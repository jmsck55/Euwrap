// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int _67new_arg_assign()
{
    int _0, _1, _2;
    

    /** 	arg_assign += 1*/
    _0 = _67arg_assign_63423;
    if (IS_ATOM_INT(_67arg_assign_63423)) {
        _67arg_assign_63423 = _67arg_assign_63423 + 1;
        if (_67arg_assign_63423 > MAXINT){
            _67arg_assign_63423 = NewDouble((double)_67arg_assign_63423);
        }
    }
    else
    _67arg_assign_63423 = binary_op(PLUS, 1, _67arg_assign_63423);
    DeRef(_0);

    /** 	return arg_assign*/
    Ref(_67arg_assign_63423);
    return _67arg_assign_63423;
    ;
}


void _67open_err_file()
{
    int _31767 = NOVALUE;
    int _0, _1, _2;
    

    /** 	err_file = open(err_file_name, "w")*/
    _67err_file_63528 = EOpen(_67err_file_name_63529, _22143, 0);

    /** 	if err_file = -1 then*/
    if (_67err_file_63528 != -1)
    goto L1; // [14] 36

    /** 		puts(2, "Can't open " & err_file_name & '\n')*/
    {
        int concat_list[3];

        concat_list[0] = 10;
        concat_list[1] = _67err_file_name_63529;
        concat_list[2] = _31766;
        Concat_N((object_ptr)&_31767, concat_list, 3);
    }
    EPuts(2, _31767); // DJP 
    DeRefDS(_31767);
    _31767 = NOVALUE;

    /** 		abort(1)*/
    UserCleanup(1);
L1: 

    /** end procedure*/
    return;
    ;
}


void _67both_puts(int _s_63542)
{
    int _0, _1, _2;
    

    /** 	if screen_err_out then*/
    if (_67screen_err_out_63539 == 0)
    {
        goto L1; // [5] 14
    }
    else{
    }

    /** 		puts(2, s)*/
    EPuts(2, _s_63542); // DJP 
L1: 

    /** 	puts(err_file, s)*/
    EPuts(_67err_file_63528, _s_63542); // DJP 

    /** end procedure*/
    DeRef(_s_63542);
    return;
    ;
}


void _67both_printf(int _format_63546, int _items_63547)
{
    int _0, _1, _2;
    

    /** 	if screen_err_out then*/
    if (_67screen_err_out_63539 == 0)
    {
        goto L1; // [9] 19
    }
    else{
    }

    /** 		printf(2, format, items)*/
    EPrintf(2, _format_63546, _items_63547);
L1: 

    /** 	printf(err_file, format, items)*/
    EPrintf(_67err_file_63528, _format_63546, _items_63547);

    /** end procedure*/
    DeRefDSi(_format_63546);
    DeRefDS(_items_63547);
    return;
    ;
}


int _67find_line(int _sub_63552, int _pc_63553)
{
    int _linetab_63554 = NOVALUE;
    int _line_63555 = NOVALUE;
    int _gline_63556 = NOVALUE;
    int _31791 = NOVALUE;
    int _31790 = NOVALUE;
    int _31789 = NOVALUE;
    int _31788 = NOVALUE;
    int _31787 = NOVALUE;
    int _31786 = NOVALUE;
    int _31784 = NOVALUE;
    int _31783 = NOVALUE;
    int _31782 = NOVALUE;
    int _31780 = NOVALUE;
    int _31779 = NOVALUE;
    int _31778 = NOVALUE;
    int _31777 = NOVALUE;
    int _31775 = NOVALUE;
    int _31774 = NOVALUE;
    int _31772 = NOVALUE;
    int _31771 = NOVALUE;
    int _31770 = NOVALUE;
    int _31768 = NOVALUE;
    int _0, _1, _2;
    

    /** 	linetab = SymTab[sub][S_LINETAB]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _31768 = (int)*(((s1_ptr)_2)->base + _sub_63552);
    DeRef(_linetab_63554);
    _2 = (int)SEQ_PTR(_31768);
    if (!IS_ATOM_INT(_26S_LINETAB_11689)){
        _linetab_63554 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_LINETAB_11689)->dbl));
    }
    else{
        _linetab_63554 = (int)*(((s1_ptr)_2)->base + _26S_LINETAB_11689);
    }
    Ref(_linetab_63554);
    _31768 = NOVALUE;

    /** 	line = 1*/
    _line_63555 = 1;

    /** 	for i = 1 to length(linetab) do*/
    if (IS_SEQUENCE(_linetab_63554)){
            _31770 = SEQ_PTR(_linetab_63554)->length;
    }
    else {
        _31770 = 1;
    }
    {
        int _i_63562;
        _i_63562 = 1;
L1: 
        if (_i_63562 > _31770){
            goto L2; // [31] 119
        }

        /** 		if linetab[i] >= pc or linetab[i] = -2 then*/
        _2 = (int)SEQ_PTR(_linetab_63554);
        _31771 = (int)*(((s1_ptr)_2)->base + _i_63562);
        if (IS_ATOM_INT(_31771)) {
            _31772 = (_31771 >= _pc_63553);
        }
        else {
            _31772 = binary_op(GREATEREQ, _31771, _pc_63553);
        }
        _31771 = NOVALUE;
        if (IS_ATOM_INT(_31772)) {
            if (_31772 != 0) {
                goto L3; // [48] 65
            }
        }
        else {
            if (DBL_PTR(_31772)->dbl != 0.0) {
                goto L3; // [48] 65
            }
        }
        _2 = (int)SEQ_PTR(_linetab_63554);
        _31774 = (int)*(((s1_ptr)_2)->base + _i_63562);
        if (IS_ATOM_INT(_31774)) {
            _31775 = (_31774 == -2);
        }
        else {
            _31775 = binary_op(EQUALS, _31774, -2);
        }
        _31774 = NOVALUE;
        if (_31775 == 0) {
            DeRef(_31775);
            _31775 = NOVALUE;
            goto L4; // [61] 112
        }
        else {
            if (!IS_ATOM_INT(_31775) && DBL_PTR(_31775)->dbl == 0.0){
                DeRef(_31775);
                _31775 = NOVALUE;
                goto L4; // [61] 112
            }
            DeRef(_31775);
            _31775 = NOVALUE;
        }
        DeRef(_31775);
        _31775 = NOVALUE;
L3: 

        /** 			line = i-1*/
        _line_63555 = _i_63562 - 1;

        /** 			while line > 1 and linetab[line] = -1 do*/
L5: 
        _31777 = (_line_63555 > 1);
        if (_31777 == 0) {
            goto L2; // [80] 119
        }
        _2 = (int)SEQ_PTR(_linetab_63554);
        _31779 = (int)*(((s1_ptr)_2)->base + _line_63555);
        if (IS_ATOM_INT(_31779)) {
            _31780 = (_31779 == -1);
        }
        else {
            _31780 = binary_op(EQUALS, _31779, -1);
        }
        _31779 = NOVALUE;
        if (_31780 <= 0) {
            if (_31780 == 0) {
                DeRef(_31780);
                _31780 = NOVALUE;
                goto L2; // [93] 119
            }
            else {
                if (!IS_ATOM_INT(_31780) && DBL_PTR(_31780)->dbl == 0.0){
                    DeRef(_31780);
                    _31780 = NOVALUE;
                    goto L2; // [93] 119
                }
                DeRef(_31780);
                _31780 = NOVALUE;
            }
        }
        DeRef(_31780);
        _31780 = NOVALUE;

        /** 				line -= 1*/
        _line_63555 = _line_63555 - 1;

        /** 			end while*/
        goto L5; // [104] 76

        /** 			exit*/
        goto L2; // [109] 119
L4: 

        /** 	end for*/
        _i_63562 = _i_63562 + 1;
        goto L1; // [114] 38
L2: 
        ;
    }

    /** 	gline = SymTab[sub][S_FIRSTLINE] + line - 1*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _31782 = (int)*(((s1_ptr)_2)->base + _sub_63552);
    _2 = (int)SEQ_PTR(_31782);
    if (!IS_ATOM_INT(_26S_FIRSTLINE_11694)){
        _31783 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_FIRSTLINE_11694)->dbl));
    }
    else{
        _31783 = (int)*(((s1_ptr)_2)->base + _26S_FIRSTLINE_11694);
    }
    _31782 = NOVALUE;
    if (IS_ATOM_INT(_31783)) {
        _31784 = _31783 + _line_63555;
        if ((long)((unsigned long)_31784 + (unsigned long)HIGH_BITS) >= 0) 
        _31784 = NewDouble((double)_31784);
    }
    else {
        _31784 = binary_op(PLUS, _31783, _line_63555);
    }
    _31783 = NOVALUE;
    if (IS_ATOM_INT(_31784)) {
        _gline_63556 = _31784 - 1;
    }
    else {
        _gline_63556 = binary_op(MINUS, _31784, 1);
    }
    DeRef(_31784);
    _31784 = NOVALUE;
    if (!IS_ATOM_INT(_gline_63556)) {
        _1 = (long)(DBL_PTR(_gline_63556)->dbl);
        DeRefDS(_gline_63556);
        _gline_63556 = _1;
    }

    /** 	return {known_files[slist[gline][LOCAL_FILE_NO]], slist[gline][LINE]}*/
    _2 = (int)SEQ_PTR(_26slist_12073);
    _31786 = (int)*(((s1_ptr)_2)->base + _gline_63556);
    _2 = (int)SEQ_PTR(_31786);
    _31787 = (int)*(((s1_ptr)_2)->base + 3);
    _31786 = NOVALUE;
    _2 = (int)SEQ_PTR(_27known_files_10922);
    if (!IS_ATOM_INT(_31787)){
        _31788 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_31787)->dbl));
    }
    else{
        _31788 = (int)*(((s1_ptr)_2)->base + _31787);
    }
    _2 = (int)SEQ_PTR(_26slist_12073);
    _31789 = (int)*(((s1_ptr)_2)->base + _gline_63556);
    _2 = (int)SEQ_PTR(_31789);
    _31790 = (int)*(((s1_ptr)_2)->base + 2);
    _31789 = NOVALUE;
    Ref(_31790);
    Ref(_31788);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _31788;
    ((int *)_2)[2] = _31790;
    _31791 = MAKE_SEQ(_1);
    _31790 = NOVALUE;
    _31788 = NOVALUE;
    DeRef(_linetab_63554);
    DeRef(_31777);
    _31777 = NOVALUE;
    DeRef(_31772);
    _31772 = NOVALUE;
    _31787 = NOVALUE;
    return _31791;
    ;
}


void _67show_var(int _x_63597)
{
    int _31805 = NOVALUE;
    int _31803 = NOVALUE;
    int _31802 = NOVALUE;
    int _31801 = NOVALUE;
    int _31800 = NOVALUE;
    int _31799 = NOVALUE;
    int _31797 = NOVALUE;
    int _31796 = NOVALUE;
    int _31795 = NOVALUE;
    int _31793 = NOVALUE;
    int _31792 = NOVALUE;
    int _0, _1, _2;
    

    /** 	puts(err_file, "    " & SymTab[x][S_NAME] & " = ")*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _31792 = (int)*(((s1_ptr)_2)->base + _x_63597);
    _2 = (int)SEQ_PTR(_31792);
    if (!IS_ATOM_INT(_26S_NAME_11654)){
        _31793 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NAME_11654)->dbl));
    }
    else{
        _31793 = (int)*(((s1_ptr)_2)->base + _26S_NAME_11654);
    }
    _31792 = NOVALUE;
    {
        int concat_list[3];

        concat_list[0] = _31794;
        concat_list[1] = _31793;
        concat_list[2] = _24978;
        Concat_N((object_ptr)&_31795, concat_list, 3);
    }
    _31793 = NOVALUE;
    EPuts(_67err_file_63528, _31795); // DJP 
    DeRefDS(_31795);
    _31795 = NOVALUE;

    /** 	if equal(val[x], NOVALUE) then*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _31796 = (int)*(((s1_ptr)_2)->base + _x_63597);
    if (_31796 == _26NOVALUE_11836)
    _31797 = 1;
    else if (IS_ATOM_INT(_31796) && IS_ATOM_INT(_26NOVALUE_11836))
    _31797 = 0;
    else
    _31797 = (compare(_31796, _26NOVALUE_11836) == 0);
    _31796 = NOVALUE;
    if (_31797 == 0)
    {
        _31797 = NOVALUE;
        goto L1; // [42] 55
    }
    else{
        _31797 = NOVALUE;
    }

    /** 		puts(err_file, "<no value>")*/
    EPuts(_67err_file_63528, _31798); // DJP 
    goto L2; // [52] 102
L1: 

    /** 		pretty_print(err_file, val[x],*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _31799 = (int)*(((s1_ptr)_2)->base + _x_63597);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _31800 = (int)*(((s1_ptr)_2)->base + _x_63597);
    _2 = (int)SEQ_PTR(_31800);
    if (!IS_ATOM_INT(_26S_NAME_11654)){
        _31801 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NAME_11654)->dbl));
    }
    else{
        _31801 = (int)*(((s1_ptr)_2)->base + _26S_NAME_11654);
    }
    _31800 = NOVALUE;
    if (IS_SEQUENCE(_31801)){
            _31802 = SEQ_PTR(_31801)->length;
    }
    else {
        _31802 = 1;
    }
    _31801 = NOVALUE;
    _31803 = _31802 + 7;
    _31802 = NOVALUE;
    _1 = NewS1(9);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    *((int *)(_2+12)) = _31803;
    *((int *)(_2+16)) = 78;
    RefDS(_22614);
    *((int *)(_2+20)) = _22614;
    RefDS(_31804);
    *((int *)(_2+24)) = _31804;
    *((int *)(_2+28)) = 32;
    *((int *)(_2+32)) = 127;
    *((int *)(_2+36)) = 500;
    _31805 = MAKE_SEQ(_1);
    _31803 = NOVALUE;
    Ref(_31799);
    _10pretty_print(_67err_file_63528, _31799, _31805);
    _31799 = NOVALUE;
    _31805 = NOVALUE;
L2: 

    /** 	puts(err_file, '\n')*/
    EPuts(_67err_file_63528, 10); // DJP 

    /** end procedure*/
    _31801 = NOVALUE;
    return;
    ;
}


void _67save_private_block(int _rtn_idx_63627, int _block_63628)
{
    int _saved_63629 = NOVALUE;
    int _saved_list_63630 = NOVALUE;
    int _eentry_63631 = NOVALUE;
    int _task_63632 = NOVALUE;
    int _spot_63633 = NOVALUE;
    int _tn_63634 = NOVALUE;
    int _31832 = NOVALUE;
    int _31828 = NOVALUE;
    int _31827 = NOVALUE;
    int _31826 = NOVALUE;
    int _31825 = NOVALUE;
    int _31824 = NOVALUE;
    int _31823 = NOVALUE;
    int _31821 = NOVALUE;
    int _31819 = NOVALUE;
    int _31818 = NOVALUE;
    int _31815 = NOVALUE;
    int _31813 = NOVALUE;
    int _31811 = NOVALUE;
    int _31809 = NOVALUE;
    int _31808 = NOVALUE;
    int _31806 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	task = SymTab[rtn_idx][S_RESIDENT_TASK]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _31806 = (int)*(((s1_ptr)_2)->base + _rtn_idx_63627);
    _2 = (int)SEQ_PTR(_31806);
    _task_63632 = (int)*(((s1_ptr)_2)->base + 25);
    if (!IS_ATOM_INT(_task_63632)){
        _task_63632 = (long)DBL_PTR(_task_63632)->dbl;
    }
    _31806 = NOVALUE;

    /** 	eentry = {task, tcb[task][TASK_TID], block, 0}*/
    _2 = (int)SEQ_PTR(_67tcb_63522);
    _31808 = (int)*(((s1_ptr)_2)->base + _task_63632);
    _2 = (int)SEQ_PTR(_31808);
    _31809 = (int)*(((s1_ptr)_2)->base + 2);
    _31808 = NOVALUE;
    _0 = _eentry_63631;
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _task_63632;
    Ref(_31809);
    *((int *)(_2+8)) = _31809;
    RefDS(_block_63628);
    *((int *)(_2+12)) = _block_63628;
    *((int *)(_2+16)) = 0;
    _eentry_63631 = MAKE_SEQ(_1);
    DeRef(_0);
    _31809 = NOVALUE;

    /** 	saved = SymTab[rtn_idx][S_SAVED_PRIVATES]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _31811 = (int)*(((s1_ptr)_2)->base + _rtn_idx_63627);
    DeRef(_saved_63629);
    _2 = (int)SEQ_PTR(_31811);
    _saved_63629 = (int)*(((s1_ptr)_2)->base + 26);
    Ref(_saved_63629);
    _31811 = NOVALUE;

    /** 	if length(saved) = 0 then*/
    if (IS_SEQUENCE(_saved_63629)){
            _31813 = SEQ_PTR(_saved_63629)->length;
    }
    else {
        _31813 = 1;
    }
    if (_31813 != 0)
    goto L1; // [61] 78

    /** 		saved = {1, -- index of first item*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_eentry_63631);
    *((int *)(_2+4)) = _eentry_63631;
    _31815 = MAKE_SEQ(_1);
    DeRefDS(_saved_63629);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = _31815;
    _saved_63629 = MAKE_SEQ(_1);
    _31815 = NOVALUE;
    goto L2; // [75] 219
L1: 

    /** 		saved_list = saved[2]*/
    DeRef(_saved_list_63630);
    _2 = (int)SEQ_PTR(_saved_63629);
    _saved_list_63630 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_saved_list_63630);

    /** 		spot = 0*/
    _spot_63633 = 0;

    /** 		for i = 1 to length(saved_list) do*/
    if (IS_SEQUENCE(_saved_list_63630)){
            _31818 = SEQ_PTR(_saved_list_63630)->length;
    }
    else {
        _31818 = 1;
    }
    {
        int _i_63654;
        _i_63654 = 1;
L3: 
        if (_i_63654 > _31818){
            goto L4; // [96] 169
        }

        /** 			tn = saved_list[i][SP_TASK_NUMBER]*/
        _2 = (int)SEQ_PTR(_saved_list_63630);
        _31819 = (int)*(((s1_ptr)_2)->base + _i_63654);
        _2 = (int)SEQ_PTR(_31819);
        _tn_63634 = (int)*(((s1_ptr)_2)->base + 1);
        if (!IS_ATOM_INT(_tn_63634)){
            _tn_63634 = (long)DBL_PTR(_tn_63634)->dbl;
        }
        _31819 = NOVALUE;

        /** 			if tn = -1 or*/
        _31821 = (_tn_63634 == -1);
        if (_31821 != 0) {
            goto L5; // [121] 152
        }
        _2 = (int)SEQ_PTR(_saved_list_63630);
        _31823 = (int)*(((s1_ptr)_2)->base + _i_63654);
        _2 = (int)SEQ_PTR(_31823);
        _31824 = (int)*(((s1_ptr)_2)->base + 2);
        _31823 = NOVALUE;
        _2 = (int)SEQ_PTR(_67tcb_63522);
        _31825 = (int)*(((s1_ptr)_2)->base + _tn_63634);
        _2 = (int)SEQ_PTR(_31825);
        _31826 = (int)*(((s1_ptr)_2)->base + 2);
        _31825 = NOVALUE;
        if (IS_ATOM_INT(_31824) && IS_ATOM_INT(_31826)) {
            _31827 = (_31824 != _31826);
        }
        else {
            _31827 = binary_op(NOTEQ, _31824, _31826);
        }
        _31824 = NOVALUE;
        _31826 = NOVALUE;
        if (_31827 == 0) {
            DeRef(_31827);
            _31827 = NOVALUE;
            goto L6; // [148] 162
        }
        else {
            if (!IS_ATOM_INT(_31827) && DBL_PTR(_31827)->dbl == 0.0){
                DeRef(_31827);
                _31827 = NOVALUE;
                goto L6; // [148] 162
            }
            DeRef(_31827);
            _31827 = NOVALUE;
        }
        DeRef(_31827);
        _31827 = NOVALUE;
L5: 

        /** 				spot = i*/
        _spot_63633 = _i_63654;

        /** 				exit*/
        goto L4; // [159] 169
L6: 

        /** 		end for*/
        _i_63654 = _i_63654 + 1;
        goto L3; // [164] 103
L4: 
        ;
    }

    /** 		eentry[SP_NEXT] = saved[1] -- new eentry points to previous first*/
    _2 = (int)SEQ_PTR(_saved_63629);
    _31828 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_31828);
    _2 = (int)SEQ_PTR(_eentry_63631);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _eentry_63631 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = _31828;
    if( _1 != _31828 ){
        DeRef(_1);
    }
    _31828 = NOVALUE;

    /** 		if spot = 0 then*/
    if (_spot_63633 != 0)
    goto L7; // [181] 199

    /** 			saved_list = append(saved_list, eentry)*/
    RefDS(_eentry_63631);
    Append(&_saved_list_63630, _saved_list_63630, _eentry_63631);

    /** 			spot = length(saved_list)*/
    if (IS_SEQUENCE(_saved_list_63630)){
            _spot_63633 = SEQ_PTR(_saved_list_63630)->length;
    }
    else {
        _spot_63633 = 1;
    }
    goto L8; // [196] 206
L7: 

    /** 			saved_list[spot] = eentry*/
    RefDS(_eentry_63631);
    _2 = (int)SEQ_PTR(_saved_list_63630);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _saved_list_63630 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _spot_63633);
    _1 = *(int *)_2;
    *(int *)_2 = _eentry_63631;
    DeRef(_1);
L8: 

    /** 		saved[1] = spot -- it becomes the first on the list*/
    _2 = (int)SEQ_PTR(_saved_63629);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _saved_63629 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _spot_63633;
    DeRef(_1);

    /** 		saved[2] = saved_list*/
    RefDS(_saved_list_63630);
    _2 = (int)SEQ_PTR(_saved_63629);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _saved_63629 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _saved_list_63630;
    DeRef(_1);
L2: 

    /** 	SymTab[rtn_idx][S_SAVED_PRIVATES] = saved*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_rtn_idx_63627 + ((s1_ptr)_2)->base);
    RefDS(_saved_63629);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 26);
    _1 = *(int *)_2;
    *(int *)_2 = _saved_63629;
    DeRef(_1);
    _31832 = NOVALUE;

    /** end procedure*/
    DeRefDS(_block_63628);
    DeRefDS(_saved_63629);
    DeRef(_saved_list_63630);
    DeRef(_eentry_63631);
    DeRef(_31821);
    _31821 = NOVALUE;
    return;
    ;
}


int _67load_private_block(int _rtn_idx_63679, int _task_63680)
{
    int _saved_63681 = NOVALUE;
    int _saved_list_63682 = NOVALUE;
    int _block_63683 = NOVALUE;
    int _p_63684 = NOVALUE;
    int _prev_p_63685 = NOVALUE;
    int _first_63686 = NOVALUE;
    int _31856 = NOVALUE;
    int _31854 = NOVALUE;
    int _31853 = NOVALUE;
    int _31852 = NOVALUE;
    int _31850 = NOVALUE;
    int _31848 = NOVALUE;
    int _31845 = NOVALUE;
    int _31843 = NOVALUE;
    int _31841 = NOVALUE;
    int _31839 = NOVALUE;
    int _31838 = NOVALUE;
    int _31834 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	saved = SymTab[rtn_idx][S_SAVED_PRIVATES]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _31834 = (int)*(((s1_ptr)_2)->base + _rtn_idx_63679);
    DeRef(_saved_63681);
    _2 = (int)SEQ_PTR(_31834);
    _saved_63681 = (int)*(((s1_ptr)_2)->base + 26);
    Ref(_saved_63681);
    _31834 = NOVALUE;

    /** 	first = saved[1]*/
    _2 = (int)SEQ_PTR(_saved_63681);
    _first_63686 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_first_63686))
    _first_63686 = (long)DBL_PTR(_first_63686)->dbl;

    /** 	p = first -- won't be 0*/
    _p_63684 = _first_63686;

    /** 	prev_p = -1*/
    _prev_p_63685 = -1;

    /** 	saved_list = saved[2]*/
    DeRef(_saved_list_63682);
    _2 = (int)SEQ_PTR(_saved_63681);
    _saved_list_63682 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_saved_list_63682);

    /** 	while TRUE do*/
L1: 
    if (_9TRUE_430 == 0)
    {
        goto L2; // [52] 200
    }
    else{
    }

    /** 		if saved_list[p][SP_TASK_NUMBER] = task then*/
    _2 = (int)SEQ_PTR(_saved_list_63682);
    _31838 = (int)*(((s1_ptr)_2)->base + _p_63684);
    _2 = (int)SEQ_PTR(_31838);
    _31839 = (int)*(((s1_ptr)_2)->base + 1);
    _31838 = NOVALUE;
    if (binary_op_a(NOTEQ, _31839, _task_63680)){
        _31839 = NOVALUE;
        goto L3; // [65] 178
    }
    _31839 = NOVALUE;

    /** 			block = saved_list[p][SP_BLOCK]*/
    _2 = (int)SEQ_PTR(_saved_list_63682);
    _31841 = (int)*(((s1_ptr)_2)->base + _p_63684);
    DeRef(_block_63683);
    _2 = (int)SEQ_PTR(_31841);
    _block_63683 = (int)*(((s1_ptr)_2)->base + 3);
    Ref(_block_63683);
    _31841 = NOVALUE;

    /** 			saved_list[p][SP_TASK_NUMBER] = -1 -- mark it as deleted*/
    _2 = (int)SEQ_PTR(_saved_list_63682);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _saved_list_63682 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_63684 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = -1;
    DeRef(_1);
    _31843 = NOVALUE;

    /** 			saved_list[p][SP_BLOCK] = {}*/
    _2 = (int)SEQ_PTR(_saved_list_63682);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _saved_list_63682 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_63684 + ((s1_ptr)_2)->base);
    RefDS(_22037);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = _22037;
    DeRef(_1);
    _31845 = NOVALUE;

    /** 			if prev_p = -1 then*/
    if (_prev_p_63685 != -1)
    goto L4; // [105] 124

    /** 				first = saved_list[p][SP_NEXT]*/
    _2 = (int)SEQ_PTR(_saved_list_63682);
    _31848 = (int)*(((s1_ptr)_2)->base + _p_63684);
    _2 = (int)SEQ_PTR(_31848);
    _first_63686 = (int)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_first_63686)){
        _first_63686 = (long)DBL_PTR(_first_63686)->dbl;
    }
    _31848 = NOVALUE;
    goto L5; // [121] 144
L4: 

    /** 				saved_list[prev_p][SP_NEXT] = saved_list[p][SP_NEXT]*/
    _2 = (int)SEQ_PTR(_saved_list_63682);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _saved_list_63682 = MAKE_SEQ(_2);
    }
    _3 = (int)(_prev_p_63685 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_saved_list_63682);
    _31852 = (int)*(((s1_ptr)_2)->base + _p_63684);
    _2 = (int)SEQ_PTR(_31852);
    _31853 = (int)*(((s1_ptr)_2)->base + 4);
    _31852 = NOVALUE;
    Ref(_31853);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = _31853;
    if( _1 != _31853 ){
        DeRef(_1);
    }
    _31853 = NOVALUE;
    _31850 = NOVALUE;
L5: 

    /** 			saved[1] = first*/
    _2 = (int)SEQ_PTR(_saved_63681);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _saved_63681 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _first_63686;
    DeRef(_1);

    /** 			saved[2] = saved_list*/
    RefDS(_saved_list_63682);
    _2 = (int)SEQ_PTR(_saved_63681);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _saved_63681 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _saved_list_63682;
    DeRef(_1);

    /** 			SymTab[rtn_idx][S_SAVED_PRIVATES] = saved*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_rtn_idx_63679 + ((s1_ptr)_2)->base);
    RefDS(_saved_63681);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 26);
    _1 = *(int *)_2;
    *(int *)_2 = _saved_63681;
    DeRef(_1);
    _31854 = NOVALUE;

    /** 			return block*/
    DeRefDS(_saved_63681);
    DeRefDS(_saved_list_63682);
    return _block_63683;
L3: 

    /** 		prev_p = p*/
    _prev_p_63685 = _p_63684;

    /** 		p = saved_list[p][SP_NEXT]*/
    _2 = (int)SEQ_PTR(_saved_list_63682);
    _31856 = (int)*(((s1_ptr)_2)->base + _p_63684);
    _2 = (int)SEQ_PTR(_31856);
    _p_63684 = (int)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_p_63684)){
        _p_63684 = (long)DBL_PTR(_p_63684)->dbl;
    }
    _31856 = NOVALUE;

    /** 	end while*/
    goto L1; // [197] 50
L2: 
    ;
}


void _67restore_privates(int _this_routine_63723)
{
    int _arg_63725 = NOVALUE;
    int _private_block_63726 = NOVALUE;
    int _base_63727 = NOVALUE;
    int _31923 = NOVALUE;
    int _31921 = NOVALUE;
    int _31919 = NOVALUE;
    int _31916 = NOVALUE;
    int _31914 = NOVALUE;
    int _31912 = NOVALUE;
    int _31910 = NOVALUE;
    int _31909 = NOVALUE;
    int _31908 = NOVALUE;
    int _31907 = NOVALUE;
    int _31906 = NOVALUE;
    int _31905 = NOVALUE;
    int _31904 = NOVALUE;
    int _31903 = NOVALUE;
    int _31902 = NOVALUE;
    int _31901 = NOVALUE;
    int _31900 = NOVALUE;
    int _31899 = NOVALUE;
    int _31898 = NOVALUE;
    int _31897 = NOVALUE;
    int _31896 = NOVALUE;
    int _31894 = NOVALUE;
    int _31891 = NOVALUE;
    int _31889 = NOVALUE;
    int _31886 = NOVALUE;
    int _31884 = NOVALUE;
    int _31882 = NOVALUE;
    int _31880 = NOVALUE;
    int _31879 = NOVALUE;
    int _31878 = NOVALUE;
    int _31877 = NOVALUE;
    int _31876 = NOVALUE;
    int _31875 = NOVALUE;
    int _31874 = NOVALUE;
    int _31873 = NOVALUE;
    int _31872 = NOVALUE;
    int _31871 = NOVALUE;
    int _31870 = NOVALUE;
    int _31869 = NOVALUE;
    int _31868 = NOVALUE;
    int _31867 = NOVALUE;
    int _31866 = NOVALUE;
    int _31864 = NOVALUE;
    int _31862 = NOVALUE;
    int _31861 = NOVALUE;
    int _31859 = NOVALUE;
    int _31858 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_this_routine_63723)) {
        _1 = (long)(DBL_PTR(_this_routine_63723)->dbl);
        DeRefDS(_this_routine_63723);
        _this_routine_63723 = _1;
    }

    /** 	sequence private_block*/

    /** 	integer base*/

    /** 	if SymTab[this_routine][S_RESIDENT_TASK] != current_task then*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _31858 = (int)*(((s1_ptr)_2)->base + _this_routine_63723);
    _2 = (int)SEQ_PTR(_31858);
    _31859 = (int)*(((s1_ptr)_2)->base + 25);
    _31858 = NOVALUE;
    if (binary_op_a(EQUALS, _31859, _67current_task_63496)){
        _31859 = NOVALUE;
        goto L1; // [23] 535
    }
    _31859 = NOVALUE;

    /** 		if SymTab[this_routine][S_RESIDENT_TASK] != 0 then*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _31861 = (int)*(((s1_ptr)_2)->base + _this_routine_63723);
    _2 = (int)SEQ_PTR(_31861);
    _31862 = (int)*(((s1_ptr)_2)->base + 25);
    _31861 = NOVALUE;
    if (binary_op_a(EQUALS, _31862, 0)){
        _31862 = NOVALUE;
        goto L2; // [41] 274
    }
    _31862 = NOVALUE;

    /** 			arg = SymTab[this_routine][S_NEXT]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _31864 = (int)*(((s1_ptr)_2)->base + _this_routine_63723);
    _2 = (int)SEQ_PTR(_31864);
    _arg_63725 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_arg_63725)){
        _arg_63725 = (long)DBL_PTR(_arg_63725)->dbl;
    }
    _31864 = NOVALUE;

    /** 			private_block = {}*/
    RefDS(_22037);
    DeRef(_private_block_63726);
    _private_block_63726 = _22037;

    /** 			while arg != 0 */
L3: 
    _31866 = (_arg_63725 != 0);
    if (_31866 == 0) {
        goto L4; // [77] 209
    }
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _31868 = (int)*(((s1_ptr)_2)->base + _arg_63725);
    _2 = (int)SEQ_PTR(_31868);
    _31869 = (int)*(((s1_ptr)_2)->base + 4);
    _31868 = NOVALUE;
    if (IS_ATOM_INT(_31869)) {
        _31870 = (_31869 <= 3);
    }
    else {
        _31870 = binary_op(LESSEQ, _31869, 3);
    }
    _31869 = NOVALUE;
    if (IS_ATOM_INT(_31870)) {
        if (_31870 != 0) {
            DeRef(_31871);
            _31871 = 1;
            goto L5; // [99] 125
        }
    }
    else {
        if (DBL_PTR(_31870)->dbl != 0.0) {
            DeRef(_31871);
            _31871 = 1;
            goto L5; // [99] 125
        }
    }
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _31872 = (int)*(((s1_ptr)_2)->base + _arg_63725);
    _2 = (int)SEQ_PTR(_31872);
    _31873 = (int)*(((s1_ptr)_2)->base + 4);
    _31872 = NOVALUE;
    if (IS_ATOM_INT(_31873)) {
        _31874 = (_31873 == 2);
    }
    else {
        _31874 = binary_op(EQUALS, _31873, 2);
    }
    _31873 = NOVALUE;
    DeRef(_31871);
    if (IS_ATOM_INT(_31874))
    _31871 = (_31874 != 0);
    else
    _31871 = DBL_PTR(_31874)->dbl != 0.0;
L5: 
    if (_31871 != 0) {
        DeRef(_31875);
        _31875 = 1;
        goto L6; // [125] 151
    }
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _31876 = (int)*(((s1_ptr)_2)->base + _arg_63725);
    _2 = (int)SEQ_PTR(_31876);
    _31877 = (int)*(((s1_ptr)_2)->base + 4);
    _31876 = NOVALUE;
    if (IS_ATOM_INT(_31877)) {
        _31878 = (_31877 == 9);
    }
    else {
        _31878 = binary_op(EQUALS, _31877, 9);
    }
    _31877 = NOVALUE;
    if (IS_ATOM_INT(_31878))
    _31875 = (_31878 != 0);
    else
    _31875 = DBL_PTR(_31878)->dbl != 0.0;
L6: 
    if (_31875 == 0)
    {
        _31875 = NOVALUE;
        goto L4; // [152] 209
    }
    else{
        _31875 = NOVALUE;
    }

    /** 				if SymTab[arg][S_SCOPE] != SC_UNDEFINED then*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _31879 = (int)*(((s1_ptr)_2)->base + _arg_63725);
    _2 = (int)SEQ_PTR(_31879);
    _31880 = (int)*(((s1_ptr)_2)->base + 4);
    _31879 = NOVALUE;
    if (binary_op_a(EQUALS, _31880, 9)){
        _31880 = NOVALUE;
        goto L7; // [171] 188
    }
    _31880 = NOVALUE;

    /** 					private_block = append(private_block, val[arg])*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _31882 = (int)*(((s1_ptr)_2)->base + _arg_63725);
    Ref(_31882);
    Append(&_private_block_63726, _private_block_63726, _31882);
    _31882 = NOVALUE;
L7: 

    /** 				arg = SymTab[arg][S_NEXT]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _31884 = (int)*(((s1_ptr)_2)->base + _arg_63725);
    _2 = (int)SEQ_PTR(_31884);
    _arg_63725 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_arg_63725)){
        _arg_63725 = (long)DBL_PTR(_arg_63725)->dbl;
    }
    _31884 = NOVALUE;

    /** 			end while*/
    goto L3; // [206] 73
L4: 

    /** 			arg = SymTab[this_routine][S_TEMPS]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _31886 = (int)*(((s1_ptr)_2)->base + _this_routine_63723);
    _2 = (int)SEQ_PTR(_31886);
    if (!IS_ATOM_INT(_26S_TEMPS_11699)){
        _arg_63725 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_TEMPS_11699)->dbl));
    }
    else{
        _arg_63725 = (int)*(((s1_ptr)_2)->base + _26S_TEMPS_11699);
    }
    if (!IS_ATOM_INT(_arg_63725)){
        _arg_63725 = (long)DBL_PTR(_arg_63725)->dbl;
    }
    _31886 = NOVALUE;

    /** 			while arg != 0 do*/
L8: 
    if (_arg_63725 == 0)
    goto L9; // [230] 267

    /** 				private_block = append(private_block, val[arg])*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _31889 = (int)*(((s1_ptr)_2)->base + _arg_63725);
    Ref(_31889);
    Append(&_private_block_63726, _private_block_63726, _31889);
    _31889 = NOVALUE;

    /** 				arg = SymTab[arg][S_NEXT]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _31891 = (int)*(((s1_ptr)_2)->base + _arg_63725);
    _2 = (int)SEQ_PTR(_31891);
    _arg_63725 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_arg_63725)){
        _arg_63725 = (long)DBL_PTR(_arg_63725)->dbl;
    }
    _31891 = NOVALUE;

    /** 			end while*/
    goto L8; // [264] 230
L9: 

    /** 			save_private_block(this_routine, private_block)*/
    RefDS(_private_block_63726);
    _67save_private_block(_this_routine_63723, _private_block_63726);
L2: 

    /** 		private_block = load_private_block(this_routine, current_task)*/
    _0 = _private_block_63726;
    _private_block_63726 = _67load_private_block(_this_routine_63723, _67current_task_63496);
    DeRef(_0);

    /** 		base = 1*/
    _base_63727 = 1;

    /** 		arg = SymTab[this_routine][S_NEXT]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _31894 = (int)*(((s1_ptr)_2)->base + _this_routine_63723);
    _2 = (int)SEQ_PTR(_31894);
    _arg_63725 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_arg_63725)){
        _arg_63725 = (long)DBL_PTR(_arg_63725)->dbl;
    }
    _31894 = NOVALUE;

    /** 		while arg != 0 */
LA: 
    _31896 = (_arg_63725 != 0);
    if (_31896 == 0) {
        goto LB; // [315] 453
    }
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _31898 = (int)*(((s1_ptr)_2)->base + _arg_63725);
    _2 = (int)SEQ_PTR(_31898);
    _31899 = (int)*(((s1_ptr)_2)->base + 4);
    _31898 = NOVALUE;
    if (IS_ATOM_INT(_31899)) {
        _31900 = (_31899 <= 3);
    }
    else {
        _31900 = binary_op(LESSEQ, _31899, 3);
    }
    _31899 = NOVALUE;
    if (IS_ATOM_INT(_31900)) {
        if (_31900 != 0) {
            DeRef(_31901);
            _31901 = 1;
            goto LC; // [337] 363
        }
    }
    else {
        if (DBL_PTR(_31900)->dbl != 0.0) {
            DeRef(_31901);
            _31901 = 1;
            goto LC; // [337] 363
        }
    }
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _31902 = (int)*(((s1_ptr)_2)->base + _arg_63725);
    _2 = (int)SEQ_PTR(_31902);
    _31903 = (int)*(((s1_ptr)_2)->base + 4);
    _31902 = NOVALUE;
    if (IS_ATOM_INT(_31903)) {
        _31904 = (_31903 == 2);
    }
    else {
        _31904 = binary_op(EQUALS, _31903, 2);
    }
    _31903 = NOVALUE;
    DeRef(_31901);
    if (IS_ATOM_INT(_31904))
    _31901 = (_31904 != 0);
    else
    _31901 = DBL_PTR(_31904)->dbl != 0.0;
LC: 
    if (_31901 != 0) {
        DeRef(_31905);
        _31905 = 1;
        goto LD; // [363] 389
    }
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _31906 = (int)*(((s1_ptr)_2)->base + _arg_63725);
    _2 = (int)SEQ_PTR(_31906);
    _31907 = (int)*(((s1_ptr)_2)->base + 4);
    _31906 = NOVALUE;
    if (IS_ATOM_INT(_31907)) {
        _31908 = (_31907 == 9);
    }
    else {
        _31908 = binary_op(EQUALS, _31907, 9);
    }
    _31907 = NOVALUE;
    if (IS_ATOM_INT(_31908))
    _31905 = (_31908 != 0);
    else
    _31905 = DBL_PTR(_31908)->dbl != 0.0;
LD: 
    if (_31905 == 0)
    {
        _31905 = NOVALUE;
        goto LB; // [390] 453
    }
    else{
        _31905 = NOVALUE;
    }

    /** 			if SymTab[arg][S_SCOPE] != SC_UNDEFINED then*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _31909 = (int)*(((s1_ptr)_2)->base + _arg_63725);
    _2 = (int)SEQ_PTR(_31909);
    _31910 = (int)*(((s1_ptr)_2)->base + 4);
    _31909 = NOVALUE;
    if (binary_op_a(EQUALS, _31910, 9)){
        _31910 = NOVALUE;
        goto LE; // [409] 432
    }
    _31910 = NOVALUE;

    /** 				val[arg] = private_block[base]*/
    _2 = (int)SEQ_PTR(_private_block_63726);
    _31912 = (int)*(((s1_ptr)_2)->base + _base_63727);
    Ref(_31912);
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _arg_63725);
    _1 = *(int *)_2;
    *(int *)_2 = _31912;
    if( _1 != _31912 ){
        DeRef(_1);
    }
    _31912 = NOVALUE;

    /** 				base += 1*/
    _base_63727 = _base_63727 + 1;
LE: 

    /** 			arg = SymTab[arg][S_NEXT]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _31914 = (int)*(((s1_ptr)_2)->base + _arg_63725);
    _2 = (int)SEQ_PTR(_31914);
    _arg_63725 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_arg_63725)){
        _arg_63725 = (long)DBL_PTR(_arg_63725)->dbl;
    }
    _31914 = NOVALUE;

    /** 		end while*/
    goto LA; // [450] 311
LB: 

    /** 		arg = SymTab[this_routine][S_TEMPS]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _31916 = (int)*(((s1_ptr)_2)->base + _this_routine_63723);
    _2 = (int)SEQ_PTR(_31916);
    if (!IS_ATOM_INT(_26S_TEMPS_11699)){
        _arg_63725 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_TEMPS_11699)->dbl));
    }
    else{
        _arg_63725 = (int)*(((s1_ptr)_2)->base + _26S_TEMPS_11699);
    }
    if (!IS_ATOM_INT(_arg_63725)){
        _arg_63725 = (long)DBL_PTR(_arg_63725)->dbl;
    }
    _31916 = NOVALUE;

    /** 		while arg != 0 do*/
LF: 
    if (_arg_63725 == 0)
    goto L10; // [474] 517

    /** 			val[arg] = private_block[base]*/
    _2 = (int)SEQ_PTR(_private_block_63726);
    _31919 = (int)*(((s1_ptr)_2)->base + _base_63727);
    Ref(_31919);
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _arg_63725);
    _1 = *(int *)_2;
    *(int *)_2 = _31919;
    if( _1 != _31919 ){
        DeRef(_1);
    }
    _31919 = NOVALUE;

    /** 			base += 1*/
    _base_63727 = _base_63727 + 1;

    /** 			arg = SymTab[arg][S_NEXT]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _31921 = (int)*(((s1_ptr)_2)->base + _arg_63725);
    _2 = (int)SEQ_PTR(_31921);
    _arg_63725 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_arg_63725)){
        _arg_63725 = (long)DBL_PTR(_arg_63725)->dbl;
    }
    _31921 = NOVALUE;

    /** 		end while*/
    goto LF; // [514] 474
L10: 

    /** 		SymTab[this_routine][S_RESIDENT_TASK] = current_task*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_this_routine_63723 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 25);
    _1 = *(int *)_2;
    *(int *)_2 = _67current_task_63496;
    DeRef(_1);
    _31923 = NOVALUE;
L1: 

    /** end procedure*/
    DeRef(_private_block_63726);
    DeRef(_31866);
    _31866 = NOVALUE;
    DeRef(_31896);
    _31896 = NOVALUE;
    DeRef(_31870);
    _31870 = NOVALUE;
    DeRef(_31874);
    _31874 = NOVALUE;
    DeRef(_31878);
    _31878 = NOVALUE;
    DeRef(_31900);
    _31900 = NOVALUE;
    DeRef(_31904);
    _31904 = NOVALUE;
    DeRef(_31908);
    _31908 = NOVALUE;
    return;
    ;
}


void _67trace_back(int _msg_63851)
{
    int _sub_63853 = NOVALUE;
    int _v_63854 = NOVALUE;
    int _levels_63855 = NOVALUE;
    int _prev_file_no_63856 = NOVALUE;
    int _task_63857 = NOVALUE;
    int _dash_count_63858 = NOVALUE;
    int _routine_name_63859 = NOVALUE;
    int _title_63860 = NOVALUE;
    int _show_message_63862 = NOVALUE;
    int _32075 = NOVALUE;
    int _32074 = NOVALUE;
    int _32072 = NOVALUE;
    int _32069 = NOVALUE;
    int _32067 = NOVALUE;
    int _32066 = NOVALUE;
    int _32065 = NOVALUE;
    int _32064 = NOVALUE;
    int _32063 = NOVALUE;
    int _32062 = NOVALUE;
    int _32061 = NOVALUE;
    int _32060 = NOVALUE;
    int _32059 = NOVALUE;
    int _32058 = NOVALUE;
    int _32057 = NOVALUE;
    int _32056 = NOVALUE;
    int _32055 = NOVALUE;
    int _32054 = NOVALUE;
    int _32052 = NOVALUE;
    int _32050 = NOVALUE;
    int _32046 = NOVALUE;
    int _32044 = NOVALUE;
    int _32042 = NOVALUE;
    int _32041 = NOVALUE;
    int _32040 = NOVALUE;
    int _32039 = NOVALUE;
    int _32038 = NOVALUE;
    int _32037 = NOVALUE;
    int _32036 = NOVALUE;
    int _32035 = NOVALUE;
    int _32034 = NOVALUE;
    int _32033 = NOVALUE;
    int _32031 = NOVALUE;
    int _32028 = NOVALUE;
    int _32027 = NOVALUE;
    int _32025 = NOVALUE;
    int _32024 = NOVALUE;
    int _32023 = NOVALUE;
    int _32021 = NOVALUE;
    int _32020 = NOVALUE;
    int _32019 = NOVALUE;
    int _32018 = NOVALUE;
    int _32017 = NOVALUE;
    int _32016 = NOVALUE;
    int _32015 = NOVALUE;
    int _32014 = NOVALUE;
    int _32013 = NOVALUE;
    int _32012 = NOVALUE;
    int _32010 = NOVALUE;
    int _32008 = NOVALUE;
    int _32007 = NOVALUE;
    int _32006 = NOVALUE;
    int _32005 = NOVALUE;
    int _32004 = NOVALUE;
    int _32003 = NOVALUE;
    int _32002 = NOVALUE;
    int _32001 = NOVALUE;
    int _32000 = NOVALUE;
    int _31999 = NOVALUE;
    int _31998 = NOVALUE;
    int _31997 = NOVALUE;
    int _31996 = NOVALUE;
    int _31995 = NOVALUE;
    int _31994 = NOVALUE;
    int _31992 = NOVALUE;
    int _31990 = NOVALUE;
    int _31989 = NOVALUE;
    int _31988 = NOVALUE;
    int _31987 = NOVALUE;
    int _31986 = NOVALUE;
    int _31985 = NOVALUE;
    int _31977 = NOVALUE;
    int _31976 = NOVALUE;
    int _31974 = NOVALUE;
    int _31973 = NOVALUE;
    int _31972 = NOVALUE;
    int _31971 = NOVALUE;
    int _31960 = NOVALUE;
    int _31959 = NOVALUE;
    int _31958 = NOVALUE;
    int _31955 = NOVALUE;
    int _31953 = NOVALUE;
    int _31952 = NOVALUE;
    int _31951 = NOVALUE;
    int _31950 = NOVALUE;
    int _31947 = NOVALUE;
    int _31945 = NOVALUE;
    int _31943 = NOVALUE;
    int _31942 = NOVALUE;
    int _31941 = NOVALUE;
    int _31938 = NOVALUE;
    int _31937 = NOVALUE;
    int _31936 = NOVALUE;
    int _31935 = NOVALUE;
    int _31934 = NOVALUE;
    int _31930 = NOVALUE;
    int _31927 = NOVALUE;
    int _31926 = NOVALUE;
    int _31925 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	integer levels, prev_file_no, task, dash_count*/

    /** 	sequence routine_name, title*/

    /** 	if atom(slist[$]) then*/
    if (IS_SEQUENCE(_26slist_12073)){
            _31925 = SEQ_PTR(_26slist_12073)->length;
    }
    else {
        _31925 = 1;
    }
    _2 = (int)SEQ_PTR(_26slist_12073);
    _31926 = (int)*(((s1_ptr)_2)->base + _31925);
    _31927 = IS_ATOM(_31926);
    _31926 = NOVALUE;
    if (_31927 == 0)
    {
        _31927 = NOVALUE;
        goto L1; // [21] 35
    }
    else{
        _31927 = NOVALUE;
    }

    /** 		slist = s_expand(slist)*/
    RefDS(_26slist_12073);
    _0 = _60s_expand(_26slist_12073);
    DeRefDS(_26slist_12073);
    _26slist_12073 = _0;
L1: 

    /** 	show_message = TRUE*/
    _show_message_63862 = _9TRUE_430;

    /** 	screen_err_out = atom(crash_msg)*/
    _67screen_err_out_63539 = IS_ATOM(_67crash_msg_63405);

    /** 	while TRUE do*/
L2: 
    if (_9TRUE_430 == 0)
    {
        goto L3; // [56] 973
    }
    else{
    }

    /** 		if length(tcb) > 1 then*/
    if (IS_SEQUENCE(_67tcb_63522)){
            _31930 = SEQ_PTR(_67tcb_63522)->length;
    }
    else {
        _31930 = 1;
    }
    if (_31930 <= 1)
    goto L4; // [66] 208

    /** 			if current_task = 1 then*/
    if (_67current_task_63496 != 1)
    goto L5; // [74] 88

    /** 				routine_name = "initial task"*/
    RefDS(_31933);
    DeRef(_routine_name_63859);
    _routine_name_63859 = _31933;
    goto L6; // [85] 127
L5: 

    /** 				routine_name = SymTab[e_routine[1+tcb[current_task][TASK_RID]]][S_NAME]*/
    _2 = (int)SEQ_PTR(_67tcb_63522);
    _31934 = (int)*(((s1_ptr)_2)->base + _67current_task_63496);
    _2 = (int)SEQ_PTR(_31934);
    _31935 = (int)*(((s1_ptr)_2)->base + 1);
    _31934 = NOVALUE;
    if (IS_ATOM_INT(_31935)) {
        _31936 = _31935 + 1;
    }
    else
    _31936 = binary_op(PLUS, 1, _31935);
    _31935 = NOVALUE;
    _2 = (int)SEQ_PTR(_67e_routine_63527);
    if (!IS_ATOM_INT(_31936)){
        _31937 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_31936)->dbl));
    }
    else{
        _31937 = (int)*(((s1_ptr)_2)->base + _31936);
    }
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _31938 = (int)*(((s1_ptr)_2)->base + _31937);
    DeRef(_routine_name_63859);
    _2 = (int)SEQ_PTR(_31938);
    if (!IS_ATOM_INT(_26S_NAME_11654)){
        _routine_name_63859 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NAME_11654)->dbl));
    }
    else{
        _routine_name_63859 = (int)*(((s1_ptr)_2)->base + _26S_NAME_11654);
    }
    Ref(_routine_name_63859);
    _31938 = NOVALUE;
L6: 

    /** 			title = sprintf(" TASK ID %d: %s ",*/
    _2 = (int)SEQ_PTR(_67tcb_63522);
    _31941 = (int)*(((s1_ptr)_2)->base + _67current_task_63496);
    _2 = (int)SEQ_PTR(_31941);
    _31942 = (int)*(((s1_ptr)_2)->base + 2);
    _31941 = NOVALUE;
    RefDS(_routine_name_63859);
    Ref(_31942);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _31942;
    ((int *)_2)[2] = _routine_name_63859;
    _31943 = MAKE_SEQ(_1);
    _31942 = NOVALUE;
    DeRefi(_title_63860);
    _title_63860 = EPrintf(-9999999, _31940, _31943);
    DeRefDS(_31943);
    _31943 = NOVALUE;

    /** 			dash_count = 60*/
    _dash_count_63858 = 60;

    /** 			if length(title) < dash_count then*/
    if (IS_SEQUENCE(_title_63860)){
            _31945 = SEQ_PTR(_title_63860)->length;
    }
    else {
        _31945 = 1;
    }
    if (_31945 >= 60)
    goto L7; // [161] 175

    /** 				dash_count = 52 - length(title)*/
    if (IS_SEQUENCE(_title_63860)){
            _31947 = SEQ_PTR(_title_63860)->length;
    }
    else {
        _31947 = 1;
    }
    _dash_count_63858 = 52 - _31947;
    _31947 = NOVALUE;
L7: 

    /** 			if dash_count < 1 then*/
    if (_dash_count_63858 >= 1)
    goto L8; // [177] 187

    /** 				dash_count = 1*/
    _dash_count_63858 = 1;
L8: 

    /** 			both_puts(repeat('-', 22) & title & repeat('-', dash_count) & "\n")*/
    _31950 = Repeat(45, 22);
    _31951 = Repeat(45, _dash_count_63858);
    {
        int concat_list[4];

        concat_list[0] = _22189;
        concat_list[1] = _31951;
        concat_list[2] = _title_63860;
        concat_list[3] = _31950;
        Concat_N((object_ptr)&_31952, concat_list, 4);
    }
    DeRefDS(_31951);
    _31951 = NOVALUE;
    DeRefDS(_31950);
    _31950 = NOVALUE;
    _67both_puts(_31952);
    _31952 = NOVALUE;
L4: 

    /** 		levels = 1*/
    _levels_63855 = 1;

    /** 		while length(call_stack) > 0 do*/
L9: 
    if (IS_SEQUENCE(_67call_stack_63497)){
            _31953 = SEQ_PTR(_67call_stack_63497)->length;
    }
    else {
        _31953 = 1;
    }
    if (_31953 <= 0)
    goto LA; // [223] 807

    /** 			sub = call_stack[$]*/
    if (IS_SEQUENCE(_67call_stack_63497)){
            _31955 = SEQ_PTR(_67call_stack_63497)->length;
    }
    else {
        _31955 = 1;
    }
    _2 = (int)SEQ_PTR(_67call_stack_63497);
    _sub_63853 = (int)*(((s1_ptr)_2)->base + _31955);
    if (!IS_ATOM_INT(_sub_63853)){
        _sub_63853 = (long)DBL_PTR(_sub_63853)->dbl;
    }

    /** 			if levels = 1 then*/
    if (_levels_63855 != 1)
    goto LB; // [242] 254

    /** 				puts(2, '\n')*/
    EPuts(2, 10); // DJP 
    goto LC; // [251] 283
LB: 

    /** 			elsif sub != call_back_routine and sub != delete_code_routine then*/
    _31958 = (_sub_63853 != _67call_back_routine_63413);
    if (_31958 == 0) {
        goto LD; // [262] 282
    }
    _31960 = (_sub_63853 != _67delete_code_routine_63414);
    if (_31960 == 0)
    {
        DeRef(_31960);
        _31960 = NOVALUE;
        goto LD; // [273] 282
    }
    else{
        DeRef(_31960);
        _31960 = NOVALUE;
    }

    /** 				both_puts("... called from ")*/
    RefDS(_31961);
    _67both_puts(_31961);
LD: 
LC: 

    /** 			if sub = call_back_routine then*/
    if (_sub_63853 != _67call_back_routine_63413)
    goto LE; // [287] 327

    /** 				if crash_count > 0 then*/
    if (_67crash_count_63416 <= 0)
    goto LF; // [295] 311

    /** 					both_puts("^^^ called to handle run-time crash\n")*/
    RefDS(_31964);
    _67both_puts(_31964);

    /** 					exit*/
    goto LA; // [306] 807
    goto L10; // [308] 752
LF: 

    /** 					both_puts("^^^ call-back from ")*/
    RefDS(_31965);
    _67both_puts(_31965);

    /** 					ifdef WINDOWS then*/

    /** 						both_puts("Windows\n")*/
    RefDS(_31966);
    _67both_puts(_31966);
    goto L10; // [324] 752
LE: 

    /** 			elsif sub = delete_code_routine then*/
    if (_sub_63853 != _67delete_code_routine_63414)
    goto L11; // [331] 343

    /** 				both_puts("^^^ delete routine\n")*/
    RefDS(_31969);
    _67both_puts(_31969);
    goto L10; // [340] 752
L11: 

    /** 				both_printf("%s:%d", find_line(sub, pc))*/
    _31971 = _67find_line(_sub_63853, _67pc_63479);
    RefDS(_31970);
    _67both_printf(_31970, _31971);
    _31971 = NOVALUE;

    /** 				if not equal(SymTab[sub][S_NAME], "<TopLevel>") then*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _31972 = (int)*(((s1_ptr)_2)->base + _sub_63853);
    _2 = (int)SEQ_PTR(_31972);
    if (!IS_ATOM_INT(_26S_NAME_11654)){
        _31973 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NAME_11654)->dbl));
    }
    else{
        _31973 = (int)*(((s1_ptr)_2)->base + _26S_NAME_11654);
    }
    _31972 = NOVALUE;
    if (_31973 == _24659)
    _31974 = 1;
    else if (IS_ATOM_INT(_31973) && IS_ATOM_INT(_24659))
    _31974 = 0;
    else
    _31974 = (compare(_31973, _24659) == 0);
    _31973 = NOVALUE;
    if (_31974 != 0)
    goto L12; // [374] 462
    _31974 = NOVALUE;

    /** 					switch SymTab[sub][S_TOKEN] do*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _31976 = (int)*(((s1_ptr)_2)->base + _sub_63853);
    _2 = (int)SEQ_PTR(_31976);
    if (!IS_ATOM_INT(_26S_TOKEN_11659)){
        _31977 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_TOKEN_11659)->dbl));
    }
    else{
        _31977 = (int)*(((s1_ptr)_2)->base + _26S_TOKEN_11659);
    }
    _31976 = NOVALUE;
    if (IS_SEQUENCE(_31977) ){
        goto L13; // [391] 431
    }
    if(!IS_ATOM_INT(_31977)){
        if( (DBL_PTR(_31977)->dbl != (double) ((int) DBL_PTR(_31977)->dbl) ) ){
            goto L13; // [391] 431
        }
        _0 = (int) DBL_PTR(_31977)->dbl;
    }
    else {
        _0 = _31977;
    };
    _31977 = NOVALUE;
    switch ( _0 ){ 

        /** 						case PROC then*/
        case 27:

        /** 							both_puts(" in procedure ")*/
        RefDS(_31980);
        _67both_puts(_31980);
        goto L14; // [405] 439

        /** 						case FUNC then*/
        case 501:

        /** 							both_puts(" in function ")*/
        RefDS(_31981);
        _67both_puts(_31981);
        goto L14; // [416] 439

        /** 						case TYPE then*/
        case 504:

        /** 							both_puts(" in type ")*/
        RefDS(_31982);
        _67both_puts(_31982);
        goto L14; // [427] 439

        /** 						case else*/
        default:
L13: 

        /** 							RTInternal("SymTab[sub][S_TOKEN] is not a routine")*/
        RefDS(_31983);
        _67RTInternal(_31983);
    ;}L14: 

    /** 					both_printf("%s()", {SymTab[sub][S_NAME]})*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _31985 = (int)*(((s1_ptr)_2)->base + _sub_63853);
    _2 = (int)SEQ_PTR(_31985);
    if (!IS_ATOM_INT(_26S_NAME_11654)){
        _31986 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NAME_11654)->dbl));
    }
    else{
        _31986 = (int)*(((s1_ptr)_2)->base + _26S_NAME_11654);
    }
    _31985 = NOVALUE;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_31986);
    *((int *)(_2+4)) = _31986;
    _31987 = MAKE_SEQ(_1);
    _31986 = NOVALUE;
    RefDS(_31984);
    _67both_printf(_31984, _31987);
    _31987 = NOVALUE;
L12: 

    /** 				both_puts("\n")*/
    RefDS(_22189);
    _67both_puts(_22189);

    /** 				if show_message then*/
    if (_show_message_63862 == 0)
    {
        goto L15; // [469] 510
    }
    else{
    }

    /** 					if sequence(crash_msg) then*/
    _31988 = IS_SEQUENCE(_67crash_msg_63405);
    if (_31988 == 0)
    {
        _31988 = NOVALUE;
        goto L16; // [479] 493
    }
    else{
        _31988 = NOVALUE;
    }

    /** 						clear_screen()*/
    ClearScreen();

    /** 						puts(2, crash_msg)*/
    EPuts(2, _67crash_msg_63405); // DJP 
L16: 

    /** 					both_puts(msg & " \n")*/
    Concat((object_ptr)&_31989, _msg_63851, _24158);
    _67both_puts(_31989);
    _31989 = NOVALUE;

    /** 					show_message = FALSE*/
    _show_message_63862 = _9FALSE_428;
L15: 

    /** 				if length(call_stack) < 2 then*/
    if (IS_SEQUENCE(_67call_stack_63497)){
            _31990 = SEQ_PTR(_67call_stack_63497)->length;
    }
    else {
        _31990 = 1;
    }
    if (_31990 >= 2)
    goto L17; // [517] 531

    /** 					both_puts('\n')*/
    _67both_puts(10);

    /** 					exit*/
    goto LA; // [528] 807
L17: 

    /** 				v = SymTab[sub][S_NEXT]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _31992 = (int)*(((s1_ptr)_2)->base + _sub_63853);
    _2 = (int)SEQ_PTR(_31992);
    _v_63854 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_v_63854)){
        _v_63854 = (long)DBL_PTR(_v_63854)->dbl;
    }
    _31992 = NOVALUE;

    /** 				while v != 0 and*/
L18: 
    _31994 = (_v_63854 != 0);
    if (_31994 == 0) {
        goto L19; // [556] 681
    }
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _31996 = (int)*(((s1_ptr)_2)->base + _v_63854);
    _2 = (int)SEQ_PTR(_31996);
    _31997 = (int)*(((s1_ptr)_2)->base + 4);
    _31996 = NOVALUE;
    if (IS_ATOM_INT(_31997)) {
        _31998 = (_31997 == 3);
    }
    else {
        _31998 = binary_op(EQUALS, _31997, 3);
    }
    _31997 = NOVALUE;
    if (IS_ATOM_INT(_31998)) {
        if (_31998 != 0) {
            DeRef(_31999);
            _31999 = 1;
            goto L1A; // [578] 604
        }
    }
    else {
        if (DBL_PTR(_31998)->dbl != 0.0) {
            DeRef(_31999);
            _31999 = 1;
            goto L1A; // [578] 604
        }
    }
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _32000 = (int)*(((s1_ptr)_2)->base + _v_63854);
    _2 = (int)SEQ_PTR(_32000);
    _32001 = (int)*(((s1_ptr)_2)->base + 4);
    _32000 = NOVALUE;
    if (IS_ATOM_INT(_32001)) {
        _32002 = (_32001 == 2);
    }
    else {
        _32002 = binary_op(EQUALS, _32001, 2);
    }
    _32001 = NOVALUE;
    DeRef(_31999);
    if (IS_ATOM_INT(_32002))
    _31999 = (_32002 != 0);
    else
    _31999 = DBL_PTR(_32002)->dbl != 0.0;
L1A: 
    if (_31999 != 0) {
        DeRef(_32003);
        _32003 = 1;
        goto L1B; // [604] 630
    }
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _32004 = (int)*(((s1_ptr)_2)->base + _v_63854);
    _2 = (int)SEQ_PTR(_32004);
    _32005 = (int)*(((s1_ptr)_2)->base + 4);
    _32004 = NOVALUE;
    if (IS_ATOM_INT(_32005)) {
        _32006 = (_32005 == 9);
    }
    else {
        _32006 = binary_op(EQUALS, _32005, 9);
    }
    _32005 = NOVALUE;
    if (IS_ATOM_INT(_32006))
    _32003 = (_32006 != 0);
    else
    _32003 = DBL_PTR(_32006)->dbl != 0.0;
L1B: 
    if (_32003 == 0)
    {
        _32003 = NOVALUE;
        goto L19; // [631] 681
    }
    else{
        _32003 = NOVALUE;
    }

    /** 					if SymTab[v][S_SCOPE] != SC_UNDEFINED then*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _32007 = (int)*(((s1_ptr)_2)->base + _v_63854);
    _2 = (int)SEQ_PTR(_32007);
    _32008 = (int)*(((s1_ptr)_2)->base + 4);
    _32007 = NOVALUE;
    if (binary_op_a(EQUALS, _32008, 9)){
        _32008 = NOVALUE;
        goto L1C; // [650] 660
    }
    _32008 = NOVALUE;

    /** 						show_var(v)*/
    _67show_var(_v_63854);
L1C: 

    /** 					v = SymTab[v][S_NEXT]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _32010 = (int)*(((s1_ptr)_2)->base + _v_63854);
    _2 = (int)SEQ_PTR(_32010);
    _v_63854 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_v_63854)){
        _v_63854 = (long)DBL_PTR(_v_63854)->dbl;
    }
    _32010 = NOVALUE;

    /** 				end while*/
    goto L18; // [678] 552
L19: 

    /** 				if length(SymTab[sub][S_SAVED_PRIVATES]) > 0 and*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _32012 = (int)*(((s1_ptr)_2)->base + _sub_63853);
    _2 = (int)SEQ_PTR(_32012);
    _32013 = (int)*(((s1_ptr)_2)->base + 26);
    _32012 = NOVALUE;
    if (IS_SEQUENCE(_32013)){
            _32014 = SEQ_PTR(_32013)->length;
    }
    else {
        _32014 = 1;
    }
    _32013 = NOVALUE;
    _32015 = (_32014 > 0);
    _32014 = NOVALUE;
    if (_32015 == 0) {
        goto L1D; // [702] 751
    }
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _32017 = (int)*(((s1_ptr)_2)->base + _sub_63853);
    _2 = (int)SEQ_PTR(_32017);
    _32018 = (int)*(((s1_ptr)_2)->base + 26);
    _32017 = NOVALUE;
    _2 = (int)SEQ_PTR(_32018);
    _32019 = (int)*(((s1_ptr)_2)->base + 1);
    _32018 = NOVALUE;
    if (IS_ATOM_INT(_32019)) {
        _32020 = (_32019 != 0);
    }
    else {
        _32020 = binary_op(NOTEQ, _32019, 0);
    }
    _32019 = NOVALUE;
    if (_32020 == 0) {
        DeRef(_32020);
        _32020 = NOVALUE;
        goto L1D; // [727] 751
    }
    else {
        if (!IS_ATOM_INT(_32020) && DBL_PTR(_32020)->dbl == 0.0){
            DeRef(_32020);
            _32020 = NOVALUE;
            goto L1D; // [727] 751
        }
        DeRef(_32020);
        _32020 = NOVALUE;
    }
    DeRef(_32020);
    _32020 = NOVALUE;

    /** 					SymTab[sub][S_RESIDENT_TASK] = 0*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sub_63853 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 25);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _32021 = NOVALUE;

    /** 					restore_privates(sub)*/
    _67restore_privates(_sub_63853);
L1D: 
L10: 

    /** 			puts(err_file, '\n')*/
    EPuts(_67err_file_63528, 10); // DJP 

    /** 			pc = call_stack[$-1] - 1*/
    if (IS_SEQUENCE(_67call_stack_63497)){
            _32023 = SEQ_PTR(_67call_stack_63497)->length;
    }
    else {
        _32023 = 1;
    }
    _32024 = _32023 - 1;
    _32023 = NOVALUE;
    _2 = (int)SEQ_PTR(_67call_stack_63497);
    _32025 = (int)*(((s1_ptr)_2)->base + _32024);
    if (IS_ATOM_INT(_32025)) {
        _67pc_63479 = _32025 - 1;
    }
    else {
        _67pc_63479 = binary_op(MINUS, _32025, 1);
    }
    _32025 = NOVALUE;
    if (!IS_ATOM_INT(_67pc_63479)) {
        _1 = (long)(DBL_PTR(_67pc_63479)->dbl);
        DeRefDS(_67pc_63479);
        _67pc_63479 = _1;
    }

    /** 			call_stack = call_stack[1..$-2]*/
    if (IS_SEQUENCE(_67call_stack_63497)){
            _32027 = SEQ_PTR(_67call_stack_63497)->length;
    }
    else {
        _32027 = 1;
    }
    _32028 = _32027 - 2;
    _32027 = NOVALUE;
    rhs_slice_target = (object_ptr)&_67call_stack_63497;
    RHS_Slice(_67call_stack_63497, 1, _32028);

    /** 			levels += 1*/
    _levels_63855 = _levels_63855 + 1;

    /** 		end while*/
    goto L9; // [804] 218
LA: 

    /** 		tcb[current_task][TASK_STATE] = ST_DEAD -- mark as "deleted"*/
    _2 = (int)SEQ_PTR(_67tcb_63522);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _67tcb_63522 = MAKE_SEQ(_2);
    }
    _3 = (int)(_67current_task_63496 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = 2;
    DeRef(_1);
    _32031 = NOVALUE;

    /** 		task = current_task*/
    _task_63857 = _67current_task_63496;

    /** 		for i = 1 to length(tcb) do*/
    if (IS_SEQUENCE(_67tcb_63522)){
            _32033 = SEQ_PTR(_67tcb_63522)->length;
    }
    else {
        _32033 = 1;
    }
    {
        int _i_64039;
        _i_64039 = 1;
L1E: 
        if (_i_64039 > _32033){
            goto L1F; // [836] 950
        }

        /** 			if tcb[i][TASK_STATE] != ST_DEAD and*/
        _2 = (int)SEQ_PTR(_67tcb_63522);
        _32034 = (int)*(((s1_ptr)_2)->base + _i_64039);
        _2 = (int)SEQ_PTR(_32034);
        _32035 = (int)*(((s1_ptr)_2)->base + 4);
        _32034 = NOVALUE;
        if (IS_ATOM_INT(_32035)) {
            _32036 = (_32035 != 2);
        }
        else {
            _32036 = binary_op(NOTEQ, _32035, 2);
        }
        _32035 = NOVALUE;
        if (IS_ATOM_INT(_32036)) {
            if (_32036 == 0) {
                goto L20; // [859] 943
            }
        }
        else {
            if (DBL_PTR(_32036)->dbl == 0.0) {
                goto L20; // [859] 943
            }
        }
        _2 = (int)SEQ_PTR(_67tcb_63522);
        _32038 = (int)*(((s1_ptr)_2)->base + _i_64039);
        _2 = (int)SEQ_PTR(_32038);
        _32039 = (int)*(((s1_ptr)_2)->base + 16);
        _32038 = NOVALUE;
        if (IS_SEQUENCE(_32039)){
                _32040 = SEQ_PTR(_32039)->length;
        }
        else {
            _32040 = 1;
        }
        _32039 = NOVALUE;
        _32041 = (_32040 > 0);
        _32040 = NOVALUE;
        if (_32041 == 0)
        {
            DeRef(_32041);
            _32041 = NOVALUE;
            goto L20; // [881] 943
        }
        else{
            DeRef(_32041);
            _32041 = NOVALUE;
        }

        /** 				current_task = i*/
        _67current_task_63496 = _i_64039;

        /** 				call_stack = tcb[i][TASK_STACK]*/
        _2 = (int)SEQ_PTR(_67tcb_63522);
        _32042 = (int)*(((s1_ptr)_2)->base + _i_64039);
        DeRef(_67call_stack_63497);
        _2 = (int)SEQ_PTR(_32042);
        _67call_stack_63497 = (int)*(((s1_ptr)_2)->base + 16);
        Ref(_67call_stack_63497);
        _32042 = NOVALUE;

        /** 				pc = tcb[i][TASK_PC]*/
        _2 = (int)SEQ_PTR(_67tcb_63522);
        _32044 = (int)*(((s1_ptr)_2)->base + _i_64039);
        _2 = (int)SEQ_PTR(_32044);
        _67pc_63479 = (int)*(((s1_ptr)_2)->base + 14);
        if (!IS_ATOM_INT(_67pc_63479)){
            _67pc_63479 = (long)DBL_PTR(_67pc_63479)->dbl;
        }
        _32044 = NOVALUE;

        /** 				Code = tcb[i][TASK_CODE]*/
        _2 = (int)SEQ_PTR(_67tcb_63522);
        _32046 = (int)*(((s1_ptr)_2)->base + _i_64039);
        DeRef(_26Code_12071);
        _2 = (int)SEQ_PTR(_32046);
        _26Code_12071 = (int)*(((s1_ptr)_2)->base + 15);
        Ref(_26Code_12071);
        _32046 = NOVALUE;

        /** 				screen_err_out = FALSE  -- just show offending task on screen*/
        _67screen_err_out_63539 = _9FALSE_428;

        /** 				exit*/
        goto L1F; // [940] 950
L20: 

        /** 		end for*/
        _i_64039 = _i_64039 + 1;
        goto L1E; // [945] 843
L1F: 
        ;
    }

    /** 		if task = current_task then*/
    if (_task_63857 != _67current_task_63496)
    goto L21; // [954] 963

    /** 			exit*/
    goto L3; // [960] 973
L21: 

    /** 		both_puts("\n")*/
    RefDS(_22189);
    _67both_puts(_22189);

    /** 	end while*/
    goto L2; // [970] 54
L3: 

    /** 	puts(2, "\n--> see " & err_file_name & '\n')*/
    {
        int concat_list[3];

        concat_list[0] = 10;
        concat_list[1] = _67err_file_name_63529;
        concat_list[2] = _32049;
        Concat_N((object_ptr)&_32050, concat_list, 3);
    }
    EPuts(2, _32050); // DJP 
    DeRefDS(_32050);
    _32050 = NOVALUE;

    /** 	puts(err_file, "\n\nGlobal & Local Variables\n")*/
    EPuts(_67err_file_63528, _32051); // DJP 

    /** 	prev_file_no = -1*/
    _prev_file_no_63856 = -1;

    /** 	v = SymTab[TopLevelSub][S_NEXT]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _32052 = (int)*(((s1_ptr)_2)->base + _26TopLevelSub_11989);
    _2 = (int)SEQ_PTR(_32052);
    _v_63854 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_v_63854)){
        _v_63854 = (long)DBL_PTR(_v_63854)->dbl;
    }
    _32052 = NOVALUE;

    /** 	while v do*/
L22: 
    if (_v_63854 == 0)
    {
        goto L23; // [1021] 1188
    }
    else{
    }

    /** 		if SymTab[v][S_TOKEN] = VARIABLE and*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _32054 = (int)*(((s1_ptr)_2)->base + _v_63854);
    _2 = (int)SEQ_PTR(_32054);
    if (!IS_ATOM_INT(_26S_TOKEN_11659)){
        _32055 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_TOKEN_11659)->dbl));
    }
    else{
        _32055 = (int)*(((s1_ptr)_2)->base + _26S_TOKEN_11659);
    }
    _32054 = NOVALUE;
    if (IS_ATOM_INT(_32055)) {
        _32056 = (_32055 == -100);
    }
    else {
        _32056 = binary_op(EQUALS, _32055, -100);
    }
    _32055 = NOVALUE;
    if (IS_ATOM_INT(_32056)) {
        if (_32056 == 0) {
            DeRef(_32057);
            _32057 = 0;
            goto L24; // [1044] 1070
        }
    }
    else {
        if (DBL_PTR(_32056)->dbl == 0.0) {
            DeRef(_32057);
            _32057 = 0;
            goto L24; // [1044] 1070
        }
    }
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _32058 = (int)*(((s1_ptr)_2)->base + _v_63854);
    _2 = (int)SEQ_PTR(_32058);
    _32059 = (int)*(((s1_ptr)_2)->base + 3);
    _32058 = NOVALUE;
    if (IS_ATOM_INT(_32059)) {
        _32060 = (_32059 == 1);
    }
    else {
        _32060 = binary_op(EQUALS, _32059, 1);
    }
    _32059 = NOVALUE;
    DeRef(_32057);
    if (IS_ATOM_INT(_32060))
    _32057 = (_32060 != 0);
    else
    _32057 = DBL_PTR(_32060)->dbl != 0.0;
L24: 
    if (_32057 == 0) {
        goto L25; // [1070] 1167
    }
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _32062 = (int)*(((s1_ptr)_2)->base + _v_63854);
    _2 = (int)SEQ_PTR(_32062);
    _32063 = (int)*(((s1_ptr)_2)->base + 4);
    _32062 = NOVALUE;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 5;
    *((int *)(_2+8)) = 6;
    *((int *)(_2+12)) = 4;
    _32064 = MAKE_SEQ(_1);
    _32065 = find_from(_32063, _32064, 1);
    _32063 = NOVALUE;
    DeRefDS(_32064);
    _32064 = NOVALUE;
    if (_32065 == 0)
    {
        _32065 = NOVALUE;
        goto L25; // [1104] 1167
    }
    else{
        _32065 = NOVALUE;
    }

    /** 			if SymTab[v][S_FILE_NO] != prev_file_no then*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _32066 = (int)*(((s1_ptr)_2)->base + _v_63854);
    _2 = (int)SEQ_PTR(_32066);
    if (!IS_ATOM_INT(_26S_FILE_NO_11650)){
        _32067 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_FILE_NO_11650)->dbl));
    }
    else{
        _32067 = (int)*(((s1_ptr)_2)->base + _26S_FILE_NO_11650);
    }
    _32066 = NOVALUE;
    if (binary_op_a(EQUALS, _32067, _prev_file_no_63856)){
        _32067 = NOVALUE;
        goto L26; // [1121] 1161
    }
    _32067 = NOVALUE;

    /** 				prev_file_no = SymTab[v][S_FILE_NO]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _32069 = (int)*(((s1_ptr)_2)->base + _v_63854);
    _2 = (int)SEQ_PTR(_32069);
    if (!IS_ATOM_INT(_26S_FILE_NO_11650)){
        _prev_file_no_63856 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_FILE_NO_11650)->dbl));
    }
    else{
        _prev_file_no_63856 = (int)*(((s1_ptr)_2)->base + _26S_FILE_NO_11650);
    }
    if (!IS_ATOM_INT(_prev_file_no_63856)){
        _prev_file_no_63856 = (long)DBL_PTR(_prev_file_no_63856)->dbl;
    }
    _32069 = NOVALUE;

    /** 				puts(err_file, "\n " & known_files[prev_file_no] & ":\n")*/
    _2 = (int)SEQ_PTR(_27known_files_10922);
    _32072 = (int)*(((s1_ptr)_2)->base + _prev_file_no_63856);
    {
        int concat_list[3];

        concat_list[0] = _32073;
        concat_list[1] = _32072;
        concat_list[2] = _32071;
        Concat_N((object_ptr)&_32074, concat_list, 3);
    }
    _32072 = NOVALUE;
    EPuts(_67err_file_63528, _32074); // DJP 
    DeRefDS(_32074);
    _32074 = NOVALUE;
L26: 

    /** 			show_var(v)*/
    _67show_var(_v_63854);
L25: 

    /** 		v = SymTab[v][S_NEXT]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _32075 = (int)*(((s1_ptr)_2)->base + _v_63854);
    _2 = (int)SEQ_PTR(_32075);
    _v_63854 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_v_63854)){
        _v_63854 = (long)DBL_PTR(_v_63854)->dbl;
    }
    _32075 = NOVALUE;

    /** 	end while*/
    goto L22; // [1185] 1021
L23: 

    /** 	puts(err_file, '\n')*/
    EPuts(_67err_file_63528, 10); // DJP 

    /** 	close(err_file)*/
    EClose(_67err_file_63528);

    /** end procedure*/
    DeRefDS(_msg_63851);
    DeRef(_routine_name_63859);
    DeRefi(_title_63860);
    _31937 = NOVALUE;
    DeRef(_31936);
    _31936 = NOVALUE;
    DeRef(_31958);
    _31958 = NOVALUE;
    DeRef(_31994);
    _31994 = NOVALUE;
    _32013 = NOVALUE;
    DeRef(_31998);
    _31998 = NOVALUE;
    DeRef(_32002);
    _32002 = NOVALUE;
    DeRef(_32006);
    _32006 = NOVALUE;
    DeRef(_32015);
    _32015 = NOVALUE;
    DeRef(_32024);
    _32024 = NOVALUE;
    DeRef(_32028);
    _32028 = NOVALUE;
    _32039 = NOVALUE;
    DeRef(_32036);
    _32036 = NOVALUE;
    DeRef(_32056);
    _32056 = NOVALUE;
    DeRef(_32060);
    _32060 = NOVALUE;
    return;
    ;
}


void _67call_crash_routines()
{
    int _quit_64116 = NOVALUE;
    int _32086 = NOVALUE;
    int _32084 = NOVALUE;
    int _32083 = NOVALUE;
    int _32082 = NOVALUE;
    int _32081 = NOVALUE;
    int _32080 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if crash_count > 0 then*/
    if (_67crash_count_63416 <= 0)
    goto L1; // [5] 15

    /** 		return*/
    DeRef(_quit_64116);
    return;
L1: 

    /** 	crash_count += 1*/
    _67crash_count_63416 = _67crash_count_63416 + 1;

    /** 	err_file_name = "ex_crash.err"*/
    RefDS(_32079);
    DeRef(_67err_file_name_63529);
    _67err_file_name_63529 = _32079;

    /** 	for i = length(crash_list) to 1 by -1 do*/
    if (IS_SEQUENCE(_67crash_list_63415)){
            _32080 = SEQ_PTR(_67crash_list_63415)->length;
    }
    else {
        _32080 = 1;
    }
    {
        int _i_64122;
        _i_64122 = _32080;
L2: 
        if (_i_64122 < 1){
            goto L3; // [37] 94
        }

        /** 		quit = call_func(forward_general_callback,*/
        _2 = (int)SEQ_PTR(_67crash_list_63415);
        _32081 = (int)*(((s1_ptr)_2)->base + _i_64122);
        _1 = NewS1(3);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = 0;
        Ref(_32081);
        *((int *)(_2+8)) = _32081;
        *((int *)(_2+12)) = 1;
        _32082 = MAKE_SEQ(_1);
        _32081 = NOVALUE;
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = 0;
        _32083 = MAKE_SEQ(_1);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _32082;
        ((int *)_2)[2] = _32083;
        _32084 = MAKE_SEQ(_1);
        _32083 = NOVALUE;
        _32082 = NOVALUE;
        _1 = (int)SEQ_PTR(_32084);
        _2 = (int)((s1_ptr)_1)->base;
        _0 = (int)_00[_67forward_general_callback_64112].addr;
        Ref(*(int *)(_2+4));
        Ref(*(int *)(_2+8));
        _1 = (*(int (*)())_0)(
                            *(int *)(_2+4), 
                            *(int *)(_2+8)
                             );
        DeRef(_quit_64116);
        _quit_64116 = _1;
        DeRefDS(_32084);
        _32084 = NOVALUE;

        /** 		if not equal(quit, 0) then*/
        if (_quit_64116 == 0)
        _32086 = 1;
        else if (IS_ATOM_INT(_quit_64116) && IS_ATOM_INT(0))
        _32086 = 0;
        else
        _32086 = (compare(_quit_64116, 0) == 0);
        if (_32086 != 0)
        goto L4; // [78] 87
        _32086 = NOVALUE;

        /** 			return -- don't call the others*/
        DeRef(_quit_64116);
        return;
L4: 

        /** 	end for*/
        _i_64122 = _i_64122 + -1;
        goto L2; // [89] 44
L3: 
        ;
    }

    /** end procedure*/
    DeRef(_quit_64116);
    return;
    ;
}


void _67quit_after_error()
{
    int _34852 = NOVALUE;
    int _32092 = NOVALUE;
    int _32090 = NOVALUE;
    int _32089 = NOVALUE;
    int _32088 = NOVALUE;
    int _0, _1, _2;
    

    /** 	write_coverage_db()*/
    _34852 = _49write_coverage_db();
    DeRef(_34852);
    _34852 = NOVALUE;

    /** 	ifdef WINDOWS then*/

    /** 		if not batch_job and not test_only then*/
    _32088 = (_26batch_job_11995 == 0);
    if (_32088 == 0) {
        goto L1; // [17] 41
    }
    _32090 = (_26test_only_11994 == 0);
    if (_32090 == 0)
    {
        DeRef(_32090);
        _32090 = NOVALUE;
        goto L1; // [27] 41
    }
    else{
        DeRef(_32090);
        _32090 = NOVALUE;
    }

    /** 			puts(2, "\nPress Enter...\n")*/
    EPuts(2, _32091); // DJP 

    /** 			getc(0)*/
    if (0 != last_r_file_no) {
        last_r_file_ptr = which_file(0, EF_READ);
        last_r_file_no = 0;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _32092 = getKBchar();
        }
        else
        _32092 = getc(last_r_file_ptr);
    }
    else
    _32092 = getc(last_r_file_ptr);
L1: 

    /** 	abort(1)*/
    UserCleanup(1);

    /** end procedure*/
    DeRef(_32088);
    _32088 = NOVALUE;
    return;
    ;
}


void _67RTFatalType(int _x_64145)
{
    int _msg_64146 = NOVALUE;
    int _v_64147 = NOVALUE;
    int _vname_64148 = NOVALUE;
    int _32124 = NOVALUE;
    int _32120 = NOVALUE;
    int _32119 = NOVALUE;
    int _32118 = NOVALUE;
    int _32117 = NOVALUE;
    int _32115 = NOVALUE;
    int _32114 = NOVALUE;
    int _32113 = NOVALUE;
    int _32112 = NOVALUE;
    int _32110 = NOVALUE;
    int _32109 = NOVALUE;
    int _32107 = NOVALUE;
    int _32106 = NOVALUE;
    int _32105 = NOVALUE;
    int _32103 = NOVALUE;
    int _32101 = NOVALUE;
    int _32097 = NOVALUE;
    int _32095 = NOVALUE;
    int _32094 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_x_64145)) {
        _1 = (long)(DBL_PTR(_x_64145)->dbl);
        DeRefDS(_x_64145);
        _x_64145 = _1;
    }

    /** 	open_err_file()*/
    _67open_err_file();

    /** 	a = Code[x]*/
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _x_64145);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	if length(SymTab[a]) >= S_NAME then*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _32094 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    if (IS_SEQUENCE(_32094)){
            _32095 = SEQ_PTR(_32094)->length;
    }
    else {
        _32095 = 1;
    }
    _32094 = NOVALUE;
    if (binary_op_a(LESS, _32095, _26S_NAME_11654)){
        _32095 = NOVALUE;
        goto L1; // [32] 57
    }
    _32095 = NOVALUE;

    /** 		vname = SymTab[a][S_NAME]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _32097 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    DeRef(_vname_64148);
    _2 = (int)SEQ_PTR(_32097);
    if (!IS_ATOM_INT(_26S_NAME_11654)){
        _vname_64148 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NAME_11654)->dbl));
    }
    else{
        _vname_64148 = (int)*(((s1_ptr)_2)->base + _26S_NAME_11654);
    }
    Ref(_vname_64148);
    _32097 = NOVALUE;
    goto L2; // [54] 65
L1: 

    /** 		vname = "inlined variable"*/
    RefDS(_32099);
    DeRef(_vname_64148);
    _vname_64148 = _32099;
L2: 

    /** 	msg = sprintf("type_check failure, %s is ", {vname})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_vname_64148);
    *((int *)(_2+4)) = _vname_64148;
    _32101 = MAKE_SEQ(_1);
    DeRefi(_msg_64146);
    _msg_64146 = EPrintf(-9999999, _32100, _32101);
    DeRefDS(_32101);
    _32101 = NOVALUE;

    /** 	v = sprint(val[a])*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _32103 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    Ref(_32103);
    _0 = _v_64147;
    _v_64147 = _12sprint(_32103);
    DeRef(_0);
    _32103 = NOVALUE;

    /** 	if length(v) > 70 - length(vname) then*/
    if (IS_SEQUENCE(_v_64147)){
            _32105 = SEQ_PTR(_v_64147)->length;
    }
    else {
        _32105 = 1;
    }
    if (IS_SEQUENCE(_vname_64148)){
            _32106 = SEQ_PTR(_vname_64148)->length;
    }
    else {
        _32106 = 1;
    }
    _32107 = 70 - _32106;
    _32106 = NOVALUE;
    if (_32105 <= _32107)
    goto L3; // [105] 180

    /** 		v = v[1..70 - length(vname)]*/
    if (IS_SEQUENCE(_vname_64148)){
            _32109 = SEQ_PTR(_vname_64148)->length;
    }
    else {
        _32109 = 1;
    }
    _32110 = 70 - _32109;
    _32109 = NOVALUE;
    rhs_slice_target = (object_ptr)&_v_64147;
    RHS_Slice(_v_64147, 1, _32110);

    /** 		while length(v) and not find(v[$], ",}")  do*/
L4: 
    if (IS_SEQUENCE(_v_64147)){
            _32112 = SEQ_PTR(_v_64147)->length;
    }
    else {
        _32112 = 1;
    }
    if (_32112 == 0) {
        goto L5; // [131] 173
    }
    if (IS_SEQUENCE(_v_64147)){
            _32114 = SEQ_PTR(_v_64147)->length;
    }
    else {
        _32114 = 1;
    }
    _2 = (int)SEQ_PTR(_v_64147);
    _32115 = (int)*(((s1_ptr)_2)->base + _32114);
    _32117 = find_from(_32115, _32116, 1);
    _32115 = NOVALUE;
    _32118 = (_32117 == 0);
    _32117 = NOVALUE;
    if (_32118 == 0)
    {
        DeRef(_32118);
        _32118 = NOVALUE;
        goto L5; // [151] 173
    }
    else{
        DeRef(_32118);
        _32118 = NOVALUE;
    }

    /** 			v = v[1..$-1]*/
    if (IS_SEQUENCE(_v_64147)){
            _32119 = SEQ_PTR(_v_64147)->length;
    }
    else {
        _32119 = 1;
    }
    _32120 = _32119 - 1;
    _32119 = NOVALUE;
    rhs_slice_target = (object_ptr)&_v_64147;
    RHS_Slice(_v_64147, 1, _32120);

    /** 		end while*/
    goto L4; // [170] 128
L5: 

    /** 		v = v & " ..."*/
    Concat((object_ptr)&_v_64147, _v_64147, _32122);
L3: 

    /** 	trace_back(msg & v)*/
    Concat((object_ptr)&_32124, _msg_64146, _v_64147);
    _67trace_back(_32124);
    _32124 = NOVALUE;

    /** 	call_crash_routines()*/
    _67call_crash_routines();

    /** 	quit_after_error()*/
    _67quit_after_error();

    /** end procedure*/
    DeRefDSi(_msg_64146);
    DeRefDS(_v_64147);
    DeRef(_vname_64148);
    _32094 = NOVALUE;
    DeRef(_32107);
    _32107 = NOVALUE;
    DeRef(_32110);
    _32110 = NOVALUE;
    DeRef(_32120);
    _32120 = NOVALUE;
    return;
    ;
}


void _67RTFatal(int _msg_64193)
{
    int _0, _1, _2;
    

    /** 	open_err_file()*/
    _67open_err_file();

    /** 	trace_back(msg)*/
    RefDS(_msg_64193);
    _67trace_back(_msg_64193);

    /** 	call_crash_routines()*/
    _67call_crash_routines();

    /** 	quit_after_error()*/
    _67quit_after_error();

    /** end procedure*/
    DeRefDS(_msg_64193);
    return;
    ;
}


void _67RTInternal(int _msg_64196)
{
    int _0, _1, _2;
    

    /** 	machine_proc(67, msg)*/
    machine(67, _msg_64196);

    /** end procedure*/
    DeRefDSi(_msg_64196);
    return;
    ;
}


void _67wait(int _t_64199)
{
    int _t1_64200 = NOVALUE;
    int _t2_64201 = NOVALUE;
    int _32130 = NOVALUE;
    int _32128 = NOVALUE;
    int _0, _1, _2;
    

    /** 	t1 = floor(t)*/
    DeRef(_t1_64200);
    if (IS_ATOM_INT(_t_64199))
    _t1_64200 = e_floor(_t_64199);
    else
    _t1_64200 = unary_op(FLOOR, _t_64199);

    /** 	if t1 >= 1 then*/
    if (binary_op_a(LESS, _t1_64200, 1)){
        goto L1; // [8] 24
    }

    /** 		sleep(t1)*/
    Ref(_t1_64200);
    _3sleep(_t1_64200);

    /** 		t -= t1*/
    _0 = _t_64199;
    if (IS_ATOM_INT(_t_64199) && IS_ATOM_INT(_t1_64200)) {
        _t_64199 = _t_64199 - _t1_64200;
        if ((long)((unsigned long)_t_64199 +(unsigned long) HIGH_BITS) >= 0){
            _t_64199 = NewDouble((double)_t_64199);
        }
    }
    else {
        if (IS_ATOM_INT(_t_64199)) {
            _t_64199 = NewDouble((double)_t_64199 - DBL_PTR(_t1_64200)->dbl);
        }
        else {
            if (IS_ATOM_INT(_t1_64200)) {
                _t_64199 = NewDouble(DBL_PTR(_t_64199)->dbl - (double)_t1_64200);
            }
            else
            _t_64199 = NewDouble(DBL_PTR(_t_64199)->dbl - DBL_PTR(_t1_64200)->dbl);
        }
    }
    DeRef(_0);
L1: 

    /** 	t2 = time() + t*/
    DeRef(_32128);
    _32128 = NewDouble(current_time());
    DeRef(_t2_64201);
    if (IS_ATOM_INT(_t_64199)) {
        _t2_64201 = NewDouble(DBL_PTR(_32128)->dbl + (double)_t_64199);
    }
    else
    _t2_64201 = NewDouble(DBL_PTR(_32128)->dbl + DBL_PTR(_t_64199)->dbl);
    DeRefDS(_32128);
    _32128 = NOVALUE;

    /** 	while time() < t2 do*/
L2: 
    DeRef(_32130);
    _32130 = NewDouble(current_time());
    if (binary_op_a(GREATEREQ, _32130, _t2_64201)){
        DeRefDS(_32130);
        _32130 = NOVALUE;
        goto L3; // [39] 48
    }
    DeRef(_32130);
    _32130 = NOVALUE;

    /** 	end while*/
    goto L2; // [45] 37
L3: 

    /** end procedure*/
    DeRef(_t_64199);
    DeRef(_t1_64200);
    DeRef(_t2_64201);
    return;
    ;
}


void _67scheduler()
{
    int _earliest_time_64217 = NOVALUE;
    int _start_time_64218 = NOVALUE;
    int _now_64219 = NOVALUE;
    int _ts_found_64221 = NOVALUE;
    int _tp_64222 = NOVALUE;
    int _p_64223 = NOVALUE;
    int _earliest_task_64224 = NOVALUE;
    int _32207 = NOVALUE;
    int _32206 = NOVALUE;
    int _32203 = NOVALUE;
    int _32202 = NOVALUE;
    int _32201 = NOVALUE;
    int _32200 = NOVALUE;
    int _32199 = NOVALUE;
    int _32197 = NOVALUE;
    int _32196 = NOVALUE;
    int _32194 = NOVALUE;
    int _32192 = NOVALUE;
    int _32190 = NOVALUE;
    int _32188 = NOVALUE;
    int _32186 = NOVALUE;
    int _32184 = NOVALUE;
    int _32181 = NOVALUE;
    int _32179 = NOVALUE;
    int _32178 = NOVALUE;
    int _32176 = NOVALUE;
    int _32175 = NOVALUE;
    int _32172 = NOVALUE;
    int _32170 = NOVALUE;
    int _32164 = NOVALUE;
    int _32160 = NOVALUE;
    int _32159 = NOVALUE;
    int _32157 = NOVALUE;
    int _32155 = NOVALUE;
    int _32153 = NOVALUE;
    int _32152 = NOVALUE;
    int _32151 = NOVALUE;
    int _32150 = NOVALUE;
    int _32149 = NOVALUE;
    int _32148 = NOVALUE;
    int _32147 = NOVALUE;
    int _32145 = NOVALUE;
    int _32140 = NOVALUE;
    int _32136 = NOVALUE;
    int _32134 = NOVALUE;
    int _32133 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	sequence tp*/

    /** 	integer p, earliest_task*/

    /** 	earliest_task = rt_first*/
    _earliest_task_64224 = _67rt_first_63525;

    /** 	if clock_stopped or earliest_task = 0 then*/
    if (_67clock_stopped_64213 != 0) {
        goto L1; // [16] 29
    }
    _32133 = (_earliest_task_64224 == 0);
    if (_32133 == 0)
    {
        DeRef(_32133);
        _32133 = NOVALUE;
        goto L2; // [25] 42
    }
    else{
        DeRef(_32133);
        _32133 = NOVALUE;
    }
L1: 

    /** 		start_time = 1*/
    DeRef(_start_time_64218);
    _start_time_64218 = 1;

    /** 		now = -1*/
    DeRef(_now_64219);
    _now_64219 = -1;
    goto L3; // [39] 232
L2: 

    /** 		earliest_time = tcb[earliest_task][TASK_MAX_TIME]*/
    _2 = (int)SEQ_PTR(_67tcb_63522);
    _32134 = (int)*(((s1_ptr)_2)->base + _earliest_task_64224);
    DeRef(_earliest_time_64217);
    _2 = (int)SEQ_PTR(_32134);
    _earliest_time_64217 = (int)*(((s1_ptr)_2)->base + 9);
    Ref(_earliest_time_64217);
    _32134 = NOVALUE;

    /** 		p = tcb[rt_first][TASK_NEXT]*/
    _2 = (int)SEQ_PTR(_67tcb_63522);
    _32136 = (int)*(((s1_ptr)_2)->base + _67rt_first_63525);
    _2 = (int)SEQ_PTR(_32136);
    _p_64223 = (int)*(((s1_ptr)_2)->base + 12);
    if (!IS_ATOM_INT(_p_64223)){
        _p_64223 = (long)DBL_PTR(_p_64223)->dbl;
    }
    _32136 = NOVALUE;

    /** 		while p != 0 do*/
L4: 
    if (_p_64223 == 0)
    goto L5; // [75] 122

    /** 			tp = tcb[p]*/
    DeRef(_tp_64222);
    _2 = (int)SEQ_PTR(_67tcb_63522);
    _tp_64222 = (int)*(((s1_ptr)_2)->base + _p_64223);
    RefDS(_tp_64222);

    /** 			if tp[TASK_MAX_TIME] < earliest_time then*/
    _2 = (int)SEQ_PTR(_tp_64222);
    _32140 = (int)*(((s1_ptr)_2)->base + 9);
    if (binary_op_a(GREATEREQ, _32140, _earliest_time_64217)){
        _32140 = NOVALUE;
        goto L6; // [95] 111
    }
    _32140 = NOVALUE;

    /** 				earliest_task = p*/
    _earliest_task_64224 = _p_64223;

    /** 				earliest_time = tp[TASK_MAX_TIME]*/
    DeRef(_earliest_time_64217);
    _2 = (int)SEQ_PTR(_tp_64222);
    _earliest_time_64217 = (int)*(((s1_ptr)_2)->base + 9);
    Ref(_earliest_time_64217);
L6: 

    /** 			p = tp[TASK_NEXT]*/
    _2 = (int)SEQ_PTR(_tp_64222);
    _p_64223 = (int)*(((s1_ptr)_2)->base + 12);
    if (!IS_ATOM_INT(_p_64223))
    _p_64223 = (long)DBL_PTR(_p_64223)->dbl;

    /** 		end while*/
    goto L4; // [119] 75
L5: 

    /** 		now = time()*/
    DeRef(_now_64219);
    _now_64219 = NewDouble(current_time());

    /** 		start_time = tcb[earliest_task][TASK_MIN_TIME]*/
    _2 = (int)SEQ_PTR(_67tcb_63522);
    _32145 = (int)*(((s1_ptr)_2)->base + _earliest_task_64224);
    DeRef(_start_time_64218);
    _2 = (int)SEQ_PTR(_32145);
    _start_time_64218 = (int)*(((s1_ptr)_2)->base + 8);
    Ref(_start_time_64218);
    _32145 = NOVALUE;

    /** 		if earliest_task = current_task and*/
    _32147 = (_earliest_task_64224 == _67current_task_63496);
    if (_32147 == 0) {
        goto L7; // [146] 173
    }
    _2 = (int)SEQ_PTR(_67tcb_63522);
    _32149 = (int)*(((s1_ptr)_2)->base + _67current_task_63496);
    _2 = (int)SEQ_PTR(_32149);
    _32150 = (int)*(((s1_ptr)_2)->base + 10);
    _32149 = NOVALUE;
    if (IS_ATOM_INT(_32150)) {
        _32151 = (_32150 > 0);
    }
    else {
        _32151 = binary_op(GREATER, _32150, 0);
    }
    _32150 = NOVALUE;
    if (_32151 == 0) {
        DeRef(_32151);
        _32151 = NOVALUE;
        goto L7; // [167] 173
    }
    else {
        if (!IS_ATOM_INT(_32151) && DBL_PTR(_32151)->dbl == 0.0){
            DeRef(_32151);
            _32151 = NOVALUE;
            goto L7; // [167] 173
        }
        DeRef(_32151);
        _32151 = NOVALUE;
    }
    DeRef(_32151);
    _32151 = NOVALUE;
    goto L8; // [170] 231
L7: 

    /** 			if tcb[current_task][TASK_TYPE] = T_REAL_TIME then*/
    _2 = (int)SEQ_PTR(_67tcb_63522);
    _32152 = (int)*(((s1_ptr)_2)->base + _67current_task_63496);
    _2 = (int)SEQ_PTR(_32152);
    _32153 = (int)*(((s1_ptr)_2)->base + 3);
    _32152 = NOVALUE;
    if (binary_op_a(NOTEQ, _32153, 1)){
        _32153 = NOVALUE;
        goto L9; // [187] 207
    }
    _32153 = NOVALUE;

    /** 				tcb[current_task][TASK_RUNS_LEFT] = 0*/
    _2 = (int)SEQ_PTR(_67tcb_63522);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _67tcb_63522 = MAKE_SEQ(_2);
    }
    _3 = (int)(_67current_task_63496 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 10);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _32155 = NOVALUE;
L9: 

    /** 			tcb[earliest_task][TASK_RUNS_LEFT] = tcb[earliest_task][TASK_RUNS_MAX]*/
    _2 = (int)SEQ_PTR(_67tcb_63522);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _67tcb_63522 = MAKE_SEQ(_2);
    }
    _3 = (int)(_earliest_task_64224 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_67tcb_63522);
    _32159 = (int)*(((s1_ptr)_2)->base + _earliest_task_64224);
    _2 = (int)SEQ_PTR(_32159);
    _32160 = (int)*(((s1_ptr)_2)->base + 11);
    _32159 = NOVALUE;
    Ref(_32160);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 10);
    _1 = *(int *)_2;
    *(int *)_2 = _32160;
    if( _1 != _32160 ){
        DeRef(_1);
    }
    _32160 = NOVALUE;
    _32157 = NOVALUE;
L8: 
L3: 

    /** 	if start_time > now then*/
    if (binary_op_a(LESSEQ, _start_time_64218, _now_64219)){
        goto LA; // [238] 416
    }

    /** 		ts_found = FALSE*/
    _ts_found_64221 = _9FALSE_428;

    /** 		p = ts_first*/
    _p_64223 = _67ts_first_63526;

    /** 		while p != 0 do*/
LB: 
    if (_p_64223 == 0)
    goto LC; // [261] 313

    /** 			tp = tcb[p]*/
    DeRef(_tp_64222);
    _2 = (int)SEQ_PTR(_67tcb_63522);
    _tp_64222 = (int)*(((s1_ptr)_2)->base + _p_64223);
    RefDS(_tp_64222);

    /** 			if tp[TASK_RUNS_LEFT] > 0 then*/
    _2 = (int)SEQ_PTR(_tp_64222);
    _32164 = (int)*(((s1_ptr)_2)->base + 10);
    if (binary_op_a(LESSEQ, _32164, 0)){
        _32164 = NOVALUE;
        goto LD; // [281] 302
    }
    _32164 = NOVALUE;

    /** 				  earliest_task = p*/
    _earliest_task_64224 = _p_64223;

    /** 				  ts_found = TRUE*/
    _ts_found_64221 = _9TRUE_430;

    /** 				  exit*/
    goto LC; // [299] 313
LD: 

    /** 			p = tp[TASK_NEXT]*/
    _2 = (int)SEQ_PTR(_tp_64222);
    _p_64223 = (int)*(((s1_ptr)_2)->base + 12);
    if (!IS_ATOM_INT(_p_64223))
    _p_64223 = (long)DBL_PTR(_p_64223)->dbl;

    /** 		end while*/
    goto LB; // [310] 261
LC: 

    /** 		if not ts_found then*/
    if (_ts_found_64221 != 0)
    goto LE; // [315] 378

    /** 			p = ts_first*/
    _p_64223 = _67ts_first_63526;

    /** 			while p != 0 do*/
LF: 
    if (_p_64223 == 0)
    goto L10; // [330] 377

    /** 				tp = tcb[p]*/
    DeRef(_tp_64222);
    _2 = (int)SEQ_PTR(_67tcb_63522);
    _tp_64222 = (int)*(((s1_ptr)_2)->base + _p_64223);
    RefDS(_tp_64222);

    /** 				earliest_task = p*/
    _earliest_task_64224 = _p_64223;

    /** 				tcb[p][TASK_RUNS_LEFT] = tp[TASK_RUNS_MAX]*/
    _2 = (int)SEQ_PTR(_67tcb_63522);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _67tcb_63522 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_64223 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_tp_64222);
    _32172 = (int)*(((s1_ptr)_2)->base + 11);
    Ref(_32172);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 10);
    _1 = *(int *)_2;
    *(int *)_2 = _32172;
    if( _1 != _32172 ){
        DeRef(_1);
    }
    _32172 = NOVALUE;
    _32170 = NOVALUE;

    /** 				p = tp[TASK_NEXT]*/
    _2 = (int)SEQ_PTR(_tp_64222);
    _p_64223 = (int)*(((s1_ptr)_2)->base + 12);
    if (!IS_ATOM_INT(_p_64223))
    _p_64223 = (long)DBL_PTR(_p_64223)->dbl;

    /** 			end while*/
    goto LF; // [374] 330
L10: 
LE: 

    /** 		if earliest_task = 0 then*/
    if (_earliest_task_64224 != 0)
    goto L11; // [380] 389

    /** 			abort(0)*/
    UserCleanup(0);
L11: 

    /** 		if tcb[earliest_task][TASK_TYPE] = T_REAL_TIME then*/
    _2 = (int)SEQ_PTR(_67tcb_63522);
    _32175 = (int)*(((s1_ptr)_2)->base + _earliest_task_64224);
    _2 = (int)SEQ_PTR(_32175);
    _32176 = (int)*(((s1_ptr)_2)->base + 3);
    _32175 = NOVALUE;
    if (binary_op_a(NOTEQ, _32176, 1)){
        _32176 = NOVALUE;
        goto L12; // [401] 415
    }
    _32176 = NOVALUE;

    /** 			wait(start_time - now)*/
    if (IS_ATOM_INT(_start_time_64218) && IS_ATOM_INT(_now_64219)) {
        _32178 = _start_time_64218 - _now_64219;
        if ((long)((unsigned long)_32178 +(unsigned long) HIGH_BITS) >= 0){
            _32178 = NewDouble((double)_32178);
        }
    }
    else {
        if (IS_ATOM_INT(_start_time_64218)) {
            _32178 = NewDouble((double)_start_time_64218 - DBL_PTR(_now_64219)->dbl);
        }
        else {
            if (IS_ATOM_INT(_now_64219)) {
                _32178 = NewDouble(DBL_PTR(_start_time_64218)->dbl - (double)_now_64219);
            }
            else
            _32178 = NewDouble(DBL_PTR(_start_time_64218)->dbl - DBL_PTR(_now_64219)->dbl);
        }
    }
    _67wait(_32178);
    _32178 = NOVALUE;
L12: 
LA: 

    /** 	tcb[earliest_task][TASK_START] = time()*/
    _2 = (int)SEQ_PTR(_67tcb_63522);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _67tcb_63522 = MAKE_SEQ(_2);
    }
    _3 = (int)(_earliest_task_64224 + ((s1_ptr)_2)->base);
    DeRef(_32181);
    _32181 = NewDouble(current_time());
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = _32181;
    if( _1 != _32181 ){
        DeRef(_1);
    }
    _32181 = NOVALUE;
    _32179 = NOVALUE;

    /** 	if earliest_task = current_task then*/
    if (_earliest_task_64224 != _67current_task_63496)
    goto L13; // [435] 450

    /** 		pc += 1  -- continue with current task*/
    _67pc_63479 = _67pc_63479 + 1;
    goto L14; // [447] 663
L13: 

    /** 		tcb[current_task][TASK_CODE] = Code*/
    _2 = (int)SEQ_PTR(_67tcb_63522);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _67tcb_63522 = MAKE_SEQ(_2);
    }
    _3 = (int)(_67current_task_63496 + ((s1_ptr)_2)->base);
    RefDS(_26Code_12071);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 15);
    _1 = *(int *)_2;
    *(int *)_2 = _26Code_12071;
    DeRef(_1);
    _32184 = NOVALUE;

    /** 		tcb[current_task][TASK_PC] = pc*/
    _2 = (int)SEQ_PTR(_67tcb_63522);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _67tcb_63522 = MAKE_SEQ(_2);
    }
    _3 = (int)(_67current_task_63496 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 14);
    _1 = *(int *)_2;
    *(int *)_2 = _67pc_63479;
    DeRef(_1);
    _32186 = NOVALUE;

    /** 		tcb[current_task][TASK_STACK] = call_stack*/
    _2 = (int)SEQ_PTR(_67tcb_63522);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _67tcb_63522 = MAKE_SEQ(_2);
    }
    _3 = (int)(_67current_task_63496 + ((s1_ptr)_2)->base);
    RefDS(_67call_stack_63497);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 16);
    _1 = *(int *)_2;
    *(int *)_2 = _67call_stack_63497;
    DeRef(_1);
    _32188 = NOVALUE;

    /** 		Code = tcb[earliest_task][TASK_CODE]*/
    _2 = (int)SEQ_PTR(_67tcb_63522);
    _32190 = (int)*(((s1_ptr)_2)->base + _earliest_task_64224);
    DeRefDS(_26Code_12071);
    _2 = (int)SEQ_PTR(_32190);
    _26Code_12071 = (int)*(((s1_ptr)_2)->base + 15);
    Ref(_26Code_12071);
    _32190 = NOVALUE;

    /** 		pc = tcb[earliest_task][TASK_PC]*/
    _2 = (int)SEQ_PTR(_67tcb_63522);
    _32192 = (int)*(((s1_ptr)_2)->base + _earliest_task_64224);
    _2 = (int)SEQ_PTR(_32192);
    _67pc_63479 = (int)*(((s1_ptr)_2)->base + 14);
    if (!IS_ATOM_INT(_67pc_63479)){
        _67pc_63479 = (long)DBL_PTR(_67pc_63479)->dbl;
    }
    _32192 = NOVALUE;

    /** 		call_stack = tcb[earliest_task][TASK_STACK]*/
    _2 = (int)SEQ_PTR(_67tcb_63522);
    _32194 = (int)*(((s1_ptr)_2)->base + _earliest_task_64224);
    DeRefDS(_67call_stack_63497);
    _2 = (int)SEQ_PTR(_32194);
    _67call_stack_63497 = (int)*(((s1_ptr)_2)->base + 16);
    Ref(_67call_stack_63497);
    _32194 = NOVALUE;

    /** 		current_task = earliest_task*/
    _67current_task_63496 = _earliest_task_64224;

    /** 		if tcb[current_task][TASK_PC] = 0 then*/
    _2 = (int)SEQ_PTR(_67tcb_63522);
    _32196 = (int)*(((s1_ptr)_2)->base + _67current_task_63496);
    _2 = (int)SEQ_PTR(_32196);
    _32197 = (int)*(((s1_ptr)_2)->base + 14);
    _32196 = NOVALUE;
    if (binary_op_a(NOTEQ, _32197, 0)){
        _32197 = NOVALUE;
        goto L15; // [562] 639
    }
    _32197 = NOVALUE;

    /** 			pc = 1*/
    _67pc_63479 = 1;

    /** 			val[t_id] = tcb[current_task][TASK_RID]*/
    _2 = (int)SEQ_PTR(_67tcb_63522);
    _32199 = (int)*(((s1_ptr)_2)->base + _67current_task_63496);
    _2 = (int)SEQ_PTR(_32199);
    _32200 = (int)*(((s1_ptr)_2)->base + 1);
    _32199 = NOVALUE;
    Ref(_32200);
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67t_id_63410);
    _1 = *(int *)_2;
    *(int *)_2 = _32200;
    if( _1 != _32200 ){
        DeRef(_1);
    }
    _32200 = NOVALUE;

    /** 			val[t_arglist] = tcb[current_task][TASK_ARGS]*/
    _2 = (int)SEQ_PTR(_67tcb_63522);
    _32201 = (int)*(((s1_ptr)_2)->base + _67current_task_63496);
    _2 = (int)SEQ_PTR(_32201);
    _32202 = (int)*(((s1_ptr)_2)->base + 13);
    _32201 = NOVALUE;
    Ref(_32202);
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67t_arglist_63411);
    _1 = *(int *)_2;
    *(int *)_2 = _32202;
    if( _1 != _32202 ){
        DeRef(_1);
    }
    _32202 = NOVALUE;

    /** 			new_arg_assign()*/
    _32203 = _67new_arg_assign();

    /** 			Code = {CALL_PROC, t_id, t_arglist}*/
    _0 = _26Code_12071;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 136;
    *((int *)(_2+8)) = _67t_id_63410;
    *((int *)(_2+12)) = _67t_arglist_63411;
    _26Code_12071 = MAKE_SEQ(_1);
    DeRefDS(_0);
    goto L16; // [636] 662
L15: 

    /** 			pc += 1*/
    _67pc_63479 = _67pc_63479 + 1;

    /** 			restore_privates(call_stack[$])*/
    if (IS_SEQUENCE(_67call_stack_63497)){
            _32206 = SEQ_PTR(_67call_stack_63497)->length;
    }
    else {
        _32206 = 1;
    }
    _2 = (int)SEQ_PTR(_67call_stack_63497);
    _32207 = (int)*(((s1_ptr)_2)->base + _32206);
    Ref(_32207);
    _67restore_privates(_32207);
    _32207 = NOVALUE;
L16: 
L14: 

    /** end procedure*/
    DeRef(_earliest_time_64217);
    DeRef(_start_time_64218);
    DeRef(_now_64219);
    DeRef(_tp_64222);
    DeRef(_32147);
    _32147 = NOVALUE;
    DeRef(_32203);
    _32203 = NOVALUE;
    return;
    ;
}


int _67task_insert(int _first_64327, int _task_64328)
{
    int _32208 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	tcb[task][TASK_NEXT] = first*/
    _2 = (int)SEQ_PTR(_67tcb_63522);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _67tcb_63522 = MAKE_SEQ(_2);
    }
    _3 = (int)(_task_64328 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 12);
    _1 = *(int *)_2;
    *(int *)_2 = _first_64327;
    DeRef(_1);
    _32208 = NOVALUE;

    /** 	return task*/
    return _task_64328;
    ;
}


int _67task_delete(int _first_64333, int _task_64334)
{
    int _p_64335 = NOVALUE;
    int _prev_p_64336 = NOVALUE;
    int _32219 = NOVALUE;
    int _32218 = NOVALUE;
    int _32217 = NOVALUE;
    int _32215 = NOVALUE;
    int _32214 = NOVALUE;
    int _32213 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	prev_p = -1*/
    _prev_p_64336 = -1;

    /** 	p = first*/
    _p_64335 = _first_64333;

    /** 	while p != 0 do*/
L1: 
    if (_p_64335 == 0)
    goto L2; // [20] 110

    /** 		if p = task then*/
    if (_p_64335 != _task_64334)
    goto L3; // [26] 86

    /** 			if prev_p = -1 then*/
    if (_prev_p_64336 != -1)
    goto L4; // [32] 55

    /** 				return tcb[p][TASK_NEXT]*/
    _2 = (int)SEQ_PTR(_67tcb_63522);
    _32213 = (int)*(((s1_ptr)_2)->base + _p_64335);
    _2 = (int)SEQ_PTR(_32213);
    _32214 = (int)*(((s1_ptr)_2)->base + 12);
    _32213 = NOVALUE;
    Ref(_32214);
    return _32214;
    goto L5; // [52] 85
L4: 

    /** 				tcb[prev_p][TASK_NEXT] = tcb[p][TASK_NEXT]*/
    _2 = (int)SEQ_PTR(_67tcb_63522);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _67tcb_63522 = MAKE_SEQ(_2);
    }
    _3 = (int)(_prev_p_64336 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_67tcb_63522);
    _32217 = (int)*(((s1_ptr)_2)->base + _p_64335);
    _2 = (int)SEQ_PTR(_32217);
    _32218 = (int)*(((s1_ptr)_2)->base + 12);
    _32217 = NOVALUE;
    Ref(_32218);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 12);
    _1 = *(int *)_2;
    *(int *)_2 = _32218;
    if( _1 != _32218 ){
        DeRef(_1);
    }
    _32218 = NOVALUE;
    _32215 = NOVALUE;

    /** 				return first*/
    _32214 = NOVALUE;
    return _first_64333;
L5: 
L3: 

    /** 		prev_p = p*/
    _prev_p_64336 = _p_64335;

    /** 		p = tcb[p][TASK_NEXT]*/
    _2 = (int)SEQ_PTR(_67tcb_63522);
    _32219 = (int)*(((s1_ptr)_2)->base + _p_64335);
    _2 = (int)SEQ_PTR(_32219);
    _p_64335 = (int)*(((s1_ptr)_2)->base + 12);
    if (!IS_ATOM_INT(_p_64335)){
        _p_64335 = (long)DBL_PTR(_p_64335)->dbl;
    }
    _32219 = NOVALUE;

    /** 	end while*/
    goto L1; // [107] 20
L2: 

    /** 	return first*/
    _32214 = NOVALUE;
    return _first_64333;
    ;
}


void _67opTASK_YIELD()
{
    int _now_64354 = NOVALUE;
    int _32269 = NOVALUE;
    int _32268 = NOVALUE;
    int _32267 = NOVALUE;
    int _32265 = NOVALUE;
    int _32264 = NOVALUE;
    int _32263 = NOVALUE;
    int _32262 = NOVALUE;
    int _32260 = NOVALUE;
    int _32259 = NOVALUE;
    int _32258 = NOVALUE;
    int _32257 = NOVALUE;
    int _32255 = NOVALUE;
    int _32254 = NOVALUE;
    int _32253 = NOVALUE;
    int _32252 = NOVALUE;
    int _32250 = NOVALUE;
    int _32249 = NOVALUE;
    int _32248 = NOVALUE;
    int _32246 = NOVALUE;
    int _32243 = NOVALUE;
    int _32242 = NOVALUE;
    int _32241 = NOVALUE;
    int _32240 = NOVALUE;
    int _32239 = NOVALUE;
    int _32238 = NOVALUE;
    int _32237 = NOVALUE;
    int _32236 = NOVALUE;
    int _32235 = NOVALUE;
    int _32232 = NOVALUE;
    int _32231 = NOVALUE;
    int _32230 = NOVALUE;
    int _32229 = NOVALUE;
    int _32227 = NOVALUE;
    int _32225 = NOVALUE;
    int _32224 = NOVALUE;
    int _32222 = NOVALUE;
    int _32221 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	if tcb[current_task][TASK_STATE] = ST_ACTIVE then*/
    _2 = (int)SEQ_PTR(_67tcb_63522);
    _32221 = (int)*(((s1_ptr)_2)->base + _67current_task_63496);
    _2 = (int)SEQ_PTR(_32221);
    _32222 = (int)*(((s1_ptr)_2)->base + 4);
    _32221 = NOVALUE;
    if (binary_op_a(NOTEQ, _32222, 0)){
        _32222 = NOVALUE;
        goto L1; // [15] 312
    }
    _32222 = NOVALUE;

    /** 		if tcb[current_task][TASK_RUNS_LEFT] > 0 then*/
    _2 = (int)SEQ_PTR(_67tcb_63522);
    _32224 = (int)*(((s1_ptr)_2)->base + _67current_task_63496);
    _2 = (int)SEQ_PTR(_32224);
    _32225 = (int)*(((s1_ptr)_2)->base + 10);
    _32224 = NOVALUE;
    if (binary_op_a(LESSEQ, _32225, 0)){
        _32225 = NOVALUE;
        goto L2; // [33] 61
    }
    _32225 = NOVALUE;

    /** 			tcb[current_task][TASK_RUNS_LEFT] -= 1*/
    _2 = (int)SEQ_PTR(_67tcb_63522);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _67tcb_63522 = MAKE_SEQ(_2);
    }
    _3 = (int)(_67current_task_63496 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    _32229 = (int)*(((s1_ptr)_2)->base + 10);
    _32227 = NOVALUE;
    if (IS_ATOM_INT(_32229)) {
        _32230 = _32229 - 1;
        if ((long)((unsigned long)_32230 +(unsigned long) HIGH_BITS) >= 0){
            _32230 = NewDouble((double)_32230);
        }
    }
    else {
        _32230 = binary_op(MINUS, _32229, 1);
    }
    _32229 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 10);
    _1 = *(int *)_2;
    *(int *)_2 = _32230;
    if( _1 != _32230 ){
        DeRef(_1);
    }
    _32230 = NOVALUE;
    _32227 = NOVALUE;
L2: 

    /** 		if tcb[current_task][TASK_TYPE] = T_REAL_TIME then*/
    _2 = (int)SEQ_PTR(_67tcb_63522);
    _32231 = (int)*(((s1_ptr)_2)->base + _67current_task_63496);
    _2 = (int)SEQ_PTR(_32231);
    _32232 = (int)*(((s1_ptr)_2)->base + 3);
    _32231 = NOVALUE;
    if (binary_op_a(NOTEQ, _32232, 1)){
        _32232 = NOVALUE;
        goto L3; // [75] 311
    }
    _32232 = NOVALUE;

    /** 			now = time()*/
    DeRef(_now_64354);
    _now_64354 = NewDouble(current_time());

    /** 			if tcb[current_task][TASK_RUNS_MAX] > 1 and*/
    _2 = (int)SEQ_PTR(_67tcb_63522);
    _32235 = (int)*(((s1_ptr)_2)->base + _67current_task_63496);
    _2 = (int)SEQ_PTR(_32235);
    _32236 = (int)*(((s1_ptr)_2)->base + 11);
    _32235 = NOVALUE;
    if (IS_ATOM_INT(_32236)) {
        _32237 = (_32236 > 1);
    }
    else {
        _32237 = binary_op(GREATER, _32236, 1);
    }
    _32236 = NOVALUE;
    if (IS_ATOM_INT(_32237)) {
        if (_32237 == 0) {
            goto L4; // [101] 247
        }
    }
    else {
        if (DBL_PTR(_32237)->dbl == 0.0) {
            goto L4; // [101] 247
        }
    }
    _2 = (int)SEQ_PTR(_67tcb_63522);
    _32239 = (int)*(((s1_ptr)_2)->base + _67current_task_63496);
    _2 = (int)SEQ_PTR(_32239);
    _32240 = (int)*(((s1_ptr)_2)->base + 5);
    _32239 = NOVALUE;
    _32241 = binary_op(EQUALS, _32240, _now_64354);
    _32240 = NOVALUE;
    if (_32241 == 0) {
        DeRef(_32241);
        _32241 = NOVALUE;
        goto L4; // [122] 247
    }
    else {
        if (!IS_ATOM_INT(_32241) && DBL_PTR(_32241)->dbl == 0.0){
            DeRef(_32241);
            _32241 = NOVALUE;
            goto L4; // [122] 247
        }
        DeRef(_32241);
        _32241 = NOVALUE;
    }
    DeRef(_32241);
    _32241 = NOVALUE;

    /** 				if tcb[current_task][TASK_RUNS_LEFT] = 0 then*/
    _2 = (int)SEQ_PTR(_67tcb_63522);
    _32242 = (int)*(((s1_ptr)_2)->base + _67current_task_63496);
    _2 = (int)SEQ_PTR(_32242);
    _32243 = (int)*(((s1_ptr)_2)->base + 10);
    _32242 = NOVALUE;
    if (binary_op_a(NOTEQ, _32243, 0)){
        _32243 = NOVALUE;
        goto L5; // [139] 310
    }
    _32243 = NOVALUE;

    /** 					now += clock_period*/
    _0 = _now_64354;
    if (IS_ATOM_INT(_now_64354)) {
        _now_64354 = NewDouble((double)_now_64354 + DBL_PTR(_67clock_period_63499)->dbl);
    }
    else {
        _now_64354 = NewDouble(DBL_PTR(_now_64354)->dbl + DBL_PTR(_67clock_period_63499)->dbl);
    }
    DeRef(_0);

    /** 					tcb[current_task][TASK_RUNS_LEFT] = tcb[current_task][TASK_RUNS_MAX]*/
    _2 = (int)SEQ_PTR(_67tcb_63522);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _67tcb_63522 = MAKE_SEQ(_2);
    }
    _3 = (int)(_67current_task_63496 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_67tcb_63522);
    _32248 = (int)*(((s1_ptr)_2)->base + _67current_task_63496);
    _2 = (int)SEQ_PTR(_32248);
    _32249 = (int)*(((s1_ptr)_2)->base + 11);
    _32248 = NOVALUE;
    Ref(_32249);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 10);
    _1 = *(int *)_2;
    *(int *)_2 = _32249;
    if( _1 != _32249 ){
        DeRef(_1);
    }
    _32249 = NOVALUE;
    _32246 = NOVALUE;

    /** 					tcb[current_task][TASK_MIN_TIME] = now +*/
    _2 = (int)SEQ_PTR(_67tcb_63522);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _67tcb_63522 = MAKE_SEQ(_2);
    }
    _3 = (int)(_67current_task_63496 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_67tcb_63522);
    _32252 = (int)*(((s1_ptr)_2)->base + _67current_task_63496);
    _2 = (int)SEQ_PTR(_32252);
    _32253 = (int)*(((s1_ptr)_2)->base + 6);
    _32252 = NOVALUE;
    _32254 = binary_op(PLUS, _now_64354, _32253);
    _32253 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 8);
    _1 = *(int *)_2;
    *(int *)_2 = _32254;
    if( _1 != _32254 ){
        DeRef(_1);
    }
    _32254 = NOVALUE;
    _32250 = NOVALUE;

    /** 					tcb[current_task][TASK_MAX_TIME] = now +*/
    _2 = (int)SEQ_PTR(_67tcb_63522);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _67tcb_63522 = MAKE_SEQ(_2);
    }
    _3 = (int)(_67current_task_63496 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_67tcb_63522);
    _32257 = (int)*(((s1_ptr)_2)->base + _67current_task_63496);
    _2 = (int)SEQ_PTR(_32257);
    _32258 = (int)*(((s1_ptr)_2)->base + 7);
    _32257 = NOVALUE;
    _32259 = binary_op(PLUS, _now_64354, _32258);
    _32258 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 9);
    _1 = *(int *)_2;
    *(int *)_2 = _32259;
    if( _1 != _32259 ){
        DeRef(_1);
    }
    _32259 = NOVALUE;
    _32255 = NOVALUE;
    goto L5; // [240] 310
    goto L5; // [244] 310
L4: 

    /** 				tcb[current_task][TASK_MIN_TIME] = now +*/
    _2 = (int)SEQ_PTR(_67tcb_63522);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _67tcb_63522 = MAKE_SEQ(_2);
    }
    _3 = (int)(_67current_task_63496 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_67tcb_63522);
    _32262 = (int)*(((s1_ptr)_2)->base + _67current_task_63496);
    _2 = (int)SEQ_PTR(_32262);
    _32263 = (int)*(((s1_ptr)_2)->base + 6);
    _32262 = NOVALUE;
    if (IS_ATOM_INT(_now_64354) && IS_ATOM_INT(_32263)) {
        _32264 = _now_64354 + _32263;
        if ((long)((unsigned long)_32264 + (unsigned long)HIGH_BITS) >= 0) 
        _32264 = NewDouble((double)_32264);
    }
    else {
        _32264 = binary_op(PLUS, _now_64354, _32263);
    }
    _32263 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 8);
    _1 = *(int *)_2;
    *(int *)_2 = _32264;
    if( _1 != _32264 ){
        DeRef(_1);
    }
    _32264 = NOVALUE;
    _32260 = NOVALUE;

    /** 				tcb[current_task][TASK_MAX_TIME] = now +*/
    _2 = (int)SEQ_PTR(_67tcb_63522);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _67tcb_63522 = MAKE_SEQ(_2);
    }
    _3 = (int)(_67current_task_63496 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_67tcb_63522);
    _32267 = (int)*(((s1_ptr)_2)->base + _67current_task_63496);
    _2 = (int)SEQ_PTR(_32267);
    _32268 = (int)*(((s1_ptr)_2)->base + 7);
    _32267 = NOVALUE;
    if (IS_ATOM_INT(_now_64354) && IS_ATOM_INT(_32268)) {
        _32269 = _now_64354 + _32268;
        if ((long)((unsigned long)_32269 + (unsigned long)HIGH_BITS) >= 0) 
        _32269 = NewDouble((double)_32269);
    }
    else {
        _32269 = binary_op(PLUS, _now_64354, _32268);
    }
    _32268 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 9);
    _1 = *(int *)_2;
    *(int *)_2 = _32269;
    if( _1 != _32269 ){
        DeRef(_1);
    }
    _32269 = NOVALUE;
    _32265 = NOVALUE;
L5: 
L3: 
L1: 

    /** 	scheduler()*/
    _67scheduler();

    /** end procedure*/
    DeRef(_now_64354);
    DeRef(_32237);
    _32237 = NOVALUE;
    return;
    ;
}


void _67kill_task(int _task_64413)
{
    int _32275 = NOVALUE;
    int _32271 = NOVALUE;
    int _32270 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	if tcb[task][TASK_TYPE] = T_REAL_TIME then*/
    _2 = (int)SEQ_PTR(_67tcb_63522);
    _32270 = (int)*(((s1_ptr)_2)->base + _task_64413);
    _2 = (int)SEQ_PTR(_32270);
    _32271 = (int)*(((s1_ptr)_2)->base + 3);
    _32270 = NOVALUE;
    if (binary_op_a(NOTEQ, _32271, 1)){
        _32271 = NOVALUE;
        goto L1; // [15] 33
    }
    _32271 = NOVALUE;

    /** 		rt_first = task_delete(rt_first, task)*/
    _0 = _67task_delete(_67rt_first_63525, _task_64413);
    _67rt_first_63525 = _0;
    if (!IS_ATOM_INT(_67rt_first_63525)) {
        _1 = (long)(DBL_PTR(_67rt_first_63525)->dbl);
        DeRefDS(_67rt_first_63525);
        _67rt_first_63525 = _1;
    }
    goto L2; // [30] 45
L1: 

    /** 		ts_first = task_delete(ts_first, task)*/
    _0 = _67task_delete(_67ts_first_63526, _task_64413);
    _67ts_first_63526 = _0;
    if (!IS_ATOM_INT(_67ts_first_63526)) {
        _1 = (long)(DBL_PTR(_67ts_first_63526)->dbl);
        DeRefDS(_67ts_first_63526);
        _67ts_first_63526 = _1;
    }
L2: 

    /** 	tcb[task][TASK_STATE] = ST_DEAD*/
    _2 = (int)SEQ_PTR(_67tcb_63522);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _67tcb_63522 = MAKE_SEQ(_2);
    }
    _3 = (int)(_task_64413 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = 2;
    DeRef(_1);
    _32275 = NOVALUE;

    /** end procedure*/
    return;
    ;
}


int _67which_task(int _tid_64425)
{
    int _32279 = NOVALUE;
    int _32278 = NOVALUE;
    int _32277 = NOVALUE;
    int _0, _1, _2;
    

    /** 	for i = 1 to length(tcb) do*/
    if (IS_SEQUENCE(_67tcb_63522)){
            _32277 = SEQ_PTR(_67tcb_63522)->length;
    }
    else {
        _32277 = 1;
    }
    {
        int _i_64427;
        _i_64427 = 1;
L1: 
        if (_i_64427 > _32277){
            goto L2; // [8] 45
        }

        /** 		if tcb[i][TASK_TID] = tid then*/
        _2 = (int)SEQ_PTR(_67tcb_63522);
        _32278 = (int)*(((s1_ptr)_2)->base + _i_64427);
        _2 = (int)SEQ_PTR(_32278);
        _32279 = (int)*(((s1_ptr)_2)->base + 2);
        _32278 = NOVALUE;
        if (binary_op_a(NOTEQ, _32279, _tid_64425)){
            _32279 = NOVALUE;
            goto L3; // [27] 38
        }
        _32279 = NOVALUE;

        /** 			return i*/
        DeRef(_tid_64425);
        return _i_64427;
L3: 

        /** 	end for*/
        _i_64427 = _i_64427 + 1;
        goto L1; // [40] 15
L2: 
        ;
    }

    /** 	RTFatal("invalid task id")*/
    RefDS(_32281);
    _67RTFatal(_32281);
    ;
}


void _67opTASK_STATUS()
{
    int _r_64436 = NOVALUE;
    int _tid_64437 = NOVALUE;
    int _32295 = NOVALUE;
    int _32294 = NOVALUE;
    int _32292 = NOVALUE;
    int _32291 = NOVALUE;
    int _32289 = NOVALUE;
    int _32288 = NOVALUE;
    int _32287 = NOVALUE;
    int _32284 = NOVALUE;
    int _32282 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _32282 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _32282);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	target = Code[pc+2]*/
    _32284 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67target_63484 = (int)*(((s1_ptr)_2)->base + _32284);
    if (!IS_ATOM_INT(_67target_63484)){
        _67target_63484 = (long)DBL_PTR(_67target_63484)->dbl;
    }

    /** 	tid = val[a]*/
    DeRef(_tid_64437);
    _2 = (int)SEQ_PTR(_67val_63489);
    _tid_64437 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    Ref(_tid_64437);

    /** 	r = -1*/
    _r_64436 = -1;

    /** 	for t = 1 to length(tcb) do*/
    if (IS_SEQUENCE(_67tcb_63522)){
            _32287 = SEQ_PTR(_67tcb_63522)->length;
    }
    else {
        _32287 = 1;
    }
    {
        int _t_64446;
        _t_64446 = 1;
L1: 
        if (_t_64446 > _32287){
            goto L2; // [55] 137
        }

        /** 		if tcb[t][TASK_TID] = tid then*/
        _2 = (int)SEQ_PTR(_67tcb_63522);
        _32288 = (int)*(((s1_ptr)_2)->base + _t_64446);
        _2 = (int)SEQ_PTR(_32288);
        _32289 = (int)*(((s1_ptr)_2)->base + 2);
        _32288 = NOVALUE;
        if (binary_op_a(NOTEQ, _32289, _tid_64437)){
            _32289 = NOVALUE;
            goto L3; // [74] 130
        }
        _32289 = NOVALUE;

        /** 			if tcb[t][TASK_STATE] = ST_ACTIVE then*/
        _2 = (int)SEQ_PTR(_67tcb_63522);
        _32291 = (int)*(((s1_ptr)_2)->base + _t_64446);
        _2 = (int)SEQ_PTR(_32291);
        _32292 = (int)*(((s1_ptr)_2)->base + 4);
        _32291 = NOVALUE;
        if (binary_op_a(NOTEQ, _32292, 0)){
            _32292 = NOVALUE;
            goto L4; // [90] 102
        }
        _32292 = NOVALUE;

        /** 				r = 1*/
        _r_64436 = 1;
        goto L2; // [99] 137
L4: 

        /** 			elsif tcb[t][TASK_STATE] = ST_SUSPENDED then*/
        _2 = (int)SEQ_PTR(_67tcb_63522);
        _32294 = (int)*(((s1_ptr)_2)->base + _t_64446);
        _2 = (int)SEQ_PTR(_32294);
        _32295 = (int)*(((s1_ptr)_2)->base + 4);
        _32294 = NOVALUE;
        if (binary_op_a(NOTEQ, _32295, 1)){
            _32295 = NOVALUE;
            goto L2; // [114] 137
        }
        _32295 = NOVALUE;

        /** 				r = 0*/
        _r_64436 = 0;

        /** 			exit*/
        goto L2; // [127] 137
L3: 

        /** 	end for*/
        _t_64446 = _t_64446 + 1;
        goto L1; // [132] 62
L2: 
        ;
    }

    /** 	val[target] = r*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63484);
    _1 = *(int *)_2;
    *(int *)_2 = _r_64436;
    DeRef(_1);

    /** 	pc += 3*/
    _67pc_63479 = _67pc_63479 + 3;

    /** end procedure*/
    DeRef(_tid_64437);
    DeRef(_32282);
    _32282 = NOVALUE;
    DeRef(_32284);
    _32284 = NOVALUE;
    return;
    ;
}


void _67opTASK_LIST()
{
    int _list_64463 = NOVALUE;
    int _32305 = NOVALUE;
    int _32304 = NOVALUE;
    int _32302 = NOVALUE;
    int _32301 = NOVALUE;
    int _32300 = NOVALUE;
    int _32298 = NOVALUE;
    int _0, _1, _2;
    

    /** 	target = Code[pc+1]*/
    _32298 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67target_63484 = (int)*(((s1_ptr)_2)->base + _32298);
    if (!IS_ATOM_INT(_67target_63484)){
        _67target_63484 = (long)DBL_PTR(_67target_63484)->dbl;
    }

    /** 	list = {}*/
    RefDS(_22037);
    DeRef(_list_64463);
    _list_64463 = _22037;

    /** 	for i = 1 to length(tcb) do*/
    if (IS_SEQUENCE(_67tcb_63522)){
            _32300 = SEQ_PTR(_67tcb_63522)->length;
    }
    else {
        _32300 = 1;
    }
    {
        int _i_64468;
        _i_64468 = 1;
L1: 
        if (_i_64468 > _32300){
            goto L2; // [31] 78
        }

        /** 		if tcb[i][TASK_STATE] != ST_DEAD then*/
        _2 = (int)SEQ_PTR(_67tcb_63522);
        _32301 = (int)*(((s1_ptr)_2)->base + _i_64468);
        _2 = (int)SEQ_PTR(_32301);
        _32302 = (int)*(((s1_ptr)_2)->base + 4);
        _32301 = NOVALUE;
        if (binary_op_a(EQUALS, _32302, 2)){
            _32302 = NOVALUE;
            goto L3; // [50] 71
        }
        _32302 = NOVALUE;

        /** 			list = append(list, tcb[i][TASK_TID])*/
        _2 = (int)SEQ_PTR(_67tcb_63522);
        _32304 = (int)*(((s1_ptr)_2)->base + _i_64468);
        _2 = (int)SEQ_PTR(_32304);
        _32305 = (int)*(((s1_ptr)_2)->base + 2);
        _32304 = NOVALUE;
        Ref(_32305);
        Append(&_list_64463, _list_64463, _32305);
        _32305 = NOVALUE;
L3: 

        /** 	end for*/
        _i_64468 = _i_64468 + 1;
        goto L1; // [73] 38
L2: 
        ;
    }

    /** 	val[target] = list*/
    RefDS(_list_64463);
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63484);
    _1 = *(int *)_2;
    *(int *)_2 = _list_64463;
    DeRef(_1);

    /** 	pc += 2*/
    _67pc_63479 = _67pc_63479 + 2;

    /** end procedure*/
    DeRefDS(_list_64463);
    DeRef(_32298);
    _32298 = NOVALUE;
    return;
    ;
}


void _67opTASK_SELF()
{
    int _32311 = NOVALUE;
    int _32310 = NOVALUE;
    int _32308 = NOVALUE;
    int _0, _1, _2;
    

    /** 	target = Code[pc+1]*/
    _32308 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67target_63484 = (int)*(((s1_ptr)_2)->base + _32308);
    if (!IS_ATOM_INT(_67target_63484)){
        _67target_63484 = (long)DBL_PTR(_67target_63484)->dbl;
    }

    /** 	val[target] = tcb[current_task][TASK_TID]*/
    _2 = (int)SEQ_PTR(_67tcb_63522);
    _32310 = (int)*(((s1_ptr)_2)->base + _67current_task_63496);
    _2 = (int)SEQ_PTR(_32310);
    _32311 = (int)*(((s1_ptr)_2)->base + 2);
    _32310 = NOVALUE;
    Ref(_32311);
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63484);
    _1 = *(int *)_2;
    *(int *)_2 = _32311;
    if( _1 != _32311 ){
        DeRef(_1);
    }
    _32311 = NOVALUE;

    /** 	pc += 2*/
    _67pc_63479 = _67pc_63479 + 2;

    /** end procedure*/
    _32308 = NOVALUE;
    return;
    ;
}


void _67opTASK_CLOCK_STOP()
{
    int _0, _1, _2;
    

    /** 	if not clock_stopped then*/
    if (_67clock_stopped_64213 != 0)
    goto L1; // [5] 20

    /** 		save_clock = time()*/
    DeRef(_67save_clock_64486);
    _67save_clock_64486 = NewDouble(current_time());

    /** 		clock_stopped = TRUE*/
    _67clock_stopped_64213 = _9TRUE_430;
L1: 

    /** 	pc += 1*/
    _67pc_63479 = _67pc_63479 + 1;

    /** end procedure*/
    return;
    ;
}


void _67opTASK_CLOCK_START()
{
    int _shift_64496 = NOVALUE;
    int _32330 = NOVALUE;
    int _32329 = NOVALUE;
    int _32327 = NOVALUE;
    int _32326 = NOVALUE;
    int _32325 = NOVALUE;
    int _32323 = NOVALUE;
    int _32322 = NOVALUE;
    int _32320 = NOVALUE;
    int _32319 = NOVALUE;
    int _32318 = NOVALUE;
    int _32317 = NOVALUE;
    int _32316 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	if clock_stopped then*/
    if (_67clock_stopped_64213 == 0)
    {
        goto L1; // [5] 114
    }
    else{
    }

    /** 		if save_clock >= 0 and save_clock < time() then*/
    if (IS_ATOM_INT(_67save_clock_64486)) {
        _32316 = (_67save_clock_64486 >= 0);
    }
    else {
        _32316 = (DBL_PTR(_67save_clock_64486)->dbl >= (double)0);
    }
    if (_32316 == 0) {
        goto L2; // [16] 106
    }
    _32318 = NewDouble(current_time());
    if (IS_ATOM_INT(_67save_clock_64486)) {
        _32319 = ((double)_67save_clock_64486 < DBL_PTR(_32318)->dbl);
    }
    else {
        _32319 = (DBL_PTR(_67save_clock_64486)->dbl < DBL_PTR(_32318)->dbl);
    }
    DeRefDS(_32318);
    _32318 = NOVALUE;
    if (_32319 == 0)
    {
        DeRef(_32319);
        _32319 = NOVALUE;
        goto L2; // [29] 106
    }
    else{
        DeRef(_32319);
        _32319 = NOVALUE;
    }

    /** 			shift = time() - save_clock*/
    DeRef(_32320);
    _32320 = NewDouble(current_time());
    DeRef(_shift_64496);
    if (IS_ATOM_INT(_67save_clock_64486)) {
        _shift_64496 = NewDouble(DBL_PTR(_32320)->dbl - (double)_67save_clock_64486);
    }
    else
    _shift_64496 = NewDouble(DBL_PTR(_32320)->dbl - DBL_PTR(_67save_clock_64486)->dbl);
    DeRefDS(_32320);
    _32320 = NOVALUE;

    /** 			for i = 1 to length(tcb) do*/
    if (IS_SEQUENCE(_67tcb_63522)){
            _32322 = SEQ_PTR(_67tcb_63522)->length;
    }
    else {
        _32322 = 1;
    }
    {
        int _i_64506;
        _i_64506 = 1;
L3: 
        if (_i_64506 > _32322){
            goto L4; // [49] 105
        }

        /** 				tcb[i][TASK_MIN_TIME] += shift*/
        _2 = (int)SEQ_PTR(_67tcb_63522);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _67tcb_63522 = MAKE_SEQ(_2);
        }
        _3 = (int)(_i_64506 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        _32325 = (int)*(((s1_ptr)_2)->base + 8);
        _32323 = NOVALUE;
        if (IS_ATOM_INT(_32325) && IS_ATOM_INT(_shift_64496)) {
            _32326 = _32325 + _shift_64496;
            if ((long)((unsigned long)_32326 + (unsigned long)HIGH_BITS) >= 0) 
            _32326 = NewDouble((double)_32326);
        }
        else {
            _32326 = binary_op(PLUS, _32325, _shift_64496);
        }
        _32325 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 8);
        _1 = *(int *)_2;
        *(int *)_2 = _32326;
        if( _1 != _32326 ){
            DeRef(_1);
        }
        _32326 = NOVALUE;
        _32323 = NOVALUE;

        /** 				tcb[i][TASK_MAX_TIME] += shift*/
        _2 = (int)SEQ_PTR(_67tcb_63522);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _67tcb_63522 = MAKE_SEQ(_2);
        }
        _3 = (int)(_i_64506 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        _32329 = (int)*(((s1_ptr)_2)->base + 9);
        _32327 = NOVALUE;
        if (IS_ATOM_INT(_32329) && IS_ATOM_INT(_shift_64496)) {
            _32330 = _32329 + _shift_64496;
            if ((long)((unsigned long)_32330 + (unsigned long)HIGH_BITS) >= 0) 
            _32330 = NewDouble((double)_32330);
        }
        else {
            _32330 = binary_op(PLUS, _32329, _shift_64496);
        }
        _32329 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 9);
        _1 = *(int *)_2;
        *(int *)_2 = _32330;
        if( _1 != _32330 ){
            DeRef(_1);
        }
        _32330 = NOVALUE;
        _32327 = NOVALUE;

        /** 			end for*/
        _i_64506 = _i_64506 + 1;
        goto L3; // [100] 56
L4: 
        ;
    }
L2: 

    /** 		clock_stopped = FALSE*/
    _67clock_stopped_64213 = _9FALSE_428;
L1: 

    /** 	pc += 1*/
    _67pc_63479 = _67pc_63479 + 1;

    /** end procedure*/
    DeRef(_shift_64496);
    DeRef(_32316);
    _32316 = NOVALUE;
    return;
    ;
}


void _67opTASK_SUSPEND()
{
    int _task_64520 = NOVALUE;
    int _32341 = NOVALUE;
    int _32340 = NOVALUE;
    int _32338 = NOVALUE;
    int _32336 = NOVALUE;
    int _32334 = NOVALUE;
    int _32332 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	a = Code[pc+1]*/
    _32332 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _32332);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	task = which_task(val[a])*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _32334 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    Ref(_32334);
    _task_64520 = _67which_task(_32334);
    _32334 = NOVALUE;
    if (!IS_ATOM_INT(_task_64520)) {
        _1 = (long)(DBL_PTR(_task_64520)->dbl);
        DeRefDS(_task_64520);
        _task_64520 = _1;
    }

    /** 	tcb[task][TASK_STATE] = ST_SUSPENDED*/
    _2 = (int)SEQ_PTR(_67tcb_63522);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _67tcb_63522 = MAKE_SEQ(_2);
    }
    _3 = (int)(_task_64520 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = 1;
    DeRef(_1);
    _32336 = NOVALUE;

    /** 	tcb[task][TASK_MAX_TIME] = TASK_NEVER*/
    _2 = (int)SEQ_PTR(_67tcb_63522);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _67tcb_63522 = MAKE_SEQ(_2);
    }
    _3 = (int)(_task_64520 + ((s1_ptr)_2)->base);
    RefDS(_67TASK_NEVER_63490);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 9);
    _1 = *(int *)_2;
    *(int *)_2 = _67TASK_NEVER_63490;
    DeRef(_1);
    _32338 = NOVALUE;

    /** 	if tcb[task][TASK_TYPE] = T_REAL_TIME then*/
    _2 = (int)SEQ_PTR(_67tcb_63522);
    _32340 = (int)*(((s1_ptr)_2)->base + _task_64520);
    _2 = (int)SEQ_PTR(_32340);
    _32341 = (int)*(((s1_ptr)_2)->base + 3);
    _32340 = NOVALUE;
    if (binary_op_a(NOTEQ, _32341, 1)){
        _32341 = NOVALUE;
        goto L1; // [71] 89
    }
    _32341 = NOVALUE;

    /** 		rt_first = task_delete(rt_first, task)*/
    _0 = _67task_delete(_67rt_first_63525, _task_64520);
    _67rt_first_63525 = _0;
    if (!IS_ATOM_INT(_67rt_first_63525)) {
        _1 = (long)(DBL_PTR(_67rt_first_63525)->dbl);
        DeRefDS(_67rt_first_63525);
        _67rt_first_63525 = _1;
    }
    goto L2; // [86] 101
L1: 

    /** 		ts_first = task_delete(ts_first, task)*/
    _0 = _67task_delete(_67ts_first_63526, _task_64520);
    _67ts_first_63526 = _0;
    if (!IS_ATOM_INT(_67ts_first_63526)) {
        _1 = (long)(DBL_PTR(_67ts_first_63526)->dbl);
        DeRefDS(_67ts_first_63526);
        _67ts_first_63526 = _1;
    }
L2: 

    /** 	pc += 2*/
    _67pc_63479 = _67pc_63479 + 2;

    /** end procedure*/
    DeRef(_32332);
    _32332 = NOVALUE;
    return;
    ;
}


void _67opTASK_CREATE()
{
    int _sub_64541 = NOVALUE;
    int _new_entry_64542 = NOVALUE;
    int _recycle_64544 = NOVALUE;
    int _32381 = NOVALUE;
    int _32380 = NOVALUE;
    int _32379 = NOVALUE;
    int _32377 = NOVALUE;
    int _32376 = NOVALUE;
    int _32375 = NOVALUE;
    int _32373 = NOVALUE;
    int _32369 = NOVALUE;
    int _32368 = NOVALUE;
    int _32367 = NOVALUE;
    int _32365 = NOVALUE;
    int _32364 = NOVALUE;
    int _32362 = NOVALUE;
    int _32359 = NOVALUE;
    int _32358 = NOVALUE;
    int _32356 = NOVALUE;
    int _32355 = NOVALUE;
    int _32353 = NOVALUE;
    int _32352 = NOVALUE;
    int _32351 = NOVALUE;
    int _32349 = NOVALUE;
    int _32348 = NOVALUE;
    int _32346 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence new_entry*/

    /** 	a = Code[pc+1] -- routine id*/
    _32346 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _32346);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	if val[a] < 0 or val[a] >= length(e_routine) then*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _32348 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    if (IS_ATOM_INT(_32348)) {
        _32349 = (_32348 < 0);
    }
    else {
        _32349 = binary_op(LESS, _32348, 0);
    }
    _32348 = NOVALUE;
    if (IS_ATOM_INT(_32349)) {
        if (_32349 != 0) {
            goto L1; // [33] 59
        }
    }
    else {
        if (DBL_PTR(_32349)->dbl != 0.0) {
            goto L1; // [33] 59
        }
    }
    _2 = (int)SEQ_PTR(_67val_63489);
    _32351 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    if (IS_SEQUENCE(_67e_routine_63527)){
            _32352 = SEQ_PTR(_67e_routine_63527)->length;
    }
    else {
        _32352 = 1;
    }
    if (IS_ATOM_INT(_32351)) {
        _32353 = (_32351 >= _32352);
    }
    else {
        _32353 = binary_op(GREATEREQ, _32351, _32352);
    }
    _32351 = NOVALUE;
    _32352 = NOVALUE;
    if (_32353 == 0) {
        DeRef(_32353);
        _32353 = NOVALUE;
        goto L2; // [55] 65
    }
    else {
        if (!IS_ATOM_INT(_32353) && DBL_PTR(_32353)->dbl == 0.0){
            DeRef(_32353);
            _32353 = NOVALUE;
            goto L2; // [55] 65
        }
        DeRef(_32353);
        _32353 = NOVALUE;
    }
    DeRef(_32353);
    _32353 = NOVALUE;
L1: 

    /** 		RTFatal("invalid routine id")*/
    RefDS(_32354);
    _67RTFatal(_32354);
L2: 

    /** 	sub = e_routine[val[a]+1]*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _32355 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    if (IS_ATOM_INT(_32355)) {
        _32356 = _32355 + 1;
    }
    else
    _32356 = binary_op(PLUS, 1, _32355);
    _32355 = NOVALUE;
    _2 = (int)SEQ_PTR(_67e_routine_63527);
    if (!IS_ATOM_INT(_32356)){
        _sub_64541 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_32356)->dbl));
    }
    else{
        _sub_64541 = (int)*(((s1_ptr)_2)->base + _32356);
    }

    /** 	if SymTab[sub][S_TOKEN] != PROC then*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _32358 = (int)*(((s1_ptr)_2)->base + _sub_64541);
    _2 = (int)SEQ_PTR(_32358);
    if (!IS_ATOM_INT(_26S_TOKEN_11659)){
        _32359 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_TOKEN_11659)->dbl));
    }
    else{
        _32359 = (int)*(((s1_ptr)_2)->base + _26S_TOKEN_11659);
    }
    _32358 = NOVALUE;
    if (binary_op_a(EQUALS, _32359, 27)){
        _32359 = NOVALUE;
        goto L3; // [103] 113
    }
    _32359 = NOVALUE;

    /** 		RTFatal("specify the routine id of a procedure, not a function or type")*/
    RefDS(_32361);
    _67RTFatal(_32361);
L3: 

    /** 	b = Code[pc+2] -- args*/
    _32362 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67b_63481 = (int)*(((s1_ptr)_2)->base + _32362);
    if (!IS_ATOM_INT(_67b_63481)){
        _67b_63481 = (long)DBL_PTR(_67b_63481)->dbl;
    }

    /** 	new_entry = {val[a], next_task_id, T_REAL_TIME, ST_SUSPENDED, 0,*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _32364 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    _2 = (int)SEQ_PTR(_67val_63489);
    _32365 = (int)*(((s1_ptr)_2)->base + _67b_63481);
    _0 = _new_entry_64542;
    _1 = NewS1(16);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_32364);
    *((int *)(_2+4)) = _32364;
    Ref(_67next_task_id_63498);
    *((int *)(_2+8)) = _67next_task_id_63498;
    *((int *)(_2+12)) = 1;
    *((int *)(_2+16)) = 1;
    *((int *)(_2+20)) = 0;
    *((int *)(_2+24)) = 0;
    *((int *)(_2+28)) = 0;
    *((int *)(_2+32)) = 0;
    RefDS(_67TASK_NEVER_63490);
    *((int *)(_2+36)) = _67TASK_NEVER_63490;
    *((int *)(_2+40)) = 1;
    *((int *)(_2+44)) = 1;
    *((int *)(_2+48)) = 0;
    Ref(_32365);
    *((int *)(_2+52)) = _32365;
    *((int *)(_2+56)) = 0;
    RefDSn(_22037, 2);
    *((int *)(_2+60)) = _22037;
    *((int *)(_2+64)) = _22037;
    _new_entry_64542 = MAKE_SEQ(_1);
    DeRef(_0);
    _32365 = NOVALUE;
    _32364 = NOVALUE;

    /** 	recycle = FALSE*/
    _recycle_64544 = _9FALSE_428;

    /** 	for i = 1 to length(tcb) do*/
    if (IS_SEQUENCE(_67tcb_63522)){
            _32367 = SEQ_PTR(_67tcb_63522)->length;
    }
    else {
        _32367 = 1;
    }
    {
        int _i_64575;
        _i_64575 = 1;
L4: 
        if (_i_64575 > _32367){
            goto L5; // [182] 232
        }

        /** 		if tcb[i][TASK_STATE] = ST_DEAD then*/
        _2 = (int)SEQ_PTR(_67tcb_63522);
        _32368 = (int)*(((s1_ptr)_2)->base + _i_64575);
        _2 = (int)SEQ_PTR(_32368);
        _32369 = (int)*(((s1_ptr)_2)->base + 4);
        _32368 = NOVALUE;
        if (binary_op_a(NOTEQ, _32369, 2)){
            _32369 = NOVALUE;
            goto L6; // [201] 225
        }
        _32369 = NOVALUE;

        /** 			tcb[i] = new_entry*/
        RefDS(_new_entry_64542);
        _2 = (int)SEQ_PTR(_67tcb_63522);
        _2 = (int)(((s1_ptr)_2)->base + _i_64575);
        _1 = *(int *)_2;
        *(int *)_2 = _new_entry_64542;
        DeRefDS(_1);

        /** 			recycle = TRUE*/
        _recycle_64544 = _9TRUE_430;

        /** 			exit*/
        goto L5; // [222] 232
L6: 

        /** 	end for*/
        _i_64575 = _i_64575 + 1;
        goto L4; // [227] 189
L5: 
        ;
    }

    /** 	if not recycle then*/
    if (_recycle_64544 != 0)
    goto L7; // [234] 246

    /** 		tcb = append(tcb, new_entry)*/
    RefDS(_new_entry_64542);
    Append(&_67tcb_63522, _67tcb_63522, _new_entry_64542);
L7: 

    /** 	target = Code[pc+3]*/
    _32373 = _67pc_63479 + 3;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67target_63484 = (int)*(((s1_ptr)_2)->base + _32373);
    if (!IS_ATOM_INT(_67target_63484)){
        _67target_63484 = (long)DBL_PTR(_67target_63484)->dbl;
    }

    /** 	val[target] = next_task_id*/
    Ref(_67next_task_id_63498);
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63484);
    _1 = *(int *)_2;
    *(int *)_2 = _67next_task_id_63498;
    DeRef(_1);

    /** 	if not id_wrap and next_task_id < TASK_ID_MAX then*/
    _32375 = (_67id_wrap_63494 == 0);
    if (_32375 == 0) {
        goto L8; // [281] 306
    }
    if (IS_ATOM_INT(_67next_task_id_63498)) {
        _32377 = ((double)_67next_task_id_63498 < DBL_PTR(_67TASK_ID_MAX_63491)->dbl);
    }
    else {
        _32377 = (DBL_PTR(_67next_task_id_63498)->dbl < DBL_PTR(_67TASK_ID_MAX_63491)->dbl);
    }
    if (_32377 == 0)
    {
        DeRef(_32377);
        _32377 = NOVALUE;
        goto L8; // [292] 306
    }
    else{
        DeRef(_32377);
        _32377 = NOVALUE;
    }

    /** 		next_task_id += 1*/
    _0 = _67next_task_id_63498;
    if (IS_ATOM_INT(_67next_task_id_63498)) {
        _67next_task_id_63498 = _67next_task_id_63498 + 1;
        if (_67next_task_id_63498 > MAXINT){
            _67next_task_id_63498 = NewDouble((double)_67next_task_id_63498);
        }
    }
    else
    _67next_task_id_63498 = binary_op(PLUS, 1, _67next_task_id_63498);
    DeRef(_0);
    goto L9; // [303] 396
L8: 

    /** 		id_wrap = TRUE -- id's have wrapped*/
    _67id_wrap_63494 = _9TRUE_430;

    /** 		for i = 1 to TASK_ID_MAX do*/
    {
        int _i_64596;
        _i_64596 = 1;
LA: 
        if (binary_op_a(GREATER, _i_64596, _67TASK_ID_MAX_63491)){
            goto LB; // [315] 395
        }

        /** 			next_task_id = i*/
        Ref(_i_64596);
        DeRef(_67next_task_id_63498);
        _67next_task_id_63498 = _i_64596;

        /** 			for j = 1 to length(tcb) do*/
        if (IS_SEQUENCE(_67tcb_63522)){
                _32379 = SEQ_PTR(_67tcb_63522)->length;
        }
        else {
            _32379 = 1;
        }
        {
            int _j_64598;
            _j_64598 = 1;
LC: 
            if (_j_64598 > _32379){
                goto LD; // [334] 376
            }

            /** 				if next_task_id = tcb[j][TASK_TID] then*/
            _2 = (int)SEQ_PTR(_67tcb_63522);
            _32380 = (int)*(((s1_ptr)_2)->base + _j_64598);
            _2 = (int)SEQ_PTR(_32380);
            _32381 = (int)*(((s1_ptr)_2)->base + 2);
            _32380 = NOVALUE;
            if (binary_op_a(NOTEQ, _67next_task_id_63498, _32381)){
                _32381 = NOVALUE;
                goto LE; // [355] 369
            }
            _32381 = NOVALUE;

            /** 					next_task_id = 0*/
            DeRef(_67next_task_id_63498);
            _67next_task_id_63498 = 0;

            /** 					exit -- this id is still in use*/
            goto LD; // [366] 376
LE: 

            /** 			end for*/
            _j_64598 = _j_64598 + 1;
            goto LC; // [371] 341
LD: 
            ;
        }

        /** 			if next_task_id then*/
        if (_67next_task_id_63498 == 0) {
            goto LF; // [380] 388
        }
        else {
            if (!IS_ATOM_INT(_67next_task_id_63498) && DBL_PTR(_67next_task_id_63498)->dbl == 0.0){
                goto LF; // [380] 388
            }
        }

        /** 				exit -- found unused id for next time*/
        goto LB; // [385] 395
LF: 

        /** 		end for*/
        _0 = _i_64596;
        if (IS_ATOM_INT(_i_64596)) {
            _i_64596 = _i_64596 + 1;
            if ((long)((unsigned long)_i_64596 +(unsigned long) HIGH_BITS) >= 0){
                _i_64596 = NewDouble((double)_i_64596);
            }
        }
        else {
            _i_64596 = binary_op_a(PLUS, _i_64596, 1);
        }
        DeRef(_0);
        goto LA; // [390] 322
LB: 
        ;
        DeRef(_i_64596);
    }
L9: 

    /** 	pc += 4*/
    _67pc_63479 = _67pc_63479 + 4;

    /** end procedure*/
    DeRef(_new_entry_64542);
    DeRef(_32346);
    _32346 = NOVALUE;
    DeRef(_32362);
    _32362 = NOVALUE;
    DeRef(_32349);
    _32349 = NOVALUE;
    DeRef(_32356);
    _32356 = NOVALUE;
    DeRef(_32373);
    _32373 = NOVALUE;
    DeRef(_32375);
    _32375 = NOVALUE;
    return;
    ;
}


void _67opTASK_SCHEDULE()
{
    int _task_64608 = NOVALUE;
    int _now_64609 = NOVALUE;
    int _s_64610 = NOVALUE;
    int _32473 = NOVALUE;
    int _32471 = NOVALUE;
    int _32469 = NOVALUE;
    int _32468 = NOVALUE;
    int _32467 = NOVALUE;
    int _32465 = NOVALUE;
    int _32464 = NOVALUE;
    int _32463 = NOVALUE;
    int _32460 = NOVALUE;
    int _32459 = NOVALUE;
    int _32458 = NOVALUE;
    int _32457 = NOVALUE;
    int _32455 = NOVALUE;
    int _32454 = NOVALUE;
    int _32453 = NOVALUE;
    int _32451 = NOVALUE;
    int _32449 = NOVALUE;
    int _32447 = NOVALUE;
    int _32445 = NOVALUE;
    int _32442 = NOVALUE;
    int _32441 = NOVALUE;
    int _32440 = NOVALUE;
    int _32438 = NOVALUE;
    int _32435 = NOVALUE;
    int _32433 = NOVALUE;
    int _32432 = NOVALUE;
    int _32431 = NOVALUE;
    int _32429 = NOVALUE;
    int _32426 = NOVALUE;
    int _32425 = NOVALUE;
    int _32423 = NOVALUE;
    int _32422 = NOVALUE;
    int _32420 = NOVALUE;
    int _32419 = NOVALUE;
    int _32417 = NOVALUE;
    int _32416 = NOVALUE;
    int _32414 = NOVALUE;
    int _32413 = NOVALUE;
    int _32410 = NOVALUE;
    int _32408 = NOVALUE;
    int _32406 = NOVALUE;
    int _32405 = NOVALUE;
    int _32404 = NOVALUE;
    int _32402 = NOVALUE;
    int _32401 = NOVALUE;
    int _32400 = NOVALUE;
    int _32397 = NOVALUE;
    int _32396 = NOVALUE;
    int _32394 = NOVALUE;
    int _32391 = NOVALUE;
    int _32388 = NOVALUE;
    int _32386 = NOVALUE;
    int _32384 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	a = Code[pc+1]*/
    _32384 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _32384);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	task = which_task(val[a])*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _32386 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    Ref(_32386);
    _task_64608 = _67which_task(_32386);
    _32386 = NOVALUE;
    if (!IS_ATOM_INT(_task_64608)) {
        _1 = (long)(DBL_PTR(_task_64608)->dbl);
        DeRefDS(_task_64608);
        _task_64608 = _1;
    }

    /** 	b = Code[pc+2]*/
    _32388 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67b_63481 = (int)*(((s1_ptr)_2)->base + _32388);
    if (!IS_ATOM_INT(_67b_63481)){
        _67b_63481 = (long)DBL_PTR(_67b_63481)->dbl;
    }

    /** 	s = val[b]*/
    DeRef(_s_64610);
    _2 = (int)SEQ_PTR(_67val_63489);
    _s_64610 = (int)*(((s1_ptr)_2)->base + _67b_63481);
    Ref(_s_64610);

    /** 	if atom(s) then*/
    _32391 = IS_ATOM(_s_64610);
    if (_32391 == 0)
    {
        _32391 = NOVALUE;
        goto L1; // [64] 187
    }
    else{
        _32391 = NOVALUE;
    }

    /** 		if s <= 0 then*/
    if (binary_op_a(GREATER, _s_64610, 0)){
        goto L2; // [69] 79
    }

    /** 			RTFatal("number of executions must be greater than 0")*/
    RefDS(_32393);
    _67RTFatal(_32393);
L2: 

    /** 		tcb[task][TASK_RUNS_MAX] = s   -- max execution count*/
    _2 = (int)SEQ_PTR(_67tcb_63522);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _67tcb_63522 = MAKE_SEQ(_2);
    }
    _3 = (int)(_task_64608 + ((s1_ptr)_2)->base);
    Ref(_s_64610);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 11);
    _1 = *(int *)_2;
    *(int *)_2 = _s_64610;
    DeRef(_1);
    _32394 = NOVALUE;

    /** 		if tcb[task][TASK_TYPE] = T_REAL_TIME then*/
    _2 = (int)SEQ_PTR(_67tcb_63522);
    _32396 = (int)*(((s1_ptr)_2)->base + _task_64608);
    _2 = (int)SEQ_PTR(_32396);
    _32397 = (int)*(((s1_ptr)_2)->base + 3);
    _32396 = NOVALUE;
    if (binary_op_a(NOTEQ, _32397, 1)){
        _32397 = NOVALUE;
        goto L3; // [104] 120
    }
    _32397 = NOVALUE;

    /** 			rt_first = task_delete(rt_first, task)*/
    _0 = _67task_delete(_67rt_first_63525, _task_64608);
    _67rt_first_63525 = _0;
    if (!IS_ATOM_INT(_67rt_first_63525)) {
        _1 = (long)(DBL_PTR(_67rt_first_63525)->dbl);
        DeRefDS(_67rt_first_63525);
        _67rt_first_63525 = _1;
    }
L3: 

    /** 		if tcb[task][TASK_TYPE] = T_REAL_TIME or*/
    _2 = (int)SEQ_PTR(_67tcb_63522);
    _32400 = (int)*(((s1_ptr)_2)->base + _task_64608);
    _2 = (int)SEQ_PTR(_32400);
    _32401 = (int)*(((s1_ptr)_2)->base + 3);
    _32400 = NOVALUE;
    if (IS_ATOM_INT(_32401)) {
        _32402 = (_32401 == 1);
    }
    else {
        _32402 = binary_op(EQUALS, _32401, 1);
    }
    _32401 = NOVALUE;
    if (IS_ATOM_INT(_32402)) {
        if (_32402 != 0) {
            goto L4; // [136] 159
        }
    }
    else {
        if (DBL_PTR(_32402)->dbl != 0.0) {
            goto L4; // [136] 159
        }
    }
    _2 = (int)SEQ_PTR(_67tcb_63522);
    _32404 = (int)*(((s1_ptr)_2)->base + _task_64608);
    _2 = (int)SEQ_PTR(_32404);
    _32405 = (int)*(((s1_ptr)_2)->base + 4);
    _32404 = NOVALUE;
    if (IS_ATOM_INT(_32405)) {
        _32406 = (_32405 == 1);
    }
    else {
        _32406 = binary_op(EQUALS, _32405, 1);
    }
    _32405 = NOVALUE;
    if (_32406 == 0) {
        DeRef(_32406);
        _32406 = NOVALUE;
        goto L5; // [155] 171
    }
    else {
        if (!IS_ATOM_INT(_32406) && DBL_PTR(_32406)->dbl == 0.0){
            DeRef(_32406);
            _32406 = NOVALUE;
            goto L5; // [155] 171
        }
        DeRef(_32406);
        _32406 = NOVALUE;
    }
    DeRef(_32406);
    _32406 = NOVALUE;
L4: 

    /** 			ts_first = task_insert(ts_first, task)*/
    _0 = _67task_insert(_67ts_first_63526, _task_64608);
    _67ts_first_63526 = _0;
    if (!IS_ATOM_INT(_67ts_first_63526)) {
        _1 = (long)(DBL_PTR(_67ts_first_63526)->dbl);
        DeRefDS(_67ts_first_63526);
        _67ts_first_63526 = _1;
    }
L5: 

    /** 		tcb[task][TASK_TYPE] = T_TIME_SHARE*/
    _2 = (int)SEQ_PTR(_67tcb_63522);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _67tcb_63522 = MAKE_SEQ(_2);
    }
    _3 = (int)(_task_64608 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = 2;
    DeRef(_1);
    _32408 = NOVALUE;
    goto L6; // [184] 542
L1: 

    /** 		if length(s) != 2 then*/
    if (IS_SEQUENCE(_s_64610)){
            _32410 = SEQ_PTR(_s_64610)->length;
    }
    else {
        _32410 = 1;
    }
    if (_32410 == 2)
    goto L7; // [192] 202

    /** 			RTFatal("second argument must be {min-time, max-time}")*/
    RefDS(_32412);
    _67RTFatal(_32412);
L7: 

    /** 		if sequence(s[1]) or sequence(s[2]) then*/
    _2 = (int)SEQ_PTR(_s_64610);
    _32413 = (int)*(((s1_ptr)_2)->base + 1);
    _32414 = IS_SEQUENCE(_32413);
    _32413 = NOVALUE;
    if (_32414 != 0) {
        goto L8; // [211] 227
    }
    _2 = (int)SEQ_PTR(_s_64610);
    _32416 = (int)*(((s1_ptr)_2)->base + 2);
    _32417 = IS_SEQUENCE(_32416);
    _32416 = NOVALUE;
    if (_32417 == 0)
    {
        _32417 = NOVALUE;
        goto L9; // [223] 233
    }
    else{
        _32417 = NOVALUE;
    }
L8: 

    /** 			RTFatal("min and max times must be atoms")*/
    RefDS(_32418);
    _67RTFatal(_32418);
L9: 

    /** 		if s[1] < 0 or s[2] < 0 then*/
    _2 = (int)SEQ_PTR(_s_64610);
    _32419 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_32419)) {
        _32420 = (_32419 < 0);
    }
    else {
        _32420 = binary_op(LESS, _32419, 0);
    }
    _32419 = NOVALUE;
    if (IS_ATOM_INT(_32420)) {
        if (_32420 != 0) {
            goto LA; // [243] 260
        }
    }
    else {
        if (DBL_PTR(_32420)->dbl != 0.0) {
            goto LA; // [243] 260
        }
    }
    _2 = (int)SEQ_PTR(_s_64610);
    _32422 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_32422)) {
        _32423 = (_32422 < 0);
    }
    else {
        _32423 = binary_op(LESS, _32422, 0);
    }
    _32422 = NOVALUE;
    if (_32423 == 0) {
        DeRef(_32423);
        _32423 = NOVALUE;
        goto LB; // [256] 266
    }
    else {
        if (!IS_ATOM_INT(_32423) && DBL_PTR(_32423)->dbl == 0.0){
            DeRef(_32423);
            _32423 = NOVALUE;
            goto LB; // [256] 266
        }
        DeRef(_32423);
        _32423 = NOVALUE;
    }
    DeRef(_32423);
    _32423 = NOVALUE;
LA: 

    /** 			RTFatal("min and max times must be greater than or equal to 0")*/
    RefDS(_32424);
    _67RTFatal(_32424);
LB: 

    /** 		if s[1] > s[2] then*/
    _2 = (int)SEQ_PTR(_s_64610);
    _32425 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_s_64610);
    _32426 = (int)*(((s1_ptr)_2)->base + 2);
    if (binary_op_a(LESSEQ, _32425, _32426)){
        _32425 = NOVALUE;
        _32426 = NOVALUE;
        goto LC; // [276] 286
    }
    _32425 = NOVALUE;
    _32426 = NOVALUE;

    /** 			RTFatal("task min time must be <= task max time")*/
    RefDS(_32428);
    _67RTFatal(_32428);
LC: 

    /** 		tcb[task][TASK_MIN_INC] = s[1]*/
    _2 = (int)SEQ_PTR(_67tcb_63522);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _67tcb_63522 = MAKE_SEQ(_2);
    }
    _3 = (int)(_task_64608 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_s_64610);
    _32431 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_32431);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 6);
    _1 = *(int *)_2;
    *(int *)_2 = _32431;
    if( _1 != _32431 ){
        DeRef(_1);
    }
    _32431 = NOVALUE;
    _32429 = NOVALUE;

    /** 		if s[1] < clock_period/2 then*/
    _2 = (int)SEQ_PTR(_s_64610);
    _32432 = (int)*(((s1_ptr)_2)->base + 1);
    _32433 = binary_op(DIVIDE, _67clock_period_63499, 2);
    if (binary_op_a(GREATEREQ, _32432, _32433)){
        _32432 = NOVALUE;
        DeRefDS(_32433);
        _32433 = NOVALUE;
        goto LD; // [315] 372
    }
    _32432 = NOVALUE;
    DeRef(_32433);
    _32433 = NOVALUE;

    /** 			if s[1] > 1.0e-9 then*/
    _2 = (int)SEQ_PTR(_s_64610);
    _32435 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(LESSEQ, _32435, _32436)){
        _32435 = NOVALUE;
        goto LE; // [325] 355
    }
    _32435 = NOVALUE;

    /** 				tcb[task][TASK_RUNS_MAX] =  floor(clock_period / s[1])*/
    _2 = (int)SEQ_PTR(_67tcb_63522);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _67tcb_63522 = MAKE_SEQ(_2);
    }
    _3 = (int)(_task_64608 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_s_64610);
    _32440 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = binary_op(DIVIDE, _67clock_period_63499, _32440);
    _32441 = unary_op(FLOOR, _2);
    DeRef(_2);
    _32440 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 11);
    _1 = *(int *)_2;
    *(int *)_2 = _32441;
    if( _1 != _32441 ){
        DeRef(_1);
    }
    _32441 = NOVALUE;
    _32438 = NOVALUE;
    goto LF; // [352] 386
LE: 

    /** 				tcb[task][TASK_RUNS_MAX] =  1000000000 -- arbitrary, large*/
    _2 = (int)SEQ_PTR(_67tcb_63522);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _67tcb_63522 = MAKE_SEQ(_2);
    }
    _3 = (int)(_task_64608 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 11);
    _1 = *(int *)_2;
    *(int *)_2 = 1000000000;
    DeRef(_1);
    _32442 = NOVALUE;
    goto LF; // [369] 386
LD: 

    /** 			tcb[task][TASK_RUNS_MAX] = 1*/
    _2 = (int)SEQ_PTR(_67tcb_63522);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _67tcb_63522 = MAKE_SEQ(_2);
    }
    _3 = (int)(_task_64608 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 11);
    _1 = *(int *)_2;
    *(int *)_2 = 1;
    DeRef(_1);
    _32445 = NOVALUE;
LF: 

    /** 		tcb[task][TASK_MAX_INC] = s[2]*/
    _2 = (int)SEQ_PTR(_67tcb_63522);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _67tcb_63522 = MAKE_SEQ(_2);
    }
    _3 = (int)(_task_64608 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_s_64610);
    _32449 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_32449);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 7);
    _1 = *(int *)_2;
    *(int *)_2 = _32449;
    if( _1 != _32449 ){
        DeRef(_1);
    }
    _32449 = NOVALUE;
    _32447 = NOVALUE;

    /** 		now = time()*/
    DeRef(_now_64609);
    _now_64609 = NewDouble(current_time());

    /** 		tcb[task][TASK_MIN_TIME] = now + s[1]*/
    _2 = (int)SEQ_PTR(_67tcb_63522);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _67tcb_63522 = MAKE_SEQ(_2);
    }
    _3 = (int)(_task_64608 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_s_64610);
    _32453 = (int)*(((s1_ptr)_2)->base + 1);
    _32454 = binary_op(PLUS, _now_64609, _32453);
    _32453 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 8);
    _1 = *(int *)_2;
    *(int *)_2 = _32454;
    if( _1 != _32454 ){
        DeRef(_1);
    }
    _32454 = NOVALUE;
    _32451 = NOVALUE;

    /** 		tcb[task][TASK_MAX_TIME] = now + s[2]*/
    _2 = (int)SEQ_PTR(_67tcb_63522);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _67tcb_63522 = MAKE_SEQ(_2);
    }
    _3 = (int)(_task_64608 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_s_64610);
    _32457 = (int)*(((s1_ptr)_2)->base + 2);
    _32458 = binary_op(PLUS, _now_64609, _32457);
    _32457 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 9);
    _1 = *(int *)_2;
    *(int *)_2 = _32458;
    if( _1 != _32458 ){
        DeRef(_1);
    }
    _32458 = NOVALUE;
    _32455 = NOVALUE;

    /** 		if tcb[task][TASK_TYPE] = T_TIME_SHARE then*/
    _2 = (int)SEQ_PTR(_67tcb_63522);
    _32459 = (int)*(((s1_ptr)_2)->base + _task_64608);
    _2 = (int)SEQ_PTR(_32459);
    _32460 = (int)*(((s1_ptr)_2)->base + 3);
    _32459 = NOVALUE;
    if (binary_op_a(NOTEQ, _32460, 2)){
        _32460 = NOVALUE;
        goto L10; // [461] 477
    }
    _32460 = NOVALUE;

    /** 			ts_first = task_delete(ts_first, task)*/
    _0 = _67task_delete(_67ts_first_63526, _task_64608);
    _67ts_first_63526 = _0;
    if (!IS_ATOM_INT(_67ts_first_63526)) {
        _1 = (long)(DBL_PTR(_67ts_first_63526)->dbl);
        DeRefDS(_67ts_first_63526);
        _67ts_first_63526 = _1;
    }
L10: 

    /** 		if tcb[task][TASK_TYPE] = T_TIME_SHARE or*/
    _2 = (int)SEQ_PTR(_67tcb_63522);
    _32463 = (int)*(((s1_ptr)_2)->base + _task_64608);
    _2 = (int)SEQ_PTR(_32463);
    _32464 = (int)*(((s1_ptr)_2)->base + 3);
    _32463 = NOVALUE;
    if (IS_ATOM_INT(_32464)) {
        _32465 = (_32464 == 2);
    }
    else {
        _32465 = binary_op(EQUALS, _32464, 2);
    }
    _32464 = NOVALUE;
    if (IS_ATOM_INT(_32465)) {
        if (_32465 != 0) {
            goto L11; // [493] 516
        }
    }
    else {
        if (DBL_PTR(_32465)->dbl != 0.0) {
            goto L11; // [493] 516
        }
    }
    _2 = (int)SEQ_PTR(_67tcb_63522);
    _32467 = (int)*(((s1_ptr)_2)->base + _task_64608);
    _2 = (int)SEQ_PTR(_32467);
    _32468 = (int)*(((s1_ptr)_2)->base + 4);
    _32467 = NOVALUE;
    if (IS_ATOM_INT(_32468)) {
        _32469 = (_32468 == 1);
    }
    else {
        _32469 = binary_op(EQUALS, _32468, 1);
    }
    _32468 = NOVALUE;
    if (_32469 == 0) {
        DeRef(_32469);
        _32469 = NOVALUE;
        goto L12; // [512] 528
    }
    else {
        if (!IS_ATOM_INT(_32469) && DBL_PTR(_32469)->dbl == 0.0){
            DeRef(_32469);
            _32469 = NOVALUE;
            goto L12; // [512] 528
        }
        DeRef(_32469);
        _32469 = NOVALUE;
    }
    DeRef(_32469);
    _32469 = NOVALUE;
L11: 

    /** 			rt_first = task_insert(rt_first, task)*/
    _0 = _67task_insert(_67rt_first_63525, _task_64608);
    _67rt_first_63525 = _0;
    if (!IS_ATOM_INT(_67rt_first_63525)) {
        _1 = (long)(DBL_PTR(_67rt_first_63525)->dbl);
        DeRefDS(_67rt_first_63525);
        _67rt_first_63525 = _1;
    }
L12: 

    /** 		tcb[task][TASK_TYPE] = T_REAL_TIME*/
    _2 = (int)SEQ_PTR(_67tcb_63522);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _67tcb_63522 = MAKE_SEQ(_2);
    }
    _3 = (int)(_task_64608 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = 1;
    DeRef(_1);
    _32471 = NOVALUE;
L6: 

    /** 	tcb[task][TASK_STATE] = ST_ACTIVE*/
    _2 = (int)SEQ_PTR(_67tcb_63522);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _67tcb_63522 = MAKE_SEQ(_2);
    }
    _3 = (int)(_task_64608 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _32473 = NOVALUE;

    /** 	pc += 3*/
    _67pc_63479 = _67pc_63479 + 3;

    /** end procedure*/
    DeRef(_now_64609);
    DeRef(_s_64610);
    DeRef(_32384);
    _32384 = NOVALUE;
    DeRef(_32388);
    _32388 = NOVALUE;
    DeRef(_32402);
    _32402 = NOVALUE;
    DeRef(_32420);
    _32420 = NOVALUE;
    DeRef(_32465);
    _32465 = NOVALUE;
    return;
    ;
}


void _67one_trace_line(int _line_64725)
{
    int _32478 = NOVALUE;
    int _0, _1, _2;
    

    /** 	ifdef UNIX then*/

    /** 		printf(trace_file, "%-77.77s\r\n", {line})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_line_64725);
    *((int *)(_2+4)) = _line_64725;
    _32478 = MAKE_SEQ(_1);
    EPrintf(_67trace_file_64721, _32477, _32478);
    DeRefDS(_32478);
    _32478 = NOVALUE;

    /** end procedure*/
    DeRefDS(_line_64725);
    return;
    ;
}


void _67opCOVERAGE_LINE()
{
    int _32480 = NOVALUE;
    int _32479 = NOVALUE;
    int _0, _1, _2;
    

    /** 	cover_line( Code[pc+1] )*/
    _32479 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _32480 = (int)*(((s1_ptr)_2)->base + _32479);
    Ref(_32480);
    _49cover_line(_32480);
    _32480 = NOVALUE;

    /** 	pc += 2*/
    _67pc_63479 = _67pc_63479 + 2;

    /** end procedure*/
    _32479 = NOVALUE;
    return;
    ;
}


void _67opCOVERAGE_ROUTINE()
{
    int _32483 = NOVALUE;
    int _32482 = NOVALUE;
    int _0, _1, _2;
    

    /** 	cover_routine( Code[pc+1] )*/
    _32482 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _32483 = (int)*(((s1_ptr)_2)->base + _32482);
    Ref(_32483);
    _49cover_routine(_32483);
    _32483 = NOVALUE;

    /** 	pc += 2*/
    _67pc_63479 = _67pc_63479 + 2;

    /** end procedure*/
    _32482 = NOVALUE;
    return;
    ;
}


void _67opSTARTLINE()
{
    int _line_64745 = NOVALUE;
    int _w_64746 = NOVALUE;
    int _32517 = NOVALUE;
    int _32516 = NOVALUE;
    int _32515 = NOVALUE;
    int _32512 = NOVALUE;
    int _32506 = NOVALUE;
    int _32505 = NOVALUE;
    int _32504 = NOVALUE;
    int _32503 = NOVALUE;
    int _32502 = NOVALUE;
    int _32501 = NOVALUE;
    int _32500 = NOVALUE;
    int _32497 = NOVALUE;
    int _32496 = NOVALUE;
    int _32494 = NOVALUE;
    int _32493 = NOVALUE;
    int _32492 = NOVALUE;
    int _32490 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if TraceOn then*/
    if (_67TraceOn_63477 == 0)
    {
        goto L1; // [5] 277
    }
    else{
    }

    /** 		if trace_file = -1 then*/
    if (_67trace_file_64721 != -1)
    goto L2; // [12] 40

    /** 			trace_file = open("ctrace.out", "wb")*/
    _67trace_file_64721 = EOpen(_32486, _23720, 0);

    /** 			if trace_file = -1 then*/
    if (_67trace_file_64721 != -1)
    goto L3; // [29] 39

    /** 				RTFatal("Couldn't open ctrace.out")*/
    RefDS(_32489);
    _67RTFatal(_32489);
L3: 
L2: 

    /** 		a = Code[pc+1]*/
    _32490 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _32490);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 		if atom(slist[$]) then*/
    if (IS_SEQUENCE(_26slist_12073)){
            _32492 = SEQ_PTR(_26slist_12073)->length;
    }
    else {
        _32492 = 1;
    }
    _2 = (int)SEQ_PTR(_26slist_12073);
    _32493 = (int)*(((s1_ptr)_2)->base + _32492);
    _32494 = IS_ATOM(_32493);
    _32493 = NOVALUE;
    if (_32494 == 0)
    {
        _32494 = NOVALUE;
        goto L4; // [70] 84
    }
    else{
        _32494 = NOVALUE;
    }

    /** 			slist = s_expand(slist)*/
    RefDS(_26slist_12073);
    _0 = _60s_expand(_26slist_12073);
    DeRefDS(_26slist_12073);
    _26slist_12073 = _0;
L4: 

    /** 		line = fetch_line(slist[a][SRC])*/
    _2 = (int)SEQ_PTR(_26slist_12073);
    _32496 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    _2 = (int)SEQ_PTR(_32496);
    _32497 = (int)*(((s1_ptr)_2)->base + 1);
    _32496 = NOVALUE;
    Ref(_32497);
    _0 = _line_64745;
    _line_64745 = _60fetch_line(_32497);
    DeRef(_0);
    _32497 = NOVALUE;

    /** 		line = sprintf("%s:%d\t%s",*/
    _2 = (int)SEQ_PTR(_26slist_12073);
    _32500 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    _2 = (int)SEQ_PTR(_32500);
    _32501 = (int)*(((s1_ptr)_2)->base + 3);
    _32500 = NOVALUE;
    _2 = (int)SEQ_PTR(_27known_files_10922);
    if (!IS_ATOM_INT(_32501)){
        _32502 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_32501)->dbl));
    }
    else{
        _32502 = (int)*(((s1_ptr)_2)->base + _32501);
    }
    Ref(_32502);
    _32503 = _52name_ext(_32502);
    _32502 = NOVALUE;
    _2 = (int)SEQ_PTR(_26slist_12073);
    _32504 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    _2 = (int)SEQ_PTR(_32504);
    _32505 = (int)*(((s1_ptr)_2)->base + 2);
    _32504 = NOVALUE;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _32503;
    Ref(_32505);
    *((int *)(_2+8)) = _32505;
    RefDS(_line_64745);
    *((int *)(_2+12)) = _line_64745;
    _32506 = MAKE_SEQ(_1);
    _32505 = NOVALUE;
    _32503 = NOVALUE;
    DeRefDS(_line_64745);
    _line_64745 = EPrintf(-9999999, _32499, _32506);
    DeRefDS(_32506);
    _32506 = NOVALUE;

    /** 		trace_line += 1*/
    _67trace_line_64722 = _67trace_line_64722 + 1;

    /** 		if trace_line >= 5000 then*/
    if (_67trace_line_64722 < 5000)
    goto L5; // [168] 208

    /** 			trace_line = 0*/
    _67trace_line_64722 = 0;

    /** 			one_trace_line("")*/
    RefDS(_22037);
    _67one_trace_line(_22037);

    /** 			one_trace_line("               ")*/
    RefDS(_32511);
    _67one_trace_line(_32511);

    /** 			flush(trace_file)*/
    _18flush(_67trace_file_64721);

    /** 			if seek(trace_file, 0) then*/
    _32512 = _18seek(_67trace_file_64721, 0);
    if (_32512 == 0) {
        DeRef(_32512);
        _32512 = NOVALUE;
        goto L6; // [203] 207
    }
    else {
        if (!IS_ATOM_INT(_32512) && DBL_PTR(_32512)->dbl == 0.0){
            DeRef(_32512);
            _32512 = NOVALUE;
            goto L6; // [203] 207
        }
        DeRef(_32512);
        _32512 = NOVALUE;
    }
    DeRef(_32512);
    _32512 = NOVALUE;
L6: 
L5: 

    /** 		one_trace_line(line)*/
    RefDS(_line_64745);
    _67one_trace_line(_line_64745);

    /** 		one_trace_line("")*/
    RefDS(_22037);
    _67one_trace_line(_22037);

    /** 		one_trace_line("=== THE END ===")*/
    RefDS(_32513);
    _67one_trace_line(_32513);

    /** 		one_trace_line("")*/
    RefDS(_22037);
    _67one_trace_line(_22037);

    /** 		one_trace_line("")*/
    RefDS(_22037);
    _67one_trace_line(_22037);

    /** 		one_trace_line("")*/
    RefDS(_22037);
    _67one_trace_line(_22037);

    /** 		flush(trace_file)*/
    _18flush(_67trace_file_64721);

    /** 		w = where(trace_file)*/
    _w_64746 = _18where(_67trace_file_64721);
    if (!IS_ATOM_INT(_w_64746)) {
        _1 = (long)(DBL_PTR(_w_64746)->dbl);
        DeRefDS(_w_64746);
        _w_64746 = _1;
    }

    /** 		if seek(trace_file, w-79*5) then -- back up 5 (fixed-width) lines*/
    _32515 = 395;
    _32516 = _w_64746 - 395;
    if ((long)((unsigned long)_32516 +(unsigned long) HIGH_BITS) >= 0){
        _32516 = NewDouble((double)_32516);
    }
    _32515 = NOVALUE;
    _32517 = _18seek(_67trace_file_64721, _32516);
    _32516 = NOVALUE;
    if (_32517 == 0) {
        DeRef(_32517);
        _32517 = NOVALUE;
        goto L7; // [272] 276
    }
    else {
        if (!IS_ATOM_INT(_32517) && DBL_PTR(_32517)->dbl == 0.0){
            DeRef(_32517);
            _32517 = NOVALUE;
            goto L7; // [272] 276
        }
        DeRef(_32517);
        _32517 = NOVALUE;
    }
    DeRef(_32517);
    _32517 = NOVALUE;
L7: 
L1: 

    /** 	pc += 2*/
    _67pc_63479 = _67pc_63479 + 2;

    /** end procedure*/
    DeRef(_line_64745);
    DeRef(_32490);
    _32490 = NOVALUE;
    _32501 = NOVALUE;
    return;
    ;
}


void _67opPROC_TAIL()
{
    int _arg_64809 = NOVALUE;
    int _sub_64810 = NOVALUE;
    int _32535 = NOVALUE;
    int _32534 = NOVALUE;
    int _32533 = NOVALUE;
    int _32532 = NOVALUE;
    int _32531 = NOVALUE;
    int _32529 = NOVALUE;
    int _32528 = NOVALUE;
    int _32527 = NOVALUE;
    int _32526 = NOVALUE;
    int _32525 = NOVALUE;
    int _32524 = NOVALUE;
    int _32523 = NOVALUE;
    int _32521 = NOVALUE;
    int _32519 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sub = Code[pc+1] -- subroutine*/
    _32519 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _sub_64810 = (int)*(((s1_ptr)_2)->base + _32519);
    if (!IS_ATOM_INT(_sub_64810)){
        _sub_64810 = (long)DBL_PTR(_sub_64810)->dbl;
    }

    /** 	arg = SymTab[sub][S_NEXT]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _32521 = (int)*(((s1_ptr)_2)->base + _sub_64810);
    _2 = (int)SEQ_PTR(_32521);
    _arg_64809 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_arg_64809)){
        _arg_64809 = (long)DBL_PTR(_arg_64809)->dbl;
    }
    _32521 = NOVALUE;

    /** 	for i = 1 to SymTab[sub][S_NUM_ARGS] do*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _32523 = (int)*(((s1_ptr)_2)->base + _sub_64810);
    _2 = (int)SEQ_PTR(_32523);
    if (!IS_ATOM_INT(_26S_NUM_ARGS_11705)){
        _32524 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NUM_ARGS_11705)->dbl));
    }
    else{
        _32524 = (int)*(((s1_ptr)_2)->base + _26S_NUM_ARGS_11705);
    }
    _32523 = NOVALUE;
    {
        int _i_64819;
        _i_64819 = 1;
L1: 
        if (binary_op_a(GREATER, _i_64819, _32524)){
            goto L2; // [47] 107
        }

        /** 		val[arg] = val[Code[pc+1+i]]*/
        _32525 = _67pc_63479 + 1;
        if (_32525 > MAXINT){
            _32525 = NewDouble((double)_32525);
        }
        if (IS_ATOM_INT(_32525) && IS_ATOM_INT(_i_64819)) {
            _32526 = _32525 + _i_64819;
        }
        else {
            if (IS_ATOM_INT(_32525)) {
                _32526 = NewDouble((double)_32525 + DBL_PTR(_i_64819)->dbl);
            }
            else {
                if (IS_ATOM_INT(_i_64819)) {
                    _32526 = NewDouble(DBL_PTR(_32525)->dbl + (double)_i_64819);
                }
                else
                _32526 = NewDouble(DBL_PTR(_32525)->dbl + DBL_PTR(_i_64819)->dbl);
            }
        }
        DeRef(_32525);
        _32525 = NOVALUE;
        _2 = (int)SEQ_PTR(_26Code_12071);
        if (!IS_ATOM_INT(_32526)){
            _32527 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_32526)->dbl));
        }
        else{
            _32527 = (int)*(((s1_ptr)_2)->base + _32526);
        }
        _2 = (int)SEQ_PTR(_67val_63489);
        if (!IS_ATOM_INT(_32527)){
            _32528 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_32527)->dbl));
        }
        else{
            _32528 = (int)*(((s1_ptr)_2)->base + _32527);
        }
        Ref(_32528);
        _2 = (int)SEQ_PTR(_67val_63489);
        _2 = (int)(((s1_ptr)_2)->base + _arg_64809);
        _1 = *(int *)_2;
        *(int *)_2 = _32528;
        if( _1 != _32528 ){
            DeRef(_1);
        }
        _32528 = NOVALUE;

        /** 		arg = SymTab[arg][S_NEXT]*/
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _32529 = (int)*(((s1_ptr)_2)->base + _arg_64809);
        _2 = (int)SEQ_PTR(_32529);
        _arg_64809 = (int)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_arg_64809)){
            _arg_64809 = (long)DBL_PTR(_arg_64809)->dbl;
        }
        _32529 = NOVALUE;

        /** 	end for*/
        _0 = _i_64819;
        if (IS_ATOM_INT(_i_64819)) {
            _i_64819 = _i_64819 + 1;
            if ((long)((unsigned long)_i_64819 +(unsigned long) HIGH_BITS) >= 0){
                _i_64819 = NewDouble((double)_i_64819);
            }
        }
        else {
            _i_64819 = binary_op_a(PLUS, _i_64819, 1);
        }
        DeRef(_0);
        goto L1; // [102] 54
L2: 
        ;
        DeRef(_i_64819);
    }

    /** 	while arg and SymTab[arg][S_SCOPE] <= SC_PRIVATE do*/
L3: 
    if (_arg_64809 == 0) {
        goto L4; // [112] 169
    }
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _32532 = (int)*(((s1_ptr)_2)->base + _arg_64809);
    _2 = (int)SEQ_PTR(_32532);
    _32533 = (int)*(((s1_ptr)_2)->base + 4);
    _32532 = NOVALUE;
    if (IS_ATOM_INT(_32533)) {
        _32534 = (_32533 <= 3);
    }
    else {
        _32534 = binary_op(LESSEQ, _32533, 3);
    }
    _32533 = NOVALUE;
    if (_32534 <= 0) {
        if (_32534 == 0) {
            DeRef(_32534);
            _32534 = NOVALUE;
            goto L4; // [135] 169
        }
        else {
            if (!IS_ATOM_INT(_32534) && DBL_PTR(_32534)->dbl == 0.0){
                DeRef(_32534);
                _32534 = NOVALUE;
                goto L4; // [135] 169
            }
            DeRef(_32534);
            _32534 = NOVALUE;
        }
    }
    DeRef(_32534);
    _32534 = NOVALUE;

    /** 		val[arg] = NOVALUE*/
    Ref(_26NOVALUE_11836);
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _arg_64809);
    _1 = *(int *)_2;
    *(int *)_2 = _26NOVALUE_11836;
    DeRef(_1);

    /** 		arg = SymTab[arg][S_NEXT]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _32535 = (int)*(((s1_ptr)_2)->base + _arg_64809);
    _2 = (int)SEQ_PTR(_32535);
    _arg_64809 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_arg_64809)){
        _arg_64809 = (long)DBL_PTR(_arg_64809)->dbl;
    }
    _32535 = NOVALUE;

    /** 	end while*/
    goto L3; // [166] 112
L4: 

    /** 	pc = 1*/
    _67pc_63479 = 1;

    /** end procedure*/
    DeRef(_32519);
    _32519 = NOVALUE;
    _32524 = NOVALUE;
    _32527 = NOVALUE;
    DeRef(_32526);
    _32526 = NOVALUE;
    return;
    ;
}


void _67opPROC()
{
    int _n_64848 = NOVALUE;
    int _arg_64849 = NOVALUE;
    int _sub_64850 = NOVALUE;
    int _p_64851 = NOVALUE;
    int _private_block_64852 = NOVALUE;
    int _32602 = NOVALUE;
    int _32597 = NOVALUE;
    int _32596 = NOVALUE;
    int _32594 = NOVALUE;
    int _32592 = NOVALUE;
    int _32590 = NOVALUE;
    int _32589 = NOVALUE;
    int _32588 = NOVALUE;
    int _32587 = NOVALUE;
    int _32586 = NOVALUE;
    int _32585 = NOVALUE;
    int _32583 = NOVALUE;
    int _32581 = NOVALUE;
    int _32578 = NOVALUE;
    int _32576 = NOVALUE;
    int _32574 = NOVALUE;
    int _32572 = NOVALUE;
    int _32571 = NOVALUE;
    int _32570 = NOVALUE;
    int _32569 = NOVALUE;
    int _32568 = NOVALUE;
    int _32567 = NOVALUE;
    int _32566 = NOVALUE;
    int _32565 = NOVALUE;
    int _32564 = NOVALUE;
    int _32563 = NOVALUE;
    int _32562 = NOVALUE;
    int _32561 = NOVALUE;
    int _32560 = NOVALUE;
    int _32559 = NOVALUE;
    int _32558 = NOVALUE;
    int _32556 = NOVALUE;
    int _32555 = NOVALUE;
    int _32554 = NOVALUE;
    int _32553 = NOVALUE;
    int _32552 = NOVALUE;
    int _32550 = NOVALUE;
    int _32549 = NOVALUE;
    int _32547 = NOVALUE;
    int _32546 = NOVALUE;
    int _32544 = NOVALUE;
    int _32543 = NOVALUE;
    int _32541 = NOVALUE;
    int _32539 = NOVALUE;
    int _32537 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	sub = Code[pc+1] -- subroutine*/
    _32537 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _sub_64850 = (int)*(((s1_ptr)_2)->base + _32537);
    if (!IS_ATOM_INT(_sub_64850)){
        _sub_64850 = (long)DBL_PTR(_sub_64850)->dbl;
    }

    /** 	arg = SymTab[sub][S_NEXT]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _32539 = (int)*(((s1_ptr)_2)->base + _sub_64850);
    _2 = (int)SEQ_PTR(_32539);
    _arg_64849 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_arg_64849)){
        _arg_64849 = (long)DBL_PTR(_arg_64849)->dbl;
    }
    _32539 = NOVALUE;

    /** 	n = SymTab[sub][S_NUM_ARGS]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _32541 = (int)*(((s1_ptr)_2)->base + _sub_64850);
    _2 = (int)SEQ_PTR(_32541);
    if (!IS_ATOM_INT(_26S_NUM_ARGS_11705)){
        _n_64848 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NUM_ARGS_11705)->dbl));
    }
    else{
        _n_64848 = (int)*(((s1_ptr)_2)->base + _26S_NUM_ARGS_11705);
    }
    if (!IS_ATOM_INT(_n_64848)){
        _n_64848 = (long)DBL_PTR(_n_64848)->dbl;
    }
    _32541 = NOVALUE;

    /** 	if SymTab[sub][S_RESIDENT_TASK] != 0 then*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _32543 = (int)*(((s1_ptr)_2)->base + _sub_64850);
    _2 = (int)SEQ_PTR(_32543);
    _32544 = (int)*(((s1_ptr)_2)->base + 25);
    _32543 = NOVALUE;
    if (binary_op_a(EQUALS, _32544, 0)){
        _32544 = NOVALUE;
        goto L1; // [63] 413
    }
    _32544 = NOVALUE;

    /** 		private_block = repeat(0, SymTab[sub][S_STACK_SPACE])*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _32546 = (int)*(((s1_ptr)_2)->base + _sub_64850);
    _2 = (int)SEQ_PTR(_32546);
    if (!IS_ATOM_INT(_26S_STACK_SPACE_11714)){
        _32547 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_STACK_SPACE_11714)->dbl));
    }
    else{
        _32547 = (int)*(((s1_ptr)_2)->base + _26S_STACK_SPACE_11714);
    }
    _32546 = NOVALUE;
    DeRef(_private_block_64852);
    _private_block_64852 = Repeat(0, _32547);
    _32547 = NOVALUE;

    /** 		p = 1*/
    _p_64851 = 1;

    /** 		for i = 1 to n do*/
    _32549 = _n_64848;
    {
        int _i_64876;
        _i_64876 = 1;
L2: 
        if (_i_64876 > _32549){
            goto L3; // [95] 173
        }

        /** 			private_block[p] = val[arg]*/
        _2 = (int)SEQ_PTR(_67val_63489);
        _32550 = (int)*(((s1_ptr)_2)->base + _arg_64849);
        Ref(_32550);
        _2 = (int)SEQ_PTR(_private_block_64852);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _private_block_64852 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _p_64851);
        _1 = *(int *)_2;
        *(int *)_2 = _32550;
        if( _1 != _32550 ){
            DeRef(_1);
        }
        _32550 = NOVALUE;

        /** 			p += 1*/
        _p_64851 = _p_64851 + 1;

        /** 			val[arg] = val[Code[pc+1+i]]*/
        _32552 = _67pc_63479 + 1;
        if (_32552 > MAXINT){
            _32552 = NewDouble((double)_32552);
        }
        if (IS_ATOM_INT(_32552)) {
            _32553 = _32552 + _i_64876;
        }
        else {
            _32553 = NewDouble(DBL_PTR(_32552)->dbl + (double)_i_64876);
        }
        DeRef(_32552);
        _32552 = NOVALUE;
        _2 = (int)SEQ_PTR(_26Code_12071);
        if (!IS_ATOM_INT(_32553)){
            _32554 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_32553)->dbl));
        }
        else{
            _32554 = (int)*(((s1_ptr)_2)->base + _32553);
        }
        _2 = (int)SEQ_PTR(_67val_63489);
        if (!IS_ATOM_INT(_32554)){
            _32555 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_32554)->dbl));
        }
        else{
            _32555 = (int)*(((s1_ptr)_2)->base + _32554);
        }
        Ref(_32555);
        _2 = (int)SEQ_PTR(_67val_63489);
        _2 = (int)(((s1_ptr)_2)->base + _arg_64849);
        _1 = *(int *)_2;
        *(int *)_2 = _32555;
        if( _1 != _32555 ){
            DeRef(_1);
        }
        _32555 = NOVALUE;

        /** 			arg = SymTab[arg][S_NEXT]*/
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _32556 = (int)*(((s1_ptr)_2)->base + _arg_64849);
        _2 = (int)SEQ_PTR(_32556);
        _arg_64849 = (int)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_arg_64849)){
            _arg_64849 = (long)DBL_PTR(_arg_64849)->dbl;
        }
        _32556 = NOVALUE;

        /** 		end for*/
        _i_64876 = _i_64876 + 1;
        goto L2; // [168] 102
L3: 
        ;
    }

    /** 		while arg != 0 */
L4: 
    _32558 = (_arg_64849 != 0);
    if (_32558 == 0) {
        goto L5; // [182] 330
    }
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _32560 = (int)*(((s1_ptr)_2)->base + _arg_64849);
    _2 = (int)SEQ_PTR(_32560);
    _32561 = (int)*(((s1_ptr)_2)->base + 4);
    _32560 = NOVALUE;
    if (IS_ATOM_INT(_32561)) {
        _32562 = (_32561 <= 3);
    }
    else {
        _32562 = binary_op(LESSEQ, _32561, 3);
    }
    _32561 = NOVALUE;
    if (IS_ATOM_INT(_32562)) {
        if (_32562 != 0) {
            DeRef(_32563);
            _32563 = 1;
            goto L6; // [204] 230
        }
    }
    else {
        if (DBL_PTR(_32562)->dbl != 0.0) {
            DeRef(_32563);
            _32563 = 1;
            goto L6; // [204] 230
        }
    }
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _32564 = (int)*(((s1_ptr)_2)->base + _arg_64849);
    _2 = (int)SEQ_PTR(_32564);
    _32565 = (int)*(((s1_ptr)_2)->base + 4);
    _32564 = NOVALUE;
    if (IS_ATOM_INT(_32565)) {
        _32566 = (_32565 == 2);
    }
    else {
        _32566 = binary_op(EQUALS, _32565, 2);
    }
    _32565 = NOVALUE;
    DeRef(_32563);
    if (IS_ATOM_INT(_32566))
    _32563 = (_32566 != 0);
    else
    _32563 = DBL_PTR(_32566)->dbl != 0.0;
L6: 
    if (_32563 != 0) {
        DeRef(_32567);
        _32567 = 1;
        goto L7; // [230] 256
    }
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _32568 = (int)*(((s1_ptr)_2)->base + _arg_64849);
    _2 = (int)SEQ_PTR(_32568);
    _32569 = (int)*(((s1_ptr)_2)->base + 4);
    _32568 = NOVALUE;
    if (IS_ATOM_INT(_32569)) {
        _32570 = (_32569 == 9);
    }
    else {
        _32570 = binary_op(EQUALS, _32569, 9);
    }
    _32569 = NOVALUE;
    if (IS_ATOM_INT(_32570))
    _32567 = (_32570 != 0);
    else
    _32567 = DBL_PTR(_32570)->dbl != 0.0;
L7: 
    if (_32567 == 0)
    {
        _32567 = NOVALUE;
        goto L5; // [257] 330
    }
    else{
        _32567 = NOVALUE;
    }

    /** 			if SymTab[arg][S_SCOPE] != SC_UNDEFINED then*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _32571 = (int)*(((s1_ptr)_2)->base + _arg_64849);
    _2 = (int)SEQ_PTR(_32571);
    _32572 = (int)*(((s1_ptr)_2)->base + 4);
    _32571 = NOVALUE;
    if (binary_op_a(EQUALS, _32572, 9)){
        _32572 = NOVALUE;
        goto L8; // [276] 309
    }
    _32572 = NOVALUE;

    /** 				private_block[p] = val[arg]*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _32574 = (int)*(((s1_ptr)_2)->base + _arg_64849);
    Ref(_32574);
    _2 = (int)SEQ_PTR(_private_block_64852);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _private_block_64852 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _p_64851);
    _1 = *(int *)_2;
    *(int *)_2 = _32574;
    if( _1 != _32574 ){
        DeRef(_1);
    }
    _32574 = NOVALUE;

    /** 				p += 1*/
    _p_64851 = _p_64851 + 1;

    /** 				val[arg] = NOVALUE  -- necessary?*/
    Ref(_26NOVALUE_11836);
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _arg_64849);
    _1 = *(int *)_2;
    *(int *)_2 = _26NOVALUE_11836;
    DeRef(_1);
L8: 

    /** 			arg = SymTab[arg][S_NEXT]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _32576 = (int)*(((s1_ptr)_2)->base + _arg_64849);
    _2 = (int)SEQ_PTR(_32576);
    _arg_64849 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_arg_64849)){
        _arg_64849 = (long)DBL_PTR(_arg_64849)->dbl;
    }
    _32576 = NOVALUE;

    /** 		end while*/
    goto L4; // [327] 178
L5: 

    /** 		arg = SymTab[sub][S_TEMPS]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _32578 = (int)*(((s1_ptr)_2)->base + _sub_64850);
    _2 = (int)SEQ_PTR(_32578);
    if (!IS_ATOM_INT(_26S_TEMPS_11699)){
        _arg_64849 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_TEMPS_11699)->dbl));
    }
    else{
        _arg_64849 = (int)*(((s1_ptr)_2)->base + _26S_TEMPS_11699);
    }
    if (!IS_ATOM_INT(_arg_64849)){
        _arg_64849 = (long)DBL_PTR(_arg_64849)->dbl;
    }
    _32578 = NOVALUE;

    /** 		while arg != 0 do*/
L9: 
    if (_arg_64849 == 0)
    goto LA; // [351] 404

    /** 			private_block[p] = val[arg]*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _32581 = (int)*(((s1_ptr)_2)->base + _arg_64849);
    Ref(_32581);
    _2 = (int)SEQ_PTR(_private_block_64852);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _private_block_64852 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _p_64851);
    _1 = *(int *)_2;
    *(int *)_2 = _32581;
    if( _1 != _32581 ){
        DeRef(_1);
    }
    _32581 = NOVALUE;

    /** 			p += 1*/
    _p_64851 = _p_64851 + 1;

    /** 			val[arg] = NOVALUE -- necessary?*/
    Ref(_26NOVALUE_11836);
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _arg_64849);
    _1 = *(int *)_2;
    *(int *)_2 = _26NOVALUE_11836;
    DeRef(_1);

    /** 			arg = SymTab[arg][S_NEXT]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _32583 = (int)*(((s1_ptr)_2)->base + _arg_64849);
    _2 = (int)SEQ_PTR(_32583);
    _arg_64849 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_arg_64849)){
        _arg_64849 = (long)DBL_PTR(_arg_64849)->dbl;
    }
    _32583 = NOVALUE;

    /** 		end while*/
    goto L9; // [401] 351
LA: 

    /** 		save_private_block(sub, private_block)*/
    RefDS(_private_block_64852);
    _67save_private_block(_sub_64850, _private_block_64852);
    goto LB; // [410] 479
L1: 

    /** 		for i = 1 to n do*/
    _32585 = _n_64848;
    {
        int _i_64941;
        _i_64941 = 1;
LC: 
        if (_i_64941 > _32585){
            goto LD; // [418] 478
        }

        /** 			val[arg] = val[Code[pc+1+i]]*/
        _32586 = _67pc_63479 + 1;
        if (_32586 > MAXINT){
            _32586 = NewDouble((double)_32586);
        }
        if (IS_ATOM_INT(_32586)) {
            _32587 = _32586 + _i_64941;
        }
        else {
            _32587 = NewDouble(DBL_PTR(_32586)->dbl + (double)_i_64941);
        }
        DeRef(_32586);
        _32586 = NOVALUE;
        _2 = (int)SEQ_PTR(_26Code_12071);
        if (!IS_ATOM_INT(_32587)){
            _32588 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_32587)->dbl));
        }
        else{
            _32588 = (int)*(((s1_ptr)_2)->base + _32587);
        }
        _2 = (int)SEQ_PTR(_67val_63489);
        if (!IS_ATOM_INT(_32588)){
            _32589 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_32588)->dbl));
        }
        else{
            _32589 = (int)*(((s1_ptr)_2)->base + _32588);
        }
        Ref(_32589);
        _2 = (int)SEQ_PTR(_67val_63489);
        _2 = (int)(((s1_ptr)_2)->base + _arg_64849);
        _1 = *(int *)_2;
        *(int *)_2 = _32589;
        if( _1 != _32589 ){
            DeRef(_1);
        }
        _32589 = NOVALUE;

        /** 			arg = SymTab[arg][S_NEXT]*/
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _32590 = (int)*(((s1_ptr)_2)->base + _arg_64849);
        _2 = (int)SEQ_PTR(_32590);
        _arg_64849 = (int)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_arg_64849)){
            _arg_64849 = (long)DBL_PTR(_arg_64849)->dbl;
        }
        _32590 = NOVALUE;

        /** 		end for*/
        _i_64941 = _i_64941 + 1;
        goto LC; // [473] 425
LD: 
        ;
    }
LB: 

    /** 	SymTab[sub][S_RESIDENT_TASK] = current_task*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sub_64850 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 25);
    _1 = *(int *)_2;
    *(int *)_2 = _67current_task_63496;
    DeRef(_1);
    _32592 = NOVALUE;

    /** 	pc = pc + 2 + n*/
    _32594 = _67pc_63479 + 2;
    if ((long)((unsigned long)_32594 + (unsigned long)HIGH_BITS) >= 0) 
    _32594 = NewDouble((double)_32594);
    if (IS_ATOM_INT(_32594)) {
        _67pc_63479 = _32594 + _n_64848;
    }
    else {
        _67pc_63479 = NewDouble(DBL_PTR(_32594)->dbl + (double)_n_64848);
    }
    DeRef(_32594);
    _32594 = NOVALUE;
    if (!IS_ATOM_INT(_67pc_63479)) {
        _1 = (long)(DBL_PTR(_67pc_63479)->dbl);
        DeRefDS(_67pc_63479);
        _67pc_63479 = _1;
    }

    /** 	if SymTab[sub][S_TOKEN] != PROC then*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _32596 = (int)*(((s1_ptr)_2)->base + _sub_64850);
    _2 = (int)SEQ_PTR(_32596);
    if (!IS_ATOM_INT(_26S_TOKEN_11659)){
        _32597 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_TOKEN_11659)->dbl));
    }
    else{
        _32597 = (int)*(((s1_ptr)_2)->base + _26S_TOKEN_11659);
    }
    _32596 = NOVALUE;
    if (binary_op_a(EQUALS, _32597, 27)){
        _32597 = NOVALUE;
        goto LE; // [526] 539
    }
    _32597 = NOVALUE;

    /** 		pc += 1*/
    _67pc_63479 = _67pc_63479 + 1;
LE: 

    /** 	call_stack = append(call_stack, pc)*/
    Append(&_67call_stack_63497, _67call_stack_63497, _67pc_63479);

    /** 	call_stack = append(call_stack, sub)*/
    Append(&_67call_stack_63497, _67call_stack_63497, _sub_64850);

    /** 	Code = SymTab[sub][S_CODE]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _32602 = (int)*(((s1_ptr)_2)->base + _sub_64850);
    DeRef(_26Code_12071);
    _2 = (int)SEQ_PTR(_32602);
    if (!IS_ATOM_INT(_26S_CODE_11666)){
        _26Code_12071 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_CODE_11666)->dbl));
    }
    else{
        _26Code_12071 = (int)*(((s1_ptr)_2)->base + _26S_CODE_11666);
    }
    Ref(_26Code_12071);
    _32602 = NOVALUE;

    /** 	pc = 1*/
    _67pc_63479 = 1;

    /** end procedure*/
    DeRef(_private_block_64852);
    DeRef(_32537);
    _32537 = NOVALUE;
    _32554 = NOVALUE;
    DeRef(_32553);
    _32553 = NOVALUE;
    DeRef(_32558);
    _32558 = NOVALUE;
    _32588 = NOVALUE;
    DeRef(_32562);
    _32562 = NOVALUE;
    DeRef(_32566);
    _32566 = NOVALUE;
    DeRef(_32570);
    _32570 = NOVALUE;
    DeRef(_32587);
    _32587 = NOVALUE;
    return;
    ;
}


void _67exit_block(int _block_64978)
{
    int _a_64979 = NOVALUE;
    int _32607 = NOVALUE;
    int _32604 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_block_64978)) {
        _1 = (long)(DBL_PTR(_block_64978)->dbl);
        DeRefDS(_block_64978);
        _block_64978 = _1;
    }

    /** 	integer a = SymTab[block][S_NEXT_IN_BLOCK]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _32604 = (int)*(((s1_ptr)_2)->base + _block_64978);
    _2 = (int)SEQ_PTR(_32604);
    if (!IS_ATOM_INT(_26S_NEXT_IN_BLOCK_11646)){
        _a_64979 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NEXT_IN_BLOCK_11646)->dbl));
    }
    else{
        _a_64979 = (int)*(((s1_ptr)_2)->base + _26S_NEXT_IN_BLOCK_11646);
    }
    if (!IS_ATOM_INT(_a_64979)){
        _a_64979 = (long)DBL_PTR(_a_64979)->dbl;
    }
    _32604 = NOVALUE;

    /** 	while a do*/
L1: 
    if (_a_64979 == 0)
    {
        goto L2; // [24] 60
    }
    else{
    }

    /** 		ifdef DEBUG then*/

    /** 		val[a] = NOVALUE*/
    Ref(_26NOVALUE_11836);
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _a_64979);
    _1 = *(int *)_2;
    *(int *)_2 = _26NOVALUE_11836;
    DeRef(_1);

    /** 		a = SymTab[a][S_NEXT_IN_BLOCK]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _32607 = (int)*(((s1_ptr)_2)->base + _a_64979);
    _2 = (int)SEQ_PTR(_32607);
    if (!IS_ATOM_INT(_26S_NEXT_IN_BLOCK_11646)){
        _a_64979 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NEXT_IN_BLOCK_11646)->dbl));
    }
    else{
        _a_64979 = (int)*(((s1_ptr)_2)->base + _26S_NEXT_IN_BLOCK_11646);
    }
    if (!IS_ATOM_INT(_a_64979)){
        _a_64979 = (long)DBL_PTR(_a_64979)->dbl;
    }
    _32607 = NOVALUE;

    /** 	end while*/
    goto L1; // [57] 24
L2: 

    /** end procedure*/
    return;
    ;
}


void _67opEXIT_BLOCK()
{
    int _32610 = NOVALUE;
    int _32609 = NOVALUE;
    int _0, _1, _2;
    

    /** 	exit_block( Code[pc+1] )*/
    _32609 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _32610 = (int)*(((s1_ptr)_2)->base + _32609);
    Ref(_32610);
    _67exit_block(_32610);
    _32610 = NOVALUE;

    /** 	pc += 2*/
    _67pc_63479 = _67pc_63479 + 2;

    /** end procedure*/
    _32609 = NOVALUE;
    return;
    ;
}


void _67opRETURNP()
{
    int _arg_65000 = NOVALUE;
    int _sub_65001 = NOVALUE;
    int _caller_65002 = NOVALUE;
    int _op_65003 = NOVALUE;
    int _block_65010 = NOVALUE;
    int _sub_block_65015 = NOVALUE;
    int _local_result_65020 = NOVALUE;
    int _local_result_val_65021 = NOVALUE;
    int _32635 = NOVALUE;
    int _32633 = NOVALUE;
    int _32631 = NOVALUE;
    int _32630 = NOVALUE;
    int _32628 = NOVALUE;
    int _32626 = NOVALUE;
    int _32625 = NOVALUE;
    int _32623 = NOVALUE;
    int _32622 = NOVALUE;
    int _32620 = NOVALUE;
    int _32617 = NOVALUE;
    int _32615 = NOVALUE;
    int _32613 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	integer op = Code[pc]*/
    _2 = (int)SEQ_PTR(_26Code_12071);
    _op_65003 = (int)*(((s1_ptr)_2)->base + _67pc_63479);
    if (!IS_ATOM_INT(_op_65003)){
        _op_65003 = (long)DBL_PTR(_op_65003)->dbl;
    }

    /** 	sub = Code[pc+1]*/
    _32613 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _sub_65001 = (int)*(((s1_ptr)_2)->base + _32613);
    if (!IS_ATOM_INT(_sub_65001)){
        _sub_65001 = (long)DBL_PTR(_sub_65001)->dbl;
    }

    /** 	symtab_index block = Code[pc+2]*/
    _32615 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _block_65010 = (int)*(((s1_ptr)_2)->base + _32615);
    if (!IS_ATOM_INT(_block_65010)){
        _block_65010 = (long)DBL_PTR(_block_65010)->dbl;
    }

    /** 	symtab_index sub_block = SymTab[sub][S_BLOCK]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _32617 = (int)*(((s1_ptr)_2)->base + _sub_65001);
    _2 = (int)SEQ_PTR(_32617);
    if (!IS_ATOM_INT(_26S_BLOCK_11674)){
        _sub_block_65015 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_BLOCK_11674)->dbl));
    }
    else{
        _sub_block_65015 = (int)*(((s1_ptr)_2)->base + _26S_BLOCK_11674);
    }
    if (!IS_ATOM_INT(_sub_block_65015)){
        _sub_block_65015 = (long)DBL_PTR(_sub_block_65015)->dbl;
    }
    _32617 = NOVALUE;

    /** 	integer local_result = result*/
    _local_result_65020 = _67result_64973;

    /** 	object local_result_val*/

    /** 	if local_result then*/
    if (_local_result_65020 == 0)
    {
        goto L1; // [72] 95
    }
    else{
    }

    /** 		result = 0*/
    _67result_64973 = 0;

    /** 		local_result_val = result_val*/
    Ref(_67result_val_64974);
    DeRef(_local_result_val_65021);
    _local_result_val_65021 = _67result_val_64974;

    /** 		result_val = NOVALUE*/
    Ref(_26NOVALUE_11836);
    DeRef(_67result_val_64974);
    _67result_val_64974 = _26NOVALUE_11836;
L1: 

    /** 	while block != sub_block do*/
L2: 
    if (_block_65010 == _sub_block_65015)
    goto L3; // [100] 136

    /** 		if local_result then*/
    if (_local_result_65020 == 0)
    {
        goto L4; // [106] 115
    }
    else{
    }

    /** 			exit_block( block )*/
    _67exit_block(_block_65010);
L4: 

    /** 		block = SymTab[block][S_BLOCK]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _32620 = (int)*(((s1_ptr)_2)->base + _block_65010);
    _2 = (int)SEQ_PTR(_32620);
    if (!IS_ATOM_INT(_26S_BLOCK_11674)){
        _block_65010 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_BLOCK_11674)->dbl));
    }
    else{
        _block_65010 = (int)*(((s1_ptr)_2)->base + _26S_BLOCK_11674);
    }
    if (!IS_ATOM_INT(_block_65010)){
        _block_65010 = (long)DBL_PTR(_block_65010)->dbl;
    }
    _32620 = NOVALUE;

    /** 	end while*/
    goto L2; // [133] 100
L3: 

    /** 	exit_block( sub_block )*/
    _67exit_block(_sub_block_65015);

    /** 	pc = call_stack[$-1]*/
    if (IS_SEQUENCE(_67call_stack_63497)){
            _32622 = SEQ_PTR(_67call_stack_63497)->length;
    }
    else {
        _32622 = 1;
    }
    _32623 = _32622 - 1;
    _32622 = NOVALUE;
    _2 = (int)SEQ_PTR(_67call_stack_63497);
    _67pc_63479 = (int)*(((s1_ptr)_2)->base + _32623);
    if (!IS_ATOM_INT(_67pc_63479))
    _67pc_63479 = (long)DBL_PTR(_67pc_63479)->dbl;

    /** 	call_stack = call_stack[1..$-2]*/
    if (IS_SEQUENCE(_67call_stack_63497)){
            _32625 = SEQ_PTR(_67call_stack_63497)->length;
    }
    else {
        _32625 = 1;
    }
    _32626 = _32625 - 2;
    _32625 = NOVALUE;
    rhs_slice_target = (object_ptr)&_67call_stack_63497;
    RHS_Slice(_67call_stack_63497, 1, _32626);

    /** 	SymTab[sub][S_RESIDENT_TASK] = 0*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sub_65001 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 25);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _32628 = NOVALUE;

    /** 	if length(call_stack) then*/
    if (IS_SEQUENCE(_67call_stack_63497)){
            _32630 = SEQ_PTR(_67call_stack_63497)->length;
    }
    else {
        _32630 = 1;
    }
    if (_32630 == 0)
    {
        _32630 = NOVALUE;
        goto L5; // [194] 256
    }
    else{
        _32630 = NOVALUE;
    }

    /** 		caller = call_stack[$]*/
    if (IS_SEQUENCE(_67call_stack_63497)){
            _32631 = SEQ_PTR(_67call_stack_63497)->length;
    }
    else {
        _32631 = 1;
    }
    _2 = (int)SEQ_PTR(_67call_stack_63497);
    _caller_65002 = (int)*(((s1_ptr)_2)->base + _32631);
    if (!IS_ATOM_INT(_caller_65002)){
        _caller_65002 = (long)DBL_PTR(_caller_65002)->dbl;
    }

    /** 		Code = SymTab[caller][S_CODE]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _32633 = (int)*(((s1_ptr)_2)->base + _caller_65002);
    DeRef(_26Code_12071);
    _2 = (int)SEQ_PTR(_32633);
    if (!IS_ATOM_INT(_26S_CODE_11666)){
        _26Code_12071 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_CODE_11666)->dbl));
    }
    else{
        _26Code_12071 = (int)*(((s1_ptr)_2)->base + _26S_CODE_11666);
    }
    Ref(_26Code_12071);
    _32633 = NOVALUE;

    /** 		restore_privates(caller)*/
    _67restore_privates(_caller_65002);

    /** 		if local_result then*/
    if (_local_result_65020 == 0)
    {
        goto L6; // [233] 268
    }
    else{
    }

    /** 			val[Code[local_result]] = local_result_val*/
    _2 = (int)SEQ_PTR(_26Code_12071);
    _32635 = (int)*(((s1_ptr)_2)->base + _local_result_65020);
    Ref(_local_result_val_65021);
    _2 = (int)SEQ_PTR(_67val_63489);
    if (!IS_ATOM_INT(_32635))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_32635)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _32635);
    _1 = *(int *)_2;
    *(int *)_2 = _local_result_val_65021;
    DeRef(_1);
    goto L6; // [253] 268
L5: 

    /** 		kill_task(current_task)*/
    _67kill_task(_67current_task_63496);

    /** 		scheduler()*/
    _67scheduler();
L6: 

    /** end procedure*/
    DeRef(_local_result_val_65021);
    DeRef(_32613);
    _32613 = NOVALUE;
    DeRef(_32615);
    _32615 = NOVALUE;
    DeRef(_32623);
    _32623 = NOVALUE;
    DeRef(_32626);
    _32626 = NOVALUE;
    _32635 = NOVALUE;
    return;
    ;
}


void _67opRETURNF()
{
    int _32641 = NOVALUE;
    int _32640 = NOVALUE;
    int _32639 = NOVALUE;
    int _32637 = NOVALUE;
    int _32636 = NOVALUE;
    int _0, _1, _2;
    

    /** 	result_val = val[Code[pc+3]]*/
    _32636 = _67pc_63479 + 3;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _32637 = (int)*(((s1_ptr)_2)->base + _32636);
    DeRef(_67result_val_64974);
    _2 = (int)SEQ_PTR(_67val_63489);
    if (!IS_ATOM_INT(_32637)){
        _67result_val_64974 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_32637)->dbl));
    }
    else{
        _67result_val_64974 = (int)*(((s1_ptr)_2)->base + _32637);
    }
    Ref(_67result_val_64974);

    /** 	result = call_stack[$-1] - 1*/
    if (IS_SEQUENCE(_67call_stack_63497)){
            _32639 = SEQ_PTR(_67call_stack_63497)->length;
    }
    else {
        _32639 = 1;
    }
    _32640 = _32639 - 1;
    _32639 = NOVALUE;
    _2 = (int)SEQ_PTR(_67call_stack_63497);
    _32641 = (int)*(((s1_ptr)_2)->base + _32640);
    if (IS_ATOM_INT(_32641)) {
        _67result_64973 = _32641 - 1;
    }
    else {
        _67result_64973 = binary_op(MINUS, _32641, 1);
    }
    _32641 = NOVALUE;
    if (!IS_ATOM_INT(_67result_64973)) {
        _1 = (long)(DBL_PTR(_67result_64973)->dbl);
        DeRefDS(_67result_64973);
        _67result_64973 = _1;
    }

    /** 	opRETURNP()*/
    _67opRETURNP();

    /** end procedure*/
    _32636 = NOVALUE;
    _32637 = NOVALUE;
    _32640 = NOVALUE;
    return;
    ;
}


void _67opCALL_BACK_RETURN()
{
    int _0, _1, _2;
    

    /** 	keep_running = FALSE*/
    _67keep_running_63486 = _9FALSE_428;

    /** end procedure*/
    return;
    ;
}


void _67opBADRETURNF()
{
    int _0, _1, _2;
    

    /** 	RTFatal("attempt to exit a function without returning a value")*/
    RefDS(_32643);
    _67RTFatal(_32643);

    /** end procedure*/
    return;
    ;
}


void _67opRETURNT()
{
    int _32645 = NOVALUE;
    int _0, _1, _2;
    

    /** 	pc += 1*/
    _67pc_63479 = _67pc_63479 + 1;

    /** 	if pc > length(Code) then*/
    if (IS_SEQUENCE(_26Code_12071)){
            _32645 = SEQ_PTR(_26Code_12071)->length;
    }
    else {
        _32645 = 1;
    }
    if (_67pc_63479 <= _32645)
    goto L1; // [18] 32

    /** 		keep_running = FALSE  -- we've reached the end of the code*/
    _67keep_running_63486 = _9FALSE_428;
L1: 

    /** end procedure*/
    return;
    ;
}


void _67opRHS_SUBS()
{
    int _sub_65080 = NOVALUE;
    int _x_65081 = NOVALUE;
    int _32668 = NOVALUE;
    int _32667 = NOVALUE;
    int _32666 = NOVALUE;
    int _32665 = NOVALUE;
    int _32663 = NOVALUE;
    int _32662 = NOVALUE;
    int _32660 = NOVALUE;
    int _32657 = NOVALUE;
    int _32655 = NOVALUE;
    int _32651 = NOVALUE;
    int _32649 = NOVALUE;
    int _32647 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _32647 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _32647);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _32649 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67b_63481 = (int)*(((s1_ptr)_2)->base + _32649);
    if (!IS_ATOM_INT(_67b_63481)){
        _67b_63481 = (long)DBL_PTR(_67b_63481)->dbl;
    }

    /** 	target = Code[pc+3]*/
    _32651 = _67pc_63479 + 3;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67target_63484 = (int)*(((s1_ptr)_2)->base + _32651);
    if (!IS_ATOM_INT(_67target_63484)){
        _67target_63484 = (long)DBL_PTR(_67target_63484)->dbl;
    }

    /** 	x = val[a]*/
    DeRef(_x_65081);
    _2 = (int)SEQ_PTR(_67val_63489);
    _x_65081 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    Ref(_x_65081);

    /** 	sub = val[b]*/
    DeRef(_sub_65080);
    _2 = (int)SEQ_PTR(_67val_63489);
    _sub_65080 = (int)*(((s1_ptr)_2)->base + _67b_63481);
    Ref(_sub_65080);

    /** 	if atom(x) then*/
    _32655 = IS_ATOM(_x_65081);
    if (_32655 == 0)
    {
        _32655 = NOVALUE;
        goto L1; // [74] 83
    }
    else{
        _32655 = NOVALUE;
    }

    /** 		RTFatal("attempt to subscript an atom\n(reading from it)")*/
    RefDS(_32656);
    _67RTFatal(_32656);
L1: 

    /** 	if sequence(sub) then*/
    _32657 = IS_SEQUENCE(_sub_65080);
    if (_32657 == 0)
    {
        _32657 = NOVALUE;
        goto L2; // [88] 97
    }
    else{
        _32657 = NOVALUE;
    }

    /** 		RTFatal("subscript must be an atom\n(reading an element of a sequence)")*/
    RefDS(_32658);
    _67RTFatal(_32658);
L2: 

    /** 	sub = floor(sub)*/
    _0 = _sub_65080;
    if (IS_ATOM_INT(_sub_65080))
    _sub_65080 = e_floor(_sub_65080);
    else
    _sub_65080 = unary_op(FLOOR, _sub_65080);
    DeRef(_0);

    /** 	if sub < 1 or sub > length(x) then*/
    if (IS_ATOM_INT(_sub_65080)) {
        _32660 = (_sub_65080 < 1);
    }
    else {
        _32660 = (DBL_PTR(_sub_65080)->dbl < (double)1);
    }
    if (_32660 != 0) {
        goto L3; // [108] 124
    }
    if (IS_SEQUENCE(_x_65081)){
            _32662 = SEQ_PTR(_x_65081)->length;
    }
    else {
        _32662 = 1;
    }
    if (IS_ATOM_INT(_sub_65080)) {
        _32663 = (_sub_65080 > _32662);
    }
    else {
        _32663 = (DBL_PTR(_sub_65080)->dbl > (double)_32662);
    }
    _32662 = NOVALUE;
    if (_32663 == 0)
    {
        DeRef(_32663);
        _32663 = NOVALUE;
        goto L4; // [120] 141
    }
    else{
        DeRef(_32663);
        _32663 = NOVALUE;
    }
L3: 

    /** 		RTFatal(*/
    if (IS_SEQUENCE(_x_65081)){
            _32665 = SEQ_PTR(_x_65081)->length;
    }
    else {
        _32665 = 1;
    }
    Ref(_sub_65080);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _sub_65080;
    ((int *)_2)[2] = _32665;
    _32666 = MAKE_SEQ(_1);
    _32665 = NOVALUE;
    _32667 = EPrintf(-9999999, _32664, _32666);
    DeRefDS(_32666);
    _32666 = NOVALUE;
    _67RTFatal(_32667);
    _32667 = NOVALUE;
L4: 

    /** 	val[target] = x[sub]*/
    _2 = (int)SEQ_PTR(_x_65081);
    if (!IS_ATOM_INT(_sub_65080)){
        _32668 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_sub_65080)->dbl));
    }
    else{
        _32668 = (int)*(((s1_ptr)_2)->base + _sub_65080);
    }
    Ref(_32668);
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63484);
    _1 = *(int *)_2;
    *(int *)_2 = _32668;
    if( _1 != _32668 ){
        DeRef(_1);
    }
    _32668 = NOVALUE;

    /** 	pc += 4*/
    _67pc_63479 = _67pc_63479 + 4;

    /** end procedure*/
    DeRef(_sub_65080);
    DeRef(_x_65081);
    DeRef(_32647);
    _32647 = NOVALUE;
    DeRef(_32649);
    _32649 = NOVALUE;
    DeRef(_32651);
    _32651 = NOVALUE;
    DeRef(_32660);
    _32660 = NOVALUE;
    return;
    ;
}


void _67opGOTO()
{
    int _32670 = NOVALUE;
    int _0, _1, _2;
    

    /** 	pc = Code[pc+1]*/
    _32670 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67pc_63479 = (int)*(((s1_ptr)_2)->base + _32670);
    if (!IS_ATOM_INT(_67pc_63479)){
        _67pc_63479 = (long)DBL_PTR(_67pc_63479)->dbl;
    }

    /** end procedure*/
    _32670 = NOVALUE;
    return;
    ;
}


void _67opGLABEL()
{
    int _32672 = NOVALUE;
    int _0, _1, _2;
    

    /** 	pc = Code[pc+1]*/
    _32672 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67pc_63479 = (int)*(((s1_ptr)_2)->base + _32672);
    if (!IS_ATOM_INT(_67pc_63479)){
        _67pc_63479 = (long)DBL_PTR(_67pc_63479)->dbl;
    }

    /** end procedure*/
    _32672 = NOVALUE;
    return;
    ;
}


void _67opIF()
{
    int _32678 = NOVALUE;
    int _32676 = NOVALUE;
    int _32674 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _32674 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _32674);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	if val[a] = 0 then*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _32676 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    if (binary_op_a(NOTEQ, _32676, 0)){
        _32676 = NOVALUE;
        goto L1; // [27] 50
    }
    _32676 = NOVALUE;

    /** 		pc = Code[pc+2]*/
    _32678 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67pc_63479 = (int)*(((s1_ptr)_2)->base + _32678);
    if (!IS_ATOM_INT(_67pc_63479)){
        _67pc_63479 = (long)DBL_PTR(_67pc_63479)->dbl;
    }
    goto L2; // [47] 59
L1: 

    /** 		pc += 3*/
    _67pc_63479 = _67pc_63479 + 3;
L2: 

    /** end procedure*/
    DeRef(_32674);
    _32674 = NOVALUE;
    DeRef(_32678);
    _32678 = NOVALUE;
    return;
    ;
}


void _67opINTEGER_CHECK()
{
    int _32686 = NOVALUE;
    int _32684 = NOVALUE;
    int _32683 = NOVALUE;
    int _32681 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _32681 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _32681);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	if not integer(val[a]) then*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _32683 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    if (IS_ATOM_INT(_32683))
    _32684 = 1;
    else if (IS_ATOM_DBL(_32683))
    _32684 = IS_ATOM_INT(DoubleToInt(_32683));
    else
    _32684 = 0;
    _32683 = NOVALUE;
    if (_32684 != 0)
    goto L1; // [30] 45
    _32684 = NOVALUE;

    /** 		RTFatalType(pc+1)*/
    _32686 = _67pc_63479 + 1;
    if (_32686 > MAXINT){
        _32686 = NewDouble((double)_32686);
    }
    _67RTFatalType(_32686);
    _32686 = NOVALUE;
L1: 

    /** 	pc += 2*/
    _67pc_63479 = _67pc_63479 + 2;

    /** end procedure*/
    DeRef(_32681);
    _32681 = NOVALUE;
    return;
    ;
}


void _67opATOM_CHECK()
{
    int _32693 = NOVALUE;
    int _32691 = NOVALUE;
    int _32690 = NOVALUE;
    int _32688 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _32688 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _32688);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	if not atom(val[a]) then*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _32690 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    _32691 = IS_ATOM(_32690);
    _32690 = NOVALUE;
    if (_32691 != 0)
    goto L1; // [30] 45
    _32691 = NOVALUE;

    /** 		RTFatalType(pc+1)*/
    _32693 = _67pc_63479 + 1;
    if (_32693 > MAXINT){
        _32693 = NewDouble((double)_32693);
    }
    _67RTFatalType(_32693);
    _32693 = NOVALUE;
L1: 

    /** 	pc += 2*/
    _67pc_63479 = _67pc_63479 + 2;

    /** end procedure*/
    DeRef(_32688);
    _32688 = NOVALUE;
    return;
    ;
}


void _67opSEQUENCE_CHECK()
{
    int _32700 = NOVALUE;
    int _32698 = NOVALUE;
    int _32697 = NOVALUE;
    int _32695 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _32695 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _32695);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	if not sequence(val[a]) then*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _32697 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    _32698 = IS_SEQUENCE(_32697);
    _32697 = NOVALUE;
    if (_32698 != 0)
    goto L1; // [30] 45
    _32698 = NOVALUE;

    /** 		RTFatalType(pc+1)*/
    _32700 = _67pc_63479 + 1;
    if (_32700 > MAXINT){
        _32700 = NewDouble((double)_32700);
    }
    _67RTFatalType(_32700);
    _32700 = NOVALUE;
L1: 

    /** 	pc += 2*/
    _67pc_63479 = _67pc_63479 + 2;

    /** end procedure*/
    DeRef(_32695);
    _32695 = NOVALUE;
    return;
    ;
}


void _67opASSIGN()
{
    int _a_65169 = NOVALUE;
    int _32707 = NOVALUE;
    int _32706 = NOVALUE;
    int _32704 = NOVALUE;
    int _32702 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer a = Code[pc+1]*/
    _32702 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _a_65169 = (int)*(((s1_ptr)_2)->base + _32702);
    if (!IS_ATOM_INT(_a_65169)){
        _a_65169 = (long)DBL_PTR(_a_65169)->dbl;
    }

    /** 	target = Code[pc+2]*/
    _32704 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67target_63484 = (int)*(((s1_ptr)_2)->base + _32704);
    if (!IS_ATOM_INT(_67target_63484)){
        _67target_63484 = (long)DBL_PTR(_67target_63484)->dbl;
    }

    /** 	val[target] = val[a]*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _32706 = (int)*(((s1_ptr)_2)->base + _a_65169);
    Ref(_32706);
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63484);
    _1 = *(int *)_2;
    *(int *)_2 = _32706;
    if( _1 != _32706 ){
        DeRef(_1);
    }
    _32706 = NOVALUE;

    /** 	if sym_mode( a ) = M_TEMP then*/
    _32707 = _52sym_mode(_a_65169);
    if (binary_op_a(NOTEQ, _32707, 3)){
        DeRef(_32707);
        _32707 = NOVALUE;
        goto L1; // [57] 72
    }
    DeRef(_32707);
    _32707 = NOVALUE;

    /** 		val[a] = NOVALUE*/
    Ref(_26NOVALUE_11836);
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _a_65169);
    _1 = *(int *)_2;
    *(int *)_2 = _26NOVALUE_11836;
    DeRef(_1);
L1: 

    /** 	pc += 3*/
    _67pc_63479 = _67pc_63479 + 3;

    /** end procedure*/
    DeRef(_32702);
    _32702 = NOVALUE;
    DeRef(_32704);
    _32704 = NOVALUE;
    return;
    ;
}


void _67opELSE()
{
    int _32710 = NOVALUE;
    int _0, _1, _2;
    

    /** 	pc = Code[pc+1]*/
    _32710 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67pc_63479 = (int)*(((s1_ptr)_2)->base + _32710);
    if (!IS_ATOM_INT(_67pc_63479)){
        _67pc_63479 = (long)DBL_PTR(_67pc_63479)->dbl;
    }

    /** end procedure*/
    _32710 = NOVALUE;
    return;
    ;
}


void _67opRIGHT_BRACE_N()
{
    int _x_65191 = NOVALUE;
    int _32727 = NOVALUE;
    int _32725 = NOVALUE;
    int _32724 = NOVALUE;
    int _32723 = NOVALUE;
    int _32721 = NOVALUE;
    int _32720 = NOVALUE;
    int _32718 = NOVALUE;
    int _32717 = NOVALUE;
    int _32716 = NOVALUE;
    int _32715 = NOVALUE;
    int _32714 = NOVALUE;
    int _32712 = NOVALUE;
    int _0, _1, _2;
    

    /** 	len = Code[pc+1]*/
    _32712 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67len_63485 = (int)*(((s1_ptr)_2)->base + _32712);
    if (!IS_ATOM_INT(_67len_63485)){
        _67len_63485 = (long)DBL_PTR(_67len_63485)->dbl;
    }

    /** 	x = {}*/
    RefDS(_22037);
    DeRef(_x_65191);
    _x_65191 = _22037;

    /** 	for i = pc+len+1 to pc+2 by -1 do*/
    _32714 = _67pc_63479 + _67len_63485;
    if ((long)((unsigned long)_32714 + (unsigned long)HIGH_BITS) >= 0) 
    _32714 = NewDouble((double)_32714);
    if (IS_ATOM_INT(_32714)) {
        _32715 = _32714 + 1;
        if (_32715 > MAXINT){
            _32715 = NewDouble((double)_32715);
        }
    }
    else
    _32715 = binary_op(PLUS, 1, _32714);
    DeRef(_32714);
    _32714 = NOVALUE;
    _32716 = _67pc_63479 + 2;
    if ((long)((unsigned long)_32716 + (unsigned long)HIGH_BITS) >= 0) 
    _32716 = NewDouble((double)_32716);
    {
        int _i_65196;
        Ref(_32715);
        _i_65196 = _32715;
L1: 
        if (binary_op_a(LESS, _i_65196, _32716)){
            goto L2; // [44] 111
        }

        /** 		x = append(x, val[Code[i]])*/
        _2 = (int)SEQ_PTR(_26Code_12071);
        if (!IS_ATOM_INT(_i_65196)){
            _32717 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_65196)->dbl));
        }
        else{
            _32717 = (int)*(((s1_ptr)_2)->base + _i_65196);
        }
        _2 = (int)SEQ_PTR(_67val_63489);
        if (!IS_ATOM_INT(_32717)){
            _32718 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_32717)->dbl));
        }
        else{
            _32718 = (int)*(((s1_ptr)_2)->base + _32717);
        }
        Ref(_32718);
        Append(&_x_65191, _x_65191, _32718);
        _32718 = NOVALUE;

        /** 		if sym_mode( Code[i] ) = M_TEMP then*/
        _2 = (int)SEQ_PTR(_26Code_12071);
        if (!IS_ATOM_INT(_i_65196)){
            _32720 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_65196)->dbl));
        }
        else{
            _32720 = (int)*(((s1_ptr)_2)->base + _i_65196);
        }
        Ref(_32720);
        _32721 = _52sym_mode(_32720);
        _32720 = NOVALUE;
        if (binary_op_a(NOTEQ, _32721, 3)){
            DeRef(_32721);
            _32721 = NOVALUE;
            goto L3; // [83] 104
        }
        DeRef(_32721);
        _32721 = NOVALUE;

        /** 			val[Code[i]] = NOVALUE*/
        _2 = (int)SEQ_PTR(_26Code_12071);
        if (!IS_ATOM_INT(_i_65196)){
            _32723 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_65196)->dbl));
        }
        else{
            _32723 = (int)*(((s1_ptr)_2)->base + _i_65196);
        }
        Ref(_26NOVALUE_11836);
        _2 = (int)SEQ_PTR(_67val_63489);
        if (!IS_ATOM_INT(_32723))
        _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_32723)->dbl));
        else
        _2 = (int)(((s1_ptr)_2)->base + _32723);
        _1 = *(int *)_2;
        *(int *)_2 = _26NOVALUE_11836;
        DeRef(_1);
L3: 

        /** 	end for*/
        _0 = _i_65196;
        if (IS_ATOM_INT(_i_65196)) {
            _i_65196 = _i_65196 + -1;
            if ((long)((unsigned long)_i_65196 +(unsigned long) HIGH_BITS) >= 0){
                _i_65196 = NewDouble((double)_i_65196);
            }
        }
        else {
            _i_65196 = binary_op_a(PLUS, _i_65196, -1);
        }
        DeRef(_0);
        goto L1; // [106] 51
L2: 
        ;
        DeRef(_i_65196);
    }

    /** 	target = Code[pc+len+2]*/
    _32724 = _67pc_63479 + _67len_63485;
    if ((long)((unsigned long)_32724 + (unsigned long)HIGH_BITS) >= 0) 
    _32724 = NewDouble((double)_32724);
    if (IS_ATOM_INT(_32724)) {
        _32725 = _32724 + 2;
    }
    else {
        _32725 = NewDouble(DBL_PTR(_32724)->dbl + (double)2);
    }
    DeRef(_32724);
    _32724 = NOVALUE;
    _2 = (int)SEQ_PTR(_26Code_12071);
    if (!IS_ATOM_INT(_32725)){
        _67target_63484 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_32725)->dbl));
    }
    else{
        _67target_63484 = (int)*(((s1_ptr)_2)->base + _32725);
    }
    if (!IS_ATOM_INT(_67target_63484)){
        _67target_63484 = (long)DBL_PTR(_67target_63484)->dbl;
    }

    /** 	val[target] = x*/
    RefDS(_x_65191);
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63484);
    _1 = *(int *)_2;
    *(int *)_2 = _x_65191;
    DeRef(_1);

    /** 	pc += 3 + len*/
    _32727 = 3 + _67len_63485;
    if ((long)((unsigned long)_32727 + (unsigned long)HIGH_BITS) >= 0) 
    _32727 = NewDouble((double)_32727);
    if (IS_ATOM_INT(_32727)) {
        _67pc_63479 = _67pc_63479 + _32727;
    }
    else {
        _67pc_63479 = NewDouble((double)_67pc_63479 + DBL_PTR(_32727)->dbl);
    }
    DeRef(_32727);
    _32727 = NOVALUE;
    if (!IS_ATOM_INT(_67pc_63479)) {
        _1 = (long)(DBL_PTR(_67pc_63479)->dbl);
        DeRefDS(_67pc_63479);
        _67pc_63479 = _1;
    }

    /** end procedure*/
    DeRefDS(_x_65191);
    DeRef(_32712);
    _32712 = NOVALUE;
    DeRef(_32716);
    _32716 = NOVALUE;
    DeRef(_32715);
    _32715 = NOVALUE;
    _32717 = NOVALUE;
    _32723 = NOVALUE;
    DeRef(_32725);
    _32725 = NOVALUE;
    return;
    ;
}


void _67opRIGHT_BRACE_2()
{
    int _32749 = NOVALUE;
    int _32748 = NOVALUE;
    int _32746 = NOVALUE;
    int _32745 = NOVALUE;
    int _32744 = NOVALUE;
    int _32743 = NOVALUE;
    int _32742 = NOVALUE;
    int _32740 = NOVALUE;
    int _32739 = NOVALUE;
    int _32738 = NOVALUE;
    int _32737 = NOVALUE;
    int _32736 = NOVALUE;
    int _32735 = NOVALUE;
    int _32734 = NOVALUE;
    int _32733 = NOVALUE;
    int _32732 = NOVALUE;
    int _32731 = NOVALUE;
    int _32729 = NOVALUE;
    int _0, _1, _2;
    

    /** 	target = Code[pc+3]*/
    _32729 = _67pc_63479 + 3;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67target_63484 = (int)*(((s1_ptr)_2)->base + _32729);
    if (!IS_ATOM_INT(_67target_63484)){
        _67target_63484 = (long)DBL_PTR(_67target_63484)->dbl;
    }

    /** 	val[target] = {val[Code[pc+2]], val[Code[pc+1]]}*/
    _32731 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _32732 = (int)*(((s1_ptr)_2)->base + _32731);
    _2 = (int)SEQ_PTR(_67val_63489);
    if (!IS_ATOM_INT(_32732)){
        _32733 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_32732)->dbl));
    }
    else{
        _32733 = (int)*(((s1_ptr)_2)->base + _32732);
    }
    _32734 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _32735 = (int)*(((s1_ptr)_2)->base + _32734);
    _2 = (int)SEQ_PTR(_67val_63489);
    if (!IS_ATOM_INT(_32735)){
        _32736 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_32735)->dbl));
    }
    else{
        _32736 = (int)*(((s1_ptr)_2)->base + _32735);
    }
    Ref(_32736);
    Ref(_32733);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _32733;
    ((int *)_2)[2] = _32736;
    _32737 = MAKE_SEQ(_1);
    _32736 = NOVALUE;
    _32733 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63484);
    _1 = *(int *)_2;
    *(int *)_2 = _32737;
    if( _1 != _32737 ){
        DeRef(_1);
    }
    _32737 = NOVALUE;

    /** 	if sym_mode( Code[pc+2] ) = M_TEMP then*/
    _32738 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _32739 = (int)*(((s1_ptr)_2)->base + _32738);
    Ref(_32739);
    _32740 = _52sym_mode(_32739);
    _32739 = NOVALUE;
    if (binary_op_a(NOTEQ, _32740, 3)){
        DeRef(_32740);
        _32740 = NOVALUE;
        goto L1; // [87] 114
    }
    DeRef(_32740);
    _32740 = NOVALUE;

    /** 		val[Code[pc+2]] = NOVALUE*/
    _32742 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _32743 = (int)*(((s1_ptr)_2)->base + _32742);
    Ref(_26NOVALUE_11836);
    _2 = (int)SEQ_PTR(_67val_63489);
    if (!IS_ATOM_INT(_32743))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_32743)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _32743);
    _1 = *(int *)_2;
    *(int *)_2 = _26NOVALUE_11836;
    DeRef(_1);
L1: 

    /** 	if sym_mode( Code[pc+1] ) = M_TEMP then*/
    _32744 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _32745 = (int)*(((s1_ptr)_2)->base + _32744);
    Ref(_32745);
    _32746 = _52sym_mode(_32745);
    _32745 = NOVALUE;
    if (binary_op_a(NOTEQ, _32746, 3)){
        DeRef(_32746);
        _32746 = NOVALUE;
        goto L2; // [134] 161
    }
    DeRef(_32746);
    _32746 = NOVALUE;

    /** 		val[Code[pc+1]] = NOVALUE*/
    _32748 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _32749 = (int)*(((s1_ptr)_2)->base + _32748);
    Ref(_26NOVALUE_11836);
    _2 = (int)SEQ_PTR(_67val_63489);
    if (!IS_ATOM_INT(_32749))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_32749)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _32749);
    _1 = *(int *)_2;
    *(int *)_2 = _26NOVALUE_11836;
    DeRef(_1);
L2: 

    /** 	pc += 4*/
    _67pc_63479 = _67pc_63479 + 4;

    /** end procedure*/
    DeRef(_32729);
    _32729 = NOVALUE;
    DeRef(_32731);
    _32731 = NOVALUE;
    _32732 = NOVALUE;
    DeRef(_32738);
    _32738 = NOVALUE;
    DeRef(_32734);
    _32734 = NOVALUE;
    _32735 = NOVALUE;
    DeRef(_32742);
    _32742 = NOVALUE;
    _32743 = NOVALUE;
    DeRef(_32744);
    _32744 = NOVALUE;
    DeRef(_32748);
    _32748 = NOVALUE;
    _32749 = NOVALUE;
    return;
    ;
}


void _67opPLUS1()
{
    int _32756 = NOVALUE;
    int _32755 = NOVALUE;
    int _32753 = NOVALUE;
    int _32751 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _32751 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _32751);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	target = Code[pc+3]*/
    _32753 = _67pc_63479 + 3;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67target_63484 = (int)*(((s1_ptr)_2)->base + _32753);
    if (!IS_ATOM_INT(_67target_63484)){
        _67target_63484 = (long)DBL_PTR(_67target_63484)->dbl;
    }

    /** 	val[target] = val[a] + 1*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _32755 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    if (IS_ATOM_INT(_32755)) {
        _32756 = _32755 + 1;
        if (_32756 > MAXINT){
            _32756 = NewDouble((double)_32756);
        }
    }
    else
    _32756 = binary_op(PLUS, 1, _32755);
    _32755 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63484);
    _1 = *(int *)_2;
    *(int *)_2 = _32756;
    if( _1 != _32756 ){
        DeRef(_1);
    }
    _32756 = NOVALUE;

    /** 	pc += 4*/
    _67pc_63479 = _67pc_63479 + 4;

    /** end procedure*/
    _32751 = NOVALUE;
    _32753 = NOVALUE;
    return;
    ;
}


void _67opGLOBAL_INIT_CHECK()
{
    int _32766 = NOVALUE;
    int _32764 = NOVALUE;
    int _32763 = NOVALUE;
    int _32761 = NOVALUE;
    int _32760 = NOVALUE;
    int _32758 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _32758 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _32758);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	if equal(val[a], NOVALUE) then*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _32760 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    if (_32760 == _26NOVALUE_11836)
    _32761 = 1;
    else if (IS_ATOM_INT(_32760) && IS_ATOM_INT(_26NOVALUE_11836))
    _32761 = 0;
    else
    _32761 = (compare(_32760, _26NOVALUE_11836) == 0);
    _32760 = NOVALUE;
    if (_32761 == 0)
    {
        _32761 = NOVALUE;
        goto L1; // [33] 62
    }
    else{
        _32761 = NOVALUE;
    }

    /** 		RTFatal("variable " & SymTab[a][S_NAME] & " has not been assigned a value")*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _32763 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    _2 = (int)SEQ_PTR(_32763);
    if (!IS_ATOM_INT(_26S_NAME_11654)){
        _32764 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NAME_11654)->dbl));
    }
    else{
        _32764 = (int)*(((s1_ptr)_2)->base + _26S_NAME_11654);
    }
    _32763 = NOVALUE;
    {
        int concat_list[3];

        concat_list[0] = _32765;
        concat_list[1] = _32764;
        concat_list[2] = _32762;
        Concat_N((object_ptr)&_32766, concat_list, 3);
    }
    _32764 = NOVALUE;
    _67RTFatal(_32766);
    _32766 = NOVALUE;
L1: 

    /** 	pc += 2*/
    _67pc_63479 = _67pc_63479 + 2;

    /** end procedure*/
    DeRef(_32758);
    _32758 = NOVALUE;
    return;
    ;
}


void _67opWHILE()
{
    int _32772 = NOVALUE;
    int _32770 = NOVALUE;
    int _32768 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _32768 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _32768);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	if val[a] = 0 then*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _32770 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    if (binary_op_a(NOTEQ, _32770, 0)){
        _32770 = NOVALUE;
        goto L1; // [27] 50
    }
    _32770 = NOVALUE;

    /** 		pc = Code[pc+2]*/
    _32772 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67pc_63479 = (int)*(((s1_ptr)_2)->base + _32772);
    if (!IS_ATOM_INT(_67pc_63479)){
        _67pc_63479 = (long)DBL_PTR(_67pc_63479)->dbl;
    }
    goto L2; // [47] 59
L1: 

    /** 		pc += 3*/
    _67pc_63479 = _67pc_63479 + 3;
L2: 

    /** end procedure*/
    DeRef(_32768);
    _32768 = NOVALUE;
    DeRef(_32772);
    _32772 = NOVALUE;
    return;
    ;
}


void _67opSWITCH_SPI()
{
    int _32797 = NOVALUE;
    int _32795 = NOVALUE;
    int _32794 = NOVALUE;
    int _32793 = NOVALUE;
    int _32792 = NOVALUE;
    int _32791 = NOVALUE;
    int _32790 = NOVALUE;
    int _32789 = NOVALUE;
    int _32788 = NOVALUE;
    int _32787 = NOVALUE;
    int _32786 = NOVALUE;
    int _32785 = NOVALUE;
    int _32783 = NOVALUE;
    int _32782 = NOVALUE;
    int _32781 = NOVALUE;
    int _32780 = NOVALUE;
    int _32779 = NOVALUE;
    int _32778 = NOVALUE;
    int _32777 = NOVALUE;
    int _32776 = NOVALUE;
    int _32775 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if integer( val[Code[pc+1]] ) then*/
    _32775 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _32776 = (int)*(((s1_ptr)_2)->base + _32775);
    _2 = (int)SEQ_PTR(_67val_63489);
    if (!IS_ATOM_INT(_32776)){
        _32777 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_32776)->dbl));
    }
    else{
        _32777 = (int)*(((s1_ptr)_2)->base + _32776);
    }
    if (IS_ATOM_INT(_32777))
    _32778 = 1;
    else if (IS_ATOM_DBL(_32777))
    _32778 = IS_ATOM_INT(DoubleToInt(_32777));
    else
    _32778 = 0;
    _32777 = NOVALUE;
    if (_32778 == 0)
    {
        _32778 = NOVALUE;
        goto L1; // [24] 149
    }
    else{
        _32778 = NOVALUE;
    }

    /** 		a = val[Code[pc+1]] - Code[pc+2]*/
    _32779 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _32780 = (int)*(((s1_ptr)_2)->base + _32779);
    _2 = (int)SEQ_PTR(_67val_63489);
    if (!IS_ATOM_INT(_32780)){
        _32781 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_32780)->dbl));
    }
    else{
        _32781 = (int)*(((s1_ptr)_2)->base + _32780);
    }
    _32782 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _32783 = (int)*(((s1_ptr)_2)->base + _32782);
    if (IS_ATOM_INT(_32781) && IS_ATOM_INT(_32783)) {
        _67a_63480 = _32781 - _32783;
    }
    else {
        _67a_63480 = binary_op(MINUS, _32781, _32783);
    }
    _32781 = NOVALUE;
    _32783 = NOVALUE;
    if (!IS_ATOM_INT(_67a_63480)) {
        _1 = (long)(DBL_PTR(_67a_63480)->dbl);
        DeRefDS(_67a_63480);
        _67a_63480 = _1;
    }

    /** 		if a > 0 and a <= length( val[Code[pc+3]] ) then*/
    _32785 = (_67a_63480 > 0);
    if (_32785 == 0) {
        goto L2; // [73] 148
    }
    _32787 = _67pc_63479 + 3;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _32788 = (int)*(((s1_ptr)_2)->base + _32787);
    _2 = (int)SEQ_PTR(_67val_63489);
    if (!IS_ATOM_INT(_32788)){
        _32789 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_32788)->dbl));
    }
    else{
        _32789 = (int)*(((s1_ptr)_2)->base + _32788);
    }
    if (IS_SEQUENCE(_32789)){
            _32790 = SEQ_PTR(_32789)->length;
    }
    else {
        _32790 = 1;
    }
    _32789 = NOVALUE;
    _32791 = (_67a_63480 <= _32790);
    _32790 = NOVALUE;
    if (_32791 == 0)
    {
        DeRef(_32791);
        _32791 = NOVALUE;
        goto L2; // [105] 148
    }
    else{
        DeRef(_32791);
        _32791 = NOVALUE;
    }

    /** 			pc += val[Code[pc+3]][a]*/
    _32792 = _67pc_63479 + 3;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _32793 = (int)*(((s1_ptr)_2)->base + _32792);
    _2 = (int)SEQ_PTR(_67val_63489);
    if (!IS_ATOM_INT(_32793)){
        _32794 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_32793)->dbl));
    }
    else{
        _32794 = (int)*(((s1_ptr)_2)->base + _32793);
    }
    _2 = (int)SEQ_PTR(_32794);
    _32795 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    _32794 = NOVALUE;
    if (IS_ATOM_INT(_32795)) {
        _67pc_63479 = _67pc_63479 + _32795;
    }
    else {
        _67pc_63479 = binary_op(PLUS, _67pc_63479, _32795);
    }
    _32795 = NOVALUE;
    if (!IS_ATOM_INT(_67pc_63479)) {
        _1 = (long)(DBL_PTR(_67pc_63479)->dbl);
        DeRefDS(_67pc_63479);
        _67pc_63479 = _1;
    }

    /** 			return*/
    DeRef(_32775);
    _32775 = NOVALUE;
    _32776 = NOVALUE;
    DeRef(_32779);
    _32779 = NOVALUE;
    _32780 = NOVALUE;
    DeRef(_32785);
    _32785 = NOVALUE;
    DeRef(_32782);
    _32782 = NOVALUE;
    DeRef(_32787);
    _32787 = NOVALUE;
    _32788 = NOVALUE;
    _32789 = NOVALUE;
    _32792 = NOVALUE;
    _32793 = NOVALUE;
    return;
L2: 
L1: 

    /** 	pc = Code[pc+4]*/
    _32797 = _67pc_63479 + 4;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67pc_63479 = (int)*(((s1_ptr)_2)->base + _32797);
    if (!IS_ATOM_INT(_67pc_63479)){
        _67pc_63479 = (long)DBL_PTR(_67pc_63479)->dbl;
    }

    /** end procedure*/
    DeRef(_32775);
    _32775 = NOVALUE;
    _32776 = NOVALUE;
    DeRef(_32779);
    _32779 = NOVALUE;
    _32780 = NOVALUE;
    DeRef(_32785);
    _32785 = NOVALUE;
    DeRef(_32782);
    _32782 = NOVALUE;
    DeRef(_32787);
    _32787 = NOVALUE;
    _32788 = NOVALUE;
    _32789 = NOVALUE;
    DeRef(_32792);
    _32792 = NOVALUE;
    _32793 = NOVALUE;
    _32797 = NOVALUE;
    return;
    ;
}


void _67opSWITCH()
{
    int _32811 = NOVALUE;
    int _32809 = NOVALUE;
    int _32808 = NOVALUE;
    int _32807 = NOVALUE;
    int _32806 = NOVALUE;
    int _32804 = NOVALUE;
    int _32803 = NOVALUE;
    int _32802 = NOVALUE;
    int _32801 = NOVALUE;
    int _32800 = NOVALUE;
    int _32799 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = find( val[Code[pc+1]], val[Code[pc+2]] )*/
    _32799 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _32800 = (int)*(((s1_ptr)_2)->base + _32799);
    _2 = (int)SEQ_PTR(_67val_63489);
    if (!IS_ATOM_INT(_32800)){
        _32801 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_32800)->dbl));
    }
    else{
        _32801 = (int)*(((s1_ptr)_2)->base + _32800);
    }
    _32802 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _32803 = (int)*(((s1_ptr)_2)->base + _32802);
    _2 = (int)SEQ_PTR(_67val_63489);
    if (!IS_ATOM_INT(_32803)){
        _32804 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_32803)->dbl));
    }
    else{
        _32804 = (int)*(((s1_ptr)_2)->base + _32803);
    }
    _67a_63480 = find_from(_32801, _32804, 1);
    _32801 = NOVALUE;
    _32804 = NOVALUE;

    /** 	if a then*/
    if (_67a_63480 == 0)
    {
        goto L1; // [48] 88
    }
    else{
    }

    /** 		pc += val[Code[pc+3]][a]*/
    _32806 = _67pc_63479 + 3;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _32807 = (int)*(((s1_ptr)_2)->base + _32806);
    _2 = (int)SEQ_PTR(_67val_63489);
    if (!IS_ATOM_INT(_32807)){
        _32808 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_32807)->dbl));
    }
    else{
        _32808 = (int)*(((s1_ptr)_2)->base + _32807);
    }
    _2 = (int)SEQ_PTR(_32808);
    _32809 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    _32808 = NOVALUE;
    if (IS_ATOM_INT(_32809)) {
        _67pc_63479 = _67pc_63479 + _32809;
    }
    else {
        _67pc_63479 = binary_op(PLUS, _67pc_63479, _32809);
    }
    _32809 = NOVALUE;
    if (!IS_ATOM_INT(_67pc_63479)) {
        _1 = (long)(DBL_PTR(_67pc_63479)->dbl);
        DeRefDS(_67pc_63479);
        _67pc_63479 = _1;
    }
    goto L2; // [85] 105
L1: 

    /** 		pc = Code[pc + 4]*/
    _32811 = _67pc_63479 + 4;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67pc_63479 = (int)*(((s1_ptr)_2)->base + _32811);
    if (!IS_ATOM_INT(_67pc_63479)){
        _67pc_63479 = (long)DBL_PTR(_67pc_63479)->dbl;
    }
L2: 

    /** end procedure*/
    DeRef(_32799);
    _32799 = NOVALUE;
    _32800 = NOVALUE;
    DeRef(_32806);
    _32806 = NOVALUE;
    DeRef(_32802);
    _32802 = NOVALUE;
    _32803 = NOVALUE;
    _32807 = NOVALUE;
    DeRef(_32811);
    _32811 = NOVALUE;
    return;
    ;
}


void _67opSWITCH_RT()
{
    int _values_65358 = NOVALUE;
    int _all_ints_65363 = NOVALUE;
    int _max_65364 = NOVALUE;
    int _min_65366 = NOVALUE;
    int _sym_65371 = NOVALUE;
    int _sign_65373 = NOVALUE;
    int _new_value_65388 = NOVALUE;
    int _jump_65405 = NOVALUE;
    int _switch_table_65410 = NOVALUE;
    int _offset_65418 = NOVALUE;
    int _32863 = NOVALUE;
    int _32862 = NOVALUE;
    int _32861 = NOVALUE;
    int _32860 = NOVALUE;
    int _32859 = NOVALUE;
    int _32856 = NOVALUE;
    int _32855 = NOVALUE;
    int _32854 = NOVALUE;
    int _32853 = NOVALUE;
    int _32852 = NOVALUE;
    int _32850 = NOVALUE;
    int _32849 = NOVALUE;
    int _32848 = NOVALUE;
    int _32847 = NOVALUE;
    int _32846 = NOVALUE;
    int _32843 = NOVALUE;
    int _32842 = NOVALUE;
    int _32841 = NOVALUE;
    int _32840 = NOVALUE;
    int _32839 = NOVALUE;
    int _32837 = NOVALUE;
    int _32836 = NOVALUE;
    int _32835 = NOVALUE;
    int _32834 = NOVALUE;
    int _32833 = NOVALUE;
    int _32829 = NOVALUE;
    int _32827 = NOVALUE;
    int _32826 = NOVALUE;
    int _32825 = NOVALUE;
    int _32824 = NOVALUE;
    int _32823 = NOVALUE;
    int _32821 = NOVALUE;
    int _32820 = NOVALUE;
    int _32816 = NOVALUE;
    int _32814 = NOVALUE;
    int _32813 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	sequence values = val[Code[pc+2]]*/
    _32813 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _32814 = (int)*(((s1_ptr)_2)->base + _32813);
    DeRef(_values_65358);
    _2 = (int)SEQ_PTR(_67val_63489);
    if (!IS_ATOM_INT(_32814)){
        _values_65358 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_32814)->dbl));
    }
    else{
        _values_65358 = (int)*(((s1_ptr)_2)->base + _32814);
    }
    Ref(_values_65358);

    /** 	integer all_ints = 1*/
    _all_ints_65363 = 1;

    /** 	integer max = MININT*/
    _max_65364 = -1073741824;

    /** 	integer min = MAXINT*/
    _min_65366 = 1073741823;

    /** 	for i = 1 to length( values ) do*/
    if (IS_SEQUENCE(_values_65358)){
            _32816 = SEQ_PTR(_values_65358)->length;
    }
    else {
        _32816 = 1;
    }
    {
        int _i_65369;
        _i_65369 = 1;
L1: 
        if (_i_65369 > _32816){
            goto L2; // [51] 209
        }

        /** 		integer sym = values[i]*/
        _2 = (int)SEQ_PTR(_values_65358);
        _sym_65371 = (int)*(((s1_ptr)_2)->base + _i_65369);
        if (!IS_ATOM_INT(_sym_65371))
        _sym_65371 = (long)DBL_PTR(_sym_65371)->dbl;

        /** 		integer sign = 1*/
        _sign_65373 = 1;

        /** 		if sym < 0 then*/
        if (_sym_65371 >= 0)
        goto L3; // [71] 88

        /** 			sign = -1*/
        _sign_65373 = -1;

        /** 			sym = -sym*/
        _sym_65371 = - _sym_65371;
L3: 

        /** 		if equal(val[sym], NOVALUE) then*/
        _2 = (int)SEQ_PTR(_67val_63489);
        _32820 = (int)*(((s1_ptr)_2)->base + _sym_65371);
        if (_32820 == _26NOVALUE_11836)
        _32821 = 1;
        else if (IS_ATOM_INT(_32820) && IS_ATOM_INT(_26NOVALUE_11836))
        _32821 = 0;
        else
        _32821 = (compare(_32820, _26NOVALUE_11836) == 0);
        _32820 = NOVALUE;
        if (_32821 == 0)
        {
            _32821 = NOVALUE;
            goto L4; // [102] 131
        }
        else{
            _32821 = NOVALUE;
        }

        /** 			RTFatal( sprintf( "'%s' has not been assigned a value", {SymTab[sym][S_NAME]} ) )*/
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _32823 = (int)*(((s1_ptr)_2)->base + _sym_65371);
        _2 = (int)SEQ_PTR(_32823);
        if (!IS_ATOM_INT(_26S_NAME_11654)){
            _32824 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NAME_11654)->dbl));
        }
        else{
            _32824 = (int)*(((s1_ptr)_2)->base + _26S_NAME_11654);
        }
        _32823 = NOVALUE;
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        Ref(_32824);
        *((int *)(_2+4)) = _32824;
        _32825 = MAKE_SEQ(_1);
        _32824 = NOVALUE;
        _32826 = EPrintf(-9999999, _32822, _32825);
        DeRefDS(_32825);
        _32825 = NOVALUE;
        _67RTFatal(_32826);
        _32826 = NOVALUE;
L4: 

        /** 		object new_value = sign * val[sym]*/
        _2 = (int)SEQ_PTR(_67val_63489);
        _32827 = (int)*(((s1_ptr)_2)->base + _sym_65371);
        DeRef(_new_value_65388);
        if (IS_ATOM_INT(_32827)) {
            if (_sign_65373 == (short)_sign_65373 && _32827 <= INT15 && _32827 >= -INT15)
            _new_value_65388 = _sign_65373 * _32827;
            else
            _new_value_65388 = NewDouble(_sign_65373 * (double)_32827);
        }
        else {
            _new_value_65388 = binary_op(MULTIPLY, _sign_65373, _32827);
        }
        _32827 = NOVALUE;

        /** 		values[i] = new_value*/
        Ref(_new_value_65388);
        _2 = (int)SEQ_PTR(_values_65358);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _values_65358 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_65369);
        _1 = *(int *)_2;
        *(int *)_2 = _new_value_65388;
        DeRef(_1);

        /** 		if not integer( new_value ) then*/
        if (IS_ATOM_INT(_new_value_65388))
        _32829 = 1;
        else if (IS_ATOM_DBL(_new_value_65388))
        _32829 = IS_ATOM_INT(DoubleToInt(_new_value_65388));
        else
        _32829 = 0;
        if (_32829 != 0)
        goto L5; // [154] 165
        _32829 = NOVALUE;

        /** 			all_ints = 0*/
        _all_ints_65363 = 0;
        goto L6; // [162] 200
L5: 

        /** 		elsif all_ints then*/
        if (_all_ints_65363 == 0)
        {
            goto L7; // [167] 199
        }
        else{
        }

        /** 			if new_value < min then*/
        if (binary_op_a(GREATEREQ, _new_value_65388, _min_65366)){
            goto L8; // [172] 184
        }

        /** 				min = new_value*/
        Ref(_new_value_65388);
        _min_65366 = _new_value_65388;
        if (!IS_ATOM_INT(_min_65366)) {
            _1 = (long)(DBL_PTR(_min_65366)->dbl);
            DeRefDS(_min_65366);
            _min_65366 = _1;
        }
L8: 

        /** 			if new_value > max then*/
        if (binary_op_a(LESSEQ, _new_value_65388, _max_65364)){
            goto L9; // [186] 198
        }

        /** 				max = new_value*/
        Ref(_new_value_65388);
        _max_65364 = _new_value_65388;
        if (!IS_ATOM_INT(_max_65364)) {
            _1 = (long)(DBL_PTR(_max_65364)->dbl);
            DeRefDS(_max_65364);
            _max_65364 = _1;
        }
L9: 
L7: 
L6: 
        DeRef(_new_value_65388);
        _new_value_65388 = NOVALUE;

        /** 	end for*/
        _i_65369 = _i_65369 + 1;
        goto L1; // [204] 58
L2: 
        ;
    }

    /** 	if all_ints and max - min < 1024 then*/
    if (_all_ints_65363 == 0) {
        goto LA; // [211] 412
    }
    _32834 = _max_65364 - _min_65366;
    if ((long)((unsigned long)_32834 +(unsigned long) HIGH_BITS) >= 0){
        _32834 = NewDouble((double)_32834);
    }
    if (IS_ATOM_INT(_32834)) {
        _32835 = (_32834 < 1024);
    }
    else {
        _32835 = (DBL_PTR(_32834)->dbl < (double)1024);
    }
    DeRef(_32834);
    _32834 = NOVALUE;
    if (_32835 == 0)
    {
        DeRef(_32835);
        _32835 = NOVALUE;
        goto LA; // [224] 412
    }
    else{
        DeRef(_32835);
        _32835 = NOVALUE;
    }

    /** 		Code[pc] = SWITCH_SPI*/
    _2 = (int)SEQ_PTR(_26Code_12071);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _26Code_12071 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _67pc_63479);
    _1 = *(int *)_2;
    *(int *)_2 = 192;
    DeRef(_1);

    /** 		sequence jump = val[Code[pc+3]]*/
    _32836 = _67pc_63479 + 3;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _32837 = (int)*(((s1_ptr)_2)->base + _32836);
    DeRef(_jump_65405);
    _2 = (int)SEQ_PTR(_67val_63489);
    if (!IS_ATOM_INT(_32837)){
        _jump_65405 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_32837)->dbl));
    }
    else{
        _jump_65405 = (int)*(((s1_ptr)_2)->base + _32837);
    }
    Ref(_jump_65405);

    /** 		sequence switch_table = repeat( Code[pc+4] - pc, max - min + 1 )*/
    _32839 = _67pc_63479 + 4;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _32840 = (int)*(((s1_ptr)_2)->base + _32839);
    if (IS_ATOM_INT(_32840)) {
        _32841 = _32840 - _67pc_63479;
        if ((long)((unsigned long)_32841 +(unsigned long) HIGH_BITS) >= 0){
            _32841 = NewDouble((double)_32841);
        }
    }
    else {
        _32841 = binary_op(MINUS, _32840, _67pc_63479);
    }
    _32840 = NOVALUE;
    _32842 = _max_65364 - _min_65366;
    if ((long)((unsigned long)_32842 +(unsigned long) HIGH_BITS) >= 0){
        _32842 = NewDouble((double)_32842);
    }
    if (IS_ATOM_INT(_32842)) {
        _32843 = _32842 + 1;
    }
    else
    _32843 = binary_op(PLUS, 1, _32842);
    DeRef(_32842);
    _32842 = NOVALUE;
    DeRef(_switch_table_65410);
    _switch_table_65410 = Repeat(_32841, _32843);
    DeRef(_32841);
    _32841 = NOVALUE;
    DeRef(_32843);
    _32843 = NOVALUE;

    /** 		integer offset = min - 1*/
    _offset_65418 = _min_65366 - 1;

    /** 		for i = 1 to length( values ) do*/
    if (IS_SEQUENCE(_values_65358)){
            _32846 = SEQ_PTR(_values_65358)->length;
    }
    else {
        _32846 = 1;
    }
    {
        int _i_65421;
        _i_65421 = 1;
LB: 
        if (_i_65421 > _32846){
            goto LC; // [304] 336
        }

        /** 			switch_table[values[i] - offset] = jump[i]*/
        _2 = (int)SEQ_PTR(_values_65358);
        _32847 = (int)*(((s1_ptr)_2)->base + _i_65421);
        if (IS_ATOM_INT(_32847)) {
            _32848 = _32847 - _offset_65418;
            if ((long)((unsigned long)_32848 +(unsigned long) HIGH_BITS) >= 0){
                _32848 = NewDouble((double)_32848);
            }
        }
        else {
            _32848 = binary_op(MINUS, _32847, _offset_65418);
        }
        _32847 = NOVALUE;
        _2 = (int)SEQ_PTR(_jump_65405);
        _32849 = (int)*(((s1_ptr)_2)->base + _i_65421);
        Ref(_32849);
        _2 = (int)SEQ_PTR(_switch_table_65410);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _switch_table_65410 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_32848))
        _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_32848)->dbl));
        else
        _2 = (int)(((s1_ptr)_2)->base + _32848);
        _1 = *(int *)_2;
        *(int *)_2 = _32849;
        if( _1 != _32849 ){
            DeRef(_1);
        }
        _32849 = NOVALUE;

        /** 		end for*/
        _i_65421 = _i_65421 + 1;
        goto LB; // [331] 311
LC: 
        ;
    }

    /** 		Code[pc+2] = offset*/
    _32850 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _26Code_12071 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _32850);
    _1 = *(int *)_2;
    *(int *)_2 = _offset_65418;
    DeRef(_1);

    /** 		val = append( val, switch_table )*/
    RefDS(_switch_table_65410);
    Append(&_67val_63489, _67val_63489, _switch_table_65410);

    /** 		Code[pc+3] = length(val)*/
    _32852 = _67pc_63479 + 3;
    if ((long)((unsigned long)_32852 + (unsigned long)HIGH_BITS) >= 0) 
    _32852 = NewDouble((double)_32852);
    if (IS_SEQUENCE(_67val_63489)){
            _32853 = SEQ_PTR(_67val_63489)->length;
    }
    else {
        _32853 = 1;
    }
    _2 = (int)SEQ_PTR(_26Code_12071);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _26Code_12071 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_32852))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_32852)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _32852);
    _1 = *(int *)_2;
    *(int *)_2 = _32853;
    if( _1 != _32853 ){
        DeRef(_1);
    }
    _32853 = NOVALUE;

    /** 		SymTab[call_stack[$]][S_CODE] = Code*/
    if (IS_SEQUENCE(_67call_stack_63497)){
            _32854 = SEQ_PTR(_67call_stack_63497)->length;
    }
    else {
        _32854 = 1;
    }
    _2 = (int)SEQ_PTR(_67call_stack_63497);
    _32855 = (int)*(((s1_ptr)_2)->base + _32854);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_32855))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_32855)->dbl));
    else
    _3 = (int)(_32855 + ((s1_ptr)_2)->base);
    RefDS(_26Code_12071);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_26S_CODE_11666))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_CODE_11666)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _26S_CODE_11666);
    _1 = *(int *)_2;
    *(int *)_2 = _26Code_12071;
    DeRef(_1);
    _32856 = NOVALUE;

    /** 		opSWITCH_SPI()*/
    _67opSWITCH_SPI();
    DeRef(_jump_65405);
    _jump_65405 = NOVALUE;
    DeRefDS(_switch_table_65410);
    _switch_table_65410 = NOVALUE;
    goto LD; // [409] 482
LA: 

    /** 		Code[pc] = SWITCH*/
    _2 = (int)SEQ_PTR(_26Code_12071);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _26Code_12071 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _67pc_63479);
    _1 = *(int *)_2;
    *(int *)_2 = 185;
    DeRef(_1);

    /** 		val = append( val, values )*/
    RefDS(_values_65358);
    Append(&_67val_63489, _67val_63489, _values_65358);

    /** 		Code[pc+2] = length(val)*/
    _32859 = _67pc_63479 + 2;
    if ((long)((unsigned long)_32859 + (unsigned long)HIGH_BITS) >= 0) 
    _32859 = NewDouble((double)_32859);
    if (IS_SEQUENCE(_67val_63489)){
            _32860 = SEQ_PTR(_67val_63489)->length;
    }
    else {
        _32860 = 1;
    }
    _2 = (int)SEQ_PTR(_26Code_12071);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _26Code_12071 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_32859))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_32859)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _32859);
    _1 = *(int *)_2;
    *(int *)_2 = _32860;
    if( _1 != _32860 ){
        DeRef(_1);
    }
    _32860 = NOVALUE;

    /** 		SymTab[call_stack[$]][S_CODE] = Code*/
    if (IS_SEQUENCE(_67call_stack_63497)){
            _32861 = SEQ_PTR(_67call_stack_63497)->length;
    }
    else {
        _32861 = 1;
    }
    _2 = (int)SEQ_PTR(_67call_stack_63497);
    _32862 = (int)*(((s1_ptr)_2)->base + _32861);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_32862))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_32862)->dbl));
    else
    _3 = (int)(_32862 + ((s1_ptr)_2)->base);
    RefDS(_26Code_12071);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_26S_CODE_11666))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_CODE_11666)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _26S_CODE_11666);
    _1 = *(int *)_2;
    *(int *)_2 = _26Code_12071;
    DeRef(_1);
    _32863 = NOVALUE;

    /** 		opSWITCH()*/
    _67opSWITCH();
LD: 

    /** end procedure*/
    DeRef(_values_65358);
    DeRef(_32813);
    _32813 = NOVALUE;
    _32814 = NOVALUE;
    DeRef(_32836);
    _32836 = NOVALUE;
    _32837 = NOVALUE;
    DeRef(_32839);
    _32839 = NOVALUE;
    DeRef(_32850);
    _32850 = NOVALUE;
    DeRef(_32848);
    _32848 = NOVALUE;
    DeRef(_32852);
    _32852 = NOVALUE;
    _32855 = NOVALUE;
    DeRef(_32859);
    _32859 = NOVALUE;
    _32862 = NOVALUE;
    return;
    ;
}


void _67opCASE()
{
    int _0, _1, _2;
    

    /** end procedure*/
    return;
    ;
}


void _67opNOPSWITCH()
{
    int _0, _1, _2;
    

    /** end procedure*/
    return;
    ;
}


int _67var_subs(int _x_65459, int _subs_65460)
{
    int _si_65461 = NOVALUE;
    int _32878 = NOVALUE;
    int _32877 = NOVALUE;
    int _32876 = NOVALUE;
    int _32875 = NOVALUE;
    int _32874 = NOVALUE;
    int _32872 = NOVALUE;
    int _32871 = NOVALUE;
    int _32868 = NOVALUE;
    int _32866 = NOVALUE;
    int _32865 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(x) then*/
    _32865 = IS_ATOM(_x_65459);
    if (_32865 == 0)
    {
        _32865 = NOVALUE;
        goto L1; // [8] 17
    }
    else{
        _32865 = NOVALUE;
    }

    /** 		RTFatal("attempt to subscript an atom\n(reading from it)")*/
    RefDS(_32656);
    _67RTFatal(_32656);
L1: 

    /** 	for i = 1 to length(subs) do*/
    if (IS_SEQUENCE(_subs_65460)){
            _32866 = SEQ_PTR(_subs_65460)->length;
    }
    else {
        _32866 = 1;
    }
    {
        int _i_65465;
        _i_65465 = 1;
L2: 
        if (_i_65465 > _32866){
            goto L3; // [22] 110
        }

        /** 		si = subs[i]*/
        DeRef(_si_65461);
        _2 = (int)SEQ_PTR(_subs_65460);
        _si_65461 = (int)*(((s1_ptr)_2)->base + _i_65465);
        Ref(_si_65461);

        /** 		if sequence(si) then*/
        _32868 = IS_SEQUENCE(_si_65461);
        if (_32868 == 0)
        {
            _32868 = NOVALUE;
            goto L4; // [40] 49
        }
        else{
            _32868 = NOVALUE;
        }

        /** 			RTFatal("A subscript must be an atom")*/
        RefDS(_32869);
        _67RTFatal(_32869);
L4: 

        /** 		si = floor(si)*/
        _0 = _si_65461;
        if (IS_ATOM_INT(_si_65461))
        _si_65461 = e_floor(_si_65461);
        else
        _si_65461 = unary_op(FLOOR, _si_65461);
        DeRef(_0);

        /** 		if si > length(x) or si < 1 then*/
        if (IS_SEQUENCE(_x_65459)){
                _32871 = SEQ_PTR(_x_65459)->length;
        }
        else {
            _32871 = 1;
        }
        if (IS_ATOM_INT(_si_65461)) {
            _32872 = (_si_65461 > _32871);
        }
        else {
            _32872 = (DBL_PTR(_si_65461)->dbl > (double)_32871);
        }
        _32871 = NOVALUE;
        if (_32872 != 0) {
            goto L5; // [63] 76
        }
        if (IS_ATOM_INT(_si_65461)) {
            _32874 = (_si_65461 < 1);
        }
        else {
            _32874 = (DBL_PTR(_si_65461)->dbl < (double)1);
        }
        if (_32874 == 0)
        {
            DeRef(_32874);
            _32874 = NOVALUE;
            goto L6; // [72] 93
        }
        else{
            DeRef(_32874);
            _32874 = NOVALUE;
        }
L5: 

        /** 			RTFatal(*/
        if (IS_SEQUENCE(_x_65459)){
                _32875 = SEQ_PTR(_x_65459)->length;
        }
        else {
            _32875 = 1;
        }
        Ref(_si_65461);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _si_65461;
        ((int *)_2)[2] = _32875;
        _32876 = MAKE_SEQ(_1);
        _32875 = NOVALUE;
        _32877 = EPrintf(-9999999, _32664, _32876);
        DeRefDS(_32876);
        _32876 = NOVALUE;
        _67RTFatal(_32877);
        _32877 = NOVALUE;
L6: 

        /** 		x = x[subs[i]]*/
        _2 = (int)SEQ_PTR(_subs_65460);
        _32878 = (int)*(((s1_ptr)_2)->base + _i_65465);
        _0 = _x_65459;
        _2 = (int)SEQ_PTR(_x_65459);
        if (!IS_ATOM_INT(_32878)){
            _x_65459 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_32878)->dbl));
        }
        else{
            _x_65459 = (int)*(((s1_ptr)_2)->base + _32878);
        }
        Ref(_x_65459);
        DeRef(_0);

        /** 	end for*/
        _i_65465 = _i_65465 + 1;
        goto L2; // [105] 29
L3: 
        ;
    }

    /** 	return x*/
    DeRefDS(_subs_65460);
    DeRef(_si_65461);
    DeRef(_32872);
    _32872 = NOVALUE;
    _32878 = NOVALUE;
    return _x_65459;
    ;
}


void _67opLENGTH()
{
    int _32885 = NOVALUE;
    int _32884 = NOVALUE;
    int _32882 = NOVALUE;
    int _32880 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _32880 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _32880);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	target = Code[pc+2]*/
    _32882 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67target_63484 = (int)*(((s1_ptr)_2)->base + _32882);
    if (!IS_ATOM_INT(_67target_63484)){
        _67target_63484 = (long)DBL_PTR(_67target_63484)->dbl;
    }

    /** 	val[target] = length(val[a])*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _32884 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    if (IS_SEQUENCE(_32884)){
            _32885 = SEQ_PTR(_32884)->length;
    }
    else {
        _32885 = 1;
    }
    _32884 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63484);
    _1 = *(int *)_2;
    *(int *)_2 = _32885;
    if( _1 != _32885 ){
        DeRef(_1);
    }
    _32885 = NOVALUE;

    /** 	pc += 3*/
    _67pc_63479 = _67pc_63479 + 3;

    /** end procedure*/
    _32880 = NOVALUE;
    _32882 = NOVALUE;
    _32884 = NOVALUE;
    return;
    ;
}


void _67opPLENGTH()
{
    int _32898 = NOVALUE;
    int _32897 = NOVALUE;
    int _32896 = NOVALUE;
    int _32894 = NOVALUE;
    int _32893 = NOVALUE;
    int _32891 = NOVALUE;
    int _32889 = NOVALUE;
    int _32887 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _32887 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _32887);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	target = Code[pc+2]*/
    _32889 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67target_63484 = (int)*(((s1_ptr)_2)->base + _32889);
    if (!IS_ATOM_INT(_67target_63484)){
        _67target_63484 = (long)DBL_PTR(_67target_63484)->dbl;
    }

    /** 	lhs_seq_index = val[a][1]*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _32891 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    _2 = (int)SEQ_PTR(_32891);
    _67lhs_seq_index_63487 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_67lhs_seq_index_63487)){
        _67lhs_seq_index_63487 = (long)DBL_PTR(_67lhs_seq_index_63487)->dbl;
    }
    _32891 = NOVALUE;

    /** 	lhs_subs = val[a][2..$]*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _32893 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    if (IS_SEQUENCE(_32893)){
            _32894 = SEQ_PTR(_32893)->length;
    }
    else {
        _32894 = 1;
    }
    rhs_slice_target = (object_ptr)&_67lhs_subs_63488;
    RHS_Slice(_32893, 2, _32894);
    _32893 = NOVALUE;

    /** 	val[target] = length(var_subs(val[lhs_seq_index], lhs_subs))*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _32896 = (int)*(((s1_ptr)_2)->base + _67lhs_seq_index_63487);
    Ref(_32896);
    RefDS(_67lhs_subs_63488);
    _32897 = _67var_subs(_32896, _67lhs_subs_63488);
    _32896 = NOVALUE;
    if (IS_SEQUENCE(_32897)){
            _32898 = SEQ_PTR(_32897)->length;
    }
    else {
        _32898 = 1;
    }
    DeRef(_32897);
    _32897 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63484);
    _1 = *(int *)_2;
    *(int *)_2 = _32898;
    if( _1 != _32898 ){
        DeRef(_1);
    }
    _32898 = NOVALUE;

    /** 	lhs_subs = {}*/
    RefDS(_22037);
    DeRefDS(_67lhs_subs_63488);
    _67lhs_subs_63488 = _22037;

    /** 	pc += 3*/
    _67pc_63479 = _67pc_63479 + 3;

    /** end procedure*/
    _32887 = NOVALUE;
    _32889 = NOVALUE;
    _32897 = NOVALUE;
    return;
    ;
}


void _67opLHS_SUBS()
{
    int _32908 = NOVALUE;
    int _32907 = NOVALUE;
    int _32906 = NOVALUE;
    int _32904 = NOVALUE;
    int _32902 = NOVALUE;
    int _32900 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1] -- base var sequence, or a temp that contains*/
    _32900 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _32900);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	b = Code[pc+2] -- subscript*/
    _32902 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67b_63481 = (int)*(((s1_ptr)_2)->base + _32902);
    if (!IS_ATOM_INT(_67b_63481)){
        _67b_63481 = (long)DBL_PTR(_67b_63481)->dbl;
    }

    /** 	target = Code[pc+3] -- temp for storing result*/
    _32904 = _67pc_63479 + 3;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67target_63484 = (int)*(((s1_ptr)_2)->base + _32904);
    if (!IS_ATOM_INT(_67target_63484)){
        _67target_63484 = (long)DBL_PTR(_67target_63484)->dbl;
    }

    /** 	val[target] = append(val[a], val[b])*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _32906 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    _2 = (int)SEQ_PTR(_67val_63489);
    _32907 = (int)*(((s1_ptr)_2)->base + _67b_63481);
    Ref(_32907);
    Append(&_32908, _32906, _32907);
    _32906 = NOVALUE;
    _32907 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63484);
    _1 = *(int *)_2;
    *(int *)_2 = _32908;
    if( _1 != _32908 ){
        DeRef(_1);
    }
    _32908 = NOVALUE;

    /** 	pc += 5*/
    _67pc_63479 = _67pc_63479 + 5;

    /** end procedure*/
    _32900 = NOVALUE;
    _32902 = NOVALUE;
    _32904 = NOVALUE;
    return;
    ;
}


void _67opLHS_SUBS1()
{
    int _32917 = NOVALUE;
    int _32916 = NOVALUE;
    int _32914 = NOVALUE;
    int _32912 = NOVALUE;
    int _32910 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1] -- base var sequence, or a temp that contains*/
    _32910 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _32910);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	b = Code[pc+2] -- subscript*/
    _32912 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67b_63481 = (int)*(((s1_ptr)_2)->base + _32912);
    if (!IS_ATOM_INT(_67b_63481)){
        _67b_63481 = (long)DBL_PTR(_67b_63481)->dbl;
    }

    /** 	target = Code[pc+3] -- temp for storing result*/
    _32914 = _67pc_63479 + 3;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67target_63484 = (int)*(((s1_ptr)_2)->base + _32914);
    if (!IS_ATOM_INT(_67target_63484)){
        _67target_63484 = (long)DBL_PTR(_67target_63484)->dbl;
    }

    /** 	val[target] = {a, val[b]}*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _32916 = (int)*(((s1_ptr)_2)->base + _67b_63481);
    Ref(_32916);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _67a_63480;
    ((int *)_2)[2] = _32916;
    _32917 = MAKE_SEQ(_1);
    _32916 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63484);
    _1 = *(int *)_2;
    *(int *)_2 = _32917;
    if( _1 != _32917 ){
        DeRef(_1);
    }
    _32917 = NOVALUE;

    /** 	pc += 5*/
    _67pc_63479 = _67pc_63479 + 5;

    /** end procedure*/
    _32910 = NOVALUE;
    _32912 = NOVALUE;
    _32914 = NOVALUE;
    return;
    ;
}


void _67opLHS_SUBS1_COPY()
{
    int _32929 = NOVALUE;
    int _32928 = NOVALUE;
    int _32927 = NOVALUE;
    int _32925 = NOVALUE;
    int _32923 = NOVALUE;
    int _32921 = NOVALUE;
    int _32919 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1] -- base var sequence*/
    _32919 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _32919);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	b = Code[pc+2] -- subscript*/
    _32921 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67b_63481 = (int)*(((s1_ptr)_2)->base + _32921);
    if (!IS_ATOM_INT(_67b_63481)){
        _67b_63481 = (long)DBL_PTR(_67b_63481)->dbl;
    }

    /** 	target = Code[pc+3] -- temp for storing result*/
    _32923 = _67pc_63479 + 3;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67target_63484 = (int)*(((s1_ptr)_2)->base + _32923);
    if (!IS_ATOM_INT(_67target_63484)){
        _67target_63484 = (long)DBL_PTR(_67target_63484)->dbl;
    }

    /** 	c = Code[pc+4] -- temp to hold base sequence while it's manipulated*/
    _32925 = _67pc_63479 + 4;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67c_63482 = (int)*(((s1_ptr)_2)->base + _32925);
    if (!IS_ATOM_INT(_67c_63482)){
        _67c_63482 = (long)DBL_PTR(_67c_63482)->dbl;
    }

    /** 	val[c] = val[a]*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _32927 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    Ref(_32927);
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67c_63482);
    _1 = *(int *)_2;
    *(int *)_2 = _32927;
    if( _1 != _32927 ){
        DeRef(_1);
    }
    _32927 = NOVALUE;

    /** 	val[target] = {c, val[b]}*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _32928 = (int)*(((s1_ptr)_2)->base + _67b_63481);
    Ref(_32928);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _67c_63482;
    ((int *)_2)[2] = _32928;
    _32929 = MAKE_SEQ(_1);
    _32928 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63484);
    _1 = *(int *)_2;
    *(int *)_2 = _32929;
    if( _1 != _32929 ){
        DeRef(_1);
    }
    _32929 = NOVALUE;

    /** 	pc += 5*/
    _67pc_63479 = _67pc_63479 + 5;

    /** end procedure*/
    _32919 = NOVALUE;
    _32921 = NOVALUE;
    _32923 = NOVALUE;
    _32925 = NOVALUE;
    return;
    ;
}


void _67lhs_check_subs(int _seq_65559, int _subs_65560)
{
    int _32945 = NOVALUE;
    int _32944 = NOVALUE;
    int _32943 = NOVALUE;
    int _32941 = NOVALUE;
    int _32940 = NOVALUE;
    int _32938 = NOVALUE;
    int _32936 = NOVALUE;
    int _32935 = NOVALUE;
    int _32933 = NOVALUE;
    int _32931 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(seq) then*/
    _32931 = IS_ATOM(_seq_65559);
    if (_32931 == 0)
    {
        _32931 = NOVALUE;
        goto L1; // [6] 15
    }
    else{
        _32931 = NOVALUE;
    }

    /** 		RTFatal("attempt to subscript an atom\n(assigning to it)")*/
    RefDS(_32932);
    _67RTFatal(_32932);
L1: 

    /** 	if sequence(subs) then*/
    _32933 = IS_SEQUENCE(_subs_65560);
    if (_32933 == 0)
    {
        _32933 = NOVALUE;
        goto L2; // [20] 36
    }
    else{
        _32933 = NOVALUE;
    }

    /** 		RTFatal(*/
    if (IS_SEQUENCE(_seq_65559)){
            _32935 = SEQ_PTR(_seq_65559)->length;
    }
    else {
        _32935 = 1;
    }
    _32936 = EPrintf(-9999999, _32934, _32935);
    _32935 = NOVALUE;
    _67RTFatal(_32936);
    _32936 = NOVALUE;
L2: 

    /** 	subs = floor(subs)*/
    _0 = _subs_65560;
    if (IS_ATOM_INT(_subs_65560))
    _subs_65560 = e_floor(_subs_65560);
    else
    _subs_65560 = unary_op(FLOOR, _subs_65560);
    DeRef(_0);

    /** 	if subs < 1 or subs > length(seq) then*/
    if (IS_ATOM_INT(_subs_65560)) {
        _32938 = (_subs_65560 < 1);
    }
    else {
        _32938 = (DBL_PTR(_subs_65560)->dbl < (double)1);
    }
    if (_32938 != 0) {
        goto L3; // [47] 63
    }
    if (IS_SEQUENCE(_seq_65559)){
            _32940 = SEQ_PTR(_seq_65559)->length;
    }
    else {
        _32940 = 1;
    }
    if (IS_ATOM_INT(_subs_65560)) {
        _32941 = (_subs_65560 > _32940);
    }
    else {
        _32941 = (DBL_PTR(_subs_65560)->dbl > (double)_32940);
    }
    _32940 = NOVALUE;
    if (_32941 == 0)
    {
        DeRef(_32941);
        _32941 = NOVALUE;
        goto L4; // [59] 80
    }
    else{
        DeRef(_32941);
        _32941 = NOVALUE;
    }
L3: 

    /** 		RTFatal(*/
    if (IS_SEQUENCE(_seq_65559)){
            _32943 = SEQ_PTR(_seq_65559)->length;
    }
    else {
        _32943 = 1;
    }
    Ref(_subs_65560);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _subs_65560;
    ((int *)_2)[2] = _32943;
    _32944 = MAKE_SEQ(_1);
    _32943 = NOVALUE;
    _32945 = EPrintf(-9999999, _32942, _32944);
    DeRefDS(_32944);
    _32944 = NOVALUE;
    _67RTFatal(_32945);
    _32945 = NOVALUE;
L4: 

    /** end procedure*/
    DeRef(_seq_65559);
    DeRef(_subs_65560);
    DeRef(_32938);
    _32938 = NOVALUE;
    return;
    ;
}


void _67check_slice(int _seq_65581, int _lower_65582, int _upper_65583)
{
    int _len_65584 = NOVALUE;
    int _32976 = NOVALUE;
    int _32974 = NOVALUE;
    int _32973 = NOVALUE;
    int _32972 = NOVALUE;
    int _32971 = NOVALUE;
    int _32969 = NOVALUE;
    int _32968 = NOVALUE;
    int _32967 = NOVALUE;
    int _32963 = NOVALUE;
    int _32961 = NOVALUE;
    int _32960 = NOVALUE;
    int _32951 = NOVALUE;
    int _32946 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if sequence(lower) then*/
    _32946 = IS_SEQUENCE(_lower_65582);
    if (_32946 == 0)
    {
        _32946 = NOVALUE;
        goto L1; // [6] 15
    }
    else{
        _32946 = NOVALUE;
    }

    /** 		RTFatal("slice lower index is not an atom")*/
    RefDS(_32947);
    _67RTFatal(_32947);
L1: 

    /** 	lower = floor(lower)*/
    _0 = _lower_65582;
    if (IS_ATOM_INT(_lower_65582))
    _lower_65582 = e_floor(_lower_65582);
    else
    _lower_65582 = unary_op(FLOOR, _lower_65582);
    DeRef(_0);

    /** 	if lower < 1 then*/
    if (binary_op_a(GREATEREQ, _lower_65582, 1)){
        goto L2; // [22] 32
    }

    /** 		RTFatal("slice lower index is less than 1")*/
    RefDS(_32950);
    _67RTFatal(_32950);
L2: 

    /** 	if sequence(upper) then*/
    _32951 = IS_SEQUENCE(_upper_65583);
    if (_32951 == 0)
    {
        _32951 = NOVALUE;
        goto L3; // [37] 46
    }
    else{
        _32951 = NOVALUE;
    }

    /** 		RTFatal("slice upper index is not an atom")*/
    RefDS(_32952);
    _67RTFatal(_32952);
L3: 

    /** 	upper = floor(upper)*/
    _0 = _upper_65583;
    if (IS_ATOM_INT(_upper_65583))
    _upper_65583 = e_floor(_upper_65583);
    else
    _upper_65583 = unary_op(FLOOR, _upper_65583);
    DeRef(_0);

    /** 	if upper > #FFFF_FFFF then*/
    if (binary_op_a(LESSEQ, _upper_65583, _32954)){
        goto L4; // [53] 63
    }

    /** 		upper = -2147483645*/
    RefDS(_32957);
    DeRef(_upper_65583);
    _upper_65583 = _32957;
L4: 

    /** 	if upper < 0 then*/
    if (binary_op_a(GREATEREQ, _upper_65583, 0)){
        goto L5; // [65] 79
    }

    /** 		RTFatal(sprintf("slice upper index is less than 0 (%d)", upper ) )*/
    _32960 = EPrintf(-9999999, _32959, _upper_65583);
    _67RTFatal(_32960);
    _32960 = NOVALUE;
L5: 

    /** 	if atom(seq) then*/
    _32961 = IS_ATOM(_seq_65581);
    if (_32961 == 0)
    {
        _32961 = NOVALUE;
        goto L6; // [84] 93
    }
    else{
        _32961 = NOVALUE;
    }

    /** 		RTFatal("attempt to slice an atom")*/
    RefDS(_32962);
    _67RTFatal(_32962);
L6: 

    /** 	len = upper - lower + 1*/
    if (IS_ATOM_INT(_upper_65583) && IS_ATOM_INT(_lower_65582)) {
        _32963 = _upper_65583 - _lower_65582;
        if ((long)((unsigned long)_32963 +(unsigned long) HIGH_BITS) >= 0){
            _32963 = NewDouble((double)_32963);
        }
    }
    else {
        _32963 = binary_op(MINUS, _upper_65583, _lower_65582);
    }
    DeRef(_len_65584);
    if (IS_ATOM_INT(_32963)) {
        _len_65584 = _32963 + 1;
        if (_len_65584 > MAXINT){
            _len_65584 = NewDouble((double)_len_65584);
        }
    }
    else
    _len_65584 = binary_op(PLUS, 1, _32963);
    DeRef(_32963);
    _32963 = NOVALUE;

    /** 	if len < 0 then*/
    if (binary_op_a(GREATEREQ, _len_65584, 0)){
        goto L7; // [105] 115
    }

    /** 		RTFatal("slice length is less than 0")*/
    RefDS(_32966);
    _67RTFatal(_32966);
L7: 

    /** 	if lower > length(seq) + 1 or (len > 0 and lower > length(seq)) then*/
    if (IS_SEQUENCE(_seq_65581)){
            _32967 = SEQ_PTR(_seq_65581)->length;
    }
    else {
        _32967 = 1;
    }
    _32968 = _32967 + 1;
    _32967 = NOVALUE;
    if (IS_ATOM_INT(_lower_65582)) {
        _32969 = (_lower_65582 > _32968);
    }
    else {
        _32969 = binary_op(GREATER, _lower_65582, _32968);
    }
    _32968 = NOVALUE;
    if (IS_ATOM_INT(_32969)) {
        if (_32969 != 0) {
            goto L8; // [128] 156
        }
    }
    else {
        if (DBL_PTR(_32969)->dbl != 0.0) {
            goto L8; // [128] 156
        }
    }
    if (IS_ATOM_INT(_len_65584)) {
        _32971 = (_len_65584 > 0);
    }
    else {
        _32971 = (DBL_PTR(_len_65584)->dbl > (double)0);
    }
    if (_32971 == 0) {
        DeRef(_32972);
        _32972 = 0;
        goto L9; // [136] 151
    }
    if (IS_SEQUENCE(_seq_65581)){
            _32973 = SEQ_PTR(_seq_65581)->length;
    }
    else {
        _32973 = 1;
    }
    if (IS_ATOM_INT(_lower_65582)) {
        _32974 = (_lower_65582 > _32973);
    }
    else {
        _32974 = binary_op(GREATER, _lower_65582, _32973);
    }
    _32973 = NOVALUE;
    if (IS_ATOM_INT(_32974))
    _32972 = (_32974 != 0);
    else
    _32972 = DBL_PTR(_32974)->dbl != 0.0;
L9: 
    if (_32972 == 0)
    {
        _32972 = NOVALUE;
        goto LA; // [152] 162
    }
    else{
        _32972 = NOVALUE;
    }
L8: 

    /** 		RTFatal("slice starts past end of sequence")*/
    RefDS(_32975);
    _67RTFatal(_32975);
LA: 

    /** 	if upper > length(seq) then*/
    if (IS_SEQUENCE(_seq_65581)){
            _32976 = SEQ_PTR(_seq_65581)->length;
    }
    else {
        _32976 = 1;
    }
    if (binary_op_a(LESSEQ, _upper_65583, _32976)){
        _32976 = NOVALUE;
        goto LB; // [167] 177
    }
    _32976 = NOVALUE;

    /** 		RTFatal("slice ends past end of sequence")*/
    RefDS(_32978);
    _67RTFatal(_32978);
LB: 

    /** end procedure*/
    DeRef(_seq_65581);
    DeRef(_lower_65582);
    DeRef(_upper_65583);
    DeRef(_len_65584);
    DeRef(_32971);
    _32971 = NOVALUE;
    DeRef(_32969);
    _32969 = NOVALUE;
    DeRef(_32974);
    _32974 = NOVALUE;
    return;
    ;
}


void _67lhs_check_slice(int _seq_65629, int _lower_65630, int _upper_65631, int _rhs_65632)
{
    int _len_65633 = NOVALUE;
    int _32986 = NOVALUE;
    int _32985 = NOVALUE;
    int _32984 = NOVALUE;
    int _32983 = NOVALUE;
    int _32981 = NOVALUE;
    int _32980 = NOVALUE;
    int _32979 = NOVALUE;
    int _0, _1, _2;
    

    /** 	check_slice(seq, lower, upper)*/
    Ref(_seq_65629);
    Ref(_lower_65630);
    Ref(_upper_65631);
    _67check_slice(_seq_65629, _lower_65630, _upper_65631);

    /** 	len = floor(upper) - floor(lower) + 1*/
    if (IS_ATOM_INT(_upper_65631))
    _32979 = e_floor(_upper_65631);
    else
    _32979 = unary_op(FLOOR, _upper_65631);
    if (IS_ATOM_INT(_lower_65630))
    _32980 = e_floor(_lower_65630);
    else
    _32980 = unary_op(FLOOR, _lower_65630);
    if (IS_ATOM_INT(_32979) && IS_ATOM_INT(_32980)) {
        _32981 = _32979 - _32980;
        if ((long)((unsigned long)_32981 +(unsigned long) HIGH_BITS) >= 0){
            _32981 = NewDouble((double)_32981);
        }
    }
    else {
        if (IS_ATOM_INT(_32979)) {
            _32981 = NewDouble((double)_32979 - DBL_PTR(_32980)->dbl);
        }
        else {
            if (IS_ATOM_INT(_32980)) {
                _32981 = NewDouble(DBL_PTR(_32979)->dbl - (double)_32980);
            }
            else
            _32981 = NewDouble(DBL_PTR(_32979)->dbl - DBL_PTR(_32980)->dbl);
        }
    }
    DeRef(_32979);
    _32979 = NOVALUE;
    DeRef(_32980);
    _32980 = NOVALUE;
    DeRef(_len_65633);
    if (IS_ATOM_INT(_32981)) {
        _len_65633 = _32981 + 1;
        if (_len_65633 > MAXINT){
            _len_65633 = NewDouble((double)_len_65633);
        }
    }
    else
    _len_65633 = binary_op(PLUS, 1, _32981);
    DeRef(_32981);
    _32981 = NOVALUE;

    /** 	if sequence(rhs) and length(rhs) != len then*/
    _32983 = IS_SEQUENCE(_rhs_65632);
    if (_32983 == 0) {
        goto L1; // [29] 50
    }
    if (IS_SEQUENCE(_rhs_65632)){
            _32985 = SEQ_PTR(_rhs_65632)->length;
    }
    else {
        _32985 = 1;
    }
    if (IS_ATOM_INT(_len_65633)) {
        _32986 = (_32985 != _len_65633);
    }
    else {
        _32986 = ((double)_32985 != DBL_PTR(_len_65633)->dbl);
    }
    _32985 = NOVALUE;
    if (_32986 == 0)
    {
        DeRef(_32986);
        _32986 = NOVALUE;
        goto L1; // [41] 50
    }
    else{
        DeRef(_32986);
        _32986 = NOVALUE;
    }

    /** 		RTFatal("lengths do not match on assignment to slice")*/
    RefDS(_32987);
    _67RTFatal(_32987);
L1: 

    /** end procedure*/
    DeRef(_seq_65629);
    DeRef(_lower_65630);
    DeRef(_upper_65631);
    DeRef(_rhs_65632);
    DeRef(_len_65633);
    return;
    ;
}


int _67var_slice(int _x_65646, int _subs_65647, int _lower_65648, int _upper_65649)
{
    int _33006 = NOVALUE;
    int _33004 = NOVALUE;
    int _33003 = NOVALUE;
    int _33002 = NOVALUE;
    int _33001 = NOVALUE;
    int _33000 = NOVALUE;
    int _32999 = NOVALUE;
    int _32998 = NOVALUE;
    int _32996 = NOVALUE;
    int _32995 = NOVALUE;
    int _32994 = NOVALUE;
    int _32991 = NOVALUE;
    int _32990 = NOVALUE;
    int _32989 = NOVALUE;
    int _32988 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(x) then*/
    _32988 = IS_ATOM(_x_65646);
    if (_32988 == 0)
    {
        _32988 = NOVALUE;
        goto L1; // [8] 17
    }
    else{
        _32988 = NOVALUE;
    }

    /** 		RTFatal("attempt to subscript an atom\n(reading from it)")*/
    RefDS(_32656);
    _67RTFatal(_32656);
L1: 

    /** 	for i = 1 to length(subs) do*/
    if (IS_SEQUENCE(_subs_65647)){
            _32989 = SEQ_PTR(_subs_65647)->length;
    }
    else {
        _32989 = 1;
    }
    {
        int _i_65653;
        _i_65653 = 1;
L2: 
        if (_i_65653 > _32989){
            goto L3; // [22] 122
        }

        /** 		if sequence(subs[i]) then*/
        _2 = (int)SEQ_PTR(_subs_65647);
        _32990 = (int)*(((s1_ptr)_2)->base + _i_65653);
        _32991 = IS_SEQUENCE(_32990);
        _32990 = NOVALUE;
        if (_32991 == 0)
        {
            _32991 = NOVALUE;
            goto L4; // [38] 47
        }
        else{
            _32991 = NOVALUE;
        }

        /** 			RTFatal("subscript must be an atom")*/
        RefDS(_32992);
        _67RTFatal(_32992);
L4: 

        /** 		subs = floor(subs)*/
        _0 = _subs_65647;
        _subs_65647 = unary_op(FLOOR, _subs_65647);
        DeRefDS(_0);

        /** 		if subs[i] > length(x) or subs[i] < 1 then*/
        _2 = (int)SEQ_PTR(_subs_65647);
        _32994 = (int)*(((s1_ptr)_2)->base + _i_65653);
        if (IS_SEQUENCE(_x_65646)){
                _32995 = SEQ_PTR(_x_65646)->length;
        }
        else {
            _32995 = 1;
        }
        if (IS_ATOM_INT(_32994)) {
            _32996 = (_32994 > _32995);
        }
        else {
            _32996 = binary_op(GREATER, _32994, _32995);
        }
        _32994 = NOVALUE;
        _32995 = NOVALUE;
        if (IS_ATOM_INT(_32996)) {
            if (_32996 != 0) {
                goto L5; // [67] 84
            }
        }
        else {
            if (DBL_PTR(_32996)->dbl != 0.0) {
                goto L5; // [67] 84
            }
        }
        _2 = (int)SEQ_PTR(_subs_65647);
        _32998 = (int)*(((s1_ptr)_2)->base + _i_65653);
        if (IS_ATOM_INT(_32998)) {
            _32999 = (_32998 < 1);
        }
        else {
            _32999 = binary_op(LESS, _32998, 1);
        }
        _32998 = NOVALUE;
        if (_32999 == 0) {
            DeRef(_32999);
            _32999 = NOVALUE;
            goto L6; // [80] 105
        }
        else {
            if (!IS_ATOM_INT(_32999) && DBL_PTR(_32999)->dbl == 0.0){
                DeRef(_32999);
                _32999 = NOVALUE;
                goto L6; // [80] 105
            }
            DeRef(_32999);
            _32999 = NOVALUE;
        }
        DeRef(_32999);
        _32999 = NOVALUE;
L5: 

        /** 			RTFatal(*/
        _2 = (int)SEQ_PTR(_subs_65647);
        _33000 = (int)*(((s1_ptr)_2)->base + _i_65653);
        if (IS_SEQUENCE(_x_65646)){
                _33001 = SEQ_PTR(_x_65646)->length;
        }
        else {
            _33001 = 1;
        }
        Ref(_33000);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _33000;
        ((int *)_2)[2] = _33001;
        _33002 = MAKE_SEQ(_1);
        _33001 = NOVALUE;
        _33000 = NOVALUE;
        _33003 = EPrintf(-9999999, _32664, _33002);
        DeRefDS(_33002);
        _33002 = NOVALUE;
        _67RTFatal(_33003);
        _33003 = NOVALUE;
L6: 

        /** 		x = x[subs[i]]*/
        _2 = (int)SEQ_PTR(_subs_65647);
        _33004 = (int)*(((s1_ptr)_2)->base + _i_65653);
        _0 = _x_65646;
        _2 = (int)SEQ_PTR(_x_65646);
        if (!IS_ATOM_INT(_33004)){
            _x_65646 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_33004)->dbl));
        }
        else{
            _x_65646 = (int)*(((s1_ptr)_2)->base + _33004);
        }
        Ref(_x_65646);
        DeRef(_0);

        /** 	end for*/
        _i_65653 = _i_65653 + 1;
        goto L2; // [117] 29
L3: 
        ;
    }

    /** 	check_slice(x, lower, upper)*/
    Ref(_x_65646);
    Ref(_lower_65648);
    Ref(_upper_65649);
    _67check_slice(_x_65646, _lower_65648, _upper_65649);

    /** 	return x[lower..upper]*/
    rhs_slice_target = (object_ptr)&_33006;
    RHS_Slice(_x_65646, _lower_65648, _upper_65649);
    DeRef(_x_65646);
    DeRefDS(_subs_65647);
    DeRef(_lower_65648);
    DeRef(_upper_65649);
    _33004 = NOVALUE;
    DeRef(_32996);
    _32996 = NOVALUE;
    return _33006;
    ;
}


int _67assign_subs(int _x_65676, int _subs_65677, int _rhs_val_65678)
{
    int _33017 = NOVALUE;
    int _33016 = NOVALUE;
    int _33015 = NOVALUE;
    int _33014 = NOVALUE;
    int _33013 = NOVALUE;
    int _33012 = NOVALUE;
    int _33011 = NOVALUE;
    int _33010 = NOVALUE;
    int _33008 = NOVALUE;
    int _33007 = NOVALUE;
    int _0, _1, _2;
    

    /** 	lhs_check_subs(x, subs[1])*/
    _2 = (int)SEQ_PTR(_subs_65677);
    _33007 = (int)*(((s1_ptr)_2)->base + 1);
    RefDS(_x_65676);
    Ref(_33007);
    _67lhs_check_subs(_x_65676, _33007);
    _33007 = NOVALUE;

    /** 	if length(subs) = 1 then*/
    if (IS_SEQUENCE(_subs_65677)){
            _33008 = SEQ_PTR(_subs_65677)->length;
    }
    else {
        _33008 = 1;
    }
    if (_33008 != 1)
    goto L1; // [20] 37

    /** 		x[subs[1]] = rhs_val*/
    _2 = (int)SEQ_PTR(_subs_65677);
    _33010 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_rhs_val_65678);
    _2 = (int)SEQ_PTR(_x_65676);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _x_65676 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_33010))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_33010)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _33010);
    _1 = *(int *)_2;
    *(int *)_2 = _rhs_val_65678;
    DeRef(_1);
    goto L2; // [34] 73
L1: 

    /** 		x[subs[1]] = assign_subs(x[subs[1]], subs[2..$], rhs_val)*/
    _2 = (int)SEQ_PTR(_subs_65677);
    _33011 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_subs_65677);
    _33012 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_x_65676);
    if (!IS_ATOM_INT(_33012)){
        _33013 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_33012)->dbl));
    }
    else{
        _33013 = (int)*(((s1_ptr)_2)->base + _33012);
    }
    if (IS_SEQUENCE(_subs_65677)){
            _33014 = SEQ_PTR(_subs_65677)->length;
    }
    else {
        _33014 = 1;
    }
    rhs_slice_target = (object_ptr)&_33015;
    RHS_Slice(_subs_65677, 2, _33014);
    Ref(_rhs_val_65678);
    DeRef(_33016);
    _33016 = _rhs_val_65678;
    Ref(_33013);
    _33017 = _67assign_subs(_33013, _33015, _33016);
    _33013 = NOVALUE;
    _33015 = NOVALUE;
    _33016 = NOVALUE;
    _2 = (int)SEQ_PTR(_x_65676);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _x_65676 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_33011))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_33011)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _33011);
    _1 = *(int *)_2;
    *(int *)_2 = _33017;
    if( _1 != _33017 ){
        DeRef(_1);
    }
    _33017 = NOVALUE;
L2: 

    /** 	return x*/
    DeRefDS(_subs_65677);
    DeRef(_rhs_val_65678);
    _33010 = NOVALUE;
    _33011 = NOVALUE;
    _33012 = NOVALUE;
    return _x_65676;
    ;
}


int _67assign_slice(int _x_65694, int _subs_65695, int _lower_65696, int _upper_65697, int _rhs_val_65698)
{
    int _33034 = NOVALUE;
    int _33033 = NOVALUE;
    int _33032 = NOVALUE;
    int _33031 = NOVALUE;
    int _33030 = NOVALUE;
    int _33029 = NOVALUE;
    int _33028 = NOVALUE;
    int _33027 = NOVALUE;
    int _33026 = NOVALUE;
    int _33024 = NOVALUE;
    int _33023 = NOVALUE;
    int _33022 = NOVALUE;
    int _33021 = NOVALUE;
    int _33019 = NOVALUE;
    int _33018 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	lhs_check_subs(x, subs[1])*/
    _2 = (int)SEQ_PTR(_subs_65695);
    _33018 = (int)*(((s1_ptr)_2)->base + 1);
    RefDS(_x_65694);
    Ref(_33018);
    _67lhs_check_subs(_x_65694, _33018);
    _33018 = NOVALUE;

    /** 	if length(subs) = 1 then*/
    if (IS_SEQUENCE(_subs_65695)){
            _33019 = SEQ_PTR(_subs_65695)->length;
    }
    else {
        _33019 = 1;
    }
    if (_33019 != 1)
    goto L1; // [20] 59

    /** 		lhs_check_slice(x[subs[1]],lower,upper,rhs_val)*/
    _2 = (int)SEQ_PTR(_subs_65695);
    _33021 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_x_65694);
    if (!IS_ATOM_INT(_33021)){
        _33022 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_33021)->dbl));
    }
    else{
        _33022 = (int)*(((s1_ptr)_2)->base + _33021);
    }
    Ref(_33022);
    Ref(_lower_65696);
    Ref(_upper_65697);
    Ref(_rhs_val_65698);
    _67lhs_check_slice(_33022, _lower_65696, _upper_65697, _rhs_val_65698);
    _33022 = NOVALUE;

    /** 		x[subs[1]][lower..upper] = rhs_val*/
    _2 = (int)SEQ_PTR(_subs_65695);
    _33023 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_x_65694);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _x_65694 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_33023))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_33023)->dbl));
    else
    _3 = (int)(_33023 + ((s1_ptr)_2)->base);
    assign_slice_seq = (s1_ptr *)_3;
    AssignSlice(_lower_65696, _upper_65697, _rhs_val_65698);
    goto L2; // [56] 103
L1: 

    /** 		x[subs[1]] = assign_slice(x[subs[1]], subs[2..$], lower, upper, rhs_val)*/
    _2 = (int)SEQ_PTR(_subs_65695);
    _33026 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_subs_65695);
    _33027 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_x_65694);
    if (!IS_ATOM_INT(_33027)){
        _33028 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_33027)->dbl));
    }
    else{
        _33028 = (int)*(((s1_ptr)_2)->base + _33027);
    }
    if (IS_SEQUENCE(_subs_65695)){
            _33029 = SEQ_PTR(_subs_65695)->length;
    }
    else {
        _33029 = 1;
    }
    rhs_slice_target = (object_ptr)&_33030;
    RHS_Slice(_subs_65695, 2, _33029);
    Ref(_lower_65696);
    DeRef(_33031);
    _33031 = _lower_65696;
    Ref(_upper_65697);
    DeRef(_33032);
    _33032 = _upper_65697;
    Ref(_rhs_val_65698);
    DeRef(_33033);
    _33033 = _rhs_val_65698;
    Ref(_33028);
    _33034 = _67assign_slice(_33028, _33030, _33031, _33032, _33033);
    _33028 = NOVALUE;
    _33030 = NOVALUE;
    _33031 = NOVALUE;
    _33032 = NOVALUE;
    _33033 = NOVALUE;
    _2 = (int)SEQ_PTR(_x_65694);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _x_65694 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_33026))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_33026)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _33026);
    _1 = *(int *)_2;
    *(int *)_2 = _33034;
    if( _1 != _33034 ){
        DeRef(_1);
    }
    _33034 = NOVALUE;
L2: 

    /** 	return x*/
    DeRefDS(_subs_65695);
    DeRef(_lower_65696);
    DeRef(_upper_65697);
    DeRef(_rhs_val_65698);
    _33021 = NOVALUE;
    _33023 = NOVALUE;
    DeRef(_33024);
    _33024 = NOVALUE;
    _33026 = NOVALUE;
    _33027 = NOVALUE;
    return _x_65694;
    ;
}


void _67opASSIGN_SUBS()
{
    int _x_65720 = NOVALUE;
    int _subs_65721 = NOVALUE;
    int _33048 = NOVALUE;
    int _33045 = NOVALUE;
    int _33042 = NOVALUE;
    int _33040 = NOVALUE;
    int _33039 = NOVALUE;
    int _33037 = NOVALUE;
    int _33035 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	a = Code[pc+1]  -- the sequence*/
    _33035 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _33035);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	b = Code[pc+2]  -- the subscript*/
    _33037 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67b_63481 = (int)*(((s1_ptr)_2)->base + _33037);
    if (!IS_ATOM_INT(_67b_63481)){
        _67b_63481 = (long)DBL_PTR(_67b_63481)->dbl;
    }

    /** 	if sequence(val[b]) then*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _33039 = (int)*(((s1_ptr)_2)->base + _67b_63481);
    _33040 = IS_SEQUENCE(_33039);
    _33039 = NOVALUE;
    if (_33040 == 0)
    {
        _33040 = NOVALUE;
        goto L1; // [46] 55
    }
    else{
        _33040 = NOVALUE;
    }

    /** 		RTFatal("subscript must be an atom\n(assigning to subscript of a sequence)")*/
    RefDS(_33041);
    _67RTFatal(_33041);
L1: 

    /** 	c = Code[pc+3]  -- the RHS value*/
    _33042 = _67pc_63479 + 3;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67c_63482 = (int)*(((s1_ptr)_2)->base + _33042);
    if (!IS_ATOM_INT(_67c_63482)){
        _67c_63482 = (long)DBL_PTR(_67c_63482)->dbl;
    }

    /** 	x = val[a] -- avoid lingering ref count on val[a]*/
    DeRef(_x_65720);
    _2 = (int)SEQ_PTR(_67val_63489);
    _x_65720 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    Ref(_x_65720);

    /** 	lhs_check_subs(x, val[b])*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _33045 = (int)*(((s1_ptr)_2)->base + _67b_63481);
    Ref(_x_65720);
    Ref(_33045);
    _67lhs_check_subs(_x_65720, _33045);
    _33045 = NOVALUE;

    /** 	x = val[c]*/
    DeRef(_x_65720);
    _2 = (int)SEQ_PTR(_67val_63489);
    _x_65720 = (int)*(((s1_ptr)_2)->base + _67c_63482);
    Ref(_x_65720);

    /** 	subs = val[b]*/
    DeRef(_subs_65721);
    _2 = (int)SEQ_PTR(_67val_63489);
    _subs_65721 = (int)*(((s1_ptr)_2)->base + _67b_63481);
    Ref(_subs_65721);

    /** 	val[a][subs] = x  -- single LHS subscript*/
    _2 = (int)SEQ_PTR(_67val_63489);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _67val_63489 = MAKE_SEQ(_2);
    }
    _3 = (int)(_67a_63480 + ((s1_ptr)_2)->base);
    Ref(_x_65720);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_subs_65721))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_subs_65721)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _subs_65721);
    _1 = *(int *)_2;
    *(int *)_2 = _x_65720;
    DeRef(_1);
    _33048 = NOVALUE;

    /** 	pc += 4*/
    _67pc_63479 = _67pc_63479 + 4;

    /** end procedure*/
    DeRef(_x_65720);
    DeRef(_subs_65721);
    DeRef(_33035);
    _33035 = NOVALUE;
    DeRef(_33037);
    _33037 = NOVALUE;
    _33042 = NOVALUE;
    return;
    ;
}


void _67opPASSIGN_SUBS()
{
    int _33068 = NOVALUE;
    int _33067 = NOVALUE;
    int _33066 = NOVALUE;
    int _33065 = NOVALUE;
    int _33064 = NOVALUE;
    int _33062 = NOVALUE;
    int _33061 = NOVALUE;
    int _33059 = NOVALUE;
    int _33057 = NOVALUE;
    int _33056 = NOVALUE;
    int _33055 = NOVALUE;
    int _33053 = NOVALUE;
    int _33051 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _33051 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _33051);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	b = Code[pc+2]  -- subscript*/
    _33053 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67b_63481 = (int)*(((s1_ptr)_2)->base + _33053);
    if (!IS_ATOM_INT(_67b_63481)){
        _67b_63481 = (long)DBL_PTR(_67b_63481)->dbl;
    }

    /** 	if sequence(val[b]) then*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _33055 = (int)*(((s1_ptr)_2)->base + _67b_63481);
    _33056 = IS_SEQUENCE(_33055);
    _33055 = NOVALUE;
    if (_33056 == 0)
    {
        _33056 = NOVALUE;
        goto L1; // [46] 55
    }
    else{
        _33056 = NOVALUE;
    }

    /** 		RTFatal("subscript must be an atom\n(assigning to subscript of a sequence)")*/
    RefDS(_33041);
    _67RTFatal(_33041);
L1: 

    /** 	c = Code[pc+3]  -- RHS value*/
    _33057 = _67pc_63479 + 3;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67c_63482 = (int)*(((s1_ptr)_2)->base + _33057);
    if (!IS_ATOM_INT(_67c_63482)){
        _67c_63482 = (long)DBL_PTR(_67c_63482)->dbl;
    }

    /** 	lhs_seq_index = val[a][1]*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _33059 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    _2 = (int)SEQ_PTR(_33059);
    _67lhs_seq_index_63487 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_67lhs_seq_index_63487)){
        _67lhs_seq_index_63487 = (long)DBL_PTR(_67lhs_seq_index_63487)->dbl;
    }
    _33059 = NOVALUE;

    /** 	lhs_subs = val[a][2..$]*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _33061 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    if (IS_SEQUENCE(_33061)){
            _33062 = SEQ_PTR(_33061)->length;
    }
    else {
        _33062 = 1;
    }
    rhs_slice_target = (object_ptr)&_67lhs_subs_63488;
    RHS_Slice(_33061, 2, _33062);
    _33061 = NOVALUE;

    /** 	val[lhs_seq_index] = assign_subs(val[lhs_seq_index],*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _33064 = (int)*(((s1_ptr)_2)->base + _67lhs_seq_index_63487);
    _2 = (int)SEQ_PTR(_67val_63489);
    _33065 = (int)*(((s1_ptr)_2)->base + _67b_63481);
    if (IS_SEQUENCE(_67lhs_subs_63488) && IS_ATOM(_33065)) {
        Ref(_33065);
        Append(&_33066, _67lhs_subs_63488, _33065);
    }
    else if (IS_ATOM(_67lhs_subs_63488) && IS_SEQUENCE(_33065)) {
    }
    else {
        Concat((object_ptr)&_33066, _67lhs_subs_63488, _33065);
    }
    _33065 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63489);
    _33067 = (int)*(((s1_ptr)_2)->base + _67c_63482);
    Ref(_33064);
    Ref(_33067);
    _33068 = _67assign_subs(_33064, _33066, _33067);
    _33064 = NOVALUE;
    _33066 = NOVALUE;
    _33067 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67lhs_seq_index_63487);
    _1 = *(int *)_2;
    *(int *)_2 = _33068;
    if( _1 != _33068 ){
        DeRef(_1);
    }
    _33068 = NOVALUE;

    /** 	lhs_subs = {}*/
    RefDS(_22037);
    DeRefDS(_67lhs_subs_63488);
    _67lhs_subs_63488 = _22037;

    /** 	pc += 4*/
    _67pc_63479 = _67pc_63479 + 4;

    /** end procedure*/
    DeRef(_33051);
    _33051 = NOVALUE;
    DeRef(_33053);
    _33053 = NOVALUE;
    _33057 = NOVALUE;
    return;
    ;
}


void _67opASSIGN_OP_SUBS()
{
    int _x_65769 = NOVALUE;
    int _33079 = NOVALUE;
    int _33078 = NOVALUE;
    int _33077 = NOVALUE;
    int _33074 = NOVALUE;
    int _33072 = NOVALUE;
    int _33070 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _33070 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _33070);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _33072 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67b_63481 = (int)*(((s1_ptr)_2)->base + _33072);
    if (!IS_ATOM_INT(_67b_63481)){
        _67b_63481 = (long)DBL_PTR(_67b_63481)->dbl;
    }

    /** 	target = Code[pc+3]*/
    _33074 = _67pc_63479 + 3;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67target_63484 = (int)*(((s1_ptr)_2)->base + _33074);
    if (!IS_ATOM_INT(_67target_63484)){
        _67target_63484 = (long)DBL_PTR(_67target_63484)->dbl;
    }

    /** 	lhs_subs = {}*/
    RefDS(_22037);
    DeRef(_67lhs_subs_63488);
    _67lhs_subs_63488 = _22037;

    /** 	x = val[a]*/
    DeRef(_x_65769);
    _2 = (int)SEQ_PTR(_67val_63489);
    _x_65769 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    Ref(_x_65769);

    /** 	val[target] = var_subs(x, lhs_subs & val[b])*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _33077 = (int)*(((s1_ptr)_2)->base + _67b_63481);
    if (IS_SEQUENCE(_67lhs_subs_63488) && IS_ATOM(_33077)) {
        Ref(_33077);
        Append(&_33078, _67lhs_subs_63488, _33077);
    }
    else if (IS_ATOM(_67lhs_subs_63488) && IS_SEQUENCE(_33077)) {
    }
    else {
        Concat((object_ptr)&_33078, _67lhs_subs_63488, _33077);
    }
    _33077 = NOVALUE;
    Ref(_x_65769);
    _33079 = _67var_subs(_x_65769, _33078);
    _33078 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63484);
    _1 = *(int *)_2;
    *(int *)_2 = _33079;
    if( _1 != _33079 ){
        DeRef(_1);
    }
    _33079 = NOVALUE;

    /** 	pc += 4*/
    _67pc_63479 = _67pc_63479 + 4;

    /** end procedure*/
    DeRef(_x_65769);
    _33070 = NOVALUE;
    _33072 = NOVALUE;
    _33074 = NOVALUE;
    return;
    ;
}


void _67opPASSIGN_OP_SUBS()
{
    int _33098 = NOVALUE;
    int _33097 = NOVALUE;
    int _33096 = NOVALUE;
    int _33095 = NOVALUE;
    int _33094 = NOVALUE;
    int _33093 = NOVALUE;
    int _33092 = NOVALUE;
    int _33090 = NOVALUE;
    int _33089 = NOVALUE;
    int _33087 = NOVALUE;
    int _33085 = NOVALUE;
    int _33083 = NOVALUE;
    int _33081 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _33081 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _33081);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _33083 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67b_63481 = (int)*(((s1_ptr)_2)->base + _33083);
    if (!IS_ATOM_INT(_67b_63481)){
        _67b_63481 = (long)DBL_PTR(_67b_63481)->dbl;
    }

    /** 	target = Code[pc+3]*/
    _33085 = _67pc_63479 + 3;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67target_63484 = (int)*(((s1_ptr)_2)->base + _33085);
    if (!IS_ATOM_INT(_67target_63484)){
        _67target_63484 = (long)DBL_PTR(_67target_63484)->dbl;
    }

    /** 	lhs_seq_index = val[a][1]*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _33087 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    _2 = (int)SEQ_PTR(_33087);
    _67lhs_seq_index_63487 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_67lhs_seq_index_63487)){
        _67lhs_seq_index_63487 = (long)DBL_PTR(_67lhs_seq_index_63487)->dbl;
    }
    _33087 = NOVALUE;

    /** 	lhs_subs = val[a][2..$]*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _33089 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    if (IS_SEQUENCE(_33089)){
            _33090 = SEQ_PTR(_33089)->length;
    }
    else {
        _33090 = 1;
    }
    rhs_slice_target = (object_ptr)&_67lhs_subs_63488;
    RHS_Slice(_33089, 2, _33090);
    _33089 = NOVALUE;

    /** 	Code[pc+9] = Code[pc+1] -- patch upcoming op*/
    _33092 = _67pc_63479 + 9;
    if ((long)((unsigned long)_33092 + (unsigned long)HIGH_BITS) >= 0) 
    _33092 = NewDouble((double)_33092);
    _33093 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _33094 = (int)*(((s1_ptr)_2)->base + _33093);
    Ref(_33094);
    _2 = (int)SEQ_PTR(_26Code_12071);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _26Code_12071 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_33092))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_33092)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _33092);
    _1 = *(int *)_2;
    *(int *)_2 = _33094;
    if( _1 != _33094 ){
        DeRef(_1);
    }
    _33094 = NOVALUE;

    /** 	val[target] = var_subs(val[lhs_seq_index], lhs_subs & val[b])*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _33095 = (int)*(((s1_ptr)_2)->base + _67lhs_seq_index_63487);
    _2 = (int)SEQ_PTR(_67val_63489);
    _33096 = (int)*(((s1_ptr)_2)->base + _67b_63481);
    if (IS_SEQUENCE(_67lhs_subs_63488) && IS_ATOM(_33096)) {
        Ref(_33096);
        Append(&_33097, _67lhs_subs_63488, _33096);
    }
    else if (IS_ATOM(_67lhs_subs_63488) && IS_SEQUENCE(_33096)) {
    }
    else {
        Concat((object_ptr)&_33097, _67lhs_subs_63488, _33096);
    }
    _33096 = NOVALUE;
    Ref(_33095);
    _33098 = _67var_subs(_33095, _33097);
    _33095 = NOVALUE;
    _33097 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63484);
    _1 = *(int *)_2;
    *(int *)_2 = _33098;
    if( _1 != _33098 ){
        DeRef(_1);
    }
    _33098 = NOVALUE;

    /** 	lhs_subs = {}*/
    RefDS(_22037);
    DeRefDS(_67lhs_subs_63488);
    _67lhs_subs_63488 = _22037;

    /** 	pc += 4*/
    _67pc_63479 = _67pc_63479 + 4;

    /** end procedure*/
    _33081 = NOVALUE;
    _33083 = NOVALUE;
    _33085 = NOVALUE;
    DeRef(_33092);
    _33092 = NOVALUE;
    _33093 = NOVALUE;
    return;
    ;
}


void _67opASSIGN_OP_SLICE()
{
    int _x_65812 = NOVALUE;
    int _33123 = NOVALUE;
    int _33122 = NOVALUE;
    int _33121 = NOVALUE;
    int _33119 = NOVALUE;
    int _33117 = NOVALUE;
    int _33116 = NOVALUE;
    int _33115 = NOVALUE;
    int _33114 = NOVALUE;
    int _33113 = NOVALUE;
    int _33112 = NOVALUE;
    int _33111 = NOVALUE;
    int _33110 = NOVALUE;
    int _33108 = NOVALUE;
    int _33107 = NOVALUE;
    int _33106 = NOVALUE;
    int _33105 = NOVALUE;
    int _33103 = NOVALUE;
    int _33100 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _33100 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _33100);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	x = val[a]*/
    DeRef(_x_65812);
    _2 = (int)SEQ_PTR(_67val_63489);
    _x_65812 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    Ref(_x_65812);

    /** 	b = Code[pc+2]*/
    _33103 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67b_63481 = (int)*(((s1_ptr)_2)->base + _33103);
    if (!IS_ATOM_INT(_67b_63481)){
        _67b_63481 = (long)DBL_PTR(_67b_63481)->dbl;
    }

    /** 	if floor(val[b]) > length(x) or floor(val[b]) < 1 then*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _33105 = (int)*(((s1_ptr)_2)->base + _67b_63481);
    if (IS_ATOM_INT(_33105))
    _33106 = e_floor(_33105);
    else
    _33106 = unary_op(FLOOR, _33105);
    _33105 = NOVALUE;
    if (IS_SEQUENCE(_x_65812)){
            _33107 = SEQ_PTR(_x_65812)->length;
    }
    else {
        _33107 = 1;
    }
    if (IS_ATOM_INT(_33106)) {
        _33108 = (_33106 > _33107);
    }
    else {
        _33108 = (DBL_PTR(_33106)->dbl > (double)_33107);
    }
    DeRef(_33106);
    _33106 = NOVALUE;
    _33107 = NOVALUE;
    if (_33108 != 0) {
        goto L1; // [63] 87
    }
    _2 = (int)SEQ_PTR(_67val_63489);
    _33110 = (int)*(((s1_ptr)_2)->base + _67b_63481);
    if (IS_ATOM_INT(_33110))
    _33111 = e_floor(_33110);
    else
    _33111 = unary_op(FLOOR, _33110);
    _33110 = NOVALUE;
    if (IS_ATOM_INT(_33111)) {
        _33112 = (_33111 < 1);
    }
    else {
        _33112 = (DBL_PTR(_33111)->dbl < (double)1);
    }
    DeRef(_33111);
    _33111 = NOVALUE;
    if (_33112 == 0)
    {
        DeRef(_33112);
        _33112 = NOVALUE;
        goto L2; // [83] 112
    }
    else{
        DeRef(_33112);
        _33112 = NOVALUE;
    }
L1: 

    /** 		RTFatal(*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _33113 = (int)*(((s1_ptr)_2)->base + _67b_63481);
    if (IS_SEQUENCE(_x_65812)){
            _33114 = SEQ_PTR(_x_65812)->length;
    }
    else {
        _33114 = 1;
    }
    Ref(_33113);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _33113;
    ((int *)_2)[2] = _33114;
    _33115 = MAKE_SEQ(_1);
    _33114 = NOVALUE;
    _33113 = NOVALUE;
    _33116 = EPrintf(-9999999, _32664, _33115);
    DeRefDS(_33115);
    _33115 = NOVALUE;
    _67RTFatal(_33116);
    _33116 = NOVALUE;
L2: 

    /** 	c = Code[pc+3]*/
    _33117 = _67pc_63479 + 3;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67c_63482 = (int)*(((s1_ptr)_2)->base + _33117);
    if (!IS_ATOM_INT(_67c_63482)){
        _67c_63482 = (long)DBL_PTR(_67c_63482)->dbl;
    }

    /** 	target = Code[pc+4]*/
    _33119 = _67pc_63479 + 4;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67target_63484 = (int)*(((s1_ptr)_2)->base + _33119);
    if (!IS_ATOM_INT(_67target_63484)){
        _67target_63484 = (long)DBL_PTR(_67target_63484)->dbl;
    }

    /** 	val[target] = var_slice(x, {}, val[b], val[c])*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _33121 = (int)*(((s1_ptr)_2)->base + _67b_63481);
    _2 = (int)SEQ_PTR(_67val_63489);
    _33122 = (int)*(((s1_ptr)_2)->base + _67c_63482);
    Ref(_x_65812);
    RefDS(_22037);
    Ref(_33121);
    Ref(_33122);
    _33123 = _67var_slice(_x_65812, _22037, _33121, _33122);
    _33121 = NOVALUE;
    _33122 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63484);
    _1 = *(int *)_2;
    *(int *)_2 = _33123;
    if( _1 != _33123 ){
        DeRef(_1);
    }
    _33123 = NOVALUE;

    /** 	pc += 5*/
    _67pc_63479 = _67pc_63479 + 5;

    /** end procedure*/
    DeRef(_x_65812);
    DeRef(_33100);
    _33100 = NOVALUE;
    DeRef(_33103);
    _33103 = NOVALUE;
    _33117 = NOVALUE;
    DeRef(_33108);
    _33108 = NOVALUE;
    _33119 = NOVALUE;
    return;
    ;
}


void _67opPASSIGN_OP_SLICE()
{
    int _x_65845 = NOVALUE;
    int _33143 = NOVALUE;
    int _33142 = NOVALUE;
    int _33141 = NOVALUE;
    int _33140 = NOVALUE;
    int _33139 = NOVALUE;
    int _33138 = NOVALUE;
    int _33137 = NOVALUE;
    int _33135 = NOVALUE;
    int _33132 = NOVALUE;
    int _33130 = NOVALUE;
    int _33128 = NOVALUE;
    int _33125 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _33125 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _33125);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	x = val[a]*/
    DeRef(_x_65845);
    _2 = (int)SEQ_PTR(_67val_63489);
    _x_65845 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    Ref(_x_65845);

    /** 	b = Code[pc+2]*/
    _33128 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67b_63481 = (int)*(((s1_ptr)_2)->base + _33128);
    if (!IS_ATOM_INT(_67b_63481)){
        _67b_63481 = (long)DBL_PTR(_67b_63481)->dbl;
    }

    /** 	c = Code[pc+3]*/
    _33130 = _67pc_63479 + 3;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67c_63482 = (int)*(((s1_ptr)_2)->base + _33130);
    if (!IS_ATOM_INT(_67c_63482)){
        _67c_63482 = (long)DBL_PTR(_67c_63482)->dbl;
    }

    /** 	target = Code[pc+4]*/
    _33132 = _67pc_63479 + 4;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67target_63484 = (int)*(((s1_ptr)_2)->base + _33132);
    if (!IS_ATOM_INT(_67target_63484)){
        _67target_63484 = (long)DBL_PTR(_67target_63484)->dbl;
    }

    /** 	lhs_seq_index = x[1]*/
    _2 = (int)SEQ_PTR(_x_65845);
    _67lhs_seq_index_63487 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_67lhs_seq_index_63487)){
        _67lhs_seq_index_63487 = (long)DBL_PTR(_67lhs_seq_index_63487)->dbl;
    }

    /** 	lhs_subs = x[2..$]*/
    if (IS_SEQUENCE(_x_65845)){
            _33135 = SEQ_PTR(_x_65845)->length;
    }
    else {
        _33135 = 1;
    }
    rhs_slice_target = (object_ptr)&_67lhs_subs_63488;
    RHS_Slice(_x_65845, 2, _33135);

    /** 	Code[pc+10] = Code[pc+1]*/
    _33137 = _67pc_63479 + 10;
    if ((long)((unsigned long)_33137 + (unsigned long)HIGH_BITS) >= 0) 
    _33137 = NewDouble((double)_33137);
    _33138 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _33139 = (int)*(((s1_ptr)_2)->base + _33138);
    Ref(_33139);
    _2 = (int)SEQ_PTR(_26Code_12071);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _26Code_12071 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_33137))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_33137)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _33137);
    _1 = *(int *)_2;
    *(int *)_2 = _33139;
    if( _1 != _33139 ){
        DeRef(_1);
    }
    _33139 = NOVALUE;

    /** 	val[target] = var_slice(val[lhs_seq_index], lhs_subs, val[b], val[c])*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _33140 = (int)*(((s1_ptr)_2)->base + _67lhs_seq_index_63487);
    _2 = (int)SEQ_PTR(_67val_63489);
    _33141 = (int)*(((s1_ptr)_2)->base + _67b_63481);
    _2 = (int)SEQ_PTR(_67val_63489);
    _33142 = (int)*(((s1_ptr)_2)->base + _67c_63482);
    Ref(_33140);
    RefDS(_67lhs_subs_63488);
    Ref(_33141);
    Ref(_33142);
    _33143 = _67var_slice(_33140, _67lhs_subs_63488, _33141, _33142);
    _33140 = NOVALUE;
    _33141 = NOVALUE;
    _33142 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63484);
    _1 = *(int *)_2;
    *(int *)_2 = _33143;
    if( _1 != _33143 ){
        DeRef(_1);
    }
    _33143 = NOVALUE;

    /** 	lhs_subs = {}*/
    RefDS(_22037);
    DeRefDS(_67lhs_subs_63488);
    _67lhs_subs_63488 = _22037;

    /** 	pc += 5*/
    _67pc_63479 = _67pc_63479 + 5;

    /** end procedure*/
    DeRef(_x_65845);
    _33125 = NOVALUE;
    _33128 = NOVALUE;
    _33130 = NOVALUE;
    _33132 = NOVALUE;
    DeRef(_33137);
    _33137 = NOVALUE;
    _33138 = NOVALUE;
    return;
    ;
}


void _67opASSIGN_SLICE()
{
    int _x_65874 = NOVALUE;
    int _33161 = NOVALUE;
    int _33160 = NOVALUE;
    int _33158 = NOVALUE;
    int _33156 = NOVALUE;
    int _33155 = NOVALUE;
    int _33154 = NOVALUE;
    int _33151 = NOVALUE;
    int _33149 = NOVALUE;
    int _33147 = NOVALUE;
    int _33145 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	a = Code[pc+1]  -- sequence*/
    _33145 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _33145);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	b = Code[pc+2]  -- 1st index*/
    _33147 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67b_63481 = (int)*(((s1_ptr)_2)->base + _33147);
    if (!IS_ATOM_INT(_67b_63481)){
        _67b_63481 = (long)DBL_PTR(_67b_63481)->dbl;
    }

    /** 	c = Code[pc+3]  -- 2nd index*/
    _33149 = _67pc_63479 + 3;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67c_63482 = (int)*(((s1_ptr)_2)->base + _33149);
    if (!IS_ATOM_INT(_67c_63482)){
        _67c_63482 = (long)DBL_PTR(_67c_63482)->dbl;
    }

    /** 	d = Code[pc+4]  -- rhs value to assign*/
    _33151 = _67pc_63479 + 4;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67d_63483 = (int)*(((s1_ptr)_2)->base + _33151);
    if (!IS_ATOM_INT(_67d_63483)){
        _67d_63483 = (long)DBL_PTR(_67d_63483)->dbl;
    }

    /** 	x = val[a] -- avoid lingering ref count on val[a]*/
    DeRef(_x_65874);
    _2 = (int)SEQ_PTR(_67val_63489);
    _x_65874 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    Ref(_x_65874);

    /** 	lhs_check_slice(x, val[b], val[c], val[d])*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _33154 = (int)*(((s1_ptr)_2)->base + _67b_63481);
    _2 = (int)SEQ_PTR(_67val_63489);
    _33155 = (int)*(((s1_ptr)_2)->base + _67c_63482);
    _2 = (int)SEQ_PTR(_67val_63489);
    _33156 = (int)*(((s1_ptr)_2)->base + _67d_63483);
    Ref(_x_65874);
    Ref(_33154);
    Ref(_33155);
    Ref(_33156);
    _67lhs_check_slice(_x_65874, _33154, _33155, _33156);
    _33154 = NOVALUE;
    _33155 = NOVALUE;
    _33156 = NOVALUE;

    /** 	x = val[d]*/
    DeRef(_x_65874);
    _2 = (int)SEQ_PTR(_67val_63489);
    _x_65874 = (int)*(((s1_ptr)_2)->base + _67d_63483);
    Ref(_x_65874);

    /** 	val[a][val[b]..val[c]] = x*/
    _2 = (int)SEQ_PTR(_67val_63489);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _67val_63489 = MAKE_SEQ(_2);
    }
    _3 = (int)(_67a_63480 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_67val_63489);
    _33160 = (int)*(((s1_ptr)_2)->base + _67b_63481);
    _2 = (int)SEQ_PTR(_67val_63489);
    _33161 = (int)*(((s1_ptr)_2)->base + _67c_63482);
    assign_slice_seq = (s1_ptr *)_3;
    AssignSlice(_33160, _33161, _x_65874);
    _33160 = NOVALUE;
    _33161 = NOVALUE;

    /** 	pc += 5*/
    _67pc_63479 = _67pc_63479 + 5;

    /** end procedure*/
    DeRef(_x_65874);
    _33145 = NOVALUE;
    _33147 = NOVALUE;
    _33149 = NOVALUE;
    _33151 = NOVALUE;
    _33158 = NOVALUE;
    return;
    ;
}


void _67opPASSIGN_SLICE()
{
    int _33180 = NOVALUE;
    int _33179 = NOVALUE;
    int _33178 = NOVALUE;
    int _33177 = NOVALUE;
    int _33176 = NOVALUE;
    int _33174 = NOVALUE;
    int _33173 = NOVALUE;
    int _33171 = NOVALUE;
    int _33169 = NOVALUE;
    int _33167 = NOVALUE;
    int _33165 = NOVALUE;
    int _33163 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]  -- sequence*/
    _33163 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _33163);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	b = Code[pc+2]  -- 1st index*/
    _33165 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67b_63481 = (int)*(((s1_ptr)_2)->base + _33165);
    if (!IS_ATOM_INT(_67b_63481)){
        _67b_63481 = (long)DBL_PTR(_67b_63481)->dbl;
    }

    /** 	c = Code[pc+3]  -- 2nd index*/
    _33167 = _67pc_63479 + 3;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67c_63482 = (int)*(((s1_ptr)_2)->base + _33167);
    if (!IS_ATOM_INT(_67c_63482)){
        _67c_63482 = (long)DBL_PTR(_67c_63482)->dbl;
    }

    /** 	d = Code[pc+4]  -- rhs value to assign*/
    _33169 = _67pc_63479 + 4;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67d_63483 = (int)*(((s1_ptr)_2)->base + _33169);
    if (!IS_ATOM_INT(_67d_63483)){
        _67d_63483 = (long)DBL_PTR(_67d_63483)->dbl;
    }

    /** 	lhs_seq_index = val[a][1]*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _33171 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    _2 = (int)SEQ_PTR(_33171);
    _67lhs_seq_index_63487 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_67lhs_seq_index_63487)){
        _67lhs_seq_index_63487 = (long)DBL_PTR(_67lhs_seq_index_63487)->dbl;
    }
    _33171 = NOVALUE;

    /** 	lhs_subs = val[a][2..$]*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _33173 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    if (IS_SEQUENCE(_33173)){
            _33174 = SEQ_PTR(_33173)->length;
    }
    else {
        _33174 = 1;
    }
    rhs_slice_target = (object_ptr)&_67lhs_subs_63488;
    RHS_Slice(_33173, 2, _33174);
    _33173 = NOVALUE;

    /** 	val[lhs_seq_index] = assign_slice(val[lhs_seq_index],*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _33176 = (int)*(((s1_ptr)_2)->base + _67lhs_seq_index_63487);
    _2 = (int)SEQ_PTR(_67val_63489);
    _33177 = (int)*(((s1_ptr)_2)->base + _67b_63481);
    _2 = (int)SEQ_PTR(_67val_63489);
    _33178 = (int)*(((s1_ptr)_2)->base + _67c_63482);
    _2 = (int)SEQ_PTR(_67val_63489);
    _33179 = (int)*(((s1_ptr)_2)->base + _67d_63483);
    Ref(_33176);
    RefDS(_67lhs_subs_63488);
    Ref(_33177);
    Ref(_33178);
    Ref(_33179);
    _33180 = _67assign_slice(_33176, _67lhs_subs_63488, _33177, _33178, _33179);
    _33176 = NOVALUE;
    _33177 = NOVALUE;
    _33178 = NOVALUE;
    _33179 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67lhs_seq_index_63487);
    _1 = *(int *)_2;
    *(int *)_2 = _33180;
    if( _1 != _33180 ){
        DeRef(_1);
    }
    _33180 = NOVALUE;

    /** 	lhs_subs = {}*/
    RefDS(_22037);
    DeRefDS(_67lhs_subs_63488);
    _67lhs_subs_63488 = _22037;

    /** 	pc += 5*/
    _67pc_63479 = _67pc_63479 + 5;

    /** end procedure*/
    _33163 = NOVALUE;
    _33165 = NOVALUE;
    _33167 = NOVALUE;
    _33169 = NOVALUE;
    return;
    ;
}


void _67opRHS_SLICE()
{
    int _x_65924 = NOVALUE;
    int _33195 = NOVALUE;
    int _33194 = NOVALUE;
    int _33193 = NOVALUE;
    int _33192 = NOVALUE;
    int _33191 = NOVALUE;
    int _33188 = NOVALUE;
    int _33186 = NOVALUE;
    int _33184 = NOVALUE;
    int _33182 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]  -- sequence*/
    _33182 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _33182);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	b = Code[pc+2]  -- 1st index*/
    _33184 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67b_63481 = (int)*(((s1_ptr)_2)->base + _33184);
    if (!IS_ATOM_INT(_67b_63481)){
        _67b_63481 = (long)DBL_PTR(_67b_63481)->dbl;
    }

    /** 	c = Code[pc+3]  -- 2nd index*/
    _33186 = _67pc_63479 + 3;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67c_63482 = (int)*(((s1_ptr)_2)->base + _33186);
    if (!IS_ATOM_INT(_67c_63482)){
        _67c_63482 = (long)DBL_PTR(_67c_63482)->dbl;
    }

    /** 	target = Code[pc+4]*/
    _33188 = _67pc_63479 + 4;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67target_63484 = (int)*(((s1_ptr)_2)->base + _33188);
    if (!IS_ATOM_INT(_67target_63484)){
        _67target_63484 = (long)DBL_PTR(_67target_63484)->dbl;
    }

    /** 	x = val[a]*/
    DeRef(_x_65924);
    _2 = (int)SEQ_PTR(_67val_63489);
    _x_65924 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    Ref(_x_65924);

    /** 	check_slice(x, val[b], val[c])*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _33191 = (int)*(((s1_ptr)_2)->base + _67b_63481);
    _2 = (int)SEQ_PTR(_67val_63489);
    _33192 = (int)*(((s1_ptr)_2)->base + _67c_63482);
    Ref(_x_65924);
    Ref(_33191);
    Ref(_33192);
    _67check_slice(_x_65924, _33191, _33192);
    _33191 = NOVALUE;
    _33192 = NOVALUE;

    /** 	val[target] = x[val[b]..val[c]]*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _33193 = (int)*(((s1_ptr)_2)->base + _67b_63481);
    _2 = (int)SEQ_PTR(_67val_63489);
    _33194 = (int)*(((s1_ptr)_2)->base + _67c_63482);
    rhs_slice_target = (object_ptr)&_33195;
    RHS_Slice(_x_65924, _33193, _33194);
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63484);
    _1 = *(int *)_2;
    *(int *)_2 = _33195;
    if( _1 != _33195 ){
        DeRef(_1);
    }
    _33195 = NOVALUE;

    /** 	pc += 5*/
    _67pc_63479 = _67pc_63479 + 5;

    /** end procedure*/
    DeRef(_x_65924);
    _33182 = NOVALUE;
    _33184 = NOVALUE;
    _33186 = NOVALUE;
    _33188 = NOVALUE;
    _33193 = NOVALUE;
    _33194 = NOVALUE;
    return;
    ;
}


void _67opTYPE_CHECK()
{
    int _33201 = NOVALUE;
    int _33199 = NOVALUE;
    int _33198 = NOVALUE;
    int _33197 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if val[Code[pc-1]] = 0 then*/
    _33197 = _67pc_63479 - 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _33198 = (int)*(((s1_ptr)_2)->base + _33197);
    _2 = (int)SEQ_PTR(_67val_63489);
    if (!IS_ATOM_INT(_33198)){
        _33199 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_33198)->dbl));
    }
    else{
        _33199 = (int)*(((s1_ptr)_2)->base + _33198);
    }
    if (binary_op_a(NOTEQ, _33199, 0)){
        _33199 = NOVALUE;
        goto L1; // [21] 37
    }
    _33199 = NOVALUE;

    /** 		RTFatalType(pc-2)*/
    _33201 = _67pc_63479 - 2;
    if ((long)((unsigned long)_33201 +(unsigned long) HIGH_BITS) >= 0){
        _33201 = NewDouble((double)_33201);
    }
    _67RTFatalType(_33201);
    _33201 = NOVALUE;
L1: 

    /** 	pc += 1*/
    _67pc_63479 = _67pc_63479 + 1;

    /** end procedure*/
    DeRef(_33197);
    _33197 = NOVALUE;
    _33198 = NOVALUE;
    return;
    ;
}


void _67kill_temp(int _sym_65957)
{
    int _33203 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if sym_mode( sym ) = M_TEMP then*/
    _33203 = _52sym_mode(_sym_65957);
    if (binary_op_a(NOTEQ, _33203, 3)){
        DeRef(_33203);
        _33203 = NOVALUE;
        goto L1; // [11] 26
    }
    DeRef(_33203);
    _33203 = NOVALUE;

    /** 		val[sym] = NOVALUE*/
    Ref(_26NOVALUE_11836);
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _sym_65957);
    _1 = *(int *)_2;
    *(int *)_2 = _26NOVALUE_11836;
    DeRef(_1);
L1: 

    /** end procedure*/
    return;
    ;
}


void _67opIS_AN_INTEGER()
{
    int _33210 = NOVALUE;
    int _33209 = NOVALUE;
    int _33207 = NOVALUE;
    int _33205 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _33205 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _33205);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	target = Code[pc+2]*/
    _33207 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67target_63484 = (int)*(((s1_ptr)_2)->base + _33207);
    if (!IS_ATOM_INT(_67target_63484)){
        _67target_63484 = (long)DBL_PTR(_67target_63484)->dbl;
    }

    /** 	val[target] = integer(val[a])*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _33209 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    if (IS_ATOM_INT(_33209))
    _33210 = 1;
    else if (IS_ATOM_DBL(_33209))
    _33210 = IS_ATOM_INT(DoubleToInt(_33209));
    else
    _33210 = 0;
    _33209 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63484);
    _1 = *(int *)_2;
    *(int *)_2 = _33210;
    if( _1 != _33210 ){
        DeRef(_1);
    }
    _33210 = NOVALUE;

    /** 	kill_temp( a )*/
    _67kill_temp(_67a_63480);

    /** 	pc += 3*/
    _67pc_63479 = _67pc_63479 + 3;

    /** end procedure*/
    _33205 = NOVALUE;
    _33207 = NOVALUE;
    return;
    ;
}


void _67opIS_AN_ATOM()
{
    int _33217 = NOVALUE;
    int _33216 = NOVALUE;
    int _33214 = NOVALUE;
    int _33212 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _33212 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _33212);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	target = Code[pc+2]*/
    _33214 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67target_63484 = (int)*(((s1_ptr)_2)->base + _33214);
    if (!IS_ATOM_INT(_67target_63484)){
        _67target_63484 = (long)DBL_PTR(_67target_63484)->dbl;
    }

    /** 	val[target] = atom(val[a])*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _33216 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    _33217 = IS_ATOM(_33216);
    _33216 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63484);
    _1 = *(int *)_2;
    *(int *)_2 = _33217;
    if( _1 != _33217 ){
        DeRef(_1);
    }
    _33217 = NOVALUE;

    /** 	kill_temp( a )*/
    _67kill_temp(_67a_63480);

    /** 	pc += 3*/
    _67pc_63479 = _67pc_63479 + 3;

    /** end procedure*/
    _33212 = NOVALUE;
    _33214 = NOVALUE;
    return;
    ;
}


void _67opIS_A_SEQUENCE()
{
    int _33224 = NOVALUE;
    int _33223 = NOVALUE;
    int _33221 = NOVALUE;
    int _33219 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _33219 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _33219);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	target = Code[pc+2]*/
    _33221 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67target_63484 = (int)*(((s1_ptr)_2)->base + _33221);
    if (!IS_ATOM_INT(_67target_63484)){
        _67target_63484 = (long)DBL_PTR(_67target_63484)->dbl;
    }

    /** 	val[target] = sequence(val[a])*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _33223 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    _33224 = IS_SEQUENCE(_33223);
    _33223 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63484);
    _1 = *(int *)_2;
    *(int *)_2 = _33224;
    if( _1 != _33224 ){
        DeRef(_1);
    }
    _33224 = NOVALUE;

    /** 	kill_temp( a )*/
    _67kill_temp(_67a_63480);

    /** 	pc += 3*/
    _67pc_63479 = _67pc_63479 + 3;

    /** end procedure*/
    _33219 = NOVALUE;
    _33221 = NOVALUE;
    return;
    ;
}


void _67opIS_AN_OBJECT()
{
    int _33233 = NOVALUE;
    int _33232 = NOVALUE;
    int _33231 = NOVALUE;
    int _33230 = NOVALUE;
    int _33228 = NOVALUE;
    int _33226 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _33226 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _33226);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	target = Code[pc+2]*/
    _33228 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67target_63484 = (int)*(((s1_ptr)_2)->base + _33228);
    if (!IS_ATOM_INT(_67target_63484)){
        _67target_63484 = (long)DBL_PTR(_67target_63484)->dbl;
    }

    /** 	if equal( val[a], NOVALUE ) then*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _33230 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    if (_33230 == _26NOVALUE_11836)
    _33231 = 1;
    else if (IS_ATOM_INT(_33230) && IS_ATOM_INT(_26NOVALUE_11836))
    _33231 = 0;
    else
    _33231 = (compare(_33230, _26NOVALUE_11836) == 0);
    _33230 = NOVALUE;
    if (_33231 == 0)
    {
        _33231 = NOVALUE;
        goto L1; // [49] 65
    }
    else{
        _33231 = NOVALUE;
    }

    /** 		val[target] = 0*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63484);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    goto L2; // [62] 87
L1: 

    /** 		val[target] = object( val[a] )*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _33232 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    if( NOVALUE == _33232 ){
        _33233 = 0;
    }
    else{
        if (IS_ATOM_INT(_33232))
        _33233 = 1;
        else if (IS_ATOM_DBL(_33232)) {
             if (IS_ATOM_INT(DoubleToInt(_33232))) {
                 _33233 = 1;
                 } else {
                     _33233 = 2;
                } } else if (IS_SEQUENCE(_33232))
                _33233 = 3;
                else
                _33233 = 0;
            }
            _33232 = NOVALUE;
            _2 = (int)SEQ_PTR(_67val_63489);
            _2 = (int)(((s1_ptr)_2)->base + _67target_63484);
            _1 = *(int *)_2;
            *(int *)_2 = _33233;
            if( _1 != _33233 ){
                DeRef(_1);
            }
            _33233 = NOVALUE;
L2: 

            /** 	kill_temp( a )*/
            _67kill_temp(_67a_63480);

            /** 	pc += 3*/
            _67pc_63479 = _67pc_63479 + 3;

            /** end procedure*/
            DeRef(_33226);
            _33226 = NOVALUE;
            DeRef(_33228);
            _33228 = NOVALUE;
            return;
    ;
}


void _67opSQRT()
{
    int _33240 = NOVALUE;
    int _33239 = NOVALUE;
    int _33237 = NOVALUE;
    int _33235 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _33235 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _33235);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	target = Code[pc+2]*/
    _33237 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67target_63484 = (int)*(((s1_ptr)_2)->base + _33237);
    if (!IS_ATOM_INT(_67target_63484)){
        _67target_63484 = (long)DBL_PTR(_67target_63484)->dbl;
    }

    /** 	val[target] = sqrt(val[a])*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _33239 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    if (IS_ATOM_INT(_33239))
    _33240 = e_sqrt(_33239);
    else
    _33240 = unary_op(SQRT, _33239);
    _33239 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63484);
    _1 = *(int *)_2;
    *(int *)_2 = _33240;
    if( _1 != _33240 ){
        DeRef(_1);
    }
    _33240 = NOVALUE;

    /** 	pc += 3*/
    _67pc_63479 = _67pc_63479 + 3;

    /** end procedure*/
    _33235 = NOVALUE;
    _33237 = NOVALUE;
    return;
    ;
}


void _67opSIN()
{
    int _33247 = NOVALUE;
    int _33246 = NOVALUE;
    int _33244 = NOVALUE;
    int _33242 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _33242 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _33242);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	target = Code[pc+2]*/
    _33244 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67target_63484 = (int)*(((s1_ptr)_2)->base + _33244);
    if (!IS_ATOM_INT(_67target_63484)){
        _67target_63484 = (long)DBL_PTR(_67target_63484)->dbl;
    }

    /** 	val[target] = sin(val[a])*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _33246 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    if (IS_ATOM_INT(_33246))
    _33247 = e_sin(_33246);
    else
    _33247 = unary_op(SIN, _33246);
    _33246 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63484);
    _1 = *(int *)_2;
    *(int *)_2 = _33247;
    if( _1 != _33247 ){
        DeRef(_1);
    }
    _33247 = NOVALUE;

    /** 	pc += 3*/
    _67pc_63479 = _67pc_63479 + 3;

    /** end procedure*/
    _33242 = NOVALUE;
    _33244 = NOVALUE;
    return;
    ;
}


void _67opCOS()
{
    int _33254 = NOVALUE;
    int _33253 = NOVALUE;
    int _33251 = NOVALUE;
    int _33249 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _33249 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _33249);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	target = Code[pc+2]*/
    _33251 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67target_63484 = (int)*(((s1_ptr)_2)->base + _33251);
    if (!IS_ATOM_INT(_67target_63484)){
        _67target_63484 = (long)DBL_PTR(_67target_63484)->dbl;
    }

    /** 	val[target] = cos(val[a])*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _33253 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    if (IS_ATOM_INT(_33253))
    _33254 = e_cos(_33253);
    else
    _33254 = unary_op(COS, _33253);
    _33253 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63484);
    _1 = *(int *)_2;
    *(int *)_2 = _33254;
    if( _1 != _33254 ){
        DeRef(_1);
    }
    _33254 = NOVALUE;

    /** 	pc += 3*/
    _67pc_63479 = _67pc_63479 + 3;

    /** end procedure*/
    _33249 = NOVALUE;
    _33251 = NOVALUE;
    return;
    ;
}


void _67opTAN()
{
    int _33261 = NOVALUE;
    int _33260 = NOVALUE;
    int _33258 = NOVALUE;
    int _33256 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _33256 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _33256);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	target = Code[pc+2]*/
    _33258 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67target_63484 = (int)*(((s1_ptr)_2)->base + _33258);
    if (!IS_ATOM_INT(_67target_63484)){
        _67target_63484 = (long)DBL_PTR(_67target_63484)->dbl;
    }

    /** 	val[target] = tan(val[a])*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _33260 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    if (IS_ATOM_INT(_33260))
    _33261 = e_tan(_33260);
    else
    _33261 = unary_op(TAN, _33260);
    _33260 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63484);
    _1 = *(int *)_2;
    *(int *)_2 = _33261;
    if( _1 != _33261 ){
        DeRef(_1);
    }
    _33261 = NOVALUE;

    /** 	pc += 3*/
    _67pc_63479 = _67pc_63479 + 3;

    /** end procedure*/
    _33256 = NOVALUE;
    _33258 = NOVALUE;
    return;
    ;
}


void _67opARCTAN()
{
    int _33268 = NOVALUE;
    int _33267 = NOVALUE;
    int _33265 = NOVALUE;
    int _33263 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _33263 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _33263);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	target = Code[pc+2]*/
    _33265 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67target_63484 = (int)*(((s1_ptr)_2)->base + _33265);
    if (!IS_ATOM_INT(_67target_63484)){
        _67target_63484 = (long)DBL_PTR(_67target_63484)->dbl;
    }

    /** 	val[target] = arctan(val[a])*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _33267 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    if (IS_ATOM_INT(_33267))
    _33268 = e_arctan(_33267);
    else
    _33268 = unary_op(ARCTAN, _33267);
    _33267 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63484);
    _1 = *(int *)_2;
    *(int *)_2 = _33268;
    if( _1 != _33268 ){
        DeRef(_1);
    }
    _33268 = NOVALUE;

    /** 	pc += 3*/
    _67pc_63479 = _67pc_63479 + 3;

    /** end procedure*/
    _33263 = NOVALUE;
    _33265 = NOVALUE;
    return;
    ;
}


void _67opLOG()
{
    int _33275 = NOVALUE;
    int _33274 = NOVALUE;
    int _33272 = NOVALUE;
    int _33270 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _33270 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _33270);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	target = Code[pc+2]*/
    _33272 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67target_63484 = (int)*(((s1_ptr)_2)->base + _33272);
    if (!IS_ATOM_INT(_67target_63484)){
        _67target_63484 = (long)DBL_PTR(_67target_63484)->dbl;
    }

    /** 	val[target] = log(val[a])*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _33274 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    if (IS_ATOM_INT(_33274))
    _33275 = e_log(_33274);
    else
    _33275 = unary_op(LOG, _33274);
    _33274 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63484);
    _1 = *(int *)_2;
    *(int *)_2 = _33275;
    if( _1 != _33275 ){
        DeRef(_1);
    }
    _33275 = NOVALUE;

    /** 	pc += 3*/
    _67pc_63479 = _67pc_63479 + 3;

    /** end procedure*/
    _33270 = NOVALUE;
    _33272 = NOVALUE;
    return;
    ;
}


void _67opNOT_BITS()
{
    int _33282 = NOVALUE;
    int _33281 = NOVALUE;
    int _33279 = NOVALUE;
    int _33277 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _33277 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _33277);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	target = Code[pc+2]*/
    _33279 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67target_63484 = (int)*(((s1_ptr)_2)->base + _33279);
    if (!IS_ATOM_INT(_67target_63484)){
        _67target_63484 = (long)DBL_PTR(_67target_63484)->dbl;
    }

    /** 	val[target] = not_bits(val[a])*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _33281 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    if (IS_ATOM_INT(_33281))
    _33282 = not_bits(_33281);
    else
    _33282 = unary_op(NOT_BITS, _33281);
    _33281 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63484);
    _1 = *(int *)_2;
    *(int *)_2 = _33282;
    if( _1 != _33282 ){
        DeRef(_1);
    }
    _33282 = NOVALUE;

    /** 	pc += 3*/
    _67pc_63479 = _67pc_63479 + 3;

    /** end procedure*/
    _33277 = NOVALUE;
    _33279 = NOVALUE;
    return;
    ;
}


void _67opFLOOR()
{
    int _33289 = NOVALUE;
    int _33288 = NOVALUE;
    int _33286 = NOVALUE;
    int _33284 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _33284 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _33284);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	target = Code[pc+2]*/
    _33286 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67target_63484 = (int)*(((s1_ptr)_2)->base + _33286);
    if (!IS_ATOM_INT(_67target_63484)){
        _67target_63484 = (long)DBL_PTR(_67target_63484)->dbl;
    }

    /** 	val[target] = floor(val[a])*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _33288 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    if (IS_ATOM_INT(_33288))
    _33289 = e_floor(_33288);
    else
    _33289 = unary_op(FLOOR, _33288);
    _33288 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63484);
    _1 = *(int *)_2;
    *(int *)_2 = _33289;
    if( _1 != _33289 ){
        DeRef(_1);
    }
    _33289 = NOVALUE;

    /** 	pc += 3*/
    _67pc_63479 = _67pc_63479 + 3;

    /** end procedure*/
    _33284 = NOVALUE;
    _33286 = NOVALUE;
    return;
    ;
}


void _67opNOT_IFW()
{
    int _33296 = NOVALUE;
    int _33293 = NOVALUE;
    int _33291 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _33291 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _33291);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	if val[a] = 0 then*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _33293 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    if (binary_op_a(NOTEQ, _33293, 0)){
        _33293 = NOVALUE;
        goto L1; // [27] 42
    }
    _33293 = NOVALUE;

    /** 		pc += 3*/
    _67pc_63479 = _67pc_63479 + 3;
    goto L2; // [39] 59
L1: 

    /** 		pc = Code[pc+2]*/
    _33296 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67pc_63479 = (int)*(((s1_ptr)_2)->base + _33296);
    if (!IS_ATOM_INT(_67pc_63479)){
        _67pc_63479 = (long)DBL_PTR(_67pc_63479)->dbl;
    }
L2: 

    /** end procedure*/
    DeRef(_33291);
    _33291 = NOVALUE;
    DeRef(_33296);
    _33296 = NOVALUE;
    return;
    ;
}


void _67opNOT()
{
    int _33303 = NOVALUE;
    int _33302 = NOVALUE;
    int _33300 = NOVALUE;
    int _33298 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _33298 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _33298);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	target = Code[pc+2]*/
    _33300 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67target_63484 = (int)*(((s1_ptr)_2)->base + _33300);
    if (!IS_ATOM_INT(_67target_63484)){
        _67target_63484 = (long)DBL_PTR(_67target_63484)->dbl;
    }

    /** 	val[target] = not val[a]*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _33302 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    if (IS_ATOM_INT(_33302)) {
        _33303 = (_33302 == 0);
    }
    else {
        _33303 = unary_op(NOT, _33302);
    }
    _33302 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63484);
    _1 = *(int *)_2;
    *(int *)_2 = _33303;
    if( _1 != _33303 ){
        DeRef(_1);
    }
    _33303 = NOVALUE;

    /** 	pc += 3*/
    _67pc_63479 = _67pc_63479 + 3;

    /** end procedure*/
    _33298 = NOVALUE;
    _33300 = NOVALUE;
    return;
    ;
}


void _67opUMINUS()
{
    int _33310 = NOVALUE;
    int _33309 = NOVALUE;
    int _33307 = NOVALUE;
    int _33305 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _33305 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _33305);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	target = Code[pc+2]*/
    _33307 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67target_63484 = (int)*(((s1_ptr)_2)->base + _33307);
    if (!IS_ATOM_INT(_67target_63484)){
        _67target_63484 = (long)DBL_PTR(_67target_63484)->dbl;
    }

    /** 	val[target] = -val[a]*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _33309 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    if (IS_ATOM_INT(_33309)) {
        if ((unsigned long)_33309 == 0xC0000000)
        _33310 = (int)NewDouble((double)-0xC0000000);
        else
        _33310 = - _33309;
    }
    else {
        _33310 = unary_op(UMINUS, _33309);
    }
    _33309 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63484);
    _1 = *(int *)_2;
    *(int *)_2 = _33310;
    if( _1 != _33310 ){
        DeRef(_1);
    }
    _33310 = NOVALUE;

    /** 	pc += 3*/
    _67pc_63479 = _67pc_63479 + 3;

    /** end procedure*/
    _33305 = NOVALUE;
    _33307 = NOVALUE;
    return;
    ;
}


void _67opRAND()
{
    int _33317 = NOVALUE;
    int _33316 = NOVALUE;
    int _33314 = NOVALUE;
    int _33312 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _33312 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _33312);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	target = Code[pc+2]*/
    _33314 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67target_63484 = (int)*(((s1_ptr)_2)->base + _33314);
    if (!IS_ATOM_INT(_67target_63484)){
        _67target_63484 = (long)DBL_PTR(_67target_63484)->dbl;
    }

    /** 	val[target] = rand(val[a])*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _33316 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    if (IS_ATOM_INT(_33316)) {
        _33317 = good_rand() % ((unsigned)_33316) + 1;
    }
    else {
        _33317 = unary_op(RAND, _33316);
    }
    _33316 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63484);
    _1 = *(int *)_2;
    *(int *)_2 = _33317;
    if( _1 != _33317 ){
        DeRef(_1);
    }
    _33317 = NOVALUE;

    /** 	pc += 3*/
    _67pc_63479 = _67pc_63479 + 3;

    /** end procedure*/
    _33312 = NOVALUE;
    _33314 = NOVALUE;
    return;
    ;
}


void _67opDIV2()
{
    int _33324 = NOVALUE;
    int _33323 = NOVALUE;
    int _33321 = NOVALUE;
    int _33319 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _33319 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _33319);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	target = Code[pc+3]*/
    _33321 = _67pc_63479 + 3;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67target_63484 = (int)*(((s1_ptr)_2)->base + _33321);
    if (!IS_ATOM_INT(_67target_63484)){
        _67target_63484 = (long)DBL_PTR(_67target_63484)->dbl;
    }

    /** 	val[target] = val[a] / 2*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _33323 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    if (IS_ATOM_INT(_33323)) {
        if (_33323 & 1) {
            _33324 = NewDouble((_33323 >> 1) + 0.5);
        }
        else
        _33324 = _33323 >> 1;
    }
    else {
        _33324 = binary_op(DIVIDE, _33323, 2);
    }
    _33323 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63484);
    _1 = *(int *)_2;
    *(int *)_2 = _33324;
    if( _1 != _33324 ){
        DeRef(_1);
    }
    _33324 = NOVALUE;

    /** 	pc += 4*/
    _67pc_63479 = _67pc_63479 + 4;

    /** end procedure*/
    _33319 = NOVALUE;
    _33321 = NOVALUE;
    return;
    ;
}


void _67opFLOOR_DIV2()
{
    int _33331 = NOVALUE;
    int _33330 = NOVALUE;
    int _33328 = NOVALUE;
    int _33326 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _33326 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _33326);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	target = Code[pc+3]*/
    _33328 = _67pc_63479 + 3;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67target_63484 = (int)*(((s1_ptr)_2)->base + _33328);
    if (!IS_ATOM_INT(_67target_63484)){
        _67target_63484 = (long)DBL_PTR(_67target_63484)->dbl;
    }

    /** 	val[target] = floor(val[a] / 2)*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _33330 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    if (IS_ATOM_INT(_33330)) {
        _33331 = _33330 >> 1;
    }
    else {
        _1 = binary_op(DIVIDE, _33330, 2);
        _33331 = unary_op(FLOOR, _1);
        DeRef(_1);
    }
    _33330 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63484);
    _1 = *(int *)_2;
    *(int *)_2 = _33331;
    if( _1 != _33331 ){
        DeRef(_1);
    }
    _33331 = NOVALUE;

    /** 	pc += 4*/
    _67pc_63479 = _67pc_63479 + 4;

    /** end procedure*/
    _33326 = NOVALUE;
    _33328 = NOVALUE;
    return;
    ;
}


void _67opGREATER_IFW()
{
    int _33341 = NOVALUE;
    int _33338 = NOVALUE;
    int _33337 = NOVALUE;
    int _33335 = NOVALUE;
    int _33333 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _33333 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _33333);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _33335 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67b_63481 = (int)*(((s1_ptr)_2)->base + _33335);
    if (!IS_ATOM_INT(_67b_63481)){
        _67b_63481 = (long)DBL_PTR(_67b_63481)->dbl;
    }

    /** 	if val[a] > val[b] then*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _33337 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    _2 = (int)SEQ_PTR(_67val_63489);
    _33338 = (int)*(((s1_ptr)_2)->base + _67b_63481);
    if (binary_op_a(LESSEQ, _33337, _33338)){
        _33337 = NOVALUE;
        _33338 = NOVALUE;
        goto L1; // [51] 66
    }
    _33337 = NOVALUE;
    _33338 = NOVALUE;

    /** 		pc += 4*/
    _67pc_63479 = _67pc_63479 + 4;
    goto L2; // [63] 83
L1: 

    /** 		pc = Code[pc+3]*/
    _33341 = _67pc_63479 + 3;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67pc_63479 = (int)*(((s1_ptr)_2)->base + _33341);
    if (!IS_ATOM_INT(_67pc_63479)){
        _67pc_63479 = (long)DBL_PTR(_67pc_63479)->dbl;
    }
L2: 

    /** end procedure*/
    DeRef(_33333);
    _33333 = NOVALUE;
    DeRef(_33335);
    _33335 = NOVALUE;
    DeRef(_33341);
    _33341 = NOVALUE;
    return;
    ;
}


void _67opNOTEQ_IFW()
{
    int _33351 = NOVALUE;
    int _33348 = NOVALUE;
    int _33347 = NOVALUE;
    int _33345 = NOVALUE;
    int _33343 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _33343 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _33343);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _33345 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67b_63481 = (int)*(((s1_ptr)_2)->base + _33345);
    if (!IS_ATOM_INT(_67b_63481)){
        _67b_63481 = (long)DBL_PTR(_67b_63481)->dbl;
    }

    /** 	if val[a] != val[b] then*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _33347 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    _2 = (int)SEQ_PTR(_67val_63489);
    _33348 = (int)*(((s1_ptr)_2)->base + _67b_63481);
    if (binary_op_a(EQUALS, _33347, _33348)){
        _33347 = NOVALUE;
        _33348 = NOVALUE;
        goto L1; // [51] 66
    }
    _33347 = NOVALUE;
    _33348 = NOVALUE;

    /** 		pc += 4*/
    _67pc_63479 = _67pc_63479 + 4;
    goto L2; // [63] 83
L1: 

    /** 		pc = Code[pc+3]*/
    _33351 = _67pc_63479 + 3;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67pc_63479 = (int)*(((s1_ptr)_2)->base + _33351);
    if (!IS_ATOM_INT(_67pc_63479)){
        _67pc_63479 = (long)DBL_PTR(_67pc_63479)->dbl;
    }
L2: 

    /** end procedure*/
    DeRef(_33343);
    _33343 = NOVALUE;
    DeRef(_33345);
    _33345 = NOVALUE;
    DeRef(_33351);
    _33351 = NOVALUE;
    return;
    ;
}


void _67opLESSEQ_IFW()
{
    int _33361 = NOVALUE;
    int _33358 = NOVALUE;
    int _33357 = NOVALUE;
    int _33355 = NOVALUE;
    int _33353 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _33353 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _33353);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _33355 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67b_63481 = (int)*(((s1_ptr)_2)->base + _33355);
    if (!IS_ATOM_INT(_67b_63481)){
        _67b_63481 = (long)DBL_PTR(_67b_63481)->dbl;
    }

    /** 	if val[a] <= val[b] then*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _33357 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    _2 = (int)SEQ_PTR(_67val_63489);
    _33358 = (int)*(((s1_ptr)_2)->base + _67b_63481);
    if (binary_op_a(GREATER, _33357, _33358)){
        _33357 = NOVALUE;
        _33358 = NOVALUE;
        goto L1; // [51] 66
    }
    _33357 = NOVALUE;
    _33358 = NOVALUE;

    /** 		pc += 4*/
    _67pc_63479 = _67pc_63479 + 4;
    goto L2; // [63] 83
L1: 

    /** 		pc = Code[pc+3]*/
    _33361 = _67pc_63479 + 3;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67pc_63479 = (int)*(((s1_ptr)_2)->base + _33361);
    if (!IS_ATOM_INT(_67pc_63479)){
        _67pc_63479 = (long)DBL_PTR(_67pc_63479)->dbl;
    }
L2: 

    /** end procedure*/
    DeRef(_33353);
    _33353 = NOVALUE;
    DeRef(_33355);
    _33355 = NOVALUE;
    DeRef(_33361);
    _33361 = NOVALUE;
    return;
    ;
}


void _67opGREATEREQ_IFW()
{
    int _33371 = NOVALUE;
    int _33368 = NOVALUE;
    int _33367 = NOVALUE;
    int _33365 = NOVALUE;
    int _33363 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _33363 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _33363);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _33365 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67b_63481 = (int)*(((s1_ptr)_2)->base + _33365);
    if (!IS_ATOM_INT(_67b_63481)){
        _67b_63481 = (long)DBL_PTR(_67b_63481)->dbl;
    }

    /** 	if val[a] >= val[b] then*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _33367 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    _2 = (int)SEQ_PTR(_67val_63489);
    _33368 = (int)*(((s1_ptr)_2)->base + _67b_63481);
    if (binary_op_a(LESS, _33367, _33368)){
        _33367 = NOVALUE;
        _33368 = NOVALUE;
        goto L1; // [51] 66
    }
    _33367 = NOVALUE;
    _33368 = NOVALUE;

    /** 		pc += 4*/
    _67pc_63479 = _67pc_63479 + 4;
    goto L2; // [63] 83
L1: 

    /** 		pc = Code[pc+3]*/
    _33371 = _67pc_63479 + 3;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67pc_63479 = (int)*(((s1_ptr)_2)->base + _33371);
    if (!IS_ATOM_INT(_67pc_63479)){
        _67pc_63479 = (long)DBL_PTR(_67pc_63479)->dbl;
    }
L2: 

    /** end procedure*/
    DeRef(_33363);
    _33363 = NOVALUE;
    DeRef(_33365);
    _33365 = NOVALUE;
    DeRef(_33371);
    _33371 = NOVALUE;
    return;
    ;
}


void _67opEQUALS_IFW()
{
    int _33387 = NOVALUE;
    int _33384 = NOVALUE;
    int _33383 = NOVALUE;
    int _33381 = NOVALUE;
    int _33380 = NOVALUE;
    int _33378 = NOVALUE;
    int _33377 = NOVALUE;
    int _33375 = NOVALUE;
    int _33373 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _33373 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _33373);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _33375 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67b_63481 = (int)*(((s1_ptr)_2)->base + _33375);
    if (!IS_ATOM_INT(_67b_63481)){
        _67b_63481 = (long)DBL_PTR(_67b_63481)->dbl;
    }

    /** 	if sequence( val[a] ) or sequence( val[b] ) then*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _33377 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    _33378 = IS_SEQUENCE(_33377);
    _33377 = NOVALUE;
    if (_33378 != 0) {
        goto L1; // [46] 66
    }
    _2 = (int)SEQ_PTR(_67val_63489);
    _33380 = (int)*(((s1_ptr)_2)->base + _67b_63481);
    _33381 = IS_SEQUENCE(_33380);
    _33380 = NOVALUE;
    if (_33381 == 0)
    {
        _33381 = NOVALUE;
        goto L2; // [62] 72
    }
    else{
        _33381 = NOVALUE;
    }
L1: 

    /** 		RTFatal("true/false condition must be an ATOM")*/
    RefDS(_33382);
    _67RTFatal(_33382);
L2: 

    /** 	if val[a] = val[b] then*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _33383 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    _2 = (int)SEQ_PTR(_67val_63489);
    _33384 = (int)*(((s1_ptr)_2)->base + _67b_63481);
    if (binary_op_a(NOTEQ, _33383, _33384)){
        _33383 = NOVALUE;
        _33384 = NOVALUE;
        goto L3; // [90] 105
    }
    _33383 = NOVALUE;
    _33384 = NOVALUE;

    /** 		pc += 4*/
    _67pc_63479 = _67pc_63479 + 4;
    goto L4; // [102] 122
L3: 

    /** 		pc = Code[pc+3]*/
    _33387 = _67pc_63479 + 3;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67pc_63479 = (int)*(((s1_ptr)_2)->base + _33387);
    if (!IS_ATOM_INT(_67pc_63479)){
        _67pc_63479 = (long)DBL_PTR(_67pc_63479)->dbl;
    }
L4: 

    /** end procedure*/
    DeRef(_33373);
    _33373 = NOVALUE;
    DeRef(_33375);
    _33375 = NOVALUE;
    DeRef(_33387);
    _33387 = NOVALUE;
    return;
    ;
}


void _67opLESS_IFW()
{
    int _33397 = NOVALUE;
    int _33394 = NOVALUE;
    int _33393 = NOVALUE;
    int _33391 = NOVALUE;
    int _33389 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _33389 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _33389);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _33391 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67b_63481 = (int)*(((s1_ptr)_2)->base + _33391);
    if (!IS_ATOM_INT(_67b_63481)){
        _67b_63481 = (long)DBL_PTR(_67b_63481)->dbl;
    }

    /** 	if val[a] < val[b] then*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _33393 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    _2 = (int)SEQ_PTR(_67val_63489);
    _33394 = (int)*(((s1_ptr)_2)->base + _67b_63481);
    if (binary_op_a(GREATEREQ, _33393, _33394)){
        _33393 = NOVALUE;
        _33394 = NOVALUE;
        goto L1; // [51] 66
    }
    _33393 = NOVALUE;
    _33394 = NOVALUE;

    /** 		pc += 4*/
    _67pc_63479 = _67pc_63479 + 4;
    goto L2; // [63] 83
L1: 

    /** 		pc = Code[pc+3]*/
    _33397 = _67pc_63479 + 3;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67pc_63479 = (int)*(((s1_ptr)_2)->base + _33397);
    if (!IS_ATOM_INT(_67pc_63479)){
        _67pc_63479 = (long)DBL_PTR(_67pc_63479)->dbl;
    }
L2: 

    /** end procedure*/
    DeRef(_33389);
    _33389 = NOVALUE;
    DeRef(_33391);
    _33391 = NOVALUE;
    DeRef(_33397);
    _33397 = NOVALUE;
    return;
    ;
}


void _67opMULTIPLY()
{
    int _33407 = NOVALUE;
    int _33406 = NOVALUE;
    int _33405 = NOVALUE;
    int _33403 = NOVALUE;
    int _33401 = NOVALUE;
    int _33399 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _33399 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _33399);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _33401 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67b_63481 = (int)*(((s1_ptr)_2)->base + _33401);
    if (!IS_ATOM_INT(_67b_63481)){
        _67b_63481 = (long)DBL_PTR(_67b_63481)->dbl;
    }

    /** 	target = Code[pc+3]*/
    _33403 = _67pc_63479 + 3;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67target_63484 = (int)*(((s1_ptr)_2)->base + _33403);
    if (!IS_ATOM_INT(_67target_63484)){
        _67target_63484 = (long)DBL_PTR(_67target_63484)->dbl;
    }

    /** 	val[target] = val[a] * val[b]*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _33405 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    _2 = (int)SEQ_PTR(_67val_63489);
    _33406 = (int)*(((s1_ptr)_2)->base + _67b_63481);
    if (IS_ATOM_INT(_33405) && IS_ATOM_INT(_33406)) {
        if (_33405 == (short)_33405 && _33406 <= INT15 && _33406 >= -INT15)
        _33407 = _33405 * _33406;
        else
        _33407 = NewDouble(_33405 * (double)_33406);
    }
    else {
        _33407 = binary_op(MULTIPLY, _33405, _33406);
    }
    _33405 = NOVALUE;
    _33406 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63484);
    _1 = *(int *)_2;
    *(int *)_2 = _33407;
    if( _1 != _33407 ){
        DeRef(_1);
    }
    _33407 = NOVALUE;

    /** 	pc += 4*/
    _67pc_63479 = _67pc_63479 + 4;

    /** end procedure*/
    _33399 = NOVALUE;
    _33401 = NOVALUE;
    _33403 = NOVALUE;
    return;
    ;
}


void _67opPLUS()
{
    int _33417 = NOVALUE;
    int _33416 = NOVALUE;
    int _33415 = NOVALUE;
    int _33413 = NOVALUE;
    int _33411 = NOVALUE;
    int _33409 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _33409 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _33409);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _33411 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67b_63481 = (int)*(((s1_ptr)_2)->base + _33411);
    if (!IS_ATOM_INT(_67b_63481)){
        _67b_63481 = (long)DBL_PTR(_67b_63481)->dbl;
    }

    /** 	target = Code[pc+3]*/
    _33413 = _67pc_63479 + 3;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67target_63484 = (int)*(((s1_ptr)_2)->base + _33413);
    if (!IS_ATOM_INT(_67target_63484)){
        _67target_63484 = (long)DBL_PTR(_67target_63484)->dbl;
    }

    /** 	val[target] = val[a] + val[b]*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _33415 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    _2 = (int)SEQ_PTR(_67val_63489);
    _33416 = (int)*(((s1_ptr)_2)->base + _67b_63481);
    if (IS_ATOM_INT(_33415) && IS_ATOM_INT(_33416)) {
        _33417 = _33415 + _33416;
        if ((long)((unsigned long)_33417 + (unsigned long)HIGH_BITS) >= 0) 
        _33417 = NewDouble((double)_33417);
    }
    else {
        _33417 = binary_op(PLUS, _33415, _33416);
    }
    _33415 = NOVALUE;
    _33416 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63484);
    _1 = *(int *)_2;
    *(int *)_2 = _33417;
    if( _1 != _33417 ){
        DeRef(_1);
    }
    _33417 = NOVALUE;

    /** 	pc += 4*/
    _67pc_63479 = _67pc_63479 + 4;

    /** end procedure*/
    _33409 = NOVALUE;
    _33411 = NOVALUE;
    _33413 = NOVALUE;
    return;
    ;
}


void _67opMINUS()
{
    int _33427 = NOVALUE;
    int _33426 = NOVALUE;
    int _33425 = NOVALUE;
    int _33423 = NOVALUE;
    int _33421 = NOVALUE;
    int _33419 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _33419 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _33419);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _33421 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67b_63481 = (int)*(((s1_ptr)_2)->base + _33421);
    if (!IS_ATOM_INT(_67b_63481)){
        _67b_63481 = (long)DBL_PTR(_67b_63481)->dbl;
    }

    /** 	target = Code[pc+3]*/
    _33423 = _67pc_63479 + 3;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67target_63484 = (int)*(((s1_ptr)_2)->base + _33423);
    if (!IS_ATOM_INT(_67target_63484)){
        _67target_63484 = (long)DBL_PTR(_67target_63484)->dbl;
    }

    /** 	val[target] = val[a] - val[b]*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _33425 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    _2 = (int)SEQ_PTR(_67val_63489);
    _33426 = (int)*(((s1_ptr)_2)->base + _67b_63481);
    if (IS_ATOM_INT(_33425) && IS_ATOM_INT(_33426)) {
        _33427 = _33425 - _33426;
        if ((long)((unsigned long)_33427 +(unsigned long) HIGH_BITS) >= 0){
            _33427 = NewDouble((double)_33427);
        }
    }
    else {
        _33427 = binary_op(MINUS, _33425, _33426);
    }
    _33425 = NOVALUE;
    _33426 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63484);
    _1 = *(int *)_2;
    *(int *)_2 = _33427;
    if( _1 != _33427 ){
        DeRef(_1);
    }
    _33427 = NOVALUE;

    /** 	pc += 4*/
    _67pc_63479 = _67pc_63479 + 4;

    /** end procedure*/
    _33419 = NOVALUE;
    _33421 = NOVALUE;
    _33423 = NOVALUE;
    return;
    ;
}


void _67opOR()
{
    int _33437 = NOVALUE;
    int _33436 = NOVALUE;
    int _33435 = NOVALUE;
    int _33433 = NOVALUE;
    int _33431 = NOVALUE;
    int _33429 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _33429 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _33429);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _33431 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67b_63481 = (int)*(((s1_ptr)_2)->base + _33431);
    if (!IS_ATOM_INT(_67b_63481)){
        _67b_63481 = (long)DBL_PTR(_67b_63481)->dbl;
    }

    /** 	target = Code[pc+3]*/
    _33433 = _67pc_63479 + 3;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67target_63484 = (int)*(((s1_ptr)_2)->base + _33433);
    if (!IS_ATOM_INT(_67target_63484)){
        _67target_63484 = (long)DBL_PTR(_67target_63484)->dbl;
    }

    /** 	val[target] = val[a] or val[b]*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _33435 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    _2 = (int)SEQ_PTR(_67val_63489);
    _33436 = (int)*(((s1_ptr)_2)->base + _67b_63481);
    if (IS_ATOM_INT(_33435) && IS_ATOM_INT(_33436)) {
        _33437 = (_33435 != 0 || _33436 != 0);
    }
    else {
        _33437 = binary_op(OR, _33435, _33436);
    }
    _33435 = NOVALUE;
    _33436 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63484);
    _1 = *(int *)_2;
    *(int *)_2 = _33437;
    if( _1 != _33437 ){
        DeRef(_1);
    }
    _33437 = NOVALUE;

    /** 	pc += 4*/
    _67pc_63479 = _67pc_63479 + 4;

    /** end procedure*/
    _33429 = NOVALUE;
    _33431 = NOVALUE;
    _33433 = NOVALUE;
    return;
    ;
}


void _67opXOR()
{
    int _33447 = NOVALUE;
    int _33446 = NOVALUE;
    int _33445 = NOVALUE;
    int _33443 = NOVALUE;
    int _33441 = NOVALUE;
    int _33439 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _33439 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _33439);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _33441 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67b_63481 = (int)*(((s1_ptr)_2)->base + _33441);
    if (!IS_ATOM_INT(_67b_63481)){
        _67b_63481 = (long)DBL_PTR(_67b_63481)->dbl;
    }

    /** 	target = Code[pc+3]*/
    _33443 = _67pc_63479 + 3;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67target_63484 = (int)*(((s1_ptr)_2)->base + _33443);
    if (!IS_ATOM_INT(_67target_63484)){
        _67target_63484 = (long)DBL_PTR(_67target_63484)->dbl;
    }

    /** 	val[target] = val[a] xor val[b]*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _33445 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    _2 = (int)SEQ_PTR(_67val_63489);
    _33446 = (int)*(((s1_ptr)_2)->base + _67b_63481);
    if (IS_ATOM_INT(_33445) && IS_ATOM_INT(_33446)) {
        _33447 = ((_33445 != 0) != (_33446 != 0));
    }
    else {
        _33447 = binary_op(XOR, _33445, _33446);
    }
    _33445 = NOVALUE;
    _33446 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63484);
    _1 = *(int *)_2;
    *(int *)_2 = _33447;
    if( _1 != _33447 ){
        DeRef(_1);
    }
    _33447 = NOVALUE;

    /** 	pc += 4*/
    _67pc_63479 = _67pc_63479 + 4;

    /** end procedure*/
    _33439 = NOVALUE;
    _33441 = NOVALUE;
    _33443 = NOVALUE;
    return;
    ;
}


void _67opAND()
{
    int _33457 = NOVALUE;
    int _33456 = NOVALUE;
    int _33455 = NOVALUE;
    int _33453 = NOVALUE;
    int _33451 = NOVALUE;
    int _33449 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _33449 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _33449);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _33451 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67b_63481 = (int)*(((s1_ptr)_2)->base + _33451);
    if (!IS_ATOM_INT(_67b_63481)){
        _67b_63481 = (long)DBL_PTR(_67b_63481)->dbl;
    }

    /** 	target = Code[pc+3]*/
    _33453 = _67pc_63479 + 3;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67target_63484 = (int)*(((s1_ptr)_2)->base + _33453);
    if (!IS_ATOM_INT(_67target_63484)){
        _67target_63484 = (long)DBL_PTR(_67target_63484)->dbl;
    }

    /** 	val[target] = val[a] and val[b]*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _33455 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    _2 = (int)SEQ_PTR(_67val_63489);
    _33456 = (int)*(((s1_ptr)_2)->base + _67b_63481);
    if (IS_ATOM_INT(_33455) && IS_ATOM_INT(_33456)) {
        _33457 = (_33455 != 0 && _33456 != 0);
    }
    else {
        _33457 = binary_op(AND, _33455, _33456);
    }
    _33455 = NOVALUE;
    _33456 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63484);
    _1 = *(int *)_2;
    *(int *)_2 = _33457;
    if( _1 != _33457 ){
        DeRef(_1);
    }
    _33457 = NOVALUE;

    /** 	pc += 4*/
    _67pc_63479 = _67pc_63479 + 4;

    /** end procedure*/
    _33449 = NOVALUE;
    _33451 = NOVALUE;
    _33453 = NOVALUE;
    return;
    ;
}


void _67opDIVIDE()
{
    int _33470 = NOVALUE;
    int _33469 = NOVALUE;
    int _33468 = NOVALUE;
    int _33466 = NOVALUE;
    int _33465 = NOVALUE;
    int _33463 = NOVALUE;
    int _33461 = NOVALUE;
    int _33459 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _33459 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _33459);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _33461 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67b_63481 = (int)*(((s1_ptr)_2)->base + _33461);
    if (!IS_ATOM_INT(_67b_63481)){
        _67b_63481 = (long)DBL_PTR(_67b_63481)->dbl;
    }

    /** 	target = Code[pc+3]*/
    _33463 = _67pc_63479 + 3;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67target_63484 = (int)*(((s1_ptr)_2)->base + _33463);
    if (!IS_ATOM_INT(_67target_63484)){
        _67target_63484 = (long)DBL_PTR(_67target_63484)->dbl;
    }

    /** 	if equal(val[b], 0) then*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _33465 = (int)*(((s1_ptr)_2)->base + _67b_63481);
    if (_33465 == 0)
    _33466 = 1;
    else if (IS_ATOM_INT(_33465) && IS_ATOM_INT(0))
    _33466 = 0;
    else
    _33466 = (compare(_33465, 0) == 0);
    _33465 = NOVALUE;
    if (_33466 == 0)
    {
        _33466 = NOVALUE;
        goto L1; // [63] 72
    }
    else{
        _33466 = NOVALUE;
    }

    /** 		RTFatal("attempt to divide by 0")*/
    RefDS(_33467);
    _67RTFatal(_33467);
L1: 

    /** 	val[target] = val[a] / val[b]*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _33468 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    _2 = (int)SEQ_PTR(_67val_63489);
    _33469 = (int)*(((s1_ptr)_2)->base + _67b_63481);
    if (IS_ATOM_INT(_33468) && IS_ATOM_INT(_33469)) {
        _33470 = (_33468 % _33469) ? NewDouble((double)_33468 / _33469) : (_33468 / _33469);
    }
    else {
        _33470 = binary_op(DIVIDE, _33468, _33469);
    }
    _33468 = NOVALUE;
    _33469 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63484);
    _1 = *(int *)_2;
    *(int *)_2 = _33470;
    if( _1 != _33470 ){
        DeRef(_1);
    }
    _33470 = NOVALUE;

    /** 	pc += 4*/
    _67pc_63479 = _67pc_63479 + 4;

    /** end procedure*/
    DeRef(_33459);
    _33459 = NOVALUE;
    DeRef(_33461);
    _33461 = NOVALUE;
    DeRef(_33463);
    _33463 = NOVALUE;
    return;
    ;
}


void _67opREMAINDER()
{
    int _33483 = NOVALUE;
    int _33482 = NOVALUE;
    int _33481 = NOVALUE;
    int _33479 = NOVALUE;
    int _33478 = NOVALUE;
    int _33476 = NOVALUE;
    int _33474 = NOVALUE;
    int _33472 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _33472 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _33472);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _33474 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67b_63481 = (int)*(((s1_ptr)_2)->base + _33474);
    if (!IS_ATOM_INT(_67b_63481)){
        _67b_63481 = (long)DBL_PTR(_67b_63481)->dbl;
    }

    /** 	target = Code[pc+3]*/
    _33476 = _67pc_63479 + 3;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67target_63484 = (int)*(((s1_ptr)_2)->base + _33476);
    if (!IS_ATOM_INT(_67target_63484)){
        _67target_63484 = (long)DBL_PTR(_67target_63484)->dbl;
    }

    /** 	if equal(val[b], 0) then*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _33478 = (int)*(((s1_ptr)_2)->base + _67b_63481);
    if (_33478 == 0)
    _33479 = 1;
    else if (IS_ATOM_INT(_33478) && IS_ATOM_INT(0))
    _33479 = 0;
    else
    _33479 = (compare(_33478, 0) == 0);
    _33478 = NOVALUE;
    if (_33479 == 0)
    {
        _33479 = NOVALUE;
        goto L1; // [63] 72
    }
    else{
        _33479 = NOVALUE;
    }

    /** 		RTFatal("Can't get remainder of a number divided by 0")*/
    RefDS(_33480);
    _67RTFatal(_33480);
L1: 

    /** 	val[target] = remainder(val[a], val[b])*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _33481 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    _2 = (int)SEQ_PTR(_67val_63489);
    _33482 = (int)*(((s1_ptr)_2)->base + _67b_63481);
    if (IS_ATOM_INT(_33481) && IS_ATOM_INT(_33482)) {
        _33483 = (_33481 % _33482);
    }
    else {
        _33483 = binary_op(REMAINDER, _33481, _33482);
    }
    _33481 = NOVALUE;
    _33482 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63484);
    _1 = *(int *)_2;
    *(int *)_2 = _33483;
    if( _1 != _33483 ){
        DeRef(_1);
    }
    _33483 = NOVALUE;

    /** 	pc += 4*/
    _67pc_63479 = _67pc_63479 + 4;

    /** end procedure*/
    DeRef(_33472);
    _33472 = NOVALUE;
    DeRef(_33474);
    _33474 = NOVALUE;
    DeRef(_33476);
    _33476 = NOVALUE;
    return;
    ;
}


void _67opFLOOR_DIV()
{
    int _33495 = NOVALUE;
    int _33494 = NOVALUE;
    int _33493 = NOVALUE;
    int _33492 = NOVALUE;
    int _33491 = NOVALUE;
    int _33489 = NOVALUE;
    int _33487 = NOVALUE;
    int _33485 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _33485 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _33485);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _33487 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67b_63481 = (int)*(((s1_ptr)_2)->base + _33487);
    if (!IS_ATOM_INT(_67b_63481)){
        _67b_63481 = (long)DBL_PTR(_67b_63481)->dbl;
    }

    /** 	target = Code[pc+3]*/
    _33489 = _67pc_63479 + 3;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67target_63484 = (int)*(((s1_ptr)_2)->base + _33489);
    if (!IS_ATOM_INT(_67target_63484)){
        _67target_63484 = (long)DBL_PTR(_67target_63484)->dbl;
    }

    /** 	if equal(val[b], 0) then*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _33491 = (int)*(((s1_ptr)_2)->base + _67b_63481);
    if (_33491 == 0)
    _33492 = 1;
    else if (IS_ATOM_INT(_33491) && IS_ATOM_INT(0))
    _33492 = 0;
    else
    _33492 = (compare(_33491, 0) == 0);
    _33491 = NOVALUE;
    if (_33492 == 0)
    {
        _33492 = NOVALUE;
        goto L1; // [63] 72
    }
    else{
        _33492 = NOVALUE;
    }

    /** 		RTFatal("attempt to divide by 0")*/
    RefDS(_33467);
    _67RTFatal(_33467);
L1: 

    /** 	val[target] = floor(val[a] / val[b])*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _33493 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    _2 = (int)SEQ_PTR(_67val_63489);
    _33494 = (int)*(((s1_ptr)_2)->base + _67b_63481);
    if (IS_ATOM_INT(_33493) && IS_ATOM_INT(_33494)) {
        if (_33494 > 0 && _33493 >= 0) {
            _33495 = _33493 / _33494;
        }
        else {
            temp_dbl = floor((double)_33493 / (double)_33494);
            if (_33493 != MININT)
            _33495 = (long)temp_dbl;
            else
            _33495 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _33493, _33494);
        _33495 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    _33493 = NOVALUE;
    _33494 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63484);
    _1 = *(int *)_2;
    *(int *)_2 = _33495;
    if( _1 != _33495 ){
        DeRef(_1);
    }
    _33495 = NOVALUE;

    /** 	pc += 4*/
    _67pc_63479 = _67pc_63479 + 4;

    /** end procedure*/
    DeRef(_33485);
    _33485 = NOVALUE;
    DeRef(_33487);
    _33487 = NOVALUE;
    DeRef(_33489);
    _33489 = NOVALUE;
    return;
    ;
}


void _67opAND_BITS()
{
    int _33505 = NOVALUE;
    int _33504 = NOVALUE;
    int _33503 = NOVALUE;
    int _33501 = NOVALUE;
    int _33499 = NOVALUE;
    int _33497 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _33497 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _33497);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _33499 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67b_63481 = (int)*(((s1_ptr)_2)->base + _33499);
    if (!IS_ATOM_INT(_67b_63481)){
        _67b_63481 = (long)DBL_PTR(_67b_63481)->dbl;
    }

    /** 	target = Code[pc+3]*/
    _33501 = _67pc_63479 + 3;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67target_63484 = (int)*(((s1_ptr)_2)->base + _33501);
    if (!IS_ATOM_INT(_67target_63484)){
        _67target_63484 = (long)DBL_PTR(_67target_63484)->dbl;
    }

    /** 	val[target] = and_bits(val[a], val[b])*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _33503 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    _2 = (int)SEQ_PTR(_67val_63489);
    _33504 = (int)*(((s1_ptr)_2)->base + _67b_63481);
    if (IS_ATOM_INT(_33503) && IS_ATOM_INT(_33504)) {
        {unsigned long tu;
             tu = (unsigned long)_33503 & (unsigned long)_33504;
             _33505 = MAKE_UINT(tu);
        }
    }
    else {
        _33505 = binary_op(AND_BITS, _33503, _33504);
    }
    _33503 = NOVALUE;
    _33504 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63484);
    _1 = *(int *)_2;
    *(int *)_2 = _33505;
    if( _1 != _33505 ){
        DeRef(_1);
    }
    _33505 = NOVALUE;

    /** 	pc += 4*/
    _67pc_63479 = _67pc_63479 + 4;

    /** end procedure*/
    _33497 = NOVALUE;
    _33499 = NOVALUE;
    _33501 = NOVALUE;
    return;
    ;
}


void _67opOR_BITS()
{
    int _33515 = NOVALUE;
    int _33514 = NOVALUE;
    int _33513 = NOVALUE;
    int _33511 = NOVALUE;
    int _33509 = NOVALUE;
    int _33507 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _33507 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _33507);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _33509 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67b_63481 = (int)*(((s1_ptr)_2)->base + _33509);
    if (!IS_ATOM_INT(_67b_63481)){
        _67b_63481 = (long)DBL_PTR(_67b_63481)->dbl;
    }

    /** 	target = Code[pc+3]*/
    _33511 = _67pc_63479 + 3;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67target_63484 = (int)*(((s1_ptr)_2)->base + _33511);
    if (!IS_ATOM_INT(_67target_63484)){
        _67target_63484 = (long)DBL_PTR(_67target_63484)->dbl;
    }

    /** 	val[target] = or_bits(val[a], val[b])*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _33513 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    _2 = (int)SEQ_PTR(_67val_63489);
    _33514 = (int)*(((s1_ptr)_2)->base + _67b_63481);
    if (IS_ATOM_INT(_33513) && IS_ATOM_INT(_33514)) {
        {unsigned long tu;
             tu = (unsigned long)_33513 | (unsigned long)_33514;
             _33515 = MAKE_UINT(tu);
        }
    }
    else {
        _33515 = binary_op(OR_BITS, _33513, _33514);
    }
    _33513 = NOVALUE;
    _33514 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63484);
    _1 = *(int *)_2;
    *(int *)_2 = _33515;
    if( _1 != _33515 ){
        DeRef(_1);
    }
    _33515 = NOVALUE;

    /** 	pc += 4*/
    _67pc_63479 = _67pc_63479 + 4;

    /** end procedure*/
    _33507 = NOVALUE;
    _33509 = NOVALUE;
    _33511 = NOVALUE;
    return;
    ;
}


void _67opXOR_BITS()
{
    int _33525 = NOVALUE;
    int _33524 = NOVALUE;
    int _33523 = NOVALUE;
    int _33521 = NOVALUE;
    int _33519 = NOVALUE;
    int _33517 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _33517 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _33517);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _33519 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67b_63481 = (int)*(((s1_ptr)_2)->base + _33519);
    if (!IS_ATOM_INT(_67b_63481)){
        _67b_63481 = (long)DBL_PTR(_67b_63481)->dbl;
    }

    /** 	target = Code[pc+3]*/
    _33521 = _67pc_63479 + 3;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67target_63484 = (int)*(((s1_ptr)_2)->base + _33521);
    if (!IS_ATOM_INT(_67target_63484)){
        _67target_63484 = (long)DBL_PTR(_67target_63484)->dbl;
    }

    /** 	val[target] = xor_bits(val[a], val[b])*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _33523 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    _2 = (int)SEQ_PTR(_67val_63489);
    _33524 = (int)*(((s1_ptr)_2)->base + _67b_63481);
    if (IS_ATOM_INT(_33523) && IS_ATOM_INT(_33524)) {
        {unsigned long tu;
             tu = (unsigned long)_33523 ^ (unsigned long)_33524;
             _33525 = MAKE_UINT(tu);
        }
    }
    else {
        _33525 = binary_op(XOR_BITS, _33523, _33524);
    }
    _33523 = NOVALUE;
    _33524 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63484);
    _1 = *(int *)_2;
    *(int *)_2 = _33525;
    if( _1 != _33525 ){
        DeRef(_1);
    }
    _33525 = NOVALUE;

    /** 	pc += 4*/
    _67pc_63479 = _67pc_63479 + 4;

    /** end procedure*/
    _33517 = NOVALUE;
    _33519 = NOVALUE;
    _33521 = NOVALUE;
    return;
    ;
}


void _67opPOWER()
{
    int _33535 = NOVALUE;
    int _33534 = NOVALUE;
    int _33533 = NOVALUE;
    int _33531 = NOVALUE;
    int _33529 = NOVALUE;
    int _33527 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _33527 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _33527);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _33529 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67b_63481 = (int)*(((s1_ptr)_2)->base + _33529);
    if (!IS_ATOM_INT(_67b_63481)){
        _67b_63481 = (long)DBL_PTR(_67b_63481)->dbl;
    }

    /** 	target = Code[pc+3]*/
    _33531 = _67pc_63479 + 3;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67target_63484 = (int)*(((s1_ptr)_2)->base + _33531);
    if (!IS_ATOM_INT(_67target_63484)){
        _67target_63484 = (long)DBL_PTR(_67target_63484)->dbl;
    }

    /** 	val[target] = power(val[a], val[b])*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _33533 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    _2 = (int)SEQ_PTR(_67val_63489);
    _33534 = (int)*(((s1_ptr)_2)->base + _67b_63481);
    if (IS_ATOM_INT(_33533) && IS_ATOM_INT(_33534)) {
        _33535 = power(_33533, _33534);
    }
    else {
        _33535 = binary_op(POWER, _33533, _33534);
    }
    _33533 = NOVALUE;
    _33534 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63484);
    _1 = *(int *)_2;
    *(int *)_2 = _33535;
    if( _1 != _33535 ){
        DeRef(_1);
    }
    _33535 = NOVALUE;

    /** 	pc += 4*/
    _67pc_63479 = _67pc_63479 + 4;

    /** end procedure*/
    _33527 = NOVALUE;
    _33529 = NOVALUE;
    _33531 = NOVALUE;
    return;
    ;
}


void _67opLESS()
{
    int _33545 = NOVALUE;
    int _33544 = NOVALUE;
    int _33543 = NOVALUE;
    int _33541 = NOVALUE;
    int _33539 = NOVALUE;
    int _33537 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _33537 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _33537);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _33539 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67b_63481 = (int)*(((s1_ptr)_2)->base + _33539);
    if (!IS_ATOM_INT(_67b_63481)){
        _67b_63481 = (long)DBL_PTR(_67b_63481)->dbl;
    }

    /** 	target = Code[pc+3]*/
    _33541 = _67pc_63479 + 3;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67target_63484 = (int)*(((s1_ptr)_2)->base + _33541);
    if (!IS_ATOM_INT(_67target_63484)){
        _67target_63484 = (long)DBL_PTR(_67target_63484)->dbl;
    }

    /** 	val[target] = val[a] < val[b]*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _33543 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    _2 = (int)SEQ_PTR(_67val_63489);
    _33544 = (int)*(((s1_ptr)_2)->base + _67b_63481);
    if (IS_ATOM_INT(_33543) && IS_ATOM_INT(_33544)) {
        _33545 = (_33543 < _33544);
    }
    else {
        _33545 = binary_op(LESS, _33543, _33544);
    }
    _33543 = NOVALUE;
    _33544 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63484);
    _1 = *(int *)_2;
    *(int *)_2 = _33545;
    if( _1 != _33545 ){
        DeRef(_1);
    }
    _33545 = NOVALUE;

    /** 	pc += 4*/
    _67pc_63479 = _67pc_63479 + 4;

    /** end procedure*/
    _33537 = NOVALUE;
    _33539 = NOVALUE;
    _33541 = NOVALUE;
    return;
    ;
}


void _67opGREATER()
{
    int _33555 = NOVALUE;
    int _33554 = NOVALUE;
    int _33553 = NOVALUE;
    int _33551 = NOVALUE;
    int _33549 = NOVALUE;
    int _33547 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _33547 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _33547);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _33549 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67b_63481 = (int)*(((s1_ptr)_2)->base + _33549);
    if (!IS_ATOM_INT(_67b_63481)){
        _67b_63481 = (long)DBL_PTR(_67b_63481)->dbl;
    }

    /** 	target = Code[pc+3]*/
    _33551 = _67pc_63479 + 3;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67target_63484 = (int)*(((s1_ptr)_2)->base + _33551);
    if (!IS_ATOM_INT(_67target_63484)){
        _67target_63484 = (long)DBL_PTR(_67target_63484)->dbl;
    }

    /** 	val[target] = val[a] > val[b]*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _33553 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    _2 = (int)SEQ_PTR(_67val_63489);
    _33554 = (int)*(((s1_ptr)_2)->base + _67b_63481);
    if (IS_ATOM_INT(_33553) && IS_ATOM_INT(_33554)) {
        _33555 = (_33553 > _33554);
    }
    else {
        _33555 = binary_op(GREATER, _33553, _33554);
    }
    _33553 = NOVALUE;
    _33554 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63484);
    _1 = *(int *)_2;
    *(int *)_2 = _33555;
    if( _1 != _33555 ){
        DeRef(_1);
    }
    _33555 = NOVALUE;

    /** 	pc += 4*/
    _67pc_63479 = _67pc_63479 + 4;

    /** end procedure*/
    _33547 = NOVALUE;
    _33549 = NOVALUE;
    _33551 = NOVALUE;
    return;
    ;
}


void _67opEQUALS()
{
    int _33565 = NOVALUE;
    int _33564 = NOVALUE;
    int _33563 = NOVALUE;
    int _33561 = NOVALUE;
    int _33559 = NOVALUE;
    int _33557 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _33557 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _33557);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _33559 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67b_63481 = (int)*(((s1_ptr)_2)->base + _33559);
    if (!IS_ATOM_INT(_67b_63481)){
        _67b_63481 = (long)DBL_PTR(_67b_63481)->dbl;
    }

    /** 	target = Code[pc+3]*/
    _33561 = _67pc_63479 + 3;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67target_63484 = (int)*(((s1_ptr)_2)->base + _33561);
    if (!IS_ATOM_INT(_67target_63484)){
        _67target_63484 = (long)DBL_PTR(_67target_63484)->dbl;
    }

    /** 	val[target] = val[a] = val[b]*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _33563 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    _2 = (int)SEQ_PTR(_67val_63489);
    _33564 = (int)*(((s1_ptr)_2)->base + _67b_63481);
    if (IS_ATOM_INT(_33563) && IS_ATOM_INT(_33564)) {
        _33565 = (_33563 == _33564);
    }
    else {
        _33565 = binary_op(EQUALS, _33563, _33564);
    }
    _33563 = NOVALUE;
    _33564 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63484);
    _1 = *(int *)_2;
    *(int *)_2 = _33565;
    if( _1 != _33565 ){
        DeRef(_1);
    }
    _33565 = NOVALUE;

    /** 	pc += 4*/
    _67pc_63479 = _67pc_63479 + 4;

    /** end procedure*/
    _33557 = NOVALUE;
    _33559 = NOVALUE;
    _33561 = NOVALUE;
    return;
    ;
}


void _67opNOTEQ()
{
    int _33575 = NOVALUE;
    int _33574 = NOVALUE;
    int _33573 = NOVALUE;
    int _33571 = NOVALUE;
    int _33569 = NOVALUE;
    int _33567 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _33567 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _33567);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _33569 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67b_63481 = (int)*(((s1_ptr)_2)->base + _33569);
    if (!IS_ATOM_INT(_67b_63481)){
        _67b_63481 = (long)DBL_PTR(_67b_63481)->dbl;
    }

    /** 	target = Code[pc+3]*/
    _33571 = _67pc_63479 + 3;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67target_63484 = (int)*(((s1_ptr)_2)->base + _33571);
    if (!IS_ATOM_INT(_67target_63484)){
        _67target_63484 = (long)DBL_PTR(_67target_63484)->dbl;
    }

    /** 	val[target] = val[a] != val[b]*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _33573 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    _2 = (int)SEQ_PTR(_67val_63489);
    _33574 = (int)*(((s1_ptr)_2)->base + _67b_63481);
    if (IS_ATOM_INT(_33573) && IS_ATOM_INT(_33574)) {
        _33575 = (_33573 != _33574);
    }
    else {
        _33575 = binary_op(NOTEQ, _33573, _33574);
    }
    _33573 = NOVALUE;
    _33574 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63484);
    _1 = *(int *)_2;
    *(int *)_2 = _33575;
    if( _1 != _33575 ){
        DeRef(_1);
    }
    _33575 = NOVALUE;

    /** 	pc += 4*/
    _67pc_63479 = _67pc_63479 + 4;

    /** end procedure*/
    _33567 = NOVALUE;
    _33569 = NOVALUE;
    _33571 = NOVALUE;
    return;
    ;
}


void _67opLESSEQ()
{
    int _33585 = NOVALUE;
    int _33584 = NOVALUE;
    int _33583 = NOVALUE;
    int _33581 = NOVALUE;
    int _33579 = NOVALUE;
    int _33577 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _33577 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _33577);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _33579 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67b_63481 = (int)*(((s1_ptr)_2)->base + _33579);
    if (!IS_ATOM_INT(_67b_63481)){
        _67b_63481 = (long)DBL_PTR(_67b_63481)->dbl;
    }

    /** 	target = Code[pc+3]*/
    _33581 = _67pc_63479 + 3;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67target_63484 = (int)*(((s1_ptr)_2)->base + _33581);
    if (!IS_ATOM_INT(_67target_63484)){
        _67target_63484 = (long)DBL_PTR(_67target_63484)->dbl;
    }

    /** 	val[target] = val[a] <= val[b]*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _33583 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    _2 = (int)SEQ_PTR(_67val_63489);
    _33584 = (int)*(((s1_ptr)_2)->base + _67b_63481);
    if (IS_ATOM_INT(_33583) && IS_ATOM_INT(_33584)) {
        _33585 = (_33583 <= _33584);
    }
    else {
        _33585 = binary_op(LESSEQ, _33583, _33584);
    }
    _33583 = NOVALUE;
    _33584 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63484);
    _1 = *(int *)_2;
    *(int *)_2 = _33585;
    if( _1 != _33585 ){
        DeRef(_1);
    }
    _33585 = NOVALUE;

    /** 	pc += 4*/
    _67pc_63479 = _67pc_63479 + 4;

    /** end procedure*/
    _33577 = NOVALUE;
    _33579 = NOVALUE;
    _33581 = NOVALUE;
    return;
    ;
}


void _67opGREATEREQ()
{
    int _33595 = NOVALUE;
    int _33594 = NOVALUE;
    int _33593 = NOVALUE;
    int _33591 = NOVALUE;
    int _33589 = NOVALUE;
    int _33587 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _33587 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _33587);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _33589 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67b_63481 = (int)*(((s1_ptr)_2)->base + _33589);
    if (!IS_ATOM_INT(_67b_63481)){
        _67b_63481 = (long)DBL_PTR(_67b_63481)->dbl;
    }

    /** 	target = Code[pc+3]*/
    _33591 = _67pc_63479 + 3;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67target_63484 = (int)*(((s1_ptr)_2)->base + _33591);
    if (!IS_ATOM_INT(_67target_63484)){
        _67target_63484 = (long)DBL_PTR(_67target_63484)->dbl;
    }

    /** 	val[target] = val[a] >= val[b]*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _33593 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    _2 = (int)SEQ_PTR(_67val_63489);
    _33594 = (int)*(((s1_ptr)_2)->base + _67b_63481);
    if (IS_ATOM_INT(_33593) && IS_ATOM_INT(_33594)) {
        _33595 = (_33593 >= _33594);
    }
    else {
        _33595 = binary_op(GREATEREQ, _33593, _33594);
    }
    _33593 = NOVALUE;
    _33594 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63484);
    _1 = *(int *)_2;
    *(int *)_2 = _33595;
    if( _1 != _33595 ){
        DeRef(_1);
    }
    _33595 = NOVALUE;

    /** 	pc += 4*/
    _67pc_63479 = _67pc_63479 + 4;

    /** end procedure*/
    _33587 = NOVALUE;
    _33589 = NOVALUE;
    _33591 = NOVALUE;
    return;
    ;
}


void _67opSC1_AND()
{
    int _33605 = NOVALUE;
    int _33603 = NOVALUE;
    int _33602 = NOVALUE;
    int _33601 = NOVALUE;
    int _33599 = NOVALUE;
    int _33597 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _33597 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _33597);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _33599 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67b_63481 = (int)*(((s1_ptr)_2)->base + _33599);
    if (!IS_ATOM_INT(_67b_63481)){
        _67b_63481 = (long)DBL_PTR(_67b_63481)->dbl;
    }

    /** 	if atom(val[a]) then*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _33601 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    _33602 = IS_ATOM(_33601);
    _33601 = NOVALUE;
    if (_33602 == 0)
    {
        _33602 = NOVALUE;
        goto L1; // [46] 98
    }
    else{
        _33602 = NOVALUE;
    }

    /** 		if val[a] = 0 then*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _33603 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    if (binary_op_a(NOTEQ, _33603, 0)){
        _33603 = NOVALUE;
        goto L2; // [59] 104
    }
    _33603 = NOVALUE;

    /** 			val[b] = 0*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67b_63481);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 			pc = Code[pc+3]*/
    _33605 = _67pc_63479 + 3;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67pc_63479 = (int)*(((s1_ptr)_2)->base + _33605);
    if (!IS_ATOM_INT(_67pc_63479)){
        _67pc_63479 = (long)DBL_PTR(_67pc_63479)->dbl;
    }

    /** 			return*/
    _33597 = NOVALUE;
    _33599 = NOVALUE;
    _33605 = NOVALUE;
    return;
    goto L2; // [95] 104
L1: 

    /** 		RTFatal("true/false condition must be an ATOM")*/
    RefDS(_33382);
    _67RTFatal(_33382);
L2: 

    /** 	pc += 4*/
    _67pc_63479 = _67pc_63479 + 4;

    /** end procedure*/
    DeRef(_33597);
    _33597 = NOVALUE;
    DeRef(_33599);
    _33599 = NOVALUE;
    DeRef(_33605);
    _33605 = NOVALUE;
    return;
    ;
}


void _67opSC1_AND_IF()
{
    int _33616 = NOVALUE;
    int _33614 = NOVALUE;
    int _33613 = NOVALUE;
    int _33612 = NOVALUE;
    int _33610 = NOVALUE;
    int _33608 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _33608 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _33608);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _33610 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67b_63481 = (int)*(((s1_ptr)_2)->base + _33610);
    if (!IS_ATOM_INT(_67b_63481)){
        _67b_63481 = (long)DBL_PTR(_67b_63481)->dbl;
    }

    /** 	if atom(val[a]) then*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _33612 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    _33613 = IS_ATOM(_33612);
    _33612 = NOVALUE;
    if (_33613 == 0)
    {
        _33613 = NOVALUE;
        goto L1; // [46] 88
    }
    else{
        _33613 = NOVALUE;
    }

    /** 		if val[a] = 0 then*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _33614 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    if (binary_op_a(NOTEQ, _33614, 0)){
        _33614 = NOVALUE;
        goto L2; // [59] 94
    }
    _33614 = NOVALUE;

    /** 			pc = Code[pc+3]*/
    _33616 = _67pc_63479 + 3;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67pc_63479 = (int)*(((s1_ptr)_2)->base + _33616);
    if (!IS_ATOM_INT(_67pc_63479)){
        _67pc_63479 = (long)DBL_PTR(_67pc_63479)->dbl;
    }

    /** 			return*/
    _33608 = NOVALUE;
    _33610 = NOVALUE;
    _33616 = NOVALUE;
    return;
    goto L2; // [85] 94
L1: 

    /** 		RTFatal("true/false condition must be an ATOM")*/
    RefDS(_33382);
    _67RTFatal(_33382);
L2: 

    /** 	pc += 4*/
    _67pc_63479 = _67pc_63479 + 4;

    /** end procedure*/
    DeRef(_33608);
    _33608 = NOVALUE;
    DeRef(_33610);
    _33610 = NOVALUE;
    DeRef(_33616);
    _33616 = NOVALUE;
    return;
    ;
}


void _67opSC1_OR()
{
    int _33627 = NOVALUE;
    int _33625 = NOVALUE;
    int _33624 = NOVALUE;
    int _33623 = NOVALUE;
    int _33621 = NOVALUE;
    int _33619 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _33619 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _33619);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _33621 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67b_63481 = (int)*(((s1_ptr)_2)->base + _33621);
    if (!IS_ATOM_INT(_67b_63481)){
        _67b_63481 = (long)DBL_PTR(_67b_63481)->dbl;
    }

    /** 	if atom(val[a]) then*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _33623 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    _33624 = IS_ATOM(_33623);
    _33623 = NOVALUE;
    if (_33624 == 0)
    {
        _33624 = NOVALUE;
        goto L1; // [46] 98
    }
    else{
        _33624 = NOVALUE;
    }

    /** 		if val[a] != 0 then*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _33625 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    if (binary_op_a(EQUALS, _33625, 0)){
        _33625 = NOVALUE;
        goto L2; // [59] 104
    }
    _33625 = NOVALUE;

    /** 			val[b] = 1*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67b_63481);
    _1 = *(int *)_2;
    *(int *)_2 = 1;
    DeRef(_1);

    /** 			pc = Code[pc+3]*/
    _33627 = _67pc_63479 + 3;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67pc_63479 = (int)*(((s1_ptr)_2)->base + _33627);
    if (!IS_ATOM_INT(_67pc_63479)){
        _67pc_63479 = (long)DBL_PTR(_67pc_63479)->dbl;
    }

    /** 			return*/
    _33619 = NOVALUE;
    _33621 = NOVALUE;
    _33627 = NOVALUE;
    return;
    goto L2; // [95] 104
L1: 

    /** 		RTFatal("true/false condition must be an ATOM")*/
    RefDS(_33382);
    _67RTFatal(_33382);
L2: 

    /** 	pc += 4*/
    _67pc_63479 = _67pc_63479 + 4;

    /** end procedure*/
    DeRef(_33619);
    _33619 = NOVALUE;
    DeRef(_33621);
    _33621 = NOVALUE;
    DeRef(_33627);
    _33627 = NOVALUE;
    return;
    ;
}


void _67opSC1_OR_IF()
{
    int _33638 = NOVALUE;
    int _33636 = NOVALUE;
    int _33635 = NOVALUE;
    int _33634 = NOVALUE;
    int _33632 = NOVALUE;
    int _33630 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _33630 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _33630);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _33632 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67b_63481 = (int)*(((s1_ptr)_2)->base + _33632);
    if (!IS_ATOM_INT(_67b_63481)){
        _67b_63481 = (long)DBL_PTR(_67b_63481)->dbl;
    }

    /** 	if atom(val[a]) then*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _33634 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    _33635 = IS_ATOM(_33634);
    _33634 = NOVALUE;
    if (_33635 == 0)
    {
        _33635 = NOVALUE;
        goto L1; // [46] 98
    }
    else{
        _33635 = NOVALUE;
    }

    /** 		if val[a] != 0 then*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _33636 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    if (binary_op_a(EQUALS, _33636, 0)){
        _33636 = NOVALUE;
        goto L2; // [59] 104
    }
    _33636 = NOVALUE;

    /** 			val[b] = 1*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67b_63481);
    _1 = *(int *)_2;
    *(int *)_2 = 1;
    DeRef(_1);

    /** 			pc = Code[pc+3]*/
    _33638 = _67pc_63479 + 3;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67pc_63479 = (int)*(((s1_ptr)_2)->base + _33638);
    if (!IS_ATOM_INT(_67pc_63479)){
        _67pc_63479 = (long)DBL_PTR(_67pc_63479)->dbl;
    }

    /** 			return*/
    _33630 = NOVALUE;
    _33632 = NOVALUE;
    _33638 = NOVALUE;
    return;
    goto L2; // [95] 104
L1: 

    /** 		RTFatal("true/false condition must be an ATOM")*/
    RefDS(_33382);
    _67RTFatal(_33382);
L2: 

    /** 	pc += 4*/
    _67pc_63479 = _67pc_63479 + 4;

    /** end procedure*/
    DeRef(_33630);
    _33630 = NOVALUE;
    DeRef(_33632);
    _33632 = NOVALUE;
    DeRef(_33638);
    _33638 = NOVALUE;
    return;
    ;
}


void _67opSC2_OR()
{
    int _33647 = NOVALUE;
    int _33646 = NOVALUE;
    int _33645 = NOVALUE;
    int _33643 = NOVALUE;
    int _33641 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _33641 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _33641);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _33643 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67b_63481 = (int)*(((s1_ptr)_2)->base + _33643);
    if (!IS_ATOM_INT(_67b_63481)){
        _67b_63481 = (long)DBL_PTR(_67b_63481)->dbl;
    }

    /** 	if atom(val[a]) then*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _33645 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    _33646 = IS_ATOM(_33645);
    _33645 = NOVALUE;
    if (_33646 == 0)
    {
        _33646 = NOVALUE;
        goto L1; // [46] 70
    }
    else{
        _33646 = NOVALUE;
    }

    /** 		val[b] = val[a]*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _33647 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    Ref(_33647);
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67b_63481);
    _1 = *(int *)_2;
    *(int *)_2 = _33647;
    if( _1 != _33647 ){
        DeRef(_1);
    }
    _33647 = NOVALUE;
    goto L2; // [67] 76
L1: 

    /** 		RTFatal("true/false condition must be an ATOM")*/
    RefDS(_33382);
    _67RTFatal(_33382);
L2: 

    /** 	pc += 3*/
    _67pc_63479 = _67pc_63479 + 3;

    /** end procedure*/
    DeRef(_33641);
    _33641 = NOVALUE;
    DeRef(_33643);
    _33643 = NOVALUE;
    return;
    ;
}


void _67opFOR()
{
    int _increment_66666 = NOVALUE;
    int _limit_66667 = NOVALUE;
    int _initial_66668 = NOVALUE;
    int _loopvar_66669 = NOVALUE;
    int _jump_66670 = NOVALUE;
    int _33677 = NOVALUE;
    int _33675 = NOVALUE;
    int _33674 = NOVALUE;
    int _33672 = NOVALUE;
    int _33671 = NOVALUE;
    int _33669 = NOVALUE;
    int _33666 = NOVALUE;
    int _33665 = NOVALUE;
    int _33663 = NOVALUE;
    int _33662 = NOVALUE;
    int _33660 = NOVALUE;
    int _33659 = NOVALUE;
    int _33657 = NOVALUE;
    int _33655 = NOVALUE;
    int _33653 = NOVALUE;
    int _33651 = NOVALUE;
    int _33649 = NOVALUE;
    int _0, _1, _2;
    

    /** 	increment = Code[pc+1]*/
    _33649 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _increment_66666 = (int)*(((s1_ptr)_2)->base + _33649);
    if (!IS_ATOM_INT(_increment_66666)){
        _increment_66666 = (long)DBL_PTR(_increment_66666)->dbl;
    }

    /** 	limit = Code[pc+2]*/
    _33651 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _limit_66667 = (int)*(((s1_ptr)_2)->base + _33651);
    if (!IS_ATOM_INT(_limit_66667)){
        _limit_66667 = (long)DBL_PTR(_limit_66667)->dbl;
    }

    /** 	initial = Code[pc+3]*/
    _33653 = _67pc_63479 + 3;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _initial_66668 = (int)*(((s1_ptr)_2)->base + _33653);
    if (!IS_ATOM_INT(_initial_66668)){
        _initial_66668 = (long)DBL_PTR(_initial_66668)->dbl;
    }

    /** 	loopvar = Code[pc+5]*/
    _33655 = _67pc_63479 + 5;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _loopvar_66669 = (int)*(((s1_ptr)_2)->base + _33655);
    if (!IS_ATOM_INT(_loopvar_66669)){
        _loopvar_66669 = (long)DBL_PTR(_loopvar_66669)->dbl;
    }

    /** 	jump = Code[pc+6]*/
    _33657 = _67pc_63479 + 6;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _jump_66670 = (int)*(((s1_ptr)_2)->base + _33657);
    if (!IS_ATOM_INT(_jump_66670)){
        _jump_66670 = (long)DBL_PTR(_jump_66670)->dbl;
    }

    /** 	if sequence(val[initial]) then*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _33659 = (int)*(((s1_ptr)_2)->base + _initial_66668);
    _33660 = IS_SEQUENCE(_33659);
    _33659 = NOVALUE;
    if (_33660 == 0)
    {
        _33660 = NOVALUE;
        goto L1; // [92] 101
    }
    else{
        _33660 = NOVALUE;
    }

    /** 		RTFatal("for-loop variable is not an atom")*/
    RefDS(_33661);
    _67RTFatal(_33661);
L1: 

    /** 	if sequence(val[limit]) then*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _33662 = (int)*(((s1_ptr)_2)->base + _limit_66667);
    _33663 = IS_SEQUENCE(_33662);
    _33662 = NOVALUE;
    if (_33663 == 0)
    {
        _33663 = NOVALUE;
        goto L2; // [112] 121
    }
    else{
        _33663 = NOVALUE;
    }

    /** 		RTFatal("for-loop limit is not an atom")*/
    RefDS(_33664);
    _67RTFatal(_33664);
L2: 

    /** 	if sequence(val[increment]) then*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _33665 = (int)*(((s1_ptr)_2)->base + _increment_66666);
    _33666 = IS_SEQUENCE(_33665);
    _33665 = NOVALUE;
    if (_33666 == 0)
    {
        _33666 = NOVALUE;
        goto L3; // [132] 141
    }
    else{
        _33666 = NOVALUE;
    }

    /** 		RTFatal("for-loop increment is not an atom")*/
    RefDS(_33667);
    _67RTFatal(_33667);
L3: 

    /** 	pc += 7 -- to enter into the loop*/
    _67pc_63479 = _67pc_63479 + 7;

    /** 	if val[increment] >= 0 then*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _33669 = (int)*(((s1_ptr)_2)->base + _increment_66666);
    if (binary_op_a(LESS, _33669, 0)){
        _33669 = NOVALUE;
        goto L4; // [157] 188
    }
    _33669 = NOVALUE;

    /** 		if val[initial] > val[limit] then*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _33671 = (int)*(((s1_ptr)_2)->base + _initial_66668);
    _2 = (int)SEQ_PTR(_67val_63489);
    _33672 = (int)*(((s1_ptr)_2)->base + _limit_66667);
    if (binary_op_a(LESSEQ, _33671, _33672)){
        _33671 = NOVALUE;
        _33672 = NOVALUE;
        goto L5; // [175] 213
    }
    _33671 = NOVALUE;
    _33672 = NOVALUE;

    /** 			pc = jump -- quit immediately, 0 iterations*/
    _67pc_63479 = _jump_66670;
    goto L5; // [185] 213
L4: 

    /** 		if val[initial] < val[limit] then*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _33674 = (int)*(((s1_ptr)_2)->base + _initial_66668);
    _2 = (int)SEQ_PTR(_67val_63489);
    _33675 = (int)*(((s1_ptr)_2)->base + _limit_66667);
    if (binary_op_a(GREATEREQ, _33674, _33675)){
        _33674 = NOVALUE;
        _33675 = NOVALUE;
        goto L6; // [202] 212
    }
    _33674 = NOVALUE;
    _33675 = NOVALUE;

    /** 			pc = jump -- quit immediately, 0 iterations*/
    _67pc_63479 = _jump_66670;
L6: 
L5: 

    /** 	val[loopvar] = val[initial] -- initialize loop var*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _33677 = (int)*(((s1_ptr)_2)->base + _initial_66668);
    Ref(_33677);
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _loopvar_66669);
    _1 = *(int *)_2;
    *(int *)_2 = _33677;
    if( _1 != _33677 ){
        DeRef(_1);
    }
    _33677 = NOVALUE;

    /** end procedure*/
    DeRef(_33649);
    _33649 = NOVALUE;
    DeRef(_33651);
    _33651 = NOVALUE;
    DeRef(_33653);
    _33653 = NOVALUE;
    DeRef(_33655);
    _33655 = NOVALUE;
    DeRef(_33657);
    _33657 = NOVALUE;
    return;
    ;
}


void _67opENDFOR_GENERAL()
{
    int _loopvar_66714 = NOVALUE;
    int _increment_66715 = NOVALUE;
    int _limit_66716 = NOVALUE;
    int _next_66717 = NOVALUE;
    int _33695 = NOVALUE;
    int _33691 = NOVALUE;
    int _33686 = NOVALUE;
    int _33684 = NOVALUE;
    int _33682 = NOVALUE;
    int _33681 = NOVALUE;
    int _33679 = NOVALUE;
    int _33678 = NOVALUE;
    int _0, _1, _2;
    

    /** 	limit = val[Code[pc+2]]*/
    _33678 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _33679 = (int)*(((s1_ptr)_2)->base + _33678);
    DeRef(_limit_66716);
    _2 = (int)SEQ_PTR(_67val_63489);
    if (!IS_ATOM_INT(_33679)){
        _limit_66716 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_33679)->dbl));
    }
    else{
        _limit_66716 = (int)*(((s1_ptr)_2)->base + _33679);
    }
    Ref(_limit_66716);

    /** 	increment = val[Code[pc+4]]*/
    _33681 = _67pc_63479 + 4;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _33682 = (int)*(((s1_ptr)_2)->base + _33681);
    DeRef(_increment_66715);
    _2 = (int)SEQ_PTR(_67val_63489);
    if (!IS_ATOM_INT(_33682)){
        _increment_66715 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_33682)->dbl));
    }
    else{
        _increment_66715 = (int)*(((s1_ptr)_2)->base + _33682);
    }
    Ref(_increment_66715);

    /** 	loopvar = Code[pc+3]*/
    _33684 = _67pc_63479 + 3;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _loopvar_66714 = (int)*(((s1_ptr)_2)->base + _33684);
    if (!IS_ATOM_INT(_loopvar_66714)){
        _loopvar_66714 = (long)DBL_PTR(_loopvar_66714)->dbl;
    }

    /** 	next = val[loopvar] + increment*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _33686 = (int)*(((s1_ptr)_2)->base + _loopvar_66714);
    DeRef(_next_66717);
    if (IS_ATOM_INT(_33686) && IS_ATOM_INT(_increment_66715)) {
        _next_66717 = _33686 + _increment_66715;
        if ((long)((unsigned long)_next_66717 + (unsigned long)HIGH_BITS) >= 0) 
        _next_66717 = NewDouble((double)_next_66717);
    }
    else {
        _next_66717 = binary_op(PLUS, _33686, _increment_66715);
    }
    _33686 = NOVALUE;

    /** 	if increment >= 0 then*/
    if (binary_op_a(LESS, _increment_66715, 0)){
        goto L1; // [71] 120
    }

    /** 		if next > limit then*/
    if (binary_op_a(LESSEQ, _next_66717, _limit_66716)){
        goto L2; // [77] 92
    }

    /** 			pc += 5 -- exit loop*/
    _67pc_63479 = _67pc_63479 + 5;
    goto L3; // [89] 163
L2: 

    /** 			val[loopvar] = next*/
    Ref(_next_66717);
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _loopvar_66714);
    _1 = *(int *)_2;
    *(int *)_2 = _next_66717;
    DeRef(_1);

    /** 			pc = Code[pc+1] -- loop again*/
    _33691 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67pc_63479 = (int)*(((s1_ptr)_2)->base + _33691);
    if (!IS_ATOM_INT(_67pc_63479)){
        _67pc_63479 = (long)DBL_PTR(_67pc_63479)->dbl;
    }
    goto L3; // [117] 163
L1: 

    /** 		if next < limit then*/
    if (binary_op_a(GREATEREQ, _next_66717, _limit_66716)){
        goto L4; // [122] 137
    }

    /** 			pc += 5 -- exit loop*/
    _67pc_63479 = _67pc_63479 + 5;
    goto L5; // [134] 162
L4: 

    /** 			val[loopvar] = next*/
    Ref(_next_66717);
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _loopvar_66714);
    _1 = *(int *)_2;
    *(int *)_2 = _next_66717;
    DeRef(_1);

    /** 			pc = Code[pc+1] -- loop again*/
    _33695 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67pc_63479 = (int)*(((s1_ptr)_2)->base + _33695);
    if (!IS_ATOM_INT(_67pc_63479)){
        _67pc_63479 = (long)DBL_PTR(_67pc_63479)->dbl;
    }
L5: 
L3: 

    /** end procedure*/
    DeRef(_increment_66715);
    DeRef(_limit_66716);
    DeRef(_next_66717);
    DeRef(_33678);
    _33678 = NOVALUE;
    _33679 = NOVALUE;
    DeRef(_33681);
    _33681 = NOVALUE;
    _33682 = NOVALUE;
    DeRef(_33684);
    _33684 = NOVALUE;
    DeRef(_33691);
    _33691 = NOVALUE;
    DeRef(_33695);
    _33695 = NOVALUE;
    return;
    ;
}


void _67opENDFOR_INT_UP1()
{
    int _loopvar_66750 = NOVALUE;
    int _limit_66751 = NOVALUE;
    int _next_66752 = NOVALUE;
    int _33706 = NOVALUE;
    int _33702 = NOVALUE;
    int _33700 = NOVALUE;
    int _33698 = NOVALUE;
    int _33697 = NOVALUE;
    int _0, _1, _2;
    

    /** 	limit = val[Code[pc+2]]*/
    _33697 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _33698 = (int)*(((s1_ptr)_2)->base + _33697);
    DeRef(_limit_66751);
    _2 = (int)SEQ_PTR(_67val_63489);
    if (!IS_ATOM_INT(_33698)){
        _limit_66751 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_33698)->dbl));
    }
    else{
        _limit_66751 = (int)*(((s1_ptr)_2)->base + _33698);
    }
    Ref(_limit_66751);

    /** 	loopvar = Code[pc+3]*/
    _33700 = _67pc_63479 + 3;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _loopvar_66750 = (int)*(((s1_ptr)_2)->base + _33700);
    if (!IS_ATOM_INT(_loopvar_66750)){
        _loopvar_66750 = (long)DBL_PTR(_loopvar_66750)->dbl;
    }

    /** 	next = val[loopvar] + 1*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _33702 = (int)*(((s1_ptr)_2)->base + _loopvar_66750);
    DeRef(_next_66752);
    if (IS_ATOM_INT(_33702)) {
        _next_66752 = _33702 + 1;
        if (_next_66752 > MAXINT){
            _next_66752 = NewDouble((double)_next_66752);
        }
    }
    else
    _next_66752 = binary_op(PLUS, 1, _33702);
    _33702 = NOVALUE;

    /** 	if next > limit then*/
    if (binary_op_a(LESSEQ, _next_66752, _limit_66751)){
        goto L1; // [51] 66
    }

    /** 		pc += 5 -- exit loop*/
    _67pc_63479 = _67pc_63479 + 5;
    goto L2; // [63] 91
L1: 

    /** 		val[loopvar] = next*/
    Ref(_next_66752);
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _loopvar_66750);
    _1 = *(int *)_2;
    *(int *)_2 = _next_66752;
    DeRef(_1);

    /** 		pc = Code[pc+1] -- loop again*/
    _33706 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67pc_63479 = (int)*(((s1_ptr)_2)->base + _33706);
    if (!IS_ATOM_INT(_67pc_63479)){
        _67pc_63479 = (long)DBL_PTR(_67pc_63479)->dbl;
    }
L2: 

    /** end procedure*/
    DeRef(_limit_66751);
    DeRef(_next_66752);
    DeRef(_33697);
    _33697 = NOVALUE;
    _33698 = NOVALUE;
    DeRef(_33700);
    _33700 = NOVALUE;
    DeRef(_33706);
    _33706 = NOVALUE;
    return;
    ;
}


int _67RTLookup(int _name_66771, int _file_66772, int _proc_66774, int _stlen_66775)
{
    int _s_66777 = NOVALUE;
    int _global_found_66778 = NOVALUE;
    int _ns_66779 = NOVALUE;
    int _colon_66780 = NOVALUE;
    int _ns_file_66781 = NOVALUE;
    int _found_in_path_66782 = NOVALUE;
    int _found_outside_path_66783 = NOVALUE;
    int _s_in_include_path_66784 = NOVALUE;
    int _scope_66881 = NOVALUE;
    int _33935 = NOVALUE;
    int _33934 = NOVALUE;
    int _33933 = NOVALUE;
    int _33932 = NOVALUE;
    int _33930 = NOVALUE;
    int _33928 = NOVALUE;
    int _33927 = NOVALUE;
    int _33926 = NOVALUE;
    int _33925 = NOVALUE;
    int _33924 = NOVALUE;
    int _33923 = NOVALUE;
    int _33922 = NOVALUE;
    int _33921 = NOVALUE;
    int _33920 = NOVALUE;
    int _33919 = NOVALUE;
    int _33918 = NOVALUE;
    int _33917 = NOVALUE;
    int _33915 = NOVALUE;
    int _33914 = NOVALUE;
    int _33913 = NOVALUE;
    int _33912 = NOVALUE;
    int _33911 = NOVALUE;
    int _33910 = NOVALUE;
    int _33909 = NOVALUE;
    int _33908 = NOVALUE;
    int _33907 = NOVALUE;
    int _33906 = NOVALUE;
    int _33905 = NOVALUE;
    int _33904 = NOVALUE;
    int _33899 = NOVALUE;
    int _33898 = NOVALUE;
    int _33897 = NOVALUE;
    int _33896 = NOVALUE;
    int _33895 = NOVALUE;
    int _33894 = NOVALUE;
    int _33893 = NOVALUE;
    int _33892 = NOVALUE;
    int _33891 = NOVALUE;
    int _33890 = NOVALUE;
    int _33889 = NOVALUE;
    int _33888 = NOVALUE;
    int _33887 = NOVALUE;
    int _33886 = NOVALUE;
    int _33885 = NOVALUE;
    int _33884 = NOVALUE;
    int _33883 = NOVALUE;
    int _33882 = NOVALUE;
    int _33880 = NOVALUE;
    int _33878 = NOVALUE;
    int _33877 = NOVALUE;
    int _33876 = NOVALUE;
    int _33875 = NOVALUE;
    int _33874 = NOVALUE;
    int _33873 = NOVALUE;
    int _33872 = NOVALUE;
    int _33871 = NOVALUE;
    int _33870 = NOVALUE;
    int _33869 = NOVALUE;
    int _33868 = NOVALUE;
    int _33867 = NOVALUE;
    int _33866 = NOVALUE;
    int _33865 = NOVALUE;
    int _33864 = NOVALUE;
    int _33863 = NOVALUE;
    int _33862 = NOVALUE;
    int _33861 = NOVALUE;
    int _33860 = NOVALUE;
    int _33859 = NOVALUE;
    int _33858 = NOVALUE;
    int _33857 = NOVALUE;
    int _33856 = NOVALUE;
    int _33855 = NOVALUE;
    int _33854 = NOVALUE;
    int _33853 = NOVALUE;
    int _33852 = NOVALUE;
    int _33851 = NOVALUE;
    int _33850 = NOVALUE;
    int _33849 = NOVALUE;
    int _33848 = NOVALUE;
    int _33847 = NOVALUE;
    int _33846 = NOVALUE;
    int _33844 = NOVALUE;
    int _33842 = NOVALUE;
    int _33841 = NOVALUE;
    int _33840 = NOVALUE;
    int _33839 = NOVALUE;
    int _33838 = NOVALUE;
    int _33837 = NOVALUE;
    int _33836 = NOVALUE;
    int _33835 = NOVALUE;
    int _33834 = NOVALUE;
    int _33833 = NOVALUE;
    int _33832 = NOVALUE;
    int _33831 = NOVALUE;
    int _33829 = NOVALUE;
    int _33826 = NOVALUE;
    int _33825 = NOVALUE;
    int _33824 = NOVALUE;
    int _33823 = NOVALUE;
    int _33822 = NOVALUE;
    int _33821 = NOVALUE;
    int _33820 = NOVALUE;
    int _33819 = NOVALUE;
    int _33818 = NOVALUE;
    int _33817 = NOVALUE;
    int _33816 = NOVALUE;
    int _33815 = NOVALUE;
    int _33814 = NOVALUE;
    int _33813 = NOVALUE;
    int _33812 = NOVALUE;
    int _33811 = NOVALUE;
    int _33810 = NOVALUE;
    int _33809 = NOVALUE;
    int _33808 = NOVALUE;
    int _33807 = NOVALUE;
    int _33806 = NOVALUE;
    int _33805 = NOVALUE;
    int _33804 = NOVALUE;
    int _33803 = NOVALUE;
    int _33802 = NOVALUE;
    int _33801 = NOVALUE;
    int _33800 = NOVALUE;
    int _33799 = NOVALUE;
    int _33798 = NOVALUE;
    int _33797 = NOVALUE;
    int _33796 = NOVALUE;
    int _33795 = NOVALUE;
    int _33794 = NOVALUE;
    int _33793 = NOVALUE;
    int _33792 = NOVALUE;
    int _33791 = NOVALUE;
    int _33790 = NOVALUE;
    int _33789 = NOVALUE;
    int _33788 = NOVALUE;
    int _33787 = NOVALUE;
    int _33786 = NOVALUE;
    int _33785 = NOVALUE;
    int _33784 = NOVALUE;
    int _33783 = NOVALUE;
    int _33782 = NOVALUE;
    int _33781 = NOVALUE;
    int _33780 = NOVALUE;
    int _33779 = NOVALUE;
    int _33778 = NOVALUE;
    int _33776 = NOVALUE;
    int _33775 = NOVALUE;
    int _33774 = NOVALUE;
    int _33773 = NOVALUE;
    int _33772 = NOVALUE;
    int _33771 = NOVALUE;
    int _33770 = NOVALUE;
    int _33769 = NOVALUE;
    int _33767 = NOVALUE;
    int _33765 = NOVALUE;
    int _33764 = NOVALUE;
    int _33763 = NOVALUE;
    int _33762 = NOVALUE;
    int _33761 = NOVALUE;
    int _33760 = NOVALUE;
    int _33759 = NOVALUE;
    int _33758 = NOVALUE;
    int _33754 = NOVALUE;
    int _33753 = NOVALUE;
    int _33752 = NOVALUE;
    int _33751 = NOVALUE;
    int _33750 = NOVALUE;
    int _33749 = NOVALUE;
    int _33748 = NOVALUE;
    int _33747 = NOVALUE;
    int _33746 = NOVALUE;
    int _33745 = NOVALUE;
    int _33744 = NOVALUE;
    int _33743 = NOVALUE;
    int _33740 = NOVALUE;
    int _33739 = NOVALUE;
    int _33737 = NOVALUE;
    int _33736 = NOVALUE;
    int _33734 = NOVALUE;
    int _33733 = NOVALUE;
    int _33732 = NOVALUE;
    int _33731 = NOVALUE;
    int _33730 = NOVALUE;
    int _33729 = NOVALUE;
    int _33728 = NOVALUE;
    int _33727 = NOVALUE;
    int _33725 = NOVALUE;
    int _33724 = NOVALUE;
    int _33723 = NOVALUE;
    int _33722 = NOVALUE;
    int _33721 = NOVALUE;
    int _33720 = NOVALUE;
    int _33719 = NOVALUE;
    int _33718 = NOVALUE;
    int _33717 = NOVALUE;
    int _33716 = NOVALUE;
    int _33715 = NOVALUE;
    int _33713 = NOVALUE;
    int _33712 = NOVALUE;
    int _33710 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence ns*/

    /** 	integer colon*/

    /** 	integer ns_file*/

    /** 	integer found_in_path*/

    /** 	integer found_outside_path*/

    /** 	integer s_in_include_path*/

    /** 	stlen = length( SymTab )*/
    if (IS_SEQUENCE(_27SymTab_10921)){
            _stlen_66775 = SEQ_PTR(_27SymTab_10921)->length;
    }
    else {
        _stlen_66775 = 1;
    }

    /** 	colon = find(':', name)*/
    _colon_66780 = find_from(58, _name_66771, 1);

    /** 	if colon then*/
    if (_colon_66780 == 0)
    {
        goto L1; // [37] 827
    }
    else{
    }

    /** 		ns = name[1..colon-1]*/
    _33710 = _colon_66780 - 1;
    rhs_slice_target = (object_ptr)&_ns_66779;
    RHS_Slice(_name_66771, 1, _33710);

    /** 		name = name[colon+1..$]*/
    _33712 = _colon_66780 + 1;
    if (IS_SEQUENCE(_name_66771)){
            _33713 = SEQ_PTR(_name_66771)->length;
    }
    else {
        _33713 = 1;
    }
    rhs_slice_target = (object_ptr)&_name_66771;
    RHS_Slice(_name_66771, _33712, _33713);

    /** 		while length(ns) and (ns[$] = ' ' or ns[$] = '\t') do*/
L2: 
    if (IS_SEQUENCE(_ns_66779)){
            _33715 = SEQ_PTR(_ns_66779)->length;
    }
    else {
        _33715 = 1;
    }
    if (_33715 == 0) {
        goto L3; // [73] 130
    }
    if (IS_SEQUENCE(_ns_66779)){
            _33717 = SEQ_PTR(_ns_66779)->length;
    }
    else {
        _33717 = 1;
    }
    _2 = (int)SEQ_PTR(_ns_66779);
    _33718 = (int)*(((s1_ptr)_2)->base + _33717);
    if (IS_ATOM_INT(_33718)) {
        _33719 = (_33718 == 32);
    }
    else {
        _33719 = binary_op(EQUALS, _33718, 32);
    }
    _33718 = NOVALUE;
    if (IS_ATOM_INT(_33719)) {
        if (_33719 != 0) {
            DeRef(_33720);
            _33720 = 1;
            goto L4; // [88] 107
        }
    }
    else {
        if (DBL_PTR(_33719)->dbl != 0.0) {
            DeRef(_33720);
            _33720 = 1;
            goto L4; // [88] 107
        }
    }
    if (IS_SEQUENCE(_ns_66779)){
            _33721 = SEQ_PTR(_ns_66779)->length;
    }
    else {
        _33721 = 1;
    }
    _2 = (int)SEQ_PTR(_ns_66779);
    _33722 = (int)*(((s1_ptr)_2)->base + _33721);
    if (IS_ATOM_INT(_33722)) {
        _33723 = (_33722 == 9);
    }
    else {
        _33723 = binary_op(EQUALS, _33722, 9);
    }
    _33722 = NOVALUE;
    DeRef(_33720);
    if (IS_ATOM_INT(_33723))
    _33720 = (_33723 != 0);
    else
    _33720 = DBL_PTR(_33723)->dbl != 0.0;
L4: 
    if (_33720 == 0)
    {
        _33720 = NOVALUE;
        goto L3; // [108] 130
    }
    else{
        _33720 = NOVALUE;
    }

    /** 			ns = ns[1..$-1]*/
    if (IS_SEQUENCE(_ns_66779)){
            _33724 = SEQ_PTR(_ns_66779)->length;
    }
    else {
        _33724 = 1;
    }
    _33725 = _33724 - 1;
    _33724 = NOVALUE;
    rhs_slice_target = (object_ptr)&_ns_66779;
    RHS_Slice(_ns_66779, 1, _33725);

    /** 		end while*/
    goto L2; // [127] 70
L3: 

    /** 		while length(ns) and (ns[1] = ' ' or ns[1] = '\t') do*/
L5: 
    if (IS_SEQUENCE(_ns_66779)){
            _33727 = SEQ_PTR(_ns_66779)->length;
    }
    else {
        _33727 = 1;
    }
    if (_33727 == 0) {
        goto L6; // [138] 185
    }
    _2 = (int)SEQ_PTR(_ns_66779);
    _33729 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_33729)) {
        _33730 = (_33729 == 32);
    }
    else {
        _33730 = binary_op(EQUALS, _33729, 32);
    }
    _33729 = NOVALUE;
    if (IS_ATOM_INT(_33730)) {
        if (_33730 != 0) {
            DeRef(_33731);
            _33731 = 1;
            goto L7; // [150] 166
        }
    }
    else {
        if (DBL_PTR(_33730)->dbl != 0.0) {
            DeRef(_33731);
            _33731 = 1;
            goto L7; // [150] 166
        }
    }
    _2 = (int)SEQ_PTR(_ns_66779);
    _33732 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_33732)) {
        _33733 = (_33732 == 9);
    }
    else {
        _33733 = binary_op(EQUALS, _33732, 9);
    }
    _33732 = NOVALUE;
    DeRef(_33731);
    if (IS_ATOM_INT(_33733))
    _33731 = (_33733 != 0);
    else
    _33731 = DBL_PTR(_33733)->dbl != 0.0;
L7: 
    if (_33731 == 0)
    {
        _33731 = NOVALUE;
        goto L6; // [167] 185
    }
    else{
        _33731 = NOVALUE;
    }

    /** 			ns = ns[2..$]*/
    if (IS_SEQUENCE(_ns_66779)){
            _33734 = SEQ_PTR(_ns_66779)->length;
    }
    else {
        _33734 = 1;
    }
    rhs_slice_target = (object_ptr)&_ns_66779;
    RHS_Slice(_ns_66779, 2, _33734);

    /** 		end while*/
    goto L5; // [182] 135
L6: 

    /** 		if length(ns) = 0 or equal( ns, "eu") then*/
    if (IS_SEQUENCE(_ns_66779)){
            _33736 = SEQ_PTR(_ns_66779)->length;
    }
    else {
        _33736 = 1;
    }
    _33737 = (_33736 == 0);
    _33736 = NOVALUE;
    if (_33737 != 0) {
        goto L8; // [194] 207
    }
    if (_ns_66779 == _23586)
    _33739 = 1;
    else if (IS_ATOM_INT(_ns_66779) && IS_ATOM_INT(_23586))
    _33739 = 0;
    else
    _33739 = (compare(_ns_66779, _23586) == 0);
    if (_33739 == 0)
    {
        _33739 = NOVALUE;
        goto L9; // [203] 214
    }
    else{
        _33739 = NOVALUE;
    }
L8: 

    /** 			return 0 -- bad syntax*/
    DeRefDS(_name_66771);
    DeRef(_ns_66779);
    DeRef(_33710);
    _33710 = NOVALUE;
    DeRef(_33712);
    _33712 = NOVALUE;
    DeRef(_33725);
    _33725 = NOVALUE;
    DeRef(_33719);
    _33719 = NOVALUE;
    DeRef(_33723);
    _33723 = NOVALUE;
    DeRef(_33737);
    _33737 = NOVALUE;
    DeRef(_33730);
    _33730 = NOVALUE;
    DeRef(_33733);
    _33733 = NOVALUE;
    return 0;
L9: 

    /** 		s = SymTab[TopLevelSub][S_NEXT]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _33740 = (int)*(((s1_ptr)_2)->base + _26TopLevelSub_11989);
    _2 = (int)SEQ_PTR(_33740);
    _s_66777 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_66777)){
        _s_66777 = (long)DBL_PTR(_s_66777)->dbl;
    }
    _33740 = NOVALUE;

    /** 		while s != 0 do*/
LA: 
    if (_s_66777 == 0)
    goto LB; // [237] 335

    /** 			if file = SymTab[s][S_FILE_NO] and*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _33743 = (int)*(((s1_ptr)_2)->base + _s_66777);
    _2 = (int)SEQ_PTR(_33743);
    if (!IS_ATOM_INT(_26S_FILE_NO_11650)){
        _33744 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_FILE_NO_11650)->dbl));
    }
    else{
        _33744 = (int)*(((s1_ptr)_2)->base + _26S_FILE_NO_11650);
    }
    _33743 = NOVALUE;
    if (IS_ATOM_INT(_33744)) {
        _33745 = (_file_66772 == _33744);
    }
    else {
        _33745 = binary_op(EQUALS, _file_66772, _33744);
    }
    _33744 = NOVALUE;
    if (IS_ATOM_INT(_33745)) {
        if (_33745 == 0) {
            DeRef(_33746);
            _33746 = 0;
            goto LC; // [259] 285
        }
    }
    else {
        if (DBL_PTR(_33745)->dbl == 0.0) {
            DeRef(_33746);
            _33746 = 0;
            goto LC; // [259] 285
        }
    }
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _33747 = (int)*(((s1_ptr)_2)->base + _s_66777);
    _2 = (int)SEQ_PTR(_33747);
    if (!IS_ATOM_INT(_26S_TOKEN_11659)){
        _33748 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_TOKEN_11659)->dbl));
    }
    else{
        _33748 = (int)*(((s1_ptr)_2)->base + _26S_TOKEN_11659);
    }
    _33747 = NOVALUE;
    if (IS_ATOM_INT(_33748)) {
        _33749 = (_33748 == 523);
    }
    else {
        _33749 = binary_op(EQUALS, _33748, 523);
    }
    _33748 = NOVALUE;
    DeRef(_33746);
    if (IS_ATOM_INT(_33749))
    _33746 = (_33749 != 0);
    else
    _33746 = DBL_PTR(_33749)->dbl != 0.0;
LC: 
    if (_33746 == 0) {
        goto LD; // [285] 314
    }
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _33751 = (int)*(((s1_ptr)_2)->base + _s_66777);
    _2 = (int)SEQ_PTR(_33751);
    if (!IS_ATOM_INT(_26S_NAME_11654)){
        _33752 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NAME_11654)->dbl));
    }
    else{
        _33752 = (int)*(((s1_ptr)_2)->base + _26S_NAME_11654);
    }
    _33751 = NOVALUE;
    if (_ns_66779 == _33752)
    _33753 = 1;
    else if (IS_ATOM_INT(_ns_66779) && IS_ATOM_INT(_33752))
    _33753 = 0;
    else
    _33753 = (compare(_ns_66779, _33752) == 0);
    _33752 = NOVALUE;
    if (_33753 == 0)
    {
        _33753 = NOVALUE;
        goto LD; // [306] 314
    }
    else{
        _33753 = NOVALUE;
    }

    /** 				exit*/
    goto LB; // [311] 335
LD: 

    /** 			s = SymTab[s][S_NEXT]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _33754 = (int)*(((s1_ptr)_2)->base + _s_66777);
    _2 = (int)SEQ_PTR(_33754);
    _s_66777 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_66777)){
        _s_66777 = (long)DBL_PTR(_s_66777)->dbl;
    }
    _33754 = NOVALUE;

    /** 		end while*/
    goto LA; // [332] 237
LB: 

    /** 		if s = 0 then*/
    if (_s_66777 != 0)
    goto LE; // [337] 348

    /** 			return 0 -- couldn't find ns*/
    DeRefDS(_name_66771);
    DeRef(_ns_66779);
    DeRef(_33710);
    _33710 = NOVALUE;
    DeRef(_33712);
    _33712 = NOVALUE;
    DeRef(_33725);
    _33725 = NOVALUE;
    DeRef(_33719);
    _33719 = NOVALUE;
    DeRef(_33723);
    _33723 = NOVALUE;
    DeRef(_33737);
    _33737 = NOVALUE;
    DeRef(_33730);
    _33730 = NOVALUE;
    DeRef(_33733);
    _33733 = NOVALUE;
    DeRef(_33745);
    _33745 = NOVALUE;
    DeRef(_33749);
    _33749 = NOVALUE;
    return 0;
LE: 

    /** 		ns_file = val[s]*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _ns_file_66781 = (int)*(((s1_ptr)_2)->base + _s_66777);
    if (!IS_ATOM_INT(_ns_file_66781))
    _ns_file_66781 = (long)DBL_PTR(_ns_file_66781)->dbl;

    /** 		while length(name) and (name[1] = ' ' or name[1] = '\t') do*/
LF: 
    if (IS_SEQUENCE(_name_66771)){
            _33758 = SEQ_PTR(_name_66771)->length;
    }
    else {
        _33758 = 1;
    }
    if (_33758 == 0) {
        goto L10; // [364] 411
    }
    _2 = (int)SEQ_PTR(_name_66771);
    _33760 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_33760)) {
        _33761 = (_33760 == 32);
    }
    else {
        _33761 = binary_op(EQUALS, _33760, 32);
    }
    _33760 = NOVALUE;
    if (IS_ATOM_INT(_33761)) {
        if (_33761 != 0) {
            DeRef(_33762);
            _33762 = 1;
            goto L11; // [376] 392
        }
    }
    else {
        if (DBL_PTR(_33761)->dbl != 0.0) {
            DeRef(_33762);
            _33762 = 1;
            goto L11; // [376] 392
        }
    }
    _2 = (int)SEQ_PTR(_name_66771);
    _33763 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_33763)) {
        _33764 = (_33763 == 9);
    }
    else {
        _33764 = binary_op(EQUALS, _33763, 9);
    }
    _33763 = NOVALUE;
    DeRef(_33762);
    if (IS_ATOM_INT(_33764))
    _33762 = (_33764 != 0);
    else
    _33762 = DBL_PTR(_33764)->dbl != 0.0;
L11: 
    if (_33762 == 0)
    {
        _33762 = NOVALUE;
        goto L10; // [393] 411
    }
    else{
        _33762 = NOVALUE;
    }

    /** 			name = name[2..$]*/
    if (IS_SEQUENCE(_name_66771)){
            _33765 = SEQ_PTR(_name_66771)->length;
    }
    else {
        _33765 = 1;
    }
    rhs_slice_target = (object_ptr)&_name_66771;
    RHS_Slice(_name_66771, 2, _33765);

    /** 		end while*/
    goto LF; // [408] 361
L10: 

    /** 		s = SymTab[TopLevelSub][S_NEXT]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _33767 = (int)*(((s1_ptr)_2)->base + _26TopLevelSub_11989);
    _2 = (int)SEQ_PTR(_33767);
    _s_66777 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_66777)){
        _s_66777 = (long)DBL_PTR(_s_66777)->dbl;
    }
    _33767 = NOVALUE;

    /** 		while s != 0 and (s <= stlen or SymTab[s][S_SCOPE] = SC_PRIVATE) do*/
L12: 
    _33769 = (_s_66777 != 0);
    if (_33769 == 0) {
        goto L13; // [438] 818
    }
    _33771 = (_s_66777 <= _stlen_66775);
    if (_33771 != 0) {
        DeRef(_33772);
        _33772 = 1;
        goto L14; // [446] 472
    }
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _33773 = (int)*(((s1_ptr)_2)->base + _s_66777);
    _2 = (int)SEQ_PTR(_33773);
    _33774 = (int)*(((s1_ptr)_2)->base + 4);
    _33773 = NOVALUE;
    if (IS_ATOM_INT(_33774)) {
        _33775 = (_33774 == 3);
    }
    else {
        _33775 = binary_op(EQUALS, _33774, 3);
    }
    _33774 = NOVALUE;
    if (IS_ATOM_INT(_33775))
    _33772 = (_33775 != 0);
    else
    _33772 = DBL_PTR(_33775)->dbl != 0.0;
L14: 
    if (_33772 == 0)
    {
        _33772 = NOVALUE;
        goto L13; // [473] 818
    }
    else{
        _33772 = NOVALUE;
    }

    /** 			integer scope = SymTab[s][S_SCOPE]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _33776 = (int)*(((s1_ptr)_2)->base + _s_66777);
    _2 = (int)SEQ_PTR(_33776);
    _scope_66881 = (int)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_scope_66881)){
        _scope_66881 = (long)DBL_PTR(_scope_66881)->dbl;
    }
    _33776 = NOVALUE;

    /** 			if (((scope = SC_PUBLIC) and*/
    _33778 = (_scope_66881 == 13);
    if (_33778 == 0) {
        _33779 = 0;
        goto L15; // [500] 584
    }
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _33780 = (int)*(((s1_ptr)_2)->base + _s_66777);
    _2 = (int)SEQ_PTR(_33780);
    if (!IS_ATOM_INT(_26S_FILE_NO_11650)){
        _33781 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_FILE_NO_11650)->dbl));
    }
    else{
        _33781 = (int)*(((s1_ptr)_2)->base + _26S_FILE_NO_11650);
    }
    _33780 = NOVALUE;
    if (IS_ATOM_INT(_33781)) {
        _33782 = (_33781 == _ns_file_66781);
    }
    else {
        _33782 = binary_op(EQUALS, _33781, _ns_file_66781);
    }
    _33781 = NOVALUE;
    if (IS_ATOM_INT(_33782)) {
        if (_33782 != 0) {
            DeRef(_33783);
            _33783 = 1;
            goto L16; // [520] 580
        }
    }
    else {
        if (DBL_PTR(_33782)->dbl != 0.0) {
            DeRef(_33783);
            _33783 = 1;
            goto L16; // [520] 580
        }
    }
    _2 = (int)SEQ_PTR(_27include_matrix_10928);
    _33784 = (int)*(((s1_ptr)_2)->base + _ns_file_66781);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _33785 = (int)*(((s1_ptr)_2)->base + _s_66777);
    _2 = (int)SEQ_PTR(_33785);
    if (!IS_ATOM_INT(_26S_FILE_NO_11650)){
        _33786 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_FILE_NO_11650)->dbl));
    }
    else{
        _33786 = (int)*(((s1_ptr)_2)->base + _26S_FILE_NO_11650);
    }
    _33785 = NOVALUE;
    _2 = (int)SEQ_PTR(_33784);
    if (!IS_ATOM_INT(_33786)){
        _33787 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_33786)->dbl));
    }
    else{
        _33787 = (int)*(((s1_ptr)_2)->base + _33786);
    }
    _33784 = NOVALUE;
    if (IS_ATOM_INT(_33787)) {
        {unsigned long tu;
             tu = (unsigned long)4 & (unsigned long)_33787;
             _33788 = MAKE_UINT(tu);
        }
    }
    else {
        _33788 = binary_op(AND_BITS, 4, _33787);
    }
    _33787 = NOVALUE;
    if (IS_ATOM_INT(_33788)) {
        if (_33788 == 0) {
            DeRef(_33789);
            _33789 = 0;
            goto L17; // [552] 576
        }
    }
    else {
        if (DBL_PTR(_33788)->dbl == 0.0) {
            DeRef(_33789);
            _33789 = 0;
            goto L17; // [552] 576
        }
    }
    _2 = (int)SEQ_PTR(_27include_matrix_10928);
    _33790 = (int)*(((s1_ptr)_2)->base + _file_66772);
    _2 = (int)SEQ_PTR(_33790);
    _33791 = (int)*(((s1_ptr)_2)->base + _ns_file_66781);
    _33790 = NOVALUE;
    if (IS_ATOM_INT(_33791)) {
        {unsigned long tu;
             tu = (unsigned long)6 & (unsigned long)_33791;
             _33792 = MAKE_UINT(tu);
        }
    }
    else {
        _33792 = binary_op(AND_BITS, 6, _33791);
    }
    _33791 = NOVALUE;
    DeRef(_33789);
    if (IS_ATOM_INT(_33792))
    _33789 = (_33792 != 0);
    else
    _33789 = DBL_PTR(_33792)->dbl != 0.0;
L17: 
    DeRef(_33783);
    _33783 = (_33789 != 0);
L16: 
    _33779 = (_33783 != 0);
L15: 
    if (_33779 != 0) {
        _33793 = 1;
        goto L18; // [584] 646
    }
    _33794 = (_scope_66881 == 11);
    if (_33794 == 0) {
        _33795 = 0;
        goto L19; // [594] 618
    }
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _33796 = (int)*(((s1_ptr)_2)->base + _s_66777);
    _2 = (int)SEQ_PTR(_33796);
    if (!IS_ATOM_INT(_26S_FILE_NO_11650)){
        _33797 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_FILE_NO_11650)->dbl));
    }
    else{
        _33797 = (int)*(((s1_ptr)_2)->base + _26S_FILE_NO_11650);
    }
    _33796 = NOVALUE;
    if (IS_ATOM_INT(_33797)) {
        _33798 = (_33797 == _ns_file_66781);
    }
    else {
        _33798 = binary_op(EQUALS, _33797, _ns_file_66781);
    }
    _33797 = NOVALUE;
    if (IS_ATOM_INT(_33798))
    _33795 = (_33798 != 0);
    else
    _33795 = DBL_PTR(_33798)->dbl != 0.0;
L19: 
    if (_33795 == 0) {
        _33799 = 0;
        goto L1A; // [618] 642
    }
    _2 = (int)SEQ_PTR(_27include_matrix_10928);
    _33800 = (int)*(((s1_ptr)_2)->base + _file_66772);
    _2 = (int)SEQ_PTR(_33800);
    _33801 = (int)*(((s1_ptr)_2)->base + _ns_file_66781);
    _33800 = NOVALUE;
    if (IS_ATOM_INT(_33801)) {
        {unsigned long tu;
             tu = (unsigned long)2 & (unsigned long)_33801;
             _33802 = MAKE_UINT(tu);
        }
    }
    else {
        _33802 = binary_op(AND_BITS, 2, _33801);
    }
    _33801 = NOVALUE;
    if (IS_ATOM_INT(_33802))
    _33799 = (_33802 != 0);
    else
    _33799 = DBL_PTR(_33802)->dbl != 0.0;
L1A: 
    _33793 = (_33799 != 0);
L18: 
    if (_33793 != 0) {
        _33803 = 1;
        goto L1B; // [646] 660
    }
    _33804 = (_scope_66881 == 6);
    _33803 = (_33804 != 0);
L1B: 
    if (_33803 == 0) {
        _33805 = 0;
        goto L1C; // [660] 738
    }
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _33806 = (int)*(((s1_ptr)_2)->base + _s_66777);
    _2 = (int)SEQ_PTR(_33806);
    if (!IS_ATOM_INT(_26S_FILE_NO_11650)){
        _33807 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_FILE_NO_11650)->dbl));
    }
    else{
        _33807 = (int)*(((s1_ptr)_2)->base + _26S_FILE_NO_11650);
    }
    _33806 = NOVALUE;
    if (IS_ATOM_INT(_33807)) {
        _33808 = (_33807 == _ns_file_66781);
    }
    else {
        _33808 = binary_op(EQUALS, _33807, _ns_file_66781);
    }
    _33807 = NOVALUE;
    if (IS_ATOM_INT(_33808)) {
        if (_33808 != 0) {
            DeRef(_33809);
            _33809 = 1;
            goto L1D; // [680] 734
        }
    }
    else {
        if (DBL_PTR(_33808)->dbl != 0.0) {
            DeRef(_33809);
            _33809 = 1;
            goto L1D; // [680] 734
        }
    }
    _2 = (int)SEQ_PTR(_27include_matrix_10928);
    _33810 = (int)*(((s1_ptr)_2)->base + _ns_file_66781);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _33811 = (int)*(((s1_ptr)_2)->base + _s_66777);
    _2 = (int)SEQ_PTR(_33811);
    if (!IS_ATOM_INT(_26S_FILE_NO_11650)){
        _33812 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_FILE_NO_11650)->dbl));
    }
    else{
        _33812 = (int)*(((s1_ptr)_2)->base + _26S_FILE_NO_11650);
    }
    _33811 = NOVALUE;
    _2 = (int)SEQ_PTR(_33810);
    if (!IS_ATOM_INT(_33812)){
        _33813 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_33812)->dbl));
    }
    else{
        _33813 = (int)*(((s1_ptr)_2)->base + _33812);
    }
    _33810 = NOVALUE;
    if (IS_ATOM_INT(_33813)) {
        if (_33813 == 0) {
            DeRef(_33814);
            _33814 = 0;
            goto L1E; // [706] 730
        }
    }
    else {
        if (DBL_PTR(_33813)->dbl == 0.0) {
            DeRef(_33814);
            _33814 = 0;
            goto L1E; // [706] 730
        }
    }
    _2 = (int)SEQ_PTR(_27include_matrix_10928);
    _33815 = (int)*(((s1_ptr)_2)->base + _file_66772);
    _2 = (int)SEQ_PTR(_33815);
    _33816 = (int)*(((s1_ptr)_2)->base + _ns_file_66781);
    _33815 = NOVALUE;
    if (IS_ATOM_INT(_33816)) {
        {unsigned long tu;
             tu = (unsigned long)6 & (unsigned long)_33816;
             _33817 = MAKE_UINT(tu);
        }
    }
    else {
        _33817 = binary_op(AND_BITS, 6, _33816);
    }
    _33816 = NOVALUE;
    DeRef(_33814);
    if (IS_ATOM_INT(_33817))
    _33814 = (_33817 != 0);
    else
    _33814 = DBL_PTR(_33817)->dbl != 0.0;
L1E: 
    DeRef(_33809);
    _33809 = (_33814 != 0);
L1D: 
    _33805 = (_33809 != 0);
L1C: 
    if (_33805 != 0) {
        _33818 = 1;
        goto L1F; // [738] 764
    }
    _33819 = (_scope_66881 == 5);
    if (_33819 == 0) {
        _33820 = 0;
        goto L20; // [748] 760
    }
    _33821 = (_ns_file_66781 == _file_66772);
    _33820 = (_33821 != 0);
L20: 
    _33818 = (_33820 != 0);
L1F: 
    if (_33818 == 0) {
        goto L21; // [764] 795
    }
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _33823 = (int)*(((s1_ptr)_2)->base + _s_66777);
    _2 = (int)SEQ_PTR(_33823);
    if (!IS_ATOM_INT(_26S_NAME_11654)){
        _33824 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NAME_11654)->dbl));
    }
    else{
        _33824 = (int)*(((s1_ptr)_2)->base + _26S_NAME_11654);
    }
    _33823 = NOVALUE;
    if (_33824 == _name_66771)
    _33825 = 1;
    else if (IS_ATOM_INT(_33824) && IS_ATOM_INT(_name_66771))
    _33825 = 0;
    else
    _33825 = (compare(_33824, _name_66771) == 0);
    _33824 = NOVALUE;
    if (_33825 == 0)
    {
        _33825 = NOVALUE;
        goto L21; // [785] 795
    }
    else{
        _33825 = NOVALUE;
    }

    /** 				return s*/
    DeRefDS(_name_66771);
    DeRef(_ns_66779);
    DeRef(_33730);
    _33730 = NOVALUE;
    DeRef(_33745);
    _33745 = NOVALUE;
    _33813 = NOVALUE;
    DeRef(_33817);
    _33817 = NOVALUE;
    DeRef(_33764);
    _33764 = NOVALUE;
    DeRef(_33808);
    _33808 = NOVALUE;
    DeRef(_33749);
    _33749 = NOVALUE;
    DeRef(_33792);
    _33792 = NOVALUE;
    DeRef(_33725);
    _33725 = NOVALUE;
    DeRef(_33782);
    _33782 = NOVALUE;
    DeRef(_33712);
    _33712 = NOVALUE;
    DeRef(_33771);
    _33771 = NOVALUE;
    DeRef(_33769);
    _33769 = NOVALUE;
    DeRef(_33733);
    _33733 = NOVALUE;
    DeRef(_33798);
    _33798 = NOVALUE;
    DeRef(_33719);
    _33719 = NOVALUE;
    DeRef(_33710);
    _33710 = NOVALUE;
    DeRef(_33788);
    _33788 = NOVALUE;
    DeRef(_33819);
    _33819 = NOVALUE;
    DeRef(_33821);
    _33821 = NOVALUE;
    DeRef(_33723);
    _33723 = NOVALUE;
    _33786 = NOVALUE;
    DeRef(_33737);
    _33737 = NOVALUE;
    DeRef(_33778);
    _33778 = NOVALUE;
    DeRef(_33761);
    _33761 = NOVALUE;
    DeRef(_33802);
    _33802 = NOVALUE;
    _33812 = NOVALUE;
    DeRef(_33804);
    _33804 = NOVALUE;
    DeRef(_33775);
    _33775 = NOVALUE;
    DeRef(_33794);
    _33794 = NOVALUE;
    return _s_66777;
L21: 

    /** 			s = SymTab[s][S_NEXT]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _33826 = (int)*(((s1_ptr)_2)->base + _s_66777);
    _2 = (int)SEQ_PTR(_33826);
    _s_66777 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_66777)){
        _s_66777 = (long)DBL_PTR(_s_66777)->dbl;
    }
    _33826 = NOVALUE;

    /** 		end while*/
    goto L12; // [815] 434
L13: 

    /** 		return 0 -- couldn't find name in ns file*/
    DeRefDS(_name_66771);
    DeRef(_ns_66779);
    DeRef(_33730);
    _33730 = NOVALUE;
    DeRef(_33745);
    _33745 = NOVALUE;
    _33813 = NOVALUE;
    DeRef(_33817);
    _33817 = NOVALUE;
    DeRef(_33764);
    _33764 = NOVALUE;
    DeRef(_33808);
    _33808 = NOVALUE;
    DeRef(_33749);
    _33749 = NOVALUE;
    DeRef(_33792);
    _33792 = NOVALUE;
    DeRef(_33725);
    _33725 = NOVALUE;
    DeRef(_33782);
    _33782 = NOVALUE;
    DeRef(_33712);
    _33712 = NOVALUE;
    DeRef(_33771);
    _33771 = NOVALUE;
    DeRef(_33769);
    _33769 = NOVALUE;
    DeRef(_33733);
    _33733 = NOVALUE;
    DeRef(_33798);
    _33798 = NOVALUE;
    DeRef(_33719);
    _33719 = NOVALUE;
    DeRef(_33710);
    _33710 = NOVALUE;
    DeRef(_33788);
    _33788 = NOVALUE;
    DeRef(_33819);
    _33819 = NOVALUE;
    DeRef(_33821);
    _33821 = NOVALUE;
    DeRef(_33723);
    _33723 = NOVALUE;
    _33786 = NOVALUE;
    DeRef(_33737);
    _33737 = NOVALUE;
    DeRef(_33778);
    _33778 = NOVALUE;
    DeRef(_33761);
    _33761 = NOVALUE;
    DeRef(_33802);
    _33802 = NOVALUE;
    _33812 = NOVALUE;
    DeRef(_33804);
    _33804 = NOVALUE;
    DeRef(_33775);
    _33775 = NOVALUE;
    DeRef(_33794);
    _33794 = NOVALUE;
    return 0;
    goto L22; // [824] 1636
L1: 

    /** 		if proc != TopLevelSub then*/
    if (_proc_66774 == _26TopLevelSub_11989)
    goto L23; // [831] 958

    /** 			s = SymTab[proc][S_NEXT]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _33829 = (int)*(((s1_ptr)_2)->base + _proc_66774);
    _2 = (int)SEQ_PTR(_33829);
    _s_66777 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_66777)){
        _s_66777 = (long)DBL_PTR(_s_66777)->dbl;
    }
    _33829 = NOVALUE;

    /** 			while s and (SymTab[s][S_SCOPE] = SC_PRIVATE or*/
L24: 
    if (_s_66777 == 0) {
        goto L25; // [856] 957
    }
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _33832 = (int)*(((s1_ptr)_2)->base + _s_66777);
    _2 = (int)SEQ_PTR(_33832);
    _33833 = (int)*(((s1_ptr)_2)->base + 4);
    _33832 = NOVALUE;
    if (IS_ATOM_INT(_33833)) {
        _33834 = (_33833 == 3);
    }
    else {
        _33834 = binary_op(EQUALS, _33833, 3);
    }
    _33833 = NOVALUE;
    if (IS_ATOM_INT(_33834)) {
        if (_33834 != 0) {
            DeRef(_33835);
            _33835 = 1;
            goto L26; // [878] 904
        }
    }
    else {
        if (DBL_PTR(_33834)->dbl != 0.0) {
            DeRef(_33835);
            _33835 = 1;
            goto L26; // [878] 904
        }
    }
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _33836 = (int)*(((s1_ptr)_2)->base + _s_66777);
    _2 = (int)SEQ_PTR(_33836);
    _33837 = (int)*(((s1_ptr)_2)->base + 4);
    _33836 = NOVALUE;
    if (IS_ATOM_INT(_33837)) {
        _33838 = (_33837 == 2);
    }
    else {
        _33838 = binary_op(EQUALS, _33837, 2);
    }
    _33837 = NOVALUE;
    DeRef(_33835);
    if (IS_ATOM_INT(_33838))
    _33835 = (_33838 != 0);
    else
    _33835 = DBL_PTR(_33838)->dbl != 0.0;
L26: 
    if (_33835 == 0)
    {
        _33835 = NOVALUE;
        goto L25; // [905] 957
    }
    else{
        _33835 = NOVALUE;
    }

    /** 				if equal(name, SymTab[s][S_NAME]) then*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _33839 = (int)*(((s1_ptr)_2)->base + _s_66777);
    _2 = (int)SEQ_PTR(_33839);
    if (!IS_ATOM_INT(_26S_NAME_11654)){
        _33840 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NAME_11654)->dbl));
    }
    else{
        _33840 = (int)*(((s1_ptr)_2)->base + _26S_NAME_11654);
    }
    _33839 = NOVALUE;
    if (_name_66771 == _33840)
    _33841 = 1;
    else if (IS_ATOM_INT(_name_66771) && IS_ATOM_INT(_33840))
    _33841 = 0;
    else
    _33841 = (compare(_name_66771, _33840) == 0);
    _33840 = NOVALUE;
    if (_33841 == 0)
    {
        _33841 = NOVALUE;
        goto L27; // [926] 936
    }
    else{
        _33841 = NOVALUE;
    }

    /** 					return s*/
    DeRefDS(_name_66771);
    DeRef(_ns_66779);
    DeRef(_33730);
    _33730 = NOVALUE;
    DeRef(_33745);
    _33745 = NOVALUE;
    _33813 = NOVALUE;
    DeRef(_33817);
    _33817 = NOVALUE;
    DeRef(_33834);
    _33834 = NOVALUE;
    DeRef(_33764);
    _33764 = NOVALUE;
    DeRef(_33808);
    _33808 = NOVALUE;
    DeRef(_33749);
    _33749 = NOVALUE;
    DeRef(_33792);
    _33792 = NOVALUE;
    DeRef(_33725);
    _33725 = NOVALUE;
    DeRef(_33782);
    _33782 = NOVALUE;
    DeRef(_33712);
    _33712 = NOVALUE;
    DeRef(_33771);
    _33771 = NOVALUE;
    DeRef(_33769);
    _33769 = NOVALUE;
    DeRef(_33733);
    _33733 = NOVALUE;
    DeRef(_33838);
    _33838 = NOVALUE;
    DeRef(_33798);
    _33798 = NOVALUE;
    DeRef(_33719);
    _33719 = NOVALUE;
    DeRef(_33710);
    _33710 = NOVALUE;
    DeRef(_33788);
    _33788 = NOVALUE;
    DeRef(_33819);
    _33819 = NOVALUE;
    DeRef(_33821);
    _33821 = NOVALUE;
    DeRef(_33723);
    _33723 = NOVALUE;
    _33786 = NOVALUE;
    DeRef(_33737);
    _33737 = NOVALUE;
    DeRef(_33778);
    _33778 = NOVALUE;
    DeRef(_33761);
    _33761 = NOVALUE;
    DeRef(_33802);
    _33802 = NOVALUE;
    _33812 = NOVALUE;
    DeRef(_33804);
    _33804 = NOVALUE;
    DeRef(_33775);
    _33775 = NOVALUE;
    DeRef(_33794);
    _33794 = NOVALUE;
    return _s_66777;
L27: 

    /** 				s = SymTab[s][S_NEXT]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _33842 = (int)*(((s1_ptr)_2)->base + _s_66777);
    _2 = (int)SEQ_PTR(_33842);
    _s_66777 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_66777)){
        _s_66777 = (long)DBL_PTR(_s_66777)->dbl;
    }
    _33842 = NOVALUE;

    /** 			end while*/
    goto L24; // [954] 856
L25: 
L23: 

    /** 		s = SymTab[TopLevelSub][S_NEXT]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _33844 = (int)*(((s1_ptr)_2)->base + _26TopLevelSub_11989);
    _2 = (int)SEQ_PTR(_33844);
    _s_66777 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_66777)){
        _s_66777 = (long)DBL_PTR(_s_66777)->dbl;
    }
    _33844 = NOVALUE;

    /** 		found_in_path = 0*/
    _found_in_path_66782 = 0;

    /** 		found_outside_path = 0*/
    _found_outside_path_66783 = 0;

    /** 		while s != 0 and (s <= stlen or SymTab[s][S_SCOPE] = SC_PRIVATE) do*/
L28: 
    _33846 = (_s_66777 != 0);
    if (_33846 == 0) {
        goto L29; // [995] 1221
    }
    _33848 = (_s_66777 <= _stlen_66775);
    if (_33848 != 0) {
        DeRef(_33849);
        _33849 = 1;
        goto L2A; // [1003] 1029
    }
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _33850 = (int)*(((s1_ptr)_2)->base + _s_66777);
    _2 = (int)SEQ_PTR(_33850);
    _33851 = (int)*(((s1_ptr)_2)->base + 4);
    _33850 = NOVALUE;
    if (IS_ATOM_INT(_33851)) {
        _33852 = (_33851 == 3);
    }
    else {
        _33852 = binary_op(EQUALS, _33851, 3);
    }
    _33851 = NOVALUE;
    if (IS_ATOM_INT(_33852))
    _33849 = (_33852 != 0);
    else
    _33849 = DBL_PTR(_33852)->dbl != 0.0;
L2A: 
    if (_33849 == 0)
    {
        _33849 = NOVALUE;
        goto L29; // [1030] 1221
    }
    else{
        _33849 = NOVALUE;
    }

    /** 			if SymTab[s][S_FILE_NO] = file and*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _33853 = (int)*(((s1_ptr)_2)->base + _s_66777);
    _2 = (int)SEQ_PTR(_33853);
    if (!IS_ATOM_INT(_26S_FILE_NO_11650)){
        _33854 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_FILE_NO_11650)->dbl));
    }
    else{
        _33854 = (int)*(((s1_ptr)_2)->base + _26S_FILE_NO_11650);
    }
    _33853 = NOVALUE;
    if (IS_ATOM_INT(_33854)) {
        _33855 = (_33854 == _file_66772);
    }
    else {
        _33855 = binary_op(EQUALS, _33854, _file_66772);
    }
    _33854 = NOVALUE;
    if (IS_ATOM_INT(_33855)) {
        if (_33855 == 0) {
            DeRef(_33856);
            _33856 = 0;
            goto L2B; // [1051] 1169
        }
    }
    else {
        if (DBL_PTR(_33855)->dbl == 0.0) {
            DeRef(_33856);
            _33856 = 0;
            goto L2B; // [1051] 1169
        }
    }
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _33857 = (int)*(((s1_ptr)_2)->base + _s_66777);
    _2 = (int)SEQ_PTR(_33857);
    _33858 = (int)*(((s1_ptr)_2)->base + 4);
    _33857 = NOVALUE;
    if (IS_ATOM_INT(_33858)) {
        _33859 = (_33858 == 5);
    }
    else {
        _33859 = binary_op(EQUALS, _33858, 5);
    }
    _33858 = NOVALUE;
    if (IS_ATOM_INT(_33859)) {
        if (_33859 != 0) {
            DeRef(_33860);
            _33860 = 1;
            goto L2C; // [1073] 1099
        }
    }
    else {
        if (DBL_PTR(_33859)->dbl != 0.0) {
            DeRef(_33860);
            _33860 = 1;
            goto L2C; // [1073] 1099
        }
    }
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _33861 = (int)*(((s1_ptr)_2)->base + _s_66777);
    _2 = (int)SEQ_PTR(_33861);
    _33862 = (int)*(((s1_ptr)_2)->base + 4);
    _33861 = NOVALUE;
    if (IS_ATOM_INT(_33862)) {
        _33863 = (_33862 == 6);
    }
    else {
        _33863 = binary_op(EQUALS, _33862, 6);
    }
    _33862 = NOVALUE;
    DeRef(_33860);
    if (IS_ATOM_INT(_33863))
    _33860 = (_33863 != 0);
    else
    _33860 = DBL_PTR(_33863)->dbl != 0.0;
L2C: 
    if (_33860 != 0) {
        _33864 = 1;
        goto L2D; // [1099] 1125
    }
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _33865 = (int)*(((s1_ptr)_2)->base + _s_66777);
    _2 = (int)SEQ_PTR(_33865);
    _33866 = (int)*(((s1_ptr)_2)->base + 4);
    _33865 = NOVALUE;
    if (IS_ATOM_INT(_33866)) {
        _33867 = (_33866 == 11);
    }
    else {
        _33867 = binary_op(EQUALS, _33866, 11);
    }
    _33866 = NOVALUE;
    if (IS_ATOM_INT(_33867))
    _33864 = (_33867 != 0);
    else
    _33864 = DBL_PTR(_33867)->dbl != 0.0;
L2D: 
    if (_33864 != 0) {
        _33868 = 1;
        goto L2E; // [1125] 1165
    }
    _33869 = (_proc_66774 == _26TopLevelSub_11989);
    if (_33869 == 0) {
        _33870 = 0;
        goto L2F; // [1135] 1161
    }
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _33871 = (int)*(((s1_ptr)_2)->base + _s_66777);
    _2 = (int)SEQ_PTR(_33871);
    _33872 = (int)*(((s1_ptr)_2)->base + 4);
    _33871 = NOVALUE;
    if (IS_ATOM_INT(_33872)) {
        _33873 = (_33872 == 4);
    }
    else {
        _33873 = binary_op(EQUALS, _33872, 4);
    }
    _33872 = NOVALUE;
    if (IS_ATOM_INT(_33873))
    _33870 = (_33873 != 0);
    else
    _33870 = DBL_PTR(_33873)->dbl != 0.0;
L2F: 
    _33868 = (_33870 != 0);
L2E: 
    DeRef(_33856);
    _33856 = (_33868 != 0);
L2B: 
    if (_33856 == 0) {
        goto L30; // [1169] 1200
    }
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _33875 = (int)*(((s1_ptr)_2)->base + _s_66777);
    _2 = (int)SEQ_PTR(_33875);
    if (!IS_ATOM_INT(_26S_NAME_11654)){
        _33876 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NAME_11654)->dbl));
    }
    else{
        _33876 = (int)*(((s1_ptr)_2)->base + _26S_NAME_11654);
    }
    _33875 = NOVALUE;
    if (_name_66771 == _33876)
    _33877 = 1;
    else if (IS_ATOM_INT(_name_66771) && IS_ATOM_INT(_33876))
    _33877 = 0;
    else
    _33877 = (compare(_name_66771, _33876) == 0);
    _33876 = NOVALUE;
    if (_33877 == 0)
    {
        _33877 = NOVALUE;
        goto L30; // [1190] 1200
    }
    else{
        _33877 = NOVALUE;
    }

    /** 				return s*/
    DeRefDS(_name_66771);
    DeRef(_ns_66779);
    DeRef(_33730);
    _33730 = NOVALUE;
    DeRef(_33745);
    _33745 = NOVALUE;
    _33813 = NOVALUE;
    DeRef(_33817);
    _33817 = NOVALUE;
    DeRef(_33852);
    _33852 = NOVALUE;
    DeRef(_33834);
    _33834 = NOVALUE;
    DeRef(_33764);
    _33764 = NOVALUE;
    DeRef(_33808);
    _33808 = NOVALUE;
    DeRef(_33855);
    _33855 = NOVALUE;
    DeRef(_33749);
    _33749 = NOVALUE;
    DeRef(_33792);
    _33792 = NOVALUE;
    DeRef(_33725);
    _33725 = NOVALUE;
    DeRef(_33867);
    _33867 = NOVALUE;
    DeRef(_33782);
    _33782 = NOVALUE;
    DeRef(_33712);
    _33712 = NOVALUE;
    DeRef(_33771);
    _33771 = NOVALUE;
    DeRef(_33769);
    _33769 = NOVALUE;
    DeRef(_33733);
    _33733 = NOVALUE;
    DeRef(_33848);
    _33848 = NOVALUE;
    DeRef(_33838);
    _33838 = NOVALUE;
    DeRef(_33798);
    _33798 = NOVALUE;
    DeRef(_33719);
    _33719 = NOVALUE;
    DeRef(_33710);
    _33710 = NOVALUE;
    DeRef(_33788);
    _33788 = NOVALUE;
    DeRef(_33819);
    _33819 = NOVALUE;
    DeRef(_33846);
    _33846 = NOVALUE;
    DeRef(_33821);
    _33821 = NOVALUE;
    DeRef(_33723);
    _33723 = NOVALUE;
    _33786 = NOVALUE;
    DeRef(_33737);
    _33737 = NOVALUE;
    DeRef(_33778);
    _33778 = NOVALUE;
    DeRef(_33863);
    _33863 = NOVALUE;
    DeRef(_33761);
    _33761 = NOVALUE;
    DeRef(_33802);
    _33802 = NOVALUE;
    _33812 = NOVALUE;
    DeRef(_33869);
    _33869 = NOVALUE;
    DeRef(_33804);
    _33804 = NOVALUE;
    DeRef(_33859);
    _33859 = NOVALUE;
    DeRef(_33873);
    _33873 = NOVALUE;
    DeRef(_33775);
    _33775 = NOVALUE;
    DeRef(_33794);
    _33794 = NOVALUE;
    return _s_66777;
L30: 

    /** 			s = SymTab[s][S_NEXT]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _33878 = (int)*(((s1_ptr)_2)->base + _s_66777);
    _2 = (int)SEQ_PTR(_33878);
    _s_66777 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_66777)){
        _s_66777 = (long)DBL_PTR(_s_66777)->dbl;
    }
    _33878 = NOVALUE;

    /** 		end while*/
    goto L28; // [1218] 991
L29: 

    /** 		global_found = FALSE*/
    _global_found_66778 = _9FALSE_428;

    /** 		s = SymTab[TopLevelSub][S_NEXT]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _33880 = (int)*(((s1_ptr)_2)->base + _26TopLevelSub_11989);
    _2 = (int)SEQ_PTR(_33880);
    _s_66777 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_66777)){
        _s_66777 = (long)DBL_PTR(_s_66777)->dbl;
    }
    _33880 = NOVALUE;

    /** 		while s != 0 and (s <= stlen or SymTab[s][S_SCOPE] = SC_PRIVATE) do*/
L31: 
    _33882 = (_s_66777 != 0);
    if (_33882 == 0) {
        goto L32; // [1257] 1600
    }
    _33884 = (_s_66777 <= _stlen_66775);
    if (_33884 != 0) {
        DeRef(_33885);
        _33885 = 1;
        goto L33; // [1265] 1291
    }
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _33886 = (int)*(((s1_ptr)_2)->base + _s_66777);
    _2 = (int)SEQ_PTR(_33886);
    _33887 = (int)*(((s1_ptr)_2)->base + 4);
    _33886 = NOVALUE;
    if (IS_ATOM_INT(_33887)) {
        _33888 = (_33887 == 3);
    }
    else {
        _33888 = binary_op(EQUALS, _33887, 3);
    }
    _33887 = NOVALUE;
    if (IS_ATOM_INT(_33888))
    _33885 = (_33888 != 0);
    else
    _33885 = DBL_PTR(_33888)->dbl != 0.0;
L33: 
    if (_33885 == 0)
    {
        _33885 = NOVALUE;
        goto L32; // [1292] 1600
    }
    else{
        _33885 = NOVALUE;
    }

    /** 			if SymTab[s][S_SCOPE] = SC_GLOBAL and*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _33889 = (int)*(((s1_ptr)_2)->base + _s_66777);
    _2 = (int)SEQ_PTR(_33889);
    _33890 = (int)*(((s1_ptr)_2)->base + 4);
    _33889 = NOVALUE;
    if (IS_ATOM_INT(_33890)) {
        _33891 = (_33890 == 6);
    }
    else {
        _33891 = binary_op(EQUALS, _33890, 6);
    }
    _33890 = NOVALUE;
    if (IS_ATOM_INT(_33891)) {
        if (_33891 == 0) {
            goto L34; // [1315] 1413
        }
    }
    else {
        if (DBL_PTR(_33891)->dbl == 0.0) {
            goto L34; // [1315] 1413
        }
    }
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _33893 = (int)*(((s1_ptr)_2)->base + _s_66777);
    _2 = (int)SEQ_PTR(_33893);
    if (!IS_ATOM_INT(_26S_NAME_11654)){
        _33894 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NAME_11654)->dbl));
    }
    else{
        _33894 = (int)*(((s1_ptr)_2)->base + _26S_NAME_11654);
    }
    _33893 = NOVALUE;
    if (_name_66771 == _33894)
    _33895 = 1;
    else if (IS_ATOM_INT(_name_66771) && IS_ATOM_INT(_33894))
    _33895 = 0;
    else
    _33895 = (compare(_name_66771, _33894) == 0);
    _33894 = NOVALUE;
    if (_33895 == 0)
    {
        _33895 = NOVALUE;
        goto L34; // [1336] 1413
    }
    else{
        _33895 = NOVALUE;
    }

    /** 				s_in_include_path = include_matrix[file][SymTab[s][S_FILE_NO]] != 0*/
    _2 = (int)SEQ_PTR(_27include_matrix_10928);
    _33896 = (int)*(((s1_ptr)_2)->base + _file_66772);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _33897 = (int)*(((s1_ptr)_2)->base + _s_66777);
    _2 = (int)SEQ_PTR(_33897);
    if (!IS_ATOM_INT(_26S_FILE_NO_11650)){
        _33898 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_FILE_NO_11650)->dbl));
    }
    else{
        _33898 = (int)*(((s1_ptr)_2)->base + _26S_FILE_NO_11650);
    }
    _33897 = NOVALUE;
    _2 = (int)SEQ_PTR(_33896);
    if (!IS_ATOM_INT(_33898)){
        _33899 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_33898)->dbl));
    }
    else{
        _33899 = (int)*(((s1_ptr)_2)->base + _33898);
    }
    _33896 = NOVALUE;
    if (IS_ATOM_INT(_33899)) {
        _s_in_include_path_66784 = (_33899 != 0);
    }
    else {
        _s_in_include_path_66784 = binary_op(NOTEQ, _33899, 0);
    }
    _33899 = NOVALUE;
    if (!IS_ATOM_INT(_s_in_include_path_66784)) {
        _1 = (long)(DBL_PTR(_s_in_include_path_66784)->dbl);
        DeRefDS(_s_in_include_path_66784);
        _s_in_include_path_66784 = _1;
    }

    /** 				if s_in_include_path then*/
    if (_s_in_include_path_66784 == 0)
    {
        goto L35; // [1371] 1390
    }
    else{
    }

    /** 					global_found = s*/
    _global_found_66778 = _s_66777;

    /** 					found_in_path += 1*/
    _found_in_path_66782 = _found_in_path_66782 + 1;
    goto L36; // [1387] 1579
L35: 

    /** 					if not found_in_path then*/
    if (_found_in_path_66782 != 0)
    goto L37; // [1392] 1403

    /** 						global_found = s*/
    _global_found_66778 = _s_66777;
L37: 

    /** 					found_outside_path += 1*/
    _found_outside_path_66783 = _found_outside_path_66783 + 1;
    goto L36; // [1410] 1579
L34: 

    /** 			elsif (sym_scope( s ) = SC_PUBLIC and equal( name, SymTab[s][S_NAME] ) and*/
    _33904 = _52sym_scope(_s_66777);
    if (IS_ATOM_INT(_33904)) {
        _33905 = (_33904 == 13);
    }
    else {
        _33905 = binary_op(EQUALS, _33904, 13);
    }
    DeRef(_33904);
    _33904 = NOVALUE;
    if (IS_ATOM_INT(_33905)) {
        if (_33905 == 0) {
            DeRef(_33906);
            _33906 = 0;
            goto L38; // [1425] 1449
        }
    }
    else {
        if (DBL_PTR(_33905)->dbl == 0.0) {
            DeRef(_33906);
            _33906 = 0;
            goto L38; // [1425] 1449
        }
    }
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _33907 = (int)*(((s1_ptr)_2)->base + _s_66777);
    _2 = (int)SEQ_PTR(_33907);
    if (!IS_ATOM_INT(_26S_NAME_11654)){
        _33908 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NAME_11654)->dbl));
    }
    else{
        _33908 = (int)*(((s1_ptr)_2)->base + _26S_NAME_11654);
    }
    _33907 = NOVALUE;
    if (_name_66771 == _33908)
    _33909 = 1;
    else if (IS_ATOM_INT(_name_66771) && IS_ATOM_INT(_33908))
    _33909 = 0;
    else
    _33909 = (compare(_name_66771, _33908) == 0);
    _33908 = NOVALUE;
    DeRef(_33906);
    _33906 = (_33909 != 0);
L38: 
    if (_33906 == 0) {
        _33910 = 0;
        goto L39; // [1449] 1485
    }
    _2 = (int)SEQ_PTR(_27include_matrix_10928);
    _33911 = (int)*(((s1_ptr)_2)->base + _file_66772);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _33912 = (int)*(((s1_ptr)_2)->base + _s_66777);
    _2 = (int)SEQ_PTR(_33912);
    if (!IS_ATOM_INT(_26S_FILE_NO_11650)){
        _33913 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_FILE_NO_11650)->dbl));
    }
    else{
        _33913 = (int)*(((s1_ptr)_2)->base + _26S_FILE_NO_11650);
    }
    _33912 = NOVALUE;
    _2 = (int)SEQ_PTR(_33911);
    if (!IS_ATOM_INT(_33913)){
        _33914 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_33913)->dbl));
    }
    else{
        _33914 = (int)*(((s1_ptr)_2)->base + _33913);
    }
    _33911 = NOVALUE;
    if (IS_ATOM_INT(_33914)) {
        {unsigned long tu;
             tu = (unsigned long)6 & (unsigned long)_33914;
             _33915 = MAKE_UINT(tu);
        }
    }
    else {
        _33915 = binary_op(AND_BITS, 6, _33914);
    }
    _33914 = NOVALUE;
    if (IS_ATOM_INT(_33915))
    _33910 = (_33915 != 0);
    else
    _33910 = DBL_PTR(_33915)->dbl != 0.0;
L39: 
    if (_33910 != 0) {
        goto L3A; // [1485] 1564
    }
    _33917 = _52sym_scope(_s_66777);
    if (IS_ATOM_INT(_33917)) {
        _33918 = (_33917 == 11);
    }
    else {
        _33918 = binary_op(EQUALS, _33917, 11);
    }
    DeRef(_33917);
    _33917 = NOVALUE;
    if (IS_ATOM_INT(_33918)) {
        if (_33918 == 0) {
            DeRef(_33919);
            _33919 = 0;
            goto L3B; // [1499] 1523
        }
    }
    else {
        if (DBL_PTR(_33918)->dbl == 0.0) {
            DeRef(_33919);
            _33919 = 0;
            goto L3B; // [1499] 1523
        }
    }
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _33920 = (int)*(((s1_ptr)_2)->base + _s_66777);
    _2 = (int)SEQ_PTR(_33920);
    if (!IS_ATOM_INT(_26S_NAME_11654)){
        _33921 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NAME_11654)->dbl));
    }
    else{
        _33921 = (int)*(((s1_ptr)_2)->base + _26S_NAME_11654);
    }
    _33920 = NOVALUE;
    if (_name_66771 == _33921)
    _33922 = 1;
    else if (IS_ATOM_INT(_name_66771) && IS_ATOM_INT(_33921))
    _33922 = 0;
    else
    _33922 = (compare(_name_66771, _33921) == 0);
    _33921 = NOVALUE;
    DeRef(_33919);
    _33919 = (_33922 != 0);
L3B: 
    if (_33919 == 0) {
        DeRef(_33923);
        _33923 = 0;
        goto L3C; // [1523] 1559
    }
    _2 = (int)SEQ_PTR(_27include_matrix_10928);
    _33924 = (int)*(((s1_ptr)_2)->base + _file_66772);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _33925 = (int)*(((s1_ptr)_2)->base + _s_66777);
    _2 = (int)SEQ_PTR(_33925);
    if (!IS_ATOM_INT(_26S_FILE_NO_11650)){
        _33926 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_FILE_NO_11650)->dbl));
    }
    else{
        _33926 = (int)*(((s1_ptr)_2)->base + _26S_FILE_NO_11650);
    }
    _33925 = NOVALUE;
    _2 = (int)SEQ_PTR(_33924);
    if (!IS_ATOM_INT(_33926)){
        _33927 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_33926)->dbl));
    }
    else{
        _33927 = (int)*(((s1_ptr)_2)->base + _33926);
    }
    _33924 = NOVALUE;
    if (IS_ATOM_INT(_33927)) {
        {unsigned long tu;
             tu = (unsigned long)2 & (unsigned long)_33927;
             _33928 = MAKE_UINT(tu);
        }
    }
    else {
        _33928 = binary_op(AND_BITS, 2, _33927);
    }
    _33927 = NOVALUE;
    if (IS_ATOM_INT(_33928))
    _33923 = (_33928 != 0);
    else
    _33923 = DBL_PTR(_33928)->dbl != 0.0;
L3C: 
    if (_33923 == 0)
    {
        _33923 = NOVALUE;
        goto L3D; // [1560] 1578
    }
    else{
        _33923 = NOVALUE;
    }
L3A: 

    /** 				global_found = s*/
    _global_found_66778 = _s_66777;

    /** 				found_in_path += 1*/
    _found_in_path_66782 = _found_in_path_66782 + 1;
L3D: 
L36: 

    /** 			s = SymTab[s][S_NEXT]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _33930 = (int)*(((s1_ptr)_2)->base + _s_66777);
    _2 = (int)SEQ_PTR(_33930);
    _s_66777 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_66777)){
        _s_66777 = (long)DBL_PTR(_s_66777)->dbl;
    }
    _33930 = NOVALUE;

    /** 		end while*/
    goto L31; // [1597] 1253
L32: 

    /** 		if found_in_path != 1 and (( found_in_path + found_outside_path ) != 1 ) then*/
    _33932 = (_found_in_path_66782 != 1);
    if (_33932 == 0) {
        goto L3E; // [1606] 1629
    }
    _33934 = _found_in_path_66782 + _found_outside_path_66783;
    if ((long)((unsigned long)_33934 + (unsigned long)HIGH_BITS) >= 0) 
    _33934 = NewDouble((double)_33934);
    if (IS_ATOM_INT(_33934)) {
        _33935 = (_33934 != 1);
    }
    else {
        _33935 = (DBL_PTR(_33934)->dbl != (double)1);
    }
    DeRef(_33934);
    _33934 = NOVALUE;
    if (_33935 == 0)
    {
        DeRef(_33935);
        _33935 = NOVALUE;
        goto L3E; // [1619] 1629
    }
    else{
        DeRef(_33935);
        _33935 = NOVALUE;
    }

    /** 			return 0*/
    DeRefDS(_name_66771);
    DeRef(_ns_66779);
    DeRef(_33730);
    _33730 = NOVALUE;
    DeRef(_33745);
    _33745 = NOVALUE;
    _33813 = NOVALUE;
    DeRef(_33817);
    _33817 = NOVALUE;
    DeRef(_33852);
    _33852 = NOVALUE;
    DeRef(_33932);
    _33932 = NOVALUE;
    _33898 = NOVALUE;
    DeRef(_33834);
    _33834 = NOVALUE;
    DeRef(_33764);
    _33764 = NOVALUE;
    DeRef(_33808);
    _33808 = NOVALUE;
    DeRef(_33855);
    _33855 = NOVALUE;
    DeRef(_33749);
    _33749 = NOVALUE;
    DeRef(_33792);
    _33792 = NOVALUE;
    _33913 = NOVALUE;
    DeRef(_33915);
    _33915 = NOVALUE;
    DeRef(_33725);
    _33725 = NOVALUE;
    DeRef(_33867);
    _33867 = NOVALUE;
    DeRef(_33882);
    _33882 = NOVALUE;
    DeRef(_33782);
    _33782 = NOVALUE;
    DeRef(_33712);
    _33712 = NOVALUE;
    DeRef(_33771);
    _33771 = NOVALUE;
    DeRef(_33769);
    _33769 = NOVALUE;
    DeRef(_33733);
    _33733 = NOVALUE;
    DeRef(_33848);
    _33848 = NOVALUE;
    DeRef(_33838);
    _33838 = NOVALUE;
    DeRef(_33798);
    _33798 = NOVALUE;
    DeRef(_33918);
    _33918 = NOVALUE;
    DeRef(_33719);
    _33719 = NOVALUE;
    DeRef(_33884);
    _33884 = NOVALUE;
    DeRef(_33710);
    _33710 = NOVALUE;
    DeRef(_33788);
    _33788 = NOVALUE;
    DeRef(_33905);
    _33905 = NOVALUE;
    DeRef(_33819);
    _33819 = NOVALUE;
    DeRef(_33846);
    _33846 = NOVALUE;
    DeRef(_33928);
    _33928 = NOVALUE;
    DeRef(_33821);
    _33821 = NOVALUE;
    DeRef(_33723);
    _33723 = NOVALUE;
    _33786 = NOVALUE;
    DeRef(_33888);
    _33888 = NOVALUE;
    DeRef(_33737);
    _33737 = NOVALUE;
    DeRef(_33778);
    _33778 = NOVALUE;
    DeRef(_33863);
    _33863 = NOVALUE;
    DeRef(_33891);
    _33891 = NOVALUE;
    _33926 = NOVALUE;
    DeRef(_33761);
    _33761 = NOVALUE;
    DeRef(_33802);
    _33802 = NOVALUE;
    _33812 = NOVALUE;
    DeRef(_33869);
    _33869 = NOVALUE;
    DeRef(_33804);
    _33804 = NOVALUE;
    DeRef(_33859);
    _33859 = NOVALUE;
    DeRef(_33873);
    _33873 = NOVALUE;
    DeRef(_33775);
    _33775 = NOVALUE;
    DeRef(_33794);
    _33794 = NOVALUE;
    return 0;
L3E: 

    /** 		return global_found*/
    DeRefDS(_name_66771);
    DeRef(_ns_66779);
    DeRef(_33730);
    _33730 = NOVALUE;
    DeRef(_33745);
    _33745 = NOVALUE;
    _33813 = NOVALUE;
    DeRef(_33817);
    _33817 = NOVALUE;
    DeRef(_33852);
    _33852 = NOVALUE;
    DeRef(_33932);
    _33932 = NOVALUE;
    _33898 = NOVALUE;
    DeRef(_33834);
    _33834 = NOVALUE;
    DeRef(_33764);
    _33764 = NOVALUE;
    DeRef(_33808);
    _33808 = NOVALUE;
    DeRef(_33855);
    _33855 = NOVALUE;
    DeRef(_33749);
    _33749 = NOVALUE;
    DeRef(_33792);
    _33792 = NOVALUE;
    _33913 = NOVALUE;
    DeRef(_33915);
    _33915 = NOVALUE;
    DeRef(_33725);
    _33725 = NOVALUE;
    DeRef(_33867);
    _33867 = NOVALUE;
    DeRef(_33882);
    _33882 = NOVALUE;
    DeRef(_33782);
    _33782 = NOVALUE;
    DeRef(_33712);
    _33712 = NOVALUE;
    DeRef(_33771);
    _33771 = NOVALUE;
    DeRef(_33769);
    _33769 = NOVALUE;
    DeRef(_33733);
    _33733 = NOVALUE;
    DeRef(_33848);
    _33848 = NOVALUE;
    DeRef(_33838);
    _33838 = NOVALUE;
    DeRef(_33798);
    _33798 = NOVALUE;
    DeRef(_33918);
    _33918 = NOVALUE;
    DeRef(_33719);
    _33719 = NOVALUE;
    DeRef(_33884);
    _33884 = NOVALUE;
    DeRef(_33710);
    _33710 = NOVALUE;
    DeRef(_33788);
    _33788 = NOVALUE;
    DeRef(_33905);
    _33905 = NOVALUE;
    DeRef(_33819);
    _33819 = NOVALUE;
    DeRef(_33846);
    _33846 = NOVALUE;
    DeRef(_33928);
    _33928 = NOVALUE;
    DeRef(_33821);
    _33821 = NOVALUE;
    DeRef(_33723);
    _33723 = NOVALUE;
    _33786 = NOVALUE;
    DeRef(_33888);
    _33888 = NOVALUE;
    DeRef(_33737);
    _33737 = NOVALUE;
    DeRef(_33778);
    _33778 = NOVALUE;
    DeRef(_33863);
    _33863 = NOVALUE;
    DeRef(_33891);
    _33891 = NOVALUE;
    _33926 = NOVALUE;
    DeRef(_33761);
    _33761 = NOVALUE;
    DeRef(_33802);
    _33802 = NOVALUE;
    _33812 = NOVALUE;
    DeRef(_33869);
    _33869 = NOVALUE;
    DeRef(_33804);
    _33804 = NOVALUE;
    DeRef(_33859);
    _33859 = NOVALUE;
    DeRef(_33873);
    _33873 = NOVALUE;
    DeRef(_33775);
    _33775 = NOVALUE;
    DeRef(_33794);
    _33794 = NOVALUE;
    return _global_found_66778;
L22: 
    ;
}


void _67do_call_proc(int _sub_67159, int _args_67160, int _advance_67161)
{
    int _n_67162 = NOVALUE;
    int _arg_67163 = NOVALUE;
    int _private_block_67178 = NOVALUE;
    int _p_67184 = NOVALUE;
    int _33977 = NOVALUE;
    int _33972 = NOVALUE;
    int _33970 = NOVALUE;
    int _33969 = NOVALUE;
    int _33968 = NOVALUE;
    int _33966 = NOVALUE;
    int _33964 = NOVALUE;
    int _33961 = NOVALUE;
    int _33959 = NOVALUE;
    int _33957 = NOVALUE;
    int _33956 = NOVALUE;
    int _33955 = NOVALUE;
    int _33954 = NOVALUE;
    int _33953 = NOVALUE;
    int _33952 = NOVALUE;
    int _33950 = NOVALUE;
    int _33949 = NOVALUE;
    int _33947 = NOVALUE;
    int _33946 = NOVALUE;
    int _33944 = NOVALUE;
    int _33943 = NOVALUE;
    int _33941 = NOVALUE;
    int _33940 = NOVALUE;
    int _33938 = NOVALUE;
    int _33936 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_advance_67161)) {
        _1 = (long)(DBL_PTR(_advance_67161)->dbl);
        DeRefDS(_advance_67161);
        _advance_67161 = _1;
    }

    /** 	n = SymTab[sub][S_NUM_ARGS]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _33936 = (int)*(((s1_ptr)_2)->base + _sub_67159);
    _2 = (int)SEQ_PTR(_33936);
    if (!IS_ATOM_INT(_26S_NUM_ARGS_11705)){
        _n_67162 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NUM_ARGS_11705)->dbl));
    }
    else{
        _n_67162 = (int)*(((s1_ptr)_2)->base + _26S_NUM_ARGS_11705);
    }
    if (!IS_ATOM_INT(_n_67162)){
        _n_67162 = (long)DBL_PTR(_n_67162)->dbl;
    }
    _33936 = NOVALUE;

    /** 	arg = SymTab[sub][S_NEXT]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _33938 = (int)*(((s1_ptr)_2)->base + _sub_67159);
    _2 = (int)SEQ_PTR(_33938);
    _arg_67163 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_arg_67163)){
        _arg_67163 = (long)DBL_PTR(_arg_67163)->dbl;
    }
    _33938 = NOVALUE;

    /** 	if SymTab[sub][S_RESIDENT_TASK] != 0 then*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _33940 = (int)*(((s1_ptr)_2)->base + _sub_67159);
    _2 = (int)SEQ_PTR(_33940);
    _33941 = (int)*(((s1_ptr)_2)->base + 25);
    _33940 = NOVALUE;
    if (binary_op_a(EQUALS, _33941, 0)){
        _33941 = NOVALUE;
        goto L1; // [53] 314
    }
    _33941 = NOVALUE;

    /** 		sequence private_block = repeat(0, SymTab[sub][S_STACK_SPACE])*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _33943 = (int)*(((s1_ptr)_2)->base + _sub_67159);
    _2 = (int)SEQ_PTR(_33943);
    if (!IS_ATOM_INT(_26S_STACK_SPACE_11714)){
        _33944 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_STACK_SPACE_11714)->dbl));
    }
    else{
        _33944 = (int)*(((s1_ptr)_2)->base + _26S_STACK_SPACE_11714);
    }
    _33943 = NOVALUE;
    DeRef(_private_block_67178);
    _private_block_67178 = Repeat(0, _33944);
    _33944 = NOVALUE;

    /** 		integer p = 1*/
    _p_67184 = 1;

    /** 		for i = 1 to n do*/
    _33946 = _n_67162;
    {
        int _i_67186;
        _i_67186 = 1;
L2: 
        if (_i_67186 > _33946){
            goto L3; // [85] 145
        }

        /** 			private_block[p] = val[arg]*/
        _2 = (int)SEQ_PTR(_67val_63489);
        _33947 = (int)*(((s1_ptr)_2)->base + _arg_67163);
        Ref(_33947);
        _2 = (int)SEQ_PTR(_private_block_67178);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _private_block_67178 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _p_67184);
        _1 = *(int *)_2;
        *(int *)_2 = _33947;
        if( _1 != _33947 ){
            DeRef(_1);
        }
        _33947 = NOVALUE;

        /** 			p += 1*/
        _p_67184 = _p_67184 + 1;

        /** 			val[arg] = args[i]*/
        _2 = (int)SEQ_PTR(_args_67160);
        _33949 = (int)*(((s1_ptr)_2)->base + _i_67186);
        Ref(_33949);
        _2 = (int)SEQ_PTR(_67val_63489);
        _2 = (int)(((s1_ptr)_2)->base + _arg_67163);
        _1 = *(int *)_2;
        *(int *)_2 = _33949;
        if( _1 != _33949 ){
            DeRef(_1);
        }
        _33949 = NOVALUE;

        /** 			arg = SymTab[arg][S_NEXT]*/
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _33950 = (int)*(((s1_ptr)_2)->base + _arg_67163);
        _2 = (int)SEQ_PTR(_33950);
        _arg_67163 = (int)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_arg_67163)){
            _arg_67163 = (long)DBL_PTR(_arg_67163)->dbl;
        }
        _33950 = NOVALUE;

        /** 		end for*/
        _i_67186 = _i_67186 + 1;
        goto L2; // [140] 92
L3: 
        ;
    }

    /** 		while arg != 0 and SymTab[arg][S_SCOPE] <= SC_PRIVATE do*/
L4: 
    _33952 = (_arg_67163 != 0);
    if (_33952 == 0) {
        goto L5; // [154] 229
    }
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _33954 = (int)*(((s1_ptr)_2)->base + _arg_67163);
    _2 = (int)SEQ_PTR(_33954);
    _33955 = (int)*(((s1_ptr)_2)->base + 4);
    _33954 = NOVALUE;
    if (IS_ATOM_INT(_33955)) {
        _33956 = (_33955 <= 3);
    }
    else {
        _33956 = binary_op(LESSEQ, _33955, 3);
    }
    _33955 = NOVALUE;
    if (_33956 <= 0) {
        if (_33956 == 0) {
            DeRef(_33956);
            _33956 = NOVALUE;
            goto L5; // [177] 229
        }
        else {
            if (!IS_ATOM_INT(_33956) && DBL_PTR(_33956)->dbl == 0.0){
                DeRef(_33956);
                _33956 = NOVALUE;
                goto L5; // [177] 229
            }
            DeRef(_33956);
            _33956 = NOVALUE;
        }
    }
    DeRef(_33956);
    _33956 = NOVALUE;

    /** 			private_block[p] = val[arg]*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _33957 = (int)*(((s1_ptr)_2)->base + _arg_67163);
    Ref(_33957);
    _2 = (int)SEQ_PTR(_private_block_67178);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _private_block_67178 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _p_67184);
    _1 = *(int *)_2;
    *(int *)_2 = _33957;
    if( _1 != _33957 ){
        DeRef(_1);
    }
    _33957 = NOVALUE;

    /** 			p += 1*/
    _p_67184 = _p_67184 + 1;

    /** 			val[arg] = NOVALUE -- necessary?*/
    Ref(_26NOVALUE_11836);
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _arg_67163);
    _1 = *(int *)_2;
    *(int *)_2 = _26NOVALUE_11836;
    DeRef(_1);

    /** 			arg = SymTab[arg][S_NEXT]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _33959 = (int)*(((s1_ptr)_2)->base + _arg_67163);
    _2 = (int)SEQ_PTR(_33959);
    _arg_67163 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_arg_67163)){
        _arg_67163 = (long)DBL_PTR(_arg_67163)->dbl;
    }
    _33959 = NOVALUE;

    /** 		end while*/
    goto L4; // [226] 150
L5: 

    /** 		arg = SymTab[sub][S_TEMPS]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _33961 = (int)*(((s1_ptr)_2)->base + _sub_67159);
    _2 = (int)SEQ_PTR(_33961);
    if (!IS_ATOM_INT(_26S_TEMPS_11699)){
        _arg_67163 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_TEMPS_11699)->dbl));
    }
    else{
        _arg_67163 = (int)*(((s1_ptr)_2)->base + _26S_TEMPS_11699);
    }
    if (!IS_ATOM_INT(_arg_67163)){
        _arg_67163 = (long)DBL_PTR(_arg_67163)->dbl;
    }
    _33961 = NOVALUE;

    /** 		while arg != 0 do*/
L6: 
    if (_arg_67163 == 0)
    goto L7; // [250] 303

    /** 			private_block[p] = val[arg]*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _33964 = (int)*(((s1_ptr)_2)->base + _arg_67163);
    Ref(_33964);
    _2 = (int)SEQ_PTR(_private_block_67178);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _private_block_67178 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _p_67184);
    _1 = *(int *)_2;
    *(int *)_2 = _33964;
    if( _1 != _33964 ){
        DeRef(_1);
    }
    _33964 = NOVALUE;

    /** 			p += 1*/
    _p_67184 = _p_67184 + 1;

    /** 			val[arg] = NOVALUE -- necessary?*/
    Ref(_26NOVALUE_11836);
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _arg_67163);
    _1 = *(int *)_2;
    *(int *)_2 = _26NOVALUE_11836;
    DeRef(_1);

    /** 			arg = SymTab[arg][S_NEXT]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _33966 = (int)*(((s1_ptr)_2)->base + _arg_67163);
    _2 = (int)SEQ_PTR(_33966);
    _arg_67163 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_arg_67163)){
        _arg_67163 = (long)DBL_PTR(_arg_67163)->dbl;
    }
    _33966 = NOVALUE;

    /** 		end while*/
    goto L6; // [300] 250
L7: 

    /** 		save_private_block(sub, private_block)*/
    RefDS(_private_block_67178);
    _67save_private_block(_sub_67159, _private_block_67178);
    DeRefDS(_private_block_67178);
    _private_block_67178 = NOVALUE;
    goto L8; // [311] 362
L1: 

    /** 		for i = 1 to n do*/
    _33968 = _n_67162;
    {
        int _i_67226;
        _i_67226 = 1;
L9: 
        if (_i_67226 > _33968){
            goto LA; // [319] 361
        }

        /** 			val[arg] = args[i]*/
        _2 = (int)SEQ_PTR(_args_67160);
        _33969 = (int)*(((s1_ptr)_2)->base + _i_67226);
        Ref(_33969);
        _2 = (int)SEQ_PTR(_67val_63489);
        _2 = (int)(((s1_ptr)_2)->base + _arg_67163);
        _1 = *(int *)_2;
        *(int *)_2 = _33969;
        if( _1 != _33969 ){
            DeRef(_1);
        }
        _33969 = NOVALUE;

        /** 			arg = SymTab[arg][S_NEXT]*/
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _33970 = (int)*(((s1_ptr)_2)->base + _arg_67163);
        _2 = (int)SEQ_PTR(_33970);
        _arg_67163 = (int)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_arg_67163)){
            _arg_67163 = (long)DBL_PTR(_arg_67163)->dbl;
        }
        _33970 = NOVALUE;

        /** 		end for*/
        _i_67226 = _i_67226 + 1;
        goto L9; // [356] 326
LA: 
        ;
    }
L8: 

    /** 	SymTab[sub][S_RESIDENT_TASK] = current_task*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sub_67159 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 25);
    _1 = *(int *)_2;
    *(int *)_2 = _67current_task_63496;
    DeRef(_1);
    _33972 = NOVALUE;

    /** 	pc += advance*/
    _67pc_63479 = _67pc_63479 + _advance_67161;

    /** 	call_stack = append(call_stack, pc)*/
    Append(&_67call_stack_63497, _67call_stack_63497, _67pc_63479);

    /** 	call_stack = append(call_stack, sub)*/
    Append(&_67call_stack_63497, _67call_stack_63497, _sub_67159);

    /** 	Code = SymTab[sub][S_CODE]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _33977 = (int)*(((s1_ptr)_2)->base + _sub_67159);
    DeRef(_26Code_12071);
    _2 = (int)SEQ_PTR(_33977);
    if (!IS_ATOM_INT(_26S_CODE_11666)){
        _26Code_12071 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_CODE_11666)->dbl));
    }
    else{
        _26Code_12071 = (int)*(((s1_ptr)_2)->base + _26S_CODE_11666);
    }
    Ref(_26Code_12071);
    _33977 = NOVALUE;

    /** 	pc = 1*/
    _67pc_63479 = 1;

    /** end procedure*/
    DeRefDS(_args_67160);
    DeRef(_33952);
    _33952 = NOVALUE;
    return;
    ;
}


void _67opCALL_PROC()
{
    int _cf_67247 = NOVALUE;
    int _sub_67249 = NOVALUE;
    int _34026 = NOVALUE;
    int _34025 = NOVALUE;
    int _34024 = NOVALUE;
    int _34023 = NOVALUE;
    int _34022 = NOVALUE;
    int _34021 = NOVALUE;
    int _34020 = NOVALUE;
    int _34019 = NOVALUE;
    int _34018 = NOVALUE;
    int _34017 = NOVALUE;
    int _34014 = NOVALUE;
    int _34013 = NOVALUE;
    int _34012 = NOVALUE;
    int _34011 = NOVALUE;
    int _34009 = NOVALUE;
    int _34008 = NOVALUE;
    int _34007 = NOVALUE;
    int _34006 = NOVALUE;
    int _34005 = NOVALUE;
    int _34002 = NOVALUE;
    int _34001 = NOVALUE;
    int _34000 = NOVALUE;
    int _33999 = NOVALUE;
    int _33998 = NOVALUE;
    int _33995 = NOVALUE;
    int _33994 = NOVALUE;
    int _33992 = NOVALUE;
    int _33990 = NOVALUE;
    int _33989 = NOVALUE;
    int _33988 = NOVALUE;
    int _33987 = NOVALUE;
    int _33986 = NOVALUE;
    int _33984 = NOVALUE;
    int _33983 = NOVALUE;
    int _33981 = NOVALUE;
    int _33979 = NOVALUE;
    int _0, _1, _2;
    

    /** 	cf = Code[pc] = CALL_FUNC*/
    _2 = (int)SEQ_PTR(_26Code_12071);
    _33979 = (int)*(((s1_ptr)_2)->base + _67pc_63479);
    if (IS_ATOM_INT(_33979)) {
        _cf_67247 = (_33979 == 137);
    }
    else {
        _cf_67247 = binary_op(EQUALS, _33979, 137);
    }
    _33979 = NOVALUE;
    if (!IS_ATOM_INT(_cf_67247)) {
        _1 = (long)(DBL_PTR(_cf_67247)->dbl);
        DeRefDS(_cf_67247);
        _cf_67247 = _1;
    }

    /** 	a = Code[pc+1]  -- routine id*/
    _33981 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _33981);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	if val[a] < 0 or val[a] >= length(e_routine) then*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _33983 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    if (IS_ATOM_INT(_33983)) {
        _33984 = (_33983 < 0);
    }
    else {
        _33984 = binary_op(LESS, _33983, 0);
    }
    _33983 = NOVALUE;
    if (IS_ATOM_INT(_33984)) {
        if (_33984 != 0) {
            goto L1; // [49] 75
        }
    }
    else {
        if (DBL_PTR(_33984)->dbl != 0.0) {
            goto L1; // [49] 75
        }
    }
    _2 = (int)SEQ_PTR(_67val_63489);
    _33986 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    if (IS_SEQUENCE(_67e_routine_63527)){
            _33987 = SEQ_PTR(_67e_routine_63527)->length;
    }
    else {
        _33987 = 1;
    }
    if (IS_ATOM_INT(_33986)) {
        _33988 = (_33986 >= _33987);
    }
    else {
        _33988 = binary_op(GREATEREQ, _33986, _33987);
    }
    _33986 = NOVALUE;
    _33987 = NOVALUE;
    if (_33988 == 0) {
        DeRef(_33988);
        _33988 = NOVALUE;
        goto L2; // [71] 81
    }
    else {
        if (!IS_ATOM_INT(_33988) && DBL_PTR(_33988)->dbl == 0.0){
            DeRef(_33988);
            _33988 = NOVALUE;
            goto L2; // [71] 81
        }
        DeRef(_33988);
        _33988 = NOVALUE;
    }
    DeRef(_33988);
    _33988 = NOVALUE;
L1: 

    /** 		RTFatal("invalid routine id")*/
    RefDS(_32354);
    _67RTFatal(_32354);
L2: 

    /** 	sub = e_routine[val[a]+1]*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _33989 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    if (IS_ATOM_INT(_33989)) {
        _33990 = _33989 + 1;
    }
    else
    _33990 = binary_op(PLUS, 1, _33989);
    _33989 = NOVALUE;
    _2 = (int)SEQ_PTR(_67e_routine_63527);
    if (!IS_ATOM_INT(_33990)){
        _sub_67249 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_33990)->dbl));
    }
    else{
        _sub_67249 = (int)*(((s1_ptr)_2)->base + _33990);
    }

    /** 	b = Code[pc+2]  -- argument list*/
    _33992 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67b_63481 = (int)*(((s1_ptr)_2)->base + _33992);
    if (!IS_ATOM_INT(_67b_63481)){
        _67b_63481 = (long)DBL_PTR(_67b_63481)->dbl;
    }

    /** 	if cf then*/
    if (_cf_67247 == 0)
    {
        goto L3; // [121] 169
    }
    else{
    }

    /** 		if SymTab[sub][S_TOKEN] = PROC then*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _33994 = (int)*(((s1_ptr)_2)->base + _sub_67249);
    _2 = (int)SEQ_PTR(_33994);
    if (!IS_ATOM_INT(_26S_TOKEN_11659)){
        _33995 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_TOKEN_11659)->dbl));
    }
    else{
        _33995 = (int)*(((s1_ptr)_2)->base + _26S_TOKEN_11659);
    }
    _33994 = NOVALUE;
    if (binary_op_a(NOTEQ, _33995, 27)){
        _33995 = NOVALUE;
        goto L4; // [140] 212
    }
    _33995 = NOVALUE;

    /** 			RTFatal(sprintf("%s() does not return a value", SymTab[sub][S_NAME]))*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _33998 = (int)*(((s1_ptr)_2)->base + _sub_67249);
    _2 = (int)SEQ_PTR(_33998);
    if (!IS_ATOM_INT(_26S_NAME_11654)){
        _33999 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NAME_11654)->dbl));
    }
    else{
        _33999 = (int)*(((s1_ptr)_2)->base + _26S_NAME_11654);
    }
    _33998 = NOVALUE;
    _34000 = EPrintf(-9999999, _33997, _33999);
    _33999 = NOVALUE;
    _67RTFatal(_34000);
    _34000 = NOVALUE;
    goto L4; // [166] 212
L3: 

    /** 		if SymTab[sub][S_TOKEN] != PROC then*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _34001 = (int)*(((s1_ptr)_2)->base + _sub_67249);
    _2 = (int)SEQ_PTR(_34001);
    if (!IS_ATOM_INT(_26S_TOKEN_11659)){
        _34002 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_TOKEN_11659)->dbl));
    }
    else{
        _34002 = (int)*(((s1_ptr)_2)->base + _26S_TOKEN_11659);
    }
    _34001 = NOVALUE;
    if (binary_op_a(EQUALS, _34002, 27)){
        _34002 = NOVALUE;
        goto L5; // [185] 211
    }
    _34002 = NOVALUE;

    /** 			RTFatal(sprintf("the value returned by %s() must be assigned or used",*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _34005 = (int)*(((s1_ptr)_2)->base + _sub_67249);
    _2 = (int)SEQ_PTR(_34005);
    if (!IS_ATOM_INT(_26S_NAME_11654)){
        _34006 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NAME_11654)->dbl));
    }
    else{
        _34006 = (int)*(((s1_ptr)_2)->base + _26S_NAME_11654);
    }
    _34005 = NOVALUE;
    _34007 = EPrintf(-9999999, _34004, _34006);
    _34006 = NOVALUE;
    _67RTFatal(_34007);
    _34007 = NOVALUE;
L5: 
L4: 

    /** 	if atom(val[b]) then*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _34008 = (int)*(((s1_ptr)_2)->base + _67b_63481);
    _34009 = IS_ATOM(_34008);
    _34008 = NOVALUE;
    if (_34009 == 0)
    {
        _34009 = NOVALUE;
        goto L6; // [225] 234
    }
    else{
        _34009 = NOVALUE;
    }

    /** 		RTFatal("argument list must be a sequence")*/
    RefDS(_34010);
    _67RTFatal(_34010);
L6: 

    /** 	if SymTab[sub][S_NUM_ARGS] != length(val[b]) then*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _34011 = (int)*(((s1_ptr)_2)->base + _sub_67249);
    _2 = (int)SEQ_PTR(_34011);
    if (!IS_ATOM_INT(_26S_NUM_ARGS_11705)){
        _34012 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NUM_ARGS_11705)->dbl));
    }
    else{
        _34012 = (int)*(((s1_ptr)_2)->base + _26S_NUM_ARGS_11705);
    }
    _34011 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63489);
    _34013 = (int)*(((s1_ptr)_2)->base + _67b_63481);
    if (IS_SEQUENCE(_34013)){
            _34014 = SEQ_PTR(_34013)->length;
    }
    else {
        _34014 = 1;
    }
    _34013 = NOVALUE;
    if (binary_op_a(EQUALS, _34012, _34014)){
        _34012 = NOVALUE;
        _34014 = NOVALUE;
        goto L7; // [259] 314
    }
    _34012 = NOVALUE;
    _34014 = NOVALUE;

    /** 		RTFatal(sprintf("call to %s() via routine-id should pass %d arguments, not %d",*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _34017 = (int)*(((s1_ptr)_2)->base + _sub_67249);
    _2 = (int)SEQ_PTR(_34017);
    if (!IS_ATOM_INT(_26S_NAME_11654)){
        _34018 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NAME_11654)->dbl));
    }
    else{
        _34018 = (int)*(((s1_ptr)_2)->base + _26S_NAME_11654);
    }
    _34017 = NOVALUE;
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _34019 = (int)*(((s1_ptr)_2)->base + _sub_67249);
    _2 = (int)SEQ_PTR(_34019);
    if (!IS_ATOM_INT(_26S_NUM_ARGS_11705)){
        _34020 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NUM_ARGS_11705)->dbl));
    }
    else{
        _34020 = (int)*(((s1_ptr)_2)->base + _26S_NUM_ARGS_11705);
    }
    _34019 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63489);
    _34021 = (int)*(((s1_ptr)_2)->base + _67b_63481);
    if (IS_SEQUENCE(_34021)){
            _34022 = SEQ_PTR(_34021)->length;
    }
    else {
        _34022 = 1;
    }
    _34021 = NOVALUE;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_34018);
    *((int *)(_2+4)) = _34018;
    Ref(_34020);
    *((int *)(_2+8)) = _34020;
    *((int *)(_2+12)) = _34022;
    _34023 = MAKE_SEQ(_1);
    _34022 = NOVALUE;
    _34020 = NOVALUE;
    _34018 = NOVALUE;
    _34024 = EPrintf(-9999999, _34016, _34023);
    DeRefDS(_34023);
    _34023 = NOVALUE;
    _67RTFatal(_34024);
    _34024 = NOVALUE;
L7: 

    /** 	do_call_proc( sub, val[b], 3 + cf )*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _34025 = (int)*(((s1_ptr)_2)->base + _67b_63481);
    _34026 = 3 + _cf_67247;
    if ((long)((unsigned long)_34026 + (unsigned long)HIGH_BITS) >= 0) 
    _34026 = NewDouble((double)_34026);
    Ref(_34025);
    _67do_call_proc(_sub_67249, _34025, _34026);
    _34025 = NOVALUE;
    _34026 = NOVALUE;

    /** end procedure*/
    DeRef(_33981);
    _33981 = NOVALUE;
    DeRef(_33992);
    _33992 = NOVALUE;
    DeRef(_33984);
    _33984 = NOVALUE;
    DeRef(_33990);
    _33990 = NOVALUE;
    _34013 = NOVALUE;
    _34021 = NOVALUE;
    return;
    ;
}


void _67opROUTINE_ID()
{
    int _sub_67327 = NOVALUE;
    int _fn_67328 = NOVALUE;
    int _p_67329 = NOVALUE;
    int _stlen_67330 = NOVALUE;
    int _name_67331 = NOVALUE;
    int _34053 = NOVALUE;
    int _34052 = NOVALUE;
    int _34050 = NOVALUE;
    int _34048 = NOVALUE;
    int _34047 = NOVALUE;
    int _34046 = NOVALUE;
    int _34045 = NOVALUE;
    int _34044 = NOVALUE;
    int _34043 = NOVALUE;
    int _34041 = NOVALUE;
    int _34039 = NOVALUE;
    int _34036 = NOVALUE;
    int _34034 = NOVALUE;
    int _34032 = NOVALUE;
    int _34031 = NOVALUE;
    int _34029 = NOVALUE;
    int _34027 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sub = Code[pc+1]   -- CurrentSub*/
    _34027 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _sub_67327 = (int)*(((s1_ptr)_2)->base + _34027);
    if (!IS_ATOM_INT(_sub_67327)){
        _sub_67327 = (long)DBL_PTR(_sub_67327)->dbl;
    }

    /** 	stlen = Code[pc+2]  -- s.t. length*/
    _34029 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _stlen_67330 = (int)*(((s1_ptr)_2)->base + _34029);
    if (!IS_ATOM_INT(_stlen_67330)){
        _stlen_67330 = (long)DBL_PTR(_stlen_67330)->dbl;
    }

    /** 	name = val[Code[pc+3]]  -- routine name sequence*/
    _34031 = _67pc_63479 + 3;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _34032 = (int)*(((s1_ptr)_2)->base + _34031);
    DeRef(_name_67331);
    _2 = (int)SEQ_PTR(_67val_63489);
    if (!IS_ATOM_INT(_34032)){
        _name_67331 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_34032)->dbl));
    }
    else{
        _name_67331 = (int)*(((s1_ptr)_2)->base + _34032);
    }
    Ref(_name_67331);

    /** 	fn = Code[pc+4]    -- file number*/
    _34034 = _67pc_63479 + 4;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _fn_67328 = (int)*(((s1_ptr)_2)->base + _34034);
    if (!IS_ATOM_INT(_fn_67328)){
        _fn_67328 = (long)DBL_PTR(_fn_67328)->dbl;
    }

    /** 	target = Code[pc+5]*/
    _34036 = _67pc_63479 + 5;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67target_63484 = (int)*(((s1_ptr)_2)->base + _34036);
    if (!IS_ATOM_INT(_67target_63484)){
        _67target_63484 = (long)DBL_PTR(_67target_63484)->dbl;
    }

    /** 	pc += 6*/
    _67pc_63479 = _67pc_63479 + 6;

    /** 	if atom(name) then*/
    _34039 = IS_ATOM(_name_67331);
    if (_34039 == 0)
    {
        _34039 = NOVALUE;
        goto L1; // [98] 117
    }
    else{
        _34039 = NOVALUE;
    }

    /** 		val[target] = -1*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63484);
    _1 = *(int *)_2;
    *(int *)_2 = -1;
    DeRef(_1);

    /** 		return*/
    DeRef(_name_67331);
    _34027 = NOVALUE;
    _34029 = NOVALUE;
    _34031 = NOVALUE;
    _34032 = NOVALUE;
    _34034 = NOVALUE;
    _34036 = NOVALUE;
    return;
L1: 

    /** 	p = RTLookup(name, fn, sub, stlen)*/
    Ref(_name_67331);
    _p_67329 = _67RTLookup(_name_67331, _fn_67328, _sub_67327, _stlen_67330);
    if (!IS_ATOM_INT(_p_67329)) {
        _1 = (long)(DBL_PTR(_p_67329)->dbl);
        DeRefDS(_p_67329);
        _p_67329 = _1;
    }

    /** 	if p = 0 or not find(SymTab[p][S_TOKEN], RTN_TOKS) then*/
    _34041 = (_p_67329 == 0);
    if (_34041 != 0) {
        goto L2; // [134] 165
    }
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _34043 = (int)*(((s1_ptr)_2)->base + _p_67329);
    _2 = (int)SEQ_PTR(_34043);
    if (!IS_ATOM_INT(_26S_TOKEN_11659)){
        _34044 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_TOKEN_11659)->dbl));
    }
    else{
        _34044 = (int)*(((s1_ptr)_2)->base + _26S_TOKEN_11659);
    }
    _34043 = NOVALUE;
    _34045 = find_from(_34044, _28RTN_TOKS_11602, 1);
    _34044 = NOVALUE;
    _34046 = (_34045 == 0);
    _34045 = NOVALUE;
    if (_34046 == 0)
    {
        DeRef(_34046);
        _34046 = NOVALUE;
        goto L3; // [161] 181
    }
    else{
        DeRef(_34046);
        _34046 = NOVALUE;
    }
L2: 

    /** 		val[target] = -1  -- name is not a routine*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63484);
    _1 = *(int *)_2;
    *(int *)_2 = -1;
    DeRef(_1);

    /** 		return*/
    DeRef(_name_67331);
    DeRef(_34027);
    _34027 = NOVALUE;
    DeRef(_34029);
    _34029 = NOVALUE;
    DeRef(_34031);
    _34031 = NOVALUE;
    _34032 = NOVALUE;
    DeRef(_34034);
    _34034 = NOVALUE;
    DeRef(_34036);
    _34036 = NOVALUE;
    DeRef(_34041);
    _34041 = NOVALUE;
    return;
L3: 

    /** 	for i = 1 to length(e_routine) do*/
    if (IS_SEQUENCE(_67e_routine_63527)){
            _34047 = SEQ_PTR(_67e_routine_63527)->length;
    }
    else {
        _34047 = 1;
    }
    {
        int _i_67363;
        _i_67363 = 1;
L4: 
        if (_i_67363 > _34047){
            goto L5; // [188] 234
        }

        /** 		if e_routine[i] = p then*/
        _2 = (int)SEQ_PTR(_67e_routine_63527);
        _34048 = (int)*(((s1_ptr)_2)->base + _i_67363);
        if (_34048 != _p_67329)
        goto L6; // [203] 227

        /** 			val[target] = i - 1  -- routine was already assigned an id*/
        _34050 = _i_67363 - 1;
        _2 = (int)SEQ_PTR(_67val_63489);
        _2 = (int)(((s1_ptr)_2)->base + _67target_63484);
        _1 = *(int *)_2;
        *(int *)_2 = _34050;
        if( _1 != _34050 ){
            DeRef(_1);
        }
        _34050 = NOVALUE;

        /** 			return*/
        DeRef(_name_67331);
        DeRef(_34027);
        _34027 = NOVALUE;
        DeRef(_34029);
        _34029 = NOVALUE;
        DeRef(_34031);
        _34031 = NOVALUE;
        _34032 = NOVALUE;
        DeRef(_34034);
        _34034 = NOVALUE;
        DeRef(_34036);
        _34036 = NOVALUE;
        DeRef(_34041);
        _34041 = NOVALUE;
        _34048 = NOVALUE;
        return;
L6: 

        /** 	end for*/
        _i_67363 = _i_67363 + 1;
        goto L4; // [229] 195
L5: 
        ;
    }

    /** 	e_routine = append(e_routine, p)*/
    Append(&_67e_routine_63527, _67e_routine_63527, _p_67329);

    /** 	val[target] = length(e_routine) - 1*/
    if (IS_SEQUENCE(_67e_routine_63527)){
            _34052 = SEQ_PTR(_67e_routine_63527)->length;
    }
    else {
        _34052 = 1;
    }
    _34053 = _34052 - 1;
    _34052 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63484);
    _1 = *(int *)_2;
    *(int *)_2 = _34053;
    if( _1 != _34053 ){
        DeRef(_1);
    }
    _34053 = NOVALUE;

    /** end procedure*/
    DeRef(_name_67331);
    DeRef(_34027);
    _34027 = NOVALUE;
    DeRef(_34029);
    _34029 = NOVALUE;
    DeRef(_34031);
    _34031 = NOVALUE;
    _34032 = NOVALUE;
    DeRef(_34034);
    _34034 = NOVALUE;
    DeRef(_34036);
    _34036 = NOVALUE;
    DeRef(_34041);
    _34041 = NOVALUE;
    _34048 = NOVALUE;
    return;
    ;
}


void _67opAPPEND()
{
    int _34062 = NOVALUE;
    int _34061 = NOVALUE;
    int _34060 = NOVALUE;
    int _34058 = NOVALUE;
    int _34056 = NOVALUE;
    int _34054 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _34054 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _34054);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _34056 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67b_63481 = (int)*(((s1_ptr)_2)->base + _34056);
    if (!IS_ATOM_INT(_67b_63481)){
        _67b_63481 = (long)DBL_PTR(_67b_63481)->dbl;
    }

    /** 	target = Code[pc+3]*/
    _34058 = _67pc_63479 + 3;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67target_63484 = (int)*(((s1_ptr)_2)->base + _34058);
    if (!IS_ATOM_INT(_67target_63484)){
        _67target_63484 = (long)DBL_PTR(_67target_63484)->dbl;
    }

    /** 	val[target] = append(val[a], val[b])*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _34060 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    _2 = (int)SEQ_PTR(_67val_63489);
    _34061 = (int)*(((s1_ptr)_2)->base + _67b_63481);
    Ref(_34061);
    Append(&_34062, _34060, _34061);
    _34060 = NOVALUE;
    _34061 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63484);
    _1 = *(int *)_2;
    *(int *)_2 = _34062;
    if( _1 != _34062 ){
        DeRef(_1);
    }
    _34062 = NOVALUE;

    /** 	pc += 4*/
    _67pc_63479 = _67pc_63479 + 4;

    /** end procedure*/
    _34054 = NOVALUE;
    _34056 = NOVALUE;
    _34058 = NOVALUE;
    return;
    ;
}


void _67opPREPEND()
{
    int _34072 = NOVALUE;
    int _34071 = NOVALUE;
    int _34070 = NOVALUE;
    int _34068 = NOVALUE;
    int _34066 = NOVALUE;
    int _34064 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _34064 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _34064);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _34066 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67b_63481 = (int)*(((s1_ptr)_2)->base + _34066);
    if (!IS_ATOM_INT(_67b_63481)){
        _67b_63481 = (long)DBL_PTR(_67b_63481)->dbl;
    }

    /** 	target = Code[pc+3]*/
    _34068 = _67pc_63479 + 3;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67target_63484 = (int)*(((s1_ptr)_2)->base + _34068);
    if (!IS_ATOM_INT(_67target_63484)){
        _67target_63484 = (long)DBL_PTR(_67target_63484)->dbl;
    }

    /** 	val[target] = prepend(val[a], val[b])*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _34070 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    _2 = (int)SEQ_PTR(_67val_63489);
    _34071 = (int)*(((s1_ptr)_2)->base + _67b_63481);
    Ref(_34071);
    Prepend(&_34072, _34070, _34071);
    _34070 = NOVALUE;
    _34071 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63484);
    _1 = *(int *)_2;
    *(int *)_2 = _34072;
    if( _1 != _34072 ){
        DeRef(_1);
    }
    _34072 = NOVALUE;

    /** 	pc += 4*/
    _67pc_63479 = _67pc_63479 + 4;

    /** end procedure*/
    _34064 = NOVALUE;
    _34066 = NOVALUE;
    _34068 = NOVALUE;
    return;
    ;
}


void _67opCONCAT()
{
    int _34082 = NOVALUE;
    int _34081 = NOVALUE;
    int _34080 = NOVALUE;
    int _34078 = NOVALUE;
    int _34076 = NOVALUE;
    int _34074 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _34074 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _34074);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _34076 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67b_63481 = (int)*(((s1_ptr)_2)->base + _34076);
    if (!IS_ATOM_INT(_67b_63481)){
        _67b_63481 = (long)DBL_PTR(_67b_63481)->dbl;
    }

    /** 	target = Code[pc+3]*/
    _34078 = _67pc_63479 + 3;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67target_63484 = (int)*(((s1_ptr)_2)->base + _34078);
    if (!IS_ATOM_INT(_67target_63484)){
        _67target_63484 = (long)DBL_PTR(_67target_63484)->dbl;
    }

    /** 	val[target] = val[a] & val[b]*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _34080 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    _2 = (int)SEQ_PTR(_67val_63489);
    _34081 = (int)*(((s1_ptr)_2)->base + _67b_63481);
    if (IS_SEQUENCE(_34080) && IS_ATOM(_34081)) {
        Ref(_34081);
        Append(&_34082, _34080, _34081);
    }
    else if (IS_ATOM(_34080) && IS_SEQUENCE(_34081)) {
        Ref(_34080);
        Prepend(&_34082, _34081, _34080);
    }
    else {
        Concat((object_ptr)&_34082, _34080, _34081);
        _34080 = NOVALUE;
    }
    _34080 = NOVALUE;
    _34081 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63484);
    _1 = *(int *)_2;
    *(int *)_2 = _34082;
    if( _1 != _34082 ){
        DeRef(_1);
    }
    _34082 = NOVALUE;

    /** 	pc += 4*/
    _67pc_63479 = _67pc_63479 + 4;

    /** end procedure*/
    _34074 = NOVALUE;
    _34076 = NOVALUE;
    _34078 = NOVALUE;
    return;
    ;
}


void _67opCONCAT_N()
{
    int _n_67419 = NOVALUE;
    int _x_67420 = NOVALUE;
    int _34098 = NOVALUE;
    int _34096 = NOVALUE;
    int _34095 = NOVALUE;
    int _34093 = NOVALUE;
    int _34092 = NOVALUE;
    int _34091 = NOVALUE;
    int _34090 = NOVALUE;
    int _34089 = NOVALUE;
    int _34087 = NOVALUE;
    int _34086 = NOVALUE;
    int _34084 = NOVALUE;
    int _0, _1, _2;
    

    /** 	n = Code[pc+1] -- number of items*/
    _34084 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _n_67419 = (int)*(((s1_ptr)_2)->base + _34084);
    if (!IS_ATOM_INT(_n_67419)){
        _n_67419 = (long)DBL_PTR(_n_67419)->dbl;
    }

    /** 	x = val[Code[pc+2]] -- last one*/
    _34086 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _34087 = (int)*(((s1_ptr)_2)->base + _34086);
    DeRef(_x_67420);
    _2 = (int)SEQ_PTR(_67val_63489);
    if (!IS_ATOM_INT(_34087)){
        _x_67420 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_34087)->dbl));
    }
    else{
        _x_67420 = (int)*(((s1_ptr)_2)->base + _34087);
    }
    Ref(_x_67420);

    /** 	for i = pc+3 to pc+n+1 do*/
    _34089 = _67pc_63479 + 3;
    if ((long)((unsigned long)_34089 + (unsigned long)HIGH_BITS) >= 0) 
    _34089 = NewDouble((double)_34089);
    _34090 = _67pc_63479 + _n_67419;
    if ((long)((unsigned long)_34090 + (unsigned long)HIGH_BITS) >= 0) 
    _34090 = NewDouble((double)_34090);
    if (IS_ATOM_INT(_34090)) {
        _34091 = _34090 + 1;
        if (_34091 > MAXINT){
            _34091 = NewDouble((double)_34091);
        }
    }
    else
    _34091 = binary_op(PLUS, 1, _34090);
    DeRef(_34090);
    _34090 = NOVALUE;
    {
        int _i_67429;
        Ref(_34089);
        _i_67429 = _34089;
L1: 
        if (binary_op_a(GREATER, _i_67429, _34091)){
            goto L2; // [55] 87
        }

        /** 		x = val[Code[i]] & x*/
        _2 = (int)SEQ_PTR(_26Code_12071);
        if (!IS_ATOM_INT(_i_67429)){
            _34092 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_67429)->dbl));
        }
        else{
            _34092 = (int)*(((s1_ptr)_2)->base + _i_67429);
        }
        _2 = (int)SEQ_PTR(_67val_63489);
        if (!IS_ATOM_INT(_34092)){
            _34093 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_34092)->dbl));
        }
        else{
            _34093 = (int)*(((s1_ptr)_2)->base + _34092);
        }
        if (IS_SEQUENCE(_34093) && IS_ATOM(_x_67420)) {
            Ref(_x_67420);
            Append(&_x_67420, _34093, _x_67420);
        }
        else if (IS_ATOM(_34093) && IS_SEQUENCE(_x_67420)) {
            Ref(_34093);
            Prepend(&_x_67420, _x_67420, _34093);
        }
        else {
            Concat((object_ptr)&_x_67420, _34093, _x_67420);
            _34093 = NOVALUE;
        }
        _34093 = NOVALUE;

        /** 	end for*/
        _0 = _i_67429;
        if (IS_ATOM_INT(_i_67429)) {
            _i_67429 = _i_67429 + 1;
            if ((long)((unsigned long)_i_67429 +(unsigned long) HIGH_BITS) >= 0){
                _i_67429 = NewDouble((double)_i_67429);
            }
        }
        else {
            _i_67429 = binary_op_a(PLUS, _i_67429, 1);
        }
        DeRef(_0);
        goto L1; // [82] 62
L2: 
        ;
        DeRef(_i_67429);
    }

    /** 	target = Code[pc+n+2]*/
    _34095 = _67pc_63479 + _n_67419;
    if ((long)((unsigned long)_34095 + (unsigned long)HIGH_BITS) >= 0) 
    _34095 = NewDouble((double)_34095);
    if (IS_ATOM_INT(_34095)) {
        _34096 = _34095 + 2;
    }
    else {
        _34096 = NewDouble(DBL_PTR(_34095)->dbl + (double)2);
    }
    DeRef(_34095);
    _34095 = NOVALUE;
    _2 = (int)SEQ_PTR(_26Code_12071);
    if (!IS_ATOM_INT(_34096)){
        _67target_63484 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_34096)->dbl));
    }
    else{
        _67target_63484 = (int)*(((s1_ptr)_2)->base + _34096);
    }
    if (!IS_ATOM_INT(_67target_63484)){
        _67target_63484 = (long)DBL_PTR(_67target_63484)->dbl;
    }

    /** 	val[target] = x*/
    Ref(_x_67420);
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63484);
    _1 = *(int *)_2;
    *(int *)_2 = _x_67420;
    DeRef(_1);

    /** 	pc += n+3*/
    _34098 = _n_67419 + 3;
    if ((long)((unsigned long)_34098 + (unsigned long)HIGH_BITS) >= 0) 
    _34098 = NewDouble((double)_34098);
    if (IS_ATOM_INT(_34098)) {
        _67pc_63479 = _67pc_63479 + _34098;
    }
    else {
        _67pc_63479 = NewDouble((double)_67pc_63479 + DBL_PTR(_34098)->dbl);
    }
    DeRef(_34098);
    _34098 = NOVALUE;
    if (!IS_ATOM_INT(_67pc_63479)) {
        _1 = (long)(DBL_PTR(_67pc_63479)->dbl);
        DeRefDS(_67pc_63479);
        _67pc_63479 = _1;
    }

    /** end procedure*/
    DeRef(_x_67420);
    DeRef(_34084);
    _34084 = NOVALUE;
    DeRef(_34086);
    _34086 = NOVALUE;
    _34087 = NOVALUE;
    DeRef(_34089);
    _34089 = NOVALUE;
    _34092 = NOVALUE;
    DeRef(_34091);
    _34091 = NOVALUE;
    DeRef(_34096);
    _34096 = NOVALUE;
    return;
    ;
}


void _67opREPEAT()
{
    int _34119 = NOVALUE;
    int _34118 = NOVALUE;
    int _34117 = NOVALUE;
    int _34113 = NOVALUE;
    int _34110 = NOVALUE;
    int _34107 = NOVALUE;
    int _34106 = NOVALUE;
    int _34104 = NOVALUE;
    int _34102 = NOVALUE;
    int _34100 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _34100 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _34100);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _34102 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67b_63481 = (int)*(((s1_ptr)_2)->base + _34102);
    if (!IS_ATOM_INT(_67b_63481)){
        _67b_63481 = (long)DBL_PTR(_67b_63481)->dbl;
    }

    /** 	target = Code[pc+3]*/
    _34104 = _67pc_63479 + 3;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67target_63484 = (int)*(((s1_ptr)_2)->base + _34104);
    if (!IS_ATOM_INT(_67target_63484)){
        _67target_63484 = (long)DBL_PTR(_67target_63484)->dbl;
    }

    /** 	if not atom(val[b]) then*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _34106 = (int)*(((s1_ptr)_2)->base + _67b_63481);
    _34107 = IS_ATOM(_34106);
    _34106 = NOVALUE;
    if (_34107 != 0)
    goto L1; // [62] 71
    _34107 = NOVALUE;

    /** 		RTFatal("repetition count must be an atom")*/
    RefDS(_34109);
    _67RTFatal(_34109);
L1: 

    /** 	if val[b] < 0 then*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _34110 = (int)*(((s1_ptr)_2)->base + _67b_63481);
    if (binary_op_a(GREATEREQ, _34110, 0)){
        _34110 = NOVALUE;
        goto L2; // [81] 91
    }
    _34110 = NOVALUE;

    /** 		RTFatal("repetition count must not be negative")*/
    RefDS(_34112);
    _67RTFatal(_34112);
L2: 

    /** 	if val[b] > 1073741823 then*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _34113 = (int)*(((s1_ptr)_2)->base + _67b_63481);
    if (binary_op_a(LESSEQ, _34113, 1073741823)){
        _34113 = NOVALUE;
        goto L3; // [101] 111
    }
    _34113 = NOVALUE;

    /** 		RTFatal("repetition count is too large")*/
    RefDS(_34116);
    _67RTFatal(_34116);
L3: 

    /** 	val[target] = repeat(val[a], val[b])*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _34117 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    _2 = (int)SEQ_PTR(_67val_63489);
    _34118 = (int)*(((s1_ptr)_2)->base + _67b_63481);
    _34119 = Repeat(_34117, _34118);
    _34117 = NOVALUE;
    _34118 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63484);
    _1 = *(int *)_2;
    *(int *)_2 = _34119;
    if( _1 != _34119 ){
        DeRef(_1);
    }
    _34119 = NOVALUE;

    /** 	pc += 4*/
    _67pc_63479 = _67pc_63479 + 4;

    /** end procedure*/
    DeRef(_34100);
    _34100 = NOVALUE;
    DeRef(_34102);
    _34102 = NOVALUE;
    DeRef(_34104);
    _34104 = NOVALUE;
    return;
    ;
}


void _67opDATE()
{
    int _34123 = NOVALUE;
    int _34121 = NOVALUE;
    int _0, _1, _2;
    

    /** 	target = Code[pc+1]*/
    _34121 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67target_63484 = (int)*(((s1_ptr)_2)->base + _34121);
    if (!IS_ATOM_INT(_67target_63484)){
        _67target_63484 = (long)DBL_PTR(_67target_63484)->dbl;
    }

    /** 	val[target] = date()*/
    _34123 = Date();
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63484);
    _1 = *(int *)_2;
    *(int *)_2 = _34123;
    if( _1 != _34123 ){
        DeRef(_1);
    }
    _34123 = NOVALUE;

    /** 	pc += 2*/
    _67pc_63479 = _67pc_63479 + 2;

    /** end procedure*/
    _34121 = NOVALUE;
    return;
    ;
}


void _67opTIME()
{
    int _34127 = NOVALUE;
    int _34125 = NOVALUE;
    int _0, _1, _2;
    

    /** 	target = Code[pc+1]*/
    _34125 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67target_63484 = (int)*(((s1_ptr)_2)->base + _34125);
    if (!IS_ATOM_INT(_67target_63484)){
        _67target_63484 = (long)DBL_PTR(_67target_63484)->dbl;
    }

    /** 	val[target] = time()*/
    _34127 = NewDouble(current_time());
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63484);
    _1 = *(int *)_2;
    *(int *)_2 = _34127;
    if( _1 != _34127 ){
        DeRef(_1);
    }
    _34127 = NOVALUE;

    /** 	pc += 2*/
    _67pc_63479 = _67pc_63479 + 2;

    /** end procedure*/
    _34125 = NOVALUE;
    return;
    ;
}


void _67opSPACE_USED()
{
    int _0, _1, _2;
    

    /** 	pc += 2*/
    _67pc_63479 = _67pc_63479 + 2;

    /** end procedure*/
    return;
    ;
}


void _67opNOP2()
{
    int _0, _1, _2;
    

    /** 	pc+= 2*/
    _67pc_63479 = _67pc_63479 + 2;

    /** end procedure*/
    return;
    ;
}


void _67opPOSITION()
{
    int _34136 = NOVALUE;
    int _34135 = NOVALUE;
    int _34133 = NOVALUE;
    int _34131 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _34131 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _34131);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _34133 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67b_63481 = (int)*(((s1_ptr)_2)->base + _34133);
    if (!IS_ATOM_INT(_67b_63481)){
        _67b_63481 = (long)DBL_PTR(_67b_63481)->dbl;
    }

    /** 	position(val[a], val[b])  -- error checks*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _34135 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    _2 = (int)SEQ_PTR(_67val_63489);
    _34136 = (int)*(((s1_ptr)_2)->base + _67b_63481);
    Position(_34135, _34136);
    _34135 = NOVALUE;
    _34136 = NOVALUE;

    /** 	pc += 3*/
    _67pc_63479 = _67pc_63479 + 3;

    /** end procedure*/
    _34131 = NOVALUE;
    _34133 = NOVALUE;
    return;
    ;
}


void _67opEQUAL()
{
    int _34146 = NOVALUE;
    int _34145 = NOVALUE;
    int _34144 = NOVALUE;
    int _34142 = NOVALUE;
    int _34140 = NOVALUE;
    int _34138 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _34138 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _34138);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _34140 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67b_63481 = (int)*(((s1_ptr)_2)->base + _34140);
    if (!IS_ATOM_INT(_67b_63481)){
        _67b_63481 = (long)DBL_PTR(_67b_63481)->dbl;
    }

    /** 	target = Code[pc+3]*/
    _34142 = _67pc_63479 + 3;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67target_63484 = (int)*(((s1_ptr)_2)->base + _34142);
    if (!IS_ATOM_INT(_67target_63484)){
        _67target_63484 = (long)DBL_PTR(_67target_63484)->dbl;
    }

    /** 	val[target] = equal(val[a], val[b])*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _34144 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    _2 = (int)SEQ_PTR(_67val_63489);
    _34145 = (int)*(((s1_ptr)_2)->base + _67b_63481);
    if (_34144 == _34145)
    _34146 = 1;
    else if (IS_ATOM_INT(_34144) && IS_ATOM_INT(_34145))
    _34146 = 0;
    else
    _34146 = (compare(_34144, _34145) == 0);
    _34144 = NOVALUE;
    _34145 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63484);
    _1 = *(int *)_2;
    *(int *)_2 = _34146;
    if( _1 != _34146 ){
        DeRef(_1);
    }
    _34146 = NOVALUE;

    /** 	pc += 4*/
    _67pc_63479 = _67pc_63479 + 4;

    /** end procedure*/
    _34138 = NOVALUE;
    _34140 = NOVALUE;
    _34142 = NOVALUE;
    return;
    ;
}


void _67opHASH()
{
    int _34156 = NOVALUE;
    int _34155 = NOVALUE;
    int _34154 = NOVALUE;
    int _34152 = NOVALUE;
    int _34150 = NOVALUE;
    int _34148 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _34148 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _34148);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _34150 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67b_63481 = (int)*(((s1_ptr)_2)->base + _34150);
    if (!IS_ATOM_INT(_67b_63481)){
        _67b_63481 = (long)DBL_PTR(_67b_63481)->dbl;
    }

    /** 	target = Code[pc+3]*/
    _34152 = _67pc_63479 + 3;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67target_63484 = (int)*(((s1_ptr)_2)->base + _34152);
    if (!IS_ATOM_INT(_67target_63484)){
        _67target_63484 = (long)DBL_PTR(_67target_63484)->dbl;
    }

    /** 	val[target] = hash(val[a], val[b])*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _34154 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    _2 = (int)SEQ_PTR(_67val_63489);
    _34155 = (int)*(((s1_ptr)_2)->base + _67b_63481);
    _34156 = calc_hash(_34154, _34155);
    _34154 = NOVALUE;
    _34155 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63484);
    _1 = *(int *)_2;
    *(int *)_2 = _34156;
    if( _1 != _34156 ){
        DeRef(_1);
    }
    _34156 = NOVALUE;

    /** 	pc += 4*/
    _67pc_63479 = _67pc_63479 + 4;

    /** end procedure*/
    _34148 = NOVALUE;
    _34150 = NOVALUE;
    _34152 = NOVALUE;
    return;
    ;
}


void _67opCOMPARE()
{
    int _34166 = NOVALUE;
    int _34165 = NOVALUE;
    int _34164 = NOVALUE;
    int _34162 = NOVALUE;
    int _34160 = NOVALUE;
    int _34158 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _34158 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _34158);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _34160 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67b_63481 = (int)*(((s1_ptr)_2)->base + _34160);
    if (!IS_ATOM_INT(_67b_63481)){
        _67b_63481 = (long)DBL_PTR(_67b_63481)->dbl;
    }

    /** 	target = Code[pc+3]*/
    _34162 = _67pc_63479 + 3;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67target_63484 = (int)*(((s1_ptr)_2)->base + _34162);
    if (!IS_ATOM_INT(_67target_63484)){
        _67target_63484 = (long)DBL_PTR(_67target_63484)->dbl;
    }

    /** 	val[target] = compare(val[a], val[b])*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _34164 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    _2 = (int)SEQ_PTR(_67val_63489);
    _34165 = (int)*(((s1_ptr)_2)->base + _67b_63481);
    if (IS_ATOM_INT(_34164) && IS_ATOM_INT(_34165)){
        _34166 = (_34164 < _34165) ? -1 : (_34164 > _34165);
    }
    else{
        _34166 = compare(_34164, _34165);
    }
    _34164 = NOVALUE;
    _34165 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63484);
    _1 = *(int *)_2;
    *(int *)_2 = _34166;
    if( _1 != _34166 ){
        DeRef(_1);
    }
    _34166 = NOVALUE;

    /** 	pc += 4*/
    _67pc_63479 = _67pc_63479 + 4;

    /** end procedure*/
    _34158 = NOVALUE;
    _34160 = NOVALUE;
    _34162 = NOVALUE;
    return;
    ;
}


void _67opFIND()
{
    int _34180 = NOVALUE;
    int _34179 = NOVALUE;
    int _34178 = NOVALUE;
    int _34175 = NOVALUE;
    int _34174 = NOVALUE;
    int _34172 = NOVALUE;
    int _34170 = NOVALUE;
    int _34168 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _34168 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _34168);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _34170 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67b_63481 = (int)*(((s1_ptr)_2)->base + _34170);
    if (!IS_ATOM_INT(_67b_63481)){
        _67b_63481 = (long)DBL_PTR(_67b_63481)->dbl;
    }

    /** 	target = Code[pc+3]*/
    _34172 = _67pc_63479 + 3;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67target_63484 = (int)*(((s1_ptr)_2)->base + _34172);
    if (!IS_ATOM_INT(_67target_63484)){
        _67target_63484 = (long)DBL_PTR(_67target_63484)->dbl;
    }

    /** 	if not sequence(val[b]) then*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _34174 = (int)*(((s1_ptr)_2)->base + _67b_63481);
    _34175 = IS_SEQUENCE(_34174);
    _34174 = NOVALUE;
    if (_34175 != 0)
    goto L1; // [62] 71
    _34175 = NOVALUE;

    /** 		RTFatal("second argument of find() must be a sequence")*/
    RefDS(_34177);
    _67RTFatal(_34177);
L1: 

    /** 	val[target] = find(val[a], val[b])*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _34178 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    _2 = (int)SEQ_PTR(_67val_63489);
    _34179 = (int)*(((s1_ptr)_2)->base + _67b_63481);
    _34180 = find_from(_34178, _34179, 1);
    _34178 = NOVALUE;
    _34179 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63484);
    _1 = *(int *)_2;
    *(int *)_2 = _34180;
    if( _1 != _34180 ){
        DeRef(_1);
    }
    _34180 = NOVALUE;

    /** 	pc += 4*/
    _67pc_63479 = _67pc_63479 + 4;

    /** end procedure*/
    DeRef(_34168);
    _34168 = NOVALUE;
    DeRef(_34170);
    _34170 = NOVALUE;
    DeRef(_34172);
    _34172 = NOVALUE;
    return;
    ;
}


void _67opMATCH()
{
    int _34202 = NOVALUE;
    int _34201 = NOVALUE;
    int _34200 = NOVALUE;
    int _34197 = NOVALUE;
    int _34196 = NOVALUE;
    int _34193 = NOVALUE;
    int _34192 = NOVALUE;
    int _34189 = NOVALUE;
    int _34188 = NOVALUE;
    int _34186 = NOVALUE;
    int _34184 = NOVALUE;
    int _34182 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _34182 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _34182);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _34184 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67b_63481 = (int)*(((s1_ptr)_2)->base + _34184);
    if (!IS_ATOM_INT(_67b_63481)){
        _67b_63481 = (long)DBL_PTR(_67b_63481)->dbl;
    }

    /** 	target = Code[pc+3]*/
    _34186 = _67pc_63479 + 3;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67target_63484 = (int)*(((s1_ptr)_2)->base + _34186);
    if (!IS_ATOM_INT(_67target_63484)){
        _67target_63484 = (long)DBL_PTR(_67target_63484)->dbl;
    }

    /** 	if not sequence(val[a]) then*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _34188 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    _34189 = IS_SEQUENCE(_34188);
    _34188 = NOVALUE;
    if (_34189 != 0)
    goto L1; // [62] 71
    _34189 = NOVALUE;

    /** 		RTFatal("first argument of match() must be a sequence")*/
    RefDS(_34191);
    _67RTFatal(_34191);
L1: 

    /** 	if not sequence(val[b]) then*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _34192 = (int)*(((s1_ptr)_2)->base + _67b_63481);
    _34193 = IS_SEQUENCE(_34192);
    _34192 = NOVALUE;
    if (_34193 != 0)
    goto L2; // [84] 93
    _34193 = NOVALUE;

    /** 		RTFatal("second argument of match() must be a sequence")*/
    RefDS(_34195);
    _67RTFatal(_34195);
L2: 

    /** 	if length(val[a]) = 0 then*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _34196 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    if (IS_SEQUENCE(_34196)){
            _34197 = SEQ_PTR(_34196)->length;
    }
    else {
        _34197 = 1;
    }
    _34196 = NOVALUE;
    if (_34197 != 0)
    goto L3; // [106] 116

    /** 		 RTFatal("first argument of match() must be a non-empty sequence")*/
    RefDS(_34199);
    _67RTFatal(_34199);
L3: 

    /** 	val[target] = match(val[a], val[b])*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _34200 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    _2 = (int)SEQ_PTR(_67val_63489);
    _34201 = (int)*(((s1_ptr)_2)->base + _67b_63481);
    _34202 = e_match_from(_34200, _34201, 1);
    _34200 = NOVALUE;
    _34201 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63484);
    _1 = *(int *)_2;
    *(int *)_2 = _34202;
    if( _1 != _34202 ){
        DeRef(_1);
    }
    _34202 = NOVALUE;

    /** 	pc += 4*/
    _67pc_63479 = _67pc_63479 + 4;

    /** end procedure*/
    DeRef(_34182);
    _34182 = NOVALUE;
    DeRef(_34184);
    _34184 = NOVALUE;
    DeRef(_34186);
    _34186 = NOVALUE;
    _34196 = NOVALUE;
    return;
    ;
}


void _67opFIND_FROM()
{
    int _s_67600 = NOVALUE;
    int _34225 = NOVALUE;
    int _34223 = NOVALUE;
    int _34222 = NOVALUE;
    int _34221 = NOVALUE;
    int _34219 = NOVALUE;
    int _34218 = NOVALUE;
    int _34217 = NOVALUE;
    int _34216 = NOVALUE;
    int _34212 = NOVALUE;
    int _34211 = NOVALUE;
    int _34210 = NOVALUE;
    int _34209 = NOVALUE;
    int _34207 = NOVALUE;
    int _34205 = NOVALUE;
    int _34204 = NOVALUE;
    int _0, _1, _2;
    

    /** 		c = val[Code[pc+3]]*/
    _34204 = _67pc_63479 + 3;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _34205 = (int)*(((s1_ptr)_2)->base + _34204);
    _2 = (int)SEQ_PTR(_67val_63489);
    if (!IS_ATOM_INT(_34205)){
        _67c_63482 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_34205)->dbl));
    }
    else{
        _67c_63482 = (int)*(((s1_ptr)_2)->base + _34205);
    }
    if (!IS_ATOM_INT(_67c_63482))
    _67c_63482 = (long)DBL_PTR(_67c_63482)->dbl;

    /** 		target = Code[pc+4]*/
    _34207 = _67pc_63479 + 4;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67target_63484 = (int)*(((s1_ptr)_2)->base + _34207);
    if (!IS_ATOM_INT(_67target_63484)){
        _67target_63484 = (long)DBL_PTR(_67target_63484)->dbl;
    }

    /** 		if not sequence(val[Code[pc+2]]) then*/
    _34209 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _34210 = (int)*(((s1_ptr)_2)->base + _34209);
    _2 = (int)SEQ_PTR(_67val_63489);
    if (!IS_ATOM_INT(_34210)){
        _34211 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_34210)->dbl));
    }
    else{
        _34211 = (int)*(((s1_ptr)_2)->base + _34210);
    }
    _34212 = IS_SEQUENCE(_34211);
    _34211 = NOVALUE;
    if (_34212 != 0)
    goto L1; // [60] 82
    _34212 = NOVALUE;

    /** 				RTFatal("second argument of find_from() must be a sequence")*/
    RefDS(_34214);
    _67RTFatal(_34214);

    /** 				pc += 5*/
    _67pc_63479 = _67pc_63479 + 5;

    /** 				return*/
    DeRef(_s_67600);
    _34204 = NOVALUE;
    _34205 = NOVALUE;
    _34207 = NOVALUE;
    _34209 = NOVALUE;
    _34210 = NOVALUE;
    return;
L1: 

    /** 		s = val[Code[pc+2]][c..$]*/
    _34216 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _34217 = (int)*(((s1_ptr)_2)->base + _34216);
    _2 = (int)SEQ_PTR(_67val_63489);
    if (!IS_ATOM_INT(_34217)){
        _34218 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_34217)->dbl));
    }
    else{
        _34218 = (int)*(((s1_ptr)_2)->base + _34217);
    }
    if (IS_SEQUENCE(_34218)){
            _34219 = SEQ_PTR(_34218)->length;
    }
    else {
        _34219 = 1;
    }
    rhs_slice_target = (object_ptr)&_s_67600;
    RHS_Slice(_34218, _67c_63482, _34219);
    _34218 = NOVALUE;

    /** 		b = find( val[Code[pc+1]], s )*/
    _34221 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _34222 = (int)*(((s1_ptr)_2)->base + _34221);
    _2 = (int)SEQ_PTR(_67val_63489);
    if (!IS_ATOM_INT(_34222)){
        _34223 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_34222)->dbl));
    }
    else{
        _34223 = (int)*(((s1_ptr)_2)->base + _34222);
    }
    _67b_63481 = find_from(_34223, _s_67600, 1);
    _34223 = NOVALUE;

    /** 		if b then*/
    if (_67b_63481 == 0)
    {
        goto L2; // [141] 161
    }
    else{
    }

    /** 				b += c - 1*/
    _34225 = _67c_63482 - 1;
    if ((long)((unsigned long)_34225 +(unsigned long) HIGH_BITS) >= 0){
        _34225 = NewDouble((double)_34225);
    }
    if (IS_ATOM_INT(_34225)) {
        _67b_63481 = _67b_63481 + _34225;
    }
    else {
        _67b_63481 = NewDouble((double)_67b_63481 + DBL_PTR(_34225)->dbl);
    }
    DeRef(_34225);
    _34225 = NOVALUE;
    if (!IS_ATOM_INT(_67b_63481)) {
        _1 = (long)(DBL_PTR(_67b_63481)->dbl);
        DeRefDS(_67b_63481);
        _67b_63481 = _1;
    }
L2: 

    /** 		val[target] = b*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63484);
    _1 = *(int *)_2;
    *(int *)_2 = _67b_63481;
    DeRef(_1);

    /** 		pc += 5*/
    _67pc_63479 = _67pc_63479 + 5;

    /** end procedure*/
    DeRef(_s_67600);
    DeRef(_34204);
    _34204 = NOVALUE;
    _34205 = NOVALUE;
    DeRef(_34207);
    _34207 = NOVALUE;
    DeRef(_34209);
    _34209 = NOVALUE;
    _34210 = NOVALUE;
    DeRef(_34216);
    _34216 = NOVALUE;
    _34217 = NOVALUE;
    DeRef(_34221);
    _34221 = NOVALUE;
    _34222 = NOVALUE;
    return;
    ;
}


void _67opMATCH_FROM()
{
    int _s_67634 = NOVALUE;
    int _34268 = NOVALUE;
    int _34267 = NOVALUE;
    int _34265 = NOVALUE;
    int _34264 = NOVALUE;
    int _34263 = NOVALUE;
    int _34262 = NOVALUE;
    int _34261 = NOVALUE;
    int _34260 = NOVALUE;
    int _34259 = NOVALUE;
    int _34258 = NOVALUE;
    int _34257 = NOVALUE;
    int _34256 = NOVALUE;
    int _34254 = NOVALUE;
    int _34248 = NOVALUE;
    int _34244 = NOVALUE;
    int _34243 = NOVALUE;
    int _34239 = NOVALUE;
    int _34238 = NOVALUE;
    int _34236 = NOVALUE;
    int _34234 = NOVALUE;
    int _34233 = NOVALUE;
    int _34231 = NOVALUE;
    int _34229 = NOVALUE;
    int _34228 = NOVALUE;
    int _0, _1, _2;
    

    /** 		c = val[Code[pc+3]]*/
    _34228 = _67pc_63479 + 3;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _34229 = (int)*(((s1_ptr)_2)->base + _34228);
    _2 = (int)SEQ_PTR(_67val_63489);
    if (!IS_ATOM_INT(_34229)){
        _67c_63482 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_34229)->dbl));
    }
    else{
        _67c_63482 = (int)*(((s1_ptr)_2)->base + _34229);
    }
    if (!IS_ATOM_INT(_67c_63482))
    _67c_63482 = (long)DBL_PTR(_67c_63482)->dbl;

    /** 		target = Code[pc+4]*/
    _34231 = _67pc_63479 + 4;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67target_63484 = (int)*(((s1_ptr)_2)->base + _34231);
    if (!IS_ATOM_INT(_67target_63484)){
        _67target_63484 = (long)DBL_PTR(_67target_63484)->dbl;
    }

    /** 		s = val[Code[pc+2]]*/
    _34233 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _34234 = (int)*(((s1_ptr)_2)->base + _34233);
    DeRef(_s_67634);
    _2 = (int)SEQ_PTR(_67val_63489);
    if (!IS_ATOM_INT(_34234)){
        _s_67634 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_34234)->dbl));
    }
    else{
        _s_67634 = (int)*(((s1_ptr)_2)->base + _34234);
    }
    Ref(_s_67634);

    /** 		a = Code[pc+1]*/
    _34236 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _34236);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 		if not sequence(val[a]) then*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _34238 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    _34239 = IS_SEQUENCE(_34238);
    _34238 = NOVALUE;
    if (_34239 != 0)
    goto L1; // [86] 108
    _34239 = NOVALUE;

    /** 				RTFatal("first argument of match_from() must be a sequence")*/
    RefDS(_34241);
    _67RTFatal(_34241);

    /** 				pc += 5*/
    _67pc_63479 = _67pc_63479 + 5;

    /** 				return*/
    DeRef(_s_67634);
    _34228 = NOVALUE;
    _34229 = NOVALUE;
    _34231 = NOVALUE;
    _34233 = NOVALUE;
    _34234 = NOVALUE;
    _34236 = NOVALUE;
    return;
L1: 

    /** 		if length(val[a]) = 0 then*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _34243 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    if (IS_SEQUENCE(_34243)){
            _34244 = SEQ_PTR(_34243)->length;
    }
    else {
        _34244 = 1;
    }
    _34243 = NOVALUE;
    if (_34244 != 0)
    goto L2; // [121] 144

    /** 				RTFatal("first argument of match_from() must be a non-empty sequence")*/
    RefDS(_34246);
    _67RTFatal(_34246);

    /** 				pc += 5*/
    _67pc_63479 = _67pc_63479 + 5;

    /** 				return*/
    DeRef(_s_67634);
    DeRef(_34228);
    _34228 = NOVALUE;
    _34229 = NOVALUE;
    DeRef(_34231);
    _34231 = NOVALUE;
    DeRef(_34233);
    _34233 = NOVALUE;
    _34234 = NOVALUE;
    DeRef(_34236);
    _34236 = NOVALUE;
    _34243 = NOVALUE;
    return;
L2: 

    /** 		if not sequence(s) then*/
    _34248 = IS_SEQUENCE(_s_67634);
    if (_34248 != 0)
    goto L3; // [149] 171
    _34248 = NOVALUE;

    /** 				RTFatal("second argument of match_from() must be a sequence")*/
    RefDS(_34250);
    _67RTFatal(_34250);

    /** 				pc += 5*/
    _67pc_63479 = _67pc_63479 + 5;

    /** 				return*/
    DeRef(_s_67634);
    DeRef(_34228);
    _34228 = NOVALUE;
    _34229 = NOVALUE;
    DeRef(_34231);
    _34231 = NOVALUE;
    DeRef(_34233);
    _34233 = NOVALUE;
    _34234 = NOVALUE;
    DeRef(_34236);
    _34236 = NOVALUE;
    _34243 = NOVALUE;
    return;
L3: 

    /** 		if c < 1 then*/
    if (_67c_63482 >= 1)
    goto L4; // [175] 204

    /** 				RTFatal(sprintf("index (%d) out of bounds in match_from()", c ))*/
    _34254 = EPrintf(-9999999, _34253, _67c_63482);
    _67RTFatal(_34254);
    _34254 = NOVALUE;

    /** 				pc += 5*/
    _67pc_63479 = _67pc_63479 + 5;

    /** 				return*/
    DeRef(_s_67634);
    DeRef(_34228);
    _34228 = NOVALUE;
    _34229 = NOVALUE;
    DeRef(_34231);
    _34231 = NOVALUE;
    DeRef(_34233);
    _34233 = NOVALUE;
    _34234 = NOVALUE;
    DeRef(_34236);
    _34236 = NOVALUE;
    _34243 = NOVALUE;
    return;
L4: 

    /** 		if not (length(s) = 0 and c = 1) and c > length(s) + 1 then*/
    if (IS_SEQUENCE(_s_67634)){
            _34256 = SEQ_PTR(_s_67634)->length;
    }
    else {
        _34256 = 1;
    }
    _34257 = (_34256 == 0);
    _34256 = NOVALUE;
    if (_34257 == 0) {
        DeRef(_34258);
        _34258 = 0;
        goto L5; // [213] 227
    }
    _34259 = (_67c_63482 == 1);
    _34258 = (_34259 != 0);
L5: 
    _34260 = (_34258 == 0);
    _34258 = NOVALUE;
    if (_34260 == 0) {
        goto L6; // [230] 276
    }
    if (IS_SEQUENCE(_s_67634)){
            _34262 = SEQ_PTR(_s_67634)->length;
    }
    else {
        _34262 = 1;
    }
    _34263 = _34262 + 1;
    _34262 = NOVALUE;
    _34264 = (_67c_63482 > _34263);
    _34263 = NOVALUE;
    if (_34264 == 0)
    {
        DeRef(_34264);
        _34264 = NOVALUE;
        goto L6; // [248] 276
    }
    else{
        DeRef(_34264);
        _34264 = NOVALUE;
    }

    /** 				RTFatal(sprintf("index (%d) out of bounds in match_from()", c ))*/
    _34265 = EPrintf(-9999999, _34253, _67c_63482);
    _67RTFatal(_34265);
    _34265 = NOVALUE;

    /** 				pc += 5*/
    _67pc_63479 = _67pc_63479 + 5;

    /** 				return*/
    DeRef(_s_67634);
    DeRef(_34228);
    _34228 = NOVALUE;
    _34229 = NOVALUE;
    DeRef(_34231);
    _34231 = NOVALUE;
    DeRef(_34233);
    _34233 = NOVALUE;
    _34234 = NOVALUE;
    DeRef(_34236);
    _34236 = NOVALUE;
    _34243 = NOVALUE;
    DeRef(_34257);
    _34257 = NOVALUE;
    DeRef(_34259);
    _34259 = NOVALUE;
    DeRef(_34260);
    _34260 = NOVALUE;
    return;
L6: 

    /** 		val[target] = match( val[a], s, c )*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _34267 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    _34268 = e_match_from(_34267, _s_67634, _67c_63482);
    _34267 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63484);
    _1 = *(int *)_2;
    *(int *)_2 = _34268;
    if( _1 != _34268 ){
        DeRef(_1);
    }
    _34268 = NOVALUE;

    /** 		pc += 5*/
    _67pc_63479 = _67pc_63479 + 5;

    /** end procedure*/
    DeRef(_s_67634);
    DeRef(_34228);
    _34228 = NOVALUE;
    _34229 = NOVALUE;
    DeRef(_34231);
    _34231 = NOVALUE;
    DeRef(_34233);
    _34233 = NOVALUE;
    _34234 = NOVALUE;
    DeRef(_34236);
    _34236 = NOVALUE;
    _34243 = NOVALUE;
    DeRef(_34257);
    _34257 = NOVALUE;
    DeRef(_34259);
    _34259 = NOVALUE;
    DeRef(_34260);
    _34260 = NOVALUE;
    return;
    ;
}


void _67opPEEK2U()
{
    int _34275 = NOVALUE;
    int _34274 = NOVALUE;
    int _34272 = NOVALUE;
    int _34270 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _34270 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _34270);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	target = Code[pc+2]*/
    _34272 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67target_63484 = (int)*(((s1_ptr)_2)->base + _34272);
    if (!IS_ATOM_INT(_67target_63484)){
        _67target_63484 = (long)DBL_PTR(_67target_63484)->dbl;
    }

    /** 	val[target] = peek2u(val[a])*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _34274 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    if (IS_ATOM_INT(_34274)) {
        _34275 = *(unsigned short *)_34274;
    }
    else if (IS_ATOM(_34274)) {
        _34275 = *(unsigned short *)(unsigned long)(DBL_PTR(_34274)->dbl);
    }
    else {
        _1 = (int)SEQ_PTR(_34274);
        poke2_addr = (unsigned short *)get_pos_int("peek2s/peek2u", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        poke4_addr = (unsigned long *)NewS1(_2);
        _34275 = MAKE_SEQ(poke4_addr);
        poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
        while (--_2 >= 0) {
            poke4_addr++;
            _1 = (int)(unsigned short)*poke2_addr++;
            *(int *)poke4_addr = _1;
        }
    }
    _34274 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63484);
    _1 = *(int *)_2;
    *(int *)_2 = _34275;
    if( _1 != _34275 ){
        DeRef(_1);
    }
    _34275 = NOVALUE;

    /** 	pc += 3*/
    _67pc_63479 = _67pc_63479 + 3;

    /** end procedure*/
    _34270 = NOVALUE;
    _34272 = NOVALUE;
    return;
    ;
}


void _67opPEEK2S()
{
    int _34282 = NOVALUE;
    int _34281 = NOVALUE;
    int _34279 = NOVALUE;
    int _34277 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _34277 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _34277);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	target = Code[pc+2]*/
    _34279 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67target_63484 = (int)*(((s1_ptr)_2)->base + _34279);
    if (!IS_ATOM_INT(_67target_63484)){
        _67target_63484 = (long)DBL_PTR(_67target_63484)->dbl;
    }

    /** 	val[target] = peek2s(val[a])*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _34281 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    if (IS_ATOM_INT(_34281)) {
        _34282 = *(signed short *)_34281;
    }
    else if (IS_ATOM(_34281)) {
        _34282 = *(signed short *)(unsigned long)(DBL_PTR(_34281)->dbl);
    }
    else {
        _1 = (int)SEQ_PTR(_34281);
        poke2_addr = (unsigned short *)get_pos_int("peek2s/peek2u", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        poke4_addr = (unsigned long *)NewS1(_2);
        _34282 = MAKE_SEQ(poke4_addr);
        poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
        while (--_2 >= 0) {
            poke4_addr++;
            _1 = (int)(short)*poke2_addr++;
            *(int *)poke4_addr = _1;
        }
    }
    _34281 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63484);
    _1 = *(int *)_2;
    *(int *)_2 = _34282;
    if( _1 != _34282 ){
        DeRef(_1);
    }
    _34282 = NOVALUE;

    /** 	pc += 3*/
    _67pc_63479 = _67pc_63479 + 3;

    /** end procedure*/
    _34277 = NOVALUE;
    _34279 = NOVALUE;
    return;
    ;
}


void _67opPEEK4U()
{
    int _34289 = NOVALUE;
    int _34288 = NOVALUE;
    int _34286 = NOVALUE;
    int _34284 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _34284 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _34284);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	target = Code[pc+2]*/
    _34286 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67target_63484 = (int)*(((s1_ptr)_2)->base + _34286);
    if (!IS_ATOM_INT(_67target_63484)){
        _67target_63484 = (long)DBL_PTR(_67target_63484)->dbl;
    }

    /** 	val[target] = peek4u(val[a])*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _34288 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    if (IS_ATOM_INT(_34288)) {
        _34289 = *(unsigned long *)_34288;
        if ((unsigned)_34289 > (unsigned)MAXINT)
        _34289 = NewDouble((double)(unsigned long)_34289);
    }
    else if (IS_ATOM(_34288)) {
        _34289 = *(unsigned long *)(unsigned long)(DBL_PTR(_34288)->dbl);
        if ((unsigned)_34289 > (unsigned)MAXINT)
        _34289 = NewDouble((double)(unsigned long)_34289);
    }
    else {
        _1 = (int)SEQ_PTR(_34288);
        peek4_addr = (unsigned long *)get_pos_int("peek4s/peek4u", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        poke4_addr = (unsigned long *)NewS1(_2);
        _34289 = MAKE_SEQ(poke4_addr);
        poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
        while (--_2 >= 0) {
            poke4_addr++;
            _1 = (int)*peek4_addr++;
            if ((unsigned)_1 > (unsigned)MAXINT)
            _1 = NewDouble((double)(unsigned long)_1);
            *(int *)poke4_addr = _1;
        }
    }
    _34288 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63484);
    _1 = *(int *)_2;
    *(int *)_2 = _34289;
    if( _1 != _34289 ){
        DeRef(_1);
    }
    _34289 = NOVALUE;

    /** 	pc += 3*/
    _67pc_63479 = _67pc_63479 + 3;

    /** end procedure*/
    _34284 = NOVALUE;
    _34286 = NOVALUE;
    return;
    ;
}


void _67opPEEK4S()
{
    int _34296 = NOVALUE;
    int _34295 = NOVALUE;
    int _34293 = NOVALUE;
    int _34291 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _34291 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _34291);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	target = Code[pc+2]*/
    _34293 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67target_63484 = (int)*(((s1_ptr)_2)->base + _34293);
    if (!IS_ATOM_INT(_67target_63484)){
        _67target_63484 = (long)DBL_PTR(_67target_63484)->dbl;
    }

    /** 	val[target] = peek4s(val[a])*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _34295 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    if (IS_ATOM_INT(_34295)) {
        _34296 = *(unsigned long *)_34295;
        if (_34296 < MININT || _34296 > MAXINT)
        _34296 = NewDouble((double)(long)_34296);
    }
    else if (IS_ATOM(_34295)) {
        _34296 = *(unsigned long *)(unsigned long)(DBL_PTR(_34295)->dbl);
        if (_34296 < MININT || _34296 > MAXINT)
        _34296 = NewDouble((double)(long)_34296);
    }
    else {
        _1 = (int)SEQ_PTR(_34295);
        peek4_addr = (unsigned long *)get_pos_int("peek4s/peek4u", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        poke4_addr = (unsigned long *)NewS1(_2);
        _34296 = MAKE_SEQ(poke4_addr);
        poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
        while (--_2 >= 0) {
            poke4_addr++;
            _1 = (int)*peek4_addr++;
            if (_1 < MININT || _1 > MAXINT)
            _1 = NewDouble((double)(long)_1);
            *(int *)poke4_addr = _1;
        }
    }
    _34295 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63484);
    _1 = *(int *)_2;
    *(int *)_2 = _34296;
    if( _1 != _34296 ){
        DeRef(_1);
    }
    _34296 = NOVALUE;

    /** 	pc += 3*/
    _67pc_63479 = _67pc_63479 + 3;

    /** end procedure*/
    _34291 = NOVALUE;
    _34293 = NOVALUE;
    return;
    ;
}


void _67opPEEK_STRING()
{
    int _34303 = NOVALUE;
    int _34302 = NOVALUE;
    int _34300 = NOVALUE;
    int _34298 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _34298 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _34298);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	target = Code[pc+2]*/
    _34300 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67target_63484 = (int)*(((s1_ptr)_2)->base + _34300);
    if (!IS_ATOM_INT(_67target_63484)){
        _67target_63484 = (long)DBL_PTR(_67target_63484)->dbl;
    }

    /** 	val[target] = peek_string(val[a])*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _34302 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    if (IS_ATOM_INT(_34302)) {
        _34303 =  NewString((char *)_34302);
    }
    else if (IS_ATOM(_34302)) {
        _34303 = NewString((char *)(unsigned long)(DBL_PTR(_34302)->dbl));
    }
    else {
        _1 = (int)SEQ_PTR(_34302);
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        poke4_addr = (unsigned long *)NewS1(_2);
        _34303 = MAKE_SEQ(poke4_addr);
        poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
        while (--_2 >= 0) {
            poke4_addr++;
            _1 = (int)*peek4_addr++;
            if ((unsigned)_1 > (unsigned)MAXINT)
            _1 = NewDouble((double)(unsigned long)_1);
            *(int *)poke4_addr = _1;
        }
    }
    _34302 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63484);
    _1 = *(int *)_2;
    *(int *)_2 = _34303;
    if( _1 != _34303 ){
        DeRef(_1);
    }
    _34303 = NOVALUE;

    /** 	pc += 3*/
    _67pc_63479 = _67pc_63479 + 3;

    /** end procedure*/
    _34298 = NOVALUE;
    _34300 = NOVALUE;
    return;
    ;
}


void _67opPEEK()
{
    int _34310 = NOVALUE;
    int _34309 = NOVALUE;
    int _34307 = NOVALUE;
    int _34305 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _34305 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _34305);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	target = Code[pc+2]*/
    _34307 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67target_63484 = (int)*(((s1_ptr)_2)->base + _34307);
    if (!IS_ATOM_INT(_67target_63484)){
        _67target_63484 = (long)DBL_PTR(_67target_63484)->dbl;
    }

    /** 	val[target] = peek(val[a])*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _34309 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    if (IS_ATOM_INT(_34309)) {
        _34310 = *(unsigned char *)_34309;
    }
    else if (IS_ATOM(_34309)) {
        _34310 = *(unsigned char *)(unsigned long)(DBL_PTR(_34309)->dbl);
    }
    else {
        _1 = (int)SEQ_PTR(_34309);
        poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        poke4_addr = (unsigned long *)NewS1(_2);
        _34310 = MAKE_SEQ(poke4_addr);
        poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
        while (--_2 >= 0) {
            poke4_addr++;
            _1 = (int)(unsigned char)*poke_addr++;
            *(int *)poke4_addr = _1;
        }
    }
    _34309 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63484);
    _1 = *(int *)_2;
    *(int *)_2 = _34310;
    if( _1 != _34310 ){
        DeRef(_1);
    }
    _34310 = NOVALUE;

    /** 	pc += 3*/
    _67pc_63479 = _67pc_63479 + 3;

    /** end procedure*/
    _34305 = NOVALUE;
    _34307 = NOVALUE;
    return;
    ;
}


void _67opPEEKS()
{
    int _34317 = NOVALUE;
    int _34316 = NOVALUE;
    int _34314 = NOVALUE;
    int _34312 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _34312 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _34312);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	target = Code[pc+2]*/
    _34314 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67target_63484 = (int)*(((s1_ptr)_2)->base + _34314);
    if (!IS_ATOM_INT(_67target_63484)){
        _67target_63484 = (long)DBL_PTR(_67target_63484)->dbl;
    }

    /** 	val[target] = peeks(val[a])*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _34316 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    if (IS_ATOM_INT(_34316)) {
        _34317 = *(signed char *)_34316;
    }
    else if (IS_ATOM(_34316)) {
        _34317 = *(signed char *)(unsigned long)(DBL_PTR(_34316)->dbl);
    }
    else {
        _1 = (int)SEQ_PTR(_34316);
        poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        poke4_addr = (unsigned long *)NewS1(_2);
        _34317 = MAKE_SEQ(poke4_addr);
        poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
        while (--_2 >= 0) {
            poke4_addr++;
            _1 = (int)(signed char)*poke_addr++;
            *(int *)poke4_addr = _1;
        }
    }
    _34316 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63484);
    _1 = *(int *)_2;
    *(int *)_2 = _34317;
    if( _1 != _34317 ){
        DeRef(_1);
    }
    _34317 = NOVALUE;

    /** 	pc += 3*/
    _67pc_63479 = _67pc_63479 + 3;

    /** end procedure*/
    _34312 = NOVALUE;
    _34314 = NOVALUE;
    return;
    ;
}


void _67opPOKE()
{
    int _34324 = NOVALUE;
    int _34323 = NOVALUE;
    int _34321 = NOVALUE;
    int _34319 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _34319 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _34319);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _34321 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67b_63481 = (int)*(((s1_ptr)_2)->base + _34321);
    if (!IS_ATOM_INT(_67b_63481)){
        _67b_63481 = (long)DBL_PTR(_67b_63481)->dbl;
    }

    /** 	poke(val[a], val[b])*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _34323 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    _2 = (int)SEQ_PTR(_67val_63489);
    _34324 = (int)*(((s1_ptr)_2)->base + _67b_63481);
    if (IS_ATOM_INT(_34323)){
        poke_addr = (unsigned char *)_34323;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_34323)->dbl);
    }
    if (IS_ATOM_INT(_34324)) {
        *poke_addr = (unsigned char)_34324;
    }
    else if (IS_ATOM(_34324)) {
        *poke_addr = (signed char)DBL_PTR(_34324)->dbl;
    }
    else {
        _1 = (int)SEQ_PTR(_34324);
        _1 = (int)((s1_ptr)_1)->base;
        while (1) {
            _1 += 4;
            _2 = *((int *)_1);
            if (IS_ATOM_INT(_2))
            *poke_addr++ = (unsigned char)_2;
            else if (_2 == NOVALUE)
            break;
            else {
                *poke_addr++ = (signed char)DBL_PTR(_2)->dbl;
            }
        }
    }
    _34323 = NOVALUE;
    _34324 = NOVALUE;

    /** 	pc += 3*/
    _67pc_63479 = _67pc_63479 + 3;

    /** end procedure*/
    _34319 = NOVALUE;
    _34321 = NOVALUE;
    return;
    ;
}


void _67opPOKE4()
{
    int _34331 = NOVALUE;
    int _34330 = NOVALUE;
    int _34328 = NOVALUE;
    int _34326 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _34326 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _34326);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _34328 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67b_63481 = (int)*(((s1_ptr)_2)->base + _34328);
    if (!IS_ATOM_INT(_67b_63481)){
        _67b_63481 = (long)DBL_PTR(_67b_63481)->dbl;
    }

    /** 	poke4(val[a], val[b])*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _34330 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    _2 = (int)SEQ_PTR(_67val_63489);
    _34331 = (int)*(((s1_ptr)_2)->base + _67b_63481);
    if (IS_ATOM_INT(_34330)){
        poke4_addr = (unsigned long *)_34330;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_34330)->dbl);
    }
    if (IS_ATOM_INT(_34331)) {
        *poke4_addr = (unsigned long)_34331;
    }
    else if (IS_ATOM(_34331)) {
        *poke4_addr = (unsigned long)DBL_PTR(_34331)->dbl;
    }
    else {
        _1 = (int)SEQ_PTR(_34331);
        _1 = (int)((s1_ptr)_1)->base;
        while (1) {
            _1 += 4;
            _2 = *((int *)_1);
            if (IS_ATOM_INT(_2))
            *(int *)poke4_addr++ = (unsigned long)_2;
            else if (_2 == NOVALUE)
            break;
            else {
                *(int *)poke4_addr++ = (unsigned long)DBL_PTR(_2)->dbl;
            }
        }
    }
    _34330 = NOVALUE;
    _34331 = NOVALUE;

    /** 	pc += 3*/
    _67pc_63479 = _67pc_63479 + 3;

    /** end procedure*/
    _34326 = NOVALUE;
    _34328 = NOVALUE;
    return;
    ;
}


void _67opPOKE2()
{
    int _34338 = NOVALUE;
    int _34337 = NOVALUE;
    int _34335 = NOVALUE;
    int _34333 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _34333 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _34333);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _34335 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67b_63481 = (int)*(((s1_ptr)_2)->base + _34335);
    if (!IS_ATOM_INT(_67b_63481)){
        _67b_63481 = (long)DBL_PTR(_67b_63481)->dbl;
    }

    /** 	poke2(val[a], val[b])*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _34337 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    _2 = (int)SEQ_PTR(_67val_63489);
    _34338 = (int)*(((s1_ptr)_2)->base + _67b_63481);
    if (IS_ATOM_INT(_34337)){
        poke2_addr = (unsigned short *)_34337;
    }
    else {
        poke2_addr = (unsigned short *)(unsigned long)(DBL_PTR(_34337)->dbl);
    }
    if (IS_ATOM_INT(_34338)) {
        *poke2_addr = (unsigned short)_34338;
    }
    else if (IS_ATOM(_34338)) {
        *poke_addr = (signed char)DBL_PTR(_34338)->dbl;
    }
    else {
        _1 = (int)SEQ_PTR(_34338);
        _1 = (int)((s1_ptr)_1)->base;
        while (1) {
            _1 += 4;
            _2 = *((int *)_1);
            if (IS_ATOM_INT(_2))
            *poke2_addr++ = (unsigned short)_2;
            else if (_2 == NOVALUE)
            break;
            else {
                *poke2_addr++ = (unsigned short)DBL_PTR(_2)->dbl;
            }
        }
    }
    _34337 = NOVALUE;
    _34338 = NOVALUE;

    /** 	pc += 3*/
    _67pc_63479 = _67pc_63479 + 3;

    /** end procedure*/
    _34333 = NOVALUE;
    _34335 = NOVALUE;
    return;
    ;
}


void _67opMEM_COPY()
{
    int _34348 = NOVALUE;
    int _34347 = NOVALUE;
    int _34346 = NOVALUE;
    int _34344 = NOVALUE;
    int _34342 = NOVALUE;
    int _34340 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _34340 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _34340);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _34342 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67b_63481 = (int)*(((s1_ptr)_2)->base + _34342);
    if (!IS_ATOM_INT(_67b_63481)){
        _67b_63481 = (long)DBL_PTR(_67b_63481)->dbl;
    }

    /** 	c = Code[pc+3]*/
    _34344 = _67pc_63479 + 3;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67c_63482 = (int)*(((s1_ptr)_2)->base + _34344);
    if (!IS_ATOM_INT(_67c_63482)){
        _67c_63482 = (long)DBL_PTR(_67c_63482)->dbl;
    }

    /** 	mem_copy(val[a], val[b], val[c])*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _34346 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    _2 = (int)SEQ_PTR(_67val_63489);
    _34347 = (int)*(((s1_ptr)_2)->base + _67b_63481);
    _2 = (int)SEQ_PTR(_67val_63489);
    _34348 = (int)*(((s1_ptr)_2)->base + _67c_63482);
    memory_copy(_34346, _34347, _34348);
    _34346 = NOVALUE;
    _34347 = NOVALUE;
    _34348 = NOVALUE;

    /** 	pc += 4*/
    _67pc_63479 = _67pc_63479 + 4;

    /** end procedure*/
    _34340 = NOVALUE;
    _34342 = NOVALUE;
    _34344 = NOVALUE;
    return;
    ;
}


void _67opMEM_SET()
{
    int _34358 = NOVALUE;
    int _34357 = NOVALUE;
    int _34356 = NOVALUE;
    int _34354 = NOVALUE;
    int _34352 = NOVALUE;
    int _34350 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _34350 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _34350);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _34352 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67b_63481 = (int)*(((s1_ptr)_2)->base + _34352);
    if (!IS_ATOM_INT(_67b_63481)){
        _67b_63481 = (long)DBL_PTR(_67b_63481)->dbl;
    }

    /** 	c = Code[pc+3]*/
    _34354 = _67pc_63479 + 3;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67c_63482 = (int)*(((s1_ptr)_2)->base + _34354);
    if (!IS_ATOM_INT(_67c_63482)){
        _67c_63482 = (long)DBL_PTR(_67c_63482)->dbl;
    }

    /** 	mem_set(val[a], val[b], val[c])*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _34356 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    _2 = (int)SEQ_PTR(_67val_63489);
    _34357 = (int)*(((s1_ptr)_2)->base + _67b_63481);
    _2 = (int)SEQ_PTR(_67val_63489);
    _34358 = (int)*(((s1_ptr)_2)->base + _67c_63482);
    memory_set(_34356, _34357, _34358);
    _34356 = NOVALUE;
    _34357 = NOVALUE;
    _34358 = NOVALUE;

    /** 	pc += 4*/
    _67pc_63479 = _67pc_63479 + 4;

    /** end procedure*/
    _34350 = NOVALUE;
    _34352 = NOVALUE;
    _34354 = NOVALUE;
    return;
    ;
}


void _67opCALL()
{
    int _34362 = NOVALUE;
    int _34360 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _34360 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _34360);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	call(val[a])*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _34362 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    if (IS_ATOM_INT(_34362))
    _0 = (int)_34362;
    else
    _0 = (int)(unsigned long)(DBL_PTR(_34362)->dbl);
    (*(void(*)())_0)();
    _34362 = NOVALUE;

    /** 	pc += 2*/
    _67pc_63479 = _67pc_63479 + 2;

    /** end procedure*/
    _34360 = NOVALUE;
    return;
    ;
}


void _67opSYSTEM()
{
    int _34375 = NOVALUE;
    int _34374 = NOVALUE;
    int _34372 = NOVALUE;
    int _34371 = NOVALUE;
    int _34369 = NOVALUE;
    int _34368 = NOVALUE;
    int _34366 = NOVALUE;
    int _34364 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _34364 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _34364);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _34366 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67b_63481 = (int)*(((s1_ptr)_2)->base + _34366);
    if (!IS_ATOM_INT(_67b_63481)){
        _67b_63481 = (long)DBL_PTR(_67b_63481)->dbl;
    }

    /** 	if atom(val[a]) then*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _34368 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    _34369 = IS_ATOM(_34368);
    _34368 = NOVALUE;
    if (_34369 == 0)
    {
        _34369 = NOVALUE;
        goto L1; // [46] 55
    }
    else{
        _34369 = NOVALUE;
    }

    /** 		RTFatal("first argument of system() must be a sequence")*/
    RefDS(_34370);
    _67RTFatal(_34370);
L1: 

    /** 	if sequence(val[b]) then*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _34371 = (int)*(((s1_ptr)_2)->base + _67b_63481);
    _34372 = IS_SEQUENCE(_34371);
    _34371 = NOVALUE;
    if (_34372 == 0)
    {
        _34372 = NOVALUE;
        goto L2; // [68] 77
    }
    else{
        _34372 = NOVALUE;
    }

    /** 		RTFatal("second argument of system() must be an atom")*/
    RefDS(_34373);
    _67RTFatal(_34373);
L2: 

    /** 	system(val[a], val[b])*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _34374 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    _2 = (int)SEQ_PTR(_67val_63489);
    _34375 = (int)*(((s1_ptr)_2)->base + _67b_63481);
    system_call(_34374, _34375);
    _34374 = NOVALUE;
    _34375 = NOVALUE;

    /** 	pc += 3*/
    _67pc_63479 = _67pc_63479 + 3;

    /** end procedure*/
    DeRef(_34364);
    _34364 = NOVALUE;
    DeRef(_34366);
    _34366 = NOVALUE;
    return;
    ;
}


void _67opSYSTEM_EXEC()
{
    int _34389 = NOVALUE;
    int _34388 = NOVALUE;
    int _34387 = NOVALUE;
    int _34386 = NOVALUE;
    int _34385 = NOVALUE;
    int _34384 = NOVALUE;
    int _34383 = NOVALUE;
    int _34381 = NOVALUE;
    int _34379 = NOVALUE;
    int _34377 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _34377 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _34377);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _34379 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67b_63481 = (int)*(((s1_ptr)_2)->base + _34379);
    if (!IS_ATOM_INT(_67b_63481)){
        _67b_63481 = (long)DBL_PTR(_67b_63481)->dbl;
    }

    /** 	target = Code[pc+3]*/
    _34381 = _67pc_63479 + 3;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67target_63484 = (int)*(((s1_ptr)_2)->base + _34381);
    if (!IS_ATOM_INT(_67target_63484)){
        _67target_63484 = (long)DBL_PTR(_67target_63484)->dbl;
    }

    /** 	if atom(val[a]) then*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _34383 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    _34384 = IS_ATOM(_34383);
    _34383 = NOVALUE;
    if (_34384 == 0)
    {
        _34384 = NOVALUE;
        goto L1; // [62] 71
    }
    else{
        _34384 = NOVALUE;
    }

    /** 		RTFatal("first argument of system() must be a sequence")*/
    RefDS(_34370);
    _67RTFatal(_34370);
L1: 

    /** 	if sequence(val[b]) then*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _34385 = (int)*(((s1_ptr)_2)->base + _67b_63481);
    _34386 = IS_SEQUENCE(_34385);
    _34385 = NOVALUE;
    if (_34386 == 0)
    {
        _34386 = NOVALUE;
        goto L2; // [84] 93
    }
    else{
        _34386 = NOVALUE;
    }

    /** 		RTFatal("second argument of system() must be an atom")*/
    RefDS(_34373);
    _67RTFatal(_34373);
L2: 

    /** 	val[target] = system_exec(val[a], val[b])*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _34387 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    _2 = (int)SEQ_PTR(_67val_63489);
    _34388 = (int)*(((s1_ptr)_2)->base + _67b_63481);
    _34389 = system_exec_call(_34387, _34388);
    _34387 = NOVALUE;
    _34388 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63484);
    _1 = *(int *)_2;
    *(int *)_2 = _34389;
    if( _1 != _34389 ){
        DeRef(_1);
    }
    _34389 = NOVALUE;

    /** 	pc += 4*/
    _67pc_63479 = _67pc_63479 + 4;

    /** end procedure*/
    DeRef(_34377);
    _34377 = NOVALUE;
    DeRef(_34379);
    _34379 = NOVALUE;
    DeRef(_34381);
    _34381 = NOVALUE;
    return;
    ;
}


void _67opOPEN()
{
    int _34416 = NOVALUE;
    int _34415 = NOVALUE;
    int _34414 = NOVALUE;
    int _34413 = NOVALUE;
    int _34410 = NOVALUE;
    int _34409 = NOVALUE;
    int _34407 = NOVALUE;
    int _34406 = NOVALUE;
    int _34404 = NOVALUE;
    int _34403 = NOVALUE;
    int _34402 = NOVALUE;
    int _34400 = NOVALUE;
    int _34399 = NOVALUE;
    int _34397 = NOVALUE;
    int _34395 = NOVALUE;
    int _34393 = NOVALUE;
    int _34391 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _34391 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _34391);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _34393 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67b_63481 = (int)*(((s1_ptr)_2)->base + _34393);
    if (!IS_ATOM_INT(_67b_63481)){
        _67b_63481 = (long)DBL_PTR(_67b_63481)->dbl;
    }

    /** 	c = Code[pc+3]*/
    _34395 = _67pc_63479 + 3;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67c_63482 = (int)*(((s1_ptr)_2)->base + _34395);
    if (!IS_ATOM_INT(_67c_63482)){
        _67c_63482 = (long)DBL_PTR(_67c_63482)->dbl;
    }

    /** 	target = Code[pc+4]*/
    _34397 = _67pc_63479 + 4;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67target_63484 = (int)*(((s1_ptr)_2)->base + _34397);
    if (!IS_ATOM_INT(_67target_63484)){
        _67target_63484 = (long)DBL_PTR(_67target_63484)->dbl;
    }

    /** 	if atom(val[b]) or length(val[b]) > 2 then*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _34399 = (int)*(((s1_ptr)_2)->base + _67b_63481);
    _34400 = IS_ATOM(_34399);
    _34399 = NOVALUE;
    if (_34400 != 0) {
        goto L1; // [78] 102
    }
    _2 = (int)SEQ_PTR(_67val_63489);
    _34402 = (int)*(((s1_ptr)_2)->base + _67b_63481);
    if (IS_SEQUENCE(_34402)){
            _34403 = SEQ_PTR(_34402)->length;
    }
    else {
        _34403 = 1;
    }
    _34402 = NOVALUE;
    _34404 = (_34403 > 2);
    _34403 = NOVALUE;
    if (_34404 == 0)
    {
        DeRef(_34404);
        _34404 = NOVALUE;
        goto L2; // [98] 108
    }
    else{
        DeRef(_34404);
        _34404 = NOVALUE;
    }
L1: 

    /** 	   RTFatal("invalid open mode")*/
    RefDS(_34405);
    _67RTFatal(_34405);
L2: 

    /** 	if atom(val[a]) then*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _34406 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    _34407 = IS_ATOM(_34406);
    _34406 = NOVALUE;
    if (_34407 == 0)
    {
        _34407 = NOVALUE;
        goto L3; // [121] 130
    }
    else{
        _34407 = NOVALUE;
    }

    /** 	   RTFatal("device or file name must be a sequence")*/
    RefDS(_34408);
    _67RTFatal(_34408);
L3: 

    /** 	if not atom(val[c]) then*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _34409 = (int)*(((s1_ptr)_2)->base + _67c_63482);
    _34410 = IS_ATOM(_34409);
    _34409 = NOVALUE;
    if (_34410 != 0)
    goto L4; // [143] 152
    _34410 = NOVALUE;

    /** 		RTFatal("cleanup must be an atom")*/
    RefDS(_34412);
    _67RTFatal(_34412);
L4: 

    /** 	val[target] = open(val[a], val[b], val[c])*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _34413 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    _2 = (int)SEQ_PTR(_67val_63489);
    _34414 = (int)*(((s1_ptr)_2)->base + _67b_63481);
    _2 = (int)SEQ_PTR(_67val_63489);
    _34415 = (int)*(((s1_ptr)_2)->base + _67c_63482);
    _34416 = EOpen(_34413, _34414, _34415);
    _34413 = NOVALUE;
    _34414 = NOVALUE;
    _34415 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63484);
    _1 = *(int *)_2;
    *(int *)_2 = _34416;
    if( _1 != _34416 ){
        DeRef(_1);
    }
    _34416 = NOVALUE;

    /** 	pc += 5*/
    _67pc_63479 = _67pc_63479 + 5;

    /** end procedure*/
    DeRef(_34391);
    _34391 = NOVALUE;
    DeRef(_34393);
    _34393 = NOVALUE;
    DeRef(_34395);
    _34395 = NOVALUE;
    DeRef(_34397);
    _34397 = NOVALUE;
    _34402 = NOVALUE;
    return;
    ;
}


void _67opCLOSE()
{
    int _34420 = NOVALUE;
    int _34418 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _34418 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _34418);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	close(val[a])*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _34420 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    if (IS_ATOM_INT(_34420))
    EClose(_34420);
    else
    EClose((int)DBL_PTR(_34420)->dbl);
    _34420 = NOVALUE;

    /** 	pc += 2*/
    _67pc_63479 = _67pc_63479 + 2;

    /** end procedure*/
    _34418 = NOVALUE;
    return;
    ;
}


void _67opABORT()
{
    int _34424 = NOVALUE;
    int _34423 = NOVALUE;
    int _34422 = NOVALUE;
    int _0, _1, _2;
    

    /** 	Cleanup(val[Code[pc+1]])*/
    _34422 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _34423 = (int)*(((s1_ptr)_2)->base + _34422);
    _2 = (int)SEQ_PTR(_67val_63489);
    if (!IS_ATOM_INT(_34423)){
        _34424 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_34423)->dbl));
    }
    else{
        _34424 = (int)*(((s1_ptr)_2)->base + _34423);
    }
    Ref(_34424);
    _43Cleanup(_34424);
    _34424 = NOVALUE;

    /** end procedure*/
    _34422 = NOVALUE;
    _34423 = NOVALUE;
    return;
    ;
}


void _67opGETC()
{
    int _34430 = NOVALUE;
    int _34429 = NOVALUE;
    int _34427 = NOVALUE;
    int _34425 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _34425 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _34425);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	target = Code[pc+2]*/
    _34427 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67target_63484 = (int)*(((s1_ptr)_2)->base + _34427);
    if (!IS_ATOM_INT(_67target_63484)){
        _67target_63484 = (long)DBL_PTR(_67target_63484)->dbl;
    }

    /** 	val[target] = getc(val[a])*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _34429 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    if (_34429 != last_r_file_no) {
        last_r_file_ptr = which_file(_34429, EF_READ);
        if (IS_ATOM_INT(_34429))
        last_r_file_no = _34429;
        else
        last_r_file_no = NOVALUE;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _34430 = getKBchar();
        }
        else
        _34430 = getc(last_r_file_ptr);
    }
    else
    _34430 = getc(last_r_file_ptr);
    _34429 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63484);
    _1 = *(int *)_2;
    *(int *)_2 = _34430;
    if( _1 != _34430 ){
        DeRef(_1);
    }
    _34430 = NOVALUE;

    /** 	pc += 3*/
    _67pc_63479 = _67pc_63479 + 3;

    /** end procedure*/
    _34425 = NOVALUE;
    _34427 = NOVALUE;
    return;
    ;
}


void _67opGETS()
{
    int _34437 = NOVALUE;
    int _34436 = NOVALUE;
    int _34434 = NOVALUE;
    int _34432 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _34432 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _34432);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	target = Code[pc+2]*/
    _34434 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67target_63484 = (int)*(((s1_ptr)_2)->base + _34434);
    if (!IS_ATOM_INT(_67target_63484)){
        _67target_63484 = (long)DBL_PTR(_67target_63484)->dbl;
    }

    /** 	val[target] = gets(val[a])*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _34436 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    _34437 = EGets(_34436);
    _34436 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63484);
    _1 = *(int *)_2;
    *(int *)_2 = _34437;
    if( _1 != _34437 ){
        DeRef(_1);
    }
    _34437 = NOVALUE;

    /** 	pc += 3*/
    _67pc_63479 = _67pc_63479 + 3;

    /** end procedure*/
    _34432 = NOVALUE;
    _34434 = NOVALUE;
    return;
    ;
}


void _67opGET_KEY()
{
    int _34441 = NOVALUE;
    int _34439 = NOVALUE;
    int _0, _1, _2;
    

    /** 	target = Code[pc+1]*/
    _34439 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67target_63484 = (int)*(((s1_ptr)_2)->base + _34439);
    if (!IS_ATOM_INT(_67target_63484)){
        _67target_63484 = (long)DBL_PTR(_67target_63484)->dbl;
    }

    /** 	val[target] = get_key()*/
    show_console();
    _34441 = get_key(0);
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63484);
    _1 = *(int *)_2;
    *(int *)_2 = _34441;
    if( _1 != _34441 ){
        DeRef(_1);
    }
    _34441 = NOVALUE;

    /** 	pc += 2*/
    _67pc_63479 = _67pc_63479 + 2;

    /** end procedure*/
    _34439 = NOVALUE;
    return;
    ;
}


void _67opCLEAR_SCREEN()
{
    int _0, _1, _2;
    

    /** 	clear_screen()*/
    ClearScreen();

    /** 	pc += 1*/
    _67pc_63479 = _67pc_63479 + 1;

    /** end procedure*/
    return;
    ;
}


void _67opPUTS()
{
    int _34449 = NOVALUE;
    int _34448 = NOVALUE;
    int _34446 = NOVALUE;
    int _34444 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _34444 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _34444);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _34446 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67b_63481 = (int)*(((s1_ptr)_2)->base + _34446);
    if (!IS_ATOM_INT(_67b_63481)){
        _67b_63481 = (long)DBL_PTR(_67b_63481)->dbl;
    }

    /** 	puts(val[a], val[b])*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _34448 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    _2 = (int)SEQ_PTR(_67val_63489);
    _34449 = (int)*(((s1_ptr)_2)->base + _67b_63481);
    EPuts(_34448, _34449); // DJP 
    _34448 = NOVALUE;
    _34449 = NOVALUE;

    /** 	pc += 3*/
    _67pc_63479 = _67pc_63479 + 3;

    /** end procedure*/
    _34444 = NOVALUE;
    _34446 = NOVALUE;
    return;
    ;
}


void _67opQPRINT()
{
    int _34453 = NOVALUE;
    int _34451 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+2]*/
    _34451 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _34451);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	? val[a]*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _34453 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    StdPrint(1, _34453, 1);
    _34453 = NOVALUE;

    /** 	pc += 3*/
    _67pc_63479 = _67pc_63479 + 3;

    /** end procedure*/
    _34451 = NOVALUE;
    return;
    ;
}


void _67opPRINT()
{
    int _34460 = NOVALUE;
    int _34459 = NOVALUE;
    int _34457 = NOVALUE;
    int _34455 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _34455 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _34455);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _34457 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67b_63481 = (int)*(((s1_ptr)_2)->base + _34457);
    if (!IS_ATOM_INT(_67b_63481)){
        _67b_63481 = (long)DBL_PTR(_67b_63481)->dbl;
    }

    /** 	print(val[a], val[b])*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _34459 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    _2 = (int)SEQ_PTR(_67val_63489);
    _34460 = (int)*(((s1_ptr)_2)->base + _67b_63481);
    StdPrint(_34459, _34460, 0);
    _34459 = NOVALUE;
    _34460 = NOVALUE;

    /** 	pc += 3*/
    _67pc_63479 = _67pc_63479 + 3;

    /** end procedure*/
    _34455 = NOVALUE;
    _34457 = NOVALUE;
    return;
    ;
}


void _67opPRINTF()
{
    int _34470 = NOVALUE;
    int _34469 = NOVALUE;
    int _34468 = NOVALUE;
    int _34466 = NOVALUE;
    int _34464 = NOVALUE;
    int _34462 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _34462 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _34462);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _34464 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67b_63481 = (int)*(((s1_ptr)_2)->base + _34464);
    if (!IS_ATOM_INT(_67b_63481)){
        _67b_63481 = (long)DBL_PTR(_67b_63481)->dbl;
    }

    /** 	c = Code[pc+3]*/
    _34466 = _67pc_63479 + 3;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67c_63482 = (int)*(((s1_ptr)_2)->base + _34466);
    if (!IS_ATOM_INT(_67c_63482)){
        _67c_63482 = (long)DBL_PTR(_67c_63482)->dbl;
    }

    /** 	printf(val[a], val[b], val[c])*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _34468 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    _2 = (int)SEQ_PTR(_67val_63489);
    _34469 = (int)*(((s1_ptr)_2)->base + _67b_63481);
    _2 = (int)SEQ_PTR(_67val_63489);
    _34470 = (int)*(((s1_ptr)_2)->base + _67c_63482);
    EPrintf(_34468, _34469, _34470);
    _34468 = NOVALUE;
    _34469 = NOVALUE;
    _34470 = NOVALUE;

    /** 	pc += 4*/
    _67pc_63479 = _67pc_63479 + 4;

    /** end procedure*/
    _34462 = NOVALUE;
    _34464 = NOVALUE;
    _34466 = NOVALUE;
    return;
    ;
}


void _67opSPRINTF()
{
    int _34480 = NOVALUE;
    int _34479 = NOVALUE;
    int _34478 = NOVALUE;
    int _34476 = NOVALUE;
    int _34474 = NOVALUE;
    int _34472 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _34472 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _34472);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _34474 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67b_63481 = (int)*(((s1_ptr)_2)->base + _34474);
    if (!IS_ATOM_INT(_67b_63481)){
        _67b_63481 = (long)DBL_PTR(_67b_63481)->dbl;
    }

    /** 	target = Code[pc+3]*/
    _34476 = _67pc_63479 + 3;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67target_63484 = (int)*(((s1_ptr)_2)->base + _34476);
    if (!IS_ATOM_INT(_67target_63484)){
        _67target_63484 = (long)DBL_PTR(_67target_63484)->dbl;
    }

    /** 	val[target] = sprintf(val[a], val[b])*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _34478 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    _2 = (int)SEQ_PTR(_67val_63489);
    _34479 = (int)*(((s1_ptr)_2)->base + _67b_63481);
    _34480 = EPrintf(-9999999, _34478, _34479);
    _34478 = NOVALUE;
    _34479 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63484);
    _1 = *(int *)_2;
    *(int *)_2 = _34480;
    if( _1 != _34480 ){
        DeRef(_1);
    }
    _34480 = NOVALUE;

    /** 	pc += 4*/
    _67pc_63479 = _67pc_63479 + 4;

    /** end procedure*/
    _34472 = NOVALUE;
    _34474 = NOVALUE;
    _34476 = NOVALUE;
    return;
    ;
}


void _67opCOMMAND_LINE()
{
    int _cmd_68016 = NOVALUE;
    int _34490 = NOVALUE;
    int _34489 = NOVALUE;
    int _34488 = NOVALUE;
    int _34487 = NOVALUE;
    int _34485 = NOVALUE;
    int _34482 = NOVALUE;
    int _0, _1, _2;
    

    /** 	target = Code[pc+1]*/
    _34482 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67target_63484 = (int)*(((s1_ptr)_2)->base + _34482);
    if (!IS_ATOM_INT(_67target_63484)){
        _67target_63484 = (long)DBL_PTR(_67target_63484)->dbl;
    }

    /** 	cmd = command_line()*/
    DeRef(_cmd_68016);
    _cmd_68016 = Command_Line();

    /** 	if length(cmd) > 2 then*/
    if (IS_SEQUENCE(_cmd_68016)){
            _34485 = SEQ_PTR(_cmd_68016)->length;
    }
    else {
        _34485 = 1;
    }
    if (_34485 <= 2)
    goto L1; // [26] 53

    /** 		cmd = {cmd[1]} & cmd[3..$]*/
    _2 = (int)SEQ_PTR(_cmd_68016);
    _34487 = (int)*(((s1_ptr)_2)->base + 1);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_34487);
    *((int *)(_2+4)) = _34487;
    _34488 = MAKE_SEQ(_1);
    _34487 = NOVALUE;
    if (IS_SEQUENCE(_cmd_68016)){
            _34489 = SEQ_PTR(_cmd_68016)->length;
    }
    else {
        _34489 = 1;
    }
    rhs_slice_target = (object_ptr)&_34490;
    RHS_Slice(_cmd_68016, 3, _34489);
    Concat((object_ptr)&_cmd_68016, _34488, _34490);
    DeRefDS(_34488);
    _34488 = NOVALUE;
    DeRef(_34488);
    _34488 = NOVALUE;
    DeRefDS(_34490);
    _34490 = NOVALUE;
L1: 

    /** 	val[target] = cmd*/
    RefDS(_cmd_68016);
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63484);
    _1 = *(int *)_2;
    *(int *)_2 = _cmd_68016;
    DeRef(_1);

    /** 	pc += 2*/
    _67pc_63479 = _67pc_63479 + 2;

    /** end procedure*/
    DeRefDS(_cmd_68016);
    DeRef(_34482);
    _34482 = NOVALUE;
    return;
    ;
}


void _67opOPTION_SWITCHES()
{
    int _cmd_68032 = NOVALUE;
    int _34493 = NOVALUE;
    int _0, _1, _2;
    

    /** 	target = Code[pc+1]*/
    _34493 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67target_63484 = (int)*(((s1_ptr)_2)->base + _34493);
    if (!IS_ATOM_INT(_67target_63484)){
        _67target_63484 = (long)DBL_PTR(_67target_63484)->dbl;
    }

    /** 	cmd = option_switches()*/
    DeRef(_cmd_68032);
    RefDS(_0switches);
    _cmd_68032 = _0switches;

    /** 	val[target] = cmd*/
    RefDS(_cmd_68032);
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63484);
    _1 = *(int *)_2;
    *(int *)_2 = _cmd_68032;
    DeRef(_1);

    /** 	pc += 2*/
    _67pc_63479 = _67pc_63479 + 2;

    /** end procedure*/
    DeRefDS(_cmd_68032);
    _34493 = NOVALUE;
    return;
    ;
}


void _67opGETENV()
{
    int _34505 = NOVALUE;
    int _34504 = NOVALUE;
    int _34502 = NOVALUE;
    int _34501 = NOVALUE;
    int _34499 = NOVALUE;
    int _34497 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _34497 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _34497);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	target = Code[pc+2]*/
    _34499 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67target_63484 = (int)*(((s1_ptr)_2)->base + _34499);
    if (!IS_ATOM_INT(_67target_63484)){
        _67target_63484 = (long)DBL_PTR(_67target_63484)->dbl;
    }

    /** 	if atom(val[a]) then*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _34501 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    _34502 = IS_ATOM(_34501);
    _34501 = NOVALUE;
    if (_34502 == 0)
    {
        _34502 = NOVALUE;
        goto L1; // [46] 55
    }
    else{
        _34502 = NOVALUE;
    }

    /** 		RTFatal("argument to getenv must be a sequence")*/
    RefDS(_34503);
    _67RTFatal(_34503);
L1: 

    /** 	val[target] = getenv(val[a])*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _34504 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    _34505 = EGetEnv(_34504);
    _34504 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63484);
    _1 = *(int *)_2;
    *(int *)_2 = _34505;
    if( _1 != _34505 ){
        DeRef(_1);
    }
    _34505 = NOVALUE;

    /** 	pc += 3*/
    _67pc_63479 = _67pc_63479 + 3;

    /** end procedure*/
    DeRef(_34497);
    _34497 = NOVALUE;
    DeRef(_34499);
    _34499 = NOVALUE;
    return;
    ;
}


void _67opC_PROC()
{
    int _sub_68056 = NOVALUE;
    int _34514 = NOVALUE;
    int _34513 = NOVALUE;
    int _34511 = NOVALUE;
    int _34509 = NOVALUE;
    int _34507 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _34507 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _34507);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _34509 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67b_63481 = (int)*(((s1_ptr)_2)->base + _34509);
    if (!IS_ATOM_INT(_67b_63481)){
        _67b_63481 = (long)DBL_PTR(_67b_63481)->dbl;
    }

    /** 	sub = Code[pc+3]*/
    _34511 = _67pc_63479 + 3;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _sub_68056 = (int)*(((s1_ptr)_2)->base + _34511);
    if (!IS_ATOM_INT(_sub_68056)){
        _sub_68056 = (long)DBL_PTR(_sub_68056)->dbl;
    }

    /** 	c_proc(val[a], val[b])  -- callback could happen here*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _34513 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    _2 = (int)SEQ_PTR(_67val_63489);
    _34514 = (int)*(((s1_ptr)_2)->base + _67b_63481);
    call_c(0, _34513, _34514);
    _34513 = NOVALUE;
    _34514 = NOVALUE;

    /** 	restore_privates(sub)*/
    _67restore_privates(_sub_68056);

    /** 	pc += 4*/
    _67pc_63479 = _67pc_63479 + 4;

    /** end procedure*/
    _34507 = NOVALUE;
    _34509 = NOVALUE;
    _34511 = NOVALUE;
    return;
    ;
}


void _67opC_FUNC()
{
    int _target_68071 = NOVALUE;
    int _sub_68073 = NOVALUE;
    int _temp_68074 = NOVALUE;
    int _34525 = NOVALUE;
    int _34524 = NOVALUE;
    int _34522 = NOVALUE;
    int _34520 = NOVALUE;
    int _34518 = NOVALUE;
    int _34516 = NOVALUE;
    int _0, _1, _2;
    

    /** 	object temp*/

    /** 	a = Code[pc+1]*/
    _34516 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _34516);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _34518 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67b_63481 = (int)*(((s1_ptr)_2)->base + _34518);
    if (!IS_ATOM_INT(_67b_63481)){
        _67b_63481 = (long)DBL_PTR(_67b_63481)->dbl;
    }

    /** 	sub = Code[pc+3]*/
    _34520 = _67pc_63479 + 3;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _sub_68073 = (int)*(((s1_ptr)_2)->base + _34520);
    if (!IS_ATOM_INT(_sub_68073)){
        _sub_68073 = (long)DBL_PTR(_sub_68073)->dbl;
    }

    /** 	target = Code[pc+4]*/
    _34522 = _67pc_63479 + 4;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _target_68071 = (int)*(((s1_ptr)_2)->base + _34522);
    if (!IS_ATOM_INT(_target_68071)){
        _target_68071 = (long)DBL_PTR(_target_68071)->dbl;
    }

    /** 	temp = c_func(val[a], val[b])  -- callback could happen here*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _34524 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    _2 = (int)SEQ_PTR(_67val_63489);
    _34525 = (int)*(((s1_ptr)_2)->base + _67b_63481);
    DeRef(_temp_68074);
    _temp_68074 = call_c(1, _34524, _34525);
    _34524 = NOVALUE;
    _34525 = NOVALUE;

    /** 	restore_privates(sub)*/
    _67restore_privates(_sub_68073);

    /** 	val[target] = temp*/
    Ref(_temp_68074);
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _target_68071);
    _1 = *(int *)_2;
    *(int *)_2 = _temp_68074;
    DeRef(_1);

    /** 	pc += 5*/
    _67pc_63479 = _67pc_63479 + 5;

    /** end procedure*/
    DeRef(_temp_68074);
    _34516 = NOVALUE;
    _34518 = NOVALUE;
    _34520 = NOVALUE;
    _34522 = NOVALUE;
    return;
    ;
}


void _67opTRACE()
{
    int _34529 = NOVALUE;
    int _34528 = NOVALUE;
    int _0, _1, _2;
    

    /** 	TraceOn = val[Code[pc+1]]*/
    _34528 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _34529 = (int)*(((s1_ptr)_2)->base + _34528);
    _2 = (int)SEQ_PTR(_67val_63489);
    if (!IS_ATOM_INT(_34529)){
        _67TraceOn_63477 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_34529)->dbl));
    }
    else{
        _67TraceOn_63477 = (int)*(((s1_ptr)_2)->base + _34529);
    }
    if (!IS_ATOM_INT(_67TraceOn_63477))
    _67TraceOn_63477 = (long)DBL_PTR(_67TraceOn_63477)->dbl;

    /** 	pc += 2  -- turn on/off tracing*/
    _67pc_63479 = _67pc_63479 + 2;

    /** end procedure*/
    _34528 = NOVALUE;
    _34529 = NOVALUE;
    return;
    ;
}


void _67opPROFILE()
{
    int _0, _1, _2;
    

    /** 	pc += 2*/
    _67pc_63479 = _67pc_63479 + 2;

    /** end procedure*/
    return;
    ;
}


void _67opUPDATE_GLOBALS()
{
    int _0, _1, _2;
    

    /** 	pc += 1*/
    _67pc_63479 = _67pc_63479 + 1;

    /** end procedure*/
    return;
    ;
}


int _67general_callback(int _rtn_def_68106, int _args_68107)
{
    int _arglist_assign_68109 = NOVALUE;
    int _34551 = NOVALUE;
    int _34549 = NOVALUE;
    int _34548 = NOVALUE;
    int _34547 = NOVALUE;
    int _34544 = NOVALUE;
    int _34543 = NOVALUE;
    int _34541 = NOVALUE;
    int _34540 = NOVALUE;
    int _34536 = NOVALUE;
    int _34534 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	val[t_id] = rtn_def[C_USER_ROUTINE]*/
    _2 = (int)SEQ_PTR(_rtn_def_68106);
    _34534 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_34534);
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67t_id_63410);
    _1 = *(int *)_2;
    *(int *)_2 = _34534;
    if( _1 != _34534 ){
        DeRef(_1);
    }
    _34534 = NOVALUE;

    /** 	val[t_arglist] = args*/
    RefDS(_args_68107);
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67t_arglist_63411);
    _1 = *(int *)_2;
    *(int *)_2 = _args_68107;
    DeRef(_1);

    /** 	atom arglist_assign = new_arg_assign()*/
    _0 = _arglist_assign_68109;
    _arglist_assign_68109 = _67new_arg_assign();
    DeRef(_0);

    /** 	SymTab[call_back_routine][S_RESIDENT_TASK] = current_task*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_67call_back_routine_63413 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 25);
    _1 = *(int *)_2;
    *(int *)_2 = _67current_task_63496;
    DeRef(_1);
    _34536 = NOVALUE;

    /** 	call_stack = append(call_stack, pc)*/
    Append(&_67call_stack_63497, _67call_stack_63497, _67pc_63479);

    /** 	call_stack = append(call_stack, call_back_routine)*/
    Append(&_67call_stack_63497, _67call_stack_63497, _67call_back_routine_63413);

    /** 	Code = call_back_code*/
    RefDS(_67call_back_code_63407);
    DeRef(_26Code_12071);
    _26Code_12071 = _67call_back_code_63407;

    /** 	pc = 1*/
    _67pc_63479 = 1;

    /** 	do_exec()*/
    _67do_exec();

    /** 	pc = call_stack[$-1]*/
    if (IS_SEQUENCE(_67call_stack_63497)){
            _34540 = SEQ_PTR(_67call_stack_63497)->length;
    }
    else {
        _34540 = 1;
    }
    _34541 = _34540 - 1;
    _34540 = NOVALUE;
    _2 = (int)SEQ_PTR(_67call_stack_63497);
    _67pc_63479 = (int)*(((s1_ptr)_2)->base + _34541);
    if (!IS_ATOM_INT(_67pc_63479))
    _67pc_63479 = (long)DBL_PTR(_67pc_63479)->dbl;

    /** 	call_stack = call_stack[1..$-2]*/
    if (IS_SEQUENCE(_67call_stack_63497)){
            _34543 = SEQ_PTR(_67call_stack_63497)->length;
    }
    else {
        _34543 = 1;
    }
    _34544 = _34543 - 2;
    _34543 = NOVALUE;
    rhs_slice_target = (object_ptr)&_67call_stack_63497;
    RHS_Slice(_67call_stack_63497, 1, _34544);

    /** 	if arglist_assign = arg_assign then*/
    if (binary_op_a(NOTEQ, _arglist_assign_68109, _67arg_assign_63423)){
        goto L1; // [126] 143
    }

    /** 		val[t_arglist] = NOVALUE*/
    Ref(_26NOVALUE_11836);
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67t_arglist_63411);
    _1 = *(int *)_2;
    *(int *)_2 = _26NOVALUE_11836;
    DeRef(_1);
L1: 

    /** 	Code = SymTab[call_stack[$]][S_CODE]*/
    if (IS_SEQUENCE(_67call_stack_63497)){
            _34547 = SEQ_PTR(_67call_stack_63497)->length;
    }
    else {
        _34547 = 1;
    }
    _2 = (int)SEQ_PTR(_67call_stack_63497);
    _34548 = (int)*(((s1_ptr)_2)->base + _34547);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!IS_ATOM_INT(_34548)){
        _34549 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_34548)->dbl));
    }
    else{
        _34549 = (int)*(((s1_ptr)_2)->base + _34548);
    }
    DeRef(_26Code_12071);
    _2 = (int)SEQ_PTR(_34549);
    if (!IS_ATOM_INT(_26S_CODE_11666)){
        _26Code_12071 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_CODE_11666)->dbl));
    }
    else{
        _26Code_12071 = (int)*(((s1_ptr)_2)->base + _26S_CODE_11666);
    }
    Ref(_26Code_12071);
    _34549 = NOVALUE;

    /** 	return val[t_return_val]*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _34551 = (int)*(((s1_ptr)_2)->base + _67t_return_val_63412);
    Ref(_34551);
    DeRefDS(_rtn_def_68106);
    DeRefDS(_args_68107);
    DeRef(_arglist_assign_68109);
    DeRef(_34541);
    _34541 = NOVALUE;
    DeRef(_34544);
    _34544 = NOVALUE;
    _34548 = NOVALUE;
    return _34551;
    ;
}


int _67machine_callback(int _cbx_68140, int _ptr_68141)
{
    int _rtn_def_68142 = NOVALUE;
    int _args_68143 = NOVALUE;
    int _34559 = NOVALUE;
    int _34557 = NOVALUE;
    int _34556 = NOVALUE;
    int _34555 = NOVALUE;
    int _0, _1, _2;
    

    /** 	rtn_def = call_backs[cbx]*/
    DeRef(_rtn_def_68142);
    _2 = (int)SEQ_PTR(_67call_backs_63406);
    if (!IS_ATOM_INT(_cbx_68140)){
        _rtn_def_68142 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_cbx_68140)->dbl));
    }
    else{
        _rtn_def_68142 = (int)*(((s1_ptr)_2)->base + _cbx_68140);
    }
    RefDS(_rtn_def_68142);

    /** 	args = peek4u(ptr & call_backs[cbx][C_NUM_ARGS])*/
    _2 = (int)SEQ_PTR(_67call_backs_63406);
    if (!IS_ATOM_INT(_cbx_68140)){
        _34555 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_cbx_68140)->dbl));
    }
    else{
        _34555 = (int)*(((s1_ptr)_2)->base + _cbx_68140);
    }
    _2 = (int)SEQ_PTR(_34555);
    _34556 = (int)*(((s1_ptr)_2)->base + 3);
    _34555 = NOVALUE;
    if (IS_SEQUENCE(_ptr_68141) && IS_ATOM(_34556)) {
    }
    else if (IS_ATOM(_ptr_68141) && IS_SEQUENCE(_34556)) {
        Ref(_ptr_68141);
        Prepend(&_34557, _34556, _ptr_68141);
    }
    else {
        Concat((object_ptr)&_34557, _ptr_68141, _34556);
    }
    _34556 = NOVALUE;
    DeRef(_args_68143);
    _1 = (int)SEQ_PTR(_34557);
    peek4_addr = (unsigned long *)get_pos_int("peek4s/peek4u", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _args_68143 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)*peek4_addr++;
        if ((unsigned)_1 > (unsigned)MAXINT)
        _1 = NewDouble((double)(unsigned long)_1);
        *(int *)poke4_addr = _1;
    }
    DeRefDS(_34557);
    _34557 = NOVALUE;

    /** 	return general_callback(rtn_def, args)*/
    RefDS(_rtn_def_68142);
    RefDS(_args_68143);
    _34559 = _67general_callback(_rtn_def_68142, _args_68143);
    DeRef(_cbx_68140);
    DeRef(_ptr_68141);
    DeRefDS(_rtn_def_68142);
    DeRefDS(_args_68143);
    return _34559;
    ;
}


int _67callback(int _a_68158)
{
    int _34563 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return machine_func(M_CALL_BACK, a)*/
    _34563 = machine(52, _a_68158);
    DeRefi(_a_68158);
    return _34563;
    ;
}


void _67do_callback(int _b_68162)
{
    int _r_68164 = NOVALUE;
    int _asm_68165 = NOVALUE;
    int _id_68166 = NOVALUE;
    int _convention_68167 = NOVALUE;
    int _x_68168 = NOVALUE;
    int _34624 = NOVALUE;
    int _34623 = NOVALUE;
    int _34622 = NOVALUE;
    int _34621 = NOVALUE;
    int _34620 = NOVALUE;
    int _34619 = NOVALUE;
    int _34618 = NOVALUE;
    int _34617 = NOVALUE;
    int _34616 = NOVALUE;
    int _34615 = NOVALUE;
    int _34614 = NOVALUE;
    int _34613 = NOVALUE;
    int _34611 = NOVALUE;
    int _34592 = NOVALUE;
    int _34591 = NOVALUE;
    int _34589 = NOVALUE;
    int _34588 = NOVALUE;
    int _34587 = NOVALUE;
    int _34586 = NOVALUE;
    int _34585 = NOVALUE;
    int _34584 = NOVALUE;
    int _34583 = NOVALUE;
    int _34582 = NOVALUE;
    int _34581 = NOVALUE;
    int _34580 = NOVALUE;
    int _34578 = NOVALUE;
    int _34577 = NOVALUE;
    int _34576 = NOVALUE;
    int _34575 = NOVALUE;
    int _34573 = NOVALUE;
    int _34571 = NOVALUE;
    int _34570 = NOVALUE;
    int _34568 = NOVALUE;
    int _34565 = NOVALUE;
    int _0, _1, _2;
    

    /** 	atom asm*/

    /** 	integer id, convention*/

    /** 	object x*/

    /** 	x = val[b]*/
    DeRef(_x_68168);
    _2 = (int)SEQ_PTR(_67val_63489);
    _x_68168 = (int)*(((s1_ptr)_2)->base + _b_68162);
    Ref(_x_68168);

    /** 	if atom(x) then*/
    _34565 = IS_ATOM(_x_68168);
    if (_34565 == 0)
    {
        _34565 = NOVALUE;
        goto L1; // [22] 40
    }
    else{
        _34565 = NOVALUE;
    }

    /** 		id = x*/
    Ref(_x_68168);
    _id_68166 = _x_68168;
    if (!IS_ATOM_INT(_id_68166)) {
        _1 = (long)(DBL_PTR(_id_68166)->dbl);
        DeRefDS(_id_68166);
        _id_68166 = _1;
    }

    /** 		convention = 0*/
    _convention_68167 = 0;
    goto L2; // [37] 57
L1: 

    /** 		id = x[2]*/
    _2 = (int)SEQ_PTR(_x_68168);
    _id_68166 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_id_68166)){
        _id_68166 = (long)DBL_PTR(_id_68166)->dbl;
    }

    /** 		convention = x[1]*/
    _2 = (int)SEQ_PTR(_x_68168);
    _convention_68167 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_convention_68167)){
        _convention_68167 = (long)DBL_PTR(_convention_68167)->dbl;
    }
L2: 

    /** 	if id < 0 or id >= length(e_routine) then*/
    _34568 = (_id_68166 < 0);
    if (_34568 != 0) {
        goto L3; // [65] 83
    }
    if (IS_SEQUENCE(_67e_routine_63527)){
            _34570 = SEQ_PTR(_67e_routine_63527)->length;
    }
    else {
        _34570 = 1;
    }
    _34571 = (_id_68166 >= _34570);
    _34570 = NOVALUE;
    if (_34571 == 0)
    {
        DeRef(_34571);
        _34571 = NOVALUE;
        goto L4; // [79] 89
    }
    else{
        DeRef(_34571);
        _34571 = NOVALUE;
    }
L3: 

    /** 		RTFatal("Invalid routine id")*/
    RefDS(_34572);
    _67RTFatal(_34572);
L4: 

    /** 	r = e_routine[id+1]*/
    _34573 = _id_68166 + 1;
    _2 = (int)SEQ_PTR(_67e_routine_63527);
    _r_68164 = (int)*(((s1_ptr)_2)->base + _34573);

    /** 	if platform() = WIN32 and convention = 0 then*/
    _34575 = (2 == 2);
    if (_34575 == 0) {
        goto L5; // [111] 224
    }
    _34577 = (_convention_68167 == 0);
    if (_34577 == 0)
    {
        DeRef(_34577);
        _34577 = NOVALUE;
        goto L5; // [122] 224
    }
    else{
        DeRef(_34577);
        _34577 = NOVALUE;
    }

    /** 		asm = dep:allocate_protect(length(cb_std), 1, PAGE_EXECUTE_READWRITE)*/
    _34578 = 24;
    _0 = _asm_68165;
    _asm_68165 = _6allocate_protect(24, 1, 64);
    DeRef(_0);
    _34578 = NOVALUE;

    /** 		poke( asm, cb_std )*/
    if (IS_ATOM_INT(_asm_68165)){
        poke_addr = (unsigned char *)_asm_68165;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_asm_68165)->dbl);
    }
    _1 = (int)SEQ_PTR(_67cb_std_68150);
    _1 = (int)((s1_ptr)_1)->base;
    while (1) {
        _1 += 4;
        _2 = *((int *)_1);
        if (IS_ATOM_INT(_2))
        *poke_addr++ = (unsigned char)_2;
        else if (_2 == NOVALUE)
        break;
        else {
            *poke_addr++ = (signed char)DBL_PTR(_2)->dbl;
        }
    }

    /** 		poke4( asm + 7, length(call_backs) + 1 )*/
    if (IS_ATOM_INT(_asm_68165)) {
        _34580 = _asm_68165 + 7;
        if ((long)((unsigned long)_34580 + (unsigned long)HIGH_BITS) >= 0) 
        _34580 = NewDouble((double)_34580);
    }
    else {
        _34580 = NewDouble(DBL_PTR(_asm_68165)->dbl + (double)7);
    }
    if (IS_SEQUENCE(_67call_backs_63406)){
            _34581 = SEQ_PTR(_67call_backs_63406)->length;
    }
    else {
        _34581 = 1;
    }
    _34582 = _34581 + 1;
    _34581 = NOVALUE;
    if (IS_ATOM_INT(_34580)){
        poke4_addr = (unsigned long *)_34580;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_34580)->dbl);
    }
    *poke4_addr = (unsigned long)_34582;
    DeRef(_34580);
    _34580 = NOVALUE;
    _34582 = NOVALUE;

    /** 		poke4( asm + 13, asm + 20 )*/
    if (IS_ATOM_INT(_asm_68165)) {
        _34583 = _asm_68165 + 13;
        if ((long)((unsigned long)_34583 + (unsigned long)HIGH_BITS) >= 0) 
        _34583 = NewDouble((double)_34583);
    }
    else {
        _34583 = NewDouble(DBL_PTR(_asm_68165)->dbl + (double)13);
    }
    if (IS_ATOM_INT(_asm_68165)) {
        _34584 = _asm_68165 + 20;
        if ((long)((unsigned long)_34584 + (unsigned long)HIGH_BITS) >= 0) 
        _34584 = NewDouble((double)_34584);
    }
    else {
        _34584 = NewDouble(DBL_PTR(_asm_68165)->dbl + (double)20);
    }
    if (IS_ATOM_INT(_34583)){
        poke4_addr = (unsigned long *)_34583;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_34583)->dbl);
    }
    if (IS_ATOM_INT(_34584)) {
        *poke4_addr = (unsigned long)_34584;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_34584)->dbl;
    }
    DeRef(_34583);
    _34583 = NOVALUE;
    DeRef(_34584);
    _34584 = NOVALUE;

    /** 		poke( asm + 18, SymTab[r][S_NUM_ARGS] * 4 )*/
    if (IS_ATOM_INT(_asm_68165)) {
        _34585 = _asm_68165 + 18;
        if ((long)((unsigned long)_34585 + (unsigned long)HIGH_BITS) >= 0) 
        _34585 = NewDouble((double)_34585);
    }
    else {
        _34585 = NewDouble(DBL_PTR(_asm_68165)->dbl + (double)18);
    }
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _34586 = (int)*(((s1_ptr)_2)->base + _r_68164);
    _2 = (int)SEQ_PTR(_34586);
    if (!IS_ATOM_INT(_26S_NUM_ARGS_11705)){
        _34587 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NUM_ARGS_11705)->dbl));
    }
    else{
        _34587 = (int)*(((s1_ptr)_2)->base + _26S_NUM_ARGS_11705);
    }
    _34586 = NOVALUE;
    if (IS_ATOM_INT(_34587)) {
        if (_34587 == (short)_34587)
        _34588 = _34587 * 4;
        else
        _34588 = NewDouble(_34587 * (double)4);
    }
    else {
        _34588 = binary_op(MULTIPLY, _34587, 4);
    }
    _34587 = NOVALUE;
    if (IS_ATOM_INT(_34585)){
        poke_addr = (unsigned char *)_34585;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_34585)->dbl);
    }
    if (IS_ATOM_INT(_34588)) {
        *poke_addr = (unsigned char)_34588;
    }
    else if (IS_ATOM(_34588)) {
        *poke_addr = (signed char)DBL_PTR(_34588)->dbl;
    }
    else {
        _1 = (int)SEQ_PTR(_34588);
        _1 = (int)((s1_ptr)_1)->base;
        while (1) {
            _1 += 4;
            _2 = *((int *)_1);
            if (IS_ATOM_INT(_2))
            *poke_addr++ = (unsigned char)_2;
            else if (_2 == NOVALUE)
            break;
            else {
                *poke_addr++ = (signed char)DBL_PTR(_2)->dbl;
            }
        }
    }
    DeRef(_34585);
    _34585 = NOVALUE;
    DeRef(_34588);
    _34588 = NOVALUE;

    /** 		poke4( asm + 20, callback( routine_id("machine_callback") ) )*/
    if (IS_ATOM_INT(_asm_68165)) {
        _34589 = _asm_68165 + 20;
        if ((long)((unsigned long)_34589 + (unsigned long)HIGH_BITS) >= 0) 
        _34589 = NewDouble((double)_34589);
    }
    else {
        _34589 = NewDouble(DBL_PTR(_asm_68165)->dbl + (double)20);
    }
    _34591 = CRoutineId(1544, 67, _34590);
    _34592 = _67callback(_34591);
    _34591 = NOVALUE;
    if (IS_ATOM_INT(_34589)){
        poke4_addr = (unsigned long *)_34589;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_34589)->dbl);
    }
    if (IS_ATOM_INT(_34592)) {
        *poke4_addr = (unsigned long)_34592;
    }
    else if (IS_ATOM(_34592)) {
        *poke4_addr = (unsigned long)DBL_PTR(_34592)->dbl;
    }
    else {
        _1 = (int)SEQ_PTR(_34592);
        _1 = (int)((s1_ptr)_1)->base;
        while (1) {
            _1 += 4;
            _2 = *((int *)_1);
            if (IS_ATOM_INT(_2))
            *(int *)poke4_addr++ = (unsigned long)_2;
            else if (_2 == NOVALUE)
            break;
            else {
                *(int *)poke4_addr++ = (unsigned long)DBL_PTR(_2)->dbl;
            }
        }
    }
    DeRef(_34589);
    _34589 = NOVALUE;
    DeRef(_34592);
    _34592 = NOVALUE;
    goto L6; // [221] 409
L5: 

    /** 	elsif platform() = OSX then*/

    /** 		asm = dep:allocate_protect(length(cb_cdecl), 1, PAGE_EXECUTE_READWRITE)*/
    _34611 = 27;
    _0 = _asm_68165;
    _asm_68165 = _6allocate_protect(27, 1, 64);
    DeRef(_0);
    _34611 = NOVALUE;

    /** 		poke( asm, cb_cdecl )*/
    if (IS_ATOM_INT(_asm_68165)){
        poke_addr = (unsigned char *)_asm_68165;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_asm_68165)->dbl);
    }
    _1 = (int)SEQ_PTR(_67cb_cdecl_68152);
    _1 = (int)((s1_ptr)_1)->base;
    while (1) {
        _1 += 4;
        _2 = *((int *)_1);
        if (IS_ATOM_INT(_2))
        *poke_addr++ = (unsigned char)_2;
        else if (_2 == NOVALUE)
        break;
        else {
            *poke_addr++ = (signed char)DBL_PTR(_2)->dbl;
        }
    }

    /** 		poke4( asm + 7, length(call_backs) + 1 )*/
    if (IS_ATOM_INT(_asm_68165)) {
        _34613 = _asm_68165 + 7;
        if ((long)((unsigned long)_34613 + (unsigned long)HIGH_BITS) >= 0) 
        _34613 = NewDouble((double)_34613);
    }
    else {
        _34613 = NewDouble(DBL_PTR(_asm_68165)->dbl + (double)7);
    }
    if (IS_SEQUENCE(_67call_backs_63406)){
            _34614 = SEQ_PTR(_67call_backs_63406)->length;
    }
    else {
        _34614 = 1;
    }
    _34615 = _34614 + 1;
    _34614 = NOVALUE;
    if (IS_ATOM_INT(_34613)){
        poke4_addr = (unsigned long *)_34613;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_34613)->dbl);
    }
    *poke4_addr = (unsigned long)_34615;
    DeRef(_34613);
    _34613 = NOVALUE;
    _34615 = NOVALUE;

    /** 		poke4( asm + 13, asm + 23 )*/
    if (IS_ATOM_INT(_asm_68165)) {
        _34616 = _asm_68165 + 13;
        if ((long)((unsigned long)_34616 + (unsigned long)HIGH_BITS) >= 0) 
        _34616 = NewDouble((double)_34616);
    }
    else {
        _34616 = NewDouble(DBL_PTR(_asm_68165)->dbl + (double)13);
    }
    if (IS_ATOM_INT(_asm_68165)) {
        _34617 = _asm_68165 + 23;
        if ((long)((unsigned long)_34617 + (unsigned long)HIGH_BITS) >= 0) 
        _34617 = NewDouble((double)_34617);
    }
    else {
        _34617 = NewDouble(DBL_PTR(_asm_68165)->dbl + (double)23);
    }
    if (IS_ATOM_INT(_34616)){
        poke4_addr = (unsigned long *)_34616;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_34616)->dbl);
    }
    if (IS_ATOM_INT(_34617)) {
        *poke4_addr = (unsigned long)_34617;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_34617)->dbl;
    }
    DeRef(_34616);
    _34616 = NOVALUE;
    DeRef(_34617);
    _34617 = NOVALUE;

    /** 		poke4( asm + 23, callback( ( '+' & routine_id("machine_callback") ) ) )*/
    if (IS_ATOM_INT(_asm_68165)) {
        _34618 = _asm_68165 + 23;
        if ((long)((unsigned long)_34618 + (unsigned long)HIGH_BITS) >= 0) 
        _34618 = NewDouble((double)_34618);
    }
    else {
        _34618 = NewDouble(DBL_PTR(_asm_68165)->dbl + (double)23);
    }
    _34619 = CRoutineId(1544, 67, _34590);
    Concat((object_ptr)&_34620, 43, _34619);
    _34619 = NOVALUE;
    _34621 = _67callback(_34620);
    _34620 = NOVALUE;
    if (IS_ATOM_INT(_34618)){
        poke4_addr = (unsigned long *)_34618;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_34618)->dbl);
    }
    if (IS_ATOM_INT(_34621)) {
        *poke4_addr = (unsigned long)_34621;
    }
    else if (IS_ATOM(_34621)) {
        *poke4_addr = (unsigned long)DBL_PTR(_34621)->dbl;
    }
    else {
        _1 = (int)SEQ_PTR(_34621);
        _1 = (int)((s1_ptr)_1)->base;
        while (1) {
            _1 += 4;
            _2 = *((int *)_1);
            if (IS_ATOM_INT(_2))
            *(int *)poke4_addr++ = (unsigned long)_2;
            else if (_2 == NOVALUE)
            break;
            else {
                *(int *)poke4_addr++ = (unsigned long)DBL_PTR(_2)->dbl;
            }
        }
    }
    DeRef(_34618);
    _34618 = NOVALUE;
    DeRef(_34621);
    _34621 = NOVALUE;
L6: 

    /** 	val[target] = asm*/
    Ref(_asm_68165);
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63484);
    _1 = *(int *)_2;
    *(int *)_2 = _asm_68165;
    DeRef(_1);

    /** 	call_backs = append( call_backs, { r, id, SymTab[r][S_NUM_ARGS] })*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _34622 = (int)*(((s1_ptr)_2)->base + _r_68164);
    _2 = (int)SEQ_PTR(_34622);
    if (!IS_ATOM_INT(_26S_NUM_ARGS_11705)){
        _34623 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NUM_ARGS_11705)->dbl));
    }
    else{
        _34623 = (int)*(((s1_ptr)_2)->base + _26S_NUM_ARGS_11705);
    }
    _34622 = NOVALUE;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _r_68164;
    *((int *)(_2+8)) = _id_68166;
    Ref(_34623);
    *((int *)(_2+12)) = _34623;
    _34624 = MAKE_SEQ(_1);
    _34623 = NOVALUE;
    RefDS(_34624);
    Append(&_67call_backs_63406, _67call_backs_63406, _34624);
    DeRefDS(_34624);
    _34624 = NOVALUE;

    /** end procedure*/
    DeRef(_asm_68165);
    DeRef(_x_68168);
    DeRef(_34568);
    _34568 = NOVALUE;
    DeRef(_34573);
    _34573 = NOVALUE;
    DeRef(_34575);
    _34575 = NOVALUE;
    return;
    ;
}


void _67do_crash_routine(int _b_68250)
{
    int _x_68251 = NOVALUE;
    int _34632 = NOVALUE;
    int _34631 = NOVALUE;
    int _34630 = NOVALUE;
    int _34629 = NOVALUE;
    int _34628 = NOVALUE;
    int _34627 = NOVALUE;
    int _0, _1, _2;
    

    /** 	x = val[b]*/
    DeRef(_x_68251);
    _2 = (int)SEQ_PTR(_67val_63489);
    _x_68251 = (int)*(((s1_ptr)_2)->base + _b_68250);
    Ref(_x_68251);

    /** 	if atom(x) and x >= 0 and x < length(e_routine) then*/
    _34627 = IS_ATOM(_x_68251);
    if (_34627 == 0) {
        _34628 = 0;
        goto L1; // [16] 28
    }
    if (IS_ATOM_INT(_x_68251)) {
        _34629 = (_x_68251 >= 0);
    }
    else {
        _34629 = binary_op(GREATEREQ, _x_68251, 0);
    }
    if (IS_ATOM_INT(_34629))
    _34628 = (_34629 != 0);
    else
    _34628 = DBL_PTR(_34629)->dbl != 0.0;
L1: 
    if (_34628 == 0) {
        goto L2; // [28] 56
    }
    if (IS_SEQUENCE(_67e_routine_63527)){
            _34631 = SEQ_PTR(_67e_routine_63527)->length;
    }
    else {
        _34631 = 1;
    }
    if (IS_ATOM_INT(_x_68251)) {
        _34632 = (_x_68251 < _34631);
    }
    else {
        _34632 = binary_op(LESS, _x_68251, _34631);
    }
    _34631 = NOVALUE;
    if (_34632 == 0) {
        DeRef(_34632);
        _34632 = NOVALUE;
        goto L2; // [42] 56
    }
    else {
        if (!IS_ATOM_INT(_34632) && DBL_PTR(_34632)->dbl == 0.0){
            DeRef(_34632);
            _34632 = NOVALUE;
            goto L2; // [42] 56
        }
        DeRef(_34632);
        _34632 = NOVALUE;
    }
    DeRef(_34632);
    _34632 = NOVALUE;

    /** 		crash_list = append(crash_list, x)*/
    Ref(_x_68251);
    Append(&_67crash_list_63415, _67crash_list_63415, _x_68251);
    goto L3; // [53] 62
L2: 

    /** 		RTFatal("crash routine requires a valid routine id")*/
    RefDS(_34634);
    _67RTFatal(_34634);
L3: 

    /** end procedure*/
    DeRef(_x_68251);
    DeRef(_34629);
    _34629 = NOVALUE;
    return;
    ;
}


void _67opREMOVE()
{
    int _34646 = NOVALUE;
    int _34645 = NOVALUE;
    int _34644 = NOVALUE;
    int _34643 = NOVALUE;
    int _34641 = NOVALUE;
    int _34639 = NOVALUE;
    int _34637 = NOVALUE;
    int _34635 = NOVALUE;
    int _0, _1, _2;
    

    /**  	a = Code[pc+1]*/
    _34635 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _34635);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /**  	b = Code[pc+2]*/
    _34637 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67b_63481 = (int)*(((s1_ptr)_2)->base + _34637);
    if (!IS_ATOM_INT(_67b_63481)){
        _67b_63481 = (long)DBL_PTR(_67b_63481)->dbl;
    }

    /**  	c = Code[pc+3]*/
    _34639 = _67pc_63479 + 3;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67c_63482 = (int)*(((s1_ptr)_2)->base + _34639);
    if (!IS_ATOM_INT(_67c_63482)){
        _67c_63482 = (long)DBL_PTR(_67c_63482)->dbl;
    }

    /**  	target = Code[pc+4]*/
    _34641 = _67pc_63479 + 4;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67target_63484 = (int)*(((s1_ptr)_2)->base + _34641);
    if (!IS_ATOM_INT(_67target_63484)){
        _67target_63484 = (long)DBL_PTR(_67target_63484)->dbl;
    }

    /**  	val[target] = remove(val[a],val[b],val[c])*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _34643 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    _2 = (int)SEQ_PTR(_67val_63489);
    _34644 = (int)*(((s1_ptr)_2)->base + _67b_63481);
    _2 = (int)SEQ_PTR(_67val_63489);
    _34645 = (int)*(((s1_ptr)_2)->base + _67c_63482);
    {
        s1_ptr assign_space = SEQ_PTR(_34643);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_34644)) ? _34644 : (long)(DBL_PTR(_34644)->dbl);
        int stop = (IS_ATOM_INT(_34645)) ? _34645 : (long)(DBL_PTR(_34645)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
            RefDS(_34643);
            DeRef(_34646);
            _34646 = _34643;
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_34643), start, &_34646 );
            }
            else Tail(SEQ_PTR(_34643), stop+1, &_34646);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_34643), start, &_34646);
        }
        else {
            assign_slice_seq = &assign_space;
            _1 = Remove_elements(start, stop, 0);
            DeRef(_34646);
            _34646 = _1;
        }
    }
    _34643 = NOVALUE;
    _34644 = NOVALUE;
    _34645 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63484);
    _1 = *(int *)_2;
    *(int *)_2 = _34646;
    if( _1 != _34646 ){
        DeRef(_1);
    }
    _34646 = NOVALUE;

    /**  	pc += 5*/
    _67pc_63479 = _67pc_63479 + 5;

    /** end procedure*/
    _34635 = NOVALUE;
    _34637 = NOVALUE;
    _34639 = NOVALUE;
    _34641 = NOVALUE;
    return;
    ;
}


void _67opREPLACE()
{
    int _34662 = NOVALUE;
    int _34661 = NOVALUE;
    int _34660 = NOVALUE;
    int _34659 = NOVALUE;
    int _34658 = NOVALUE;
    int _34656 = NOVALUE;
    int _34654 = NOVALUE;
    int _34652 = NOVALUE;
    int _34650 = NOVALUE;
    int _34648 = NOVALUE;
    int _0, _1, _2;
    

    /**  	a = Code[pc+1]*/
    _34648 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _34648);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /**  	b = Code[pc+2]*/
    _34650 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67b_63481 = (int)*(((s1_ptr)_2)->base + _34650);
    if (!IS_ATOM_INT(_67b_63481)){
        _67b_63481 = (long)DBL_PTR(_67b_63481)->dbl;
    }

    /**  	c = Code[pc+3]*/
    _34652 = _67pc_63479 + 3;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67c_63482 = (int)*(((s1_ptr)_2)->base + _34652);
    if (!IS_ATOM_INT(_67c_63482)){
        _67c_63482 = (long)DBL_PTR(_67c_63482)->dbl;
    }

    /**  	d = Code[pc+4]*/
    _34654 = _67pc_63479 + 4;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67d_63483 = (int)*(((s1_ptr)_2)->base + _34654);
    if (!IS_ATOM_INT(_67d_63483)){
        _67d_63483 = (long)DBL_PTR(_67d_63483)->dbl;
    }

    /**  	target = Code[pc+5]*/
    _34656 = _67pc_63479 + 5;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67target_63484 = (int)*(((s1_ptr)_2)->base + _34656);
    if (!IS_ATOM_INT(_67target_63484)){
        _67target_63484 = (long)DBL_PTR(_67target_63484)->dbl;
    }

    /**  	val[target] = replace(val[a],val[b],val[c],val[d])*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _34658 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    _2 = (int)SEQ_PTR(_67val_63489);
    _34659 = (int)*(((s1_ptr)_2)->base + _67b_63481);
    _2 = (int)SEQ_PTR(_67val_63489);
    _34660 = (int)*(((s1_ptr)_2)->base + _67c_63482);
    _2 = (int)SEQ_PTR(_67val_63489);
    _34661 = (int)*(((s1_ptr)_2)->base + _67d_63483);
    {
        int p1 = _34658;
        int p2 = _34659;
        int p3 = _34660;
        int p4 = _34661;
        struct replace_block replace_params;
        replace_params.copy_to   = &p1;
        replace_params.copy_from = &p2;
        replace_params.start     = &p3;
        replace_params.stop      = &p4;
        replace_params.target    = &_34662;
        Replace( &replace_params );
    }
    _34658 = NOVALUE;
    _34659 = NOVALUE;
    _34660 = NOVALUE;
    _34661 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63484);
    _1 = *(int *)_2;
    *(int *)_2 = _34662;
    if( _1 != _34662 ){
        DeRef(_1);
    }
    _34662 = NOVALUE;

    /**  	pc += 6*/
    _67pc_63479 = _67pc_63479 + 6;

    /** end procedure*/
    _34648 = NOVALUE;
    _34650 = NOVALUE;
    _34652 = NOVALUE;
    _34654 = NOVALUE;
    _34656 = NOVALUE;
    return;
    ;
}


void _67opHEAD()
{
    int _34672 = NOVALUE;
    int _34671 = NOVALUE;
    int _34670 = NOVALUE;
    int _34668 = NOVALUE;
    int _34666 = NOVALUE;
    int _34664 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _34664 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _34664);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _34666 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67b_63481 = (int)*(((s1_ptr)_2)->base + _34666);
    if (!IS_ATOM_INT(_67b_63481)){
        _67b_63481 = (long)DBL_PTR(_67b_63481)->dbl;
    }

    /** 	target = Code[pc+3]*/
    _34668 = _67pc_63479 + 3;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67target_63484 = (int)*(((s1_ptr)_2)->base + _34668);
    if (!IS_ATOM_INT(_67target_63484)){
        _67target_63484 = (long)DBL_PTR(_67target_63484)->dbl;
    }

    /** 	val[target] = head(val[a],val[b])*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _34670 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    _2 = (int)SEQ_PTR(_67val_63489);
    _34671 = (int)*(((s1_ptr)_2)->base + _67b_63481);
    {
        int len = SEQ_PTR(_34670)->length;
        int size = (IS_ATOM_INT(_34671)) ? _34671 : (long)(DBL_PTR(_34671)->dbl);
        if (size <= 0) _34672 = MAKE_SEQ(NewS1(0));
        else if (len <= size) {
            RefDS(_34670);
            DeRef(_34672);
            _34672 = _34670;
        }
        else Head(SEQ_PTR(_34670),size+1,&_34672);
    }
    _34670 = NOVALUE;
    _34671 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63484);
    _1 = *(int *)_2;
    *(int *)_2 = _34672;
    if( _1 != _34672 ){
        DeRef(_1);
    }
    _34672 = NOVALUE;

    /** 	pc += 4*/
    _67pc_63479 = _67pc_63479 + 4;

    /** end procedure*/
    _34664 = NOVALUE;
    _34666 = NOVALUE;
    _34668 = NOVALUE;
    return;
    ;
}


void _67opTAIL()
{
    int _34682 = NOVALUE;
    int _34681 = NOVALUE;
    int _34680 = NOVALUE;
    int _34678 = NOVALUE;
    int _34676 = NOVALUE;
    int _34674 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _34674 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _34674);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _34676 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67b_63481 = (int)*(((s1_ptr)_2)->base + _34676);
    if (!IS_ATOM_INT(_67b_63481)){
        _67b_63481 = (long)DBL_PTR(_67b_63481)->dbl;
    }

    /** 	target = Code[pc+3]*/
    _34678 = _67pc_63479 + 3;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67target_63484 = (int)*(((s1_ptr)_2)->base + _34678);
    if (!IS_ATOM_INT(_67target_63484)){
        _67target_63484 = (long)DBL_PTR(_67target_63484)->dbl;
    }

    /** 	val[target] = tail(val[a],val[b])*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _34680 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    _2 = (int)SEQ_PTR(_67val_63489);
    _34681 = (int)*(((s1_ptr)_2)->base + _67b_63481);
    {
        int len = SEQ_PTR(_34680)->length;
        int size = (IS_ATOM_INT(_34681)) ? _34681 : (long)(DBL_PTR(_34681)->dbl);
        if (size <= 0) {
            DeRef(_34682);
            _34682 = MAKE_SEQ(NewS1(0));
        }
        else if (len <= size) {
            RefDS(_34680);
            DeRef(_34682);
            _34682 = _34680;
        }
        else Tail(SEQ_PTR(_34680), len-size+1, &_34682);
    }
    _34680 = NOVALUE;
    _34681 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63484);
    _1 = *(int *)_2;
    *(int *)_2 = _34682;
    if( _1 != _34682 ){
        DeRef(_1);
    }
    _34682 = NOVALUE;

    /** 	pc += 4*/
    _67pc_63479 = _67pc_63479 + 4;

    /** end procedure*/
    _34674 = NOVALUE;
    _34676 = NOVALUE;
    _34678 = NOVALUE;
    return;
    ;
}


void _67opMACHINE_FUNC()
{
    int _34695 = NOVALUE;
    int _34694 = NOVALUE;
    int _34693 = NOVALUE;
    int _34691 = NOVALUE;
    int _34688 = NOVALUE;
    int _34686 = NOVALUE;
    int _34684 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _34684 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _34684);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _34686 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67b_63481 = (int)*(((s1_ptr)_2)->base + _34686);
    if (!IS_ATOM_INT(_67b_63481)){
        _67b_63481 = (long)DBL_PTR(_67b_63481)->dbl;
    }

    /** 	target = Code[pc+3]*/
    _34688 = _67pc_63479 + 3;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67target_63484 = (int)*(((s1_ptr)_2)->base + _34688);
    if (!IS_ATOM_INT(_67target_63484)){
        _67target_63484 = (long)DBL_PTR(_67target_63484)->dbl;
    }

    /** 	pc += 4*/
    _67pc_63479 = _67pc_63479 + 4;

    /** 	if val[a] = M_CALL_BACK then*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _34691 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    if (binary_op_a(NOTEQ, _34691, 52)){
        _34691 = NOVALUE;
        goto L1; // [67] 81
    }
    _34691 = NOVALUE;

    /** 		do_callback(b)*/
    _67do_callback(_67b_63481);
    goto L2; // [78] 112
L1: 

    /** 		val[target] = machine_func(val[a], val[b])*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _34693 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    _2 = (int)SEQ_PTR(_67val_63489);
    _34694 = (int)*(((s1_ptr)_2)->base + _67b_63481);
    _34695 = machine(_34693, _34694);
    _34693 = NOVALUE;
    _34694 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63484);
    _1 = *(int *)_2;
    *(int *)_2 = _34695;
    if( _1 != _34695 ){
        DeRef(_1);
    }
    _34695 = NOVALUE;
L2: 

    /** end procedure*/
    DeRef(_34684);
    _34684 = NOVALUE;
    DeRef(_34686);
    _34686 = NOVALUE;
    DeRef(_34688);
    _34688 = NOVALUE;
    return;
    ;
}


void _67opSPLICE()
{
    int _34707 = NOVALUE;
    int _34706 = NOVALUE;
    int _34705 = NOVALUE;
    int _34704 = NOVALUE;
    int _34702 = NOVALUE;
    int _34700 = NOVALUE;
    int _34698 = NOVALUE;
    int _34696 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _34696 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _34696);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _34698 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67b_63481 = (int)*(((s1_ptr)_2)->base + _34698);
    if (!IS_ATOM_INT(_67b_63481)){
        _67b_63481 = (long)DBL_PTR(_67b_63481)->dbl;
    }

    /** 	c = Code[pc+3]*/
    _34700 = _67pc_63479 + 3;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67c_63482 = (int)*(((s1_ptr)_2)->base + _34700);
    if (!IS_ATOM_INT(_67c_63482)){
        _67c_63482 = (long)DBL_PTR(_67c_63482)->dbl;
    }

    /** 	target = Code[pc+4]*/
    _34702 = _67pc_63479 + 4;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67target_63484 = (int)*(((s1_ptr)_2)->base + _34702);
    if (!IS_ATOM_INT(_67target_63484)){
        _67target_63484 = (long)DBL_PTR(_67target_63484)->dbl;
    }

    /** 	val[target] = splice(val[a],val[b],val[c])*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _34704 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    _2 = (int)SEQ_PTR(_67val_63489);
    _34705 = (int)*(((s1_ptr)_2)->base + _67b_63481);
    _2 = (int)SEQ_PTR(_67val_63489);
    _34706 = (int)*(((s1_ptr)_2)->base + _67c_63482);
    {
        s1_ptr assign_space;
        insert_pos = IS_ATOM_INT(_34706) ? _34706 : DBL_PTR(_34706)->dbl;
        if (insert_pos <= 0) {
            if (IS_SEQUENCE(_34705)) {
                Concat(&_34707,_34705,_34704);
            }
            else{
                Prepend(&_34707,_34704,_34705);
            }
        }
        else if (insert_pos > SEQ_PTR(_34704)->length){
            if (IS_SEQUENCE(_34705)) {
                Concat(&_34707,_34704,_34705);
            }
            else{
                Append(&_34707,_34704,_34705);
            }
        }
        else if (IS_SEQUENCE(_34705)) {
            if( _34707 != _34704 || SEQ_PTR( _34704 )->ref != 1 ){
                DeRef( _34707 );
                RefDS( _34704 );
            }
            assign_space = Add_internal_space( _34704, insert_pos,((s1_ptr)SEQ_PTR(_34705))->length);
            assign_slice_seq = &assign_space;
            assign_space = Copy_elements( insert_pos, SEQ_PTR(_34705), _34704 == _34707 );
            _34707 = MAKE_SEQ( assign_space );
        }
        else {
            if( _34707 != _34704 && SEQ_PTR( _34704 )->ref != 1 ){
                _34707 = Insert( _34704, _34705, insert_pos);
            }
            else {
                DeRef( _34707 );
                RefDS( _34704 );
                _34707 = Insert( _34704, _34705, insert_pos);
            }
        }
    }
    _34704 = NOVALUE;
    _34705 = NOVALUE;
    _34706 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63484);
    _1 = *(int *)_2;
    *(int *)_2 = _34707;
    if( _1 != _34707 ){
        DeRef(_1);
    }
    _34707 = NOVALUE;

    /** 	pc += 5*/
    _67pc_63479 = _67pc_63479 + 5;

    /** end procedure*/
    _34696 = NOVALUE;
    _34698 = NOVALUE;
    _34700 = NOVALUE;
    _34702 = NOVALUE;
    return;
    ;
}


void _67opINSERT()
{
    int _34720 = NOVALUE;
    int _34719 = NOVALUE;
    int _34718 = NOVALUE;
    int _34717 = NOVALUE;
    int _34715 = NOVALUE;
    int _34713 = NOVALUE;
    int _34711 = NOVALUE;
    int _34709 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _34709 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _34709);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _34711 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67b_63481 = (int)*(((s1_ptr)_2)->base + _34711);
    if (!IS_ATOM_INT(_67b_63481)){
        _67b_63481 = (long)DBL_PTR(_67b_63481)->dbl;
    }

    /** 	c = Code[pc+3]*/
    _34713 = _67pc_63479 + 3;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67c_63482 = (int)*(((s1_ptr)_2)->base + _34713);
    if (!IS_ATOM_INT(_67c_63482)){
        _67c_63482 = (long)DBL_PTR(_67c_63482)->dbl;
    }

    /** 	target = Code[pc+4]*/
    _34715 = _67pc_63479 + 4;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67target_63484 = (int)*(((s1_ptr)_2)->base + _34715);
    if (!IS_ATOM_INT(_67target_63484)){
        _67target_63484 = (long)DBL_PTR(_67target_63484)->dbl;
    }

    /** 	val[target] = insert(val[a],val[b],val[c])*/
    _2 = (int)SEQ_PTR(_67val_63489);
    _34717 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    _2 = (int)SEQ_PTR(_67val_63489);
    _34718 = (int)*(((s1_ptr)_2)->base + _67b_63481);
    _2 = (int)SEQ_PTR(_67val_63489);
    _34719 = (int)*(((s1_ptr)_2)->base + _67c_63482);
    {
        s1_ptr assign_space;
        insert_pos = IS_ATOM_INT(_34719) ? _34719 : DBL_PTR(_34719)->dbl;
        if (insert_pos <= 0){
            Prepend(&_34720,_34717,_34718);
        }
        else if (insert_pos > SEQ_PTR(_34717)->length) {
            Ref( _34718 );
            Append(&_34720,_34717,_34718);
        }
        else {
            Ref( _34718 );
            RefDS( _34717 );
            _34720 = Insert(_34717,_34718,insert_pos);
        }
    }
    _34717 = NOVALUE;
    _34718 = NOVALUE;
    _34719 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63484);
    _1 = *(int *)_2;
    *(int *)_2 = _34720;
    if( _1 != _34720 ){
        DeRef(_1);
    }
    _34720 = NOVALUE;

    /** 	pc += 5*/
    _67pc_63479 = _67pc_63479 + 5;

    /** end procedure*/
    _34709 = NOVALUE;
    _34711 = NOVALUE;
    _34713 = NOVALUE;
    _34715 = NOVALUE;
    return;
    ;
}


void _67opMACHINE_PROC()
{
    int _v_68395 = NOVALUE;
    int _34739 = NOVALUE;
    int _34738 = NOVALUE;
    int _34736 = NOVALUE;
    int _34734 = NOVALUE;
    int _34733 = NOVALUE;
    int _34731 = NOVALUE;
    int _34730 = NOVALUE;
    int _34724 = NOVALUE;
    int _34722 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _34722 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _34722);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _34724 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67b_63481 = (int)*(((s1_ptr)_2)->base + _34724);
    if (!IS_ATOM_INT(_67b_63481)){
        _67b_63481 = (long)DBL_PTR(_67b_63481)->dbl;
    }

    /** 	v = val[a]*/
    DeRef(_v_68395);
    _2 = (int)SEQ_PTR(_67val_63489);
    _v_68395 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    Ref(_v_68395);

    /** 	switch v do*/
    if (IS_SEQUENCE(_v_68395) ){
        goto L1; // [45] 201
    }
    if(!IS_ATOM_INT(_v_68395)){
        if( (DBL_PTR(_v_68395)->dbl != (double) ((int) DBL_PTR(_v_68395)->dbl) ) ){
            goto L1; // [45] 201
        }
        _0 = (int) DBL_PTR(_v_68395)->dbl;
    }
    else {
        _0 = _v_68395;
    };
    switch ( _0 ){ 

        /** 		case M_CRASH_ROUTINE then*/
        case 66:

        /** 			do_crash_routine(b)*/
        _67do_crash_routine(_67b_63481);
        goto L2; // [61] 217

        /** 		case M_CRASH_MESSAGE then*/
        case 37:

        /** 			crash_msg = val[b]*/
        DeRef(_67crash_msg_63405);
        _2 = (int)SEQ_PTR(_67val_63489);
        _67crash_msg_63405 = (int)*(((s1_ptr)_2)->base + _67b_63481);
        Ref(_67crash_msg_63405);
        goto L2; // [77] 217

        /** 		case M_CRASH_FILE then*/
        case 57:

        /** 			if sequence(val[b]) then*/
        _2 = (int)SEQ_PTR(_67val_63489);
        _34730 = (int)*(((s1_ptr)_2)->base + _67b_63481);
        _34731 = IS_SEQUENCE(_34730);
        _34730 = NOVALUE;
        if (_34731 == 0)
        {
            _34731 = NOVALUE;
            goto L2; // [96] 217
        }
        else{
            _34731 = NOVALUE;
        }

        /** 				err_file_name = val[b]*/
        DeRef(_67err_file_name_63529);
        _2 = (int)SEQ_PTR(_67val_63489);
        _67err_file_name_63529 = (int)*(((s1_ptr)_2)->base + _67b_63481);
        Ref(_67err_file_name_63529);
        goto L2; // [112] 217

        /** 		case M_WARNING_FILE then*/
        case 72:

        /** 			display_warnings = 1*/
        _43display_warnings_48556 = 1;

        /** 			if sequence(val[b]) then*/
        _2 = (int)SEQ_PTR(_67val_63489);
        _34733 = (int)*(((s1_ptr)_2)->base + _67b_63481);
        _34734 = IS_SEQUENCE(_34733);
        _34733 = NOVALUE;
        if (_34734 == 0)
        {
            _34734 = NOVALUE;
            goto L3; // [138] 154
        }
        else{
            _34734 = NOVALUE;
        }

        /** 				TempWarningName = val[b]*/
        DeRef(_26TempWarningName_11996);
        _2 = (int)SEQ_PTR(_67val_63489);
        _26TempWarningName_11996 = (int)*(((s1_ptr)_2)->base + _67b_63481);
        Ref(_26TempWarningName_11996);
        goto L2; // [151] 217
L3: 

        /** 				TempWarningName = STDERR*/
        DeRef(_26TempWarningName_11996);
        _26TempWarningName_11996 = 2;

        /** 				display_warnings = (val[b] >= 0)*/
        _2 = (int)SEQ_PTR(_67val_63489);
        _34736 = (int)*(((s1_ptr)_2)->base + _67b_63481);
        if (IS_ATOM_INT(_34736)) {
            _43display_warnings_48556 = (_34736 >= 0);
        }
        else {
            _43display_warnings_48556 = binary_op(GREATEREQ, _34736, 0);
        }
        _34736 = NOVALUE;
        if (!IS_ATOM_INT(_43display_warnings_48556)) {
            _1 = (long)(DBL_PTR(_43display_warnings_48556)->dbl);
            DeRefDS(_43display_warnings_48556);
            _43display_warnings_48556 = _1;
        }
        goto L2; // [178] 217

        /** 		case M_CRASH then*/
        case 67:

        /** 			RTFatal( val[b] )*/
        _2 = (int)SEQ_PTR(_67val_63489);
        _34738 = (int)*(((s1_ptr)_2)->base + _67b_63481);
        Ref(_34738);
        _67RTFatal(_34738);
        _34738 = NOVALUE;
        goto L2; // [197] 217

        /** 		case else*/
        default:
L1: 

        /** 			machine_proc(v, val[b])*/
        _2 = (int)SEQ_PTR(_67val_63489);
        _34739 = (int)*(((s1_ptr)_2)->base + _67b_63481);
        machine(_v_68395, _34739);
        _34739 = NOVALUE;
    ;}L2: 

    /** 	pc += 3*/
    _67pc_63479 = _67pc_63479 + 3;

    /** end procedure*/
    DeRef(_v_68395);
    DeRef(_34722);
    _34722 = NOVALUE;
    DeRef(_34724);
    _34724 = NOVALUE;
    return;
    ;
}


void _67opDEREF_TEMP()
{
    int _34742 = NOVALUE;
    int _34741 = NOVALUE;
    int _0, _1, _2;
    

    /** 	val[Code[pc+1]] = NOVALUE*/
    _34741 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _34742 = (int)*(((s1_ptr)_2)->base + _34741);
    Ref(_26NOVALUE_11836);
    _2 = (int)SEQ_PTR(_67val_63489);
    if (!IS_ATOM_INT(_34742))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_34742)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _34742);
    _1 = *(int *)_2;
    *(int *)_2 = _26NOVALUE_11836;
    DeRef(_1);

    /** 	pc += 2*/
    _67pc_63479 = _67pc_63479 + 2;

    /** end procedure*/
    _34741 = NOVALUE;
    _34742 = NOVALUE;
    return;
    ;
}


void _67do_delete_routine(int _dx_68448, int _o_68449)
{
    int _arglist_assign_68452 = NOVALUE;
    int _34764 = NOVALUE;
    int _34763 = NOVALUE;
    int _34762 = NOVALUE;
    int _34761 = NOVALUE;
    int _34760 = NOVALUE;
    int _34758 = NOVALUE;
    int _34757 = NOVALUE;
    int _34755 = NOVALUE;
    int _34754 = NOVALUE;
    int _34749 = NOVALUE;
    int _34747 = NOVALUE;
    int _34746 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	val[t_id] = user_delete_rid[dx]*/
    _2 = (int)SEQ_PTR(_67user_delete_rid_68441);
    _34746 = (int)*(((s1_ptr)_2)->base + _dx_68448);
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67t_id_63410);
    _1 = *(int *)_2;
    *(int *)_2 = _34746;
    if( _1 != _34746 ){
        DeRef(_1);
    }
    _34746 = NOVALUE;

    /** 	val[t_arglist] = {o}*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_o_68449);
    *((int *)(_2+4)) = _o_68449;
    _34747 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67t_arglist_63411);
    _1 = *(int *)_2;
    *(int *)_2 = _34747;
    if( _1 != _34747 ){
        DeRef(_1);
    }
    _34747 = NOVALUE;

    /** 	atom arglist_assign = new_arg_assign()*/
    _0 = _arglist_assign_68452;
    _arglist_assign_68452 = _67new_arg_assign();
    DeRef(_0);

    /** 	SymTab[delete_code_routine][S_RESIDENT_TASK] = current_task*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_67delete_code_routine_63414 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 25);
    _1 = *(int *)_2;
    *(int *)_2 = _67current_task_63496;
    DeRef(_1);
    _34749 = NOVALUE;

    /** 	call_stack = append(call_stack, pc)*/
    Append(&_67call_stack_63497, _67call_stack_63497, _67pc_63479);

    /** 	call_stack = append(call_stack, delete_code_routine)*/
    Append(&_67call_stack_63497, _67call_stack_63497, _67delete_code_routine_63414);

    /** 	Code = delete_code*/
    RefDS(_67delete_code_63408);
    DeRef(_26Code_12071);
    _26Code_12071 = _67delete_code_63408;

    /** 	pc = 1*/
    _67pc_63479 = 1;

    /** 	do_exec()*/
    _67do_exec();

    /** 	if arglist_assign = arg_assign then*/
    if (binary_op_a(NOTEQ, _arglist_assign_68452, _67arg_assign_63423)){
        goto L1; // [99] 116
    }

    /** 		val[t_arglist] = NOVALUE*/
    Ref(_26NOVALUE_11836);
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67t_arglist_63411);
    _1 = *(int *)_2;
    *(int *)_2 = _26NOVALUE_11836;
    DeRef(_1);
L1: 

    /** 	o = 0*/
    DeRef(_o_68449);
    _o_68449 = 0;

    /** 	pc = call_stack[$-1]*/
    if (IS_SEQUENCE(_67call_stack_63497)){
            _34754 = SEQ_PTR(_67call_stack_63497)->length;
    }
    else {
        _34754 = 1;
    }
    _34755 = _34754 - 1;
    _34754 = NOVALUE;
    _2 = (int)SEQ_PTR(_67call_stack_63497);
    _67pc_63479 = (int)*(((s1_ptr)_2)->base + _34755);
    if (!IS_ATOM_INT(_67pc_63479))
    _67pc_63479 = (long)DBL_PTR(_67pc_63479)->dbl;

    /** 	call_stack = call_stack[1..$-2]*/
    if (IS_SEQUENCE(_67call_stack_63497)){
            _34757 = SEQ_PTR(_67call_stack_63497)->length;
    }
    else {
        _34757 = 1;
    }
    _34758 = _34757 - 2;
    _34757 = NOVALUE;
    rhs_slice_target = (object_ptr)&_67call_stack_63497;
    RHS_Slice(_67call_stack_63497, 1, _34758);

    /** 	restore_privates( call_stack[$] )*/
    if (IS_SEQUENCE(_67call_stack_63497)){
            _34760 = SEQ_PTR(_67call_stack_63497)->length;
    }
    else {
        _34760 = 1;
    }
    _2 = (int)SEQ_PTR(_67call_stack_63497);
    _34761 = (int)*(((s1_ptr)_2)->base + _34760);
    Ref(_34761);
    _67restore_privates(_34761);
    _34761 = NOVALUE;

    /** 	Code = SymTab[call_stack[$]][S_CODE]*/
    if (IS_SEQUENCE(_67call_stack_63497)){
            _34762 = SEQ_PTR(_67call_stack_63497)->length;
    }
    else {
        _34762 = 1;
    }
    _2 = (int)SEQ_PTR(_67call_stack_63497);
    _34763 = (int)*(((s1_ptr)_2)->base + _34762);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!IS_ATOM_INT(_34763)){
        _34764 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_34763)->dbl));
    }
    else{
        _34764 = (int)*(((s1_ptr)_2)->base + _34763);
    }
    DeRef(_26Code_12071);
    _2 = (int)SEQ_PTR(_34764);
    if (!IS_ATOM_INT(_26S_CODE_11666)){
        _26Code_12071 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_CODE_11666)->dbl));
    }
    else{
        _26Code_12071 = (int)*(((s1_ptr)_2)->base + _26S_CODE_11666);
    }
    Ref(_26Code_12071);
    _34764 = NOVALUE;

    /** end procedure*/
    DeRef(_arglist_assign_68452);
    _34755 = NOVALUE;
    _34758 = NOVALUE;
    _34763 = NOVALUE;
    return;
    ;
}


void _67user_delete_01(int _o_68482)
{
    int _0, _1, _2;
    

    /** 	do_delete_routine( 1, o )*/
    Ref(_o_68482);
    _67do_delete_routine(1, _o_68482);

    /** end procedure*/
    DeRef(_o_68482);
    return;
    ;
}


void _67user_delete_02(int _o_68487)
{
    int _0, _1, _2;
    

    /** 	do_delete_routine( 2, o )*/
    Ref(_o_68487);
    _67do_delete_routine(2, _o_68487);

    /** end procedure*/
    DeRef(_o_68487);
    return;
    ;
}


void _67user_delete_03(int _o_68492)
{
    int _0, _1, _2;
    

    /** 	do_delete_routine( 3, o )*/
    Ref(_o_68492);
    _67do_delete_routine(3, _o_68492);

    /** end procedure*/
    DeRef(_o_68492);
    return;
    ;
}


void _67user_delete_04(int _o_68497)
{
    int _0, _1, _2;
    

    /** 	do_delete_routine( 4, o )*/
    Ref(_o_68497);
    _67do_delete_routine(4, _o_68497);

    /** end procedure*/
    DeRef(_o_68497);
    return;
    ;
}


void _67user_delete_05(int _o_68502)
{
    int _0, _1, _2;
    

    /** 	do_delete_routine( 5, o )*/
    Ref(_o_68502);
    _67do_delete_routine(5, _o_68502);

    /** end procedure*/
    DeRef(_o_68502);
    return;
    ;
}


void _67user_delete_06(int _o_68507)
{
    int _0, _1, _2;
    

    /** 	do_delete_routine( 6, o )*/
    Ref(_o_68507);
    _67do_delete_routine(6, _o_68507);

    /** end procedure*/
    DeRef(_o_68507);
    return;
    ;
}


void _67user_delete_07(int _o_68512)
{
    int _0, _1, _2;
    

    /** 	do_delete_routine( 7, o )*/
    Ref(_o_68512);
    _67do_delete_routine(7, _o_68512);

    /** end procedure*/
    DeRef(_o_68512);
    return;
    ;
}


void _67user_delete_08(int _o_68517)
{
    int _0, _1, _2;
    

    /** 	do_delete_routine( 8, o )*/
    Ref(_o_68517);
    _67do_delete_routine(8, _o_68517);

    /** end procedure*/
    DeRef(_o_68517);
    return;
    ;
}


void _67user_delete_09(int _o_68522)
{
    int _0, _1, _2;
    

    /** 	do_delete_routine( 9, o )*/
    Ref(_o_68522);
    _67do_delete_routine(9, _o_68522);

    /** end procedure*/
    DeRef(_o_68522);
    return;
    ;
}


void _67user_delete_10(int _o_68527)
{
    int _0, _1, _2;
    

    /** 	do_delete_routine( 10, o )*/
    Ref(_o_68527);
    _67do_delete_routine(10, _o_68527);

    /** end procedure*/
    DeRef(_o_68527);
    return;
    ;
}


void _67user_delete_11(int _o_68532)
{
    int _0, _1, _2;
    

    /** 	do_delete_routine( 11, o )*/
    Ref(_o_68532);
    _67do_delete_routine(11, _o_68532);

    /** end procedure*/
    DeRef(_o_68532);
    return;
    ;
}


void _67user_delete_12(int _o_68537)
{
    int _0, _1, _2;
    

    /** 	do_delete_routine( 12, o )*/
    Ref(_o_68537);
    _67do_delete_routine(12, _o_68537);

    /** end procedure*/
    DeRef(_o_68537);
    return;
    ;
}


void _67user_delete_13(int _o_68542)
{
    int _0, _1, _2;
    

    /** 	do_delete_routine( 13, o )*/
    Ref(_o_68542);
    _67do_delete_routine(13, _o_68542);

    /** end procedure*/
    DeRef(_o_68542);
    return;
    ;
}


void _67user_delete_14(int _o_68547)
{
    int _0, _1, _2;
    

    /** 	do_delete_routine( 14, o )*/
    Ref(_o_68547);
    _67do_delete_routine(14, _o_68547);

    /** end procedure*/
    DeRef(_o_68547);
    return;
    ;
}


void _67user_delete_15(int _o_68552)
{
    int _0, _1, _2;
    

    /** 	do_delete_routine( 15, o )*/
    Ref(_o_68552);
    _67do_delete_routine(15, _o_68552);

    /** end procedure*/
    DeRef(_o_68552);
    return;
    ;
}


void _67user_delete_16(int _o_68557)
{
    int _0, _1, _2;
    

    /** 	do_delete_routine( 16, o )*/
    Ref(_o_68557);
    _67do_delete_routine(16, _o_68557);

    /** end procedure*/
    DeRef(_o_68557);
    return;
    ;
}


void _67user_delete_17(int _o_68562)
{
    int _0, _1, _2;
    

    /** 	do_delete_routine( 17, o )*/
    Ref(_o_68562);
    _67do_delete_routine(17, _o_68562);

    /** end procedure*/
    DeRef(_o_68562);
    return;
    ;
}


void _67user_delete_18(int _o_68567)
{
    int _0, _1, _2;
    

    /** 	do_delete_routine( 18, o )*/
    Ref(_o_68567);
    _67do_delete_routine(18, _o_68567);

    /** end procedure*/
    DeRef(_o_68567);
    return;
    ;
}


void _67user_delete_19(int _o_68572)
{
    int _0, _1, _2;
    

    /** 	do_delete_routine( 19, o )*/
    Ref(_o_68572);
    _67do_delete_routine(19, _o_68572);

    /** end procedure*/
    DeRef(_o_68572);
    return;
    ;
}


void _67user_delete_20(int _o_68577)
{
    int _0, _1, _2;
    

    /** 	do_delete_routine( 20, o )*/
    Ref(_o_68577);
    _67do_delete_routine(20, _o_68577);

    /** end procedure*/
    DeRef(_o_68577);
    return;
    ;
}


void _67opDELETE_ROUTINE()
{
    int _rid_68585 = NOVALUE;
    int _34821 = NOVALUE;
    int _34820 = NOVALUE;
    int _34819 = NOVALUE;
    int _34818 = NOVALUE;
    int _34817 = NOVALUE;
    int _34816 = NOVALUE;
    int _34809 = NOVALUE;
    int _34808 = NOVALUE;
    int _34806 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _34806 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _67a_63480 = (int)*(((s1_ptr)_2)->base + _34806);
    if (!IS_ATOM_INT(_67a_63480)){
        _67a_63480 = (long)DBL_PTR(_67a_63480)->dbl;
    }

    /** 	integer rid = val[Code[pc+2]]*/
    _34808 = _67pc_63479 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _34809 = (int)*(((s1_ptr)_2)->base + _34808);
    _2 = (int)SEQ_PTR(_67val_63489);
    if (!IS_ATOM_INT(_34809)){
        _rid_68585 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_34809)->dbl));
    }
    else{
        _rid_68585 = (int)*(((s1_ptr)_2)->base + _34809);
    }
    if (!IS_ATOM_INT(_rid_68585))
    _rid_68585 = (long)DBL_PTR(_rid_68585)->dbl;

    /** 	b = find( rid, user_delete_rid )*/
    _67b_63481 = find_from(_rid_68585, _67user_delete_rid_68441, 1);

    /** 	if not b then*/
    if (_67b_63481 != 0)
    goto L1; // [50] 86

    /** 		b = find( -1, user_delete_rid )*/
    _67b_63481 = find_from(-1, _67user_delete_rid_68441, 1);

    /** 		if not b then*/
    if (_67b_63481 != 0)
    goto L2; // [66] 75

    /** 			RTFatal("Maximum of 20 user defined delete routines exceeded.")*/
    RefDS(_34815);
    _67RTFatal(_34815);
L2: 

    /** 		user_delete_rid[b] = rid*/
    _2 = (int)SEQ_PTR(_67user_delete_rid_68441);
    _2 = (int)(((s1_ptr)_2)->base + _67b_63481);
    *(int *)_2 = _rid_68585;
L1: 

    /** 	val[Code[pc+3]] = delete_routine( val[a], eu_delete_rid[b] )*/
    _34816 = _67pc_63479 + 3;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _34817 = (int)*(((s1_ptr)_2)->base + _34816);
    _2 = (int)SEQ_PTR(_67val_63489);
    _34818 = (int)*(((s1_ptr)_2)->base + _67a_63480);
    _2 = (int)SEQ_PTR(_67eu_delete_rid_68439);
    _34819 = (int)*(((s1_ptr)_2)->base + _67b_63481);
    DeRef(_34820);
    if( IS_ATOM_INT(_34818) ){
        _34820 = NewDouble( (double) _34818 );
    }
    else {
        if( !UNIQUE(SEQ_PTR(_34818)) ){
            if( IS_ATOM_DBL( _34818 ) ){
                _34820 = NewDouble( DBL_PTR(_34818)->dbl );
            }
            else {
                RefDS(_34818);
                _34820 = MAKE_SEQ(SequenceCopy( SEQ_PTR(_34818) ));
            }
        }
        else {
            _34820 = _34818;
        }
    }
    _1 = (int) _00[_34819].cleanup;
    if( _1 == 0 ){
        _1 = (int) TransAlloc( sizeof(struct cleanup) );
        _00[_34819].cleanup = (cleanup_ptr)_1;
    }
    ((cleanup_ptr)_1)->type = CLEAN_UDT_RT;
    ((cleanup_ptr)_1)->func.rid = _34819;
    ((cleanup_ptr)_1)->next = 0;
    if( IS_ATOM(_34820) ){
        if( IS_ATOM_INT(_34820) ){
            _34820 = NewDouble( (double) _34818 );
        }
        if(DBL_PTR(_34820)->cleanup != 0 ){
            _1 = (int) ChainDeleteRoutine( (cleanup_ptr)_1, DBL_PTR(_34820)->cleanup );
        }
        else if( !UNIQUE(DBL_PTR(_34820)) ){
            DeRefDS(_34820);
            _34820 = NewDouble( DBL_PTR(_34820)->dbl );
        }
        DBL_PTR(_34820)->cleanup = (cleanup_ptr)_1;
    }
    else{
        if(SEQ_PTR(_34820)->cleanup != 0 ){
            _1 = (int) ChainDeleteRoutine( (cleanup_ptr)_1, SEQ_PTR(_34820)->cleanup );
        }
        else if( !UNIQUE(SEQ_PTR(_34820)) ){
            _34820 = MAKE_SEQ(SequenceCopy( SEQ_PTR(_34820) ));
        }
        SEQ_PTR(_34820)->cleanup = (cleanup_ptr)_1;
    }
    _34818 = NOVALUE;
    _34819 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63489);
    if (!IS_ATOM_INT(_34817))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_34817)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _34817);
    _1 = *(int *)_2;
    *(int *)_2 = _34820;
    if( _1 != _34820 ){
        DeRef(_1);
    }
    _34820 = NOVALUE;

    /** 	if sym_mode( a ) = M_TEMP then*/
    _34821 = _52sym_mode(_67a_63480);
    if (binary_op_a(NOTEQ, _34821, 3)){
        DeRef(_34821);
        _34821 = NOVALUE;
        goto L3; // [136] 153
    }
    DeRef(_34821);
    _34821 = NOVALUE;

    /** 		val[a] = NOVALUE*/
    Ref(_26NOVALUE_11836);
    _2 = (int)SEQ_PTR(_67val_63489);
    _2 = (int)(((s1_ptr)_2)->base + _67a_63480);
    _1 = *(int *)_2;
    *(int *)_2 = _26NOVALUE_11836;
    DeRef(_1);
L3: 

    /** 	pc += 4*/
    _67pc_63479 = _67pc_63479 + 4;

    /** end procedure*/
    DeRef(_34806);
    _34806 = NOVALUE;
    DeRef(_34808);
    _34808 = NOVALUE;
    _34809 = NOVALUE;
    DeRef(_34816);
    _34816 = NOVALUE;
    _34817 = NOVALUE;
    return;
    ;
}


void _67opDELETE_OBJECT()
{
    int _34826 = NOVALUE;
    int _34825 = NOVALUE;
    int _34824 = NOVALUE;
    int _0, _1, _2;
    

    /** 	delete( val[Code[pc+1]] )*/
    _34824 = _67pc_63479 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _34825 = (int)*(((s1_ptr)_2)->base + _34824);
    _2 = (int)SEQ_PTR(_67val_63489);
    if (!IS_ATOM_INT(_34825)){
        _34826 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_34825)->dbl));
    }
    else{
        _34826 = (int)*(((s1_ptr)_2)->base + _34825);
    }
    if( IS_SEQUENCE(_34826) ){
        cleanup_sequence(SEQ_PTR(_34826));
    }
    if( IS_ATOM_DBL(_34826)){
        cleanup_double(DBL_PTR(_34826));
    }
    _34826 = NOVALUE;

    /** 	pc += 2*/
    _67pc_63479 = _67pc_63479 + 2;

    /** end procedure*/
    _34824 = NOVALUE;
    _34825 = NOVALUE;
    return;
    ;
}


void _67do_exec()
{
    int _op_68621 = NOVALUE;
    int _34835 = NOVALUE;
    int _0, _1, _2;
    

    /** 	keep_running = TRUE*/
    _67keep_running_63486 = _9TRUE_430;

    /** 	while keep_running do*/
L1: 
    if (_67keep_running_63486 == 0)
    {
        goto L2; // [17] 1850
    }
    else{
    }

    /** 		integer op = Code[pc]*/
    _2 = (int)SEQ_PTR(_26Code_12071);
    _op_68621 = (int)*(((s1_ptr)_2)->base + _67pc_63479);
    if (!IS_ATOM_INT(_op_68621)){
        _op_68621 = (long)DBL_PTR(_op_68621)->dbl;
    }

    /** 		ifdef DEBUG then*/

    /** 		switch op do*/
    _0 = _op_68621;
    switch ( _0 ){ 

        /** 			case ABORT then*/
        case 126:

        /** 				opABORT()*/
        _67opABORT();
        goto L3; // [49] 1843

        /** 			case AND then*/
        case 8:

        /** 				opAND()*/
        _67opAND();
        goto L3; // [59] 1843

        /** 			case AND_BITS then*/
        case 56:

        /** 				opAND_BITS()*/
        _67opAND_BITS();
        goto L3; // [69] 1843

        /** 			case APPEND then*/
        case 35:

        /** 				opAPPEND()*/
        _67opAPPEND();
        goto L3; // [79] 1843

        /** 			case ARCTAN then*/
        case 73:

        /** 				opARCTAN()*/
        _67opARCTAN();
        goto L3; // [89] 1843

        /** 			case ASSIGN, ASSIGN_I then*/
        case 18:
        case 113:

        /** 				opASSIGN()*/
        _67opASSIGN();
        goto L3; // [101] 1843

        /** 			case ASSIGN_OP_SLICE then*/
        case 150:

        /** 				opASSIGN_OP_SLICE()*/
        _67opASSIGN_OP_SLICE();
        goto L3; // [111] 1843

        /** 			case ASSIGN_OP_SUBS then*/
        case 149:

        /** 				opASSIGN_OP_SUBS()*/
        _67opASSIGN_OP_SUBS();
        goto L3; // [121] 1843

        /** 			case ASSIGN_SLICE then*/
        case 45:

        /** 				opASSIGN_SLICE()*/
        _67opASSIGN_SLICE();
        goto L3; // [131] 1843

        /** 			case ASSIGN_SUBS, ASSIGN_SUBS_CHECK, ASSIGN_SUBS_I then*/
        case 16:
        case 84:
        case 118:

        /** 				opASSIGN_SUBS()*/
        _67opASSIGN_SUBS();
        goto L3; // [145] 1843

        /** 			case ATOM_CHECK then*/
        case 101:

        /** 				opATOM_CHECK()*/
        _67opATOM_CHECK();
        goto L3; // [155] 1843

        /** 			case BADRETURNF then*/
        case 43:

        /** 				opBADRETURNF()*/
        _67opBADRETURNF();
        goto L3; // [165] 1843

        /** 			case C_FUNC then*/
        case 133:

        /** 				opC_FUNC()*/
        _67opC_FUNC();
        goto L3; // [175] 1843

        /** 			case C_PROC then*/
        case 132:

        /** 				opC_PROC()*/
        _67opC_PROC();
        goto L3; // [185] 1843

        /** 			case CALL then*/
        case 129:

        /** 				opCALL()*/
        _67opCALL();
        goto L3; // [195] 1843

        /** 			case CALL_BACK_RETURN then*/
        case 135:

        /** 				opCALL_BACK_RETURN()*/
        _67opCALL_BACK_RETURN();
        goto L3; // [205] 1843

        /** 			case CALL_PROC, CALL_FUNC then*/
        case 136:
        case 137:

        /** 				opCALL_PROC()*/
        _67opCALL_PROC();
        goto L3; // [217] 1843

        /** 			case CASE then*/
        case 186:

        /** 				opCASE()*/
        _67opCASE();
        goto L3; // [227] 1843

        /** 			case CLEAR_SCREEN then*/
        case 59:

        /** 				opCLEAR_SCREEN()*/
        _67opCLEAR_SCREEN();
        goto L3; // [237] 1843

        /** 			case CLOSE then*/
        case 86:

        /** 				opCLOSE()*/
        _67opCLOSE();
        goto L3; // [247] 1843

        /** 			case COMMAND_LINE then*/
        case 100:

        /** 				opCOMMAND_LINE()*/
        _67opCOMMAND_LINE();
        goto L3; // [257] 1843

        /** 			case COMPARE then*/
        case 76:

        /** 				opCOMPARE()*/
        _67opCOMPARE();
        goto L3; // [267] 1843

        /** 			case CONCAT then*/
        case 15:

        /** 				opCONCAT()*/
        _67opCONCAT();
        goto L3; // [277] 1843

        /** 			case CONCAT_N then*/
        case 157:

        /** 				opCONCAT_N()*/
        _67opCONCAT_N();
        goto L3; // [287] 1843

        /** 			case COS then*/
        case 81:

        /** 				opCOS()*/
        _67opCOS();
        goto L3; // [297] 1843

        /** 			case DATE then*/
        case 69:

        /** 				opDATE()*/
        _67opDATE();
        goto L3; // [307] 1843

        /** 			case DIV2 then*/
        case 98:

        /** 				opDIV2()*/
        _67opDIV2();
        goto L3; // [317] 1843

        /** 			case DIVIDE then*/
        case 14:

        /** 				opDIVIDE()*/
        _67opDIVIDE();
        goto L3; // [327] 1843

        /** 			case ELSE, EXIT, ENDWHILE, RETRY then*/
        case 23:
        case 61:
        case 22:
        case 184:

        /** 				opELSE()*/
        _67opELSE();
        goto L3; // [343] 1843

        /** 			case ENDFOR_GENERAL, ENDFOR_UP, ENDFOR_DOWN, ENDFOR_INT_UP,*/
        case 39:
        case 49:
        case 50:
        case 48:
        case 52:
        case 55:

        /** 				opENDFOR_GENERAL()*/
        _67opENDFOR_GENERAL();
        goto L3; // [363] 1843

        /** 			case ENDFOR_INT_UP1 then*/
        case 54:

        /** 				opENDFOR_INT_UP1()*/
        _67opENDFOR_INT_UP1();
        goto L3; // [373] 1843

        /** 			case EQUAL then*/
        case 153:

        /** 				opEQUAL()*/
        _67opEQUAL();
        goto L3; // [383] 1843

        /** 			case EQUALS then*/
        case 3:

        /** 				opEQUALS()*/
        _67opEQUALS();
        goto L3; // [393] 1843

        /** 			case EQUALS_IFW, EQUALS_IFW_I then*/
        case 104:
        case 121:

        /** 				opEQUALS_IFW()*/
        _67opEQUALS_IFW();
        goto L3; // [405] 1843

        /** 			case EXIT_BLOCK then*/
        case 206:

        /** 				opEXIT_BLOCK()*/
        _67opEXIT_BLOCK();
        goto L3; // [415] 1843

        /** 			case FIND then*/
        case 77:

        /** 				opFIND()*/
        _67opFIND();
        goto L3; // [425] 1843

        /** 			case FIND_FROM then*/
        case 176:

        /** 				opFIND_FROM()*/
        _67opFIND_FROM();
        goto L3; // [435] 1843

        /** 			case FLOOR then*/
        case 83:

        /** 				opFLOOR()*/
        _67opFLOOR();
        goto L3; // [445] 1843

        /** 			case FLOOR_DIV then*/
        case 63:

        /** 				opFLOOR_DIV()*/
        _67opFLOOR_DIV();
        goto L3; // [455] 1843

        /** 			case FLOOR_DIV2 then*/
        case 66:

        /** 				opFLOOR_DIV2()*/
        _67opFLOOR_DIV2();
        goto L3; // [465] 1843

        /** 			case FOR, FOR_I then*/
        case 21:
        case 125:

        /** 				opFOR()*/
        _67opFOR();
        goto L3; // [477] 1843

        /** 			case GET_KEY then*/
        case 79:

        /** 				opGET_KEY()*/
        _67opGET_KEY();
        goto L3; // [487] 1843

        /** 			case GETC then*/
        case 33:

        /** 				opGETC()*/
        _67opGETC();
        goto L3; // [497] 1843

        /** 			case GETENV then*/
        case 91:

        /** 				opGETENV()*/
        _67opGETENV();
        goto L3; // [507] 1843

        /** 			case GETS then*/
        case 17:

        /** 				opGETS()*/
        _67opGETS();
        goto L3; // [517] 1843

        /** 			case GLABEL then*/
        case 189:

        /** 				opGLABEL()*/
        _67opGLABEL();
        goto L3; // [527] 1843

        /** 			case GLOBAL_INIT_CHECK, PRIVATE_INIT_CHECK then*/
        case 109:
        case 30:

        /** 				opGLOBAL_INIT_CHECK()*/
        _67opGLOBAL_INIT_CHECK();
        goto L3; // [539] 1843

        /** 			case GOTO then*/
        case 188:

        /** 				opGOTO()*/
        _67opGOTO();
        goto L3; // [549] 1843

        /** 			case GREATER then*/
        case 6:

        /** 				opGREATER()*/
        _67opGREATER();
        goto L3; // [559] 1843

        /** 			case GREATER_IFW, GREATER_IFW_I then*/
        case 107:
        case 124:

        /** 				opGREATER_IFW()*/
        _67opGREATER_IFW();
        goto L3; // [571] 1843

        /** 			case GREATEREQ then*/
        case 2:

        /** 				opGREATEREQ()*/
        _67opGREATEREQ();
        goto L3; // [581] 1843

        /** 			case GREATEREQ_IFW, GREATEREQ_IFW_I then*/
        case 103:
        case 120:

        /** 				opGREATEREQ_IFW()*/
        _67opGREATEREQ_IFW();
        goto L3; // [593] 1843

        /** 			case HASH then*/
        case 194:

        /** 				opHASH()*/
        _67opHASH();
        goto L3; // [603] 1843

        /** 			case HEAD then*/
        case 198:

        /** 				opHEAD()*/
        _67opHEAD();
        goto L3; // [613] 1843

        /** 			case IF then*/
        case 20:

        /** 				opIF()*/
        _67opIF();
        goto L3; // [623] 1843

        /** 			case INSERT then*/
        case 191:

        /** 				opINSERT()*/
        _67opINSERT();
        goto L3; // [633] 1843

        /** 			case INTEGER_CHECK then*/
        case 96:

        /** 				opINTEGER_CHECK()*/
        _67opINTEGER_CHECK();
        goto L3; // [643] 1843

        /** 			case IS_A_SEQUENCE then*/
        case 68:

        /** 				opIS_A_SEQUENCE()*/
        _67opIS_A_SEQUENCE();
        goto L3; // [653] 1843

        /** 			case IS_AN_ATOM then*/
        case 67:

        /** 				opIS_AN_ATOM()*/
        _67opIS_AN_ATOM();
        goto L3; // [663] 1843

        /** 			case IS_AN_INTEGER then*/
        case 94:

        /** 				opIS_AN_INTEGER()*/
        _67opIS_AN_INTEGER();
        goto L3; // [673] 1843

        /** 			case IS_AN_OBJECT then*/
        case 40:

        /** 				opIS_AN_OBJECT()*/
        _67opIS_AN_OBJECT();
        goto L3; // [683] 1843

        /** 			case LENGTH then*/
        case 42:

        /** 				opLENGTH()*/
        _67opLENGTH();
        goto L3; // [693] 1843

        /** 			case LESS then*/
        case 1:

        /** 				opLESS()*/
        _67opLESS();
        goto L3; // [703] 1843

        /** 			case LESS_IFW_I, LESS_IFW then*/
        case 119:
        case 102:

        /** 				opLESS_IFW()*/
        _67opLESS_IFW();
        goto L3; // [715] 1843

        /** 			case LESSEQ then*/
        case 5:

        /** 				opLESSEQ()*/
        _67opLESSEQ();
        goto L3; // [725] 1843

        /** 			case LESSEQ_IFW, LESSEQ_IFW_I then*/
        case 106:
        case 123:

        /** 				opLESSEQ_IFW()*/
        _67opLESSEQ_IFW();
        goto L3; // [737] 1843

        /** 			case LHS_SUBS then*/
        case 95:

        /** 				opLHS_SUBS()*/
        _67opLHS_SUBS();
        goto L3; // [747] 1843

        /** 			case LHS_SUBS1 then*/
        case 161:

        /** 				opLHS_SUBS1()*/
        _67opLHS_SUBS1();
        goto L3; // [757] 1843

        /** 			case LHS_SUBS1_COPY then*/
        case 166:

        /** 				opLHS_SUBS1_COPY()*/
        _67opLHS_SUBS1_COPY();
        goto L3; // [767] 1843

        /** 			case LOG then*/
        case 74:

        /** 				opLOG()*/
        _67opLOG();
        goto L3; // [777] 1843

        /** 			case MACHINE_FUNC then*/
        case 111:

        /** 				opMACHINE_FUNC()*/
        _67opMACHINE_FUNC();
        goto L3; // [787] 1843

        /** 			case MACHINE_PROC then*/
        case 112:

        /** 				opMACHINE_PROC()*/
        _67opMACHINE_PROC();
        goto L3; // [797] 1843

        /** 			case MATCH then*/
        case 78:

        /** 				opMATCH()*/
        _67opMATCH();
        goto L3; // [807] 1843

        /** 			case MATCH_FROM then*/
        case 177:

        /** 				opMATCH_FROM()*/
        _67opMATCH_FROM();
        goto L3; // [817] 1843

        /** 			case MEM_COPY then*/
        case 130:

        /** 				opMEM_COPY()*/
        _67opMEM_COPY();
        goto L3; // [827] 1843

        /** 			case MEM_SET then*/
        case 131:

        /** 				opMEM_SET()*/
        _67opMEM_SET();
        goto L3; // [837] 1843

        /** 			case MINUS, MINUS_I then*/
        case 10:
        case 116:

        /** 				opMINUS()*/
        _67opMINUS();
        goto L3; // [849] 1843

        /** 			case MULTIPLY then*/
        case 13:

        /** 				opMULTIPLY()*/
        _67opMULTIPLY();
        goto L3; // [859] 1843

        /** 			case NOP2, SC2_NULL, ASSIGN_SUBS2, PLATFORM, END_PARAM_CHECK,*/
        case 110:
        case 145:
        case 148:
        case 155:
        case 156:
        case 158:
        case 159:

        /** 				opNOP2()*/
        _67opNOP2();
        goto L3; // [881] 1843

        /** 			case NOPSWITCH then*/
        case 187:

        /** 				opNOPSWITCH()*/
        _67opNOPSWITCH();
        goto L3; // [891] 1843

        /** 			case NOT then*/
        case 7:

        /** 				opNOT()*/
        _67opNOT();
        goto L3; // [901] 1843

        /** 			case NOT_BITS then*/
        case 51:

        /** 				opNOT_BITS()*/
        _67opNOT_BITS();
        goto L3; // [911] 1843

        /** 			case NOT_IFW then*/
        case 108:

        /** 				opNOT_IFW()*/
        _67opNOT_IFW();
        goto L3; // [921] 1843

        /** 			case NOTEQ then*/
        case 4:

        /** 				opNOTEQ()*/
        _67opNOTEQ();
        goto L3; // [931] 1843

        /** 			case NOTEQ_IFW, NOTEQ_IFW_I then*/
        case 105:
        case 122:

        /** 				opNOTEQ_IFW()*/
        _67opNOTEQ_IFW();
        goto L3; // [943] 1843

        /** 			case OPEN then*/
        case 37:

        /** 				opOPEN()*/
        _67opOPEN();
        goto L3; // [953] 1843

        /** 			case OPTION_SWITCHES then*/
        case 183:

        /** 				opOPTION_SWITCHES()*/
        _67opOPTION_SWITCHES();
        goto L3; // [963] 1843

        /** 			case OR then*/
        case 9:

        /** 				opOR()*/
        _67opOR();
        goto L3; // [973] 1843

        /** 			case OR_BITS then*/
        case 24:

        /** 				opOR_BITS()*/
        _67opOR_BITS();
        goto L3; // [983] 1843

        /** 			case PASSIGN_OP_SLICE then*/
        case 165:

        /** 				opPASSIGN_OP_SLICE()*/
        _67opPASSIGN_OP_SLICE();
        goto L3; // [993] 1843

        /** 			case PASSIGN_OP_SUBS then*/
        case 164:

        /** 				opPASSIGN_OP_SUBS()*/
        _67opPASSIGN_OP_SUBS();
        goto L3; // [1003] 1843

        /** 			case PASSIGN_SLICE then*/
        case 163:

        /** 				opPASSIGN_SLICE()*/
        _67opPASSIGN_SLICE();
        goto L3; // [1013] 1843

        /** 			case PASSIGN_SUBS then*/
        case 162:

        /** 				opPASSIGN_SUBS()*/
        _67opPASSIGN_SUBS();
        goto L3; // [1023] 1843

        /** 			case PEEK then*/
        case 127:

        /** 				opPEEK()*/
        _67opPEEK();
        goto L3; // [1033] 1843

        /** 			case PEEK_STRING then*/
        case 182:

        /** 				opPEEK_STRING()*/
        _67opPEEK_STRING();
        goto L3; // [1043] 1843

        /** 			case PEEK2S then*/
        case 179:

        /** 				opPEEK2S()*/
        _67opPEEK2S();
        goto L3; // [1053] 1843

        /** 			case PEEK2U then*/
        case 180:

        /** 				opPEEK2U()*/
        _67opPEEK2U();
        goto L3; // [1063] 1843

        /** 			case PEEK4S then*/
        case 139:

        /** 				opPEEK4S()*/
        _67opPEEK4S();
        goto L3; // [1073] 1843

        /** 			case PEEK4U then*/
        case 140:

        /** 				opPEEK4U()*/
        _67opPEEK4U();
        goto L3; // [1083] 1843

        /** 			case PEEKS then*/
        case 181:

        /** 				opPEEKS()*/
        _67opPEEKS();
        goto L3; // [1093] 1843

        /** 			case PLENGTH then*/
        case 160:

        /** 				opPLENGTH()*/
        _67opPLENGTH();
        goto L3; // [1103] 1843

        /** 			case PLUS, PLUS_I then*/
        case 11:
        case 115:

        /** 				opPLUS()*/
        _67opPLUS();
        goto L3; // [1115] 1843

        /** 			case PLUS1, PLUS1_I then*/
        case 93:
        case 117:

        /** 				opPLUS1()*/
        _67opPLUS1();
        goto L3; // [1127] 1843

        /** 			case POKE then*/
        case 128:

        /** 				opPOKE()*/
        _67opPOKE();
        goto L3; // [1137] 1843

        /** 			case POKE2 then*/
        case 178:

        /** 				opPOKE2()*/
        _67opPOKE2();
        goto L3; // [1147] 1843

        /** 			case POKE4 then*/
        case 138:

        /** 				opPOKE4()*/
        _67opPOKE4();
        goto L3; // [1157] 1843

        /** 			case POSITION then*/
        case 60:

        /** 				opPOSITION()*/
        _67opPOSITION();
        goto L3; // [1167] 1843

        /** 			case POWER then*/
        case 72:

        /** 				opPOWER()*/
        _67opPOWER();
        goto L3; // [1177] 1843

        /** 			case PREPEND then*/
        case 57:

        /** 				opPREPEND()*/
        _67opPREPEND();
        goto L3; // [1187] 1843

        /** 			case PRINT then*/
        case 19:

        /** 				opPRINT()*/
        _67opPRINT();
        goto L3; // [1197] 1843

        /** 			case PRINTF then*/
        case 38:

        /** 				opPRINTF()*/
        _67opPRINTF();
        goto L3; // [1207] 1843

        /** 			case PROC_TAIL then*/
        case 203:

        /** 				opPROC_TAIL()*/
        _67opPROC_TAIL();
        goto L3; // [1217] 1843

        /** 			case PROC then*/
        case 27:

        /** 				opPROC()*/
        _67opPROC();
        goto L3; // [1227] 1843

        /** 			case PROFILE, DISPLAY_VAR, ERASE_PRIVATE_NAMES, ERASE_SYMBOL then*/
        case 151:
        case 87:
        case 88:
        case 90:

        /** 				opPROFILE()*/
        _67opPROFILE();
        goto L3; // [1243] 1843

        /** 			case PUTS then*/
        case 44:

        /** 				opPUTS()*/
        _67opPUTS();
        goto L3; // [1253] 1843

        /** 			case QPRINT then*/
        case 36:

        /** 				opQPRINT()*/
        _67opQPRINT();
        goto L3; // [1263] 1843

        /** 			case RAND then*/
        case 62:

        /** 				opRAND()*/
        _67opRAND();
        goto L3; // [1273] 1843

        /** 			case REMAINDER then*/
        case 71:

        /** 				opREMAINDER()*/
        _67opREMAINDER();
        goto L3; // [1283] 1843

        /** 			case REMOVE then*/
        case 200:

        /** 				opREMOVE()*/
        _67opREMOVE();
        goto L3; // [1293] 1843

        /** 			case REPEAT then*/
        case 32:

        /** 				opREPEAT()*/
        _67opREPEAT();
        goto L3; // [1303] 1843

        /** 			case REPLACE then*/
        case 201:

        /** 				opREPLACE()*/
        _67opREPLACE();
        goto L3; // [1313] 1843

        /** 			case RETURNF then*/
        case 28:

        /** 				opRETURNF()*/
        _67opRETURNF();
        goto L3; // [1323] 1843

        /** 			case RETURNP then*/
        case 29:

        /** 				opRETURNP()*/
        _67opRETURNP();
        goto L3; // [1333] 1843

        /** 			case RETURNT then*/
        case 34:

        /** 				opRETURNT()*/
        _67opRETURNT();
        goto L3; // [1343] 1843

        /** 			case RHS_SLICE then*/
        case 46:

        /** 				opRHS_SLICE()*/
        _67opRHS_SLICE();
        goto L3; // [1353] 1843

        /** 			case RHS_SUBS, RHS_SUBS_CHECK, RHS_SUBS_I then*/
        case 25:
        case 92:
        case 114:

        /** 				opRHS_SUBS()*/
        _67opRHS_SUBS();
        goto L3; // [1367] 1843

        /** 			case RIGHT_BRACE_2 then*/
        case 85:

        /** 				opRIGHT_BRACE_2()*/
        _67opRIGHT_BRACE_2();
        goto L3; // [1377] 1843

        /** 			case RIGHT_BRACE_N then*/
        case 31:

        /** 				opRIGHT_BRACE_N()*/
        _67opRIGHT_BRACE_N();
        goto L3; // [1387] 1843

        /** 			case ROUTINE_ID then*/
        case 134:

        /** 				opROUTINE_ID()*/
        _67opROUTINE_ID();
        goto L3; // [1397] 1843

        /** 			case SC1_AND then*/
        case 141:

        /** 				opSC1_AND()*/
        _67opSC1_AND();
        goto L3; // [1407] 1843

        /** 			case SC1_AND_IF then*/
        case 146:

        /** 				opSC1_AND_IF()*/
        _67opSC1_AND_IF();
        goto L3; // [1417] 1843

        /** 			case SC1_OR then*/
        case 143:

        /** 				opSC1_OR()*/
        _67opSC1_OR();
        goto L3; // [1427] 1843

        /** 			case SC1_OR_IF then*/
        case 147:

        /** 				opSC1_OR_IF()*/
        _67opSC1_OR_IF();
        goto L3; // [1437] 1843

        /** 			case SC2_OR, SC2_AND then*/
        case 144:
        case 142:

        /** 				opSC2_OR()*/
        _67opSC2_OR();
        goto L3; // [1449] 1843

        /** 			case SEQUENCE_CHECK then*/
        case 97:

        /** 				opSEQUENCE_CHECK()*/
        _67opSEQUENCE_CHECK();
        goto L3; // [1459] 1843

        /** 			case SIN then*/
        case 80:

        /** 				opSIN()*/
        _67opSIN();
        goto L3; // [1469] 1843

        /** 			case SPACE_USED then*/
        case 75:

        /** 				opSPACE_USED()*/
        _67opSPACE_USED();
        goto L3; // [1479] 1843

        /** 			case SPLICE then*/
        case 190:

        /** 				opSPLICE()*/
        _67opSPLICE();
        goto L3; // [1489] 1843

        /** 			case SPRINTF then*/
        case 53:

        /** 				opSPRINTF()*/
        _67opSPRINTF();
        goto L3; // [1499] 1843

        /** 			case SQRT then*/
        case 41:

        /** 				opSQRT()*/
        _67opSQRT();
        goto L3; // [1509] 1843

        /** 			case STARTLINE then*/
        case 58:

        /** 				opSTARTLINE()*/
        _67opSTARTLINE();
        goto L3; // [1519] 1843

        /** 			case SWITCH, SWITCH_I then*/
        case 185:
        case 193:

        /** 				opSWITCH()*/
        _67opSWITCH();
        goto L3; // [1531] 1843

        /** 			case SWITCH_SPI then*/
        case 192:

        /** 				opSWITCH_SPI()*/
        _67opSWITCH_SPI();
        goto L3; // [1541] 1843

        /** 			case SWITCH_RT then*/
        case 202:

        /** 				opSWITCH_RT()*/
        _67opSWITCH_RT();
        goto L3; // [1551] 1843

        /** 			case SYSTEM then*/
        case 99:

        /** 				opSYSTEM()*/
        _67opSYSTEM();
        goto L3; // [1561] 1843

        /** 			case SYSTEM_EXEC then*/
        case 154:

        /** 				opSYSTEM_EXEC()*/
        _67opSYSTEM_EXEC();
        goto L3; // [1571] 1843

        /** 			case TAIL then*/
        case 199:

        /** 				opTAIL()*/
        _67opTAIL();
        goto L3; // [1581] 1843

        /** 			case TAN then*/
        case 82:

        /** 				opTAN()*/
        _67opTAN();
        goto L3; // [1591] 1843

        /** 			case TASK_CLOCK_START then*/
        case 175:

        /** 				opTASK_CLOCK_START()*/
        _67opTASK_CLOCK_START();
        goto L3; // [1601] 1843

        /** 			case TASK_CLOCK_STOP then*/
        case 174:

        /** 				opTASK_CLOCK_STOP()*/
        _67opTASK_CLOCK_STOP();
        goto L3; // [1611] 1843

        /** 			case TASK_CREATE then*/
        case 167:

        /** 				opTASK_CREATE()*/
        _67opTASK_CREATE();
        goto L3; // [1621] 1843

        /** 			case TASK_LIST then*/
        case 172:

        /** 				opTASK_LIST()*/
        _67opTASK_LIST();
        goto L3; // [1631] 1843

        /** 			case TASK_SCHEDULE then*/
        case 168:

        /** 				opTASK_SCHEDULE()*/
        _67opTASK_SCHEDULE();
        goto L3; // [1641] 1843

        /** 			case TASK_SELF then*/
        case 170:

        /** 				opTASK_SELF()*/
        _67opTASK_SELF();
        goto L3; // [1651] 1843

        /** 			case TASK_STATUS then*/
        case 173:

        /** 				opTASK_STATUS()*/
        _67opTASK_STATUS();
        goto L3; // [1661] 1843

        /** 			case TASK_SUSPEND then*/
        case 171:

        /** 				opTASK_SUSPEND()*/
        _67opTASK_SUSPEND();
        goto L3; // [1671] 1843

        /** 			case TASK_YIELD then*/
        case 169:

        /** 				opTASK_YIELD()*/
        _67opTASK_YIELD();
        goto L3; // [1681] 1843

        /** 			case TIME then*/
        case 70:

        /** 				opTIME()*/
        _67opTIME();
        goto L3; // [1691] 1843

        /** 			case TRACE then*/
        case 64:

        /** 				opTRACE()*/
        _67opTRACE();
        goto L3; // [1701] 1843

        /** 			case TYPE_CHECK then*/
        case 65:

        /** 				opTYPE_CHECK()*/
        _67opTYPE_CHECK();
        goto L3; // [1711] 1843

        /** 			case UMINUS then*/
        case 12:

        /** 				opUMINUS()*/
        _67opUMINUS();
        goto L3; // [1721] 1843

        /** 			case UPDATE_GLOBALS then*/
        case 89:

        /** 				opUPDATE_GLOBALS()*/
        _67opUPDATE_GLOBALS();
        goto L3; // [1731] 1843

        /** 			case WHILE then*/
        case 47:

        /** 				opWHILE()*/
        _67opWHILE();
        goto L3; // [1741] 1843

        /** 			case XOR then*/
        case 152:

        /** 				opXOR()*/
        _67opXOR();
        goto L3; // [1751] 1843

        /** 			case XOR_BITS then*/
        case 26:

        /** 				opXOR_BITS()*/
        _67opXOR_BITS();
        goto L3; // [1761] 1843

        /** 			case DELETE_ROUTINE then*/
        case 204:

        /** 				opDELETE_ROUTINE()*/
        _67opDELETE_ROUTINE();
        goto L3; // [1771] 1843

        /** 			case DELETE_OBJECT then*/
        case 205:

        /** 				opDELETE_OBJECT()*/
        _67opDELETE_OBJECT();
        goto L3; // [1781] 1843

        /** 			case REF_TEMP then*/
        case 207:

        /** 				pc += 2*/
        _67pc_63479 = _67pc_63479 + 2;
        goto L3; // [1795] 1843

        /** 			case DEREF_TEMP, NOVALUE_TEMP then*/
        case 208:
        case 209:

        /** 				opDEREF_TEMP()*/
        _67opDEREF_TEMP();
        goto L3; // [1807] 1843

        /** 			case COVERAGE_LINE then*/
        case 210:

        /** 				opCOVERAGE_LINE()*/
        _67opCOVERAGE_LINE();
        goto L3; // [1817] 1843

        /** 			case COVERAGE_ROUTINE then*/
        case 211:

        /** 				opCOVERAGE_ROUTINE()*/
        _67opCOVERAGE_ROUTINE();
        goto L3; // [1827] 1843

        /** 			case else*/
        default:

        /** 				RTFatal( sprintf("Unknown opcode: %d", op ) )*/
        _34835 = EPrintf(-9999999, _34834, _op_68621);
        _67RTFatal(_34835);
        _34835 = NOVALUE;
    ;}L3: 

    /** 	end while*/
    goto L1; // [1847] 15
L2: 

    /** 	keep_running = TRUE -- so higher-level do_exec() will keep running*/
    _67keep_running_63486 = _9TRUE_430;

    /** end procedure*/
    return;
    ;
}


void _67InitBackEnd()
{
    int _name_69014 = NOVALUE;
    int _34841 = NOVALUE;
    int _34840 = NOVALUE;
    int _34839 = NOVALUE;
    int _34838 = NOVALUE;
    int _34836 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	val = repeat(0, length(SymTab))*/
    if (IS_SEQUENCE(_27SymTab_10921)){
            _34836 = SEQ_PTR(_27SymTab_10921)->length;
    }
    else {
        _34836 = 1;
    }
    DeRef(_67val_63489);
    _67val_63489 = Repeat(0, _34836);
    _34836 = NOVALUE;

    /** 	for i = 1 to length(SymTab) do*/
    if (IS_SEQUENCE(_27SymTab_10921)){
            _34838 = SEQ_PTR(_27SymTab_10921)->length;
    }
    else {
        _34838 = 1;
    }
    {
        int _i_69019;
        _i_69019 = 1;
L1: 
        if (_i_69019 > _34838){
            goto L2; // [19] 68
        }

        /** 		val[i] = SymTab[i][S_OBJ] -- might be NOVALUE*/
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _34839 = (int)*(((s1_ptr)_2)->base + _i_69019);
        _2 = (int)SEQ_PTR(_34839);
        _34840 = (int)*(((s1_ptr)_2)->base + 1);
        _34839 = NOVALUE;
        Ref(_34840);
        _2 = (int)SEQ_PTR(_67val_63489);
        _2 = (int)(((s1_ptr)_2)->base + _i_69019);
        _1 = *(int *)_2;
        *(int *)_2 = _34840;
        if( _1 != _34840 ){
            DeRef(_1);
        }
        _34840 = NOVALUE;

        /** 		SymTab[i][S_OBJ] = 0*/
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _27SymTab_10921 = MAKE_SEQ(_2);
        }
        _3 = (int)(_i_69019 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 1);
        _1 = *(int *)_2;
        *(int *)_2 = 0;
        DeRef(_1);
        _34841 = NOVALUE;

        /** 	end for*/
        _i_69019 = _i_69019 + 1;
        goto L1; // [63] 26
L2: 
        ;
    }

    /** end procedure*/
    return;
    ;
}


void _67fake_init(int _ignore_69032)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_ignore_69032)) {
        _1 = (long)(DBL_PTR(_ignore_69032)->dbl);
        DeRefDS(_ignore_69032);
        _ignore_69032 = _1;
    }

    /** 	intoptions()*/
    _68intoptions();

    /** end procedure*/
    return;
    ;
}


void _67Execute(int _proc_69041, int _start_index_69042)
{
    int _34846 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_proc_69041)) {
        _1 = (long)(DBL_PTR(_proc_69041)->dbl);
        DeRefDS(_proc_69041);
        _proc_69041 = _1;
    }
    if (!IS_ATOM_INT(_start_index_69042)) {
        _1 = (long)(DBL_PTR(_start_index_69042)->dbl);
        DeRefDS(_start_index_69042);
        _start_index_69042 = _1;
    }

    /** 	InitBackEnd()*/
    _67InitBackEnd();

    /** 	current_task = 1*/
    _67current_task_63496 = 1;

    /** 	call_stack = {proc}*/
    _0 = _67call_stack_63497;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _proc_69041;
    _67call_stack_63497 = MAKE_SEQ(_1);
    DeRef(_0);

    /** 	pc = start_index*/
    _67pc_63479 = _start_index_69042;

    /** 	Code = SymTab[proc][S_CODE]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _34846 = (int)*(((s1_ptr)_2)->base + _proc_69041);
    DeRef(_26Code_12071);
    _2 = (int)SEQ_PTR(_34846);
    if (!IS_ATOM_INT(_26S_CODE_11666)){
        _26Code_12071 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_CODE_11666)->dbl));
    }
    else{
        _26Code_12071 = (int)*(((s1_ptr)_2)->base + _26S_CODE_11666);
    }
    Ref(_26Code_12071);
    _34846 = NOVALUE;

    /** 	do_exec()*/
    _67do_exec();

    /** end procedure*/
    return;
    ;
}


void _67BackEnd(int _ignore_69054)
{
    int _0, _1, _2;
    

    /** 	Execute(TopLevelSub, 1)*/
    _67Execute(_26TopLevelSub_11989, 1);

    /** end procedure*/
    return;
    ;
}


void _67OutputIL()
{
    int _0, _1, _2;
    

    /** end procedure*/
    return;
    ;
}


int _67extract_options(int _s_69063)
{
    int _0, _1, _2;
    

    /** 	return s*/
    return _s_69063;
    ;
}



// 0x4477212D
