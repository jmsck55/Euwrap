// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int _69GetSourceName()
{
    int _real_name_69067 = NOVALUE;
    int _fh_69068 = NOVALUE;
    int _has_extension_69070 = NOVALUE;
    int _34885 = NOVALUE;
    int _34883 = NOVALUE;
    int _34882 = NOVALUE;
    int _34879 = NOVALUE;
    int _34878 = NOVALUE;
    int _34877 = NOVALUE;
    int _34876 = NOVALUE;
    int _34875 = NOVALUE;
    int _34874 = NOVALUE;
    int _34871 = NOVALUE;
    int _34870 = NOVALUE;
    int _34868 = NOVALUE;
    int _34867 = NOVALUE;
    int _34866 = NOVALUE;
    int _34865 = NOVALUE;
    int _34864 = NOVALUE;
    int _34863 = NOVALUE;
    int _34860 = NOVALUE;
    int _34859 = NOVALUE;
    int _34857 = NOVALUE;
    int _34856 = NOVALUE;
    int _34853 = NOVALUE;
    int _0, _1, _2;
    

    /** 	boolean has_extension = FALSE*/
    _has_extension_69070 = _9FALSE_428;

    /** 	if length(src_name) = 0 then*/
    if (IS_SEQUENCE(_39src_name_48895)){
            _34853 = SEQ_PTR(_39src_name_48895)->length;
    }
    else {
        _34853 = 1;
    }
    if (_34853 != 0)
    goto L1; // [15] 30

    /** 		show_banner()*/
    _39show_banner();

    /** 		return -2 -- No source file*/
    DeRef(_real_name_69067);
    return -2;
L1: 

    /** 	ifdef WINDOWS then*/

    /** 		src_name = match_replace("/", src_name, "\\")*/
    RefDS(_23480);
    RefDS(_39src_name_48895);
    RefDS(_23592);
    _0 = _14match_replace(_23480, _39src_name_48895, _23592, 0);
    DeRefDS(_39src_name_48895);
    _39src_name_48895 = _0;

    /** 	for p = length(src_name) to 1 by -1 do*/
    if (IS_SEQUENCE(_39src_name_48895)){
            _34856 = SEQ_PTR(_39src_name_48895)->length;
    }
    else {
        _34856 = 1;
    }
    {
        int _p_69082;
        _p_69082 = _34856;
L2: 
        if (_p_69082 < 1){
            goto L3; // [52] 116
        }

        /** 		if src_name[p] = '.' then*/
        _2 = (int)SEQ_PTR(_39src_name_48895);
        _34857 = (int)*(((s1_ptr)_2)->base + _p_69082);
        if (binary_op_a(NOTEQ, _34857, 46)){
            _34857 = NOVALUE;
            goto L4; // [67] 85
        }
        _34857 = NOVALUE;

        /** 		   has_extension = TRUE*/
        _has_extension_69070 = _9TRUE_430;

        /** 		   exit*/
        goto L3; // [80] 116
        goto L5; // [82] 109
L4: 

        /** 		elsif find(src_name[p], SLASH_CHARS) then*/
        _2 = (int)SEQ_PTR(_39src_name_48895);
        _34859 = (int)*(((s1_ptr)_2)->base + _p_69082);
        _34860 = find_from(_34859, _36SLASH_CHARS_14319, 1);
        _34859 = NOVALUE;
        if (_34860 == 0)
        {
            _34860 = NOVALUE;
            goto L6; // [100] 108
        }
        else{
            _34860 = NOVALUE;
        }

        /** 		   exit*/
        goto L3; // [105] 116
L6: 
L5: 

        /** 	end for*/
        _p_69082 = _p_69082 + -1;
        goto L2; // [111] 59
L3: 
        ;
    }

    /** 	if not has_extension then*/
    if (_has_extension_69070 != 0)
    goto L7; // [118] 223

    /** 		known_files = append(known_files, "")*/
    RefDS(_22037);
    Append(&_27known_files_10922, _27known_files_10922, _22037);

    /** 		for i = 1 to length( DEFAULT_EXTS ) do*/
    _34863 = 4;
    {
        int _i_69101;
        _i_69101 = 1;
L8: 
        if (_i_69101 > 4){
            goto L9; // [138] 203
        }

        /** 			known_files[$] = src_name & DEFAULT_EXTS[i]*/
        if (IS_SEQUENCE(_27known_files_10922)){
                _34864 = SEQ_PTR(_27known_files_10922)->length;
        }
        else {
            _34864 = 1;
        }
        _2 = (int)SEQ_PTR(_36DEFAULT_EXTS_14300);
        _34865 = (int)*(((s1_ptr)_2)->base + _i_69101);
        Concat((object_ptr)&_34866, _39src_name_48895, _34865);
        _34865 = NOVALUE;
        _2 = (int)SEQ_PTR(_27known_files_10922);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _27known_files_10922 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _34864);
        _1 = *(int *)_2;
        *(int *)_2 = _34866;
        if( _1 != _34866 ){
            DeRef(_1);
        }
        _34866 = NOVALUE;

        /** 			real_name = e_path_find(known_files[$])*/
        if (IS_SEQUENCE(_27known_files_10922)){
                _34867 = SEQ_PTR(_27known_files_10922)->length;
        }
        else {
            _34867 = 1;
        }
        _2 = (int)SEQ_PTR(_27known_files_10922);
        _34868 = (int)*(((s1_ptr)_2)->base + _34867);
        Ref(_34868);
        _0 = _real_name_69067;
        _real_name_69067 = _38e_path_find(_34868);
        DeRef(_0);
        _34868 = NOVALUE;

        /** 			if sequence(real_name) then*/
        _34870 = IS_SEQUENCE(_real_name_69067);
        if (_34870 == 0)
        {
            _34870 = NOVALUE;
            goto LA; // [188] 196
        }
        else{
            _34870 = NOVALUE;
        }

        /** 				exit*/
        goto L9; // [193] 203
LA: 

        /** 		end for*/
        _i_69101 = _i_69101 + 1;
        goto L8; // [198] 145
L9: 
        ;
    }

    /** 		if atom(real_name) then*/
    _34871 = IS_ATOM(_real_name_69067);
    if (_34871 == 0)
    {
        _34871 = NOVALUE;
        goto LB; // [210] 259
    }
    else{
        _34871 = NOVALUE;
    }

    /** 			return -1*/
    DeRef(_real_name_69067);
    return -1;
    goto LB; // [220] 259
L7: 

    /** 		known_files = append(known_files, src_name)*/
    RefDS(_39src_name_48895);
    Append(&_27known_files_10922, _27known_files_10922, _39src_name_48895);

    /** 		real_name = e_path_find(src_name)*/
    RefDS(_39src_name_48895);
    _0 = _real_name_69067;
    _real_name_69067 = _38e_path_find(_39src_name_48895);
    DeRef(_0);

    /** 		if atom(real_name) then*/
    _34874 = IS_ATOM(_real_name_69067);
    if (_34874 == 0)
    {
        _34874 = NOVALUE;
        goto LC; // [248] 258
    }
    else{
        _34874 = NOVALUE;
    }

    /** 			return -1*/
    DeRef(_real_name_69067);
    return -1;
LC: 
LB: 

    /** 	known_files[$] = canonical_path(real_name,,CORRECT)*/
    if (IS_SEQUENCE(_27known_files_10922)){
            _34875 = SEQ_PTR(_27known_files_10922)->length;
    }
    else {
        _34875 = 1;
    }
    Ref(_real_name_69067);
    _34876 = _15canonical_path(_real_name_69067, 0, 2);
    _2 = (int)SEQ_PTR(_27known_files_10922);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27known_files_10922 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _34875);
    _1 = *(int *)_2;
    *(int *)_2 = _34876;
    if( _1 != _34876 ){
        DeRef(_1);
    }
    _34876 = NOVALUE;

    /** 	known_files_hash &= hash(known_files[$], stdhash:HSIEH32)*/
    if (IS_SEQUENCE(_27known_files_10922)){
            _34877 = SEQ_PTR(_27known_files_10922)->length;
    }
    else {
        _34877 = 1;
    }
    _2 = (int)SEQ_PTR(_27known_files_10922);
    _34878 = (int)*(((s1_ptr)_2)->base + _34877);
    _34879 = calc_hash(_34878, -5);
    _34878 = NOVALUE;
    Ref(_34879);
    Append(&_27known_files_hash_10923, _27known_files_hash_10923, _34879);
    DeRef(_34879);
    _34879 = NOVALUE;

    /** 	finished_files &= 0*/
    Append(&_27finished_files_10924, _27finished_files_10924, 0);

    /** 	file_include_depend = append( file_include_depend, { length( known_files ) } )*/
    if (IS_SEQUENCE(_27known_files_10922)){
            _34882 = SEQ_PTR(_27known_files_10922)->length;
    }
    else {
        _34882 = 1;
    }
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _34882;
    _34883 = MAKE_SEQ(_1);
    _34882 = NOVALUE;
    RefDS(_34883);
    Append(&_27file_include_depend_10925, _27file_include_depend_10925, _34883);
    DeRefDS(_34883);
    _34883 = NOVALUE;

    /** 	if file_exists(real_name) then*/
    Ref(_real_name_69067);
    _34885 = _15file_exists(_real_name_69067);
    if (_34885 == 0) {
        DeRef(_34885);
        _34885 = NOVALUE;
        goto LD; // [338] 362
    }
    else {
        if (!IS_ATOM_INT(_34885) && DBL_PTR(_34885)->dbl == 0.0){
            DeRef(_34885);
            _34885 = NOVALUE;
            goto LD; // [338] 362
        }
        DeRef(_34885);
        _34885 = NOVALUE;
    }
    DeRef(_34885);
    _34885 = NOVALUE;

    /** 		real_name = maybe_preprocess(real_name)*/
    Ref(_real_name_69067);
    _0 = _real_name_69067;
    _real_name_69067 = _63maybe_preprocess(_real_name_69067);
    DeRef(_0);

    /** 		fh = open_locked(real_name)*/
    Ref(_real_name_69067);
    _fh_69068 = _27open_locked(_real_name_69067);
    if (!IS_ATOM_INT(_fh_69068)) {
        _1 = (long)(DBL_PTR(_fh_69068)->dbl);
        DeRefDS(_fh_69068);
        _fh_69068 = _1;
    }

    /** 		return fh*/
    DeRef(_real_name_69067);
    return _fh_69068;
LD: 

    /** 	return -1*/
    DeRef(_real_name_69067);
    return -1;
    ;
}


void _69main()
{
    int _argc_69170 = NOVALUE;
    int _argv_69171 = NOVALUE;
    int _34915 = NOVALUE;
    int _34914 = NOVALUE;
    int _34911 = NOVALUE;
    int _34909 = NOVALUE;
    int _34907 = NOVALUE;
    int _34906 = NOVALUE;
    int _34905 = NOVALUE;
    int _34904 = NOVALUE;
    int _34903 = NOVALUE;
    int _34902 = NOVALUE;
    int _34901 = NOVALUE;
    int _34900 = NOVALUE;
    int _34896 = NOVALUE;
    int _0, _1, _2;
    

    /** 	argv = command_line()*/
    DeRef(_argv_69171);
    _argv_69171 = Command_Line();

    /** 	if BIND then*/
    if (_26BIND_11622 == 0)
    {
        goto L1; // [9] 21
    }
    else{
    }

    /** 		argv = extract_options(argv)*/
    RefDS(_argv_69171);
    _0 = _argv_69171;
    _argv_69171 = _2extract_options(_argv_69171);
    DeRefDS(_0);
L1: 

    /** 	argc = length(argv)*/
    if (IS_SEQUENCE(_argv_69171)){
            _argc_69170 = SEQ_PTR(_argv_69171)->length;
    }
    else {
        _argc_69170 = 1;
    }

    /** 	Argv = argv*/
    RefDS(_argv_69171);
    DeRef(_26Argv_11993);
    _26Argv_11993 = _argv_69171;

    /** 	Argc = argc*/
    _26Argc_11992 = _argc_69170;

    /** 	TempErrName = "ex.err"*/
    RefDS(_31763);
    DeRefi(_43TempErrName_48555);
    _43TempErrName_48555 = _31763;

    /** 	TempWarningName = STDERR*/
    DeRef(_26TempWarningName_11996);
    _26TempWarningName_11996 = 2;

    /** 	display_warnings = 1*/
    _43display_warnings_48556 = 1;

    /** 	InitGlobals()*/
    _30InitGlobals();

    /** 	if TRANSLATE or BIND or INTERPRET then*/
    if (_26TRANSLATE_11619 != 0) {
        _34896 = 1;
        goto L2; // [69] 79
    }
    _34896 = (_26BIND_11622 != 0);
L2: 
    if (_34896 != 0) {
        goto L3; // [79] 90
    }
    if (_26INTERPRET_11616 == 0)
    {
        goto L4; // [86] 96
    }
    else{
    }
L3: 

    /** 		InitBackEnd(0)*/
    _2InitBackEnd(0);
L4: 

    /** 	src_file = GetSourceName()*/
    _0 = _69GetSourceName();
    _26src_file_12104 = _0;
    if (!IS_ATOM_INT(_26src_file_12104)) {
        _1 = (long)(DBL_PTR(_26src_file_12104)->dbl);
        DeRefDS(_26src_file_12104);
        _26src_file_12104 = _1;
    }

    /** 	if src_file = -1 then*/
    if (_26src_file_12104 != -1)
    goto L5; // [107] 181

    /** 		screen_output(STDERR, GetMsgText(51, 0, {known_files[$]}))*/
    if (IS_SEQUENCE(_27known_files_10922)){
            _34900 = SEQ_PTR(_27known_files_10922)->length;
    }
    else {
        _34900 = 1;
    }
    _2 = (int)SEQ_PTR(_27known_files_10922);
    _34901 = (int)*(((s1_ptr)_2)->base + _34900);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_34901);
    *((int *)(_2+4)) = _34901;
    _34902 = MAKE_SEQ(_1);
    _34901 = NOVALUE;
    _34903 = _44GetMsgText(51, 0, _34902);
    _34902 = NOVALUE;
    _43screen_output(2, _34903);
    _34903 = NOVALUE;

    /** 		if not batch_job and not test_only then*/
    _34904 = (_26batch_job_11995 == 0);
    if (_34904 == 0) {
        goto L6; // [145] 173
    }
    _34906 = (_26test_only_11994 == 0);
    if (_34906 == 0)
    {
        DeRef(_34906);
        _34906 = NOVALUE;
        goto L6; // [155] 173
    }
    else{
        DeRef(_34906);
        _34906 = NOVALUE;
    }

    /** 			maybe_any_key(GetMsgText(277,0), STDERR)*/
    RefDS(_22037);
    _34907 = _44GetMsgText(277, 0, _22037);
    _41maybe_any_key(_34907, 2);
    _34907 = NOVALUE;
L6: 

    /** 		Cleanup(1)*/
    _43Cleanup(1);
    goto L7; // [178] 226
L5: 

    /** 	elsif src_file >= 0 then*/
    if (_26src_file_12104 < 0)
    goto L8; // [185] 225

    /** 		main_path = known_files[$]*/
    if (IS_SEQUENCE(_27known_files_10922)){
            _34909 = SEQ_PTR(_27known_files_10922)->length;
    }
    else {
        _34909 = 1;
    }
    DeRef(_26main_path_12103);
    _2 = (int)SEQ_PTR(_27known_files_10922);
    _26main_path_12103 = (int)*(((s1_ptr)_2)->base + _34909);
    Ref(_26main_path_12103);

    /** 		if length(main_path) = 0 then*/
    if (IS_SEQUENCE(_26main_path_12103)){
            _34911 = SEQ_PTR(_26main_path_12103)->length;
    }
    else {
        _34911 = 1;
    }
    if (_34911 != 0)
    goto L9; // [209] 224

    /** 			main_path = '.' & SLASH*/
    Concat((object_ptr)&_26main_path_12103, 46, 92);
L9: 
L8: 
L7: 

    /** 	if TRANSLATE then*/
    if (_26TRANSLATE_11619 == 0)
    {
        goto LA; // [230] 239
    }
    else{
    }

    /** 		InitBackEnd(1)*/
    _2InitBackEnd(1);
LA: 

    /** 	CheckPlatform()*/
    _2CheckPlatform();

    /** 	InitSymTab()*/
    _52InitSymTab();

    /** 	InitEmit()*/
    _37InitEmit();

    /** 	InitLex()*/
    _60InitLex();

    /** 	InitParser()*/
    _30InitParser();

    /** 	eu_namespace()*/
    _60eu_namespace();

    /** 	ifdef TRANSLATOR then*/

    /** 	main_file()*/
    _60main_file();

    /** 	check_coverage()*/
    _49check_coverage();

    /** 	parser()*/
    _30parser();

    /** 	init_coverage()*/
    _49init_coverage();

    /** 	if TRANSLATE then*/
    if (_26TRANSLATE_11619 == 0)
    {
        goto LB; // [285] 296
    }
    else{
    }

    /** 		BackEnd(0) -- translate IL to C*/
    _2BackEnd(0);
    goto LC; // [293] 336
LB: 

    /** 	elsif BIND then*/
    if (_26BIND_11622 == 0)
    {
        goto LD; // [300] 310
    }
    else{
    }

    /** 		OutputIL()*/
    _2OutputIL();
    goto LC; // [307] 336
LD: 

    /** 	elsif INTERPRET and not test_only then*/
    if (_26INTERPRET_11616 == 0) {
        goto LE; // [314] 335
    }
    _34915 = (_26test_only_11994 == 0);
    if (_34915 == 0)
    {
        DeRef(_34915);
        _34915 = NOVALUE;
        goto LE; // [324] 335
    }
    else{
        DeRef(_34915);
        _34915 = NOVALUE;
    }

    /** 		ifdef not STDDEBUG then*/

    /** 			BackEnd(0) -- execute IL using Euphoria-coded back-end*/
    _2BackEnd(0);
LE: 
LC: 

    /** 	Cleanup(0) -- does warnings*/
    _43Cleanup(0);

    /** end procedure*/
    DeRef(_argv_69171);
    DeRef(_34904);
    _34904 = NOVALUE;
    return;
    ;
}



// 0x734430AE
