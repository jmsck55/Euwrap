// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int _36host_platform()
{
    int _0, _1, _2;
    

    /** 	return ihost_platform*/
    return 2;
    ;
}


int _36GetPlatformDefines(int _for_translator_14343)
{
    int _local_defines_14344 = NOVALUE;
    int _lcmds_14354 = NOVALUE;
    int _fh_14356 = NOVALUE;
    int _sk_14376 = NOVALUE;
    int _7940 = NOVALUE;
    int _7939 = NOVALUE;
    int _7937 = NOVALUE;
    int _7934 = NOVALUE;
    int _7932 = NOVALUE;
    int _7930 = NOVALUE;
    int _7929 = NOVALUE;
    int _7927 = NOVALUE;
    int _7925 = NOVALUE;
    int _7923 = NOVALUE;
    int _7922 = NOVALUE;
    int _7920 = NOVALUE;
    int _7918 = NOVALUE;
    int _7916 = NOVALUE;
    int _7915 = NOVALUE;
    int _7913 = NOVALUE;
    int _7910 = NOVALUE;
    int _7908 = NOVALUE;
    int _7907 = NOVALUE;
    int _7905 = NOVALUE;
    int _7903 = NOVALUE;
    int _7901 = NOVALUE;
    int _7900 = NOVALUE;
    int _7897 = NOVALUE;
    int _7895 = NOVALUE;
    int _7892 = NOVALUE;
    int _7888 = NOVALUE;
    int _7887 = NOVALUE;
    int _7882 = NOVALUE;
    int _7881 = NOVALUE;
    int _7868 = NOVALUE;
    int _7865 = NOVALUE;
    int _7862 = NOVALUE;
    int _7861 = NOVALUE;
    int _7860 = NOVALUE;
    int _7856 = NOVALUE;
    int _7853 = NOVALUE;
    int _7850 = NOVALUE;
    int _7848 = NOVALUE;
    int _7847 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence local_defines = {}*/
    RefDS(_5);
    DeRef(_local_defines_14344);
    _local_defines_14344 = _5;

    /** 	if (IWINDOWS and not for_translator) or (TWINDOWS and for_translator) then*/
    if (_36IWINDOWS_14304 == 0) {
        _7847 = 0;
        goto L1; // [14] 25
    }
    _7848 = (0 == 0);
    _7847 = (_7848 != 0);
L1: 
    if (_7847 != 0) {
        goto L2; // [25] 44
    }
    if (_36TWINDOWS_14305 == 0) {
        DeRef(_7850);
        _7850 = 0;
        goto L3; // [31] 39
    }
    _7850 = (_for_translator_14343 != 0);
L3: 
    if (_7850 == 0)
    {
        _7850 = NOVALUE;
        goto L4; // [40] 326
    }
    else{
        _7850 = NOVALUE;
    }
L2: 

    /** 		local_defines &= {"WINDOWS", "WIN32"}*/
    RefDS(_7852);
    RefDS(_7851);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _7851;
    ((int *)_2)[2] = _7852;
    _7853 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_14344, _local_defines_14344, _7853);
    DeRefDS(_7853);
    _7853 = NOVALUE;

    /** 		sequence lcmds = command_line()*/
    DeRef(_lcmds_14354);
    _lcmds_14354 = Command_Line();

    /** 		integer fh*/

    /** 		fh = open(lcmds[1], "rb")*/
    _2 = (int)SEQ_PTR(_lcmds_14354);
    _7856 = (int)*(((s1_ptr)_2)->base + 1);
    _fh_14356 = EOpen(_7856, _1342, 0);
    _7856 = NOVALUE;

    /** 		if fh = -1 then*/
    if (_fh_14356 != -1)
    goto L5; // [73] 123

    /**  			if match("euiw", lower(lcmds[1])) != 0 then*/
    _2 = (int)SEQ_PTR(_lcmds_14354);
    _7860 = (int)*(((s1_ptr)_2)->base + 1);
    RefDS(_7860);
    _7861 = _12lower(_7860);
    _7860 = NOVALUE;
    _7862 = e_match_from(_7859, _7861, 1);
    DeRef(_7861);
    _7861 = NOVALUE;
    if (_7862 == 0)
    goto L6; // [92] 109

    /**  				local_defines &= { "GUI" }*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_7864);
    *((int *)(_2+4)) = _7864;
    _7865 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_14344, _local_defines_14344, _7865);
    DeRefDS(_7865);
    _7865 = NOVALUE;
    goto L7; // [106] 321
L6: 

    /**  				local_defines &= { "CONSOLE" }*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_7867);
    *((int *)(_2+4)) = _7867;
    _7868 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_14344, _local_defines_14344, _7868);
    DeRefDS(_7868);
    _7868 = NOVALUE;
    goto L7; // [120] 321
L5: 

    /** 			atom sk*/

    /** 			sk = seek(fh, #18) -- Fixed location of relocation table.*/
    _0 = _sk_14376;
    _sk_14376 = _18seek(_fh_14356, 24);
    DeRef(_0);

    /** 			sk = get_integer16(fh)*/
    _0 = _sk_14376;
    _sk_14376 = _18get_integer16(_fh_14356);
    DeRef(_0);

    /** 			if sk = #40 then*/
    if (binary_op_a(NOTEQ, _sk_14376, 64)){
        goto L8; // [140] 259
    }

    /** 				sk = seek(fh, #3C) -- Fixed location of COFF signature offset.*/
    _0 = _sk_14376;
    _sk_14376 = _18seek(_fh_14356, 60);
    DeRef(_0);

    /** 				sk = get_integer32(fh)*/
    _0 = _sk_14376;
    _sk_14376 = _18get_integer32(_fh_14356);
    DeRef(_0);

    /** 				sk = seek(fh, sk)*/
    Ref(_sk_14376);
    _0 = _sk_14376;
    _sk_14376 = _18seek(_fh_14356, _sk_14376);
    DeRef(_0);

    /** 				sk = get_integer16(fh)*/
    _0 = _sk_14376;
    _sk_14376 = _18get_integer16(_fh_14356);
    DeRef(_0);

    /** 				if sk = #4550 then -- "PE" in intel endian*/
    if (binary_op_a(NOTEQ, _sk_14376, 17744)){
        goto L9; // [172] 221
    }

    /** 					sk = get_integer16(fh)*/
    _0 = _sk_14376;
    _sk_14376 = _18get_integer16(_fh_14356);
    DeRef(_0);

    /** 					if sk = 0 then*/
    if (binary_op_a(NOTEQ, _sk_14376, 0)){
        goto LA; // [184] 212
    }

    /** 						sk = seek(fh, where(fh) + 88 )*/
    _7881 = _18where(_fh_14356);
    if (IS_ATOM_INT(_7881)) {
        _7882 = _7881 + 88;
        if ((long)((unsigned long)_7882 + (unsigned long)HIGH_BITS) >= 0) 
        _7882 = NewDouble((double)_7882);
    }
    else {
        _7882 = binary_op(PLUS, _7881, 88);
    }
    DeRef(_7881);
    _7881 = NOVALUE;
    _0 = _sk_14376;
    _sk_14376 = _18seek(_fh_14356, _7882);
    DeRef(_0);
    _7882 = NOVALUE;

    /** 						sk = get_integer16(fh)*/
    _0 = _sk_14376;
    _sk_14376 = _18get_integer16(_fh_14356);
    DeRef(_0);
    goto LB; // [209] 265
LA: 

    /** 						sk = 0	-- Don't know this format.*/
    DeRef(_sk_14376);
    _sk_14376 = 0;
    goto LB; // [218] 265
L9: 

    /** 				elsif sk = #454E then -- "NE" in intel endian*/
    if (binary_op_a(NOTEQ, _sk_14376, 17742)){
        goto LC; // [223] 250
    }

    /** 					sk = seek(fh, where(fh) + 54 )*/
    _7887 = _18where(_fh_14356);
    if (IS_ATOM_INT(_7887)) {
        _7888 = _7887 + 54;
        if ((long)((unsigned long)_7888 + (unsigned long)HIGH_BITS) >= 0) 
        _7888 = NewDouble((double)_7888);
    }
    else {
        _7888 = binary_op(PLUS, _7887, 54);
    }
    DeRef(_7887);
    _7887 = NOVALUE;
    _0 = _sk_14376;
    _sk_14376 = _18seek(_fh_14356, _7888);
    DeRef(_0);
    _7888 = NOVALUE;

    /** 					sk = getc(fh)*/
    DeRef(_sk_14376);
    if (_fh_14356 != last_r_file_no) {
        last_r_file_ptr = which_file(_fh_14356, EF_READ);
        last_r_file_no = _fh_14356;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _sk_14376 = getKBchar();
        }
        else
        _sk_14376 = getc(last_r_file_ptr);
    }
    else
    _sk_14376 = getc(last_r_file_ptr);
    goto LB; // [247] 265
LC: 

    /** 					sk = 0*/
    DeRef(_sk_14376);
    _sk_14376 = 0;
    goto LB; // [256] 265
L8: 

    /** 				sk = 0*/
    DeRef(_sk_14376);
    _sk_14376 = 0;
LB: 

    /** 			if sk = 2 then*/
    if (binary_op_a(NOTEQ, _sk_14376, 2)){
        goto LD; // [267] 284
    }

    /** 				local_defines &= { "GUI" }*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_7864);
    *((int *)(_2+4)) = _7864;
    _7892 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_14344, _local_defines_14344, _7892);
    DeRefDS(_7892);
    _7892 = NOVALUE;
    goto LE; // [281] 314
LD: 

    /** 			elsif sk = 3 then*/
    if (binary_op_a(NOTEQ, _sk_14376, 3)){
        goto LF; // [286] 303
    }

    /** 				local_defines &= { "CONSOLE" }*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_7867);
    *((int *)(_2+4)) = _7867;
    _7895 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_14344, _local_defines_14344, _7895);
    DeRefDS(_7895);
    _7895 = NOVALUE;
    goto LE; // [300] 314
LF: 

    /** 				local_defines &= { "UNKNOWN" }*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_640);
    *((int *)(_2+4)) = _640;
    _7897 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_14344, _local_defines_14344, _7897);
    DeRefDS(_7897);
    _7897 = NOVALUE;
LE: 

    /** 			close(fh)*/
    EClose(_fh_14356);
    DeRef(_sk_14376);
    _sk_14376 = NOVALUE;
L7: 
    DeRef(_lcmds_14354);
    _lcmds_14354 = NOVALUE;
    goto L10; // [323] 575
L4: 

    /** 		local_defines = append( local_defines, "CONSOLE" )*/
    RefDS(_7867);
    Append(&_local_defines_14344, _local_defines_14344, _7867);

    /** 		if (ILINUX and not for_translator) or (TLINUX and for_translator) then*/
    if (0 == 0) {
        _7900 = 0;
        goto L11; // [336] 347
    }
    _7901 = (_for_translator_14343 == 0);
    _7900 = (_7901 != 0);
L11: 
    if (_7900 != 0) {
        goto L12; // [347] 366
    }
    if (0 == 0) {
        DeRef(_7903);
        _7903 = 0;
        goto L13; // [353] 361
    }
    _7903 = (_for_translator_14343 != 0);
L13: 
    if (_7903 == 0)
    {
        _7903 = NOVALUE;
        goto L14; // [362] 379
    }
    else{
        _7903 = NOVALUE;
    }
L12: 

    /** 			local_defines &= {"UNIX", "LINUX"}*/
    RefDS(_7904);
    RefDS(_6418);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _6418;
    ((int *)_2)[2] = _7904;
    _7905 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_14344, _local_defines_14344, _7905);
    DeRefDS(_7905);
    _7905 = NOVALUE;
    goto L15; // [376] 574
L14: 

    /** 		elsif (IOSX and not for_translator) or (TOSX and for_translator) then*/
    if (0 == 0) {
        _7907 = 0;
        goto L16; // [383] 394
    }
    _7908 = (_for_translator_14343 == 0);
    _7907 = (_7908 != 0);
L16: 
    if (_7907 != 0) {
        goto L17; // [394] 413
    }
    if (0 == 0) {
        DeRef(_7910);
        _7910 = 0;
        goto L18; // [400] 408
    }
    _7910 = (_for_translator_14343 != 0);
L18: 
    if (_7910 == 0)
    {
        _7910 = NOVALUE;
        goto L19; // [409] 428
    }
    else{
        _7910 = NOVALUE;
    }
L17: 

    /** 			local_defines &= {"UNIX", "BSD", "OSX"}*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_6418);
    *((int *)(_2+4)) = _6418;
    RefDS(_7911);
    *((int *)(_2+8)) = _7911;
    RefDS(_7912);
    *((int *)(_2+12)) = _7912;
    _7913 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_14344, _local_defines_14344, _7913);
    DeRefDS(_7913);
    _7913 = NOVALUE;
    goto L15; // [425] 574
L19: 

    /** 		elsif (IOPENBSD and not for_translator) or (TOPENBSD and for_translator) then*/
    if (0 == 0) {
        _7915 = 0;
        goto L1A; // [432] 443
    }
    _7916 = (_for_translator_14343 == 0);
    _7915 = (_7916 != 0);
L1A: 
    if (_7915 != 0) {
        goto L1B; // [443] 462
    }
    if (0 == 0) {
        DeRef(_7918);
        _7918 = 0;
        goto L1C; // [449] 457
    }
    _7918 = (_for_translator_14343 != 0);
L1C: 
    if (_7918 == 0)
    {
        _7918 = NOVALUE;
        goto L1D; // [458] 477
    }
    else{
        _7918 = NOVALUE;
    }
L1B: 

    /** 			local_defines &= { "UNIX", "BSD", "OPENBSD"}*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_6418);
    *((int *)(_2+4)) = _6418;
    RefDS(_7911);
    *((int *)(_2+8)) = _7911;
    RefDS(_7919);
    *((int *)(_2+12)) = _7919;
    _7920 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_14344, _local_defines_14344, _7920);
    DeRefDS(_7920);
    _7920 = NOVALUE;
    goto L15; // [474] 574
L1D: 

    /** 		elsif (INETBSD and not for_translator) or (TNETBSD and for_translator) then*/
    if (0 == 0) {
        _7922 = 0;
        goto L1E; // [481] 492
    }
    _7923 = (_for_translator_14343 == 0);
    _7922 = (_7923 != 0);
L1E: 
    if (_7922 != 0) {
        goto L1F; // [492] 511
    }
    if (0 == 0) {
        DeRef(_7925);
        _7925 = 0;
        goto L20; // [498] 506
    }
    _7925 = (_for_translator_14343 != 0);
L20: 
    if (_7925 == 0)
    {
        _7925 = NOVALUE;
        goto L21; // [507] 526
    }
    else{
        _7925 = NOVALUE;
    }
L1F: 

    /** 			local_defines &= { "UNIX", "BSD", "NETBSD"}*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_6418);
    *((int *)(_2+4)) = _6418;
    RefDS(_7911);
    *((int *)(_2+8)) = _7911;
    RefDS(_7926);
    *((int *)(_2+12)) = _7926;
    _7927 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_14344, _local_defines_14344, _7927);
    DeRefDS(_7927);
    _7927 = NOVALUE;
    goto L15; // [523] 574
L21: 

    /** 		elsif (IBSD and not for_translator) or (TBSD and for_translator) then*/
    if (0 == 0) {
        _7929 = 0;
        goto L22; // [530] 541
    }
    _7930 = (_for_translator_14343 == 0);
    _7929 = (_7930 != 0);
L22: 
    if (_7929 != 0) {
        goto L23; // [541] 560
    }
    if (0 == 0) {
        DeRef(_7932);
        _7932 = 0;
        goto L24; // [547] 555
    }
    _7932 = (_for_translator_14343 != 0);
L24: 
    if (_7932 == 0)
    {
        _7932 = NOVALUE;
        goto L25; // [556] 573
    }
    else{
        _7932 = NOVALUE;
    }
L23: 

    /** 			local_defines &= {"UNIX", "BSD", "FREEBSD"}*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_6418);
    *((int *)(_2+4)) = _6418;
    RefDS(_7911);
    *((int *)(_2+8)) = _7911;
    RefDS(_7933);
    *((int *)(_2+12)) = _7933;
    _7934 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_14344, _local_defines_14344, _7934);
    DeRefDS(_7934);
    _7934 = NOVALUE;
L25: 
L15: 
L10: 

    /** 	return { "_PLAT_START" } & local_defines & { "_PLAT_STOP" }*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_7936);
    *((int *)(_2+4)) = _7936;
    _7937 = MAKE_SEQ(_1);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_7938);
    *((int *)(_2+4)) = _7938;
    _7939 = MAKE_SEQ(_1);
    {
        int concat_list[3];

        concat_list[0] = _7939;
        concat_list[1] = _local_defines_14344;
        concat_list[2] = _7937;
        Concat_N((object_ptr)&_7940, concat_list, 3);
    }
    DeRefDS(_7939);
    _7939 = NOVALUE;
    DeRefDS(_7937);
    _7937 = NOVALUE;
    DeRefDS(_local_defines_14344);
    DeRef(_7848);
    _7848 = NOVALUE;
    DeRef(_7901);
    _7901 = NOVALUE;
    DeRef(_7908);
    _7908 = NOVALUE;
    DeRef(_7916);
    _7916 = NOVALUE;
    DeRef(_7923);
    _7923 = NOVALUE;
    DeRef(_7930);
    _7930 = NOVALUE;
    return _7940;
    ;
}



// 0xE98AE042
