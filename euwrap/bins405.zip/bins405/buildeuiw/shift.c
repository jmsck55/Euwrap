// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

void _64init_op_info()
{
    int _SHORT_CIRCUIT_27045 = NOVALUE;
    int _15282 = NOVALUE;
    int _15281 = NOVALUE;
    int _15280 = NOVALUE;
    int _15279 = NOVALUE;
    int _15278 = NOVALUE;
    int _15277 = NOVALUE;
    int _15276 = NOVALUE;
    int _15275 = NOVALUE;
    int _15274 = NOVALUE;
    int _15273 = NOVALUE;
    int _15272 = NOVALUE;
    int _15271 = NOVALUE;
    int _15270 = NOVALUE;
    int _15269 = NOVALUE;
    int _15268 = NOVALUE;
    int _15267 = NOVALUE;
    int _15266 = NOVALUE;
    int _15264 = NOVALUE;
    int _15263 = NOVALUE;
    int _15262 = NOVALUE;
    int _15261 = NOVALUE;
    int _15260 = NOVALUE;
    int _15259 = NOVALUE;
    int _15258 = NOVALUE;
    int _15257 = NOVALUE;
    int _15256 = NOVALUE;
    int _15255 = NOVALUE;
    int _15254 = NOVALUE;
    int _15253 = NOVALUE;
    int _15252 = NOVALUE;
    int _15251 = NOVALUE;
    int _15250 = NOVALUE;
    int _15249 = NOVALUE;
    int _15248 = NOVALUE;
    int _15247 = NOVALUE;
    int _15246 = NOVALUE;
    int _15245 = NOVALUE;
    int _15244 = NOVALUE;
    int _15243 = NOVALUE;
    int _15242 = NOVALUE;
    int _15241 = NOVALUE;
    int _15240 = NOVALUE;
    int _15239 = NOVALUE;
    int _15238 = NOVALUE;
    int _15237 = NOVALUE;
    int _15236 = NOVALUE;
    int _15235 = NOVALUE;
    int _15234 = NOVALUE;
    int _15233 = NOVALUE;
    int _15232 = NOVALUE;
    int _15231 = NOVALUE;
    int _15230 = NOVALUE;
    int _15229 = NOVALUE;
    int _15228 = NOVALUE;
    int _15227 = NOVALUE;
    int _15226 = NOVALUE;
    int _15225 = NOVALUE;
    int _15224 = NOVALUE;
    int _15223 = NOVALUE;
    int _15222 = NOVALUE;
    int _15221 = NOVALUE;
    int _15220 = NOVALUE;
    int _15219 = NOVALUE;
    int _15218 = NOVALUE;
    int _15217 = NOVALUE;
    int _15216 = NOVALUE;
    int _15215 = NOVALUE;
    int _15214 = NOVALUE;
    int _15213 = NOVALUE;
    int _15212 = NOVALUE;
    int _15211 = NOVALUE;
    int _15210 = NOVALUE;
    int _15209 = NOVALUE;
    int _15208 = NOVALUE;
    int _15207 = NOVALUE;
    int _15206 = NOVALUE;
    int _15205 = NOVALUE;
    int _15204 = NOVALUE;
    int _15203 = NOVALUE;
    int _15202 = NOVALUE;
    int _15201 = NOVALUE;
    int _15200 = NOVALUE;
    int _15199 = NOVALUE;
    int _15198 = NOVALUE;
    int _15197 = NOVALUE;
    int _15196 = NOVALUE;
    int _15195 = NOVALUE;
    int _15194 = NOVALUE;
    int _15193 = NOVALUE;
    int _15192 = NOVALUE;
    int _15191 = NOVALUE;
    int _15190 = NOVALUE;
    int _15189 = NOVALUE;
    int _15188 = NOVALUE;
    int _15187 = NOVALUE;
    int _15186 = NOVALUE;
    int _15185 = NOVALUE;
    int _15184 = NOVALUE;
    int _15183 = NOVALUE;
    int _15182 = NOVALUE;
    int _15181 = NOVALUE;
    int _15180 = NOVALUE;
    int _15179 = NOVALUE;
    int _15178 = NOVALUE;
    int _15177 = NOVALUE;
    int _15176 = NOVALUE;
    int _15175 = NOVALUE;
    int _15174 = NOVALUE;
    int _15173 = NOVALUE;
    int _15172 = NOVALUE;
    int _15171 = NOVALUE;
    int _15170 = NOVALUE;
    int _15169 = NOVALUE;
    int _15168 = NOVALUE;
    int _15167 = NOVALUE;
    int _15166 = NOVALUE;
    int _15165 = NOVALUE;
    int _15164 = NOVALUE;
    int _15163 = NOVALUE;
    int _15162 = NOVALUE;
    int _15161 = NOVALUE;
    int _15160 = NOVALUE;
    int _15159 = NOVALUE;
    int _15158 = NOVALUE;
    int _15157 = NOVALUE;
    int _15156 = NOVALUE;
    int _15155 = NOVALUE;
    int _15154 = NOVALUE;
    int _15153 = NOVALUE;
    int _15151 = NOVALUE;
    int _15150 = NOVALUE;
    int _15149 = NOVALUE;
    int _15148 = NOVALUE;
    int _15147 = NOVALUE;
    int _15146 = NOVALUE;
    int _15145 = NOVALUE;
    int _15144 = NOVALUE;
    int _15143 = NOVALUE;
    int _15142 = NOVALUE;
    int _15141 = NOVALUE;
    int _15140 = NOVALUE;
    int _15139 = NOVALUE;
    int _15138 = NOVALUE;
    int _15137 = NOVALUE;
    int _15136 = NOVALUE;
    int _15135 = NOVALUE;
    int _15134 = NOVALUE;
    int _15133 = NOVALUE;
    int _15132 = NOVALUE;
    int _15131 = NOVALUE;
    int _15130 = NOVALUE;
    int _15129 = NOVALUE;
    int _15128 = NOVALUE;
    int _15127 = NOVALUE;
    int _15126 = NOVALUE;
    int _15125 = NOVALUE;
    int _15123 = NOVALUE;
    int _15122 = NOVALUE;
    int _15121 = NOVALUE;
    int _15120 = NOVALUE;
    int _15119 = NOVALUE;
    int _15118 = NOVALUE;
    int _15117 = NOVALUE;
    int _15116 = NOVALUE;
    int _15115 = NOVALUE;
    int _15114 = NOVALUE;
    int _15113 = NOVALUE;
    int _15112 = NOVALUE;
    int _15111 = NOVALUE;
    int _15110 = NOVALUE;
    int _15109 = NOVALUE;
    int _15108 = NOVALUE;
    int _15107 = NOVALUE;
    int _15106 = NOVALUE;
    int _15105 = NOVALUE;
    int _15104 = NOVALUE;
    int _15103 = NOVALUE;
    int _15102 = NOVALUE;
    int _15101 = NOVALUE;
    int _15100 = NOVALUE;
    int _15099 = NOVALUE;
    int _15098 = NOVALUE;
    int _15097 = NOVALUE;
    int _15096 = NOVALUE;
    int _15095 = NOVALUE;
    int _15094 = NOVALUE;
    int _15093 = NOVALUE;
    int _15092 = NOVALUE;
    int _15091 = NOVALUE;
    int _15090 = NOVALUE;
    int _15089 = NOVALUE;
    int _15088 = NOVALUE;
    int _15087 = NOVALUE;
    int _15086 = NOVALUE;
    int _15085 = NOVALUE;
    int _15084 = NOVALUE;
    int _15083 = NOVALUE;
    int _15082 = NOVALUE;
    int _15081 = NOVALUE;
    int _15080 = NOVALUE;
    int _15079 = NOVALUE;
    int _15078 = NOVALUE;
    int _15077 = NOVALUE;
    int _15076 = NOVALUE;
    int _15075 = NOVALUE;
    int _15074 = NOVALUE;
    int _15073 = NOVALUE;
    int _15072 = NOVALUE;
    int _15071 = NOVALUE;
    int _15070 = NOVALUE;
    int _15069 = NOVALUE;
    int _0, _1, _2;
    

    /** 	op_info = repeat( 0, MAX_OPCODE )*/
    DeRef(_64op_info_26647);
    _64op_info_26647 = Repeat(0, 213);

    /** 	op_info[ABORT               ] = { FIXED_SIZE, 2, {}, {}, {} }   -- ary: pun*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15069 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 126);
    *(int *)_2 = _15069;
    if( _1 != _15069 ){
    }
    _15069 = NOVALUE;

    /** 	op_info[AND                 ] = { FIXED_SIZE, 4, {}, {}, {} }   -- ary: bin*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15070 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 8);
    _1 = *(int *)_2;
    *(int *)_2 = _15070;
    if( _1 != _15070 ){
        DeRef(_1);
    }
    _15070 = NOVALUE;

    /** 	op_info[AND_BITS            ] = { FIXED_SIZE, 4, {}, {3}, {} }   -- ary: bin*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13429);
    *((int *)(_2+16)) = _13429;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15071 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 56);
    _1 = *(int *)_2;
    *(int *)_2 = _15071;
    if( _1 != _15071 ){
        DeRef(_1);
    }
    _15071 = NOVALUE;

    /** 	op_info[APPEND              ] = { FIXED_SIZE, 4, {}, {3}, {} }   -- ary: bin*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13429);
    *((int *)(_2+16)) = _13429;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15072 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 35);
    _1 = *(int *)_2;
    *(int *)_2 = _15072;
    if( _1 != _15072 ){
        DeRef(_1);
    }
    _15072 = NOVALUE;

    /** 	op_info[ARCTAN              ] = { FIXED_SIZE, 3, {}, {2}, {} }   -- ary: un*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13492);
    *((int *)(_2+16)) = _13492;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15073 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 73);
    _1 = *(int *)_2;
    *(int *)_2 = _15073;
    if( _1 != _15073 ){
        DeRef(_1);
    }
    _15073 = NOVALUE;

    /** 	op_info[ASSIGN              ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13492);
    *((int *)(_2+16)) = _13492;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15074 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 18);
    _1 = *(int *)_2;
    *(int *)_2 = _15074;
    if( _1 != _15074 ){
        DeRef(_1);
    }
    _15074 = NOVALUE;

    /** 	op_info[ASSIGN_I            ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13492);
    *((int *)(_2+16)) = _13492;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15075 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 113);
    _1 = *(int *)_2;
    *(int *)_2 = _15075;
    if( _1 != _15075 ){
        DeRef(_1);
    }
    _15075 = NOVALUE;

    /** 	op_info[ASSIGN_OP_SLICE     ] = { FIXED_SIZE, 5, {}, {4}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 5;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13652);
    *((int *)(_2+16)) = _13652;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15076 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 150);
    _1 = *(int *)_2;
    *(int *)_2 = _15076;
    if( _1 != _15076 ){
        DeRef(_1);
    }
    _15076 = NOVALUE;

    /** 	op_info[ASSIGN_OP_SUBS      ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13429);
    *((int *)(_2+16)) = _13429;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15077 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 149);
    _1 = *(int *)_2;
    *(int *)_2 = _15077;
    if( _1 != _15077 ){
        DeRef(_1);
    }
    _15077 = NOVALUE;

    /** 	op_info[ASSIGN_SLICE        ] = { FIXED_SIZE, 5, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 5;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13111);
    *((int *)(_2+16)) = _13111;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15078 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 45);
    _1 = *(int *)_2;
    *(int *)_2 = _15078;
    if( _1 != _15078 ){
        DeRef(_1);
    }
    _15078 = NOVALUE;

    /** 	op_info[ASSIGN_SUBS         ] = { FIXED_SIZE, 4, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13111);
    *((int *)(_2+16)) = _13111;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15079 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 16);
    _1 = *(int *)_2;
    *(int *)_2 = _15079;
    if( _1 != _15079 ){
        DeRef(_1);
    }
    _15079 = NOVALUE;

    /** 	op_info[ASSIGN_SUBS_CHECK   ] = { FIXED_SIZE, 4, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13111);
    *((int *)(_2+16)) = _13111;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15080 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 84);
    _1 = *(int *)_2;
    *(int *)_2 = _15080;
    if( _1 != _15080 ){
        DeRef(_1);
    }
    _15080 = NOVALUE;

    /** 	op_info[ASSIGN_SUBS_I       ] = { FIXED_SIZE, 4, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13111);
    *((int *)(_2+16)) = _13111;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15081 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 118);
    _1 = *(int *)_2;
    *(int *)_2 = _15081;
    if( _1 != _15081 ){
        DeRef(_1);
    }
    _15081 = NOVALUE;

    /** 	op_info[BADRETURNF          ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 1;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15082 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 43);
    _1 = *(int *)_2;
    *(int *)_2 = _15082;
    if( _1 != _15082 ){
        DeRef(_1);
    }
    _15082 = NOVALUE;

    /** 	op_info[CALL                ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15083 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 129);
    _1 = *(int *)_2;
    *(int *)_2 = _15083;
    if( _1 != _15083 ){
        DeRef(_1);
    }
    _15083 = NOVALUE;

    /** 	op_info[CALL_PROC           ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15084 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 136);
    _1 = *(int *)_2;
    *(int *)_2 = _15084;
    if( _1 != _15084 ){
        DeRef(_1);
    }
    _15084 = NOVALUE;

    /** 	op_info[CALL_FUNC           ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13429);
    *((int *)(_2+16)) = _13429;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15085 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 137);
    _1 = *(int *)_2;
    *(int *)_2 = _15085;
    if( _1 != _15085 ){
        DeRef(_1);
    }
    _15085 = NOVALUE;

    /** 	op_info[CASE                ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15086 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 186);
    _1 = *(int *)_2;
    *(int *)_2 = _15086;
    if( _1 != _15086 ){
        DeRef(_1);
    }
    _15086 = NOVALUE;

    /** 	op_info[CLEAR_SCREEN        ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 1;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15087 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 59);
    _1 = *(int *)_2;
    *(int *)_2 = _15087;
    if( _1 != _15087 ){
        DeRef(_1);
    }
    _15087 = NOVALUE;

    /** 	op_info[CLOSE               ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15088 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 86);
    _1 = *(int *)_2;
    *(int *)_2 = _15088;
    if( _1 != _15088 ){
        DeRef(_1);
    }
    _15088 = NOVALUE;

    /** 	op_info[COMMAND_LINE        ] = { FIXED_SIZE, 2, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13111);
    *((int *)(_2+16)) = _13111;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15089 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 100);
    _1 = *(int *)_2;
    *(int *)_2 = _15089;
    if( _1 != _15089 ){
        DeRef(_1);
    }
    _15089 = NOVALUE;

    /** 	op_info[COMPARE             ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13429);
    *((int *)(_2+16)) = _13429;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15090 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 76);
    _1 = *(int *)_2;
    *(int *)_2 = _15090;
    if( _1 != _15090 ){
        DeRef(_1);
    }
    _15090 = NOVALUE;

    /** 	op_info[CONCAT              ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13429);
    *((int *)(_2+16)) = _13429;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15091 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 15);
    _1 = *(int *)_2;
    *(int *)_2 = _15091;
    if( _1 != _15091 ){
        DeRef(_1);
    }
    _15091 = NOVALUE;

    /** 	op_info[COS                 ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13492);
    *((int *)(_2+16)) = _13492;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15092 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 81);
    _1 = *(int *)_2;
    *(int *)_2 = _15092;
    if( _1 != _15092 ){
        DeRef(_1);
    }
    _15092 = NOVALUE;

    /** 	op_info[COVERAGE_LINE       ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15093 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 210);
    _1 = *(int *)_2;
    *(int *)_2 = _15093;
    if( _1 != _15093 ){
        DeRef(_1);
    }
    _15093 = NOVALUE;

    /** 	op_info[COVERAGE_ROUTINE    ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15094 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 211);
    _1 = *(int *)_2;
    *(int *)_2 = _15094;
    if( _1 != _15094 ){
        DeRef(_1);
    }
    _15094 = NOVALUE;

    /** 	op_info[C_FUNC              ] = { FIXED_SIZE, 5, {}, {4}, {3} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 5;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13652);
    *((int *)(_2+16)) = _13652;
    RefDS(_13429);
    *((int *)(_2+20)) = _13429;
    _15095 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 133);
    _1 = *(int *)_2;
    *(int *)_2 = _15095;
    if( _1 != _15095 ){
        DeRef(_1);
    }
    _15095 = NOVALUE;

    /** 	op_info[C_PROC              ] = { FIXED_SIZE, 4, {}, {}, {3} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDSn(_5, 2);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    RefDS(_13429);
    *((int *)(_2+20)) = _13429;
    _15096 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 132);
    _1 = *(int *)_2;
    *(int *)_2 = _15096;
    if( _1 != _15096 ){
        DeRef(_1);
    }
    _15096 = NOVALUE;

    /** 	op_info[DATE                ] = { FIXED_SIZE, 2, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13111);
    *((int *)(_2+16)) = _13111;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15097 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 69);
    _1 = *(int *)_2;
    *(int *)_2 = _15097;
    if( _1 != _15097 ){
        DeRef(_1);
    }
    _15097 = NOVALUE;

    /** 	op_info[DELETE_ROUTINE      ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13429);
    *((int *)(_2+16)) = _13429;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15098 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 204);
    _1 = *(int *)_2;
    *(int *)_2 = _15098;
    if( _1 != _15098 ){
        DeRef(_1);
    }
    _15098 = NOVALUE;

    /** 	op_info[DELETE_OBJECT       ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15099 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 205);
    _1 = *(int *)_2;
    *(int *)_2 = _15099;
    if( _1 != _15099 ){
        DeRef(_1);
    }
    _15099 = NOVALUE;

    /** 	op_info[DIV2                ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13429);
    *((int *)(_2+16)) = _13429;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15100 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 98);
    _1 = *(int *)_2;
    *(int *)_2 = _15100;
    if( _1 != _15100 ){
        DeRef(_1);
    }
    _15100 = NOVALUE;

    /** 	op_info[DIVIDE              ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13429);
    *((int *)(_2+16)) = _13429;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15101 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 14);
    _1 = *(int *)_2;
    *(int *)_2 = _15101;
    if( _1 != _15101 ){
        DeRef(_1);
    }
    _15101 = NOVALUE;

    /** 	op_info[ELSE                ] = { FIXED_SIZE, 2, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDS(_13111);
    *((int *)(_2+12)) = _13111;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15102 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 23);
    _1 = *(int *)_2;
    *(int *)_2 = _15102;
    if( _1 != _15102 ){
        DeRef(_1);
    }
    _15102 = NOVALUE;

    /** 	op_info[EXIT                ] = { FIXED_SIZE, 2, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDS(_13111);
    *((int *)(_2+12)) = _13111;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15103 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 61);
    _1 = *(int *)_2;
    *(int *)_2 = _15103;
    if( _1 != _15103 ){
        DeRef(_1);
    }
    _15103 = NOVALUE;

    /** 	op_info[EXIT_BLOCK          ] = { FIXED_SIZE, 2, {},  {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15104 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 206);
    _1 = *(int *)_2;
    *(int *)_2 = _15104;
    if( _1 != _15104 ){
        DeRef(_1);
    }
    _15104 = NOVALUE;

    /** 	op_info[ENDWHILE            ] = { FIXED_SIZE, 2, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDS(_13111);
    *((int *)(_2+12)) = _13111;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15105 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 22);
    _1 = *(int *)_2;
    *(int *)_2 = _15105;
    if( _1 != _15105 ){
        DeRef(_1);
    }
    _15105 = NOVALUE;

    /** 	op_info[RETRY               ] = { FIXED_SIZE, 2, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDS(_13111);
    *((int *)(_2+12)) = _13111;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15106 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 184);
    _1 = *(int *)_2;
    *(int *)_2 = _15106;
    if( _1 != _15106 ){
        DeRef(_1);
    }
    _15106 = NOVALUE;

    /** 	op_info[GOTO                ] = { FIXED_SIZE, 2, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDS(_13111);
    *((int *)(_2+12)) = _13111;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15107 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 188);
    _1 = *(int *)_2;
    *(int *)_2 = _15107;
    if( _1 != _15107 ){
        DeRef(_1);
    }
    _15107 = NOVALUE;

    /** 	op_info[ENDFOR_GENERAL      ] = { FIXED_SIZE, 5, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 5;
    RefDS(_13111);
    *((int *)(_2+12)) = _13111;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15108 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 39);
    _1 = *(int *)_2;
    *(int *)_2 = _15108;
    if( _1 != _15108 ){
        DeRef(_1);
    }
    _15108 = NOVALUE;

    /** 	op_info[ENDFOR_UP           ] = { FIXED_SIZE, 4, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_13111);
    *((int *)(_2+12)) = _13111;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15109 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 49);
    _1 = *(int *)_2;
    *(int *)_2 = _15109;
    if( _1 != _15109 ){
        DeRef(_1);
    }
    _15109 = NOVALUE;

    /** 	op_info[ENDFOR_DOWN         ] = { FIXED_SIZE, 4, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_13111);
    *((int *)(_2+12)) = _13111;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15110 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 50);
    _1 = *(int *)_2;
    *(int *)_2 = _15110;
    if( _1 != _15110 ){
        DeRef(_1);
    }
    _15110 = NOVALUE;

    /** 	op_info[ENDFOR_INT_UP       ] = { FIXED_SIZE, 4, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_13111);
    *((int *)(_2+12)) = _13111;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15111 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 48);
    _1 = *(int *)_2;
    *(int *)_2 = _15111;
    if( _1 != _15111 ){
        DeRef(_1);
    }
    _15111 = NOVALUE;

    /** 	op_info[ENDFOR_INT_DOWN     ] = { FIXED_SIZE, 4, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_13111);
    *((int *)(_2+12)) = _13111;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15112 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 52);
    _1 = *(int *)_2;
    *(int *)_2 = _15112;
    if( _1 != _15112 ){
        DeRef(_1);
    }
    _15112 = NOVALUE;

    /** 	op_info[ENDFOR_INT_DOWN1    ] = { FIXED_SIZE, 4, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_13111);
    *((int *)(_2+12)) = _13111;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15113 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 55);
    _1 = *(int *)_2;
    *(int *)_2 = _15113;
    if( _1 != _15113 ){
        DeRef(_1);
    }
    _15113 = NOVALUE;

    /** 	op_info[ENDFOR_INT_UP1      ] = { FIXED_SIZE, 5, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 5;
    RefDS(_13111);
    *((int *)(_2+12)) = _13111;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15114 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 54);
    _1 = *(int *)_2;
    *(int *)_2 = _15114;
    if( _1 != _15114 ){
        DeRef(_1);
    }
    _15114 = NOVALUE;

    /** 	op_info[EQUAL               ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13429);
    *((int *)(_2+16)) = _13429;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15115 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 153);
    _1 = *(int *)_2;
    *(int *)_2 = _15115;
    if( _1 != _15115 ){
        DeRef(_1);
    }
    _15115 = NOVALUE;

    /** 	op_info[EQUALS              ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13429);
    *((int *)(_2+16)) = _13429;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15116 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = _15116;
    if( _1 != _15116 ){
        DeRef(_1);
    }
    _15116 = NOVALUE;

    /** 	op_info[EQUALS_IFW          ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_13429);
    *((int *)(_2+12)) = _13429;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15117 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 104);
    _1 = *(int *)_2;
    *(int *)_2 = _15117;
    if( _1 != _15117 ){
        DeRef(_1);
    }
    _15117 = NOVALUE;

    /** 	op_info[EQUALS_IFW_I        ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_13429);
    *((int *)(_2+12)) = _13429;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15118 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 121);
    _1 = *(int *)_2;
    *(int *)_2 = _15118;
    if( _1 != _15118 ){
        DeRef(_1);
    }
    _15118 = NOVALUE;

    /** 	op_info[FIND                ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13429);
    *((int *)(_2+16)) = _13429;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15119 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 77);
    _1 = *(int *)_2;
    *(int *)_2 = _15119;
    if( _1 != _15119 ){
        DeRef(_1);
    }
    _15119 = NOVALUE;

    /** 	op_info[FIND_FROM           ] = { FIXED_SIZE, 5, {}, {4}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 5;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13652);
    *((int *)(_2+16)) = _13652;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15120 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 176);
    _1 = *(int *)_2;
    *(int *)_2 = _15120;
    if( _1 != _15120 ){
        DeRef(_1);
    }
    _15120 = NOVALUE;

    /** 	op_info[FLOOR               ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13492);
    *((int *)(_2+16)) = _13492;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15121 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 83);
    _1 = *(int *)_2;
    *(int *)_2 = _15121;
    if( _1 != _15121 ){
        DeRef(_1);
    }
    _15121 = NOVALUE;

    /** 	op_info[FLOOR_DIV           ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13429);
    *((int *)(_2+16)) = _13429;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15122 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 63);
    _1 = *(int *)_2;
    *(int *)_2 = _15122;
    if( _1 != _15122 ){
        DeRef(_1);
    }
    _15122 = NOVALUE;

    /** 	op_info[FLOOR_DIV2          ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13429);
    *((int *)(_2+16)) = _13429;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15123 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 66);
    _1 = *(int *)_2;
    *(int *)_2 = _15123;
    if( _1 != _15123 ){
        DeRef(_1);
    }
    _15123 = NOVALUE;

    /** 	op_info[FOR                 ] = { FIXED_SIZE, 7, {6}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 7;
    RefDS(_15124);
    *((int *)(_2+12)) = _15124;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15125 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 21);
    _1 = *(int *)_2;
    *(int *)_2 = _15125;
    if( _1 != _15125 ){
        DeRef(_1);
    }
    _15125 = NOVALUE;

    /** 	op_info[FOR_I               ] = { FIXED_SIZE, 7, {6}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 7;
    RefDS(_15124);
    *((int *)(_2+12)) = _15124;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15126 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 125);
    _1 = *(int *)_2;
    *(int *)_2 = _15126;
    if( _1 != _15126 ){
        DeRef(_1);
    }
    _15126 = NOVALUE;

    /** 	op_info[GETC                ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13492);
    *((int *)(_2+16)) = _13492;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15127 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 33);
    _1 = *(int *)_2;
    *(int *)_2 = _15127;
    if( _1 != _15127 ){
        DeRef(_1);
    }
    _15127 = NOVALUE;

    /** 	op_info[GETENV              ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13492);
    *((int *)(_2+16)) = _13492;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15128 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 91);
    _1 = *(int *)_2;
    *(int *)_2 = _15128;
    if( _1 != _15128 ){
        DeRef(_1);
    }
    _15128 = NOVALUE;

    /** 	op_info[GETS                ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13492);
    *((int *)(_2+16)) = _13492;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15129 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 17);
    _1 = *(int *)_2;
    *(int *)_2 = _15129;
    if( _1 != _15129 ){
        DeRef(_1);
    }
    _15129 = NOVALUE;

    /** 	op_info[GET_KEY             ] = { FIXED_SIZE, 2, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13111);
    *((int *)(_2+16)) = _13111;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15130 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 79);
    _1 = *(int *)_2;
    *(int *)_2 = _15130;
    if( _1 != _15130 ){
        DeRef(_1);
    }
    _15130 = NOVALUE;

    /** 	op_info[GLABEL              ] = { FIXED_SIZE, 2, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDS(_13111);
    *((int *)(_2+12)) = _13111;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15131 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 189);
    _1 = *(int *)_2;
    *(int *)_2 = _15131;
    if( _1 != _15131 ){
        DeRef(_1);
    }
    _15131 = NOVALUE;

    /** 	op_info[GLOBAL_INIT_CHECK   ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15132 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 109);
    _1 = *(int *)_2;
    *(int *)_2 = _15132;
    if( _1 != _15132 ){
        DeRef(_1);
    }
    _15132 = NOVALUE;

    /** 	op_info[PRIVATE_INIT_CHECK  ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15133 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 30);
    _1 = *(int *)_2;
    *(int *)_2 = _15133;
    if( _1 != _15133 ){
        DeRef(_1);
    }
    _15133 = NOVALUE;

    /** 	op_info[GREATER             ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13429);
    *((int *)(_2+16)) = _13429;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15134 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 6);
    _1 = *(int *)_2;
    *(int *)_2 = _15134;
    if( _1 != _15134 ){
        DeRef(_1);
    }
    _15134 = NOVALUE;

    /** 	op_info[GREATEREQ           ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13429);
    *((int *)(_2+16)) = _13429;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15135 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _15135;
    if( _1 != _15135 ){
        DeRef(_1);
    }
    _15135 = NOVALUE;

    /** 	op_info[GREATEREQ_IFW       ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_13429);
    *((int *)(_2+12)) = _13429;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15136 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 103);
    _1 = *(int *)_2;
    *(int *)_2 = _15136;
    if( _1 != _15136 ){
        DeRef(_1);
    }
    _15136 = NOVALUE;

    /** 	op_info[GREATEREQ_IFW_I     ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_13429);
    *((int *)(_2+12)) = _13429;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15137 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 120);
    _1 = *(int *)_2;
    *(int *)_2 = _15137;
    if( _1 != _15137 ){
        DeRef(_1);
    }
    _15137 = NOVALUE;

    /** 	op_info[GREATER_IFW         ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_13429);
    *((int *)(_2+12)) = _13429;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15138 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 107);
    _1 = *(int *)_2;
    *(int *)_2 = _15138;
    if( _1 != _15138 ){
        DeRef(_1);
    }
    _15138 = NOVALUE;

    /** 	op_info[GREATER_IFW_I       ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_13429);
    *((int *)(_2+12)) = _13429;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15139 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 124);
    _1 = *(int *)_2;
    *(int *)_2 = _15139;
    if( _1 != _15139 ){
        DeRef(_1);
    }
    _15139 = NOVALUE;

    /** 	op_info[HASH                ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13429);
    *((int *)(_2+16)) = _13429;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15140 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 194);
    _1 = *(int *)_2;
    *(int *)_2 = _15140;
    if( _1 != _15140 ){
        DeRef(_1);
    }
    _15140 = NOVALUE;

    /** 	op_info[HEAD                ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13429);
    *((int *)(_2+16)) = _13429;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15141 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 198);
    _1 = *(int *)_2;
    *(int *)_2 = _15141;
    if( _1 != _15141 ){
        DeRef(_1);
    }
    _15141 = NOVALUE;

    /** 	op_info[IF                  ] = { FIXED_SIZE, 3, {2}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_13492);
    *((int *)(_2+12)) = _13492;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15142 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 20);
    _1 = *(int *)_2;
    *(int *)_2 = _15142;
    if( _1 != _15142 ){
        DeRef(_1);
    }
    _15142 = NOVALUE;

    /** 	op_info[INSERT              ] = { FIXED_SIZE, 5, {}, {4}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 5;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13652);
    *((int *)(_2+16)) = _13652;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15143 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 191);
    _1 = *(int *)_2;
    *(int *)_2 = _15143;
    if( _1 != _15143 ){
        DeRef(_1);
    }
    _15143 = NOVALUE;

    /** 	op_info[LENGTH              ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13492);
    *((int *)(_2+16)) = _13492;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15144 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 42);
    _1 = *(int *)_2;
    *(int *)_2 = _15144;
    if( _1 != _15144 ){
        DeRef(_1);
    }
    _15144 = NOVALUE;

    /** 	op_info[LESS                ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13429);
    *((int *)(_2+16)) = _13429;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15145 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _15145;
    if( _1 != _15145 ){
        DeRef(_1);
    }
    _15145 = NOVALUE;

    /** 	op_info[LESSEQ              ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13429);
    *((int *)(_2+16)) = _13429;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15146 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = _15146;
    if( _1 != _15146 ){
        DeRef(_1);
    }
    _15146 = NOVALUE;

    /** 	op_info[LESSEQ_IFW          ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_13429);
    *((int *)(_2+12)) = _13429;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15147 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 106);
    _1 = *(int *)_2;
    *(int *)_2 = _15147;
    if( _1 != _15147 ){
        DeRef(_1);
    }
    _15147 = NOVALUE;

    /** 	op_info[LESSEQ_IFW_I        ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_13429);
    *((int *)(_2+12)) = _13429;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15148 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 123);
    _1 = *(int *)_2;
    *(int *)_2 = _15148;
    if( _1 != _15148 ){
        DeRef(_1);
    }
    _15148 = NOVALUE;

    /** 	op_info[LESS_IFW            ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_13429);
    *((int *)(_2+12)) = _13429;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15149 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 102);
    _1 = *(int *)_2;
    *(int *)_2 = _15149;
    if( _1 != _15149 ){
        DeRef(_1);
    }
    _15149 = NOVALUE;

    /** 	op_info[LESS_IFW_I          ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_13429);
    *((int *)(_2+12)) = _13429;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15150 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 119);
    _1 = *(int *)_2;
    *(int *)_2 = _15150;
    if( _1 != _15150 ){
        DeRef(_1);
    }
    _15150 = NOVALUE;

    /** 	op_info[LHS_SUBS            ] = { FIXED_SIZE, 5, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 5;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13429);
    *((int *)(_2+16)) = _13429;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15151 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 95);
    _1 = *(int *)_2;
    *(int *)_2 = _15151;
    if( _1 != _15151 ){
        DeRef(_1);
    }
    _15151 = NOVALUE;

    /** 	op_info[LHS_SUBS1           ] = { FIXED_SIZE, 5, {}, {3,4}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 5;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_15152);
    *((int *)(_2+16)) = _15152;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15153 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 161);
    _1 = *(int *)_2;
    *(int *)_2 = _15153;
    if( _1 != _15153 ){
        DeRef(_1);
    }
    _15153 = NOVALUE;

    /** 	op_info[LHS_SUBS1_COPY      ] = { FIXED_SIZE, 5, {}, {3,4}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 5;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_15152);
    *((int *)(_2+16)) = _15152;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15154 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 166);
    _1 = *(int *)_2;
    *(int *)_2 = _15154;
    if( _1 != _15154 ){
        DeRef(_1);
    }
    _15154 = NOVALUE;

    /** 	op_info[LOG                 ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13492);
    *((int *)(_2+16)) = _13492;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15155 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 74);
    _1 = *(int *)_2;
    *(int *)_2 = _15155;
    if( _1 != _15155 ){
        DeRef(_1);
    }
    _15155 = NOVALUE;

    /** 	op_info[MACHINE_FUNC        ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13429);
    *((int *)(_2+16)) = _13429;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15156 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 111);
    _1 = *(int *)_2;
    *(int *)_2 = _15156;
    if( _1 != _15156 ){
        DeRef(_1);
    }
    _15156 = NOVALUE;

    /** 	op_info[MACHINE_PROC        ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15157 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 112);
    _1 = *(int *)_2;
    *(int *)_2 = _15157;
    if( _1 != _15157 ){
        DeRef(_1);
    }
    _15157 = NOVALUE;

    /** 	op_info[MATCH               ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13429);
    *((int *)(_2+16)) = _13429;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15158 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 78);
    _1 = *(int *)_2;
    *(int *)_2 = _15158;
    if( _1 != _15158 ){
        DeRef(_1);
    }
    _15158 = NOVALUE;

    /** 	op_info[MATCH_FROM          ] = { FIXED_SIZE, 5, {}, {4}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 5;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13652);
    *((int *)(_2+16)) = _13652;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15159 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 177);
    _1 = *(int *)_2;
    *(int *)_2 = _15159;
    if( _1 != _15159 ){
        DeRef(_1);
    }
    _15159 = NOVALUE;

    /** 	op_info[MEM_COPY            ] = { FIXED_SIZE, 4, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15160 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 130);
    _1 = *(int *)_2;
    *(int *)_2 = _15160;
    if( _1 != _15160 ){
        DeRef(_1);
    }
    _15160 = NOVALUE;

    /** 	op_info[MEM_SET             ] = { FIXED_SIZE, 4, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15161 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 131);
    _1 = *(int *)_2;
    *(int *)_2 = _15161;
    if( _1 != _15161 ){
        DeRef(_1);
    }
    _15161 = NOVALUE;

    /** 	op_info[MINUS               ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13429);
    *((int *)(_2+16)) = _13429;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15162 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 10);
    _1 = *(int *)_2;
    *(int *)_2 = _15162;
    if( _1 != _15162 ){
        DeRef(_1);
    }
    _15162 = NOVALUE;

    /** 	op_info[MINUS_I             ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13429);
    *((int *)(_2+16)) = _13429;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15163 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 116);
    _1 = *(int *)_2;
    *(int *)_2 = _15163;
    if( _1 != _15163 ){
        DeRef(_1);
    }
    _15163 = NOVALUE;

    /** 	op_info[MULTIPLY            ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13429);
    *((int *)(_2+16)) = _13429;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15164 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 13);
    _1 = *(int *)_2;
    *(int *)_2 = _15164;
    if( _1 != _15164 ){
        DeRef(_1);
    }
    _15164 = NOVALUE;

    /** 	op_info[NOP1                ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 1;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15165 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 159);
    _1 = *(int *)_2;
    *(int *)_2 = _15165;
    if( _1 != _15165 ){
        DeRef(_1);
    }
    _15165 = NOVALUE;

    /** 	op_info[NOPWHILE            ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 1;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15166 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 158);
    _1 = *(int *)_2;
    *(int *)_2 = _15166;
    if( _1 != _15166 ){
        DeRef(_1);
    }
    _15166 = NOVALUE;

    /** 	op_info[NOP2                ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15167 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 110);
    _1 = *(int *)_2;
    *(int *)_2 = _15167;
    if( _1 != _15167 ){
        DeRef(_1);
    }
    _15167 = NOVALUE;

    /** 	op_info[SC2_NULL            ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15168 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 145);
    _1 = *(int *)_2;
    *(int *)_2 = _15168;
    if( _1 != _15168 ){
        DeRef(_1);
    }
    _15168 = NOVALUE;

    /** 	op_info[ASSIGN_SUBS2        ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15169 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 148);
    _1 = *(int *)_2;
    *(int *)_2 = _15169;
    if( _1 != _15169 ){
        DeRef(_1);
    }
    _15169 = NOVALUE;

    /** 	op_info[PLATFORM            ] = { FIXED_SIZE, 2, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13111);
    *((int *)(_2+16)) = _13111;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15170 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 155);
    _1 = *(int *)_2;
    *(int *)_2 = _15170;
    if( _1 != _15170 ){
        DeRef(_1);
    }
    _15170 = NOVALUE;

    /** 	op_info[END_PARAM_CHECK     ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15171 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 156);
    _1 = *(int *)_2;
    *(int *)_2 = _15171;
    if( _1 != _15171 ){
        DeRef(_1);
    }
    _15171 = NOVALUE;

    /** 	op_info[NOPSWITCH           ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 1;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15172 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 187);
    _1 = *(int *)_2;
    *(int *)_2 = _15172;
    if( _1 != _15172 ){
        DeRef(_1);
    }
    _15172 = NOVALUE;

    /** 	op_info[NOT                 ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13492);
    *((int *)(_2+16)) = _13492;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15173 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 7);
    _1 = *(int *)_2;
    *(int *)_2 = _15173;
    if( _1 != _15173 ){
        DeRef(_1);
    }
    _15173 = NOVALUE;

    /** 	op_info[NOTEQ               ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13429);
    *((int *)(_2+16)) = _13429;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15174 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = _15174;
    if( _1 != _15174 ){
        DeRef(_1);
    }
    _15174 = NOVALUE;

    /** 	op_info[NOTEQ_IFW           ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_13429);
    *((int *)(_2+12)) = _13429;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15175 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 105);
    _1 = *(int *)_2;
    *(int *)_2 = _15175;
    if( _1 != _15175 ){
        DeRef(_1);
    }
    _15175 = NOVALUE;

    /** 	op_info[NOTEQ_IFW_I         ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_13429);
    *((int *)(_2+12)) = _13429;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15176 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 122);
    _1 = *(int *)_2;
    *(int *)_2 = _15176;
    if( _1 != _15176 ){
        DeRef(_1);
    }
    _15176 = NOVALUE;

    /** 	op_info[NOT_BITS            ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13492);
    *((int *)(_2+16)) = _13492;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15177 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 51);
    _1 = *(int *)_2;
    *(int *)_2 = _15177;
    if( _1 != _15177 ){
        DeRef(_1);
    }
    _15177 = NOVALUE;

    /** 	op_info[NOT_IFW             ] = { FIXED_SIZE, 3, {2}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_13492);
    *((int *)(_2+12)) = _13492;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15178 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 108);
    _1 = *(int *)_2;
    *(int *)_2 = _15178;
    if( _1 != _15178 ){
        DeRef(_1);
    }
    _15178 = NOVALUE;

    /** 	op_info[OPEN                ] = { FIXED_SIZE, 5, {}, {4}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 5;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13652);
    *((int *)(_2+16)) = _13652;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15179 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 37);
    _1 = *(int *)_2;
    *(int *)_2 = _15179;
    if( _1 != _15179 ){
        DeRef(_1);
    }
    _15179 = NOVALUE;

    /** 	op_info[OPTION_SWITCHES     ] = { FIXED_SIZE, 2, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13111);
    *((int *)(_2+16)) = _13111;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15180 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 183);
    _1 = *(int *)_2;
    *(int *)_2 = _15180;
    if( _1 != _15180 ){
        DeRef(_1);
    }
    _15180 = NOVALUE;

    /** 	op_info[OR                  ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13429);
    *((int *)(_2+16)) = _13429;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15181 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 9);
    _1 = *(int *)_2;
    *(int *)_2 = _15181;
    if( _1 != _15181 ){
        DeRef(_1);
    }
    _15181 = NOVALUE;

    /** 	op_info[OR_BITS             ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13429);
    *((int *)(_2+16)) = _13429;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15182 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 24);
    _1 = *(int *)_2;
    *(int *)_2 = _15182;
    if( _1 != _15182 ){
        DeRef(_1);
    }
    _15182 = NOVALUE;

    /** 	op_info[PASSIGN_OP_SLICE    ] = { FIXED_SIZE, 5, {}, {4}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 5;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13652);
    *((int *)(_2+16)) = _13652;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15183 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 165);
    _1 = *(int *)_2;
    *(int *)_2 = _15183;
    if( _1 != _15183 ){
        DeRef(_1);
    }
    _15183 = NOVALUE;

    /** 	op_info[PASSIGN_OP_SUBS     ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13429);
    *((int *)(_2+16)) = _13429;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15184 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 164);
    _1 = *(int *)_2;
    *(int *)_2 = _15184;
    if( _1 != _15184 ){
        DeRef(_1);
    }
    _15184 = NOVALUE;

    /** 	op_info[PASSIGN_SLICE       ] = { FIXED_SIZE, 5, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 5;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13111);
    *((int *)(_2+16)) = _13111;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15185 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 163);
    _1 = *(int *)_2;
    *(int *)_2 = _15185;
    if( _1 != _15185 ){
        DeRef(_1);
    }
    _15185 = NOVALUE;

    /** 	op_info[PASSIGN_SUBS        ] = { FIXED_SIZE, 4, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13111);
    *((int *)(_2+16)) = _13111;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15186 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 162);
    _1 = *(int *)_2;
    *(int *)_2 = _15186;
    if( _1 != _15186 ){
        DeRef(_1);
    }
    _15186 = NOVALUE;

    /** 	op_info[PEEK_STRING         ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13492);
    *((int *)(_2+16)) = _13492;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15187 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 182);
    _1 = *(int *)_2;
    *(int *)_2 = _15187;
    if( _1 != _15187 ){
        DeRef(_1);
    }
    _15187 = NOVALUE;

    /** 	op_info[PEEK2U              ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13492);
    *((int *)(_2+16)) = _13492;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15188 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 180);
    _1 = *(int *)_2;
    *(int *)_2 = _15188;
    if( _1 != _15188 ){
        DeRef(_1);
    }
    _15188 = NOVALUE;

    /** 	op_info[PEEK2S              ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13492);
    *((int *)(_2+16)) = _13492;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15189 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 179);
    _1 = *(int *)_2;
    *(int *)_2 = _15189;
    if( _1 != _15189 ){
        DeRef(_1);
    }
    _15189 = NOVALUE;

    /** 	op_info[PEEK4U              ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13492);
    *((int *)(_2+16)) = _13492;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15190 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 140);
    _1 = *(int *)_2;
    *(int *)_2 = _15190;
    if( _1 != _15190 ){
        DeRef(_1);
    }
    _15190 = NOVALUE;

    /** 	op_info[PEEK4S              ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13492);
    *((int *)(_2+16)) = _13492;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15191 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 139);
    _1 = *(int *)_2;
    *(int *)_2 = _15191;
    if( _1 != _15191 ){
        DeRef(_1);
    }
    _15191 = NOVALUE;

    /** 	op_info[PEEKS               ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13492);
    *((int *)(_2+16)) = _13492;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15192 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 181);
    _1 = *(int *)_2;
    *(int *)_2 = _15192;
    if( _1 != _15192 ){
        DeRef(_1);
    }
    _15192 = NOVALUE;

    /** 	op_info[PEEK                ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13492);
    *((int *)(_2+16)) = _13492;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15193 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 127);
    _1 = *(int *)_2;
    *(int *)_2 = _15193;
    if( _1 != _15193 ){
        DeRef(_1);
    }
    _15193 = NOVALUE;

    /** 	op_info[PLENGTH             ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13492);
    *((int *)(_2+16)) = _13492;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15194 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 160);
    _1 = *(int *)_2;
    *(int *)_2 = _15194;
    if( _1 != _15194 ){
        DeRef(_1);
    }
    _15194 = NOVALUE;

    /** 	op_info[PLUS                ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13429);
    *((int *)(_2+16)) = _13429;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15195 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 11);
    _1 = *(int *)_2;
    *(int *)_2 = _15195;
    if( _1 != _15195 ){
        DeRef(_1);
    }
    _15195 = NOVALUE;

    /** 	op_info[PLUS_I              ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13429);
    *((int *)(_2+16)) = _13429;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15196 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 115);
    _1 = *(int *)_2;
    *(int *)_2 = _15196;
    if( _1 != _15196 ){
        DeRef(_1);
    }
    _15196 = NOVALUE;

    /** 	op_info[PLUS1               ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13429);
    *((int *)(_2+16)) = _13429;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15197 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 93);
    _1 = *(int *)_2;
    *(int *)_2 = _15197;
    if( _1 != _15197 ){
        DeRef(_1);
    }
    _15197 = NOVALUE;

    /** 	op_info[PLUS1_I             ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13429);
    *((int *)(_2+16)) = _13429;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15198 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 117);
    _1 = *(int *)_2;
    *(int *)_2 = _15198;
    if( _1 != _15198 ){
        DeRef(_1);
    }
    _15198 = NOVALUE;

    /** 	op_info[POKE                ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15199 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 128);
    _1 = *(int *)_2;
    *(int *)_2 = _15199;
    if( _1 != _15199 ){
        DeRef(_1);
    }
    _15199 = NOVALUE;

    /** 	op_info[POKE2               ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15200 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 178);
    _1 = *(int *)_2;
    *(int *)_2 = _15200;
    if( _1 != _15200 ){
        DeRef(_1);
    }
    _15200 = NOVALUE;

    /** 	op_info[POKE4               ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15201 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 138);
    _1 = *(int *)_2;
    *(int *)_2 = _15201;
    if( _1 != _15201 ){
        DeRef(_1);
    }
    _15201 = NOVALUE;

    /** 	op_info[POSITION            ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15202 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 60);
    _1 = *(int *)_2;
    *(int *)_2 = _15202;
    if( _1 != _15202 ){
        DeRef(_1);
    }
    _15202 = NOVALUE;

    /** 	op_info[POWER               ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13429);
    *((int *)(_2+16)) = _13429;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15203 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 72);
    _1 = *(int *)_2;
    *(int *)_2 = _15203;
    if( _1 != _15203 ){
        DeRef(_1);
    }
    _15203 = NOVALUE;

    /** 	op_info[PREPEND             ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13429);
    *((int *)(_2+16)) = _13429;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15204 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 57);
    _1 = *(int *)_2;
    *(int *)_2 = _15204;
    if( _1 != _15204 ){
        DeRef(_1);
    }
    _15204 = NOVALUE;

    /** 	op_info[PRINT               ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15205 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 19);
    _1 = *(int *)_2;
    *(int *)_2 = _15205;
    if( _1 != _15205 ){
        DeRef(_1);
    }
    _15205 = NOVALUE;

    /** 	op_info[PRINTF              ] = { FIXED_SIZE, 4, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15206 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 38);
    _1 = *(int *)_2;
    *(int *)_2 = _15206;
    if( _1 != _15206 ){
        DeRef(_1);
    }
    _15206 = NOVALUE;

    /** 	op_info[PROFILE             ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15207 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 151);
    _1 = *(int *)_2;
    *(int *)_2 = _15207;
    if( _1 != _15207 ){
        DeRef(_1);
    }
    _15207 = NOVALUE;

    /** 	op_info[DISPLAY_VAR         ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15208 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 87);
    _1 = *(int *)_2;
    *(int *)_2 = _15208;
    if( _1 != _15208 ){
        DeRef(_1);
    }
    _15208 = NOVALUE;

    /** 	op_info[ERASE_PRIVATE_NAMES ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15209 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 88);
    _1 = *(int *)_2;
    *(int *)_2 = _15209;
    if( _1 != _15209 ){
        DeRef(_1);
    }
    _15209 = NOVALUE;

    /** 	op_info[ERASE_SYMBOL        ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15210 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 90);
    _1 = *(int *)_2;
    *(int *)_2 = _15210;
    if( _1 != _15210 ){
        DeRef(_1);
    }
    _15210 = NOVALUE;

    /** 	op_info[PUTS                ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15211 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 44);
    _1 = *(int *)_2;
    *(int *)_2 = _15211;
    if( _1 != _15211 ){
        DeRef(_1);
    }
    _15211 = NOVALUE;

    /** 	op_info[QPRINT              ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15212 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 36);
    _1 = *(int *)_2;
    *(int *)_2 = _15212;
    if( _1 != _15212 ){
        DeRef(_1);
    }
    _15212 = NOVALUE;

    /** 	op_info[RAND                ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13492);
    *((int *)(_2+16)) = _13492;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15213 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 62);
    _1 = *(int *)_2;
    *(int *)_2 = _15213;
    if( _1 != _15213 ){
        DeRef(_1);
    }
    _15213 = NOVALUE;

    /** 	op_info[REMAINDER           ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13429);
    *((int *)(_2+16)) = _13429;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15214 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 71);
    _1 = *(int *)_2;
    *(int *)_2 = _15214;
    if( _1 != _15214 ){
        DeRef(_1);
    }
    _15214 = NOVALUE;

    /** 	op_info[REMOVE              ] = { FIXED_SIZE, 5, {}, {4}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 5;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13652);
    *((int *)(_2+16)) = _13652;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15215 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 200);
    _1 = *(int *)_2;
    *(int *)_2 = _15215;
    if( _1 != _15215 ){
        DeRef(_1);
    }
    _15215 = NOVALUE;

    /** 	op_info[REPEAT              ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13429);
    *((int *)(_2+16)) = _13429;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15216 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 32);
    _1 = *(int *)_2;
    *(int *)_2 = _15216;
    if( _1 != _15216 ){
        DeRef(_1);
    }
    _15216 = NOVALUE;

    /** 	op_info[REPLACE             ] = { FIXED_SIZE, 6, {}, {5}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 6;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13140);
    *((int *)(_2+16)) = _13140;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15217 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 201);
    _1 = *(int *)_2;
    *(int *)_2 = _15217;
    if( _1 != _15217 ){
        DeRef(_1);
    }
    _15217 = NOVALUE;

    /** 	op_info[RETURNF             ] = { FIXED_SIZE, 4, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15218 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 28);
    _1 = *(int *)_2;
    *(int *)_2 = _15218;
    if( _1 != _15218 ){
        DeRef(_1);
    }
    _15218 = NOVALUE;

    /** 	op_info[RETURNP             ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15219 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 29);
    _1 = *(int *)_2;
    *(int *)_2 = _15219;
    if( _1 != _15219 ){
        DeRef(_1);
    }
    _15219 = NOVALUE;

    /** 	op_info[RETURNT             ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 1;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15220 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 34);
    _1 = *(int *)_2;
    *(int *)_2 = _15220;
    if( _1 != _15220 ){
        DeRef(_1);
    }
    _15220 = NOVALUE;

    /** 	op_info[RHS_SLICE           ] = { FIXED_SIZE, 5, {}, {4}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 5;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13652);
    *((int *)(_2+16)) = _13652;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15221 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 46);
    _1 = *(int *)_2;
    *(int *)_2 = _15221;
    if( _1 != _15221 ){
        DeRef(_1);
    }
    _15221 = NOVALUE;

    /** 	op_info[RHS_SUBS            ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13429);
    *((int *)(_2+16)) = _13429;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15222 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 25);
    _1 = *(int *)_2;
    *(int *)_2 = _15222;
    if( _1 != _15222 ){
        DeRef(_1);
    }
    _15222 = NOVALUE;

    /** 	op_info[RHS_SUBS_I          ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13429);
    *((int *)(_2+16)) = _13429;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15223 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 114);
    _1 = *(int *)_2;
    *(int *)_2 = _15223;
    if( _1 != _15223 ){
        DeRef(_1);
    }
    _15223 = NOVALUE;

    /** 	op_info[RHS_SUBS_CHECK      ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13429);
    *((int *)(_2+16)) = _13429;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15224 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 92);
    _1 = *(int *)_2;
    *(int *)_2 = _15224;
    if( _1 != _15224 ){
        DeRef(_1);
    }
    _15224 = NOVALUE;

    /** 	op_info[RIGHT_BRACE_2       ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13429);
    *((int *)(_2+16)) = _13429;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15225 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 85);
    _1 = *(int *)_2;
    *(int *)_2 = _15225;
    if( _1 != _15225 ){
        DeRef(_1);
    }
    _15225 = NOVALUE;

    /** 	op_info[ROUTINE_ID          ] = { FIXED_SIZE, 6 - TRANSLATE, {}, { 4 + not TRANSLATE }, {} }*/
    _15226 = 6 - _26TRANSLATE_11619;
    _15227 = (_26TRANSLATE_11619 == 0);
    _15228 = 4 + _15227;
    if ((long)((unsigned long)_15228 + (unsigned long)HIGH_BITS) >= 0) 
    _15228 = NewDouble((double)_15228);
    _15227 = NOVALUE;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _15228;
    _15229 = MAKE_SEQ(_1);
    _15228 = NOVALUE;
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = _15226;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _15229;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15230 = MAKE_SEQ(_1);
    _15229 = NOVALUE;
    _15226 = NOVALUE;
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 134);
    _1 = *(int *)_2;
    *(int *)_2 = _15230;
    if( _1 != _15230 ){
        DeRef(_1);
    }
    _15230 = NOVALUE;

    /** 	op_info[SC2_OR              ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15231 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 144);
    _1 = *(int *)_2;
    *(int *)_2 = _15231;
    if( _1 != _15231 ){
        DeRef(_1);
    }
    _15231 = NOVALUE;

    /** 	op_info[SC2_AND             ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15232 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 142);
    _1 = *(int *)_2;
    *(int *)_2 = _15232;
    if( _1 != _15232 ){
        DeRef(_1);
    }
    _15232 = NOVALUE;

    /** 	op_info[SIN                 ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13492);
    *((int *)(_2+16)) = _13492;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15233 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 80);
    _1 = *(int *)_2;
    *(int *)_2 = _15233;
    if( _1 != _15233 ){
        DeRef(_1);
    }
    _15233 = NOVALUE;

    /** 	op_info[SPACE_USED          ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15234 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 75);
    _1 = *(int *)_2;
    *(int *)_2 = _15234;
    if( _1 != _15234 ){
        DeRef(_1);
    }
    _15234 = NOVALUE;

    /** 	op_info[SPLICE              ] = { FIXED_SIZE, 5, {}, {4}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 5;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13652);
    *((int *)(_2+16)) = _13652;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15235 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 190);
    _1 = *(int *)_2;
    *(int *)_2 = _15235;
    if( _1 != _15235 ){
        DeRef(_1);
    }
    _15235 = NOVALUE;

    /** 	op_info[SPRINTF             ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13429);
    *((int *)(_2+16)) = _13429;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15236 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 53);
    _1 = *(int *)_2;
    *(int *)_2 = _15236;
    if( _1 != _15236 ){
        DeRef(_1);
    }
    _15236 = NOVALUE;

    /** 	op_info[SQRT                ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13492);
    *((int *)(_2+16)) = _13492;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15237 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 41);
    _1 = *(int *)_2;
    *(int *)_2 = _15237;
    if( _1 != _15237 ){
        DeRef(_1);
    }
    _15237 = NOVALUE;

    /** 	op_info[STARTLINE           ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15238 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 58);
    _1 = *(int *)_2;
    *(int *)_2 = _15238;
    if( _1 != _15238 ){
        DeRef(_1);
    }
    _15238 = NOVALUE;

    /** 	op_info[SWITCH              ] = { FIXED_SIZE, 5, {4}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 5;
    RefDS(_13652);
    *((int *)(_2+12)) = _13652;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15239 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 185);
    _1 = *(int *)_2;
    *(int *)_2 = _15239;
    if( _1 != _15239 ){
        DeRef(_1);
    }
    _15239 = NOVALUE;

    /** 	op_info[SWITCH_I            ] = { FIXED_SIZE, 5, {4}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 5;
    RefDS(_13652);
    *((int *)(_2+12)) = _13652;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15240 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 193);
    _1 = *(int *)_2;
    *(int *)_2 = _15240;
    if( _1 != _15240 ){
        DeRef(_1);
    }
    _15240 = NOVALUE;

    /** 	op_info[SWITCH_SPI          ] = { FIXED_SIZE, 5, {4}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 5;
    RefDS(_13652);
    *((int *)(_2+12)) = _13652;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15241 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 192);
    _1 = *(int *)_2;
    *(int *)_2 = _15241;
    if( _1 != _15241 ){
        DeRef(_1);
    }
    _15241 = NOVALUE;

    /** 	op_info[SWITCH_RT           ] = { FIXED_SIZE, 5, {4}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 5;
    RefDS(_13652);
    *((int *)(_2+12)) = _13652;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15242 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 202);
    _1 = *(int *)_2;
    *(int *)_2 = _15242;
    if( _1 != _15242 ){
        DeRef(_1);
    }
    _15242 = NOVALUE;

    /** 	op_info[SYSTEM              ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15243 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 99);
    _1 = *(int *)_2;
    *(int *)_2 = _15243;
    if( _1 != _15243 ){
        DeRef(_1);
    }
    _15243 = NOVALUE;

    /** 	op_info[SYSTEM_EXEC         ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13429);
    *((int *)(_2+16)) = _13429;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15244 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 154);
    _1 = *(int *)_2;
    *(int *)_2 = _15244;
    if( _1 != _15244 ){
        DeRef(_1);
    }
    _15244 = NOVALUE;

    /** 	op_info[TAIL                ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13429);
    *((int *)(_2+16)) = _13429;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15245 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 199);
    _1 = *(int *)_2;
    *(int *)_2 = _15245;
    if( _1 != _15245 ){
        DeRef(_1);
    }
    _15245 = NOVALUE;

    /** 	op_info[TAN                 ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13492);
    *((int *)(_2+16)) = _13492;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15246 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 82);
    _1 = *(int *)_2;
    *(int *)_2 = _15246;
    if( _1 != _15246 ){
        DeRef(_1);
    }
    _15246 = NOVALUE;

    /** 	op_info[TASK_CLOCK_START    ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 1;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15247 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 175);
    _1 = *(int *)_2;
    *(int *)_2 = _15247;
    if( _1 != _15247 ){
        DeRef(_1);
    }
    _15247 = NOVALUE;

    /** 	op_info[TASK_CLOCK_STOP     ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 1;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15248 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 174);
    _1 = *(int *)_2;
    *(int *)_2 = _15248;
    if( _1 != _15248 ){
        DeRef(_1);
    }
    _15248 = NOVALUE;

    /** 	op_info[TASK_CREATE         ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13429);
    *((int *)(_2+16)) = _13429;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15249 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 167);
    _1 = *(int *)_2;
    *(int *)_2 = _15249;
    if( _1 != _15249 ){
        DeRef(_1);
    }
    _15249 = NOVALUE;

    /** 	op_info[TASK_LIST           ] = { FIXED_SIZE, 2, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13111);
    *((int *)(_2+16)) = _13111;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15250 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 172);
    _1 = *(int *)_2;
    *(int *)_2 = _15250;
    if( _1 != _15250 ){
        DeRef(_1);
    }
    _15250 = NOVALUE;

    /** 	op_info[TASK_SCHEDULE       ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15251 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 168);
    _1 = *(int *)_2;
    *(int *)_2 = _15251;
    if( _1 != _15251 ){
        DeRef(_1);
    }
    _15251 = NOVALUE;

    /** 	op_info[TASK_SELF           ] = { FIXED_SIZE, 2, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13111);
    *((int *)(_2+16)) = _13111;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15252 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 170);
    _1 = *(int *)_2;
    *(int *)_2 = _15252;
    if( _1 != _15252 ){
        DeRef(_1);
    }
    _15252 = NOVALUE;

    /** 	op_info[TASK_STATUS         ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13492);
    *((int *)(_2+16)) = _13492;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15253 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 173);
    _1 = *(int *)_2;
    *(int *)_2 = _15253;
    if( _1 != _15253 ){
        DeRef(_1);
    }
    _15253 = NOVALUE;

    /** 	op_info[TASK_SUSPEND        ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15254 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 171);
    _1 = *(int *)_2;
    *(int *)_2 = _15254;
    if( _1 != _15254 ){
        DeRef(_1);
    }
    _15254 = NOVALUE;

    /** 	op_info[TASK_YIELD          ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 1;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15255 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 169);
    _1 = *(int *)_2;
    *(int *)_2 = _15255;
    if( _1 != _15255 ){
        DeRef(_1);
    }
    _15255 = NOVALUE;

    /** 	op_info[TIME                ] = { FIXED_SIZE, 2, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13111);
    *((int *)(_2+16)) = _13111;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15256 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 70);
    _1 = *(int *)_2;
    *(int *)_2 = _15256;
    if( _1 != _15256 ){
        DeRef(_1);
    }
    _15256 = NOVALUE;

    /** 	op_info[TRACE               ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15257 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 64);
    _1 = *(int *)_2;
    *(int *)_2 = _15257;
    if( _1 != _15257 ){
        DeRef(_1);
    }
    _15257 = NOVALUE;

    /** 	op_info[TYPE_CHECK          ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 1;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15258 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 65);
    _1 = *(int *)_2;
    *(int *)_2 = _15258;
    if( _1 != _15258 ){
        DeRef(_1);
    }
    _15258 = NOVALUE;

    /** 	op_info[UMINUS              ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13492);
    *((int *)(_2+16)) = _13492;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15259 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 12);
    _1 = *(int *)_2;
    *(int *)_2 = _15259;
    if( _1 != _15259 ){
        DeRef(_1);
    }
    _15259 = NOVALUE;

    /** 	op_info[UPDATE_GLOBALS      ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 1;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15260 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 89);
    _1 = *(int *)_2;
    *(int *)_2 = _15260;
    if( _1 != _15260 ){
        DeRef(_1);
    }
    _15260 = NOVALUE;

    /** 	op_info[WHILE               ] = { FIXED_SIZE, 3, {2}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_13492);
    *((int *)(_2+12)) = _13492;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15261 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 47);
    _1 = *(int *)_2;
    *(int *)_2 = _15261;
    if( _1 != _15261 ){
        DeRef(_1);
    }
    _15261 = NOVALUE;

    /** 	op_info[XOR                 ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13429);
    *((int *)(_2+16)) = _13429;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15262 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 152);
    _1 = *(int *)_2;
    *(int *)_2 = _15262;
    if( _1 != _15262 ){
        DeRef(_1);
    }
    _15262 = NOVALUE;

    /** 	op_info[XOR_BITS            ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13429);
    *((int *)(_2+16)) = _13429;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15263 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 26);
    _1 = *(int *)_2;
    *(int *)_2 = _15263;
    if( _1 != _15263 ){
        DeRef(_1);
    }
    _15263 = NOVALUE;

    /** 	op_info[TYPE_CHECK_FORWARD  ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15264 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 197);
    _1 = *(int *)_2;
    *(int *)_2 = _15264;
    if( _1 != _15264 ){
        DeRef(_1);
    }
    _15264 = NOVALUE;

    /** 	sequence SHORT_CIRCUIT = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _0 = _SHORT_CIRCUIT_27045;
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_13429);
    *((int *)(_2+12)) = _13429;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _SHORT_CIRCUIT_27045 = MAKE_SEQ(_1);
    DeRef(_0);

    /** 	op_info[SC1_AND_IF          ] = SHORT_CIRCUIT*/
    RefDS(_SHORT_CIRCUIT_27045);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 146);
    _1 = *(int *)_2;
    *(int *)_2 = _SHORT_CIRCUIT_27045;
    DeRef(_1);

    /** 	op_info[SC1_OR_IF           ] = SHORT_CIRCUIT*/
    RefDS(_SHORT_CIRCUIT_27045);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 147);
    _1 = *(int *)_2;
    *(int *)_2 = _SHORT_CIRCUIT_27045;
    DeRef(_1);

    /** 	op_info[SC1_AND             ] = SHORT_CIRCUIT*/
    RefDS(_SHORT_CIRCUIT_27045);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 141);
    _1 = *(int *)_2;
    *(int *)_2 = _SHORT_CIRCUIT_27045;
    DeRef(_1);

    /** 	op_info[SC1_OR              ] = SHORT_CIRCUIT*/
    RefDS(_SHORT_CIRCUIT_27045);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 143);
    _1 = *(int *)_2;
    *(int *)_2 = _SHORT_CIRCUIT_27045;
    DeRef(_1);

    /** 	op_info[ATOM_CHECK          ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15266 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 101);
    _1 = *(int *)_2;
    *(int *)_2 = _15266;
    if( _1 != _15266 ){
        DeRef(_1);
    }
    _15266 = NOVALUE;

    /** 	op_info[INTEGER_CHECK       ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15267 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 96);
    _1 = *(int *)_2;
    *(int *)_2 = _15267;
    if( _1 != _15267 ){
        DeRef(_1);
    }
    _15267 = NOVALUE;

    /** 	op_info[SEQUENCE_CHECK      ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15268 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 97);
    _1 = *(int *)_2;
    *(int *)_2 = _15268;
    if( _1 != _15268 ){
        DeRef(_1);
    }
    _15268 = NOVALUE;

    /** 	op_info[IS_AN_INTEGER       ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13492);
    *((int *)(_2+16)) = _13492;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15269 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 94);
    _1 = *(int *)_2;
    *(int *)_2 = _15269;
    if( _1 != _15269 ){
        DeRef(_1);
    }
    _15269 = NOVALUE;

    /** 	op_info[IS_AN_ATOM          ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13492);
    *((int *)(_2+16)) = _13492;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15270 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 67);
    _1 = *(int *)_2;
    *(int *)_2 = _15270;
    if( _1 != _15270 ){
        DeRef(_1);
    }
    _15270 = NOVALUE;

    /** 	op_info[IS_A_SEQUENCE       ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13492);
    *((int *)(_2+16)) = _13492;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15271 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 68);
    _1 = *(int *)_2;
    *(int *)_2 = _15271;
    if( _1 != _15271 ){
        DeRef(_1);
    }
    _15271 = NOVALUE;

    /** 	op_info[IS_AN_OBJECT        ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13492);
    *((int *)(_2+16)) = _13492;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15272 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 40);
    _1 = *(int *)_2;
    *(int *)_2 = _15272;
    if( _1 != _15272 ){
        DeRef(_1);
    }
    _15272 = NOVALUE;

    /** 	op_info[CALL_BACK_RETURN    ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 1;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15273 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 135);
    _1 = *(int *)_2;
    *(int *)_2 = _15273;
    if( _1 != _15273 ){
        DeRef(_1);
    }
    _15273 = NOVALUE;

    /** 	op_info[REF_TEMP            ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15274 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 207);
    _1 = *(int *)_2;
    *(int *)_2 = _15274;
    if( _1 != _15274 ){
        DeRef(_1);
    }
    _15274 = NOVALUE;

    /** 	op_info[DEREF_TEMP          ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15275 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 208);
    _1 = *(int *)_2;
    *(int *)_2 = _15275;
    if( _1 != _15275 ){
        DeRef(_1);
    }
    _15275 = NOVALUE;

    /** 	op_info[NOVALUE_TEMP        ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15276 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 209);
    _1 = *(int *)_2;
    *(int *)_2 = _15276;
    if( _1 != _15276 ){
        DeRef(_1);
    }
    _15276 = NOVALUE;

    /** 	op_info[PROC_FORWARD        ] = { VARIABLE_SIZE, 0, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 2;
    *((int *)(_2+8)) = 0;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15277 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 195);
    _1 = *(int *)_2;
    *(int *)_2 = _15277;
    if( _1 != _15277 ){
        DeRef(_1);
    }
    _15277 = NOVALUE;

    /** 	op_info[FUNC_FORWARD        ] = { VARIABLE_SIZE, 0, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 2;
    *((int *)(_2+8)) = 0;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15278 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 196);
    _1 = *(int *)_2;
    *(int *)_2 = _15278;
    if( _1 != _15278 ){
        DeRef(_1);
    }
    _15278 = NOVALUE;

    /** 	op_info[RIGHT_BRACE_N       ] = { VARIABLE_SIZE, 3, {}, {}, {} } -- target: [pc+1] + 2*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 2;
    *((int *)(_2+8)) = 3;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15279 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 31);
    _1 = *(int *)_2;
    *(int *)_2 = _15279;
    if( _1 != _15279 ){
        DeRef(_1);
    }
    _15279 = NOVALUE;

    /** 	op_info[CONCAT_N            ] = { VARIABLE_SIZE, 0, {}, {}, {} } -- target: [pc+1] + 2*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 2;
    *((int *)(_2+8)) = 0;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15280 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 157);
    _1 = *(int *)_2;
    *(int *)_2 = _15280;
    if( _1 != _15280 ){
        DeRef(_1);
    }
    _15280 = NOVALUE;

    /** 	op_info[PROC                ] = { VARIABLE_SIZE, 0, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 2;
    *((int *)(_2+8)) = 0;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15281 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 27);
    _1 = *(int *)_2;
    *(int *)_2 = _15281;
    if( _1 != _15281 ){
        DeRef(_1);
    }
    _15281 = NOVALUE;

    /** 	op_info[PROC_TAIL           ] = op_info[PROC]*/
    _2 = (int)SEQ_PTR(_64op_info_26647);
    _15282 = (int)*(((s1_ptr)_2)->base + 27);
    Ref(_15282);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26647 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 203);
    _1 = *(int *)_2;
    *(int *)_2 = _15282;
    if( _1 != _15282 ){
        DeRef(_1);
    }
    _15282 = NOVALUE;

    /** end procedure*/
    DeRefDS(_SHORT_CIRCUIT_27045);
    return;
    ;
}


int _64op_size(int _pc_27088, int _code_27089)
{
    int _op_27092 = NOVALUE;
    int _info_27094 = NOVALUE;
    int _int_27096 = NOVALUE;
    int _15307 = NOVALUE;
    int _15304 = NOVALUE;
    int _15301 = NOVALUE;
    int _15298 = NOVALUE;
    int _15297 = NOVALUE;
    int _15296 = NOVALUE;
    int _15295 = NOVALUE;
    int _15294 = NOVALUE;
    int _15293 = NOVALUE;
    int _15291 = NOVALUE;
    int _15290 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer op = code[pc]*/
    _2 = (int)SEQ_PTR(_code_27089);
    _op_27092 = (int)*(((s1_ptr)_2)->base + _pc_27088);
    if (!IS_ATOM_INT(_op_27092))
    _op_27092 = (long)DBL_PTR(_op_27092)->dbl;

    /** 	sequence info = op_info[op]*/
    DeRef(_info_27094);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    _info_27094 = (int)*(((s1_ptr)_2)->base + _op_27092);
    Ref(_info_27094);

    /** 	integer int = info[OP_SIZE_TYPE]*/
    _2 = (int)SEQ_PTR(_info_27094);
    _int_27096 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_int_27096))
    _int_27096 = (long)DBL_PTR(_int_27096)->dbl;

    /** 	if int = FIXED_SIZE then*/
    if (_int_27096 != 1)
    goto L1; // [29] 48

    /** 		int = info[OP_SIZE]*/
    _2 = (int)SEQ_PTR(_info_27094);
    _int_27096 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_int_27096))
    _int_27096 = (long)DBL_PTR(_int_27096)->dbl;

    /** 		return int*/
    DeRefDS(_code_27089);
    DeRefDS(_info_27094);
    return _int_27096;
    goto L2; // [45] 203
L1: 

    /** 		switch op do*/
    _0 = _op_27092;
    switch ( _0 ){ 

        /** 			case PROC, PROC_TAIL then*/
        case 27:
        case 203:

        /** 				info = SymTab[code[pc+1]]*/
        _15290 = _pc_27088 + 1;
        _2 = (int)SEQ_PTR(_code_27089);
        _15291 = (int)*(((s1_ptr)_2)->base + _15290);
        DeRef(_info_27094);
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        if (!IS_ATOM_INT(_15291)){
            _info_27094 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_15291)->dbl));
        }
        else{
            _info_27094 = (int)*(((s1_ptr)_2)->base + _15291);
        }
        Ref(_info_27094);

        /** 				return info[S_NUM_ARGS] + 2 + (info[S_TOKEN] != PROC)*/
        _2 = (int)SEQ_PTR(_info_27094);
        if (!IS_ATOM_INT(_26S_NUM_ARGS_11705)){
            _15293 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NUM_ARGS_11705)->dbl));
        }
        else{
            _15293 = (int)*(((s1_ptr)_2)->base + _26S_NUM_ARGS_11705);
        }
        if (IS_ATOM_INT(_15293)) {
            _15294 = _15293 + 2;
            if ((long)((unsigned long)_15294 + (unsigned long)HIGH_BITS) >= 0) 
            _15294 = NewDouble((double)_15294);
        }
        else {
            _15294 = binary_op(PLUS, _15293, 2);
        }
        _15293 = NOVALUE;
        _2 = (int)SEQ_PTR(_info_27094);
        if (!IS_ATOM_INT(_26S_TOKEN_11659)){
            _15295 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_TOKEN_11659)->dbl));
        }
        else{
            _15295 = (int)*(((s1_ptr)_2)->base + _26S_TOKEN_11659);
        }
        if (IS_ATOM_INT(_15295)) {
            _15296 = (_15295 != 27);
        }
        else {
            _15296 = binary_op(NOTEQ, _15295, 27);
        }
        _15295 = NOVALUE;
        if (IS_ATOM_INT(_15294) && IS_ATOM_INT(_15296)) {
            _15297 = _15294 + _15296;
            if ((long)((unsigned long)_15297 + (unsigned long)HIGH_BITS) >= 0) 
            _15297 = NewDouble((double)_15297);
        }
        else {
            _15297 = binary_op(PLUS, _15294, _15296);
        }
        DeRef(_15294);
        _15294 = NOVALUE;
        DeRef(_15296);
        _15296 = NOVALUE;
        DeRefDS(_code_27089);
        DeRefDS(_info_27094);
        _15290 = NOVALUE;
        _15291 = NOVALUE;
        return _15297;
        goto L3; // [111] 196

        /** 			case PROC_FORWARD then*/
        case 195:

        /** 				int = code[pc+2]*/
        _15298 = _pc_27088 + 2;
        _2 = (int)SEQ_PTR(_code_27089);
        _int_27096 = (int)*(((s1_ptr)_2)->base + _15298);
        if (!IS_ATOM_INT(_int_27096))
        _int_27096 = (long)DBL_PTR(_int_27096)->dbl;

        /** 				int += 3*/
        _int_27096 = _int_27096 + 3;
        goto L3; // [133] 196

        /** 			case FUNC_FORWARD then*/
        case 196:

        /** 				int = code[pc+2]*/
        _15301 = _pc_27088 + 2;
        _2 = (int)SEQ_PTR(_code_27089);
        _int_27096 = (int)*(((s1_ptr)_2)->base + _15301);
        if (!IS_ATOM_INT(_int_27096))
        _int_27096 = (long)DBL_PTR(_int_27096)->dbl;

        /** 				int += 4*/
        _int_27096 = _int_27096 + 4;
        goto L3; // [155] 196

        /** 			case RIGHT_BRACE_N, CONCAT_N then*/
        case 31:
        case 157:

        /** 				int = code[pc+1]*/
        _15304 = _pc_27088 + 1;
        _2 = (int)SEQ_PTR(_code_27089);
        _int_27096 = (int)*(((s1_ptr)_2)->base + _15304);
        if (!IS_ATOM_INT(_int_27096))
        _int_27096 = (long)DBL_PTR(_int_27096)->dbl;

        /** 				int += 3*/
        _int_27096 = _int_27096 + 3;
        goto L3; // [179] 196

        /** 			case else*/
        default:

        /** 				InternalErr( 269, {op} )*/
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = _op_27092;
        _15307 = MAKE_SEQ(_1);
        _43InternalErr(269, _15307);
        _15307 = NOVALUE;
    ;}L3: 

    /** 		return int*/
    DeRefDS(_code_27089);
    DeRef(_info_27094);
    DeRef(_15290);
    _15290 = NOVALUE;
    _15291 = NOVALUE;
    DeRef(_15297);
    _15297 = NOVALUE;
    DeRef(_15298);
    _15298 = NOVALUE;
    DeRef(_15301);
    _15301 = NOVALUE;
    DeRef(_15304);
    _15304 = NOVALUE;
    return _int_27096;
L2: 
    ;
}


int _64advance(int _pc_27140, int _code_27141)
{
    int _15308 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_pc_27140)) {
        _1 = (long)(DBL_PTR(_pc_27140)->dbl);
        DeRefDS(_pc_27140);
        _pc_27140 = _1;
    }

    /** 	pc += op_size( pc, code )*/
    RefDS(_code_27141);
    _15308 = _64op_size(_pc_27140, _code_27141);
    if (IS_ATOM_INT(_15308)) {
        _pc_27140 = _pc_27140 + _15308;
    }
    else {
        _pc_27140 = binary_op(PLUS, _pc_27140, _15308);
    }
    DeRef(_15308);
    _15308 = NOVALUE;
    if (!IS_ATOM_INT(_pc_27140)) {
        _1 = (long)(DBL_PTR(_pc_27140)->dbl);
        DeRefDS(_pc_27140);
        _pc_27140 = _1;
    }

    /** 	return pc*/
    DeRefDS(_code_27141);
    return _pc_27140;
    ;
}


void _64shift_switch(int _pc_27148, int _start_27149, int _amount_27150)
{
    int _addr_27151 = NOVALUE;
    int _jump_27183 = NOVALUE;
    int _15344 = NOVALUE;
    int _15343 = NOVALUE;
    int _15342 = NOVALUE;
    int _15341 = NOVALUE;
    int _15340 = NOVALUE;
    int _15339 = NOVALUE;
    int _15338 = NOVALUE;
    int _15337 = NOVALUE;
    int _15336 = NOVALUE;
    int _15335 = NOVALUE;
    int _15334 = NOVALUE;
    int _15332 = NOVALUE;
    int _15331 = NOVALUE;
    int _15330 = NOVALUE;
    int _15329 = NOVALUE;
    int _15328 = NOVALUE;
    int _15327 = NOVALUE;
    int _15326 = NOVALUE;
    int _15325 = NOVALUE;
    int _15323 = NOVALUE;
    int _15322 = NOVALUE;
    int _15321 = NOVALUE;
    int _15320 = NOVALUE;
    int _15319 = NOVALUE;
    int _15316 = NOVALUE;
    int _15314 = NOVALUE;
    int _15313 = NOVALUE;
    int _15312 = NOVALUE;
    int _15311 = NOVALUE;
    int _15310 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	if sequence( Code[pc+4] ) then*/
    _15310 = _pc_27148 + 4;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _15311 = (int)*(((s1_ptr)_2)->base + _15310);
    _15312 = IS_SEQUENCE(_15311);
    _15311 = NOVALUE;
    if (_15312 == 0)
    {
        _15312 = NOVALUE;
        goto L1; // [22] 46
    }
    else{
        _15312 = NOVALUE;
    }

    /** 		addr = Code[pc+4][2]*/
    _15313 = _pc_27148 + 4;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _15314 = (int)*(((s1_ptr)_2)->base + _15313);
    _2 = (int)SEQ_PTR(_15314);
    _addr_27151 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_addr_27151)){
        _addr_27151 = (long)DBL_PTR(_addr_27151)->dbl;
    }
    _15314 = NOVALUE;
    goto L2; // [43] 61
L1: 

    /** 		addr = Code[pc+4]*/
    _15316 = _pc_27148 + 4;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _addr_27151 = (int)*(((s1_ptr)_2)->base + _15316);
    if (!IS_ATOM_INT(_addr_27151)){
        _addr_27151 = (long)DBL_PTR(_addr_27151)->dbl;
    }
L2: 

    /** 	if start < addr then*/
    if (_start_27149 >= _addr_27151)
    goto L3; // [65] 137

    /** 		if sequence( Code[pc+4] ) then*/
    _15319 = _pc_27148 + 4;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _15320 = (int)*(((s1_ptr)_2)->base + _15319);
    _15321 = IS_SEQUENCE(_15320);
    _15320 = NOVALUE;
    if (_15321 == 0)
    {
        _15321 = NOVALUE;
        goto L4; // [84] 115
    }
    else{
        _15321 = NOVALUE;
    }

    /** 			Code[pc+4][2] += amount*/
    _15322 = _pc_27148 + 4;
    _2 = (int)SEQ_PTR(_26Code_12071);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _26Code_12071 = MAKE_SEQ(_2);
    }
    _3 = (int)(_15322 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    _15325 = (int)*(((s1_ptr)_2)->base + 2);
    _15323 = NOVALUE;
    if (IS_ATOM_INT(_15325)) {
        _15326 = _15325 + _amount_27150;
        if ((long)((unsigned long)_15326 + (unsigned long)HIGH_BITS) >= 0) 
        _15326 = NewDouble((double)_15326);
    }
    else {
        _15326 = binary_op(PLUS, _15325, _amount_27150);
    }
    _15325 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _15326;
    if( _1 != _15326 ){
        DeRef(_1);
    }
    _15326 = NOVALUE;
    _15323 = NOVALUE;
    goto L5; // [112] 136
L4: 

    /** 			Code[pc+4] += amount*/
    _15327 = _pc_27148 + 4;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _15328 = (int)*(((s1_ptr)_2)->base + _15327);
    if (IS_ATOM_INT(_15328)) {
        _15329 = _15328 + _amount_27150;
        if ((long)((unsigned long)_15329 + (unsigned long)HIGH_BITS) >= 0) 
        _15329 = NewDouble((double)_15329);
    }
    else {
        _15329 = binary_op(PLUS, _15328, _amount_27150);
    }
    _15328 = NOVALUE;
    _2 = (int)SEQ_PTR(_26Code_12071);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _26Code_12071 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _15327);
    _1 = *(int *)_2;
    *(int *)_2 = _15329;
    if( _1 != _15329 ){
        DeRef(_1);
    }
    _15329 = NOVALUE;
L5: 
L3: 

    /** 	sequence jump = SymTab[Code[pc+3]][S_OBJ]*/
    _15330 = _pc_27148 + 3;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _15331 = (int)*(((s1_ptr)_2)->base + _15330);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!IS_ATOM_INT(_15331)){
        _15332 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_15331)->dbl));
    }
    else{
        _15332 = (int)*(((s1_ptr)_2)->base + _15331);
    }
    DeRef(_jump_27183);
    _2 = (int)SEQ_PTR(_15332);
    _jump_27183 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_jump_27183);
    _15332 = NOVALUE;

    /** 	for i = 1 to length(jump) do*/
    if (IS_SEQUENCE(_jump_27183)){
            _15334 = SEQ_PTR(_jump_27183)->length;
    }
    else {
        _15334 = 1;
    }
    {
        int _i_27192;
        _i_27192 = 1;
L6: 
        if (_i_27192 > _15334){
            goto L7; // [168] 223
        }

        /** 		if start > pc and start < pc + jump[i] then*/
        _15335 = (_start_27149 > _pc_27148);
        if (_15335 == 0) {
            goto L8; // [181] 216
        }
        _2 = (int)SEQ_PTR(_jump_27183);
        _15337 = (int)*(((s1_ptr)_2)->base + _i_27192);
        if (IS_ATOM_INT(_15337)) {
            _15338 = _pc_27148 + _15337;
            if ((long)((unsigned long)_15338 + (unsigned long)HIGH_BITS) >= 0) 
            _15338 = NewDouble((double)_15338);
        }
        else {
            _15338 = binary_op(PLUS, _pc_27148, _15337);
        }
        _15337 = NOVALUE;
        if (IS_ATOM_INT(_15338)) {
            _15339 = (_start_27149 < _15338);
        }
        else {
            _15339 = binary_op(LESS, _start_27149, _15338);
        }
        DeRef(_15338);
        _15338 = NOVALUE;
        if (_15339 == 0) {
            DeRef(_15339);
            _15339 = NOVALUE;
            goto L8; // [198] 216
        }
        else {
            if (!IS_ATOM_INT(_15339) && DBL_PTR(_15339)->dbl == 0.0){
                DeRef(_15339);
                _15339 = NOVALUE;
                goto L8; // [198] 216
            }
            DeRef(_15339);
            _15339 = NOVALUE;
        }
        DeRef(_15339);
        _15339 = NOVALUE;

        /** 			jump[i] += amount*/
        _2 = (int)SEQ_PTR(_jump_27183);
        _15340 = (int)*(((s1_ptr)_2)->base + _i_27192);
        if (IS_ATOM_INT(_15340)) {
            _15341 = _15340 + _amount_27150;
            if ((long)((unsigned long)_15341 + (unsigned long)HIGH_BITS) >= 0) 
            _15341 = NewDouble((double)_15341);
        }
        else {
            _15341 = binary_op(PLUS, _15340, _amount_27150);
        }
        _15340 = NOVALUE;
        _2 = (int)SEQ_PTR(_jump_27183);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _jump_27183 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_27192);
        _1 = *(int *)_2;
        *(int *)_2 = _15341;
        if( _1 != _15341 ){
            DeRef(_1);
        }
        _15341 = NOVALUE;
L8: 

        /** 	end for*/
        _i_27192 = _i_27192 + 1;
        goto L6; // [218] 175
L7: 
        ;
    }

    /** 	SymTab[Code[pc+3]][S_OBJ] = jump*/
    _15342 = _pc_27148 + 3;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _15343 = (int)*(((s1_ptr)_2)->base + _15342);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_15343))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_15343)->dbl));
    else
    _3 = (int)(_15343 + ((s1_ptr)_2)->base);
    RefDS(_jump_27183);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _jump_27183;
    DeRef(_1);
    _15344 = NOVALUE;

    /** end procedure*/
    DeRefDS(_jump_27183);
    DeRef(_15310);
    _15310 = NOVALUE;
    DeRef(_15313);
    _15313 = NOVALUE;
    DeRef(_15316);
    _15316 = NOVALUE;
    DeRef(_15319);
    _15319 = NOVALUE;
    DeRef(_15322);
    _15322 = NOVALUE;
    DeRef(_15327);
    _15327 = NOVALUE;
    DeRef(_15330);
    _15330 = NOVALUE;
    _15331 = NOVALUE;
    DeRef(_15335);
    _15335 = NOVALUE;
    _15342 = NOVALUE;
    _15343 = NOVALUE;
    return;
    ;
}


void _64shift_addr(int _pc_27211, int _amount_27212, int _start_27213, int _bound_27214)
{
    int _int_27215 = NOVALUE;
    int _15359 = NOVALUE;
    int _15356 = NOVALUE;
    int _15352 = NOVALUE;
    int _15347 = NOVALUE;
    int _15346 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_pc_27211)) {
        _1 = (long)(DBL_PTR(_pc_27211)->dbl);
        DeRefDS(_pc_27211);
        _pc_27211 = _1;
    }

    /** 	if atom( Code[pc] ) then*/
    _2 = (int)SEQ_PTR(_26Code_12071);
    _15346 = (int)*(((s1_ptr)_2)->base + _pc_27211);
    _15347 = IS_ATOM(_15346);
    _15346 = NOVALUE;
    if (_15347 == 0)
    {
        _15347 = NOVALUE;
        goto L1; // [20] 75
    }
    else{
        _15347 = NOVALUE;
    }

    /** 		int = Code[pc]*/
    _2 = (int)SEQ_PTR(_26Code_12071);
    _int_27215 = (int)*(((s1_ptr)_2)->base + _pc_27211);
    if (!IS_ATOM_INT(_int_27215)){
        _int_27215 = (long)DBL_PTR(_int_27215)->dbl;
    }

    /** 		if int >= start then*/
    if (_int_27215 < _start_27213)
    goto L2; // [35] 139

    /** 			if int < bound then*/
    if (_int_27215 >= _bound_27214)
    goto L3; // [41] 56

    /** 				Code[pc] = start*/
    _2 = (int)SEQ_PTR(_26Code_12071);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _26Code_12071 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _pc_27211);
    _1 = *(int *)_2;
    *(int *)_2 = _start_27213;
    DeRef(_1);
    goto L2; // [53] 139
L3: 

    /** 				int += amount*/
    _int_27215 = _int_27215 + _amount_27212;

    /** 				Code[pc] = int*/
    _2 = (int)SEQ_PTR(_26Code_12071);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _26Code_12071 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _pc_27211);
    _1 = *(int *)_2;
    *(int *)_2 = _int_27215;
    DeRef(_1);
    goto L2; // [72] 139
L1: 

    /** 		int = Code[pc][2]*/
    _2 = (int)SEQ_PTR(_26Code_12071);
    _15352 = (int)*(((s1_ptr)_2)->base + _pc_27211);
    _2 = (int)SEQ_PTR(_15352);
    _int_27215 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_int_27215)){
        _int_27215 = (long)DBL_PTR(_int_27215)->dbl;
    }
    _15352 = NOVALUE;

    /** 		if int >= start then*/
    if (_int_27215 < _start_27213)
    goto L4; // [91] 138

    /** 			if int < bound then*/
    if (_int_27215 >= _bound_27214)
    goto L5; // [97] 117

    /** 				Code[pc][2] = start*/
    _2 = (int)SEQ_PTR(_26Code_12071);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _26Code_12071 = MAKE_SEQ(_2);
    }
    _3 = (int)(_pc_27211 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _start_27213;
    DeRef(_1);
    _15356 = NOVALUE;
    goto L6; // [114] 137
L5: 

    /** 				int += amount*/
    _int_27215 = _int_27215 + _amount_27212;

    /** 				Code[pc][2] = int*/
    _2 = (int)SEQ_PTR(_26Code_12071);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _26Code_12071 = MAKE_SEQ(_2);
    }
    _3 = (int)(_pc_27211 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _int_27215;
    DeRef(_1);
    _15359 = NOVALUE;
L6: 
L4: 
L2: 

    /** end procedure*/
    return;
    ;
}


void _64shift(int _start_27248, int _amount_27249, int _bound_27250)
{
    int _int_27253 = NOVALUE;
    int _pc_27266 = NOVALUE;
    int _op_27267 = NOVALUE;
    int _finish_27268 = NOVALUE;
    int _len_27271 = NOVALUE;
    int _addrs_27282 = NOVALUE;
    int _15381 = NOVALUE;
    int _15377 = NOVALUE;
    int _15375 = NOVALUE;
    int _15373 = NOVALUE;
    int _15371 = NOVALUE;
    int _15367 = NOVALUE;
    int _15362 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_start_27248)) {
        _1 = (long)(DBL_PTR(_start_27248)->dbl);
        DeRefDS(_start_27248);
        _start_27248 = _1;
    }
    if (!IS_ATOM_INT(_amount_27249)) {
        _1 = (long)(DBL_PTR(_amount_27249)->dbl);
        DeRefDS(_amount_27249);
        _amount_27249 = _1;
    }
    if (!IS_ATOM_INT(_bound_27250)) {
        _1 = (long)(DBL_PTR(_bound_27250)->dbl);
        DeRefDS(_bound_27250);
        _bound_27250 = _1;
    }

    /** 	if amount = 0 then*/
    if (_amount_27249 != 0)
    goto L1; // [9] 19

    /** 		return*/
    return;
L1: 

    /** 	integer int*/

    /** 	for i = length( LineTable ) to 1 by -1 do*/
    if (IS_SEQUENCE(_26LineTable_12072)){
            _15362 = SEQ_PTR(_26LineTable_12072)->length;
    }
    else {
        _15362 = 1;
    }
    {
        int _i_27255;
        _i_27255 = _15362;
L2: 
        if (_i_27255 < 1){
            goto L3; // [28] 84
        }

        /** 		int = LineTable[i]*/
        _2 = (int)SEQ_PTR(_26LineTable_12072);
        _int_27253 = (int)*(((s1_ptr)_2)->base + _i_27255);
        if (!IS_ATOM_INT(_int_27253)){
            _int_27253 = (long)DBL_PTR(_int_27253)->dbl;
        }

        /** 		if int > 0 then*/
        if (_int_27253 <= 0)
        goto L4; // [47] 77

        /** 			if int < start then*/
        if (_int_27253 >= _start_27248)
        goto L5; // [53] 62

        /** 				exit*/
        goto L3; // [59] 84
L5: 

        /** 			int += amount*/
        _int_27253 = _int_27253 + _amount_27249;

        /** 			LineTable[i] = int*/
        _2 = (int)SEQ_PTR(_26LineTable_12072);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _26LineTable_12072 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_27255);
        _1 = *(int *)_2;
        *(int *)_2 = _int_27253;
        DeRef(_1);
L4: 

        /** 	end for*/
        _i_27255 = _i_27255 + -1;
        goto L2; // [79] 35
L3: 
        ;
    }

    /** 	integer pc = 1*/
    _pc_27266 = 1;

    /** 	integer op*/

    /** 	integer finish = start + amount - 1*/
    _15367 = _start_27248 + _amount_27249;
    if ((long)((unsigned long)_15367 + (unsigned long)HIGH_BITS) >= 0) 
    _15367 = NewDouble((double)_15367);
    if (IS_ATOM_INT(_15367)) {
        _finish_27268 = _15367 - 1;
    }
    else {
        _finish_27268 = NewDouble(DBL_PTR(_15367)->dbl - (double)1);
    }
    DeRef(_15367);
    _15367 = NOVALUE;
    if (!IS_ATOM_INT(_finish_27268)) {
        _1 = (long)(DBL_PTR(_finish_27268)->dbl);
        DeRefDS(_finish_27268);
        _finish_27268 = _1;
    }

    /** 	integer len = length( Code )*/
    if (IS_SEQUENCE(_26Code_12071)){
            _len_27271 = SEQ_PTR(_26Code_12071)->length;
    }
    else {
        _len_27271 = 1;
    }

    /** 	while pc <= len do*/
L6: 
    if (_pc_27266 > _len_27271)
    goto L7; // [115] 251

    /** 		if pc < start or pc > finish then*/
    _15371 = (_pc_27266 < _start_27248);
    if (_15371 != 0) {
        goto L8; // [125] 138
    }
    _15373 = (_pc_27266 > _finish_27268);
    if (_15373 == 0)
    {
        DeRef(_15373);
        _15373 = NOVALUE;
        goto L9; // [134] 233
    }
    else{
        DeRef(_15373);
        _15373 = NOVALUE;
    }
L8: 

    /** 			op = Code[pc]*/
    _2 = (int)SEQ_PTR(_26Code_12071);
    _op_27267 = (int)*(((s1_ptr)_2)->base + _pc_27266);
    if (!IS_ATOM_INT(_op_27267)){
        _op_27267 = (long)DBL_PTR(_op_27267)->dbl;
    }

    /** 			sequence addrs = op_info[op][OP_ADDR]*/
    _2 = (int)SEQ_PTR(_64op_info_26647);
    _15375 = (int)*(((s1_ptr)_2)->base + _op_27267);
    DeRef(_addrs_27282);
    _2 = (int)SEQ_PTR(_15375);
    _addrs_27282 = (int)*(((s1_ptr)_2)->base + 3);
    Ref(_addrs_27282);
    _15375 = NOVALUE;

    /** 			for i = 1 to length( addrs ) do*/
    if (IS_SEQUENCE(_addrs_27282)){
            _15377 = SEQ_PTR(_addrs_27282)->length;
    }
    else {
        _15377 = 1;
    }
    {
        int _i_27286;
        _i_27286 = 1;
LA: 
        if (_i_27286 > _15377){
            goto LB; // [167] 232
        }

        /** 				switch op with fallthru do*/
        _0 = _op_27267;
        switch ( _0 ){ 

            /** 					case SWITCH then*/
            case 185:
            case 193:
            case 192:
            case 202:

            /** 						shift_switch( pc, start, amount )*/
            _64shift_switch(_pc_27266, _start_27248, _amount_27249);

            /** 						break*/
            goto LC; // [200] 225

            /** 					case else*/
            default:

            /** 						int = addrs[i]*/
            _2 = (int)SEQ_PTR(_addrs_27282);
            _int_27253 = (int)*(((s1_ptr)_2)->base + _i_27286);
            if (!IS_ATOM_INT(_int_27253))
            _int_27253 = (long)DBL_PTR(_int_27253)->dbl;

            /** 						shift_addr( pc + int, amount, start, bound )*/
            _15381 = _pc_27266 + _int_27253;
            if ((long)((unsigned long)_15381 + (unsigned long)HIGH_BITS) >= 0) 
            _15381 = NewDouble((double)_15381);
            _64shift_addr(_15381, _amount_27249, _start_27248, _bound_27250);
            _15381 = NOVALUE;
        ;}LC: 

        /** 			end for*/
        _i_27286 = _i_27286 + 1;
        goto LA; // [227] 174
LB: 
        ;
    }
L9: 
    DeRef(_addrs_27282);
    _addrs_27282 = NOVALUE;

    /** 		pc = advance( pc )*/
    RefDS(_26Code_12071);
    _pc_27266 = _64advance(_pc_27266, _26Code_12071);
    if (!IS_ATOM_INT(_pc_27266)) {
        _1 = (long)(DBL_PTR(_pc_27266)->dbl);
        DeRefDS(_pc_27266);
        _pc_27266 = _1;
    }

    /** 	end while*/
    goto L6; // [248] 115
L7: 

    /** 	shift_fwd_refs( start, amount )*/
    _29shift_fwd_refs(_start_27248, _amount_27249);

    /** 	move_last_pc( amount )*/
    _37move_last_pc(_amount_27249);

    /** end procedure*/
    DeRef(_15371);
    _15371 = NOVALUE;
    return;
    ;
}


void _64insert_code(int _code_27304, int _index_27305)
{
    int _15384 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_index_27305)) {
        _1 = (long)(DBL_PTR(_index_27305)->dbl);
        DeRefDS(_index_27305);
        _index_27305 = _1;
    }

    /** 	Code = splice( Code, code, index )*/
    {
        s1_ptr assign_space;
        insert_pos = _index_27305;
        if (insert_pos <= 0) {
            Concat(&_26Code_12071,_code_27304,_26Code_12071);
        }
        else if (insert_pos > SEQ_PTR(_26Code_12071)->length){
            Concat(&_26Code_12071,_26Code_12071,_code_27304);
        }
        else if (IS_SEQUENCE(_code_27304)) {
            if( _26Code_12071 != _26Code_12071 || SEQ_PTR( _26Code_12071 )->ref != 1 ){
                DeRef( _26Code_12071 );
                RefDS( _26Code_12071 );
            }
            assign_space = Add_internal_space( _26Code_12071, insert_pos,((s1_ptr)SEQ_PTR(_code_27304))->length);
            assign_slice_seq = &assign_space;
            assign_space = Copy_elements( insert_pos, SEQ_PTR(_code_27304), _26Code_12071 == _26Code_12071 );
            _26Code_12071 = MAKE_SEQ( assign_space );
        }
        else {
            if( _26Code_12071 != _26Code_12071 && SEQ_PTR( _26Code_12071 )->ref != 1 ){
                _26Code_12071 = Insert( _26Code_12071, _code_27304, insert_pos);
            }
            else {
                DeRef( _26Code_12071 );
                RefDS( _26Code_12071 );
                _26Code_12071 = Insert( _26Code_12071, _code_27304, insert_pos);
            }
        }
    }

    /** 	shift( index, length( code ) )*/
    if (IS_SEQUENCE(_code_27304)){
            _15384 = SEQ_PTR(_code_27304)->length;
    }
    else {
        _15384 = 1;
    }
    _64shift(_index_27305, _15384, _index_27305);
    _15384 = NOVALUE;

    /** end procedure*/
    DeRefDS(_code_27304);
    return;
    ;
}


void _64replace_code(int _code_27312, int _start_27313, int _finish_27314)
{
    int _15389 = NOVALUE;
    int _15388 = NOVALUE;
    int _15387 = NOVALUE;
    int _15386 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_start_27313)) {
        _1 = (long)(DBL_PTR(_start_27313)->dbl);
        DeRefDS(_start_27313);
        _start_27313 = _1;
    }
    if (!IS_ATOM_INT(_finish_27314)) {
        _1 = (long)(DBL_PTR(_finish_27314)->dbl);
        DeRefDS(_finish_27314);
        _finish_27314 = _1;
    }

    /** 	Code = replace( Code, code, start, finish )*/
    {
        int p1 = _26Code_12071;
        int p2 = _code_27312;
        int p3 = _start_27313;
        int p4 = _finish_27314;
        struct replace_block replace_params;
        replace_params.copy_to   = &p1;
        replace_params.copy_from = &p2;
        replace_params.start     = &p3;
        replace_params.stop      = &p4;
        replace_params.target    = &_26Code_12071;
        Replace( &replace_params );
    }

    /** 	shift( start, length( code ) - (finish - start + 1), finish )*/
    if (IS_SEQUENCE(_code_27312)){
            _15386 = SEQ_PTR(_code_27312)->length;
    }
    else {
        _15386 = 1;
    }
    _15387 = _finish_27314 - _start_27313;
    if ((long)((unsigned long)_15387 +(unsigned long) HIGH_BITS) >= 0){
        _15387 = NewDouble((double)_15387);
    }
    if (IS_ATOM_INT(_15387)) {
        _15388 = _15387 + 1;
        if (_15388 > MAXINT){
            _15388 = NewDouble((double)_15388);
        }
    }
    else
    _15388 = binary_op(PLUS, 1, _15387);
    DeRef(_15387);
    _15387 = NOVALUE;
    if (IS_ATOM_INT(_15388)) {
        _15389 = _15386 - _15388;
        if ((long)((unsigned long)_15389 +(unsigned long) HIGH_BITS) >= 0){
            _15389 = NewDouble((double)_15389);
        }
    }
    else {
        _15389 = NewDouble((double)_15386 - DBL_PTR(_15388)->dbl);
    }
    _15386 = NOVALUE;
    DeRef(_15388);
    _15388 = NOVALUE;
    _64shift(_start_27313, _15389, _finish_27314);
    _15389 = NOVALUE;

    /** end procedure*/
    DeRefDS(_code_27312);
    return;
    ;
}


int _64current_op(int _pc_27324, int _code_27325)
{
    int _15397 = NOVALUE;
    int _15396 = NOVALUE;
    int _15395 = NOVALUE;
    int _15394 = NOVALUE;
    int _15393 = NOVALUE;
    int _15391 = NOVALUE;
    int _15390 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_pc_27324)) {
        _1 = (long)(DBL_PTR(_pc_27324)->dbl);
        DeRefDS(_pc_27324);
        _pc_27324 = _1;
    }

    /** 	if pc > length(code) or pc < 1 then*/
    if (IS_SEQUENCE(_code_27325)){
            _15390 = SEQ_PTR(_code_27325)->length;
    }
    else {
        _15390 = 1;
    }
    _15391 = (_pc_27324 > _15390);
    _15390 = NOVALUE;
    if (_15391 != 0) {
        goto L1; // [14] 27
    }
    _15393 = (_pc_27324 < 1);
    if (_15393 == 0)
    {
        DeRef(_15393);
        _15393 = NOVALUE;
        goto L2; // [23] 34
    }
    else{
        DeRef(_15393);
        _15393 = NOVALUE;
    }
L1: 

    /** 		return {}*/
    RefDS(_5);
    DeRefDS(_code_27325);
    DeRef(_15391);
    _15391 = NOVALUE;
    return _5;
L2: 

    /** 	return code[pc..pc-1+op_size( pc, code )]*/
    _15394 = _pc_27324 - 1;
    if ((long)((unsigned long)_15394 +(unsigned long) HIGH_BITS) >= 0){
        _15394 = NewDouble((double)_15394);
    }
    RefDS(_code_27325);
    _15395 = _64op_size(_pc_27324, _code_27325);
    if (IS_ATOM_INT(_15394) && IS_ATOM_INT(_15395)) {
        _15396 = _15394 + _15395;
    }
    else {
        _15396 = binary_op(PLUS, _15394, _15395);
    }
    DeRef(_15394);
    _15394 = NOVALUE;
    DeRef(_15395);
    _15395 = NOVALUE;
    rhs_slice_target = (object_ptr)&_15397;
    RHS_Slice(_code_27325, _pc_27324, _15396);
    DeRefDS(_code_27325);
    DeRef(_15391);
    _15391 = NOVALUE;
    DeRef(_15396);
    _15396 = NOVALUE;
    return _15397;
    ;
}


int _64get_ops(int _pc_27339, int _offset_27340, int _num_ops_27341, int _code_27342)
{
    int _sign_27345 = NOVALUE;
    int _ops_27354 = NOVALUE;
    int _opx_27356 = NOVALUE;
    int _15414 = NOVALUE;
    int _15413 = NOVALUE;
    int _15409 = NOVALUE;
    int _15408 = NOVALUE;
    int _15407 = NOVALUE;
    int _15406 = NOVALUE;
    int _15405 = NOVALUE;
    int _15404 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_pc_27339)) {
        _1 = (long)(DBL_PTR(_pc_27339)->dbl);
        DeRefDS(_pc_27339);
        _pc_27339 = _1;
    }
    if (!IS_ATOM_INT(_offset_27340)) {
        _1 = (long)(DBL_PTR(_offset_27340)->dbl);
        DeRefDS(_offset_27340);
        _offset_27340 = _1;
    }
    if (!IS_ATOM_INT(_num_ops_27341)) {
        _1 = (long)(DBL_PTR(_num_ops_27341)->dbl);
        DeRefDS(_num_ops_27341);
        _num_ops_27341 = _1;
    }

    /** 	integer sign = offset >= 0*/
    _sign_27345 = (_offset_27340 >= 0);

    /** 	if not sign then*/
    if (_sign_27345 != 0)
    goto L1; // [17] 33

    /** 		offset = -offset*/
    _offset_27340 = - _offset_27340;

    /** 		sign = -1*/
    _sign_27345 = -1;
L1: 

    /** 	while offset do*/
L2: 
    if (_offset_27340 == 0)
    {
        goto L3; // [38] 63
    }
    else{
    }

    /** 		pc = advance( pc )*/
    RefDS(_26Code_12071);
    _pc_27339 = _64advance(_pc_27339, _26Code_12071);
    if (!IS_ATOM_INT(_pc_27339)) {
        _1 = (long)(DBL_PTR(_pc_27339)->dbl);
        DeRefDS(_pc_27339);
        _pc_27339 = _1;
    }

    /** 		offset -= sign*/
    _offset_27340 = _offset_27340 - _sign_27345;

    /** 	end while*/
    goto L2; // [60] 38
L3: 

    /** 	sequence ops = repeat( 0, num_ops )*/
    DeRef(_ops_27354);
    _ops_27354 = Repeat(0, _num_ops_27341);

    /** 	integer opx = 1*/
    _opx_27356 = 1;

    /** 	while num_ops and pc <= length(code) do*/
L4: 
    if (_num_ops_27341 == 0) {
        goto L5; // [79] 137
    }
    if (IS_SEQUENCE(_code_27342)){
            _15405 = SEQ_PTR(_code_27342)->length;
    }
    else {
        _15405 = 1;
    }
    _15406 = (_pc_27339 <= _15405);
    _15405 = NOVALUE;
    if (_15406 == 0)
    {
        DeRef(_15406);
        _15406 = NOVALUE;
        goto L5; // [91] 137
    }
    else{
        DeRef(_15406);
        _15406 = NOVALUE;
    }

    /** 		ops[opx] = current_op( pc )*/
    RefDS(_26Code_12071);
    _15407 = _64current_op(_pc_27339, _26Code_12071);
    _2 = (int)SEQ_PTR(_ops_27354);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _ops_27354 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _opx_27356);
    _1 = *(int *)_2;
    *(int *)_2 = _15407;
    if( _1 != _15407 ){
        DeRef(_1);
    }
    _15407 = NOVALUE;

    /** 		pc += length( ops[opx] )*/
    _2 = (int)SEQ_PTR(_ops_27354);
    _15408 = (int)*(((s1_ptr)_2)->base + _opx_27356);
    if (IS_SEQUENCE(_15408)){
            _15409 = SEQ_PTR(_15408)->length;
    }
    else {
        _15409 = 1;
    }
    _15408 = NOVALUE;
    _pc_27339 = _pc_27339 + _15409;
    _15409 = NOVALUE;

    /** 		opx += 1*/
    _opx_27356 = _opx_27356 + 1;

    /** 		num_ops -= 1*/
    _num_ops_27341 = _num_ops_27341 - 1;

    /** 	end while*/
    goto L4; // [134] 79
L5: 

    /** 	if num_ops then*/
    if (_num_ops_27341 == 0)
    {
        goto L6; // [139] 156
    }
    else{
    }

    /** 		ops = head( ops, length( ops ) - num_ops )*/
    if (IS_SEQUENCE(_ops_27354)){
            _15413 = SEQ_PTR(_ops_27354)->length;
    }
    else {
        _15413 = 1;
    }
    _15414 = _15413 - _num_ops_27341;
    if ((long)((unsigned long)_15414 +(unsigned long) HIGH_BITS) >= 0){
        _15414 = NewDouble((double)_15414);
    }
    _15413 = NOVALUE;
    {
        int len = SEQ_PTR(_ops_27354)->length;
        int size = (IS_ATOM_INT(_15414)) ? _15414 : (long)(DBL_PTR(_15414)->dbl);
        if (size <= 0) _ops_27354 = MAKE_SEQ(NewS1(0));
        else if (len <= size) {
            RefDS(_ops_27354);
            DeRef(_ops_27354);
            _ops_27354 = _ops_27354;
        }
        else Head(SEQ_PTR(_ops_27354),size+1,&_ops_27354);
    }
    DeRef(_15414);
    _15414 = NOVALUE;
L6: 

    /** 	return ops*/
    DeRefDS(_code_27342);
    _15408 = NOVALUE;
    return _ops_27354;
    ;
}


int _64find_ops(int _pc_27374, int _op_27375, int _code_27376)
{
    int _ops_27379 = NOVALUE;
    int _found_op_27383 = NOVALUE;
    int _15423 = NOVALUE;
    int _15421 = NOVALUE;
    int _15419 = NOVALUE;
    int _15416 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_pc_27374)) {
        _1 = (long)(DBL_PTR(_pc_27374)->dbl);
        DeRefDS(_pc_27374);
        _pc_27374 = _1;
    }
    if (!IS_ATOM_INT(_op_27375)) {
        _1 = (long)(DBL_PTR(_op_27375)->dbl);
        DeRefDS(_op_27375);
        _op_27375 = _1;
    }

    /** 	sequence ops = {}*/
    RefDS(_5);
    DeRef(_ops_27379);
    _ops_27379 = _5;

    /** 	while pc <= length(code) do*/
L1: 
    if (IS_SEQUENCE(_code_27376)){
            _15416 = SEQ_PTR(_code_27376)->length;
    }
    else {
        _15416 = 1;
    }
    if (_pc_27374 > _15416)
    goto L2; // [22] 74

    /** 		sequence found_op = current_op( pc )*/
    RefDS(_26Code_12071);
    _0 = _found_op_27383;
    _found_op_27383 = _64current_op(_pc_27374, _26Code_12071);
    DeRef(_0);

    /** 		if found_op[1] = op then*/
    _2 = (int)SEQ_PTR(_found_op_27383);
    _15419 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _15419, _op_27375)){
        _15419 = NOVALUE;
        goto L3; // [43] 58
    }
    _15419 = NOVALUE;

    /** 			ops = append( ops, { pc, found_op } )*/
    RefDS(_found_op_27383);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _pc_27374;
    ((int *)_2)[2] = _found_op_27383;
    _15421 = MAKE_SEQ(_1);
    RefDS(_15421);
    Append(&_ops_27379, _ops_27379, _15421);
    DeRefDS(_15421);
    _15421 = NOVALUE;
L3: 

    /** 		pc += length( found_op )*/
    if (IS_SEQUENCE(_found_op_27383)){
            _15423 = SEQ_PTR(_found_op_27383)->length;
    }
    else {
        _15423 = 1;
    }
    _pc_27374 = _pc_27374 + _15423;
    _15423 = NOVALUE;
    DeRefDS(_found_op_27383);
    _found_op_27383 = NOVALUE;

    /** 	end while*/
    goto L1; // [71] 19
L2: 

    /** 	return ops*/
    DeRefDS(_code_27376);
    return _ops_27379;
    ;
}


int _64get_target_sym(int _opseq_27395)
{
    int _op_27399 = NOVALUE;
    int _info_27401 = NOVALUE;
    int _targets_27417 = NOVALUE;
    int _sub_27432 = NOVALUE;
    int _15455 = NOVALUE;
    int _15454 = NOVALUE;
    int _15453 = NOVALUE;
    int _15452 = NOVALUE;
    int _15451 = NOVALUE;
    int _15450 = NOVALUE;
    int _15449 = NOVALUE;
    int _15447 = NOVALUE;
    int _15443 = NOVALUE;
    int _15442 = NOVALUE;
    int _15441 = NOVALUE;
    int _15440 = NOVALUE;
    int _15438 = NOVALUE;
    int _15437 = NOVALUE;
    int _15436 = NOVALUE;
    int _15435 = NOVALUE;
    int _15432 = NOVALUE;
    int _15431 = NOVALUE;
    int _15429 = NOVALUE;
    int _15425 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not length( opseq ) then*/
    if (IS_SEQUENCE(_opseq_27395)){
            _15425 = SEQ_PTR(_opseq_27395)->length;
    }
    else {
        _15425 = 1;
    }
    if (_15425 != 0)
    goto L1; // [8] 18
    _15425 = NOVALUE;

    /** 		return 0*/
    DeRefDS(_opseq_27395);
    DeRef(_info_27401);
    return 0;
L1: 

    /** 	integer op = opseq[1]*/
    _2 = (int)SEQ_PTR(_opseq_27395);
    _op_27399 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_op_27399))
    _op_27399 = (long)DBL_PTR(_op_27399)->dbl;

    /** 	sequence info = op_info[op]*/
    DeRef(_info_27401);
    _2 = (int)SEQ_PTR(_64op_info_26647);
    _info_27401 = (int)*(((s1_ptr)_2)->base + _op_27399);
    Ref(_info_27401);

    /** 	if info[OP_SIZE_TYPE] = FIXED_SIZE then*/
    _2 = (int)SEQ_PTR(_info_27401);
    _15429 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _15429, 1)){
        _15429 = NOVALUE;
        goto L2; // [40] 157
    }
    _15429 = NOVALUE;

    /** 		switch length( info[OP_TARGET] ) do*/
    _2 = (int)SEQ_PTR(_info_27401);
    _15431 = (int)*(((s1_ptr)_2)->base + 4);
    if (IS_SEQUENCE(_15431)){
            _15432 = SEQ_PTR(_15431)->length;
    }
    else {
        _15432 = 1;
    }
    _15431 = NOVALUE;
    _0 = _15432;
    _15432 = NOVALUE;
    switch ( _0 ){ 

        /** 			case 0 then*/
        case 0:

        /** 				break*/
        goto L3; // [64] 152
        goto L3; // [66] 152

        /** 			case 1 then*/
        case 1:

        /** 				return opseq[info[OP_TARGET][1]+1]*/
        _2 = (int)SEQ_PTR(_info_27401);
        _15435 = (int)*(((s1_ptr)_2)->base + 4);
        _2 = (int)SEQ_PTR(_15435);
        _15436 = (int)*(((s1_ptr)_2)->base + 1);
        _15435 = NOVALUE;
        if (IS_ATOM_INT(_15436)) {
            _15437 = _15436 + 1;
        }
        else
        _15437 = binary_op(PLUS, 1, _15436);
        _15436 = NOVALUE;
        _2 = (int)SEQ_PTR(_opseq_27395);
        if (!IS_ATOM_INT(_15437)){
            _15438 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_15437)->dbl));
        }
        else{
            _15438 = (int)*(((s1_ptr)_2)->base + _15437);
        }
        Ref(_15438);
        DeRefDS(_opseq_27395);
        DeRefDS(_info_27401);
        _15431 = NOVALUE;
        DeRef(_15437);
        _15437 = NOVALUE;
        return _15438;
        goto L3; // [94] 152

        /** 			case else*/
        default:

        /** 				sequence targets = info[OP_TARGET]*/
        DeRef(_targets_27417);
        _2 = (int)SEQ_PTR(_info_27401);
        _targets_27417 = (int)*(((s1_ptr)_2)->base + 4);
        Ref(_targets_27417);

        /** 				for i = 1 to length( targets ) do*/
        if (IS_SEQUENCE(_targets_27417)){
                _15440 = SEQ_PTR(_targets_27417)->length;
        }
        else {
            _15440 = 1;
        }
        {
            int _i_27420;
            _i_27420 = 1;
L4: 
            if (_i_27420 > _15440){
                goto L5; // [113] 145
            }

            /** 					targets[i] = opseq[targets[i] + 1]*/
            _2 = (int)SEQ_PTR(_targets_27417);
            _15441 = (int)*(((s1_ptr)_2)->base + _i_27420);
            if (IS_ATOM_INT(_15441)) {
                _15442 = _15441 + 1;
            }
            else
            _15442 = binary_op(PLUS, 1, _15441);
            _15441 = NOVALUE;
            _2 = (int)SEQ_PTR(_opseq_27395);
            if (!IS_ATOM_INT(_15442)){
                _15443 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_15442)->dbl));
            }
            else{
                _15443 = (int)*(((s1_ptr)_2)->base + _15442);
            }
            Ref(_15443);
            _2 = (int)SEQ_PTR(_targets_27417);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _targets_27417 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _i_27420);
            _1 = *(int *)_2;
            *(int *)_2 = _15443;
            if( _1 != _15443 ){
                DeRef(_1);
            }
            _15443 = NOVALUE;

            /** 				end for*/
            _i_27420 = _i_27420 + 1;
            goto L4; // [140] 120
L5: 
            ;
        }

        /** 				return targets*/
        DeRefDS(_opseq_27395);
        DeRef(_info_27401);
        _15431 = NOVALUE;
        _15438 = NOVALUE;
        DeRef(_15437);
        _15437 = NOVALUE;
        DeRef(_15442);
        _15442 = NOVALUE;
        return _targets_27417;
    ;}L3: 
    DeRef(_targets_27417);
    _targets_27417 = NOVALUE;
    goto L6; // [154] 253
L2: 

    /** 		switch op do*/
    _0 = _op_27399;
    switch ( _0 ){ 

        /** 			case PROC, PROC_TAIL then*/
        case 27:
        case 203:

        /** 				symtab_index sub = opseq[2]*/
        _2 = (int)SEQ_PTR(_opseq_27395);
        _sub_27432 = (int)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_sub_27432)){
            _sub_27432 = (long)DBL_PTR(_sub_27432)->dbl;
        }

        /** 				if sym_token( sub ) = FUNC then*/
        _15447 = _52sym_token(_sub_27432);
        if (binary_op_a(NOTEQ, _15447, 501)){
            DeRef(_15447);
            _15447 = NOVALUE;
            goto L7; // [186] 204
        }
        DeRef(_15447);
        _15447 = NOVALUE;

        /** 					return opseq[$]*/
        if (IS_SEQUENCE(_opseq_27395)){
                _15449 = SEQ_PTR(_opseq_27395)->length;
        }
        else {
            _15449 = 1;
        }
        _2 = (int)SEQ_PTR(_opseq_27395);
        _15450 = (int)*(((s1_ptr)_2)->base + _15449);
        Ref(_15450);
        DeRefDS(_opseq_27395);
        DeRef(_info_27401);
        _15431 = NOVALUE;
        _15438 = NOVALUE;
        DeRef(_15437);
        _15437 = NOVALUE;
        DeRef(_15442);
        _15442 = NOVALUE;
        return _15450;
L7: 
        goto L8; // [206] 252

        /** 			case FUNC_FORWARD then*/
        case 196:

        /** 				return opseq[$]*/
        if (IS_SEQUENCE(_opseq_27395)){
                _15451 = SEQ_PTR(_opseq_27395)->length;
        }
        else {
            _15451 = 1;
        }
        _2 = (int)SEQ_PTR(_opseq_27395);
        _15452 = (int)*(((s1_ptr)_2)->base + _15451);
        Ref(_15452);
        DeRefDS(_opseq_27395);
        DeRef(_info_27401);
        _15431 = NOVALUE;
        _15438 = NOVALUE;
        DeRef(_15437);
        _15437 = NOVALUE;
        _15450 = NOVALUE;
        DeRef(_15442);
        _15442 = NOVALUE;
        return _15452;
        goto L8; // [225] 252

        /** 			case RIGHT_BRACE_N, CONCAT_N then*/
        case 31:
        case 157:

        /** 				return opseq[opseq[2]+2]*/
        _2 = (int)SEQ_PTR(_opseq_27395);
        _15453 = (int)*(((s1_ptr)_2)->base + 2);
        if (IS_ATOM_INT(_15453)) {
            _15454 = _15453 + 2;
        }
        else {
            _15454 = binary_op(PLUS, _15453, 2);
        }
        _15453 = NOVALUE;
        _2 = (int)SEQ_PTR(_opseq_27395);
        if (!IS_ATOM_INT(_15454)){
            _15455 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_15454)->dbl));
        }
        else{
            _15455 = (int)*(((s1_ptr)_2)->base + _15454);
        }
        Ref(_15455);
        DeRefDS(_opseq_27395);
        DeRef(_info_27401);
        _15431 = NOVALUE;
        _15438 = NOVALUE;
        DeRef(_15437);
        _15437 = NOVALUE;
        _15450 = NOVALUE;
        DeRef(_15442);
        _15442 = NOVALUE;
        _15452 = NOVALUE;
        DeRef(_15454);
        _15454 = NOVALUE;
        return _15455;
    ;}L8: 
L6: 

    /** 	return 0*/
    DeRefDS(_opseq_27395);
    DeRef(_info_27401);
    _15431 = NOVALUE;
    _15438 = NOVALUE;
    DeRef(_15437);
    _15437 = NOVALUE;
    _15450 = NOVALUE;
    DeRef(_15442);
    _15442 = NOVALUE;
    _15452 = NOVALUE;
    _15455 = NOVALUE;
    DeRef(_15454);
    _15454 = NOVALUE;
    return 0;
    ;
}



// 0x639FA953
