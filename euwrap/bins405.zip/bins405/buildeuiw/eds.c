// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

void _48fatal(int _errcode_17423, int _msg_17424, int _routine_name_17425, int _parms_17426)
{
    int _9884 = NOVALUE;
    int _0, _1, _2;
    

    /** 	vLastErrors = append(vLastErrors, {errcode, msg, routine_name, parms})*/
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _errcode_17423;
    RefDS(_msg_17424);
    *((int *)(_2+8)) = _msg_17424;
    RefDS(_routine_name_17425);
    *((int *)(_2+12)) = _routine_name_17425;
    RefDS(_parms_17426);
    *((int *)(_2+16)) = _parms_17426;
    _9884 = MAKE_SEQ(_1);
    RefDS(_9884);
    Append(&_48vLastErrors_17420, _48vLastErrors_17420, _9884);
    DeRefDS(_9884);
    _9884 = NOVALUE;

    /** 	if db_fatal_id >= 0 then*/

    /** end procedure*/
    DeRefDSi(_msg_17424);
    DeRefDSi(_routine_name_17425);
    DeRefDS(_parms_17426);
    return;
    ;
}


int _48get4()
{
    int _9900 = NOVALUE;
    int _9899 = NOVALUE;
    int _9898 = NOVALUE;
    int _9897 = NOVALUE;
    int _9896 = NOVALUE;
    int _0, _1, _2;
    

    /** 	poke(mem0, getc(current_db))*/
    if (_48current_db_17396 != last_r_file_no) {
        last_r_file_ptr = which_file(_48current_db_17396, EF_READ);
        last_r_file_no = _48current_db_17396;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _9896 = getKBchar();
        }
        else
        _9896 = getc(last_r_file_ptr);
    }
    else
    _9896 = getc(last_r_file_ptr);
    if (IS_ATOM_INT(_48mem0_17438)){
        poke_addr = (unsigned char *)_48mem0_17438;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_48mem0_17438)->dbl);
    }
    *poke_addr = (unsigned char)_9896;
    _9896 = NOVALUE;

    /** 	poke(mem1, getc(current_db))*/
    if (_48current_db_17396 != last_r_file_no) {
        last_r_file_ptr = which_file(_48current_db_17396, EF_READ);
        last_r_file_no = _48current_db_17396;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _9897 = getKBchar();
        }
        else
        _9897 = getc(last_r_file_ptr);
    }
    else
    _9897 = getc(last_r_file_ptr);
    if (IS_ATOM_INT(_48mem1_17439)){
        poke_addr = (unsigned char *)_48mem1_17439;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_48mem1_17439)->dbl);
    }
    *poke_addr = (unsigned char)_9897;
    _9897 = NOVALUE;

    /** 	poke(mem2, getc(current_db))*/
    if (_48current_db_17396 != last_r_file_no) {
        last_r_file_ptr = which_file(_48current_db_17396, EF_READ);
        last_r_file_no = _48current_db_17396;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _9898 = getKBchar();
        }
        else
        _9898 = getc(last_r_file_ptr);
    }
    else
    _9898 = getc(last_r_file_ptr);
    if (IS_ATOM_INT(_48mem2_17440)){
        poke_addr = (unsigned char *)_48mem2_17440;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_48mem2_17440)->dbl);
    }
    *poke_addr = (unsigned char)_9898;
    _9898 = NOVALUE;

    /** 	poke(mem3, getc(current_db))*/
    if (_48current_db_17396 != last_r_file_no) {
        last_r_file_ptr = which_file(_48current_db_17396, EF_READ);
        last_r_file_no = _48current_db_17396;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _9899 = getKBchar();
        }
        else
        _9899 = getc(last_r_file_ptr);
    }
    else
    _9899 = getc(last_r_file_ptr);
    if (IS_ATOM_INT(_48mem3_17441)){
        poke_addr = (unsigned char *)_48mem3_17441;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_48mem3_17441)->dbl);
    }
    *poke_addr = (unsigned char)_9899;
    _9899 = NOVALUE;

    /** 	return peek4u(mem0)*/
    if (IS_ATOM_INT(_48mem0_17438)) {
        _9900 = *(unsigned long *)_48mem0_17438;
        if ((unsigned)_9900 > (unsigned)MAXINT)
        _9900 = NewDouble((double)(unsigned long)_9900);
    }
    else {
        _9900 = *(unsigned long *)(unsigned long)(DBL_PTR(_48mem0_17438)->dbl);
        if ((unsigned)_9900 > (unsigned)MAXINT)
        _9900 = NewDouble((double)(unsigned long)_9900);
    }
    return _9900;
    ;
}


int _48get_string()
{
    int _where_inlined_where_at_31_17466 = NOVALUE;
    int _s_17455 = NOVALUE;
    int _c_17456 = NOVALUE;
    int _i_17457 = NOVALUE;
    int _9913 = NOVALUE;
    int _9910 = NOVALUE;
    int _9908 = NOVALUE;
    int _9906 = NOVALUE;
    int _0, _1, _2;
    

    /** 	s = repeat(0, 256)*/
    DeRefi(_s_17455);
    _s_17455 = Repeat(0, 256);

    /** 	i = 0*/
    _i_17457 = 0;

    /** 	while c with entry do*/
    goto L1; // [14] 89
L2: 
    if (_c_17456 == 0)
    {
        goto L3; // [19] 101
    }
    else{
    }

    /** 		if c = -1 then*/
    if (_c_17456 != -1)
    goto L4; // [24] 54

    /** 			fatal(MISSING_END, "string is missing 0 terminator", "get_string", {io:where(current_db)})*/

    /** 	return machine_func(M_WHERE, fn)*/
    DeRef(_where_inlined_where_at_31_17466);
    _where_inlined_where_at_31_17466 = machine(20, _48current_db_17396);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_where_inlined_where_at_31_17466);
    *((int *)(_2+4)) = _where_inlined_where_at_31_17466;
    _9906 = MAKE_SEQ(_1);
    RefDS(_9904);
    RefDS(_9905);
    _48fatal(900, _9904, _9905, _9906);
    _9906 = NOVALUE;

    /** 			exit*/
    goto L3; // [51] 101
L4: 

    /** 		i += 1*/
    _i_17457 = _i_17457 + 1;

    /** 		if i > length(s) then*/
    if (IS_SEQUENCE(_s_17455)){
            _9908 = SEQ_PTR(_s_17455)->length;
    }
    else {
        _9908 = 1;
    }
    if (_i_17457 <= _9908)
    goto L5; // [65] 80

    /** 			s &= repeat(0, 256)*/
    _9910 = Repeat(0, 256);
    Concat((object_ptr)&_s_17455, _s_17455, _9910);
    DeRefDS(_9910);
    _9910 = NOVALUE;
L5: 

    /** 		s[i] = c*/
    _2 = (int)SEQ_PTR(_s_17455);
    _2 = (int)(((s1_ptr)_2)->base + _i_17457);
    *(int *)_2 = _c_17456;

    /** 	  entry*/
L1: 

    /** 		c = getc(current_db)*/
    if (_48current_db_17396 != last_r_file_no) {
        last_r_file_ptr = which_file(_48current_db_17396, EF_READ);
        last_r_file_no = _48current_db_17396;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _c_17456 = getKBchar();
        }
        else
        _c_17456 = getc(last_r_file_ptr);
    }
    else
    _c_17456 = getc(last_r_file_ptr);

    /** 	end while*/
    goto L2; // [98] 17
L3: 

    /** 	return s[1..i]*/
    rhs_slice_target = (object_ptr)&_9913;
    RHS_Slice(_s_17455, 1, _i_17457);
    DeRefDSi(_s_17455);
    return _9913;
    ;
}


int _48equal_string(int _target_17478)
{
    int _c_17479 = NOVALUE;
    int _i_17480 = NOVALUE;
    int _where_inlined_where_at_27_17486 = NOVALUE;
    int _9924 = NOVALUE;
    int _9923 = NOVALUE;
    int _9920 = NOVALUE;
    int _9918 = NOVALUE;
    int _9916 = NOVALUE;
    int _0, _1, _2;
    

    /** 	i = 0*/
    _i_17480 = 0;

    /** 	while c with entry do*/
    goto L1; // [10] 94
L2: 
    if (_c_17479 == 0)
    {
        goto L3; // [15] 106
    }
    else{
    }

    /** 		if c = -1 then*/
    if (_c_17479 != -1)
    goto L4; // [20] 52

    /** 			fatal(MISSING_END, "string is missing 0 terminator", "equal_string", {io:where(current_db)})*/

    /** 	return machine_func(M_WHERE, fn)*/
    DeRef(_where_inlined_where_at_27_17486);
    _where_inlined_where_at_27_17486 = machine(20, _48current_db_17396);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_where_inlined_where_at_27_17486);
    *((int *)(_2+4)) = _where_inlined_where_at_27_17486;
    _9916 = MAKE_SEQ(_1);
    RefDS(_9904);
    RefDS(_9915);
    _48fatal(900, _9904, _9915, _9916);
    _9916 = NOVALUE;

    /** 			return DB_FATAL_FAIL*/
    DeRefDS(_target_17478);
    return -404;
L4: 

    /** 		i += 1*/
    _i_17480 = _i_17480 + 1;

    /** 		if i > length(target) then*/
    if (IS_SEQUENCE(_target_17478)){
            _9918 = SEQ_PTR(_target_17478)->length;
    }
    else {
        _9918 = 1;
    }
    if (_i_17480 <= _9918)
    goto L5; // [63] 74

    /** 			return 0*/
    DeRefDS(_target_17478);
    return 0;
L5: 

    /** 		if target[i] != c then*/
    _2 = (int)SEQ_PTR(_target_17478);
    _9920 = (int)*(((s1_ptr)_2)->base + _i_17480);
    if (binary_op_a(EQUALS, _9920, _c_17479)){
        _9920 = NOVALUE;
        goto L6; // [80] 91
    }
    _9920 = NOVALUE;

    /** 			return 0*/
    DeRefDS(_target_17478);
    return 0;
L6: 

    /** 	  entry*/
L1: 

    /** 		c = getc(current_db)*/
    if (_48current_db_17396 != last_r_file_no) {
        last_r_file_ptr = which_file(_48current_db_17396, EF_READ);
        last_r_file_no = _48current_db_17396;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _c_17479 = getKBchar();
        }
        else
        _c_17479 = getc(last_r_file_ptr);
    }
    else
    _c_17479 = getc(last_r_file_ptr);

    /** 	end while*/
    goto L2; // [103] 13
L3: 

    /** 	return (i = length(target))*/
    if (IS_SEQUENCE(_target_17478)){
            _9923 = SEQ_PTR(_target_17478)->length;
    }
    else {
        _9923 = 1;
    }
    _9924 = (_i_17480 == _9923);
    _9923 = NOVALUE;
    DeRefDS(_target_17478);
    return _9924;
    ;
}


int _48decompress(int _c_17537)
{
    int _s_17538 = NOVALUE;
    int _len_17539 = NOVALUE;
    int _float32_to_atom_inlined_float32_to_atom_at_176_17575 = NOVALUE;
    int _ieee32_inlined_float32_to_atom_at_173_17574 = NOVALUE;
    int _float64_to_atom_inlined_float64_to_atom_at_251_17588 = NOVALUE;
    int _ieee64_inlined_float64_to_atom_at_248_17587 = NOVALUE;
    int _9993 = NOVALUE;
    int _9992 = NOVALUE;
    int _9991 = NOVALUE;
    int _9988 = NOVALUE;
    int _9983 = NOVALUE;
    int _9982 = NOVALUE;
    int _9981 = NOVALUE;
    int _9980 = NOVALUE;
    int _9979 = NOVALUE;
    int _9978 = NOVALUE;
    int _9977 = NOVALUE;
    int _9976 = NOVALUE;
    int _9975 = NOVALUE;
    int _9974 = NOVALUE;
    int _9973 = NOVALUE;
    int _9972 = NOVALUE;
    int _9971 = NOVALUE;
    int _9970 = NOVALUE;
    int _9969 = NOVALUE;
    int _9968 = NOVALUE;
    int _9967 = NOVALUE;
    int _9966 = NOVALUE;
    int _9965 = NOVALUE;
    int _9964 = NOVALUE;
    int _9962 = NOVALUE;
    int _9961 = NOVALUE;
    int _9960 = NOVALUE;
    int _9959 = NOVALUE;
    int _9958 = NOVALUE;
    int _9957 = NOVALUE;
    int _9956 = NOVALUE;
    int _9955 = NOVALUE;
    int _9954 = NOVALUE;
    int _9951 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if c = 0 then*/
    if (_c_17537 != 0)
    goto L1; // [5] 34

    /** 		c = getc(current_db)*/
    if (_48current_db_17396 != last_r_file_no) {
        last_r_file_ptr = which_file(_48current_db_17396, EF_READ);
        last_r_file_no = _48current_db_17396;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _c_17537 = getKBchar();
        }
        else
        _c_17537 = getc(last_r_file_ptr);
    }
    else
    _c_17537 = getc(last_r_file_ptr);

    /** 		if c < I2B then*/
    if (_c_17537 >= 249)
    goto L2; // [18] 33

    /** 			return c + MIN1B*/
    _9951 = _c_17537 + -9;
    DeRef(_s_17538);
    return _9951;
L2: 
L1: 

    /** 	switch c with fallthru do*/
    _0 = _c_17537;
    switch ( _0 ){ 

        /** 		case I2B then*/
        case 249:

        /** 			return getc(current_db) +*/
        if (_48current_db_17396 != last_r_file_no) {
            last_r_file_ptr = which_file(_48current_db_17396, EF_READ);
            last_r_file_no = _48current_db_17396;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _9954 = getKBchar();
            }
            else
            _9954 = getc(last_r_file_ptr);
        }
        else
        _9954 = getc(last_r_file_ptr);
        if (_48current_db_17396 != last_r_file_no) {
            last_r_file_ptr = which_file(_48current_db_17396, EF_READ);
            last_r_file_no = _48current_db_17396;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _9955 = getKBchar();
            }
            else
            _9955 = getc(last_r_file_ptr);
        }
        else
        _9955 = getc(last_r_file_ptr);
        _9956 = 256 * _9955;
        _9955 = NOVALUE;
        _9957 = _9954 + _9956;
        _9954 = NOVALUE;
        _9956 = NOVALUE;
        _9958 = _9957 + _48MIN2B_17517;
        if ((long)((unsigned long)_9958 + (unsigned long)HIGH_BITS) >= 0) 
        _9958 = NewDouble((double)_9958);
        _9957 = NOVALUE;
        DeRef(_s_17538);
        DeRef(_9951);
        _9951 = NOVALUE;
        return _9958;

        /** 		case I3B then*/
        case 250:

        /** 			return getc(current_db) +*/
        if (_48current_db_17396 != last_r_file_no) {
            last_r_file_ptr = which_file(_48current_db_17396, EF_READ);
            last_r_file_no = _48current_db_17396;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _9959 = getKBchar();
            }
            else
            _9959 = getc(last_r_file_ptr);
        }
        else
        _9959 = getc(last_r_file_ptr);
        if (_48current_db_17396 != last_r_file_no) {
            last_r_file_ptr = which_file(_48current_db_17396, EF_READ);
            last_r_file_no = _48current_db_17396;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _9960 = getKBchar();
            }
            else
            _9960 = getc(last_r_file_ptr);
        }
        else
        _9960 = getc(last_r_file_ptr);
        _9961 = 256 * _9960;
        _9960 = NOVALUE;
        _9962 = _9959 + _9961;
        _9959 = NOVALUE;
        _9961 = NOVALUE;
        if (_48current_db_17396 != last_r_file_no) {
            last_r_file_ptr = which_file(_48current_db_17396, EF_READ);
            last_r_file_no = _48current_db_17396;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _9964 = getKBchar();
            }
            else
            _9964 = getc(last_r_file_ptr);
        }
        else
        _9964 = getc(last_r_file_ptr);
        _9965 = 65536 * _9964;
        _9964 = NOVALUE;
        _9966 = _9962 + _9965;
        _9962 = NOVALUE;
        _9965 = NOVALUE;
        _9967 = _9966 + _48MIN3B_17524;
        if ((long)((unsigned long)_9967 + (unsigned long)HIGH_BITS) >= 0) 
        _9967 = NewDouble((double)_9967);
        _9966 = NOVALUE;
        DeRef(_s_17538);
        DeRef(_9951);
        _9951 = NOVALUE;
        DeRef(_9958);
        _9958 = NOVALUE;
        return _9967;

        /** 		case I4B then*/
        case 251:

        /** 			return get4() + MIN4B*/
        _9968 = _48get4();
        if (IS_ATOM_INT(_9968) && IS_ATOM_INT(_48MIN4B_17531)) {
            _9969 = _9968 + _48MIN4B_17531;
            if ((long)((unsigned long)_9969 + (unsigned long)HIGH_BITS) >= 0) 
            _9969 = NewDouble((double)_9969);
        }
        else {
            _9969 = binary_op(PLUS, _9968, _48MIN4B_17531);
        }
        DeRef(_9968);
        _9968 = NOVALUE;
        DeRef(_s_17538);
        DeRef(_9951);
        _9951 = NOVALUE;
        DeRef(_9958);
        _9958 = NOVALUE;
        DeRef(_9967);
        _9967 = NOVALUE;
        return _9969;

        /** 		case F4B then*/
        case 252:

        /** 			return convert:float32_to_atom({getc(current_db), getc(current_db),*/
        if (_48current_db_17396 != last_r_file_no) {
            last_r_file_ptr = which_file(_48current_db_17396, EF_READ);
            last_r_file_no = _48current_db_17396;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _9970 = getKBchar();
            }
            else
            _9970 = getc(last_r_file_ptr);
        }
        else
        _9970 = getc(last_r_file_ptr);
        if (_48current_db_17396 != last_r_file_no) {
            last_r_file_ptr = which_file(_48current_db_17396, EF_READ);
            last_r_file_no = _48current_db_17396;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _9971 = getKBchar();
            }
            else
            _9971 = getc(last_r_file_ptr);
        }
        else
        _9971 = getc(last_r_file_ptr);
        if (_48current_db_17396 != last_r_file_no) {
            last_r_file_ptr = which_file(_48current_db_17396, EF_READ);
            last_r_file_no = _48current_db_17396;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _9972 = getKBchar();
            }
            else
            _9972 = getc(last_r_file_ptr);
        }
        else
        _9972 = getc(last_r_file_ptr);
        if (_48current_db_17396 != last_r_file_no) {
            last_r_file_ptr = which_file(_48current_db_17396, EF_READ);
            last_r_file_no = _48current_db_17396;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _9973 = getKBchar();
            }
            else
            _9973 = getc(last_r_file_ptr);
        }
        else
        _9973 = getc(last_r_file_ptr);
        _1 = NewS1(4);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = _9970;
        *((int *)(_2+8)) = _9971;
        *((int *)(_2+12)) = _9972;
        *((int *)(_2+16)) = _9973;
        _9974 = MAKE_SEQ(_1);
        _9973 = NOVALUE;
        _9972 = NOVALUE;
        _9971 = NOVALUE;
        _9970 = NOVALUE;
        DeRefi(_ieee32_inlined_float32_to_atom_at_173_17574);
        _ieee32_inlined_float32_to_atom_at_173_17574 = _9974;
        _9974 = NOVALUE;

        /** 	return machine_func(M_F32_TO_A, ieee32)*/
        DeRef(_float32_to_atom_inlined_float32_to_atom_at_176_17575);
        _float32_to_atom_inlined_float32_to_atom_at_176_17575 = machine(49, _ieee32_inlined_float32_to_atom_at_173_17574);
        DeRefi(_ieee32_inlined_float32_to_atom_at_173_17574);
        _ieee32_inlined_float32_to_atom_at_173_17574 = NOVALUE;
        DeRef(_s_17538);
        DeRef(_9951);
        _9951 = NOVALUE;
        DeRef(_9958);
        _9958 = NOVALUE;
        DeRef(_9967);
        _9967 = NOVALUE;
        DeRef(_9969);
        _9969 = NOVALUE;
        return _float32_to_atom_inlined_float32_to_atom_at_176_17575;

        /** 		case F8B then*/
        case 253:

        /** 			return convert:float64_to_atom({getc(current_db), getc(current_db),*/
        if (_48current_db_17396 != last_r_file_no) {
            last_r_file_ptr = which_file(_48current_db_17396, EF_READ);
            last_r_file_no = _48current_db_17396;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _9975 = getKBchar();
            }
            else
            _9975 = getc(last_r_file_ptr);
        }
        else
        _9975 = getc(last_r_file_ptr);
        if (_48current_db_17396 != last_r_file_no) {
            last_r_file_ptr = which_file(_48current_db_17396, EF_READ);
            last_r_file_no = _48current_db_17396;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _9976 = getKBchar();
            }
            else
            _9976 = getc(last_r_file_ptr);
        }
        else
        _9976 = getc(last_r_file_ptr);
        if (_48current_db_17396 != last_r_file_no) {
            last_r_file_ptr = which_file(_48current_db_17396, EF_READ);
            last_r_file_no = _48current_db_17396;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _9977 = getKBchar();
            }
            else
            _9977 = getc(last_r_file_ptr);
        }
        else
        _9977 = getc(last_r_file_ptr);
        if (_48current_db_17396 != last_r_file_no) {
            last_r_file_ptr = which_file(_48current_db_17396, EF_READ);
            last_r_file_no = _48current_db_17396;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _9978 = getKBchar();
            }
            else
            _9978 = getc(last_r_file_ptr);
        }
        else
        _9978 = getc(last_r_file_ptr);
        if (_48current_db_17396 != last_r_file_no) {
            last_r_file_ptr = which_file(_48current_db_17396, EF_READ);
            last_r_file_no = _48current_db_17396;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _9979 = getKBchar();
            }
            else
            _9979 = getc(last_r_file_ptr);
        }
        else
        _9979 = getc(last_r_file_ptr);
        if (_48current_db_17396 != last_r_file_no) {
            last_r_file_ptr = which_file(_48current_db_17396, EF_READ);
            last_r_file_no = _48current_db_17396;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _9980 = getKBchar();
            }
            else
            _9980 = getc(last_r_file_ptr);
        }
        else
        _9980 = getc(last_r_file_ptr);
        if (_48current_db_17396 != last_r_file_no) {
            last_r_file_ptr = which_file(_48current_db_17396, EF_READ);
            last_r_file_no = _48current_db_17396;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _9981 = getKBchar();
            }
            else
            _9981 = getc(last_r_file_ptr);
        }
        else
        _9981 = getc(last_r_file_ptr);
        if (_48current_db_17396 != last_r_file_no) {
            last_r_file_ptr = which_file(_48current_db_17396, EF_READ);
            last_r_file_no = _48current_db_17396;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _9982 = getKBchar();
            }
            else
            _9982 = getc(last_r_file_ptr);
        }
        else
        _9982 = getc(last_r_file_ptr);
        _1 = NewS1(8);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = _9975;
        *((int *)(_2+8)) = _9976;
        *((int *)(_2+12)) = _9977;
        *((int *)(_2+16)) = _9978;
        *((int *)(_2+20)) = _9979;
        *((int *)(_2+24)) = _9980;
        *((int *)(_2+28)) = _9981;
        *((int *)(_2+32)) = _9982;
        _9983 = MAKE_SEQ(_1);
        _9982 = NOVALUE;
        _9981 = NOVALUE;
        _9980 = NOVALUE;
        _9979 = NOVALUE;
        _9978 = NOVALUE;
        _9977 = NOVALUE;
        _9976 = NOVALUE;
        _9975 = NOVALUE;
        DeRefi(_ieee64_inlined_float64_to_atom_at_248_17587);
        _ieee64_inlined_float64_to_atom_at_248_17587 = _9983;
        _9983 = NOVALUE;

        /** 	return machine_func(M_F64_TO_A, ieee64)*/
        DeRef(_float64_to_atom_inlined_float64_to_atom_at_251_17588);
        _float64_to_atom_inlined_float64_to_atom_at_251_17588 = machine(47, _ieee64_inlined_float64_to_atom_at_248_17587);
        DeRefi(_ieee64_inlined_float64_to_atom_at_248_17587);
        _ieee64_inlined_float64_to_atom_at_248_17587 = NOVALUE;
        DeRef(_s_17538);
        DeRef(_9951);
        _9951 = NOVALUE;
        DeRef(_9958);
        _9958 = NOVALUE;
        DeRef(_9967);
        _9967 = NOVALUE;
        DeRef(_9969);
        _9969 = NOVALUE;
        return _float64_to_atom_inlined_float64_to_atom_at_251_17588;

        /** 		case else*/
        default:

        /** 			if c = S1B then*/
        if (_c_17537 != 254)
        goto L3; // [273] 287

        /** 				len = getc(current_db)*/
        if (_48current_db_17396 != last_r_file_no) {
            last_r_file_ptr = which_file(_48current_db_17396, EF_READ);
            last_r_file_no = _48current_db_17396;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _len_17539 = getKBchar();
            }
            else
            _len_17539 = getc(last_r_file_ptr);
        }
        else
        _len_17539 = getc(last_r_file_ptr);
        goto L4; // [284] 295
L3: 

        /** 				len = get4()*/
        _len_17539 = _48get4();
        if (!IS_ATOM_INT(_len_17539)) {
            _1 = (long)(DBL_PTR(_len_17539)->dbl);
            DeRefDS(_len_17539);
            _len_17539 = _1;
        }
L4: 

        /** 			s = repeat(0, len)*/
        DeRef(_s_17538);
        _s_17538 = Repeat(0, _len_17539);

        /** 			for i = 1 to len do*/
        _9988 = _len_17539;
        {
            int _i_17597;
            _i_17597 = 1;
L5: 
            if (_i_17597 > _9988){
                goto L6; // [308] 362
            }

            /** 				c = getc(current_db)*/
            if (_48current_db_17396 != last_r_file_no) {
                last_r_file_ptr = which_file(_48current_db_17396, EF_READ);
                last_r_file_no = _48current_db_17396;
            }
            if (last_r_file_ptr == xstdin) {
                show_console();
                if (in_from_keyb) {
                    _c_17537 = getKBchar();
                }
                else
                _c_17537 = getc(last_r_file_ptr);
            }
            else
            _c_17537 = getc(last_r_file_ptr);

            /** 				if c < I2B then*/
            if (_c_17537 >= 249)
            goto L7; // [324] 341

            /** 					s[i] = c + MIN1B*/
            _9991 = _c_17537 + -9;
            _2 = (int)SEQ_PTR(_s_17538);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _s_17538 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _i_17597);
            _1 = *(int *)_2;
            *(int *)_2 = _9991;
            if( _1 != _9991 ){
                DeRef(_1);
            }
            _9991 = NOVALUE;
            goto L8; // [338] 355
L7: 

            /** 					s[i] = decompress(c)*/
            DeRef(_9992);
            _9992 = _c_17537;
            _9993 = _48decompress(_9992);
            _9992 = NOVALUE;
            _2 = (int)SEQ_PTR(_s_17538);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _s_17538 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _i_17597);
            _1 = *(int *)_2;
            *(int *)_2 = _9993;
            if( _1 != _9993 ){
                DeRef(_1);
            }
            _9993 = NOVALUE;
L8: 

            /** 			end for*/
            _i_17597 = _i_17597 + 1;
            goto L5; // [357] 315
L6: 
            ;
        }

        /** 			return s*/
        DeRef(_9951);
        _9951 = NOVALUE;
        DeRef(_9958);
        _9958 = NOVALUE;
        DeRef(_9967);
        _9967 = NOVALUE;
        DeRef(_9969);
        _9969 = NOVALUE;
        return _s_17538;
    ;}    ;
}


int _48compress(int _x_17608)
{
    int _x4_17609 = NOVALUE;
    int _s_17610 = NOVALUE;
    int _atom_to_float32_inlined_atom_to_float32_at_192_17644 = NOVALUE;
    int _float32_to_atom_inlined_float32_to_atom_at_203_17647 = NOVALUE;
    int _atom_to_float64_inlined_atom_to_float64_at_229_17652 = NOVALUE;
    int _10032 = NOVALUE;
    int _10031 = NOVALUE;
    int _10030 = NOVALUE;
    int _10028 = NOVALUE;
    int _10027 = NOVALUE;
    int _10025 = NOVALUE;
    int _10023 = NOVALUE;
    int _10022 = NOVALUE;
    int _10021 = NOVALUE;
    int _10019 = NOVALUE;
    int _10018 = NOVALUE;
    int _10017 = NOVALUE;
    int _10016 = NOVALUE;
    int _10015 = NOVALUE;
    int _10014 = NOVALUE;
    int _10013 = NOVALUE;
    int _10012 = NOVALUE;
    int _10011 = NOVALUE;
    int _10009 = NOVALUE;
    int _10008 = NOVALUE;
    int _10007 = NOVALUE;
    int _10006 = NOVALUE;
    int _10005 = NOVALUE;
    int _10004 = NOVALUE;
    int _10002 = NOVALUE;
    int _10001 = NOVALUE;
    int _10000 = NOVALUE;
    int _9999 = NOVALUE;
    int _9998 = NOVALUE;
    int _9997 = NOVALUE;
    int _9996 = NOVALUE;
    int _9995 = NOVALUE;
    int _9994 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if integer(x) then*/
    if (IS_ATOM_INT(_x_17608))
    _9994 = 1;
    else if (IS_ATOM_DBL(_x_17608))
    _9994 = IS_ATOM_INT(DoubleToInt(_x_17608));
    else
    _9994 = 0;
    if (_9994 == 0)
    {
        _9994 = NOVALUE;
        goto L1; // [6] 183
    }
    else{
        _9994 = NOVALUE;
    }

    /** 		if x >= MIN1B and x <= MAX1B then*/
    if (IS_ATOM_INT(_x_17608)) {
        _9995 = (_x_17608 >= -9);
    }
    else {
        _9995 = binary_op(GREATEREQ, _x_17608, -9);
    }
    if (IS_ATOM_INT(_9995)) {
        if (_9995 == 0) {
            goto L2; // [15] 44
        }
    }
    else {
        if (DBL_PTR(_9995)->dbl == 0.0) {
            goto L2; // [15] 44
        }
    }
    if (IS_ATOM_INT(_x_17608)) {
        _9997 = (_x_17608 <= 239);
    }
    else {
        _9997 = binary_op(LESSEQ, _x_17608, 239);
    }
    if (_9997 == 0) {
        DeRef(_9997);
        _9997 = NOVALUE;
        goto L2; // [24] 44
    }
    else {
        if (!IS_ATOM_INT(_9997) && DBL_PTR(_9997)->dbl == 0.0){
            DeRef(_9997);
            _9997 = NOVALUE;
            goto L2; // [24] 44
        }
        DeRef(_9997);
        _9997 = NOVALUE;
    }
    DeRef(_9997);
    _9997 = NOVALUE;

    /** 			return {x - MIN1B}*/
    if (IS_ATOM_INT(_x_17608)) {
        _9998 = _x_17608 - -9;
        if ((long)((unsigned long)_9998 +(unsigned long) HIGH_BITS) >= 0){
            _9998 = NewDouble((double)_9998);
        }
    }
    else {
        _9998 = binary_op(MINUS, _x_17608, -9);
    }
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _9998;
    _9999 = MAKE_SEQ(_1);
    _9998 = NOVALUE;
    DeRef(_x_17608);
    DeRefi(_x4_17609);
    DeRef(_s_17610);
    DeRef(_9995);
    _9995 = NOVALUE;
    return _9999;
    goto L3; // [41] 328
L2: 

    /** 		elsif x >= MIN2B and x <= MAX2B then*/
    if (IS_ATOM_INT(_x_17608)) {
        _10000 = (_x_17608 >= _48MIN2B_17517);
    }
    else {
        _10000 = binary_op(GREATEREQ, _x_17608, _48MIN2B_17517);
    }
    if (IS_ATOM_INT(_10000)) {
        if (_10000 == 0) {
            goto L4; // [52] 97
        }
    }
    else {
        if (DBL_PTR(_10000)->dbl == 0.0) {
            goto L4; // [52] 97
        }
    }
    if (IS_ATOM_INT(_x_17608)) {
        _10002 = (_x_17608 <= 32767);
    }
    else {
        _10002 = binary_op(LESSEQ, _x_17608, 32767);
    }
    if (_10002 == 0) {
        DeRef(_10002);
        _10002 = NOVALUE;
        goto L4; // [63] 97
    }
    else {
        if (!IS_ATOM_INT(_10002) && DBL_PTR(_10002)->dbl == 0.0){
            DeRef(_10002);
            _10002 = NOVALUE;
            goto L4; // [63] 97
        }
        DeRef(_10002);
        _10002 = NOVALUE;
    }
    DeRef(_10002);
    _10002 = NOVALUE;

    /** 			x -= MIN2B*/
    _0 = _x_17608;
    if (IS_ATOM_INT(_x_17608)) {
        _x_17608 = _x_17608 - _48MIN2B_17517;
        if ((long)((unsigned long)_x_17608 +(unsigned long) HIGH_BITS) >= 0){
            _x_17608 = NewDouble((double)_x_17608);
        }
    }
    else {
        _x_17608 = binary_op(MINUS, _x_17608, _48MIN2B_17517);
    }
    DeRef(_0);

    /** 			return {I2B, and_bits(x, #FF), floor(x / #100)}*/
    if (IS_ATOM_INT(_x_17608)) {
        {unsigned long tu;
             tu = (unsigned long)_x_17608 & (unsigned long)255;
             _10004 = MAKE_UINT(tu);
        }
    }
    else {
        _10004 = binary_op(AND_BITS, _x_17608, 255);
    }
    if (IS_ATOM_INT(_x_17608)) {
        if (256 > 0 && _x_17608 >= 0) {
            _10005 = _x_17608 / 256;
        }
        else {
            temp_dbl = floor((double)_x_17608 / (double)256);
            if (_x_17608 != MININT)
            _10005 = (long)temp_dbl;
            else
            _10005 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x_17608, 256);
        _10005 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 249;
    *((int *)(_2+8)) = _10004;
    *((int *)(_2+12)) = _10005;
    _10006 = MAKE_SEQ(_1);
    _10005 = NOVALUE;
    _10004 = NOVALUE;
    DeRef(_x_17608);
    DeRefi(_x4_17609);
    DeRef(_s_17610);
    DeRef(_9995);
    _9995 = NOVALUE;
    DeRef(_9999);
    _9999 = NOVALUE;
    DeRef(_10000);
    _10000 = NOVALUE;
    return _10006;
    goto L3; // [94] 328
L4: 

    /** 		elsif x >= MIN3B and x <= MAX3B then*/
    if (IS_ATOM_INT(_x_17608)) {
        _10007 = (_x_17608 >= _48MIN3B_17524);
    }
    else {
        _10007 = binary_op(GREATEREQ, _x_17608, _48MIN3B_17524);
    }
    if (IS_ATOM_INT(_10007)) {
        if (_10007 == 0) {
            goto L5; // [105] 159
        }
    }
    else {
        if (DBL_PTR(_10007)->dbl == 0.0) {
            goto L5; // [105] 159
        }
    }
    if (IS_ATOM_INT(_x_17608)) {
        _10009 = (_x_17608 <= 8388607);
    }
    else {
        _10009 = binary_op(LESSEQ, _x_17608, 8388607);
    }
    if (_10009 == 0) {
        DeRef(_10009);
        _10009 = NOVALUE;
        goto L5; // [116] 159
    }
    else {
        if (!IS_ATOM_INT(_10009) && DBL_PTR(_10009)->dbl == 0.0){
            DeRef(_10009);
            _10009 = NOVALUE;
            goto L5; // [116] 159
        }
        DeRef(_10009);
        _10009 = NOVALUE;
    }
    DeRef(_10009);
    _10009 = NOVALUE;

    /** 			x -= MIN3B*/
    _0 = _x_17608;
    if (IS_ATOM_INT(_x_17608)) {
        _x_17608 = _x_17608 - _48MIN3B_17524;
        if ((long)((unsigned long)_x_17608 +(unsigned long) HIGH_BITS) >= 0){
            _x_17608 = NewDouble((double)_x_17608);
        }
    }
    else {
        _x_17608 = binary_op(MINUS, _x_17608, _48MIN3B_17524);
    }
    DeRef(_0);

    /** 			return {I3B, and_bits(x, #FF), and_bits(floor(x / #100), #FF), floor(x / #10000)}*/
    if (IS_ATOM_INT(_x_17608)) {
        {unsigned long tu;
             tu = (unsigned long)_x_17608 & (unsigned long)255;
             _10011 = MAKE_UINT(tu);
        }
    }
    else {
        _10011 = binary_op(AND_BITS, _x_17608, 255);
    }
    if (IS_ATOM_INT(_x_17608)) {
        if (256 > 0 && _x_17608 >= 0) {
            _10012 = _x_17608 / 256;
        }
        else {
            temp_dbl = floor((double)_x_17608 / (double)256);
            if (_x_17608 != MININT)
            _10012 = (long)temp_dbl;
            else
            _10012 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x_17608, 256);
        _10012 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    if (IS_ATOM_INT(_10012)) {
        {unsigned long tu;
             tu = (unsigned long)_10012 & (unsigned long)255;
             _10013 = MAKE_UINT(tu);
        }
    }
    else {
        _10013 = binary_op(AND_BITS, _10012, 255);
    }
    DeRef(_10012);
    _10012 = NOVALUE;
    if (IS_ATOM_INT(_x_17608)) {
        if (65536 > 0 && _x_17608 >= 0) {
            _10014 = _x_17608 / 65536;
        }
        else {
            temp_dbl = floor((double)_x_17608 / (double)65536);
            if (_x_17608 != MININT)
            _10014 = (long)temp_dbl;
            else
            _10014 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x_17608, 65536);
        _10014 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 250;
    *((int *)(_2+8)) = _10011;
    *((int *)(_2+12)) = _10013;
    *((int *)(_2+16)) = _10014;
    _10015 = MAKE_SEQ(_1);
    _10014 = NOVALUE;
    _10013 = NOVALUE;
    _10011 = NOVALUE;
    DeRef(_x_17608);
    DeRefi(_x4_17609);
    DeRef(_s_17610);
    DeRef(_9995);
    _9995 = NOVALUE;
    DeRef(_9999);
    _9999 = NOVALUE;
    DeRef(_10000);
    _10000 = NOVALUE;
    DeRef(_10006);
    _10006 = NOVALUE;
    DeRef(_10007);
    _10007 = NOVALUE;
    return _10015;
    goto L3; // [156] 328
L5: 

    /** 			return I4B & convert:int_to_bytes(x-MIN4B)*/
    if (IS_ATOM_INT(_x_17608) && IS_ATOM_INT(_48MIN4B_17531)) {
        _10016 = _x_17608 - _48MIN4B_17531;
        if ((long)((unsigned long)_10016 +(unsigned long) HIGH_BITS) >= 0){
            _10016 = NewDouble((double)_10016);
        }
    }
    else {
        _10016 = binary_op(MINUS, _x_17608, _48MIN4B_17531);
    }
    _10017 = _13int_to_bytes(_10016);
    _10016 = NOVALUE;
    if (IS_SEQUENCE(251) && IS_ATOM(_10017)) {
    }
    else if (IS_ATOM(251) && IS_SEQUENCE(_10017)) {
        Prepend(&_10018, _10017, 251);
    }
    else {
        Concat((object_ptr)&_10018, 251, _10017);
    }
    DeRef(_10017);
    _10017 = NOVALUE;
    DeRef(_x_17608);
    DeRefi(_x4_17609);
    DeRef(_s_17610);
    DeRef(_9995);
    _9995 = NOVALUE;
    DeRef(_9999);
    _9999 = NOVALUE;
    DeRef(_10000);
    _10000 = NOVALUE;
    DeRef(_10006);
    _10006 = NOVALUE;
    DeRef(_10007);
    _10007 = NOVALUE;
    DeRef(_10015);
    _10015 = NOVALUE;
    return _10018;
    goto L3; // [180] 328
L1: 

    /** 	elsif atom(x) then*/
    _10019 = IS_ATOM(_x_17608);
    if (_10019 == 0)
    {
        _10019 = NOVALUE;
        goto L6; // [188] 249
    }
    else{
        _10019 = NOVALUE;
    }

    /** 		x4 = convert:atom_to_float32(x)*/

    /** 	return machine_func(M_A_TO_F32, a)*/
    DeRefi(_x4_17609);
    _x4_17609 = machine(48, _x_17608);

    /** 		if x = convert:float32_to_atom(x4) then*/

    /** 	return machine_func(M_F32_TO_A, ieee32)*/
    DeRef(_float32_to_atom_inlined_float32_to_atom_at_203_17647);
    _float32_to_atom_inlined_float32_to_atom_at_203_17647 = machine(49, _x4_17609);
    if (binary_op_a(NOTEQ, _x_17608, _float32_to_atom_inlined_float32_to_atom_at_203_17647)){
        goto L7; // [211] 228
    }

    /** 			return F4B & x4*/
    Prepend(&_10021, _x4_17609, 252);
    DeRef(_x_17608);
    DeRefDSi(_x4_17609);
    DeRef(_s_17610);
    DeRef(_9995);
    _9995 = NOVALUE;
    DeRef(_9999);
    _9999 = NOVALUE;
    DeRef(_10000);
    _10000 = NOVALUE;
    DeRef(_10006);
    _10006 = NOVALUE;
    DeRef(_10007);
    _10007 = NOVALUE;
    DeRef(_10015);
    _10015 = NOVALUE;
    DeRef(_10018);
    _10018 = NOVALUE;
    return _10021;
    goto L3; // [225] 328
L7: 

    /** 			return F8B & convert:atom_to_float64(x)*/

    /** 	return machine_func(M_A_TO_F64, a)*/
    DeRefi(_atom_to_float64_inlined_atom_to_float64_at_229_17652);
    _atom_to_float64_inlined_atom_to_float64_at_229_17652 = machine(46, _x_17608);
    Prepend(&_10022, _atom_to_float64_inlined_atom_to_float64_at_229_17652, 253);
    DeRef(_x_17608);
    DeRefi(_x4_17609);
    DeRef(_s_17610);
    DeRef(_9995);
    _9995 = NOVALUE;
    DeRef(_9999);
    _9999 = NOVALUE;
    DeRef(_10000);
    _10000 = NOVALUE;
    DeRef(_10006);
    _10006 = NOVALUE;
    DeRef(_10007);
    _10007 = NOVALUE;
    DeRef(_10015);
    _10015 = NOVALUE;
    DeRef(_10018);
    _10018 = NOVALUE;
    DeRef(_10021);
    _10021 = NOVALUE;
    return _10022;
    goto L3; // [246] 328
L6: 

    /** 		if length(x) <= 255 then*/
    if (IS_SEQUENCE(_x_17608)){
            _10023 = SEQ_PTR(_x_17608)->length;
    }
    else {
        _10023 = 1;
    }
    if (_10023 > 255)
    goto L8; // [254] 270

    /** 			s = {S1B, length(x)}*/
    if (IS_SEQUENCE(_x_17608)){
            _10025 = SEQ_PTR(_x_17608)->length;
    }
    else {
        _10025 = 1;
    }
    DeRef(_s_17610);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 254;
    ((int *)_2)[2] = _10025;
    _s_17610 = MAKE_SEQ(_1);
    _10025 = NOVALUE;
    goto L9; // [267] 284
L8: 

    /** 			s = S4B & convert:int_to_bytes(length(x))*/
    if (IS_SEQUENCE(_x_17608)){
            _10027 = SEQ_PTR(_x_17608)->length;
    }
    else {
        _10027 = 1;
    }
    _10028 = _13int_to_bytes(_10027);
    _10027 = NOVALUE;
    if (IS_SEQUENCE(255) && IS_ATOM(_10028)) {
    }
    else if (IS_ATOM(255) && IS_SEQUENCE(_10028)) {
        Prepend(&_s_17610, _10028, 255);
    }
    else {
        Concat((object_ptr)&_s_17610, 255, _10028);
    }
    DeRef(_10028);
    _10028 = NOVALUE;
L9: 

    /** 		for i = 1 to length(x) do*/
    if (IS_SEQUENCE(_x_17608)){
            _10030 = SEQ_PTR(_x_17608)->length;
    }
    else {
        _10030 = 1;
    }
    {
        int _i_17665;
        _i_17665 = 1;
LA: 
        if (_i_17665 > _10030){
            goto LB; // [289] 319
        }

        /** 			s &= compress(x[i])*/
        _2 = (int)SEQ_PTR(_x_17608);
        _10031 = (int)*(((s1_ptr)_2)->base + _i_17665);
        Ref(_10031);
        _10032 = _48compress(_10031);
        _10031 = NOVALUE;
        if (IS_SEQUENCE(_s_17610) && IS_ATOM(_10032)) {
            Ref(_10032);
            Append(&_s_17610, _s_17610, _10032);
        }
        else if (IS_ATOM(_s_17610) && IS_SEQUENCE(_10032)) {
        }
        else {
            Concat((object_ptr)&_s_17610, _s_17610, _10032);
        }
        DeRef(_10032);
        _10032 = NOVALUE;

        /** 		end for*/
        _i_17665 = _i_17665 + 1;
        goto LA; // [314] 296
LB: 
        ;
    }

    /** 		return s*/
    DeRef(_x_17608);
    DeRefi(_x4_17609);
    DeRef(_9995);
    _9995 = NOVALUE;
    DeRef(_9999);
    _9999 = NOVALUE;
    DeRef(_10000);
    _10000 = NOVALUE;
    DeRef(_10006);
    _10006 = NOVALUE;
    DeRef(_10007);
    _10007 = NOVALUE;
    DeRef(_10015);
    _10015 = NOVALUE;
    DeRef(_10018);
    _10018 = NOVALUE;
    DeRef(_10021);
    _10021 = NOVALUE;
    DeRef(_10022);
    _10022 = NOVALUE;
    return _s_17610;
L3: 
    ;
}


int _48db_allocate(int _n_18049)
{
    int _free_list_18050 = NOVALUE;
    int _size_18051 = NOVALUE;
    int _size_ptr_18052 = NOVALUE;
    int _addr_18053 = NOVALUE;
    int _free_count_18054 = NOVALUE;
    int _remaining_18055 = NOVALUE;
    int _seek_1__tmp_at4_18058 = NOVALUE;
    int _seek_inlined_seek_at_4_18057 = NOVALUE;
    int _seek_1__tmp_at39_18065 = NOVALUE;
    int _seek_inlined_seek_at_39_18064 = NOVALUE;
    int _seek_1__tmp_at111_18082 = NOVALUE;
    int _seek_inlined_seek_at_111_18081 = NOVALUE;
    int _pos_inlined_seek_at_108_18080 = NOVALUE;
    int _put4_1__tmp_at137_18087 = NOVALUE;
    int _x_inlined_put4_at_134_18086 = NOVALUE;
    int _seek_1__tmp_at167_18090 = NOVALUE;
    int _seek_inlined_seek_at_167_18089 = NOVALUE;
    int _put4_1__tmp_at193_18095 = NOVALUE;
    int _x_inlined_put4_at_190_18094 = NOVALUE;
    int _seek_1__tmp_at244_18103 = NOVALUE;
    int _seek_inlined_seek_at_244_18102 = NOVALUE;
    int _pos_inlined_seek_at_241_18101 = NOVALUE;
    int _put4_1__tmp_at266_18107 = NOVALUE;
    int _x_inlined_put4_at_263_18106 = NOVALUE;
    int _seek_1__tmp_at333_18118 = NOVALUE;
    int _seek_inlined_seek_at_333_18117 = NOVALUE;
    int _pos_inlined_seek_at_330_18116 = NOVALUE;
    int _seek_1__tmp_at364_18122 = NOVALUE;
    int _seek_inlined_seek_at_364_18121 = NOVALUE;
    int _put4_1__tmp_at386_18126 = NOVALUE;
    int _x_inlined_put4_at_383_18125 = NOVALUE;
    int _seek_1__tmp_at423_18131 = NOVALUE;
    int _seek_inlined_seek_at_423_18130 = NOVALUE;
    int _pos_inlined_seek_at_420_18129 = NOVALUE;
    int _put4_1__tmp_at438_18133 = NOVALUE;
    int _seek_1__tmp_at490_18137 = NOVALUE;
    int _seek_inlined_seek_at_490_18136 = NOVALUE;
    int _put4_1__tmp_at512_18141 = NOVALUE;
    int _x_inlined_put4_at_509_18140 = NOVALUE;
    int _where_inlined_where_at_542_18143 = NOVALUE;
    int _10244 = NOVALUE;
    int _10242 = NOVALUE;
    int _10241 = NOVALUE;
    int _10240 = NOVALUE;
    int _10239 = NOVALUE;
    int _10238 = NOVALUE;
    int _10236 = NOVALUE;
    int _10235 = NOVALUE;
    int _10234 = NOVALUE;
    int _10233 = NOVALUE;
    int _10231 = NOVALUE;
    int _10230 = NOVALUE;
    int _10229 = NOVALUE;
    int _10228 = NOVALUE;
    int _10227 = NOVALUE;
    int _10226 = NOVALUE;
    int _10225 = NOVALUE;
    int _10223 = NOVALUE;
    int _10221 = NOVALUE;
    int _10218 = NOVALUE;
    int _0, _1, _2;
    

    /** 	io:seek(current_db, FREE_COUNT)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at4_18058);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _48current_db_17396;
    ((int *)_2)[2] = 7;
    _seek_1__tmp_at4_18058 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_4_18057 = machine(19, _seek_1__tmp_at4_18058);
    DeRefi(_seek_1__tmp_at4_18058);
    _seek_1__tmp_at4_18058 = NOVALUE;

    /** 	free_count = get4()*/
    _free_count_18054 = _48get4();
    if (!IS_ATOM_INT(_free_count_18054)) {
        _1 = (long)(DBL_PTR(_free_count_18054)->dbl);
        DeRefDS(_free_count_18054);
        _free_count_18054 = _1;
    }

    /** 	if free_count > 0 then*/
    if (_free_count_18054 <= 0)
    goto L1; // [27] 487

    /** 		free_list = get4()*/
    _0 = _free_list_18050;
    _free_list_18050 = _48get4();
    DeRef(_0);

    /** 		io:seek(current_db, free_list)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_free_list_18050);
    DeRef(_seek_1__tmp_at39_18065);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _48current_db_17396;
    ((int *)_2)[2] = _free_list_18050;
    _seek_1__tmp_at39_18065 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_39_18064 = machine(19, _seek_1__tmp_at39_18065);
    DeRef(_seek_1__tmp_at39_18065);
    _seek_1__tmp_at39_18065 = NOVALUE;

    /** 		size_ptr = free_list + 4*/
    DeRef(_size_ptr_18052);
    if (IS_ATOM_INT(_free_list_18050)) {
        _size_ptr_18052 = _free_list_18050 + 4;
        if ((long)((unsigned long)_size_ptr_18052 + (unsigned long)HIGH_BITS) >= 0) 
        _size_ptr_18052 = NewDouble((double)_size_ptr_18052);
    }
    else {
        _size_ptr_18052 = NewDouble(DBL_PTR(_free_list_18050)->dbl + (double)4);
    }

    /** 		for i = 1 to free_count do*/
    _10218 = _free_count_18054;
    {
        int _i_18068;
        _i_18068 = 1;
L2: 
        if (_i_18068 > _10218){
            goto L3; // [64] 486
        }

        /** 			addr = get4()*/
        _0 = _addr_18053;
        _addr_18053 = _48get4();
        DeRef(_0);

        /** 			size = get4()*/
        _0 = _size_18051;
        _size_18051 = _48get4();
        DeRef(_0);

        /** 			if size >= n+4 then*/
        if (IS_ATOM_INT(_n_18049)) {
            _10221 = _n_18049 + 4;
            if ((long)((unsigned long)_10221 + (unsigned long)HIGH_BITS) >= 0) 
            _10221 = NewDouble((double)_10221);
        }
        else {
            _10221 = NewDouble(DBL_PTR(_n_18049)->dbl + (double)4);
        }
        if (binary_op_a(LESS, _size_18051, _10221)){
            DeRef(_10221);
            _10221 = NOVALUE;
            goto L4; // [87] 473
        }
        DeRef(_10221);
        _10221 = NOVALUE;

        /** 				if size >= n+16 then*/
        if (IS_ATOM_INT(_n_18049)) {
            _10223 = _n_18049 + 16;
            if ((long)((unsigned long)_10223 + (unsigned long)HIGH_BITS) >= 0) 
            _10223 = NewDouble((double)_10223);
        }
        else {
            _10223 = NewDouble(DBL_PTR(_n_18049)->dbl + (double)16);
        }
        if (binary_op_a(LESS, _size_18051, _10223)){
            DeRef(_10223);
            _10223 = NOVALUE;
            goto L5; // [97] 296
        }
        DeRef(_10223);
        _10223 = NOVALUE;

        /** 					io:seek(current_db, addr - 4)*/
        if (IS_ATOM_INT(_addr_18053)) {
            _10225 = _addr_18053 - 4;
            if ((long)((unsigned long)_10225 +(unsigned long) HIGH_BITS) >= 0){
                _10225 = NewDouble((double)_10225);
            }
        }
        else {
            _10225 = NewDouble(DBL_PTR(_addr_18053)->dbl - (double)4);
        }
        DeRef(_pos_inlined_seek_at_108_18080);
        _pos_inlined_seek_at_108_18080 = _10225;
        _10225 = NOVALUE;

        /** 	return machine_func(M_SEEK, {fn, pos})*/
        Ref(_pos_inlined_seek_at_108_18080);
        DeRef(_seek_1__tmp_at111_18082);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _48current_db_17396;
        ((int *)_2)[2] = _pos_inlined_seek_at_108_18080;
        _seek_1__tmp_at111_18082 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_111_18081 = machine(19, _seek_1__tmp_at111_18082);
        DeRef(_pos_inlined_seek_at_108_18080);
        _pos_inlined_seek_at_108_18080 = NOVALUE;
        DeRef(_seek_1__tmp_at111_18082);
        _seek_1__tmp_at111_18082 = NOVALUE;

        /** 					put4(size-n-4) -- shrink the block*/
        if (IS_ATOM_INT(_size_18051) && IS_ATOM_INT(_n_18049)) {
            _10226 = _size_18051 - _n_18049;
            if ((long)((unsigned long)_10226 +(unsigned long) HIGH_BITS) >= 0){
                _10226 = NewDouble((double)_10226);
            }
        }
        else {
            if (IS_ATOM_INT(_size_18051)) {
                _10226 = NewDouble((double)_size_18051 - DBL_PTR(_n_18049)->dbl);
            }
            else {
                if (IS_ATOM_INT(_n_18049)) {
                    _10226 = NewDouble(DBL_PTR(_size_18051)->dbl - (double)_n_18049);
                }
                else
                _10226 = NewDouble(DBL_PTR(_size_18051)->dbl - DBL_PTR(_n_18049)->dbl);
            }
        }
        if (IS_ATOM_INT(_10226)) {
            _10227 = _10226 - 4;
            if ((long)((unsigned long)_10227 +(unsigned long) HIGH_BITS) >= 0){
                _10227 = NewDouble((double)_10227);
            }
        }
        else {
            _10227 = NewDouble(DBL_PTR(_10226)->dbl - (double)4);
        }
        DeRef(_10226);
        _10226 = NOVALUE;
        DeRef(_x_inlined_put4_at_134_18086);
        _x_inlined_put4_at_134_18086 = _10227;
        _10227 = NOVALUE;

        /** 	poke4(mem0, x) -- faster than doing divides etc.*/
        if (IS_ATOM_INT(_48mem0_17438)){
            poke4_addr = (unsigned long *)_48mem0_17438;
        }
        else {
            poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_48mem0_17438)->dbl);
        }
        if (IS_ATOM_INT(_x_inlined_put4_at_134_18086)) {
            *poke4_addr = (unsigned long)_x_inlined_put4_at_134_18086;
        }
        else {
            *poke4_addr = (unsigned long)DBL_PTR(_x_inlined_put4_at_134_18086)->dbl;
        }

        /** 	puts(current_db, peek(memseq))*/
        DeRefi(_put4_1__tmp_at137_18087);
        _1 = (int)SEQ_PTR(_48memseq_17673);
        poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        poke4_addr = (unsigned long *)NewS1(_2);
        _put4_1__tmp_at137_18087 = MAKE_SEQ(poke4_addr);
        poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
        while (--_2 >= 0) {
            poke4_addr++;
            _1 = (int)(unsigned char)*poke_addr++;
            *(int *)poke4_addr = _1;
        }
        EPuts(_48current_db_17396, _put4_1__tmp_at137_18087); // DJP 

        /** end procedure*/
        goto L6; // [159] 162
L6: 
        DeRef(_x_inlined_put4_at_134_18086);
        _x_inlined_put4_at_134_18086 = NOVALUE;
        DeRefi(_put4_1__tmp_at137_18087);
        _put4_1__tmp_at137_18087 = NOVALUE;

        /** 					io:seek(current_db, size_ptr)*/

        /** 	return machine_func(M_SEEK, {fn, pos})*/
        Ref(_size_ptr_18052);
        DeRef(_seek_1__tmp_at167_18090);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _48current_db_17396;
        ((int *)_2)[2] = _size_ptr_18052;
        _seek_1__tmp_at167_18090 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_167_18089 = machine(19, _seek_1__tmp_at167_18090);
        DeRef(_seek_1__tmp_at167_18090);
        _seek_1__tmp_at167_18090 = NOVALUE;

        /** 					put4(size-n-4) -- update size on free list too*/
        if (IS_ATOM_INT(_size_18051) && IS_ATOM_INT(_n_18049)) {
            _10228 = _size_18051 - _n_18049;
            if ((long)((unsigned long)_10228 +(unsigned long) HIGH_BITS) >= 0){
                _10228 = NewDouble((double)_10228);
            }
        }
        else {
            if (IS_ATOM_INT(_size_18051)) {
                _10228 = NewDouble((double)_size_18051 - DBL_PTR(_n_18049)->dbl);
            }
            else {
                if (IS_ATOM_INT(_n_18049)) {
                    _10228 = NewDouble(DBL_PTR(_size_18051)->dbl - (double)_n_18049);
                }
                else
                _10228 = NewDouble(DBL_PTR(_size_18051)->dbl - DBL_PTR(_n_18049)->dbl);
            }
        }
        if (IS_ATOM_INT(_10228)) {
            _10229 = _10228 - 4;
            if ((long)((unsigned long)_10229 +(unsigned long) HIGH_BITS) >= 0){
                _10229 = NewDouble((double)_10229);
            }
        }
        else {
            _10229 = NewDouble(DBL_PTR(_10228)->dbl - (double)4);
        }
        DeRef(_10228);
        _10228 = NOVALUE;
        DeRef(_x_inlined_put4_at_190_18094);
        _x_inlined_put4_at_190_18094 = _10229;
        _10229 = NOVALUE;

        /** 	poke4(mem0, x) -- faster than doing divides etc.*/
        if (IS_ATOM_INT(_48mem0_17438)){
            poke4_addr = (unsigned long *)_48mem0_17438;
        }
        else {
            poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_48mem0_17438)->dbl);
        }
        if (IS_ATOM_INT(_x_inlined_put4_at_190_18094)) {
            *poke4_addr = (unsigned long)_x_inlined_put4_at_190_18094;
        }
        else {
            *poke4_addr = (unsigned long)DBL_PTR(_x_inlined_put4_at_190_18094)->dbl;
        }

        /** 	puts(current_db, peek(memseq))*/
        DeRefi(_put4_1__tmp_at193_18095);
        _1 = (int)SEQ_PTR(_48memseq_17673);
        poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        poke4_addr = (unsigned long *)NewS1(_2);
        _put4_1__tmp_at193_18095 = MAKE_SEQ(poke4_addr);
        poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
        while (--_2 >= 0) {
            poke4_addr++;
            _1 = (int)(unsigned char)*poke_addr++;
            *(int *)poke4_addr = _1;
        }
        EPuts(_48current_db_17396, _put4_1__tmp_at193_18095); // DJP 

        /** end procedure*/
        goto L7; // [215] 218
L7: 
        DeRef(_x_inlined_put4_at_190_18094);
        _x_inlined_put4_at_190_18094 = NOVALUE;
        DeRefi(_put4_1__tmp_at193_18095);
        _put4_1__tmp_at193_18095 = NOVALUE;

        /** 					addr += size-n-4*/
        if (IS_ATOM_INT(_size_18051) && IS_ATOM_INT(_n_18049)) {
            _10230 = _size_18051 - _n_18049;
            if ((long)((unsigned long)_10230 +(unsigned long) HIGH_BITS) >= 0){
                _10230 = NewDouble((double)_10230);
            }
        }
        else {
            if (IS_ATOM_INT(_size_18051)) {
                _10230 = NewDouble((double)_size_18051 - DBL_PTR(_n_18049)->dbl);
            }
            else {
                if (IS_ATOM_INT(_n_18049)) {
                    _10230 = NewDouble(DBL_PTR(_size_18051)->dbl - (double)_n_18049);
                }
                else
                _10230 = NewDouble(DBL_PTR(_size_18051)->dbl - DBL_PTR(_n_18049)->dbl);
            }
        }
        if (IS_ATOM_INT(_10230)) {
            _10231 = _10230 - 4;
            if ((long)((unsigned long)_10231 +(unsigned long) HIGH_BITS) >= 0){
                _10231 = NewDouble((double)_10231);
            }
        }
        else {
            _10231 = NewDouble(DBL_PTR(_10230)->dbl - (double)4);
        }
        DeRef(_10230);
        _10230 = NOVALUE;
        _0 = _addr_18053;
        if (IS_ATOM_INT(_addr_18053) && IS_ATOM_INT(_10231)) {
            _addr_18053 = _addr_18053 + _10231;
            if ((long)((unsigned long)_addr_18053 + (unsigned long)HIGH_BITS) >= 0) 
            _addr_18053 = NewDouble((double)_addr_18053);
        }
        else {
            if (IS_ATOM_INT(_addr_18053)) {
                _addr_18053 = NewDouble((double)_addr_18053 + DBL_PTR(_10231)->dbl);
            }
            else {
                if (IS_ATOM_INT(_10231)) {
                    _addr_18053 = NewDouble(DBL_PTR(_addr_18053)->dbl + (double)_10231);
                }
                else
                _addr_18053 = NewDouble(DBL_PTR(_addr_18053)->dbl + DBL_PTR(_10231)->dbl);
            }
        }
        DeRef(_0);
        DeRef(_10231);
        _10231 = NOVALUE;

        /** 					io:seek(current_db, addr - 4) */
        if (IS_ATOM_INT(_addr_18053)) {
            _10233 = _addr_18053 - 4;
            if ((long)((unsigned long)_10233 +(unsigned long) HIGH_BITS) >= 0){
                _10233 = NewDouble((double)_10233);
            }
        }
        else {
            _10233 = NewDouble(DBL_PTR(_addr_18053)->dbl - (double)4);
        }
        DeRef(_pos_inlined_seek_at_241_18101);
        _pos_inlined_seek_at_241_18101 = _10233;
        _10233 = NOVALUE;

        /** 	return machine_func(M_SEEK, {fn, pos})*/
        Ref(_pos_inlined_seek_at_241_18101);
        DeRef(_seek_1__tmp_at244_18103);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _48current_db_17396;
        ((int *)_2)[2] = _pos_inlined_seek_at_241_18101;
        _seek_1__tmp_at244_18103 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_244_18102 = machine(19, _seek_1__tmp_at244_18103);
        DeRef(_pos_inlined_seek_at_241_18101);
        _pos_inlined_seek_at_241_18101 = NOVALUE;
        DeRef(_seek_1__tmp_at244_18103);
        _seek_1__tmp_at244_18103 = NOVALUE;

        /** 					put4(n+4)*/
        if (IS_ATOM_INT(_n_18049)) {
            _10234 = _n_18049 + 4;
            if ((long)((unsigned long)_10234 + (unsigned long)HIGH_BITS) >= 0) 
            _10234 = NewDouble((double)_10234);
        }
        else {
            _10234 = NewDouble(DBL_PTR(_n_18049)->dbl + (double)4);
        }
        DeRef(_x_inlined_put4_at_263_18106);
        _x_inlined_put4_at_263_18106 = _10234;
        _10234 = NOVALUE;

        /** 	poke4(mem0, x) -- faster than doing divides etc.*/
        if (IS_ATOM_INT(_48mem0_17438)){
            poke4_addr = (unsigned long *)_48mem0_17438;
        }
        else {
            poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_48mem0_17438)->dbl);
        }
        if (IS_ATOM_INT(_x_inlined_put4_at_263_18106)) {
            *poke4_addr = (unsigned long)_x_inlined_put4_at_263_18106;
        }
        else {
            *poke4_addr = (unsigned long)DBL_PTR(_x_inlined_put4_at_263_18106)->dbl;
        }

        /** 	puts(current_db, peek(memseq))*/
        DeRefi(_put4_1__tmp_at266_18107);
        _1 = (int)SEQ_PTR(_48memseq_17673);
        poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        poke4_addr = (unsigned long *)NewS1(_2);
        _put4_1__tmp_at266_18107 = MAKE_SEQ(poke4_addr);
        poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
        while (--_2 >= 0) {
            poke4_addr++;
            _1 = (int)(unsigned char)*poke_addr++;
            *(int *)poke4_addr = _1;
        }
        EPuts(_48current_db_17396, _put4_1__tmp_at266_18107); // DJP 

        /** end procedure*/
        goto L8; // [288] 291
L8: 
        DeRef(_x_inlined_put4_at_263_18106);
        _x_inlined_put4_at_263_18106 = NOVALUE;
        DeRefi(_put4_1__tmp_at266_18107);
        _put4_1__tmp_at266_18107 = NOVALUE;
        goto L9; // [293] 466
L5: 

        /** 					remaining = io:get_bytes(current_db, (free_count-i) * 8)*/
        _10235 = _free_count_18054 - _i_18068;
        if ((long)((unsigned long)_10235 +(unsigned long) HIGH_BITS) >= 0){
            _10235 = NewDouble((double)_10235);
        }
        if (IS_ATOM_INT(_10235)) {
            if (_10235 == (short)_10235)
            _10236 = _10235 * 8;
            else
            _10236 = NewDouble(_10235 * (double)8);
        }
        else {
            _10236 = NewDouble(DBL_PTR(_10235)->dbl * (double)8);
        }
        DeRef(_10235);
        _10235 = NOVALUE;
        _0 = _remaining_18055;
        _remaining_18055 = _18get_bytes(_48current_db_17396, _10236);
        DeRef(_0);
        _10236 = NOVALUE;

        /** 					io:seek(current_db, free_list+8*(i-1))*/
        _10238 = _i_18068 - 1;
        if (_10238 <= INT15)
        _10239 = 8 * _10238;
        else
        _10239 = NewDouble(8 * (double)_10238);
        _10238 = NOVALUE;
        if (IS_ATOM_INT(_free_list_18050) && IS_ATOM_INT(_10239)) {
            _10240 = _free_list_18050 + _10239;
            if ((long)((unsigned long)_10240 + (unsigned long)HIGH_BITS) >= 0) 
            _10240 = NewDouble((double)_10240);
        }
        else {
            if (IS_ATOM_INT(_free_list_18050)) {
                _10240 = NewDouble((double)_free_list_18050 + DBL_PTR(_10239)->dbl);
            }
            else {
                if (IS_ATOM_INT(_10239)) {
                    _10240 = NewDouble(DBL_PTR(_free_list_18050)->dbl + (double)_10239);
                }
                else
                _10240 = NewDouble(DBL_PTR(_free_list_18050)->dbl + DBL_PTR(_10239)->dbl);
            }
        }
        DeRef(_10239);
        _10239 = NOVALUE;
        DeRef(_pos_inlined_seek_at_330_18116);
        _pos_inlined_seek_at_330_18116 = _10240;
        _10240 = NOVALUE;

        /** 	return machine_func(M_SEEK, {fn, pos})*/
        Ref(_pos_inlined_seek_at_330_18116);
        DeRef(_seek_1__tmp_at333_18118);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _48current_db_17396;
        ((int *)_2)[2] = _pos_inlined_seek_at_330_18116;
        _seek_1__tmp_at333_18118 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_333_18117 = machine(19, _seek_1__tmp_at333_18118);
        DeRef(_pos_inlined_seek_at_330_18116);
        _pos_inlined_seek_at_330_18116 = NOVALUE;
        DeRef(_seek_1__tmp_at333_18118);
        _seek_1__tmp_at333_18118 = NOVALUE;

        /** 					putn(remaining)*/

        /** 	puts(current_db, s)*/
        EPuts(_48current_db_17396, _remaining_18055); // DJP 

        /** end procedure*/
        goto LA; // [358] 361
LA: 

        /** 					io:seek(current_db, FREE_COUNT)*/

        /** 	return machine_func(M_SEEK, {fn, pos})*/
        DeRefi(_seek_1__tmp_at364_18122);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _48current_db_17396;
        ((int *)_2)[2] = 7;
        _seek_1__tmp_at364_18122 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_364_18121 = machine(19, _seek_1__tmp_at364_18122);
        DeRefi(_seek_1__tmp_at364_18122);
        _seek_1__tmp_at364_18122 = NOVALUE;

        /** 					put4(free_count-1)*/
        _10241 = _free_count_18054 - 1;
        if ((long)((unsigned long)_10241 +(unsigned long) HIGH_BITS) >= 0){
            _10241 = NewDouble((double)_10241);
        }
        DeRef(_x_inlined_put4_at_383_18125);
        _x_inlined_put4_at_383_18125 = _10241;
        _10241 = NOVALUE;

        /** 	poke4(mem0, x) -- faster than doing divides etc.*/
        if (IS_ATOM_INT(_48mem0_17438)){
            poke4_addr = (unsigned long *)_48mem0_17438;
        }
        else {
            poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_48mem0_17438)->dbl);
        }
        if (IS_ATOM_INT(_x_inlined_put4_at_383_18125)) {
            *poke4_addr = (unsigned long)_x_inlined_put4_at_383_18125;
        }
        else {
            *poke4_addr = (unsigned long)DBL_PTR(_x_inlined_put4_at_383_18125)->dbl;
        }

        /** 	puts(current_db, peek(memseq))*/
        DeRefi(_put4_1__tmp_at386_18126);
        _1 = (int)SEQ_PTR(_48memseq_17673);
        poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        poke4_addr = (unsigned long *)NewS1(_2);
        _put4_1__tmp_at386_18126 = MAKE_SEQ(poke4_addr);
        poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
        while (--_2 >= 0) {
            poke4_addr++;
            _1 = (int)(unsigned char)*poke_addr++;
            *(int *)poke4_addr = _1;
        }
        EPuts(_48current_db_17396, _put4_1__tmp_at386_18126); // DJP 

        /** end procedure*/
        goto LB; // [408] 411
LB: 
        DeRef(_x_inlined_put4_at_383_18125);
        _x_inlined_put4_at_383_18125 = NOVALUE;
        DeRefi(_put4_1__tmp_at386_18126);
        _put4_1__tmp_at386_18126 = NOVALUE;

        /** 					io:seek(current_db, addr - 4)*/
        if (IS_ATOM_INT(_addr_18053)) {
            _10242 = _addr_18053 - 4;
            if ((long)((unsigned long)_10242 +(unsigned long) HIGH_BITS) >= 0){
                _10242 = NewDouble((double)_10242);
            }
        }
        else {
            _10242 = NewDouble(DBL_PTR(_addr_18053)->dbl - (double)4);
        }
        DeRef(_pos_inlined_seek_at_420_18129);
        _pos_inlined_seek_at_420_18129 = _10242;
        _10242 = NOVALUE;

        /** 	return machine_func(M_SEEK, {fn, pos})*/
        Ref(_pos_inlined_seek_at_420_18129);
        DeRef(_seek_1__tmp_at423_18131);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _48current_db_17396;
        ((int *)_2)[2] = _pos_inlined_seek_at_420_18129;
        _seek_1__tmp_at423_18131 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_423_18130 = machine(19, _seek_1__tmp_at423_18131);
        DeRef(_pos_inlined_seek_at_420_18129);
        _pos_inlined_seek_at_420_18129 = NOVALUE;
        DeRef(_seek_1__tmp_at423_18131);
        _seek_1__tmp_at423_18131 = NOVALUE;

        /** 					put4(size) -- in case size was not updated by db_free()*/

        /** 	poke4(mem0, x) -- faster than doing divides etc.*/
        if (IS_ATOM_INT(_48mem0_17438)){
            poke4_addr = (unsigned long *)_48mem0_17438;
        }
        else {
            poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_48mem0_17438)->dbl);
        }
        if (IS_ATOM_INT(_size_18051)) {
            *poke4_addr = (unsigned long)_size_18051;
        }
        else {
            *poke4_addr = (unsigned long)DBL_PTR(_size_18051)->dbl;
        }

        /** 	puts(current_db, peek(memseq))*/
        DeRefi(_put4_1__tmp_at438_18133);
        _1 = (int)SEQ_PTR(_48memseq_17673);
        poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        poke4_addr = (unsigned long *)NewS1(_2);
        _put4_1__tmp_at438_18133 = MAKE_SEQ(poke4_addr);
        poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
        while (--_2 >= 0) {
            poke4_addr++;
            _1 = (int)(unsigned char)*poke_addr++;
            *(int *)poke4_addr = _1;
        }
        EPuts(_48current_db_17396, _put4_1__tmp_at438_18133); // DJP 

        /** end procedure*/
        goto LC; // [460] 463
LC: 
        DeRefi(_put4_1__tmp_at438_18133);
        _put4_1__tmp_at438_18133 = NOVALUE;
L9: 

        /** 				return addr*/
        DeRef(_n_18049);
        DeRef(_free_list_18050);
        DeRef(_size_18051);
        DeRef(_size_ptr_18052);
        DeRef(_remaining_18055);
        return _addr_18053;
L4: 

        /** 			size_ptr += 8*/
        _0 = _size_ptr_18052;
        if (IS_ATOM_INT(_size_ptr_18052)) {
            _size_ptr_18052 = _size_ptr_18052 + 8;
            if ((long)((unsigned long)_size_ptr_18052 + (unsigned long)HIGH_BITS) >= 0) 
            _size_ptr_18052 = NewDouble((double)_size_ptr_18052);
        }
        else {
            _size_ptr_18052 = NewDouble(DBL_PTR(_size_ptr_18052)->dbl + (double)8);
        }
        DeRef(_0);

        /** 		end for*/
        _i_18068 = _i_18068 + 1;
        goto L2; // [481] 71
L3: 
        ;
    }
L1: 

    /** 	io:seek(current_db, -1)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at490_18137);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _48current_db_17396;
    ((int *)_2)[2] = -1;
    _seek_1__tmp_at490_18137 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_490_18136 = machine(19, _seek_1__tmp_at490_18137);
    DeRefi(_seek_1__tmp_at490_18137);
    _seek_1__tmp_at490_18137 = NOVALUE;

    /** 	put4(n+4)*/
    if (IS_ATOM_INT(_n_18049)) {
        _10244 = _n_18049 + 4;
        if ((long)((unsigned long)_10244 + (unsigned long)HIGH_BITS) >= 0) 
        _10244 = NewDouble((double)_10244);
    }
    else {
        _10244 = NewDouble(DBL_PTR(_n_18049)->dbl + (double)4);
    }
    DeRef(_x_inlined_put4_at_509_18140);
    _x_inlined_put4_at_509_18140 = _10244;
    _10244 = NOVALUE;

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_48mem0_17438)){
        poke4_addr = (unsigned long *)_48mem0_17438;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_48mem0_17438)->dbl);
    }
    if (IS_ATOM_INT(_x_inlined_put4_at_509_18140)) {
        *poke4_addr = (unsigned long)_x_inlined_put4_at_509_18140;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_x_inlined_put4_at_509_18140)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at512_18141);
    _1 = (int)SEQ_PTR(_48memseq_17673);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at512_18141 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_48current_db_17396, _put4_1__tmp_at512_18141); // DJP 

    /** end procedure*/
    goto LD; // [534] 537
LD: 
    DeRef(_x_inlined_put4_at_509_18140);
    _x_inlined_put4_at_509_18140 = NOVALUE;
    DeRefi(_put4_1__tmp_at512_18141);
    _put4_1__tmp_at512_18141 = NOVALUE;

    /** 	return io:where(current_db)*/

    /** 	return machine_func(M_WHERE, fn)*/
    DeRef(_where_inlined_where_at_542_18143);
    _where_inlined_where_at_542_18143 = machine(20, _48current_db_17396);
    DeRef(_n_18049);
    DeRef(_free_list_18050);
    DeRef(_size_18051);
    DeRef(_size_ptr_18052);
    DeRef(_addr_18053);
    DeRef(_remaining_18055);
    return _where_inlined_where_at_542_18143;
    ;
}


void _48db_free(int _p_18146)
{
    int _psize_18147 = NOVALUE;
    int _i_18148 = NOVALUE;
    int _size_18149 = NOVALUE;
    int _addr_18150 = NOVALUE;
    int _free_list_18151 = NOVALUE;
    int _free_list_space_18152 = NOVALUE;
    int _new_space_18153 = NOVALUE;
    int _to_be_freed_18154 = NOVALUE;
    int _prev_addr_18155 = NOVALUE;
    int _prev_size_18156 = NOVALUE;
    int _free_count_18157 = NOVALUE;
    int _remaining_18158 = NOVALUE;
    int _seek_1__tmp_at11_18163 = NOVALUE;
    int _seek_inlined_seek_at_11_18162 = NOVALUE;
    int _pos_inlined_seek_at_8_18161 = NOVALUE;
    int _seek_1__tmp_at33_18167 = NOVALUE;
    int _seek_inlined_seek_at_33_18166 = NOVALUE;
    int _seek_1__tmp_at69_18174 = NOVALUE;
    int _seek_inlined_seek_at_69_18173 = NOVALUE;
    int _pos_inlined_seek_at_66_18172 = NOVALUE;
    int _seek_1__tmp_at133_18187 = NOVALUE;
    int _seek_inlined_seek_at_133_18186 = NOVALUE;
    int _seek_1__tmp_at157_18191 = NOVALUE;
    int _seek_inlined_seek_at_157_18190 = NOVALUE;
    int _put4_1__tmp_at172_18193 = NOVALUE;
    int _seek_1__tmp_at202_18196 = NOVALUE;
    int _seek_inlined_seek_at_202_18195 = NOVALUE;
    int _seek_1__tmp_at234_18201 = NOVALUE;
    int _seek_inlined_seek_at_234_18200 = NOVALUE;
    int _s_inlined_putn_at_274_18207 = NOVALUE;
    int _seek_1__tmp_at297_18210 = NOVALUE;
    int _seek_inlined_seek_at_297_18209 = NOVALUE;
    int _seek_1__tmp_at430_18231 = NOVALUE;
    int _seek_inlined_seek_at_430_18230 = NOVALUE;
    int _pos_inlined_seek_at_427_18229 = NOVALUE;
    int _put4_1__tmp_at482_18241 = NOVALUE;
    int _x_inlined_put4_at_479_18240 = NOVALUE;
    int _seek_1__tmp_at523_18247 = NOVALUE;
    int _seek_inlined_seek_at_523_18246 = NOVALUE;
    int _pos_inlined_seek_at_520_18245 = NOVALUE;
    int _seek_1__tmp_at574_18257 = NOVALUE;
    int _seek_inlined_seek_at_574_18256 = NOVALUE;
    int _pos_inlined_seek_at_571_18255 = NOVALUE;
    int _seek_1__tmp_at611_18262 = NOVALUE;
    int _seek_inlined_seek_at_611_18261 = NOVALUE;
    int _put4_1__tmp_at626_18264 = NOVALUE;
    int _put4_1__tmp_at664_18269 = NOVALUE;
    int _x_inlined_put4_at_661_18268 = NOVALUE;
    int _seek_1__tmp_at737_18281 = NOVALUE;
    int _seek_inlined_seek_at_737_18280 = NOVALUE;
    int _pos_inlined_seek_at_734_18279 = NOVALUE;
    int _put4_1__tmp_at752_18283 = NOVALUE;
    int _put4_1__tmp_at789_18287 = NOVALUE;
    int _x_inlined_put4_at_786_18286 = NOVALUE;
    int _seek_1__tmp_at837_18295 = NOVALUE;
    int _seek_inlined_seek_at_837_18294 = NOVALUE;
    int _pos_inlined_seek_at_834_18293 = NOVALUE;
    int _seek_1__tmp_at883_18303 = NOVALUE;
    int _seek_inlined_seek_at_883_18302 = NOVALUE;
    int _put4_1__tmp_at898_18305 = NOVALUE;
    int _seek_1__tmp_at943_18312 = NOVALUE;
    int _seek_inlined_seek_at_943_18311 = NOVALUE;
    int _pos_inlined_seek_at_940_18310 = NOVALUE;
    int _put4_1__tmp_at958_18314 = NOVALUE;
    int _put4_1__tmp_at986_18316 = NOVALUE;
    int _10312 = NOVALUE;
    int _10311 = NOVALUE;
    int _10310 = NOVALUE;
    int _10307 = NOVALUE;
    int _10306 = NOVALUE;
    int _10305 = NOVALUE;
    int _10304 = NOVALUE;
    int _10303 = NOVALUE;
    int _10302 = NOVALUE;
    int _10301 = NOVALUE;
    int _10300 = NOVALUE;
    int _10299 = NOVALUE;
    int _10298 = NOVALUE;
    int _10297 = NOVALUE;
    int _10296 = NOVALUE;
    int _10295 = NOVALUE;
    int _10294 = NOVALUE;
    int _10293 = NOVALUE;
    int _10291 = NOVALUE;
    int _10290 = NOVALUE;
    int _10289 = NOVALUE;
    int _10287 = NOVALUE;
    int _10286 = NOVALUE;
    int _10285 = NOVALUE;
    int _10284 = NOVALUE;
    int _10283 = NOVALUE;
    int _10282 = NOVALUE;
    int _10281 = NOVALUE;
    int _10280 = NOVALUE;
    int _10279 = NOVALUE;
    int _10278 = NOVALUE;
    int _10277 = NOVALUE;
    int _10276 = NOVALUE;
    int _10275 = NOVALUE;
    int _10274 = NOVALUE;
    int _10273 = NOVALUE;
    int _10272 = NOVALUE;
    int _10271 = NOVALUE;
    int _10270 = NOVALUE;
    int _10264 = NOVALUE;
    int _10263 = NOVALUE;
    int _10262 = NOVALUE;
    int _10260 = NOVALUE;
    int _10256 = NOVALUE;
    int _10255 = NOVALUE;
    int _10253 = NOVALUE;
    int _10252 = NOVALUE;
    int _10250 = NOVALUE;
    int _10249 = NOVALUE;
    int _10245 = NOVALUE;
    int _0, _1, _2;
    

    /** 	io:seek(current_db, p-4)*/
    if (IS_ATOM_INT(_p_18146)) {
        _10245 = _p_18146 - 4;
        if ((long)((unsigned long)_10245 +(unsigned long) HIGH_BITS) >= 0){
            _10245 = NewDouble((double)_10245);
        }
    }
    else {
        _10245 = NewDouble(DBL_PTR(_p_18146)->dbl - (double)4);
    }
    DeRef(_pos_inlined_seek_at_8_18161);
    _pos_inlined_seek_at_8_18161 = _10245;
    _10245 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_8_18161);
    DeRef(_seek_1__tmp_at11_18163);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _48current_db_17396;
    ((int *)_2)[2] = _pos_inlined_seek_at_8_18161;
    _seek_1__tmp_at11_18163 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_11_18162 = machine(19, _seek_1__tmp_at11_18163);
    DeRef(_pos_inlined_seek_at_8_18161);
    _pos_inlined_seek_at_8_18161 = NOVALUE;
    DeRef(_seek_1__tmp_at11_18163);
    _seek_1__tmp_at11_18163 = NOVALUE;

    /** 	psize = get4()*/
    _0 = _psize_18147;
    _psize_18147 = _48get4();
    DeRef(_0);

    /** 	io:seek(current_db, FREE_COUNT)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at33_18167);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _48current_db_17396;
    ((int *)_2)[2] = 7;
    _seek_1__tmp_at33_18167 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_33_18166 = machine(19, _seek_1__tmp_at33_18167);
    DeRefi(_seek_1__tmp_at33_18167);
    _seek_1__tmp_at33_18167 = NOVALUE;

    /** 	free_count = get4()*/
    _free_count_18157 = _48get4();
    if (!IS_ATOM_INT(_free_count_18157)) {
        _1 = (long)(DBL_PTR(_free_count_18157)->dbl);
        DeRefDS(_free_count_18157);
        _free_count_18157 = _1;
    }

    /** 	free_list = get4()*/
    _0 = _free_list_18151;
    _free_list_18151 = _48get4();
    DeRef(_0);

    /** 	io:seek(current_db, free_list - 4)*/
    if (IS_ATOM_INT(_free_list_18151)) {
        _10249 = _free_list_18151 - 4;
        if ((long)((unsigned long)_10249 +(unsigned long) HIGH_BITS) >= 0){
            _10249 = NewDouble((double)_10249);
        }
    }
    else {
        _10249 = NewDouble(DBL_PTR(_free_list_18151)->dbl - (double)4);
    }
    DeRef(_pos_inlined_seek_at_66_18172);
    _pos_inlined_seek_at_66_18172 = _10249;
    _10249 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_66_18172);
    DeRef(_seek_1__tmp_at69_18174);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _48current_db_17396;
    ((int *)_2)[2] = _pos_inlined_seek_at_66_18172;
    _seek_1__tmp_at69_18174 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_69_18173 = machine(19, _seek_1__tmp_at69_18174);
    DeRef(_pos_inlined_seek_at_66_18172);
    _pos_inlined_seek_at_66_18172 = NOVALUE;
    DeRef(_seek_1__tmp_at69_18174);
    _seek_1__tmp_at69_18174 = NOVALUE;

    /** 	free_list_space = get4()-4*/
    _10250 = _48get4();
    DeRef(_free_list_space_18152);
    if (IS_ATOM_INT(_10250)) {
        _free_list_space_18152 = _10250 - 4;
        if ((long)((unsigned long)_free_list_space_18152 +(unsigned long) HIGH_BITS) >= 0){
            _free_list_space_18152 = NewDouble((double)_free_list_space_18152);
        }
    }
    else {
        _free_list_space_18152 = binary_op(MINUS, _10250, 4);
    }
    DeRef(_10250);
    _10250 = NOVALUE;

    /** 	if free_list_space < 8 * (free_count+1) then*/
    _10252 = _free_count_18157 + 1;
    if (_10252 > MAXINT){
        _10252 = NewDouble((double)_10252);
    }
    if (IS_ATOM_INT(_10252)) {
        if (_10252 <= INT15 && _10252 >= -INT15)
        _10253 = 8 * _10252;
        else
        _10253 = NewDouble(8 * (double)_10252);
    }
    else {
        _10253 = NewDouble((double)8 * DBL_PTR(_10252)->dbl);
    }
    DeRef(_10252);
    _10252 = NOVALUE;
    if (binary_op_a(GREATEREQ, _free_list_space_18152, _10253)){
        DeRef(_10253);
        _10253 = NOVALUE;
        goto L1; // [102] 314
    }
    DeRef(_10253);
    _10253 = NOVALUE;

    /** 		new_space = floor(free_list_space + free_list_space / 2)*/
    if (IS_ATOM_INT(_free_list_space_18152)) {
        if (_free_list_space_18152 & 1) {
            _10255 = NewDouble((_free_list_space_18152 >> 1) + 0.5);
        }
        else
        _10255 = _free_list_space_18152 >> 1;
    }
    else {
        _10255 = binary_op(DIVIDE, _free_list_space_18152, 2);
    }
    if (IS_ATOM_INT(_free_list_space_18152) && IS_ATOM_INT(_10255)) {
        _10256 = _free_list_space_18152 + _10255;
        if ((long)((unsigned long)_10256 + (unsigned long)HIGH_BITS) >= 0) 
        _10256 = NewDouble((double)_10256);
    }
    else {
        if (IS_ATOM_INT(_free_list_space_18152)) {
            _10256 = NewDouble((double)_free_list_space_18152 + DBL_PTR(_10255)->dbl);
        }
        else {
            if (IS_ATOM_INT(_10255)) {
                _10256 = NewDouble(DBL_PTR(_free_list_space_18152)->dbl + (double)_10255);
            }
            else
            _10256 = NewDouble(DBL_PTR(_free_list_space_18152)->dbl + DBL_PTR(_10255)->dbl);
        }
    }
    DeRef(_10255);
    _10255 = NOVALUE;
    DeRef(_new_space_18153);
    if (IS_ATOM_INT(_10256))
    _new_space_18153 = e_floor(_10256);
    else
    _new_space_18153 = unary_op(FLOOR, _10256);
    DeRef(_10256);
    _10256 = NOVALUE;

    /** 		to_be_freed = free_list*/
    Ref(_free_list_18151);
    DeRef(_to_be_freed_18154);
    _to_be_freed_18154 = _free_list_18151;

    /** 		free_list = db_allocate(new_space)*/
    Ref(_new_space_18153);
    _0 = _free_list_18151;
    _free_list_18151 = _48db_allocate(_new_space_18153);
    DeRef(_0);

    /** 		io:seek(current_db, FREE_COUNT)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at133_18187);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _48current_db_17396;
    ((int *)_2)[2] = 7;
    _seek_1__tmp_at133_18187 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_133_18186 = machine(19, _seek_1__tmp_at133_18187);
    DeRefi(_seek_1__tmp_at133_18187);
    _seek_1__tmp_at133_18187 = NOVALUE;

    /** 		free_count = get4() -- db_allocate may have changed it*/
    _free_count_18157 = _48get4();
    if (!IS_ATOM_INT(_free_count_18157)) {
        _1 = (long)(DBL_PTR(_free_count_18157)->dbl);
        DeRefDS(_free_count_18157);
        _free_count_18157 = _1;
    }

    /** 		io:seek(current_db, FREE_LIST)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at157_18191);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _48current_db_17396;
    ((int *)_2)[2] = 11;
    _seek_1__tmp_at157_18191 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_157_18190 = machine(19, _seek_1__tmp_at157_18191);
    DeRefi(_seek_1__tmp_at157_18191);
    _seek_1__tmp_at157_18191 = NOVALUE;

    /** 		put4(free_list)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_48mem0_17438)){
        poke4_addr = (unsigned long *)_48mem0_17438;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_48mem0_17438)->dbl);
    }
    if (IS_ATOM_INT(_free_list_18151)) {
        *poke4_addr = (unsigned long)_free_list_18151;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_free_list_18151)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at172_18193);
    _1 = (int)SEQ_PTR(_48memseq_17673);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at172_18193 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_48current_db_17396, _put4_1__tmp_at172_18193); // DJP 

    /** end procedure*/
    goto L2; // [194] 197
L2: 
    DeRefi(_put4_1__tmp_at172_18193);
    _put4_1__tmp_at172_18193 = NOVALUE;

    /** 		io:seek(current_db, to_be_freed)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_to_be_freed_18154);
    DeRef(_seek_1__tmp_at202_18196);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _48current_db_17396;
    ((int *)_2)[2] = _to_be_freed_18154;
    _seek_1__tmp_at202_18196 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_202_18195 = machine(19, _seek_1__tmp_at202_18196);
    DeRef(_seek_1__tmp_at202_18196);
    _seek_1__tmp_at202_18196 = NOVALUE;

    /** 		remaining = io:get_bytes(current_db, 8*free_count)*/
    if (_free_count_18157 <= INT15 && _free_count_18157 >= -INT15)
    _10260 = 8 * _free_count_18157;
    else
    _10260 = NewDouble(8 * (double)_free_count_18157);
    _0 = _remaining_18158;
    _remaining_18158 = _18get_bytes(_48current_db_17396, _10260);
    DeRef(_0);
    _10260 = NOVALUE;

    /** 		io:seek(current_db, free_list)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_free_list_18151);
    DeRef(_seek_1__tmp_at234_18201);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _48current_db_17396;
    ((int *)_2)[2] = _free_list_18151;
    _seek_1__tmp_at234_18201 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_234_18200 = machine(19, _seek_1__tmp_at234_18201);
    DeRef(_seek_1__tmp_at234_18201);
    _seek_1__tmp_at234_18201 = NOVALUE;

    /** 		putn(remaining)*/

    /** 	puts(current_db, s)*/
    EPuts(_48current_db_17396, _remaining_18158); // DJP 

    /** end procedure*/
    goto L3; // [259] 262
L3: 

    /** 		putn(repeat(0, new_space-length(remaining)))*/
    if (IS_SEQUENCE(_remaining_18158)){
            _10262 = SEQ_PTR(_remaining_18158)->length;
    }
    else {
        _10262 = 1;
    }
    if (IS_ATOM_INT(_new_space_18153)) {
        _10263 = _new_space_18153 - _10262;
    }
    else {
        _10263 = NewDouble(DBL_PTR(_new_space_18153)->dbl - (double)_10262);
    }
    _10262 = NOVALUE;
    _10264 = Repeat(0, _10263);
    DeRef(_10263);
    _10263 = NOVALUE;
    DeRefi(_s_inlined_putn_at_274_18207);
    _s_inlined_putn_at_274_18207 = _10264;
    _10264 = NOVALUE;

    /** 	puts(current_db, s)*/
    EPuts(_48current_db_17396, _s_inlined_putn_at_274_18207); // DJP 

    /** end procedure*/
    goto L4; // [289] 292
L4: 
    DeRefi(_s_inlined_putn_at_274_18207);
    _s_inlined_putn_at_274_18207 = NOVALUE;

    /** 		io:seek(current_db, free_list)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_free_list_18151);
    DeRef(_seek_1__tmp_at297_18210);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _48current_db_17396;
    ((int *)_2)[2] = _free_list_18151;
    _seek_1__tmp_at297_18210 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_297_18209 = machine(19, _seek_1__tmp_at297_18210);
    DeRef(_seek_1__tmp_at297_18210);
    _seek_1__tmp_at297_18210 = NOVALUE;
    goto L5; // [311] 320
L1: 

    /** 		new_space = 0*/
    DeRef(_new_space_18153);
    _new_space_18153 = 0;
L5: 

    /** 	i = 1*/
    DeRef(_i_18148);
    _i_18148 = 1;

    /** 	prev_addr = 0*/
    DeRef(_prev_addr_18155);
    _prev_addr_18155 = 0;

    /** 	prev_size = 0*/
    DeRef(_prev_size_18156);
    _prev_size_18156 = 0;

    /** 	while i <= free_count do*/
L6: 
    if (binary_op_a(GREATER, _i_18148, _free_count_18157)){
        goto L7; // [340] 386
    }

    /** 		addr = get4()*/
    _0 = _addr_18150;
    _addr_18150 = _48get4();
    DeRef(_0);

    /** 		size = get4()*/
    _0 = _size_18149;
    _size_18149 = _48get4();
    DeRef(_0);

    /** 		if p < addr then*/
    if (binary_op_a(GREATEREQ, _p_18146, _addr_18150)){
        goto L8; // [356] 365
    }

    /** 			exit*/
    goto L7; // [362] 386
L8: 

    /** 		prev_addr = addr*/
    Ref(_addr_18150);
    DeRef(_prev_addr_18155);
    _prev_addr_18155 = _addr_18150;

    /** 		prev_size = size*/
    Ref(_size_18149);
    DeRef(_prev_size_18156);
    _prev_size_18156 = _size_18149;

    /** 		i += 1*/
    _0 = _i_18148;
    if (IS_ATOM_INT(_i_18148)) {
        _i_18148 = _i_18148 + 1;
        if (_i_18148 > MAXINT){
            _i_18148 = NewDouble((double)_i_18148);
        }
    }
    else
    _i_18148 = binary_op(PLUS, 1, _i_18148);
    DeRef(_0);

    /** 	end while*/
    goto L6; // [383] 340
L7: 

    /** 	if i > 1 and prev_addr + prev_size = p then*/
    if (IS_ATOM_INT(_i_18148)) {
        _10270 = (_i_18148 > 1);
    }
    else {
        _10270 = (DBL_PTR(_i_18148)->dbl > (double)1);
    }
    if (_10270 == 0) {
        goto L9; // [392] 695
    }
    if (IS_ATOM_INT(_prev_addr_18155) && IS_ATOM_INT(_prev_size_18156)) {
        _10272 = _prev_addr_18155 + _prev_size_18156;
        if ((long)((unsigned long)_10272 + (unsigned long)HIGH_BITS) >= 0) 
        _10272 = NewDouble((double)_10272);
    }
    else {
        if (IS_ATOM_INT(_prev_addr_18155)) {
            _10272 = NewDouble((double)_prev_addr_18155 + DBL_PTR(_prev_size_18156)->dbl);
        }
        else {
            if (IS_ATOM_INT(_prev_size_18156)) {
                _10272 = NewDouble(DBL_PTR(_prev_addr_18155)->dbl + (double)_prev_size_18156);
            }
            else
            _10272 = NewDouble(DBL_PTR(_prev_addr_18155)->dbl + DBL_PTR(_prev_size_18156)->dbl);
        }
    }
    if (IS_ATOM_INT(_10272) && IS_ATOM_INT(_p_18146)) {
        _10273 = (_10272 == _p_18146);
    }
    else {
        if (IS_ATOM_INT(_10272)) {
            _10273 = ((double)_10272 == DBL_PTR(_p_18146)->dbl);
        }
        else {
            if (IS_ATOM_INT(_p_18146)) {
                _10273 = (DBL_PTR(_10272)->dbl == (double)_p_18146);
            }
            else
            _10273 = (DBL_PTR(_10272)->dbl == DBL_PTR(_p_18146)->dbl);
        }
    }
    DeRef(_10272);
    _10272 = NOVALUE;
    if (_10273 == 0)
    {
        DeRef(_10273);
        _10273 = NOVALUE;
        goto L9; // [405] 695
    }
    else{
        DeRef(_10273);
        _10273 = NOVALUE;
    }

    /** 		io:seek(current_db, free_list+(i-2)*8+4)*/
    if (IS_ATOM_INT(_i_18148)) {
        _10274 = _i_18148 - 2;
        if ((long)((unsigned long)_10274 +(unsigned long) HIGH_BITS) >= 0){
            _10274 = NewDouble((double)_10274);
        }
    }
    else {
        _10274 = NewDouble(DBL_PTR(_i_18148)->dbl - (double)2);
    }
    if (IS_ATOM_INT(_10274)) {
        if (_10274 == (short)_10274)
        _10275 = _10274 * 8;
        else
        _10275 = NewDouble(_10274 * (double)8);
    }
    else {
        _10275 = NewDouble(DBL_PTR(_10274)->dbl * (double)8);
    }
    DeRef(_10274);
    _10274 = NOVALUE;
    if (IS_ATOM_INT(_free_list_18151) && IS_ATOM_INT(_10275)) {
        _10276 = _free_list_18151 + _10275;
        if ((long)((unsigned long)_10276 + (unsigned long)HIGH_BITS) >= 0) 
        _10276 = NewDouble((double)_10276);
    }
    else {
        if (IS_ATOM_INT(_free_list_18151)) {
            _10276 = NewDouble((double)_free_list_18151 + DBL_PTR(_10275)->dbl);
        }
        else {
            if (IS_ATOM_INT(_10275)) {
                _10276 = NewDouble(DBL_PTR(_free_list_18151)->dbl + (double)_10275);
            }
            else
            _10276 = NewDouble(DBL_PTR(_free_list_18151)->dbl + DBL_PTR(_10275)->dbl);
        }
    }
    DeRef(_10275);
    _10275 = NOVALUE;
    if (IS_ATOM_INT(_10276)) {
        _10277 = _10276 + 4;
        if ((long)((unsigned long)_10277 + (unsigned long)HIGH_BITS) >= 0) 
        _10277 = NewDouble((double)_10277);
    }
    else {
        _10277 = NewDouble(DBL_PTR(_10276)->dbl + (double)4);
    }
    DeRef(_10276);
    _10276 = NOVALUE;
    DeRef(_pos_inlined_seek_at_427_18229);
    _pos_inlined_seek_at_427_18229 = _10277;
    _10277 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_427_18229);
    DeRef(_seek_1__tmp_at430_18231);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _48current_db_17396;
    ((int *)_2)[2] = _pos_inlined_seek_at_427_18229;
    _seek_1__tmp_at430_18231 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_430_18230 = machine(19, _seek_1__tmp_at430_18231);
    DeRef(_pos_inlined_seek_at_427_18229);
    _pos_inlined_seek_at_427_18229 = NOVALUE;
    DeRef(_seek_1__tmp_at430_18231);
    _seek_1__tmp_at430_18231 = NOVALUE;

    /** 		if i < free_count and p + psize = addr then*/
    if (IS_ATOM_INT(_i_18148)) {
        _10278 = (_i_18148 < _free_count_18157);
    }
    else {
        _10278 = (DBL_PTR(_i_18148)->dbl < (double)_free_count_18157);
    }
    if (_10278 == 0) {
        goto LA; // [450] 656
    }
    if (IS_ATOM_INT(_p_18146) && IS_ATOM_INT(_psize_18147)) {
        _10280 = _p_18146 + _psize_18147;
        if ((long)((unsigned long)_10280 + (unsigned long)HIGH_BITS) >= 0) 
        _10280 = NewDouble((double)_10280);
    }
    else {
        if (IS_ATOM_INT(_p_18146)) {
            _10280 = NewDouble((double)_p_18146 + DBL_PTR(_psize_18147)->dbl);
        }
        else {
            if (IS_ATOM_INT(_psize_18147)) {
                _10280 = NewDouble(DBL_PTR(_p_18146)->dbl + (double)_psize_18147);
            }
            else
            _10280 = NewDouble(DBL_PTR(_p_18146)->dbl + DBL_PTR(_psize_18147)->dbl);
        }
    }
    if (IS_ATOM_INT(_10280) && IS_ATOM_INT(_addr_18150)) {
        _10281 = (_10280 == _addr_18150);
    }
    else {
        if (IS_ATOM_INT(_10280)) {
            _10281 = ((double)_10280 == DBL_PTR(_addr_18150)->dbl);
        }
        else {
            if (IS_ATOM_INT(_addr_18150)) {
                _10281 = (DBL_PTR(_10280)->dbl == (double)_addr_18150);
            }
            else
            _10281 = (DBL_PTR(_10280)->dbl == DBL_PTR(_addr_18150)->dbl);
        }
    }
    DeRef(_10280);
    _10280 = NOVALUE;
    if (_10281 == 0)
    {
        DeRef(_10281);
        _10281 = NOVALUE;
        goto LA; // [465] 656
    }
    else{
        DeRef(_10281);
        _10281 = NOVALUE;
    }

    /** 			put4(prev_size+psize+size) -- update size on free list (only)*/
    if (IS_ATOM_INT(_prev_size_18156) && IS_ATOM_INT(_psize_18147)) {
        _10282 = _prev_size_18156 + _psize_18147;
        if ((long)((unsigned long)_10282 + (unsigned long)HIGH_BITS) >= 0) 
        _10282 = NewDouble((double)_10282);
    }
    else {
        if (IS_ATOM_INT(_prev_size_18156)) {
            _10282 = NewDouble((double)_prev_size_18156 + DBL_PTR(_psize_18147)->dbl);
        }
        else {
            if (IS_ATOM_INT(_psize_18147)) {
                _10282 = NewDouble(DBL_PTR(_prev_size_18156)->dbl + (double)_psize_18147);
            }
            else
            _10282 = NewDouble(DBL_PTR(_prev_size_18156)->dbl + DBL_PTR(_psize_18147)->dbl);
        }
    }
    if (IS_ATOM_INT(_10282) && IS_ATOM_INT(_size_18149)) {
        _10283 = _10282 + _size_18149;
        if ((long)((unsigned long)_10283 + (unsigned long)HIGH_BITS) >= 0) 
        _10283 = NewDouble((double)_10283);
    }
    else {
        if (IS_ATOM_INT(_10282)) {
            _10283 = NewDouble((double)_10282 + DBL_PTR(_size_18149)->dbl);
        }
        else {
            if (IS_ATOM_INT(_size_18149)) {
                _10283 = NewDouble(DBL_PTR(_10282)->dbl + (double)_size_18149);
            }
            else
            _10283 = NewDouble(DBL_PTR(_10282)->dbl + DBL_PTR(_size_18149)->dbl);
        }
    }
    DeRef(_10282);
    _10282 = NOVALUE;
    DeRef(_x_inlined_put4_at_479_18240);
    _x_inlined_put4_at_479_18240 = _10283;
    _10283 = NOVALUE;

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_48mem0_17438)){
        poke4_addr = (unsigned long *)_48mem0_17438;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_48mem0_17438)->dbl);
    }
    if (IS_ATOM_INT(_x_inlined_put4_at_479_18240)) {
        *poke4_addr = (unsigned long)_x_inlined_put4_at_479_18240;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_x_inlined_put4_at_479_18240)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at482_18241);
    _1 = (int)SEQ_PTR(_48memseq_17673);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at482_18241 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_48current_db_17396, _put4_1__tmp_at482_18241); // DJP 

    /** end procedure*/
    goto LB; // [504] 507
LB: 
    DeRef(_x_inlined_put4_at_479_18240);
    _x_inlined_put4_at_479_18240 = NOVALUE;
    DeRefi(_put4_1__tmp_at482_18241);
    _put4_1__tmp_at482_18241 = NOVALUE;

    /** 			io:seek(current_db, free_list+i*8)*/
    if (IS_ATOM_INT(_i_18148)) {
        if (_i_18148 == (short)_i_18148)
        _10284 = _i_18148 * 8;
        else
        _10284 = NewDouble(_i_18148 * (double)8);
    }
    else {
        _10284 = NewDouble(DBL_PTR(_i_18148)->dbl * (double)8);
    }
    if (IS_ATOM_INT(_free_list_18151) && IS_ATOM_INT(_10284)) {
        _10285 = _free_list_18151 + _10284;
        if ((long)((unsigned long)_10285 + (unsigned long)HIGH_BITS) >= 0) 
        _10285 = NewDouble((double)_10285);
    }
    else {
        if (IS_ATOM_INT(_free_list_18151)) {
            _10285 = NewDouble((double)_free_list_18151 + DBL_PTR(_10284)->dbl);
        }
        else {
            if (IS_ATOM_INT(_10284)) {
                _10285 = NewDouble(DBL_PTR(_free_list_18151)->dbl + (double)_10284);
            }
            else
            _10285 = NewDouble(DBL_PTR(_free_list_18151)->dbl + DBL_PTR(_10284)->dbl);
        }
    }
    DeRef(_10284);
    _10284 = NOVALUE;
    DeRef(_pos_inlined_seek_at_520_18245);
    _pos_inlined_seek_at_520_18245 = _10285;
    _10285 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_520_18245);
    DeRef(_seek_1__tmp_at523_18247);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _48current_db_17396;
    ((int *)_2)[2] = _pos_inlined_seek_at_520_18245;
    _seek_1__tmp_at523_18247 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_523_18246 = machine(19, _seek_1__tmp_at523_18247);
    DeRef(_pos_inlined_seek_at_520_18245);
    _pos_inlined_seek_at_520_18245 = NOVALUE;
    DeRef(_seek_1__tmp_at523_18247);
    _seek_1__tmp_at523_18247 = NOVALUE;

    /** 			remaining = io:get_bytes(current_db, (free_count-i)*8)*/
    if (IS_ATOM_INT(_i_18148)) {
        _10286 = _free_count_18157 - _i_18148;
        if ((long)((unsigned long)_10286 +(unsigned long) HIGH_BITS) >= 0){
            _10286 = NewDouble((double)_10286);
        }
    }
    else {
        _10286 = NewDouble((double)_free_count_18157 - DBL_PTR(_i_18148)->dbl);
    }
    if (IS_ATOM_INT(_10286)) {
        if (_10286 == (short)_10286)
        _10287 = _10286 * 8;
        else
        _10287 = NewDouble(_10286 * (double)8);
    }
    else {
        _10287 = NewDouble(DBL_PTR(_10286)->dbl * (double)8);
    }
    DeRef(_10286);
    _10286 = NOVALUE;
    _0 = _remaining_18158;
    _remaining_18158 = _18get_bytes(_48current_db_17396, _10287);
    DeRef(_0);
    _10287 = NOVALUE;

    /** 			io:seek(current_db, free_list+(i-1)*8)*/
    if (IS_ATOM_INT(_i_18148)) {
        _10289 = _i_18148 - 1;
        if ((long)((unsigned long)_10289 +(unsigned long) HIGH_BITS) >= 0){
            _10289 = NewDouble((double)_10289);
        }
    }
    else {
        _10289 = NewDouble(DBL_PTR(_i_18148)->dbl - (double)1);
    }
    if (IS_ATOM_INT(_10289)) {
        if (_10289 == (short)_10289)
        _10290 = _10289 * 8;
        else
        _10290 = NewDouble(_10289 * (double)8);
    }
    else {
        _10290 = NewDouble(DBL_PTR(_10289)->dbl * (double)8);
    }
    DeRef(_10289);
    _10289 = NOVALUE;
    if (IS_ATOM_INT(_free_list_18151) && IS_ATOM_INT(_10290)) {
        _10291 = _free_list_18151 + _10290;
        if ((long)((unsigned long)_10291 + (unsigned long)HIGH_BITS) >= 0) 
        _10291 = NewDouble((double)_10291);
    }
    else {
        if (IS_ATOM_INT(_free_list_18151)) {
            _10291 = NewDouble((double)_free_list_18151 + DBL_PTR(_10290)->dbl);
        }
        else {
            if (IS_ATOM_INT(_10290)) {
                _10291 = NewDouble(DBL_PTR(_free_list_18151)->dbl + (double)_10290);
            }
            else
            _10291 = NewDouble(DBL_PTR(_free_list_18151)->dbl + DBL_PTR(_10290)->dbl);
        }
    }
    DeRef(_10290);
    _10290 = NOVALUE;
    DeRef(_pos_inlined_seek_at_571_18255);
    _pos_inlined_seek_at_571_18255 = _10291;
    _10291 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_571_18255);
    DeRef(_seek_1__tmp_at574_18257);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _48current_db_17396;
    ((int *)_2)[2] = _pos_inlined_seek_at_571_18255;
    _seek_1__tmp_at574_18257 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_574_18256 = machine(19, _seek_1__tmp_at574_18257);
    DeRef(_pos_inlined_seek_at_571_18255);
    _pos_inlined_seek_at_571_18255 = NOVALUE;
    DeRef(_seek_1__tmp_at574_18257);
    _seek_1__tmp_at574_18257 = NOVALUE;

    /** 			putn(remaining)*/

    /** 	puts(current_db, s)*/
    EPuts(_48current_db_17396, _remaining_18158); // DJP 

    /** end procedure*/
    goto LC; // [599] 602
LC: 

    /** 			free_count -= 1*/
    _free_count_18157 = _free_count_18157 - 1;

    /** 			io:seek(current_db, FREE_COUNT)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at611_18262);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _48current_db_17396;
    ((int *)_2)[2] = 7;
    _seek_1__tmp_at611_18262 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_611_18261 = machine(19, _seek_1__tmp_at611_18262);
    DeRefi(_seek_1__tmp_at611_18262);
    _seek_1__tmp_at611_18262 = NOVALUE;

    /** 			put4(free_count)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_48mem0_17438)){
        poke4_addr = (unsigned long *)_48mem0_17438;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_48mem0_17438)->dbl);
    }
    *poke4_addr = (unsigned long)_free_count_18157;

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at626_18264);
    _1 = (int)SEQ_PTR(_48memseq_17673);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at626_18264 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_48current_db_17396, _put4_1__tmp_at626_18264); // DJP 

    /** end procedure*/
    goto LD; // [648] 651
LD: 
    DeRefi(_put4_1__tmp_at626_18264);
    _put4_1__tmp_at626_18264 = NOVALUE;
    goto LE; // [653] 1028
LA: 

    /** 			put4(prev_size+psize) -- increase previous size on free list (only)*/
    if (IS_ATOM_INT(_prev_size_18156) && IS_ATOM_INT(_psize_18147)) {
        _10293 = _prev_size_18156 + _psize_18147;
        if ((long)((unsigned long)_10293 + (unsigned long)HIGH_BITS) >= 0) 
        _10293 = NewDouble((double)_10293);
    }
    else {
        if (IS_ATOM_INT(_prev_size_18156)) {
            _10293 = NewDouble((double)_prev_size_18156 + DBL_PTR(_psize_18147)->dbl);
        }
        else {
            if (IS_ATOM_INT(_psize_18147)) {
                _10293 = NewDouble(DBL_PTR(_prev_size_18156)->dbl + (double)_psize_18147);
            }
            else
            _10293 = NewDouble(DBL_PTR(_prev_size_18156)->dbl + DBL_PTR(_psize_18147)->dbl);
        }
    }
    DeRef(_x_inlined_put4_at_661_18268);
    _x_inlined_put4_at_661_18268 = _10293;
    _10293 = NOVALUE;

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_48mem0_17438)){
        poke4_addr = (unsigned long *)_48mem0_17438;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_48mem0_17438)->dbl);
    }
    if (IS_ATOM_INT(_x_inlined_put4_at_661_18268)) {
        *poke4_addr = (unsigned long)_x_inlined_put4_at_661_18268;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_x_inlined_put4_at_661_18268)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at664_18269);
    _1 = (int)SEQ_PTR(_48memseq_17673);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at664_18269 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_48current_db_17396, _put4_1__tmp_at664_18269); // DJP 

    /** end procedure*/
    goto LF; // [686] 689
LF: 
    DeRef(_x_inlined_put4_at_661_18268);
    _x_inlined_put4_at_661_18268 = NOVALUE;
    DeRefi(_put4_1__tmp_at664_18269);
    _put4_1__tmp_at664_18269 = NOVALUE;
    goto LE; // [692] 1028
L9: 

    /** 	elsif i < free_count and p + psize = addr then*/
    if (IS_ATOM_INT(_i_18148)) {
        _10294 = (_i_18148 < _free_count_18157);
    }
    else {
        _10294 = (DBL_PTR(_i_18148)->dbl < (double)_free_count_18157);
    }
    if (_10294 == 0) {
        goto L10; // [701] 819
    }
    if (IS_ATOM_INT(_p_18146) && IS_ATOM_INT(_psize_18147)) {
        _10296 = _p_18146 + _psize_18147;
        if ((long)((unsigned long)_10296 + (unsigned long)HIGH_BITS) >= 0) 
        _10296 = NewDouble((double)_10296);
    }
    else {
        if (IS_ATOM_INT(_p_18146)) {
            _10296 = NewDouble((double)_p_18146 + DBL_PTR(_psize_18147)->dbl);
        }
        else {
            if (IS_ATOM_INT(_psize_18147)) {
                _10296 = NewDouble(DBL_PTR(_p_18146)->dbl + (double)_psize_18147);
            }
            else
            _10296 = NewDouble(DBL_PTR(_p_18146)->dbl + DBL_PTR(_psize_18147)->dbl);
        }
    }
    if (IS_ATOM_INT(_10296) && IS_ATOM_INT(_addr_18150)) {
        _10297 = (_10296 == _addr_18150);
    }
    else {
        if (IS_ATOM_INT(_10296)) {
            _10297 = ((double)_10296 == DBL_PTR(_addr_18150)->dbl);
        }
        else {
            if (IS_ATOM_INT(_addr_18150)) {
                _10297 = (DBL_PTR(_10296)->dbl == (double)_addr_18150);
            }
            else
            _10297 = (DBL_PTR(_10296)->dbl == DBL_PTR(_addr_18150)->dbl);
        }
    }
    DeRef(_10296);
    _10296 = NOVALUE;
    if (_10297 == 0)
    {
        DeRef(_10297);
        _10297 = NOVALUE;
        goto L10; // [716] 819
    }
    else{
        DeRef(_10297);
        _10297 = NOVALUE;
    }

    /** 		io:seek(current_db, free_list+(i-1)*8)*/
    if (IS_ATOM_INT(_i_18148)) {
        _10298 = _i_18148 - 1;
        if ((long)((unsigned long)_10298 +(unsigned long) HIGH_BITS) >= 0){
            _10298 = NewDouble((double)_10298);
        }
    }
    else {
        _10298 = NewDouble(DBL_PTR(_i_18148)->dbl - (double)1);
    }
    if (IS_ATOM_INT(_10298)) {
        if (_10298 == (short)_10298)
        _10299 = _10298 * 8;
        else
        _10299 = NewDouble(_10298 * (double)8);
    }
    else {
        _10299 = NewDouble(DBL_PTR(_10298)->dbl * (double)8);
    }
    DeRef(_10298);
    _10298 = NOVALUE;
    if (IS_ATOM_INT(_free_list_18151) && IS_ATOM_INT(_10299)) {
        _10300 = _free_list_18151 + _10299;
        if ((long)((unsigned long)_10300 + (unsigned long)HIGH_BITS) >= 0) 
        _10300 = NewDouble((double)_10300);
    }
    else {
        if (IS_ATOM_INT(_free_list_18151)) {
            _10300 = NewDouble((double)_free_list_18151 + DBL_PTR(_10299)->dbl);
        }
        else {
            if (IS_ATOM_INT(_10299)) {
                _10300 = NewDouble(DBL_PTR(_free_list_18151)->dbl + (double)_10299);
            }
            else
            _10300 = NewDouble(DBL_PTR(_free_list_18151)->dbl + DBL_PTR(_10299)->dbl);
        }
    }
    DeRef(_10299);
    _10299 = NOVALUE;
    DeRef(_pos_inlined_seek_at_734_18279);
    _pos_inlined_seek_at_734_18279 = _10300;
    _10300 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_734_18279);
    DeRef(_seek_1__tmp_at737_18281);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _48current_db_17396;
    ((int *)_2)[2] = _pos_inlined_seek_at_734_18279;
    _seek_1__tmp_at737_18281 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_737_18280 = machine(19, _seek_1__tmp_at737_18281);
    DeRef(_pos_inlined_seek_at_734_18279);
    _pos_inlined_seek_at_734_18279 = NOVALUE;
    DeRef(_seek_1__tmp_at737_18281);
    _seek_1__tmp_at737_18281 = NOVALUE;

    /** 		put4(p)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_48mem0_17438)){
        poke4_addr = (unsigned long *)_48mem0_17438;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_48mem0_17438)->dbl);
    }
    if (IS_ATOM_INT(_p_18146)) {
        *poke4_addr = (unsigned long)_p_18146;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_p_18146)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at752_18283);
    _1 = (int)SEQ_PTR(_48memseq_17673);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at752_18283 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_48current_db_17396, _put4_1__tmp_at752_18283); // DJP 

    /** end procedure*/
    goto L11; // [774] 777
L11: 
    DeRefi(_put4_1__tmp_at752_18283);
    _put4_1__tmp_at752_18283 = NOVALUE;

    /** 		put4(psize+size)*/
    if (IS_ATOM_INT(_psize_18147) && IS_ATOM_INT(_size_18149)) {
        _10301 = _psize_18147 + _size_18149;
        if ((long)((unsigned long)_10301 + (unsigned long)HIGH_BITS) >= 0) 
        _10301 = NewDouble((double)_10301);
    }
    else {
        if (IS_ATOM_INT(_psize_18147)) {
            _10301 = NewDouble((double)_psize_18147 + DBL_PTR(_size_18149)->dbl);
        }
        else {
            if (IS_ATOM_INT(_size_18149)) {
                _10301 = NewDouble(DBL_PTR(_psize_18147)->dbl + (double)_size_18149);
            }
            else
            _10301 = NewDouble(DBL_PTR(_psize_18147)->dbl + DBL_PTR(_size_18149)->dbl);
        }
    }
    DeRef(_x_inlined_put4_at_786_18286);
    _x_inlined_put4_at_786_18286 = _10301;
    _10301 = NOVALUE;

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_48mem0_17438)){
        poke4_addr = (unsigned long *)_48mem0_17438;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_48mem0_17438)->dbl);
    }
    if (IS_ATOM_INT(_x_inlined_put4_at_786_18286)) {
        *poke4_addr = (unsigned long)_x_inlined_put4_at_786_18286;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_x_inlined_put4_at_786_18286)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at789_18287);
    _1 = (int)SEQ_PTR(_48memseq_17673);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at789_18287 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_48current_db_17396, _put4_1__tmp_at789_18287); // DJP 

    /** end procedure*/
    goto L12; // [811] 814
L12: 
    DeRef(_x_inlined_put4_at_786_18286);
    _x_inlined_put4_at_786_18286 = NOVALUE;
    DeRefi(_put4_1__tmp_at789_18287);
    _put4_1__tmp_at789_18287 = NOVALUE;
    goto LE; // [816] 1028
L10: 

    /** 		io:seek(current_db, free_list+(i-1)*8)*/
    if (IS_ATOM_INT(_i_18148)) {
        _10302 = _i_18148 - 1;
        if ((long)((unsigned long)_10302 +(unsigned long) HIGH_BITS) >= 0){
            _10302 = NewDouble((double)_10302);
        }
    }
    else {
        _10302 = NewDouble(DBL_PTR(_i_18148)->dbl - (double)1);
    }
    if (IS_ATOM_INT(_10302)) {
        if (_10302 == (short)_10302)
        _10303 = _10302 * 8;
        else
        _10303 = NewDouble(_10302 * (double)8);
    }
    else {
        _10303 = NewDouble(DBL_PTR(_10302)->dbl * (double)8);
    }
    DeRef(_10302);
    _10302 = NOVALUE;
    if (IS_ATOM_INT(_free_list_18151) && IS_ATOM_INT(_10303)) {
        _10304 = _free_list_18151 + _10303;
        if ((long)((unsigned long)_10304 + (unsigned long)HIGH_BITS) >= 0) 
        _10304 = NewDouble((double)_10304);
    }
    else {
        if (IS_ATOM_INT(_free_list_18151)) {
            _10304 = NewDouble((double)_free_list_18151 + DBL_PTR(_10303)->dbl);
        }
        else {
            if (IS_ATOM_INT(_10303)) {
                _10304 = NewDouble(DBL_PTR(_free_list_18151)->dbl + (double)_10303);
            }
            else
            _10304 = NewDouble(DBL_PTR(_free_list_18151)->dbl + DBL_PTR(_10303)->dbl);
        }
    }
    DeRef(_10303);
    _10303 = NOVALUE;
    DeRef(_pos_inlined_seek_at_834_18293);
    _pos_inlined_seek_at_834_18293 = _10304;
    _10304 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_834_18293);
    DeRef(_seek_1__tmp_at837_18295);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _48current_db_17396;
    ((int *)_2)[2] = _pos_inlined_seek_at_834_18293;
    _seek_1__tmp_at837_18295 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_837_18294 = machine(19, _seek_1__tmp_at837_18295);
    DeRef(_pos_inlined_seek_at_834_18293);
    _pos_inlined_seek_at_834_18293 = NOVALUE;
    DeRef(_seek_1__tmp_at837_18295);
    _seek_1__tmp_at837_18295 = NOVALUE;

    /** 		remaining = io:get_bytes(current_db, (free_count-i+1)*8)*/
    if (IS_ATOM_INT(_i_18148)) {
        _10305 = _free_count_18157 - _i_18148;
        if ((long)((unsigned long)_10305 +(unsigned long) HIGH_BITS) >= 0){
            _10305 = NewDouble((double)_10305);
        }
    }
    else {
        _10305 = NewDouble((double)_free_count_18157 - DBL_PTR(_i_18148)->dbl);
    }
    if (IS_ATOM_INT(_10305)) {
        _10306 = _10305 + 1;
        if (_10306 > MAXINT){
            _10306 = NewDouble((double)_10306);
        }
    }
    else
    _10306 = binary_op(PLUS, 1, _10305);
    DeRef(_10305);
    _10305 = NOVALUE;
    if (IS_ATOM_INT(_10306)) {
        if (_10306 == (short)_10306)
        _10307 = _10306 * 8;
        else
        _10307 = NewDouble(_10306 * (double)8);
    }
    else {
        _10307 = NewDouble(DBL_PTR(_10306)->dbl * (double)8);
    }
    DeRef(_10306);
    _10306 = NOVALUE;
    _0 = _remaining_18158;
    _remaining_18158 = _18get_bytes(_48current_db_17396, _10307);
    DeRef(_0);
    _10307 = NOVALUE;

    /** 		free_count += 1*/
    _free_count_18157 = _free_count_18157 + 1;

    /** 		io:seek(current_db, FREE_COUNT)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at883_18303);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _48current_db_17396;
    ((int *)_2)[2] = 7;
    _seek_1__tmp_at883_18303 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_883_18302 = machine(19, _seek_1__tmp_at883_18303);
    DeRefi(_seek_1__tmp_at883_18303);
    _seek_1__tmp_at883_18303 = NOVALUE;

    /** 		put4(free_count)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_48mem0_17438)){
        poke4_addr = (unsigned long *)_48mem0_17438;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_48mem0_17438)->dbl);
    }
    *poke4_addr = (unsigned long)_free_count_18157;

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at898_18305);
    _1 = (int)SEQ_PTR(_48memseq_17673);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at898_18305 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_48current_db_17396, _put4_1__tmp_at898_18305); // DJP 

    /** end procedure*/
    goto L13; // [920] 923
L13: 
    DeRefi(_put4_1__tmp_at898_18305);
    _put4_1__tmp_at898_18305 = NOVALUE;

    /** 		io:seek(current_db, free_list+(i-1)*8)*/
    if (IS_ATOM_INT(_i_18148)) {
        _10310 = _i_18148 - 1;
        if ((long)((unsigned long)_10310 +(unsigned long) HIGH_BITS) >= 0){
            _10310 = NewDouble((double)_10310);
        }
    }
    else {
        _10310 = NewDouble(DBL_PTR(_i_18148)->dbl - (double)1);
    }
    if (IS_ATOM_INT(_10310)) {
        if (_10310 == (short)_10310)
        _10311 = _10310 * 8;
        else
        _10311 = NewDouble(_10310 * (double)8);
    }
    else {
        _10311 = NewDouble(DBL_PTR(_10310)->dbl * (double)8);
    }
    DeRef(_10310);
    _10310 = NOVALUE;
    if (IS_ATOM_INT(_free_list_18151) && IS_ATOM_INT(_10311)) {
        _10312 = _free_list_18151 + _10311;
        if ((long)((unsigned long)_10312 + (unsigned long)HIGH_BITS) >= 0) 
        _10312 = NewDouble((double)_10312);
    }
    else {
        if (IS_ATOM_INT(_free_list_18151)) {
            _10312 = NewDouble((double)_free_list_18151 + DBL_PTR(_10311)->dbl);
        }
        else {
            if (IS_ATOM_INT(_10311)) {
                _10312 = NewDouble(DBL_PTR(_free_list_18151)->dbl + (double)_10311);
            }
            else
            _10312 = NewDouble(DBL_PTR(_free_list_18151)->dbl + DBL_PTR(_10311)->dbl);
        }
    }
    DeRef(_10311);
    _10311 = NOVALUE;
    DeRef(_pos_inlined_seek_at_940_18310);
    _pos_inlined_seek_at_940_18310 = _10312;
    _10312 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_940_18310);
    DeRef(_seek_1__tmp_at943_18312);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _48current_db_17396;
    ((int *)_2)[2] = _pos_inlined_seek_at_940_18310;
    _seek_1__tmp_at943_18312 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_943_18311 = machine(19, _seek_1__tmp_at943_18312);
    DeRef(_pos_inlined_seek_at_940_18310);
    _pos_inlined_seek_at_940_18310 = NOVALUE;
    DeRef(_seek_1__tmp_at943_18312);
    _seek_1__tmp_at943_18312 = NOVALUE;

    /** 		put4(p)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_48mem0_17438)){
        poke4_addr = (unsigned long *)_48mem0_17438;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_48mem0_17438)->dbl);
    }
    if (IS_ATOM_INT(_p_18146)) {
        *poke4_addr = (unsigned long)_p_18146;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_p_18146)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at958_18314);
    _1 = (int)SEQ_PTR(_48memseq_17673);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at958_18314 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_48current_db_17396, _put4_1__tmp_at958_18314); // DJP 

    /** end procedure*/
    goto L14; // [980] 983
L14: 
    DeRefi(_put4_1__tmp_at958_18314);
    _put4_1__tmp_at958_18314 = NOVALUE;

    /** 		put4(psize)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_48mem0_17438)){
        poke4_addr = (unsigned long *)_48mem0_17438;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_48mem0_17438)->dbl);
    }
    if (IS_ATOM_INT(_psize_18147)) {
        *poke4_addr = (unsigned long)_psize_18147;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_psize_18147)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at986_18316);
    _1 = (int)SEQ_PTR(_48memseq_17673);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at986_18316 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_48current_db_17396, _put4_1__tmp_at986_18316); // DJP 

    /** end procedure*/
    goto L15; // [1008] 1011
L15: 
    DeRefi(_put4_1__tmp_at986_18316);
    _put4_1__tmp_at986_18316 = NOVALUE;

    /** 		putn(remaining)*/

    /** 	puts(current_db, s)*/
    EPuts(_48current_db_17396, _remaining_18158); // DJP 

    /** end procedure*/
    goto L16; // [1024] 1027
L16: 
LE: 

    /** 	if new_space then*/
    if (_new_space_18153 == 0) {
        goto L17; // [1032] 1043
    }
    else {
        if (!IS_ATOM_INT(_new_space_18153) && DBL_PTR(_new_space_18153)->dbl == 0.0){
            goto L17; // [1032] 1043
        }
    }

    /** 		db_free(to_be_freed) -- free the old space*/
    Ref(_to_be_freed_18154);
    _48db_free(_to_be_freed_18154);
L17: 

    /** end procedure*/
    DeRef(_p_18146);
    DeRef(_psize_18147);
    DeRef(_i_18148);
    DeRef(_size_18149);
    DeRef(_addr_18150);
    DeRef(_free_list_18151);
    DeRef(_free_list_space_18152);
    DeRef(_new_space_18153);
    DeRef(_to_be_freed_18154);
    DeRef(_prev_addr_18155);
    DeRef(_prev_size_18156);
    DeRef(_remaining_18158);
    DeRef(_10270);
    _10270 = NOVALUE;
    DeRef(_10278);
    _10278 = NOVALUE;
    DeRef(_10294);
    _10294 = NOVALUE;
    return;
    ;
}


void _48save_keys()
{
    int _k_18321 = NOVALUE;
    int _10319 = NOVALUE;
    int _10315 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if caching_option = 1 then*/

    /** 		if current_table_pos > 0 then*/
    if (binary_op_a(LESSEQ, _48current_table_pos_17397, 0)){
        goto L1; // [13] 81
    }

    /** 			k = eu:find({current_db, current_table_pos}, cache_index)*/
    Ref(_48current_table_pos_17397);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _48current_db_17396;
    ((int *)_2)[2] = _48current_table_pos_17397;
    _10315 = MAKE_SEQ(_1);
    _k_18321 = find_from(_10315, _48cache_index_17405, 1);
    DeRefDS(_10315);
    _10315 = NOVALUE;

    /** 			if k != 0 then*/
    if (_k_18321 == 0)
    goto L2; // [36] 53

    /** 				key_cache[k] = key_pointers*/
    RefDS(_48key_pointers_17403);
    _2 = (int)SEQ_PTR(_48key_cache_17404);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _48key_cache_17404 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _k_18321);
    _1 = *(int *)_2;
    *(int *)_2 = _48key_pointers_17403;
    DeRef(_1);
    goto L3; // [50] 80
L2: 

    /** 				key_cache = append(key_cache, key_pointers)*/
    RefDS(_48key_pointers_17403);
    Append(&_48key_cache_17404, _48key_cache_17404, _48key_pointers_17403);

    /** 				cache_index = append(cache_index, {current_db, current_table_pos})*/
    Ref(_48current_table_pos_17397);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _48current_db_17396;
    ((int *)_2)[2] = _48current_table_pos_17397;
    _10319 = MAKE_SEQ(_1);
    RefDS(_10319);
    Append(&_48cache_index_17405, _48cache_index_17405, _10319);
    DeRefDS(_10319);
    _10319 = NOVALUE;
L3: 
L1: 

    /** end procedure*/
    return;
    ;
}


int _48db_create(int _path_18418, int _lock_method_18419, int _init_tables_18420, int _init_free_18421)
{
    int _db_18422 = NOVALUE;
    int _lock_file_1__tmp_at222_18463 = NOVALUE;
    int _lock_file_inlined_lock_file_at_222_18462 = NOVALUE;
    int _put4_1__tmp_at342_18472 = NOVALUE;
    int _put4_1__tmp_at370_18474 = NOVALUE;
    int _put4_1__tmp_at413_18480 = NOVALUE;
    int _x_inlined_put4_at_410_18479 = NOVALUE;
    int _put4_1__tmp_at452_18485 = NOVALUE;
    int _x_inlined_put4_at_449_18484 = NOVALUE;
    int _put4_1__tmp_at480_18487 = NOVALUE;
    int _s_inlined_putn_at_516_18491 = NOVALUE;
    int _put4_1__tmp_at548_18496 = NOVALUE;
    int _x_inlined_put4_at_545_18495 = NOVALUE;
    int _s_inlined_putn_at_584_18500 = NOVALUE;
    int _10419 = NOVALUE;
    int _10418 = NOVALUE;
    int _10417 = NOVALUE;
    int _10416 = NOVALUE;
    int _10415 = NOVALUE;
    int _10414 = NOVALUE;
    int _10413 = NOVALUE;
    int _10412 = NOVALUE;
    int _10411 = NOVALUE;
    int _10410 = NOVALUE;
    int _10409 = NOVALUE;
    int _10390 = NOVALUE;
    int _10388 = NOVALUE;
    int _10387 = NOVALUE;
    int _10385 = NOVALUE;
    int _10384 = NOVALUE;
    int _10382 = NOVALUE;
    int _10381 = NOVALUE;
    int _10379 = NOVALUE;
    int _0, _1, _2;
    

    /** 	db = find(path, Known_Aliases)*/
    _db_18422 = find_from(_path_18418, _48Known_Aliases_17417, 1);

    /** 	if db then*/
    if (_db_18422 == 0)
    {
        goto L1; // [20] 94
    }
    else{
    }

    /** 		path = Alias_Details[db][1]*/
    _2 = (int)SEQ_PTR(_48Alias_Details_17418);
    _10379 = (int)*(((s1_ptr)_2)->base + _db_18422);
    DeRefDS(_path_18418);
    _2 = (int)SEQ_PTR(_10379);
    _path_18418 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_path_18418);
    _10379 = NOVALUE;

    /** 		lock_method = Alias_Details[db][2][CONNECT_LOCK]*/
    _2 = (int)SEQ_PTR(_48Alias_Details_17418);
    _10381 = (int)*(((s1_ptr)_2)->base + _db_18422);
    _2 = (int)SEQ_PTR(_10381);
    _10382 = (int)*(((s1_ptr)_2)->base + 2);
    _10381 = NOVALUE;
    _2 = (int)SEQ_PTR(_10382);
    _lock_method_18419 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_lock_method_18419)){
        _lock_method_18419 = (long)DBL_PTR(_lock_method_18419)->dbl;
    }
    _10382 = NOVALUE;

    /** 		init_tables = Alias_Details[db][2][CONNECT_TABLES]*/
    _2 = (int)SEQ_PTR(_48Alias_Details_17418);
    _10384 = (int)*(((s1_ptr)_2)->base + _db_18422);
    _2 = (int)SEQ_PTR(_10384);
    _10385 = (int)*(((s1_ptr)_2)->base + 2);
    _10384 = NOVALUE;
    _2 = (int)SEQ_PTR(_10385);
    _init_tables_18420 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_init_tables_18420)){
        _init_tables_18420 = (long)DBL_PTR(_init_tables_18420)->dbl;
    }
    _10385 = NOVALUE;

    /** 		init_free = Alias_Details[db][2][CONNECT_FREE]*/
    _2 = (int)SEQ_PTR(_48Alias_Details_17418);
    _10387 = (int)*(((s1_ptr)_2)->base + _db_18422);
    _2 = (int)SEQ_PTR(_10387);
    _10388 = (int)*(((s1_ptr)_2)->base + 2);
    _10387 = NOVALUE;
    _2 = (int)SEQ_PTR(_10388);
    _init_free_18421 = (int)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_init_free_18421)){
        _init_free_18421 = (long)DBL_PTR(_init_free_18421)->dbl;
    }
    _10388 = NOVALUE;
    goto L2; // [91] 134
L1: 

    /** 		path = filesys:canonical_path( defaultext(path, "edb") )*/
    RefDS(_path_18418);
    RefDS(_10373);
    _10390 = _15defaultext(_path_18418, _10373);
    _0 = _path_18418;
    _path_18418 = _15canonical_path(_10390, 0, 0);
    DeRefDS(_0);
    _10390 = NOVALUE;

    /** 		if init_tables < 1 then*/
    if (_init_tables_18420 >= 1)
    goto L3; // [111] 121

    /** 			init_tables = 1*/
    _init_tables_18420 = 1;
L3: 

    /** 		if init_free < 0 then*/
    if (_init_free_18421 >= 0)
    goto L4; // [123] 133

    /** 			init_free = 0*/
    _init_free_18421 = 0;
L4: 
L2: 

    /** 	db = open(path, "rb")*/
    _db_18422 = EOpen(_path_18418, _10394, 0);

    /** 	if db != -1 then*/
    if (_db_18422 == -1)
    goto L5; // [143] 158

    /** 		close(db)*/
    EClose(_db_18422);

    /** 		return DB_EXISTS_ALREADY*/
    DeRefDS(_path_18418);
    return -2;
L5: 

    /** 	db = open(path, "wb")*/
    _db_18422 = EOpen(_path_18418, _10397, 0);

    /** 	if db = -1 then*/
    if (_db_18422 != -1)
    goto L6; // [167] 178

    /** 		return DB_OPEN_FAIL*/
    DeRefDS(_path_18418);
    return -1;
L6: 

    /** 	close(db)*/
    EClose(_db_18422);

    /** 	db = open(path, "ub")*/
    _db_18422 = EOpen(_path_18418, _10400, 0);

    /** 	if db = -1 then*/
    if (_db_18422 != -1)
    goto L7; // [191] 202

    /** 		return DB_OPEN_FAIL*/
    DeRefDS(_path_18418);
    return -1;
L7: 

    /** 	if lock_method = DB_LOCK_SHARED then*/
    if (_lock_method_18419 != 1)
    goto L8; // [204] 214

    /** 		lock_method = DB_LOCK_NO*/
    _lock_method_18419 = 0;
L8: 

    /** 	if lock_method = DB_LOCK_EXCLUSIVE then*/
    if (_lock_method_18419 != 2)
    goto L9; // [216] 248

    /** 		if not io:lock_file(db, io:LOCK_EXCLUSIVE, {}) then*/

    /** 	return machine_func(M_LOCK_FILE, {fn, t, r})*/
    _0 = _lock_file_1__tmp_at222_18463;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _db_18422;
    *((int *)(_2+8)) = 2;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    _lock_file_1__tmp_at222_18463 = MAKE_SEQ(_1);
    DeRef(_0);
    _lock_file_inlined_lock_file_at_222_18462 = machine(61, _lock_file_1__tmp_at222_18463);
    DeRef(_lock_file_1__tmp_at222_18463);
    _lock_file_1__tmp_at222_18463 = NOVALUE;
    if (_lock_file_inlined_lock_file_at_222_18462 != 0)
    goto LA; // [237] 247

    /** 			return DB_LOCK_FAIL*/
    DeRefDS(_path_18418);
    return -3;
LA: 
L9: 

    /** 	save_keys()*/
    _48save_keys();

    /** 	current_db = db*/
    _48current_db_17396 = _db_18422;

    /** 	current_lock = lock_method*/
    _48current_lock_17402 = _lock_method_18419;

    /** 	current_table_pos = -1*/
    DeRef(_48current_table_pos_17397);
    _48current_table_pos_17397 = -1;

    /** 	current_table_name = ""*/
    RefDS(_5);
    DeRef(_48current_table_name_17398);
    _48current_table_name_17398 = _5;

    /** 	db_names = append(db_names, path)*/
    RefDS(_path_18418);
    Append(&_48db_names_17399, _48db_names_17399, _path_18418);

    /** 	db_lock_methods = append(db_lock_methods, lock_method)*/
    Append(&_48db_lock_methods_17401, _48db_lock_methods_17401, _lock_method_18419);

    /** 	db_file_nums = append(db_file_nums, db)*/
    Append(&_48db_file_nums_17400, _48db_file_nums_17400, _db_18422);

    /** 	put1(DB_MAGIC) -- so we know what type of file it is*/

    /** 	puts(current_db, x)*/
    EPuts(_48current_db_17396, 77); // DJP 

    /** end procedure*/
    goto LB; // [309] 312
LB: 

    /** 	put1(DB_MAJOR) -- major version*/

    /** 	puts(current_db, x)*/
    EPuts(_48current_db_17396, 4); // DJP 

    /** end procedure*/
    goto LC; // [323] 326
LC: 

    /** 	put1(DB_MINOR) -- minor version*/

    /** 	puts(current_db, x)*/
    EPuts(_48current_db_17396, 0); // DJP 

    /** end procedure*/
    goto LD; // [337] 340
LD: 

    /** 	put4(19)  -- pointer to tables*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_48mem0_17438)){
        poke4_addr = (unsigned long *)_48mem0_17438;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_48mem0_17438)->dbl);
    }
    *poke4_addr = (unsigned long)19;

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at342_18472);
    _1 = (int)SEQ_PTR(_48memseq_17673);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at342_18472 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_48current_db_17396, _put4_1__tmp_at342_18472); // DJP 

    /** end procedure*/
    goto LE; // [363] 366
LE: 
    DeRefi(_put4_1__tmp_at342_18472);
    _put4_1__tmp_at342_18472 = NOVALUE;

    /** 	put4(0)   -- number of free blocks*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_48mem0_17438)){
        poke4_addr = (unsigned long *)_48mem0_17438;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_48mem0_17438)->dbl);
    }
    *poke4_addr = (unsigned long)0;

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at370_18474);
    _1 = (int)SEQ_PTR(_48memseq_17673);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at370_18474 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_48current_db_17396, _put4_1__tmp_at370_18474); // DJP 

    /** end procedure*/
    goto LF; // [391] 394
LF: 
    DeRefi(_put4_1__tmp_at370_18474);
    _put4_1__tmp_at370_18474 = NOVALUE;

    /** 	put4(23 + init_tables * SIZEOF_TABLE_HEADER + 4)   -- pointer to free list*/
    if (_init_tables_18420 == (short)_init_tables_18420)
    _10409 = _init_tables_18420 * 16;
    else
    _10409 = NewDouble(_init_tables_18420 * (double)16);
    if (IS_ATOM_INT(_10409)) {
        _10410 = 23 + _10409;
        if ((long)((unsigned long)_10410 + (unsigned long)HIGH_BITS) >= 0) 
        _10410 = NewDouble((double)_10410);
    }
    else {
        _10410 = NewDouble((double)23 + DBL_PTR(_10409)->dbl);
    }
    DeRef(_10409);
    _10409 = NOVALUE;
    if (IS_ATOM_INT(_10410)) {
        _10411 = _10410 + 4;
        if ((long)((unsigned long)_10411 + (unsigned long)HIGH_BITS) >= 0) 
        _10411 = NewDouble((double)_10411);
    }
    else {
        _10411 = NewDouble(DBL_PTR(_10410)->dbl + (double)4);
    }
    DeRef(_10410);
    _10410 = NOVALUE;
    DeRef(_x_inlined_put4_at_410_18479);
    _x_inlined_put4_at_410_18479 = _10411;
    _10411 = NOVALUE;

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_48mem0_17438)){
        poke4_addr = (unsigned long *)_48mem0_17438;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_48mem0_17438)->dbl);
    }
    if (IS_ATOM_INT(_x_inlined_put4_at_410_18479)) {
        *poke4_addr = (unsigned long)_x_inlined_put4_at_410_18479;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_x_inlined_put4_at_410_18479)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at413_18480);
    _1 = (int)SEQ_PTR(_48memseq_17673);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at413_18480 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_48current_db_17396, _put4_1__tmp_at413_18480); // DJP 

    /** end procedure*/
    goto L10; // [434] 437
L10: 
    DeRef(_x_inlined_put4_at_410_18479);
    _x_inlined_put4_at_410_18479 = NOVALUE;
    DeRefi(_put4_1__tmp_at413_18480);
    _put4_1__tmp_at413_18480 = NOVALUE;

    /** 	put4( 8 + init_tables * SIZEOF_TABLE_HEADER)  -- allocated size*/
    if (_init_tables_18420 == (short)_init_tables_18420)
    _10412 = _init_tables_18420 * 16;
    else
    _10412 = NewDouble(_init_tables_18420 * (double)16);
    if (IS_ATOM_INT(_10412)) {
        _10413 = 8 + _10412;
        if ((long)((unsigned long)_10413 + (unsigned long)HIGH_BITS) >= 0) 
        _10413 = NewDouble((double)_10413);
    }
    else {
        _10413 = NewDouble((double)8 + DBL_PTR(_10412)->dbl);
    }
    DeRef(_10412);
    _10412 = NOVALUE;
    DeRef(_x_inlined_put4_at_449_18484);
    _x_inlined_put4_at_449_18484 = _10413;
    _10413 = NOVALUE;

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_48mem0_17438)){
        poke4_addr = (unsigned long *)_48mem0_17438;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_48mem0_17438)->dbl);
    }
    if (IS_ATOM_INT(_x_inlined_put4_at_449_18484)) {
        *poke4_addr = (unsigned long)_x_inlined_put4_at_449_18484;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_x_inlined_put4_at_449_18484)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at452_18485);
    _1 = (int)SEQ_PTR(_48memseq_17673);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at452_18485 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_48current_db_17396, _put4_1__tmp_at452_18485); // DJP 

    /** end procedure*/
    goto L11; // [473] 476
L11: 
    DeRef(_x_inlined_put4_at_449_18484);
    _x_inlined_put4_at_449_18484 = NOVALUE;
    DeRefi(_put4_1__tmp_at452_18485);
    _put4_1__tmp_at452_18485 = NOVALUE;

    /** 	put4(0)   -- number of tables that currently exist*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_48mem0_17438)){
        poke4_addr = (unsigned long *)_48mem0_17438;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_48mem0_17438)->dbl);
    }
    *poke4_addr = (unsigned long)0;

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at480_18487);
    _1 = (int)SEQ_PTR(_48memseq_17673);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at480_18487 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_48current_db_17396, _put4_1__tmp_at480_18487); // DJP 

    /** end procedure*/
    goto L12; // [501] 504
L12: 
    DeRefi(_put4_1__tmp_at480_18487);
    _put4_1__tmp_at480_18487 = NOVALUE;

    /** 	putn(repeat(0, init_tables * SIZEOF_TABLE_HEADER))*/
    _10414 = _init_tables_18420 * 16;
    _10415 = Repeat(0, _10414);
    _10414 = NOVALUE;
    DeRefi(_s_inlined_putn_at_516_18491);
    _s_inlined_putn_at_516_18491 = _10415;
    _10415 = NOVALUE;

    /** 	puts(current_db, s)*/
    EPuts(_48current_db_17396, _s_inlined_putn_at_516_18491); // DJP 

    /** end procedure*/
    goto L13; // [530] 533
L13: 
    DeRefi(_s_inlined_putn_at_516_18491);
    _s_inlined_putn_at_516_18491 = NOVALUE;

    /** 	put4(4+init_free*8)   -- allocated size*/
    if (_init_free_18421 == (short)_init_free_18421)
    _10416 = _init_free_18421 * 8;
    else
    _10416 = NewDouble(_init_free_18421 * (double)8);
    if (IS_ATOM_INT(_10416)) {
        _10417 = 4 + _10416;
        if ((long)((unsigned long)_10417 + (unsigned long)HIGH_BITS) >= 0) 
        _10417 = NewDouble((double)_10417);
    }
    else {
        _10417 = NewDouble((double)4 + DBL_PTR(_10416)->dbl);
    }
    DeRef(_10416);
    _10416 = NOVALUE;
    DeRef(_x_inlined_put4_at_545_18495);
    _x_inlined_put4_at_545_18495 = _10417;
    _10417 = NOVALUE;

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_48mem0_17438)){
        poke4_addr = (unsigned long *)_48mem0_17438;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_48mem0_17438)->dbl);
    }
    if (IS_ATOM_INT(_x_inlined_put4_at_545_18495)) {
        *poke4_addr = (unsigned long)_x_inlined_put4_at_545_18495;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_x_inlined_put4_at_545_18495)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at548_18496);
    _1 = (int)SEQ_PTR(_48memseq_17673);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at548_18496 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_48current_db_17396, _put4_1__tmp_at548_18496); // DJP 

    /** end procedure*/
    goto L14; // [569] 572
L14: 
    DeRef(_x_inlined_put4_at_545_18495);
    _x_inlined_put4_at_545_18495 = NOVALUE;
    DeRefi(_put4_1__tmp_at548_18496);
    _put4_1__tmp_at548_18496 = NOVALUE;

    /** 	putn(repeat(0, init_free * 8))*/
    _10418 = _init_free_18421 * 8;
    _10419 = Repeat(0, _10418);
    _10418 = NOVALUE;
    DeRefi(_s_inlined_putn_at_584_18500);
    _s_inlined_putn_at_584_18500 = _10419;
    _10419 = NOVALUE;

    /** 	puts(current_db, s)*/
    EPuts(_48current_db_17396, _s_inlined_putn_at_584_18500); // DJP 

    /** end procedure*/
    goto L15; // [598] 601
L15: 
    DeRefi(_s_inlined_putn_at_584_18500);
    _s_inlined_putn_at_584_18500 = NOVALUE;

    /** 	return DB_OK*/
    DeRefDS(_path_18418);
    return 0;
    ;
}


int _48db_open(int _path_18503, int _lock_method_18504)
{
    int _db_18505 = NOVALUE;
    int _magic_18506 = NOVALUE;
    int _lock_file_1__tmp_at141_18533 = NOVALUE;
    int _lock_file_inlined_lock_file_at_141_18532 = NOVALUE;
    int _lock_file_1__tmp_at181_18540 = NOVALUE;
    int _lock_file_inlined_lock_file_at_181_18539 = NOVALUE;
    int _10430 = NOVALUE;
    int _10428 = NOVALUE;
    int _10426 = NOVALUE;
    int _10424 = NOVALUE;
    int _10423 = NOVALUE;
    int _10421 = NOVALUE;
    int _0, _1, _2;
    

    /** 	db = find(path, Known_Aliases)*/
    _db_18505 = find_from(_path_18503, _48Known_Aliases_17417, 1);

    /** 	if db then*/
    if (_db_18505 == 0)
    {
        goto L1; // [16] 54
    }
    else{
    }

    /** 		path = Alias_Details[db][1]*/
    _2 = (int)SEQ_PTR(_48Alias_Details_17418);
    _10421 = (int)*(((s1_ptr)_2)->base + _db_18505);
    DeRefDS(_path_18503);
    _2 = (int)SEQ_PTR(_10421);
    _path_18503 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_path_18503);
    _10421 = NOVALUE;

    /** 		lock_method = Alias_Details[db][2][CONNECT_LOCK]*/
    _2 = (int)SEQ_PTR(_48Alias_Details_17418);
    _10423 = (int)*(((s1_ptr)_2)->base + _db_18505);
    _2 = (int)SEQ_PTR(_10423);
    _10424 = (int)*(((s1_ptr)_2)->base + 2);
    _10423 = NOVALUE;
    _2 = (int)SEQ_PTR(_10424);
    _lock_method_18504 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_lock_method_18504)){
        _lock_method_18504 = (long)DBL_PTR(_lock_method_18504)->dbl;
    }
    _10424 = NOVALUE;
    goto L2; // [51] 70
L1: 

    /** 		path = filesys:canonical_path( filesys:defaultext(path, "edb") )*/
    RefDS(_path_18503);
    RefDS(_10373);
    _10426 = _15defaultext(_path_18503, _10373);
    _0 = _path_18503;
    _path_18503 = _15canonical_path(_10426, 0, 0);
    DeRefDS(_0);
    _10426 = NOVALUE;
L2: 

    /** 	if lock_method = DB_LOCK_NO or*/
    _10428 = (_lock_method_18504 == 0);
    if (_10428 != 0) {
        goto L3; // [76] 89
    }
    _10430 = (_lock_method_18504 == 2);
    if (_10430 == 0)
    {
        DeRef(_10430);
        _10430 = NOVALUE;
        goto L4; // [85] 99
    }
    else{
        DeRef(_10430);
        _10430 = NOVALUE;
    }
L3: 

    /** 		db = open(path, "ub")*/
    _db_18505 = EOpen(_path_18503, _10400, 0);
    goto L5; // [96] 107
L4: 

    /** 		db = open(path, "rb")*/
    _db_18505 = EOpen(_path_18503, _10394, 0);
L5: 

    /** ifdef WINDOWS then*/

    /** 	if lock_method = DB_LOCK_SHARED then*/
    if (_lock_method_18504 != 1)
    goto L6; // [111] 121

    /** 		lock_method = DB_LOCK_EXCLUSIVE*/
    _lock_method_18504 = 2;
L6: 

    /** 	if db = -1 then*/
    if (_db_18505 != -1)
    goto L7; // [123] 134

    /** 		return DB_OPEN_FAIL*/
    DeRefDS(_path_18503);
    DeRef(_10428);
    _10428 = NOVALUE;
    return -1;
L7: 

    /** 	if lock_method = DB_LOCK_EXCLUSIVE then*/
    if (_lock_method_18504 != 2)
    goto L8; // [136] 174

    /** 		if not io:lock_file(db, io:LOCK_EXCLUSIVE, {}) then*/

    /** 	return machine_func(M_LOCK_FILE, {fn, t, r})*/
    _0 = _lock_file_1__tmp_at141_18533;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _db_18505;
    *((int *)(_2+8)) = 2;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    _lock_file_1__tmp_at141_18533 = MAKE_SEQ(_1);
    DeRef(_0);
    _lock_file_inlined_lock_file_at_141_18532 = machine(61, _lock_file_1__tmp_at141_18533);
    DeRef(_lock_file_1__tmp_at141_18533);
    _lock_file_1__tmp_at141_18533 = NOVALUE;
    if (_lock_file_inlined_lock_file_at_141_18532 != 0)
    goto L9; // [157] 213

    /** 			close(db)*/
    EClose(_db_18505);

    /** 			return DB_LOCK_FAIL*/
    DeRefDS(_path_18503);
    DeRef(_10428);
    _10428 = NOVALUE;
    return -3;
    goto L9; // [171] 213
L8: 

    /** 	elsif lock_method = DB_LOCK_SHARED then*/
    if (_lock_method_18504 != 1)
    goto LA; // [176] 212

    /** 		if not io:lock_file(db, io:LOCK_SHARED, {}) then*/

    /** 	return machine_func(M_LOCK_FILE, {fn, t, r})*/
    _0 = _lock_file_1__tmp_at181_18540;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _db_18505;
    *((int *)(_2+8)) = 1;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    _lock_file_1__tmp_at181_18540 = MAKE_SEQ(_1);
    DeRef(_0);
    _lock_file_inlined_lock_file_at_181_18539 = machine(61, _lock_file_1__tmp_at181_18540);
    DeRef(_lock_file_1__tmp_at181_18540);
    _lock_file_1__tmp_at181_18540 = NOVALUE;
    if (_lock_file_inlined_lock_file_at_181_18539 != 0)
    goto LB; // [197] 211

    /** 			close(db)*/
    EClose(_db_18505);

    /** 			return DB_LOCK_FAIL*/
    DeRefDS(_path_18503);
    DeRef(_10428);
    _10428 = NOVALUE;
    return -3;
LB: 
LA: 
L9: 

    /** 	magic = getc(db)*/
    if (_db_18505 != last_r_file_no) {
        last_r_file_ptr = which_file(_db_18505, EF_READ);
        last_r_file_no = _db_18505;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _magic_18506 = getKBchar();
        }
        else
        _magic_18506 = getc(last_r_file_ptr);
    }
    else
    _magic_18506 = getc(last_r_file_ptr);

    /** 	if magic != DB_MAGIC then*/
    if (_magic_18506 == 77)
    goto LC; // [220] 235

    /** 		close(db)*/
    EClose(_db_18505);

    /** 		return DB_OPEN_FAIL*/
    DeRefDS(_path_18503);
    DeRef(_10428);
    _10428 = NOVALUE;
    return -1;
LC: 

    /** 	save_keys()*/
    _48save_keys();

    /** 	current_db = db */
    _48current_db_17396 = _db_18505;

    /** 	current_table_pos = -1*/
    DeRef(_48current_table_pos_17397);
    _48current_table_pos_17397 = -1;

    /** 	current_table_name = ""*/
    RefDS(_5);
    DeRef(_48current_table_name_17398);
    _48current_table_name_17398 = _5;

    /** 	current_lock = lock_method*/
    _48current_lock_17402 = _lock_method_18504;

    /** 	db_names = append(db_names, path)*/
    RefDS(_path_18503);
    Append(&_48db_names_17399, _48db_names_17399, _path_18503);

    /** 	db_lock_methods = append(db_lock_methods, lock_method)*/
    Append(&_48db_lock_methods_17401, _48db_lock_methods_17401, _lock_method_18504);

    /** 	db_file_nums = append(db_file_nums, db)*/
    Append(&_48db_file_nums_17400, _48db_file_nums_17400, _db_18505);

    /** 	return DB_OK*/
    DeRefDS(_path_18503);
    DeRef(_10428);
    _10428 = NOVALUE;
    return 0;
    ;
}


int _48db_select(int _path_18550, int _lock_method_18551)
{
    int _index_18552 = NOVALUE;
    int _10450 = NOVALUE;
    int _10448 = NOVALUE;
    int _10447 = NOVALUE;
    int _10445 = NOVALUE;
    int _0, _1, _2;
    

    /** 	index = find(path, Known_Aliases)*/
    _index_18552 = find_from(_path_18550, _48Known_Aliases_17417, 1);

    /** 	if index then*/
    if (_index_18552 == 0)
    {
        goto L1; // [16] 54
    }
    else{
    }

    /** 		path = Alias_Details[index][1]*/
    _2 = (int)SEQ_PTR(_48Alias_Details_17418);
    _10445 = (int)*(((s1_ptr)_2)->base + _index_18552);
    DeRefDS(_path_18550);
    _2 = (int)SEQ_PTR(_10445);
    _path_18550 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_path_18550);
    _10445 = NOVALUE;

    /** 		lock_method = Alias_Details[index][2][CONNECT_LOCK]*/
    _2 = (int)SEQ_PTR(_48Alias_Details_17418);
    _10447 = (int)*(((s1_ptr)_2)->base + _index_18552);
    _2 = (int)SEQ_PTR(_10447);
    _10448 = (int)*(((s1_ptr)_2)->base + 2);
    _10447 = NOVALUE;
    _2 = (int)SEQ_PTR(_10448);
    _lock_method_18551 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_lock_method_18551)){
        _lock_method_18551 = (long)DBL_PTR(_lock_method_18551)->dbl;
    }
    _10448 = NOVALUE;
    goto L2; // [51] 70
L1: 

    /** 		path = filesys:canonical_path( filesys:defaultext(path, "edb") )*/
    RefDS(_path_18550);
    RefDS(_10373);
    _10450 = _15defaultext(_path_18550, _10373);
    _0 = _path_18550;
    _path_18550 = _15canonical_path(_10450, 0, 0);
    DeRefDS(_0);
    _10450 = NOVALUE;
L2: 

    /** 	index = eu:find(path, db_names)*/
    _index_18552 = find_from(_path_18550, _48db_names_17399, 1);

    /** 	if index = 0 then*/
    if (_index_18552 != 0)
    goto L3; // [81] 130

    /** 		if lock_method = -1 then*/
    if (_lock_method_18551 != -1)
    goto L4; // [87] 98

    /** 			return DB_OPEN_FAIL*/
    DeRefDS(_path_18550);
    return -1;
L4: 

    /** 		index = db_open(path, lock_method)*/
    RefDS(_path_18550);
    _index_18552 = _48db_open(_path_18550, _lock_method_18551);
    if (!IS_ATOM_INT(_index_18552)) {
        _1 = (long)(DBL_PTR(_index_18552)->dbl);
        DeRefDS(_index_18552);
        _index_18552 = _1;
    }

    /** 		if index != DB_OK then*/
    if (_index_18552 == 0)
    goto L5; // [109] 120

    /** 			return index*/
    DeRefDS(_path_18550);
    return _index_18552;
L5: 

    /** 		index = eu:find(path, db_names)*/
    _index_18552 = find_from(_path_18550, _48db_names_17399, 1);
L3: 

    /** 	save_keys()*/
    _48save_keys();

    /** 	current_db = db_file_nums[index]*/
    _2 = (int)SEQ_PTR(_48db_file_nums_17400);
    _48current_db_17396 = (int)*(((s1_ptr)_2)->base + _index_18552);
    if (!IS_ATOM_INT(_48current_db_17396))
    _48current_db_17396 = (long)DBL_PTR(_48current_db_17396)->dbl;

    /** 	current_lock = db_lock_methods[index]*/
    _2 = (int)SEQ_PTR(_48db_lock_methods_17401);
    _48current_lock_17402 = (int)*(((s1_ptr)_2)->base + _index_18552);
    if (!IS_ATOM_INT(_48current_lock_17402))
    _48current_lock_17402 = (long)DBL_PTR(_48current_lock_17402)->dbl;

    /** 	current_table_pos = -1*/
    DeRef(_48current_table_pos_17397);
    _48current_table_pos_17397 = -1;

    /** 	current_table_name = ""*/
    RefDS(_5);
    DeRef(_48current_table_name_17398);
    _48current_table_name_17398 = _5;

    /** 	key_pointers = {}*/
    RefDS(_5);
    DeRef(_48key_pointers_17403);
    _48key_pointers_17403 = _5;

    /** 	return DB_OK*/
    DeRefDS(_path_18550);
    return 0;
    ;
}


void _48db_close()
{
    int _unlock_file_1__tmp_at25_18581 = NOVALUE;
    int _index_18576 = NOVALUE;
    int _10467 = NOVALUE;
    int _10466 = NOVALUE;
    int _10465 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if current_db = -1 then*/
    if (_48current_db_17396 != -1)
    goto L1; // [5] 15

    /** 		return*/
    return;
L1: 

    /** 	if current_lock then*/
    if (_48current_lock_17402 == 0)
    {
        goto L2; // [19] 43
    }
    else{
    }

    /** 		io:unlock_file(current_db, {})*/

    /** 	machine_proc(M_UNLOCK_FILE, {fn, r})*/
    RefDS(_5);
    DeRef(_unlock_file_1__tmp_at25_18581);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _48current_db_17396;
    ((int *)_2)[2] = _5;
    _unlock_file_1__tmp_at25_18581 = MAKE_SEQ(_1);
    machine(62, _unlock_file_1__tmp_at25_18581);

    /** end procedure*/
    goto L3; // [37] 40
L3: 
    DeRef(_unlock_file_1__tmp_at25_18581);
    _unlock_file_1__tmp_at25_18581 = NOVALUE;
L2: 

    /** 	close(current_db)*/
    EClose(_48current_db_17396);

    /** 	index = eu:find(current_db, db_file_nums)*/
    _index_18576 = find_from(_48current_db_17396, _48db_file_nums_17400, 1);

    /** 	db_names = remove(db_names, index)*/
    {
        s1_ptr assign_space = SEQ_PTR(_48db_names_17399);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_index_18576)) ? _index_18576 : (long)(DBL_PTR(_index_18576)->dbl);
        int stop = (IS_ATOM_INT(_index_18576)) ? _index_18576 : (long)(DBL_PTR(_index_18576)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_48db_names_17399), start, &_48db_names_17399 );
            }
            else Tail(SEQ_PTR(_48db_names_17399), stop+1, &_48db_names_17399);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_48db_names_17399), start, &_48db_names_17399);
        }
        else {
            assign_slice_seq = &assign_space;
            _48db_names_17399 = Remove_elements(start, stop, (SEQ_PTR(_48db_names_17399)->ref == 1));
        }
    }

    /** 	db_file_nums = remove(db_file_nums, index)*/
    {
        s1_ptr assign_space = SEQ_PTR(_48db_file_nums_17400);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_index_18576)) ? _index_18576 : (long)(DBL_PTR(_index_18576)->dbl);
        int stop = (IS_ATOM_INT(_index_18576)) ? _index_18576 : (long)(DBL_PTR(_index_18576)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_48db_file_nums_17400), start, &_48db_file_nums_17400 );
            }
            else Tail(SEQ_PTR(_48db_file_nums_17400), stop+1, &_48db_file_nums_17400);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_48db_file_nums_17400), start, &_48db_file_nums_17400);
        }
        else {
            assign_slice_seq = &assign_space;
            _48db_file_nums_17400 = Remove_elements(start, stop, (SEQ_PTR(_48db_file_nums_17400)->ref == 1));
        }
    }

    /** 	db_lock_methods = remove(db_lock_methods, index)*/
    {
        s1_ptr assign_space = SEQ_PTR(_48db_lock_methods_17401);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_index_18576)) ? _index_18576 : (long)(DBL_PTR(_index_18576)->dbl);
        int stop = (IS_ATOM_INT(_index_18576)) ? _index_18576 : (long)(DBL_PTR(_index_18576)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_48db_lock_methods_17401), start, &_48db_lock_methods_17401 );
            }
            else Tail(SEQ_PTR(_48db_lock_methods_17401), stop+1, &_48db_lock_methods_17401);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_48db_lock_methods_17401), start, &_48db_lock_methods_17401);
        }
        else {
            assign_slice_seq = &assign_space;
            _48db_lock_methods_17401 = Remove_elements(start, stop, (SEQ_PTR(_48db_lock_methods_17401)->ref == 1));
        }
    }

    /** 	for i = length(cache_index) to 1 by -1 do*/
    if (IS_SEQUENCE(_48cache_index_17405)){
            _10465 = SEQ_PTR(_48cache_index_17405)->length;
    }
    else {
        _10465 = 1;
    }
    {
        int _i_18587;
        _i_18587 = _10465;
L4: 
        if (_i_18587 < 1){
            goto L5; // [94] 145
        }

        /** 		if cache_index[i][1] = current_db then*/
        _2 = (int)SEQ_PTR(_48cache_index_17405);
        _10466 = (int)*(((s1_ptr)_2)->base + _i_18587);
        _2 = (int)SEQ_PTR(_10466);
        _10467 = (int)*(((s1_ptr)_2)->base + 1);
        _10466 = NOVALUE;
        if (binary_op_a(NOTEQ, _10467, _48current_db_17396)){
            _10467 = NOVALUE;
            goto L6; // [115] 138
        }
        _10467 = NOVALUE;

        /** 			cache_index = remove(cache_index, i)*/
        {
            s1_ptr assign_space = SEQ_PTR(_48cache_index_17405);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_i_18587)) ? _i_18587 : (long)(DBL_PTR(_i_18587)->dbl);
            int stop = (IS_ATOM_INT(_i_18587)) ? _i_18587 : (long)(DBL_PTR(_i_18587)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<0) {
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_48cache_index_17405), start, &_48cache_index_17405 );
                }
                else Tail(SEQ_PTR(_48cache_index_17405), stop+1, &_48cache_index_17405);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_48cache_index_17405), start, &_48cache_index_17405);
            }
            else {
                assign_slice_seq = &assign_space;
                _48cache_index_17405 = Remove_elements(start, stop, (SEQ_PTR(_48cache_index_17405)->ref == 1));
            }
        }

        /** 			key_cache = remove(key_cache, i)*/
        {
            s1_ptr assign_space = SEQ_PTR(_48key_cache_17404);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_i_18587)) ? _i_18587 : (long)(DBL_PTR(_i_18587)->dbl);
            int stop = (IS_ATOM_INT(_i_18587)) ? _i_18587 : (long)(DBL_PTR(_i_18587)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<0) {
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_48key_cache_17404), start, &_48key_cache_17404 );
                }
                else Tail(SEQ_PTR(_48key_cache_17404), stop+1, &_48key_cache_17404);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_48key_cache_17404), start, &_48key_cache_17404);
            }
            else {
                assign_slice_seq = &assign_space;
                _48key_cache_17404 = Remove_elements(start, stop, (SEQ_PTR(_48key_cache_17404)->ref == 1));
            }
        }
L6: 

        /** 	end for*/
        _i_18587 = _i_18587 + -1;
        goto L4; // [140] 101
L5: 
        ;
    }

    /** 	current_table_pos = -1*/
    DeRef(_48current_table_pos_17397);
    _48current_table_pos_17397 = -1;

    /** 	current_table_name = ""	*/
    RefDS(_5);
    DeRef(_48current_table_name_17398);
    _48current_table_name_17398 = _5;

    /** 	current_db = -1*/
    _48current_db_17396 = -1;

    /** 	key_pointers = {}*/
    RefDS(_5);
    DeRef(_48key_pointers_17403);
    _48key_pointers_17403 = _5;

    /** end procedure*/
    return;
    ;
}


int _48table_find(int _name_18597)
{
    int _tables_18598 = NOVALUE;
    int _nt_18599 = NOVALUE;
    int _t_header_18600 = NOVALUE;
    int _name_ptr_18601 = NOVALUE;
    int _seek_1__tmp_at6_18604 = NOVALUE;
    int _seek_inlined_seek_at_6_18603 = NOVALUE;
    int _seek_1__tmp_at44_18611 = NOVALUE;
    int _seek_inlined_seek_at_44_18610 = NOVALUE;
    int _seek_1__tmp_at84_18619 = NOVALUE;
    int _seek_inlined_seek_at_84_18618 = NOVALUE;
    int _seek_1__tmp_at106_18623 = NOVALUE;
    int _seek_inlined_seek_at_106_18622 = NOVALUE;
    int _10478 = NOVALUE;
    int _10476 = NOVALUE;
    int _10471 = NOVALUE;
    int _0, _1, _2;
    

    /** 	io:seek(current_db, TABLE_HEADERS)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at6_18604);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _48current_db_17396;
    ((int *)_2)[2] = 3;
    _seek_1__tmp_at6_18604 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_6_18603 = machine(19, _seek_1__tmp_at6_18604);
    DeRefi(_seek_1__tmp_at6_18604);
    _seek_1__tmp_at6_18604 = NOVALUE;

    /** 	if length(vLastErrors) > 0 then return -1 end if*/
    if (IS_SEQUENCE(_48vLastErrors_17420)){
            _10471 = SEQ_PTR(_48vLastErrors_17420)->length;
    }
    else {
        _10471 = 1;
    }
    if (_10471 <= 0)
    goto L1; // [27] 36
    DeRefDS(_name_18597);
    DeRef(_tables_18598);
    DeRef(_nt_18599);
    DeRef(_t_header_18600);
    DeRef(_name_ptr_18601);
    return -1;
L1: 

    /** 	tables = get4()*/
    _0 = _tables_18598;
    _tables_18598 = _48get4();
    DeRef(_0);

    /** 	io:seek(current_db, tables)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_tables_18598);
    DeRef(_seek_1__tmp_at44_18611);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _48current_db_17396;
    ((int *)_2)[2] = _tables_18598;
    _seek_1__tmp_at44_18611 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_44_18610 = machine(19, _seek_1__tmp_at44_18611);
    DeRef(_seek_1__tmp_at44_18611);
    _seek_1__tmp_at44_18611 = NOVALUE;

    /** 	nt = get4()*/
    _0 = _nt_18599;
    _nt_18599 = _48get4();
    DeRef(_0);

    /** 	t_header = tables+4*/
    DeRef(_t_header_18600);
    if (IS_ATOM_INT(_tables_18598)) {
        _t_header_18600 = _tables_18598 + 4;
        if ((long)((unsigned long)_t_header_18600 + (unsigned long)HIGH_BITS) >= 0) 
        _t_header_18600 = NewDouble((double)_t_header_18600);
    }
    else {
        _t_header_18600 = NewDouble(DBL_PTR(_tables_18598)->dbl + (double)4);
    }

    /** 	for i = 1 to nt do*/
    Ref(_nt_18599);
    DeRef(_10476);
    _10476 = _nt_18599;
    {
        int _i_18615;
        _i_18615 = 1;
L2: 
        if (binary_op_a(GREATER, _i_18615, _10476)){
            goto L3; // [74] 150
        }

        /** 		io:seek(current_db, t_header)*/

        /** 	return machine_func(M_SEEK, {fn, pos})*/
        Ref(_t_header_18600);
        DeRef(_seek_1__tmp_at84_18619);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _48current_db_17396;
        ((int *)_2)[2] = _t_header_18600;
        _seek_1__tmp_at84_18619 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_84_18618 = machine(19, _seek_1__tmp_at84_18619);
        DeRef(_seek_1__tmp_at84_18619);
        _seek_1__tmp_at84_18619 = NOVALUE;

        /** 		name_ptr = get4()*/
        _0 = _name_ptr_18601;
        _name_ptr_18601 = _48get4();
        DeRef(_0);

        /** 		io:seek(current_db, name_ptr)*/

        /** 	return machine_func(M_SEEK, {fn, pos})*/
        Ref(_name_ptr_18601);
        DeRef(_seek_1__tmp_at106_18623);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _48current_db_17396;
        ((int *)_2)[2] = _name_ptr_18601;
        _seek_1__tmp_at106_18623 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_106_18622 = machine(19, _seek_1__tmp_at106_18623);
        DeRef(_seek_1__tmp_at106_18623);
        _seek_1__tmp_at106_18623 = NOVALUE;

        /** 		if equal_string(name) > 0 then*/
        RefDS(_name_18597);
        _10478 = _48equal_string(_name_18597);
        if (binary_op_a(LESSEQ, _10478, 0)){
            DeRef(_10478);
            _10478 = NOVALUE;
            goto L4; // [126] 137
        }
        DeRef(_10478);
        _10478 = NOVALUE;

        /** 			return t_header*/
        DeRef(_i_18615);
        DeRefDS(_name_18597);
        DeRef(_tables_18598);
        DeRef(_nt_18599);
        DeRef(_name_ptr_18601);
        return _t_header_18600;
L4: 

        /** 		t_header += SIZEOF_TABLE_HEADER*/
        _0 = _t_header_18600;
        if (IS_ATOM_INT(_t_header_18600)) {
            _t_header_18600 = _t_header_18600 + 16;
            if ((long)((unsigned long)_t_header_18600 + (unsigned long)HIGH_BITS) >= 0) 
            _t_header_18600 = NewDouble((double)_t_header_18600);
        }
        else {
            _t_header_18600 = NewDouble(DBL_PTR(_t_header_18600)->dbl + (double)16);
        }
        DeRef(_0);

        /** 	end for*/
        _0 = _i_18615;
        if (IS_ATOM_INT(_i_18615)) {
            _i_18615 = _i_18615 + 1;
            if ((long)((unsigned long)_i_18615 +(unsigned long) HIGH_BITS) >= 0){
                _i_18615 = NewDouble((double)_i_18615);
            }
        }
        else {
            _i_18615 = binary_op_a(PLUS, _i_18615, 1);
        }
        DeRef(_0);
        goto L2; // [145] 81
L3: 
        ;
        DeRef(_i_18615);
    }

    /** 	return -1*/
    DeRefDS(_name_18597);
    DeRef(_tables_18598);
    DeRef(_nt_18599);
    DeRef(_t_header_18600);
    DeRef(_name_ptr_18601);
    return -1;
    ;
}


int _48db_select_table(int _name_18630)
{
    int _table_18631 = NOVALUE;
    int _nkeys_18632 = NOVALUE;
    int _index_18633 = NOVALUE;
    int _block_ptr_18634 = NOVALUE;
    int _block_size_18635 = NOVALUE;
    int _blocks_18636 = NOVALUE;
    int _k_18637 = NOVALUE;
    int _seek_1__tmp_at120_18656 = NOVALUE;
    int _seek_inlined_seek_at_120_18655 = NOVALUE;
    int _pos_inlined_seek_at_117_18654 = NOVALUE;
    int _seek_1__tmp_at178_18666 = NOVALUE;
    int _seek_inlined_seek_at_178_18665 = NOVALUE;
    int _seek_1__tmp_at205_18671 = NOVALUE;
    int _seek_inlined_seek_at_205_18670 = NOVALUE;
    int _10499 = NOVALUE;
    int _10498 = NOVALUE;
    int _10495 = NOVALUE;
    int _10490 = NOVALUE;
    int _10485 = NOVALUE;
    int _10481 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if equal(current_table_name, name) then*/
    if (_48current_table_name_17398 == _name_18630)
    _10481 = 1;
    else if (IS_ATOM_INT(_48current_table_name_17398) && IS_ATOM_INT(_name_18630))
    _10481 = 0;
    else
    _10481 = (compare(_48current_table_name_17398, _name_18630) == 0);
    if (_10481 == 0)
    {
        _10481 = NOVALUE;
        goto L1; // [11] 21
    }
    else{
        _10481 = NOVALUE;
    }

    /** 		return DB_OK*/
    DeRefDS(_name_18630);
    DeRef(_table_18631);
    DeRef(_nkeys_18632);
    DeRef(_index_18633);
    DeRef(_block_ptr_18634);
    DeRef(_block_size_18635);
    return 0;
L1: 

    /** 	table = table_find(name)*/
    RefDS(_name_18630);
    _0 = _table_18631;
    _table_18631 = _48table_find(_name_18630);
    DeRef(_0);

    /** 	if table = -1 then*/
    if (binary_op_a(NOTEQ, _table_18631, -1)){
        goto L2; // [29] 40
    }

    /** 		return DB_OPEN_FAIL*/
    DeRefDS(_name_18630);
    DeRef(_table_18631);
    DeRef(_nkeys_18632);
    DeRef(_index_18633);
    DeRef(_block_ptr_18634);
    DeRef(_block_size_18635);
    return -1;
L2: 

    /** 	save_keys()*/
    _48save_keys();

    /** 	current_table_pos = table*/
    Ref(_table_18631);
    DeRef(_48current_table_pos_17397);
    _48current_table_pos_17397 = _table_18631;

    /** 	current_table_name = name*/
    RefDS(_name_18630);
    DeRef(_48current_table_name_17398);
    _48current_table_name_17398 = _name_18630;

    /** 	k = 0*/
    _k_18637 = 0;

    /** 	if caching_option = 1 then*/

    /** 		k = eu:find({current_db, current_table_pos}, cache_index)*/
    Ref(_48current_table_pos_17397);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _48current_db_17396;
    ((int *)_2)[2] = _48current_table_pos_17397;
    _10485 = MAKE_SEQ(_1);
    _k_18637 = find_from(_10485, _48cache_index_17405, 1);
    DeRefDS(_10485);
    _10485 = NOVALUE;

    /** 		if k != 0 then*/
    if (_k_18637 == 0)
    goto L3; // [88] 103

    /** 			key_pointers = key_cache[k]*/
    DeRef(_48key_pointers_17403);
    _2 = (int)SEQ_PTR(_48key_cache_17404);
    _48key_pointers_17403 = (int)*(((s1_ptr)_2)->base + _k_18637);
    Ref(_48key_pointers_17403);
L3: 

    /** 	if k = 0 then*/
    if (_k_18637 != 0)
    goto L4; // [106] 269

    /** 		io:seek(current_db, table+4)*/
    if (IS_ATOM_INT(_table_18631)) {
        _10490 = _table_18631 + 4;
        if ((long)((unsigned long)_10490 + (unsigned long)HIGH_BITS) >= 0) 
        _10490 = NewDouble((double)_10490);
    }
    else {
        _10490 = NewDouble(DBL_PTR(_table_18631)->dbl + (double)4);
    }
    DeRef(_pos_inlined_seek_at_117_18654);
    _pos_inlined_seek_at_117_18654 = _10490;
    _10490 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_117_18654);
    DeRef(_seek_1__tmp_at120_18656);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _48current_db_17396;
    ((int *)_2)[2] = _pos_inlined_seek_at_117_18654;
    _seek_1__tmp_at120_18656 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_120_18655 = machine(19, _seek_1__tmp_at120_18656);
    DeRef(_pos_inlined_seek_at_117_18654);
    _pos_inlined_seek_at_117_18654 = NOVALUE;
    DeRef(_seek_1__tmp_at120_18656);
    _seek_1__tmp_at120_18656 = NOVALUE;

    /** 		nkeys = get4()*/
    _0 = _nkeys_18632;
    _nkeys_18632 = _48get4();
    DeRef(_0);

    /** 		blocks = get4()*/
    _blocks_18636 = _48get4();
    if (!IS_ATOM_INT(_blocks_18636)) {
        _1 = (long)(DBL_PTR(_blocks_18636)->dbl);
        DeRefDS(_blocks_18636);
        _blocks_18636 = _1;
    }

    /** 		index = get4()*/
    _0 = _index_18633;
    _index_18633 = _48get4();
    DeRef(_0);

    /** 		key_pointers = repeat(0, nkeys)*/
    DeRef(_48key_pointers_17403);
    _48key_pointers_17403 = Repeat(0, _nkeys_18632);

    /** 		k = 1*/
    _k_18637 = 1;

    /** 		for b = 0 to blocks-1 do*/
    _10495 = _blocks_18636 - 1;
    if ((long)((unsigned long)_10495 +(unsigned long) HIGH_BITS) >= 0){
        _10495 = NewDouble((double)_10495);
    }
    {
        int _b_18662;
        _b_18662 = 0;
L5: 
        if (binary_op_a(GREATER, _b_18662, _10495)){
            goto L6; // [168] 268
        }

        /** 			io:seek(current_db, index)*/

        /** 	return machine_func(M_SEEK, {fn, pos})*/
        Ref(_index_18633);
        DeRef(_seek_1__tmp_at178_18666);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _48current_db_17396;
        ((int *)_2)[2] = _index_18633;
        _seek_1__tmp_at178_18666 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_178_18665 = machine(19, _seek_1__tmp_at178_18666);
        DeRef(_seek_1__tmp_at178_18666);
        _seek_1__tmp_at178_18666 = NOVALUE;

        /** 			block_size = get4()*/
        _0 = _block_size_18635;
        _block_size_18635 = _48get4();
        DeRef(_0);

        /** 			block_ptr = get4()*/
        _0 = _block_ptr_18634;
        _block_ptr_18634 = _48get4();
        DeRef(_0);

        /** 			io:seek(current_db, block_ptr)*/

        /** 	return machine_func(M_SEEK, {fn, pos})*/
        Ref(_block_ptr_18634);
        DeRef(_seek_1__tmp_at205_18671);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _48current_db_17396;
        ((int *)_2)[2] = _block_ptr_18634;
        _seek_1__tmp_at205_18671 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_205_18670 = machine(19, _seek_1__tmp_at205_18671);
        DeRef(_seek_1__tmp_at205_18671);
        _seek_1__tmp_at205_18671 = NOVALUE;

        /** 			for j = 1 to block_size do*/
        Ref(_block_size_18635);
        DeRef(_10498);
        _10498 = _block_size_18635;
        {
            int _j_18673;
            _j_18673 = 1;
L7: 
            if (binary_op_a(GREATER, _j_18673, _10498)){
                goto L8; // [224] 255
            }

            /** 				key_pointers[k] = get4()*/
            _10499 = _48get4();
            _2 = (int)SEQ_PTR(_48key_pointers_17403);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _48key_pointers_17403 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _k_18637);
            _1 = *(int *)_2;
            *(int *)_2 = _10499;
            if( _1 != _10499 ){
                DeRef(_1);
            }
            _10499 = NOVALUE;

            /** 				k += 1*/
            _k_18637 = _k_18637 + 1;

            /** 			end for*/
            _0 = _j_18673;
            if (IS_ATOM_INT(_j_18673)) {
                _j_18673 = _j_18673 + 1;
                if ((long)((unsigned long)_j_18673 +(unsigned long) HIGH_BITS) >= 0){
                    _j_18673 = NewDouble((double)_j_18673);
                }
            }
            else {
                _j_18673 = binary_op_a(PLUS, _j_18673, 1);
            }
            DeRef(_0);
            goto L7; // [250] 231
L8: 
            ;
            DeRef(_j_18673);
        }

        /** 			index += 8*/
        _0 = _index_18633;
        if (IS_ATOM_INT(_index_18633)) {
            _index_18633 = _index_18633 + 8;
            if ((long)((unsigned long)_index_18633 + (unsigned long)HIGH_BITS) >= 0) 
            _index_18633 = NewDouble((double)_index_18633);
        }
        else {
            _index_18633 = NewDouble(DBL_PTR(_index_18633)->dbl + (double)8);
        }
        DeRef(_0);

        /** 		end for*/
        _0 = _b_18662;
        if (IS_ATOM_INT(_b_18662)) {
            _b_18662 = _b_18662 + 1;
            if ((long)((unsigned long)_b_18662 +(unsigned long) HIGH_BITS) >= 0){
                _b_18662 = NewDouble((double)_b_18662);
            }
        }
        else {
            _b_18662 = binary_op_a(PLUS, _b_18662, 1);
        }
        DeRef(_0);
        goto L5; // [263] 175
L6: 
        ;
        DeRef(_b_18662);
    }
L4: 

    /** 	return DB_OK*/
    DeRefDS(_name_18630);
    DeRef(_table_18631);
    DeRef(_nkeys_18632);
    DeRef(_index_18633);
    DeRef(_block_ptr_18634);
    DeRef(_block_size_18635);
    DeRef(_10495);
    _10495 = NOVALUE;
    return 0;
    ;
}


int _48db_create_table(int _name_18682, int _init_records_18683)
{
    int _name_ptr_18684 = NOVALUE;
    int _nt_18685 = NOVALUE;
    int _tables_18686 = NOVALUE;
    int _newtables_18687 = NOVALUE;
    int _table_18688 = NOVALUE;
    int _records_ptr_18689 = NOVALUE;
    int _size_18690 = NOVALUE;
    int _newsize_18691 = NOVALUE;
    int _index_ptr_18692 = NOVALUE;
    int _remaining_18693 = NOVALUE;
    int _init_index_18694 = NOVALUE;
    int _seek_1__tmp_at68_18708 = NOVALUE;
    int _seek_inlined_seek_at_68_18707 = NOVALUE;
    int _seek_1__tmp_at97_18714 = NOVALUE;
    int _seek_inlined_seek_at_97_18713 = NOVALUE;
    int _pos_inlined_seek_at_94_18712 = NOVALUE;
    int _put4_1__tmp_at159_18727 = NOVALUE;
    int _seek_1__tmp_at196_18732 = NOVALUE;
    int _seek_inlined_seek_at_196_18731 = NOVALUE;
    int _pos_inlined_seek_at_193_18730 = NOVALUE;
    int _seek_1__tmp_at239_18740 = NOVALUE;
    int _seek_inlined_seek_at_239_18739 = NOVALUE;
    int _pos_inlined_seek_at_236_18738 = NOVALUE;
    int _s_inlined_putn_at_288_18748 = NOVALUE;
    int _seek_1__tmp_at316_18751 = NOVALUE;
    int _seek_inlined_seek_at_316_18750 = NOVALUE;
    int _put4_1__tmp_at331_18753 = NOVALUE;
    int _seek_1__tmp_at369_18757 = NOVALUE;
    int _seek_inlined_seek_at_369_18756 = NOVALUE;
    int _put4_1__tmp_at384_18759 = NOVALUE;
    int _s_inlined_putn_at_431_18765 = NOVALUE;
    int _put4_1__tmp_at462_18769 = NOVALUE;
    int _put4_1__tmp_at490_18771 = NOVALUE;
    int _s_inlined_putn_at_530_18776 = NOVALUE;
    int _s_inlined_putn_at_568_18782 = NOVALUE;
    int _seek_1__tmp_at610_18790 = NOVALUE;
    int _seek_inlined_seek_at_610_18789 = NOVALUE;
    int _pos_inlined_seek_at_607_18788 = NOVALUE;
    int _put4_1__tmp_at625_18792 = NOVALUE;
    int _put4_1__tmp_at653_18794 = NOVALUE;
    int _put4_1__tmp_at681_18796 = NOVALUE;
    int _put4_1__tmp_at709_18798 = NOVALUE;
    int _10548 = NOVALUE;
    int _10547 = NOVALUE;
    int _10546 = NOVALUE;
    int _10545 = NOVALUE;
    int _10544 = NOVALUE;
    int _10543 = NOVALUE;
    int _10541 = NOVALUE;
    int _10540 = NOVALUE;
    int _10539 = NOVALUE;
    int _10538 = NOVALUE;
    int _10537 = NOVALUE;
    int _10535 = NOVALUE;
    int _10534 = NOVALUE;
    int _10533 = NOVALUE;
    int _10531 = NOVALUE;
    int _10530 = NOVALUE;
    int _10529 = NOVALUE;
    int _10528 = NOVALUE;
    int _10527 = NOVALUE;
    int _10526 = NOVALUE;
    int _10525 = NOVALUE;
    int _10523 = NOVALUE;
    int _10522 = NOVALUE;
    int _10521 = NOVALUE;
    int _10518 = NOVALUE;
    int _10517 = NOVALUE;
    int _10515 = NOVALUE;
    int _10514 = NOVALUE;
    int _10512 = NOVALUE;
    int _10510 = NOVALUE;
    int _10507 = NOVALUE;
    int _10502 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not cstring(name) then*/
    RefDS(_name_18682);
    _10502 = _9cstring(_name_18682);
    if (IS_ATOM_INT(_10502)) {
        if (_10502 != 0){
            DeRef(_10502);
            _10502 = NOVALUE;
            goto L1; // [11] 21
        }
    }
    else {
        if (DBL_PTR(_10502)->dbl != 0.0){
            DeRef(_10502);
            _10502 = NOVALUE;
            goto L1; // [11] 21
        }
    }
    DeRef(_10502);
    _10502 = NOVALUE;

    /** 		return DB_BAD_NAME*/
    DeRefDS(_name_18682);
    DeRef(_name_ptr_18684);
    DeRef(_nt_18685);
    DeRef(_tables_18686);
    DeRef(_newtables_18687);
    DeRef(_table_18688);
    DeRef(_records_ptr_18689);
    DeRef(_size_18690);
    DeRef(_newsize_18691);
    DeRef(_index_ptr_18692);
    DeRef(_remaining_18693);
    return -4;
L1: 

    /** 	table = table_find(name)*/
    RefDS(_name_18682);
    _0 = _table_18688;
    _table_18688 = _48table_find(_name_18682);
    DeRef(_0);

    /** 	if table != -1 then*/
    if (binary_op_a(EQUALS, _table_18688, -1)){
        goto L2; // [29] 40
    }

    /** 		return DB_EXISTS_ALREADY*/
    DeRefDS(_name_18682);
    DeRef(_name_ptr_18684);
    DeRef(_nt_18685);
    DeRef(_tables_18686);
    DeRef(_newtables_18687);
    DeRef(_table_18688);
    DeRef(_records_ptr_18689);
    DeRef(_size_18690);
    DeRef(_newsize_18691);
    DeRef(_index_ptr_18692);
    DeRef(_remaining_18693);
    return -2;
L2: 

    /** 	if init_records < 1 then*/
    if (_init_records_18683 >= 1)
    goto L3; // [42] 52

    /** 		init_records = 1*/
    _init_records_18683 = 1;
L3: 

    /** 	init_index = math:min({init_records, MAX_INDEX})*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _init_records_18683;
    ((int *)_2)[2] = 10;
    _10507 = MAKE_SEQ(_1);
    _init_index_18694 = _20min(_10507);
    _10507 = NOVALUE;
    if (!IS_ATOM_INT(_init_index_18694)) {
        _1 = (long)(DBL_PTR(_init_index_18694)->dbl);
        DeRefDS(_init_index_18694);
        _init_index_18694 = _1;
    }

    /** 	io:seek(current_db, TABLE_HEADERS)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at68_18708);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _48current_db_17396;
    ((int *)_2)[2] = 3;
    _seek_1__tmp_at68_18708 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_68_18707 = machine(19, _seek_1__tmp_at68_18708);
    DeRefi(_seek_1__tmp_at68_18708);
    _seek_1__tmp_at68_18708 = NOVALUE;

    /** 	tables = get4()*/
    _0 = _tables_18686;
    _tables_18686 = _48get4();
    DeRef(_0);

    /** 	io:seek(current_db, tables-4)*/
    if (IS_ATOM_INT(_tables_18686)) {
        _10510 = _tables_18686 - 4;
        if ((long)((unsigned long)_10510 +(unsigned long) HIGH_BITS) >= 0){
            _10510 = NewDouble((double)_10510);
        }
    }
    else {
        _10510 = NewDouble(DBL_PTR(_tables_18686)->dbl - (double)4);
    }
    DeRef(_pos_inlined_seek_at_94_18712);
    _pos_inlined_seek_at_94_18712 = _10510;
    _10510 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_94_18712);
    DeRef(_seek_1__tmp_at97_18714);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _48current_db_17396;
    ((int *)_2)[2] = _pos_inlined_seek_at_94_18712;
    _seek_1__tmp_at97_18714 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_97_18713 = machine(19, _seek_1__tmp_at97_18714);
    DeRef(_pos_inlined_seek_at_94_18712);
    _pos_inlined_seek_at_94_18712 = NOVALUE;
    DeRef(_seek_1__tmp_at97_18714);
    _seek_1__tmp_at97_18714 = NOVALUE;

    /** 	size = get4()*/
    _0 = _size_18690;
    _size_18690 = _48get4();
    DeRef(_0);

    /** 	nt = get4()+1*/
    _10512 = _48get4();
    DeRef(_nt_18685);
    if (IS_ATOM_INT(_10512)) {
        _nt_18685 = _10512 + 1;
        if (_nt_18685 > MAXINT){
            _nt_18685 = NewDouble((double)_nt_18685);
        }
    }
    else
    _nt_18685 = binary_op(PLUS, 1, _10512);
    DeRef(_10512);
    _10512 = NOVALUE;

    /** 	if nt*SIZEOF_TABLE_HEADER + 8 > size then*/
    if (IS_ATOM_INT(_nt_18685)) {
        if (_nt_18685 == (short)_nt_18685)
        _10514 = _nt_18685 * 16;
        else
        _10514 = NewDouble(_nt_18685 * (double)16);
    }
    else {
        _10514 = NewDouble(DBL_PTR(_nt_18685)->dbl * (double)16);
    }
    if (IS_ATOM_INT(_10514)) {
        _10515 = _10514 + 8;
        if ((long)((unsigned long)_10515 + (unsigned long)HIGH_BITS) >= 0) 
        _10515 = NewDouble((double)_10515);
    }
    else {
        _10515 = NewDouble(DBL_PTR(_10514)->dbl + (double)8);
    }
    DeRef(_10514);
    _10514 = NOVALUE;
    if (binary_op_a(LESSEQ, _10515, _size_18690)){
        DeRef(_10515);
        _10515 = NOVALUE;
        goto L4; // [134] 365
    }
    DeRef(_10515);
    _10515 = NOVALUE;

    /** 		newsize = floor(size + size / 2)*/
    if (IS_ATOM_INT(_size_18690)) {
        if (_size_18690 & 1) {
            _10517 = NewDouble((_size_18690 >> 1) + 0.5);
        }
        else
        _10517 = _size_18690 >> 1;
    }
    else {
        _10517 = binary_op(DIVIDE, _size_18690, 2);
    }
    if (IS_ATOM_INT(_size_18690) && IS_ATOM_INT(_10517)) {
        _10518 = _size_18690 + _10517;
        if ((long)((unsigned long)_10518 + (unsigned long)HIGH_BITS) >= 0) 
        _10518 = NewDouble((double)_10518);
    }
    else {
        if (IS_ATOM_INT(_size_18690)) {
            _10518 = NewDouble((double)_size_18690 + DBL_PTR(_10517)->dbl);
        }
        else {
            if (IS_ATOM_INT(_10517)) {
                _10518 = NewDouble(DBL_PTR(_size_18690)->dbl + (double)_10517);
            }
            else
            _10518 = NewDouble(DBL_PTR(_size_18690)->dbl + DBL_PTR(_10517)->dbl);
        }
    }
    DeRef(_10517);
    _10517 = NOVALUE;
    DeRef(_newsize_18691);
    if (IS_ATOM_INT(_10518))
    _newsize_18691 = e_floor(_10518);
    else
    _newsize_18691 = unary_op(FLOOR, _10518);
    DeRef(_10518);
    _10518 = NOVALUE;

    /** 		newtables = db_allocate(newsize)*/
    Ref(_newsize_18691);
    _0 = _newtables_18687;
    _newtables_18687 = _48db_allocate(_newsize_18691);
    DeRef(_0);

    /** 		put4(nt)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_48mem0_17438)){
        poke4_addr = (unsigned long *)_48mem0_17438;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_48mem0_17438)->dbl);
    }
    if (IS_ATOM_INT(_nt_18685)) {
        *poke4_addr = (unsigned long)_nt_18685;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_nt_18685)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at159_18727);
    _1 = (int)SEQ_PTR(_48memseq_17673);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at159_18727 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_48current_db_17396, _put4_1__tmp_at159_18727); // DJP 

    /** end procedure*/
    goto L5; // [180] 183
L5: 
    DeRefi(_put4_1__tmp_at159_18727);
    _put4_1__tmp_at159_18727 = NOVALUE;

    /** 		io:seek(current_db, tables+4)*/
    if (IS_ATOM_INT(_tables_18686)) {
        _10521 = _tables_18686 + 4;
        if ((long)((unsigned long)_10521 + (unsigned long)HIGH_BITS) >= 0) 
        _10521 = NewDouble((double)_10521);
    }
    else {
        _10521 = NewDouble(DBL_PTR(_tables_18686)->dbl + (double)4);
    }
    DeRef(_pos_inlined_seek_at_193_18730);
    _pos_inlined_seek_at_193_18730 = _10521;
    _10521 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_193_18730);
    DeRef(_seek_1__tmp_at196_18732);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _48current_db_17396;
    ((int *)_2)[2] = _pos_inlined_seek_at_193_18730;
    _seek_1__tmp_at196_18732 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_196_18731 = machine(19, _seek_1__tmp_at196_18732);
    DeRef(_pos_inlined_seek_at_193_18730);
    _pos_inlined_seek_at_193_18730 = NOVALUE;
    DeRef(_seek_1__tmp_at196_18732);
    _seek_1__tmp_at196_18732 = NOVALUE;

    /** 		remaining = io:get_bytes(current_db, (nt-1)*SIZEOF_TABLE_HEADER)*/
    if (IS_ATOM_INT(_nt_18685)) {
        _10522 = _nt_18685 - 1;
        if ((long)((unsigned long)_10522 +(unsigned long) HIGH_BITS) >= 0){
            _10522 = NewDouble((double)_10522);
        }
    }
    else {
        _10522 = NewDouble(DBL_PTR(_nt_18685)->dbl - (double)1);
    }
    if (IS_ATOM_INT(_10522)) {
        if (_10522 == (short)_10522)
        _10523 = _10522 * 16;
        else
        _10523 = NewDouble(_10522 * (double)16);
    }
    else {
        _10523 = NewDouble(DBL_PTR(_10522)->dbl * (double)16);
    }
    DeRef(_10522);
    _10522 = NOVALUE;
    _0 = _remaining_18693;
    _remaining_18693 = _18get_bytes(_48current_db_17396, _10523);
    DeRef(_0);
    _10523 = NOVALUE;

    /** 		io:seek(current_db, newtables+4)*/
    if (IS_ATOM_INT(_newtables_18687)) {
        _10525 = _newtables_18687 + 4;
        if ((long)((unsigned long)_10525 + (unsigned long)HIGH_BITS) >= 0) 
        _10525 = NewDouble((double)_10525);
    }
    else {
        _10525 = NewDouble(DBL_PTR(_newtables_18687)->dbl + (double)4);
    }
    DeRef(_pos_inlined_seek_at_236_18738);
    _pos_inlined_seek_at_236_18738 = _10525;
    _10525 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_236_18738);
    DeRef(_seek_1__tmp_at239_18740);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _48current_db_17396;
    ((int *)_2)[2] = _pos_inlined_seek_at_236_18738;
    _seek_1__tmp_at239_18740 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_239_18739 = machine(19, _seek_1__tmp_at239_18740);
    DeRef(_pos_inlined_seek_at_236_18738);
    _pos_inlined_seek_at_236_18738 = NOVALUE;
    DeRef(_seek_1__tmp_at239_18740);
    _seek_1__tmp_at239_18740 = NOVALUE;

    /** 		putn(remaining)*/

    /** 	puts(current_db, s)*/
    EPuts(_48current_db_17396, _remaining_18693); // DJP 

    /** end procedure*/
    goto L6; // [263] 266
L6: 

    /** 		putn(repeat(0, newsize - 4 - (nt-1)*SIZEOF_TABLE_HEADER))*/
    if (IS_ATOM_INT(_newsize_18691)) {
        _10526 = _newsize_18691 - 4;
        if ((long)((unsigned long)_10526 +(unsigned long) HIGH_BITS) >= 0){
            _10526 = NewDouble((double)_10526);
        }
    }
    else {
        _10526 = NewDouble(DBL_PTR(_newsize_18691)->dbl - (double)4);
    }
    if (IS_ATOM_INT(_nt_18685)) {
        _10527 = _nt_18685 - 1;
        if ((long)((unsigned long)_10527 +(unsigned long) HIGH_BITS) >= 0){
            _10527 = NewDouble((double)_10527);
        }
    }
    else {
        _10527 = NewDouble(DBL_PTR(_nt_18685)->dbl - (double)1);
    }
    if (IS_ATOM_INT(_10527)) {
        if (_10527 == (short)_10527)
        _10528 = _10527 * 16;
        else
        _10528 = NewDouble(_10527 * (double)16);
    }
    else {
        _10528 = NewDouble(DBL_PTR(_10527)->dbl * (double)16);
    }
    DeRef(_10527);
    _10527 = NOVALUE;
    if (IS_ATOM_INT(_10526) && IS_ATOM_INT(_10528)) {
        _10529 = _10526 - _10528;
    }
    else {
        if (IS_ATOM_INT(_10526)) {
            _10529 = NewDouble((double)_10526 - DBL_PTR(_10528)->dbl);
        }
        else {
            if (IS_ATOM_INT(_10528)) {
                _10529 = NewDouble(DBL_PTR(_10526)->dbl - (double)_10528);
            }
            else
            _10529 = NewDouble(DBL_PTR(_10526)->dbl - DBL_PTR(_10528)->dbl);
        }
    }
    DeRef(_10526);
    _10526 = NOVALUE;
    DeRef(_10528);
    _10528 = NOVALUE;
    _10530 = Repeat(0, _10529);
    DeRef(_10529);
    _10529 = NOVALUE;
    DeRefi(_s_inlined_putn_at_288_18748);
    _s_inlined_putn_at_288_18748 = _10530;
    _10530 = NOVALUE;

    /** 	puts(current_db, s)*/
    EPuts(_48current_db_17396, _s_inlined_putn_at_288_18748); // DJP 

    /** end procedure*/
    goto L7; // [302] 305
L7: 
    DeRefi(_s_inlined_putn_at_288_18748);
    _s_inlined_putn_at_288_18748 = NOVALUE;

    /** 		db_free(tables)*/
    Ref(_tables_18686);
    _48db_free(_tables_18686);

    /** 		io:seek(current_db, TABLE_HEADERS)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at316_18751);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _48current_db_17396;
    ((int *)_2)[2] = 3;
    _seek_1__tmp_at316_18751 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_316_18750 = machine(19, _seek_1__tmp_at316_18751);
    DeRefi(_seek_1__tmp_at316_18751);
    _seek_1__tmp_at316_18751 = NOVALUE;

    /** 		put4(newtables)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_48mem0_17438)){
        poke4_addr = (unsigned long *)_48mem0_17438;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_48mem0_17438)->dbl);
    }
    if (IS_ATOM_INT(_newtables_18687)) {
        *poke4_addr = (unsigned long)_newtables_18687;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_newtables_18687)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at331_18753);
    _1 = (int)SEQ_PTR(_48memseq_17673);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at331_18753 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_48current_db_17396, _put4_1__tmp_at331_18753); // DJP 

    /** end procedure*/
    goto L8; // [352] 355
L8: 
    DeRefi(_put4_1__tmp_at331_18753);
    _put4_1__tmp_at331_18753 = NOVALUE;

    /** 		tables = newtables*/
    Ref(_newtables_18687);
    DeRef(_tables_18686);
    _tables_18686 = _newtables_18687;
    goto L9; // [362] 411
L4: 

    /** 		io:seek(current_db, tables)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_tables_18686);
    DeRef(_seek_1__tmp_at369_18757);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _48current_db_17396;
    ((int *)_2)[2] = _tables_18686;
    _seek_1__tmp_at369_18757 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_369_18756 = machine(19, _seek_1__tmp_at369_18757);
    DeRef(_seek_1__tmp_at369_18757);
    _seek_1__tmp_at369_18757 = NOVALUE;

    /** 		put4(nt)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_48mem0_17438)){
        poke4_addr = (unsigned long *)_48mem0_17438;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_48mem0_17438)->dbl);
    }
    if (IS_ATOM_INT(_nt_18685)) {
        *poke4_addr = (unsigned long)_nt_18685;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_nt_18685)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at384_18759);
    _1 = (int)SEQ_PTR(_48memseq_17673);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at384_18759 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_48current_db_17396, _put4_1__tmp_at384_18759); // DJP 

    /** end procedure*/
    goto LA; // [405] 408
LA: 
    DeRefi(_put4_1__tmp_at384_18759);
    _put4_1__tmp_at384_18759 = NOVALUE;
L9: 

    /** 	records_ptr = db_allocate(init_records * 4)*/
    if (_init_records_18683 == (short)_init_records_18683)
    _10531 = _init_records_18683 * 4;
    else
    _10531 = NewDouble(_init_records_18683 * (double)4);
    _0 = _records_ptr_18689;
    _records_ptr_18689 = _48db_allocate(_10531);
    DeRef(_0);
    _10531 = NOVALUE;

    /** 	putn(repeat(0, init_records * 4))*/
    _10533 = _init_records_18683 * 4;
    _10534 = Repeat(0, _10533);
    _10533 = NOVALUE;
    DeRefi(_s_inlined_putn_at_431_18765);
    _s_inlined_putn_at_431_18765 = _10534;
    _10534 = NOVALUE;

    /** 	puts(current_db, s)*/
    EPuts(_48current_db_17396, _s_inlined_putn_at_431_18765); // DJP 

    /** end procedure*/
    goto LB; // [445] 448
LB: 
    DeRefi(_s_inlined_putn_at_431_18765);
    _s_inlined_putn_at_431_18765 = NOVALUE;

    /** 	index_ptr = db_allocate(init_index * 8)*/
    if (_init_index_18694 == (short)_init_index_18694)
    _10535 = _init_index_18694 * 8;
    else
    _10535 = NewDouble(_init_index_18694 * (double)8);
    _0 = _index_ptr_18692;
    _index_ptr_18692 = _48db_allocate(_10535);
    DeRef(_0);
    _10535 = NOVALUE;

    /** 	put4(0)  -- 0 records*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_48mem0_17438)){
        poke4_addr = (unsigned long *)_48mem0_17438;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_48mem0_17438)->dbl);
    }
    *poke4_addr = (unsigned long)0;

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at462_18769);
    _1 = (int)SEQ_PTR(_48memseq_17673);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at462_18769 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_48current_db_17396, _put4_1__tmp_at462_18769); // DJP 

    /** end procedure*/
    goto LC; // [483] 486
LC: 
    DeRefi(_put4_1__tmp_at462_18769);
    _put4_1__tmp_at462_18769 = NOVALUE;

    /** 	put4(records_ptr) -- point to 1st block*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_48mem0_17438)){
        poke4_addr = (unsigned long *)_48mem0_17438;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_48mem0_17438)->dbl);
    }
    if (IS_ATOM_INT(_records_ptr_18689)) {
        *poke4_addr = (unsigned long)_records_ptr_18689;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_records_ptr_18689)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at490_18771);
    _1 = (int)SEQ_PTR(_48memseq_17673);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at490_18771 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_48current_db_17396, _put4_1__tmp_at490_18771); // DJP 

    /** end procedure*/
    goto LD; // [511] 514
LD: 
    DeRefi(_put4_1__tmp_at490_18771);
    _put4_1__tmp_at490_18771 = NOVALUE;

    /** 	putn(repeat(0, (init_index-1) * 8))*/
    _10537 = _init_index_18694 - 1;
    if ((long)((unsigned long)_10537 +(unsigned long) HIGH_BITS) >= 0){
        _10537 = NewDouble((double)_10537);
    }
    if (IS_ATOM_INT(_10537)) {
        _10538 = _10537 * 8;
    }
    else {
        _10538 = NewDouble(DBL_PTR(_10537)->dbl * (double)8);
    }
    DeRef(_10537);
    _10537 = NOVALUE;
    _10539 = Repeat(0, _10538);
    DeRef(_10538);
    _10538 = NOVALUE;
    DeRefi(_s_inlined_putn_at_530_18776);
    _s_inlined_putn_at_530_18776 = _10539;
    _10539 = NOVALUE;

    /** 	puts(current_db, s)*/
    EPuts(_48current_db_17396, _s_inlined_putn_at_530_18776); // DJP 

    /** end procedure*/
    goto LE; // [544] 547
LE: 
    DeRefi(_s_inlined_putn_at_530_18776);
    _s_inlined_putn_at_530_18776 = NOVALUE;

    /** 	name_ptr = db_allocate(length(name)+1)*/
    if (IS_SEQUENCE(_name_18682)){
            _10540 = SEQ_PTR(_name_18682)->length;
    }
    else {
        _10540 = 1;
    }
    _10541 = _10540 + 1;
    _10540 = NOVALUE;
    _0 = _name_ptr_18684;
    _name_ptr_18684 = _48db_allocate(_10541);
    DeRef(_0);
    _10541 = NOVALUE;

    /** 	putn(name & 0)*/
    Append(&_10543, _name_18682, 0);
    DeRef(_s_inlined_putn_at_568_18782);
    _s_inlined_putn_at_568_18782 = _10543;
    _10543 = NOVALUE;

    /** 	puts(current_db, s)*/
    EPuts(_48current_db_17396, _s_inlined_putn_at_568_18782); // DJP 

    /** end procedure*/
    goto LF; // [582] 585
LF: 
    DeRef(_s_inlined_putn_at_568_18782);
    _s_inlined_putn_at_568_18782 = NOVALUE;

    /** 	io:seek(current_db, tables+4+(nt-1)*SIZEOF_TABLE_HEADER)*/
    if (IS_ATOM_INT(_tables_18686)) {
        _10544 = _tables_18686 + 4;
        if ((long)((unsigned long)_10544 + (unsigned long)HIGH_BITS) >= 0) 
        _10544 = NewDouble((double)_10544);
    }
    else {
        _10544 = NewDouble(DBL_PTR(_tables_18686)->dbl + (double)4);
    }
    if (IS_ATOM_INT(_nt_18685)) {
        _10545 = _nt_18685 - 1;
        if ((long)((unsigned long)_10545 +(unsigned long) HIGH_BITS) >= 0){
            _10545 = NewDouble((double)_10545);
        }
    }
    else {
        _10545 = NewDouble(DBL_PTR(_nt_18685)->dbl - (double)1);
    }
    if (IS_ATOM_INT(_10545)) {
        if (_10545 == (short)_10545)
        _10546 = _10545 * 16;
        else
        _10546 = NewDouble(_10545 * (double)16);
    }
    else {
        _10546 = NewDouble(DBL_PTR(_10545)->dbl * (double)16);
    }
    DeRef(_10545);
    _10545 = NOVALUE;
    if (IS_ATOM_INT(_10544) && IS_ATOM_INT(_10546)) {
        _10547 = _10544 + _10546;
        if ((long)((unsigned long)_10547 + (unsigned long)HIGH_BITS) >= 0) 
        _10547 = NewDouble((double)_10547);
    }
    else {
        if (IS_ATOM_INT(_10544)) {
            _10547 = NewDouble((double)_10544 + DBL_PTR(_10546)->dbl);
        }
        else {
            if (IS_ATOM_INT(_10546)) {
                _10547 = NewDouble(DBL_PTR(_10544)->dbl + (double)_10546);
            }
            else
            _10547 = NewDouble(DBL_PTR(_10544)->dbl + DBL_PTR(_10546)->dbl);
        }
    }
    DeRef(_10544);
    _10544 = NOVALUE;
    DeRef(_10546);
    _10546 = NOVALUE;
    DeRef(_pos_inlined_seek_at_607_18788);
    _pos_inlined_seek_at_607_18788 = _10547;
    _10547 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_607_18788);
    DeRef(_seek_1__tmp_at610_18790);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _48current_db_17396;
    ((int *)_2)[2] = _pos_inlined_seek_at_607_18788;
    _seek_1__tmp_at610_18790 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_610_18789 = machine(19, _seek_1__tmp_at610_18790);
    DeRef(_pos_inlined_seek_at_607_18788);
    _pos_inlined_seek_at_607_18788 = NOVALUE;
    DeRef(_seek_1__tmp_at610_18790);
    _seek_1__tmp_at610_18790 = NOVALUE;

    /** 	put4(name_ptr)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_48mem0_17438)){
        poke4_addr = (unsigned long *)_48mem0_17438;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_48mem0_17438)->dbl);
    }
    if (IS_ATOM_INT(_name_ptr_18684)) {
        *poke4_addr = (unsigned long)_name_ptr_18684;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_name_ptr_18684)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at625_18792);
    _1 = (int)SEQ_PTR(_48memseq_17673);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at625_18792 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_48current_db_17396, _put4_1__tmp_at625_18792); // DJP 

    /** end procedure*/
    goto L10; // [646] 649
L10: 
    DeRefi(_put4_1__tmp_at625_18792);
    _put4_1__tmp_at625_18792 = NOVALUE;

    /** 	put4(0)  -- start with 0 records total*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_48mem0_17438)){
        poke4_addr = (unsigned long *)_48mem0_17438;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_48mem0_17438)->dbl);
    }
    *poke4_addr = (unsigned long)0;

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at653_18794);
    _1 = (int)SEQ_PTR(_48memseq_17673);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at653_18794 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_48current_db_17396, _put4_1__tmp_at653_18794); // DJP 

    /** end procedure*/
    goto L11; // [674] 677
L11: 
    DeRefi(_put4_1__tmp_at653_18794);
    _put4_1__tmp_at653_18794 = NOVALUE;

    /** 	put4(1)  -- start with 1 block of records in index*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_48mem0_17438)){
        poke4_addr = (unsigned long *)_48mem0_17438;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_48mem0_17438)->dbl);
    }
    *poke4_addr = (unsigned long)1;

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at681_18796);
    _1 = (int)SEQ_PTR(_48memseq_17673);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at681_18796 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_48current_db_17396, _put4_1__tmp_at681_18796); // DJP 

    /** end procedure*/
    goto L12; // [702] 705
L12: 
    DeRefi(_put4_1__tmp_at681_18796);
    _put4_1__tmp_at681_18796 = NOVALUE;

    /** 	put4(index_ptr)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_48mem0_17438)){
        poke4_addr = (unsigned long *)_48mem0_17438;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_48mem0_17438)->dbl);
    }
    if (IS_ATOM_INT(_index_ptr_18692)) {
        *poke4_addr = (unsigned long)_index_ptr_18692;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_index_ptr_18692)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at709_18798);
    _1 = (int)SEQ_PTR(_48memseq_17673);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at709_18798 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_48current_db_17396, _put4_1__tmp_at709_18798); // DJP 

    /** end procedure*/
    goto L13; // [730] 733
L13: 
    DeRefi(_put4_1__tmp_at709_18798);
    _put4_1__tmp_at709_18798 = NOVALUE;

    /** 	if db_select_table(name) then*/
    RefDS(_name_18682);
    _10548 = _48db_select_table(_name_18682);
    if (_10548 == 0) {
        DeRef(_10548);
        _10548 = NOVALUE;
        goto L14; // [741] 745
    }
    else {
        if (!IS_ATOM_INT(_10548) && DBL_PTR(_10548)->dbl == 0.0){
            DeRef(_10548);
            _10548 = NOVALUE;
            goto L14; // [741] 745
        }
        DeRef(_10548);
        _10548 = NOVALUE;
    }
    DeRef(_10548);
    _10548 = NOVALUE;
L14: 

    /** 	return DB_OK*/
    DeRefDS(_name_18682);
    DeRef(_name_ptr_18684);
    DeRef(_nt_18685);
    DeRef(_tables_18686);
    DeRef(_newtables_18687);
    DeRef(_table_18688);
    DeRef(_records_ptr_18689);
    DeRef(_size_18690);
    DeRef(_newsize_18691);
    DeRef(_index_ptr_18692);
    DeRef(_remaining_18693);
    return 0;
    ;
}


int _48db_table_list()
{
    int _seek_1__tmp_at120_19057 = NOVALUE;
    int _seek_inlined_seek_at_120_19056 = NOVALUE;
    int _seek_1__tmp_at98_19053 = NOVALUE;
    int _seek_inlined_seek_at_98_19052 = NOVALUE;
    int _pos_inlined_seek_at_95_19051 = NOVALUE;
    int _seek_1__tmp_at42_19041 = NOVALUE;
    int _seek_inlined_seek_at_42_19040 = NOVALUE;
    int _seek_1__tmp_at4_19034 = NOVALUE;
    int _seek_inlined_seek_at_4_19033 = NOVALUE;
    int _table_names_19028 = NOVALUE;
    int _tables_19029 = NOVALUE;
    int _nt_19030 = NOVALUE;
    int _name_19031 = NOVALUE;
    int _10647 = NOVALUE;
    int _10646 = NOVALUE;
    int _10644 = NOVALUE;
    int _10643 = NOVALUE;
    int _10642 = NOVALUE;
    int _10641 = NOVALUE;
    int _10636 = NOVALUE;
    int _0, _1, _2;
    

    /** 	io:seek(current_db, TABLE_HEADERS)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at4_19034);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _48current_db_17396;
    ((int *)_2)[2] = 3;
    _seek_1__tmp_at4_19034 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_4_19033 = machine(19, _seek_1__tmp_at4_19034);
    DeRefi(_seek_1__tmp_at4_19034);
    _seek_1__tmp_at4_19034 = NOVALUE;

    /** 	if length(vLastErrors) > 0 then return {} end if*/
    if (IS_SEQUENCE(_48vLastErrors_17420)){
            _10636 = SEQ_PTR(_48vLastErrors_17420)->length;
    }
    else {
        _10636 = 1;
    }
    if (_10636 <= 0)
    goto L1; // [25] 34
    RefDS(_5);
    DeRef(_table_names_19028);
    DeRef(_tables_19029);
    DeRef(_nt_19030);
    DeRef(_name_19031);
    return _5;
L1: 

    /** 	tables = get4()*/
    _0 = _tables_19029;
    _tables_19029 = _48get4();
    DeRef(_0);

    /** 	io:seek(current_db, tables)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_tables_19029);
    DeRef(_seek_1__tmp_at42_19041);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _48current_db_17396;
    ((int *)_2)[2] = _tables_19029;
    _seek_1__tmp_at42_19041 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_42_19040 = machine(19, _seek_1__tmp_at42_19041);
    DeRef(_seek_1__tmp_at42_19041);
    _seek_1__tmp_at42_19041 = NOVALUE;

    /** 	nt = get4()*/
    _0 = _nt_19030;
    _nt_19030 = _48get4();
    DeRef(_0);

    /** 	table_names = repeat(0, nt)*/
    DeRef(_table_names_19028);
    _table_names_19028 = Repeat(0, _nt_19030);

    /** 	for i = 0 to nt-1 do*/
    if (IS_ATOM_INT(_nt_19030)) {
        _10641 = _nt_19030 - 1;
        if ((long)((unsigned long)_10641 +(unsigned long) HIGH_BITS) >= 0){
            _10641 = NewDouble((double)_10641);
        }
    }
    else {
        _10641 = NewDouble(DBL_PTR(_nt_19030)->dbl - (double)1);
    }
    {
        int _i_19045;
        _i_19045 = 0;
L2: 
        if (binary_op_a(GREATER, _i_19045, _10641)){
            goto L3; // [73] 154
        }

        /** 		io:seek(current_db, tables + 4 + i*SIZEOF_TABLE_HEADER)*/
        if (IS_ATOM_INT(_tables_19029)) {
            _10642 = _tables_19029 + 4;
            if ((long)((unsigned long)_10642 + (unsigned long)HIGH_BITS) >= 0) 
            _10642 = NewDouble((double)_10642);
        }
        else {
            _10642 = NewDouble(DBL_PTR(_tables_19029)->dbl + (double)4);
        }
        if (IS_ATOM_INT(_i_19045)) {
            if (_i_19045 == (short)_i_19045)
            _10643 = _i_19045 * 16;
            else
            _10643 = NewDouble(_i_19045 * (double)16);
        }
        else {
            _10643 = NewDouble(DBL_PTR(_i_19045)->dbl * (double)16);
        }
        if (IS_ATOM_INT(_10642) && IS_ATOM_INT(_10643)) {
            _10644 = _10642 + _10643;
            if ((long)((unsigned long)_10644 + (unsigned long)HIGH_BITS) >= 0) 
            _10644 = NewDouble((double)_10644);
        }
        else {
            if (IS_ATOM_INT(_10642)) {
                _10644 = NewDouble((double)_10642 + DBL_PTR(_10643)->dbl);
            }
            else {
                if (IS_ATOM_INT(_10643)) {
                    _10644 = NewDouble(DBL_PTR(_10642)->dbl + (double)_10643);
                }
                else
                _10644 = NewDouble(DBL_PTR(_10642)->dbl + DBL_PTR(_10643)->dbl);
            }
        }
        DeRef(_10642);
        _10642 = NOVALUE;
        DeRef(_10643);
        _10643 = NOVALUE;
        DeRef(_pos_inlined_seek_at_95_19051);
        _pos_inlined_seek_at_95_19051 = _10644;
        _10644 = NOVALUE;

        /** 	return machine_func(M_SEEK, {fn, pos})*/
        Ref(_pos_inlined_seek_at_95_19051);
        DeRef(_seek_1__tmp_at98_19053);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _48current_db_17396;
        ((int *)_2)[2] = _pos_inlined_seek_at_95_19051;
        _seek_1__tmp_at98_19053 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_98_19052 = machine(19, _seek_1__tmp_at98_19053);
        DeRef(_pos_inlined_seek_at_95_19051);
        _pos_inlined_seek_at_95_19051 = NOVALUE;
        DeRef(_seek_1__tmp_at98_19053);
        _seek_1__tmp_at98_19053 = NOVALUE;

        /** 		name = get4()*/
        _0 = _name_19031;
        _name_19031 = _48get4();
        DeRef(_0);

        /** 		io:seek(current_db, name)*/

        /** 	return machine_func(M_SEEK, {fn, pos})*/
        Ref(_name_19031);
        DeRef(_seek_1__tmp_at120_19057);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _48current_db_17396;
        ((int *)_2)[2] = _name_19031;
        _seek_1__tmp_at120_19057 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_120_19056 = machine(19, _seek_1__tmp_at120_19057);
        DeRef(_seek_1__tmp_at120_19057);
        _seek_1__tmp_at120_19057 = NOVALUE;

        /** 		table_names[i+1] = get_string()*/
        if (IS_ATOM_INT(_i_19045)) {
            _10646 = _i_19045 + 1;
            if (_10646 > MAXINT){
                _10646 = NewDouble((double)_10646);
            }
        }
        else
        _10646 = binary_op(PLUS, 1, _i_19045);
        _10647 = _48get_string();
        _2 = (int)SEQ_PTR(_table_names_19028);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _table_names_19028 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_10646))
        _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_10646)->dbl));
        else
        _2 = (int)(((s1_ptr)_2)->base + _10646);
        _1 = *(int *)_2;
        *(int *)_2 = _10647;
        if( _1 != _10647 ){
            DeRef(_1);
        }
        _10647 = NOVALUE;

        /** 	end for*/
        _0 = _i_19045;
        if (IS_ATOM_INT(_i_19045)) {
            _i_19045 = _i_19045 + 1;
            if ((long)((unsigned long)_i_19045 +(unsigned long) HIGH_BITS) >= 0){
                _i_19045 = NewDouble((double)_i_19045);
            }
        }
        else {
            _i_19045 = binary_op_a(PLUS, _i_19045, 1);
        }
        DeRef(_0);
        goto L2; // [149] 80
L3: 
        ;
        DeRef(_i_19045);
    }

    /** 	return table_names*/
    DeRef(_tables_19029);
    DeRef(_nt_19030);
    DeRef(_name_19031);
    DeRef(_10641);
    _10641 = NOVALUE;
    DeRef(_10646);
    _10646 = NOVALUE;
    return _table_names_19028;
    ;
}


int _48key_value(int _ptr_19062)
{
    int _seek_1__tmp_at11_19067 = NOVALUE;
    int _seek_inlined_seek_at_11_19066 = NOVALUE;
    int _pos_inlined_seek_at_8_19065 = NOVALUE;
    int _10649 = NOVALUE;
    int _10648 = NOVALUE;
    int _0, _1, _2;
    

    /** 	io:seek(current_db, ptr+4) -- skip ptr to data*/
    if (IS_ATOM_INT(_ptr_19062)) {
        _10648 = _ptr_19062 + 4;
        if ((long)((unsigned long)_10648 + (unsigned long)HIGH_BITS) >= 0) 
        _10648 = NewDouble((double)_10648);
    }
    else {
        _10648 = NewDouble(DBL_PTR(_ptr_19062)->dbl + (double)4);
    }
    DeRef(_pos_inlined_seek_at_8_19065);
    _pos_inlined_seek_at_8_19065 = _10648;
    _10648 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_8_19065);
    DeRef(_seek_1__tmp_at11_19067);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _48current_db_17396;
    ((int *)_2)[2] = _pos_inlined_seek_at_8_19065;
    _seek_1__tmp_at11_19067 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_11_19066 = machine(19, _seek_1__tmp_at11_19067);
    DeRef(_pos_inlined_seek_at_8_19065);
    _pos_inlined_seek_at_8_19065 = NOVALUE;
    DeRef(_seek_1__tmp_at11_19067);
    _seek_1__tmp_at11_19067 = NOVALUE;

    /** 	return decompress(0)*/
    _10649 = _48decompress(0);
    DeRef(_ptr_19062);
    return _10649;
    ;
}


int _48db_find_key(int _key_19071, int _table_name_19072)
{
    int _lo_19073 = NOVALUE;
    int _hi_19074 = NOVALUE;
    int _mid_19075 = NOVALUE;
    int _c_19076 = NOVALUE;
    int _10673 = NOVALUE;
    int _10665 = NOVALUE;
    int _10664 = NOVALUE;
    int _10662 = NOVALUE;
    int _10659 = NOVALUE;
    int _10656 = NOVALUE;
    int _10652 = NOVALUE;
    int _10650 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not equal(table_name, current_table_name) then*/
    if (_table_name_19072 == _48current_table_name_17398)
    _10650 = 1;
    else if (IS_ATOM_INT(_table_name_19072) && IS_ATOM_INT(_48current_table_name_17398))
    _10650 = 0;
    else
    _10650 = (compare(_table_name_19072, _48current_table_name_17398) == 0);
    if (_10650 != 0)
    goto L1; // [9] 42
    _10650 = NOVALUE;

    /** 		if db_select_table(table_name) != DB_OK then*/
    RefDS(_table_name_19072);
    _10652 = _48db_select_table(_table_name_19072);
    if (binary_op_a(EQUALS, _10652, 0)){
        DeRef(_10652);
        _10652 = NOVALUE;
        goto L2; // [18] 41
    }
    DeRef(_10652);
    _10652 = NOVALUE;

    /** 			fatal(NO_TABLE, "invalid table name given", "db_find_key", {key, table_name})*/
    RefDS(_table_name_19072);
    Ref(_key_19071);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _key_19071;
    ((int *)_2)[2] = _table_name_19072;
    _10656 = MAKE_SEQ(_1);
    RefDS(_10654);
    RefDS(_10655);
    _48fatal(903, _10654, _10655, _10656);
    _10656 = NOVALUE;

    /** 			return 0*/
    DeRef(_key_19071);
    DeRefDS(_table_name_19072);
    return 0;
L2: 
L1: 

    /** 	if current_table_pos = -1 then*/
    if (binary_op_a(NOTEQ, _48current_table_pos_17397, -1)){
        goto L3; // [46] 69
    }

    /** 		fatal(NO_TABLE, "no table selected", "db_find_key", {key, table_name})*/
    Ref(_table_name_19072);
    Ref(_key_19071);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _key_19071;
    ((int *)_2)[2] = _table_name_19072;
    _10659 = MAKE_SEQ(_1);
    RefDS(_10658);
    RefDS(_10655);
    _48fatal(903, _10658, _10655, _10659);
    _10659 = NOVALUE;

    /** 		return 0*/
    DeRef(_key_19071);
    DeRef(_table_name_19072);
    return 0;
L3: 

    /** 	lo = 1*/
    _lo_19073 = 1;

    /** 	hi = length(key_pointers)*/
    if (IS_SEQUENCE(_48key_pointers_17403)){
            _hi_19074 = SEQ_PTR(_48key_pointers_17403)->length;
    }
    else {
        _hi_19074 = 1;
    }

    /** 	mid = 1*/
    _mid_19075 = 1;

    /** 	c = 0*/
    _c_19076 = 0;

    /** 	while lo <= hi do*/
L4: 
    if (_lo_19073 > _hi_19074)
    goto L5; // [96] 170

    /** 		mid = floor((lo + hi) / 2)*/
    _10662 = _lo_19073 + _hi_19074;
    if ((long)((unsigned long)_10662 + (unsigned long)HIGH_BITS) >= 0) 
    _10662 = NewDouble((double)_10662);
    if (IS_ATOM_INT(_10662)) {
        _mid_19075 = _10662 >> 1;
    }
    else {
        _1 = binary_op(DIVIDE, _10662, 2);
        _mid_19075 = unary_op(FLOOR, _1);
        DeRef(_1);
    }
    DeRef(_10662);
    _10662 = NOVALUE;
    if (!IS_ATOM_INT(_mid_19075)) {
        _1 = (long)(DBL_PTR(_mid_19075)->dbl);
        DeRefDS(_mid_19075);
        _mid_19075 = _1;
    }

    /** 		c = eu:compare(key, key_value(key_pointers[mid]))*/
    _2 = (int)SEQ_PTR(_48key_pointers_17403);
    _10664 = (int)*(((s1_ptr)_2)->base + _mid_19075);
    Ref(_10664);
    _10665 = _48key_value(_10664);
    _10664 = NOVALUE;
    if (IS_ATOM_INT(_key_19071) && IS_ATOM_INT(_10665)){
        _c_19076 = (_key_19071 < _10665) ? -1 : (_key_19071 > _10665);
    }
    else{
        _c_19076 = compare(_key_19071, _10665);
    }
    DeRef(_10665);
    _10665 = NOVALUE;

    /** 		if c < 0 then*/
    if (_c_19076 >= 0)
    goto L6; // [130] 143

    /** 			hi = mid - 1*/
    _hi_19074 = _mid_19075 - 1;
    goto L4; // [140] 96
L6: 

    /** 		elsif c > 0 then*/
    if (_c_19076 <= 0)
    goto L7; // [145] 158

    /** 			lo = mid + 1*/
    _lo_19073 = _mid_19075 + 1;
    goto L4; // [155] 96
L7: 

    /** 			return mid*/
    DeRef(_key_19071);
    DeRef(_table_name_19072);
    return _mid_19075;

    /** 	end while*/
    goto L4; // [167] 96
L5: 

    /** 	if c > 0 then*/
    if (_c_19076 <= 0)
    goto L8; // [172] 183

    /** 		mid += 1*/
    _mid_19075 = _mid_19075 + 1;
L8: 

    /** 	return -mid*/
    if ((unsigned long)_mid_19075 == 0xC0000000)
    _10673 = (int)NewDouble((double)-0xC0000000);
    else
    _10673 = - _mid_19075;
    DeRef(_key_19071);
    DeRef(_table_name_19072);
    return _10673;
    ;
}


int _48db_insert(int _key_19111, int _data_19112, int _table_name_19113)
{
    int _key_string_19114 = NOVALUE;
    int _data_string_19115 = NOVALUE;
    int _last_part_19116 = NOVALUE;
    int _remaining_19117 = NOVALUE;
    int _key_ptr_19118 = NOVALUE;
    int _data_ptr_19119 = NOVALUE;
    int _records_ptr_19120 = NOVALUE;
    int _nrecs_19121 = NOVALUE;
    int _current_block_19122 = NOVALUE;
    int _size_19123 = NOVALUE;
    int _new_size_19124 = NOVALUE;
    int _key_location_19125 = NOVALUE;
    int _new_block_19126 = NOVALUE;
    int _index_ptr_19127 = NOVALUE;
    int _new_index_ptr_19128 = NOVALUE;
    int _total_recs_19129 = NOVALUE;
    int _r_19130 = NOVALUE;
    int _blocks_19131 = NOVALUE;
    int _new_recs_19132 = NOVALUE;
    int _n_19133 = NOVALUE;
    int _put4_1__tmp_at79_19147 = NOVALUE;
    int _seek_1__tmp_at132_19153 = NOVALUE;
    int _seek_inlined_seek_at_132_19152 = NOVALUE;
    int _pos_inlined_seek_at_129_19151 = NOVALUE;
    int _seek_1__tmp_at174_19161 = NOVALUE;
    int _seek_inlined_seek_at_174_19160 = NOVALUE;
    int _pos_inlined_seek_at_171_19159 = NOVALUE;
    int _put4_1__tmp_at189_19163 = NOVALUE;
    int _seek_1__tmp_at317_19181 = NOVALUE;
    int _seek_inlined_seek_at_317_19180 = NOVALUE;
    int _pos_inlined_seek_at_314_19179 = NOVALUE;
    int _seek_1__tmp_at339_19185 = NOVALUE;
    int _seek_inlined_seek_at_339_19184 = NOVALUE;
    int _where_inlined_where_at_404_19194 = NOVALUE;
    int _seek_1__tmp_at448_19204 = NOVALUE;
    int _seek_inlined_seek_at_448_19203 = NOVALUE;
    int _pos_inlined_seek_at_445_19202 = NOVALUE;
    int _put4_1__tmp_at493_19213 = NOVALUE;
    int _x_inlined_put4_at_490_19212 = NOVALUE;
    int _seek_1__tmp_at530_19216 = NOVALUE;
    int _seek_inlined_seek_at_530_19215 = NOVALUE;
    int _put4_1__tmp_at551_19219 = NOVALUE;
    int _seek_1__tmp_at588_19224 = NOVALUE;
    int _seek_inlined_seek_at_588_19223 = NOVALUE;
    int _pos_inlined_seek_at_585_19222 = NOVALUE;
    int _seek_1__tmp_at690_19249 = NOVALUE;
    int _seek_inlined_seek_at_690_19248 = NOVALUE;
    int _pos_inlined_seek_at_687_19247 = NOVALUE;
    int _s_inlined_putn_at_751_19258 = NOVALUE;
    int _seek_1__tmp_at774_19261 = NOVALUE;
    int _seek_inlined_seek_at_774_19260 = NOVALUE;
    int _put4_1__tmp_at796_19265 = NOVALUE;
    int _x_inlined_put4_at_793_19264 = NOVALUE;
    int _seek_1__tmp_at833_19270 = NOVALUE;
    int _seek_inlined_seek_at_833_19269 = NOVALUE;
    int _pos_inlined_seek_at_830_19268 = NOVALUE;
    int _seek_1__tmp_at884_19280 = NOVALUE;
    int _seek_inlined_seek_at_884_19279 = NOVALUE;
    int _pos_inlined_seek_at_881_19278 = NOVALUE;
    int _put4_1__tmp_at899_19282 = NOVALUE;
    int _put4_1__tmp_at927_19284 = NOVALUE;
    int _seek_1__tmp_at980_19290 = NOVALUE;
    int _seek_inlined_seek_at_980_19289 = NOVALUE;
    int _pos_inlined_seek_at_977_19288 = NOVALUE;
    int _put4_1__tmp_at1001_19293 = NOVALUE;
    int _seek_1__tmp_at1038_19298 = NOVALUE;
    int _seek_inlined_seek_at_1038_19297 = NOVALUE;
    int _pos_inlined_seek_at_1035_19296 = NOVALUE;
    int _s_inlined_putn_at_1136_19316 = NOVALUE;
    int _seek_1__tmp_at1173_19321 = NOVALUE;
    int _seek_inlined_seek_at_1173_19320 = NOVALUE;
    int _pos_inlined_seek_at_1170_19319 = NOVALUE;
    int _put4_1__tmp_at1188_19323 = NOVALUE;
    int _10769 = NOVALUE;
    int _10768 = NOVALUE;
    int _10767 = NOVALUE;
    int _10766 = NOVALUE;
    int _10763 = NOVALUE;
    int _10762 = NOVALUE;
    int _10760 = NOVALUE;
    int _10758 = NOVALUE;
    int _10757 = NOVALUE;
    int _10755 = NOVALUE;
    int _10754 = NOVALUE;
    int _10752 = NOVALUE;
    int _10751 = NOVALUE;
    int _10749 = NOVALUE;
    int _10748 = NOVALUE;
    int _10747 = NOVALUE;
    int _10746 = NOVALUE;
    int _10745 = NOVALUE;
    int _10744 = NOVALUE;
    int _10743 = NOVALUE;
    int _10742 = NOVALUE;
    int _10741 = NOVALUE;
    int _10738 = NOVALUE;
    int _10737 = NOVALUE;
    int _10736 = NOVALUE;
    int _10735 = NOVALUE;
    int _10732 = NOVALUE;
    int _10729 = NOVALUE;
    int _10728 = NOVALUE;
    int _10727 = NOVALUE;
    int _10726 = NOVALUE;
    int _10722 = NOVALUE;
    int _10721 = NOVALUE;
    int _10719 = NOVALUE;
    int _10718 = NOVALUE;
    int _10716 = NOVALUE;
    int _10715 = NOVALUE;
    int _10714 = NOVALUE;
    int _10713 = NOVALUE;
    int _10712 = NOVALUE;
    int _10711 = NOVALUE;
    int _10710 = NOVALUE;
    int _10708 = NOVALUE;
    int _10705 = NOVALUE;
    int _10700 = NOVALUE;
    int _10698 = NOVALUE;
    int _10697 = NOVALUE;
    int _10695 = NOVALUE;
    int _10694 = NOVALUE;
    int _10693 = NOVALUE;
    int _10690 = NOVALUE;
    int _10688 = NOVALUE;
    int _10685 = NOVALUE;
    int _10684 = NOVALUE;
    int _10682 = NOVALUE;
    int _10681 = NOVALUE;
    int _10679 = NOVALUE;
    int _0, _1, _2;
    

    /** 	key_location = db_find_key(key, table_name) -- Let it set the current table if necessary*/
    Ref(_key_19111);
    RefDS(_table_name_19113);
    _0 = _key_location_19125;
    _key_location_19125 = _48db_find_key(_key_19111, _table_name_19113);
    DeRef(_0);

    /** 	if key_location > 0 then*/
    if (binary_op_a(LESSEQ, _key_location_19125, 0)){
        goto L1; // [10] 21
    }

    /** 		return DB_EXISTS_ALREADY*/
    DeRef(_key_19111);
    DeRefDS(_table_name_19113);
    DeRef(_key_string_19114);
    DeRef(_data_string_19115);
    DeRef(_last_part_19116);
    DeRef(_remaining_19117);
    DeRef(_key_ptr_19118);
    DeRef(_data_ptr_19119);
    DeRef(_records_ptr_19120);
    DeRef(_nrecs_19121);
    DeRef(_current_block_19122);
    DeRef(_size_19123);
    DeRef(_new_size_19124);
    DeRef(_key_location_19125);
    DeRef(_new_block_19126);
    DeRef(_index_ptr_19127);
    DeRef(_new_index_ptr_19128);
    DeRef(_total_recs_19129);
    return -2;
L1: 

    /** 	key_location = -key_location*/
    _0 = _key_location_19125;
    if (IS_ATOM_INT(_key_location_19125)) {
        if ((unsigned long)_key_location_19125 == 0xC0000000)
        _key_location_19125 = (int)NewDouble((double)-0xC0000000);
        else
        _key_location_19125 = - _key_location_19125;
    }
    else {
        _key_location_19125 = unary_op(UMINUS, _key_location_19125);
    }
    DeRef(_0);

    /** 	data_string = compress(data)*/
    _0 = _data_string_19115;
    _data_string_19115 = _48compress(_data_19112);
    DeRef(_0);

    /** 	key_string  = compress(key)*/
    Ref(_key_19111);
    _0 = _key_string_19114;
    _key_string_19114 = _48compress(_key_19111);
    DeRef(_0);

    /** 	data_ptr = db_allocate(length(data_string))*/
    if (IS_SEQUENCE(_data_string_19115)){
            _10679 = SEQ_PTR(_data_string_19115)->length;
    }
    else {
        _10679 = 1;
    }
    _0 = _data_ptr_19119;
    _data_ptr_19119 = _48db_allocate(_10679);
    DeRef(_0);
    _10679 = NOVALUE;

    /** 	putn(data_string)*/

    /** 	puts(current_db, s)*/
    EPuts(_48current_db_17396, _data_string_19115); // DJP 

    /** end procedure*/
    goto L2; // [62] 65
L2: 

    /** 	key_ptr = db_allocate(4+length(key_string))*/
    if (IS_SEQUENCE(_key_string_19114)){
            _10681 = SEQ_PTR(_key_string_19114)->length;
    }
    else {
        _10681 = 1;
    }
    _10682 = 4 + _10681;
    _10681 = NOVALUE;
    _0 = _key_ptr_19118;
    _key_ptr_19118 = _48db_allocate(_10682);
    DeRef(_0);
    _10682 = NOVALUE;

    /** 	put4(data_ptr)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_48mem0_17438)){
        poke4_addr = (unsigned long *)_48mem0_17438;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_48mem0_17438)->dbl);
    }
    if (IS_ATOM_INT(_data_ptr_19119)) {
        *poke4_addr = (unsigned long)_data_ptr_19119;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_data_ptr_19119)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at79_19147);
    _1 = (int)SEQ_PTR(_48memseq_17673);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at79_19147 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_48current_db_17396, _put4_1__tmp_at79_19147); // DJP 

    /** end procedure*/
    goto L3; // [101] 104
L3: 
    DeRefi(_put4_1__tmp_at79_19147);
    _put4_1__tmp_at79_19147 = NOVALUE;

    /** 	putn(key_string)*/

    /** 	puts(current_db, s)*/
    EPuts(_48current_db_17396, _key_string_19114); // DJP 

    /** end procedure*/
    goto L4; // [117] 120
L4: 

    /** 	io:seek(current_db, current_table_pos+4)*/
    if (IS_ATOM_INT(_48current_table_pos_17397)) {
        _10684 = _48current_table_pos_17397 + 4;
        if ((long)((unsigned long)_10684 + (unsigned long)HIGH_BITS) >= 0) 
        _10684 = NewDouble((double)_10684);
    }
    else {
        _10684 = NewDouble(DBL_PTR(_48current_table_pos_17397)->dbl + (double)4);
    }
    DeRef(_pos_inlined_seek_at_129_19151);
    _pos_inlined_seek_at_129_19151 = _10684;
    _10684 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_129_19151);
    DeRef(_seek_1__tmp_at132_19153);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _48current_db_17396;
    ((int *)_2)[2] = _pos_inlined_seek_at_129_19151;
    _seek_1__tmp_at132_19153 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_132_19152 = machine(19, _seek_1__tmp_at132_19153);
    DeRef(_pos_inlined_seek_at_129_19151);
    _pos_inlined_seek_at_129_19151 = NOVALUE;
    DeRef(_seek_1__tmp_at132_19153);
    _seek_1__tmp_at132_19153 = NOVALUE;

    /** 	total_recs = get4()+1*/
    _10685 = _48get4();
    DeRef(_total_recs_19129);
    if (IS_ATOM_INT(_10685)) {
        _total_recs_19129 = _10685 + 1;
        if (_total_recs_19129 > MAXINT){
            _total_recs_19129 = NewDouble((double)_total_recs_19129);
        }
    }
    else
    _total_recs_19129 = binary_op(PLUS, 1, _10685);
    DeRef(_10685);
    _10685 = NOVALUE;

    /** 	blocks = get4()*/
    _blocks_19131 = _48get4();
    if (!IS_ATOM_INT(_blocks_19131)) {
        _1 = (long)(DBL_PTR(_blocks_19131)->dbl);
        DeRefDS(_blocks_19131);
        _blocks_19131 = _1;
    }

    /** 	io:seek(current_db, current_table_pos+4)*/
    if (IS_ATOM_INT(_48current_table_pos_17397)) {
        _10688 = _48current_table_pos_17397 + 4;
        if ((long)((unsigned long)_10688 + (unsigned long)HIGH_BITS) >= 0) 
        _10688 = NewDouble((double)_10688);
    }
    else {
        _10688 = NewDouble(DBL_PTR(_48current_table_pos_17397)->dbl + (double)4);
    }
    DeRef(_pos_inlined_seek_at_171_19159);
    _pos_inlined_seek_at_171_19159 = _10688;
    _10688 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_171_19159);
    DeRef(_seek_1__tmp_at174_19161);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _48current_db_17396;
    ((int *)_2)[2] = _pos_inlined_seek_at_171_19159;
    _seek_1__tmp_at174_19161 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_174_19160 = machine(19, _seek_1__tmp_at174_19161);
    DeRef(_pos_inlined_seek_at_171_19159);
    _pos_inlined_seek_at_171_19159 = NOVALUE;
    DeRef(_seek_1__tmp_at174_19161);
    _seek_1__tmp_at174_19161 = NOVALUE;

    /** 	put4(total_recs)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_48mem0_17438)){
        poke4_addr = (unsigned long *)_48mem0_17438;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_48mem0_17438)->dbl);
    }
    if (IS_ATOM_INT(_total_recs_19129)) {
        *poke4_addr = (unsigned long)_total_recs_19129;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_total_recs_19129)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at189_19163);
    _1 = (int)SEQ_PTR(_48memseq_17673);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at189_19163 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_48current_db_17396, _put4_1__tmp_at189_19163); // DJP 

    /** end procedure*/
    goto L5; // [211] 214
L5: 
    DeRefi(_put4_1__tmp_at189_19163);
    _put4_1__tmp_at189_19163 = NOVALUE;

    /** 	n = length(key_pointers)*/
    if (IS_SEQUENCE(_48key_pointers_17403)){
            _n_19133 = SEQ_PTR(_48key_pointers_17403)->length;
    }
    else {
        _n_19133 = 1;
    }

    /** 	if key_location >= floor(n/2) then*/
    _10690 = _n_19133 >> 1;
    if (binary_op_a(LESS, _key_location_19125, _10690)){
        _10690 = NOVALUE;
        goto L6; // [229] 268
    }
    DeRef(_10690);
    _10690 = NOVALUE;

    /** 		key_pointers = append(key_pointers, 0)*/
    Append(&_48key_pointers_17403, _48key_pointers_17403, 0);

    /** 		key_pointers[key_location+1..n+1] = key_pointers[key_location..n]*/
    if (IS_ATOM_INT(_key_location_19125)) {
        _10693 = _key_location_19125 + 1;
        if (_10693 > MAXINT){
            _10693 = NewDouble((double)_10693);
        }
    }
    else
    _10693 = binary_op(PLUS, 1, _key_location_19125);
    _10694 = _n_19133 + 1;
    rhs_slice_target = (object_ptr)&_10695;
    RHS_Slice(_48key_pointers_17403, _key_location_19125, _n_19133);
    assign_slice_seq = (s1_ptr *)&_48key_pointers_17403;
    AssignSlice(_10693, _10694, _10695);
    DeRef(_10693);
    _10693 = NOVALUE;
    _10694 = NOVALUE;
    DeRefDS(_10695);
    _10695 = NOVALUE;
    goto L7; // [265] 297
L6: 

    /** 		key_pointers = prepend(key_pointers, 0)*/
    Prepend(&_48key_pointers_17403, _48key_pointers_17403, 0);

    /** 		key_pointers[1..key_location-1] = key_pointers[2..key_location]*/
    if (IS_ATOM_INT(_key_location_19125)) {
        _10697 = _key_location_19125 - 1;
        if ((long)((unsigned long)_10697 +(unsigned long) HIGH_BITS) >= 0){
            _10697 = NewDouble((double)_10697);
        }
    }
    else {
        _10697 = NewDouble(DBL_PTR(_key_location_19125)->dbl - (double)1);
    }
    rhs_slice_target = (object_ptr)&_10698;
    RHS_Slice(_48key_pointers_17403, 2, _key_location_19125);
    assign_slice_seq = (s1_ptr *)&_48key_pointers_17403;
    AssignSlice(1, _10697, _10698);
    DeRef(_10697);
    _10697 = NOVALUE;
    DeRefDS(_10698);
    _10698 = NOVALUE;
L7: 

    /** 	key_pointers[key_location] = key_ptr*/
    Ref(_key_ptr_19118);
    _2 = (int)SEQ_PTR(_48key_pointers_17403);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _48key_pointers_17403 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_key_location_19125))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_key_location_19125)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _key_location_19125);
    _1 = *(int *)_2;
    *(int *)_2 = _key_ptr_19118;
    DeRef(_1);

    /** 	io:seek(current_db, current_table_pos+12) -- get after put - seek is necessary*/
    if (IS_ATOM_INT(_48current_table_pos_17397)) {
        _10700 = _48current_table_pos_17397 + 12;
        if ((long)((unsigned long)_10700 + (unsigned long)HIGH_BITS) >= 0) 
        _10700 = NewDouble((double)_10700);
    }
    else {
        _10700 = NewDouble(DBL_PTR(_48current_table_pos_17397)->dbl + (double)12);
    }
    DeRef(_pos_inlined_seek_at_314_19179);
    _pos_inlined_seek_at_314_19179 = _10700;
    _10700 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_314_19179);
    DeRef(_seek_1__tmp_at317_19181);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _48current_db_17396;
    ((int *)_2)[2] = _pos_inlined_seek_at_314_19179;
    _seek_1__tmp_at317_19181 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_317_19180 = machine(19, _seek_1__tmp_at317_19181);
    DeRef(_pos_inlined_seek_at_314_19179);
    _pos_inlined_seek_at_314_19179 = NOVALUE;
    DeRef(_seek_1__tmp_at317_19181);
    _seek_1__tmp_at317_19181 = NOVALUE;

    /** 	index_ptr = get4()*/
    _0 = _index_ptr_19127;
    _index_ptr_19127 = _48get4();
    DeRef(_0);

    /** 	io:seek(current_db, index_ptr)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_index_ptr_19127);
    DeRef(_seek_1__tmp_at339_19185);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _48current_db_17396;
    ((int *)_2)[2] = _index_ptr_19127;
    _seek_1__tmp_at339_19185 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_339_19184 = machine(19, _seek_1__tmp_at339_19185);
    DeRef(_seek_1__tmp_at339_19185);
    _seek_1__tmp_at339_19185 = NOVALUE;

    /** 	r = 0*/
    _r_19130 = 0;

    /** 	while TRUE do*/
L8: 

    /** 		nrecs = get4()*/
    _0 = _nrecs_19121;
    _nrecs_19121 = _48get4();
    DeRef(_0);

    /** 		records_ptr = get4()*/
    _0 = _records_ptr_19120;
    _records_ptr_19120 = _48get4();
    DeRef(_0);

    /** 		r += nrecs*/
    if (IS_ATOM_INT(_nrecs_19121)) {
        _r_19130 = _r_19130 + _nrecs_19121;
    }
    else {
        _r_19130 = NewDouble((double)_r_19130 + DBL_PTR(_nrecs_19121)->dbl);
    }
    if (!IS_ATOM_INT(_r_19130)) {
        _1 = (long)(DBL_PTR(_r_19130)->dbl);
        DeRefDS(_r_19130);
        _r_19130 = _1;
    }

    /** 		if r + 1 >= key_location then*/
    _10705 = _r_19130 + 1;
    if (_10705 > MAXINT){
        _10705 = NewDouble((double)_10705);
    }
    if (binary_op_a(LESS, _10705, _key_location_19125)){
        DeRef(_10705);
        _10705 = NOVALUE;
        goto L8; // [387] 363
    }
    DeRef(_10705);
    _10705 = NOVALUE;

    /** 			exit*/
    goto L9; // [393] 401

    /** 	end while*/
    goto L8; // [398] 363
L9: 

    /** 	current_block = io:where(current_db)-8*/

    /** 	return machine_func(M_WHERE, fn)*/
    DeRef(_where_inlined_where_at_404_19194);
    _where_inlined_where_at_404_19194 = machine(20, _48current_db_17396);
    DeRef(_current_block_19122);
    if (IS_ATOM_INT(_where_inlined_where_at_404_19194)) {
        _current_block_19122 = _where_inlined_where_at_404_19194 - 8;
        if ((long)((unsigned long)_current_block_19122 +(unsigned long) HIGH_BITS) >= 0){
            _current_block_19122 = NewDouble((double)_current_block_19122);
        }
    }
    else {
        _current_block_19122 = NewDouble(DBL_PTR(_where_inlined_where_at_404_19194)->dbl - (double)8);
    }

    /** 	key_location -= (r-nrecs)*/
    if (IS_ATOM_INT(_nrecs_19121)) {
        _10708 = _r_19130 - _nrecs_19121;
        if ((long)((unsigned long)_10708 +(unsigned long) HIGH_BITS) >= 0){
            _10708 = NewDouble((double)_10708);
        }
    }
    else {
        _10708 = NewDouble((double)_r_19130 - DBL_PTR(_nrecs_19121)->dbl);
    }
    _0 = _key_location_19125;
    if (IS_ATOM_INT(_key_location_19125) && IS_ATOM_INT(_10708)) {
        _key_location_19125 = _key_location_19125 - _10708;
        if ((long)((unsigned long)_key_location_19125 +(unsigned long) HIGH_BITS) >= 0){
            _key_location_19125 = NewDouble((double)_key_location_19125);
        }
    }
    else {
        if (IS_ATOM_INT(_key_location_19125)) {
            _key_location_19125 = NewDouble((double)_key_location_19125 - DBL_PTR(_10708)->dbl);
        }
        else {
            if (IS_ATOM_INT(_10708)) {
                _key_location_19125 = NewDouble(DBL_PTR(_key_location_19125)->dbl - (double)_10708);
            }
            else
            _key_location_19125 = NewDouble(DBL_PTR(_key_location_19125)->dbl - DBL_PTR(_10708)->dbl);
        }
    }
    DeRef(_0);
    DeRef(_10708);
    _10708 = NOVALUE;

    /** 	io:seek(current_db, records_ptr+4*(key_location-1))*/
    if (IS_ATOM_INT(_key_location_19125)) {
        _10710 = _key_location_19125 - 1;
        if ((long)((unsigned long)_10710 +(unsigned long) HIGH_BITS) >= 0){
            _10710 = NewDouble((double)_10710);
        }
    }
    else {
        _10710 = NewDouble(DBL_PTR(_key_location_19125)->dbl - (double)1);
    }
    if (IS_ATOM_INT(_10710)) {
        if (_10710 <= INT15 && _10710 >= -INT15)
        _10711 = 4 * _10710;
        else
        _10711 = NewDouble(4 * (double)_10710);
    }
    else {
        _10711 = NewDouble((double)4 * DBL_PTR(_10710)->dbl);
    }
    DeRef(_10710);
    _10710 = NOVALUE;
    if (IS_ATOM_INT(_records_ptr_19120) && IS_ATOM_INT(_10711)) {
        _10712 = _records_ptr_19120 + _10711;
        if ((long)((unsigned long)_10712 + (unsigned long)HIGH_BITS) >= 0) 
        _10712 = NewDouble((double)_10712);
    }
    else {
        if (IS_ATOM_INT(_records_ptr_19120)) {
            _10712 = NewDouble((double)_records_ptr_19120 + DBL_PTR(_10711)->dbl);
        }
        else {
            if (IS_ATOM_INT(_10711)) {
                _10712 = NewDouble(DBL_PTR(_records_ptr_19120)->dbl + (double)_10711);
            }
            else
            _10712 = NewDouble(DBL_PTR(_records_ptr_19120)->dbl + DBL_PTR(_10711)->dbl);
        }
    }
    DeRef(_10711);
    _10711 = NOVALUE;
    DeRef(_pos_inlined_seek_at_445_19202);
    _pos_inlined_seek_at_445_19202 = _10712;
    _10712 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_445_19202);
    DeRef(_seek_1__tmp_at448_19204);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _48current_db_17396;
    ((int *)_2)[2] = _pos_inlined_seek_at_445_19202;
    _seek_1__tmp_at448_19204 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_448_19203 = machine(19, _seek_1__tmp_at448_19204);
    DeRef(_pos_inlined_seek_at_445_19202);
    _pos_inlined_seek_at_445_19202 = NOVALUE;
    DeRef(_seek_1__tmp_at448_19204);
    _seek_1__tmp_at448_19204 = NOVALUE;

    /** 	for i = key_location to nrecs+1 do*/
    if (IS_ATOM_INT(_nrecs_19121)) {
        _10713 = _nrecs_19121 + 1;
        if (_10713 > MAXINT){
            _10713 = NewDouble((double)_10713);
        }
    }
    else
    _10713 = binary_op(PLUS, 1, _nrecs_19121);
    {
        int _i_19206;
        Ref(_key_location_19125);
        _i_19206 = _key_location_19125;
LA: 
        if (binary_op_a(GREATER, _i_19206, _10713)){
            goto LB; // [468] 527
        }

        /** 		put4(key_pointers[i+r-nrecs])*/
        if (IS_ATOM_INT(_i_19206)) {
            _10714 = _i_19206 + _r_19130;
            if ((long)((unsigned long)_10714 + (unsigned long)HIGH_BITS) >= 0) 
            _10714 = NewDouble((double)_10714);
        }
        else {
            _10714 = NewDouble(DBL_PTR(_i_19206)->dbl + (double)_r_19130);
        }
        if (IS_ATOM_INT(_10714) && IS_ATOM_INT(_nrecs_19121)) {
            _10715 = _10714 - _nrecs_19121;
        }
        else {
            if (IS_ATOM_INT(_10714)) {
                _10715 = NewDouble((double)_10714 - DBL_PTR(_nrecs_19121)->dbl);
            }
            else {
                if (IS_ATOM_INT(_nrecs_19121)) {
                    _10715 = NewDouble(DBL_PTR(_10714)->dbl - (double)_nrecs_19121);
                }
                else
                _10715 = NewDouble(DBL_PTR(_10714)->dbl - DBL_PTR(_nrecs_19121)->dbl);
            }
        }
        DeRef(_10714);
        _10714 = NOVALUE;
        _2 = (int)SEQ_PTR(_48key_pointers_17403);
        if (!IS_ATOM_INT(_10715)){
            _10716 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_10715)->dbl));
        }
        else{
            _10716 = (int)*(((s1_ptr)_2)->base + _10715);
        }
        Ref(_10716);
        DeRef(_x_inlined_put4_at_490_19212);
        _x_inlined_put4_at_490_19212 = _10716;
        _10716 = NOVALUE;

        /** 	poke4(mem0, x) -- faster than doing divides etc.*/
        if (IS_ATOM_INT(_48mem0_17438)){
            poke4_addr = (unsigned long *)_48mem0_17438;
        }
        else {
            poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_48mem0_17438)->dbl);
        }
        if (IS_ATOM_INT(_x_inlined_put4_at_490_19212)) {
            *poke4_addr = (unsigned long)_x_inlined_put4_at_490_19212;
        }
        else if (IS_ATOM(_x_inlined_put4_at_490_19212)) {
            *poke4_addr = (unsigned long)DBL_PTR(_x_inlined_put4_at_490_19212)->dbl;
        }
        else {
            _1 = (int)SEQ_PTR(_x_inlined_put4_at_490_19212);
            _1 = (int)((s1_ptr)_1)->base;
            while (1) {
                _1 += 4;
                _2 = *((int *)_1);
                if (IS_ATOM_INT(_2))
                *(int *)poke4_addr++ = (unsigned long)_2;
                else if (_2 == NOVALUE)
                break;
                else {
                    *(int *)poke4_addr++ = (unsigned long)DBL_PTR(_2)->dbl;
                }
            }
        }

        /** 	puts(current_db, peek(memseq))*/
        DeRefi(_put4_1__tmp_at493_19213);
        _1 = (int)SEQ_PTR(_48memseq_17673);
        poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        poke4_addr = (unsigned long *)NewS1(_2);
        _put4_1__tmp_at493_19213 = MAKE_SEQ(poke4_addr);
        poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
        while (--_2 >= 0) {
            poke4_addr++;
            _1 = (int)(unsigned char)*poke_addr++;
            *(int *)poke4_addr = _1;
        }
        EPuts(_48current_db_17396, _put4_1__tmp_at493_19213); // DJP 

        /** end procedure*/
        goto LC; // [515] 518
LC: 
        DeRef(_x_inlined_put4_at_490_19212);
        _x_inlined_put4_at_490_19212 = NOVALUE;
        DeRefi(_put4_1__tmp_at493_19213);
        _put4_1__tmp_at493_19213 = NOVALUE;

        /** 	end for*/
        _0 = _i_19206;
        if (IS_ATOM_INT(_i_19206)) {
            _i_19206 = _i_19206 + 1;
            if ((long)((unsigned long)_i_19206 +(unsigned long) HIGH_BITS) >= 0){
                _i_19206 = NewDouble((double)_i_19206);
            }
        }
        else {
            _i_19206 = binary_op_a(PLUS, _i_19206, 1);
        }
        DeRef(_0);
        goto LA; // [522] 475
LB: 
        ;
        DeRef(_i_19206);
    }

    /** 	io:seek(current_db, current_block)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_current_block_19122);
    DeRef(_seek_1__tmp_at530_19216);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _48current_db_17396;
    ((int *)_2)[2] = _current_block_19122;
    _seek_1__tmp_at530_19216 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_530_19215 = machine(19, _seek_1__tmp_at530_19216);
    DeRef(_seek_1__tmp_at530_19216);
    _seek_1__tmp_at530_19216 = NOVALUE;

    /** 	nrecs += 1*/
    _0 = _nrecs_19121;
    if (IS_ATOM_INT(_nrecs_19121)) {
        _nrecs_19121 = _nrecs_19121 + 1;
        if (_nrecs_19121 > MAXINT){
            _nrecs_19121 = NewDouble((double)_nrecs_19121);
        }
    }
    else
    _nrecs_19121 = binary_op(PLUS, 1, _nrecs_19121);
    DeRef(_0);

    /** 	put4(nrecs)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_48mem0_17438)){
        poke4_addr = (unsigned long *)_48mem0_17438;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_48mem0_17438)->dbl);
    }
    if (IS_ATOM_INT(_nrecs_19121)) {
        *poke4_addr = (unsigned long)_nrecs_19121;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_nrecs_19121)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at551_19219);
    _1 = (int)SEQ_PTR(_48memseq_17673);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at551_19219 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_48current_db_17396, _put4_1__tmp_at551_19219); // DJP 

    /** end procedure*/
    goto LD; // [573] 576
LD: 
    DeRefi(_put4_1__tmp_at551_19219);
    _put4_1__tmp_at551_19219 = NOVALUE;

    /** 	io:seek(current_db, records_ptr - 4)*/
    if (IS_ATOM_INT(_records_ptr_19120)) {
        _10718 = _records_ptr_19120 - 4;
        if ((long)((unsigned long)_10718 +(unsigned long) HIGH_BITS) >= 0){
            _10718 = NewDouble((double)_10718);
        }
    }
    else {
        _10718 = NewDouble(DBL_PTR(_records_ptr_19120)->dbl - (double)4);
    }
    DeRef(_pos_inlined_seek_at_585_19222);
    _pos_inlined_seek_at_585_19222 = _10718;
    _10718 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_585_19222);
    DeRef(_seek_1__tmp_at588_19224);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _48current_db_17396;
    ((int *)_2)[2] = _pos_inlined_seek_at_585_19222;
    _seek_1__tmp_at588_19224 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_588_19223 = machine(19, _seek_1__tmp_at588_19224);
    DeRef(_pos_inlined_seek_at_585_19222);
    _pos_inlined_seek_at_585_19222 = NOVALUE;
    DeRef(_seek_1__tmp_at588_19224);
    _seek_1__tmp_at588_19224 = NOVALUE;

    /** 	size = get4() - 4*/
    _10719 = _48get4();
    DeRef(_size_19123);
    if (IS_ATOM_INT(_10719)) {
        _size_19123 = _10719 - 4;
        if ((long)((unsigned long)_size_19123 +(unsigned long) HIGH_BITS) >= 0){
            _size_19123 = NewDouble((double)_size_19123);
        }
    }
    else {
        _size_19123 = binary_op(MINUS, _10719, 4);
    }
    DeRef(_10719);
    _10719 = NOVALUE;

    /** 	if nrecs*4 > size-4 then*/
    if (IS_ATOM_INT(_nrecs_19121)) {
        if (_nrecs_19121 == (short)_nrecs_19121)
        _10721 = _nrecs_19121 * 4;
        else
        _10721 = NewDouble(_nrecs_19121 * (double)4);
    }
    else {
        _10721 = NewDouble(DBL_PTR(_nrecs_19121)->dbl * (double)4);
    }
    if (IS_ATOM_INT(_size_19123)) {
        _10722 = _size_19123 - 4;
        if ((long)((unsigned long)_10722 +(unsigned long) HIGH_BITS) >= 0){
            _10722 = NewDouble((double)_10722);
        }
    }
    else {
        _10722 = NewDouble(DBL_PTR(_size_19123)->dbl - (double)4);
    }
    if (binary_op_a(LESSEQ, _10721, _10722)){
        DeRef(_10721);
        _10721 = NOVALUE;
        DeRef(_10722);
        _10722 = NOVALUE;
        goto LE; // [621] 1217
    }
    DeRef(_10721);
    _10721 = NOVALUE;
    DeRef(_10722);
    _10722 = NOVALUE;

    /** 		new_size = 8 * (20 + floor(sqrt(1.5 * total_recs)))*/
    if (IS_ATOM_INT(_total_recs_19129)) {
        _10726 = NewDouble(DBL_PTR(_10725)->dbl * (double)_total_recs_19129);
    }
    else
    _10726 = NewDouble(DBL_PTR(_10725)->dbl * DBL_PTR(_total_recs_19129)->dbl);
    _10727 = unary_op(SQRT, _10726);
    DeRefDS(_10726);
    _10726 = NOVALUE;
    _10728 = unary_op(FLOOR, _10727);
    DeRefDS(_10727);
    _10727 = NOVALUE;
    if (IS_ATOM_INT(_10728)) {
        _10729 = 20 + _10728;
        if ((long)((unsigned long)_10729 + (unsigned long)HIGH_BITS) >= 0) 
        _10729 = NewDouble((double)_10729);
    }
    else {
        _10729 = NewDouble((double)20 + DBL_PTR(_10728)->dbl);
    }
    DeRef(_10728);
    _10728 = NOVALUE;
    DeRef(_new_size_19124);
    if (IS_ATOM_INT(_10729)) {
        if (_10729 <= INT15 && _10729 >= -INT15)
        _new_size_19124 = 8 * _10729;
        else
        _new_size_19124 = NewDouble(8 * (double)_10729);
    }
    else {
        _new_size_19124 = NewDouble((double)8 * DBL_PTR(_10729)->dbl);
    }
    DeRef(_10729);
    _10729 = NOVALUE;

    /** 		new_recs = floor(new_size/8)*/
    if (IS_ATOM_INT(_new_size_19124)) {
        if (8 > 0 && _new_size_19124 >= 0) {
            _new_recs_19132 = _new_size_19124 / 8;
        }
        else {
            temp_dbl = floor((double)_new_size_19124 / (double)8);
            _new_recs_19132 = (long)temp_dbl;
        }
    }
    else {
        _2 = binary_op(DIVIDE, _new_size_19124, 8);
        _new_recs_19132 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    if (!IS_ATOM_INT(_new_recs_19132)) {
        _1 = (long)(DBL_PTR(_new_recs_19132)->dbl);
        DeRefDS(_new_recs_19132);
        _new_recs_19132 = _1;
    }

    /** 		if new_recs > floor(nrecs/2) then*/
    if (IS_ATOM_INT(_nrecs_19121)) {
        _10732 = _nrecs_19121 >> 1;
    }
    else {
        _1 = binary_op(DIVIDE, _nrecs_19121, 2);
        _10732 = unary_op(FLOOR, _1);
        DeRef(_1);
    }
    if (binary_op_a(LESSEQ, _new_recs_19132, _10732)){
        DeRef(_10732);
        _10732 = NOVALUE;
        goto LF; // [659] 672
    }
    DeRef(_10732);
    _10732 = NOVALUE;

    /** 			new_recs = floor(nrecs/2)*/
    if (IS_ATOM_INT(_nrecs_19121)) {
        _new_recs_19132 = _nrecs_19121 >> 1;
    }
    else {
        _1 = binary_op(DIVIDE, _nrecs_19121, 2);
        _new_recs_19132 = unary_op(FLOOR, _1);
        DeRef(_1);
    }
    if (!IS_ATOM_INT(_new_recs_19132)) {
        _1 = (long)(DBL_PTR(_new_recs_19132)->dbl);
        DeRefDS(_new_recs_19132);
        _new_recs_19132 = _1;
    }
LF: 

    /** 		io:seek(current_db, records_ptr + (nrecs-new_recs)*4)*/
    if (IS_ATOM_INT(_nrecs_19121)) {
        _10735 = _nrecs_19121 - _new_recs_19132;
        if ((long)((unsigned long)_10735 +(unsigned long) HIGH_BITS) >= 0){
            _10735 = NewDouble((double)_10735);
        }
    }
    else {
        _10735 = NewDouble(DBL_PTR(_nrecs_19121)->dbl - (double)_new_recs_19132);
    }
    if (IS_ATOM_INT(_10735)) {
        if (_10735 == (short)_10735)
        _10736 = _10735 * 4;
        else
        _10736 = NewDouble(_10735 * (double)4);
    }
    else {
        _10736 = NewDouble(DBL_PTR(_10735)->dbl * (double)4);
    }
    DeRef(_10735);
    _10735 = NOVALUE;
    if (IS_ATOM_INT(_records_ptr_19120) && IS_ATOM_INT(_10736)) {
        _10737 = _records_ptr_19120 + _10736;
        if ((long)((unsigned long)_10737 + (unsigned long)HIGH_BITS) >= 0) 
        _10737 = NewDouble((double)_10737);
    }
    else {
        if (IS_ATOM_INT(_records_ptr_19120)) {
            _10737 = NewDouble((double)_records_ptr_19120 + DBL_PTR(_10736)->dbl);
        }
        else {
            if (IS_ATOM_INT(_10736)) {
                _10737 = NewDouble(DBL_PTR(_records_ptr_19120)->dbl + (double)_10736);
            }
            else
            _10737 = NewDouble(DBL_PTR(_records_ptr_19120)->dbl + DBL_PTR(_10736)->dbl);
        }
    }
    DeRef(_10736);
    _10736 = NOVALUE;
    DeRef(_pos_inlined_seek_at_687_19247);
    _pos_inlined_seek_at_687_19247 = _10737;
    _10737 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_687_19247);
    DeRef(_seek_1__tmp_at690_19249);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _48current_db_17396;
    ((int *)_2)[2] = _pos_inlined_seek_at_687_19247;
    _seek_1__tmp_at690_19249 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_690_19248 = machine(19, _seek_1__tmp_at690_19249);
    DeRef(_pos_inlined_seek_at_687_19247);
    _pos_inlined_seek_at_687_19247 = NOVALUE;
    DeRef(_seek_1__tmp_at690_19249);
    _seek_1__tmp_at690_19249 = NOVALUE;

    /** 		last_part = io:get_bytes(current_db, new_recs*4)*/
    if (_new_recs_19132 == (short)_new_recs_19132)
    _10738 = _new_recs_19132 * 4;
    else
    _10738 = NewDouble(_new_recs_19132 * (double)4);
    _0 = _last_part_19116;
    _last_part_19116 = _18get_bytes(_48current_db_17396, _10738);
    DeRef(_0);
    _10738 = NOVALUE;

    /** 		new_block = db_allocate(new_size)*/
    Ref(_new_size_19124);
    _0 = _new_block_19126;
    _new_block_19126 = _48db_allocate(_new_size_19124);
    DeRef(_0);

    /** 		putn(last_part)*/

    /** 	puts(current_db, s)*/
    EPuts(_48current_db_17396, _last_part_19116); // DJP 

    /** end procedure*/
    goto L10; // [736] 739
L10: 

    /** 		putn(repeat(0, new_size-length(last_part)))*/
    if (IS_SEQUENCE(_last_part_19116)){
            _10741 = SEQ_PTR(_last_part_19116)->length;
    }
    else {
        _10741 = 1;
    }
    if (IS_ATOM_INT(_new_size_19124)) {
        _10742 = _new_size_19124 - _10741;
    }
    else {
        _10742 = NewDouble(DBL_PTR(_new_size_19124)->dbl - (double)_10741);
    }
    _10741 = NOVALUE;
    _10743 = Repeat(0, _10742);
    DeRef(_10742);
    _10742 = NOVALUE;
    DeRefi(_s_inlined_putn_at_751_19258);
    _s_inlined_putn_at_751_19258 = _10743;
    _10743 = NOVALUE;

    /** 	puts(current_db, s)*/
    EPuts(_48current_db_17396, _s_inlined_putn_at_751_19258); // DJP 

    /** end procedure*/
    goto L11; // [766] 769
L11: 
    DeRefi(_s_inlined_putn_at_751_19258);
    _s_inlined_putn_at_751_19258 = NOVALUE;

    /** 		io:seek(current_db, current_block)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_current_block_19122);
    DeRef(_seek_1__tmp_at774_19261);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _48current_db_17396;
    ((int *)_2)[2] = _current_block_19122;
    _seek_1__tmp_at774_19261 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_774_19260 = machine(19, _seek_1__tmp_at774_19261);
    DeRef(_seek_1__tmp_at774_19261);
    _seek_1__tmp_at774_19261 = NOVALUE;

    /** 		put4(nrecs-new_recs)*/
    if (IS_ATOM_INT(_nrecs_19121)) {
        _10744 = _nrecs_19121 - _new_recs_19132;
        if ((long)((unsigned long)_10744 +(unsigned long) HIGH_BITS) >= 0){
            _10744 = NewDouble((double)_10744);
        }
    }
    else {
        _10744 = NewDouble(DBL_PTR(_nrecs_19121)->dbl - (double)_new_recs_19132);
    }
    DeRef(_x_inlined_put4_at_793_19264);
    _x_inlined_put4_at_793_19264 = _10744;
    _10744 = NOVALUE;

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_48mem0_17438)){
        poke4_addr = (unsigned long *)_48mem0_17438;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_48mem0_17438)->dbl);
    }
    if (IS_ATOM_INT(_x_inlined_put4_at_793_19264)) {
        *poke4_addr = (unsigned long)_x_inlined_put4_at_793_19264;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_x_inlined_put4_at_793_19264)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at796_19265);
    _1 = (int)SEQ_PTR(_48memseq_17673);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at796_19265 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_48current_db_17396, _put4_1__tmp_at796_19265); // DJP 

    /** end procedure*/
    goto L12; // [818] 821
L12: 
    DeRef(_x_inlined_put4_at_793_19264);
    _x_inlined_put4_at_793_19264 = NOVALUE;
    DeRefi(_put4_1__tmp_at796_19265);
    _put4_1__tmp_at796_19265 = NOVALUE;

    /** 		io:seek(current_db, current_block+8)*/
    if (IS_ATOM_INT(_current_block_19122)) {
        _10745 = _current_block_19122 + 8;
        if ((long)((unsigned long)_10745 + (unsigned long)HIGH_BITS) >= 0) 
        _10745 = NewDouble((double)_10745);
    }
    else {
        _10745 = NewDouble(DBL_PTR(_current_block_19122)->dbl + (double)8);
    }
    DeRef(_pos_inlined_seek_at_830_19268);
    _pos_inlined_seek_at_830_19268 = _10745;
    _10745 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_830_19268);
    DeRef(_seek_1__tmp_at833_19270);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _48current_db_17396;
    ((int *)_2)[2] = _pos_inlined_seek_at_830_19268;
    _seek_1__tmp_at833_19270 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_833_19269 = machine(19, _seek_1__tmp_at833_19270);
    DeRef(_pos_inlined_seek_at_830_19268);
    _pos_inlined_seek_at_830_19268 = NOVALUE;
    DeRef(_seek_1__tmp_at833_19270);
    _seek_1__tmp_at833_19270 = NOVALUE;

    /** 		remaining = io:get_bytes(current_db, index_ptr+blocks*8-(current_block+8))*/
    if (_blocks_19131 == (short)_blocks_19131)
    _10746 = _blocks_19131 * 8;
    else
    _10746 = NewDouble(_blocks_19131 * (double)8);
    if (IS_ATOM_INT(_index_ptr_19127) && IS_ATOM_INT(_10746)) {
        _10747 = _index_ptr_19127 + _10746;
        if ((long)((unsigned long)_10747 + (unsigned long)HIGH_BITS) >= 0) 
        _10747 = NewDouble((double)_10747);
    }
    else {
        if (IS_ATOM_INT(_index_ptr_19127)) {
            _10747 = NewDouble((double)_index_ptr_19127 + DBL_PTR(_10746)->dbl);
        }
        else {
            if (IS_ATOM_INT(_10746)) {
                _10747 = NewDouble(DBL_PTR(_index_ptr_19127)->dbl + (double)_10746);
            }
            else
            _10747 = NewDouble(DBL_PTR(_index_ptr_19127)->dbl + DBL_PTR(_10746)->dbl);
        }
    }
    DeRef(_10746);
    _10746 = NOVALUE;
    if (IS_ATOM_INT(_current_block_19122)) {
        _10748 = _current_block_19122 + 8;
        if ((long)((unsigned long)_10748 + (unsigned long)HIGH_BITS) >= 0) 
        _10748 = NewDouble((double)_10748);
    }
    else {
        _10748 = NewDouble(DBL_PTR(_current_block_19122)->dbl + (double)8);
    }
    if (IS_ATOM_INT(_10747) && IS_ATOM_INT(_10748)) {
        _10749 = _10747 - _10748;
        if ((long)((unsigned long)_10749 +(unsigned long) HIGH_BITS) >= 0){
            _10749 = NewDouble((double)_10749);
        }
    }
    else {
        if (IS_ATOM_INT(_10747)) {
            _10749 = NewDouble((double)_10747 - DBL_PTR(_10748)->dbl);
        }
        else {
            if (IS_ATOM_INT(_10748)) {
                _10749 = NewDouble(DBL_PTR(_10747)->dbl - (double)_10748);
            }
            else
            _10749 = NewDouble(DBL_PTR(_10747)->dbl - DBL_PTR(_10748)->dbl);
        }
    }
    DeRef(_10747);
    _10747 = NOVALUE;
    DeRef(_10748);
    _10748 = NOVALUE;
    _0 = _remaining_19117;
    _remaining_19117 = _18get_bytes(_48current_db_17396, _10749);
    DeRef(_0);
    _10749 = NOVALUE;

    /** 		io:seek(current_db, current_block+8)*/
    if (IS_ATOM_INT(_current_block_19122)) {
        _10751 = _current_block_19122 + 8;
        if ((long)((unsigned long)_10751 + (unsigned long)HIGH_BITS) >= 0) 
        _10751 = NewDouble((double)_10751);
    }
    else {
        _10751 = NewDouble(DBL_PTR(_current_block_19122)->dbl + (double)8);
    }
    DeRef(_pos_inlined_seek_at_881_19278);
    _pos_inlined_seek_at_881_19278 = _10751;
    _10751 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_881_19278);
    DeRef(_seek_1__tmp_at884_19280);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _48current_db_17396;
    ((int *)_2)[2] = _pos_inlined_seek_at_881_19278;
    _seek_1__tmp_at884_19280 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_884_19279 = machine(19, _seek_1__tmp_at884_19280);
    DeRef(_pos_inlined_seek_at_881_19278);
    _pos_inlined_seek_at_881_19278 = NOVALUE;
    DeRef(_seek_1__tmp_at884_19280);
    _seek_1__tmp_at884_19280 = NOVALUE;

    /** 		put4(new_recs)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_48mem0_17438)){
        poke4_addr = (unsigned long *)_48mem0_17438;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_48mem0_17438)->dbl);
    }
    *poke4_addr = (unsigned long)_new_recs_19132;

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at899_19282);
    _1 = (int)SEQ_PTR(_48memseq_17673);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at899_19282 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_48current_db_17396, _put4_1__tmp_at899_19282); // DJP 

    /** end procedure*/
    goto L13; // [921] 924
L13: 
    DeRefi(_put4_1__tmp_at899_19282);
    _put4_1__tmp_at899_19282 = NOVALUE;

    /** 		put4(new_block)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_48mem0_17438)){
        poke4_addr = (unsigned long *)_48mem0_17438;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_48mem0_17438)->dbl);
    }
    if (IS_ATOM_INT(_new_block_19126)) {
        *poke4_addr = (unsigned long)_new_block_19126;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_new_block_19126)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at927_19284);
    _1 = (int)SEQ_PTR(_48memseq_17673);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at927_19284 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_48current_db_17396, _put4_1__tmp_at927_19284); // DJP 

    /** end procedure*/
    goto L14; // [949] 952
L14: 
    DeRefi(_put4_1__tmp_at927_19284);
    _put4_1__tmp_at927_19284 = NOVALUE;

    /** 		putn(remaining)*/

    /** 	puts(current_db, s)*/
    EPuts(_48current_db_17396, _remaining_19117); // DJP 

    /** end procedure*/
    goto L15; // [965] 968
L15: 

    /** 		io:seek(current_db, current_table_pos+8)*/
    if (IS_ATOM_INT(_48current_table_pos_17397)) {
        _10752 = _48current_table_pos_17397 + 8;
        if ((long)((unsigned long)_10752 + (unsigned long)HIGH_BITS) >= 0) 
        _10752 = NewDouble((double)_10752);
    }
    else {
        _10752 = NewDouble(DBL_PTR(_48current_table_pos_17397)->dbl + (double)8);
    }
    DeRef(_pos_inlined_seek_at_977_19288);
    _pos_inlined_seek_at_977_19288 = _10752;
    _10752 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_977_19288);
    DeRef(_seek_1__tmp_at980_19290);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _48current_db_17396;
    ((int *)_2)[2] = _pos_inlined_seek_at_977_19288;
    _seek_1__tmp_at980_19290 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_980_19289 = machine(19, _seek_1__tmp_at980_19290);
    DeRef(_pos_inlined_seek_at_977_19288);
    _pos_inlined_seek_at_977_19288 = NOVALUE;
    DeRef(_seek_1__tmp_at980_19290);
    _seek_1__tmp_at980_19290 = NOVALUE;

    /** 		blocks += 1*/
    _blocks_19131 = _blocks_19131 + 1;

    /** 		put4(blocks)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_48mem0_17438)){
        poke4_addr = (unsigned long *)_48mem0_17438;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_48mem0_17438)->dbl);
    }
    *poke4_addr = (unsigned long)_blocks_19131;

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at1001_19293);
    _1 = (int)SEQ_PTR(_48memseq_17673);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at1001_19293 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_48current_db_17396, _put4_1__tmp_at1001_19293); // DJP 

    /** end procedure*/
    goto L16; // [1023] 1026
L16: 
    DeRefi(_put4_1__tmp_at1001_19293);
    _put4_1__tmp_at1001_19293 = NOVALUE;

    /** 		io:seek(current_db, index_ptr-4)*/
    if (IS_ATOM_INT(_index_ptr_19127)) {
        _10754 = _index_ptr_19127 - 4;
        if ((long)((unsigned long)_10754 +(unsigned long) HIGH_BITS) >= 0){
            _10754 = NewDouble((double)_10754);
        }
    }
    else {
        _10754 = NewDouble(DBL_PTR(_index_ptr_19127)->dbl - (double)4);
    }
    DeRef(_pos_inlined_seek_at_1035_19296);
    _pos_inlined_seek_at_1035_19296 = _10754;
    _10754 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_1035_19296);
    DeRef(_seek_1__tmp_at1038_19298);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _48current_db_17396;
    ((int *)_2)[2] = _pos_inlined_seek_at_1035_19296;
    _seek_1__tmp_at1038_19298 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_1038_19297 = machine(19, _seek_1__tmp_at1038_19298);
    DeRef(_pos_inlined_seek_at_1035_19296);
    _pos_inlined_seek_at_1035_19296 = NOVALUE;
    DeRef(_seek_1__tmp_at1038_19298);
    _seek_1__tmp_at1038_19298 = NOVALUE;

    /** 		size = get4() - 4*/
    _10755 = _48get4();
    DeRef(_size_19123);
    if (IS_ATOM_INT(_10755)) {
        _size_19123 = _10755 - 4;
        if ((long)((unsigned long)_size_19123 +(unsigned long) HIGH_BITS) >= 0){
            _size_19123 = NewDouble((double)_size_19123);
        }
    }
    else {
        _size_19123 = binary_op(MINUS, _10755, 4);
    }
    DeRef(_10755);
    _10755 = NOVALUE;

    /** 		if blocks*8 > size-8 then*/
    if (_blocks_19131 == (short)_blocks_19131)
    _10757 = _blocks_19131 * 8;
    else
    _10757 = NewDouble(_blocks_19131 * (double)8);
    if (IS_ATOM_INT(_size_19123)) {
        _10758 = _size_19123 - 8;
        if ((long)((unsigned long)_10758 +(unsigned long) HIGH_BITS) >= 0){
            _10758 = NewDouble((double)_10758);
        }
    }
    else {
        _10758 = NewDouble(DBL_PTR(_size_19123)->dbl - (double)8);
    }
    if (binary_op_a(LESSEQ, _10757, _10758)){
        DeRef(_10757);
        _10757 = NOVALUE;
        DeRef(_10758);
        _10758 = NOVALUE;
        goto L17; // [1071] 1216
    }
    DeRef(_10757);
    _10757 = NOVALUE;
    DeRef(_10758);
    _10758 = NOVALUE;

    /** 			remaining = io:get_bytes(current_db, blocks*8)*/
    if (_blocks_19131 == (short)_blocks_19131)
    _10760 = _blocks_19131 * 8;
    else
    _10760 = NewDouble(_blocks_19131 * (double)8);
    _0 = _remaining_19117;
    _remaining_19117 = _18get_bytes(_48current_db_17396, _10760);
    DeRef(_0);
    _10760 = NOVALUE;

    /** 			new_size = floor(size + size/2)*/
    if (IS_ATOM_INT(_size_19123)) {
        if (_size_19123 & 1) {
            _10762 = NewDouble((_size_19123 >> 1) + 0.5);
        }
        else
        _10762 = _size_19123 >> 1;
    }
    else {
        _10762 = binary_op(DIVIDE, _size_19123, 2);
    }
    if (IS_ATOM_INT(_size_19123) && IS_ATOM_INT(_10762)) {
        _10763 = _size_19123 + _10762;
        if ((long)((unsigned long)_10763 + (unsigned long)HIGH_BITS) >= 0) 
        _10763 = NewDouble((double)_10763);
    }
    else {
        if (IS_ATOM_INT(_size_19123)) {
            _10763 = NewDouble((double)_size_19123 + DBL_PTR(_10762)->dbl);
        }
        else {
            if (IS_ATOM_INT(_10762)) {
                _10763 = NewDouble(DBL_PTR(_size_19123)->dbl + (double)_10762);
            }
            else
            _10763 = NewDouble(DBL_PTR(_size_19123)->dbl + DBL_PTR(_10762)->dbl);
        }
    }
    DeRef(_10762);
    _10762 = NOVALUE;
    DeRef(_new_size_19124);
    if (IS_ATOM_INT(_10763))
    _new_size_19124 = e_floor(_10763);
    else
    _new_size_19124 = unary_op(FLOOR, _10763);
    DeRef(_10763);
    _10763 = NOVALUE;

    /** 			new_index_ptr = db_allocate(new_size)*/
    Ref(_new_size_19124);
    _0 = _new_index_ptr_19128;
    _new_index_ptr_19128 = _48db_allocate(_new_size_19124);
    DeRef(_0);

    /** 			putn(remaining)*/

    /** 	puts(current_db, s)*/
    EPuts(_48current_db_17396, _remaining_19117); // DJP 

    /** end procedure*/
    goto L18; // [1120] 1123
L18: 

    /** 			putn(repeat(0, new_size-blocks*8))*/
    if (_blocks_19131 == (short)_blocks_19131)
    _10766 = _blocks_19131 * 8;
    else
    _10766 = NewDouble(_blocks_19131 * (double)8);
    if (IS_ATOM_INT(_new_size_19124) && IS_ATOM_INT(_10766)) {
        _10767 = _new_size_19124 - _10766;
    }
    else {
        if (IS_ATOM_INT(_new_size_19124)) {
            _10767 = NewDouble((double)_new_size_19124 - DBL_PTR(_10766)->dbl);
        }
        else {
            if (IS_ATOM_INT(_10766)) {
                _10767 = NewDouble(DBL_PTR(_new_size_19124)->dbl - (double)_10766);
            }
            else
            _10767 = NewDouble(DBL_PTR(_new_size_19124)->dbl - DBL_PTR(_10766)->dbl);
        }
    }
    DeRef(_10766);
    _10766 = NOVALUE;
    _10768 = Repeat(0, _10767);
    DeRef(_10767);
    _10767 = NOVALUE;
    DeRefi(_s_inlined_putn_at_1136_19316);
    _s_inlined_putn_at_1136_19316 = _10768;
    _10768 = NOVALUE;

    /** 	puts(current_db, s)*/
    EPuts(_48current_db_17396, _s_inlined_putn_at_1136_19316); // DJP 

    /** end procedure*/
    goto L19; // [1151] 1154
L19: 
    DeRefi(_s_inlined_putn_at_1136_19316);
    _s_inlined_putn_at_1136_19316 = NOVALUE;

    /** 			db_free(index_ptr)*/
    Ref(_index_ptr_19127);
    _48db_free(_index_ptr_19127);

    /** 			io:seek(current_db, current_table_pos+12)*/
    if (IS_ATOM_INT(_48current_table_pos_17397)) {
        _10769 = _48current_table_pos_17397 + 12;
        if ((long)((unsigned long)_10769 + (unsigned long)HIGH_BITS) >= 0) 
        _10769 = NewDouble((double)_10769);
    }
    else {
        _10769 = NewDouble(DBL_PTR(_48current_table_pos_17397)->dbl + (double)12);
    }
    DeRef(_pos_inlined_seek_at_1170_19319);
    _pos_inlined_seek_at_1170_19319 = _10769;
    _10769 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_1170_19319);
    DeRef(_seek_1__tmp_at1173_19321);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _48current_db_17396;
    ((int *)_2)[2] = _pos_inlined_seek_at_1170_19319;
    _seek_1__tmp_at1173_19321 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_1173_19320 = machine(19, _seek_1__tmp_at1173_19321);
    DeRef(_pos_inlined_seek_at_1170_19319);
    _pos_inlined_seek_at_1170_19319 = NOVALUE;
    DeRef(_seek_1__tmp_at1173_19321);
    _seek_1__tmp_at1173_19321 = NOVALUE;

    /** 			put4(new_index_ptr)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_48mem0_17438)){
        poke4_addr = (unsigned long *)_48mem0_17438;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_48mem0_17438)->dbl);
    }
    if (IS_ATOM_INT(_new_index_ptr_19128)) {
        *poke4_addr = (unsigned long)_new_index_ptr_19128;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_new_index_ptr_19128)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at1188_19323);
    _1 = (int)SEQ_PTR(_48memseq_17673);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at1188_19323 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_48current_db_17396, _put4_1__tmp_at1188_19323); // DJP 

    /** end procedure*/
    goto L1A; // [1210] 1213
L1A: 
    DeRefi(_put4_1__tmp_at1188_19323);
    _put4_1__tmp_at1188_19323 = NOVALUE;
L17: 
LE: 

    /** 	return DB_OK*/
    DeRef(_key_19111);
    DeRef(_table_name_19113);
    DeRef(_key_string_19114);
    DeRef(_data_string_19115);
    DeRef(_last_part_19116);
    DeRef(_remaining_19117);
    DeRef(_key_ptr_19118);
    DeRef(_data_ptr_19119);
    DeRef(_records_ptr_19120);
    DeRef(_nrecs_19121);
    DeRef(_current_block_19122);
    DeRef(_size_19123);
    DeRef(_new_size_19124);
    DeRef(_key_location_19125);
    DeRef(_new_block_19126);
    DeRef(_index_ptr_19127);
    DeRef(_new_index_ptr_19128);
    DeRef(_total_recs_19129);
    DeRef(_10713);
    _10713 = NOVALUE;
    DeRef(_10715);
    _10715 = NOVALUE;
    return 0;
    ;
}


void _48db_replace_data(int _key_location_19458, int _data_19459, int _table_name_19460)
{
    int _10843 = NOVALUE;
    int _10842 = NOVALUE;
    int _10841 = NOVALUE;
    int _10840 = NOVALUE;
    int _10838 = NOVALUE;
    int _10837 = NOVALUE;
    int _10835 = NOVALUE;
    int _10832 = NOVALUE;
    int _10830 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not equal(table_name, current_table_name) then*/
    if (_table_name_19460 == _48current_table_name_17398)
    _10830 = 1;
    else if (IS_ATOM_INT(_table_name_19460) && IS_ATOM_INT(_48current_table_name_17398))
    _10830 = 0;
    else
    _10830 = (compare(_table_name_19460, _48current_table_name_17398) == 0);
    if (_10830 != 0)
    goto L1; // [11] 45
    _10830 = NOVALUE;

    /** 		if db_select_table(table_name) != DB_OK then*/
    RefDS(_table_name_19460);
    _10832 = _48db_select_table(_table_name_19460);
    if (binary_op_a(EQUALS, _10832, 0)){
        DeRef(_10832);
        _10832 = NOVALUE;
        goto L2; // [20] 44
    }
    DeRef(_10832);
    _10832 = NOVALUE;

    /** 			fatal(NO_TABLE, "invalid table name given", "db_replace_data", {key_location, data, table_name})*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _key_location_19458;
    *((int *)(_2+8)) = _data_19459;
    RefDS(_table_name_19460);
    *((int *)(_2+12)) = _table_name_19460;
    _10835 = MAKE_SEQ(_1);
    RefDS(_10654);
    RefDS(_10834);
    _48fatal(903, _10654, _10834, _10835);
    _10835 = NOVALUE;

    /** 			return*/
    DeRefDS(_table_name_19460);
    return;
L2: 
L1: 

    /** 	if current_table_pos = -1 then*/
    if (binary_op_a(NOTEQ, _48current_table_pos_17397, -1)){
        goto L3; // [49] 73
    }

    /** 		fatal(NO_TABLE, "no table selected", "db_replace_data", {key_location, data, table_name})*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _key_location_19458;
    *((int *)(_2+8)) = _data_19459;
    Ref(_table_name_19460);
    *((int *)(_2+12)) = _table_name_19460;
    _10837 = MAKE_SEQ(_1);
    RefDS(_10658);
    RefDS(_10834);
    _48fatal(903, _10658, _10834, _10837);
    _10837 = NOVALUE;

    /** 		return*/
    DeRef(_table_name_19460);
    return;
L3: 

    /** 	if key_location < 1 or key_location > length(key_pointers) then*/
    _10838 = (_key_location_19458 < 1);
    if (_10838 != 0) {
        goto L4; // [79] 97
    }
    if (IS_SEQUENCE(_48key_pointers_17403)){
            _10840 = SEQ_PTR(_48key_pointers_17403)->length;
    }
    else {
        _10840 = 1;
    }
    _10841 = (_key_location_19458 > _10840);
    _10840 = NOVALUE;
    if (_10841 == 0)
    {
        DeRef(_10841);
        _10841 = NOVALUE;
        goto L5; // [93] 117
    }
    else{
        DeRef(_10841);
        _10841 = NOVALUE;
    }
L4: 

    /** 		fatal(BAD_RECNO, "bad record number", "db_replace_data", {key_location, data, table_name})*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _key_location_19458;
    *((int *)(_2+8)) = _data_19459;
    Ref(_table_name_19460);
    *((int *)(_2+12)) = _table_name_19460;
    _10842 = MAKE_SEQ(_1);
    RefDS(_10782);
    RefDS(_10834);
    _48fatal(905, _10782, _10834, _10842);
    _10842 = NOVALUE;

    /** 		return*/
    DeRef(_table_name_19460);
    DeRef(_10838);
    _10838 = NOVALUE;
    return;
L5: 

    /** 	db_replace_recid(key_pointers[key_location], data)*/
    _2 = (int)SEQ_PTR(_48key_pointers_17403);
    _10843 = (int)*(((s1_ptr)_2)->base + _key_location_19458);
    Ref(_10843);
    _48db_replace_recid(_10843, _data_19459);
    _10843 = NOVALUE;

    /** end procedure*/
    DeRef(_table_name_19460);
    DeRef(_10838);
    _10838 = NOVALUE;
    return;
    ;
}


int _48db_table_size(int _table_name_19482)
{
    int _10852 = NOVALUE;
    int _10851 = NOVALUE;
    int _10849 = NOVALUE;
    int _10846 = NOVALUE;
    int _10844 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not equal(table_name, current_table_name) then*/
    if (_table_name_19482 == _48current_table_name_17398)
    _10844 = 1;
    else if (IS_ATOM_INT(_table_name_19482) && IS_ATOM_INT(_48current_table_name_17398))
    _10844 = 0;
    else
    _10844 = (compare(_table_name_19482, _48current_table_name_17398) == 0);
    if (_10844 != 0)
    goto L1; // [9] 42
    _10844 = NOVALUE;

    /** 		if db_select_table(table_name) != DB_OK then*/
    RefDS(_table_name_19482);
    _10846 = _48db_select_table(_table_name_19482);
    if (binary_op_a(EQUALS, _10846, 0)){
        DeRef(_10846);
        _10846 = NOVALUE;
        goto L2; // [18] 41
    }
    DeRef(_10846);
    _10846 = NOVALUE;

    /** 			fatal(NO_TABLE, "invalid table name given", "db_table_size", {table_name})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_table_name_19482);
    *((int *)(_2+4)) = _table_name_19482;
    _10849 = MAKE_SEQ(_1);
    RefDS(_10654);
    RefDS(_10848);
    _48fatal(903, _10654, _10848, _10849);
    _10849 = NOVALUE;

    /** 			return -1*/
    DeRefDS(_table_name_19482);
    return -1;
L2: 
L1: 

    /** 	if current_table_pos = -1 then*/
    if (binary_op_a(NOTEQ, _48current_table_pos_17397, -1)){
        goto L3; // [46] 69
    }

    /** 		fatal(NO_TABLE, "no table selected", "db_table_size", {table_name})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_table_name_19482);
    *((int *)(_2+4)) = _table_name_19482;
    _10851 = MAKE_SEQ(_1);
    RefDS(_10658);
    RefDS(_10848);
    _48fatal(903, _10658, _10848, _10851);
    _10851 = NOVALUE;

    /** 		return -1*/
    DeRef(_table_name_19482);
    return -1;
L3: 

    /** 	return length(key_pointers)*/
    if (IS_SEQUENCE(_48key_pointers_17403)){
            _10852 = SEQ_PTR(_48key_pointers_17403)->length;
    }
    else {
        _10852 = 1;
    }
    DeRef(_table_name_19482);
    return _10852;
    ;
}


int _48db_record_data(int _key_location_19497, int _table_name_19498)
{
    int _data_ptr_19499 = NOVALUE;
    int _data_value_19500 = NOVALUE;
    int _seek_1__tmp_at126_19522 = NOVALUE;
    int _seek_inlined_seek_at_126_19521 = NOVALUE;
    int _pos_inlined_seek_at_123_19520 = NOVALUE;
    int _seek_1__tmp_at164_19529 = NOVALUE;
    int _seek_inlined_seek_at_164_19528 = NOVALUE;
    int _10867 = NOVALUE;
    int _10866 = NOVALUE;
    int _10865 = NOVALUE;
    int _10864 = NOVALUE;
    int _10863 = NOVALUE;
    int _10861 = NOVALUE;
    int _10860 = NOVALUE;
    int _10858 = NOVALUE;
    int _10855 = NOVALUE;
    int _10853 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_key_location_19497)) {
        _1 = (long)(DBL_PTR(_key_location_19497)->dbl);
        DeRefDS(_key_location_19497);
        _key_location_19497 = _1;
    }

    /** 	if not equal(table_name, current_table_name) then*/
    if (_table_name_19498 == _48current_table_name_17398)
    _10853 = 1;
    else if (IS_ATOM_INT(_table_name_19498) && IS_ATOM_INT(_48current_table_name_17398))
    _10853 = 0;
    else
    _10853 = (compare(_table_name_19498, _48current_table_name_17398) == 0);
    if (_10853 != 0)
    goto L1; // [11] 44
    _10853 = NOVALUE;

    /** 		if db_select_table(table_name) != DB_OK then*/
    RefDS(_table_name_19498);
    _10855 = _48db_select_table(_table_name_19498);
    if (binary_op_a(EQUALS, _10855, 0)){
        DeRef(_10855);
        _10855 = NOVALUE;
        goto L2; // [20] 43
    }
    DeRef(_10855);
    _10855 = NOVALUE;

    /** 			fatal(NO_TABLE, "invalid table name given", "db_record_data", {key_location, table_name})*/
    RefDS(_table_name_19498);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _key_location_19497;
    ((int *)_2)[2] = _table_name_19498;
    _10858 = MAKE_SEQ(_1);
    RefDS(_10654);
    RefDS(_10857);
    _48fatal(903, _10654, _10857, _10858);
    _10858 = NOVALUE;

    /** 			return -1*/
    DeRefDS(_table_name_19498);
    DeRef(_data_ptr_19499);
    DeRef(_data_value_19500);
    return -1;
L2: 
L1: 

    /** 	if current_table_pos = -1 then*/
    if (binary_op_a(NOTEQ, _48current_table_pos_17397, -1)){
        goto L3; // [48] 71
    }

    /** 		fatal(NO_TABLE, "no table selected", "db_record_data", {key_location, table_name})*/
    Ref(_table_name_19498);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _key_location_19497;
    ((int *)_2)[2] = _table_name_19498;
    _10860 = MAKE_SEQ(_1);
    RefDS(_10658);
    RefDS(_10857);
    _48fatal(903, _10658, _10857, _10860);
    _10860 = NOVALUE;

    /** 		return -1*/
    DeRef(_table_name_19498);
    DeRef(_data_ptr_19499);
    DeRef(_data_value_19500);
    return -1;
L3: 

    /** 	if key_location < 1 or key_location > length(key_pointers) then*/
    _10861 = (_key_location_19497 < 1);
    if (_10861 != 0) {
        goto L4; // [77] 95
    }
    if (IS_SEQUENCE(_48key_pointers_17403)){
            _10863 = SEQ_PTR(_48key_pointers_17403)->length;
    }
    else {
        _10863 = 1;
    }
    _10864 = (_key_location_19497 > _10863);
    _10863 = NOVALUE;
    if (_10864 == 0)
    {
        DeRef(_10864);
        _10864 = NOVALUE;
        goto L5; // [91] 114
    }
    else{
        DeRef(_10864);
        _10864 = NOVALUE;
    }
L4: 

    /** 		fatal(BAD_RECNO, "bad record number", "db_record_data", {key_location, table_name})*/
    Ref(_table_name_19498);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _key_location_19497;
    ((int *)_2)[2] = _table_name_19498;
    _10865 = MAKE_SEQ(_1);
    RefDS(_10782);
    RefDS(_10857);
    _48fatal(905, _10782, _10857, _10865);
    _10865 = NOVALUE;

    /** 		return -1*/
    DeRef(_table_name_19498);
    DeRef(_data_ptr_19499);
    DeRef(_data_value_19500);
    DeRef(_10861);
    _10861 = NOVALUE;
    return -1;
L5: 

    /** 	io:seek(current_db, key_pointers[key_location])*/
    _2 = (int)SEQ_PTR(_48key_pointers_17403);
    _10866 = (int)*(((s1_ptr)_2)->base + _key_location_19497);
    Ref(_10866);
    DeRef(_pos_inlined_seek_at_123_19520);
    _pos_inlined_seek_at_123_19520 = _10866;
    _10866 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_123_19520);
    DeRef(_seek_1__tmp_at126_19522);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _48current_db_17396;
    ((int *)_2)[2] = _pos_inlined_seek_at_123_19520;
    _seek_1__tmp_at126_19522 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_126_19521 = machine(19, _seek_1__tmp_at126_19522);
    DeRef(_pos_inlined_seek_at_123_19520);
    _pos_inlined_seek_at_123_19520 = NOVALUE;
    DeRef(_seek_1__tmp_at126_19522);
    _seek_1__tmp_at126_19522 = NOVALUE;

    /** 	if length(vLastErrors) > 0 then return -1 end if*/
    if (IS_SEQUENCE(_48vLastErrors_17420)){
            _10867 = SEQ_PTR(_48vLastErrors_17420)->length;
    }
    else {
        _10867 = 1;
    }
    if (_10867 <= 0)
    goto L6; // [147] 156
    DeRef(_table_name_19498);
    DeRef(_data_ptr_19499);
    DeRef(_data_value_19500);
    DeRef(_10861);
    _10861 = NOVALUE;
    return -1;
L6: 

    /** 	data_ptr = get4()*/
    _0 = _data_ptr_19499;
    _data_ptr_19499 = _48get4();
    DeRef(_0);

    /** 	io:seek(current_db, data_ptr)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_data_ptr_19499);
    DeRef(_seek_1__tmp_at164_19529);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _48current_db_17396;
    ((int *)_2)[2] = _data_ptr_19499;
    _seek_1__tmp_at164_19529 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_164_19528 = machine(19, _seek_1__tmp_at164_19529);
    DeRef(_seek_1__tmp_at164_19529);
    _seek_1__tmp_at164_19529 = NOVALUE;

    /** 	data_value = decompress(0)*/
    _0 = _data_value_19500;
    _data_value_19500 = _48decompress(0);
    DeRef(_0);

    /** 	return data_value*/
    DeRef(_table_name_19498);
    DeRef(_data_ptr_19499);
    DeRef(_10861);
    _10861 = NOVALUE;
    return _data_value_19500;
    ;
}


int _48db_fetch_record(int _key_19533, int _table_name_19534)
{
    int _pos_19535 = NOVALUE;
    int _10873 = NOVALUE;
    int _0, _1, _2;
    

    /** 	pos = db_find_key(key, table_name)*/
    Ref(_key_19533);
    RefDS(_table_name_19534);
    _pos_19535 = _48db_find_key(_key_19533, _table_name_19534);
    if (!IS_ATOM_INT(_pos_19535)) {
        _1 = (long)(DBL_PTR(_pos_19535)->dbl);
        DeRefDS(_pos_19535);
        _pos_19535 = _1;
    }

    /** 	if pos > 0 then*/
    if (_pos_19535 <= 0)
    goto L1; // [12] 30

    /** 		return db_record_data(pos, table_name)*/
    RefDS(_table_name_19534);
    _10873 = _48db_record_data(_pos_19535, _table_name_19534);
    DeRef(_key_19533);
    DeRefDS(_table_name_19534);
    return _10873;
    goto L2; // [27] 37
L1: 

    /** 		return pos*/
    DeRef(_key_19533);
    DeRef(_table_name_19534);
    DeRef(_10873);
    _10873 = NOVALUE;
    return _pos_19535;
L2: 
    ;
}


int _48db_record_key(int _key_location_19543, int _table_name_19544)
{
    int _10888 = NOVALUE;
    int _10887 = NOVALUE;
    int _10886 = NOVALUE;
    int _10885 = NOVALUE;
    int _10884 = NOVALUE;
    int _10882 = NOVALUE;
    int _10881 = NOVALUE;
    int _10879 = NOVALUE;
    int _10876 = NOVALUE;
    int _10874 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_key_location_19543)) {
        _1 = (long)(DBL_PTR(_key_location_19543)->dbl);
        DeRefDS(_key_location_19543);
        _key_location_19543 = _1;
    }

    /** 	if not equal(table_name, current_table_name) then*/
    if (_table_name_19544 == _48current_table_name_17398)
    _10874 = 1;
    else if (IS_ATOM_INT(_table_name_19544) && IS_ATOM_INT(_48current_table_name_17398))
    _10874 = 0;
    else
    _10874 = (compare(_table_name_19544, _48current_table_name_17398) == 0);
    if (_10874 != 0)
    goto L1; // [11] 44
    _10874 = NOVALUE;

    /** 		if db_select_table(table_name) != DB_OK then*/
    RefDS(_table_name_19544);
    _10876 = _48db_select_table(_table_name_19544);
    if (binary_op_a(EQUALS, _10876, 0)){
        DeRef(_10876);
        _10876 = NOVALUE;
        goto L2; // [20] 43
    }
    DeRef(_10876);
    _10876 = NOVALUE;

    /** 			fatal(NO_TABLE, "invalid table name given", "db_record_key", {key_location, table_name})*/
    RefDS(_table_name_19544);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _key_location_19543;
    ((int *)_2)[2] = _table_name_19544;
    _10879 = MAKE_SEQ(_1);
    RefDS(_10654);
    RefDS(_10878);
    _48fatal(903, _10654, _10878, _10879);
    _10879 = NOVALUE;

    /** 			return -1*/
    DeRefDS(_table_name_19544);
    return -1;
L2: 
L1: 

    /** 	if current_table_pos = -1 then*/
    if (binary_op_a(NOTEQ, _48current_table_pos_17397, -1)){
        goto L3; // [48] 71
    }

    /** 		fatal(NO_TABLE, "no table selected", "db_record_key", {key_location, table_name})*/
    Ref(_table_name_19544);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _key_location_19543;
    ((int *)_2)[2] = _table_name_19544;
    _10881 = MAKE_SEQ(_1);
    RefDS(_10658);
    RefDS(_10878);
    _48fatal(903, _10658, _10878, _10881);
    _10881 = NOVALUE;

    /** 		return -1*/
    DeRef(_table_name_19544);
    return -1;
L3: 

    /** 	if key_location < 1 or key_location > length(key_pointers) then*/
    _10882 = (_key_location_19543 < 1);
    if (_10882 != 0) {
        goto L4; // [77] 95
    }
    if (IS_SEQUENCE(_48key_pointers_17403)){
            _10884 = SEQ_PTR(_48key_pointers_17403)->length;
    }
    else {
        _10884 = 1;
    }
    _10885 = (_key_location_19543 > _10884);
    _10884 = NOVALUE;
    if (_10885 == 0)
    {
        DeRef(_10885);
        _10885 = NOVALUE;
        goto L5; // [91] 114
    }
    else{
        DeRef(_10885);
        _10885 = NOVALUE;
    }
L4: 

    /** 		fatal(BAD_RECNO, "bad record number", "db_record_key", {key_location, table_name})*/
    Ref(_table_name_19544);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _key_location_19543;
    ((int *)_2)[2] = _table_name_19544;
    _10886 = MAKE_SEQ(_1);
    RefDS(_10782);
    RefDS(_10878);
    _48fatal(905, _10782, _10878, _10886);
    _10886 = NOVALUE;

    /** 		return -1*/
    DeRef(_table_name_19544);
    DeRef(_10882);
    _10882 = NOVALUE;
    return -1;
L5: 

    /** 	return key_value(key_pointers[key_location])*/
    _2 = (int)SEQ_PTR(_48key_pointers_17403);
    _10887 = (int)*(((s1_ptr)_2)->base + _key_location_19543);
    Ref(_10887);
    _10888 = _48key_value(_10887);
    _10887 = NOVALUE;
    DeRef(_table_name_19544);
    DeRef(_10882);
    _10882 = NOVALUE;
    return _10888;
    ;
}


void _48db_replace_recid(int _recid_19657, int _data_19658)
{
    int _old_size_19659 = NOVALUE;
    int _new_size_19660 = NOVALUE;
    int _data_ptr_19661 = NOVALUE;
    int _data_string_19662 = NOVALUE;
    int _put4_1__tmp_at111_19682 = NOVALUE;
    int _10987 = NOVALUE;
    int _10986 = NOVALUE;
    int _10985 = NOVALUE;
    int _10984 = NOVALUE;
    int _10983 = NOVALUE;
    int _10955 = NOVALUE;
    int _10953 = NOVALUE;
    int _10952 = NOVALUE;
    int _10951 = NOVALUE;
    int _10950 = NOVALUE;
    int _10949 = NOVALUE;
    int _10945 = NOVALUE;
    int _10944 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_recid_19657)) {
        _1 = (long)(DBL_PTR(_recid_19657)->dbl);
        DeRefDS(_recid_19657);
        _recid_19657 = _1;
    }

    /** 	seek(current_db, recid)*/
    _10987 = _18seek(_48current_db_17396, _recid_19657);
    DeRef(_10987);
    _10987 = NOVALUE;

    /** 	data_ptr = get4()*/
    _0 = _data_ptr_19661;
    _data_ptr_19661 = _48get4();
    DeRef(_0);

    /** 	seek(current_db, data_ptr-4)*/
    if (IS_ATOM_INT(_data_ptr_19661)) {
        _10944 = _data_ptr_19661 - 4;
        if ((long)((unsigned long)_10944 +(unsigned long) HIGH_BITS) >= 0){
            _10944 = NewDouble((double)_10944);
        }
    }
    else {
        _10944 = NewDouble(DBL_PTR(_data_ptr_19661)->dbl - (double)4);
    }
    _10986 = _18seek(_48current_db_17396, _10944);
    _10944 = NOVALUE;
    DeRef(_10986);
    _10986 = NOVALUE;

    /** 	old_size = get4()-4*/
    _10945 = _48get4();
    DeRef(_old_size_19659);
    if (IS_ATOM_INT(_10945)) {
        _old_size_19659 = _10945 - 4;
        if ((long)((unsigned long)_old_size_19659 +(unsigned long) HIGH_BITS) >= 0){
            _old_size_19659 = NewDouble((double)_old_size_19659);
        }
    }
    else {
        _old_size_19659 = binary_op(MINUS, _10945, 4);
    }
    DeRef(_10945);
    _10945 = NOVALUE;

    /** 	data_string = compress(data)*/
    _0 = _data_string_19662;
    _data_string_19662 = _48compress(_data_19658);
    DeRef(_0);

    /** 	new_size = length(data_string)*/
    if (IS_SEQUENCE(_data_string_19662)){
            _new_size_19660 = SEQ_PTR(_data_string_19662)->length;
    }
    else {
        _new_size_19660 = 1;
    }

    /** 	if new_size <= old_size and*/
    if (IS_ATOM_INT(_old_size_19659)) {
        _10949 = (_new_size_19660 <= _old_size_19659);
    }
    else {
        _10949 = ((double)_new_size_19660 <= DBL_PTR(_old_size_19659)->dbl);
    }
    if (_10949 == 0) {
        goto L1; // [62] 92
    }
    if (IS_ATOM_INT(_old_size_19659)) {
        _10951 = _old_size_19659 - 16;
        if ((long)((unsigned long)_10951 +(unsigned long) HIGH_BITS) >= 0){
            _10951 = NewDouble((double)_10951);
        }
    }
    else {
        _10951 = NewDouble(DBL_PTR(_old_size_19659)->dbl - (double)16);
    }
    if (IS_ATOM_INT(_10951)) {
        _10952 = (_new_size_19660 >= _10951);
    }
    else {
        _10952 = ((double)_new_size_19660 >= DBL_PTR(_10951)->dbl);
    }
    DeRef(_10951);
    _10951 = NOVALUE;
    if (_10952 == 0)
    {
        DeRef(_10952);
        _10952 = NOVALUE;
        goto L1; // [75] 92
    }
    else{
        DeRef(_10952);
        _10952 = NOVALUE;
    }

    /** 		seek(current_db, data_ptr)*/
    Ref(_data_ptr_19661);
    _10985 = _18seek(_48current_db_17396, _data_ptr_19661);
    DeRef(_10985);
    _10985 = NOVALUE;
    goto L2; // [89] 168
L1: 

    /** 		db_free(data_ptr)*/
    Ref(_data_ptr_19661);
    _48db_free(_data_ptr_19661);

    /** 		data_ptr = db_allocate(new_size + 8)*/
    _10953 = _new_size_19660 + 8;
    if ((long)((unsigned long)_10953 + (unsigned long)HIGH_BITS) >= 0) 
    _10953 = NewDouble((double)_10953);
    _0 = _data_ptr_19661;
    _data_ptr_19661 = _48db_allocate(_10953);
    DeRef(_0);
    _10953 = NOVALUE;

    /** 		seek(current_db, recid)*/
    _10984 = _18seek(_48current_db_17396, _recid_19657);
    DeRef(_10984);
    _10984 = NOVALUE;

    /** 		put4(data_ptr)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_48mem0_17438)){
        poke4_addr = (unsigned long *)_48mem0_17438;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_48mem0_17438)->dbl);
    }
    if (IS_ATOM_INT(_data_ptr_19661)) {
        *poke4_addr = (unsigned long)_data_ptr_19661;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_data_ptr_19661)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at111_19682);
    _1 = (int)SEQ_PTR(_48memseq_17673);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at111_19682 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_48current_db_17396, _put4_1__tmp_at111_19682); // DJP 

    /** end procedure*/
    goto L3; // [141] 144
L3: 
    DeRefi(_put4_1__tmp_at111_19682);
    _put4_1__tmp_at111_19682 = NOVALUE;

    /** 		seek(current_db, data_ptr)*/
    Ref(_data_ptr_19661);
    _10983 = _18seek(_48current_db_17396, _data_ptr_19661);
    DeRef(_10983);
    _10983 = NOVALUE;

    /** 		data_string &= repeat( 0, 8 )*/
    _10955 = Repeat(0, 8);
    Concat((object_ptr)&_data_string_19662, _data_string_19662, _10955);
    DeRefDS(_10955);
    _10955 = NOVALUE;
L2: 

    /** 	putn(data_string)*/

    /** 	puts(current_db, s)*/
    EPuts(_48current_db_17396, _data_string_19662); // DJP 

    /** end procedure*/
    goto L4; // [179] 182
L4: 

    /** end procedure*/
    DeRef(_old_size_19659);
    DeRef(_data_ptr_19661);
    DeRef(_data_string_19662);
    DeRef(_10949);
    _10949 = NOVALUE;
    return;
    ;
}



// 0xC6469A2E
