// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int _8positive_int(int _x_341)
{
    int _57 = NOVALUE;
    int _55 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not integer(x) then*/
    if (IS_ATOM_INT(_x_341))
    _55 = 1;
    else if (IS_ATOM_DBL(_x_341))
    _55 = IS_ATOM_INT(DoubleToInt(_x_341));
    else
    _55 = 0;
    if (_55 != 0)
    goto L1; // [6] 16
    _55 = NOVALUE;

    /** 		return 0*/
    DeRef(_x_341);
    return 0;
L1: 

    /**     return x >= 1*/
    if (IS_ATOM_INT(_x_341)) {
        _57 = (_x_341 >= 1);
    }
    else {
        _57 = binary_op(GREATEREQ, _x_341, 1);
    }
    DeRef(_x_341);
    return _57;
    ;
}


int _8machine_addr(int _a_348)
{
    int _66 = NOVALUE;
    int _65 = NOVALUE;
    int _64 = NOVALUE;
    int _62 = NOVALUE;
    int _60 = NOVALUE;
    int _58 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not atom(a) then*/
    _58 = IS_ATOM(_a_348);
    if (_58 != 0)
    goto L1; // [6] 16
    _58 = NOVALUE;

    /** 		return 0*/
    DeRef(_a_348);
    return 0;
L1: 

    /** 	if not integer(a)then*/
    if (IS_ATOM_INT(_a_348))
    _60 = 1;
    else if (IS_ATOM_DBL(_a_348))
    _60 = IS_ATOM_INT(DoubleToInt(_a_348));
    else
    _60 = 0;
    if (_60 != 0)
    goto L2; // [21] 41
    _60 = NOVALUE;

    /** 		if floor(a) != a then*/
    if (IS_ATOM_INT(_a_348))
    _62 = e_floor(_a_348);
    else
    _62 = unary_op(FLOOR, _a_348);
    if (binary_op_a(EQUALS, _62, _a_348)){
        DeRef(_62);
        _62 = NOVALUE;
        goto L3; // [29] 40
    }
    DeRef(_62);
    _62 = NOVALUE;

    /** 			return 0*/
    DeRef(_a_348);
    return 0;
L3: 
L2: 

    /** 	return a > 0 and a <= MAX_ADDR*/
    if (IS_ATOM_INT(_a_348)) {
        _64 = (_a_348 > 0);
    }
    else {
        _64 = binary_op(GREATER, _a_348, 0);
    }
    if (IS_ATOM_INT(_a_348) && IS_ATOM_INT(_8MAX_ADDR_334)) {
        _65 = (_a_348 <= _8MAX_ADDR_334);
    }
    else {
        _65 = binary_op(LESSEQ, _a_348, _8MAX_ADDR_334);
    }
    if (IS_ATOM_INT(_64) && IS_ATOM_INT(_65)) {
        _66 = (_64 != 0 && _65 != 0);
    }
    else {
        _66 = binary_op(AND, _64, _65);
    }
    DeRef(_64);
    _64 = NOVALUE;
    DeRef(_65);
    _65 = NOVALUE;
    DeRef(_a_348);
    return _66;
    ;
}


void _8deallocate(int _addr_363)
{
    int _0, _1, _2;
    

    /** 	ifdef DATA_EXECUTE and WINDOWS then*/

    /**    	machine_proc( memconst:M_FREE, addr)*/
    machine(17, _addr_363);

    /** end procedure*/
    DeRef(_addr_363);
    return;
    ;
}


void _8register_block(int _block_addr_370, int _block_len_371, int _protection_372)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_protection_372)) {
        _1 = (long)(DBL_PTR(_protection_372)->dbl);
        DeRefDS(_protection_372);
        _protection_372 = _1;
    }

    /** end procedure*/
    return;
    ;
}


void _8unregister_block(int _block_addr_376)
{
    int _0, _1, _2;
    

    /** end procedure*/
    return;
    ;
}


int _8safe_address(int _start_380, int _len_381, int _action_382)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_len_381)) {
        _1 = (long)(DBL_PTR(_len_381)->dbl);
        DeRefDS(_len_381);
        _len_381 = _1;
    }

    /** 	return 1*/
    return 1;
    ;
}


void _8check_all_blocks()
{
    int _0, _1, _2;
    

    /** end procedure*/
    return;
    ;
}


int _8prepare_block(int _addr_389, int _a_390, int _protection_391)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_a_390)) {
        _1 = (long)(DBL_PTR(_a_390)->dbl);
        DeRefDS(_a_390);
        _a_390 = _1;
    }
    if (!IS_ATOM_INT(_protection_391)) {
        _1 = (long)(DBL_PTR(_protection_391)->dbl);
        DeRefDS(_protection_391);
        _protection_391 = _1;
    }

    /** 	return addr*/
    return _addr_389;
    ;
}


int _8bordered_address(int _addr_399)
{
    int _71 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not atom(addr) then*/
    _71 = IS_ATOM(_addr_399);
    if (_71 != 0)
    goto L1; // [6] 16
    _71 = NOVALUE;

    /** 		return 0*/
    DeRef(_addr_399);
    return 0;
L1: 

    /** 	return 1*/
    DeRef(_addr_399);
    return 1;
    ;
}


int _8dep_works()
{
    int _73 = NOVALUE;
    int _0, _1, _2;
    

    /** 	ifdef WINDOWS then*/

    /** 		return (DEP_really_works and use_DEP)*/
    _73 = (_7DEP_really_works_305 != 0 && 1 != 0);
    return _73;

    /** 	return 1*/
    _73 = NOVALUE;
    return 1;
    ;
}


void _8free_code(int _addr_411, int _size_412, int _wordsize_414)
{
    int _77 = NOVALUE;
    int _76 = NOVALUE;
    int _75 = NOVALUE;
    int _74 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_size_412)) {
        _1 = (long)(DBL_PTR(_size_412)->dbl);
        DeRefDS(_size_412);
        _size_412 = _1;
    }

    /** 		if dep_works() then*/
    _74 = _8dep_works();
    if (_74 == 0) {
        DeRef(_74);
        _74 = NOVALUE;
        goto L1; // [8] 35
    }
    else {
        if (!IS_ATOM_INT(_74) && DBL_PTR(_74)->dbl == 0.0){
            DeRef(_74);
            _74 = NOVALUE;
            goto L1; // [8] 35
        }
        DeRef(_74);
        _74 = NOVALUE;
    }
    DeRef(_74);
    _74 = NOVALUE;

    /** 			c_func(VirtualFree_rid, { addr, size*wordsize, MEM_RELEASE })*/
    if (IS_ATOM_INT(_wordsize_414)) {
        if (_size_412 == (short)_size_412 && _wordsize_414 <= INT15 && _wordsize_414 >= -INT15)
        _75 = _size_412 * _wordsize_414;
        else
        _75 = NewDouble(_size_412 * (double)_wordsize_414);
    }
    else {
        _75 = binary_op(MULTIPLY, _size_412, _wordsize_414);
    }
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_addr_411);
    *((int *)(_2+4)) = _addr_411;
    *((int *)(_2+8)) = _75;
    *((int *)(_2+12)) = 32768;
    _76 = MAKE_SEQ(_1);
    _75 = NOVALUE;
    _77 = call_c(1, _8VirtualFree_rid_408, _76);
    DeRefDS(_76);
    _76 = NOVALUE;
    goto L2; // [32] 41
L1: 

    /** 			machine_proc( memconst:M_FREE, addr)*/
    machine(17, _addr_411);
L2: 

    /** end procedure*/
    DeRef(_addr_411);
    DeRef(_wordsize_414);
    DeRef(_77);
    _77 = NOVALUE;
    return;
    ;
}



// 0x5C7A0AEE
