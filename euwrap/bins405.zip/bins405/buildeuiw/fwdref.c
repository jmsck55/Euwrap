// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

void _29clear_fwd_refs()
{
    int _0, _1, _2;
    

    /** 	fwdref_count = 0*/
    _29fwdref_count_61552 = 0;

    /** end procedure*/
    return;
    ;
}


int _29get_fwdref_count()
{
    int _0, _1, _2;
    

    /** 	return fwdref_count*/
    return _29fwdref_count_61552;
    ;
}


void _29set_glabel_block(int _ref_61559, int _block_61561)
{
    int _30809 = NOVALUE;
    int _30808 = NOVALUE;
    int _30806 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_ref_61559)) {
        _1 = (long)(DBL_PTR(_ref_61559)->dbl);
        DeRefDS(_ref_61559);
        _ref_61559 = _1;
    }
    if (!IS_ATOM_INT(_block_61561)) {
        _1 = (long)(DBL_PTR(_block_61561)->dbl);
        DeRefDS(_block_61561);
        _block_61561 = _1;
    }

    /** 	forward_references[ref][FR_DATA] &= block*/
    _2 = (int)SEQ_PTR(_29forward_references_61532);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29forward_references_61532 = MAKE_SEQ(_2);
    }
    _3 = (int)(_ref_61559 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    _30808 = (int)*(((s1_ptr)_2)->base + 12);
    _30806 = NOVALUE;
    if (IS_SEQUENCE(_30808) && IS_ATOM(_block_61561)) {
        Append(&_30809, _30808, _block_61561);
    }
    else if (IS_ATOM(_30808) && IS_SEQUENCE(_block_61561)) {
    }
    else {
        Concat((object_ptr)&_30809, _30808, _block_61561);
        _30808 = NOVALUE;
    }
    _30808 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 12);
    _1 = *(int *)_2;
    *(int *)_2 = _30809;
    if( _1 != _30809 ){
        DeRef(_1);
    }
    _30809 = NOVALUE;
    _30806 = NOVALUE;

    /** end procedure*/
    return;
    ;
}


void _29replace_code(int _code_61573, int _start_61574, int _finish_61575, int _subprog_61576)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_finish_61575)) {
        _1 = (long)(DBL_PTR(_finish_61575)->dbl);
        DeRefDS(_finish_61575);
        _finish_61575 = _1;
    }
    if (!IS_ATOM_INT(_subprog_61576)) {
        _1 = (long)(DBL_PTR(_subprog_61576)->dbl);
        DeRefDS(_subprog_61576);
        _subprog_61576 = _1;
    }

    /** 	shifting_sub = subprog*/
    _29shifting_sub_61551 = _subprog_61576;

    /** 	shift:replace_code( code, start, finish )*/
    RefDS(_code_61573);
    _64replace_code(_code_61573, _start_61574, _finish_61575);

    /** 	shifting_sub = 0*/
    _29shifting_sub_61551 = 0;

    /** end procedure*/
    DeRefDS(_code_61573);
    return;
    ;
}


void _29resolved_reference(int _ref_61579)
{
    int _file_61580 = NOVALUE;
    int _subprog_61583 = NOVALUE;
    int _tx_61586 = NOVALUE;
    int _ax_61587 = NOVALUE;
    int _sp_61588 = NOVALUE;
    int _r_61603 = NOVALUE;
    int _r_61621 = NOVALUE;
    int _30833 = NOVALUE;
    int _30832 = NOVALUE;
    int _30831 = NOVALUE;
    int _30829 = NOVALUE;
    int _30826 = NOVALUE;
    int _30824 = NOVALUE;
    int _30822 = NOVALUE;
    int _30821 = NOVALUE;
    int _30819 = NOVALUE;
    int _30817 = NOVALUE;
    int _30815 = NOVALUE;
    int _30814 = NOVALUE;
    int _30812 = NOVALUE;
    int _30810 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 		file    = forward_references[ref][FR_FILE],*/
    _2 = (int)SEQ_PTR(_29forward_references_61532);
    _30810 = (int)*(((s1_ptr)_2)->base + _ref_61579);
    _2 = (int)SEQ_PTR(_30810);
    _file_61580 = (int)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_file_61580)){
        _file_61580 = (long)DBL_PTR(_file_61580)->dbl;
    }
    _30810 = NOVALUE;

    /** 		subprog = forward_references[ref][FR_SUBPROG]*/
    _2 = (int)SEQ_PTR(_29forward_references_61532);
    _30812 = (int)*(((s1_ptr)_2)->base + _ref_61579);
    _2 = (int)SEQ_PTR(_30812);
    _subprog_61583 = (int)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_subprog_61583)){
        _subprog_61583 = (long)DBL_PTR(_subprog_61583)->dbl;
    }
    _30812 = NOVALUE;

    /** 		tx = 0,*/
    _tx_61586 = 0;

    /** 		ax = 0,*/
    _ax_61587 = 0;

    /** 		sp = 0*/
    _sp_61588 = 0;

    /** 	if forward_references[ref][FR_SUBPROG] = TopLevelSub then*/
    _2 = (int)SEQ_PTR(_29forward_references_61532);
    _30814 = (int)*(((s1_ptr)_2)->base + _ref_61579);
    _2 = (int)SEQ_PTR(_30814);
    _30815 = (int)*(((s1_ptr)_2)->base + 4);
    _30814 = NOVALUE;
    if (binary_op_a(NOTEQ, _30815, _26TopLevelSub_11989)){
        _30815 = NOVALUE;
        goto L1; // [60] 80
    }
    _30815 = NOVALUE;

    /** 		tx = find( ref, toplevel_references[file] )*/
    _2 = (int)SEQ_PTR(_29toplevel_references_61535);
    _30817 = (int)*(((s1_ptr)_2)->base + _file_61580);
    _tx_61586 = find_from(_ref_61579, _30817, 1);
    _30817 = NOVALUE;
    goto L2; // [77] 111
L1: 

    /** 		sp = find( subprog, active_subprogs[file] )*/
    _2 = (int)SEQ_PTR(_29active_subprogs_61533);
    _30819 = (int)*(((s1_ptr)_2)->base + _file_61580);
    _sp_61588 = find_from(_subprog_61583, _30819, 1);
    _30819 = NOVALUE;

    /** 		ax = find( ref, active_references[file][sp] )*/
    _2 = (int)SEQ_PTR(_29active_references_61534);
    _30821 = (int)*(((s1_ptr)_2)->base + _file_61580);
    _2 = (int)SEQ_PTR(_30821);
    _30822 = (int)*(((s1_ptr)_2)->base + _sp_61588);
    _30821 = NOVALUE;
    _ax_61587 = find_from(_ref_61579, _30822, 1);
    _30822 = NOVALUE;
L2: 

    /** 	if ax then*/
    if (_ax_61587 == 0)
    {
        goto L3; // [113] 253
    }
    else{
    }

    /** 		sequence r = active_references[file][sp] */
    _2 = (int)SEQ_PTR(_29active_references_61534);
    _30824 = (int)*(((s1_ptr)_2)->base + _file_61580);
    DeRef(_r_61603);
    _2 = (int)SEQ_PTR(_30824);
    _r_61603 = (int)*(((s1_ptr)_2)->base + _sp_61588);
    Ref(_r_61603);
    _30824 = NOVALUE;

    /** 		active_references[file][sp] = 0*/
    _2 = (int)SEQ_PTR(_29active_references_61534);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29active_references_61534 = MAKE_SEQ(_2);
    }
    _3 = (int)(_file_61580 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _sp_61588);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _30826 = NOVALUE;

    /** 		r = remove( r, ax )*/
    {
        s1_ptr assign_space = SEQ_PTR(_r_61603);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_ax_61587)) ? _ax_61587 : (long)(DBL_PTR(_ax_61587)->dbl);
        int stop = (IS_ATOM_INT(_ax_61587)) ? _ax_61587 : (long)(DBL_PTR(_ax_61587)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_r_61603), start, &_r_61603 );
            }
            else Tail(SEQ_PTR(_r_61603), stop+1, &_r_61603);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_r_61603), start, &_r_61603);
        }
        else {
            assign_slice_seq = &assign_space;
            _r_61603 = Remove_elements(start, stop, (SEQ_PTR(_r_61603)->ref == 1));
        }
    }

    /** 		active_references[file][sp] = r*/
    _2 = (int)SEQ_PTR(_29active_references_61534);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29active_references_61534 = MAKE_SEQ(_2);
    }
    _3 = (int)(_file_61580 + ((s1_ptr)_2)->base);
    RefDS(_r_61603);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _sp_61588);
    _1 = *(int *)_2;
    *(int *)_2 = _r_61603;
    DeRef(_1);
    _30829 = NOVALUE;

    /** 		if not length( active_references[file][sp] ) then*/
    _2 = (int)SEQ_PTR(_29active_references_61534);
    _30831 = (int)*(((s1_ptr)_2)->base + _file_61580);
    _2 = (int)SEQ_PTR(_30831);
    _30832 = (int)*(((s1_ptr)_2)->base + _sp_61588);
    _30831 = NOVALUE;
    if (IS_SEQUENCE(_30832)){
            _30833 = SEQ_PTR(_30832)->length;
    }
    else {
        _30833 = 1;
    }
    _30832 = NOVALUE;
    if (_30833 != 0)
    goto L4; // [178] 248
    _30833 = NOVALUE;

    /** 			r = active_references[file]*/
    DeRefDS(_r_61603);
    _2 = (int)SEQ_PTR(_29active_references_61534);
    _r_61603 = (int)*(((s1_ptr)_2)->base + _file_61580);
    Ref(_r_61603);

    /** 			active_references[file] = 0*/
    _2 = (int)SEQ_PTR(_29active_references_61534);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29active_references_61534 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _file_61580);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 			r = remove( r, sp )*/
    {
        s1_ptr assign_space = SEQ_PTR(_r_61603);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_sp_61588)) ? _sp_61588 : (long)(DBL_PTR(_sp_61588)->dbl);
        int stop = (IS_ATOM_INT(_sp_61588)) ? _sp_61588 : (long)(DBL_PTR(_sp_61588)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_r_61603), start, &_r_61603 );
            }
            else Tail(SEQ_PTR(_r_61603), stop+1, &_r_61603);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_r_61603), start, &_r_61603);
        }
        else {
            assign_slice_seq = &assign_space;
            _r_61603 = Remove_elements(start, stop, (SEQ_PTR(_r_61603)->ref == 1));
        }
    }

    /** 			active_references[file] = r*/
    RefDS(_r_61603);
    _2 = (int)SEQ_PTR(_29active_references_61534);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29active_references_61534 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _file_61580);
    _1 = *(int *)_2;
    *(int *)_2 = _r_61603;
    DeRef(_1);

    /** 			r = active_subprogs[file]*/
    DeRefDS(_r_61603);
    _2 = (int)SEQ_PTR(_29active_subprogs_61533);
    _r_61603 = (int)*(((s1_ptr)_2)->base + _file_61580);
    Ref(_r_61603);

    /** 			active_subprogs[file] = 0*/
    _2 = (int)SEQ_PTR(_29active_subprogs_61533);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29active_subprogs_61533 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _file_61580);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 			r = remove( r,   sp )*/
    {
        s1_ptr assign_space = SEQ_PTR(_r_61603);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_sp_61588)) ? _sp_61588 : (long)(DBL_PTR(_sp_61588)->dbl);
        int stop = (IS_ATOM_INT(_sp_61588)) ? _sp_61588 : (long)(DBL_PTR(_sp_61588)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_r_61603), start, &_r_61603 );
            }
            else Tail(SEQ_PTR(_r_61603), stop+1, &_r_61603);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_r_61603), start, &_r_61603);
        }
        else {
            assign_slice_seq = &assign_space;
            _r_61603 = Remove_elements(start, stop, (SEQ_PTR(_r_61603)->ref == 1));
        }
    }

    /** 			active_subprogs[file] = r*/
    RefDS(_r_61603);
    _2 = (int)SEQ_PTR(_29active_subprogs_61533);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29active_subprogs_61533 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _file_61580);
    _1 = *(int *)_2;
    *(int *)_2 = _r_61603;
    DeRef(_1);
L4: 
    DeRef(_r_61603);
    _r_61603 = NOVALUE;
    goto L5; // [250] 303
L3: 

    /** 	elsif tx then*/
    if (_tx_61586 == 0)
    {
        goto L6; // [255] 296
    }
    else{
    }

    /** 		sequence r = toplevel_references[file]*/
    DeRef(_r_61621);
    _2 = (int)SEQ_PTR(_29toplevel_references_61535);
    _r_61621 = (int)*(((s1_ptr)_2)->base + _file_61580);
    Ref(_r_61621);

    /** 		toplevel_references[file] = 0*/
    _2 = (int)SEQ_PTR(_29toplevel_references_61535);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29toplevel_references_61535 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _file_61580);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 		r = remove( r, tx )*/
    {
        s1_ptr assign_space = SEQ_PTR(_r_61621);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_tx_61586)) ? _tx_61586 : (long)(DBL_PTR(_tx_61586)->dbl);
        int stop = (IS_ATOM_INT(_tx_61586)) ? _tx_61586 : (long)(DBL_PTR(_tx_61586)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_r_61621), start, &_r_61621 );
            }
            else Tail(SEQ_PTR(_r_61621), stop+1, &_r_61621);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_r_61621), start, &_r_61621);
        }
        else {
            assign_slice_seq = &assign_space;
            _r_61621 = Remove_elements(start, stop, (SEQ_PTR(_r_61621)->ref == 1));
        }
    }

    /** 		toplevel_references[file] = r*/
    RefDS(_r_61621);
    _2 = (int)SEQ_PTR(_29toplevel_references_61535);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29toplevel_references_61535 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _file_61580);
    _1 = *(int *)_2;
    *(int *)_2 = _r_61621;
    DeRef(_1);
    DeRefDS(_r_61621);
    _r_61621 = NOVALUE;
    goto L5; // [293] 303
L6: 

    /** 		InternalErr( 260 )*/
    RefDS(_22037);
    _43InternalErr(260, _22037);
L5: 

    /** 	inactive_references &= ref*/
    Append(&_29inactive_references_61536, _29inactive_references_61536, _ref_61579);

    /** 	forward_references[ref] = 0*/
    _2 = (int)SEQ_PTR(_29forward_references_61532);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29forward_references_61532 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _ref_61579);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** end procedure*/
    _30832 = NOVALUE;
    return;
    ;
}


void _29set_code(int _ref_61635)
{
    int _30849 = NOVALUE;
    int _30847 = NOVALUE;
    int _30845 = NOVALUE;
    int _30842 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	patch_code_sub = forward_references[ref][FR_SUBPROG]*/
    _2 = (int)SEQ_PTR(_29forward_references_61532);
    _30842 = (int)*(((s1_ptr)_2)->base + _ref_61635);
    _2 = (int)SEQ_PTR(_30842);
    _29patch_code_sub_61630 = (int)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_29patch_code_sub_61630)){
        _29patch_code_sub_61630 = (long)DBL_PTR(_29patch_code_sub_61630)->dbl;
    }
    _30842 = NOVALUE;

    /** 	if patch_code_sub != CurrentSub then*/
    if (_29patch_code_sub_61630 == _26CurrentSub_11990)
    goto L1; // [23] 119

    /** 		patch_code_temp = Code*/
    RefDS(_26Code_12071);
    DeRef(_29patch_code_temp_61627);
    _29patch_code_temp_61627 = _26Code_12071;

    /** 		patch_linetab_temp = LineTable*/
    RefDS(_26LineTable_12072);
    DeRef(_29patch_linetab_temp_61628);
    _29patch_linetab_temp_61628 = _26LineTable_12072;

    /** 		Code = SymTab[patch_code_sub][S_CODE]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _30845 = (int)*(((s1_ptr)_2)->base + _29patch_code_sub_61630);
    DeRefDS(_26Code_12071);
    _2 = (int)SEQ_PTR(_30845);
    if (!IS_ATOM_INT(_26S_CODE_11666)){
        _26Code_12071 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_CODE_11666)->dbl));
    }
    else{
        _26Code_12071 = (int)*(((s1_ptr)_2)->base + _26S_CODE_11666);
    }
    Ref(_26Code_12071);
    _30845 = NOVALUE;

    /** 		SymTab[patch_code_sub][S_CODE] = 0*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_29patch_code_sub_61630 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_26S_CODE_11666))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_CODE_11666)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _26S_CODE_11666);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _30847 = NOVALUE;

    /** 		LineTable = SymTab[patch_code_sub][S_LINETAB]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _30849 = (int)*(((s1_ptr)_2)->base + _29patch_code_sub_61630);
    DeRefDS(_26LineTable_12072);
    _2 = (int)SEQ_PTR(_30849);
    if (!IS_ATOM_INT(_26S_LINETAB_11689)){
        _26LineTable_12072 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_LINETAB_11689)->dbl));
    }
    else{
        _26LineTable_12072 = (int)*(((s1_ptr)_2)->base + _26S_LINETAB_11689);
    }
    Ref(_26LineTable_12072);
    _30849 = NOVALUE;

    /** 		patch_current_sub = CurrentSub*/
    _29patch_current_sub_61632 = _26CurrentSub_11990;

    /** 		CurrentSub = patch_code_sub*/
    _26CurrentSub_11990 = _29patch_code_sub_61630;
    goto L2; // [116] 129
L1: 

    /** 		patch_current_sub = patch_code_sub*/
    _29patch_current_sub_61632 = _29patch_code_sub_61630;
L2: 

    /** end procedure*/
    return;
    ;
}


void _29reset_code()
{
    int _30853 = NOVALUE;
    int _30851 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	SymTab[patch_code_sub][S_CODE] = Code*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_29patch_code_sub_61630 + ((s1_ptr)_2)->base);
    RefDS(_26Code_12071);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_26S_CODE_11666))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_CODE_11666)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _26S_CODE_11666);
    _1 = *(int *)_2;
    *(int *)_2 = _26Code_12071;
    DeRef(_1);
    _30851 = NOVALUE;

    /** 	SymTab[patch_code_sub][S_LINETAB] = LineTable*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_29patch_code_sub_61630 + ((s1_ptr)_2)->base);
    RefDS(_26LineTable_12072);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_26S_LINETAB_11689))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_LINETAB_11689)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _26S_LINETAB_11689);
    _1 = *(int *)_2;
    *(int *)_2 = _26LineTable_12072;
    DeRef(_1);
    _30853 = NOVALUE;

    /** 	if patch_code_sub != patch_current_sub then*/
    if (_29patch_code_sub_61630 == _29patch_current_sub_61632)
    goto L1; // [45] 77

    /** 		CurrentSub = patch_current_sub*/
    _26CurrentSub_11990 = _29patch_current_sub_61632;

    /** 		Code = patch_code_temp*/
    RefDS(_29patch_code_temp_61627);
    DeRefDS(_26Code_12071);
    _26Code_12071 = _29patch_code_temp_61627;

    /** 		LineTable = patch_linetab_temp*/
    RefDS(_29patch_linetab_temp_61628);
    DeRefDS(_26LineTable_12072);
    _26LineTable_12072 = _29patch_linetab_temp_61628;
L1: 

    /** 	patch_code_temp = {}*/
    RefDS(_22037);
    DeRef(_29patch_code_temp_61627);
    _29patch_code_temp_61627 = _22037;

    /** 	patch_linetab_temp = {}*/
    RefDS(_22037);
    DeRef(_29patch_linetab_temp_61628);
    _29patch_linetab_temp_61628 = _22037;

    /** end procedure*/
    return;
    ;
}


void _29set_data(int _ref_61679, int _data_61680)
{
    int _30856 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_ref_61679)) {
        _1 = (long)(DBL_PTR(_ref_61679)->dbl);
        DeRefDS(_ref_61679);
        _ref_61679 = _1;
    }

    /** 	forward_references[ref][FR_DATA] = data*/
    _2 = (int)SEQ_PTR(_29forward_references_61532);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29forward_references_61532 = MAKE_SEQ(_2);
    }
    _3 = (int)(_ref_61679 + ((s1_ptr)_2)->base);
    Ref(_data_61680);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 12);
    _1 = *(int *)_2;
    *(int *)_2 = _data_61680;
    DeRef(_1);
    _30856 = NOVALUE;

    /** end procedure*/
    DeRef(_data_61680);
    return;
    ;
}


void _29add_data(int _ref_61685, int _data_61686)
{
    int _30862 = NOVALUE;
    int _30861 = NOVALUE;
    int _30860 = NOVALUE;
    int _30858 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_ref_61685)) {
        _1 = (long)(DBL_PTR(_ref_61685)->dbl);
        DeRefDS(_ref_61685);
        _ref_61685 = _1;
    }

    /** 	forward_references[ref][FR_DATA] = append( forward_references[ref][FR_DATA], data )*/
    _2 = (int)SEQ_PTR(_29forward_references_61532);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29forward_references_61532 = MAKE_SEQ(_2);
    }
    _3 = (int)(_ref_61685 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_29forward_references_61532);
    _30860 = (int)*(((s1_ptr)_2)->base + _ref_61685);
    _2 = (int)SEQ_PTR(_30860);
    _30861 = (int)*(((s1_ptr)_2)->base + 12);
    _30860 = NOVALUE;
    Ref(_data_61686);
    Append(&_30862, _30861, _data_61686);
    _30861 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 12);
    _1 = *(int *)_2;
    *(int *)_2 = _30862;
    if( _1 != _30862 ){
        DeRef(_1);
    }
    _30862 = NOVALUE;
    _30858 = NOVALUE;

    /** end procedure*/
    DeRef(_data_61686);
    return;
    ;
}


void _29set_line(int _ref_61694, int _line_no_61695, int _this_line_61696, int _bp_61697)
{
    int _30867 = NOVALUE;
    int _30865 = NOVALUE;
    int _30863 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_ref_61694)) {
        _1 = (long)(DBL_PTR(_ref_61694)->dbl);
        DeRefDS(_ref_61694);
        _ref_61694 = _1;
    }
    if (!IS_ATOM_INT(_line_no_61695)) {
        _1 = (long)(DBL_PTR(_line_no_61695)->dbl);
        DeRefDS(_line_no_61695);
        _line_no_61695 = _1;
    }
    if (!IS_ATOM_INT(_bp_61697)) {
        _1 = (long)(DBL_PTR(_bp_61697)->dbl);
        DeRefDS(_bp_61697);
        _bp_61697 = _1;
    }

    /** 	forward_references[ref][FR_LINE] = line_no*/
    _2 = (int)SEQ_PTR(_29forward_references_61532);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29forward_references_61532 = MAKE_SEQ(_2);
    }
    _3 = (int)(_ref_61694 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 6);
    _1 = *(int *)_2;
    *(int *)_2 = _line_no_61695;
    DeRef(_1);
    _30863 = NOVALUE;

    /** 	forward_references[ref][FR_THISLINE] = this_line*/
    _2 = (int)SEQ_PTR(_29forward_references_61532);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29forward_references_61532 = MAKE_SEQ(_2);
    }
    _3 = (int)(_ref_61694 + ((s1_ptr)_2)->base);
    RefDS(_this_line_61696);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 7);
    _1 = *(int *)_2;
    *(int *)_2 = _this_line_61696;
    DeRef(_1);
    _30865 = NOVALUE;

    /** 	forward_references[ref][FR_BP] = bp*/
    _2 = (int)SEQ_PTR(_29forward_references_61532);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29forward_references_61532 = MAKE_SEQ(_2);
    }
    _3 = (int)(_ref_61694 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 8);
    _1 = *(int *)_2;
    *(int *)_2 = _bp_61697;
    DeRef(_1);
    _30867 = NOVALUE;

    /** end procedure*/
    DeRefDS(_this_line_61696);
    return;
    ;
}


void _29add_private_symbol(int _sym_61709, int _name_61710)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_sym_61709)) {
        _1 = (long)(DBL_PTR(_sym_61709)->dbl);
        DeRefDS(_sym_61709);
        _sym_61709 = _1;
    }

    /** 	fwd_private_sym &= sym*/
    Append(&_29fwd_private_sym_61704, _29fwd_private_sym_61704, _sym_61709);

    /** 	fwd_private_name = append( fwd_private_name, name )*/
    RefDS(_name_61710);
    Append(&_29fwd_private_name_61705, _29fwd_private_name_61705, _name_61710);

    /** end procedure*/
    DeRefDS(_name_61710);
    return;
    ;
}


void _29patch_forward_goto(int _tok_61718, int _ref_61719)
{
    int _fr_61720 = NOVALUE;
    int _30883 = NOVALUE;
    int _30882 = NOVALUE;
    int _30881 = NOVALUE;
    int _30880 = NOVALUE;
    int _30879 = NOVALUE;
    int _30878 = NOVALUE;
    int _30877 = NOVALUE;
    int _30876 = NOVALUE;
    int _30874 = NOVALUE;
    int _30873 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence fr = forward_references[ref]*/
    DeRef(_fr_61720);
    _2 = (int)SEQ_PTR(_29forward_references_61532);
    _fr_61720 = (int)*(((s1_ptr)_2)->base + _ref_61719);
    Ref(_fr_61720);

    /** 	set_code( ref )*/
    _29set_code(_ref_61719);

    /** 	shifting_sub = fr[FR_SUBPROG]*/
    _2 = (int)SEQ_PTR(_fr_61720);
    _29shifting_sub_61551 = (int)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_29shifting_sub_61551))
    _29shifting_sub_61551 = (long)DBL_PTR(_29shifting_sub_61551)->dbl;

    /** 	if length( fr[FR_DATA] ) = 2 then*/
    _2 = (int)SEQ_PTR(_fr_61720);
    _30873 = (int)*(((s1_ptr)_2)->base + 12);
    if (IS_SEQUENCE(_30873)){
            _30874 = SEQ_PTR(_30873)->length;
    }
    else {
        _30874 = 1;
    }
    _30873 = NOVALUE;
    if (_30874 != 2)
    goto L1; // [33] 62

    /** 		prep_forward_error( ref )*/
    _29prep_forward_error(_ref_61719);

    /** 		CompileErr( 156, { fr[FR_DATA][2] })*/
    _2 = (int)SEQ_PTR(_fr_61720);
    _30876 = (int)*(((s1_ptr)_2)->base + 12);
    _2 = (int)SEQ_PTR(_30876);
    _30877 = (int)*(((s1_ptr)_2)->base + 2);
    _30876 = NOVALUE;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_30877);
    *((int *)(_2+4)) = _30877;
    _30878 = MAKE_SEQ(_1);
    _30877 = NOVALUE;
    _43CompileErr(156, _30878, 0);
    _30878 = NOVALUE;
L1: 

    /** 	Goto_block(  fr[FR_DATA][1], fr[FR_DATA][3], fr[FR_PC] )*/
    _2 = (int)SEQ_PTR(_fr_61720);
    _30879 = (int)*(((s1_ptr)_2)->base + 12);
    _2 = (int)SEQ_PTR(_30879);
    _30880 = (int)*(((s1_ptr)_2)->base + 1);
    _30879 = NOVALUE;
    _2 = (int)SEQ_PTR(_fr_61720);
    _30881 = (int)*(((s1_ptr)_2)->base + 12);
    _2 = (int)SEQ_PTR(_30881);
    _30882 = (int)*(((s1_ptr)_2)->base + 3);
    _30881 = NOVALUE;
    _2 = (int)SEQ_PTR(_fr_61720);
    _30883 = (int)*(((s1_ptr)_2)->base + 5);
    Ref(_30880);
    Ref(_30882);
    Ref(_30883);
    _65Goto_block(_30880, _30882, _30883);
    _30880 = NOVALUE;
    _30882 = NOVALUE;
    _30883 = NOVALUE;

    /** 	shifting_sub = 0*/
    _29shifting_sub_61551 = 0;

    /** 	reset_code()*/
    _29reset_code();

    /** 	resolved_reference( ref )*/
    _29resolved_reference(_ref_61719);

    /** end procedure*/
    DeRefDS(_fr_61720);
    _30873 = NOVALUE;
    return;
    ;
}


void _29patch_forward_call(int _tok_61741, int _ref_61742)
{
    int _fr_61743 = NOVALUE;
    int _sub_61746 = NOVALUE;
    int _defarg_61752 = NOVALUE;
    int _paramsym_61756 = NOVALUE;
    int _old_61759 = NOVALUE;
    int _tx_61763 = NOVALUE;
    int _code_sub_61773 = NOVALUE;
    int _args_61775 = NOVALUE;
    int _is_func_61780 = NOVALUE;
    int _real_file_61794 = NOVALUE;
    int _code_61798 = NOVALUE;
    int _temp_sub_61800 = NOVALUE;
    int _pc_61802 = NOVALUE;
    int _next_pc_61804 = NOVALUE;
    int _supplied_args_61805 = NOVALUE;
    int _name_61808 = NOVALUE;
    int _old_temps_allocated_61832 = NOVALUE;
    int _temp_target_61841 = NOVALUE;
    int _converted_code_61844 = NOVALUE;
    int _target_61860 = NOVALUE;
    int _has_defaults_61866 = NOVALUE;
    int _goto_target_61867 = NOVALUE;
    int _defarg_61870 = NOVALUE;
    int _code_len_61871 = NOVALUE;
    int _extra_default_args_61873 = NOVALUE;
    int _param_sym_61876 = NOVALUE;
    int _params_61877 = NOVALUE;
    int _orig_code_61879 = NOVALUE;
    int _orig_linetable_61880 = NOVALUE;
    int _ar_sp_61883 = NOVALUE;
    int _pre_refs_61887 = NOVALUE;
    int _old_fwd_params_61902 = NOVALUE;
    int _temp_shifting_sub_61943 = NOVALUE;
    int _new_code_61947 = NOVALUE;
    int _routine_type_61956 = NOVALUE;
    int _31635 = NOVALUE;
    int _31019 = NOVALUE;
    int _31018 = NOVALUE;
    int _31017 = NOVALUE;
    int _31015 = NOVALUE;
    int _31014 = NOVALUE;
    int _31013 = NOVALUE;
    int _31012 = NOVALUE;
    int _31011 = NOVALUE;
    int _31010 = NOVALUE;
    int _31009 = NOVALUE;
    int _31008 = NOVALUE;
    int _31007 = NOVALUE;
    int _31006 = NOVALUE;
    int _31005 = NOVALUE;
    int _31004 = NOVALUE;
    int _31003 = NOVALUE;
    int _31001 = NOVALUE;
    int _31000 = NOVALUE;
    int _30999 = NOVALUE;
    int _30998 = NOVALUE;
    int _30997 = NOVALUE;
    int _30996 = NOVALUE;
    int _30995 = NOVALUE;
    int _30994 = NOVALUE;
    int _30992 = NOVALUE;
    int _30989 = NOVALUE;
    int _30988 = NOVALUE;
    int _30987 = NOVALUE;
    int _30986 = NOVALUE;
    int _30982 = NOVALUE;
    int _30981 = NOVALUE;
    int _30980 = NOVALUE;
    int _30979 = NOVALUE;
    int _30978 = NOVALUE;
    int _30976 = NOVALUE;
    int _30975 = NOVALUE;
    int _30974 = NOVALUE;
    int _30973 = NOVALUE;
    int _30972 = NOVALUE;
    int _30971 = NOVALUE;
    int _30969 = NOVALUE;
    int _30968 = NOVALUE;
    int _30966 = NOVALUE;
    int _30965 = NOVALUE;
    int _30964 = NOVALUE;
    int _30963 = NOVALUE;
    int _30961 = NOVALUE;
    int _30959 = NOVALUE;
    int _30958 = NOVALUE;
    int _30957 = NOVALUE;
    int _30955 = NOVALUE;
    int _30954 = NOVALUE;
    int _30952 = NOVALUE;
    int _30950 = NOVALUE;
    int _30947 = NOVALUE;
    int _30943 = NOVALUE;
    int _30941 = NOVALUE;
    int _30940 = NOVALUE;
    int _30938 = NOVALUE;
    int _30937 = NOVALUE;
    int _30936 = NOVALUE;
    int _30935 = NOVALUE;
    int _30933 = NOVALUE;
    int _30932 = NOVALUE;
    int _30931 = NOVALUE;
    int _30930 = NOVALUE;
    int _30929 = NOVALUE;
    int _30927 = NOVALUE;
    int _30926 = NOVALUE;
    int _30925 = NOVALUE;
    int _30924 = NOVALUE;
    int _30923 = NOVALUE;
    int _30922 = NOVALUE;
    int _30921 = NOVALUE;
    int _30920 = NOVALUE;
    int _30919 = NOVALUE;
    int _30917 = NOVALUE;
    int _30916 = NOVALUE;
    int _30915 = NOVALUE;
    int _30914 = NOVALUE;
    int _30913 = NOVALUE;
    int _30910 = NOVALUE;
    int _30906 = NOVALUE;
    int _30905 = NOVALUE;
    int _30904 = NOVALUE;
    int _30903 = NOVALUE;
    int _30902 = NOVALUE;
    int _30901 = NOVALUE;
    int _30899 = NOVALUE;
    int _30896 = NOVALUE;
    int _30894 = NOVALUE;
    int _30893 = NOVALUE;
    int _30891 = NOVALUE;
    int _30888 = NOVALUE;
    int _30887 = NOVALUE;
    int _30886 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	sequence fr = forward_references[ref]*/
    DeRef(_fr_61743);
    _2 = (int)SEQ_PTR(_29forward_references_61532);
    _fr_61743 = (int)*(((s1_ptr)_2)->base + _ref_61742);
    Ref(_fr_61743);

    /** 	symtab_index sub = tok[T_SYM]*/
    _2 = (int)SEQ_PTR(_tok_61741);
    _sub_61746 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_sub_61746)){
        _sub_61746 = (long)DBL_PTR(_sub_61746)->dbl;
    }

    /** 	if sequence( fr[FR_DATA] ) then*/
    _2 = (int)SEQ_PTR(_fr_61743);
    _30886 = (int)*(((s1_ptr)_2)->base + 12);
    _30887 = IS_SEQUENCE(_30886);
    _30886 = NOVALUE;
    if (_30887 == 0)
    {
        _30887 = NOVALUE;
        goto L1; // [32] 117
    }
    else{
        _30887 = NOVALUE;
    }

    /** 		sequence defarg = fr[FR_DATA][1]*/
    _2 = (int)SEQ_PTR(_fr_61743);
    _30888 = (int)*(((s1_ptr)_2)->base + 12);
    DeRef(_defarg_61752);
    _2 = (int)SEQ_PTR(_30888);
    _defarg_61752 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_defarg_61752);
    _30888 = NOVALUE;

    /** 		symtab_index paramsym = defarg[2]*/
    _2 = (int)SEQ_PTR(_defarg_61752);
    _paramsym_61756 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_paramsym_61756)){
        _paramsym_61756 = (long)DBL_PTR(_paramsym_61756)->dbl;
    }

    /** 		token old = { RECORDED, defarg[3] }*/
    _2 = (int)SEQ_PTR(_defarg_61752);
    _30891 = (int)*(((s1_ptr)_2)->base + 3);
    Ref(_30891);
    DeRef(_old_61759);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 508;
    ((int *)_2)[2] = _30891;
    _old_61759 = MAKE_SEQ(_1);
    _30891 = NOVALUE;

    /** 		integer tx = find( old, SymTab[paramsym][S_CODE] )*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _30893 = (int)*(((s1_ptr)_2)->base + _paramsym_61756);
    _2 = (int)SEQ_PTR(_30893);
    if (!IS_ATOM_INT(_26S_CODE_11666)){
        _30894 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_CODE_11666)->dbl));
    }
    else{
        _30894 = (int)*(((s1_ptr)_2)->base + _26S_CODE_11666);
    }
    _30893 = NOVALUE;
    _tx_61763 = find_from(_old_61759, _30894, 1);
    _30894 = NOVALUE;

    /** 		SymTab[paramsym][S_CODE][tx] = tok*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_paramsym_61756 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(object_ptr)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(object_ptr)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_26S_CODE_11666))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_CODE_11666)->dbl));
    else
    _3 = (int)(_26S_CODE_11666 + ((s1_ptr)_2)->base);
    _30896 = NOVALUE;
    Ref(_tok_61741);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _tx_61763);
    _1 = *(int *)_2;
    *(int *)_2 = _tok_61741;
    DeRef(_1);
    _30896 = NOVALUE;

    /** 		resolved_reference( ref )*/
    _29resolved_reference(_ref_61742);

    /** 		return*/
    DeRefDS(_defarg_61752);
    DeRefDS(_old_61759);
    DeRef(_tok_61741);
    DeRefDS(_fr_61743);
    DeRef(_code_61798);
    DeRef(_name_61808);
    DeRef(_params_61877);
    DeRef(_orig_code_61879);
    DeRef(_orig_linetable_61880);
    DeRef(_old_fwd_params_61902);
    DeRef(_new_code_61947);
    return;
L1: 
    DeRef(_defarg_61752);
    _defarg_61752 = NOVALUE;
    DeRef(_old_61759);
    _old_61759 = NOVALUE;

    /** 	integer code_sub = fr[FR_SUBPROG]*/
    _2 = (int)SEQ_PTR(_fr_61743);
    _code_sub_61773 = (int)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_code_sub_61773))
    _code_sub_61773 = (long)DBL_PTR(_code_sub_61773)->dbl;

    /** 	integer args = SymTab[sub][S_NUM_ARGS]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _30899 = (int)*(((s1_ptr)_2)->base + _sub_61746);
    _2 = (int)SEQ_PTR(_30899);
    if (!IS_ATOM_INT(_26S_NUM_ARGS_11705)){
        _args_61775 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NUM_ARGS_11705)->dbl));
    }
    else{
        _args_61775 = (int)*(((s1_ptr)_2)->base + _26S_NUM_ARGS_11705);
    }
    if (!IS_ATOM_INT(_args_61775)){
        _args_61775 = (long)DBL_PTR(_args_61775)->dbl;
    }
    _30899 = NOVALUE;

    /** 	integer is_func = (SymTab[sub][S_TOKEN] = FUNC) or (SymTab[sub][S_TOKEN] = TYPE)*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _30901 = (int)*(((s1_ptr)_2)->base + _sub_61746);
    _2 = (int)SEQ_PTR(_30901);
    if (!IS_ATOM_INT(_26S_TOKEN_11659)){
        _30902 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_TOKEN_11659)->dbl));
    }
    else{
        _30902 = (int)*(((s1_ptr)_2)->base + _26S_TOKEN_11659);
    }
    _30901 = NOVALUE;
    if (IS_ATOM_INT(_30902)) {
        _30903 = (_30902 == 501);
    }
    else {
        _30903 = binary_op(EQUALS, _30902, 501);
    }
    _30902 = NOVALUE;
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _30904 = (int)*(((s1_ptr)_2)->base + _sub_61746);
    _2 = (int)SEQ_PTR(_30904);
    if (!IS_ATOM_INT(_26S_TOKEN_11659)){
        _30905 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_TOKEN_11659)->dbl));
    }
    else{
        _30905 = (int)*(((s1_ptr)_2)->base + _26S_TOKEN_11659);
    }
    _30904 = NOVALUE;
    if (IS_ATOM_INT(_30905)) {
        _30906 = (_30905 == 504);
    }
    else {
        _30906 = binary_op(EQUALS, _30905, 504);
    }
    _30905 = NOVALUE;
    if (IS_ATOM_INT(_30903) && IS_ATOM_INT(_30906)) {
        _is_func_61780 = (_30903 != 0 || _30906 != 0);
    }
    else {
        _is_func_61780 = binary_op(OR, _30903, _30906);
    }
    DeRef(_30903);
    _30903 = NOVALUE;
    DeRef(_30906);
    _30906 = NOVALUE;
    if (!IS_ATOM_INT(_is_func_61780)) {
        _1 = (long)(DBL_PTR(_is_func_61780)->dbl);
        DeRefDS(_is_func_61780);
        _is_func_61780 = _1;
    }

    /** 	integer real_file = current_file_no*/
    _real_file_61794 = _26current_file_no_11982;

    /** 	current_file_no = fr[FR_FILE]*/
    _2 = (int)SEQ_PTR(_fr_61743);
    _26current_file_no_11982 = (int)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_26current_file_no_11982)){
        _26current_file_no_11982 = (long)DBL_PTR(_26current_file_no_11982)->dbl;
    }

    /** 	set_code( ref )*/
    _29set_code(_ref_61742);

    /** 	sequence code = Code*/
    RefDS(_26Code_12071);
    DeRef(_code_61798);
    _code_61798 = _26Code_12071;

    /** 	integer temp_sub = CurrentSub*/
    _temp_sub_61800 = _26CurrentSub_11990;

    /** 	integer pc = fr[FR_PC]*/
    _2 = (int)SEQ_PTR(_fr_61743);
    _pc_61802 = (int)*(((s1_ptr)_2)->base + 5);
    if (!IS_ATOM_INT(_pc_61802))
    _pc_61802 = (long)DBL_PTR(_pc_61802)->dbl;

    /** 	integer next_pc = pc*/
    _next_pc_61804 = _pc_61802;

    /** 	integer supplied_args = code[pc+2]*/
    _30910 = _pc_61802 + 2;
    _2 = (int)SEQ_PTR(_code_61798);
    _supplied_args_61805 = (int)*(((s1_ptr)_2)->base + _30910);
    if (!IS_ATOM_INT(_supplied_args_61805))
    _supplied_args_61805 = (long)DBL_PTR(_supplied_args_61805)->dbl;

    /** 	sequence name = fr[FR_NAME]*/
    DeRef(_name_61808);
    _2 = (int)SEQ_PTR(_fr_61743);
    _name_61808 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_name_61808);

    /** 	if Code[pc] != FUNC_FORWARD and Code[pc] != PROC_FORWARD then*/
    _2 = (int)SEQ_PTR(_26Code_12071);
    _30913 = (int)*(((s1_ptr)_2)->base + _pc_61802);
    if (IS_ATOM_INT(_30913)) {
        _30914 = (_30913 != 196);
    }
    else {
        _30914 = binary_op(NOTEQ, _30913, 196);
    }
    _30913 = NOVALUE;
    if (IS_ATOM_INT(_30914)) {
        if (_30914 == 0) {
            goto L2; // [268] 332
        }
    }
    else {
        if (DBL_PTR(_30914)->dbl == 0.0) {
            goto L2; // [268] 332
        }
    }
    _2 = (int)SEQ_PTR(_26Code_12071);
    _30916 = (int)*(((s1_ptr)_2)->base + _pc_61802);
    if (IS_ATOM_INT(_30916)) {
        _30917 = (_30916 != 195);
    }
    else {
        _30917 = binary_op(NOTEQ, _30916, 195);
    }
    _30916 = NOVALUE;
    if (_30917 == 0) {
        DeRef(_30917);
        _30917 = NOVALUE;
        goto L2; // [285] 332
    }
    else {
        if (!IS_ATOM_INT(_30917) && DBL_PTR(_30917)->dbl == 0.0){
            DeRef(_30917);
            _30917 = NOVALUE;
            goto L2; // [285] 332
        }
        DeRef(_30917);
        _30917 = NOVALUE;
    }
    DeRef(_30917);
    _30917 = NOVALUE;

    /** 		prep_forward_error( ref )*/
    _29prep_forward_error(_ref_61742);

    /** 		CompileErr( "The forward call to [4] wasn't where we thought it would be: [1]:[2]:[3]",*/
    _2 = (int)SEQ_PTR(_27known_files_10922);
    _30919 = (int)*(((s1_ptr)_2)->base + _26current_file_no_11982);
    _2 = (int)SEQ_PTR(_fr_61743);
    _30920 = (int)*(((s1_ptr)_2)->base + 4);
    Ref(_30920);
    _30921 = _52sym_name(_30920);
    _30920 = NOVALUE;
    _2 = (int)SEQ_PTR(_fr_61743);
    _30922 = (int)*(((s1_ptr)_2)->base + 6);
    _2 = (int)SEQ_PTR(_fr_61743);
    _30923 = (int)*(((s1_ptr)_2)->base + 2);
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_30919);
    *((int *)(_2+4)) = _30919;
    *((int *)(_2+8)) = _30921;
    Ref(_30922);
    *((int *)(_2+12)) = _30922;
    Ref(_30923);
    *((int *)(_2+16)) = _30923;
    _30924 = MAKE_SEQ(_1);
    _30923 = NOVALUE;
    _30922 = NOVALUE;
    _30921 = NOVALUE;
    _30919 = NOVALUE;
    RefDS(_30918);
    _43CompileErr(_30918, _30924, 0);
    _30924 = NOVALUE;
L2: 

    /** 	integer old_temps_allocated = temps_allocated*/
    _old_temps_allocated_61832 = _52temps_allocated_46650;

    /** 	temps_allocated = 0*/
    _52temps_allocated_46650 = 0;

    /** 	if is_func and fr[FR_OP] = PROC then*/
    if (_is_func_61780 == 0) {
        goto L3; // [350] 438
    }
    _2 = (int)SEQ_PTR(_fr_61743);
    _30926 = (int)*(((s1_ptr)_2)->base + 10);
    if (IS_ATOM_INT(_30926)) {
        _30927 = (_30926 == 27);
    }
    else {
        _30927 = binary_op(EQUALS, _30926, 27);
    }
    _30926 = NOVALUE;
    if (_30927 == 0) {
        DeRef(_30927);
        _30927 = NOVALUE;
        goto L3; // [365] 438
    }
    else {
        if (!IS_ATOM_INT(_30927) && DBL_PTR(_30927)->dbl == 0.0){
            DeRef(_30927);
            _30927 = NOVALUE;
            goto L3; // [365] 438
        }
        DeRef(_30927);
        _30927 = NOVALUE;
    }
    DeRef(_30927);
    _30927 = NOVALUE;

    /** 		symtab_index temp_target = NewTempSym()*/
    _temp_target_61841 = _52NewTempSym(0);
    if (!IS_ATOM_INT(_temp_target_61841)) {
        _1 = (long)(DBL_PTR(_temp_target_61841)->dbl);
        DeRefDS(_temp_target_61841);
        _temp_target_61841 = _1;
    }

    /** 		sequence converted_code = */
    _30929 = _pc_61802 + 1;
    if (_30929 > MAXINT){
        _30929 = NewDouble((double)_30929);
    }
    _30930 = _pc_61802 + 2;
    if ((long)((unsigned long)_30930 + (unsigned long)HIGH_BITS) >= 0) 
    _30930 = NewDouble((double)_30930);
    if (IS_ATOM_INT(_30930)) {
        _30931 = _30930 + _supplied_args_61805;
    }
    else {
        _30931 = NewDouble(DBL_PTR(_30930)->dbl + (double)_supplied_args_61805);
    }
    DeRef(_30930);
    _30930 = NOVALUE;
    rhs_slice_target = (object_ptr)&_30932;
    RHS_Slice(_26Code_12071, _30929, _30931);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 208;
    ((int *)_2)[2] = _temp_target_61841;
    _30933 = MAKE_SEQ(_1);
    {
        int concat_list[4];

        concat_list[0] = _30933;
        concat_list[1] = _temp_target_61841;
        concat_list[2] = _30932;
        concat_list[3] = 196;
        Concat_N((object_ptr)&_converted_code_61844, concat_list, 4);
    }
    DeRefDS(_30933);
    _30933 = NOVALUE;
    DeRefDS(_30932);
    _30932 = NOVALUE;

    /** 		replace_code( converted_code, pc, pc + 2 + supplied_args, code_sub )*/
    _30935 = _pc_61802 + 2;
    if ((long)((unsigned long)_30935 + (unsigned long)HIGH_BITS) >= 0) 
    _30935 = NewDouble((double)_30935);
    if (IS_ATOM_INT(_30935)) {
        _30936 = _30935 + _supplied_args_61805;
        if ((long)((unsigned long)_30936 + (unsigned long)HIGH_BITS) >= 0) 
        _30936 = NewDouble((double)_30936);
    }
    else {
        _30936 = NewDouble(DBL_PTR(_30935)->dbl + (double)_supplied_args_61805);
    }
    DeRef(_30935);
    _30935 = NOVALUE;
    RefDS(_converted_code_61844);
    _29replace_code(_converted_code_61844, _pc_61802, _30936, _code_sub_61773);
    _30936 = NOVALUE;

    /** 		code = Code*/
    RefDS(_26Code_12071);
    DeRef(_code_61798);
    _code_61798 = _26Code_12071;
L3: 
    DeRef(_converted_code_61844);
    _converted_code_61844 = NOVALUE;

    /** 	next_pc +=*/
    _30937 = 3 + _supplied_args_61805;
    if ((long)((unsigned long)_30937 + (unsigned long)HIGH_BITS) >= 0) 
    _30937 = NewDouble((double)_30937);
    if (IS_ATOM_INT(_30937)) {
        _30938 = _30937 + _is_func_61780;
        if ((long)((unsigned long)_30938 + (unsigned long)HIGH_BITS) >= 0) 
        _30938 = NewDouble((double)_30938);
    }
    else {
        _30938 = NewDouble(DBL_PTR(_30937)->dbl + (double)_is_func_61780);
    }
    DeRef(_30937);
    _30937 = NOVALUE;
    if (IS_ATOM_INT(_30938)) {
        _next_pc_61804 = _next_pc_61804 + _30938;
    }
    else {
        _next_pc_61804 = NewDouble((double)_next_pc_61804 + DBL_PTR(_30938)->dbl);
    }
    DeRef(_30938);
    _30938 = NOVALUE;
    if (!IS_ATOM_INT(_next_pc_61804)) {
        _1 = (long)(DBL_PTR(_next_pc_61804)->dbl);
        DeRefDS(_next_pc_61804);
        _next_pc_61804 = _1;
    }

    /** 	integer target*/

    /** 	if is_func then*/
    if (_is_func_61780 == 0)
    {
        goto L4; // [460] 482
    }
    else{
    }

    /** 		target = Code[pc + 3 + supplied_args]*/
    _30940 = _pc_61802 + 3;
    if ((long)((unsigned long)_30940 + (unsigned long)HIGH_BITS) >= 0) 
    _30940 = NewDouble((double)_30940);
    if (IS_ATOM_INT(_30940)) {
        _30941 = _30940 + _supplied_args_61805;
    }
    else {
        _30941 = NewDouble(DBL_PTR(_30940)->dbl + (double)_supplied_args_61805);
    }
    DeRef(_30940);
    _30940 = NOVALUE;
    _2 = (int)SEQ_PTR(_26Code_12071);
    if (!IS_ATOM_INT(_30941)){
        _target_61860 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_30941)->dbl));
    }
    else{
        _target_61860 = (int)*(((s1_ptr)_2)->base + _30941);
    }
    if (!IS_ATOM_INT(_target_61860)){
        _target_61860 = (long)DBL_PTR(_target_61860)->dbl;
    }
L4: 

    /** 	integer has_defaults = 0*/
    _has_defaults_61866 = 0;

    /** 	integer goto_target = length( code ) + 1*/
    if (IS_SEQUENCE(_code_61798)){
            _30943 = SEQ_PTR(_code_61798)->length;
    }
    else {
        _30943 = 1;
    }
    _goto_target_61867 = _30943 + 1;
    _30943 = NOVALUE;

    /** 	integer defarg = 0*/
    _defarg_61870 = 0;

    /** 	integer code_len = length(code)*/
    if (IS_SEQUENCE(_code_61798)){
            _code_len_61871 = SEQ_PTR(_code_61798)->length;
    }
    else {
        _code_len_61871 = 1;
    }

    /** 	integer extra_default_args = 0*/
    _extra_default_args_61873 = 0;

    /** 	set_dont_read( 1 )*/
    _60set_dont_read(1);

    /** 	reset_private_lists()*/

    /** 	fwd_private_sym  = {}*/
    RefDS(_22037);
    DeRefi(_29fwd_private_sym_61704);
    _29fwd_private_sym_61704 = _22037;

    /** 	fwd_private_name = {}*/
    RefDS(_22037);
    DeRef(_29fwd_private_name_61705);
    _29fwd_private_name_61705 = _22037;

    /** end procedure*/
    goto L5; // [534] 537
L5: 

    /** 	integer param_sym = sub*/
    _param_sym_61876 = _sub_61746;

    /** 	sequence params = repeat( 0, args )*/
    DeRef(_params_61877);
    _params_61877 = Repeat(0, _args_61775);

    /** 	sequence orig_code = code*/
    RefDS(_code_61798);
    DeRef(_orig_code_61879);
    _orig_code_61879 = _code_61798;

    /** 	sequence orig_linetable = LineTable*/
    RefDS(_26LineTable_12072);
    DeRef(_orig_linetable_61880);
    _orig_linetable_61880 = _26LineTable_12072;

    /** 	Code = {}*/
    RefDS(_22037);
    DeRef(_26Code_12071);
    _26Code_12071 = _22037;

    /** 	integer ar_sp = find( code_sub, active_subprogs[current_file_no] )*/
    _2 = (int)SEQ_PTR(_29active_subprogs_61533);
    _30947 = (int)*(((s1_ptr)_2)->base + _26current_file_no_11982);
    _ar_sp_61883 = find_from(_code_sub_61773, _30947, 1);
    _30947 = NOVALUE;

    /** 	integer pre_refs*/

    /** 	if code_sub = TopLevelSub then*/
    if (_code_sub_61773 != _26TopLevelSub_11989)
    goto L6; // [594] 614

    /** 		pre_refs = length( toplevel_references[current_file_no] )*/
    _2 = (int)SEQ_PTR(_29toplevel_references_61535);
    _30950 = (int)*(((s1_ptr)_2)->base + _26current_file_no_11982);
    if (IS_SEQUENCE(_30950)){
            _pre_refs_61887 = SEQ_PTR(_30950)->length;
    }
    else {
        _pre_refs_61887 = 1;
    }
    _30950 = NOVALUE;
    goto L7; // [611] 647
L6: 

    /** 		ar_sp = find( code_sub, active_subprogs[current_file_no] )*/
    _2 = (int)SEQ_PTR(_29active_subprogs_61533);
    _30952 = (int)*(((s1_ptr)_2)->base + _26current_file_no_11982);
    _ar_sp_61883 = find_from(_code_sub_61773, _30952, 1);
    _30952 = NOVALUE;

    /** 		pre_refs = length( active_references[current_file_no][ar_sp] )*/
    _2 = (int)SEQ_PTR(_29active_references_61534);
    _30954 = (int)*(((s1_ptr)_2)->base + _26current_file_no_11982);
    _2 = (int)SEQ_PTR(_30954);
    _30955 = (int)*(((s1_ptr)_2)->base + _ar_sp_61883);
    _30954 = NOVALUE;
    if (IS_SEQUENCE(_30955)){
            _pre_refs_61887 = SEQ_PTR(_30955)->length;
    }
    else {
        _pre_refs_61887 = 1;
    }
    _30955 = NOVALUE;
L7: 

    /** 	sequence old_fwd_params = {}*/
    RefDS(_22037);
    DeRef(_old_fwd_params_61902);
    _old_fwd_params_61902 = _22037;

    /** 	for i = pc + 3 to pc + args + 2 do*/
    _30957 = _pc_61802 + 3;
    if ((long)((unsigned long)_30957 + (unsigned long)HIGH_BITS) >= 0) 
    _30957 = NewDouble((double)_30957);
    _30958 = _pc_61802 + _args_61775;
    if ((long)((unsigned long)_30958 + (unsigned long)HIGH_BITS) >= 0) 
    _30958 = NewDouble((double)_30958);
    if (IS_ATOM_INT(_30958)) {
        _30959 = _30958 + 2;
        if ((long)((unsigned long)_30959 + (unsigned long)HIGH_BITS) >= 0) 
        _30959 = NewDouble((double)_30959);
    }
    else {
        _30959 = NewDouble(DBL_PTR(_30958)->dbl + (double)2);
    }
    DeRef(_30958);
    _30958 = NOVALUE;
    {
        int _i_61904;
        Ref(_30957);
        _i_61904 = _30957;
L8: 
        if (binary_op_a(GREATER, _i_61904, _30959)){
            goto L9; // [668] 829
        }

        /** 		defarg += 1*/
        _defarg_61870 = _defarg_61870 + 1;

        /** 		param_sym = SymTab[param_sym][S_NEXT]*/
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _30961 = (int)*(((s1_ptr)_2)->base + _param_sym_61876);
        _2 = (int)SEQ_PTR(_30961);
        _param_sym_61876 = (int)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_param_sym_61876)){
            _param_sym_61876 = (long)DBL_PTR(_param_sym_61876)->dbl;
        }
        _30961 = NOVALUE;

        /** 		if defarg > supplied_args or i > length( code ) or not code[i] then*/
        _30963 = (_defarg_61870 > _supplied_args_61805);
        if (_30963 != 0) {
            _30964 = 1;
            goto LA; // [703] 718
        }
        if (IS_SEQUENCE(_code_61798)){
                _30965 = SEQ_PTR(_code_61798)->length;
        }
        else {
            _30965 = 1;
        }
        if (IS_ATOM_INT(_i_61904)) {
            _30966 = (_i_61904 > _30965);
        }
        else {
            _30966 = (DBL_PTR(_i_61904)->dbl > (double)_30965);
        }
        _30965 = NOVALUE;
        _30964 = (_30966 != 0);
LA: 
        if (_30964 != 0) {
            goto LB; // [718] 734
        }
        _2 = (int)SEQ_PTR(_code_61798);
        if (!IS_ATOM_INT(_i_61904)){
            _30968 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_61904)->dbl));
        }
        else{
            _30968 = (int)*(((s1_ptr)_2)->base + _i_61904);
        }
        if (IS_ATOM_INT(_30968)) {
            _30969 = (_30968 == 0);
        }
        else {
            _30969 = unary_op(NOT, _30968);
        }
        _30968 = NOVALUE;
        if (_30969 == 0) {
            DeRef(_30969);
            _30969 = NOVALUE;
            goto LC; // [730] 784
        }
        else {
            if (!IS_ATOM_INT(_30969) && DBL_PTR(_30969)->dbl == 0.0){
                DeRef(_30969);
                _30969 = NOVALUE;
                goto LC; // [730] 784
            }
            DeRef(_30969);
            _30969 = NOVALUE;
        }
        DeRef(_30969);
        _30969 = NOVALUE;
LB: 

        /** 			has_defaults = 1*/
        _has_defaults_61866 = 1;

        /** 			extra_default_args += 1*/
        _extra_default_args_61873 = _extra_default_args_61873 + 1;

        /** 			show_params( sub )*/
        _52show_params(_sub_61746);

        /** 			set_error_info( ref )*/
        _29set_error_info(_ref_61742);

        /** 			Parse_default_arg(sub, defarg, fwd_private_name, fwd_private_sym) --call_proc( parse_arg_rid, { sub, defarg, fwd_private_name, fwd_private_sym } )*/
        RefDS(_29fwd_private_name_61705);
        RefDS(_29fwd_private_sym_61704);
        _30Parse_default_arg(_sub_61746, _defarg_61870, _29fwd_private_name_61705, _29fwd_private_sym_61704);

        /** 			hide_params( sub )*/
        _52hide_params(_sub_61746);

        /** 			params[defarg] = Pop()*/
        _30971 = _37Pop();
        _2 = (int)SEQ_PTR(_params_61877);
        _2 = (int)(((s1_ptr)_2)->base + _defarg_61870);
        _1 = *(int *)_2;
        *(int *)_2 = _30971;
        if( _1 != _30971 ){
            DeRef(_1);
        }
        _30971 = NOVALUE;
        goto LD; // [781] 822
LC: 

        /** 			extra_default_args = 0*/
        _extra_default_args_61873 = 0;

        /** 			add_private_symbol( code[i], SymTab[param_sym][S_NAME] )*/
        _2 = (int)SEQ_PTR(_code_61798);
        if (!IS_ATOM_INT(_i_61904)){
            _30972 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_61904)->dbl));
        }
        else{
            _30972 = (int)*(((s1_ptr)_2)->base + _i_61904);
        }
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _30973 = (int)*(((s1_ptr)_2)->base + _param_sym_61876);
        _2 = (int)SEQ_PTR(_30973);
        if (!IS_ATOM_INT(_26S_NAME_11654)){
            _30974 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NAME_11654)->dbl));
        }
        else{
            _30974 = (int)*(((s1_ptr)_2)->base + _26S_NAME_11654);
        }
        _30973 = NOVALUE;
        Ref(_30972);
        Ref(_30974);
        _29add_private_symbol(_30972, _30974);
        _30972 = NOVALUE;
        _30974 = NOVALUE;

        /** 			params[defarg] = code[i]*/
        _2 = (int)SEQ_PTR(_code_61798);
        if (!IS_ATOM_INT(_i_61904)){
            _30975 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_61904)->dbl));
        }
        else{
            _30975 = (int)*(((s1_ptr)_2)->base + _i_61904);
        }
        Ref(_30975);
        _2 = (int)SEQ_PTR(_params_61877);
        _2 = (int)(((s1_ptr)_2)->base + _defarg_61870);
        _1 = *(int *)_2;
        *(int *)_2 = _30975;
        if( _1 != _30975 ){
            DeRef(_1);
        }
        _30975 = NOVALUE;
LD: 

        /** 	end for*/
        _0 = _i_61904;
        if (IS_ATOM_INT(_i_61904)) {
            _i_61904 = _i_61904 + 1;
            if ((long)((unsigned long)_i_61904 +(unsigned long) HIGH_BITS) >= 0){
                _i_61904 = NewDouble((double)_i_61904);
            }
        }
        else {
            _i_61904 = binary_op_a(PLUS, _i_61904, 1);
        }
        DeRef(_0);
        goto L8; // [824] 675
L9: 
        ;
        DeRef(_i_61904);
    }

    /** 	SymTab[code_sub][S_STACK_SPACE] += temps_allocated*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_code_sub_61773 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!IS_ATOM_INT(_26S_STACK_SPACE_11714)){
        _30978 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_STACK_SPACE_11714)->dbl));
    }
    else{
        _30978 = (int)*(((s1_ptr)_2)->base + _26S_STACK_SPACE_11714);
    }
    _30976 = NOVALUE;
    if (IS_ATOM_INT(_30978)) {
        _30979 = _30978 + _52temps_allocated_46650;
        if ((long)((unsigned long)_30979 + (unsigned long)HIGH_BITS) >= 0) 
        _30979 = NewDouble((double)_30979);
    }
    else {
        _30979 = binary_op(PLUS, _30978, _52temps_allocated_46650);
    }
    _30978 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_26S_STACK_SPACE_11714))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_STACK_SPACE_11714)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _26S_STACK_SPACE_11714);
    _1 = *(int *)_2;
    *(int *)_2 = _30979;
    if( _1 != _30979 ){
        DeRef(_1);
    }
    _30979 = NOVALUE;
    _30976 = NOVALUE;

    /** 	temps_allocated = old_temps_allocated*/
    _52temps_allocated_46650 = _old_temps_allocated_61832;

    /** 	integer temp_shifting_sub = shifting_sub*/
    _temp_shifting_sub_61943 = _29shifting_sub_61551;

    /** 	shift( -pc, pc-1 )*/
    if ((unsigned long)_pc_61802 == 0xC0000000)
    _30980 = (int)NewDouble((double)-0xC0000000);
    else
    _30980 = - _pc_61802;
    _30981 = _pc_61802 - 1;
    if ((long)((unsigned long)_30981 +(unsigned long) HIGH_BITS) >= 0){
        _30981 = NewDouble((double)_30981);
    }
    Ref(_30980);
    DeRef(_31635);
    _31635 = _30980;
    _64shift(_30980, _30981, _31635);
    _30980 = NOVALUE;
    _30981 = NOVALUE;
    _31635 = NOVALUE;

    /** 	sequence new_code = Code*/
    RefDS(_26Code_12071);
    DeRef(_new_code_61947);
    _new_code_61947 = _26Code_12071;

    /** 	Code = orig_code*/
    RefDS(_orig_code_61879);
    DeRefDS(_26Code_12071);
    _26Code_12071 = _orig_code_61879;

    /** 	LineTable = orig_linetable*/
    RefDS(_orig_linetable_61880);
    DeRef(_26LineTable_12072);
    _26LineTable_12072 = _orig_linetable_61880;

    /** 	set_dont_read( 0 )*/
    _60set_dont_read(0);

    /** 	current_file_no = real_file*/
    _26current_file_no_11982 = _real_file_61794;

    /** 	if args != ( supplied_args + extra_default_args ) then*/
    _30982 = _supplied_args_61805 + _extra_default_args_61873;
    if ((long)((unsigned long)_30982 + (unsigned long)HIGH_BITS) >= 0) 
    _30982 = NewDouble((double)_30982);
    if (binary_op_a(EQUALS, _args_61775, _30982)){
        DeRef(_30982);
        _30982 = NOVALUE;
        goto LE; // [926] 1004
    }
    DeRef(_30982);
    _30982 = NOVALUE;

    /** 		sequence routine_type*/

    /** 		if is_func then */
    if (_is_func_61780 == 0)
    {
        goto LF; // [934] 947
    }
    else{
    }

    /** 			routine_type = "function"*/
    RefDS(_26343);
    DeRefi(_routine_type_61956);
    _routine_type_61956 = _26343;
    goto L10; // [944] 955
LF: 

    /** 			routine_type = "procedure"*/
    RefDS(_26397);
    DeRefi(_routine_type_61956);
    _routine_type_61956 = _26397;
L10: 

    /** 		current_file_no = fr[FR_FILE]*/
    _2 = (int)SEQ_PTR(_fr_61743);
    _26current_file_no_11982 = (int)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_26current_file_no_11982)){
        _26current_file_no_11982 = (long)DBL_PTR(_26current_file_no_11982)->dbl;
    }

    /** 		line_number = fr[FR_LINE]*/
    _2 = (int)SEQ_PTR(_fr_61743);
    _26line_number_11983 = (int)*(((s1_ptr)_2)->base + 6);
    if (!IS_ATOM_INT(_26line_number_11983)){
        _26line_number_11983 = (long)DBL_PTR(_26line_number_11983)->dbl;
    }

    /** 		CompileErr( 158,*/
    _2 = (int)SEQ_PTR(_27known_files_10922);
    _30986 = (int)*(((s1_ptr)_2)->base + _26current_file_no_11982);
    _30987 = _supplied_args_61805 + _extra_default_args_61873;
    if ((long)((unsigned long)_30987 + (unsigned long)HIGH_BITS) >= 0) 
    _30987 = NewDouble((double)_30987);
    _1 = NewS1(6);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_30986);
    *((int *)(_2+4)) = _30986;
    *((int *)(_2+8)) = _26line_number_11983;
    RefDS(_routine_type_61956);
    *((int *)(_2+12)) = _routine_type_61956;
    RefDS(_name_61808);
    *((int *)(_2+16)) = _name_61808;
    *((int *)(_2+20)) = _args_61775;
    *((int *)(_2+24)) = _30987;
    _30988 = MAKE_SEQ(_1);
    _30987 = NOVALUE;
    _30986 = NOVALUE;
    _43CompileErr(158, _30988, 0);
    _30988 = NOVALUE;
LE: 
    DeRefi(_routine_type_61956);
    _routine_type_61956 = NOVALUE;

    /** 	new_code &= PROC & sub & params*/
    {
        int concat_list[3];

        concat_list[0] = _params_61877;
        concat_list[1] = _sub_61746;
        concat_list[2] = 27;
        Concat_N((object_ptr)&_30989, concat_list, 3);
    }
    Concat((object_ptr)&_new_code_61947, _new_code_61947, _30989);
    DeRefDS(_30989);
    _30989 = NOVALUE;

    /** 	if is_func then*/
    if (_is_func_61780 == 0)
    {
        goto L11; // [1022] 1034
    }
    else{
    }

    /** 		new_code &= target*/
    Append(&_new_code_61947, _new_code_61947, _target_61860);
L11: 

    /** 	replace_code( new_code, pc, next_pc - 1, code_sub )*/
    _30992 = _next_pc_61804 - 1;
    if ((long)((unsigned long)_30992 +(unsigned long) HIGH_BITS) >= 0){
        _30992 = NewDouble((double)_30992);
    }
    RefDS(_new_code_61947);
    _29replace_code(_new_code_61947, _pc_61802, _30992, _code_sub_61773);
    _30992 = NOVALUE;

    /** 	if code_sub = TopLevelSub then*/
    if (_code_sub_61773 != _26TopLevelSub_11989)
    goto L12; // [1050] 1131

    /** 		for i = pre_refs + 1 to length( toplevel_references[fr[FR_FILE]] ) do*/
    _30994 = _pre_refs_61887 + 1;
    if (_30994 > MAXINT){
        _30994 = NewDouble((double)_30994);
    }
    _2 = (int)SEQ_PTR(_fr_61743);
    _30995 = (int)*(((s1_ptr)_2)->base + 3);
    _2 = (int)SEQ_PTR(_29toplevel_references_61535);
    if (!IS_ATOM_INT(_30995)){
        _30996 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_30995)->dbl));
    }
    else{
        _30996 = (int)*(((s1_ptr)_2)->base + _30995);
    }
    if (IS_SEQUENCE(_30996)){
            _30997 = SEQ_PTR(_30996)->length;
    }
    else {
        _30997 = 1;
    }
    _30996 = NOVALUE;
    {
        int _i_61980;
        Ref(_30994);
        _i_61980 = _30994;
L13: 
        if (binary_op_a(GREATER, _i_61980, _30997)){
            goto L14; // [1075] 1128
        }

        /** 			forward_references[toplevel_references[fr[FR_FILE]][i]][FR_PC] += pc - 1*/
        _2 = (int)SEQ_PTR(_fr_61743);
        _30998 = (int)*(((s1_ptr)_2)->base + 3);
        _2 = (int)SEQ_PTR(_29toplevel_references_61535);
        if (!IS_ATOM_INT(_30998)){
            _30999 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_30998)->dbl));
        }
        else{
            _30999 = (int)*(((s1_ptr)_2)->base + _30998);
        }
        _2 = (int)SEQ_PTR(_30999);
        if (!IS_ATOM_INT(_i_61980)){
            _31000 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_61980)->dbl));
        }
        else{
            _31000 = (int)*(((s1_ptr)_2)->base + _i_61980);
        }
        _30999 = NOVALUE;
        _2 = (int)SEQ_PTR(_29forward_references_61532);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _29forward_references_61532 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_31000))
        _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_31000)->dbl));
        else
        _3 = (int)(_31000 + ((s1_ptr)_2)->base);
        _31003 = _pc_61802 - 1;
        if ((long)((unsigned long)_31003 +(unsigned long) HIGH_BITS) >= 0){
            _31003 = NewDouble((double)_31003);
        }
        _2 = (int)SEQ_PTR(*(int *)_3);
        _31004 = (int)*(((s1_ptr)_2)->base + 5);
        _31001 = NOVALUE;
        if (IS_ATOM_INT(_31004) && IS_ATOM_INT(_31003)) {
            _31005 = _31004 + _31003;
            if ((long)((unsigned long)_31005 + (unsigned long)HIGH_BITS) >= 0) 
            _31005 = NewDouble((double)_31005);
        }
        else {
            _31005 = binary_op(PLUS, _31004, _31003);
        }
        _31004 = NOVALUE;
        DeRef(_31003);
        _31003 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 5);
        _1 = *(int *)_2;
        *(int *)_2 = _31005;
        if( _1 != _31005 ){
            DeRef(_1);
        }
        _31005 = NOVALUE;
        _31001 = NOVALUE;

        /** 		end for*/
        _0 = _i_61980;
        if (IS_ATOM_INT(_i_61980)) {
            _i_61980 = _i_61980 + 1;
            if ((long)((unsigned long)_i_61980 +(unsigned long) HIGH_BITS) >= 0){
                _i_61980 = NewDouble((double)_i_61980);
            }
        }
        else {
            _i_61980 = binary_op_a(PLUS, _i_61980, 1);
        }
        DeRef(_0);
        goto L13; // [1123] 1082
L14: 
        ;
        DeRef(_i_61980);
    }
    goto L15; // [1128] 1214
L12: 

    /** 		for i = pre_refs + 1 to length( active_references[fr[FR_FILE]][ar_sp] ) do*/
    _31006 = _pre_refs_61887 + 1;
    if (_31006 > MAXINT){
        _31006 = NewDouble((double)_31006);
    }
    _2 = (int)SEQ_PTR(_fr_61743);
    _31007 = (int)*(((s1_ptr)_2)->base + 3);
    _2 = (int)SEQ_PTR(_29active_references_61534);
    if (!IS_ATOM_INT(_31007)){
        _31008 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_31007)->dbl));
    }
    else{
        _31008 = (int)*(((s1_ptr)_2)->base + _31007);
    }
    _2 = (int)SEQ_PTR(_31008);
    _31009 = (int)*(((s1_ptr)_2)->base + _ar_sp_61883);
    _31008 = NOVALUE;
    if (IS_SEQUENCE(_31009)){
            _31010 = SEQ_PTR(_31009)->length;
    }
    else {
        _31010 = 1;
    }
    _31009 = NOVALUE;
    {
        int _i_61995;
        Ref(_31006);
        _i_61995 = _31006;
L16: 
        if (binary_op_a(GREATER, _i_61995, _31010)){
            goto L17; // [1156] 1213
        }

        /** 			forward_references[active_references[fr[FR_FILE]][ar_sp][i]][FR_PC] += pc - 1*/
        _2 = (int)SEQ_PTR(_fr_61743);
        _31011 = (int)*(((s1_ptr)_2)->base + 3);
        _2 = (int)SEQ_PTR(_29active_references_61534);
        if (!IS_ATOM_INT(_31011)){
            _31012 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_31011)->dbl));
        }
        else{
            _31012 = (int)*(((s1_ptr)_2)->base + _31011);
        }
        _2 = (int)SEQ_PTR(_31012);
        _31013 = (int)*(((s1_ptr)_2)->base + _ar_sp_61883);
        _31012 = NOVALUE;
        _2 = (int)SEQ_PTR(_31013);
        if (!IS_ATOM_INT(_i_61995)){
            _31014 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_61995)->dbl));
        }
        else{
            _31014 = (int)*(((s1_ptr)_2)->base + _i_61995);
        }
        _31013 = NOVALUE;
        _2 = (int)SEQ_PTR(_29forward_references_61532);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _29forward_references_61532 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_31014))
        _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_31014)->dbl));
        else
        _3 = (int)(_31014 + ((s1_ptr)_2)->base);
        _31017 = _pc_61802 - 1;
        if ((long)((unsigned long)_31017 +(unsigned long) HIGH_BITS) >= 0){
            _31017 = NewDouble((double)_31017);
        }
        _2 = (int)SEQ_PTR(*(int *)_3);
        _31018 = (int)*(((s1_ptr)_2)->base + 5);
        _31015 = NOVALUE;
        if (IS_ATOM_INT(_31018) && IS_ATOM_INT(_31017)) {
            _31019 = _31018 + _31017;
            if ((long)((unsigned long)_31019 + (unsigned long)HIGH_BITS) >= 0) 
            _31019 = NewDouble((double)_31019);
        }
        else {
            _31019 = binary_op(PLUS, _31018, _31017);
        }
        _31018 = NOVALUE;
        DeRef(_31017);
        _31017 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 5);
        _1 = *(int *)_2;
        *(int *)_2 = _31019;
        if( _1 != _31019 ){
            DeRef(_1);
        }
        _31019 = NOVALUE;
        _31015 = NOVALUE;

        /** 		end for*/
        _0 = _i_61995;
        if (IS_ATOM_INT(_i_61995)) {
            _i_61995 = _i_61995 + 1;
            if ((long)((unsigned long)_i_61995 +(unsigned long) HIGH_BITS) >= 0){
                _i_61995 = NewDouble((double)_i_61995);
            }
        }
        else {
            _i_61995 = binary_op_a(PLUS, _i_61995, 1);
        }
        DeRef(_0);
        goto L16; // [1208] 1163
L17: 
        ;
        DeRef(_i_61995);
    }
L15: 

    /** 	reset_code()*/
    _29reset_code();

    /** 	resolved_reference( ref )*/
    _29resolved_reference(_ref_61742);

    /** end procedure*/
    DeRef(_tok_61741);
    DeRef(_fr_61743);
    DeRef(_code_61798);
    DeRef(_name_61808);
    DeRef(_params_61877);
    DeRef(_orig_code_61879);
    DeRef(_orig_linetable_61880);
    DeRef(_old_fwd_params_61902);
    DeRef(_new_code_61947);
    _31011 = NOVALUE;
    _30950 = NOVALUE;
    DeRef(_30959);
    _30959 = NOVALUE;
    _30998 = NOVALUE;
    DeRef(_30910);
    _30910 = NOVALUE;
    DeRef(_30914);
    _30914 = NOVALUE;
    DeRef(_30957);
    _30957 = NOVALUE;
    DeRef(_31006);
    _31006 = NOVALUE;
    _30955 = NOVALUE;
    _31009 = NOVALUE;
    DeRef(_30966);
    _30966 = NOVALUE;
    _30996 = NOVALUE;
    _31000 = NOVALUE;
    _31014 = NOVALUE;
    DeRef(_30963);
    _30963 = NOVALUE;
    DeRef(_30994);
    _30994 = NOVALUE;
    _31007 = NOVALUE;
    DeRef(_30931);
    _30931 = NOVALUE;
    DeRef(_30941);
    _30941 = NOVALUE;
    DeRef(_30929);
    _30929 = NOVALUE;
    _30995 = NOVALUE;
    return;
    ;
}


void _29set_error_info(int _ref_62012)
{
    int _fr_62013 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence fr = forward_references[ref]*/
    DeRef(_fr_62013);
    _2 = (int)SEQ_PTR(_29forward_references_61532);
    _fr_62013 = (int)*(((s1_ptr)_2)->base + _ref_62012);
    Ref(_fr_62013);

    /** 	ThisLine        = fr[FR_THISLINE]*/
    DeRef(_43ThisLine_48557);
    _2 = (int)SEQ_PTR(_fr_62013);
    _43ThisLine_48557 = (int)*(((s1_ptr)_2)->base + 7);
    Ref(_43ThisLine_48557);

    /** 	bp              = fr[FR_BP]*/
    _2 = (int)SEQ_PTR(_fr_62013);
    _43bp_48561 = (int)*(((s1_ptr)_2)->base + 8);
    if (!IS_ATOM_INT(_43bp_48561)){
        _43bp_48561 = (long)DBL_PTR(_43bp_48561)->dbl;
    }

    /** 	line_number     = fr[FR_LINE]*/
    _2 = (int)SEQ_PTR(_fr_62013);
    _26line_number_11983 = (int)*(((s1_ptr)_2)->base + 6);
    if (!IS_ATOM_INT(_26line_number_11983)){
        _26line_number_11983 = (long)DBL_PTR(_26line_number_11983)->dbl;
    }

    /** 	current_file_no = fr[FR_FILE]*/
    _2 = (int)SEQ_PTR(_fr_62013);
    _26current_file_no_11982 = (int)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_26current_file_no_11982)){
        _26current_file_no_11982 = (long)DBL_PTR(_26current_file_no_11982)->dbl;
    }

    /** end procedure*/
    DeRefDS(_fr_62013);
    return;
    ;
}


void _29patch_forward_variable(int _tok_62026, int _ref_62027)
{
    int _fr_62028 = NOVALUE;
    int _sym_62031 = NOVALUE;
    int _pc_62083 = NOVALUE;
    int _vx_62087 = NOVALUE;
    int _d_62104 = NOVALUE;
    int _param_62114 = NOVALUE;
    int _old_62117 = NOVALUE;
    int _new_62122 = NOVALUE;
    int _31076 = NOVALUE;
    int _31075 = NOVALUE;
    int _31074 = NOVALUE;
    int _31072 = NOVALUE;
    int _31069 = NOVALUE;
    int _31067 = NOVALUE;
    int _31066 = NOVALUE;
    int _31065 = NOVALUE;
    int _31064 = NOVALUE;
    int _31062 = NOVALUE;
    int _31061 = NOVALUE;
    int _31060 = NOVALUE;
    int _31059 = NOVALUE;
    int _31058 = NOVALUE;
    int _31056 = NOVALUE;
    int _31054 = NOVALUE;
    int _31051 = NOVALUE;
    int _31050 = NOVALUE;
    int _31049 = NOVALUE;
    int _31047 = NOVALUE;
    int _31046 = NOVALUE;
    int _31045 = NOVALUE;
    int _31044 = NOVALUE;
    int _31042 = NOVALUE;
    int _31040 = NOVALUE;
    int _31039 = NOVALUE;
    int _31038 = NOVALUE;
    int _31037 = NOVALUE;
    int _31036 = NOVALUE;
    int _31035 = NOVALUE;
    int _31034 = NOVALUE;
    int _31033 = NOVALUE;
    int _31032 = NOVALUE;
    int _31031 = NOVALUE;
    int _31030 = NOVALUE;
    int _31029 = NOVALUE;
    int _31028 = NOVALUE;
    int _31027 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	sequence fr = forward_references[ref]*/
    DeRef(_fr_62028);
    _2 = (int)SEQ_PTR(_29forward_references_61532);
    _fr_62028 = (int)*(((s1_ptr)_2)->base + _ref_62027);
    Ref(_fr_62028);

    /** 	symtab_index sym = tok[T_SYM]*/
    _2 = (int)SEQ_PTR(_tok_62026);
    _sym_62031 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_sym_62031)){
        _sym_62031 = (long)DBL_PTR(_sym_62031)->dbl;
    }

    /** 	if SymTab[sym][S_FILE_NO] = fr[FR_FILE] */
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _31027 = (int)*(((s1_ptr)_2)->base + _sym_62031);
    _2 = (int)SEQ_PTR(_31027);
    if (!IS_ATOM_INT(_26S_FILE_NO_11650)){
        _31028 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_FILE_NO_11650)->dbl));
    }
    else{
        _31028 = (int)*(((s1_ptr)_2)->base + _26S_FILE_NO_11650);
    }
    _31027 = NOVALUE;
    _2 = (int)SEQ_PTR(_fr_62028);
    _31029 = (int)*(((s1_ptr)_2)->base + 3);
    if (IS_ATOM_INT(_31028) && IS_ATOM_INT(_31029)) {
        _31030 = (_31028 == _31029);
    }
    else {
        _31030 = binary_op(EQUALS, _31028, _31029);
    }
    _31028 = NOVALUE;
    _31029 = NOVALUE;
    if (IS_ATOM_INT(_31030)) {
        if (_31030 == 0) {
            goto L1; // [45] 69
        }
    }
    else {
        if (DBL_PTR(_31030)->dbl == 0.0) {
            goto L1; // [45] 69
        }
    }
    _2 = (int)SEQ_PTR(_fr_62028);
    _31032 = (int)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_31032)) {
        _31033 = (_31032 == _26TopLevelSub_11989);
    }
    else {
        _31033 = binary_op(EQUALS, _31032, _26TopLevelSub_11989);
    }
    _31032 = NOVALUE;
    if (_31033 == 0) {
        DeRef(_31033);
        _31033 = NOVALUE;
        goto L1; // [60] 69
    }
    else {
        if (!IS_ATOM_INT(_31033) && DBL_PTR(_31033)->dbl == 0.0){
            DeRef(_31033);
            _31033 = NOVALUE;
            goto L1; // [60] 69
        }
        DeRef(_31033);
        _31033 = NOVALUE;
    }
    DeRef(_31033);
    _31033 = NOVALUE;

    /** 		return*/
    DeRef(_tok_62026);
    DeRef(_fr_62028);
    DeRef(_31030);
    _31030 = NOVALUE;
    return;
L1: 

    /** 	if fr[FR_OP] = ASSIGN and SymTab[sym][S_MODE] = M_CONSTANT then*/
    _2 = (int)SEQ_PTR(_fr_62028);
    _31034 = (int)*(((s1_ptr)_2)->base + 10);
    if (IS_ATOM_INT(_31034)) {
        _31035 = (_31034 == 18);
    }
    else {
        _31035 = binary_op(EQUALS, _31034, 18);
    }
    _31034 = NOVALUE;
    if (IS_ATOM_INT(_31035)) {
        if (_31035 == 0) {
            goto L2; // [81] 120
        }
    }
    else {
        if (DBL_PTR(_31035)->dbl == 0.0) {
            goto L2; // [81] 120
        }
    }
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _31037 = (int)*(((s1_ptr)_2)->base + _sym_62031);
    _2 = (int)SEQ_PTR(_31037);
    _31038 = (int)*(((s1_ptr)_2)->base + 3);
    _31037 = NOVALUE;
    if (IS_ATOM_INT(_31038)) {
        _31039 = (_31038 == 2);
    }
    else {
        _31039 = binary_op(EQUALS, _31038, 2);
    }
    _31038 = NOVALUE;
    if (_31039 == 0) {
        DeRef(_31039);
        _31039 = NOVALUE;
        goto L2; // [104] 120
    }
    else {
        if (!IS_ATOM_INT(_31039) && DBL_PTR(_31039)->dbl == 0.0){
            DeRef(_31039);
            _31039 = NOVALUE;
            goto L2; // [104] 120
        }
        DeRef(_31039);
        _31039 = NOVALUE;
    }
    DeRef(_31039);
    _31039 = NOVALUE;

    /** 		prep_forward_error( ref )*/
    _29prep_forward_error(_ref_62027);

    /** 		CompileErr( 110 )*/
    RefDS(_22037);
    _43CompileErr(110, _22037, 0);
L2: 

    /** 	if fr[FR_OP] = ASSIGN then*/
    _2 = (int)SEQ_PTR(_fr_62028);
    _31040 = (int)*(((s1_ptr)_2)->base + 10);
    if (binary_op_a(NOTEQ, _31040, 18)){
        _31040 = NOVALUE;
        goto L3; // [128] 168
    }
    _31040 = NOVALUE;

    /** 		SymTab[sym][S_USAGE] = or_bits( U_WRITTEN, SymTab[sym][S_USAGE] )*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_62031 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _31044 = (int)*(((s1_ptr)_2)->base + _sym_62031);
    _2 = (int)SEQ_PTR(_31044);
    _31045 = (int)*(((s1_ptr)_2)->base + 5);
    _31044 = NOVALUE;
    if (IS_ATOM_INT(_31045)) {
        {unsigned long tu;
             tu = (unsigned long)2 | (unsigned long)_31045;
             _31046 = MAKE_UINT(tu);
        }
    }
    else {
        _31046 = binary_op(OR_BITS, 2, _31045);
    }
    _31045 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = _31046;
    if( _1 != _31046 ){
        DeRef(_1);
    }
    _31046 = NOVALUE;
    _31042 = NOVALUE;
    goto L4; // [165] 202
L3: 

    /** 		SymTab[sym][S_USAGE] = or_bits( U_READ, SymTab[sym][S_USAGE] )*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_62031 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _31049 = (int)*(((s1_ptr)_2)->base + _sym_62031);
    _2 = (int)SEQ_PTR(_31049);
    _31050 = (int)*(((s1_ptr)_2)->base + 5);
    _31049 = NOVALUE;
    if (IS_ATOM_INT(_31050)) {
        {unsigned long tu;
             tu = (unsigned long)1 | (unsigned long)_31050;
             _31051 = MAKE_UINT(tu);
        }
    }
    else {
        _31051 = binary_op(OR_BITS, 1, _31050);
    }
    _31050 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = _31051;
    if( _1 != _31051 ){
        DeRef(_1);
    }
    _31051 = NOVALUE;
    _31047 = NOVALUE;
L4: 

    /** 	set_code( ref )*/
    _29set_code(_ref_62027);

    /** 	integer pc = fr[FR_PC]*/
    _2 = (int)SEQ_PTR(_fr_62028);
    _pc_62083 = (int)*(((s1_ptr)_2)->base + 5);
    if (!IS_ATOM_INT(_pc_62083))
    _pc_62083 = (long)DBL_PTR(_pc_62083)->dbl;

    /** 	if pc < 1 then*/
    if (_pc_62083 >= 1)
    goto L5; // [215] 225

    /** 		pc = 1*/
    _pc_62083 = 1;
L5: 

    /** 	integer vx = find( -ref, Code, pc )*/
    if ((unsigned long)_ref_62027 == 0xC0000000)
    _31054 = (int)NewDouble((double)-0xC0000000);
    else
    _31054 = - _ref_62027;
    _vx_62087 = find_from(_31054, _26Code_12071, _pc_62083);
    DeRef(_31054);
    _31054 = NOVALUE;

    /** 	if vx then*/
    if (_vx_62087 == 0)
    {
        goto L6; // [239] 281
    }
    else{
    }

    /** 		while vx do*/
L7: 
    if (_vx_62087 == 0)
    {
        goto L8; // [247] 275
    }
    else{
    }

    /** 			Code[vx] = sym*/
    _2 = (int)SEQ_PTR(_26Code_12071);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _26Code_12071 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _vx_62087);
    _1 = *(int *)_2;
    *(int *)_2 = _sym_62031;
    DeRef(_1);

    /** 			vx = find( -ref, Code, vx )*/
    if ((unsigned long)_ref_62027 == 0xC0000000)
    _31056 = (int)NewDouble((double)-0xC0000000);
    else
    _31056 = - _ref_62027;
    _vx_62087 = find_from(_31056, _26Code_12071, _vx_62087);
    DeRef(_31056);
    _31056 = NOVALUE;

    /** 		end while*/
    goto L7; // [272] 247
L8: 

    /** 		resolved_reference( ref )*/
    _29resolved_reference(_ref_62027);
L6: 

    /** 	if sequence( fr[FR_DATA] ) then*/
    _2 = (int)SEQ_PTR(_fr_62028);
    _31058 = (int)*(((s1_ptr)_2)->base + 12);
    _31059 = IS_SEQUENCE(_31058);
    _31058 = NOVALUE;
    if (_31059 == 0)
    {
        _31059 = NOVALUE;
        goto L9; // [290] 422
    }
    else{
        _31059 = NOVALUE;
    }

    /** 		for i = 1 to length( fr[FR_DATA] ) do*/
    _2 = (int)SEQ_PTR(_fr_62028);
    _31060 = (int)*(((s1_ptr)_2)->base + 12);
    if (IS_SEQUENCE(_31060)){
            _31061 = SEQ_PTR(_31060)->length;
    }
    else {
        _31061 = 1;
    }
    _31060 = NOVALUE;
    {
        int _i_62101;
        _i_62101 = 1;
LA: 
        if (_i_62101 > _31061){
            goto LB; // [302] 416
        }

        /** 			object d = fr[FR_DATA][i]*/
        _2 = (int)SEQ_PTR(_fr_62028);
        _31062 = (int)*(((s1_ptr)_2)->base + 12);
        DeRef(_d_62104);
        _2 = (int)SEQ_PTR(_31062);
        _d_62104 = (int)*(((s1_ptr)_2)->base + _i_62101);
        Ref(_d_62104);
        _31062 = NOVALUE;

        /** 			if sequence( d ) and d[1] = PAM_RECORD then*/
        _31064 = IS_SEQUENCE(_d_62104);
        if (_31064 == 0) {
            goto LC; // [324] 405
        }
        _2 = (int)SEQ_PTR(_d_62104);
        _31066 = (int)*(((s1_ptr)_2)->base + 1);
        if (IS_ATOM_INT(_31066)) {
            _31067 = (_31066 == 1);
        }
        else {
            _31067 = binary_op(EQUALS, _31066, 1);
        }
        _31066 = NOVALUE;
        if (_31067 == 0) {
            DeRef(_31067);
            _31067 = NOVALUE;
            goto LC; // [339] 405
        }
        else {
            if (!IS_ATOM_INT(_31067) && DBL_PTR(_31067)->dbl == 0.0){
                DeRef(_31067);
                _31067 = NOVALUE;
                goto LC; // [339] 405
            }
            DeRef(_31067);
            _31067 = NOVALUE;
        }
        DeRef(_31067);
        _31067 = NOVALUE;

        /** 				symtab_index param = d[2]*/
        _2 = (int)SEQ_PTR(_d_62104);
        _param_62114 = (int)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_param_62114)){
            _param_62114 = (long)DBL_PTR(_param_62114)->dbl;
        }

        /** 				token old = {RECORDED, d[3]}*/
        _2 = (int)SEQ_PTR(_d_62104);
        _31069 = (int)*(((s1_ptr)_2)->base + 3);
        Ref(_31069);
        DeRef(_old_62117);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = 508;
        ((int *)_2)[2] = _31069;
        _old_62117 = MAKE_SEQ(_1);
        _31069 = NOVALUE;

        /** 				token new = {VARIABLE, sym}*/
        DeRefi(_new_62122);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = -100;
        ((int *)_2)[2] = _sym_62031;
        _new_62122 = MAKE_SEQ(_1);

        /** 				SymTab[param][S_CODE] = find_replace( old, SymTab[param][S_CODE], new )*/
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _27SymTab_10921 = MAKE_SEQ(_2);
        }
        _3 = (int)(_param_62114 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _31074 = (int)*(((s1_ptr)_2)->base + _param_62114);
        _2 = (int)SEQ_PTR(_31074);
        if (!IS_ATOM_INT(_26S_CODE_11666)){
            _31075 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_CODE_11666)->dbl));
        }
        else{
            _31075 = (int)*(((s1_ptr)_2)->base + _26S_CODE_11666);
        }
        _31074 = NOVALUE;
        RefDS(_old_62117);
        Ref(_31075);
        RefDS(_new_62122);
        _31076 = _14find_replace(_old_62117, _31075, _new_62122, 0);
        _31075 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_26S_CODE_11666))
        _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_CODE_11666)->dbl));
        else
        _2 = (int)(((s1_ptr)_2)->base + _26S_CODE_11666);
        _1 = *(int *)_2;
        *(int *)_2 = _31076;
        if( _1 != _31076 ){
            DeRef(_1);
        }
        _31076 = NOVALUE;
        _31072 = NOVALUE;
LC: 
        DeRef(_old_62117);
        _old_62117 = NOVALUE;
        DeRefi(_new_62122);
        _new_62122 = NOVALUE;
        DeRef(_d_62104);
        _d_62104 = NOVALUE;

        /** 		end for*/
        _i_62101 = _i_62101 + 1;
        goto LA; // [411] 309
LB: 
        ;
    }

    /** 		resolved_reference( ref )*/
    _29resolved_reference(_ref_62027);
L9: 

    /** 	reset_code()*/
    _29reset_code();

    /** end procedure*/
    DeRef(_tok_62026);
    DeRef(_fr_62028);
    _31060 = NOVALUE;
    DeRef(_31035);
    _31035 = NOVALUE;
    DeRef(_31030);
    _31030 = NOVALUE;
    return;
    ;
}


void _29patch_forward_init_check(int _tok_62138, int _ref_62139)
{
    int _fr_62140 = NOVALUE;
    int _31084 = NOVALUE;
    int _31083 = NOVALUE;
    int _31082 = NOVALUE;
    int _31080 = NOVALUE;
    int _31079 = NOVALUE;
    int _31078 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence fr = forward_references[ref]*/
    DeRef(_fr_62140);
    _2 = (int)SEQ_PTR(_29forward_references_61532);
    _fr_62140 = (int)*(((s1_ptr)_2)->base + _ref_62139);
    Ref(_fr_62140);

    /** 	set_code( ref )*/
    _29set_code(_ref_62139);

    /** 	if sequence( fr[FR_DATA] ) then*/
    _2 = (int)SEQ_PTR(_fr_62140);
    _31078 = (int)*(((s1_ptr)_2)->base + 12);
    _31079 = IS_SEQUENCE(_31078);
    _31078 = NOVALUE;
    if (_31079 == 0)
    {
        _31079 = NOVALUE;
        goto L1; // [27] 38
    }
    else{
        _31079 = NOVALUE;
    }

    /** 		resolved_reference( ref )*/
    _29resolved_reference(_ref_62139);
    goto L2; // [35] 85
L1: 

    /** 	elsif fr[FR_PC] > 0 then*/
    _2 = (int)SEQ_PTR(_fr_62140);
    _31080 = (int)*(((s1_ptr)_2)->base + 5);
    if (binary_op_a(LESSEQ, _31080, 0)){
        _31080 = NOVALUE;
        goto L3; // [44] 78
    }
    _31080 = NOVALUE;

    /** 		Code[fr[FR_PC]+1] = tok[T_SYM]*/
    _2 = (int)SEQ_PTR(_fr_62140);
    _31082 = (int)*(((s1_ptr)_2)->base + 5);
    if (IS_ATOM_INT(_31082)) {
        _31083 = _31082 + 1;
        if (_31083 > MAXINT){
            _31083 = NewDouble((double)_31083);
        }
    }
    else
    _31083 = binary_op(PLUS, 1, _31082);
    _31082 = NOVALUE;
    _2 = (int)SEQ_PTR(_tok_62138);
    _31084 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_31084);
    _2 = (int)SEQ_PTR(_26Code_12071);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _26Code_12071 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_31083))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_31083)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _31083);
    _1 = *(int *)_2;
    *(int *)_2 = _31084;
    if( _1 != _31084 ){
        DeRef(_1);
    }
    _31084 = NOVALUE;

    /** 		resolved_reference( ref )*/
    _29resolved_reference(_ref_62139);
    goto L2; // [75] 85
L3: 

    /** 		forward_error( tok, ref )*/
    Ref(_tok_62138);
    _29forward_error(_tok_62138, _ref_62139);
L2: 

    /** 	reset_code()*/
    _29reset_code();

    /** end procedure*/
    DeRef(_tok_62138);
    DeRef(_fr_62140);
    DeRef(_31083);
    _31083 = NOVALUE;
    return;
    ;
}


int _29expected_name(int _id_62157)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id_62157)) {
        _1 = (long)(DBL_PTR(_id_62157)->dbl);
        DeRefDS(_id_62157);
        _id_62157 = _1;
    }

    /** 	switch id with fallthru do*/
    _0 = _id_62157;
    switch ( _0 ){ 

        /** 		case PROC then*/
        case 27:
        case 195:

        /** 			return "a procedure"*/
        RefDS(_26395);
        return _26395;

        /** 		case FUNC then*/
        case 501:
        case 196:

        /** 			return "a function"*/
        RefDS(_26341);
        return _26341;

        /** 		case VARIABLE then*/
        case -100:

        /** 			return "a variable, constant or enum"*/
        RefDS(_31087);
        return _31087;

        /** 		case else*/
        default:

        /** 			return "something"*/
        RefDS(_31088);
        return _31088;
    ;}    ;
}


void _29patch_forward_type(int _tok_62174, int _ref_62175)
{
    int _fr_62176 = NOVALUE;
    int _syms_62178 = NOVALUE;
    int _31100 = NOVALUE;
    int _31099 = NOVALUE;
    int _31097 = NOVALUE;
    int _31096 = NOVALUE;
    int _31095 = NOVALUE;
    int _31093 = NOVALUE;
    int _31092 = NOVALUE;
    int _31091 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	sequence fr = forward_references[ref]*/
    DeRef(_fr_62176);
    _2 = (int)SEQ_PTR(_29forward_references_61532);
    _fr_62176 = (int)*(((s1_ptr)_2)->base + _ref_62175);
    Ref(_fr_62176);

    /** 	sequence syms = fr[FR_DATA]*/
    DeRef(_syms_62178);
    _2 = (int)SEQ_PTR(_fr_62176);
    _syms_62178 = (int)*(((s1_ptr)_2)->base + 12);
    Ref(_syms_62178);

    /** 	for i = 2 to length( syms ) do*/
    if (IS_SEQUENCE(_syms_62178)){
            _31091 = SEQ_PTR(_syms_62178)->length;
    }
    else {
        _31091 = 1;
    }
    {
        int _i_62181;
        _i_62181 = 2;
L1: 
        if (_i_62181 > _31091){
            goto L2; // [26] 102
        }

        /** 		SymTab[syms[i]][S_VTYPE] = tok[T_SYM]*/
        _2 = (int)SEQ_PTR(_syms_62178);
        _31092 = (int)*(((s1_ptr)_2)->base + _i_62181);
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _27SymTab_10921 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_31092))
        _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_31092)->dbl));
        else
        _3 = (int)(_31092 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(_tok_62174);
        _31095 = (int)*(((s1_ptr)_2)->base + 2);
        Ref(_31095);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 15);
        _1 = *(int *)_2;
        *(int *)_2 = _31095;
        if( _1 != _31095 ){
            DeRef(_1);
        }
        _31095 = NOVALUE;
        _31093 = NOVALUE;

        /** 		if TRANSLATE then*/
        if (_26TRANSLATE_11619 == 0)
        {
            goto L3; // [62] 95
        }
        else{
        }

        /** 			SymTab[syms[i]][S_GTYPE] = CompileType(tok[T_SYM])*/
        _2 = (int)SEQ_PTR(_syms_62178);
        _31096 = (int)*(((s1_ptr)_2)->base + _i_62181);
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _27SymTab_10921 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_31096))
        _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_31096)->dbl));
        else
        _3 = (int)(_31096 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(_tok_62174);
        _31099 = (int)*(((s1_ptr)_2)->base + 2);
        Ref(_31099);
        _31100 = _30CompileType(_31099);
        _31099 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 36);
        _1 = *(int *)_2;
        *(int *)_2 = _31100;
        if( _1 != _31100 ){
            DeRef(_1);
        }
        _31100 = NOVALUE;
        _31097 = NOVALUE;
L3: 

        /** 	end for*/
        _i_62181 = _i_62181 + 1;
        goto L1; // [97] 33
L2: 
        ;
    }

    /** 	resolved_reference( ref )*/
    _29resolved_reference(_ref_62175);

    /** end procedure*/
    DeRef(_tok_62174);
    DeRef(_fr_62176);
    DeRef(_syms_62178);
    _31092 = NOVALUE;
    _31096 = NOVALUE;
    return;
    ;
}


void _29patch_forward_case(int _tok_62204, int _ref_62205)
{
    int _fr_62206 = NOVALUE;
    int _switch_pc_62208 = NOVALUE;
    int _case_sym_62211 = NOVALUE;
    int _case_values_62240 = NOVALUE;
    int _cx_62245 = NOVALUE;
    int _negative_62253 = NOVALUE;
    int _31138 = NOVALUE;
    int _31137 = NOVALUE;
    int _31136 = NOVALUE;
    int _31135 = NOVALUE;
    int _31134 = NOVALUE;
    int _31133 = NOVALUE;
    int _31131 = NOVALUE;
    int _31129 = NOVALUE;
    int _31128 = NOVALUE;
    int _31126 = NOVALUE;
    int _31125 = NOVALUE;
    int _31122 = NOVALUE;
    int _31120 = NOVALUE;
    int _31119 = NOVALUE;
    int _31118 = NOVALUE;
    int _31117 = NOVALUE;
    int _31116 = NOVALUE;
    int _31115 = NOVALUE;
    int _31114 = NOVALUE;
    int _31113 = NOVALUE;
    int _31112 = NOVALUE;
    int _31110 = NOVALUE;
    int _31109 = NOVALUE;
    int _31108 = NOVALUE;
    int _31107 = NOVALUE;
    int _31105 = NOVALUE;
    int _31103 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	sequence fr = forward_references[ref]*/
    DeRef(_fr_62206);
    _2 = (int)SEQ_PTR(_29forward_references_61532);
    _fr_62206 = (int)*(((s1_ptr)_2)->base + _ref_62205);
    Ref(_fr_62206);

    /** 	integer switch_pc = fr[FR_DATA]*/
    _2 = (int)SEQ_PTR(_fr_62206);
    _switch_pc_62208 = (int)*(((s1_ptr)_2)->base + 12);
    if (!IS_ATOM_INT(_switch_pc_62208))
    _switch_pc_62208 = (long)DBL_PTR(_switch_pc_62208)->dbl;

    /** 	if fr[FR_SUBPROG] = TopLevelSub then*/
    _2 = (int)SEQ_PTR(_fr_62206);
    _31103 = (int)*(((s1_ptr)_2)->base + 4);
    if (binary_op_a(NOTEQ, _31103, _26TopLevelSub_11989)){
        _31103 = NOVALUE;
        goto L1; // [27] 48
    }
    _31103 = NOVALUE;

    /** 		case_sym = Code[switch_pc + 2]*/
    _31105 = _switch_pc_62208 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _case_sym_62211 = (int)*(((s1_ptr)_2)->base + _31105);
    if (!IS_ATOM_INT(_case_sym_62211)){
        _case_sym_62211 = (long)DBL_PTR(_case_sym_62211)->dbl;
    }
    goto L2; // [45] 77
L1: 

    /** 		case_sym = SymTab[fr[FR_SUBPROG]][S_CODE][switch_pc + 2]*/
    _2 = (int)SEQ_PTR(_fr_62206);
    _31107 = (int)*(((s1_ptr)_2)->base + 4);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!IS_ATOM_INT(_31107)){
        _31108 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_31107)->dbl));
    }
    else{
        _31108 = (int)*(((s1_ptr)_2)->base + _31107);
    }
    _2 = (int)SEQ_PTR(_31108);
    if (!IS_ATOM_INT(_26S_CODE_11666)){
        _31109 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_CODE_11666)->dbl));
    }
    else{
        _31109 = (int)*(((s1_ptr)_2)->base + _26S_CODE_11666);
    }
    _31108 = NOVALUE;
    _31110 = _switch_pc_62208 + 2;
    _2 = (int)SEQ_PTR(_31109);
    _case_sym_62211 = (int)*(((s1_ptr)_2)->base + _31110);
    if (!IS_ATOM_INT(_case_sym_62211)){
        _case_sym_62211 = (long)DBL_PTR(_case_sym_62211)->dbl;
    }
    _31109 = NOVALUE;
L2: 

    /** 	if SymTab[tok[T_SYM]][S_FILE_NO] = fr[FR_FILE] and fr[FR_SUBPROG] = TopLevelSub then*/
    _2 = (int)SEQ_PTR(_tok_62204);
    _31112 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!IS_ATOM_INT(_31112)){
        _31113 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_31112)->dbl));
    }
    else{
        _31113 = (int)*(((s1_ptr)_2)->base + _31112);
    }
    _2 = (int)SEQ_PTR(_31113);
    if (!IS_ATOM_INT(_26S_FILE_NO_11650)){
        _31114 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_FILE_NO_11650)->dbl));
    }
    else{
        _31114 = (int)*(((s1_ptr)_2)->base + _26S_FILE_NO_11650);
    }
    _31113 = NOVALUE;
    _2 = (int)SEQ_PTR(_fr_62206);
    _31115 = (int)*(((s1_ptr)_2)->base + 3);
    if (IS_ATOM_INT(_31114) && IS_ATOM_INT(_31115)) {
        _31116 = (_31114 == _31115);
    }
    else {
        _31116 = binary_op(EQUALS, _31114, _31115);
    }
    _31114 = NOVALUE;
    _31115 = NOVALUE;
    if (IS_ATOM_INT(_31116)) {
        if (_31116 == 0) {
            goto L3; // [105] 129
        }
    }
    else {
        if (DBL_PTR(_31116)->dbl == 0.0) {
            goto L3; // [105] 129
        }
    }
    _2 = (int)SEQ_PTR(_fr_62206);
    _31118 = (int)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_31118)) {
        _31119 = (_31118 == _26TopLevelSub_11989);
    }
    else {
        _31119 = binary_op(EQUALS, _31118, _26TopLevelSub_11989);
    }
    _31118 = NOVALUE;
    if (_31119 == 0) {
        DeRef(_31119);
        _31119 = NOVALUE;
        goto L3; // [120] 129
    }
    else {
        if (!IS_ATOM_INT(_31119) && DBL_PTR(_31119)->dbl == 0.0){
            DeRef(_31119);
            _31119 = NOVALUE;
            goto L3; // [120] 129
        }
        DeRef(_31119);
        _31119 = NOVALUE;
    }
    DeRef(_31119);
    _31119 = NOVALUE;

    /** 		return*/
    DeRef(_tok_62204);
    DeRef(_fr_62206);
    DeRef(_case_values_62240);
    DeRef(_31105);
    _31105 = NOVALUE;
    _31107 = NOVALUE;
    _31112 = NOVALUE;
    DeRef(_31110);
    _31110 = NOVALUE;
    DeRef(_31116);
    _31116 = NOVALUE;
    return;
L3: 

    /** 	sequence case_values = SymTab[case_sym][S_OBJ]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _31120 = (int)*(((s1_ptr)_2)->base + _case_sym_62211);
    DeRef(_case_values_62240);
    _2 = (int)SEQ_PTR(_31120);
    _case_values_62240 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_case_values_62240);
    _31120 = NOVALUE;

    /** 	integer cx = find( { ref }, case_values )*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _ref_62205;
    _31122 = MAKE_SEQ(_1);
    _cx_62245 = find_from(_31122, _case_values_62240, 1);
    DeRefDS(_31122);
    _31122 = NOVALUE;

    /** 	if not cx then*/
    if (_cx_62245 != 0)
    goto L4; // [160] 178

    /** 		cx = find( { -ref }, case_values )*/
    if ((unsigned long)_ref_62205 == 0xC0000000)
    _31125 = (int)NewDouble((double)-0xC0000000);
    else
    _31125 = - _ref_62205;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _31125;
    _31126 = MAKE_SEQ(_1);
    _31125 = NOVALUE;
    _cx_62245 = find_from(_31126, _case_values_62240, 1);
    DeRefDS(_31126);
    _31126 = NOVALUE;
L4: 

    /**  	ifdef DEBUG then	*/

    /** 	integer negative = 0*/
    _negative_62253 = 0;

    /** 	if case_values[cx][1] < 0 then*/
    _2 = (int)SEQ_PTR(_case_values_62240);
    _31128 = (int)*(((s1_ptr)_2)->base + _cx_62245);
    _2 = (int)SEQ_PTR(_31128);
    _31129 = (int)*(((s1_ptr)_2)->base + 1);
    _31128 = NOVALUE;
    if (binary_op_a(GREATEREQ, _31129, 0)){
        _31129 = NOVALUE;
        goto L5; // [195] 224
    }
    _31129 = NOVALUE;

    /** 		negative = 1*/
    _negative_62253 = 1;

    /** 		case_values[cx][1] *= -1*/
    _2 = (int)SEQ_PTR(_case_values_62240);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _case_values_62240 = MAKE_SEQ(_2);
    }
    _3 = (int)(_cx_62245 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    _31133 = (int)*(((s1_ptr)_2)->base + 1);
    _31131 = NOVALUE;
    if (IS_ATOM_INT(_31133)) {
        if (_31133 == (short)_31133)
        _31134 = _31133 * -1;
        else
        _31134 = NewDouble(_31133 * (double)-1);
    }
    else {
        _31134 = binary_op(MULTIPLY, _31133, -1);
    }
    _31133 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _31134;
    if( _1 != _31134 ){
        DeRef(_1);
    }
    _31134 = NOVALUE;
    _31131 = NOVALUE;
L5: 

    /** 	if negative then*/
    if (_negative_62253 == 0)
    {
        goto L6; // [226] 247
    }
    else{
    }

    /** 		case_values[cx] = - tok[T_SYM]*/
    _2 = (int)SEQ_PTR(_tok_62204);
    _31135 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_31135)) {
        if ((unsigned long)_31135 == 0xC0000000)
        _31136 = (int)NewDouble((double)-0xC0000000);
        else
        _31136 = - _31135;
    }
    else {
        _31136 = unary_op(UMINUS, _31135);
    }
    _31135 = NOVALUE;
    _2 = (int)SEQ_PTR(_case_values_62240);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _case_values_62240 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _cx_62245);
    _1 = *(int *)_2;
    *(int *)_2 = _31136;
    if( _1 != _31136 ){
        DeRef(_1);
    }
    _31136 = NOVALUE;
    goto L7; // [244] 260
L6: 

    /** 		case_values[cx] = tok[T_SYM]*/
    _2 = (int)SEQ_PTR(_tok_62204);
    _31137 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_31137);
    _2 = (int)SEQ_PTR(_case_values_62240);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _case_values_62240 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _cx_62245);
    _1 = *(int *)_2;
    *(int *)_2 = _31137;
    if( _1 != _31137 ){
        DeRef(_1);
    }
    _31137 = NOVALUE;
L7: 

    /** 	SymTab[case_sym][S_OBJ] = case_values*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_case_sym_62211 + ((s1_ptr)_2)->base);
    RefDS(_case_values_62240);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _case_values_62240;
    DeRef(_1);
    _31138 = NOVALUE;

    /** 	resolved_reference( ref )*/
    _29resolved_reference(_ref_62205);

    /** end procedure*/
    DeRef(_tok_62204);
    DeRef(_fr_62206);
    DeRefDS(_case_values_62240);
    DeRef(_31105);
    _31105 = NOVALUE;
    _31107 = NOVALUE;
    _31112 = NOVALUE;
    DeRef(_31110);
    _31110 = NOVALUE;
    DeRef(_31116);
    _31116 = NOVALUE;
    return;
    ;
}


void _29patch_forward_type_check(int _tok_62276, int _ref_62277)
{
    int _fr_62278 = NOVALUE;
    int _which_type_62281 = NOVALUE;
    int _var_62283 = NOVALUE;
    int _pc_62316 = NOVALUE;
    int _with_type_check_62318 = NOVALUE;
    int _c_62348 = NOVALUE;
    int _subprog_inlined_insert_code_at_332_62357 = NOVALUE;
    int _code_inlined_insert_code_at_329_62356 = NOVALUE;
    int _subprog_inlined_insert_code_at_415_62373 = NOVALUE;
    int _code_inlined_insert_code_at_412_62372 = NOVALUE;
    int _subprog_inlined_insert_code_at_477_62383 = NOVALUE;
    int _code_inlined_insert_code_at_474_62382 = NOVALUE;
    int _subprog_inlined_insert_code_at_539_62393 = NOVALUE;
    int _code_inlined_insert_code_at_536_62392 = NOVALUE;
    int _start_pc_62400 = NOVALUE;
    int _subprog_inlined_insert_code_at_647_62417 = NOVALUE;
    int _code_inlined_insert_code_at_644_62416 = NOVALUE;
    int _c_62420 = NOVALUE;
    int _subprog_inlined_insert_code_at_741_62436 = NOVALUE;
    int _code_inlined_insert_code_at_738_62435 = NOVALUE;
    int _start_pc_62447 = NOVALUE;
    int _subprog_inlined_insert_code_at_886_62467 = NOVALUE;
    int _code_inlined_insert_code_at_883_62466 = NOVALUE;
    int _subprog_inlined_insert_code_at_987_62488 = NOVALUE;
    int _code_inlined_insert_code_at_984_62487 = NOVALUE;
    int _31228 = NOVALUE;
    int _31227 = NOVALUE;
    int _31226 = NOVALUE;
    int _31225 = NOVALUE;
    int _31224 = NOVALUE;
    int _31223 = NOVALUE;
    int _31222 = NOVALUE;
    int _31220 = NOVALUE;
    int _31218 = NOVALUE;
    int _31217 = NOVALUE;
    int _31216 = NOVALUE;
    int _31215 = NOVALUE;
    int _31214 = NOVALUE;
    int _31213 = NOVALUE;
    int _31212 = NOVALUE;
    int _31210 = NOVALUE;
    int _31209 = NOVALUE;
    int _31208 = NOVALUE;
    int _31207 = NOVALUE;
    int _31206 = NOVALUE;
    int _31205 = NOVALUE;
    int _31203 = NOVALUE;
    int _31202 = NOVALUE;
    int _31201 = NOVALUE;
    int _31200 = NOVALUE;
    int _31198 = NOVALUE;
    int _31197 = NOVALUE;
    int _31194 = NOVALUE;
    int _31193 = NOVALUE;
    int _31191 = NOVALUE;
    int _31190 = NOVALUE;
    int _31189 = NOVALUE;
    int _31188 = NOVALUE;
    int _31187 = NOVALUE;
    int _31186 = NOVALUE;
    int _31184 = NOVALUE;
    int _31183 = NOVALUE;
    int _31180 = NOVALUE;
    int _31179 = NOVALUE;
    int _31176 = NOVALUE;
    int _31175 = NOVALUE;
    int _31171 = NOVALUE;
    int _31170 = NOVALUE;
    int _31168 = NOVALUE;
    int _31167 = NOVALUE;
    int _31165 = NOVALUE;
    int _31164 = NOVALUE;
    int _31161 = NOVALUE;
    int _31158 = NOVALUE;
    int _31156 = NOVALUE;
    int _31153 = NOVALUE;
    int _31152 = NOVALUE;
    int _31149 = NOVALUE;
    int _31144 = NOVALUE;
    int _31143 = NOVALUE;
    int _31141 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	sequence fr = forward_references[ref]*/
    DeRef(_fr_62278);
    _2 = (int)SEQ_PTR(_29forward_references_61532);
    _fr_62278 = (int)*(((s1_ptr)_2)->base + _ref_62277);
    Ref(_fr_62278);

    /** 	if fr[FR_OP] = TYPE_CHECK_FORWARD then*/
    _2 = (int)SEQ_PTR(_fr_62278);
    _31141 = (int)*(((s1_ptr)_2)->base + 10);
    if (binary_op_a(NOTEQ, _31141, 197)){
        _31141 = NOVALUE;
        goto L1; // [21] 86
    }
    _31141 = NOVALUE;

    /** 		which_type = SymTab[tok[T_SYM]][S_VTYPE]*/
    _2 = (int)SEQ_PTR(_tok_62276);
    _31143 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!IS_ATOM_INT(_31143)){
        _31144 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_31143)->dbl));
    }
    else{
        _31144 = (int)*(((s1_ptr)_2)->base + _31143);
    }
    _2 = (int)SEQ_PTR(_31144);
    _which_type_62281 = (int)*(((s1_ptr)_2)->base + 15);
    if (!IS_ATOM_INT(_which_type_62281)){
        _which_type_62281 = (long)DBL_PTR(_which_type_62281)->dbl;
    }
    _31144 = NOVALUE;

    /** 		if not which_type then*/
    if (_which_type_62281 != 0)
    goto L2; // [49] 72

    /** 			which_type = tok[T_SYM]*/
    _2 = (int)SEQ_PTR(_tok_62276);
    _which_type_62281 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_which_type_62281)){
        _which_type_62281 = (long)DBL_PTR(_which_type_62281)->dbl;
    }

    /** 			var = 0*/
    _var_62283 = 0;
    goto L3; // [69] 144
L2: 

    /** 			var = tok[T_SYM]*/
    _2 = (int)SEQ_PTR(_tok_62276);
    _var_62283 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_var_62283)){
        _var_62283 = (long)DBL_PTR(_var_62283)->dbl;
    }
    goto L3; // [83] 144
L1: 

    /** 	elsif fr[FR_OP] = TYPE then*/
    _2 = (int)SEQ_PTR(_fr_62278);
    _31149 = (int)*(((s1_ptr)_2)->base + 10);
    if (binary_op_a(NOTEQ, _31149, 504)){
        _31149 = NOVALUE;
        goto L4; // [94] 118
    }
    _31149 = NOVALUE;

    /** 		which_type = tok[T_SYM]*/
    _2 = (int)SEQ_PTR(_tok_62276);
    _which_type_62281 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_which_type_62281)){
        _which_type_62281 = (long)DBL_PTR(_which_type_62281)->dbl;
    }

    /** 		var = 0*/
    _var_62283 = 0;
    goto L3; // [115] 144
L4: 

    /** 		prep_forward_error( ref )*/
    _29prep_forward_error(_ref_62277);

    /** 		InternalErr( 262, { TYPE_CHECK, TYPE_CHECK_FORWARD, fr[FR_OP] })*/
    _2 = (int)SEQ_PTR(_fr_62278);
    _31152 = (int)*(((s1_ptr)_2)->base + 10);
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 65;
    *((int *)(_2+8)) = 197;
    Ref(_31152);
    *((int *)(_2+12)) = _31152;
    _31153 = MAKE_SEQ(_1);
    _31152 = NOVALUE;
    _43InternalErr(262, _31153);
    _31153 = NOVALUE;
L3: 

    /** 	if which_type < 0 then*/
    if (_which_type_62281 >= 0)
    goto L5; // [148] 158

    /** 		return*/
    DeRef(_tok_62276);
    DeRef(_fr_62278);
    _31143 = NOVALUE;
    return;
L5: 

    /** 	set_code( ref )*/
    _29set_code(_ref_62277);

    /** 	integer pc = fr[FR_PC]*/
    _2 = (int)SEQ_PTR(_fr_62278);
    _pc_62316 = (int)*(((s1_ptr)_2)->base + 5);
    if (!IS_ATOM_INT(_pc_62316))
    _pc_62316 = (long)DBL_PTR(_pc_62316)->dbl;

    /** 	integer with_type_check = Code[pc + 2]*/
    _31156 = _pc_62316 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _with_type_check_62318 = (int)*(((s1_ptr)_2)->base + _31156);
    if (!IS_ATOM_INT(_with_type_check_62318)){
        _with_type_check_62318 = (long)DBL_PTR(_with_type_check_62318)->dbl;
    }

    /** 	if Code[pc] != TYPE_CHECK_FORWARD then*/
    _2 = (int)SEQ_PTR(_26Code_12071);
    _31158 = (int)*(((s1_ptr)_2)->base + _pc_62316);
    if (binary_op_a(EQUALS, _31158, 197)){
        _31158 = NOVALUE;
        goto L6; // [193] 204
    }
    _31158 = NOVALUE;

    /** 		forward_error( tok, ref )*/
    Ref(_tok_62276);
    _29forward_error(_tok_62276, _ref_62277);
L6: 

    /** 	if not var then*/
    if (_var_62283 != 0)
    goto L7; // [208] 226

    /** 		var = Code[pc+1]*/
    _31161 = _pc_62316 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _var_62283 = (int)*(((s1_ptr)_2)->base + _31161);
    if (!IS_ATOM_INT(_var_62283)){
        _var_62283 = (long)DBL_PTR(_var_62283)->dbl;
    }
L7: 

    /** 	if var < 0 then*/
    if (_var_62283 >= 0)
    goto L8; // [228] 238

    /** 		return*/
    DeRef(_tok_62276);
    DeRef(_fr_62278);
    _31143 = NOVALUE;
    DeRef(_31156);
    _31156 = NOVALUE;
    DeRef(_31161);
    _31161 = NOVALUE;
    return;
L8: 

    /** 	replace_code( {}, pc, pc + 2, fr[FR_SUBPROG])*/
    _31164 = _pc_62316 + 2;
    if ((long)((unsigned long)_31164 + (unsigned long)HIGH_BITS) >= 0) 
    _31164 = NewDouble((double)_31164);
    _2 = (int)SEQ_PTR(_fr_62278);
    _31165 = (int)*(((s1_ptr)_2)->base + 4);
    RefDS(_22037);
    Ref(_31165);
    _29replace_code(_22037, _pc_62316, _31164, _31165);
    _31164 = NOVALUE;
    _31165 = NOVALUE;

    /** 	if TRANSLATE then*/
    if (_26TRANSLATE_11619 == 0)
    {
        goto L9; // [258] 364
    }
    else{
    }

    /** 		if with_type_check then*/
    if (_with_type_check_62318 == 0)
    {
        goto LA; // [263] 771
    }
    else{
    }

    /** 			if which_type != object_type then*/
    if (_which_type_62281 == _52object_type_46130)
    goto LA; // [270] 771

    /** 				if SymTab[which_type][S_EFFECT] then*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _31167 = (int)*(((s1_ptr)_2)->base + _which_type_62281);
    _2 = (int)SEQ_PTR(_31167);
    _31168 = (int)*(((s1_ptr)_2)->base + 23);
    _31167 = NOVALUE;
    if (_31168 == 0) {
        _31168 = NOVALUE;
        goto LB; // [288] 357
    }
    else {
        if (!IS_ATOM_INT(_31168) && DBL_PTR(_31168)->dbl == 0.0){
            _31168 = NOVALUE;
            goto LB; // [288] 357
        }
        _31168 = NOVALUE;
    }
    _31168 = NOVALUE;

    /** 					integer c = NewTempSym()*/
    _c_62348 = _52NewTempSym(0);
    if (!IS_ATOM_INT(_c_62348)) {
        _1 = (long)(DBL_PTR(_c_62348)->dbl);
        DeRefDS(_c_62348);
        _c_62348 = _1;
    }

    /** 					insert_code( { PROC, which_type, var, c, TYPE_CHECK }, pc, fr[FR_SUBPROG] )*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 27;
    *((int *)(_2+8)) = _which_type_62281;
    *((int *)(_2+12)) = _var_62283;
    *((int *)(_2+16)) = _c_62348;
    *((int *)(_2+20)) = 65;
    _31170 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_fr_62278);
    _31171 = (int)*(((s1_ptr)_2)->base + 4);
    DeRefi(_code_inlined_insert_code_at_329_62356);
    _code_inlined_insert_code_at_329_62356 = _31170;
    _31170 = NOVALUE;
    Ref(_31171);
    DeRef(_subprog_inlined_insert_code_at_332_62357);
    _subprog_inlined_insert_code_at_332_62357 = _31171;
    _31171 = NOVALUE;
    if (!IS_ATOM_INT(_subprog_inlined_insert_code_at_332_62357)) {
        _1 = (long)(DBL_PTR(_subprog_inlined_insert_code_at_332_62357)->dbl);
        DeRefDS(_subprog_inlined_insert_code_at_332_62357);
        _subprog_inlined_insert_code_at_332_62357 = _1;
    }

    /** 	shifting_sub = subprog*/
    _29shifting_sub_61551 = _subprog_inlined_insert_code_at_332_62357;

    /** 	shift:insert_code( code, index )*/
    RefDS(_code_inlined_insert_code_at_329_62356);
    _64insert_code(_code_inlined_insert_code_at_329_62356, _pc_62316);

    /** 	shifting_sub = 0*/
    _29shifting_sub_61551 = 0;

    /** end procedure*/
    goto LC; // [345] 348
LC: 
    DeRefi(_code_inlined_insert_code_at_329_62356);
    _code_inlined_insert_code_at_329_62356 = NOVALUE;
    DeRef(_subprog_inlined_insert_code_at_332_62357);
    _subprog_inlined_insert_code_at_332_62357 = NOVALUE;

    /** 					pc += 5*/
    _pc_62316 = _pc_62316 + 5;
LB: 
    goto LA; // [361] 771
L9: 

    /** 		if with_type_check then*/
    if (_with_type_check_62318 == 0)
    {
        goto LD; // [366] 770
    }
    else{
    }

    /** 			if which_type = object_type then*/
    if (_which_type_62281 != _52object_type_46130)
    goto LE; // [373] 380
    goto LF; // [377] 769
LE: 

    /** 				if which_type = integer_type then*/
    if (_which_type_62281 != _52integer_type_46136)
    goto L10; // [384] 442

    /** 					insert_code( { INTEGER_CHECK, var }, pc, fr[FR_SUBPROG] )*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 96;
    ((int *)_2)[2] = _var_62283;
    _31175 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_fr_62278);
    _31176 = (int)*(((s1_ptr)_2)->base + 4);
    DeRefi(_code_inlined_insert_code_at_412_62372);
    _code_inlined_insert_code_at_412_62372 = _31175;
    _31175 = NOVALUE;
    Ref(_31176);
    DeRef(_subprog_inlined_insert_code_at_415_62373);
    _subprog_inlined_insert_code_at_415_62373 = _31176;
    _31176 = NOVALUE;
    if (!IS_ATOM_INT(_subprog_inlined_insert_code_at_415_62373)) {
        _1 = (long)(DBL_PTR(_subprog_inlined_insert_code_at_415_62373)->dbl);
        DeRefDS(_subprog_inlined_insert_code_at_415_62373);
        _subprog_inlined_insert_code_at_415_62373 = _1;
    }

    /** 	shifting_sub = subprog*/
    _29shifting_sub_61551 = _subprog_inlined_insert_code_at_415_62373;

    /** 	shift:insert_code( code, index )*/
    RefDS(_code_inlined_insert_code_at_412_62372);
    _64insert_code(_code_inlined_insert_code_at_412_62372, _pc_62316);

    /** 	shifting_sub = 0*/
    _29shifting_sub_61551 = 0;

    /** end procedure*/
    goto L11; // [428] 431
L11: 
    DeRefi(_code_inlined_insert_code_at_412_62372);
    _code_inlined_insert_code_at_412_62372 = NOVALUE;
    DeRef(_subprog_inlined_insert_code_at_415_62373);
    _subprog_inlined_insert_code_at_415_62373 = NOVALUE;

    /** 					pc += 2*/
    _pc_62316 = _pc_62316 + 2;
    goto L12; // [439] 768
L10: 

    /** 				elsif which_type = sequence_type then*/
    if (_which_type_62281 != _52sequence_type_46134)
    goto L13; // [446] 504

    /** 					insert_code( { SEQUENCE_CHECK, var }, pc, fr[FR_SUBPROG])*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 97;
    ((int *)_2)[2] = _var_62283;
    _31179 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_fr_62278);
    _31180 = (int)*(((s1_ptr)_2)->base + 4);
    DeRefi(_code_inlined_insert_code_at_474_62382);
    _code_inlined_insert_code_at_474_62382 = _31179;
    _31179 = NOVALUE;
    Ref(_31180);
    DeRef(_subprog_inlined_insert_code_at_477_62383);
    _subprog_inlined_insert_code_at_477_62383 = _31180;
    _31180 = NOVALUE;
    if (!IS_ATOM_INT(_subprog_inlined_insert_code_at_477_62383)) {
        _1 = (long)(DBL_PTR(_subprog_inlined_insert_code_at_477_62383)->dbl);
        DeRefDS(_subprog_inlined_insert_code_at_477_62383);
        _subprog_inlined_insert_code_at_477_62383 = _1;
    }

    /** 	shifting_sub = subprog*/
    _29shifting_sub_61551 = _subprog_inlined_insert_code_at_477_62383;

    /** 	shift:insert_code( code, index )*/
    RefDS(_code_inlined_insert_code_at_474_62382);
    _64insert_code(_code_inlined_insert_code_at_474_62382, _pc_62316);

    /** 	shifting_sub = 0*/
    _29shifting_sub_61551 = 0;

    /** end procedure*/
    goto L14; // [490] 493
L14: 
    DeRefi(_code_inlined_insert_code_at_474_62382);
    _code_inlined_insert_code_at_474_62382 = NOVALUE;
    DeRef(_subprog_inlined_insert_code_at_477_62383);
    _subprog_inlined_insert_code_at_477_62383 = NOVALUE;

    /** 					pc += 2*/
    _pc_62316 = _pc_62316 + 2;
    goto L12; // [501] 768
L13: 

    /** 				elsif which_type = atom_type then*/
    if (_which_type_62281 != _52atom_type_46132)
    goto L15; // [508] 566

    /** 					insert_code( { ATOM_CHECK, var }, pc, fr[FR_SUBPROG] )*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 101;
    ((int *)_2)[2] = _var_62283;
    _31183 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_fr_62278);
    _31184 = (int)*(((s1_ptr)_2)->base + 4);
    DeRefi(_code_inlined_insert_code_at_536_62392);
    _code_inlined_insert_code_at_536_62392 = _31183;
    _31183 = NOVALUE;
    Ref(_31184);
    DeRef(_subprog_inlined_insert_code_at_539_62393);
    _subprog_inlined_insert_code_at_539_62393 = _31184;
    _31184 = NOVALUE;
    if (!IS_ATOM_INT(_subprog_inlined_insert_code_at_539_62393)) {
        _1 = (long)(DBL_PTR(_subprog_inlined_insert_code_at_539_62393)->dbl);
        DeRefDS(_subprog_inlined_insert_code_at_539_62393);
        _subprog_inlined_insert_code_at_539_62393 = _1;
    }

    /** 	shifting_sub = subprog*/
    _29shifting_sub_61551 = _subprog_inlined_insert_code_at_539_62393;

    /** 	shift:insert_code( code, index )*/
    RefDS(_code_inlined_insert_code_at_536_62392);
    _64insert_code(_code_inlined_insert_code_at_536_62392, _pc_62316);

    /** 	shifting_sub = 0*/
    _29shifting_sub_61551 = 0;

    /** end procedure*/
    goto L16; // [552] 555
L16: 
    DeRefi(_code_inlined_insert_code_at_536_62392);
    _code_inlined_insert_code_at_536_62392 = NOVALUE;
    DeRef(_subprog_inlined_insert_code_at_539_62393);
    _subprog_inlined_insert_code_at_539_62393 = NOVALUE;

    /** 					pc += 2*/
    _pc_62316 = _pc_62316 + 2;
    goto L12; // [563] 768
L15: 

    /** 				elsif SymTab[which_type][S_NEXT] then*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _31186 = (int)*(((s1_ptr)_2)->base + _which_type_62281);
    _2 = (int)SEQ_PTR(_31186);
    _31187 = (int)*(((s1_ptr)_2)->base + 2);
    _31186 = NOVALUE;
    if (_31187 == 0) {
        _31187 = NOVALUE;
        goto L17; // [580] 765
    }
    else {
        if (!IS_ATOM_INT(_31187) && DBL_PTR(_31187)->dbl == 0.0){
            _31187 = NOVALUE;
            goto L17; // [580] 765
        }
        _31187 = NOVALUE;
    }
    _31187 = NOVALUE;

    /** 					integer start_pc = pc*/
    _start_pc_62400 = _pc_62316;

    /** 					if SymTab[SymTab[which_type][S_NEXT]][S_VTYPE] = integer_type then*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _31188 = (int)*(((s1_ptr)_2)->base + _which_type_62281);
    _2 = (int)SEQ_PTR(_31188);
    _31189 = (int)*(((s1_ptr)_2)->base + 2);
    _31188 = NOVALUE;
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!IS_ATOM_INT(_31189)){
        _31190 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_31189)->dbl));
    }
    else{
        _31190 = (int)*(((s1_ptr)_2)->base + _31189);
    }
    _2 = (int)SEQ_PTR(_31190);
    _31191 = (int)*(((s1_ptr)_2)->base + 15);
    _31190 = NOVALUE;
    if (binary_op_a(NOTEQ, _31191, _52integer_type_46136)){
        _31191 = NOVALUE;
        goto L18; // [616] 672
    }
    _31191 = NOVALUE;

    /** 						insert_code( { INTEGER_CHECK, var }, pc, fr[FR_SUBPROG] )*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 96;
    ((int *)_2)[2] = _var_62283;
    _31193 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_fr_62278);
    _31194 = (int)*(((s1_ptr)_2)->base + 4);
    DeRefi(_code_inlined_insert_code_at_644_62416);
    _code_inlined_insert_code_at_644_62416 = _31193;
    _31193 = NOVALUE;
    Ref(_31194);
    DeRef(_subprog_inlined_insert_code_at_647_62417);
    _subprog_inlined_insert_code_at_647_62417 = _31194;
    _31194 = NOVALUE;
    if (!IS_ATOM_INT(_subprog_inlined_insert_code_at_647_62417)) {
        _1 = (long)(DBL_PTR(_subprog_inlined_insert_code_at_647_62417)->dbl);
        DeRefDS(_subprog_inlined_insert_code_at_647_62417);
        _subprog_inlined_insert_code_at_647_62417 = _1;
    }

    /** 	shifting_sub = subprog*/
    _29shifting_sub_61551 = _subprog_inlined_insert_code_at_647_62417;

    /** 	shift:insert_code( code, index )*/
    RefDS(_code_inlined_insert_code_at_644_62416);
    _64insert_code(_code_inlined_insert_code_at_644_62416, _pc_62316);

    /** 	shifting_sub = 0*/
    _29shifting_sub_61551 = 0;

    /** end procedure*/
    goto L19; // [660] 663
L19: 
    DeRefi(_code_inlined_insert_code_at_644_62416);
    _code_inlined_insert_code_at_644_62416 = NOVALUE;
    DeRef(_subprog_inlined_insert_code_at_647_62417);
    _subprog_inlined_insert_code_at_647_62417 = NOVALUE;

    /** 						pc += 2*/
    _pc_62316 = _pc_62316 + 2;
L18: 

    /** 					symtab_index c = NewTempSym()*/
    _c_62420 = _52NewTempSym(0);
    if (!IS_ATOM_INT(_c_62420)) {
        _1 = (long)(DBL_PTR(_c_62420)->dbl);
        DeRefDS(_c_62420);
        _c_62420 = _1;
    }

    /** 					SymTab[fr[FR_SUBPROG]][S_STACK_SPACE] += 1*/
    _2 = (int)SEQ_PTR(_fr_62278);
    _31197 = (int)*(((s1_ptr)_2)->base + 4);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_31197))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_31197)->dbl));
    else
    _3 = (int)(_31197 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!IS_ATOM_INT(_26S_STACK_SPACE_11714)){
        _31200 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_STACK_SPACE_11714)->dbl));
    }
    else{
        _31200 = (int)*(((s1_ptr)_2)->base + _26S_STACK_SPACE_11714);
    }
    _31198 = NOVALUE;
    if (IS_ATOM_INT(_31200)) {
        _31201 = _31200 + 1;
        if (_31201 > MAXINT){
            _31201 = NewDouble((double)_31201);
        }
    }
    else
    _31201 = binary_op(PLUS, 1, _31200);
    _31200 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_26S_STACK_SPACE_11714))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_STACK_SPACE_11714)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _26S_STACK_SPACE_11714);
    _1 = *(int *)_2;
    *(int *)_2 = _31201;
    if( _1 != _31201 ){
        DeRef(_1);
    }
    _31201 = NOVALUE;
    _31198 = NOVALUE;

    /** 					insert_code( { PROC, which_type, var, c, TYPE_CHECK }, pc, fr[FR_SUBPROG] )*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 27;
    *((int *)(_2+8)) = _which_type_62281;
    *((int *)(_2+12)) = _var_62283;
    *((int *)(_2+16)) = _c_62420;
    *((int *)(_2+20)) = 65;
    _31202 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_fr_62278);
    _31203 = (int)*(((s1_ptr)_2)->base + 4);
    DeRefi(_code_inlined_insert_code_at_738_62435);
    _code_inlined_insert_code_at_738_62435 = _31202;
    _31202 = NOVALUE;
    Ref(_31203);
    DeRef(_subprog_inlined_insert_code_at_741_62436);
    _subprog_inlined_insert_code_at_741_62436 = _31203;
    _31203 = NOVALUE;
    if (!IS_ATOM_INT(_subprog_inlined_insert_code_at_741_62436)) {
        _1 = (long)(DBL_PTR(_subprog_inlined_insert_code_at_741_62436)->dbl);
        DeRefDS(_subprog_inlined_insert_code_at_741_62436);
        _subprog_inlined_insert_code_at_741_62436 = _1;
    }

    /** 	shifting_sub = subprog*/
    _29shifting_sub_61551 = _subprog_inlined_insert_code_at_741_62436;

    /** 	shift:insert_code( code, index )*/
    RefDS(_code_inlined_insert_code_at_738_62435);
    _64insert_code(_code_inlined_insert_code_at_738_62435, _pc_62316);

    /** 	shifting_sub = 0*/
    _29shifting_sub_61551 = 0;

    /** end procedure*/
    goto L1A; // [753] 756
L1A: 
    DeRefi(_code_inlined_insert_code_at_738_62435);
    _code_inlined_insert_code_at_738_62435 = NOVALUE;
    DeRef(_subprog_inlined_insert_code_at_741_62436);
    _subprog_inlined_insert_code_at_741_62436 = NOVALUE;

    /** 					pc += 4*/
    _pc_62316 = _pc_62316 + 4;
L17: 
L12: 
LF: 
LD: 
LA: 

    /** 	if (TRANSLATE or not with_type_check) and SymTab[which_type][S_NEXT] then*/
    if (_26TRANSLATE_11619 != 0) {
        _31205 = 1;
        goto L1B; // [775] 786
    }
    _31206 = (_with_type_check_62318 == 0);
    _31205 = (_31206 != 0);
L1B: 
    if (_31205 == 0) {
        goto L1C; // [786] 1013
    }
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _31208 = (int)*(((s1_ptr)_2)->base + _which_type_62281);
    _2 = (int)SEQ_PTR(_31208);
    _31209 = (int)*(((s1_ptr)_2)->base + 2);
    _31208 = NOVALUE;
    if (_31209 == 0) {
        _31209 = NOVALUE;
        goto L1C; // [803] 1013
    }
    else {
        if (!IS_ATOM_INT(_31209) && DBL_PTR(_31209)->dbl == 0.0){
            _31209 = NOVALUE;
            goto L1C; // [803] 1013
        }
        _31209 = NOVALUE;
    }
    _31209 = NOVALUE;

    /** 		integer start_pc = pc*/
    _start_pc_62447 = _pc_62316;

    /** 		if which_type = sequence_type or*/
    _31210 = (_which_type_62281 == _52sequence_type_46134);
    if (_31210 != 0) {
        goto L1D; // [819] 858
    }
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _31212 = (int)*(((s1_ptr)_2)->base + _which_type_62281);
    _2 = (int)SEQ_PTR(_31212);
    _31213 = (int)*(((s1_ptr)_2)->base + 2);
    _31212 = NOVALUE;
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!IS_ATOM_INT(_31213)){
        _31214 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_31213)->dbl));
    }
    else{
        _31214 = (int)*(((s1_ptr)_2)->base + _31213);
    }
    _2 = (int)SEQ_PTR(_31214);
    _31215 = (int)*(((s1_ptr)_2)->base + 15);
    _31214 = NOVALUE;
    if (IS_ATOM_INT(_31215)) {
        _31216 = (_31215 == _52sequence_type_46134);
    }
    else {
        _31216 = binary_op(EQUALS, _31215, _52sequence_type_46134);
    }
    _31215 = NOVALUE;
    if (_31216 == 0) {
        DeRef(_31216);
        _31216 = NOVALUE;
        goto L1E; // [854] 912
    }
    else {
        if (!IS_ATOM_INT(_31216) && DBL_PTR(_31216)->dbl == 0.0){
            DeRef(_31216);
            _31216 = NOVALUE;
            goto L1E; // [854] 912
        }
        DeRef(_31216);
        _31216 = NOVALUE;
    }
    DeRef(_31216);
    _31216 = NOVALUE;
L1D: 

    /** 			insert_code( { SEQUENCE_CHECK, var }, pc, fr[FR_SUBPROG] )*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 97;
    ((int *)_2)[2] = _var_62283;
    _31217 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_fr_62278);
    _31218 = (int)*(((s1_ptr)_2)->base + 4);
    DeRefi(_code_inlined_insert_code_at_883_62466);
    _code_inlined_insert_code_at_883_62466 = _31217;
    _31217 = NOVALUE;
    Ref(_31218);
    DeRef(_subprog_inlined_insert_code_at_886_62467);
    _subprog_inlined_insert_code_at_886_62467 = _31218;
    _31218 = NOVALUE;
    if (!IS_ATOM_INT(_subprog_inlined_insert_code_at_886_62467)) {
        _1 = (long)(DBL_PTR(_subprog_inlined_insert_code_at_886_62467)->dbl);
        DeRefDS(_subprog_inlined_insert_code_at_886_62467);
        _subprog_inlined_insert_code_at_886_62467 = _1;
    }

    /** 	shifting_sub = subprog*/
    _29shifting_sub_61551 = _subprog_inlined_insert_code_at_886_62467;

    /** 	shift:insert_code( code, index )*/
    RefDS(_code_inlined_insert_code_at_883_62466);
    _64insert_code(_code_inlined_insert_code_at_883_62466, _pc_62316);

    /** 	shifting_sub = 0*/
    _29shifting_sub_61551 = 0;

    /** end procedure*/
    goto L1F; // [898] 901
L1F: 
    DeRefi(_code_inlined_insert_code_at_883_62466);
    _code_inlined_insert_code_at_883_62466 = NOVALUE;
    DeRef(_subprog_inlined_insert_code_at_886_62467);
    _subprog_inlined_insert_code_at_886_62467 = NOVALUE;

    /** 			pc += 2*/
    _pc_62316 = _pc_62316 + 2;
    goto L20; // [909] 1012
L1E: 

    /** 		elsif which_type = integer_type or*/
    _31220 = (_which_type_62281 == _52integer_type_46136);
    if (_31220 != 0) {
        goto L21; // [920] 959
    }
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _31222 = (int)*(((s1_ptr)_2)->base + _which_type_62281);
    _2 = (int)SEQ_PTR(_31222);
    _31223 = (int)*(((s1_ptr)_2)->base + 2);
    _31222 = NOVALUE;
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!IS_ATOM_INT(_31223)){
        _31224 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_31223)->dbl));
    }
    else{
        _31224 = (int)*(((s1_ptr)_2)->base + _31223);
    }
    _2 = (int)SEQ_PTR(_31224);
    _31225 = (int)*(((s1_ptr)_2)->base + 15);
    _31224 = NOVALUE;
    if (IS_ATOM_INT(_31225)) {
        _31226 = (_31225 == _52integer_type_46136);
    }
    else {
        _31226 = binary_op(EQUALS, _31225, _52integer_type_46136);
    }
    _31225 = NOVALUE;
    if (_31226 == 0) {
        DeRef(_31226);
        _31226 = NOVALUE;
        goto L22; // [955] 1011
    }
    else {
        if (!IS_ATOM_INT(_31226) && DBL_PTR(_31226)->dbl == 0.0){
            DeRef(_31226);
            _31226 = NOVALUE;
            goto L22; // [955] 1011
        }
        DeRef(_31226);
        _31226 = NOVALUE;
    }
    DeRef(_31226);
    _31226 = NOVALUE;
L21: 

    /** 			insert_code( { INTEGER_CHECK, var }, pc, fr[FR_SUBPROG] )*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 96;
    ((int *)_2)[2] = _var_62283;
    _31227 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_fr_62278);
    _31228 = (int)*(((s1_ptr)_2)->base + 4);
    DeRefi(_code_inlined_insert_code_at_984_62487);
    _code_inlined_insert_code_at_984_62487 = _31227;
    _31227 = NOVALUE;
    Ref(_31228);
    DeRef(_subprog_inlined_insert_code_at_987_62488);
    _subprog_inlined_insert_code_at_987_62488 = _31228;
    _31228 = NOVALUE;
    if (!IS_ATOM_INT(_subprog_inlined_insert_code_at_987_62488)) {
        _1 = (long)(DBL_PTR(_subprog_inlined_insert_code_at_987_62488)->dbl);
        DeRefDS(_subprog_inlined_insert_code_at_987_62488);
        _subprog_inlined_insert_code_at_987_62488 = _1;
    }

    /** 	shifting_sub = subprog*/
    _29shifting_sub_61551 = _subprog_inlined_insert_code_at_987_62488;

    /** 	shift:insert_code( code, index )*/
    RefDS(_code_inlined_insert_code_at_984_62487);
    _64insert_code(_code_inlined_insert_code_at_984_62487, _pc_62316);

    /** 	shifting_sub = 0*/
    _29shifting_sub_61551 = 0;

    /** end procedure*/
    goto L23; // [999] 1002
L23: 
    DeRefi(_code_inlined_insert_code_at_984_62487);
    _code_inlined_insert_code_at_984_62487 = NOVALUE;
    DeRef(_subprog_inlined_insert_code_at_987_62488);
    _subprog_inlined_insert_code_at_987_62488 = NOVALUE;

    /** 			pc += 4*/
    _pc_62316 = _pc_62316 + 4;
L22: 
L20: 
L1C: 

    /** 	resolved_reference( ref )*/
    _29resolved_reference(_ref_62277);

    /** 	reset_code()*/
    _29reset_code();

    /** end procedure*/
    DeRef(_tok_62276);
    DeRef(_fr_62278);
    _31143 = NOVALUE;
    DeRef(_31156);
    _31156 = NOVALUE;
    DeRef(_31161);
    _31161 = NOVALUE;
    _31189 = NOVALUE;
    _31197 = NOVALUE;
    DeRef(_31206);
    _31206 = NOVALUE;
    DeRef(_31210);
    _31210 = NOVALUE;
    _31213 = NOVALUE;
    DeRef(_31220);
    _31220 = NOVALUE;
    _31223 = NOVALUE;
    return;
    ;
}


void _29prep_forward_error(int _ref_62492)
{
    int _31236 = NOVALUE;
    int _31234 = NOVALUE;
    int _31232 = NOVALUE;
    int _31230 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_ref_62492)) {
        _1 = (long)(DBL_PTR(_ref_62492)->dbl);
        DeRefDS(_ref_62492);
        _ref_62492 = _1;
    }

    /** 	ThisLine = forward_references[ref][FR_THISLINE]*/
    _2 = (int)SEQ_PTR(_29forward_references_61532);
    _31230 = (int)*(((s1_ptr)_2)->base + _ref_62492);
    DeRef(_43ThisLine_48557);
    _2 = (int)SEQ_PTR(_31230);
    _43ThisLine_48557 = (int)*(((s1_ptr)_2)->base + 7);
    Ref(_43ThisLine_48557);
    _31230 = NOVALUE;

    /** 	bp = forward_references[ref][FR_BP]*/
    _2 = (int)SEQ_PTR(_29forward_references_61532);
    _31232 = (int)*(((s1_ptr)_2)->base + _ref_62492);
    _2 = (int)SEQ_PTR(_31232);
    _43bp_48561 = (int)*(((s1_ptr)_2)->base + 8);
    if (!IS_ATOM_INT(_43bp_48561)){
        _43bp_48561 = (long)DBL_PTR(_43bp_48561)->dbl;
    }
    _31232 = NOVALUE;

    /** 	line_number = forward_references[ref][FR_LINE]*/
    _2 = (int)SEQ_PTR(_29forward_references_61532);
    _31234 = (int)*(((s1_ptr)_2)->base + _ref_62492);
    _2 = (int)SEQ_PTR(_31234);
    _26line_number_11983 = (int)*(((s1_ptr)_2)->base + 6);
    if (!IS_ATOM_INT(_26line_number_11983)){
        _26line_number_11983 = (long)DBL_PTR(_26line_number_11983)->dbl;
    }
    _31234 = NOVALUE;

    /** 	current_file_no = forward_references[ref][FR_FILE]*/
    _2 = (int)SEQ_PTR(_29forward_references_61532);
    _31236 = (int)*(((s1_ptr)_2)->base + _ref_62492);
    _2 = (int)SEQ_PTR(_31236);
    _26current_file_no_11982 = (int)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_26current_file_no_11982)){
        _26current_file_no_11982 = (long)DBL_PTR(_26current_file_no_11982)->dbl;
    }
    _31236 = NOVALUE;

    /** end procedure*/
    return;
    ;
}


void _29forward_error(int _tok_62508, int _ref_62509)
{
    int _31243 = NOVALUE;
    int _31242 = NOVALUE;
    int _31241 = NOVALUE;
    int _31240 = NOVALUE;
    int _31239 = NOVALUE;
    int _31238 = NOVALUE;
    int _0, _1, _2;
    

    /** 	prep_forward_error( ref )*/
    _29prep_forward_error(_ref_62509);

    /** 	CompileErr(68, { expected_name( forward_references[ref][FR_TYPE] ),*/
    _2 = (int)SEQ_PTR(_29forward_references_61532);
    _31238 = (int)*(((s1_ptr)_2)->base + _ref_62509);
    _2 = (int)SEQ_PTR(_31238);
    _31239 = (int)*(((s1_ptr)_2)->base + 1);
    _31238 = NOVALUE;
    Ref(_31239);
    _31240 = _29expected_name(_31239);
    _31239 = NOVALUE;
    _2 = (int)SEQ_PTR(_tok_62508);
    _31241 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_31241);
    _31242 = _29expected_name(_31241);
    _31241 = NOVALUE;
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _31240;
    ((int *)_2)[2] = _31242;
    _31243 = MAKE_SEQ(_1);
    _31242 = NOVALUE;
    _31240 = NOVALUE;
    _43CompileErr(68, _31243, 0);
    _31243 = NOVALUE;

    /** end procedure*/
    DeRef(_tok_62508);
    return;
    ;
}


int _29find_reference(int _fr_62520)
{
    int _name_62521 = NOVALUE;
    int _file_62523 = NOVALUE;
    int _ns_file_62525 = NOVALUE;
    int _ix_62526 = NOVALUE;
    int _ns_62529 = NOVALUE;
    int _ns_tok_62533 = NOVALUE;
    int _tok_62545 = NOVALUE;
    int _31254 = NOVALUE;
    int _31251 = NOVALUE;
    int _31249 = NOVALUE;
    int _31247 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence name = fr[FR_NAME]*/
    DeRef(_name_62521);
    _2 = (int)SEQ_PTR(_fr_62520);
    _name_62521 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_name_62521);

    /** 	integer file  = fr[FR_FILE]*/
    _2 = (int)SEQ_PTR(_fr_62520);
    _file_62523 = (int)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_file_62523))
    _file_62523 = (long)DBL_PTR(_file_62523)->dbl;

    /** 	integer ns_file = -1*/
    _ns_file_62525 = -1;

    /** 	integer ix = find( ':', name )*/
    _ix_62526 = find_from(58, _name_62521, 1);

    /** 	if ix then*/
    if (_ix_62526 == 0)
    {
        goto L1; // [31] 85
    }
    else{
    }

    /** 		sequence ns = name[1..ix-1]*/
    _31247 = _ix_62526 - 1;
    rhs_slice_target = (object_ptr)&_ns_62529;
    RHS_Slice(_name_62521, 1, _31247);

    /** 		token ns_tok = keyfind( ns, ns_file, file, 1, fr[FR_HASHVAL] )*/
    _2 = (int)SEQ_PTR(_fr_62520);
    _31249 = (int)*(((s1_ptr)_2)->base + 11);
    RefDS(_ns_62529);
    Ref(_31249);
    _0 = _ns_tok_62533;
    _ns_tok_62533 = _52keyfind(_ns_62529, -1, _file_62523, 1, _31249);
    DeRef(_0);
    _31249 = NOVALUE;

    /** 		if ns_tok[T_ID] != NAMESPACE then*/
    _2 = (int)SEQ_PTR(_ns_tok_62533);
    _31251 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _31251, 523)){
        _31251 = NOVALUE;
        goto L2; // [69] 80
    }
    _31251 = NOVALUE;

    /** 			return ns_tok*/
    DeRefDS(_ns_62529);
    DeRefDS(_fr_62520);
    DeRefDS(_name_62521);
    DeRef(_tok_62545);
    _31247 = NOVALUE;
    return _ns_tok_62533;
L2: 
    DeRef(_ns_62529);
    _ns_62529 = NOVALUE;
    DeRef(_ns_tok_62533);
    _ns_tok_62533 = NOVALUE;
    goto L3; // [82] 92
L1: 

    /** 		ns_file = fr[FR_QUALIFIED]*/
    _2 = (int)SEQ_PTR(_fr_62520);
    _ns_file_62525 = (int)*(((s1_ptr)_2)->base + 9);
    if (!IS_ATOM_INT(_ns_file_62525))
    _ns_file_62525 = (long)DBL_PTR(_ns_file_62525)->dbl;
L3: 

    /** 	No_new_entry = 1*/
    _52No_new_entry_47302 = 1;

    /** 	object tok = keyfind( name, ns_file, file, , fr[FR_HASHVAL] )*/
    _2 = (int)SEQ_PTR(_fr_62520);
    _31254 = (int)*(((s1_ptr)_2)->base + 11);
    RefDS(_name_62521);
    Ref(_31254);
    _0 = _tok_62545;
    _tok_62545 = _52keyfind(_name_62521, _ns_file_62525, _file_62523, 0, _31254);
    DeRef(_0);
    _31254 = NOVALUE;

    /** 	No_new_entry = 0*/
    _52No_new_entry_47302 = 0;

    /** 	return tok*/
    DeRefDS(_fr_62520);
    DeRefDS(_name_62521);
    DeRef(_31247);
    _31247 = NOVALUE;
    return _tok_62545;
    ;
}


void _29register_forward_type(int _sym_62553, int _ref_62554)
{
    int _31261 = NOVALUE;
    int _31260 = NOVALUE;
    int _31258 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_sym_62553)) {
        _1 = (long)(DBL_PTR(_sym_62553)->dbl);
        DeRefDS(_sym_62553);
        _sym_62553 = _1;
    }
    if (!IS_ATOM_INT(_ref_62554)) {
        _1 = (long)(DBL_PTR(_ref_62554)->dbl);
        DeRefDS(_ref_62554);
        _ref_62554 = _1;
    }

    /** 	if ref < 0 then*/
    if (_ref_62554 >= 0)
    goto L1; // [7] 19

    /** 		ref = -ref*/
    _ref_62554 = - _ref_62554;
L1: 

    /** 	forward_references[ref][FR_DATA] &= sym*/
    _2 = (int)SEQ_PTR(_29forward_references_61532);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29forward_references_61532 = MAKE_SEQ(_2);
    }
    _3 = (int)(_ref_62554 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    _31260 = (int)*(((s1_ptr)_2)->base + 12);
    _31258 = NOVALUE;
    if (IS_SEQUENCE(_31260) && IS_ATOM(_sym_62553)) {
        Append(&_31261, _31260, _sym_62553);
    }
    else if (IS_ATOM(_31260) && IS_SEQUENCE(_sym_62553)) {
    }
    else {
        Concat((object_ptr)&_31261, _31260, _sym_62553);
        _31260 = NOVALUE;
    }
    _31260 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 12);
    _1 = *(int *)_2;
    *(int *)_2 = _31261;
    if( _1 != _31261 ){
        DeRef(_1);
    }
    _31261 = NOVALUE;
    _31258 = NOVALUE;

    /** end procedure*/
    return;
    ;
}


int _29forward_reference(int _ref_62564)
{
    int _31274 = NOVALUE;
    int _31273 = NOVALUE;
    int _31272 = NOVALUE;
    int _31271 = NOVALUE;
    int _31270 = NOVALUE;
    int _31269 = NOVALUE;
    int _31268 = NOVALUE;
    int _31266 = NOVALUE;
    int _31265 = NOVALUE;
    int _31264 = NOVALUE;
    int _31263 = NOVALUE;
    int _31262 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_ref_62564)) {
        _1 = (long)(DBL_PTR(_ref_62564)->dbl);
        DeRefDS(_ref_62564);
        _ref_62564 = _1;
    }

    /** 	if 0 > ref and ref >= -length( forward_references ) then*/
    _31262 = (0 > _ref_62564);
    if (_31262 == 0) {
        goto L1; // [9] 91
    }
    if (IS_SEQUENCE(_29forward_references_61532)){
            _31264 = SEQ_PTR(_29forward_references_61532)->length;
    }
    else {
        _31264 = 1;
    }
    _31265 = - _31264;
    _31266 = (_ref_62564 >= _31265);
    _31265 = NOVALUE;
    if (_31266 == 0)
    {
        DeRef(_31266);
        _31266 = NOVALUE;
        goto L1; // [26] 91
    }
    else{
        DeRef(_31266);
        _31266 = NOVALUE;
    }

    /** 		ref = -ref*/
    _ref_62564 = - _ref_62564;

    /** 		if integer(forward_references[ref][FR_FILE]) and*/
    _2 = (int)SEQ_PTR(_29forward_references_61532);
    _31268 = (int)*(((s1_ptr)_2)->base + _ref_62564);
    _2 = (int)SEQ_PTR(_31268);
    _31269 = (int)*(((s1_ptr)_2)->base + 3);
    _31268 = NOVALUE;
    if (IS_ATOM_INT(_31269))
    _31270 = 1;
    else if (IS_ATOM_DBL(_31269))
    _31270 = IS_ATOM_INT(DoubleToInt(_31269));
    else
    _31270 = 0;
    _31269 = NOVALUE;
    if (_31270 == 0) {
        goto L2; // [51] 81
    }
    _2 = (int)SEQ_PTR(_29forward_references_61532);
    _31272 = (int)*(((s1_ptr)_2)->base + _ref_62564);
    _2 = (int)SEQ_PTR(_31272);
    _31273 = (int)*(((s1_ptr)_2)->base + 5);
    _31272 = NOVALUE;
    if (IS_ATOM_INT(_31273))
    _31274 = 1;
    else if (IS_ATOM_DBL(_31273))
    _31274 = IS_ATOM_INT(DoubleToInt(_31273));
    else
    _31274 = 0;
    _31273 = NOVALUE;
    if (_31274 == 0)
    {
        _31274 = NOVALUE;
        goto L2; // [69] 81
    }
    else{
        _31274 = NOVALUE;
    }

    /** 				return 1*/
    DeRef(_31262);
    _31262 = NOVALUE;
    return 1;
    goto L3; // [78] 98
L2: 

    /** 			return 0*/
    DeRef(_31262);
    _31262 = NOVALUE;
    return 0;
    goto L3; // [88] 98
L1: 

    /** 		return 0*/
    DeRef(_31262);
    _31262 = NOVALUE;
    return 0;
L3: 
    ;
}


int _29new_forward_reference(int _fwd_op_62584, int _sym_62586, int _op_62587)
{
    int _ref_62588 = NOVALUE;
    int _len_62589 = NOVALUE;
    int _hashval_62619 = NOVALUE;
    int _default_sym_62694 = NOVALUE;
    int _param_62697 = NOVALUE;
    int _set_data_2__tmp_at578_62714 = NOVALUE;
    int _set_data_1__tmp_at578_62713 = NOVALUE;
    int _data_inlined_set_data_at_575_62712 = NOVALUE;
    int _31347 = NOVALUE;
    int _31346 = NOVALUE;
    int _31345 = NOVALUE;
    int _31342 = NOVALUE;
    int _31340 = NOVALUE;
    int _31339 = NOVALUE;
    int _31337 = NOVALUE;
    int _31336 = NOVALUE;
    int _31335 = NOVALUE;
    int _31333 = NOVALUE;
    int _31331 = NOVALUE;
    int _31329 = NOVALUE;
    int _31326 = NOVALUE;
    int _31325 = NOVALUE;
    int _31323 = NOVALUE;
    int _31321 = NOVALUE;
    int _31319 = NOVALUE;
    int _31317 = NOVALUE;
    int _31316 = NOVALUE;
    int _31315 = NOVALUE;
    int _31313 = NOVALUE;
    int _31310 = NOVALUE;
    int _31308 = NOVALUE;
    int _31306 = NOVALUE;
    int _31305 = NOVALUE;
    int _31304 = NOVALUE;
    int _31303 = NOVALUE;
    int _31301 = NOVALUE;
    int _31298 = NOVALUE;
    int _31297 = NOVALUE;
    int _31296 = NOVALUE;
    int _31294 = NOVALUE;
    int _31293 = NOVALUE;
    int _31292 = NOVALUE;
    int _31291 = NOVALUE;
    int _31289 = NOVALUE;
    int _31288 = NOVALUE;
    int _31287 = NOVALUE;
    int _31286 = NOVALUE;
    int _31284 = NOVALUE;
    int _31281 = NOVALUE;
    int _31280 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_fwd_op_62584)) {
        _1 = (long)(DBL_PTR(_fwd_op_62584)->dbl);
        DeRefDS(_fwd_op_62584);
        _fwd_op_62584 = _1;
    }
    if (!IS_ATOM_INT(_sym_62586)) {
        _1 = (long)(DBL_PTR(_sym_62586)->dbl);
        DeRefDS(_sym_62586);
        _sym_62586 = _1;
    }
    if (!IS_ATOM_INT(_op_62587)) {
        _1 = (long)(DBL_PTR(_op_62587)->dbl);
        DeRefDS(_op_62587);
        _op_62587 = _1;
    }

    /** 		len = length( inactive_references )*/
    if (IS_SEQUENCE(_29inactive_references_61536)){
            _len_62589 = SEQ_PTR(_29inactive_references_61536)->length;
    }
    else {
        _len_62589 = 1;
    }

    /** 	if len then*/
    if (_len_62589 == 0)
    {
        goto L1; // [16] 39
    }
    else{
    }

    /** 		ref = inactive_references[len]*/
    _2 = (int)SEQ_PTR(_29inactive_references_61536);
    _ref_62588 = (int)*(((s1_ptr)_2)->base + _len_62589);
    if (!IS_ATOM_INT(_ref_62588))
    _ref_62588 = (long)DBL_PTR(_ref_62588)->dbl;

    /** 		inactive_references = remove( inactive_references, len, len )*/
    {
        s1_ptr assign_space = SEQ_PTR(_29inactive_references_61536);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_len_62589)) ? _len_62589 : (long)(DBL_PTR(_len_62589)->dbl);
        int stop = (IS_ATOM_INT(_len_62589)) ? _len_62589 : (long)(DBL_PTR(_len_62589)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_29inactive_references_61536), start, &_29inactive_references_61536 );
            }
            else Tail(SEQ_PTR(_29inactive_references_61536), stop+1, &_29inactive_references_61536);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_29inactive_references_61536), start, &_29inactive_references_61536);
        }
        else {
            assign_slice_seq = &assign_space;
            _29inactive_references_61536 = Remove_elements(start, stop, (SEQ_PTR(_29inactive_references_61536)->ref == 1));
        }
    }
    goto L2; // [36] 55
L1: 

    /** 		forward_references &= 0*/
    Append(&_29forward_references_61532, _29forward_references_61532, 0);

    /** 		ref = length( forward_references )*/
    if (IS_SEQUENCE(_29forward_references_61532)){
            _ref_62588 = SEQ_PTR(_29forward_references_61532)->length;
    }
    else {
        _ref_62588 = 1;
    }
L2: 

    /** 	forward_references[ref] = repeat( 0, FR_SIZE )*/
    _31280 = Repeat(0, 12);
    _2 = (int)SEQ_PTR(_29forward_references_61532);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29forward_references_61532 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _ref_62588);
    _1 = *(int *)_2;
    *(int *)_2 = _31280;
    if( _1 != _31280 ){
        DeRef(_1);
    }
    _31280 = NOVALUE;

    /** 	forward_references[ref][FR_TYPE]      = fwd_op*/
    _2 = (int)SEQ_PTR(_29forward_references_61532);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29forward_references_61532 = MAKE_SEQ(_2);
    }
    _3 = (int)(_ref_62588 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _fwd_op_62584;
    DeRef(_1);
    _31281 = NOVALUE;

    /** 	if sym < 0 then*/
    if (_sym_62586 >= 0)
    goto L3; // [84] 143

    /** 		forward_references[ref][FR_NAME] = forward_references[-sym][FR_NAME]*/
    _2 = (int)SEQ_PTR(_29forward_references_61532);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29forward_references_61532 = MAKE_SEQ(_2);
    }
    _3 = (int)(_ref_62588 + ((s1_ptr)_2)->base);
    if ((unsigned long)_sym_62586 == 0xC0000000)
    _31286 = (int)NewDouble((double)-0xC0000000);
    else
    _31286 = - _sym_62586;
    _2 = (int)SEQ_PTR(_29forward_references_61532);
    if (!IS_ATOM_INT(_31286)){
        _31287 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_31286)->dbl));
    }
    else{
        _31287 = (int)*(((s1_ptr)_2)->base + _31286);
    }
    _2 = (int)SEQ_PTR(_31287);
    _31288 = (int)*(((s1_ptr)_2)->base + 2);
    _31287 = NOVALUE;
    Ref(_31288);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _31288;
    if( _1 != _31288 ){
        DeRef(_1);
    }
    _31288 = NOVALUE;
    _31284 = NOVALUE;

    /** 		forward_references[ref][FR_HASHVAL] = forward_references[-sym][FR_HASHVAL]*/
    _2 = (int)SEQ_PTR(_29forward_references_61532);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29forward_references_61532 = MAKE_SEQ(_2);
    }
    _3 = (int)(_ref_62588 + ((s1_ptr)_2)->base);
    if ((unsigned long)_sym_62586 == 0xC0000000)
    _31291 = (int)NewDouble((double)-0xC0000000);
    else
    _31291 = - _sym_62586;
    _2 = (int)SEQ_PTR(_29forward_references_61532);
    if (!IS_ATOM_INT(_31291)){
        _31292 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_31291)->dbl));
    }
    else{
        _31292 = (int)*(((s1_ptr)_2)->base + _31291);
    }
    _2 = (int)SEQ_PTR(_31292);
    _31293 = (int)*(((s1_ptr)_2)->base + 11);
    _31292 = NOVALUE;
    Ref(_31293);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 11);
    _1 = *(int *)_2;
    *(int *)_2 = _31293;
    if( _1 != _31293 ){
        DeRef(_1);
    }
    _31293 = NOVALUE;
    _31289 = NOVALUE;
    goto L4; // [140] 242
L3: 

    /** 		forward_references[ref][FR_NAME] = SymTab[sym][S_NAME]*/
    _2 = (int)SEQ_PTR(_29forward_references_61532);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29forward_references_61532 = MAKE_SEQ(_2);
    }
    _3 = (int)(_ref_62588 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _31296 = (int)*(((s1_ptr)_2)->base + _sym_62586);
    _2 = (int)SEQ_PTR(_31296);
    if (!IS_ATOM_INT(_26S_NAME_11654)){
        _31297 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NAME_11654)->dbl));
    }
    else{
        _31297 = (int)*(((s1_ptr)_2)->base + _26S_NAME_11654);
    }
    _31296 = NOVALUE;
    Ref(_31297);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _31297;
    if( _1 != _31297 ){
        DeRef(_1);
    }
    _31297 = NOVALUE;
    _31294 = NOVALUE;

    /** 		integer hashval = SymTab[sym][S_HASHVAL]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _31298 = (int)*(((s1_ptr)_2)->base + _sym_62586);
    _2 = (int)SEQ_PTR(_31298);
    _hashval_62619 = (int)*(((s1_ptr)_2)->base + 11);
    if (!IS_ATOM_INT(_hashval_62619)){
        _hashval_62619 = (long)DBL_PTR(_hashval_62619)->dbl;
    }
    _31298 = NOVALUE;

    /** 		if 0 = hashval then*/
    if (0 != _hashval_62619)
    goto L5; // [186] 220

    /** 			forward_references[ref][FR_HASHVAL] = hashfn( forward_references[ref][FR_NAME] )*/
    _2 = (int)SEQ_PTR(_29forward_references_61532);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29forward_references_61532 = MAKE_SEQ(_2);
    }
    _3 = (int)(_ref_62588 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_29forward_references_61532);
    _31303 = (int)*(((s1_ptr)_2)->base + _ref_62588);
    _2 = (int)SEQ_PTR(_31303);
    _31304 = (int)*(((s1_ptr)_2)->base + 2);
    _31303 = NOVALUE;
    Ref(_31304);
    _31305 = _52hashfn(_31304);
    _31304 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 11);
    _1 = *(int *)_2;
    *(int *)_2 = _31305;
    if( _1 != _31305 ){
        DeRef(_1);
    }
    _31305 = NOVALUE;
    _31301 = NOVALUE;
    goto L6; // [217] 239
L5: 

    /** 			forward_references[ref][FR_HASHVAL] = hashval*/
    _2 = (int)SEQ_PTR(_29forward_references_61532);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29forward_references_61532 = MAKE_SEQ(_2);
    }
    _3 = (int)(_ref_62588 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 11);
    _1 = *(int *)_2;
    *(int *)_2 = _hashval_62619;
    DeRef(_1);
    _31306 = NOVALUE;

    /** 			remove_symbol( sym )*/
    _52remove_symbol(_sym_62586);
L6: 
L4: 

    /** 	forward_references[ref][FR_FILE]      = current_file_no*/
    _2 = (int)SEQ_PTR(_29forward_references_61532);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29forward_references_61532 = MAKE_SEQ(_2);
    }
    _3 = (int)(_ref_62588 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = _26current_file_no_11982;
    DeRef(_1);
    _31308 = NOVALUE;

    /** 	forward_references[ref][FR_SUBPROG]   = CurrentSub*/
    _2 = (int)SEQ_PTR(_29forward_references_61532);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29forward_references_61532 = MAKE_SEQ(_2);
    }
    _3 = (int)(_ref_62588 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = _26CurrentSub_11990;
    DeRef(_1);
    _31310 = NOVALUE;

    /** 	if fwd_op != TYPE then*/
    if (_fwd_op_62584 == 504)
    goto L7; // [276] 303

    /** 		forward_references[ref][FR_PC]        = length( Code ) + 1*/
    _2 = (int)SEQ_PTR(_29forward_references_61532);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29forward_references_61532 = MAKE_SEQ(_2);
    }
    _3 = (int)(_ref_62588 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_26Code_12071)){
            _31315 = SEQ_PTR(_26Code_12071)->length;
    }
    else {
        _31315 = 1;
    }
    _31316 = _31315 + 1;
    _31315 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = _31316;
    if( _1 != _31316 ){
        DeRef(_1);
    }
    _31316 = NOVALUE;
    _31313 = NOVALUE;
L7: 

    /** 	forward_references[ref][FR_LINE]      = fwd_line_number*/
    _2 = (int)SEQ_PTR(_29forward_references_61532);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29forward_references_61532 = MAKE_SEQ(_2);
    }
    _3 = (int)(_ref_62588 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 6);
    _1 = *(int *)_2;
    *(int *)_2 = _26fwd_line_number_11984;
    DeRef(_1);
    _31317 = NOVALUE;

    /** 	forward_references[ref][FR_THISLINE]  = ForwardLine*/
    _2 = (int)SEQ_PTR(_29forward_references_61532);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29forward_references_61532 = MAKE_SEQ(_2);
    }
    _3 = (int)(_ref_62588 + ((s1_ptr)_2)->base);
    Ref(_43ForwardLine_48558);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 7);
    _1 = *(int *)_2;
    *(int *)_2 = _43ForwardLine_48558;
    DeRef(_1);
    _31319 = NOVALUE;

    /** 	forward_references[ref][FR_BP]        = forward_bp*/
    _2 = (int)SEQ_PTR(_29forward_references_61532);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29forward_references_61532 = MAKE_SEQ(_2);
    }
    _3 = (int)(_ref_62588 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 8);
    _1 = *(int *)_2;
    *(int *)_2 = _43forward_bp_48562;
    DeRef(_1);
    _31321 = NOVALUE;

    /** 	forward_references[ref][FR_QUALIFIED] = get_qualified_fwd()*/
    _2 = (int)SEQ_PTR(_29forward_references_61532);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29forward_references_61532 = MAKE_SEQ(_2);
    }
    _3 = (int)(_ref_62588 + ((s1_ptr)_2)->base);
    _31325 = _60get_qualified_fwd();
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 9);
    _1 = *(int *)_2;
    *(int *)_2 = _31325;
    if( _1 != _31325 ){
        DeRef(_1);
    }
    _31325 = NOVALUE;
    _31323 = NOVALUE;

    /** 	forward_references[ref][FR_OP]        = op*/
    _2 = (int)SEQ_PTR(_29forward_references_61532);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29forward_references_61532 = MAKE_SEQ(_2);
    }
    _3 = (int)(_ref_62588 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 10);
    _1 = *(int *)_2;
    *(int *)_2 = _op_62587;
    DeRef(_1);
    _31326 = NOVALUE;

    /** 	if op = GOTO then*/
    if (_op_62587 != 188)
    goto L8; // [381] 403

    /** 		forward_references[ref][FR_DATA] = { sym }*/
    _2 = (int)SEQ_PTR(_29forward_references_61532);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29forward_references_61532 = MAKE_SEQ(_2);
    }
    _3 = (int)(_ref_62588 + ((s1_ptr)_2)->base);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _sym_62586;
    _31331 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 12);
    _1 = *(int *)_2;
    *(int *)_2 = _31331;
    if( _1 != _31331 ){
        DeRef(_1);
    }
    _31331 = NOVALUE;
    _31329 = NOVALUE;
L8: 

    /** 	if CurrentSub = TopLevelSub then*/
    if (_26CurrentSub_11990 != _26TopLevelSub_11989)
    goto L9; // [409] 471

    /** 		if length( toplevel_references ) < current_file_no then*/
    if (IS_SEQUENCE(_29toplevel_references_61535)){
            _31333 = SEQ_PTR(_29toplevel_references_61535)->length;
    }
    else {
        _31333 = 1;
    }
    if (_31333 >= _26current_file_no_11982)
    goto LA; // [422] 450

    /** 			toplevel_references &= repeat( {}, current_file_no - length( toplevel_references ) )*/
    if (IS_SEQUENCE(_29toplevel_references_61535)){
            _31335 = SEQ_PTR(_29toplevel_references_61535)->length;
    }
    else {
        _31335 = 1;
    }
    _31336 = _26current_file_no_11982 - _31335;
    _31335 = NOVALUE;
    _31337 = Repeat(_22037, _31336);
    _31336 = NOVALUE;
    Concat((object_ptr)&_29toplevel_references_61535, _29toplevel_references_61535, _31337);
    DeRefDS(_31337);
    _31337 = NOVALUE;
LA: 

    /** 		toplevel_references[current_file_no] &= ref*/
    _2 = (int)SEQ_PTR(_29toplevel_references_61535);
    _31339 = (int)*(((s1_ptr)_2)->base + _26current_file_no_11982);
    if (IS_SEQUENCE(_31339) && IS_ATOM(_ref_62588)) {
        Append(&_31340, _31339, _ref_62588);
    }
    else if (IS_ATOM(_31339) && IS_SEQUENCE(_ref_62588)) {
    }
    else {
        Concat((object_ptr)&_31340, _31339, _ref_62588);
        _31339 = NOVALUE;
    }
    _31339 = NOVALUE;
    _2 = (int)SEQ_PTR(_29toplevel_references_61535);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29toplevel_references_61535 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _26current_file_no_11982);
    _1 = *(int *)_2;
    *(int *)_2 = _31340;
    if( _1 != _31340 ){
        DeRef(_1);
    }
    _31340 = NOVALUE;
    goto LB; // [468] 595
L9: 

    /** 		add_active_reference( ref )*/
    _29add_active_reference(_ref_62588, _26current_file_no_11982);

    /** 		if Parser_mode = PAM_RECORD then*/
    if (_26Parser_mode_12088 != 1)
    goto LC; // [485] 592

    /** 			symtab_pointer default_sym = CurrentSub*/
    _default_sym_62694 = _26CurrentSub_11990;

    /** 			symtab_pointer param = 0*/
    _param_62697 = 0;

    /** 			while default_sym with entry do*/
    goto LD; // [507] 536
LE: 
    if (_default_sym_62694 == 0)
    {
        goto LF; // [510] 549
    }
    else{
    }

    /** 				if sym_scope( default_sym ) = SC_PRIVATE then*/
    _31342 = _52sym_scope(_default_sym_62694);
    if (binary_op_a(NOTEQ, _31342, 3)){
        DeRef(_31342);
        _31342 = NOVALUE;
        goto L10; // [521] 533
    }
    DeRef(_31342);
    _31342 = NOVALUE;

    /** 					param = default_sym*/
    _param_62697 = _default_sym_62694;
L10: 

    /** 			entry*/
LD: 

    /** 				default_sym = sym_next( default_sym )*/
    _default_sym_62694 = _52sym_next(_default_sym_62694);
    if (!IS_ATOM_INT(_default_sym_62694)) {
        _1 = (long)(DBL_PTR(_default_sym_62694)->dbl);
        DeRefDS(_default_sym_62694);
        _default_sym_62694 = _1;
    }

    /** 			end while*/
    goto LE; // [546] 510
LF: 

    /** 			set_data( ref, {{ PAM_RECORD, param, length( Recorded_sym ) }} )*/
    if (IS_SEQUENCE(_26Recorded_sym_12091)){
            _31345 = SEQ_PTR(_26Recorded_sym_12091)->length;
    }
    else {
        _31345 = 1;
    }
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = _param_62697;
    *((int *)(_2+12)) = _31345;
    _31346 = MAKE_SEQ(_1);
    _31345 = NOVALUE;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _31346;
    _31347 = MAKE_SEQ(_1);
    _31346 = NOVALUE;
    DeRef(_data_inlined_set_data_at_575_62712);
    _data_inlined_set_data_at_575_62712 = _31347;
    _31347 = NOVALUE;

    /** 	forward_references[ref][FR_DATA] = data*/
    _2 = (int)SEQ_PTR(_29forward_references_61532);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29forward_references_61532 = MAKE_SEQ(_2);
    }
    _3 = (int)(_ref_62588 + ((s1_ptr)_2)->base);
    RefDS(_data_inlined_set_data_at_575_62712);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 12);
    _1 = *(int *)_2;
    *(int *)_2 = _data_inlined_set_data_at_575_62712;
    DeRef(_1);

    /** end procedure*/
    goto L11; // [586] 589
L11: 
    DeRef(_data_inlined_set_data_at_575_62712);
    _data_inlined_set_data_at_575_62712 = NOVALUE;
LC: 
LB: 

    /** 	fwdref_count += 1*/
    _29fwdref_count_61552 = _29fwdref_count_61552 + 1;

    /** 	return ref*/
    DeRef(_31286);
    _31286 = NOVALUE;
    DeRef(_31291);
    _31291 = NOVALUE;
    return _ref_62588;
    ;
}


void _29add_active_reference(int _ref_62718, int _file_no_62719)
{
    int _sp_62733 = NOVALUE;
    int _31371 = NOVALUE;
    int _31370 = NOVALUE;
    int _31368 = NOVALUE;
    int _31367 = NOVALUE;
    int _31366 = NOVALUE;
    int _31364 = NOVALUE;
    int _31363 = NOVALUE;
    int _31362 = NOVALUE;
    int _31359 = NOVALUE;
    int _31357 = NOVALUE;
    int _31356 = NOVALUE;
    int _31355 = NOVALUE;
    int _31353 = NOVALUE;
    int _31352 = NOVALUE;
    int _31351 = NOVALUE;
    int _31349 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	if length( active_references ) < file_no then*/
    if (IS_SEQUENCE(_29active_references_61534)){
            _31349 = SEQ_PTR(_29active_references_61534)->length;
    }
    else {
        _31349 = 1;
    }
    if (_31349 >= _file_no_62719)
    goto L1; // [12] 59

    /** 		active_references &= repeat( {}, file_no - length( active_references ) )*/
    if (IS_SEQUENCE(_29active_references_61534)){
            _31351 = SEQ_PTR(_29active_references_61534)->length;
    }
    else {
        _31351 = 1;
    }
    _31352 = _file_no_62719 - _31351;
    _31351 = NOVALUE;
    _31353 = Repeat(_22037, _31352);
    _31352 = NOVALUE;
    Concat((object_ptr)&_29active_references_61534, _29active_references_61534, _31353);
    DeRefDS(_31353);
    _31353 = NOVALUE;

    /** 		active_subprogs   &= repeat( {}, file_no - length( active_subprogs ) )*/
    if (IS_SEQUENCE(_29active_subprogs_61533)){
            _31355 = SEQ_PTR(_29active_subprogs_61533)->length;
    }
    else {
        _31355 = 1;
    }
    _31356 = _file_no_62719 - _31355;
    _31355 = NOVALUE;
    _31357 = Repeat(_22037, _31356);
    _31356 = NOVALUE;
    Concat((object_ptr)&_29active_subprogs_61533, _29active_subprogs_61533, _31357);
    DeRefDS(_31357);
    _31357 = NOVALUE;
L1: 

    /** 	integer sp = find( CurrentSub, active_subprogs[file_no] )*/
    _2 = (int)SEQ_PTR(_29active_subprogs_61533);
    _31359 = (int)*(((s1_ptr)_2)->base + _file_no_62719);
    _sp_62733 = find_from(_26CurrentSub_11990, _31359, 1);
    _31359 = NOVALUE;

    /** 	if not sp then*/
    if (_sp_62733 != 0)
    goto L2; // [76] 127

    /** 		active_subprogs[file_no] &= CurrentSub*/
    _2 = (int)SEQ_PTR(_29active_subprogs_61533);
    _31362 = (int)*(((s1_ptr)_2)->base + _file_no_62719);
    if (IS_SEQUENCE(_31362) && IS_ATOM(_26CurrentSub_11990)) {
        Append(&_31363, _31362, _26CurrentSub_11990);
    }
    else if (IS_ATOM(_31362) && IS_SEQUENCE(_26CurrentSub_11990)) {
    }
    else {
        Concat((object_ptr)&_31363, _31362, _26CurrentSub_11990);
        _31362 = NOVALUE;
    }
    _31362 = NOVALUE;
    _2 = (int)SEQ_PTR(_29active_subprogs_61533);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29active_subprogs_61533 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _file_no_62719);
    _1 = *(int *)_2;
    *(int *)_2 = _31363;
    if( _1 != _31363 ){
        DeRef(_1);
    }
    _31363 = NOVALUE;

    /** 		sp = length( active_subprogs[file_no] )*/
    _2 = (int)SEQ_PTR(_29active_subprogs_61533);
    _31364 = (int)*(((s1_ptr)_2)->base + _file_no_62719);
    if (IS_SEQUENCE(_31364)){
            _sp_62733 = SEQ_PTR(_31364)->length;
    }
    else {
        _sp_62733 = 1;
    }
    _31364 = NOVALUE;

    /** 		active_references[file_no] = append( active_references[file_no], {} )*/
    _2 = (int)SEQ_PTR(_29active_references_61534);
    _31366 = (int)*(((s1_ptr)_2)->base + _file_no_62719);
    RefDS(_22037);
    Append(&_31367, _31366, _22037);
    _31366 = NOVALUE;
    _2 = (int)SEQ_PTR(_29active_references_61534);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29active_references_61534 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _file_no_62719);
    _1 = *(int *)_2;
    *(int *)_2 = _31367;
    if( _1 != _31367 ){
        DeRef(_1);
    }
    _31367 = NOVALUE;
L2: 

    /** 	active_references[file_no][sp] &= ref*/
    _2 = (int)SEQ_PTR(_29active_references_61534);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29active_references_61534 = MAKE_SEQ(_2);
    }
    _3 = (int)(_file_no_62719 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    _31370 = (int)*(((s1_ptr)_2)->base + _sp_62733);
    _31368 = NOVALUE;
    if (IS_SEQUENCE(_31370) && IS_ATOM(_ref_62718)) {
        Append(&_31371, _31370, _ref_62718);
    }
    else if (IS_ATOM(_31370) && IS_SEQUENCE(_ref_62718)) {
    }
    else {
        Concat((object_ptr)&_31371, _31370, _ref_62718);
        _31370 = NOVALUE;
    }
    _31370 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _sp_62733);
    _1 = *(int *)_2;
    *(int *)_2 = _31371;
    if( _1 != _31371 ){
        DeRef(_1);
    }
    _31371 = NOVALUE;
    _31368 = NOVALUE;

    /** end procedure*/
    _31364 = NOVALUE;
    return;
    ;
}


int _29resolve_file(int _refs_62770, int _report_errors_62771, int _unincluded_ok_62772)
{
    int _errors_62773 = NOVALUE;
    int _ref_62777 = NOVALUE;
    int _fr_62779 = NOVALUE;
    int _tok_62792 = NOVALUE;
    int _code_sub_62800 = NOVALUE;
    int _fr_type_62802 = NOVALUE;
    int _sym_tok_62804 = NOVALUE;
    int _31425 = NOVALUE;
    int _31424 = NOVALUE;
    int _31423 = NOVALUE;
    int _31422 = NOVALUE;
    int _31421 = NOVALUE;
    int _31420 = NOVALUE;
    int _31415 = NOVALUE;
    int _31414 = NOVALUE;
    int _31413 = NOVALUE;
    int _31411 = NOVALUE;
    int _31410 = NOVALUE;
    int _31407 = NOVALUE;
    int _31406 = NOVALUE;
    int _31405 = NOVALUE;
    int _31401 = NOVALUE;
    int _31400 = NOVALUE;
    int _31392 = NOVALUE;
    int _31390 = NOVALUE;
    int _31389 = NOVALUE;
    int _31388 = NOVALUE;
    int _31387 = NOVALUE;
    int _31386 = NOVALUE;
    int _31385 = NOVALUE;
    int _31382 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence errors = {}*/
    RefDS(_22037);
    DeRefi(_errors_62773);
    _errors_62773 = _22037;

    /** 	for ar = length( refs ) to 1 by -1 do*/
    if (IS_SEQUENCE(_refs_62770)){
            _31382 = SEQ_PTR(_refs_62770)->length;
    }
    else {
        _31382 = 1;
    }
    {
        int _ar_62775;
        _ar_62775 = _31382;
L1: 
        if (_ar_62775 < 1){
            goto L2; // [19] 481
        }

        /** 		integer ref = refs[ar]*/
        _2 = (int)SEQ_PTR(_refs_62770);
        _ref_62777 = (int)*(((s1_ptr)_2)->base + _ar_62775);
        if (!IS_ATOM_INT(_ref_62777))
        _ref_62777 = (long)DBL_PTR(_ref_62777)->dbl;

        /** 		sequence fr = forward_references[ref]*/
        DeRef(_fr_62779);
        _2 = (int)SEQ_PTR(_29forward_references_61532);
        _fr_62779 = (int)*(((s1_ptr)_2)->base + _ref_62777);
        Ref(_fr_62779);

        /** 		if include_matrix[fr[FR_FILE]][current_file_no] = NOT_INCLUDED and not unincluded_ok then*/
        _2 = (int)SEQ_PTR(_fr_62779);
        _31385 = (int)*(((s1_ptr)_2)->base + 3);
        _2 = (int)SEQ_PTR(_27include_matrix_10928);
        if (!IS_ATOM_INT(_31385)){
            _31386 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_31385)->dbl));
        }
        else{
            _31386 = (int)*(((s1_ptr)_2)->base + _31385);
        }
        _2 = (int)SEQ_PTR(_31386);
        _31387 = (int)*(((s1_ptr)_2)->base + _26current_file_no_11982);
        _31386 = NOVALUE;
        if (IS_ATOM_INT(_31387)) {
            _31388 = (_31387 == 0);
        }
        else {
            _31388 = binary_op(EQUALS, _31387, 0);
        }
        _31387 = NOVALUE;
        if (IS_ATOM_INT(_31388)) {
            if (_31388 == 0) {
                goto L3; // [66] 84
            }
        }
        else {
            if (DBL_PTR(_31388)->dbl == 0.0) {
                goto L3; // [66] 84
            }
        }
        _31390 = (_unincluded_ok_62772 == 0);
        if (_31390 == 0)
        {
            DeRef(_31390);
            _31390 = NOVALUE;
            goto L3; // [74] 84
        }
        else{
            DeRef(_31390);
            _31390 = NOVALUE;
        }

        /** 			continue*/
        DeRef(_fr_62779);
        _fr_62779 = NOVALUE;
        DeRef(_tok_62792);
        _tok_62792 = NOVALUE;
        goto L4; // [81] 476
L3: 

        /** 		token tok = find_reference( fr )*/
        RefDS(_fr_62779);
        _0 = _tok_62792;
        _tok_62792 = _29find_reference(_fr_62779);
        DeRef(_0);

        /** 		if tok[T_ID] = IGNORED then*/
        _2 = (int)SEQ_PTR(_tok_62792);
        _31392 = (int)*(((s1_ptr)_2)->base + 1);
        if (binary_op_a(NOTEQ, _31392, 509)){
            _31392 = NOVALUE;
            goto L5; // [100] 117
        }
        _31392 = NOVALUE;

        /** 			errors &= ref*/
        Append(&_errors_62773, _errors_62773, _ref_62777);

        /** 			continue*/
        DeRefDS(_fr_62779);
        _fr_62779 = NOVALUE;
        DeRef(_tok_62792);
        _tok_62792 = NOVALUE;
        goto L4; // [114] 476
L5: 

        /** 		integer code_sub = fr[FR_SUBPROG]*/
        _2 = (int)SEQ_PTR(_fr_62779);
        _code_sub_62800 = (int)*(((s1_ptr)_2)->base + 4);
        if (!IS_ATOM_INT(_code_sub_62800))
        _code_sub_62800 = (long)DBL_PTR(_code_sub_62800)->dbl;

        /** 		integer fr_type  = fr[FR_TYPE]*/
        _2 = (int)SEQ_PTR(_fr_62779);
        _fr_type_62802 = (int)*(((s1_ptr)_2)->base + 1);
        if (!IS_ATOM_INT(_fr_type_62802))
        _fr_type_62802 = (long)DBL_PTR(_fr_type_62802)->dbl;

        /** 		integer sym_tok*/

        /** 		switch fr_type label "fr_type" do*/
        _0 = _fr_type_62802;
        switch ( _0 ){ 

            /** 			case PROC, FUNC then*/
            case 27:
            case 501:

            /** 				sym_tok = SymTab[tok[T_SYM]][S_TOKEN]*/
            _2 = (int)SEQ_PTR(_tok_62792);
            _31400 = (int)*(((s1_ptr)_2)->base + 2);
            _2 = (int)SEQ_PTR(_27SymTab_10921);
            if (!IS_ATOM_INT(_31400)){
                _31401 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_31400)->dbl));
            }
            else{
                _31401 = (int)*(((s1_ptr)_2)->base + _31400);
            }
            _2 = (int)SEQ_PTR(_31401);
            if (!IS_ATOM_INT(_26S_TOKEN_11659)){
                _sym_tok_62804 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_TOKEN_11659)->dbl));
            }
            else{
                _sym_tok_62804 = (int)*(((s1_ptr)_2)->base + _26S_TOKEN_11659);
            }
            if (!IS_ATOM_INT(_sym_tok_62804)){
                _sym_tok_62804 = (long)DBL_PTR(_sym_tok_62804)->dbl;
            }
            _31401 = NOVALUE;

            /** 				if sym_tok = TYPE then*/
            if (_sym_tok_62804 != 504)
            goto L6; // [170] 184

            /** 					sym_tok = FUNC*/
            _sym_tok_62804 = 501;
L6: 

            /** 				if sym_tok != fr_type then*/
            if (_sym_tok_62804 == _fr_type_62802)
            goto L7; // [186] 220

            /** 					if sym_tok != FUNC and fr_type != PROC then*/
            _31405 = (_sym_tok_62804 != 501);
            if (_31405 == 0) {
                goto L8; // [198] 219
            }
            _31407 = (_fr_type_62802 != 27);
            if (_31407 == 0)
            {
                DeRef(_31407);
                _31407 = NOVALUE;
                goto L8; // [209] 219
            }
            else{
                DeRef(_31407);
                _31407 = NOVALUE;
            }

            /** 						forward_error( tok, ref )*/
            Ref(_tok_62792);
            _29forward_error(_tok_62792, _ref_62777);
L8: 
L7: 

            /** 				switch sym_tok do*/
            _0 = _sym_tok_62804;
            switch ( _0 ){ 

                /** 					case PROC, FUNC then*/
                case 27:
                case 501:

                /** 						patch_forward_call( tok, ref )*/
                Ref(_tok_62792);
                _29patch_forward_call(_tok_62792, _ref_62777);

                /** 						break "fr_type"*/
                goto L9; // [241] 446
                goto L9; // [243] 446

                /** 					case else*/
                default:

                /** 						forward_error( tok, ref )*/
                Ref(_tok_62792);
                _29forward_error(_tok_62792, _ref_62777);
            ;}            goto L9; // [256] 446

            /** 			case VARIABLE then*/
            case -100:

            /** 				sym_tok = SymTab[tok[T_SYM]][S_TOKEN]*/
            _2 = (int)SEQ_PTR(_tok_62792);
            _31410 = (int)*(((s1_ptr)_2)->base + 2);
            _2 = (int)SEQ_PTR(_27SymTab_10921);
            if (!IS_ATOM_INT(_31410)){
                _31411 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_31410)->dbl));
            }
            else{
                _31411 = (int)*(((s1_ptr)_2)->base + _31410);
            }
            _2 = (int)SEQ_PTR(_31411);
            if (!IS_ATOM_INT(_26S_TOKEN_11659)){
                _sym_tok_62804 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_TOKEN_11659)->dbl));
            }
            else{
                _sym_tok_62804 = (int)*(((s1_ptr)_2)->base + _26S_TOKEN_11659);
            }
            if (!IS_ATOM_INT(_sym_tok_62804)){
                _sym_tok_62804 = (long)DBL_PTR(_sym_tok_62804)->dbl;
            }
            _31411 = NOVALUE;

            /** 				if SymTab[tok[T_SYM]][S_SCOPE] = SC_UNDEFINED then*/
            _2 = (int)SEQ_PTR(_tok_62792);
            _31413 = (int)*(((s1_ptr)_2)->base + 2);
            _2 = (int)SEQ_PTR(_27SymTab_10921);
            if (!IS_ATOM_INT(_31413)){
                _31414 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_31413)->dbl));
            }
            else{
                _31414 = (int)*(((s1_ptr)_2)->base + _31413);
            }
            _2 = (int)SEQ_PTR(_31414);
            _31415 = (int)*(((s1_ptr)_2)->base + 4);
            _31414 = NOVALUE;
            if (binary_op_a(NOTEQ, _31415, 9)){
                _31415 = NOVALUE;
                goto LA; // [306] 323
            }
            _31415 = NOVALUE;

            /** 					errors &= ref*/
            Append(&_errors_62773, _errors_62773, _ref_62777);

            /** 					continue*/
            DeRef(_fr_62779);
            _fr_62779 = NOVALUE;
            DeRef(_tok_62792);
            _tok_62792 = NOVALUE;
            goto L4; // [320] 476
LA: 

            /** 				switch sym_tok do*/
            _0 = _sym_tok_62804;
            switch ( _0 ){ 

                /** 					case CONSTANT, ENUM, VARIABLE then*/
                case 417:
                case 427:
                case -100:

                /** 						patch_forward_variable( tok, ref )*/
                Ref(_tok_62792);
                _29patch_forward_variable(_tok_62792, _ref_62777);

                /** 						break "fr_type"*/
                goto L9; // [346] 446
                goto L9; // [348] 446

                /** 					case else*/
                default:

                /** 						forward_error( tok, ref )*/
                Ref(_tok_62792);
                _29forward_error(_tok_62792, _ref_62777);
            ;}            goto L9; // [361] 446

            /** 			case TYPE_CHECK then*/
            case 65:

            /** 				patch_forward_type_check( tok, ref )*/
            Ref(_tok_62792);
            _29patch_forward_type_check(_tok_62792, _ref_62777);
            goto L9; // [373] 446

            /** 			case GLOBAL_INIT_CHECK then*/
            case 109:

            /** 				patch_forward_init_check( tok, ref )*/
            Ref(_tok_62792);
            _29patch_forward_init_check(_tok_62792, _ref_62777);
            goto L9; // [385] 446

            /** 			case CASE then*/
            case 186:

            /** 				patch_forward_case( tok, ref )*/
            Ref(_tok_62792);
            _29patch_forward_case(_tok_62792, _ref_62777);
            goto L9; // [397] 446

            /** 			case TYPE then*/
            case 504:

            /** 				patch_forward_type( tok, ref )*/
            Ref(_tok_62792);
            _29patch_forward_type(_tok_62792, _ref_62777);
            goto L9; // [409] 446

            /** 			case GOTO then*/
            case 188:

            /** 				patch_forward_goto( tok, ref )*/
            Ref(_tok_62792);
            _29patch_forward_goto(_tok_62792, _ref_62777);
            goto L9; // [421] 446

            /** 			case else*/
            default:

            /** 				InternalErr( 263, {fr[FR_TYPE], fr[FR_NAME]})*/
            _2 = (int)SEQ_PTR(_fr_62779);
            _31420 = (int)*(((s1_ptr)_2)->base + 1);
            _2 = (int)SEQ_PTR(_fr_62779);
            _31421 = (int)*(((s1_ptr)_2)->base + 2);
            Ref(_31421);
            Ref(_31420);
            _1 = NewS1(2);
            _2 = (int)((s1_ptr)_1)->base;
            ((int *)_2)[1] = _31420;
            ((int *)_2)[2] = _31421;
            _31422 = MAKE_SEQ(_1);
            _31421 = NOVALUE;
            _31420 = NOVALUE;
            _43InternalErr(263, _31422);
            _31422 = NOVALUE;
        ;}L9: 

        /** 		if report_errors and sequence( forward_references[ref] ) then*/
        if (_report_errors_62771 == 0) {
            goto LB; // [448] 472
        }
        _2 = (int)SEQ_PTR(_29forward_references_61532);
        _31424 = (int)*(((s1_ptr)_2)->base + _ref_62777);
        _31425 = IS_SEQUENCE(_31424);
        _31424 = NOVALUE;
        if (_31425 == 0)
        {
            _31425 = NOVALUE;
            goto LB; // [462] 472
        }
        else{
            _31425 = NOVALUE;
        }

        /** 			errors &= ref*/
        Append(&_errors_62773, _errors_62773, _ref_62777);
LB: 
        DeRef(_fr_62779);
        _fr_62779 = NOVALUE;
        DeRef(_tok_62792);
        _tok_62792 = NOVALUE;

        /** 	end for*/
L4: 
        _ar_62775 = _ar_62775 + -1;
        goto L1; // [476] 26
L2: 
        ;
    }

    /** 	return errors*/
    DeRefDS(_refs_62770);
    _31385 = NOVALUE;
    _31400 = NOVALUE;
    DeRef(_31388);
    _31388 = NOVALUE;
    DeRef(_31405);
    _31405 = NOVALUE;
    _31410 = NOVALUE;
    _31413 = NOVALUE;
    return _errors_62773;
    ;
}


int _29file_name_based_symindex_compare(int _si1_62882, int _si2_62883)
{
    int _fn1_62904 = NOVALUE;
    int _fn2_62909 = NOVALUE;
    int _31454 = NOVALUE;
    int _31453 = NOVALUE;
    int _31452 = NOVALUE;
    int _31451 = NOVALUE;
    int _31450 = NOVALUE;
    int _31449 = NOVALUE;
    int _31448 = NOVALUE;
    int _31447 = NOVALUE;
    int _31446 = NOVALUE;
    int _31445 = NOVALUE;
    int _31444 = NOVALUE;
    int _31443 = NOVALUE;
    int _31441 = NOVALUE;
    int _31439 = NOVALUE;
    int _31438 = NOVALUE;
    int _31437 = NOVALUE;
    int _31436 = NOVALUE;
    int _31435 = NOVALUE;
    int _31434 = NOVALUE;
    int _31433 = NOVALUE;
    int _31432 = NOVALUE;
    int _31431 = NOVALUE;
    int _31430 = NOVALUE;
    int _31428 = NOVALUE;
    int _31427 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_si1_62882)) {
        _1 = (long)(DBL_PTR(_si1_62882)->dbl);
        DeRefDS(_si1_62882);
        _si1_62882 = _1;
    }
    if (!IS_ATOM_INT(_si2_62883)) {
        _1 = (long)(DBL_PTR(_si2_62883)->dbl);
        DeRefDS(_si2_62883);
        _si2_62883 = _1;
    }

    /** 	if not symtab_index(si1) or not symtab_index(si2) then*/
    _31427 = _26symtab_index(_si1_62882);
    if (IS_ATOM_INT(_31427)) {
        _31428 = (_31427 == 0);
    }
    else {
        _31428 = unary_op(NOT, _31427);
    }
    DeRef(_31427);
    _31427 = NOVALUE;
    if (IS_ATOM_INT(_31428)) {
        if (_31428 != 0) {
            goto L1; // [14] 30
        }
    }
    else {
        if (DBL_PTR(_31428)->dbl != 0.0) {
            goto L1; // [14] 30
        }
    }
    _31430 = _26symtab_index(_si2_62883);
    if (IS_ATOM_INT(_31430)) {
        _31431 = (_31430 == 0);
    }
    else {
        _31431 = unary_op(NOT, _31430);
    }
    DeRef(_31430);
    _31430 = NOVALUE;
    if (_31431 == 0) {
        DeRef(_31431);
        _31431 = NOVALUE;
        goto L2; // [26] 37
    }
    else {
        if (!IS_ATOM_INT(_31431) && DBL_PTR(_31431)->dbl == 0.0){
            DeRef(_31431);
            _31431 = NOVALUE;
            goto L2; // [26] 37
        }
        DeRef(_31431);
        _31431 = NOVALUE;
    }
    DeRef(_31431);
    _31431 = NOVALUE;
L1: 

    /** 		return 1 -- put non symbols last*/
    DeRef(_31428);
    _31428 = NOVALUE;
    return 1;
L2: 

    /** 	if S_FILE_NO <= length(SymTab[si1]) and S_FILE_NO <= length(SymTab[si2]) then*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _31432 = (int)*(((s1_ptr)_2)->base + _si1_62882);
    if (IS_SEQUENCE(_31432)){
            _31433 = SEQ_PTR(_31432)->length;
    }
    else {
        _31433 = 1;
    }
    _31432 = NOVALUE;
    if (IS_ATOM_INT(_26S_FILE_NO_11650)) {
        _31434 = (_26S_FILE_NO_11650 <= _31433);
    }
    else {
        _31434 = binary_op(LESSEQ, _26S_FILE_NO_11650, _31433);
    }
    _31433 = NOVALUE;
    if (IS_ATOM_INT(_31434)) {
        if (_31434 == 0) {
            goto L3; // [54] 186
        }
    }
    else {
        if (DBL_PTR(_31434)->dbl == 0.0) {
            goto L3; // [54] 186
        }
    }
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _31436 = (int)*(((s1_ptr)_2)->base + _si2_62883);
    if (IS_SEQUENCE(_31436)){
            _31437 = SEQ_PTR(_31436)->length;
    }
    else {
        _31437 = 1;
    }
    _31436 = NOVALUE;
    if (IS_ATOM_INT(_26S_FILE_NO_11650)) {
        _31438 = (_26S_FILE_NO_11650 <= _31437);
    }
    else {
        _31438 = binary_op(LESSEQ, _26S_FILE_NO_11650, _31437);
    }
    _31437 = NOVALUE;
    if (_31438 == 0) {
        DeRef(_31438);
        _31438 = NOVALUE;
        goto L3; // [74] 186
    }
    else {
        if (!IS_ATOM_INT(_31438) && DBL_PTR(_31438)->dbl == 0.0){
            DeRef(_31438);
            _31438 = NOVALUE;
            goto L3; // [74] 186
        }
        DeRef(_31438);
        _31438 = NOVALUE;
    }
    DeRef(_31438);
    _31438 = NOVALUE;

    /** 		integer fn1 = SymTab[si1][S_FILE_NO], fn2 = SymTab[si2][S_FILE_NO]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _31439 = (int)*(((s1_ptr)_2)->base + _si1_62882);
    _2 = (int)SEQ_PTR(_31439);
    if (!IS_ATOM_INT(_26S_FILE_NO_11650)){
        _fn1_62904 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_FILE_NO_11650)->dbl));
    }
    else{
        _fn1_62904 = (int)*(((s1_ptr)_2)->base + _26S_FILE_NO_11650);
    }
    if (!IS_ATOM_INT(_fn1_62904)){
        _fn1_62904 = (long)DBL_PTR(_fn1_62904)->dbl;
    }
    _31439 = NOVALUE;
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _31441 = (int)*(((s1_ptr)_2)->base + _si2_62883);
    _2 = (int)SEQ_PTR(_31441);
    if (!IS_ATOM_INT(_26S_FILE_NO_11650)){
        _fn2_62909 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_FILE_NO_11650)->dbl));
    }
    else{
        _fn2_62909 = (int)*(((s1_ptr)_2)->base + _26S_FILE_NO_11650);
    }
    if (!IS_ATOM_INT(_fn2_62909)){
        _fn2_62909 = (long)DBL_PTR(_fn2_62909)->dbl;
    }
    _31441 = NOVALUE;

    /** 		if find(1,{fn1,fn2} > length(known_files) or {fn1,fn2} <= 0) then*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _fn1_62904;
    ((int *)_2)[2] = _fn2_62909;
    _31443 = MAKE_SEQ(_1);
    if (IS_SEQUENCE(_27known_files_10922)){
            _31444 = SEQ_PTR(_27known_files_10922)->length;
    }
    else {
        _31444 = 1;
    }
    _31445 = binary_op(GREATER, _31443, _31444);
    DeRefDS(_31443);
    _31443 = NOVALUE;
    _31444 = NOVALUE;
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _fn1_62904;
    ((int *)_2)[2] = _fn2_62909;
    _31446 = MAKE_SEQ(_1);
    _31447 = binary_op(LESSEQ, _31446, 0);
    DeRefDS(_31446);
    _31446 = NOVALUE;
    _31448 = binary_op(OR, _31445, _31447);
    DeRefDS(_31445);
    _31445 = NOVALUE;
    DeRefDS(_31447);
    _31447 = NOVALUE;
    _31449 = find_from(1, _31448, 1);
    DeRefDS(_31448);
    _31448 = NOVALUE;
    if (_31449 == 0)
    {
        _31449 = NOVALUE;
        goto L4; // [139] 149
    }
    else{
        _31449 = NOVALUE;
    }

    /** 			return 1*/
    DeRef(_31428);
    _31428 = NOVALUE;
    _31432 = NOVALUE;
    DeRef(_31434);
    _31434 = NOVALUE;
    _31436 = NOVALUE;
    return 1;
L4: 

    /** 		return compare(abbreviate_path(known_files[fn1]),*/
    _2 = (int)SEQ_PTR(_27known_files_10922);
    _31450 = (int)*(((s1_ptr)_2)->base + _fn1_62904);
    Ref(_31450);
    RefDS(_22037);
    _31451 = _15abbreviate_path(_31450, _22037);
    _31450 = NOVALUE;
    _2 = (int)SEQ_PTR(_27known_files_10922);
    _31452 = (int)*(((s1_ptr)_2)->base + _fn2_62909);
    Ref(_31452);
    RefDS(_22037);
    _31453 = _15abbreviate_path(_31452, _22037);
    _31452 = NOVALUE;
    if (IS_ATOM_INT(_31451) && IS_ATOM_INT(_31453)){
        _31454 = (_31451 < _31453) ? -1 : (_31451 > _31453);
    }
    else{
        _31454 = compare(_31451, _31453);
    }
    DeRef(_31451);
    _31451 = NOVALUE;
    DeRef(_31453);
    _31453 = NOVALUE;
    DeRef(_31428);
    _31428 = NOVALUE;
    _31432 = NOVALUE;
    DeRef(_31434);
    _31434 = NOVALUE;
    _31436 = NOVALUE;
    return _31454;
    goto L5; // [183] 193
L3: 

    /** 		return 1 -- put non-names last*/
    DeRef(_31428);
    _31428 = NOVALUE;
    _31432 = NOVALUE;
    DeRef(_31434);
    _31434 = NOVALUE;
    _31436 = NOVALUE;
    return 1;
L5: 
    ;
}


void _29Resolve_forward_references(int _report_errors_62935)
{
    int _errors_62936 = NOVALUE;
    int _unincluded_ok_62937 = NOVALUE;
    int _msg_62998 = NOVALUE;
    int _errloc_62999 = NOVALUE;
    int _ref_63004 = NOVALUE;
    int _tok_63020 = NOVALUE;
    int _THIS_SCOPE_63022 = NOVALUE;
    int _THESE_GLOBALS_63023 = NOVALUE;
    int _syms_63081 = NOVALUE;
    int _s_63102 = NOVALUE;
    int _31585 = NOVALUE;
    int _31583 = NOVALUE;
    int _31578 = NOVALUE;
    int _31575 = NOVALUE;
    int _31573 = NOVALUE;
    int _31572 = NOVALUE;
    int _31571 = NOVALUE;
    int _31570 = NOVALUE;
    int _31569 = NOVALUE;
    int _31568 = NOVALUE;
    int _31567 = NOVALUE;
    int _31565 = NOVALUE;
    int _31564 = NOVALUE;
    int _31563 = NOVALUE;
    int _31561 = NOVALUE;
    int _31559 = NOVALUE;
    int _31558 = NOVALUE;
    int _31557 = NOVALUE;
    int _31556 = NOVALUE;
    int _31555 = NOVALUE;
    int _31554 = NOVALUE;
    int _31551 = NOVALUE;
    int _31547 = NOVALUE;
    int _31546 = NOVALUE;
    int _31545 = NOVALUE;
    int _31544 = NOVALUE;
    int _31543 = NOVALUE;
    int _31542 = NOVALUE;
    int _31539 = NOVALUE;
    int _31538 = NOVALUE;
    int _31537 = NOVALUE;
    int _31536 = NOVALUE;
    int _31535 = NOVALUE;
    int _31534 = NOVALUE;
    int _31531 = NOVALUE;
    int _31530 = NOVALUE;
    int _31529 = NOVALUE;
    int _31528 = NOVALUE;
    int _31527 = NOVALUE;
    int _31526 = NOVALUE;
    int _31525 = NOVALUE;
    int _31524 = NOVALUE;
    int _31523 = NOVALUE;
    int _31522 = NOVALUE;
    int _31519 = NOVALUE;
    int _31517 = NOVALUE;
    int _31514 = NOVALUE;
    int _31512 = NOVALUE;
    int _31510 = NOVALUE;
    int _31509 = NOVALUE;
    int _31507 = NOVALUE;
    int _31506 = NOVALUE;
    int _31505 = NOVALUE;
    int _31504 = NOVALUE;
    int _31503 = NOVALUE;
    int _31501 = NOVALUE;
    int _31500 = NOVALUE;
    int _31498 = NOVALUE;
    int _31497 = NOVALUE;
    int _31495 = NOVALUE;
    int _31494 = NOVALUE;
    int _31492 = NOVALUE;
    int _31491 = NOVALUE;
    int _31490 = NOVALUE;
    int _31489 = NOVALUE;
    int _31488 = NOVALUE;
    int _31487 = NOVALUE;
    int _31486 = NOVALUE;
    int _31485 = NOVALUE;
    int _31484 = NOVALUE;
    int _31483 = NOVALUE;
    int _31482 = NOVALUE;
    int _31481 = NOVALUE;
    int _31480 = NOVALUE;
    int _31479 = NOVALUE;
    int _31478 = NOVALUE;
    int _31477 = NOVALUE;
    int _31475 = NOVALUE;
    int _31474 = NOVALUE;
    int _31473 = NOVALUE;
    int _31472 = NOVALUE;
    int _31470 = NOVALUE;
    int _31469 = NOVALUE;
    int _31467 = NOVALUE;
    int _31466 = NOVALUE;
    int _31465 = NOVALUE;
    int _31464 = NOVALUE;
    int _31462 = NOVALUE;
    int _31461 = NOVALUE;
    int _31460 = NOVALUE;
    int _31459 = NOVALUE;
    int _31457 = NOVALUE;
    int _31456 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_report_errors_62935)) {
        _1 = (long)(DBL_PTR(_report_errors_62935)->dbl);
        DeRefDS(_report_errors_62935);
        _report_errors_62935 = _1;
    }

    /** 	sequence errors = {}*/
    RefDS(_22037);
    DeRef(_errors_62936);
    _errors_62936 = _22037;

    /** 	integer unincluded_ok = get_resolve_unincluded_globals()*/
    _unincluded_ok_62937 = _52get_resolve_unincluded_globals();
    if (!IS_ATOM_INT(_unincluded_ok_62937)) {
        _1 = (long)(DBL_PTR(_unincluded_ok_62937)->dbl);
        DeRefDS(_unincluded_ok_62937);
        _unincluded_ok_62937 = _1;
    }

    /** 	if length( active_references ) < length( known_files ) then*/
    if (IS_SEQUENCE(_29active_references_61534)){
            _31456 = SEQ_PTR(_29active_references_61534)->length;
    }
    else {
        _31456 = 1;
    }
    if (IS_SEQUENCE(_27known_files_10922)){
            _31457 = SEQ_PTR(_27known_files_10922)->length;
    }
    else {
        _31457 = 1;
    }
    if (_31456 >= _31457)
    goto L1; // [29] 86

    /** 		active_references &= repeat( {}, length( known_files ) - length( active_references ) )*/
    if (IS_SEQUENCE(_27known_files_10922)){
            _31459 = SEQ_PTR(_27known_files_10922)->length;
    }
    else {
        _31459 = 1;
    }
    if (IS_SEQUENCE(_29active_references_61534)){
            _31460 = SEQ_PTR(_29active_references_61534)->length;
    }
    else {
        _31460 = 1;
    }
    _31461 = _31459 - _31460;
    _31459 = NOVALUE;
    _31460 = NOVALUE;
    _31462 = Repeat(_22037, _31461);
    _31461 = NOVALUE;
    Concat((object_ptr)&_29active_references_61534, _29active_references_61534, _31462);
    DeRefDS(_31462);
    _31462 = NOVALUE;

    /** 		active_subprogs   &= repeat( {}, length( known_files ) - length( active_subprogs ) )*/
    if (IS_SEQUENCE(_27known_files_10922)){
            _31464 = SEQ_PTR(_27known_files_10922)->length;
    }
    else {
        _31464 = 1;
    }
    if (IS_SEQUENCE(_29active_subprogs_61533)){
            _31465 = SEQ_PTR(_29active_subprogs_61533)->length;
    }
    else {
        _31465 = 1;
    }
    _31466 = _31464 - _31465;
    _31464 = NOVALUE;
    _31465 = NOVALUE;
    _31467 = Repeat(_22037, _31466);
    _31466 = NOVALUE;
    Concat((object_ptr)&_29active_subprogs_61533, _29active_subprogs_61533, _31467);
    DeRefDS(_31467);
    _31467 = NOVALUE;
L1: 

    /** 	if length( toplevel_references ) < length( known_files ) then*/
    if (IS_SEQUENCE(_29toplevel_references_61535)){
            _31469 = SEQ_PTR(_29toplevel_references_61535)->length;
    }
    else {
        _31469 = 1;
    }
    if (IS_SEQUENCE(_27known_files_10922)){
            _31470 = SEQ_PTR(_27known_files_10922)->length;
    }
    else {
        _31470 = 1;
    }
    if (_31469 >= _31470)
    goto L2; // [98] 129

    /** 		toplevel_references &= repeat( {}, length( known_files ) - length( toplevel_references ) )*/
    if (IS_SEQUENCE(_27known_files_10922)){
            _31472 = SEQ_PTR(_27known_files_10922)->length;
    }
    else {
        _31472 = 1;
    }
    if (IS_SEQUENCE(_29toplevel_references_61535)){
            _31473 = SEQ_PTR(_29toplevel_references_61535)->length;
    }
    else {
        _31473 = 1;
    }
    _31474 = _31472 - _31473;
    _31472 = NOVALUE;
    _31473 = NOVALUE;
    _31475 = Repeat(_22037, _31474);
    _31474 = NOVALUE;
    Concat((object_ptr)&_29toplevel_references_61535, _29toplevel_references_61535, _31475);
    DeRefDS(_31475);
    _31475 = NOVALUE;
L2: 

    /** 	for i = 1 to length( active_subprogs ) do*/
    if (IS_SEQUENCE(_29active_subprogs_61533)){
            _31477 = SEQ_PTR(_29active_subprogs_61533)->length;
    }
    else {
        _31477 = 1;
    }
    {
        int _i_62969;
        _i_62969 = 1;
L3: 
        if (_i_62969 > _31477){
            goto L4; // [136] 280
        }

        /** 		if (length( active_subprogs[i] ) or length(toplevel_references[i])) */
        _2 = (int)SEQ_PTR(_29active_subprogs_61533);
        _31478 = (int)*(((s1_ptr)_2)->base + _i_62969);
        if (IS_SEQUENCE(_31478)){
                _31479 = SEQ_PTR(_31478)->length;
        }
        else {
            _31479 = 1;
        }
        _31478 = NOVALUE;
        if (_31479 != 0) {
            _31480 = 1;
            goto L5; // [154] 171
        }
        _2 = (int)SEQ_PTR(_29toplevel_references_61535);
        _31481 = (int)*(((s1_ptr)_2)->base + _i_62969);
        if (IS_SEQUENCE(_31481)){
                _31482 = SEQ_PTR(_31481)->length;
        }
        else {
            _31482 = 1;
        }
        _31481 = NOVALUE;
        _31480 = (_31482 != 0);
L5: 
        if (_31480 == 0) {
            goto L6; // [171] 273
        }
        _31484 = (_i_62969 == _26current_file_no_11982);
        if (_31484 != 0) {
            _31485 = 1;
            goto L7; // [181] 195
        }
        _2 = (int)SEQ_PTR(_27finished_files_10924);
        _31486 = (int)*(((s1_ptr)_2)->base + _i_62969);
        _31485 = (_31486 != 0);
L7: 
        if (_31485 != 0) {
            DeRef(_31487);
            _31487 = 1;
            goto L8; // [195] 203
        }
        _31487 = (_unincluded_ok_62937 != 0);
L8: 
        if (_31487 == 0)
        {
            _31487 = NOVALUE;
            goto L6; // [204] 273
        }
        else{
            _31487 = NOVALUE;
        }

        /** 			for j = length( active_references[i] ) to 1 by -1 do*/
        _2 = (int)SEQ_PTR(_29active_references_61534);
        _31488 = (int)*(((s1_ptr)_2)->base + _i_62969);
        if (IS_SEQUENCE(_31488)){
                _31489 = SEQ_PTR(_31488)->length;
        }
        else {
            _31489 = 1;
        }
        _31488 = NOVALUE;
        {
            int _j_62985;
            _j_62985 = _31489;
L9: 
            if (_j_62985 < 1){
                goto LA; // [218] 254
            }

            /** 				errors &= resolve_file( active_references[i][j], report_errors, unincluded_ok )*/
            _2 = (int)SEQ_PTR(_29active_references_61534);
            _31490 = (int)*(((s1_ptr)_2)->base + _i_62969);
            _2 = (int)SEQ_PTR(_31490);
            _31491 = (int)*(((s1_ptr)_2)->base + _j_62985);
            _31490 = NOVALUE;
            Ref(_31491);
            _31492 = _29resolve_file(_31491, _report_errors_62935, _unincluded_ok_62937);
            _31491 = NOVALUE;
            if (IS_SEQUENCE(_errors_62936) && IS_ATOM(_31492)) {
                Ref(_31492);
                Append(&_errors_62936, _errors_62936, _31492);
            }
            else if (IS_ATOM(_errors_62936) && IS_SEQUENCE(_31492)) {
            }
            else {
                Concat((object_ptr)&_errors_62936, _errors_62936, _31492);
            }
            DeRef(_31492);
            _31492 = NOVALUE;

            /** 			end for*/
            _j_62985 = _j_62985 + -1;
            goto L9; // [249] 225
LA: 
            ;
        }

        /** 			errors &= resolve_file( toplevel_references[i], report_errors, unincluded_ok )*/
        _2 = (int)SEQ_PTR(_29toplevel_references_61535);
        _31494 = (int)*(((s1_ptr)_2)->base + _i_62969);
        Ref(_31494);
        _31495 = _29resolve_file(_31494, _report_errors_62935, _unincluded_ok_62937);
        _31494 = NOVALUE;
        if (IS_SEQUENCE(_errors_62936) && IS_ATOM(_31495)) {
            Ref(_31495);
            Append(&_errors_62936, _errors_62936, _31495);
        }
        else if (IS_ATOM(_errors_62936) && IS_SEQUENCE(_31495)) {
        }
        else {
            Concat((object_ptr)&_errors_62936, _errors_62936, _31495);
        }
        DeRef(_31495);
        _31495 = NOVALUE;
L6: 

        /** 	end for*/
        _i_62969 = _i_62969 + 1;
        goto L3; // [275] 143
L4: 
        ;
    }

    /** 	if report_errors and length( errors ) then*/
    if (_report_errors_62935 == 0) {
        goto LB; // [282] 854
    }
    if (IS_SEQUENCE(_errors_62936)){
            _31498 = SEQ_PTR(_errors_62936)->length;
    }
    else {
        _31498 = 1;
    }
    if (_31498 == 0)
    {
        _31498 = NOVALUE;
        goto LB; // [290] 854
    }
    else{
        _31498 = NOVALUE;
    }

    /** 		sequence msg = ""*/
    RefDS(_22037);
    DeRefi(_msg_62998);
    _msg_62998 = _22037;

    /** 		sequence errloc = "Internal Error - Unknown Error Message"*/
    RefDS(_31499);
    DeRefi(_errloc_62999);
    _errloc_62999 = _31499;

    /** 		for e = length(errors) to 1 by -1 do*/
    if (IS_SEQUENCE(_errors_62936)){
            _31500 = SEQ_PTR(_errors_62936)->length;
    }
    else {
        _31500 = 1;
    }
    {
        int _e_63002;
        _e_63002 = _31500;
LC: 
        if (_e_63002 < 1){
            goto LD; // [312] 828
        }

        /** 			sequence ref = forward_references[errors[e]]*/
        _2 = (int)SEQ_PTR(_errors_62936);
        _31501 = (int)*(((s1_ptr)_2)->base + _e_63002);
        DeRef(_ref_63004);
        _2 = (int)SEQ_PTR(_29forward_references_61532);
        if (!IS_ATOM_INT(_31501)){
            _ref_63004 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_31501)->dbl));
        }
        else{
            _ref_63004 = (int)*(((s1_ptr)_2)->base + _31501);
        }
        Ref(_ref_63004);

        /** 			if (ref[FR_TYPE] = TYPE_CHECK and ref[FR_OP] = TYPE_CHECK) or ref[FR_TYPE] = GLOBAL_INIT_CHECK then*/
        _2 = (int)SEQ_PTR(_ref_63004);
        _31503 = (int)*(((s1_ptr)_2)->base + 1);
        if (IS_ATOM_INT(_31503)) {
            _31504 = (_31503 == 65);
        }
        else {
            _31504 = binary_op(EQUALS, _31503, 65);
        }
        _31503 = NOVALUE;
        if (IS_ATOM_INT(_31504)) {
            if (_31504 == 0) {
                DeRef(_31505);
                _31505 = 0;
                goto LE; // [345] 363
            }
        }
        else {
            if (DBL_PTR(_31504)->dbl == 0.0) {
                DeRef(_31505);
                _31505 = 0;
                goto LE; // [345] 363
            }
        }
        _2 = (int)SEQ_PTR(_ref_63004);
        _31506 = (int)*(((s1_ptr)_2)->base + 10);
        if (IS_ATOM_INT(_31506)) {
            _31507 = (_31506 == 65);
        }
        else {
            _31507 = binary_op(EQUALS, _31506, 65);
        }
        _31506 = NOVALUE;
        DeRef(_31505);
        if (IS_ATOM_INT(_31507))
        _31505 = (_31507 != 0);
        else
        _31505 = DBL_PTR(_31507)->dbl != 0.0;
LE: 
        if (_31505 != 0) {
            goto LF; // [363] 382
        }
        _2 = (int)SEQ_PTR(_ref_63004);
        _31509 = (int)*(((s1_ptr)_2)->base + 1);
        if (IS_ATOM_INT(_31509)) {
            _31510 = (_31509 == 109);
        }
        else {
            _31510 = binary_op(EQUALS, _31509, 109);
        }
        _31509 = NOVALUE;
        if (_31510 == 0) {
            DeRef(_31510);
            _31510 = NOVALUE;
            goto L10; // [378] 391
        }
        else {
            if (!IS_ATOM_INT(_31510) && DBL_PTR(_31510)->dbl == 0.0){
                DeRef(_31510);
                _31510 = NOVALUE;
                goto L10; // [378] 391
            }
            DeRef(_31510);
            _31510 = NOVALUE;
        }
        DeRef(_31510);
        _31510 = NOVALUE;
LF: 

        /** 				continue*/
        DeRef(_ref_63004);
        _ref_63004 = NOVALUE;
        goto L11; // [386] 823
        goto L12; // [388] 789
L10: 

        /** 				object tok = find_reference(ref)*/
        RefDS(_ref_63004);
        _0 = _tok_63020;
        _tok_63020 = _29find_reference(_ref_63004);
        DeRef(_0);

        /** 				integer THIS_SCOPE = 3*/
        _THIS_SCOPE_63022 = 3;

        /** 				integer THESE_GLOBALS = 4*/
        _THESE_GLOBALS_63023 = 4;

        /** 				if tok[T_ID] = IGNORED then*/
        _2 = (int)SEQ_PTR(_tok_63020);
        _31512 = (int)*(((s1_ptr)_2)->base + 1);
        if (binary_op_a(NOTEQ, _31512, 509)){
            _31512 = NOVALUE;
            goto L13; // [417] 760
        }
        _31512 = NOVALUE;

        /** 					switch tok[THIS_SCOPE] do*/
        _2 = (int)SEQ_PTR(_tok_63020);
        _31514 = (int)*(((s1_ptr)_2)->base + 3);
        if (IS_SEQUENCE(_31514) ){
            goto L14; // [427] 756
        }
        if(!IS_ATOM_INT(_31514)){
            if( (DBL_PTR(_31514)->dbl != (double) ((int) DBL_PTR(_31514)->dbl) ) ){
                goto L14; // [427] 756
            }
            _0 = (int) DBL_PTR(_31514)->dbl;
        }
        else {
            _0 = _31514;
        };
        _31514 = NOVALUE;
        switch ( _0 ){ 

            /** 						case SC_UNDEFINED then*/
            case 9:

            /** 							if ref[FR_QUALIFIED] != -1 then*/
            _2 = (int)SEQ_PTR(_ref_63004);
            _31517 = (int)*(((s1_ptr)_2)->base + 9);
            if (binary_op_a(EQUALS, _31517, -1)){
                _31517 = NOVALUE;
                goto L15; // [442] 556
            }
            _31517 = NOVALUE;

            /** 								if ref[FR_QUALIFIED] > 0 then*/
            _2 = (int)SEQ_PTR(_ref_63004);
            _31519 = (int)*(((s1_ptr)_2)->base + 9);
            if (binary_op_a(LESSEQ, _31519, 0)){
                _31519 = NOVALUE;
                goto L16; // [452] 517
            }
            _31519 = NOVALUE;

            /** 									errloc = sprintf("\t\'%s\' (%s:%d) was not declared in \'%s\'.\n", */
            _2 = (int)SEQ_PTR(_ref_63004);
            _31522 = (int)*(((s1_ptr)_2)->base + 2);
            _2 = (int)SEQ_PTR(_ref_63004);
            _31523 = (int)*(((s1_ptr)_2)->base + 3);
            _2 = (int)SEQ_PTR(_27known_files_10922);
            if (!IS_ATOM_INT(_31523)){
                _31524 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_31523)->dbl));
            }
            else{
                _31524 = (int)*(((s1_ptr)_2)->base + _31523);
            }
            Ref(_31524);
            RefDS(_22037);
            _31525 = _15abbreviate_path(_31524, _22037);
            _31524 = NOVALUE;
            _2 = (int)SEQ_PTR(_ref_63004);
            _31526 = (int)*(((s1_ptr)_2)->base + 6);
            _2 = (int)SEQ_PTR(_ref_63004);
            _31527 = (int)*(((s1_ptr)_2)->base + 9);
            _2 = (int)SEQ_PTR(_27known_files_10922);
            if (!IS_ATOM_INT(_31527)){
                _31528 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_31527)->dbl));
            }
            else{
                _31528 = (int)*(((s1_ptr)_2)->base + _31527);
            }
            Ref(_31528);
            RefDS(_22037);
            _31529 = _15abbreviate_path(_31528, _22037);
            _31528 = NOVALUE;
            _31530 = _14find_replace(92, _31529, 47, 0);
            _31529 = NOVALUE;
            _1 = NewS1(4);
            _2 = (int)((s1_ptr)_1)->base;
            Ref(_31522);
            *((int *)(_2+4)) = _31522;
            *((int *)(_2+8)) = _31525;
            Ref(_31526);
            *((int *)(_2+12)) = _31526;
            *((int *)(_2+16)) = _31530;
            _31531 = MAKE_SEQ(_1);
            _31530 = NOVALUE;
            _31526 = NOVALUE;
            _31525 = NOVALUE;
            _31522 = NOVALUE;
            DeRefi(_errloc_62999);
            _errloc_62999 = EPrintf(-9999999, _31521, _31531);
            DeRefDS(_31531);
            _31531 = NOVALUE;
            goto L17; // [514] 759
L16: 

            /** 									errloc = sprintf("\t\'%s\' (%s:%d) is not a builtin.\n", */
            _2 = (int)SEQ_PTR(_ref_63004);
            _31534 = (int)*(((s1_ptr)_2)->base + 2);
            _2 = (int)SEQ_PTR(_ref_63004);
            _31535 = (int)*(((s1_ptr)_2)->base + 3);
            _2 = (int)SEQ_PTR(_27known_files_10922);
            if (!IS_ATOM_INT(_31535)){
                _31536 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_31535)->dbl));
            }
            else{
                _31536 = (int)*(((s1_ptr)_2)->base + _31535);
            }
            Ref(_31536);
            RefDS(_22037);
            _31537 = _15abbreviate_path(_31536, _22037);
            _31536 = NOVALUE;
            _2 = (int)SEQ_PTR(_ref_63004);
            _31538 = (int)*(((s1_ptr)_2)->base + 6);
            _1 = NewS1(3);
            _2 = (int)((s1_ptr)_1)->base;
            Ref(_31534);
            *((int *)(_2+4)) = _31534;
            *((int *)(_2+8)) = _31537;
            Ref(_31538);
            *((int *)(_2+12)) = _31538;
            _31539 = MAKE_SEQ(_1);
            _31538 = NOVALUE;
            _31537 = NOVALUE;
            _31534 = NOVALUE;
            DeRefi(_errloc_62999);
            _errloc_62999 = EPrintf(-9999999, _31533, _31539);
            DeRefDS(_31539);
            _31539 = NOVALUE;
            goto L17; // [553] 759
L15: 

            /** 								errloc = sprintf("\t\'%s\' (%s:%d) has not been declared.\n", */
            _2 = (int)SEQ_PTR(_ref_63004);
            _31542 = (int)*(((s1_ptr)_2)->base + 2);
            _2 = (int)SEQ_PTR(_ref_63004);
            _31543 = (int)*(((s1_ptr)_2)->base + 3);
            _2 = (int)SEQ_PTR(_27known_files_10922);
            if (!IS_ATOM_INT(_31543)){
                _31544 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_31543)->dbl));
            }
            else{
                _31544 = (int)*(((s1_ptr)_2)->base + _31543);
            }
            Ref(_31544);
            RefDS(_22037);
            _31545 = _15abbreviate_path(_31544, _22037);
            _31544 = NOVALUE;
            _2 = (int)SEQ_PTR(_ref_63004);
            _31546 = (int)*(((s1_ptr)_2)->base + 6);
            _1 = NewS1(3);
            _2 = (int)((s1_ptr)_1)->base;
            Ref(_31542);
            *((int *)(_2+4)) = _31542;
            *((int *)(_2+8)) = _31545;
            Ref(_31546);
            *((int *)(_2+12)) = _31546;
            _31547 = MAKE_SEQ(_1);
            _31546 = NOVALUE;
            _31545 = NOVALUE;
            _31542 = NOVALUE;
            DeRefi(_errloc_62999);
            _errloc_62999 = EPrintf(-9999999, _31541, _31547);
            DeRefDS(_31547);
            _31547 = NOVALUE;
            goto L17; // [592] 759

            /** 						case SC_MULTIPLY_DEFINED then*/
            case 10:

            /** 							sequence syms = tok[THESE_GLOBALS] -- there should be no forward references in here.*/
            DeRef(_syms_63081);
            _2 = (int)SEQ_PTR(_tok_63020);
            _syms_63081 = (int)*(((s1_ptr)_2)->base + _THESE_GLOBALS_63023);
            Ref(_syms_63081);

            /** 							syms = custom_sort(routine_id("file_name_based_symindex_compare"), syms,, ASCENDING)*/
            _31551 = CRoutineId(1339, 29, _31550);
            RefDS(_syms_63081);
            RefDS(_22037);
            _0 = _syms_63081;
            _syms_63081 = _24custom_sort(_31551, _syms_63081, _22037, 1);
            DeRefDS(_0);
            _31551 = NOVALUE;

            /** 							errloc = sprintf("\t\'%s\' (%s:%d) has been declared more than once.\n", */
            _2 = (int)SEQ_PTR(_ref_63004);
            _31554 = (int)*(((s1_ptr)_2)->base + 2);
            _2 = (int)SEQ_PTR(_ref_63004);
            _31555 = (int)*(((s1_ptr)_2)->base + 3);
            _2 = (int)SEQ_PTR(_27known_files_10922);
            if (!IS_ATOM_INT(_31555)){
                _31556 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_31555)->dbl));
            }
            else{
                _31556 = (int)*(((s1_ptr)_2)->base + _31555);
            }
            Ref(_31556);
            RefDS(_22037);
            _31557 = _15abbreviate_path(_31556, _22037);
            _31556 = NOVALUE;
            _2 = (int)SEQ_PTR(_ref_63004);
            _31558 = (int)*(((s1_ptr)_2)->base + 6);
            _1 = NewS1(3);
            _2 = (int)((s1_ptr)_1)->base;
            Ref(_31554);
            *((int *)(_2+4)) = _31554;
            *((int *)(_2+8)) = _31557;
            Ref(_31558);
            *((int *)(_2+12)) = _31558;
            _31559 = MAKE_SEQ(_1);
            _31558 = NOVALUE;
            _31557 = NOVALUE;
            _31554 = NOVALUE;
            DeRefi(_errloc_62999);
            _errloc_62999 = EPrintf(-9999999, _31553, _31559);
            DeRefDS(_31559);
            _31559 = NOVALUE;

            /** 							for si = 1 to length(syms) do*/
            if (IS_SEQUENCE(_syms_63081)){
                    _31561 = SEQ_PTR(_syms_63081)->length;
            }
            else {
                _31561 = 1;
            }
            {
                int _si_63099;
                _si_63099 = 1;
L18: 
                if (_si_63099 > _31561){
                    goto L19; // [664] 750
                }

                /** 								symtab_index s = syms[si] */
                _2 = (int)SEQ_PTR(_syms_63081);
                _s_63102 = (int)*(((s1_ptr)_2)->base + _si_63099);
                if (!IS_ATOM_INT(_s_63102)){
                    _s_63102 = (long)DBL_PTR(_s_63102)->dbl;
                }

                /** 								if equal(ref[FR_NAME], sym_name(s)) then*/
                _2 = (int)SEQ_PTR(_ref_63004);
                _31563 = (int)*(((s1_ptr)_2)->base + 2);
                _31564 = _52sym_name(_s_63102);
                if (_31563 == _31564)
                _31565 = 1;
                else if (IS_ATOM_INT(_31563) && IS_ATOM_INT(_31564))
                _31565 = 0;
                else
                _31565 = (compare(_31563, _31564) == 0);
                _31563 = NOVALUE;
                DeRef(_31564);
                _31564 = NOVALUE;
                if (_31565 == 0)
                {
                    _31565 = NOVALUE;
                    goto L1A; // [693] 741
                }
                else{
                    _31565 = NOVALUE;
                }

                /** 									errloc &= sprintf("\t\tin %s\n", */
                _2 = (int)SEQ_PTR(_27SymTab_10921);
                _31567 = (int)*(((s1_ptr)_2)->base + _s_63102);
                _2 = (int)SEQ_PTR(_31567);
                if (!IS_ATOM_INT(_26S_FILE_NO_11650)){
                    _31568 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_FILE_NO_11650)->dbl));
                }
                else{
                    _31568 = (int)*(((s1_ptr)_2)->base + _26S_FILE_NO_11650);
                }
                _31567 = NOVALUE;
                _2 = (int)SEQ_PTR(_27known_files_10922);
                if (!IS_ATOM_INT(_31568)){
                    _31569 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_31568)->dbl));
                }
                else{
                    _31569 = (int)*(((s1_ptr)_2)->base + _31568);
                }
                Ref(_31569);
                RefDS(_22037);
                _31570 = _15abbreviate_path(_31569, _22037);
                _31569 = NOVALUE;
                _31571 = _14find_replace(92, _31570, 47, 0);
                _31570 = NOVALUE;
                _1 = NewS1(1);
                _2 = (int)((s1_ptr)_1)->base;
                *((int *)(_2+4)) = _31571;
                _31572 = MAKE_SEQ(_1);
                _31571 = NOVALUE;
                _31573 = EPrintf(-9999999, _31566, _31572);
                DeRefDS(_31572);
                _31572 = NOVALUE;
                Concat((object_ptr)&_errloc_62999, _errloc_62999, _31573);
                DeRefDS(_31573);
                _31573 = NOVALUE;
L1A: 

                /** 							end for*/
                _si_63099 = _si_63099 + 1;
                goto L18; // [745] 671
L19: 
                ;
            }
            DeRef(_syms_63081);
            _syms_63081 = NOVALUE;
            goto L17; // [752] 759

            /** 						case else */
            default:
L14: 
        ;}L17: 
L13: 

        /** 				if not match(errloc, msg) then*/
        _31575 = e_match_from(_errloc_62999, _msg_62998, 1);
        if (_31575 != 0)
        goto L1B; // [767] 786
        _31575 = NOVALUE;

        /** 					msg &= errloc*/
        Concat((object_ptr)&_msg_62998, _msg_62998, _errloc_62999);

        /** 					prep_forward_error( errors[e] )*/
        _2 = (int)SEQ_PTR(_errors_62936);
        _31578 = (int)*(((s1_ptr)_2)->base + _e_63002);
        Ref(_31578);
        _29prep_forward_error(_31578);
        _31578 = NOVALUE;
L1B: 
        DeRef(_tok_63020);
        _tok_63020 = NOVALUE;
L12: 

        /** 			ThisLine    = ref[FR_THISLINE]*/
        DeRef(_43ThisLine_48557);
        _2 = (int)SEQ_PTR(_ref_63004);
        _43ThisLine_48557 = (int)*(((s1_ptr)_2)->base + 7);
        Ref(_43ThisLine_48557);

        /** 			bp          = ref[FR_BP]*/
        _2 = (int)SEQ_PTR(_ref_63004);
        _43bp_48561 = (int)*(((s1_ptr)_2)->base + 8);
        if (!IS_ATOM_INT(_43bp_48561)){
            _43bp_48561 = (long)DBL_PTR(_43bp_48561)->dbl;
        }

        /** 			CurrentSub  = ref[FR_SUBPROG]*/
        _2 = (int)SEQ_PTR(_ref_63004);
        _26CurrentSub_11990 = (int)*(((s1_ptr)_2)->base + 4);
        if (!IS_ATOM_INT(_26CurrentSub_11990)){
            _26CurrentSub_11990 = (long)DBL_PTR(_26CurrentSub_11990)->dbl;
        }

        /** 			line_number = ref[FR_LINE]*/
        _2 = (int)SEQ_PTR(_ref_63004);
        _26line_number_11983 = (int)*(((s1_ptr)_2)->base + 6);
        if (!IS_ATOM_INT(_26line_number_11983)){
            _26line_number_11983 = (long)DBL_PTR(_26line_number_11983)->dbl;
        }
        DeRefDS(_ref_63004);
        _ref_63004 = NOVALUE;

        /** 		end for*/
L11: 
        _e_63002 = _e_63002 + -1;
        goto LC; // [823] 319
LD: 
        ;
    }

    /** 		if length(msg) > 0 then*/
    if (IS_SEQUENCE(_msg_62998)){
            _31583 = SEQ_PTR(_msg_62998)->length;
    }
    else {
        _31583 = 1;
    }
    if (_31583 <= 0)
    goto L1C; // [833] 849

    /** 			CompileErr( 74, {msg} )*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_msg_62998);
    *((int *)(_2+4)) = _msg_62998;
    _31585 = MAKE_SEQ(_1);
    _43CompileErr(74, _31585, 0);
    _31585 = NOVALUE;
L1C: 
    DeRefi(_msg_62998);
    _msg_62998 = NOVALUE;
    DeRefi(_errloc_62999);
    _errloc_62999 = NOVALUE;
    goto L1D; // [851] 889
LB: 

    /** 	elsif report_errors then*/
    if (_report_errors_62935 == 0)
    {
        goto L1E; // [856] 888
    }
    else{
    }

    /** 		forward_references  = {}*/
    RefDS(_22037);
    DeRef(_29forward_references_61532);
    _29forward_references_61532 = _22037;

    /** 		active_references   = {}*/
    RefDS(_22037);
    DeRef(_29active_references_61534);
    _29active_references_61534 = _22037;

    /** 		toplevel_references = {}*/
    RefDS(_22037);
    DeRef(_29toplevel_references_61535);
    _29toplevel_references_61535 = _22037;

    /** 		inactive_references = {}*/
    RefDS(_22037);
    DeRef(_29inactive_references_61536);
    _29inactive_references_61536 = _22037;
L1E: 
L1D: 

    /** 	clear_last()*/
    _37clear_last();

    /** end procedure*/
    DeRef(_errors_62936);
    _31478 = NOVALUE;
    _31481 = NOVALUE;
    DeRef(_31484);
    _31484 = NOVALUE;
    _31486 = NOVALUE;
    _31488 = NOVALUE;
    _31501 = NOVALUE;
    _31568 = NOVALUE;
    DeRef(_31504);
    _31504 = NOVALUE;
    DeRef(_31507);
    _31507 = NOVALUE;
    _31523 = NOVALUE;
    _31535 = NOVALUE;
    _31543 = NOVALUE;
    _31527 = NOVALUE;
    _31555 = NOVALUE;
    return;
    ;
}


void _29shift_these(int _refs_63146, int _pc_63147, int _amount_63148)
{
    int _fr_63152 = NOVALUE;
    int _31603 = NOVALUE;
    int _31602 = NOVALUE;
    int _31601 = NOVALUE;
    int _31600 = NOVALUE;
    int _31599 = NOVALUE;
    int _31598 = NOVALUE;
    int _31597 = NOVALUE;
    int _31596 = NOVALUE;
    int _31595 = NOVALUE;
    int _31594 = NOVALUE;
    int _31592 = NOVALUE;
    int _31590 = NOVALUE;
    int _31589 = NOVALUE;
    int _31587 = NOVALUE;
    int _31586 = NOVALUE;
    int _0, _1, _2;
    

    /** 	for i = length( refs ) to 1 by -1 do*/
    if (IS_SEQUENCE(_refs_63146)){
            _31586 = SEQ_PTR(_refs_63146)->length;
    }
    else {
        _31586 = 1;
    }
    {
        int _i_63150;
        _i_63150 = _31586;
L1: 
        if (_i_63150 < 1){
            goto L2; // [12] 147
        }

        /** 		sequence fr = forward_references[refs[i]]*/
        _2 = (int)SEQ_PTR(_refs_63146);
        _31587 = (int)*(((s1_ptr)_2)->base + _i_63150);
        DeRef(_fr_63152);
        _2 = (int)SEQ_PTR(_29forward_references_61532);
        if (!IS_ATOM_INT(_31587)){
            _fr_63152 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_31587)->dbl));
        }
        else{
            _fr_63152 = (int)*(((s1_ptr)_2)->base + _31587);
        }
        Ref(_fr_63152);

        /** 		forward_references[refs[i]] = 0*/
        _2 = (int)SEQ_PTR(_refs_63146);
        _31589 = (int)*(((s1_ptr)_2)->base + _i_63150);
        _2 = (int)SEQ_PTR(_29forward_references_61532);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _29forward_references_61532 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_31589))
        _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_31589)->dbl));
        else
        _2 = (int)(((s1_ptr)_2)->base + _31589);
        _1 = *(int *)_2;
        *(int *)_2 = 0;
        DeRef(_1);

        /** 		if fr[FR_SUBPROG] = shifting_sub then*/
        _2 = (int)SEQ_PTR(_fr_63152);
        _31590 = (int)*(((s1_ptr)_2)->base + 4);
        if (binary_op_a(NOTEQ, _31590, _29shifting_sub_61551)){
            _31590 = NOVALUE;
            goto L3; // [53] 126
        }
        _31590 = NOVALUE;

        /** 			if fr[FR_PC] >= pc then*/
        _2 = (int)SEQ_PTR(_fr_63152);
        _31592 = (int)*(((s1_ptr)_2)->base + 5);
        if (binary_op_a(LESS, _31592, _pc_63147)){
            _31592 = NOVALUE;
            goto L4; // [63] 125
        }
        _31592 = NOVALUE;

        /** 				fr[FR_PC] += amount*/
        _2 = (int)SEQ_PTR(_fr_63152);
        _31594 = (int)*(((s1_ptr)_2)->base + 5);
        if (IS_ATOM_INT(_31594)) {
            _31595 = _31594 + _amount_63148;
            if ((long)((unsigned long)_31595 + (unsigned long)HIGH_BITS) >= 0) 
            _31595 = NewDouble((double)_31595);
        }
        else {
            _31595 = binary_op(PLUS, _31594, _amount_63148);
        }
        _31594 = NOVALUE;
        _2 = (int)SEQ_PTR(_fr_63152);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _fr_63152 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 5);
        _1 = *(int *)_2;
        *(int *)_2 = _31595;
        if( _1 != _31595 ){
            DeRef(_1);
        }
        _31595 = NOVALUE;

        /** 				if fr[FR_TYPE] = CASE*/
        _2 = (int)SEQ_PTR(_fr_63152);
        _31596 = (int)*(((s1_ptr)_2)->base + 1);
        if (IS_ATOM_INT(_31596)) {
            _31597 = (_31596 == 186);
        }
        else {
            _31597 = binary_op(EQUALS, _31596, 186);
        }
        _31596 = NOVALUE;
        if (IS_ATOM_INT(_31597)) {
            if (_31597 == 0) {
                goto L5; // [93] 124
            }
        }
        else {
            if (DBL_PTR(_31597)->dbl == 0.0) {
                goto L5; // [93] 124
            }
        }
        _2 = (int)SEQ_PTR(_fr_63152);
        _31599 = (int)*(((s1_ptr)_2)->base + 12);
        if (IS_ATOM_INT(_31599)) {
            _31600 = (_31599 >= _pc_63147);
        }
        else {
            _31600 = binary_op(GREATEREQ, _31599, _pc_63147);
        }
        _31599 = NOVALUE;
        if (_31600 == 0) {
            DeRef(_31600);
            _31600 = NOVALUE;
            goto L5; // [106] 124
        }
        else {
            if (!IS_ATOM_INT(_31600) && DBL_PTR(_31600)->dbl == 0.0){
                DeRef(_31600);
                _31600 = NOVALUE;
                goto L5; // [106] 124
            }
            DeRef(_31600);
            _31600 = NOVALUE;
        }
        DeRef(_31600);
        _31600 = NOVALUE;

        /** 					fr[FR_DATA] += amount*/
        _2 = (int)SEQ_PTR(_fr_63152);
        _31601 = (int)*(((s1_ptr)_2)->base + 12);
        if (IS_ATOM_INT(_31601)) {
            _31602 = _31601 + _amount_63148;
            if ((long)((unsigned long)_31602 + (unsigned long)HIGH_BITS) >= 0) 
            _31602 = NewDouble((double)_31602);
        }
        else {
            _31602 = binary_op(PLUS, _31601, _amount_63148);
        }
        _31601 = NOVALUE;
        _2 = (int)SEQ_PTR(_fr_63152);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _fr_63152 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 12);
        _1 = *(int *)_2;
        *(int *)_2 = _31602;
        if( _1 != _31602 ){
            DeRef(_1);
        }
        _31602 = NOVALUE;
L5: 
L4: 
L3: 

        /** 		forward_references[refs[i]] = fr*/
        _2 = (int)SEQ_PTR(_refs_63146);
        _31603 = (int)*(((s1_ptr)_2)->base + _i_63150);
        RefDS(_fr_63152);
        _2 = (int)SEQ_PTR(_29forward_references_61532);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _29forward_references_61532 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_31603))
        _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_31603)->dbl));
        else
        _2 = (int)(((s1_ptr)_2)->base + _31603);
        _1 = *(int *)_2;
        *(int *)_2 = _fr_63152;
        DeRef(_1);
        DeRefDS(_fr_63152);
        _fr_63152 = NOVALUE;

        /** 	end for*/
        _i_63150 = _i_63150 + -1;
        goto L1; // [142] 19
L2: 
        ;
    }

    /** end procedure*/
    DeRefDS(_refs_63146);
    _31587 = NOVALUE;
    _31589 = NOVALUE;
    _31603 = NOVALUE;
    DeRef(_31597);
    _31597 = NOVALUE;
    return;
    ;
}


void _29shift_top(int _refs_63176, int _pc_63177, int _amount_63178)
{
    int _fr_63182 = NOVALUE;
    int _31619 = NOVALUE;
    int _31618 = NOVALUE;
    int _31617 = NOVALUE;
    int _31616 = NOVALUE;
    int _31615 = NOVALUE;
    int _31614 = NOVALUE;
    int _31613 = NOVALUE;
    int _31612 = NOVALUE;
    int _31611 = NOVALUE;
    int _31610 = NOVALUE;
    int _31608 = NOVALUE;
    int _31607 = NOVALUE;
    int _31605 = NOVALUE;
    int _31604 = NOVALUE;
    int _0, _1, _2;
    

    /** 	for i = length( refs ) to 1 by -1 do*/
    if (IS_SEQUENCE(_refs_63176)){
            _31604 = SEQ_PTR(_refs_63176)->length;
    }
    else {
        _31604 = 1;
    }
    {
        int _i_63180;
        _i_63180 = _31604;
L1: 
        if (_i_63180 < 1){
            goto L2; // [12] 134
        }

        /** 		sequence fr = forward_references[refs[i]]*/
        _2 = (int)SEQ_PTR(_refs_63176);
        _31605 = (int)*(((s1_ptr)_2)->base + _i_63180);
        DeRef(_fr_63182);
        _2 = (int)SEQ_PTR(_29forward_references_61532);
        if (!IS_ATOM_INT(_31605)){
            _fr_63182 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_31605)->dbl));
        }
        else{
            _fr_63182 = (int)*(((s1_ptr)_2)->base + _31605);
        }
        Ref(_fr_63182);

        /** 		forward_references[refs[i]] = 0*/
        _2 = (int)SEQ_PTR(_refs_63176);
        _31607 = (int)*(((s1_ptr)_2)->base + _i_63180);
        _2 = (int)SEQ_PTR(_29forward_references_61532);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _29forward_references_61532 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_31607))
        _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_31607)->dbl));
        else
        _2 = (int)(((s1_ptr)_2)->base + _31607);
        _1 = *(int *)_2;
        *(int *)_2 = 0;
        DeRef(_1);

        /** 		if fr[FR_PC] >= pc then*/
        _2 = (int)SEQ_PTR(_fr_63182);
        _31608 = (int)*(((s1_ptr)_2)->base + 5);
        if (binary_op_a(LESS, _31608, _pc_63177)){
            _31608 = NOVALUE;
            goto L3; // [51] 113
        }
        _31608 = NOVALUE;

        /** 			fr[FR_PC] += amount*/
        _2 = (int)SEQ_PTR(_fr_63182);
        _31610 = (int)*(((s1_ptr)_2)->base + 5);
        if (IS_ATOM_INT(_31610)) {
            _31611 = _31610 + _amount_63178;
            if ((long)((unsigned long)_31611 + (unsigned long)HIGH_BITS) >= 0) 
            _31611 = NewDouble((double)_31611);
        }
        else {
            _31611 = binary_op(PLUS, _31610, _amount_63178);
        }
        _31610 = NOVALUE;
        _2 = (int)SEQ_PTR(_fr_63182);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _fr_63182 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 5);
        _1 = *(int *)_2;
        *(int *)_2 = _31611;
        if( _1 != _31611 ){
            DeRef(_1);
        }
        _31611 = NOVALUE;

        /** 			if fr[FR_TYPE] = CASE*/
        _2 = (int)SEQ_PTR(_fr_63182);
        _31612 = (int)*(((s1_ptr)_2)->base + 1);
        if (IS_ATOM_INT(_31612)) {
            _31613 = (_31612 == 186);
        }
        else {
            _31613 = binary_op(EQUALS, _31612, 186);
        }
        _31612 = NOVALUE;
        if (IS_ATOM_INT(_31613)) {
            if (_31613 == 0) {
                goto L4; // [81] 112
            }
        }
        else {
            if (DBL_PTR(_31613)->dbl == 0.0) {
                goto L4; // [81] 112
            }
        }
        _2 = (int)SEQ_PTR(_fr_63182);
        _31615 = (int)*(((s1_ptr)_2)->base + 12);
        if (IS_ATOM_INT(_31615)) {
            _31616 = (_31615 >= _pc_63177);
        }
        else {
            _31616 = binary_op(GREATEREQ, _31615, _pc_63177);
        }
        _31615 = NOVALUE;
        if (_31616 == 0) {
            DeRef(_31616);
            _31616 = NOVALUE;
            goto L4; // [94] 112
        }
        else {
            if (!IS_ATOM_INT(_31616) && DBL_PTR(_31616)->dbl == 0.0){
                DeRef(_31616);
                _31616 = NOVALUE;
                goto L4; // [94] 112
            }
            DeRef(_31616);
            _31616 = NOVALUE;
        }
        DeRef(_31616);
        _31616 = NOVALUE;

        /** 				fr[FR_DATA] += amount*/
        _2 = (int)SEQ_PTR(_fr_63182);
        _31617 = (int)*(((s1_ptr)_2)->base + 12);
        if (IS_ATOM_INT(_31617)) {
            _31618 = _31617 + _amount_63178;
            if ((long)((unsigned long)_31618 + (unsigned long)HIGH_BITS) >= 0) 
            _31618 = NewDouble((double)_31618);
        }
        else {
            _31618 = binary_op(PLUS, _31617, _amount_63178);
        }
        _31617 = NOVALUE;
        _2 = (int)SEQ_PTR(_fr_63182);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _fr_63182 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 12);
        _1 = *(int *)_2;
        *(int *)_2 = _31618;
        if( _1 != _31618 ){
            DeRef(_1);
        }
        _31618 = NOVALUE;
L4: 
L3: 

        /** 		forward_references[refs[i]] = fr*/
        _2 = (int)SEQ_PTR(_refs_63176);
        _31619 = (int)*(((s1_ptr)_2)->base + _i_63180);
        RefDS(_fr_63182);
        _2 = (int)SEQ_PTR(_29forward_references_61532);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _29forward_references_61532 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_31619))
        _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_31619)->dbl));
        else
        _2 = (int)(((s1_ptr)_2)->base + _31619);
        _1 = *(int *)_2;
        *(int *)_2 = _fr_63182;
        DeRef(_1);
        DeRefDS(_fr_63182);
        _fr_63182 = NOVALUE;

        /** 	end for*/
        _i_63180 = _i_63180 + -1;
        goto L1; // [129] 19
L2: 
        ;
    }

    /** end procedure*/
    DeRefDS(_refs_63176);
    _31605 = NOVALUE;
    _31607 = NOVALUE;
    _31619 = NOVALUE;
    DeRef(_31613);
    _31613 = NOVALUE;
    return;
    ;
}


void _29shift_fwd_refs(int _pc_63203, int _amount_63204)
{
    int _file_63215 = NOVALUE;
    int _sp_63220 = NOVALUE;
    int _31629 = NOVALUE;
    int _31628 = NOVALUE;
    int _31626 = NOVALUE;
    int _31624 = NOVALUE;
    int _31623 = NOVALUE;
    int _31622 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_pc_63203)) {
        _1 = (long)(DBL_PTR(_pc_63203)->dbl);
        DeRefDS(_pc_63203);
        _pc_63203 = _1;
    }
    if (!IS_ATOM_INT(_amount_63204)) {
        _1 = (long)(DBL_PTR(_amount_63204)->dbl);
        DeRefDS(_amount_63204);
        _amount_63204 = _1;
    }

    /** 	if not shifting_sub then*/
    if (_29shifting_sub_61551 != 0)
    goto L1; // [9] 18

    /** 		return*/
    return;
L1: 

    /** 	if shifting_sub = TopLevelSub then*/
    if (_29shifting_sub_61551 != _26TopLevelSub_11989)
    goto L2; // [24] 65

    /** 		for file = 1 to length( toplevel_references ) do*/
    if (IS_SEQUENCE(_29toplevel_references_61535)){
            _31622 = SEQ_PTR(_29toplevel_references_61535)->length;
    }
    else {
        _31622 = 1;
    }
    {
        int _file_63211;
        _file_63211 = 1;
L3: 
        if (_file_63211 > _31622){
            goto L4; // [35] 62
        }

        /** 			shift_top( toplevel_references[file], pc, amount )*/
        _2 = (int)SEQ_PTR(_29toplevel_references_61535);
        _31623 = (int)*(((s1_ptr)_2)->base + _file_63211);
        Ref(_31623);
        _29shift_top(_31623, _pc_63203, _amount_63204);
        _31623 = NOVALUE;

        /** 		end for*/
        _file_63211 = _file_63211 + 1;
        goto L3; // [57] 42
L4: 
        ;
    }
    goto L5; // [62] 118
L2: 

    /** 		integer file = SymTab[shifting_sub][S_FILE_NO]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _31624 = (int)*(((s1_ptr)_2)->base + _29shifting_sub_61551);
    _2 = (int)SEQ_PTR(_31624);
    if (!IS_ATOM_INT(_26S_FILE_NO_11650)){
        _file_63215 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_FILE_NO_11650)->dbl));
    }
    else{
        _file_63215 = (int)*(((s1_ptr)_2)->base + _26S_FILE_NO_11650);
    }
    if (!IS_ATOM_INT(_file_63215)){
        _file_63215 = (long)DBL_PTR(_file_63215)->dbl;
    }
    _31624 = NOVALUE;

    /** 		integer sp   = find( shifting_sub, active_subprogs[file] )*/
    _2 = (int)SEQ_PTR(_29active_subprogs_61533);
    _31626 = (int)*(((s1_ptr)_2)->base + _file_63215);
    _sp_63220 = find_from(_29shifting_sub_61551, _31626, 1);
    _31626 = NOVALUE;

    /** 		shift_these( active_references[file][sp], pc, amount )*/
    _2 = (int)SEQ_PTR(_29active_references_61534);
    _31628 = (int)*(((s1_ptr)_2)->base + _file_63215);
    _2 = (int)SEQ_PTR(_31628);
    _31629 = (int)*(((s1_ptr)_2)->base + _sp_63220);
    _31628 = NOVALUE;
    Ref(_31629);
    _29shift_these(_31629, _pc_63203, _amount_63204);
    _31629 = NOVALUE;
L5: 

    /** end procedure*/
    return;
    ;
}



// 0xB4A0B5A8
