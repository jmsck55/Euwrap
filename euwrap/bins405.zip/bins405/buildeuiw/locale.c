// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int _45get_text(int _MsgNum_20136, int _LocalQuals_20137, int _DBBase_20138)
{
    int _db_res_20140 = NOVALUE;
    int _lMsgText_20141 = NOVALUE;
    int _dbname_20142 = NOVALUE;
    int _11249 = NOVALUE;
    int _11247 = NOVALUE;
    int _11245 = NOVALUE;
    int _11244 = NOVALUE;
    int _11243 = NOVALUE;
    int _11241 = NOVALUE;
    int _11240 = NOVALUE;
    int _11239 = NOVALUE;
    int _11233 = NOVALUE;
    int _11232 = NOVALUE;
    int _11231 = NOVALUE;
    int _11224 = NOVALUE;
    int _11221 = NOVALUE;
    int _11219 = NOVALUE;
    int _11217 = NOVALUE;
    int _11216 = NOVALUE;
    int _11215 = NOVALUE;
    int _11214 = NOVALUE;
    int _0, _1, _2;
    

    /** 	db_res = -1*/
    _db_res_20140 = -1;

    /** 	lMsgText = 0*/
    DeRef(_lMsgText_20141);
    _lMsgText_20141 = 0;

    /** 	if string(LocalQuals) and length(LocalQuals) > 0 then*/
    RefDS(_LocalQuals_20137);
    _11214 = _9string(_LocalQuals_20137);
    if (IS_ATOM_INT(_11214)) {
        if (_11214 == 0) {
            goto L1; // [23] 45
        }
    }
    else {
        if (DBL_PTR(_11214)->dbl == 0.0) {
            goto L1; // [23] 45
        }
    }
    if (IS_SEQUENCE(_LocalQuals_20137)){
            _11216 = SEQ_PTR(_LocalQuals_20137)->length;
    }
    else {
        _11216 = 1;
    }
    _11217 = (_11216 > 0);
    _11216 = NOVALUE;
    if (_11217 == 0)
    {
        DeRef(_11217);
        _11217 = NOVALUE;
        goto L1; // [35] 45
    }
    else{
        DeRef(_11217);
        _11217 = NOVALUE;
    }

    /** 		LocalQuals = {LocalQuals}*/
    _0 = _LocalQuals_20137;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_LocalQuals_20137);
    *((int *)(_2+4)) = _LocalQuals_20137;
    _LocalQuals_20137 = MAKE_SEQ(_1);
    DeRefDS(_0);
L1: 

    /** 	for i = 1 to length(LocalQuals) do*/
    if (IS_SEQUENCE(_LocalQuals_20137)){
            _11219 = SEQ_PTR(_LocalQuals_20137)->length;
    }
    else {
        _11219 = 1;
    }
    {
        int _i_20151;
        _i_20151 = 1;
L2: 
        if (_i_20151 > _11219){
            goto L3; // [50] 136
        }

        /** 		dbname = DBBase & "_" & LocalQuals[i] & ".edb"*/
        _2 = (int)SEQ_PTR(_LocalQuals_20137);
        _11221 = (int)*(((s1_ptr)_2)->base + _i_20151);
        {
            int concat_list[4];

            concat_list[0] = _11222;
            concat_list[1] = _11221;
            concat_list[2] = _11220;
            concat_list[3] = _DBBase_20138;
            Concat_N((object_ptr)&_dbname_20142, concat_list, 4);
        }
        _11221 = NOVALUE;

        /** 		db_res = eds:db_select( filesys:locate_file( dbname ), eds:DB_LOCK_READ_ONLY)*/
        RefDS(_dbname_20142);
        RefDS(_5);
        RefDS(_5);
        _11224 = _15locate_file(_dbname_20142, _5, _5);
        _db_res_20140 = _48db_select(_11224, 3);
        _11224 = NOVALUE;
        if (!IS_ATOM_INT(_db_res_20140)) {
            _1 = (long)(DBL_PTR(_db_res_20140)->dbl);
            DeRefDS(_db_res_20140);
            _db_res_20140 = _1;
        }

        /** 		if db_res = eds:DB_OK then*/
        if (_db_res_20140 != 0)
        goto L4; // [87] 129

        /** 			db_res = eds:db_select_table("1")*/
        RefDS(_11227);
        _db_res_20140 = _48db_select_table(_11227);
        if (!IS_ATOM_INT(_db_res_20140)) {
            _1 = (long)(DBL_PTR(_db_res_20140)->dbl);
            DeRefDS(_db_res_20140);
            _db_res_20140 = _1;
        }

        /** 			if db_res = eds:DB_OK then*/
        if (_db_res_20140 != 0)
        goto L5; // [101] 128

        /** 				lMsgText = eds:db_fetch_record(MsgNum)*/
        RefDS(_48current_table_name_17398);
        _0 = _lMsgText_20141;
        _lMsgText_20141 = _48db_fetch_record(_MsgNum_20136, _48current_table_name_17398);
        DeRef(_0);

        /** 				if sequence(lMsgText) then*/
        _11231 = IS_SEQUENCE(_lMsgText_20141);
        if (_11231 == 0)
        {
            _11231 = NOVALUE;
            goto L6; // [119] 127
        }
        else{
            _11231 = NOVALUE;
        }

        /** 					exit*/
        goto L3; // [124] 136
L6: 
L5: 
L4: 

        /** 	end for*/
        _i_20151 = _i_20151 + 1;
        goto L2; // [131] 57
L3: 
        ;
    }

    /** 	if atom(lMsgText) then*/
    _11232 = IS_ATOM(_lMsgText_20141);
    if (_11232 == 0)
    {
        _11232 = NOVALUE;
        goto L7; // [141] 281
    }
    else{
        _11232 = NOVALUE;
    }

    /** 		dbname = filesys:locate_file( DBBase & ".edb" )*/
    Concat((object_ptr)&_11233, _DBBase_20138, _11222);
    RefDS(_5);
    RefDS(_5);
    _0 = _dbname_20142;
    _dbname_20142 = _15locate_file(_11233, _5, _5);
    DeRef(_0);
    _11233 = NOVALUE;

    /** 		db_res = eds:db_select(	dbname, DB_LOCK_READ_ONLY)*/
    RefDS(_dbname_20142);
    _db_res_20140 = _48db_select(_dbname_20142, 3);
    if (!IS_ATOM_INT(_db_res_20140)) {
        _1 = (long)(DBL_PTR(_db_res_20140)->dbl);
        DeRefDS(_db_res_20140);
        _db_res_20140 = _1;
    }

    /** 		if db_res = eds:DB_OK then*/
    if (_db_res_20140 != 0)
    goto L8; // [171] 280

    /** 			db_res = eds:db_select_table("1")*/
    RefDS(_11227);
    _db_res_20140 = _48db_select_table(_11227);
    if (!IS_ATOM_INT(_db_res_20140)) {
        _1 = (long)(DBL_PTR(_db_res_20140)->dbl);
        DeRefDS(_db_res_20140);
        _db_res_20140 = _1;
    }

    /** 			if db_res = eds:DB_OK then*/
    if (_db_res_20140 != 0)
    goto L9; // [185] 279

    /** 				for i = 1 to length(LocalQuals) do*/
    if (IS_SEQUENCE(_LocalQuals_20137)){
            _11239 = SEQ_PTR(_LocalQuals_20137)->length;
    }
    else {
        _11239 = 1;
    }
    {
        int _i_20180;
        _i_20180 = 1;
LA: 
        if (_i_20180 > _11239){
            goto LB; // [194] 238
        }

        /** 					lMsgText = eds:db_fetch_record({LocalQuals[i],MsgNum})*/
        _2 = (int)SEQ_PTR(_LocalQuals_20137);
        _11240 = (int)*(((s1_ptr)_2)->base + _i_20180);
        Ref(_11240);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _11240;
        ((int *)_2)[2] = _MsgNum_20136;
        _11241 = MAKE_SEQ(_1);
        _11240 = NOVALUE;
        RefDS(_48current_table_name_17398);
        _0 = _lMsgText_20141;
        _lMsgText_20141 = _48db_fetch_record(_11241, _48current_table_name_17398);
        DeRef(_0);
        _11241 = NOVALUE;

        /** 					if sequence(lMsgText) then*/
        _11243 = IS_SEQUENCE(_lMsgText_20141);
        if (_11243 == 0)
        {
            _11243 = NOVALUE;
            goto LC; // [223] 231
        }
        else{
            _11243 = NOVALUE;
        }

        /** 						exit*/
        goto LB; // [228] 238
LC: 

        /** 				end for*/
        _i_20180 = _i_20180 + 1;
        goto LA; // [233] 201
LB: 
        ;
    }

    /** 				if atom(lMsgText) then*/
    _11244 = IS_ATOM(_lMsgText_20141);
    if (_11244 == 0)
    {
        _11244 = NOVALUE;
        goto LD; // [243] 260
    }
    else{
        _11244 = NOVALUE;
    }

    /** 					lMsgText = eds:db_fetch_record({"",MsgNum})*/
    RefDS(_5);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _5;
    ((int *)_2)[2] = _MsgNum_20136;
    _11245 = MAKE_SEQ(_1);
    RefDS(_48current_table_name_17398);
    _0 = _lMsgText_20141;
    _lMsgText_20141 = _48db_fetch_record(_11245, _48current_table_name_17398);
    DeRef(_0);
    _11245 = NOVALUE;
LD: 

    /** 				if atom(lMsgText) then*/
    _11247 = IS_ATOM(_lMsgText_20141);
    if (_11247 == 0)
    {
        _11247 = NOVALUE;
        goto LE; // [265] 278
    }
    else{
        _11247 = NOVALUE;
    }

    /** 					lMsgText = eds:db_fetch_record(MsgNum)*/
    RefDS(_48current_table_name_17398);
    _0 = _lMsgText_20141;
    _lMsgText_20141 = _48db_fetch_record(_MsgNum_20136, _48current_table_name_17398);
    DeRef(_0);
LE: 
L9: 
L8: 
L7: 

    /** 	if atom(lMsgText) then*/
    _11249 = IS_ATOM(_lMsgText_20141);
    if (_11249 == 0)
    {
        _11249 = NOVALUE;
        goto LF; // [286] 298
    }
    else{
        _11249 = NOVALUE;
    }

    /** 		return 0*/
    DeRefDS(_LocalQuals_20137);
    DeRefDS(_DBBase_20138);
    DeRef(_lMsgText_20141);
    DeRef(_dbname_20142);
    DeRef(_11214);
    _11214 = NOVALUE;
    return 0;
    goto L10; // [295] 305
LF: 

    /** 		return lMsgText*/
    DeRefDS(_LocalQuals_20137);
    DeRefDS(_DBBase_20138);
    DeRef(_dbname_20142);
    DeRef(_11214);
    _11214 = NOVALUE;
    return _lMsgText_20141;
L10: 
    ;
}



// 0x33304B7E
