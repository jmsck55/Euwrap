// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int _18get_bytes(int _fn_2669, int _n_2670)
{
    int _s_2671 = NOVALUE;
    int _c_2672 = NOVALUE;
    int _first_2673 = NOVALUE;
    int _last_2674 = NOVALUE;
    int _1223 = NOVALUE;
    int _1220 = NOVALUE;
    int _1218 = NOVALUE;
    int _1217 = NOVALUE;
    int _1216 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_n_2670)) {
        _1 = (long)(DBL_PTR(_n_2670)->dbl);
        DeRefDS(_n_2670);
        _n_2670 = _1;
    }

    /** 	if n = 0 then*/
    if (_n_2670 != 0)
    goto L1; // [7] 18

    /** 		return {}*/
    RefDS(_5);
    DeRefi(_s_2671);
    return _5;
L1: 

    /** 	c = getc(fn)*/
    if (_fn_2669 != last_r_file_no) {
        last_r_file_ptr = which_file(_fn_2669, EF_READ);
        last_r_file_no = _fn_2669;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _c_2672 = getKBchar();
        }
        else
        _c_2672 = getc(last_r_file_ptr);
    }
    else
    _c_2672 = getc(last_r_file_ptr);

    /** 	if c = EOF then*/
    if (_c_2672 != -1)
    goto L2; // [25] 36

    /** 		return {}*/
    RefDS(_5);
    DeRefi(_s_2671);
    return _5;
L2: 

    /** 	s = repeat(c, n)*/
    DeRefi(_s_2671);
    _s_2671 = Repeat(_c_2672, _n_2670);

    /** 	last = 1*/
    _last_2674 = 1;

    /** 	while last < n do*/
L3: 
    if (_last_2674 >= _n_2670)
    goto L4; // [52] 159

    /** 		first = last+1*/
    _first_2673 = _last_2674 + 1;

    /** 		last  = last+CHUNK*/
    _last_2674 = _last_2674 + 100;

    /** 		if last > n then*/
    if (_last_2674 <= _n_2670)
    goto L5; // [70] 80

    /** 			last = n*/
    _last_2674 = _n_2670;
L5: 

    /** 		for i = first to last do*/
    _1216 = _last_2674;
    {
        int _i_2688;
        _i_2688 = _first_2673;
L6: 
        if (_i_2688 > _1216){
            goto L7; // [85] 108
        }

        /** 			s[i] = getc(fn)*/
        if (_fn_2669 != last_r_file_no) {
            last_r_file_ptr = which_file(_fn_2669, EF_READ);
            last_r_file_no = _fn_2669;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _1217 = getKBchar();
            }
            else
            _1217 = getc(last_r_file_ptr);
        }
        else
        _1217 = getc(last_r_file_ptr);
        _2 = (int)SEQ_PTR(_s_2671);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _s_2671 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_2688);
        *(int *)_2 = _1217;
        if( _1 != _1217 ){
        }
        _1217 = NOVALUE;

        /** 		end for*/
        _i_2688 = _i_2688 + 1;
        goto L6; // [103] 92
L7: 
        ;
    }

    /** 		if s[last] = EOF then*/
    _2 = (int)SEQ_PTR(_s_2671);
    _1218 = (int)*(((s1_ptr)_2)->base + _last_2674);
    if (_1218 != -1)
    goto L3; // [114] 52

    /** 			while s[last] = EOF do*/
L8: 
    _2 = (int)SEQ_PTR(_s_2671);
    _1220 = (int)*(((s1_ptr)_2)->base + _last_2674);
    if (_1220 != -1)
    goto L9; // [127] 142

    /** 				last -= 1*/
    _last_2674 = _last_2674 - 1;

    /** 			end while*/
    goto L8; // [139] 123
L9: 

    /** 			return s[1..last]*/
    rhs_slice_target = (object_ptr)&_1223;
    RHS_Slice(_s_2671, 1, _last_2674);
    DeRefDSi(_s_2671);
    _1218 = NOVALUE;
    _1220 = NOVALUE;
    return _1223;

    /** 	end while*/
    goto L3; // [156] 52
L4: 

    /** 	return s*/
    _1218 = NOVALUE;
    _1220 = NOVALUE;
    DeRef(_1223);
    _1223 = NOVALUE;
    return _s_2671;
    ;
}


int _18get_integer32(int _fh_2709)
{
    int _1232 = NOVALUE;
    int _1231 = NOVALUE;
    int _1230 = NOVALUE;
    int _1229 = NOVALUE;
    int _1228 = NOVALUE;
    int _0, _1, _2;
    

    /** 	poke(mem0, getc(fh))*/
    if (_fh_2709 != last_r_file_no) {
        last_r_file_ptr = which_file(_fh_2709, EF_READ);
        last_r_file_no = _fh_2709;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _1228 = getKBchar();
        }
        else
        _1228 = getc(last_r_file_ptr);
    }
    else
    _1228 = getc(last_r_file_ptr);
    if (IS_ATOM_INT(_18mem0_2699)){
        poke_addr = (unsigned char *)_18mem0_2699;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_18mem0_2699)->dbl);
    }
    *poke_addr = (unsigned char)_1228;
    _1228 = NOVALUE;

    /** 	poke(mem1, getc(fh))*/
    if (_fh_2709 != last_r_file_no) {
        last_r_file_ptr = which_file(_fh_2709, EF_READ);
        last_r_file_no = _fh_2709;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _1229 = getKBchar();
        }
        else
        _1229 = getc(last_r_file_ptr);
    }
    else
    _1229 = getc(last_r_file_ptr);
    if (IS_ATOM_INT(_18mem1_2700)){
        poke_addr = (unsigned char *)_18mem1_2700;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_18mem1_2700)->dbl);
    }
    *poke_addr = (unsigned char)_1229;
    _1229 = NOVALUE;

    /** 	poke(mem2, getc(fh))*/
    if (_fh_2709 != last_r_file_no) {
        last_r_file_ptr = which_file(_fh_2709, EF_READ);
        last_r_file_no = _fh_2709;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _1230 = getKBchar();
        }
        else
        _1230 = getc(last_r_file_ptr);
    }
    else
    _1230 = getc(last_r_file_ptr);
    if (IS_ATOM_INT(_18mem2_2701)){
        poke_addr = (unsigned char *)_18mem2_2701;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_18mem2_2701)->dbl);
    }
    *poke_addr = (unsigned char)_1230;
    _1230 = NOVALUE;

    /** 	poke(mem3, getc(fh))*/
    if (_fh_2709 != last_r_file_no) {
        last_r_file_ptr = which_file(_fh_2709, EF_READ);
        last_r_file_no = _fh_2709;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _1231 = getKBchar();
        }
        else
        _1231 = getc(last_r_file_ptr);
    }
    else
    _1231 = getc(last_r_file_ptr);
    if (IS_ATOM_INT(_18mem3_2702)){
        poke_addr = (unsigned char *)_18mem3_2702;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_18mem3_2702)->dbl);
    }
    *poke_addr = (unsigned char)_1231;
    _1231 = NOVALUE;

    /** 	return peek4u(mem0)*/
    if (IS_ATOM_INT(_18mem0_2699)) {
        _1232 = *(unsigned long *)_18mem0_2699;
        if ((unsigned)_1232 > (unsigned)MAXINT)
        _1232 = NewDouble((double)(unsigned long)_1232);
    }
    else {
        _1232 = *(unsigned long *)(unsigned long)(DBL_PTR(_18mem0_2699)->dbl);
        if ((unsigned)_1232 > (unsigned)MAXINT)
        _1232 = NewDouble((double)(unsigned long)_1232);
    }
    return _1232;
    ;
}


int _18get_integer16(int _fh_2717)
{
    int _1235 = NOVALUE;
    int _1234 = NOVALUE;
    int _1233 = NOVALUE;
    int _0, _1, _2;
    

    /** 	poke(mem0, getc(fh))*/
    if (_fh_2717 != last_r_file_no) {
        last_r_file_ptr = which_file(_fh_2717, EF_READ);
        last_r_file_no = _fh_2717;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _1233 = getKBchar();
        }
        else
        _1233 = getc(last_r_file_ptr);
    }
    else
    _1233 = getc(last_r_file_ptr);
    if (IS_ATOM_INT(_18mem0_2699)){
        poke_addr = (unsigned char *)_18mem0_2699;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_18mem0_2699)->dbl);
    }
    *poke_addr = (unsigned char)_1233;
    _1233 = NOVALUE;

    /** 	poke(mem1, getc(fh))*/
    if (_fh_2717 != last_r_file_no) {
        last_r_file_ptr = which_file(_fh_2717, EF_READ);
        last_r_file_no = _fh_2717;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _1234 = getKBchar();
        }
        else
        _1234 = getc(last_r_file_ptr);
    }
    else
    _1234 = getc(last_r_file_ptr);
    if (IS_ATOM_INT(_18mem1_2700)){
        poke_addr = (unsigned char *)_18mem1_2700;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_18mem1_2700)->dbl);
    }
    *poke_addr = (unsigned char)_1234;
    _1234 = NOVALUE;

    /** 	return peek2u(mem0)*/
    if (IS_ATOM_INT(_18mem0_2699)) {
        _1235 = *(unsigned short *)_18mem0_2699;
    }
    else {
        _1235 = *(unsigned short *)(unsigned long)(DBL_PTR(_18mem0_2699)->dbl);
    }
    return _1235;
    ;
}


int _18seek(int _fn_2810, int _pos_2811)
{
    int _1281 = NOVALUE;
    int _1280 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_2811);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _fn_2810;
    ((int *)_2)[2] = _pos_2811;
    _1280 = MAKE_SEQ(_1);
    _1281 = machine(19, _1280);
    DeRefDS(_1280);
    _1280 = NOVALUE;
    DeRef(_pos_2811);
    return _1281;
    ;
}


int _18where(int _fn_2816)
{
    int _1282 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return machine_func(M_WHERE, fn)*/
    _1282 = machine(20, _fn_2816);
    return _1282;
    ;
}


void _18flush(int _fn_2820)
{
    int _0, _1, _2;
    

    /** 	machine_proc(M_FLUSH, fn)*/
    machine(60, _fn_2820);

    /** end procedure*/
    return;
    ;
}


int _18read_lines(int _file_2835)
{
    int _fn_2836 = NOVALUE;
    int _ret_2837 = NOVALUE;
    int _y_2838 = NOVALUE;
    int _1305 = NOVALUE;
    int _1304 = NOVALUE;
    int _1303 = NOVALUE;
    int _1302 = NOVALUE;
    int _1297 = NOVALUE;
    int _1296 = NOVALUE;
    int _1294 = NOVALUE;
    int _1293 = NOVALUE;
    int _1292 = NOVALUE;
    int _1287 = NOVALUE;
    int _1286 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if sequence(file) then*/
    _1286 = 1;
    if (_1286 == 0)
    {
        _1286 = NOVALUE;
        goto L1; // [6] 37
    }
    else{
        _1286 = NOVALUE;
    }

    /** 		if length(file) = 0 then*/
    if (IS_SEQUENCE(_file_2835)){
            _1287 = SEQ_PTR(_file_2835)->length;
    }
    else {
        _1287 = 1;
    }
    if (_1287 != 0)
    goto L2; // [14] 26

    /** 			fn = 0*/
    DeRef(_fn_2836);
    _fn_2836 = 0;
    goto L3; // [23] 43
L2: 

    /** 			fn = open(file, "r")*/
    DeRef(_fn_2836);
    _fn_2836 = EOpen(_file_2835, _1289, 0);
    goto L3; // [34] 43
L1: 

    /** 		fn = file*/
    Ref(_file_2835);
    DeRef(_fn_2836);
    _fn_2836 = _file_2835;
L3: 

    /** 	if fn < 0 then return -1 end if*/
    if (binary_op_a(GREATEREQ, _fn_2836, 0)){
        goto L4; // [47] 56
    }
    DeRef(_file_2835);
    DeRef(_fn_2836);
    DeRef(_ret_2837);
    DeRefi(_y_2838);
    return -1;
L4: 

    /** 	ret = {}*/
    RefDS(_5);
    DeRef(_ret_2837);
    _ret_2837 = _5;

    /** 	while sequence(y) with entry do*/
    goto L5; // [63] 125
L6: 
    _1292 = IS_SEQUENCE(_y_2838);
    if (_1292 == 0)
    {
        _1292 = NOVALUE;
        goto L7; // [71] 135
    }
    else{
        _1292 = NOVALUE;
    }

    /** 		if y[$] = '\n' then*/
    if (IS_SEQUENCE(_y_2838)){
            _1293 = SEQ_PTR(_y_2838)->length;
    }
    else {
        _1293 = 1;
    }
    _2 = (int)SEQ_PTR(_y_2838);
    _1294 = (int)*(((s1_ptr)_2)->base + _1293);
    if (_1294 != 10)
    goto L8; // [83] 104

    /** 			y = y[1..$-1]*/
    if (IS_SEQUENCE(_y_2838)){
            _1296 = SEQ_PTR(_y_2838)->length;
    }
    else {
        _1296 = 1;
    }
    _1297 = _1296 - 1;
    _1296 = NOVALUE;
    rhs_slice_target = (object_ptr)&_y_2838;
    RHS_Slice(_y_2838, 1, _1297);

    /** 			ifdef UNIX then*/
L8: 

    /** 		ret = append(ret, y)*/
    Ref(_y_2838);
    Append(&_ret_2837, _ret_2837, _y_2838);

    /** 		if fn = 0 then*/
    if (binary_op_a(NOTEQ, _fn_2836, 0)){
        goto L9; // [112] 122
    }

    /** 			puts(2, '\n')*/
    EPuts(2, 10); // DJP 
L9: 

    /** 	entry*/
L5: 

    /** 		y = gets(fn)*/
    DeRefi(_y_2838);
    _y_2838 = EGets(_fn_2836);

    /** 	end while*/
    goto L6; // [132] 66
L7: 

    /** 	if sequence(file) and length(file) != 0 then*/
    _1302 = IS_SEQUENCE(_file_2835);
    if (_1302 == 0) {
        goto LA; // [140] 160
    }
    if (IS_SEQUENCE(_file_2835)){
            _1304 = SEQ_PTR(_file_2835)->length;
    }
    else {
        _1304 = 1;
    }
    _1305 = (_1304 != 0);
    _1304 = NOVALUE;
    if (_1305 == 0)
    {
        DeRef(_1305);
        _1305 = NOVALUE;
        goto LA; // [152] 160
    }
    else{
        DeRef(_1305);
        _1305 = NOVALUE;
    }

    /** 		close(fn)*/
    if (IS_ATOM_INT(_fn_2836))
    EClose(_fn_2836);
    else
    EClose((int)DBL_PTR(_fn_2836)->dbl);
LA: 

    /** 	return ret*/
    DeRef(_file_2835);
    DeRef(_fn_2836);
    DeRefi(_y_2838);
    _1294 = NOVALUE;
    DeRef(_1297);
    _1297 = NOVALUE;
    return _ret_2837;
    ;
}


int _18write_lines(int _file_2912, int _lines_2913)
{
    int _fn_2914 = NOVALUE;
    int _1335 = NOVALUE;
    int _1334 = NOVALUE;
    int _1333 = NOVALUE;
    int _1329 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if sequence(file) then*/
    _1329 = 1;
    if (_1329 == 0)
    {
        _1329 = NOVALUE;
        goto L1; // [8] 21
    }
    else{
        _1329 = NOVALUE;
    }

    /**     	fn = open(file, "w")*/
    DeRef(_fn_2914);
    _fn_2914 = EOpen(_file_2912, _1330, 0);
    goto L2; // [18] 27
L1: 

    /** 		fn = file*/
    Ref(_file_2912);
    DeRef(_fn_2914);
    _fn_2914 = _file_2912;
L2: 

    /** 	if fn < 0 then return -1 end if*/
    if (binary_op_a(GREATEREQ, _fn_2914, 0)){
        goto L3; // [31] 40
    }
    DeRef(_file_2912);
    DeRefDS(_lines_2913);
    DeRef(_fn_2914);
    return -1;
L3: 

    /** 	for i = 1 to length(lines) do*/
    if (IS_SEQUENCE(_lines_2913)){
            _1333 = SEQ_PTR(_lines_2913)->length;
    }
    else {
        _1333 = 1;
    }
    {
        int _i_2923;
        _i_2923 = 1;
L4: 
        if (_i_2923 > _1333){
            goto L5; // [45] 73
        }

        /** 		puts(fn, lines[i])*/
        _2 = (int)SEQ_PTR(_lines_2913);
        _1334 = (int)*(((s1_ptr)_2)->base + _i_2923);
        EPuts(_fn_2914, _1334); // DJP 
        _1334 = NOVALUE;

        /** 		puts(fn, '\n')*/
        EPuts(_fn_2914, 10); // DJP 

        /** 	end for*/
        _i_2923 = _i_2923 + 1;
        goto L4; // [68] 52
L5: 
        ;
    }

    /** 	if sequence(file) then*/
    _1335 = IS_SEQUENCE(_file_2912);
    if (_1335 == 0)
    {
        _1335 = NOVALUE;
        goto L6; // [78] 86
    }
    else{
        _1335 = NOVALUE;
    }

    /** 		close(fn)*/
    if (IS_ATOM_INT(_fn_2914))
    EClose(_fn_2914);
    else
    EClose((int)DBL_PTR(_fn_2914)->dbl);
L6: 

    /** 	return 1*/
    DeRef(_file_2912);
    DeRefDS(_lines_2913);
    DeRef(_fn_2914);
    return 1;
    ;
}


void _18writef(int _fm_3047, int _data_3048, int _fn_3049, int _data_not_string_3050)
{
    int _real_fn_3051 = NOVALUE;
    int _close_fn_3052 = NOVALUE;
    int _out_style_3053 = NOVALUE;
    int _ts_3056 = NOVALUE;
    int _msg_inlined_crash_at_163_3081 = NOVALUE;
    int _data_inlined_crash_at_160_3080 = NOVALUE;
    int _1410 = NOVALUE;
    int _1408 = NOVALUE;
    int _1407 = NOVALUE;
    int _1406 = NOVALUE;
    int _1400 = NOVALUE;
    int _1399 = NOVALUE;
    int _1398 = NOVALUE;
    int _1397 = NOVALUE;
    int _1396 = NOVALUE;
    int _1395 = NOVALUE;
    int _1393 = NOVALUE;
    int _1392 = NOVALUE;
    int _1391 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer real_fn = 0*/
    _real_fn_3051 = 0;

    /** 	integer close_fn = 0*/
    _close_fn_3052 = 0;

    /** 	sequence out_style = "w"*/
    RefDS(_1330);
    DeRefi(_out_style_3053);
    _out_style_3053 = _1330;

    /** 	if integer(fm) then*/
    _1391 = 1;
    if (_1391 == 0)
    {
        _1391 = NOVALUE;
        goto L1; // [23] 49
    }
    else{
        _1391 = NOVALUE;
    }

    /** 		object ts*/

    /** 		ts = fm*/
    _ts_3056 = _fm_3047;

    /** 		fm = data*/
    RefDS(_data_3048);
    _fm_3047 = _data_3048;

    /** 		data = fn*/
    RefDS(_fn_3049);
    DeRefDS(_data_3048);
    _data_3048 = _fn_3049;

    /** 		fn = ts*/
    DeRefDS(_fn_3049);
    _fn_3049 = _ts_3056;
L1: 

    /** 	if sequence(fn) then*/
    _1392 = IS_SEQUENCE(_fn_3049);
    if (_1392 == 0)
    {
        _1392 = NOVALUE;
        goto L2; // [56] 191
    }
    else{
        _1392 = NOVALUE;
    }

    /** 		if length(fn) = 2 then*/
    if (IS_SEQUENCE(_fn_3049)){
            _1393 = SEQ_PTR(_fn_3049)->length;
    }
    else {
        _1393 = 1;
    }
    if (_1393 != 2)
    goto L3; // [64] 142

    /** 			if sequence(fn[1]) then*/
    _2 = (int)SEQ_PTR(_fn_3049);
    _1395 = (int)*(((s1_ptr)_2)->base + 1);
    _1396 = IS_SEQUENCE(_1395);
    _1395 = NOVALUE;
    if (_1396 == 0)
    {
        _1396 = NOVALUE;
        goto L4; // [77] 141
    }
    else{
        _1396 = NOVALUE;
    }

    /** 				if equal(fn[2], 'a') then*/
    _2 = (int)SEQ_PTR(_fn_3049);
    _1397 = (int)*(((s1_ptr)_2)->base + 2);
    if (_1397 == 97)
    _1398 = 1;
    else if (IS_ATOM_INT(_1397) && IS_ATOM_INT(97))
    _1398 = 0;
    else
    _1398 = (compare(_1397, 97) == 0);
    _1397 = NOVALUE;
    if (_1398 == 0)
    {
        _1398 = NOVALUE;
        goto L5; // [90] 103
    }
    else{
        _1398 = NOVALUE;
    }

    /** 					out_style = "a"*/
    RefDS(_1336);
    DeRefi(_out_style_3053);
    _out_style_3053 = _1336;
    goto L6; // [100] 134
L5: 

    /** 				elsif not equal(fn[2], "a") then*/
    _2 = (int)SEQ_PTR(_fn_3049);
    _1399 = (int)*(((s1_ptr)_2)->base + 2);
    if (_1399 == _1336)
    _1400 = 1;
    else if (IS_ATOM_INT(_1399) && IS_ATOM_INT(_1336))
    _1400 = 0;
    else
    _1400 = (compare(_1399, _1336) == 0);
    _1399 = NOVALUE;
    if (_1400 != 0)
    goto L7; // [113] 126
    _1400 = NOVALUE;

    /** 					out_style = "w"*/
    RefDS(_1330);
    DeRefi(_out_style_3053);
    _out_style_3053 = _1330;
    goto L6; // [123] 134
L7: 

    /** 					out_style = "a"*/
    RefDS(_1336);
    DeRefi(_out_style_3053);
    _out_style_3053 = _1336;
L6: 

    /** 				fn = fn[1]*/
    _0 = _fn_3049;
    _2 = (int)SEQ_PTR(_fn_3049);
    _fn_3049 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_fn_3049);
    DeRef(_0);
L4: 
L3: 

    /** 		real_fn = open(fn, out_style)*/
    _real_fn_3051 = EOpen(_fn_3049, _out_style_3053, 0);

    /** 		if real_fn = -1 then*/
    if (_real_fn_3051 != -1)
    goto L8; // [151] 183

    /** 			error:crash("Unable to write to '%s'", {fn})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_fn_3049);
    *((int *)(_2+4)) = _fn_3049;
    _1406 = MAKE_SEQ(_1);
    DeRef(_data_inlined_crash_at_160_3080);
    _data_inlined_crash_at_160_3080 = _1406;
    _1406 = NOVALUE;

    /** 	msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_163_3081);
    _msg_inlined_crash_at_163_3081 = EPrintf(-9999999, _1405, _data_inlined_crash_at_160_3080);

    /** 	machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_163_3081);

    /** end procedure*/
    goto L9; // [177] 180
L9: 
    DeRef(_data_inlined_crash_at_160_3080);
    _data_inlined_crash_at_160_3080 = NOVALUE;
    DeRefi(_msg_inlined_crash_at_163_3081);
    _msg_inlined_crash_at_163_3081 = NOVALUE;
L8: 

    /** 		close_fn = 1*/
    _close_fn_3052 = 1;
    goto LA; // [188] 199
L2: 

    /** 		real_fn = fn*/
    Ref(_fn_3049);
    _real_fn_3051 = _fn_3049;
    if (!IS_ATOM_INT(_real_fn_3051)) {
        _1 = (long)(DBL_PTR(_real_fn_3051)->dbl);
        DeRefDS(_real_fn_3051);
        _real_fn_3051 = _1;
    }
LA: 

    /** 	if equal(data_not_string, 0) then*/
    if (_data_not_string_3050 == 0)
    _1407 = 1;
    else if (IS_ATOM_INT(_data_not_string_3050) && IS_ATOM_INT(0))
    _1407 = 0;
    else
    _1407 = (compare(_data_not_string_3050, 0) == 0);
    if (_1407 == 0)
    {
        _1407 = NOVALUE;
        goto LB; // [205] 225
    }
    else{
        _1407 = NOVALUE;
    }

    /** 		if types:t_display(data) then*/
    Ref(_data_3048);
    _1408 = _9t_display(_data_3048);
    if (_1408 == 0) {
        DeRef(_1408);
        _1408 = NOVALUE;
        goto LC; // [214] 224
    }
    else {
        if (!IS_ATOM_INT(_1408) && DBL_PTR(_1408)->dbl == 0.0){
            DeRef(_1408);
            _1408 = NOVALUE;
            goto LC; // [214] 224
        }
        DeRef(_1408);
        _1408 = NOVALUE;
    }
    DeRef(_1408);
    _1408 = NOVALUE;

    /** 			data = {data}*/
    _0 = _data_3048;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_data_3048);
    *((int *)(_2+4)) = _data_3048;
    _data_3048 = MAKE_SEQ(_1);
    DeRef(_0);
LC: 
LB: 

    /**     puts(real_fn, text:format( fm, data ) )*/
    Ref(_fm_3047);
    Ref(_data_3048);
    _1410 = _12format(_fm_3047, _data_3048);
    EPuts(_real_fn_3051, _1410); // DJP 
    DeRef(_1410);
    _1410 = NOVALUE;

    /**     if close_fn then*/
    if (_close_fn_3052 == 0)
    {
        goto LD; // [237] 245
    }
    else{
    }

    /**     	close(real_fn)*/
    EClose(_real_fn_3051);
LD: 

    /** end procedure*/
    DeRef(_fm_3047);
    DeRef(_data_3048);
    DeRef(_fn_3049);
    DeRefi(_out_style_3053);
    return;
    ;
}



// 0x5BF56340
