// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int _15find_first_wildcard(int _name_7252, int _from_7253)
{
    int _asterisk_at_7254 = NOVALUE;
    int _question_at_7256 = NOVALUE;
    int _first_wildcard_at_7258 = NOVALUE;
    int _3792 = NOVALUE;
    int _3791 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer asterisk_at = eu:find('*', name, from)*/
    _asterisk_at_7254 = find_from(42, _name_7252, 1);

    /** 	integer question_at = eu:find('?', name, from)*/
    _question_at_7256 = find_from(63, _name_7252, 1);

    /** 	integer first_wildcard_at = asterisk_at*/
    _first_wildcard_at_7258 = _asterisk_at_7254;

    /** 	if asterisk_at or question_at then*/
    if (_asterisk_at_7254 != 0) {
        goto L1; // [26] 35
    }
    if (_question_at_7256 == 0)
    {
        goto L2; // [31] 56
    }
    else{
    }
L1: 

    /** 		if question_at and question_at < asterisk_at then*/
    if (_question_at_7256 == 0) {
        goto L3; // [37] 55
    }
    _3792 = (_question_at_7256 < _asterisk_at_7254);
    if (_3792 == 0)
    {
        DeRef(_3792);
        _3792 = NOVALUE;
        goto L3; // [46] 55
    }
    else{
        DeRef(_3792);
        _3792 = NOVALUE;
    }

    /** 			first_wildcard_at = question_at*/
    _first_wildcard_at_7258 = _question_at_7256;
L3: 
L2: 

    /** 	return first_wildcard_at*/
    DeRefDS(_name_7252);
    return _first_wildcard_at_7258;
    ;
}


int _15dir(int _name_7266)
{
    int _3793 = NOVALUE;
    int _0, _1, _2;
    

    /** 	ifdef WINDOWS then*/

    /** 		return machine_func(M_DIR, name)*/
    _3793 = machine(22, _name_7266);
    DeRefDS(_name_7266);
    return _3793;
    ;
}


int _15current_dir()
{
    int _3795 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return machine_func(M_CURRENT_DIR, 0)*/
    _3795 = machine(23, 0);
    return _3795;
    ;
}


int _15chdir(int _newdir_7274)
{
    int _3796 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return machine_func(M_CHDIR, newdir)*/
    _3796 = machine(63, _newdir_7274);
    DeRefDS(_newdir_7274);
    return _3796;
    ;
}


int _15delete_file(int _name_7406)
{
    int _pfilename_7407 = NOVALUE;
    int _success_7409 = NOVALUE;
    int _3869 = NOVALUE;
    int _0, _1, _2;
    

    /** 	atom pfilename = machine:allocate_string(name)*/
    RefDS(_name_7406);
    _0 = _pfilename_7407;
    _pfilename_7407 = _6allocate_string(_name_7406, 0);
    DeRef(_0);

    /** 	integer success = c_func(xDeleteFile, {pfilename})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_pfilename_7407);
    *((int *)(_2+4)) = _pfilename_7407;
    _3869 = MAKE_SEQ(_1);
    _success_7409 = call_c(1, _15xDeleteFile_7201, _3869);
    DeRefDS(_3869);
    _3869 = NOVALUE;
    if (!IS_ATOM_INT(_success_7409)) {
        _1 = (long)(DBL_PTR(_success_7409)->dbl);
        DeRefDS(_success_7409);
        _success_7409 = _1;
    }

    /** 	ifdef UNIX then*/

    /** 	machine:free(pfilename)*/
    Ref(_pfilename_7407);
    _6free(_pfilename_7407);

    /** 	return success*/
    DeRefDS(_name_7406);
    DeRef(_pfilename_7407);
    return _success_7409;
    ;
}


int _15curdir(int _drive_id_7414)
{
    int _lCurDir_7415 = NOVALUE;
    int _lOrigDir_7416 = NOVALUE;
    int _lDrive_7417 = NOVALUE;
    int _current_dir_inlined_current_dir_at_25_7422 = NOVALUE;
    int _chdir_inlined_chdir_at_55_7425 = NOVALUE;
    int _current_dir_inlined_current_dir_at_77_7428 = NOVALUE;
    int _chdir_inlined_chdir_at_109_7435 = NOVALUE;
    int _newdir_inlined_chdir_at_106_7434 = NOVALUE;
    int _3877 = NOVALUE;
    int _3876 = NOVALUE;
    int _3875 = NOVALUE;
    int _3873 = NOVALUE;
    int _3871 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_drive_id_7414)) {
        _1 = (long)(DBL_PTR(_drive_id_7414)->dbl);
        DeRefDS(_drive_id_7414);
        _drive_id_7414 = _1;
    }

    /** 	ifdef not LINUX then*/

    /** 	    sequence lOrigDir = ""*/
    RefDS(_5);
    DeRefi(_lOrigDir_7416);
    _lOrigDir_7416 = _5;

    /** 	    sequence lDrive*/

    /** 	    if t_alpha(drive_id) then*/
    _3871 = _9t_alpha(_drive_id_7414);
    if (_3871 == 0) {
        DeRef(_3871);
        _3871 = NOVALUE;
        goto L1; // [20] 75
    }
    else {
        if (!IS_ATOM_INT(_3871) && DBL_PTR(_3871)->dbl == 0.0){
            DeRef(_3871);
            _3871 = NOVALUE;
            goto L1; // [20] 75
        }
        DeRef(_3871);
        _3871 = NOVALUE;
    }
    DeRef(_3871);
    _3871 = NOVALUE;

    /** 		    lOrigDir =  current_dir()*/

    /** 	return machine_func(M_CURRENT_DIR, 0)*/
    DeRefDSi(_lOrigDir_7416);
    _lOrigDir_7416 = machine(23, 0);

    /** 		    lDrive = "  "*/
    RefDS(_150);
    DeRefi(_lDrive_7417);
    _lDrive_7417 = _150;

    /** 		    lDrive[1] = drive_id*/
    _2 = (int)SEQ_PTR(_lDrive_7417);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _lDrive_7417 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    *(int *)_2 = _drive_id_7414;

    /** 		    lDrive[2] = ':'*/
    _2 = (int)SEQ_PTR(_lDrive_7417);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _lDrive_7417 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    *(int *)_2 = 58;

    /** 		    if chdir(lDrive) = 0 then*/

    /** 	return machine_func(M_CHDIR, newdir)*/
    _chdir_inlined_chdir_at_55_7425 = machine(63, _lDrive_7417);
    if (_chdir_inlined_chdir_at_55_7425 != 0)
    goto L2; // [62] 74

    /** 		    	lOrigDir = ""*/
    RefDS(_5);
    DeRefi(_lOrigDir_7416);
    _lOrigDir_7416 = _5;
L2: 
L1: 

    /**     lCurDir = current_dir()*/

    /** 	return machine_func(M_CURRENT_DIR, 0)*/
    DeRefi(_lCurDir_7415);
    _lCurDir_7415 = machine(23, 0);

    /** 	ifdef not LINUX then*/

    /** 		if length(lOrigDir) > 0 then*/
    if (IS_SEQUENCE(_lOrigDir_7416)){
            _3873 = SEQ_PTR(_lOrigDir_7416)->length;
    }
    else {
        _3873 = 1;
    }
    if (_3873 <= 0)
    goto L3; // [95] 121

    /** 	    	chdir(lOrigDir[1..2])*/
    rhs_slice_target = (object_ptr)&_3875;
    RHS_Slice(_lOrigDir_7416, 1, 2);
    DeRefi(_newdir_inlined_chdir_at_106_7434);
    _newdir_inlined_chdir_at_106_7434 = _3875;
    _3875 = NOVALUE;

    /** 	return machine_func(M_CHDIR, newdir)*/
    _chdir_inlined_chdir_at_109_7435 = machine(63, _newdir_inlined_chdir_at_106_7434);
    DeRefi(_newdir_inlined_chdir_at_106_7434);
    _newdir_inlined_chdir_at_106_7434 = NOVALUE;
L3: 

    /** 	if (lCurDir[$] != SLASH) then*/
    if (IS_SEQUENCE(_lCurDir_7415)){
            _3876 = SEQ_PTR(_lCurDir_7415)->length;
    }
    else {
        _3876 = 1;
    }
    _2 = (int)SEQ_PTR(_lCurDir_7415);
    _3877 = (int)*(((s1_ptr)_2)->base + _3876);
    if (_3877 == 92)
    goto L4; // [130] 141

    /** 		lCurDir &= SLASH*/
    Append(&_lCurDir_7415, _lCurDir_7415, 92);
L4: 

    /** 	return lCurDir*/
    DeRefi(_lOrigDir_7416);
    DeRefi(_lDrive_7417);
    _3877 = NOVALUE;
    return _lCurDir_7415;
    ;
}


int _15pathinfo(int _path_7594, int _std_slash_7595)
{
    int _slash_7596 = NOVALUE;
    int _period_7597 = NOVALUE;
    int _ch_7598 = NOVALUE;
    int _dir_name_7599 = NOVALUE;
    int _file_name_7600 = NOVALUE;
    int _file_ext_7601 = NOVALUE;
    int _file_full_7602 = NOVALUE;
    int _drive_id_7603 = NOVALUE;
    int _from_slash_7643 = NOVALUE;
    int _4002 = NOVALUE;
    int _3995 = NOVALUE;
    int _3994 = NOVALUE;
    int _3991 = NOVALUE;
    int _3990 = NOVALUE;
    int _3988 = NOVALUE;
    int _3987 = NOVALUE;
    int _3984 = NOVALUE;
    int _3983 = NOVALUE;
    int _3981 = NOVALUE;
    int _3977 = NOVALUE;
    int _3975 = NOVALUE;
    int _3974 = NOVALUE;
    int _3973 = NOVALUE;
    int _3972 = NOVALUE;
    int _3970 = NOVALUE;
    int _0, _1, _2;
    

    /** 	dir_name  = ""*/
    RefDS(_5);
    DeRef(_dir_name_7599);
    _dir_name_7599 = _5;

    /** 	file_name = ""*/
    RefDS(_5);
    DeRef(_file_name_7600);
    _file_name_7600 = _5;

    /** 	file_ext  = ""*/
    RefDS(_5);
    DeRef(_file_ext_7601);
    _file_ext_7601 = _5;

    /** 	file_full = ""*/
    RefDS(_5);
    DeRef(_file_full_7602);
    _file_full_7602 = _5;

    /** 	drive_id  = ""*/
    RefDS(_5);
    DeRef(_drive_id_7603);
    _drive_id_7603 = _5;

    /** 	slash = 0*/
    _slash_7596 = 0;

    /** 	period = 0*/
    _period_7597 = 0;

    /** 	for i = length(path) to 1 by -1 do*/
    if (IS_SEQUENCE(_path_7594)){
            _3970 = SEQ_PTR(_path_7594)->length;
    }
    else {
        _3970 = 1;
    }
    {
        int _i_7605;
        _i_7605 = _3970;
L1: 
        if (_i_7605 < 1){
            goto L2; // [55] 122
        }

        /** 		ch = path[i]*/
        _2 = (int)SEQ_PTR(_path_7594);
        _ch_7598 = (int)*(((s1_ptr)_2)->base + _i_7605);
        if (!IS_ATOM_INT(_ch_7598))
        _ch_7598 = (long)DBL_PTR(_ch_7598)->dbl;

        /** 		if period = 0 and ch = '.' then*/
        _3972 = (_period_7597 == 0);
        if (_3972 == 0) {
            goto L3; // [74] 94
        }
        _3974 = (_ch_7598 == 46);
        if (_3974 == 0)
        {
            DeRef(_3974);
            _3974 = NOVALUE;
            goto L3; // [83] 94
        }
        else{
            DeRef(_3974);
            _3974 = NOVALUE;
        }

        /** 			period = i*/
        _period_7597 = _i_7605;
        goto L4; // [91] 115
L3: 

        /** 		elsif eu:find(ch, SLASHES) then*/
        _3975 = find_from(_ch_7598, _15SLASHES_7229, 1);
        if (_3975 == 0)
        {
            _3975 = NOVALUE;
            goto L5; // [101] 114
        }
        else{
            _3975 = NOVALUE;
        }

        /** 			slash = i*/
        _slash_7596 = _i_7605;

        /** 			exit*/
        goto L2; // [111] 122
L5: 
L4: 

        /** 	end for*/
        _i_7605 = _i_7605 + -1;
        goto L1; // [117] 62
L2: 
        ;
    }

    /** 	if slash > 0 then*/
    if (_slash_7596 <= 0)
    goto L6; // [124] 181

    /** 		dir_name = path[1..slash-1]*/
    _3977 = _slash_7596 - 1;
    rhs_slice_target = (object_ptr)&_dir_name_7599;
    RHS_Slice(_path_7594, 1, _3977);

    /** 		ifdef not UNIX then*/

    /** 			ch = eu:find(':', dir_name)*/
    _ch_7598 = find_from(58, _dir_name_7599, 1);

    /** 			if ch != 0 then*/
    if (_ch_7598 == 0)
    goto L7; // [150] 180

    /** 				drive_id = dir_name[1..ch-1]*/
    _3981 = _ch_7598 - 1;
    rhs_slice_target = (object_ptr)&_drive_id_7603;
    RHS_Slice(_dir_name_7599, 1, _3981);

    /** 				dir_name = dir_name[ch+1..$]*/
    _3983 = _ch_7598 + 1;
    if (IS_SEQUENCE(_dir_name_7599)){
            _3984 = SEQ_PTR(_dir_name_7599)->length;
    }
    else {
        _3984 = 1;
    }
    rhs_slice_target = (object_ptr)&_dir_name_7599;
    RHS_Slice(_dir_name_7599, _3983, _3984);
L7: 
L6: 

    /** 	if period > 0 then*/
    if (_period_7597 <= 0)
    goto L8; // [183] 227

    /** 		file_name = path[slash+1..period-1]*/
    _3987 = _slash_7596 + 1;
    if (_3987 > MAXINT){
        _3987 = NewDouble((double)_3987);
    }
    _3988 = _period_7597 - 1;
    rhs_slice_target = (object_ptr)&_file_name_7600;
    RHS_Slice(_path_7594, _3987, _3988);

    /** 		file_ext = path[period+1..$]*/
    _3990 = _period_7597 + 1;
    if (_3990 > MAXINT){
        _3990 = NewDouble((double)_3990);
    }
    if (IS_SEQUENCE(_path_7594)){
            _3991 = SEQ_PTR(_path_7594)->length;
    }
    else {
        _3991 = 1;
    }
    rhs_slice_target = (object_ptr)&_file_ext_7601;
    RHS_Slice(_path_7594, _3990, _3991);

    /** 		file_full = file_name & '.' & file_ext*/
    {
        int concat_list[3];

        concat_list[0] = _file_ext_7601;
        concat_list[1] = 46;
        concat_list[2] = _file_name_7600;
        Concat_N((object_ptr)&_file_full_7602, concat_list, 3);
    }
    goto L9; // [224] 249
L8: 

    /** 		file_name = path[slash+1..$]*/
    _3994 = _slash_7596 + 1;
    if (_3994 > MAXINT){
        _3994 = NewDouble((double)_3994);
    }
    if (IS_SEQUENCE(_path_7594)){
            _3995 = SEQ_PTR(_path_7594)->length;
    }
    else {
        _3995 = 1;
    }
    rhs_slice_target = (object_ptr)&_file_name_7600;
    RHS_Slice(_path_7594, _3994, _3995);

    /** 		file_full = file_name*/
    RefDS(_file_name_7600);
    DeRef(_file_full_7602);
    _file_full_7602 = _file_name_7600;
L9: 

    /** 	if std_slash != 0 then*/
    if (_std_slash_7595 == 0)
    goto LA; // [251] 317

    /** 		if std_slash < 0 then*/
    if (_std_slash_7595 >= 0)
    goto LB; // [257] 293

    /** 			std_slash = SLASH*/
    _std_slash_7595 = 92;

    /** 			ifdef UNIX then*/

    /** 			sequence from_slash = "/"*/
    RefDS(_3781);
    DeRefi(_from_slash_7643);
    _from_slash_7643 = _3781;

    /** 			dir_name = search:match_replace(from_slash, dir_name, std_slash)*/
    RefDS(_from_slash_7643);
    RefDS(_dir_name_7599);
    _0 = _dir_name_7599;
    _dir_name_7599 = _14match_replace(_from_slash_7643, _dir_name_7599, 92, 0);
    DeRefDS(_0);
    DeRefDSi(_from_slash_7643);
    _from_slash_7643 = NOVALUE;
    goto LC; // [290] 316
LB: 

    /** 			dir_name = search:match_replace("\\", dir_name, std_slash)*/
    RefDS(_1177);
    RefDS(_dir_name_7599);
    _0 = _dir_name_7599;
    _dir_name_7599 = _14match_replace(_1177, _dir_name_7599, _std_slash_7595, 0);
    DeRefDS(_0);

    /** 			dir_name = search:match_replace("/", dir_name, std_slash)*/
    RefDS(_3781);
    RefDS(_dir_name_7599);
    _0 = _dir_name_7599;
    _dir_name_7599 = _14match_replace(_3781, _dir_name_7599, _std_slash_7595, 0);
    DeRefDS(_0);
LC: 
LA: 

    /** 	return {dir_name, file_full, file_name, file_ext, drive_id}*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_dir_name_7599);
    *((int *)(_2+4)) = _dir_name_7599;
    RefDS(_file_full_7602);
    *((int *)(_2+8)) = _file_full_7602;
    RefDS(_file_name_7600);
    *((int *)(_2+12)) = _file_name_7600;
    RefDS(_file_ext_7601);
    *((int *)(_2+16)) = _file_ext_7601;
    RefDS(_drive_id_7603);
    *((int *)(_2+20)) = _drive_id_7603;
    _4002 = MAKE_SEQ(_1);
    DeRefDS(_path_7594);
    DeRefDS(_dir_name_7599);
    DeRefDS(_file_name_7600);
    DeRefDS(_file_ext_7601);
    DeRefDS(_file_full_7602);
    DeRefDS(_drive_id_7603);
    DeRef(_3972);
    _3972 = NOVALUE;
    DeRef(_3977);
    _3977 = NOVALUE;
    DeRef(_3981);
    _3981 = NOVALUE;
    DeRef(_3983);
    _3983 = NOVALUE;
    DeRef(_3987);
    _3987 = NOVALUE;
    DeRef(_3988);
    _3988 = NOVALUE;
    DeRef(_3990);
    _3990 = NOVALUE;
    DeRef(_3994);
    _3994 = NOVALUE;
    return _4002;
    ;
}


int _15dirname(int _path_7651, int _pcd_7652)
{
    int _data_7653 = NOVALUE;
    int _4007 = NOVALUE;
    int _0, _1, _2;
    

    /** 	data = pathinfo(path)*/
    RefDS(_path_7651);
    _0 = _data_7653;
    _data_7653 = _15pathinfo(_path_7651, 0);
    DeRef(_0);

    /** 	if pcd then*/

    /** 	return data[1]*/
    _2 = (int)SEQ_PTR(_data_7653);
    _4007 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_4007);
    DeRefDS(_path_7651);
    DeRefDS(_data_7653);
    return _4007;
    ;
}


int _15filebase(int _path_7680)
{
    int _data_7681 = NOVALUE;
    int _4016 = NOVALUE;
    int _0, _1, _2;
    

    /** 	data = pathinfo(path)*/
    RefDS(_path_7680);
    _0 = _data_7681;
    _data_7681 = _15pathinfo(_path_7680, 0);
    DeRef(_0);

    /** 	return data[3]*/
    _2 = (int)SEQ_PTR(_data_7681);
    _4016 = (int)*(((s1_ptr)_2)->base + 3);
    Ref(_4016);
    DeRefDS(_path_7680);
    DeRefDS(_data_7681);
    return _4016;
    ;
}


int _15fileext(int _path_7686)
{
    int _data_7687 = NOVALUE;
    int _4018 = NOVALUE;
    int _0, _1, _2;
    

    /** 	data = pathinfo(path)*/
    RefDS(_path_7686);
    _0 = _data_7687;
    _data_7687 = _15pathinfo(_path_7686, 0);
    DeRef(_0);

    /** 	return data[4]*/
    _2 = (int)SEQ_PTR(_data_7687);
    _4018 = (int)*(((s1_ptr)_2)->base + 4);
    Ref(_4018);
    DeRefDS(_path_7686);
    DeRefDS(_data_7687);
    return _4018;
    ;
}


int _15defaultext(int _path_7698, int _defext_7699)
{
    int _4033 = NOVALUE;
    int _4030 = NOVALUE;
    int _4028 = NOVALUE;
    int _4027 = NOVALUE;
    int _4026 = NOVALUE;
    int _4024 = NOVALUE;
    int _4023 = NOVALUE;
    int _4021 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if length(defext) = 0 then*/
    _4021 = 3;

    /** 	for i = length(path) to 1 by -1 do*/
    if (IS_SEQUENCE(_path_7698)){
            _4023 = SEQ_PTR(_path_7698)->length;
    }
    else {
        _4023 = 1;
    }
    {
        int _i_7704;
        _i_7704 = _4023;
L1: 
        if (_i_7704 < 1){
            goto L2; // [26] 95
        }

        /** 		if path[i] = '.' then*/
        _2 = (int)SEQ_PTR(_path_7698);
        _4024 = (int)*(((s1_ptr)_2)->base + _i_7704);
        if (binary_op_a(NOTEQ, _4024, 46)){
            _4024 = NOVALUE;
            goto L3; // [39] 50
        }
        _4024 = NOVALUE;

        /** 			return path*/
        DeRefDSi(_defext_7699);
        return _path_7698;
L3: 

        /** 		if find(path[i], SLASHES) then*/
        _2 = (int)SEQ_PTR(_path_7698);
        _4026 = (int)*(((s1_ptr)_2)->base + _i_7704);
        _4027 = find_from(_4026, _15SLASHES_7229, 1);
        _4026 = NOVALUE;
        if (_4027 == 0)
        {
            _4027 = NOVALUE;
            goto L4; // [61] 88
        }
        else{
            _4027 = NOVALUE;
        }

        /** 			if i = length(path) then*/
        if (IS_SEQUENCE(_path_7698)){
                _4028 = SEQ_PTR(_path_7698)->length;
        }
        else {
            _4028 = 1;
        }
        if (_i_7704 != _4028)
        goto L2; // [69] 95

        /** 				return path*/
        DeRefDSi(_defext_7699);
        return _path_7698;
        goto L5; // [79] 87

        /** 				exit*/
        goto L2; // [84] 95
L5: 
L4: 

        /** 	end for*/
        _i_7704 = _i_7704 + -1;
        goto L1; // [90] 33
L2: 
        ;
    }

    /** 	if defext[1] != '.' then*/
    _2 = (int)SEQ_PTR(_defext_7699);
    _4030 = (int)*(((s1_ptr)_2)->base + 1);
    if (_4030 == 46)
    goto L6; // [101] 112

    /** 		path &= '.'*/
    Append(&_path_7698, _path_7698, 46);
L6: 

    /** 	return path & defext*/
    Concat((object_ptr)&_4033, _path_7698, _defext_7699);
    DeRefDS(_path_7698);
    DeRefDSi(_defext_7699);
    _4030 = NOVALUE;
    return _4033;
    ;
}


int _15absolute_path(int _filename_7723)
{
    int _4045 = NOVALUE;
    int _4044 = NOVALUE;
    int _4042 = NOVALUE;
    int _4040 = NOVALUE;
    int _4038 = NOVALUE;
    int _4037 = NOVALUE;
    int _4036 = NOVALUE;
    int _4034 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if length(filename) = 0 then*/
    if (IS_SEQUENCE(_filename_7723)){
            _4034 = SEQ_PTR(_filename_7723)->length;
    }
    else {
        _4034 = 1;
    }
    if (_4034 != 0)
    goto L1; // [8] 19

    /** 		return 0*/
    DeRefDS(_filename_7723);
    return 0;
L1: 

    /** 	if eu:find(filename[1], SLASHES) then*/
    _2 = (int)SEQ_PTR(_filename_7723);
    _4036 = (int)*(((s1_ptr)_2)->base + 1);
    _4037 = find_from(_4036, _15SLASHES_7229, 1);
    _4036 = NOVALUE;
    if (_4037 == 0)
    {
        _4037 = NOVALUE;
        goto L2; // [30] 40
    }
    else{
        _4037 = NOVALUE;
    }

    /** 		return 1*/
    DeRefDS(_filename_7723);
    return 1;
L2: 

    /** 	ifdef WINDOWS then*/

    /** 		if length(filename) = 1 then*/
    if (IS_SEQUENCE(_filename_7723)){
            _4038 = SEQ_PTR(_filename_7723)->length;
    }
    else {
        _4038 = 1;
    }
    if (_4038 != 1)
    goto L3; // [47] 58

    /** 			return 0*/
    DeRefDS(_filename_7723);
    return 0;
L3: 

    /** 		if filename[2] != ':' then*/
    _2 = (int)SEQ_PTR(_filename_7723);
    _4040 = (int)*(((s1_ptr)_2)->base + 2);
    if (binary_op_a(EQUALS, _4040, 58)){
        _4040 = NOVALUE;
        goto L4; // [64] 75
    }
    _4040 = NOVALUE;

    /** 			return 0*/
    DeRefDS(_filename_7723);
    return 0;
L4: 

    /** 		if length(filename) < 3 then*/
    if (IS_SEQUENCE(_filename_7723)){
            _4042 = SEQ_PTR(_filename_7723)->length;
    }
    else {
        _4042 = 1;
    }
    if (_4042 >= 3)
    goto L5; // [80] 91

    /** 			return 0*/
    DeRefDS(_filename_7723);
    return 0;
L5: 

    /** 		if eu:find(filename[3], SLASHES) then*/
    _2 = (int)SEQ_PTR(_filename_7723);
    _4044 = (int)*(((s1_ptr)_2)->base + 3);
    _4045 = find_from(_4044, _15SLASHES_7229, 1);
    _4044 = NOVALUE;
    if (_4045 == 0)
    {
        _4045 = NOVALUE;
        goto L6; // [102] 112
    }
    else{
        _4045 = NOVALUE;
    }

    /** 			return 1*/
    DeRefDS(_filename_7723);
    return 1;
L6: 

    /** 	return 0*/
    DeRefDS(_filename_7723);
    return 0;
    ;
}


int _15canonical_path(int _path_in_7762, int _directory_given_7763, int _case_flags_7764)
{
    int _lPath_7765 = NOVALUE;
    int _lPosA_7766 = NOVALUE;
    int _lPosB_7767 = NOVALUE;
    int _lLevel_7768 = NOVALUE;
    int _lHome_7769 = NOVALUE;
    int _lDrive_7770 = NOVALUE;
    int _current_dir_inlined_current_dir_at_300_7830 = NOVALUE;
    int _driveid_inlined_driveid_at_307_7833 = NOVALUE;
    int _data_inlined_driveid_at_307_7832 = NOVALUE;
    int _wildcard_suffix_7835 = NOVALUE;
    int _first_wildcard_at_7836 = NOVALUE;
    int _last_slash_7839 = NOVALUE;
    int _sl_7911 = NOVALUE;
    int _short_name_7914 = NOVALUE;
    int _correct_name_7917 = NOVALUE;
    int _lower_name_7920 = NOVALUE;
    int _part_7936 = NOVALUE;
    int _list_7940 = NOVALUE;
    int _dir_inlined_dir_at_867_7944 = NOVALUE;
    int _name_inlined_dir_at_864_7943 = NOVALUE;
    int _supplied_name_7945 = NOVALUE;
    int _read_name_7964 = NOVALUE;
    int _read_name_7989 = NOVALUE;
    int _4266 = NOVALUE;
    int _4263 = NOVALUE;
    int _4259 = NOVALUE;
    int _4258 = NOVALUE;
    int _4256 = NOVALUE;
    int _4255 = NOVALUE;
    int _4254 = NOVALUE;
    int _4253 = NOVALUE;
    int _4252 = NOVALUE;
    int _4250 = NOVALUE;
    int _4249 = NOVALUE;
    int _4248 = NOVALUE;
    int _4247 = NOVALUE;
    int _4246 = NOVALUE;
    int _4245 = NOVALUE;
    int _4244 = NOVALUE;
    int _4243 = NOVALUE;
    int _4241 = NOVALUE;
    int _4240 = NOVALUE;
    int _4239 = NOVALUE;
    int _4238 = NOVALUE;
    int _4237 = NOVALUE;
    int _4236 = NOVALUE;
    int _4235 = NOVALUE;
    int _4234 = NOVALUE;
    int _4233 = NOVALUE;
    int _4231 = NOVALUE;
    int _4230 = NOVALUE;
    int _4229 = NOVALUE;
    int _4228 = NOVALUE;
    int _4227 = NOVALUE;
    int _4226 = NOVALUE;
    int _4225 = NOVALUE;
    int _4224 = NOVALUE;
    int _4223 = NOVALUE;
    int _4222 = NOVALUE;
    int _4221 = NOVALUE;
    int _4220 = NOVALUE;
    int _4219 = NOVALUE;
    int _4218 = NOVALUE;
    int _4217 = NOVALUE;
    int _4215 = NOVALUE;
    int _4214 = NOVALUE;
    int _4213 = NOVALUE;
    int _4212 = NOVALUE;
    int _4211 = NOVALUE;
    int _4209 = NOVALUE;
    int _4208 = NOVALUE;
    int _4207 = NOVALUE;
    int _4206 = NOVALUE;
    int _4205 = NOVALUE;
    int _4204 = NOVALUE;
    int _4203 = NOVALUE;
    int _4202 = NOVALUE;
    int _4201 = NOVALUE;
    int _4200 = NOVALUE;
    int _4199 = NOVALUE;
    int _4198 = NOVALUE;
    int _4197 = NOVALUE;
    int _4195 = NOVALUE;
    int _4194 = NOVALUE;
    int _4192 = NOVALUE;
    int _4191 = NOVALUE;
    int _4190 = NOVALUE;
    int _4189 = NOVALUE;
    int _4188 = NOVALUE;
    int _4186 = NOVALUE;
    int _4185 = NOVALUE;
    int _4184 = NOVALUE;
    int _4183 = NOVALUE;
    int _4182 = NOVALUE;
    int _4181 = NOVALUE;
    int _4179 = NOVALUE;
    int _4178 = NOVALUE;
    int _4176 = NOVALUE;
    int _4175 = NOVALUE;
    int _4173 = NOVALUE;
    int _4172 = NOVALUE;
    int _4171 = NOVALUE;
    int _4169 = NOVALUE;
    int _4168 = NOVALUE;
    int _4166 = NOVALUE;
    int _4164 = NOVALUE;
    int _4162 = NOVALUE;
    int _4155 = NOVALUE;
    int _4152 = NOVALUE;
    int _4151 = NOVALUE;
    int _4150 = NOVALUE;
    int _4149 = NOVALUE;
    int _4143 = NOVALUE;
    int _4139 = NOVALUE;
    int _4138 = NOVALUE;
    int _4137 = NOVALUE;
    int _4136 = NOVALUE;
    int _4135 = NOVALUE;
    int _4133 = NOVALUE;
    int _4130 = NOVALUE;
    int _4129 = NOVALUE;
    int _4128 = NOVALUE;
    int _4127 = NOVALUE;
    int _4126 = NOVALUE;
    int _4125 = NOVALUE;
    int _4123 = NOVALUE;
    int _4122 = NOVALUE;
    int _4120 = NOVALUE;
    int _4118 = NOVALUE;
    int _4117 = NOVALUE;
    int _4116 = NOVALUE;
    int _4114 = NOVALUE;
    int _4113 = NOVALUE;
    int _4112 = NOVALUE;
    int _4111 = NOVALUE;
    int _4109 = NOVALUE;
    int _4107 = NOVALUE;
    int _4102 = NOVALUE;
    int _4100 = NOVALUE;
    int _4099 = NOVALUE;
    int _4098 = NOVALUE;
    int _4097 = NOVALUE;
    int _4096 = NOVALUE;
    int _4094 = NOVALUE;
    int _4093 = NOVALUE;
    int _4091 = NOVALUE;
    int _4090 = NOVALUE;
    int _4089 = NOVALUE;
    int _4088 = NOVALUE;
    int _4087 = NOVALUE;
    int _4086 = NOVALUE;
    int _4085 = NOVALUE;
    int _4082 = NOVALUE;
    int _4081 = NOVALUE;
    int _4079 = NOVALUE;
    int _4077 = NOVALUE;
    int _4075 = NOVALUE;
    int _4072 = NOVALUE;
    int _4071 = NOVALUE;
    int _4070 = NOVALUE;
    int _4069 = NOVALUE;
    int _4068 = NOVALUE;
    int _4066 = NOVALUE;
    int _4065 = NOVALUE;
    int _4064 = NOVALUE;
    int _4063 = NOVALUE;
    int _4062 = NOVALUE;
    int _4061 = NOVALUE;
    int _4060 = NOVALUE;
    int _4059 = NOVALUE;
    int _4058 = NOVALUE;
    int _4057 = NOVALUE;
    int _4056 = NOVALUE;
    int _0, _1, _2;
    

    /**     sequence lPath = ""*/
    RefDS(_5);
    DeRef(_lPath_7765);
    _lPath_7765 = _5;

    /**     integer lPosA = -1*/
    _lPosA_7766 = -1;

    /**     integer lPosB = -1*/
    _lPosB_7767 = -1;

    /**     sequence lLevel = ""*/
    RefDS(_5);
    DeRefi(_lLevel_7768);
    _lLevel_7768 = _5;

    /**     path_in = path_in*/
    RefDS(_path_in_7762);
    DeRefDS(_path_in_7762);
    _path_in_7762 = _path_in_7762;

    /** 	ifdef UNIX then*/

    /** 	    sequence lDrive*/

    /** 	    lPath = match_replace("/", path_in, SLASH)*/
    RefDS(_3781);
    RefDS(_path_in_7762);
    _0 = _lPath_7765;
    _lPath_7765 = _14match_replace(_3781, _path_in_7762, 92, 0);
    DeRefDS(_0);

    /**     if (length(lPath) > 2 and lPath[1] = '"' and lPath[$] = '"') then*/
    if (IS_SEQUENCE(_lPath_7765)){
            _4056 = SEQ_PTR(_lPath_7765)->length;
    }
    else {
        _4056 = 1;
    }
    _4057 = (_4056 > 2);
    _4056 = NOVALUE;
    if (_4057 == 0) {
        _4058 = 0;
        goto L1; // [62] 78
    }
    _2 = (int)SEQ_PTR(_lPath_7765);
    _4059 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_4059)) {
        _4060 = (_4059 == 34);
    }
    else {
        _4060 = binary_op(EQUALS, _4059, 34);
    }
    _4059 = NOVALUE;
    if (IS_ATOM_INT(_4060))
    _4058 = (_4060 != 0);
    else
    _4058 = DBL_PTR(_4060)->dbl != 0.0;
L1: 
    if (_4058 == 0) {
        DeRef(_4061);
        _4061 = 0;
        goto L2; // [78] 97
    }
    if (IS_SEQUENCE(_lPath_7765)){
            _4062 = SEQ_PTR(_lPath_7765)->length;
    }
    else {
        _4062 = 1;
    }
    _2 = (int)SEQ_PTR(_lPath_7765);
    _4063 = (int)*(((s1_ptr)_2)->base + _4062);
    if (IS_ATOM_INT(_4063)) {
        _4064 = (_4063 == 34);
    }
    else {
        _4064 = binary_op(EQUALS, _4063, 34);
    }
    _4063 = NOVALUE;
    if (IS_ATOM_INT(_4064))
    _4061 = (_4064 != 0);
    else
    _4061 = DBL_PTR(_4064)->dbl != 0.0;
L2: 
    if (_4061 == 0)
    {
        _4061 = NOVALUE;
        goto L3; // [97] 115
    }
    else{
        _4061 = NOVALUE;
    }

    /**         lPath = lPath[2..$-1]*/
    if (IS_SEQUENCE(_lPath_7765)){
            _4065 = SEQ_PTR(_lPath_7765)->length;
    }
    else {
        _4065 = 1;
    }
    _4066 = _4065 - 1;
    _4065 = NOVALUE;
    rhs_slice_target = (object_ptr)&_lPath_7765;
    RHS_Slice(_lPath_7765, 2, _4066);
L3: 

    /**     if (length(lPath) > 0 and lPath[1] = '~') then*/
    if (IS_SEQUENCE(_lPath_7765)){
            _4068 = SEQ_PTR(_lPath_7765)->length;
    }
    else {
        _4068 = 1;
    }
    _4069 = (_4068 > 0);
    _4068 = NOVALUE;
    if (_4069 == 0) {
        DeRef(_4070);
        _4070 = 0;
        goto L4; // [124] 140
    }
    _2 = (int)SEQ_PTR(_lPath_7765);
    _4071 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_4071)) {
        _4072 = (_4071 == 126);
    }
    else {
        _4072 = binary_op(EQUALS, _4071, 126);
    }
    _4071 = NOVALUE;
    if (IS_ATOM_INT(_4072))
    _4070 = (_4072 != 0);
    else
    _4070 = DBL_PTR(_4072)->dbl != 0.0;
L4: 
    if (_4070 == 0)
    {
        _4070 = NOVALUE;
        goto L5; // [140] 249
    }
    else{
        _4070 = NOVALUE;
    }

    /** 		lHome = getenv("HOME")*/
    DeRef(_lHome_7769);
    _lHome_7769 = EGetEnv(_4073);

    /** 		ifdef WINDOWS then*/

    /** 			if atom(lHome) then*/
    _4075 = IS_ATOM(_lHome_7769);
    if (_4075 == 0)
    {
        _4075 = NOVALUE;
        goto L6; // [155] 171
    }
    else{
        _4075 = NOVALUE;
    }

    /** 				lHome = getenv("HOMEDRIVE") & getenv("HOMEPATH")*/
    _4077 = EGetEnv(_4076);
    _4079 = EGetEnv(_4078);
    if (IS_SEQUENCE(_4077) && IS_ATOM(_4079)) {
        Ref(_4079);
        Append(&_lHome_7769, _4077, _4079);
    }
    else if (IS_ATOM(_4077) && IS_SEQUENCE(_4079)) {
        Ref(_4077);
        Prepend(&_lHome_7769, _4079, _4077);
    }
    else {
        Concat((object_ptr)&_lHome_7769, _4077, _4079);
        DeRef(_4077);
        _4077 = NOVALUE;
    }
    DeRef(_4077);
    _4077 = NOVALUE;
    DeRef(_4079);
    _4079 = NOVALUE;
L6: 

    /** 		if lHome[$] != SLASH then*/
    if (IS_SEQUENCE(_lHome_7769)){
            _4081 = SEQ_PTR(_lHome_7769)->length;
    }
    else {
        _4081 = 1;
    }
    _2 = (int)SEQ_PTR(_lHome_7769);
    _4082 = (int)*(((s1_ptr)_2)->base + _4081);
    if (binary_op_a(EQUALS, _4082, 92)){
        _4082 = NOVALUE;
        goto L7; // [180] 191
    }
    _4082 = NOVALUE;

    /** 			lHome &= SLASH*/
    if (IS_SEQUENCE(_lHome_7769) && IS_ATOM(92)) {
        Append(&_lHome_7769, _lHome_7769, 92);
    }
    else if (IS_ATOM(_lHome_7769) && IS_SEQUENCE(92)) {
    }
    else {
        Concat((object_ptr)&_lHome_7769, _lHome_7769, 92);
    }
L7: 

    /** 		if length(lPath) > 1 and lPath[2] = SLASH then*/
    if (IS_SEQUENCE(_lPath_7765)){
            _4085 = SEQ_PTR(_lPath_7765)->length;
    }
    else {
        _4085 = 1;
    }
    _4086 = (_4085 > 1);
    _4085 = NOVALUE;
    if (_4086 == 0) {
        goto L8; // [200] 233
    }
    _2 = (int)SEQ_PTR(_lPath_7765);
    _4088 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_4088)) {
        _4089 = (_4088 == 92);
    }
    else {
        _4089 = binary_op(EQUALS, _4088, 92);
    }
    _4088 = NOVALUE;
    if (_4089 == 0) {
        DeRef(_4089);
        _4089 = NOVALUE;
        goto L8; // [213] 233
    }
    else {
        if (!IS_ATOM_INT(_4089) && DBL_PTR(_4089)->dbl == 0.0){
            DeRef(_4089);
            _4089 = NOVALUE;
            goto L8; // [213] 233
        }
        DeRef(_4089);
        _4089 = NOVALUE;
    }
    DeRef(_4089);
    _4089 = NOVALUE;

    /** 			lPath = lHome & lPath[3 .. $]*/
    if (IS_SEQUENCE(_lPath_7765)){
            _4090 = SEQ_PTR(_lPath_7765)->length;
    }
    else {
        _4090 = 1;
    }
    rhs_slice_target = (object_ptr)&_4091;
    RHS_Slice(_lPath_7765, 3, _4090);
    if (IS_SEQUENCE(_lHome_7769) && IS_ATOM(_4091)) {
    }
    else if (IS_ATOM(_lHome_7769) && IS_SEQUENCE(_4091)) {
        Ref(_lHome_7769);
        Prepend(&_lPath_7765, _4091, _lHome_7769);
    }
    else {
        Concat((object_ptr)&_lPath_7765, _lHome_7769, _4091);
    }
    DeRefDS(_4091);
    _4091 = NOVALUE;
    goto L9; // [230] 248
L8: 

    /** 			lPath = lHome & lPath[2 .. $]*/
    if (IS_SEQUENCE(_lPath_7765)){
            _4093 = SEQ_PTR(_lPath_7765)->length;
    }
    else {
        _4093 = 1;
    }
    rhs_slice_target = (object_ptr)&_4094;
    RHS_Slice(_lPath_7765, 2, _4093);
    if (IS_SEQUENCE(_lHome_7769) && IS_ATOM(_4094)) {
    }
    else if (IS_ATOM(_lHome_7769) && IS_SEQUENCE(_4094)) {
        Ref(_lHome_7769);
        Prepend(&_lPath_7765, _4094, _lHome_7769);
    }
    else {
        Concat((object_ptr)&_lPath_7765, _lHome_7769, _4094);
    }
    DeRefDS(_4094);
    _4094 = NOVALUE;
L9: 
L5: 

    /** 	ifdef WINDOWS then*/

    /** 	    if ( (length(lPath) > 1) and (lPath[2] = ':' ) ) then*/
    if (IS_SEQUENCE(_lPath_7765)){
            _4096 = SEQ_PTR(_lPath_7765)->length;
    }
    else {
        _4096 = 1;
    }
    _4097 = (_4096 > 1);
    _4096 = NOVALUE;
    if (_4097 == 0) {
        DeRef(_4098);
        _4098 = 0;
        goto LA; // [260] 276
    }
    _2 = (int)SEQ_PTR(_lPath_7765);
    _4099 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_4099)) {
        _4100 = (_4099 == 58);
    }
    else {
        _4100 = binary_op(EQUALS, _4099, 58);
    }
    _4099 = NOVALUE;
    if (IS_ATOM_INT(_4100))
    _4098 = (_4100 != 0);
    else
    _4098 = DBL_PTR(_4100)->dbl != 0.0;
LA: 
    if (_4098 == 0)
    {
        _4098 = NOVALUE;
        goto LB; // [276] 299
    }
    else{
        _4098 = NOVALUE;
    }

    /** 			lDrive = lPath[1..2]*/
    rhs_slice_target = (object_ptr)&_lDrive_7770;
    RHS_Slice(_lPath_7765, 1, 2);

    /** 			lPath = lPath[3..$]*/
    if (IS_SEQUENCE(_lPath_7765)){
            _4102 = SEQ_PTR(_lPath_7765)->length;
    }
    else {
        _4102 = 1;
    }
    rhs_slice_target = (object_ptr)&_lPath_7765;
    RHS_Slice(_lPath_7765, 3, _4102);
    goto LC; // [296] 333
LB: 

    /** 			lDrive = driveid(current_dir()) & ':'*/

    /** 	return machine_func(M_CURRENT_DIR, 0)*/
    DeRefi(_current_dir_inlined_current_dir_at_300_7830);
    _current_dir_inlined_current_dir_at_300_7830 = machine(23, 0);

    /** 	data = pathinfo(path)*/
    RefDS(_current_dir_inlined_current_dir_at_300_7830);
    _0 = _data_inlined_driveid_at_307_7832;
    _data_inlined_driveid_at_307_7832 = _15pathinfo(_current_dir_inlined_current_dir_at_300_7830, 0);
    DeRef(_0);

    /** 	return data[5]*/
    DeRef(_driveid_inlined_driveid_at_307_7833);
    _2 = (int)SEQ_PTR(_data_inlined_driveid_at_307_7832);
    _driveid_inlined_driveid_at_307_7833 = (int)*(((s1_ptr)_2)->base + 5);
    Ref(_driveid_inlined_driveid_at_307_7833);
    DeRef(_data_inlined_driveid_at_307_7832);
    _data_inlined_driveid_at_307_7832 = NOVALUE;
    if (IS_SEQUENCE(_driveid_inlined_driveid_at_307_7833) && IS_ATOM(58)) {
        Append(&_lDrive_7770, _driveid_inlined_driveid_at_307_7833, 58);
    }
    else if (IS_ATOM(_driveid_inlined_driveid_at_307_7833) && IS_SEQUENCE(58)) {
    }
    else {
        Concat((object_ptr)&_lDrive_7770, _driveid_inlined_driveid_at_307_7833, 58);
    }
LC: 

    /** 	sequence wildcard_suffix*/

    /** 	integer first_wildcard_at = find_first_wildcard( lPath )*/
    RefDS(_lPath_7765);
    _first_wildcard_at_7836 = _15find_first_wildcard(_lPath_7765, 1);
    if (!IS_ATOM_INT(_first_wildcard_at_7836)) {
        _1 = (long)(DBL_PTR(_first_wildcard_at_7836)->dbl);
        DeRefDS(_first_wildcard_at_7836);
        _first_wildcard_at_7836 = _1;
    }

    /** 	if first_wildcard_at then*/
    if (_first_wildcard_at_7836 == 0)
    {
        goto LD; // [346] 407
    }
    else{
    }

    /** 		integer last_slash = search:rfind( SLASH, lPath, first_wildcard_at )*/
    RefDS(_lPath_7765);
    _last_slash_7839 = _14rfind(92, _lPath_7765, _first_wildcard_at_7836);
    if (!IS_ATOM_INT(_last_slash_7839)) {
        _1 = (long)(DBL_PTR(_last_slash_7839)->dbl);
        DeRefDS(_last_slash_7839);
        _last_slash_7839 = _1;
    }

    /** 		if last_slash then*/
    if (_last_slash_7839 == 0)
    {
        goto LE; // [361] 387
    }
    else{
    }

    /** 			wildcard_suffix = lPath[last_slash..$]*/
    if (IS_SEQUENCE(_lPath_7765)){
            _4107 = SEQ_PTR(_lPath_7765)->length;
    }
    else {
        _4107 = 1;
    }
    rhs_slice_target = (object_ptr)&_wildcard_suffix_7835;
    RHS_Slice(_lPath_7765, _last_slash_7839, _4107);

    /** 			lPath = remove( lPath, last_slash, length( lPath ) )*/
    if (IS_SEQUENCE(_lPath_7765)){
            _4109 = SEQ_PTR(_lPath_7765)->length;
    }
    else {
        _4109 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_lPath_7765);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_last_slash_7839)) ? _last_slash_7839 : (long)(DBL_PTR(_last_slash_7839)->dbl);
        int stop = (IS_ATOM_INT(_4109)) ? _4109 : (long)(DBL_PTR(_4109)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_lPath_7765), start, &_lPath_7765 );
            }
            else Tail(SEQ_PTR(_lPath_7765), stop+1, &_lPath_7765);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_lPath_7765), start, &_lPath_7765);
        }
        else {
            assign_slice_seq = &assign_space;
            _lPath_7765 = Remove_elements(start, stop, (SEQ_PTR(_lPath_7765)->ref == 1));
        }
    }
    _4109 = NOVALUE;
    goto LF; // [384] 402
LE: 

    /** 			wildcard_suffix = lPath*/
    RefDS(_lPath_7765);
    DeRef(_wildcard_suffix_7835);
    _wildcard_suffix_7835 = _lPath_7765;

    /** 			lPath = ""*/
    RefDS(_5);
    DeRefDS(_lPath_7765);
    _lPath_7765 = _5;
LF: 
    goto L10; // [404] 415
LD: 

    /** 		wildcard_suffix = ""*/
    RefDS(_5);
    DeRef(_wildcard_suffix_7835);
    _wildcard_suffix_7835 = _5;
L10: 

    /** 	if ((length(lPath) = 0) or not find(lPath[1], "/\\")) then*/
    if (IS_SEQUENCE(_lPath_7765)){
            _4111 = SEQ_PTR(_lPath_7765)->length;
    }
    else {
        _4111 = 1;
    }
    _4112 = (_4111 == 0);
    _4111 = NOVALUE;
    if (_4112 != 0) {
        DeRef(_4113);
        _4113 = 1;
        goto L11; // [424] 444
    }
    _2 = (int)SEQ_PTR(_lPath_7765);
    _4114 = (int)*(((s1_ptr)_2)->base + 1);
    _4116 = find_from(_4114, _4115, 1);
    _4114 = NOVALUE;
    _4117 = (_4116 == 0);
    _4116 = NOVALUE;
    _4113 = (_4117 != 0);
L11: 
    if (_4113 == 0)
    {
        _4113 = NOVALUE;
        goto L12; // [444] 545
    }
    else{
        _4113 = NOVALUE;
    }

    /** 		ifdef UNIX then*/

    /** 			if (length(lDrive) = 0) then*/
    if (IS_SEQUENCE(_lDrive_7770)){
            _4118 = SEQ_PTR(_lDrive_7770)->length;
    }
    else {
        _4118 = 1;
    }
    if (_4118 != 0)
    goto L13; // [456] 473

    /** 				lPath = curdir() & lPath*/
    _4120 = _15curdir(0);
    if (IS_SEQUENCE(_4120) && IS_ATOM(_lPath_7765)) {
    }
    else if (IS_ATOM(_4120) && IS_SEQUENCE(_lPath_7765)) {
        Ref(_4120);
        Prepend(&_lPath_7765, _lPath_7765, _4120);
    }
    else {
        Concat((object_ptr)&_lPath_7765, _4120, _lPath_7765);
        DeRef(_4120);
        _4120 = NOVALUE;
    }
    DeRef(_4120);
    _4120 = NOVALUE;
    goto L14; // [470] 488
L13: 

    /** 				lPath = curdir(lDrive[1]) & lPath*/
    _2 = (int)SEQ_PTR(_lDrive_7770);
    _4122 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_4122);
    _4123 = _15curdir(_4122);
    _4122 = NOVALUE;
    if (IS_SEQUENCE(_4123) && IS_ATOM(_lPath_7765)) {
    }
    else if (IS_ATOM(_4123) && IS_SEQUENCE(_lPath_7765)) {
        Ref(_4123);
        Prepend(&_lPath_7765, _lPath_7765, _4123);
    }
    else {
        Concat((object_ptr)&_lPath_7765, _4123, _lPath_7765);
        DeRef(_4123);
        _4123 = NOVALUE;
    }
    DeRef(_4123);
    _4123 = NOVALUE;
L14: 

    /** 			if ( (length(lPath) > 1) and (lPath[2] = ':' ) ) then*/
    if (IS_SEQUENCE(_lPath_7765)){
            _4125 = SEQ_PTR(_lPath_7765)->length;
    }
    else {
        _4125 = 1;
    }
    _4126 = (_4125 > 1);
    _4125 = NOVALUE;
    if (_4126 == 0) {
        DeRef(_4127);
        _4127 = 0;
        goto L15; // [497] 513
    }
    _2 = (int)SEQ_PTR(_lPath_7765);
    _4128 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_4128)) {
        _4129 = (_4128 == 58);
    }
    else {
        _4129 = binary_op(EQUALS, _4128, 58);
    }
    _4128 = NOVALUE;
    if (IS_ATOM_INT(_4129))
    _4127 = (_4129 != 0);
    else
    _4127 = DBL_PTR(_4129)->dbl != 0.0;
L15: 
    if (_4127 == 0)
    {
        _4127 = NOVALUE;
        goto L16; // [513] 544
    }
    else{
        _4127 = NOVALUE;
    }

    /** 				if (length(lDrive) = 0) then*/
    if (IS_SEQUENCE(_lDrive_7770)){
            _4130 = SEQ_PTR(_lDrive_7770)->length;
    }
    else {
        _4130 = 1;
    }
    if (_4130 != 0)
    goto L17; // [521] 533

    /** 					lDrive = lPath[1..2]*/
    rhs_slice_target = (object_ptr)&_lDrive_7770;
    RHS_Slice(_lPath_7765, 1, 2);
L17: 

    /** 				lPath = lPath[3..$]*/
    if (IS_SEQUENCE(_lPath_7765)){
            _4133 = SEQ_PTR(_lPath_7765)->length;
    }
    else {
        _4133 = 1;
    }
    rhs_slice_target = (object_ptr)&_lPath_7765;
    RHS_Slice(_lPath_7765, 3, _4133);
L16: 
L12: 

    /** 	if ((directory_given != 0) and (lPath[$] != SLASH) ) then*/
    _4135 = (_directory_given_7763 != 0);
    if (_4135 == 0) {
        DeRef(_4136);
        _4136 = 0;
        goto L18; // [551] 570
    }
    if (IS_SEQUENCE(_lPath_7765)){
            _4137 = SEQ_PTR(_lPath_7765)->length;
    }
    else {
        _4137 = 1;
    }
    _2 = (int)SEQ_PTR(_lPath_7765);
    _4138 = (int)*(((s1_ptr)_2)->base + _4137);
    if (IS_ATOM_INT(_4138)) {
        _4139 = (_4138 != 92);
    }
    else {
        _4139 = binary_op(NOTEQ, _4138, 92);
    }
    _4138 = NOVALUE;
    if (IS_ATOM_INT(_4139))
    _4136 = (_4139 != 0);
    else
    _4136 = DBL_PTR(_4139)->dbl != 0.0;
L18: 
    if (_4136 == 0)
    {
        _4136 = NOVALUE;
        goto L19; // [570] 580
    }
    else{
        _4136 = NOVALUE;
    }

    /** 		lPath &= SLASH*/
    Append(&_lPath_7765, _lPath_7765, 92);
L19: 

    /** 	lLevel = SLASH & '.' & SLASH*/
    {
        int concat_list[3];

        concat_list[0] = 92;
        concat_list[1] = 46;
        concat_list[2] = 92;
        Concat_N((object_ptr)&_lLevel_7768, concat_list, 3);
    }

    /** 	lPosA = 1*/
    _lPosA_7766 = 1;

    /** 	while( lPosA != 0 ) with entry do*/
    goto L1A; // [595] 616
L1B: 
    if (_lPosA_7766 == 0)
    goto L1C; // [598] 628

    /** 		lPath = eu:remove(lPath, lPosA, lPosA + 1)*/
    _4143 = _lPosA_7766 + 1;
    if (_4143 > MAXINT){
        _4143 = NewDouble((double)_4143);
    }
    {
        s1_ptr assign_space = SEQ_PTR(_lPath_7765);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_lPosA_7766)) ? _lPosA_7766 : (long)(DBL_PTR(_lPosA_7766)->dbl);
        int stop = (IS_ATOM_INT(_4143)) ? _4143 : (long)(DBL_PTR(_4143)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_lPath_7765), start, &_lPath_7765 );
            }
            else Tail(SEQ_PTR(_lPath_7765), stop+1, &_lPath_7765);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_lPath_7765), start, &_lPath_7765);
        }
        else {
            assign_slice_seq = &assign_space;
            _lPath_7765 = Remove_elements(start, stop, (SEQ_PTR(_lPath_7765)->ref == 1));
        }
    }
    DeRef(_4143);
    _4143 = NOVALUE;

    /** 	  entry*/
L1A: 

    /** 		lPosA = match(lLevel, lPath, lPosA )*/
    _lPosA_7766 = e_match_from(_lLevel_7768, _lPath_7765, _lPosA_7766);

    /** 	end while*/
    goto L1B; // [625] 598
L1C: 

    /** 	lLevel = SLASH & ".." & SLASH*/
    {
        int concat_list[3];

        concat_list[0] = 92;
        concat_list[1] = _3825;
        concat_list[2] = 92;
        Concat_N((object_ptr)&_lLevel_7768, concat_list, 3);
    }

    /** 	lPosB = 1*/
    _lPosB_7767 = 1;

    /** 	while( lPosA != 0 ) with entry do*/
    goto L1D; // [643] 721
L1E: 
    if (_lPosA_7766 == 0)
    goto L1F; // [646] 733

    /** 		lPosB = lPosA-1*/
    _lPosB_7767 = _lPosA_7766 - 1;

    /** 		while((lPosB > 0) and (lPath[lPosB] != SLASH)) do*/
L20: 
    _4149 = (_lPosB_7767 > 0);
    if (_4149 == 0) {
        DeRef(_4150);
        _4150 = 0;
        goto L21; // [665] 681
    }
    _2 = (int)SEQ_PTR(_lPath_7765);
    _4151 = (int)*(((s1_ptr)_2)->base + _lPosB_7767);
    if (IS_ATOM_INT(_4151)) {
        _4152 = (_4151 != 92);
    }
    else {
        _4152 = binary_op(NOTEQ, _4151, 92);
    }
    _4151 = NOVALUE;
    if (IS_ATOM_INT(_4152))
    _4150 = (_4152 != 0);
    else
    _4150 = DBL_PTR(_4152)->dbl != 0.0;
L21: 
    if (_4150 == 0)
    {
        _4150 = NOVALUE;
        goto L22; // [681] 695
    }
    else{
        _4150 = NOVALUE;
    }

    /** 			lPosB -= 1*/
    _lPosB_7767 = _lPosB_7767 - 1;

    /** 		end while*/
    goto L20; // [692] 661
L22: 

    /** 		if (lPosB <= 0) then*/
    if (_lPosB_7767 > 0)
    goto L23; // [697] 707

    /** 			lPosB = 1*/
    _lPosB_7767 = 1;
L23: 

    /** 		lPath = eu:remove(lPath, lPosB, lPosA + 2)*/
    _4155 = _lPosA_7766 + 2;
    if ((long)((unsigned long)_4155 + (unsigned long)HIGH_BITS) >= 0) 
    _4155 = NewDouble((double)_4155);
    {
        s1_ptr assign_space = SEQ_PTR(_lPath_7765);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_lPosB_7767)) ? _lPosB_7767 : (long)(DBL_PTR(_lPosB_7767)->dbl);
        int stop = (IS_ATOM_INT(_4155)) ? _4155 : (long)(DBL_PTR(_4155)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_lPath_7765), start, &_lPath_7765 );
            }
            else Tail(SEQ_PTR(_lPath_7765), stop+1, &_lPath_7765);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_lPath_7765), start, &_lPath_7765);
        }
        else {
            assign_slice_seq = &assign_space;
            _lPath_7765 = Remove_elements(start, stop, (SEQ_PTR(_lPath_7765)->ref == 1));
        }
    }
    DeRef(_4155);
    _4155 = NOVALUE;

    /** 	  entry*/
L1D: 

    /** 		lPosA = match(lLevel, lPath, lPosB )*/
    _lPosA_7766 = e_match_from(_lLevel_7768, _lPath_7765, _lPosB_7767);

    /** 	end while*/
    goto L1E; // [730] 646
L1F: 

    /** 	if case_flags = TO_LOWER then*/
    if (_case_flags_7764 != 1)
    goto L24; // [735] 750

    /** 		lPath = lower( lPath )*/
    RefDS(_lPath_7765);
    _0 = _lPath_7765;
    _lPath_7765 = _12lower(_lPath_7765);
    DeRefDS(_0);
    goto L25; // [747] 1355
L24: 

    /** 	elsif case_flags != AS_IS then*/
    if (_case_flags_7764 == 0)
    goto L26; // [752] 1352

    /** 		sequence sl = find_all(SLASH,lPath) -- split apart lPath*/
    RefDS(_lPath_7765);
    _0 = _sl_7911;
    _sl_7911 = _14find_all(92, _lPath_7765, 1);
    DeRef(_0);

    /** 		integer short_name = and_bits(TO_SHORT,case_flags)=TO_SHORT*/
    {unsigned long tu;
         tu = (unsigned long)4 & (unsigned long)_case_flags_7764;
         _4162 = MAKE_UINT(tu);
    }
    if (IS_ATOM_INT(_4162)) {
        _short_name_7914 = (_4162 == 4);
    }
    else {
        _short_name_7914 = (DBL_PTR(_4162)->dbl == (double)4);
    }
    DeRef(_4162);
    _4162 = NOVALUE;

    /** 		integer correct_name = and_bits(case_flags,CORRECT)=CORRECT*/
    {unsigned long tu;
         tu = (unsigned long)_case_flags_7764 & (unsigned long)2;
         _4164 = MAKE_UINT(tu);
    }
    if (IS_ATOM_INT(_4164)) {
        _correct_name_7917 = (_4164 == 2);
    }
    else {
        _correct_name_7917 = (DBL_PTR(_4164)->dbl == (double)2);
    }
    DeRef(_4164);
    _4164 = NOVALUE;

    /** 		integer lower_name = and_bits(TO_LOWER,case_flags)=TO_LOWER*/
    {unsigned long tu;
         tu = (unsigned long)1 & (unsigned long)_case_flags_7764;
         _4166 = MAKE_UINT(tu);
    }
    if (IS_ATOM_INT(_4166)) {
        _lower_name_7920 = (_4166 == 1);
    }
    else {
        _lower_name_7920 = (DBL_PTR(_4166)->dbl == (double)1);
    }
    DeRef(_4166);
    _4166 = NOVALUE;

    /** 		if lPath[$] != SLASH then*/
    if (IS_SEQUENCE(_lPath_7765)){
            _4168 = SEQ_PTR(_lPath_7765)->length;
    }
    else {
        _4168 = 1;
    }
    _2 = (int)SEQ_PTR(_lPath_7765);
    _4169 = (int)*(((s1_ptr)_2)->base + _4168);
    if (binary_op_a(EQUALS, _4169, 92)){
        _4169 = NOVALUE;
        goto L27; // [805] 827
    }
    _4169 = NOVALUE;

    /** 			sl = sl & {length(lPath)+1}*/
    if (IS_SEQUENCE(_lPath_7765)){
            _4171 = SEQ_PTR(_lPath_7765)->length;
    }
    else {
        _4171 = 1;
    }
    _4172 = _4171 + 1;
    _4171 = NOVALUE;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _4172;
    _4173 = MAKE_SEQ(_1);
    _4172 = NOVALUE;
    Concat((object_ptr)&_sl_7911, _sl_7911, _4173);
    DeRefDS(_4173);
    _4173 = NOVALUE;
L27: 

    /** 		for i = length(sl)-1 to 1 by -1 label "partloop" do*/
    if (IS_SEQUENCE(_sl_7911)){
            _4175 = SEQ_PTR(_sl_7911)->length;
    }
    else {
        _4175 = 1;
    }
    _4176 = _4175 - 1;
    _4175 = NOVALUE;
    {
        int _i_7932;
        _i_7932 = _4176;
L28: 
        if (_i_7932 < 1){
            goto L29; // [836] 1317
        }

        /** 			sequence part = lPath[1..sl[i]-1]*/
        _2 = (int)SEQ_PTR(_sl_7911);
        _4178 = (int)*(((s1_ptr)_2)->base + _i_7932);
        if (IS_ATOM_INT(_4178)) {
            _4179 = _4178 - 1;
        }
        else {
            _4179 = binary_op(MINUS, _4178, 1);
        }
        _4178 = NOVALUE;
        rhs_slice_target = (object_ptr)&_part_7936;
        RHS_Slice(_lPath_7765, 1, _4179);

        /** 			object list = dir( part & SLASH )*/
        Append(&_4181, _part_7936, 92);
        DeRef(_name_inlined_dir_at_864_7943);
        _name_inlined_dir_at_864_7943 = _4181;
        _4181 = NOVALUE;

        /** 	ifdef WINDOWS then*/

        /** 		return machine_func(M_DIR, name)*/
        DeRef(_list_7940);
        _list_7940 = machine(22, _name_inlined_dir_at_864_7943);
        DeRef(_name_inlined_dir_at_864_7943);
        _name_inlined_dir_at_864_7943 = NOVALUE;

        /** 			sequence supplied_name = lPath[sl[i]+1..sl[i+1]-1]*/
        _2 = (int)SEQ_PTR(_sl_7911);
        _4182 = (int)*(((s1_ptr)_2)->base + _i_7932);
        if (IS_ATOM_INT(_4182)) {
            _4183 = _4182 + 1;
            if (_4183 > MAXINT){
                _4183 = NewDouble((double)_4183);
            }
        }
        else
        _4183 = binary_op(PLUS, 1, _4182);
        _4182 = NOVALUE;
        _4184 = _i_7932 + 1;
        _2 = (int)SEQ_PTR(_sl_7911);
        _4185 = (int)*(((s1_ptr)_2)->base + _4184);
        if (IS_ATOM_INT(_4185)) {
            _4186 = _4185 - 1;
        }
        else {
            _4186 = binary_op(MINUS, _4185, 1);
        }
        _4185 = NOVALUE;
        rhs_slice_target = (object_ptr)&_supplied_name_7945;
        RHS_Slice(_lPath_7765, _4183, _4186);

        /** 			if atom(list) then*/
        _4188 = IS_ATOM(_list_7940);
        if (_4188 == 0)
        {
            _4188 = NOVALUE;
            goto L2A; // [912] 950
        }
        else{
            _4188 = NOVALUE;
        }

        /** 				if lower_name then*/
        if (_lower_name_7920 == 0)
        {
            goto L2B; // [917] 943
        }
        else{
        }

        /** 					lPath = part & lower(lPath[sl[i]..$])*/
        _2 = (int)SEQ_PTR(_sl_7911);
        _4189 = (int)*(((s1_ptr)_2)->base + _i_7932);
        if (IS_SEQUENCE(_lPath_7765)){
                _4190 = SEQ_PTR(_lPath_7765)->length;
        }
        else {
            _4190 = 1;
        }
        rhs_slice_target = (object_ptr)&_4191;
        RHS_Slice(_lPath_7765, _4189, _4190);
        _4192 = _12lower(_4191);
        _4191 = NOVALUE;
        if (IS_SEQUENCE(_part_7936) && IS_ATOM(_4192)) {
            Ref(_4192);
            Append(&_lPath_7765, _part_7936, _4192);
        }
        else if (IS_ATOM(_part_7936) && IS_SEQUENCE(_4192)) {
        }
        else {
            Concat((object_ptr)&_lPath_7765, _part_7936, _4192);
        }
        DeRef(_4192);
        _4192 = NOVALUE;
L2B: 

        /** 				continue*/
        DeRef(_part_7936);
        _part_7936 = NOVALUE;
        DeRef(_list_7940);
        _list_7940 = NOVALUE;
        DeRef(_supplied_name_7945);
        _supplied_name_7945 = NOVALUE;
        goto L2C; // [947] 1312
L2A: 

        /** 			for j = 1 to length(list) do*/
        if (IS_SEQUENCE(_list_7940)){
                _4194 = SEQ_PTR(_list_7940)->length;
        }
        else {
            _4194 = 1;
        }
        {
            int _j_7962;
            _j_7962 = 1;
L2D: 
            if (_j_7962 > _4194){
                goto L2E; // [955] 1080
            }

            /** 				sequence read_name = list[j][D_NAME]*/
            _2 = (int)SEQ_PTR(_list_7940);
            _4195 = (int)*(((s1_ptr)_2)->base + _j_7962);
            DeRef(_read_name_7964);
            _2 = (int)SEQ_PTR(_4195);
            _read_name_7964 = (int)*(((s1_ptr)_2)->base + 1);
            Ref(_read_name_7964);
            _4195 = NOVALUE;

            /** 				if equal(read_name, supplied_name) then*/
            if (_read_name_7964 == _supplied_name_7945)
            _4197 = 1;
            else if (IS_ATOM_INT(_read_name_7964) && IS_ATOM_INT(_supplied_name_7945))
            _4197 = 0;
            else
            _4197 = (compare(_read_name_7964, _supplied_name_7945) == 0);
            if (_4197 == 0)
            {
                _4197 = NOVALUE;
                goto L2F; // [980] 1071
            }
            else{
                _4197 = NOVALUE;
            }

            /** 					if short_name and sequence(list[j][D_ALTNAME]) then*/
            if (_short_name_7914 == 0) {
                goto L30; // [985] 1062
            }
            _2 = (int)SEQ_PTR(_list_7940);
            _4199 = (int)*(((s1_ptr)_2)->base + _j_7962);
            _2 = (int)SEQ_PTR(_4199);
            _4200 = (int)*(((s1_ptr)_2)->base + 11);
            _4199 = NOVALUE;
            _4201 = IS_SEQUENCE(_4200);
            _4200 = NOVALUE;
            if (_4201 == 0)
            {
                _4201 = NOVALUE;
                goto L30; // [1001] 1062
            }
            else{
                _4201 = NOVALUE;
            }

            /** 						lPath = lPath[1..sl[i]] & list[j][D_ALTNAME] & lPath[sl[i+1]..$]*/
            _2 = (int)SEQ_PTR(_sl_7911);
            _4202 = (int)*(((s1_ptr)_2)->base + _i_7932);
            rhs_slice_target = (object_ptr)&_4203;
            RHS_Slice(_lPath_7765, 1, _4202);
            _2 = (int)SEQ_PTR(_list_7940);
            _4204 = (int)*(((s1_ptr)_2)->base + _j_7962);
            _2 = (int)SEQ_PTR(_4204);
            _4205 = (int)*(((s1_ptr)_2)->base + 11);
            _4204 = NOVALUE;
            _4206 = _i_7932 + 1;
            _2 = (int)SEQ_PTR(_sl_7911);
            _4207 = (int)*(((s1_ptr)_2)->base + _4206);
            if (IS_SEQUENCE(_lPath_7765)){
                    _4208 = SEQ_PTR(_lPath_7765)->length;
            }
            else {
                _4208 = 1;
            }
            rhs_slice_target = (object_ptr)&_4209;
            RHS_Slice(_lPath_7765, _4207, _4208);
            {
                int concat_list[3];

                concat_list[0] = _4209;
                concat_list[1] = _4205;
                concat_list[2] = _4203;
                Concat_N((object_ptr)&_lPath_7765, concat_list, 3);
            }
            DeRefDS(_4209);
            _4209 = NOVALUE;
            _4205 = NOVALUE;
            DeRefDS(_4203);
            _4203 = NOVALUE;

            /** 						sl[$] = length(lPath)+1*/
            if (IS_SEQUENCE(_sl_7911)){
                    _4211 = SEQ_PTR(_sl_7911)->length;
            }
            else {
                _4211 = 1;
            }
            if (IS_SEQUENCE(_lPath_7765)){
                    _4212 = SEQ_PTR(_lPath_7765)->length;
            }
            else {
                _4212 = 1;
            }
            _4213 = _4212 + 1;
            _4212 = NOVALUE;
            _2 = (int)SEQ_PTR(_sl_7911);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _sl_7911 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _4211);
            _1 = *(int *)_2;
            *(int *)_2 = _4213;
            if( _1 != _4213 ){
                DeRef(_1);
            }
            _4213 = NOVALUE;
L30: 

            /** 					continue "partloop"*/
            DeRef(_read_name_7964);
            _read_name_7964 = NOVALUE;
            DeRef(_part_7936);
            _part_7936 = NOVALUE;
            DeRef(_list_7940);
            _list_7940 = NOVALUE;
            DeRef(_supplied_name_7945);
            _supplied_name_7945 = NOVALUE;
            goto L2C; // [1068] 1312
L2F: 
            DeRef(_read_name_7964);
            _read_name_7964 = NOVALUE;

            /** 			end for*/
            _j_7962 = _j_7962 + 1;
            goto L2D; // [1075] 962
L2E: 
            ;
        }

        /** 			for j = 1 to length(list) do*/
        if (IS_SEQUENCE(_list_7940)){
                _4214 = SEQ_PTR(_list_7940)->length;
        }
        else {
            _4214 = 1;
        }
        {
            int _j_7987;
            _j_7987 = 1;
L31: 
            if (_j_7987 > _4214){
                goto L32; // [1085] 1257
            }

            /** 				sequence read_name = list[j][D_NAME]*/
            _2 = (int)SEQ_PTR(_list_7940);
            _4215 = (int)*(((s1_ptr)_2)->base + _j_7987);
            DeRef(_read_name_7989);
            _2 = (int)SEQ_PTR(_4215);
            _read_name_7989 = (int)*(((s1_ptr)_2)->base + 1);
            Ref(_read_name_7989);
            _4215 = NOVALUE;

            /** 				if equal(lower(read_name), lower(supplied_name)) then*/
            RefDS(_read_name_7989);
            _4217 = _12lower(_read_name_7989);
            RefDS(_supplied_name_7945);
            _4218 = _12lower(_supplied_name_7945);
            if (_4217 == _4218)
            _4219 = 1;
            else if (IS_ATOM_INT(_4217) && IS_ATOM_INT(_4218))
            _4219 = 0;
            else
            _4219 = (compare(_4217, _4218) == 0);
            DeRef(_4217);
            _4217 = NOVALUE;
            DeRef(_4218);
            _4218 = NOVALUE;
            if (_4219 == 0)
            {
                _4219 = NOVALUE;
                goto L33; // [1118] 1248
            }
            else{
                _4219 = NOVALUE;
            }

            /** 					if short_name and sequence(list[j][D_ALTNAME]) then*/
            if (_short_name_7914 == 0) {
                goto L34; // [1123] 1200
            }
            _2 = (int)SEQ_PTR(_list_7940);
            _4221 = (int)*(((s1_ptr)_2)->base + _j_7987);
            _2 = (int)SEQ_PTR(_4221);
            _4222 = (int)*(((s1_ptr)_2)->base + 11);
            _4221 = NOVALUE;
            _4223 = IS_SEQUENCE(_4222);
            _4222 = NOVALUE;
            if (_4223 == 0)
            {
                _4223 = NOVALUE;
                goto L34; // [1139] 1200
            }
            else{
                _4223 = NOVALUE;
            }

            /** 						lPath = lPath[1..sl[i]] & list[j][D_ALTNAME] & lPath[sl[i+1]..$]*/
            _2 = (int)SEQ_PTR(_sl_7911);
            _4224 = (int)*(((s1_ptr)_2)->base + _i_7932);
            rhs_slice_target = (object_ptr)&_4225;
            RHS_Slice(_lPath_7765, 1, _4224);
            _2 = (int)SEQ_PTR(_list_7940);
            _4226 = (int)*(((s1_ptr)_2)->base + _j_7987);
            _2 = (int)SEQ_PTR(_4226);
            _4227 = (int)*(((s1_ptr)_2)->base + 11);
            _4226 = NOVALUE;
            _4228 = _i_7932 + 1;
            _2 = (int)SEQ_PTR(_sl_7911);
            _4229 = (int)*(((s1_ptr)_2)->base + _4228);
            if (IS_SEQUENCE(_lPath_7765)){
                    _4230 = SEQ_PTR(_lPath_7765)->length;
            }
            else {
                _4230 = 1;
            }
            rhs_slice_target = (object_ptr)&_4231;
            RHS_Slice(_lPath_7765, _4229, _4230);
            {
                int concat_list[3];

                concat_list[0] = _4231;
                concat_list[1] = _4227;
                concat_list[2] = _4225;
                Concat_N((object_ptr)&_lPath_7765, concat_list, 3);
            }
            DeRefDS(_4231);
            _4231 = NOVALUE;
            _4227 = NOVALUE;
            DeRefDS(_4225);
            _4225 = NOVALUE;

            /** 						sl[$] = length(lPath)+1*/
            if (IS_SEQUENCE(_sl_7911)){
                    _4233 = SEQ_PTR(_sl_7911)->length;
            }
            else {
                _4233 = 1;
            }
            if (IS_SEQUENCE(_lPath_7765)){
                    _4234 = SEQ_PTR(_lPath_7765)->length;
            }
            else {
                _4234 = 1;
            }
            _4235 = _4234 + 1;
            _4234 = NOVALUE;
            _2 = (int)SEQ_PTR(_sl_7911);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _sl_7911 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _4233);
            _1 = *(int *)_2;
            *(int *)_2 = _4235;
            if( _1 != _4235 ){
                DeRef(_1);
            }
            _4235 = NOVALUE;
L34: 

            /** 					if correct_name then*/
            if (_correct_name_7917 == 0)
            {
                goto L35; // [1202] 1239
            }
            else{
            }

            /** 						lPath = lPath[1..sl[i]] & read_name & lPath[sl[i+1]..$]*/
            _2 = (int)SEQ_PTR(_sl_7911);
            _4236 = (int)*(((s1_ptr)_2)->base + _i_7932);
            rhs_slice_target = (object_ptr)&_4237;
            RHS_Slice(_lPath_7765, 1, _4236);
            _4238 = _i_7932 + 1;
            _2 = (int)SEQ_PTR(_sl_7911);
            _4239 = (int)*(((s1_ptr)_2)->base + _4238);
            if (IS_SEQUENCE(_lPath_7765)){
                    _4240 = SEQ_PTR(_lPath_7765)->length;
            }
            else {
                _4240 = 1;
            }
            rhs_slice_target = (object_ptr)&_4241;
            RHS_Slice(_lPath_7765, _4239, _4240);
            {
                int concat_list[3];

                concat_list[0] = _4241;
                concat_list[1] = _read_name_7989;
                concat_list[2] = _4237;
                Concat_N((object_ptr)&_lPath_7765, concat_list, 3);
            }
            DeRefDS(_4241);
            _4241 = NOVALUE;
            DeRefDS(_4237);
            _4237 = NOVALUE;
L35: 

            /** 					continue "partloop"*/
            DeRef(_read_name_7989);
            _read_name_7989 = NOVALUE;
            DeRef(_part_7936);
            _part_7936 = NOVALUE;
            DeRef(_list_7940);
            _list_7940 = NOVALUE;
            DeRef(_supplied_name_7945);
            _supplied_name_7945 = NOVALUE;
            goto L2C; // [1245] 1312
L33: 
            DeRef(_read_name_7989);
            _read_name_7989 = NOVALUE;

            /** 			end for*/
            _j_7987 = _j_7987 + 1;
            goto L31; // [1252] 1092
L32: 
            ;
        }

        /** 			if and_bits(TO_LOWER,case_flags) then*/
        {unsigned long tu;
             tu = (unsigned long)1 & (unsigned long)_case_flags_7764;
             _4243 = MAKE_UINT(tu);
        }
        if (_4243 == 0) {
            DeRef(_4243);
            _4243 = NOVALUE;
            goto L36; // [1263] 1302
        }
        else {
            if (!IS_ATOM_INT(_4243) && DBL_PTR(_4243)->dbl == 0.0){
                DeRef(_4243);
                _4243 = NOVALUE;
                goto L36; // [1263] 1302
            }
            DeRef(_4243);
            _4243 = NOVALUE;
        }
        DeRef(_4243);
        _4243 = NOVALUE;

        /** 				lPath = lPath[1..sl[i]-1] & lower(lPath[sl[i]..$])*/
        _2 = (int)SEQ_PTR(_sl_7911);
        _4244 = (int)*(((s1_ptr)_2)->base + _i_7932);
        if (IS_ATOM_INT(_4244)) {
            _4245 = _4244 - 1;
        }
        else {
            _4245 = binary_op(MINUS, _4244, 1);
        }
        _4244 = NOVALUE;
        rhs_slice_target = (object_ptr)&_4246;
        RHS_Slice(_lPath_7765, 1, _4245);
        _2 = (int)SEQ_PTR(_sl_7911);
        _4247 = (int)*(((s1_ptr)_2)->base + _i_7932);
        if (IS_SEQUENCE(_lPath_7765)){
                _4248 = SEQ_PTR(_lPath_7765)->length;
        }
        else {
            _4248 = 1;
        }
        rhs_slice_target = (object_ptr)&_4249;
        RHS_Slice(_lPath_7765, _4247, _4248);
        _4250 = _12lower(_4249);
        _4249 = NOVALUE;
        if (IS_SEQUENCE(_4246) && IS_ATOM(_4250)) {
            Ref(_4250);
            Append(&_lPath_7765, _4246, _4250);
        }
        else if (IS_ATOM(_4246) && IS_SEQUENCE(_4250)) {
        }
        else {
            Concat((object_ptr)&_lPath_7765, _4246, _4250);
            DeRefDS(_4246);
            _4246 = NOVALUE;
        }
        DeRef(_4246);
        _4246 = NOVALUE;
        DeRef(_4250);
        _4250 = NOVALUE;
L36: 

        /** 			exit*/
        DeRef(_part_7936);
        _part_7936 = NOVALUE;
        DeRef(_list_7940);
        _list_7940 = NOVALUE;
        DeRef(_supplied_name_7945);
        _supplied_name_7945 = NOVALUE;
        goto L29; // [1306] 1317

        /** 		end for*/
L2C: 
        _i_7932 = _i_7932 + -1;
        goto L28; // [1312] 843
L29: 
        ;
    }

    /** 		if and_bits(case_flags,or_bits(CORRECT,TO_LOWER))=TO_LOWER and length(lPath) then*/
    {unsigned long tu;
         tu = (unsigned long)2 | (unsigned long)1;
         _4252 = MAKE_UINT(tu);
    }
    if (IS_ATOM_INT(_4252)) {
        {unsigned long tu;
             tu = (unsigned long)_case_flags_7764 & (unsigned long)_4252;
             _4253 = MAKE_UINT(tu);
        }
    }
    else {
        temp_d.dbl = (double)_case_flags_7764;
        _4253 = Dand_bits(&temp_d, DBL_PTR(_4252));
    }
    DeRef(_4252);
    _4252 = NOVALUE;
    if (IS_ATOM_INT(_4253)) {
        _4254 = (_4253 == 1);
    }
    else {
        _4254 = (DBL_PTR(_4253)->dbl == (double)1);
    }
    DeRef(_4253);
    _4253 = NOVALUE;
    if (_4254 == 0) {
        goto L37; // [1331] 1351
    }
    if (IS_SEQUENCE(_lPath_7765)){
            _4256 = SEQ_PTR(_lPath_7765)->length;
    }
    else {
        _4256 = 1;
    }
    if (_4256 == 0)
    {
        _4256 = NOVALUE;
        goto L37; // [1339] 1351
    }
    else{
        _4256 = NOVALUE;
    }

    /** 			lPath = lower(lPath)*/
    RefDS(_lPath_7765);
    _0 = _lPath_7765;
    _lPath_7765 = _12lower(_lPath_7765);
    DeRefDS(_0);
L37: 
L26: 
    DeRef(_sl_7911);
    _sl_7911 = NOVALUE;
L25: 

    /** 	ifdef WINDOWS then*/

    /** 		if and_bits(CORRECT,case_flags) then*/
    {unsigned long tu;
         tu = (unsigned long)2 & (unsigned long)_case_flags_7764;
         _4258 = MAKE_UINT(tu);
    }
    if (_4258 == 0) {
        DeRef(_4258);
        _4258 = NOVALUE;
        goto L38; // [1363] 1405
    }
    else {
        if (!IS_ATOM_INT(_4258) && DBL_PTR(_4258)->dbl == 0.0){
            DeRef(_4258);
            _4258 = NOVALUE;
            goto L38; // [1363] 1405
        }
        DeRef(_4258);
        _4258 = NOVALUE;
    }
    DeRef(_4258);
    _4258 = NOVALUE;

    /** 			if or_bits(system_drive_case,'A') = 'a' then*/
    if (IS_ATOM_INT(_15system_drive_case_7748)) {
        {unsigned long tu;
             tu = (unsigned long)_15system_drive_case_7748 | (unsigned long)65;
             _4259 = MAKE_UINT(tu);
        }
    }
    else {
        temp_d.dbl = (double)65;
        _4259 = Dor_bits(DBL_PTR(_15system_drive_case_7748), &temp_d);
    }
    if (binary_op_a(NOTEQ, _4259, 97)){
        DeRef(_4259);
        _4259 = NOVALUE;
        goto L39; // [1374] 1391
    }
    DeRef(_4259);
    _4259 = NOVALUE;

    /** 				lDrive = lower(lDrive)*/
    RefDS(_lDrive_7770);
    _0 = _lDrive_7770;
    _lDrive_7770 = _12lower(_lDrive_7770);
    DeRefDS(_0);
    goto L3A; // [1388] 1426
L39: 

    /** 				lDrive = upper(lDrive)*/
    RefDS(_lDrive_7770);
    _0 = _lDrive_7770;
    _lDrive_7770 = _12upper(_lDrive_7770);
    DeRefDS(_0);
    goto L3A; // [1402] 1426
L38: 

    /** 		elsif and_bits(TO_LOWER,case_flags) then*/
    {unsigned long tu;
         tu = (unsigned long)1 & (unsigned long)_case_flags_7764;
         _4263 = MAKE_UINT(tu);
    }
    if (_4263 == 0) {
        DeRef(_4263);
        _4263 = NOVALUE;
        goto L3B; // [1411] 1425
    }
    else {
        if (!IS_ATOM_INT(_4263) && DBL_PTR(_4263)->dbl == 0.0){
            DeRef(_4263);
            _4263 = NOVALUE;
            goto L3B; // [1411] 1425
        }
        DeRef(_4263);
        _4263 = NOVALUE;
    }
    DeRef(_4263);
    _4263 = NOVALUE;

    /** 			lDrive = lower(lDrive)*/
    RefDS(_lDrive_7770);
    _0 = _lDrive_7770;
    _lDrive_7770 = _12lower(_lDrive_7770);
    DeRefDS(_0);
L3B: 
L3A: 

    /** 		lPath = lDrive & lPath*/
    Concat((object_ptr)&_lPath_7765, _lDrive_7770, _lPath_7765);

    /** 	return lPath & wildcard_suffix*/
    Concat((object_ptr)&_4266, _lPath_7765, _wildcard_suffix_7835);
    DeRefDS(_path_in_7762);
    DeRefDS(_lPath_7765);
    DeRefi(_lLevel_7768);
    DeRef(_lHome_7769);
    DeRefDS(_lDrive_7770);
    DeRefDS(_wildcard_suffix_7835);
    DeRef(_4064);
    _4064 = NOVALUE;
    DeRef(_4183);
    _4183 = NOVALUE;
    DeRef(_4072);
    _4072 = NOVALUE;
    DeRef(_4057);
    _4057 = NOVALUE;
    DeRef(_4149);
    _4149 = NOVALUE;
    DeRef(_4152);
    _4152 = NOVALUE;
    DeRef(_4066);
    _4066 = NOVALUE;
    _4229 = NOVALUE;
    DeRef(_4069);
    _4069 = NOVALUE;
    DeRef(_4129);
    _4129 = NOVALUE;
    DeRef(_4228);
    _4228 = NOVALUE;
    _4236 = NOVALUE;
    DeRef(_4135);
    _4135 = NOVALUE;
    DeRef(_4176);
    _4176 = NOVALUE;
    _4207 = NOVALUE;
    DeRef(_4238);
    _4238 = NOVALUE;
    DeRef(_4100);
    _4100 = NOVALUE;
    DeRef(_4206);
    _4206 = NOVALUE;
    DeRef(_4112);
    _4112 = NOVALUE;
    DeRef(_4117);
    _4117 = NOVALUE;
    DeRef(_4139);
    _4139 = NOVALUE;
    _4247 = NOVALUE;
    _4224 = NOVALUE;
    _4239 = NOVALUE;
    DeRef(_4179);
    _4179 = NOVALUE;
    _4189 = NOVALUE;
    DeRef(_4254);
    _4254 = NOVALUE;
    DeRef(_4097);
    _4097 = NOVALUE;
    _4202 = NOVALUE;
    DeRef(_4245);
    _4245 = NOVALUE;
    DeRef(_4086);
    _4086 = NOVALUE;
    DeRef(_4126);
    _4126 = NOVALUE;
    DeRef(_4186);
    _4186 = NOVALUE;
    DeRef(_4184);
    _4184 = NOVALUE;
    DeRef(_4060);
    _4060 = NOVALUE;
    return _4266;
    ;
}


int _15fs_case(int _s_8060)
{
    int _4267 = NOVALUE;
    int _0, _1, _2;
    

    /** 	ifdef WINDOWS then*/

    /** 		return lower(s)*/
    RefDS(_s_8060);
    _4267 = _12lower(_s_8060);
    DeRefDS(_s_8060);
    return _4267;
    ;
}


int _15abbreviate_path(int _orig_path_8065, int _base_paths_8066)
{
    int _expanded_path_8067 = NOVALUE;
    int _lowered_expanded_path_8077 = NOVALUE;
    int _4312 = NOVALUE;
    int _4311 = NOVALUE;
    int _4308 = NOVALUE;
    int _4307 = NOVALUE;
    int _4306 = NOVALUE;
    int _4305 = NOVALUE;
    int _4304 = NOVALUE;
    int _4302 = NOVALUE;
    int _4301 = NOVALUE;
    int _4300 = NOVALUE;
    int _4299 = NOVALUE;
    int _4298 = NOVALUE;
    int _4297 = NOVALUE;
    int _4296 = NOVALUE;
    int _4295 = NOVALUE;
    int _4294 = NOVALUE;
    int _4291 = NOVALUE;
    int _4290 = NOVALUE;
    int _4288 = NOVALUE;
    int _4287 = NOVALUE;
    int _4286 = NOVALUE;
    int _4285 = NOVALUE;
    int _4284 = NOVALUE;
    int _4283 = NOVALUE;
    int _4282 = NOVALUE;
    int _4281 = NOVALUE;
    int _4280 = NOVALUE;
    int _4279 = NOVALUE;
    int _4278 = NOVALUE;
    int _4277 = NOVALUE;
    int _4276 = NOVALUE;
    int _4273 = NOVALUE;
    int _4272 = NOVALUE;
    int _4271 = NOVALUE;
    int _4269 = NOVALUE;
    int _0, _1, _2;
    

    /** 	expanded_path = canonical_path(orig_path)*/
    RefDS(_orig_path_8065);
    _0 = _expanded_path_8067;
    _expanded_path_8067 = _15canonical_path(_orig_path_8065, 0, 0);
    DeRef(_0);

    /** 	base_paths = append(base_paths, curdir())*/
    _4269 = _15curdir(0);
    Ref(_4269);
    Append(&_base_paths_8066, _base_paths_8066, _4269);
    DeRef(_4269);
    _4269 = NOVALUE;

    /** 	for i = 1 to length(base_paths) do*/
    _4271 = 1;
    {
        int _i_8072;
        _i_8072 = 1;
L1: 
        if (_i_8072 > 1){
            goto L2; // [30] 60
        }

        /** 		base_paths[i] = canonical_path(base_paths[i], 1) -- assume each base path is meant to be a directory.*/
        _2 = (int)SEQ_PTR(_base_paths_8066);
        _4272 = (int)*(((s1_ptr)_2)->base + 1);
        Ref(_4272);
        _4273 = _15canonical_path(_4272, 1, 0);
        _4272 = NOVALUE;
        _2 = (int)SEQ_PTR(_base_paths_8066);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _base_paths_8066 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 1);
        _1 = *(int *)_2;
        *(int *)_2 = _4273;
        if( _1 != _4273 ){
            DeRef(_1);
        }
        _4273 = NOVALUE;

        /** 	end for*/
        _i_8072 = 1 + 1;
        goto L1; // [55] 37
L2: 
        ;
    }

    /** 	base_paths = fs_case(base_paths)*/
    RefDS(_base_paths_8066);
    _0 = _base_paths_8066;
    _base_paths_8066 = _15fs_case(_base_paths_8066);
    DeRefDS(_0);

    /** 	sequence lowered_expanded_path = fs_case(expanded_path)*/
    RefDS(_expanded_path_8067);
    _0 = _lowered_expanded_path_8077;
    _lowered_expanded_path_8077 = _15fs_case(_expanded_path_8067);
    DeRef(_0);

    /** 	for i = 1 to length(base_paths) do*/
    if (IS_SEQUENCE(_base_paths_8066)){
            _4276 = SEQ_PTR(_base_paths_8066)->length;
    }
    else {
        _4276 = 1;
    }
    {
        int _i_8080;
        _i_8080 = 1;
L3: 
        if (_i_8080 > _4276){
            goto L4; // [81] 135
        }

        /** 		if search:begins(base_paths[i], lowered_expanded_path) then*/
        _2 = (int)SEQ_PTR(_base_paths_8066);
        _4277 = (int)*(((s1_ptr)_2)->base + _i_8080);
        Ref(_4277);
        RefDS(_lowered_expanded_path_8077);
        _4278 = _14begins(_4277, _lowered_expanded_path_8077);
        _4277 = NOVALUE;
        if (_4278 == 0) {
            DeRef(_4278);
            _4278 = NOVALUE;
            goto L5; // [99] 128
        }
        else {
            if (!IS_ATOM_INT(_4278) && DBL_PTR(_4278)->dbl == 0.0){
                DeRef(_4278);
                _4278 = NOVALUE;
                goto L5; // [99] 128
            }
            DeRef(_4278);
            _4278 = NOVALUE;
        }
        DeRef(_4278);
        _4278 = NOVALUE;

        /** 			return expanded_path[length(base_paths[i]) + 1 .. $]*/
        _2 = (int)SEQ_PTR(_base_paths_8066);
        _4279 = (int)*(((s1_ptr)_2)->base + _i_8080);
        if (IS_SEQUENCE(_4279)){
                _4280 = SEQ_PTR(_4279)->length;
        }
        else {
            _4280 = 1;
        }
        _4279 = NOVALUE;
        _4281 = _4280 + 1;
        _4280 = NOVALUE;
        if (IS_SEQUENCE(_expanded_path_8067)){
                _4282 = SEQ_PTR(_expanded_path_8067)->length;
        }
        else {
            _4282 = 1;
        }
        rhs_slice_target = (object_ptr)&_4283;
        RHS_Slice(_expanded_path_8067, _4281, _4282);
        DeRefDS(_orig_path_8065);
        DeRefDS(_base_paths_8066);
        DeRefDS(_expanded_path_8067);
        DeRefDS(_lowered_expanded_path_8077);
        _4279 = NOVALUE;
        _4281 = NOVALUE;
        return _4283;
L5: 

        /** 	end for*/
        _i_8080 = _i_8080 + 1;
        goto L3; // [130] 88
L4: 
        ;
    }

    /** 	ifdef WINDOWS then*/

    /** 		if not equal(base_paths[$][1], lowered_expanded_path[1]) then*/
    if (IS_SEQUENCE(_base_paths_8066)){
            _4284 = SEQ_PTR(_base_paths_8066)->length;
    }
    else {
        _4284 = 1;
    }
    _2 = (int)SEQ_PTR(_base_paths_8066);
    _4285 = (int)*(((s1_ptr)_2)->base + _4284);
    _2 = (int)SEQ_PTR(_4285);
    _4286 = (int)*(((s1_ptr)_2)->base + 1);
    _4285 = NOVALUE;
    _2 = (int)SEQ_PTR(_lowered_expanded_path_8077);
    _4287 = (int)*(((s1_ptr)_2)->base + 1);
    if (_4286 == _4287)
    _4288 = 1;
    else if (IS_ATOM_INT(_4286) && IS_ATOM_INT(_4287))
    _4288 = 0;
    else
    _4288 = (compare(_4286, _4287) == 0);
    _4286 = NOVALUE;
    _4287 = NOVALUE;
    if (_4288 != 0)
    goto L6; // [158] 168
    _4288 = NOVALUE;

    /** 			return orig_path*/
    DeRefDS(_base_paths_8066);
    DeRef(_expanded_path_8067);
    DeRefDS(_lowered_expanded_path_8077);
    _4279 = NOVALUE;
    DeRef(_4281);
    _4281 = NOVALUE;
    DeRef(_4283);
    _4283 = NOVALUE;
    return _orig_path_8065;
L6: 

    /** 	base_paths = stdseq:split(base_paths[$], SLASH)*/
    if (IS_SEQUENCE(_base_paths_8066)){
            _4290 = SEQ_PTR(_base_paths_8066)->length;
    }
    else {
        _4290 = 1;
    }
    _2 = (int)SEQ_PTR(_base_paths_8066);
    _4291 = (int)*(((s1_ptr)_2)->base + _4290);
    Ref(_4291);
    _0 = _base_paths_8066;
    _base_paths_8066 = _23split(_4291, 92, 0, 0);
    DeRefDS(_0);
    _4291 = NOVALUE;

    /** 	expanded_path = stdseq:split(expanded_path, SLASH)*/
    RefDS(_expanded_path_8067);
    _0 = _expanded_path_8067;
    _expanded_path_8067 = _23split(_expanded_path_8067, 92, 0, 0);
    DeRefDS(_0);

    /** 	lowered_expanded_path = ""*/
    RefDS(_5);
    DeRef(_lowered_expanded_path_8077);
    _lowered_expanded_path_8077 = _5;

    /** 	for i = 1 to math:min({length(expanded_path), length(base_paths) - 1}) do*/
    if (IS_SEQUENCE(_expanded_path_8067)){
            _4294 = SEQ_PTR(_expanded_path_8067)->length;
    }
    else {
        _4294 = 1;
    }
    if (IS_SEQUENCE(_base_paths_8066)){
            _4295 = SEQ_PTR(_base_paths_8066)->length;
    }
    else {
        _4295 = 1;
    }
    _4296 = _4295 - 1;
    _4295 = NOVALUE;
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _4294;
    ((int *)_2)[2] = _4296;
    _4297 = MAKE_SEQ(_1);
    _4296 = NOVALUE;
    _4294 = NOVALUE;
    _4298 = _20min(_4297);
    _4297 = NOVALUE;
    {
        int _i_8102;
        _i_8102 = 1;
L7: 
        if (binary_op_a(GREATER, _i_8102, _4298)){
            goto L8; // [224] 317
        }

        /** 		if not equal(fs_case(expanded_path[i]), base_paths[i]) then*/
        _2 = (int)SEQ_PTR(_expanded_path_8067);
        if (!IS_ATOM_INT(_i_8102)){
            _4299 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_8102)->dbl));
        }
        else{
            _4299 = (int)*(((s1_ptr)_2)->base + _i_8102);
        }
        Ref(_4299);
        _4300 = _15fs_case(_4299);
        _4299 = NOVALUE;
        _2 = (int)SEQ_PTR(_base_paths_8066);
        if (!IS_ATOM_INT(_i_8102)){
            _4301 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_8102)->dbl));
        }
        else{
            _4301 = (int)*(((s1_ptr)_2)->base + _i_8102);
        }
        if (_4300 == _4301)
        _4302 = 1;
        else if (IS_ATOM_INT(_4300) && IS_ATOM_INT(_4301))
        _4302 = 0;
        else
        _4302 = (compare(_4300, _4301) == 0);
        DeRef(_4300);
        _4300 = NOVALUE;
        _4301 = NOVALUE;
        if (_4302 != 0)
        goto L9; // [249] 310
        _4302 = NOVALUE;

        /** 			expanded_path = repeat("..", length(base_paths) - i) & expanded_path[i .. $]*/
        if (IS_SEQUENCE(_base_paths_8066)){
                _4304 = SEQ_PTR(_base_paths_8066)->length;
        }
        else {
            _4304 = 1;
        }
        if (IS_ATOM_INT(_i_8102)) {
            _4305 = _4304 - _i_8102;
        }
        else {
            _4305 = NewDouble((double)_4304 - DBL_PTR(_i_8102)->dbl);
        }
        _4304 = NOVALUE;
        _4306 = Repeat(_3825, _4305);
        DeRef(_4305);
        _4305 = NOVALUE;
        if (IS_SEQUENCE(_expanded_path_8067)){
                _4307 = SEQ_PTR(_expanded_path_8067)->length;
        }
        else {
            _4307 = 1;
        }
        rhs_slice_target = (object_ptr)&_4308;
        RHS_Slice(_expanded_path_8067, _i_8102, _4307);
        Concat((object_ptr)&_expanded_path_8067, _4306, _4308);
        DeRefDS(_4306);
        _4306 = NOVALUE;
        DeRef(_4306);
        _4306 = NOVALUE;
        DeRefDS(_4308);
        _4308 = NOVALUE;

        /** 			expanded_path = stdseq:join(expanded_path, SLASH)*/
        RefDS(_expanded_path_8067);
        _0 = _expanded_path_8067;
        _expanded_path_8067 = _23join(_expanded_path_8067, 92);
        DeRefDS(_0);

        /** 			if length(expanded_path) < length(orig_path) then*/
        if (IS_SEQUENCE(_expanded_path_8067)){
                _4311 = SEQ_PTR(_expanded_path_8067)->length;
        }
        else {
            _4311 = 1;
        }
        if (IS_SEQUENCE(_orig_path_8065)){
                _4312 = SEQ_PTR(_orig_path_8065)->length;
        }
        else {
            _4312 = 1;
        }
        if (_4311 >= _4312)
        goto L8; // [294] 317

        /** 		  		return expanded_path*/
        DeRef(_i_8102);
        DeRefDS(_orig_path_8065);
        DeRefDS(_base_paths_8066);
        DeRef(_lowered_expanded_path_8077);
        _4279 = NOVALUE;
        DeRef(_4281);
        _4281 = NOVALUE;
        DeRef(_4283);
        _4283 = NOVALUE;
        DeRef(_4298);
        _4298 = NOVALUE;
        return _expanded_path_8067;

        /** 			exit*/
        goto L8; // [307] 317
L9: 

        /** 	end for*/
        _0 = _i_8102;
        if (IS_ATOM_INT(_i_8102)) {
            _i_8102 = _i_8102 + 1;
            if ((long)((unsigned long)_i_8102 +(unsigned long) HIGH_BITS) >= 0){
                _i_8102 = NewDouble((double)_i_8102);
            }
        }
        else {
            _i_8102 = binary_op_a(PLUS, _i_8102, 1);
        }
        DeRef(_0);
        goto L7; // [312] 231
L8: 
        ;
        DeRef(_i_8102);
    }

    /** 	return orig_path*/
    DeRefDS(_base_paths_8066);
    DeRef(_expanded_path_8067);
    DeRef(_lowered_expanded_path_8077);
    _4279 = NOVALUE;
    DeRef(_4281);
    _4281 = NOVALUE;
    DeRef(_4283);
    _4283 = NOVALUE;
    DeRef(_4298);
    _4298 = NOVALUE;
    return _orig_path_8065;
    ;
}


int _15file_type(int _filename_8162)
{
    int _dirfil_8163 = NOVALUE;
    int _dir_inlined_dir_at_64_8176 = NOVALUE;
    int _4353 = NOVALUE;
    int _4352 = NOVALUE;
    int _4351 = NOVALUE;
    int _4350 = NOVALUE;
    int _4349 = NOVALUE;
    int _4347 = NOVALUE;
    int _4346 = NOVALUE;
    int _4345 = NOVALUE;
    int _4344 = NOVALUE;
    int _4343 = NOVALUE;
    int _4342 = NOVALUE;
    int _4341 = NOVALUE;
    int _4339 = NOVALUE;
    int _4338 = NOVALUE;
    int _4337 = NOVALUE;
    int _4336 = NOVALUE;
    int _4335 = NOVALUE;
    int _4334 = NOVALUE;
    int _4332 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if eu:find('*', filename) or eu:find('?', filename) then return FILETYPE_UNDEFINED end if*/
    _4332 = find_from(42, _filename_8162, 1);
    if (_4332 != 0) {
        goto L1; // [10] 24
    }
    _4334 = find_from(63, _filename_8162, 1);
    if (_4334 == 0)
    {
        _4334 = NOVALUE;
        goto L2; // [20] 29
    }
    else{
        _4334 = NOVALUE;
    }
L1: 
    DeRefDS(_filename_8162);
    DeRef(_dirfil_8163);
    return -1;
L2: 

    /** 	ifdef WINDOWS then*/

    /** 		if length(filename) = 2 and filename[2] = ':' then*/
    if (IS_SEQUENCE(_filename_8162)){
            _4335 = SEQ_PTR(_filename_8162)->length;
    }
    else {
        _4335 = 1;
    }
    _4336 = (_4335 == 2);
    _4335 = NOVALUE;
    if (_4336 == 0) {
        goto L3; // [40] 63
    }
    _2 = (int)SEQ_PTR(_filename_8162);
    _4338 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_4338)) {
        _4339 = (_4338 == 58);
    }
    else {
        _4339 = binary_op(EQUALS, _4338, 58);
    }
    _4338 = NOVALUE;
    if (_4339 == 0) {
        DeRef(_4339);
        _4339 = NOVALUE;
        goto L3; // [53] 63
    }
    else {
        if (!IS_ATOM_INT(_4339) && DBL_PTR(_4339)->dbl == 0.0){
            DeRef(_4339);
            _4339 = NOVALUE;
            goto L3; // [53] 63
        }
        DeRef(_4339);
        _4339 = NOVALUE;
    }
    DeRef(_4339);
    _4339 = NOVALUE;

    /** 			filename &= "\\"*/
    Concat((object_ptr)&_filename_8162, _filename_8162, _1177);
L3: 

    /** 	dirfil = dir(filename)*/

    /** 	ifdef WINDOWS then*/

    /** 		return machine_func(M_DIR, name)*/
    DeRef(_dirfil_8163);
    _dirfil_8163 = machine(22, _filename_8162);

    /** 	if sequence(dirfil) then*/
    _4341 = IS_SEQUENCE(_dirfil_8163);
    if (_4341 == 0)
    {
        _4341 = NOVALUE;
        goto L4; // [79] 163
    }
    else{
        _4341 = NOVALUE;
    }

    /** 		if length( dirfil ) > 1 or eu:find('d', dirfil[1][2]) or (length(filename)=3 and filename[2]=':') then*/
    if (IS_SEQUENCE(_dirfil_8163)){
            _4342 = SEQ_PTR(_dirfil_8163)->length;
    }
    else {
        _4342 = 1;
    }
    _4343 = (_4342 > 1);
    _4342 = NOVALUE;
    if (_4343 != 0) {
        _4344 = 1;
        goto L5; // [91] 112
    }
    _2 = (int)SEQ_PTR(_dirfil_8163);
    _4345 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_4345);
    _4346 = (int)*(((s1_ptr)_2)->base + 2);
    _4345 = NOVALUE;
    _4347 = find_from(100, _4346, 1);
    _4346 = NOVALUE;
    _4344 = (_4347 != 0);
L5: 
    if (_4344 != 0) {
        goto L6; // [112] 144
    }
    if (IS_SEQUENCE(_filename_8162)){
            _4349 = SEQ_PTR(_filename_8162)->length;
    }
    else {
        _4349 = 1;
    }
    _4350 = (_4349 == 3);
    _4349 = NOVALUE;
    if (_4350 == 0) {
        DeRef(_4351);
        _4351 = 0;
        goto L7; // [123] 139
    }
    _2 = (int)SEQ_PTR(_filename_8162);
    _4352 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_4352)) {
        _4353 = (_4352 == 58);
    }
    else {
        _4353 = binary_op(EQUALS, _4352, 58);
    }
    _4352 = NOVALUE;
    if (IS_ATOM_INT(_4353))
    _4351 = (_4353 != 0);
    else
    _4351 = DBL_PTR(_4353)->dbl != 0.0;
L7: 
    if (_4351 == 0)
    {
        _4351 = NOVALUE;
        goto L8; // [140] 153
    }
    else{
        _4351 = NOVALUE;
    }
L6: 

    /** 			return FILETYPE_DIRECTORY*/
    DeRefDS(_filename_8162);
    DeRef(_dirfil_8163);
    DeRef(_4336);
    _4336 = NOVALUE;
    DeRef(_4343);
    _4343 = NOVALUE;
    DeRef(_4350);
    _4350 = NOVALUE;
    DeRef(_4353);
    _4353 = NOVALUE;
    return 2;
    goto L9; // [150] 170
L8: 

    /** 			return FILETYPE_FILE*/
    DeRefDS(_filename_8162);
    DeRef(_dirfil_8163);
    DeRef(_4336);
    _4336 = NOVALUE;
    DeRef(_4343);
    _4343 = NOVALUE;
    DeRef(_4350);
    _4350 = NOVALUE;
    DeRef(_4353);
    _4353 = NOVALUE;
    return 1;
    goto L9; // [160] 170
L4: 

    /** 		return FILETYPE_NOT_FOUND*/
    DeRefDS(_filename_8162);
    DeRef(_dirfil_8163);
    DeRef(_4336);
    _4336 = NOVALUE;
    DeRef(_4343);
    _4343 = NOVALUE;
    DeRef(_4350);
    _4350 = NOVALUE;
    DeRef(_4353);
    _4353 = NOVALUE;
    return 0;
L9: 
    ;
}


int _15file_exists(int _name_8210)
{
    int _pName_8213 = NOVALUE;
    int _r_8216 = NOVALUE;
    int _4358 = NOVALUE;
    int _4356 = NOVALUE;
    int _4354 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(name) then*/
    _4354 = IS_ATOM(_name_8210);
    if (_4354 == 0)
    {
        _4354 = NOVALUE;
        goto L1; // [6] 16
    }
    else{
        _4354 = NOVALUE;
    }

    /** 		return 0*/
    DeRef(_name_8210);
    DeRef(_pName_8213);
    DeRef(_r_8216);
    return 0;
L1: 

    /** 	ifdef WINDOWS then*/

    /** 		atom pName = allocate_string(name)*/
    Ref(_name_8210);
    _0 = _pName_8213;
    _pName_8213 = _6allocate_string(_name_8210, 0);
    DeRef(_0);

    /** 		atom r = c_func(xGetFileAttributes, {pName})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_pName_8213);
    *((int *)(_2+4)) = _pName_8213;
    _4356 = MAKE_SEQ(_1);
    DeRef(_r_8216);
    _r_8216 = call_c(1, _15xGetFileAttributes_7216, _4356);
    DeRefDS(_4356);
    _4356 = NOVALUE;

    /** 		free(pName)*/
    Ref(_pName_8213);
    _6free(_pName_8213);

    /** 		return r > 0*/
    if (IS_ATOM_INT(_r_8216)) {
        _4358 = (_r_8216 > 0);
    }
    else {
        _4358 = (DBL_PTR(_r_8216)->dbl > (double)0);
    }
    DeRef(_name_8210);
    DeRef(_pName_8213);
    DeRef(_r_8216);
    return _4358;
    ;
}


int _15file_timestamp(int _fname_8223)
{
    int _d_8224 = NOVALUE;
    int _dir_inlined_dir_at_4_8226 = NOVALUE;
    int _4372 = NOVALUE;
    int _4371 = NOVALUE;
    int _4370 = NOVALUE;
    int _4369 = NOVALUE;
    int _4368 = NOVALUE;
    int _4367 = NOVALUE;
    int _4366 = NOVALUE;
    int _4365 = NOVALUE;
    int _4364 = NOVALUE;
    int _4363 = NOVALUE;
    int _4362 = NOVALUE;
    int _4361 = NOVALUE;
    int _4360 = NOVALUE;
    int _4359 = NOVALUE;
    int _0, _1, _2;
    

    /** 	object d = dir(fname)*/

    /** 	ifdef WINDOWS then*/

    /** 		return machine_func(M_DIR, name)*/
    DeRef(_d_8224);
    _d_8224 = machine(22, _fname_8223);

    /** 	if atom(d) then return -1 end if*/
    _4359 = IS_ATOM(_d_8224);
    if (_4359 == 0)
    {
        _4359 = NOVALUE;
        goto L1; // [19] 27
    }
    else{
        _4359 = NOVALUE;
    }
    DeRefDS(_fname_8223);
    DeRef(_d_8224);
    return -1;
L1: 

    /** 	return datetime:new(d[1][D_YEAR], d[1][D_MONTH], d[1][D_DAY],*/
    _2 = (int)SEQ_PTR(_d_8224);
    _4360 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_4360);
    _4361 = (int)*(((s1_ptr)_2)->base + 4);
    _4360 = NOVALUE;
    _2 = (int)SEQ_PTR(_d_8224);
    _4362 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_4362);
    _4363 = (int)*(((s1_ptr)_2)->base + 5);
    _4362 = NOVALUE;
    _2 = (int)SEQ_PTR(_d_8224);
    _4364 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_4364);
    _4365 = (int)*(((s1_ptr)_2)->base + 6);
    _4364 = NOVALUE;
    _2 = (int)SEQ_PTR(_d_8224);
    _4366 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_4366);
    _4367 = (int)*(((s1_ptr)_2)->base + 7);
    _4366 = NOVALUE;
    _2 = (int)SEQ_PTR(_d_8224);
    _4368 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_4368);
    _4369 = (int)*(((s1_ptr)_2)->base + 8);
    _4368 = NOVALUE;
    _2 = (int)SEQ_PTR(_d_8224);
    _4370 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_4370);
    _4371 = (int)*(((s1_ptr)_2)->base + 9);
    _4370 = NOVALUE;
    Ref(_4361);
    Ref(_4363);
    Ref(_4365);
    Ref(_4367);
    Ref(_4369);
    Ref(_4371);
    _4372 = _16new(_4361, _4363, _4365, _4367, _4369, _4371);
    _4361 = NOVALUE;
    _4363 = NOVALUE;
    _4365 = NOVALUE;
    _4367 = NOVALUE;
    _4369 = NOVALUE;
    _4371 = NOVALUE;
    DeRefDS(_fname_8223);
    DeRef(_d_8224);
    return _4372;
    ;
}


int _15locate_file(int _filename_8354, int _search_list_8355, int _subdir_8356)
{
    int _extra_paths_8357 = NOVALUE;
    int _this_path_8358 = NOVALUE;
    int _4507 = NOVALUE;
    int _4506 = NOVALUE;
    int _4504 = NOVALUE;
    int _4502 = NOVALUE;
    int _4500 = NOVALUE;
    int _4499 = NOVALUE;
    int _4498 = NOVALUE;
    int _4496 = NOVALUE;
    int _4495 = NOVALUE;
    int _4494 = NOVALUE;
    int _4492 = NOVALUE;
    int _4491 = NOVALUE;
    int _4490 = NOVALUE;
    int _4487 = NOVALUE;
    int _4486 = NOVALUE;
    int _4484 = NOVALUE;
    int _4482 = NOVALUE;
    int _4481 = NOVALUE;
    int _4478 = NOVALUE;
    int _4473 = NOVALUE;
    int _4469 = NOVALUE;
    int _4462 = NOVALUE;
    int _4459 = NOVALUE;
    int _4456 = NOVALUE;
    int _4455 = NOVALUE;
    int _4451 = NOVALUE;
    int _4448 = NOVALUE;
    int _4446 = NOVALUE;
    int _4442 = NOVALUE;
    int _4440 = NOVALUE;
    int _4439 = NOVALUE;
    int _4437 = NOVALUE;
    int _4436 = NOVALUE;
    int _4433 = NOVALUE;
    int _4432 = NOVALUE;
    int _4429 = NOVALUE;
    int _4427 = NOVALUE;
    int _4426 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if absolute_path(filename) then*/
    RefDS(_filename_8354);
    _4426 = _15absolute_path(_filename_8354);
    if (_4426 == 0) {
        DeRef(_4426);
        _4426 = NOVALUE;
        goto L1; // [13] 23
    }
    else {
        if (!IS_ATOM_INT(_4426) && DBL_PTR(_4426)->dbl == 0.0){
            DeRef(_4426);
            _4426 = NOVALUE;
            goto L1; // [13] 23
        }
        DeRef(_4426);
        _4426 = NOVALUE;
    }
    DeRef(_4426);
    _4426 = NOVALUE;

    /** 		return filename*/
    DeRefDS(_search_list_8355);
    DeRefDS(_subdir_8356);
    DeRef(_extra_paths_8357);
    DeRef(_this_path_8358);
    return _filename_8354;
L1: 

    /** 	if length(search_list) = 0 then*/
    if (IS_SEQUENCE(_search_list_8355)){
            _4427 = SEQ_PTR(_search_list_8355)->length;
    }
    else {
        _4427 = 1;
    }
    if (_4427 != 0)
    goto L2; // [28] 277

    /** 		search_list = append(search_list, "." & SLASH)*/
    Append(&_4429, _3794, 92);
    RefDS(_4429);
    Append(&_search_list_8355, _search_list_8355, _4429);
    DeRefDS(_4429);
    _4429 = NOVALUE;

    /** 		extra_paths = command_line()*/
    DeRef(_extra_paths_8357);
    _extra_paths_8357 = Command_Line();

    /** 		extra_paths = canonical_path(dirname(extra_paths[2]), 1)*/
    _2 = (int)SEQ_PTR(_extra_paths_8357);
    _4432 = (int)*(((s1_ptr)_2)->base + 2);
    RefDS(_4432);
    _4433 = _15dirname(_4432, 0);
    _4432 = NOVALUE;
    _0 = _extra_paths_8357;
    _extra_paths_8357 = _15canonical_path(_4433, 1, 0);
    DeRefDS(_0);
    _4433 = NOVALUE;

    /** 		search_list = append(search_list, extra_paths)*/
    Ref(_extra_paths_8357);
    Append(&_search_list_8355, _search_list_8355, _extra_paths_8357);

    /** 		ifdef UNIX then*/

    /** 			extra_paths = getenv("HOMEDRIVE") & getenv("HOMEPATH")*/
    _4436 = EGetEnv(_4076);
    _4437 = EGetEnv(_4078);
    if (IS_SEQUENCE(_4436) && IS_ATOM(_4437)) {
        Ref(_4437);
        Append(&_extra_paths_8357, _4436, _4437);
    }
    else if (IS_ATOM(_4436) && IS_SEQUENCE(_4437)) {
        Ref(_4436);
        Prepend(&_extra_paths_8357, _4437, _4436);
    }
    else {
        Concat((object_ptr)&_extra_paths_8357, _4436, _4437);
        DeRef(_4436);
        _4436 = NOVALUE;
    }
    DeRef(_4436);
    _4436 = NOVALUE;
    DeRef(_4437);
    _4437 = NOVALUE;

    /** 		if sequence(extra_paths) then*/
    _4439 = 1;
    if (_4439 == 0)
    {
        _4439 = NOVALUE;
        goto L3; // [88] 102
    }
    else{
        _4439 = NOVALUE;
    }

    /** 			search_list = append(search_list, extra_paths & SLASH)*/
    Append(&_4440, _extra_paths_8357, 92);
    RefDS(_4440);
    Append(&_search_list_8355, _search_list_8355, _4440);
    DeRefDS(_4440);
    _4440 = NOVALUE;
L3: 

    /** 		search_list = append(search_list, ".." & SLASH)*/
    Append(&_4442, _3825, 92);
    RefDS(_4442);
    Append(&_search_list_8355, _search_list_8355, _4442);
    DeRefDS(_4442);
    _4442 = NOVALUE;

    /** 		extra_paths = getenv("EUDIR")*/
    DeRef(_extra_paths_8357);
    _extra_paths_8357 = EGetEnv(_4444);

    /** 		if sequence(extra_paths) then*/
    _4446 = IS_SEQUENCE(_extra_paths_8357);
    if (_4446 == 0)
    {
        _4446 = NOVALUE;
        goto L4; // [122] 152
    }
    else{
        _4446 = NOVALUE;
    }

    /** 			search_list = append(search_list, extra_paths & SLASH & "bin" & SLASH)*/
    {
        int concat_list[4];

        concat_list[0] = 92;
        concat_list[1] = _4447;
        concat_list[2] = 92;
        concat_list[3] = _extra_paths_8357;
        Concat_N((object_ptr)&_4448, concat_list, 4);
    }
    RefDS(_4448);
    Append(&_search_list_8355, _search_list_8355, _4448);
    DeRefDS(_4448);
    _4448 = NOVALUE;

    /** 			search_list = append(search_list, extra_paths & SLASH & "docs" & SLASH)*/
    {
        int concat_list[4];

        concat_list[0] = 92;
        concat_list[1] = _4450;
        concat_list[2] = 92;
        concat_list[3] = _extra_paths_8357;
        Concat_N((object_ptr)&_4451, concat_list, 4);
    }
    RefDS(_4451);
    Append(&_search_list_8355, _search_list_8355, _4451);
    DeRefDS(_4451);
    _4451 = NOVALUE;
L4: 

    /** 		extra_paths = getenv("EUDIST")*/
    DeRef(_extra_paths_8357);
    _extra_paths_8357 = EGetEnv(_4453);

    /** 		if sequence(extra_paths) then*/
    _4455 = IS_SEQUENCE(_extra_paths_8357);
    if (_4455 == 0)
    {
        _4455 = NOVALUE;
        goto L5; // [162] 202
    }
    else{
        _4455 = NOVALUE;
    }

    /** 			search_list = append(search_list, extra_paths & SLASH)*/
    if (IS_SEQUENCE(_extra_paths_8357) && IS_ATOM(92)) {
        Append(&_4456, _extra_paths_8357, 92);
    }
    else if (IS_ATOM(_extra_paths_8357) && IS_SEQUENCE(92)) {
    }
    else {
        Concat((object_ptr)&_4456, _extra_paths_8357, 92);
    }
    RefDS(_4456);
    Append(&_search_list_8355, _search_list_8355, _4456);
    DeRefDS(_4456);
    _4456 = NOVALUE;

    /** 			search_list = append(search_list, extra_paths & SLASH & "etc" & SLASH)*/
    {
        int concat_list[4];

        concat_list[0] = 92;
        concat_list[1] = _4458;
        concat_list[2] = 92;
        concat_list[3] = _extra_paths_8357;
        Concat_N((object_ptr)&_4459, concat_list, 4);
    }
    RefDS(_4459);
    Append(&_search_list_8355, _search_list_8355, _4459);
    DeRefDS(_4459);
    _4459 = NOVALUE;

    /** 			search_list = append(search_list, extra_paths & SLASH & "data" & SLASH)*/
    {
        int concat_list[4];

        concat_list[0] = 92;
        concat_list[1] = _4461;
        concat_list[2] = 92;
        concat_list[3] = _extra_paths_8357;
        Concat_N((object_ptr)&_4462, concat_list, 4);
    }
    RefDS(_4462);
    Append(&_search_list_8355, _search_list_8355, _4462);
    DeRefDS(_4462);
    _4462 = NOVALUE;
L5: 

    /** 		ifdef UNIX then*/

    /** 		search_list &= include_paths(1)*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_4468);
    *((int *)(_2+4)) = _4468;
    RefDS(_4467);
    *((int *)(_2+8)) = _4467;
    RefDS(_4466);
    *((int *)(_2+12)) = _4466;
    _4469 = MAKE_SEQ(_1);
    Concat((object_ptr)&_search_list_8355, _search_list_8355, _4469);
    DeRefDS(_4469);
    _4469 = NOVALUE;

    /** 		extra_paths = getenv("USERPATH")*/
    DeRef(_extra_paths_8357);
    _extra_paths_8357 = EGetEnv(_4471);

    /** 		if sequence(extra_paths) then*/
    _4473 = IS_SEQUENCE(_extra_paths_8357);
    if (_4473 == 0)
    {
        _4473 = NOVALUE;
        goto L6; // [226] 245
    }
    else{
        _4473 = NOVALUE;
    }

    /** 			extra_paths = stdseq:split(extra_paths, PATHSEP)*/
    Ref(_extra_paths_8357);
    _0 = _extra_paths_8357;
    _extra_paths_8357 = _23split(_extra_paths_8357, 59, 0, 0);
    DeRefi(_0);

    /** 			search_list &= extra_paths*/
    if (IS_SEQUENCE(_search_list_8355) && IS_ATOM(_extra_paths_8357)) {
        Ref(_extra_paths_8357);
        Append(&_search_list_8355, _search_list_8355, _extra_paths_8357);
    }
    else if (IS_ATOM(_search_list_8355) && IS_SEQUENCE(_extra_paths_8357)) {
    }
    else {
        Concat((object_ptr)&_search_list_8355, _search_list_8355, _extra_paths_8357);
    }
L6: 

    /** 		extra_paths = getenv("PATH")*/
    DeRef(_extra_paths_8357);
    _extra_paths_8357 = EGetEnv(_4476);

    /** 		if sequence(extra_paths) then*/
    _4478 = IS_SEQUENCE(_extra_paths_8357);
    if (_4478 == 0)
    {
        _4478 = NOVALUE;
        goto L7; // [255] 302
    }
    else{
        _4478 = NOVALUE;
    }

    /** 			extra_paths = stdseq:split(extra_paths, PATHSEP)*/
    Ref(_extra_paths_8357);
    _0 = _extra_paths_8357;
    _extra_paths_8357 = _23split(_extra_paths_8357, 59, 0, 0);
    DeRefi(_0);

    /** 			search_list &= extra_paths*/
    if (IS_SEQUENCE(_search_list_8355) && IS_ATOM(_extra_paths_8357)) {
        Ref(_extra_paths_8357);
        Append(&_search_list_8355, _search_list_8355, _extra_paths_8357);
    }
    else if (IS_ATOM(_search_list_8355) && IS_SEQUENCE(_extra_paths_8357)) {
    }
    else {
        Concat((object_ptr)&_search_list_8355, _search_list_8355, _extra_paths_8357);
    }
    goto L7; // [274] 302
L2: 

    /** 		if integer(search_list[1]) then*/
    _2 = (int)SEQ_PTR(_search_list_8355);
    _4481 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_4481))
    _4482 = 1;
    else if (IS_ATOM_DBL(_4481))
    _4482 = IS_ATOM_INT(DoubleToInt(_4481));
    else
    _4482 = 0;
    _4481 = NOVALUE;
    if (_4482 == 0)
    {
        _4482 = NOVALUE;
        goto L8; // [286] 301
    }
    else{
        _4482 = NOVALUE;
    }

    /** 			search_list = stdseq:split(search_list, PATHSEP)*/
    RefDS(_search_list_8355);
    _0 = _search_list_8355;
    _search_list_8355 = _23split(_search_list_8355, 59, 0, 0);
    DeRefDS(_0);
L8: 
L7: 

    /** 	if length(subdir) > 0 then*/
    if (IS_SEQUENCE(_subdir_8356)){
            _4484 = SEQ_PTR(_subdir_8356)->length;
    }
    else {
        _4484 = 1;
    }
    if (_4484 <= 0)
    goto L9; // [307] 332

    /** 		if subdir[$] != SLASH then*/
    if (IS_SEQUENCE(_subdir_8356)){
            _4486 = SEQ_PTR(_subdir_8356)->length;
    }
    else {
        _4486 = 1;
    }
    _2 = (int)SEQ_PTR(_subdir_8356);
    _4487 = (int)*(((s1_ptr)_2)->base + _4486);
    if (binary_op_a(EQUALS, _4487, 92)){
        _4487 = NOVALUE;
        goto LA; // [320] 331
    }
    _4487 = NOVALUE;

    /** 			subdir &= SLASH*/
    Append(&_subdir_8356, _subdir_8356, 92);
LA: 
L9: 

    /** 	for i = 1 to length(search_list) do*/
    if (IS_SEQUENCE(_search_list_8355)){
            _4490 = SEQ_PTR(_search_list_8355)->length;
    }
    else {
        _4490 = 1;
    }
    {
        int _i_8435;
        _i_8435 = 1;
LB: 
        if (_i_8435 > _4490){
            goto LC; // [337] 460
        }

        /** 		if length(search_list[i]) = 0 then*/
        _2 = (int)SEQ_PTR(_search_list_8355);
        _4491 = (int)*(((s1_ptr)_2)->base + _i_8435);
        if (IS_SEQUENCE(_4491)){
                _4492 = SEQ_PTR(_4491)->length;
        }
        else {
            _4492 = 1;
        }
        _4491 = NOVALUE;
        if (_4492 != 0)
        goto LD; // [353] 362

        /** 			continue*/
        goto LE; // [359] 455
LD: 

        /** 		if search_list[i][$] != SLASH then*/
        _2 = (int)SEQ_PTR(_search_list_8355);
        _4494 = (int)*(((s1_ptr)_2)->base + _i_8435);
        if (IS_SEQUENCE(_4494)){
                _4495 = SEQ_PTR(_4494)->length;
        }
        else {
            _4495 = 1;
        }
        _2 = (int)SEQ_PTR(_4494);
        _4496 = (int)*(((s1_ptr)_2)->base + _4495);
        _4494 = NOVALUE;
        if (binary_op_a(EQUALS, _4496, 92)){
            _4496 = NOVALUE;
            goto LF; // [375] 394
        }
        _4496 = NOVALUE;

        /** 			search_list[i] &= SLASH*/
        _2 = (int)SEQ_PTR(_search_list_8355);
        _4498 = (int)*(((s1_ptr)_2)->base + _i_8435);
        if (IS_SEQUENCE(_4498) && IS_ATOM(92)) {
            Append(&_4499, _4498, 92);
        }
        else if (IS_ATOM(_4498) && IS_SEQUENCE(92)) {
        }
        else {
            Concat((object_ptr)&_4499, _4498, 92);
            _4498 = NOVALUE;
        }
        _4498 = NOVALUE;
        _2 = (int)SEQ_PTR(_search_list_8355);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _search_list_8355 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_8435);
        _1 = *(int *)_2;
        *(int *)_2 = _4499;
        if( _1 != _4499 ){
            DeRef(_1);
        }
        _4499 = NOVALUE;
LF: 

        /** 		if length(subdir) > 0 then*/
        if (IS_SEQUENCE(_subdir_8356)){
                _4500 = SEQ_PTR(_subdir_8356)->length;
        }
        else {
            _4500 = 1;
        }
        if (_4500 <= 0)
        goto L10; // [399] 418

        /** 			this_path = search_list[i] & subdir & filename*/
        _2 = (int)SEQ_PTR(_search_list_8355);
        _4502 = (int)*(((s1_ptr)_2)->base + _i_8435);
        {
            int concat_list[3];

            concat_list[0] = _filename_8354;
            concat_list[1] = _subdir_8356;
            concat_list[2] = _4502;
            Concat_N((object_ptr)&_this_path_8358, concat_list, 3);
        }
        _4502 = NOVALUE;
        goto L11; // [415] 429
L10: 

        /** 			this_path = search_list[i] & filename*/
        _2 = (int)SEQ_PTR(_search_list_8355);
        _4504 = (int)*(((s1_ptr)_2)->base + _i_8435);
        if (IS_SEQUENCE(_4504) && IS_ATOM(_filename_8354)) {
        }
        else if (IS_ATOM(_4504) && IS_SEQUENCE(_filename_8354)) {
            Ref(_4504);
            Prepend(&_this_path_8358, _filename_8354, _4504);
        }
        else {
            Concat((object_ptr)&_this_path_8358, _4504, _filename_8354);
            _4504 = NOVALUE;
        }
        _4504 = NOVALUE;
L11: 

        /** 		if file_exists(this_path) then*/
        RefDS(_this_path_8358);
        _4506 = _15file_exists(_this_path_8358);
        if (_4506 == 0) {
            DeRef(_4506);
            _4506 = NOVALUE;
            goto L12; // [437] 453
        }
        else {
            if (!IS_ATOM_INT(_4506) && DBL_PTR(_4506)->dbl == 0.0){
                DeRef(_4506);
                _4506 = NOVALUE;
                goto L12; // [437] 453
            }
            DeRef(_4506);
            _4506 = NOVALUE;
        }
        DeRef(_4506);
        _4506 = NOVALUE;

        /** 			return canonical_path(this_path)*/
        RefDS(_this_path_8358);
        _4507 = _15canonical_path(_this_path_8358, 0, 0);
        DeRefDS(_filename_8354);
        DeRefDS(_search_list_8355);
        DeRefDS(_subdir_8356);
        DeRef(_extra_paths_8357);
        DeRefDS(_this_path_8358);
        _4491 = NOVALUE;
        return _4507;
L12: 

        /** 	end for*/
LE: 
        _i_8435 = _i_8435 + 1;
        goto LB; // [455] 344
LC: 
        ;
    }

    /** 	return filename*/
    DeRefDS(_search_list_8355);
    DeRefDS(_subdir_8356);
    DeRef(_extra_paths_8357);
    DeRef(_this_path_8358);
    _4491 = NOVALUE;
    DeRef(_4507);
    _4507 = NOVALUE;
    return _filename_8354;
    ;
}


int _15count_files(int _orig_path_8512, int _dir_info_8513, int _inst_8514)
{
    int _pos_8515 = NOVALUE;
    int _ext_8516 = NOVALUE;
    int _fileext_inlined_fileext_at_223_8559 = NOVALUE;
    int _data_inlined_fileext_at_223_8558 = NOVALUE;
    int _path_inlined_fileext_at_220_8557 = NOVALUE;
    int _4603 = NOVALUE;
    int _4602 = NOVALUE;
    int _4601 = NOVALUE;
    int _4599 = NOVALUE;
    int _4598 = NOVALUE;
    int _4597 = NOVALUE;
    int _4596 = NOVALUE;
    int _4594 = NOVALUE;
    int _4593 = NOVALUE;
    int _4591 = NOVALUE;
    int _4590 = NOVALUE;
    int _4589 = NOVALUE;
    int _4588 = NOVALUE;
    int _4587 = NOVALUE;
    int _4586 = NOVALUE;
    int _4585 = NOVALUE;
    int _4583 = NOVALUE;
    int _4582 = NOVALUE;
    int _4580 = NOVALUE;
    int _4579 = NOVALUE;
    int _4578 = NOVALUE;
    int _4577 = NOVALUE;
    int _4576 = NOVALUE;
    int _4575 = NOVALUE;
    int _4574 = NOVALUE;
    int _4573 = NOVALUE;
    int _4572 = NOVALUE;
    int _4571 = NOVALUE;
    int _4570 = NOVALUE;
    int _4569 = NOVALUE;
    int _4568 = NOVALUE;
    int _4567 = NOVALUE;
    int _4565 = NOVALUE;
    int _4564 = NOVALUE;
    int _4563 = NOVALUE;
    int _4562 = NOVALUE;
    int _4560 = NOVALUE;
    int _4559 = NOVALUE;
    int _4558 = NOVALUE;
    int _4557 = NOVALUE;
    int _4556 = NOVALUE;
    int _4555 = NOVALUE;
    int _4554 = NOVALUE;
    int _4552 = NOVALUE;
    int _4551 = NOVALUE;
    int _4550 = NOVALUE;
    int _4549 = NOVALUE;
    int _4548 = NOVALUE;
    int _4547 = NOVALUE;
    int _4544 = NOVALUE;
    int _4543 = NOVALUE;
    int _4542 = NOVALUE;
    int _4541 = NOVALUE;
    int _4540 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	integer pos = 0*/
    _pos_8515 = 0;

    /** 	orig_path = orig_path*/
    RefDS(_orig_path_8512);
    DeRefDS(_orig_path_8512);
    _orig_path_8512 = _orig_path_8512;

    /** 	if equal(dir_info[D_NAME], ".") then*/
    _2 = (int)SEQ_PTR(_dir_info_8513);
    _4540 = (int)*(((s1_ptr)_2)->base + 1);
    if (_4540 == _3794)
    _4541 = 1;
    else if (IS_ATOM_INT(_4540) && IS_ATOM_INT(_3794))
    _4541 = 0;
    else
    _4541 = (compare(_4540, _3794) == 0);
    _4540 = NOVALUE;
    if (_4541 == 0)
    {
        _4541 = NOVALUE;
        goto L1; // [29] 39
    }
    else{
        _4541 = NOVALUE;
    }

    /** 		return 0*/
    DeRefDS(_orig_path_8512);
    DeRefDS(_dir_info_8513);
    DeRefDS(_inst_8514);
    DeRef(_ext_8516);
    return 0;
L1: 

    /** 	if equal(dir_info[D_NAME], "..") then*/
    _2 = (int)SEQ_PTR(_dir_info_8513);
    _4542 = (int)*(((s1_ptr)_2)->base + 1);
    if (_4542 == _3825)
    _4543 = 1;
    else if (IS_ATOM_INT(_4542) && IS_ATOM_INT(_3825))
    _4543 = 0;
    else
    _4543 = (compare(_4542, _3825) == 0);
    _4542 = NOVALUE;
    if (_4543 == 0)
    {
        _4543 = NOVALUE;
        goto L2; // [49] 59
    }
    else{
        _4543 = NOVALUE;
    }

    /** 		return 0*/
    DeRefDS(_orig_path_8512);
    DeRefDS(_dir_info_8513);
    DeRefDS(_inst_8514);
    DeRef(_ext_8516);
    return 0;
L2: 

    /** 	if inst[1] = 0 then -- count all is false*/
    _2 = (int)SEQ_PTR(_inst_8514);
    _4544 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _4544, 0)){
        _4544 = NOVALUE;
        goto L3; // [65] 112
    }
    _4544 = NOVALUE;

    /** 		if find('h', dir_info[D_ATTRIBUTES]) then*/
    _2 = (int)SEQ_PTR(_dir_info_8513);
    _4547 = (int)*(((s1_ptr)_2)->base + 2);
    _4548 = find_from(104, _4547, 1);
    _4547 = NOVALUE;
    if (_4548 == 0)
    {
        _4548 = NOVALUE;
        goto L4; // [80] 90
    }
    else{
        _4548 = NOVALUE;
    }

    /** 			return 0*/
    DeRefDS(_orig_path_8512);
    DeRefDS(_dir_info_8513);
    DeRefDS(_inst_8514);
    DeRef(_ext_8516);
    return 0;
L4: 

    /** 		if find('s', dir_info[D_ATTRIBUTES]) then*/
    _2 = (int)SEQ_PTR(_dir_info_8513);
    _4549 = (int)*(((s1_ptr)_2)->base + 2);
    _4550 = find_from(115, _4549, 1);
    _4549 = NOVALUE;
    if (_4550 == 0)
    {
        _4550 = NOVALUE;
        goto L5; // [101] 111
    }
    else{
        _4550 = NOVALUE;
    }

    /** 			return 0*/
    DeRefDS(_orig_path_8512);
    DeRefDS(_dir_info_8513);
    DeRefDS(_inst_8514);
    DeRef(_ext_8516);
    return 0;
L5: 
L3: 

    /** 	file_counters[inst[2]][COUNT_SIZE] += dir_info[D_SIZE]*/
    _2 = (int)SEQ_PTR(_inst_8514);
    _4551 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_15file_counters_8509);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _15file_counters_8509 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_4551))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_4551)->dbl));
    else
    _3 = (int)(_4551 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_dir_info_8513);
    _4554 = (int)*(((s1_ptr)_2)->base + 3);
    _2 = (int)SEQ_PTR(*(int *)_3);
    _4555 = (int)*(((s1_ptr)_2)->base + 3);
    _4552 = NOVALUE;
    if (IS_ATOM_INT(_4555) && IS_ATOM_INT(_4554)) {
        _4556 = _4555 + _4554;
        if ((long)((unsigned long)_4556 + (unsigned long)HIGH_BITS) >= 0) 
        _4556 = NewDouble((double)_4556);
    }
    else {
        _4556 = binary_op(PLUS, _4555, _4554);
    }
    _4555 = NOVALUE;
    _4554 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = _4556;
    if( _1 != _4556 ){
        DeRef(_1);
    }
    _4556 = NOVALUE;
    _4552 = NOVALUE;

    /** 	if find('d', dir_info[D_ATTRIBUTES]) then*/
    _2 = (int)SEQ_PTR(_dir_info_8513);
    _4557 = (int)*(((s1_ptr)_2)->base + 2);
    _4558 = find_from(100, _4557, 1);
    _4557 = NOVALUE;
    if (_4558 == 0)
    {
        _4558 = NOVALUE;
        goto L6; // [152] 183
    }
    else{
        _4558 = NOVALUE;
    }

    /** 		file_counters[inst[2]][COUNT_DIRS] += 1*/
    _2 = (int)SEQ_PTR(_inst_8514);
    _4559 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_15file_counters_8509);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _15file_counters_8509 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_4559))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_4559)->dbl));
    else
    _3 = (int)(_4559 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    _4562 = (int)*(((s1_ptr)_2)->base + 1);
    _4560 = NOVALUE;
    if (IS_ATOM_INT(_4562)) {
        _4563 = _4562 + 1;
        if (_4563 > MAXINT){
            _4563 = NewDouble((double)_4563);
        }
    }
    else
    _4563 = binary_op(PLUS, 1, _4562);
    _4562 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _4563;
    if( _1 != _4563 ){
        DeRef(_1);
    }
    _4563 = NOVALUE;
    _4560 = NOVALUE;
    goto L7; // [180] 464
L6: 

    /** 		file_counters[inst[2]][COUNT_FILES] += 1*/
    _2 = (int)SEQ_PTR(_inst_8514);
    _4564 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_15file_counters_8509);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _15file_counters_8509 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_4564))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_4564)->dbl));
    else
    _3 = (int)(_4564 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    _4567 = (int)*(((s1_ptr)_2)->base + 2);
    _4565 = NOVALUE;
    if (IS_ATOM_INT(_4567)) {
        _4568 = _4567 + 1;
        if (_4568 > MAXINT){
            _4568 = NewDouble((double)_4568);
        }
    }
    else
    _4568 = binary_op(PLUS, 1, _4567);
    _4567 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _4568;
    if( _1 != _4568 ){
        DeRef(_1);
    }
    _4568 = NOVALUE;
    _4565 = NOVALUE;

    /** 		ifdef not UNIX then*/

    /** 			ext = fileext(lower(dir_info[D_NAME]))*/
    _2 = (int)SEQ_PTR(_dir_info_8513);
    _4569 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_4569);
    _4570 = _12lower(_4569);
    _4569 = NOVALUE;
    DeRef(_path_inlined_fileext_at_220_8557);
    _path_inlined_fileext_at_220_8557 = _4570;
    _4570 = NOVALUE;

    /** 	data = pathinfo(path)*/
    Ref(_path_inlined_fileext_at_220_8557);
    _0 = _data_inlined_fileext_at_223_8558;
    _data_inlined_fileext_at_223_8558 = _15pathinfo(_path_inlined_fileext_at_220_8557, 0);
    DeRef(_0);

    /** 	return data[4]*/
    DeRef(_ext_8516);
    _2 = (int)SEQ_PTR(_data_inlined_fileext_at_223_8558);
    _ext_8516 = (int)*(((s1_ptr)_2)->base + 4);
    Ref(_ext_8516);
    DeRef(_path_inlined_fileext_at_220_8557);
    _path_inlined_fileext_at_220_8557 = NOVALUE;
    DeRef(_data_inlined_fileext_at_223_8558);
    _data_inlined_fileext_at_223_8558 = NOVALUE;

    /** 		pos = 0*/
    _pos_8515 = 0;

    /** 		for i = 1 to length(file_counters[inst[2]][COUNT_TYPES]) do*/
    _2 = (int)SEQ_PTR(_inst_8514);
    _4571 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_15file_counters_8509);
    if (!IS_ATOM_INT(_4571)){
        _4572 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_4571)->dbl));
    }
    else{
        _4572 = (int)*(((s1_ptr)_2)->base + _4571);
    }
    _2 = (int)SEQ_PTR(_4572);
    _4573 = (int)*(((s1_ptr)_2)->base + 4);
    _4572 = NOVALUE;
    if (IS_SEQUENCE(_4573)){
            _4574 = SEQ_PTR(_4573)->length;
    }
    else {
        _4574 = 1;
    }
    _4573 = NOVALUE;
    {
        int _i_8561;
        _i_8561 = 1;
L8: 
        if (_i_8561 > _4574){
            goto L9; // [269] 326
        }

        /** 			if equal(file_counters[inst[2]][COUNT_TYPES][i][EXT_NAME], ext) then*/
        _2 = (int)SEQ_PTR(_inst_8514);
        _4575 = (int)*(((s1_ptr)_2)->base + 2);
        _2 = (int)SEQ_PTR(_15file_counters_8509);
        if (!IS_ATOM_INT(_4575)){
            _4576 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_4575)->dbl));
        }
        else{
            _4576 = (int)*(((s1_ptr)_2)->base + _4575);
        }
        _2 = (int)SEQ_PTR(_4576);
        _4577 = (int)*(((s1_ptr)_2)->base + 4);
        _4576 = NOVALUE;
        _2 = (int)SEQ_PTR(_4577);
        _4578 = (int)*(((s1_ptr)_2)->base + _i_8561);
        _4577 = NOVALUE;
        _2 = (int)SEQ_PTR(_4578);
        _4579 = (int)*(((s1_ptr)_2)->base + 1);
        _4578 = NOVALUE;
        if (_4579 == _ext_8516)
        _4580 = 1;
        else if (IS_ATOM_INT(_4579) && IS_ATOM_INT(_ext_8516))
        _4580 = 0;
        else
        _4580 = (compare(_4579, _ext_8516) == 0);
        _4579 = NOVALUE;
        if (_4580 == 0)
        {
            _4580 = NOVALUE;
            goto LA; // [306] 319
        }
        else{
            _4580 = NOVALUE;
        }

        /** 				pos = i*/
        _pos_8515 = _i_8561;

        /** 				exit*/
        goto L9; // [316] 326
LA: 

        /** 		end for*/
        _i_8561 = _i_8561 + 1;
        goto L8; // [321] 276
L9: 
        ;
    }

    /** 		if pos = 0 then*/
    if (_pos_8515 != 0)
    goto LB; // [328] 389

    /** 			file_counters[inst[2]][COUNT_TYPES] &= {{ext, 0, 0}}*/
    _2 = (int)SEQ_PTR(_inst_8514);
    _4582 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_15file_counters_8509);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _15file_counters_8509 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_4582))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_4582)->dbl));
    else
    _3 = (int)(_4582 + ((s1_ptr)_2)->base);
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_ext_8516);
    *((int *)(_2+4)) = _ext_8516;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = 0;
    _4585 = MAKE_SEQ(_1);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _4585;
    _4586 = MAKE_SEQ(_1);
    _4585 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    _4587 = (int)*(((s1_ptr)_2)->base + 4);
    _4583 = NOVALUE;
    if (IS_SEQUENCE(_4587) && IS_ATOM(_4586)) {
    }
    else if (IS_ATOM(_4587) && IS_SEQUENCE(_4586)) {
        Ref(_4587);
        Prepend(&_4588, _4586, _4587);
    }
    else {
        Concat((object_ptr)&_4588, _4587, _4586);
        _4587 = NOVALUE;
    }
    _4587 = NOVALUE;
    DeRefDS(_4586);
    _4586 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = _4588;
    if( _1 != _4588 ){
        DeRef(_1);
    }
    _4588 = NOVALUE;
    _4583 = NOVALUE;

    /** 			pos = length(file_counters[inst[2]][COUNT_TYPES])*/
    _2 = (int)SEQ_PTR(_inst_8514);
    _4589 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_15file_counters_8509);
    if (!IS_ATOM_INT(_4589)){
        _4590 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_4589)->dbl));
    }
    else{
        _4590 = (int)*(((s1_ptr)_2)->base + _4589);
    }
    _2 = (int)SEQ_PTR(_4590);
    _4591 = (int)*(((s1_ptr)_2)->base + 4);
    _4590 = NOVALUE;
    if (IS_SEQUENCE(_4591)){
            _pos_8515 = SEQ_PTR(_4591)->length;
    }
    else {
        _pos_8515 = 1;
    }
    _4591 = NOVALUE;
LB: 

    /** 		file_counters[inst[2]][COUNT_TYPES][pos][EXT_COUNT] += 1*/
    _2 = (int)SEQ_PTR(_inst_8514);
    _4593 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_15file_counters_8509);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _15file_counters_8509 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_4593))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_4593)->dbl));
    else
    _3 = (int)(_4593 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(object_ptr)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(object_ptr)_3 = MAKE_SEQ(_2);
    }
    _3 = (int)(4 + ((s1_ptr)_2)->base);
    _4594 = NOVALUE;
    _2 = (int)SEQ_PTR(*(object_ptr)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(object_ptr)_3 = MAKE_SEQ(_2);
    }
    _3 = (int)(_pos_8515 + ((s1_ptr)_2)->base);
    _4594 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    _4596 = (int)*(((s1_ptr)_2)->base + 2);
    _4594 = NOVALUE;
    if (IS_ATOM_INT(_4596)) {
        _4597 = _4596 + 1;
        if (_4597 > MAXINT){
            _4597 = NewDouble((double)_4597);
        }
    }
    else
    _4597 = binary_op(PLUS, 1, _4596);
    _4596 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _4597;
    if( _1 != _4597 ){
        DeRef(_1);
    }
    _4597 = NOVALUE;
    _4594 = NOVALUE;

    /** 		file_counters[inst[2]][COUNT_TYPES][pos][EXT_SIZE] += dir_info[D_SIZE]*/
    _2 = (int)SEQ_PTR(_inst_8514);
    _4598 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_15file_counters_8509);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _15file_counters_8509 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_4598))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_4598)->dbl));
    else
    _3 = (int)(_4598 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(object_ptr)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(object_ptr)_3 = MAKE_SEQ(_2);
    }
    _3 = (int)(4 + ((s1_ptr)_2)->base);
    _4599 = NOVALUE;
    _2 = (int)SEQ_PTR(*(object_ptr)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(object_ptr)_3 = MAKE_SEQ(_2);
    }
    _3 = (int)(_pos_8515 + ((s1_ptr)_2)->base);
    _4599 = NOVALUE;
    _2 = (int)SEQ_PTR(_dir_info_8513);
    _4601 = (int)*(((s1_ptr)_2)->base + 3);
    _2 = (int)SEQ_PTR(*(int *)_3);
    _4602 = (int)*(((s1_ptr)_2)->base + 3);
    _4599 = NOVALUE;
    if (IS_ATOM_INT(_4602) && IS_ATOM_INT(_4601)) {
        _4603 = _4602 + _4601;
        if ((long)((unsigned long)_4603 + (unsigned long)HIGH_BITS) >= 0) 
        _4603 = NewDouble((double)_4603);
    }
    else {
        _4603 = binary_op(PLUS, _4602, _4601);
    }
    _4602 = NOVALUE;
    _4601 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = _4603;
    if( _1 != _4603 ){
        DeRef(_1);
    }
    _4603 = NOVALUE;
    _4599 = NOVALUE;
L7: 

    /** 	return 0*/
    DeRefDS(_orig_path_8512);
    DeRefDS(_dir_info_8513);
    DeRefDS(_inst_8514);
    DeRef(_ext_8516);
    _4551 = NOVALUE;
    _4559 = NOVALUE;
    _4564 = NOVALUE;
    _4571 = NOVALUE;
    _4573 = NOVALUE;
    _4575 = NOVALUE;
    _4582 = NOVALUE;
    _4589 = NOVALUE;
    _4591 = NOVALUE;
    _4593 = NOVALUE;
    _4598 = NOVALUE;
    return 0;
    ;
}



// 0xC0BB75F4
