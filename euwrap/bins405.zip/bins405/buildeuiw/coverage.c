// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

void _49check_coverage()
{
    int _25199 = NOVALUE;
    int _25198 = NOVALUE;
    int _25197 = NOVALUE;
    int _25196 = NOVALUE;
    int _25195 = NOVALUE;
    int _25194 = NOVALUE;
    int _0, _1, _2;
    

    /** 	for i = length( file_coverage ) + 1 to length( known_files ) do*/
    if (IS_SEQUENCE(_49file_coverage_48139)){
            _25194 = SEQ_PTR(_49file_coverage_48139)->length;
    }
    else {
        _25194 = 1;
    }
    _25195 = _25194 + 1;
    _25194 = NOVALUE;
    if (IS_SEQUENCE(_27known_files_10922)){
            _25196 = SEQ_PTR(_27known_files_10922)->length;
    }
    else {
        _25196 = 1;
    }
    {
        int _i_48150;
        _i_48150 = _25195;
L1: 
        if (_i_48150 > _25196){
            goto L2; // [17] 58
        }

        /** 		file_coverage &= find( canonical_path( known_files[i],,1 ), covered_files )*/
        _2 = (int)SEQ_PTR(_27known_files_10922);
        _25197 = (int)*(((s1_ptr)_2)->base + _i_48150);
        Ref(_25197);
        _25198 = _15canonical_path(_25197, 0, 1);
        _25197 = NOVALUE;
        _25199 = find_from(_25198, _49covered_files_48138, 1);
        DeRef(_25198);
        _25198 = NOVALUE;
        Append(&_49file_coverage_48139, _49file_coverage_48139, _25199);
        _25199 = NOVALUE;

        /** 	end for*/
        _i_48150 = _i_48150 + 1;
        goto L1; // [53] 24
L2: 
        ;
    }

    /** end procedure*/
    DeRef(_25195);
    _25195 = NOVALUE;
    return;
    ;
}


void _49init_coverage()
{
    int _cmd_48174 = NOVALUE;
    int _25217 = NOVALUE;
    int _25216 = NOVALUE;
    int _25214 = NOVALUE;
    int _25213 = NOVALUE;
    int _25212 = NOVALUE;
    int _25210 = NOVALUE;
    int _25208 = NOVALUE;
    int _25207 = NOVALUE;
    int _25205 = NOVALUE;
    int _25204 = NOVALUE;
    int _25203 = NOVALUE;
    int _25202 = NOVALUE;
    int _25201 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if initialized_coverage then*/
    if (_49initialized_coverage_48146 == 0)
    {
        goto L1; // [5] 14
    }
    else{
    }

    /** 		return*/
    return;
L1: 

    /** 	initialized_coverage = 1*/
    _49initialized_coverage_48146 = 1;

    /** 	for i = 1 to length( file_coverage ) do*/
    if (IS_SEQUENCE(_49file_coverage_48139)){
            _25201 = SEQ_PTR(_49file_coverage_48139)->length;
    }
    else {
        _25201 = 1;
    }
    {
        int _i_48165;
        _i_48165 = 1;
L2: 
        if (_i_48165 > _25201){
            goto L3; // [26] 67
        }

        /** 		file_coverage[i] = find( canonical_path( known_files[i],,1 ), covered_files )*/
        _2 = (int)SEQ_PTR(_27known_files_10922);
        _25202 = (int)*(((s1_ptr)_2)->base + _i_48165);
        Ref(_25202);
        _25203 = _15canonical_path(_25202, 0, 1);
        _25202 = NOVALUE;
        _25204 = find_from(_25203, _49covered_files_48138, 1);
        DeRef(_25203);
        _25203 = NOVALUE;
        _2 = (int)SEQ_PTR(_49file_coverage_48139);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _49file_coverage_48139 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_48165);
        *(int *)_2 = _25204;
        if( _1 != _25204 ){
        }
        _25204 = NOVALUE;

        /** 	end for*/
        _i_48165 = _i_48165 + 1;
        goto L2; // [62] 33
L3: 
        ;
    }

    /** 	if equal( coverage_db_name, "" ) then*/
    if (_49coverage_db_name_48140 == _22037)
    _25205 = 1;
    else if (IS_ATOM_INT(_49coverage_db_name_48140) && IS_ATOM_INT(_22037))
    _25205 = 0;
    else
    _25205 = (compare(_49coverage_db_name_48140, _22037) == 0);
    if (_25205 == 0)
    {
        _25205 = NOVALUE;
        goto L4; // [75] 105
    }
    else{
        _25205 = NOVALUE;
    }

    /** 		sequence cmd = command_line()*/
    DeRef(_cmd_48174);
    _cmd_48174 = Command_Line();

    /** 		coverage_db_name = canonical_path( filebase( cmd[2] ) & "-cvg.edb" )*/
    _2 = (int)SEQ_PTR(_cmd_48174);
    _25207 = (int)*(((s1_ptr)_2)->base + 2);
    RefDS(_25207);
    _25208 = _15filebase(_25207);
    _25207 = NOVALUE;
    if (IS_SEQUENCE(_25208) && IS_ATOM(_25209)) {
    }
    else if (IS_ATOM(_25208) && IS_SEQUENCE(_25209)) {
        Ref(_25208);
        Prepend(&_25210, _25209, _25208);
    }
    else {
        Concat((object_ptr)&_25210, _25208, _25209);
        DeRef(_25208);
        _25208 = NOVALUE;
    }
    DeRef(_25208);
    _25208 = NOVALUE;
    _0 = _15canonical_path(_25210, 0, 0);
    DeRefDS(_49coverage_db_name_48140);
    _49coverage_db_name_48140 = _0;
    _25210 = NOVALUE;
L4: 
    DeRef(_cmd_48174);
    _cmd_48174 = NOVALUE;

    /** 	if coverage_erase and file_exists( coverage_db_name ) then*/
    if (_49coverage_erase_48141 == 0) {
        goto L5; // [111] 151
    }
    RefDS(_49coverage_db_name_48140);
    _25213 = _15file_exists(_49coverage_db_name_48140);
    if (_25213 == 0) {
        DeRef(_25213);
        _25213 = NOVALUE;
        goto L5; // [122] 151
    }
    else {
        if (!IS_ATOM_INT(_25213) && DBL_PTR(_25213)->dbl == 0.0){
            DeRef(_25213);
            _25213 = NOVALUE;
            goto L5; // [122] 151
        }
        DeRef(_25213);
        _25213 = NOVALUE;
    }
    DeRef(_25213);
    _25213 = NOVALUE;

    /** 		if not delete_file( coverage_db_name ) then*/
    RefDS(_49coverage_db_name_48140);
    _25214 = _15delete_file(_49coverage_db_name_48140);
    if (IS_ATOM_INT(_25214)) {
        if (_25214 != 0){
            DeRef(_25214);
            _25214 = NOVALUE;
            goto L6; // [133] 150
        }
    }
    else {
        if (DBL_PTR(_25214)->dbl != 0.0){
            DeRef(_25214);
            _25214 = NOVALUE;
            goto L6; // [133] 150
        }
    }
    DeRef(_25214);
    _25214 = NOVALUE;

    /** 			CompileErr( 335, { coverage_db_name } )*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_49coverage_db_name_48140);
    *((int *)(_2+4)) = _49coverage_db_name_48140;
    _25216 = MAKE_SEQ(_1);
    _43CompileErr(335, _25216, 0);
    _25216 = NOVALUE;
L6: 
L5: 

    /** 	if db_open( coverage_db_name ) = DB_OK then*/
    RefDS(_49coverage_db_name_48140);
    _25217 = _48db_open(_49coverage_db_name_48140, 0);
    if (binary_op_a(NOTEQ, _25217, 0)){
        DeRef(_25217);
        _25217 = NOVALUE;
        goto L7; // [162] 175
    }
    DeRef(_25217);
    _25217 = NOVALUE;

    /** 		read_coverage_db()*/
    _49read_coverage_db();

    /** 		db_close()*/
    _48db_close();
L7: 

    /** end procedure*/
    return;
    ;
}


void _49write_map(int _coverage_48203, int _table_name_48204)
{
    int _keys_48226 = NOVALUE;
    int _rec_48231 = NOVALUE;
    int _val_48235 = NOVALUE;
    int _31666 = NOVALUE;
    int _25234 = NOVALUE;
    int _25231 = NOVALUE;
    int _25229 = NOVALUE;
    int _25228 = NOVALUE;
    int _25226 = NOVALUE;
    int _25225 = NOVALUE;
    int _25223 = NOVALUE;
    int _25221 = NOVALUE;
    int _25219 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if db_select( coverage_db_name, DB_LOCK_EXCLUSIVE) = DB_OK then*/
    RefDS(_49coverage_db_name_48140);
    _25219 = _48db_select(_49coverage_db_name_48140, 2);
    if (binary_op_a(NOTEQ, _25219, 0)){
        DeRef(_25219);
        _25219 = NOVALUE;
        goto L1; // [16] 61
    }
    DeRef(_25219);
    _25219 = NOVALUE;

    /** 		if db_select_table( table_name ) != DB_OK then*/
    RefDS(_table_name_48204);
    _25221 = _48db_select_table(_table_name_48204);
    if (binary_op_a(EQUALS, _25221, 0)){
        DeRef(_25221);
        _25221 = NOVALUE;
        goto L2; // [28] 73
    }
    DeRef(_25221);
    _25221 = NOVALUE;

    /** 			if db_create_table( table_name ) != DB_OK then*/
    RefDS(_table_name_48204);
    _25223 = _48db_create_table(_table_name_48204, 50);
    if (binary_op_a(EQUALS, _25223, 0)){
        DeRef(_25223);
        _25223 = NOVALUE;
        goto L2; // [41] 73
    }
    DeRef(_25223);
    _25223 = NOVALUE;

    /** 				CompileErr( 336, {table_name} )*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_table_name_48204);
    *((int *)(_2+4)) = _table_name_48204;
    _25225 = MAKE_SEQ(_1);
    _43CompileErr(336, _25225, 0);
    _25225 = NOVALUE;
    goto L2; // [58] 73
L1: 

    /** 		CompileErr( 336, {table_name} )*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_table_name_48204);
    *((int *)(_2+4)) = _table_name_48204;
    _25226 = MAKE_SEQ(_1);
    _43CompileErr(336, _25226, 0);
    _25226 = NOVALUE;
L2: 

    /** 	sequence keys = map:keys( coverage )*/
    Ref(_coverage_48203);
    _0 = _keys_48226;
    _keys_48226 = _32keys(_coverage_48203, 0);
    DeRef(_0);

    /** 	for i = 1 to length( keys ) do*/
    if (IS_SEQUENCE(_keys_48226)){
            _25228 = SEQ_PTR(_keys_48226)->length;
    }
    else {
        _25228 = 1;
    }
    {
        int _i_48229;
        _i_48229 = 1;
L3: 
        if (_i_48229 > _25228){
            goto L4; // [87] 167
        }

        /** 		integer rec = db_find_key( keys[i] )*/
        _2 = (int)SEQ_PTR(_keys_48226);
        _25229 = (int)*(((s1_ptr)_2)->base + _i_48229);
        Ref(_25229);
        RefDS(_48current_table_name_17398);
        _rec_48231 = _48db_find_key(_25229, _48current_table_name_17398);
        _25229 = NOVALUE;
        if (!IS_ATOM_INT(_rec_48231)) {
            _1 = (long)(DBL_PTR(_rec_48231)->dbl);
            DeRefDS(_rec_48231);
            _rec_48231 = _1;
        }

        /** 		integer val = map:get( coverage, keys[i] )*/
        _2 = (int)SEQ_PTR(_keys_48226);
        _25231 = (int)*(((s1_ptr)_2)->base + _i_48229);
        Ref(_coverage_48203);
        Ref(_25231);
        _val_48235 = _32get(_coverage_48203, _25231, 0);
        _25231 = NOVALUE;
        if (!IS_ATOM_INT(_val_48235)) {
            _1 = (long)(DBL_PTR(_val_48235)->dbl);
            DeRefDS(_val_48235);
            _val_48235 = _1;
        }

        /** 		if rec > 0 then*/
        if (_rec_48231 <= 0)
        goto L5; // [125] 141

        /** 			db_replace_data( rec, val )*/
        RefDS(_48current_table_name_17398);
        _48db_replace_data(_rec_48231, _val_48235, _48current_table_name_17398);
        goto L6; // [138] 158
L5: 

        /** 			db_insert( keys[i], val )*/
        _2 = (int)SEQ_PTR(_keys_48226);
        _25234 = (int)*(((s1_ptr)_2)->base + _i_48229);
        Ref(_25234);
        RefDS(_48current_table_name_17398);
        _31666 = _48db_insert(_25234, _val_48235, _48current_table_name_17398);
        _25234 = NOVALUE;
        DeRef(_31666);
        _31666 = NOVALUE;
L6: 

        /** 	end for*/
        _i_48229 = _i_48229 + 1;
        goto L3; // [162] 94
L4: 
        ;
    }

    /** end procedure*/
    DeRef(_coverage_48203);
    DeRefDS(_table_name_48204);
    DeRef(_keys_48226);
    return;
    ;
}


int _49write_coverage_db()
{
    int _25249 = NOVALUE;
    int _25248 = NOVALUE;
    int _25247 = NOVALUE;
    int _25246 = NOVALUE;
    int _25245 = NOVALUE;
    int _25244 = NOVALUE;
    int _25243 = NOVALUE;
    int _25242 = NOVALUE;
    int _25239 = NOVALUE;
    int _25237 = NOVALUE;
    int _25235 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if wrote_coverage then*/
    if (_49wrote_coverage_48244 == 0)
    {
        goto L1; // [5] 15
    }
    else{
    }

    /** 		return 1*/
    return 1;
L1: 

    /** 	wrote_coverage = 1*/
    _49wrote_coverage_48244 = 1;

    /** 	init_coverage()*/
    _49init_coverage();

    /** 	if not length( covered_files ) then*/
    if (IS_SEQUENCE(_49covered_files_48138)){
            _25235 = SEQ_PTR(_49covered_files_48138)->length;
    }
    else {
        _25235 = 1;
    }
    if (_25235 != 0)
    goto L2; // [31] 41
    _25235 = NOVALUE;

    /** 		return 1*/
    return 1;
L2: 

    /** 	if DB_OK != db_open( coverage_db_name, DB_LOCK_EXCLUSIVE) then*/
    RefDS(_49coverage_db_name_48140);
    _25237 = _48db_open(_49coverage_db_name_48140, 2);
    if (binary_op_a(EQUALS, 0, _25237)){
        DeRef(_25237);
        _25237 = NOVALUE;
        goto L3; // [54] 95
    }
    DeRef(_25237);
    _25237 = NOVALUE;

    /** 		if DB_OK != db_create( coverage_db_name ) then*/
    RefDS(_49coverage_db_name_48140);
    _25239 = _48db_create(_49coverage_db_name_48140, 0, 5, 5);
    if (binary_op_a(EQUALS, 0, _25239)){
        DeRef(_25239);
        _25239 = NOVALUE;
        goto L4; // [71] 94
    }
    DeRef(_25239);
    _25239 = NOVALUE;

    /** 			printf(2, "error opening %s\n", {coverage_db_name})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_49coverage_db_name_48140);
    *((int *)(_2+4)) = _49coverage_db_name_48140;
    _25242 = MAKE_SEQ(_1);
    EPrintf(2, _25241, _25242);
    DeRefDS(_25242);
    _25242 = NOVALUE;

    /** 			return 0*/
    return 0;
L4: 
L3: 

    /** 	process_lines()*/
    _49process_lines();

    /** 	for tx = 1 to length( routine_map ) do*/
    if (IS_SEQUENCE(_49routine_map_48144)){
            _25243 = SEQ_PTR(_49routine_map_48144)->length;
    }
    else {
        _25243 = 1;
    }
    {
        int _tx_48266;
        _tx_48266 = 1;
L5: 
        if (_tx_48266 > _25243){
            goto L6; // [106] 164
        }

        /** 		write_map( routine_map[tx], 'r' & covered_files[tx] )*/
        _2 = (int)SEQ_PTR(_49routine_map_48144);
        _25244 = (int)*(((s1_ptr)_2)->base + _tx_48266);
        _2 = (int)SEQ_PTR(_49covered_files_48138);
        _25245 = (int)*(((s1_ptr)_2)->base + _tx_48266);
        if (IS_SEQUENCE(114) && IS_ATOM(_25245)) {
        }
        else if (IS_ATOM(114) && IS_SEQUENCE(_25245)) {
            Prepend(&_25246, _25245, 114);
        }
        else {
            Concat((object_ptr)&_25246, 114, _25245);
        }
        _25245 = NOVALUE;
        Ref(_25244);
        _49write_map(_25244, _25246);
        _25244 = NOVALUE;
        _25246 = NOVALUE;

        /** 		write_map( line_map[tx],    'l' & covered_files[tx] )*/
        _2 = (int)SEQ_PTR(_49line_map_48143);
        _25247 = (int)*(((s1_ptr)_2)->base + _tx_48266);
        _2 = (int)SEQ_PTR(_49covered_files_48138);
        _25248 = (int)*(((s1_ptr)_2)->base + _tx_48266);
        if (IS_SEQUENCE(108) && IS_ATOM(_25248)) {
        }
        else if (IS_ATOM(108) && IS_SEQUENCE(_25248)) {
            Prepend(&_25249, _25248, 108);
        }
        else {
            Concat((object_ptr)&_25249, 108, _25248);
        }
        _25248 = NOVALUE;
        Ref(_25247);
        _49write_map(_25247, _25249);
        _25247 = NOVALUE;
        _25249 = NOVALUE;

        /** 	end for*/
        _tx_48266 = _tx_48266 + 1;
        goto L5; // [159] 113
L6: 
        ;
    }

    /** 	db_close()*/
    _48db_close();

    /** 	routine_map = {}*/
    RefDS(_22037);
    DeRef(_49routine_map_48144);
    _49routine_map_48144 = _22037;

    /** 	line_map    = {}*/
    RefDS(_22037);
    DeRef(_49line_map_48143);
    _49line_map_48143 = _22037;

    /** 	return 1*/
    return 1;
    ;
}


void _49read_coverage_db()
{
    int _tables_48277 = NOVALUE;
    int _name_48283 = NOVALUE;
    int _fx_48287 = NOVALUE;
    int _the_map_48294 = NOVALUE;
    int _31665 = NOVALUE;
    int _25265 = NOVALUE;
    int _25264 = NOVALUE;
    int _25263 = NOVALUE;
    int _25259 = NOVALUE;
    int _25258 = NOVALUE;
    int _25257 = NOVALUE;
    int _25253 = NOVALUE;
    int _25252 = NOVALUE;
    int _25251 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence tables = db_table_list()*/
    _0 = _tables_48277;
    _tables_48277 = _48db_table_list();
    DeRef(_0);

    /** 	for i = 1 to length( tables ) do*/
    if (IS_SEQUENCE(_tables_48277)){
            _25251 = SEQ_PTR(_tables_48277)->length;
    }
    else {
        _25251 = 1;
    }
    {
        int _i_48281;
        _i_48281 = 1;
L1: 
        if (_i_48281 > _25251){
            goto L2; // [13] 159
        }

        /** 		sequence name = tables[i][2..$]*/
        _2 = (int)SEQ_PTR(_tables_48277);
        _25252 = (int)*(((s1_ptr)_2)->base + _i_48281);
        if (IS_SEQUENCE(_25252)){
                _25253 = SEQ_PTR(_25252)->length;
        }
        else {
            _25253 = 1;
        }
        rhs_slice_target = (object_ptr)&_name_48283;
        RHS_Slice(_25252, 2, _25253);
        _25252 = NOVALUE;

        /** 		integer fx = find( name, covered_files )*/
        _fx_48287 = find_from(_name_48283, _49covered_files_48138, 1);

        /** 		if not fx then*/
        if (_fx_48287 != 0)
        goto L3; // [45] 55

        /** 			continue*/
        DeRefDS(_name_48283);
        _name_48283 = NOVALUE;
        DeRef(_the_map_48294);
        _the_map_48294 = NOVALUE;
        goto L4; // [52] 154
L3: 

        /** 		db_select_table( tables[i] )*/
        _2 = (int)SEQ_PTR(_tables_48277);
        _25257 = (int)*(((s1_ptr)_2)->base + _i_48281);
        Ref(_25257);
        _31665 = _48db_select_table(_25257);
        _25257 = NOVALUE;
        DeRef(_31665);
        _31665 = NOVALUE;

        /** 		if tables[i][1] = 'r' then*/
        _2 = (int)SEQ_PTR(_tables_48277);
        _25258 = (int)*(((s1_ptr)_2)->base + _i_48281);
        _2 = (int)SEQ_PTR(_25258);
        _25259 = (int)*(((s1_ptr)_2)->base + 1);
        _25258 = NOVALUE;
        if (binary_op_a(NOTEQ, _25259, 114)){
            _25259 = NOVALUE;
            goto L5; // [77] 92
        }
        _25259 = NOVALUE;

        /** 			the_map = routine_map[fx]*/
        DeRef(_the_map_48294);
        _2 = (int)SEQ_PTR(_49routine_map_48144);
        _the_map_48294 = (int)*(((s1_ptr)_2)->base + _fx_48287);
        Ref(_the_map_48294);
        goto L6; // [89] 101
L5: 

        /** 			the_map = line_map[fx]*/
        DeRef(_the_map_48294);
        _2 = (int)SEQ_PTR(_49line_map_48143);
        _the_map_48294 = (int)*(((s1_ptr)_2)->base + _fx_48287);
        Ref(_the_map_48294);
L6: 

        /** 		for j = 1 to db_table_size() do*/
        RefDS(_48current_table_name_17398);
        _25263 = _48db_table_size(_48current_table_name_17398);
        {
            int _j_48303;
            _j_48303 = 1;
L7: 
            if (binary_op_a(GREATER, _j_48303, _25263)){
                goto L8; // [109] 150
            }

            /** 			map:put( the_map, db_record_key( j ), db_record_data( j ), map:ADD )*/
            Ref(_j_48303);
            RefDS(_48current_table_name_17398);
            _25264 = _48db_record_key(_j_48303, _48current_table_name_17398);
            Ref(_j_48303);
            RefDS(_48current_table_name_17398);
            _25265 = _48db_record_data(_j_48303, _48current_table_name_17398);
            Ref(_the_map_48294);
            _32put(_the_map_48294, _25264, _25265, 2, 23);
            _25264 = NOVALUE;
            _25265 = NOVALUE;

            /** 		end for*/
            _0 = _j_48303;
            if (IS_ATOM_INT(_j_48303)) {
                _j_48303 = _j_48303 + 1;
                if ((long)((unsigned long)_j_48303 +(unsigned long) HIGH_BITS) >= 0){
                    _j_48303 = NewDouble((double)_j_48303);
                }
            }
            else {
                _j_48303 = binary_op_a(PLUS, _j_48303, 1);
            }
            DeRef(_0);
            goto L7; // [145] 116
L8: 
            ;
            DeRef(_j_48303);
        }
        DeRef(_name_48283);
        _name_48283 = NOVALUE;
        DeRef(_the_map_48294);
        _the_map_48294 = NOVALUE;

        /** 	end for*/
L4: 
        _i_48281 = _i_48281 + 1;
        goto L1; // [154] 20
L2: 
        ;
    }

    /** end procedure*/
    DeRef(_tables_48277);
    DeRef(_25263);
    _25263 = NOVALUE;
    return;
    ;
}


void _49coverage_db(int _name_48312)
{
    int _0, _1, _2;
    

    /** 	coverage_db_name = name*/
    RefDS(_name_48312);
    DeRef(_49coverage_db_name_48140);
    _49coverage_db_name_48140 = _name_48312;

    /** end procedure*/
    DeRefDS(_name_48312);
    return;
    ;
}


int _49coverage_on()
{
    int _25266 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return file_coverage[current_file_no]*/
    _2 = (int)SEQ_PTR(_49file_coverage_48139);
    _25266 = (int)*(((s1_ptr)_2)->base + _26current_file_no_11982);
    return _25266;
    ;
}


void _49new_covered_path(int _name_48324)
{
    int _25272 = NOVALUE;
    int _25270 = NOVALUE;
    int _0, _1, _2;
    

    /** 	covered_files = append( covered_files, name )*/
    RefDS(_name_48324);
    Append(&_49covered_files_48138, _49covered_files_48138, _name_48324);

    /** 	routine_map &= map:new()*/
    _25270 = _32new(690);
    if (IS_SEQUENCE(_49routine_map_48144) && IS_ATOM(_25270)) {
        Ref(_25270);
        Append(&_49routine_map_48144, _49routine_map_48144, _25270);
    }
    else if (IS_ATOM(_49routine_map_48144) && IS_SEQUENCE(_25270)) {
    }
    else {
        Concat((object_ptr)&_49routine_map_48144, _49routine_map_48144, _25270);
    }
    DeRef(_25270);
    _25270 = NOVALUE;

    /** 	line_map    &= map:new()*/
    _25272 = _32new(690);
    if (IS_SEQUENCE(_49line_map_48143) && IS_ATOM(_25272)) {
        Ref(_25272);
        Append(&_49line_map_48143, _49line_map_48143, _25272);
    }
    else if (IS_ATOM(_49line_map_48143) && IS_SEQUENCE(_25272)) {
    }
    else {
        Concat((object_ptr)&_49line_map_48143, _49line_map_48143, _25272);
    }
    DeRef(_25272);
    _25272 = NOVALUE;

    /** end procedure*/
    DeRefDS(_name_48324);
    return;
    ;
}


void _49add_coverage(int _cover_this_48332)
{
    int _path_48333 = NOVALUE;
    int _files_48342 = NOVALUE;
    int _subpath_48370 = NOVALUE;
    int _25307 = NOVALUE;
    int _25306 = NOVALUE;
    int _25305 = NOVALUE;
    int _25304 = NOVALUE;
    int _25303 = NOVALUE;
    int _25302 = NOVALUE;
    int _25301 = NOVALUE;
    int _25300 = NOVALUE;
    int _25299 = NOVALUE;
    int _25298 = NOVALUE;
    int _25297 = NOVALUE;
    int _25296 = NOVALUE;
    int _25294 = NOVALUE;
    int _25293 = NOVALUE;
    int _25292 = NOVALUE;
    int _25291 = NOVALUE;
    int _25290 = NOVALUE;
    int _25289 = NOVALUE;
    int _25288 = NOVALUE;
    int _25287 = NOVALUE;
    int _25285 = NOVALUE;
    int _25284 = NOVALUE;
    int _25283 = NOVALUE;
    int _25282 = NOVALUE;
    int _25281 = NOVALUE;
    int _25280 = NOVALUE;
    int _25279 = NOVALUE;
    int _25278 = NOVALUE;
    int _25275 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence path = canonical_path( cover_this,, CORRECT )*/
    RefDS(_cover_this_48332);
    _0 = _path_48333;
    _path_48333 = _15canonical_path(_cover_this_48332, 0, 2);
    DeRef(_0);

    /** 	if file_type( path ) = FILETYPE_DIRECTORY then*/
    RefDS(_path_48333);
    _25275 = _15file_type(_path_48333);
    if (binary_op_a(NOTEQ, _25275, 2)){
        DeRef(_25275);
        _25275 = NOVALUE;
        goto L1; // [23] 211
    }
    DeRef(_25275);
    _25275 = NOVALUE;

    /** 		sequence files = dir( path  )*/
    RefDS(_path_48333);
    _0 = _files_48342;
    _files_48342 = _15dir(_path_48333);
    DeRef(_0);

    /** 		for i = 1 to length( files ) do*/
    if (IS_SEQUENCE(_files_48342)){
            _25278 = SEQ_PTR(_files_48342)->length;
    }
    else {
        _25278 = 1;
    }
    {
        int _i_48346;
        _i_48346 = 1;
L2: 
        if (_i_48346 > _25278){
            goto L3; // [40] 206
        }

        /** 			if find( 'd', files[i][D_ATTRIBUTES] ) then*/
        _2 = (int)SEQ_PTR(_files_48342);
        _25279 = (int)*(((s1_ptr)_2)->base + _i_48346);
        _2 = (int)SEQ_PTR(_25279);
        _25280 = (int)*(((s1_ptr)_2)->base + 2);
        _25279 = NOVALUE;
        _25281 = find_from(100, _25280, 1);
        _25280 = NOVALUE;
        if (_25281 == 0)
        {
            _25281 = NOVALUE;
            goto L4; // [64] 118
        }
        else{
            _25281 = NOVALUE;
        }

        /** 				if not eu:find(files[i][D_NAME], {".", ".."}) then*/
        _2 = (int)SEQ_PTR(_files_48342);
        _25282 = (int)*(((s1_ptr)_2)->base + _i_48346);
        _2 = (int)SEQ_PTR(_25282);
        _25283 = (int)*(((s1_ptr)_2)->base + 1);
        _25282 = NOVALUE;
        RefDS(_23110);
        RefDS(_23111);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _23111;
        ((int *)_2)[2] = _23110;
        _25284 = MAKE_SEQ(_1);
        _25285 = find_from(_25283, _25284, 1);
        _25283 = NOVALUE;
        DeRefDS(_25284);
        _25284 = NOVALUE;
        if (_25285 != 0)
        goto L5; // [88] 199
        _25285 = NOVALUE;

        /** 					add_coverage( cover_this & SLASH & files[i][D_NAME] )*/
        _2 = (int)SEQ_PTR(_files_48342);
        _25287 = (int)*(((s1_ptr)_2)->base + _i_48346);
        _2 = (int)SEQ_PTR(_25287);
        _25288 = (int)*(((s1_ptr)_2)->base + 1);
        _25287 = NOVALUE;
        {
            int concat_list[3];

            concat_list[0] = _25288;
            concat_list[1] = 92;
            concat_list[2] = _cover_this_48332;
            Concat_N((object_ptr)&_25289, concat_list, 3);
        }
        _25288 = NOVALUE;
        _49add_coverage(_25289);
        _25289 = NOVALUE;
        goto L5; // [115] 199
L4: 

        /** 			elsif regex:has_match( eu_file, files[i][D_NAME] ) then*/
        _2 = (int)SEQ_PTR(_files_48342);
        _25290 = (int)*(((s1_ptr)_2)->base + _i_48346);
        _2 = (int)SEQ_PTR(_25290);
        _25291 = (int)*(((s1_ptr)_2)->base + 1);
        _25290 = NOVALUE;
        Ref(_49eu_file_48318);
        Ref(_25291);
        _25292 = _50has_match(_49eu_file_48318, _25291, 1, 0);
        _25291 = NOVALUE;
        if (_25292 == 0) {
            DeRef(_25292);
            _25292 = NOVALUE;
            goto L6; // [139] 196
        }
        else {
            if (!IS_ATOM_INT(_25292) && DBL_PTR(_25292)->dbl == 0.0){
                DeRef(_25292);
                _25292 = NOVALUE;
                goto L6; // [139] 196
            }
            DeRef(_25292);
            _25292 = NOVALUE;
        }
        DeRef(_25292);
        _25292 = NOVALUE;

        /** 				sequence subpath = path & SLASH & files[i][D_NAME]*/
        _2 = (int)SEQ_PTR(_files_48342);
        _25293 = (int)*(((s1_ptr)_2)->base + _i_48346);
        _2 = (int)SEQ_PTR(_25293);
        _25294 = (int)*(((s1_ptr)_2)->base + 1);
        _25293 = NOVALUE;
        {
            int concat_list[3];

            concat_list[0] = _25294;
            concat_list[1] = 92;
            concat_list[2] = _path_48333;
            Concat_N((object_ptr)&_subpath_48370, concat_list, 3);
        }
        _25294 = NOVALUE;

        /** 				if not find( subpath, covered_files ) and not excluded( subpath ) then*/
        _25296 = find_from(_subpath_48370, _49covered_files_48138, 1);
        _25297 = (_25296 == 0);
        _25296 = NOVALUE;
        if (_25297 == 0) {
            goto L7; // [174] 195
        }
        RefDS(_subpath_48370);
        _25299 = _49excluded(_subpath_48370);
        if (IS_ATOM_INT(_25299)) {
            _25300 = (_25299 == 0);
        }
        else {
            _25300 = unary_op(NOT, _25299);
        }
        DeRef(_25299);
        _25299 = NOVALUE;
        if (_25300 == 0) {
            DeRef(_25300);
            _25300 = NOVALUE;
            goto L7; // [186] 195
        }
        else {
            if (!IS_ATOM_INT(_25300) && DBL_PTR(_25300)->dbl == 0.0){
                DeRef(_25300);
                _25300 = NOVALUE;
                goto L7; // [186] 195
            }
            DeRef(_25300);
            _25300 = NOVALUE;
        }
        DeRef(_25300);
        _25300 = NOVALUE;

        /** 					new_covered_path( subpath )*/
        RefDS(_subpath_48370);
        _49new_covered_path(_subpath_48370);
L7: 
L6: 
        DeRef(_subpath_48370);
        _subpath_48370 = NOVALUE;
L5: 

        /** 		end for*/
        _i_48346 = _i_48346 + 1;
        goto L2; // [201] 47
L3: 
        ;
    }
    DeRef(_files_48342);
    _files_48342 = NOVALUE;
    goto L8; // [208] 262
L1: 

    /** 	elsif regex:has_match( eu_file, path ) and*/
    Ref(_49eu_file_48318);
    RefDS(_path_48333);
    _25301 = _50has_match(_49eu_file_48318, _path_48333, 1, 0);
    if (IS_ATOM_INT(_25301)) {
        if (_25301 == 0) {
            DeRef(_25302);
            _25302 = 0;
            goto L9; // [222] 240
        }
    }
    else {
        if (DBL_PTR(_25301)->dbl == 0.0) {
            DeRef(_25302);
            _25302 = 0;
            goto L9; // [222] 240
        }
    }
    _25303 = find_from(_path_48333, _49covered_files_48138, 1);
    _25304 = (_25303 == 0);
    _25303 = NOVALUE;
    DeRef(_25302);
    _25302 = (_25304 != 0);
L9: 
    if (_25302 == 0) {
        goto LA; // [240] 261
    }
    RefDS(_path_48333);
    _25306 = _49excluded(_path_48333);
    if (IS_ATOM_INT(_25306)) {
        _25307 = (_25306 == 0);
    }
    else {
        _25307 = unary_op(NOT, _25306);
    }
    DeRef(_25306);
    _25306 = NOVALUE;
    if (_25307 == 0) {
        DeRef(_25307);
        _25307 = NOVALUE;
        goto LA; // [252] 261
    }
    else {
        if (!IS_ATOM_INT(_25307) && DBL_PTR(_25307)->dbl == 0.0){
            DeRef(_25307);
            _25307 = NOVALUE;
            goto LA; // [252] 261
        }
        DeRef(_25307);
        _25307 = NOVALUE;
    }
    DeRef(_25307);
    _25307 = NOVALUE;

    /** 		new_covered_path( path )*/
    RefDS(_path_48333);
    _49new_covered_path(_path_48333);
LA: 
L8: 

    /** end procedure*/
    DeRefDS(_cover_this_48332);
    DeRef(_path_48333);
    DeRef(_25297);
    _25297 = NOVALUE;
    DeRef(_25301);
    _25301 = NOVALUE;
    DeRef(_25304);
    _25304 = NOVALUE;
    return;
    ;
}


int _49excluded(int _file_48394)
{
    int _25310 = NOVALUE;
    int _25309 = NOVALUE;
    int _25308 = NOVALUE;
    int _0, _1, _2;
    

    /** 	for i = 1 to length( exclusion_patterns ) do*/
    if (IS_SEQUENCE(_49exclusion_patterns_48142)){
            _25308 = SEQ_PTR(_49exclusion_patterns_48142)->length;
    }
    else {
        _25308 = 1;
    }
    {
        int _i_48396;
        _i_48396 = 1;
L1: 
        if (_i_48396 > _25308){
            goto L2; // [10] 49
        }

        /** 		if regex:has_match( exclusion_patterns[i], file ) then*/
        _2 = (int)SEQ_PTR(_49exclusion_patterns_48142);
        _25309 = (int)*(((s1_ptr)_2)->base + _i_48396);
        Ref(_25309);
        RefDS(_file_48394);
        _25310 = _50has_match(_25309, _file_48394, 1, 0);
        _25309 = NOVALUE;
        if (_25310 == 0) {
            DeRef(_25310);
            _25310 = NOVALUE;
            goto L3; // [32] 42
        }
        else {
            if (!IS_ATOM_INT(_25310) && DBL_PTR(_25310)->dbl == 0.0){
                DeRef(_25310);
                _25310 = NOVALUE;
                goto L3; // [32] 42
            }
            DeRef(_25310);
            _25310 = NOVALUE;
        }
        DeRef(_25310);
        _25310 = NOVALUE;

        /** 			return 1*/
        DeRefDS(_file_48394);
        return 1;
L3: 

        /** 	end for*/
        _i_48396 = _i_48396 + 1;
        goto L1; // [44] 17
L2: 
        ;
    }

    /** 	return 0*/
    DeRefDS(_file_48394);
    return 0;
    ;
}


void _49coverage_exclude(int _patterns_48403)
{
    int _ex_48408 = NOVALUE;
    int _fx_48415 = NOVALUE;
    int _25328 = NOVALUE;
    int _25327 = NOVALUE;
    int _25326 = NOVALUE;
    int _25325 = NOVALUE;
    int _25319 = NOVALUE;
    int _25318 = NOVALUE;
    int _25316 = NOVALUE;
    int _25314 = NOVALUE;
    int _25312 = NOVALUE;
    int _25311 = NOVALUE;
    int _0, _1, _2;
    

    /** 	for i = 1 to length( patterns ) do*/
    if (IS_SEQUENCE(_patterns_48403)){
            _25311 = SEQ_PTR(_patterns_48403)->length;
    }
    else {
        _25311 = 1;
    }
    {
        int _i_48405;
        _i_48405 = 1;
L1: 
        if (_i_48405 > _25311){
            goto L2; // [8] 161
        }

        /** 		regex ex = regex:new( patterns[i] )*/
        _2 = (int)SEQ_PTR(_patterns_48403);
        _25312 = (int)*(((s1_ptr)_2)->base + _i_48405);
        Ref(_25312);
        _0 = _ex_48408;
        _ex_48408 = _50new(_25312, 0);
        DeRef(_0);
        _25312 = NOVALUE;

        /** 		if regex( ex ) then*/
        Ref(_ex_48408);
        _25314 = _50regex(_ex_48408);
        if (_25314 == 0) {
            DeRef(_25314);
            _25314 = NOVALUE;
            goto L3; // [32] 127
        }
        else {
            if (!IS_ATOM_INT(_25314) && DBL_PTR(_25314)->dbl == 0.0){
                DeRef(_25314);
                _25314 = NOVALUE;
                goto L3; // [32] 127
            }
            DeRef(_25314);
            _25314 = NOVALUE;
        }
        DeRef(_25314);
        _25314 = NOVALUE;

        /** 			exclusion_patterns = append( exclusion_patterns, ex )*/
        Ref(_ex_48408);
        Append(&_49exclusion_patterns_48142, _49exclusion_patterns_48142, _ex_48408);

        /** 			integer fx = 1*/
        _fx_48415 = 1;

        /** 			while fx <= length( covered_files ) do*/
L4: 
        if (IS_SEQUENCE(_49covered_files_48138)){
                _25316 = SEQ_PTR(_49covered_files_48138)->length;
        }
        else {
            _25316 = 1;
        }
        if (_fx_48415 > _25316)
        goto L5; // [58] 122

        /** 				if regex:has_match( ex, covered_files[fx] ) then*/
        _2 = (int)SEQ_PTR(_49covered_files_48138);
        _25318 = (int)*(((s1_ptr)_2)->base + _fx_48415);
        Ref(_ex_48408);
        Ref(_25318);
        _25319 = _50has_match(_ex_48408, _25318, 1, 0);
        _25318 = NOVALUE;
        if (_25319 == 0) {
            DeRef(_25319);
            _25319 = NOVALUE;
            goto L6; // [77] 110
        }
        else {
            if (!IS_ATOM_INT(_25319) && DBL_PTR(_25319)->dbl == 0.0){
                DeRef(_25319);
                _25319 = NOVALUE;
                goto L6; // [77] 110
            }
            DeRef(_25319);
            _25319 = NOVALUE;
        }
        DeRef(_25319);
        _25319 = NOVALUE;

        /** 					covered_files = remove( covered_files, fx )*/
        {
            s1_ptr assign_space = SEQ_PTR(_49covered_files_48138);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_fx_48415)) ? _fx_48415 : (long)(DBL_PTR(_fx_48415)->dbl);
            int stop = (IS_ATOM_INT(_fx_48415)) ? _fx_48415 : (long)(DBL_PTR(_fx_48415)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<0) {
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_49covered_files_48138), start, &_49covered_files_48138 );
                }
                else Tail(SEQ_PTR(_49covered_files_48138), stop+1, &_49covered_files_48138);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_49covered_files_48138), start, &_49covered_files_48138);
            }
            else {
                assign_slice_seq = &assign_space;
                _49covered_files_48138 = Remove_elements(start, stop, (SEQ_PTR(_49covered_files_48138)->ref == 1));
            }
        }

        /** 					routine_map   = remove( routine_map, fx )*/
        {
            s1_ptr assign_space = SEQ_PTR(_49routine_map_48144);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_fx_48415)) ? _fx_48415 : (long)(DBL_PTR(_fx_48415)->dbl);
            int stop = (IS_ATOM_INT(_fx_48415)) ? _fx_48415 : (long)(DBL_PTR(_fx_48415)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<0) {
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_49routine_map_48144), start, &_49routine_map_48144 );
                }
                else Tail(SEQ_PTR(_49routine_map_48144), stop+1, &_49routine_map_48144);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_49routine_map_48144), start, &_49routine_map_48144);
            }
            else {
                assign_slice_seq = &assign_space;
                _49routine_map_48144 = Remove_elements(start, stop, (SEQ_PTR(_49routine_map_48144)->ref == 1));
            }
        }

        /** 					line_map      = remove( line_map, fx )*/
        {
            s1_ptr assign_space = SEQ_PTR(_49line_map_48143);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_fx_48415)) ? _fx_48415 : (long)(DBL_PTR(_fx_48415)->dbl);
            int stop = (IS_ATOM_INT(_fx_48415)) ? _fx_48415 : (long)(DBL_PTR(_fx_48415)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<0) {
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_49line_map_48143), start, &_49line_map_48143 );
                }
                else Tail(SEQ_PTR(_49line_map_48143), stop+1, &_49line_map_48143);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_49line_map_48143), start, &_49line_map_48143);
            }
            else {
                assign_slice_seq = &assign_space;
                _49line_map_48143 = Remove_elements(start, stop, (SEQ_PTR(_49line_map_48143)->ref == 1));
            }
        }
        goto L4; // [107] 53
L6: 

        /** 					fx += 1*/
        _fx_48415 = _fx_48415 + 1;

        /** 			end while*/
        goto L4; // [119] 53
L5: 
        goto L7; // [124] 152
L3: 

        /** 			printf( 2,"%s\n", { GetMsgText( 339, 1, {patterns[i]}) } )*/
        _2 = (int)SEQ_PTR(_patterns_48403);
        _25325 = (int)*(((s1_ptr)_2)->base + _i_48405);
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        Ref(_25325);
        *((int *)(_2+4)) = _25325;
        _25326 = MAKE_SEQ(_1);
        _25325 = NOVALUE;
        _25327 = _44GetMsgText(339, 1, _25326);
        _25326 = NOVALUE;
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = _25327;
        _25328 = MAKE_SEQ(_1);
        _25327 = NOVALUE;
        EPrintf(2, _25324, _25328);
        DeRefDS(_25328);
        _25328 = NOVALUE;
L7: 
        DeRef(_ex_48408);
        _ex_48408 = NOVALUE;

        /** 	end for*/
        _i_48405 = _i_48405 + 1;
        goto L1; // [156] 15
L2: 
        ;
    }

    /** end procedure*/
    DeRefDS(_patterns_48403);
    return;
    ;
}


void _49new_coverage_db()
{
    int _0, _1, _2;
    

    /** 	coverage_erase = 1*/
    _49coverage_erase_48141 = 1;

    /** end procedure*/
    return;
    ;
}


void _49include_line(int _line_number_48438)
{
    int _25329 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_line_number_48438)) {
        _1 = (long)(DBL_PTR(_line_number_48438)->dbl);
        DeRefDS(_line_number_48438);
        _line_number_48438 = _1;
    }

    /** 	if coverage_on() then*/
    _25329 = _49coverage_on();
    if (_25329 == 0) {
        DeRef(_25329);
        _25329 = NOVALUE;
        goto L1; // [8] 34
    }
    else {
        if (!IS_ATOM_INT(_25329) && DBL_PTR(_25329)->dbl == 0.0){
            DeRef(_25329);
            _25329 = NOVALUE;
            goto L1; // [8] 34
        }
        DeRef(_25329);
        _25329 = NOVALUE;
    }
    DeRef(_25329);
    _25329 = NOVALUE;

    /** 		emit_op( COVERAGE_LINE )*/
    _37emit_op(210);

    /** 		emit_addr( gline_number )*/
    _37emit_addr(_26gline_number_11987);

    /** 		included_lines &= line_number*/
    Append(&_49included_lines_48145, _49included_lines_48145, _line_number_48438);
L1: 

    /** end procedure*/
    return;
    ;
}


void _49include_routine()
{
    int _file_no_48454 = NOVALUE;
    int _25336 = NOVALUE;
    int _25335 = NOVALUE;
    int _25334 = NOVALUE;
    int _25332 = NOVALUE;
    int _25331 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if coverage_on() then*/
    _25331 = _49coverage_on();
    if (_25331 == 0) {
        DeRef(_25331);
        _25331 = NOVALUE;
        goto L1; // [6] 71
    }
    else {
        if (!IS_ATOM_INT(_25331) && DBL_PTR(_25331)->dbl == 0.0){
            DeRef(_25331);
            _25331 = NOVALUE;
            goto L1; // [6] 71
        }
        DeRef(_25331);
        _25331 = NOVALUE;
    }
    DeRef(_25331);
    _25331 = NOVALUE;

    /** 		emit_op( COVERAGE_ROUTINE )*/
    _37emit_op(211);

    /** 		emit_addr( CurrentSub )*/
    _37emit_addr(_26CurrentSub_11990);

    /** 		integer file_no = SymTab[CurrentSub][S_FILE_NO]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _25332 = (int)*(((s1_ptr)_2)->base + _26CurrentSub_11990);
    _2 = (int)SEQ_PTR(_25332);
    if (!IS_ATOM_INT(_26S_FILE_NO_11650)){
        _file_no_48454 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_FILE_NO_11650)->dbl));
    }
    else{
        _file_no_48454 = (int)*(((s1_ptr)_2)->base + _26S_FILE_NO_11650);
    }
    if (!IS_ATOM_INT(_file_no_48454)){
        _file_no_48454 = (long)DBL_PTR(_file_no_48454)->dbl;
    }
    _25332 = NOVALUE;

    /** 		map:put( routine_map[file_coverage[file_no]], sym_name( CurrentSub ), 0, map:ADD )*/
    _2 = (int)SEQ_PTR(_49file_coverage_48139);
    _25334 = (int)*(((s1_ptr)_2)->base + _file_no_48454);
    _2 = (int)SEQ_PTR(_49routine_map_48144);
    _25335 = (int)*(((s1_ptr)_2)->base + _25334);
    _25336 = _52sym_name(_26CurrentSub_11990);
    Ref(_25335);
    _32put(_25335, _25336, 0, 2, 23);
    _25335 = NOVALUE;
    _25336 = NOVALUE;
L1: 

    /** end procedure*/
    _25334 = NOVALUE;
    return;
    ;
}


void _49process_lines()
{
    int _sline_48482 = NOVALUE;
    int _file_48486 = NOVALUE;
    int _line_48496 = NOVALUE;
    int _25354 = NOVALUE;
    int _25352 = NOVALUE;
    int _25351 = NOVALUE;
    int _25350 = NOVALUE;
    int _25349 = NOVALUE;
    int _25348 = NOVALUE;
    int _25346 = NOVALUE;
    int _25344 = NOVALUE;
    int _25343 = NOVALUE;
    int _25341 = NOVALUE;
    int _25340 = NOVALUE;
    int _25339 = NOVALUE;
    int _25337 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not length( included_lines ) then*/
    if (IS_SEQUENCE(_49included_lines_48145)){
            _25337 = SEQ_PTR(_49included_lines_48145)->length;
    }
    else {
        _25337 = 1;
    }
    if (_25337 != 0)
    goto L1; // [8] 17
    _25337 = NOVALUE;

    /** 		return*/
    return;
L1: 

    /** 	if atom(slist[$]) then*/
    if (IS_SEQUENCE(_26slist_12073)){
            _25339 = SEQ_PTR(_26slist_12073)->length;
    }
    else {
        _25339 = 1;
    }
    _2 = (int)SEQ_PTR(_26slist_12073);
    _25340 = (int)*(((s1_ptr)_2)->base + _25339);
    _25341 = IS_ATOM(_25340);
    _25340 = NOVALUE;
    if (_25341 == 0)
    {
        _25341 = NOVALUE;
        goto L2; // [31] 45
    }
    else{
        _25341 = NOVALUE;
    }

    /** 		slist = s_expand( slist )*/
    RefDS(_26slist_12073);
    _0 = _60s_expand(_26slist_12073);
    DeRefDS(_26slist_12073);
    _26slist_12073 = _0;
L2: 

    /** 	for i = 1 to length( included_lines ) do*/
    if (IS_SEQUENCE(_49included_lines_48145)){
            _25343 = SEQ_PTR(_49included_lines_48145)->length;
    }
    else {
        _25343 = 1;
    }
    {
        int _i_48480;
        _i_48480 = 1;
L3: 
        if (_i_48480 > _25343){
            goto L4; // [52] 159
        }

        /** 		sequence sline = slist[included_lines[i]]*/
        _2 = (int)SEQ_PTR(_49included_lines_48145);
        _25344 = (int)*(((s1_ptr)_2)->base + _i_48480);
        DeRef(_sline_48482);
        _2 = (int)SEQ_PTR(_26slist_12073);
        _sline_48482 = (int)*(((s1_ptr)_2)->base + _25344);
        Ref(_sline_48482);

        /** 		integer file = file_coverage[sline[LOCAL_FILE_NO]]*/
        _2 = (int)SEQ_PTR(_sline_48482);
        _25346 = (int)*(((s1_ptr)_2)->base + 3);
        _2 = (int)SEQ_PTR(_49file_coverage_48139);
        if (!IS_ATOM_INT(_25346)){
            _file_48486 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_25346)->dbl));
        }
        else{
            _file_48486 = (int)*(((s1_ptr)_2)->base + _25346);
        }

        /** 		if file and file <= length( line_map ) and line_map[file] then*/
        if (_file_48486 == 0) {
            _25348 = 0;
            goto L5; // [91] 108
        }
        if (IS_SEQUENCE(_49line_map_48143)){
                _25349 = SEQ_PTR(_49line_map_48143)->length;
        }
        else {
            _25349 = 1;
        }
        _25350 = (_file_48486 <= _25349);
        _25349 = NOVALUE;
        _25348 = (_25350 != 0);
L5: 
        if (_25348 == 0) {
            goto L6; // [108] 148
        }
        _2 = (int)SEQ_PTR(_49line_map_48143);
        _25352 = (int)*(((s1_ptr)_2)->base + _file_48486);
        if (_25352 == 0) {
            _25352 = NOVALUE;
            goto L6; // [119] 148
        }
        else {
            if (!IS_ATOM_INT(_25352) && DBL_PTR(_25352)->dbl == 0.0){
                _25352 = NOVALUE;
                goto L6; // [119] 148
            }
            _25352 = NOVALUE;
        }
        _25352 = NOVALUE;

        /** 			integer line = sline[LINE]*/
        _2 = (int)SEQ_PTR(_sline_48482);
        _line_48496 = (int)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_line_48496))
        _line_48496 = (long)DBL_PTR(_line_48496)->dbl;

        /** 			map:put( line_map[file], line, 0, map:ADD )*/
        _2 = (int)SEQ_PTR(_49line_map_48143);
        _25354 = (int)*(((s1_ptr)_2)->base + _file_48486);
        Ref(_25354);
        _32put(_25354, _line_48496, 0, 2, 23);
        _25354 = NOVALUE;
L6: 
        DeRef(_sline_48482);
        _sline_48482 = NOVALUE;

        /** 	end for*/
        _i_48480 = _i_48480 + 1;
        goto L3; // [154] 59
L4: 
        ;
    }

    /** end procedure*/
    _25344 = NOVALUE;
    _25346 = NOVALUE;
    DeRef(_25350);
    _25350 = NOVALUE;
    return;
    ;
}


void _49cover_line(int _gline_number_48502)
{
    int _sline_48512 = NOVALUE;
    int _file_48515 = NOVALUE;
    int _line_48520 = NOVALUE;
    int _25363 = NOVALUE;
    int _25360 = NOVALUE;
    int _25357 = NOVALUE;
    int _25356 = NOVALUE;
    int _25355 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_gline_number_48502)) {
        _1 = (long)(DBL_PTR(_gline_number_48502)->dbl);
        DeRefDS(_gline_number_48502);
        _gline_number_48502 = _1;
    }

    /** 	if atom(slist[$]) then*/
    if (IS_SEQUENCE(_26slist_12073)){
            _25355 = SEQ_PTR(_26slist_12073)->length;
    }
    else {
        _25355 = 1;
    }
    _2 = (int)SEQ_PTR(_26slist_12073);
    _25356 = (int)*(((s1_ptr)_2)->base + _25355);
    _25357 = IS_ATOM(_25356);
    _25356 = NOVALUE;
    if (_25357 == 0)
    {
        _25357 = NOVALUE;
        goto L1; // [17] 31
    }
    else{
        _25357 = NOVALUE;
    }

    /** 		slist = s_expand(slist)*/
    RefDS(_26slist_12073);
    _0 = _60s_expand(_26slist_12073);
    DeRefDS(_26slist_12073);
    _26slist_12073 = _0;
L1: 

    /** 	sequence sline = slist[gline_number]*/
    DeRef(_sline_48512);
    _2 = (int)SEQ_PTR(_26slist_12073);
    _sline_48512 = (int)*(((s1_ptr)_2)->base + _gline_number_48502);
    Ref(_sline_48512);

    /** 	integer file = file_coverage[sline[LOCAL_FILE_NO]]*/
    _2 = (int)SEQ_PTR(_sline_48512);
    _25360 = (int)*(((s1_ptr)_2)->base + 3);
    _2 = (int)SEQ_PTR(_49file_coverage_48139);
    if (!IS_ATOM_INT(_25360)){
        _file_48515 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_25360)->dbl));
    }
    else{
        _file_48515 = (int)*(((s1_ptr)_2)->base + _25360);
    }

    /** 	if file then*/
    if (_file_48515 == 0)
    {
        goto L2; // [57] 86
    }
    else{
    }

    /** 		integer line = sline[LINE]*/
    _2 = (int)SEQ_PTR(_sline_48512);
    _line_48520 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_line_48520))
    _line_48520 = (long)DBL_PTR(_line_48520)->dbl;

    /** 		map:put( line_map[file], line, 1, map:ADD )*/
    _2 = (int)SEQ_PTR(_49line_map_48143);
    _25363 = (int)*(((s1_ptr)_2)->base + _file_48515);
    Ref(_25363);
    _32put(_25363, _line_48520, 1, 2, 23);
    _25363 = NOVALUE;
L2: 

    /** end procedure*/
    DeRef(_sline_48512);
    _25360 = NOVALUE;
    return;
    ;
}


void _49cover_routine(int _sub_48527)
{
    int _file_no_48528 = NOVALUE;
    int _25368 = NOVALUE;
    int _25367 = NOVALUE;
    int _25366 = NOVALUE;
    int _25364 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_sub_48527)) {
        _1 = (long)(DBL_PTR(_sub_48527)->dbl);
        DeRefDS(_sub_48527);
        _sub_48527 = _1;
    }

    /** 	integer file_no = SymTab[sub][S_FILE_NO]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _25364 = (int)*(((s1_ptr)_2)->base + _sub_48527);
    _2 = (int)SEQ_PTR(_25364);
    if (!IS_ATOM_INT(_26S_FILE_NO_11650)){
        _file_no_48528 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_FILE_NO_11650)->dbl));
    }
    else{
        _file_no_48528 = (int)*(((s1_ptr)_2)->base + _26S_FILE_NO_11650);
    }
    if (!IS_ATOM_INT(_file_no_48528)){
        _file_no_48528 = (long)DBL_PTR(_file_no_48528)->dbl;
    }
    _25364 = NOVALUE;

    /** 	map:put( routine_map[file_coverage[file_no]], sym_name( sub ), 1, map:ADD )*/
    _2 = (int)SEQ_PTR(_49file_coverage_48139);
    _25366 = (int)*(((s1_ptr)_2)->base + _file_no_48528);
    _2 = (int)SEQ_PTR(_49routine_map_48144);
    _25367 = (int)*(((s1_ptr)_2)->base + _25366);
    _25368 = _52sym_name(_sub_48527);
    Ref(_25367);
    _32put(_25367, _25368, 1, 2, 23);
    _25367 = NOVALUE;
    _25368 = NOVALUE;

    /** end procedure*/
    _25366 = NOVALUE;
    return;
    ;
}


int _49has_coverage()
{
    int _25369 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return length( covered_files )*/
    if (IS_SEQUENCE(_49covered_files_48138)){
            _25369 = SEQ_PTR(_49covered_files_48138)->length;
    }
    else {
        _25369 = 1;
    }
    return _25369;
    ;
}



// 0x8F357BDE
