// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int _14find_all(int _needle_1809, int _haystack_1810, int _start_1811)
{
    int _kx_1812 = NOVALUE;
    int _778 = NOVALUE;
    int _777 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer kx = 0*/
    _kx_1812 = 0;

    /** 	while start with entry do*/
    goto L1; // [12] 39
L2: 
    if (_start_1811 == 0)
    {
        goto L3; // [15] 51
    }
    else{
    }

    /** 		kx += 1*/
    _kx_1812 = _kx_1812 + 1;

    /** 		haystack[kx] = start*/
    _2 = (int)SEQ_PTR(_haystack_1810);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _haystack_1810 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _kx_1812);
    _1 = *(int *)_2;
    *(int *)_2 = _start_1811;
    DeRef(_1);

    /** 		start += 1*/
    _start_1811 = _start_1811 + 1;

    /** 	entry*/
L1: 

    /** 		start = find(needle, haystack, start)*/
    _start_1811 = find_from(_needle_1809, _haystack_1810, _start_1811);

    /** 	end while*/
    goto L2; // [48] 15
L3: 

    /** 	haystack = remove( haystack, kx+1, length( haystack ) )*/
    _777 = _kx_1812 + 1;
    if (_777 > MAXINT){
        _777 = NewDouble((double)_777);
    }
    if (IS_SEQUENCE(_haystack_1810)){
            _778 = SEQ_PTR(_haystack_1810)->length;
    }
    else {
        _778 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_haystack_1810);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_777)) ? _777 : (long)(DBL_PTR(_777)->dbl);
        int stop = (IS_ATOM_INT(_778)) ? _778 : (long)(DBL_PTR(_778)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_haystack_1810), start, &_haystack_1810 );
            }
            else Tail(SEQ_PTR(_haystack_1810), stop+1, &_haystack_1810);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_haystack_1810), start, &_haystack_1810);
        }
        else {
            assign_slice_seq = &assign_space;
            _haystack_1810 = Remove_elements(start, stop, (SEQ_PTR(_haystack_1810)->ref == 1));
        }
    }
    DeRef(_777);
    _777 = NOVALUE;
    _778 = NOVALUE;

    /** 	return haystack*/
    return _haystack_1810;
    ;
}


int _14rfind(int _needle_1927, int _haystack_1928, int _start_1929)
{
    int _len_1931 = NOVALUE;
    int _839 = NOVALUE;
    int _838 = NOVALUE;
    int _835 = NOVALUE;
    int _834 = NOVALUE;
    int _832 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer len = length(haystack)*/
    if (IS_SEQUENCE(_haystack_1928)){
            _len_1931 = SEQ_PTR(_haystack_1928)->length;
    }
    else {
        _len_1931 = 1;
    }

    /** 	if start = 0 then start = len end if*/
    if (_start_1929 != 0)
    goto L1; // [12] 20
    _start_1929 = _len_1931;
L1: 

    /** 	if (start > len) or (len + start < 1) then*/
    _832 = (_start_1929 > _len_1931);
    if (_832 != 0) {
        goto L2; // [26] 43
    }
    _834 = _len_1931 + _start_1929;
    if ((long)((unsigned long)_834 + (unsigned long)HIGH_BITS) >= 0) 
    _834 = NewDouble((double)_834);
    if (IS_ATOM_INT(_834)) {
        _835 = (_834 < 1);
    }
    else {
        _835 = (DBL_PTR(_834)->dbl < (double)1);
    }
    DeRef(_834);
    _834 = NOVALUE;
    if (_835 == 0)
    {
        DeRef(_835);
        _835 = NOVALUE;
        goto L3; // [39] 50
    }
    else{
        DeRef(_835);
        _835 = NOVALUE;
    }
L2: 

    /** 		return 0*/
    DeRef(_needle_1927);
    DeRefDS(_haystack_1928);
    DeRef(_832);
    _832 = NOVALUE;
    return 0;
L3: 

    /** 	if start < 1 then*/
    if (_start_1929 >= 1)
    goto L4; // [52] 63

    /** 		start = len + start*/
    _start_1929 = _len_1931 + _start_1929;
L4: 

    /** 	for i = start to 1 by -1 do*/
    {
        int _i_1944;
        _i_1944 = _start_1929;
L5: 
        if (_i_1944 < 1){
            goto L6; // [65] 99
        }

        /** 		if equal(haystack[i], needle) then*/
        _2 = (int)SEQ_PTR(_haystack_1928);
        _838 = (int)*(((s1_ptr)_2)->base + _i_1944);
        if (_838 == _needle_1927)
        _839 = 1;
        else if (IS_ATOM_INT(_838) && IS_ATOM_INT(_needle_1927))
        _839 = 0;
        else
        _839 = (compare(_838, _needle_1927) == 0);
        _838 = NOVALUE;
        if (_839 == 0)
        {
            _839 = NOVALUE;
            goto L7; // [82] 92
        }
        else{
            _839 = NOVALUE;
        }

        /** 			return i*/
        DeRef(_needle_1927);
        DeRefDS(_haystack_1928);
        DeRef(_832);
        _832 = NOVALUE;
        return _i_1944;
L7: 

        /** 	end for*/
        _i_1944 = _i_1944 + -1;
        goto L5; // [94] 72
L6: 
        ;
    }

    /** 	return 0*/
    DeRef(_needle_1927);
    DeRefDS(_haystack_1928);
    DeRef(_832);
    _832 = NOVALUE;
    return 0;
    ;
}


int _14find_replace(int _needle_1950, int _haystack_1951, int _replacement_1952, int _max_1953)
{
    int _posn_1954 = NOVALUE;
    int _843 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer posn = 0*/
    _posn_1954 = 0;

    /** 	while posn != 0 entry do */
    goto L1; // [12] 45
L2: 
    if (_posn_1954 == 0)
    goto L3; // [15] 61

    /** 		haystack[posn] = replacement*/
    Ref(_replacement_1952);
    _2 = (int)SEQ_PTR(_haystack_1951);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _haystack_1951 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _posn_1954);
    _1 = *(int *)_2;
    *(int *)_2 = _replacement_1952;
    DeRef(_1);

    /** 		max -= 1*/
    _max_1953 = _max_1953 - 1;

    /** 		if max = 0 then*/
    if (_max_1953 != 0)
    goto L4; // [33] 42

    /** 			exit*/
    goto L3; // [39] 61
L4: 

    /** 	entry*/
L1: 

    /** 		posn = find(needle, haystack, posn + 1)*/
    _843 = _posn_1954 + 1;
    if (_843 > MAXINT){
        _843 = NewDouble((double)_843);
    }
    _posn_1954 = find_from(_needle_1950, _haystack_1951, _843);
    DeRef(_843);
    _843 = NOVALUE;

    /** 	end while*/
    goto L2; // [58] 15
L3: 

    /** 	return haystack*/
    DeRef(_needle_1950);
    DeRefi(_replacement_1952);
    return _haystack_1951;
    ;
}


int _14match_replace(int _needle_1964, int _haystack_1965, int _replacement_1966, int _max_1967)
{
    int _posn_1968 = NOVALUE;
    int _needle_len_1969 = NOVALUE;
    int _replacement_len_1970 = NOVALUE;
    int _scan_from_1971 = NOVALUE;
    int _cnt_1972 = NOVALUE;
    int _855 = NOVALUE;
    int _852 = NOVALUE;
    int _850 = NOVALUE;
    int _848 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if max < 0 then*/

    /** 	cnt = length(haystack)*/
    if (IS_SEQUENCE(_haystack_1965)){
            _cnt_1972 = SEQ_PTR(_haystack_1965)->length;
    }
    else {
        _cnt_1972 = 1;
    }

    /** 	if max != 0 then*/

    /** 	if atom(needle) then*/
    _848 = IS_ATOM(_needle_1964);
    if (_848 == 0)
    {
        _848 = NOVALUE;
        goto L1; // [40] 50
    }
    else{
        _848 = NOVALUE;
    }

    /** 		needle = {needle}*/
    _0 = _needle_1964;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_needle_1964);
    *((int *)(_2+4)) = _needle_1964;
    _needle_1964 = MAKE_SEQ(_1);
    DeRef(_0);
L1: 

    /** 	if atom(replacement) then*/
    _850 = IS_ATOM(_replacement_1966);
    if (_850 == 0)
    {
        _850 = NOVALUE;
        goto L2; // [55] 65
    }
    else{
        _850 = NOVALUE;
    }

    /** 		replacement = {replacement}*/
    _0 = _replacement_1966;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_replacement_1966);
    *((int *)(_2+4)) = _replacement_1966;
    _replacement_1966 = MAKE_SEQ(_1);
    DeRef(_0);
L2: 

    /** 	needle_len = length(needle) - 1*/
    if (IS_SEQUENCE(_needle_1964)){
            _852 = SEQ_PTR(_needle_1964)->length;
    }
    else {
        _852 = 1;
    }
    _needle_len_1969 = _852 - 1;
    _852 = NOVALUE;

    /** 	replacement_len = length(replacement)*/
    if (IS_SEQUENCE(_replacement_1966)){
            _replacement_len_1970 = SEQ_PTR(_replacement_1966)->length;
    }
    else {
        _replacement_len_1970 = 1;
    }

    /** 	scan_from = 1*/
    _scan_from_1971 = 1;

    /** 	while posn with entry do*/
    goto L3; // [86] 132
L4: 
    if (_posn_1968 == 0)
    {
        goto L5; // [91] 144
    }
    else{
    }

    /** 		haystack = replace(haystack, replacement, posn, posn + needle_len)*/
    _855 = _posn_1968 + _needle_len_1969;
    if ((long)((unsigned long)_855 + (unsigned long)HIGH_BITS) >= 0) 
    _855 = NewDouble((double)_855);
    {
        int p1 = _haystack_1965;
        int p2 = _replacement_1966;
        int p3 = _posn_1968;
        int p4 = _855;
        struct replace_block replace_params;
        replace_params.copy_to   = &p1;
        replace_params.copy_from = &p2;
        replace_params.start     = &p3;
        replace_params.stop      = &p4;
        replace_params.target    = &_haystack_1965;
        Replace( &replace_params );
    }
    DeRef(_855);
    _855 = NOVALUE;

    /** 		cnt -= 1*/
    _cnt_1972 = _cnt_1972 - 1;

    /** 		if cnt = 0 then*/
    if (_cnt_1972 != 0)
    goto L6; // [114] 123

    /** 			exit*/
    goto L5; // [120] 144
L6: 

    /** 		scan_from = posn + replacement_len*/
    _scan_from_1971 = _posn_1968 + _replacement_len_1970;

    /** 	entry*/
L3: 

    /** 		posn = match(needle, haystack, scan_from)*/
    _posn_1968 = e_match_from(_needle_1964, _haystack_1965, _scan_from_1971);

    /** 	end while*/
    goto L4; // [141] 89
L5: 

    /** 	return haystack*/
    DeRef(_needle_1964);
    DeRef(_replacement_1966);
    return _haystack_1965;
    ;
}


int _14binary_search(int _needle_1997, int _haystack_1998, int _start_point_1999, int _end_point_2000)
{
    int _lo_2001 = NOVALUE;
    int _hi_2002 = NOVALUE;
    int _mid_2003 = NOVALUE;
    int _c_2004 = NOVALUE;
    int _881 = NOVALUE;
    int _873 = NOVALUE;
    int _871 = NOVALUE;
    int _868 = NOVALUE;
    int _867 = NOVALUE;
    int _866 = NOVALUE;
    int _865 = NOVALUE;
    int _862 = NOVALUE;
    int _0, _1, _2;
    

    /** 	lo = start_point*/
    _lo_2001 = 1;

    /** 	if end_point <= 0 then*/
    if (_end_point_2000 > 0)
    goto L1; // [14] 30

    /** 		hi = length(haystack) + end_point*/
    if (IS_SEQUENCE(_haystack_1998)){
            _862 = SEQ_PTR(_haystack_1998)->length;
    }
    else {
        _862 = 1;
    }
    _hi_2002 = _862 + _end_point_2000;
    _862 = NOVALUE;
    goto L2; // [27] 36
L1: 

    /** 		hi = end_point*/
    _hi_2002 = _end_point_2000;
L2: 

    /** 	if lo<1 then*/
    if (_lo_2001 >= 1)
    goto L3; // [38] 48

    /** 		lo=1*/
    _lo_2001 = 1;
L3: 

    /** 	if lo > hi and length(haystack) > 0 then*/
    _865 = (_lo_2001 > _hi_2002);
    if (_865 == 0) {
        goto L4; // [56] 77
    }
    if (IS_SEQUENCE(_haystack_1998)){
            _867 = SEQ_PTR(_haystack_1998)->length;
    }
    else {
        _867 = 1;
    }
    _868 = (_867 > 0);
    _867 = NOVALUE;
    if (_868 == 0)
    {
        DeRef(_868);
        _868 = NOVALUE;
        goto L4; // [68] 77
    }
    else{
        DeRef(_868);
        _868 = NOVALUE;
    }

    /** 		hi = length(haystack)*/
    if (IS_SEQUENCE(_haystack_1998)){
            _hi_2002 = SEQ_PTR(_haystack_1998)->length;
    }
    else {
        _hi_2002 = 1;
    }
L4: 

    /** 	mid = start_point*/
    _mid_2003 = _start_point_1999;

    /** 	c = 0*/
    _c_2004 = 0;

    /** 	while lo <= hi do*/
L5: 
    if (_lo_2001 > _hi_2002)
    goto L6; // [92] 160

    /** 		mid = floor((lo + hi) / 2)*/
    _871 = _lo_2001 + _hi_2002;
    if ((long)((unsigned long)_871 + (unsigned long)HIGH_BITS) >= 0) 
    _871 = NewDouble((double)_871);
    if (IS_ATOM_INT(_871)) {
        _mid_2003 = _871 >> 1;
    }
    else {
        _1 = binary_op(DIVIDE, _871, 2);
        _mid_2003 = unary_op(FLOOR, _1);
        DeRef(_1);
    }
    DeRef(_871);
    _871 = NOVALUE;
    if (!IS_ATOM_INT(_mid_2003)) {
        _1 = (long)(DBL_PTR(_mid_2003)->dbl);
        DeRefDS(_mid_2003);
        _mid_2003 = _1;
    }

    /** 		c = eu:compare(needle, haystack[mid])*/
    _2 = (int)SEQ_PTR(_haystack_1998);
    _873 = (int)*(((s1_ptr)_2)->base + _mid_2003);
    if (IS_ATOM_INT(_needle_1997) && IS_ATOM_INT(_873)){
        _c_2004 = (_needle_1997 < _873) ? -1 : (_needle_1997 > _873);
    }
    else{
        _c_2004 = compare(_needle_1997, _873);
    }
    _873 = NOVALUE;

    /** 		if c < 0 then*/
    if (_c_2004 >= 0)
    goto L7; // [120] 133

    /** 			hi = mid - 1*/
    _hi_2002 = _mid_2003 - 1;
    goto L5; // [130] 92
L7: 

    /** 		elsif c > 0 then*/
    if (_c_2004 <= 0)
    goto L8; // [135] 148

    /** 			lo = mid + 1*/
    _lo_2001 = _mid_2003 + 1;
    goto L5; // [145] 92
L8: 

    /** 			return mid*/
    DeRefDS(_haystack_1998);
    DeRef(_865);
    _865 = NOVALUE;
    return _mid_2003;

    /** 	end while*/
    goto L5; // [157] 92
L6: 

    /** 	if c > 0 then*/
    if (_c_2004 <= 0)
    goto L9; // [162] 173

    /** 		mid += 1*/
    _mid_2003 = _mid_2003 + 1;
L9: 

    /** 	return -mid*/
    if ((unsigned long)_mid_2003 == 0xC0000000)
    _881 = (int)NewDouble((double)-0xC0000000);
    else
    _881 = - _mid_2003;
    DeRefDS(_haystack_1998);
    DeRef(_865);
    _865 = NOVALUE;
    return _881;
    ;
}


int _14begins(int _sub_text_2085, int _full_text_2086)
{
    int _919 = NOVALUE;
    int _918 = NOVALUE;
    int _917 = NOVALUE;
    int _915 = NOVALUE;
    int _914 = NOVALUE;
    int _913 = NOVALUE;
    int _912 = NOVALUE;
    int _911 = NOVALUE;
    int _909 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if length(full_text) = 0 then*/
    if (IS_SEQUENCE(_full_text_2086)){
            _909 = SEQ_PTR(_full_text_2086)->length;
    }
    else {
        _909 = 1;
    }
    if (_909 != 0)
    goto L1; // [8] 19

    /** 		return 0*/
    DeRef(_sub_text_2085);
    DeRefDS(_full_text_2086);
    return 0;
L1: 

    /** 	if atom(sub_text) then*/
    _911 = IS_ATOM(_sub_text_2085);
    if (_911 == 0)
    {
        _911 = NOVALUE;
        goto L2; // [24] 57
    }
    else{
        _911 = NOVALUE;
    }

    /** 		if equal(sub_text, full_text[1]) then*/
    _2 = (int)SEQ_PTR(_full_text_2086);
    _912 = (int)*(((s1_ptr)_2)->base + 1);
    if (_sub_text_2085 == _912)
    _913 = 1;
    else if (IS_ATOM_INT(_sub_text_2085) && IS_ATOM_INT(_912))
    _913 = 0;
    else
    _913 = (compare(_sub_text_2085, _912) == 0);
    _912 = NOVALUE;
    if (_913 == 0)
    {
        _913 = NOVALUE;
        goto L3; // [37] 49
    }
    else{
        _913 = NOVALUE;
    }

    /** 			return 1*/
    DeRef(_sub_text_2085);
    DeRefDS(_full_text_2086);
    return 1;
    goto L4; // [46] 56
L3: 

    /** 			return 0*/
    DeRef(_sub_text_2085);
    DeRefDS(_full_text_2086);
    return 0;
L4: 
L2: 

    /** 	if length(sub_text) > length(full_text) then*/
    if (IS_SEQUENCE(_sub_text_2085)){
            _914 = SEQ_PTR(_sub_text_2085)->length;
    }
    else {
        _914 = 1;
    }
    if (IS_SEQUENCE(_full_text_2086)){
            _915 = SEQ_PTR(_full_text_2086)->length;
    }
    else {
        _915 = 1;
    }
    if (_914 <= _915)
    goto L5; // [65] 76

    /** 		return 0*/
    DeRef(_sub_text_2085);
    DeRefDS(_full_text_2086);
    return 0;
L5: 

    /** 	if equal(sub_text, full_text[1.. length(sub_text)]) then*/
    if (IS_SEQUENCE(_sub_text_2085)){
            _917 = SEQ_PTR(_sub_text_2085)->length;
    }
    else {
        _917 = 1;
    }
    rhs_slice_target = (object_ptr)&_918;
    RHS_Slice(_full_text_2086, 1, _917);
    if (_sub_text_2085 == _918)
    _919 = 1;
    else if (IS_ATOM_INT(_sub_text_2085) && IS_ATOM_INT(_918))
    _919 = 0;
    else
    _919 = (compare(_sub_text_2085, _918) == 0);
    DeRefDS(_918);
    _918 = NOVALUE;
    if (_919 == 0)
    {
        _919 = NOVALUE;
        goto L6; // [90] 102
    }
    else{
        _919 = NOVALUE;
    }

    /** 		return 1*/
    DeRef(_sub_text_2085);
    DeRefDS(_full_text_2086);
    return 1;
    goto L7; // [99] 109
L6: 

    /** 		return 0*/
    DeRef(_sub_text_2085);
    DeRefDS(_full_text_2086);
    return 0;
L7: 
    ;
}


int _14ends(int _sub_text_2107, int _full_text_2108)
{
    int _935 = NOVALUE;
    int _934 = NOVALUE;
    int _933 = NOVALUE;
    int _932 = NOVALUE;
    int _931 = NOVALUE;
    int _930 = NOVALUE;
    int _929 = NOVALUE;
    int _927 = NOVALUE;
    int _926 = NOVALUE;
    int _925 = NOVALUE;
    int _924 = NOVALUE;
    int _923 = NOVALUE;
    int _922 = NOVALUE;
    int _920 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if length(full_text) = 0 then*/
    if (IS_SEQUENCE(_full_text_2108)){
            _920 = SEQ_PTR(_full_text_2108)->length;
    }
    else {
        _920 = 1;
    }
    if (_920 != 0)
    goto L1; // [8] 19

    /** 		return 0*/
    DeRefDSi(_sub_text_2107);
    DeRefDS(_full_text_2108);
    return 0;
L1: 

    /** 	if atom(sub_text) then*/
    _922 = IS_ATOM(_sub_text_2107);
    if (_922 == 0)
    {
        _922 = NOVALUE;
        goto L2; // [24] 60
    }
    else{
        _922 = NOVALUE;
    }

    /** 		if equal(sub_text, full_text[$]) then*/
    if (IS_SEQUENCE(_full_text_2108)){
            _923 = SEQ_PTR(_full_text_2108)->length;
    }
    else {
        _923 = 1;
    }
    _2 = (int)SEQ_PTR(_full_text_2108);
    _924 = (int)*(((s1_ptr)_2)->base + _923);
    if (_sub_text_2107 == _924)
    _925 = 1;
    else if (IS_ATOM_INT(_sub_text_2107) && IS_ATOM_INT(_924))
    _925 = 0;
    else
    _925 = (compare(_sub_text_2107, _924) == 0);
    _924 = NOVALUE;
    if (_925 == 0)
    {
        _925 = NOVALUE;
        goto L3; // [40] 52
    }
    else{
        _925 = NOVALUE;
    }

    /** 			return 1*/
    DeRefi(_sub_text_2107);
    DeRefDS(_full_text_2108);
    return 1;
    goto L4; // [49] 59
L3: 

    /** 			return 0*/
    DeRefi(_sub_text_2107);
    DeRefDS(_full_text_2108);
    return 0;
L4: 
L2: 

    /** 	if length(sub_text) > length(full_text) then*/
    if (IS_SEQUENCE(_sub_text_2107)){
            _926 = SEQ_PTR(_sub_text_2107)->length;
    }
    else {
        _926 = 1;
    }
    if (IS_SEQUENCE(_full_text_2108)){
            _927 = SEQ_PTR(_full_text_2108)->length;
    }
    else {
        _927 = 1;
    }
    if (_926 <= _927)
    goto L5; // [68] 79

    /** 		return 0*/
    DeRefi(_sub_text_2107);
    DeRefDS(_full_text_2108);
    return 0;
L5: 

    /** 	if equal(sub_text, full_text[$ - length(sub_text) + 1 .. $]) then*/
    if (IS_SEQUENCE(_full_text_2108)){
            _929 = SEQ_PTR(_full_text_2108)->length;
    }
    else {
        _929 = 1;
    }
    if (IS_SEQUENCE(_sub_text_2107)){
            _930 = SEQ_PTR(_sub_text_2107)->length;
    }
    else {
        _930 = 1;
    }
    _931 = _929 - _930;
    _929 = NOVALUE;
    _930 = NOVALUE;
    _932 = _931 + 1;
    _931 = NOVALUE;
    if (IS_SEQUENCE(_full_text_2108)){
            _933 = SEQ_PTR(_full_text_2108)->length;
    }
    else {
        _933 = 1;
    }
    rhs_slice_target = (object_ptr)&_934;
    RHS_Slice(_full_text_2108, _932, _933);
    if (_sub_text_2107 == _934)
    _935 = 1;
    else if (IS_ATOM_INT(_sub_text_2107) && IS_ATOM_INT(_934))
    _935 = 0;
    else
    _935 = (compare(_sub_text_2107, _934) == 0);
    DeRefDS(_934);
    _934 = NOVALUE;
    if (_935 == 0)
    {
        _935 = NOVALUE;
        goto L6; // [107] 119
    }
    else{
        _935 = NOVALUE;
    }

    /** 		return 1*/
    DeRefi(_sub_text_2107);
    DeRefDS(_full_text_2108);
    _932 = NOVALUE;
    return 1;
    goto L7; // [116] 126
L6: 

    /** 		return 0*/
    DeRefi(_sub_text_2107);
    DeRefDS(_full_text_2108);
    DeRef(_932);
    _932 = NOVALUE;
    return 0;
L7: 
    ;
}



// 0x73C5F44F
