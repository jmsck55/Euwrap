// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int _63is_file_newer(int _f1_23734, int _f2_23735)
{
    int _d1_23736 = NOVALUE;
    int _d2_23739 = NOVALUE;
    int _diff_2__tmp_at33_23748 = NOVALUE;
    int _diff_1__tmp_at33_23747 = NOVALUE;
    int _diff_inlined_diff_at_33_23746 = NOVALUE;
    int _13686 = NOVALUE;
    int _0, _1, _2;
    

    /** 	object d1 = file_timestamp(f1)*/
    RefDS(_f1_23734);
    _0 = _d1_23736;
    _d1_23736 = _15file_timestamp(_f1_23734);
    DeRef(_0);

    /** 	object d2 = file_timestamp(f2)*/
    RefDS(_f2_23735);
    _0 = _d2_23739;
    _d2_23739 = _15file_timestamp(_f2_23735);
    DeRef(_0);

    /** 	if atom(d2) then return 1 end if*/
    _13686 = IS_ATOM(_d2_23739);
    if (_13686 == 0)
    {
        _13686 = NOVALUE;
        goto L1; // [22] 30
    }
    else{
        _13686 = NOVALUE;
    }
    DeRefDS(_f1_23734);
    DeRefDS(_f2_23735);
    DeRef(_d1_23736);
    DeRef(_d2_23739);
    return 1;
L1: 

    /** 	if dt:diff(d1, d2) < 0 then*/

    /** 	return datetimeToSeconds(dt2) - datetimeToSeconds(dt1)*/
    Ref(_d2_23739);
    _0 = _diff_1__tmp_at33_23747;
    _diff_1__tmp_at33_23747 = _16datetimeToSeconds(_d2_23739);
    DeRef(_0);
    Ref(_d1_23736);
    _0 = _diff_2__tmp_at33_23748;
    _diff_2__tmp_at33_23748 = _16datetimeToSeconds(_d1_23736);
    DeRef(_0);
    DeRef(_diff_inlined_diff_at_33_23746);
    if (IS_ATOM_INT(_diff_1__tmp_at33_23747) && IS_ATOM_INT(_diff_2__tmp_at33_23748)) {
        _diff_inlined_diff_at_33_23746 = _diff_1__tmp_at33_23747 - _diff_2__tmp_at33_23748;
        if ((long)((unsigned long)_diff_inlined_diff_at_33_23746 +(unsigned long) HIGH_BITS) >= 0){
            _diff_inlined_diff_at_33_23746 = NewDouble((double)_diff_inlined_diff_at_33_23746);
        }
    }
    else {
        _diff_inlined_diff_at_33_23746 = binary_op(MINUS, _diff_1__tmp_at33_23747, _diff_2__tmp_at33_23748);
    }
    DeRef(_diff_1__tmp_at33_23747);
    _diff_1__tmp_at33_23747 = NOVALUE;
    DeRef(_diff_2__tmp_at33_23748);
    _diff_2__tmp_at33_23748 = NOVALUE;
    if (binary_op_a(GREATEREQ, _diff_inlined_diff_at_33_23746, 0)){
        goto L2; // [49] 60
    }

    /** 		return 1*/
    DeRefDS(_f1_23734);
    DeRefDS(_f2_23735);
    DeRef(_d1_23736);
    DeRef(_d2_23739);
    return 1;
L2: 

    /** 	return 0*/
    DeRefDS(_f1_23734);
    DeRefDS(_f2_23735);
    DeRef(_d1_23736);
    DeRef(_d2_23739);
    return 0;
    ;
}


void _63add_preprocessor(int _file_ext_23752, int _command_23753, int _params_23754)
{
    int _tmp_23757 = NOVALUE;
    int _file_exts_23767 = NOVALUE;
    int _exts_23773 = NOVALUE;
    int _13703 = NOVALUE;
    int _13702 = NOVALUE;
    int _13701 = NOVALUE;
    int _13700 = NOVALUE;
    int _13698 = NOVALUE;
    int _13693 = NOVALUE;
    int _13688 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(command) then*/
    _13688 = 1;
    if (_13688 == 0)
    {
        _13688 = NOVALUE;
        goto L1; // [8] 53
    }
    else{
        _13688 = NOVALUE;
    }

    /** 		sequence tmp = split( file_ext, ":")*/
    RefDS(_file_ext_23752);
    RefDS(_13689);
    _0 = _tmp_23757;
    _tmp_23757 = _23split(_file_ext_23752, _13689, 0, 0);
    DeRef(_0);

    /** 		file_ext = tmp[1]*/
    DeRefDS(_file_ext_23752);
    _2 = (int)SEQ_PTR(_tmp_23757);
    _file_ext_23752 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_file_ext_23752);

    /** 		command = tmp[2]*/
    _2 = (int)SEQ_PTR(_tmp_23757);
    _command_23753 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_command_23753);

    /** 		if length(tmp) >= 3 then*/
    if (IS_SEQUENCE(_tmp_23757)){
            _13693 = SEQ_PTR(_tmp_23757)->length;
    }
    else {
        _13693 = 1;
    }
    if (_13693 < 3)
    goto L2; // [41] 52

    /** 			params = tmp[3]*/
    _2 = (int)SEQ_PTR(_tmp_23757);
    _params_23754 = (int)*(((s1_ptr)_2)->base + 3);
    Ref(_params_23754);
L2: 
L1: 
    DeRef(_tmp_23757);
    _tmp_23757 = NOVALUE;

    /** 	sequence file_exts = split( file_ext, "," )*/
    RefDS(_file_ext_23752);
    RefDS(_13696);
    _0 = _file_exts_23767;
    _file_exts_23767 = _23split(_file_ext_23752, _13696, 0, 0);
    DeRef(_0);

    /** 	if atom(params) then*/
    _13698 = IS_ATOM(_params_23754);
    if (_13698 == 0)
    {
        _13698 = NOVALUE;
        goto L3; // [71] 80
    }
    else{
        _13698 = NOVALUE;
    }

    /** 		params = ""*/
    RefDS(_5);
    DeRef(_params_23754);
    _params_23754 = _5;
L3: 

    /** 	sequence exts = split(file_ext, ",")*/
    RefDS(_file_ext_23752);
    RefDS(_13696);
    _0 = _exts_23773;
    _exts_23773 = _23split(_file_ext_23752, _13696, 0, 0);
    DeRef(_0);

    /** 	for i = 1 to length(exts) do*/
    if (IS_SEQUENCE(_exts_23773)){
            _13700 = SEQ_PTR(_exts_23773)->length;
    }
    else {
        _13700 = 1;
    }
    {
        int _i_23777;
        _i_23777 = 1;
L4: 
        if (_i_23777 > _13700){
            goto L5; // [96] 135
        }

        /** 		preprocessors &= { { exts[i], command, params, -1 } }*/
        _2 = (int)SEQ_PTR(_exts_23773);
        _13701 = (int)*(((s1_ptr)_2)->base + _i_23777);
        _1 = NewS1(4);
        _2 = (int)((s1_ptr)_1)->base;
        Ref(_13701);
        *((int *)(_2+4)) = _13701;
        Ref(_command_23753);
        *((int *)(_2+8)) = _command_23753;
        Ref(_params_23754);
        *((int *)(_2+12)) = _params_23754;
        *((int *)(_2+16)) = -1;
        _13702 = MAKE_SEQ(_1);
        _13701 = NOVALUE;
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = _13702;
        _13703 = MAKE_SEQ(_1);
        _13702 = NOVALUE;
        Concat((object_ptr)&_27preprocessors_10940, _27preprocessors_10940, _13703);
        DeRefDS(_13703);
        _13703 = NOVALUE;

        /** 	end for*/
        _i_23777 = _i_23777 + 1;
        goto L4; // [130] 103
L5: 
        ;
    }

    /** end procedure */
    DeRefDS(_file_ext_23752);
    DeRef(_command_23753);
    DeRef(_params_23754);
    DeRef(_file_exts_23767);
    DeRef(_exts_23773);
    return;
    ;
}


int _63maybe_preprocess(int _fname_23786)
{
    int _pp_23787 = NOVALUE;
    int _pp_id_23788 = NOVALUE;
    int _fext_23792 = NOVALUE;
    int _post_fname_23809 = NOVALUE;
    int _rid_23837 = NOVALUE;
    int _dll_id_23841 = NOVALUE;
    int _public_cmd_args_23877 = NOVALUE;
    int _cmd_args_23880 = NOVALUE;
    int _cmd_23909 = NOVALUE;
    int _pcmd_23914 = NOVALUE;
    int _result_23919 = NOVALUE;
    int _13782 = NOVALUE;
    int _13781 = NOVALUE;
    int _13776 = NOVALUE;
    int _13775 = NOVALUE;
    int _13773 = NOVALUE;
    int _13772 = NOVALUE;
    int _13770 = NOVALUE;
    int _13768 = NOVALUE;
    int _13767 = NOVALUE;
    int _13765 = NOVALUE;
    int _13762 = NOVALUE;
    int _13760 = NOVALUE;
    int _13758 = NOVALUE;
    int _13756 = NOVALUE;
    int _13755 = NOVALUE;
    int _13753 = NOVALUE;
    int _13752 = NOVALUE;
    int _13750 = NOVALUE;
    int _13747 = NOVALUE;
    int _13746 = NOVALUE;
    int _13745 = NOVALUE;
    int _13743 = NOVALUE;
    int _13739 = NOVALUE;
    int _13737 = NOVALUE;
    int _13736 = NOVALUE;
    int _13735 = NOVALUE;
    int _13731 = NOVALUE;
    int _13728 = NOVALUE;
    int _13727 = NOVALUE;
    int _13726 = NOVALUE;
    int _13724 = NOVALUE;
    int _13721 = NOVALUE;
    int _13719 = NOVALUE;
    int _13718 = NOVALUE;
    int _13716 = NOVALUE;
    int _13714 = NOVALUE;
    int _13712 = NOVALUE;
    int _13710 = NOVALUE;
    int _13709 = NOVALUE;
    int _13708 = NOVALUE;
    int _13707 = NOVALUE;
    int _13705 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	sequence pp = {}*/
    RefDS(_5);
    DeRef(_pp_23787);
    _pp_23787 = _5;

    /** 	if length(preprocessors) then*/
    if (IS_SEQUENCE(_27preprocessors_10940)){
            _13705 = SEQ_PTR(_27preprocessors_10940)->length;
    }
    else {
        _13705 = 1;
    }
    if (_13705 == 0)
    {
        _13705 = NOVALUE;
        goto L1; // [17] 89
    }
    else{
        _13705 = NOVALUE;
    }

    /** 		sequence fext = fileext(fname)*/
    RefDS(_fname_23786);
    _0 = _fext_23792;
    _fext_23792 = _15fileext(_fname_23786);
    DeRef(_0);

    /** 		for i = 1 to length(preprocessors) do*/
    if (IS_SEQUENCE(_27preprocessors_10940)){
            _13707 = SEQ_PTR(_27preprocessors_10940)->length;
    }
    else {
        _13707 = 1;
    }
    {
        int _i_23796;
        _i_23796 = 1;
L2: 
        if (_i_23796 > _13707){
            goto L3; // [35] 88
        }

        /** 			if equal(fext, preprocessors[i][1]) then*/
        _2 = (int)SEQ_PTR(_27preprocessors_10940);
        _13708 = (int)*(((s1_ptr)_2)->base + _i_23796);
        _2 = (int)SEQ_PTR(_13708);
        _13709 = (int)*(((s1_ptr)_2)->base + 1);
        _13708 = NOVALUE;
        if (_fext_23792 == _13709)
        _13710 = 1;
        else if (IS_ATOM_INT(_fext_23792) && IS_ATOM_INT(_13709))
        _13710 = 0;
        else
        _13710 = (compare(_fext_23792, _13709) == 0);
        _13709 = NOVALUE;
        if (_13710 == 0)
        {
            _13710 = NOVALUE;
            goto L4; // [58] 81
        }
        else{
            _13710 = NOVALUE;
        }

        /** 				pp_id = i*/
        _pp_id_23788 = _i_23796;

        /** 				pp = preprocessors[pp_id]*/
        DeRef(_pp_23787);
        _2 = (int)SEQ_PTR(_27preprocessors_10940);
        _pp_23787 = (int)*(((s1_ptr)_2)->base + _pp_id_23788);
        RefDS(_pp_23787);

        /** 				exit*/
        goto L3; // [78] 88
L4: 

        /** 		end for*/
        _i_23796 = _i_23796 + 1;
        goto L2; // [83] 42
L3: 
        ;
    }
L1: 
    DeRef(_fext_23792);
    _fext_23792 = NOVALUE;

    /** 	if length(pp) = 0 then */
    if (IS_SEQUENCE(_pp_23787)){
            _13712 = SEQ_PTR(_pp_23787)->length;
    }
    else {
        _13712 = 1;
    }
    if (_13712 != 0)
    goto L5; // [96] 107

    /** 		return fname*/
    DeRefDS(_pp_23787);
    DeRef(_post_fname_23809);
    return _fname_23786;
L5: 

    /** 	sequence post_fname = filebase(fname) & ".pp." & fileext(fname)*/
    RefDS(_fname_23786);
    _13714 = _15filebase(_fname_23786);
    RefDS(_fname_23786);
    _13716 = _15fileext(_fname_23786);
    {
        int concat_list[3];

        concat_list[0] = _13716;
        concat_list[1] = _13715;
        concat_list[2] = _13714;
        Concat_N((object_ptr)&_post_fname_23809, concat_list, 3);
    }
    DeRef(_13716);
    _13716 = NOVALUE;
    DeRef(_13714);
    _13714 = NOVALUE;

    /** 	if length(dirname(fname)) > 0 then*/
    RefDS(_fname_23786);
    _13718 = _15dirname(_fname_23786, 0);
    if (IS_SEQUENCE(_13718)){
            _13719 = SEQ_PTR(_13718)->length;
    }
    else {
        _13719 = 1;
    }
    DeRef(_13718);
    _13718 = NOVALUE;
    if (_13719 <= 0)
    goto L6; // [133] 153

    /** 		post_fname = dirname(fname) & SLASH & post_fname*/
    RefDS(_fname_23786);
    _13721 = _15dirname(_fname_23786, 0);
    {
        int concat_list[3];

        concat_list[0] = _post_fname_23809;
        concat_list[1] = 92;
        concat_list[2] = _13721;
        Concat_N((object_ptr)&_post_fname_23809, concat_list, 3);
    }
    DeRef(_13721);
    _13721 = NOVALUE;
L6: 

    /** 	if not force_preprocessor then*/
    if (_27force_preprocessor_10941 != 0)
    goto L7; // [157] 178

    /** 		if not is_file_newer(fname, post_fname) then*/
    RefDS(_fname_23786);
    RefDS(_post_fname_23809);
    _13724 = _63is_file_newer(_fname_23786, _post_fname_23809);
    if (IS_ATOM_INT(_13724)) {
        if (_13724 != 0){
            DeRef(_13724);
            _13724 = NOVALUE;
            goto L8; // [167] 177
        }
    }
    else {
        if (DBL_PTR(_13724)->dbl != 0.0){
            DeRef(_13724);
            _13724 = NOVALUE;
            goto L8; // [167] 177
        }
    }
    DeRef(_13724);
    _13724 = NOVALUE;

    /** 			return post_fname*/
    DeRefDS(_fname_23786);
    DeRef(_pp_23787);
    _13718 = NOVALUE;
    return _post_fname_23809;
L8: 
L7: 

    /** 	if equal(fileext(pp[PP_COMMAND]), SHARED_LIB_EXT) then*/
    _2 = (int)SEQ_PTR(_pp_23787);
    _13726 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_13726);
    _13727 = _15fileext(_13726);
    _13726 = NOVALUE;
    if (_13727 == _15SHARED_LIB_EXT_7235)
    _13728 = 1;
    else if (IS_ATOM_INT(_13727) && IS_ATOM_INT(_15SHARED_LIB_EXT_7235))
    _13728 = 0;
    else
    _13728 = (compare(_13727, _15SHARED_LIB_EXT_7235) == 0);
    DeRef(_13727);
    _13727 = NOVALUE;
    if (_13728 == 0)
    {
        _13728 = NOVALUE;
        goto L9; // [194] 348
    }
    else{
        _13728 = NOVALUE;
    }

    /** 		integer rid = pp[PP_RID]*/
    _2 = (int)SEQ_PTR(_pp_23787);
    _rid_23837 = (int)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_rid_23837))
    _rid_23837 = (long)DBL_PTR(_rid_23837)->dbl;

    /** 		if rid = -1 then*/
    if (_rid_23837 != -1)
    goto LA; // [205] 307

    /** 			integer dll_id = open_dll(pp[PP_COMMAND])*/
    _2 = (int)SEQ_PTR(_pp_23787);
    _13731 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_13731);
    _dll_id_23841 = _4open_dll(_13731);
    _13731 = NOVALUE;
    if (!IS_ATOM_INT(_dll_id_23841)) {
        _1 = (long)(DBL_PTR(_dll_id_23841)->dbl);
        DeRefDS(_dll_id_23841);
        _dll_id_23841 = _1;
    }

    /** 			if dll_id = -1 then*/
    if (_dll_id_23841 != -1)
    goto LB; // [223] 247

    /** 				CompileErr(sprintf("Preprocessor shared library '%s' could not be loaded\n",*/
    _2 = (int)SEQ_PTR(_pp_23787);
    _13735 = (int)*(((s1_ptr)_2)->base + 2);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_13735);
    *((int *)(_2+4)) = _13735;
    _13736 = MAKE_SEQ(_1);
    _13735 = NOVALUE;
    _13737 = EPrintf(-9999999, _13734, _13736);
    DeRefDS(_13736);
    _13736 = NOVALUE;
    RefDS(_22037);
    _43CompileErr(_13737, _22037, 1);
    _13737 = NOVALUE;
LB: 

    /** 			rid = define_c_func(dll_id, "preprocess", { E_SEQUENCE, E_SEQUENCE, E_SEQUENCE }, */
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 134217732;
    *((int *)(_2+8)) = 134217732;
    *((int *)(_2+12)) = 134217732;
    _13739 = MAKE_SEQ(_1);
    RefDS(_13738);
    _rid_23837 = _4define_c_func(_dll_id_23841, _13738, _13739, 100663300);
    _13739 = NOVALUE;
    if (!IS_ATOM_INT(_rid_23837)) {
        _1 = (long)(DBL_PTR(_rid_23837)->dbl);
        DeRefDS(_rid_23837);
        _rid_23837 = _1;
    }

    /** 			if rid = -1 then*/
    if (_rid_23837 != -1)
    goto LC; // [274] 291

    /** 				CompileErr("Preprocessor entry point cound not be found\n",,1)*/
    RefDS(_13742);
    RefDS(_22037);
    _43CompileErr(_13742, _22037, 1);

    /** 				Cleanup(1)*/
    _43Cleanup(1);
LC: 

    /** 			preprocessors[pp_id][PP_RID] = rid*/
    _2 = (int)SEQ_PTR(_27preprocessors_10940);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27preprocessors_10940 = MAKE_SEQ(_2);
    }
    _3 = (int)(_pp_id_23788 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = _rid_23837;
    DeRef(_1);
    _13743 = NOVALUE;
LA: 

    /** 		if c_func(rid, { fname, post_fname, pp[PP_PARAMS] }) != 0 then*/
    _2 = (int)SEQ_PTR(_pp_23787);
    _13745 = (int)*(((s1_ptr)_2)->base + 3);
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_fname_23786);
    *((int *)(_2+4)) = _fname_23786;
    RefDS(_post_fname_23809);
    *((int *)(_2+8)) = _post_fname_23809;
    Ref(_13745);
    *((int *)(_2+12)) = _13745;
    _13746 = MAKE_SEQ(_1);
    _13745 = NOVALUE;
    _13747 = call_c(1, _rid_23837, _13746);
    DeRefDS(_13746);
    _13746 = NOVALUE;
    if (binary_op_a(EQUALS, _13747, 0)){
        DeRef(_13747);
        _13747 = NOVALUE;
        goto LD; // [326] 343
    }
    DeRef(_13747);
    _13747 = NOVALUE;

    /** 			CompileErr("Preprocessor call failed\n",,1)*/
    RefDS(_13749);
    RefDS(_22037);
    _43CompileErr(_13749, _22037, 1);

    /** 			Cleanup(1)*/
    _43Cleanup(1);
LD: 
    goto LE; // [345] 520
L9: 

    /** 		sequence public_cmd_args = {pp[PP_COMMAND]}*/
    _2 = (int)SEQ_PTR(_pp_23787);
    _13750 = (int)*(((s1_ptr)_2)->base + 2);
    _0 = _public_cmd_args_23877;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_13750);
    *((int *)(_2+4)) = _13750;
    _public_cmd_args_23877 = MAKE_SEQ(_1);
    DeRef(_0);
    _13750 = NOVALUE;

    /** 		sequence cmd_args = {canonical_path(pp[PP_COMMAND],,TO_SHORT)}*/
    _2 = (int)SEQ_PTR(_pp_23787);
    _13752 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_13752);
    _13753 = _15canonical_path(_13752, 0, 4);
    _13752 = NOVALUE;
    _0 = _cmd_args_23880;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _13753;
    _cmd_args_23880 = MAKE_SEQ(_1);
    DeRef(_0);
    _13753 = NOVALUE;

    /** 		if equal(fileext(pp[PP_COMMAND]), "ex") then*/
    _2 = (int)SEQ_PTR(_pp_23787);
    _13755 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_13755);
    _13756 = _15fileext(_13755);
    _13755 = NOVALUE;
    if (_13756 == _13757)
    _13758 = 1;
    else if (IS_ATOM_INT(_13756) && IS_ATOM_INT(_13757))
    _13758 = 0;
    else
    _13758 = (compare(_13756, _13757) == 0);
    DeRef(_13756);
    _13756 = NOVALUE;
    if (_13758 == 0)
    {
        _13758 = NOVALUE;
        goto LF; // [390] 414
    }
    else{
        _13758 = NOVALUE;
    }

    /** 			public_cmd_args = { "eui" } & public_cmd_args*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_13759);
    *((int *)(_2+4)) = _13759;
    _13760 = MAKE_SEQ(_1);
    Concat((object_ptr)&_public_cmd_args_23877, _13760, _public_cmd_args_23877);
    DeRefDS(_13760);
    _13760 = NOVALUE;
    DeRef(_13760);
    _13760 = NOVALUE;

    /** 			cmd_args = { "eui" } & cmd_args*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_13759);
    *((int *)(_2+4)) = _13759;
    _13762 = MAKE_SEQ(_1);
    Concat((object_ptr)&_cmd_args_23880, _13762, _cmd_args_23880);
    DeRefDS(_13762);
    _13762 = NOVALUE;
    DeRef(_13762);
    _13762 = NOVALUE;
LF: 

    /** 		cmd_args &= { "-i", canonical_path(fname,,TO_SHORT), "-o", canonical_path(post_fname,,TO_SHORT) }*/
    RefDS(_fname_23786);
    _13765 = _15canonical_path(_fname_23786, 0, 4);
    RefDS(_post_fname_23809);
    _13767 = _15canonical_path(_post_fname_23809, 0, 4);
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_13764);
    *((int *)(_2+4)) = _13764;
    *((int *)(_2+8)) = _13765;
    RefDS(_13766);
    *((int *)(_2+12)) = _13766;
    *((int *)(_2+16)) = _13767;
    _13768 = MAKE_SEQ(_1);
    _13767 = NOVALUE;
    _13765 = NOVALUE;
    Concat((object_ptr)&_cmd_args_23880, _cmd_args_23880, _13768);
    DeRefDS(_13768);
    _13768 = NOVALUE;

    /** 		public_cmd_args &= { "-i", fname, "-o", post_fname }*/
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_13764);
    *((int *)(_2+4)) = _13764;
    RefDS(_fname_23786);
    *((int *)(_2+8)) = _fname_23786;
    RefDS(_13766);
    *((int *)(_2+12)) = _13766;
    RefDS(_post_fname_23809);
    *((int *)(_2+16)) = _post_fname_23809;
    _13770 = MAKE_SEQ(_1);
    Concat((object_ptr)&_public_cmd_args_23877, _public_cmd_args_23877, _13770);
    DeRefDS(_13770);
    _13770 = NOVALUE;

    /** 		sequence cmd = build_commandline( cmd_args ) & pp[PP_PARAMS]*/
    RefDS(_cmd_args_23880);
    _13772 = _40build_commandline(_cmd_args_23880);
    _2 = (int)SEQ_PTR(_pp_23787);
    _13773 = (int)*(((s1_ptr)_2)->base + 3);
    if (IS_SEQUENCE(_13772) && IS_ATOM(_13773)) {
        Ref(_13773);
        Append(&_cmd_23909, _13772, _13773);
    }
    else if (IS_ATOM(_13772) && IS_SEQUENCE(_13773)) {
        Ref(_13772);
        Prepend(&_cmd_23909, _13773, _13772);
    }
    else {
        Concat((object_ptr)&_cmd_23909, _13772, _13773);
        DeRef(_13772);
        _13772 = NOVALUE;
    }
    DeRef(_13772);
    _13772 = NOVALUE;
    _13773 = NOVALUE;

    /** 		sequence pcmd = build_commandline(public_cmd_args) & pp[PP_PARAMS]*/
    RefDS(_public_cmd_args_23877);
    _13775 = _40build_commandline(_public_cmd_args_23877);
    _2 = (int)SEQ_PTR(_pp_23787);
    _13776 = (int)*(((s1_ptr)_2)->base + 3);
    if (IS_SEQUENCE(_13775) && IS_ATOM(_13776)) {
        Ref(_13776);
        Append(&_pcmd_23914, _13775, _13776);
    }
    else if (IS_ATOM(_13775) && IS_SEQUENCE(_13776)) {
        Ref(_13775);
        Prepend(&_pcmd_23914, _13776, _13775);
    }
    else {
        Concat((object_ptr)&_pcmd_23914, _13775, _13776);
        DeRef(_13775);
        _13775 = NOVALUE;
    }
    DeRef(_13775);
    _13775 = NOVALUE;
    _13776 = NOVALUE;

    /** 		integer result = system_exec(cmd, 2)*/
    _result_23919 = system_exec_call(_cmd_23909, 2);

    /** 		if result != 0 then*/
    if (_result_23919 == 0)
    goto L10; // [492] 517

    /** 			CompileErr(sprintf("Preprocessor command failed (%d): %s\n", { result, pcmd } ),,1)*/
    RefDS(_pcmd_23914);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _result_23919;
    ((int *)_2)[2] = _pcmd_23914;
    _13781 = MAKE_SEQ(_1);
    _13782 = EPrintf(-9999999, _13780, _13781);
    DeRefDS(_13781);
    _13781 = NOVALUE;
    RefDS(_22037);
    _43CompileErr(_13782, _22037, 1);
    _13782 = NOVALUE;

    /** 			Cleanup(1)*/
    _43Cleanup(1);
L10: 
    DeRef(_public_cmd_args_23877);
    _public_cmd_args_23877 = NOVALUE;
    DeRef(_cmd_args_23880);
    _cmd_args_23880 = NOVALUE;
    DeRef(_cmd_23909);
    _cmd_23909 = NOVALUE;
    DeRef(_pcmd_23914);
    _pcmd_23914 = NOVALUE;
LE: 

    /** 	return post_fname*/
    DeRefDS(_fname_23786);
    DeRef(_pp_23787);
    _13718 = NOVALUE;
    return _post_fname_23809;
    ;
}



// 0x03CADCFB
