// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

void _30EndLineTable()
{
    int _0, _1, _2;
    

    /** 	LineTable = append(LineTable, -2)*/
    Append(&_26LineTable_12072, _26LineTable_12072, -2);

    /** end procedure*/
    return;
    ;
}


void _30CreateTopLevel()
{
    int _27915 = NOVALUE;
    int _27913 = NOVALUE;
    int _27911 = NOVALUE;
    int _27909 = NOVALUE;
    int _27907 = NOVALUE;
    int _27905 = NOVALUE;
    int _27903 = NOVALUE;
    int _27901 = NOVALUE;
    int _27899 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	SymTab[TopLevelSub][S_NUM_ARGS] = 0*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_26TopLevelSub_11989 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_26S_NUM_ARGS_11705))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NUM_ARGS_11705)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _26S_NUM_ARGS_11705);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _27899 = NOVALUE;

    /** 	SymTab[TopLevelSub][S_TEMPS] = 0*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_26TopLevelSub_11989 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_26S_TEMPS_11699))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_TEMPS_11699)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _26S_TEMPS_11699);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _27901 = NOVALUE;

    /** 	SymTab[TopLevelSub][S_CODE] = {}*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_26TopLevelSub_11989 + ((s1_ptr)_2)->base);
    RefDS(_22037);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_26S_CODE_11666))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_CODE_11666)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _26S_CODE_11666);
    _1 = *(int *)_2;
    *(int *)_2 = _22037;
    DeRef(_1);
    _27903 = NOVALUE;

    /** 	SymTab[TopLevelSub][S_LINETAB] = {}*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_26TopLevelSub_11989 + ((s1_ptr)_2)->base);
    RefDS(_22037);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_26S_LINETAB_11689))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_LINETAB_11689)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _26S_LINETAB_11689);
    _1 = *(int *)_2;
    *(int *)_2 = _22037;
    DeRef(_1);
    _27905 = NOVALUE;

    /** 	SymTab[TopLevelSub][S_FIRSTLINE] = 1*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_26TopLevelSub_11989 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_26S_FIRSTLINE_11694))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_FIRSTLINE_11694)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _26S_FIRSTLINE_11694);
    _1 = *(int *)_2;
    *(int *)_2 = 1;
    DeRef(_1);
    _27907 = NOVALUE;

    /** 	SymTab[TopLevelSub][S_REFLIST] = {}*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_26TopLevelSub_11989 + ((s1_ptr)_2)->base);
    RefDS(_22037);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 24);
    _1 = *(int *)_2;
    *(int *)_2 = _22037;
    DeRef(_1);
    _27909 = NOVALUE;

    /** 	SymTab[TopLevelSub][S_NREFS] = 1*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_26TopLevelSub_11989 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 12);
    _1 = *(int *)_2;
    *(int *)_2 = 1;
    DeRef(_1);
    _27911 = NOVALUE;

    /** 	SymTab[TopLevelSub][S_RESIDENT_TASK] = 1*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_26TopLevelSub_11989 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 25);
    _1 = *(int *)_2;
    *(int *)_2 = 1;
    DeRef(_1);
    _27913 = NOVALUE;

    /** 	SymTab[TopLevelSub][S_SAVED_PRIVATES] = {}*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_26TopLevelSub_11989 + ((s1_ptr)_2)->base);
    RefDS(_22037);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 26);
    _1 = *(int *)_2;
    *(int *)_2 = _22037;
    DeRef(_1);
    _27915 = NOVALUE;

    /** 	Start_block( PROC, TopLevelSub )*/
    _65Start_block(27, _26TopLevelSub_11989);

    /** end procedure*/
    return;
    ;
}


void _30CheckForUndefinedGotoLabels()
{
    int _27929 = NOVALUE;
    int _27928 = NOVALUE;
    int _27925 = NOVALUE;
    int _27923 = NOVALUE;
    int _27921 = NOVALUE;
    int _27919 = NOVALUE;
    int _27918 = NOVALUE;
    int _27917 = NOVALUE;
    int _0, _1, _2;
    

    /** 	for i = 1 to length(goto_delay) do*/
    if (IS_SEQUENCE(_26goto_delay_12093)){
            _27917 = SEQ_PTR(_26goto_delay_12093)->length;
    }
    else {
        _27917 = 1;
    }
    {
        int _i_54260;
        _i_54260 = 1;
L1: 
        if (_i_54260 > _27917){
            goto L2; // [8] 104
        }

        /** 		if not equal(goto_delay[i],"") then*/
        _2 = (int)SEQ_PTR(_26goto_delay_12093);
        _27918 = (int)*(((s1_ptr)_2)->base + _i_54260);
        if (_27918 == _22037)
        _27919 = 1;
        else if (IS_ATOM_INT(_27918) && IS_ATOM_INT(_22037))
        _27919 = 0;
        else
        _27919 = (compare(_27918, _22037) == 0);
        _27918 = NOVALUE;
        if (_27919 != 0)
        goto L3; // [27] 97
        _27919 = NOVALUE;

        /** 			line_number = goto_line[i][1] -- tell compiler the correct line number*/
        _2 = (int)SEQ_PTR(_30goto_line_54166);
        _27921 = (int)*(((s1_ptr)_2)->base + _i_54260);
        _2 = (int)SEQ_PTR(_27921);
        _26line_number_11983 = (int)*(((s1_ptr)_2)->base + 1);
        if (!IS_ATOM_INT(_26line_number_11983)){
            _26line_number_11983 = (long)DBL_PTR(_26line_number_11983)->dbl;
        }
        _27921 = NOVALUE;

        /** 			gline_number = goto_line[i][1] -- tell compiler the correct line number*/
        _2 = (int)SEQ_PTR(_30goto_line_54166);
        _27923 = (int)*(((s1_ptr)_2)->base + _i_54260);
        _2 = (int)SEQ_PTR(_27923);
        _26gline_number_11987 = (int)*(((s1_ptr)_2)->base + 1);
        if (!IS_ATOM_INT(_26gline_number_11987)){
            _26gline_number_11987 = (long)DBL_PTR(_26gline_number_11987)->dbl;
        }
        _27923 = NOVALUE;

        /** 			ThisLine = goto_line[i][2] -- tell compiler the correct line number*/
        _2 = (int)SEQ_PTR(_30goto_line_54166);
        _27925 = (int)*(((s1_ptr)_2)->base + _i_54260);
        DeRef(_43ThisLine_48557);
        _2 = (int)SEQ_PTR(_27925);
        _43ThisLine_48557 = (int)*(((s1_ptr)_2)->base + 2);
        Ref(_43ThisLine_48557);
        _27925 = NOVALUE;

        /** 			bp = length(ThisLine)*/
        if (IS_SEQUENCE(_43ThisLine_48557)){
                _43bp_48561 = SEQ_PTR(_43ThisLine_48557)->length;
        }
        else {
            _43bp_48561 = 1;
        }

        /** 				CompileErr(156, {goto_delay[i]})*/
        _2 = (int)SEQ_PTR(_26goto_delay_12093);
        _27928 = (int)*(((s1_ptr)_2)->base + _i_54260);
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        Ref(_27928);
        *((int *)(_2+4)) = _27928;
        _27929 = MAKE_SEQ(_1);
        _27928 = NOVALUE;
        _43CompileErr(156, _27929, 0);
        _27929 = NOVALUE;
L3: 

        /** 	end for*/
        _i_54260 = _i_54260 + 1;
        goto L1; // [99] 15
L2: 
        ;
    }

    /** end procedure*/
    return;
    ;
}


void _30PushGoto()
{
    int _27930 = NOVALUE;
    int _0, _1, _2;
    

    /** 	goto_stack = append(goto_stack, {goto_addr, goto_list, goto_labels, goto_delay, goto_line, goto_ref, label_block, goto_init })*/
    _1 = NewS1(8);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_30goto_addr_54168);
    *((int *)(_2+4)) = _30goto_addr_54168;
    RefDS(_26goto_list_12094);
    *((int *)(_2+8)) = _26goto_list_12094;
    RefDS(_30goto_labels_54167);
    *((int *)(_2+12)) = _30goto_labels_54167;
    RefDS(_26goto_delay_12093);
    *((int *)(_2+16)) = _26goto_delay_12093;
    RefDS(_30goto_line_54166);
    *((int *)(_2+20)) = _30goto_line_54166;
    RefDS(_30goto_ref_54170);
    *((int *)(_2+24)) = _30goto_ref_54170;
    RefDS(_30label_block_54171);
    *((int *)(_2+28)) = _30label_block_54171;
    Ref(_30goto_init_54173);
    *((int *)(_2+32)) = _30goto_init_54173;
    _27930 = MAKE_SEQ(_1);
    RefDS(_27930);
    Append(&_30goto_stack_54169, _30goto_stack_54169, _27930);
    DeRefDS(_27930);
    _27930 = NOVALUE;

    /** 	goto_addr = {}*/
    RefDS(_22037);
    DeRefDS(_30goto_addr_54168);
    _30goto_addr_54168 = _22037;

    /** 	goto_list = {}*/
    RefDS(_22037);
    DeRefDS(_26goto_list_12094);
    _26goto_list_12094 = _22037;

    /** 	goto_labels = {}*/
    RefDS(_22037);
    DeRefDS(_30goto_labels_54167);
    _30goto_labels_54167 = _22037;

    /** 	goto_delay = {}*/
    RefDS(_22037);
    DeRefDS(_26goto_delay_12093);
    _26goto_delay_12093 = _22037;

    /** 	goto_line = {}*/
    RefDS(_22037);
    DeRefDS(_30goto_line_54166);
    _30goto_line_54166 = _22037;

    /** 	goto_ref = {}*/
    RefDS(_22037);
    DeRefDS(_30goto_ref_54170);
    _30goto_ref_54170 = _22037;

    /** 	label_block = {}*/
    RefDS(_22037);
    DeRefDS(_30label_block_54171);
    _30label_block_54171 = _22037;

    /** 	goto_init = map:new()*/
    _0 = _32new(690);
    DeRef(_30goto_init_54173);
    _30goto_init_54173 = _0;

    /** end procedure*/
    return;
    ;
}


void _30PopGoto()
{
    int _27957 = NOVALUE;
    int _27955 = NOVALUE;
    int _27954 = NOVALUE;
    int _27952 = NOVALUE;
    int _27951 = NOVALUE;
    int _27949 = NOVALUE;
    int _27948 = NOVALUE;
    int _27946 = NOVALUE;
    int _27945 = NOVALUE;
    int _27943 = NOVALUE;
    int _27942 = NOVALUE;
    int _27940 = NOVALUE;
    int _27939 = NOVALUE;
    int _27937 = NOVALUE;
    int _27936 = NOVALUE;
    int _27934 = NOVALUE;
    int _27933 = NOVALUE;
    int _0, _1, _2;
    

    /** 	CheckForUndefinedGotoLabels()*/
    _30CheckForUndefinedGotoLabels();

    /** 	goto_addr   = goto_stack[$][1]*/
    if (IS_SEQUENCE(_30goto_stack_54169)){
            _27933 = SEQ_PTR(_30goto_stack_54169)->length;
    }
    else {
        _27933 = 1;
    }
    _2 = (int)SEQ_PTR(_30goto_stack_54169);
    _27934 = (int)*(((s1_ptr)_2)->base + _27933);
    DeRef(_30goto_addr_54168);
    _2 = (int)SEQ_PTR(_27934);
    _30goto_addr_54168 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_30goto_addr_54168);
    _27934 = NOVALUE;

    /** 	goto_list   = goto_stack[$][2]*/
    if (IS_SEQUENCE(_30goto_stack_54169)){
            _27936 = SEQ_PTR(_30goto_stack_54169)->length;
    }
    else {
        _27936 = 1;
    }
    _2 = (int)SEQ_PTR(_30goto_stack_54169);
    _27937 = (int)*(((s1_ptr)_2)->base + _27936);
    DeRef(_26goto_list_12094);
    _2 = (int)SEQ_PTR(_27937);
    _26goto_list_12094 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_26goto_list_12094);
    _27937 = NOVALUE;

    /** 	goto_labels = goto_stack[$][3]*/
    if (IS_SEQUENCE(_30goto_stack_54169)){
            _27939 = SEQ_PTR(_30goto_stack_54169)->length;
    }
    else {
        _27939 = 1;
    }
    _2 = (int)SEQ_PTR(_30goto_stack_54169);
    _27940 = (int)*(((s1_ptr)_2)->base + _27939);
    DeRef(_30goto_labels_54167);
    _2 = (int)SEQ_PTR(_27940);
    _30goto_labels_54167 = (int)*(((s1_ptr)_2)->base + 3);
    Ref(_30goto_labels_54167);
    _27940 = NOVALUE;

    /** 	goto_delay  = goto_stack[$][4]*/
    if (IS_SEQUENCE(_30goto_stack_54169)){
            _27942 = SEQ_PTR(_30goto_stack_54169)->length;
    }
    else {
        _27942 = 1;
    }
    _2 = (int)SEQ_PTR(_30goto_stack_54169);
    _27943 = (int)*(((s1_ptr)_2)->base + _27942);
    DeRef(_26goto_delay_12093);
    _2 = (int)SEQ_PTR(_27943);
    _26goto_delay_12093 = (int)*(((s1_ptr)_2)->base + 4);
    Ref(_26goto_delay_12093);
    _27943 = NOVALUE;

    /** 	goto_line   = goto_stack[$][5]*/
    if (IS_SEQUENCE(_30goto_stack_54169)){
            _27945 = SEQ_PTR(_30goto_stack_54169)->length;
    }
    else {
        _27945 = 1;
    }
    _2 = (int)SEQ_PTR(_30goto_stack_54169);
    _27946 = (int)*(((s1_ptr)_2)->base + _27945);
    DeRef(_30goto_line_54166);
    _2 = (int)SEQ_PTR(_27946);
    _30goto_line_54166 = (int)*(((s1_ptr)_2)->base + 5);
    Ref(_30goto_line_54166);
    _27946 = NOVALUE;

    /** 	goto_ref    = goto_stack[$][6]*/
    if (IS_SEQUENCE(_30goto_stack_54169)){
            _27948 = SEQ_PTR(_30goto_stack_54169)->length;
    }
    else {
        _27948 = 1;
    }
    _2 = (int)SEQ_PTR(_30goto_stack_54169);
    _27949 = (int)*(((s1_ptr)_2)->base + _27948);
    DeRef(_30goto_ref_54170);
    _2 = (int)SEQ_PTR(_27949);
    _30goto_ref_54170 = (int)*(((s1_ptr)_2)->base + 6);
    Ref(_30goto_ref_54170);
    _27949 = NOVALUE;

    /** 	label_block = goto_stack[$][7]*/
    if (IS_SEQUENCE(_30goto_stack_54169)){
            _27951 = SEQ_PTR(_30goto_stack_54169)->length;
    }
    else {
        _27951 = 1;
    }
    _2 = (int)SEQ_PTR(_30goto_stack_54169);
    _27952 = (int)*(((s1_ptr)_2)->base + _27951);
    DeRef(_30label_block_54171);
    _2 = (int)SEQ_PTR(_27952);
    _30label_block_54171 = (int)*(((s1_ptr)_2)->base + 7);
    Ref(_30label_block_54171);
    _27952 = NOVALUE;

    /** 	goto_init   = goto_stack[$][8]*/
    if (IS_SEQUENCE(_30goto_stack_54169)){
            _27954 = SEQ_PTR(_30goto_stack_54169)->length;
    }
    else {
        _27954 = 1;
    }
    _2 = (int)SEQ_PTR(_30goto_stack_54169);
    _27955 = (int)*(((s1_ptr)_2)->base + _27954);
    DeRef(_30goto_init_54173);
    _2 = (int)SEQ_PTR(_27955);
    _30goto_init_54173 = (int)*(((s1_ptr)_2)->base + 8);
    Ref(_30goto_init_54173);
    _27955 = NOVALUE;

    /** 	goto_stack = remove( goto_stack, length( goto_stack ) )*/
    if (IS_SEQUENCE(_30goto_stack_54169)){
            _27957 = SEQ_PTR(_30goto_stack_54169)->length;
    }
    else {
        _27957 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_30goto_stack_54169);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_27957)) ? _27957 : (long)(DBL_PTR(_27957)->dbl);
        int stop = (IS_ATOM_INT(_27957)) ? _27957 : (long)(DBL_PTR(_27957)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_30goto_stack_54169), start, &_30goto_stack_54169 );
            }
            else Tail(SEQ_PTR(_30goto_stack_54169), stop+1, &_30goto_stack_54169);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_30goto_stack_54169), start, &_30goto_stack_54169);
        }
        else {
            assign_slice_seq = &assign_space;
            _30goto_stack_54169 = Remove_elements(start, stop, (SEQ_PTR(_30goto_stack_54169)->ref == 1));
        }
    }
    _27957 = NOVALUE;
    _27957 = NOVALUE;

    /** end procedure*/
    return;
    ;
}


void _30EnterTopLevel(int _end_line_table_54325)
{
    int _27972 = NOVALUE;
    int _27971 = NOVALUE;
    int _27969 = NOVALUE;
    int _27968 = NOVALUE;
    int _27966 = NOVALUE;
    int _27964 = NOVALUE;
    int _27963 = NOVALUE;
    int _27961 = NOVALUE;
    int _27959 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	if CurrentSub then*/
    if (_26CurrentSub_11990 == 0)
    {
        goto L1; // [7] 59
    }
    else{
    }

    /** 		if end_line_table then*/
    if (_end_line_table_54325 == 0)
    {
        goto L2; // [12] 58
    }
    else{
    }

    /** 			EndLineTable()*/
    _30EndLineTable();

    /** 			SymTab[CurrentSub][S_LINETAB] = LineTable*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_26CurrentSub_11990 + ((s1_ptr)_2)->base);
    RefDS(_26LineTable_12072);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_26S_LINETAB_11689))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_LINETAB_11689)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _26S_LINETAB_11689);
    _1 = *(int *)_2;
    *(int *)_2 = _26LineTable_12072;
    DeRef(_1);
    _27959 = NOVALUE;

    /** 			SymTab[CurrentSub][S_CODE] = Code*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_26CurrentSub_11990 + ((s1_ptr)_2)->base);
    RefDS(_26Code_12071);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_26S_CODE_11666))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_CODE_11666)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _26S_CODE_11666);
    _1 = *(int *)_2;
    *(int *)_2 = _26Code_12071;
    DeRef(_1);
    _27961 = NOVALUE;
L2: 
L1: 

    /** 	if length(goto_stack) then*/
    if (IS_SEQUENCE(_30goto_stack_54169)){
            _27963 = SEQ_PTR(_30goto_stack_54169)->length;
    }
    else {
        _27963 = 1;
    }
    if (_27963 == 0)
    {
        _27963 = NOVALUE;
        goto L3; // [66] 74
    }
    else{
        _27963 = NOVALUE;
    }

    /** 		PopGoto()*/
    _30PopGoto();
L3: 

    /** 	LineTable = SymTab[TopLevelSub][S_LINETAB]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _27964 = (int)*(((s1_ptr)_2)->base + _26TopLevelSub_11989);
    DeRef(_26LineTable_12072);
    _2 = (int)SEQ_PTR(_27964);
    if (!IS_ATOM_INT(_26S_LINETAB_11689)){
        _26LineTable_12072 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_LINETAB_11689)->dbl));
    }
    else{
        _26LineTable_12072 = (int)*(((s1_ptr)_2)->base + _26S_LINETAB_11689);
    }
    Ref(_26LineTable_12072);
    _27964 = NOVALUE;

    /** 	Code = SymTab[TopLevelSub][S_CODE]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _27966 = (int)*(((s1_ptr)_2)->base + _26TopLevelSub_11989);
    DeRef(_26Code_12071);
    _2 = (int)SEQ_PTR(_27966);
    if (!IS_ATOM_INT(_26S_CODE_11666)){
        _26Code_12071 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_CODE_11666)->dbl));
    }
    else{
        _26Code_12071 = (int)*(((s1_ptr)_2)->base + _26S_CODE_11666);
    }
    Ref(_26Code_12071);
    _27966 = NOVALUE;

    /** 	previous_op = -1*/
    _26previous_op_12081 = -1;

    /** 	CurrentSub = TopLevelSub*/
    _26CurrentSub_11990 = _26TopLevelSub_11989;

    /** 	clear_last()*/
    _37clear_last();

    /** 	if length( branch_stack ) then*/
    if (IS_SEQUENCE(_30branch_stack_54155)){
            _27968 = SEQ_PTR(_30branch_stack_54155)->length;
    }
    else {
        _27968 = 1;
    }
    if (_27968 == 0)
    {
        _27968 = NOVALUE;
        goto L4; // [137] 171
    }
    else{
        _27968 = NOVALUE;
    }

    /** 		branch_list = branch_stack[$]*/
    if (IS_SEQUENCE(_30branch_stack_54155)){
            _27969 = SEQ_PTR(_30branch_stack_54155)->length;
    }
    else {
        _27969 = 1;
    }
    DeRef(_30branch_list_54154);
    _2 = (int)SEQ_PTR(_30branch_stack_54155);
    _30branch_list_54154 = (int)*(((s1_ptr)_2)->base + _27969);
    Ref(_30branch_list_54154);

    /** 		branch_stack = tail( branch_stack )*/
    if (IS_SEQUENCE(_30branch_stack_54155)){
            _27971 = SEQ_PTR(_30branch_stack_54155)->length;
    }
    else {
        _27971 = 1;
    }
    _27972 = _27971 - 1;
    _27971 = NOVALUE;
    {
        int len = SEQ_PTR(_30branch_stack_54155)->length;
        int size = (IS_ATOM_INT(_27972)) ? _27972 : (long)(DBL_PTR(_27972)->dbl);
        if (size <= 0) {
            DeRef(_30branch_stack_54155);
            _30branch_stack_54155 = MAKE_SEQ(NewS1(0));
        }
        else if (len <= size) {
            RefDS(_30branch_stack_54155);
            DeRef(_30branch_stack_54155);
            _30branch_stack_54155 = _30branch_stack_54155;
        }
        else Tail(SEQ_PTR(_30branch_stack_54155), len-size+1, &_30branch_stack_54155);
    }
    _27972 = NOVALUE;
L4: 

    /** end procedure*/
    return;
    ;
}


void _30LeaveTopLevel()
{
    int _27977 = NOVALUE;
    int _27975 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	branch_stack = append( branch_stack, branch_list )*/
    RefDS(_30branch_list_54154);
    Append(&_30branch_stack_54155, _30branch_stack_54155, _30branch_list_54154);

    /** 	branch_list = {}*/
    RefDS(_22037);
    DeRefDS(_30branch_list_54154);
    _30branch_list_54154 = _22037;

    /** 	PushGoto()*/
    _30PushGoto();

    /** 	LastLineNumber = -1*/
    _60LastLineNumber_23941 = -1;

    /** 	SymTab[TopLevelSub][S_LINETAB] = LineTable*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_26TopLevelSub_11989 + ((s1_ptr)_2)->base);
    RefDS(_26LineTable_12072);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_26S_LINETAB_11689))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_LINETAB_11689)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _26S_LINETAB_11689);
    _1 = *(int *)_2;
    *(int *)_2 = _26LineTable_12072;
    DeRef(_1);
    _27975 = NOVALUE;

    /** 	SymTab[TopLevelSub][S_CODE] = Code*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_26TopLevelSub_11989 + ((s1_ptr)_2)->base);
    RefDS(_26Code_12071);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_26S_CODE_11666))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_CODE_11666)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _26S_CODE_11666);
    _1 = *(int *)_2;
    *(int *)_2 = _26Code_12071;
    DeRef(_1);
    _27977 = NOVALUE;

    /** 	LineTable = {}*/
    RefDS(_22037);
    DeRefDS(_26LineTable_12072);
    _26LineTable_12072 = _22037;

    /** 	Code = {}*/
    RefDS(_22037);
    DeRefDS(_26Code_12071);
    _26Code_12071 = _22037;

    /** 	previous_op = -1*/
    _26previous_op_12081 = -1;

    /** 	clear_last()*/
    _37clear_last();

    /** end procedure*/
    return;
    ;
}


void _30InitParser()
{
    int _0, _1, _2;
    

    /** 	goto_stack = {}*/
    RefDS(_22037);
    DeRef(_30goto_stack_54169);
    _30goto_stack_54169 = _22037;

    /** 	goto_labels = {}*/
    RefDS(_22037);
    DeRef(_30goto_labels_54167);
    _30goto_labels_54167 = _22037;

    /** 	label_block = {}*/
    RefDS(_22037);
    DeRef(_30label_block_54171);
    _30label_block_54171 = _22037;

    /** 	goto_ref = {}*/
    RefDS(_22037);
    DeRef(_30goto_ref_54170);
    _30goto_ref_54170 = _22037;

    /** 	goto_addr = {}*/
    RefDS(_22037);
    DeRef(_30goto_addr_54168);
    _30goto_addr_54168 = _22037;

    /** 	goto_line = {}*/
    RefDS(_22037);
    DeRef(_30goto_line_54166);
    _30goto_line_54166 = _22037;

    /** 	break_list = {}*/
    RefDS(_22037);
    DeRefi(_30break_list_54174);
    _30break_list_54174 = _22037;

    /** 	break_delay = {}*/
    RefDS(_22037);
    DeRef(_30break_delay_54175);
    _30break_delay_54175 = _22037;

    /** 	exit_list = {}*/
    RefDS(_22037);
    DeRefi(_30exit_list_54176);
    _30exit_list_54176 = _22037;

    /** 	exit_delay = {}*/
    RefDS(_22037);
    DeRef(_30exit_delay_54177);
    _30exit_delay_54177 = _22037;

    /** 	continue_list = {}*/
    RefDS(_22037);
    DeRefi(_30continue_list_54178);
    _30continue_list_54178 = _22037;

    /** 	continue_delay = {}*/
    RefDS(_22037);
    DeRef(_30continue_delay_54179);
    _30continue_delay_54179 = _22037;

    /** 	init_stack = {}*/
    RefDS(_22037);
    DeRefi(_30init_stack_54189);
    _30init_stack_54189 = _22037;

    /** 	CurrentSub = 0*/
    _26CurrentSub_11990 = 0;

    /** 	CreateTopLevel()*/
    _30CreateTopLevel();

    /** 	EnterTopLevel()*/
    _30EnterTopLevel(1);

    /** 	backed_up_tok = {}*/
    RefDS(_22037);
    DeRef(_30backed_up_tok_54163);
    _30backed_up_tok_54163 = _22037;

    /** 	loop_stack = {}*/
    RefDS(_22037);
    DeRefi(_30loop_stack_54190);
    _30loop_stack_54190 = _22037;

    /** 	stmt_nest = 0*/
    _30stmt_nest_54188 = 0;

    /** 	loop_labels = {}*/
    RefDS(_22037);
    DeRef(_30loop_labels_54184);
    _30loop_labels_54184 = _22037;

    /** 	if_labels = {}*/
    RefDS(_22037);
    DeRef(_30if_labels_54185);
    _30if_labels_54185 = _22037;

    /** 	if_stack = {}*/
    RefDS(_22037);
    DeRefi(_30if_stack_54191);
    _30if_stack_54191 = _22037;

    /** 	continue_addr = {}*/
    RefDS(_22037);
    DeRefi(_30continue_addr_54181);
    _30continue_addr_54181 = _22037;

    /** 	retry_addr = {}*/
    RefDS(_22037);
    DeRefi(_30retry_addr_54182);
    _30retry_addr_54182 = _22037;

    /** 	entry_addr = {}*/
    RefDS(_22037);
    DeRefi(_30entry_addr_54180);
    _30entry_addr_54180 = _22037;

    /** 	block_list = {}*/
    RefDS(_22037);
    DeRefi(_30block_list_54186);
    _30block_list_54186 = _22037;

    /** 	block_index = 0*/
    _30block_index_54187 = 0;

    /** 	param_num = -1*/
    _30param_num_54165 = -1;

    /** 	entry_stack = {}*/
    RefDS(_22037);
    DeRef(_30entry_stack_54183);
    _30entry_stack_54183 = _22037;

    /** 	goto_init = map:new()*/
    _0 = _32new(690);
    DeRef(_30goto_init_54173);
    _30goto_init_54173 = _0;

    /** end procedure*/
    return;
    ;
}


void _30NotReached(int _tok_54399, int _keyword_54400)
{
    int _27993 = NOVALUE;
    int _27992 = NOVALUE;
    int _27991 = NOVALUE;
    int _27990 = NOVALUE;
    int _27989 = NOVALUE;
    int _27988 = NOVALUE;
    int _27986 = NOVALUE;
    int _27985 = NOVALUE;
    int _27984 = NOVALUE;
    int _27983 = NOVALUE;
    int _27981 = NOVALUE;
    int _27980 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_tok_54399)) {
        _1 = (long)(DBL_PTR(_tok_54399)->dbl);
        DeRefDS(_tok_54399);
        _tok_54399 = _1;
    }

    /** 	if not find(tok, {END, ELSE, ELSIF, END_OF_FILE, CASE, IFDEF, ELSIFDEF, ELSEDEF}) then*/
    _1 = NewS1(8);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 402;
    *((int *)(_2+8)) = 23;
    *((int *)(_2+12)) = 414;
    *((int *)(_2+16)) = -21;
    *((int *)(_2+20)) = 186;
    *((int *)(_2+24)) = 407;
    *((int *)(_2+28)) = 408;
    *((int *)(_2+32)) = 409;
    _27980 = MAKE_SEQ(_1);
    _27981 = find_from(_tok_54399, _27980, 1);
    DeRefDS(_27980);
    _27980 = NOVALUE;
    if (_27981 != 0)
    goto L1; // [39] 135
    _27981 = NOVALUE;

    /** 		if equal(keyword, "goto") and find(tok, {LOOP, LABEL, WHILE}) then*/
    if (_keyword_54400 == _26349)
    _27983 = 1;
    else if (IS_ATOM_INT(_keyword_54400) && IS_ATOM_INT(_26349))
    _27983 = 0;
    else
    _27983 = (compare(_keyword_54400, _26349) == 0);
    if (_27983 == 0) {
        goto L2; // [48] 79
    }
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 422;
    *((int *)(_2+8)) = 419;
    *((int *)(_2+12)) = 47;
    _27985 = MAKE_SEQ(_1);
    _27986 = find_from(_tok_54399, _27985, 1);
    DeRefDS(_27985);
    _27985 = NOVALUE;
    if (_27986 == 0)
    {
        _27986 = NOVALUE;
        goto L2; // [70] 79
    }
    else{
        _27986 = NOVALUE;
    }

    /** 			return*/
    DeRefDSi(_keyword_54400);
    return;
L2: 

    /** 		if equal(keyword, "abort()") and tok = LABEL then*/
    if (_keyword_54400 == _27987)
    _27988 = 1;
    else if (IS_ATOM_INT(_keyword_54400) && IS_ATOM_INT(_27987))
    _27988 = 0;
    else
    _27988 = (compare(_keyword_54400, _27987) == 0);
    if (_27988 == 0) {
        goto L3; // [85] 105
    }
    _27990 = (_tok_54399 == 419);
    if (_27990 == 0)
    {
        DeRef(_27990);
        _27990 = NOVALUE;
        goto L3; // [96] 105
    }
    else{
        DeRef(_27990);
        _27990 = NOVALUE;
    }

    /** 			return*/
    DeRefDSi(_keyword_54400);
    return;
L3: 

    /** 		Warning(218, not_reached_warning_flag,*/
    _2 = (int)SEQ_PTR(_27known_files_10922);
    _27991 = (int)*(((s1_ptr)_2)->base + _26current_file_no_11982);
    Ref(_27991);
    _27992 = _52name_ext(_27991);
    _27991 = NOVALUE;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _27992;
    *((int *)(_2+8)) = _26line_number_11983;
    RefDS(_keyword_54400);
    *((int *)(_2+12)) = _keyword_54400;
    _27993 = MAKE_SEQ(_1);
    _27992 = NOVALUE;
    _43Warning(218, 512, _27993);
    _27993 = NOVALUE;
L1: 

    /** end procedure*/
    DeRefDSi(_keyword_54400);
    return;
    ;
}


void _30Forward_InitCheck(int _tok_54439, int _ref_54440)
{
    int _sym_54442 = NOVALUE;
    int _27999 = NOVALUE;
    int _27998 = NOVALUE;
    int _27997 = NOVALUE;
    int _27995 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if ref then*/
    if (_ref_54440 == 0)
    {
        goto L1; // [5] 83
    }
    else{
    }

    /** 		integer sym = tok[T_SYM]*/
    _2 = (int)SEQ_PTR(_tok_54439);
    _sym_54442 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_sym_54442)){
        _sym_54442 = (long)DBL_PTR(_sym_54442)->dbl;
    }

    /** 		if tok[T_ID] = QUALIFIED_VARIABLE then*/
    _2 = (int)SEQ_PTR(_tok_54439);
    _27995 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _27995, 512)){
        _27995 = NOVALUE;
        goto L2; // [28] 50
    }
    _27995 = NOVALUE;

    /** 			set_qualified_fwd( SymTab[sym][S_FILE_NO] )*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _27997 = (int)*(((s1_ptr)_2)->base + _sym_54442);
    _2 = (int)SEQ_PTR(_27997);
    if (!IS_ATOM_INT(_26S_FILE_NO_11650)){
        _27998 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_FILE_NO_11650)->dbl));
    }
    else{
        _27998 = (int)*(((s1_ptr)_2)->base + _26S_FILE_NO_11650);
    }
    _27997 = NOVALUE;
    Ref(_27998);
    _60set_qualified_fwd(_27998);
    _27998 = NOVALUE;
L2: 

    /** 		ref = new_forward_reference( GLOBAL_INIT_CHECK, tok[T_SYM], GLOBAL_INIT_CHECK )*/
    _2 = (int)SEQ_PTR(_tok_54439);
    _27999 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_27999);
    _ref_54440 = _29new_forward_reference(109, _27999, 109);
    _27999 = NOVALUE;
    if (!IS_ATOM_INT(_ref_54440)) {
        _1 = (long)(DBL_PTR(_ref_54440)->dbl);
        DeRefDS(_ref_54440);
        _ref_54440 = _1;
    }

    /** 		emit_op( GLOBAL_INIT_CHECK )*/
    _37emit_op(109);

    /** 		emit_addr( sym )*/
    _37emit_addr(_sym_54442);
L1: 

    /** end procedure*/
    DeRef(_tok_54439);
    return;
    ;
}


void _30InitCheck(int _sym_54467, int _ref_54468)
{
    int _28076 = NOVALUE;
    int _28075 = NOVALUE;
    int _28074 = NOVALUE;
    int _28073 = NOVALUE;
    int _28072 = NOVALUE;
    int _28071 = NOVALUE;
    int _28070 = NOVALUE;
    int _28069 = NOVALUE;
    int _28067 = NOVALUE;
    int _28065 = NOVALUE;
    int _28064 = NOVALUE;
    int _28062 = NOVALUE;
    int _28061 = NOVALUE;
    int _28060 = NOVALUE;
    int _28059 = NOVALUE;
    int _28058 = NOVALUE;
    int _28057 = NOVALUE;
    int _28056 = NOVALUE;
    int _28055 = NOVALUE;
    int _28054 = NOVALUE;
    int _28053 = NOVALUE;
    int _28052 = NOVALUE;
    int _28051 = NOVALUE;
    int _28050 = NOVALUE;
    int _28049 = NOVALUE;
    int _28047 = NOVALUE;
    int _28046 = NOVALUE;
    int _28045 = NOVALUE;
    int _28044 = NOVALUE;
    int _28043 = NOVALUE;
    int _28042 = NOVALUE;
    int _28041 = NOVALUE;
    int _28040 = NOVALUE;
    int _28039 = NOVALUE;
    int _28037 = NOVALUE;
    int _28036 = NOVALUE;
    int _28035 = NOVALUE;
    int _28034 = NOVALUE;
    int _28033 = NOVALUE;
    int _28032 = NOVALUE;
    int _28031 = NOVALUE;
    int _28030 = NOVALUE;
    int _28029 = NOVALUE;
    int _28028 = NOVALUE;
    int _28027 = NOVALUE;
    int _28026 = NOVALUE;
    int _28025 = NOVALUE;
    int _28024 = NOVALUE;
    int _28023 = NOVALUE;
    int _28022 = NOVALUE;
    int _28021 = NOVALUE;
    int _28020 = NOVALUE;
    int _28019 = NOVALUE;
    int _28018 = NOVALUE;
    int _28017 = NOVALUE;
    int _28016 = NOVALUE;
    int _28014 = NOVALUE;
    int _28013 = NOVALUE;
    int _28012 = NOVALUE;
    int _28011 = NOVALUE;
    int _28010 = NOVALUE;
    int _28009 = NOVALUE;
    int _28008 = NOVALUE;
    int _28007 = NOVALUE;
    int _28006 = NOVALUE;
    int _28005 = NOVALUE;
    int _28004 = NOVALUE;
    int _28003 = NOVALUE;
    int _28001 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	if sym < 0 or (SymTab[sym][S_MODE] = M_NORMAL and*/
    _28001 = (_sym_54467 < 0);
    if (_28001 != 0) {
        goto L1; // [11] 90
    }
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _28003 = (int)*(((s1_ptr)_2)->base + _sym_54467);
    _2 = (int)SEQ_PTR(_28003);
    _28004 = (int)*(((s1_ptr)_2)->base + 3);
    _28003 = NOVALUE;
    if (IS_ATOM_INT(_28004)) {
        _28005 = (_28004 == 1);
    }
    else {
        _28005 = binary_op(EQUALS, _28004, 1);
    }
    _28004 = NOVALUE;
    if (IS_ATOM_INT(_28005)) {
        if (_28005 == 0) {
            _28006 = 0;
            goto L2; // [33] 59
        }
    }
    else {
        if (DBL_PTR(_28005)->dbl == 0.0) {
            _28006 = 0;
            goto L2; // [33] 59
        }
    }
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _28007 = (int)*(((s1_ptr)_2)->base + _sym_54467);
    _2 = (int)SEQ_PTR(_28007);
    _28008 = (int)*(((s1_ptr)_2)->base + 4);
    _28007 = NOVALUE;
    if (IS_ATOM_INT(_28008)) {
        _28009 = (_28008 != 2);
    }
    else {
        _28009 = binary_op(NOTEQ, _28008, 2);
    }
    _28008 = NOVALUE;
    DeRef(_28006);
    if (IS_ATOM_INT(_28009))
    _28006 = (_28009 != 0);
    else
    _28006 = DBL_PTR(_28009)->dbl != 0.0;
L2: 
    if (_28006 == 0) {
        DeRef(_28010);
        _28010 = 0;
        goto L3; // [59] 85
    }
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _28011 = (int)*(((s1_ptr)_2)->base + _sym_54467);
    _2 = (int)SEQ_PTR(_28011);
    _28012 = (int)*(((s1_ptr)_2)->base + 4);
    _28011 = NOVALUE;
    if (IS_ATOM_INT(_28012)) {
        _28013 = (_28012 != 4);
    }
    else {
        _28013 = binary_op(NOTEQ, _28012, 4);
    }
    _28012 = NOVALUE;
    if (IS_ATOM_INT(_28013))
    _28010 = (_28013 != 0);
    else
    _28010 = DBL_PTR(_28013)->dbl != 0.0;
L3: 
    if (_28010 == 0)
    {
        _28010 = NOVALUE;
        goto L4; // [86] 502
    }
    else{
        _28010 = NOVALUE;
    }
L1: 

    /** 		if sym < 0 or ((SymTab[sym][S_SCOPE] != SC_PRIVATE and*/
    _28014 = (_sym_54467 < 0);
    if (_28014 != 0) {
        goto L5; // [96] 213
    }
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _28016 = (int)*(((s1_ptr)_2)->base + _sym_54467);
    _2 = (int)SEQ_PTR(_28016);
    _28017 = (int)*(((s1_ptr)_2)->base + 4);
    _28016 = NOVALUE;
    if (IS_ATOM_INT(_28017)) {
        _28018 = (_28017 != 3);
    }
    else {
        _28018 = binary_op(NOTEQ, _28017, 3);
    }
    _28017 = NOVALUE;
    if (IS_ATOM_INT(_28018)) {
        if (_28018 == 0) {
            DeRef(_28019);
            _28019 = 0;
            goto L6; // [118] 144
        }
    }
    else {
        if (DBL_PTR(_28018)->dbl == 0.0) {
            DeRef(_28019);
            _28019 = 0;
            goto L6; // [118] 144
        }
    }
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _28020 = (int)*(((s1_ptr)_2)->base + _sym_54467);
    _2 = (int)SEQ_PTR(_28020);
    _28021 = (int)*(((s1_ptr)_2)->base + 1);
    _28020 = NOVALUE;
    if (_28021 == _26NOVALUE_11836)
    _28022 = 1;
    else if (IS_ATOM_INT(_28021) && IS_ATOM_INT(_26NOVALUE_11836))
    _28022 = 0;
    else
    _28022 = (compare(_28021, _26NOVALUE_11836) == 0);
    _28021 = NOVALUE;
    DeRef(_28019);
    _28019 = (_28022 != 0);
L6: 
    if (_28019 != 0) {
        DeRef(_28023);
        _28023 = 1;
        goto L7; // [144] 208
    }
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _28024 = (int)*(((s1_ptr)_2)->base + _sym_54467);
    _2 = (int)SEQ_PTR(_28024);
    _28025 = (int)*(((s1_ptr)_2)->base + 4);
    _28024 = NOVALUE;
    if (IS_ATOM_INT(_28025)) {
        _28026 = (_28025 == 3);
    }
    else {
        _28026 = binary_op(EQUALS, _28025, 3);
    }
    _28025 = NOVALUE;
    if (IS_ATOM_INT(_28026)) {
        if (_28026 == 0) {
            DeRef(_28027);
            _28027 = 0;
            goto L8; // [166] 204
        }
    }
    else {
        if (DBL_PTR(_28026)->dbl == 0.0) {
            DeRef(_28027);
            _28027 = 0;
            goto L8; // [166] 204
        }
    }
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _28028 = (int)*(((s1_ptr)_2)->base + _sym_54467);
    _2 = (int)SEQ_PTR(_28028);
    _28029 = (int)*(((s1_ptr)_2)->base + 16);
    _28028 = NOVALUE;
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _28030 = (int)*(((s1_ptr)_2)->base + _26CurrentSub_11990);
    _2 = (int)SEQ_PTR(_28030);
    if (!IS_ATOM_INT(_26S_NUM_ARGS_11705)){
        _28031 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NUM_ARGS_11705)->dbl));
    }
    else{
        _28031 = (int)*(((s1_ptr)_2)->base + _26S_NUM_ARGS_11705);
    }
    _28030 = NOVALUE;
    if (IS_ATOM_INT(_28029) && IS_ATOM_INT(_28031)) {
        _28032 = (_28029 >= _28031);
    }
    else {
        _28032 = binary_op(GREATEREQ, _28029, _28031);
    }
    _28029 = NOVALUE;
    _28031 = NOVALUE;
    DeRef(_28027);
    if (IS_ATOM_INT(_28032))
    _28027 = (_28032 != 0);
    else
    _28027 = DBL_PTR(_28032)->dbl != 0.0;
L8: 
    DeRef(_28023);
    _28023 = (_28027 != 0);
L7: 
    if (_28023 == 0)
    {
        _28023 = NOVALUE;
        goto L9; // [209] 566
    }
    else{
        _28023 = NOVALUE;
    }
L5: 

    /** 			if sym < 0 or (SymTab[sym][S_INITLEVEL] = -1)*/
    _28033 = (_sym_54467 < 0);
    if (_28033 != 0) {
        _28034 = 1;
        goto LA; // [219] 243
    }
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _28035 = (int)*(((s1_ptr)_2)->base + _sym_54467);
    _2 = (int)SEQ_PTR(_28035);
    _28036 = (int)*(((s1_ptr)_2)->base + 14);
    _28035 = NOVALUE;
    if (IS_ATOM_INT(_28036)) {
        _28037 = (_28036 == -1);
    }
    else {
        _28037 = binary_op(EQUALS, _28036, -1);
    }
    _28036 = NOVALUE;
    if (IS_ATOM_INT(_28037))
    _28034 = (_28037 != 0);
    else
    _28034 = DBL_PTR(_28037)->dbl != 0.0;
LA: 
    if (_28034 != 0) {
        goto LB; // [243] 270
    }
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _28039 = (int)*(((s1_ptr)_2)->base + _sym_54467);
    _2 = (int)SEQ_PTR(_28039);
    _28040 = (int)*(((s1_ptr)_2)->base + 4);
    _28039 = NOVALUE;
    if (IS_ATOM_INT(_28040)) {
        _28041 = (_28040 != 3);
    }
    else {
        _28041 = binary_op(NOTEQ, _28040, 3);
    }
    _28040 = NOVALUE;
    if (_28041 == 0) {
        DeRef(_28041);
        _28041 = NOVALUE;
        goto L9; // [266] 566
    }
    else {
        if (!IS_ATOM_INT(_28041) && DBL_PTR(_28041)->dbl == 0.0){
            DeRef(_28041);
            _28041 = NOVALUE;
            goto L9; // [266] 566
        }
        DeRef(_28041);
        _28041 = NOVALUE;
    }
    DeRef(_28041);
    _28041 = NOVALUE;
LB: 

    /** 				if ref then*/
    if (_ref_54468 == 0)
    {
        goto LC; // [272] 375
    }
    else{
    }

    /** 					if sym > 0 and (SymTab[sym][S_SCOPE] = SC_UNDEFINED) then*/
    _28042 = (_sym_54467 > 0);
    if (_28042 == 0) {
        goto LD; // [281] 317
    }
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _28044 = (int)*(((s1_ptr)_2)->base + _sym_54467);
    _2 = (int)SEQ_PTR(_28044);
    _28045 = (int)*(((s1_ptr)_2)->base + 4);
    _28044 = NOVALUE;
    if (IS_ATOM_INT(_28045)) {
        _28046 = (_28045 == 9);
    }
    else {
        _28046 = binary_op(EQUALS, _28045, 9);
    }
    _28045 = NOVALUE;
    if (_28046 == 0) {
        DeRef(_28046);
        _28046 = NOVALUE;
        goto LD; // [304] 317
    }
    else {
        if (!IS_ATOM_INT(_28046) && DBL_PTR(_28046)->dbl == 0.0){
            DeRef(_28046);
            _28046 = NOVALUE;
            goto LD; // [304] 317
        }
        DeRef(_28046);
        _28046 = NOVALUE;
    }
    DeRef(_28046);
    _28046 = NOVALUE;

    /** 						emit_op(PRIVATE_INIT_CHECK)*/
    _37emit_op(30);
    goto LE; // [314] 369
LD: 

    /** 					elsif sym < 0 or find(SymTab[sym][S_SCOPE], SCOPE_TYPES) then*/
    _28047 = (_sym_54467 < 0);
    if (_28047 != 0) {
        goto LF; // [323] 351
    }
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _28049 = (int)*(((s1_ptr)_2)->base + _sym_54467);
    _2 = (int)SEQ_PTR(_28049);
    _28050 = (int)*(((s1_ptr)_2)->base + 4);
    _28049 = NOVALUE;
    _28051 = find_from(_28050, _30SCOPE_TYPES_54147, 1);
    _28050 = NOVALUE;
    if (_28051 == 0)
    {
        _28051 = NOVALUE;
        goto L10; // [347] 361
    }
    else{
        _28051 = NOVALUE;
    }
LF: 

    /** 						emit_op(GLOBAL_INIT_CHECK) -- will become NOP2*/
    _37emit_op(109);
    goto LE; // [358] 369
L10: 

    /** 						emit_op(PRIVATE_INIT_CHECK)*/
    _37emit_op(30);
LE: 

    /** 					emit_addr(sym)*/
    _37emit_addr(_sym_54467);
LC: 

    /** 				if sym > 0 */
    _28052 = (_sym_54467 > 0);
    if (_28052 == 0) {
        _28053 = 0;
        goto L11; // [381] 411
    }
    _28054 = (_30short_circuit_54156 <= 0);
    if (_28054 != 0) {
        _28055 = 1;
        goto L12; // [391] 407
    }
    _28056 = (_30short_circuit_B_54158 == _9FALSE_428);
    _28055 = (_28056 != 0);
L12: 
    _28053 = (_28055 != 0);
L11: 
    if (_28053 == 0) {
        goto L9; // [411] 566
    }
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _28058 = (int)*(((s1_ptr)_2)->base + _sym_54467);
    _2 = (int)SEQ_PTR(_28058);
    _28059 = (int)*(((s1_ptr)_2)->base + 4);
    _28058 = NOVALUE;
    if (IS_ATOM_INT(_28059)) {
        _28060 = (_28059 != 3);
    }
    else {
        _28060 = binary_op(NOTEQ, _28059, 3);
    }
    _28059 = NOVALUE;
    if (IS_ATOM_INT(_28060)) {
        _28061 = (_28060 == 0);
    }
    else {
        _28061 = unary_op(NOT, _28060);
    }
    DeRef(_28060);
    _28060 = NOVALUE;
    if (_28061 == 0) {
        DeRef(_28061);
        _28061 = NOVALUE;
        goto L9; // [437] 566
    }
    else {
        if (!IS_ATOM_INT(_28061) && DBL_PTR(_28061)->dbl == 0.0){
            DeRef(_28061);
            _28061 = NOVALUE;
            goto L9; // [437] 566
        }
        DeRef(_28061);
        _28061 = NOVALUE;
    }
    DeRef(_28061);
    _28061 = NOVALUE;

    /** 					if CurrentSub != TopLevelSub */
    _28062 = (_26CurrentSub_11990 != _26TopLevelSub_11989);
    if (_28062 != 0) {
        goto L13; // [450] 470
    }
    if (IS_SEQUENCE(_27known_files_10922)){
            _28064 = SEQ_PTR(_27known_files_10922)->length;
    }
    else {
        _28064 = 1;
    }
    _28065 = (_26current_file_no_11982 == _28064);
    _28064 = NOVALUE;
    if (_28065 == 0)
    {
        DeRef(_28065);
        _28065 = NOVALUE;
        goto L9; // [466] 566
    }
    else{
        DeRef(_28065);
        _28065 = NOVALUE;
    }
L13: 

    /** 						init_stack = append(init_stack, sym)*/
    Append(&_30init_stack_54189, _30init_stack_54189, _sym_54467);

    /** 						SymTab[sym][S_INITLEVEL] = stmt_nest*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_54467 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 14);
    _1 = *(int *)_2;
    *(int *)_2 = _30stmt_nest_54188;
    DeRef(_1);
    _28067 = NOVALUE;
    goto L9; // [499] 566
L4: 

    /** 	elsif ref and sym > 0 and sym_mode( sym ) = M_CONSTANT and equal( NOVALUE, sym_obj( sym ) ) then*/
    if (_ref_54468 == 0) {
        _28069 = 0;
        goto L14; // [504] 516
    }
    _28070 = (_sym_54467 > 0);
    _28069 = (_28070 != 0);
L14: 
    if (_28069 == 0) {
        _28071 = 0;
        goto L15; // [516] 534
    }
    _28072 = _52sym_mode(_sym_54467);
    if (IS_ATOM_INT(_28072)) {
        _28073 = (_28072 == 2);
    }
    else {
        _28073 = binary_op(EQUALS, _28072, 2);
    }
    DeRef(_28072);
    _28072 = NOVALUE;
    if (IS_ATOM_INT(_28073))
    _28071 = (_28073 != 0);
    else
    _28071 = DBL_PTR(_28073)->dbl != 0.0;
L15: 
    if (_28071 == 0) {
        goto L16; // [534] 565
    }
    _28075 = _52sym_obj(_sym_54467);
    if (_26NOVALUE_11836 == _28075)
    _28076 = 1;
    else if (IS_ATOM_INT(_26NOVALUE_11836) && IS_ATOM_INT(_28075))
    _28076 = 0;
    else
    _28076 = (compare(_26NOVALUE_11836, _28075) == 0);
    DeRef(_28075);
    _28075 = NOVALUE;
    if (_28076 == 0)
    {
        _28076 = NOVALUE;
        goto L16; // [549] 565
    }
    else{
        _28076 = NOVALUE;
    }

    /** 		emit_op( GLOBAL_INIT_CHECK )*/
    _37emit_op(109);

    /** 		emit_addr(sym)*/
    _37emit_addr(_sym_54467);
L16: 
L9: 

    /** end procedure*/
    DeRef(_28001);
    _28001 = NOVALUE;
    DeRef(_28014);
    _28014 = NOVALUE;
    DeRef(_28005);
    _28005 = NOVALUE;
    DeRef(_28009);
    _28009 = NOVALUE;
    DeRef(_28013);
    _28013 = NOVALUE;
    DeRef(_28033);
    _28033 = NOVALUE;
    DeRef(_28018);
    _28018 = NOVALUE;
    DeRef(_28026);
    _28026 = NOVALUE;
    DeRef(_28042);
    _28042 = NOVALUE;
    DeRef(_28032);
    _28032 = NOVALUE;
    DeRef(_28037);
    _28037 = NOVALUE;
    DeRef(_28047);
    _28047 = NOVALUE;
    DeRef(_28052);
    _28052 = NOVALUE;
    DeRef(_28054);
    _28054 = NOVALUE;
    DeRef(_28056);
    _28056 = NOVALUE;
    DeRef(_28062);
    _28062 = NOVALUE;
    DeRef(_28070);
    _28070 = NOVALUE;
    DeRef(_28073);
    _28073 = NOVALUE;
    return;
    ;
}


void _30InitDelete()
{
    int _28089 = NOVALUE;
    int _28088 = NOVALUE;
    int _28086 = NOVALUE;
    int _28085 = NOVALUE;
    int _28084 = NOVALUE;
    int _28083 = NOVALUE;
    int _28082 = NOVALUE;
    int _28081 = NOVALUE;
    int _28080 = NOVALUE;
    int _28079 = NOVALUE;
    int _28078 = NOVALUE;
    int _28077 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	while length(init_stack) and*/
L1: 
    if (IS_SEQUENCE(_30init_stack_54189)){
            _28077 = SEQ_PTR(_30init_stack_54189)->length;
    }
    else {
        _28077 = 1;
    }
    if (_28077 == 0) {
        goto L2; // [11] 91
    }
    if (IS_SEQUENCE(_30init_stack_54189)){
            _28079 = SEQ_PTR(_30init_stack_54189)->length;
    }
    else {
        _28079 = 1;
    }
    _2 = (int)SEQ_PTR(_30init_stack_54189);
    _28080 = (int)*(((s1_ptr)_2)->base + _28079);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _28081 = (int)*(((s1_ptr)_2)->base + _28080);
    _2 = (int)SEQ_PTR(_28081);
    _28082 = (int)*(((s1_ptr)_2)->base + 14);
    _28081 = NOVALUE;
    if (IS_ATOM_INT(_28082)) {
        _28083 = (_28082 > _30stmt_nest_54188);
    }
    else {
        _28083 = binary_op(GREATER, _28082, _30stmt_nest_54188);
    }
    _28082 = NOVALUE;
    if (_28083 <= 0) {
        if (_28083 == 0) {
            DeRef(_28083);
            _28083 = NOVALUE;
            goto L2; // [43] 91
        }
        else {
            if (!IS_ATOM_INT(_28083) && DBL_PTR(_28083)->dbl == 0.0){
                DeRef(_28083);
                _28083 = NOVALUE;
                goto L2; // [43] 91
            }
            DeRef(_28083);
            _28083 = NOVALUE;
        }
    }
    DeRef(_28083);
    _28083 = NOVALUE;

    /** 		SymTab[init_stack[$]][S_INITLEVEL] = -1*/
    if (IS_SEQUENCE(_30init_stack_54189)){
            _28084 = SEQ_PTR(_30init_stack_54189)->length;
    }
    else {
        _28084 = 1;
    }
    _2 = (int)SEQ_PTR(_30init_stack_54189);
    _28085 = (int)*(((s1_ptr)_2)->base + _28084);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_28085 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 14);
    _1 = *(int *)_2;
    *(int *)_2 = -1;
    DeRef(_1);
    _28086 = NOVALUE;

    /** 		init_stack = init_stack[1..$-1]*/
    if (IS_SEQUENCE(_30init_stack_54189)){
            _28088 = SEQ_PTR(_30init_stack_54189)->length;
    }
    else {
        _28088 = 1;
    }
    _28089 = _28088 - 1;
    _28088 = NOVALUE;
    rhs_slice_target = (object_ptr)&_30init_stack_54189;
    RHS_Slice(_30init_stack_54189, 1, _28089);

    /** 	end while*/
    goto L1; // [88] 6
L2: 

    /** end procedure*/
    _28080 = NOVALUE;
    _28085 = NOVALUE;
    DeRef(_28089);
    _28089 = NOVALUE;
    return;
    ;
}


void _30emit_forward_addr()
{
    int _28091 = NOVALUE;
    int _0, _1, _2;
    

    /** 	emit_addr(0)*/
    _37emit_addr(0);

    /** 	branch_list = append(branch_list, length(Code))*/
    if (IS_SEQUENCE(_26Code_12071)){
            _28091 = SEQ_PTR(_26Code_12071)->length;
    }
    else {
        _28091 = 1;
    }
    Append(&_30branch_list_54154, _30branch_list_54154, _28091);
    _28091 = NOVALUE;

    /** end procedure*/
    return;
    ;
}


void _30StraightenBranches()
{
    int _br_54641 = NOVALUE;
    int _target_54642 = NOVALUE;
    int _28112 = NOVALUE;
    int _28111 = NOVALUE;
    int _28110 = NOVALUE;
    int _28109 = NOVALUE;
    int _28107 = NOVALUE;
    int _28106 = NOVALUE;
    int _28105 = NOVALUE;
    int _28103 = NOVALUE;
    int _28102 = NOVALUE;
    int _28101 = NOVALUE;
    int _28100 = NOVALUE;
    int _28098 = NOVALUE;
    int _28095 = NOVALUE;
    int _28094 = NOVALUE;
    int _28093 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if TRANSLATE then*/
    if (_26TRANSLATE_11619 == 0)
    {
        goto L1; // [5] 14
    }
    else{
    }

    /** 		return -- do it in back-end*/
    return;
L1: 

    /** 	for i = length(branch_list) to 1 by -1 do*/
    if (IS_SEQUENCE(_30branch_list_54154)){
            _28093 = SEQ_PTR(_30branch_list_54154)->length;
    }
    else {
        _28093 = 1;
    }
    {
        int _i_54646;
        _i_54646 = _28093;
L2: 
        if (_i_54646 < 1){
            goto L3; // [21] 170
        }

        /** 		if branch_list[i] > length(Code) then*/
        _2 = (int)SEQ_PTR(_30branch_list_54154);
        _28094 = (int)*(((s1_ptr)_2)->base + _i_54646);
        if (IS_SEQUENCE(_26Code_12071)){
                _28095 = SEQ_PTR(_26Code_12071)->length;
        }
        else {
            _28095 = 1;
        }
        if (binary_op_a(LESSEQ, _28094, _28095)){
            _28094 = NOVALUE;
            _28095 = NOVALUE;
            goto L4; // [41] 53
        }
        _28094 = NOVALUE;
        _28095 = NOVALUE;

        /** 			CompileErr("wtf")*/
        RefDS(_28097);
        RefDS(_22037);
        _43CompileErr(_28097, _22037, 0);
L4: 

        /** 		target = Code[branch_list[i]]*/
        _2 = (int)SEQ_PTR(_30branch_list_54154);
        _28098 = (int)*(((s1_ptr)_2)->base + _i_54646);
        _2 = (int)SEQ_PTR(_26Code_12071);
        if (!IS_ATOM_INT(_28098)){
            _target_54642 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_28098)->dbl));
        }
        else{
            _target_54642 = (int)*(((s1_ptr)_2)->base + _28098);
        }
        if (!IS_ATOM_INT(_target_54642)){
            _target_54642 = (long)DBL_PTR(_target_54642)->dbl;
        }

        /** 		if target <= length(Code) and target > 0 then*/
        if (IS_SEQUENCE(_26Code_12071)){
                _28100 = SEQ_PTR(_26Code_12071)->length;
        }
        else {
            _28100 = 1;
        }
        _28101 = (_target_54642 <= _28100);
        _28100 = NOVALUE;
        if (_28101 == 0) {
            goto L5; // [80] 163
        }
        _28103 = (_target_54642 > 0);
        if (_28103 == 0)
        {
            DeRef(_28103);
            _28103 = NOVALUE;
            goto L5; // [89] 163
        }
        else{
            DeRef(_28103);
            _28103 = NOVALUE;
        }

        /** 			br = Code[target]*/
        _2 = (int)SEQ_PTR(_26Code_12071);
        _br_54641 = (int)*(((s1_ptr)_2)->base + _target_54642);
        if (!IS_ATOM_INT(_br_54641)){
            _br_54641 = (long)DBL_PTR(_br_54641)->dbl;
        }

        /** 			if br = ELSE or br = ENDWHILE or br = EXIT then*/
        _28105 = (_br_54641 == 23);
        if (_28105 != 0) {
            _28106 = 1;
            goto L6; // [110] 124
        }
        _28107 = (_br_54641 == 22);
        _28106 = (_28107 != 0);
L6: 
        if (_28106 != 0) {
            goto L7; // [124] 139
        }
        _28109 = (_br_54641 == 61);
        if (_28109 == 0)
        {
            DeRef(_28109);
            _28109 = NOVALUE;
            goto L8; // [135] 162
        }
        else{
            DeRef(_28109);
            _28109 = NOVALUE;
        }
L7: 

        /** 				backpatch(branch_list[i], Code[target+1])*/
        _2 = (int)SEQ_PTR(_30branch_list_54154);
        _28110 = (int)*(((s1_ptr)_2)->base + _i_54646);
        _28111 = _target_54642 + 1;
        _2 = (int)SEQ_PTR(_26Code_12071);
        _28112 = (int)*(((s1_ptr)_2)->base + _28111);
        Ref(_28110);
        Ref(_28112);
        _37backpatch(_28110, _28112);
        _28110 = NOVALUE;
        _28112 = NOVALUE;
L8: 
L5: 

        /** 	end for*/
        _i_54646 = _i_54646 + -1;
        goto L2; // [165] 28
L3: 
        ;
    }

    /** 	branch_list = {}*/
    RefDS(_22037);
    DeRef(_30branch_list_54154);
    _30branch_list_54154 = _22037;

    /** end procedure*/
    _28098 = NOVALUE;
    DeRef(_28101);
    _28101 = NOVALUE;
    DeRef(_28105);
    _28105 = NOVALUE;
    DeRef(_28107);
    _28107 = NOVALUE;
    DeRef(_28111);
    _28111 = NOVALUE;
    return;
    ;
}


void _30PatchEList(int _base_54694)
{
    int _break_top_54695 = NOVALUE;
    int _n_54696 = NOVALUE;
    int _28129 = NOVALUE;
    int _28128 = NOVALUE;
    int _28127 = NOVALUE;
    int _28123 = NOVALUE;
    int _28122 = NOVALUE;
    int _28121 = NOVALUE;
    int _28119 = NOVALUE;
    int _28118 = NOVALUE;
    int _28116 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not length(break_list) then*/
    if (IS_SEQUENCE(_30break_list_54174)){
            _28116 = SEQ_PTR(_30break_list_54174)->length;
    }
    else {
        _28116 = 1;
    }
    if (_28116 != 0)
    goto L1; // [10] 19
    _28116 = NOVALUE;

    /** 		return*/
    return;
L1: 

    /** 	break_top = 0*/
    _break_top_54695 = 0;

    /** 	for i=length(break_list) to base+1 by -1 do*/
    if (IS_SEQUENCE(_30break_list_54174)){
            _28118 = SEQ_PTR(_30break_list_54174)->length;
    }
    else {
        _28118 = 1;
    }
    _28119 = _base_54694 + 1;
    if (_28119 > MAXINT){
        _28119 = NewDouble((double)_28119);
    }
    {
        int _i_54701;
        _i_54701 = _28118;
L2: 
        if (binary_op_a(LESS, _i_54701, _28119)){
            goto L3; // [35] 129
        }

        /** 		n=break_delay[i]*/
        _2 = (int)SEQ_PTR(_30break_delay_54175);
        if (!IS_ATOM_INT(_i_54701)){
            _n_54696 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_54701)->dbl));
        }
        else{
            _n_54696 = (int)*(((s1_ptr)_2)->base + _i_54701);
        }
        if (!IS_ATOM_INT(_n_54696))
        _n_54696 = (long)DBL_PTR(_n_54696)->dbl;

        /** 		break_delay[i] -= (n>0)*/
        _28121 = (_n_54696 > 0);
        _2 = (int)SEQ_PTR(_30break_delay_54175);
        if (!IS_ATOM_INT(_i_54701)){
            _28122 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_54701)->dbl));
        }
        else{
            _28122 = (int)*(((s1_ptr)_2)->base + _i_54701);
        }
        if (IS_ATOM_INT(_28122)) {
            _28123 = _28122 - _28121;
            if ((long)((unsigned long)_28123 +(unsigned long) HIGH_BITS) >= 0){
                _28123 = NewDouble((double)_28123);
            }
        }
        else {
            _28123 = binary_op(MINUS, _28122, _28121);
        }
        _28122 = NOVALUE;
        _28121 = NOVALUE;
        _2 = (int)SEQ_PTR(_30break_delay_54175);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _30break_delay_54175 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_i_54701))
        _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_54701)->dbl));
        else
        _2 = (int)(((s1_ptr)_2)->base + _i_54701);
        _1 = *(int *)_2;
        *(int *)_2 = _28123;
        if( _1 != _28123 ){
            DeRef(_1);
        }
        _28123 = NOVALUE;

        /** 		if n>1 then*/
        if (_n_54696 <= 1)
        goto L4; // [72] 93

        /** 			if break_top = 0 then*/
        if (_break_top_54695 != 0)
        goto L5; // [78] 122

        /** 				break_top = i*/
        Ref(_i_54701);
        _break_top_54695 = _i_54701;
        if (!IS_ATOM_INT(_break_top_54695)) {
            _1 = (long)(DBL_PTR(_break_top_54695)->dbl);
            DeRefDS(_break_top_54695);
            _break_top_54695 = _1;
        }
        goto L5; // [90] 122
L4: 

        /** 		elsif n=1 then*/
        if (_n_54696 != 1)
        goto L6; // [95] 121

        /** 			backpatch(break_list[i],length(Code)+1)*/
        _2 = (int)SEQ_PTR(_30break_list_54174);
        if (!IS_ATOM_INT(_i_54701)){
            _28127 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_54701)->dbl));
        }
        else{
            _28127 = (int)*(((s1_ptr)_2)->base + _i_54701);
        }
        if (IS_SEQUENCE(_26Code_12071)){
                _28128 = SEQ_PTR(_26Code_12071)->length;
        }
        else {
            _28128 = 1;
        }
        _28129 = _28128 + 1;
        _28128 = NOVALUE;
        _37backpatch(_28127, _28129);
        _28127 = NOVALUE;
        _28129 = NOVALUE;
L6: 
L5: 

        /** 	end for*/
        _0 = _i_54701;
        if (IS_ATOM_INT(_i_54701)) {
            _i_54701 = _i_54701 + -1;
            if ((long)((unsigned long)_i_54701 +(unsigned long) HIGH_BITS) >= 0){
                _i_54701 = NewDouble((double)_i_54701);
            }
        }
        else {
            _i_54701 = binary_op_a(PLUS, _i_54701, -1);
        }
        DeRef(_0);
        goto L2; // [124] 42
L3: 
        ;
        DeRef(_i_54701);
    }

    /** 	if break_top=0 then*/
    if (_break_top_54695 != 0)
    goto L7; // [131] 141

    /** 	    break_top=base*/
    _break_top_54695 = _base_54694;
L7: 

    /** 	break_delay = break_delay[1..break_top]*/
    rhs_slice_target = (object_ptr)&_30break_delay_54175;
    RHS_Slice(_30break_delay_54175, 1, _break_top_54695);

    /** 	break_list = break_list[1..break_top]*/
    rhs_slice_target = (object_ptr)&_30break_list_54174;
    RHS_Slice(_30break_list_54174, 1, _break_top_54695);

    /** end procedure*/
    DeRef(_28119);
    _28119 = NOVALUE;
    return;
    ;
}


void _30PatchNList(int _base_54725)
{
    int _next_top_54726 = NOVALUE;
    int _n_54727 = NOVALUE;
    int _28146 = NOVALUE;
    int _28145 = NOVALUE;
    int _28144 = NOVALUE;
    int _28140 = NOVALUE;
    int _28139 = NOVALUE;
    int _28138 = NOVALUE;
    int _28136 = NOVALUE;
    int _28135 = NOVALUE;
    int _28133 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not length(continue_list) then*/
    if (IS_SEQUENCE(_30continue_list_54178)){
            _28133 = SEQ_PTR(_30continue_list_54178)->length;
    }
    else {
        _28133 = 1;
    }
    if (_28133 != 0)
    goto L1; // [10] 19
    _28133 = NOVALUE;

    /** 		return*/
    return;
L1: 

    /** 	next_top = 0*/
    _next_top_54726 = 0;

    /** 	for i=length(continue_list) to base+1 by -1 do*/
    if (IS_SEQUENCE(_30continue_list_54178)){
            _28135 = SEQ_PTR(_30continue_list_54178)->length;
    }
    else {
        _28135 = 1;
    }
    _28136 = _base_54725 + 1;
    if (_28136 > MAXINT){
        _28136 = NewDouble((double)_28136);
    }
    {
        int _i_54732;
        _i_54732 = _28135;
L2: 
        if (binary_op_a(LESS, _i_54732, _28136)){
            goto L3; // [35] 129
        }

        /** 		n=continue_delay[i]*/
        _2 = (int)SEQ_PTR(_30continue_delay_54179);
        if (!IS_ATOM_INT(_i_54732)){
            _n_54727 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_54732)->dbl));
        }
        else{
            _n_54727 = (int)*(((s1_ptr)_2)->base + _i_54732);
        }
        if (!IS_ATOM_INT(_n_54727))
        _n_54727 = (long)DBL_PTR(_n_54727)->dbl;

        /** 		continue_delay[i] -= (n>0)*/
        _28138 = (_n_54727 > 0);
        _2 = (int)SEQ_PTR(_30continue_delay_54179);
        if (!IS_ATOM_INT(_i_54732)){
            _28139 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_54732)->dbl));
        }
        else{
            _28139 = (int)*(((s1_ptr)_2)->base + _i_54732);
        }
        if (IS_ATOM_INT(_28139)) {
            _28140 = _28139 - _28138;
            if ((long)((unsigned long)_28140 +(unsigned long) HIGH_BITS) >= 0){
                _28140 = NewDouble((double)_28140);
            }
        }
        else {
            _28140 = binary_op(MINUS, _28139, _28138);
        }
        _28139 = NOVALUE;
        _28138 = NOVALUE;
        _2 = (int)SEQ_PTR(_30continue_delay_54179);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _30continue_delay_54179 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_i_54732))
        _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_54732)->dbl));
        else
        _2 = (int)(((s1_ptr)_2)->base + _i_54732);
        _1 = *(int *)_2;
        *(int *)_2 = _28140;
        if( _1 != _28140 ){
            DeRef(_1);
        }
        _28140 = NOVALUE;

        /** 		if n>1 then*/
        if (_n_54727 <= 1)
        goto L4; // [72] 93

        /** 			if next_top = 0 then*/
        if (_next_top_54726 != 0)
        goto L5; // [78] 122

        /** 				next_top = i*/
        Ref(_i_54732);
        _next_top_54726 = _i_54732;
        if (!IS_ATOM_INT(_next_top_54726)) {
            _1 = (long)(DBL_PTR(_next_top_54726)->dbl);
            DeRefDS(_next_top_54726);
            _next_top_54726 = _1;
        }
        goto L5; // [90] 122
L4: 

        /** 		elsif n=1 then*/
        if (_n_54727 != 1)
        goto L6; // [95] 121

        /** 			backpatch(continue_list[i],length(Code)+1)*/
        _2 = (int)SEQ_PTR(_30continue_list_54178);
        if (!IS_ATOM_INT(_i_54732)){
            _28144 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_54732)->dbl));
        }
        else{
            _28144 = (int)*(((s1_ptr)_2)->base + _i_54732);
        }
        if (IS_SEQUENCE(_26Code_12071)){
                _28145 = SEQ_PTR(_26Code_12071)->length;
        }
        else {
            _28145 = 1;
        }
        _28146 = _28145 + 1;
        _28145 = NOVALUE;
        _37backpatch(_28144, _28146);
        _28144 = NOVALUE;
        _28146 = NOVALUE;
L6: 
L5: 

        /** 	end for*/
        _0 = _i_54732;
        if (IS_ATOM_INT(_i_54732)) {
            _i_54732 = _i_54732 + -1;
            if ((long)((unsigned long)_i_54732 +(unsigned long) HIGH_BITS) >= 0){
                _i_54732 = NewDouble((double)_i_54732);
            }
        }
        else {
            _i_54732 = binary_op_a(PLUS, _i_54732, -1);
        }
        DeRef(_0);
        goto L2; // [124] 42
L3: 
        ;
        DeRef(_i_54732);
    }

    /** 	if next_top=0 then*/
    if (_next_top_54726 != 0)
    goto L7; // [131] 141

    /** 	    next_top=base*/
    _next_top_54726 = _base_54725;
L7: 

    /** 	continue_delay =continue_delay[1..next_top]*/
    rhs_slice_target = (object_ptr)&_30continue_delay_54179;
    RHS_Slice(_30continue_delay_54179, 1, _next_top_54726);

    /** 	continue_list = continue_list[1..next_top]*/
    rhs_slice_target = (object_ptr)&_30continue_list_54178;
    RHS_Slice(_30continue_list_54178, 1, _next_top_54726);

    /** end procedure*/
    DeRef(_28136);
    _28136 = NOVALUE;
    return;
    ;
}


void _30PatchXList(int _base_54756)
{
    int _exit_top_54757 = NOVALUE;
    int _n_54758 = NOVALUE;
    int _28163 = NOVALUE;
    int _28162 = NOVALUE;
    int _28161 = NOVALUE;
    int _28157 = NOVALUE;
    int _28156 = NOVALUE;
    int _28155 = NOVALUE;
    int _28153 = NOVALUE;
    int _28152 = NOVALUE;
    int _28150 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not length(exit_list) then*/
    if (IS_SEQUENCE(_30exit_list_54176)){
            _28150 = SEQ_PTR(_30exit_list_54176)->length;
    }
    else {
        _28150 = 1;
    }
    if (_28150 != 0)
    goto L1; // [10] 19
    _28150 = NOVALUE;

    /** 		return*/
    return;
L1: 

    /** 	exit_top = 0*/
    _exit_top_54757 = 0;

    /** 	for i=length(exit_list) to base+1 by -1 do*/
    if (IS_SEQUENCE(_30exit_list_54176)){
            _28152 = SEQ_PTR(_30exit_list_54176)->length;
    }
    else {
        _28152 = 1;
    }
    _28153 = _base_54756 + 1;
    if (_28153 > MAXINT){
        _28153 = NewDouble((double)_28153);
    }
    {
        int _i_54763;
        _i_54763 = _28152;
L2: 
        if (binary_op_a(LESS, _i_54763, _28153)){
            goto L3; // [35] 129
        }

        /** 		n=exit_delay[i]*/
        _2 = (int)SEQ_PTR(_30exit_delay_54177);
        if (!IS_ATOM_INT(_i_54763)){
            _n_54758 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_54763)->dbl));
        }
        else{
            _n_54758 = (int)*(((s1_ptr)_2)->base + _i_54763);
        }
        if (!IS_ATOM_INT(_n_54758))
        _n_54758 = (long)DBL_PTR(_n_54758)->dbl;

        /** 		exit_delay[i] -= (n>0)*/
        _28155 = (_n_54758 > 0);
        _2 = (int)SEQ_PTR(_30exit_delay_54177);
        if (!IS_ATOM_INT(_i_54763)){
            _28156 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_54763)->dbl));
        }
        else{
            _28156 = (int)*(((s1_ptr)_2)->base + _i_54763);
        }
        if (IS_ATOM_INT(_28156)) {
            _28157 = _28156 - _28155;
            if ((long)((unsigned long)_28157 +(unsigned long) HIGH_BITS) >= 0){
                _28157 = NewDouble((double)_28157);
            }
        }
        else {
            _28157 = binary_op(MINUS, _28156, _28155);
        }
        _28156 = NOVALUE;
        _28155 = NOVALUE;
        _2 = (int)SEQ_PTR(_30exit_delay_54177);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _30exit_delay_54177 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_i_54763))
        _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_54763)->dbl));
        else
        _2 = (int)(((s1_ptr)_2)->base + _i_54763);
        _1 = *(int *)_2;
        *(int *)_2 = _28157;
        if( _1 != _28157 ){
            DeRef(_1);
        }
        _28157 = NOVALUE;

        /** 		if n>1 then*/
        if (_n_54758 <= 1)
        goto L4; // [72] 93

        /** 			if exit_top = 0 then*/
        if (_exit_top_54757 != 0)
        goto L5; // [78] 122

        /** 				exit_top = i*/
        Ref(_i_54763);
        _exit_top_54757 = _i_54763;
        if (!IS_ATOM_INT(_exit_top_54757)) {
            _1 = (long)(DBL_PTR(_exit_top_54757)->dbl);
            DeRefDS(_exit_top_54757);
            _exit_top_54757 = _1;
        }
        goto L5; // [90] 122
L4: 

        /** 		elsif n=1 then*/
        if (_n_54758 != 1)
        goto L6; // [95] 121

        /** 			backpatch(exit_list[i],length(Code)+1)*/
        _2 = (int)SEQ_PTR(_30exit_list_54176);
        if (!IS_ATOM_INT(_i_54763)){
            _28161 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_54763)->dbl));
        }
        else{
            _28161 = (int)*(((s1_ptr)_2)->base + _i_54763);
        }
        if (IS_SEQUENCE(_26Code_12071)){
                _28162 = SEQ_PTR(_26Code_12071)->length;
        }
        else {
            _28162 = 1;
        }
        _28163 = _28162 + 1;
        _28162 = NOVALUE;
        _37backpatch(_28161, _28163);
        _28161 = NOVALUE;
        _28163 = NOVALUE;
L6: 
L5: 

        /** 	end for*/
        _0 = _i_54763;
        if (IS_ATOM_INT(_i_54763)) {
            _i_54763 = _i_54763 + -1;
            if ((long)((unsigned long)_i_54763 +(unsigned long) HIGH_BITS) >= 0){
                _i_54763 = NewDouble((double)_i_54763);
            }
        }
        else {
            _i_54763 = binary_op_a(PLUS, _i_54763, -1);
        }
        DeRef(_0);
        goto L2; // [124] 42
L3: 
        ;
        DeRef(_i_54763);
    }

    /** 	if exit_top=0 then*/
    if (_exit_top_54757 != 0)
    goto L7; // [131] 141

    /** 	    exit_top=base*/
    _exit_top_54757 = _base_54756;
L7: 

    /** 	exit_delay = exit_delay [1..exit_top]*/
    rhs_slice_target = (object_ptr)&_30exit_delay_54177;
    RHS_Slice(_30exit_delay_54177, 1, _exit_top_54757);

    /** 	exit_list = exit_list [1..exit_top]*/
    rhs_slice_target = (object_ptr)&_30exit_list_54176;
    RHS_Slice(_30exit_list_54176, 1, _exit_top_54757);

    /** end procedure*/
    DeRef(_28153);
    _28153 = NOVALUE;
    return;
    ;
}


void _30putback(int _t_54788)
{
    int _28168 = NOVALUE;
    int _0, _1, _2;
    

    /** 	backed_up_tok = append(backed_up_tok, t)*/
    Ref(_t_54788);
    Append(&_30backed_up_tok_54163, _30backed_up_tok_54163, _t_54788);

    /** 	if t[T_SYM] then*/
    _2 = (int)SEQ_PTR(_t_54788);
    _28168 = (int)*(((s1_ptr)_2)->base + 2);
    if (_28168 == 0) {
        _28168 = NOVALUE;
        goto L1; // [17] 79
    }
    else {
        if (!IS_ATOM_INT(_28168) && DBL_PTR(_28168)->dbl == 0.0){
            _28168 = NOVALUE;
            goto L1; // [17] 79
        }
        _28168 = NOVALUE;
    }
    _28168 = NOVALUE;

    /** 		putback_ForwardLine     = ForwardLine*/
    Ref(_43ForwardLine_48558);
    DeRef(_43putback_ForwardLine_48559);
    _43putback_ForwardLine_48559 = _43ForwardLine_48558;

    /** 		putback_forward_bp      = forward_bp*/
    _43putback_forward_bp_48563 = _43forward_bp_48562;

    /** 		putback_fwd_line_number = fwd_line_number*/
    _26putback_fwd_line_number_11985 = _26fwd_line_number_11984;

    /** 		if last_fwd_line_number then*/
    if (_26last_fwd_line_number_11986 == 0)
    {
        goto L2; // [49] 78
    }
    else{
    }

    /** 			ForwardLine     = last_ForwardLine*/
    Ref(_43last_ForwardLine_48560);
    DeRef(_43ForwardLine_48558);
    _43ForwardLine_48558 = _43last_ForwardLine_48560;

    /** 			forward_bp      = last_forward_bp*/
    _43forward_bp_48562 = _43last_forward_bp_48564;

    /** 			fwd_line_number = last_fwd_line_number*/
    _26fwd_line_number_11984 = _26last_fwd_line_number_11986;
L2: 
L1: 

    /** end procedure*/
    DeRef(_t_54788);
    return;
    ;
}


void _30start_recording()
{
    int _0, _1, _2;
    

    /** 	psm_stack &= Parser_mode*/
    Append(&_30psm_stack_54807, _30psm_stack_54807, _26Parser_mode_12088);

    /** 	can_stack = append(can_stack,canned_tokens)*/
    Ref(_30canned_tokens_54200);
    Append(&_30can_stack_54808, _30can_stack_54808, _30canned_tokens_54200);

    /** 	idx_stack &= canned_index*/
    Append(&_30idx_stack_54809, _30idx_stack_54809, _30canned_index_54201);

    /** 	tok_stack = append(tok_stack,backed_up_tok)*/
    RefDS(_30backed_up_tok_54163);
    Append(&_30tok_stack_54810, _30tok_stack_54810, _30backed_up_tok_54163);

    /** 	canned_tokens = {}*/
    RefDS(_22037);
    DeRef(_30canned_tokens_54200);
    _30canned_tokens_54200 = _22037;

    /** 	Parser_mode = PAM_RECORD*/
    _26Parser_mode_12088 = 1;

    /** 	clear_last()*/
    _37clear_last();

    /** end procedure*/
    return;
    ;
}


int _30restore_parser()
{
    int _n_54823 = NOVALUE;
    int _tok_54824 = NOVALUE;
    int _x_54825 = NOVALUE;
    int _28199 = NOVALUE;
    int _28198 = NOVALUE;
    int _28197 = NOVALUE;
    int _28195 = NOVALUE;
    int _28191 = NOVALUE;
    int _28190 = NOVALUE;
    int _28188 = NOVALUE;
    int _28186 = NOVALUE;
    int _28185 = NOVALUE;
    int _28183 = NOVALUE;
    int _28181 = NOVALUE;
    int _28180 = NOVALUE;
    int _28178 = NOVALUE;
    int _28176 = NOVALUE;
    int _28175 = NOVALUE;
    int _28173 = NOVALUE;
    int _0, _1, _2;
    

    /** 	n=Parser_mode*/
    _n_54823 = _26Parser_mode_12088;

    /** 	x = canned_tokens*/
    Ref(_30canned_tokens_54200);
    DeRef(_x_54825);
    _x_54825 = _30canned_tokens_54200;

    /** 	canned_tokens = can_stack[$]*/
    if (IS_SEQUENCE(_30can_stack_54808)){
            _28173 = SEQ_PTR(_30can_stack_54808)->length;
    }
    else {
        _28173 = 1;
    }
    DeRef(_30canned_tokens_54200);
    _2 = (int)SEQ_PTR(_30can_stack_54808);
    _30canned_tokens_54200 = (int)*(((s1_ptr)_2)->base + _28173);
    Ref(_30canned_tokens_54200);

    /** 	can_stack     = can_stack[1..$-1]*/
    if (IS_SEQUENCE(_30can_stack_54808)){
            _28175 = SEQ_PTR(_30can_stack_54808)->length;
    }
    else {
        _28175 = 1;
    }
    _28176 = _28175 - 1;
    _28175 = NOVALUE;
    rhs_slice_target = (object_ptr)&_30can_stack_54808;
    RHS_Slice(_30can_stack_54808, 1, _28176);

    /** 	canned_index  = idx_stack[$]*/
    if (IS_SEQUENCE(_30idx_stack_54809)){
            _28178 = SEQ_PTR(_30idx_stack_54809)->length;
    }
    else {
        _28178 = 1;
    }
    _2 = (int)SEQ_PTR(_30idx_stack_54809);
    _30canned_index_54201 = (int)*(((s1_ptr)_2)->base + _28178);

    /** 	idx_stack     = idx_stack[1..$-1]*/
    if (IS_SEQUENCE(_30idx_stack_54809)){
            _28180 = SEQ_PTR(_30idx_stack_54809)->length;
    }
    else {
        _28180 = 1;
    }
    _28181 = _28180 - 1;
    _28180 = NOVALUE;
    rhs_slice_target = (object_ptr)&_30idx_stack_54809;
    RHS_Slice(_30idx_stack_54809, 1, _28181);

    /** 	Parser_mode   = psm_stack[$]*/
    if (IS_SEQUENCE(_30psm_stack_54807)){
            _28183 = SEQ_PTR(_30psm_stack_54807)->length;
    }
    else {
        _28183 = 1;
    }
    _2 = (int)SEQ_PTR(_30psm_stack_54807);
    _26Parser_mode_12088 = (int)*(((s1_ptr)_2)->base + _28183);

    /** 	psm_stack     = psm_stack[1..$-1]*/
    if (IS_SEQUENCE(_30psm_stack_54807)){
            _28185 = SEQ_PTR(_30psm_stack_54807)->length;
    }
    else {
        _28185 = 1;
    }
    _28186 = _28185 - 1;
    _28185 = NOVALUE;
    rhs_slice_target = (object_ptr)&_30psm_stack_54807;
    RHS_Slice(_30psm_stack_54807, 1, _28186);

    /** 	tok 		  = tok_stack[$]*/
    if (IS_SEQUENCE(_30tok_stack_54810)){
            _28188 = SEQ_PTR(_30tok_stack_54810)->length;
    }
    else {
        _28188 = 1;
    }
    DeRef(_tok_54824);
    _2 = (int)SEQ_PTR(_30tok_stack_54810);
    _tok_54824 = (int)*(((s1_ptr)_2)->base + _28188);
    RefDS(_tok_54824);

    /** 	tok_stack 	  = tok_stack[1..$-1]*/
    if (IS_SEQUENCE(_30tok_stack_54810)){
            _28190 = SEQ_PTR(_30tok_stack_54810)->length;
    }
    else {
        _28190 = 1;
    }
    _28191 = _28190 - 1;
    _28190 = NOVALUE;
    rhs_slice_target = (object_ptr)&_30tok_stack_54810;
    RHS_Slice(_30tok_stack_54810, 1, _28191);

    /** 	clear_last()*/
    _37clear_last();

    /** 	if n=PAM_PLAYBACK then*/
    if (_n_54823 != -1)
    goto L1; // [137] 150

    /** 		return {}*/
    RefDS(_22037);
    DeRefDS(_tok_54824);
    DeRefDS(_x_54825);
    _28176 = NOVALUE;
    _28181 = NOVALUE;
    _28186 = NOVALUE;
    _28191 = NOVALUE;
    return _22037;
    goto L2; // [147] 167
L1: 

    /** 	elsif n = PAM_NORMAL then*/
    if (_n_54823 != 0)
    goto L3; // [154] 166

    /** 		use_private_list = 0*/
    _26use_private_list_12096 = 0;
L3: 
L2: 

    /** 	if length(backed_up_tok) > 0 then*/
    if (IS_SEQUENCE(_30backed_up_tok_54163)){
            _28195 = SEQ_PTR(_30backed_up_tok_54163)->length;
    }
    else {
        _28195 = 1;
    }
    if (_28195 <= 0)
    goto L4; // [174] 199

    /** 		return x[1..$-1]*/
    if (IS_SEQUENCE(_x_54825)){
            _28197 = SEQ_PTR(_x_54825)->length;
    }
    else {
        _28197 = 1;
    }
    _28198 = _28197 - 1;
    _28197 = NOVALUE;
    rhs_slice_target = (object_ptr)&_28199;
    RHS_Slice(_x_54825, 1, _28198);
    DeRef(_tok_54824);
    DeRefDS(_x_54825);
    DeRef(_28176);
    _28176 = NOVALUE;
    DeRef(_28181);
    _28181 = NOVALUE;
    DeRef(_28186);
    _28186 = NOVALUE;
    DeRef(_28191);
    _28191 = NOVALUE;
    _28198 = NOVALUE;
    return _28199;
    goto L5; // [196] 206
L4: 

    /** 		return x*/
    DeRef(_tok_54824);
    DeRef(_28176);
    _28176 = NOVALUE;
    DeRef(_28181);
    _28181 = NOVALUE;
    DeRef(_28186);
    _28186 = NOVALUE;
    DeRef(_28191);
    _28191 = NOVALUE;
    DeRef(_28198);
    _28198 = NOVALUE;
    DeRef(_28199);
    _28199 = NOVALUE;
    return _x_54825;
L5: 
    ;
}


void _30start_playback(int _s_54865)
{
    int _0, _1, _2;
    

    /** 	psm_stack &= Parser_mode*/
    Append(&_30psm_stack_54807, _30psm_stack_54807, _26Parser_mode_12088);

    /** 	can_stack = append(can_stack,canned_tokens)*/
    Ref(_30canned_tokens_54200);
    Append(&_30can_stack_54808, _30can_stack_54808, _30canned_tokens_54200);

    /** 	idx_stack &= canned_index*/
    Append(&_30idx_stack_54809, _30idx_stack_54809, _30canned_index_54201);

    /** 	tok_stack = append(tok_stack,backed_up_tok)*/
    RefDS(_30backed_up_tok_54163);
    Append(&_30tok_stack_54810, _30tok_stack_54810, _30backed_up_tok_54163);

    /** 	canned_index = 1*/
    _30canned_index_54201 = 1;

    /** 	canned_tokens = s*/
    RefDS(_s_54865);
    DeRef(_30canned_tokens_54200);
    _30canned_tokens_54200 = _s_54865;

    /** 	backed_up_tok = {}*/
    RefDS(_22037);
    DeRefDS(_30backed_up_tok_54163);
    _30backed_up_tok_54163 = _22037;

    /** 	Parser_mode = PAM_PLAYBACK*/
    _26Parser_mode_12088 = -1;

    /** end procedure*/
    DeRefDS(_s_54865);
    return;
    ;
}


void _30restore_parseargs_states()
{
    int _s_54884 = NOVALUE;
    int _n_54885 = NOVALUE;
    int _28216 = NOVALUE;
    int _28215 = NOVALUE;
    int _28207 = NOVALUE;
    int _28206 = NOVALUE;
    int _28204 = NOVALUE;
    int _0, _1, _2;
    

    /** 	s = parseargs_states[$]*/
    if (IS_SEQUENCE(_30parseargs_states_54873)){
            _28204 = SEQ_PTR(_30parseargs_states_54873)->length;
    }
    else {
        _28204 = 1;
    }
    DeRef(_s_54884);
    _2 = (int)SEQ_PTR(_30parseargs_states_54873);
    _s_54884 = (int)*(((s1_ptr)_2)->base + _28204);
    RefDS(_s_54884);

    /** 	parseargs_states = parseargs_states[1..$-1]*/
    if (IS_SEQUENCE(_30parseargs_states_54873)){
            _28206 = SEQ_PTR(_30parseargs_states_54873)->length;
    }
    else {
        _28206 = 1;
    }
    _28207 = _28206 - 1;
    _28206 = NOVALUE;
    rhs_slice_target = (object_ptr)&_30parseargs_states_54873;
    RHS_Slice(_30parseargs_states_54873, 1, _28207);

    /** 	n=s[PS_POSITION]*/
    _2 = (int)SEQ_PTR(_s_54884);
    _n_54885 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_n_54885))
    _n_54885 = (long)DBL_PTR(_n_54885)->dbl;

    /** 	private_list = private_list[1..n]*/
    rhs_slice_target = (object_ptr)&_30private_list_54878;
    RHS_Slice(_30private_list_54878, 1, _n_54885);

    /** 	private_sym = private_sym[1..n]*/
    rhs_slice_target = (object_ptr)&_26private_sym_12095;
    RHS_Slice(_26private_sym_12095, 1, _n_54885);

    /** 	lock_scanner = s[PS_SCAN_LOCK]*/
    _2 = (int)SEQ_PTR(_s_54884);
    _30lock_scanner_54879 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_30lock_scanner_54879))
    _30lock_scanner_54879 = (long)DBL_PTR(_30lock_scanner_54879)->dbl;

    /** 	use_private_list = s[PS_USE_LIST]*/
    _2 = (int)SEQ_PTR(_s_54884);
    _26use_private_list_12096 = (int)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_26use_private_list_12096)){
        _26use_private_list_12096 = (long)DBL_PTR(_26use_private_list_12096)->dbl;
    }

    /** 	on_arg = s[PS_ON_ARG]*/
    _2 = (int)SEQ_PTR(_s_54884);
    _30on_arg_54880 = (int)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_30on_arg_54880))
    _30on_arg_54880 = (long)DBL_PTR(_30on_arg_54880)->dbl;

    /** 	nested_calls = nested_calls[1..$-1]*/
    if (IS_SEQUENCE(_30nested_calls_54881)){
            _28215 = SEQ_PTR(_30nested_calls_54881)->length;
    }
    else {
        _28215 = 1;
    }
    _28216 = _28215 - 1;
    _28215 = NOVALUE;
    rhs_slice_target = (object_ptr)&_30nested_calls_54881;
    RHS_Slice(_30nested_calls_54881, 1, _28216);

    /** end procedure*/
    DeRefDS(_s_54884);
    _28207 = NOVALUE;
    _28216 = NOVALUE;
    return;
    ;
}


int _30read_recorded_token(int _n_54905)
{
    int _t_54907 = NOVALUE;
    int _p_54908 = NOVALUE;
    int _prev_Nne_54909 = NOVALUE;
    int _ts_54938 = NOVALUE;
    int _31661 = NOVALUE;
    int _31660 = NOVALUE;
    int _31659 = NOVALUE;
    int _31658 = NOVALUE;
    int _31657 = NOVALUE;
    int _31656 = NOVALUE;
    int _31655 = NOVALUE;
    int _31654 = NOVALUE;
    int _28288 = NOVALUE;
    int _28287 = NOVALUE;
    int _28286 = NOVALUE;
    int _28285 = NOVALUE;
    int _28281 = NOVALUE;
    int _28279 = NOVALUE;
    int _28278 = NOVALUE;
    int _28277 = NOVALUE;
    int _28276 = NOVALUE;
    int _28274 = NOVALUE;
    int _28273 = NOVALUE;
    int _28272 = NOVALUE;
    int _28271 = NOVALUE;
    int _28269 = NOVALUE;
    int _28266 = NOVALUE;
    int _28264 = NOVALUE;
    int _28262 = NOVALUE;
    int _28261 = NOVALUE;
    int _28260 = NOVALUE;
    int _28259 = NOVALUE;
    int _28257 = NOVALUE;
    int _28255 = NOVALUE;
    int _28251 = NOVALUE;
    int _28249 = NOVALUE;
    int _28247 = NOVALUE;
    int _28246 = NOVALUE;
    int _28245 = NOVALUE;
    int _28244 = NOVALUE;
    int _28243 = NOVALUE;
    int _28242 = NOVALUE;
    int _28241 = NOVALUE;
    int _28240 = NOVALUE;
    int _28239 = NOVALUE;
    int _28238 = NOVALUE;
    int _28237 = NOVALUE;
    int _28236 = NOVALUE;
    int _28234 = NOVALUE;
    int _28233 = NOVALUE;
    int _28231 = NOVALUE;
    int _28230 = NOVALUE;
    int _28229 = NOVALUE;
    int _28228 = NOVALUE;
    int _28227 = NOVALUE;
    int _28226 = NOVALUE;
    int _28225 = NOVALUE;
    int _28224 = NOVALUE;
    int _28221 = NOVALUE;
    int _28219 = NOVALUE;
    int _28218 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_n_54905)) {
        _1 = (long)(DBL_PTR(_n_54905)->dbl);
        DeRefDS(_n_54905);
        _n_54905 = _1;
    }

    /** 	integer p, prev_Nne*/

    /** 	if atom(Ns_recorded[n]) label "top if" then*/
    _2 = (int)SEQ_PTR(_26Ns_recorded_12090);
    _28218 = (int)*(((s1_ptr)_2)->base + _n_54905);
    _28219 = IS_ATOM(_28218);
    _28218 = NOVALUE;
    if (_28219 == 0)
    {
        _28219 = NOVALUE;
        goto L1; // [16] 403
    }
    else{
        _28219 = NOVALUE;
    }

    /** 		if use_private_list then*/
    if (_26use_private_list_12096 == 0)
    {
        goto L2; // [23] 171
    }
    else{
    }

    /** 			p = find( Recorded[n], private_list)*/
    _2 = (int)SEQ_PTR(_26Recorded_12089);
    _28221 = (int)*(((s1_ptr)_2)->base + _n_54905);
    _p_54908 = find_from(_28221, _30private_list_54878, 1);
    _28221 = NOVALUE;

    /** 			if p > 0 then -- the value of this parameter is known, use it*/
    if (_p_54908 <= 0)
    goto L3; // [43] 170

    /** 				if TRANSLATE*/
    if (_26TRANSLATE_11619 == 0) {
        goto L4; // [51] 150
    }
    _2 = (int)SEQ_PTR(_26private_sym_12095);
    _28225 = (int)*(((s1_ptr)_2)->base + _p_54908);
    if (IS_ATOM_INT(_28225)) {
        _28226 = (_28225 < 0);
    }
    else {
        _28226 = binary_op(LESS, _28225, 0);
    }
    _28225 = NOVALUE;
    if (IS_ATOM_INT(_28226)) {
        if (_28226 != 0) {
            _28227 = 1;
            goto L5; // [65] 97
        }
    }
    else {
        if (DBL_PTR(_28226)->dbl != 0.0) {
            _28227 = 1;
            goto L5; // [65] 97
        }
    }
    _2 = (int)SEQ_PTR(_26private_sym_12095);
    _28228 = (int)*(((s1_ptr)_2)->base + _p_54908);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!IS_ATOM_INT(_28228)){
        _28229 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_28228)->dbl));
    }
    else{
        _28229 = (int)*(((s1_ptr)_2)->base + _28228);
    }
    _2 = (int)SEQ_PTR(_28229);
    _28230 = (int)*(((s1_ptr)_2)->base + 3);
    _28229 = NOVALUE;
    if (IS_ATOM_INT(_28230)) {
        _28231 = (_28230 == 3);
    }
    else {
        _28231 = binary_op(EQUALS, _28230, 3);
    }
    _28230 = NOVALUE;
    DeRef(_28227);
    if (IS_ATOM_INT(_28231))
    _28227 = (_28231 != 0);
    else
    _28227 = DBL_PTR(_28231)->dbl != 0.0;
L5: 
    if (_28227 == 0)
    {
        _28227 = NOVALUE;
        goto L4; // [98] 150
    }
    else{
        _28227 = NOVALUE;
    }

    /** 					symtab_index ts = NewTempSym()*/
    _ts_54938 = _52NewTempSym(0);
    if (!IS_ATOM_INT(_ts_54938)) {
        _1 = (long)(DBL_PTR(_ts_54938)->dbl);
        DeRefDS(_ts_54938);
        _ts_54938 = _1;
    }

    /** 					Code &= { ASSIGN, private_sym[p], ts }*/
    _2 = (int)SEQ_PTR(_26private_sym_12095);
    _28233 = (int)*(((s1_ptr)_2)->base + _p_54908);
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 18;
    Ref(_28233);
    *((int *)(_2+8)) = _28233;
    *((int *)(_2+12)) = _ts_54938;
    _28234 = MAKE_SEQ(_1);
    _28233 = NOVALUE;
    Concat((object_ptr)&_26Code_12071, _26Code_12071, _28234);
    DeRefDS(_28234);
    _28234 = NOVALUE;

    /** 					return {VARIABLE, ts}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -100;
    ((int *)_2)[2] = _ts_54938;
    _28236 = MAKE_SEQ(_1);
    DeRef(_t_54907);
    _28228 = NOVALUE;
    DeRef(_28226);
    _28226 = NOVALUE;
    DeRef(_28231);
    _28231 = NOVALUE;
    return _28236;
    goto L6; // [147] 169
L4: 

    /** 					return {VARIABLE, private_sym[p]}*/
    _2 = (int)SEQ_PTR(_26private_sym_12095);
    _28237 = (int)*(((s1_ptr)_2)->base + _p_54908);
    Ref(_28237);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -100;
    ((int *)_2)[2] = _28237;
    _28238 = MAKE_SEQ(_1);
    _28237 = NOVALUE;
    DeRef(_t_54907);
    _28228 = NOVALUE;
    DeRef(_28226);
    _28226 = NOVALUE;
    DeRef(_28236);
    _28236 = NOVALUE;
    DeRef(_28231);
    _28231 = NOVALUE;
    return _28238;
L6: 
L3: 
L2: 

    /** 		prev_Nne = No_new_entry*/
    _prev_Nne_54909 = _52No_new_entry_47302;

    /** 		No_new_entry = 1*/
    _52No_new_entry_47302 = 1;

    /** 		if Recorded_sym[n] > 0 and  sym_scope( Recorded_sym[n] ) != SC_UNDEFINED then*/
    _2 = (int)SEQ_PTR(_26Recorded_sym_12091);
    _28239 = (int)*(((s1_ptr)_2)->base + _n_54905);
    if (IS_ATOM_INT(_28239)) {
        _28240 = (_28239 > 0);
    }
    else {
        _28240 = binary_op(GREATER, _28239, 0);
    }
    _28239 = NOVALUE;
    if (IS_ATOM_INT(_28240)) {
        if (_28240 == 0) {
            goto L7; // [199] 250
        }
    }
    else {
        if (DBL_PTR(_28240)->dbl == 0.0) {
            goto L7; // [199] 250
        }
    }
    _2 = (int)SEQ_PTR(_26Recorded_sym_12091);
    _28242 = (int)*(((s1_ptr)_2)->base + _n_54905);
    Ref(_28242);
    _28243 = _52sym_scope(_28242);
    _28242 = NOVALUE;
    if (IS_ATOM_INT(_28243)) {
        _28244 = (_28243 != 9);
    }
    else {
        _28244 = binary_op(NOTEQ, _28243, 9);
    }
    DeRef(_28243);
    _28243 = NOVALUE;
    if (_28244 == 0) {
        DeRef(_28244);
        _28244 = NOVALUE;
        goto L7; // [220] 250
    }
    else {
        if (!IS_ATOM_INT(_28244) && DBL_PTR(_28244)->dbl == 0.0){
            DeRef(_28244);
            _28244 = NOVALUE;
            goto L7; // [220] 250
        }
        DeRef(_28244);
        _28244 = NOVALUE;
    }
    DeRef(_28244);
    _28244 = NOVALUE;

    /** 			t = { sym_token( Recorded_sym[n] ), Recorded_sym[n] }*/
    _2 = (int)SEQ_PTR(_26Recorded_sym_12091);
    _28245 = (int)*(((s1_ptr)_2)->base + _n_54905);
    Ref(_28245);
    _28246 = _52sym_token(_28245);
    _28245 = NOVALUE;
    _2 = (int)SEQ_PTR(_26Recorded_sym_12091);
    _28247 = (int)*(((s1_ptr)_2)->base + _n_54905);
    Ref(_28247);
    DeRef(_t_54907);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _28246;
    ((int *)_2)[2] = _28247;
    _t_54907 = MAKE_SEQ(_1);
    _28247 = NOVALUE;
    _28246 = NOVALUE;

    /** 			break "top if"*/
    goto L8; // [247] 728
L7: 

    /** 		t = keyfind(Recorded[n],-1)*/
    _2 = (int)SEQ_PTR(_26Recorded_12089);
    _28249 = (int)*(((s1_ptr)_2)->base + _n_54905);
    RefDS(_28249);
    DeRef(_31660);
    _31660 = _28249;
    _31661 = _52hashfn(_31660);
    _31660 = NOVALUE;
    RefDS(_28249);
    _0 = _t_54907;
    _t_54907 = _52keyfind(_28249, -1, _26current_file_no_11982, 0, _31661);
    DeRef(_0);
    _28249 = NOVALUE;
    _31661 = NOVALUE;

    /** 		if t[T_ID] = IGNORED then*/
    _2 = (int)SEQ_PTR(_t_54907);
    _28251 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28251, 509)){
        _28251 = NOVALUE;
        goto L8; // [286] 728
    }
    _28251 = NOVALUE;

    /** 	        p = Recorded_sym[n]*/
    _2 = (int)SEQ_PTR(_26Recorded_sym_12091);
    _p_54908 = (int)*(((s1_ptr)_2)->base + _n_54905);
    if (!IS_ATOM_INT(_p_54908)){
        _p_54908 = (long)DBL_PTR(_p_54908)->dbl;
    }

    /** 	        if p = 0 then*/
    if (_p_54908 != 0)
    goto L9; // [302] 380

    /** 				No_new_entry = 0*/
    _52No_new_entry_47302 = 0;

    /** 				t = keyfind( Recorded[n], -1 )*/
    _2 = (int)SEQ_PTR(_26Recorded_12089);
    _28255 = (int)*(((s1_ptr)_2)->base + _n_54905);
    RefDS(_28255);
    DeRef(_31658);
    _31658 = _28255;
    _31659 = _52hashfn(_31658);
    _31658 = NOVALUE;
    RefDS(_28255);
    _0 = _t_54907;
    _t_54907 = _52keyfind(_28255, -1, _26current_file_no_11982, 0, _31659);
    DeRef(_0);
    _28255 = NOVALUE;
    _31659 = NOVALUE;

    /** 				No_new_entry = 1*/
    _52No_new_entry_47302 = 1;

    /** 				if t[T_ID] = IGNORED then*/
    _2 = (int)SEQ_PTR(_t_54907);
    _28257 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28257, 509)){
        _28257 = NOVALUE;
        goto L8; // [355] 728
    }
    _28257 = NOVALUE;

    /** 					CompileErr(157,{Recorded[n]})*/
    _2 = (int)SEQ_PTR(_26Recorded_12089);
    _28259 = (int)*(((s1_ptr)_2)->base + _n_54905);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_28259);
    *((int *)(_2+4)) = _28259;
    _28260 = MAKE_SEQ(_1);
    _28259 = NOVALUE;
    _43CompileErr(157, _28260, 0);
    _28260 = NOVALUE;
    goto L8; // [377] 728
L9: 

    /** 				t = {SymTab[p][S_TOKEN], p}*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _28261 = (int)*(((s1_ptr)_2)->base + _p_54908);
    _2 = (int)SEQ_PTR(_28261);
    if (!IS_ATOM_INT(_26S_TOKEN_11659)){
        _28262 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_TOKEN_11659)->dbl));
    }
    else{
        _28262 = (int)*(((s1_ptr)_2)->base + _26S_TOKEN_11659);
    }
    _28261 = NOVALUE;
    Ref(_28262);
    DeRef(_t_54907);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _28262;
    ((int *)_2)[2] = _p_54908;
    _t_54907 = MAKE_SEQ(_1);
    _28262 = NOVALUE;
    goto L8; // [400] 728
L1: 

    /** 		prev_Nne = No_new_entry*/
    _prev_Nne_54909 = _52No_new_entry_47302;

    /** 		No_new_entry = 1*/
    _52No_new_entry_47302 = 1;

    /** 		t = keyfind(Ns_recorded[n],-1, , 1)*/
    _2 = (int)SEQ_PTR(_26Ns_recorded_12090);
    _28264 = (int)*(((s1_ptr)_2)->base + _n_54905);
    Ref(_28264);
    DeRef(_31656);
    _31656 = _28264;
    _31657 = _52hashfn(_31656);
    _31656 = NOVALUE;
    Ref(_28264);
    _0 = _t_54907;
    _t_54907 = _52keyfind(_28264, -1, _26current_file_no_11982, 1, _31657);
    DeRef(_0);
    _28264 = NOVALUE;
    _31657 = NOVALUE;

    /** 		if t[T_ID] != NAMESPACE then*/
    _2 = (int)SEQ_PTR(_t_54907);
    _28266 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _28266, 523)){
        _28266 = NOVALUE;
        goto LA; // [454] 520
    }
    _28266 = NOVALUE;

    /** 			p = Ns_recorded_sym[n]*/
    _2 = (int)SEQ_PTR(_26Ns_recorded_sym_12092);
    _p_54908 = (int)*(((s1_ptr)_2)->base + _n_54905);
    if (!IS_ATOM_INT(_p_54908)){
        _p_54908 = (long)DBL_PTR(_p_54908)->dbl;
    }

    /** 			if p = 0 or sym_token( p ) != NAMESPACE then*/
    _28269 = (_p_54908 == 0);
    if (_28269 != 0) {
        goto LB; // [474] 493
    }
    _28271 = _52sym_token(_p_54908);
    if (IS_ATOM_INT(_28271)) {
        _28272 = (_28271 != 523);
    }
    else {
        _28272 = binary_op(NOTEQ, _28271, 523);
    }
    DeRef(_28271);
    _28271 = NOVALUE;
    if (_28272 == 0) {
        DeRef(_28272);
        _28272 = NOVALUE;
        goto LC; // [489] 511
    }
    else {
        if (!IS_ATOM_INT(_28272) && DBL_PTR(_28272)->dbl == 0.0){
            DeRef(_28272);
            _28272 = NOVALUE;
            goto LC; // [489] 511
        }
        DeRef(_28272);
        _28272 = NOVALUE;
    }
    DeRef(_28272);
    _28272 = NOVALUE;
LB: 

    /** 				CompileErr(153, {Ns_recorded[n]})*/
    _2 = (int)SEQ_PTR(_26Ns_recorded_12090);
    _28273 = (int)*(((s1_ptr)_2)->base + _n_54905);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_28273);
    *((int *)(_2+4)) = _28273;
    _28274 = MAKE_SEQ(_1);
    _28273 = NOVALUE;
    _43CompileErr(153, _28274, 0);
    _28274 = NOVALUE;
LC: 

    /** 			t = {NAMESPACE, p}*/
    DeRef(_t_54907);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 523;
    ((int *)_2)[2] = _p_54908;
    _t_54907 = MAKE_SEQ(_1);
LA: 

    /** 		t = keyfind(Recorded[n],SymTab[t[T_SYM]][S_OBJ])*/
    _2 = (int)SEQ_PTR(_26Recorded_12089);
    _28276 = (int)*(((s1_ptr)_2)->base + _n_54905);
    _2 = (int)SEQ_PTR(_t_54907);
    _28277 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!IS_ATOM_INT(_28277)){
        _28278 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_28277)->dbl));
    }
    else{
        _28278 = (int)*(((s1_ptr)_2)->base + _28277);
    }
    _2 = (int)SEQ_PTR(_28278);
    _28279 = (int)*(((s1_ptr)_2)->base + 1);
    _28278 = NOVALUE;
    RefDS(_28276);
    DeRef(_31654);
    _31654 = _28276;
    _31655 = _52hashfn(_31654);
    _31654 = NOVALUE;
    RefDS(_28276);
    Ref(_28279);
    _0 = _t_54907;
    _t_54907 = _52keyfind(_28276, _28279, _26current_file_no_11982, 0, _31655);
    DeRef(_0);
    _28276 = NOVALUE;
    _28279 = NOVALUE;
    _31655 = NOVALUE;

    /** 		if t[T_ID] = IGNORED then*/
    _2 = (int)SEQ_PTR(_t_54907);
    _28281 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28281, 509)){
        _28281 = NOVALUE;
        goto LD; // [573] 630
    }
    _28281 = NOVALUE;

    /** 	        p = Recorded_sym[n]*/
    _2 = (int)SEQ_PTR(_26Recorded_sym_12091);
    _p_54908 = (int)*(((s1_ptr)_2)->base + _n_54905);
    if (!IS_ATOM_INT(_p_54908)){
        _p_54908 = (long)DBL_PTR(_p_54908)->dbl;
    }

    /** 	        if p = 0 then*/
    if (_p_54908 != 0)
    goto LE; // [589] 611

    /** 	        	CompileErr(157,{Recorded[n]})*/
    _2 = (int)SEQ_PTR(_26Recorded_12089);
    _28285 = (int)*(((s1_ptr)_2)->base + _n_54905);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_28285);
    *((int *)(_2+4)) = _28285;
    _28286 = MAKE_SEQ(_1);
    _28285 = NOVALUE;
    _43CompileErr(157, _28286, 0);
    _28286 = NOVALUE;
LE: 

    /** 		    t = {SymTab[p][S_TOKEN], p}*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _28287 = (int)*(((s1_ptr)_2)->base + _p_54908);
    _2 = (int)SEQ_PTR(_28287);
    if (!IS_ATOM_INT(_26S_TOKEN_11659)){
        _28288 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_TOKEN_11659)->dbl));
    }
    else{
        _28288 = (int)*(((s1_ptr)_2)->base + _26S_TOKEN_11659);
    }
    _28287 = NOVALUE;
    Ref(_28288);
    DeRef(_t_54907);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _28288;
    ((int *)_2)[2] = _p_54908;
    _t_54907 = MAKE_SEQ(_1);
    _28288 = NOVALUE;
LD: 

    /** 		n = t[T_ID]*/
    _2 = (int)SEQ_PTR(_t_54907);
    _n_54905 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_n_54905)){
        _n_54905 = (long)DBL_PTR(_n_54905)->dbl;
    }

    /** 		if n = VARIABLE then*/
    if (_n_54905 != -100)
    goto LF; // [644] 660

    /** 			n = QUALIFIED_VARIABLE*/
    _n_54905 = 512;
    goto L10; // [657] 719
LF: 

    /** 		elsif n = FUNC then*/
    if (_n_54905 != 501)
    goto L11; // [664] 680

    /** 			n = QUALIFIED_FUNC*/
    _n_54905 = 520;
    goto L10; // [677] 719
L11: 

    /** 		elsif n = PROC then*/
    if (_n_54905 != 27)
    goto L12; // [684] 700

    /** 			n = QUALIFIED_PROC*/
    _n_54905 = 521;
    goto L10; // [697] 719
L12: 

    /** 		elsif n = TYPE then*/
    if (_n_54905 != 504)
    goto L13; // [704] 718

    /** 			n = QUALIFIED_TYPE*/
    _n_54905 = 522;
L13: 
L10: 

    /** 		t[T_ID] = n*/
    _2 = (int)SEQ_PTR(_t_54907);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _t_54907 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _n_54905;
    DeRef(_1);
L8: 

    /** 	No_new_entry = prev_Nne*/
    _52No_new_entry_47302 = _prev_Nne_54909;

    /**   	return t*/
    _28228 = NOVALUE;
    DeRef(_28226);
    _28226 = NOVALUE;
    DeRef(_28236);
    _28236 = NOVALUE;
    DeRef(_28231);
    _28231 = NOVALUE;
    DeRef(_28238);
    _28238 = NOVALUE;
    DeRef(_28269);
    _28269 = NOVALUE;
    DeRef(_28240);
    _28240 = NOVALUE;
    _28277 = NOVALUE;
    return _t_54907;
    ;
}


int _30next_token()
{
    int _t_55086 = NOVALUE;
    int _s_55087 = NOVALUE;
    int _28327 = NOVALUE;
    int _28326 = NOVALUE;
    int _28325 = NOVALUE;
    int _28324 = NOVALUE;
    int _28323 = NOVALUE;
    int _28322 = NOVALUE;
    int _28321 = NOVALUE;
    int _28320 = NOVALUE;
    int _28318 = NOVALUE;
    int _28317 = NOVALUE;
    int _28316 = NOVALUE;
    int _28315 = NOVALUE;
    int _28313 = NOVALUE;
    int _28311 = NOVALUE;
    int _28309 = NOVALUE;
    int _28305 = NOVALUE;
    int _28302 = NOVALUE;
    int _28299 = NOVALUE;
    int _28297 = NOVALUE;
    int _28295 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence s*/

    /** 	if length(backed_up_tok) > 0 then*/
    if (IS_SEQUENCE(_30backed_up_tok_54163)){
            _28295 = SEQ_PTR(_30backed_up_tok_54163)->length;
    }
    else {
        _28295 = 1;
    }
    if (_28295 <= 0)
    goto L1; // [10] 82

    /** 		t = backed_up_tok[$]*/
    if (IS_SEQUENCE(_30backed_up_tok_54163)){
            _28297 = SEQ_PTR(_30backed_up_tok_54163)->length;
    }
    else {
        _28297 = 1;
    }
    DeRef(_t_55086);
    _2 = (int)SEQ_PTR(_30backed_up_tok_54163);
    _t_55086 = (int)*(((s1_ptr)_2)->base + _28297);
    Ref(_t_55086);

    /** 		backed_up_tok = remove( backed_up_tok, length( backed_up_tok ) )*/
    if (IS_SEQUENCE(_30backed_up_tok_54163)){
            _28299 = SEQ_PTR(_30backed_up_tok_54163)->length;
    }
    else {
        _28299 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_30backed_up_tok_54163);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_28299)) ? _28299 : (long)(DBL_PTR(_28299)->dbl);
        int stop = (IS_ATOM_INT(_28299)) ? _28299 : (long)(DBL_PTR(_28299)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_30backed_up_tok_54163), start, &_30backed_up_tok_54163 );
            }
            else Tail(SEQ_PTR(_30backed_up_tok_54163), stop+1, &_30backed_up_tok_54163);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_30backed_up_tok_54163), start, &_30backed_up_tok_54163);
        }
        else {
            assign_slice_seq = &assign_space;
            _30backed_up_tok_54163 = Remove_elements(start, stop, (SEQ_PTR(_30backed_up_tok_54163)->ref == 1));
        }
    }
    _28299 = NOVALUE;
    _28299 = NOVALUE;

    /** 		if putback_fwd_line_number then*/
    if (_26putback_fwd_line_number_11985 == 0)
    {
        goto L2; // [43] 347
    }
    else{
    }

    /** 			ForwardLine     = putback_ForwardLine*/
    Ref(_43putback_ForwardLine_48559);
    DeRef(_43ForwardLine_48558);
    _43ForwardLine_48558 = _43putback_ForwardLine_48559;

    /** 			forward_bp      = putback_forward_bp*/
    _43forward_bp_48562 = _43putback_forward_bp_48563;

    /** 			fwd_line_number = putback_fwd_line_number*/
    _26fwd_line_number_11984 = _26putback_fwd_line_number_11985;

    /** 			putback_fwd_line_number = 0*/
    _26putback_fwd_line_number_11985 = 0;
    goto L2; // [79] 347
L1: 

    /** 	elsif Parser_mode = PAM_PLAYBACK then*/
    if (_26Parser_mode_12088 != -1)
    goto L3; // [88] 300

    /** 		if canned_index <= length(canned_tokens) then*/
    if (IS_SEQUENCE(_30canned_tokens_54200)){
            _28302 = SEQ_PTR(_30canned_tokens_54200)->length;
    }
    else {
        _28302 = 1;
    }
    if (_30canned_index_54201 > _28302)
    goto L4; // [101] 150

    /** 			t = canned_tokens[canned_index]*/
    DeRef(_t_55086);
    _2 = (int)SEQ_PTR(_30canned_tokens_54200);
    _t_55086 = (int)*(((s1_ptr)_2)->base + _30canned_index_54201);
    Ref(_t_55086);

    /** 			if canned_index < length(canned_tokens) then*/
    if (IS_SEQUENCE(_30canned_tokens_54200)){
            _28305 = SEQ_PTR(_30canned_tokens_54200)->length;
    }
    else {
        _28305 = 1;
    }
    if (_30canned_index_54201 >= _28305)
    goto L5; // [124] 139

    /** 				canned_index += 1*/
    _30canned_index_54201 = _30canned_index_54201 + 1;
    goto L6; // [136] 157
L5: 

    /** 	            s = restore_parser()*/
    _0 = _s_55087;
    _s_55087 = _30restore_parser();
    DeRef(_0);
    goto L6; // [147] 157
L4: 

    /** 	    	InternalErr(266)*/
    RefDS(_22037);
    _43InternalErr(266, _22037);
L6: 

    /** 		if t[T_ID] = RECORDED then*/
    _2 = (int)SEQ_PTR(_t_55086);
    _28309 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28309, 508)){
        _28309 = NOVALUE;
        goto L7; // [169] 188
    }
    _28309 = NOVALUE;

    /** 			t=read_recorded_token(t[T_SYM])*/
    _2 = (int)SEQ_PTR(_t_55086);
    _28311 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_28311);
    _0 = _t_55086;
    _t_55086 = _30read_recorded_token(_28311);
    DeRef(_0);
    _28311 = NOVALUE;
    goto L2; // [185] 347
L7: 

    /** 		elsif t[T_ID] = DEF_PARAM then*/
    _2 = (int)SEQ_PTR(_t_55086);
    _28313 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28313, 510)){
        _28313 = NOVALUE;
        goto L2; // [198] 347
    }
    _28313 = NOVALUE;

    /**         	for i=length(nested_calls) to 1 by -1 do*/
    if (IS_SEQUENCE(_30nested_calls_54881)){
            _28315 = SEQ_PTR(_30nested_calls_54881)->length;
    }
    else {
        _28315 = 1;
    }
    {
        int _i_55134;
        _i_55134 = _28315;
L8: 
        if (_i_55134 < 1){
            goto L9; // [209] 288
        }

        /**         	    if nested_calls[i] = t[T_SYM][2] then*/
        _2 = (int)SEQ_PTR(_30nested_calls_54881);
        _28316 = (int)*(((s1_ptr)_2)->base + _i_55134);
        _2 = (int)SEQ_PTR(_t_55086);
        _28317 = (int)*(((s1_ptr)_2)->base + 2);
        _2 = (int)SEQ_PTR(_28317);
        _28318 = (int)*(((s1_ptr)_2)->base + 2);
        _28317 = NOVALUE;
        if (binary_op_a(NOTEQ, _28316, _28318)){
            _28316 = NOVALUE;
            _28318 = NOVALUE;
            goto LA; // [234] 281
        }
        _28316 = NOVALUE;
        _28318 = NOVALUE;

        /** 					return {VARIABLE, private_sym[parseargs_states[i][PS_POSITION]+t[T_SYM][1]]}*/
        _2 = (int)SEQ_PTR(_30parseargs_states_54873);
        _28320 = (int)*(((s1_ptr)_2)->base + _i_55134);
        _2 = (int)SEQ_PTR(_28320);
        _28321 = (int)*(((s1_ptr)_2)->base + 1);
        _28320 = NOVALUE;
        _2 = (int)SEQ_PTR(_t_55086);
        _28322 = (int)*(((s1_ptr)_2)->base + 2);
        _2 = (int)SEQ_PTR(_28322);
        _28323 = (int)*(((s1_ptr)_2)->base + 1);
        _28322 = NOVALUE;
        if (IS_ATOM_INT(_28321) && IS_ATOM_INT(_28323)) {
            _28324 = _28321 + _28323;
        }
        else {
            _28324 = binary_op(PLUS, _28321, _28323);
        }
        _28321 = NOVALUE;
        _28323 = NOVALUE;
        _2 = (int)SEQ_PTR(_26private_sym_12095);
        if (!IS_ATOM_INT(_28324)){
            _28325 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_28324)->dbl));
        }
        else{
            _28325 = (int)*(((s1_ptr)_2)->base + _28324);
        }
        Ref(_28325);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = -100;
        ((int *)_2)[2] = _28325;
        _28326 = MAKE_SEQ(_1);
        _28325 = NOVALUE;
        DeRef(_t_55086);
        DeRef(_s_55087);
        DeRef(_28324);
        _28324 = NOVALUE;
        return _28326;
LA: 

        /** 			end for*/
        _i_55134 = _i_55134 + -1;
        goto L8; // [283] 216
L9: 
        ;
    }

    /** 			CompileErr(98)*/
    RefDS(_22037);
    _43CompileErr(98, _22037, 0);
    goto L2; // [297] 347
L3: 

    /** 	elsif lock_scanner then*/
    if (_30lock_scanner_54879 == 0)
    {
        goto LB; // [304] 322
    }
    else{
    }

    /** 		return {PLAYBACK_ENDS,0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 505;
    ((int *)_2)[2] = 0;
    _28327 = MAKE_SEQ(_1);
    DeRef(_t_55086);
    DeRef(_s_55087);
    DeRef(_28326);
    _28326 = NOVALUE;
    DeRef(_28324);
    _28324 = NOVALUE;
    return _28327;
    goto L2; // [319] 347
LB: 

    /** 	    t = Scanner()*/
    _0 = _t_55086;
    _t_55086 = _60Scanner();
    DeRef(_0);

    /** 	    if Parser_mode = PAM_RECORD then*/
    if (_26Parser_mode_12088 != 1)
    goto LC; // [333] 346

    /** 	        canned_tokens = append(canned_tokens,t)*/
    Ref(_t_55086);
    Append(&_30canned_tokens_54200, _30canned_tokens_54200, _t_55086);
LC: 
L2: 

    /** 	putback_fwd_line_number = 0*/
    _26putback_fwd_line_number_11985 = 0;

    /** 	return t*/
    DeRef(_s_55087);
    DeRef(_28326);
    _28326 = NOVALUE;
    DeRef(_28327);
    _28327 = NOVALUE;
    DeRef(_28324);
    _28324 = NOVALUE;
    return _t_55086;
    ;
}


int _30Expr_list()
{
    int _tok_55169 = NOVALUE;
    int _n_55170 = NOVALUE;
    int _28343 = NOVALUE;
    int _28340 = NOVALUE;
    int _28339 = NOVALUE;
    int _28337 = NOVALUE;
    int _28336 = NOVALUE;
    int _28332 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer n*/

    /** 	tok = next_token()*/
    _0 = _tok_55169;
    _tok_55169 = _30next_token();
    DeRef(_0);

    /** 	putback(tok)*/
    Ref(_tok_55169);
    _30putback(_tok_55169);

    /** 	if tok[T_ID] = RIGHT_BRACE then*/
    _2 = (int)SEQ_PTR(_tok_55169);
    _28332 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28332, -25)){
        _28332 = NOVALUE;
        goto L1; // [23] 36
    }
    _28332 = NOVALUE;

    /** 		return 0*/
    DeRef(_tok_55169);
    return 0;
    goto L2; // [33] 142
L1: 

    /** 		n = 0*/
    _n_55170 = 0;

    /** 		short_circuit -= 1*/
    _30short_circuit_54156 = _30short_circuit_54156 - 1;

    /** 		while TRUE do*/
L3: 
    if (_9TRUE_430 == 0)
    {
        goto L4; // [56] 133
    }
    else{
    }

    /** 			gListItem &= 1*/
    Append(&_30gListItem_54192, _30gListItem_54192, 1);

    /** 			Expr()*/
    _30Expr();

    /** 			n += gListItem[$]*/
    if (IS_SEQUENCE(_30gListItem_54192)){
            _28336 = SEQ_PTR(_30gListItem_54192)->length;
    }
    else {
        _28336 = 1;
    }
    _2 = (int)SEQ_PTR(_30gListItem_54192);
    _28337 = (int)*(((s1_ptr)_2)->base + _28336);
    _n_55170 = _n_55170 + _28337;
    _28337 = NOVALUE;

    /** 			gListItem = gListItem[1 .. $-1]*/
    if (IS_SEQUENCE(_30gListItem_54192)){
            _28339 = SEQ_PTR(_30gListItem_54192)->length;
    }
    else {
        _28339 = 1;
    }
    _28340 = _28339 - 1;
    _28339 = NOVALUE;
    rhs_slice_target = (object_ptr)&_30gListItem_54192;
    RHS_Slice(_30gListItem_54192, 1, _28340);

    /** 			tok = next_token()*/
    _0 = _tok_55169;
    _tok_55169 = _30next_token();
    DeRef(_0);

    /** 			if tok[T_ID] != COMMA then*/
    _2 = (int)SEQ_PTR(_tok_55169);
    _28343 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _28343, -30)){
        _28343 = NOVALUE;
        goto L3; // [119] 54
    }
    _28343 = NOVALUE;

    /** 				exit*/
    goto L4; // [125] 133

    /** 		end while*/
    goto L3; // [130] 54
L4: 

    /** 		short_circuit += 1*/
    _30short_circuit_54156 = _30short_circuit_54156 + 1;
L2: 

    /** 	putback(tok)*/
    Ref(_tok_55169);
    _30putback(_tok_55169);

    /** 	return n*/
    DeRef(_tok_55169);
    DeRef(_28340);
    _28340 = NOVALUE;
    return _n_55170;
    ;
}


void _30tok_match(int _tok_55198, int _prevtok_55199)
{
    int _t_55201 = NOVALUE;
    int _expected_55202 = NOVALUE;
    int _actual_55203 = NOVALUE;
    int _prevname_55204 = NOVALUE;
    int _28355 = NOVALUE;
    int _28353 = NOVALUE;
    int _28350 = NOVALUE;
    int _28347 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence expected, actual, prevname*/

    /** 	t = next_token()*/
    _0 = _t_55201;
    _t_55201 = _30next_token();
    DeRef(_0);

    /** 	if t[T_ID] != tok then*/
    _2 = (int)SEQ_PTR(_t_55201);
    _28347 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _28347, _tok_55198)){
        _28347 = NOVALUE;
        goto L1; // [20] 92
    }
    _28347 = NOVALUE;

    /** 		expected = LexName(tok)*/
    RefDS(_26480);
    _0 = _expected_55202;
    _expected_55202 = _37LexName(_tok_55198, _26480);
    DeRef(_0);

    /** 		actual = LexName(t[T_ID])*/
    _2 = (int)SEQ_PTR(_t_55201);
    _28350 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_28350);
    RefDS(_26480);
    _0 = _actual_55203;
    _actual_55203 = _37LexName(_28350, _26480);
    DeRef(_0);
    _28350 = NOVALUE;

    /** 		if prevtok = 0 then*/
    if (_prevtok_55199 != 0)
    goto L2; // [50] 68

    /** 			CompileErr(132, {expected, actual})*/
    RefDS(_actual_55203);
    RefDS(_expected_55202);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _expected_55202;
    ((int *)_2)[2] = _actual_55203;
    _28353 = MAKE_SEQ(_1);
    _43CompileErr(132, _28353, 0);
    _28353 = NOVALUE;
    goto L3; // [65] 91
L2: 

    /** 			prevname = LexName(prevtok)*/
    RefDS(_26480);
    _0 = _prevname_55204;
    _prevname_55204 = _37LexName(_prevtok_55199, _26480);
    DeRef(_0);

    /** 			CompileErr(138, {expected, prevname, actual})*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_expected_55202);
    *((int *)(_2+4)) = _expected_55202;
    RefDS(_prevname_55204);
    *((int *)(_2+8)) = _prevname_55204;
    RefDS(_actual_55203);
    *((int *)(_2+12)) = _actual_55203;
    _28355 = MAKE_SEQ(_1);
    _43CompileErr(138, _28355, 0);
    _28355 = NOVALUE;
L3: 
L1: 

    /** end procedure*/
    DeRef(_t_55201);
    DeRef(_expected_55202);
    DeRef(_actual_55203);
    DeRef(_prevname_55204);
    return;
    ;
}


void _30UndefinedVar(int _s_55238)
{
    int _dup_55240 = NOVALUE;
    int _errmsg_55241 = NOVALUE;
    int _rname_55242 = NOVALUE;
    int _fname_55243 = NOVALUE;
    int _28378 = NOVALUE;
    int _28377 = NOVALUE;
    int _28375 = NOVALUE;
    int _28373 = NOVALUE;
    int _28372 = NOVALUE;
    int _28370 = NOVALUE;
    int _28368 = NOVALUE;
    int _28366 = NOVALUE;
    int _28365 = NOVALUE;
    int _28364 = NOVALUE;
    int _28363 = NOVALUE;
    int _28362 = NOVALUE;
    int _28360 = NOVALUE;
    int _28359 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_s_55238)) {
        _1 = (long)(DBL_PTR(_s_55238)->dbl);
        DeRefDS(_s_55238);
        _s_55238 = _1;
    }

    /** 	sequence errmsg*/

    /** 	sequence rname*/

    /** 	sequence fname*/

    /** 	if SymTab[s][S_SCOPE] = SC_UNDEFINED then*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _28359 = (int)*(((s1_ptr)_2)->base + _s_55238);
    _2 = (int)SEQ_PTR(_28359);
    _28360 = (int)*(((s1_ptr)_2)->base + 4);
    _28359 = NOVALUE;
    if (binary_op_a(NOTEQ, _28360, 9)){
        _28360 = NOVALUE;
        goto L1; // [25] 55
    }
    _28360 = NOVALUE;

    /** 		CompileErr(19, {SymTab[s][S_NAME]})*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _28362 = (int)*(((s1_ptr)_2)->base + _s_55238);
    _2 = (int)SEQ_PTR(_28362);
    if (!IS_ATOM_INT(_26S_NAME_11654)){
        _28363 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NAME_11654)->dbl));
    }
    else{
        _28363 = (int)*(((s1_ptr)_2)->base + _26S_NAME_11654);
    }
    _28362 = NOVALUE;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_28363);
    *((int *)(_2+4)) = _28363;
    _28364 = MAKE_SEQ(_1);
    _28363 = NOVALUE;
    _43CompileErr(19, _28364, 0);
    _28364 = NOVALUE;
    goto L2; // [52] 202
L1: 

    /** 	elsif SymTab[s][S_SCOPE] = SC_MULTIPLY_DEFINED then*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _28365 = (int)*(((s1_ptr)_2)->base + _s_55238);
    _2 = (int)SEQ_PTR(_28365);
    _28366 = (int)*(((s1_ptr)_2)->base + 4);
    _28365 = NOVALUE;
    if (binary_op_a(NOTEQ, _28366, 10)){
        _28366 = NOVALUE;
        goto L3; // [71] 179
    }
    _28366 = NOVALUE;

    /** 		rname = SymTab[s][S_NAME]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _28368 = (int)*(((s1_ptr)_2)->base + _s_55238);
    DeRef(_rname_55242);
    _2 = (int)SEQ_PTR(_28368);
    if (!IS_ATOM_INT(_26S_NAME_11654)){
        _rname_55242 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NAME_11654)->dbl));
    }
    else{
        _rname_55242 = (int)*(((s1_ptr)_2)->base + _26S_NAME_11654);
    }
    Ref(_rname_55242);
    _28368 = NOVALUE;

    /** 		errmsg = ""*/
    RefDS(_22037);
    DeRef(_errmsg_55241);
    _errmsg_55241 = _22037;

    /** 		for i = 1 to length(dup_globals) do*/
    if (IS_SEQUENCE(_52dup_globals_47291)){
            _28370 = SEQ_PTR(_52dup_globals_47291)->length;
    }
    else {
        _28370 = 1;
    }
    {
        int _i_55269;
        _i_55269 = 1;
L4: 
        if (_i_55269 > _28370){
            goto L5; // [105] 163
        }

        /** 			dup = dup_globals[i]*/
        _2 = (int)SEQ_PTR(_52dup_globals_47291);
        _dup_55240 = (int)*(((s1_ptr)_2)->base + _i_55269);
        if (!IS_ATOM_INT(_dup_55240)){
            _dup_55240 = (long)DBL_PTR(_dup_55240)->dbl;
        }

        /** 			fname = known_files[SymTab[dup][S_FILE_NO]]*/
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _28372 = (int)*(((s1_ptr)_2)->base + _dup_55240);
        _2 = (int)SEQ_PTR(_28372);
        if (!IS_ATOM_INT(_26S_FILE_NO_11650)){
            _28373 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_FILE_NO_11650)->dbl));
        }
        else{
            _28373 = (int)*(((s1_ptr)_2)->base + _26S_FILE_NO_11650);
        }
        _28372 = NOVALUE;
        DeRef(_fname_55243);
        _2 = (int)SEQ_PTR(_27known_files_10922);
        if (!IS_ATOM_INT(_28373)){
            _fname_55243 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_28373)->dbl));
        }
        else{
            _fname_55243 = (int)*(((s1_ptr)_2)->base + _28373);
        }
        Ref(_fname_55243);

        /** 			errmsg &= "    " & fname & "\n"*/
        {
            int concat_list[3];

            concat_list[0] = _22189;
            concat_list[1] = _fname_55243;
            concat_list[2] = _24978;
            Concat_N((object_ptr)&_28375, concat_list, 3);
        }
        Concat((object_ptr)&_errmsg_55241, _errmsg_55241, _28375);
        DeRefDS(_28375);
        _28375 = NOVALUE;

        /** 		end for*/
        _i_55269 = _i_55269 + 1;
        goto L4; // [158] 112
L5: 
        ;
    }

    /** 		CompileErr(23, {rname, rname, errmsg})*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    RefDSn(_rname_55242, 2);
    *((int *)(_2+4)) = _rname_55242;
    *((int *)(_2+8)) = _rname_55242;
    RefDS(_errmsg_55241);
    *((int *)(_2+12)) = _errmsg_55241;
    _28377 = MAKE_SEQ(_1);
    _43CompileErr(23, _28377, 0);
    _28377 = NOVALUE;
    goto L2; // [176] 202
L3: 

    /** 	elsif length(symbol_resolution_warning) then*/
    if (IS_SEQUENCE(_26symbol_resolution_warning_12084)){
            _28378 = SEQ_PTR(_26symbol_resolution_warning_12084)->length;
    }
    else {
        _28378 = 1;
    }
    if (_28378 == 0)
    {
        _28378 = NOVALUE;
        goto L6; // [186] 201
    }
    else{
        _28378 = NOVALUE;
    }

    /** 		Warning( symbol_resolution_warning, resolution_warning_flag)*/
    RefDS(_26symbol_resolution_warning_12084);
    RefDS(_22037);
    _43Warning(_26symbol_resolution_warning_12084, 1, _22037);
L6: 
L2: 

    /** end procedure*/
    DeRef(_errmsg_55241);
    DeRef(_rname_55242);
    DeRef(_fname_55243);
    _28373 = NOVALUE;
    return;
    ;
}


void _30WrongNumberArgs(int _subsym_55293, int _only_55294)
{
    int _msgno_55295 = NOVALUE;
    int _28390 = NOVALUE;
    int _28389 = NOVALUE;
    int _28388 = NOVALUE;
    int _28387 = NOVALUE;
    int _28386 = NOVALUE;
    int _28384 = NOVALUE;
    int _28382 = NOVALUE;
    int _28380 = NOVALUE;
    int _28379 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_subsym_55293)) {
        _1 = (long)(DBL_PTR(_subsym_55293)->dbl);
        DeRefDS(_subsym_55293);
        _subsym_55293 = _1;
    }

    /** 	if SymTab[subsym][S_NUM_ARGS] = 1 then*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _28379 = (int)*(((s1_ptr)_2)->base + _subsym_55293);
    _2 = (int)SEQ_PTR(_28379);
    if (!IS_ATOM_INT(_26S_NUM_ARGS_11705)){
        _28380 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NUM_ARGS_11705)->dbl));
    }
    else{
        _28380 = (int)*(((s1_ptr)_2)->base + _26S_NUM_ARGS_11705);
    }
    _28379 = NOVALUE;
    if (binary_op_a(NOTEQ, _28380, 1)){
        _28380 = NOVALUE;
        goto L1; // [19] 49
    }
    _28380 = NOVALUE;

    /** 		if length(only) = 0 then*/
    if (IS_SEQUENCE(_only_55294)){
            _28382 = SEQ_PTR(_only_55294)->length;
    }
    else {
        _28382 = 1;
    }
    if (_28382 != 0)
    goto L2; // [28] 40

    /** 			msgno = 20*/
    _msgno_55295 = 20;
    goto L3; // [37] 73
L2: 

    /** 			msgno = 237*/
    _msgno_55295 = 237;
    goto L3; // [46] 73
L1: 

    /** 		if length(only) = 0 then*/
    if (IS_SEQUENCE(_only_55294)){
            _28384 = SEQ_PTR(_only_55294)->length;
    }
    else {
        _28384 = 1;
    }
    if (_28384 != 0)
    goto L4; // [54] 66

    /** 			msgno = 236*/
    _msgno_55295 = 236;
    goto L5; // [63] 72
L4: 

    /** 			msgno = 238*/
    _msgno_55295 = 238;
L5: 
L3: 

    /** 	CompileErr(msgno, {SymTab[subsym][S_NAME], SymTab[subsym][S_NUM_ARGS]})*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _28386 = (int)*(((s1_ptr)_2)->base + _subsym_55293);
    _2 = (int)SEQ_PTR(_28386);
    if (!IS_ATOM_INT(_26S_NAME_11654)){
        _28387 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NAME_11654)->dbl));
    }
    else{
        _28387 = (int)*(((s1_ptr)_2)->base + _26S_NAME_11654);
    }
    _28386 = NOVALUE;
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _28388 = (int)*(((s1_ptr)_2)->base + _subsym_55293);
    _2 = (int)SEQ_PTR(_28388);
    if (!IS_ATOM_INT(_26S_NUM_ARGS_11705)){
        _28389 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NUM_ARGS_11705)->dbl));
    }
    else{
        _28389 = (int)*(((s1_ptr)_2)->base + _26S_NUM_ARGS_11705);
    }
    _28388 = NOVALUE;
    Ref(_28389);
    Ref(_28387);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _28387;
    ((int *)_2)[2] = _28389;
    _28390 = MAKE_SEQ(_1);
    _28389 = NOVALUE;
    _28387 = NOVALUE;
    _43CompileErr(_msgno_55295, _28390, 0);
    _28390 = NOVALUE;

    /** end procedure*/
    DeRefDSi(_only_55294);
    return;
    ;
}


void _30MissingArgs(int _subsym_55324)
{
    int _eentry_55325 = NOVALUE;
    int _28395 = NOVALUE;
    int _28394 = NOVALUE;
    int _28393 = NOVALUE;
    int _28392 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence eentry = SymTab[subsym]*/
    DeRef(_eentry_55325);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _eentry_55325 = (int)*(((s1_ptr)_2)->base + _subsym_55324);
    Ref(_eentry_55325);

    /** 	CompileErr(235, {eentry[S_NAME], eentry[S_DEF_ARGS][2]})*/
    _2 = (int)SEQ_PTR(_eentry_55325);
    if (!IS_ATOM_INT(_26S_NAME_11654)){
        _28392 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NAME_11654)->dbl));
    }
    else{
        _28392 = (int)*(((s1_ptr)_2)->base + _26S_NAME_11654);
    }
    _2 = (int)SEQ_PTR(_eentry_55325);
    _28393 = (int)*(((s1_ptr)_2)->base + 28);
    _2 = (int)SEQ_PTR(_28393);
    _28394 = (int)*(((s1_ptr)_2)->base + 2);
    _28393 = NOVALUE;
    Ref(_28394);
    Ref(_28392);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _28392;
    ((int *)_2)[2] = _28394;
    _28395 = MAKE_SEQ(_1);
    _28394 = NOVALUE;
    _28392 = NOVALUE;
    _43CompileErr(235, _28395, 0);
    _28395 = NOVALUE;

    /** end procedure*/
    DeRefDS(_eentry_55325);
    return;
    ;
}


void _30Parse_default_arg(int _subsym_55338, int _arg_55339, int _fwd_private_list_55340, int _fwd_private_sym_55341)
{
    int _param_55343 = NOVALUE;
    int _28415 = NOVALUE;
    int _28414 = NOVALUE;
    int _28413 = NOVALUE;
    int _28412 = NOVALUE;
    int _28411 = NOVALUE;
    int _28410 = NOVALUE;
    int _28409 = NOVALUE;
    int _28408 = NOVALUE;
    int _28407 = NOVALUE;
    int _28406 = NOVALUE;
    int _28405 = NOVALUE;
    int _28404 = NOVALUE;
    int _28403 = NOVALUE;
    int _28401 = NOVALUE;
    int _28400 = NOVALUE;
    int _28397 = NOVALUE;
    int _28396 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_subsym_55338)) {
        _1 = (long)(DBL_PTR(_subsym_55338)->dbl);
        DeRefDS(_subsym_55338);
        _subsym_55338 = _1;
    }
    if (!IS_ATOM_INT(_arg_55339)) {
        _1 = (long)(DBL_PTR(_arg_55339)->dbl);
        DeRefDS(_arg_55339);
        _arg_55339 = _1;
    }

    /** 	symtab_index param = subsym*/
    _param_55343 = _subsym_55338;

    /** 	on_arg = arg*/
    _30on_arg_54880 = _arg_55339;

    /** 	parseargs_states = append(parseargs_states,*/
    if (IS_SEQUENCE(_30private_list_54878)){
            _28396 = SEQ_PTR(_30private_list_54878)->length;
    }
    else {
        _28396 = 1;
    }
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _28396;
    *((int *)(_2+8)) = _30lock_scanner_54879;
    *((int *)(_2+12)) = _26use_private_list_12096;
    *((int *)(_2+16)) = _30on_arg_54880;
    _28397 = MAKE_SEQ(_1);
    _28396 = NOVALUE;
    RefDS(_28397);
    Append(&_30parseargs_states_54873, _30parseargs_states_54873, _28397);
    DeRefDS(_28397);
    _28397 = NOVALUE;

    /** 	nested_calls &= subsym*/
    Append(&_30nested_calls_54881, _30nested_calls_54881, _subsym_55338);

    /** 	for i = 1 to arg do*/
    _28400 = _arg_55339;
    {
        int _i_55350;
        _i_55350 = 1;
L1: 
        if (_i_55350 > _28400){
            goto L2; // [60] 90
        }

        /** 		param = SymTab[param][S_NEXT]*/
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _28401 = (int)*(((s1_ptr)_2)->base + _param_55343);
        _2 = (int)SEQ_PTR(_28401);
        _param_55343 = (int)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_param_55343)){
            _param_55343 = (long)DBL_PTR(_param_55343)->dbl;
        }
        _28401 = NOVALUE;

        /** 	end for*/
        _i_55350 = _i_55350 + 1;
        goto L1; // [85] 67
L2: 
        ;
    }

    /** 	private_list = fwd_private_list*/
    RefDS(_fwd_private_list_55340);
    DeRef(_30private_list_54878);
    _30private_list_54878 = _fwd_private_list_55340;

    /** 	private_sym  = fwd_private_sym*/
    RefDS(_fwd_private_sym_55341);
    DeRef(_26private_sym_12095);
    _26private_sym_12095 = _fwd_private_sym_55341;

    /** 	if atom(SymTab[param][S_CODE]) then  -- but no default set*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _28403 = (int)*(((s1_ptr)_2)->base + _param_55343);
    _2 = (int)SEQ_PTR(_28403);
    if (!IS_ATOM_INT(_26S_CODE_11666)){
        _28404 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_CODE_11666)->dbl));
    }
    else{
        _28404 = (int)*(((s1_ptr)_2)->base + _26S_CODE_11666);
    }
    _28403 = NOVALUE;
    _28405 = IS_ATOM(_28404);
    _28404 = NOVALUE;
    if (_28405 == 0)
    {
        _28405 = NOVALUE;
        goto L3; // [121] 162
    }
    else{
        _28405 = NOVALUE;
    }

    /** 		CompileErr(26, {arg, SymTab[subsym][S_NAME], SymTab[param][S_NAME]})*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _28406 = (int)*(((s1_ptr)_2)->base + _subsym_55338);
    _2 = (int)SEQ_PTR(_28406);
    if (!IS_ATOM_INT(_26S_NAME_11654)){
        _28407 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NAME_11654)->dbl));
    }
    else{
        _28407 = (int)*(((s1_ptr)_2)->base + _26S_NAME_11654);
    }
    _28406 = NOVALUE;
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _28408 = (int)*(((s1_ptr)_2)->base + _param_55343);
    _2 = (int)SEQ_PTR(_28408);
    if (!IS_ATOM_INT(_26S_NAME_11654)){
        _28409 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NAME_11654)->dbl));
    }
    else{
        _28409 = (int)*(((s1_ptr)_2)->base + _26S_NAME_11654);
    }
    _28408 = NOVALUE;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _arg_55339;
    Ref(_28407);
    *((int *)(_2+8)) = _28407;
    Ref(_28409);
    *((int *)(_2+12)) = _28409;
    _28410 = MAKE_SEQ(_1);
    _28409 = NOVALUE;
    _28407 = NOVALUE;
    _43CompileErr(26, _28410, 0);
    _28410 = NOVALUE;
L3: 

    /** 	use_private_list = 1*/
    _26use_private_list_12096 = 1;

    /** 	lock_scanner = 1*/
    _30lock_scanner_54879 = 1;

    /** 	start_playback(SymTab[param][S_CODE] )*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _28411 = (int)*(((s1_ptr)_2)->base + _param_55343);
    _2 = (int)SEQ_PTR(_28411);
    if (!IS_ATOM_INT(_26S_CODE_11666)){
        _28412 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_CODE_11666)->dbl));
    }
    else{
        _28412 = (int)*(((s1_ptr)_2)->base + _26S_CODE_11666);
    }
    _28411 = NOVALUE;
    Ref(_28412);
    _30start_playback(_28412);
    _28412 = NOVALUE;

    /** 	call_proc(forward_expr, {})*/
    _0 = (int)_00[_30forward_expr_55165].addr;
    (*(int (*)())_0)(
                         );

    /** 	add_private_symbol( Top(), SymTab[param][S_NAME] )*/
    _28413 = _37Top();
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _28414 = (int)*(((s1_ptr)_2)->base + _param_55343);
    _2 = (int)SEQ_PTR(_28414);
    if (!IS_ATOM_INT(_26S_NAME_11654)){
        _28415 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NAME_11654)->dbl));
    }
    else{
        _28415 = (int)*(((s1_ptr)_2)->base + _26S_NAME_11654);
    }
    _28414 = NOVALUE;
    Ref(_28415);
    _29add_private_symbol(_28413, _28415);
    _28413 = NOVALUE;
    _28415 = NOVALUE;

    /** 	lock_scanner = 0*/
    _30lock_scanner_54879 = 0;

    /** 	restore_parseargs_states()*/
    _30restore_parseargs_states();

    /** end procedure*/
    DeRefDS(_fwd_private_list_55340);
    DeRefDS(_fwd_private_sym_55341);
    return;
    ;
}


void _30ParseArgs(int _subsym_55388)
{
    int _n_55389 = NOVALUE;
    int _fda_55390 = NOVALUE;
    int _lnda_55391 = NOVALUE;
    int _tok_55393 = NOVALUE;
    int _s_55395 = NOVALUE;
    int _var_code_55396 = NOVALUE;
    int _name_55397 = NOVALUE;
    int _28509 = NOVALUE;
    int _28507 = NOVALUE;
    int _28503 = NOVALUE;
    int _28502 = NOVALUE;
    int _28501 = NOVALUE;
    int _28498 = NOVALUE;
    int _28495 = NOVALUE;
    int _28493 = NOVALUE;
    int _28491 = NOVALUE;
    int _28489 = NOVALUE;
    int _28487 = NOVALUE;
    int _28486 = NOVALUE;
    int _28485 = NOVALUE;
    int _28484 = NOVALUE;
    int _28483 = NOVALUE;
    int _28482 = NOVALUE;
    int _28481 = NOVALUE;
    int _28475 = NOVALUE;
    int _28473 = NOVALUE;
    int _28470 = NOVALUE;
    int _28467 = NOVALUE;
    int _28462 = NOVALUE;
    int _28460 = NOVALUE;
    int _28459 = NOVALUE;
    int _28458 = NOVALUE;
    int _28456 = NOVALUE;
    int _28453 = NOVALUE;
    int _28450 = NOVALUE;
    int _28448 = NOVALUE;
    int _28446 = NOVALUE;
    int _28444 = NOVALUE;
    int _28442 = NOVALUE;
    int _28441 = NOVALUE;
    int _28440 = NOVALUE;
    int _28439 = NOVALUE;
    int _28438 = NOVALUE;
    int _28437 = NOVALUE;
    int _28436 = NOVALUE;
    int _28434 = NOVALUE;
    int _28432 = NOVALUE;
    int _28428 = NOVALUE;
    int _28427 = NOVALUE;
    int _28425 = NOVALUE;
    int _28424 = NOVALUE;
    int _28422 = NOVALUE;
    int _28421 = NOVALUE;
    int _28420 = NOVALUE;
    int _28419 = NOVALUE;
    int _28418 = NOVALUE;
    int _28416 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_subsym_55388)) {
        _1 = (long)(DBL_PTR(_subsym_55388)->dbl);
        DeRefDS(_subsym_55388);
        _subsym_55388 = _1;
    }

    /** 	object var_code*/

    /** 	sequence name*/

    /** 	n = SymTab[subsym][S_NUM_ARGS]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _28416 = (int)*(((s1_ptr)_2)->base + _subsym_55388);
    _2 = (int)SEQ_PTR(_28416);
    if (!IS_ATOM_INT(_26S_NUM_ARGS_11705)){
        _n_55389 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NUM_ARGS_11705)->dbl));
    }
    else{
        _n_55389 = (int)*(((s1_ptr)_2)->base + _26S_NUM_ARGS_11705);
    }
    if (!IS_ATOM_INT(_n_55389)){
        _n_55389 = (long)DBL_PTR(_n_55389)->dbl;
    }
    _28416 = NOVALUE;

    /** 	if sequence(SymTab[subsym][S_DEF_ARGS]) then*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _28418 = (int)*(((s1_ptr)_2)->base + _subsym_55388);
    _2 = (int)SEQ_PTR(_28418);
    _28419 = (int)*(((s1_ptr)_2)->base + 28);
    _28418 = NOVALUE;
    _28420 = IS_SEQUENCE(_28419);
    _28419 = NOVALUE;
    if (_28420 == 0)
    {
        _28420 = NOVALUE;
        goto L1; // [40] 86
    }
    else{
        _28420 = NOVALUE;
    }

    /** 		fda = SymTab[subsym][S_DEF_ARGS][1]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _28421 = (int)*(((s1_ptr)_2)->base + _subsym_55388);
    _2 = (int)SEQ_PTR(_28421);
    _28422 = (int)*(((s1_ptr)_2)->base + 28);
    _28421 = NOVALUE;
    _2 = (int)SEQ_PTR(_28422);
    _fda_55390 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_fda_55390)){
        _fda_55390 = (long)DBL_PTR(_fda_55390)->dbl;
    }
    _28422 = NOVALUE;

    /** 		lnda = SymTab[subsym][S_DEF_ARGS][2]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _28424 = (int)*(((s1_ptr)_2)->base + _subsym_55388);
    _2 = (int)SEQ_PTR(_28424);
    _28425 = (int)*(((s1_ptr)_2)->base + 28);
    _28424 = NOVALUE;
    _2 = (int)SEQ_PTR(_28425);
    _lnda_55391 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_lnda_55391)){
        _lnda_55391 = (long)DBL_PTR(_lnda_55391)->dbl;
    }
    _28425 = NOVALUE;
    goto L2; // [83] 97
L1: 

    /** 		fda = 0*/
    _fda_55390 = 0;

    /** 		lnda = 0*/
    _lnda_55391 = 0;
L2: 

    /** 	s = subsym*/
    _s_55395 = _subsym_55388;

    /** 	parseargs_states = append(parseargs_states,*/
    if (IS_SEQUENCE(_30private_list_54878)){
            _28427 = SEQ_PTR(_30private_list_54878)->length;
    }
    else {
        _28427 = 1;
    }
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _28427;
    *((int *)(_2+8)) = _30lock_scanner_54879;
    *((int *)(_2+12)) = _26use_private_list_12096;
    *((int *)(_2+16)) = _30on_arg_54880;
    _28428 = MAKE_SEQ(_1);
    _28427 = NOVALUE;
    RefDS(_28428);
    Append(&_30parseargs_states_54873, _30parseargs_states_54873, _28428);
    DeRefDS(_28428);
    _28428 = NOVALUE;

    /** 	nested_calls &= subsym*/
    Append(&_30nested_calls_54881, _30nested_calls_54881, _subsym_55388);

    /** 	lock_scanner = 0*/
    _30lock_scanner_54879 = 0;

    /** 	on_arg = 0*/
    _30on_arg_54880 = 0;

    /** 	short_circuit -= 1*/
    _30short_circuit_54156 = _30short_circuit_54156 - 1;

    /** 	for i = 1 to n do*/
    _28432 = _n_55389;
    {
        int _i_55426;
        _i_55426 = 1;
L3: 
        if (_i_55426 > _28432){
            goto L4; // [161] 915
        }

        /** 	  	tok = next_token()*/
        _0 = _tok_55393;
        _tok_55393 = _30next_token();
        DeRef(_0);

        /** 		if tok[T_ID] = COMMA then*/
        _2 = (int)SEQ_PTR(_tok_55393);
        _28434 = (int)*(((s1_ptr)_2)->base + 1);
        if (binary_op_a(NOTEQ, _28434, -30)){
            _28434 = NOVALUE;
            goto L5; // [183] 392
        }
        _28434 = NOVALUE;

        /** 			if SymTab[subsym][S_OPCODE] then*/
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _28436 = (int)*(((s1_ptr)_2)->base + _subsym_55388);
        _2 = (int)SEQ_PTR(_28436);
        _28437 = (int)*(((s1_ptr)_2)->base + 21);
        _28436 = NOVALUE;
        if (_28437 == 0) {
            _28437 = NOVALUE;
            goto L6; // [201] 261
        }
        else {
            if (!IS_ATOM_INT(_28437) && DBL_PTR(_28437)->dbl == 0.0){
                _28437 = NOVALUE;
                goto L6; // [201] 261
            }
            _28437 = NOVALUE;
        }
        _28437 = NOVALUE;

        /** 				if atom(SymTab[subsym][S_CODE]) then*/
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _28438 = (int)*(((s1_ptr)_2)->base + _subsym_55388);
        _2 = (int)SEQ_PTR(_28438);
        if (!IS_ATOM_INT(_26S_CODE_11666)){
            _28439 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_CODE_11666)->dbl));
        }
        else{
            _28439 = (int)*(((s1_ptr)_2)->base + _26S_CODE_11666);
        }
        _28438 = NOVALUE;
        _28440 = IS_ATOM(_28439);
        _28439 = NOVALUE;
        if (_28440 == 0)
        {
            _28440 = NOVALUE;
            goto L7; // [221] 232
        }
        else{
            _28440 = NOVALUE;
        }

        /** 					var_code = 0*/
        DeRef(_var_code_55396);
        _var_code_55396 = 0;
        goto L8; // [229] 251
L7: 

        /** 					var_code = SymTab[subsym][S_CODE][i]*/
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _28441 = (int)*(((s1_ptr)_2)->base + _subsym_55388);
        _2 = (int)SEQ_PTR(_28441);
        if (!IS_ATOM_INT(_26S_CODE_11666)){
            _28442 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_CODE_11666)->dbl));
        }
        else{
            _28442 = (int)*(((s1_ptr)_2)->base + _26S_CODE_11666);
        }
        _28441 = NOVALUE;
        DeRef(_var_code_55396);
        _2 = (int)SEQ_PTR(_28442);
        _var_code_55396 = (int)*(((s1_ptr)_2)->base + _i_55426);
        Ref(_var_code_55396);
        _28442 = NOVALUE;
L8: 

        /** 				name = ""*/
        RefDS(_22037);
        DeRef(_name_55397);
        _name_55397 = _22037;
        goto L9; // [258] 308
L6: 

        /** 				s = SymTab[s][S_NEXT]*/
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _28444 = (int)*(((s1_ptr)_2)->base + _s_55395);
        _2 = (int)SEQ_PTR(_28444);
        _s_55395 = (int)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_s_55395)){
            _s_55395 = (long)DBL_PTR(_s_55395)->dbl;
        }
        _28444 = NOVALUE;

        /** 				var_code = SymTab[s][S_CODE]*/
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _28446 = (int)*(((s1_ptr)_2)->base + _s_55395);
        DeRef(_var_code_55396);
        _2 = (int)SEQ_PTR(_28446);
        if (!IS_ATOM_INT(_26S_CODE_11666)){
            _var_code_55396 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_CODE_11666)->dbl));
        }
        else{
            _var_code_55396 = (int)*(((s1_ptr)_2)->base + _26S_CODE_11666);
        }
        Ref(_var_code_55396);
        _28446 = NOVALUE;

        /** 				name = SymTab[s][S_NAME]*/
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _28448 = (int)*(((s1_ptr)_2)->base + _s_55395);
        DeRef(_name_55397);
        _2 = (int)SEQ_PTR(_28448);
        if (!IS_ATOM_INT(_26S_NAME_11654)){
            _name_55397 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NAME_11654)->dbl));
        }
        else{
            _name_55397 = (int)*(((s1_ptr)_2)->base + _26S_NAME_11654);
        }
        Ref(_name_55397);
        _28448 = NOVALUE;
L9: 

        /** 			if atom(var_code) then  -- but no default set*/
        _28450 = IS_ATOM(_var_code_55396);
        if (_28450 == 0)
        {
            _28450 = NOVALUE;
            goto LA; // [315] 326
        }
        else{
            _28450 = NOVALUE;
        }

        /** 				CompileErr(29,i)*/
        _43CompileErr(29, _i_55426, 0);
LA: 

        /** 			use_private_list = 1*/
        _26use_private_list_12096 = 1;

        /** 			start_playback(var_code)*/
        Ref(_var_code_55396);
        _30start_playback(_var_code_55396);

        /** 			lock_scanner=1*/
        _30lock_scanner_54879 = 1;

        /** 			Expr()*/
        _30Expr();

        /** 			lock_scanner=0*/
        _30lock_scanner_54879 = 0;

        /** 			on_arg += 1*/
        _30on_arg_54880 = _30on_arg_54880 + 1;

        /** 			private_list = append(private_list,name)*/
        RefDS(_name_55397);
        Append(&_30private_list_54878, _30private_list_54878, _name_55397);

        /** 			private_sym &= Top()*/
        _28453 = _37Top();
        if (IS_SEQUENCE(_26private_sym_12095) && IS_ATOM(_28453)) {
            Ref(_28453);
            Append(&_26private_sym_12095, _26private_sym_12095, _28453);
        }
        else if (IS_ATOM(_26private_sym_12095) && IS_SEQUENCE(_28453)) {
        }
        else {
            Concat((object_ptr)&_26private_sym_12095, _26private_sym_12095, _28453);
        }
        DeRef(_28453);
        _28453 = NOVALUE;

        /** 			backed_up_tok = {tok} -- ????*/
        _0 = _30backed_up_tok_54163;
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        Ref(_tok_55393);
        *((int *)(_2+4)) = _tok_55393;
        _30backed_up_tok_54163 = MAKE_SEQ(_1);
        DeRef(_0);
        goto LB; // [389] 520
L5: 

        /** 		elsif tok[T_ID] != RIGHT_ROUND then*/
        _2 = (int)SEQ_PTR(_tok_55393);
        _28456 = (int)*(((s1_ptr)_2)->base + 1);
        if (binary_op_a(EQUALS, _28456, -27)){
            _28456 = NOVALUE;
            goto LC; // [402] 519
        }
        _28456 = NOVALUE;

        /** 			if SymTab[subsym][S_OPCODE] then*/
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _28458 = (int)*(((s1_ptr)_2)->base + _subsym_55388);
        _2 = (int)SEQ_PTR(_28458);
        _28459 = (int)*(((s1_ptr)_2)->base + 21);
        _28458 = NOVALUE;
        if (_28459 == 0) {
            _28459 = NOVALUE;
            goto LD; // [420] 433
        }
        else {
            if (!IS_ATOM_INT(_28459) && DBL_PTR(_28459)->dbl == 0.0){
                _28459 = NOVALUE;
                goto LD; // [420] 433
            }
            _28459 = NOVALUE;
        }
        _28459 = NOVALUE;

        /** 				name = ""*/
        RefDS(_22037);
        DeRef(_name_55397);
        _name_55397 = _22037;
        goto LE; // [430] 466
LD: 

        /** 				s = SymTab[s][S_NEXT]*/
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _28460 = (int)*(((s1_ptr)_2)->base + _s_55395);
        _2 = (int)SEQ_PTR(_28460);
        _s_55395 = (int)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_s_55395)){
            _s_55395 = (long)DBL_PTR(_s_55395)->dbl;
        }
        _28460 = NOVALUE;

        /** 				name = SymTab[s][S_NAME]*/
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _28462 = (int)*(((s1_ptr)_2)->base + _s_55395);
        DeRef(_name_55397);
        _2 = (int)SEQ_PTR(_28462);
        if (!IS_ATOM_INT(_26S_NAME_11654)){
            _name_55397 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NAME_11654)->dbl));
        }
        else{
            _name_55397 = (int)*(((s1_ptr)_2)->base + _26S_NAME_11654);
        }
        Ref(_name_55397);
        _28462 = NOVALUE;
LE: 

        /** 			use_private_list = Parser_mode != PAM_NORMAL*/
        _26use_private_list_12096 = (_26Parser_mode_12088 != 0);

        /** 			putback(tok)*/
        Ref(_tok_55393);
        _30putback(_tok_55393);

        /** 			Expr()*/
        _30Expr();

        /** 			on_arg += 1*/
        _30on_arg_54880 = _30on_arg_54880 + 1;

        /** 			private_list = append(private_list,name)*/
        RefDS(_name_55397);
        Append(&_30private_list_54878, _30private_list_54878, _name_55397);

        /** 			private_sym &= Top()*/
        _28467 = _37Top();
        if (IS_SEQUENCE(_26private_sym_12095) && IS_ATOM(_28467)) {
            Ref(_28467);
            Append(&_26private_sym_12095, _26private_sym_12095, _28467);
        }
        else if (IS_ATOM(_26private_sym_12095) && IS_SEQUENCE(_28467)) {
        }
        else {
            Concat((object_ptr)&_26private_sym_12095, _26private_sym_12095, _28467);
        }
        DeRef(_28467);
        _28467 = NOVALUE;
LC: 
LB: 

        /** 		if on_arg != n then*/
        if (_30on_arg_54880 == _n_55389)
        goto LF; // [524] 908

        /** 			if tok[T_ID] = RIGHT_ROUND then*/
        _2 = (int)SEQ_PTR(_tok_55393);
        _28470 = (int)*(((s1_ptr)_2)->base + 1);
        if (binary_op_a(NOTEQ, _28470, -27)){
            _28470 = NOVALUE;
            goto L10; // [538] 548
        }
        _28470 = NOVALUE;

        /** 				putback( tok )*/
        Ref(_tok_55393);
        _30putback(_tok_55393);
L10: 

        /** 			tok = next_token()*/
        _0 = _tok_55393;
        _tok_55393 = _30next_token();
        DeRef(_0);

        /** 			if tok[T_ID] != COMMA then*/
        _2 = (int)SEQ_PTR(_tok_55393);
        _28473 = (int)*(((s1_ptr)_2)->base + 1);
        if (binary_op_a(EQUALS, _28473, -30)){
            _28473 = NOVALUE;
            goto L11; // [563] 907
        }
        _28473 = NOVALUE;

        /** 		  		if tok[T_ID] = RIGHT_ROUND then*/
        _2 = (int)SEQ_PTR(_tok_55393);
        _28475 = (int)*(((s1_ptr)_2)->base + 1);
        if (binary_op_a(NOTEQ, _28475, -27)){
            _28475 = NOVALUE;
            goto L12; // [577] 892
        }
        _28475 = NOVALUE;

        /** 					if fda=0 then*/
        if (_fda_55390 != 0)
        goto L13; // [585] 598

        /** 						WrongNumberArgs(subsym, "")*/
        RefDS(_22037);
        _30WrongNumberArgs(_subsym_55388, _22037);
        goto L14; // [595] 613
L13: 

        /** 					elsif i<lnda then*/
        if (_i_55426 >= _lnda_55391)
        goto L15; // [602] 612

        /** 						MissingArgs(subsym)*/
        _30MissingArgs(_subsym_55388);
L15: 
L14: 

        /** 					lock_scanner = 1*/
        _30lock_scanner_54879 = 1;

        /** 					use_private_list = 1*/
        _26use_private_list_12096 = 1;

        /** 					while on_arg < n do*/
L16: 
        if (_30on_arg_54880 >= _n_55389)
        goto L17; // [632] 841

        /** 						on_arg += 1*/
        _30on_arg_54880 = _30on_arg_54880 + 1;

        /** 						if SymTab[subsym][S_OPCODE] then*/
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _28481 = (int)*(((s1_ptr)_2)->base + _subsym_55388);
        _2 = (int)SEQ_PTR(_28481);
        _28482 = (int)*(((s1_ptr)_2)->base + 21);
        _28481 = NOVALUE;
        if (_28482 == 0) {
            _28482 = NOVALUE;
            goto L18; // [658] 720
        }
        else {
            if (!IS_ATOM_INT(_28482) && DBL_PTR(_28482)->dbl == 0.0){
                _28482 = NOVALUE;
                goto L18; // [658] 720
            }
            _28482 = NOVALUE;
        }
        _28482 = NOVALUE;

        /** 							if atom(SymTab[subsym][S_CODE]) then*/
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _28483 = (int)*(((s1_ptr)_2)->base + _subsym_55388);
        _2 = (int)SEQ_PTR(_28483);
        if (!IS_ATOM_INT(_26S_CODE_11666)){
            _28484 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_CODE_11666)->dbl));
        }
        else{
            _28484 = (int)*(((s1_ptr)_2)->base + _26S_CODE_11666);
        }
        _28483 = NOVALUE;
        _28485 = IS_ATOM(_28484);
        _28484 = NOVALUE;
        if (_28485 == 0)
        {
            _28485 = NOVALUE;
            goto L19; // [678] 689
        }
        else{
            _28485 = NOVALUE;
        }

        /** 								var_code = 0*/
        DeRef(_var_code_55396);
        _var_code_55396 = 0;
        goto L1A; // [686] 710
L19: 

        /** 								var_code = SymTab[subsym][S_CODE][on_arg]*/
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _28486 = (int)*(((s1_ptr)_2)->base + _subsym_55388);
        _2 = (int)SEQ_PTR(_28486);
        if (!IS_ATOM_INT(_26S_CODE_11666)){
            _28487 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_CODE_11666)->dbl));
        }
        else{
            _28487 = (int)*(((s1_ptr)_2)->base + _26S_CODE_11666);
        }
        _28486 = NOVALUE;
        DeRef(_var_code_55396);
        _2 = (int)SEQ_PTR(_28487);
        _var_code_55396 = (int)*(((s1_ptr)_2)->base + _30on_arg_54880);
        Ref(_var_code_55396);
        _28487 = NOVALUE;
L1A: 

        /** 							name = ""*/
        RefDS(_22037);
        DeRef(_name_55397);
        _name_55397 = _22037;
        goto L1B; // [717] 767
L18: 

        /** 							s = SymTab[s][S_NEXT]*/
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _28489 = (int)*(((s1_ptr)_2)->base + _s_55395);
        _2 = (int)SEQ_PTR(_28489);
        _s_55395 = (int)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_s_55395)){
            _s_55395 = (long)DBL_PTR(_s_55395)->dbl;
        }
        _28489 = NOVALUE;

        /** 							var_code = SymTab[s][S_CODE]*/
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _28491 = (int)*(((s1_ptr)_2)->base + _s_55395);
        DeRef(_var_code_55396);
        _2 = (int)SEQ_PTR(_28491);
        if (!IS_ATOM_INT(_26S_CODE_11666)){
            _var_code_55396 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_CODE_11666)->dbl));
        }
        else{
            _var_code_55396 = (int)*(((s1_ptr)_2)->base + _26S_CODE_11666);
        }
        Ref(_var_code_55396);
        _28491 = NOVALUE;

        /** 							name = SymTab[s][S_NAME]*/
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _28493 = (int)*(((s1_ptr)_2)->base + _s_55395);
        DeRef(_name_55397);
        _2 = (int)SEQ_PTR(_28493);
        if (!IS_ATOM_INT(_26S_NAME_11654)){
            _name_55397 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NAME_11654)->dbl));
        }
        else{
            _name_55397 = (int)*(((s1_ptr)_2)->base + _26S_NAME_11654);
        }
        Ref(_name_55397);
        _28493 = NOVALUE;
L1B: 

        /** 						if sequence(var_code) then*/
        _28495 = IS_SEQUENCE(_var_code_55396);
        if (_28495 == 0)
        {
            _28495 = NOVALUE;
            goto L1C; // [774] 826
        }
        else{
            _28495 = NOVALUE;
        }

        /** 							putback( tok )*/
        Ref(_tok_55393);
        _30putback(_tok_55393);

        /** 							start_playback(var_code)*/
        Ref(_var_code_55396);
        _30start_playback(_var_code_55396);

        /** 							Expr()*/
        _30Expr();

        /** 							if on_arg < n then*/
        if (_30on_arg_54880 >= _n_55389)
        goto L16; // [795] 630

        /** 								private_list = append(private_list,name)*/
        RefDS(_name_55397);
        Append(&_30private_list_54878, _30private_list_54878, _name_55397);

        /** 								private_sym &= Top()*/
        _28498 = _37Top();
        if (IS_SEQUENCE(_26private_sym_12095) && IS_ATOM(_28498)) {
            Ref(_28498);
            Append(&_26private_sym_12095, _26private_sym_12095, _28498);
        }
        else if (IS_ATOM(_26private_sym_12095) && IS_SEQUENCE(_28498)) {
        }
        else {
            Concat((object_ptr)&_26private_sym_12095, _26private_sym_12095, _28498);
        }
        DeRef(_28498);
        _28498 = NOVALUE;
        goto L16; // [823] 630
L1C: 

        /** 							CompileErr(29, on_arg)*/
        _43CompileErr(29, _30on_arg_54880, 0);

        /** 		  		    end while*/
        goto L16; // [838] 630
L17: 

        /** 					short_circuit += 1*/
        _30short_circuit_54156 = _30short_circuit_54156 + 1;

        /** 					if backed_up_tok[$][T_ID] = PLAYBACK_ENDS then*/
        if (IS_SEQUENCE(_30backed_up_tok_54163)){
                _28501 = SEQ_PTR(_30backed_up_tok_54163)->length;
        }
        else {
            _28501 = 1;
        }
        _2 = (int)SEQ_PTR(_30backed_up_tok_54163);
        _28502 = (int)*(((s1_ptr)_2)->base + _28501);
        _2 = (int)SEQ_PTR(_28502);
        _28503 = (int)*(((s1_ptr)_2)->base + 1);
        _28502 = NOVALUE;
        if (binary_op_a(NOTEQ, _28503, 505)){
            _28503 = NOVALUE;
            goto L1D; // [868] 880
        }
        _28503 = NOVALUE;

        /** 						backed_up_tok = {}*/
        RefDS(_22037);
        DeRefDS(_30backed_up_tok_54163);
        _30backed_up_tok_54163 = _22037;
L1D: 

        /** 					restore_parseargs_states()*/
        _30restore_parseargs_states();

        /** 					return*/
        DeRef(_tok_55393);
        DeRef(_var_code_55396);
        DeRef(_name_55397);
        return;
        goto L1E; // [889] 906
L12: 

        /** 					putback(tok)*/
        Ref(_tok_55393);
        _30putback(_tok_55393);

        /** 					tok_match(COMMA)*/
        _30tok_match(-30, 0);
L1E: 
L11: 
LF: 

        /** 	end for*/
        _i_55426 = _i_55426 + 1;
        goto L3; // [910] 168
L4: 
        ;
    }

    /** 	tok = next_token()*/
    _0 = _tok_55393;
    _tok_55393 = _30next_token();
    DeRef(_0);

    /** 	short_circuit += 1*/
    _30short_circuit_54156 = _30short_circuit_54156 + 1;

    /** 	if tok[T_ID] != RIGHT_ROUND then*/
    _2 = (int)SEQ_PTR(_tok_55393);
    _28507 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _28507, -27)){
        _28507 = NOVALUE;
        goto L1F; // [938] 980
    }
    _28507 = NOVALUE;

    /** 		if tok[T_ID] = COMMA then*/
    _2 = (int)SEQ_PTR(_tok_55393);
    _28509 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28509, -30)){
        _28509 = NOVALUE;
        goto L20; // [952] 965
    }
    _28509 = NOVALUE;

    /** 			WrongNumberArgs(subsym, "only ")*/
    RefDS(_28511);
    _30WrongNumberArgs(_subsym_55388, _28511);
    goto L21; // [962] 979
L20: 

    /** 			putback(tok)*/
    Ref(_tok_55393);
    _30putback(_tok_55393);

    /** 			tok_match(RIGHT_ROUND)*/
    _30tok_match(-27, 0);
L21: 
L1F: 

    /** 	restore_parseargs_states()*/
    _30restore_parseargs_states();

    /** end procedure*/
    DeRef(_tok_55393);
    DeRef(_var_code_55396);
    DeRef(_name_55397);
    return;
    ;
}


void _30Forward_var(int _tok_55602, int _init_check_55603, int _op_55604)
{
    int _ref_55608 = NOVALUE;
    int _28515 = NOVALUE;
    int _28513 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_op_55604)) {
        _1 = (long)(DBL_PTR(_op_55604)->dbl);
        DeRefDS(_op_55604);
        _op_55604 = _1;
    }

    /** 	ref = new_forward_reference( VARIABLE, tok[T_SYM], op )*/
    _2 = (int)SEQ_PTR(_tok_55602);
    _28513 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_28513);
    _ref_55608 = _29new_forward_reference(-100, _28513, _op_55604);
    _28513 = NOVALUE;
    if (!IS_ATOM_INT(_ref_55608)) {
        _1 = (long)(DBL_PTR(_ref_55608)->dbl);
        DeRefDS(_ref_55608);
        _ref_55608 = _1;
    }

    /** 	emit_opnd( - ref )*/
    if ((unsigned long)_ref_55608 == 0xC0000000)
    _28515 = (int)NewDouble((double)-0xC0000000);
    else
    _28515 = - _ref_55608;
    _37emit_opnd(_28515);
    _28515 = NOVALUE;

    /** 	if init_check != -1 then*/
    if (_init_check_55603 == -1)
    goto L1; // [33] 44

    /** 		Forward_InitCheck( tok, init_check )*/
    Ref(_tok_55602);
    _30Forward_InitCheck(_tok_55602, _init_check_55603);
L1: 

    /** end procedure*/
    DeRef(_tok_55602);
    return;
    ;
}


void _30Forward_call(int _tok_55621, int _opcode_55622)
{
    int _args_55625 = NOVALUE;
    int _proc_55627 = NOVALUE;
    int _tok_id_55630 = NOVALUE;
    int _id_55637 = NOVALUE;
    int _fc_pc_55660 = NOVALUE;
    int _28534 = NOVALUE;
    int _28533 = NOVALUE;
    int _28530 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer args = 0*/
    _args_55625 = 0;

    /** 	symtab_index proc = tok[T_SYM]*/
    _2 = (int)SEQ_PTR(_tok_55621);
    _proc_55627 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_proc_55627)){
        _proc_55627 = (long)DBL_PTR(_proc_55627)->dbl;
    }

    /** 	integer tok_id = tok[T_ID]*/
    _2 = (int)SEQ_PTR(_tok_55621);
    _tok_id_55630 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_tok_id_55630)){
        _tok_id_55630 = (long)DBL_PTR(_tok_id_55630)->dbl;
    }

    /** 	remove_symbol( proc )*/
    _52remove_symbol(_proc_55627);

    /** 	short_circuit -= 1*/
    _30short_circuit_54156 = _30short_circuit_54156 - 1;

    /** 	while 1 do*/
L1: 

    /** 		tok = next_token()*/
    _0 = _tok_55621;
    _tok_55621 = _30next_token();
    DeRef(_0);

    /** 		integer id = tok[T_ID]*/
    _2 = (int)SEQ_PTR(_tok_55621);
    _id_55637 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_id_55637)){
        _id_55637 = (long)DBL_PTR(_id_55637)->dbl;
    }

    /** 		switch id do*/
    _0 = _id_55637;
    switch ( _0 ){ 

        /** 			case COMMA then*/
        case -30:

        /** 				emit_opnd( 0 ) -- clean this up later*/
        _37emit_opnd(0);

        /** 				args += 1*/
        _args_55625 = _args_55625 + 1;
        goto L2; // [83] 166

        /** 			case RIGHT_ROUND then*/
        case -27:

        /** 				exit*/
        goto L3; // [93] 173
        goto L2; // [95] 166

        /** 			case else*/
        default:

        /** 				putback( tok )*/
        Ref(_tok_55621);
        _30putback(_tok_55621);

        /** 				call_proc( forward_expr, {} )*/
        _0 = (int)_00[_30forward_expr_55165].addr;
        (*(int (*)())_0)(
                             );

        /** 				args += 1*/
        _args_55625 = _args_55625 + 1;

        /** 				tok = next_token()*/
        _0 = _tok_55621;
        _tok_55621 = _30next_token();
        DeRef(_0);

        /** 				id = tok[T_ID]*/
        _2 = (int)SEQ_PTR(_tok_55621);
        _id_55637 = (int)*(((s1_ptr)_2)->base + 1);
        if (!IS_ATOM_INT(_id_55637)){
            _id_55637 = (long)DBL_PTR(_id_55637)->dbl;
        }

        /** 				if id = RIGHT_ROUND then*/
        if (_id_55637 != -27)
        goto L4; // [138] 149

        /** 					exit*/
        goto L3; // [146] 173
L4: 

        /** 				if id != COMMA then*/
        if (_id_55637 == -30)
        goto L5; // [153] 165

        /** 						CompileErr(69)*/
        RefDS(_22037);
        _43CompileErr(69, _22037, 0);
L5: 
    ;}L2: 

    /** 	end while*/
    goto L1; // [170] 46
L3: 

    /** 	integer fc_pc = length( Code ) + 1*/
    if (IS_SEQUENCE(_26Code_12071)){
            _28530 = SEQ_PTR(_26Code_12071)->length;
    }
    else {
        _28530 = 1;
    }
    _fc_pc_55660 = _28530 + 1;
    _28530 = NOVALUE;

    /** 	emit_opnd( args )*/
    _37emit_opnd(_args_55625);

    /** 	op_info1 = proc*/
    _37op_info1_50262 = _proc_55627;

    /** 	if tok_id = QUALIFIED_VARIABLE then*/
    if (_tok_id_55630 != 512)
    goto L6; // [200] 224

    /** 		set_qualified_fwd( SymTab[proc][S_FILE_NO] )*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _28533 = (int)*(((s1_ptr)_2)->base + _proc_55627);
    _2 = (int)SEQ_PTR(_28533);
    if (!IS_ATOM_INT(_26S_FILE_NO_11650)){
        _28534 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_FILE_NO_11650)->dbl));
    }
    else{
        _28534 = (int)*(((s1_ptr)_2)->base + _26S_FILE_NO_11650);
    }
    _28533 = NOVALUE;
    Ref(_28534);
    _60set_qualified_fwd(_28534);
    _28534 = NOVALUE;
    goto L7; // [221] 230
L6: 

    /** 		set_qualified_fwd( -1 )*/
    _60set_qualified_fwd(-1);
L7: 

    /** 	emit_op( opcode )*/
    _37emit_op(_opcode_55622);

    /** 	if not TRANSLATE then*/
    if (_26TRANSLATE_11619 != 0)
    goto L8; // [239] 258

    /** 		if OpTrace then*/
    if (_26OpTrace_12052 == 0)
    {
        goto L9; // [246] 257
    }
    else{
    }

    /** 			emit_op(UPDATE_GLOBALS)*/
    _37emit_op(89);
L9: 
L8: 

    /** 	short_circuit += 1*/
    _30short_circuit_54156 = _30short_circuit_54156 + 1;

    /** end procedure*/
    DeRef(_tok_55621);
    return;
    ;
}


void _30Object_call(int _tok_55688)
{
    int _tok2_55690 = NOVALUE;
    int _tok3_55691 = NOVALUE;
    int _save_factors_55692 = NOVALUE;
    int _save_lhs_subs_level_55693 = NOVALUE;
    int _sym_55695 = NOVALUE;
    int _28594 = NOVALUE;
    int _28592 = NOVALUE;
    int _28591 = NOVALUE;
    int _28588 = NOVALUE;
    int _28587 = NOVALUE;
    int _28583 = NOVALUE;
    int _28577 = NOVALUE;
    int _28574 = NOVALUE;
    int _28573 = NOVALUE;
    int _28572 = NOVALUE;
    int _28570 = NOVALUE;
    int _28569 = NOVALUE;
    int _28567 = NOVALUE;
    int _28566 = NOVALUE;
    int _28563 = NOVALUE;
    int _28562 = NOVALUE;
    int _28561 = NOVALUE;
    int _28559 = NOVALUE;
    int _28558 = NOVALUE;
    int _28556 = NOVALUE;
    int _28555 = NOVALUE;
    int _28554 = NOVALUE;
    int _28553 = NOVALUE;
    int _28551 = NOVALUE;
    int _28550 = NOVALUE;
    int _28548 = NOVALUE;
    int _28547 = NOVALUE;
    int _28544 = NOVALUE;
    int _28542 = NOVALUE;
    int _28541 = NOVALUE;
    int _28539 = NOVALUE;
    int _28538 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	integer save_factors, save_lhs_subs_level*/

    /** 	tok2 = next_token()*/
    _0 = _tok2_55690;
    _tok2_55690 = _30next_token();
    DeRef(_0);

    /** 	if tok2[T_ID] = VARIABLE or tok2[T_ID] = QUALIFIED_VARIABLE then*/
    _2 = (int)SEQ_PTR(_tok2_55690);
    _28538 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_28538)) {
        _28539 = (_28538 == -100);
    }
    else {
        _28539 = binary_op(EQUALS, _28538, -100);
    }
    _28538 = NOVALUE;
    if (IS_ATOM_INT(_28539)) {
        if (_28539 != 0) {
            goto L1; // [22] 43
        }
    }
    else {
        if (DBL_PTR(_28539)->dbl != 0.0) {
            goto L1; // [22] 43
        }
    }
    _2 = (int)SEQ_PTR(_tok2_55690);
    _28541 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_28541)) {
        _28542 = (_28541 == 512);
    }
    else {
        _28542 = binary_op(EQUALS, _28541, 512);
    }
    _28541 = NOVALUE;
    if (_28542 == 0) {
        DeRef(_28542);
        _28542 = NOVALUE;
        goto L2; // [39] 586
    }
    else {
        if (!IS_ATOM_INT(_28542) && DBL_PTR(_28542)->dbl == 0.0){
            DeRef(_28542);
            _28542 = NOVALUE;
            goto L2; // [39] 586
        }
        DeRef(_28542);
        _28542 = NOVALUE;
    }
    DeRef(_28542);
    _28542 = NOVALUE;
L1: 

    /** 		tok3 = next_token()*/
    _0 = _tok3_55691;
    _tok3_55691 = _30next_token();
    DeRef(_0);

    /** 		if tok3[T_ID] = RIGHT_ROUND then*/
    _2 = (int)SEQ_PTR(_tok3_55691);
    _28544 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28544, -27)){
        _28544 = NOVALUE;
        goto L3; // [58] 155
    }
    _28544 = NOVALUE;

    /** 			sym = tok2[T_SYM]*/
    _2 = (int)SEQ_PTR(_tok2_55690);
    _sym_55695 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_sym_55695)){
        _sym_55695 = (long)DBL_PTR(_sym_55695)->dbl;
    }

    /** 			if SymTab[sym][S_SCOPE] = SC_UNDEFINED then*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _28547 = (int)*(((s1_ptr)_2)->base + _sym_55695);
    _2 = (int)SEQ_PTR(_28547);
    _28548 = (int)*(((s1_ptr)_2)->base + 4);
    _28547 = NOVALUE;
    if (binary_op_a(NOTEQ, _28548, 9)){
        _28548 = NOVALUE;
        goto L4; // [88] 108
    }
    _28548 = NOVALUE;

    /** 				Forward_var( tok2 )*/
    _2 = (int)SEQ_PTR(_tok2_55690);
    _28550 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_tok2_55690);
    Ref(_28550);
    _30Forward_var(_tok2_55690, -1, _28550);
    _28550 = NOVALUE;
    goto L5; // [105] 147
L4: 

    /** 				SymTab[sym][S_USAGE] = or_bits(SymTab[sym][S_USAGE], U_READ)*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_55695 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _28553 = (int)*(((s1_ptr)_2)->base + _sym_55695);
    _2 = (int)SEQ_PTR(_28553);
    _28554 = (int)*(((s1_ptr)_2)->base + 5);
    _28553 = NOVALUE;
    if (IS_ATOM_INT(_28554)) {
        {unsigned long tu;
             tu = (unsigned long)_28554 | (unsigned long)1;
             _28555 = MAKE_UINT(tu);
        }
    }
    else {
        _28555 = binary_op(OR_BITS, _28554, 1);
    }
    _28554 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = _28555;
    if( _1 != _28555 ){
        DeRef(_1);
    }
    _28555 = NOVALUE;
    _28551 = NOVALUE;

    /** 				emit_opnd(sym)*/
    _37emit_opnd(_sym_55695);
L5: 

    /** 			putback( tok3 )*/
    Ref(_tok3_55691);
    _30putback(_tok3_55691);
    goto L6; // [152] 575
L3: 

    /** 		elsif tok3[T_ID] = COMMA then*/
    _2 = (int)SEQ_PTR(_tok3_55691);
    _28556 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28556, -30)){
        _28556 = NOVALUE;
        goto L7; // [165] 184
    }
    _28556 = NOVALUE;

    /** 			WrongNumberArgs(tok[T_SYM], "")*/
    _2 = (int)SEQ_PTR(_tok_55688);
    _28558 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_28558);
    RefDS(_22037);
    _30WrongNumberArgs(_28558, _22037);
    _28558 = NOVALUE;
    goto L6; // [181] 575
L7: 

    /** 		elsif tok3[T_ID] = LEFT_ROUND then*/
    _2 = (int)SEQ_PTR(_tok3_55691);
    _28559 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28559, -26)){
        _28559 = NOVALUE;
        goto L8; // [194] 244
    }
    _28559 = NOVALUE;

    /** 			if SymTab[tok2[T_SYM]][S_SCOPE] = SC_UNDEFINED then*/
    _2 = (int)SEQ_PTR(_tok2_55690);
    _28561 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!IS_ATOM_INT(_28561)){
        _28562 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_28561)->dbl));
    }
    else{
        _28562 = (int)*(((s1_ptr)_2)->base + _28561);
    }
    _2 = (int)SEQ_PTR(_28562);
    _28563 = (int)*(((s1_ptr)_2)->base + 4);
    _28562 = NOVALUE;
    if (binary_op_a(NOTEQ, _28563, 9)){
        _28563 = NOVALUE;
        goto L9; // [220] 235
    }
    _28563 = NOVALUE;

    /** 				Forward_call( tok2, FUNC_FORWARD )*/
    Ref(_tok2_55690);
    _30Forward_call(_tok2_55690, 196);
    goto L6; // [232] 575
L9: 

    /** 				Function_call( tok2 )*/
    Ref(_tok2_55690);
    _30Function_call(_tok2_55690);
    goto L6; // [241] 575
L8: 

    /** 			sym = tok2[T_SYM]*/
    _2 = (int)SEQ_PTR(_tok2_55690);
    _sym_55695 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_sym_55695)){
        _sym_55695 = (long)DBL_PTR(_sym_55695)->dbl;
    }

    /** 			if SymTab[sym][S_SCOPE] = SC_UNDEFINED then*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _28566 = (int)*(((s1_ptr)_2)->base + _sym_55695);
    _2 = (int)SEQ_PTR(_28566);
    _28567 = (int)*(((s1_ptr)_2)->base + 4);
    _28566 = NOVALUE;
    if (binary_op_a(NOTEQ, _28567, 9)){
        _28567 = NOVALUE;
        goto LA; // [270] 292
    }
    _28567 = NOVALUE;

    /** 				Forward_var( tok2, TRUE )*/
    _2 = (int)SEQ_PTR(_tok2_55690);
    _28569 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_tok2_55690);
    Ref(_28569);
    _30Forward_var(_tok2_55690, _9TRUE_430, _28569);
    _28569 = NOVALUE;
    goto LB; // [289] 339
LA: 

    /** 				SymTab[sym][S_USAGE] = or_bits(SymTab[sym][S_USAGE], U_READ)*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_55695 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _28572 = (int)*(((s1_ptr)_2)->base + _sym_55695);
    _2 = (int)SEQ_PTR(_28572);
    _28573 = (int)*(((s1_ptr)_2)->base + 5);
    _28572 = NOVALUE;
    if (IS_ATOM_INT(_28573)) {
        {unsigned long tu;
             tu = (unsigned long)_28573 | (unsigned long)1;
             _28574 = MAKE_UINT(tu);
        }
    }
    else {
        _28574 = binary_op(OR_BITS, _28573, 1);
    }
    _28573 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = _28574;
    if( _1 != _28574 ){
        DeRef(_1);
    }
    _28574 = NOVALUE;
    _28570 = NOVALUE;

    /** 				InitCheck(sym, TRUE)*/
    _30InitCheck(_sym_55695, _9TRUE_430);

    /** 				emit_opnd(sym)*/
    _37emit_opnd(_sym_55695);
LB: 

    /** 			if sym = left_sym then*/
    if (_sym_55695 != _30left_sym_54197)
    goto LC; // [343] 353

    /** 				lhs_subs_level = 0*/
    _30lhs_subs_level_54195 = 0;
LC: 

    /** 			tok2 = tok3*/
    Ref(_tok3_55691);
    DeRef(_tok2_55690);
    _tok2_55690 = _tok3_55691;

    /** 			current_sequence = append(current_sequence, sym)*/
    Append(&_37current_sequence_50270, _37current_sequence_50270, _sym_55695);

    /** 			while tok2[T_ID] = LEFT_SQUARE do*/
LD: 
    _2 = (int)SEQ_PTR(_tok2_55690);
    _28577 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28577, -28)){
        _28577 = NOVALUE;
        goto LE; // [381] 551
    }
    _28577 = NOVALUE;

    /** 				subs_depth += 1*/
    _30subs_depth_54198 = _30subs_depth_54198 + 1;

    /** 				if lhs_subs_level >= 0 then*/
    if (_30lhs_subs_level_54195 < 0)
    goto LF; // [397] 410

    /** 					lhs_subs_level += 1*/
    _30lhs_subs_level_54195 = _30lhs_subs_level_54195 + 1;
LF: 

    /** 				save_factors = factors*/
    _save_factors_55692 = _30factors_54194;

    /** 				save_lhs_subs_level = lhs_subs_level*/
    _save_lhs_subs_level_55693 = _30lhs_subs_level_54195;

    /** 				call_proc(forward_expr, {})*/
    _0 = (int)_00[_30forward_expr_55165].addr;
    (*(int (*)())_0)(
                         );

    /** 				tok2 = next_token()*/
    _0 = _tok2_55690;
    _tok2_55690 = _30next_token();
    DeRef(_0);

    /** 				if tok2[T_ID] = SLICE then*/
    _2 = (int)SEQ_PTR(_tok2_55690);
    _28583 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28583, 513)){
        _28583 = NOVALUE;
        goto L10; // [446] 484
    }
    _28583 = NOVALUE;

    /** 					call_proc(forward_expr, {})*/
    _0 = (int)_00[_30forward_expr_55165].addr;
    (*(int (*)())_0)(
                         );

    /** 					emit_op(RHS_SLICE)*/
    _37emit_op(46);

    /** 					tok_match(RIGHT_SQUARE)*/
    _30tok_match(-29, 0);

    /** 					tok2 = next_token()*/
    _0 = _tok2_55690;
    _tok2_55690 = _30next_token();
    DeRef(_0);

    /** 					exit*/
    goto LE; // [479] 551
    goto L11; // [481] 531
L10: 

    /** 					putback(tok2)*/
    Ref(_tok2_55690);
    _30putback(_tok2_55690);

    /** 					tok_match(RIGHT_SQUARE)*/
    _30tok_match(-29, 0);

    /** 					subs_depth -= 1*/
    _30subs_depth_54198 = _30subs_depth_54198 - 1;

    /** 					current_sequence = current_sequence[1..$-1]*/
    if (IS_SEQUENCE(_37current_sequence_50270)){
            _28587 = SEQ_PTR(_37current_sequence_50270)->length;
    }
    else {
        _28587 = 1;
    }
    _28588 = _28587 - 1;
    _28587 = NOVALUE;
    rhs_slice_target = (object_ptr)&_37current_sequence_50270;
    RHS_Slice(_37current_sequence_50270, 1, _28588);

    /** 					emit_op(RHS_SUBS)*/
    _37emit_op(25);
L11: 

    /** 				factors = save_factors*/
    _30factors_54194 = _save_factors_55692;

    /** 				lhs_subs_level = save_lhs_subs_level*/
    _30lhs_subs_level_54195 = _save_lhs_subs_level_55693;

    /** 				tok2 = next_token()*/
    _0 = _tok2_55690;
    _tok2_55690 = _30next_token();
    DeRef(_0);

    /** 			end while*/
    goto LD; // [548] 373
LE: 

    /** 			current_sequence = current_sequence[1..$-1]*/
    if (IS_SEQUENCE(_37current_sequence_50270)){
            _28591 = SEQ_PTR(_37current_sequence_50270)->length;
    }
    else {
        _28591 = 1;
    }
    _28592 = _28591 - 1;
    _28591 = NOVALUE;
    rhs_slice_target = (object_ptr)&_37current_sequence_50270;
    RHS_Slice(_37current_sequence_50270, 1, _28592);

    /** 			putback(tok2)*/
    Ref(_tok2_55690);
    _30putback(_tok2_55690);
L6: 

    /** 		tok_match( RIGHT_ROUND )*/
    _30tok_match(-27, 0);
    goto L12; // [583] 603
L2: 

    /** 		putback(tok2)*/
    Ref(_tok2_55690);
    _30putback(_tok2_55690);

    /** 		ParseArgs(tok[T_SYM])*/
    _2 = (int)SEQ_PTR(_tok_55688);
    _28594 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_28594);
    _30ParseArgs(_28594);
    _28594 = NOVALUE;
L12: 

    /** end procedure*/
    DeRef(_tok_55688);
    DeRef(_tok2_55690);
    DeRef(_tok3_55691);
    _28561 = NOVALUE;
    DeRef(_28539);
    _28539 = NOVALUE;
    DeRef(_28588);
    _28588 = NOVALUE;
    DeRef(_28592);
    _28592 = NOVALUE;
    return;
    ;
}


void _30Function_call(int _tok_55833)
{
    int _id_55834 = NOVALUE;
    int _scope_55835 = NOVALUE;
    int _opcode_55836 = NOVALUE;
    int _e_55837 = NOVALUE;
    int _28635 = NOVALUE;
    int _28634 = NOVALUE;
    int _28633 = NOVALUE;
    int _28632 = NOVALUE;
    int _28631 = NOVALUE;
    int _28630 = NOVALUE;
    int _28629 = NOVALUE;
    int _28627 = NOVALUE;
    int _28626 = NOVALUE;
    int _28624 = NOVALUE;
    int _28623 = NOVALUE;
    int _28622 = NOVALUE;
    int _28621 = NOVALUE;
    int _28620 = NOVALUE;
    int _28619 = NOVALUE;
    int _28618 = NOVALUE;
    int _28617 = NOVALUE;
    int _28616 = NOVALUE;
    int _28615 = NOVALUE;
    int _28614 = NOVALUE;
    int _28613 = NOVALUE;
    int _28612 = NOVALUE;
    int _28611 = NOVALUE;
    int _28610 = NOVALUE;
    int _28608 = NOVALUE;
    int _28606 = NOVALUE;
    int _28605 = NOVALUE;
    int _28603 = NOVALUE;
    int _28601 = NOVALUE;
    int _28600 = NOVALUE;
    int _28599 = NOVALUE;
    int _28598 = NOVALUE;
    int _28596 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	id = tok[T_ID]*/
    _2 = (int)SEQ_PTR(_tok_55833);
    _id_55834 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_id_55834)){
        _id_55834 = (long)DBL_PTR(_id_55834)->dbl;
    }

    /** 	if id = FUNC or id = TYPE then*/
    _28596 = (_id_55834 == 501);
    if (_28596 != 0) {
        goto L1; // [19] 34
    }
    _28598 = (_id_55834 == 504);
    if (_28598 == 0)
    {
        DeRef(_28598);
        _28598 = NOVALUE;
        goto L2; // [30] 46
    }
    else{
        DeRef(_28598);
        _28598 = NOVALUE;
    }
L1: 

    /** 		UndefinedVar( tok[T_SYM] )*/
    _2 = (int)SEQ_PTR(_tok_55833);
    _28599 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_28599);
    _30UndefinedVar(_28599);
    _28599 = NOVALUE;
L2: 

    /** 	e = SymTab[tok[T_SYM]][S_EFFECT]*/
    _2 = (int)SEQ_PTR(_tok_55833);
    _28600 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!IS_ATOM_INT(_28600)){
        _28601 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_28600)->dbl));
    }
    else{
        _28601 = (int)*(((s1_ptr)_2)->base + _28600);
    }
    _2 = (int)SEQ_PTR(_28601);
    _e_55837 = (int)*(((s1_ptr)_2)->base + 23);
    if (!IS_ATOM_INT(_e_55837)){
        _e_55837 = (long)DBL_PTR(_e_55837)->dbl;
    }
    _28601 = NOVALUE;

    /** 	if e then*/
    if (_e_55837 == 0)
    {
        goto L3; // [70] 229
    }
    else{
    }

    /** 		if e = E_ALL_EFFECT or tok[T_SYM] > left_sym then*/
    _28603 = (_e_55837 == 1073741823);
    if (_28603 != 0) {
        goto L4; // [81] 102
    }
    _2 = (int)SEQ_PTR(_tok_55833);
    _28605 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_28605)) {
        _28606 = (_28605 > _30left_sym_54197);
    }
    else {
        _28606 = binary_op(GREATER, _28605, _30left_sym_54197);
    }
    _28605 = NOVALUE;
    if (_28606 == 0) {
        DeRef(_28606);
        _28606 = NOVALUE;
        goto L5; // [98] 111
    }
    else {
        if (!IS_ATOM_INT(_28606) && DBL_PTR(_28606)->dbl == 0.0){
            DeRef(_28606);
            _28606 = NOVALUE;
            goto L5; // [98] 111
        }
        DeRef(_28606);
        _28606 = NOVALUE;
    }
    DeRef(_28606);
    _28606 = NOVALUE;
L4: 

    /** 			side_effect_calls = or_bits(side_effect_calls, e)*/
    {unsigned long tu;
         tu = (unsigned long)_30side_effect_calls_54193 | (unsigned long)_e_55837;
         _30side_effect_calls_54193 = MAKE_UINT(tu);
    }
L5: 

    /** 		SymTab[CurrentSub][S_EFFECT] = or_bits(SymTab[CurrentSub][S_EFFECT], e)*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_26CurrentSub_11990 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _28610 = (int)*(((s1_ptr)_2)->base + _26CurrentSub_11990);
    _2 = (int)SEQ_PTR(_28610);
    _28611 = (int)*(((s1_ptr)_2)->base + 23);
    _28610 = NOVALUE;
    if (IS_ATOM_INT(_28611)) {
        {unsigned long tu;
             tu = (unsigned long)_28611 | (unsigned long)_e_55837;
             _28612 = MAKE_UINT(tu);
        }
    }
    else {
        _28612 = binary_op(OR_BITS, _28611, _e_55837);
    }
    _28611 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 23);
    _1 = *(int *)_2;
    *(int *)_2 = _28612;
    if( _1 != _28612 ){
        DeRef(_1);
    }
    _28612 = NOVALUE;
    _28608 = NOVALUE;

    /** 		if short_circuit > 0 and short_circuit_B and*/
    _28613 = (_30short_circuit_54156 > 0);
    if (_28613 == 0) {
        _28614 = 0;
        goto L6; // [154] 164
    }
    _28614 = (_30short_circuit_B_54158 != 0);
L6: 
    if (_28614 == 0) {
        goto L7; // [164] 228
    }
    _28616 = find_from(_id_55834, _28FUNC_TOKS_11614, 1);
    if (_28616 == 0)
    {
        _28616 = NOVALUE;
        goto L7; // [176] 228
    }
    else{
        _28616 = NOVALUE;
    }

    /** 			Warning(219, short_circuit_warning_flag,*/
    _2 = (int)SEQ_PTR(_27known_files_10922);
    _28617 = (int)*(((s1_ptr)_2)->base + _26current_file_no_11982);
    Ref(_28617);
    RefDS(_22037);
    _28618 = _15abbreviate_path(_28617, _22037);
    _28617 = NOVALUE;
    _2 = (int)SEQ_PTR(_tok_55833);
    _28619 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!IS_ATOM_INT(_28619)){
        _28620 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_28619)->dbl));
    }
    else{
        _28620 = (int)*(((s1_ptr)_2)->base + _28619);
    }
    _2 = (int)SEQ_PTR(_28620);
    if (!IS_ATOM_INT(_26S_NAME_11654)){
        _28621 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NAME_11654)->dbl));
    }
    else{
        _28621 = (int)*(((s1_ptr)_2)->base + _26S_NAME_11654);
    }
    _28620 = NOVALUE;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _28618;
    *((int *)(_2+8)) = _26line_number_11983;
    Ref(_28621);
    *((int *)(_2+12)) = _28621;
    _28622 = MAKE_SEQ(_1);
    _28621 = NOVALUE;
    _28618 = NOVALUE;
    _43Warning(219, 2, _28622);
    _28622 = NOVALUE;
L7: 
L3: 

    /** 	tok_match(LEFT_ROUND)*/
    _30tok_match(-26, 0);

    /** 	scope = SymTab[tok[T_SYM]][S_SCOPE]*/
    _2 = (int)SEQ_PTR(_tok_55833);
    _28623 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!IS_ATOM_INT(_28623)){
        _28624 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_28623)->dbl));
    }
    else{
        _28624 = (int)*(((s1_ptr)_2)->base + _28623);
    }
    _2 = (int)SEQ_PTR(_28624);
    _scope_55835 = (int)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_scope_55835)){
        _scope_55835 = (long)DBL_PTR(_scope_55835)->dbl;
    }
    _28624 = NOVALUE;

    /** 	opcode = SymTab[tok[T_SYM]][S_OPCODE]*/
    _2 = (int)SEQ_PTR(_tok_55833);
    _28626 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!IS_ATOM_INT(_28626)){
        _28627 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_28626)->dbl));
    }
    else{
        _28627 = (int)*(((s1_ptr)_2)->base + _28626);
    }
    _2 = (int)SEQ_PTR(_28627);
    _opcode_55836 = (int)*(((s1_ptr)_2)->base + 21);
    if (!IS_ATOM_INT(_opcode_55836)){
        _opcode_55836 = (long)DBL_PTR(_opcode_55836)->dbl;
    }
    _28627 = NOVALUE;

    /** 	if equal(SymTab[tok[T_SYM]][S_NAME],"object") and scope = SC_PREDEF then*/
    _2 = (int)SEQ_PTR(_tok_55833);
    _28629 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!IS_ATOM_INT(_28629)){
        _28630 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_28629)->dbl));
    }
    else{
        _28630 = (int)*(((s1_ptr)_2)->base + _28629);
    }
    _2 = (int)SEQ_PTR(_28630);
    if (!IS_ATOM_INT(_26S_NAME_11654)){
        _28631 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NAME_11654)->dbl));
    }
    else{
        _28631 = (int)*(((s1_ptr)_2)->base + _26S_NAME_11654);
    }
    _28630 = NOVALUE;
    if (_28631 == _24664)
    _28632 = 1;
    else if (IS_ATOM_INT(_28631) && IS_ATOM_INT(_24664))
    _28632 = 0;
    else
    _28632 = (compare(_28631, _24664) == 0);
    _28631 = NOVALUE;
    if (_28632 == 0) {
        goto L8; // [305] 327
    }
    _28634 = (_scope_55835 == 7);
    if (_28634 == 0)
    {
        DeRef(_28634);
        _28634 = NOVALUE;
        goto L8; // [316] 327
    }
    else{
        DeRef(_28634);
        _28634 = NOVALUE;
    }

    /** 		Object_call( tok )*/
    Ref(_tok_55833);
    _30Object_call(_tok_55833);
    goto L9; // [324] 339
L8: 

    /** 		ParseArgs(tok[T_SYM])*/
    _2 = (int)SEQ_PTR(_tok_55833);
    _28635 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_28635);
    _30ParseArgs(_28635);
    _28635 = NOVALUE;
L9: 

    /** 	if scope = SC_PREDEF then*/
    if (_scope_55835 != 7)
    goto LA; // [343] 355

    /** 		emit_op(opcode)*/
    _37emit_op(_opcode_55836);
    goto LB; // [352] 393
LA: 

    /** 		op_info1 = tok[T_SYM]*/
    _2 = (int)SEQ_PTR(_tok_55833);
    _37op_info1_50262 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_37op_info1_50262)){
        _37op_info1_50262 = (long)DBL_PTR(_37op_info1_50262)->dbl;
    }

    /** 		emit_or_inline()*/
    _66emit_or_inline();

    /** 		if not TRANSLATE then*/
    if (_26TRANSLATE_11619 != 0)
    goto LC; // [373] 392

    /** 			if OpTrace then*/
    if (_26OpTrace_12052 == 0)
    {
        goto LD; // [380] 391
    }
    else{
    }

    /** 				emit_op(UPDATE_GLOBALS)*/
    _37emit_op(89);
LD: 
LC: 
LB: 

    /** end procedure*/
    DeRef(_tok_55833);
    DeRef(_28596);
    _28596 = NOVALUE;
    _28600 = NOVALUE;
    DeRef(_28603);
    _28603 = NOVALUE;
    DeRef(_28613);
    _28613 = NOVALUE;
    _28619 = NOVALUE;
    _28623 = NOVALUE;
    _28626 = NOVALUE;
    _28629 = NOVALUE;
    return;
    ;
}


void _30Factor()
{
    int _tok_55941 = NOVALUE;
    int _id_55942 = NOVALUE;
    int _n_55943 = NOVALUE;
    int _save_factors_55944 = NOVALUE;
    int _save_lhs_subs_level_55945 = NOVALUE;
    int _sym_55947 = NOVALUE;
    int _forward_55978 = NOVALUE;
    int _28697 = NOVALUE;
    int _28696 = NOVALUE;
    int _28695 = NOVALUE;
    int _28693 = NOVALUE;
    int _28692 = NOVALUE;
    int _28691 = NOVALUE;
    int _28690 = NOVALUE;
    int _28689 = NOVALUE;
    int _28687 = NOVALUE;
    int _28683 = NOVALUE;
    int _28682 = NOVALUE;
    int _28679 = NOVALUE;
    int _28678 = NOVALUE;
    int _28674 = NOVALUE;
    int _28668 = NOVALUE;
    int _28663 = NOVALUE;
    int _28662 = NOVALUE;
    int _28661 = NOVALUE;
    int _28659 = NOVALUE;
    int _28658 = NOVALUE;
    int _28656 = NOVALUE;
    int _28654 = NOVALUE;
    int _28653 = NOVALUE;
    int _28652 = NOVALUE;
    int _28650 = NOVALUE;
    int _28643 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	integer id, n*/

    /** 	integer save_factors, save_lhs_subs_level*/

    /** 	factors += 1*/
    _30factors_54194 = _30factors_54194 + 1;

    /** 	tok = next_token()*/
    _0 = _tok_55941;
    _tok_55941 = _30next_token();
    DeRef(_0);

    /** 	id = tok[T_ID]*/
    _2 = (int)SEQ_PTR(_tok_55941);
    _id_55942 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_id_55942)){
        _id_55942 = (long)DBL_PTR(_id_55942)->dbl;
    }

    /** 	if id = RECORDED then*/
    if (_id_55942 != 508)
    goto L1; // [32] 59

    /** 		tok = read_recorded_token(tok[T_SYM])*/
    _2 = (int)SEQ_PTR(_tok_55941);
    _28643 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_28643);
    _0 = _tok_55941;
    _tok_55941 = _30read_recorded_token(_28643);
    DeRef(_0);
    _28643 = NOVALUE;

    /** 		id = tok[T_ID]*/
    _2 = (int)SEQ_PTR(_tok_55941);
    _id_55942 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_id_55942)){
        _id_55942 = (long)DBL_PTR(_id_55942)->dbl;
    }
L1: 

    /** 	switch id label "factor" do*/
    _0 = _id_55942;
    switch ( _0 ){ 

        /** 		case VARIABLE, QUALIFIED_VARIABLE then*/
        case -100:
        case 512:

        /** 			sym = tok[T_SYM]*/
        _2 = (int)SEQ_PTR(_tok_55941);
        _sym_55947 = (int)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_sym_55947)){
            _sym_55947 = (long)DBL_PTR(_sym_55947)->dbl;
        }

        /** 			if sym < 0 or SymTab[sym][S_SCOPE] = SC_UNDEFINED then*/
        _28650 = (_sym_55947 < 0);
        if (_28650 != 0) {
            goto L2; // [88] 115
        }
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _28652 = (int)*(((s1_ptr)_2)->base + _sym_55947);
        _2 = (int)SEQ_PTR(_28652);
        _28653 = (int)*(((s1_ptr)_2)->base + 4);
        _28652 = NOVALUE;
        if (IS_ATOM_INT(_28653)) {
            _28654 = (_28653 == 9);
        }
        else {
            _28654 = binary_op(EQUALS, _28653, 9);
        }
        _28653 = NOVALUE;
        if (_28654 == 0) {
            DeRef(_28654);
            _28654 = NOVALUE;
            goto L3; // [111] 177
        }
        else {
            if (!IS_ATOM_INT(_28654) && DBL_PTR(_28654)->dbl == 0.0){
                DeRef(_28654);
                _28654 = NOVALUE;
                goto L3; // [111] 177
            }
            DeRef(_28654);
            _28654 = NOVALUE;
        }
        DeRef(_28654);
        _28654 = NOVALUE;
L2: 

        /** 				token forward = next_token()*/
        _0 = _forward_55978;
        _forward_55978 = _30next_token();
        DeRef(_0);

        /** 				if forward[T_ID] = LEFT_ROUND then*/
        _2 = (int)SEQ_PTR(_forward_55978);
        _28656 = (int)*(((s1_ptr)_2)->base + 1);
        if (binary_op_a(NOTEQ, _28656, -26)){
            _28656 = NOVALUE;
            goto L4; // [130] 151
        }
        _28656 = NOVALUE;

        /** 					Forward_call( tok, FUNC_FORWARD )*/
        Ref(_tok_55941);
        _30Forward_call(_tok_55941, 196);

        /** 					break "factor"*/
        DeRef(_forward_55978);
        _forward_55978 = NOVALUE;
        goto L5; // [146] 696
        goto L6; // [148] 172
L4: 

        /** 					putback( forward )*/
        Ref(_forward_55978);
        _30putback(_forward_55978);

        /** 					Forward_var( tok, TRUE )*/
        _2 = (int)SEQ_PTR(_tok_55941);
        _28658 = (int)*(((s1_ptr)_2)->base + 1);
        Ref(_tok_55941);
        Ref(_28658);
        _30Forward_var(_tok_55941, _9TRUE_430, _28658);
        _28658 = NOVALUE;
L6: 
        DeRef(_forward_55978);
        _forward_55978 = NOVALUE;
        goto L7; // [174] 229
L3: 

        /** 				UndefinedVar(sym)*/
        _30UndefinedVar(_sym_55947);

        /** 				SymTab[sym][S_USAGE] = or_bits(SymTab[sym][S_USAGE], U_READ)*/
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _27SymTab_10921 = MAKE_SEQ(_2);
        }
        _3 = (int)(_sym_55947 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _28661 = (int)*(((s1_ptr)_2)->base + _sym_55947);
        _2 = (int)SEQ_PTR(_28661);
        _28662 = (int)*(((s1_ptr)_2)->base + 5);
        _28661 = NOVALUE;
        if (IS_ATOM_INT(_28662)) {
            {unsigned long tu;
                 tu = (unsigned long)_28662 | (unsigned long)1;
                 _28663 = MAKE_UINT(tu);
            }
        }
        else {
            _28663 = binary_op(OR_BITS, _28662, 1);
        }
        _28662 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 5);
        _1 = *(int *)_2;
        *(int *)_2 = _28663;
        if( _1 != _28663 ){
            DeRef(_1);
        }
        _28663 = NOVALUE;
        _28659 = NOVALUE;

        /** 				InitCheck(sym, TRUE)*/
        _30InitCheck(_sym_55947, _9TRUE_430);

        /** 				emit_opnd(sym)*/
        _37emit_opnd(_sym_55947);
L7: 

        /** 			if sym = left_sym then*/
        if (_sym_55947 != _30left_sym_54197)
        goto L8; // [233] 243

        /** 				lhs_subs_level = 0 -- start counting subscripts*/
        _30lhs_subs_level_54195 = 0;
L8: 

        /** 			short_circuit -= 1*/
        _30short_circuit_54156 = _30short_circuit_54156 - 1;

        /** 			tok = next_token()*/
        _0 = _tok_55941;
        _tok_55941 = _30next_token();
        DeRef(_0);

        /** 			current_sequence = append(current_sequence, sym)*/
        Append(&_37current_sequence_50270, _37current_sequence_50270, _sym_55947);

        /** 			while tok[T_ID] = LEFT_SQUARE do*/
L9: 
        _2 = (int)SEQ_PTR(_tok_55941);
        _28668 = (int)*(((s1_ptr)_2)->base + 1);
        if (binary_op_a(NOTEQ, _28668, -28)){
            _28668 = NOVALUE;
            goto LA; // [279] 450
        }
        _28668 = NOVALUE;

        /** 				subs_depth += 1*/
        _30subs_depth_54198 = _30subs_depth_54198 + 1;

        /** 				if lhs_subs_level >= 0 then*/
        if (_30lhs_subs_level_54195 < 0)
        goto LB; // [295] 308

        /** 					lhs_subs_level += 1*/
        _30lhs_subs_level_54195 = _30lhs_subs_level_54195 + 1;
LB: 

        /** 				save_factors = factors*/
        _save_factors_55944 = _30factors_54194;

        /** 				save_lhs_subs_level = lhs_subs_level*/
        _save_lhs_subs_level_55945 = _30lhs_subs_level_54195;

        /** 				call_proc(forward_expr, {})*/
        _0 = (int)_00[_30forward_expr_55165].addr;
        (*(int (*)())_0)(
                             );

        /** 				tok = next_token()*/
        _0 = _tok_55941;
        _tok_55941 = _30next_token();
        DeRef(_0);

        /** 				if tok[T_ID] = SLICE then*/
        _2 = (int)SEQ_PTR(_tok_55941);
        _28674 = (int)*(((s1_ptr)_2)->base + 1);
        if (binary_op_a(NOTEQ, _28674, 513)){
            _28674 = NOVALUE;
            goto LC; // [344] 382
        }
        _28674 = NOVALUE;

        /** 					call_proc(forward_expr, {})*/
        _0 = (int)_00[_30forward_expr_55165].addr;
        (*(int (*)())_0)(
                             );

        /** 					emit_op(RHS_SLICE)*/
        _37emit_op(46);

        /** 					tok_match(RIGHT_SQUARE)*/
        _30tok_match(-29, 0);

        /** 					tok = next_token()*/
        _0 = _tok_55941;
        _tok_55941 = _30next_token();
        DeRef(_0);

        /** 					exit*/
        goto LA; // [377] 450
        goto LD; // [379] 430
LC: 

        /** 					putback(tok)*/
        Ref(_tok_55941);
        _30putback(_tok_55941);

        /** 					tok_match(RIGHT_SQUARE)*/
        _30tok_match(-29, 0);

        /** 					subs_depth -= 1*/
        _30subs_depth_54198 = _30subs_depth_54198 - 1;

        /** 					current_sequence = head( current_sequence, length( current_sequence ) - 1 )*/
        if (IS_SEQUENCE(_37current_sequence_50270)){
                _28678 = SEQ_PTR(_37current_sequence_50270)->length;
        }
        else {
            _28678 = 1;
        }
        _28679 = _28678 - 1;
        _28678 = NOVALUE;
        {
            int len = SEQ_PTR(_37current_sequence_50270)->length;
            int size = (IS_ATOM_INT(_28679)) ? _28679 : (long)(DBL_PTR(_28679)->dbl);
            if (size <= 0) _37current_sequence_50270 = MAKE_SEQ(NewS1(0));
            else if (len <= size) {
                RefDS(_37current_sequence_50270);
                DeRef(_37current_sequence_50270);
                _37current_sequence_50270 = _37current_sequence_50270;
            }
            else Head(SEQ_PTR(_37current_sequence_50270),size+1,&_37current_sequence_50270);
        }
        _28679 = NOVALUE;

        /** 					emit_op(RHS_SUBS) -- current_sequence will be updated*/
        _37emit_op(25);
LD: 

        /** 				factors = save_factors*/
        _30factors_54194 = _save_factors_55944;

        /** 				lhs_subs_level = save_lhs_subs_level*/
        _30lhs_subs_level_54195 = _save_lhs_subs_level_55945;

        /** 				tok = next_token()*/
        _0 = _tok_55941;
        _tok_55941 = _30next_token();
        DeRef(_0);

        /** 			end while*/
        goto L9; // [447] 271
LA: 

        /** 			current_sequence = head( current_sequence, length( current_sequence ) - 1 )*/
        if (IS_SEQUENCE(_37current_sequence_50270)){
                _28682 = SEQ_PTR(_37current_sequence_50270)->length;
        }
        else {
            _28682 = 1;
        }
        _28683 = _28682 - 1;
        _28682 = NOVALUE;
        {
            int len = SEQ_PTR(_37current_sequence_50270)->length;
            int size = (IS_ATOM_INT(_28683)) ? _28683 : (long)(DBL_PTR(_28683)->dbl);
            if (size <= 0) _37current_sequence_50270 = MAKE_SEQ(NewS1(0));
            else if (len <= size) {
                RefDS(_37current_sequence_50270);
                DeRef(_37current_sequence_50270);
                _37current_sequence_50270 = _37current_sequence_50270;
            }
            else Head(SEQ_PTR(_37current_sequence_50270),size+1,&_37current_sequence_50270);
        }
        _28683 = NOVALUE;

        /** 			putback(tok)*/
        Ref(_tok_55941);
        _30putback(_tok_55941);

        /** 			short_circuit += 1*/
        _30short_circuit_54156 = _30short_circuit_54156 + 1;
        goto L5; // [482] 696

        /** 		case DOLLAR then*/
        case -22:

        /** 			tok = next_token()*/
        _0 = _tok_55941;
        _tok_55941 = _30next_token();
        DeRef(_0);

        /** 			putback(tok)*/
        Ref(_tok_55941);
        _30putback(_tok_55941);

        /** 			if tok[T_ID] = RIGHT_BRACE then*/
        _2 = (int)SEQ_PTR(_tok_55941);
        _28687 = (int)*(((s1_ptr)_2)->base + 1);
        if (binary_op_a(NOTEQ, _28687, -25)){
            _28687 = NOVALUE;
            goto LE; // [508] 526
        }
        _28687 = NOVALUE;

        /** 				gListItem[$] = 0*/
        if (IS_SEQUENCE(_30gListItem_54192)){
                _28689 = SEQ_PTR(_30gListItem_54192)->length;
        }
        else {
            _28689 = 1;
        }
        _2 = (int)SEQ_PTR(_30gListItem_54192);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _30gListItem_54192 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _28689);
        *(int *)_2 = 0;
        goto L5; // [523] 696
LE: 

        /** 				if subs_depth > 0 and length(current_sequence) then*/
        _28690 = (_30subs_depth_54198 > 0);
        if (_28690 == 0) {
            goto LF; // [534] 557
        }
        if (IS_SEQUENCE(_37current_sequence_50270)){
                _28692 = SEQ_PTR(_37current_sequence_50270)->length;
        }
        else {
            _28692 = 1;
        }
        if (_28692 == 0)
        {
            _28692 = NOVALUE;
            goto LF; // [544] 557
        }
        else{
            _28692 = NOVALUE;
        }

        /** 					emit_op(DOLLAR)*/
        _37emit_op(-22);
        goto L5; // [554] 696
LF: 

        /** 					CompileErr(21)*/
        RefDS(_22037);
        _43CompileErr(21, _22037, 0);
        goto L5; // [566] 696

        /** 		case ATOM then*/
        case 502:

        /** 			emit_opnd(tok[T_SYM])*/
        _2 = (int)SEQ_PTR(_tok_55941);
        _28693 = (int)*(((s1_ptr)_2)->base + 2);
        Ref(_28693);
        _37emit_opnd(_28693);
        _28693 = NOVALUE;
        goto L5; // [583] 696

        /** 		case LEFT_BRACE then*/
        case -24:

        /** 			n = Expr_list()*/
        _n_55943 = _30Expr_list();
        if (!IS_ATOM_INT(_n_55943)) {
            _1 = (long)(DBL_PTR(_n_55943)->dbl);
            DeRefDS(_n_55943);
            _n_55943 = _1;
        }

        /** 			tok_match(RIGHT_BRACE)*/
        _30tok_match(-25, 0);

        /** 			op_info1 = n*/
        _37op_info1_50262 = _n_55943;

        /** 			emit_op(RIGHT_BRACE_N)*/
        _37emit_op(31);
        goto L5; // [618] 696

        /** 		case STRING then*/
        case 503:

        /** 			emit_opnd(tok[T_SYM])*/
        _2 = (int)SEQ_PTR(_tok_55941);
        _28695 = (int)*(((s1_ptr)_2)->base + 2);
        Ref(_28695);
        _37emit_opnd(_28695);
        _28695 = NOVALUE;
        goto L5; // [635] 696

        /** 		case LEFT_ROUND then*/
        case -26:

        /** 			call_proc(forward_expr, {})*/
        _0 = (int)_00[_30forward_expr_55165].addr;
        (*(int (*)())_0)(
                             );

        /** 			tok_match(RIGHT_ROUND)*/
        _30tok_match(-27, 0);
        goto L5; // [656] 696

        /** 		case FUNC, TYPE, QUALIFIED_FUNC, QUALIFIED_TYPE then*/
        case 501:
        case 504:
        case 520:
        case 522:

        /** 			Function_call( tok )*/
        Ref(_tok_55941);
        _30Function_call(_tok_55941);
        goto L5; // [673] 696

        /** 		case else*/
        default:

        /** 			CompileErr(135, {LexName(id)})*/
        RefDS(_26480);
        _28696 = _37LexName(_id_55942, _26480);
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = _28696;
        _28697 = MAKE_SEQ(_1);
        _28696 = NOVALUE;
        _43CompileErr(135, _28697, 0);
        _28697 = NOVALUE;
    ;}L5: 

    /** end procedure*/
    DeRef(_tok_55941);
    DeRef(_28650);
    _28650 = NOVALUE;
    DeRef(_28690);
    _28690 = NOVALUE;
    return;
    ;
}


void _30UFactor()
{
    int _tok_56100 = NOVALUE;
    int _28703 = NOVALUE;
    int _28701 = NOVALUE;
    int _28699 = NOVALUE;
    int _0, _1, _2;
    

    /** 	tok = next_token()*/
    _0 = _tok_56100;
    _tok_56100 = _30next_token();
    DeRef(_0);

    /** 	if tok[T_ID] = MINUS then*/
    _2 = (int)SEQ_PTR(_tok_56100);
    _28699 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28699, 10)){
        _28699 = NOVALUE;
        goto L1; // [16] 34
    }
    _28699 = NOVALUE;

    /** 		Factor()*/
    _30Factor();

    /** 		emit_op(UMINUS)*/
    _37emit_op(12);
    goto L2; // [31] 93
L1: 

    /** 	elsif tok[T_ID] = NOT then*/
    _2 = (int)SEQ_PTR(_tok_56100);
    _28701 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28701, 7)){
        _28701 = NOVALUE;
        goto L3; // [44] 62
    }
    _28701 = NOVALUE;

    /** 		Factor()*/
    _30Factor();

    /** 		emit_op(NOT)*/
    _37emit_op(7);
    goto L2; // [59] 93
L3: 

    /** 	elsif tok[T_ID] = PLUS then*/
    _2 = (int)SEQ_PTR(_tok_56100);
    _28703 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28703, 11)){
        _28703 = NOVALUE;
        goto L4; // [72] 83
    }
    _28703 = NOVALUE;

    /** 		Factor()*/
    _30Factor();
    goto L2; // [80] 93
L4: 

    /** 		putback(tok)*/
    Ref(_tok_56100);
    _30putback(_tok_56100);

    /** 		Factor()*/
    _30Factor();
L2: 

    /** end procedure*/
    DeRef(_tok_56100);
    return;
    ;
}


int _30Term()
{
    int _tok_56125 = NOVALUE;
    int _28711 = NOVALUE;
    int _28710 = NOVALUE;
    int _28709 = NOVALUE;
    int _28707 = NOVALUE;
    int _28706 = NOVALUE;
    int _0, _1, _2;
    

    /** 	UFactor()*/
    _30UFactor();

    /** 	tok = next_token()*/
    _0 = _tok_56125;
    _tok_56125 = _30next_token();
    DeRef(_0);

    /** 	while tok[T_ID] = reserved:MULTIPLY or tok[T_ID] = reserved:DIVIDE do*/
L1: 
    _2 = (int)SEQ_PTR(_tok_56125);
    _28706 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_28706)) {
        _28707 = (_28706 == 13);
    }
    else {
        _28707 = binary_op(EQUALS, _28706, 13);
    }
    _28706 = NOVALUE;
    if (IS_ATOM_INT(_28707)) {
        if (_28707 != 0) {
            goto L2; // [25] 44
        }
    }
    else {
        if (DBL_PTR(_28707)->dbl != 0.0) {
            goto L2; // [25] 44
        }
    }
    _2 = (int)SEQ_PTR(_tok_56125);
    _28709 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_28709)) {
        _28710 = (_28709 == 14);
    }
    else {
        _28710 = binary_op(EQUALS, _28709, 14);
    }
    _28709 = NOVALUE;
    if (_28710 <= 0) {
        if (_28710 == 0) {
            DeRef(_28710);
            _28710 = NOVALUE;
            goto L3; // [40] 69
        }
        else {
            if (!IS_ATOM_INT(_28710) && DBL_PTR(_28710)->dbl == 0.0){
                DeRef(_28710);
                _28710 = NOVALUE;
                goto L3; // [40] 69
            }
            DeRef(_28710);
            _28710 = NOVALUE;
        }
    }
    DeRef(_28710);
    _28710 = NOVALUE;
L2: 

    /** 		UFactor()*/
    _30UFactor();

    /** 		emit_op(tok[T_ID])*/
    _2 = (int)SEQ_PTR(_tok_56125);
    _28711 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_28711);
    _37emit_op(_28711);
    _28711 = NOVALUE;

    /** 		tok = next_token()*/
    _0 = _tok_56125;
    _tok_56125 = _30next_token();
    DeRef(_0);

    /** 	end while*/
    goto L1; // [66] 15
L3: 

    /** 	return tok*/
    DeRef(_28707);
    _28707 = NOVALUE;
    return _tok_56125;
    ;
}


int _30aexpr()
{
    int _tok_56142 = NOVALUE;
    int _id_56143 = NOVALUE;
    int _28718 = NOVALUE;
    int _28717 = NOVALUE;
    int _28715 = NOVALUE;
    int _28714 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer id*/

    /** 	tok = Term()*/
    _0 = _tok_56142;
    _tok_56142 = _30Term();
    DeRef(_0);

    /** 	while tok[T_ID] = PLUS or tok[T_ID] = MINUS do*/
L1: 
    _2 = (int)SEQ_PTR(_tok_56142);
    _28714 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_28714)) {
        _28715 = (_28714 == 11);
    }
    else {
        _28715 = binary_op(EQUALS, _28714, 11);
    }
    _28714 = NOVALUE;
    if (IS_ATOM_INT(_28715)) {
        if (_28715 != 0) {
            goto L2; // [25] 46
        }
    }
    else {
        if (DBL_PTR(_28715)->dbl != 0.0) {
            goto L2; // [25] 46
        }
    }
    _2 = (int)SEQ_PTR(_tok_56142);
    _28717 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_28717)) {
        _28718 = (_28717 == 10);
    }
    else {
        _28718 = binary_op(EQUALS, _28717, 10);
    }
    _28717 = NOVALUE;
    if (_28718 <= 0) {
        if (_28718 == 0) {
            DeRef(_28718);
            _28718 = NOVALUE;
            goto L3; // [42] 71
        }
        else {
            if (!IS_ATOM_INT(_28718) && DBL_PTR(_28718)->dbl == 0.0){
                DeRef(_28718);
                _28718 = NOVALUE;
                goto L3; // [42] 71
            }
            DeRef(_28718);
            _28718 = NOVALUE;
        }
    }
    DeRef(_28718);
    _28718 = NOVALUE;
L2: 

    /** 		id = tok[T_ID]*/
    _2 = (int)SEQ_PTR(_tok_56142);
    _id_56143 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_id_56143)){
        _id_56143 = (long)DBL_PTR(_id_56143)->dbl;
    }

    /** 		tok = Term()*/
    _0 = _tok_56142;
    _tok_56142 = _30Term();
    DeRef(_0);

    /** 		emit_op(id)*/
    _37emit_op(_id_56143);

    /** 	end while*/
    goto L1; // [68] 13
L3: 

    /** 	return tok*/
    DeRef(_28715);
    _28715 = NOVALUE;
    return _tok_56142;
    ;
}


int _30cexpr()
{
    int _tok_56162 = NOVALUE;
    int _concat_count_56163 = NOVALUE;
    int _28722 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer concat_count*/

    /** 	tok = aexpr()*/
    _0 = _tok_56162;
    _tok_56162 = _30aexpr();
    DeRef(_0);

    /** 	concat_count = 0*/
    _concat_count_56163 = 0;

    /** 	while tok[T_ID] = reserved:CONCAT do*/
L1: 
    _2 = (int)SEQ_PTR(_tok_56162);
    _28722 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28722, 15)){
        _28722 = NOVALUE;
        goto L2; // [24] 44
    }
    _28722 = NOVALUE;

    /** 		tok = aexpr()*/
    _0 = _tok_56162;
    _tok_56162 = _30aexpr();
    DeRef(_0);

    /** 		concat_count += 1*/
    _concat_count_56163 = _concat_count_56163 + 1;

    /** 	end while*/
    goto L1; // [41] 18
L2: 

    /** 	if concat_count = 1 then*/
    if (_concat_count_56163 != 1)
    goto L3; // [46] 58

    /** 		emit_op( reserved:CONCAT )*/
    _37emit_op(15);
    goto L4; // [55] 81
L3: 

    /** 	elsif concat_count > 1 then*/
    if (_concat_count_56163 <= 1)
    goto L5; // [60] 80

    /** 		op_info1 = concat_count+1*/
    _37op_info1_50262 = _concat_count_56163 + 1;

    /** 		emit_op(CONCAT_N)*/
    _37emit_op(157);
L5: 
L4: 

    /** 	return tok*/
    return _tok_56162;
    ;
}


int _30rexpr()
{
    int _tok_56183 = NOVALUE;
    int _id_56184 = NOVALUE;
    int _28734 = NOVALUE;
    int _28733 = NOVALUE;
    int _28732 = NOVALUE;
    int _28731 = NOVALUE;
    int _28730 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer id*/

    /** 	tok = cexpr()*/
    _0 = _tok_56183;
    _tok_56183 = _30cexpr();
    DeRef(_0);

    /** 	while tok[T_ID] <= GREATER and tok[T_ID] >= LESS do*/
L1: 
    _2 = (int)SEQ_PTR(_tok_56183);
    _28730 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_28730)) {
        _28731 = (_28730 <= 6);
    }
    else {
        _28731 = binary_op(LESSEQ, _28730, 6);
    }
    _28730 = NOVALUE;
    if (IS_ATOM_INT(_28731)) {
        if (_28731 == 0) {
            goto L2; // [25] 70
        }
    }
    else {
        if (DBL_PTR(_28731)->dbl == 0.0) {
            goto L2; // [25] 70
        }
    }
    _2 = (int)SEQ_PTR(_tok_56183);
    _28733 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_28733)) {
        _28734 = (_28733 >= 1);
    }
    else {
        _28734 = binary_op(GREATEREQ, _28733, 1);
    }
    _28733 = NOVALUE;
    if (_28734 <= 0) {
        if (_28734 == 0) {
            DeRef(_28734);
            _28734 = NOVALUE;
            goto L2; // [42] 70
        }
        else {
            if (!IS_ATOM_INT(_28734) && DBL_PTR(_28734)->dbl == 0.0){
                DeRef(_28734);
                _28734 = NOVALUE;
                goto L2; // [42] 70
            }
            DeRef(_28734);
            _28734 = NOVALUE;
        }
    }
    DeRef(_28734);
    _28734 = NOVALUE;

    /** 		id = tok[T_ID]*/
    _2 = (int)SEQ_PTR(_tok_56183);
    _id_56184 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_id_56184)){
        _id_56184 = (long)DBL_PTR(_id_56184)->dbl;
    }

    /** 		tok = cexpr()*/
    _0 = _tok_56183;
    _tok_56183 = _30cexpr();
    DeRef(_0);

    /** 		emit_op(id)*/
    _37emit_op(_id_56184);

    /** 	end while*/
    goto L1; // [67] 13
L2: 

    /** 	return tok*/
    DeRef(_28731);
    _28731 = NOVALUE;
    return _tok_56183;
    ;
}


void _30Expr()
{
    int _tok_56210 = NOVALUE;
    int _id_56211 = NOVALUE;
    int _patch_56212 = NOVALUE;
    int _28757 = NOVALUE;
    int _28755 = NOVALUE;
    int _28754 = NOVALUE;
    int _28752 = NOVALUE;
    int _28751 = NOVALUE;
    int _28750 = NOVALUE;
    int _28749 = NOVALUE;
    int _28748 = NOVALUE;
    int _28742 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer id*/

    /** 	integer patch*/

    /** 	ExprLine = ThisLine*/
    Ref(_43ThisLine_48557);
    DeRef(_30ExprLine_56205);
    _30ExprLine_56205 = _43ThisLine_48557;

    /** 	expr_bp = bp*/
    _30expr_bp_56206 = _43bp_48561;

    /** 	id = -1*/
    _id_56211 = -1;

    /** 	patch = 0*/
    _patch_56212 = 0;

    /** 	while TRUE do*/
L1: 
    if (_9TRUE_430 == 0)
    {
        goto L2; // [40] 300
    }
    else{
    }

    /** 		if id != -1 then*/
    if (_id_56211 == -1)
    goto L3; // [45] 116

    /** 			if id != XOR then*/
    if (_id_56211 == 152)
    goto L4; // [53] 115

    /** 				if short_circuit > 0 then*/
    if (_30short_circuit_54156 <= 0)
    goto L5; // [61] 114

    /** 					if id = OR then*/
    if (_id_56211 != 9)
    goto L6; // [69] 83

    /** 						emit_op(SC1_OR)*/
    _37emit_op(143);
    goto L7; // [80] 91
L6: 

    /** 						emit_op(SC1_AND)*/
    _37emit_op(141);
L7: 

    /** 					patch = length(Code)+1*/
    if (IS_SEQUENCE(_26Code_12071)){
            _28742 = SEQ_PTR(_26Code_12071)->length;
    }
    else {
        _28742 = 1;
    }
    _patch_56212 = _28742 + 1;
    _28742 = NOVALUE;

    /** 					emit_forward_addr()*/
    _30emit_forward_addr();

    /** 					short_circuit_B = TRUE*/
    _30short_circuit_B_54158 = _9TRUE_430;
L5: 
L4: 
L3: 

    /** 		tok = rexpr()*/
    _0 = _tok_56210;
    _tok_56210 = _30rexpr();
    DeRef(_0);

    /** 		if id != -1 then*/
    if (_id_56211 == -1)
    goto L8; // [123] 268

    /** 			if id != XOR then*/
    if (_id_56211 == 152)
    goto L9; // [131] 261

    /** 				if short_circuit > 0 then*/
    if (_30short_circuit_54156 <= 0)
    goto LA; // [139] 252

    /** 					if tok[T_ID] != THEN and tok[T_ID] != DO then*/
    _2 = (int)SEQ_PTR(_tok_56210);
    _28748 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_28748)) {
        _28749 = (_28748 != 410);
    }
    else {
        _28749 = binary_op(NOTEQ, _28748, 410);
    }
    _28748 = NOVALUE;
    if (IS_ATOM_INT(_28749)) {
        if (_28749 == 0) {
            goto LB; // [157] 206
        }
    }
    else {
        if (DBL_PTR(_28749)->dbl == 0.0) {
            goto LB; // [157] 206
        }
    }
    _2 = (int)SEQ_PTR(_tok_56210);
    _28751 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_28751)) {
        _28752 = (_28751 != 411);
    }
    else {
        _28752 = binary_op(NOTEQ, _28751, 411);
    }
    _28751 = NOVALUE;
    if (_28752 == 0) {
        DeRef(_28752);
        _28752 = NOVALUE;
        goto LB; // [174] 206
    }
    else {
        if (!IS_ATOM_INT(_28752) && DBL_PTR(_28752)->dbl == 0.0){
            DeRef(_28752);
            _28752 = NOVALUE;
            goto LB; // [174] 206
        }
        DeRef(_28752);
        _28752 = NOVALUE;
    }
    DeRef(_28752);
    _28752 = NOVALUE;

    /** 						if id = OR then*/
    if (_id_56211 != 9)
    goto LC; // [181] 195

    /** 							emit_op(SC2_OR)*/
    _37emit_op(144);
    goto LD; // [192] 219
LC: 

    /** 							emit_op(SC2_AND)*/
    _37emit_op(142);
    goto LD; // [203] 219
LB: 

    /** 						SC1_type = id -- if/while/elsif must patch*/
    _30SC1_type_54161 = _id_56211;

    /** 						emit_op(SC2_NULL)*/
    _37emit_op(145);
LD: 

    /** 					if TRANSLATE then*/
    if (_26TRANSLATE_11619 == 0)
    {
        goto LE; // [223] 234
    }
    else{
    }

    /** 						emit_op(NOP1)   -- to get label here*/
    _37emit_op(159);
LE: 

    /** 					backpatch(patch, length(Code)+1)*/
    if (IS_SEQUENCE(_26Code_12071)){
            _28754 = SEQ_PTR(_26Code_12071)->length;
    }
    else {
        _28754 = 1;
    }
    _28755 = _28754 + 1;
    _28754 = NOVALUE;
    _37backpatch(_patch_56212, _28755);
    _28755 = NOVALUE;
    goto LF; // [249] 267
LA: 

    /** 					emit_op(id)*/
    _37emit_op(_id_56211);
    goto LF; // [258] 267
L9: 

    /** 				emit_op(id)*/
    _37emit_op(_id_56211);
LF: 
L8: 

    /** 		id = tok[T_ID]*/
    _2 = (int)SEQ_PTR(_tok_56210);
    _id_56211 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_id_56211)){
        _id_56211 = (long)DBL_PTR(_id_56211)->dbl;
    }

    /** 		if not find(id, boolOps) then*/
    _28757 = find_from(_id_56211, _30boolOps_56200, 1);
    if (_28757 != 0)
    goto L1; // [287] 38
    _28757 = NOVALUE;

    /** 			exit*/
    goto L2; // [292] 300

    /** 	end while*/
    goto L1; // [297] 38
L2: 

    /** 	putback(tok)*/
    Ref(_tok_56210);
    _30putback(_tok_56210);

    /** 	SC1_patch = patch -- extra line*/
    _30SC1_patch_54160 = _patch_56212;

    /** end procedure*/
    DeRef(_tok_56210);
    DeRef(_28749);
    _28749 = NOVALUE;
    return;
    ;
}


void _30TypeCheck(int _var_56287)
{
    int _which_type_56288 = NOVALUE;
    int _ref_56298 = NOVALUE;
    int _ref_56331 = NOVALUE;
    int _28813 = NOVALUE;
    int _28812 = NOVALUE;
    int _28811 = NOVALUE;
    int _28810 = NOVALUE;
    int _28809 = NOVALUE;
    int _28807 = NOVALUE;
    int _28806 = NOVALUE;
    int _28805 = NOVALUE;
    int _28804 = NOVALUE;
    int _28803 = NOVALUE;
    int _28802 = NOVALUE;
    int _28800 = NOVALUE;
    int _28799 = NOVALUE;
    int _28796 = NOVALUE;
    int _28795 = NOVALUE;
    int _28794 = NOVALUE;
    int _28793 = NOVALUE;
    int _28788 = NOVALUE;
    int _28787 = NOVALUE;
    int _28783 = NOVALUE;
    int _28781 = NOVALUE;
    int _28780 = NOVALUE;
    int _28779 = NOVALUE;
    int _28777 = NOVALUE;
    int _28776 = NOVALUE;
    int _28775 = NOVALUE;
    int _28774 = NOVALUE;
    int _28773 = NOVALUE;
    int _28772 = NOVALUE;
    int _28769 = NOVALUE;
    int _28767 = NOVALUE;
    int _28765 = NOVALUE;
    int _28764 = NOVALUE;
    int _28763 = NOVALUE;
    int _28761 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if var < 0 or SymTab[var][S_SCOPE] = SC_UNDEFINED then*/
    _28761 = (_var_56287 < 0);
    if (_28761 != 0) {
        goto L1; // [9] 36
    }
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _28763 = (int)*(((s1_ptr)_2)->base + _var_56287);
    _2 = (int)SEQ_PTR(_28763);
    _28764 = (int)*(((s1_ptr)_2)->base + 4);
    _28763 = NOVALUE;
    if (IS_ATOM_INT(_28764)) {
        _28765 = (_28764 == 9);
    }
    else {
        _28765 = binary_op(EQUALS, _28764, 9);
    }
    _28764 = NOVALUE;
    if (_28765 == 0) {
        DeRef(_28765);
        _28765 = NOVALUE;
        goto L2; // [32] 76
    }
    else {
        if (!IS_ATOM_INT(_28765) && DBL_PTR(_28765)->dbl == 0.0){
            DeRef(_28765);
            _28765 = NOVALUE;
            goto L2; // [32] 76
        }
        DeRef(_28765);
        _28765 = NOVALUE;
    }
    DeRef(_28765);
    _28765 = NOVALUE;
L1: 

    /** 		integer ref = new_forward_reference( TYPE_CHECK, var, TYPE_CHECK_FORWARD )*/
    _ref_56298 = _29new_forward_reference(65, _var_56287, 197);
    if (!IS_ATOM_INT(_ref_56298)) {
        _1 = (long)(DBL_PTR(_ref_56298)->dbl);
        DeRefDS(_ref_56298);
        _ref_56298 = _1;
    }

    /** 		Code &= { TYPE_CHECK_FORWARD, var, OpTypeCheck }*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 197;
    *((int *)(_2+8)) = _var_56287;
    *((int *)(_2+12)) = _26OpTypeCheck_12053;
    _28767 = MAKE_SEQ(_1);
    Concat((object_ptr)&_26Code_12071, _26Code_12071, _28767);
    DeRefDS(_28767);
    _28767 = NOVALUE;

    /** 		return*/
    DeRef(_28761);
    _28761 = NOVALUE;
    return;
L2: 

    /** 	which_type = SymTab[var][S_VTYPE]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _28769 = (int)*(((s1_ptr)_2)->base + _var_56287);
    _2 = (int)SEQ_PTR(_28769);
    _which_type_56288 = (int)*(((s1_ptr)_2)->base + 15);
    if (!IS_ATOM_INT(_which_type_56288)){
        _which_type_56288 = (long)DBL_PTR(_which_type_56288)->dbl;
    }
    _28769 = NOVALUE;

    /** 	if which_type = 0 then*/
    if (_which_type_56288 != 0)
    goto L3; // [96] 106

    /** 		return	-- Not a typed identifier.*/
    DeRef(_28761);
    _28761 = NOVALUE;
    return;
L3: 

    /** 	if which_type > 0 and length(SymTab[which_type]) < S_TOKEN then*/
    _28772 = (_which_type_56288 > 0);
    if (_28772 == 0) {
        goto L4; // [112] 141
    }
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _28774 = (int)*(((s1_ptr)_2)->base + _which_type_56288);
    if (IS_SEQUENCE(_28774)){
            _28775 = SEQ_PTR(_28774)->length;
    }
    else {
        _28775 = 1;
    }
    _28774 = NOVALUE;
    if (IS_ATOM_INT(_26S_TOKEN_11659)) {
        _28776 = (_28775 < _26S_TOKEN_11659);
    }
    else {
        _28776 = binary_op(LESS, _28775, _26S_TOKEN_11659);
    }
    _28775 = NOVALUE;
    if (_28776 == 0) {
        DeRef(_28776);
        _28776 = NOVALUE;
        goto L4; // [132] 141
    }
    else {
        if (!IS_ATOM_INT(_28776) && DBL_PTR(_28776)->dbl == 0.0){
            DeRef(_28776);
            _28776 = NOVALUE;
            goto L4; // [132] 141
        }
        DeRef(_28776);
        _28776 = NOVALUE;
    }
    DeRef(_28776);
    _28776 = NOVALUE;

    /** 		return	-- Not a typed identifier.*/
    DeRef(_28761);
    _28761 = NOVALUE;
    DeRef(_28772);
    _28772 = NOVALUE;
    _28774 = NOVALUE;
    return;
L4: 

    /** 	if which_type < 0 or SymTab[which_type][S_TOKEN] = VARIABLE  then*/
    _28777 = (_which_type_56288 < 0);
    if (_28777 != 0) {
        goto L5; // [147] 174
    }
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _28779 = (int)*(((s1_ptr)_2)->base + _which_type_56288);
    _2 = (int)SEQ_PTR(_28779);
    if (!IS_ATOM_INT(_26S_TOKEN_11659)){
        _28780 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_TOKEN_11659)->dbl));
    }
    else{
        _28780 = (int)*(((s1_ptr)_2)->base + _26S_TOKEN_11659);
    }
    _28779 = NOVALUE;
    if (IS_ATOM_INT(_28780)) {
        _28781 = (_28780 == -100);
    }
    else {
        _28781 = binary_op(EQUALS, _28780, -100);
    }
    _28780 = NOVALUE;
    if (_28781 == 0) {
        DeRef(_28781);
        _28781 = NOVALUE;
        goto L6; // [170] 214
    }
    else {
        if (!IS_ATOM_INT(_28781) && DBL_PTR(_28781)->dbl == 0.0){
            DeRef(_28781);
            _28781 = NOVALUE;
            goto L6; // [170] 214
        }
        DeRef(_28781);
        _28781 = NOVALUE;
    }
    DeRef(_28781);
    _28781 = NOVALUE;
L5: 

    /** 		integer ref = new_forward_reference( TYPE_CHECK, which_type, TYPE )*/
    _ref_56331 = _29new_forward_reference(65, _which_type_56288, 504);
    if (!IS_ATOM_INT(_ref_56331)) {
        _1 = (long)(DBL_PTR(_ref_56331)->dbl);
        DeRefDS(_ref_56331);
        _ref_56331 = _1;
    }

    /** 		Code &= { TYPE_CHECK_FORWARD, var, OpTypeCheck }*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 197;
    *((int *)(_2+8)) = _var_56287;
    *((int *)(_2+12)) = _26OpTypeCheck_12053;
    _28783 = MAKE_SEQ(_1);
    Concat((object_ptr)&_26Code_12071, _26Code_12071, _28783);
    DeRefDS(_28783);
    _28783 = NOVALUE;

    /** 		return*/
    DeRef(_28761);
    _28761 = NOVALUE;
    DeRef(_28772);
    _28772 = NOVALUE;
    _28774 = NOVALUE;
    DeRef(_28777);
    _28777 = NOVALUE;
    return;
L6: 

    /** 	if TRANSLATE then*/
    if (_26TRANSLATE_11619 == 0)
    {
        goto L7; // [220] 317
    }
    else{
    }

    /** 		if OpTypeCheck then*/
    if (_26OpTypeCheck_12053 == 0)
    {
        goto L8; // [227] 481
    }
    else{
    }

    /** 			switch which_type do*/
    if( _30_56345_cases == 0 ){
        _30_56345_cases = 1;
        SEQ_PTR( _28785 )->base[1] = _52object_type_46130;
        SEQ_PTR( _28785 )->base[2] = _52sequence_type_46134;
        SEQ_PTR( _28785 )->base[3] = _52atom_type_46132;
        SEQ_PTR( _28785 )->base[4] = _52integer_type_46136;
    }
    _1 = find(_which_type_56288, _28785);
    switch ( _1 ){ 

        /** 				case object_type, sequence_type, atom_type then*/
        case 1:
        case 2:
        case 3:

        /** 				case integer_type then*/
        goto L8; // [247] 481
        case 4:

        /** 					op_info1 = var*/
        _37op_info1_50262 = _var_56287;

        /** 					emit_op(INTEGER_CHECK)*/
        _37emit_op(96);
        goto L8; // [265] 481

        /** 				case else*/
        case 0:

        /** 					if SymTab[which_type][S_EFFECT] then*/
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _28787 = (int)*(((s1_ptr)_2)->base + _which_type_56288);
        _2 = (int)SEQ_PTR(_28787);
        _28788 = (int)*(((s1_ptr)_2)->base + 23);
        _28787 = NOVALUE;
        if (_28788 == 0) {
            _28788 = NOVALUE;
            goto L9; // [285] 312
        }
        else {
            if (!IS_ATOM_INT(_28788) && DBL_PTR(_28788)->dbl == 0.0){
                _28788 = NOVALUE;
                goto L9; // [285] 312
            }
            _28788 = NOVALUE;
        }
        _28788 = NOVALUE;

        /** 						emit_opnd(var)*/
        _37emit_opnd(_var_56287);

        /** 						op_info1 = which_type*/
        _37op_info1_50262 = _which_type_56288;

        /** 						emit_or_inline()*/
        _66emit_or_inline();

        /** 						emit_op(TYPE_CHECK)*/
        _37emit_op(65);
L9: 
    ;}    goto L8; // [314] 481
L7: 

    /** 		if OpTypeCheck then*/
    if (_26OpTypeCheck_12053 == 0)
    {
        goto LA; // [321] 480
    }
    else{
    }

    /** 			if which_type != object_type then*/
    if (_which_type_56288 == _52object_type_46130)
    goto LB; // [328] 479

    /** 				if which_type = integer_type then*/
    if (_which_type_56288 != _52integer_type_46136)
    goto LC; // [336] 357

    /** 						op_info1 = var*/
    _37op_info1_50262 = _var_56287;

    /** 						emit_op(INTEGER_CHECK)*/
    _37emit_op(96);
    goto LD; // [354] 478
LC: 

    /** 				elsif which_type = sequence_type then*/
    if (_which_type_56288 != _52sequence_type_46134)
    goto LE; // [361] 382

    /** 						op_info1 = var*/
    _37op_info1_50262 = _var_56287;

    /** 						emit_op(SEQUENCE_CHECK)*/
    _37emit_op(97);
    goto LD; // [379] 478
LE: 

    /** 				elsif which_type = atom_type then*/
    if (_which_type_56288 != _52atom_type_46132)
    goto LF; // [386] 407

    /** 						op_info1 = var*/
    _37op_info1_50262 = _var_56287;

    /** 						emit_op(ATOM_CHECK)*/
    _37emit_op(101);
    goto LD; // [404] 478
LF: 

    /** 						if SymTab[SymTab[which_type][S_NEXT]][S_VTYPE] =*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _28793 = (int)*(((s1_ptr)_2)->base + _which_type_56288);
    _2 = (int)SEQ_PTR(_28793);
    _28794 = (int)*(((s1_ptr)_2)->base + 2);
    _28793 = NOVALUE;
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!IS_ATOM_INT(_28794)){
        _28795 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_28794)->dbl));
    }
    else{
        _28795 = (int)*(((s1_ptr)_2)->base + _28794);
    }
    _2 = (int)SEQ_PTR(_28795);
    _28796 = (int)*(((s1_ptr)_2)->base + 15);
    _28795 = NOVALUE;
    if (binary_op_a(NOTEQ, _28796, _52integer_type_46136)){
        _28796 = NOVALUE;
        goto L10; // [435] 454
    }
    _28796 = NOVALUE;

    /** 							op_info1 = var*/
    _37op_info1_50262 = _var_56287;

    /** 							emit_op(INTEGER_CHECK) -- need integer conversion*/
    _37emit_op(96);
L10: 

    /** 						emit_opnd(var)*/
    _37emit_opnd(_var_56287);

    /** 						op_info1 = which_type*/
    _37op_info1_50262 = _which_type_56288;

    /** 						emit_or_inline()*/
    _66emit_or_inline();

    /** 						emit_op(TYPE_CHECK)*/
    _37emit_op(65);
LD: 
LB: 
LA: 
L8: 

    /** 	if TRANSLATE or not OpTypeCheck then*/
    if (_26TRANSLATE_11619 != 0) {
        goto L11; // [485] 499
    }
    _28799 = (_26OpTypeCheck_12053 == 0);
    if (_28799 == 0)
    {
        DeRef(_28799);
        _28799 = NOVALUE;
        goto L12; // [495] 620
    }
    else{
        DeRef(_28799);
        _28799 = NOVALUE;
    }
L11: 

    /** 		op_info1 = var*/
    _37op_info1_50262 = _var_56287;

    /** 		if which_type = sequence_type or*/
    _28800 = (_which_type_56288 == _52sequence_type_46134);
    if (_28800 != 0) {
        goto L13; // [514] 553
    }
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _28802 = (int)*(((s1_ptr)_2)->base + _which_type_56288);
    _2 = (int)SEQ_PTR(_28802);
    _28803 = (int)*(((s1_ptr)_2)->base + 2);
    _28802 = NOVALUE;
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!IS_ATOM_INT(_28803)){
        _28804 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_28803)->dbl));
    }
    else{
        _28804 = (int)*(((s1_ptr)_2)->base + _28803);
    }
    _2 = (int)SEQ_PTR(_28804);
    _28805 = (int)*(((s1_ptr)_2)->base + 15);
    _28804 = NOVALUE;
    if (IS_ATOM_INT(_28805)) {
        _28806 = (_28805 == _52sequence_type_46134);
    }
    else {
        _28806 = binary_op(EQUALS, _28805, _52sequence_type_46134);
    }
    _28805 = NOVALUE;
    if (_28806 == 0) {
        DeRef(_28806);
        _28806 = NOVALUE;
        goto L14; // [549] 563
    }
    else {
        if (!IS_ATOM_INT(_28806) && DBL_PTR(_28806)->dbl == 0.0){
            DeRef(_28806);
            _28806 = NOVALUE;
            goto L14; // [549] 563
        }
        DeRef(_28806);
        _28806 = NOVALUE;
    }
    DeRef(_28806);
    _28806 = NOVALUE;
L13: 

    /** 			emit_op(SEQUENCE_CHECK)*/
    _37emit_op(97);
    goto L15; // [560] 619
L14: 

    /** 		elsif which_type = integer_type or*/
    _28807 = (_which_type_56288 == _52integer_type_46136);
    if (_28807 != 0) {
        goto L16; // [571] 610
    }
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _28809 = (int)*(((s1_ptr)_2)->base + _which_type_56288);
    _2 = (int)SEQ_PTR(_28809);
    _28810 = (int)*(((s1_ptr)_2)->base + 2);
    _28809 = NOVALUE;
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!IS_ATOM_INT(_28810)){
        _28811 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_28810)->dbl));
    }
    else{
        _28811 = (int)*(((s1_ptr)_2)->base + _28810);
    }
    _2 = (int)SEQ_PTR(_28811);
    _28812 = (int)*(((s1_ptr)_2)->base + 15);
    _28811 = NOVALUE;
    if (IS_ATOM_INT(_28812)) {
        _28813 = (_28812 == _52integer_type_46136);
    }
    else {
        _28813 = binary_op(EQUALS, _28812, _52integer_type_46136);
    }
    _28812 = NOVALUE;
    if (_28813 == 0) {
        DeRef(_28813);
        _28813 = NOVALUE;
        goto L17; // [606] 618
    }
    else {
        if (!IS_ATOM_INT(_28813) && DBL_PTR(_28813)->dbl == 0.0){
            DeRef(_28813);
            _28813 = NOVALUE;
            goto L17; // [606] 618
        }
        DeRef(_28813);
        _28813 = NOVALUE;
    }
    DeRef(_28813);
    _28813 = NOVALUE;
L16: 

    /** 			emit_op(INTEGER_CHECK)*/
    _37emit_op(96);
L17: 
L15: 
L12: 

    /** end procedure*/
    DeRef(_28761);
    _28761 = NOVALUE;
    DeRef(_28772);
    _28772 = NOVALUE;
    _28774 = NOVALUE;
    DeRef(_28777);
    _28777 = NOVALUE;
    _28794 = NOVALUE;
    DeRef(_28800);
    _28800 = NOVALUE;
    _28803 = NOVALUE;
    DeRef(_28807);
    _28807 = NOVALUE;
    _28810 = NOVALUE;
    return;
    ;
}


void _30Assignment(int _left_var_56452)
{
    int _tok_56454 = NOVALUE;
    int _subs_56455 = NOVALUE;
    int _slice_56456 = NOVALUE;
    int _assign_op_56457 = NOVALUE;
    int _subs1_patch_56458 = NOVALUE;
    int _dangerous_56460 = NOVALUE;
    int _lname_56584 = NOVALUE;
    int _temp_len_56601 = NOVALUE;
    int _28912 = NOVALUE;
    int _28911 = NOVALUE;
    int _28910 = NOVALUE;
    int _28909 = NOVALUE;
    int _28908 = NOVALUE;
    int _28907 = NOVALUE;
    int _28906 = NOVALUE;
    int _28905 = NOVALUE;
    int _28896 = NOVALUE;
    int _28895 = NOVALUE;
    int _28894 = NOVALUE;
    int _28893 = NOVALUE;
    int _28892 = NOVALUE;
    int _28891 = NOVALUE;
    int _28890 = NOVALUE;
    int _28889 = NOVALUE;
    int _28888 = NOVALUE;
    int _28887 = NOVALUE;
    int _28886 = NOVALUE;
    int _28885 = NOVALUE;
    int _28884 = NOVALUE;
    int _28883 = NOVALUE;
    int _28882 = NOVALUE;
    int _28880 = NOVALUE;
    int _28879 = NOVALUE;
    int _28878 = NOVALUE;
    int _28876 = NOVALUE;
    int _28871 = NOVALUE;
    int _28870 = NOVALUE;
    int _28867 = NOVALUE;
    int _28866 = NOVALUE;
    int _28864 = NOVALUE;
    int _28858 = NOVALUE;
    int _28853 = NOVALUE;
    int _28850 = NOVALUE;
    int _28849 = NOVALUE;
    int _28846 = NOVALUE;
    int _28843 = NOVALUE;
    int _28842 = NOVALUE;
    int _28841 = NOVALUE;
    int _28839 = NOVALUE;
    int _28838 = NOVALUE;
    int _28837 = NOVALUE;
    int _28836 = NOVALUE;
    int _28835 = NOVALUE;
    int _28834 = NOVALUE;
    int _28832 = NOVALUE;
    int _28831 = NOVALUE;
    int _28830 = NOVALUE;
    int _28829 = NOVALUE;
    int _28827 = NOVALUE;
    int _28826 = NOVALUE;
    int _28825 = NOVALUE;
    int _28824 = NOVALUE;
    int _28823 = NOVALUE;
    int _28821 = NOVALUE;
    int _28820 = NOVALUE;
    int _28819 = NOVALUE;
    int _28816 = NOVALUE;
    int _28815 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	integer subs, slice, assign_op, subs1_patch*/

    /** 	left_sym = left_var[T_SYM]*/
    _2 = (int)SEQ_PTR(_left_var_56452);
    _30left_sym_54197 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_30left_sym_54197)){
        _30left_sym_54197 = (long)DBL_PTR(_30left_sym_54197)->dbl;
    }

    /** 	if SymTab[left_sym][S_SCOPE] = SC_UNDEFINED then*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _28815 = (int)*(((s1_ptr)_2)->base + _30left_sym_54197);
    _2 = (int)SEQ_PTR(_28815);
    _28816 = (int)*(((s1_ptr)_2)->base + 4);
    _28815 = NOVALUE;
    if (binary_op_a(NOTEQ, _28816, 9)){
        _28816 = NOVALUE;
        goto L1; // [31] 54
    }
    _28816 = NOVALUE;

    /** 		Forward_var( left_var, ,ASSIGN )*/
    Ref(_left_var_56452);
    _30Forward_var(_left_var_56452, -1, 18);

    /** 		left_sym = Pop() -- pops off what forward var emitted, because it gets emitted later*/
    _0 = _37Pop();
    _30left_sym_54197 = _0;
    if (!IS_ATOM_INT(_30left_sym_54197)) {
        _1 = (long)(DBL_PTR(_30left_sym_54197)->dbl);
        DeRefDS(_30left_sym_54197);
        _30left_sym_54197 = _1;
    }
    goto L2; // [51] 267
L1: 

    /** 		UndefinedVar(left_sym)*/
    _30UndefinedVar(_30left_sym_54197);

    /** 		if SymTab[left_sym][S_SCOPE] = SC_LOOP_VAR or*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _28819 = (int)*(((s1_ptr)_2)->base + _30left_sym_54197);
    _2 = (int)SEQ_PTR(_28819);
    _28820 = (int)*(((s1_ptr)_2)->base + 4);
    _28819 = NOVALUE;
    if (IS_ATOM_INT(_28820)) {
        _28821 = (_28820 == 2);
    }
    else {
        _28821 = binary_op(EQUALS, _28820, 2);
    }
    _28820 = NOVALUE;
    if (IS_ATOM_INT(_28821)) {
        if (_28821 != 0) {
            goto L3; // [83] 112
        }
    }
    else {
        if (DBL_PTR(_28821)->dbl != 0.0) {
            goto L3; // [83] 112
        }
    }
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _28823 = (int)*(((s1_ptr)_2)->base + _30left_sym_54197);
    _2 = (int)SEQ_PTR(_28823);
    _28824 = (int)*(((s1_ptr)_2)->base + 4);
    _28823 = NOVALUE;
    if (IS_ATOM_INT(_28824)) {
        _28825 = (_28824 == 4);
    }
    else {
        _28825 = binary_op(EQUALS, _28824, 4);
    }
    _28824 = NOVALUE;
    if (_28825 == 0) {
        DeRef(_28825);
        _28825 = NOVALUE;
        goto L4; // [108] 122
    }
    else {
        if (!IS_ATOM_INT(_28825) && DBL_PTR(_28825)->dbl == 0.0){
            DeRef(_28825);
            _28825 = NOVALUE;
            goto L4; // [108] 122
        }
        DeRef(_28825);
        _28825 = NOVALUE;
    }
    DeRef(_28825);
    _28825 = NOVALUE;
L3: 

    /** 			CompileErr(109)*/
    RefDS(_22037);
    _43CompileErr(109, _22037, 0);
    goto L5; // [119] 229
L4: 

    /** 		elsif SymTab[left_sym][S_MODE] = M_CONSTANT then*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _28826 = (int)*(((s1_ptr)_2)->base + _30left_sym_54197);
    _2 = (int)SEQ_PTR(_28826);
    _28827 = (int)*(((s1_ptr)_2)->base + 3);
    _28826 = NOVALUE;
    if (binary_op_a(NOTEQ, _28827, 2)){
        _28827 = NOVALUE;
        goto L6; // [140] 154
    }
    _28827 = NOVALUE;

    /** 			CompileErr(110)*/
    RefDS(_22037);
    _43CompileErr(110, _22037, 0);
    goto L5; // [151] 229
L6: 

    /** 		elsif find(SymTab[left_sym][S_SCOPE], SCOPE_TYPES) then*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _28829 = (int)*(((s1_ptr)_2)->base + _30left_sym_54197);
    _2 = (int)SEQ_PTR(_28829);
    _28830 = (int)*(((s1_ptr)_2)->base + 4);
    _28829 = NOVALUE;
    _28831 = find_from(_28830, _30SCOPE_TYPES_54147, 1);
    _28830 = NOVALUE;
    if (_28831 == 0)
    {
        _28831 = NOVALUE;
        goto L7; // [177] 228
    }
    else{
        _28831 = NOVALUE;
    }

    /** 			SymTab[CurrentSub][S_EFFECT] = or_bits(SymTab[CurrentSub][S_EFFECT],*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_26CurrentSub_11990 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _28834 = (int)*(((s1_ptr)_2)->base + _26CurrentSub_11990);
    _2 = (int)SEQ_PTR(_28834);
    _28835 = (int)*(((s1_ptr)_2)->base + 23);
    _28834 = NOVALUE;
    _28836 = (_30left_sym_54197 % 29);
    _28837 = power(2, _28836);
    _28836 = NOVALUE;
    if (IS_ATOM_INT(_28835) && IS_ATOM_INT(_28837)) {
        {unsigned long tu;
             tu = (unsigned long)_28835 | (unsigned long)_28837;
             _28838 = MAKE_UINT(tu);
        }
    }
    else {
        _28838 = binary_op(OR_BITS, _28835, _28837);
    }
    _28835 = NOVALUE;
    DeRef(_28837);
    _28837 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 23);
    _1 = *(int *)_2;
    *(int *)_2 = _28838;
    if( _1 != _28838 ){
        DeRef(_1);
    }
    _28838 = NOVALUE;
    _28832 = NOVALUE;
L7: 
L5: 

    /** 		SymTab[left_sym][S_USAGE] = or_bits(SymTab[left_sym][S_USAGE], U_WRITTEN)*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_30left_sym_54197 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _28841 = (int)*(((s1_ptr)_2)->base + _30left_sym_54197);
    _2 = (int)SEQ_PTR(_28841);
    _28842 = (int)*(((s1_ptr)_2)->base + 5);
    _28841 = NOVALUE;
    if (IS_ATOM_INT(_28842)) {
        {unsigned long tu;
             tu = (unsigned long)_28842 | (unsigned long)2;
             _28843 = MAKE_UINT(tu);
        }
    }
    else {
        _28843 = binary_op(OR_BITS, _28842, 2);
    }
    _28842 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = _28843;
    if( _1 != _28843 ){
        DeRef(_1);
    }
    _28843 = NOVALUE;
    _28839 = NOVALUE;
L2: 

    /** 	tok = next_token()*/
    _0 = _tok_56454;
    _tok_56454 = _30next_token();
    DeRef(_0);

    /** 	subs = 0*/
    _subs_56455 = 0;

    /** 	slice = FALSE*/
    _slice_56456 = _9FALSE_428;

    /** 	dangerous = FALSE*/
    _dangerous_56460 = _9FALSE_428;

    /** 	side_effect_calls = 0*/
    _30side_effect_calls_54193 = 0;

    /** 	emit_opnd(left_sym)*/
    _37emit_opnd(_30left_sym_54197);

    /** 	current_sequence = append(current_sequence, left_sym)*/
    Append(&_37current_sequence_50270, _37current_sequence_50270, _30left_sym_54197);

    /** 	while tok[T_ID] = LEFT_SQUARE do*/
L8: 
    _2 = (int)SEQ_PTR(_tok_56454);
    _28846 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28846, -28)){
        _28846 = NOVALUE;
        goto L9; // [330] 522
    }
    _28846 = NOVALUE;

    /** 		subs_depth += 1*/
    _30subs_depth_54198 = _30subs_depth_54198 + 1;

    /** 		if lhs_ptr then*/
    if (_37lhs_ptr_50272 == 0)
    {
        goto LA; // [346] 404
    }
    else{
    }

    /** 			current_sequence = head( current_sequence, length( current_sequence ) - 1 )*/
    if (IS_SEQUENCE(_37current_sequence_50270)){
            _28849 = SEQ_PTR(_37current_sequence_50270)->length;
    }
    else {
        _28849 = 1;
    }
    _28850 = _28849 - 1;
    _28849 = NOVALUE;
    {
        int len = SEQ_PTR(_37current_sequence_50270)->length;
        int size = (IS_ATOM_INT(_28850)) ? _28850 : (long)(DBL_PTR(_28850)->dbl);
        if (size <= 0) _37current_sequence_50270 = MAKE_SEQ(NewS1(0));
        else if (len <= size) {
            RefDS(_37current_sequence_50270);
            DeRef(_37current_sequence_50270);
            _37current_sequence_50270 = _37current_sequence_50270;
        }
        else Head(SEQ_PTR(_37current_sequence_50270),size+1,&_37current_sequence_50270);
    }
    _28850 = NOVALUE;

    /** 			if subs = 1 then*/
    if (_subs_56455 != 1)
    goto LB; // [370] 395

    /** 				subs1_patch = length(Code)+1*/
    if (IS_SEQUENCE(_26Code_12071)){
            _28853 = SEQ_PTR(_26Code_12071)->length;
    }
    else {
        _28853 = 1;
    }
    _subs1_patch_56458 = _28853 + 1;
    _28853 = NOVALUE;

    /** 				emit_op(LHS_SUBS1) -- creates new current_sequence*/
    _37emit_op(161);
    goto LC; // [392] 403
LB: 

    /** 				emit_op(LHS_SUBS) -- adds to current_sequence*/
    _37emit_op(95);
LC: 
LA: 

    /** 		subs += 1*/
    _subs_56455 = _subs_56455 + 1;

    /** 		if subs = 1 then*/
    if (_subs_56455 != 1)
    goto LD; // [412] 427

    /** 			InitCheck(left_sym, TRUE)*/
    _30InitCheck(_30left_sym_54197, _9TRUE_430);
LD: 

    /** 		Expr()*/
    _30Expr();

    /** 		tok = next_token()*/
    _0 = _tok_56454;
    _tok_56454 = _30next_token();
    DeRef(_0);

    /** 		if tok[T_ID] = SLICE then*/
    _2 = (int)SEQ_PTR(_tok_56454);
    _28858 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28858, 513)){
        _28858 = NOVALUE;
        goto LE; // [446] 483
    }
    _28858 = NOVALUE;

    /** 			Expr()*/
    _30Expr();

    /** 			slice = TRUE*/
    _slice_56456 = _9TRUE_430;

    /** 			tok_match(RIGHT_SQUARE)*/
    _30tok_match(-29, 0);

    /** 			tok = next_token()*/
    _0 = _tok_56454;
    _tok_56454 = _30next_token();
    DeRef(_0);

    /** 			exit  -- no further subs or slices allowed*/
    goto L9; // [478] 522
    goto LF; // [480] 505
LE: 

    /** 			putback(tok)*/
    Ref(_tok_56454);
    _30putback(_tok_56454);

    /** 			tok_match(RIGHT_SQUARE)*/
    _30tok_match(-29, 0);

    /** 			subs_depth -= 1*/
    _30subs_depth_54198 = _30subs_depth_54198 - 1;
LF: 

    /** 		tok = next_token()*/
    _0 = _tok_56454;
    _tok_56454 = _30next_token();
    DeRef(_0);

    /** 		lhs_ptr = TRUE*/
    _37lhs_ptr_50272 = _9TRUE_430;

    /** 	end while*/
    goto L8; // [519] 322
L9: 

    /** 	lhs_ptr = FALSE*/
    _37lhs_ptr_50272 = _9FALSE_428;

    /** 	assign_op = tok[T_ID]*/
    _2 = (int)SEQ_PTR(_tok_56454);
    _assign_op_56457 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_assign_op_56457)){
        _assign_op_56457 = (long)DBL_PTR(_assign_op_56457)->dbl;
    }

    /** 	if not find(assign_op, ASSIGN_OPS) then*/
    _28864 = find_from(_assign_op_56457, _30ASSIGN_OPS_54139, 1);
    if (_28864 != 0)
    goto L10; // [548] 608
    _28864 = NOVALUE;

    /** 		sequence lname = SymTab[left_var[T_SYM]][S_NAME]*/
    _2 = (int)SEQ_PTR(_left_var_56452);
    _28866 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!IS_ATOM_INT(_28866)){
        _28867 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_28866)->dbl));
    }
    else{
        _28867 = (int)*(((s1_ptr)_2)->base + _28866);
    }
    DeRef(_lname_56584);
    _2 = (int)SEQ_PTR(_28867);
    if (!IS_ATOM_INT(_26S_NAME_11654)){
        _lname_56584 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NAME_11654)->dbl));
    }
    else{
        _lname_56584 = (int)*(((s1_ptr)_2)->base + _26S_NAME_11654);
    }
    Ref(_lname_56584);
    _28867 = NOVALUE;

    /** 		if assign_op = COLON then*/
    if (_assign_op_56457 != -23)
    goto L11; // [577] 595

    /** 			CompileErr(133, {lname})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_lname_56584);
    *((int *)(_2+4)) = _lname_56584;
    _28870 = MAKE_SEQ(_1);
    _43CompileErr(133, _28870, 0);
    _28870 = NOVALUE;
    goto L12; // [592] 607
L11: 

    /** 			CompileErr(76, {lname})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_lname_56584);
    *((int *)(_2+4)) = _lname_56584;
    _28871 = MAKE_SEQ(_1);
    _43CompileErr(76, _28871, 0);
    _28871 = NOVALUE;
L12: 
L10: 
    DeRef(_lname_56584);
    _lname_56584 = NOVALUE;

    /** 	if subs = 0 then*/
    if (_subs_56455 != 0)
    goto L13; // [612] 740

    /** 		integer temp_len = length(Code)*/
    if (IS_SEQUENCE(_26Code_12071)){
            _temp_len_56601 = SEQ_PTR(_26Code_12071)->length;
    }
    else {
        _temp_len_56601 = 1;
    }

    /** 		if assign_op = EQUALS then*/
    if (_assign_op_56457 != 3)
    goto L14; // [627] 648

    /** 			Expr() -- RHS expression*/
    _30Expr();

    /** 			InitCheck(left_sym, FALSE)*/
    _30InitCheck(_30left_sym_54197, _9FALSE_428);
    goto L15; // [645] 721
L14: 

    /** 			InitCheck(left_sym, TRUE)*/
    _30InitCheck(_30left_sym_54197, _9TRUE_430);

    /** 			if left_sym > 0 then*/
    if (_30left_sym_54197 <= 0)
    goto L16; // [662] 704

    /** 				SymTab[left_sym][S_USAGE] = or_bits(SymTab[left_sym][S_USAGE], U_READ)*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_30left_sym_54197 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _28878 = (int)*(((s1_ptr)_2)->base + _30left_sym_54197);
    _2 = (int)SEQ_PTR(_28878);
    _28879 = (int)*(((s1_ptr)_2)->base + 5);
    _28878 = NOVALUE;
    if (IS_ATOM_INT(_28879)) {
        {unsigned long tu;
             tu = (unsigned long)_28879 | (unsigned long)1;
             _28880 = MAKE_UINT(tu);
        }
    }
    else {
        _28880 = binary_op(OR_BITS, _28879, 1);
    }
    _28879 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = _28880;
    if( _1 != _28880 ){
        DeRef(_1);
    }
    _28880 = NOVALUE;
    _28876 = NOVALUE;
L16: 

    /** 			emit_opnd(left_sym)*/
    _37emit_opnd(_30left_sym_54197);

    /** 			Expr() -- RHS expression*/
    _30Expr();

    /** 			emit_assign_op(assign_op)*/
    _37emit_assign_op(_assign_op_56457);
L15: 

    /** 		emit_op(ASSIGN)*/
    _37emit_op(18);

    /** 		TypeCheck(left_sym)*/
    _30TypeCheck(_30left_sym_54197);
    goto L17; // [737] 1164
L13: 

    /** 		factors = 0*/
    _30factors_54194 = 0;

    /** 		lhs_subs_level = -1*/
    _30lhs_subs_level_54195 = -1;

    /** 		Expr() -- RHS expression*/
    _30Expr();

    /** 		if subs > 1 then*/
    if (_subs_56455 <= 1)
    goto L18; // [756] 895

    /** 			if left_sym < 0 or SymTab[left_sym][S_SCOPE] != SC_PRIVATE and*/
    _28882 = (_30left_sym_54197 < 0);
    if (_28882 != 0) {
        _28883 = 1;
        goto L19; // [768] 796
    }
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _28884 = (int)*(((s1_ptr)_2)->base + _30left_sym_54197);
    _2 = (int)SEQ_PTR(_28884);
    _28885 = (int)*(((s1_ptr)_2)->base + 4);
    _28884 = NOVALUE;
    if (IS_ATOM_INT(_28885)) {
        _28886 = (_28885 != 3);
    }
    else {
        _28886 = binary_op(NOTEQ, _28885, 3);
    }
    _28885 = NOVALUE;
    if (IS_ATOM_INT(_28886))
    _28883 = (_28886 != 0);
    else
    _28883 = DBL_PTR(_28886)->dbl != 0.0;
L19: 
    if (_28883 == 0) {
        goto L1A; // [796] 830
    }
    _28888 = (_30left_sym_54197 % 29);
    _28889 = power(2, _28888);
    _28888 = NOVALUE;
    if (IS_ATOM_INT(_28889)) {
        {unsigned long tu;
             tu = (unsigned long)_30side_effect_calls_54193 & (unsigned long)_28889;
             _28890 = MAKE_UINT(tu);
        }
    }
    else {
        temp_d.dbl = (double)_30side_effect_calls_54193;
        _28890 = Dand_bits(&temp_d, DBL_PTR(_28889));
    }
    DeRef(_28889);
    _28889 = NOVALUE;
    if (_28890 == 0) {
        DeRef(_28890);
        _28890 = NOVALUE;
        goto L1A; // [819] 830
    }
    else {
        if (!IS_ATOM_INT(_28890) && DBL_PTR(_28890)->dbl == 0.0){
            DeRef(_28890);
            _28890 = NOVALUE;
            goto L1A; // [819] 830
        }
        DeRef(_28890);
        _28890 = NOVALUE;
    }
    DeRef(_28890);
    _28890 = NOVALUE;

    /** 				dangerous = TRUE*/
    _dangerous_56460 = _9TRUE_430;
L1A: 

    /** 			if factors = 1 and*/
    _28891 = (_30factors_54194 == 1);
    if (_28891 == 0) {
        _28892 = 0;
        goto L1B; // [838] 852
    }
    _28893 = (_30lhs_subs_level_54195 >= 0);
    _28892 = (_28893 != 0);
L1B: 
    if (_28892 == 0) {
        goto L1C; // [852] 878
    }
    _28895 = _subs_56455 + _slice_56456;
    if ((long)((unsigned long)_28895 + (unsigned long)HIGH_BITS) >= 0) 
    _28895 = NewDouble((double)_28895);
    if (IS_ATOM_INT(_28895)) {
        _28896 = (_30lhs_subs_level_54195 < _28895);
    }
    else {
        _28896 = ((double)_30lhs_subs_level_54195 < DBL_PTR(_28895)->dbl);
    }
    DeRef(_28895);
    _28895 = NOVALUE;
    if (_28896 == 0)
    {
        DeRef(_28896);
        _28896 = NOVALUE;
        goto L1C; // [867] 878
    }
    else{
        DeRef(_28896);
        _28896 = NOVALUE;
    }

    /** 				dangerous = TRUE*/
    _dangerous_56460 = _9TRUE_430;
L1C: 

    /** 			if dangerous then*/
    if (_dangerous_56460 == 0)
    {
        goto L1D; // [880] 894
    }
    else{
    }

    /** 				backpatch(subs1_patch, LHS_SUBS1_COPY)*/
    _37backpatch(_subs1_patch_56458, 166);
L1D: 
L18: 

    /** 		if slice then*/
    if (_slice_56456 == 0)
    {
        goto L1E; // [897] 965
    }
    else{
    }

    /** 			if assign_op != EQUALS then*/
    if (_assign_op_56457 == 3)
    goto L1F; // [904] 938

    /** 				if subs = 1 then*/
    if (_subs_56455 != 1)
    goto L20; // [910] 924

    /** 					emit_op(ASSIGN_OP_SLICE)*/
    _37emit_op(150);
    goto L21; // [921] 932
L20: 

    /** 					emit_op(PASSIGN_OP_SLICE)*/
    _37emit_op(165);
L21: 

    /** 				emit_assign_op(assign_op)*/
    _37emit_assign_op(_assign_op_56457);
L1F: 

    /** 			if subs = 1 then*/
    if (_subs_56455 != 1)
    goto L22; // [940] 954

    /** 				emit_op(ASSIGN_SLICE)*/
    _37emit_op(45);
    goto L23; // [951] 1055
L22: 

    /** 				emit_op(PASSIGN_SLICE)*/
    _37emit_op(163);
    goto L23; // [962] 1055
L1E: 

    /** 			if assign_op = EQUALS then*/
    if (_assign_op_56457 != 3)
    goto L24; // [969] 1000

    /** 				if subs = 1 then*/
    if (_subs_56455 != 1)
    goto L25; // [975] 989

    /** 					emit_op(ASSIGN_SUBS)*/
    _37emit_op(16);
    goto L26; // [986] 1054
L25: 

    /** 					emit_op(PASSIGN_SUBS)*/
    _37emit_op(162);
    goto L26; // [997] 1054
L24: 

    /** 				if subs = 1 then*/
    if (_subs_56455 != 1)
    goto L27; // [1002] 1016

    /** 					emit_op(ASSIGN_OP_SUBS)*/
    _37emit_op(149);
    goto L28; // [1013] 1024
L27: 

    /** 					emit_op(PASSIGN_OP_SUBS)*/
    _37emit_op(164);
L28: 

    /** 				emit_assign_op(assign_op)*/
    _37emit_assign_op(_assign_op_56457);

    /** 				if subs = 1 then*/
    if (_subs_56455 != 1)
    goto L29; // [1031] 1045

    /** 					emit_op(ASSIGN_SUBS2)*/
    _37emit_op(148);
    goto L2A; // [1042] 1053
L29: 

    /** 					emit_op(PASSIGN_SUBS)*/
    _37emit_op(162);
L2A: 
L26: 
L23: 

    /** 		if subs > 1 then*/
    if (_subs_56455 <= 1)
    goto L2B; // [1057] 1109

    /** 			if dangerous then*/
    if (_dangerous_56460 == 0)
    {
        goto L2C; // [1063] 1100
    }
    else{
    }

    /** 				emit_opnd(left_sym)*/
    _37emit_opnd(_30left_sym_54197);

    /** 				emit_opnd(lhs_subs1_copy_temp) -- will be freed*/
    _37emit_opnd(_37lhs_subs1_copy_temp_50275);

    /** 				emit_temp( lhs_subs1_copy_temp, NEW_REFERENCE )*/
    _37emit_temp(_37lhs_subs1_copy_temp_50275, 1);

    /** 				emit_op(ASSIGN)*/
    _37emit_op(18);
    goto L2D; // [1097] 1108
L2C: 

    /** 				TempFree(lhs_subs1_copy_temp)*/
    _37TempFree(_37lhs_subs1_copy_temp_50275);
L2D: 
L2B: 

    /** 		if OpTypeCheck and (left_sym < 0 or SymTab[left_sym][S_VTYPE] != sequence_type) then*/
    if (_26OpTypeCheck_12053 == 0) {
        goto L2E; // [1113] 1163
    }
    _28906 = (_30left_sym_54197 < 0);
    if (_28906 != 0) {
        DeRef(_28907);
        _28907 = 1;
        goto L2F; // [1123] 1151
    }
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _28908 = (int)*(((s1_ptr)_2)->base + _30left_sym_54197);
    _2 = (int)SEQ_PTR(_28908);
    _28909 = (int)*(((s1_ptr)_2)->base + 15);
    _28908 = NOVALUE;
    if (IS_ATOM_INT(_28909)) {
        _28910 = (_28909 != _52sequence_type_46134);
    }
    else {
        _28910 = binary_op(NOTEQ, _28909, _52sequence_type_46134);
    }
    _28909 = NOVALUE;
    if (IS_ATOM_INT(_28910))
    _28907 = (_28910 != 0);
    else
    _28907 = DBL_PTR(_28910)->dbl != 0.0;
L2F: 
    if (_28907 == 0)
    {
        _28907 = NOVALUE;
        goto L2E; // [1152] 1163
    }
    else{
        _28907 = NOVALUE;
    }

    /** 			TypeCheck(left_sym)*/
    _30TypeCheck(_30left_sym_54197);
L2E: 
L17: 

    /** 	current_sequence = head( current_sequence, length( current_sequence ) - 1 )*/
    if (IS_SEQUENCE(_37current_sequence_50270)){
            _28911 = SEQ_PTR(_37current_sequence_50270)->length;
    }
    else {
        _28911 = 1;
    }
    _28912 = _28911 - 1;
    _28911 = NOVALUE;
    {
        int len = SEQ_PTR(_37current_sequence_50270)->length;
        int size = (IS_ATOM_INT(_28912)) ? _28912 : (long)(DBL_PTR(_28912)->dbl);
        if (size <= 0) _37current_sequence_50270 = MAKE_SEQ(NewS1(0));
        else if (len <= size) {
            RefDS(_37current_sequence_50270);
            DeRef(_37current_sequence_50270);
            _37current_sequence_50270 = _37current_sequence_50270;
        }
        else Head(SEQ_PTR(_37current_sequence_50270),size+1,&_37current_sequence_50270);
    }
    _28912 = NOVALUE;

    /** 	if not TRANSLATE then*/
    if (_26TRANSLATE_11619 != 0)
    goto L30; // [1187] 1213

    /** 		if OpTrace then*/
    if (_26OpTrace_12052 == 0)
    {
        goto L31; // [1194] 1212
    }
    else{
    }

    /** 			emit_op(DISPLAY_VAR)*/
    _37emit_op(87);

    /** 			emit_addr(left_sym)*/
    _37emit_addr(_30left_sym_54197);
L31: 
L30: 

    /** end procedure*/
    DeRef(_left_var_56452);
    DeRef(_tok_56454);
    _28866 = NOVALUE;
    DeRef(_28821);
    _28821 = NOVALUE;
    DeRef(_28882);
    _28882 = NOVALUE;
    DeRef(_28891);
    _28891 = NOVALUE;
    DeRef(_28886);
    _28886 = NOVALUE;
    DeRef(_28893);
    _28893 = NOVALUE;
    DeRef(_28906);
    _28906 = NOVALUE;
    DeRef(_28910);
    _28910 = NOVALUE;
    return;
    ;
}


void _30Return_statement()
{
    int _tok_56743 = NOVALUE;
    int _pop_56744 = NOVALUE;
    int _last_op_56750 = NOVALUE;
    int _last_pc_56753 = NOVALUE;
    int _is_tail_56756 = NOVALUE;
    int _28946 = NOVALUE;
    int _28944 = NOVALUE;
    int _28943 = NOVALUE;
    int _28942 = NOVALUE;
    int _28941 = NOVALUE;
    int _28939 = NOVALUE;
    int _28938 = NOVALUE;
    int _28937 = NOVALUE;
    int _28936 = NOVALUE;
    int _28935 = NOVALUE;
    int _28934 = NOVALUE;
    int _28933 = NOVALUE;
    int _28932 = NOVALUE;
    int _28928 = NOVALUE;
    int _28927 = NOVALUE;
    int _28925 = NOVALUE;
    int _28924 = NOVALUE;
    int _28923 = NOVALUE;
    int _28922 = NOVALUE;
    int _28921 = NOVALUE;
    int _28920 = NOVALUE;
    int _28919 = NOVALUE;
    int _28918 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer pop*/

    /** 	if CurrentSub = TopLevelSub then*/
    if (_26CurrentSub_11990 != _26TopLevelSub_11989)
    goto L1; // [9] 21

    /** 		CompileErr(130)*/
    RefDS(_22037);
    _43CompileErr(130, _22037, 0);
L1: 

    /** 	integer*/

    /** 		last_op = Last_op(),*/
    _last_op_56750 = _37Last_op();
    if (!IS_ATOM_INT(_last_op_56750)) {
        _1 = (long)(DBL_PTR(_last_op_56750)->dbl);
        DeRefDS(_last_op_56750);
        _last_op_56750 = _1;
    }

    /** 		last_pc = Last_pc(),*/
    _last_pc_56753 = _37Last_pc();
    if (!IS_ATOM_INT(_last_pc_56753)) {
        _1 = (long)(DBL_PTR(_last_pc_56753)->dbl);
        DeRefDS(_last_pc_56753);
        _last_pc_56753 = _1;
    }

    /** 		is_tail = 0*/
    _is_tail_56756 = 0;

    /** 	if last_op = PROC and length(Code) > last_pc and Code[last_pc+1] = CurrentSub then*/
    _28918 = (_last_op_56750 == 27);
    if (_28918 == 0) {
        _28919 = 0;
        goto L2; // [50] 67
    }
    if (IS_SEQUENCE(_26Code_12071)){
            _28920 = SEQ_PTR(_26Code_12071)->length;
    }
    else {
        _28920 = 1;
    }
    _28921 = (_28920 > _last_pc_56753);
    _28920 = NOVALUE;
    _28919 = (_28921 != 0);
L2: 
    if (_28919 == 0) {
        goto L3; // [67] 97
    }
    _28923 = _last_pc_56753 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _28924 = (int)*(((s1_ptr)_2)->base + _28923);
    if (IS_ATOM_INT(_28924)) {
        _28925 = (_28924 == _26CurrentSub_11990);
    }
    else {
        _28925 = binary_op(EQUALS, _28924, _26CurrentSub_11990);
    }
    _28924 = NOVALUE;
    if (_28925 == 0) {
        DeRef(_28925);
        _28925 = NOVALUE;
        goto L3; // [88] 97
    }
    else {
        if (!IS_ATOM_INT(_28925) && DBL_PTR(_28925)->dbl == 0.0){
            DeRef(_28925);
            _28925 = NOVALUE;
            goto L3; // [88] 97
        }
        DeRef(_28925);
        _28925 = NOVALUE;
    }
    DeRef(_28925);
    _28925 = NOVALUE;

    /** 		is_tail = 1*/
    _is_tail_56756 = 1;
L3: 

    /** 	if not TRANSLATE then*/
    if (_26TRANSLATE_11619 != 0)
    goto L4; // [101] 127

    /** 		if OpTrace then*/
    if (_26OpTrace_12052 == 0)
    {
        goto L5; // [108] 126
    }
    else{
    }

    /** 			emit_op(ERASE_PRIVATE_NAMES)*/
    _37emit_op(88);

    /** 			emit_addr(CurrentSub)*/
    _37emit_addr(_26CurrentSub_11990);
L5: 
L4: 

    /** 	if SymTab[CurrentSub][S_TOKEN] != PROC then*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _28927 = (int)*(((s1_ptr)_2)->base + _26CurrentSub_11990);
    _2 = (int)SEQ_PTR(_28927);
    if (!IS_ATOM_INT(_26S_TOKEN_11659)){
        _28928 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_TOKEN_11659)->dbl));
    }
    else{
        _28928 = (int)*(((s1_ptr)_2)->base + _26S_TOKEN_11659);
    }
    _28927 = NOVALUE;
    if (binary_op_a(EQUALS, _28928, 27)){
        _28928 = NOVALUE;
        goto L6; // [145] 271
    }
    _28928 = NOVALUE;

    /** 		Expr()*/
    _30Expr();

    /** 		last_op = Last_op()*/
    _last_op_56750 = _37Last_op();
    if (!IS_ATOM_INT(_last_op_56750)) {
        _1 = (long)(DBL_PTR(_last_op_56750)->dbl);
        DeRefDS(_last_op_56750);
        _last_op_56750 = _1;
    }

    /** 		last_pc = Last_pc()*/
    _last_pc_56753 = _37Last_pc();
    if (!IS_ATOM_INT(_last_pc_56753)) {
        _1 = (long)(DBL_PTR(_last_pc_56753)->dbl);
        DeRefDS(_last_pc_56753);
        _last_pc_56753 = _1;
    }

    /** 		if last_op = PROC and length(Code) > last_pc and Code[last_pc+1] = CurrentSub then*/
    _28932 = (_last_op_56750 == 27);
    if (_28932 == 0) {
        _28933 = 0;
        goto L7; // [175] 192
    }
    if (IS_SEQUENCE(_26Code_12071)){
            _28934 = SEQ_PTR(_26Code_12071)->length;
    }
    else {
        _28934 = 1;
    }
    _28935 = (_28934 > _last_pc_56753);
    _28934 = NOVALUE;
    _28933 = (_28935 != 0);
L7: 
    if (_28933 == 0) {
        goto L8; // [192] 251
    }
    _28937 = _last_pc_56753 + 1;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _28938 = (int)*(((s1_ptr)_2)->base + _28937);
    if (IS_ATOM_INT(_28938)) {
        _28939 = (_28938 == _26CurrentSub_11990);
    }
    else {
        _28939 = binary_op(EQUALS, _28938, _26CurrentSub_11990);
    }
    _28938 = NOVALUE;
    if (_28939 == 0) {
        DeRef(_28939);
        _28939 = NOVALUE;
        goto L8; // [213] 251
    }
    else {
        if (!IS_ATOM_INT(_28939) && DBL_PTR(_28939)->dbl == 0.0){
            DeRef(_28939);
            _28939 = NOVALUE;
            goto L8; // [213] 251
        }
        DeRef(_28939);
        _28939 = NOVALUE;
    }
    DeRef(_28939);
    _28939 = NOVALUE;

    /** 			pop = Pop() -- prevent cg_stack (code generation stack) leakage*/
    _pop_56744 = _37Pop();
    if (!IS_ATOM_INT(_pop_56744)) {
        _1 = (long)(DBL_PTR(_pop_56744)->dbl);
        DeRefDS(_pop_56744);
        _pop_56744 = _1;
    }

    /** 			Code[Last_pc()] = PROC_TAIL*/
    _28941 = _37Last_pc();
    _2 = (int)SEQ_PTR(_26Code_12071);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _26Code_12071 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_28941))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_28941)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _28941);
    _1 = *(int *)_2;
    *(int *)_2 = 203;
    DeRef(_1);

    /** 			if object(pop_temps()) then end if*/
    _28942 = _37pop_temps();
    if( NOVALUE == _28942 ){
        _28943 = 0;
    }
    else{
        if (IS_ATOM_INT(_28942))
        _28943 = 1;
        else if (IS_ATOM_DBL(_28942)) {
             if (IS_ATOM_INT(DoubleToInt(_28942))) {
                 _28943 = 1;
                 } else {
                     _28943 = 2;
                } } else if (IS_SEQUENCE(_28942))
                _28943 = 3;
                else
                _28943 = 0;
            }
            DeRef(_28942);
            _28942 = NOVALUE;
            if (_28943 == 0)
            {
                _28943 = NOVALUE;
                goto L9; // [244] 298
            }
            else{
                _28943 = NOVALUE;
            }
            goto L9; // [248] 298
L8: 

            /** 			FuncReturn = TRUE*/
            _30FuncReturn_54164 = _9TRUE_430;

            /** 			emit_op(RETURNF)*/
            _37emit_op(28);
            goto L9; // [268] 298
L6: 

            /** 		if is_tail then*/
            if (_is_tail_56756 == 0)
            {
                goto LA; // [273] 290
            }
            else{
            }

            /** 			Code[Last_pc()] = PROC_TAIL*/
            _28944 = _37Last_pc();
            _2 = (int)SEQ_PTR(_26Code_12071);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _26Code_12071 = MAKE_SEQ(_2);
            }
            if (!IS_ATOM_INT(_28944))
            _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_28944)->dbl));
            else
            _2 = (int)(((s1_ptr)_2)->base + _28944);
            _1 = *(int *)_2;
            *(int *)_2 = 203;
            DeRef(_1);
LA: 

            /** 		emit_op(RETURNP)*/
            _37emit_op(29);
L9: 

            /** 	tok = next_token()*/
            _0 = _tok_56743;
            _tok_56743 = _30next_token();
            DeRef(_0);

            /** 	putback(tok)*/
            Ref(_tok_56743);
            _30putback(_tok_56743);

            /** 	NotReached(tok[T_ID], "return")*/
            _2 = (int)SEQ_PTR(_tok_56743);
            _28946 = (int)*(((s1_ptr)_2)->base + 1);
            Ref(_28946);
            RefDS(_26407);
            _30NotReached(_28946, _26407);
            _28946 = NOVALUE;

            /** end procedure*/
            DeRef(_tok_56743);
            DeRef(_28918);
            _28918 = NOVALUE;
            DeRef(_28921);
            _28921 = NOVALUE;
            DeRef(_28923);
            _28923 = NOVALUE;
            DeRef(_28932);
            _28932 = NOVALUE;
            DeRef(_28935);
            _28935 = NOVALUE;
            DeRef(_28937);
            _28937 = NOVALUE;
            DeRef(_28941);
            _28941 = NOVALUE;
            DeRef(_28944);
            _28944 = NOVALUE;
            return;
    ;
}


int _30exit_level(int _tok_56832, int _flag_56833)
{
    int _arg_56834 = NOVALUE;
    int _n_56835 = NOVALUE;
    int _num_labels_56836 = NOVALUE;
    int _negative_56837 = NOVALUE;
    int _labels_56838 = NOVALUE;
    int _28975 = NOVALUE;
    int _28974 = NOVALUE;
    int _28973 = NOVALUE;
    int _28972 = NOVALUE;
    int _28971 = NOVALUE;
    int _28968 = NOVALUE;
    int _28967 = NOVALUE;
    int _28966 = NOVALUE;
    int _28964 = NOVALUE;
    int _28963 = NOVALUE;
    int _28962 = NOVALUE;
    int _28961 = NOVALUE;
    int _28959 = NOVALUE;
    int _28954 = NOVALUE;
    int _28953 = NOVALUE;
    int _28951 = NOVALUE;
    int _28948 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer negative = 0*/
    _negative_56837 = 0;

    /** 	if flag then*/
    if (_flag_56833 == 0)
    {
        goto L1; // [10] 25
    }
    else{
    }

    /** 		labels = if_labels*/
    RefDS(_30if_labels_54185);
    DeRef(_labels_56838);
    _labels_56838 = _30if_labels_54185;
    goto L2; // [22] 35
L1: 

    /** 		labels = loop_labels*/
    RefDS(_30loop_labels_54184);
    DeRef(_labels_56838);
    _labels_56838 = _30loop_labels_54184;
L2: 

    /** 	num_labels = length(labels)*/
    if (IS_SEQUENCE(_labels_56838)){
            _num_labels_56836 = SEQ_PTR(_labels_56838)->length;
    }
    else {
        _num_labels_56836 = 1;
    }

    /** 	if tok[T_ID] = MINUS then*/
    _2 = (int)SEQ_PTR(_tok_56832);
    _28948 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28948, 10)){
        _28948 = NOVALUE;
        goto L3; // [52] 67
    }
    _28948 = NOVALUE;

    /** 		tok = next_token()*/
    _0 = _tok_56832;
    _tok_56832 = _30next_token();
    DeRef(_0);

    /** 		negative = 1*/
    _negative_56837 = 1;
L3: 

    /** 	if tok[T_ID]=ATOM then*/
    _2 = (int)SEQ_PTR(_tok_56832);
    _28951 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28951, 502)){
        _28951 = NOVALUE;
        goto L4; // [77] 178
    }
    _28951 = NOVALUE;

    /** 		arg = SymTab[tok[T_SYM]][S_OBJ]*/
    _2 = (int)SEQ_PTR(_tok_56832);
    _28953 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!IS_ATOM_INT(_28953)){
        _28954 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_28953)->dbl));
    }
    else{
        _28954 = (int)*(((s1_ptr)_2)->base + _28953);
    }
    DeRef(_arg_56834);
    _2 = (int)SEQ_PTR(_28954);
    _arg_56834 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_arg_56834);
    _28954 = NOVALUE;

    /** 		n = floor(arg)*/
    if (IS_ATOM_INT(_arg_56834))
    _n_56835 = e_floor(_arg_56834);
    else
    _n_56835 = unary_op(FLOOR, _arg_56834);
    if (!IS_ATOM_INT(_n_56835)) {
        _1 = (long)(DBL_PTR(_n_56835)->dbl);
        DeRefDS(_n_56835);
        _n_56835 = _1;
    }

    /** 		if negative then*/
    if (_negative_56837 == 0)
    {
        goto L5; // [110] 122
    }
    else{
    }

    /** 			n = num_labels - n*/
    _n_56835 = _num_labels_56836 - _n_56835;
    goto L6; // [119] 135
L5: 

    /** 		elsif n = 0 then*/
    if (_n_56835 != 0)
    goto L7; // [124] 134

    /** 			n = num_labels*/
    _n_56835 = _num_labels_56836;
L7: 
L6: 

    /** 		if n<=0 or n>num_labels then*/
    _28959 = (_n_56835 <= 0);
    if (_28959 != 0) {
        goto L8; // [141] 154
    }
    _28961 = (_n_56835 > _num_labels_56836);
    if (_28961 == 0)
    {
        DeRef(_28961);
        _28961 = NOVALUE;
        goto L9; // [150] 162
    }
    else{
        DeRef(_28961);
        _28961 = NOVALUE;
    }
L8: 

    /** 			CompileErr(87)*/
    RefDS(_22037);
    _43CompileErr(87, _22037, 0);
L9: 

    /** 		return {n, next_token()}*/
    _28962 = _30next_token();
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _n_56835;
    ((int *)_2)[2] = _28962;
    _28963 = MAKE_SEQ(_1);
    _28962 = NOVALUE;
    DeRef(_tok_56832);
    DeRef(_arg_56834);
    DeRef(_labels_56838);
    _28953 = NOVALUE;
    DeRef(_28959);
    _28959 = NOVALUE;
    return _28963;
    goto LA; // [175] 266
L4: 

    /** 	elsif tok[T_ID]=STRING then*/
    _2 = (int)SEQ_PTR(_tok_56832);
    _28964 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28964, 503)){
        _28964 = NOVALUE;
        goto LB; // [188] 255
    }
    _28964 = NOVALUE;

    /** 		n = find(SymTab[tok[T_SYM]][S_OBJ],labels)*/
    _2 = (int)SEQ_PTR(_tok_56832);
    _28966 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!IS_ATOM_INT(_28966)){
        _28967 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_28966)->dbl));
    }
    else{
        _28967 = (int)*(((s1_ptr)_2)->base + _28966);
    }
    _2 = (int)SEQ_PTR(_28967);
    _28968 = (int)*(((s1_ptr)_2)->base + 1);
    _28967 = NOVALUE;
    _n_56835 = find_from(_28968, _labels_56838, 1);
    _28968 = NOVALUE;

    /** 		if n = 0 then*/
    if (_n_56835 != 0)
    goto LC; // [219] 231

    /** 			CompileErr(152)*/
    RefDS(_22037);
    _43CompileErr(152, _22037, 0);
LC: 

    /** 		return {num_labels + 1 - n, next_token()}*/
    _28971 = _num_labels_56836 + 1;
    if (_28971 > MAXINT){
        _28971 = NewDouble((double)_28971);
    }
    if (IS_ATOM_INT(_28971)) {
        _28972 = _28971 - _n_56835;
        if ((long)((unsigned long)_28972 +(unsigned long) HIGH_BITS) >= 0){
            _28972 = NewDouble((double)_28972);
        }
    }
    else {
        _28972 = NewDouble(DBL_PTR(_28971)->dbl - (double)_n_56835);
    }
    DeRef(_28971);
    _28971 = NOVALUE;
    _28973 = _30next_token();
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _28972;
    ((int *)_2)[2] = _28973;
    _28974 = MAKE_SEQ(_1);
    _28973 = NOVALUE;
    _28972 = NOVALUE;
    DeRef(_tok_56832);
    DeRef(_arg_56834);
    DeRef(_labels_56838);
    _28953 = NOVALUE;
    DeRef(_28959);
    _28959 = NOVALUE;
    DeRef(_28963);
    _28963 = NOVALUE;
    _28966 = NOVALUE;
    return _28974;
    goto LA; // [252] 266
LB: 

    /** 		return {1, tok} -- no parameters*/
    Ref(_tok_56832);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = _tok_56832;
    _28975 = MAKE_SEQ(_1);
    DeRef(_tok_56832);
    DeRef(_arg_56834);
    DeRef(_labels_56838);
    _28953 = NOVALUE;
    DeRef(_28959);
    _28959 = NOVALUE;
    DeRef(_28963);
    _28963 = NOVALUE;
    _28966 = NOVALUE;
    DeRef(_28974);
    _28974 = NOVALUE;
    return _28975;
LA: 
    ;
}


void _30GLabel_statement()
{
    int _tok_56895 = NOVALUE;
    int _labbel_56896 = NOVALUE;
    int _laddr_56897 = NOVALUE;
    int _n_56898 = NOVALUE;
    int _28994 = NOVALUE;
    int _28992 = NOVALUE;
    int _28991 = NOVALUE;
    int _28990 = NOVALUE;
    int _28989 = NOVALUE;
    int _28987 = NOVALUE;
    int _28984 = NOVALUE;
    int _28982 = NOVALUE;
    int _28980 = NOVALUE;
    int _28979 = NOVALUE;
    int _28977 = NOVALUE;
    int _0, _1, _2;
    

    /** 	object labbel*/

    /** 	object laddr*/

    /** 	integer n*/

    /** 	tok = next_token()*/
    _0 = _tok_56895;
    _tok_56895 = _30next_token();
    DeRef(_0);

    /** 	if tok[T_ID] != STRING then*/
    _2 = (int)SEQ_PTR(_tok_56895);
    _28977 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _28977, 503)){
        _28977 = NOVALUE;
        goto L1; // [22] 34
    }
    _28977 = NOVALUE;

    /** 		CompileErr(35)*/
    RefDS(_22037);
    _43CompileErr(35, _22037, 0);
L1: 

    /** 	labbel = SymTab[tok[T_SYM]][S_OBJ]*/
    _2 = (int)SEQ_PTR(_tok_56895);
    _28979 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!IS_ATOM_INT(_28979)){
        _28980 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_28979)->dbl));
    }
    else{
        _28980 = (int)*(((s1_ptr)_2)->base + _28979);
    }
    DeRef(_labbel_56896);
    _2 = (int)SEQ_PTR(_28980);
    _labbel_56896 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_labbel_56896);
    _28980 = NOVALUE;

    /** 	laddr = length(Code) + 1*/
    if (IS_SEQUENCE(_26Code_12071)){
            _28982 = SEQ_PTR(_26Code_12071)->length;
    }
    else {
        _28982 = 1;
    }
    _laddr_56897 = _28982 + 1;
    _28982 = NOVALUE;

    /** 	if find(labbel, goto_labels) then*/
    _28984 = find_from(_labbel_56896, _30goto_labels_54167, 1);
    if (_28984 == 0)
    {
        _28984 = NOVALUE;
        goto L2; // [74] 85
    }
    else{
        _28984 = NOVALUE;
    }

    /** 		CompileErr(59)*/
    RefDS(_22037);
    _43CompileErr(59, _22037, 0);
L2: 

    /** 	goto_labels = append(goto_labels, labbel)*/
    Ref(_labbel_56896);
    Append(&_30goto_labels_54167, _30goto_labels_54167, _labbel_56896);

    /** 	goto_addr = append(goto_addr, laddr)*/
    Append(&_30goto_addr_54168, _30goto_addr_54168, _laddr_56897);

    /** 	label_block = append( label_block, top_block() )*/
    _28987 = _65top_block(0);
    Ref(_28987);
    Append(&_30label_block_54171, _30label_block_54171, _28987);
    DeRef(_28987);
    _28987 = NOVALUE;

    /** 	while n with entry do*/
    goto L3; // [115] 174
L4: 
    if (_n_56898 == 0)
    {
        goto L5; // [120] 188
    }
    else{
    }

    /** 		backpatch(goto_list[n], laddr)*/
    _2 = (int)SEQ_PTR(_26goto_list_12094);
    _28989 = (int)*(((s1_ptr)_2)->base + _n_56898);
    Ref(_28989);
    _37backpatch(_28989, _laddr_56897);
    _28989 = NOVALUE;

    /** 		set_glabel_block( goto_ref[n], top_block() )*/
    _2 = (int)SEQ_PTR(_30goto_ref_54170);
    _28990 = (int)*(((s1_ptr)_2)->base + _n_56898);
    _28991 = _65top_block(0);
    Ref(_28990);
    _29set_glabel_block(_28990, _28991);
    _28990 = NOVALUE;
    _28991 = NOVALUE;

    /** 		goto_delay[n] = "" --clear it*/
    RefDS(_22037);
    _2 = (int)SEQ_PTR(_26goto_delay_12093);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _26goto_delay_12093 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _n_56898);
    _1 = *(int *)_2;
    *(int *)_2 = _22037;
    DeRef(_1);

    /** 		goto_line[n] = {-1,""} --clear it*/
    RefDS(_22037);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -1;
    ((int *)_2)[2] = _22037;
    _28992 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_30goto_line_54166);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _30goto_line_54166 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _n_56898);
    _1 = *(int *)_2;
    *(int *)_2 = _28992;
    if( _1 != _28992 ){
        DeRef(_1);
    }
    _28992 = NOVALUE;

    /** 	entry*/
L3: 

    /** 		n = find(labbel, goto_delay)*/
    _n_56898 = find_from(_labbel_56896, _26goto_delay_12093, 1);

    /** 	end while*/
    goto L4; // [185] 118
L5: 

    /** 	force_uninitialize( map:get( goto_init, labbel, {} ) )*/
    Ref(_30goto_init_54173);
    Ref(_labbel_56896);
    RefDS(_22037);
    _28994 = _32get(_30goto_init_54173, _labbel_56896, _22037);
    _30force_uninitialize(_28994);
    _28994 = NOVALUE;

    /** 	if TRANSLATE then*/
    if (_26TRANSLATE_11619 == 0)
    {
        goto L6; // [205] 221
    }
    else{
    }

    /** 		emit_op(GLABEL)*/
    _37emit_op(189);

    /** 		emit_addr(laddr)*/
    _37emit_addr(_laddr_56897);
L6: 

    /** end procedure*/
    DeRef(_tok_56895);
    DeRef(_labbel_56896);
    _28979 = NOVALUE;
    return;
    ;
}


void _30Goto_statement()
{
    int _tok_56945 = NOVALUE;
    int _n_56946 = NOVALUE;
    int _num_labels_56947 = NOVALUE;
    int _31653 = NOVALUE;
    int _29033 = NOVALUE;
    int _29032 = NOVALUE;
    int _29029 = NOVALUE;
    int _29028 = NOVALUE;
    int _29027 = NOVALUE;
    int _29026 = NOVALUE;
    int _29025 = NOVALUE;
    int _29024 = NOVALUE;
    int _29023 = NOVALUE;
    int _29022 = NOVALUE;
    int _29021 = NOVALUE;
    int _29020 = NOVALUE;
    int _29019 = NOVALUE;
    int _29018 = NOVALUE;
    int _29016 = NOVALUE;
    int _29015 = NOVALUE;
    int _29013 = NOVALUE;
    int _29012 = NOVALUE;
    int _29010 = NOVALUE;
    int _29009 = NOVALUE;
    int _29007 = NOVALUE;
    int _29006 = NOVALUE;
    int _29005 = NOVALUE;
    int _29004 = NOVALUE;
    int _29001 = NOVALUE;
    int _29000 = NOVALUE;
    int _28999 = NOVALUE;
    int _28997 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer n*/

    /** 	integer num_labels*/

    /** 	tok = next_token()*/
    _0 = _tok_56945;
    _tok_56945 = _30next_token();
    DeRef(_0);

    /** 	num_labels = length(goto_labels)*/
    if (IS_SEQUENCE(_30goto_labels_54167)){
            _num_labels_56947 = SEQ_PTR(_30goto_labels_54167)->length;
    }
    else {
        _num_labels_56947 = 1;
    }

    /** 	if tok[T_ID]=STRING then*/
    _2 = (int)SEQ_PTR(_tok_56945);
    _28997 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28997, 503)){
        _28997 = NOVALUE;
        goto L1; // [27] 269
    }
    _28997 = NOVALUE;

    /** 		n = find(SymTab[tok[T_SYM]][S_OBJ],goto_labels)*/
    _2 = (int)SEQ_PTR(_tok_56945);
    _28999 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!IS_ATOM_INT(_28999)){
        _29000 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_28999)->dbl));
    }
    else{
        _29000 = (int)*(((s1_ptr)_2)->base + _28999);
    }
    _2 = (int)SEQ_PTR(_29000);
    _29001 = (int)*(((s1_ptr)_2)->base + 1);
    _29000 = NOVALUE;
    _n_56946 = find_from(_29001, _30goto_labels_54167, 1);
    _29001 = NOVALUE;

    /** 		if n = 0 then*/
    if (_n_56946 != 0)
    goto L2; // [60] 243

    /** 			goto_delay &= {SymTab[tok[T_SYM]][S_OBJ]}*/
    _2 = (int)SEQ_PTR(_tok_56945);
    _29004 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!IS_ATOM_INT(_29004)){
        _29005 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_29004)->dbl));
    }
    else{
        _29005 = (int)*(((s1_ptr)_2)->base + _29004);
    }
    _2 = (int)SEQ_PTR(_29005);
    _29006 = (int)*(((s1_ptr)_2)->base + 1);
    _29005 = NOVALUE;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_29006);
    *((int *)(_2+4)) = _29006;
    _29007 = MAKE_SEQ(_1);
    _29006 = NOVALUE;
    Concat((object_ptr)&_26goto_delay_12093, _26goto_delay_12093, _29007);
    DeRefDS(_29007);
    _29007 = NOVALUE;

    /** 			goto_list &= length(Code)+2 --not 1???*/
    if (IS_SEQUENCE(_26Code_12071)){
            _29009 = SEQ_PTR(_26Code_12071)->length;
    }
    else {
        _29009 = 1;
    }
    _29010 = _29009 + 2;
    _29009 = NOVALUE;
    Append(&_26goto_list_12094, _26goto_list_12094, _29010);
    _29010 = NOVALUE;

    /** 			goto_line &= {{line_number,ThisLine}}*/
    Ref(_43ThisLine_48557);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _26line_number_11983;
    ((int *)_2)[2] = _43ThisLine_48557;
    _29012 = MAKE_SEQ(_1);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _29012;
    _29013 = MAKE_SEQ(_1);
    _29012 = NOVALUE;
    Concat((object_ptr)&_30goto_line_54166, _30goto_line_54166, _29013);
    DeRefDS(_29013);
    _29013 = NOVALUE;

    /** 			goto_ref &= new_forward_reference( GOTO, top_block() )*/
    _29015 = _65top_block(0);
    _31653 = 188;
    _29016 = _29new_forward_reference(188, _29015, 188);
    _29015 = NOVALUE;
    _31653 = NOVALUE;
    if (IS_SEQUENCE(_30goto_ref_54170) && IS_ATOM(_29016)) {
        Ref(_29016);
        Append(&_30goto_ref_54170, _30goto_ref_54170, _29016);
    }
    else if (IS_ATOM(_30goto_ref_54170) && IS_SEQUENCE(_29016)) {
    }
    else {
        Concat((object_ptr)&_30goto_ref_54170, _30goto_ref_54170, _29016);
    }
    DeRef(_29016);
    _29016 = NOVALUE;

    /** 			map:put( goto_init, SymTab[tok[T_SYM]][S_OBJ], get_private_uninitialized() )*/
    _2 = (int)SEQ_PTR(_tok_56945);
    _29018 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!IS_ATOM_INT(_29018)){
        _29019 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_29018)->dbl));
    }
    else{
        _29019 = (int)*(((s1_ptr)_2)->base + _29018);
    }
    _2 = (int)SEQ_PTR(_29019);
    _29020 = (int)*(((s1_ptr)_2)->base + 1);
    _29019 = NOVALUE;
    _29021 = _30get_private_uninitialized();
    Ref(_30goto_init_54173);
    Ref(_29020);
    _32put(_30goto_init_54173, _29020, _29021, 1, 23);
    _29020 = NOVALUE;
    _29021 = NOVALUE;

    /** 			add_data( goto_ref[$], sym_obj( tok[T_SYM] ) )*/
    if (IS_SEQUENCE(_30goto_ref_54170)){
            _29022 = SEQ_PTR(_30goto_ref_54170)->length;
    }
    else {
        _29022 = 1;
    }
    _2 = (int)SEQ_PTR(_30goto_ref_54170);
    _29023 = (int)*(((s1_ptr)_2)->base + _29022);
    _2 = (int)SEQ_PTR(_tok_56945);
    _29024 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_29024);
    _29025 = _52sym_obj(_29024);
    _29024 = NOVALUE;
    Ref(_29023);
    _29add_data(_29023, _29025);
    _29023 = NOVALUE;
    _29025 = NOVALUE;

    /** 			set_line( goto_ref[$], line_number, ThisLine, bp )*/
    if (IS_SEQUENCE(_30goto_ref_54170)){
            _29026 = SEQ_PTR(_30goto_ref_54170)->length;
    }
    else {
        _29026 = 1;
    }
    _2 = (int)SEQ_PTR(_30goto_ref_54170);
    _29027 = (int)*(((s1_ptr)_2)->base + _29026);
    Ref(_29027);
    Ref(_43ThisLine_48557);
    _29set_line(_29027, _26line_number_11983, _43ThisLine_48557, _43bp_48561);
    _29027 = NOVALUE;
    goto L3; // [240] 261
L2: 

    /** 			Goto_block( top_block(), label_block[n] )*/
    _29028 = _65top_block(0);
    _2 = (int)SEQ_PTR(_30label_block_54171);
    _29029 = (int)*(((s1_ptr)_2)->base + _n_56946);
    Ref(_29029);
    _65Goto_block(_29028, _29029, 0);
    _29028 = NOVALUE;
    _29029 = NOVALUE;
L3: 

    /** 		tok = next_token()*/
    _0 = _tok_56945;
    _tok_56945 = _30next_token();
    DeRef(_0);
    goto L4; // [266] 277
L1: 

    /** 		CompileErr(96)*/
    RefDS(_22037);
    _43CompileErr(96, _22037, 0);
L4: 

    /** 	emit_op(GOTO)*/
    _37emit_op(188);

    /** 	if n = 0 then*/
    if (_n_56946 != 0)
    goto L5; // [288] 300

    /** 		emit_addr(0) -- to be back-patched*/
    _37emit_addr(0);
    goto L6; // [297] 312
L5: 

    /** 		emit_addr(goto_addr[n])*/
    _2 = (int)SEQ_PTR(_30goto_addr_54168);
    _29032 = (int)*(((s1_ptr)_2)->base + _n_56946);
    Ref(_29032);
    _37emit_addr(_29032);
    _29032 = NOVALUE;
L6: 

    /** 	putback(tok)*/
    Ref(_tok_56945);
    _30putback(_tok_56945);

    /** 	NotReached(tok[T_ID], "goto")*/
    _2 = (int)SEQ_PTR(_tok_56945);
    _29033 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_29033);
    RefDS(_26349);
    _30NotReached(_29033, _26349);
    _29033 = NOVALUE;

    /** end procedure*/
    DeRef(_tok_56945);
    _28999 = NOVALUE;
    _29004 = NOVALUE;
    _29018 = NOVALUE;
    return;
    ;
}


void _30Exit_statement()
{
    int _addr_inlined_AppendXList_at_63_57048 = NOVALUE;
    int _tok_57031 = NOVALUE;
    int _by_ref_57032 = NOVALUE;
    int _29041 = NOVALUE;
    int _29040 = NOVALUE;
    int _29039 = NOVALUE;
    int _29038 = NOVALUE;
    int _29036 = NOVALUE;
    int _29034 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence by_ref*/

    /** 	if not length(loop_stack) then*/
    if (IS_SEQUENCE(_30loop_stack_54190)){
            _29034 = SEQ_PTR(_30loop_stack_54190)->length;
    }
    else {
        _29034 = 1;
    }
    if (_29034 != 0)
    goto L1; // [10] 21
    _29034 = NOVALUE;

    /** 		CompileErr(88)*/
    RefDS(_22037);
    _43CompileErr(88, _22037, 0);
L1: 

    /** 	by_ref = exit_level(next_token(),0) -- can't pass tok by reference*/
    _29036 = _30next_token();
    _0 = _by_ref_57032;
    _by_ref_57032 = _30exit_level(_29036, 0);
    DeRef(_0);
    _29036 = NOVALUE;

    /** 	Leave_blocks( by_ref[1], LOOP_BLOCK )*/
    _2 = (int)SEQ_PTR(_by_ref_57032);
    _29038 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_29038);
    _65Leave_blocks(_29038, 1);
    _29038 = NOVALUE;

    /** 	emit_op(EXIT)*/
    _37emit_op(61);

    /** 	AppendXList(length(Code)+1)*/
    if (IS_SEQUENCE(_26Code_12071)){
            _29039 = SEQ_PTR(_26Code_12071)->length;
    }
    else {
        _29039 = 1;
    }
    _29040 = _29039 + 1;
    _29039 = NOVALUE;
    _addr_inlined_AppendXList_at_63_57048 = _29040;
    _29040 = NOVALUE;

    /** 	exit_list = append(exit_list, addr)*/
    Append(&_30exit_list_54176, _30exit_list_54176, _addr_inlined_AppendXList_at_63_57048);

    /** end procedure*/
    goto L2; // [78] 81
L2: 

    /** 	exit_delay &= by_ref[1]*/
    _2 = (int)SEQ_PTR(_by_ref_57032);
    _29041 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_30exit_delay_54177) && IS_ATOM(_29041)) {
        Ref(_29041);
        Append(&_30exit_delay_54177, _30exit_delay_54177, _29041);
    }
    else if (IS_ATOM(_30exit_delay_54177) && IS_SEQUENCE(_29041)) {
    }
    else {
        Concat((object_ptr)&_30exit_delay_54177, _30exit_delay_54177, _29041);
    }
    _29041 = NOVALUE;

    /** 	emit_forward_addr()    -- to be back-patched*/
    _30emit_forward_addr();

    /** 	tok = by_ref[2]*/
    DeRef(_tok_57031);
    _2 = (int)SEQ_PTR(_by_ref_57032);
    _tok_57031 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_tok_57031);

    /** 	putback(tok)*/
    Ref(_tok_57031);
    _30putback(_tok_57031);

    /** end procedure*/
    DeRef(_tok_57031);
    DeRefDS(_by_ref_57032);
    return;
    ;
}


void _30Continue_statement()
{
    int _addr_inlined_AppendNList_at_149_57092 = NOVALUE;
    int _tok_57055 = NOVALUE;
    int _by_ref_57056 = NOVALUE;
    int _loop_level_57057 = NOVALUE;
    int _29067 = NOVALUE;
    int _29064 = NOVALUE;
    int _29063 = NOVALUE;
    int _29062 = NOVALUE;
    int _29061 = NOVALUE;
    int _29060 = NOVALUE;
    int _29059 = NOVALUE;
    int _29057 = NOVALUE;
    int _29056 = NOVALUE;
    int _29055 = NOVALUE;
    int _29054 = NOVALUE;
    int _29053 = NOVALUE;
    int _29052 = NOVALUE;
    int _29051 = NOVALUE;
    int _29050 = NOVALUE;
    int _29048 = NOVALUE;
    int _29046 = NOVALUE;
    int _29044 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence by_ref*/

    /** 	integer loop_level*/

    /** 	if not length(loop_stack) then*/
    if (IS_SEQUENCE(_30loop_stack_54190)){
            _29044 = SEQ_PTR(_30loop_stack_54190)->length;
    }
    else {
        _29044 = 1;
    }
    if (_29044 != 0)
    goto L1; // [12] 23
    _29044 = NOVALUE;

    /** 		CompileErr(49)*/
    RefDS(_22037);
    _43CompileErr(49, _22037, 0);
L1: 

    /** 	by_ref = exit_level(next_token(),0) -- can't pass tok by reference*/
    _29046 = _30next_token();
    _0 = _by_ref_57056;
    _by_ref_57056 = _30exit_level(_29046, 0);
    DeRef(_0);
    _29046 = NOVALUE;

    /** 	Leave_blocks( by_ref[1], LOOP_BLOCK )*/
    _2 = (int)SEQ_PTR(_by_ref_57056);
    _29048 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_29048);
    _65Leave_blocks(_29048, 1);
    _29048 = NOVALUE;

    /** 	emit_op(ELSE)*/
    _37emit_op(23);

    /** 	loop_level = by_ref[1]*/
    _2 = (int)SEQ_PTR(_by_ref_57056);
    _loop_level_57057 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_loop_level_57057))
    _loop_level_57057 = (long)DBL_PTR(_loop_level_57057)->dbl;

    /** 	if continue_addr[$+1-loop_level] then -- address is known for while loops*/
    if (IS_SEQUENCE(_30continue_addr_54181)){
            _29050 = SEQ_PTR(_30continue_addr_54181)->length;
    }
    else {
        _29050 = 1;
    }
    _29051 = _29050 + 1;
    _29050 = NOVALUE;
    _29052 = _29051 - _loop_level_57057;
    _29051 = NOVALUE;
    _2 = (int)SEQ_PTR(_30continue_addr_54181);
    _29053 = (int)*(((s1_ptr)_2)->base + _29052);
    if (_29053 == 0)
    {
        _29053 = NOVALUE;
        goto L2; // [79] 138
    }
    else{
        _29053 = NOVALUE;
    }

    /** 		if continue_addr[$+1-loop_level] < 0 then*/
    if (IS_SEQUENCE(_30continue_addr_54181)){
            _29054 = SEQ_PTR(_30continue_addr_54181)->length;
    }
    else {
        _29054 = 1;
    }
    _29055 = _29054 + 1;
    _29054 = NOVALUE;
    _29056 = _29055 - _loop_level_57057;
    _29055 = NOVALUE;
    _2 = (int)SEQ_PTR(_30continue_addr_54181);
    _29057 = (int)*(((s1_ptr)_2)->base + _29056);
    if (_29057 >= 0)
    goto L3; // [101] 113

    /** 			CompileErr(49)*/
    RefDS(_22037);
    _43CompileErr(49, _22037, 0);
L3: 

    /** 		emit_addr(continue_addr[$+1-loop_level])*/
    if (IS_SEQUENCE(_30continue_addr_54181)){
            _29059 = SEQ_PTR(_30continue_addr_54181)->length;
    }
    else {
        _29059 = 1;
    }
    _29060 = _29059 + 1;
    _29059 = NOVALUE;
    _29061 = _29060 - _loop_level_57057;
    _29060 = NOVALUE;
    _2 = (int)SEQ_PTR(_30continue_addr_54181);
    _29062 = (int)*(((s1_ptr)_2)->base + _29061);
    _37emit_addr(_29062);
    _29062 = NOVALUE;
    goto L4; // [135] 182
L2: 

    /** 		AppendNList(length(Code)+1)*/
    if (IS_SEQUENCE(_26Code_12071)){
            _29063 = SEQ_PTR(_26Code_12071)->length;
    }
    else {
        _29063 = 1;
    }
    _29064 = _29063 + 1;
    _29063 = NOVALUE;
    _addr_inlined_AppendNList_at_149_57092 = _29064;
    _29064 = NOVALUE;

    /** 	continue_list = append(continue_list, addr)*/
    Append(&_30continue_list_54178, _30continue_list_54178, _addr_inlined_AppendNList_at_149_57092);

    /** end procedure*/
    goto L5; // [164] 167
L5: 

    /** 		continue_delay &= loop_level*/
    Append(&_30continue_delay_54179, _30continue_delay_54179, _loop_level_57057);

    /** 		emit_forward_addr()    -- to be back-patched*/
    _30emit_forward_addr();
L4: 

    /** 	tok = by_ref[2]*/
    DeRef(_tok_57055);
    _2 = (int)SEQ_PTR(_by_ref_57056);
    _tok_57055 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_tok_57055);

    /** 	putback(tok)*/
    Ref(_tok_57055);
    _30putback(_tok_57055);

    /** 	NotReached(tok[T_ID], "continue")*/
    _2 = (int)SEQ_PTR(_tok_57055);
    _29067 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_29067);
    RefDS(_26311);
    _30NotReached(_29067, _26311);
    _29067 = NOVALUE;

    /** end procedure*/
    DeRef(_tok_57055);
    DeRefDS(_by_ref_57056);
    _29057 = NOVALUE;
    DeRef(_29052);
    _29052 = NOVALUE;
    DeRef(_29056);
    _29056 = NOVALUE;
    DeRef(_29061);
    _29061 = NOVALUE;
    return;
    ;
}


void _30Retry_statement()
{
    int _by_ref_57099 = NOVALUE;
    int _tok_57101 = NOVALUE;
    int _29091 = NOVALUE;
    int _29089 = NOVALUE;
    int _29088 = NOVALUE;
    int _29087 = NOVALUE;
    int _29086 = NOVALUE;
    int _29085 = NOVALUE;
    int _29083 = NOVALUE;
    int _29082 = NOVALUE;
    int _29081 = NOVALUE;
    int _29080 = NOVALUE;
    int _29079 = NOVALUE;
    int _29077 = NOVALUE;
    int _29076 = NOVALUE;
    int _29075 = NOVALUE;
    int _29074 = NOVALUE;
    int _29073 = NOVALUE;
    int _29072 = NOVALUE;
    int _29070 = NOVALUE;
    int _29068 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not length(loop_stack) then*/
    if (IS_SEQUENCE(_30loop_stack_54190)){
            _29068 = SEQ_PTR(_30loop_stack_54190)->length;
    }
    else {
        _29068 = 1;
    }
    if (_29068 != 0)
    goto L1; // [8] 19
    _29068 = NOVALUE;

    /** 		CompileErr(131)*/
    RefDS(_22037);
    _43CompileErr(131, _22037, 0);
L1: 

    /** 	by_ref = exit_level(next_token(),0) -- can't pass tok by reference*/
    _29070 = _30next_token();
    _0 = _by_ref_57099;
    _by_ref_57099 = _30exit_level(_29070, 0);
    DeRef(_0);
    _29070 = NOVALUE;

    /** 	Leave_blocks( by_ref[1], LOOP_BLOCK )*/
    _2 = (int)SEQ_PTR(_by_ref_57099);
    _29072 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_29072);
    _65Leave_blocks(_29072, 1);
    _29072 = NOVALUE;

    /** 	if loop_stack[$+1-by_ref[1]]=FOR then*/
    if (IS_SEQUENCE(_30loop_stack_54190)){
            _29073 = SEQ_PTR(_30loop_stack_54190)->length;
    }
    else {
        _29073 = 1;
    }
    _29074 = _29073 + 1;
    _29073 = NOVALUE;
    _2 = (int)SEQ_PTR(_by_ref_57099);
    _29075 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_29075)) {
        _29076 = _29074 - _29075;
    }
    else {
        _29076 = binary_op(MINUS, _29074, _29075);
    }
    _29074 = NOVALUE;
    _29075 = NOVALUE;
    _2 = (int)SEQ_PTR(_30loop_stack_54190);
    if (!IS_ATOM_INT(_29076)){
        _29077 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_29076)->dbl));
    }
    else{
        _29077 = (int)*(((s1_ptr)_2)->base + _29076);
    }
    if (_29077 != 21)
    goto L2; // [68] 82

    /** 		emit_op(RETRY) -- for Translator to emit a label at the right place*/
    _37emit_op(184);
    goto L3; // [79] 125
L2: 

    /** 		if retry_addr[$+1-by_ref[1]] < 0 then*/
    if (IS_SEQUENCE(_30retry_addr_54182)){
            _29079 = SEQ_PTR(_30retry_addr_54182)->length;
    }
    else {
        _29079 = 1;
    }
    _29080 = _29079 + 1;
    _29079 = NOVALUE;
    _2 = (int)SEQ_PTR(_by_ref_57099);
    _29081 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_29081)) {
        _29082 = _29080 - _29081;
    }
    else {
        _29082 = binary_op(MINUS, _29080, _29081);
    }
    _29080 = NOVALUE;
    _29081 = NOVALUE;
    _2 = (int)SEQ_PTR(_30retry_addr_54182);
    if (!IS_ATOM_INT(_29082)){
        _29083 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_29082)->dbl));
    }
    else{
        _29083 = (int)*(((s1_ptr)_2)->base + _29082);
    }
    if (_29083 >= 0)
    goto L4; // [105] 117

    /** 			CompileErr(131)*/
    RefDS(_22037);
    _43CompileErr(131, _22037, 0);
L4: 

    /** 		emit_op(ELSE)*/
    _37emit_op(23);
L3: 

    /** 	emit_addr(retry_addr[$+1-by_ref[1]])*/
    if (IS_SEQUENCE(_30retry_addr_54182)){
            _29085 = SEQ_PTR(_30retry_addr_54182)->length;
    }
    else {
        _29085 = 1;
    }
    _29086 = _29085 + 1;
    _29085 = NOVALUE;
    _2 = (int)SEQ_PTR(_by_ref_57099);
    _29087 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_29087)) {
        _29088 = _29086 - _29087;
    }
    else {
        _29088 = binary_op(MINUS, _29086, _29087);
    }
    _29086 = NOVALUE;
    _29087 = NOVALUE;
    _2 = (int)SEQ_PTR(_30retry_addr_54182);
    if (!IS_ATOM_INT(_29088)){
        _29089 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_29088)->dbl));
    }
    else{
        _29089 = (int)*(((s1_ptr)_2)->base + _29088);
    }
    _37emit_addr(_29089);
    _29089 = NOVALUE;

    /** 	tok = by_ref[2]*/
    DeRef(_tok_57101);
    _2 = (int)SEQ_PTR(_by_ref_57099);
    _tok_57101 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_tok_57101);

    /** 	putback(tok)*/
    Ref(_tok_57101);
    _30putback(_tok_57101);

    /** 	NotReached(tok[T_ID], "retry")*/
    _2 = (int)SEQ_PTR(_tok_57101);
    _29091 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_29091);
    RefDS(_26405);
    _30NotReached(_29091, _26405);
    _29091 = NOVALUE;

    /** end procedure*/
    DeRefDS(_by_ref_57099);
    DeRef(_tok_57101);
    _29077 = NOVALUE;
    _29083 = NOVALUE;
    DeRef(_29076);
    _29076 = NOVALUE;
    DeRef(_29082);
    _29082 = NOVALUE;
    DeRef(_29088);
    _29088 = NOVALUE;
    return;
    ;
}


int _30in_switch()
{
    int _29096 = NOVALUE;
    int _29095 = NOVALUE;
    int _29094 = NOVALUE;
    int _29093 = NOVALUE;
    int _29092 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if length( if_stack ) and if_stack[$] = SWITCH then*/
    if (IS_SEQUENCE(_30if_stack_54191)){
            _29092 = SEQ_PTR(_30if_stack_54191)->length;
    }
    else {
        _29092 = 1;
    }
    if (_29092 == 0) {
        goto L1; // [8] 40
    }
    if (IS_SEQUENCE(_30if_stack_54191)){
            _29094 = SEQ_PTR(_30if_stack_54191)->length;
    }
    else {
        _29094 = 1;
    }
    _2 = (int)SEQ_PTR(_30if_stack_54191);
    _29095 = (int)*(((s1_ptr)_2)->base + _29094);
    _29096 = (_29095 == 185);
    _29095 = NOVALUE;
    if (_29096 == 0)
    {
        DeRef(_29096);
        _29096 = NOVALUE;
        goto L1; // [28] 40
    }
    else{
        DeRef(_29096);
        _29096 = NOVALUE;
    }

    /** 		return 1*/
    return 1;
    goto L2; // [37] 47
L1: 

    /** 		return 0*/
    return 0;
L2: 
    ;
}


void _30Break_statement()
{
    int _addr_inlined_AppendEList_at_63_57171 = NOVALUE;
    int _tok_57154 = NOVALUE;
    int _by_ref_57155 = NOVALUE;
    int _29107 = NOVALUE;
    int _29104 = NOVALUE;
    int _29103 = NOVALUE;
    int _29102 = NOVALUE;
    int _29101 = NOVALUE;
    int _29099 = NOVALUE;
    int _29097 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence by_ref*/

    /** 	if not length(if_labels) then*/
    if (IS_SEQUENCE(_30if_labels_54185)){
            _29097 = SEQ_PTR(_30if_labels_54185)->length;
    }
    else {
        _29097 = 1;
    }
    if (_29097 != 0)
    goto L1; // [10] 21
    _29097 = NOVALUE;

    /** 		CompileErr(40)*/
    RefDS(_22037);
    _43CompileErr(40, _22037, 0);
L1: 

    /** 	by_ref = exit_level(next_token(),1)*/
    _29099 = _30next_token();
    _0 = _by_ref_57155;
    _by_ref_57155 = _30exit_level(_29099, 1);
    DeRef(_0);
    _29099 = NOVALUE;

    /** 	Leave_blocks( by_ref[1], CONDITIONAL_BLOCK )*/
    _2 = (int)SEQ_PTR(_by_ref_57155);
    _29101 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_29101);
    _65Leave_blocks(_29101, 2);
    _29101 = NOVALUE;

    /** 	emit_op(ELSE)*/
    _37emit_op(23);

    /** 	AppendEList(length(Code)+1)*/
    if (IS_SEQUENCE(_26Code_12071)){
            _29102 = SEQ_PTR(_26Code_12071)->length;
    }
    else {
        _29102 = 1;
    }
    _29103 = _29102 + 1;
    _29102 = NOVALUE;
    _addr_inlined_AppendEList_at_63_57171 = _29103;
    _29103 = NOVALUE;

    /** 	break_list = append(break_list, addr)*/
    Append(&_30break_list_54174, _30break_list_54174, _addr_inlined_AppendEList_at_63_57171);

    /** end procedure*/
    goto L2; // [78] 81
L2: 

    /** 	break_delay &= by_ref[1]*/
    _2 = (int)SEQ_PTR(_by_ref_57155);
    _29104 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_30break_delay_54175) && IS_ATOM(_29104)) {
        Ref(_29104);
        Append(&_30break_delay_54175, _30break_delay_54175, _29104);
    }
    else if (IS_ATOM(_30break_delay_54175) && IS_SEQUENCE(_29104)) {
    }
    else {
        Concat((object_ptr)&_30break_delay_54175, _30break_delay_54175, _29104);
    }
    _29104 = NOVALUE;

    /** 	emit_forward_addr()    -- to be back-patched*/
    _30emit_forward_addr();

    /** 	tok = by_ref[2]*/
    DeRef(_tok_57154);
    _2 = (int)SEQ_PTR(_by_ref_57155);
    _tok_57154 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_tok_57154);

    /** 	putback(tok)*/
    Ref(_tok_57154);
    _30putback(_tok_57154);

    /** 	NotReached(tok[T_ID], "break")*/
    _2 = (int)SEQ_PTR(_tok_57154);
    _29107 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_29107);
    RefDS(_26295);
    _30NotReached(_29107, _26295);
    _29107 = NOVALUE;

    /** end procedure*/
    DeRef(_tok_57154);
    DeRefDS(_by_ref_57155);
    return;
    ;
}


int _30finish_block_header(int _opcode_57180)
{
    int _tok_57182 = NOVALUE;
    int _labbel_57183 = NOVALUE;
    int _has_entry_57184 = NOVALUE;
    int _29161 = NOVALUE;
    int _29160 = NOVALUE;
    int _29159 = NOVALUE;
    int _29158 = NOVALUE;
    int _29155 = NOVALUE;
    int _29150 = NOVALUE;
    int _29147 = NOVALUE;
    int _29145 = NOVALUE;
    int _29142 = NOVALUE;
    int _29141 = NOVALUE;
    int _29139 = NOVALUE;
    int _29136 = NOVALUE;
    int _29133 = NOVALUE;
    int _29132 = NOVALUE;
    int _29130 = NOVALUE;
    int _29128 = NOVALUE;
    int _29125 = NOVALUE;
    int _29122 = NOVALUE;
    int _29121 = NOVALUE;
    int _29119 = NOVALUE;
    int _29117 = NOVALUE;
    int _29116 = NOVALUE;
    int _29115 = NOVALUE;
    int _29112 = NOVALUE;
    int _29109 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	object labbel*/

    /** 	integer has_entry*/

    /** 	tok = next_token()*/
    _0 = _tok_57182;
    _tok_57182 = _30next_token();
    DeRef(_0);

    /** 	has_entry=0*/
    _has_entry_57184 = 0;

    /** 	if tok[T_ID] = WITH then*/
    _2 = (int)SEQ_PTR(_tok_57182);
    _29109 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29109, 420)){
        _29109 = NOVALUE;
        goto L1; // [27] 154
    }
    _29109 = NOVALUE;

    /** 		tok = next_token()*/
    _0 = _tok_57182;
    _tok_57182 = _30next_token();
    DeRef(_0);

    /** 		switch tok[T_ID] do*/
    _2 = (int)SEQ_PTR(_tok_57182);
    _29112 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_29112) ){
        goto L2; // [44] 136
    }
    if(!IS_ATOM_INT(_29112)){
        if( (DBL_PTR(_29112)->dbl != (double) ((int) DBL_PTR(_29112)->dbl) ) ){
            goto L2; // [44] 136
        }
        _0 = (int) DBL_PTR(_29112)->dbl;
    }
    else {
        _0 = _29112;
    };
    _29112 = NOVALUE;
    switch ( _0 ){ 

        /** 		    case ENTRY then*/
        case 424:

        /** 				if not (opcode = WHILE or opcode = LOOP) then*/
        _29115 = (_opcode_57180 == 47);
        if (_29115 != 0) {
            DeRef(_29116);
            _29116 = 1;
            goto L3; // [61] 75
        }
        _29117 = (_opcode_57180 == 422);
        _29116 = (_29117 != 0);
L3: 
        if (_29116 != 0)
        goto L4; // [75] 86
        _29116 = NOVALUE;

        /** 					CompileErr(14)*/
        RefDS(_22037);
        _43CompileErr(14, _22037, 0);
L4: 

        /** 			    has_entry = 1*/
        _has_entry_57184 = 1;
        goto L5; // [91] 146

        /** 			case FALLTHRU then*/
        case 431:

        /** 				if not opcode = SWITCH then*/
        _29119 = (_opcode_57180 == 0);
        if (_29119 != 185)
        goto L6; // [104] 116

        /** 					CompileErr(13)*/
        RefDS(_22037);
        _43CompileErr(13, _22037, 0);
L6: 

        /** 				switch_stack[$][SWITCH_FALLTHRU] = 1*/
        if (IS_SEQUENCE(_30switch_stack_54390)){
                _29121 = SEQ_PTR(_30switch_stack_54390)->length;
        }
        else {
            _29121 = 1;
        }
        _2 = (int)SEQ_PTR(_30switch_stack_54390);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _30switch_stack_54390 = MAKE_SEQ(_2);
        }
        _3 = (int)(_29121 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 5);
        _1 = *(int *)_2;
        *(int *)_2 = 1;
        DeRef(_1);
        _29122 = NOVALUE;
        goto L5; // [132] 146

        /** 			case else*/
        default:
L2: 

        /** 			    CompileErr(27)*/
        RefDS(_22037);
        _43CompileErr(27, _22037, 0);
    ;}L5: 

    /**         tok = next_token()*/
    _0 = _tok_57182;
    _tok_57182 = _30next_token();
    DeRef(_0);
    goto L7; // [151] 240
L1: 

    /** 	elsif tok[T_ID] = WITHOUT then*/
    _2 = (int)SEQ_PTR(_tok_57182);
    _29125 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29125, 421)){
        _29125 = NOVALUE;
        goto L8; // [164] 239
    }
    _29125 = NOVALUE;

    /** 		tok = next_token()*/
    _0 = _tok_57182;
    _tok_57182 = _30next_token();
    DeRef(_0);

    /** 		if tok[T_ID] = FALLTHRU then*/
    _2 = (int)SEQ_PTR(_tok_57182);
    _29128 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29128, 431)){
        _29128 = NOVALUE;
        goto L9; // [183] 225
    }
    _29128 = NOVALUE;

    /** 			if not opcode = SWITCH then*/
    _29130 = (_opcode_57180 == 0);
    if (_29130 != 185)
    goto LA; // [194] 206

    /** 				CompileErr(15)*/
    RefDS(_22037);
    _43CompileErr(15, _22037, 0);
LA: 

    /** 			switch_stack[$][SWITCH_FALLTHRU] = 0*/
    if (IS_SEQUENCE(_30switch_stack_54390)){
            _29132 = SEQ_PTR(_30switch_stack_54390)->length;
    }
    else {
        _29132 = 1;
    }
    _2 = (int)SEQ_PTR(_30switch_stack_54390);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _30switch_stack_54390 = MAKE_SEQ(_2);
    }
    _3 = (int)(_29132 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _29133 = NOVALUE;
    goto LB; // [222] 233
L9: 

    /** 			CompileErr(27)*/
    RefDS(_22037);
    _43CompileErr(27, _22037, 0);
LB: 

    /**         tok = next_token()*/
    _0 = _tok_57182;
    _tok_57182 = _30next_token();
    DeRef(_0);
L8: 
L7: 

    /** 	labbel=0*/
    DeRef(_labbel_57183);
    _labbel_57183 = 0;

    /** 	if tok[T_ID]=LABEL then*/
    _2 = (int)SEQ_PTR(_tok_57182);
    _29136 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29136, 419)){
        _29136 = NOVALUE;
        goto LC; // [255] 317
    }
    _29136 = NOVALUE;

    /** 		tok = next_token()*/
    _0 = _tok_57182;
    _tok_57182 = _30next_token();
    DeRef(_0);

    /** 		if tok[T_ID] != STRING then*/
    _2 = (int)SEQ_PTR(_tok_57182);
    _29139 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _29139, 503)){
        _29139 = NOVALUE;
        goto LD; // [274] 286
    }
    _29139 = NOVALUE;

    /** 			CompileErr(38)*/
    RefDS(_22037);
    _43CompileErr(38, _22037, 0);
LD: 

    /** 		labbel = SymTab[tok[T_SYM]][S_OBJ]*/
    _2 = (int)SEQ_PTR(_tok_57182);
    _29141 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!IS_ATOM_INT(_29141)){
        _29142 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_29141)->dbl));
    }
    else{
        _29142 = (int)*(((s1_ptr)_2)->base + _29141);
    }
    DeRef(_labbel_57183);
    _2 = (int)SEQ_PTR(_29142);
    _labbel_57183 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_labbel_57183);
    _29142 = NOVALUE;

    /** 		block_label( labbel )*/
    Ref(_labbel_57183);
    _65block_label(_labbel_57183);

    /** 		tok = next_token()*/
    _0 = _tok_57182;
    _tok_57182 = _30next_token();
    DeRef(_0);
LC: 

    /** 	if opcode = IF or opcode = SWITCH then*/
    _29145 = (_opcode_57180 == 20);
    if (_29145 != 0) {
        goto LE; // [325] 340
    }
    _29147 = (_opcode_57180 == 185);
    if (_29147 == 0)
    {
        DeRef(_29147);
        _29147 = NOVALUE;
        goto LF; // [336] 351
    }
    else{
        DeRef(_29147);
        _29147 = NOVALUE;
    }
LE: 

    /** 		if_labels = append(if_labels,labbel)*/
    Ref(_labbel_57183);
    Append(&_30if_labels_54185, _30if_labels_54185, _labbel_57183);
    goto L10; // [348] 360
LF: 

    /** 		loop_labels = append(loop_labels,labbel)*/
    Ref(_labbel_57183);
    Append(&_30loop_labels_54184, _30loop_labels_54184, _labbel_57183);
L10: 

    /** 	if block_index=length(block_list) then*/
    if (IS_SEQUENCE(_30block_list_54186)){
            _29150 = SEQ_PTR(_30block_list_54186)->length;
    }
    else {
        _29150 = 1;
    }
    if (_30block_index_54187 != _29150)
    goto L11; // [369] 392

    /** 	    block_list &= opcode*/
    Append(&_30block_list_54186, _30block_list_54186, _opcode_57180);

    /** 	    block_index += 1*/
    _30block_index_54187 = _30block_index_54187 + 1;
    goto L12; // [389] 411
L11: 

    /** 	    block_index += 1*/
    _30block_index_54187 = _30block_index_54187 + 1;

    /** 	    block_list[block_index] = opcode*/
    _2 = (int)SEQ_PTR(_30block_list_54186);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _30block_list_54186 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _30block_index_54187);
    *(int *)_2 = _opcode_57180;
L12: 

    /** 	if tok[T_ID]=ENTRY then*/
    _2 = (int)SEQ_PTR(_tok_57182);
    _29155 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29155, 424)){
        _29155 = NOVALUE;
        goto L13; // [421] 449
    }
    _29155 = NOVALUE;

    /** 	    if has_entry then*/
    if (_has_entry_57184 == 0)
    {
        goto L14; // [427] 438
    }
    else{
    }

    /** 	        CompileErr(64)*/
    RefDS(_22037);
    _43CompileErr(64, _22037, 0);
L14: 

    /** 	    has_entry=1*/
    _has_entry_57184 = 1;

    /** 	    tok=next_token()*/
    _0 = _tok_57182;
    _tok_57182 = _30next_token();
    DeRef(_0);
L13: 

    /** 	if has_entry and (opcode = IF or opcode = SWITCH) then*/
    if (_has_entry_57184 == 0) {
        goto L15; // [451] 487
    }
    _29159 = (_opcode_57180 == 20);
    if (_29159 != 0) {
        DeRef(_29160);
        _29160 = 1;
        goto L16; // [461] 475
    }
    _29161 = (_opcode_57180 == 185);
    _29160 = (_29161 != 0);
L16: 
    if (_29160 == 0)
    {
        _29160 = NOVALUE;
        goto L15; // [476] 487
    }
    else{
        _29160 = NOVALUE;
    }

    /** 		CompileErr(80)*/
    RefDS(_22037);
    _43CompileErr(80, _22037, 0);
L15: 

    /** 	if opcode = IF then*/
    if (_opcode_57180 != 20)
    goto L17; // [491] 507

    /** 		opcode = THEN*/
    _opcode_57180 = 410;
    goto L18; // [504] 517
L17: 

    /** 		opcode = DO*/
    _opcode_57180 = 411;
L18: 

    /** 	putback(tok)*/
    Ref(_tok_57182);
    _30putback(_tok_57182);

    /** 	tok_match(opcode)*/
    _30tok_match(_opcode_57180, 0);

    /** 	return has_entry*/
    DeRef(_tok_57182);
    DeRef(_labbel_57183);
    DeRef(_29115);
    _29115 = NOVALUE;
    DeRef(_29117);
    _29117 = NOVALUE;
    DeRef(_29119);
    _29119 = NOVALUE;
    DeRef(_29130);
    _29130 = NOVALUE;
    _29141 = NOVALUE;
    DeRef(_29145);
    _29145 = NOVALUE;
    DeRef(_29159);
    _29159 = NOVALUE;
    DeRef(_29161);
    _29161 = NOVALUE;
    return _has_entry_57184;
    ;
}


void _30If_statement()
{
    int _addr_inlined_AppendEList_at_624_57430 = NOVALUE;
    int _addr_inlined_AppendEList_at_260_57359 = NOVALUE;
    int _tok_57302 = NOVALUE;
    int _prev_false_57303 = NOVALUE;
    int _prev_false2_57304 = NOVALUE;
    int _elist_base_57305 = NOVALUE;
    int _temps_57313 = NOVALUE;
    int _31652 = NOVALUE;
    int _29227 = NOVALUE;
    int _29226 = NOVALUE;
    int _29223 = NOVALUE;
    int _29222 = NOVALUE;
    int _29220 = NOVALUE;
    int _29219 = NOVALUE;
    int _29218 = NOVALUE;
    int _29216 = NOVALUE;
    int _29215 = NOVALUE;
    int _29213 = NOVALUE;
    int _29212 = NOVALUE;
    int _29211 = NOVALUE;
    int _29209 = NOVALUE;
    int _29208 = NOVALUE;
    int _29206 = NOVALUE;
    int _29205 = NOVALUE;
    int _29204 = NOVALUE;
    int _29203 = NOVALUE;
    int _29201 = NOVALUE;
    int _29200 = NOVALUE;
    int _29197 = NOVALUE;
    int _29195 = NOVALUE;
    int _29194 = NOVALUE;
    int _29193 = NOVALUE;
    int _29190 = NOVALUE;
    int _29187 = NOVALUE;
    int _29186 = NOVALUE;
    int _29184 = NOVALUE;
    int _29183 = NOVALUE;
    int _29181 = NOVALUE;
    int _29180 = NOVALUE;
    int _29178 = NOVALUE;
    int _29175 = NOVALUE;
    int _29173 = NOVALUE;
    int _29172 = NOVALUE;
    int _29171 = NOVALUE;
    int _29167 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer prev_false*/

    /** 	integer prev_false2*/

    /** 	integer elist_base*/

    /** 	if_stack &= IF*/
    Append(&_30if_stack_54191, _30if_stack_54191, 20);

    /** 	Start_block( IF )*/
    _65Start_block(20, 0);

    /** 	elist_base = length(break_list)*/
    if (IS_SEQUENCE(_30break_list_54174)){
            _elist_base_57305 = SEQ_PTR(_30break_list_54174)->length;
    }
    else {
        _elist_base_57305 = 1;
    }

    /** 	short_circuit += 1*/
    _30short_circuit_54156 = _30short_circuit_54156 + 1;

    /** 	short_circuit_B = FALSE*/
    _30short_circuit_B_54158 = _9FALSE_428;

    /** 	SC1_type = 0*/
    _30SC1_type_54161 = 0;

    /** 	Expr()*/
    _30Expr();

    /** 	sequence temps = get_temps()*/
    _31652 = Repeat(_22037, 2);
    _0 = _temps_57313;
    _temps_57313 = _37get_temps(_31652);
    DeRef(_0);
    _31652 = NOVALUE;

    /** 	emit_op(IF)*/
    _37emit_op(20);

    /** 	prev_false = length(Code)+1*/
    if (IS_SEQUENCE(_26Code_12071)){
            _29167 = SEQ_PTR(_26Code_12071)->length;
    }
    else {
        _29167 = 1;
    }
    _prev_false_57303 = _29167 + 1;
    _29167 = NOVALUE;

    /** 	emit_forward_addr() -- to be patched*/
    _30emit_forward_addr();

    /** 	prev_false2=finish_block_header(IF)  -- 0*/
    _prev_false2_57304 = _30finish_block_header(20);
    if (!IS_ATOM_INT(_prev_false2_57304)) {
        _1 = (long)(DBL_PTR(_prev_false2_57304)->dbl);
        DeRefDS(_prev_false2_57304);
        _prev_false2_57304 = _1;
    }

    /** 	if SC1_type = OR then*/
    if (_30SC1_type_54161 != 9)
    goto L1; // [106] 159

    /** 		backpatch(SC1_patch-3, SC1_OR_IF)*/
    _29171 = _30SC1_patch_54160 - 3;
    if ((long)((unsigned long)_29171 +(unsigned long) HIGH_BITS) >= 0){
        _29171 = NewDouble((double)_29171);
    }
    _37backpatch(_29171, 147);
    _29171 = NOVALUE;

    /** 		if TRANSLATE then*/
    if (_26TRANSLATE_11619 == 0)
    {
        goto L2; // [128] 139
    }
    else{
    }

    /** 			emit_op(NOP1)  -- to get label here*/
    _37emit_op(159);
L2: 

    /** 		backpatch(SC1_patch, length(Code)+1)*/
    if (IS_SEQUENCE(_26Code_12071)){
            _29172 = SEQ_PTR(_26Code_12071)->length;
    }
    else {
        _29172 = 1;
    }
    _29173 = _29172 + 1;
    _29172 = NOVALUE;
    _37backpatch(_30SC1_patch_54160, _29173);
    _29173 = NOVALUE;
    goto L3; // [156] 192
L1: 

    /** 	elsif SC1_type = AND then*/
    if (_30SC1_type_54161 != 8)
    goto L4; // [165] 191

    /** 		backpatch(SC1_patch-3, SC1_AND_IF)*/
    _29175 = _30SC1_patch_54160 - 3;
    if ((long)((unsigned long)_29175 +(unsigned long) HIGH_BITS) >= 0){
        _29175 = NewDouble((double)_29175);
    }
    _37backpatch(_29175, 146);
    _29175 = NOVALUE;

    /** 		prev_false2 = SC1_patch*/
    _prev_false2_57304 = _30SC1_patch_54160;
L4: 
L3: 

    /** 	short_circuit -= 1*/
    _30short_circuit_54156 = _30short_circuit_54156 - 1;

    /** 	Statement_list()*/
    _30Statement_list();

    /** 	tok = next_token()*/
    _0 = _tok_57302;
    _tok_57302 = _30next_token();
    DeRef(_0);

    /** 	while tok[T_ID] = ELSIF do*/
L5: 
    _2 = (int)SEQ_PTR(_tok_57302);
    _29178 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29178, 414)){
        _29178 = NOVALUE;
        goto L6; // [222] 530
    }
    _29178 = NOVALUE;

    /** 		Sibling_block( IF )*/
    _65Sibling_block(20);

    /** 		emit_op(ELSE)*/
    _37emit_op(23);

    /** 		AppendEList(length(Code)+1)*/
    if (IS_SEQUENCE(_26Code_12071)){
            _29180 = SEQ_PTR(_26Code_12071)->length;
    }
    else {
        _29180 = 1;
    }
    _29181 = _29180 + 1;
    _29180 = NOVALUE;
    _addr_inlined_AppendEList_at_260_57359 = _29181;
    _29181 = NOVALUE;

    /** 	break_list = append(break_list, addr)*/
    Append(&_30break_list_54174, _30break_list_54174, _addr_inlined_AppendEList_at_260_57359);

    /** end procedure*/
    goto L7; // [266] 269
L7: 

    /** 		break_delay &= 1*/
    Append(&_30break_delay_54175, _30break_delay_54175, 1);

    /** 		emit_forward_addr()  -- to be patched*/
    _30emit_forward_addr();

    /** 		if TRANSLATE then*/
    if (_26TRANSLATE_11619 == 0)
    {
        goto L8; // [287] 298
    }
    else{
    }

    /** 			emit_op(NOP1)*/
    _37emit_op(159);
L8: 

    /** 		backpatch(prev_false, length(Code)+1)*/
    if (IS_SEQUENCE(_26Code_12071)){
            _29183 = SEQ_PTR(_26Code_12071)->length;
    }
    else {
        _29183 = 1;
    }
    _29184 = _29183 + 1;
    _29183 = NOVALUE;
    _37backpatch(_prev_false_57303, _29184);
    _29184 = NOVALUE;

    /** 		if prev_false2 != 0 then*/
    if (_prev_false2_57304 == 0)
    goto L9; // [315] 335

    /** 			backpatch(prev_false2, length(Code)+1)*/
    if (IS_SEQUENCE(_26Code_12071)){
            _29186 = SEQ_PTR(_26Code_12071)->length;
    }
    else {
        _29186 = 1;
    }
    _29187 = _29186 + 1;
    _29186 = NOVALUE;
    _37backpatch(_prev_false2_57304, _29187);
    _29187 = NOVALUE;
L9: 

    /** 		StartSourceLine(TRUE)*/
    _37StartSourceLine(_9TRUE_430, 0, 2);

    /** 		short_circuit += 1*/
    _30short_circuit_54156 = _30short_circuit_54156 + 1;

    /** 		short_circuit_B = FALSE*/
    _30short_circuit_B_54158 = _9FALSE_428;

    /** 		SC1_type = 0*/
    _30SC1_type_54161 = 0;

    /** 		push_temps( temps )*/
    RefDS(_temps_57313);
    _37push_temps(_temps_57313);

    /** 		Expr()*/
    _30Expr();

    /** 		temps = get_temps( temps )*/
    RefDS(_temps_57313);
    _0 = _temps_57313;
    _temps_57313 = _37get_temps(_temps_57313);
    DeRefDS(_0);

    /** 		emit_op(IF)*/
    _37emit_op(20);

    /** 		prev_false = length(Code)+1*/
    if (IS_SEQUENCE(_26Code_12071)){
            _29190 = SEQ_PTR(_26Code_12071)->length;
    }
    else {
        _29190 = 1;
    }
    _prev_false_57303 = _29190 + 1;
    _29190 = NOVALUE;

    /** 		prev_false2 = 0*/
    _prev_false2_57304 = 0;

    /** 		emit_forward_addr() -- to be patched*/
    _30emit_forward_addr();

    /** 		if SC1_type = OR then*/
    if (_30SC1_type_54161 != 9)
    goto LA; // [414] 467

    /** 			backpatch(SC1_patch-3, SC1_OR_IF)*/
    _29193 = _30SC1_patch_54160 - 3;
    if ((long)((unsigned long)_29193 +(unsigned long) HIGH_BITS) >= 0){
        _29193 = NewDouble((double)_29193);
    }
    _37backpatch(_29193, 147);
    _29193 = NOVALUE;

    /** 			if TRANSLATE then*/
    if (_26TRANSLATE_11619 == 0)
    {
        goto LB; // [436] 447
    }
    else{
    }

    /** 				emit_op(NOP1)*/
    _37emit_op(159);
LB: 

    /** 			backpatch(SC1_patch, length(Code)+1)*/
    if (IS_SEQUENCE(_26Code_12071)){
            _29194 = SEQ_PTR(_26Code_12071)->length;
    }
    else {
        _29194 = 1;
    }
    _29195 = _29194 + 1;
    _29194 = NOVALUE;
    _37backpatch(_30SC1_patch_54160, _29195);
    _29195 = NOVALUE;
    goto LC; // [464] 500
LA: 

    /** 		elsif SC1_type = AND then*/
    if (_30SC1_type_54161 != 8)
    goto LD; // [473] 499

    /** 			backpatch(SC1_patch-3, SC1_AND_IF)*/
    _29197 = _30SC1_patch_54160 - 3;
    if ((long)((unsigned long)_29197 +(unsigned long) HIGH_BITS) >= 0){
        _29197 = NewDouble((double)_29197);
    }
    _37backpatch(_29197, 146);
    _29197 = NOVALUE;

    /** 			prev_false2 = SC1_patch*/
    _prev_false2_57304 = _30SC1_patch_54160;
LD: 
LC: 

    /** 		short_circuit -= 1*/
    _30short_circuit_54156 = _30short_circuit_54156 - 1;

    /** 		tok_match(THEN)*/
    _30tok_match(410, 0);

    /** 		Statement_list()*/
    _30Statement_list();

    /** 		tok = next_token()*/
    _0 = _tok_57302;
    _tok_57302 = _30next_token();
    DeRef(_0);

    /** 	end while*/
    goto L5; // [527] 214
L6: 

    /** 	if tok[T_ID] = ELSE or length(temps[1]) then*/
    _2 = (int)SEQ_PTR(_tok_57302);
    _29200 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_29200)) {
        _29201 = (_29200 == 23);
    }
    else {
        _29201 = binary_op(EQUALS, _29200, 23);
    }
    _29200 = NOVALUE;
    if (IS_ATOM_INT(_29201)) {
        if (_29201 != 0) {
            goto LE; // [544] 560
        }
    }
    else {
        if (DBL_PTR(_29201)->dbl != 0.0) {
            goto LE; // [544] 560
        }
    }
    _2 = (int)SEQ_PTR(_temps_57313);
    _29203 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_29203)){
            _29204 = SEQ_PTR(_29203)->length;
    }
    else {
        _29204 = 1;
    }
    _29203 = NOVALUE;
    if (_29204 == 0)
    {
        _29204 = NOVALUE;
        goto LF; // [556] 715
    }
    else{
        _29204 = NOVALUE;
    }
LE: 

    /** 		Sibling_block( IF )*/
    _65Sibling_block(20);

    /** 		StartSourceLine(FALSE, , COVERAGE_SUPPRESS )*/
    _37StartSourceLine(_9FALSE_428, 0, 1);

    /** 		emit_op(ELSE)*/
    _37emit_op(23);

    /** 		AppendEList(length(Code)+1)*/
    if (IS_SEQUENCE(_26Code_12071)){
            _29205 = SEQ_PTR(_26Code_12071)->length;
    }
    else {
        _29205 = 1;
    }
    _29206 = _29205 + 1;
    _29205 = NOVALUE;
    _addr_inlined_AppendEList_at_624_57430 = _29206;
    _29206 = NOVALUE;

    /** 	break_list = append(break_list, addr)*/
    Append(&_30break_list_54174, _30break_list_54174, _addr_inlined_AppendEList_at_624_57430);

    /** end procedure*/
    goto L10; // [611] 614
L10: 

    /** 		break_delay &= 1*/
    Append(&_30break_delay_54175, _30break_delay_54175, 1);

    /** 		emit_forward_addr() -- to be patched*/
    _30emit_forward_addr();

    /** 		if TRANSLATE then*/
    if (_26TRANSLATE_11619 == 0)
    {
        goto L11; // [632] 643
    }
    else{
    }

    /** 			emit_op(NOP1)*/
    _37emit_op(159);
L11: 

    /** 		backpatch(prev_false, length(Code)+1)*/
    if (IS_SEQUENCE(_26Code_12071)){
            _29208 = SEQ_PTR(_26Code_12071)->length;
    }
    else {
        _29208 = 1;
    }
    _29209 = _29208 + 1;
    _29208 = NOVALUE;
    _37backpatch(_prev_false_57303, _29209);
    _29209 = NOVALUE;

    /** 		if prev_false2 != 0 then*/
    if (_prev_false2_57304 == 0)
    goto L12; // [660] 680

    /** 			backpatch(prev_false2, length(Code)+1)*/
    if (IS_SEQUENCE(_26Code_12071)){
            _29211 = SEQ_PTR(_26Code_12071)->length;
    }
    else {
        _29211 = 1;
    }
    _29212 = _29211 + 1;
    _29211 = NOVALUE;
    _37backpatch(_prev_false2_57304, _29212);
    _29212 = NOVALUE;
L12: 

    /** 		push_temps( temps )*/
    RefDS(_temps_57313);
    _37push_temps(_temps_57313);

    /** 		if tok[T_ID] = ELSE then*/
    _2 = (int)SEQ_PTR(_tok_57302);
    _29213 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29213, 23)){
        _29213 = NOVALUE;
        goto L13; // [695] 706
    }
    _29213 = NOVALUE;

    /** 			Statement_list()*/
    _30Statement_list();
    goto L14; // [703] 773
L13: 

    /** 			putback(tok)*/
    Ref(_tok_57302);
    _30putback(_tok_57302);
    goto L14; // [712] 773
LF: 

    /** 		putback(tok)*/
    Ref(_tok_57302);
    _30putback(_tok_57302);

    /** 		if TRANSLATE then*/
    if (_26TRANSLATE_11619 == 0)
    {
        goto L15; // [724] 735
    }
    else{
    }

    /** 			emit_op(NOP1)*/
    _37emit_op(159);
L15: 

    /** 		backpatch(prev_false, length(Code)+1)*/
    if (IS_SEQUENCE(_26Code_12071)){
            _29215 = SEQ_PTR(_26Code_12071)->length;
    }
    else {
        _29215 = 1;
    }
    _29216 = _29215 + 1;
    _29215 = NOVALUE;
    _37backpatch(_prev_false_57303, _29216);
    _29216 = NOVALUE;

    /** 		if prev_false2 != 0 then*/
    if (_prev_false2_57304 == 0)
    goto L16; // [752] 772

    /** 			backpatch(prev_false2, length(Code)+1)*/
    if (IS_SEQUENCE(_26Code_12071)){
            _29218 = SEQ_PTR(_26Code_12071)->length;
    }
    else {
        _29218 = 1;
    }
    _29219 = _29218 + 1;
    _29218 = NOVALUE;
    _37backpatch(_prev_false2_57304, _29219);
    _29219 = NOVALUE;
L16: 
L14: 

    /** 	tok_match(END)*/
    _30tok_match(402, 0);

    /** 	tok_match(IF, END)*/
    _30tok_match(20, 402);

    /** 	End_block( IF )*/
    _65End_block(20);

    /** 	if TRANSLATE then*/
    if (_26TRANSLATE_11619 == 0)
    {
        goto L17; // [802] 825
    }
    else{
    }

    /** 		if length(break_list) > elist_base then*/
    if (IS_SEQUENCE(_30break_list_54174)){
            _29220 = SEQ_PTR(_30break_list_54174)->length;
    }
    else {
        _29220 = 1;
    }
    if (_29220 <= _elist_base_57305)
    goto L18; // [812] 824

    /** 			emit_op(NOP1)  -- to emit label here*/
    _37emit_op(159);
L18: 
L17: 

    /** 	PatchEList(elist_base)*/
    _30PatchEList(_elist_base_57305);

    /** 	if_labels = if_labels[1..$-1]*/
    if (IS_SEQUENCE(_30if_labels_54185)){
            _29222 = SEQ_PTR(_30if_labels_54185)->length;
    }
    else {
        _29222 = 1;
    }
    _29223 = _29222 - 1;
    _29222 = NOVALUE;
    rhs_slice_target = (object_ptr)&_30if_labels_54185;
    RHS_Slice(_30if_labels_54185, 1, _29223);

    /** 	block_index -= 1*/
    _30block_index_54187 = _30block_index_54187 - 1;

    /** 	if_stack = if_stack[1..$-1]*/
    if (IS_SEQUENCE(_30if_stack_54191)){
            _29226 = SEQ_PTR(_30if_stack_54191)->length;
    }
    else {
        _29226 = 1;
    }
    _29227 = _29226 - 1;
    _29226 = NOVALUE;
    rhs_slice_target = (object_ptr)&_30if_stack_54191;
    RHS_Slice(_30if_stack_54191, 1, _29227);

    /** end procedure*/
    DeRef(_tok_57302);
    DeRef(_temps_57313);
    _29203 = NOVALUE;
    DeRef(_29201);
    _29201 = NOVALUE;
    _29223 = NOVALUE;
    _29227 = NOVALUE;
    return;
    ;
}


void _30exit_loop(int _exit_base_57490)
{
    int _29242 = NOVALUE;
    int _29241 = NOVALUE;
    int _29239 = NOVALUE;
    int _29238 = NOVALUE;
    int _29236 = NOVALUE;
    int _29235 = NOVALUE;
    int _29233 = NOVALUE;
    int _29232 = NOVALUE;
    int _29230 = NOVALUE;
    int _29229 = NOVALUE;
    int _0, _1, _2;
    

    /** 	PatchXList(exit_base)*/
    _30PatchXList(_exit_base_57490);

    /** 	loop_labels = loop_labels[1..$-1]*/
    if (IS_SEQUENCE(_30loop_labels_54184)){
            _29229 = SEQ_PTR(_30loop_labels_54184)->length;
    }
    else {
        _29229 = 1;
    }
    _29230 = _29229 - 1;
    _29229 = NOVALUE;
    rhs_slice_target = (object_ptr)&_30loop_labels_54184;
    RHS_Slice(_30loop_labels_54184, 1, _29230);

    /** 	loop_stack = loop_stack[1..$-1]*/
    if (IS_SEQUENCE(_30loop_stack_54190)){
            _29232 = SEQ_PTR(_30loop_stack_54190)->length;
    }
    else {
        _29232 = 1;
    }
    _29233 = _29232 - 1;
    _29232 = NOVALUE;
    rhs_slice_target = (object_ptr)&_30loop_stack_54190;
    RHS_Slice(_30loop_stack_54190, 1, _29233);

    /** 	continue_addr = continue_addr[1..$-1]*/
    if (IS_SEQUENCE(_30continue_addr_54181)){
            _29235 = SEQ_PTR(_30continue_addr_54181)->length;
    }
    else {
        _29235 = 1;
    }
    _29236 = _29235 - 1;
    _29235 = NOVALUE;
    rhs_slice_target = (object_ptr)&_30continue_addr_54181;
    RHS_Slice(_30continue_addr_54181, 1, _29236);

    /** 	retry_addr = retry_addr[1..$-1]*/
    if (IS_SEQUENCE(_30retry_addr_54182)){
            _29238 = SEQ_PTR(_30retry_addr_54182)->length;
    }
    else {
        _29238 = 1;
    }
    _29239 = _29238 - 1;
    _29238 = NOVALUE;
    rhs_slice_target = (object_ptr)&_30retry_addr_54182;
    RHS_Slice(_30retry_addr_54182, 1, _29239);

    /** 	entry_addr = entry_addr[1..$-1]*/
    if (IS_SEQUENCE(_30entry_addr_54180)){
            _29241 = SEQ_PTR(_30entry_addr_54180)->length;
    }
    else {
        _29241 = 1;
    }
    _29242 = _29241 - 1;
    _29241 = NOVALUE;
    rhs_slice_target = (object_ptr)&_30entry_addr_54180;
    RHS_Slice(_30entry_addr_54180, 1, _29242);

    /** 	block_index -= 1*/
    _30block_index_54187 = _30block_index_54187 - 1;

    /** end procedure*/
    _29230 = NOVALUE;
    _29233 = NOVALUE;
    _29236 = NOVALUE;
    _29239 = NOVALUE;
    _29242 = NOVALUE;
    return;
    ;
}


void _30push_switch()
{
    int _29246 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if_stack &= SWITCH*/
    Append(&_30if_stack_54191, _30if_stack_54191, 185);

    /** 	switch_stack = append( switch_stack, { {}, {}, 0, 0, 0, 0 })*/
    _1 = NewS1(6);
    _2 = (int)((s1_ptr)_1)->base;
    RefDSn(_22037, 2);
    *((int *)(_2+4)) = _22037;
    *((int *)(_2+8)) = _22037;
    *((int *)(_2+12)) = 0;
    *((int *)(_2+16)) = 0;
    *((int *)(_2+20)) = 0;
    *((int *)(_2+24)) = 0;
    _29246 = MAKE_SEQ(_1);
    RefDS(_29246);
    Append(&_30switch_stack_54390, _30switch_stack_54390, _29246);
    DeRefDS(_29246);
    _29246 = NOVALUE;

    /** end procedure*/
    return;
    ;
}


void _30pop_switch(int _break_base_57515)
{
    int _29261 = NOVALUE;
    int _29260 = NOVALUE;
    int _29258 = NOVALUE;
    int _29257 = NOVALUE;
    int _29255 = NOVALUE;
    int _29254 = NOVALUE;
    int _29252 = NOVALUE;
    int _29251 = NOVALUE;
    int _29250 = NOVALUE;
    int _29249 = NOVALUE;
    int _0, _1, _2;
    

    /** 	PatchEList( break_base )*/
    _30PatchEList(_break_base_57515);

    /** 	block_index -= 1*/
    _30block_index_54187 = _30block_index_54187 - 1;

    /** 	if length(switch_stack[$][SWITCH_CASES]) > 0 then*/
    if (IS_SEQUENCE(_30switch_stack_54390)){
            _29249 = SEQ_PTR(_30switch_stack_54390)->length;
    }
    else {
        _29249 = 1;
    }
    _2 = (int)SEQ_PTR(_30switch_stack_54390);
    _29250 = (int)*(((s1_ptr)_2)->base + _29249);
    _2 = (int)SEQ_PTR(_29250);
    _29251 = (int)*(((s1_ptr)_2)->base + 1);
    _29250 = NOVALUE;
    if (IS_SEQUENCE(_29251)){
            _29252 = SEQ_PTR(_29251)->length;
    }
    else {
        _29252 = 1;
    }
    _29251 = NOVALUE;
    if (_29252 <= 0)
    goto L1; // [34] 46

    /** 		End_block( CASE )*/
    _65End_block(186);
L1: 

    /** 	if_labels = if_labels[1..$-1]*/
    if (IS_SEQUENCE(_30if_labels_54185)){
            _29254 = SEQ_PTR(_30if_labels_54185)->length;
    }
    else {
        _29254 = 1;
    }
    _29255 = _29254 - 1;
    _29254 = NOVALUE;
    rhs_slice_target = (object_ptr)&_30if_labels_54185;
    RHS_Slice(_30if_labels_54185, 1, _29255);

    /** 	if_stack  = if_stack[1..$-1]*/
    if (IS_SEQUENCE(_30if_stack_54191)){
            _29257 = SEQ_PTR(_30if_stack_54191)->length;
    }
    else {
        _29257 = 1;
    }
    _29258 = _29257 - 1;
    _29257 = NOVALUE;
    rhs_slice_target = (object_ptr)&_30if_stack_54191;
    RHS_Slice(_30if_stack_54191, 1, _29258);

    /** 	switch_stack  = switch_stack[1..$-1]*/
    if (IS_SEQUENCE(_30switch_stack_54390)){
            _29260 = SEQ_PTR(_30switch_stack_54390)->length;
    }
    else {
        _29260 = 1;
    }
    _29261 = _29260 - 1;
    _29260 = NOVALUE;
    rhs_slice_target = (object_ptr)&_30switch_stack_54390;
    RHS_Slice(_30switch_stack_54390, 1, _29261);

    /** end procedure*/
    _29251 = NOVALUE;
    _29255 = NOVALUE;
    _29258 = NOVALUE;
    _29261 = NOVALUE;
    return;
    ;
}


void _30add_case(int _sym_57536, int _sign_57537)
{
    int _29287 = NOVALUE;
    int _29286 = NOVALUE;
    int _29285 = NOVALUE;
    int _29284 = NOVALUE;
    int _29283 = NOVALUE;
    int _29282 = NOVALUE;
    int _29281 = NOVALUE;
    int _29280 = NOVALUE;
    int _29278 = NOVALUE;
    int _29277 = NOVALUE;
    int _29276 = NOVALUE;
    int _29275 = NOVALUE;
    int _29274 = NOVALUE;
    int _29273 = NOVALUE;
    int _29271 = NOVALUE;
    int _29270 = NOVALUE;
    int _29268 = NOVALUE;
    int _29267 = NOVALUE;
    int _29266 = NOVALUE;
    int _29265 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	if sign < 0 then*/
    if (_sign_57537 >= 0)
    goto L1; // [5] 15

    /** 		sym = -sym*/
    _0 = _sym_57536;
    if (IS_ATOM_INT(_sym_57536)) {
        if ((unsigned long)_sym_57536 == 0xC0000000)
        _sym_57536 = (int)NewDouble((double)-0xC0000000);
        else
        _sym_57536 = - _sym_57536;
    }
    else {
        _sym_57536 = unary_op(UMINUS, _sym_57536);
    }
    DeRefi(_0);
L1: 

    /** 	if find(sym, switch_stack[$][SWITCH_CASES] ) = 0 then*/
    if (IS_SEQUENCE(_30switch_stack_54390)){
            _29265 = SEQ_PTR(_30switch_stack_54390)->length;
    }
    else {
        _29265 = 1;
    }
    _2 = (int)SEQ_PTR(_30switch_stack_54390);
    _29266 = (int)*(((s1_ptr)_2)->base + _29265);
    _2 = (int)SEQ_PTR(_29266);
    _29267 = (int)*(((s1_ptr)_2)->base + 1);
    _29266 = NOVALUE;
    _29268 = find_from(_sym_57536, _29267, 1);
    _29267 = NOVALUE;
    if (_29268 != 0)
    goto L2; // [35] 144

    /** 		switch_stack[$][SWITCH_CASES]       = append( switch_stack[$][SWITCH_CASES], sym )*/
    if (IS_SEQUENCE(_30switch_stack_54390)){
            _29270 = SEQ_PTR(_30switch_stack_54390)->length;
    }
    else {
        _29270 = 1;
    }
    _2 = (int)SEQ_PTR(_30switch_stack_54390);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _30switch_stack_54390 = MAKE_SEQ(_2);
    }
    _3 = (int)(_29270 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_30switch_stack_54390)){
            _29273 = SEQ_PTR(_30switch_stack_54390)->length;
    }
    else {
        _29273 = 1;
    }
    _2 = (int)SEQ_PTR(_30switch_stack_54390);
    _29274 = (int)*(((s1_ptr)_2)->base + _29273);
    _2 = (int)SEQ_PTR(_29274);
    _29275 = (int)*(((s1_ptr)_2)->base + 1);
    _29274 = NOVALUE;
    Ref(_sym_57536);
    Append(&_29276, _29275, _sym_57536);
    _29275 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _29276;
    if( _1 != _29276 ){
        DeRef(_1);
    }
    _29276 = NOVALUE;
    _29271 = NOVALUE;

    /** 		switch_stack[$][SWITCH_JUMP_TABLE] &= length(Code) + 1*/
    if (IS_SEQUENCE(_30switch_stack_54390)){
            _29277 = SEQ_PTR(_30switch_stack_54390)->length;
    }
    else {
        _29277 = 1;
    }
    _2 = (int)SEQ_PTR(_30switch_stack_54390);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _30switch_stack_54390 = MAKE_SEQ(_2);
    }
    _3 = (int)(_29277 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_26Code_12071)){
            _29280 = SEQ_PTR(_26Code_12071)->length;
    }
    else {
        _29280 = 1;
    }
    _29281 = _29280 + 1;
    _29280 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    _29282 = (int)*(((s1_ptr)_2)->base + 2);
    _29278 = NOVALUE;
    if (IS_SEQUENCE(_29282) && IS_ATOM(_29281)) {
        Append(&_29283, _29282, _29281);
    }
    else if (IS_ATOM(_29282) && IS_SEQUENCE(_29281)) {
    }
    else {
        Concat((object_ptr)&_29283, _29282, _29281);
        _29282 = NOVALUE;
    }
    _29282 = NOVALUE;
    _29281 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _29283;
    if( _1 != _29283 ){
        DeRef(_1);
    }
    _29283 = NOVALUE;
    _29278 = NOVALUE;

    /** 		if TRANSLATE then*/
    if (_26TRANSLATE_11619 == 0)
    {
        goto L3; // [109] 152
    }
    else{
    }

    /** 			emit_addr( CASE )*/
    _37emit_addr(186);

    /** 			emit_addr( length( switch_stack[$][SWITCH_CASES] ) )*/
    if (IS_SEQUENCE(_30switch_stack_54390)){
            _29284 = SEQ_PTR(_30switch_stack_54390)->length;
    }
    else {
        _29284 = 1;
    }
    _2 = (int)SEQ_PTR(_30switch_stack_54390);
    _29285 = (int)*(((s1_ptr)_2)->base + _29284);
    _2 = (int)SEQ_PTR(_29285);
    _29286 = (int)*(((s1_ptr)_2)->base + 1);
    _29285 = NOVALUE;
    if (IS_SEQUENCE(_29286)){
            _29287 = SEQ_PTR(_29286)->length;
    }
    else {
        _29287 = 1;
    }
    _29286 = NOVALUE;
    _37emit_addr(_29287);
    _29287 = NOVALUE;
    goto L3; // [141] 152
L2: 

    /** 		CompileErr( 63 )*/
    RefDS(_22037);
    _43CompileErr(63, _22037, 0);
L3: 

    /** end procedure*/
    DeRef(_sym_57536);
    _29286 = NOVALUE;
    return;
    ;
}


void _30case_else()
{
    int _29295 = NOVALUE;
    int _29294 = NOVALUE;
    int _29292 = NOVALUE;
    int _29291 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	switch_stack[$][SWITCH_ELSE] = length(Code) + 1*/
    if (IS_SEQUENCE(_30switch_stack_54390)){
            _29291 = SEQ_PTR(_30switch_stack_54390)->length;
    }
    else {
        _29291 = 1;
    }
    _2 = (int)SEQ_PTR(_30switch_stack_54390);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _30switch_stack_54390 = MAKE_SEQ(_2);
    }
    _3 = (int)(_29291 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_26Code_12071)){
            _29294 = SEQ_PTR(_26Code_12071)->length;
    }
    else {
        _29294 = 1;
    }
    _29295 = _29294 + 1;
    _29294 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = _29295;
    if( _1 != _29295 ){
        DeRef(_1);
    }
    _29295 = NOVALUE;
    _29292 = NOVALUE;

    /** 	if TRANSLATE then*/
    if (_26TRANSLATE_11619 == 0)
    {
        goto L1; // [30] 46
    }
    else{
    }

    /** 		emit_addr( CASE )*/
    _37emit_addr(186);

    /** 		emit_addr( 0 )*/
    _37emit_addr(0);
L1: 

    /** end procedure*/
    return;
    ;
}


void _30Case_statement()
{
    int _else_case_2__tmp_at145_57633 = NOVALUE;
    int _else_case_1__tmp_at145_57632 = NOVALUE;
    int _else_case_inlined_else_case_at_145_57631 = NOVALUE;
    int _tok_57595 = NOVALUE;
    int _condition_57597 = NOVALUE;
    int _start_line_57626 = NOVALUE;
    int _sign_57637 = NOVALUE;
    int _fwd_57650 = NOVALUE;
    int _symi_57660 = NOVALUE;
    int _fwdref_57729 = NOVALUE;
    int _31651 = NOVALUE;
    int _29377 = NOVALUE;
    int _29376 = NOVALUE;
    int _29375 = NOVALUE;
    int _29374 = NOVALUE;
    int _29373 = NOVALUE;
    int _29372 = NOVALUE;
    int _29370 = NOVALUE;
    int _29369 = NOVALUE;
    int _29368 = NOVALUE;
    int _29367 = NOVALUE;
    int _29366 = NOVALUE;
    int _29365 = NOVALUE;
    int _29363 = NOVALUE;
    int _29360 = NOVALUE;
    int _29357 = NOVALUE;
    int _29356 = NOVALUE;
    int _29355 = NOVALUE;
    int _29354 = NOVALUE;
    int _29351 = NOVALUE;
    int _29350 = NOVALUE;
    int _29349 = NOVALUE;
    int _29348 = NOVALUE;
    int _29345 = NOVALUE;
    int _29344 = NOVALUE;
    int _29343 = NOVALUE;
    int _29342 = NOVALUE;
    int _29340 = NOVALUE;
    int _29339 = NOVALUE;
    int _29338 = NOVALUE;
    int _29336 = NOVALUE;
    int _29335 = NOVALUE;
    int _29334 = NOVALUE;
    int _29333 = NOVALUE;
    int _29332 = NOVALUE;
    int _29330 = NOVALUE;
    int _29329 = NOVALUE;
    int _29327 = NOVALUE;
    int _29326 = NOVALUE;
    int _29325 = NOVALUE;
    int _29324 = NOVALUE;
    int _29320 = NOVALUE;
    int _29319 = NOVALUE;
    int _29318 = NOVALUE;
    int _29315 = NOVALUE;
    int _29312 = NOVALUE;
    int _29309 = NOVALUE;
    int _29308 = NOVALUE;
    int _29307 = NOVALUE;
    int _29306 = NOVALUE;
    int _29305 = NOVALUE;
    int _29304 = NOVALUE;
    int _29303 = NOVALUE;
    int _29301 = NOVALUE;
    int _29300 = NOVALUE;
    int _29299 = NOVALUE;
    int _29298 = NOVALUE;
    int _29296 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	if not in_switch() then*/
    _29296 = _30in_switch();
    if (IS_ATOM_INT(_29296)) {
        if (_29296 != 0){
            DeRef(_29296);
            _29296 = NOVALUE;
            goto L1; // [6] 17
        }
    }
    else {
        if (DBL_PTR(_29296)->dbl != 0.0){
            DeRef(_29296);
            _29296 = NOVALUE;
            goto L1; // [6] 17
        }
    }
    DeRef(_29296);
    _29296 = NOVALUE;

    /** 		CompileErr( 34 )*/
    RefDS(_22037);
    _43CompileErr(34, _22037, 0);
L1: 

    /** 	if length(switch_stack[$][SWITCH_CASES]) > 0 then*/
    if (IS_SEQUENCE(_30switch_stack_54390)){
            _29298 = SEQ_PTR(_30switch_stack_54390)->length;
    }
    else {
        _29298 = 1;
    }
    _2 = (int)SEQ_PTR(_30switch_stack_54390);
    _29299 = (int)*(((s1_ptr)_2)->base + _29298);
    _2 = (int)SEQ_PTR(_29299);
    _29300 = (int)*(((s1_ptr)_2)->base + 1);
    _29299 = NOVALUE;
    if (IS_SEQUENCE(_29300)){
            _29301 = SEQ_PTR(_29300)->length;
    }
    else {
        _29301 = 1;
    }
    _29300 = NOVALUE;
    if (_29301 <= 0)
    goto L2; // [35] 101

    /** 		Sibling_block( CASE )*/
    _65Sibling_block(186);

    /** 		if not switch_stack[$][SWITCH_FALLTHRU] and*/
    if (IS_SEQUENCE(_30switch_stack_54390)){
            _29303 = SEQ_PTR(_30switch_stack_54390)->length;
    }
    else {
        _29303 = 1;
    }
    _2 = (int)SEQ_PTR(_30switch_stack_54390);
    _29304 = (int)*(((s1_ptr)_2)->base + _29303);
    _2 = (int)SEQ_PTR(_29304);
    _29305 = (int)*(((s1_ptr)_2)->base + 5);
    _29304 = NOVALUE;
    if (IS_ATOM_INT(_29305)) {
        _29306 = (_29305 == 0);
    }
    else {
        _29306 = unary_op(NOT, _29305);
    }
    _29305 = NOVALUE;
    if (IS_ATOM_INT(_29306)) {
        if (_29306 == 0) {
            goto L3; // [64] 110
        }
    }
    else {
        if (DBL_PTR(_29306)->dbl == 0.0) {
            goto L3; // [64] 110
        }
    }
    _29308 = (_30fallthru_case_57591 == 0);
    if (_29308 == 0)
    {
        DeRef(_29308);
        _29308 = NOVALUE;
        goto L3; // [74] 110
    }
    else{
        DeRef(_29308);
        _29308 = NOVALUE;
    }

    /** 			putback( {CASE, 0} )*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 186;
    ((int *)_2)[2] = 0;
    _29309 = MAKE_SEQ(_1);
    _30putback(_29309);
    _29309 = NOVALUE;

    /** 			Break_statement()*/
    _30Break_statement();

    /** 			tok = next_token()*/
    _0 = _tok_57595;
    _tok_57595 = _30next_token();
    DeRef(_0);
    goto L3; // [98] 110
L2: 

    /** 		Start_block( CASE )*/
    _65Start_block(186, 0);
L3: 

    /** 	StartSourceLine(TRUE, , COVERAGE_SUPPRESS)*/
    _37StartSourceLine(_9TRUE_430, 0, 1);

    /** 	fallthru_case = 0*/
    _30fallthru_case_57591 = 0;

    /** 	integer start_line = line_number*/
    _start_line_57626 = _26line_number_11983;

    /** 	while 1 do*/
L4: 

    /** 		if else_case() then*/

    /** 	return switch_stack[$][SWITCH_ELSE]*/
    if (IS_SEQUENCE(_30switch_stack_54390)){
            _else_case_1__tmp_at145_57632 = SEQ_PTR(_30switch_stack_54390)->length;
    }
    else {
        _else_case_1__tmp_at145_57632 = 1;
    }
    DeRef(_else_case_2__tmp_at145_57633);
    _2 = (int)SEQ_PTR(_30switch_stack_54390);
    _else_case_2__tmp_at145_57633 = (int)*(((s1_ptr)_2)->base + _else_case_1__tmp_at145_57632);
    RefDS(_else_case_2__tmp_at145_57633);
    DeRef(_else_case_inlined_else_case_at_145_57631);
    _2 = (int)SEQ_PTR(_else_case_2__tmp_at145_57633);
    _else_case_inlined_else_case_at_145_57631 = (int)*(((s1_ptr)_2)->base + 3);
    Ref(_else_case_inlined_else_case_at_145_57631);
    DeRef(_else_case_2__tmp_at145_57633);
    _else_case_2__tmp_at145_57633 = NOVALUE;
    if (_else_case_inlined_else_case_at_145_57631 == 0) {
        goto L5; // [160] 171
    }
    else {
        if (!IS_ATOM_INT(_else_case_inlined_else_case_at_145_57631) && DBL_PTR(_else_case_inlined_else_case_at_145_57631)->dbl == 0.0){
            goto L5; // [160] 171
        }
    }

    /** 			CompileErr( 33 )*/
    RefDS(_22037);
    _43CompileErr(33, _22037, 0);
L5: 

    /** 		maybe_namespace()*/
    _60maybe_namespace();

    /** 		tok = next_token()*/
    _0 = _tok_57595;
    _tok_57595 = _30next_token();
    DeRef(_0);

    /** 		integer sign = 1*/
    _sign_57637 = 1;

    /** 		if tok[T_ID] = MINUS then*/
    _2 = (int)SEQ_PTR(_tok_57595);
    _29312 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29312, 10)){
        _29312 = NOVALUE;
        goto L6; // [195] 212
    }
    _29312 = NOVALUE;

    /** 			sign = -1*/
    _sign_57637 = -1;

    /** 			tok = next_token()*/
    _0 = _tok_57595;
    _tok_57595 = _30next_token();
    DeRef(_0);
    goto L7; // [209] 233
L6: 

    /** 		elsif tok[T_ID] = PLUS then*/
    _2 = (int)SEQ_PTR(_tok_57595);
    _29315 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29315, 11)){
        _29315 = NOVALUE;
        goto L8; // [222] 232
    }
    _29315 = NOVALUE;

    /** 			tok = next_token()*/
    _0 = _tok_57595;
    _tok_57595 = _30next_token();
    DeRef(_0);
L8: 
L7: 

    /** 		integer fwd*/

    /** 		if not find( tok[T_ID], {ATOM, STRING, ELSE} ) then*/
    _2 = (int)SEQ_PTR(_tok_57595);
    _29318 = (int)*(((s1_ptr)_2)->base + 1);
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 502;
    *((int *)(_2+8)) = 503;
    *((int *)(_2+12)) = 23;
    _29319 = MAKE_SEQ(_1);
    _29320 = find_from(_29318, _29319, 1);
    _29318 = NOVALUE;
    DeRefDS(_29319);
    _29319 = NOVALUE;
    if (_29320 != 0)
    goto L9; // [260] 435
    _29320 = NOVALUE;

    /** 			integer symi = tok[T_SYM]*/
    _2 = (int)SEQ_PTR(_tok_57595);
    _symi_57660 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_symi_57660)){
        _symi_57660 = (long)DBL_PTR(_symi_57660)->dbl;
    }

    /** 			fwd = -1*/
    _fwd_57650 = -1;

    /** 			if symi > 0 then*/
    if (_symi_57660 <= 0)
    goto LA; // [280] 430

    /** 				if find(tok[T_ID] , VAR_TOKS) then*/
    _2 = (int)SEQ_PTR(_tok_57595);
    _29324 = (int)*(((s1_ptr)_2)->base + 1);
    _29325 = find_from(_29324, _28VAR_TOKS_11612, 1);
    _29324 = NOVALUE;
    if (_29325 == 0)
    {
        _29325 = NOVALUE;
        goto LB; // [299] 429
    }
    else{
        _29325 = NOVALUE;
    }

    /** 					if SymTab[symi][S_SCOPE] = SC_UNDEFINED then*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _29326 = (int)*(((s1_ptr)_2)->base + _symi_57660);
    _2 = (int)SEQ_PTR(_29326);
    _29327 = (int)*(((s1_ptr)_2)->base + 4);
    _29326 = NOVALUE;
    if (binary_op_a(NOTEQ, _29327, 9)){
        _29327 = NOVALUE;
        goto LC; // [318] 330
    }
    _29327 = NOVALUE;

    /** 						fwd = symi*/
    _fwd_57650 = _symi_57660;
    goto LD; // [327] 428
LC: 

    /** 					elsif SymTab[symi][S_MODE] = M_CONSTANT then*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _29329 = (int)*(((s1_ptr)_2)->base + _symi_57660);
    _2 = (int)SEQ_PTR(_29329);
    _29330 = (int)*(((s1_ptr)_2)->base + 3);
    _29329 = NOVALUE;
    if (binary_op_a(NOTEQ, _29330, 2)){
        _29330 = NOVALUE;
        goto LE; // [346] 427
    }
    _29330 = NOVALUE;

    /** 						fwd = 0*/
    _fwd_57650 = 0;

    /** 						if SymTab[symi][S_CODE] then*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _29332 = (int)*(((s1_ptr)_2)->base + _symi_57660);
    _2 = (int)SEQ_PTR(_29332);
    if (!IS_ATOM_INT(_26S_CODE_11666)){
        _29333 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_CODE_11666)->dbl));
    }
    else{
        _29333 = (int)*(((s1_ptr)_2)->base + _26S_CODE_11666);
    }
    _29332 = NOVALUE;
    if (_29333 == 0) {
        _29333 = NOVALUE;
        goto LF; // [369] 393
    }
    else {
        if (!IS_ATOM_INT(_29333) && DBL_PTR(_29333)->dbl == 0.0){
            _29333 = NOVALUE;
            goto LF; // [369] 393
        }
        _29333 = NOVALUE;
    }
    _29333 = NOVALUE;

    /** 							tok[T_SYM] = SymTab[symi][S_CODE]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _29334 = (int)*(((s1_ptr)_2)->base + _symi_57660);
    _2 = (int)SEQ_PTR(_29334);
    if (!IS_ATOM_INT(_26S_CODE_11666)){
        _29335 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_CODE_11666)->dbl));
    }
    else{
        _29335 = (int)*(((s1_ptr)_2)->base + _26S_CODE_11666);
    }
    _29334 = NOVALUE;
    Ref(_29335);
    _2 = (int)SEQ_PTR(_tok_57595);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _tok_57595 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _29335;
    if( _1 != _29335 ){
        DeRef(_1);
    }
    _29335 = NOVALUE;
LF: 

    /** 						SymTab[symi][S_USAGE] = or_bits( SymTab[symi][S_USAGE], U_READ )*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_symi_57660 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _29338 = (int)*(((s1_ptr)_2)->base + _symi_57660);
    _2 = (int)SEQ_PTR(_29338);
    _29339 = (int)*(((s1_ptr)_2)->base + 5);
    _29338 = NOVALUE;
    if (IS_ATOM_INT(_29339)) {
        {unsigned long tu;
             tu = (unsigned long)_29339 | (unsigned long)1;
             _29340 = MAKE_UINT(tu);
        }
    }
    else {
        _29340 = binary_op(OR_BITS, _29339, 1);
    }
    _29339 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = _29340;
    if( _1 != _29340 ){
        DeRef(_1);
    }
    _29340 = NOVALUE;
    _29336 = NOVALUE;
LE: 
LD: 
LB: 
LA: 
    goto L10; // [432] 441
L9: 

    /** 			fwd = 0*/
    _fwd_57650 = 0;
L10: 

    /** 		if fwd < 0 then*/
    if (_fwd_57650 >= 0)
    goto L11; // [445] 471

    /** 			CompileErr( 91, {find_category(tok[T_ID])})*/
    _2 = (int)SEQ_PTR(_tok_57595);
    _29342 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_29342);
    _29343 = _62find_category(_29342);
    _29342 = NOVALUE;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _29343;
    _29344 = MAKE_SEQ(_1);
    _29343 = NOVALUE;
    _43CompileErr(91, _29344, 0);
    _29344 = NOVALUE;
L11: 

    /** 		if tok[T_ID] = ELSE then*/
    _2 = (int)SEQ_PTR(_tok_57595);
    _29345 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29345, 23)){
        _29345 = NOVALUE;
        goto L12; // [481] 542
    }
    _29345 = NOVALUE;

    /** 			if sign = -1 then*/
    if (_sign_57637 != -1)
    goto L13; // [487] 499

    /** 				CompileErr( 71 )*/
    RefDS(_22037);
    _43CompileErr(71, _22037, 0);
L13: 

    /** 			if length(switch_stack[$][SWITCH_CASES]) = 0 then*/
    if (IS_SEQUENCE(_30switch_stack_54390)){
            _29348 = SEQ_PTR(_30switch_stack_54390)->length;
    }
    else {
        _29348 = 1;
    }
    _2 = (int)SEQ_PTR(_30switch_stack_54390);
    _29349 = (int)*(((s1_ptr)_2)->base + _29348);
    _2 = (int)SEQ_PTR(_29349);
    _29350 = (int)*(((s1_ptr)_2)->base + 1);
    _29349 = NOVALUE;
    if (IS_SEQUENCE(_29350)){
            _29351 = SEQ_PTR(_29350)->length;
    }
    else {
        _29351 = 1;
    }
    _29350 = NOVALUE;
    if (_29351 != 0)
    goto L14; // [517] 529

    /** 				CompileErr( 44 )*/
    RefDS(_22037);
    _43CompileErr(44, _22037, 0);
L14: 

    /** 			case_else()*/
    _30case_else();

    /** 			exit*/
    goto L15; // [537] 777
    goto L16; // [539] 613
L12: 

    /** 		elsif fwd then*/
    if (_fwd_57650 == 0)
    {
        goto L17; // [544] 596
    }
    else{
    }

    /** 			integer fwdref = new_forward_reference( CASE, fwd )*/
    DeRef(_31651);
    _31651 = 186;
    _fwdref_57729 = _29new_forward_reference(186, _fwd_57650, 186);
    _31651 = NOVALUE;
    if (!IS_ATOM_INT(_fwdref_57729)) {
        _1 = (long)(DBL_PTR(_fwdref_57729)->dbl);
        DeRefDS(_fwdref_57729);
        _fwdref_57729 = _1;
    }

    /** 			add_case( {fwdref}, sign )*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _fwdref_57729;
    _29354 = MAKE_SEQ(_1);
    _30add_case(_29354, _sign_57637);
    _29354 = NOVALUE;

    /** 			fwd:set_data( fwdref, switch_stack[$][SWITCH_PC] )*/
    if (IS_SEQUENCE(_30switch_stack_54390)){
            _29355 = SEQ_PTR(_30switch_stack_54390)->length;
    }
    else {
        _29355 = 1;
    }
    _2 = (int)SEQ_PTR(_30switch_stack_54390);
    _29356 = (int)*(((s1_ptr)_2)->base + _29355);
    _2 = (int)SEQ_PTR(_29356);
    _29357 = (int)*(((s1_ptr)_2)->base + 4);
    _29356 = NOVALUE;
    Ref(_29357);
    _29set_data(_fwdref_57729, _29357);
    _29357 = NOVALUE;
    goto L16; // [593] 613
L17: 

    /** 			condition = tok[T_SYM]*/
    _2 = (int)SEQ_PTR(_tok_57595);
    _condition_57597 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_condition_57597)){
        _condition_57597 = (long)DBL_PTR(_condition_57597)->dbl;
    }

    /** 			add_case( condition, sign )*/
    _30add_case(_condition_57597, _sign_57637);
L16: 

    /** 		tok = next_token()*/
    _0 = _tok_57595;
    _tok_57595 = _30next_token();
    DeRef(_0);

    /** 		if tok[T_ID] = THEN then*/
    _2 = (int)SEQ_PTR(_tok_57595);
    _29360 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29360, 410)){
        _29360 = NOVALUE;
        goto L18; // [628] 732
    }
    _29360 = NOVALUE;

    /** 			tok = next_token()*/
    _0 = _tok_57595;
    _tok_57595 = _30next_token();
    DeRef(_0);

    /** 			if tok[T_ID] = CASE then*/
    _2 = (int)SEQ_PTR(_tok_57595);
    _29363 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29363, 186)){
        _29363 = NOVALUE;
        goto L19; // [647] 717
    }
    _29363 = NOVALUE;

    /** 				if switch_stack[$][SWITCH_FALLTHRU] then*/
    if (IS_SEQUENCE(_30switch_stack_54390)){
            _29365 = SEQ_PTR(_30switch_stack_54390)->length;
    }
    else {
        _29365 = 1;
    }
    _2 = (int)SEQ_PTR(_30switch_stack_54390);
    _29366 = (int)*(((s1_ptr)_2)->base + _29365);
    _2 = (int)SEQ_PTR(_29366);
    _29367 = (int)*(((s1_ptr)_2)->base + 5);
    _29366 = NOVALUE;
    if (_29367 == 0) {
        _29367 = NOVALUE;
        goto L1A; // [666] 681
    }
    else {
        if (!IS_ATOM_INT(_29367) && DBL_PTR(_29367)->dbl == 0.0){
            _29367 = NOVALUE;
            goto L1A; // [666] 681
        }
        _29367 = NOVALUE;
    }
    _29367 = NOVALUE;

    /** 					start_line = line_number*/
    _start_line_57626 = _26line_number_11983;
    goto L1B; // [678] 770
L1A: 

    /** 					putback( tok )*/
    Ref(_tok_57595);
    _30putback(_tok_57595);

    /** 					Warning(220, empty_case_warning_flag,*/
    _2 = (int)SEQ_PTR(_27known_files_10922);
    _29368 = (int)*(((s1_ptr)_2)->base + _26current_file_no_11982);
    Ref(_29368);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _29368;
    ((int *)_2)[2] = _start_line_57626;
    _29369 = MAKE_SEQ(_1);
    _29368 = NOVALUE;
    _43Warning(220, 2048, _29369);
    _29369 = NOVALUE;

    /** 					exit*/
    goto L15; // [711] 777
    goto L1B; // [714] 770
L19: 

    /** 				putback( tok )*/
    Ref(_tok_57595);
    _30putback(_tok_57595);

    /** 				exit*/
    goto L15; // [726] 777
    goto L1B; // [729] 770
L18: 

    /** 		elsif tok[T_ID] != COMMA then*/
    _2 = (int)SEQ_PTR(_tok_57595);
    _29370 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _29370, -30)){
        _29370 = NOVALUE;
        goto L1C; // [742] 769
    }
    _29370 = NOVALUE;

    /** 			CompileErr(66,{LexName(tok[T_ID])})*/
    _2 = (int)SEQ_PTR(_tok_57595);
    _29372 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_29372);
    RefDS(_26480);
    _29373 = _37LexName(_29372, _26480);
    _29372 = NOVALUE;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _29373;
    _29374 = MAKE_SEQ(_1);
    _29373 = NOVALUE;
    _43CompileErr(66, _29374, 0);
    _29374 = NOVALUE;
L1C: 
L1B: 

    /** 	end while*/
    goto L4; // [774] 140
L15: 

    /** 	StartSourceLine( TRUE )*/
    _37StartSourceLine(_9TRUE_430, 0, 2);

    /** 	emit_temp( switch_stack[$][SWITCH_VALUE], NEW_REFERENCE )*/
    if (IS_SEQUENCE(_30switch_stack_54390)){
            _29375 = SEQ_PTR(_30switch_stack_54390)->length;
    }
    else {
        _29375 = 1;
    }
    _2 = (int)SEQ_PTR(_30switch_stack_54390);
    _29376 = (int)*(((s1_ptr)_2)->base + _29375);
    _2 = (int)SEQ_PTR(_29376);
    _29377 = (int)*(((s1_ptr)_2)->base + 6);
    _29376 = NOVALUE;
    Ref(_29377);
    _37emit_temp(_29377, 1);
    _29377 = NOVALUE;

    /** 	flush_temps()*/
    RefDS(_22037);
    _37flush_temps(_22037);

    /** end procedure*/
    DeRef(_tok_57595);
    _29300 = NOVALUE;
    DeRef(_29306);
    _29306 = NOVALUE;
    _29350 = NOVALUE;
    return;
    ;
}


void _30Fallthru_statement()
{
    int _29378 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not in_switch() then*/
    _29378 = _30in_switch();
    if (IS_ATOM_INT(_29378)) {
        if (_29378 != 0){
            DeRef(_29378);
            _29378 = NOVALUE;
            goto L1; // [6] 17
        }
    }
    else {
        if (DBL_PTR(_29378)->dbl != 0.0){
            DeRef(_29378);
            _29378 = NOVALUE;
            goto L1; // [6] 17
        }
    }
    DeRef(_29378);
    _29378 = NOVALUE;

    /** 		CompileErr( 22 )*/
    RefDS(_22037);
    _43CompileErr(22, _22037, 0);
L1: 

    /** 	tok_match( CASE )*/
    _30tok_match(186, 0);

    /** 	fallthru_case = 1*/
    _30fallthru_case_57591 = 1;

    /** 	Case_statement()*/
    _30Case_statement();

    /** end procedure*/
    return;
    ;
}


void _30update_translator_info(int _sym_57795, int _all_ints_57796, int _has_integer_57797, int _has_atom_57798, int _has_sequence_57799)
{
    int _29403 = NOVALUE;
    int _29401 = NOVALUE;
    int _29399 = NOVALUE;
    int _29397 = NOVALUE;
    int _29395 = NOVALUE;
    int _29394 = NOVALUE;
    int _29392 = NOVALUE;
    int _29390 = NOVALUE;
    int _29389 = NOVALUE;
    int _29388 = NOVALUE;
    int _29387 = NOVALUE;
    int _29386 = NOVALUE;
    int _29384 = NOVALUE;
    int _29382 = NOVALUE;
    int _29380 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	SymTab[sym][S_MODE] = M_TEMP    -- override CONSTANT for compile*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_57795 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = 3;
    DeRef(_1);
    _29380 = NOVALUE;

    /** 	SymTab[sym][S_GTYPE] = TYPE_SEQUENCE*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_57795 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 36);
    _1 = *(int *)_2;
    *(int *)_2 = 8;
    DeRef(_1);
    _29382 = NOVALUE;

    /** 	SymTab[sym][S_SEQ_LEN] = length( SymTab[sym][S_OBJ] )*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_57795 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _29386 = (int)*(((s1_ptr)_2)->base + _sym_57795);
    _2 = (int)SEQ_PTR(_29386);
    _29387 = (int)*(((s1_ptr)_2)->base + 1);
    _29386 = NOVALUE;
    if (IS_SEQUENCE(_29387)){
            _29388 = SEQ_PTR(_29387)->length;
    }
    else {
        _29388 = 1;
    }
    _29387 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 32);
    _1 = *(int *)_2;
    *(int *)_2 = _29388;
    if( _1 != _29388 ){
        DeRef(_1);
    }
    _29388 = NOVALUE;
    _29384 = NOVALUE;

    /** 	if SymTab[sym][S_SEQ_LEN] > 0 then*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _29389 = (int)*(((s1_ptr)_2)->base + _sym_57795);
    _2 = (int)SEQ_PTR(_29389);
    _29390 = (int)*(((s1_ptr)_2)->base + 32);
    _29389 = NOVALUE;
    if (binary_op_a(LESSEQ, _29390, 0)){
        _29390 = NOVALUE;
        goto L1; // [89] 198
    }
    _29390 = NOVALUE;

    /** 		if all_ints then*/
    if (_all_ints_57796 == 0)
    {
        goto L2; // [95] 118
    }
    else{
    }

    /** 			SymTab[sym][S_SEQ_ELEM] = TYPE_INTEGER*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_57795 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 33);
    _1 = *(int *)_2;
    *(int *)_2 = 1;
    DeRef(_1);
    _29392 = NOVALUE;
    goto L3; // [115] 216
L2: 

    /** 		elsif has_atom + has_sequence + has_integer > 1 then*/
    _29394 = _has_atom_57798 + _has_sequence_57799;
    if ((long)((unsigned long)_29394 + (unsigned long)HIGH_BITS) >= 0) 
    _29394 = NewDouble((double)_29394);
    if (IS_ATOM_INT(_29394)) {
        _29395 = _29394 + _has_integer_57797;
        if ((long)((unsigned long)_29395 + (unsigned long)HIGH_BITS) >= 0) 
        _29395 = NewDouble((double)_29395);
    }
    else {
        _29395 = NewDouble(DBL_PTR(_29394)->dbl + (double)_has_integer_57797);
    }
    DeRef(_29394);
    _29394 = NOVALUE;
    if (binary_op_a(LESSEQ, _29395, 1)){
        DeRef(_29395);
        _29395 = NOVALUE;
        goto L4; // [128] 152
    }
    DeRef(_29395);
    _29395 = NOVALUE;

    /** 			SymTab[sym][S_SEQ_ELEM] = TYPE_OBJECT*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_57795 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 33);
    _1 = *(int *)_2;
    *(int *)_2 = 16;
    DeRef(_1);
    _29397 = NOVALUE;
    goto L3; // [149] 216
L4: 

    /** 		elsif has_atom then*/
    if (_has_atom_57798 == 0)
    {
        goto L5; // [154] 177
    }
    else{
    }

    /** 			SymTab[sym][S_SEQ_ELEM] = TYPE_ATOM*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_57795 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 33);
    _1 = *(int *)_2;
    *(int *)_2 = 4;
    DeRef(_1);
    _29399 = NOVALUE;
    goto L3; // [174] 216
L5: 

    /** 			SymTab[sym][S_SEQ_ELEM] = TYPE_SEQUENCE*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_57795 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 33);
    _1 = *(int *)_2;
    *(int *)_2 = 8;
    DeRef(_1);
    _29401 = NOVALUE;
    goto L3; // [195] 216
L1: 

    /** 		SymTab[sym][S_SEQ_ELEM] = TYPE_NULL*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_57795 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 33);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _29403 = NOVALUE;
L3: 

    /** end procedure*/
    _29387 = NOVALUE;
    return;
    ;
}


void _30optimize_switch(int _switch_pc_57860, int _else_bp_57861, int _cases_57862, int _jump_table_57863)
{
    int _values_57864 = NOVALUE;
    int _min_57868 = NOVALUE;
    int _max_57870 = NOVALUE;
    int _all_ints_57872 = NOVALUE;
    int _has_integer_57873 = NOVALUE;
    int _has_atom_57874 = NOVALUE;
    int _has_sequence_57875 = NOVALUE;
    int _has_unassigned_57876 = NOVALUE;
    int _has_fwdref_57877 = NOVALUE;
    int _sym_57884 = NOVALUE;
    int _sign_57886 = NOVALUE;
    int _else_target_57950 = NOVALUE;
    int _opcode_57953 = NOVALUE;
    int _delta_57959 = NOVALUE;
    int _jump_57969 = NOVALUE;
    int _switch_table_57973 = NOVALUE;
    int _offset_57976 = NOVALUE;
    int _29481 = NOVALUE;
    int _29480 = NOVALUE;
    int _29479 = NOVALUE;
    int _29478 = NOVALUE;
    int _29476 = NOVALUE;
    int _29474 = NOVALUE;
    int _29471 = NOVALUE;
    int _29470 = NOVALUE;
    int _29469 = NOVALUE;
    int _29468 = NOVALUE;
    int _29467 = NOVALUE;
    int _29466 = NOVALUE;
    int _29465 = NOVALUE;
    int _29462 = NOVALUE;
    int _29460 = NOVALUE;
    int _29459 = NOVALUE;
    int _29458 = NOVALUE;
    int _29457 = NOVALUE;
    int _29456 = NOVALUE;
    int _29455 = NOVALUE;
    int _29454 = NOVALUE;
    int _29450 = NOVALUE;
    int _29449 = NOVALUE;
    int _29447 = NOVALUE;
    int _29446 = NOVALUE;
    int _29445 = NOVALUE;
    int _29444 = NOVALUE;
    int _29443 = NOVALUE;
    int _29442 = NOVALUE;
    int _29441 = NOVALUE;
    int _29440 = NOVALUE;
    int _29439 = NOVALUE;
    int _29438 = NOVALUE;
    int _29436 = NOVALUE;
    int _29435 = NOVALUE;
    int _29431 = NOVALUE;
    int _29428 = NOVALUE;
    int _29427 = NOVALUE;
    int _29426 = NOVALUE;
    int _29424 = NOVALUE;
    int _29423 = NOVALUE;
    int _29422 = NOVALUE;
    int _29421 = NOVALUE;
    int _29420 = NOVALUE;
    int _29418 = NOVALUE;
    int _29417 = NOVALUE;
    int _29416 = NOVALUE;
    int _29412 = NOVALUE;
    int _29411 = NOVALUE;
    int _29410 = NOVALUE;
    int _29406 = NOVALUE;
    int _29405 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	sequence values = switch_stack[$][SWITCH_CASES]*/
    if (IS_SEQUENCE(_30switch_stack_54390)){
            _29405 = SEQ_PTR(_30switch_stack_54390)->length;
    }
    else {
        _29405 = 1;
    }
    _2 = (int)SEQ_PTR(_30switch_stack_54390);
    _29406 = (int)*(((s1_ptr)_2)->base + _29405);
    DeRef(_values_57864);
    _2 = (int)SEQ_PTR(_29406);
    _values_57864 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_values_57864);
    _29406 = NOVALUE;

    /** 	atom min =  1e+300*/
    RefDS(_29408);
    DeRef(_min_57868);
    _min_57868 = _29408;

    /** 	atom max = -1e+300*/
    RefDS(_29409);
    DeRef(_max_57870);
    _max_57870 = _29409;

    /** 	integer all_ints = 1*/
    _all_ints_57872 = 1;

    /** 	integer has_integer    = 0*/
    _has_integer_57873 = 0;

    /** 	integer has_atom       = 0*/
    _has_atom_57874 = 0;

    /** 	integer has_sequence   = 0*/
    _has_sequence_57875 = 0;

    /** 	integer has_unassigned = 0*/
    _has_unassigned_57876 = 0;

    /** 	integer has_fwdref     = 0*/
    _has_fwdref_57877 = 0;

    /** 	for i = 1 to length( values ) do*/
    if (IS_SEQUENCE(_values_57864)){
            _29410 = SEQ_PTR(_values_57864)->length;
    }
    else {
        _29410 = 1;
    }
    {
        int _i_57879;
        _i_57879 = 1;
L1: 
        if (_i_57879 > _29410){
            goto L2; // [71] 292
        }

        /** 		if sequence( values[i] ) then*/
        _2 = (int)SEQ_PTR(_values_57864);
        _29411 = (int)*(((s1_ptr)_2)->base + _i_57879);
        _29412 = IS_SEQUENCE(_29411);
        _29411 = NOVALUE;
        if (_29412 == 0)
        {
            _29412 = NOVALUE;
            goto L3; // [87] 100
        }
        else{
            _29412 = NOVALUE;
        }

        /** 			has_fwdref = 1*/
        _has_fwdref_57877 = 1;

        /** 			exit*/
        goto L2; // [97] 292
L3: 

        /** 		integer sym = values[i]*/
        _2 = (int)SEQ_PTR(_values_57864);
        _sym_57884 = (int)*(((s1_ptr)_2)->base + _i_57879);
        if (!IS_ATOM_INT(_sym_57884))
        _sym_57884 = (long)DBL_PTR(_sym_57884)->dbl;

        /** 		integer sign*/

        /** 		if sym < 0 then*/
        if (_sym_57884 >= 0)
        goto L4; // [110] 129

        /** 			sign = -1*/
        _sign_57886 = -1;

        /** 			sym = -sym*/
        _sym_57884 = - _sym_57884;
        goto L5; // [126] 135
L4: 

        /** 			sign = 1*/
        _sign_57886 = 1;
L5: 

        /** 		if not equal(SymTab[sym][S_OBJ], NOVALUE) then*/
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _29416 = (int)*(((s1_ptr)_2)->base + _sym_57884);
        _2 = (int)SEQ_PTR(_29416);
        _29417 = (int)*(((s1_ptr)_2)->base + 1);
        _29416 = NOVALUE;
        if (_29417 == _26NOVALUE_11836)
        _29418 = 1;
        else if (IS_ATOM_INT(_29417) && IS_ATOM_INT(_26NOVALUE_11836))
        _29418 = 0;
        else
        _29418 = (compare(_29417, _26NOVALUE_11836) == 0);
        _29417 = NOVALUE;
        if (_29418 != 0)
        goto L6; // [155] 271
        _29418 = NOVALUE;

        /** 			values[i] = sign * SymTab[sym][S_OBJ]*/
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _29420 = (int)*(((s1_ptr)_2)->base + _sym_57884);
        _2 = (int)SEQ_PTR(_29420);
        _29421 = (int)*(((s1_ptr)_2)->base + 1);
        _29420 = NOVALUE;
        if (IS_ATOM_INT(_29421)) {
            if (_sign_57886 == (short)_sign_57886 && _29421 <= INT15 && _29421 >= -INT15)
            _29422 = _sign_57886 * _29421;
            else
            _29422 = NewDouble(_sign_57886 * (double)_29421);
        }
        else {
            _29422 = binary_op(MULTIPLY, _sign_57886, _29421);
        }
        _29421 = NOVALUE;
        _2 = (int)SEQ_PTR(_values_57864);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _values_57864 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_57879);
        _1 = *(int *)_2;
        *(int *)_2 = _29422;
        if( _1 != _29422 ){
            DeRef(_1);
        }
        _29422 = NOVALUE;

        /** 			if not integer( values[i] ) then*/
        _2 = (int)SEQ_PTR(_values_57864);
        _29423 = (int)*(((s1_ptr)_2)->base + _i_57879);
        if (IS_ATOM_INT(_29423))
        _29424 = 1;
        else if (IS_ATOM_DBL(_29423))
        _29424 = IS_ATOM_INT(DoubleToInt(_29423));
        else
        _29424 = 0;
        _29423 = NOVALUE;
        if (_29424 != 0)
        goto L7; // [191] 228
        _29424 = NOVALUE;

        /** 				all_ints = 0*/
        _all_ints_57872 = 0;

        /** 				if atom( values[i] ) then*/
        _2 = (int)SEQ_PTR(_values_57864);
        _29426 = (int)*(((s1_ptr)_2)->base + _i_57879);
        _29427 = IS_ATOM(_29426);
        _29426 = NOVALUE;
        if (_29427 == 0)
        {
            _29427 = NOVALUE;
            goto L8; // [208] 219
        }
        else{
            _29427 = NOVALUE;
        }

        /** 					has_atom = 1*/
        _has_atom_57874 = 1;
        goto L9; // [216] 283
L8: 

        /** 					has_sequence = 1*/
        _has_sequence_57875 = 1;
        goto L9; // [225] 283
L7: 

        /** 				has_integer = 1*/
        _has_integer_57873 = 1;

        /** 				if values[i] < min then*/
        _2 = (int)SEQ_PTR(_values_57864);
        _29428 = (int)*(((s1_ptr)_2)->base + _i_57879);
        if (binary_op_a(GREATEREQ, _29428, _min_57868)){
            _29428 = NOVALUE;
            goto LA; // [239] 250
        }
        _29428 = NOVALUE;

        /** 					min = values[i]*/
        DeRef(_min_57868);
        _2 = (int)SEQ_PTR(_values_57864);
        _min_57868 = (int)*(((s1_ptr)_2)->base + _i_57879);
        Ref(_min_57868);
LA: 

        /** 				if values[i] > max then*/
        _2 = (int)SEQ_PTR(_values_57864);
        _29431 = (int)*(((s1_ptr)_2)->base + _i_57879);
        if (binary_op_a(LESSEQ, _29431, _max_57870)){
            _29431 = NOVALUE;
            goto L9; // [256] 283
        }
        _29431 = NOVALUE;

        /** 					max = values[i]*/
        DeRef(_max_57870);
        _2 = (int)SEQ_PTR(_values_57864);
        _max_57870 = (int)*(((s1_ptr)_2)->base + _i_57879);
        Ref(_max_57870);
        goto L9; // [268] 283
L6: 

        /** 			has_unassigned = 1*/
        _has_unassigned_57876 = 1;

        /** 			exit*/
        goto L2; // [280] 292
L9: 

        /** 	end for*/
        _i_57879 = _i_57879 + 1;
        goto L1; // [287] 78
L2: 
        ;
    }

    /** 	if has_unassigned or has_fwdref then*/
    if (_has_unassigned_57876 != 0) {
        goto LB; // [294] 303
    }
    if (_has_fwdref_57877 == 0)
    {
        goto LC; // [299] 321
    }
    else{
    }
LB: 

    /** 		values = switch_stack[$][SWITCH_CASES]*/
    if (IS_SEQUENCE(_30switch_stack_54390)){
            _29435 = SEQ_PTR(_30switch_stack_54390)->length;
    }
    else {
        _29435 = 1;
    }
    _2 = (int)SEQ_PTR(_30switch_stack_54390);
    _29436 = (int)*(((s1_ptr)_2)->base + _29435);
    DeRef(_values_57864);
    _2 = (int)SEQ_PTR(_29436);
    _values_57864 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_values_57864);
    _29436 = NOVALUE;
LC: 

    /** 	if switch_stack[$][SWITCH_ELSE] then*/
    if (IS_SEQUENCE(_30switch_stack_54390)){
            _29438 = SEQ_PTR(_30switch_stack_54390)->length;
    }
    else {
        _29438 = 1;
    }
    _2 = (int)SEQ_PTR(_30switch_stack_54390);
    _29439 = (int)*(((s1_ptr)_2)->base + _29438);
    _2 = (int)SEQ_PTR(_29439);
    _29440 = (int)*(((s1_ptr)_2)->base + 3);
    _29439 = NOVALUE;
    if (_29440 == 0) {
        _29440 = NOVALUE;
        goto LD; // [336] 363
    }
    else {
        if (!IS_ATOM_INT(_29440) && DBL_PTR(_29440)->dbl == 0.0){
            _29440 = NOVALUE;
            goto LD; // [336] 363
        }
        _29440 = NOVALUE;
    }
    _29440 = NOVALUE;

    /** 			Code[else_bp] = switch_stack[$][SWITCH_ELSE]*/
    if (IS_SEQUENCE(_30switch_stack_54390)){
            _29441 = SEQ_PTR(_30switch_stack_54390)->length;
    }
    else {
        _29441 = 1;
    }
    _2 = (int)SEQ_PTR(_30switch_stack_54390);
    _29442 = (int)*(((s1_ptr)_2)->base + _29441);
    _2 = (int)SEQ_PTR(_29442);
    _29443 = (int)*(((s1_ptr)_2)->base + 3);
    _29442 = NOVALUE;
    Ref(_29443);
    _2 = (int)SEQ_PTR(_26Code_12071);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _26Code_12071 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _else_bp_57861);
    _1 = *(int *)_2;
    *(int *)_2 = _29443;
    if( _1 != _29443 ){
        DeRef(_1);
    }
    _29443 = NOVALUE;
    goto LE; // [360] 387
LD: 

    /** 		Code[else_bp] = length(Code) + 1 + TRANSLATE*/
    if (IS_SEQUENCE(_26Code_12071)){
            _29444 = SEQ_PTR(_26Code_12071)->length;
    }
    else {
        _29444 = 1;
    }
    _29445 = _29444 + 1;
    _29444 = NOVALUE;
    _29446 = _29445 + _26TRANSLATE_11619;
    _29445 = NOVALUE;
    _2 = (int)SEQ_PTR(_26Code_12071);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _26Code_12071 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _else_bp_57861);
    _1 = *(int *)_2;
    *(int *)_2 = _29446;
    if( _1 != _29446 ){
        DeRef(_1);
    }
    _29446 = NOVALUE;
LE: 

    /** 	if TRANSLATE then*/
    if (_26TRANSLATE_11619 == 0)
    {
        goto LF; // [391] 418
    }
    else{
    }

    /** 		SymTab[cases][S_OBJ] &= 0*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_cases_57862 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    _29449 = (int)*(((s1_ptr)_2)->base + 1);
    _29447 = NOVALUE;
    if (IS_SEQUENCE(_29449) && IS_ATOM(0)) {
        Append(&_29450, _29449, 0);
    }
    else if (IS_ATOM(_29449) && IS_SEQUENCE(0)) {
    }
    else {
        Concat((object_ptr)&_29450, _29449, 0);
        _29449 = NOVALUE;
    }
    _29449 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _29450;
    if( _1 != _29450 ){
        DeRef(_1);
    }
    _29450 = NOVALUE;
    _29447 = NOVALUE;
LF: 

    /** 	integer else_target = Code[else_bp]*/
    _2 = (int)SEQ_PTR(_26Code_12071);
    _else_target_57950 = (int)*(((s1_ptr)_2)->base + _else_bp_57861);
    if (!IS_ATOM_INT(_else_target_57950)){
        _else_target_57950 = (long)DBL_PTR(_else_target_57950)->dbl;
    }

    /** 	integer opcode = SWITCH*/
    _opcode_57953 = 185;

    /** 	if has_unassigned or has_fwdref then*/
    if (_has_unassigned_57876 != 0) {
        goto L10; // [439] 448
    }
    if (_has_fwdref_57877 == 0)
    {
        goto L11; // [444] 460
    }
    else{
    }
L10: 

    /** 		opcode = SWITCH_RT*/
    _opcode_57953 = 202;
    goto L12; // [457] 630
L11: 

    /** 	elsif all_ints then*/
    if (_all_ints_57872 == 0)
    {
        goto L13; // [462] 627
    }
    else{
    }

    /** 		atom delta = max - min*/
    DeRef(_delta_57959);
    if (IS_ATOM_INT(_max_57870) && IS_ATOM_INT(_min_57868)) {
        _delta_57959 = _max_57870 - _min_57868;
        if ((long)((unsigned long)_delta_57959 +(unsigned long) HIGH_BITS) >= 0){
            _delta_57959 = NewDouble((double)_delta_57959);
        }
    }
    else {
        if (IS_ATOM_INT(_max_57870)) {
            _delta_57959 = NewDouble((double)_max_57870 - DBL_PTR(_min_57868)->dbl);
        }
        else {
            if (IS_ATOM_INT(_min_57868)) {
                _delta_57959 = NewDouble(DBL_PTR(_max_57870)->dbl - (double)_min_57868);
            }
            else
            _delta_57959 = NewDouble(DBL_PTR(_max_57870)->dbl - DBL_PTR(_min_57868)->dbl);
        }
    }

    /** 		if not TRANSLATE and  delta < 1024 and delta >= 0 then*/
    _29454 = (_26TRANSLATE_11619 == 0);
    if (_29454 == 0) {
        _29455 = 0;
        goto L14; // [478] 490
    }
    if (IS_ATOM_INT(_delta_57959)) {
        _29456 = (_delta_57959 < 1024);
    }
    else {
        _29456 = (DBL_PTR(_delta_57959)->dbl < (double)1024);
    }
    _29455 = (_29456 != 0);
L14: 
    if (_29455 == 0) {
        goto L15; // [490] 616
    }
    if (IS_ATOM_INT(_delta_57959)) {
        _29458 = (_delta_57959 >= 0);
    }
    else {
        _29458 = (DBL_PTR(_delta_57959)->dbl >= (double)0);
    }
    if (_29458 == 0)
    {
        DeRef(_29458);
        _29458 = NOVALUE;
        goto L15; // [499] 616
    }
    else{
        DeRef(_29458);
        _29458 = NOVALUE;
    }

    /** 			opcode = SWITCH_SPI*/
    _opcode_57953 = 192;

    /** 			sequence jump = switch_stack[$][SWITCH_JUMP_TABLE]*/
    if (IS_SEQUENCE(_30switch_stack_54390)){
            _29459 = SEQ_PTR(_30switch_stack_54390)->length;
    }
    else {
        _29459 = 1;
    }
    _2 = (int)SEQ_PTR(_30switch_stack_54390);
    _29460 = (int)*(((s1_ptr)_2)->base + _29459);
    DeRef(_jump_57969);
    _2 = (int)SEQ_PTR(_29460);
    _jump_57969 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_jump_57969);
    _29460 = NOVALUE;

    /** 			sequence switch_table = repeat( else_target, delta + 1 )*/
    if (IS_ATOM_INT(_delta_57959)) {
        _29462 = _delta_57959 + 1;
    }
    else
    _29462 = binary_op(PLUS, 1, _delta_57959);
    DeRef(_switch_table_57973);
    _switch_table_57973 = Repeat(_else_target_57950, _29462);
    DeRef(_29462);
    _29462 = NOVALUE;

    /** 			integer offset = min - 1*/
    if (IS_ATOM_INT(_min_57868)) {
        _offset_57976 = _min_57868 - 1;
    }
    else {
        _offset_57976 = NewDouble(DBL_PTR(_min_57868)->dbl - (double)1);
    }
    if (!IS_ATOM_INT(_offset_57976)) {
        _1 = (long)(DBL_PTR(_offset_57976)->dbl);
        DeRefDS(_offset_57976);
        _offset_57976 = _1;
    }

    /** 			for i = 1 to length( values ) do*/
    if (IS_SEQUENCE(_values_57864)){
            _29465 = SEQ_PTR(_values_57864)->length;
    }
    else {
        _29465 = 1;
    }
    {
        int _i_57979;
        _i_57979 = 1;
L16: 
        if (_i_57979 > _29465){
            goto L17; // [551] 583
        }

        /** 				switch_table[values[i] - offset] = jump[i]*/
        _2 = (int)SEQ_PTR(_values_57864);
        _29466 = (int)*(((s1_ptr)_2)->base + _i_57979);
        if (IS_ATOM_INT(_29466)) {
            _29467 = _29466 - _offset_57976;
            if ((long)((unsigned long)_29467 +(unsigned long) HIGH_BITS) >= 0){
                _29467 = NewDouble((double)_29467);
            }
        }
        else {
            _29467 = binary_op(MINUS, _29466, _offset_57976);
        }
        _29466 = NOVALUE;
        _2 = (int)SEQ_PTR(_jump_57969);
        _29468 = (int)*(((s1_ptr)_2)->base + _i_57979);
        Ref(_29468);
        _2 = (int)SEQ_PTR(_switch_table_57973);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _switch_table_57973 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_29467))
        _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_29467)->dbl));
        else
        _2 = (int)(((s1_ptr)_2)->base + _29467);
        _1 = *(int *)_2;
        *(int *)_2 = _29468;
        if( _1 != _29468 ){
            DeRef(_1);
        }
        _29468 = NOVALUE;

        /** 			end for*/
        _i_57979 = _i_57979 + 1;
        goto L16; // [578] 558
L17: 
        ;
    }

    /** 			Code[switch_pc + 2] = offset*/
    _29469 = _switch_pc_57860 + 2;
    _2 = (int)SEQ_PTR(_26Code_12071);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _26Code_12071 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _29469);
    _1 = *(int *)_2;
    *(int *)_2 = _offset_57976;
    DeRef(_1);

    /** 			switch_stack[$][SWITCH_JUMP_TABLE] = switch_table*/
    if (IS_SEQUENCE(_30switch_stack_54390)){
            _29470 = SEQ_PTR(_30switch_stack_54390)->length;
    }
    else {
        _29470 = 1;
    }
    _2 = (int)SEQ_PTR(_30switch_stack_54390);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _30switch_stack_54390 = MAKE_SEQ(_2);
    }
    _3 = (int)(_29470 + ((s1_ptr)_2)->base);
    RefDS(_switch_table_57973);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _switch_table_57973;
    DeRef(_1);
    _29471 = NOVALUE;
    DeRef(_jump_57969);
    _jump_57969 = NOVALUE;
    DeRefDS(_switch_table_57973);
    _switch_table_57973 = NOVALUE;
    goto L18; // [613] 626
L15: 

    /** 			opcode = SWITCH_I*/
    _opcode_57953 = 193;
L18: 
L13: 
    DeRef(_delta_57959);
    _delta_57959 = NOVALUE;
L12: 

    /** 	Code[switch_pc] = opcode*/
    _2 = (int)SEQ_PTR(_26Code_12071);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _26Code_12071 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _switch_pc_57860);
    _1 = *(int *)_2;
    *(int *)_2 = _opcode_57953;
    DeRef(_1);

    /** 	if opcode != SWITCH_SPI then*/
    if (_opcode_57953 == 192)
    goto L19; // [642] 679

    /** 		SymTab[cases][S_OBJ] = values*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_cases_57862 + ((s1_ptr)_2)->base);
    RefDS(_values_57864);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _values_57864;
    DeRef(_1);
    _29474 = NOVALUE;

    /** 		if TRANSLATE then*/
    if (_26TRANSLATE_11619 == 0)
    {
        goto L1A; // [665] 678
    }
    else{
    }

    /** 			update_translator_info( cases, all_ints, has_integer, has_atom, has_sequence )*/
    _30update_translator_info(_cases_57862, _all_ints_57872, _has_integer_57873, _has_atom_57874, _has_sequence_57875);
L1A: 
L19: 

    /** 	SymTab[jump_table][S_OBJ] = switch_stack[$][SWITCH_JUMP_TABLE] - switch_pc*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_jump_table_57863 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_30switch_stack_54390)){
            _29478 = SEQ_PTR(_30switch_stack_54390)->length;
    }
    else {
        _29478 = 1;
    }
    _2 = (int)SEQ_PTR(_30switch_stack_54390);
    _29479 = (int)*(((s1_ptr)_2)->base + _29478);
    _2 = (int)SEQ_PTR(_29479);
    _29480 = (int)*(((s1_ptr)_2)->base + 2);
    _29479 = NOVALUE;
    if (IS_ATOM_INT(_29480)) {
        _29481 = _29480 - _switch_pc_57860;
        if ((long)((unsigned long)_29481 +(unsigned long) HIGH_BITS) >= 0){
            _29481 = NewDouble((double)_29481);
        }
    }
    else {
        _29481 = binary_op(MINUS, _29480, _switch_pc_57860);
    }
    _29480 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _29481;
    if( _1 != _29481 ){
        DeRef(_1);
    }
    _29481 = NOVALUE;
    _29476 = NOVALUE;

    /** end procedure*/
    DeRef(_values_57864);
    DeRef(_min_57868);
    DeRef(_max_57870);
    DeRef(_29454);
    _29454 = NOVALUE;
    DeRef(_29456);
    _29456 = NOVALUE;
    DeRef(_29469);
    _29469 = NOVALUE;
    DeRef(_29467);
    _29467 = NOVALUE;
    return;
    ;
}


void _30Switch_statement()
{
    int _else_case_2__tmp_at250_58073 = NOVALUE;
    int _else_case_1__tmp_at250_58072 = NOVALUE;
    int _else_case_inlined_else_case_at_250_58071 = NOVALUE;
    int _break_base_58011 = NOVALUE;
    int _cases_58013 = NOVALUE;
    int _jump_table_58014 = NOVALUE;
    int _else_bp_58015 = NOVALUE;
    int _switch_pc_58016 = NOVALUE;
    int _t_58053 = NOVALUE;
    int _29512 = NOVALUE;
    int _29511 = NOVALUE;
    int _29510 = NOVALUE;
    int _29509 = NOVALUE;
    int _29508 = NOVALUE;
    int _29504 = NOVALUE;
    int _29500 = NOVALUE;
    int _29499 = NOVALUE;
    int _29497 = NOVALUE;
    int _29496 = NOVALUE;
    int _29494 = NOVALUE;
    int _29493 = NOVALUE;
    int _29491 = NOVALUE;
    int _29490 = NOVALUE;
    int _29489 = NOVALUE;
    int _29488 = NOVALUE;
    int _29487 = NOVALUE;
    int _29486 = NOVALUE;
    int _29484 = NOVALUE;
    int _29483 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	integer else_bp*/

    /** 	integer switch_pc*/

    /** 	push_switch()*/
    _30push_switch();

    /** 	break_base = length(break_list)*/
    if (IS_SEQUENCE(_30break_list_54174)){
            _break_base_58011 = SEQ_PTR(_30break_list_54174)->length;
    }
    else {
        _break_base_58011 = 1;
    }

    /** 	Expr()*/
    _30Expr();

    /** 	switch_stack[$][SWITCH_VALUE] = Top()*/
    if (IS_SEQUENCE(_30switch_stack_54390)){
            _29483 = SEQ_PTR(_30switch_stack_54390)->length;
    }
    else {
        _29483 = 1;
    }
    _2 = (int)SEQ_PTR(_30switch_stack_54390);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _30switch_stack_54390 = MAKE_SEQ(_2);
    }
    _3 = (int)(_29483 + ((s1_ptr)_2)->base);
    _29486 = _37Top();
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 6);
    _1 = *(int *)_2;
    *(int *)_2 = _29486;
    if( _1 != _29486 ){
        DeRef(_1);
    }
    _29486 = NOVALUE;
    _29484 = NOVALUE;

    /** 	clear_temp( switch_stack[$][SWITCH_VALUE] )*/
    if (IS_SEQUENCE(_30switch_stack_54390)){
            _29487 = SEQ_PTR(_30switch_stack_54390)->length;
    }
    else {
        _29487 = 1;
    }
    _2 = (int)SEQ_PTR(_30switch_stack_54390);
    _29488 = (int)*(((s1_ptr)_2)->base + _29487);
    _2 = (int)SEQ_PTR(_29488);
    _29489 = (int)*(((s1_ptr)_2)->base + 6);
    _29488 = NOVALUE;
    Ref(_29489);
    _37clear_temp(_29489);
    _29489 = NOVALUE;

    /** 	cases = NewStringSym( {-1, length(SymTab) } )*/
    if (IS_SEQUENCE(_27SymTab_10921)){
            _29490 = SEQ_PTR(_27SymTab_10921)->length;
    }
    else {
        _29490 = 1;
    }
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -1;
    ((int *)_2)[2] = _29490;
    _29491 = MAKE_SEQ(_1);
    _29490 = NOVALUE;
    _cases_58013 = _52NewStringSym(_29491);
    _29491 = NOVALUE;
    if (!IS_ATOM_INT(_cases_58013)) {
        _1 = (long)(DBL_PTR(_cases_58013)->dbl);
        DeRefDS(_cases_58013);
        _cases_58013 = _1;
    }

    /** 	emit_opnd( cases )*/
    _37emit_opnd(_cases_58013);

    /** 	jump_table = NewStringSym( {-2, length(SymTab) } )*/
    if (IS_SEQUENCE(_27SymTab_10921)){
            _29493 = SEQ_PTR(_27SymTab_10921)->length;
    }
    else {
        _29493 = 1;
    }
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -2;
    ((int *)_2)[2] = _29493;
    _29494 = MAKE_SEQ(_1);
    _29493 = NOVALUE;
    _jump_table_58014 = _52NewStringSym(_29494);
    _29494 = NOVALUE;
    if (!IS_ATOM_INT(_jump_table_58014)) {
        _1 = (long)(DBL_PTR(_jump_table_58014)->dbl);
        DeRefDS(_jump_table_58014);
        _jump_table_58014 = _1;
    }

    /** 	emit_opnd( jump_table )*/
    _37emit_opnd(_jump_table_58014);

    /** 	if finish_block_header(SWITCH) then end if*/
    _29496 = _30finish_block_header(185);
    if (_29496 == 0) {
        DeRef(_29496);
        _29496 = NOVALUE;
        goto L1; // [109] 113
    }
    else {
        if (!IS_ATOM_INT(_29496) && DBL_PTR(_29496)->dbl == 0.0){
            DeRef(_29496);
            _29496 = NOVALUE;
            goto L1; // [109] 113
        }
        DeRef(_29496);
        _29496 = NOVALUE;
    }
    DeRef(_29496);
    _29496 = NOVALUE;
L1: 

    /** 	switch_pc = length(Code) + 1*/
    if (IS_SEQUENCE(_26Code_12071)){
            _29497 = SEQ_PTR(_26Code_12071)->length;
    }
    else {
        _29497 = 1;
    }
    _switch_pc_58016 = _29497 + 1;
    _29497 = NOVALUE;

    /** 	switch_stack[$][SWITCH_PC] = switch_pc*/
    if (IS_SEQUENCE(_30switch_stack_54390)){
            _29499 = SEQ_PTR(_30switch_stack_54390)->length;
    }
    else {
        _29499 = 1;
    }
    _2 = (int)SEQ_PTR(_30switch_stack_54390);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _30switch_stack_54390 = MAKE_SEQ(_2);
    }
    _3 = (int)(_29499 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = _switch_pc_58016;
    DeRef(_1);
    _29500 = NOVALUE;

    /** 	emit_op(SWITCH)*/
    _37emit_op(185);

    /** 	emit_forward_addr()  -- the else*/
    _30emit_forward_addr();

    /** 	else_bp = length( Code )*/
    if (IS_SEQUENCE(_26Code_12071)){
            _else_bp_58015 = SEQ_PTR(_26Code_12071)->length;
    }
    else {
        _else_bp_58015 = 1;
    }

    /** 	t = next_token()*/
    _0 = _t_58053;
    _t_58053 = _30next_token();
    DeRef(_0);

    /** 	if t[T_ID] = CASE then*/
    _2 = (int)SEQ_PTR(_t_58053);
    _29504 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29504, 186)){
        _29504 = NOVALUE;
        goto L2; // [173] 188
    }
    _29504 = NOVALUE;

    /** 		Case_statement()*/
    _30Case_statement();

    /** 		Statement_list()*/
    _30Statement_list();
    goto L3; // [185] 194
L2: 

    /** 		putback(t)*/
    Ref(_t_58053);
    _30putback(_t_58053);
L3: 

    /** 	optimize_switch( switch_pc, else_bp, cases, jump_table )*/
    _30optimize_switch(_switch_pc_58016, _else_bp_58015, _cases_58013, _jump_table_58014);

    /** 	tok_match(END)*/
    _30tok_match(402, 0);

    /** 	tok_match(SWITCH, END)*/
    _30tok_match(185, 402);

    /** 	if TRANSLATE then*/
    if (_26TRANSLATE_11619 == 0)
    {
        goto L4; // [224] 235
    }
    else{
    }

    /** 		emit_op(NOPSWITCH)*/
    _37emit_op(187);
L4: 

    /** 	if not else_case() then*/

    /** 	return switch_stack[$][SWITCH_ELSE]*/
    if (IS_SEQUENCE(_30switch_stack_54390)){
            _else_case_1__tmp_at250_58072 = SEQ_PTR(_30switch_stack_54390)->length;
    }
    else {
        _else_case_1__tmp_at250_58072 = 1;
    }
    DeRef(_else_case_2__tmp_at250_58073);
    _2 = (int)SEQ_PTR(_30switch_stack_54390);
    _else_case_2__tmp_at250_58073 = (int)*(((s1_ptr)_2)->base + _else_case_1__tmp_at250_58072);
    RefDS(_else_case_2__tmp_at250_58073);
    DeRef(_else_case_inlined_else_case_at_250_58071);
    _2 = (int)SEQ_PTR(_else_case_2__tmp_at250_58073);
    _else_case_inlined_else_case_at_250_58071 = (int)*(((s1_ptr)_2)->base + 3);
    Ref(_else_case_inlined_else_case_at_250_58071);
    DeRef(_else_case_2__tmp_at250_58073);
    _else_case_2__tmp_at250_58073 = NOVALUE;
    if (IS_ATOM_INT(_else_case_inlined_else_case_at_250_58071)) {
        if (_else_case_inlined_else_case_at_250_58071 != 0){
            goto L5; // [255] 327
        }
    }
    else {
        if (DBL_PTR(_else_case_inlined_else_case_at_250_58071)->dbl != 0.0){
            goto L5; // [255] 327
        }
    }

    /** 		if not TRANSLATE then*/
    if (_26TRANSLATE_11619 != 0)
    goto L6; // [262] 303

    /** 			StartSourceLine( TRUE, , COVERAGE_SUPPRESS )*/
    _37StartSourceLine(_9TRUE_430, 0, 1);

    /** 			emit_temp( switch_stack[$][SWITCH_VALUE], NEW_REFERENCE )*/
    if (IS_SEQUENCE(_30switch_stack_54390)){
            _29508 = SEQ_PTR(_30switch_stack_54390)->length;
    }
    else {
        _29508 = 1;
    }
    _2 = (int)SEQ_PTR(_30switch_stack_54390);
    _29509 = (int)*(((s1_ptr)_2)->base + _29508);
    _2 = (int)SEQ_PTR(_29509);
    _29510 = (int)*(((s1_ptr)_2)->base + 6);
    _29509 = NOVALUE;
    Ref(_29510);
    _37emit_temp(_29510, 1);
    _29510 = NOVALUE;

    /** 			flush_temps()*/
    RefDS(_22037);
    _37flush_temps(_22037);
L6: 

    /** 		Warning(221, no_case_else_warning_flag,*/
    _2 = (int)SEQ_PTR(_27known_files_10922);
    _29511 = (int)*(((s1_ptr)_2)->base + _26current_file_no_11982);
    Ref(_29511);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _29511;
    ((int *)_2)[2] = _26line_number_11983;
    _29512 = MAKE_SEQ(_1);
    _29511 = NOVALUE;
    _43Warning(221, 4096, _29512);
    _29512 = NOVALUE;
L5: 

    /** 	pop_switch( break_base )*/
    _30pop_switch(_break_base_58011);

    /** end procedure*/
    DeRef(_t_58053);
    return;
    ;
}


int _30get_private_uninitialized()
{
    int _uninitialized_58096 = NOVALUE;
    int _s_58102 = NOVALUE;
    int _pu_58108 = NOVALUE;
    int _29529 = NOVALUE;
    int _29527 = NOVALUE;
    int _29526 = NOVALUE;
    int _29525 = NOVALUE;
    int _29524 = NOVALUE;
    int _29523 = NOVALUE;
    int _29522 = NOVALUE;
    int _29521 = NOVALUE;
    int _29520 = NOVALUE;
    int _29519 = NOVALUE;
    int _29518 = NOVALUE;
    int _29517 = NOVALUE;
    int _29514 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence uninitialized = {}*/
    RefDS(_22037);
    DeRefi(_uninitialized_58096);
    _uninitialized_58096 = _22037;

    /** 	if CurrentSub != TopLevelSub then*/
    if (_26CurrentSub_11990 == _26TopLevelSub_11989)
    goto L1; // [14] 149

    /** 		symtab_pointer s = SymTab[CurrentSub][S_NEXT]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _29514 = (int)*(((s1_ptr)_2)->base + _26CurrentSub_11990);
    _2 = (int)SEQ_PTR(_29514);
    _s_58102 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_58102)){
        _s_58102 = (long)DBL_PTR(_s_58102)->dbl;
    }
    _29514 = NOVALUE;

    /** 		sequence pu = { SC_PRIVATE, SC_UNDEFINED }*/
    DeRefi(_pu_58108);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 3;
    ((int *)_2)[2] = 9;
    _pu_58108 = MAKE_SEQ(_1);

    /** 		while s and find( SymTab[s][S_SCOPE], pu ) do*/
L2: 
    if (_s_58102 == 0) {
        goto L3; // [51] 148
    }
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _29518 = (int)*(((s1_ptr)_2)->base + _s_58102);
    _2 = (int)SEQ_PTR(_29518);
    _29519 = (int)*(((s1_ptr)_2)->base + 4);
    _29518 = NOVALUE;
    _29520 = find_from(_29519, _pu_58108, 1);
    _29519 = NOVALUE;
    if (_29520 == 0)
    {
        _29520 = NOVALUE;
        goto L3; // [73] 148
    }
    else{
        _29520 = NOVALUE;
    }

    /** 			if SymTab[s][S_SCOPE] = SC_PRIVATE and SymTab[s][S_INITLEVEL] = -1 then*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _29521 = (int)*(((s1_ptr)_2)->base + _s_58102);
    _2 = (int)SEQ_PTR(_29521);
    _29522 = (int)*(((s1_ptr)_2)->base + 4);
    _29521 = NOVALUE;
    if (IS_ATOM_INT(_29522)) {
        _29523 = (_29522 == 3);
    }
    else {
        _29523 = binary_op(EQUALS, _29522, 3);
    }
    _29522 = NOVALUE;
    if (IS_ATOM_INT(_29523)) {
        if (_29523 == 0) {
            goto L4; // [96] 127
        }
    }
    else {
        if (DBL_PTR(_29523)->dbl == 0.0) {
            goto L4; // [96] 127
        }
    }
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _29525 = (int)*(((s1_ptr)_2)->base + _s_58102);
    _2 = (int)SEQ_PTR(_29525);
    _29526 = (int)*(((s1_ptr)_2)->base + 14);
    _29525 = NOVALUE;
    if (IS_ATOM_INT(_29526)) {
        _29527 = (_29526 == -1);
    }
    else {
        _29527 = binary_op(EQUALS, _29526, -1);
    }
    _29526 = NOVALUE;
    if (_29527 == 0) {
        DeRef(_29527);
        _29527 = NOVALUE;
        goto L4; // [117] 127
    }
    else {
        if (!IS_ATOM_INT(_29527) && DBL_PTR(_29527)->dbl == 0.0){
            DeRef(_29527);
            _29527 = NOVALUE;
            goto L4; // [117] 127
        }
        DeRef(_29527);
        _29527 = NOVALUE;
    }
    DeRef(_29527);
    _29527 = NOVALUE;

    /** 				uninitialized &= s*/
    Append(&_uninitialized_58096, _uninitialized_58096, _s_58102);
L4: 

    /** 			s = SymTab[s][S_NEXT]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _29529 = (int)*(((s1_ptr)_2)->base + _s_58102);
    _2 = (int)SEQ_PTR(_29529);
    _s_58102 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_58102)){
        _s_58102 = (long)DBL_PTR(_s_58102)->dbl;
    }
    _29529 = NOVALUE;

    /** 		end while*/
    goto L2; // [145] 51
L3: 
L1: 
    DeRefi(_pu_58108);
    _pu_58108 = NOVALUE;

    /** 	return uninitialized*/
    DeRef(_29523);
    _29523 = NOVALUE;
    return _uninitialized_58096;
    ;
}


void _30While_statement()
{
    int _bp1_58139 = NOVALUE;
    int _bp2_58140 = NOVALUE;
    int _exit_base_58141 = NOVALUE;
    int _next_base_58142 = NOVALUE;
    int _uninitialized_58143 = NOVALUE;
    int _temps_58213 = NOVALUE;
    int _29565 = NOVALUE;
    int _29564 = NOVALUE;
    int _29563 = NOVALUE;
    int _29559 = NOVALUE;
    int _29558 = NOVALUE;
    int _29556 = NOVALUE;
    int _29554 = NOVALUE;
    int _29553 = NOVALUE;
    int _29552 = NOVALUE;
    int _29548 = NOVALUE;
    int _29546 = NOVALUE;
    int _29544 = NOVALUE;
    int _29538 = NOVALUE;
    int _29536 = NOVALUE;
    int _29535 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence uninitialized = get_private_uninitialized()*/
    _0 = _uninitialized_58143;
    _uninitialized_58143 = _30get_private_uninitialized();
    DeRef(_0);

    /** 	entry_stack = append( entry_stack, uninitialized )*/
    RefDS(_uninitialized_58143);
    Append(&_30entry_stack_54183, _30entry_stack_54183, _uninitialized_58143);

    /** 	Start_block( WHILE )*/
    _65Start_block(47, 0);

    /** 	exit_base = length(exit_list)*/
    if (IS_SEQUENCE(_30exit_list_54176)){
            _exit_base_58141 = SEQ_PTR(_30exit_list_54176)->length;
    }
    else {
        _exit_base_58141 = 1;
    }

    /** 	next_base = length(continue_list)*/
    if (IS_SEQUENCE(_30continue_list_54178)){
            _next_base_58142 = SEQ_PTR(_30continue_list_54178)->length;
    }
    else {
        _next_base_58142 = 1;
    }

    /** 	entry_addr &= length(Code)+1*/
    if (IS_SEQUENCE(_26Code_12071)){
            _29535 = SEQ_PTR(_26Code_12071)->length;
    }
    else {
        _29535 = 1;
    }
    _29536 = _29535 + 1;
    _29535 = NOVALUE;
    Append(&_30entry_addr_54180, _30entry_addr_54180, _29536);
    _29536 = NOVALUE;

    /** 	emit_op(NOP2) -- Entry_statement may patch this later*/
    _37emit_op(110);

    /** 	emit_addr(0)*/
    _37emit_addr(0);

    /** 	if TRANSLATE then*/
    if (_26TRANSLATE_11619 == 0)
    {
        goto L1; // [71] 82
    }
    else{
    }

    /** 		emit_op(NOPWHILE)*/
    _37emit_op(158);
L1: 

    /** 	bp1 = length(Code)+1*/
    if (IS_SEQUENCE(_26Code_12071)){
            _29538 = SEQ_PTR(_26Code_12071)->length;
    }
    else {
        _29538 = 1;
    }
    _bp1_58139 = _29538 + 1;
    _29538 = NOVALUE;

    /** 	continue_addr &= bp1*/
    Append(&_30continue_addr_54181, _30continue_addr_54181, _bp1_58139);

    /** 	short_circuit += 1*/
    _30short_circuit_54156 = _30short_circuit_54156 + 1;

    /** 	short_circuit_B = FALSE*/
    _30short_circuit_B_54158 = _9FALSE_428;

    /** 	SC1_type = 0*/
    _30SC1_type_54161 = 0;

    /** 	Expr()*/
    _30Expr();

    /** 	optimized_while = FALSE*/
    _37optimized_while_50264 = _9FALSE_428;

    /** 	emit_op(WHILE)*/
    _37emit_op(47);

    /** 	short_circuit -= 1*/
    _30short_circuit_54156 = _30short_circuit_54156 - 1;

    /** 	if not optimized_while then*/
    if (_37optimized_while_50264 != 0)
    goto L2; // [153] 174

    /** 		bp2 = length(Code)+1*/
    if (IS_SEQUENCE(_26Code_12071)){
            _29544 = SEQ_PTR(_26Code_12071)->length;
    }
    else {
        _29544 = 1;
    }
    _bp2_58140 = _29544 + 1;
    _29544 = NOVALUE;

    /** 		emit_forward_addr() -- will be patched*/
    _30emit_forward_addr();
    goto L3; // [171] 180
L2: 

    /** 		bp2 = 0*/
    _bp2_58140 = 0;
L3: 

    /** 	if finish_block_header(WHILE)=0 then*/
    _29546 = _30finish_block_header(47);
    if (binary_op_a(NOTEQ, _29546, 0)){
        DeRef(_29546);
        _29546 = NOVALUE;
        goto L4; // [188] 204
    }
    DeRef(_29546);
    _29546 = NOVALUE;

    /** 		entry_addr[$]=-1*/
    if (IS_SEQUENCE(_30entry_addr_54180)){
            _29548 = SEQ_PTR(_30entry_addr_54180)->length;
    }
    else {
        _29548 = 1;
    }
    _2 = (int)SEQ_PTR(_30entry_addr_54180);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _30entry_addr_54180 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _29548);
    *(int *)_2 = -1;
L4: 

    /** 	loop_stack &= WHILE*/
    Append(&_30loop_stack_54190, _30loop_stack_54190, 47);

    /** 	exit_base = length(exit_list)*/
    if (IS_SEQUENCE(_30exit_list_54176)){
            _exit_base_58141 = SEQ_PTR(_30exit_list_54176)->length;
    }
    else {
        _exit_base_58141 = 1;
    }

    /** 	if SC1_type = OR then*/
    if (_30SC1_type_54161 != 9)
    goto L5; // [227] 280

    /** 		backpatch(SC1_patch-3, SC1_OR_IF)*/
    _29552 = _30SC1_patch_54160 - 3;
    if ((long)((unsigned long)_29552 +(unsigned long) HIGH_BITS) >= 0){
        _29552 = NewDouble((double)_29552);
    }
    _37backpatch(_29552, 147);
    _29552 = NOVALUE;

    /** 		if TRANSLATE then*/
    if (_26TRANSLATE_11619 == 0)
    {
        goto L6; // [249] 260
    }
    else{
    }

    /** 			emit_op(NOP1)*/
    _37emit_op(159);
L6: 

    /** 		backpatch(SC1_patch, length(Code)+1)*/
    if (IS_SEQUENCE(_26Code_12071)){
            _29553 = SEQ_PTR(_26Code_12071)->length;
    }
    else {
        _29553 = 1;
    }
    _29554 = _29553 + 1;
    _29553 = NOVALUE;
    _37backpatch(_30SC1_patch_54160, _29554);
    _29554 = NOVALUE;
    goto L7; // [277] 331
L5: 

    /** 	elsif SC1_type = AND then*/
    if (_30SC1_type_54161 != 8)
    goto L8; // [286] 330

    /** 		backpatch(SC1_patch-3, SC1_AND_IF)*/
    _29556 = _30SC1_patch_54160 - 3;
    if ((long)((unsigned long)_29556 +(unsigned long) HIGH_BITS) >= 0){
        _29556 = NewDouble((double)_29556);
    }
    _37backpatch(_29556, 146);
    _29556 = NOVALUE;

    /** 		AppendXList(SC1_patch)*/

    /** 	exit_list = append(exit_list, addr)*/
    Append(&_30exit_list_54176, _30exit_list_54176, _30SC1_patch_54160);

    /** end procedure*/
    goto L9; // [318] 321
L9: 

    /** 		exit_delay &= 1*/
    Append(&_30exit_delay_54177, _30exit_delay_54177, 1);
L8: 
L7: 

    /** 	retry_addr &= length(Code)+1*/
    if (IS_SEQUENCE(_26Code_12071)){
            _29558 = SEQ_PTR(_26Code_12071)->length;
    }
    else {
        _29558 = 1;
    }
    _29559 = _29558 + 1;
    _29558 = NOVALUE;
    Append(&_30retry_addr_54182, _30retry_addr_54182, _29559);
    _29559 = NOVALUE;

    /** 	sequence temps = pop_temps()*/
    _0 = _temps_58213;
    _temps_58213 = _37pop_temps();
    DeRef(_0);

    /** 	push_temps( temps )*/
    RefDS(_temps_58213);
    _37push_temps(_temps_58213);

    /** 	Statement_list()*/
    _30Statement_list();

    /** 	PatchNList(next_base)*/
    _30PatchNList(_next_base_58142);

    /** 	tok_match(END)*/
    _30tok_match(402, 0);

    /** 	tok_match(WHILE, END)*/
    _30tok_match(47, 402);

    /** 	End_block( WHILE )*/
    _65End_block(47);

    /** 	StartSourceLine(TRUE)*/
    _37StartSourceLine(_9TRUE_430, 0, 2);

    /** 	emit_op(ENDWHILE)*/
    _37emit_op(22);

    /** 	emit_addr(bp1)*/
    _37emit_addr(_bp1_58139);

    /** 	if TRANSLATE then*/
    if (_26TRANSLATE_11619 == 0)
    {
        goto LA; // [419] 430
    }
    else{
    }

    /** 		emit_op(NOP1)*/
    _37emit_op(159);
LA: 

    /** 	if bp2 != 0 then*/
    if (_bp2_58140 == 0)
    goto LB; // [434] 454

    /** 		backpatch(bp2, length(Code)+1)*/
    if (IS_SEQUENCE(_26Code_12071)){
            _29563 = SEQ_PTR(_26Code_12071)->length;
    }
    else {
        _29563 = 1;
    }
    _29564 = _29563 + 1;
    _29563 = NOVALUE;
    _37backpatch(_bp2_58140, _29564);
    _29564 = NOVALUE;
LB: 

    /** 	exit_loop(exit_base)*/
    _30exit_loop(_exit_base_58141);

    /** 	entry_stack = remove( entry_stack, length( entry_stack ) )*/
    if (IS_SEQUENCE(_30entry_stack_54183)){
            _29565 = SEQ_PTR(_30entry_stack_54183)->length;
    }
    else {
        _29565 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_30entry_stack_54183);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_29565)) ? _29565 : (long)(DBL_PTR(_29565)->dbl);
        int stop = (IS_ATOM_INT(_29565)) ? _29565 : (long)(DBL_PTR(_29565)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_30entry_stack_54183), start, &_30entry_stack_54183 );
            }
            else Tail(SEQ_PTR(_30entry_stack_54183), stop+1, &_30entry_stack_54183);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_30entry_stack_54183), start, &_30entry_stack_54183);
        }
        else {
            assign_slice_seq = &assign_space;
            _30entry_stack_54183 = Remove_elements(start, stop, (SEQ_PTR(_30entry_stack_54183)->ref == 1));
        }
    }
    _29565 = NOVALUE;
    _29565 = NOVALUE;

    /** 	push_temps( temps )*/
    RefDS(_temps_58213);
    _37push_temps(_temps_58213);

    /** end procedure*/
    DeRef(_uninitialized_58143);
    DeRefDS(_temps_58213);
    return;
    ;
}


void _30Loop_statement()
{
    int _bp1_58243 = NOVALUE;
    int _exit_base_58244 = NOVALUE;
    int _next_base_58245 = NOVALUE;
    int _t_58247 = NOVALUE;
    int _uninitialized_58250 = NOVALUE;
    int _29589 = NOVALUE;
    int _29587 = NOVALUE;
    int _29586 = NOVALUE;
    int _29585 = NOVALUE;
    int _29579 = NOVALUE;
    int _29578 = NOVALUE;
    int _29576 = NOVALUE;
    int _29573 = NOVALUE;
    int _29572 = NOVALUE;
    int _29571 = NOVALUE;
    int _0, _1, _2;
    

    /** 	Start_block( LOOP )*/
    _65Start_block(422, 0);

    /** 	sequence uninitialized = get_private_uninitialized()*/
    _0 = _uninitialized_58250;
    _uninitialized_58250 = _30get_private_uninitialized();
    DeRef(_0);

    /** 	entry_stack = append( entry_stack, uninitialized )*/
    RefDS(_uninitialized_58250);
    Append(&_30entry_stack_54183, _30entry_stack_54183, _uninitialized_58250);

    /** 	exit_base = length(exit_list)*/
    if (IS_SEQUENCE(_30exit_list_54176)){
            _exit_base_58244 = SEQ_PTR(_30exit_list_54176)->length;
    }
    else {
        _exit_base_58244 = 1;
    }

    /** 	next_base = length(continue_list)*/
    if (IS_SEQUENCE(_30continue_list_54178)){
            _next_base_58245 = SEQ_PTR(_30continue_list_54178)->length;
    }
    else {
        _next_base_58245 = 1;
    }

    /** 	emit_op(NOP2) -- Entry_statement() may patch this*/
    _37emit_op(110);

    /** 	emit_addr(0)*/
    _37emit_addr(0);

    /** 	if finish_block_header(LOOP) then*/
    _29571 = _30finish_block_header(422);
    if (_29571 == 0) {
        DeRef(_29571);
        _29571 = NOVALUE;
        goto L1; // [58] 81
    }
    else {
        if (!IS_ATOM_INT(_29571) && DBL_PTR(_29571)->dbl == 0.0){
            DeRef(_29571);
            _29571 = NOVALUE;
            goto L1; // [58] 81
        }
        DeRef(_29571);
        _29571 = NOVALUE;
    }
    DeRef(_29571);
    _29571 = NOVALUE;

    /** 	    entry_addr &= length(Code)-1*/
    if (IS_SEQUENCE(_26Code_12071)){
            _29572 = SEQ_PTR(_26Code_12071)->length;
    }
    else {
        _29572 = 1;
    }
    _29573 = _29572 - 1;
    _29572 = NOVALUE;
    Append(&_30entry_addr_54180, _30entry_addr_54180, _29573);
    _29573 = NOVALUE;
    goto L2; // [78] 90
L1: 

    /** 		entry_addr &= -1*/
    Append(&_30entry_addr_54180, _30entry_addr_54180, -1);
L2: 

    /** 	if TRANSLATE then*/
    if (_26TRANSLATE_11619 == 0)
    {
        goto L3; // [94] 105
    }
    else{
    }

    /** 		emit_op(NOP1)*/
    _37emit_op(159);
L3: 

    /** 	bp1 = length(Code)+1*/
    if (IS_SEQUENCE(_26Code_12071)){
            _29576 = SEQ_PTR(_26Code_12071)->length;
    }
    else {
        _29576 = 1;
    }
    _bp1_58243 = _29576 + 1;
    _29576 = NOVALUE;

    /** 	retry_addr &= length(Code)+1*/
    if (IS_SEQUENCE(_26Code_12071)){
            _29578 = SEQ_PTR(_26Code_12071)->length;
    }
    else {
        _29578 = 1;
    }
    _29579 = _29578 + 1;
    _29578 = NOVALUE;
    Append(&_30retry_addr_54182, _30retry_addr_54182, _29579);
    _29579 = NOVALUE;

    /** 	continue_addr &= 0*/
    Append(&_30continue_addr_54181, _30continue_addr_54181, 0);

    /** 	loop_stack &= LOOP*/
    Append(&_30loop_stack_54190, _30loop_stack_54190, 422);

    /** 	Statement_list()*/
    _30Statement_list();

    /** 	End_block( LOOP )*/
    _65End_block(422);

    /** 	tok_match(UNTIL)*/
    _30tok_match(423, 0);

    /** 	if TRANSLATE then*/
    if (_26TRANSLATE_11619 == 0)
    {
        goto L4; // [174] 185
    }
    else{
    }

    /** 		emit_op(NOP1)*/
    _37emit_op(159);
L4: 

    /** 	PatchNList(next_base)*/
    _30PatchNList(_next_base_58245);

    /** 	StartSourceLine(TRUE)*/
    _37StartSourceLine(_9TRUE_430, 0, 2);

    /** 	short_circuit += 1*/
    _30short_circuit_54156 = _30short_circuit_54156 + 1;

    /** 	short_circuit_B = FALSE*/
    _30short_circuit_B_54158 = _9FALSE_428;

    /** 	SC1_type = 0*/
    _30SC1_type_54161 = 0;

    /** 	Expr()*/
    _30Expr();

    /** 	if SC1_type = OR then*/
    if (_30SC1_type_54161 != 9)
    goto L5; // [229] 282

    /** 		backpatch(SC1_patch-3, SC1_OR_IF)*/
    _29585 = _30SC1_patch_54160 - 3;
    if ((long)((unsigned long)_29585 +(unsigned long) HIGH_BITS) >= 0){
        _29585 = NewDouble((double)_29585);
    }
    _37backpatch(_29585, 147);
    _29585 = NOVALUE;

    /** 		if TRANSLATE then*/
    if (_26TRANSLATE_11619 == 0)
    {
        goto L6; // [251] 262
    }
    else{
    }

    /** 		    emit_op(NOP1)  -- to get label here*/
    _37emit_op(159);
L6: 

    /** 		backpatch(SC1_patch, length(Code)+1)*/
    if (IS_SEQUENCE(_26Code_12071)){
            _29586 = SEQ_PTR(_26Code_12071)->length;
    }
    else {
        _29586 = 1;
    }
    _29587 = _29586 + 1;
    _29586 = NOVALUE;
    _37backpatch(_30SC1_patch_54160, _29587);
    _29587 = NOVALUE;
    goto L7; // [279] 308
L5: 

    /** 	elsif SC1_type = AND then*/
    if (_30SC1_type_54161 != 8)
    goto L8; // [288] 307

    /** 		backpatch(SC1_patch-3, SC1_AND_IF)*/
    _29589 = _30SC1_patch_54160 - 3;
    if ((long)((unsigned long)_29589 +(unsigned long) HIGH_BITS) >= 0){
        _29589 = NewDouble((double)_29589);
    }
    _37backpatch(_29589, 146);
    _29589 = NOVALUE;
L8: 
L7: 

    /** 	short_circuit -= 1*/
    _30short_circuit_54156 = _30short_circuit_54156 - 1;

    /** 	emit_op(IF)*/
    _37emit_op(20);

    /** 	emit_addr(bp1)*/
    _37emit_addr(_bp1_58243);

    /** 	if TRANSLATE then*/
    if (_26TRANSLATE_11619 == 0)
    {
        goto L9; // [332] 343
    }
    else{
    }

    /** 		emit_op(NOP1)*/
    _37emit_op(159);
L9: 

    /** 	exit_loop(exit_base)*/
    _30exit_loop(_exit_base_58244);

    /** 	tok_match(END)*/
    _30tok_match(402, 0);

    /** 	tok_match(LOOP, END)*/
    _30tok_match(422, 402);

    /** end procedure*/
    DeRef(_uninitialized_58250);
    return;
    ;
}


void _30Ifdef_statement()
{
    int _option_58329 = NOVALUE;
    int _matched_58330 = NOVALUE;
    int _has_matched_58331 = NOVALUE;
    int _in_matched_58332 = NOVALUE;
    int _dead_ifdef_58333 = NOVALUE;
    int _in_elsedef_58334 = NOVALUE;
    int _tok_58336 = NOVALUE;
    int _keyw_58337 = NOVALUE;
    int _parser_id_58341 = NOVALUE;
    int _negate_58357 = NOVALUE;
    int _conjunction_58358 = NOVALUE;
    int _at_start_58359 = NOVALUE;
    int _prev_conj_58360 = NOVALUE;
    int _this_matched_58433 = NOVALUE;
    int _gotword_58449 = NOVALUE;
    int _gotthen_58450 = NOVALUE;
    int _if_lvl_58451 = NOVALUE;
    int _29706 = NOVALUE;
    int _29705 = NOVALUE;
    int _29701 = NOVALUE;
    int _29699 = NOVALUE;
    int _29696 = NOVALUE;
    int _29694 = NOVALUE;
    int _29693 = NOVALUE;
    int _29689 = NOVALUE;
    int _29686 = NOVALUE;
    int _29683 = NOVALUE;
    int _29679 = NOVALUE;
    int _29677 = NOVALUE;
    int _29676 = NOVALUE;
    int _29675 = NOVALUE;
    int _29674 = NOVALUE;
    int _29673 = NOVALUE;
    int _29672 = NOVALUE;
    int _29671 = NOVALUE;
    int _29667 = NOVALUE;
    int _29664 = NOVALUE;
    int _29663 = NOVALUE;
    int _29662 = NOVALUE;
    int _29658 = NOVALUE;
    int _29657 = NOVALUE;
    int _29656 = NOVALUE;
    int _29653 = NOVALUE;
    int _29650 = NOVALUE;
    int _29649 = NOVALUE;
    int _29648 = NOVALUE;
    int _29646 = NOVALUE;
    int _29635 = NOVALUE;
    int _29633 = NOVALUE;
    int _29632 = NOVALUE;
    int _29631 = NOVALUE;
    int _29630 = NOVALUE;
    int _29629 = NOVALUE;
    int _29628 = NOVALUE;
    int _29627 = NOVALUE;
    int _29624 = NOVALUE;
    int _29623 = NOVALUE;
    int _29621 = NOVALUE;
    int _29619 = NOVALUE;
    int _29618 = NOVALUE;
    int _29616 = NOVALUE;
    int _29614 = NOVALUE;
    int _29613 = NOVALUE;
    int _29611 = NOVALUE;
    int _29610 = NOVALUE;
    int _29609 = NOVALUE;
    int _29606 = NOVALUE;
    int _29604 = NOVALUE;
    int _29601 = NOVALUE;
    int _29600 = NOVALUE;
    int _29599 = NOVALUE;
    int _29597 = NOVALUE;
    int _29595 = NOVALUE;
    int _29594 = NOVALUE;
    int _29593 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer matched = 0, has_matched = 0,  in_matched = 0, dead_ifdef = 0, in_elsedef = 0*/
    _matched_58330 = 0;
    _has_matched_58331 = 0;
    _in_matched_58332 = 0;
    _dead_ifdef_58333 = 0;
    _in_elsedef_58334 = 0;

    /** 	sequence keyw ="ifdef"*/
    RefDS(_26357);
    DeRefi(_keyw_58337);
    _keyw_58337 = _26357;

    /** 	live_ifdef += 1*/
    _30live_ifdef_58325 = _30live_ifdef_58325 + 1;

    /** 	ifdef_lineno &= line_number*/
    Append(&_30ifdef_lineno_58326, _30ifdef_lineno_58326, _26line_number_11983);

    /** 	integer parser_id*/

    /** 	if CurrentSub != TopLevelSub or length(if_labels) or length(loop_labels) then*/
    _29593 = (_26CurrentSub_11990 != _26TopLevelSub_11989);
    if (_29593 != 0) {
        _29594 = 1;
        goto L1; // [55] 68
    }
    if (IS_SEQUENCE(_30if_labels_54185)){
            _29595 = SEQ_PTR(_30if_labels_54185)->length;
    }
    else {
        _29595 = 1;
    }
    _29594 = (_29595 != 0);
L1: 
    if (_29594 != 0) {
        goto L2; // [68] 82
    }
    if (IS_SEQUENCE(_30loop_labels_54184)){
            _29597 = SEQ_PTR(_30loop_labels_54184)->length;
    }
    else {
        _29597 = 1;
    }
    if (_29597 == 0)
    {
        _29597 = NOVALUE;
        goto L3; // [78] 92
    }
    else{
        _29597 = NOVALUE;
    }
L2: 

    /** 		parser_id = forward_Statement_list*/
    _parser_id_58341 = _30forward_Statement_list_57177;
    goto L4; // [89] 100
L3: 

    /** 		parser_id = top_level_parser*/
    _parser_id_58341 = _30top_level_parser_58324;
L4: 

    /** 	while 1 label "top" do*/
L5: 

    /** 		if matched = 0 and in_elsedef = 0 then*/
    _29599 = (_matched_58330 == 0);
    if (_29599 == 0) {
        goto L6; // [111] 632
    }
    _29601 = (_in_elsedef_58334 == 0);
    if (_29601 == 0)
    {
        DeRef(_29601);
        _29601 = NOVALUE;
        goto L6; // [120] 632
    }
    else{
        DeRef(_29601);
        _29601 = NOVALUE;
    }

    /** 			integer negate = 0, conjunction = 0*/
    _negate_58357 = 0;
    _conjunction_58358 = 0;

    /** 			integer at_start = 1*/
    _at_start_58359 = 1;

    /** 			sequence prev_conj = ""*/
    RefDS(_22037);
    DeRef(_prev_conj_58360);
    _prev_conj_58360 = _22037;

    /** 			while 1 label "deflist" do*/
L7: 

    /** 				option = StringToken()*/
    RefDS(_5);
    _0 = _option_58329;
    _option_58329 = _60StringToken(_5);
    DeRef(_0);

    /** 				if equal(option, "then") then*/
    if (_option_58329 == _26424)
    _29604 = 1;
    else if (IS_ATOM_INT(_option_58329) && IS_ATOM_INT(_26424))
    _29604 = 0;
    else
    _29604 = (compare(_option_58329, _26424) == 0);
    if (_29604 == 0)
    {
        _29604 = NOVALUE;
        goto L8; // [162] 234
    }
    else{
        _29604 = NOVALUE;
    }

    /** 					if at_start = 1 then*/
    if (_at_start_58359 != 1)
    goto L9; // [167] 185

    /** 						CompileErr(6, {keyw})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_keyw_58337);
    *((int *)(_2+4)) = _keyw_58337;
    _29606 = MAKE_SEQ(_1);
    _43CompileErr(6, _29606, 0);
    _29606 = NOVALUE;
    goto LA; // [182] 518
L9: 

    /** 					elsif conjunction = 0 then*/
    if (_conjunction_58358 != 0)
    goto LB; // [187] 219

    /** 						if negate = 0 then*/
    if (_negate_58357 != 0)
    goto LC; // [193] 204

    /** 							exit "deflist"*/
    goto LD; // [199] 606
    goto LA; // [201] 518
LC: 

    /** 							CompileErr(11, {keyw})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_keyw_58337);
    *((int *)(_2+4)) = _keyw_58337;
    _29609 = MAKE_SEQ(_1);
    _43CompileErr(11, _29609, 0);
    _29609 = NOVALUE;
    goto LA; // [216] 518
LB: 

    /** 						CompileErr(8, {keyw, prev_conj})*/
    RefDS(_prev_conj_58360);
    RefDS(_keyw_58337);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _keyw_58337;
    ((int *)_2)[2] = _prev_conj_58360;
    _29610 = MAKE_SEQ(_1);
    _43CompileErr(8, _29610, 0);
    _29610 = NOVALUE;
    goto LA; // [231] 518
L8: 

    /** 				elsif equal(option, "not") then*/
    if (_option_58329 == _26385)
    _29611 = 1;
    else if (IS_ATOM_INT(_option_58329) && IS_ATOM_INT(_26385))
    _29611 = 0;
    else
    _29611 = (compare(_option_58329, _26385) == 0);
    if (_29611 == 0)
    {
        _29611 = NOVALUE;
        goto LE; // [240] 276
    }
    else{
        _29611 = NOVALUE;
    }

    /** 					if negate = 0 then*/
    if (_negate_58357 != 0)
    goto LF; // [245] 261

    /** 						negate = 1*/
    _negate_58357 = 1;

    /** 						continue "deflist"*/
    goto L7; // [256] 148
    goto LA; // [258] 518
LF: 

    /** 						CompileErr(7, {keyw})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_keyw_58337);
    *((int *)(_2+4)) = _keyw_58337;
    _29613 = MAKE_SEQ(_1);
    _43CompileErr(7, _29613, 0);
    _29613 = NOVALUE;
    goto LA; // [273] 518
LE: 

    /** 				elsif equal(option, "and") then*/
    if (_option_58329 == _26289)
    _29614 = 1;
    else if (IS_ATOM_INT(_option_58329) && IS_ATOM_INT(_26289))
    _29614 = 0;
    else
    _29614 = (compare(_option_58329, _26289) == 0);
    if (_29614 == 0)
    {
        _29614 = NOVALUE;
        goto L10; // [282] 345
    }
    else{
        _29614 = NOVALUE;
    }

    /** 					if at_start = 1 then*/
    if (_at_start_58359 != 1)
    goto L11; // [287] 305

    /** 						CompileErr(2, {keyw})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_keyw_58337);
    *((int *)(_2+4)) = _keyw_58337;
    _29616 = MAKE_SEQ(_1);
    _43CompileErr(2, _29616, 0);
    _29616 = NOVALUE;
    goto LA; // [302] 518
L11: 

    /** 					elsif conjunction = 0 then*/
    if (_conjunction_58358 != 0)
    goto L12; // [307] 330

    /** 						conjunction = 1*/
    _conjunction_58358 = 1;

    /** 						prev_conj = option*/
    RefDS(_option_58329);
    DeRef(_prev_conj_58360);
    _prev_conj_58360 = _option_58329;

    /** 						continue "deflist"*/
    goto L7; // [325] 148
    goto LA; // [327] 518
L12: 

    /** 						CompileErr(10,{keyw,prev_conj})*/
    RefDS(_prev_conj_58360);
    RefDS(_keyw_58337);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _keyw_58337;
    ((int *)_2)[2] = _prev_conj_58360;
    _29618 = MAKE_SEQ(_1);
    _43CompileErr(10, _29618, 0);
    _29618 = NOVALUE;
    goto LA; // [342] 518
L10: 

    /** 				elsif equal(option, "or") then*/
    if (_option_58329 == _26389)
    _29619 = 1;
    else if (IS_ATOM_INT(_option_58329) && IS_ATOM_INT(_26389))
    _29619 = 0;
    else
    _29619 = (compare(_option_58329, _26389) == 0);
    if (_29619 == 0)
    {
        _29619 = NOVALUE;
        goto L13; // [351] 414
    }
    else{
        _29619 = NOVALUE;
    }

    /** 					if at_start = 1 then*/
    if (_at_start_58359 != 1)
    goto L14; // [356] 374

    /** 						CompileErr(6, {keyw})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_keyw_58337);
    *((int *)(_2+4)) = _keyw_58337;
    _29621 = MAKE_SEQ(_1);
    _43CompileErr(6, _29621, 0);
    _29621 = NOVALUE;
    goto LA; // [371] 518
L14: 

    /** 					elsif conjunction = 0 then*/
    if (_conjunction_58358 != 0)
    goto L15; // [376] 399

    /** 						conjunction = 2*/
    _conjunction_58358 = 2;

    /** 						prev_conj = option*/
    RefDS(_option_58329);
    DeRef(_prev_conj_58360);
    _prev_conj_58360 = _option_58329;

    /** 						continue "deflist"*/
    goto L7; // [394] 148
    goto LA; // [396] 518
L15: 

    /** 						CompileErr(9, {keyw, prev_conj})*/
    RefDS(_prev_conj_58360);
    RefDS(_keyw_58337);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _keyw_58337;
    ((int *)_2)[2] = _prev_conj_58360;
    _29623 = MAKE_SEQ(_1);
    _43CompileErr(9, _29623, 0);
    _29623 = NOVALUE;
    goto LA; // [411] 518
L13: 

    /** 				elsif length(option) = 0 then*/
    if (IS_SEQUENCE(_option_58329)){
            _29624 = SEQ_PTR(_option_58329)->length;
    }
    else {
        _29624 = 1;
    }
    if (_29624 != 0)
    goto L16; // [419] 454

    /** 					if at_start = 1 then*/
    if (_at_start_58359 != 1)
    goto L17; // [425] 443

    /** 						CompileErr(122, {keyw})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_keyw_58337);
    *((int *)(_2+4)) = _keyw_58337;
    _29627 = MAKE_SEQ(_1);
    _43CompileErr(122, _29627, 0);
    _29627 = NOVALUE;
    goto LA; // [440] 518
L17: 

    /** 						CompileErr(82)*/
    RefDS(_22037);
    _43CompileErr(82, _22037, 0);
    goto LA; // [451] 518
L16: 

    /** 				elsif not at_start and length(prev_conj) = 0 then*/
    _29628 = (_at_start_58359 == 0);
    if (_29628 == 0) {
        goto L18; // [459] 488
    }
    if (IS_SEQUENCE(_prev_conj_58360)){
            _29630 = SEQ_PTR(_prev_conj_58360)->length;
    }
    else {
        _29630 = 1;
    }
    _29631 = (_29630 == 0);
    _29630 = NOVALUE;
    if (_29631 == 0)
    {
        DeRef(_29631);
        _29631 = NOVALUE;
        goto L18; // [471] 488
    }
    else{
        DeRef(_29631);
        _29631 = NOVALUE;
    }

    /** 					CompileErr(4, {keyw})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_keyw_58337);
    *((int *)(_2+4)) = _keyw_58337;
    _29632 = MAKE_SEQ(_1);
    _43CompileErr(4, _29632, 0);
    _29632 = NOVALUE;
    goto LA; // [485] 518
L18: 

    /** 				elsif t_identifier(option) = 0 then*/
    RefDS(_option_58329);
    _29633 = _9t_identifier(_option_58329);
    if (binary_op_a(NOTEQ, _29633, 0)){
        DeRef(_29633);
        _29633 = NOVALUE;
        goto L19; // [494] 512
    }
    DeRef(_29633);
    _29633 = NOVALUE;

    /** 					CompileErr(3, {keyw})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_keyw_58337);
    *((int *)(_2+4)) = _keyw_58337;
    _29635 = MAKE_SEQ(_1);
    _43CompileErr(3, _29635, 0);
    _29635 = NOVALUE;
    goto LA; // [509] 518
L19: 

    /** 					at_start = 0*/
    _at_start_58359 = 0;
LA: 

    /** 				integer this_matched = find(option, OpDefines)*/
    _this_matched_58433 = find_from(_option_58329, _26OpDefines_12056, 1);

    /** 				if negate then*/
    if (_negate_58357 == 0)
    {
        goto L1A; // [529] 543
    }
    else{
    }

    /** 					this_matched = not this_matched*/
    _this_matched_58433 = (_this_matched_58433 == 0);

    /** 					negate = 0*/
    _negate_58357 = 0;
L1A: 

    /** 				if conjunction = 0 then*/
    if (_conjunction_58358 != 0)
    goto L1B; // [545] 557

    /** 					matched = this_matched*/
    _matched_58330 = _this_matched_58433;
    goto L1C; // [554] 599
L1B: 

    /** 					if conjunction = 1 then*/
    if (_conjunction_58358 != 1)
    goto L1D; // [559] 572

    /** 						matched = matched and this_matched*/
    _matched_58330 = (_matched_58330 != 0 && _this_matched_58433 != 0);
    goto L1E; // [569] 586
L1D: 

    /** 					elsif conjunction = 2 then*/
    if (_conjunction_58358 != 2)
    goto L1F; // [574] 585

    /** 						matched = matched or this_matched*/
    _matched_58330 = (_matched_58330 != 0 || _this_matched_58433 != 0);
L1F: 
L1E: 

    /** 					conjunction = 0*/
    _conjunction_58358 = 0;

    /** 					prev_conj = ""*/
    RefDS(_22037);
    DeRef(_prev_conj_58360);
    _prev_conj_58360 = _22037;
L1C: 

    /** 			end while*/
    goto L7; // [603] 148
LD: 

    /** 			in_matched = matched*/
    _in_matched_58332 = _matched_58330;

    /** 			if matched then*/
    if (_matched_58330 == 0)
    {
        goto L20; // [613] 631
    }
    else{
    }

    /** 				No_new_entry = 0*/
    _52No_new_entry_47302 = 0;

    /** 				call_proc(parser_id, {})*/
    _0 = (int)_00[_parser_id_58341].addr;
    (*(int (*)())_0)(
                         );
L20: 
L6: 
    DeRef(_prev_conj_58360);
    _prev_conj_58360 = NOVALUE;

    /** 		integer gotword = 0*/
    _gotword_58449 = 0;

    /** 		integer gotthen = 0*/
    _gotthen_58450 = 0;

    /** 		integer if_lvl  = 0*/
    _if_lvl_58451 = 0;

    /** 		No_new_entry = not matched*/
    _52No_new_entry_47302 = (_matched_58330 == 0);

    /** 		has_matched = has_matched or matched*/
    _has_matched_58331 = (_has_matched_58331 != 0 || _matched_58330 != 0);

    /** 		keyw = "elsifdef"*/
    RefDS(_26325);
    DeRefi(_keyw_58337);
    _keyw_58337 = _26325;

    /** 		while 1 do*/
L21: 

    /** 			tok = next_token()*/
    _0 = _tok_58336;
    _tok_58336 = _30next_token();
    DeRef(_0);

    /** 			if tok[T_ID] = END_OF_FILE then*/
    _2 = (int)SEQ_PTR(_tok_58336);
    _29646 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29646, -21)){
        _29646 = NOVALUE;
        goto L22; // [689] 712
    }
    _29646 = NOVALUE;

    /** 				CompileErr(65, ifdef_lineno[$])*/
    if (IS_SEQUENCE(_30ifdef_lineno_58326)){
            _29648 = SEQ_PTR(_30ifdef_lineno_58326)->length;
    }
    else {
        _29648 = 1;
    }
    _2 = (int)SEQ_PTR(_30ifdef_lineno_58326);
    _29649 = (int)*(((s1_ptr)_2)->base + _29648);
    _43CompileErr(65, _29649, 0);
    _29649 = NOVALUE;
    goto L21; // [709] 674
L22: 

    /** 			elsif tok[T_ID] = END then*/
    _2 = (int)SEQ_PTR(_tok_58336);
    _29650 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29650, 402)){
        _29650 = NOVALUE;
        goto L23; // [722] 844
    }
    _29650 = NOVALUE;

    /** 				tok = next_token()*/
    _0 = _tok_58336;
    _tok_58336 = _30next_token();
    DeRef(_0);

    /** 				if tok[T_ID] = IFDEF then*/
    _2 = (int)SEQ_PTR(_tok_58336);
    _29653 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29653, 407)){
        _29653 = NOVALUE;
        goto L24; // [741] 769
    }
    _29653 = NOVALUE;

    /** 					if dead_ifdef then*/
    if (_dead_ifdef_58333 == 0)
    {
        goto L25; // [747] 759
    }
    else{
    }

    /** 						dead_ifdef -= 1*/
    _dead_ifdef_58333 = _dead_ifdef_58333 - 1;
    goto L21; // [756] 674
L25: 

    /** 						exit "top"*/
    goto L26; // [763] 1312
    goto L21; // [766] 674
L24: 

    /** 				elsif in_matched then*/
    if (_in_matched_58332 == 0)
    {
        goto L27; // [771] 793
    }
    else{
    }

    /** 					CompileErr(75, ifdef_lineno[$])*/
    if (IS_SEQUENCE(_30ifdef_lineno_58326)){
            _29656 = SEQ_PTR(_30ifdef_lineno_58326)->length;
    }
    else {
        _29656 = 1;
    }
    _2 = (int)SEQ_PTR(_30ifdef_lineno_58326);
    _29657 = (int)*(((s1_ptr)_2)->base + _29656);
    _43CompileErr(75, _29657, 0);
    _29657 = NOVALUE;
    goto L21; // [790] 674
L27: 

    /** 					if tok[T_ID] = IF then*/
    _2 = (int)SEQ_PTR(_tok_58336);
    _29658 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29658, 20)){
        _29658 = NOVALUE;
        goto L21; // [803] 674
    }
    _29658 = NOVALUE;

    /** 						if if_lvl > 0 then*/
    if (_if_lvl_58451 <= 0)
    goto L28; // [809] 822

    /** 							if_lvl -= 1*/
    _if_lvl_58451 = _if_lvl_58451 - 1;
    goto L21; // [819] 674
L28: 

    /** 							CompileErr(111, ifdef_lineno[$])*/
    if (IS_SEQUENCE(_30ifdef_lineno_58326)){
            _29662 = SEQ_PTR(_30ifdef_lineno_58326)->length;
    }
    else {
        _29662 = 1;
    }
    _2 = (int)SEQ_PTR(_30ifdef_lineno_58326);
    _29663 = (int)*(((s1_ptr)_2)->base + _29662);
    _43CompileErr(111, _29663, 0);
    _29663 = NOVALUE;
    goto L21; // [841] 674
L23: 

    /** 			elsif tok[T_ID] = IF then*/
    _2 = (int)SEQ_PTR(_tok_58336);
    _29664 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29664, 20)){
        _29664 = NOVALUE;
        goto L29; // [854] 867
    }
    _29664 = NOVALUE;

    /** 				if_lvl += 1*/
    _if_lvl_58451 = _if_lvl_58451 + 1;
    goto L21; // [864] 674
L29: 

    /** 			elsif tok[T_ID] = ELSE then*/
    _2 = (int)SEQ_PTR(_tok_58336);
    _29667 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29667, 23)){
        _29667 = NOVALUE;
        goto L2A; // [877] 913
    }
    _29667 = NOVALUE;

    /** 				if not in_matched then*/
    if (_in_matched_58332 != 0)
    goto L21; // [883] 674

    /** 					if if_lvl = 0 then*/
    if (_if_lvl_58451 != 0)
    goto L21; // [888] 674

    /** 						CompileErr(108, ifdef_lineno[$])*/
    if (IS_SEQUENCE(_30ifdef_lineno_58326)){
            _29671 = SEQ_PTR(_30ifdef_lineno_58326)->length;
    }
    else {
        _29671 = 1;
    }
    _2 = (int)SEQ_PTR(_30ifdef_lineno_58326);
    _29672 = (int)*(((s1_ptr)_2)->base + _29671);
    _43CompileErr(108, _29672, 0);
    _29672 = NOVALUE;
    goto L21; // [910] 674
L2A: 

    /** 			elsif tok[T_ID] = ELSIFDEF and not dead_ifdef then*/
    _2 = (int)SEQ_PTR(_tok_58336);
    _29673 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_29673)) {
        _29674 = (_29673 == 408);
    }
    else {
        _29674 = binary_op(EQUALS, _29673, 408);
    }
    _29673 = NOVALUE;
    if (IS_ATOM_INT(_29674)) {
        if (_29674 == 0) {
            goto L2B; // [927] 1065
        }
    }
    else {
        if (DBL_PTR(_29674)->dbl == 0.0) {
            goto L2B; // [927] 1065
        }
    }
    _29676 = (_dead_ifdef_58333 == 0);
    if (_29676 == 0)
    {
        DeRef(_29676);
        _29676 = NOVALUE;
        goto L2B; // [935] 1065
    }
    else{
        DeRef(_29676);
        _29676 = NOVALUE;
    }

    /** 				if has_matched then*/
    if (_has_matched_58331 == 0)
    {
        goto L2C; // [940] 1305
    }
    else{
    }

    /** 					in_matched = 0*/
    _in_matched_58332 = 0;

    /** 					No_new_entry = 1*/
    _52No_new_entry_47302 = 1;

    /** 					gotword = 0*/
    _gotword_58449 = 0;

    /** 					gotthen = 0*/
    _gotthen_58450 = 0;

    /** 					while length(option) > 0 with entry do*/
    goto L2D; // [967] 1009
L2E: 
    if (IS_SEQUENCE(_option_58329)){
            _29677 = SEQ_PTR(_option_58329)->length;
    }
    else {
        _29677 = 1;
    }
    if (_29677 <= 0)
    goto L2F; // [975] 1022

    /** 						if equal(option, "then") then*/
    if (_option_58329 == _26424)
    _29679 = 1;
    else if (IS_ATOM_INT(_option_58329) && IS_ATOM_INT(_26424))
    _29679 = 0;
    else
    _29679 = (compare(_option_58329, _26424) == 0);
    if (_29679 == 0)
    {
        _29679 = NOVALUE;
        goto L30; // [985] 1000
    }
    else{
        _29679 = NOVALUE;
    }

    /** 							gotthen = 1*/
    _gotthen_58450 = 1;

    /** 							exit*/
    goto L2F; // [995] 1022
    goto L31; // [997] 1006
L30: 

    /** 							gotword = 1*/
    _gotword_58449 = 1;
L31: 

    /** 					entry*/
L2D: 

    /** 						option = StringToken()*/
    RefDS(_5);
    _0 = _option_58329;
    _option_58329 = _60StringToken(_5);
    DeRef(_0);

    /** 					end while*/
    goto L2E; // [1019] 970
L2F: 

    /** 					if gotword = 0 then*/
    if (_gotword_58449 != 0)
    goto L32; // [1024] 1036

    /** 						CompileErr(78)*/
    RefDS(_22037);
    _43CompileErr(78, _22037, 0);
L32: 

    /** 					if gotthen = 0 then*/
    if (_gotthen_58450 != 0)
    goto L33; // [1038] 1050

    /** 						CompileErr(77)*/
    RefDS(_22037);
    _43CompileErr(77, _22037, 0);
L33: 

    /** 					read_line()*/
    _60read_line();
    goto L21; // [1054] 674

    /** 					exit*/
    goto L2C; // [1059] 1305
    goto L21; // [1062] 674
L2B: 

    /** 			elsif tok[T_ID] = ELSEDEF then*/
    _2 = (int)SEQ_PTR(_tok_58336);
    _29683 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29683, 409)){
        _29683 = NOVALUE;
        goto L34; // [1075] 1235
    }
    _29683 = NOVALUE;

    /** 				gotword = line_number*/
    _gotword_58449 = _26line_number_11983;

    /** 				option = StringToken()*/
    RefDS(_5);
    _0 = _option_58329;
    _option_58329 = _60StringToken(_5);
    DeRef(_0);

    /** 				if length(option) > 0 then*/
    if (IS_SEQUENCE(_option_58329)){
            _29686 = SEQ_PTR(_option_58329)->length;
    }
    else {
        _29686 = 1;
    }
    if (_29686 <= 0)
    goto L35; // [1101] 1135

    /** 					if line_number = gotword then*/
    if (_26line_number_11983 != _gotword_58449)
    goto L36; // [1109] 1121

    /** 						CompileErr(116)*/
    RefDS(_22037);
    _43CompileErr(116, _22037, 0);
L36: 

    /** 					bp -= length(option)*/
    if (IS_SEQUENCE(_option_58329)){
            _29689 = SEQ_PTR(_option_58329)->length;
    }
    else {
        _29689 = 1;
    }
    _43bp_48561 = _43bp_48561 - _29689;
    _29689 = NOVALUE;
L35: 

    /** 				if not dead_ifdef then*/
    if (_dead_ifdef_58333 != 0)
    goto L21; // [1137] 674

    /** 					if has_matched then*/
    if (_has_matched_58331 == 0)
    {
        goto L37; // [1142] 1164
    }
    else{
    }

    /** 						in_matched = 0*/
    _in_matched_58332 = 0;

    /** 						No_new_entry = 1*/
    _52No_new_entry_47302 = 1;

    /** 						read_line()*/
    _60read_line();
    goto L21; // [1161] 674
L37: 

    /** 						No_new_entry = 0*/
    _52No_new_entry_47302 = 0;

    /** 						in_elsedef = 1*/
    _in_elsedef_58334 = 1;

    /** 						call_proc(parser_id, {})*/
    _0 = (int)_00[_parser_id_58341].addr;
    (*(int (*)())_0)(
                         );

    /** 						tok_match(END)*/
    _30tok_match(402, 0);

    /** 						tok_match(IFDEF, END)*/
    _30tok_match(407, 402);

    /** 						live_ifdef -= 1*/
    _30live_ifdef_58325 = _30live_ifdef_58325 - 1;

    /** 						ifdef_lineno = ifdef_lineno[1..$-1]*/
    if (IS_SEQUENCE(_30ifdef_lineno_58326)){
            _29693 = SEQ_PTR(_30ifdef_lineno_58326)->length;
    }
    else {
        _29693 = 1;
    }
    _29694 = _29693 - 1;
    _29693 = NOVALUE;
    rhs_slice_target = (object_ptr)&_30ifdef_lineno_58326;
    RHS_Slice(_30ifdef_lineno_58326, 1, _29694);

    /** 						return*/
    DeRef(_option_58329);
    DeRef(_tok_58336);
    DeRefi(_keyw_58337);
    DeRef(_29593);
    _29593 = NOVALUE;
    DeRef(_29599);
    _29599 = NOVALUE;
    DeRef(_29628);
    _29628 = NOVALUE;
    _29694 = NOVALUE;
    DeRef(_29674);
    _29674 = NOVALUE;
    return;
    goto L21; // [1232] 674
L34: 

    /** 			elsif tok[T_ID] = IFDEF then*/
    _2 = (int)SEQ_PTR(_tok_58336);
    _29696 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29696, 407)){
        _29696 = NOVALUE;
        goto L38; // [1245] 1258
    }
    _29696 = NOVALUE;

    /** 				dead_ifdef += 1*/
    _dead_ifdef_58333 = _dead_ifdef_58333 + 1;
    goto L21; // [1255] 674
L38: 

    /** 			elsif tok[T_ID] = INCLUDE then*/
    _2 = (int)SEQ_PTR(_tok_58336);
    _29699 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29699, 418)){
        _29699 = NOVALUE;
        goto L39; // [1268] 1279
    }
    _29699 = NOVALUE;

    /** 				read_line()*/
    _60read_line();
    goto L21; // [1276] 674
L39: 

    /** 			elsif tok[T_ID] = CASE then*/
    _2 = (int)SEQ_PTR(_tok_58336);
    _29701 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29701, 186)){
        _29701 = NOVALUE;
        goto L21; // [1289] 674
    }
    _29701 = NOVALUE;

    /** 				tok = next_token()*/
    _0 = _tok_58336;
    _tok_58336 = _30next_token();
    DeRef(_0);

    /** 		end while*/
    goto L21; // [1302] 674
L2C: 

    /** 	end while*/
    goto L5; // [1309] 105
L26: 

    /** 	live_ifdef -= 1*/
    _30live_ifdef_58325 = _30live_ifdef_58325 - 1;

    /** 	ifdef_lineno = ifdef_lineno[1..$-1]*/
    if (IS_SEQUENCE(_30ifdef_lineno_58326)){
            _29705 = SEQ_PTR(_30ifdef_lineno_58326)->length;
    }
    else {
        _29705 = 1;
    }
    _29706 = _29705 - 1;
    _29705 = NOVALUE;
    rhs_slice_target = (object_ptr)&_30ifdef_lineno_58326;
    RHS_Slice(_30ifdef_lineno_58326, 1, _29706);

    /** 	No_new_entry = 0*/
    _52No_new_entry_47302 = 0;

    /** end procedure*/
    DeRef(_option_58329);
    DeRef(_tok_58336);
    DeRefi(_keyw_58337);
    DeRef(_29593);
    _29593 = NOVALUE;
    DeRef(_29599);
    _29599 = NOVALUE;
    DeRef(_29628);
    _29628 = NOVALUE;
    DeRef(_29694);
    _29694 = NOVALUE;
    DeRef(_29674);
    _29674 = NOVALUE;
    _29706 = NOVALUE;
    return;
    ;
}


int _30SetPrivateScope(int _s_58597, int _type_sym_58599, int _n_58600)
{
    int _hashval_58601 = NOVALUE;
    int _scope_58602 = NOVALUE;
    int _t_58604 = NOVALUE;
    int _29727 = NOVALUE;
    int _29726 = NOVALUE;
    int _29725 = NOVALUE;
    int _29724 = NOVALUE;
    int _29723 = NOVALUE;
    int _29722 = NOVALUE;
    int _29719 = NOVALUE;
    int _29716 = NOVALUE;
    int _29714 = NOVALUE;
    int _29712 = NOVALUE;
    int _29708 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_s_58597)) {
        _1 = (long)(DBL_PTR(_s_58597)->dbl);
        DeRefDS(_s_58597);
        _s_58597 = _1;
    }

    /** 	scope = SymTab[s][S_SCOPE]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _29708 = (int)*(((s1_ptr)_2)->base + _s_58597);
    _2 = (int)SEQ_PTR(_29708);
    _scope_58602 = (int)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_scope_58602)){
        _scope_58602 = (long)DBL_PTR(_scope_58602)->dbl;
    }
    _29708 = NOVALUE;

    /** 	switch scope do*/
    _0 = _scope_58602;
    switch ( _0 ){ 

        /** 		case SC_PRIVATE then*/
        case 3:

        /** 			DefinedYet(s)*/
        _52DefinedYet(_s_58597);

        /** 			Block_var( s )*/
        _65Block_var(_s_58597);

        /** 			return s*/
        return _s_58597;
        goto L1; // [50] 260

        /** 		case SC_LOOP_VAR then*/
        case 2:

        /** 			DefinedYet(s)*/
        _52DefinedYet(_s_58597);

        /** 			return s*/
        return _s_58597;
        goto L1; // [67] 260

        /** 		case SC_UNDEFINED, SC_MULTIPLY_DEFINED then*/
        case 9:
        case 10:

        /** 			SymTab[s][S_SCOPE] = SC_PRIVATE*/
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _27SymTab_10921 = MAKE_SEQ(_2);
        }
        _3 = (int)(_s_58597 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 4);
        _1 = *(int *)_2;
        *(int *)_2 = 3;
        DeRef(_1);
        _29712 = NOVALUE;

        /** 			SymTab[s][S_VARNUM] = n*/
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _27SymTab_10921 = MAKE_SEQ(_2);
        }
        _3 = (int)(_s_58597 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 16);
        _1 = *(int *)_2;
        *(int *)_2 = _n_58600;
        DeRef(_1);
        _29714 = NOVALUE;

        /** 			SymTab[s][S_VTYPE] = type_sym*/
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _27SymTab_10921 = MAKE_SEQ(_2);
        }
        _3 = (int)(_s_58597 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 15);
        _1 = *(int *)_2;
        *(int *)_2 = _type_sym_58599;
        DeRef(_1);
        _29716 = NOVALUE;

        /** 			if type_sym < 0 then*/
        if (_type_sym_58599 >= 0)
        goto L2; // [124] 135

        /** 				register_forward_type( s, type_sym )*/
        _29register_forward_type(_s_58597, _type_sym_58599);
L2: 

        /** 			Block_var( s )*/
        _65Block_var(_s_58597);

        /** 			return s*/
        return _s_58597;
        goto L1; // [146] 260

        /** 		case SC_LOCAL, SC_GLOBAL, SC_PREDEF, SC_PUBLIC, SC_EXPORT then*/
        case 5:
        case 6:
        case 7:
        case 13:
        case 11:

        /** 			hashval = SymTab[s][S_HASHVAL]*/
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _29719 = (int)*(((s1_ptr)_2)->base + _s_58597);
        _2 = (int)SEQ_PTR(_29719);
        _hashval_58601 = (int)*(((s1_ptr)_2)->base + 11);
        if (!IS_ATOM_INT(_hashval_58601)){
            _hashval_58601 = (long)DBL_PTR(_hashval_58601)->dbl;
        }
        _29719 = NOVALUE;

        /** 			t = buckets[hashval]*/
        _2 = (int)SEQ_PTR(_52buckets_46126);
        _t_58604 = (int)*(((s1_ptr)_2)->base + _hashval_58601);
        if (!IS_ATOM_INT(_t_58604)){
            _t_58604 = (long)DBL_PTR(_t_58604)->dbl;
        }

        /** 			buckets[hashval] = NewEntry(SymTab[s][S_NAME], n, SC_PRIVATE,*/
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _29722 = (int)*(((s1_ptr)_2)->base + _s_58597);
        _2 = (int)SEQ_PTR(_29722);
        if (!IS_ATOM_INT(_26S_NAME_11654)){
            _29723 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NAME_11654)->dbl));
        }
        else{
            _29723 = (int)*(((s1_ptr)_2)->base + _26S_NAME_11654);
        }
        _29722 = NOVALUE;
        Ref(_29723);
        _29724 = _52NewEntry(_29723, _n_58600, 3, -100, _hashval_58601, _t_58604, _type_sym_58599);
        _29723 = NOVALUE;
        _2 = (int)SEQ_PTR(_52buckets_46126);
        _2 = (int)(((s1_ptr)_2)->base + _hashval_58601);
        _1 = *(int *)_2;
        *(int *)_2 = _29724;
        if( _1 != _29724 ){
            DeRef(_1);
        }
        _29724 = NOVALUE;

        /** 			Block_var( buckets[hashval] )*/
        _2 = (int)SEQ_PTR(_52buckets_46126);
        _29725 = (int)*(((s1_ptr)_2)->base + _hashval_58601);
        Ref(_29725);
        _65Block_var(_29725);
        _29725 = NOVALUE;

        /** 			return buckets[hashval]*/
        _2 = (int)SEQ_PTR(_52buckets_46126);
        _29726 = (int)*(((s1_ptr)_2)->base + _hashval_58601);
        Ref(_29726);
        return _29726;
        goto L1; // [243] 260

        /** 		case else*/
        default:

        /** 			InternalErr(267, {scope})*/
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = _scope_58602;
        _29727 = MAKE_SEQ(_1);
        _43InternalErr(267, _29727);
        _29727 = NOVALUE;
    ;}L1: 

    /** 	return 0*/
    _29726 = NOVALUE;
    return 0;
    ;
}


void _30For_statement()
{
    int _bp1_58669 = NOVALUE;
    int _bp2_58670 = NOVALUE;
    int _exit_base_58671 = NOVALUE;
    int _next_base_58672 = NOVALUE;
    int _end_op_58673 = NOVALUE;
    int _tok_58675 = NOVALUE;
    int _loop_var_58676 = NOVALUE;
    int _loop_var_sym_58678 = NOVALUE;
    int _save_syms_58679 = NOVALUE;
    int _29774 = NOVALUE;
    int _29772 = NOVALUE;
    int _29771 = NOVALUE;
    int _29765 = NOVALUE;
    int _29763 = NOVALUE;
    int _29761 = NOVALUE;
    int _29760 = NOVALUE;
    int _29759 = NOVALUE;
    int _29758 = NOVALUE;
    int _29756 = NOVALUE;
    int _29754 = NOVALUE;
    int _29753 = NOVALUE;
    int _29752 = NOVALUE;
    int _29751 = NOVALUE;
    int _29749 = NOVALUE;
    int _29747 = NOVALUE;
    int _29743 = NOVALUE;
    int _29741 = NOVALUE;
    int _29738 = NOVALUE;
    int _29736 = NOVALUE;
    int _29730 = NOVALUE;
    int _29729 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	sequence save_syms*/

    /** 	Start_block( FOR )*/
    _65Start_block(21, 0);

    /** 	loop_var = next_token()*/
    _0 = _loop_var_58676;
    _loop_var_58676 = _30next_token();
    DeRef(_0);

    /** 	if not find(loop_var[T_ID], ADDR_TOKS) then*/
    _2 = (int)SEQ_PTR(_loop_var_58676);
    _29729 = (int)*(((s1_ptr)_2)->base + 1);
    _29730 = find_from(_29729, _28ADDR_TOKS_11606, 1);
    _29729 = NOVALUE;
    if (_29730 != 0)
    goto L1; // [31] 42
    _29730 = NOVALUE;

    /** 		CompileErr(28)*/
    RefDS(_22037);
    _43CompileErr(28, _22037, 0);
L1: 

    /** 	if BIND then*/
    if (_26BIND_11622 == 0)
    {
        goto L2; // [46] 55
    }
    else{
    }

    /** 		add_ref(loop_var)*/
    Ref(_loop_var_58676);
    _52add_ref(_loop_var_58676);
L2: 

    /** 	tok_match(EQUALS)*/
    _30tok_match(3, 0);

    /** 	exit_base = length(exit_list)*/
    if (IS_SEQUENCE(_30exit_list_54176)){
            _exit_base_58671 = SEQ_PTR(_30exit_list_54176)->length;
    }
    else {
        _exit_base_58671 = 1;
    }

    /** 	next_base = length(continue_list)*/
    if (IS_SEQUENCE(_30continue_list_54178)){
            _next_base_58672 = SEQ_PTR(_30continue_list_54178)->length;
    }
    else {
        _next_base_58672 = 1;
    }

    /** 	Expr()*/
    _30Expr();

    /** 	tok_match(TO)*/
    _30tok_match(403, 0);

    /** 	exit_base = length(exit_list)*/
    if (IS_SEQUENCE(_30exit_list_54176)){
            _exit_base_58671 = SEQ_PTR(_30exit_list_54176)->length;
    }
    else {
        _exit_base_58671 = 1;
    }

    /** 	Expr()*/
    _30Expr();

    /** 	tok = next_token()*/
    _0 = _tok_58675;
    _tok_58675 = _30next_token();
    DeRef(_0);

    /** 	if tok[T_ID] = BY then*/
    _2 = (int)SEQ_PTR(_tok_58675);
    _29736 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29736, 404)){
        _29736 = NOVALUE;
        goto L3; // [115] 135
    }
    _29736 = NOVALUE;

    /** 		Expr()*/
    _30Expr();

    /** 		end_op = ENDFOR_GENERAL -- will be set at runtime by FOR op*/
    _end_op_58673 = 39;
    goto L4; // [132] 159
L3: 

    /** 		emit_opnd(NewIntSym(1))*/
    _29738 = _52NewIntSym(1);
    _37emit_opnd(_29738);
    _29738 = NOVALUE;

    /** 		putback(tok)*/
    Ref(_tok_58675);
    _30putback(_tok_58675);

    /** 		end_op = ENDFOR_INT_UP1*/
    _end_op_58673 = 54;
L4: 

    /** 	loop_var_sym = loop_var[T_SYM]*/
    _2 = (int)SEQ_PTR(_loop_var_58676);
    _loop_var_sym_58678 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_loop_var_sym_58678)){
        _loop_var_sym_58678 = (long)DBL_PTR(_loop_var_sym_58678)->dbl;
    }

    /** 	if CurrentSub = TopLevelSub then*/
    if (_26CurrentSub_11990 != _26TopLevelSub_11989)
    goto L5; // [175] 221

    /** 		DefinedYet(loop_var_sym)*/
    _52DefinedYet(_loop_var_sym_58678);

    /** 		SymTab[loop_var_sym][S_SCOPE] = SC_GLOOP_VAR*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_loop_var_sym_58678 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = 4;
    DeRef(_1);
    _29741 = NOVALUE;

    /** 		SymTab[loop_var_sym][S_VTYPE] = object_type*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_loop_var_sym_58678 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 15);
    _1 = *(int *)_2;
    *(int *)_2 = _52object_type_46130;
    DeRef(_1);
    _29743 = NOVALUE;
    goto L6; // [218] 265
L5: 

    /** 		loop_var_sym = SetPrivateScope(loop_var_sym, object_type, param_num)*/
    _loop_var_sym_58678 = _30SetPrivateScope(_loop_var_sym_58678, _52object_type_46130, _30param_num_54165);
    if (!IS_ATOM_INT(_loop_var_sym_58678)) {
        _1 = (long)(DBL_PTR(_loop_var_sym_58678)->dbl);
        DeRefDS(_loop_var_sym_58678);
        _loop_var_sym_58678 = _1;
    }

    /** 		param_num += 1*/
    _30param_num_54165 = _30param_num_54165 + 1;

    /** 		SymTab[loop_var_sym][S_SCOPE] = SC_LOOP_VAR*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_loop_var_sym_58678 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = 2;
    DeRef(_1);
    _29747 = NOVALUE;

    /** 		Pop_block_var()*/
    _65Pop_block_var();
L6: 

    /** 	SymTab[loop_var_sym][S_USAGE] = or_bits(SymTab[loop_var_sym][S_USAGE], U_USED)*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_loop_var_sym_58678 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _29751 = (int)*(((s1_ptr)_2)->base + _loop_var_sym_58678);
    _2 = (int)SEQ_PTR(_29751);
    _29752 = (int)*(((s1_ptr)_2)->base + 5);
    _29751 = NOVALUE;
    if (IS_ATOM_INT(_29752)) {
        {unsigned long tu;
             tu = (unsigned long)_29752 | (unsigned long)3;
             _29753 = MAKE_UINT(tu);
        }
    }
    else {
        _29753 = binary_op(OR_BITS, _29752, 3);
    }
    _29752 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = _29753;
    if( _1 != _29753 ){
        DeRef(_1);
    }
    _29753 = NOVALUE;
    _29749 = NOVALUE;

    /** 	op_info1 = loop_var_sym*/
    _37op_info1_50262 = _loop_var_sym_58678;

    /** 	emit_op(FOR)*/
    _37emit_op(21);

    /** 	emit_addr(loop_var_sym)*/
    _37emit_addr(_loop_var_sym_58678);

    /** 	if finish_block_header(FOR) then*/
    _29754 = _30finish_block_header(21);
    if (_29754 == 0) {
        DeRef(_29754);
        _29754 = NOVALUE;
        goto L7; // [325] 336
    }
    else {
        if (!IS_ATOM_INT(_29754) && DBL_PTR(_29754)->dbl == 0.0){
            DeRef(_29754);
            _29754 = NOVALUE;
            goto L7; // [325] 336
        }
        DeRef(_29754);
        _29754 = NOVALUE;
    }
    DeRef(_29754);
    _29754 = NOVALUE;

    /** 		CompileErr(83)*/
    RefDS(_22037);
    _43CompileErr(83, _22037, 0);
L7: 

    /** 	entry_addr &= 0*/
    Append(&_30entry_addr_54180, _30entry_addr_54180, 0);

    /** 	bp1 = length(Code)+1*/
    if (IS_SEQUENCE(_26Code_12071)){
            _29756 = SEQ_PTR(_26Code_12071)->length;
    }
    else {
        _29756 = 1;
    }
    _bp1_58669 = _29756 + 1;
    _29756 = NOVALUE;

    /** 	emit_addr(0) -- will be patched - don't straighten*/
    _37emit_addr(0);

    /** 	save_syms = Code[$-5..$-3] -- could be temps, but can't get rid of them yet*/
    if (IS_SEQUENCE(_26Code_12071)){
            _29758 = SEQ_PTR(_26Code_12071)->length;
    }
    else {
        _29758 = 1;
    }
    _29759 = _29758 - 5;
    _29758 = NOVALUE;
    if (IS_SEQUENCE(_26Code_12071)){
            _29760 = SEQ_PTR(_26Code_12071)->length;
    }
    else {
        _29760 = 1;
    }
    _29761 = _29760 - 3;
    _29760 = NOVALUE;
    rhs_slice_target = (object_ptr)&_save_syms_58679;
    RHS_Slice(_26Code_12071, _29759, _29761);

    /** 	for i = 1 to 3 do*/
    {
        int _i_58767;
        _i_58767 = 1;
L8: 
        if (_i_58767 > 3){
            goto L9; // [385] 408
        }

        /** 		clear_temp( save_syms[i] )*/
        _2 = (int)SEQ_PTR(_save_syms_58679);
        _29763 = (int)*(((s1_ptr)_2)->base + _i_58767);
        Ref(_29763);
        _37clear_temp(_29763);
        _29763 = NOVALUE;

        /** 	end for*/
        _i_58767 = _i_58767 + 1;
        goto L8; // [403] 392
L9: 
        ;
    }

    /** 	flush_temps()*/
    RefDS(_22037);
    _37flush_temps(_22037);

    /** 	bp2 = length(Code)*/
    if (IS_SEQUENCE(_26Code_12071)){
            _bp2_58670 = SEQ_PTR(_26Code_12071)->length;
    }
    else {
        _bp2_58670 = 1;
    }

    /** 	retry_addr &= bp2 + 1*/
    _29765 = _bp2_58670 + 1;
    Append(&_30retry_addr_54182, _30retry_addr_54182, _29765);
    _29765 = NOVALUE;

    /** 	continue_addr &= 0*/
    Append(&_30continue_addr_54181, _30continue_addr_54181, 0);

    /** 	loop_stack &= FOR*/
    Append(&_30loop_stack_54190, _30loop_stack_54190, 21);

    /** 	if not TRANSLATE then*/
    if (_26TRANSLATE_11619 != 0)
    goto LA; // [454] 478

    /** 		if OpTrace then*/
    if (_26OpTrace_12052 == 0)
    {
        goto LB; // [461] 477
    }
    else{
    }

    /** 			emit_op(DISPLAY_VAR)*/
    _37emit_op(87);

    /** 			emit_addr(loop_var_sym)*/
    _37emit_addr(_loop_var_sym_58678);
LB: 
LA: 

    /** 	Statement_list()*/
    _30Statement_list();

    /** 	tok_match(END)*/
    _30tok_match(402, 0);

    /** 	tok_match(FOR, END)*/
    _30tok_match(21, 402);

    /** 	End_block( FOR )*/
    _65End_block(21);

    /** 	StartSourceLine(TRUE, TRANSLATE)*/
    _37StartSourceLine(_9TRUE_430, _26TRANSLATE_11619, 2);

    /** 	op_info1 = loop_var_sym*/
    _37op_info1_50262 = _loop_var_sym_58678;

    /** 	op_info2 = bp2 + 1*/
    _37op_info2_50263 = _bp2_58670 + 1;

    /** 	PatchNList(next_base)*/
    _30PatchNList(_next_base_58672);

    /** 	emit_op(end_op)*/
    _37emit_op(_end_op_58673);

    /** 	backpatch(bp1, length(Code)+1)*/
    if (IS_SEQUENCE(_26Code_12071)){
            _29771 = SEQ_PTR(_26Code_12071)->length;
    }
    else {
        _29771 = 1;
    }
    _29772 = _29771 + 1;
    _29771 = NOVALUE;
    _37backpatch(_bp1_58669, _29772);
    _29772 = NOVALUE;

    /** 	if not TRANSLATE then*/
    if (_26TRANSLATE_11619 != 0)
    goto LC; // [564] 588

    /** 		if OpTrace then*/
    if (_26OpTrace_12052 == 0)
    {
        goto LD; // [571] 587
    }
    else{
    }

    /** 			emit_op(ERASE_SYMBOL)*/
    _37emit_op(90);

    /** 			emit_addr(loop_var_sym)*/
    _37emit_addr(_loop_var_sym_58678);
LD: 
LC: 

    /** 	Hide(loop_var_sym)*/
    _52Hide(_loop_var_sym_58678);

    /** 	exit_loop(exit_base)*/
    _30exit_loop(_exit_base_58671);

    /** 	for i = 1 to 3 do*/
    {
        int _i_58813;
        _i_58813 = 1;
LE: 
        if (_i_58813 > 3){
            goto LF; // [600] 626
        }

        /** 		emit_temp( save_syms[i], NEW_REFERENCE )*/
        _2 = (int)SEQ_PTR(_save_syms_58679);
        _29774 = (int)*(((s1_ptr)_2)->base + _i_58813);
        Ref(_29774);
        _37emit_temp(_29774, 1);
        _29774 = NOVALUE;

        /** 	end for*/
        _i_58813 = _i_58813 + 1;
        goto LE; // [621] 607
LF: 
        ;
    }

    /** 	flush_temps()*/
    RefDS(_22037);
    _37flush_temps(_22037);

    /** end procedure*/
    DeRef(_tok_58675);
    DeRef(_loop_var_58676);
    DeRef(_save_syms_58679);
    DeRef(_29759);
    _29759 = NOVALUE;
    DeRef(_29761);
    _29761 = NOVALUE;
    return;
    ;
}


int _30CompileType(int _type_ptr_58821)
{
    int _t_58822 = NOVALUE;
    int _29785 = NOVALUE;
    int _29784 = NOVALUE;
    int _29783 = NOVALUE;
    int _29777 = NOVALUE;
    int _29776 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_type_ptr_58821)) {
        _1 = (long)(DBL_PTR(_type_ptr_58821)->dbl);
        DeRefDS(_type_ptr_58821);
        _type_ptr_58821 = _1;
    }

    /** 	if type_ptr < 0 then*/
    if (_type_ptr_58821 >= 0)
    goto L1; // [5] 16

    /** 		return type_ptr*/
    return _type_ptr_58821;
L1: 

    /** 	if SymTab[type_ptr][S_TOKEN] = OBJECT then*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _29776 = (int)*(((s1_ptr)_2)->base + _type_ptr_58821);
    _2 = (int)SEQ_PTR(_29776);
    if (!IS_ATOM_INT(_26S_TOKEN_11659)){
        _29777 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_TOKEN_11659)->dbl));
    }
    else{
        _29777 = (int)*(((s1_ptr)_2)->base + _26S_TOKEN_11659);
    }
    _29776 = NOVALUE;
    if (binary_op_a(NOTEQ, _29777, 415)){
        _29777 = NOVALUE;
        goto L2; // [32] 47
    }
    _29777 = NOVALUE;

    /** 		return TYPE_OBJECT*/
    return 16;
    goto L3; // [44] 218
L2: 

    /** 	elsif type_ptr = integer_type then*/
    if (_type_ptr_58821 != _52integer_type_46136)
    goto L4; // [51] 66

    /** 		return TYPE_INTEGER*/
    return 1;
    goto L3; // [63] 218
L4: 

    /** 	elsif type_ptr = atom_type then*/
    if (_type_ptr_58821 != _52atom_type_46132)
    goto L5; // [70] 85

    /** 		return TYPE_ATOM*/
    return 4;
    goto L3; // [82] 218
L5: 

    /** 	elsif type_ptr = sequence_type then*/
    if (_type_ptr_58821 != _52sequence_type_46134)
    goto L6; // [89] 104

    /** 		return TYPE_SEQUENCE*/
    return 8;
    goto L3; // [101] 218
L6: 

    /** 	elsif type_ptr = object_type then*/
    if (_type_ptr_58821 != _52object_type_46130)
    goto L7; // [108] 123

    /** 		return TYPE_OBJECT*/
    return 16;
    goto L3; // [120] 218
L7: 

    /** 		t = SymTab[SymTab[type_ptr][S_NEXT]][S_VTYPE]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _29783 = (int)*(((s1_ptr)_2)->base + _type_ptr_58821);
    _2 = (int)SEQ_PTR(_29783);
    _29784 = (int)*(((s1_ptr)_2)->base + 2);
    _29783 = NOVALUE;
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!IS_ATOM_INT(_29784)){
        _29785 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_29784)->dbl));
    }
    else{
        _29785 = (int)*(((s1_ptr)_2)->base + _29784);
    }
    _2 = (int)SEQ_PTR(_29785);
    _t_58822 = (int)*(((s1_ptr)_2)->base + 15);
    if (!IS_ATOM_INT(_t_58822)){
        _t_58822 = (long)DBL_PTR(_t_58822)->dbl;
    }
    _29785 = NOVALUE;

    /** 		if t = integer_type then*/
    if (_t_58822 != _52integer_type_46136)
    goto L8; // [155] 170

    /** 			return TYPE_INTEGER*/
    _29784 = NOVALUE;
    return 1;
    goto L9; // [167] 217
L8: 

    /** 		elsif t = atom_type then*/
    if (_t_58822 != _52atom_type_46132)
    goto LA; // [174] 189

    /** 			return TYPE_ATOM*/
    _29784 = NOVALUE;
    return 4;
    goto L9; // [186] 217
LA: 

    /** 		elsif t = sequence_type then*/
    if (_t_58822 != _52sequence_type_46134)
    goto LB; // [193] 208

    /** 			return TYPE_SEQUENCE*/
    _29784 = NOVALUE;
    return 8;
    goto L9; // [205] 217
LB: 

    /** 			return TYPE_OBJECT*/
    _29784 = NOVALUE;
    return 16;
L9: 
L3: 
    ;
}


int _30get_assigned_sym()
{
    int _29798 = NOVALUE;
    int _29797 = NOVALUE;
    int _29796 = NOVALUE;
    int _29794 = NOVALUE;
    int _29793 = NOVALUE;
    int _29792 = NOVALUE;
    int _29791 = NOVALUE;
    int _29790 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not find( Code[$-2], {ASSIGN, ASSIGN_I}) then*/
    if (IS_SEQUENCE(_26Code_12071)){
            _29790 = SEQ_PTR(_26Code_12071)->length;
    }
    else {
        _29790 = 1;
    }
    _29791 = _29790 - 2;
    _29790 = NOVALUE;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _29792 = (int)*(((s1_ptr)_2)->base + _29791);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 18;
    ((int *)_2)[2] = 113;
    _29793 = MAKE_SEQ(_1);
    _29794 = find_from(_29792, _29793, 1);
    _29792 = NOVALUE;
    DeRefDS(_29793);
    _29793 = NOVALUE;
    if (_29794 != 0)
    goto L1; // [29] 39
    _29794 = NOVALUE;

    /** 		return 0*/
    _29791 = NOVALUE;
    return 0;
L1: 

    /** 	return Code[$-1]*/
    if (IS_SEQUENCE(_26Code_12071)){
            _29796 = SEQ_PTR(_26Code_12071)->length;
    }
    else {
        _29796 = 1;
    }
    _29797 = _29796 - 1;
    _29796 = NOVALUE;
    _2 = (int)SEQ_PTR(_26Code_12071);
    _29798 = (int)*(((s1_ptr)_2)->base + _29797);
    Ref(_29798);
    DeRef(_29791);
    _29791 = NOVALUE;
    _29797 = NOVALUE;
    return _29798;
    ;
}


void _30Assign_Constant(int _sym_58891)
{
    int _valsym_58893 = NOVALUE;
    int _val_58896 = NOVALUE;
    int _29825 = NOVALUE;
    int _29824 = NOVALUE;
    int _29822 = NOVALUE;
    int _29821 = NOVALUE;
    int _29820 = NOVALUE;
    int _29818 = NOVALUE;
    int _29817 = NOVALUE;
    int _29816 = NOVALUE;
    int _29814 = NOVALUE;
    int _29813 = NOVALUE;
    int _29812 = NOVALUE;
    int _29810 = NOVALUE;
    int _29809 = NOVALUE;
    int _29808 = NOVALUE;
    int _29806 = NOVALUE;
    int _29804 = NOVALUE;
    int _29802 = NOVALUE;
    int _29800 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	symtab_index valsym = Pop() -- pop the sym for the constant, too*/
    _valsym_58893 = _37Pop();
    if (!IS_ATOM_INT(_valsym_58893)) {
        _1 = (long)(DBL_PTR(_valsym_58893)->dbl);
        DeRefDS(_valsym_58893);
        _valsym_58893 = _1;
    }

    /** 	object val = SymTab[valsym][S_OBJ]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _29800 = (int)*(((s1_ptr)_2)->base + _valsym_58893);
    DeRef(_val_58896);
    _2 = (int)SEQ_PTR(_29800);
    _val_58896 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_val_58896);
    _29800 = NOVALUE;

    /** 	SymTab[sym][S_OBJ] = val*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58891 + ((s1_ptr)_2)->base);
    Ref(_val_58896);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _val_58896;
    DeRef(_1);
    _29802 = NOVALUE;

    /** 	SymTab[sym][S_INITLEVEL] = 0*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58891 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 14);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _29804 = NOVALUE;

    /** 	if TRANSLATE then*/
    if (_26TRANSLATE_11619 == 0)
    {
        goto L1; // [58] 197
    }
    else{
    }

    /** 		SymTab[sym][S_GTYPE] = SymTab[valsym][S_GTYPE]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58891 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _29808 = (int)*(((s1_ptr)_2)->base + _valsym_58893);
    _2 = (int)SEQ_PTR(_29808);
    _29809 = (int)*(((s1_ptr)_2)->base + 36);
    _29808 = NOVALUE;
    Ref(_29809);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 36);
    _1 = *(int *)_2;
    *(int *)_2 = _29809;
    if( _1 != _29809 ){
        DeRef(_1);
    }
    _29809 = NOVALUE;
    _29806 = NOVALUE;

    /** 		SymTab[sym][S_SEQ_ELEM] = SymTab[valsym][S_SEQ_ELEM]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58891 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _29812 = (int)*(((s1_ptr)_2)->base + _valsym_58893);
    _2 = (int)SEQ_PTR(_29812);
    _29813 = (int)*(((s1_ptr)_2)->base + 33);
    _29812 = NOVALUE;
    Ref(_29813);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 33);
    _1 = *(int *)_2;
    *(int *)_2 = _29813;
    if( _1 != _29813 ){
        DeRef(_1);
    }
    _29813 = NOVALUE;
    _29810 = NOVALUE;

    /** 		SymTab[sym][S_OBJ_MIN] = SymTab[valsym][S_OBJ_MIN]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58891 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _29816 = (int)*(((s1_ptr)_2)->base + _valsym_58893);
    _2 = (int)SEQ_PTR(_29816);
    _29817 = (int)*(((s1_ptr)_2)->base + 30);
    _29816 = NOVALUE;
    Ref(_29817);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 30);
    _1 = *(int *)_2;
    *(int *)_2 = _29817;
    if( _1 != _29817 ){
        DeRef(_1);
    }
    _29817 = NOVALUE;
    _29814 = NOVALUE;

    /** 		SymTab[sym][S_OBJ_MAX] = SymTab[valsym][S_OBJ_MAX]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58891 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _29820 = (int)*(((s1_ptr)_2)->base + _valsym_58893);
    _2 = (int)SEQ_PTR(_29820);
    _29821 = (int)*(((s1_ptr)_2)->base + 31);
    _29820 = NOVALUE;
    Ref(_29821);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 31);
    _1 = *(int *)_2;
    *(int *)_2 = _29821;
    if( _1 != _29821 ){
        DeRef(_1);
    }
    _29821 = NOVALUE;
    _29818 = NOVALUE;

    /** 		SymTab[sym][S_SEQ_LEN] = SymTab[valsym][S_SEQ_LEN]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58891 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _29824 = (int)*(((s1_ptr)_2)->base + _valsym_58893);
    _2 = (int)SEQ_PTR(_29824);
    _29825 = (int)*(((s1_ptr)_2)->base + 32);
    _29824 = NOVALUE;
    Ref(_29825);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 32);
    _1 = *(int *)_2;
    *(int *)_2 = _29825;
    if( _1 != _29825 ){
        DeRef(_1);
    }
    _29825 = NOVALUE;
    _29822 = NOVALUE;
L1: 

    /** end procedure*/
    DeRef(_val_58896);
    return;
    ;
}


int _30Global_declaration(int _type_ptr_58953, int _scope_58954)
{
    int _new_symbols_58955 = NOVALUE;
    int _tok_58957 = NOVALUE;
    int _tsym_58958 = NOVALUE;
    int _prevtok_58959 = NOVALUE;
    int _sym_58961 = NOVALUE;
    int _valsym_58962 = NOVALUE;
    int _h_58963 = NOVALUE;
    int _count_58964 = NOVALUE;
    int _val_58965 = NOVALUE;
    int _usedval_58966 = NOVALUE;
    int _deltafunc_58967 = NOVALUE;
    int _delta_58968 = NOVALUE;
    int _is_fwd_ref_58969 = NOVALUE;
    int _ptok_58986 = NOVALUE;
    int _negate_59002 = NOVALUE;
    int _negate_59248 = NOVALUE;
    int _31650 = NOVALUE;
    int _31649 = NOVALUE;
    int _31648 = NOVALUE;
    int _30065 = NOVALUE;
    int _30063 = NOVALUE;
    int _30061 = NOVALUE;
    int _30059 = NOVALUE;
    int _30057 = NOVALUE;
    int _30054 = NOVALUE;
    int _30052 = NOVALUE;
    int _30051 = NOVALUE;
    int _30050 = NOVALUE;
    int _30049 = NOVALUE;
    int _30048 = NOVALUE;
    int _30047 = NOVALUE;
    int _30045 = NOVALUE;
    int _30041 = NOVALUE;
    int _30039 = NOVALUE;
    int _30037 = NOVALUE;
    int _30035 = NOVALUE;
    int _30033 = NOVALUE;
    int _30031 = NOVALUE;
    int _30030 = NOVALUE;
    int _30028 = NOVALUE;
    int _30027 = NOVALUE;
    int _30026 = NOVALUE;
    int _30024 = NOVALUE;
    int _30022 = NOVALUE;
    int _30020 = NOVALUE;
    int _30019 = NOVALUE;
    int _30018 = NOVALUE;
    int _30016 = NOVALUE;
    int _30015 = NOVALUE;
    int _30014 = NOVALUE;
    int _30012 = NOVALUE;
    int _30010 = NOVALUE;
    int _30008 = NOVALUE;
    int _30007 = NOVALUE;
    int _30006 = NOVALUE;
    int _30005 = NOVALUE;
    int _30004 = NOVALUE;
    int _30001 = NOVALUE;
    int _29999 = NOVALUE;
    int _29997 = NOVALUE;
    int _29996 = NOVALUE;
    int _29995 = NOVALUE;
    int _29991 = NOVALUE;
    int _29990 = NOVALUE;
    int _29989 = NOVALUE;
    int _29985 = NOVALUE;
    int _29984 = NOVALUE;
    int _29983 = NOVALUE;
    int _29981 = NOVALUE;
    int _29980 = NOVALUE;
    int _29979 = NOVALUE;
    int _29978 = NOVALUE;
    int _29977 = NOVALUE;
    int _29976 = NOVALUE;
    int _29975 = NOVALUE;
    int _29974 = NOVALUE;
    int _29973 = NOVALUE;
    int _29970 = NOVALUE;
    int _29968 = NOVALUE;
    int _29967 = NOVALUE;
    int _29965 = NOVALUE;
    int _29964 = NOVALUE;
    int _29962 = NOVALUE;
    int _29961 = NOVALUE;
    int _29960 = NOVALUE;
    int _29959 = NOVALUE;
    int _29957 = NOVALUE;
    int _29955 = NOVALUE;
    int _29953 = NOVALUE;
    int _29950 = NOVALUE;
    int _29947 = NOVALUE;
    int _29944 = NOVALUE;
    int _29942 = NOVALUE;
    int _29941 = NOVALUE;
    int _29940 = NOVALUE;
    int _29939 = NOVALUE;
    int _29937 = NOVALUE;
    int _29936 = NOVALUE;
    int _29935 = NOVALUE;
    int _29934 = NOVALUE;
    int _29930 = NOVALUE;
    int _29929 = NOVALUE;
    int _29928 = NOVALUE;
    int _29927 = NOVALUE;
    int _29926 = NOVALUE;
    int _29925 = NOVALUE;
    int _29922 = NOVALUE;
    int _29920 = NOVALUE;
    int _29919 = NOVALUE;
    int _29918 = NOVALUE;
    int _29917 = NOVALUE;
    int _29916 = NOVALUE;
    int _29913 = NOVALUE;
    int _29911 = NOVALUE;
    int _29909 = NOVALUE;
    int _29908 = NOVALUE;
    int _29907 = NOVALUE;
    int _29906 = NOVALUE;
    int _29905 = NOVALUE;
    int _29904 = NOVALUE;
    int _29903 = NOVALUE;
    int _29901 = NOVALUE;
    int _29898 = NOVALUE;
    int _29896 = NOVALUE;
    int _29895 = NOVALUE;
    int _29894 = NOVALUE;
    int _29893 = NOVALUE;
    int _29892 = NOVALUE;
    int _29891 = NOVALUE;
    int _29890 = NOVALUE;
    int _29889 = NOVALUE;
    int _29886 = NOVALUE;
    int _29885 = NOVALUE;
    int _29884 = NOVALUE;
    int _29882 = NOVALUE;
    int _29881 = NOVALUE;
    int _29880 = NOVALUE;
    int _29879 = NOVALUE;
    int _29878 = NOVALUE;
    int _29876 = NOVALUE;
    int _29875 = NOVALUE;
    int _29874 = NOVALUE;
    int _29872 = NOVALUE;
    int _29871 = NOVALUE;
    int _29869 = NOVALUE;
    int _29866 = NOVALUE;
    int _29864 = NOVALUE;
    int _29862 = NOVALUE;
    int _29854 = NOVALUE;
    int _29853 = NOVALUE;
    int _29851 = NOVALUE;
    int _29848 = NOVALUE;
    int _29841 = NOVALUE;
    int _29838 = NOVALUE;
    int _29837 = NOVALUE;
    int _29835 = NOVALUE;
    int _29831 = NOVALUE;
    int _29830 = NOVALUE;
    int _29829 = NOVALUE;
    int _29828 = NOVALUE;
    int _29827 = NOVALUE;
    int _29826 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_type_ptr_58953)) {
        _1 = (long)(DBL_PTR(_type_ptr_58953)->dbl);
        DeRefDS(_type_ptr_58953);
        _type_ptr_58953 = _1;
    }

    /** 	object tsym*/

    /** 	object prevtok = 0*/
    DeRef(_prevtok_58959);
    _prevtok_58959 = 0;

    /** 	integer h, count = 0*/
    _count_58964 = 0;

    /** 	atom val = 1, usedval*/
    DeRef(_val_58965);
    _val_58965 = 1;

    /** 	integer deltafunc = '+'*/
    _deltafunc_58967 = 43;

    /** 	atom delta = 1*/
    DeRef(_delta_58968);
    _delta_58968 = 1;

    /** 	new_symbols = {}*/
    RefDS(_22037);
    DeRefi(_new_symbols_58955);
    _new_symbols_58955 = _22037;

    /** 	integer is_fwd_ref = 0*/
    _is_fwd_ref_58969 = 0;

    /** 	if type_ptr > 0 and SymTab[type_ptr][S_SCOPE] = SC_UNDEFINED then*/
    _29826 = (_type_ptr_58953 > 0);
    if (_29826 == 0) {
        goto L1; // [50] 105
    }
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _29828 = (int)*(((s1_ptr)_2)->base + _type_ptr_58953);
    _2 = (int)SEQ_PTR(_29828);
    _29829 = (int)*(((s1_ptr)_2)->base + 4);
    _29828 = NOVALUE;
    if (IS_ATOM_INT(_29829)) {
        _29830 = (_29829 == 9);
    }
    else {
        _29830 = binary_op(EQUALS, _29829, 9);
    }
    _29829 = NOVALUE;
    if (_29830 == 0) {
        DeRef(_29830);
        _29830 = NOVALUE;
        goto L1; // [73] 105
    }
    else {
        if (!IS_ATOM_INT(_29830) && DBL_PTR(_29830)->dbl == 0.0){
            DeRef(_29830);
            _29830 = NOVALUE;
            goto L1; // [73] 105
        }
        DeRef(_29830);
        _29830 = NOVALUE;
    }
    DeRef(_29830);
    _29830 = NOVALUE;

    /** 		is_fwd_ref = 1*/
    _is_fwd_ref_58969 = 1;

    /** 		Hide(type_ptr)*/
    _52Hide(_type_ptr_58953);

    /** 		type_ptr = -new_forward_reference( TYPE, type_ptr )*/
    DeRef(_31650);
    _31650 = 504;
    _29831 = _29new_forward_reference(504, _type_ptr_58953, 504);
    _31650 = NOVALUE;
    if (IS_ATOM_INT(_29831)) {
        if ((unsigned long)_29831 == 0xC0000000)
        _type_ptr_58953 = (int)NewDouble((double)-0xC0000000);
        else
        _type_ptr_58953 = - _29831;
    }
    else {
        _type_ptr_58953 = unary_op(UMINUS, _29831);
    }
    DeRef(_29831);
    _29831 = NOVALUE;
    if (!IS_ATOM_INT(_type_ptr_58953)) {
        _1 = (long)(DBL_PTR(_type_ptr_58953)->dbl);
        DeRefDS(_type_ptr_58953);
        _type_ptr_58953 = _1;
    }
L1: 

    /** 	if type_ptr = -1 then*/
    if (_type_ptr_58953 != -1)
    goto L2; // [107] 423

    /** 		sequence ptok = next_token()*/
    _0 = _ptok_58986;
    _ptok_58986 = _30next_token();
    DeRef(_0);

    /** 		if ptok[T_ID] = TYPE_DECL then*/
    _2 = (int)SEQ_PTR(_ptok_58986);
    _29835 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29835, 416)){
        _29835 = NOVALUE;
        goto L3; // [128] 171
    }
    _29835 = NOVALUE;

    /** 			putback(keyfind("enum",-1))*/
    RefDS(_26333);
    DeRef(_31648);
    _31648 = _26333;
    _31649 = _52hashfn(_31648);
    _31648 = NOVALUE;
    RefDS(_26333);
    _29837 = _52keyfind(_26333, -1, _26current_file_no_11982, 0, _31649);
    _31649 = NOVALUE;
    _30putback(_29837);
    _29837 = NOVALUE;

    /** 			SubProg(TYPE_DECL, scope)*/
    _30SubProg(416, _scope_58954);

    /** 			return {}*/
    RefDS(_22037);
    DeRefDS(_ptok_58986);
    DeRefi(_new_symbols_58955);
    DeRef(_tok_58957);
    DeRef(_tsym_58958);
    DeRef(_prevtok_58959);
    DeRef(_val_58965);
    DeRef(_usedval_58966);
    DeRef(_delta_58968);
    DeRef(_29826);
    _29826 = NOVALUE;
    return _22037;
    goto L4; // [168] 422
L3: 

    /** 		elsif ptok[T_ID] = BY then*/
    _2 = (int)SEQ_PTR(_ptok_58986);
    _29838 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29838, 404)){
        _29838 = NOVALUE;
        goto L5; // [181] 416
    }
    _29838 = NOVALUE;

    /** 			integer negate = 0*/
    _negate_59002 = 0;

    /** 			ptok = next_token()*/
    _0 = _ptok_58986;
    _ptok_58986 = _30next_token();
    DeRefDS(_0);

    /** 			switch ptok[T_ID] do*/
    _2 = (int)SEQ_PTR(_ptok_58986);
    _29841 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_29841) ){
        goto L6; // [205] 284
    }
    if(!IS_ATOM_INT(_29841)){
        if( (DBL_PTR(_29841)->dbl != (double) ((int) DBL_PTR(_29841)->dbl) ) ){
            goto L6; // [205] 284
        }
        _0 = (int) DBL_PTR(_29841)->dbl;
    }
    else {
        _0 = _29841;
    };
    _29841 = NOVALUE;
    switch ( _0 ){ 

        /** 				case reserved:MULTIPLY then*/
        case 13:

        /** 					deltafunc = '*'*/
        _deltafunc_58967 = 42;

        /** 					ptok = next_token()*/
        _0 = _ptok_58986;
        _ptok_58986 = _30next_token();
        DeRef(_0);
        goto L7; // [226] 292

        /** 				case reserved:DIVIDE then*/
        case 14:

        /** 					deltafunc = '/'*/
        _deltafunc_58967 = 47;

        /** 					ptok = next_token()*/
        _0 = _ptok_58986;
        _ptok_58986 = _30next_token();
        DeRef(_0);
        goto L7; // [244] 292

        /** 				case MINUS then*/
        case 10:

        /** 					deltafunc = '-'*/
        _deltafunc_58967 = 45;

        /** 					ptok = next_token()*/
        _0 = _ptok_58986;
        _ptok_58986 = _30next_token();
        DeRef(_0);
        goto L7; // [262] 292

        /** 				case PLUS then*/
        case 11:

        /** 					deltafunc = '+'*/
        _deltafunc_58967 = 43;

        /** 					ptok = next_token()*/
        _0 = _ptok_58986;
        _ptok_58986 = _30next_token();
        DeRef(_0);
        goto L7; // [280] 292

        /** 				case else*/
        default:
L6: 

        /** 					deltafunc = '+'*/
        _deltafunc_58967 = 43;
    ;}L7: 

    /** 			if ptok[T_ID] = MINUS then*/
    _2 = (int)SEQ_PTR(_ptok_58986);
    _29848 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29848, 10)){
        _29848 = NOVALUE;
        goto L8; // [302] 319
    }
    _29848 = NOVALUE;

    /** 				negate = 1*/
    _negate_59002 = 1;

    /** 				ptok = next_token()*/
    _0 = _ptok_58986;
    _ptok_58986 = _30next_token();
    DeRefDS(_0);
L8: 

    /** 			if ptok[T_ID] != ATOM then*/
    _2 = (int)SEQ_PTR(_ptok_58986);
    _29851 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _29851, 502)){
        _29851 = NOVALUE;
        goto L9; // [329] 341
    }
    _29851 = NOVALUE;

    /** 				CompileErr( 344 )*/
    RefDS(_22037);
    _43CompileErr(344, _22037, 0);
L9: 

    /** 			delta = SymTab[ptok[T_SYM]][S_OBJ]*/
    _2 = (int)SEQ_PTR(_ptok_58986);
    _29853 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!IS_ATOM_INT(_29853)){
        _29854 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_29853)->dbl));
    }
    else{
        _29854 = (int)*(((s1_ptr)_2)->base + _29853);
    }
    DeRef(_delta_58968);
    _2 = (int)SEQ_PTR(_29854);
    _delta_58968 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_delta_58968);
    _29854 = NOVALUE;

    /** 			if negate then*/
    if (_negate_59002 == 0)
    {
        goto LA; // [363] 372
    }
    else{
    }

    /** 				delta = -delta*/
    _0 = _delta_58968;
    if (IS_ATOM_INT(_delta_58968)) {
        if ((unsigned long)_delta_58968 == 0xC0000000)
        _delta_58968 = (int)NewDouble((double)-0xC0000000);
        else
        _delta_58968 = - _delta_58968;
    }
    else {
        _delta_58968 = unary_op(UMINUS, _delta_58968);
    }
    DeRef(_0);
LA: 

    /** 			switch deltafunc do*/
    _0 = _deltafunc_58967;
    switch ( _0 ){ 

        /** 				case '/' then*/
        case 47:

        /** 					delta = 1 / delta*/
        _0 = _delta_58968;
        if (IS_ATOM_INT(_delta_58968)) {
            _delta_58968 = (1 % _delta_58968) ? NewDouble((double)1 / _delta_58968) : (1 / _delta_58968);
        }
        else {
            _delta_58968 = NewDouble((double)1 / DBL_PTR(_delta_58968)->dbl);
        }
        DeRef(_0);

        /** 					deltafunc = '*'*/
        _deltafunc_58967 = 42;
        goto LB; // [394] 411

        /** 				case '-' then*/
        case 45:

        /** 					delta = -delta*/
        _0 = _delta_58968;
        if (IS_ATOM_INT(_delta_58968)) {
            if ((unsigned long)_delta_58968 == 0xC0000000)
            _delta_58968 = (int)NewDouble((double)-0xC0000000);
            else
            _delta_58968 = - _delta_58968;
        }
        else {
            _delta_58968 = unary_op(UMINUS, _delta_58968);
        }
        DeRef(_0);

        /** 					deltafunc = '+'*/
        _deltafunc_58967 = 43;
    ;}LB: 
    goto L4; // [413] 422
L5: 

    /** 			putback(ptok)*/
    RefDS(_ptok_58986);
    _30putback(_ptok_58986);
L4: 
L2: 
    DeRef(_ptok_58986);
    _ptok_58986 = NOVALUE;

    /** 	valsym = 0*/
    _valsym_58962 = 0;

    /** 	while TRUE do*/
LC: 
    if (_9TRUE_430 == 0)
    {
        goto LD; // [439] 2282
    }
    else{
    }

    /** 		tok = next_token()*/
    _0 = _tok_58957;
    _tok_58957 = _30next_token();
    DeRef(_0);

    /** 		if tok[T_ID] = DOLLAR then*/
    _2 = (int)SEQ_PTR(_tok_58957);
    _29862 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29862, -22)){
        _29862 = NOVALUE;
        goto LE; // [457] 496
    }
    _29862 = NOVALUE;

    /** 			if not equal(prevtok, 0) then*/
    if (_prevtok_58959 == 0)
    _29864 = 1;
    else if (IS_ATOM_INT(_prevtok_58959) && IS_ATOM_INT(0))
    _29864 = 0;
    else
    _29864 = (compare(_prevtok_58959, 0) == 0);
    if (_29864 != 0)
    goto LF; // [467] 495
    _29864 = NOVALUE;

    /** 				if prevtok[T_ID] = COMMA then*/
    _2 = (int)SEQ_PTR(_prevtok_58959);
    _29866 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29866, -30)){
        _29866 = NOVALUE;
        goto L10; // [480] 494
    }
    _29866 = NOVALUE;

    /** 					tok = next_token()*/
    _0 = _tok_58957;
    _tok_58957 = _30next_token();
    DeRef(_0);

    /** 					exit*/
    goto LD; // [491] 2282
L10: 
LF: 
LE: 

    /** 		if tok[T_ID] = END_OF_FILE then*/
    _2 = (int)SEQ_PTR(_tok_58957);
    _29869 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29869, -21)){
        _29869 = NOVALUE;
        goto L11; // [506] 518
    }
    _29869 = NOVALUE;

    /** 			CompileErr( 32 )*/
    RefDS(_22037);
    _43CompileErr(32, _22037, 0);
L11: 

    /** 		if not find(tok[T_ID], ADDR_TOKS) then*/
    _2 = (int)SEQ_PTR(_tok_58957);
    _29871 = (int)*(((s1_ptr)_2)->base + 1);
    _29872 = find_from(_29871, _28ADDR_TOKS_11606, 1);
    _29871 = NOVALUE;
    if (_29872 != 0)
    goto L12; // [533] 558
    _29872 = NOVALUE;

    /** 			CompileErr(25, {find_category(tok[T_ID])} )*/
    _2 = (int)SEQ_PTR(_tok_58957);
    _29874 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_29874);
    _29875 = _62find_category(_29874);
    _29874 = NOVALUE;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _29875;
    _29876 = MAKE_SEQ(_1);
    _29875 = NOVALUE;
    _43CompileErr(25, _29876, 0);
    _29876 = NOVALUE;
L12: 

    /** 		sym = tok[T_SYM]*/
    _2 = (int)SEQ_PTR(_tok_58957);
    _sym_58961 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_sym_58961)){
        _sym_58961 = (long)DBL_PTR(_sym_58961)->dbl;
    }

    /** 		DefinedYet(sym)*/
    _52DefinedYet(_sym_58961);

    /** 		if find(SymTab[sym][S_SCOPE], {SC_GLOBAL, SC_PREDEF, SC_PUBLIC, SC_EXPORT}) then*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _29878 = (int)*(((s1_ptr)_2)->base + _sym_58961);
    _2 = (int)SEQ_PTR(_29878);
    _29879 = (int)*(((s1_ptr)_2)->base + 4);
    _29878 = NOVALUE;
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 6;
    *((int *)(_2+8)) = 7;
    *((int *)(_2+12)) = 13;
    *((int *)(_2+16)) = 11;
    _29880 = MAKE_SEQ(_1);
    _29881 = find_from(_29879, _29880, 1);
    _29879 = NOVALUE;
    DeRefDS(_29880);
    _29880 = NOVALUE;
    if (_29881 == 0)
    {
        _29881 = NOVALUE;
        goto L13; // [607] 669
    }
    else{
        _29881 = NOVALUE;
    }

    /** 			h = SymTab[sym][S_HASHVAL]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _29882 = (int)*(((s1_ptr)_2)->base + _sym_58961);
    _2 = (int)SEQ_PTR(_29882);
    _h_58963 = (int)*(((s1_ptr)_2)->base + 11);
    if (!IS_ATOM_INT(_h_58963)){
        _h_58963 = (long)DBL_PTR(_h_58963)->dbl;
    }
    _29882 = NOVALUE;

    /** 			sym = NewEntry(SymTab[sym][S_NAME], 0, 0, VARIABLE, h, buckets[h], 0)*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _29884 = (int)*(((s1_ptr)_2)->base + _sym_58961);
    _2 = (int)SEQ_PTR(_29884);
    if (!IS_ATOM_INT(_26S_NAME_11654)){
        _29885 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NAME_11654)->dbl));
    }
    else{
        _29885 = (int)*(((s1_ptr)_2)->base + _26S_NAME_11654);
    }
    _29884 = NOVALUE;
    _2 = (int)SEQ_PTR(_52buckets_46126);
    _29886 = (int)*(((s1_ptr)_2)->base + _h_58963);
    Ref(_29885);
    Ref(_29886);
    _sym_58961 = _52NewEntry(_29885, 0, 0, -100, _h_58963, _29886, 0);
    _29885 = NOVALUE;
    _29886 = NOVALUE;
    if (!IS_ATOM_INT(_sym_58961)) {
        _1 = (long)(DBL_PTR(_sym_58961)->dbl);
        DeRefDS(_sym_58961);
        _sym_58961 = _1;
    }

    /** 			buckets[h] = sym*/
    _2 = (int)SEQ_PTR(_52buckets_46126);
    _2 = (int)(((s1_ptr)_2)->base + _h_58963);
    _1 = *(int *)_2;
    *(int *)_2 = _sym_58961;
    DeRef(_1);
L13: 

    /** 		new_symbols = append(new_symbols, sym)*/
    Append(&_new_symbols_58955, _new_symbols_58955, _sym_58961);

    /** 		Block_var( sym )*/
    _65Block_var(_sym_58961);

    /** 		if SymTab[sym][S_SCOPE] = SC_UNDEFINED and SymTab[sym][S_FILE_NO] != current_file_no then*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _29889 = (int)*(((s1_ptr)_2)->base + _sym_58961);
    _2 = (int)SEQ_PTR(_29889);
    _29890 = (int)*(((s1_ptr)_2)->base + 4);
    _29889 = NOVALUE;
    if (IS_ATOM_INT(_29890)) {
        _29891 = (_29890 == 9);
    }
    else {
        _29891 = binary_op(EQUALS, _29890, 9);
    }
    _29890 = NOVALUE;
    if (IS_ATOM_INT(_29891)) {
        if (_29891 == 0) {
            goto L14; // [700] 744
        }
    }
    else {
        if (DBL_PTR(_29891)->dbl == 0.0) {
            goto L14; // [700] 744
        }
    }
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _29893 = (int)*(((s1_ptr)_2)->base + _sym_58961);
    _2 = (int)SEQ_PTR(_29893);
    if (!IS_ATOM_INT(_26S_FILE_NO_11650)){
        _29894 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_FILE_NO_11650)->dbl));
    }
    else{
        _29894 = (int)*(((s1_ptr)_2)->base + _26S_FILE_NO_11650);
    }
    _29893 = NOVALUE;
    if (IS_ATOM_INT(_29894)) {
        _29895 = (_29894 != _26current_file_no_11982);
    }
    else {
        _29895 = binary_op(NOTEQ, _29894, _26current_file_no_11982);
    }
    _29894 = NOVALUE;
    if (_29895 == 0) {
        DeRef(_29895);
        _29895 = NOVALUE;
        goto L14; // [723] 744
    }
    else {
        if (!IS_ATOM_INT(_29895) && DBL_PTR(_29895)->dbl == 0.0){
            DeRef(_29895);
            _29895 = NOVALUE;
            goto L14; // [723] 744
        }
        DeRef(_29895);
        _29895 = NOVALUE;
    }
    DeRef(_29895);
    _29895 = NOVALUE;

    /** 			SymTab[sym][S_FILE_NO] = current_file_no*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58961 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_26S_FILE_NO_11650))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_FILE_NO_11650)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _26S_FILE_NO_11650);
    _1 = *(int *)_2;
    *(int *)_2 = _26current_file_no_11982;
    DeRef(_1);
    _29896 = NOVALUE;
L14: 

    /** 		SymTab[sym][S_SCOPE] = scope*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58961 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = _scope_58954;
    DeRef(_1);
    _29898 = NOVALUE;

    /** 		if type_ptr = 0 then*/
    if (_type_ptr_58953 != 0)
    goto L15; // [761] 1096

    /** 			SymTab[sym][S_MODE] = M_CONSTANT*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58961 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = 2;
    DeRef(_1);
    _29901 = NOVALUE;

    /** 			buckets[SymTab[sym][S_HASHVAL]] = SymTab[sym][S_SAMEHASH]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _29903 = (int)*(((s1_ptr)_2)->base + _sym_58961);
    _2 = (int)SEQ_PTR(_29903);
    _29904 = (int)*(((s1_ptr)_2)->base + 11);
    _29903 = NOVALUE;
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _29905 = (int)*(((s1_ptr)_2)->base + _sym_58961);
    _2 = (int)SEQ_PTR(_29905);
    _29906 = (int)*(((s1_ptr)_2)->base + 9);
    _29905 = NOVALUE;
    Ref(_29906);
    _2 = (int)SEQ_PTR(_52buckets_46126);
    if (!IS_ATOM_INT(_29904))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_29904)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _29904);
    _1 = *(int *)_2;
    *(int *)_2 = _29906;
    if( _1 != _29906 ){
        DeRef(_1);
    }
    _29906 = NOVALUE;

    /** 			tok_match(EQUALS)*/
    _30tok_match(3, 0);

    /** 			StartSourceLine(FALSE, , COVERAGE_OVERRIDE)*/
    _37StartSourceLine(_9FALSE_428, 0, 3);

    /** 			emit_opnd(sym)*/
    _37emit_opnd(_sym_58961);

    /** 			Expr()  -- no new symbols can be defined in here*/
    _30Expr();

    /** 			buckets[SymTab[sym][S_HASHVAL]] = sym*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _29907 = (int)*(((s1_ptr)_2)->base + _sym_58961);
    _2 = (int)SEQ_PTR(_29907);
    _29908 = (int)*(((s1_ptr)_2)->base + 11);
    _29907 = NOVALUE;
    _2 = (int)SEQ_PTR(_52buckets_46126);
    if (!IS_ATOM_INT(_29908))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_29908)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _29908);
    _1 = *(int *)_2;
    *(int *)_2 = _sym_58961;
    DeRef(_1);

    /** 			SymTab[sym][S_USAGE] = U_WRITTEN*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58961 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = 2;
    DeRef(_1);
    _29909 = NOVALUE;

    /** 			if TRANSLATE then*/
    if (_26TRANSLATE_11619 == 0)
    {
        goto L16; // [883] 921
    }
    else{
    }

    /** 				SymTab[sym][S_GTYPE] = TYPE_OBJECT*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58961 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 36);
    _1 = *(int *)_2;
    *(int *)_2 = 16;
    DeRef(_1);
    _29911 = NOVALUE;

    /** 				SymTab[sym][S_OBJ] = NOVALUE     -- distinguish from literals*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58961 + ((s1_ptr)_2)->base);
    Ref(_26NOVALUE_11836);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _26NOVALUE_11836;
    DeRef(_1);
    _29913 = NOVALUE;
L16: 

    /** 			valsym = Top()*/
    _valsym_58962 = _37Top();
    if (!IS_ATOM_INT(_valsym_58962)) {
        _1 = (long)(DBL_PTR(_valsym_58962)->dbl);
        DeRefDS(_valsym_58962);
        _valsym_58962 = _1;
    }

    /** 			if valsym > 0 and compare( SymTab[valsym][S_OBJ], NOVALUE ) then*/
    _29916 = (_valsym_58962 > 0);
    if (_29916 == 0) {
        goto L17; // [934] 975
    }
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _29918 = (int)*(((s1_ptr)_2)->base + _valsym_58962);
    _2 = (int)SEQ_PTR(_29918);
    _29919 = (int)*(((s1_ptr)_2)->base + 1);
    _29918 = NOVALUE;
    if (IS_ATOM_INT(_29919) && IS_ATOM_INT(_26NOVALUE_11836)){
        _29920 = (_29919 < _26NOVALUE_11836) ? -1 : (_29919 > _26NOVALUE_11836);
    }
    else{
        _29920 = compare(_29919, _26NOVALUE_11836);
    }
    _29919 = NOVALUE;
    if (_29920 == 0)
    {
        _29920 = NOVALUE;
        goto L17; // [957] 975
    }
    else{
        _29920 = NOVALUE;
    }

    /** 				Assign_Constant( sym )*/
    _30Assign_Constant(_sym_58961);

    /** 				sym = Pop()*/
    _sym_58961 = _37Pop();
    if (!IS_ATOM_INT(_sym_58961)) {
        _1 = (long)(DBL_PTR(_sym_58961)->dbl);
        DeRefDS(_sym_58961);
        _sym_58961 = _1;
    }
    goto L18; // [972] 2248
L17: 

    /** 				emit_op(ASSIGN)*/
    _37emit_op(18);

    /** 				if Last_op() = ASSIGN then*/
    _29922 = _37Last_op();
    if (binary_op_a(NOTEQ, _29922, 18)){
        DeRef(_29922);
        _29922 = NOVALUE;
        goto L19; // [989] 1003
    }
    DeRef(_29922);
    _29922 = NOVALUE;

    /** 					valsym = get_assigned_sym()*/
    _valsym_58962 = _30get_assigned_sym();
    if (!IS_ATOM_INT(_valsym_58962)) {
        _1 = (long)(DBL_PTR(_valsym_58962)->dbl);
        DeRefDS(_valsym_58962);
        _valsym_58962 = _1;
    }
    goto L1A; // [1000] 1011
L19: 

    /** 					valsym = -1*/
    _valsym_58962 = -1;
L1A: 

    /** 				if valsym > 0 and compare( SymTab[valsym][S_OBJ], NOVALUE ) then*/
    _29925 = (_valsym_58962 > 0);
    if (_29925 == 0) {
        goto L1B; // [1017] 1059
    }
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _29927 = (int)*(((s1_ptr)_2)->base + _valsym_58962);
    _2 = (int)SEQ_PTR(_29927);
    _29928 = (int)*(((s1_ptr)_2)->base + 1);
    _29927 = NOVALUE;
    if (IS_ATOM_INT(_29928) && IS_ATOM_INT(_26NOVALUE_11836)){
        _29929 = (_29928 < _26NOVALUE_11836) ? -1 : (_29928 > _26NOVALUE_11836);
    }
    else{
        _29929 = compare(_29928, _26NOVALUE_11836);
    }
    _29928 = NOVALUE;
    if (_29929 == 0)
    {
        _29929 = NOVALUE;
        goto L1B; // [1040] 1059
    }
    else{
        _29929 = NOVALUE;
    }

    /** 					SymTab[sym][S_CODE] = valsym*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58961 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_26S_CODE_11666))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_CODE_11666)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _26S_CODE_11666);
    _1 = *(int *)_2;
    *(int *)_2 = _valsym_58962;
    DeRef(_1);
    _29930 = NOVALUE;
L1B: 

    /** 				if TRANSLATE then*/
    if (_26TRANSLATE_11619 == 0)
    {
        goto L18; // [1063] 2248
    }
    else{
    }

    /** 					count += 1*/
    _count_58964 = _count_58964 + 1;

    /** 					if count = 10 then*/
    if (_count_58964 != 10)
    goto L18; // [1074] 2248

    /** 						count = 0*/
    _count_58964 = 0;

    /** 						emit_op( RETURNT )*/
    _37emit_op(34);
    goto L18; // [1093] 2248
L15: 

    /** 		elsif type_ptr = -1 and not is_fwd_ref then*/
    _29934 = (_type_ptr_58953 == -1);
    if (_29934 == 0) {
        goto L1C; // [1102] 2075
    }
    _29936 = (_is_fwd_ref_58969 == 0);
    if (_29936 == 0)
    {
        DeRef(_29936);
        _29936 = NOVALUE;
        goto L1C; // [1110] 2075
    }
    else{
        DeRef(_29936);
        _29936 = NOVALUE;
    }

    /** 			StartSourceLine(FALSE, , COVERAGE_OVERRIDE )*/
    _37StartSourceLine(_9FALSE_428, 0, 3);

    /** 			SymTab[sym][S_MODE] = M_CONSTANT*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58961 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = 2;
    DeRef(_1);
    _29937 = NOVALUE;

    /** 			buckets[SymTab[sym][S_HASHVAL]] = SymTab[sym][S_SAMEHASH]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _29939 = (int)*(((s1_ptr)_2)->base + _sym_58961);
    _2 = (int)SEQ_PTR(_29939);
    _29940 = (int)*(((s1_ptr)_2)->base + 11);
    _29939 = NOVALUE;
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _29941 = (int)*(((s1_ptr)_2)->base + _sym_58961);
    _2 = (int)SEQ_PTR(_29941);
    _29942 = (int)*(((s1_ptr)_2)->base + 9);
    _29941 = NOVALUE;
    Ref(_29942);
    _2 = (int)SEQ_PTR(_52buckets_46126);
    if (!IS_ATOM_INT(_29940))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_29940)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _29940);
    _1 = *(int *)_2;
    *(int *)_2 = _29942;
    if( _1 != _29942 ){
        DeRef(_1);
    }
    _29942 = NOVALUE;

    /** 			tok = next_token()*/
    _0 = _tok_58957;
    _tok_58957 = _30next_token();
    DeRef(_0);

    /** 			emit_opnd(sym)*/
    _37emit_opnd(_sym_58961);

    /** 			if tok[T_ID] = EQUALS then*/
    _2 = (int)SEQ_PTR(_tok_58957);
    _29944 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29944, 3)){
        _29944 = NOVALUE;
        goto L1D; // [1193] 1588
    }
    _29944 = NOVALUE;

    /** 				integer negate = 1*/
    _negate_59248 = 1;

    /** 				tok = next_token()*/
    _0 = _tok_58957;
    _tok_58957 = _30next_token();
    DeRef(_0);

    /** 				if tok[T_ID] = MINUS then*/
    _2 = (int)SEQ_PTR(_tok_58957);
    _29947 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29947, 10)){
        _29947 = NOVALUE;
        goto L1E; // [1217] 1232
    }
    _29947 = NOVALUE;

    /** 					negate = -1*/
    _negate_59248 = -1;

    /** 					tok = next_token()*/
    _0 = _tok_58957;
    _tok_58957 = _30next_token();
    DeRef(_0);
L1E: 

    /** 				if tok[T_ID] = ATOM then*/
    _2 = (int)SEQ_PTR(_tok_58957);
    _29950 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29950, 502)){
        _29950 = NOVALUE;
        goto L1F; // [1242] 1259
    }
    _29950 = NOVALUE;

    /** 					valsym = tok[T_SYM]*/
    _2 = (int)SEQ_PTR(_tok_58957);
    _valsym_58962 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_valsym_58962)){
        _valsym_58962 = (long)DBL_PTR(_valsym_58962)->dbl;
    }
    goto L20; // [1256] 1448
L1F: 

    /** 				elsif tok[T_SYM] > 0 then*/
    _2 = (int)SEQ_PTR(_tok_58957);
    _29953 = (int)*(((s1_ptr)_2)->base + 2);
    if (binary_op_a(LESSEQ, _29953, 0)){
        _29953 = NOVALUE;
        goto L21; // [1267] 1440
    }
    _29953 = NOVALUE;

    /** 					tsym = SymTab[tok[T_SYM]]*/
    _2 = (int)SEQ_PTR(_tok_58957);
    _29955 = (int)*(((s1_ptr)_2)->base + 2);
    DeRef(_tsym_58958);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!IS_ATOM_INT(_29955)){
        _tsym_58958 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_29955)->dbl));
    }
    else{
        _tsym_58958 = (int)*(((s1_ptr)_2)->base + _29955);
    }
    Ref(_tsym_58958);

    /** 					if tsym[S_MODE] = M_CONSTANT then*/
    _2 = (int)SEQ_PTR(_tsym_58958);
    _29957 = (int)*(((s1_ptr)_2)->base + 3);
    if (binary_op_a(NOTEQ, _29957, 2)){
        _29957 = NOVALUE;
        goto L22; // [1295] 1403
    }
    _29957 = NOVALUE;

    /** 						if length(tsym) >= S_CODE and tsym[S_CODE] then*/
    if (IS_SEQUENCE(_tsym_58958)){
            _29959 = SEQ_PTR(_tsym_58958)->length;
    }
    else {
        _29959 = 1;
    }
    if (IS_ATOM_INT(_26S_CODE_11666)) {
        _29960 = (_29959 >= _26S_CODE_11666);
    }
    else {
        _29960 = binary_op(GREATEREQ, _29959, _26S_CODE_11666);
    }
    _29959 = NOVALUE;
    if (IS_ATOM_INT(_29960)) {
        if (_29960 == 0) {
            goto L23; // [1310] 1337
        }
    }
    else {
        if (DBL_PTR(_29960)->dbl == 0.0) {
            goto L23; // [1310] 1337
        }
    }
    _2 = (int)SEQ_PTR(_tsym_58958);
    if (!IS_ATOM_INT(_26S_CODE_11666)){
        _29962 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_CODE_11666)->dbl));
    }
    else{
        _29962 = (int)*(((s1_ptr)_2)->base + _26S_CODE_11666);
    }
    if (_29962 == 0) {
        _29962 = NOVALUE;
        goto L23; // [1321] 1337
    }
    else {
        if (!IS_ATOM_INT(_29962) && DBL_PTR(_29962)->dbl == 0.0){
            _29962 = NOVALUE;
            goto L23; // [1321] 1337
        }
        _29962 = NOVALUE;
    }
    _29962 = NOVALUE;

    /** 							valsym = tsym[S_CODE]*/
    _2 = (int)SEQ_PTR(_tsym_58958);
    if (!IS_ATOM_INT(_26S_CODE_11666)){
        _valsym_58962 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_CODE_11666)->dbl));
    }
    else{
        _valsym_58962 = (int)*(((s1_ptr)_2)->base + _26S_CODE_11666);
    }
    if (!IS_ATOM_INT(_valsym_58962)){
        _valsym_58962 = (long)DBL_PTR(_valsym_58962)->dbl;
    }
    goto L20; // [1334] 1448
L23: 

    /** 						elsif not equal( tsym[S_OBJ], NOVALUE ) then*/
    _2 = (int)SEQ_PTR(_tsym_58958);
    _29964 = (int)*(((s1_ptr)_2)->base + 1);
    if (_29964 == _26NOVALUE_11836)
    _29965 = 1;
    else if (IS_ATOM_INT(_29964) && IS_ATOM_INT(_26NOVALUE_11836))
    _29965 = 0;
    else
    _29965 = (compare(_29964, _26NOVALUE_11836) == 0);
    _29964 = NOVALUE;
    if (_29965 != 0)
    goto L24; // [1351] 1392
    _29965 = NOVALUE;

    /** 							if integer(tsym[S_OBJ]) then*/
    _2 = (int)SEQ_PTR(_tsym_58958);
    _29967 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_29967))
    _29968 = 1;
    else if (IS_ATOM_DBL(_29967))
    _29968 = IS_ATOM_INT(DoubleToInt(_29967));
    else
    _29968 = 0;
    _29967 = NOVALUE;
    if (_29968 == 0)
    {
        _29968 = NOVALUE;
        goto L25; // [1365] 1381
    }
    else{
        _29968 = NOVALUE;
    }

    /** 								valsym = tok[T_SYM]*/
    _2 = (int)SEQ_PTR(_tok_58957);
    _valsym_58962 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_valsym_58962)){
        _valsym_58962 = (long)DBL_PTR(_valsym_58962)->dbl;
    }
    goto L20; // [1378] 1448
L25: 

    /** 								CompileErr(30)*/
    RefDS(_22037);
    _43CompileErr(30, _22037, 0);
    goto L20; // [1389] 1448
L24: 

    /** 							CompileErr(70)*/
    RefDS(_22037);
    _43CompileErr(70, _22037, 0);
    goto L20; // [1400] 1448
L22: 

    /** 					elsif tsym[S_OBJ] = NOVALUE then*/
    _2 = (int)SEQ_PTR(_tsym_58958);
    _29970 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29970, _26NOVALUE_11836)){
        _29970 = NOVALUE;
        goto L26; // [1413] 1429
    }
    _29970 = NOVALUE;

    /** 						CompileErr(ENUM_FWD_REFERENCES_NOT_SUPPORTED)*/
    RefDS(_22037);
    _43CompileErr(331, _22037, 0);
    goto L20; // [1426] 1448
L26: 

    /** 						CompileErr(99)*/
    RefDS(_22037);
    _43CompileErr(99, _22037, 0);
    goto L20; // [1437] 1448
L21: 

    /** 						CompileErr(99)*/
    RefDS(_22037);
    _43CompileErr(99, _22037, 0);
L20: 

    /** 				valsym = tok[T_SYM]*/
    _2 = (int)SEQ_PTR(_tok_58957);
    _valsym_58962 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_valsym_58962)){
        _valsym_58962 = (long)DBL_PTR(_valsym_58962)->dbl;
    }

    /** 				if not atom( SymTab[valsym][S_OBJ] ) and tsym[S_SCOPE] != SC_UNDEFINED then*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _29973 = (int)*(((s1_ptr)_2)->base + _valsym_58962);
    _2 = (int)SEQ_PTR(_29973);
    _29974 = (int)*(((s1_ptr)_2)->base + 1);
    _29973 = NOVALUE;
    _29975 = IS_ATOM(_29974);
    _29974 = NOVALUE;
    _29976 = (_29975 == 0);
    _29975 = NOVALUE;
    if (_29976 == 0) {
        goto L27; // [1478] 1508
    }
    _2 = (int)SEQ_PTR(_tsym_58958);
    _29978 = (int)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_29978)) {
        _29979 = (_29978 != 9);
    }
    else {
        _29979 = binary_op(NOTEQ, _29978, 9);
    }
    _29978 = NOVALUE;
    if (_29979 == 0) {
        DeRef(_29979);
        _29979 = NOVALUE;
        goto L27; // [1497] 1508
    }
    else {
        if (!IS_ATOM_INT(_29979) && DBL_PTR(_29979)->dbl == 0.0){
            DeRef(_29979);
            _29979 = NOVALUE;
            goto L27; // [1497] 1508
        }
        DeRef(_29979);
        _29979 = NOVALUE;
    }
    DeRef(_29979);
    _29979 = NOVALUE;

    /** 					CompileErr(84)*/
    RefDS(_22037);
    _43CompileErr(84, _22037, 0);
L27: 

    /** 				val = SymTab[valsym][S_OBJ] * negate*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _29980 = (int)*(((s1_ptr)_2)->base + _valsym_58962);
    _2 = (int)SEQ_PTR(_29980);
    _29981 = (int)*(((s1_ptr)_2)->base + 1);
    _29980 = NOVALUE;
    DeRef(_val_58965);
    if (IS_ATOM_INT(_29981)) {
        if (_29981 == (short)_29981 && _negate_59248 <= INT15 && _negate_59248 >= -INT15)
        _val_58965 = _29981 * _negate_59248;
        else
        _val_58965 = NewDouble(_29981 * (double)_negate_59248);
    }
    else {
        _val_58965 = binary_op(MULTIPLY, _29981, _negate_59248);
    }
    _29981 = NOVALUE;

    /** 				if integer(val) then*/
    if (IS_ATOM_INT(_val_58965))
    _29983 = 1;
    else if (IS_ATOM_DBL(_val_58965))
    _29983 = IS_ATOM_INT(DoubleToInt(_val_58965));
    else
    _29983 = 0;
    if (_29983 == 0)
    {
        _29983 = NOVALUE;
        goto L28; // [1531] 1546
    }
    else{
        _29983 = NOVALUE;
    }

    /** 					Push(NewIntSym(val))*/
    Ref(_val_58965);
    _29984 = _52NewIntSym(_val_58965);
    _37Push(_29984);
    _29984 = NOVALUE;
    goto L29; // [1543] 1556
L28: 

    /** 					Push(NewDoubleSym(val))*/
    Ref(_val_58965);
    _29985 = _52NewDoubleSym(_val_58965);
    _37Push(_29985);
    _29985 = NOVALUE;
L29: 

    /** 				usedval = val*/
    Ref(_val_58965);
    DeRef(_usedval_58966);
    _usedval_58966 = _val_58965;

    /** 				if deltafunc = '+' then*/
    if (_deltafunc_58967 != 43)
    goto L2A; // [1563] 1576

    /** 					val += delta*/
    _0 = _val_58965;
    if (IS_ATOM_INT(_val_58965) && IS_ATOM_INT(_delta_58968)) {
        _val_58965 = _val_58965 + _delta_58968;
        if ((long)((unsigned long)_val_58965 + (unsigned long)HIGH_BITS) >= 0) 
        _val_58965 = NewDouble((double)_val_58965);
    }
    else {
        if (IS_ATOM_INT(_val_58965)) {
            _val_58965 = NewDouble((double)_val_58965 + DBL_PTR(_delta_58968)->dbl);
        }
        else {
            if (IS_ATOM_INT(_delta_58968)) {
                _val_58965 = NewDouble(DBL_PTR(_val_58965)->dbl + (double)_delta_58968);
            }
            else
            _val_58965 = NewDouble(DBL_PTR(_val_58965)->dbl + DBL_PTR(_delta_58968)->dbl);
        }
    }
    DeRef(_0);
    goto L2B; // [1573] 1583
L2A: 

    /** 					val *= delta*/
    _0 = _val_58965;
    if (IS_ATOM_INT(_val_58965) && IS_ATOM_INT(_delta_58968)) {
        if (_val_58965 == (short)_val_58965 && _delta_58968 <= INT15 && _delta_58968 >= -INT15)
        _val_58965 = _val_58965 * _delta_58968;
        else
        _val_58965 = NewDouble(_val_58965 * (double)_delta_58968);
    }
    else {
        if (IS_ATOM_INT(_val_58965)) {
            _val_58965 = NewDouble((double)_val_58965 * DBL_PTR(_delta_58968)->dbl);
        }
        else {
            if (IS_ATOM_INT(_delta_58968)) {
                _val_58965 = NewDouble(DBL_PTR(_val_58965)->dbl * (double)_delta_58968);
            }
            else
            _val_58965 = NewDouble(DBL_PTR(_val_58965)->dbl * DBL_PTR(_delta_58968)->dbl);
        }
    }
    DeRef(_0);
L2B: 
    goto L2C; // [1585] 1658
L1D: 

    /** 				putback(tok)*/
    Ref(_tok_58957);
    _30putback(_tok_58957);

    /** 				if integer(val) then*/
    if (IS_ATOM_INT(_val_58965))
    _29989 = 1;
    else if (IS_ATOM_DBL(_val_58965))
    _29989 = IS_ATOM_INT(DoubleToInt(_val_58965));
    else
    _29989 = 0;
    if (_29989 == 0)
    {
        _29989 = NOVALUE;
        goto L2D; // [1598] 1613
    }
    else{
        _29989 = NOVALUE;
    }

    /** 					Push(NewIntSym(val))*/
    Ref(_val_58965);
    _29990 = _52NewIntSym(_val_58965);
    _37Push(_29990);
    _29990 = NOVALUE;
    goto L2E; // [1610] 1623
L2D: 

    /** 					Push(NewDoubleSym(val))*/
    Ref(_val_58965);
    _29991 = _52NewDoubleSym(_val_58965);
    _37Push(_29991);
    _29991 = NOVALUE;
L2E: 

    /** 				usedval = val*/
    Ref(_val_58965);
    DeRef(_usedval_58966);
    _usedval_58966 = _val_58965;

    /** 				if deltafunc = '+' then*/
    if (_deltafunc_58967 != 43)
    goto L2F; // [1630] 1643

    /** 					val += delta*/
    _0 = _val_58965;
    if (IS_ATOM_INT(_val_58965) && IS_ATOM_INT(_delta_58968)) {
        _val_58965 = _val_58965 + _delta_58968;
        if ((long)((unsigned long)_val_58965 + (unsigned long)HIGH_BITS) >= 0) 
        _val_58965 = NewDouble((double)_val_58965);
    }
    else {
        if (IS_ATOM_INT(_val_58965)) {
            _val_58965 = NewDouble((double)_val_58965 + DBL_PTR(_delta_58968)->dbl);
        }
        else {
            if (IS_ATOM_INT(_delta_58968)) {
                _val_58965 = NewDouble(DBL_PTR(_val_58965)->dbl + (double)_delta_58968);
            }
            else
            _val_58965 = NewDouble(DBL_PTR(_val_58965)->dbl + DBL_PTR(_delta_58968)->dbl);
        }
    }
    DeRef(_0);
    goto L30; // [1640] 1650
L2F: 

    /** 					val *= delta*/
    _0 = _val_58965;
    if (IS_ATOM_INT(_val_58965) && IS_ATOM_INT(_delta_58968)) {
        if (_val_58965 == (short)_val_58965 && _delta_58968 <= INT15 && _delta_58968 >= -INT15)
        _val_58965 = _val_58965 * _delta_58968;
        else
        _val_58965 = NewDouble(_val_58965 * (double)_delta_58968);
    }
    else {
        if (IS_ATOM_INT(_val_58965)) {
            _val_58965 = NewDouble((double)_val_58965 * DBL_PTR(_delta_58968)->dbl);
        }
        else {
            if (IS_ATOM_INT(_delta_58968)) {
                _val_58965 = NewDouble(DBL_PTR(_val_58965)->dbl * (double)_delta_58968);
            }
            else
            _val_58965 = NewDouble(DBL_PTR(_val_58965)->dbl * DBL_PTR(_delta_58968)->dbl);
        }
    }
    DeRef(_0);
L30: 

    /** 				valsym = 0*/
    _valsym_58962 = 0;
L2C: 

    /** 			buckets[SymTab[sym][S_HASHVAL]] = sym*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _29995 = (int)*(((s1_ptr)_2)->base + _sym_58961);
    _2 = (int)SEQ_PTR(_29995);
    _29996 = (int)*(((s1_ptr)_2)->base + 11);
    _29995 = NOVALUE;
    _2 = (int)SEQ_PTR(_52buckets_46126);
    if (!IS_ATOM_INT(_29996))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_29996)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _29996);
    _1 = *(int *)_2;
    *(int *)_2 = _sym_58961;
    DeRef(_1);

    /** 			SymTab[sym][S_USAGE] = U_WRITTEN*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58961 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = 2;
    DeRef(_1);
    _29997 = NOVALUE;

    /** 			if TRANSLATE then*/
    if (_26TRANSLATE_11619 == 0)
    {
        goto L31; // [1699] 1737
    }
    else{
    }

    /** 				SymTab[sym][S_GTYPE] = TYPE_OBJECT*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58961 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 36);
    _1 = *(int *)_2;
    *(int *)_2 = 16;
    DeRef(_1);
    _29999 = NOVALUE;

    /** 				SymTab[sym][S_OBJ] = NOVALUE     -- distinguish from literals*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58961 + ((s1_ptr)_2)->base);
    Ref(_26NOVALUE_11836);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _26NOVALUE_11836;
    DeRef(_1);
    _30001 = NOVALUE;
L31: 

    /** 			if valsym < 0 then*/
    if (_valsym_58962 >= 0)
    goto L32; // [1739] 1744
L32: 

    /** 			if valsym and compare( SymTab[valsym][S_OBJ], NOVALUE ) then*/
    if (_valsym_58962 == 0) {
        goto L33; // [1746] 1926
    }
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _30005 = (int)*(((s1_ptr)_2)->base + _valsym_58962);
    _2 = (int)SEQ_PTR(_30005);
    _30006 = (int)*(((s1_ptr)_2)->base + 1);
    _30005 = NOVALUE;
    if (IS_ATOM_INT(_30006) && IS_ATOM_INT(_26NOVALUE_11836)){
        _30007 = (_30006 < _26NOVALUE_11836) ? -1 : (_30006 > _26NOVALUE_11836);
    }
    else{
        _30007 = compare(_30006, _26NOVALUE_11836);
    }
    _30006 = NOVALUE;
    if (_30007 == 0)
    {
        _30007 = NOVALUE;
        goto L33; // [1769] 1926
    }
    else{
        _30007 = NOVALUE;
    }

    /** 				SymTab[sym][S_CODE] = valsym*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58961 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_26S_CODE_11666))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_CODE_11666)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _26S_CODE_11666);
    _1 = *(int *)_2;
    *(int *)_2 = _valsym_58962;
    DeRef(_1);
    _30008 = NOVALUE;

    /** 				SymTab[sym][S_OBJ]  = usedval*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58961 + ((s1_ptr)_2)->base);
    Ref(_usedval_58966);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _usedval_58966;
    DeRef(_1);
    _30010 = NOVALUE;

    /** 				if TRANSLATE then*/
    if (_26TRANSLATE_11619 == 0)
    {
        goto L34; // [1808] 2058
    }
    else{
    }

    /** 					SymTab[sym][S_GTYPE] = SymTab[valsym][S_GTYPE]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58961 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _30014 = (int)*(((s1_ptr)_2)->base + _valsym_58962);
    _2 = (int)SEQ_PTR(_30014);
    _30015 = (int)*(((s1_ptr)_2)->base + 36);
    _30014 = NOVALUE;
    Ref(_30015);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 36);
    _1 = *(int *)_2;
    *(int *)_2 = _30015;
    if( _1 != _30015 ){
        DeRef(_1);
    }
    _30015 = NOVALUE;
    _30012 = NOVALUE;

    /** 					SymTab[sym][S_SEQ_ELEM] = SymTab[valsym][S_SEQ_ELEM]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58961 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _30018 = (int)*(((s1_ptr)_2)->base + _valsym_58962);
    _2 = (int)SEQ_PTR(_30018);
    _30019 = (int)*(((s1_ptr)_2)->base + 33);
    _30018 = NOVALUE;
    Ref(_30019);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 33);
    _1 = *(int *)_2;
    *(int *)_2 = _30019;
    if( _1 != _30019 ){
        DeRef(_1);
    }
    _30019 = NOVALUE;
    _30016 = NOVALUE;

    /** 					SymTab[sym][S_OBJ_MIN] = usedval*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58961 + ((s1_ptr)_2)->base);
    Ref(_usedval_58966);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 30);
    _1 = *(int *)_2;
    *(int *)_2 = _usedval_58966;
    DeRef(_1);
    _30020 = NOVALUE;

    /** 					SymTab[sym][S_OBJ_MAX] = usedval*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58961 + ((s1_ptr)_2)->base);
    Ref(_usedval_58966);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 31);
    _1 = *(int *)_2;
    *(int *)_2 = _usedval_58966;
    DeRef(_1);
    _30022 = NOVALUE;

    /** 					SymTab[sym][S_SEQ_LEN] = SymTab[valsym][S_SEQ_LEN]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58961 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _30026 = (int)*(((s1_ptr)_2)->base + _valsym_58962);
    _2 = (int)SEQ_PTR(_30026);
    _30027 = (int)*(((s1_ptr)_2)->base + 32);
    _30026 = NOVALUE;
    Ref(_30027);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 32);
    _1 = *(int *)_2;
    *(int *)_2 = _30027;
    if( _1 != _30027 ){
        DeRef(_1);
    }
    _30027 = NOVALUE;
    _30024 = NOVALUE;
    goto L34; // [1923] 2058
L33: 

    /** 				SymTab[sym][S_OBJ] = usedval*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58961 + ((s1_ptr)_2)->base);
    Ref(_usedval_58966);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _usedval_58966;
    DeRef(_1);
    _30028 = NOVALUE;

    /** 				if TRANSLATE then*/
    if (_26TRANSLATE_11619 == 0)
    {
        goto L35; // [1947] 2057
    }
    else{
    }

    /** 					if integer( usedval ) then*/
    if (IS_ATOM_INT(_usedval_58966))
    _30030 = 1;
    else if (IS_ATOM_DBL(_usedval_58966))
    _30030 = IS_ATOM_INT(DoubleToInt(_usedval_58966));
    else
    _30030 = 0;
    if (_30030 == 0)
    {
        _30030 = NOVALUE;
        goto L36; // [1955] 1978
    }
    else{
        _30030 = NOVALUE;
    }

    /** 						SymTab[sym][S_GTYPE] = TYPE_INTEGER*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58961 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 36);
    _1 = *(int *)_2;
    *(int *)_2 = 1;
    DeRef(_1);
    _30031 = NOVALUE;
    goto L37; // [1975] 1996
L36: 

    /** 						SymTab[sym][S_GTYPE] = TYPE_DOUBLE*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58961 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 36);
    _1 = *(int *)_2;
    *(int *)_2 = 2;
    DeRef(_1);
    _30033 = NOVALUE;
L37: 

    /** 					SymTab[sym][S_SEQ_ELEM] = 0*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58961 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 33);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _30035 = NOVALUE;

    /** 					SymTab[sym][S_OBJ_MIN] = usedval*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58961 + ((s1_ptr)_2)->base);
    Ref(_usedval_58966);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 30);
    _1 = *(int *)_2;
    *(int *)_2 = _usedval_58966;
    DeRef(_1);
    _30037 = NOVALUE;

    /** 					SymTab[sym][S_OBJ_MAX] = usedval*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58961 + ((s1_ptr)_2)->base);
    Ref(_usedval_58966);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 31);
    _1 = *(int *)_2;
    *(int *)_2 = _usedval_58966;
    DeRef(_1);
    _30039 = NOVALUE;

    /** 					SymTab[sym][S_SEQ_LEN] = 0 --SymTab[valsym][S_SEQ_LEN]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58961 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 32);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _30041 = NOVALUE;
L35: 
L34: 

    /** 			valsym = Pop()*/
    _valsym_58962 = _37Pop();
    if (!IS_ATOM_INT(_valsym_58962)) {
        _1 = (long)(DBL_PTR(_valsym_58962)->dbl);
        DeRefDS(_valsym_58962);
        _valsym_58962 = _1;
    }

    /** 			valsym = Pop()*/
    _valsym_58962 = _37Pop();
    if (!IS_ATOM_INT(_valsym_58962)) {
        _1 = (long)(DBL_PTR(_valsym_58962)->dbl);
        DeRefDS(_valsym_58962);
        _valsym_58962 = _1;
    }
    goto L18; // [2072] 2248
L1C: 

    /** 			SymTab[sym][S_MODE] = M_NORMAL*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58961 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = 1;
    DeRef(_1);
    _30045 = NOVALUE;

    /** 			if type_ptr > 0 and SymTab[type_ptr][S_TOKEN] = OBJECT then*/
    _30047 = (_type_ptr_58953 > 0);
    if (_30047 == 0) {
        goto L38; // [2098] 2144
    }
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _30049 = (int)*(((s1_ptr)_2)->base + _type_ptr_58953);
    _2 = (int)SEQ_PTR(_30049);
    if (!IS_ATOM_INT(_26S_TOKEN_11659)){
        _30050 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_TOKEN_11659)->dbl));
    }
    else{
        _30050 = (int)*(((s1_ptr)_2)->base + _26S_TOKEN_11659);
    }
    _30049 = NOVALUE;
    if (IS_ATOM_INT(_30050)) {
        _30051 = (_30050 == 415);
    }
    else {
        _30051 = binary_op(EQUALS, _30050, 415);
    }
    _30050 = NOVALUE;
    if (_30051 == 0) {
        DeRef(_30051);
        _30051 = NOVALUE;
        goto L38; // [2121] 2144
    }
    else {
        if (!IS_ATOM_INT(_30051) && DBL_PTR(_30051)->dbl == 0.0){
            DeRef(_30051);
            _30051 = NOVALUE;
            goto L38; // [2121] 2144
        }
        DeRef(_30051);
        _30051 = NOVALUE;
    }
    DeRef(_30051);
    _30051 = NOVALUE;

    /** 				SymTab[sym][S_VTYPE] = object_type*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58961 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 15);
    _1 = *(int *)_2;
    *(int *)_2 = _52object_type_46130;
    DeRef(_1);
    _30052 = NOVALUE;
    goto L39; // [2141] 2173
L38: 

    /** 				SymTab[sym][S_VTYPE] = type_ptr*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58961 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 15);
    _1 = *(int *)_2;
    *(int *)_2 = _type_ptr_58953;
    DeRef(_1);
    _30054 = NOVALUE;

    /** 				if type_ptr < 0 then*/
    if (_type_ptr_58953 >= 0)
    goto L3A; // [2161] 2172

    /** 					register_forward_type( sym, type_ptr )*/
    _29register_forward_type(_sym_58961, _type_ptr_58953);
L3A: 
L39: 

    /** 			if TRANSLATE then*/
    if (_26TRANSLATE_11619 == 0)
    {
        goto L3B; // [2177] 2200
    }
    else{
    }

    /** 				SymTab[sym][S_GTYPE] = CompileType(type_ptr)*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58961 + ((s1_ptr)_2)->base);
    _30059 = _30CompileType(_type_ptr_58953);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 36);
    _1 = *(int *)_2;
    *(int *)_2 = _30059;
    if( _1 != _30059 ){
        DeRef(_1);
    }
    _30059 = NOVALUE;
    _30057 = NOVALUE;
L3B: 

    /** 	   		tok = next_token()*/
    _0 = _tok_58957;
    _tok_58957 = _30next_token();
    DeRef(_0);

    /**    			putback(tok)*/
    Ref(_tok_58957);
    _30putback(_tok_58957);

    /** 	   		if tok[T_ID] = EQUALS then -- assign on declare*/
    _2 = (int)SEQ_PTR(_tok_58957);
    _30061 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30061, 3)){
        _30061 = NOVALUE;
        goto L3C; // [2220] 2247
    }
    _30061 = NOVALUE;

    /** 	   			StartSourceLine( FALSE, , COVERAGE_OVERRIDE )*/
    _37StartSourceLine(_9FALSE_428, 0, 3);

    /** 	   			Assignment({VARIABLE,sym})*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -100;
    ((int *)_2)[2] = _sym_58961;
    _30063 = MAKE_SEQ(_1);
    _30Assignment(_30063);
    _30063 = NOVALUE;
L3C: 
L18: 

    /** 		tok = next_token()*/
    _0 = _tok_58957;
    _tok_58957 = _30next_token();
    DeRef(_0);

    /** 		if tok[T_ID] != COMMA then*/
    _2 = (int)SEQ_PTR(_tok_58957);
    _30065 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _30065, -30)){
        _30065 = NOVALUE;
        goto L3D; // [2263] 2272
    }
    _30065 = NOVALUE;

    /** 			exit*/
    goto LD; // [2269] 2282
L3D: 

    /** 		prevtok = tok*/
    Ref(_tok_58957);
    DeRef(_prevtok_58959);
    _prevtok_58959 = _tok_58957;

    /** 	end while*/
    goto LC; // [2279] 437
LD: 

    /** 	putback(tok)*/
    Ref(_tok_58957);
    _30putback(_tok_58957);

    /** 	return new_symbols*/
    DeRef(_tok_58957);
    DeRef(_tsym_58958);
    DeRef(_prevtok_58959);
    DeRef(_val_58965);
    DeRef(_usedval_58966);
    DeRef(_delta_58968);
    DeRef(_29826);
    _29826 = NOVALUE;
    _29853 = NOVALUE;
    _29904 = NOVALUE;
    DeRef(_29891);
    _29891 = NOVALUE;
    _29908 = NOVALUE;
    DeRef(_29916);
    _29916 = NOVALUE;
    DeRef(_29925);
    _29925 = NOVALUE;
    DeRef(_29934);
    _29934 = NOVALUE;
    _29940 = NOVALUE;
    _29955 = NOVALUE;
    DeRef(_29960);
    _29960 = NOVALUE;
    DeRef(_29976);
    _29976 = NOVALUE;
    _29996 = NOVALUE;
    DeRef(_30047);
    _30047 = NOVALUE;
    return _new_symbols_58955;
    ;
}


void _30Private_declaration(int _type_sym_59530)
{
    int _tok_59532 = NOVALUE;
    int _sym_59534 = NOVALUE;
    int _31647 = NOVALUE;
    int _31646 = NOVALUE;
    int _31645 = NOVALUE;
    int _30091 = NOVALUE;
    int _30089 = NOVALUE;
    int _30087 = NOVALUE;
    int _30085 = NOVALUE;
    int _30083 = NOVALUE;
    int _30081 = NOVALUE;
    int _30079 = NOVALUE;
    int _30076 = NOVALUE;
    int _30074 = NOVALUE;
    int _30073 = NOVALUE;
    int _30070 = NOVALUE;
    int _30068 = NOVALUE;
    int _30067 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_type_sym_59530)) {
        _1 = (long)(DBL_PTR(_type_sym_59530)->dbl);
        DeRefDS(_type_sym_59530);
        _type_sym_59530 = _1;
    }

    /** 	if SymTab[type_sym][S_SCOPE] = SC_UNDEFINED then*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _30067 = (int)*(((s1_ptr)_2)->base + _type_sym_59530);
    _2 = (int)SEQ_PTR(_30067);
    _30068 = (int)*(((s1_ptr)_2)->base + 4);
    _30067 = NOVALUE;
    if (binary_op_a(NOTEQ, _30068, 9)){
        _30068 = NOVALUE;
        goto L1; // [19] 47
    }
    _30068 = NOVALUE;

    /** 		Hide( type_sym )*/
    _52Hide(_type_sym_59530);

    /** 		type_sym = -new_forward_reference( TYPE, type_sym )*/
    _31647 = 504;
    _30070 = _29new_forward_reference(504, _type_sym_59530, 504);
    _31647 = NOVALUE;
    if (IS_ATOM_INT(_30070)) {
        if ((unsigned long)_30070 == 0xC0000000)
        _type_sym_59530 = (int)NewDouble((double)-0xC0000000);
        else
        _type_sym_59530 = - _30070;
    }
    else {
        _type_sym_59530 = unary_op(UMINUS, _30070);
    }
    DeRef(_30070);
    _30070 = NOVALUE;
    if (!IS_ATOM_INT(_type_sym_59530)) {
        _1 = (long)(DBL_PTR(_type_sym_59530)->dbl);
        DeRefDS(_type_sym_59530);
        _type_sym_59530 = _1;
    }
L1: 

    /** 	while TRUE do*/
L2: 
    if (_9TRUE_430 == 0)
    {
        goto L3; // [54] 255
    }
    else{
    }

    /** 		tok = next_token()*/
    _0 = _tok_59532;
    _tok_59532 = _30next_token();
    DeRef(_0);

    /** 		if not find(tok[T_ID], ID_TOKS) then*/
    _2 = (int)SEQ_PTR(_tok_59532);
    _30073 = (int)*(((s1_ptr)_2)->base + 1);
    _30074 = find_from(_30073, _28ID_TOKS_11608, 1);
    _30073 = NOVALUE;
    if (_30074 != 0)
    goto L4; // [77] 88
    _30074 = NOVALUE;

    /** 			CompileErr(24)*/
    RefDS(_22037);
    _43CompileErr(24, _22037, 0);
L4: 

    /** 		sym = SetPrivateScope(tok[T_SYM], type_sym, param_num)*/
    _2 = (int)SEQ_PTR(_tok_59532);
    _30076 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_30076);
    _sym_59534 = _30SetPrivateScope(_30076, _type_sym_59530, _30param_num_54165);
    _30076 = NOVALUE;
    if (!IS_ATOM_INT(_sym_59534)) {
        _1 = (long)(DBL_PTR(_sym_59534)->dbl);
        DeRefDS(_sym_59534);
        _sym_59534 = _1;
    }

    /** 		param_num += 1*/
    _30param_num_54165 = _30param_num_54165 + 1;

    /** 		if TRANSLATE then*/
    if (_26TRANSLATE_11619 == 0)
    {
        goto L5; // [118] 141
    }
    else{
    }

    /** 			SymTab[sym][S_GTYPE] = CompileType(type_sym)*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_59534 + ((s1_ptr)_2)->base);
    _30081 = _30CompileType(_type_sym_59530);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 36);
    _1 = *(int *)_2;
    *(int *)_2 = _30081;
    if( _1 != _30081 ){
        DeRef(_1);
    }
    _30081 = NOVALUE;
    _30079 = NOVALUE;
L5: 

    /**    		tok = next_token()*/
    _0 = _tok_59532;
    _tok_59532 = _30next_token();
    DeRef(_0);

    /**    		if tok[T_ID] = EQUALS then -- assign on declare*/
    _2 = (int)SEQ_PTR(_tok_59532);
    _30083 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30083, 3)){
        _30083 = NOVALUE;
        goto L6; // [156] 231
    }
    _30083 = NOVALUE;

    /** 		    putback(tok)*/
    Ref(_tok_59532);
    _30putback(_tok_59532);

    /** 		    StartSourceLine( TRUE )*/
    _37StartSourceLine(_9TRUE_430, 0, 2);

    /** 		    Assignment({VARIABLE,sym})*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -100;
    ((int *)_2)[2] = _sym_59534;
    _30085 = MAKE_SEQ(_1);
    _30Assignment(_30085);
    _30085 = NOVALUE;

    /** 			tok = next_token()*/
    _0 = _tok_59532;
    _tok_59532 = _30next_token();
    DeRef(_0);

    /** 			if tok[T_ID]=IGNORED then*/
    _2 = (int)SEQ_PTR(_tok_59532);
    _30087 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30087, 509)){
        _30087 = NOVALUE;
        goto L7; // [200] 230
    }
    _30087 = NOVALUE;

    /** 				tok = keyfind(tok[T_SYM],-1)*/
    _2 = (int)SEQ_PTR(_tok_59532);
    _30089 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_30089);
    DeRef(_31645);
    _31645 = _30089;
    _31646 = _52hashfn(_31645);
    _31645 = NOVALUE;
    Ref(_30089);
    _0 = _tok_59532;
    _tok_59532 = _52keyfind(_30089, -1, _26current_file_no_11982, 0, _31646);
    DeRef(_0);
    _30089 = NOVALUE;
    _31646 = NOVALUE;
L7: 
L6: 

    /** 		if tok[T_ID] != COMMA then*/
    _2 = (int)SEQ_PTR(_tok_59532);
    _30091 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _30091, -30)){
        _30091 = NOVALUE;
        goto L2; // [241] 52
    }
    _30091 = NOVALUE;

    /** 			exit*/
    goto L3; // [247] 255

    /** 	end while*/
    goto L2; // [252] 52
L3: 

    /** 	putback(tok)*/
    Ref(_tok_59532);
    _30putback(_tok_59532);

    /** end procedure*/
    DeRef(_tok_59532);
    return;
    ;
}


void _30Procedure_call(int _tok_59596)
{
    int _n_59597 = NOVALUE;
    int _scope_59598 = NOVALUE;
    int _opcode_59599 = NOVALUE;
    int _temp_tok_59601 = NOVALUE;
    int _s_59603 = NOVALUE;
    int _sub_59604 = NOVALUE;
    int _30127 = NOVALUE;
    int _30122 = NOVALUE;
    int _30121 = NOVALUE;
    int _30120 = NOVALUE;
    int _30119 = NOVALUE;
    int _30118 = NOVALUE;
    int _30117 = NOVALUE;
    int _30116 = NOVALUE;
    int _30115 = NOVALUE;
    int _30114 = NOVALUE;
    int _30113 = NOVALUE;
    int _30112 = NOVALUE;
    int _30110 = NOVALUE;
    int _30109 = NOVALUE;
    int _30108 = NOVALUE;
    int _30107 = NOVALUE;
    int _30106 = NOVALUE;
    int _30105 = NOVALUE;
    int _30104 = NOVALUE;
    int _30102 = NOVALUE;
    int _30101 = NOVALUE;
    int _30100 = NOVALUE;
    int _30098 = NOVALUE;
    int _30096 = NOVALUE;
    int _30094 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	tok_match(LEFT_ROUND)*/
    _30tok_match(-26, 0);

    /** 	s = tok[T_SYM]*/
    _2 = (int)SEQ_PTR(_tok_59596);
    _s_59603 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_59603)){
        _s_59603 = (long)DBL_PTR(_s_59603)->dbl;
    }

    /** 	sub=s*/
    _sub_59604 = _s_59603;

    /** 	n = SymTab[s][S_NUM_ARGS]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _30094 = (int)*(((s1_ptr)_2)->base + _s_59603);
    _2 = (int)SEQ_PTR(_30094);
    if (!IS_ATOM_INT(_26S_NUM_ARGS_11705)){
        _n_59597 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NUM_ARGS_11705)->dbl));
    }
    else{
        _n_59597 = (int)*(((s1_ptr)_2)->base + _26S_NUM_ARGS_11705);
    }
    if (!IS_ATOM_INT(_n_59597)){
        _n_59597 = (long)DBL_PTR(_n_59597)->dbl;
    }
    _30094 = NOVALUE;

    /** 	scope = SymTab[s][S_SCOPE]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _30096 = (int)*(((s1_ptr)_2)->base + _s_59603);
    _2 = (int)SEQ_PTR(_30096);
    _scope_59598 = (int)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_scope_59598)){
        _scope_59598 = (long)DBL_PTR(_scope_59598)->dbl;
    }
    _30096 = NOVALUE;

    /** 	opcode = SymTab[s][S_OPCODE]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _30098 = (int)*(((s1_ptr)_2)->base + _s_59603);
    _2 = (int)SEQ_PTR(_30098);
    _opcode_59599 = (int)*(((s1_ptr)_2)->base + 21);
    if (!IS_ATOM_INT(_opcode_59599)){
        _opcode_59599 = (long)DBL_PTR(_opcode_59599)->dbl;
    }
    _30098 = NOVALUE;

    /** 	if SymTab[s][S_EFFECT] then*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _30100 = (int)*(((s1_ptr)_2)->base + _s_59603);
    _2 = (int)SEQ_PTR(_30100);
    _30101 = (int)*(((s1_ptr)_2)->base + 23);
    _30100 = NOVALUE;
    if (_30101 == 0) {
        _30101 = NOVALUE;
        goto L1; // [88] 139
    }
    else {
        if (!IS_ATOM_INT(_30101) && DBL_PTR(_30101)->dbl == 0.0){
            _30101 = NOVALUE;
            goto L1; // [88] 139
        }
        _30101 = NOVALUE;
    }
    _30101 = NOVALUE;

    /** 		SymTab[CurrentSub][S_EFFECT] = or_bits(SymTab[CurrentSub][S_EFFECT],*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_26CurrentSub_11990 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _30104 = (int)*(((s1_ptr)_2)->base + _26CurrentSub_11990);
    _2 = (int)SEQ_PTR(_30104);
    _30105 = (int)*(((s1_ptr)_2)->base + 23);
    _30104 = NOVALUE;
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _30106 = (int)*(((s1_ptr)_2)->base + _s_59603);
    _2 = (int)SEQ_PTR(_30106);
    _30107 = (int)*(((s1_ptr)_2)->base + 23);
    _30106 = NOVALUE;
    if (IS_ATOM_INT(_30105) && IS_ATOM_INT(_30107)) {
        {unsigned long tu;
             tu = (unsigned long)_30105 | (unsigned long)_30107;
             _30108 = MAKE_UINT(tu);
        }
    }
    else {
        _30108 = binary_op(OR_BITS, _30105, _30107);
    }
    _30105 = NOVALUE;
    _30107 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 23);
    _1 = *(int *)_2;
    *(int *)_2 = _30108;
    if( _1 != _30108 ){
        DeRef(_1);
    }
    _30108 = NOVALUE;
    _30102 = NOVALUE;
L1: 

    /** 	ParseArgs(s)*/
    _30ParseArgs(_s_59603);

    /** 	for i=1 to n+1 do*/
    _30109 = _n_59597 + 1;
    if (_30109 > MAXINT){
        _30109 = NewDouble((double)_30109);
    }
    {
        int _i_59641;
        _i_59641 = 1;
L2: 
        if (binary_op_a(GREATER, _i_59641, _30109)){
            goto L3; // [150] 180
        }

        /** 		s = SymTab[s][S_NEXT]*/
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _30110 = (int)*(((s1_ptr)_2)->base + _s_59603);
        _2 = (int)SEQ_PTR(_30110);
        _s_59603 = (int)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_s_59603)){
            _s_59603 = (long)DBL_PTR(_s_59603)->dbl;
        }
        _30110 = NOVALUE;

        /** 	end for*/
        _0 = _i_59641;
        if (IS_ATOM_INT(_i_59641)) {
            _i_59641 = _i_59641 + 1;
            if ((long)((unsigned long)_i_59641 +(unsigned long) HIGH_BITS) >= 0){
                _i_59641 = NewDouble((double)_i_59641);
            }
        }
        else {
            _i_59641 = binary_op_a(PLUS, _i_59641, 1);
        }
        DeRef(_0);
        goto L2; // [175] 157
L3: 
        ;
        DeRef(_i_59641);
    }

    /** 	while s and SymTab[s][S_SCOPE]=SC_PRIVATE do*/
L4: 
    if (_s_59603 == 0) {
        goto L5; // [185] 281
    }
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _30113 = (int)*(((s1_ptr)_2)->base + _s_59603);
    _2 = (int)SEQ_PTR(_30113);
    _30114 = (int)*(((s1_ptr)_2)->base + 4);
    _30113 = NOVALUE;
    if (IS_ATOM_INT(_30114)) {
        _30115 = (_30114 == 3);
    }
    else {
        _30115 = binary_op(EQUALS, _30114, 3);
    }
    _30114 = NOVALUE;
    if (_30115 <= 0) {
        if (_30115 == 0) {
            DeRef(_30115);
            _30115 = NOVALUE;
            goto L5; // [208] 281
        }
        else {
            if (!IS_ATOM_INT(_30115) && DBL_PTR(_30115)->dbl == 0.0){
                DeRef(_30115);
                _30115 = NOVALUE;
                goto L5; // [208] 281
            }
            DeRef(_30115);
            _30115 = NOVALUE;
        }
    }
    DeRef(_30115);
    _30115 = NOVALUE;

    /** 		if sequence(SymTab[s][S_CODE]) then*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _30116 = (int)*(((s1_ptr)_2)->base + _s_59603);
    _2 = (int)SEQ_PTR(_30116);
    if (!IS_ATOM_INT(_26S_CODE_11666)){
        _30117 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_CODE_11666)->dbl));
    }
    else{
        _30117 = (int)*(((s1_ptr)_2)->base + _26S_CODE_11666);
    }
    _30116 = NOVALUE;
    _30118 = IS_SEQUENCE(_30117);
    _30117 = NOVALUE;
    if (_30118 == 0)
    {
        _30118 = NOVALUE;
        goto L6; // [228] 260
    }
    else{
        _30118 = NOVALUE;
    }

    /** 			start_playback(SymTab[s][S_CODE])*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _30119 = (int)*(((s1_ptr)_2)->base + _s_59603);
    _2 = (int)SEQ_PTR(_30119);
    if (!IS_ATOM_INT(_26S_CODE_11666)){
        _30120 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_CODE_11666)->dbl));
    }
    else{
        _30120 = (int)*(((s1_ptr)_2)->base + _26S_CODE_11666);
    }
    _30119 = NOVALUE;
    Ref(_30120);
    _30start_playback(_30120);
    _30120 = NOVALUE;

    /** 			Assignment({VARIABLE,s})*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -100;
    ((int *)_2)[2] = _s_59603;
    _30121 = MAKE_SEQ(_1);
    _30Assignment(_30121);
    _30121 = NOVALUE;
L6: 

    /** 		s = SymTab[s][S_NEXT]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _30122 = (int)*(((s1_ptr)_2)->base + _s_59603);
    _2 = (int)SEQ_PTR(_30122);
    _s_59603 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_59603)){
        _s_59603 = (long)DBL_PTR(_s_59603)->dbl;
    }
    _30122 = NOVALUE;

    /** 	end while*/
    goto L4; // [278] 185
L5: 

    /** 	s = sub*/
    _s_59603 = _sub_59604;

    /** 	if scope = SC_PREDEF then*/
    if (_scope_59598 != 7)
    goto L7; // [292] 335

    /** 		emit_op(opcode)*/
    _37emit_op(_opcode_59599);

    /** 		if opcode = ABORT then*/
    if (_opcode_59599 != 126)
    goto L8; // [305] 370

    /** 			temp_tok = next_token()*/
    _0 = _temp_tok_59601;
    _temp_tok_59601 = _30next_token();
    DeRef(_0);

    /** 			putback(temp_tok)*/
    Ref(_temp_tok_59601);
    _30putback(_temp_tok_59601);

    /** 			NotReached(temp_tok[T_ID], "abort()")*/
    _2 = (int)SEQ_PTR(_temp_tok_59601);
    _30127 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_30127);
    RefDS(_27987);
    _30NotReached(_30127, _27987);
    _30127 = NOVALUE;
    goto L8; // [332] 370
L7: 

    /** 		op_info1 = s*/
    _37op_info1_50262 = _s_59603;

    /** 		emit_or_inline()*/
    _66emit_or_inline();

    /** 		if not TRANSLATE then*/
    if (_26TRANSLATE_11619 != 0)
    goto L9; // [350] 369

    /** 			if OpTrace then*/
    if (_26OpTrace_12052 == 0)
    {
        goto LA; // [357] 368
    }
    else{
    }

    /** 				emit_op(UPDATE_GLOBALS)*/
    _37emit_op(89);
LA: 
L9: 
L8: 

    /** end procedure*/
    DeRef(_tok_59596);
    DeRef(_temp_tok_59601);
    DeRef(_30109);
    _30109 = NOVALUE;
    return;
    ;
}


void _30Print_statement()
{
    int _30134 = NOVALUE;
    int _30133 = NOVALUE;
    int _30132 = NOVALUE;
    int _30130 = NOVALUE;
    int _30129 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	emit_opnd(NewIntSym(1)) -- stdout*/
    _30129 = _52NewIntSym(1);
    _37emit_opnd(_30129);
    _30129 = NOVALUE;

    /** 	Expr()*/
    _30Expr();

    /** 	emit_op(QPRINT)*/
    _37emit_op(36);

    /** 	SymTab[CurrentSub][S_EFFECT] = or_bits(SymTab[CurrentSub][S_EFFECT],*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_26CurrentSub_11990 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _30132 = (int)*(((s1_ptr)_2)->base + _26CurrentSub_11990);
    _2 = (int)SEQ_PTR(_30132);
    _30133 = (int)*(((s1_ptr)_2)->base + 23);
    _30132 = NOVALUE;
    if (IS_ATOM_INT(_30133)) {
        {unsigned long tu;
             tu = (unsigned long)_30133 | (unsigned long)536870912;
             _30134 = MAKE_UINT(tu);
        }
    }
    else {
        _30134 = binary_op(OR_BITS, _30133, 536870912);
    }
    _30133 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 23);
    _1 = *(int *)_2;
    *(int *)_2 = _30134;
    if( _1 != _30134 ){
        DeRef(_1);
    }
    _30134 = NOVALUE;
    _30130 = NOVALUE;

    /** end procedure*/
    return;
    ;
}


void _30Entry_statement()
{
    int _addr_59712 = NOVALUE;
    int _30158 = NOVALUE;
    int _30157 = NOVALUE;
    int _30156 = NOVALUE;
    int _30155 = NOVALUE;
    int _30154 = NOVALUE;
    int _30153 = NOVALUE;
    int _30152 = NOVALUE;
    int _30151 = NOVALUE;
    int _30147 = NOVALUE;
    int _30145 = NOVALUE;
    int _30144 = NOVALUE;
    int _30143 = NOVALUE;
    int _30142 = NOVALUE;
    int _30140 = NOVALUE;
    int _30139 = NOVALUE;
    int _30138 = NOVALUE;
    int _30136 = NOVALUE;
    int _30135 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not length(loop_stack) or block_index=0 then*/
    if (IS_SEQUENCE(_30loop_stack_54190)){
            _30135 = SEQ_PTR(_30loop_stack_54190)->length;
    }
    else {
        _30135 = 1;
    }
    _30136 = (_30135 == 0);
    _30135 = NOVALUE;
    if (_30136 != 0) {
        goto L1; // [11] 26
    }
    _30138 = (_30block_index_54187 == 0);
    if (_30138 == 0)
    {
        DeRef(_30138);
        _30138 = NOVALUE;
        goto L2; // [22] 34
    }
    else{
        DeRef(_30138);
        _30138 = NOVALUE;
    }
L1: 

    /** 		CompileErr(144)*/
    RefDS(_22037);
    _43CompileErr(144, _22037, 0);
L2: 

    /** 	if block_list[block_index]=IF or block_list[block_index]=SWITCH then*/
    _2 = (int)SEQ_PTR(_30block_list_54186);
    _30139 = (int)*(((s1_ptr)_2)->base + _30block_index_54187);
    _30140 = (_30139 == 20);
    _30139 = NOVALUE;
    if (_30140 != 0) {
        goto L3; // [50] 73
    }
    _2 = (int)SEQ_PTR(_30block_list_54186);
    _30142 = (int)*(((s1_ptr)_2)->base + _30block_index_54187);
    _30143 = (_30142 == 185);
    _30142 = NOVALUE;
    if (_30143 == 0)
    {
        DeRef(_30143);
        _30143 = NOVALUE;
        goto L4; // [69] 83
    }
    else{
        DeRef(_30143);
        _30143 = NOVALUE;
    }
L3: 

    /** 		CompileErr(143)*/
    RefDS(_22037);
    _43CompileErr(143, _22037, 0);
    goto L5; // [80] 109
L4: 

    /** 	elsif loop_stack[$] = FOR then  -- not allowed in an innermost for loop*/
    if (IS_SEQUENCE(_30loop_stack_54190)){
            _30144 = SEQ_PTR(_30loop_stack_54190)->length;
    }
    else {
        _30144 = 1;
    }
    _2 = (int)SEQ_PTR(_30loop_stack_54190);
    _30145 = (int)*(((s1_ptr)_2)->base + _30144);
    if (_30145 != 21)
    goto L6; // [96] 108

    /** 		CompileErr(142)*/
    RefDS(_22037);
    _43CompileErr(142, _22037, 0);
L6: 
L5: 

    /** 	addr = entry_addr[$]*/
    if (IS_SEQUENCE(_30entry_addr_54180)){
            _30147 = SEQ_PTR(_30entry_addr_54180)->length;
    }
    else {
        _30147 = 1;
    }
    _2 = (int)SEQ_PTR(_30entry_addr_54180);
    _addr_59712 = (int)*(((s1_ptr)_2)->base + _30147);

    /** 	if addr=0  then*/
    if (_addr_59712 != 0)
    goto L7; // [122] 136

    /** 		CompileErr(141)*/
    RefDS(_22037);
    _43CompileErr(141, _22037, 0);
    goto L8; // [133] 151
L7: 

    /** 	elsif addr<0 then*/
    if (_addr_59712 >= 0)
    goto L9; // [138] 150

    /** 		CompileErr(73)*/
    RefDS(_22037);
    _43CompileErr(73, _22037, 0);
L9: 
L8: 

    /** 	backpatch(addr,ELSE)*/
    _37backpatch(_addr_59712, 23);

    /** 	backpatch(addr+1,length(Code)+1+(TRANSLATE>0))*/
    _30151 = _addr_59712 + 1;
    if (_30151 > MAXINT){
        _30151 = NewDouble((double)_30151);
    }
    if (IS_SEQUENCE(_26Code_12071)){
            _30152 = SEQ_PTR(_26Code_12071)->length;
    }
    else {
        _30152 = 1;
    }
    _30153 = _30152 + 1;
    _30152 = NOVALUE;
    _30154 = (_26TRANSLATE_11619 > 0);
    _30155 = _30153 + _30154;
    _30153 = NOVALUE;
    _30154 = NOVALUE;
    _37backpatch(_30151, _30155);
    _30151 = NOVALUE;
    _30155 = NOVALUE;

    /** 	entry_addr[$] = 0*/
    if (IS_SEQUENCE(_30entry_addr_54180)){
            _30156 = SEQ_PTR(_30entry_addr_54180)->length;
    }
    else {
        _30156 = 1;
    }
    _2 = (int)SEQ_PTR(_30entry_addr_54180);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _30entry_addr_54180 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _30156);
    *(int *)_2 = 0;

    /** 	if TRANSLATE then*/
    if (_26TRANSLATE_11619 == 0)
    {
        goto LA; // [203] 214
    }
    else{
    }

    /** 	    emit_op(NOP1)*/
    _37emit_op(159);
LA: 

    /** 	force_uninitialize( entry_stack[$] )*/
    if (IS_SEQUENCE(_30entry_stack_54183)){
            _30157 = SEQ_PTR(_30entry_stack_54183)->length;
    }
    else {
        _30157 = 1;
    }
    _2 = (int)SEQ_PTR(_30entry_stack_54183);
    _30158 = (int)*(((s1_ptr)_2)->base + _30157);
    Ref(_30158);
    _30force_uninitialize(_30158);
    _30158 = NOVALUE;

    /** end procedure*/
    DeRef(_30136);
    _30136 = NOVALUE;
    _30145 = NOVALUE;
    DeRef(_30140);
    _30140 = NOVALUE;
    return;
    ;
}


void _30force_uninitialize(int _uninitialized_59762)
{
    int _30161 = NOVALUE;
    int _30160 = NOVALUE;
    int _30159 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	for i = 1 to length( uninitialized ) do*/
    if (IS_SEQUENCE(_uninitialized_59762)){
            _30159 = SEQ_PTR(_uninitialized_59762)->length;
    }
    else {
        _30159 = 1;
    }
    {
        int _i_59764;
        _i_59764 = 1;
L1: 
        if (_i_59764 > _30159){
            goto L2; // [8] 41
        }

        /** 		SymTab[uninitialized[i]][S_INITLEVEL] = -1*/
        _2 = (int)SEQ_PTR(_uninitialized_59762);
        _30160 = (int)*(((s1_ptr)_2)->base + _i_59764);
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _27SymTab_10921 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_30160))
        _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_30160)->dbl));
        else
        _3 = (int)(_30160 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 14);
        _1 = *(int *)_2;
        *(int *)_2 = -1;
        DeRef(_1);
        _30161 = NOVALUE;

        /** 	end for*/
        _i_59764 = _i_59764 + 1;
        goto L1; // [36] 15
L2: 
        ;
    }

    /** end procedure*/
    DeRefDS(_uninitialized_59762);
    _30160 = NOVALUE;
    return;
    ;
}


void _30Statement_list()
{
    int _tok_59774 = NOVALUE;
    int _id_59775 = NOVALUE;
    int _forward_59798 = NOVALUE;
    int _test_59947 = NOVALUE;
    int _30233 = NOVALUE;
    int _30232 = NOVALUE;
    int _30229 = NOVALUE;
    int _30227 = NOVALUE;
    int _30226 = NOVALUE;
    int _30223 = NOVALUE;
    int _30221 = NOVALUE;
    int _30220 = NOVALUE;
    int _30219 = NOVALUE;
    int _30216 = NOVALUE;
    int _30214 = NOVALUE;
    int _30212 = NOVALUE;
    int _30210 = NOVALUE;
    int _30192 = NOVALUE;
    int _30191 = NOVALUE;
    int _30189 = NOVALUE;
    int _30187 = NOVALUE;
    int _30186 = NOVALUE;
    int _30184 = NOVALUE;
    int _30182 = NOVALUE;
    int _30181 = NOVALUE;
    int _30180 = NOVALUE;
    int _30179 = NOVALUE;
    int _30174 = NOVALUE;
    int _30171 = NOVALUE;
    int _30170 = NOVALUE;
    int _30169 = NOVALUE;
    int _30168 = NOVALUE;
    int _30166 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer id*/

    /** 	stmt_nest += 1*/
    _30stmt_nest_54188 = _30stmt_nest_54188 + 1;

    /** 	while TRUE do*/
L1: 
    if (_9TRUE_430 == 0)
    {
        goto L2; // [18] 1093
    }
    else{
    }

    /** 		tok = next_token()*/
    _0 = _tok_59774;
    _tok_59774 = _30next_token();
    DeRef(_0);

    /** 		id = tok[T_ID]*/
    _2 = (int)SEQ_PTR(_tok_59774);
    _id_59775 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_id_59775)){
        _id_59775 = (long)DBL_PTR(_id_59775)->dbl;
    }

    /** 		if id = VARIABLE or id = QUALIFIED_VARIABLE then*/
    _30166 = (_id_59775 == -100);
    if (_30166 != 0) {
        goto L3; // [44] 59
    }
    _30168 = (_id_59775 == 512);
    if (_30168 == 0)
    {
        DeRef(_30168);
        _30168 = NOVALUE;
        goto L4; // [55] 229
    }
    else{
        DeRef(_30168);
        _30168 = NOVALUE;
    }
L3: 

    /** 			if SymTab[tok[T_SYM]][S_SCOPE] = SC_UNDEFINED then*/
    _2 = (int)SEQ_PTR(_tok_59774);
    _30169 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!IS_ATOM_INT(_30169)){
        _30170 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_30169)->dbl));
    }
    else{
        _30170 = (int)*(((s1_ptr)_2)->base + _30169);
    }
    _2 = (int)SEQ_PTR(_30170);
    _30171 = (int)*(((s1_ptr)_2)->base + 4);
    _30170 = NOVALUE;
    if (binary_op_a(NOTEQ, _30171, 9)){
        _30171 = NOVALUE;
        goto L5; // [81] 210
    }
    _30171 = NOVALUE;

    /** 				token forward = next_token()*/
    _0 = _forward_59798;
    _forward_59798 = _30next_token();
    DeRef(_0);

    /** 				switch forward[T_ID] do*/
    _2 = (int)SEQ_PTR(_forward_59798);
    _30174 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_30174) ){
        goto L6; // [98] 204
    }
    if(!IS_ATOM_INT(_30174)){
        if( (DBL_PTR(_30174)->dbl != (double) ((int) DBL_PTR(_30174)->dbl) ) ){
            goto L6; // [98] 204
        }
        _0 = (int) DBL_PTR(_30174)->dbl;
    }
    else {
        _0 = _30174;
    };
    _30174 = NOVALUE;
    switch ( _0 ){ 

        /** 					case LEFT_ROUND then*/
        case -26:

        /** 						StartSourceLine( TRUE )*/
        _37StartSourceLine(_9TRUE_430, 0, 2);

        /** 						Forward_call( tok )*/
        Ref(_tok_59774);
        _30Forward_call(_tok_59774, 195);

        /** 						flush_temps()*/
        RefDS(_22037);
        _37flush_temps(_22037);

        /** 						continue*/
        DeRef(_forward_59798);
        _forward_59798 = NOVALUE;
        goto L1; // [133] 16
        goto L6; // [135] 204

        /** 					case VARIABLE then*/
        case -100:

        /** 						putback( forward )*/
        Ref(_forward_59798);
        _30putback(_forward_59798);

        /** 						if param_num != -1 then*/
        if (_30param_num_54165 == -1)
        goto L7; // [150] 176

        /** 							param_num += 1*/
        _30param_num_54165 = _30param_num_54165 + 1;

        /** 							Private_declaration( tok[T_SYM] )*/
        _2 = (int)SEQ_PTR(_tok_59774);
        _30179 = (int)*(((s1_ptr)_2)->base + 2);
        Ref(_30179);
        _30Private_declaration(_30179);
        _30179 = NOVALUE;
        goto L8; // [173] 192
L7: 

        /** 							Global_declaration( tok[T_SYM], SC_LOCAL )*/
        _2 = (int)SEQ_PTR(_tok_59774);
        _30180 = (int)*(((s1_ptr)_2)->base + 2);
        Ref(_30180);
        _30181 = _30Global_declaration(_30180, 5);
        _30180 = NOVALUE;
L8: 

        /** 						flush_temps()*/
        RefDS(_22037);
        _37flush_temps(_22037);

        /** 						continue*/
        DeRef(_forward_59798);
        _forward_59798 = NOVALUE;
        goto L1; // [201] 16
    ;}L6: 

    /** 				putback( forward )*/
    Ref(_forward_59798);
    _30putback(_forward_59798);
L5: 
    DeRef(_forward_59798);
    _forward_59798 = NOVALUE;

    /** 			StartSourceLine(TRUE)*/
    _37StartSourceLine(_9TRUE_430, 0, 2);

    /** 			Assignment(tok)*/
    Ref(_tok_59774);
    _30Assignment(_tok_59774);
    goto L9; // [226] 1083
L4: 

    /** 		elsif id = PROC or id = QUALIFIED_PROC then*/
    _30182 = (_id_59775 == 27);
    if (_30182 != 0) {
        goto LA; // [237] 252
    }
    _30184 = (_id_59775 == 521);
    if (_30184 == 0)
    {
        DeRef(_30184);
        _30184 = NOVALUE;
        goto LB; // [248] 289
    }
    else{
        DeRef(_30184);
        _30184 = NOVALUE;
    }
LA: 

    /** 			if id = PROC then*/
    if (_id_59775 != 27)
    goto LC; // [256] 272

    /** 				UndefinedVar( tok[T_SYM] )*/
    _2 = (int)SEQ_PTR(_tok_59774);
    _30186 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_30186);
    _30UndefinedVar(_30186);
    _30186 = NOVALUE;
LC: 

    /** 			StartSourceLine(TRUE)*/
    _37StartSourceLine(_9TRUE_430, 0, 2);

    /** 			Procedure_call(tok)*/
    Ref(_tok_59774);
    _30Procedure_call(_tok_59774);
    goto L9; // [286] 1083
LB: 

    /** 		elsif id = FUNC or id = QUALIFIED_FUNC then*/
    _30187 = (_id_59775 == 501);
    if (_30187 != 0) {
        goto LD; // [297] 312
    }
    _30189 = (_id_59775 == 520);
    if (_30189 == 0)
    {
        DeRef(_30189);
        _30189 = NOVALUE;
        goto LE; // [308] 362
    }
    else{
        DeRef(_30189);
        _30189 = NOVALUE;
    }
LD: 

    /** 			if id = FUNC then*/
    if (_id_59775 != 501)
    goto LF; // [316] 332

    /** 				UndefinedVar( tok[T_SYM] )*/
    _2 = (int)SEQ_PTR(_tok_59774);
    _30191 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_30191);
    _30UndefinedVar(_30191);
    _30191 = NOVALUE;
LF: 

    /** 			StartSourceLine(TRUE)*/
    _37StartSourceLine(_9TRUE_430, 0, 2);

    /** 			Procedure_call(tok)*/
    Ref(_tok_59774);
    _30Procedure_call(_tok_59774);

    /** 			clear_op()*/
    _37clear_op();

    /** 			if Pop() then end if*/
    _30192 = _37Pop();
    if (_30192 == 0) {
        DeRef(_30192);
        _30192 = NOVALUE;
        goto L9; // [355] 1083
    }
    else {
        if (!IS_ATOM_INT(_30192) && DBL_PTR(_30192)->dbl == 0.0){
            DeRef(_30192);
            _30192 = NOVALUE;
            goto L9; // [355] 1083
        }
        DeRef(_30192);
        _30192 = NOVALUE;
    }
    DeRef(_30192);
    _30192 = NOVALUE;
    goto L9; // [359] 1083
LE: 

    /** 		elsif id = IF then*/
    if (_id_59775 != 20)
    goto L10; // [366] 386

    /** 			StartSourceLine(TRUE)*/
    _37StartSourceLine(_9TRUE_430, 0, 2);

    /** 			If_statement()*/
    _30If_statement();
    goto L9; // [383] 1083
L10: 

    /** 		elsif id = FOR then*/
    if (_id_59775 != 21)
    goto L11; // [390] 410

    /** 			StartSourceLine(TRUE)*/
    _37StartSourceLine(_9TRUE_430, 0, 2);

    /** 			For_statement()*/
    _30For_statement();
    goto L9; // [407] 1083
L11: 

    /** 		elsif id = RETURN then*/
    if (_id_59775 != 413)
    goto L12; // [414] 434

    /** 			StartSourceLine(TRUE)*/
    _37StartSourceLine(_9TRUE_430, 0, 2);

    /** 			Return_statement()*/
    _30Return_statement();
    goto L9; // [431] 1083
L12: 

    /** 		elsif id = LABEL then*/
    if (_id_59775 != 419)
    goto L13; // [438] 460

    /** 			StartSourceLine(TRUE, , COVERAGE_SUPPRESS )*/
    _37StartSourceLine(_9TRUE_430, 0, 1);

    /** 			GLabel_statement()*/
    _30GLabel_statement();
    goto L9; // [457] 1083
L13: 

    /** 		elsif id = GOTO then*/
    if (_id_59775 != 188)
    goto L14; // [464] 484

    /** 			StartSourceLine(TRUE)*/
    _37StartSourceLine(_9TRUE_430, 0, 2);

    /** 			Goto_statement()*/
    _30Goto_statement();
    goto L9; // [481] 1083
L14: 

    /** 		elsif id = EXIT then*/
    if (_id_59775 != 61)
    goto L15; // [488] 508

    /** 			StartSourceLine(TRUE)*/
    _37StartSourceLine(_9TRUE_430, 0, 2);

    /** 			Exit_statement()*/
    _30Exit_statement();
    goto L9; // [505] 1083
L15: 

    /** 		elsif id = BREAK then*/
    if (_id_59775 != 425)
    goto L16; // [512] 532

    /** 			StartSourceLine(TRUE)*/
    _37StartSourceLine(_9TRUE_430, 0, 2);

    /** 			Break_statement()*/
    _30Break_statement();
    goto L9; // [529] 1083
L16: 

    /** 		elsif id = WHILE then*/
    if (_id_59775 != 47)
    goto L17; // [536] 556

    /** 			StartSourceLine(TRUE)*/
    _37StartSourceLine(_9TRUE_430, 0, 2);

    /** 			While_statement()*/
    _30While_statement();
    goto L9; // [553] 1083
L17: 

    /** 		elsif id = LOOP then*/
    if (_id_59775 != 422)
    goto L18; // [560] 580

    /** 		    StartSourceLine(TRUE)*/
    _37StartSourceLine(_9TRUE_430, 0, 2);

    /** 	        Loop_statement()*/
    _30Loop_statement();
    goto L9; // [577] 1083
L18: 

    /** 		elsif id = ENTRY then*/
    if (_id_59775 != 424)
    goto L19; // [584] 606

    /** 		    StartSourceLine(TRUE, , COVERAGE_SUPPRESS )*/
    _37StartSourceLine(_9TRUE_430, 0, 1);

    /** 		    Entry_statement()*/
    _30Entry_statement();
    goto L9; // [603] 1083
L19: 

    /** 		elsif id = QUESTION_MARK then*/
    if (_id_59775 != -31)
    goto L1A; // [610] 630

    /** 			StartSourceLine(TRUE)*/
    _37StartSourceLine(_9TRUE_430, 0, 2);

    /** 			Print_statement()*/
    _30Print_statement();
    goto L9; // [627] 1083
L1A: 

    /** 		elsif id = CONTINUE then*/
    if (_id_59775 != 426)
    goto L1B; // [634] 654

    /** 			StartSourceLine(TRUE)*/
    _37StartSourceLine(_9TRUE_430, 0, 2);

    /** 			Continue_statement()*/
    _30Continue_statement();
    goto L9; // [651] 1083
L1B: 

    /** 		elsif id = RETRY then*/
    if (_id_59775 != 184)
    goto L1C; // [658] 678

    /** 			StartSourceLine(TRUE)*/
    _37StartSourceLine(_9TRUE_430, 0, 2);

    /** 			Retry_statement()*/
    _30Retry_statement();
    goto L9; // [675] 1083
L1C: 

    /** 		elsif id = IFDEF then*/
    if (_id_59775 != 407)
    goto L1D; // [682] 702

    /** 			StartSourceLine(TRUE)*/
    _37StartSourceLine(_9TRUE_430, 0, 2);

    /** 			Ifdef_statement()*/
    _30Ifdef_statement();
    goto L9; // [699] 1083
L1D: 

    /** 		elsif id = CASE then*/
    if (_id_59775 != 186)
    goto L1E; // [706] 717

    /** 			Case_statement()*/
    _30Case_statement();
    goto L9; // [714] 1083
L1E: 

    /** 		elsif id = SWITCH then*/
    if (_id_59775 != 185)
    goto L1F; // [721] 741

    /** 			StartSourceLine(TRUE)*/
    _37StartSourceLine(_9TRUE_430, 0, 2);

    /** 			Switch_statement()*/
    _30Switch_statement();
    goto L9; // [738] 1083
L1F: 

    /** 		elsif id = FALLTHRU then*/
    if (_id_59775 != 431)
    goto L20; // [745] 756

    /** 			Fallthru_statement()*/
    _30Fallthru_statement();
    goto L9; // [753] 1083
L20: 

    /** 		elsif id = TYPE or id = QUALIFIED_TYPE then*/
    _30210 = (_id_59775 == 504);
    if (_30210 != 0) {
        goto L21; // [764] 779
    }
    _30212 = (_id_59775 == 522);
    if (_30212 == 0)
    {
        DeRef(_30212);
        _30212 = NOVALUE;
        goto L22; // [775] 904
    }
    else{
        DeRef(_30212);
        _30212 = NOVALUE;
    }
L21: 

    /** 			StartSourceLine(TRUE)*/
    _37StartSourceLine(_9TRUE_430, 0, 2);

    /** 			token test = next_token()*/
    _0 = _test_59947;
    _test_59947 = _30next_token();
    DeRef(_0);

    /** 			putback( test )*/
    Ref(_test_59947);
    _30putback(_test_59947);

    /** 			if test[T_ID] = LEFT_ROUND then*/
    _2 = (int)SEQ_PTR(_test_59947);
    _30214 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30214, -26)){
        _30214 = NOVALUE;
        goto L23; // [808] 852
    }
    _30214 = NOVALUE;

    /** 				StartSourceLine( TRUE )*/
    _37StartSourceLine(_9TRUE_430, 0, 2);

    /** 				Procedure_call(tok)*/
    Ref(_tok_59774);
    _30Procedure_call(_tok_59774);

    /** 				clear_op()*/
    _37clear_op();

    /** 				if Pop() then end if*/
    _30216 = _37Pop();
    if (_30216 == 0) {
        DeRef(_30216);
        _30216 = NOVALUE;
        goto L24; // [835] 839
    }
    else {
        if (!IS_ATOM_INT(_30216) && DBL_PTR(_30216)->dbl == 0.0){
            DeRef(_30216);
            _30216 = NOVALUE;
            goto L24; // [835] 839
        }
        DeRef(_30216);
        _30216 = NOVALUE;
    }
    DeRef(_30216);
    _30216 = NOVALUE;
L24: 

    /** 				ExecCommand()*/
    _30ExecCommand();

    /** 				continue*/
    DeRef(_test_59947);
    _test_59947 = NOVALUE;
    goto L1; // [847] 16
    goto L25; // [849] 899
L23: 

    /** 				if param_num != -1 then*/
    if (_30param_num_54165 == -1)
    goto L26; // [856] 882

    /** 					param_num += 1*/
    _30param_num_54165 = _30param_num_54165 + 1;

    /** 					Private_declaration( tok[T_SYM] )*/
    _2 = (int)SEQ_PTR(_tok_59774);
    _30219 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_30219);
    _30Private_declaration(_30219);
    _30219 = NOVALUE;
    goto L27; // [879] 898
L26: 

    /** 					Global_declaration( tok[T_SYM], SC_LOCAL )*/
    _2 = (int)SEQ_PTR(_tok_59774);
    _30220 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_30220);
    _30221 = _30Global_declaration(_30220, 5);
    _30220 = NOVALUE;
L27: 
L25: 
    DeRef(_test_59947);
    _test_59947 = NOVALUE;
    goto L9; // [901] 1083
L22: 

    /** 			if id = ELSE then*/
    if (_id_59775 != 23)
    goto L28; // [908] 962

    /** 				if length(if_stack) = 0 then*/
    if (IS_SEQUENCE(_30if_stack_54191)){
            _30223 = SEQ_PTR(_30if_stack_54191)->length;
    }
    else {
        _30223 = 1;
    }
    if (_30223 != 0)
    goto L29; // [919] 1019

    /** 					if live_ifdef > 0 then*/
    if (_30live_ifdef_58325 <= 0)
    goto L2A; // [927] 950

    /** 						CompileErr(134, ifdef_lineno[$])*/
    if (IS_SEQUENCE(_30ifdef_lineno_58326)){
            _30226 = SEQ_PTR(_30ifdef_lineno_58326)->length;
    }
    else {
        _30226 = 1;
    }
    _2 = (int)SEQ_PTR(_30ifdef_lineno_58326);
    _30227 = (int)*(((s1_ptr)_2)->base + _30226);
    _43CompileErr(134, _30227, 0);
    _30227 = NOVALUE;
    goto L29; // [947] 1019
L2A: 

    /** 						CompileErr(118)*/
    RefDS(_22037);
    _43CompileErr(118, _22037, 0);
    goto L29; // [959] 1019
L28: 

    /** 			elsif id = ELSIF then*/
    if (_id_59775 != 414)
    goto L2B; // [966] 1018

    /** 				if length(if_stack) = 0 then*/
    if (IS_SEQUENCE(_30if_stack_54191)){
            _30229 = SEQ_PTR(_30if_stack_54191)->length;
    }
    else {
        _30229 = 1;
    }
    if (_30229 != 0)
    goto L2C; // [977] 1017

    /** 					if live_ifdef > 0 then*/
    if (_30live_ifdef_58325 <= 0)
    goto L2D; // [985] 1008

    /** 						CompileErr(139, ifdef_lineno[$])*/
    if (IS_SEQUENCE(_30ifdef_lineno_58326)){
            _30232 = SEQ_PTR(_30ifdef_lineno_58326)->length;
    }
    else {
        _30232 = 1;
    }
    _2 = (int)SEQ_PTR(_30ifdef_lineno_58326);
    _30233 = (int)*(((s1_ptr)_2)->base + _30232);
    _43CompileErr(139, _30233, 0);
    _30233 = NOVALUE;
    goto L2E; // [1005] 1016
L2D: 

    /** 						CompileErr(119)*/
    RefDS(_22037);
    _43CompileErr(119, _22037, 0);
L2E: 
L2C: 
L2B: 
L29: 

    /** 			putback( tok )*/
    Ref(_tok_59774);
    _30putback(_tok_59774);

    /** 			switch id do*/
    _0 = _id_59775;
    switch ( _0 ){ 

        /** 				case END, ELSEDEF, ELSIFDEF, ELSIF, ELSE, UNTIL then*/
        case 402:
        case 409:
        case 408:
        case 414:
        case 23:
        case 423:

        /** 					stmt_nest -= 1*/
        _30stmt_nest_54188 = _30stmt_nest_54188 - 1;

        /** 					InitDelete()*/
        _30InitDelete();

        /** 					flush_temps()*/
        RefDS(_22037);
        _37flush_temps(_22037);

        /** 					return*/
        DeRef(_tok_59774);
        DeRef(_30166);
        _30166 = NOVALUE;
        _30169 = NOVALUE;
        DeRef(_30182);
        _30182 = NOVALUE;
        DeRef(_30181);
        _30181 = NOVALUE;
        DeRef(_30187);
        _30187 = NOVALUE;
        DeRef(_30210);
        _30210 = NOVALUE;
        DeRef(_30221);
        _30221 = NOVALUE;
        return;
        goto L2F; // [1067] 1082

        /** 				case else*/
        default:

        /** 					tok_match( END )*/
        _30tok_match(402, 0);
    ;}L2F: 
L9: 

    /** 		flush_temps()*/
    RefDS(_22037);
    _37flush_temps(_22037);

    /** 	end while*/
    goto L1; // [1090] 16
L2: 

    /** end procedure*/
    DeRef(_tok_59774);
    DeRef(_30166);
    _30166 = NOVALUE;
    _30169 = NOVALUE;
    DeRef(_30182);
    _30182 = NOVALUE;
    DeRef(_30181);
    _30181 = NOVALUE;
    DeRef(_30187);
    _30187 = NOVALUE;
    DeRef(_30210);
    _30210 = NOVALUE;
    DeRef(_30221);
    _30221 = NOVALUE;
    return;
    ;
}


void _30SubProg(int _prog_type_60017, int _scope_60018)
{
    int _h_60019 = NOVALUE;
    int _pt_60020 = NOVALUE;
    int _p_60022 = NOVALUE;
    int _type_sym_60023 = NOVALUE;
    int _sym_60024 = NOVALUE;
    int _tok_60026 = NOVALUE;
    int _prog_name_60027 = NOVALUE;
    int _first_def_arg_60028 = NOVALUE;
    int _again_60029 = NOVALUE;
    int _type_enum_60030 = NOVALUE;
    int _seq_sym_60031 = NOVALUE;
    int _i1_sym_60032 = NOVALUE;
    int _enum_syms_60033 = NOVALUE;
    int _type_enum_gline_60034 = NOVALUE;
    int _real_gline_60035 = NOVALUE;
    int _tsym_60046 = NOVALUE;
    int _seq_symbol_60057 = NOVALUE;
    int _middle_def_args_60256 = NOVALUE;
    int _last_nda_60257 = NOVALUE;
    int _start_def_60258 = NOVALUE;
    int _last_link_60260 = NOVALUE;
    int _temptok_60287 = NOVALUE;
    int _undef_type_60289 = NOVALUE;
    int _tokcat_60338 = NOVALUE;
    int _31644 = NOVALUE;
    int _31643 = NOVALUE;
    int _31642 = NOVALUE;
    int _31641 = NOVALUE;
    int _31640 = NOVALUE;
    int _31639 = NOVALUE;
    int _31638 = NOVALUE;
    int _31637 = NOVALUE;
    int _31636 = NOVALUE;
    int _30497 = NOVALUE;
    int _30495 = NOVALUE;
    int _30494 = NOVALUE;
    int _30492 = NOVALUE;
    int _30491 = NOVALUE;
    int _30490 = NOVALUE;
    int _30489 = NOVALUE;
    int _30488 = NOVALUE;
    int _30486 = NOVALUE;
    int _30485 = NOVALUE;
    int _30482 = NOVALUE;
    int _30481 = NOVALUE;
    int _30480 = NOVALUE;
    int _30479 = NOVALUE;
    int _30477 = NOVALUE;
    int _30468 = NOVALUE;
    int _30466 = NOVALUE;
    int _30465 = NOVALUE;
    int _30464 = NOVALUE;
    int _30463 = NOVALUE;
    int _30460 = NOVALUE;
    int _30459 = NOVALUE;
    int _30458 = NOVALUE;
    int _30456 = NOVALUE;
    int _30453 = NOVALUE;
    int _30452 = NOVALUE;
    int _30451 = NOVALUE;
    int _30449 = NOVALUE;
    int _30448 = NOVALUE;
    int _30445 = NOVALUE;
    int _30443 = NOVALUE;
    int _30441 = NOVALUE;
    int _30440 = NOVALUE;
    int _30439 = NOVALUE;
    int _30438 = NOVALUE;
    int _30436 = NOVALUE;
    int _30435 = NOVALUE;
    int _30434 = NOVALUE;
    int _30433 = NOVALUE;
    int _30432 = NOVALUE;
    int _30431 = NOVALUE;
    int _30428 = NOVALUE;
    int _30426 = NOVALUE;
    int _30424 = NOVALUE;
    int _30422 = NOVALUE;
    int _30420 = NOVALUE;
    int _30417 = NOVALUE;
    int _30415 = NOVALUE;
    int _30414 = NOVALUE;
    int _30411 = NOVALUE;
    int _30407 = NOVALUE;
    int _30406 = NOVALUE;
    int _30404 = NOVALUE;
    int _30402 = NOVALUE;
    int _30400 = NOVALUE;
    int _30398 = NOVALUE;
    int _30396 = NOVALUE;
    int _30394 = NOVALUE;
    int _30393 = NOVALUE;
    int _30392 = NOVALUE;
    int _30391 = NOVALUE;
    int _30390 = NOVALUE;
    int _30389 = NOVALUE;
    int _30388 = NOVALUE;
    int _30387 = NOVALUE;
    int _30386 = NOVALUE;
    int _30385 = NOVALUE;
    int _30384 = NOVALUE;
    int _30383 = NOVALUE;
    int _30380 = NOVALUE;
    int _30379 = NOVALUE;
    int _30378 = NOVALUE;
    int _30377 = NOVALUE;
    int _30376 = NOVALUE;
    int _30375 = NOVALUE;
    int _30374 = NOVALUE;
    int _30373 = NOVALUE;
    int _30372 = NOVALUE;
    int _30371 = NOVALUE;
    int _30370 = NOVALUE;
    int _30369 = NOVALUE;
    int _30368 = NOVALUE;
    int _30367 = NOVALUE;
    int _30366 = NOVALUE;
    int _30364 = NOVALUE;
    int _30362 = NOVALUE;
    int _30361 = NOVALUE;
    int _30356 = NOVALUE;
    int _30355 = NOVALUE;
    int _30353 = NOVALUE;
    int _30352 = NOVALUE;
    int _30351 = NOVALUE;
    int _30350 = NOVALUE;
    int _30349 = NOVALUE;
    int _30348 = NOVALUE;
    int _30347 = NOVALUE;
    int _30346 = NOVALUE;
    int _30345 = NOVALUE;
    int _30344 = NOVALUE;
    int _30342 = NOVALUE;
    int _30341 = NOVALUE;
    int _30339 = NOVALUE;
    int _30338 = NOVALUE;
    int _30337 = NOVALUE;
    int _30336 = NOVALUE;
    int _30335 = NOVALUE;
    int _30334 = NOVALUE;
    int _30333 = NOVALUE;
    int _30331 = NOVALUE;
    int _30328 = NOVALUE;
    int _30326 = NOVALUE;
    int _30324 = NOVALUE;
    int _30322 = NOVALUE;
    int _30320 = NOVALUE;
    int _30318 = NOVALUE;
    int _30316 = NOVALUE;
    int _30314 = NOVALUE;
    int _30312 = NOVALUE;
    int _30311 = NOVALUE;
    int _30310 = NOVALUE;
    int _30309 = NOVALUE;
    int _30308 = NOVALUE;
    int _30307 = NOVALUE;
    int _30306 = NOVALUE;
    int _30304 = NOVALUE;
    int _30303 = NOVALUE;
    int _30301 = NOVALUE;
    int _30299 = NOVALUE;
    int _30297 = NOVALUE;
    int _30296 = NOVALUE;
    int _30293 = NOVALUE;
    int _30292 = NOVALUE;
    int _30291 = NOVALUE;
    int _30290 = NOVALUE;
    int _30289 = NOVALUE;
    int _30287 = NOVALUE;
    int _30286 = NOVALUE;
    int _30285 = NOVALUE;
    int _30284 = NOVALUE;
    int _30283 = NOVALUE;
    int _30281 = NOVALUE;
    int _30280 = NOVALUE;
    int _30279 = NOVALUE;
    int _30277 = NOVALUE;
    int _30276 = NOVALUE;
    int _30275 = NOVALUE;
    int _30274 = NOVALUE;
    int _30270 = NOVALUE;
    int _30269 = NOVALUE;
    int _30268 = NOVALUE;
    int _30266 = NOVALUE;
    int _30265 = NOVALUE;
    int _30264 = NOVALUE;
    int _30263 = NOVALUE;
    int _30262 = NOVALUE;
    int _30261 = NOVALUE;
    int _30257 = NOVALUE;
    int _30256 = NOVALUE;
    int _30255 = NOVALUE;
    int _30253 = NOVALUE;
    int _30252 = NOVALUE;
    int _30251 = NOVALUE;
    int _30249 = NOVALUE;
    int _30248 = NOVALUE;
    int _30246 = NOVALUE;
    int _30245 = NOVALUE;
    int _30244 = NOVALUE;
    int _30240 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_prog_type_60017)) {
        _1 = (long)(DBL_PTR(_prog_type_60017)->dbl);
        DeRefDS(_prog_type_60017);
        _prog_type_60017 = _1;
    }

    /** 	integer first_def_arg*/

    /** 	integer again*/

    /** 	integer type_enum*/

    /** 	object seq_sym*/

    /** 	object i1_sym*/

    /** 	sequence enum_syms = {}*/
    RefDS(_22037);
    DeRef(_enum_syms_60033);
    _enum_syms_60033 = _22037;

    /** 	integer type_enum_gline, real_gline*/

    /** 	LeaveTopLevel()*/
    _30LeaveTopLevel();

    /** 	prog_name = next_token()*/
    _0 = _prog_name_60027;
    _prog_name_60027 = _30next_token();
    DeRef(_0);

    /** 	if prog_name[T_ID] = END_OF_FILE then*/
    _2 = (int)SEQ_PTR(_prog_name_60027);
    _30240 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30240, -21)){
        _30240 = NOVALUE;
        goto L1; // [43] 55
    }
    _30240 = NOVALUE;

    /** 		CompileErr( 32 )*/
    RefDS(_22037);
    _43CompileErr(32, _22037, 0);
L1: 

    /** 	type_enum =  0*/
    _type_enum_60030 = 0;

    /** 	if prog_type = TYPE_DECL then*/
    if (_prog_type_60017 != 416)
    goto L2; // [64] 316

    /** 		object tsym = prog_name[T_SYM]*/
    DeRef(_tsym_60046);
    _2 = (int)SEQ_PTR(_prog_name_60027);
    _tsym_60046 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_tsym_60046);

    /** 		if equal(sym_name(prog_name[T_SYM]),"enum") then*/
    _2 = (int)SEQ_PTR(_prog_name_60027);
    _30244 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_30244);
    _30245 = _52sym_name(_30244);
    _30244 = NOVALUE;
    if (_30245 == _26333)
    _30246 = 1;
    else if (IS_ATOM_INT(_30245) && IS_ATOM_INT(_26333))
    _30246 = 0;
    else
    _30246 = (compare(_30245, _26333) == 0);
    DeRef(_30245);
    _30245 = NOVALUE;
    if (_30246 == 0)
    {
        _30246 = NOVALUE;
        goto L3; // [92] 313
    }
    else{
        _30246 = NOVALUE;
    }

    /** 			EnterTopLevel( FALSE )*/
    _30EnterTopLevel(_9FALSE_428);

    /** 			type_enum_gline = gline_number*/
    _type_enum_gline_60034 = _26gline_number_11987;

    /** 			type_enum = 1*/
    _type_enum_60030 = 1;

    /** 			sequence seq_symbol*/

    /** 			prog_name = next_token()*/
    _0 = _prog_name_60027;
    _prog_name_60027 = _30next_token();
    DeRef(_0);

    /** 			if not find(prog_name[T_ID], ADDR_TOKS) then*/
    _2 = (int)SEQ_PTR(_prog_name_60027);
    _30248 = (int)*(((s1_ptr)_2)->base + 1);
    _30249 = find_from(_30248, _28ADDR_TOKS_11606, 1);
    _30248 = NOVALUE;
    if (_30249 != 0)
    goto L4; // [138] 163
    _30249 = NOVALUE;

    /** 				CompileErr(25, {find_category(prog_name[T_ID])} )*/
    _2 = (int)SEQ_PTR(_prog_name_60027);
    _30251 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_30251);
    _30252 = _62find_category(_30251);
    _30251 = NOVALUE;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _30252;
    _30253 = MAKE_SEQ(_1);
    _30252 = NOVALUE;
    _43CompileErr(25, _30253, 0);
    _30253 = NOVALUE;
L4: 

    /** 			enum_syms = Global_declaration(-1, scope)*/
    _0 = _enum_syms_60033;
    _enum_syms_60033 = _30Global_declaration(-1, _scope_60018);
    DeRef(_0);

    /** 			seq_symbol = enum_syms*/
    RefDS(_enum_syms_60033);
    DeRef(_seq_symbol_60057);
    _seq_symbol_60057 = _enum_syms_60033;

    /** 			for i = 1 to length( enum_syms ) do*/
    if (IS_SEQUENCE(_enum_syms_60033)){
            _30255 = SEQ_PTR(_enum_syms_60033)->length;
    }
    else {
        _30255 = 1;
    }
    {
        int _i_60073;
        _i_60073 = 1;
L5: 
        if (_i_60073 > _30255){
            goto L6; // [184] 212
        }

        /** 				seq_symbol[i] = sym_obj(enum_syms[i])*/
        _2 = (int)SEQ_PTR(_enum_syms_60033);
        _30256 = (int)*(((s1_ptr)_2)->base + _i_60073);
        Ref(_30256);
        _30257 = _52sym_obj(_30256);
        _30256 = NOVALUE;
        _2 = (int)SEQ_PTR(_seq_symbol_60057);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _seq_symbol_60057 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_60073);
        _1 = *(int *)_2;
        *(int *)_2 = _30257;
        if( _1 != _30257 ){
            DeRef(_1);
        }
        _30257 = NOVALUE;

        /** 			end for*/
        _i_60073 = _i_60073 + 1;
        goto L5; // [207] 191
L6: 
        ;
    }

    /** 			i1_sym = keyfind("i1",-1)*/
    RefDS(_30258);
    DeRef(_31643);
    _31643 = _30258;
    _31644 = _52hashfn(_31643);
    _31643 = NOVALUE;
    RefDS(_30258);
    _0 = _i1_sym_60032;
    _i1_sym_60032 = _52keyfind(_30258, -1, _26current_file_no_11982, 0, _31644);
    DeRef(_0);
    _31644 = NOVALUE;

    /** 			seq_sym = NewStringSym(seq_symbol)*/
    RefDS(_seq_symbol_60057);
    _0 = _seq_sym_60031;
    _seq_sym_60031 = _52NewStringSym(_seq_symbol_60057);
    DeRef(_0);

    /** 			putback(keyfind("return",-1))*/
    RefDS(_26407);
    DeRef(_31641);
    _31641 = _26407;
    _31642 = _52hashfn(_31641);
    _31641 = NOVALUE;
    RefDS(_26407);
    _30261 = _52keyfind(_26407, -1, _26current_file_no_11982, 0, _31642);
    _31642 = NOVALUE;
    _30putback(_30261);
    _30261 = NOVALUE;

    /** 			putback({RIGHT_ROUND,0})*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -27;
    ((int *)_2)[2] = 0;
    _30262 = MAKE_SEQ(_1);
    _30putback(_30262);
    _30262 = NOVALUE;

    /** 			putback(i1_sym)*/
    Ref(_i1_sym_60032);
    _30putback(_i1_sym_60032);

    /** 			putback(keyfind("object",-1))*/
    RefDS(_24664);
    DeRef(_31639);
    _31639 = _24664;
    _31640 = _52hashfn(_31639);
    _31639 = NOVALUE;
    RefDS(_24664);
    _30263 = _52keyfind(_24664, -1, _26current_file_no_11982, 0, _31640);
    _31640 = NOVALUE;
    _30putback(_30263);
    _30263 = NOVALUE;

    /** 			putback({LEFT_ROUND,0})*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -26;
    ((int *)_2)[2] = 0;
    _30264 = MAKE_SEQ(_1);
    _30putback(_30264);
    _30264 = NOVALUE;

    /** 			LeaveTopLevel()*/
    _30LeaveTopLevel();
L3: 
    DeRef(_seq_symbol_60057);
    _seq_symbol_60057 = NOVALUE;
L2: 
    DeRef(_tsym_60046);
    _tsym_60046 = NOVALUE;

    /** 	if not find(prog_name[T_ID], ADDR_TOKS) then*/
    _2 = (int)SEQ_PTR(_prog_name_60027);
    _30265 = (int)*(((s1_ptr)_2)->base + 1);
    _30266 = find_from(_30265, _28ADDR_TOKS_11606, 1);
    _30265 = NOVALUE;
    if (_30266 != 0)
    goto L7; // [333] 358
    _30266 = NOVALUE;

    /** 		CompileErr(25, {find_category(prog_name[T_ID])} )*/
    _2 = (int)SEQ_PTR(_prog_name_60027);
    _30268 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_30268);
    _30269 = _62find_category(_30268);
    _30268 = NOVALUE;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _30269;
    _30270 = MAKE_SEQ(_1);
    _30269 = NOVALUE;
    _43CompileErr(25, _30270, 0);
    _30270 = NOVALUE;
L7: 

    /** 	p = prog_name[T_SYM]*/
    _2 = (int)SEQ_PTR(_prog_name_60027);
    _p_60022 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_p_60022)){
        _p_60022 = (long)DBL_PTR(_p_60022)->dbl;
    }

    /** 	DefinedYet(p)*/
    _52DefinedYet(_p_60022);

    /** 	if prog_type = PROCEDURE then*/
    if (_prog_type_60017 != 405)
    goto L8; // [377] 393

    /** 		pt = PROC*/
    _pt_60020 = 27;
    goto L9; // [390] 423
L8: 

    /** 	elsif prog_type = FUNCTION then*/
    if (_prog_type_60017 != 406)
    goto LA; // [397] 413

    /** 		pt = FUNC*/
    _pt_60020 = 501;
    goto L9; // [410] 423
LA: 

    /** 		pt = TYPE*/
    _pt_60020 = 504;
L9: 

    /** 	clear_fwd_refs()*/
    _29clear_fwd_refs();

    /** 	if find(SymTab[p][S_SCOPE], {SC_PREDEF, SC_GLOBAL, SC_PUBLIC, SC_EXPORT, SC_OVERRIDE}) then*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _30274 = (int)*(((s1_ptr)_2)->base + _p_60022);
    _2 = (int)SEQ_PTR(_30274);
    _30275 = (int)*(((s1_ptr)_2)->base + 4);
    _30274 = NOVALUE;
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 7;
    *((int *)(_2+8)) = 6;
    *((int *)(_2+12)) = 13;
    *((int *)(_2+16)) = 11;
    *((int *)(_2+20)) = 12;
    _30276 = MAKE_SEQ(_1);
    _30277 = find_from(_30275, _30276, 1);
    _30275 = NOVALUE;
    DeRefDS(_30276);
    _30276 = NOVALUE;
    if (_30277 == 0)
    {
        _30277 = NOVALUE;
        goto LB; // [464] 660
    }
    else{
        _30277 = NOVALUE;
    }

    /** 		if scope = SC_OVERRIDE then*/
    if (_scope_60018 != 12)
    goto LC; // [471] 597

    /** 			if SymTab[p][S_SCOPE] = SC_PREDEF or SymTab[p][S_SCOPE] = SC_OVERRIDE then*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _30279 = (int)*(((s1_ptr)_2)->base + _p_60022);
    _2 = (int)SEQ_PTR(_30279);
    _30280 = (int)*(((s1_ptr)_2)->base + 4);
    _30279 = NOVALUE;
    if (IS_ATOM_INT(_30280)) {
        _30281 = (_30280 == 7);
    }
    else {
        _30281 = binary_op(EQUALS, _30280, 7);
    }
    _30280 = NOVALUE;
    if (IS_ATOM_INT(_30281)) {
        if (_30281 != 0) {
            goto LD; // [495] 522
        }
    }
    else {
        if (DBL_PTR(_30281)->dbl != 0.0) {
            goto LD; // [495] 522
        }
    }
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _30283 = (int)*(((s1_ptr)_2)->base + _p_60022);
    _2 = (int)SEQ_PTR(_30283);
    _30284 = (int)*(((s1_ptr)_2)->base + 4);
    _30283 = NOVALUE;
    if (IS_ATOM_INT(_30284)) {
        _30285 = (_30284 == 12);
    }
    else {
        _30285 = binary_op(EQUALS, _30284, 12);
    }
    _30284 = NOVALUE;
    if (_30285 == 0) {
        DeRef(_30285);
        _30285 = NOVALUE;
        goto LE; // [518] 596
    }
    else {
        if (!IS_ATOM_INT(_30285) && DBL_PTR(_30285)->dbl == 0.0){
            DeRef(_30285);
            _30285 = NOVALUE;
            goto LE; // [518] 596
        }
        DeRef(_30285);
        _30285 = NOVALUE;
    }
    DeRef(_30285);
    _30285 = NOVALUE;
LD: 

    /** 					if SymTab[p][S_SCOPE] = SC_OVERRIDE then*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _30286 = (int)*(((s1_ptr)_2)->base + _p_60022);
    _2 = (int)SEQ_PTR(_30286);
    _30287 = (int)*(((s1_ptr)_2)->base + 4);
    _30286 = NOVALUE;
    if (binary_op_a(NOTEQ, _30287, 12)){
        _30287 = NOVALUE;
        goto LF; // [538] 550
    }
    _30287 = NOVALUE;

    /** 						again = 223*/
    _again_60029 = 223;
    goto L10; // [547] 556
LF: 

    /** 						again = 222*/
    _again_60029 = 222;
L10: 

    /** 					Warning(again, override_warning_flag,*/
    _2 = (int)SEQ_PTR(_27known_files_10922);
    _30289 = (int)*(((s1_ptr)_2)->base + _26current_file_no_11982);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _30290 = (int)*(((s1_ptr)_2)->base + _p_60022);
    _2 = (int)SEQ_PTR(_30290);
    if (!IS_ATOM_INT(_26S_NAME_11654)){
        _30291 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NAME_11654)->dbl));
    }
    else{
        _30291 = (int)*(((s1_ptr)_2)->base + _26S_NAME_11654);
    }
    _30290 = NOVALUE;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_30289);
    *((int *)(_2+4)) = _30289;
    *((int *)(_2+8)) = _26line_number_11983;
    Ref(_30291);
    *((int *)(_2+12)) = _30291;
    _30292 = MAKE_SEQ(_1);
    _30291 = NOVALUE;
    _30289 = NOVALUE;
    _43Warning(_again_60029, 4, _30292);
    _30292 = NOVALUE;
LE: 
LC: 

    /** 		h = SymTab[p][S_HASHVAL]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _30293 = (int)*(((s1_ptr)_2)->base + _p_60022);
    _2 = (int)SEQ_PTR(_30293);
    _h_60019 = (int)*(((s1_ptr)_2)->base + 11);
    if (!IS_ATOM_INT(_h_60019)){
        _h_60019 = (long)DBL_PTR(_h_60019)->dbl;
    }
    _30293 = NOVALUE;

    /** 		sym = buckets[h]*/
    _2 = (int)SEQ_PTR(_52buckets_46126);
    _sym_60024 = (int)*(((s1_ptr)_2)->base + _h_60019);
    if (!IS_ATOM_INT(_sym_60024)){
        _sym_60024 = (long)DBL_PTR(_sym_60024)->dbl;
    }

    /** 		p = NewEntry(SymTab[p][S_NAME], 0, 0, pt, h, sym, 0)*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _30296 = (int)*(((s1_ptr)_2)->base + _p_60022);
    _2 = (int)SEQ_PTR(_30296);
    if (!IS_ATOM_INT(_26S_NAME_11654)){
        _30297 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NAME_11654)->dbl));
    }
    else{
        _30297 = (int)*(((s1_ptr)_2)->base + _26S_NAME_11654);
    }
    _30296 = NOVALUE;
    Ref(_30297);
    _p_60022 = _52NewEntry(_30297, 0, 0, _pt_60020, _h_60019, _sym_60024, 0);
    _30297 = NOVALUE;
    if (!IS_ATOM_INT(_p_60022)) {
        _1 = (long)(DBL_PTR(_p_60022)->dbl);
        DeRefDS(_p_60022);
        _p_60022 = _1;
    }

    /** 		buckets[h] = p*/
    _2 = (int)SEQ_PTR(_52buckets_46126);
    _2 = (int)(((s1_ptr)_2)->base + _h_60019);
    _1 = *(int *)_2;
    *(int *)_2 = _p_60022;
    DeRef(_1);
LB: 

    /** 	Start_block( pt, p )*/
    _65Start_block(_pt_60020, _p_60022);

    /** 	CurrentSub = p*/
    _26CurrentSub_11990 = _p_60022;

    /** 	first_def_arg = 0*/
    _first_def_arg_60028 = 0;

    /** 	temps_allocated = 0*/
    _52temps_allocated_46650 = 0;

    /** 	SymTab[p][S_SCOPE] = scope*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_60022 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = _scope_60018;
    DeRef(_1);
    _30299 = NOVALUE;

    /** 	SymTab[p][S_TOKEN] = pt*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_60022 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_26S_TOKEN_11659))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_TOKEN_11659)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _26S_TOKEN_11659);
    _1 = *(int *)_2;
    *(int *)_2 = _pt_60020;
    DeRef(_1);
    _30301 = NOVALUE;

    /** 	if length(SymTab[p]) < SIZEOF_ROUTINE_ENTRY then*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _30303 = (int)*(((s1_ptr)_2)->base + _p_60022);
    if (IS_SEQUENCE(_30303)){
            _30304 = SEQ_PTR(_30303)->length;
    }
    else {
        _30304 = 1;
    }
    _30303 = NOVALUE;
    if (_30304 >= _26SIZEOF_ROUTINE_ENTRY_11779)
    goto L11; // [730] 772

    /** 		SymTab[p] = SymTab[p] & repeat(0, SIZEOF_ROUTINE_ENTRY -*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _30306 = (int)*(((s1_ptr)_2)->base + _p_60022);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _30307 = (int)*(((s1_ptr)_2)->base + _p_60022);
    if (IS_SEQUENCE(_30307)){
            _30308 = SEQ_PTR(_30307)->length;
    }
    else {
        _30308 = 1;
    }
    _30307 = NOVALUE;
    _30309 = _26SIZEOF_ROUTINE_ENTRY_11779 - _30308;
    _30308 = NOVALUE;
    _30310 = Repeat(0, _30309);
    _30309 = NOVALUE;
    if (IS_SEQUENCE(_30306) && IS_ATOM(_30310)) {
    }
    else if (IS_ATOM(_30306) && IS_SEQUENCE(_30310)) {
        Ref(_30306);
        Prepend(&_30311, _30310, _30306);
    }
    else {
        Concat((object_ptr)&_30311, _30306, _30310);
        _30306 = NOVALUE;
    }
    _30306 = NOVALUE;
    DeRefDS(_30310);
    _30310 = NOVALUE;
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _p_60022);
    _1 = *(int *)_2;
    *(int *)_2 = _30311;
    if( _1 != _30311 ){
        DeRef(_1);
    }
    _30311 = NOVALUE;
L11: 

    /** 	SymTab[p][S_CODE] = 0*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_60022 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_26S_CODE_11666))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_CODE_11666)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _26S_CODE_11666);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _30312 = NOVALUE;

    /** 	SymTab[p][S_LINETAB] = 0*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_60022 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_26S_LINETAB_11689))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_LINETAB_11689)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _26S_LINETAB_11689);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _30314 = NOVALUE;

    /** 	SymTab[p][S_EFFECT] = E_PURE*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_60022 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 23);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _30316 = NOVALUE;

    /** 	SymTab[p][S_REFLIST] = {}*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_60022 + ((s1_ptr)_2)->base);
    RefDS(_22037);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 24);
    _1 = *(int *)_2;
    *(int *)_2 = _22037;
    DeRef(_1);
    _30318 = NOVALUE;

    /** 	SymTab[p][S_FIRSTLINE] = gline_number*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_60022 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_26S_FIRSTLINE_11694))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_FIRSTLINE_11694)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _26S_FIRSTLINE_11694);
    _1 = *(int *)_2;
    *(int *)_2 = _26gline_number_11987;
    DeRef(_1);
    _30320 = NOVALUE;

    /** 	SymTab[p][S_TEMPS] = 0*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_60022 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_26S_TEMPS_11699))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_TEMPS_11699)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _26S_TEMPS_11699);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _30322 = NOVALUE;

    /** 	SymTab[p][S_RESIDENT_TASK] = 0*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_60022 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 25);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _30324 = NOVALUE;

    /** 	SymTab[p][S_SAVED_PRIVATES] = {}*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_60022 + ((s1_ptr)_2)->base);
    RefDS(_22037);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 26);
    _1 = *(int *)_2;
    *(int *)_2 = _22037;
    DeRef(_1);
    _30326 = NOVALUE;

    /** 	if type_enum then*/
    if (_type_enum_60030 == 0)
    {
        goto L12; // [898] 955
    }
    else{
    }

    /** 		SymTab[p][S_FIRSTLINE] = type_enum_gline*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_60022 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_26S_FIRSTLINE_11694))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_FIRSTLINE_11694)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _26S_FIRSTLINE_11694);
    _1 = *(int *)_2;
    *(int *)_2 = _type_enum_gline_60034;
    DeRef(_1);
    _30328 = NOVALUE;

    /** 		real_gline = gline_number*/
    _real_gline_60035 = _26gline_number_11987;

    /** 		gline_number = type_enum_gline*/
    _26gline_number_11987 = _type_enum_gline_60034;

    /** 		StartSourceLine( FALSE, , COVERAGE_OVERRIDE )*/
    _37StartSourceLine(_9FALSE_428, 0, 3);

    /** 		gline_number = real_gline*/
    _26gline_number_11987 = _real_gline_60035;
    goto L13; // [952] 967
L12: 

    /** 		StartSourceLine(FALSE, , COVERAGE_OVERRIDE)*/
    _37StartSourceLine(_9FALSE_428, 0, 3);
L13: 

    /** 	tok_match(LEFT_ROUND)*/
    _30tok_match(-26, 0);

    /** 	tok = next_token()*/
    _0 = _tok_60026;
    _tok_60026 = _30next_token();
    DeRef(_0);

    /** 	param_num = 0*/
    _30param_num_54165 = 0;

    /** 	sequence middle_def_args = {}*/
    RefDS(_22037);
    DeRef(_middle_def_args_60256);
    _middle_def_args_60256 = _22037;

    /** 	integer last_nda = 0, start_def = 0*/
    _last_nda_60257 = 0;
    _start_def_60258 = 0;

    /** 	symtab_index last_link = p*/
    _last_link_60260 = _p_60022;

    /** 	while tok[T_ID] != RIGHT_ROUND do*/
L14: 
    _2 = (int)SEQ_PTR(_tok_60026);
    _30331 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _30331, -27)){
        _30331 = NOVALUE;
        goto L15; // [1020] 1793
    }
    _30331 = NOVALUE;

    /** 		if tok[T_ID] != TYPE and tok[T_ID] != QUALIFIED_TYPE then*/
    _2 = (int)SEQ_PTR(_tok_60026);
    _30333 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_30333)) {
        _30334 = (_30333 != 504);
    }
    else {
        _30334 = binary_op(NOTEQ, _30333, 504);
    }
    _30333 = NOVALUE;
    if (IS_ATOM_INT(_30334)) {
        if (_30334 == 0) {
            goto L16; // [1038] 1262
        }
    }
    else {
        if (DBL_PTR(_30334)->dbl == 0.0) {
            goto L16; // [1038] 1262
        }
    }
    _2 = (int)SEQ_PTR(_tok_60026);
    _30336 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_30336)) {
        _30337 = (_30336 != 522);
    }
    else {
        _30337 = binary_op(NOTEQ, _30336, 522);
    }
    _30336 = NOVALUE;
    if (_30337 == 0) {
        DeRef(_30337);
        _30337 = NOVALUE;
        goto L16; // [1055] 1262
    }
    else {
        if (!IS_ATOM_INT(_30337) && DBL_PTR(_30337)->dbl == 0.0){
            DeRef(_30337);
            _30337 = NOVALUE;
            goto L16; // [1055] 1262
        }
        DeRef(_30337);
        _30337 = NOVALUE;
    }
    DeRef(_30337);
    _30337 = NOVALUE;

    /** 			if tok[T_ID] = VARIABLE or tok[T_ID] = QUALIFIED_VARIABLE then*/
    _2 = (int)SEQ_PTR(_tok_60026);
    _30338 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_30338)) {
        _30339 = (_30338 == -100);
    }
    else {
        _30339 = binary_op(EQUALS, _30338, -100);
    }
    _30338 = NOVALUE;
    if (IS_ATOM_INT(_30339)) {
        if (_30339 != 0) {
            goto L17; // [1072] 1093
        }
    }
    else {
        if (DBL_PTR(_30339)->dbl != 0.0) {
            goto L17; // [1072] 1093
        }
    }
    _2 = (int)SEQ_PTR(_tok_60026);
    _30341 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_30341)) {
        _30342 = (_30341 == 512);
    }
    else {
        _30342 = binary_op(EQUALS, _30341, 512);
    }
    _30341 = NOVALUE;
    if (_30342 == 0) {
        DeRef(_30342);
        _30342 = NOVALUE;
        goto L18; // [1089] 1253
    }
    else {
        if (!IS_ATOM_INT(_30342) && DBL_PTR(_30342)->dbl == 0.0){
            DeRef(_30342);
            _30342 = NOVALUE;
            goto L18; // [1089] 1253
        }
        DeRef(_30342);
        _30342 = NOVALUE;
    }
    DeRef(_30342);
    _30342 = NOVALUE;
L17: 

    /** 				token temptok = next_token()*/
    _0 = _temptok_60287;
    _temptok_60287 = _30next_token();
    DeRef(_0);

    /** 				integer undef_type = 0*/
    _undef_type_60289 = 0;

    /** 				if temptok[T_ID] != TYPE and temptok[T_ID] != QUALIFIED_TYPE then*/
    _2 = (int)SEQ_PTR(_temptok_60287);
    _30344 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_30344)) {
        _30345 = (_30344 != 504);
    }
    else {
        _30345 = binary_op(NOTEQ, _30344, 504);
    }
    _30344 = NOVALUE;
    if (IS_ATOM_INT(_30345)) {
        if (_30345 == 0) {
            goto L19; // [1117] 1218
        }
    }
    else {
        if (DBL_PTR(_30345)->dbl == 0.0) {
            goto L19; // [1117] 1218
        }
    }
    _2 = (int)SEQ_PTR(_temptok_60287);
    _30347 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_30347)) {
        _30348 = (_30347 != 522);
    }
    else {
        _30348 = binary_op(NOTEQ, _30347, 522);
    }
    _30347 = NOVALUE;
    if (_30348 == 0) {
        DeRef(_30348);
        _30348 = NOVALUE;
        goto L19; // [1134] 1218
    }
    else {
        if (!IS_ATOM_INT(_30348) && DBL_PTR(_30348)->dbl == 0.0){
            DeRef(_30348);
            _30348 = NOVALUE;
            goto L19; // [1134] 1218
        }
        DeRef(_30348);
        _30348 = NOVALUE;
    }
    DeRef(_30348);
    _30348 = NOVALUE;

    /** 					if find( temptok[T_ID], FULL_ID_TOKS) then*/
    _2 = (int)SEQ_PTR(_temptok_60287);
    _30349 = (int)*(((s1_ptr)_2)->base + 1);
    _30350 = find_from(_30349, _28FULL_ID_TOKS_11610, 1);
    _30349 = NOVALUE;
    if (_30350 == 0)
    {
        _30350 = NOVALUE;
        goto L1A; // [1152] 1217
    }
    else{
        _30350 = NOVALUE;
    }

    /** 						if SymTab[tok[T_SYM]][S_SCOPE] = SC_UNDEFINED then*/
    _2 = (int)SEQ_PTR(_tok_60026);
    _30351 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!IS_ATOM_INT(_30351)){
        _30352 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_30351)->dbl));
    }
    else{
        _30352 = (int)*(((s1_ptr)_2)->base + _30351);
    }
    _2 = (int)SEQ_PTR(_30352);
    _30353 = (int)*(((s1_ptr)_2)->base + 4);
    _30352 = NOVALUE;
    if (binary_op_a(NOTEQ, _30353, 9)){
        _30353 = NOVALUE;
        goto L1B; // [1177] 1208
    }
    _30353 = NOVALUE;

    /** 							undef_type = - new_forward_reference( TYPE, tok[T_SYM] )*/
    _2 = (int)SEQ_PTR(_tok_60026);
    _30355 = (int)*(((s1_ptr)_2)->base + 2);
    DeRef(_31638);
    _31638 = 504;
    Ref(_30355);
    _30356 = _29new_forward_reference(504, _30355, 504);
    _30355 = NOVALUE;
    _31638 = NOVALUE;
    if (IS_ATOM_INT(_30356)) {
        if ((unsigned long)_30356 == 0xC0000000)
        _undef_type_60289 = (int)NewDouble((double)-0xC0000000);
        else
        _undef_type_60289 = - _30356;
    }
    else {
        _undef_type_60289 = unary_op(UMINUS, _30356);
    }
    DeRef(_30356);
    _30356 = NOVALUE;
    if (!IS_ATOM_INT(_undef_type_60289)) {
        _1 = (long)(DBL_PTR(_undef_type_60289)->dbl);
        DeRefDS(_undef_type_60289);
        _undef_type_60289 = _1;
    }
    goto L1C; // [1205] 1216
L1B: 

    /** 							CompileErr(37)*/
    RefDS(_22037);
    _43CompileErr(37, _22037, 0);
L1C: 
L1A: 
L19: 

    /** 				putback(temptok) -- Return whatever came after the name back onto the token stream.*/
    Ref(_temptok_60287);
    _30putback(_temptok_60287);

    /** 				if undef_type != 0 then*/
    if (_undef_type_60289 == 0)
    goto L1D; // [1225] 1240

    /** 					tok[T_SYM] = undef_type*/
    _2 = (int)SEQ_PTR(_tok_60026);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _tok_60026 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _undef_type_60289;
    DeRef(_1);
    goto L1E; // [1237] 1248
L1D: 

    /** 					CompileErr(37)*/
    RefDS(_22037);
    _43CompileErr(37, _22037, 0);
L1E: 
    DeRef(_temptok_60287);
    _temptok_60287 = NOVALUE;
    goto L1F; // [1250] 1261
L18: 

    /** 				CompileErr(37)*/
    RefDS(_22037);
    _43CompileErr(37, _22037, 0);
L1F: 
L16: 

    /** 		type_sym = tok[T_SYM]*/
    _2 = (int)SEQ_PTR(_tok_60026);
    _type_sym_60023 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_type_sym_60023)){
        _type_sym_60023 = (long)DBL_PTR(_type_sym_60023)->dbl;
    }

    /** 		tok = next_token()*/
    _0 = _tok_60026;
    _tok_60026 = _30next_token();
    DeRef(_0);

    /** 		if not find(tok[T_ID], ID_TOKS) then*/
    _2 = (int)SEQ_PTR(_tok_60026);
    _30361 = (int)*(((s1_ptr)_2)->base + 1);
    _30362 = find_from(_30361, _28ID_TOKS_11608, 1);
    _30361 = NOVALUE;
    if (_30362 != 0)
    goto L20; // [1292] 1406
    _30362 = NOVALUE;

    /** 			sequence tokcat = find_category(tok[T_ID])*/
    _2 = (int)SEQ_PTR(_tok_60026);
    _30364 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_30364);
    _0 = _tokcat_60338;
    _tokcat_60338 = _62find_category(_30364);
    DeRef(_0);
    _30364 = NOVALUE;

    /** 			if tok[T_SYM] != 0 and length(SymTab[tok[T_SYM]]) >= S_NAME then*/
    _2 = (int)SEQ_PTR(_tok_60026);
    _30366 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_30366)) {
        _30367 = (_30366 != 0);
    }
    else {
        _30367 = binary_op(NOTEQ, _30366, 0);
    }
    _30366 = NOVALUE;
    if (IS_ATOM_INT(_30367)) {
        if (_30367 == 0) {
            goto L21; // [1321] 1382
        }
    }
    else {
        if (DBL_PTR(_30367)->dbl == 0.0) {
            goto L21; // [1321] 1382
        }
    }
    _2 = (int)SEQ_PTR(_tok_60026);
    _30369 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!IS_ATOM_INT(_30369)){
        _30370 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_30369)->dbl));
    }
    else{
        _30370 = (int)*(((s1_ptr)_2)->base + _30369);
    }
    if (IS_SEQUENCE(_30370)){
            _30371 = SEQ_PTR(_30370)->length;
    }
    else {
        _30371 = 1;
    }
    _30370 = NOVALUE;
    if (IS_ATOM_INT(_26S_NAME_11654)) {
        _30372 = (_30371 >= _26S_NAME_11654);
    }
    else {
        _30372 = binary_op(GREATEREQ, _30371, _26S_NAME_11654);
    }
    _30371 = NOVALUE;
    if (_30372 == 0) {
        DeRef(_30372);
        _30372 = NOVALUE;
        goto L21; // [1347] 1382
    }
    else {
        if (!IS_ATOM_INT(_30372) && DBL_PTR(_30372)->dbl == 0.0){
            DeRef(_30372);
            _30372 = NOVALUE;
            goto L21; // [1347] 1382
        }
        DeRef(_30372);
        _30372 = NOVALUE;
    }
    DeRef(_30372);
    _30372 = NOVALUE;

    /** 				CompileErr(90, {tokcat, SymTab[tok[T_SYM]][S_NAME]})*/
    _2 = (int)SEQ_PTR(_tok_60026);
    _30373 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!IS_ATOM_INT(_30373)){
        _30374 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_30373)->dbl));
    }
    else{
        _30374 = (int)*(((s1_ptr)_2)->base + _30373);
    }
    _2 = (int)SEQ_PTR(_30374);
    if (!IS_ATOM_INT(_26S_NAME_11654)){
        _30375 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NAME_11654)->dbl));
    }
    else{
        _30375 = (int)*(((s1_ptr)_2)->base + _26S_NAME_11654);
    }
    _30374 = NOVALUE;
    Ref(_30375);
    RefDS(_tokcat_60338);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _tokcat_60338;
    ((int *)_2)[2] = _30375;
    _30376 = MAKE_SEQ(_1);
    _30375 = NOVALUE;
    _43CompileErr(90, _30376, 0);
    _30376 = NOVALUE;
    goto L22; // [1379] 1405
L21: 

    /** 				CompileErr(92, {LexName(tok[T_ID])})*/
    _2 = (int)SEQ_PTR(_tok_60026);
    _30377 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_30377);
    RefDS(_26480);
    _30378 = _37LexName(_30377, _26480);
    _30377 = NOVALUE;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _30378;
    _30379 = MAKE_SEQ(_1);
    _30378 = NOVALUE;
    _43CompileErr(92, _30379, 0);
    _30379 = NOVALUE;
L22: 
L20: 
    DeRef(_tokcat_60338);
    _tokcat_60338 = NOVALUE;

    /** 		sym = SetPrivateScope(tok[T_SYM], type_sym, param_num)*/
    _2 = (int)SEQ_PTR(_tok_60026);
    _30380 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_30380);
    _sym_60024 = _30SetPrivateScope(_30380, _type_sym_60023, _30param_num_54165);
    _30380 = NOVALUE;
    if (!IS_ATOM_INT(_sym_60024)) {
        _1 = (long)(DBL_PTR(_sym_60024)->dbl);
        DeRefDS(_sym_60024);
        _sym_60024 = _1;
    }

    /** 		param_num += 1*/
    _30param_num_54165 = _30param_num_54165 + 1;

    /** 		if SymTab[last_link][S_NEXT] != sym*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _30383 = (int)*(((s1_ptr)_2)->base + _last_link_60260);
    _2 = (int)SEQ_PTR(_30383);
    _30384 = (int)*(((s1_ptr)_2)->base + 2);
    _30383 = NOVALUE;
    if (IS_ATOM_INT(_30384)) {
        _30385 = (_30384 != _sym_60024);
    }
    else {
        _30385 = binary_op(NOTEQ, _30384, _sym_60024);
    }
    _30384 = NOVALUE;
    if (IS_ATOM_INT(_30385)) {
        if (_30385 == 0) {
            goto L23; // [1452] 1533
        }
    }
    else {
        if (DBL_PTR(_30385)->dbl == 0.0) {
            goto L23; // [1452] 1533
        }
    }
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _30387 = (int)*(((s1_ptr)_2)->base + _last_link_60260);
    _2 = (int)SEQ_PTR(_30387);
    _30388 = (int)*(((s1_ptr)_2)->base + 2);
    _30387 = NOVALUE;
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!IS_ATOM_INT(_30388)){
        _30389 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_30388)->dbl));
    }
    else{
        _30389 = (int)*(((s1_ptr)_2)->base + _30388);
    }
    _2 = (int)SEQ_PTR(_30389);
    _30390 = (int)*(((s1_ptr)_2)->base + 4);
    _30389 = NOVALUE;
    if (IS_ATOM_INT(_30390)) {
        _30391 = (_30390 == 9);
    }
    else {
        _30391 = binary_op(EQUALS, _30390, 9);
    }
    _30390 = NOVALUE;
    if (_30391 == 0) {
        DeRef(_30391);
        _30391 = NOVALUE;
        goto L23; // [1487] 1533
    }
    else {
        if (!IS_ATOM_INT(_30391) && DBL_PTR(_30391)->dbl == 0.0){
            DeRef(_30391);
            _30391 = NOVALUE;
            goto L23; // [1487] 1533
        }
        DeRef(_30391);
        _30391 = NOVALUE;
    }
    DeRef(_30391);
    _30391 = NOVALUE;

    /** 			SymTab[SymTab[last_link][S_NEXT]][S_NEXT] = 0*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _30392 = (int)*(((s1_ptr)_2)->base + _last_link_60260);
    _2 = (int)SEQ_PTR(_30392);
    _30393 = (int)*(((s1_ptr)_2)->base + 2);
    _30392 = NOVALUE;
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_30393))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_30393)->dbl));
    else
    _3 = (int)(_30393 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _30394 = NOVALUE;

    /** 			SymTab[last_link][S_NEXT] = sym*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_last_link_60260 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _sym_60024;
    DeRef(_1);
    _30396 = NOVALUE;
L23: 

    /** 		last_link = sym*/
    _last_link_60260 = _sym_60024;

    /** 		if TRANSLATE then*/
    if (_26TRANSLATE_11619 == 0)
    {
        goto L24; // [1544] 1567
    }
    else{
    }

    /** 			SymTab[sym][S_GTYPE] = CompileType(type_sym)*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_60024 + ((s1_ptr)_2)->base);
    _30400 = _30CompileType(_type_sym_60023);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 36);
    _1 = *(int *)_2;
    *(int *)_2 = _30400;
    if( _1 != _30400 ){
        DeRef(_1);
    }
    _30400 = NOVALUE;
    _30398 = NOVALUE;
L24: 

    /** 		tok = next_token()*/
    _0 = _tok_60026;
    _tok_60026 = _30next_token();
    DeRef(_0);

    /** 		if tok[T_ID] = EQUALS then -- defaulted parameter*/
    _2 = (int)SEQ_PTR(_tok_60026);
    _30402 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30402, 3)){
        _30402 = NOVALUE;
        goto L25; // [1582] 1664
    }
    _30402 = NOVALUE;

    /** 			start_recording()*/
    _30start_recording();

    /** 			Expr()*/
    _30Expr();

    /** 			SymTab[sym][S_CODE] = restore_parser()*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_60024 + ((s1_ptr)_2)->base);
    _30406 = _30restore_parser();
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_26S_CODE_11666))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_CODE_11666)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _26S_CODE_11666);
    _1 = *(int *)_2;
    *(int *)_2 = _30406;
    if( _1 != _30406 ){
        DeRef(_1);
    }
    _30406 = NOVALUE;
    _30404 = NOVALUE;

    /** 			if Pop() then end if -- don't leak the default argument*/
    _30407 = _37Pop();
    if (_30407 == 0) {
        DeRef(_30407);
        _30407 = NOVALUE;
        goto L26; // [1617] 1621
    }
    else {
        if (!IS_ATOM_INT(_30407) && DBL_PTR(_30407)->dbl == 0.0){
            DeRef(_30407);
            _30407 = NOVALUE;
            goto L26; // [1617] 1621
        }
        DeRef(_30407);
        _30407 = NOVALUE;
    }
    DeRef(_30407);
    _30407 = NOVALUE;
L26: 

    /** 			tok = next_token()*/
    _0 = _tok_60026;
    _tok_60026 = _30next_token();
    DeRef(_0);

    /** 			if first_def_arg = 0 then*/
    if (_first_def_arg_60028 != 0)
    goto L27; // [1628] 1640

    /** 				first_def_arg = param_num*/
    _first_def_arg_60028 = _30param_num_54165;
L27: 

    /** 			previous_op = -1 -- no interferences betwen defparms, or them and subsequent code*/
    _26previous_op_12081 = -1;

    /** 			if start_def = 0 then*/
    if (_start_def_60258 != 0)
    goto L28; // [1649] 1721

    /** 				start_def = param_num*/
    _start_def_60258 = _30param_num_54165;
    goto L28; // [1661] 1721
L25: 

    /** 			last_nda = param_num*/
    _last_nda_60257 = _30param_num_54165;

    /** 			if start_def then*/
    if (_start_def_60258 == 0)
    {
        goto L29; // [1673] 1720
    }
    else{
    }

    /** 				if start_def = param_num-1 then*/
    _30411 = _30param_num_54165 - 1;
    if ((long)((unsigned long)_30411 +(unsigned long) HIGH_BITS) >= 0){
        _30411 = NewDouble((double)_30411);
    }
    if (binary_op_a(NOTEQ, _start_def_60258, _30411)){
        DeRef(_30411);
        _30411 = NOVALUE;
        goto L2A; // [1684] 1697
    }
    DeRef(_30411);
    _30411 = NOVALUE;

    /** 					middle_def_args &= start_def*/
    Append(&_middle_def_args_60256, _middle_def_args_60256, _start_def_60258);
    goto L2B; // [1694] 1714
L2A: 

    /** 					middle_def_args = append(middle_def_args, {start_def, param_num-1})*/
    _30414 = _30param_num_54165 - 1;
    if ((long)((unsigned long)_30414 +(unsigned long) HIGH_BITS) >= 0){
        _30414 = NewDouble((double)_30414);
    }
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _start_def_60258;
    ((int *)_2)[2] = _30414;
    _30415 = MAKE_SEQ(_1);
    _30414 = NOVALUE;
    RefDS(_30415);
    Append(&_middle_def_args_60256, _middle_def_args_60256, _30415);
    DeRefDS(_30415);
    _30415 = NOVALUE;
L2B: 

    /** 				start_def = 0*/
    _start_def_60258 = 0;
L29: 
L28: 

    /** 		if tok[T_ID] = COMMA then*/
    _2 = (int)SEQ_PTR(_tok_60026);
    _30417 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30417, -30)){
        _30417 = NOVALUE;
        goto L2C; // [1731] 1765
    }
    _30417 = NOVALUE;

    /** 			tok = next_token()*/
    _0 = _tok_60026;
    _tok_60026 = _30next_token();
    DeRef(_0);

    /** 			if tok[T_ID] = RIGHT_ROUND then*/
    _2 = (int)SEQ_PTR(_tok_60026);
    _30420 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30420, -27)){
        _30420 = NOVALUE;
        goto L14; // [1750] 1012
    }
    _30420 = NOVALUE;

    /** 				CompileErr(85)*/
    RefDS(_22037);
    _43CompileErr(85, _22037, 0);
    goto L14; // [1762] 1012
L2C: 

    /** 		elsif tok[T_ID] != RIGHT_ROUND then*/
    _2 = (int)SEQ_PTR(_tok_60026);
    _30422 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _30422, -27)){
        _30422 = NOVALUE;
        goto L14; // [1775] 1012
    }
    _30422 = NOVALUE;

    /** 			CompileErr(41)*/
    RefDS(_22037);
    _43CompileErr(41, _22037, 0);

    /** 	end while*/
    goto L14; // [1790] 1012
L15: 

    /** 	Code = {} -- removes any spurious code emitted while recording parameters*/
    RefDS(_22037);
    DeRef(_26Code_12071);
    _26Code_12071 = _22037;

    /** 	SymTab[p][S_NUM_ARGS] = param_num*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_60022 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_26S_NUM_ARGS_11705))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NUM_ARGS_11705)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _26S_NUM_ARGS_11705);
    _1 = *(int *)_2;
    *(int *)_2 = _30param_num_54165;
    DeRef(_1);
    _30424 = NOVALUE;

    /** 	SymTab[p][S_DEF_ARGS] = {first_def_arg, last_nda, middle_def_args}*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_60022 + ((s1_ptr)_2)->base);
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _first_def_arg_60028;
    *((int *)(_2+8)) = _last_nda_60257;
    RefDS(_middle_def_args_60256);
    *((int *)(_2+12)) = _middle_def_args_60256;
    _30428 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 28);
    _1 = *(int *)_2;
    *(int *)_2 = _30428;
    if( _1 != _30428 ){
        DeRef(_1);
    }
    _30428 = NOVALUE;
    _30426 = NOVALUE;

    /** 	if TRANSLATE then*/
    if (_26TRANSLATE_11619 == 0)
    {
        goto L2D; // [1842] 1876
    }
    else{
    }

    /** 		if param_num > max_params then*/
    if (_30param_num_54165 <= _37max_params_50268)
    goto L2E; // [1851] 1865

    /** 			max_params = param_num*/
    _37max_params_50268 = _30param_num_54165;
L2E: 

    /** 		num_routines += 1*/
    _26num_routines_11991 = _26num_routines_11991 + 1;
L2D: 

    /** 	if SymTab[p][S_TOKEN] = TYPE and param_num != 1 then*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _30431 = (int)*(((s1_ptr)_2)->base + _p_60022);
    _2 = (int)SEQ_PTR(_30431);
    if (!IS_ATOM_INT(_26S_TOKEN_11659)){
        _30432 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_TOKEN_11659)->dbl));
    }
    else{
        _30432 = (int)*(((s1_ptr)_2)->base + _26S_TOKEN_11659);
    }
    _30431 = NOVALUE;
    if (IS_ATOM_INT(_30432)) {
        _30433 = (_30432 == 504);
    }
    else {
        _30433 = binary_op(EQUALS, _30432, 504);
    }
    _30432 = NOVALUE;
    if (IS_ATOM_INT(_30433)) {
        if (_30433 == 0) {
            goto L2F; // [1896] 1918
        }
    }
    else {
        if (DBL_PTR(_30433)->dbl == 0.0) {
            goto L2F; // [1896] 1918
        }
    }
    _30435 = (_30param_num_54165 != 1);
    if (_30435 == 0)
    {
        DeRef(_30435);
        _30435 = NOVALUE;
        goto L2F; // [1907] 1918
    }
    else{
        DeRef(_30435);
        _30435 = NOVALUE;
    }

    /** 		CompileErr(148)*/
    RefDS(_22037);
    _43CompileErr(148, _22037, 0);
L2F: 

    /** 	include_routine()*/
    _49include_routine();

    /** 	sym = SymTab[p][S_NEXT]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _30436 = (int)*(((s1_ptr)_2)->base + _p_60022);
    _2 = (int)SEQ_PTR(_30436);
    _sym_60024 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_sym_60024)){
        _sym_60024 = (long)DBL_PTR(_sym_60024)->dbl;
    }
    _30436 = NOVALUE;

    /** 	for i = 1 to SymTab[p][S_NUM_ARGS] do*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _30438 = (int)*(((s1_ptr)_2)->base + _p_60022);
    _2 = (int)SEQ_PTR(_30438);
    if (!IS_ATOM_INT(_26S_NUM_ARGS_11705)){
        _30439 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NUM_ARGS_11705)->dbl));
    }
    else{
        _30439 = (int)*(((s1_ptr)_2)->base + _26S_NUM_ARGS_11705);
    }
    _30438 = NOVALUE;
    {
        int _i_60492;
        _i_60492 = 1;
L30: 
        if (binary_op_a(GREATER, _i_60492, _30439)){
            goto L31; // [1952] 2031
        }

        /** 		while SymTab[sym][S_SCOPE] != SC_PRIVATE do*/
L32: 
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _30440 = (int)*(((s1_ptr)_2)->base + _sym_60024);
        _2 = (int)SEQ_PTR(_30440);
        _30441 = (int)*(((s1_ptr)_2)->base + 4);
        _30440 = NOVALUE;
        if (binary_op_a(EQUALS, _30441, 3)){
            _30441 = NOVALUE;
            goto L33; // [1978] 2003
        }
        _30441 = NOVALUE;

        /** 			sym = SymTab[sym][S_NEXT]*/
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _30443 = (int)*(((s1_ptr)_2)->base + _sym_60024);
        _2 = (int)SEQ_PTR(_30443);
        _sym_60024 = (int)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_sym_60024)){
            _sym_60024 = (long)DBL_PTR(_sym_60024)->dbl;
        }
        _30443 = NOVALUE;

        /** 		end while*/
        goto L32; // [2000] 1964
L33: 

        /** 		TypeCheck(sym)*/
        _30TypeCheck(_sym_60024);

        /** 		sym = SymTab[sym][S_NEXT]*/
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _30445 = (int)*(((s1_ptr)_2)->base + _sym_60024);
        _2 = (int)SEQ_PTR(_30445);
        _sym_60024 = (int)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_sym_60024)){
            _sym_60024 = (long)DBL_PTR(_sym_60024)->dbl;
        }
        _30445 = NOVALUE;

        /** 	end for*/
        _0 = _i_60492;
        if (IS_ATOM_INT(_i_60492)) {
            _i_60492 = _i_60492 + 1;
            if ((long)((unsigned long)_i_60492 +(unsigned long) HIGH_BITS) >= 0){
                _i_60492 = NewDouble((double)_i_60492);
            }
        }
        else {
            _i_60492 = binary_op_a(PLUS, _i_60492, 1);
        }
        DeRef(_0);
        goto L30; // [2026] 1959
L31: 
        ;
        DeRef(_i_60492);
    }

    /** 	tok = next_token()*/
    _0 = _tok_60026;
    _tok_60026 = _30next_token();
    DeRef(_0);

    /** 	while tok[T_ID] = TYPE or tok[T_ID] = QUALIFIED_TYPE do*/
L34: 
    _2 = (int)SEQ_PTR(_tok_60026);
    _30448 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_30448)) {
        _30449 = (_30448 == 504);
    }
    else {
        _30449 = binary_op(EQUALS, _30448, 504);
    }
    _30448 = NOVALUE;
    if (IS_ATOM_INT(_30449)) {
        if (_30449 != 0) {
            goto L35; // [2053] 2074
        }
    }
    else {
        if (DBL_PTR(_30449)->dbl != 0.0) {
            goto L35; // [2053] 2074
        }
    }
    _2 = (int)SEQ_PTR(_tok_60026);
    _30451 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_30451)) {
        _30452 = (_30451 == 522);
    }
    else {
        _30452 = binary_op(EQUALS, _30451, 522);
    }
    _30451 = NOVALUE;
    if (_30452 <= 0) {
        if (_30452 == 0) {
            DeRef(_30452);
            _30452 = NOVALUE;
            goto L36; // [2070] 2095
        }
        else {
            if (!IS_ATOM_INT(_30452) && DBL_PTR(_30452)->dbl == 0.0){
                DeRef(_30452);
                _30452 = NOVALUE;
                goto L36; // [2070] 2095
            }
            DeRef(_30452);
            _30452 = NOVALUE;
        }
    }
    DeRef(_30452);
    _30452 = NOVALUE;
L35: 

    /** 		Private_declaration(tok[T_SYM])*/
    _2 = (int)SEQ_PTR(_tok_60026);
    _30453 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_30453);
    _30Private_declaration(_30453);
    _30453 = NOVALUE;

    /** 		tok = next_token()*/
    _0 = _tok_60026;
    _tok_60026 = _30next_token();
    DeRef(_0);

    /** 	end while*/
    goto L34; // [2092] 2041
L36: 

    /** 	if not TRANSLATE then*/
    if (_26TRANSLATE_11619 != 0)
    goto L37; // [2099] 2202

    /** 		if OpTrace then*/
    if (_26OpTrace_12052 == 0)
    {
        goto L38; // [2106] 2201
    }
    else{
    }

    /** 			emit_op(ERASE_PRIVATE_NAMES)*/
    _37emit_op(88);

    /** 			emit_addr(p)*/
    _37emit_addr(_p_60022);

    /** 			sym = SymTab[p][S_NEXT]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _30456 = (int)*(((s1_ptr)_2)->base + _p_60022);
    _2 = (int)SEQ_PTR(_30456);
    _sym_60024 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_sym_60024)){
        _sym_60024 = (long)DBL_PTR(_sym_60024)->dbl;
    }
    _30456 = NOVALUE;

    /** 			for i = 1 to SymTab[p][S_NUM_ARGS] do*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _30458 = (int)*(((s1_ptr)_2)->base + _p_60022);
    _2 = (int)SEQ_PTR(_30458);
    if (!IS_ATOM_INT(_26S_NUM_ARGS_11705)){
        _30459 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NUM_ARGS_11705)->dbl));
    }
    else{
        _30459 = (int)*(((s1_ptr)_2)->base + _26S_NUM_ARGS_11705);
    }
    _30458 = NOVALUE;
    {
        int _i_60539;
        _i_60539 = 1;
L39: 
        if (binary_op_a(GREATER, _i_60539, _30459)){
            goto L3A; // [2151] 2193
        }

        /** 				emit_op(DISPLAY_VAR)*/
        _37emit_op(87);

        /** 				emit_addr(sym)*/
        _37emit_addr(_sym_60024);

        /** 				sym = SymTab[sym][S_NEXT]*/
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _30460 = (int)*(((s1_ptr)_2)->base + _sym_60024);
        _2 = (int)SEQ_PTR(_30460);
        _sym_60024 = (int)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_sym_60024)){
            _sym_60024 = (long)DBL_PTR(_sym_60024)->dbl;
        }
        _30460 = NOVALUE;

        /** 			end for*/
        _0 = _i_60539;
        if (IS_ATOM_INT(_i_60539)) {
            _i_60539 = _i_60539 + 1;
            if ((long)((unsigned long)_i_60539 +(unsigned long) HIGH_BITS) >= 0){
                _i_60539 = NewDouble((double)_i_60539);
            }
        }
        else {
            _i_60539 = binary_op_a(PLUS, _i_60539, 1);
        }
        DeRef(_0);
        goto L39; // [2188] 2158
L3A: 
        ;
        DeRef(_i_60539);
    }

    /** 			emit_op(UPDATE_GLOBALS)*/
    _37emit_op(89);
L38: 
L37: 

    /** 	putback(tok)*/
    Ref(_tok_60026);
    _30putback(_tok_60026);

    /** 	FuncReturn = FALSE*/
    _30FuncReturn_54164 = _9FALSE_428;

    /** 	if type_enum then*/
    if (_type_enum_60030 == 0)
    {
        goto L3B; // [2218] 2387
    }
    else{
    }

    /** 		stmt_nest += 1*/
    _30stmt_nest_54188 = _30stmt_nest_54188 + 1;

    /** 		tok_match(RETURN)*/
    _30tok_match(413, 0);

    /** 		putback({RIGHT_ROUND,0})*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -27;
    ((int *)_2)[2] = 0;
    _30463 = MAKE_SEQ(_1);
    _30putback(_30463);
    _30463 = NOVALUE;

    /** 		putback({VARIABLE,seq_sym})*/
    Ref(_seq_sym_60031);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -100;
    ((int *)_2)[2] = _seq_sym_60031;
    _30464 = MAKE_SEQ(_1);
    _30putback(_30464);
    _30464 = NOVALUE;

    /** 		putback({COMMA,0})*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -30;
    ((int *)_2)[2] = 0;
    _30465 = MAKE_SEQ(_1);
    _30putback(_30465);
    _30465 = NOVALUE;

    /** 		putback(i1_sym)*/
    Ref(_i1_sym_60032);
    _30putback(_i1_sym_60032);

    /** 		putback({LEFT_ROUND,0})*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -26;
    ((int *)_2)[2] = 0;
    _30466 = MAKE_SEQ(_1);
    _30putback(_30466);
    _30466 = NOVALUE;

    /** 		putback(keyfind("find",-1))*/
    RefDS(_30467);
    DeRef(_31636);
    _31636 = _30467;
    _31637 = _52hashfn(_31636);
    _31636 = NOVALUE;
    RefDS(_30467);
    _30468 = _52keyfind(_30467, -1, _26current_file_no_11982, 0, _31637);
    _31637 = NOVALUE;
    _30putback(_30468);
    _30468 = NOVALUE;

    /** 		if not TRANSLATE then*/
    if (_26TRANSLATE_11619 != 0)
    goto L3C; // [2316] 2342

    /** 			if OpTrace then*/
    if (_26OpTrace_12052 == 0)
    {
        goto L3D; // [2323] 2341
    }
    else{
    }

    /** 				emit_op(ERASE_PRIVATE_NAMES)*/
    _37emit_op(88);

    /** 				emit_addr(CurrentSub)*/
    _37emit_addr(_26CurrentSub_11990);
L3D: 
L3C: 

    /** 		Expr()*/
    _30Expr();

    /** 		FuncReturn = TRUE*/
    _30FuncReturn_54164 = _9TRUE_430;

    /** 		emit_op(RETURNF)*/
    _37emit_op(28);

    /** 		flush_temps()*/
    RefDS(_22037);
    _37flush_temps(_22037);

    /** 		stmt_nest -= 1*/
    _30stmt_nest_54188 = _30stmt_nest_54188 - 1;

    /** 		InitDelete()*/
    _30InitDelete();

    /** 		flush_temps()*/
    RefDS(_22037);
    _37flush_temps(_22037);
    goto L3E; // [2384] 2400
L3B: 

    /** 		Statement_list()*/
    _30Statement_list();

    /** 		tok_match(END)*/
    _30tok_match(402, 0);
L3E: 

    /** 	tok_match(prog_type, END)*/
    _30tok_match(_prog_type_60017, 402);

    /** 	if prog_type != PROCEDURE then*/
    if (_prog_type_60017 == 405)
    goto L3F; // [2412] 2460

    /** 		if not FuncReturn then*/
    if (_30FuncReturn_54164 != 0)
    goto L40; // [2420] 2450

    /** 			if prog_type = FUNCTION then*/
    if (_prog_type_60017 != 406)
    goto L41; // [2427] 2441

    /** 				CompileErr(120)*/
    RefDS(_22037);
    _43CompileErr(120, _22037, 0);
    goto L42; // [2438] 2449
L41: 

    /** 				CompileErr(149)*/
    RefDS(_22037);
    _43CompileErr(149, _22037, 0);
L42: 
L40: 

    /** 		emit_op(BADRETURNF) -- function/type shouldn't reach here*/
    _37emit_op(43);
    goto L43; // [2457] 2520
L3F: 

    /** 		StartSourceLine(TRUE)*/
    _37StartSourceLine(_9TRUE_430, 0, 2);

    /** 		if not TRANSLATE then*/
    if (_26TRANSLATE_11619 != 0)
    goto L44; // [2473] 2497

    /** 			if OpTrace then*/
    if (_26OpTrace_12052 == 0)
    {
        goto L45; // [2480] 2496
    }
    else{
    }

    /** 				emit_op(ERASE_PRIVATE_NAMES)*/
    _37emit_op(88);

    /** 				emit_addr(p)*/
    _37emit_addr(_p_60022);
L45: 
L44: 

    /** 		emit_op(RETURNP)*/
    _37emit_op(29);

    /** 		if TRANSLATE then*/
    if (_26TRANSLATE_11619 == 0)
    {
        goto L46; // [2508] 2519
    }
    else{
    }

    /** 			emit_op(BADRETURNF) -- just to mark end of procedure*/
    _37emit_op(43);
L46: 
L43: 

    /** 	Drop_block( pt )*/
    _65Drop_block(_pt_60020);

    /** 	if Strict_Override > 0 then*/
    if (_26Strict_Override_12049 <= 0)
    goto L47; // [2529] 2544

    /** 		Strict_Override -= 1	-- Reset at the end of each routine.*/
    _26Strict_Override_12049 = _26Strict_Override_12049 - 1;
L47: 

    /** 	SymTab[p][S_STACK_SPACE] += temps_allocated + param_num*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_60022 + ((s1_ptr)_2)->base);
    _30479 = _52temps_allocated_46650 + _30param_num_54165;
    if ((long)((unsigned long)_30479 + (unsigned long)HIGH_BITS) >= 0) 
    _30479 = NewDouble((double)_30479);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!IS_ATOM_INT(_26S_STACK_SPACE_11714)){
        _30480 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_STACK_SPACE_11714)->dbl));
    }
    else{
        _30480 = (int)*(((s1_ptr)_2)->base + _26S_STACK_SPACE_11714);
    }
    _30477 = NOVALUE;
    if (IS_ATOM_INT(_30480) && IS_ATOM_INT(_30479)) {
        _30481 = _30480 + _30479;
        if ((long)((unsigned long)_30481 + (unsigned long)HIGH_BITS) >= 0) 
        _30481 = NewDouble((double)_30481);
    }
    else {
        _30481 = binary_op(PLUS, _30480, _30479);
    }
    _30480 = NOVALUE;
    DeRef(_30479);
    _30479 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_26S_STACK_SPACE_11714))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_STACK_SPACE_11714)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _26S_STACK_SPACE_11714);
    _1 = *(int *)_2;
    *(int *)_2 = _30481;
    if( _1 != _30481 ){
        DeRef(_1);
    }
    _30481 = NOVALUE;
    _30477 = NOVALUE;

    /** 	if temps_allocated + param_num > max_stack_per_call then*/
    _30482 = _52temps_allocated_46650 + _30param_num_54165;
    if ((long)((unsigned long)_30482 + (unsigned long)HIGH_BITS) >= 0) 
    _30482 = NewDouble((double)_30482);
    if (binary_op_a(LESSEQ, _30482, _26max_stack_per_call_12082)){
        DeRef(_30482);
        _30482 = NOVALUE;
        goto L48; // [2587] 2604
    }
    DeRef(_30482);
    _30482 = NOVALUE;

    /** 		max_stack_per_call = temps_allocated + param_num*/
    _26max_stack_per_call_12082 = _52temps_allocated_46650 + _30param_num_54165;
L48: 

    /** 	param_num = -1*/
    _30param_num_54165 = -1;

    /** 	StraightenBranches()*/
    _30StraightenBranches();

    /** 	check_inline( p )*/
    _66check_inline(_p_60022);

    /** 	param_num = -1*/
    _30param_num_54165 = -1;

    /** 	EnterTopLevel()*/
    _30EnterTopLevel(1);

    /** 	if length( enum_syms ) then*/
    if (IS_SEQUENCE(_enum_syms_60033)){
            _30485 = SEQ_PTR(_enum_syms_60033)->length;
    }
    else {
        _30485 = 1;
    }
    if (_30485 == 0)
    {
        _30485 = NOVALUE;
        goto L49; // [2633] 2720
    }
    else{
        _30485 = NOVALUE;
    }

    /** 		SymTab[p][S_NEXT] = SymTab[enum_syms[$]][S_NEXT]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_60022 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_enum_syms_60033)){
            _30488 = SEQ_PTR(_enum_syms_60033)->length;
    }
    else {
        _30488 = 1;
    }
    _2 = (int)SEQ_PTR(_enum_syms_60033);
    _30489 = (int)*(((s1_ptr)_2)->base + _30488);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!IS_ATOM_INT(_30489)){
        _30490 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_30489)->dbl));
    }
    else{
        _30490 = (int)*(((s1_ptr)_2)->base + _30489);
    }
    _2 = (int)SEQ_PTR(_30490);
    _30491 = (int)*(((s1_ptr)_2)->base + 2);
    _30490 = NOVALUE;
    Ref(_30491);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _30491;
    if( _1 != _30491 ){
        DeRef(_1);
    }
    _30491 = NOVALUE;
    _30486 = NOVALUE;

    /** 		SymTab[last_sym][S_NEXT] = enum_syms[1]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_52last_sym_46139 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_enum_syms_60033);
    _30494 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_30494);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _30494;
    if( _1 != _30494 ){
        DeRef(_1);
    }
    _30494 = NOVALUE;
    _30492 = NOVALUE;

    /** 		last_sym = enum_syms[$]*/
    if (IS_SEQUENCE(_enum_syms_60033)){
            _30495 = SEQ_PTR(_enum_syms_60033)->length;
    }
    else {
        _30495 = 1;
    }
    _2 = (int)SEQ_PTR(_enum_syms_60033);
    _52last_sym_46139 = (int)*(((s1_ptr)_2)->base + _30495);
    if (!IS_ATOM_INT(_52last_sym_46139)){
        _52last_sym_46139 = (long)DBL_PTR(_52last_sym_46139)->dbl;
    }

    /** 		SymTab[last_sym][S_NEXT] = 0*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_52last_sym_46139 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _30497 = NOVALUE;
L49: 

    /** end procedure*/
    DeRef(_tok_60026);
    DeRef(_prog_name_60027);
    DeRef(_seq_sym_60031);
    DeRef(_i1_sym_60032);
    DeRef(_enum_syms_60033);
    DeRef(_middle_def_args_60256);
    _30303 = NOVALUE;
    DeRef(_30281);
    _30281 = NOVALUE;
    _30351 = NOVALUE;
    _30307 = NOVALUE;
    DeRef(_30334);
    _30334 = NOVALUE;
    DeRef(_30339);
    _30339 = NOVALUE;
    DeRef(_30345);
    _30345 = NOVALUE;
    _30369 = NOVALUE;
    DeRef(_30367);
    _30367 = NOVALUE;
    _30370 = NOVALUE;
    _30373 = NOVALUE;
    _30388 = NOVALUE;
    DeRef(_30385);
    _30385 = NOVALUE;
    _30393 = NOVALUE;
    _30439 = NOVALUE;
    DeRef(_30433);
    _30433 = NOVALUE;
    _30459 = NOVALUE;
    DeRef(_30449);
    _30449 = NOVALUE;
    _30489 = NOVALUE;
    return;
    ;
}


void _30InitGlobals()
{
    int _30516 = NOVALUE;
    int _30514 = NOVALUE;
    int _30513 = NOVALUE;
    int _30512 = NOVALUE;
    int _30511 = NOVALUE;
    int _30510 = NOVALUE;
    int _30509 = NOVALUE;
    int _30507 = NOVALUE;
    int _30506 = NOVALUE;
    int _30505 = NOVALUE;
    int _30504 = NOVALUE;
    int _30502 = NOVALUE;
    int _30501 = NOVALUE;
    int _30500 = NOVALUE;
    int _0, _1, _2;
    

    /** 	ResetTP()*/
    _60ResetTP();

    /** 	OpTypeCheck = TRUE*/
    _26OpTypeCheck_12053 = _9TRUE_430;

    /** 	OpDefines &= {*/
    _30500 = _31version_major();
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _30500;
    _30501 = MAKE_SEQ(_1);
    _30500 = NOVALUE;
    _30502 = EPrintf(-9999999, _30499, _30501);
    DeRefDS(_30501);
    _30501 = NOVALUE;
    _30504 = _31version_major();
    _30505 = _31version_minor();
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _30504;
    ((int *)_2)[2] = _30505;
    _30506 = MAKE_SEQ(_1);
    _30505 = NOVALUE;
    _30504 = NOVALUE;
    _30507 = EPrintf(-9999999, _30503, _30506);
    DeRefDS(_30506);
    _30506 = NOVALUE;
    _30509 = _31version_major();
    _30510 = _31version_minor();
    _30511 = _31version_patch();
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _30509;
    *((int *)(_2+8)) = _30510;
    *((int *)(_2+12)) = _30511;
    _30512 = MAKE_SEQ(_1);
    _30511 = NOVALUE;
    _30510 = NOVALUE;
    _30509 = NOVALUE;
    _30513 = EPrintf(-9999999, _30508, _30512);
    DeRefDS(_30512);
    _30512 = NOVALUE;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _30502;
    *((int *)(_2+8)) = _30507;
    *((int *)(_2+12)) = _30513;
    _30514 = MAKE_SEQ(_1);
    _30513 = NOVALUE;
    _30507 = NOVALUE;
    _30502 = NOVALUE;
    Concat((object_ptr)&_26OpDefines_12056, _26OpDefines_12056, _30514);
    DeRefDS(_30514);
    _30514 = NOVALUE;

    /** 	OpDefines &= GetPlatformDefines()*/
    _30516 = _36GetPlatformDefines(0);
    if (IS_SEQUENCE(_26OpDefines_12056) && IS_ATOM(_30516)) {
        Ref(_30516);
        Append(&_26OpDefines_12056, _26OpDefines_12056, _30516);
    }
    else if (IS_ATOM(_26OpDefines_12056) && IS_SEQUENCE(_30516)) {
    }
    else {
        Concat((object_ptr)&_26OpDefines_12056, _26OpDefines_12056, _30516);
    }
    DeRef(_30516);
    _30516 = NOVALUE;

    /** 	OpInline = DEFAULT_INLINE*/
    _26OpInline_12057 = 30;

    /** 	OpIndirectInclude = 1*/
    _26OpIndirectInclude_12058 = 1;

    /** end procedure*/
    return;
    ;
}


void _30not_supported_compile(int _feature_60703)
{
    int _30518 = NOVALUE;
    int _0, _1, _2;
    

    /** 	CompileErr(5, {feature, version_name})*/
    RefDS(_26version_name_11633);
    RefDS(_feature_60703);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _feature_60703;
    ((int *)_2)[2] = _26version_name_11633;
    _30518 = MAKE_SEQ(_1);
    _43CompileErr(5, _30518, 0);
    _30518 = NOVALUE;

    /** end procedure*/
    DeRefDSi(_feature_60703);
    return;
    ;
}


void _30SetWith(int _on_off_60709)
{
    int _option_60710 = NOVALUE;
    int _idx_60711 = NOVALUE;
    int _reset_flags_60712 = NOVALUE;
    int _tok_60764 = NOVALUE;
    int _good_sofar_60812 = NOVALUE;
    int _tok_60815 = NOVALUE;
    int _warning_extra_60817 = NOVALUE;
    int _endlist_60908 = NOVALUE;
    int _tok_61051 = NOVALUE;
    int _30663 = NOVALUE;
    int _30662 = NOVALUE;
    int _30661 = NOVALUE;
    int _30660 = NOVALUE;
    int _30659 = NOVALUE;
    int _30656 = NOVALUE;
    int _30655 = NOVALUE;
    int _30654 = NOVALUE;
    int _30652 = NOVALUE;
    int _30650 = NOVALUE;
    int _30647 = NOVALUE;
    int _30645 = NOVALUE;
    int _30644 = NOVALUE;
    int _30643 = NOVALUE;
    int _30642 = NOVALUE;
    int _30641 = NOVALUE;
    int _30637 = NOVALUE;
    int _30635 = NOVALUE;
    int _30633 = NOVALUE;
    int _30629 = NOVALUE;
    int _30624 = NOVALUE;
    int _30623 = NOVALUE;
    int _30618 = NOVALUE;
    int _30617 = NOVALUE;
    int _30616 = NOVALUE;
    int _30615 = NOVALUE;
    int _30614 = NOVALUE;
    int _30613 = NOVALUE;
    int _30612 = NOVALUE;
    int _30611 = NOVALUE;
    int _30610 = NOVALUE;
    int _30609 = NOVALUE;
    int _30607 = NOVALUE;
    int _30606 = NOVALUE;
    int _30604 = NOVALUE;
    int _30603 = NOVALUE;
    int _30602 = NOVALUE;
    int _30600 = NOVALUE;
    int _30599 = NOVALUE;
    int _30597 = NOVALUE;
    int _30594 = NOVALUE;
    int _30592 = NOVALUE;
    int _30589 = NOVALUE;
    int _30588 = NOVALUE;
    int _30587 = NOVALUE;
    int _30586 = NOVALUE;
    int _30579 = NOVALUE;
    int _30578 = NOVALUE;
    int _30576 = NOVALUE;
    int _30573 = NOVALUE;
    int _30572 = NOVALUE;
    int _30570 = NOVALUE;
    int _30569 = NOVALUE;
    int _30568 = NOVALUE;
    int _30567 = NOVALUE;
    int _30566 = NOVALUE;
    int _30565 = NOVALUE;
    int _30562 = NOVALUE;
    int _30561 = NOVALUE;
    int _30560 = NOVALUE;
    int _30559 = NOVALUE;
    int _30558 = NOVALUE;
    int _30557 = NOVALUE;
    int _30554 = NOVALUE;
    int _30553 = NOVALUE;
    int _30552 = NOVALUE;
    int _30550 = NOVALUE;
    int _30547 = NOVALUE;
    int _30545 = NOVALUE;
    int _30544 = NOVALUE;
    int _30542 = NOVALUE;
    int _30541 = NOVALUE;
    int _30540 = NOVALUE;
    int _30539 = NOVALUE;
    int _30538 = NOVALUE;
    int _30537 = NOVALUE;
    int _30535 = NOVALUE;
    int _30532 = NOVALUE;
    int _30531 = NOVALUE;
    int _30530 = NOVALUE;
    int _30529 = NOVALUE;
    int _30527 = NOVALUE;
    int _30526 = NOVALUE;
    int _30525 = NOVALUE;
    int _30524 = NOVALUE;
    int _30522 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer reset_flags = 1*/
    _reset_flags_60712 = 1;

    /** 	option = StringToken("&+=")*/
    RefDS(_30519);
    _0 = _option_60710;
    _option_60710 = _60StringToken(_30519);
    DeRef(_0);

    /** 	if equal(option, "type_check") then*/
    if (_option_60710 == _30521)
    _30522 = 1;
    else if (IS_ATOM_INT(_option_60710) && IS_ATOM_INT(_30521))
    _30522 = 0;
    else
    _30522 = (compare(_option_60710, _30521) == 0);
    if (_30522 == 0)
    {
        _30522 = NOVALUE;
        goto L1; // [22] 35
    }
    else{
        _30522 = NOVALUE;
    }

    /** 		OpTypeCheck = on_off*/
    _26OpTypeCheck_12053 = _on_off_60709;
    goto L2; // [32] 1521
L1: 

    /** 	elsif equal(option, "profile") then*/
    if (_option_60710 == _30523)
    _30524 = 1;
    else if (IS_ATOM_INT(_option_60710) && IS_ATOM_INT(_30523))
    _30524 = 0;
    else
    _30524 = (compare(_option_60710, _30523) == 0);
    if (_30524 == 0)
    {
        _30524 = NOVALUE;
        goto L3; // [41] 121
    }
    else{
        _30524 = NOVALUE;
    }

    /** 		if not TRANSLATE and not BIND then*/
    _30525 = (_26TRANSLATE_11619 == 0);
    if (_30525 == 0) {
        goto L2; // [51] 1521
    }
    _30527 = (_26BIND_11622 == 0);
    if (_30527 == 0)
    {
        DeRef(_30527);
        _30527 = NOVALUE;
        goto L2; // [61] 1521
    }
    else{
        DeRef(_30527);
        _30527 = NOVALUE;
    }

    /** 			OpProfileStatement = on_off*/
    _26OpProfileStatement_12054 = _on_off_60709;

    /** 			if OpProfileStatement then*/
    if (_26OpProfileStatement_12054 == 0)
    {
        goto L2; // [75] 1521
    }
    else{
    }

    /** 				if AnyTimeProfile then*/
    if (_27AnyTimeProfile_10945 == 0)
    {
        goto L4; // [82] 106
    }
    else{
    }

    /** 					Warning(224, mixed_profile_warning_flag)*/
    RefDS(_22037);
    _43Warning(224, 1024, _22037);

    /** 					OpProfileStatement = FALSE*/
    _26OpProfileStatement_12054 = _9FALSE_428;
    goto L2; // [103] 1521
L4: 

    /** 					AnyStatementProfile = TRUE*/
    _27AnyStatementProfile_10946 = _9TRUE_430;
    goto L2; // [118] 1521
L3: 

    /** 	elsif equal(option, "profile_time") then*/
    if (_option_60710 == _30528)
    _30529 = 1;
    else if (IS_ATOM_INT(_option_60710) && IS_ATOM_INT(_30528))
    _30529 = 0;
    else
    _30529 = (compare(_option_60710, _30528) == 0);
    if (_30529 == 0)
    {
        _30529 = NOVALUE;
        goto L5; // [127] 361
    }
    else{
        _30529 = NOVALUE;
    }

    /** 		if not TRANSLATE and not BIND then*/
    _30530 = (_26TRANSLATE_11619 == 0);
    if (_30530 == 0) {
        goto L2; // [137] 1521
    }
    _30532 = (_26BIND_11622 == 0);
    if (_30532 == 0)
    {
        DeRef(_30532);
        _30532 = NOVALUE;
        goto L2; // [147] 1521
    }
    else{
        DeRef(_30532);
        _30532 = NOVALUE;
    }

    /** 			if not IWINDOWS then*/
    if (_36IWINDOWS_14304 != 0)
    goto L6; // [154] 169

    /** 				if on_off then*/
    if (_on_off_60709 == 0)
    {
        goto L7; // [159] 168
    }
    else{
    }

    /** 					not_supported_compile("profile_time")*/
    RefDS(_30528);
    _30not_supported_compile(_30528);
L7: 
L6: 

    /** 			OpProfileTime = on_off*/
    _26OpProfileTime_12055 = _on_off_60709;

    /** 			if OpProfileTime then*/
    if (_26OpProfileTime_12055 == 0)
    {
        goto L8; // [180] 355
    }
    else{
    }

    /** 				if AnyStatementProfile then*/
    if (_27AnyStatementProfile_10946 == 0)
    {
        goto L9; // [187] 209
    }
    else{
    }

    /** 					Warning(224,mixed_profile_warning_flag)*/
    RefDS(_22037);
    _43Warning(224, 1024, _22037);

    /** 					OpProfileTime = FALSE*/
    _26OpProfileTime_12055 = _9FALSE_428;
L9: 

    /** 				token tok = next_token()*/
    _0 = _tok_60764;
    _tok_60764 = _30next_token();
    DeRef(_0);

    /** 				if tok[T_ID] = ATOM then*/
    _2 = (int)SEQ_PTR(_tok_60764);
    _30535 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30535, 502)){
        _30535 = NOVALUE;
        goto LA; // [224] 316
    }
    _30535 = NOVALUE;

    /** 					if integer(SymTab[tok[T_SYM]][S_OBJ]) then*/
    _2 = (int)SEQ_PTR(_tok_60764);
    _30537 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!IS_ATOM_INT(_30537)){
        _30538 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_30537)->dbl));
    }
    else{
        _30538 = (int)*(((s1_ptr)_2)->base + _30537);
    }
    _2 = (int)SEQ_PTR(_30538);
    _30539 = (int)*(((s1_ptr)_2)->base + 1);
    _30538 = NOVALUE;
    if (IS_ATOM_INT(_30539))
    _30540 = 1;
    else if (IS_ATOM_DBL(_30539))
    _30540 = IS_ATOM_INT(DoubleToInt(_30539));
    else
    _30540 = 0;
    _30539 = NOVALUE;
    if (_30540 == 0)
    {
        _30540 = NOVALUE;
        goto LB; // [251] 279
    }
    else{
        _30540 = NOVALUE;
    }

    /** 						sample_size = SymTab[tok[T_SYM]][S_OBJ]*/
    _2 = (int)SEQ_PTR(_tok_60764);
    _30541 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!IS_ATOM_INT(_30541)){
        _30542 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_30541)->dbl));
    }
    else{
        _30542 = (int)*(((s1_ptr)_2)->base + _30541);
    }
    _2 = (int)SEQ_PTR(_30542);
    _26sample_size_12083 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_26sample_size_12083)){
        _26sample_size_12083 = (long)DBL_PTR(_26sample_size_12083)->dbl;
    }
    _30542 = NOVALUE;
    goto LC; // [276] 287
LB: 

    /** 						sample_size = -1*/
    _26sample_size_12083 = -1;
LC: 

    /** 					if sample_size < 1 and OpProfileTime then*/
    _30544 = (_26sample_size_12083 < 1);
    if (_30544 == 0) {
        goto LD; // [295] 329
    }
    if (_26OpProfileTime_12055 == 0)
    {
        goto LD; // [302] 329
    }
    else{
    }

    /** 						CompileErr(136)*/
    RefDS(_22037);
    _43CompileErr(136, _22037, 0);
    goto LD; // [313] 329
LA: 

    /** 					putback(tok)*/
    Ref(_tok_60764);
    _30putback(_tok_60764);

    /** 					sample_size = DEFAULT_SAMPLE_SIZE*/
    _26sample_size_12083 = 25000;
LD: 

    /** 				if OpProfileTime then*/
    if (_26OpProfileTime_12055 == 0)
    {
        goto LE; // [333] 354
    }
    else{
    }

    /** 					if IWINDOWS then*/
    if (_36IWINDOWS_14304 == 0)
    {
        goto LF; // [340] 353
    }
    else{
    }

    /** 						AnyTimeProfile = TRUE*/
    _27AnyTimeProfile_10945 = _9TRUE_430;
LF: 
LE: 
L8: 
    DeRef(_tok_60764);
    _tok_60764 = NOVALUE;
    goto L2; // [358] 1521
L5: 

    /** 	elsif equal(option, "trace") then*/
    if (_option_60710 == _30546)
    _30547 = 1;
    else if (IS_ATOM_INT(_option_60710) && IS_ATOM_INT(_30546))
    _30547 = 0;
    else
    _30547 = (compare(_option_60710, _30546) == 0);
    if (_30547 == 0)
    {
        _30547 = NOVALUE;
        goto L10; // [367] 388
    }
    else{
        _30547 = NOVALUE;
    }

    /** 		if not BIND then*/
    if (_26BIND_11622 != 0)
    goto L2; // [374] 1521

    /** 			OpTrace = on_off*/
    _26OpTrace_12052 = _on_off_60709;
    goto L2; // [385] 1521
L10: 

    /** 	elsif equal(option, "warning") then*/
    if (_option_60710 == _30549)
    _30550 = 1;
    else if (IS_ATOM_INT(_option_60710) && IS_ATOM_INT(_30549))
    _30550 = 0;
    else
    _30550 = (compare(_option_60710, _30549) == 0);
    if (_30550 == 0)
    {
        _30550 = NOVALUE;
        goto L11; // [394] 1234
    }
    else{
        _30550 = NOVALUE;
    }

    /** 		integer good_sofar = line_number*/
    _good_sofar_60812 = _26line_number_11983;

    /** 		reset_flags = 1*/
    _reset_flags_60712 = 1;

    /** 		token tok = next_token()*/
    _0 = _tok_60815;
    _tok_60815 = _30next_token();
    DeRef(_0);

    /** 		integer warning_extra = 1*/
    _warning_extra_60817 = 1;

    /** 		if find(tok[T_ID], {CONCAT_EQUALS, PLUS_EQUALS}) != 0 then*/
    _2 = (int)SEQ_PTR(_tok_60815);
    _30552 = (int)*(((s1_ptr)_2)->base + 1);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 519;
    ((int *)_2)[2] = 515;
    _30553 = MAKE_SEQ(_1);
    _30554 = find_from(_30552, _30553, 1);
    _30552 = NOVALUE;
    DeRefDS(_30553);
    _30553 = NOVALUE;
    if (_30554 == 0)
    goto L12; // [442] 501

    /** 			tok = next_token()*/
    _0 = _tok_60815;
    _tok_60815 = _30next_token();
    DeRef(_0);

    /** 			if tok[T_ID] != LEFT_BRACE and tok[T_ID] != LEFT_ROUND then*/
    _2 = (int)SEQ_PTR(_tok_60815);
    _30557 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_30557)) {
        _30558 = (_30557 != -24);
    }
    else {
        _30558 = binary_op(NOTEQ, _30557, -24);
    }
    _30557 = NOVALUE;
    if (IS_ATOM_INT(_30558)) {
        if (_30558 == 0) {
            goto L13; // [465] 493
        }
    }
    else {
        if (DBL_PTR(_30558)->dbl == 0.0) {
            goto L13; // [465] 493
        }
    }
    _2 = (int)SEQ_PTR(_tok_60815);
    _30560 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_30560)) {
        _30561 = (_30560 != -26);
    }
    else {
        _30561 = binary_op(NOTEQ, _30560, -26);
    }
    _30560 = NOVALUE;
    if (_30561 == 0) {
        DeRef(_30561);
        _30561 = NOVALUE;
        goto L13; // [482] 493
    }
    else {
        if (!IS_ATOM_INT(_30561) && DBL_PTR(_30561)->dbl == 0.0){
            DeRef(_30561);
            _30561 = NOVALUE;
            goto L13; // [482] 493
        }
        DeRef(_30561);
        _30561 = NOVALUE;
    }
    DeRef(_30561);
    _30561 = NOVALUE;

    /** 				CompileErr(160)*/
    RefDS(_22037);
    _43CompileErr(160, _22037, 0);
L13: 

    /** 			reset_flags = 0*/
    _reset_flags_60712 = 0;
    goto L14; // [498] 727
L12: 

    /** 		elsif tok[T_ID] = EQUALS then*/
    _2 = (int)SEQ_PTR(_tok_60815);
    _30562 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30562, 3)){
        _30562 = NOVALUE;
        goto L15; // [511] 570
    }
    _30562 = NOVALUE;

    /** 			tok = next_token()*/
    _0 = _tok_60815;
    _tok_60815 = _30next_token();
    DeRef(_0);

    /** 			if tok[T_ID] != LEFT_BRACE and tok[T_ID] != LEFT_ROUND then*/
    _2 = (int)SEQ_PTR(_tok_60815);
    _30565 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_30565)) {
        _30566 = (_30565 != -24);
    }
    else {
        _30566 = binary_op(NOTEQ, _30565, -24);
    }
    _30565 = NOVALUE;
    if (IS_ATOM_INT(_30566)) {
        if (_30566 == 0) {
            goto L16; // [534] 562
        }
    }
    else {
        if (DBL_PTR(_30566)->dbl == 0.0) {
            goto L16; // [534] 562
        }
    }
    _2 = (int)SEQ_PTR(_tok_60815);
    _30568 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_30568)) {
        _30569 = (_30568 != -26);
    }
    else {
        _30569 = binary_op(NOTEQ, _30568, -26);
    }
    _30568 = NOVALUE;
    if (_30569 == 0) {
        DeRef(_30569);
        _30569 = NOVALUE;
        goto L16; // [551] 562
    }
    else {
        if (!IS_ATOM_INT(_30569) && DBL_PTR(_30569)->dbl == 0.0){
            DeRef(_30569);
            _30569 = NOVALUE;
            goto L16; // [551] 562
        }
        DeRef(_30569);
        _30569 = NOVALUE;
    }
    DeRef(_30569);
    _30569 = NOVALUE;

    /** 				CompileErr(160)*/
    RefDS(_22037);
    _43CompileErr(160, _22037, 0);
L16: 

    /** 			reset_flags = 1*/
    _reset_flags_60712 = 1;
    goto L14; // [567] 727
L15: 

    /** 		elsif tok[T_ID] = VARIABLE then*/
    _2 = (int)SEQ_PTR(_tok_60815);
    _30570 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30570, -100)){
        _30570 = NOVALUE;
        goto L17; // [580] 726
    }
    _30570 = NOVALUE;

    /** 			option = SymTab[tok[T_SYM]][S_NAME]*/
    _2 = (int)SEQ_PTR(_tok_60815);
    _30572 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!IS_ATOM_INT(_30572)){
        _30573 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_30572)->dbl));
    }
    else{
        _30573 = (int)*(((s1_ptr)_2)->base + _30572);
    }
    DeRef(_option_60710);
    _2 = (int)SEQ_PTR(_30573);
    if (!IS_ATOM_INT(_26S_NAME_11654)){
        _option_60710 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NAME_11654)->dbl));
    }
    else{
        _option_60710 = (int)*(((s1_ptr)_2)->base + _26S_NAME_11654);
    }
    Ref(_option_60710);
    _30573 = NOVALUE;

    /** 			if equal(option, "save") then*/
    if (_option_60710 == _30575)
    _30576 = 1;
    else if (IS_ATOM_INT(_option_60710) && IS_ATOM_INT(_30575))
    _30576 = 0;
    else
    _30576 = (compare(_option_60710, _30575) == 0);
    if (_30576 == 0)
    {
        _30576 = NOVALUE;
        goto L18; // [612] 636
    }
    else{
        _30576 = NOVALUE;
    }

    /** 				prev_OpWarning = OpWarning*/
    _26prev_OpWarning_12051 = _26OpWarning_12050;

    /** 				warning_extra = FALSE*/
    _warning_extra_60817 = _9FALSE_428;
    goto L19; // [633] 725
L18: 

    /** 			elsif equal(option, "restore") then*/
    if (_option_60710 == _30577)
    _30578 = 1;
    else if (IS_ATOM_INT(_option_60710) && IS_ATOM_INT(_30577))
    _30578 = 0;
    else
    _30578 = (compare(_option_60710, _30577) == 0);
    if (_30578 == 0)
    {
        _30578 = NOVALUE;
        goto L1A; // [642] 666
    }
    else{
        _30578 = NOVALUE;
    }

    /** 				OpWarning = prev_OpWarning*/
    _26OpWarning_12050 = _26prev_OpWarning_12051;

    /** 				warning_extra = FALSE*/
    _warning_extra_60817 = _9FALSE_428;
    goto L19; // [663] 725
L1A: 

    /** 			elsif equal(option, "strict") then*/
    if (_option_60710 == _25574)
    _30579 = 1;
    else if (IS_ATOM_INT(_option_60710) && IS_ATOM_INT(_25574))
    _30579 = 0;
    else
    _30579 = (compare(_option_60710, _25574) == 0);
    if (_30579 == 0)
    {
        _30579 = NOVALUE;
        goto L1B; // [672] 724
    }
    else{
        _30579 = NOVALUE;
    }

    /** 				if on_off = 0 then*/
    if (_on_off_60709 != 0)
    goto L1C; // [677] 694

    /** 					Strict_Override += 1*/
    _26Strict_Override_12049 = _26Strict_Override_12049 + 1;
    goto L1D; // [691] 714
L1C: 

    /** 				elsif Strict_Override > 0 then*/
    if (_26Strict_Override_12049 <= 0)
    goto L1E; // [698] 713

    /** 					Strict_Override -= 1*/
    _26Strict_Override_12049 = _26Strict_Override_12049 - 1;
L1E: 
L1D: 

    /** 				warning_extra = FALSE*/
    _warning_extra_60817 = _9FALSE_428;
L1B: 
L19: 
L17: 
L14: 

    /** 		if warning_extra = TRUE then*/
    if (_warning_extra_60817 != _9TRUE_430)
    goto L1F; // [731] 1229

    /** 			if reset_flags then*/
    if (_reset_flags_60712 == 0)
    {
        goto L20; // [737] 769
    }
    else{
    }

    /** 				if on_off = 0 then*/
    if (_on_off_60709 != 0)
    goto L21; // [742] 758

    /** 					OpWarning = no_warning_flag*/
    _26OpWarning_12050 = 0;
    goto L22; // [755] 768
L21: 

    /** 					OpWarning = all_warning_flag*/
    _26OpWarning_12050 = 32767;
L22: 
L20: 

    /** 			if find(tok[T_ID], {LEFT_BRACE, LEFT_ROUND}) then*/
    _2 = (int)SEQ_PTR(_tok_60815);
    _30586 = (int)*(((s1_ptr)_2)->base + 1);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -24;
    ((int *)_2)[2] = -26;
    _30587 = MAKE_SEQ(_1);
    _30588 = find_from(_30586, _30587, 1);
    _30586 = NOVALUE;
    DeRefDS(_30587);
    _30587 = NOVALUE;
    if (_30588 == 0)
    {
        _30588 = NOVALUE;
        goto L23; // [790] 1222
    }
    else{
        _30588 = NOVALUE;
    }

    /** 				integer endlist*/

    /** 				if tok[T_ID] = LEFT_BRACE then*/
    _2 = (int)SEQ_PTR(_tok_60815);
    _30589 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30589, -24)){
        _30589 = NOVALUE;
        goto L24; // [805] 821
    }
    _30589 = NOVALUE;

    /** 					endlist = RIGHT_BRACE*/
    _endlist_60908 = -25;
    goto L25; // [818] 831
L24: 

    /** 					endlist = RIGHT_ROUND*/
    _endlist_60908 = -27;
L25: 

    /** 				tok = next_token()*/
    _0 = _tok_60815;
    _tok_60815 = _30next_token();
    DeRef(_0);

    /** 				while tok[T_ID] != endlist do*/
L26: 
    _2 = (int)SEQ_PTR(_tok_60815);
    _30592 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _30592, _endlist_60908)){
        _30592 = NOVALUE;
        goto L27; // [849] 1217
    }
    _30592 = NOVALUE;

    /** 					if tok[T_ID] = COMMA then*/
    _2 = (int)SEQ_PTR(_tok_60815);
    _30594 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30594, -30)){
        _30594 = NOVALUE;
        goto L28; // [863] 877
    }
    _30594 = NOVALUE;

    /** 						tok = next_token()*/
    _0 = _tok_60815;
    _tok_60815 = _30next_token();
    DeRef(_0);

    /** 						continue*/
    goto L26; // [874] 841
L28: 

    /** 					if tok[T_ID] = STRING then*/
    _2 = (int)SEQ_PTR(_tok_60815);
    _30597 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30597, 503)){
        _30597 = NOVALUE;
        goto L29; // [887] 916
    }
    _30597 = NOVALUE;

    /** 						option = SymTab[tok[T_SYM]][S_OBJ]*/
    _2 = (int)SEQ_PTR(_tok_60815);
    _30599 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!IS_ATOM_INT(_30599)){
        _30600 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_30599)->dbl));
    }
    else{
        _30600 = (int)*(((s1_ptr)_2)->base + _30599);
    }
    DeRef(_option_60710);
    _2 = (int)SEQ_PTR(_30600);
    _option_60710 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_option_60710);
    _30600 = NOVALUE;
    goto L2A; // [913] 1064
L29: 

    /** 					elsif length(SymTab[tok[T_SYM]]) >= S_NAME then*/
    _2 = (int)SEQ_PTR(_tok_60815);
    _30602 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!IS_ATOM_INT(_30602)){
        _30603 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_30602)->dbl));
    }
    else{
        _30603 = (int)*(((s1_ptr)_2)->base + _30602);
    }
    if (IS_SEQUENCE(_30603)){
            _30604 = SEQ_PTR(_30603)->length;
    }
    else {
        _30604 = 1;
    }
    _30603 = NOVALUE;
    if (binary_op_a(LESS, _30604, _26S_NAME_11654)){
        _30604 = NOVALUE;
        goto L2B; // [935] 964
    }
    _30604 = NOVALUE;

    /** 						option = SymTab[tok[T_SYM]][S_NAME]*/
    _2 = (int)SEQ_PTR(_tok_60815);
    _30606 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!IS_ATOM_INT(_30606)){
        _30607 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_30606)->dbl));
    }
    else{
        _30607 = (int)*(((s1_ptr)_2)->base + _30606);
    }
    DeRef(_option_60710);
    _2 = (int)SEQ_PTR(_30607);
    if (!IS_ATOM_INT(_26S_NAME_11654)){
        _option_60710 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NAME_11654)->dbl));
    }
    else{
        _option_60710 = (int)*(((s1_ptr)_2)->base + _26S_NAME_11654);
    }
    Ref(_option_60710);
    _30607 = NOVALUE;
    goto L2A; // [961] 1064
L2B: 

    /** 						option = ""*/
    RefDS(_22037);
    DeRef(_option_60710);
    _option_60710 = _22037;

    /** 						for k = 1 to length(keylist) do*/
    if (IS_SEQUENCE(_62keylist_22870)){
            _30609 = SEQ_PTR(_62keylist_22870)->length;
    }
    else {
        _30609 = 1;
    }
    {
        int _k_60955;
        _k_60955 = 1;
L2C: 
        if (_k_60955 > _30609){
            goto L2D; // [978] 1063
        }

        /** 							if keylist[k][S_SCOPE] = SC_KEYWORD and*/
        _2 = (int)SEQ_PTR(_62keylist_22870);
        _30610 = (int)*(((s1_ptr)_2)->base + _k_60955);
        _2 = (int)SEQ_PTR(_30610);
        _30611 = (int)*(((s1_ptr)_2)->base + 4);
        _30610 = NOVALUE;
        if (IS_ATOM_INT(_30611)) {
            _30612 = (_30611 == 8);
        }
        else {
            _30612 = binary_op(EQUALS, _30611, 8);
        }
        _30611 = NOVALUE;
        if (IS_ATOM_INT(_30612)) {
            if (_30612 == 0) {
                goto L2E; // [1005] 1056
            }
        }
        else {
            if (DBL_PTR(_30612)->dbl == 0.0) {
                goto L2E; // [1005] 1056
            }
        }
        _2 = (int)SEQ_PTR(_62keylist_22870);
        _30614 = (int)*(((s1_ptr)_2)->base + _k_60955);
        _2 = (int)SEQ_PTR(_30614);
        if (!IS_ATOM_INT(_26S_TOKEN_11659)){
            _30615 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_TOKEN_11659)->dbl));
        }
        else{
            _30615 = (int)*(((s1_ptr)_2)->base + _26S_TOKEN_11659);
        }
        _30614 = NOVALUE;
        _2 = (int)SEQ_PTR(_tok_60815);
        _30616 = (int)*(((s1_ptr)_2)->base + 1);
        if (IS_ATOM_INT(_30615) && IS_ATOM_INT(_30616)) {
            _30617 = (_30615 == _30616);
        }
        else {
            _30617 = binary_op(EQUALS, _30615, _30616);
        }
        _30615 = NOVALUE;
        _30616 = NOVALUE;
        if (_30617 == 0) {
            DeRef(_30617);
            _30617 = NOVALUE;
            goto L2E; // [1032] 1056
        }
        else {
            if (!IS_ATOM_INT(_30617) && DBL_PTR(_30617)->dbl == 0.0){
                DeRef(_30617);
                _30617 = NOVALUE;
                goto L2E; // [1032] 1056
            }
            DeRef(_30617);
            _30617 = NOVALUE;
        }
        DeRef(_30617);
        _30617 = NOVALUE;

        /** 									option = keylist[k][S_NAME]*/
        _2 = (int)SEQ_PTR(_62keylist_22870);
        _30618 = (int)*(((s1_ptr)_2)->base + _k_60955);
        DeRef(_option_60710);
        _2 = (int)SEQ_PTR(_30618);
        if (!IS_ATOM_INT(_26S_NAME_11654)){
            _option_60710 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NAME_11654)->dbl));
        }
        else{
            _option_60710 = (int)*(((s1_ptr)_2)->base + _26S_NAME_11654);
        }
        Ref(_option_60710);
        _30618 = NOVALUE;

        /** 									exit*/
        goto L2D; // [1053] 1063
L2E: 

        /** 						end for*/
        _k_60955 = _k_60955 + 1;
        goto L2C; // [1058] 985
L2D: 
        ;
    }
L2A: 

    /** 					idx = find(option, warning_names)*/
    _idx_60711 = find_from(_option_60710, _26warning_names_12027, 1);

    /** 					if idx = 0 then*/
    if (_idx_60711 != 0)
    goto L2F; // [1075] 1128

    /** 	 					if good_sofar != line_number then*/
    if (_good_sofar_60812 == _26line_number_11983)
    goto L30; // [1083] 1095

    /**  							CompileErr(147)*/
    RefDS(_22037);
    _43CompileErr(147, _22037, 0);
L30: 

    /** 						Warning(225, 0,*/
    _2 = (int)SEQ_PTR(_27known_files_10922);
    _30623 = (int)*(((s1_ptr)_2)->base + _26current_file_no_11982);
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_30623);
    *((int *)(_2+4)) = _30623;
    *((int *)(_2+8)) = _26line_number_11983;
    RefDS(_option_60710);
    *((int *)(_2+12)) = _option_60710;
    _30624 = MAKE_SEQ(_1);
    _30623 = NOVALUE;
    _43Warning(225, 0, _30624);
    _30624 = NOVALUE;

    /** 						tok = next_token()*/
    _0 = _tok_60815;
    _tok_60815 = _30next_token();
    DeRef(_0);

    /** 						continue*/
    goto L26; // [1125] 841
L2F: 

    /** 					idx = warning_flags[idx]*/
    _2 = (int)SEQ_PTR(_26warning_flags_12025);
    _idx_60711 = (int)*(((s1_ptr)_2)->base + _idx_60711);

    /** 					if idx = 0 then*/
    if (_idx_60711 != 0)
    goto L31; // [1140] 1174

    /** 						if on_off then*/
    if (_on_off_60709 == 0)
    {
        goto L32; // [1146] 1161
    }
    else{
    }

    /** 							OpWarning = no_warning_flag*/
    _26OpWarning_12050 = 0;
    goto L33; // [1158] 1207
L32: 

    /** 						    OpWarning = all_warning_flag*/
    _26OpWarning_12050 = 32767;
    goto L33; // [1171] 1207
L31: 

    /** 						if on_off then*/
    if (_on_off_60709 == 0)
    {
        goto L34; // [1176] 1192
    }
    else{
    }

    /** 							OpWarning = or_bits(OpWarning, idx)*/
    {unsigned long tu;
         tu = (unsigned long)_26OpWarning_12050 | (unsigned long)_idx_60711;
         _26OpWarning_12050 = MAKE_UINT(tu);
    }
    if (!IS_ATOM_INT(_26OpWarning_12050)) {
        _1 = (long)(DBL_PTR(_26OpWarning_12050)->dbl);
        DeRefDS(_26OpWarning_12050);
        _26OpWarning_12050 = _1;
    }
    goto L35; // [1189] 1206
L34: 

    /** 						    OpWarning = and_bits(OpWarning, not_bits(idx))*/
    _30629 = not_bits(_idx_60711);
    if (IS_ATOM_INT(_30629)) {
        {unsigned long tu;
             tu = (unsigned long)_26OpWarning_12050 & (unsigned long)_30629;
             _26OpWarning_12050 = MAKE_UINT(tu);
        }
    }
    else {
        temp_d.dbl = (double)_26OpWarning_12050;
        _26OpWarning_12050 = Dand_bits(&temp_d, DBL_PTR(_30629));
    }
    DeRef(_30629);
    _30629 = NOVALUE;
    if (!IS_ATOM_INT(_26OpWarning_12050)) {
        _1 = (long)(DBL_PTR(_26OpWarning_12050)->dbl);
        DeRefDS(_26OpWarning_12050);
        _26OpWarning_12050 = _1;
    }
L35: 
L33: 

    /** 					tok = next_token()*/
    _0 = _tok_60815;
    _tok_60815 = _30next_token();
    DeRef(_0);

    /** 				end while*/
    goto L26; // [1214] 841
L27: 
    goto L36; // [1219] 1228
L23: 

    /** 				putback(tok)*/
    Ref(_tok_60815);
    _30putback(_tok_60815);
L36: 
L1F: 
    DeRef(_tok_60815);
    _tok_60815 = NOVALUE;
    goto L2; // [1231] 1521
L11: 

    /** 	elsif equal(option, "define") then*/
    if (_option_60710 == _30632)
    _30633 = 1;
    else if (IS_ATOM_INT(_option_60710) && IS_ATOM_INT(_30632))
    _30633 = 0;
    else
    _30633 = (compare(_option_60710, _30632) == 0);
    if (_30633 == 0)
    {
        _30633 = NOVALUE;
        goto L37; // [1240] 1363
    }
    else{
        _30633 = NOVALUE;
    }

    /** 		option = StringToken()*/
    RefDS(_5);
    _0 = _option_60710;
    _option_60710 = _60StringToken(_5);
    DeRefDS(_0);

    /** 		if length(option) = 0 then*/
    if (IS_SEQUENCE(_option_60710)){
            _30635 = SEQ_PTR(_option_60710)->length;
    }
    else {
        _30635 = 1;
    }
    if (_30635 != 0)
    goto L38; // [1256] 1270

    /** 			CompileErr(81)*/
    RefDS(_22037);
    _43CompileErr(81, _22037, 0);
    goto L39; // [1267] 1288
L38: 

    /** 		elsif not t_identifier(option) then*/
    RefDS(_option_60710);
    _30637 = _9t_identifier(_option_60710);
    if (IS_ATOM_INT(_30637)) {
        if (_30637 != 0){
            DeRef(_30637);
            _30637 = NOVALUE;
            goto L3A; // [1276] 1287
        }
    }
    else {
        if (DBL_PTR(_30637)->dbl != 0.0){
            DeRef(_30637);
            _30637 = NOVALUE;
            goto L3A; // [1276] 1287
        }
    }
    DeRef(_30637);
    _30637 = NOVALUE;

    /** 			CompileErr(61)*/
    RefDS(_22037);
    _43CompileErr(61, _22037, 0);
L3A: 
L39: 

    /** 		if on_off = 0 then*/
    if (_on_off_60709 != 0)
    goto L3B; // [1290] 1345

    /** 			idx = find(option, OpDefines)*/
    _idx_60711 = find_from(_option_60710, _26OpDefines_12056, 1);

    /** 			if idx then*/
    if (_idx_60711 == 0)
    {
        goto L2; // [1305] 1521
    }
    else{
    }

    /** 				OpDefines = OpDefines[1..idx-1]&OpDefines[idx+1..$]*/
    _30641 = _idx_60711 - 1;
    rhs_slice_target = (object_ptr)&_30642;
    RHS_Slice(_26OpDefines_12056, 1, _30641);
    _30643 = _idx_60711 + 1;
    if (IS_SEQUENCE(_26OpDefines_12056)){
            _30644 = SEQ_PTR(_26OpDefines_12056)->length;
    }
    else {
        _30644 = 1;
    }
    rhs_slice_target = (object_ptr)&_30645;
    RHS_Slice(_26OpDefines_12056, _30643, _30644);
    Concat((object_ptr)&_26OpDefines_12056, _30642, _30645);
    DeRefDS(_30642);
    _30642 = NOVALUE;
    DeRef(_30642);
    _30642 = NOVALUE;
    DeRefDS(_30645);
    _30645 = NOVALUE;
    goto L2; // [1342] 1521
L3B: 

    /** 			OpDefines &= {option}*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_option_60710);
    *((int *)(_2+4)) = _option_60710;
    _30647 = MAKE_SEQ(_1);
    Concat((object_ptr)&_26OpDefines_12056, _26OpDefines_12056, _30647);
    DeRefDS(_30647);
    _30647 = NOVALUE;
    goto L2; // [1360] 1521
L37: 

    /** 	elsif equal(option, "inline") then*/
    if (_option_60710 == _30649)
    _30650 = 1;
    else if (IS_ATOM_INT(_option_60710) && IS_ATOM_INT(_30649))
    _30650 = 0;
    else
    _30650 = (compare(_option_60710, _30649) == 0);
    if (_30650 == 0)
    {
        _30650 = NOVALUE;
        goto L3C; // [1369] 1455
    }
    else{
        _30650 = NOVALUE;
    }

    /** 		if on_off then*/
    if (_on_off_60709 == 0)
    {
        goto L3D; // [1374] 1444
    }
    else{
    }

    /** 			token tok = next_token()*/
    _0 = _tok_61051;
    _tok_61051 = _30next_token();
    DeRef(_0);

    /** 			if tok[T_ID] = ATOM then*/
    _2 = (int)SEQ_PTR(_tok_61051);
    _30652 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30652, 502)){
        _30652 = NOVALUE;
        goto L3E; // [1392] 1424
    }
    _30652 = NOVALUE;

    /** 				OpInline = floor( SymTab[tok[T_SYM]][S_OBJ] )*/
    _2 = (int)SEQ_PTR(_tok_61051);
    _30654 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!IS_ATOM_INT(_30654)){
        _30655 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_30654)->dbl));
    }
    else{
        _30655 = (int)*(((s1_ptr)_2)->base + _30654);
    }
    _2 = (int)SEQ_PTR(_30655);
    _30656 = (int)*(((s1_ptr)_2)->base + 1);
    _30655 = NOVALUE;
    if (IS_ATOM_INT(_30656))
    _26OpInline_12057 = e_floor(_30656);
    else
    _26OpInline_12057 = unary_op(FLOOR, _30656);
    _30656 = NOVALUE;
    if (!IS_ATOM_INT(_26OpInline_12057)) {
        _1 = (long)(DBL_PTR(_26OpInline_12057)->dbl);
        DeRefDS(_26OpInline_12057);
        _26OpInline_12057 = _1;
    }
    goto L3F; // [1421] 1439
L3E: 

    /** 				putback(tok)*/
    Ref(_tok_61051);
    _30putback(_tok_61051);

    /** 				OpInline = DEFAULT_INLINE*/
    _26OpInline_12057 = 30;
L3F: 
    DeRef(_tok_61051);
    _tok_61051 = NOVALUE;
    goto L2; // [1441] 1521
L3D: 

    /** 			OpInline = 0*/
    _26OpInline_12057 = 0;
    goto L2; // [1452] 1521
L3C: 

    /** 	elsif equal( option, "indirect_includes" ) then*/
    if (_option_60710 == _30658)
    _30659 = 1;
    else if (IS_ATOM_INT(_option_60710) && IS_ATOM_INT(_30658))
    _30659 = 0;
    else
    _30659 = (compare(_option_60710, _30658) == 0);
    if (_30659 == 0)
    {
        _30659 = NOVALUE;
        goto L40; // [1461] 1474
    }
    else{
        _30659 = NOVALUE;
    }

    /** 		OpIndirectInclude = on_off*/
    _26OpIndirectInclude_12058 = _on_off_60709;
    goto L2; // [1471] 1521
L40: 

    /** 	elsif equal(option, "batch") then*/
    if (_option_60710 == _25571)
    _30660 = 1;
    else if (IS_ATOM_INT(_option_60710) && IS_ATOM_INT(_25571))
    _30660 = 0;
    else
    _30660 = (compare(_option_60710, _25571) == 0);
    if (_30660 == 0)
    {
        _30660 = NOVALUE;
        goto L41; // [1480] 1493
    }
    else{
        _30660 = NOVALUE;
    }

    /** 		batch_job = on_off*/
    _26batch_job_11995 = _on_off_60709;
    goto L2; // [1490] 1521
L41: 

    /** 	elsif integer(to_number(option, -1)) then*/
    RefDS(_option_60710);
    _30661 = _13to_number(_option_60710, -1);
    if (IS_ATOM_INT(_30661))
    _30662 = 1;
    else if (IS_ATOM_DBL(_30661))
    _30662 = IS_ATOM_INT(DoubleToInt(_30661));
    else
    _30662 = 0;
    DeRef(_30661);
    _30661 = NOVALUE;
    if (_30662 == 0)
    {
        _30662 = NOVALUE;
        goto L42; // [1503] 1509
    }
    else{
        _30662 = NOVALUE;
    }
    goto L2; // [1506] 1521
L42: 

    /** 		CompileErr(154, {option})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_option_60710);
    *((int *)(_2+4)) = _option_60710;
    _30663 = MAKE_SEQ(_1);
    _43CompileErr(154, _30663, 0);
    _30663 = NOVALUE;
L2: 

    /** end procedure*/
    DeRef(_option_60710);
    DeRef(_30525);
    _30525 = NOVALUE;
    DeRef(_30530);
    _30530 = NOVALUE;
    _30537 = NOVALUE;
    _30541 = NOVALUE;
    DeRef(_30544);
    _30544 = NOVALUE;
    _30572 = NOVALUE;
    DeRef(_30558);
    _30558 = NOVALUE;
    DeRef(_30566);
    _30566 = NOVALUE;
    _30599 = NOVALUE;
    _30602 = NOVALUE;
    _30603 = NOVALUE;
    _30606 = NOVALUE;
    DeRef(_30641);
    _30641 = NOVALUE;
    DeRef(_30612);
    _30612 = NOVALUE;
    _30654 = NOVALUE;
    DeRef(_30643);
    _30643 = NOVALUE;
    return;
    ;
}


void _30ExecCommand()
{
    int _0, _1, _2;
    

    /** 	if TRANSLATE then*/
    if (_26TRANSLATE_11619 == 0)
    {
        goto L1; // [5] 16
    }
    else{
    }

    /** 		emit_op(RETURNT)*/
    _37emit_op(34);
L1: 

    /** 	StraightenBranches()  -- straighten top-level*/
    _30StraightenBranches();

    /** end procedure*/
    return;
    ;
}


int _30undefined_var(int _tok_61094, int _scope_61095)
{
    int _forward_61097 = NOVALUE;
    int _30669 = NOVALUE;
    int _30668 = NOVALUE;
    int _30665 = NOVALUE;
    int _0, _1, _2;
    

    /** 	token forward = next_token()*/
    _0 = _forward_61097;
    _forward_61097 = _30next_token();
    DeRef(_0);

    /** 		switch forward[T_ID] do*/
    _2 = (int)SEQ_PTR(_forward_61097);
    _30665 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_30665) ){
        goto L1; // [16] 82
    }
    if(!IS_ATOM_INT(_30665)){
        if( (DBL_PTR(_30665)->dbl != (double) ((int) DBL_PTR(_30665)->dbl) ) ){
            goto L1; // [16] 82
        }
        _0 = (int) DBL_PTR(_30665)->dbl;
    }
    else {
        _0 = _30665;
    };
    _30665 = NOVALUE;
    switch ( _0 ){ 

        /** 			case LEFT_ROUND then*/
        case -26:

        /** 				StartSourceLine( TRUE )*/
        _37StartSourceLine(_9TRUE_430, 0, 2);

        /** 				Forward_call( tok )*/
        Ref(_tok_61094);
        _30Forward_call(_tok_61094, 195);

        /** 				return 1*/
        DeRef(_tok_61094);
        DeRef(_forward_61097);
        return 1;
        goto L2; // [48] 96

        /** 			case VARIABLE then*/
        case -100:

        /** 				putback( forward )*/
        Ref(_forward_61097);
        _30putback(_forward_61097);

        /** 				Global_declaration( tok[T_SYM], scope )*/
        _2 = (int)SEQ_PTR(_tok_61094);
        _30668 = (int)*(((s1_ptr)_2)->base + 2);
        Ref(_30668);
        _30669 = _30Global_declaration(_30668, _scope_61095);
        _30668 = NOVALUE;

        /** 				return 1*/
        DeRef(_tok_61094);
        DeRef(_forward_61097);
        DeRef(_30669);
        _30669 = NOVALUE;
        return 1;
        goto L2; // [78] 96

        /** 			case else*/
        default:
L1: 

        /** 				putback( forward )*/
        Ref(_forward_61097);
        _30putback(_forward_61097);

        /** 				return 0*/
        DeRef(_tok_61094);
        DeRef(_forward_61097);
        DeRef(_30669);
        _30669 = NOVALUE;
        return 0;
    ;}L2: 
    ;
}


void _30real_parser(int _nested_61116)
{
    int _tok_61118 = NOVALUE;
    int _id_61119 = NOVALUE;
    int _scope_61120 = NOVALUE;
    int _test_61261 = NOVALUE;
    int _30802 = NOVALUE;
    int _30800 = NOVALUE;
    int _30799 = NOVALUE;
    int _30798 = NOVALUE;
    int _30797 = NOVALUE;
    int _30796 = NOVALUE;
    int _30795 = NOVALUE;
    int _30794 = NOVALUE;
    int _30789 = NOVALUE;
    int _30788 = NOVALUE;
    int _30785 = NOVALUE;
    int _30783 = NOVALUE;
    int _30782 = NOVALUE;
    int _30779 = NOVALUE;
    int _30766 = NOVALUE;
    int _30759 = NOVALUE;
    int _30758 = NOVALUE;
    int _30756 = NOVALUE;
    int _30754 = NOVALUE;
    int _30753 = NOVALUE;
    int _30751 = NOVALUE;
    int _30749 = NOVALUE;
    int _30744 = NOVALUE;
    int _30742 = NOVALUE;
    int _30740 = NOVALUE;
    int _30739 = NOVALUE;
    int _30738 = NOVALUE;
    int _30736 = NOVALUE;
    int _30734 = NOVALUE;
    int _30732 = NOVALUE;
    int _30730 = NOVALUE;
    int _30729 = NOVALUE;
    int _30728 = NOVALUE;
    int _30727 = NOVALUE;
    int _30726 = NOVALUE;
    int _30725 = NOVALUE;
    int _30724 = NOVALUE;
    int _30723 = NOVALUE;
    int _30722 = NOVALUE;
    int _30721 = NOVALUE;
    int _30720 = NOVALUE;
    int _30719 = NOVALUE;
    int _30718 = NOVALUE;
    int _30717 = NOVALUE;
    int _30715 = NOVALUE;
    int _30714 = NOVALUE;
    int _30713 = NOVALUE;
    int _30712 = NOVALUE;
    int _30710 = NOVALUE;
    int _30708 = NOVALUE;
    int _30707 = NOVALUE;
    int _30706 = NOVALUE;
    int _30704 = NOVALUE;
    int _30697 = NOVALUE;
    int _30695 = NOVALUE;
    int _30694 = NOVALUE;
    int _30693 = NOVALUE;
    int _30692 = NOVALUE;
    int _30691 = NOVALUE;
    int _30690 = NOVALUE;
    int _30689 = NOVALUE;
    int _30687 = NOVALUE;
    int _30686 = NOVALUE;
    int _30685 = NOVALUE;
    int _30684 = NOVALUE;
    int _30683 = NOVALUE;
    int _30682 = NOVALUE;
    int _30681 = NOVALUE;
    int _30680 = NOVALUE;
    int _30679 = NOVALUE;
    int _30678 = NOVALUE;
    int _30676 = NOVALUE;
    int _30672 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_nested_61116)) {
        _1 = (long)(DBL_PTR(_nested_61116)->dbl);
        DeRefDS(_nested_61116);
        _nested_61116 = _1;
    }

    /** 	integer id*/

    /** 	integer scope*/

    /** 	while TRUE do  -- infinite loop until scanner aborts*/
L1: 
    if (_9TRUE_430 == 0)
    {
        goto L2; // [14] 1811
    }
    else{
    }

    /** 		if OpInline = 25000 then*/
    if (_26OpInline_12057 != 25000)
    goto L3; // [21] 35

    /** 			CompileErr("OpInline went nuts: [1]", OpInline )*/
    RefDS(_30671);
    _43CompileErr(_30671, _26OpInline_12057, 0);
L3: 

    /** 		start_index = length(Code)+1*/
    if (IS_SEQUENCE(_26Code_12071)){
            _30672 = SEQ_PTR(_26Code_12071)->length;
    }
    else {
        _30672 = 1;
    }
    _30start_index_54162 = _30672 + 1;
    _30672 = NOVALUE;

    /** 		tok = next_token()*/
    _0 = _tok_61118;
    _tok_61118 = _30next_token();
    DeRef(_0);

    /** 		id = tok[T_ID]*/
    _2 = (int)SEQ_PTR(_tok_61118);
    _id_61119 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_id_61119)){
        _id_61119 = (long)DBL_PTR(_id_61119)->dbl;
    }

    /** 		if id = VARIABLE or id = QUALIFIED_VARIABLE then*/
    _30676 = (_id_61119 == -100);
    if (_30676 != 0) {
        goto L4; // [69] 84
    }
    _30678 = (_id_61119 == 512);
    if (_30678 == 0)
    {
        DeRef(_30678);
        _30678 = NOVALUE;
        goto L5; // [80] 151
    }
    else{
        DeRef(_30678);
        _30678 = NOVALUE;
    }
L4: 

    /** 			if SymTab[tok[T_SYM]][S_SCOPE] = SC_UNDEFINED*/
    _2 = (int)SEQ_PTR(_tok_61118);
    _30679 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!IS_ATOM_INT(_30679)){
        _30680 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_30679)->dbl));
    }
    else{
        _30680 = (int)*(((s1_ptr)_2)->base + _30679);
    }
    _2 = (int)SEQ_PTR(_30680);
    _30681 = (int)*(((s1_ptr)_2)->base + 4);
    _30680 = NOVALUE;
    if (IS_ATOM_INT(_30681)) {
        _30682 = (_30681 == 9);
    }
    else {
        _30682 = binary_op(EQUALS, _30681, 9);
    }
    _30681 = NOVALUE;
    if (IS_ATOM_INT(_30682)) {
        if (_30682 == 0) {
            goto L6; // [110] 130
        }
    }
    else {
        if (DBL_PTR(_30682)->dbl == 0.0) {
            goto L6; // [110] 130
        }
    }
    Ref(_tok_61118);
    _30684 = _30undefined_var(_tok_61118, 5);
    if (_30684 == 0) {
        DeRef(_30684);
        _30684 = NOVALUE;
        goto L6; // [122] 130
    }
    else {
        if (!IS_ATOM_INT(_30684) && DBL_PTR(_30684)->dbl == 0.0){
            DeRef(_30684);
            _30684 = NOVALUE;
            goto L6; // [122] 130
        }
        DeRef(_30684);
        _30684 = NOVALUE;
    }
    DeRef(_30684);
    _30684 = NOVALUE;

    /** 				continue*/
    goto L1; // [127] 12
L6: 

    /** 			StartSourceLine(TRUE)*/
    _37StartSourceLine(_9TRUE_430, 0, 2);

    /** 			Assignment(tok)*/
    Ref(_tok_61118);
    _30Assignment(_tok_61118);

    /** 			ExecCommand()*/
    _30ExecCommand();
    goto L7; // [148] 1801
L5: 

    /** 		elsif id = PROCEDURE or id = FUNCTION or id = TYPE_DECL then*/
    _30685 = (_id_61119 == 405);
    if (_30685 != 0) {
        _30686 = 1;
        goto L8; // [159] 173
    }
    _30687 = (_id_61119 == 406);
    _30686 = (_30687 != 0);
L8: 
    if (_30686 != 0) {
        goto L9; // [173] 188
    }
    _30689 = (_id_61119 == 416);
    if (_30689 == 0)
    {
        DeRef(_30689);
        _30689 = NOVALUE;
        goto LA; // [184] 205
    }
    else{
        DeRef(_30689);
        _30689 = NOVALUE;
    }
L9: 

    /** 			SubProg(tok[T_ID], SC_LOCAL)*/
    _2 = (int)SEQ_PTR(_tok_61118);
    _30690 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_30690);
    _30SubProg(_30690, 5);
    _30690 = NOVALUE;
    goto L7; // [202] 1801
LA: 

    /** 		elsif id = GLOBAL or id = EXPORT or id = OVERRIDE or id = PUBLIC then*/
    _30691 = (_id_61119 == 412);
    if (_30691 != 0) {
        _30692 = 1;
        goto LB; // [213] 227
    }
    _30693 = (_id_61119 == 428);
    _30692 = (_30693 != 0);
LB: 
    if (_30692 != 0) {
        _30694 = 1;
        goto LC; // [227] 241
    }
    _30695 = (_id_61119 == 429);
    _30694 = (_30695 != 0);
LC: 
    if (_30694 != 0) {
        goto LD; // [241] 256
    }
    _30697 = (_id_61119 == 430);
    if (_30697 == 0)
    {
        DeRef(_30697);
        _30697 = NOVALUE;
        goto LE; // [252] 626
    }
    else{
        DeRef(_30697);
        _30697 = NOVALUE;
    }
LD: 

    /** 			if id = GLOBAL then*/
    if (_id_61119 != 412)
    goto LF; // [260] 276

    /** 			    scope = SC_GLOBAL*/
    _scope_61120 = 6;
    goto L10; // [273] 335
LF: 

    /** 			elsif id = EXPORT then*/
    if (_id_61119 != 428)
    goto L11; // [280] 296

    /** 				scope = SC_EXPORT*/
    _scope_61120 = 11;
    goto L10; // [293] 335
L11: 

    /** 			elsif id = OVERRIDE then*/
    if (_id_61119 != 429)
    goto L12; // [300] 316

    /** 				scope = SC_OVERRIDE*/
    _scope_61120 = 12;
    goto L10; // [313] 335
L12: 

    /** 			elsif id = PUBLIC then*/
    if (_id_61119 != 430)
    goto L13; // [320] 334

    /** 				scope = SC_PUBLIC*/
    _scope_61120 = 13;
L13: 
L10: 

    /** 			tok = next_token()*/
    _0 = _tok_61118;
    _tok_61118 = _30next_token();
    DeRef(_0);

    /** 			id = tok[T_ID]*/
    _2 = (int)SEQ_PTR(_tok_61118);
    _id_61119 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_id_61119)){
        _id_61119 = (long)DBL_PTR(_id_61119)->dbl;
    }

    /** 			if id = TYPE or id = QUALIFIED_TYPE then*/
    _30704 = (_id_61119 == 504);
    if (_30704 != 0) {
        goto L14; // [358] 373
    }
    _30706 = (_id_61119 == 522);
    if (_30706 == 0)
    {
        DeRef(_30706);
        _30706 = NOVALUE;
        goto L15; // [369] 391
    }
    else{
        DeRef(_30706);
        _30706 = NOVALUE;
    }
L14: 

    /** 				Global_declaration(tok[T_SYM], scope )*/
    _2 = (int)SEQ_PTR(_tok_61118);
    _30707 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_30707);
    _30708 = _30Global_declaration(_30707, _scope_61120);
    _30707 = NOVALUE;
    goto L7; // [388] 1801
L15: 

    /** 			elsif id = CONSTANT then*/
    if (_id_61119 != 417)
    goto L16; // [395] 415

    /** 				Global_declaration(0, scope )*/
    _30710 = _30Global_declaration(0, _scope_61120);

    /** 				ExecCommand()*/
    _30ExecCommand();
    goto L7; // [412] 1801
L16: 

    /** 			elsif id = ENUM then*/
    if (_id_61119 != 427)
    goto L17; // [419] 439

    /** 				Global_declaration(-1, scope )*/
    _30712 = _30Global_declaration(-1, _scope_61120);

    /** 				ExecCommand()*/
    _30ExecCommand();
    goto L7; // [436] 1801
L17: 

    /** 			elsif id = PROCEDURE or id = FUNCTION or id = TYPE_DECL then*/
    _30713 = (_id_61119 == 405);
    if (_30713 != 0) {
        _30714 = 1;
        goto L18; // [447] 461
    }
    _30715 = (_id_61119 == 406);
    _30714 = (_30715 != 0);
L18: 
    if (_30714 != 0) {
        goto L19; // [461] 476
    }
    _30717 = (_id_61119 == 416);
    if (_30717 == 0)
    {
        DeRef(_30717);
        _30717 = NOVALUE;
        goto L1A; // [472] 487
    }
    else{
        DeRef(_30717);
        _30717 = NOVALUE;
    }
L19: 

    /** 				SubProg(id, scope )*/
    _30SubProg(_id_61119, _scope_61120);
    goto L7; // [484] 1801
L1A: 

    /** 			elsif (scope = SC_PUBLIC) and id = INCLUDE then*/
    _30718 = (_scope_61120 == 13);
    if (_30718 == 0) {
        goto L1B; // [497] 523
    }
    _30720 = (_id_61119 == 418);
    if (_30720 == 0)
    {
        DeRef(_30720);
        _30720 = NOVALUE;
        goto L1B; // [508] 523
    }
    else{
        DeRef(_30720);
        _30720 = NOVALUE;
    }

    /** 				IncludeScan( 1 )*/
    _60IncludeScan(1);

    /** 				PushGoto()*/
    _30PushGoto();
    goto L7; // [520] 1801
L1B: 

    /** 			elsif (id = VARIABLE or id = QUALIFIED_VARIABLE)*/
    _30721 = (_id_61119 == -100);
    if (_30721 != 0) {
        _30722 = 1;
        goto L1C; // [531] 545
    }
    _30723 = (_id_61119 == 512);
    _30722 = (_30723 != 0);
L1C: 
    if (_30722 == 0) {
        _30724 = 0;
        goto L1D; // [545] 577
    }
    _2 = (int)SEQ_PTR(_tok_61118);
    _30725 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!IS_ATOM_INT(_30725)){
        _30726 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_30725)->dbl));
    }
    else{
        _30726 = (int)*(((s1_ptr)_2)->base + _30725);
    }
    _2 = (int)SEQ_PTR(_30726);
    _30727 = (int)*(((s1_ptr)_2)->base + 4);
    _30726 = NOVALUE;
    if (IS_ATOM_INT(_30727)) {
        _30728 = (_30727 == 9);
    }
    else {
        _30728 = binary_op(EQUALS, _30727, 9);
    }
    _30727 = NOVALUE;
    if (IS_ATOM_INT(_30728))
    _30724 = (_30728 != 0);
    else
    _30724 = DBL_PTR(_30728)->dbl != 0.0;
L1D: 
    if (_30724 == 0) {
        goto L1E; // [577] 597
    }
    Ref(_tok_61118);
    _30730 = _30undefined_var(_tok_61118, _scope_61120);
    if (_30730 == 0) {
        DeRef(_30730);
        _30730 = NOVALUE;
        goto L1E; // [587] 597
    }
    else {
        if (!IS_ATOM_INT(_30730) && DBL_PTR(_30730)->dbl == 0.0){
            DeRef(_30730);
            _30730 = NOVALUE;
            goto L1E; // [587] 597
        }
        DeRef(_30730);
        _30730 = NOVALUE;
    }
    DeRef(_30730);
    _30730 = NOVALUE;

    /** 				continue*/
    goto L1; // [592] 12
    goto L7; // [594] 1801
L1E: 

    /** 			elsif scope = SC_GLOBAL then*/
    if (_scope_61120 != 6)
    goto L1F; // [601] 615

    /** 				CompileErr( 18 )*/
    RefDS(_22037);
    _43CompileErr(18, _22037, 0);
    goto L7; // [612] 1801
L1F: 

    /** 				CompileErr( 16 )*/
    RefDS(_22037);
    _43CompileErr(16, _22037, 0);
    goto L7; // [623] 1801
LE: 

    /** 		elsif id = TYPE or id = QUALIFIED_TYPE then*/
    _30732 = (_id_61119 == 504);
    if (_30732 != 0) {
        goto L20; // [634] 649
    }
    _30734 = (_id_61119 == 522);
    if (_30734 == 0)
    {
        DeRef(_30734);
        _30734 = NOVALUE;
        goto L21; // [645] 734
    }
    else{
        DeRef(_30734);
        _30734 = NOVALUE;
    }
L20: 

    /** 			token test = next_token()*/
    _0 = _test_61261;
    _test_61261 = _30next_token();
    DeRef(_0);

    /** 			putback( test )*/
    Ref(_test_61261);
    _30putback(_test_61261);

    /** 			if test[T_ID] = LEFT_ROUND then*/
    _2 = (int)SEQ_PTR(_test_61261);
    _30736 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30736, -26)){
        _30736 = NOVALUE;
        goto L22; // [669] 707
    }
    _30736 = NOVALUE;

    /** 					StartSourceLine( TRUE )*/
    _37StartSourceLine(_9TRUE_430, 0, 2);

    /** 					Procedure_call(tok)*/
    Ref(_tok_61118);
    _30Procedure_call(_tok_61118);

    /** 					clear_op()*/
    _37clear_op();

    /** 					if Pop() then end if*/
    _30738 = _37Pop();
    if (_30738 == 0) {
        DeRef(_30738);
        _30738 = NOVALUE;
        goto L23; // [696] 700
    }
    else {
        if (!IS_ATOM_INT(_30738) && DBL_PTR(_30738)->dbl == 0.0){
            DeRef(_30738);
            _30738 = NOVALUE;
            goto L23; // [696] 700
        }
        DeRef(_30738);
        _30738 = NOVALUE;
    }
    DeRef(_30738);
    _30738 = NOVALUE;
L23: 

    /** 					ExecCommand()*/
    _30ExecCommand();
    goto L24; // [704] 723
L22: 

    /** 				Global_declaration( tok[T_SYM], SC_LOCAL )*/
    _2 = (int)SEQ_PTR(_tok_61118);
    _30739 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_30739);
    _30740 = _30Global_declaration(_30739, 5);
    _30739 = NOVALUE;
L24: 

    /** 			continue*/
    DeRef(_test_61261);
    _test_61261 = NOVALUE;
    goto L1; // [727] 12
    goto L7; // [731] 1801
L21: 

    /** 		elsif id = CONSTANT then*/
    if (_id_61119 != 417)
    goto L25; // [738] 758

    /** 			Global_declaration(0, SC_LOCAL)*/
    _30742 = _30Global_declaration(0, 5);

    /** 			ExecCommand()*/
    _30ExecCommand();
    goto L7; // [755] 1801
L25: 

    /** 		elsif id = ENUM then*/
    if (_id_61119 != 427)
    goto L26; // [762] 782

    /** 			Global_declaration(-1, SC_LOCAL)*/
    _30744 = _30Global_declaration(-1, 5);

    /** 			ExecCommand()*/
    _30ExecCommand();
    goto L7; // [779] 1801
L26: 

    /** 		elsif id = IF then*/
    if (_id_61119 != 20)
    goto L27; // [786] 810

    /** 			StartSourceLine(TRUE)*/
    _37StartSourceLine(_9TRUE_430, 0, 2);

    /** 			If_statement()*/
    _30If_statement();

    /** 			ExecCommand()*/
    _30ExecCommand();
    goto L7; // [807] 1801
L27: 

    /** 		elsif id = FOR then*/
    if (_id_61119 != 21)
    goto L28; // [814] 838

    /** 			StartSourceLine(TRUE)*/
    _37StartSourceLine(_9TRUE_430, 0, 2);

    /** 			For_statement()*/
    _30For_statement();

    /** 			ExecCommand()*/
    _30ExecCommand();
    goto L7; // [835] 1801
L28: 

    /** 		elsif id = WHILE then*/
    if (_id_61119 != 47)
    goto L29; // [842] 866

    /** 			StartSourceLine(TRUE)*/
    _37StartSourceLine(_9TRUE_430, 0, 2);

    /** 			While_statement()*/
    _30While_statement();

    /** 			ExecCommand()*/
    _30ExecCommand();
    goto L7; // [863] 1801
L29: 

    /** 		elsif id = LOOP then*/
    if (_id_61119 != 422)
    goto L2A; // [870] 894

    /** 		    StartSourceLine(TRUE)*/
    _37StartSourceLine(_9TRUE_430, 0, 2);

    /** 		    Loop_statement()*/
    _30Loop_statement();

    /** 		    ExecCommand()*/
    _30ExecCommand();
    goto L7; // [891] 1801
L2A: 

    /** 		elsif id = PROC or id = QUALIFIED_PROC then*/
    _30749 = (_id_61119 == 27);
    if (_30749 != 0) {
        goto L2B; // [902] 917
    }
    _30751 = (_id_61119 == 521);
    if (_30751 == 0)
    {
        DeRef(_30751);
        _30751 = NOVALUE;
        goto L2C; // [913] 958
    }
    else{
        DeRef(_30751);
        _30751 = NOVALUE;
    }
L2B: 

    /** 			StartSourceLine(TRUE)*/
    _37StartSourceLine(_9TRUE_430, 0, 2);

    /** 			if id = PROC then*/
    if (_id_61119 != 27)
    goto L2D; // [930] 946

    /** 				UndefinedVar( tok[T_SYM] )*/
    _2 = (int)SEQ_PTR(_tok_61118);
    _30753 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_30753);
    _30UndefinedVar(_30753);
    _30753 = NOVALUE;
L2D: 

    /** 			Procedure_call(tok)*/
    Ref(_tok_61118);
    _30Procedure_call(_tok_61118);

    /** 			ExecCommand()*/
    _30ExecCommand();
    goto L7; // [955] 1801
L2C: 

    /** 		elsif id = FUNC or id = QUALIFIED_FUNC then*/
    _30754 = (_id_61119 == 501);
    if (_30754 != 0) {
        goto L2E; // [966] 981
    }
    _30756 = (_id_61119 == 520);
    if (_30756 == 0)
    {
        DeRef(_30756);
        _30756 = NOVALUE;
        goto L2F; // [977] 1035
    }
    else{
        DeRef(_30756);
        _30756 = NOVALUE;
    }
L2E: 

    /** 			StartSourceLine(TRUE)*/
    _37StartSourceLine(_9TRUE_430, 0, 2);

    /** 			if id = FUNC then*/
    if (_id_61119 != 501)
    goto L30; // [994] 1010

    /** 				UndefinedVar( tok[T_SYM] )*/
    _2 = (int)SEQ_PTR(_tok_61118);
    _30758 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_30758);
    _30UndefinedVar(_30758);
    _30758 = NOVALUE;
L30: 

    /** 			Procedure_call(tok)*/
    Ref(_tok_61118);
    _30Procedure_call(_tok_61118);

    /** 			clear_op()*/
    _37clear_op();

    /** 			if Pop() then end if*/
    _30759 = _37Pop();
    if (_30759 == 0) {
        DeRef(_30759);
        _30759 = NOVALUE;
        goto L31; // [1024] 1028
    }
    else {
        if (!IS_ATOM_INT(_30759) && DBL_PTR(_30759)->dbl == 0.0){
            DeRef(_30759);
            _30759 = NOVALUE;
            goto L31; // [1024] 1028
        }
        DeRef(_30759);
        _30759 = NOVALUE;
    }
    DeRef(_30759);
    _30759 = NOVALUE;
L31: 

    /** 			ExecCommand()*/
    _30ExecCommand();
    goto L7; // [1032] 1801
L2F: 

    /** 		elsif id = RETURN then*/
    if (_id_61119 != 413)
    goto L32; // [1039] 1050

    /** 			Return_statement() -- will fail - not allowed at top level*/
    _30Return_statement();
    goto L7; // [1047] 1801
L32: 

    /** 		elsif id = EXIT then*/
    if (_id_61119 != 61)
    goto L33; // [1054] 1090

    /** 			if nested then*/
    if (_nested_61116 == 0)
    {
        goto L34; // [1060] 1079
    }
    else{
    }

    /** 			StartSourceLine(TRUE)*/
    _37StartSourceLine(_9TRUE_430, 0, 2);

    /** 			Exit_statement()*/
    _30Exit_statement();
    goto L7; // [1076] 1801
L34: 

    /** 			CompileErr(89)*/
    RefDS(_22037);
    _43CompileErr(89, _22037, 0);
    goto L7; // [1087] 1801
L33: 

    /** 		elsif id = INCLUDE then*/
    if (_id_61119 != 418)
    goto L35; // [1094] 1110

    /** 			IncludeScan( 0 )*/
    _60IncludeScan(0);

    /** 			PushGoto()*/
    _30PushGoto();
    goto L7; // [1107] 1801
L35: 

    /** 		elsif id = WITH then*/
    if (_id_61119 != 420)
    goto L36; // [1114] 1128

    /** 			SetWith(TRUE)*/
    _30SetWith(_9TRUE_430);
    goto L7; // [1125] 1801
L36: 

    /** 		elsif id = WITHOUT then*/
    if (_id_61119 != 421)
    goto L37; // [1132] 1146

    /** 			SetWith(FALSE)*/
    _30SetWith(_9FALSE_428);
    goto L7; // [1143] 1801
L37: 

    /** 		elsif id = END_OF_FILE then*/
    if (_id_61119 != -21)
    goto L38; // [1150] 1267

    /** 			if IncludePop() then*/
    _30766 = _60IncludePop();
    if (_30766 == 0) {
        DeRef(_30766);
        _30766 = NOVALUE;
        goto L39; // [1159] 1255
    }
    else {
        if (!IS_ATOM_INT(_30766) && DBL_PTR(_30766)->dbl == 0.0){
            DeRef(_30766);
            _30766 = NOVALUE;
            goto L39; // [1159] 1255
        }
        DeRef(_30766);
        _30766 = NOVALUE;
    }
    DeRef(_30766);
    _30766 = NOVALUE;

    /** 				backed_up_tok = {}*/
    RefDS(_22037);
    DeRef(_30backed_up_tok_54163);
    _30backed_up_tok_54163 = _22037;

    /** 				PopGoto()*/
    _30PopGoto();

    /** 				read_line()*/
    _60read_line();

    /** 				last_ForwardLine     = ThisLine*/
    Ref(_43ThisLine_48557);
    DeRef(_43last_ForwardLine_48560);
    _43last_ForwardLine_48560 = _43ThisLine_48557;

    /** 				last_fwd_line_number = line_number*/
    _26last_fwd_line_number_11986 = _26line_number_11983;

    /** 				last_forward_bp      = bp*/
    _43last_forward_bp_48564 = _43bp_48561;

    /** 				putback_ForwardLine     = ThisLine*/
    Ref(_43ThisLine_48557);
    DeRef(_43putback_ForwardLine_48559);
    _43putback_ForwardLine_48559 = _43ThisLine_48557;

    /** 				putback_fwd_line_number = line_number*/
    _26putback_fwd_line_number_11985 = _26line_number_11983;

    /** 				putback_forward_bp      = bp*/
    _43putback_forward_bp_48563 = _43bp_48561;

    /** 				ForwardLine     = ThisLine*/
    Ref(_43ThisLine_48557);
    DeRef(_43ForwardLine_48558);
    _43ForwardLine_48558 = _43ThisLine_48557;

    /** 				fwd_line_number = line_number*/
    _26fwd_line_number_11984 = _26line_number_11983;

    /** 				forward_bp      = bp*/
    _43forward_bp_48562 = _43bp_48561;
    goto L7; // [1252] 1801
L39: 

    /** 				CheckForUndefinedGotoLabels()*/
    _30CheckForUndefinedGotoLabels();

    /** 				exit -- all finished*/
    goto L2; // [1261] 1811
    goto L7; // [1264] 1801
L38: 

    /** 		elsif id = QUESTION_MARK then*/
    if (_id_61119 != -31)
    goto L3A; // [1271] 1295

    /** 			StartSourceLine(TRUE)*/
    _37StartSourceLine(_9TRUE_430, 0, 2);

    /** 			Print_statement()*/
    _30Print_statement();

    /** 			ExecCommand()*/
    _30ExecCommand();
    goto L7; // [1292] 1801
L3A: 

    /** 		elsif id = LABEL then*/
    if (_id_61119 != 419)
    goto L3B; // [1299] 1321

    /** 			StartSourceLine(TRUE, , COVERAGE_SUPPRESS)*/
    _37StartSourceLine(_9TRUE_430, 0, 1);

    /** 			GLabel_statement()*/
    _30GLabel_statement();
    goto L7; // [1318] 1801
L3B: 

    /** 		elsif id = GOTO then*/
    if (_id_61119 != 188)
    goto L3C; // [1325] 1345

    /** 			StartSourceLine(TRUE)*/
    _37StartSourceLine(_9TRUE_430, 0, 2);

    /** 			Goto_statement()*/
    _30Goto_statement();
    goto L7; // [1342] 1801
L3C: 

    /** 		elsif id = CONTINUE then*/
    if (_id_61119 != 426)
    goto L3D; // [1349] 1385

    /** 			if nested then*/
    if (_nested_61116 == 0)
    {
        goto L3E; // [1355] 1374
    }
    else{
    }

    /** 				StartSourceLine(TRUE)*/
    _37StartSourceLine(_9TRUE_430, 0, 2);

    /** 				Continue_statement()*/
    _30Continue_statement();
    goto L7; // [1371] 1801
L3E: 

    /** 				CompileErr(50)*/
    RefDS(_22037);
    _43CompileErr(50, _22037, 0);
    goto L7; // [1382] 1801
L3D: 

    /** 		elsif id = RETRY then*/
    if (_id_61119 != 184)
    goto L3F; // [1389] 1425

    /** 			if nested then*/
    if (_nested_61116 == 0)
    {
        goto L40; // [1395] 1414
    }
    else{
    }

    /** 				StartSourceLine(TRUE)*/
    _37StartSourceLine(_9TRUE_430, 0, 2);

    /** 				Retry_statement()*/
    _30Retry_statement();
    goto L7; // [1411] 1801
L40: 

    /** 				CompileErr(128)*/
    RefDS(_22037);
    _43CompileErr(128, _22037, 0);
    goto L7; // [1422] 1801
L3F: 

    /** 		elsif id = BREAK then*/
    if (_id_61119 != 425)
    goto L41; // [1429] 1465

    /** 			if nested then*/
    if (_nested_61116 == 0)
    {
        goto L42; // [1435] 1454
    }
    else{
    }

    /** 				StartSourceLine(TRUE)*/
    _37StartSourceLine(_9TRUE_430, 0, 2);

    /** 				Break_statement()*/
    _30Break_statement();
    goto L7; // [1451] 1801
L42: 

    /** 				CompileErr(39)*/
    RefDS(_22037);
    _43CompileErr(39, _22037, 0);
    goto L7; // [1462] 1801
L41: 

    /** 		elsif id = ENTRY then*/
    if (_id_61119 != 424)
    goto L43; // [1469] 1507

    /** 			if nested then*/
    if (_nested_61116 == 0)
    {
        goto L44; // [1475] 1496
    }
    else{
    }

    /** 			    StartSourceLine(TRUE, , COVERAGE_SUPPRESS)*/
    _37StartSourceLine(_9TRUE_430, 0, 1);

    /** 			    Entry_statement()*/
    _30Entry_statement();
    goto L7; // [1493] 1801
L44: 

    /** 				CompileErr(72)*/
    RefDS(_22037);
    _43CompileErr(72, _22037, 0);
    goto L7; // [1504] 1801
L43: 

    /** 		elsif id = IFDEF then*/
    if (_id_61119 != 407)
    goto L45; // [1511] 1531

    /** 			StartSourceLine(TRUE)*/
    _37StartSourceLine(_9TRUE_430, 0, 2);

    /** 			Ifdef_statement()*/
    _30Ifdef_statement();
    goto L7; // [1528] 1801
L45: 

    /** 		elsif id = CASE then*/
    if (_id_61119 != 186)
    goto L46; // [1535] 1546

    /** 			Case_statement()*/
    _30Case_statement();
    goto L7; // [1543] 1801
L46: 

    /** 		elsif id = SWITCH then*/
    if (_id_61119 != 185)
    goto L47; // [1550] 1570

    /** 			StartSourceLine(TRUE)*/
    _37StartSourceLine(_9TRUE_430, 0, 2);

    /** 			Switch_statement()*/
    _30Switch_statement();
    goto L7; // [1567] 1801
L47: 

    /** 		elsif id = ILLEGAL_CHAR then*/
    if (_id_61119 != -20)
    goto L48; // [1574] 1588

    /** 			CompileErr(102)*/
    RefDS(_22037);
    _43CompileErr(102, _22037, 0);
    goto L7; // [1585] 1801
L48: 

    /** 			if nested then*/
    if (_nested_61116 == 0)
    {
        goto L49; // [1590] 1742
    }
    else{
    }

    /** 				if id = ELSE then*/
    if (_id_61119 != 23)
    goto L4A; // [1597] 1651

    /** 					if length(if_stack) = 0 then*/
    if (IS_SEQUENCE(_30if_stack_54191)){
            _30779 = SEQ_PTR(_30if_stack_54191)->length;
    }
    else {
        _30779 = 1;
    }
    if (_30779 != 0)
    goto L4B; // [1608] 1708

    /** 						if live_ifdef > 0 then*/
    if (_30live_ifdef_58325 <= 0)
    goto L4C; // [1616] 1639

    /** 							CompileErr(134, ifdef_lineno[$])*/
    if (IS_SEQUENCE(_30ifdef_lineno_58326)){
            _30782 = SEQ_PTR(_30ifdef_lineno_58326)->length;
    }
    else {
        _30782 = 1;
    }
    _2 = (int)SEQ_PTR(_30ifdef_lineno_58326);
    _30783 = (int)*(((s1_ptr)_2)->base + _30782);
    _43CompileErr(134, _30783, 0);
    _30783 = NOVALUE;
    goto L4B; // [1636] 1708
L4C: 

    /** 							CompileErr(118)*/
    RefDS(_22037);
    _43CompileErr(118, _22037, 0);
    goto L4B; // [1648] 1708
L4A: 

    /** 				elsif id = ELSIF then*/
    if (_id_61119 != 414)
    goto L4D; // [1655] 1707

    /** 					if length(if_stack) = 0 then*/
    if (IS_SEQUENCE(_30if_stack_54191)){
            _30785 = SEQ_PTR(_30if_stack_54191)->length;
    }
    else {
        _30785 = 1;
    }
    if (_30785 != 0)
    goto L4E; // [1666] 1706

    /** 						if live_ifdef > 0 then*/
    if (_30live_ifdef_58325 <= 0)
    goto L4F; // [1674] 1697

    /** 							CompileErr(139, ifdef_lineno[$])*/
    if (IS_SEQUENCE(_30ifdef_lineno_58326)){
            _30788 = SEQ_PTR(_30ifdef_lineno_58326)->length;
    }
    else {
        _30788 = 1;
    }
    _2 = (int)SEQ_PTR(_30ifdef_lineno_58326);
    _30789 = (int)*(((s1_ptr)_2)->base + _30788);
    _43CompileErr(139, _30789, 0);
    _30789 = NOVALUE;
    goto L50; // [1694] 1705
L4F: 

    /** 							CompileErr(119)*/
    RefDS(_22037);
    _43CompileErr(119, _22037, 0);
L50: 
L4E: 
L4D: 
L4B: 

    /** 				putback(tok)*/
    Ref(_tok_61118);
    _30putback(_tok_61118);

    /** 				if stmt_nest > 0 then*/
    if (_30stmt_nest_54188 <= 0)
    goto L51; // [1717] 1734

    /** 					stmt_nest -= 1*/
    _30stmt_nest_54188 = _30stmt_nest_54188 - 1;

    /** 					InitDelete()*/
    _30InitDelete();
L51: 

    /** 				return*/
    DeRef(_tok_61118);
    DeRef(_30708);
    _30708 = NOVALUE;
    DeRef(_30713);
    _30713 = NOVALUE;
    DeRef(_30744);
    _30744 = NOVALUE;
    DeRef(_30676);
    _30676 = NOVALUE;
    DeRef(_30749);
    _30749 = NOVALUE;
    DeRef(_30740);
    _30740 = NOVALUE;
    DeRef(_30715);
    _30715 = NOVALUE;
    DeRef(_30693);
    _30693 = NOVALUE;
    DeRef(_30723);
    _30723 = NOVALUE;
    DeRef(_30754);
    _30754 = NOVALUE;
    DeRef(_30695);
    _30695 = NOVALUE;
    _30725 = NOVALUE;
    DeRef(_30732);
    _30732 = NOVALUE;
    DeRef(_30728);
    _30728 = NOVALUE;
    _30679 = NOVALUE;
    DeRef(_30691);
    _30691 = NOVALUE;
    DeRef(_30687);
    _30687 = NOVALUE;
    DeRef(_30704);
    _30704 = NOVALUE;
    DeRef(_30710);
    _30710 = NOVALUE;
    DeRef(_30682);
    _30682 = NOVALUE;
    DeRef(_30685);
    _30685 = NOVALUE;
    DeRef(_30712);
    _30712 = NOVALUE;
    DeRef(_30721);
    _30721 = NOVALUE;
    DeRef(_30742);
    _30742 = NOVALUE;
    DeRef(_30718);
    _30718 = NOVALUE;
    return;
    goto L52; // [1739] 1800
L49: 

    /** 				if id = END then*/
    if (_id_61119 != 402)
    goto L53; // [1746] 1777

    /** 					tok = next_token()*/
    _0 = _tok_61118;
    _tok_61118 = _30next_token();
    DeRef(_0);

    /** 					CompileErr(17, {find_token_text(tok[T_ID])})*/
    _2 = (int)SEQ_PTR(_tok_61118);
    _30794 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_30794);
    _30795 = _62find_token_text(_30794);
    _30794 = NOVALUE;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _30795;
    _30796 = MAKE_SEQ(_1);
    _30795 = NOVALUE;
    _43CompileErr(17, _30796, 0);
    _30796 = NOVALUE;
L53: 

    /** 				CompileErr(117, { match_replace(",", find_token_text(id), "") })*/
    _30797 = _62find_token_text(_id_61119);
    RefDS(_26303);
    RefDS(_22037);
    _30798 = _14match_replace(_26303, _30797, _22037, 0);
    _30797 = NOVALUE;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _30798;
    _30799 = MAKE_SEQ(_1);
    _30798 = NOVALUE;
    _43CompileErr(117, _30799, 0);
    _30799 = NOVALUE;
L52: 
L7: 

    /** 		flush_temps()*/
    RefDS(_22037);
    _37flush_temps(_22037);

    /** 	end while*/
    goto L1; // [1808] 12
L2: 

    /** 	emit_op(RETURNT)*/
    _37emit_op(34);

    /** 	clear_last()*/
    _37clear_last();

    /** 	StraightenBranches()*/
    _30StraightenBranches();

    /** 	SymTab[TopLevelSub][S_CODE] = Code*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_26TopLevelSub_11989 + ((s1_ptr)_2)->base);
    RefDS(_26Code_12071);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_26S_CODE_11666))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_CODE_11666)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _26S_CODE_11666);
    _1 = *(int *)_2;
    *(int *)_2 = _26Code_12071;
    DeRef(_1);
    _30800 = NOVALUE;

    /** 	EndLineTable()*/
    _30EndLineTable();

    /** 	SymTab[TopLevelSub][S_LINETAB] = LineTable*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_26TopLevelSub_11989 + ((s1_ptr)_2)->base);
    RefDS(_26LineTable_12072);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_26S_LINETAB_11689))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_LINETAB_11689)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _26S_LINETAB_11689);
    _1 = *(int *)_2;
    *(int *)_2 = _26LineTable_12072;
    DeRef(_1);
    _30802 = NOVALUE;

    /** end procedure*/
    DeRef(_tok_61118);
    DeRef(_30708);
    _30708 = NOVALUE;
    DeRef(_30713);
    _30713 = NOVALUE;
    DeRef(_30744);
    _30744 = NOVALUE;
    DeRef(_30676);
    _30676 = NOVALUE;
    DeRef(_30749);
    _30749 = NOVALUE;
    DeRef(_30740);
    _30740 = NOVALUE;
    DeRef(_30715);
    _30715 = NOVALUE;
    DeRef(_30693);
    _30693 = NOVALUE;
    DeRef(_30723);
    _30723 = NOVALUE;
    DeRef(_30754);
    _30754 = NOVALUE;
    DeRef(_30695);
    _30695 = NOVALUE;
    _30725 = NOVALUE;
    DeRef(_30732);
    _30732 = NOVALUE;
    DeRef(_30728);
    _30728 = NOVALUE;
    _30679 = NOVALUE;
    DeRef(_30691);
    _30691 = NOVALUE;
    DeRef(_30687);
    _30687 = NOVALUE;
    DeRef(_30704);
    _30704 = NOVALUE;
    DeRef(_30710);
    _30710 = NOVALUE;
    DeRef(_30682);
    _30682 = NOVALUE;
    DeRef(_30685);
    _30685 = NOVALUE;
    DeRef(_30712);
    _30712 = NOVALUE;
    DeRef(_30721);
    _30721 = NOVALUE;
    DeRef(_30742);
    _30742 = NOVALUE;
    DeRef(_30718);
    _30718 = NOVALUE;
    return;
    ;
}


void _30parser()
{
    int _0, _1, _2;
    

    /** 	real_parser(0)*/
    _30real_parser(0);

    /** 	mark_final_targets()*/
    _52mark_final_targets();

    /** 	resolve_unincluded_globals( 1 )*/
    _52resolve_unincluded_globals(1);

    /** 	Resolve_forward_references( 1 )*/
    _29Resolve_forward_references(1);

    /** 	inline_deferred_calls()*/
    _66inline_deferred_calls();

    /** 	End_block( PROC )*/
    _65End_block(27);

    /** 	Code = {}*/
    RefDS(_22037);
    DeRef(_26Code_12071);
    _26Code_12071 = _22037;

    /** 	LineTable = {}*/
    RefDS(_22037);
    DeRef(_26LineTable_12072);
    _26LineTable_12072 = _22037;

    /** end procedure*/
    return;
    ;
}


void _30nested_parser()
{
    int _0, _1, _2;
    

    /** 	real_parser(1)*/
    _30real_parser(1);

    /** end procedure*/
    return;
    ;
}



// 0x9E60AC5D
