// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int _54find_file(int _fname_44284)
{
    int _23484 = NOVALUE;
    int _23483 = NOVALUE;
    int _23482 = NOVALUE;
    int _23481 = NOVALUE;
    int _23479 = NOVALUE;
    int _23478 = NOVALUE;
    int _0, _1, _2;
    

    /** 	for i = 1 to length(inc_dirs) do*/
    _23478 = 4;
    {
        int _i_44286;
        _i_44286 = 1;
L1: 
        if (_i_44286 > 4){
            goto L2; // [10] 64
        }

        /** 		if file_exists(inc_dirs[i] & "/" & fname) then*/
        _2 = (int)SEQ_PTR(_54inc_dirs_44275);
        _23479 = (int)*(((s1_ptr)_2)->base + _i_44286);
        {
            int concat_list[3];

            concat_list[0] = _fname_44284;
            concat_list[1] = _23480;
            concat_list[2] = _23479;
            Concat_N((object_ptr)&_23481, concat_list, 3);
        }
        _23479 = NOVALUE;
        _23482 = _15file_exists(_23481);
        _23481 = NOVALUE;
        if (_23482 == 0) {
            DeRef(_23482);
            _23482 = NOVALUE;
            goto L3; // [35] 57
        }
        else {
            if (!IS_ATOM_INT(_23482) && DBL_PTR(_23482)->dbl == 0.0){
                DeRef(_23482);
                _23482 = NOVALUE;
                goto L3; // [35] 57
            }
            DeRef(_23482);
            _23482 = NOVALUE;
        }
        DeRef(_23482);
        _23482 = NOVALUE;

        /** 			return inc_dirs[i] & "/" & fname*/
        _2 = (int)SEQ_PTR(_54inc_dirs_44275);
        _23483 = (int)*(((s1_ptr)_2)->base + _i_44286);
        {
            int concat_list[3];

            concat_list[0] = _fname_44284;
            concat_list[1] = _23480;
            concat_list[2] = _23483;
            Concat_N((object_ptr)&_23484, concat_list, 3);
        }
        _23483 = NOVALUE;
        DeRefDS(_fname_44284);
        return _23484;
L3: 

        /** 	end for*/
        _i_44286 = _i_44286 + 1;
        goto L1; // [59] 17
L2: 
        ;
    }

    /** 	return 0*/
    DeRefDS(_fname_44284);
    DeRef(_23484);
    _23484 = NOVALUE;
    return 0;
    ;
}


int _54find_all_includes(int _fname_44298, int _includes_44299)
{
    int _lines_44300 = NOVALUE;
    int _m_44306 = NOVALUE;
    int _full_fname_44311 = NOVALUE;
    int _23497 = NOVALUE;
    int _23495 = NOVALUE;
    int _23493 = NOVALUE;
    int _23492 = NOVALUE;
    int _23490 = NOVALUE;
    int _23489 = NOVALUE;
    int _23487 = NOVALUE;
    int _23486 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence lines = read_lines(fname)*/
    RefDS(_fname_44298);
    _0 = _lines_44300;
    _lines_44300 = _18read_lines(_fname_44298);
    DeRef(_0);

    /** 	for i = 1 to length(lines) do*/
    if (IS_SEQUENCE(_lines_44300)){
            _23486 = SEQ_PTR(_lines_44300)->length;
    }
    else {
        _23486 = 1;
    }
    {
        int _i_44304;
        _i_44304 = 1;
L1: 
        if (_i_44304 > _23486){
            goto L2; // [18] 113
        }

        /** 		object m = regex:matches(re_include, lines[i])*/
        _2 = (int)SEQ_PTR(_lines_44300);
        _23487 = (int)*(((s1_ptr)_2)->base + _i_44304);
        Ref(_54re_include_44272);
        Ref(_23487);
        _0 = _m_44306;
        _m_44306 = _50matches(_54re_include_44272, _23487, 1, 0);
        DeRef(_0);
        _23487 = NOVALUE;

        /** 		if sequence(m) then*/
        _23489 = IS_SEQUENCE(_m_44306);
        if (_23489 == 0)
        {
            _23489 = NOVALUE;
            goto L3; // [45] 102
        }
        else{
            _23489 = NOVALUE;
        }

        /** 			object full_fname = find_file(m[3])*/
        _2 = (int)SEQ_PTR(_m_44306);
        _23490 = (int)*(((s1_ptr)_2)->base + 3);
        Ref(_23490);
        _0 = _full_fname_44311;
        _full_fname_44311 = _54find_file(_23490);
        DeRef(_0);
        _23490 = NOVALUE;

        /** 			if sequence(full_fname) then*/
        _23492 = IS_SEQUENCE(_full_fname_44311);
        if (_23492 == 0)
        {
            _23492 = NOVALUE;
            goto L4; // [63] 101
        }
        else{
            _23492 = NOVALUE;
        }

        /** 				if eu:find(full_fname, includes) = 0 then*/
        _23493 = find_from(_full_fname_44311, _includes_44299, 1);
        if (_23493 != 0)
        goto L5; // [73] 100

        /** 					includes &= { full_fname }*/
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        Ref(_full_fname_44311);
        *((int *)(_2+4)) = _full_fname_44311;
        _23495 = MAKE_SEQ(_1);
        Concat((object_ptr)&_includes_44299, _includes_44299, _23495);
        DeRefDS(_23495);
        _23495 = NOVALUE;

        /** 					includes = find_all_includes(full_fname, includes)*/
        RefDS(_includes_44299);
        DeRef(_23497);
        _23497 = _includes_44299;
        Ref(_full_fname_44311);
        _0 = _includes_44299;
        _includes_44299 = _54find_all_includes(_full_fname_44311, _23497);
        DeRefDS(_0);
        _23497 = NOVALUE;
L5: 
L4: 
L3: 
        DeRef(_full_fname_44311);
        _full_fname_44311 = NOVALUE;
        DeRef(_m_44306);
        _m_44306 = NOVALUE;

        /** 	end for*/
        _i_44304 = _i_44304 + 1;
        goto L1; // [108] 25
L2: 
        ;
    }

    /** 	return includes*/
    DeRefDS(_fname_44298);
    DeRef(_lines_44300);
    return _includes_44299;
    ;
}


int _54quick_has_changed(int _fname_44325)
{
    int _d1_44326 = NOVALUE;
    int _all_files_44336 = NOVALUE;
    int _d2_44342 = NOVALUE;
    int _diff_2__tmp_at88_44352 = NOVALUE;
    int _diff_1__tmp_at88_44351 = NOVALUE;
    int _diff_inlined_diff_at_88_44350 = NOVALUE;
    int _23509 = NOVALUE;
    int _23507 = NOVALUE;
    int _23506 = NOVALUE;
    int _23504 = NOVALUE;
    int _23503 = NOVALUE;
    int _23501 = NOVALUE;
    int _23499 = NOVALUE;
    int _0, _1, _2;
    

    /** 	object d1 = file_timestamp(output_dir & filebase(fname) & ".bld")*/
    RefDS(_fname_44325);
    _23499 = _15filebase(_fname_44325);
    {
        int concat_list[3];

        concat_list[0] = _23500;
        concat_list[1] = _23499;
        concat_list[2] = _56output_dir_41729;
        Concat_N((object_ptr)&_23501, concat_list, 3);
    }
    DeRef(_23499);
    _23499 = NOVALUE;
    _0 = _d1_44326;
    _d1_44326 = _15file_timestamp(_23501);
    DeRef(_0);
    _23501 = NOVALUE;

    /** 	if atom(d1) then*/
    _23503 = IS_ATOM(_d1_44326);
    if (_23503 == 0)
    {
        _23503 = NOVALUE;
        goto L1; // [26] 36
    }
    else{
        _23503 = NOVALUE;
    }

    /** 		return 1*/
    DeRefDS(_fname_44325);
    DeRef(_d1_44326);
    DeRef(_all_files_44336);
    return 1;
L1: 

    /** 	sequence all_files = append(find_all_includes(fname), fname)*/
    RefDS(_fname_44325);
    RefDS(_22037);
    _23504 = _54find_all_includes(_fname_44325, _22037);
    RefDS(_fname_44325);
    Append(&_all_files_44336, _23504, _fname_44325);
    DeRef(_23504);
    _23504 = NOVALUE;

    /** 	for i = 1 to length(all_files) do*/
    if (IS_SEQUENCE(_all_files_44336)){
            _23506 = SEQ_PTR(_all_files_44336)->length;
    }
    else {
        _23506 = 1;
    }
    {
        int _i_44340;
        _i_44340 = 1;
L2: 
        if (_i_44340 > _23506){
            goto L3; // [52] 123
        }

        /** 		object d2 = file_timestamp(all_files[i])*/
        _2 = (int)SEQ_PTR(_all_files_44336);
        _23507 = (int)*(((s1_ptr)_2)->base + _i_44340);
        Ref(_23507);
        _0 = _d2_44342;
        _d2_44342 = _15file_timestamp(_23507);
        DeRef(_0);
        _23507 = NOVALUE;

        /** 		if atom(d2) then*/
        _23509 = IS_ATOM(_d2_44342);
        if (_23509 == 0)
        {
            _23509 = NOVALUE;
            goto L4; // [74] 84
        }
        else{
            _23509 = NOVALUE;
        }

        /** 			return 1*/
        DeRef(_d2_44342);
        DeRefDS(_fname_44325);
        DeRef(_d1_44326);
        DeRefDS(_all_files_44336);
        return 1;
L4: 

        /** 		if datetime:diff(d1, d2) > 0 then*/

        /** 	return datetimeToSeconds(dt2) - datetimeToSeconds(dt1)*/
        Ref(_d2_44342);
        _0 = _diff_1__tmp_at88_44351;
        _diff_1__tmp_at88_44351 = _16datetimeToSeconds(_d2_44342);
        DeRef(_0);
        Ref(_d1_44326);
        _0 = _diff_2__tmp_at88_44352;
        _diff_2__tmp_at88_44352 = _16datetimeToSeconds(_d1_44326);
        DeRef(_0);
        DeRef(_diff_inlined_diff_at_88_44350);
        if (IS_ATOM_INT(_diff_1__tmp_at88_44351) && IS_ATOM_INT(_diff_2__tmp_at88_44352)) {
            _diff_inlined_diff_at_88_44350 = _diff_1__tmp_at88_44351 - _diff_2__tmp_at88_44352;
            if ((long)((unsigned long)_diff_inlined_diff_at_88_44350 +(unsigned long) HIGH_BITS) >= 0){
                _diff_inlined_diff_at_88_44350 = NewDouble((double)_diff_inlined_diff_at_88_44350);
            }
        }
        else {
            _diff_inlined_diff_at_88_44350 = binary_op(MINUS, _diff_1__tmp_at88_44351, _diff_2__tmp_at88_44352);
        }
        DeRef(_diff_1__tmp_at88_44351);
        _diff_1__tmp_at88_44351 = NOVALUE;
        DeRef(_diff_2__tmp_at88_44352);
        _diff_2__tmp_at88_44352 = NOVALUE;
        if (binary_op_a(LESSEQ, _diff_inlined_diff_at_88_44350, 0)){
            goto L5; // [103] 114
        }

        /** 			return 1*/
        DeRef(_d2_44342);
        DeRefDS(_fname_44325);
        DeRef(_d1_44326);
        DeRef(_all_files_44336);
        return 1;
L5: 
        DeRef(_d2_44342);
        _d2_44342 = NOVALUE;

        /** 	end for*/
        _i_44340 = _i_44340 + 1;
        goto L2; // [118] 59
L3: 
        ;
    }

    /** 	return 0*/
    DeRefDS(_fname_44325);
    DeRef(_d1_44326);
    DeRef(_all_files_44336);
    return 0;
    ;
}


void _54update_checksum(int _raw_data_44394)
{
    int _23517 = NOVALUE;
    int _0, _1, _2;
    

    /** 	cfile_check = xor_bits(cfile_check, hash( raw_data, stdhash:HSIEH32))*/
    _23517 = calc_hash(_raw_data_44394, -5);
    _0 = _54cfile_check_44378;
    if (IS_ATOM_INT(_54cfile_check_44378) && IS_ATOM_INT(_23517)) {
        {unsigned long tu;
             tu = (unsigned long)_54cfile_check_44378 ^ (unsigned long)_23517;
             _54cfile_check_44378 = MAKE_UINT(tu);
        }
    }
    else {
        if (IS_ATOM_INT(_54cfile_check_44378)) {
            temp_d.dbl = (double)_54cfile_check_44378;
            _54cfile_check_44378 = Dxor_bits(&temp_d, DBL_PTR(_23517));
        }
        else {
            if (IS_ATOM_INT(_23517)) {
                temp_d.dbl = (double)_23517;
                _54cfile_check_44378 = Dxor_bits(DBL_PTR(_54cfile_check_44378), &temp_d);
            }
            else
            _54cfile_check_44378 = Dxor_bits(DBL_PTR(_54cfile_check_44378), DBL_PTR(_23517));
        }
    }
    DeRef(_0);
    DeRef(_23517);
    _23517 = NOVALUE;

    /** end procedure*/
    DeRef(_raw_data_44394);
    return;
    ;
}


void _54write_checksum(int _file_44399)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_file_44399)) {
        _1 = (long)(DBL_PTR(_file_44399)->dbl);
        DeRefDS(_file_44399);
        _file_44399 = _1;
    }

    /** 	printf( file, "\n// 0x%08x\n", cfile_check )*/
    EPrintf(_file_44399, _23519, _54cfile_check_44378);

    /** 	cfile_check = 0*/
    DeRef(_54cfile_check_44378);
    _54cfile_check_44378 = 0;

    /** end procedure*/
    return;
    ;
}


int _54find_file_element(int _needle_44403, int _files_44404)
{
    int _23535 = NOVALUE;
    int _23534 = NOVALUE;
    int _23533 = NOVALUE;
    int _23532 = NOVALUE;
    int _23531 = NOVALUE;
    int _23530 = NOVALUE;
    int _23529 = NOVALUE;
    int _23528 = NOVALUE;
    int _23527 = NOVALUE;
    int _23526 = NOVALUE;
    int _23525 = NOVALUE;
    int _23524 = NOVALUE;
    int _23523 = NOVALUE;
    int _23522 = NOVALUE;
    int _23521 = NOVALUE;
    int _23520 = NOVALUE;
    int _0, _1, _2;
    

    /** 	for j = 1 to length(files) do*/
    if (IS_SEQUENCE(_files_44404)){
            _23520 = SEQ_PTR(_files_44404)->length;
    }
    else {
        _23520 = 1;
    }
    {
        int _j_44406;
        _j_44406 = 1;
L1: 
        if (_j_44406 > _23520){
            goto L2; // [10] 50
        }

        /** 		if equal(files[j][D_NAME],needle) then*/
        _2 = (int)SEQ_PTR(_files_44404);
        _23521 = (int)*(((s1_ptr)_2)->base + _j_44406);
        _2 = (int)SEQ_PTR(_23521);
        _23522 = (int)*(((s1_ptr)_2)->base + 1);
        _23521 = NOVALUE;
        if (_23522 == _needle_44403)
        _23523 = 1;
        else if (IS_ATOM_INT(_23522) && IS_ATOM_INT(_needle_44403))
        _23523 = 0;
        else
        _23523 = (compare(_23522, _needle_44403) == 0);
        _23522 = NOVALUE;
        if (_23523 == 0)
        {
            _23523 = NOVALUE;
            goto L3; // [33] 43
        }
        else{
            _23523 = NOVALUE;
        }

        /** 			return j*/
        DeRefDS(_needle_44403);
        DeRefDS(_files_44404);
        return _j_44406;
L3: 

        /** 	end for*/
        _j_44406 = _j_44406 + 1;
        goto L1; // [45] 17
L2: 
        ;
    }

    /** 	for j = 1 to length(files) do*/
    if (IS_SEQUENCE(_files_44404)){
            _23524 = SEQ_PTR(_files_44404)->length;
    }
    else {
        _23524 = 1;
    }
    {
        int _j_44414;
        _j_44414 = 1;
L4: 
        if (_j_44414 > _23524){
            goto L5; // [55] 103
        }

        /** 		if equal(lower(files[j][D_NAME]),lower(needle)) then*/
        _2 = (int)SEQ_PTR(_files_44404);
        _23525 = (int)*(((s1_ptr)_2)->base + _j_44414);
        _2 = (int)SEQ_PTR(_23525);
        _23526 = (int)*(((s1_ptr)_2)->base + 1);
        _23525 = NOVALUE;
        Ref(_23526);
        _23527 = _12lower(_23526);
        _23526 = NOVALUE;
        RefDS(_needle_44403);
        _23528 = _12lower(_needle_44403);
        if (_23527 == _23528)
        _23529 = 1;
        else if (IS_ATOM_INT(_23527) && IS_ATOM_INT(_23528))
        _23529 = 0;
        else
        _23529 = (compare(_23527, _23528) == 0);
        DeRef(_23527);
        _23527 = NOVALUE;
        DeRef(_23528);
        _23528 = NOVALUE;
        if (_23529 == 0)
        {
            _23529 = NOVALUE;
            goto L6; // [86] 96
        }
        else{
            _23529 = NOVALUE;
        }

        /** 			return j*/
        DeRefDS(_needle_44403);
        DeRefDS(_files_44404);
        return _j_44414;
L6: 

        /** 	end for*/
        _j_44414 = _j_44414 + 1;
        goto L4; // [98] 62
L5: 
        ;
    }

    /** 	for j = 1 to length(files) do*/
    if (IS_SEQUENCE(_files_44404)){
            _23530 = SEQ_PTR(_files_44404)->length;
    }
    else {
        _23530 = 1;
    }
    {
        int _j_44426;
        _j_44426 = 1;
L7: 
        if (_j_44426 > _23530){
            goto L8; // [108] 156
        }

        /** 		if equal(lower(files[j][D_ALTNAME]),lower(needle)) then*/
        _2 = (int)SEQ_PTR(_files_44404);
        _23531 = (int)*(((s1_ptr)_2)->base + _j_44426);
        _2 = (int)SEQ_PTR(_23531);
        _23532 = (int)*(((s1_ptr)_2)->base + 11);
        _23531 = NOVALUE;
        Ref(_23532);
        _23533 = _12lower(_23532);
        _23532 = NOVALUE;
        RefDS(_needle_44403);
        _23534 = _12lower(_needle_44403);
        if (_23533 == _23534)
        _23535 = 1;
        else if (IS_ATOM_INT(_23533) && IS_ATOM_INT(_23534))
        _23535 = 0;
        else
        _23535 = (compare(_23533, _23534) == 0);
        DeRef(_23533);
        _23533 = NOVALUE;
        DeRef(_23534);
        _23534 = NOVALUE;
        if (_23535 == 0)
        {
            _23535 = NOVALUE;
            goto L9; // [139] 149
        }
        else{
            _23535 = NOVALUE;
        }

        /** 			return j*/
        DeRefDS(_needle_44403);
        DeRefDS(_files_44404);
        return _j_44426;
L9: 

        /** 	end for*/
        _j_44426 = _j_44426 + 1;
        goto L7; // [151] 115
L8: 
        ;
    }

    /** 	return 0*/
    DeRefDS(_needle_44403);
    DeRefDS(_files_44404);
    return 0;
    ;
}


int _54adjust_for_command_line_passing(int _long_path_44447)
{
    int _slash_44448 = NOVALUE;
    int _longs_44456 = NOVALUE;
    int _short_path_44462 = NOVALUE;
    int _files_44468 = NOVALUE;
    int _file_location_44471 = NOVALUE;
    int _23574 = NOVALUE;
    int _23573 = NOVALUE;
    int _23571 = NOVALUE;
    int _23570 = NOVALUE;
    int _23568 = NOVALUE;
    int _23567 = NOVALUE;
    int _23565 = NOVALUE;
    int _23564 = NOVALUE;
    int _23561 = NOVALUE;
    int _23560 = NOVALUE;
    int _23558 = NOVALUE;
    int _23557 = NOVALUE;
    int _23556 = NOVALUE;
    int _23555 = NOVALUE;
    int _23554 = NOVALUE;
    int _23552 = NOVALUE;
    int _23551 = NOVALUE;
    int _23549 = NOVALUE;
    int _23547 = NOVALUE;
    int _23545 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if compiler_type = COMPILER_GCC then*/

    /** 	elsif compiler_type = COMPILER_WATCOM then*/

    /** 		slash = SLASH*/
    _slash_44448 = 92;

    /** 	ifdef UNIX then*/

    /** 		long_path = regex:find_replace(quote_pattern, long_path, "")*/
    Ref(_54quote_pattern_44440);
    RefDS(_long_path_44447);
    RefDS(_22037);
    _0 = _long_path_44447;
    _long_path_44447 = _50find_replace(_54quote_pattern_44440, _long_path_44447, _22037, 1, 0);
    DeRefDS(_0);

    /** 		sequence longs = split( slash_pattern, long_path )*/
    Ref(_54slash_pattern_44437);
    RefDS(_long_path_44447);
    _0 = _longs_44456;
    _longs_44456 = _50split(_54slash_pattern_44437, _long_path_44447, 1, 0);
    DeRef(_0);

    /** 		if length(longs)=0 then*/
    if (IS_SEQUENCE(_longs_44456)){
            _23545 = SEQ_PTR(_longs_44456)->length;
    }
    else {
        _23545 = 1;
    }
    if (_23545 != 0)
    goto L1; // [79] 90

    /** 			return long_path*/
    DeRefDS(_longs_44456);
    DeRef(_short_path_44462);
    return _long_path_44447;
L1: 

    /** 		sequence short_path = longs[1] & slash*/
    _2 = (int)SEQ_PTR(_longs_44456);
    _23547 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_23547) && IS_ATOM(_slash_44448)) {
        Append(&_short_path_44462, _23547, _slash_44448);
    }
    else if (IS_ATOM(_23547) && IS_SEQUENCE(_slash_44448)) {
    }
    else {
        Concat((object_ptr)&_short_path_44462, _23547, _slash_44448);
        _23547 = NOVALUE;
    }
    _23547 = NOVALUE;

    /** 		for i = 2 to length(longs) do*/
    if (IS_SEQUENCE(_longs_44456)){
            _23549 = SEQ_PTR(_longs_44456)->length;
    }
    else {
        _23549 = 1;
    }
    {
        int _i_44466;
        _i_44466 = 2;
L2: 
        if (_i_44466 > _23549){
            goto L3; // [107] 266
        }

        /** 			object files = dir(short_path)*/
        RefDS(_short_path_44462);
        _0 = _files_44468;
        _files_44468 = _15dir(_short_path_44462);
        DeRef(_0);

        /** 			integer file_location = 0*/
        _file_location_44471 = 0;

        /** 			if sequence(files) then*/
        _23551 = IS_SEQUENCE(_files_44468);
        if (_23551 == 0)
        {
            _23551 = NOVALUE;
            goto L4; // [130] 147
        }
        else{
            _23551 = NOVALUE;
        }

        /** 				file_location = find_file_element(longs[i], files)*/
        _2 = (int)SEQ_PTR(_longs_44456);
        _23552 = (int)*(((s1_ptr)_2)->base + _i_44466);
        Ref(_23552);
        Ref(_files_44468);
        _file_location_44471 = _54find_file_element(_23552, _files_44468);
        _23552 = NOVALUE;
        if (!IS_ATOM_INT(_file_location_44471)) {
            _1 = (long)(DBL_PTR(_file_location_44471)->dbl);
            DeRefDS(_file_location_44471);
            _file_location_44471 = _1;
        }
L4: 

        /** 			if file_location then*/
        if (_file_location_44471 == 0)
        {
            goto L5; // [149] 215
        }
        else{
        }

        /** 				if sequence(files[file_location][D_ALTNAME]) then*/
        _2 = (int)SEQ_PTR(_files_44468);
        _23554 = (int)*(((s1_ptr)_2)->base + _file_location_44471);
        _2 = (int)SEQ_PTR(_23554);
        _23555 = (int)*(((s1_ptr)_2)->base + 11);
        _23554 = NOVALUE;
        _23556 = IS_SEQUENCE(_23555);
        _23555 = NOVALUE;
        if (_23556 == 0)
        {
            _23556 = NOVALUE;
            goto L6; // [167] 189
        }
        else{
            _23556 = NOVALUE;
        }

        /** 					short_path &= files[file_location][D_ALTNAME]*/
        _2 = (int)SEQ_PTR(_files_44468);
        _23557 = (int)*(((s1_ptr)_2)->base + _file_location_44471);
        _2 = (int)SEQ_PTR(_23557);
        _23558 = (int)*(((s1_ptr)_2)->base + 11);
        _23557 = NOVALUE;
        if (IS_SEQUENCE(_short_path_44462) && IS_ATOM(_23558)) {
            Ref(_23558);
            Append(&_short_path_44462, _short_path_44462, _23558);
        }
        else if (IS_ATOM(_short_path_44462) && IS_SEQUENCE(_23558)) {
        }
        else {
            Concat((object_ptr)&_short_path_44462, _short_path_44462, _23558);
        }
        _23558 = NOVALUE;
        goto L7; // [186] 206
L6: 

        /** 					short_path &= files[file_location][D_NAME]*/
        _2 = (int)SEQ_PTR(_files_44468);
        _23560 = (int)*(((s1_ptr)_2)->base + _file_location_44471);
        _2 = (int)SEQ_PTR(_23560);
        _23561 = (int)*(((s1_ptr)_2)->base + 1);
        _23560 = NOVALUE;
        if (IS_SEQUENCE(_short_path_44462) && IS_ATOM(_23561)) {
            Ref(_23561);
            Append(&_short_path_44462, _short_path_44462, _23561);
        }
        else if (IS_ATOM(_short_path_44462) && IS_SEQUENCE(_23561)) {
        }
        else {
            Concat((object_ptr)&_short_path_44462, _short_path_44462, _23561);
        }
        _23561 = NOVALUE;
L7: 

        /** 				short_path &= slash*/
        Append(&_short_path_44462, _short_path_44462, _slash_44448);
        goto L8; // [212] 257
L5: 

        /** 				if not find(' ',longs[i]) then*/
        _2 = (int)SEQ_PTR(_longs_44456);
        _23564 = (int)*(((s1_ptr)_2)->base + _i_44466);
        _23565 = find_from(32, _23564, 1);
        _23564 = NOVALUE;
        if (_23565 != 0)
        goto L9; // [226] 250
        _23565 = NOVALUE;

        /** 					short_path &= longs[i] & slash*/
        _2 = (int)SEQ_PTR(_longs_44456);
        _23567 = (int)*(((s1_ptr)_2)->base + _i_44466);
        if (IS_SEQUENCE(_23567) && IS_ATOM(_slash_44448)) {
            Append(&_23568, _23567, _slash_44448);
        }
        else if (IS_ATOM(_23567) && IS_SEQUENCE(_slash_44448)) {
        }
        else {
            Concat((object_ptr)&_23568, _23567, _slash_44448);
            _23567 = NOVALUE;
        }
        _23567 = NOVALUE;
        Concat((object_ptr)&_short_path_44462, _short_path_44462, _23568);
        DeRefDS(_23568);
        _23568 = NOVALUE;

        /** 					continue*/
        DeRef(_files_44468);
        _files_44468 = NOVALUE;
        goto LA; // [247] 261
L9: 

        /** 				return 0*/
        DeRef(_files_44468);
        DeRefDS(_long_path_44447);
        DeRef(_longs_44456);
        DeRef(_short_path_44462);
        return 0;
L8: 
        DeRef(_files_44468);
        _files_44468 = NOVALUE;

        /** 		end for -- i*/
LA: 
        _i_44466 = _i_44466 + 1;
        goto L2; // [261] 114
L3: 
        ;
    }

    /** 		if short_path[$] = slash then*/
    if (IS_SEQUENCE(_short_path_44462)){
            _23570 = SEQ_PTR(_short_path_44462)->length;
    }
    else {
        _23570 = 1;
    }
    _2 = (int)SEQ_PTR(_short_path_44462);
    _23571 = (int)*(((s1_ptr)_2)->base + _23570);
    if (binary_op_a(NOTEQ, _23571, _slash_44448)){
        _23571 = NOVALUE;
        goto LB; // [275] 294
    }
    _23571 = NOVALUE;

    /** 			short_path = short_path[1..$-1]*/
    if (IS_SEQUENCE(_short_path_44462)){
            _23573 = SEQ_PTR(_short_path_44462)->length;
    }
    else {
        _23573 = 1;
    }
    _23574 = _23573 - 1;
    _23573 = NOVALUE;
    rhs_slice_target = (object_ptr)&_short_path_44462;
    RHS_Slice(_short_path_44462, 1, _23574);
LB: 

    /** 		return short_path*/
    DeRefDS(_long_path_44447);
    DeRef(_longs_44456);
    DeRef(_23574);
    _23574 = NOVALUE;
    return _short_path_44462;
    ;
}


int _54adjust_for_build_file(int _long_path_44509)
{
    int _short_path_44510 = NOVALUE;
    int _23582 = NOVALUE;
    int _23581 = NOVALUE;
    int _23580 = NOVALUE;
    int _23579 = NOVALUE;
    int _23578 = NOVALUE;
    int _23577 = NOVALUE;
    int _0, _1, _2;
    

    /**     object short_path = adjust_for_command_line_passing(long_path)*/
    RefDS(_long_path_44509);
    _0 = _short_path_44510;
    _short_path_44510 = _54adjust_for_command_line_passing(_long_path_44509);
    DeRef(_0);

    /**     if atom(short_path) then*/
    _23577 = IS_ATOM(_short_path_44510);
    if (_23577 == 0)
    {
        _23577 = NOVALUE;
        goto L1; // [14] 24
    }
    else{
        _23577 = NOVALUE;
    }

    /**     	return short_path*/
    DeRefDS(_long_path_44509);
    return _short_path_44510;
L1: 

    /** 	if compiler_type = COMPILER_GCC and build_system_type != BUILD_DIRECT and TWINDOWS then*/
    _23578 = (0 == 1);
    if (_23578 == 0) {
        _23579 = 0;
        goto L2; // [32] 46
    }
    _23580 = (3 != 3);
    _23579 = (_23580 != 0);
L2: 
    if (_23579 == 0) {
        goto L3; // [46] 69
    }
    if (_36TWINDOWS_14305 == 0)
    {
        goto L3; // [53] 69
    }
    else{
    }

    /** 		return windows_to_mingw_path(short_path)*/
    Ref(_short_path_44510);
    _23582 = _54windows_to_mingw_path(_short_path_44510);
    DeRefDS(_long_path_44509);
    DeRef(_short_path_44510);
    DeRef(_23578);
    _23578 = NOVALUE;
    DeRef(_23580);
    _23580 = NOVALUE;
    return _23582;
    goto L4; // [66] 76
L3: 

    /** 		return short_path*/
    DeRefDS(_long_path_44509);
    DeRef(_23578);
    _23578 = NOVALUE;
    DeRef(_23580);
    _23580 = NOVALUE;
    DeRef(_23582);
    _23582 = NOVALUE;
    return _short_path_44510;
L4: 
    ;
}


int _54setup_build()
{
    int _c_exe_44525 = NOVALUE;
    int _c_flags_44526 = NOVALUE;
    int _l_exe_44527 = NOVALUE;
    int _l_flags_44528 = NOVALUE;
    int _obj_ext_44529 = NOVALUE;
    int _exe_ext_44530 = NOVALUE;
    int _l_flags_begin_44531 = NOVALUE;
    int _rc_comp_44532 = NOVALUE;
    int _l_names_44533 = NOVALUE;
    int _l_ext_44534 = NOVALUE;
    int _t_slash_44535 = NOVALUE;
    int _eudir_44555 = NOVALUE;
    int _compile_dir_44613 = NOVALUE;
    int _23709 = NOVALUE;
    int _23708 = NOVALUE;
    int _23707 = NOVALUE;
    int _23704 = NOVALUE;
    int _23703 = NOVALUE;
    int _23700 = NOVALUE;
    int _23699 = NOVALUE;
    int _23692 = NOVALUE;
    int _23691 = NOVALUE;
    int _23686 = NOVALUE;
    int _23685 = NOVALUE;
    int _23680 = NOVALUE;
    int _23679 = NOVALUE;
    int _23676 = NOVALUE;
    int _23675 = NOVALUE;
    int _23665 = NOVALUE;
    int _23664 = NOVALUE;
    int _23649 = NOVALUE;
    int _23648 = NOVALUE;
    int _23644 = NOVALUE;
    int _23642 = NOVALUE;
    int _23641 = NOVALUE;
    int _23640 = NOVALUE;
    int _23639 = NOVALUE;
    int _23627 = NOVALUE;
    int _23626 = NOVALUE;
    int _23623 = NOVALUE;
    int _23611 = NOVALUE;
    int _23607 = NOVALUE;
    int _23604 = NOVALUE;
    int _23603 = NOVALUE;
    int _23602 = NOVALUE;
    int _23599 = NOVALUE;
    int _23598 = NOVALUE;
    int _23597 = NOVALUE;
    int _23594 = NOVALUE;
    int _23590 = NOVALUE;
    int _23583 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence c_exe   = "", c_flags = "", l_exe   = "", l_flags = "", obj_ext = "",*/
    RefDS(_22037);
    DeRefi(_c_exe_44525);
    _c_exe_44525 = _22037;
    RefDS(_22037);
    DeRef(_c_flags_44526);
    _c_flags_44526 = _22037;
    RefDS(_22037);
    DeRefi(_l_exe_44527);
    _l_exe_44527 = _22037;
    RefDS(_22037);
    DeRefi(_l_flags_44528);
    _l_flags_44528 = _22037;
    RefDS(_22037);
    DeRefi(_obj_ext_44529);
    _obj_ext_44529 = _22037;

    /** 		exe_ext = "", l_flags_begin = "", rc_comp = "", l_names, l_ext, t_slash*/
    RefDS(_22037);
    DeRefi(_exe_ext_44530);
    _exe_ext_44530 = _22037;
    RefDS(_22037);
    DeRefi(_l_flags_begin_44531);
    _l_flags_begin_44531 = _22037;
    RefDS(_22037);
    DeRef(_rc_comp_44532);
    _rc_comp_44532 = _22037;

    /** 	if length(user_library) = 0 then*/
    if (IS_SEQUENCE(_56user_library_41728)){
            _23583 = SEQ_PTR(_56user_library_41728)->length;
    }
    else {
        _23583 = 1;
    }
    if (_23583 != 0)
    goto L1; // [52] 257

    /** 		if debug_option then*/
    if (_56debug_option_41726 == 0)
    {
        goto L2; // [60] 72
    }
    else{
    }

    /** 			l_names = { "eudbg", "eu" }*/
    RefDS(_23586);
    RefDS(_23585);
    DeRef(_l_names_44533);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _23585;
    ((int *)_2)[2] = _23586;
    _l_names_44533 = MAKE_SEQ(_1);
    goto L3; // [69] 79
L2: 

    /** 			l_names = { "eu", "eudbg" }*/
    RefDS(_23585);
    RefDS(_23586);
    DeRef(_l_names_44533);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _23586;
    ((int *)_2)[2] = _23585;
    _l_names_44533 = MAKE_SEQ(_1);
L3: 

    /** 		if TUNIX or compiler_type = COMPILER_GCC then*/
    if (0 != 0) {
        goto L4; // [83] 98
    }
    _23590 = (0 == 1);
    if (_23590 == 0)
    {
        DeRef(_23590);
        _23590 = NOVALUE;
        goto L5; // [94] 115
    }
    else{
        DeRef(_23590);
        _23590 = NOVALUE;
    }
L4: 

    /** 			l_ext = "a"*/
    RefDS(_22275);
    DeRefi(_l_ext_44534);
    _l_ext_44534 = _22275;

    /** 			t_slash = "/"*/
    RefDS(_23480);
    DeRefi(_t_slash_44535);
    _t_slash_44535 = _23480;
    goto L6; // [112] 138
L5: 

    /** 		elsif TWINDOWS then*/
    if (_36TWINDOWS_14305 == 0)
    {
        goto L7; // [119] 137
    }
    else{
    }

    /** 			l_ext = "lib"*/
    RefDS(_23591);
    DeRefi(_l_ext_44534);
    _l_ext_44534 = _23591;

    /** 			t_slash = "\\"*/
    RefDS(_23592);
    DeRefi(_t_slash_44535);
    _t_slash_44535 = _23592;
L7: 
L6: 

    /** 		object eudir = get_eucompiledir()*/
    _0 = _eudir_44555;
    _eudir_44555 = _56get_eucompiledir();
    DeRef(_0);

    /** 		if not file_exists(eudir) then*/
    Ref(_eudir_44555);
    _23594 = _15file_exists(_eudir_44555);
    if (IS_ATOM_INT(_23594)) {
        if (_23594 != 0){
            DeRef(_23594);
            _23594 = NOVALUE;
            goto L8; // [149] 170
        }
    }
    else {
        if (DBL_PTR(_23594)->dbl != 0.0){
            DeRef(_23594);
            _23594 = NOVALUE;
            goto L8; // [149] 170
        }
    }
    DeRef(_23594);
    _23594 = NOVALUE;

    /** 			printf(2,"Supplied directory \'%s\' is not a valid EUDIR\n",{get_eucompiledir()})*/
    _23597 = _56get_eucompiledir();
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _23597;
    _23598 = MAKE_SEQ(_1);
    _23597 = NOVALUE;
    EPrintf(2, _23596, _23598);
    DeRefDS(_23598);
    _23598 = NOVALUE;

    /** 			abort(1)*/
    UserCleanup(1);
L8: 

    /** 		for tk = 1 to length(l_names) label "translation kind" do*/
    _23599 = 2;
    {
        int _tk_44567;
        _tk_44567 = 1;
L9: 
        if (_tk_44567 > 2){
            goto LA; // [177] 256
        }

        /** 			user_library = eudir & sprintf("%sbin%s%s.%s",{t_slash, t_slash, l_names[tk],l_ext})*/
        _2 = (int)SEQ_PTR(_l_names_44533);
        _23602 = (int)*(((s1_ptr)_2)->base + _tk_44567);
        _1 = NewS1(4);
        _2 = (int)((s1_ptr)_1)->base;
        RefDSn(_t_slash_44535, 2);
        *((int *)(_2+4)) = _t_slash_44535;
        *((int *)(_2+8)) = _t_slash_44535;
        RefDS(_23602);
        *((int *)(_2+12)) = _23602;
        RefDS(_l_ext_44534);
        *((int *)(_2+16)) = _l_ext_44534;
        _23603 = MAKE_SEQ(_1);
        _23602 = NOVALUE;
        _23604 = EPrintf(-9999999, _23601, _23603);
        DeRefDS(_23603);
        _23603 = NOVALUE;
        if (IS_SEQUENCE(_eudir_44555) && IS_ATOM(_23604)) {
        }
        else if (IS_ATOM(_eudir_44555) && IS_SEQUENCE(_23604)) {
            Ref(_eudir_44555);
            Prepend(&_56user_library_41728, _23604, _eudir_44555);
        }
        else {
            Concat((object_ptr)&_56user_library_41728, _eudir_44555, _23604);
        }
        DeRefDS(_23604);
        _23604 = NOVALUE;

        /** 			if TUNIX or compiler_type = COMPILER_GCC then*/
        if (0 != 0) {
            goto LB; // [215] 230
        }
        _23607 = (0 == 1);
        if (_23607 == 0)
        {
            DeRef(_23607);
            _23607 = NOVALUE;
            goto LC; // [226] 233
        }
        else{
            DeRef(_23607);
            _23607 = NOVALUE;
        }
LB: 

        /** 				ifdef UNIX then*/
LC: 

        /** 			if file_exists(user_library) then*/
        RefDS(_56user_library_41728);
        _23611 = _15file_exists(_56user_library_41728);
        if (_23611 == 0) {
            DeRef(_23611);
            _23611 = NOVALUE;
            goto LD; // [241] 249
        }
        else {
            if (!IS_ATOM_INT(_23611) && DBL_PTR(_23611)->dbl == 0.0){
                DeRef(_23611);
                _23611 = NOVALUE;
                goto LD; // [241] 249
            }
            DeRef(_23611);
            _23611 = NOVALUE;
        }
        DeRef(_23611);
        _23611 = NOVALUE;

        /** 				exit "translation kind"*/
        goto LA; // [246] 256
LD: 

        /** 		end for -- tk*/
        _tk_44567 = _tk_44567 + 1;
        goto L9; // [251] 184
LA: 
        ;
    }
L1: 
    DeRef(_eudir_44555);
    _eudir_44555 = NOVALUE;

    /** 	user_library = adjust_for_build_file(user_library)*/
    RefDS(_56user_library_41728);
    _0 = _54adjust_for_build_file(_56user_library_41728);
    DeRefDS(_56user_library_41728);
    _56user_library_41728 = _0;

    /** 	if TWINDOWS then*/
    if (_36TWINDOWS_14305 == 0)
    {
        goto LE; // [273] 328
    }
    else{
    }

    /** 		if compiler_type = COMPILER_WATCOM then*/

    /** 			c_flags &= " -DEWINDOWS"*/
    Concat((object_ptr)&_c_flags_44526, _c_flags_44526, _23616);

    /** 		if dll_option then*/
    if (_56dll_option_41716 == 0)
    {
        goto LF; // [304] 317
    }
    else{
    }

    /** 			exe_ext = ".dll"*/
    RefDS(_23618);
    DeRefi(_exe_ext_44530);
    _exe_ext_44530 = _23618;
    goto L10; // [314] 369
LF: 

    /** 			exe_ext = ".exe"*/
    RefDS(_23619);
    DeRefi(_exe_ext_44530);
    _exe_ext_44530 = _23619;
    goto L10; // [325] 369
LE: 

    /** 	elsif TOSX then*/

    /** 		if dll_option then*/
    if (_56dll_option_41716 == 0)
    {
        goto L11; // [357] 368
    }
    else{
    }

    /** 			exe_ext = ".so"*/
    RefDS(_23621);
    DeRefi(_exe_ext_44530);
    _exe_ext_44530 = _23621;
L11: 
L10: 

    /** 	object compile_dir = get_eucompiledir()*/
    _0 = _compile_dir_44613;
    _compile_dir_44613 = _56get_eucompiledir();
    DeRef(_0);

    /** 	if not file_exists(compile_dir) then*/
    Ref(_compile_dir_44613);
    _23623 = _15file_exists(_compile_dir_44613);
    if (IS_ATOM_INT(_23623)) {
        if (_23623 != 0){
            DeRef(_23623);
            _23623 = NOVALUE;
            goto L12; // [380] 401
        }
    }
    else {
        if (DBL_PTR(_23623)->dbl != 0.0){
            DeRef(_23623);
            _23623 = NOVALUE;
            goto L12; // [380] 401
        }
    }
    DeRef(_23623);
    _23623 = NOVALUE;

    /** 		printf(2,"Couldn't get include directory '%s'",{get_eucompiledir()})*/
    _23626 = _56get_eucompiledir();
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _23626;
    _23627 = MAKE_SEQ(_1);
    _23626 = NOVALUE;
    EPrintf(2, _23625, _23627);
    DeRefDS(_23627);
    _23627 = NOVALUE;

    /** 		abort(1)*/
    UserCleanup(1);
L12: 

    /** 	switch compiler_type do*/
    _0 = 0;
    switch ( _0 ){ 

        /** 		case COMPILER_GCC then*/
        case 1:

        /** 			c_exe = "gcc"*/
        RefDS(_23630);
        DeRefi(_c_exe_44525);
        _c_exe_44525 = _23630;

        /** 			l_exe = "gcc"*/
        RefDS(_23630);
        DeRefi(_l_exe_44527);
        _l_exe_44527 = _23630;

        /** 			obj_ext = "o"*/
        RefDS(_23631);
        DeRefi(_obj_ext_44529);
        _obj_ext_44529 = _23631;

        /** 			if debug_option then*/
        if (_56debug_option_41726 == 0)
        {
            goto L13; // [439] 451
        }
        else{
        }

        /** 				c_flags &= " -g3"*/
        Concat((object_ptr)&_c_flags_44526, _c_flags_44526, _23632);
        goto L14; // [448] 458
L13: 

        /** 				c_flags &= " -fomit-frame-pointer"*/
        Concat((object_ptr)&_c_flags_44526, _c_flags_44526, _23634);
L14: 

        /** 			if dll_option then*/
        if (_56dll_option_41716 == 0)
        {
            goto L15; // [462] 472
        }
        else{
        }

        /** 				c_flags &= " -fPIC"*/
        Concat((object_ptr)&_c_flags_44526, _c_flags_44526, _23636);
L15: 

        /** 			c_flags &= sprintf(" -c -w -fsigned-char -O2 -m32 -I%s -ffast-math",*/
        _23639 = _56get_eucompiledir();
        _23640 = _54adjust_for_build_file(_23639);
        _23639 = NOVALUE;
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = _23640;
        _23641 = MAKE_SEQ(_1);
        _23640 = NOVALUE;
        _23642 = EPrintf(-9999999, _23638, _23641);
        DeRefDS(_23641);
        _23641 = NOVALUE;
        Concat((object_ptr)&_c_flags_44526, _c_flags_44526, _23642);
        DeRefDS(_23642);
        _23642 = NOVALUE;

        /** 			if TWINDOWS and mno_cygwin then*/
        if (_36TWINDOWS_14305 == 0) {
            goto L16; // [497] 514
        }
        goto L16; // [504] 514

        /** 				c_flags &= " -mno-cygwin"*/
        Concat((object_ptr)&_c_flags_44526, _c_flags_44526, _23645);
L16: 

        /** 			l_flags = sprintf( "%s -m32 ", { adjust_for_build_file(user_library) })*/
        RefDS(_56user_library_41728);
        _23648 = _54adjust_for_build_file(_56user_library_41728);
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = _23648;
        _23649 = MAKE_SEQ(_1);
        _23648 = NOVALUE;
        DeRefi(_l_flags_44528);
        _l_flags_44528 = EPrintf(-9999999, _23647, _23649);
        DeRefDS(_23649);
        _23649 = NOVALUE;

        /** 			if dll_option then*/
        if (_56dll_option_41716 == 0)
        {
            goto L17; // [534] 544
        }
        else{
        }

        /** 				l_flags &= " -shared "*/
        Concat((object_ptr)&_l_flags_44528, _l_flags_44528, _23651);
L17: 

        /** 			if TLINUX then*/

        /** 			elsif TBSD then*/

        /** 			elsif TOSX then*/

        /** 			elsif TWINDOWS then*/
        if (_36TWINDOWS_14305 == 0)
        {
            goto L18; // [596] 628
        }
        else{
        }

        /** 				if mno_cygwin then*/

        /** 				if not con_option then*/
        if (_56con_option_41718 != 0)
        goto L19; // [617] 627

        /** 					l_flags &= " -mwindows"*/
        Concat((object_ptr)&_l_flags_44528, _l_flags_44528, _23661);
L19: 
L18: 

        /** 			rc_comp = "windres -DSRCDIR=\"" & adjust_for_build_file(current_dir()) & "\" [1] -O coff -o [2]"*/
        _23664 = _15current_dir();
        _23665 = _54adjust_for_build_file(_23664);
        _23664 = NOVALUE;
        {
            int concat_list[3];

            concat_list[0] = _23666;
            concat_list[1] = _23665;
            concat_list[2] = _23663;
            Concat_N((object_ptr)&_rc_comp_44532, concat_list, 3);
        }
        DeRef(_23665);
        _23665 = NOVALUE;
        goto L1A; // [644] 843

        /** 		case COMPILER_WATCOM then*/
        case 2:

        /** 			c_exe = "wcc386"*/
        RefDS(_23668);
        DeRefi(_c_exe_44525);
        _c_exe_44525 = _23668;

        /** 			l_exe = "wlink"*/
        RefDS(_23669);
        DeRefi(_l_exe_44527);
        _l_exe_44527 = _23669;

        /** 			obj_ext = "obj"*/
        RefDS(_23670);
        DeRefi(_obj_ext_44529);
        _obj_ext_44529 = _23670;

        /** 			if debug_option then*/
        if (_56debug_option_41726 == 0)
        {
            goto L1B; // [675] 692
        }
        else{
        }

        /** 				c_flags = " /d3"*/
        RefDS(_23671);
        DeRef(_c_flags_44526);
        _c_flags_44526 = _23671;

        /** 				l_flags_begin &= " DEBUG ALL "*/
        Concat((object_ptr)&_l_flags_begin_44531, _l_flags_begin_44531, _23672);
L1B: 

        /** 			l_flags &= sprintf(" OPTION STACK=%d ", { total_stack_size })*/
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = _56total_stack_size_41730;
        _23675 = MAKE_SEQ(_1);
        _23676 = EPrintf(-9999999, _23674, _23675);
        DeRefDS(_23675);
        _23675 = NOVALUE;
        Concat((object_ptr)&_l_flags_44528, _l_flags_44528, _23676);
        DeRefDS(_23676);
        _23676 = NOVALUE;

        /** 			l_flags &= sprintf(" COMMIT STACK=%d ", { total_stack_size })*/
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = _56total_stack_size_41730;
        _23679 = MAKE_SEQ(_1);
        _23680 = EPrintf(-9999999, _23678, _23679);
        DeRefDS(_23679);
        _23679 = NOVALUE;
        Concat((object_ptr)&_l_flags_44528, _l_flags_44528, _23680);
        DeRefDS(_23680);
        _23680 = NOVALUE;

        /** 			l_flags &= " OPTION QUIET OPTION ELIMINATE OPTION CASEEXACT"*/
        Concat((object_ptr)&_l_flags_44528, _l_flags_44528, _23682);

        /** 			if dll_option then*/
        if (_56dll_option_41716 == 0)
        {
            goto L1C; // [734] 760
        }
        else{
        }

        /** 				c_flags &= " /bd /bt=nt /mf /w0 /zq /j /zp4 /fp5 /fpi87 /5r /otimra /s /I" & adjust_for_build_file(compile_dir) */
        Ref(_compile_dir_44613);
        _23685 = _54adjust_for_build_file(_compile_dir_44613);
        if (IS_SEQUENCE(_23684) && IS_ATOM(_23685)) {
            Ref(_23685);
            Append(&_23686, _23684, _23685);
        }
        else if (IS_ATOM(_23684) && IS_SEQUENCE(_23685)) {
        }
        else {
            Concat((object_ptr)&_23686, _23684, _23685);
        }
        DeRef(_23685);
        _23685 = NOVALUE;
        Concat((object_ptr)&_c_flags_44526, _c_flags_44526, _23686);
        DeRefDS(_23686);
        _23686 = NOVALUE;

        /** 				l_flags &= " SYSTEM NT_DLL initinstance terminstance"*/
        Concat((object_ptr)&_l_flags_44528, _l_flags_44528, _23688);
        goto L1D; // [757] 798
L1C: 

        /** 				c_flags &= " /bt=nt /mf /w0 /zq /j /zp4 /fp5 /fpi87 /5r /otimra /s /I" & adjust_for_build_file(compile_dir)*/
        Ref(_compile_dir_44613);
        _23691 = _54adjust_for_build_file(_compile_dir_44613);
        if (IS_SEQUENCE(_23690) && IS_ATOM(_23691)) {
            Ref(_23691);
            Append(&_23692, _23690, _23691);
        }
        else if (IS_ATOM(_23690) && IS_SEQUENCE(_23691)) {
        }
        else {
            Concat((object_ptr)&_23692, _23690, _23691);
        }
        DeRef(_23691);
        _23691 = NOVALUE;
        Concat((object_ptr)&_c_flags_44526, _c_flags_44526, _23692);
        DeRefDS(_23692);
        _23692 = NOVALUE;

        /** 				if con_option then*/
        if (_56con_option_41718 == 0)
        {
            goto L1E; // [778] 790
        }
        else{
        }

        /** 					l_flags = " SYSTEM NT" & l_flags*/
        Concat((object_ptr)&_l_flags_44528, _23694, _l_flags_44528);
        goto L1F; // [787] 797
L1E: 

        /** 					l_flags = " SYSTEM NT_WIN RUNTIME WINDOWS=4.0" & l_flags*/
        Concat((object_ptr)&_l_flags_44528, _23696, _l_flags_44528);
L1F: 
L1D: 

        /** 			l_flags &= sprintf(" FILE %s", { (user_library) })*/
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        RefDS(_56user_library_41728);
        *((int *)(_2+4)) = _56user_library_41728;
        _23699 = MAKE_SEQ(_1);
        _23700 = EPrintf(-9999999, _23698, _23699);
        DeRefDS(_23699);
        _23699 = NOVALUE;
        Concat((object_ptr)&_l_flags_44528, _l_flags_44528, _23700);
        DeRefDS(_23700);
        _23700 = NOVALUE;

        /** 			rc_comp = "wrc -DSRCDIR=\"" & adjust_for_build_file(current_dir()) & "\" -q -fo=[2] -ad [1] [3]"*/
        _23703 = _15current_dir();
        _23704 = _54adjust_for_build_file(_23703);
        _23703 = NOVALUE;
        {
            int concat_list[3];

            concat_list[0] = _23705;
            concat_list[1] = _23704;
            concat_list[2] = _23702;
            Concat_N((object_ptr)&_rc_comp_44532, concat_list, 3);
        }
        DeRef(_23704);
        _23704 = NOVALUE;
        goto L1A; // [829] 843

        /** 		case else*/
        default:

        /** 			CompileErr(43)*/
        RefDS(_22037);
        _43CompileErr(43, _22037, 0);
    ;}L1A: 

    /** 	if length(cflags) then*/
    _23707 = 0;

    /** 	if length(lflags) then*/
    _23708 = 0;

    /** 	return { */
    _1 = NewS1(8);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_c_exe_44525);
    *((int *)(_2+4)) = _c_exe_44525;
    RefDS(_c_flags_44526);
    *((int *)(_2+8)) = _c_flags_44526;
    RefDS(_l_exe_44527);
    *((int *)(_2+12)) = _l_exe_44527;
    RefDS(_l_flags_44528);
    *((int *)(_2+16)) = _l_flags_44528;
    RefDS(_obj_ext_44529);
    *((int *)(_2+20)) = _obj_ext_44529;
    RefDS(_exe_ext_44530);
    *((int *)(_2+24)) = _exe_ext_44530;
    RefDS(_l_flags_begin_44531);
    *((int *)(_2+28)) = _l_flags_begin_44531;
    RefDS(_rc_comp_44532);
    *((int *)(_2+32)) = _rc_comp_44532;
    _23709 = MAKE_SEQ(_1);
    DeRefDSi(_c_exe_44525);
    DeRefDS(_c_flags_44526);
    DeRefDSi(_l_exe_44527);
    DeRefDSi(_l_flags_44528);
    DeRefDSi(_obj_ext_44529);
    DeRefDSi(_exe_ext_44530);
    DeRefDSi(_l_flags_begin_44531);
    DeRefDS(_rc_comp_44532);
    DeRef(_l_names_44533);
    DeRefi(_l_ext_44534);
    DeRefi(_t_slash_44535);
    DeRef(_compile_dir_44613);
    return _23709;
    ;
}


void _54ensure_exename(int _ext_44749)
{
    int _23716 = NOVALUE;
    int _23715 = NOVALUE;
    int _23714 = NOVALUE;
    int _23713 = NOVALUE;
    int _23711 = NOVALUE;
    int _23710 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if length(exe_name[D_ALTNAME]) = 0 then*/
    _2 = (int)SEQ_PTR(_54exe_name_44364);
    _23710 = (int)*(((s1_ptr)_2)->base + 11);
    if (IS_SEQUENCE(_23710)){
            _23711 = SEQ_PTR(_23710)->length;
    }
    else {
        _23711 = 1;
    }
    _23710 = NOVALUE;
    if (_23711 != 0)
    goto L1; // [16] 67

    /** 		exe_name[D_NAME] = current_dir() & SLASH & file0 & ext*/
    _23713 = _15current_dir();
    {
        int concat_list[4];

        concat_list[0] = _ext_44749;
        concat_list[1] = _56file0_43544;
        concat_list[2] = 92;
        concat_list[3] = _23713;
        Concat_N((object_ptr)&_23714, concat_list, 4);
    }
    DeRef(_23713);
    _23713 = NOVALUE;
    _2 = (int)SEQ_PTR(_54exe_name_44364);
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _23714;
    if( _1 != _23714 ){
        DeRef(_1);
    }
    _23714 = NOVALUE;

    /** 		exe_name[D_ALTNAME] = adjust_for_command_line_passing(exe_name[D_NAME])*/
    _2 = (int)SEQ_PTR(_54exe_name_44364);
    _23715 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_23715);
    _23716 = _54adjust_for_command_line_passing(_23715);
    _23715 = NOVALUE;
    _2 = (int)SEQ_PTR(_54exe_name_44364);
    _2 = (int)(((s1_ptr)_2)->base + 11);
    _1 = *(int *)_2;
    *(int *)_2 = _23716;
    if( _1 != _23716 ){
        DeRef(_1);
    }
    _23716 = NOVALUE;
L1: 

    /** end procedure*/
    DeRefDS(_ext_44749);
    _23710 = NOVALUE;
    return;
    ;
}


void _54write_objlink_file()
{
    int _settings_44767 = NOVALUE;
    int _fh_44769 = NOVALUE;
    int _s_44817 = NOVALUE;
    int _23765 = NOVALUE;
    int _23763 = NOVALUE;
    int _23762 = NOVALUE;
    int _23761 = NOVALUE;
    int _23760 = NOVALUE;
    int _23759 = NOVALUE;
    int _23758 = NOVALUE;
    int _23757 = NOVALUE;
    int _23756 = NOVALUE;
    int _23755 = NOVALUE;
    int _23754 = NOVALUE;
    int _23753 = NOVALUE;
    int _23752 = NOVALUE;
    int _23750 = NOVALUE;
    int _23749 = NOVALUE;
    int _23748 = NOVALUE;
    int _23747 = NOVALUE;
    int _23745 = NOVALUE;
    int _23744 = NOVALUE;
    int _23743 = NOVALUE;
    int _23742 = NOVALUE;
    int _23741 = NOVALUE;
    int _23740 = NOVALUE;
    int _23734 = NOVALUE;
    int _23733 = NOVALUE;
    int _23730 = NOVALUE;
    int _23729 = NOVALUE;
    int _23728 = NOVALUE;
    int _23727 = NOVALUE;
    int _23726 = NOVALUE;
    int _23724 = NOVALUE;
    int _23723 = NOVALUE;
    int _23722 = NOVALUE;
    int _23719 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence settings = setup_build()*/
    _0 = _settings_44767;
    _settings_44767 = _54setup_build();
    DeRef(_0);

    /** 	integer fh = open(output_dir & file0 & ".lnk", "wb")*/
    {
        int concat_list[3];

        concat_list[0] = _23718;
        concat_list[1] = _56file0_43544;
        concat_list[2] = _56output_dir_41729;
        Concat_N((object_ptr)&_23719, concat_list, 3);
    }
    _fh_44769 = EOpen(_23719, _23720, 0);
    DeRefDS(_23719);
    _23719 = NOVALUE;

    /** 	ensure_exename(settings[SETUP_EXE_EXT])*/
    _2 = (int)SEQ_PTR(_settings_44767);
    _23722 = (int)*(((s1_ptr)_2)->base + 6);
    Ref(_23722);
    _54ensure_exename(_23722);
    _23722 = NOVALUE;

    /** 	if length(settings[SETUP_LFLAGS_BEGIN]) > 0 then*/
    _2 = (int)SEQ_PTR(_settings_44767);
    _23723 = (int)*(((s1_ptr)_2)->base + 7);
    if (IS_SEQUENCE(_23723)){
            _23724 = SEQ_PTR(_23723)->length;
    }
    else {
        _23724 = 1;
    }
    _23723 = NOVALUE;
    if (_23724 <= 0)
    goto L1; // [43] 63

    /** 		puts(fh, settings[SETUP_LFLAGS_BEGIN] & HOSTNL)*/
    _2 = (int)SEQ_PTR(_settings_44767);
    _23726 = (int)*(((s1_ptr)_2)->base + 7);
    if (IS_SEQUENCE(_23726) && IS_ATOM(_36HOSTNL_14320)) {
    }
    else if (IS_ATOM(_23726) && IS_SEQUENCE(_36HOSTNL_14320)) {
        Ref(_23726);
        Prepend(&_23727, _36HOSTNL_14320, _23726);
    }
    else {
        Concat((object_ptr)&_23727, _23726, _36HOSTNL_14320);
        _23726 = NOVALUE;
    }
    _23726 = NOVALUE;
    EPuts(_fh_44769, _23727); // DJP 
    DeRefDS(_23727);
    _23727 = NOVALUE;
L1: 

    /** 	for i = 1 to length(generated_files) do*/
    if (IS_SEQUENCE(_56generated_files_41720)){
            _23728 = SEQ_PTR(_56generated_files_41720)->length;
    }
    else {
        _23728 = 1;
    }
    {
        int _i_44785;
        _i_44785 = 1;
L2: 
        if (_i_44785 > _23728){
            goto L3; // [70] 132
        }

        /** 		if match(".o", generated_files[i]) then*/
        _2 = (int)SEQ_PTR(_56generated_files_41720);
        _23729 = (int)*(((s1_ptr)_2)->base + _i_44785);
        _23730 = e_match_from(_23072, _23729, 1);
        _23729 = NOVALUE;
        if (_23730 == 0)
        {
            _23730 = NOVALUE;
            goto L4; // [90] 125
        }
        else{
            _23730 = NOVALUE;
        }

        /** 			if compiler_type = COMPILER_WATCOM then*/

        /** 			puts(fh, generated_files[i] & HOSTNL)*/
        _2 = (int)SEQ_PTR(_56generated_files_41720);
        _23733 = (int)*(((s1_ptr)_2)->base + _i_44785);
        Concat((object_ptr)&_23734, _23733, _36HOSTNL_14320);
        _23733 = NOVALUE;
        _23733 = NOVALUE;
        EPuts(_fh_44769, _23734); // DJP 
        DeRefDS(_23734);
        _23734 = NOVALUE;
L4: 

        /** 	end for*/
        _i_44785 = _i_44785 + 1;
        goto L2; // [127] 77
L3: 
        ;
    }

    /** 	if compiler_type = COMPILER_WATCOM then*/

    /** 	puts(fh, trim(settings[SETUP_LFLAGS] & HOSTNL))*/
    _2 = (int)SEQ_PTR(_settings_44767);
    _23740 = (int)*(((s1_ptr)_2)->base + 4);
    if (IS_SEQUENCE(_23740) && IS_ATOM(_36HOSTNL_14320)) {
    }
    else if (IS_ATOM(_23740) && IS_SEQUENCE(_36HOSTNL_14320)) {
        Ref(_23740);
        Prepend(&_23741, _36HOSTNL_14320, _23740);
    }
    else {
        Concat((object_ptr)&_23741, _23740, _36HOSTNL_14320);
        _23740 = NOVALUE;
    }
    _23740 = NOVALUE;
    RefDS(_4538);
    _23742 = _12trim(_23741, _4538, 0);
    _23741 = NOVALUE;
    EPuts(_fh_44769, _23742); // DJP 
    DeRef(_23742);
    _23742 = NOVALUE;

    /** 	if compiler_type = COMPILER_WATCOM and dll_option then*/
    _23743 = (0 == 2);
    if (_23743 == 0) {
        goto L5; // [194] 361
    }
    if (_56dll_option_41716 == 0)
    {
        goto L5; // [201] 361
    }
    else{
    }

    /** 		puts(fh, HOSTNL)*/
    EPuts(_fh_44769, _36HOSTNL_14320); // DJP 

    /** 		object s = SymTab[TopLevelSub][S_NEXT]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _23745 = (int)*(((s1_ptr)_2)->base + _26TopLevelSub_11989);
    DeRef(_s_44817);
    _2 = (int)SEQ_PTR(_23745);
    _s_44817 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_s_44817);
    _23745 = NOVALUE;

    /** 		while s do*/
L6: 
    if (_s_44817 <= 0) {
        if (_s_44817 == 0) {
            goto L7; // [232] 360
        }
        else {
            if (!IS_ATOM_INT(_s_44817) && DBL_PTR(_s_44817)->dbl == 0.0){
                goto L7; // [232] 360
            }
        }
    }

    /** 			if eu:find(SymTab[s][S_TOKEN], RTN_TOKS) then*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!IS_ATOM_INT(_s_44817)){
        _23747 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_s_44817)->dbl));
    }
    else{
        _23747 = (int)*(((s1_ptr)_2)->base + _s_44817);
    }
    _2 = (int)SEQ_PTR(_23747);
    if (!IS_ATOM_INT(_26S_TOKEN_11659)){
        _23748 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_TOKEN_11659)->dbl));
    }
    else{
        _23748 = (int)*(((s1_ptr)_2)->base + _26S_TOKEN_11659);
    }
    _23747 = NOVALUE;
    _23749 = find_from(_23748, _28RTN_TOKS_11602, 1);
    _23748 = NOVALUE;
    if (_23749 == 0)
    {
        _23749 = NOVALUE;
        goto L8; // [256] 341
    }
    else{
        _23749 = NOVALUE;
    }

    /** 				if is_exported( s ) then*/
    Ref(_s_44817);
    _23750 = _56is_exported(_s_44817);
    if (_23750 == 0) {
        DeRef(_23750);
        _23750 = NOVALUE;
        goto L9; // [265] 340
    }
    else {
        if (!IS_ATOM_INT(_23750) && DBL_PTR(_23750)->dbl == 0.0){
            DeRef(_23750);
            _23750 = NOVALUE;
            goto L9; // [265] 340
        }
        DeRef(_23750);
        _23750 = NOVALUE;
    }
    DeRef(_23750);
    _23750 = NOVALUE;

    /** 					printf(fh, "EXPORT %s='__%d%s@%d'" & HOSTNL,*/
    Concat((object_ptr)&_23752, _23751, _36HOSTNL_14320);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!IS_ATOM_INT(_s_44817)){
        _23753 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_s_44817)->dbl));
    }
    else{
        _23753 = (int)*(((s1_ptr)_2)->base + _s_44817);
    }
    _2 = (int)SEQ_PTR(_23753);
    if (!IS_ATOM_INT(_26S_NAME_11654)){
        _23754 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NAME_11654)->dbl));
    }
    else{
        _23754 = (int)*(((s1_ptr)_2)->base + _26S_NAME_11654);
    }
    _23753 = NOVALUE;
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!IS_ATOM_INT(_s_44817)){
        _23755 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_s_44817)->dbl));
    }
    else{
        _23755 = (int)*(((s1_ptr)_2)->base + _s_44817);
    }
    _2 = (int)SEQ_PTR(_23755);
    if (!IS_ATOM_INT(_26S_FILE_NO_11650)){
        _23756 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_FILE_NO_11650)->dbl));
    }
    else{
        _23756 = (int)*(((s1_ptr)_2)->base + _26S_FILE_NO_11650);
    }
    _23755 = NOVALUE;
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!IS_ATOM_INT(_s_44817)){
        _23757 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_s_44817)->dbl));
    }
    else{
        _23757 = (int)*(((s1_ptr)_2)->base + _s_44817);
    }
    _2 = (int)SEQ_PTR(_23757);
    if (!IS_ATOM_INT(_26S_NAME_11654)){
        _23758 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NAME_11654)->dbl));
    }
    else{
        _23758 = (int)*(((s1_ptr)_2)->base + _26S_NAME_11654);
    }
    _23757 = NOVALUE;
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!IS_ATOM_INT(_s_44817)){
        _23759 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_s_44817)->dbl));
    }
    else{
        _23759 = (int)*(((s1_ptr)_2)->base + _s_44817);
    }
    _2 = (int)SEQ_PTR(_23759);
    if (!IS_ATOM_INT(_26S_NUM_ARGS_11705)){
        _23760 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NUM_ARGS_11705)->dbl));
    }
    else{
        _23760 = (int)*(((s1_ptr)_2)->base + _26S_NUM_ARGS_11705);
    }
    _23759 = NOVALUE;
    if (IS_ATOM_INT(_23760)) {
        if (_23760 == (short)_23760)
        _23761 = _23760 * 4;
        else
        _23761 = NewDouble(_23760 * (double)4);
    }
    else {
        _23761 = binary_op(MULTIPLY, _23760, 4);
    }
    _23760 = NOVALUE;
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_23754);
    *((int *)(_2+4)) = _23754;
    Ref(_23756);
    *((int *)(_2+8)) = _23756;
    Ref(_23758);
    *((int *)(_2+12)) = _23758;
    *((int *)(_2+16)) = _23761;
    _23762 = MAKE_SEQ(_1);
    _23761 = NOVALUE;
    _23758 = NOVALUE;
    _23756 = NOVALUE;
    _23754 = NOVALUE;
    EPrintf(_fh_44769, _23752, _23762);
    DeRefDS(_23752);
    _23752 = NOVALUE;
    DeRefDS(_23762);
    _23762 = NOVALUE;
L9: 
L8: 

    /** 			s = SymTab[s][S_NEXT]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!IS_ATOM_INT(_s_44817)){
        _23763 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_s_44817)->dbl));
    }
    else{
        _23763 = (int)*(((s1_ptr)_2)->base + _s_44817);
    }
    DeRef(_s_44817);
    _2 = (int)SEQ_PTR(_23763);
    _s_44817 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_s_44817);
    _23763 = NOVALUE;

    /** 		end while*/
    goto L6; // [357] 232
L7: 
L5: 
    DeRef(_s_44817);
    _s_44817 = NOVALUE;

    /** 	close(fh)*/
    EClose(_fh_44769);

    /** 	generated_files = append(generated_files, file0 & ".lnk")*/
    Concat((object_ptr)&_23765, _56file0_43544, _23718);
    RefDS(_23765);
    Append(&_56generated_files_41720, _56generated_files_41720, _23765);
    DeRefDS(_23765);
    _23765 = NOVALUE;

    /** end procedure*/
    DeRef(_settings_44767);
    _23723 = NOVALUE;
    DeRef(_23743);
    _23743 = NOVALUE;
    return;
    ;
}


void _54write_makefile_srcobj_list(int _fh_44866)
{
    int _23790 = NOVALUE;
    int _23789 = NOVALUE;
    int _23788 = NOVALUE;
    int _23787 = NOVALUE;
    int _23786 = NOVALUE;
    int _23784 = NOVALUE;
    int _23783 = NOVALUE;
    int _23782 = NOVALUE;
    int _23781 = NOVALUE;
    int _23780 = NOVALUE;
    int _23779 = NOVALUE;
    int _23778 = NOVALUE;
    int _23776 = NOVALUE;
    int _23775 = NOVALUE;
    int _23773 = NOVALUE;
    int _23772 = NOVALUE;
    int _23771 = NOVALUE;
    int _23770 = NOVALUE;
    int _23769 = NOVALUE;
    int _23768 = NOVALUE;
    int _0, _1, _2;
    

    /** 	printf(fh, "%s_SOURCES =", { upper(file0) })*/
    RefDS(_56file0_43544);
    _23768 = _12upper(_56file0_43544);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _23768;
    _23769 = MAKE_SEQ(_1);
    _23768 = NOVALUE;
    EPrintf(_fh_44866, _23767, _23769);
    DeRefDS(_23769);
    _23769 = NOVALUE;

    /** 	for i = 1 to length(generated_files) do*/
    if (IS_SEQUENCE(_56generated_files_41720)){
            _23770 = SEQ_PTR(_56generated_files_41720)->length;
    }
    else {
        _23770 = 1;
    }
    {
        int _i_44873;
        _i_44873 = 1;
L1: 
        if (_i_44873 > _23770){
            goto L2; // [26] 75
        }

        /** 		if generated_files[i][$] = 'c' then*/
        _2 = (int)SEQ_PTR(_56generated_files_41720);
        _23771 = (int)*(((s1_ptr)_2)->base + _i_44873);
        if (IS_SEQUENCE(_23771)){
                _23772 = SEQ_PTR(_23771)->length;
        }
        else {
            _23772 = 1;
        }
        _2 = (int)SEQ_PTR(_23771);
        _23773 = (int)*(((s1_ptr)_2)->base + _23772);
        _23771 = NOVALUE;
        if (binary_op_a(NOTEQ, _23773, 99)){
            _23773 = NOVALUE;
            goto L3; // [48] 68
        }
        _23773 = NOVALUE;

        /** 			puts(fh, " " & generated_files[i])*/
        _2 = (int)SEQ_PTR(_56generated_files_41720);
        _23775 = (int)*(((s1_ptr)_2)->base + _i_44873);
        Concat((object_ptr)&_23776, _23312, _23775);
        _23775 = NOVALUE;
        EPuts(_fh_44866, _23776); // DJP 
        DeRefDS(_23776);
        _23776 = NOVALUE;
L3: 

        /** 	end for*/
        _i_44873 = _i_44873 + 1;
        goto L1; // [70] 33
L2: 
        ;
    }

    /** 	puts(fh, HOSTNL)*/
    EPuts(_fh_44866, _36HOSTNL_14320); // DJP 

    /** 	printf(fh, "%s_OBJECTS =", { upper(file0) })*/
    RefDS(_56file0_43544);
    _23778 = _12upper(_56file0_43544);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _23778;
    _23779 = MAKE_SEQ(_1);
    _23778 = NOVALUE;
    EPrintf(_fh_44866, _23777, _23779);
    DeRefDS(_23779);
    _23779 = NOVALUE;

    /** 	for i = 1 to length(generated_files) do*/
    if (IS_SEQUENCE(_56generated_files_41720)){
            _23780 = SEQ_PTR(_56generated_files_41720)->length;
    }
    else {
        _23780 = 1;
    }
    {
        int _i_44892;
        _i_44892 = 1;
L4: 
        if (_i_44892 > _23780){
            goto L5; // [105] 151
        }

        /** 		if match(".o", generated_files[i]) then*/
        _2 = (int)SEQ_PTR(_56generated_files_41720);
        _23781 = (int)*(((s1_ptr)_2)->base + _i_44892);
        _23782 = e_match_from(_23072, _23781, 1);
        _23781 = NOVALUE;
        if (_23782 == 0)
        {
            _23782 = NOVALUE;
            goto L6; // [125] 144
        }
        else{
            _23782 = NOVALUE;
        }

        /** 			puts(fh, " " & generated_files[i])*/
        _2 = (int)SEQ_PTR(_56generated_files_41720);
        _23783 = (int)*(((s1_ptr)_2)->base + _i_44892);
        Concat((object_ptr)&_23784, _23312, _23783);
        _23783 = NOVALUE;
        EPuts(_fh_44866, _23784); // DJP 
        DeRefDS(_23784);
        _23784 = NOVALUE;
L6: 

        /** 	end for*/
        _i_44892 = _i_44892 + 1;
        goto L4; // [146] 112
L5: 
        ;
    }

    /** 	puts(fh, HOSTNL)*/
    EPuts(_fh_44866, _36HOSTNL_14320); // DJP 

    /** 	printf(fh, "%s_GENERATED_FILES = ", { upper(file0) })*/
    RefDS(_56file0_43544);
    _23786 = _12upper(_56file0_43544);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _23786;
    _23787 = MAKE_SEQ(_1);
    _23786 = NOVALUE;
    EPrintf(_fh_44866, _23785, _23787);
    DeRefDS(_23787);
    _23787 = NOVALUE;

    /** 	for i = 1 to length(generated_files) do*/
    if (IS_SEQUENCE(_56generated_files_41720)){
            _23788 = SEQ_PTR(_56generated_files_41720)->length;
    }
    else {
        _23788 = 1;
    }
    {
        int _i_44909;
        _i_44909 = 1;
L7: 
        if (_i_44909 > _23788){
            goto L8; // [181] 210
        }

        /** 		puts(fh, " " & generated_files[i])*/
        _2 = (int)SEQ_PTR(_56generated_files_41720);
        _23789 = (int)*(((s1_ptr)_2)->base + _i_44909);
        Concat((object_ptr)&_23790, _23312, _23789);
        _23789 = NOVALUE;
        EPuts(_fh_44866, _23790); // DJP 
        DeRefDS(_23790);
        _23790 = NOVALUE;

        /** 	end for*/
        _i_44909 = _i_44909 + 1;
        goto L7; // [205] 188
L8: 
        ;
    }

    /** 	puts(fh, HOSTNL)*/
    EPuts(_fh_44866, _36HOSTNL_14320); // DJP 

    /** end procedure*/
    return;
    ;
}


int _54windows_to_mingw_path(int _s_44918)
{
    int _23792 = NOVALUE;
    int _0, _1, _2;
    

    /** 	ifdef TEST_FOR_WIN9X_ON_MING then*/

    /** 	return search:find_replace('\\',s,'/')*/
    RefDS(_s_44918);
    _23792 = _14find_replace(92, _s_44918, 47, 0);
    DeRefDS(_s_44918);
    return _23792;
    ;
}


void _54write_makefile_full()
{
    int _settings_44923 = NOVALUE;
    int _fh_44926 = NOVALUE;
    int _23916 = NOVALUE;
    int _23914 = NOVALUE;
    int _23912 = NOVALUE;
    int _23911 = NOVALUE;
    int _23910 = NOVALUE;
    int _23909 = NOVALUE;
    int _23908 = NOVALUE;
    int _23906 = NOVALUE;
    int _23905 = NOVALUE;
    int _23903 = NOVALUE;
    int _23902 = NOVALUE;
    int _23901 = NOVALUE;
    int _23900 = NOVALUE;
    int _23898 = NOVALUE;
    int _23897 = NOVALUE;
    int _23895 = NOVALUE;
    int _23894 = NOVALUE;
    int _23892 = NOVALUE;
    int _23891 = NOVALUE;
    int _23890 = NOVALUE;
    int _23889 = NOVALUE;
    int _23888 = NOVALUE;
    int _23887 = NOVALUE;
    int _23886 = NOVALUE;
    int _23885 = NOVALUE;
    int _23883 = NOVALUE;
    int _23882 = NOVALUE;
    int _23881 = NOVALUE;
    int _23880 = NOVALUE;
    int _23879 = NOVALUE;
    int _23878 = NOVALUE;
    int _23877 = NOVALUE;
    int _23876 = NOVALUE;
    int _23875 = NOVALUE;
    int _23874 = NOVALUE;
    int _23873 = NOVALUE;
    int _23872 = NOVALUE;
    int _23871 = NOVALUE;
    int _23809 = NOVALUE;
    int _23808 = NOVALUE;
    int _23807 = NOVALUE;
    int _23805 = NOVALUE;
    int _23804 = NOVALUE;
    int _23803 = NOVALUE;
    int _23801 = NOVALUE;
    int _23800 = NOVALUE;
    int _23799 = NOVALUE;
    int _23796 = NOVALUE;
    int _23794 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence settings = setup_build()*/
    _0 = _settings_44923;
    _settings_44923 = _54setup_build();
    DeRef(_0);

    /** 	ensure_exename(settings[SETUP_EXE_EXT])*/
    _2 = (int)SEQ_PTR(_settings_44923);
    _23794 = (int)*(((s1_ptr)_2)->base + 6);
    Ref(_23794);
    _54ensure_exename(_23794);
    _23794 = NOVALUE;

    /** 	integer fh = open(output_dir & file0 & ".mak", "wb")*/
    {
        int concat_list[3];

        concat_list[0] = _23795;
        concat_list[1] = _56file0_43544;
        concat_list[2] = _56output_dir_41729;
        Concat_N((object_ptr)&_23796, concat_list, 3);
    }
    _fh_44926 = EOpen(_23796, _23720, 0);
    DeRefDS(_23796);
    _23796 = NOVALUE;

    /** 	printf(fh, "CC     = %s" & HOSTNL, { settings[SETUP_CEXE] })*/
    Concat((object_ptr)&_23799, _23798, _36HOSTNL_14320);
    _2 = (int)SEQ_PTR(_settings_44923);
    _23800 = (int)*(((s1_ptr)_2)->base + 1);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_23800);
    *((int *)(_2+4)) = _23800;
    _23801 = MAKE_SEQ(_1);
    _23800 = NOVALUE;
    EPrintf(_fh_44926, _23799, _23801);
    DeRefDS(_23799);
    _23799 = NOVALUE;
    DeRefDS(_23801);
    _23801 = NOVALUE;

    /** 	printf(fh, "CFLAGS = %s" & HOSTNL, { settings[SETUP_CFLAGS] })*/
    Concat((object_ptr)&_23803, _23802, _36HOSTNL_14320);
    _2 = (int)SEQ_PTR(_settings_44923);
    _23804 = (int)*(((s1_ptr)_2)->base + 2);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_23804);
    *((int *)(_2+4)) = _23804;
    _23805 = MAKE_SEQ(_1);
    _23804 = NOVALUE;
    EPrintf(_fh_44926, _23803, _23805);
    DeRefDS(_23803);
    _23803 = NOVALUE;
    DeRefDS(_23805);
    _23805 = NOVALUE;

    /** 	printf(fh, "LINKER = %s" & HOSTNL, { settings[SETUP_LEXE] })*/
    Concat((object_ptr)&_23807, _23806, _36HOSTNL_14320);
    _2 = (int)SEQ_PTR(_settings_44923);
    _23808 = (int)*(((s1_ptr)_2)->base + 3);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_23808);
    *((int *)(_2+4)) = _23808;
    _23809 = MAKE_SEQ(_1);
    _23808 = NOVALUE;
    EPrintf(_fh_44926, _23807, _23809);
    DeRefDS(_23807);
    _23807 = NOVALUE;
    DeRefDS(_23809);
    _23809 = NOVALUE;

    /** 	if compiler_type = COMPILER_GCC then*/

    /** 		write_objlink_file()*/
    _54write_objlink_file();

    /** 	write_makefile_srcobj_list(fh)*/
    _54write_makefile_srcobj_list(_fh_44926);

    /** 	puts(fh, HOSTNL)*/
    EPuts(_fh_44926, _36HOSTNL_14320); // DJP 

    /** 	if compiler_type = COMPILER_WATCOM then*/

    /** 		printf(fh, "%s: $(%s_OBJECTS) %s %s" & HOSTNL, { adjust_for_build_file(exe_name[D_ALTNAME]), upper(file0), user_library, rc_file[D_ALTNAME] })*/
    Concat((object_ptr)&_23871, _23870, _36HOSTNL_14320);
    _2 = (int)SEQ_PTR(_54exe_name_44364);
    _23872 = (int)*(((s1_ptr)_2)->base + 11);
    Ref(_23872);
    _23873 = _54adjust_for_build_file(_23872);
    _23872 = NOVALUE;
    RefDS(_56file0_43544);
    _23874 = _12upper(_56file0_43544);
    _2 = (int)SEQ_PTR(_54rc_file_44370);
    _23875 = (int)*(((s1_ptr)_2)->base + 11);
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _23873;
    *((int *)(_2+8)) = _23874;
    RefDS(_56user_library_41728);
    *((int *)(_2+12)) = _56user_library_41728;
    RefDS(_23875);
    *((int *)(_2+16)) = _23875;
    _23876 = MAKE_SEQ(_1);
    _23875 = NOVALUE;
    _23874 = NOVALUE;
    _23873 = NOVALUE;
    EPrintf(_fh_44926, _23871, _23876);
    DeRefDS(_23871);
    _23871 = NOVALUE;
    DeRefDS(_23876);
    _23876 = NOVALUE;

    /** 		if length(rc_file[D_ALTNAME]) then*/
    _2 = (int)SEQ_PTR(_54rc_file_44370);
    _23877 = (int)*(((s1_ptr)_2)->base + 11);
    if (IS_SEQUENCE(_23877)){
            _23878 = SEQ_PTR(_23877)->length;
    }
    else {
        _23878 = 1;
    }
    _23877 = NOVALUE;
    if (_23878 == 0)
    {
        _23878 = NOVALUE;
        goto L1; // [635] 679
    }
    else{
        _23878 = NOVALUE;
    }

    /** 			writef(fh, "\t" & settings[SETUP_RC_COMPILER] & HOSTNL, { rc_file[D_ALTNAME], res_file[D_ALTNAME] })*/
    _2 = (int)SEQ_PTR(_settings_44923);
    _23879 = (int)*(((s1_ptr)_2)->base + 8);
    {
        int concat_list[3];

        concat_list[0] = _36HOSTNL_14320;
        concat_list[1] = _23879;
        concat_list[2] = _23829;
        Concat_N((object_ptr)&_23880, concat_list, 3);
    }
    _23879 = NOVALUE;
    _2 = (int)SEQ_PTR(_54rc_file_44370);
    _23881 = (int)*(((s1_ptr)_2)->base + 11);
    _2 = (int)SEQ_PTR(_54res_file_44376);
    _23882 = (int)*(((s1_ptr)_2)->base + 11);
    RefDS(_23882);
    RefDS(_23881);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _23881;
    ((int *)_2)[2] = _23882;
    _23883 = MAKE_SEQ(_1);
    _23882 = NOVALUE;
    _23881 = NOVALUE;
    _18writef(_fh_44926, _23880, _23883, 0);
    _23880 = NOVALUE;
    _23883 = NOVALUE;
L1: 

    /** 		printf(fh, "\t$(LINKER) -o %s $(%s_OBJECTS) %s $(LFLAGS)" & HOSTNL, {*/
    Concat((object_ptr)&_23885, _23884, _36HOSTNL_14320);
    _2 = (int)SEQ_PTR(_54exe_name_44364);
    _23886 = (int)*(((s1_ptr)_2)->base + 11);
    RefDS(_56file0_43544);
    _23887 = _12upper(_56file0_43544);
    _2 = (int)SEQ_PTR(_54res_file_44376);
    _23888 = (int)*(((s1_ptr)_2)->base + 11);
    if (IS_SEQUENCE(_23888)){
            _23889 = SEQ_PTR(_23888)->length;
    }
    else {
        _23889 = 1;
    }
    _23888 = NOVALUE;
    _2 = (int)SEQ_PTR(_54res_file_44376);
    _23890 = (int)*(((s1_ptr)_2)->base + 11);
    RefDS(_23890);
    RefDS(_22037);
    _23891 = _55iif(_23889, _23890, _22037);
    _23889 = NOVALUE;
    _23890 = NOVALUE;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_23886);
    *((int *)(_2+4)) = _23886;
    *((int *)(_2+8)) = _23887;
    *((int *)(_2+12)) = _23891;
    _23892 = MAKE_SEQ(_1);
    _23891 = NOVALUE;
    _23887 = NOVALUE;
    _23886 = NOVALUE;
    EPrintf(_fh_44926, _23885, _23892);
    DeRefDS(_23885);
    _23885 = NOVALUE;
    DeRefDS(_23892);
    _23892 = NOVALUE;

    /** 		puts(fh, HOSTNL)*/
    EPuts(_fh_44926, _36HOSTNL_14320); // DJP 

    /** 		printf(fh, ".PHONY: %s-clean %s-clean-all" & HOSTNL, { file0, file0 })*/
    Concat((object_ptr)&_23894, _23893, _36HOSTNL_14320);
    RefDS(_56file0_43544);
    RefDS(_56file0_43544);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _56file0_43544;
    ((int *)_2)[2] = _56file0_43544;
    _23895 = MAKE_SEQ(_1);
    EPrintf(_fh_44926, _23894, _23895);
    DeRefDS(_23894);
    _23894 = NOVALUE;
    DeRefDS(_23895);
    _23895 = NOVALUE;

    /** 		puts(fh, HOSTNL)*/
    EPuts(_fh_44926, _36HOSTNL_14320); // DJP 

    /** 		printf(fh, "%s-clean:" & HOSTNL, { file0 })*/
    Concat((object_ptr)&_23897, _23896, _36HOSTNL_14320);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_56file0_43544);
    *((int *)(_2+4)) = _56file0_43544;
    _23898 = MAKE_SEQ(_1);
    EPrintf(_fh_44926, _23897, _23898);
    DeRefDS(_23897);
    _23897 = NOVALUE;
    DeRefDS(_23898);
    _23898 = NOVALUE;

    /** 		printf(fh, "\trm -rf $(%s_OBJECTS) %s" & HOSTNL, { upper(file0), res_file[D_ALTNAME] })*/
    Concat((object_ptr)&_23900, _23899, _36HOSTNL_14320);
    RefDS(_56file0_43544);
    _23901 = _12upper(_56file0_43544);
    _2 = (int)SEQ_PTR(_54res_file_44376);
    _23902 = (int)*(((s1_ptr)_2)->base + 11);
    RefDS(_23902);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _23901;
    ((int *)_2)[2] = _23902;
    _23903 = MAKE_SEQ(_1);
    _23902 = NOVALUE;
    _23901 = NOVALUE;
    EPrintf(_fh_44926, _23900, _23903);
    DeRefDS(_23900);
    _23900 = NOVALUE;
    DeRefDS(_23903);
    _23903 = NOVALUE;

    /** 		puts(fh, HOSTNL)*/
    EPuts(_fh_44926, _36HOSTNL_14320); // DJP 

    /** 		printf(fh, "%s-clean-all: %s-clean" & HOSTNL, { file0, file0 })*/
    Concat((object_ptr)&_23905, _23904, _36HOSTNL_14320);
    RefDS(_56file0_43544);
    RefDS(_56file0_43544);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _56file0_43544;
    ((int *)_2)[2] = _56file0_43544;
    _23906 = MAKE_SEQ(_1);
    EPrintf(_fh_44926, _23905, _23906);
    DeRefDS(_23905);
    _23905 = NOVALUE;
    DeRefDS(_23906);
    _23906 = NOVALUE;

    /** 		printf(fh, "\trm -rf $(%s_SOURCES) %s %s" & HOSTNL, { upper(file0), res_file[D_ALTNAME], exe_name[D_ALTNAME] })*/
    Concat((object_ptr)&_23908, _23907, _36HOSTNL_14320);
    RefDS(_56file0_43544);
    _23909 = _12upper(_56file0_43544);
    _2 = (int)SEQ_PTR(_54res_file_44376);
    _23910 = (int)*(((s1_ptr)_2)->base + 11);
    _2 = (int)SEQ_PTR(_54exe_name_44364);
    _23911 = (int)*(((s1_ptr)_2)->base + 11);
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _23909;
    RefDS(_23910);
    *((int *)(_2+8)) = _23910;
    Ref(_23911);
    *((int *)(_2+12)) = _23911;
    _23912 = MAKE_SEQ(_1);
    _23911 = NOVALUE;
    _23910 = NOVALUE;
    _23909 = NOVALUE;
    EPrintf(_fh_44926, _23908, _23912);
    DeRefDS(_23908);
    _23908 = NOVALUE;
    DeRefDS(_23912);
    _23912 = NOVALUE;

    /** 		puts(fh, HOSTNL)*/
    EPuts(_fh_44926, _36HOSTNL_14320); // DJP 

    /** 		puts(fh, "%.o: %.c" & HOSTNL)*/
    Concat((object_ptr)&_23914, _23913, _36HOSTNL_14320);
    EPuts(_fh_44926, _23914); // DJP 
    DeRefDS(_23914);
    _23914 = NOVALUE;

    /** 		puts(fh, "\t$(CC) $(CFLAGS) $*.c -o $*.o" & HOSTNL)*/
    Concat((object_ptr)&_23916, _23915, _36HOSTNL_14320);
    EPuts(_fh_44926, _23916); // DJP 
    DeRefDS(_23916);
    _23916 = NOVALUE;

    /** 		puts(fh, HOSTNL)*/
    EPuts(_fh_44926, _36HOSTNL_14320); // DJP 

    /** 	close(fh)*/
    EClose(_fh_44926);

    /** end procedure*/
    DeRef(_settings_44923);
    _23877 = NOVALUE;
    _23888 = NOVALUE;
    return;
    ;
}


void _54write_makefile_partial()
{
    int _settings_45150 = NOVALUE;
    int _fh_45152 = NOVALUE;
    int _23918 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence settings = setup_build()*/
    _0 = _settings_45150;
    _settings_45150 = _54setup_build();
    DeRef(_0);

    /** 	integer fh = open(output_dir & file0 & ".mak", "wb")*/
    {
        int concat_list[3];

        concat_list[0] = _23795;
        concat_list[1] = _56file0_43544;
        concat_list[2] = _56output_dir_41729;
        Concat_N((object_ptr)&_23918, concat_list, 3);
    }
    _fh_45152 = EOpen(_23918, _23720, 0);
    DeRefDS(_23918);
    _23918 = NOVALUE;

    /** 	write_makefile_srcobj_list(fh)*/
    _54write_makefile_srcobj_list(_fh_45152);

    /** 	close(fh)*/
    EClose(_fh_45152);

    /** end procedure*/
    DeRefDS(_settings_45150);
    return;
    ;
}


void _54build_direct(int _link_only_45159, int _the_file0_45160)
{
    int _cmd_45166 = NOVALUE;
    int _objs_45167 = NOVALUE;
    int _settings_45168 = NOVALUE;
    int _cwd_45170 = NOVALUE;
    int _status_45173 = NOVALUE;
    int _link_files_45202 = NOVALUE;
    int _pdone_45228 = NOVALUE;
    int _files_45274 = NOVALUE;
    int _31673 = NOVALUE;
    int _31672 = NOVALUE;
    int _31671 = NOVALUE;
    int _31670 = NOVALUE;
    int _31669 = NOVALUE;
    int _31667 = NOVALUE;
    int _24062 = NOVALUE;
    int _24061 = NOVALUE;
    int _24060 = NOVALUE;
    int _24059 = NOVALUE;
    int _24058 = NOVALUE;
    int _24057 = NOVALUE;
    int _24056 = NOVALUE;
    int _24054 = NOVALUE;
    int _24053 = NOVALUE;
    int _24052 = NOVALUE;
    int _24051 = NOVALUE;
    int _24047 = NOVALUE;
    int _24046 = NOVALUE;
    int _24045 = NOVALUE;
    int _24044 = NOVALUE;
    int _24043 = NOVALUE;
    int _24042 = NOVALUE;
    int _24041 = NOVALUE;
    int _24040 = NOVALUE;
    int _24039 = NOVALUE;
    int _24038 = NOVALUE;
    int _24037 = NOVALUE;
    int _24036 = NOVALUE;
    int _24035 = NOVALUE;
    int _24034 = NOVALUE;
    int _24033 = NOVALUE;
    int _24030 = NOVALUE;
    int _24029 = NOVALUE;
    int _24028 = NOVALUE;
    int _24027 = NOVALUE;
    int _24024 = NOVALUE;
    int _24022 = NOVALUE;
    int _24021 = NOVALUE;
    int _24020 = NOVALUE;
    int _24019 = NOVALUE;
    int _24018 = NOVALUE;
    int _24017 = NOVALUE;
    int _24014 = NOVALUE;
    int _24013 = NOVALUE;
    int _24009 = NOVALUE;
    int _24008 = NOVALUE;
    int _24007 = NOVALUE;
    int _24003 = NOVALUE;
    int _24002 = NOVALUE;
    int _24001 = NOVALUE;
    int _24000 = NOVALUE;
    int _23999 = NOVALUE;
    int _23998 = NOVALUE;
    int _23997 = NOVALUE;
    int _23996 = NOVALUE;
    int _23995 = NOVALUE;
    int _23994 = NOVALUE;
    int _23993 = NOVALUE;
    int _23992 = NOVALUE;
    int _23990 = NOVALUE;
    int _23989 = NOVALUE;
    int _23988 = NOVALUE;
    int _23987 = NOVALUE;
    int _23986 = NOVALUE;
    int _23984 = NOVALUE;
    int _23983 = NOVALUE;
    int _23982 = NOVALUE;
    int _23981 = NOVALUE;
    int _23980 = NOVALUE;
    int _23978 = NOVALUE;
    int _23976 = NOVALUE;
    int _23975 = NOVALUE;
    int _23974 = NOVALUE;
    int _23973 = NOVALUE;
    int _23971 = NOVALUE;
    int _23970 = NOVALUE;
    int _23969 = NOVALUE;
    int _23966 = NOVALUE;
    int _23965 = NOVALUE;
    int _23964 = NOVALUE;
    int _23963 = NOVALUE;
    int _23962 = NOVALUE;
    int _23961 = NOVALUE;
    int _23960 = NOVALUE;
    int _23959 = NOVALUE;
    int _23958 = NOVALUE;
    int _23957 = NOVALUE;
    int _23954 = NOVALUE;
    int _23953 = NOVALUE;
    int _23950 = NOVALUE;
    int _23948 = NOVALUE;
    int _23947 = NOVALUE;
    int _23946 = NOVALUE;
    int _23945 = NOVALUE;
    int _23942 = NOVALUE;
    int _23941 = NOVALUE;
    int _23940 = NOVALUE;
    int _23939 = NOVALUE;
    int _23937 = NOVALUE;
    int _23936 = NOVALUE;
    int _23935 = NOVALUE;
    int _23934 = NOVALUE;
    int _23933 = NOVALUE;
    int _23930 = NOVALUE;
    int _23924 = NOVALUE;
    int _23920 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_link_only_45159)) {
        _1 = (long)(DBL_PTR(_link_only_45159)->dbl);
        DeRefDS(_link_only_45159);
        _link_only_45159 = _1;
    }

    /** 	if length(the_file0) then*/
    if (IS_SEQUENCE(_the_file0_45160)){
            _23920 = SEQ_PTR(_the_file0_45160)->length;
    }
    else {
        _23920 = 1;
    }
    if (_23920 == 0)
    {
        _23920 = NOVALUE;
        goto L1; // [10] 22
    }
    else{
        _23920 = NOVALUE;
    }

    /** 		file0 = filebase(the_file0)*/
    RefDS(_the_file0_45160);
    _0 = _15filebase(_the_file0_45160);
    DeRef(_56file0_43544);
    _56file0_43544 = _0;
L1: 

    /** 	sequence cmd, objs = "", settings = setup_build(), cwd = current_dir()*/
    RefDS(_22037);
    DeRef(_objs_45167);
    _objs_45167 = _22037;
    _0 = _settings_45168;
    _settings_45168 = _54setup_build();
    DeRef(_0);
    _0 = _cwd_45170;
    _cwd_45170 = _15current_dir();
    DeRef(_0);

    /** 	integer status*/

    /** 	ensure_exename(settings[SETUP_EXE_EXT])*/
    _2 = (int)SEQ_PTR(_settings_45168);
    _23924 = (int)*(((s1_ptr)_2)->base + 6);
    Ref(_23924);
    _54ensure_exename(_23924);
    _23924 = NOVALUE;

    /** 	if not link_only then*/
    if (_link_only_45159 != 0)
    goto L2; // [52] 120

    /** 		switch compiler_type do*/
    _0 = 0;
    switch ( _0 ){ 

        /** 			case COMPILER_GCC then*/
        case 1:

        /** 				if not silent then*/
        if (_26silent_12098 != 0)
        goto L3; // [72] 119

        /** 					ShowMsg(1, 176, {"GCC"})*/
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        RefDS(_23929);
        *((int *)(_2+4)) = _23929;
        _23930 = MAKE_SEQ(_1);
        _44ShowMsg(1, 176, _23930, 1);
        _23930 = NOVALUE;
        goto L3; // [88] 119

        /** 			case COMPILER_WATCOM then*/
        case 2:

        /** 				write_objlink_file()*/
        _54write_objlink_file();

        /** 				if not silent then*/
        if (_26silent_12098 != 0)
        goto L4; // [102] 118

        /** 					ShowMsg(1, 176, {"Watcom"})*/
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        RefDS(_23932);
        *((int *)(_2+4)) = _23932;
        _23933 = MAKE_SEQ(_1);
        _44ShowMsg(1, 176, _23933, 1);
        _23933 = NOVALUE;
L4: 
    ;}L3: 
L2: 

    /** 	if sequence(output_dir) and length(output_dir) > 0 then*/
    _23934 = 1;
    if (_23934 == 0) {
        goto L5; // [127] 155
    }
    _23936 = 0;
    _23937 = (0 > 0);
    _23936 = NOVALUE;
    if (_23937 == 0)
    {
        DeRef(_23937);
        _23937 = NOVALUE;
        goto L5; // [141] 155
    }
    else{
        DeRef(_23937);
        _23937 = NOVALUE;
    }

    /** 		chdir(output_dir)*/
    RefDS(_56output_dir_41729);
    _31673 = _15chdir(_56output_dir_41729);
    DeRef(_31673);
    _31673 = NOVALUE;
L5: 

    /** 	sequence link_files = {}*/
    RefDS(_22037);
    DeRef(_link_files_45202);
    _link_files_45202 = _22037;

    /** 	if not link_only then*/
    if (_link_only_45159 != 0)
    goto L6; // [164] 468

    /** 		for i = 1 to length(generated_files) do*/
    if (IS_SEQUENCE(_56generated_files_41720)){
            _23939 = SEQ_PTR(_56generated_files_41720)->length;
    }
    else {
        _23939 = 1;
    }
    {
        int _i_45206;
        _i_45206 = 1;
L7: 
        if (_i_45206 > _23939){
            goto L8; // [174] 465
        }

        /** 			if generated_files[i][$] = 'c' then*/
        _2 = (int)SEQ_PTR(_56generated_files_41720);
        _23940 = (int)*(((s1_ptr)_2)->base + _i_45206);
        if (IS_SEQUENCE(_23940)){
                _23941 = SEQ_PTR(_23940)->length;
        }
        else {
            _23941 = 1;
        }
        _2 = (int)SEQ_PTR(_23940);
        _23942 = (int)*(((s1_ptr)_2)->base + _23941);
        _23940 = NOVALUE;
        if (binary_op_a(NOTEQ, _23942, 99)){
            _23942 = NOVALUE;
            goto L9; // [196] 424
        }
        _23942 = NOVALUE;

        /** 				cmd = sprintf("%s %s %s", { settings[SETUP_CEXE], settings[SETUP_CFLAGS],*/
        _2 = (int)SEQ_PTR(_settings_45168);
        _23945 = (int)*(((s1_ptr)_2)->base + 1);
        _2 = (int)SEQ_PTR(_settings_45168);
        _23946 = (int)*(((s1_ptr)_2)->base + 2);
        _2 = (int)SEQ_PTR(_56generated_files_41720);
        _23947 = (int)*(((s1_ptr)_2)->base + _i_45206);
        _1 = NewS1(3);
        _2 = (int)((s1_ptr)_1)->base;
        Ref(_23945);
        *((int *)(_2+4)) = _23945;
        Ref(_23946);
        *((int *)(_2+8)) = _23946;
        RefDS(_23947);
        *((int *)(_2+12)) = _23947;
        _23948 = MAKE_SEQ(_1);
        _23947 = NOVALUE;
        _23946 = NOVALUE;
        _23945 = NOVALUE;
        DeRef(_cmd_45166);
        _cmd_45166 = EPrintf(-9999999, _23944, _23948);
        DeRefDS(_23948);
        _23948 = NOVALUE;

        /** 				link_files = append(link_files, generated_files[i])*/
        _2 = (int)SEQ_PTR(_56generated_files_41720);
        _23950 = (int)*(((s1_ptr)_2)->base + _i_45206);
        RefDS(_23950);
        Append(&_link_files_45202, _link_files_45202, _23950);
        _23950 = NOVALUE;

        /** 				if not silent then*/
        if (_26silent_12098 != 0)
        goto LA; // [242] 364

        /** 					atom pdone = 100 * (i / length(generated_files))*/
        if (IS_SEQUENCE(_56generated_files_41720)){
                _23953 = SEQ_PTR(_56generated_files_41720)->length;
        }
        else {
            _23953 = 1;
        }
        _23954 = (_i_45206 % _23953) ? NewDouble((double)_i_45206 / _23953) : (_i_45206 / _23953);
        _23953 = NOVALUE;
        DeRef(_pdone_45228);
        if (IS_ATOM_INT(_23954)) {
            if (_23954 <= INT15 && _23954 >= -INT15)
            _pdone_45228 = 100 * _23954;
            else
            _pdone_45228 = NewDouble(100 * (double)_23954);
        }
        else {
            _pdone_45228 = NewDouble((double)100 * DBL_PTR(_23954)->dbl);
        }
        DeRef(_23954);
        _23954 = NOVALUE;

        /** 					if not verbose then*/
        if (_26verbose_12101 != 0)
        goto LB; // [264] 350

        /** 						if 0 and outdated_files[i] = 0 and force_build = 0 then*/
        if (0 == 0) {
            _23957 = 0;
            goto LC; // [269] 287
        }
        _2 = (int)SEQ_PTR(_56outdated_files_41721);
        _23958 = (int)*(((s1_ptr)_2)->base + _i_45206);
        if (IS_ATOM_INT(_23958)) {
            _23959 = (_23958 == 0);
        }
        else {
            _23959 = binary_op(EQUALS, _23958, 0);
        }
        _23958 = NOVALUE;
        if (IS_ATOM_INT(_23959))
        _23957 = (_23959 != 0);
        else
        _23957 = DBL_PTR(_23959)->dbl != 0.0;
LC: 
        if (_23957 == 0) {
            goto LD; // [287] 328
        }
        _23961 = (0 == 0);
        if (_23961 == 0)
        {
            DeRef(_23961);
            _23961 = NOVALUE;
            goto LD; // [298] 328
        }
        else{
            DeRef(_23961);
            _23961 = NOVALUE;
        }

        /** 							ShowMsg(1, 325, { pdone, generated_files[i] })*/
        _2 = (int)SEQ_PTR(_56generated_files_41720);
        _23962 = (int)*(((s1_ptr)_2)->base + _i_45206);
        RefDS(_23962);
        Ref(_pdone_45228);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _pdone_45228;
        ((int *)_2)[2] = _23962;
        _23963 = MAKE_SEQ(_1);
        _23962 = NOVALUE;
        _44ShowMsg(1, 325, _23963, 1);
        _23963 = NOVALUE;

        /** 							continue*/
        DeRef(_pdone_45228);
        _pdone_45228 = NOVALUE;
        goto LE; // [323] 460
        goto LF; // [325] 363
LD: 

        /** 							ShowMsg(1, 163, { pdone, generated_files[i] })*/
        _2 = (int)SEQ_PTR(_56generated_files_41720);
        _23964 = (int)*(((s1_ptr)_2)->base + _i_45206);
        RefDS(_23964);
        Ref(_pdone_45228);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _pdone_45228;
        ((int *)_2)[2] = _23964;
        _23965 = MAKE_SEQ(_1);
        _23964 = NOVALUE;
        _44ShowMsg(1, 163, _23965, 1);
        _23965 = NOVALUE;
        goto LF; // [347] 363
LB: 

        /** 						ShowMsg(1, 163, { pdone, cmd })*/
        RefDS(_cmd_45166);
        Ref(_pdone_45228);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _pdone_45228;
        ((int *)_2)[2] = _cmd_45166;
        _23966 = MAKE_SEQ(_1);
        _44ShowMsg(1, 163, _23966, 1);
        _23966 = NOVALUE;
LF: 
LA: 
        DeRef(_pdone_45228);
        _pdone_45228 = NOVALUE;

        /** 				status = system_exec(cmd, 0)*/
        _status_45173 = system_exec_call(_cmd_45166, 0);

        /** 				if status != 0 then*/
        if (_status_45173 == 0)
        goto L10; // [374] 458

        /** 					ShowMsg(2, 164, { generated_files[i] })*/
        _2 = (int)SEQ_PTR(_56generated_files_41720);
        _23969 = (int)*(((s1_ptr)_2)->base + _i_45206);
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        RefDS(_23969);
        *((int *)(_2+4)) = _23969;
        _23970 = MAKE_SEQ(_1);
        _23969 = NOVALUE;
        _44ShowMsg(2, 164, _23970, 1);
        _23970 = NOVALUE;

        /** 					ShowMsg(2, 165, { status, cmd })*/
        RefDS(_cmd_45166);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _status_45173;
        ((int *)_2)[2] = _cmd_45166;
        _23971 = MAKE_SEQ(_1);
        _44ShowMsg(2, 165, _23971, 1);
        _23971 = NOVALUE;

        /** 					goto "build_direct_cleanup"*/
        goto G11;
        goto L10; // [421] 458
L9: 

        /** 			elsif match(".o", generated_files[i]) then*/
        _2 = (int)SEQ_PTR(_56generated_files_41720);
        _23973 = (int)*(((s1_ptr)_2)->base + _i_45206);
        _23974 = e_match_from(_23072, _23973, 1);
        _23973 = NOVALUE;
        if (_23974 == 0)
        {
            _23974 = NOVALUE;
            goto L12; // [437] 457
        }
        else{
            _23974 = NOVALUE;
        }

        /** 				objs &= " " & generated_files[i]*/
        _2 = (int)SEQ_PTR(_56generated_files_41720);
        _23975 = (int)*(((s1_ptr)_2)->base + _i_45206);
        Concat((object_ptr)&_23976, _23312, _23975);
        _23975 = NOVALUE;
        Concat((object_ptr)&_objs_45167, _objs_45167, _23976);
        DeRefDS(_23976);
        _23976 = NOVALUE;
L12: 
L10: 

        /** 		end for*/
LE: 
        _i_45206 = _i_45206 + 1;
        goto L7; // [460] 181
L8: 
        ;
    }
    goto L13; // [465] 527
L6: 

    /** 		object files = read_lines(file0 & ".bld")*/
    Concat((object_ptr)&_23978, _56file0_43544, _23500);
    _0 = _files_45274;
    _files_45274 = _18read_lines(_23978);
    DeRef(_0);
    _23978 = NOVALUE;

    /** 		for i = 1 to length(files) do*/
    if (IS_SEQUENCE(_files_45274)){
            _23980 = SEQ_PTR(_files_45274)->length;
    }
    else {
        _23980 = 1;
    }
    {
        int _i_45280;
        _i_45280 = 1;
L14: 
        if (_i_45280 > _23980){
            goto L15; // [485] 524
        }

        /** 			objs &= " " & filebase(files[i]) & "." & settings[SETUP_OBJ_EXT]*/
        _2 = (int)SEQ_PTR(_files_45274);
        _23981 = (int)*(((s1_ptr)_2)->base + _i_45280);
        Ref(_23981);
        _23982 = _15filebase(_23981);
        _23981 = NOVALUE;
        _2 = (int)SEQ_PTR(_settings_45168);
        _23983 = (int)*(((s1_ptr)_2)->base + 5);
        {
            int concat_list[4];

            concat_list[0] = _23983;
            concat_list[1] = _23111;
            concat_list[2] = _23982;
            concat_list[3] = _23312;
            Concat_N((object_ptr)&_23984, concat_list, 4);
        }
        _23983 = NOVALUE;
        DeRef(_23982);
        _23982 = NOVALUE;
        Concat((object_ptr)&_objs_45167, _objs_45167, _23984);
        DeRefDS(_23984);
        _23984 = NOVALUE;

        /** 		end for*/
        _i_45280 = _i_45280 + 1;
        goto L14; // [519] 492
L15: 
        ;
    }
    DeRef(_files_45274);
    _files_45274 = NOVALUE;
L13: 

    /** 	if keep and not link_only and length(link_files) then*/
    if (_56keep_41723 == 0) {
        _23986 = 0;
        goto L16; // [531] 542
    }
    _23987 = (_link_only_45159 == 0);
    _23986 = (_23987 != 0);
L16: 
    if (_23986 == 0) {
        goto L17; // [542] 571
    }
    if (IS_SEQUENCE(_link_files_45202)){
            _23989 = SEQ_PTR(_link_files_45202)->length;
    }
    else {
        _23989 = 1;
    }
    if (_23989 == 0)
    {
        _23989 = NOVALUE;
        goto L17; // [550] 571
    }
    else{
        _23989 = NOVALUE;
    }

    /** 		write_lines(file0 & ".bld", link_files)*/
    Concat((object_ptr)&_23990, _56file0_43544, _23500);
    RefDS(_link_files_45202);
    _31672 = _18write_lines(_23990, _link_files_45202);
    _23990 = NOVALUE;
    DeRef(_31672);
    _31672 = NOVALUE;
    goto L18; // [568] 595
L17: 

    /** 	elsif keep = 0 then*/
    if (_56keep_41723 != 0)
    goto L19; // [575] 594

    /** 		delete_file(file0 & ".bld")*/
    Concat((object_ptr)&_23992, _56file0_43544, _23500);
    _31671 = _15delete_file(_23992);
    _23992 = NOVALUE;
    DeRef(_31671);
    _31671 = NOVALUE;
L19: 
L18: 

    /** 	if length(rc_file[D_ALTNAME]) and length(settings[SETUP_RC_COMPILER]) and compiler_type = COMPILER_GCC then*/
    _2 = (int)SEQ_PTR(_54rc_file_44370);
    _23993 = (int)*(((s1_ptr)_2)->base + 11);
    if (IS_SEQUENCE(_23993)){
            _23994 = SEQ_PTR(_23993)->length;
    }
    else {
        _23994 = 1;
    }
    _23993 = NOVALUE;
    if (_23994 == 0) {
        _23995 = 0;
        goto L1A; // [608] 623
    }
    _2 = (int)SEQ_PTR(_settings_45168);
    _23996 = (int)*(((s1_ptr)_2)->base + 8);
    if (IS_SEQUENCE(_23996)){
            _23997 = SEQ_PTR(_23996)->length;
    }
    else {
        _23997 = 1;
    }
    _23996 = NOVALUE;
    _23995 = (_23997 != 0);
L1A: 
    if (_23995 == 0) {
        goto L1B; // [623] 724
    }
    _23999 = (0 == 1);
    if (_23999 == 0)
    {
        DeRef(_23999);
        _23999 = NOVALUE;
        goto L1B; // [634] 724
    }
    else{
        DeRef(_23999);
        _23999 = NOVALUE;
    }

    /** 		cmd = text:format(settings[SETUP_RC_COMPILER], { rc_file[D_ALTNAME], res_file[D_ALTNAME] })*/
    _2 = (int)SEQ_PTR(_settings_45168);
    _24000 = (int)*(((s1_ptr)_2)->base + 8);
    _2 = (int)SEQ_PTR(_54rc_file_44370);
    _24001 = (int)*(((s1_ptr)_2)->base + 11);
    _2 = (int)SEQ_PTR(_54res_file_44376);
    _24002 = (int)*(((s1_ptr)_2)->base + 11);
    RefDS(_24002);
    RefDS(_24001);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _24001;
    ((int *)_2)[2] = _24002;
    _24003 = MAKE_SEQ(_1);
    _24002 = NOVALUE;
    _24001 = NOVALUE;
    Ref(_24000);
    _0 = _cmd_45166;
    _cmd_45166 = _12format(_24000, _24003);
    DeRef(_0);
    _24000 = NOVALUE;
    _24003 = NOVALUE;

    /** 		status = system_exec(cmd, 0)*/
    _status_45173 = system_exec_call(_cmd_45166, 0);

    /** 		if status != 0 then*/
    if (_status_45173 == 0)
    goto L1C; // [678] 723

    /** 			ShowMsg(2, 350, { rc_file[D_NAME] })*/
    _2 = (int)SEQ_PTR(_54rc_file_44370);
    _24007 = (int)*(((s1_ptr)_2)->base + 1);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_24007);
    *((int *)(_2+4)) = _24007;
    _24008 = MAKE_SEQ(_1);
    _24007 = NOVALUE;
    _44ShowMsg(2, 350, _24008, 1);
    _24008 = NOVALUE;

    /** 			ShowMsg(2, 169, { status, cmd })*/
    RefDS(_cmd_45166);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _status_45173;
    ((int *)_2)[2] = _cmd_45166;
    _24009 = MAKE_SEQ(_1);
    _44ShowMsg(2, 169, _24009, 1);
    _24009 = NOVALUE;

    /** 			goto "build_direct_cleanup"*/
    goto G11;
L1C: 
L1B: 

    /** 	switch compiler_type do*/
    _0 = 0;
    switch ( _0 ){ 

        /** 		case COMPILER_WATCOM then*/
        case 2:

        /** 			cmd = sprintf("%s @%s.lnk", { settings[SETUP_LEXE], file0 })*/
        _2 = (int)SEQ_PTR(_settings_45168);
        _24013 = (int)*(((s1_ptr)_2)->base + 3);
        RefDS(_56file0_43544);
        Ref(_24013);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _24013;
        ((int *)_2)[2] = _56file0_43544;
        _24014 = MAKE_SEQ(_1);
        _24013 = NOVALUE;
        DeRef(_cmd_45166);
        _cmd_45166 = EPrintf(-9999999, _24012, _24014);
        DeRefDS(_24014);
        _24014 = NOVALUE;
        goto L1D; // [753] 828

        /** 		case COMPILER_GCC then*/
        case 1:

        /** 			cmd = sprintf("%s -o %s %s %s %s", { */
        _2 = (int)SEQ_PTR(_settings_45168);
        _24017 = (int)*(((s1_ptr)_2)->base + 3);
        _2 = (int)SEQ_PTR(_54exe_name_44364);
        _24018 = (int)*(((s1_ptr)_2)->base + 11);
        Ref(_24018);
        _24019 = _54adjust_for_build_file(_24018);
        _24018 = NOVALUE;
        _2 = (int)SEQ_PTR(_54res_file_44376);
        _24020 = (int)*(((s1_ptr)_2)->base + 11);
        _2 = (int)SEQ_PTR(_settings_45168);
        _24021 = (int)*(((s1_ptr)_2)->base + 4);
        _1 = NewS1(5);
        _2 = (int)((s1_ptr)_1)->base;
        Ref(_24017);
        *((int *)(_2+4)) = _24017;
        *((int *)(_2+8)) = _24019;
        RefDS(_objs_45167);
        *((int *)(_2+12)) = _objs_45167;
        RefDS(_24020);
        *((int *)(_2+16)) = _24020;
        Ref(_24021);
        *((int *)(_2+20)) = _24021;
        _24022 = MAKE_SEQ(_1);
        _24021 = NOVALUE;
        _24020 = NOVALUE;
        _24019 = NOVALUE;
        _24017 = NOVALUE;
        DeRef(_cmd_45166);
        _cmd_45166 = EPrintf(-9999999, _24016, _24022);
        DeRefDS(_24022);
        _24022 = NOVALUE;
        goto L1D; // [801] 828

        /** 		case else*/
        default:

        /** 			ShowMsg(2, 167, { compiler_type })*/
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = 0;
        _24024 = MAKE_SEQ(_1);
        _44ShowMsg(2, 167, _24024, 1);
        _24024 = NOVALUE;

        /** 			goto "build_direct_cleanup"*/
        goto G11;
    ;}L1D: 

    /** 	if not silent then*/
    if (_26silent_12098 != 0)
    goto L1E; // [832] 886

    /** 		if not verbose then*/
    if (_26verbose_12101 != 0)
    goto L1F; // [839] 870

    /** 			ShowMsg(1, 166, { abbreviate_path(exe_name[D_NAME]) })*/
    _2 = (int)SEQ_PTR(_54exe_name_44364);
    _24027 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_24027);
    RefDS(_22037);
    _24028 = _15abbreviate_path(_24027, _22037);
    _24027 = NOVALUE;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _24028;
    _24029 = MAKE_SEQ(_1);
    _24028 = NOVALUE;
    _44ShowMsg(1, 166, _24029, 1);
    _24029 = NOVALUE;
    goto L20; // [867] 885
L1F: 

    /** 			ShowMsg(1, 166, { cmd })*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_cmd_45166);
    *((int *)(_2+4)) = _cmd_45166;
    _24030 = MAKE_SEQ(_1);
    _44ShowMsg(1, 166, _24030, 1);
    _24030 = NOVALUE;
L20: 
L1E: 

    /** 	status = system_exec(cmd, 0)*/
    _status_45173 = system_exec_call(_cmd_45166, 0);

    /** 	if status != 0 then*/
    if (_status_45173 == 0)
    goto L21; // [896] 939

    /** 		ShowMsg(2, 168, { exe_name[D_NAME] })*/
    _2 = (int)SEQ_PTR(_54exe_name_44364);
    _24033 = (int)*(((s1_ptr)_2)->base + 1);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_24033);
    *((int *)(_2+4)) = _24033;
    _24034 = MAKE_SEQ(_1);
    _24033 = NOVALUE;
    _44ShowMsg(2, 168, _24034, 1);
    _24034 = NOVALUE;

    /** 		ShowMsg(2, 169, { status, cmd })*/
    RefDS(_cmd_45166);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _status_45173;
    ((int *)_2)[2] = _cmd_45166;
    _24035 = MAKE_SEQ(_1);
    _44ShowMsg(2, 169, _24035, 1);
    _24035 = NOVALUE;

    /** 		goto "build_direct_cleanup"*/
    goto G11;
L21: 

    /** 	if length(rc_file[D_ALTNAME]) and length(settings[SETUP_RC_COMPILER]) and compiler_type = COMPILER_WATCOM then*/
    _2 = (int)SEQ_PTR(_54rc_file_44370);
    _24036 = (int)*(((s1_ptr)_2)->base + 11);
    if (IS_SEQUENCE(_24036)){
            _24037 = SEQ_PTR(_24036)->length;
    }
    else {
        _24037 = 1;
    }
    _24036 = NOVALUE;
    if (_24037 == 0) {
        _24038 = 0;
        goto L22; // [952] 967
    }
    _2 = (int)SEQ_PTR(_settings_45168);
    _24039 = (int)*(((s1_ptr)_2)->base + 8);
    if (IS_SEQUENCE(_24039)){
            _24040 = SEQ_PTR(_24039)->length;
    }
    else {
        _24040 = 1;
    }
    _24039 = NOVALUE;
    _24038 = (_24040 != 0);
L22: 
    if (_24038 == 0) {
        goto L23; // [967] 1086
    }
    _24042 = (0 == 2);
    if (_24042 == 0)
    {
        DeRef(_24042);
        _24042 = NOVALUE;
        goto L23; // [978] 1086
    }
    else{
        DeRef(_24042);
        _24042 = NOVALUE;
    }

    /** 		cmd = text:format(settings[SETUP_RC_COMPILER], { rc_file[D_ALTNAME], res_file[D_ALTNAME], exe_name[D_ALTNAME] })*/
    _2 = (int)SEQ_PTR(_settings_45168);
    _24043 = (int)*(((s1_ptr)_2)->base + 8);
    _2 = (int)SEQ_PTR(_54rc_file_44370);
    _24044 = (int)*(((s1_ptr)_2)->base + 11);
    _2 = (int)SEQ_PTR(_54res_file_44376);
    _24045 = (int)*(((s1_ptr)_2)->base + 11);
    _2 = (int)SEQ_PTR(_54exe_name_44364);
    _24046 = (int)*(((s1_ptr)_2)->base + 11);
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_24044);
    *((int *)(_2+4)) = _24044;
    RefDS(_24045);
    *((int *)(_2+8)) = _24045;
    Ref(_24046);
    *((int *)(_2+12)) = _24046;
    _24047 = MAKE_SEQ(_1);
    _24046 = NOVALUE;
    _24045 = NOVALUE;
    _24044 = NOVALUE;
    Ref(_24043);
    _0 = _cmd_45166;
    _cmd_45166 = _12format(_24043, _24047);
    DeRef(_0);
    _24043 = NOVALUE;
    _24047 = NOVALUE;

    /** 		status = system_exec(cmd, 0)*/
    _status_45173 = system_exec_call(_cmd_45166, 0);

    /** 		if status != 0 then*/
    if (_status_45173 == 0)
    goto L24; // [1032] 1085

    /** 			ShowMsg(2, 187, { rc_file[D_NAME], exe_name[D_NAME] })*/
    _2 = (int)SEQ_PTR(_54rc_file_44370);
    _24051 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_54exe_name_44364);
    _24052 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_24052);
    RefDS(_24051);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _24051;
    ((int *)_2)[2] = _24052;
    _24053 = MAKE_SEQ(_1);
    _24052 = NOVALUE;
    _24051 = NOVALUE;
    _44ShowMsg(2, 187, _24053, 1);
    _24053 = NOVALUE;

    /** 			ShowMsg(2, 169, { status, cmd })*/
    RefDS(_cmd_45166);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _status_45173;
    ((int *)_2)[2] = _cmd_45166;
    _24054 = MAKE_SEQ(_1);
    _44ShowMsg(2, 169, _24054, 1);
    _24054 = NOVALUE;

    /** 			goto "build_direct_cleanup"*/
    goto G11;
L24: 
L23: 

    /** label "build_direct_cleanup"*/
G11:

    /** 	if keep = 0 then*/
    if (_56keep_41723 != 0)
    goto L25; // [1094] 1241

    /** 		for i = 1 to length(generated_files) do*/
    if (IS_SEQUENCE(_56generated_files_41720)){
            _24056 = SEQ_PTR(_56generated_files_41720)->length;
    }
    else {
        _24056 = 1;
    }
    {
        int _i_45407;
        _i_45407 = 1;
L26: 
        if (_i_45407 > _24056){
            goto L27; // [1105] 1159
        }

        /** 			if verbose then*/
        if (_26verbose_12101 == 0)
        {
            goto L28; // [1116] 1138
        }
        else{
        }

        /** 				ShowMsg(1, 347, { generated_files[i] })*/
        _2 = (int)SEQ_PTR(_56generated_files_41720);
        _24057 = (int)*(((s1_ptr)_2)->base + _i_45407);
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        RefDS(_24057);
        *((int *)(_2+4)) = _24057;
        _24058 = MAKE_SEQ(_1);
        _24057 = NOVALUE;
        _44ShowMsg(1, 347, _24058, 1);
        _24058 = NOVALUE;
L28: 

        /** 			delete_file(generated_files[i])*/
        _2 = (int)SEQ_PTR(_56generated_files_41720);
        _24059 = (int)*(((s1_ptr)_2)->base + _i_45407);
        RefDS(_24059);
        _31670 = _15delete_file(_24059);
        _24059 = NOVALUE;
        DeRef(_31670);
        _31670 = NOVALUE;

        /** 		end for*/
        _i_45407 = _i_45407 + 1;
        goto L26; // [1154] 1112
L27: 
        ;
    }

    /** 		if length(res_file[D_ALTNAME]) then*/
    _2 = (int)SEQ_PTR(_54res_file_44376);
    _24060 = (int)*(((s1_ptr)_2)->base + 11);
    if (IS_SEQUENCE(_24060)){
            _24061 = SEQ_PTR(_24060)->length;
    }
    else {
        _24061 = 1;
    }
    _24060 = NOVALUE;
    if (_24061 == 0)
    {
        _24061 = NOVALUE;
        goto L29; // [1172] 1192
    }
    else{
        _24061 = NOVALUE;
    }

    /** 			delete_file(res_file[D_ALTNAME])*/
    _2 = (int)SEQ_PTR(_54res_file_44376);
    _24062 = (int)*(((s1_ptr)_2)->base + 11);
    RefDS(_24062);
    _31669 = _15delete_file(_24062);
    _24062 = NOVALUE;
    DeRef(_31669);
    _31669 = NOVALUE;
L29: 

    /** 		if remove_output_dir then*/
L25: 

    /** 	chdir(cwd)*/
    RefDS(_cwd_45170);
    _31667 = _15chdir(_cwd_45170);
    DeRef(_31667);
    _31667 = NOVALUE;

    /** end procedure*/
    DeRefDS(_the_file0_45160);
    DeRef(_cmd_45166);
    DeRef(_objs_45167);
    DeRef(_settings_45168);
    DeRefDS(_cwd_45170);
    DeRef(_link_files_45202);
    DeRef(_23987);
    _23987 = NOVALUE;
    DeRef(_23959);
    _23959 = NOVALUE;
    _23993 = NOVALUE;
    _23996 = NOVALUE;
    _24036 = NOVALUE;
    _24039 = NOVALUE;
    _24060 = NOVALUE;
    return;
    ;
}


void _54write_buildfile()
{
    int _make_command_45447 = NOVALUE;
    int _settings_45487 = NOVALUE;
    int _24089 = NOVALUE;
    int _24088 = NOVALUE;
    int _24084 = NOVALUE;
    int _24083 = NOVALUE;
    int _24082 = NOVALUE;
    int _24080 = NOVALUE;
    int _24079 = NOVALUE;
    int _24078 = NOVALUE;
    int _24077 = NOVALUE;
    int _24076 = NOVALUE;
    int _24075 = NOVALUE;
    int _24074 = NOVALUE;
    int _24073 = NOVALUE;
    int _0, _1, _2;
    

    /** 	switch build_system_type do*/
    _0 = 3;
    switch ( _0 ){ 

        /** 		case BUILD_MAKEFILE_FULL then*/
        case 2:

        /** 			write_makefile_full()*/
        _54write_makefile_full();

        /** 			if not silent then*/
        if (_26silent_12098 != 0)
        goto L1; // [22] 136

        /** 				sequence make_command*/

        /** 				if compiler_type = COMPILER_WATCOM then*/

        /** 					make_command = "make -f "*/
        RefDS(_24072);
        DeRefi(_make_command_45447);
        _make_command_45447 = _24072;

        /** 				ShowMsg(1, 170, { cfile_count + 2 })*/
        _24073 = _26cfile_count_12061 + 2;
        if ((long)((unsigned long)_24073 + (unsigned long)HIGH_BITS) >= 0) 
        _24073 = NewDouble((double)_24073);
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = _24073;
        _24074 = MAKE_SEQ(_1);
        _24073 = NOVALUE;
        _44ShowMsg(1, 170, _24074, 1);
        _24074 = NOVALUE;

        /** 				if sequence(output_dir) and length(output_dir) > 0 then*/
        _24075 = 1;
        if (_24075 == 0) {
            goto L2; // [78] 118
        }
        _24077 = 0;
        _24078 = (0 > 0);
        _24077 = NOVALUE;
        if (_24078 == 0)
        {
            DeRef(_24078);
            _24078 = NOVALUE;
            goto L2; // [92] 118
        }
        else{
            DeRef(_24078);
            _24078 = NOVALUE;
        }

        /** 					ShowMsg(1, 174, { output_dir, make_command, file0 })*/
        _1 = NewS1(3);
        _2 = (int)((s1_ptr)_1)->base;
        RefDS(_56output_dir_41729);
        *((int *)(_2+4)) = _56output_dir_41729;
        RefDS(_make_command_45447);
        *((int *)(_2+8)) = _make_command_45447;
        RefDS(_56file0_43544);
        *((int *)(_2+12)) = _56file0_43544;
        _24079 = MAKE_SEQ(_1);
        _44ShowMsg(1, 174, _24079, 1);
        _24079 = NOVALUE;
        goto L3; // [115] 135
L2: 

        /** 					ShowMsg(1, 172, { make_command, file0 })*/
        RefDS(_56file0_43544);
        RefDS(_make_command_45447);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _make_command_45447;
        ((int *)_2)[2] = _56file0_43544;
        _24080 = MAKE_SEQ(_1);
        _44ShowMsg(1, 172, _24080, 1);
        _24080 = NOVALUE;
L3: 
L1: 
        DeRefi(_make_command_45447);
        _make_command_45447 = NOVALUE;
        goto L4; // [138] 263

        /** 		case BUILD_MAKEFILE_PARTIAL then*/
        case 1:

        /** 			write_makefile_partial()*/
        _54write_makefile_partial();

        /** 			if not silent then*/
        if (_26silent_12098 != 0)
        goto L4; // [152] 263

        /** 				ShowMsg(1, 170, { cfile_count + 2 })*/
        _24082 = _26cfile_count_12061 + 2;
        if ((long)((unsigned long)_24082 + (unsigned long)HIGH_BITS) >= 0) 
        _24082 = NewDouble((double)_24082);
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = _24082;
        _24083 = MAKE_SEQ(_1);
        _24082 = NOVALUE;
        _44ShowMsg(1, 170, _24083, 1);
        _24083 = NOVALUE;

        /** 				ShowMsg(1, 173, { file0 })*/
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        RefDS(_56file0_43544);
        *((int *)(_2+4)) = _56file0_43544;
        _24084 = MAKE_SEQ(_1);
        _44ShowMsg(1, 173, _24084, 1);
        _24084 = NOVALUE;
        goto L4; // [188] 263

        /** 		case BUILD_DIRECT then*/
        case 3:

        /** 			build_direct()*/
        RefDS(_22037);
        _54build_direct(0, _22037);

        /** 			if not silent then*/
        if (_26silent_12098 != 0)
        goto L5; // [204] 215

        /** 				sequence settings = setup_build()*/
        _0 = _settings_45487;
        _settings_45487 = _54setup_build();
        DeRef(_0);
L5: 
        DeRef(_settings_45487);
        _settings_45487 = NOVALUE;
        goto L4; // [217] 263

        /** 		case BUILD_NONE then*/
        case 0:

        /** 			if not silent then*/
        if (_26silent_12098 != 0)
        goto L4; // [227] 263

        /** 				ShowMsg(1, 170, { cfile_count + 2 })*/
        _24088 = _26cfile_count_12061 + 2;
        if ((long)((unsigned long)_24088 + (unsigned long)HIGH_BITS) >= 0) 
        _24088 = NewDouble((double)_24088);
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = _24088;
        _24089 = MAKE_SEQ(_1);
        _24088 = NOVALUE;
        _44ShowMsg(1, 170, _24089, 1);
        _24089 = NOVALUE;
        goto L4; // [249] 263

        /** 		case else*/
        default:

        /** 			CompileErr(151)*/
        RefDS(_22037);
        _43CompileErr(151, _22037, 0);
    ;}L4: 

    /** end procedure*/
    return;
    ;
}



// 0x3E06F7B1
