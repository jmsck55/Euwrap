// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int _66block_type_name(int _opcode_45667)
{
    int _24158 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_opcode_45667)) {
        _1 = (long)(DBL_PTR(_opcode_45667)->dbl);
        DeRefDS(_opcode_45667);
        _opcode_45667 = _1;
    }

    /** 	switch opcode do*/
    _0 = _opcode_45667;
    switch ( _0 ){ 

        /** 		case LOOP then*/
        case 422:

        /** 			return "LOOP"*/
        RefDS(_24156);
        return _24156;
        goto L1; // [20] 63

        /** 		case PROC then*/
        case 27:

        /** 			return "PROC"*/
        RefDS(_21781);
        return _21781;
        goto L1; // [32] 63

        /** 		case FUNC then*/
        case 501:

        /** 			return "FUNC"*/
        RefDS(_24157);
        return _24157;
        goto L1; // [44] 63

        /** 		case else*/
        default:

        /** 			return opnames[opcode]*/
        _2 = (int)SEQ_PTR(_60opnames_22195);
        _24158 = (int)*(((s1_ptr)_2)->base + _opcode_45667);
        RefDS(_24158);
        return _24158;
    ;}L1: 
    ;
}


void _66check_block(int _got_45683)
{
    int _expected_45684 = NOVALUE;
    int _24166 = NOVALUE;
    int _24165 = NOVALUE;
    int _24164 = NOVALUE;
    int _24160 = NOVALUE;
    int _24159 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer expected = block_stack[$][BLOCK_OPCODE]*/
    if (IS_SEQUENCE(_66block_stack_45657)){
            _24159 = SEQ_PTR(_66block_stack_45657)->length;
    }
    else {
        _24159 = 1;
    }
    _2 = (int)SEQ_PTR(_66block_stack_45657);
    _24160 = (int)*(((s1_ptr)_2)->base + _24159);
    _2 = (int)SEQ_PTR(_24160);
    _expected_45684 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_expected_45684)){
        _expected_45684 = (long)DBL_PTR(_expected_45684)->dbl;
    }
    _24160 = NOVALUE;

    /** 	if got = FUNC then*/
    if (_got_45683 != 501)
    goto L1; // [24] 38

    /** 		got = PROC*/
    _got_45683 = 27;
L1: 

    /** 	if got != expected then*/
    if (_got_45683 == _expected_45684)
    goto L2; // [40] 64

    /** 		CompileErr( 79, {block_type_name( expected ), block_type_name( got)} )*/
    _24164 = _66block_type_name(_expected_45684);
    _24165 = _66block_type_name(_got_45683);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _24164;
    ((int *)_2)[2] = _24165;
    _24166 = MAKE_SEQ(_1);
    _24165 = NOVALUE;
    _24164 = NOVALUE;
    _44CompileErr(79, _24166, 0);
    _24166 = NOVALUE;
L2: 

    /** end procedure*/
    return;
    ;
}


void _66Block_var(int _sym_45701)
{
    int _block_45702 = NOVALUE;
    int _24187 = NOVALUE;
    int _24186 = NOVALUE;
    int _24185 = NOVALUE;
    int _24183 = NOVALUE;
    int _24182 = NOVALUE;
    int _24180 = NOVALUE;
    int _24179 = NOVALUE;
    int _24178 = NOVALUE;
    int _24177 = NOVALUE;
    int _24176 = NOVALUE;
    int _24175 = NOVALUE;
    int _24174 = NOVALUE;
    int _24172 = NOVALUE;
    int _24170 = NOVALUE;
    int _24169 = NOVALUE;
    int _24167 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_sym_45701)) {
        _1 = (long)(DBL_PTR(_sym_45701)->dbl);
        DeRefDS(_sym_45701);
        _sym_45701 = _1;
    }

    /** 	sequence block = block_stack[$]*/
    if (IS_SEQUENCE(_66block_stack_45657)){
            _24167 = SEQ_PTR(_66block_stack_45657)->length;
    }
    else {
        _24167 = 1;
    }
    DeRef(_block_45702);
    _2 = (int)SEQ_PTR(_66block_stack_45657);
    _block_45702 = (int)*(((s1_ptr)_2)->base + _24167);
    Ref(_block_45702);

    /** 	block_stack[$] = 0*/
    if (IS_SEQUENCE(_66block_stack_45657)){
            _24169 = SEQ_PTR(_66block_stack_45657)->length;
    }
    else {
        _24169 = 1;
    }
    _2 = (int)SEQ_PTR(_66block_stack_45657);
    _2 = (int)(((s1_ptr)_2)->base + _24169);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 	if length(block_stack) > 1 then*/
    if (IS_SEQUENCE(_66block_stack_45657)){
            _24170 = SEQ_PTR(_66block_stack_45657)->length;
    }
    else {
        _24170 = 1;
    }
    if (_24170 <= 1)
    goto L1; // [34] 58

    /** 		SymTab[sym][S_BLOCK] = block[BLOCK_SYM]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_45701 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_block_45702);
    _24174 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_24174);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35S_BLOCK_15937))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_BLOCK_15937)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _35S_BLOCK_15937);
    _1 = *(int *)_2;
    *(int *)_2 = _24174;
    if( _1 != _24174 ){
        DeRef(_1);
    }
    _24174 = NOVALUE;
    _24172 = NOVALUE;
L1: 

    /** 	if length(block[BLOCK_VARS]) then*/
    _2 = (int)SEQ_PTR(_block_45702);
    _24175 = (int)*(((s1_ptr)_2)->base + 6);
    if (IS_SEQUENCE(_24175)){
            _24176 = SEQ_PTR(_24175)->length;
    }
    else {
        _24176 = 1;
    }
    _24175 = NOVALUE;
    if (_24176 == 0)
    {
        _24176 = NOVALUE;
        goto L2; // [67] 99
    }
    else{
        _24176 = NOVALUE;
    }

    /** 		SymTab[block[BLOCK_VARS][$]][S_NEXT_IN_BLOCK] = sym*/
    _2 = (int)SEQ_PTR(_block_45702);
    _24177 = (int)*(((s1_ptr)_2)->base + 6);
    if (IS_SEQUENCE(_24177)){
            _24178 = SEQ_PTR(_24177)->length;
    }
    else {
        _24178 = 1;
    }
    _2 = (int)SEQ_PTR(_24177);
    _24179 = (int)*(((s1_ptr)_2)->base + _24178);
    _24177 = NOVALUE;
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_24179))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_24179)->dbl));
    else
    _3 = (int)(_24179 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35S_NEXT_IN_BLOCK_15909))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NEXT_IN_BLOCK_15909)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _35S_NEXT_IN_BLOCK_15909);
    _1 = *(int *)_2;
    *(int *)_2 = _sym_45701;
    DeRef(_1);
    _24180 = NOVALUE;
    goto L3; // [96] 119
L2: 

    /** 		SymTab[block[BLOCK_SYM]][S_NEXT_IN_BLOCK] = sym*/
    _2 = (int)SEQ_PTR(_block_45702);
    _24182 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_24182))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_24182)->dbl));
    else
    _3 = (int)(_24182 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35S_NEXT_IN_BLOCK_15909))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NEXT_IN_BLOCK_15909)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _35S_NEXT_IN_BLOCK_15909);
    _1 = *(int *)_2;
    *(int *)_2 = _sym_45701;
    DeRef(_1);
    _24183 = NOVALUE;
L3: 

    /** 	block[BLOCK_VARS] &= sym*/
    _2 = (int)SEQ_PTR(_block_45702);
    _24185 = (int)*(((s1_ptr)_2)->base + 6);
    if (IS_SEQUENCE(_24185) && IS_ATOM(_sym_45701)) {
        Append(&_24186, _24185, _sym_45701);
    }
    else if (IS_ATOM(_24185) && IS_SEQUENCE(_sym_45701)) {
    }
    else {
        Concat((object_ptr)&_24186, _24185, _sym_45701);
        _24185 = NOVALUE;
    }
    _24185 = NOVALUE;
    _2 = (int)SEQ_PTR(_block_45702);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _block_45702 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 6);
    _1 = *(int *)_2;
    *(int *)_2 = _24186;
    if( _1 != _24186 ){
        DeRef(_1);
    }
    _24186 = NOVALUE;

    /** 	block_stack[$] = block*/
    if (IS_SEQUENCE(_66block_stack_45657)){
            _24187 = SEQ_PTR(_66block_stack_45657)->length;
    }
    else {
        _24187 = 1;
    }
    RefDS(_block_45702);
    _2 = (int)SEQ_PTR(_66block_stack_45657);
    _2 = (int)(((s1_ptr)_2)->base + _24187);
    _1 = *(int *)_2;
    *(int *)_2 = _block_45702;
    DeRef(_1);

    /** 	ifdef BDEBUG then*/

    /** end procedure*/
    DeRefDS(_block_45702);
    _24175 = NOVALUE;
    _24179 = NOVALUE;
    _24182 = NOVALUE;
    return;
    ;
}


void _66NewBlock(int _opcode_45736, int _block_label_45737)
{
    int _block_45755 = NOVALUE;
    int _24201 = NOVALUE;
    int _24200 = NOVALUE;
    int _24199 = NOVALUE;
    int _24197 = NOVALUE;
    int _24195 = NOVALUE;
    int _24194 = NOVALUE;
    int _24192 = NOVALUE;
    int _24191 = NOVALUE;
    int _24189 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	SymTab = append( SymTab, repeat( 0, SIZEOF_BLOCK_ENTRY ) )*/
    _24189 = Repeat(0, _35SIZEOF_BLOCK_ENTRY_16049);
    RefDS(_24189);
    Append(&_36SymTab_15242, _36SymTab_15242, _24189);
    DeRefDS(_24189);
    _24189 = NOVALUE;

    /** 	SymTab[$][S_MODE] = M_BLOCK*/
    if (IS_SEQUENCE(_36SymTab_15242)){
            _24191 = SEQ_PTR(_36SymTab_15242)->length;
    }
    else {
        _24191 = 1;
    }
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_24191 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = 4;
    DeRef(_1);
    _24192 = NOVALUE;

    /** 	SymTab[$][S_FIRST_LINE] = gline_number*/
    if (IS_SEQUENCE(_36SymTab_15242)){
            _24194 = SEQ_PTR(_36SymTab_15242)->length;
    }
    else {
        _24194 = 1;
    }
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_24194 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35S_FIRST_LINE_15942))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FIRST_LINE_15942)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _35S_FIRST_LINE_15942);
    _1 = *(int *)_2;
    *(int *)_2 = _35gline_number_16249;
    DeRef(_1);
    _24195 = NOVALUE;

    /** 	sequence block = repeat( 0, BLOCK_SIZE-1 )*/
    _24197 = 6;
    DeRef(_block_45755);
    _block_45755 = Repeat(0, 6);
    _24197 = NOVALUE;

    /** 	block[BLOCK_SYM]    = length(SymTab)*/
    if (IS_SEQUENCE(_36SymTab_15242)){
            _24199 = SEQ_PTR(_36SymTab_15242)->length;
    }
    else {
        _24199 = 1;
    }
    _2 = (int)SEQ_PTR(_block_45755);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _block_45755 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    *(int *)_2 = _24199;
    if( _1 != _24199 ){
    }
    _24199 = NOVALUE;

    /** 	block[BLOCK_OPCODE] = opcode*/
    _2 = (int)SEQ_PTR(_block_45755);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _block_45755 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    *(int *)_2 = _opcode_45736;

    /** 	block[BLOCK_LABEL]  = block_label*/
    Ref(_block_label_45737);
    _2 = (int)SEQ_PTR(_block_45755);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _block_45755 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    *(int *)_2 = _block_label_45737;

    /** 	block[BLOCK_START]  = length(Code) + 1*/
    if (IS_SEQUENCE(_35Code_16332)){
            _24200 = SEQ_PTR(_35Code_16332)->length;
    }
    else {
        _24200 = 1;
    }
    _24201 = _24200 + 1;
    _24200 = NOVALUE;
    _2 = (int)SEQ_PTR(_block_45755);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _block_45755 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = _24201;
    if( _1 != _24201 ){
        DeRef(_1);
    }
    _24201 = NOVALUE;

    /** 	block[BLOCK_VARS]   = {}*/
    RefDS(_22023);
    _2 = (int)SEQ_PTR(_block_45755);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _block_45755 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 6);
    _1 = *(int *)_2;
    *(int *)_2 = _22023;
    DeRef(_1);

    /** 	block_stack = append( block_stack, block )*/
    RefDS(_block_45755);
    Append(&_66block_stack_45657, _66block_stack_45657, _block_45755);

    /** 	current_block = length(SymTab)*/
    if (IS_SEQUENCE(_36SymTab_15242)){
            _66current_block_45664 = SEQ_PTR(_36SymTab_15242)->length;
    }
    else {
        _66current_block_45664 = 1;
    }

    /** end procedure*/
    DeRef(_block_label_45737);
    DeRefDS(_block_45755);
    return;
    ;
}


void _66Start_block(int _opcode_45768, int _block_label_45769)
{
    int _last_block_45771 = NOVALUE;
    int _label_name_45799 = NOVALUE;
    int _24223 = NOVALUE;
    int _24222 = NOVALUE;
    int _24221 = NOVALUE;
    int _24218 = NOVALUE;
    int _24217 = NOVALUE;
    int _24215 = NOVALUE;
    int _24214 = NOVALUE;
    int _24213 = NOVALUE;
    int _24212 = NOVALUE;
    int _24211 = NOVALUE;
    int _24208 = NOVALUE;
    int _24206 = NOVALUE;
    int _24205 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_opcode_45768)) {
        _1 = (long)(DBL_PTR(_opcode_45768)->dbl);
        DeRefDS(_opcode_45768);
        _opcode_45768 = _1;
    }

    /** 	symtab_index last_block = current_block*/
    _last_block_45771 = _66current_block_45664;

    /** 	if opcode = FUNC then*/
    if (_opcode_45768 != 501)
    goto L1; // [16] 30

    /** 		opcode = PROC*/
    _opcode_45768 = 27;
L1: 

    /** 	NewBlock( opcode, block_label )*/
    Ref(_block_label_45769);
    _66NewBlock(_opcode_45768, _block_label_45769);

    /** 	if find(opcode, RTN_TOKS) then*/
    _24205 = find_from(_opcode_45768, _37RTN_TOKS_15870, 1);
    if (_24205 == 0)
    {
        _24205 = NOVALUE;
        goto L2; // [45] 105
    }
    else{
        _24205 = NOVALUE;
    }

    /** 		SymTab[block_label][S_BLOCK] = current_block*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_block_label_45769))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_block_label_45769)->dbl));
    else
    _3 = (int)(_block_label_45769 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35S_BLOCK_15937))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_BLOCK_15937)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _35S_BLOCK_15937);
    _1 = *(int *)_2;
    *(int *)_2 = _66current_block_45664;
    DeRef(_1);
    _24206 = NOVALUE;

    /** 		SymTab[current_block][S_NAME] = sprintf("BLOCK: %s", {SymTab[block_label][S_NAME]})*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_66current_block_45664 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!IS_ATOM_INT(_block_label_45769)){
        _24211 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_block_label_45769)->dbl));
    }
    else{
        _24211 = (int)*(((s1_ptr)_2)->base + _block_label_45769);
    }
    _2 = (int)SEQ_PTR(_24211);
    if (!IS_ATOM_INT(_35S_NAME_15917)){
        _24212 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15917)->dbl));
    }
    else{
        _24212 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15917);
    }
    _24211 = NOVALUE;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_24212);
    *((int *)(_2+4)) = _24212;
    _24213 = MAKE_SEQ(_1);
    _24212 = NOVALUE;
    _24214 = EPrintf(-9999999, _24210, _24213);
    DeRefDS(_24213);
    _24213 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35S_NAME_15917))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15917)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _35S_NAME_15917);
    _1 = *(int *)_2;
    *(int *)_2 = _24214;
    if( _1 != _24214 ){
        DeRef(_1);
    }
    _24214 = NOVALUE;
    _24208 = NOVALUE;
    goto L3; // [102] 185
L2: 

    /** 	elsif current_block then*/
    if (_66current_block_45664 == 0)
    {
        goto L4; // [109] 182
    }
    else{
    }

    /** 		SymTab[current_block][S_BLOCK] = last_block*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_66current_block_45664 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35S_BLOCK_15937))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_BLOCK_15937)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _35S_BLOCK_15937);
    _1 = *(int *)_2;
    *(int *)_2 = _last_block_45771;
    DeRef(_1);
    _24215 = NOVALUE;

    /** 		sequence label_name = ""*/
    RefDS(_22023);
    DeRef(_label_name_45799);
    _label_name_45799 = _22023;

    /** 		if sequence(block_label) then*/
    _24217 = IS_SEQUENCE(_block_label_45769);
    if (_24217 == 0)
    {
        _24217 = NOVALUE;
        goto L5; // [141] 152
    }
    else{
        _24217 = NOVALUE;
    }

    /** 			label_name = block_label*/
    Ref(_block_label_45769);
    DeRefDS(_label_name_45799);
    _label_name_45799 = _block_label_45769;
L5: 

    /** 		SymTab[current_block][S_NAME] = sprintf( "BLOCK: %s-%s", {block_type_name(opcode), label_name})*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_66current_block_45664 + ((s1_ptr)_2)->base);
    _24221 = _66block_type_name(_opcode_45768);
    RefDS(_label_name_45799);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _24221;
    ((int *)_2)[2] = _label_name_45799;
    _24222 = MAKE_SEQ(_1);
    _24221 = NOVALUE;
    _24223 = EPrintf(-9999999, _24220, _24222);
    DeRefDS(_24222);
    _24222 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35S_NAME_15917))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15917)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _35S_NAME_15917);
    _1 = *(int *)_2;
    *(int *)_2 = _24223;
    if( _1 != _24223 ){
        DeRef(_1);
    }
    _24223 = NOVALUE;
    _24218 = NOVALUE;
L4: 
    DeRef(_label_name_45799);
    _label_name_45799 = NOVALUE;
L3: 

    /** 	ifdef BDEBUG then*/

    /** end procedure*/
    DeRef(_block_label_45769);
    return;
    ;
}


void _66block_label(int _label_name_45815)
{
    int _24237 = NOVALUE;
    int _24236 = NOVALUE;
    int _24235 = NOVALUE;
    int _24234 = NOVALUE;
    int _24233 = NOVALUE;
    int _24232 = NOVALUE;
    int _24230 = NOVALUE;
    int _24228 = NOVALUE;
    int _24227 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	block_stack[$][BLOCK_LABEL] = label_name*/
    if (IS_SEQUENCE(_66block_stack_45657)){
            _24227 = SEQ_PTR(_66block_stack_45657)->length;
    }
    else {
        _24227 = 1;
    }
    _2 = (int)SEQ_PTR(_66block_stack_45657);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _66block_stack_45657 = MAKE_SEQ(_2);
    }
    _3 = (int)(_24227 + ((s1_ptr)_2)->base);
    RefDS(_label_name_45815);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = _label_name_45815;
    DeRef(_1);
    _24228 = NOVALUE;

    /** 	SymTab[current_block][S_NAME] = sprintf( "BLOCK: %s-%s", */
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_66current_block_45664 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_66block_stack_45657)){
            _24232 = SEQ_PTR(_66block_stack_45657)->length;
    }
    else {
        _24232 = 1;
    }
    _2 = (int)SEQ_PTR(_66block_stack_45657);
    _24233 = (int)*(((s1_ptr)_2)->base + _24232);
    _2 = (int)SEQ_PTR(_24233);
    _24234 = (int)*(((s1_ptr)_2)->base + 2);
    _24233 = NOVALUE;
    Ref(_24234);
    _24235 = _66block_type_name(_24234);
    _24234 = NOVALUE;
    RefDS(_label_name_45815);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _24235;
    ((int *)_2)[2] = _label_name_45815;
    _24236 = MAKE_SEQ(_1);
    _24235 = NOVALUE;
    _24237 = EPrintf(-9999999, _24220, _24236);
    DeRefDS(_24236);
    _24236 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35S_NAME_15917))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15917)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _35S_NAME_15917);
    _1 = *(int *)_2;
    *(int *)_2 = _24237;
    if( _1 != _24237 ){
        DeRef(_1);
    }
    _24237 = NOVALUE;
    _24230 = NOVALUE;

    /** end procedure*/
    DeRefDS(_label_name_45815);
    return;
    ;
}


int _66pop_block()
{
    int _block_45834 = NOVALUE;
    int _block_vars_45847 = NOVALUE;
    int _24266 = NOVALUE;
    int _24264 = NOVALUE;
    int _24263 = NOVALUE;
    int _24262 = NOVALUE;
    int _24261 = NOVALUE;
    int _24259 = NOVALUE;
    int _24258 = NOVALUE;
    int _24257 = NOVALUE;
    int _24256 = NOVALUE;
    int _24255 = NOVALUE;
    int _24254 = NOVALUE;
    int _24253 = NOVALUE;
    int _24252 = NOVALUE;
    int _24251 = NOVALUE;
    int _24250 = NOVALUE;
    int _24246 = NOVALUE;
    int _24245 = NOVALUE;
    int _24243 = NOVALUE;
    int _24242 = NOVALUE;
    int _24240 = NOVALUE;
    int _24238 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	if not length(block_stack) then*/
    if (IS_SEQUENCE(_66block_stack_45657)){
            _24238 = SEQ_PTR(_66block_stack_45657)->length;
    }
    else {
        _24238 = 1;
    }
    if (_24238 != 0)
    goto L1; // [8] 18
    _24238 = NOVALUE;

    /** 		return 0*/
    DeRef(_block_45834);
    DeRef(_block_vars_45847);
    return 0;
L1: 

    /** 	sequence  block = block_stack[$]*/
    if (IS_SEQUENCE(_66block_stack_45657)){
            _24240 = SEQ_PTR(_66block_stack_45657)->length;
    }
    else {
        _24240 = 1;
    }
    DeRef(_block_45834);
    _2 = (int)SEQ_PTR(_66block_stack_45657);
    _block_45834 = (int)*(((s1_ptr)_2)->base + _24240);
    Ref(_block_45834);

    /** 	block_stack = block_stack[1..$-1]*/
    if (IS_SEQUENCE(_66block_stack_45657)){
            _24242 = SEQ_PTR(_66block_stack_45657)->length;
    }
    else {
        _24242 = 1;
    }
    _24243 = _24242 - 1;
    _24242 = NOVALUE;
    rhs_slice_target = (object_ptr)&_66block_stack_45657;
    RHS_Slice(_66block_stack_45657, 1, _24243);

    /** 	SymTab[block[BLOCK_SYM]][S_LAST_LINE] = gline_number*/
    _2 = (int)SEQ_PTR(_block_45834);
    _24245 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_24245))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_24245)->dbl));
    else
    _3 = (int)(_24245 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35S_LAST_LINE_15947))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_LAST_LINE_15947)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _35S_LAST_LINE_15947);
    _1 = *(int *)_2;
    *(int *)_2 = _35gline_number_16249;
    DeRef(_1);
    _24246 = NOVALUE;

    /** 	ifdef BDEBUG then*/

    /** 	sequence block_vars = block[BLOCK_VARS]*/
    DeRef(_block_vars_45847);
    _2 = (int)SEQ_PTR(_block_45834);
    _block_vars_45847 = (int)*(((s1_ptr)_2)->base + 6);
    Ref(_block_vars_45847);

    /** 	for sx = 1 to length( block_vars ) do*/
    if (IS_SEQUENCE(_block_vars_45847)){
            _24250 = SEQ_PTR(_block_vars_45847)->length;
    }
    else {
        _24250 = 1;
    }
    {
        int _sx_45850;
        _sx_45850 = 1;
L2: 
        if (_sx_45850 > _24250){
            goto L3; // [83] 172
        }

        /** 		if SymTab[block_vars[sx]][S_MODE] = M_NORMAL */
        _2 = (int)SEQ_PTR(_block_vars_45847);
        _24251 = (int)*(((s1_ptr)_2)->base + _sx_45850);
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        if (!IS_ATOM_INT(_24251)){
            _24252 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_24251)->dbl));
        }
        else{
            _24252 = (int)*(((s1_ptr)_2)->base + _24251);
        }
        _2 = (int)SEQ_PTR(_24252);
        _24253 = (int)*(((s1_ptr)_2)->base + 3);
        _24252 = NOVALUE;
        if (IS_ATOM_INT(_24253)) {
            _24254 = (_24253 == 1);
        }
        else {
            _24254 = binary_op(EQUALS, _24253, 1);
        }
        _24253 = NOVALUE;
        if (IS_ATOM_INT(_24254)) {
            if (_24254 == 0) {
                goto L4; // [114] 165
            }
        }
        else {
            if (DBL_PTR(_24254)->dbl == 0.0) {
                goto L4; // [114] 165
            }
        }
        _2 = (int)SEQ_PTR(_block_vars_45847);
        _24256 = (int)*(((s1_ptr)_2)->base + _sx_45850);
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        if (!IS_ATOM_INT(_24256)){
            _24257 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_24256)->dbl));
        }
        else{
            _24257 = (int)*(((s1_ptr)_2)->base + _24256);
        }
        _2 = (int)SEQ_PTR(_24257);
        _24258 = (int)*(((s1_ptr)_2)->base + 4);
        _24257 = NOVALUE;
        if (IS_ATOM_INT(_24258)) {
            _24259 = (_24258 <= 5);
        }
        else {
            _24259 = binary_op(LESSEQ, _24258, 5);
        }
        _24258 = NOVALUE;
        if (_24259 == 0) {
            DeRef(_24259);
            _24259 = NOVALUE;
            goto L4; // [141] 165
        }
        else {
            if (!IS_ATOM_INT(_24259) && DBL_PTR(_24259)->dbl == 0.0){
                DeRef(_24259);
                _24259 = NOVALUE;
                goto L4; // [141] 165
            }
            DeRef(_24259);
            _24259 = NOVALUE;
        }
        DeRef(_24259);
        _24259 = NOVALUE;

        /** 			ifdef BDEBUG then*/

        /** 			Hide( block_vars[sx] )*/
        _2 = (int)SEQ_PTR(_block_vars_45847);
        _24261 = (int)*(((s1_ptr)_2)->base + _sx_45850);
        Ref(_24261);
        _53Hide(_24261);
        _24261 = NOVALUE;

        /** 			LintCheck( block_vars[sx] )*/
        _2 = (int)SEQ_PTR(_block_vars_45847);
        _24262 = (int)*(((s1_ptr)_2)->base + _sx_45850);
        Ref(_24262);
        _53LintCheck(_24262);
        _24262 = NOVALUE;
L4: 

        /** 	end for*/
        _sx_45850 = _sx_45850 + 1;
        goto L2; // [167] 90
L3: 
        ;
    }

    /** 	current_block = block_stack[$][BLOCK_SYM]*/
    if (IS_SEQUENCE(_66block_stack_45657)){
            _24263 = SEQ_PTR(_66block_stack_45657)->length;
    }
    else {
        _24263 = 1;
    }
    _2 = (int)SEQ_PTR(_66block_stack_45657);
    _24264 = (int)*(((s1_ptr)_2)->base + _24263);
    _2 = (int)SEQ_PTR(_24264);
    _66current_block_45664 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_66current_block_45664)){
        _66current_block_45664 = (long)DBL_PTR(_66current_block_45664)->dbl;
    }
    _24264 = NOVALUE;

    /** 	return block[BLOCK_SYM]*/
    _2 = (int)SEQ_PTR(_block_45834);
    _24266 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_24266);
    DeRefDS(_block_45834);
    DeRef(_block_vars_45847);
    DeRef(_24243);
    _24243 = NOVALUE;
    _24245 = NOVALUE;
    _24251 = NOVALUE;
    _24256 = NOVALUE;
    DeRef(_24254);
    _24254 = NOVALUE;
    return _24266;
    ;
}


int _66top_block(int _offset_45879)
{
    int _24274 = NOVALUE;
    int _24273 = NOVALUE;
    int _24272 = NOVALUE;
    int _24271 = NOVALUE;
    int _24270 = NOVALUE;
    int _24269 = NOVALUE;
    int _24267 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_offset_45879)) {
        _1 = (long)(DBL_PTR(_offset_45879)->dbl);
        DeRefDS(_offset_45879);
        _offset_45879 = _1;
    }

    /** 	if offset >= length(block_stack) then*/
    if (IS_SEQUENCE(_66block_stack_45657)){
            _24267 = SEQ_PTR(_66block_stack_45657)->length;
    }
    else {
        _24267 = 1;
    }
    if (_offset_45879 < _24267)
    goto L1; // [10] 33

    /** 		CompileErr(107, {offset,length(block_stack)})*/
    if (IS_SEQUENCE(_66block_stack_45657)){
            _24269 = SEQ_PTR(_66block_stack_45657)->length;
    }
    else {
        _24269 = 1;
    }
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _offset_45879;
    ((int *)_2)[2] = _24269;
    _24270 = MAKE_SEQ(_1);
    _24269 = NOVALUE;
    _44CompileErr(107, _24270, 0);
    _24270 = NOVALUE;
    goto L2; // [30] 57
L1: 

    /** 		return block_stack[$-offset][BLOCK_SYM]*/
    if (IS_SEQUENCE(_66block_stack_45657)){
            _24271 = SEQ_PTR(_66block_stack_45657)->length;
    }
    else {
        _24271 = 1;
    }
    _24272 = _24271 - _offset_45879;
    _24271 = NOVALUE;
    _2 = (int)SEQ_PTR(_66block_stack_45657);
    _24273 = (int)*(((s1_ptr)_2)->base + _24272);
    _2 = (int)SEQ_PTR(_24273);
    _24274 = (int)*(((s1_ptr)_2)->base + 1);
    _24273 = NOVALUE;
    Ref(_24274);
    _24272 = NOVALUE;
    return _24274;
L2: 
    ;
}


void _66End_block(int _opcode_45893)
{
    int _ix_45904 = NOVALUE;
    int _24282 = NOVALUE;
    int _24279 = NOVALUE;
    int _24278 = NOVALUE;
    int _24277 = NOVALUE;
    int _24276 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_opcode_45893)) {
        _1 = (long)(DBL_PTR(_opcode_45893)->dbl);
        DeRefDS(_opcode_45893);
        _opcode_45893 = _1;
    }

    /** 	if opcode = FUNC then*/
    if (_opcode_45893 != 501)
    goto L1; // [7] 21

    /** 		opcode = PROC*/
    _opcode_45893 = 27;
L1: 

    /** 	check_block( opcode )*/
    _66check_block(_opcode_45893);

    /** 	if not length(block_stack[$][BLOCK_VARS]) then*/
    if (IS_SEQUENCE(_66block_stack_45657)){
            _24276 = SEQ_PTR(_66block_stack_45657)->length;
    }
    else {
        _24276 = 1;
    }
    _2 = (int)SEQ_PTR(_66block_stack_45657);
    _24277 = (int)*(((s1_ptr)_2)->base + _24276);
    _2 = (int)SEQ_PTR(_24277);
    _24278 = (int)*(((s1_ptr)_2)->base + 6);
    _24277 = NOVALUE;
    if (IS_SEQUENCE(_24278)){
            _24279 = SEQ_PTR(_24278)->length;
    }
    else {
        _24279 = 1;
    }
    _24278 = NOVALUE;
    if (_24279 != 0)
    goto L2; // [44] 64
    _24279 = NOVALUE;

    /** 		integer ix = 1*/
    _ix_45904 = 1;

    /** 		ix = pop_block()*/
    _ix_45904 = _66pop_block();
    if (!IS_ATOM_INT(_ix_45904)) {
        _1 = (long)(DBL_PTR(_ix_45904)->dbl);
        DeRefDS(_ix_45904);
        _ix_45904 = _1;
    }
    goto L3; // [61] 80
L2: 

    /** 		Push( pop_block() )*/
    _24282 = _66pop_block();
    _41Push(_24282);
    _24282 = NOVALUE;

    /** 		emit_op( EXIT_BLOCK )*/
    _41emit_op(206);
L3: 

    /** end procedure*/
    _24278 = NOVALUE;
    return;
    ;
}


int _66End_inline_block(int _opcode_45913)
{
    int _24289 = NOVALUE;
    int _24288 = NOVALUE;
    int _24287 = NOVALUE;
    int _24286 = NOVALUE;
    int _24285 = NOVALUE;
    int _24284 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_opcode_45913)) {
        _1 = (long)(DBL_PTR(_opcode_45913)->dbl);
        DeRefDS(_opcode_45913);
        _opcode_45913 = _1;
    }

    /** 	if opcode = FUNC then*/
    if (_opcode_45913 != 501)
    goto L1; // [7] 21

    /** 		opcode = PROC*/
    _opcode_45913 = 27;
L1: 

    /** 	if length(block_stack[$][BLOCK_VARS]) then*/
    if (IS_SEQUENCE(_66block_stack_45657)){
            _24284 = SEQ_PTR(_66block_stack_45657)->length;
    }
    else {
        _24284 = 1;
    }
    _2 = (int)SEQ_PTR(_66block_stack_45657);
    _24285 = (int)*(((s1_ptr)_2)->base + _24284);
    _2 = (int)SEQ_PTR(_24285);
    _24286 = (int)*(((s1_ptr)_2)->base + 6);
    _24285 = NOVALUE;
    if (IS_SEQUENCE(_24286)){
            _24287 = SEQ_PTR(_24286)->length;
    }
    else {
        _24287 = 1;
    }
    _24286 = NOVALUE;
    if (_24287 == 0)
    {
        _24287 = NOVALUE;
        goto L2; // [39] 60
    }
    else{
        _24287 = NOVALUE;
    }

    /** 		return { EXIT_BLOCK, pop_block() }*/
    _24288 = _66pop_block();
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 206;
    ((int *)_2)[2] = _24288;
    _24289 = MAKE_SEQ(_1);
    _24288 = NOVALUE;
    _24286 = NOVALUE;
    return _24289;
    goto L3; // [57] 72
L2: 

    /** 		Drop_block( opcode )*/
    _66Drop_block(_opcode_45913);

    /** 		return {}*/
    RefDS(_22023);
    _24286 = NOVALUE;
    DeRef(_24289);
    _24289 = NOVALUE;
    return _22023;
L3: 
    ;
}


void _66Sibling_block(int _opcode_45930)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_opcode_45930)) {
        _1 = (long)(DBL_PTR(_opcode_45930)->dbl);
        DeRefDS(_opcode_45930);
        _opcode_45930 = _1;
    }

    /** 	End_block( opcode )*/
    _66End_block(_opcode_45930);

    /** 	Start_block( opcode )*/
    _66Start_block(_opcode_45930, 0);

    /** end procedure*/
    return;
    ;
}


void _66Leave_block(int _offset_45933)
{
    int _24295 = NOVALUE;
    int _24294 = NOVALUE;
    int _24293 = NOVALUE;
    int _24292 = NOVALUE;
    int _24291 = NOVALUE;
    int _24290 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_offset_45933)) {
        _1 = (long)(DBL_PTR(_offset_45933)->dbl);
        DeRefDS(_offset_45933);
        _offset_45933 = _1;
    }

    /** 	if length( block_stack[$-offset][BLOCK_VARS]) then*/
    if (IS_SEQUENCE(_66block_stack_45657)){
            _24290 = SEQ_PTR(_66block_stack_45657)->length;
    }
    else {
        _24290 = 1;
    }
    _24291 = _24290 - _offset_45933;
    _24290 = NOVALUE;
    _2 = (int)SEQ_PTR(_66block_stack_45657);
    _24292 = (int)*(((s1_ptr)_2)->base + _24291);
    _2 = (int)SEQ_PTR(_24292);
    _24293 = (int)*(((s1_ptr)_2)->base + 6);
    _24292 = NOVALUE;
    if (IS_SEQUENCE(_24293)){
            _24294 = SEQ_PTR(_24293)->length;
    }
    else {
        _24294 = 1;
    }
    _24293 = NOVALUE;
    if (_24294 == 0)
    {
        _24294 = NOVALUE;
        goto L1; // [25] 45
    }
    else{
        _24294 = NOVALUE;
    }

    /** 		Push( top_block( offset ) )*/
    _24295 = _66top_block(_offset_45933);
    _41Push(_24295);
    _24295 = NOVALUE;

    /** 		emit_op( EXIT_BLOCK )*/
    _41emit_op(206);
L1: 

    /** end procedure*/
    DeRef(_24291);
    _24291 = NOVALUE;
    _24293 = NOVALUE;
    return;
    ;
}


void _66Leave_blocks(int _blocks_45953, int _block_type_45954)
{
    int _bx_45955 = NOVALUE;
    int _Block_opcode_3__tmp_at29_45962 = NOVALUE;
    int _Block_opcode_2__tmp_at29_45961 = NOVALUE;
    int _Block_opcode_1__tmp_at29_45960 = NOVALUE;
    int _Block_opcode_inlined_Block_opcode_at_29_45959 = NOVALUE;
    int _24308 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_blocks_45953)) {
        _1 = (long)(DBL_PTR(_blocks_45953)->dbl);
        DeRefDS(_blocks_45953);
        _blocks_45953 = _1;
    }
    if (!IS_ATOM_INT(_block_type_45954)) {
        _1 = (long)(DBL_PTR(_block_type_45954)->dbl);
        DeRefDS(_block_type_45954);
        _block_type_45954 = _1;
    }

    /** 	integer bx = 0*/
    _bx_45955 = 0;

    /** 	while blocks do*/
L1: 
    if (_blocks_45953 == 0)
    {
        goto L2; // [15] 119
    }
    else{
    }

    /** 		Leave_block( bx )*/
    _66Leave_block(_bx_45955);

    /** 		if block_type then*/
    if (_block_type_45954 == 0)
    {
        goto L3; // [25] 101
    }
    else{
    }

    /** 			switch Block_opcode( bx ) do*/

    /** 	return block_stack[$-bx][BLOCK_OPCODE]*/
    if (IS_SEQUENCE(_66block_stack_45657)){
            _Block_opcode_1__tmp_at29_45960 = SEQ_PTR(_66block_stack_45657)->length;
    }
    else {
        _Block_opcode_1__tmp_at29_45960 = 1;
    }
    _Block_opcode_2__tmp_at29_45961 = _Block_opcode_1__tmp_at29_45960 - _bx_45955;
    DeRef(_Block_opcode_3__tmp_at29_45962);
    _2 = (int)SEQ_PTR(_66block_stack_45657);
    _Block_opcode_3__tmp_at29_45962 = (int)*(((s1_ptr)_2)->base + _Block_opcode_2__tmp_at29_45961);
    Ref(_Block_opcode_3__tmp_at29_45962);
    DeRef(_Block_opcode_inlined_Block_opcode_at_29_45959);
    _2 = (int)SEQ_PTR(_Block_opcode_3__tmp_at29_45962);
    _Block_opcode_inlined_Block_opcode_at_29_45959 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_Block_opcode_inlined_Block_opcode_at_29_45959);
    DeRef(_Block_opcode_3__tmp_at29_45962);
    _Block_opcode_3__tmp_at29_45962 = NOVALUE;
    if (IS_SEQUENCE(_Block_opcode_inlined_Block_opcode_at_29_45959) ){
        goto L4; // [52] 82
    }
    if(!IS_ATOM_INT(_Block_opcode_inlined_Block_opcode_at_29_45959)){
        if( (DBL_PTR(_Block_opcode_inlined_Block_opcode_at_29_45959)->dbl != (double) ((int) DBL_PTR(_Block_opcode_inlined_Block_opcode_at_29_45959)->dbl) ) ){
            goto L4; // [52] 82
        }
        _0 = (int) DBL_PTR(_Block_opcode_inlined_Block_opcode_at_29_45959)->dbl;
    }
    else {
        _0 = _Block_opcode_inlined_Block_opcode_at_29_45959;
    };
    switch ( _0 ){ 

        /** 				case FOR, WHILE, LOOP then*/
        case 21:
        case 47:
        case 422:

        /** 					if block_type = LOOP_BLOCK then*/
        if (_block_type_45954 != 1)
        goto L5; // [67] 108

        /** 						blocks -= 1*/
        _blocks_45953 = _blocks_45953 - 1;
        goto L5; // [78] 108

        /** 				case else*/
        default:
L4: 

        /** 					if block_type = CONDITIONAL_BLOCK then*/
        if (_block_type_45954 != 2)
        goto L6; // [86] 97

        /** 						blocks -= 1*/
        _blocks_45953 = _blocks_45953 - 1;
L6: 
    ;}    goto L5; // [98] 108
L3: 

    /** 			blocks -= 1*/
    _blocks_45953 = _blocks_45953 - 1;
L5: 

    /** 		bx += 1*/
    _bx_45955 = _bx_45955 + 1;

    /** 	end while*/
    goto L1; // [116] 15
L2: 

    /** 	for i = 0 to blocks - 1 do*/
    _24308 = _blocks_45953 - 1;
    if ((long)((unsigned long)_24308 +(unsigned long) HIGH_BITS) >= 0){
        _24308 = NewDouble((double)_24308);
    }
    {
        int _i_45980;
        _i_45980 = 0;
L7: 
        if (binary_op_a(GREATER, _i_45980, _24308)){
            goto L8; // [125] 144
        }

        /** 		Leave_block( i )*/
        Ref(_i_45980);
        _66Leave_block(_i_45980);

        /** 	end for*/
        _0 = _i_45980;
        if (IS_ATOM_INT(_i_45980)) {
            _i_45980 = _i_45980 + 1;
            if ((long)((unsigned long)_i_45980 +(unsigned long) HIGH_BITS) >= 0){
                _i_45980 = NewDouble((double)_i_45980);
            }
        }
        else {
            _i_45980 = binary_op_a(PLUS, _i_45980, 1);
        }
        DeRef(_0);
        goto L7; // [139] 132
L8: 
        ;
        DeRef(_i_45980);
    }

    /** end procedure*/
    DeRef(_24308);
    _24308 = NOVALUE;
    return;
    ;
}


void _66Drop_block(int _opcode_45984)
{
    int _x_45986 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_opcode_45984)) {
        _1 = (long)(DBL_PTR(_opcode_45984)->dbl);
        DeRefDS(_opcode_45984);
        _opcode_45984 = _1;
    }

    /** 	check_block( opcode )*/
    _66check_block(_opcode_45984);

    /** 	symtab_index x = pop_block()*/
    _x_45986 = _66pop_block();
    if (!IS_ATOM_INT(_x_45986)) {
        _1 = (long)(DBL_PTR(_x_45986)->dbl);
        DeRefDS(_x_45986);
        _x_45986 = _1;
    }

    /** end procedure*/
    return;
    ;
}


void _66Pop_block_var()
{
    int _sym_45991 = NOVALUE;
    int _block_sym_45998 = NOVALUE;
    int _24336 = NOVALUE;
    int _24335 = NOVALUE;
    int _24334 = NOVALUE;
    int _24333 = NOVALUE;
    int _24332 = NOVALUE;
    int _24331 = NOVALUE;
    int _24330 = NOVALUE;
    int _24329 = NOVALUE;
    int _24327 = NOVALUE;
    int _24326 = NOVALUE;
    int _24324 = NOVALUE;
    int _24323 = NOVALUE;
    int _24321 = NOVALUE;
    int _24318 = NOVALUE;
    int _24316 = NOVALUE;
    int _24315 = NOVALUE;
    int _24313 = NOVALUE;
    int _24312 = NOVALUE;
    int _24311 = NOVALUE;
    int _24310 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	symtab_index sym = block_stack[$][BLOCK_VARS][$]*/
    if (IS_SEQUENCE(_66block_stack_45657)){
            _24310 = SEQ_PTR(_66block_stack_45657)->length;
    }
    else {
        _24310 = 1;
    }
    _2 = (int)SEQ_PTR(_66block_stack_45657);
    _24311 = (int)*(((s1_ptr)_2)->base + _24310);
    _2 = (int)SEQ_PTR(_24311);
    _24312 = (int)*(((s1_ptr)_2)->base + 6);
    _24311 = NOVALUE;
    if (IS_SEQUENCE(_24312)){
            _24313 = SEQ_PTR(_24312)->length;
    }
    else {
        _24313 = 1;
    }
    _2 = (int)SEQ_PTR(_24312);
    _sym_45991 = (int)*(((s1_ptr)_2)->base + _24313);
    if (!IS_ATOM_INT(_sym_45991)){
        _sym_45991 = (long)DBL_PTR(_sym_45991)->dbl;
    }
    _24312 = NOVALUE;

    /** 	symtab_index block_sym = block_stack[$][BLOCK_SYM]*/
    if (IS_SEQUENCE(_66block_stack_45657)){
            _24315 = SEQ_PTR(_66block_stack_45657)->length;
    }
    else {
        _24315 = 1;
    }
    _2 = (int)SEQ_PTR(_66block_stack_45657);
    _24316 = (int)*(((s1_ptr)_2)->base + _24315);
    _2 = (int)SEQ_PTR(_24316);
    _block_sym_45998 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_block_sym_45998)){
        _block_sym_45998 = (long)DBL_PTR(_block_sym_45998)->dbl;
    }
    _24316 = NOVALUE;

    /** 	while sym_next_in_block( block_sym ) != sym do*/
L1: 
    _24318 = _53sym_next_in_block(_block_sym_45998);
    if (binary_op_a(EQUALS, _24318, _sym_45991)){
        DeRef(_24318);
        _24318 = NOVALUE;
        goto L2; // [51] 68
    }
    DeRef(_24318);
    _24318 = NOVALUE;

    /** 		block_sym = sym_next_in_block( block_sym )*/
    _block_sym_45998 = _53sym_next_in_block(_block_sym_45998);
    if (!IS_ATOM_INT(_block_sym_45998)) {
        _1 = (long)(DBL_PTR(_block_sym_45998)->dbl);
        DeRefDS(_block_sym_45998);
        _block_sym_45998 = _1;
    }

    /** 	end while*/
    goto L1; // [65] 47
L2: 

    /** 	SymTab[block_sym][S_NEXT_IN_BLOCK] = sym_next_in_block( sym )*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_block_sym_45998 + ((s1_ptr)_2)->base);
    _24323 = _53sym_next_in_block(_sym_45991);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35S_NEXT_IN_BLOCK_15909))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NEXT_IN_BLOCK_15909)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _35S_NEXT_IN_BLOCK_15909);
    _1 = *(int *)_2;
    *(int *)_2 = _24323;
    if( _1 != _24323 ){
        DeRef(_1);
    }
    _24323 = NOVALUE;
    _24321 = NOVALUE;

    /** 	SymTab[sym][S_NEXT_IN_BLOCK] = 0*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_45991 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35S_NEXT_IN_BLOCK_15909))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NEXT_IN_BLOCK_15909)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _35S_NEXT_IN_BLOCK_15909);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _24324 = NOVALUE;

    /** 	block_stack[$][BLOCK_VARS] = eu:remove( block_stack[$][BLOCK_VARS], */
    if (IS_SEQUENCE(_66block_stack_45657)){
            _24326 = SEQ_PTR(_66block_stack_45657)->length;
    }
    else {
        _24326 = 1;
    }
    _2 = (int)SEQ_PTR(_66block_stack_45657);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _66block_stack_45657 = MAKE_SEQ(_2);
    }
    _3 = (int)(_24326 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_66block_stack_45657)){
            _24329 = SEQ_PTR(_66block_stack_45657)->length;
    }
    else {
        _24329 = 1;
    }
    _2 = (int)SEQ_PTR(_66block_stack_45657);
    _24330 = (int)*(((s1_ptr)_2)->base + _24329);
    _2 = (int)SEQ_PTR(_24330);
    _24331 = (int)*(((s1_ptr)_2)->base + 6);
    _24330 = NOVALUE;
    if (IS_SEQUENCE(_66block_stack_45657)){
            _24332 = SEQ_PTR(_66block_stack_45657)->length;
    }
    else {
        _24332 = 1;
    }
    _2 = (int)SEQ_PTR(_66block_stack_45657);
    _24333 = (int)*(((s1_ptr)_2)->base + _24332);
    _2 = (int)SEQ_PTR(_24333);
    _24334 = (int)*(((s1_ptr)_2)->base + 6);
    _24333 = NOVALUE;
    if (IS_SEQUENCE(_24334)){
            _24335 = SEQ_PTR(_24334)->length;
    }
    else {
        _24335 = 1;
    }
    _24334 = NOVALUE;
    {
        s1_ptr assign_space = SEQ_PTR(_24331);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_24335)) ? _24335 : (long)(DBL_PTR(_24335)->dbl);
        int stop = (IS_ATOM_INT(_24335)) ? _24335 : (long)(DBL_PTR(_24335)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
            RefDS(_24331);
            DeRef(_24336);
            _24336 = _24331;
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_24331), start, &_24336 );
            }
            else Tail(SEQ_PTR(_24331), stop+1, &_24336);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_24331), start, &_24336);
        }
        else {
            assign_slice_seq = &assign_space;
            _1 = Remove_elements(start, stop, 0);
            DeRef(_24336);
            _24336 = _1;
        }
    }
    _24331 = NOVALUE;
    _24335 = NOVALUE;
    _24335 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 6);
    _1 = *(int *)_2;
    *(int *)_2 = _24336;
    if( _1 != _24336 ){
        DeRef(_1);
    }
    _24336 = NOVALUE;
    _24327 = NOVALUE;

    /** end procedure*/
    _24334 = NOVALUE;
    return;
    ;
}


void _66Goto_block(int _from_block_46032, int _to_block_46034, int _pc_46035)
{
    int _code_46036 = NOVALUE;
    int _next_block_46038 = NOVALUE;
    int _24347 = NOVALUE;
    int _24344 = NOVALUE;
    int _24343 = NOVALUE;
    int _24342 = NOVALUE;
    int _24341 = NOVALUE;
    int _24340 = NOVALUE;
    int _24339 = NOVALUE;
    int _24338 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_from_block_46032)) {
        _1 = (long)(DBL_PTR(_from_block_46032)->dbl);
        DeRefDS(_from_block_46032);
        _from_block_46032 = _1;
    }
    if (!IS_ATOM_INT(_to_block_46034)) {
        _1 = (long)(DBL_PTR(_to_block_46034)->dbl);
        DeRefDS(_to_block_46034);
        _to_block_46034 = _1;
    }
    if (!IS_ATOM_INT(_pc_46035)) {
        _1 = (long)(DBL_PTR(_pc_46035)->dbl);
        DeRefDS(_pc_46035);
        _pc_46035 = _1;
    }

    /** 	sequence code = {}*/
    RefDS(_22023);
    DeRefi(_code_46036);
    _code_46036 = _22023;

    /** 	symtab_index next_block = sym_block( from_block )*/
    _next_block_46038 = _53sym_block(_from_block_46032);
    if (!IS_ATOM_INT(_next_block_46038)) {
        _1 = (long)(DBL_PTR(_next_block_46038)->dbl);
        DeRefDS(_next_block_46038);
        _next_block_46038 = _1;
    }

    /** 	while next_block */
L1: 
    if (_next_block_46038 == 0) {
        _24338 = 0;
        goto L2; // [27] 39
    }
    _24339 = (_from_block_46032 != _to_block_46034);
    _24338 = (_24339 != 0);
L2: 
    if (_24338 == 0) {
        goto L3; // [39] 93
    }
    _24341 = _53sym_token(_next_block_46038);
    _24342 = find_from(_24341, _37RTN_TOKS_15870, 1);
    DeRef(_24341);
    _24341 = NOVALUE;
    _24343 = (_24342 == 0);
    _24342 = NOVALUE;
    if (_24343 == 0)
    {
        DeRef(_24343);
        _24343 = NOVALUE;
        goto L3; // [58] 93
    }
    else{
        DeRef(_24343);
        _24343 = NOVALUE;
    }

    /** 		code &= { EXIT_BLOCK, from_block }*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 206;
    ((int *)_2)[2] = _from_block_46032;
    _24344 = MAKE_SEQ(_1);
    Concat((object_ptr)&_code_46036, _code_46036, _24344);
    DeRefDS(_24344);
    _24344 = NOVALUE;

    /** 		from_block = next_block*/
    _from_block_46032 = _next_block_46038;

    /** 		next_block = sym_block( next_block )*/
    _next_block_46038 = _53sym_block(_next_block_46038);
    if (!IS_ATOM_INT(_next_block_46038)) {
        _1 = (long)(DBL_PTR(_next_block_46038)->dbl);
        DeRefDS(_next_block_46038);
        _next_block_46038 = _1;
    }

    /** 	end while*/
    goto L1; // [90] 27
L3: 

    /** 	if length(code) then*/
    if (IS_SEQUENCE(_code_46036)){
            _24347 = SEQ_PTR(_code_46036)->length;
    }
    else {
        _24347 = 1;
    }
    if (_24347 == 0)
    {
        _24347 = NOVALUE;
        goto L4; // [98] 127
    }
    else{
        _24347 = NOVALUE;
    }

    /** 		if pc then*/
    if (_pc_46035 == 0)
    {
        goto L5; // [103] 115
    }
    else{
    }

    /** 			insert_code( code, pc )*/
    RefDS(_code_46036);
    _65insert_code(_code_46036, _pc_46035);
    goto L6; // [112] 126
L5: 

    /** 			Code &= code*/
    Concat((object_ptr)&_35Code_16332, _35Code_16332, _code_46036);
L6: 
L4: 

    /** end procedure*/
    DeRefi(_code_46036);
    DeRef(_24339);
    _24339 = NOVALUE;
    return;
    ;
}


void _66blocks_info()
{
    int _0, _1, _2;
    

    /** 	? block_stack*/
    StdPrint(1, _66block_stack_45657, 1);

    /** end procedure*/
    return;
    ;
}


int _66Least_block()
{
    int _ix_46066 = NOVALUE;
    int _sub_block_46069 = NOVALUE;
    int _24361 = NOVALUE;
    int _24360 = NOVALUE;
    int _24358 = NOVALUE;
    int _24357 = NOVALUE;
    int _24356 = NOVALUE;
    int _24355 = NOVALUE;
    int _24354 = NOVALUE;
    int _24353 = NOVALUE;
    int _24352 = NOVALUE;
    int _24351 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer ix = length( block_stack )*/
    if (IS_SEQUENCE(_66block_stack_45657)){
            _ix_46066 = SEQ_PTR(_66block_stack_45657)->length;
    }
    else {
        _ix_46066 = 1;
    }

    /** 	symtab_index sub_block = sym_block( CurrentSub )*/
    _sub_block_46069 = _53sym_block(_35CurrentSub_16252);
    if (!IS_ATOM_INT(_sub_block_46069)) {
        _1 = (long)(DBL_PTR(_sub_block_46069)->dbl);
        DeRefDS(_sub_block_46069);
        _sub_block_46069 = _1;
    }

    /** 	while not length( block_stack[ix][BLOCK_VARS] ) */
L1: 
    _2 = (int)SEQ_PTR(_66block_stack_45657);
    _24351 = (int)*(((s1_ptr)_2)->base + _ix_46066);
    _2 = (int)SEQ_PTR(_24351);
    _24352 = (int)*(((s1_ptr)_2)->base + 6);
    _24351 = NOVALUE;
    if (IS_SEQUENCE(_24352)){
            _24353 = SEQ_PTR(_24352)->length;
    }
    else {
        _24353 = 1;
    }
    _24352 = NOVALUE;
    _24354 = (_24353 == 0);
    _24353 = NOVALUE;
    if (_24354 == 0) {
        goto L2; // [39] 72
    }
    _2 = (int)SEQ_PTR(_66block_stack_45657);
    _24356 = (int)*(((s1_ptr)_2)->base + _ix_46066);
    _2 = (int)SEQ_PTR(_24356);
    _24357 = (int)*(((s1_ptr)_2)->base + 1);
    _24356 = NOVALUE;
    if (IS_ATOM_INT(_24357)) {
        _24358 = (_24357 != _sub_block_46069);
    }
    else {
        _24358 = binary_op(NOTEQ, _24357, _sub_block_46069);
    }
    _24357 = NOVALUE;
    if (_24358 <= 0) {
        if (_24358 == 0) {
            DeRef(_24358);
            _24358 = NOVALUE;
            goto L2; // [58] 72
        }
        else {
            if (!IS_ATOM_INT(_24358) && DBL_PTR(_24358)->dbl == 0.0){
                DeRef(_24358);
                _24358 = NOVALUE;
                goto L2; // [58] 72
            }
            DeRef(_24358);
            _24358 = NOVALUE;
        }
    }
    DeRef(_24358);
    _24358 = NOVALUE;

    /** 		ix -= 1	*/
    _ix_46066 = _ix_46066 - 1;

    /** 	end while*/
    goto L1; // [69] 23
L2: 

    /** 	return block_stack[ix][BLOCK_SYM]*/
    _2 = (int)SEQ_PTR(_66block_stack_45657);
    _24360 = (int)*(((s1_ptr)_2)->base + _ix_46066);
    _2 = (int)SEQ_PTR(_24360);
    _24361 = (int)*(((s1_ptr)_2)->base + 1);
    _24360 = NOVALUE;
    Ref(_24361);
    _24352 = NOVALUE;
    DeRef(_24354);
    _24354 = NOVALUE;
    return _24361;
    ;
}



// 0x0E6A58AB
