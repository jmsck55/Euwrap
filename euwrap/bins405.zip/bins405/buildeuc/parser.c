// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

void _39EndLineTable()
{
    int _0, _1, _2;
    

    /** 	LineTable = append(LineTable, -2)*/
    Append(&_35LineTable_16333, _35LineTable_16333, -2);

    /** end procedure*/
    return;
    ;
}


void _39CreateTopLevel()
{
    int _27903 = NOVALUE;
    int _27901 = NOVALUE;
    int _27899 = NOVALUE;
    int _27897 = NOVALUE;
    int _27895 = NOVALUE;
    int _27893 = NOVALUE;
    int _27891 = NOVALUE;
    int _27889 = NOVALUE;
    int _27887 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	SymTab[TopLevelSub][S_NUM_ARGS] = 0*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_35TopLevelSub_16251 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35S_NUM_ARGS_15968))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NUM_ARGS_15968)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _35S_NUM_ARGS_15968);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _27887 = NOVALUE;

    /** 	SymTab[TopLevelSub][S_TEMPS] = 0*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_35TopLevelSub_16251 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35S_TEMPS_15962))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TEMPS_15962)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _35S_TEMPS_15962);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _27889 = NOVALUE;

    /** 	SymTab[TopLevelSub][S_CODE] = {}*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_35TopLevelSub_16251 + ((s1_ptr)_2)->base);
    RefDS(_22023);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35S_CODE_15929))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_CODE_15929)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _35S_CODE_15929);
    _1 = *(int *)_2;
    *(int *)_2 = _22023;
    DeRef(_1);
    _27891 = NOVALUE;

    /** 	SymTab[TopLevelSub][S_LINETAB] = {}*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_35TopLevelSub_16251 + ((s1_ptr)_2)->base);
    RefDS(_22023);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35S_LINETAB_15952))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_LINETAB_15952)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _35S_LINETAB_15952);
    _1 = *(int *)_2;
    *(int *)_2 = _22023;
    DeRef(_1);
    _27893 = NOVALUE;

    /** 	SymTab[TopLevelSub][S_FIRSTLINE] = 1*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_35TopLevelSub_16251 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35S_FIRSTLINE_15957))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FIRSTLINE_15957)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _35S_FIRSTLINE_15957);
    _1 = *(int *)_2;
    *(int *)_2 = 1;
    DeRef(_1);
    _27895 = NOVALUE;

    /** 	SymTab[TopLevelSub][S_REFLIST] = {}*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_35TopLevelSub_16251 + ((s1_ptr)_2)->base);
    RefDS(_22023);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 24);
    _1 = *(int *)_2;
    *(int *)_2 = _22023;
    DeRef(_1);
    _27897 = NOVALUE;

    /** 	SymTab[TopLevelSub][S_NREFS] = 1*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_35TopLevelSub_16251 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 12);
    _1 = *(int *)_2;
    *(int *)_2 = 1;
    DeRef(_1);
    _27899 = NOVALUE;

    /** 	SymTab[TopLevelSub][S_RESIDENT_TASK] = 1*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_35TopLevelSub_16251 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 25);
    _1 = *(int *)_2;
    *(int *)_2 = 1;
    DeRef(_1);
    _27901 = NOVALUE;

    /** 	SymTab[TopLevelSub][S_SAVED_PRIVATES] = {}*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_35TopLevelSub_16251 + ((s1_ptr)_2)->base);
    RefDS(_22023);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 26);
    _1 = *(int *)_2;
    *(int *)_2 = _22023;
    DeRef(_1);
    _27903 = NOVALUE;

    /** 	Start_block( PROC, TopLevelSub )*/
    _66Start_block(27, _35TopLevelSub_16251);

    /** end procedure*/
    return;
    ;
}


void _39CheckForUndefinedGotoLabels()
{
    int _27918 = NOVALUE;
    int _27917 = NOVALUE;
    int _27913 = NOVALUE;
    int _27911 = NOVALUE;
    int _27909 = NOVALUE;
    int _27907 = NOVALUE;
    int _27906 = NOVALUE;
    int _27905 = NOVALUE;
    int _0, _1, _2;
    

    /** 	for i = 1 to length(goto_delay) do*/
    if (IS_SEQUENCE(_35goto_delay_16354)){
            _27905 = SEQ_PTR(_35goto_delay_16354)->length;
    }
    else {
        _27905 = 1;
    }
    {
        int _i_54221;
        _i_54221 = 1;
L1: 
        if (_i_54221 > _27905){
            goto L2; // [8] 104
        }

        /** 		if not equal(goto_delay[i],"") then*/
        _2 = (int)SEQ_PTR(_35goto_delay_16354);
        _27906 = (int)*(((s1_ptr)_2)->base + _i_54221);
        if (_27906 == _22023)
        _27907 = 1;
        else if (IS_ATOM_INT(_27906) && IS_ATOM_INT(_22023))
        _27907 = 0;
        else
        _27907 = (compare(_27906, _22023) == 0);
        _27906 = NOVALUE;
        if (_27907 != 0)
        goto L3; // [27] 97
        _27907 = NOVALUE;

        /** 			line_number = goto_line[i][1] -- tell compiler the correct line number*/
        _2 = (int)SEQ_PTR(_39goto_line_54127);
        _27909 = (int)*(((s1_ptr)_2)->base + _i_54221);
        _2 = (int)SEQ_PTR(_27909);
        _35line_number_16245 = (int)*(((s1_ptr)_2)->base + 1);
        if (!IS_ATOM_INT(_35line_number_16245)){
            _35line_number_16245 = (long)DBL_PTR(_35line_number_16245)->dbl;
        }
        _27909 = NOVALUE;

        /** 			gline_number = goto_line[i][1] -- tell compiler the correct line number*/
        _2 = (int)SEQ_PTR(_39goto_line_54127);
        _27911 = (int)*(((s1_ptr)_2)->base + _i_54221);
        _2 = (int)SEQ_PTR(_27911);
        _35gline_number_16249 = (int)*(((s1_ptr)_2)->base + 1);
        if (!IS_ATOM_INT(_35gline_number_16249)){
            _35gline_number_16249 = (long)DBL_PTR(_35gline_number_16249)->dbl;
        }
        _27911 = NOVALUE;

        /** 			ThisLine = goto_line[i][2] -- tell compiler the correct line number*/
        _2 = (int)SEQ_PTR(_39goto_line_54127);
        _27913 = (int)*(((s1_ptr)_2)->base + _i_54221);
        DeRef(_44ThisLine_48518);
        _2 = (int)SEQ_PTR(_27913);
        _44ThisLine_48518 = (int)*(((s1_ptr)_2)->base + 2);
        Ref(_44ThisLine_48518);
        _27913 = NOVALUE;

        /** 			bp = length(ThisLine)*/
        if (IS_SEQUENCE(_44ThisLine_48518)){
                _44bp_48522 = SEQ_PTR(_44ThisLine_48518)->length;
        }
        else {
            _44bp_48522 = 1;
        }

        /** 				CompileErr(156, {goto_delay[i]})*/
        _2 = (int)SEQ_PTR(_35goto_delay_16354);
        _27917 = (int)*(((s1_ptr)_2)->base + _i_54221);
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        Ref(_27917);
        *((int *)(_2+4)) = _27917;
        _27918 = MAKE_SEQ(_1);
        _27917 = NOVALUE;
        _44CompileErr(156, _27918, 0);
        _27918 = NOVALUE;
L3: 

        /** 	end for*/
        _i_54221 = _i_54221 + 1;
        goto L1; // [99] 15
L2: 
        ;
    }

    /** end procedure*/
    return;
    ;
}


void _39PushGoto()
{
    int _27919 = NOVALUE;
    int _0, _1, _2;
    

    /** 	goto_stack = append(goto_stack, {goto_addr, goto_list, goto_labels, goto_delay, goto_line, goto_ref, label_block, goto_init })*/
    _1 = NewS1(8);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_39goto_addr_54129);
    *((int *)(_2+4)) = _39goto_addr_54129;
    RefDS(_35goto_list_16355);
    *((int *)(_2+8)) = _35goto_list_16355;
    RefDS(_39goto_labels_54128);
    *((int *)(_2+12)) = _39goto_labels_54128;
    RefDS(_35goto_delay_16354);
    *((int *)(_2+16)) = _35goto_delay_16354;
    RefDS(_39goto_line_54127);
    *((int *)(_2+20)) = _39goto_line_54127;
    RefDS(_39goto_ref_54131);
    *((int *)(_2+24)) = _39goto_ref_54131;
    RefDS(_39label_block_54132);
    *((int *)(_2+28)) = _39label_block_54132;
    Ref(_39goto_init_54134);
    *((int *)(_2+32)) = _39goto_init_54134;
    _27919 = MAKE_SEQ(_1);
    RefDS(_27919);
    Append(&_39goto_stack_54130, _39goto_stack_54130, _27919);
    DeRefDS(_27919);
    _27919 = NOVALUE;

    /** 	goto_addr = {}*/
    RefDS(_22023);
    DeRefDS(_39goto_addr_54129);
    _39goto_addr_54129 = _22023;

    /** 	goto_list = {}*/
    RefDS(_22023);
    DeRefDS(_35goto_list_16355);
    _35goto_list_16355 = _22023;

    /** 	goto_labels = {}*/
    RefDS(_22023);
    DeRefDS(_39goto_labels_54128);
    _39goto_labels_54128 = _22023;

    /** 	goto_delay = {}*/
    RefDS(_22023);
    DeRefDS(_35goto_delay_16354);
    _35goto_delay_16354 = _22023;

    /** 	goto_line = {}*/
    RefDS(_22023);
    DeRefDS(_39goto_line_54127);
    _39goto_line_54127 = _22023;

    /** 	goto_ref = {}*/
    RefDS(_22023);
    DeRefDS(_39goto_ref_54131);
    _39goto_ref_54131 = _22023;

    /** 	label_block = {}*/
    RefDS(_22023);
    DeRefDS(_39label_block_54132);
    _39label_block_54132 = _22023;

    /** 	goto_init = map:new()*/
    _0 = _28new(690);
    DeRef(_39goto_init_54134);
    _39goto_init_54134 = _0;

    /** end procedure*/
    return;
    ;
}


void _39PopGoto()
{
    int _27946 = NOVALUE;
    int _27944 = NOVALUE;
    int _27943 = NOVALUE;
    int _27941 = NOVALUE;
    int _27940 = NOVALUE;
    int _27938 = NOVALUE;
    int _27937 = NOVALUE;
    int _27935 = NOVALUE;
    int _27934 = NOVALUE;
    int _27932 = NOVALUE;
    int _27931 = NOVALUE;
    int _27929 = NOVALUE;
    int _27928 = NOVALUE;
    int _27926 = NOVALUE;
    int _27925 = NOVALUE;
    int _27923 = NOVALUE;
    int _27922 = NOVALUE;
    int _0, _1, _2;
    

    /** 	CheckForUndefinedGotoLabels()*/
    _39CheckForUndefinedGotoLabels();

    /** 	goto_addr   = goto_stack[$][1]*/
    if (IS_SEQUENCE(_39goto_stack_54130)){
            _27922 = SEQ_PTR(_39goto_stack_54130)->length;
    }
    else {
        _27922 = 1;
    }
    _2 = (int)SEQ_PTR(_39goto_stack_54130);
    _27923 = (int)*(((s1_ptr)_2)->base + _27922);
    DeRef(_39goto_addr_54129);
    _2 = (int)SEQ_PTR(_27923);
    _39goto_addr_54129 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_39goto_addr_54129);
    _27923 = NOVALUE;

    /** 	goto_list   = goto_stack[$][2]*/
    if (IS_SEQUENCE(_39goto_stack_54130)){
            _27925 = SEQ_PTR(_39goto_stack_54130)->length;
    }
    else {
        _27925 = 1;
    }
    _2 = (int)SEQ_PTR(_39goto_stack_54130);
    _27926 = (int)*(((s1_ptr)_2)->base + _27925);
    DeRef(_35goto_list_16355);
    _2 = (int)SEQ_PTR(_27926);
    _35goto_list_16355 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_35goto_list_16355);
    _27926 = NOVALUE;

    /** 	goto_labels = goto_stack[$][3]*/
    if (IS_SEQUENCE(_39goto_stack_54130)){
            _27928 = SEQ_PTR(_39goto_stack_54130)->length;
    }
    else {
        _27928 = 1;
    }
    _2 = (int)SEQ_PTR(_39goto_stack_54130);
    _27929 = (int)*(((s1_ptr)_2)->base + _27928);
    DeRef(_39goto_labels_54128);
    _2 = (int)SEQ_PTR(_27929);
    _39goto_labels_54128 = (int)*(((s1_ptr)_2)->base + 3);
    Ref(_39goto_labels_54128);
    _27929 = NOVALUE;

    /** 	goto_delay  = goto_stack[$][4]*/
    if (IS_SEQUENCE(_39goto_stack_54130)){
            _27931 = SEQ_PTR(_39goto_stack_54130)->length;
    }
    else {
        _27931 = 1;
    }
    _2 = (int)SEQ_PTR(_39goto_stack_54130);
    _27932 = (int)*(((s1_ptr)_2)->base + _27931);
    DeRef(_35goto_delay_16354);
    _2 = (int)SEQ_PTR(_27932);
    _35goto_delay_16354 = (int)*(((s1_ptr)_2)->base + 4);
    Ref(_35goto_delay_16354);
    _27932 = NOVALUE;

    /** 	goto_line   = goto_stack[$][5]*/
    if (IS_SEQUENCE(_39goto_stack_54130)){
            _27934 = SEQ_PTR(_39goto_stack_54130)->length;
    }
    else {
        _27934 = 1;
    }
    _2 = (int)SEQ_PTR(_39goto_stack_54130);
    _27935 = (int)*(((s1_ptr)_2)->base + _27934);
    DeRef(_39goto_line_54127);
    _2 = (int)SEQ_PTR(_27935);
    _39goto_line_54127 = (int)*(((s1_ptr)_2)->base + 5);
    Ref(_39goto_line_54127);
    _27935 = NOVALUE;

    /** 	goto_ref    = goto_stack[$][6]*/
    if (IS_SEQUENCE(_39goto_stack_54130)){
            _27937 = SEQ_PTR(_39goto_stack_54130)->length;
    }
    else {
        _27937 = 1;
    }
    _2 = (int)SEQ_PTR(_39goto_stack_54130);
    _27938 = (int)*(((s1_ptr)_2)->base + _27937);
    DeRef(_39goto_ref_54131);
    _2 = (int)SEQ_PTR(_27938);
    _39goto_ref_54131 = (int)*(((s1_ptr)_2)->base + 6);
    Ref(_39goto_ref_54131);
    _27938 = NOVALUE;

    /** 	label_block = goto_stack[$][7]*/
    if (IS_SEQUENCE(_39goto_stack_54130)){
            _27940 = SEQ_PTR(_39goto_stack_54130)->length;
    }
    else {
        _27940 = 1;
    }
    _2 = (int)SEQ_PTR(_39goto_stack_54130);
    _27941 = (int)*(((s1_ptr)_2)->base + _27940);
    DeRef(_39label_block_54132);
    _2 = (int)SEQ_PTR(_27941);
    _39label_block_54132 = (int)*(((s1_ptr)_2)->base + 7);
    Ref(_39label_block_54132);
    _27941 = NOVALUE;

    /** 	goto_init   = goto_stack[$][8]*/
    if (IS_SEQUENCE(_39goto_stack_54130)){
            _27943 = SEQ_PTR(_39goto_stack_54130)->length;
    }
    else {
        _27943 = 1;
    }
    _2 = (int)SEQ_PTR(_39goto_stack_54130);
    _27944 = (int)*(((s1_ptr)_2)->base + _27943);
    DeRef(_39goto_init_54134);
    _2 = (int)SEQ_PTR(_27944);
    _39goto_init_54134 = (int)*(((s1_ptr)_2)->base + 8);
    Ref(_39goto_init_54134);
    _27944 = NOVALUE;

    /** 	goto_stack = remove( goto_stack, length( goto_stack ) )*/
    if (IS_SEQUENCE(_39goto_stack_54130)){
            _27946 = SEQ_PTR(_39goto_stack_54130)->length;
    }
    else {
        _27946 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_39goto_stack_54130);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_27946)) ? _27946 : (long)(DBL_PTR(_27946)->dbl);
        int stop = (IS_ATOM_INT(_27946)) ? _27946 : (long)(DBL_PTR(_27946)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_39goto_stack_54130), start, &_39goto_stack_54130 );
            }
            else Tail(SEQ_PTR(_39goto_stack_54130), stop+1, &_39goto_stack_54130);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_39goto_stack_54130), start, &_39goto_stack_54130);
        }
        else {
            assign_slice_seq = &assign_space;
            _39goto_stack_54130 = Remove_elements(start, stop, (SEQ_PTR(_39goto_stack_54130)->ref == 1));
        }
    }
    _27946 = NOVALUE;
    _27946 = NOVALUE;

    /** end procedure*/
    return;
    ;
}


void _39EnterTopLevel(int _end_line_table_54287)
{
    int _27961 = NOVALUE;
    int _27960 = NOVALUE;
    int _27958 = NOVALUE;
    int _27957 = NOVALUE;
    int _27955 = NOVALUE;
    int _27953 = NOVALUE;
    int _27952 = NOVALUE;
    int _27950 = NOVALUE;
    int _27948 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	if CurrentSub then*/
    if (_35CurrentSub_16252 == 0)
    {
        goto L1; // [7] 59
    }
    else{
    }

    /** 		if end_line_table then*/
    if (_end_line_table_54287 == 0)
    {
        goto L2; // [12] 58
    }
    else{
    }

    /** 			EndLineTable()*/
    _39EndLineTable();

    /** 			SymTab[CurrentSub][S_LINETAB] = LineTable*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_35CurrentSub_16252 + ((s1_ptr)_2)->base);
    RefDS(_35LineTable_16333);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35S_LINETAB_15952))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_LINETAB_15952)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _35S_LINETAB_15952);
    _1 = *(int *)_2;
    *(int *)_2 = _35LineTable_16333;
    DeRef(_1);
    _27948 = NOVALUE;

    /** 			SymTab[CurrentSub][S_CODE] = Code*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_35CurrentSub_16252 + ((s1_ptr)_2)->base);
    RefDS(_35Code_16332);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35S_CODE_15929))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_CODE_15929)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _35S_CODE_15929);
    _1 = *(int *)_2;
    *(int *)_2 = _35Code_16332;
    DeRef(_1);
    _27950 = NOVALUE;
L2: 
L1: 

    /** 	if length(goto_stack) then*/
    if (IS_SEQUENCE(_39goto_stack_54130)){
            _27952 = SEQ_PTR(_39goto_stack_54130)->length;
    }
    else {
        _27952 = 1;
    }
    if (_27952 == 0)
    {
        _27952 = NOVALUE;
        goto L3; // [66] 74
    }
    else{
        _27952 = NOVALUE;
    }

    /** 		PopGoto()*/
    _39PopGoto();
L3: 

    /** 	LineTable = SymTab[TopLevelSub][S_LINETAB]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _27953 = (int)*(((s1_ptr)_2)->base + _35TopLevelSub_16251);
    DeRef(_35LineTable_16333);
    _2 = (int)SEQ_PTR(_27953);
    if (!IS_ATOM_INT(_35S_LINETAB_15952)){
        _35LineTable_16333 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_LINETAB_15952)->dbl));
    }
    else{
        _35LineTable_16333 = (int)*(((s1_ptr)_2)->base + _35S_LINETAB_15952);
    }
    Ref(_35LineTable_16333);
    _27953 = NOVALUE;

    /** 	Code = SymTab[TopLevelSub][S_CODE]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _27955 = (int)*(((s1_ptr)_2)->base + _35TopLevelSub_16251);
    DeRef(_35Code_16332);
    _2 = (int)SEQ_PTR(_27955);
    if (!IS_ATOM_INT(_35S_CODE_15929)){
        _35Code_16332 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_CODE_15929)->dbl));
    }
    else{
        _35Code_16332 = (int)*(((s1_ptr)_2)->base + _35S_CODE_15929);
    }
    Ref(_35Code_16332);
    _27955 = NOVALUE;

    /** 	previous_op = -1*/
    _35previous_op_16342 = -1;

    /** 	CurrentSub = TopLevelSub*/
    _35CurrentSub_16252 = _35TopLevelSub_16251;

    /** 	clear_last()*/
    _41clear_last();

    /** 	if length( branch_stack ) then*/
    if (IS_SEQUENCE(_39branch_stack_54116)){
            _27957 = SEQ_PTR(_39branch_stack_54116)->length;
    }
    else {
        _27957 = 1;
    }
    if (_27957 == 0)
    {
        _27957 = NOVALUE;
        goto L4; // [137] 171
    }
    else{
        _27957 = NOVALUE;
    }

    /** 		branch_list = branch_stack[$]*/
    if (IS_SEQUENCE(_39branch_stack_54116)){
            _27958 = SEQ_PTR(_39branch_stack_54116)->length;
    }
    else {
        _27958 = 1;
    }
    DeRef(_39branch_list_54115);
    _2 = (int)SEQ_PTR(_39branch_stack_54116);
    _39branch_list_54115 = (int)*(((s1_ptr)_2)->base + _27958);
    Ref(_39branch_list_54115);

    /** 		branch_stack = tail( branch_stack )*/
    if (IS_SEQUENCE(_39branch_stack_54116)){
            _27960 = SEQ_PTR(_39branch_stack_54116)->length;
    }
    else {
        _27960 = 1;
    }
    _27961 = _27960 - 1;
    _27960 = NOVALUE;
    {
        int len = SEQ_PTR(_39branch_stack_54116)->length;
        int size = (IS_ATOM_INT(_27961)) ? _27961 : (long)(DBL_PTR(_27961)->dbl);
        if (size <= 0) {
            DeRef(_39branch_stack_54116);
            _39branch_stack_54116 = MAKE_SEQ(NewS1(0));
        }
        else if (len <= size) {
            RefDS(_39branch_stack_54116);
            DeRef(_39branch_stack_54116);
            _39branch_stack_54116 = _39branch_stack_54116;
        }
        else Tail(SEQ_PTR(_39branch_stack_54116), len-size+1, &_39branch_stack_54116);
    }
    _27961 = NOVALUE;
L4: 

    /** end procedure*/
    return;
    ;
}


void _39LeaveTopLevel()
{
    int _27966 = NOVALUE;
    int _27964 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	branch_stack = append( branch_stack, branch_list )*/
    RefDS(_39branch_list_54115);
    Append(&_39branch_stack_54116, _39branch_stack_54116, _39branch_list_54115);

    /** 	branch_list = {}*/
    RefDS(_22023);
    DeRefDS(_39branch_list_54115);
    _39branch_list_54115 = _22023;

    /** 	PushGoto()*/
    _39PushGoto();

    /** 	LastLineNumber = -1*/
    _61LastLineNumber_23900 = -1;

    /** 	SymTab[TopLevelSub][S_LINETAB] = LineTable*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_35TopLevelSub_16251 + ((s1_ptr)_2)->base);
    RefDS(_35LineTable_16333);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35S_LINETAB_15952))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_LINETAB_15952)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _35S_LINETAB_15952);
    _1 = *(int *)_2;
    *(int *)_2 = _35LineTable_16333;
    DeRef(_1);
    _27964 = NOVALUE;

    /** 	SymTab[TopLevelSub][S_CODE] = Code*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_35TopLevelSub_16251 + ((s1_ptr)_2)->base);
    RefDS(_35Code_16332);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35S_CODE_15929))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_CODE_15929)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _35S_CODE_15929);
    _1 = *(int *)_2;
    *(int *)_2 = _35Code_16332;
    DeRef(_1);
    _27966 = NOVALUE;

    /** 	LineTable = {}*/
    RefDS(_22023);
    DeRefDS(_35LineTable_16333);
    _35LineTable_16333 = _22023;

    /** 	Code = {}*/
    RefDS(_22023);
    DeRefDS(_35Code_16332);
    _35Code_16332 = _22023;

    /** 	previous_op = -1*/
    _35previous_op_16342 = -1;

    /** 	clear_last()*/
    _41clear_last();

    /** end procedure*/
    return;
    ;
}


void _39InitParser()
{
    int _0, _1, _2;
    

    /** 	goto_stack = {}*/
    RefDS(_22023);
    DeRef(_39goto_stack_54130);
    _39goto_stack_54130 = _22023;

    /** 	goto_labels = {}*/
    RefDS(_22023);
    DeRef(_39goto_labels_54128);
    _39goto_labels_54128 = _22023;

    /** 	label_block = {}*/
    RefDS(_22023);
    DeRef(_39label_block_54132);
    _39label_block_54132 = _22023;

    /** 	goto_ref = {}*/
    RefDS(_22023);
    DeRef(_39goto_ref_54131);
    _39goto_ref_54131 = _22023;

    /** 	goto_addr = {}*/
    RefDS(_22023);
    DeRef(_39goto_addr_54129);
    _39goto_addr_54129 = _22023;

    /** 	goto_line = {}*/
    RefDS(_22023);
    DeRef(_39goto_line_54127);
    _39goto_line_54127 = _22023;

    /** 	break_list = {}*/
    RefDS(_22023);
    DeRefi(_39break_list_54135);
    _39break_list_54135 = _22023;

    /** 	break_delay = {}*/
    RefDS(_22023);
    DeRef(_39break_delay_54136);
    _39break_delay_54136 = _22023;

    /** 	exit_list = {}*/
    RefDS(_22023);
    DeRefi(_39exit_list_54137);
    _39exit_list_54137 = _22023;

    /** 	exit_delay = {}*/
    RefDS(_22023);
    DeRef(_39exit_delay_54138);
    _39exit_delay_54138 = _22023;

    /** 	continue_list = {}*/
    RefDS(_22023);
    DeRefi(_39continue_list_54139);
    _39continue_list_54139 = _22023;

    /** 	continue_delay = {}*/
    RefDS(_22023);
    DeRef(_39continue_delay_54140);
    _39continue_delay_54140 = _22023;

    /** 	init_stack = {}*/
    RefDS(_22023);
    DeRefi(_39init_stack_54150);
    _39init_stack_54150 = _22023;

    /** 	CurrentSub = 0*/
    _35CurrentSub_16252 = 0;

    /** 	CreateTopLevel()*/
    _39CreateTopLevel();

    /** 	EnterTopLevel()*/
    _39EnterTopLevel(1);

    /** 	backed_up_tok = {}*/
    RefDS(_22023);
    DeRef(_39backed_up_tok_54124);
    _39backed_up_tok_54124 = _22023;

    /** 	loop_stack = {}*/
    RefDS(_22023);
    DeRefi(_39loop_stack_54151);
    _39loop_stack_54151 = _22023;

    /** 	stmt_nest = 0*/
    _39stmt_nest_54149 = 0;

    /** 	loop_labels = {}*/
    RefDS(_22023);
    DeRef(_39loop_labels_54145);
    _39loop_labels_54145 = _22023;

    /** 	if_labels = {}*/
    RefDS(_22023);
    DeRef(_39if_labels_54146);
    _39if_labels_54146 = _22023;

    /** 	if_stack = {}*/
    RefDS(_22023);
    DeRefi(_39if_stack_54152);
    _39if_stack_54152 = _22023;

    /** 	continue_addr = {}*/
    RefDS(_22023);
    DeRefi(_39continue_addr_54142);
    _39continue_addr_54142 = _22023;

    /** 	retry_addr = {}*/
    RefDS(_22023);
    DeRefi(_39retry_addr_54143);
    _39retry_addr_54143 = _22023;

    /** 	entry_addr = {}*/
    RefDS(_22023);
    DeRefi(_39entry_addr_54141);
    _39entry_addr_54141 = _22023;

    /** 	block_list = {}*/
    RefDS(_22023);
    DeRefi(_39block_list_54147);
    _39block_list_54147 = _22023;

    /** 	block_index = 0*/
    _39block_index_54148 = 0;

    /** 	param_num = -1*/
    _39param_num_54126 = -1;

    /** 	entry_stack = {}*/
    RefDS(_22023);
    DeRef(_39entry_stack_54144);
    _39entry_stack_54144 = _22023;

    /** 	goto_init = map:new()*/
    _0 = _28new(690);
    DeRef(_39goto_init_54134);
    _39goto_init_54134 = _0;

    /** end procedure*/
    return;
    ;
}


void _39NotReached(int _tok_54361, int _keyword_54362)
{
    int _27982 = NOVALUE;
    int _27981 = NOVALUE;
    int _27980 = NOVALUE;
    int _27979 = NOVALUE;
    int _27978 = NOVALUE;
    int _27977 = NOVALUE;
    int _27975 = NOVALUE;
    int _27974 = NOVALUE;
    int _27973 = NOVALUE;
    int _27972 = NOVALUE;
    int _27970 = NOVALUE;
    int _27969 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_tok_54361)) {
        _1 = (long)(DBL_PTR(_tok_54361)->dbl);
        DeRefDS(_tok_54361);
        _tok_54361 = _1;
    }

    /** 	if not find(tok, {END, ELSE, ELSIF, END_OF_FILE, CASE, IFDEF, ELSIFDEF, ELSEDEF}) then*/
    _1 = NewS1(8);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 402;
    *((int *)(_2+8)) = 23;
    *((int *)(_2+12)) = 414;
    *((int *)(_2+16)) = -21;
    *((int *)(_2+20)) = 186;
    *((int *)(_2+24)) = 407;
    *((int *)(_2+28)) = 408;
    *((int *)(_2+32)) = 409;
    _27969 = MAKE_SEQ(_1);
    _27970 = find_from(_tok_54361, _27969, 1);
    DeRefDS(_27969);
    _27969 = NOVALUE;
    if (_27970 != 0)
    goto L1; // [39] 135
    _27970 = NOVALUE;

    /** 		if equal(keyword, "goto") and find(tok, {LOOP, LABEL, WHILE}) then*/
    if (_keyword_54362 == _26336)
    _27972 = 1;
    else if (IS_ATOM_INT(_keyword_54362) && IS_ATOM_INT(_26336))
    _27972 = 0;
    else
    _27972 = (compare(_keyword_54362, _26336) == 0);
    if (_27972 == 0) {
        goto L2; // [48] 79
    }
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 422;
    *((int *)(_2+8)) = 419;
    *((int *)(_2+12)) = 47;
    _27974 = MAKE_SEQ(_1);
    _27975 = find_from(_tok_54361, _27974, 1);
    DeRefDS(_27974);
    _27974 = NOVALUE;
    if (_27975 == 0)
    {
        _27975 = NOVALUE;
        goto L2; // [70] 79
    }
    else{
        _27975 = NOVALUE;
    }

    /** 			return*/
    DeRefDSi(_keyword_54362);
    return;
L2: 

    /** 		if equal(keyword, "abort()") and tok = LABEL then*/
    if (_keyword_54362 == _27976)
    _27977 = 1;
    else if (IS_ATOM_INT(_keyword_54362) && IS_ATOM_INT(_27976))
    _27977 = 0;
    else
    _27977 = (compare(_keyword_54362, _27976) == 0);
    if (_27977 == 0) {
        goto L3; // [85] 105
    }
    _27979 = (_tok_54361 == 419);
    if (_27979 == 0)
    {
        DeRef(_27979);
        _27979 = NOVALUE;
        goto L3; // [96] 105
    }
    else{
        DeRef(_27979);
        _27979 = NOVALUE;
    }

    /** 			return*/
    DeRefDSi(_keyword_54362);
    return;
L3: 

    /** 		Warning(218, not_reached_warning_flag,*/
    _2 = (int)SEQ_PTR(_36known_files_15243);
    _27980 = (int)*(((s1_ptr)_2)->base + _35current_file_no_16244);
    Ref(_27980);
    _27981 = _53name_ext(_27980);
    _27980 = NOVALUE;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _27981;
    *((int *)(_2+8)) = _35line_number_16245;
    RefDS(_keyword_54362);
    *((int *)(_2+12)) = _keyword_54362;
    _27982 = MAKE_SEQ(_1);
    _27981 = NOVALUE;
    _44Warning(218, 512, _27982);
    _27982 = NOVALUE;
L1: 

    /** end procedure*/
    DeRefDSi(_keyword_54362);
    return;
    ;
}


void _39Forward_InitCheck(int _tok_54401, int _ref_54402)
{
    int _sym_54404 = NOVALUE;
    int _27988 = NOVALUE;
    int _27987 = NOVALUE;
    int _27986 = NOVALUE;
    int _27984 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if ref then*/
    if (_ref_54402 == 0)
    {
        goto L1; // [5] 83
    }
    else{
    }

    /** 		integer sym = tok[T_SYM]*/
    _2 = (int)SEQ_PTR(_tok_54401);
    _sym_54404 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_sym_54404)){
        _sym_54404 = (long)DBL_PTR(_sym_54404)->dbl;
    }

    /** 		if tok[T_ID] = QUALIFIED_VARIABLE then*/
    _2 = (int)SEQ_PTR(_tok_54401);
    _27984 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _27984, 512)){
        _27984 = NOVALUE;
        goto L2; // [28] 50
    }
    _27984 = NOVALUE;

    /** 			set_qualified_fwd( SymTab[sym][S_FILE_NO] )*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _27986 = (int)*(((s1_ptr)_2)->base + _sym_54404);
    _2 = (int)SEQ_PTR(_27986);
    if (!IS_ATOM_INT(_35S_FILE_NO_15913)){
        _27987 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FILE_NO_15913)->dbl));
    }
    else{
        _27987 = (int)*(((s1_ptr)_2)->base + _35S_FILE_NO_15913);
    }
    _27986 = NOVALUE;
    Ref(_27987);
    _61set_qualified_fwd(_27987);
    _27987 = NOVALUE;
L2: 

    /** 		ref = new_forward_reference( GLOBAL_INIT_CHECK, tok[T_SYM], GLOBAL_INIT_CHECK )*/
    _2 = (int)SEQ_PTR(_tok_54401);
    _27988 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_27988);
    _ref_54402 = _38new_forward_reference(109, _27988, 109);
    _27988 = NOVALUE;
    if (!IS_ATOM_INT(_ref_54402)) {
        _1 = (long)(DBL_PTR(_ref_54402)->dbl);
        DeRefDS(_ref_54402);
        _ref_54402 = _1;
    }

    /** 		emit_op( GLOBAL_INIT_CHECK )*/
    _41emit_op(109);

    /** 		emit_addr( sym )*/
    _41emit_addr(_sym_54404);
L1: 

    /** end procedure*/
    DeRef(_tok_54401);
    return;
    ;
}


void _39InitCheck(int _sym_54429, int _ref_54430)
{
    int _28065 = NOVALUE;
    int _28064 = NOVALUE;
    int _28063 = NOVALUE;
    int _28062 = NOVALUE;
    int _28061 = NOVALUE;
    int _28060 = NOVALUE;
    int _28059 = NOVALUE;
    int _28058 = NOVALUE;
    int _28056 = NOVALUE;
    int _28054 = NOVALUE;
    int _28053 = NOVALUE;
    int _28051 = NOVALUE;
    int _28050 = NOVALUE;
    int _28049 = NOVALUE;
    int _28048 = NOVALUE;
    int _28047 = NOVALUE;
    int _28046 = NOVALUE;
    int _28045 = NOVALUE;
    int _28044 = NOVALUE;
    int _28043 = NOVALUE;
    int _28042 = NOVALUE;
    int _28041 = NOVALUE;
    int _28040 = NOVALUE;
    int _28039 = NOVALUE;
    int _28038 = NOVALUE;
    int _28036 = NOVALUE;
    int _28035 = NOVALUE;
    int _28034 = NOVALUE;
    int _28033 = NOVALUE;
    int _28032 = NOVALUE;
    int _28031 = NOVALUE;
    int _28030 = NOVALUE;
    int _28029 = NOVALUE;
    int _28028 = NOVALUE;
    int _28026 = NOVALUE;
    int _28025 = NOVALUE;
    int _28024 = NOVALUE;
    int _28023 = NOVALUE;
    int _28022 = NOVALUE;
    int _28021 = NOVALUE;
    int _28020 = NOVALUE;
    int _28019 = NOVALUE;
    int _28018 = NOVALUE;
    int _28017 = NOVALUE;
    int _28016 = NOVALUE;
    int _28015 = NOVALUE;
    int _28014 = NOVALUE;
    int _28013 = NOVALUE;
    int _28012 = NOVALUE;
    int _28011 = NOVALUE;
    int _28010 = NOVALUE;
    int _28009 = NOVALUE;
    int _28008 = NOVALUE;
    int _28007 = NOVALUE;
    int _28006 = NOVALUE;
    int _28005 = NOVALUE;
    int _28003 = NOVALUE;
    int _28002 = NOVALUE;
    int _28001 = NOVALUE;
    int _28000 = NOVALUE;
    int _27999 = NOVALUE;
    int _27998 = NOVALUE;
    int _27997 = NOVALUE;
    int _27996 = NOVALUE;
    int _27995 = NOVALUE;
    int _27994 = NOVALUE;
    int _27993 = NOVALUE;
    int _27992 = NOVALUE;
    int _27990 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	if sym < 0 or (SymTab[sym][S_MODE] = M_NORMAL and*/
    _27990 = (_sym_54429 < 0);
    if (_27990 != 0) {
        goto L1; // [11] 90
    }
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _27992 = (int)*(((s1_ptr)_2)->base + _sym_54429);
    _2 = (int)SEQ_PTR(_27992);
    _27993 = (int)*(((s1_ptr)_2)->base + 3);
    _27992 = NOVALUE;
    if (IS_ATOM_INT(_27993)) {
        _27994 = (_27993 == 1);
    }
    else {
        _27994 = binary_op(EQUALS, _27993, 1);
    }
    _27993 = NOVALUE;
    if (IS_ATOM_INT(_27994)) {
        if (_27994 == 0) {
            _27995 = 0;
            goto L2; // [33] 59
        }
    }
    else {
        if (DBL_PTR(_27994)->dbl == 0.0) {
            _27995 = 0;
            goto L2; // [33] 59
        }
    }
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _27996 = (int)*(((s1_ptr)_2)->base + _sym_54429);
    _2 = (int)SEQ_PTR(_27996);
    _27997 = (int)*(((s1_ptr)_2)->base + 4);
    _27996 = NOVALUE;
    if (IS_ATOM_INT(_27997)) {
        _27998 = (_27997 != 2);
    }
    else {
        _27998 = binary_op(NOTEQ, _27997, 2);
    }
    _27997 = NOVALUE;
    DeRef(_27995);
    if (IS_ATOM_INT(_27998))
    _27995 = (_27998 != 0);
    else
    _27995 = DBL_PTR(_27998)->dbl != 0.0;
L2: 
    if (_27995 == 0) {
        DeRef(_27999);
        _27999 = 0;
        goto L3; // [59] 85
    }
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _28000 = (int)*(((s1_ptr)_2)->base + _sym_54429);
    _2 = (int)SEQ_PTR(_28000);
    _28001 = (int)*(((s1_ptr)_2)->base + 4);
    _28000 = NOVALUE;
    if (IS_ATOM_INT(_28001)) {
        _28002 = (_28001 != 4);
    }
    else {
        _28002 = binary_op(NOTEQ, _28001, 4);
    }
    _28001 = NOVALUE;
    if (IS_ATOM_INT(_28002))
    _27999 = (_28002 != 0);
    else
    _27999 = DBL_PTR(_28002)->dbl != 0.0;
L3: 
    if (_27999 == 0)
    {
        _27999 = NOVALUE;
        goto L4; // [86] 502
    }
    else{
        _27999 = NOVALUE;
    }
L1: 

    /** 		if sym < 0 or ((SymTab[sym][S_SCOPE] != SC_PRIVATE and*/
    _28003 = (_sym_54429 < 0);
    if (_28003 != 0) {
        goto L5; // [96] 213
    }
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _28005 = (int)*(((s1_ptr)_2)->base + _sym_54429);
    _2 = (int)SEQ_PTR(_28005);
    _28006 = (int)*(((s1_ptr)_2)->base + 4);
    _28005 = NOVALUE;
    if (IS_ATOM_INT(_28006)) {
        _28007 = (_28006 != 3);
    }
    else {
        _28007 = binary_op(NOTEQ, _28006, 3);
    }
    _28006 = NOVALUE;
    if (IS_ATOM_INT(_28007)) {
        if (_28007 == 0) {
            DeRef(_28008);
            _28008 = 0;
            goto L6; // [118] 144
        }
    }
    else {
        if (DBL_PTR(_28007)->dbl == 0.0) {
            DeRef(_28008);
            _28008 = 0;
            goto L6; // [118] 144
        }
    }
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _28009 = (int)*(((s1_ptr)_2)->base + _sym_54429);
    _2 = (int)SEQ_PTR(_28009);
    _28010 = (int)*(((s1_ptr)_2)->base + 1);
    _28009 = NOVALUE;
    if (_28010 == _35NOVALUE_16099)
    _28011 = 1;
    else if (IS_ATOM_INT(_28010) && IS_ATOM_INT(_35NOVALUE_16099))
    _28011 = 0;
    else
    _28011 = (compare(_28010, _35NOVALUE_16099) == 0);
    _28010 = NOVALUE;
    DeRef(_28008);
    _28008 = (_28011 != 0);
L6: 
    if (_28008 != 0) {
        DeRef(_28012);
        _28012 = 1;
        goto L7; // [144] 208
    }
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _28013 = (int)*(((s1_ptr)_2)->base + _sym_54429);
    _2 = (int)SEQ_PTR(_28013);
    _28014 = (int)*(((s1_ptr)_2)->base + 4);
    _28013 = NOVALUE;
    if (IS_ATOM_INT(_28014)) {
        _28015 = (_28014 == 3);
    }
    else {
        _28015 = binary_op(EQUALS, _28014, 3);
    }
    _28014 = NOVALUE;
    if (IS_ATOM_INT(_28015)) {
        if (_28015 == 0) {
            DeRef(_28016);
            _28016 = 0;
            goto L8; // [166] 204
        }
    }
    else {
        if (DBL_PTR(_28015)->dbl == 0.0) {
            DeRef(_28016);
            _28016 = 0;
            goto L8; // [166] 204
        }
    }
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _28017 = (int)*(((s1_ptr)_2)->base + _sym_54429);
    _2 = (int)SEQ_PTR(_28017);
    _28018 = (int)*(((s1_ptr)_2)->base + 16);
    _28017 = NOVALUE;
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _28019 = (int)*(((s1_ptr)_2)->base + _35CurrentSub_16252);
    _2 = (int)SEQ_PTR(_28019);
    if (!IS_ATOM_INT(_35S_NUM_ARGS_15968)){
        _28020 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NUM_ARGS_15968)->dbl));
    }
    else{
        _28020 = (int)*(((s1_ptr)_2)->base + _35S_NUM_ARGS_15968);
    }
    _28019 = NOVALUE;
    if (IS_ATOM_INT(_28018) && IS_ATOM_INT(_28020)) {
        _28021 = (_28018 >= _28020);
    }
    else {
        _28021 = binary_op(GREATEREQ, _28018, _28020);
    }
    _28018 = NOVALUE;
    _28020 = NOVALUE;
    DeRef(_28016);
    if (IS_ATOM_INT(_28021))
    _28016 = (_28021 != 0);
    else
    _28016 = DBL_PTR(_28021)->dbl != 0.0;
L8: 
    DeRef(_28012);
    _28012 = (_28016 != 0);
L7: 
    if (_28012 == 0)
    {
        _28012 = NOVALUE;
        goto L9; // [209] 566
    }
    else{
        _28012 = NOVALUE;
    }
L5: 

    /** 			if sym < 0 or (SymTab[sym][S_INITLEVEL] = -1)*/
    _28022 = (_sym_54429 < 0);
    if (_28022 != 0) {
        _28023 = 1;
        goto LA; // [219] 243
    }
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _28024 = (int)*(((s1_ptr)_2)->base + _sym_54429);
    _2 = (int)SEQ_PTR(_28024);
    _28025 = (int)*(((s1_ptr)_2)->base + 14);
    _28024 = NOVALUE;
    if (IS_ATOM_INT(_28025)) {
        _28026 = (_28025 == -1);
    }
    else {
        _28026 = binary_op(EQUALS, _28025, -1);
    }
    _28025 = NOVALUE;
    if (IS_ATOM_INT(_28026))
    _28023 = (_28026 != 0);
    else
    _28023 = DBL_PTR(_28026)->dbl != 0.0;
LA: 
    if (_28023 != 0) {
        goto LB; // [243] 270
    }
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _28028 = (int)*(((s1_ptr)_2)->base + _sym_54429);
    _2 = (int)SEQ_PTR(_28028);
    _28029 = (int)*(((s1_ptr)_2)->base + 4);
    _28028 = NOVALUE;
    if (IS_ATOM_INT(_28029)) {
        _28030 = (_28029 != 3);
    }
    else {
        _28030 = binary_op(NOTEQ, _28029, 3);
    }
    _28029 = NOVALUE;
    if (_28030 == 0) {
        DeRef(_28030);
        _28030 = NOVALUE;
        goto L9; // [266] 566
    }
    else {
        if (!IS_ATOM_INT(_28030) && DBL_PTR(_28030)->dbl == 0.0){
            DeRef(_28030);
            _28030 = NOVALUE;
            goto L9; // [266] 566
        }
        DeRef(_28030);
        _28030 = NOVALUE;
    }
    DeRef(_28030);
    _28030 = NOVALUE;
LB: 

    /** 				if ref then*/
    if (_ref_54430 == 0)
    {
        goto LC; // [272] 375
    }
    else{
    }

    /** 					if sym > 0 and (SymTab[sym][S_SCOPE] = SC_UNDEFINED) then*/
    _28031 = (_sym_54429 > 0);
    if (_28031 == 0) {
        goto LD; // [281] 317
    }
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _28033 = (int)*(((s1_ptr)_2)->base + _sym_54429);
    _2 = (int)SEQ_PTR(_28033);
    _28034 = (int)*(((s1_ptr)_2)->base + 4);
    _28033 = NOVALUE;
    if (IS_ATOM_INT(_28034)) {
        _28035 = (_28034 == 9);
    }
    else {
        _28035 = binary_op(EQUALS, _28034, 9);
    }
    _28034 = NOVALUE;
    if (_28035 == 0) {
        DeRef(_28035);
        _28035 = NOVALUE;
        goto LD; // [304] 317
    }
    else {
        if (!IS_ATOM_INT(_28035) && DBL_PTR(_28035)->dbl == 0.0){
            DeRef(_28035);
            _28035 = NOVALUE;
            goto LD; // [304] 317
        }
        DeRef(_28035);
        _28035 = NOVALUE;
    }
    DeRef(_28035);
    _28035 = NOVALUE;

    /** 						emit_op(PRIVATE_INIT_CHECK)*/
    _41emit_op(30);
    goto LE; // [314] 369
LD: 

    /** 					elsif sym < 0 or find(SymTab[sym][S_SCOPE], SCOPE_TYPES) then*/
    _28036 = (_sym_54429 < 0);
    if (_28036 != 0) {
        goto LF; // [323] 351
    }
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _28038 = (int)*(((s1_ptr)_2)->base + _sym_54429);
    _2 = (int)SEQ_PTR(_28038);
    _28039 = (int)*(((s1_ptr)_2)->base + 4);
    _28038 = NOVALUE;
    _28040 = find_from(_28039, _39SCOPE_TYPES_54108, 1);
    _28039 = NOVALUE;
    if (_28040 == 0)
    {
        _28040 = NOVALUE;
        goto L10; // [347] 361
    }
    else{
        _28040 = NOVALUE;
    }
LF: 

    /** 						emit_op(GLOBAL_INIT_CHECK) -- will become NOP2*/
    _41emit_op(109);
    goto LE; // [358] 369
L10: 

    /** 						emit_op(PRIVATE_INIT_CHECK)*/
    _41emit_op(30);
LE: 

    /** 					emit_addr(sym)*/
    _41emit_addr(_sym_54429);
LC: 

    /** 				if sym > 0 */
    _28041 = (_sym_54429 > 0);
    if (_28041 == 0) {
        _28042 = 0;
        goto L11; // [381] 411
    }
    _28043 = (_39short_circuit_54117 <= 0);
    if (_28043 != 0) {
        _28044 = 1;
        goto L12; // [391] 407
    }
    _28045 = (_39short_circuit_B_54119 == _13FALSE_434);
    _28044 = (_28045 != 0);
L12: 
    _28042 = (_28044 != 0);
L11: 
    if (_28042 == 0) {
        goto L9; // [411] 566
    }
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _28047 = (int)*(((s1_ptr)_2)->base + _sym_54429);
    _2 = (int)SEQ_PTR(_28047);
    _28048 = (int)*(((s1_ptr)_2)->base + 4);
    _28047 = NOVALUE;
    if (IS_ATOM_INT(_28048)) {
        _28049 = (_28048 != 3);
    }
    else {
        _28049 = binary_op(NOTEQ, _28048, 3);
    }
    _28048 = NOVALUE;
    if (IS_ATOM_INT(_28049)) {
        _28050 = (_28049 == 0);
    }
    else {
        _28050 = unary_op(NOT, _28049);
    }
    DeRef(_28049);
    _28049 = NOVALUE;
    if (_28050 == 0) {
        DeRef(_28050);
        _28050 = NOVALUE;
        goto L9; // [437] 566
    }
    else {
        if (!IS_ATOM_INT(_28050) && DBL_PTR(_28050)->dbl == 0.0){
            DeRef(_28050);
            _28050 = NOVALUE;
            goto L9; // [437] 566
        }
        DeRef(_28050);
        _28050 = NOVALUE;
    }
    DeRef(_28050);
    _28050 = NOVALUE;

    /** 					if CurrentSub != TopLevelSub */
    _28051 = (_35CurrentSub_16252 != _35TopLevelSub_16251);
    if (_28051 != 0) {
        goto L13; // [450] 470
    }
    if (IS_SEQUENCE(_36known_files_15243)){
            _28053 = SEQ_PTR(_36known_files_15243)->length;
    }
    else {
        _28053 = 1;
    }
    _28054 = (_35current_file_no_16244 == _28053);
    _28053 = NOVALUE;
    if (_28054 == 0)
    {
        DeRef(_28054);
        _28054 = NOVALUE;
        goto L9; // [466] 566
    }
    else{
        DeRef(_28054);
        _28054 = NOVALUE;
    }
L13: 

    /** 						init_stack = append(init_stack, sym)*/
    Append(&_39init_stack_54150, _39init_stack_54150, _sym_54429);

    /** 						SymTab[sym][S_INITLEVEL] = stmt_nest*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_54429 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 14);
    _1 = *(int *)_2;
    *(int *)_2 = _39stmt_nest_54149;
    DeRef(_1);
    _28056 = NOVALUE;
    goto L9; // [499] 566
L4: 

    /** 	elsif ref and sym > 0 and sym_mode( sym ) = M_CONSTANT and equal( NOVALUE, sym_obj( sym ) ) then*/
    if (_ref_54430 == 0) {
        _28058 = 0;
        goto L14; // [504] 516
    }
    _28059 = (_sym_54429 > 0);
    _28058 = (_28059 != 0);
L14: 
    if (_28058 == 0) {
        _28060 = 0;
        goto L15; // [516] 534
    }
    _28061 = _53sym_mode(_sym_54429);
    if (IS_ATOM_INT(_28061)) {
        _28062 = (_28061 == 2);
    }
    else {
        _28062 = binary_op(EQUALS, _28061, 2);
    }
    DeRef(_28061);
    _28061 = NOVALUE;
    if (IS_ATOM_INT(_28062))
    _28060 = (_28062 != 0);
    else
    _28060 = DBL_PTR(_28062)->dbl != 0.0;
L15: 
    if (_28060 == 0) {
        goto L16; // [534] 565
    }
    _28064 = _53sym_obj(_sym_54429);
    if (_35NOVALUE_16099 == _28064)
    _28065 = 1;
    else if (IS_ATOM_INT(_35NOVALUE_16099) && IS_ATOM_INT(_28064))
    _28065 = 0;
    else
    _28065 = (compare(_35NOVALUE_16099, _28064) == 0);
    DeRef(_28064);
    _28064 = NOVALUE;
    if (_28065 == 0)
    {
        _28065 = NOVALUE;
        goto L16; // [549] 565
    }
    else{
        _28065 = NOVALUE;
    }

    /** 		emit_op( GLOBAL_INIT_CHECK )*/
    _41emit_op(109);

    /** 		emit_addr(sym)*/
    _41emit_addr(_sym_54429);
L16: 
L9: 

    /** end procedure*/
    DeRef(_27990);
    _27990 = NOVALUE;
    DeRef(_28003);
    _28003 = NOVALUE;
    DeRef(_27994);
    _27994 = NOVALUE;
    DeRef(_27998);
    _27998 = NOVALUE;
    DeRef(_28002);
    _28002 = NOVALUE;
    DeRef(_28022);
    _28022 = NOVALUE;
    DeRef(_28007);
    _28007 = NOVALUE;
    DeRef(_28015);
    _28015 = NOVALUE;
    DeRef(_28031);
    _28031 = NOVALUE;
    DeRef(_28021);
    _28021 = NOVALUE;
    DeRef(_28026);
    _28026 = NOVALUE;
    DeRef(_28036);
    _28036 = NOVALUE;
    DeRef(_28041);
    _28041 = NOVALUE;
    DeRef(_28043);
    _28043 = NOVALUE;
    DeRef(_28045);
    _28045 = NOVALUE;
    DeRef(_28051);
    _28051 = NOVALUE;
    DeRef(_28059);
    _28059 = NOVALUE;
    DeRef(_28062);
    _28062 = NOVALUE;
    return;
    ;
}


void _39InitDelete()
{
    int _28078 = NOVALUE;
    int _28077 = NOVALUE;
    int _28075 = NOVALUE;
    int _28074 = NOVALUE;
    int _28073 = NOVALUE;
    int _28072 = NOVALUE;
    int _28071 = NOVALUE;
    int _28070 = NOVALUE;
    int _28069 = NOVALUE;
    int _28068 = NOVALUE;
    int _28067 = NOVALUE;
    int _28066 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	while length(init_stack) and*/
L1: 
    if (IS_SEQUENCE(_39init_stack_54150)){
            _28066 = SEQ_PTR(_39init_stack_54150)->length;
    }
    else {
        _28066 = 1;
    }
    if (_28066 == 0) {
        goto L2; // [11] 91
    }
    if (IS_SEQUENCE(_39init_stack_54150)){
            _28068 = SEQ_PTR(_39init_stack_54150)->length;
    }
    else {
        _28068 = 1;
    }
    _2 = (int)SEQ_PTR(_39init_stack_54150);
    _28069 = (int)*(((s1_ptr)_2)->base + _28068);
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _28070 = (int)*(((s1_ptr)_2)->base + _28069);
    _2 = (int)SEQ_PTR(_28070);
    _28071 = (int)*(((s1_ptr)_2)->base + 14);
    _28070 = NOVALUE;
    if (IS_ATOM_INT(_28071)) {
        _28072 = (_28071 > _39stmt_nest_54149);
    }
    else {
        _28072 = binary_op(GREATER, _28071, _39stmt_nest_54149);
    }
    _28071 = NOVALUE;
    if (_28072 <= 0) {
        if (_28072 == 0) {
            DeRef(_28072);
            _28072 = NOVALUE;
            goto L2; // [43] 91
        }
        else {
            if (!IS_ATOM_INT(_28072) && DBL_PTR(_28072)->dbl == 0.0){
                DeRef(_28072);
                _28072 = NOVALUE;
                goto L2; // [43] 91
            }
            DeRef(_28072);
            _28072 = NOVALUE;
        }
    }
    DeRef(_28072);
    _28072 = NOVALUE;

    /** 		SymTab[init_stack[$]][S_INITLEVEL] = -1*/
    if (IS_SEQUENCE(_39init_stack_54150)){
            _28073 = SEQ_PTR(_39init_stack_54150)->length;
    }
    else {
        _28073 = 1;
    }
    _2 = (int)SEQ_PTR(_39init_stack_54150);
    _28074 = (int)*(((s1_ptr)_2)->base + _28073);
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_28074 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 14);
    _1 = *(int *)_2;
    *(int *)_2 = -1;
    DeRef(_1);
    _28075 = NOVALUE;

    /** 		init_stack = init_stack[1..$-1]*/
    if (IS_SEQUENCE(_39init_stack_54150)){
            _28077 = SEQ_PTR(_39init_stack_54150)->length;
    }
    else {
        _28077 = 1;
    }
    _28078 = _28077 - 1;
    _28077 = NOVALUE;
    rhs_slice_target = (object_ptr)&_39init_stack_54150;
    RHS_Slice(_39init_stack_54150, 1, _28078);

    /** 	end while*/
    goto L1; // [88] 6
L2: 

    /** end procedure*/
    _28069 = NOVALUE;
    _28074 = NOVALUE;
    DeRef(_28078);
    _28078 = NOVALUE;
    return;
    ;
}


void _39emit_forward_addr()
{
    int _28080 = NOVALUE;
    int _0, _1, _2;
    

    /** 	emit_addr(0)*/
    _41emit_addr(0);

    /** 	branch_list = append(branch_list, length(Code))*/
    if (IS_SEQUENCE(_35Code_16332)){
            _28080 = SEQ_PTR(_35Code_16332)->length;
    }
    else {
        _28080 = 1;
    }
    Append(&_39branch_list_54115, _39branch_list_54115, _28080);
    _28080 = NOVALUE;

    /** end procedure*/
    return;
    ;
}


void _39StraightenBranches()
{
    int _br_54603 = NOVALUE;
    int _target_54604 = NOVALUE;
    int _28101 = NOVALUE;
    int _28100 = NOVALUE;
    int _28099 = NOVALUE;
    int _28098 = NOVALUE;
    int _28096 = NOVALUE;
    int _28095 = NOVALUE;
    int _28094 = NOVALUE;
    int _28092 = NOVALUE;
    int _28091 = NOVALUE;
    int _28090 = NOVALUE;
    int _28089 = NOVALUE;
    int _28087 = NOVALUE;
    int _28084 = NOVALUE;
    int _28083 = NOVALUE;
    int _28082 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if TRANSLATE then*/
    if (_35TRANSLATE_15887 == 0)
    {
        goto L1; // [5] 14
    }
    else{
    }

    /** 		return -- do it in back-end*/
    return;
L1: 

    /** 	for i = length(branch_list) to 1 by -1 do*/
    if (IS_SEQUENCE(_39branch_list_54115)){
            _28082 = SEQ_PTR(_39branch_list_54115)->length;
    }
    else {
        _28082 = 1;
    }
    {
        int _i_54608;
        _i_54608 = _28082;
L2: 
        if (_i_54608 < 1){
            goto L3; // [21] 170
        }

        /** 		if branch_list[i] > length(Code) then*/
        _2 = (int)SEQ_PTR(_39branch_list_54115);
        _28083 = (int)*(((s1_ptr)_2)->base + _i_54608);
        if (IS_SEQUENCE(_35Code_16332)){
                _28084 = SEQ_PTR(_35Code_16332)->length;
        }
        else {
            _28084 = 1;
        }
        if (binary_op_a(LESSEQ, _28083, _28084)){
            _28083 = NOVALUE;
            _28084 = NOVALUE;
            goto L4; // [41] 53
        }
        _28083 = NOVALUE;
        _28084 = NOVALUE;

        /** 			CompileErr("wtf")*/
        RefDS(_28086);
        RefDS(_22023);
        _44CompileErr(_28086, _22023, 0);
L4: 

        /** 		target = Code[branch_list[i]]*/
        _2 = (int)SEQ_PTR(_39branch_list_54115);
        _28087 = (int)*(((s1_ptr)_2)->base + _i_54608);
        _2 = (int)SEQ_PTR(_35Code_16332);
        if (!IS_ATOM_INT(_28087)){
            _target_54604 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_28087)->dbl));
        }
        else{
            _target_54604 = (int)*(((s1_ptr)_2)->base + _28087);
        }
        if (!IS_ATOM_INT(_target_54604)){
            _target_54604 = (long)DBL_PTR(_target_54604)->dbl;
        }

        /** 		if target <= length(Code) and target > 0 then*/
        if (IS_SEQUENCE(_35Code_16332)){
                _28089 = SEQ_PTR(_35Code_16332)->length;
        }
        else {
            _28089 = 1;
        }
        _28090 = (_target_54604 <= _28089);
        _28089 = NOVALUE;
        if (_28090 == 0) {
            goto L5; // [80] 163
        }
        _28092 = (_target_54604 > 0);
        if (_28092 == 0)
        {
            DeRef(_28092);
            _28092 = NOVALUE;
            goto L5; // [89] 163
        }
        else{
            DeRef(_28092);
            _28092 = NOVALUE;
        }

        /** 			br = Code[target]*/
        _2 = (int)SEQ_PTR(_35Code_16332);
        _br_54603 = (int)*(((s1_ptr)_2)->base + _target_54604);
        if (!IS_ATOM_INT(_br_54603)){
            _br_54603 = (long)DBL_PTR(_br_54603)->dbl;
        }

        /** 			if br = ELSE or br = ENDWHILE or br = EXIT then*/
        _28094 = (_br_54603 == 23);
        if (_28094 != 0) {
            _28095 = 1;
            goto L6; // [110] 124
        }
        _28096 = (_br_54603 == 22);
        _28095 = (_28096 != 0);
L6: 
        if (_28095 != 0) {
            goto L7; // [124] 139
        }
        _28098 = (_br_54603 == 61);
        if (_28098 == 0)
        {
            DeRef(_28098);
            _28098 = NOVALUE;
            goto L8; // [135] 162
        }
        else{
            DeRef(_28098);
            _28098 = NOVALUE;
        }
L7: 

        /** 				backpatch(branch_list[i], Code[target+1])*/
        _2 = (int)SEQ_PTR(_39branch_list_54115);
        _28099 = (int)*(((s1_ptr)_2)->base + _i_54608);
        _28100 = _target_54604 + 1;
        _2 = (int)SEQ_PTR(_35Code_16332);
        _28101 = (int)*(((s1_ptr)_2)->base + _28100);
        Ref(_28099);
        Ref(_28101);
        _41backpatch(_28099, _28101);
        _28099 = NOVALUE;
        _28101 = NOVALUE;
L8: 
L5: 

        /** 	end for*/
        _i_54608 = _i_54608 + -1;
        goto L2; // [165] 28
L3: 
        ;
    }

    /** 	branch_list = {}*/
    RefDS(_22023);
    DeRef(_39branch_list_54115);
    _39branch_list_54115 = _22023;

    /** end procedure*/
    _28087 = NOVALUE;
    DeRef(_28090);
    _28090 = NOVALUE;
    DeRef(_28094);
    _28094 = NOVALUE;
    DeRef(_28096);
    _28096 = NOVALUE;
    DeRef(_28100);
    _28100 = NOVALUE;
    return;
    ;
}


void _39PatchEList(int _base_54656)
{
    int _break_top_54657 = NOVALUE;
    int _n_54658 = NOVALUE;
    int _28118 = NOVALUE;
    int _28117 = NOVALUE;
    int _28116 = NOVALUE;
    int _28112 = NOVALUE;
    int _28111 = NOVALUE;
    int _28110 = NOVALUE;
    int _28108 = NOVALUE;
    int _28107 = NOVALUE;
    int _28105 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not length(break_list) then*/
    if (IS_SEQUENCE(_39break_list_54135)){
            _28105 = SEQ_PTR(_39break_list_54135)->length;
    }
    else {
        _28105 = 1;
    }
    if (_28105 != 0)
    goto L1; // [10] 19
    _28105 = NOVALUE;

    /** 		return*/
    return;
L1: 

    /** 	break_top = 0*/
    _break_top_54657 = 0;

    /** 	for i=length(break_list) to base+1 by -1 do*/
    if (IS_SEQUENCE(_39break_list_54135)){
            _28107 = SEQ_PTR(_39break_list_54135)->length;
    }
    else {
        _28107 = 1;
    }
    _28108 = _base_54656 + 1;
    if (_28108 > MAXINT){
        _28108 = NewDouble((double)_28108);
    }
    {
        int _i_54663;
        _i_54663 = _28107;
L2: 
        if (binary_op_a(LESS, _i_54663, _28108)){
            goto L3; // [35] 129
        }

        /** 		n=break_delay[i]*/
        _2 = (int)SEQ_PTR(_39break_delay_54136);
        if (!IS_ATOM_INT(_i_54663)){
            _n_54658 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_54663)->dbl));
        }
        else{
            _n_54658 = (int)*(((s1_ptr)_2)->base + _i_54663);
        }
        if (!IS_ATOM_INT(_n_54658))
        _n_54658 = (long)DBL_PTR(_n_54658)->dbl;

        /** 		break_delay[i] -= (n>0)*/
        _28110 = (_n_54658 > 0);
        _2 = (int)SEQ_PTR(_39break_delay_54136);
        if (!IS_ATOM_INT(_i_54663)){
            _28111 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_54663)->dbl));
        }
        else{
            _28111 = (int)*(((s1_ptr)_2)->base + _i_54663);
        }
        if (IS_ATOM_INT(_28111)) {
            _28112 = _28111 - _28110;
            if ((long)((unsigned long)_28112 +(unsigned long) HIGH_BITS) >= 0){
                _28112 = NewDouble((double)_28112);
            }
        }
        else {
            _28112 = binary_op(MINUS, _28111, _28110);
        }
        _28111 = NOVALUE;
        _28110 = NOVALUE;
        _2 = (int)SEQ_PTR(_39break_delay_54136);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _39break_delay_54136 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_i_54663))
        _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_54663)->dbl));
        else
        _2 = (int)(((s1_ptr)_2)->base + _i_54663);
        _1 = *(int *)_2;
        *(int *)_2 = _28112;
        if( _1 != _28112 ){
            DeRef(_1);
        }
        _28112 = NOVALUE;

        /** 		if n>1 then*/
        if (_n_54658 <= 1)
        goto L4; // [72] 93

        /** 			if break_top = 0 then*/
        if (_break_top_54657 != 0)
        goto L5; // [78] 122

        /** 				break_top = i*/
        Ref(_i_54663);
        _break_top_54657 = _i_54663;
        if (!IS_ATOM_INT(_break_top_54657)) {
            _1 = (long)(DBL_PTR(_break_top_54657)->dbl);
            DeRefDS(_break_top_54657);
            _break_top_54657 = _1;
        }
        goto L5; // [90] 122
L4: 

        /** 		elsif n=1 then*/
        if (_n_54658 != 1)
        goto L6; // [95] 121

        /** 			backpatch(break_list[i],length(Code)+1)*/
        _2 = (int)SEQ_PTR(_39break_list_54135);
        if (!IS_ATOM_INT(_i_54663)){
            _28116 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_54663)->dbl));
        }
        else{
            _28116 = (int)*(((s1_ptr)_2)->base + _i_54663);
        }
        if (IS_SEQUENCE(_35Code_16332)){
                _28117 = SEQ_PTR(_35Code_16332)->length;
        }
        else {
            _28117 = 1;
        }
        _28118 = _28117 + 1;
        _28117 = NOVALUE;
        _41backpatch(_28116, _28118);
        _28116 = NOVALUE;
        _28118 = NOVALUE;
L6: 
L5: 

        /** 	end for*/
        _0 = _i_54663;
        if (IS_ATOM_INT(_i_54663)) {
            _i_54663 = _i_54663 + -1;
            if ((long)((unsigned long)_i_54663 +(unsigned long) HIGH_BITS) >= 0){
                _i_54663 = NewDouble((double)_i_54663);
            }
        }
        else {
            _i_54663 = binary_op_a(PLUS, _i_54663, -1);
        }
        DeRef(_0);
        goto L2; // [124] 42
L3: 
        ;
        DeRef(_i_54663);
    }

    /** 	if break_top=0 then*/
    if (_break_top_54657 != 0)
    goto L7; // [131] 141

    /** 	    break_top=base*/
    _break_top_54657 = _base_54656;
L7: 

    /** 	break_delay = break_delay[1..break_top]*/
    rhs_slice_target = (object_ptr)&_39break_delay_54136;
    RHS_Slice(_39break_delay_54136, 1, _break_top_54657);

    /** 	break_list = break_list[1..break_top]*/
    rhs_slice_target = (object_ptr)&_39break_list_54135;
    RHS_Slice(_39break_list_54135, 1, _break_top_54657);

    /** end procedure*/
    DeRef(_28108);
    _28108 = NOVALUE;
    return;
    ;
}


void _39PatchNList(int _base_54687)
{
    int _next_top_54688 = NOVALUE;
    int _n_54689 = NOVALUE;
    int _28135 = NOVALUE;
    int _28134 = NOVALUE;
    int _28133 = NOVALUE;
    int _28129 = NOVALUE;
    int _28128 = NOVALUE;
    int _28127 = NOVALUE;
    int _28125 = NOVALUE;
    int _28124 = NOVALUE;
    int _28122 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not length(continue_list) then*/
    if (IS_SEQUENCE(_39continue_list_54139)){
            _28122 = SEQ_PTR(_39continue_list_54139)->length;
    }
    else {
        _28122 = 1;
    }
    if (_28122 != 0)
    goto L1; // [10] 19
    _28122 = NOVALUE;

    /** 		return*/
    return;
L1: 

    /** 	next_top = 0*/
    _next_top_54688 = 0;

    /** 	for i=length(continue_list) to base+1 by -1 do*/
    if (IS_SEQUENCE(_39continue_list_54139)){
            _28124 = SEQ_PTR(_39continue_list_54139)->length;
    }
    else {
        _28124 = 1;
    }
    _28125 = _base_54687 + 1;
    if (_28125 > MAXINT){
        _28125 = NewDouble((double)_28125);
    }
    {
        int _i_54694;
        _i_54694 = _28124;
L2: 
        if (binary_op_a(LESS, _i_54694, _28125)){
            goto L3; // [35] 129
        }

        /** 		n=continue_delay[i]*/
        _2 = (int)SEQ_PTR(_39continue_delay_54140);
        if (!IS_ATOM_INT(_i_54694)){
            _n_54689 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_54694)->dbl));
        }
        else{
            _n_54689 = (int)*(((s1_ptr)_2)->base + _i_54694);
        }
        if (!IS_ATOM_INT(_n_54689))
        _n_54689 = (long)DBL_PTR(_n_54689)->dbl;

        /** 		continue_delay[i] -= (n>0)*/
        _28127 = (_n_54689 > 0);
        _2 = (int)SEQ_PTR(_39continue_delay_54140);
        if (!IS_ATOM_INT(_i_54694)){
            _28128 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_54694)->dbl));
        }
        else{
            _28128 = (int)*(((s1_ptr)_2)->base + _i_54694);
        }
        if (IS_ATOM_INT(_28128)) {
            _28129 = _28128 - _28127;
            if ((long)((unsigned long)_28129 +(unsigned long) HIGH_BITS) >= 0){
                _28129 = NewDouble((double)_28129);
            }
        }
        else {
            _28129 = binary_op(MINUS, _28128, _28127);
        }
        _28128 = NOVALUE;
        _28127 = NOVALUE;
        _2 = (int)SEQ_PTR(_39continue_delay_54140);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _39continue_delay_54140 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_i_54694))
        _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_54694)->dbl));
        else
        _2 = (int)(((s1_ptr)_2)->base + _i_54694);
        _1 = *(int *)_2;
        *(int *)_2 = _28129;
        if( _1 != _28129 ){
            DeRef(_1);
        }
        _28129 = NOVALUE;

        /** 		if n>1 then*/
        if (_n_54689 <= 1)
        goto L4; // [72] 93

        /** 			if next_top = 0 then*/
        if (_next_top_54688 != 0)
        goto L5; // [78] 122

        /** 				next_top = i*/
        Ref(_i_54694);
        _next_top_54688 = _i_54694;
        if (!IS_ATOM_INT(_next_top_54688)) {
            _1 = (long)(DBL_PTR(_next_top_54688)->dbl);
            DeRefDS(_next_top_54688);
            _next_top_54688 = _1;
        }
        goto L5; // [90] 122
L4: 

        /** 		elsif n=1 then*/
        if (_n_54689 != 1)
        goto L6; // [95] 121

        /** 			backpatch(continue_list[i],length(Code)+1)*/
        _2 = (int)SEQ_PTR(_39continue_list_54139);
        if (!IS_ATOM_INT(_i_54694)){
            _28133 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_54694)->dbl));
        }
        else{
            _28133 = (int)*(((s1_ptr)_2)->base + _i_54694);
        }
        if (IS_SEQUENCE(_35Code_16332)){
                _28134 = SEQ_PTR(_35Code_16332)->length;
        }
        else {
            _28134 = 1;
        }
        _28135 = _28134 + 1;
        _28134 = NOVALUE;
        _41backpatch(_28133, _28135);
        _28133 = NOVALUE;
        _28135 = NOVALUE;
L6: 
L5: 

        /** 	end for*/
        _0 = _i_54694;
        if (IS_ATOM_INT(_i_54694)) {
            _i_54694 = _i_54694 + -1;
            if ((long)((unsigned long)_i_54694 +(unsigned long) HIGH_BITS) >= 0){
                _i_54694 = NewDouble((double)_i_54694);
            }
        }
        else {
            _i_54694 = binary_op_a(PLUS, _i_54694, -1);
        }
        DeRef(_0);
        goto L2; // [124] 42
L3: 
        ;
        DeRef(_i_54694);
    }

    /** 	if next_top=0 then*/
    if (_next_top_54688 != 0)
    goto L7; // [131] 141

    /** 	    next_top=base*/
    _next_top_54688 = _base_54687;
L7: 

    /** 	continue_delay =continue_delay[1..next_top]*/
    rhs_slice_target = (object_ptr)&_39continue_delay_54140;
    RHS_Slice(_39continue_delay_54140, 1, _next_top_54688);

    /** 	continue_list = continue_list[1..next_top]*/
    rhs_slice_target = (object_ptr)&_39continue_list_54139;
    RHS_Slice(_39continue_list_54139, 1, _next_top_54688);

    /** end procedure*/
    DeRef(_28125);
    _28125 = NOVALUE;
    return;
    ;
}


void _39PatchXList(int _base_54718)
{
    int _exit_top_54719 = NOVALUE;
    int _n_54720 = NOVALUE;
    int _28152 = NOVALUE;
    int _28151 = NOVALUE;
    int _28150 = NOVALUE;
    int _28146 = NOVALUE;
    int _28145 = NOVALUE;
    int _28144 = NOVALUE;
    int _28142 = NOVALUE;
    int _28141 = NOVALUE;
    int _28139 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not length(exit_list) then*/
    if (IS_SEQUENCE(_39exit_list_54137)){
            _28139 = SEQ_PTR(_39exit_list_54137)->length;
    }
    else {
        _28139 = 1;
    }
    if (_28139 != 0)
    goto L1; // [10] 19
    _28139 = NOVALUE;

    /** 		return*/
    return;
L1: 

    /** 	exit_top = 0*/
    _exit_top_54719 = 0;

    /** 	for i=length(exit_list) to base+1 by -1 do*/
    if (IS_SEQUENCE(_39exit_list_54137)){
            _28141 = SEQ_PTR(_39exit_list_54137)->length;
    }
    else {
        _28141 = 1;
    }
    _28142 = _base_54718 + 1;
    if (_28142 > MAXINT){
        _28142 = NewDouble((double)_28142);
    }
    {
        int _i_54725;
        _i_54725 = _28141;
L2: 
        if (binary_op_a(LESS, _i_54725, _28142)){
            goto L3; // [35] 129
        }

        /** 		n=exit_delay[i]*/
        _2 = (int)SEQ_PTR(_39exit_delay_54138);
        if (!IS_ATOM_INT(_i_54725)){
            _n_54720 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_54725)->dbl));
        }
        else{
            _n_54720 = (int)*(((s1_ptr)_2)->base + _i_54725);
        }
        if (!IS_ATOM_INT(_n_54720))
        _n_54720 = (long)DBL_PTR(_n_54720)->dbl;

        /** 		exit_delay[i] -= (n>0)*/
        _28144 = (_n_54720 > 0);
        _2 = (int)SEQ_PTR(_39exit_delay_54138);
        if (!IS_ATOM_INT(_i_54725)){
            _28145 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_54725)->dbl));
        }
        else{
            _28145 = (int)*(((s1_ptr)_2)->base + _i_54725);
        }
        if (IS_ATOM_INT(_28145)) {
            _28146 = _28145 - _28144;
            if ((long)((unsigned long)_28146 +(unsigned long) HIGH_BITS) >= 0){
                _28146 = NewDouble((double)_28146);
            }
        }
        else {
            _28146 = binary_op(MINUS, _28145, _28144);
        }
        _28145 = NOVALUE;
        _28144 = NOVALUE;
        _2 = (int)SEQ_PTR(_39exit_delay_54138);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _39exit_delay_54138 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_i_54725))
        _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_54725)->dbl));
        else
        _2 = (int)(((s1_ptr)_2)->base + _i_54725);
        _1 = *(int *)_2;
        *(int *)_2 = _28146;
        if( _1 != _28146 ){
            DeRef(_1);
        }
        _28146 = NOVALUE;

        /** 		if n>1 then*/
        if (_n_54720 <= 1)
        goto L4; // [72] 93

        /** 			if exit_top = 0 then*/
        if (_exit_top_54719 != 0)
        goto L5; // [78] 122

        /** 				exit_top = i*/
        Ref(_i_54725);
        _exit_top_54719 = _i_54725;
        if (!IS_ATOM_INT(_exit_top_54719)) {
            _1 = (long)(DBL_PTR(_exit_top_54719)->dbl);
            DeRefDS(_exit_top_54719);
            _exit_top_54719 = _1;
        }
        goto L5; // [90] 122
L4: 

        /** 		elsif n=1 then*/
        if (_n_54720 != 1)
        goto L6; // [95] 121

        /** 			backpatch(exit_list[i],length(Code)+1)*/
        _2 = (int)SEQ_PTR(_39exit_list_54137);
        if (!IS_ATOM_INT(_i_54725)){
            _28150 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_54725)->dbl));
        }
        else{
            _28150 = (int)*(((s1_ptr)_2)->base + _i_54725);
        }
        if (IS_SEQUENCE(_35Code_16332)){
                _28151 = SEQ_PTR(_35Code_16332)->length;
        }
        else {
            _28151 = 1;
        }
        _28152 = _28151 + 1;
        _28151 = NOVALUE;
        _41backpatch(_28150, _28152);
        _28150 = NOVALUE;
        _28152 = NOVALUE;
L6: 
L5: 

        /** 	end for*/
        _0 = _i_54725;
        if (IS_ATOM_INT(_i_54725)) {
            _i_54725 = _i_54725 + -1;
            if ((long)((unsigned long)_i_54725 +(unsigned long) HIGH_BITS) >= 0){
                _i_54725 = NewDouble((double)_i_54725);
            }
        }
        else {
            _i_54725 = binary_op_a(PLUS, _i_54725, -1);
        }
        DeRef(_0);
        goto L2; // [124] 42
L3: 
        ;
        DeRef(_i_54725);
    }

    /** 	if exit_top=0 then*/
    if (_exit_top_54719 != 0)
    goto L7; // [131] 141

    /** 	    exit_top=base*/
    _exit_top_54719 = _base_54718;
L7: 

    /** 	exit_delay = exit_delay [1..exit_top]*/
    rhs_slice_target = (object_ptr)&_39exit_delay_54138;
    RHS_Slice(_39exit_delay_54138, 1, _exit_top_54719);

    /** 	exit_list = exit_list [1..exit_top]*/
    rhs_slice_target = (object_ptr)&_39exit_list_54137;
    RHS_Slice(_39exit_list_54137, 1, _exit_top_54719);

    /** end procedure*/
    DeRef(_28142);
    _28142 = NOVALUE;
    return;
    ;
}


void _39putback(int _t_54750)
{
    int _28157 = NOVALUE;
    int _0, _1, _2;
    

    /** 	backed_up_tok = append(backed_up_tok, t)*/
    Ref(_t_54750);
    Append(&_39backed_up_tok_54124, _39backed_up_tok_54124, _t_54750);

    /** 	if t[T_SYM] then*/
    _2 = (int)SEQ_PTR(_t_54750);
    _28157 = (int)*(((s1_ptr)_2)->base + 2);
    if (_28157 == 0) {
        _28157 = NOVALUE;
        goto L1; // [17] 79
    }
    else {
        if (!IS_ATOM_INT(_28157) && DBL_PTR(_28157)->dbl == 0.0){
            _28157 = NOVALUE;
            goto L1; // [17] 79
        }
        _28157 = NOVALUE;
    }
    _28157 = NOVALUE;

    /** 		putback_ForwardLine     = ForwardLine*/
    Ref(_44ForwardLine_48519);
    DeRef(_44putback_ForwardLine_48520);
    _44putback_ForwardLine_48520 = _44ForwardLine_48519;

    /** 		putback_forward_bp      = forward_bp*/
    _44putback_forward_bp_48524 = _44forward_bp_48523;

    /** 		putback_fwd_line_number = fwd_line_number*/
    _35putback_fwd_line_number_16247 = _35fwd_line_number_16246;

    /** 		if last_fwd_line_number then*/
    if (_35last_fwd_line_number_16248 == 0)
    {
        goto L2; // [49] 78
    }
    else{
    }

    /** 			ForwardLine     = last_ForwardLine*/
    Ref(_44last_ForwardLine_48521);
    DeRef(_44ForwardLine_48519);
    _44ForwardLine_48519 = _44last_ForwardLine_48521;

    /** 			forward_bp      = last_forward_bp*/
    _44forward_bp_48523 = _44last_forward_bp_48525;

    /** 			fwd_line_number = last_fwd_line_number*/
    _35fwd_line_number_16246 = _35last_fwd_line_number_16248;
L2: 
L1: 

    /** end procedure*/
    DeRef(_t_54750);
    return;
    ;
}


void _39start_recording()
{
    int _0, _1, _2;
    

    /** 	psm_stack &= Parser_mode*/
    Append(&_39psm_stack_54769, _39psm_stack_54769, _35Parser_mode_16349);

    /** 	can_stack = append(can_stack,canned_tokens)*/
    Ref(_39canned_tokens_54161);
    Append(&_39can_stack_54770, _39can_stack_54770, _39canned_tokens_54161);

    /** 	idx_stack &= canned_index*/
    Append(&_39idx_stack_54771, _39idx_stack_54771, _39canned_index_54162);

    /** 	tok_stack = append(tok_stack,backed_up_tok)*/
    RefDS(_39backed_up_tok_54124);
    Append(&_39tok_stack_54772, _39tok_stack_54772, _39backed_up_tok_54124);

    /** 	canned_tokens = {}*/
    RefDS(_22023);
    DeRef(_39canned_tokens_54161);
    _39canned_tokens_54161 = _22023;

    /** 	Parser_mode = PAM_RECORD*/
    _35Parser_mode_16349 = 1;

    /** 	clear_last()*/
    _41clear_last();

    /** end procedure*/
    return;
    ;
}


int _39restore_parser()
{
    int _n_54785 = NOVALUE;
    int _tok_54786 = NOVALUE;
    int _x_54787 = NOVALUE;
    int _28188 = NOVALUE;
    int _28187 = NOVALUE;
    int _28186 = NOVALUE;
    int _28184 = NOVALUE;
    int _28180 = NOVALUE;
    int _28179 = NOVALUE;
    int _28177 = NOVALUE;
    int _28175 = NOVALUE;
    int _28174 = NOVALUE;
    int _28172 = NOVALUE;
    int _28170 = NOVALUE;
    int _28169 = NOVALUE;
    int _28167 = NOVALUE;
    int _28165 = NOVALUE;
    int _28164 = NOVALUE;
    int _28162 = NOVALUE;
    int _0, _1, _2;
    

    /** 	n=Parser_mode*/
    _n_54785 = _35Parser_mode_16349;

    /** 	x = canned_tokens*/
    Ref(_39canned_tokens_54161);
    DeRef(_x_54787);
    _x_54787 = _39canned_tokens_54161;

    /** 	canned_tokens = can_stack[$]*/
    if (IS_SEQUENCE(_39can_stack_54770)){
            _28162 = SEQ_PTR(_39can_stack_54770)->length;
    }
    else {
        _28162 = 1;
    }
    DeRef(_39canned_tokens_54161);
    _2 = (int)SEQ_PTR(_39can_stack_54770);
    _39canned_tokens_54161 = (int)*(((s1_ptr)_2)->base + _28162);
    Ref(_39canned_tokens_54161);

    /** 	can_stack     = can_stack[1..$-1]*/
    if (IS_SEQUENCE(_39can_stack_54770)){
            _28164 = SEQ_PTR(_39can_stack_54770)->length;
    }
    else {
        _28164 = 1;
    }
    _28165 = _28164 - 1;
    _28164 = NOVALUE;
    rhs_slice_target = (object_ptr)&_39can_stack_54770;
    RHS_Slice(_39can_stack_54770, 1, _28165);

    /** 	canned_index  = idx_stack[$]*/
    if (IS_SEQUENCE(_39idx_stack_54771)){
            _28167 = SEQ_PTR(_39idx_stack_54771)->length;
    }
    else {
        _28167 = 1;
    }
    _2 = (int)SEQ_PTR(_39idx_stack_54771);
    _39canned_index_54162 = (int)*(((s1_ptr)_2)->base + _28167);

    /** 	idx_stack     = idx_stack[1..$-1]*/
    if (IS_SEQUENCE(_39idx_stack_54771)){
            _28169 = SEQ_PTR(_39idx_stack_54771)->length;
    }
    else {
        _28169 = 1;
    }
    _28170 = _28169 - 1;
    _28169 = NOVALUE;
    rhs_slice_target = (object_ptr)&_39idx_stack_54771;
    RHS_Slice(_39idx_stack_54771, 1, _28170);

    /** 	Parser_mode   = psm_stack[$]*/
    if (IS_SEQUENCE(_39psm_stack_54769)){
            _28172 = SEQ_PTR(_39psm_stack_54769)->length;
    }
    else {
        _28172 = 1;
    }
    _2 = (int)SEQ_PTR(_39psm_stack_54769);
    _35Parser_mode_16349 = (int)*(((s1_ptr)_2)->base + _28172);

    /** 	psm_stack     = psm_stack[1..$-1]*/
    if (IS_SEQUENCE(_39psm_stack_54769)){
            _28174 = SEQ_PTR(_39psm_stack_54769)->length;
    }
    else {
        _28174 = 1;
    }
    _28175 = _28174 - 1;
    _28174 = NOVALUE;
    rhs_slice_target = (object_ptr)&_39psm_stack_54769;
    RHS_Slice(_39psm_stack_54769, 1, _28175);

    /** 	tok 		  = tok_stack[$]*/
    if (IS_SEQUENCE(_39tok_stack_54772)){
            _28177 = SEQ_PTR(_39tok_stack_54772)->length;
    }
    else {
        _28177 = 1;
    }
    DeRef(_tok_54786);
    _2 = (int)SEQ_PTR(_39tok_stack_54772);
    _tok_54786 = (int)*(((s1_ptr)_2)->base + _28177);
    RefDS(_tok_54786);

    /** 	tok_stack 	  = tok_stack[1..$-1]*/
    if (IS_SEQUENCE(_39tok_stack_54772)){
            _28179 = SEQ_PTR(_39tok_stack_54772)->length;
    }
    else {
        _28179 = 1;
    }
    _28180 = _28179 - 1;
    _28179 = NOVALUE;
    rhs_slice_target = (object_ptr)&_39tok_stack_54772;
    RHS_Slice(_39tok_stack_54772, 1, _28180);

    /** 	clear_last()*/
    _41clear_last();

    /** 	if n=PAM_PLAYBACK then*/
    if (_n_54785 != -1)
    goto L1; // [137] 150

    /** 		return {}*/
    RefDS(_22023);
    DeRefDS(_tok_54786);
    DeRefDS(_x_54787);
    _28165 = NOVALUE;
    _28170 = NOVALUE;
    _28175 = NOVALUE;
    _28180 = NOVALUE;
    return _22023;
    goto L2; // [147] 167
L1: 

    /** 	elsif n = PAM_NORMAL then*/
    if (_n_54785 != 0)
    goto L3; // [154] 166

    /** 		use_private_list = 0*/
    _35use_private_list_16357 = 0;
L3: 
L2: 

    /** 	if length(backed_up_tok) > 0 then*/
    if (IS_SEQUENCE(_39backed_up_tok_54124)){
            _28184 = SEQ_PTR(_39backed_up_tok_54124)->length;
    }
    else {
        _28184 = 1;
    }
    if (_28184 <= 0)
    goto L4; // [174] 199

    /** 		return x[1..$-1]*/
    if (IS_SEQUENCE(_x_54787)){
            _28186 = SEQ_PTR(_x_54787)->length;
    }
    else {
        _28186 = 1;
    }
    _28187 = _28186 - 1;
    _28186 = NOVALUE;
    rhs_slice_target = (object_ptr)&_28188;
    RHS_Slice(_x_54787, 1, _28187);
    DeRef(_tok_54786);
    DeRefDS(_x_54787);
    DeRef(_28165);
    _28165 = NOVALUE;
    DeRef(_28170);
    _28170 = NOVALUE;
    DeRef(_28175);
    _28175 = NOVALUE;
    DeRef(_28180);
    _28180 = NOVALUE;
    _28187 = NOVALUE;
    return _28188;
    goto L5; // [196] 206
L4: 

    /** 		return x*/
    DeRef(_tok_54786);
    DeRef(_28165);
    _28165 = NOVALUE;
    DeRef(_28170);
    _28170 = NOVALUE;
    DeRef(_28175);
    _28175 = NOVALUE;
    DeRef(_28180);
    _28180 = NOVALUE;
    DeRef(_28187);
    _28187 = NOVALUE;
    DeRef(_28188);
    _28188 = NOVALUE;
    return _x_54787;
L5: 
    ;
}


void _39start_playback(int _s_54827)
{
    int _0, _1, _2;
    

    /** 	psm_stack &= Parser_mode*/
    Append(&_39psm_stack_54769, _39psm_stack_54769, _35Parser_mode_16349);

    /** 	can_stack = append(can_stack,canned_tokens)*/
    Ref(_39canned_tokens_54161);
    Append(&_39can_stack_54770, _39can_stack_54770, _39canned_tokens_54161);

    /** 	idx_stack &= canned_index*/
    Append(&_39idx_stack_54771, _39idx_stack_54771, _39canned_index_54162);

    /** 	tok_stack = append(tok_stack,backed_up_tok)*/
    RefDS(_39backed_up_tok_54124);
    Append(&_39tok_stack_54772, _39tok_stack_54772, _39backed_up_tok_54124);

    /** 	canned_index = 1*/
    _39canned_index_54162 = 1;

    /** 	canned_tokens = s*/
    RefDS(_s_54827);
    DeRef(_39canned_tokens_54161);
    _39canned_tokens_54161 = _s_54827;

    /** 	backed_up_tok = {}*/
    RefDS(_22023);
    DeRefDS(_39backed_up_tok_54124);
    _39backed_up_tok_54124 = _22023;

    /** 	Parser_mode = PAM_PLAYBACK*/
    _35Parser_mode_16349 = -1;

    /** end procedure*/
    DeRefDS(_s_54827);
    return;
    ;
}


void _39restore_parseargs_states()
{
    int _s_54846 = NOVALUE;
    int _n_54847 = NOVALUE;
    int _28205 = NOVALUE;
    int _28204 = NOVALUE;
    int _28196 = NOVALUE;
    int _28195 = NOVALUE;
    int _28193 = NOVALUE;
    int _0, _1, _2;
    

    /** 	s = parseargs_states[$]*/
    if (IS_SEQUENCE(_39parseargs_states_54835)){
            _28193 = SEQ_PTR(_39parseargs_states_54835)->length;
    }
    else {
        _28193 = 1;
    }
    DeRef(_s_54846);
    _2 = (int)SEQ_PTR(_39parseargs_states_54835);
    _s_54846 = (int)*(((s1_ptr)_2)->base + _28193);
    RefDS(_s_54846);

    /** 	parseargs_states = parseargs_states[1..$-1]*/
    if (IS_SEQUENCE(_39parseargs_states_54835)){
            _28195 = SEQ_PTR(_39parseargs_states_54835)->length;
    }
    else {
        _28195 = 1;
    }
    _28196 = _28195 - 1;
    _28195 = NOVALUE;
    rhs_slice_target = (object_ptr)&_39parseargs_states_54835;
    RHS_Slice(_39parseargs_states_54835, 1, _28196);

    /** 	n=s[PS_POSITION]*/
    _2 = (int)SEQ_PTR(_s_54846);
    _n_54847 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_n_54847))
    _n_54847 = (long)DBL_PTR(_n_54847)->dbl;

    /** 	private_list = private_list[1..n]*/
    rhs_slice_target = (object_ptr)&_39private_list_54840;
    RHS_Slice(_39private_list_54840, 1, _n_54847);

    /** 	private_sym = private_sym[1..n]*/
    rhs_slice_target = (object_ptr)&_35private_sym_16356;
    RHS_Slice(_35private_sym_16356, 1, _n_54847);

    /** 	lock_scanner = s[PS_SCAN_LOCK]*/
    _2 = (int)SEQ_PTR(_s_54846);
    _39lock_scanner_54841 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_39lock_scanner_54841))
    _39lock_scanner_54841 = (long)DBL_PTR(_39lock_scanner_54841)->dbl;

    /** 	use_private_list = s[PS_USE_LIST]*/
    _2 = (int)SEQ_PTR(_s_54846);
    _35use_private_list_16357 = (int)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_35use_private_list_16357)){
        _35use_private_list_16357 = (long)DBL_PTR(_35use_private_list_16357)->dbl;
    }

    /** 	on_arg = s[PS_ON_ARG]*/
    _2 = (int)SEQ_PTR(_s_54846);
    _39on_arg_54842 = (int)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_39on_arg_54842))
    _39on_arg_54842 = (long)DBL_PTR(_39on_arg_54842)->dbl;

    /** 	nested_calls = nested_calls[1..$-1]*/
    if (IS_SEQUENCE(_39nested_calls_54843)){
            _28204 = SEQ_PTR(_39nested_calls_54843)->length;
    }
    else {
        _28204 = 1;
    }
    _28205 = _28204 - 1;
    _28204 = NOVALUE;
    rhs_slice_target = (object_ptr)&_39nested_calls_54843;
    RHS_Slice(_39nested_calls_54843, 1, _28205);

    /** end procedure*/
    DeRefDS(_s_54846);
    _28196 = NOVALUE;
    _28205 = NOVALUE;
    return;
    ;
}


int _39read_recorded_token(int _n_54867)
{
    int _t_54869 = NOVALUE;
    int _p_54870 = NOVALUE;
    int _prev_Nne_54871 = NOVALUE;
    int _ts_54900 = NOVALUE;
    int _31658 = NOVALUE;
    int _31657 = NOVALUE;
    int _31656 = NOVALUE;
    int _31655 = NOVALUE;
    int _31654 = NOVALUE;
    int _31653 = NOVALUE;
    int _31652 = NOVALUE;
    int _31651 = NOVALUE;
    int _28279 = NOVALUE;
    int _28278 = NOVALUE;
    int _28277 = NOVALUE;
    int _28276 = NOVALUE;
    int _28272 = NOVALUE;
    int _28270 = NOVALUE;
    int _28269 = NOVALUE;
    int _28268 = NOVALUE;
    int _28267 = NOVALUE;
    int _28265 = NOVALUE;
    int _28264 = NOVALUE;
    int _28262 = NOVALUE;
    int _28261 = NOVALUE;
    int _28259 = NOVALUE;
    int _28256 = NOVALUE;
    int _28254 = NOVALUE;
    int _28252 = NOVALUE;
    int _28251 = NOVALUE;
    int _28250 = NOVALUE;
    int _28249 = NOVALUE;
    int _28246 = NOVALUE;
    int _28244 = NOVALUE;
    int _28240 = NOVALUE;
    int _28238 = NOVALUE;
    int _28236 = NOVALUE;
    int _28235 = NOVALUE;
    int _28234 = NOVALUE;
    int _28233 = NOVALUE;
    int _28232 = NOVALUE;
    int _28231 = NOVALUE;
    int _28230 = NOVALUE;
    int _28229 = NOVALUE;
    int _28228 = NOVALUE;
    int _28227 = NOVALUE;
    int _28226 = NOVALUE;
    int _28225 = NOVALUE;
    int _28223 = NOVALUE;
    int _28222 = NOVALUE;
    int _28220 = NOVALUE;
    int _28219 = NOVALUE;
    int _28218 = NOVALUE;
    int _28217 = NOVALUE;
    int _28216 = NOVALUE;
    int _28215 = NOVALUE;
    int _28214 = NOVALUE;
    int _28213 = NOVALUE;
    int _28210 = NOVALUE;
    int _28208 = NOVALUE;
    int _28207 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_n_54867)) {
        _1 = (long)(DBL_PTR(_n_54867)->dbl);
        DeRefDS(_n_54867);
        _n_54867 = _1;
    }

    /** 	integer p, prev_Nne*/

    /** 	if atom(Ns_recorded[n]) label "top if" then*/
    _2 = (int)SEQ_PTR(_35Ns_recorded_16351);
    _28207 = (int)*(((s1_ptr)_2)->base + _n_54867);
    _28208 = IS_ATOM(_28207);
    _28207 = NOVALUE;
    if (_28208 == 0)
    {
        _28208 = NOVALUE;
        goto L1; // [16] 403
    }
    else{
        _28208 = NOVALUE;
    }

    /** 		if use_private_list then*/
    if (_35use_private_list_16357 == 0)
    {
        goto L2; // [23] 171
    }
    else{
    }

    /** 			p = find( Recorded[n], private_list)*/
    _2 = (int)SEQ_PTR(_35Recorded_16350);
    _28210 = (int)*(((s1_ptr)_2)->base + _n_54867);
    _p_54870 = find_from(_28210, _39private_list_54840, 1);
    _28210 = NOVALUE;

    /** 			if p > 0 then -- the value of this parameter is known, use it*/
    if (_p_54870 <= 0)
    goto L3; // [43] 170

    /** 				if TRANSLATE*/
    if (_35TRANSLATE_15887 == 0) {
        goto L4; // [51] 150
    }
    _2 = (int)SEQ_PTR(_35private_sym_16356);
    _28214 = (int)*(((s1_ptr)_2)->base + _p_54870);
    if (IS_ATOM_INT(_28214)) {
        _28215 = (_28214 < 0);
    }
    else {
        _28215 = binary_op(LESS, _28214, 0);
    }
    _28214 = NOVALUE;
    if (IS_ATOM_INT(_28215)) {
        if (_28215 != 0) {
            _28216 = 1;
            goto L5; // [65] 97
        }
    }
    else {
        if (DBL_PTR(_28215)->dbl != 0.0) {
            _28216 = 1;
            goto L5; // [65] 97
        }
    }
    _2 = (int)SEQ_PTR(_35private_sym_16356);
    _28217 = (int)*(((s1_ptr)_2)->base + _p_54870);
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!IS_ATOM_INT(_28217)){
        _28218 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_28217)->dbl));
    }
    else{
        _28218 = (int)*(((s1_ptr)_2)->base + _28217);
    }
    _2 = (int)SEQ_PTR(_28218);
    _28219 = (int)*(((s1_ptr)_2)->base + 3);
    _28218 = NOVALUE;
    if (IS_ATOM_INT(_28219)) {
        _28220 = (_28219 == 3);
    }
    else {
        _28220 = binary_op(EQUALS, _28219, 3);
    }
    _28219 = NOVALUE;
    DeRef(_28216);
    if (IS_ATOM_INT(_28220))
    _28216 = (_28220 != 0);
    else
    _28216 = DBL_PTR(_28220)->dbl != 0.0;
L5: 
    if (_28216 == 0)
    {
        _28216 = NOVALUE;
        goto L4; // [98] 150
    }
    else{
        _28216 = NOVALUE;
    }

    /** 					symtab_index ts = NewTempSym()*/
    _ts_54900 = _53NewTempSym(0);
    if (!IS_ATOM_INT(_ts_54900)) {
        _1 = (long)(DBL_PTR(_ts_54900)->dbl);
        DeRefDS(_ts_54900);
        _ts_54900 = _1;
    }

    /** 					Code &= { ASSIGN, private_sym[p], ts }*/
    _2 = (int)SEQ_PTR(_35private_sym_16356);
    _28222 = (int)*(((s1_ptr)_2)->base + _p_54870);
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 18;
    Ref(_28222);
    *((int *)(_2+8)) = _28222;
    *((int *)(_2+12)) = _ts_54900;
    _28223 = MAKE_SEQ(_1);
    _28222 = NOVALUE;
    Concat((object_ptr)&_35Code_16332, _35Code_16332, _28223);
    DeRefDS(_28223);
    _28223 = NOVALUE;

    /** 					return {VARIABLE, ts}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -100;
    ((int *)_2)[2] = _ts_54900;
    _28225 = MAKE_SEQ(_1);
    DeRef(_t_54869);
    _28217 = NOVALUE;
    DeRef(_28215);
    _28215 = NOVALUE;
    DeRef(_28220);
    _28220 = NOVALUE;
    return _28225;
    goto L6; // [147] 169
L4: 

    /** 					return {VARIABLE, private_sym[p]}*/
    _2 = (int)SEQ_PTR(_35private_sym_16356);
    _28226 = (int)*(((s1_ptr)_2)->base + _p_54870);
    Ref(_28226);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -100;
    ((int *)_2)[2] = _28226;
    _28227 = MAKE_SEQ(_1);
    _28226 = NOVALUE;
    DeRef(_t_54869);
    _28217 = NOVALUE;
    DeRef(_28215);
    _28215 = NOVALUE;
    DeRef(_28225);
    _28225 = NOVALUE;
    DeRef(_28220);
    _28220 = NOVALUE;
    return _28227;
L6: 
L3: 
L2: 

    /** 		prev_Nne = No_new_entry*/
    _prev_Nne_54871 = _53No_new_entry_47263;

    /** 		No_new_entry = 1*/
    _53No_new_entry_47263 = 1;

    /** 		if Recorded_sym[n] > 0 and  sym_scope( Recorded_sym[n] ) != SC_UNDEFINED then*/
    _2 = (int)SEQ_PTR(_35Recorded_sym_16352);
    _28228 = (int)*(((s1_ptr)_2)->base + _n_54867);
    if (IS_ATOM_INT(_28228)) {
        _28229 = (_28228 > 0);
    }
    else {
        _28229 = binary_op(GREATER, _28228, 0);
    }
    _28228 = NOVALUE;
    if (IS_ATOM_INT(_28229)) {
        if (_28229 == 0) {
            goto L7; // [199] 250
        }
    }
    else {
        if (DBL_PTR(_28229)->dbl == 0.0) {
            goto L7; // [199] 250
        }
    }
    _2 = (int)SEQ_PTR(_35Recorded_sym_16352);
    _28231 = (int)*(((s1_ptr)_2)->base + _n_54867);
    Ref(_28231);
    _28232 = _53sym_scope(_28231);
    _28231 = NOVALUE;
    if (IS_ATOM_INT(_28232)) {
        _28233 = (_28232 != 9);
    }
    else {
        _28233 = binary_op(NOTEQ, _28232, 9);
    }
    DeRef(_28232);
    _28232 = NOVALUE;
    if (_28233 == 0) {
        DeRef(_28233);
        _28233 = NOVALUE;
        goto L7; // [220] 250
    }
    else {
        if (!IS_ATOM_INT(_28233) && DBL_PTR(_28233)->dbl == 0.0){
            DeRef(_28233);
            _28233 = NOVALUE;
            goto L7; // [220] 250
        }
        DeRef(_28233);
        _28233 = NOVALUE;
    }
    DeRef(_28233);
    _28233 = NOVALUE;

    /** 			t = { sym_token( Recorded_sym[n] ), Recorded_sym[n] }*/
    _2 = (int)SEQ_PTR(_35Recorded_sym_16352);
    _28234 = (int)*(((s1_ptr)_2)->base + _n_54867);
    Ref(_28234);
    _28235 = _53sym_token(_28234);
    _28234 = NOVALUE;
    _2 = (int)SEQ_PTR(_35Recorded_sym_16352);
    _28236 = (int)*(((s1_ptr)_2)->base + _n_54867);
    Ref(_28236);
    DeRef(_t_54869);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _28235;
    ((int *)_2)[2] = _28236;
    _t_54869 = MAKE_SEQ(_1);
    _28236 = NOVALUE;
    _28235 = NOVALUE;

    /** 			break "top if"*/
    goto L8; // [247] 728
L7: 

    /** 		t = keyfind(Recorded[n],-1)*/
    _2 = (int)SEQ_PTR(_35Recorded_16350);
    _28238 = (int)*(((s1_ptr)_2)->base + _n_54867);
    RefDS(_28238);
    DeRef(_31657);
    _31657 = _28238;
    _31658 = _53hashfn(_31657);
    _31657 = NOVALUE;
    RefDS(_28238);
    _0 = _t_54869;
    _t_54869 = _53keyfind(_28238, -1, _35current_file_no_16244, 0, _31658);
    DeRef(_0);
    _28238 = NOVALUE;
    _31658 = NOVALUE;

    /** 		if t[T_ID] = IGNORED then*/
    _2 = (int)SEQ_PTR(_t_54869);
    _28240 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28240, 509)){
        _28240 = NOVALUE;
        goto L8; // [286] 728
    }
    _28240 = NOVALUE;

    /** 	        p = Recorded_sym[n]*/
    _2 = (int)SEQ_PTR(_35Recorded_sym_16352);
    _p_54870 = (int)*(((s1_ptr)_2)->base + _n_54867);
    if (!IS_ATOM_INT(_p_54870)){
        _p_54870 = (long)DBL_PTR(_p_54870)->dbl;
    }

    /** 	        if p = 0 then*/
    if (_p_54870 != 0)
    goto L9; // [302] 380

    /** 				No_new_entry = 0*/
    _53No_new_entry_47263 = 0;

    /** 				t = keyfind( Recorded[n], -1 )*/
    _2 = (int)SEQ_PTR(_35Recorded_16350);
    _28244 = (int)*(((s1_ptr)_2)->base + _n_54867);
    RefDS(_28244);
    DeRef(_31655);
    _31655 = _28244;
    _31656 = _53hashfn(_31655);
    _31655 = NOVALUE;
    RefDS(_28244);
    _0 = _t_54869;
    _t_54869 = _53keyfind(_28244, -1, _35current_file_no_16244, 0, _31656);
    DeRef(_0);
    _28244 = NOVALUE;
    _31656 = NOVALUE;

    /** 				No_new_entry = 1*/
    _53No_new_entry_47263 = 1;

    /** 				if t[T_ID] = IGNORED then*/
    _2 = (int)SEQ_PTR(_t_54869);
    _28246 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28246, 509)){
        _28246 = NOVALUE;
        goto L8; // [355] 728
    }
    _28246 = NOVALUE;

    /** 					CompileErr(157,{Recorded[n]})*/
    _2 = (int)SEQ_PTR(_35Recorded_16350);
    _28249 = (int)*(((s1_ptr)_2)->base + _n_54867);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_28249);
    *((int *)(_2+4)) = _28249;
    _28250 = MAKE_SEQ(_1);
    _28249 = NOVALUE;
    _44CompileErr(157, _28250, 0);
    _28250 = NOVALUE;
    goto L8; // [377] 728
L9: 

    /** 				t = {SymTab[p][S_TOKEN], p}*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _28251 = (int)*(((s1_ptr)_2)->base + _p_54870);
    _2 = (int)SEQ_PTR(_28251);
    if (!IS_ATOM_INT(_35S_TOKEN_15922)){
        _28252 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TOKEN_15922)->dbl));
    }
    else{
        _28252 = (int)*(((s1_ptr)_2)->base + _35S_TOKEN_15922);
    }
    _28251 = NOVALUE;
    Ref(_28252);
    DeRef(_t_54869);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _28252;
    ((int *)_2)[2] = _p_54870;
    _t_54869 = MAKE_SEQ(_1);
    _28252 = NOVALUE;
    goto L8; // [400] 728
L1: 

    /** 		prev_Nne = No_new_entry*/
    _prev_Nne_54871 = _53No_new_entry_47263;

    /** 		No_new_entry = 1*/
    _53No_new_entry_47263 = 1;

    /** 		t = keyfind(Ns_recorded[n],-1, , 1)*/
    _2 = (int)SEQ_PTR(_35Ns_recorded_16351);
    _28254 = (int)*(((s1_ptr)_2)->base + _n_54867);
    Ref(_28254);
    DeRef(_31653);
    _31653 = _28254;
    _31654 = _53hashfn(_31653);
    _31653 = NOVALUE;
    Ref(_28254);
    _0 = _t_54869;
    _t_54869 = _53keyfind(_28254, -1, _35current_file_no_16244, 1, _31654);
    DeRef(_0);
    _28254 = NOVALUE;
    _31654 = NOVALUE;

    /** 		if t[T_ID] != NAMESPACE then*/
    _2 = (int)SEQ_PTR(_t_54869);
    _28256 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _28256, 523)){
        _28256 = NOVALUE;
        goto LA; // [454] 520
    }
    _28256 = NOVALUE;

    /** 			p = Ns_recorded_sym[n]*/
    _2 = (int)SEQ_PTR(_35Ns_recorded_sym_16353);
    _p_54870 = (int)*(((s1_ptr)_2)->base + _n_54867);
    if (!IS_ATOM_INT(_p_54870)){
        _p_54870 = (long)DBL_PTR(_p_54870)->dbl;
    }

    /** 			if p = 0 or sym_token( p ) != NAMESPACE then*/
    _28259 = (_p_54870 == 0);
    if (_28259 != 0) {
        goto LB; // [474] 493
    }
    _28261 = _53sym_token(_p_54870);
    if (IS_ATOM_INT(_28261)) {
        _28262 = (_28261 != 523);
    }
    else {
        _28262 = binary_op(NOTEQ, _28261, 523);
    }
    DeRef(_28261);
    _28261 = NOVALUE;
    if (_28262 == 0) {
        DeRef(_28262);
        _28262 = NOVALUE;
        goto LC; // [489] 511
    }
    else {
        if (!IS_ATOM_INT(_28262) && DBL_PTR(_28262)->dbl == 0.0){
            DeRef(_28262);
            _28262 = NOVALUE;
            goto LC; // [489] 511
        }
        DeRef(_28262);
        _28262 = NOVALUE;
    }
    DeRef(_28262);
    _28262 = NOVALUE;
LB: 

    /** 				CompileErr(153, {Ns_recorded[n]})*/
    _2 = (int)SEQ_PTR(_35Ns_recorded_16351);
    _28264 = (int)*(((s1_ptr)_2)->base + _n_54867);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_28264);
    *((int *)(_2+4)) = _28264;
    _28265 = MAKE_SEQ(_1);
    _28264 = NOVALUE;
    _44CompileErr(153, _28265, 0);
    _28265 = NOVALUE;
LC: 

    /** 			t = {NAMESPACE, p}*/
    DeRef(_t_54869);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 523;
    ((int *)_2)[2] = _p_54870;
    _t_54869 = MAKE_SEQ(_1);
LA: 

    /** 		t = keyfind(Recorded[n],SymTab[t[T_SYM]][S_OBJ])*/
    _2 = (int)SEQ_PTR(_35Recorded_16350);
    _28267 = (int)*(((s1_ptr)_2)->base + _n_54867);
    _2 = (int)SEQ_PTR(_t_54869);
    _28268 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!IS_ATOM_INT(_28268)){
        _28269 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_28268)->dbl));
    }
    else{
        _28269 = (int)*(((s1_ptr)_2)->base + _28268);
    }
    _2 = (int)SEQ_PTR(_28269);
    _28270 = (int)*(((s1_ptr)_2)->base + 1);
    _28269 = NOVALUE;
    RefDS(_28267);
    DeRef(_31651);
    _31651 = _28267;
    _31652 = _53hashfn(_31651);
    _31651 = NOVALUE;
    RefDS(_28267);
    Ref(_28270);
    _0 = _t_54869;
    _t_54869 = _53keyfind(_28267, _28270, _35current_file_no_16244, 0, _31652);
    DeRef(_0);
    _28267 = NOVALUE;
    _28270 = NOVALUE;
    _31652 = NOVALUE;

    /** 		if t[T_ID] = IGNORED then*/
    _2 = (int)SEQ_PTR(_t_54869);
    _28272 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28272, 509)){
        _28272 = NOVALUE;
        goto LD; // [573] 630
    }
    _28272 = NOVALUE;

    /** 	        p = Recorded_sym[n]*/
    _2 = (int)SEQ_PTR(_35Recorded_sym_16352);
    _p_54870 = (int)*(((s1_ptr)_2)->base + _n_54867);
    if (!IS_ATOM_INT(_p_54870)){
        _p_54870 = (long)DBL_PTR(_p_54870)->dbl;
    }

    /** 	        if p = 0 then*/
    if (_p_54870 != 0)
    goto LE; // [589] 611

    /** 	        	CompileErr(157,{Recorded[n]})*/
    _2 = (int)SEQ_PTR(_35Recorded_16350);
    _28276 = (int)*(((s1_ptr)_2)->base + _n_54867);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_28276);
    *((int *)(_2+4)) = _28276;
    _28277 = MAKE_SEQ(_1);
    _28276 = NOVALUE;
    _44CompileErr(157, _28277, 0);
    _28277 = NOVALUE;
LE: 

    /** 		    t = {SymTab[p][S_TOKEN], p}*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _28278 = (int)*(((s1_ptr)_2)->base + _p_54870);
    _2 = (int)SEQ_PTR(_28278);
    if (!IS_ATOM_INT(_35S_TOKEN_15922)){
        _28279 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TOKEN_15922)->dbl));
    }
    else{
        _28279 = (int)*(((s1_ptr)_2)->base + _35S_TOKEN_15922);
    }
    _28278 = NOVALUE;
    Ref(_28279);
    DeRef(_t_54869);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _28279;
    ((int *)_2)[2] = _p_54870;
    _t_54869 = MAKE_SEQ(_1);
    _28279 = NOVALUE;
LD: 

    /** 		n = t[T_ID]*/
    _2 = (int)SEQ_PTR(_t_54869);
    _n_54867 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_n_54867)){
        _n_54867 = (long)DBL_PTR(_n_54867)->dbl;
    }

    /** 		if n = VARIABLE then*/
    if (_n_54867 != -100)
    goto LF; // [644] 660

    /** 			n = QUALIFIED_VARIABLE*/
    _n_54867 = 512;
    goto L10; // [657] 719
LF: 

    /** 		elsif n = FUNC then*/
    if (_n_54867 != 501)
    goto L11; // [664] 680

    /** 			n = QUALIFIED_FUNC*/
    _n_54867 = 520;
    goto L10; // [677] 719
L11: 

    /** 		elsif n = PROC then*/
    if (_n_54867 != 27)
    goto L12; // [684] 700

    /** 			n = QUALIFIED_PROC*/
    _n_54867 = 521;
    goto L10; // [697] 719
L12: 

    /** 		elsif n = TYPE then*/
    if (_n_54867 != 504)
    goto L13; // [704] 718

    /** 			n = QUALIFIED_TYPE*/
    _n_54867 = 522;
L13: 
L10: 

    /** 		t[T_ID] = n*/
    _2 = (int)SEQ_PTR(_t_54869);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _t_54869 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _n_54867;
    DeRef(_1);
L8: 

    /** 	No_new_entry = prev_Nne*/
    _53No_new_entry_47263 = _prev_Nne_54871;

    /**   	return t*/
    _28217 = NOVALUE;
    DeRef(_28215);
    _28215 = NOVALUE;
    DeRef(_28225);
    _28225 = NOVALUE;
    DeRef(_28220);
    _28220 = NOVALUE;
    DeRef(_28227);
    _28227 = NOVALUE;
    DeRef(_28259);
    _28259 = NOVALUE;
    DeRef(_28229);
    _28229 = NOVALUE;
    _28268 = NOVALUE;
    return _t_54869;
    ;
}


int _39next_token()
{
    int _t_55050 = NOVALUE;
    int _s_55051 = NOVALUE;
    int _28318 = NOVALUE;
    int _28317 = NOVALUE;
    int _28316 = NOVALUE;
    int _28315 = NOVALUE;
    int _28314 = NOVALUE;
    int _28313 = NOVALUE;
    int _28312 = NOVALUE;
    int _28311 = NOVALUE;
    int _28309 = NOVALUE;
    int _28308 = NOVALUE;
    int _28307 = NOVALUE;
    int _28306 = NOVALUE;
    int _28304 = NOVALUE;
    int _28302 = NOVALUE;
    int _28300 = NOVALUE;
    int _28296 = NOVALUE;
    int _28293 = NOVALUE;
    int _28290 = NOVALUE;
    int _28288 = NOVALUE;
    int _28286 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence s*/

    /** 	if length(backed_up_tok) > 0 then*/
    if (IS_SEQUENCE(_39backed_up_tok_54124)){
            _28286 = SEQ_PTR(_39backed_up_tok_54124)->length;
    }
    else {
        _28286 = 1;
    }
    if (_28286 <= 0)
    goto L1; // [10] 82

    /** 		t = backed_up_tok[$]*/
    if (IS_SEQUENCE(_39backed_up_tok_54124)){
            _28288 = SEQ_PTR(_39backed_up_tok_54124)->length;
    }
    else {
        _28288 = 1;
    }
    DeRef(_t_55050);
    _2 = (int)SEQ_PTR(_39backed_up_tok_54124);
    _t_55050 = (int)*(((s1_ptr)_2)->base + _28288);
    Ref(_t_55050);

    /** 		backed_up_tok = remove( backed_up_tok, length( backed_up_tok ) )*/
    if (IS_SEQUENCE(_39backed_up_tok_54124)){
            _28290 = SEQ_PTR(_39backed_up_tok_54124)->length;
    }
    else {
        _28290 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_39backed_up_tok_54124);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_28290)) ? _28290 : (long)(DBL_PTR(_28290)->dbl);
        int stop = (IS_ATOM_INT(_28290)) ? _28290 : (long)(DBL_PTR(_28290)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_39backed_up_tok_54124), start, &_39backed_up_tok_54124 );
            }
            else Tail(SEQ_PTR(_39backed_up_tok_54124), stop+1, &_39backed_up_tok_54124);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_39backed_up_tok_54124), start, &_39backed_up_tok_54124);
        }
        else {
            assign_slice_seq = &assign_space;
            _39backed_up_tok_54124 = Remove_elements(start, stop, (SEQ_PTR(_39backed_up_tok_54124)->ref == 1));
        }
    }
    _28290 = NOVALUE;
    _28290 = NOVALUE;

    /** 		if putback_fwd_line_number then*/
    if (_35putback_fwd_line_number_16247 == 0)
    {
        goto L2; // [43] 347
    }
    else{
    }

    /** 			ForwardLine     = putback_ForwardLine*/
    Ref(_44putback_ForwardLine_48520);
    DeRef(_44ForwardLine_48519);
    _44ForwardLine_48519 = _44putback_ForwardLine_48520;

    /** 			forward_bp      = putback_forward_bp*/
    _44forward_bp_48523 = _44putback_forward_bp_48524;

    /** 			fwd_line_number = putback_fwd_line_number*/
    _35fwd_line_number_16246 = _35putback_fwd_line_number_16247;

    /** 			putback_fwd_line_number = 0*/
    _35putback_fwd_line_number_16247 = 0;
    goto L2; // [79] 347
L1: 

    /** 	elsif Parser_mode = PAM_PLAYBACK then*/
    if (_35Parser_mode_16349 != -1)
    goto L3; // [88] 300

    /** 		if canned_index <= length(canned_tokens) then*/
    if (IS_SEQUENCE(_39canned_tokens_54161)){
            _28293 = SEQ_PTR(_39canned_tokens_54161)->length;
    }
    else {
        _28293 = 1;
    }
    if (_39canned_index_54162 > _28293)
    goto L4; // [101] 150

    /** 			t = canned_tokens[canned_index]*/
    DeRef(_t_55050);
    _2 = (int)SEQ_PTR(_39canned_tokens_54161);
    _t_55050 = (int)*(((s1_ptr)_2)->base + _39canned_index_54162);
    Ref(_t_55050);

    /** 			if canned_index < length(canned_tokens) then*/
    if (IS_SEQUENCE(_39canned_tokens_54161)){
            _28296 = SEQ_PTR(_39canned_tokens_54161)->length;
    }
    else {
        _28296 = 1;
    }
    if (_39canned_index_54162 >= _28296)
    goto L5; // [124] 139

    /** 				canned_index += 1*/
    _39canned_index_54162 = _39canned_index_54162 + 1;
    goto L6; // [136] 157
L5: 

    /** 	            s = restore_parser()*/
    _0 = _s_55051;
    _s_55051 = _39restore_parser();
    DeRef(_0);
    goto L6; // [147] 157
L4: 

    /** 	    	InternalErr(266)*/
    RefDS(_22023);
    _44InternalErr(266, _22023);
L6: 

    /** 		if t[T_ID] = RECORDED then*/
    _2 = (int)SEQ_PTR(_t_55050);
    _28300 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28300, 508)){
        _28300 = NOVALUE;
        goto L7; // [169] 188
    }
    _28300 = NOVALUE;

    /** 			t=read_recorded_token(t[T_SYM])*/
    _2 = (int)SEQ_PTR(_t_55050);
    _28302 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_28302);
    _0 = _t_55050;
    _t_55050 = _39read_recorded_token(_28302);
    DeRef(_0);
    _28302 = NOVALUE;
    goto L2; // [185] 347
L7: 

    /** 		elsif t[T_ID] = DEF_PARAM then*/
    _2 = (int)SEQ_PTR(_t_55050);
    _28304 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28304, 510)){
        _28304 = NOVALUE;
        goto L2; // [198] 347
    }
    _28304 = NOVALUE;

    /**         	for i=length(nested_calls) to 1 by -1 do*/
    if (IS_SEQUENCE(_39nested_calls_54843)){
            _28306 = SEQ_PTR(_39nested_calls_54843)->length;
    }
    else {
        _28306 = 1;
    }
    {
        int _i_55098;
        _i_55098 = _28306;
L8: 
        if (_i_55098 < 1){
            goto L9; // [209] 288
        }

        /**         	    if nested_calls[i] = t[T_SYM][2] then*/
        _2 = (int)SEQ_PTR(_39nested_calls_54843);
        _28307 = (int)*(((s1_ptr)_2)->base + _i_55098);
        _2 = (int)SEQ_PTR(_t_55050);
        _28308 = (int)*(((s1_ptr)_2)->base + 2);
        _2 = (int)SEQ_PTR(_28308);
        _28309 = (int)*(((s1_ptr)_2)->base + 2);
        _28308 = NOVALUE;
        if (binary_op_a(NOTEQ, _28307, _28309)){
            _28307 = NOVALUE;
            _28309 = NOVALUE;
            goto LA; // [234] 281
        }
        _28307 = NOVALUE;
        _28309 = NOVALUE;

        /** 					return {VARIABLE, private_sym[parseargs_states[i][PS_POSITION]+t[T_SYM][1]]}*/
        _2 = (int)SEQ_PTR(_39parseargs_states_54835);
        _28311 = (int)*(((s1_ptr)_2)->base + _i_55098);
        _2 = (int)SEQ_PTR(_28311);
        _28312 = (int)*(((s1_ptr)_2)->base + 1);
        _28311 = NOVALUE;
        _2 = (int)SEQ_PTR(_t_55050);
        _28313 = (int)*(((s1_ptr)_2)->base + 2);
        _2 = (int)SEQ_PTR(_28313);
        _28314 = (int)*(((s1_ptr)_2)->base + 1);
        _28313 = NOVALUE;
        if (IS_ATOM_INT(_28312) && IS_ATOM_INT(_28314)) {
            _28315 = _28312 + _28314;
        }
        else {
            _28315 = binary_op(PLUS, _28312, _28314);
        }
        _28312 = NOVALUE;
        _28314 = NOVALUE;
        _2 = (int)SEQ_PTR(_35private_sym_16356);
        if (!IS_ATOM_INT(_28315)){
            _28316 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_28315)->dbl));
        }
        else{
            _28316 = (int)*(((s1_ptr)_2)->base + _28315);
        }
        Ref(_28316);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = -100;
        ((int *)_2)[2] = _28316;
        _28317 = MAKE_SEQ(_1);
        _28316 = NOVALUE;
        DeRef(_t_55050);
        DeRef(_s_55051);
        DeRef(_28315);
        _28315 = NOVALUE;
        return _28317;
LA: 

        /** 			end for*/
        _i_55098 = _i_55098 + -1;
        goto L8; // [283] 216
L9: 
        ;
    }

    /** 			CompileErr(98)*/
    RefDS(_22023);
    _44CompileErr(98, _22023, 0);
    goto L2; // [297] 347
L3: 

    /** 	elsif lock_scanner then*/
    if (_39lock_scanner_54841 == 0)
    {
        goto LB; // [304] 322
    }
    else{
    }

    /** 		return {PLAYBACK_ENDS,0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 505;
    ((int *)_2)[2] = 0;
    _28318 = MAKE_SEQ(_1);
    DeRef(_t_55050);
    DeRef(_s_55051);
    DeRef(_28317);
    _28317 = NOVALUE;
    DeRef(_28315);
    _28315 = NOVALUE;
    return _28318;
    goto L2; // [319] 347
LB: 

    /** 	    t = Scanner()*/
    _0 = _t_55050;
    _t_55050 = _61Scanner();
    DeRef(_0);

    /** 	    if Parser_mode = PAM_RECORD then*/
    if (_35Parser_mode_16349 != 1)
    goto LC; // [333] 346

    /** 	        canned_tokens = append(canned_tokens,t)*/
    Ref(_t_55050);
    Append(&_39canned_tokens_54161, _39canned_tokens_54161, _t_55050);
LC: 
L2: 

    /** 	putback_fwd_line_number = 0*/
    _35putback_fwd_line_number_16247 = 0;

    /** 	return t*/
    DeRef(_s_55051);
    DeRef(_28317);
    _28317 = NOVALUE;
    DeRef(_28318);
    _28318 = NOVALUE;
    DeRef(_28315);
    _28315 = NOVALUE;
    return _t_55050;
    ;
}


int _39Expr_list()
{
    int _tok_55133 = NOVALUE;
    int _n_55134 = NOVALUE;
    int _28334 = NOVALUE;
    int _28331 = NOVALUE;
    int _28330 = NOVALUE;
    int _28328 = NOVALUE;
    int _28327 = NOVALUE;
    int _28323 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer n*/

    /** 	tok = next_token()*/
    _0 = _tok_55133;
    _tok_55133 = _39next_token();
    DeRef(_0);

    /** 	putback(tok)*/
    Ref(_tok_55133);
    _39putback(_tok_55133);

    /** 	if tok[T_ID] = RIGHT_BRACE then*/
    _2 = (int)SEQ_PTR(_tok_55133);
    _28323 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28323, -25)){
        _28323 = NOVALUE;
        goto L1; // [23] 36
    }
    _28323 = NOVALUE;

    /** 		return 0*/
    DeRef(_tok_55133);
    return 0;
    goto L2; // [33] 142
L1: 

    /** 		n = 0*/
    _n_55134 = 0;

    /** 		short_circuit -= 1*/
    _39short_circuit_54117 = _39short_circuit_54117 - 1;

    /** 		while TRUE do*/
L3: 
    if (_13TRUE_436 == 0)
    {
        goto L4; // [56] 133
    }
    else{
    }

    /** 			gListItem &= 1*/
    Append(&_39gListItem_54153, _39gListItem_54153, 1);

    /** 			Expr()*/
    _39Expr();

    /** 			n += gListItem[$]*/
    if (IS_SEQUENCE(_39gListItem_54153)){
            _28327 = SEQ_PTR(_39gListItem_54153)->length;
    }
    else {
        _28327 = 1;
    }
    _2 = (int)SEQ_PTR(_39gListItem_54153);
    _28328 = (int)*(((s1_ptr)_2)->base + _28327);
    _n_55134 = _n_55134 + _28328;
    _28328 = NOVALUE;

    /** 			gListItem = gListItem[1 .. $-1]*/
    if (IS_SEQUENCE(_39gListItem_54153)){
            _28330 = SEQ_PTR(_39gListItem_54153)->length;
    }
    else {
        _28330 = 1;
    }
    _28331 = _28330 - 1;
    _28330 = NOVALUE;
    rhs_slice_target = (object_ptr)&_39gListItem_54153;
    RHS_Slice(_39gListItem_54153, 1, _28331);

    /** 			tok = next_token()*/
    _0 = _tok_55133;
    _tok_55133 = _39next_token();
    DeRef(_0);

    /** 			if tok[T_ID] != COMMA then*/
    _2 = (int)SEQ_PTR(_tok_55133);
    _28334 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _28334, -30)){
        _28334 = NOVALUE;
        goto L3; // [119] 54
    }
    _28334 = NOVALUE;

    /** 				exit*/
    goto L4; // [125] 133

    /** 		end while*/
    goto L3; // [130] 54
L4: 

    /** 		short_circuit += 1*/
    _39short_circuit_54117 = _39short_circuit_54117 + 1;
L2: 

    /** 	putback(tok)*/
    Ref(_tok_55133);
    _39putback(_tok_55133);

    /** 	return n*/
    DeRef(_tok_55133);
    DeRef(_28331);
    _28331 = NOVALUE;
    return _n_55134;
    ;
}


void _39tok_match(int _tok_55162, int _prevtok_55163)
{
    int _t_55165 = NOVALUE;
    int _expected_55166 = NOVALUE;
    int _actual_55167 = NOVALUE;
    int _prevname_55168 = NOVALUE;
    int _28346 = NOVALUE;
    int _28344 = NOVALUE;
    int _28341 = NOVALUE;
    int _28338 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence expected, actual, prevname*/

    /** 	t = next_token()*/
    _0 = _t_55165;
    _t_55165 = _39next_token();
    DeRef(_0);

    /** 	if t[T_ID] != tok then*/
    _2 = (int)SEQ_PTR(_t_55165);
    _28338 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _28338, _tok_55162)){
        _28338 = NOVALUE;
        goto L1; // [20] 92
    }
    _28338 = NOVALUE;

    /** 		expected = LexName(tok)*/
    RefDS(_26467);
    _0 = _expected_55166;
    _expected_55166 = _41LexName(_tok_55162, _26467);
    DeRef(_0);

    /** 		actual = LexName(t[T_ID])*/
    _2 = (int)SEQ_PTR(_t_55165);
    _28341 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_28341);
    RefDS(_26467);
    _0 = _actual_55167;
    _actual_55167 = _41LexName(_28341, _26467);
    DeRef(_0);
    _28341 = NOVALUE;

    /** 		if prevtok = 0 then*/
    if (_prevtok_55163 != 0)
    goto L2; // [50] 68

    /** 			CompileErr(132, {expected, actual})*/
    RefDS(_actual_55167);
    RefDS(_expected_55166);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _expected_55166;
    ((int *)_2)[2] = _actual_55167;
    _28344 = MAKE_SEQ(_1);
    _44CompileErr(132, _28344, 0);
    _28344 = NOVALUE;
    goto L3; // [65] 91
L2: 

    /** 			prevname = LexName(prevtok)*/
    RefDS(_26467);
    _0 = _prevname_55168;
    _prevname_55168 = _41LexName(_prevtok_55163, _26467);
    DeRef(_0);

    /** 			CompileErr(138, {expected, prevname, actual})*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_expected_55166);
    *((int *)(_2+4)) = _expected_55166;
    RefDS(_prevname_55168);
    *((int *)(_2+8)) = _prevname_55168;
    RefDS(_actual_55167);
    *((int *)(_2+12)) = _actual_55167;
    _28346 = MAKE_SEQ(_1);
    _44CompileErr(138, _28346, 0);
    _28346 = NOVALUE;
L3: 
L1: 

    /** end procedure*/
    DeRef(_t_55165);
    DeRef(_expected_55166);
    DeRef(_actual_55167);
    DeRef(_prevname_55168);
    return;
    ;
}


void _39UndefinedVar(int _s_55202)
{
    int _dup_55204 = NOVALUE;
    int _errmsg_55205 = NOVALUE;
    int _rname_55206 = NOVALUE;
    int _fname_55207 = NOVALUE;
    int _28369 = NOVALUE;
    int _28368 = NOVALUE;
    int _28366 = NOVALUE;
    int _28364 = NOVALUE;
    int _28363 = NOVALUE;
    int _28361 = NOVALUE;
    int _28359 = NOVALUE;
    int _28357 = NOVALUE;
    int _28356 = NOVALUE;
    int _28355 = NOVALUE;
    int _28354 = NOVALUE;
    int _28353 = NOVALUE;
    int _28351 = NOVALUE;
    int _28350 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_s_55202)) {
        _1 = (long)(DBL_PTR(_s_55202)->dbl);
        DeRefDS(_s_55202);
        _s_55202 = _1;
    }

    /** 	sequence errmsg*/

    /** 	sequence rname*/

    /** 	sequence fname*/

    /** 	if SymTab[s][S_SCOPE] = SC_UNDEFINED then*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _28350 = (int)*(((s1_ptr)_2)->base + _s_55202);
    _2 = (int)SEQ_PTR(_28350);
    _28351 = (int)*(((s1_ptr)_2)->base + 4);
    _28350 = NOVALUE;
    if (binary_op_a(NOTEQ, _28351, 9)){
        _28351 = NOVALUE;
        goto L1; // [25] 55
    }
    _28351 = NOVALUE;

    /** 		CompileErr(19, {SymTab[s][S_NAME]})*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _28353 = (int)*(((s1_ptr)_2)->base + _s_55202);
    _2 = (int)SEQ_PTR(_28353);
    if (!IS_ATOM_INT(_35S_NAME_15917)){
        _28354 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15917)->dbl));
    }
    else{
        _28354 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15917);
    }
    _28353 = NOVALUE;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_28354);
    *((int *)(_2+4)) = _28354;
    _28355 = MAKE_SEQ(_1);
    _28354 = NOVALUE;
    _44CompileErr(19, _28355, 0);
    _28355 = NOVALUE;
    goto L2; // [52] 202
L1: 

    /** 	elsif SymTab[s][S_SCOPE] = SC_MULTIPLY_DEFINED then*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _28356 = (int)*(((s1_ptr)_2)->base + _s_55202);
    _2 = (int)SEQ_PTR(_28356);
    _28357 = (int)*(((s1_ptr)_2)->base + 4);
    _28356 = NOVALUE;
    if (binary_op_a(NOTEQ, _28357, 10)){
        _28357 = NOVALUE;
        goto L3; // [71] 179
    }
    _28357 = NOVALUE;

    /** 		rname = SymTab[s][S_NAME]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _28359 = (int)*(((s1_ptr)_2)->base + _s_55202);
    DeRef(_rname_55206);
    _2 = (int)SEQ_PTR(_28359);
    if (!IS_ATOM_INT(_35S_NAME_15917)){
        _rname_55206 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15917)->dbl));
    }
    else{
        _rname_55206 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15917);
    }
    Ref(_rname_55206);
    _28359 = NOVALUE;

    /** 		errmsg = ""*/
    RefDS(_22023);
    DeRef(_errmsg_55205);
    _errmsg_55205 = _22023;

    /** 		for i = 1 to length(dup_globals) do*/
    if (IS_SEQUENCE(_53dup_globals_47252)){
            _28361 = SEQ_PTR(_53dup_globals_47252)->length;
    }
    else {
        _28361 = 1;
    }
    {
        int _i_55233;
        _i_55233 = 1;
L4: 
        if (_i_55233 > _28361){
            goto L5; // [105] 163
        }

        /** 			dup = dup_globals[i]*/
        _2 = (int)SEQ_PTR(_53dup_globals_47252);
        _dup_55204 = (int)*(((s1_ptr)_2)->base + _i_55233);
        if (!IS_ATOM_INT(_dup_55204)){
            _dup_55204 = (long)DBL_PTR(_dup_55204)->dbl;
        }

        /** 			fname = known_files[SymTab[dup][S_FILE_NO]]*/
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _28363 = (int)*(((s1_ptr)_2)->base + _dup_55204);
        _2 = (int)SEQ_PTR(_28363);
        if (!IS_ATOM_INT(_35S_FILE_NO_15913)){
            _28364 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FILE_NO_15913)->dbl));
        }
        else{
            _28364 = (int)*(((s1_ptr)_2)->base + _35S_FILE_NO_15913);
        }
        _28363 = NOVALUE;
        DeRef(_fname_55207);
        _2 = (int)SEQ_PTR(_36known_files_15243);
        if (!IS_ATOM_INT(_28364)){
            _fname_55207 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_28364)->dbl));
        }
        else{
            _fname_55207 = (int)*(((s1_ptr)_2)->base + _28364);
        }
        Ref(_fname_55207);

        /** 			errmsg &= "    " & fname & "\n"*/
        {
            int concat_list[3];

            concat_list[0] = _22175;
            concat_list[1] = _fname_55207;
            concat_list[2] = _24965;
            Concat_N((object_ptr)&_28366, concat_list, 3);
        }
        Concat((object_ptr)&_errmsg_55205, _errmsg_55205, _28366);
        DeRefDS(_28366);
        _28366 = NOVALUE;

        /** 		end for*/
        _i_55233 = _i_55233 + 1;
        goto L4; // [158] 112
L5: 
        ;
    }

    /** 		CompileErr(23, {rname, rname, errmsg})*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    RefDSn(_rname_55206, 2);
    *((int *)(_2+4)) = _rname_55206;
    *((int *)(_2+8)) = _rname_55206;
    RefDS(_errmsg_55205);
    *((int *)(_2+12)) = _errmsg_55205;
    _28368 = MAKE_SEQ(_1);
    _44CompileErr(23, _28368, 0);
    _28368 = NOVALUE;
    goto L2; // [176] 202
L3: 

    /** 	elsif length(symbol_resolution_warning) then*/
    if (IS_SEQUENCE(_35symbol_resolution_warning_16345)){
            _28369 = SEQ_PTR(_35symbol_resolution_warning_16345)->length;
    }
    else {
        _28369 = 1;
    }
    if (_28369 == 0)
    {
        _28369 = NOVALUE;
        goto L6; // [186] 201
    }
    else{
        _28369 = NOVALUE;
    }

    /** 		Warning( symbol_resolution_warning, resolution_warning_flag)*/
    RefDS(_35symbol_resolution_warning_16345);
    RefDS(_22023);
    _44Warning(_35symbol_resolution_warning_16345, 1, _22023);
L6: 
L2: 

    /** end procedure*/
    DeRef(_errmsg_55205);
    DeRef(_rname_55206);
    DeRef(_fname_55207);
    _28364 = NOVALUE;
    return;
    ;
}


void _39WrongNumberArgs(int _subsym_55257, int _only_55258)
{
    int _msgno_55259 = NOVALUE;
    int _28381 = NOVALUE;
    int _28380 = NOVALUE;
    int _28379 = NOVALUE;
    int _28378 = NOVALUE;
    int _28377 = NOVALUE;
    int _28375 = NOVALUE;
    int _28373 = NOVALUE;
    int _28371 = NOVALUE;
    int _28370 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_subsym_55257)) {
        _1 = (long)(DBL_PTR(_subsym_55257)->dbl);
        DeRefDS(_subsym_55257);
        _subsym_55257 = _1;
    }

    /** 	if SymTab[subsym][S_NUM_ARGS] = 1 then*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _28370 = (int)*(((s1_ptr)_2)->base + _subsym_55257);
    _2 = (int)SEQ_PTR(_28370);
    if (!IS_ATOM_INT(_35S_NUM_ARGS_15968)){
        _28371 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NUM_ARGS_15968)->dbl));
    }
    else{
        _28371 = (int)*(((s1_ptr)_2)->base + _35S_NUM_ARGS_15968);
    }
    _28370 = NOVALUE;
    if (binary_op_a(NOTEQ, _28371, 1)){
        _28371 = NOVALUE;
        goto L1; // [19] 49
    }
    _28371 = NOVALUE;

    /** 		if length(only) = 0 then*/
    if (IS_SEQUENCE(_only_55258)){
            _28373 = SEQ_PTR(_only_55258)->length;
    }
    else {
        _28373 = 1;
    }
    if (_28373 != 0)
    goto L2; // [28] 40

    /** 			msgno = 20*/
    _msgno_55259 = 20;
    goto L3; // [37] 73
L2: 

    /** 			msgno = 237*/
    _msgno_55259 = 237;
    goto L3; // [46] 73
L1: 

    /** 		if length(only) = 0 then*/
    if (IS_SEQUENCE(_only_55258)){
            _28375 = SEQ_PTR(_only_55258)->length;
    }
    else {
        _28375 = 1;
    }
    if (_28375 != 0)
    goto L4; // [54] 66

    /** 			msgno = 236*/
    _msgno_55259 = 236;
    goto L5; // [63] 72
L4: 

    /** 			msgno = 238*/
    _msgno_55259 = 238;
L5: 
L3: 

    /** 	CompileErr(msgno, {SymTab[subsym][S_NAME], SymTab[subsym][S_NUM_ARGS]})*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _28377 = (int)*(((s1_ptr)_2)->base + _subsym_55257);
    _2 = (int)SEQ_PTR(_28377);
    if (!IS_ATOM_INT(_35S_NAME_15917)){
        _28378 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15917)->dbl));
    }
    else{
        _28378 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15917);
    }
    _28377 = NOVALUE;
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _28379 = (int)*(((s1_ptr)_2)->base + _subsym_55257);
    _2 = (int)SEQ_PTR(_28379);
    if (!IS_ATOM_INT(_35S_NUM_ARGS_15968)){
        _28380 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NUM_ARGS_15968)->dbl));
    }
    else{
        _28380 = (int)*(((s1_ptr)_2)->base + _35S_NUM_ARGS_15968);
    }
    _28379 = NOVALUE;
    Ref(_28380);
    Ref(_28378);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _28378;
    ((int *)_2)[2] = _28380;
    _28381 = MAKE_SEQ(_1);
    _28380 = NOVALUE;
    _28378 = NOVALUE;
    _44CompileErr(_msgno_55259, _28381, 0);
    _28381 = NOVALUE;

    /** end procedure*/
    DeRefDSi(_only_55258);
    return;
    ;
}


void _39MissingArgs(int _subsym_55288)
{
    int _eentry_55289 = NOVALUE;
    int _28386 = NOVALUE;
    int _28385 = NOVALUE;
    int _28384 = NOVALUE;
    int _28383 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence eentry = SymTab[subsym]*/
    DeRef(_eentry_55289);
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _eentry_55289 = (int)*(((s1_ptr)_2)->base + _subsym_55288);
    Ref(_eentry_55289);

    /** 	CompileErr(235, {eentry[S_NAME], eentry[S_DEF_ARGS][2]})*/
    _2 = (int)SEQ_PTR(_eentry_55289);
    if (!IS_ATOM_INT(_35S_NAME_15917)){
        _28383 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15917)->dbl));
    }
    else{
        _28383 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15917);
    }
    _2 = (int)SEQ_PTR(_eentry_55289);
    _28384 = (int)*(((s1_ptr)_2)->base + 28);
    _2 = (int)SEQ_PTR(_28384);
    _28385 = (int)*(((s1_ptr)_2)->base + 2);
    _28384 = NOVALUE;
    Ref(_28385);
    Ref(_28383);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _28383;
    ((int *)_2)[2] = _28385;
    _28386 = MAKE_SEQ(_1);
    _28385 = NOVALUE;
    _28383 = NOVALUE;
    _44CompileErr(235, _28386, 0);
    _28386 = NOVALUE;

    /** end procedure*/
    DeRefDS(_eentry_55289);
    return;
    ;
}


void _39Parse_default_arg(int _subsym_55302, int _arg_55303, int _fwd_private_list_55304, int _fwd_private_sym_55305)
{
    int _param_55307 = NOVALUE;
    int _28406 = NOVALUE;
    int _28405 = NOVALUE;
    int _28404 = NOVALUE;
    int _28403 = NOVALUE;
    int _28402 = NOVALUE;
    int _28401 = NOVALUE;
    int _28400 = NOVALUE;
    int _28399 = NOVALUE;
    int _28398 = NOVALUE;
    int _28397 = NOVALUE;
    int _28396 = NOVALUE;
    int _28395 = NOVALUE;
    int _28394 = NOVALUE;
    int _28392 = NOVALUE;
    int _28391 = NOVALUE;
    int _28388 = NOVALUE;
    int _28387 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_subsym_55302)) {
        _1 = (long)(DBL_PTR(_subsym_55302)->dbl);
        DeRefDS(_subsym_55302);
        _subsym_55302 = _1;
    }
    if (!IS_ATOM_INT(_arg_55303)) {
        _1 = (long)(DBL_PTR(_arg_55303)->dbl);
        DeRefDS(_arg_55303);
        _arg_55303 = _1;
    }

    /** 	symtab_index param = subsym*/
    _param_55307 = _subsym_55302;

    /** 	on_arg = arg*/
    _39on_arg_54842 = _arg_55303;

    /** 	parseargs_states = append(parseargs_states,*/
    if (IS_SEQUENCE(_39private_list_54840)){
            _28387 = SEQ_PTR(_39private_list_54840)->length;
    }
    else {
        _28387 = 1;
    }
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _28387;
    *((int *)(_2+8)) = _39lock_scanner_54841;
    *((int *)(_2+12)) = _35use_private_list_16357;
    *((int *)(_2+16)) = _39on_arg_54842;
    _28388 = MAKE_SEQ(_1);
    _28387 = NOVALUE;
    RefDS(_28388);
    Append(&_39parseargs_states_54835, _39parseargs_states_54835, _28388);
    DeRefDS(_28388);
    _28388 = NOVALUE;

    /** 	nested_calls &= subsym*/
    Append(&_39nested_calls_54843, _39nested_calls_54843, _subsym_55302);

    /** 	for i = 1 to arg do*/
    _28391 = _arg_55303;
    {
        int _i_55314;
        _i_55314 = 1;
L1: 
        if (_i_55314 > _28391){
            goto L2; // [60] 90
        }

        /** 		param = SymTab[param][S_NEXT]*/
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _28392 = (int)*(((s1_ptr)_2)->base + _param_55307);
        _2 = (int)SEQ_PTR(_28392);
        _param_55307 = (int)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_param_55307)){
            _param_55307 = (long)DBL_PTR(_param_55307)->dbl;
        }
        _28392 = NOVALUE;

        /** 	end for*/
        _i_55314 = _i_55314 + 1;
        goto L1; // [85] 67
L2: 
        ;
    }

    /** 	private_list = fwd_private_list*/
    RefDS(_fwd_private_list_55304);
    DeRef(_39private_list_54840);
    _39private_list_54840 = _fwd_private_list_55304;

    /** 	private_sym  = fwd_private_sym*/
    RefDS(_fwd_private_sym_55305);
    DeRef(_35private_sym_16356);
    _35private_sym_16356 = _fwd_private_sym_55305;

    /** 	if atom(SymTab[param][S_CODE]) then  -- but no default set*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _28394 = (int)*(((s1_ptr)_2)->base + _param_55307);
    _2 = (int)SEQ_PTR(_28394);
    if (!IS_ATOM_INT(_35S_CODE_15929)){
        _28395 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_CODE_15929)->dbl));
    }
    else{
        _28395 = (int)*(((s1_ptr)_2)->base + _35S_CODE_15929);
    }
    _28394 = NOVALUE;
    _28396 = IS_ATOM(_28395);
    _28395 = NOVALUE;
    if (_28396 == 0)
    {
        _28396 = NOVALUE;
        goto L3; // [121] 162
    }
    else{
        _28396 = NOVALUE;
    }

    /** 		CompileErr(26, {arg, SymTab[subsym][S_NAME], SymTab[param][S_NAME]})*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _28397 = (int)*(((s1_ptr)_2)->base + _subsym_55302);
    _2 = (int)SEQ_PTR(_28397);
    if (!IS_ATOM_INT(_35S_NAME_15917)){
        _28398 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15917)->dbl));
    }
    else{
        _28398 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15917);
    }
    _28397 = NOVALUE;
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _28399 = (int)*(((s1_ptr)_2)->base + _param_55307);
    _2 = (int)SEQ_PTR(_28399);
    if (!IS_ATOM_INT(_35S_NAME_15917)){
        _28400 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15917)->dbl));
    }
    else{
        _28400 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15917);
    }
    _28399 = NOVALUE;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _arg_55303;
    Ref(_28398);
    *((int *)(_2+8)) = _28398;
    Ref(_28400);
    *((int *)(_2+12)) = _28400;
    _28401 = MAKE_SEQ(_1);
    _28400 = NOVALUE;
    _28398 = NOVALUE;
    _44CompileErr(26, _28401, 0);
    _28401 = NOVALUE;
L3: 

    /** 	use_private_list = 1*/
    _35use_private_list_16357 = 1;

    /** 	lock_scanner = 1*/
    _39lock_scanner_54841 = 1;

    /** 	start_playback(SymTab[param][S_CODE] )*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _28402 = (int)*(((s1_ptr)_2)->base + _param_55307);
    _2 = (int)SEQ_PTR(_28402);
    if (!IS_ATOM_INT(_35S_CODE_15929)){
        _28403 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_CODE_15929)->dbl));
    }
    else{
        _28403 = (int)*(((s1_ptr)_2)->base + _35S_CODE_15929);
    }
    _28402 = NOVALUE;
    Ref(_28403);
    _39start_playback(_28403);
    _28403 = NOVALUE;

    /** 	call_proc(forward_expr, {})*/
    _0 = (int)_00[_39forward_expr_55129].addr;
    (*(int (*)())_0)(
                         );

    /** 	add_private_symbol( Top(), SymTab[param][S_NAME] )*/
    _28404 = _41Top();
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _28405 = (int)*(((s1_ptr)_2)->base + _param_55307);
    _2 = (int)SEQ_PTR(_28405);
    if (!IS_ATOM_INT(_35S_NAME_15917)){
        _28406 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15917)->dbl));
    }
    else{
        _28406 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15917);
    }
    _28405 = NOVALUE;
    Ref(_28406);
    _38add_private_symbol(_28404, _28406);
    _28404 = NOVALUE;
    _28406 = NOVALUE;

    /** 	lock_scanner = 0*/
    _39lock_scanner_54841 = 0;

    /** 	restore_parseargs_states()*/
    _39restore_parseargs_states();

    /** end procedure*/
    DeRefDS(_fwd_private_list_55304);
    DeRefDS(_fwd_private_sym_55305);
    return;
    ;
}


void _39ParseArgs(int _subsym_55352)
{
    int _n_55353 = NOVALUE;
    int _fda_55354 = NOVALUE;
    int _lnda_55355 = NOVALUE;
    int _tok_55357 = NOVALUE;
    int _s_55359 = NOVALUE;
    int _var_code_55360 = NOVALUE;
    int _name_55361 = NOVALUE;
    int _28500 = NOVALUE;
    int _28498 = NOVALUE;
    int _28494 = NOVALUE;
    int _28493 = NOVALUE;
    int _28492 = NOVALUE;
    int _28489 = NOVALUE;
    int _28486 = NOVALUE;
    int _28484 = NOVALUE;
    int _28482 = NOVALUE;
    int _28480 = NOVALUE;
    int _28478 = NOVALUE;
    int _28477 = NOVALUE;
    int _28476 = NOVALUE;
    int _28475 = NOVALUE;
    int _28474 = NOVALUE;
    int _28473 = NOVALUE;
    int _28472 = NOVALUE;
    int _28466 = NOVALUE;
    int _28464 = NOVALUE;
    int _28461 = NOVALUE;
    int _28458 = NOVALUE;
    int _28453 = NOVALUE;
    int _28451 = NOVALUE;
    int _28450 = NOVALUE;
    int _28449 = NOVALUE;
    int _28447 = NOVALUE;
    int _28444 = NOVALUE;
    int _28441 = NOVALUE;
    int _28439 = NOVALUE;
    int _28437 = NOVALUE;
    int _28435 = NOVALUE;
    int _28433 = NOVALUE;
    int _28432 = NOVALUE;
    int _28431 = NOVALUE;
    int _28430 = NOVALUE;
    int _28429 = NOVALUE;
    int _28428 = NOVALUE;
    int _28427 = NOVALUE;
    int _28425 = NOVALUE;
    int _28423 = NOVALUE;
    int _28419 = NOVALUE;
    int _28418 = NOVALUE;
    int _28416 = NOVALUE;
    int _28415 = NOVALUE;
    int _28413 = NOVALUE;
    int _28412 = NOVALUE;
    int _28411 = NOVALUE;
    int _28410 = NOVALUE;
    int _28409 = NOVALUE;
    int _28407 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_subsym_55352)) {
        _1 = (long)(DBL_PTR(_subsym_55352)->dbl);
        DeRefDS(_subsym_55352);
        _subsym_55352 = _1;
    }

    /** 	object var_code*/

    /** 	sequence name*/

    /** 	n = SymTab[subsym][S_NUM_ARGS]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _28407 = (int)*(((s1_ptr)_2)->base + _subsym_55352);
    _2 = (int)SEQ_PTR(_28407);
    if (!IS_ATOM_INT(_35S_NUM_ARGS_15968)){
        _n_55353 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NUM_ARGS_15968)->dbl));
    }
    else{
        _n_55353 = (int)*(((s1_ptr)_2)->base + _35S_NUM_ARGS_15968);
    }
    if (!IS_ATOM_INT(_n_55353)){
        _n_55353 = (long)DBL_PTR(_n_55353)->dbl;
    }
    _28407 = NOVALUE;

    /** 	if sequence(SymTab[subsym][S_DEF_ARGS]) then*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _28409 = (int)*(((s1_ptr)_2)->base + _subsym_55352);
    _2 = (int)SEQ_PTR(_28409);
    _28410 = (int)*(((s1_ptr)_2)->base + 28);
    _28409 = NOVALUE;
    _28411 = IS_SEQUENCE(_28410);
    _28410 = NOVALUE;
    if (_28411 == 0)
    {
        _28411 = NOVALUE;
        goto L1; // [40] 86
    }
    else{
        _28411 = NOVALUE;
    }

    /** 		fda = SymTab[subsym][S_DEF_ARGS][1]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _28412 = (int)*(((s1_ptr)_2)->base + _subsym_55352);
    _2 = (int)SEQ_PTR(_28412);
    _28413 = (int)*(((s1_ptr)_2)->base + 28);
    _28412 = NOVALUE;
    _2 = (int)SEQ_PTR(_28413);
    _fda_55354 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_fda_55354)){
        _fda_55354 = (long)DBL_PTR(_fda_55354)->dbl;
    }
    _28413 = NOVALUE;

    /** 		lnda = SymTab[subsym][S_DEF_ARGS][2]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _28415 = (int)*(((s1_ptr)_2)->base + _subsym_55352);
    _2 = (int)SEQ_PTR(_28415);
    _28416 = (int)*(((s1_ptr)_2)->base + 28);
    _28415 = NOVALUE;
    _2 = (int)SEQ_PTR(_28416);
    _lnda_55355 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_lnda_55355)){
        _lnda_55355 = (long)DBL_PTR(_lnda_55355)->dbl;
    }
    _28416 = NOVALUE;
    goto L2; // [83] 97
L1: 

    /** 		fda = 0*/
    _fda_55354 = 0;

    /** 		lnda = 0*/
    _lnda_55355 = 0;
L2: 

    /** 	s = subsym*/
    _s_55359 = _subsym_55352;

    /** 	parseargs_states = append(parseargs_states,*/
    if (IS_SEQUENCE(_39private_list_54840)){
            _28418 = SEQ_PTR(_39private_list_54840)->length;
    }
    else {
        _28418 = 1;
    }
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _28418;
    *((int *)(_2+8)) = _39lock_scanner_54841;
    *((int *)(_2+12)) = _35use_private_list_16357;
    *((int *)(_2+16)) = _39on_arg_54842;
    _28419 = MAKE_SEQ(_1);
    _28418 = NOVALUE;
    RefDS(_28419);
    Append(&_39parseargs_states_54835, _39parseargs_states_54835, _28419);
    DeRefDS(_28419);
    _28419 = NOVALUE;

    /** 	nested_calls &= subsym*/
    Append(&_39nested_calls_54843, _39nested_calls_54843, _subsym_55352);

    /** 	lock_scanner = 0*/
    _39lock_scanner_54841 = 0;

    /** 	on_arg = 0*/
    _39on_arg_54842 = 0;

    /** 	short_circuit -= 1*/
    _39short_circuit_54117 = _39short_circuit_54117 - 1;

    /** 	for i = 1 to n do*/
    _28423 = _n_55353;
    {
        int _i_55390;
        _i_55390 = 1;
L3: 
        if (_i_55390 > _28423){
            goto L4; // [161] 915
        }

        /** 	  	tok = next_token()*/
        _0 = _tok_55357;
        _tok_55357 = _39next_token();
        DeRef(_0);

        /** 		if tok[T_ID] = COMMA then*/
        _2 = (int)SEQ_PTR(_tok_55357);
        _28425 = (int)*(((s1_ptr)_2)->base + 1);
        if (binary_op_a(NOTEQ, _28425, -30)){
            _28425 = NOVALUE;
            goto L5; // [183] 392
        }
        _28425 = NOVALUE;

        /** 			if SymTab[subsym][S_OPCODE] then*/
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _28427 = (int)*(((s1_ptr)_2)->base + _subsym_55352);
        _2 = (int)SEQ_PTR(_28427);
        _28428 = (int)*(((s1_ptr)_2)->base + 21);
        _28427 = NOVALUE;
        if (_28428 == 0) {
            _28428 = NOVALUE;
            goto L6; // [201] 261
        }
        else {
            if (!IS_ATOM_INT(_28428) && DBL_PTR(_28428)->dbl == 0.0){
                _28428 = NOVALUE;
                goto L6; // [201] 261
            }
            _28428 = NOVALUE;
        }
        _28428 = NOVALUE;

        /** 				if atom(SymTab[subsym][S_CODE]) then*/
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _28429 = (int)*(((s1_ptr)_2)->base + _subsym_55352);
        _2 = (int)SEQ_PTR(_28429);
        if (!IS_ATOM_INT(_35S_CODE_15929)){
            _28430 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_CODE_15929)->dbl));
        }
        else{
            _28430 = (int)*(((s1_ptr)_2)->base + _35S_CODE_15929);
        }
        _28429 = NOVALUE;
        _28431 = IS_ATOM(_28430);
        _28430 = NOVALUE;
        if (_28431 == 0)
        {
            _28431 = NOVALUE;
            goto L7; // [221] 232
        }
        else{
            _28431 = NOVALUE;
        }

        /** 					var_code = 0*/
        DeRef(_var_code_55360);
        _var_code_55360 = 0;
        goto L8; // [229] 251
L7: 

        /** 					var_code = SymTab[subsym][S_CODE][i]*/
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _28432 = (int)*(((s1_ptr)_2)->base + _subsym_55352);
        _2 = (int)SEQ_PTR(_28432);
        if (!IS_ATOM_INT(_35S_CODE_15929)){
            _28433 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_CODE_15929)->dbl));
        }
        else{
            _28433 = (int)*(((s1_ptr)_2)->base + _35S_CODE_15929);
        }
        _28432 = NOVALUE;
        DeRef(_var_code_55360);
        _2 = (int)SEQ_PTR(_28433);
        _var_code_55360 = (int)*(((s1_ptr)_2)->base + _i_55390);
        Ref(_var_code_55360);
        _28433 = NOVALUE;
L8: 

        /** 				name = ""*/
        RefDS(_22023);
        DeRef(_name_55361);
        _name_55361 = _22023;
        goto L9; // [258] 308
L6: 

        /** 				s = SymTab[s][S_NEXT]*/
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _28435 = (int)*(((s1_ptr)_2)->base + _s_55359);
        _2 = (int)SEQ_PTR(_28435);
        _s_55359 = (int)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_s_55359)){
            _s_55359 = (long)DBL_PTR(_s_55359)->dbl;
        }
        _28435 = NOVALUE;

        /** 				var_code = SymTab[s][S_CODE]*/
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _28437 = (int)*(((s1_ptr)_2)->base + _s_55359);
        DeRef(_var_code_55360);
        _2 = (int)SEQ_PTR(_28437);
        if (!IS_ATOM_INT(_35S_CODE_15929)){
            _var_code_55360 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_CODE_15929)->dbl));
        }
        else{
            _var_code_55360 = (int)*(((s1_ptr)_2)->base + _35S_CODE_15929);
        }
        Ref(_var_code_55360);
        _28437 = NOVALUE;

        /** 				name = SymTab[s][S_NAME]*/
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _28439 = (int)*(((s1_ptr)_2)->base + _s_55359);
        DeRef(_name_55361);
        _2 = (int)SEQ_PTR(_28439);
        if (!IS_ATOM_INT(_35S_NAME_15917)){
            _name_55361 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15917)->dbl));
        }
        else{
            _name_55361 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15917);
        }
        Ref(_name_55361);
        _28439 = NOVALUE;
L9: 

        /** 			if atom(var_code) then  -- but no default set*/
        _28441 = IS_ATOM(_var_code_55360);
        if (_28441 == 0)
        {
            _28441 = NOVALUE;
            goto LA; // [315] 326
        }
        else{
            _28441 = NOVALUE;
        }

        /** 				CompileErr(29,i)*/
        _44CompileErr(29, _i_55390, 0);
LA: 

        /** 			use_private_list = 1*/
        _35use_private_list_16357 = 1;

        /** 			start_playback(var_code)*/
        Ref(_var_code_55360);
        _39start_playback(_var_code_55360);

        /** 			lock_scanner=1*/
        _39lock_scanner_54841 = 1;

        /** 			Expr()*/
        _39Expr();

        /** 			lock_scanner=0*/
        _39lock_scanner_54841 = 0;

        /** 			on_arg += 1*/
        _39on_arg_54842 = _39on_arg_54842 + 1;

        /** 			private_list = append(private_list,name)*/
        RefDS(_name_55361);
        Append(&_39private_list_54840, _39private_list_54840, _name_55361);

        /** 			private_sym &= Top()*/
        _28444 = _41Top();
        if (IS_SEQUENCE(_35private_sym_16356) && IS_ATOM(_28444)) {
            Ref(_28444);
            Append(&_35private_sym_16356, _35private_sym_16356, _28444);
        }
        else if (IS_ATOM(_35private_sym_16356) && IS_SEQUENCE(_28444)) {
        }
        else {
            Concat((object_ptr)&_35private_sym_16356, _35private_sym_16356, _28444);
        }
        DeRef(_28444);
        _28444 = NOVALUE;

        /** 			backed_up_tok = {tok} -- ????*/
        _0 = _39backed_up_tok_54124;
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        Ref(_tok_55357);
        *((int *)(_2+4)) = _tok_55357;
        _39backed_up_tok_54124 = MAKE_SEQ(_1);
        DeRef(_0);
        goto LB; // [389] 520
L5: 

        /** 		elsif tok[T_ID] != RIGHT_ROUND then*/
        _2 = (int)SEQ_PTR(_tok_55357);
        _28447 = (int)*(((s1_ptr)_2)->base + 1);
        if (binary_op_a(EQUALS, _28447, -27)){
            _28447 = NOVALUE;
            goto LC; // [402] 519
        }
        _28447 = NOVALUE;

        /** 			if SymTab[subsym][S_OPCODE] then*/
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _28449 = (int)*(((s1_ptr)_2)->base + _subsym_55352);
        _2 = (int)SEQ_PTR(_28449);
        _28450 = (int)*(((s1_ptr)_2)->base + 21);
        _28449 = NOVALUE;
        if (_28450 == 0) {
            _28450 = NOVALUE;
            goto LD; // [420] 433
        }
        else {
            if (!IS_ATOM_INT(_28450) && DBL_PTR(_28450)->dbl == 0.0){
                _28450 = NOVALUE;
                goto LD; // [420] 433
            }
            _28450 = NOVALUE;
        }
        _28450 = NOVALUE;

        /** 				name = ""*/
        RefDS(_22023);
        DeRef(_name_55361);
        _name_55361 = _22023;
        goto LE; // [430] 466
LD: 

        /** 				s = SymTab[s][S_NEXT]*/
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _28451 = (int)*(((s1_ptr)_2)->base + _s_55359);
        _2 = (int)SEQ_PTR(_28451);
        _s_55359 = (int)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_s_55359)){
            _s_55359 = (long)DBL_PTR(_s_55359)->dbl;
        }
        _28451 = NOVALUE;

        /** 				name = SymTab[s][S_NAME]*/
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _28453 = (int)*(((s1_ptr)_2)->base + _s_55359);
        DeRef(_name_55361);
        _2 = (int)SEQ_PTR(_28453);
        if (!IS_ATOM_INT(_35S_NAME_15917)){
            _name_55361 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15917)->dbl));
        }
        else{
            _name_55361 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15917);
        }
        Ref(_name_55361);
        _28453 = NOVALUE;
LE: 

        /** 			use_private_list = Parser_mode != PAM_NORMAL*/
        _35use_private_list_16357 = (_35Parser_mode_16349 != 0);

        /** 			putback(tok)*/
        Ref(_tok_55357);
        _39putback(_tok_55357);

        /** 			Expr()*/
        _39Expr();

        /** 			on_arg += 1*/
        _39on_arg_54842 = _39on_arg_54842 + 1;

        /** 			private_list = append(private_list,name)*/
        RefDS(_name_55361);
        Append(&_39private_list_54840, _39private_list_54840, _name_55361);

        /** 			private_sym &= Top()*/
        _28458 = _41Top();
        if (IS_SEQUENCE(_35private_sym_16356) && IS_ATOM(_28458)) {
            Ref(_28458);
            Append(&_35private_sym_16356, _35private_sym_16356, _28458);
        }
        else if (IS_ATOM(_35private_sym_16356) && IS_SEQUENCE(_28458)) {
        }
        else {
            Concat((object_ptr)&_35private_sym_16356, _35private_sym_16356, _28458);
        }
        DeRef(_28458);
        _28458 = NOVALUE;
LC: 
LB: 

        /** 		if on_arg != n then*/
        if (_39on_arg_54842 == _n_55353)
        goto LF; // [524] 908

        /** 			if tok[T_ID] = RIGHT_ROUND then*/
        _2 = (int)SEQ_PTR(_tok_55357);
        _28461 = (int)*(((s1_ptr)_2)->base + 1);
        if (binary_op_a(NOTEQ, _28461, -27)){
            _28461 = NOVALUE;
            goto L10; // [538] 548
        }
        _28461 = NOVALUE;

        /** 				putback( tok )*/
        Ref(_tok_55357);
        _39putback(_tok_55357);
L10: 

        /** 			tok = next_token()*/
        _0 = _tok_55357;
        _tok_55357 = _39next_token();
        DeRef(_0);

        /** 			if tok[T_ID] != COMMA then*/
        _2 = (int)SEQ_PTR(_tok_55357);
        _28464 = (int)*(((s1_ptr)_2)->base + 1);
        if (binary_op_a(EQUALS, _28464, -30)){
            _28464 = NOVALUE;
            goto L11; // [563] 907
        }
        _28464 = NOVALUE;

        /** 		  		if tok[T_ID] = RIGHT_ROUND then*/
        _2 = (int)SEQ_PTR(_tok_55357);
        _28466 = (int)*(((s1_ptr)_2)->base + 1);
        if (binary_op_a(NOTEQ, _28466, -27)){
            _28466 = NOVALUE;
            goto L12; // [577] 892
        }
        _28466 = NOVALUE;

        /** 					if fda=0 then*/
        if (_fda_55354 != 0)
        goto L13; // [585] 598

        /** 						WrongNumberArgs(subsym, "")*/
        RefDS(_22023);
        _39WrongNumberArgs(_subsym_55352, _22023);
        goto L14; // [595] 613
L13: 

        /** 					elsif i<lnda then*/
        if (_i_55390 >= _lnda_55355)
        goto L15; // [602] 612

        /** 						MissingArgs(subsym)*/
        _39MissingArgs(_subsym_55352);
L15: 
L14: 

        /** 					lock_scanner = 1*/
        _39lock_scanner_54841 = 1;

        /** 					use_private_list = 1*/
        _35use_private_list_16357 = 1;

        /** 					while on_arg < n do*/
L16: 
        if (_39on_arg_54842 >= _n_55353)
        goto L17; // [632] 841

        /** 						on_arg += 1*/
        _39on_arg_54842 = _39on_arg_54842 + 1;

        /** 						if SymTab[subsym][S_OPCODE] then*/
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _28472 = (int)*(((s1_ptr)_2)->base + _subsym_55352);
        _2 = (int)SEQ_PTR(_28472);
        _28473 = (int)*(((s1_ptr)_2)->base + 21);
        _28472 = NOVALUE;
        if (_28473 == 0) {
            _28473 = NOVALUE;
            goto L18; // [658] 720
        }
        else {
            if (!IS_ATOM_INT(_28473) && DBL_PTR(_28473)->dbl == 0.0){
                _28473 = NOVALUE;
                goto L18; // [658] 720
            }
            _28473 = NOVALUE;
        }
        _28473 = NOVALUE;

        /** 							if atom(SymTab[subsym][S_CODE]) then*/
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _28474 = (int)*(((s1_ptr)_2)->base + _subsym_55352);
        _2 = (int)SEQ_PTR(_28474);
        if (!IS_ATOM_INT(_35S_CODE_15929)){
            _28475 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_CODE_15929)->dbl));
        }
        else{
            _28475 = (int)*(((s1_ptr)_2)->base + _35S_CODE_15929);
        }
        _28474 = NOVALUE;
        _28476 = IS_ATOM(_28475);
        _28475 = NOVALUE;
        if (_28476 == 0)
        {
            _28476 = NOVALUE;
            goto L19; // [678] 689
        }
        else{
            _28476 = NOVALUE;
        }

        /** 								var_code = 0*/
        DeRef(_var_code_55360);
        _var_code_55360 = 0;
        goto L1A; // [686] 710
L19: 

        /** 								var_code = SymTab[subsym][S_CODE][on_arg]*/
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _28477 = (int)*(((s1_ptr)_2)->base + _subsym_55352);
        _2 = (int)SEQ_PTR(_28477);
        if (!IS_ATOM_INT(_35S_CODE_15929)){
            _28478 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_CODE_15929)->dbl));
        }
        else{
            _28478 = (int)*(((s1_ptr)_2)->base + _35S_CODE_15929);
        }
        _28477 = NOVALUE;
        DeRef(_var_code_55360);
        _2 = (int)SEQ_PTR(_28478);
        _var_code_55360 = (int)*(((s1_ptr)_2)->base + _39on_arg_54842);
        Ref(_var_code_55360);
        _28478 = NOVALUE;
L1A: 

        /** 							name = ""*/
        RefDS(_22023);
        DeRef(_name_55361);
        _name_55361 = _22023;
        goto L1B; // [717] 767
L18: 

        /** 							s = SymTab[s][S_NEXT]*/
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _28480 = (int)*(((s1_ptr)_2)->base + _s_55359);
        _2 = (int)SEQ_PTR(_28480);
        _s_55359 = (int)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_s_55359)){
            _s_55359 = (long)DBL_PTR(_s_55359)->dbl;
        }
        _28480 = NOVALUE;

        /** 							var_code = SymTab[s][S_CODE]*/
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _28482 = (int)*(((s1_ptr)_2)->base + _s_55359);
        DeRef(_var_code_55360);
        _2 = (int)SEQ_PTR(_28482);
        if (!IS_ATOM_INT(_35S_CODE_15929)){
            _var_code_55360 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_CODE_15929)->dbl));
        }
        else{
            _var_code_55360 = (int)*(((s1_ptr)_2)->base + _35S_CODE_15929);
        }
        Ref(_var_code_55360);
        _28482 = NOVALUE;

        /** 							name = SymTab[s][S_NAME]*/
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _28484 = (int)*(((s1_ptr)_2)->base + _s_55359);
        DeRef(_name_55361);
        _2 = (int)SEQ_PTR(_28484);
        if (!IS_ATOM_INT(_35S_NAME_15917)){
            _name_55361 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15917)->dbl));
        }
        else{
            _name_55361 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15917);
        }
        Ref(_name_55361);
        _28484 = NOVALUE;
L1B: 

        /** 						if sequence(var_code) then*/
        _28486 = IS_SEQUENCE(_var_code_55360);
        if (_28486 == 0)
        {
            _28486 = NOVALUE;
            goto L1C; // [774] 826
        }
        else{
            _28486 = NOVALUE;
        }

        /** 							putback( tok )*/
        Ref(_tok_55357);
        _39putback(_tok_55357);

        /** 							start_playback(var_code)*/
        Ref(_var_code_55360);
        _39start_playback(_var_code_55360);

        /** 							Expr()*/
        _39Expr();

        /** 							if on_arg < n then*/
        if (_39on_arg_54842 >= _n_55353)
        goto L16; // [795] 630

        /** 								private_list = append(private_list,name)*/
        RefDS(_name_55361);
        Append(&_39private_list_54840, _39private_list_54840, _name_55361);

        /** 								private_sym &= Top()*/
        _28489 = _41Top();
        if (IS_SEQUENCE(_35private_sym_16356) && IS_ATOM(_28489)) {
            Ref(_28489);
            Append(&_35private_sym_16356, _35private_sym_16356, _28489);
        }
        else if (IS_ATOM(_35private_sym_16356) && IS_SEQUENCE(_28489)) {
        }
        else {
            Concat((object_ptr)&_35private_sym_16356, _35private_sym_16356, _28489);
        }
        DeRef(_28489);
        _28489 = NOVALUE;
        goto L16; // [823] 630
L1C: 

        /** 							CompileErr(29, on_arg)*/
        _44CompileErr(29, _39on_arg_54842, 0);

        /** 		  		    end while*/
        goto L16; // [838] 630
L17: 

        /** 					short_circuit += 1*/
        _39short_circuit_54117 = _39short_circuit_54117 + 1;

        /** 					if backed_up_tok[$][T_ID] = PLAYBACK_ENDS then*/
        if (IS_SEQUENCE(_39backed_up_tok_54124)){
                _28492 = SEQ_PTR(_39backed_up_tok_54124)->length;
        }
        else {
            _28492 = 1;
        }
        _2 = (int)SEQ_PTR(_39backed_up_tok_54124);
        _28493 = (int)*(((s1_ptr)_2)->base + _28492);
        _2 = (int)SEQ_PTR(_28493);
        _28494 = (int)*(((s1_ptr)_2)->base + 1);
        _28493 = NOVALUE;
        if (binary_op_a(NOTEQ, _28494, 505)){
            _28494 = NOVALUE;
            goto L1D; // [868] 880
        }
        _28494 = NOVALUE;

        /** 						backed_up_tok = {}*/
        RefDS(_22023);
        DeRefDS(_39backed_up_tok_54124);
        _39backed_up_tok_54124 = _22023;
L1D: 

        /** 					restore_parseargs_states()*/
        _39restore_parseargs_states();

        /** 					return*/
        DeRef(_tok_55357);
        DeRef(_var_code_55360);
        DeRef(_name_55361);
        return;
        goto L1E; // [889] 906
L12: 

        /** 					putback(tok)*/
        Ref(_tok_55357);
        _39putback(_tok_55357);

        /** 					tok_match(COMMA)*/
        _39tok_match(-30, 0);
L1E: 
L11: 
LF: 

        /** 	end for*/
        _i_55390 = _i_55390 + 1;
        goto L3; // [910] 168
L4: 
        ;
    }

    /** 	tok = next_token()*/
    _0 = _tok_55357;
    _tok_55357 = _39next_token();
    DeRef(_0);

    /** 	short_circuit += 1*/
    _39short_circuit_54117 = _39short_circuit_54117 + 1;

    /** 	if tok[T_ID] != RIGHT_ROUND then*/
    _2 = (int)SEQ_PTR(_tok_55357);
    _28498 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _28498, -27)){
        _28498 = NOVALUE;
        goto L1F; // [938] 980
    }
    _28498 = NOVALUE;

    /** 		if tok[T_ID] = COMMA then*/
    _2 = (int)SEQ_PTR(_tok_55357);
    _28500 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28500, -30)){
        _28500 = NOVALUE;
        goto L20; // [952] 965
    }
    _28500 = NOVALUE;

    /** 			WrongNumberArgs(subsym, "only ")*/
    RefDS(_28502);
    _39WrongNumberArgs(_subsym_55352, _28502);
    goto L21; // [962] 979
L20: 

    /** 			putback(tok)*/
    Ref(_tok_55357);
    _39putback(_tok_55357);

    /** 			tok_match(RIGHT_ROUND)*/
    _39tok_match(-27, 0);
L21: 
L1F: 

    /** 	restore_parseargs_states()*/
    _39restore_parseargs_states();

    /** end procedure*/
    DeRef(_tok_55357);
    DeRef(_var_code_55360);
    DeRef(_name_55361);
    return;
    ;
}


void _39Forward_var(int _tok_55566, int _init_check_55567, int _op_55568)
{
    int _ref_55572 = NOVALUE;
    int _28506 = NOVALUE;
    int _28504 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_op_55568)) {
        _1 = (long)(DBL_PTR(_op_55568)->dbl);
        DeRefDS(_op_55568);
        _op_55568 = _1;
    }

    /** 	ref = new_forward_reference( VARIABLE, tok[T_SYM], op )*/
    _2 = (int)SEQ_PTR(_tok_55566);
    _28504 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_28504);
    _ref_55572 = _38new_forward_reference(-100, _28504, _op_55568);
    _28504 = NOVALUE;
    if (!IS_ATOM_INT(_ref_55572)) {
        _1 = (long)(DBL_PTR(_ref_55572)->dbl);
        DeRefDS(_ref_55572);
        _ref_55572 = _1;
    }

    /** 	emit_opnd( - ref )*/
    if ((unsigned long)_ref_55572 == 0xC0000000)
    _28506 = (int)NewDouble((double)-0xC0000000);
    else
    _28506 = - _ref_55572;
    _41emit_opnd(_28506);
    _28506 = NOVALUE;

    /** 	if init_check != -1 then*/
    if (_init_check_55567 == -1)
    goto L1; // [33] 44

    /** 		Forward_InitCheck( tok, init_check )*/
    Ref(_tok_55566);
    _39Forward_InitCheck(_tok_55566, _init_check_55567);
L1: 

    /** end procedure*/
    DeRef(_tok_55566);
    return;
    ;
}


void _39Forward_call(int _tok_55585, int _opcode_55586)
{
    int _args_55589 = NOVALUE;
    int _proc_55591 = NOVALUE;
    int _tok_id_55594 = NOVALUE;
    int _id_55601 = NOVALUE;
    int _fc_pc_55624 = NOVALUE;
    int _28525 = NOVALUE;
    int _28524 = NOVALUE;
    int _28521 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer args = 0*/
    _args_55589 = 0;

    /** 	symtab_index proc = tok[T_SYM]*/
    _2 = (int)SEQ_PTR(_tok_55585);
    _proc_55591 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_proc_55591)){
        _proc_55591 = (long)DBL_PTR(_proc_55591)->dbl;
    }

    /** 	integer tok_id = tok[T_ID]*/
    _2 = (int)SEQ_PTR(_tok_55585);
    _tok_id_55594 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_tok_id_55594)){
        _tok_id_55594 = (long)DBL_PTR(_tok_id_55594)->dbl;
    }

    /** 	remove_symbol( proc )*/
    _53remove_symbol(_proc_55591);

    /** 	short_circuit -= 1*/
    _39short_circuit_54117 = _39short_circuit_54117 - 1;

    /** 	while 1 do*/
L1: 

    /** 		tok = next_token()*/
    _0 = _tok_55585;
    _tok_55585 = _39next_token();
    DeRef(_0);

    /** 		integer id = tok[T_ID]*/
    _2 = (int)SEQ_PTR(_tok_55585);
    _id_55601 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_id_55601)){
        _id_55601 = (long)DBL_PTR(_id_55601)->dbl;
    }

    /** 		switch id do*/
    _0 = _id_55601;
    switch ( _0 ){ 

        /** 			case COMMA then*/
        case -30:

        /** 				emit_opnd( 0 ) -- clean this up later*/
        _41emit_opnd(0);

        /** 				args += 1*/
        _args_55589 = _args_55589 + 1;
        goto L2; // [83] 166

        /** 			case RIGHT_ROUND then*/
        case -27:

        /** 				exit*/
        goto L3; // [93] 173
        goto L2; // [95] 166

        /** 			case else*/
        default:

        /** 				putback( tok )*/
        Ref(_tok_55585);
        _39putback(_tok_55585);

        /** 				call_proc( forward_expr, {} )*/
        _0 = (int)_00[_39forward_expr_55129].addr;
        (*(int (*)())_0)(
                             );

        /** 				args += 1*/
        _args_55589 = _args_55589 + 1;

        /** 				tok = next_token()*/
        _0 = _tok_55585;
        _tok_55585 = _39next_token();
        DeRef(_0);

        /** 				id = tok[T_ID]*/
        _2 = (int)SEQ_PTR(_tok_55585);
        _id_55601 = (int)*(((s1_ptr)_2)->base + 1);
        if (!IS_ATOM_INT(_id_55601)){
            _id_55601 = (long)DBL_PTR(_id_55601)->dbl;
        }

        /** 				if id = RIGHT_ROUND then*/
        if (_id_55601 != -27)
        goto L4; // [138] 149

        /** 					exit*/
        goto L3; // [146] 173
L4: 

        /** 				if id != COMMA then*/
        if (_id_55601 == -30)
        goto L5; // [153] 165

        /** 						CompileErr(69)*/
        RefDS(_22023);
        _44CompileErr(69, _22023, 0);
L5: 
    ;}L2: 

    /** 	end while*/
    goto L1; // [170] 46
L3: 

    /** 	integer fc_pc = length( Code ) + 1*/
    if (IS_SEQUENCE(_35Code_16332)){
            _28521 = SEQ_PTR(_35Code_16332)->length;
    }
    else {
        _28521 = 1;
    }
    _fc_pc_55624 = _28521 + 1;
    _28521 = NOVALUE;

    /** 	emit_opnd( args )*/
    _41emit_opnd(_args_55589);

    /** 	op_info1 = proc*/
    _41op_info1_50222 = _proc_55591;

    /** 	if tok_id = QUALIFIED_VARIABLE then*/
    if (_tok_id_55594 != 512)
    goto L6; // [200] 224

    /** 		set_qualified_fwd( SymTab[proc][S_FILE_NO] )*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _28524 = (int)*(((s1_ptr)_2)->base + _proc_55591);
    _2 = (int)SEQ_PTR(_28524);
    if (!IS_ATOM_INT(_35S_FILE_NO_15913)){
        _28525 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FILE_NO_15913)->dbl));
    }
    else{
        _28525 = (int)*(((s1_ptr)_2)->base + _35S_FILE_NO_15913);
    }
    _28524 = NOVALUE;
    Ref(_28525);
    _61set_qualified_fwd(_28525);
    _28525 = NOVALUE;
    goto L7; // [221] 230
L6: 

    /** 		set_qualified_fwd( -1 )*/
    _61set_qualified_fwd(-1);
L7: 

    /** 	emit_op( opcode )*/
    _41emit_op(_opcode_55586);

    /** 	if not TRANSLATE then*/
    if (_35TRANSLATE_15887 != 0)
    goto L8; // [239] 258

    /** 		if OpTrace then*/
    if (_35OpTrace_16313 == 0)
    {
        goto L9; // [246] 257
    }
    else{
    }

    /** 			emit_op(UPDATE_GLOBALS)*/
    _41emit_op(89);
L9: 
L8: 

    /** 	short_circuit += 1*/
    _39short_circuit_54117 = _39short_circuit_54117 + 1;

    /** end procedure*/
    DeRef(_tok_55585);
    return;
    ;
}


void _39Object_call(int _tok_55652)
{
    int _tok2_55654 = NOVALUE;
    int _tok3_55655 = NOVALUE;
    int _save_factors_55656 = NOVALUE;
    int _save_lhs_subs_level_55657 = NOVALUE;
    int _sym_55659 = NOVALUE;
    int _28585 = NOVALUE;
    int _28583 = NOVALUE;
    int _28582 = NOVALUE;
    int _28579 = NOVALUE;
    int _28578 = NOVALUE;
    int _28574 = NOVALUE;
    int _28568 = NOVALUE;
    int _28565 = NOVALUE;
    int _28564 = NOVALUE;
    int _28563 = NOVALUE;
    int _28561 = NOVALUE;
    int _28560 = NOVALUE;
    int _28558 = NOVALUE;
    int _28557 = NOVALUE;
    int _28554 = NOVALUE;
    int _28553 = NOVALUE;
    int _28552 = NOVALUE;
    int _28550 = NOVALUE;
    int _28549 = NOVALUE;
    int _28547 = NOVALUE;
    int _28546 = NOVALUE;
    int _28545 = NOVALUE;
    int _28544 = NOVALUE;
    int _28542 = NOVALUE;
    int _28541 = NOVALUE;
    int _28539 = NOVALUE;
    int _28538 = NOVALUE;
    int _28535 = NOVALUE;
    int _28533 = NOVALUE;
    int _28532 = NOVALUE;
    int _28530 = NOVALUE;
    int _28529 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	integer save_factors, save_lhs_subs_level*/

    /** 	tok2 = next_token()*/
    _0 = _tok2_55654;
    _tok2_55654 = _39next_token();
    DeRef(_0);

    /** 	if tok2[T_ID] = VARIABLE or tok2[T_ID] = QUALIFIED_VARIABLE then*/
    _2 = (int)SEQ_PTR(_tok2_55654);
    _28529 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_28529)) {
        _28530 = (_28529 == -100);
    }
    else {
        _28530 = binary_op(EQUALS, _28529, -100);
    }
    _28529 = NOVALUE;
    if (IS_ATOM_INT(_28530)) {
        if (_28530 != 0) {
            goto L1; // [22] 43
        }
    }
    else {
        if (DBL_PTR(_28530)->dbl != 0.0) {
            goto L1; // [22] 43
        }
    }
    _2 = (int)SEQ_PTR(_tok2_55654);
    _28532 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_28532)) {
        _28533 = (_28532 == 512);
    }
    else {
        _28533 = binary_op(EQUALS, _28532, 512);
    }
    _28532 = NOVALUE;
    if (_28533 == 0) {
        DeRef(_28533);
        _28533 = NOVALUE;
        goto L2; // [39] 586
    }
    else {
        if (!IS_ATOM_INT(_28533) && DBL_PTR(_28533)->dbl == 0.0){
            DeRef(_28533);
            _28533 = NOVALUE;
            goto L2; // [39] 586
        }
        DeRef(_28533);
        _28533 = NOVALUE;
    }
    DeRef(_28533);
    _28533 = NOVALUE;
L1: 

    /** 		tok3 = next_token()*/
    _0 = _tok3_55655;
    _tok3_55655 = _39next_token();
    DeRef(_0);

    /** 		if tok3[T_ID] = RIGHT_ROUND then*/
    _2 = (int)SEQ_PTR(_tok3_55655);
    _28535 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28535, -27)){
        _28535 = NOVALUE;
        goto L3; // [58] 155
    }
    _28535 = NOVALUE;

    /** 			sym = tok2[T_SYM]*/
    _2 = (int)SEQ_PTR(_tok2_55654);
    _sym_55659 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_sym_55659)){
        _sym_55659 = (long)DBL_PTR(_sym_55659)->dbl;
    }

    /** 			if SymTab[sym][S_SCOPE] = SC_UNDEFINED then*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _28538 = (int)*(((s1_ptr)_2)->base + _sym_55659);
    _2 = (int)SEQ_PTR(_28538);
    _28539 = (int)*(((s1_ptr)_2)->base + 4);
    _28538 = NOVALUE;
    if (binary_op_a(NOTEQ, _28539, 9)){
        _28539 = NOVALUE;
        goto L4; // [88] 108
    }
    _28539 = NOVALUE;

    /** 				Forward_var( tok2 )*/
    _2 = (int)SEQ_PTR(_tok2_55654);
    _28541 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_tok2_55654);
    Ref(_28541);
    _39Forward_var(_tok2_55654, -1, _28541);
    _28541 = NOVALUE;
    goto L5; // [105] 147
L4: 

    /** 				SymTab[sym][S_USAGE] = or_bits(SymTab[sym][S_USAGE], U_READ)*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_55659 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _28544 = (int)*(((s1_ptr)_2)->base + _sym_55659);
    _2 = (int)SEQ_PTR(_28544);
    _28545 = (int)*(((s1_ptr)_2)->base + 5);
    _28544 = NOVALUE;
    if (IS_ATOM_INT(_28545)) {
        {unsigned long tu;
             tu = (unsigned long)_28545 | (unsigned long)1;
             _28546 = MAKE_UINT(tu);
        }
    }
    else {
        _28546 = binary_op(OR_BITS, _28545, 1);
    }
    _28545 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = _28546;
    if( _1 != _28546 ){
        DeRef(_1);
    }
    _28546 = NOVALUE;
    _28542 = NOVALUE;

    /** 				emit_opnd(sym)*/
    _41emit_opnd(_sym_55659);
L5: 

    /** 			putback( tok3 )*/
    Ref(_tok3_55655);
    _39putback(_tok3_55655);
    goto L6; // [152] 575
L3: 

    /** 		elsif tok3[T_ID] = COMMA then*/
    _2 = (int)SEQ_PTR(_tok3_55655);
    _28547 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28547, -30)){
        _28547 = NOVALUE;
        goto L7; // [165] 184
    }
    _28547 = NOVALUE;

    /** 			WrongNumberArgs(tok[T_SYM], "")*/
    _2 = (int)SEQ_PTR(_tok_55652);
    _28549 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_28549);
    RefDS(_22023);
    _39WrongNumberArgs(_28549, _22023);
    _28549 = NOVALUE;
    goto L6; // [181] 575
L7: 

    /** 		elsif tok3[T_ID] = LEFT_ROUND then*/
    _2 = (int)SEQ_PTR(_tok3_55655);
    _28550 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28550, -26)){
        _28550 = NOVALUE;
        goto L8; // [194] 244
    }
    _28550 = NOVALUE;

    /** 			if SymTab[tok2[T_SYM]][S_SCOPE] = SC_UNDEFINED then*/
    _2 = (int)SEQ_PTR(_tok2_55654);
    _28552 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!IS_ATOM_INT(_28552)){
        _28553 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_28552)->dbl));
    }
    else{
        _28553 = (int)*(((s1_ptr)_2)->base + _28552);
    }
    _2 = (int)SEQ_PTR(_28553);
    _28554 = (int)*(((s1_ptr)_2)->base + 4);
    _28553 = NOVALUE;
    if (binary_op_a(NOTEQ, _28554, 9)){
        _28554 = NOVALUE;
        goto L9; // [220] 235
    }
    _28554 = NOVALUE;

    /** 				Forward_call( tok2, FUNC_FORWARD )*/
    Ref(_tok2_55654);
    _39Forward_call(_tok2_55654, 196);
    goto L6; // [232] 575
L9: 

    /** 				Function_call( tok2 )*/
    Ref(_tok2_55654);
    _39Function_call(_tok2_55654);
    goto L6; // [241] 575
L8: 

    /** 			sym = tok2[T_SYM]*/
    _2 = (int)SEQ_PTR(_tok2_55654);
    _sym_55659 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_sym_55659)){
        _sym_55659 = (long)DBL_PTR(_sym_55659)->dbl;
    }

    /** 			if SymTab[sym][S_SCOPE] = SC_UNDEFINED then*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _28557 = (int)*(((s1_ptr)_2)->base + _sym_55659);
    _2 = (int)SEQ_PTR(_28557);
    _28558 = (int)*(((s1_ptr)_2)->base + 4);
    _28557 = NOVALUE;
    if (binary_op_a(NOTEQ, _28558, 9)){
        _28558 = NOVALUE;
        goto LA; // [270] 292
    }
    _28558 = NOVALUE;

    /** 				Forward_var( tok2, TRUE )*/
    _2 = (int)SEQ_PTR(_tok2_55654);
    _28560 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_tok2_55654);
    Ref(_28560);
    _39Forward_var(_tok2_55654, _13TRUE_436, _28560);
    _28560 = NOVALUE;
    goto LB; // [289] 339
LA: 

    /** 				SymTab[sym][S_USAGE] = or_bits(SymTab[sym][S_USAGE], U_READ)*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_55659 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _28563 = (int)*(((s1_ptr)_2)->base + _sym_55659);
    _2 = (int)SEQ_PTR(_28563);
    _28564 = (int)*(((s1_ptr)_2)->base + 5);
    _28563 = NOVALUE;
    if (IS_ATOM_INT(_28564)) {
        {unsigned long tu;
             tu = (unsigned long)_28564 | (unsigned long)1;
             _28565 = MAKE_UINT(tu);
        }
    }
    else {
        _28565 = binary_op(OR_BITS, _28564, 1);
    }
    _28564 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = _28565;
    if( _1 != _28565 ){
        DeRef(_1);
    }
    _28565 = NOVALUE;
    _28561 = NOVALUE;

    /** 				InitCheck(sym, TRUE)*/
    _39InitCheck(_sym_55659, _13TRUE_436);

    /** 				emit_opnd(sym)*/
    _41emit_opnd(_sym_55659);
LB: 

    /** 			if sym = left_sym then*/
    if (_sym_55659 != _39left_sym_54158)
    goto LC; // [343] 353

    /** 				lhs_subs_level = 0*/
    _39lhs_subs_level_54156 = 0;
LC: 

    /** 			tok2 = tok3*/
    Ref(_tok3_55655);
    DeRef(_tok2_55654);
    _tok2_55654 = _tok3_55655;

    /** 			current_sequence = append(current_sequence, sym)*/
    Append(&_41current_sequence_50230, _41current_sequence_50230, _sym_55659);

    /** 			while tok2[T_ID] = LEFT_SQUARE do*/
LD: 
    _2 = (int)SEQ_PTR(_tok2_55654);
    _28568 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28568, -28)){
        _28568 = NOVALUE;
        goto LE; // [381] 551
    }
    _28568 = NOVALUE;

    /** 				subs_depth += 1*/
    _39subs_depth_54159 = _39subs_depth_54159 + 1;

    /** 				if lhs_subs_level >= 0 then*/
    if (_39lhs_subs_level_54156 < 0)
    goto LF; // [397] 410

    /** 					lhs_subs_level += 1*/
    _39lhs_subs_level_54156 = _39lhs_subs_level_54156 + 1;
LF: 

    /** 				save_factors = factors*/
    _save_factors_55656 = _39factors_54155;

    /** 				save_lhs_subs_level = lhs_subs_level*/
    _save_lhs_subs_level_55657 = _39lhs_subs_level_54156;

    /** 				call_proc(forward_expr, {})*/
    _0 = (int)_00[_39forward_expr_55129].addr;
    (*(int (*)())_0)(
                         );

    /** 				tok2 = next_token()*/
    _0 = _tok2_55654;
    _tok2_55654 = _39next_token();
    DeRef(_0);

    /** 				if tok2[T_ID] = SLICE then*/
    _2 = (int)SEQ_PTR(_tok2_55654);
    _28574 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28574, 513)){
        _28574 = NOVALUE;
        goto L10; // [446] 484
    }
    _28574 = NOVALUE;

    /** 					call_proc(forward_expr, {})*/
    _0 = (int)_00[_39forward_expr_55129].addr;
    (*(int (*)())_0)(
                         );

    /** 					emit_op(RHS_SLICE)*/
    _41emit_op(46);

    /** 					tok_match(RIGHT_SQUARE)*/
    _39tok_match(-29, 0);

    /** 					tok2 = next_token()*/
    _0 = _tok2_55654;
    _tok2_55654 = _39next_token();
    DeRef(_0);

    /** 					exit*/
    goto LE; // [479] 551
    goto L11; // [481] 531
L10: 

    /** 					putback(tok2)*/
    Ref(_tok2_55654);
    _39putback(_tok2_55654);

    /** 					tok_match(RIGHT_SQUARE)*/
    _39tok_match(-29, 0);

    /** 					subs_depth -= 1*/
    _39subs_depth_54159 = _39subs_depth_54159 - 1;

    /** 					current_sequence = current_sequence[1..$-1]*/
    if (IS_SEQUENCE(_41current_sequence_50230)){
            _28578 = SEQ_PTR(_41current_sequence_50230)->length;
    }
    else {
        _28578 = 1;
    }
    _28579 = _28578 - 1;
    _28578 = NOVALUE;
    rhs_slice_target = (object_ptr)&_41current_sequence_50230;
    RHS_Slice(_41current_sequence_50230, 1, _28579);

    /** 					emit_op(RHS_SUBS)*/
    _41emit_op(25);
L11: 

    /** 				factors = save_factors*/
    _39factors_54155 = _save_factors_55656;

    /** 				lhs_subs_level = save_lhs_subs_level*/
    _39lhs_subs_level_54156 = _save_lhs_subs_level_55657;

    /** 				tok2 = next_token()*/
    _0 = _tok2_55654;
    _tok2_55654 = _39next_token();
    DeRef(_0);

    /** 			end while*/
    goto LD; // [548] 373
LE: 

    /** 			current_sequence = current_sequence[1..$-1]*/
    if (IS_SEQUENCE(_41current_sequence_50230)){
            _28582 = SEQ_PTR(_41current_sequence_50230)->length;
    }
    else {
        _28582 = 1;
    }
    _28583 = _28582 - 1;
    _28582 = NOVALUE;
    rhs_slice_target = (object_ptr)&_41current_sequence_50230;
    RHS_Slice(_41current_sequence_50230, 1, _28583);

    /** 			putback(tok2)*/
    Ref(_tok2_55654);
    _39putback(_tok2_55654);
L6: 

    /** 		tok_match( RIGHT_ROUND )*/
    _39tok_match(-27, 0);
    goto L12; // [583] 603
L2: 

    /** 		putback(tok2)*/
    Ref(_tok2_55654);
    _39putback(_tok2_55654);

    /** 		ParseArgs(tok[T_SYM])*/
    _2 = (int)SEQ_PTR(_tok_55652);
    _28585 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_28585);
    _39ParseArgs(_28585);
    _28585 = NOVALUE;
L12: 

    /** end procedure*/
    DeRef(_tok_55652);
    DeRef(_tok2_55654);
    DeRef(_tok3_55655);
    _28552 = NOVALUE;
    DeRef(_28530);
    _28530 = NOVALUE;
    DeRef(_28579);
    _28579 = NOVALUE;
    DeRef(_28583);
    _28583 = NOVALUE;
    return;
    ;
}


void _39Function_call(int _tok_55797)
{
    int _id_55798 = NOVALUE;
    int _scope_55799 = NOVALUE;
    int _opcode_55800 = NOVALUE;
    int _e_55801 = NOVALUE;
    int _28626 = NOVALUE;
    int _28625 = NOVALUE;
    int _28624 = NOVALUE;
    int _28623 = NOVALUE;
    int _28622 = NOVALUE;
    int _28621 = NOVALUE;
    int _28620 = NOVALUE;
    int _28618 = NOVALUE;
    int _28617 = NOVALUE;
    int _28615 = NOVALUE;
    int _28614 = NOVALUE;
    int _28613 = NOVALUE;
    int _28612 = NOVALUE;
    int _28611 = NOVALUE;
    int _28610 = NOVALUE;
    int _28609 = NOVALUE;
    int _28608 = NOVALUE;
    int _28607 = NOVALUE;
    int _28606 = NOVALUE;
    int _28605 = NOVALUE;
    int _28604 = NOVALUE;
    int _28603 = NOVALUE;
    int _28602 = NOVALUE;
    int _28601 = NOVALUE;
    int _28599 = NOVALUE;
    int _28597 = NOVALUE;
    int _28596 = NOVALUE;
    int _28594 = NOVALUE;
    int _28592 = NOVALUE;
    int _28591 = NOVALUE;
    int _28590 = NOVALUE;
    int _28589 = NOVALUE;
    int _28587 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	id = tok[T_ID]*/
    _2 = (int)SEQ_PTR(_tok_55797);
    _id_55798 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_id_55798)){
        _id_55798 = (long)DBL_PTR(_id_55798)->dbl;
    }

    /** 	if id = FUNC or id = TYPE then*/
    _28587 = (_id_55798 == 501);
    if (_28587 != 0) {
        goto L1; // [19] 34
    }
    _28589 = (_id_55798 == 504);
    if (_28589 == 0)
    {
        DeRef(_28589);
        _28589 = NOVALUE;
        goto L2; // [30] 46
    }
    else{
        DeRef(_28589);
        _28589 = NOVALUE;
    }
L1: 

    /** 		UndefinedVar( tok[T_SYM] )*/
    _2 = (int)SEQ_PTR(_tok_55797);
    _28590 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_28590);
    _39UndefinedVar(_28590);
    _28590 = NOVALUE;
L2: 

    /** 	e = SymTab[tok[T_SYM]][S_EFFECT]*/
    _2 = (int)SEQ_PTR(_tok_55797);
    _28591 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!IS_ATOM_INT(_28591)){
        _28592 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_28591)->dbl));
    }
    else{
        _28592 = (int)*(((s1_ptr)_2)->base + _28591);
    }
    _2 = (int)SEQ_PTR(_28592);
    _e_55801 = (int)*(((s1_ptr)_2)->base + 23);
    if (!IS_ATOM_INT(_e_55801)){
        _e_55801 = (long)DBL_PTR(_e_55801)->dbl;
    }
    _28592 = NOVALUE;

    /** 	if e then*/
    if (_e_55801 == 0)
    {
        goto L3; // [70] 229
    }
    else{
    }

    /** 		if e = E_ALL_EFFECT or tok[T_SYM] > left_sym then*/
    _28594 = (_e_55801 == 1073741823);
    if (_28594 != 0) {
        goto L4; // [81] 102
    }
    _2 = (int)SEQ_PTR(_tok_55797);
    _28596 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_28596)) {
        _28597 = (_28596 > _39left_sym_54158);
    }
    else {
        _28597 = binary_op(GREATER, _28596, _39left_sym_54158);
    }
    _28596 = NOVALUE;
    if (_28597 == 0) {
        DeRef(_28597);
        _28597 = NOVALUE;
        goto L5; // [98] 111
    }
    else {
        if (!IS_ATOM_INT(_28597) && DBL_PTR(_28597)->dbl == 0.0){
            DeRef(_28597);
            _28597 = NOVALUE;
            goto L5; // [98] 111
        }
        DeRef(_28597);
        _28597 = NOVALUE;
    }
    DeRef(_28597);
    _28597 = NOVALUE;
L4: 

    /** 			side_effect_calls = or_bits(side_effect_calls, e)*/
    {unsigned long tu;
         tu = (unsigned long)_39side_effect_calls_54154 | (unsigned long)_e_55801;
         _39side_effect_calls_54154 = MAKE_UINT(tu);
    }
L5: 

    /** 		SymTab[CurrentSub][S_EFFECT] = or_bits(SymTab[CurrentSub][S_EFFECT], e)*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_35CurrentSub_16252 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _28601 = (int)*(((s1_ptr)_2)->base + _35CurrentSub_16252);
    _2 = (int)SEQ_PTR(_28601);
    _28602 = (int)*(((s1_ptr)_2)->base + 23);
    _28601 = NOVALUE;
    if (IS_ATOM_INT(_28602)) {
        {unsigned long tu;
             tu = (unsigned long)_28602 | (unsigned long)_e_55801;
             _28603 = MAKE_UINT(tu);
        }
    }
    else {
        _28603 = binary_op(OR_BITS, _28602, _e_55801);
    }
    _28602 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 23);
    _1 = *(int *)_2;
    *(int *)_2 = _28603;
    if( _1 != _28603 ){
        DeRef(_1);
    }
    _28603 = NOVALUE;
    _28599 = NOVALUE;

    /** 		if short_circuit > 0 and short_circuit_B and*/
    _28604 = (_39short_circuit_54117 > 0);
    if (_28604 == 0) {
        _28605 = 0;
        goto L6; // [154] 164
    }
    _28605 = (_39short_circuit_B_54119 != 0);
L6: 
    if (_28605 == 0) {
        goto L7; // [164] 228
    }
    _28607 = find_from(_id_55798, _37FUNC_TOKS_15882, 1);
    if (_28607 == 0)
    {
        _28607 = NOVALUE;
        goto L7; // [176] 228
    }
    else{
        _28607 = NOVALUE;
    }

    /** 			Warning(219, short_circuit_warning_flag,*/
    _2 = (int)SEQ_PTR(_36known_files_15243);
    _28608 = (int)*(((s1_ptr)_2)->base + _35current_file_no_16244);
    Ref(_28608);
    RefDS(_22023);
    _28609 = _17abbreviate_path(_28608, _22023);
    _28608 = NOVALUE;
    _2 = (int)SEQ_PTR(_tok_55797);
    _28610 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!IS_ATOM_INT(_28610)){
        _28611 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_28610)->dbl));
    }
    else{
        _28611 = (int)*(((s1_ptr)_2)->base + _28610);
    }
    _2 = (int)SEQ_PTR(_28611);
    if (!IS_ATOM_INT(_35S_NAME_15917)){
        _28612 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15917)->dbl));
    }
    else{
        _28612 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15917);
    }
    _28611 = NOVALUE;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _28609;
    *((int *)(_2+8)) = _35line_number_16245;
    Ref(_28612);
    *((int *)(_2+12)) = _28612;
    _28613 = MAKE_SEQ(_1);
    _28612 = NOVALUE;
    _28609 = NOVALUE;
    _44Warning(219, 2, _28613);
    _28613 = NOVALUE;
L7: 
L3: 

    /** 	tok_match(LEFT_ROUND)*/
    _39tok_match(-26, 0);

    /** 	scope = SymTab[tok[T_SYM]][S_SCOPE]*/
    _2 = (int)SEQ_PTR(_tok_55797);
    _28614 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!IS_ATOM_INT(_28614)){
        _28615 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_28614)->dbl));
    }
    else{
        _28615 = (int)*(((s1_ptr)_2)->base + _28614);
    }
    _2 = (int)SEQ_PTR(_28615);
    _scope_55799 = (int)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_scope_55799)){
        _scope_55799 = (long)DBL_PTR(_scope_55799)->dbl;
    }
    _28615 = NOVALUE;

    /** 	opcode = SymTab[tok[T_SYM]][S_OPCODE]*/
    _2 = (int)SEQ_PTR(_tok_55797);
    _28617 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!IS_ATOM_INT(_28617)){
        _28618 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_28617)->dbl));
    }
    else{
        _28618 = (int)*(((s1_ptr)_2)->base + _28617);
    }
    _2 = (int)SEQ_PTR(_28618);
    _opcode_55800 = (int)*(((s1_ptr)_2)->base + 21);
    if (!IS_ATOM_INT(_opcode_55800)){
        _opcode_55800 = (long)DBL_PTR(_opcode_55800)->dbl;
    }
    _28618 = NOVALUE;

    /** 	if equal(SymTab[tok[T_SYM]][S_NAME],"object") and scope = SC_PREDEF then*/
    _2 = (int)SEQ_PTR(_tok_55797);
    _28620 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!IS_ATOM_INT(_28620)){
        _28621 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_28620)->dbl));
    }
    else{
        _28621 = (int)*(((s1_ptr)_2)->base + _28620);
    }
    _2 = (int)SEQ_PTR(_28621);
    if (!IS_ATOM_INT(_35S_NAME_15917)){
        _28622 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15917)->dbl));
    }
    else{
        _28622 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15917);
    }
    _28621 = NOVALUE;
    if (_28622 == _24651)
    _28623 = 1;
    else if (IS_ATOM_INT(_28622) && IS_ATOM_INT(_24651))
    _28623 = 0;
    else
    _28623 = (compare(_28622, _24651) == 0);
    _28622 = NOVALUE;
    if (_28623 == 0) {
        goto L8; // [305] 327
    }
    _28625 = (_scope_55799 == 7);
    if (_28625 == 0)
    {
        DeRef(_28625);
        _28625 = NOVALUE;
        goto L8; // [316] 327
    }
    else{
        DeRef(_28625);
        _28625 = NOVALUE;
    }

    /** 		Object_call( tok )*/
    Ref(_tok_55797);
    _39Object_call(_tok_55797);
    goto L9; // [324] 339
L8: 

    /** 		ParseArgs(tok[T_SYM])*/
    _2 = (int)SEQ_PTR(_tok_55797);
    _28626 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_28626);
    _39ParseArgs(_28626);
    _28626 = NOVALUE;
L9: 

    /** 	if scope = SC_PREDEF then*/
    if (_scope_55799 != 7)
    goto LA; // [343] 355

    /** 		emit_op(opcode)*/
    _41emit_op(_opcode_55800);
    goto LB; // [352] 393
LA: 

    /** 		op_info1 = tok[T_SYM]*/
    _2 = (int)SEQ_PTR(_tok_55797);
    _41op_info1_50222 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_41op_info1_50222)){
        _41op_info1_50222 = (long)DBL_PTR(_41op_info1_50222)->dbl;
    }

    /** 		emit_or_inline()*/
    _67emit_or_inline();

    /** 		if not TRANSLATE then*/
    if (_35TRANSLATE_15887 != 0)
    goto LC; // [373] 392

    /** 			if OpTrace then*/
    if (_35OpTrace_16313 == 0)
    {
        goto LD; // [380] 391
    }
    else{
    }

    /** 				emit_op(UPDATE_GLOBALS)*/
    _41emit_op(89);
LD: 
LC: 
LB: 

    /** end procedure*/
    DeRef(_tok_55797);
    DeRef(_28587);
    _28587 = NOVALUE;
    _28591 = NOVALUE;
    DeRef(_28594);
    _28594 = NOVALUE;
    DeRef(_28604);
    _28604 = NOVALUE;
    _28610 = NOVALUE;
    _28614 = NOVALUE;
    _28617 = NOVALUE;
    _28620 = NOVALUE;
    return;
    ;
}


void _39Factor()
{
    int _tok_55905 = NOVALUE;
    int _id_55906 = NOVALUE;
    int _n_55907 = NOVALUE;
    int _save_factors_55908 = NOVALUE;
    int _save_lhs_subs_level_55909 = NOVALUE;
    int _sym_55911 = NOVALUE;
    int _forward_55942 = NOVALUE;
    int _28688 = NOVALUE;
    int _28687 = NOVALUE;
    int _28686 = NOVALUE;
    int _28684 = NOVALUE;
    int _28683 = NOVALUE;
    int _28682 = NOVALUE;
    int _28681 = NOVALUE;
    int _28680 = NOVALUE;
    int _28678 = NOVALUE;
    int _28674 = NOVALUE;
    int _28673 = NOVALUE;
    int _28670 = NOVALUE;
    int _28669 = NOVALUE;
    int _28665 = NOVALUE;
    int _28659 = NOVALUE;
    int _28654 = NOVALUE;
    int _28653 = NOVALUE;
    int _28652 = NOVALUE;
    int _28650 = NOVALUE;
    int _28649 = NOVALUE;
    int _28647 = NOVALUE;
    int _28645 = NOVALUE;
    int _28644 = NOVALUE;
    int _28643 = NOVALUE;
    int _28641 = NOVALUE;
    int _28634 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	integer id, n*/

    /** 	integer save_factors, save_lhs_subs_level*/

    /** 	factors += 1*/
    _39factors_54155 = _39factors_54155 + 1;

    /** 	tok = next_token()*/
    _0 = _tok_55905;
    _tok_55905 = _39next_token();
    DeRef(_0);

    /** 	id = tok[T_ID]*/
    _2 = (int)SEQ_PTR(_tok_55905);
    _id_55906 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_id_55906)){
        _id_55906 = (long)DBL_PTR(_id_55906)->dbl;
    }

    /** 	if id = RECORDED then*/
    if (_id_55906 != 508)
    goto L1; // [32] 59

    /** 		tok = read_recorded_token(tok[T_SYM])*/
    _2 = (int)SEQ_PTR(_tok_55905);
    _28634 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_28634);
    _0 = _tok_55905;
    _tok_55905 = _39read_recorded_token(_28634);
    DeRef(_0);
    _28634 = NOVALUE;

    /** 		id = tok[T_ID]*/
    _2 = (int)SEQ_PTR(_tok_55905);
    _id_55906 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_id_55906)){
        _id_55906 = (long)DBL_PTR(_id_55906)->dbl;
    }
L1: 

    /** 	switch id label "factor" do*/
    _0 = _id_55906;
    switch ( _0 ){ 

        /** 		case VARIABLE, QUALIFIED_VARIABLE then*/
        case -100:
        case 512:

        /** 			sym = tok[T_SYM]*/
        _2 = (int)SEQ_PTR(_tok_55905);
        _sym_55911 = (int)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_sym_55911)){
            _sym_55911 = (long)DBL_PTR(_sym_55911)->dbl;
        }

        /** 			if sym < 0 or SymTab[sym][S_SCOPE] = SC_UNDEFINED then*/
        _28641 = (_sym_55911 < 0);
        if (_28641 != 0) {
            goto L2; // [88] 115
        }
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _28643 = (int)*(((s1_ptr)_2)->base + _sym_55911);
        _2 = (int)SEQ_PTR(_28643);
        _28644 = (int)*(((s1_ptr)_2)->base + 4);
        _28643 = NOVALUE;
        if (IS_ATOM_INT(_28644)) {
            _28645 = (_28644 == 9);
        }
        else {
            _28645 = binary_op(EQUALS, _28644, 9);
        }
        _28644 = NOVALUE;
        if (_28645 == 0) {
            DeRef(_28645);
            _28645 = NOVALUE;
            goto L3; // [111] 177
        }
        else {
            if (!IS_ATOM_INT(_28645) && DBL_PTR(_28645)->dbl == 0.0){
                DeRef(_28645);
                _28645 = NOVALUE;
                goto L3; // [111] 177
            }
            DeRef(_28645);
            _28645 = NOVALUE;
        }
        DeRef(_28645);
        _28645 = NOVALUE;
L2: 

        /** 				token forward = next_token()*/
        _0 = _forward_55942;
        _forward_55942 = _39next_token();
        DeRef(_0);

        /** 				if forward[T_ID] = LEFT_ROUND then*/
        _2 = (int)SEQ_PTR(_forward_55942);
        _28647 = (int)*(((s1_ptr)_2)->base + 1);
        if (binary_op_a(NOTEQ, _28647, -26)){
            _28647 = NOVALUE;
            goto L4; // [130] 151
        }
        _28647 = NOVALUE;

        /** 					Forward_call( tok, FUNC_FORWARD )*/
        Ref(_tok_55905);
        _39Forward_call(_tok_55905, 196);

        /** 					break "factor"*/
        DeRef(_forward_55942);
        _forward_55942 = NOVALUE;
        goto L5; // [146] 696
        goto L6; // [148] 172
L4: 

        /** 					putback( forward )*/
        Ref(_forward_55942);
        _39putback(_forward_55942);

        /** 					Forward_var( tok, TRUE )*/
        _2 = (int)SEQ_PTR(_tok_55905);
        _28649 = (int)*(((s1_ptr)_2)->base + 1);
        Ref(_tok_55905);
        Ref(_28649);
        _39Forward_var(_tok_55905, _13TRUE_436, _28649);
        _28649 = NOVALUE;
L6: 
        DeRef(_forward_55942);
        _forward_55942 = NOVALUE;
        goto L7; // [174] 229
L3: 

        /** 				UndefinedVar(sym)*/
        _39UndefinedVar(_sym_55911);

        /** 				SymTab[sym][S_USAGE] = or_bits(SymTab[sym][S_USAGE], U_READ)*/
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _36SymTab_15242 = MAKE_SEQ(_2);
        }
        _3 = (int)(_sym_55911 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _28652 = (int)*(((s1_ptr)_2)->base + _sym_55911);
        _2 = (int)SEQ_PTR(_28652);
        _28653 = (int)*(((s1_ptr)_2)->base + 5);
        _28652 = NOVALUE;
        if (IS_ATOM_INT(_28653)) {
            {unsigned long tu;
                 tu = (unsigned long)_28653 | (unsigned long)1;
                 _28654 = MAKE_UINT(tu);
            }
        }
        else {
            _28654 = binary_op(OR_BITS, _28653, 1);
        }
        _28653 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 5);
        _1 = *(int *)_2;
        *(int *)_2 = _28654;
        if( _1 != _28654 ){
            DeRef(_1);
        }
        _28654 = NOVALUE;
        _28650 = NOVALUE;

        /** 				InitCheck(sym, TRUE)*/
        _39InitCheck(_sym_55911, _13TRUE_436);

        /** 				emit_opnd(sym)*/
        _41emit_opnd(_sym_55911);
L7: 

        /** 			if sym = left_sym then*/
        if (_sym_55911 != _39left_sym_54158)
        goto L8; // [233] 243

        /** 				lhs_subs_level = 0 -- start counting subscripts*/
        _39lhs_subs_level_54156 = 0;
L8: 

        /** 			short_circuit -= 1*/
        _39short_circuit_54117 = _39short_circuit_54117 - 1;

        /** 			tok = next_token()*/
        _0 = _tok_55905;
        _tok_55905 = _39next_token();
        DeRef(_0);

        /** 			current_sequence = append(current_sequence, sym)*/
        Append(&_41current_sequence_50230, _41current_sequence_50230, _sym_55911);

        /** 			while tok[T_ID] = LEFT_SQUARE do*/
L9: 
        _2 = (int)SEQ_PTR(_tok_55905);
        _28659 = (int)*(((s1_ptr)_2)->base + 1);
        if (binary_op_a(NOTEQ, _28659, -28)){
            _28659 = NOVALUE;
            goto LA; // [279] 450
        }
        _28659 = NOVALUE;

        /** 				subs_depth += 1*/
        _39subs_depth_54159 = _39subs_depth_54159 + 1;

        /** 				if lhs_subs_level >= 0 then*/
        if (_39lhs_subs_level_54156 < 0)
        goto LB; // [295] 308

        /** 					lhs_subs_level += 1*/
        _39lhs_subs_level_54156 = _39lhs_subs_level_54156 + 1;
LB: 

        /** 				save_factors = factors*/
        _save_factors_55908 = _39factors_54155;

        /** 				save_lhs_subs_level = lhs_subs_level*/
        _save_lhs_subs_level_55909 = _39lhs_subs_level_54156;

        /** 				call_proc(forward_expr, {})*/
        _0 = (int)_00[_39forward_expr_55129].addr;
        (*(int (*)())_0)(
                             );

        /** 				tok = next_token()*/
        _0 = _tok_55905;
        _tok_55905 = _39next_token();
        DeRef(_0);

        /** 				if tok[T_ID] = SLICE then*/
        _2 = (int)SEQ_PTR(_tok_55905);
        _28665 = (int)*(((s1_ptr)_2)->base + 1);
        if (binary_op_a(NOTEQ, _28665, 513)){
            _28665 = NOVALUE;
            goto LC; // [344] 382
        }
        _28665 = NOVALUE;

        /** 					call_proc(forward_expr, {})*/
        _0 = (int)_00[_39forward_expr_55129].addr;
        (*(int (*)())_0)(
                             );

        /** 					emit_op(RHS_SLICE)*/
        _41emit_op(46);

        /** 					tok_match(RIGHT_SQUARE)*/
        _39tok_match(-29, 0);

        /** 					tok = next_token()*/
        _0 = _tok_55905;
        _tok_55905 = _39next_token();
        DeRef(_0);

        /** 					exit*/
        goto LA; // [377] 450
        goto LD; // [379] 430
LC: 

        /** 					putback(tok)*/
        Ref(_tok_55905);
        _39putback(_tok_55905);

        /** 					tok_match(RIGHT_SQUARE)*/
        _39tok_match(-29, 0);

        /** 					subs_depth -= 1*/
        _39subs_depth_54159 = _39subs_depth_54159 - 1;

        /** 					current_sequence = head( current_sequence, length( current_sequence ) - 1 )*/
        if (IS_SEQUENCE(_41current_sequence_50230)){
                _28669 = SEQ_PTR(_41current_sequence_50230)->length;
        }
        else {
            _28669 = 1;
        }
        _28670 = _28669 - 1;
        _28669 = NOVALUE;
        {
            int len = SEQ_PTR(_41current_sequence_50230)->length;
            int size = (IS_ATOM_INT(_28670)) ? _28670 : (long)(DBL_PTR(_28670)->dbl);
            if (size <= 0) _41current_sequence_50230 = MAKE_SEQ(NewS1(0));
            else if (len <= size) {
                RefDS(_41current_sequence_50230);
                DeRef(_41current_sequence_50230);
                _41current_sequence_50230 = _41current_sequence_50230;
            }
            else Head(SEQ_PTR(_41current_sequence_50230),size+1,&_41current_sequence_50230);
        }
        _28670 = NOVALUE;

        /** 					emit_op(RHS_SUBS) -- current_sequence will be updated*/
        _41emit_op(25);
LD: 

        /** 				factors = save_factors*/
        _39factors_54155 = _save_factors_55908;

        /** 				lhs_subs_level = save_lhs_subs_level*/
        _39lhs_subs_level_54156 = _save_lhs_subs_level_55909;

        /** 				tok = next_token()*/
        _0 = _tok_55905;
        _tok_55905 = _39next_token();
        DeRef(_0);

        /** 			end while*/
        goto L9; // [447] 271
LA: 

        /** 			current_sequence = head( current_sequence, length( current_sequence ) - 1 )*/
        if (IS_SEQUENCE(_41current_sequence_50230)){
                _28673 = SEQ_PTR(_41current_sequence_50230)->length;
        }
        else {
            _28673 = 1;
        }
        _28674 = _28673 - 1;
        _28673 = NOVALUE;
        {
            int len = SEQ_PTR(_41current_sequence_50230)->length;
            int size = (IS_ATOM_INT(_28674)) ? _28674 : (long)(DBL_PTR(_28674)->dbl);
            if (size <= 0) _41current_sequence_50230 = MAKE_SEQ(NewS1(0));
            else if (len <= size) {
                RefDS(_41current_sequence_50230);
                DeRef(_41current_sequence_50230);
                _41current_sequence_50230 = _41current_sequence_50230;
            }
            else Head(SEQ_PTR(_41current_sequence_50230),size+1,&_41current_sequence_50230);
        }
        _28674 = NOVALUE;

        /** 			putback(tok)*/
        Ref(_tok_55905);
        _39putback(_tok_55905);

        /** 			short_circuit += 1*/
        _39short_circuit_54117 = _39short_circuit_54117 + 1;
        goto L5; // [482] 696

        /** 		case DOLLAR then*/
        case -22:

        /** 			tok = next_token()*/
        _0 = _tok_55905;
        _tok_55905 = _39next_token();
        DeRef(_0);

        /** 			putback(tok)*/
        Ref(_tok_55905);
        _39putback(_tok_55905);

        /** 			if tok[T_ID] = RIGHT_BRACE then*/
        _2 = (int)SEQ_PTR(_tok_55905);
        _28678 = (int)*(((s1_ptr)_2)->base + 1);
        if (binary_op_a(NOTEQ, _28678, -25)){
            _28678 = NOVALUE;
            goto LE; // [508] 526
        }
        _28678 = NOVALUE;

        /** 				gListItem[$] = 0*/
        if (IS_SEQUENCE(_39gListItem_54153)){
                _28680 = SEQ_PTR(_39gListItem_54153)->length;
        }
        else {
            _28680 = 1;
        }
        _2 = (int)SEQ_PTR(_39gListItem_54153);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _39gListItem_54153 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _28680);
        *(int *)_2 = 0;
        goto L5; // [523] 696
LE: 

        /** 				if subs_depth > 0 and length(current_sequence) then*/
        _28681 = (_39subs_depth_54159 > 0);
        if (_28681 == 0) {
            goto LF; // [534] 557
        }
        if (IS_SEQUENCE(_41current_sequence_50230)){
                _28683 = SEQ_PTR(_41current_sequence_50230)->length;
        }
        else {
            _28683 = 1;
        }
        if (_28683 == 0)
        {
            _28683 = NOVALUE;
            goto LF; // [544] 557
        }
        else{
            _28683 = NOVALUE;
        }

        /** 					emit_op(DOLLAR)*/
        _41emit_op(-22);
        goto L5; // [554] 696
LF: 

        /** 					CompileErr(21)*/
        RefDS(_22023);
        _44CompileErr(21, _22023, 0);
        goto L5; // [566] 696

        /** 		case ATOM then*/
        case 502:

        /** 			emit_opnd(tok[T_SYM])*/
        _2 = (int)SEQ_PTR(_tok_55905);
        _28684 = (int)*(((s1_ptr)_2)->base + 2);
        Ref(_28684);
        _41emit_opnd(_28684);
        _28684 = NOVALUE;
        goto L5; // [583] 696

        /** 		case LEFT_BRACE then*/
        case -24:

        /** 			n = Expr_list()*/
        _n_55907 = _39Expr_list();
        if (!IS_ATOM_INT(_n_55907)) {
            _1 = (long)(DBL_PTR(_n_55907)->dbl);
            DeRefDS(_n_55907);
            _n_55907 = _1;
        }

        /** 			tok_match(RIGHT_BRACE)*/
        _39tok_match(-25, 0);

        /** 			op_info1 = n*/
        _41op_info1_50222 = _n_55907;

        /** 			emit_op(RIGHT_BRACE_N)*/
        _41emit_op(31);
        goto L5; // [618] 696

        /** 		case STRING then*/
        case 503:

        /** 			emit_opnd(tok[T_SYM])*/
        _2 = (int)SEQ_PTR(_tok_55905);
        _28686 = (int)*(((s1_ptr)_2)->base + 2);
        Ref(_28686);
        _41emit_opnd(_28686);
        _28686 = NOVALUE;
        goto L5; // [635] 696

        /** 		case LEFT_ROUND then*/
        case -26:

        /** 			call_proc(forward_expr, {})*/
        _0 = (int)_00[_39forward_expr_55129].addr;
        (*(int (*)())_0)(
                             );

        /** 			tok_match(RIGHT_ROUND)*/
        _39tok_match(-27, 0);
        goto L5; // [656] 696

        /** 		case FUNC, TYPE, QUALIFIED_FUNC, QUALIFIED_TYPE then*/
        case 501:
        case 504:
        case 520:
        case 522:

        /** 			Function_call( tok )*/
        Ref(_tok_55905);
        _39Function_call(_tok_55905);
        goto L5; // [673] 696

        /** 		case else*/
        default:

        /** 			CompileErr(135, {LexName(id)})*/
        RefDS(_26467);
        _28687 = _41LexName(_id_55906, _26467);
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = _28687;
        _28688 = MAKE_SEQ(_1);
        _28687 = NOVALUE;
        _44CompileErr(135, _28688, 0);
        _28688 = NOVALUE;
    ;}L5: 

    /** end procedure*/
    DeRef(_tok_55905);
    DeRef(_28641);
    _28641 = NOVALUE;
    DeRef(_28681);
    _28681 = NOVALUE;
    return;
    ;
}


void _39UFactor()
{
    int _tok_56064 = NOVALUE;
    int _28694 = NOVALUE;
    int _28692 = NOVALUE;
    int _28690 = NOVALUE;
    int _0, _1, _2;
    

    /** 	tok = next_token()*/
    _0 = _tok_56064;
    _tok_56064 = _39next_token();
    DeRef(_0);

    /** 	if tok[T_ID] = MINUS then*/
    _2 = (int)SEQ_PTR(_tok_56064);
    _28690 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28690, 10)){
        _28690 = NOVALUE;
        goto L1; // [16] 34
    }
    _28690 = NOVALUE;

    /** 		Factor()*/
    _39Factor();

    /** 		emit_op(UMINUS)*/
    _41emit_op(12);
    goto L2; // [31] 93
L1: 

    /** 	elsif tok[T_ID] = NOT then*/
    _2 = (int)SEQ_PTR(_tok_56064);
    _28692 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28692, 7)){
        _28692 = NOVALUE;
        goto L3; // [44] 62
    }
    _28692 = NOVALUE;

    /** 		Factor()*/
    _39Factor();

    /** 		emit_op(NOT)*/
    _41emit_op(7);
    goto L2; // [59] 93
L3: 

    /** 	elsif tok[T_ID] = PLUS then*/
    _2 = (int)SEQ_PTR(_tok_56064);
    _28694 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28694, 11)){
        _28694 = NOVALUE;
        goto L4; // [72] 83
    }
    _28694 = NOVALUE;

    /** 		Factor()*/
    _39Factor();
    goto L2; // [80] 93
L4: 

    /** 		putback(tok)*/
    Ref(_tok_56064);
    _39putback(_tok_56064);

    /** 		Factor()*/
    _39Factor();
L2: 

    /** end procedure*/
    DeRef(_tok_56064);
    return;
    ;
}


int _39Term()
{
    int _tok_56089 = NOVALUE;
    int _28702 = NOVALUE;
    int _28701 = NOVALUE;
    int _28700 = NOVALUE;
    int _28698 = NOVALUE;
    int _28697 = NOVALUE;
    int _0, _1, _2;
    

    /** 	UFactor()*/
    _39UFactor();

    /** 	tok = next_token()*/
    _0 = _tok_56089;
    _tok_56089 = _39next_token();
    DeRef(_0);

    /** 	while tok[T_ID] = reserved:MULTIPLY or tok[T_ID] = reserved:DIVIDE do*/
L1: 
    _2 = (int)SEQ_PTR(_tok_56089);
    _28697 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_28697)) {
        _28698 = (_28697 == 13);
    }
    else {
        _28698 = binary_op(EQUALS, _28697, 13);
    }
    _28697 = NOVALUE;
    if (IS_ATOM_INT(_28698)) {
        if (_28698 != 0) {
            goto L2; // [25] 44
        }
    }
    else {
        if (DBL_PTR(_28698)->dbl != 0.0) {
            goto L2; // [25] 44
        }
    }
    _2 = (int)SEQ_PTR(_tok_56089);
    _28700 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_28700)) {
        _28701 = (_28700 == 14);
    }
    else {
        _28701 = binary_op(EQUALS, _28700, 14);
    }
    _28700 = NOVALUE;
    if (_28701 <= 0) {
        if (_28701 == 0) {
            DeRef(_28701);
            _28701 = NOVALUE;
            goto L3; // [40] 69
        }
        else {
            if (!IS_ATOM_INT(_28701) && DBL_PTR(_28701)->dbl == 0.0){
                DeRef(_28701);
                _28701 = NOVALUE;
                goto L3; // [40] 69
            }
            DeRef(_28701);
            _28701 = NOVALUE;
        }
    }
    DeRef(_28701);
    _28701 = NOVALUE;
L2: 

    /** 		UFactor()*/
    _39UFactor();

    /** 		emit_op(tok[T_ID])*/
    _2 = (int)SEQ_PTR(_tok_56089);
    _28702 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_28702);
    _41emit_op(_28702);
    _28702 = NOVALUE;

    /** 		tok = next_token()*/
    _0 = _tok_56089;
    _tok_56089 = _39next_token();
    DeRef(_0);

    /** 	end while*/
    goto L1; // [66] 15
L3: 

    /** 	return tok*/
    DeRef(_28698);
    _28698 = NOVALUE;
    return _tok_56089;
    ;
}


int _39aexpr()
{
    int _tok_56106 = NOVALUE;
    int _id_56107 = NOVALUE;
    int _28709 = NOVALUE;
    int _28708 = NOVALUE;
    int _28706 = NOVALUE;
    int _28705 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer id*/

    /** 	tok = Term()*/
    _0 = _tok_56106;
    _tok_56106 = _39Term();
    DeRef(_0);

    /** 	while tok[T_ID] = PLUS or tok[T_ID] = MINUS do*/
L1: 
    _2 = (int)SEQ_PTR(_tok_56106);
    _28705 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_28705)) {
        _28706 = (_28705 == 11);
    }
    else {
        _28706 = binary_op(EQUALS, _28705, 11);
    }
    _28705 = NOVALUE;
    if (IS_ATOM_INT(_28706)) {
        if (_28706 != 0) {
            goto L2; // [25] 46
        }
    }
    else {
        if (DBL_PTR(_28706)->dbl != 0.0) {
            goto L2; // [25] 46
        }
    }
    _2 = (int)SEQ_PTR(_tok_56106);
    _28708 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_28708)) {
        _28709 = (_28708 == 10);
    }
    else {
        _28709 = binary_op(EQUALS, _28708, 10);
    }
    _28708 = NOVALUE;
    if (_28709 <= 0) {
        if (_28709 == 0) {
            DeRef(_28709);
            _28709 = NOVALUE;
            goto L3; // [42] 71
        }
        else {
            if (!IS_ATOM_INT(_28709) && DBL_PTR(_28709)->dbl == 0.0){
                DeRef(_28709);
                _28709 = NOVALUE;
                goto L3; // [42] 71
            }
            DeRef(_28709);
            _28709 = NOVALUE;
        }
    }
    DeRef(_28709);
    _28709 = NOVALUE;
L2: 

    /** 		id = tok[T_ID]*/
    _2 = (int)SEQ_PTR(_tok_56106);
    _id_56107 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_id_56107)){
        _id_56107 = (long)DBL_PTR(_id_56107)->dbl;
    }

    /** 		tok = Term()*/
    _0 = _tok_56106;
    _tok_56106 = _39Term();
    DeRef(_0);

    /** 		emit_op(id)*/
    _41emit_op(_id_56107);

    /** 	end while*/
    goto L1; // [68] 13
L3: 

    /** 	return tok*/
    DeRef(_28706);
    _28706 = NOVALUE;
    return _tok_56106;
    ;
}


int _39cexpr()
{
    int _tok_56126 = NOVALUE;
    int _concat_count_56127 = NOVALUE;
    int _28713 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer concat_count*/

    /** 	tok = aexpr()*/
    _0 = _tok_56126;
    _tok_56126 = _39aexpr();
    DeRef(_0);

    /** 	concat_count = 0*/
    _concat_count_56127 = 0;

    /** 	while tok[T_ID] = reserved:CONCAT do*/
L1: 
    _2 = (int)SEQ_PTR(_tok_56126);
    _28713 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28713, 15)){
        _28713 = NOVALUE;
        goto L2; // [24] 44
    }
    _28713 = NOVALUE;

    /** 		tok = aexpr()*/
    _0 = _tok_56126;
    _tok_56126 = _39aexpr();
    DeRef(_0);

    /** 		concat_count += 1*/
    _concat_count_56127 = _concat_count_56127 + 1;

    /** 	end while*/
    goto L1; // [41] 18
L2: 

    /** 	if concat_count = 1 then*/
    if (_concat_count_56127 != 1)
    goto L3; // [46] 58

    /** 		emit_op( reserved:CONCAT )*/
    _41emit_op(15);
    goto L4; // [55] 81
L3: 

    /** 	elsif concat_count > 1 then*/
    if (_concat_count_56127 <= 1)
    goto L5; // [60] 80

    /** 		op_info1 = concat_count+1*/
    _41op_info1_50222 = _concat_count_56127 + 1;

    /** 		emit_op(CONCAT_N)*/
    _41emit_op(157);
L5: 
L4: 

    /** 	return tok*/
    return _tok_56126;
    ;
}


int _39rexpr()
{
    int _tok_56147 = NOVALUE;
    int _id_56148 = NOVALUE;
    int _28725 = NOVALUE;
    int _28724 = NOVALUE;
    int _28723 = NOVALUE;
    int _28722 = NOVALUE;
    int _28721 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer id*/

    /** 	tok = cexpr()*/
    _0 = _tok_56147;
    _tok_56147 = _39cexpr();
    DeRef(_0);

    /** 	while tok[T_ID] <= GREATER and tok[T_ID] >= LESS do*/
L1: 
    _2 = (int)SEQ_PTR(_tok_56147);
    _28721 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_28721)) {
        _28722 = (_28721 <= 6);
    }
    else {
        _28722 = binary_op(LESSEQ, _28721, 6);
    }
    _28721 = NOVALUE;
    if (IS_ATOM_INT(_28722)) {
        if (_28722 == 0) {
            goto L2; // [25] 70
        }
    }
    else {
        if (DBL_PTR(_28722)->dbl == 0.0) {
            goto L2; // [25] 70
        }
    }
    _2 = (int)SEQ_PTR(_tok_56147);
    _28724 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_28724)) {
        _28725 = (_28724 >= 1);
    }
    else {
        _28725 = binary_op(GREATEREQ, _28724, 1);
    }
    _28724 = NOVALUE;
    if (_28725 <= 0) {
        if (_28725 == 0) {
            DeRef(_28725);
            _28725 = NOVALUE;
            goto L2; // [42] 70
        }
        else {
            if (!IS_ATOM_INT(_28725) && DBL_PTR(_28725)->dbl == 0.0){
                DeRef(_28725);
                _28725 = NOVALUE;
                goto L2; // [42] 70
            }
            DeRef(_28725);
            _28725 = NOVALUE;
        }
    }
    DeRef(_28725);
    _28725 = NOVALUE;

    /** 		id = tok[T_ID]*/
    _2 = (int)SEQ_PTR(_tok_56147);
    _id_56148 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_id_56148)){
        _id_56148 = (long)DBL_PTR(_id_56148)->dbl;
    }

    /** 		tok = cexpr()*/
    _0 = _tok_56147;
    _tok_56147 = _39cexpr();
    DeRef(_0);

    /** 		emit_op(id)*/
    _41emit_op(_id_56148);

    /** 	end while*/
    goto L1; // [67] 13
L2: 

    /** 	return tok*/
    DeRef(_28722);
    _28722 = NOVALUE;
    return _tok_56147;
    ;
}


void _39Expr()
{
    int _tok_56174 = NOVALUE;
    int _id_56175 = NOVALUE;
    int _patch_56176 = NOVALUE;
    int _28748 = NOVALUE;
    int _28746 = NOVALUE;
    int _28745 = NOVALUE;
    int _28743 = NOVALUE;
    int _28742 = NOVALUE;
    int _28741 = NOVALUE;
    int _28740 = NOVALUE;
    int _28739 = NOVALUE;
    int _28733 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer id*/

    /** 	integer patch*/

    /** 	ExprLine = ThisLine*/
    Ref(_44ThisLine_48518);
    DeRef(_39ExprLine_56169);
    _39ExprLine_56169 = _44ThisLine_48518;

    /** 	expr_bp = bp*/
    _39expr_bp_56170 = _44bp_48522;

    /** 	id = -1*/
    _id_56175 = -1;

    /** 	patch = 0*/
    _patch_56176 = 0;

    /** 	while TRUE do*/
L1: 
    if (_13TRUE_436 == 0)
    {
        goto L2; // [40] 300
    }
    else{
    }

    /** 		if id != -1 then*/
    if (_id_56175 == -1)
    goto L3; // [45] 116

    /** 			if id != XOR then*/
    if (_id_56175 == 152)
    goto L4; // [53] 115

    /** 				if short_circuit > 0 then*/
    if (_39short_circuit_54117 <= 0)
    goto L5; // [61] 114

    /** 					if id = OR then*/
    if (_id_56175 != 9)
    goto L6; // [69] 83

    /** 						emit_op(SC1_OR)*/
    _41emit_op(143);
    goto L7; // [80] 91
L6: 

    /** 						emit_op(SC1_AND)*/
    _41emit_op(141);
L7: 

    /** 					patch = length(Code)+1*/
    if (IS_SEQUENCE(_35Code_16332)){
            _28733 = SEQ_PTR(_35Code_16332)->length;
    }
    else {
        _28733 = 1;
    }
    _patch_56176 = _28733 + 1;
    _28733 = NOVALUE;

    /** 					emit_forward_addr()*/
    _39emit_forward_addr();

    /** 					short_circuit_B = TRUE*/
    _39short_circuit_B_54119 = _13TRUE_436;
L5: 
L4: 
L3: 

    /** 		tok = rexpr()*/
    _0 = _tok_56174;
    _tok_56174 = _39rexpr();
    DeRef(_0);

    /** 		if id != -1 then*/
    if (_id_56175 == -1)
    goto L8; // [123] 268

    /** 			if id != XOR then*/
    if (_id_56175 == 152)
    goto L9; // [131] 261

    /** 				if short_circuit > 0 then*/
    if (_39short_circuit_54117 <= 0)
    goto LA; // [139] 252

    /** 					if tok[T_ID] != THEN and tok[T_ID] != DO then*/
    _2 = (int)SEQ_PTR(_tok_56174);
    _28739 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_28739)) {
        _28740 = (_28739 != 410);
    }
    else {
        _28740 = binary_op(NOTEQ, _28739, 410);
    }
    _28739 = NOVALUE;
    if (IS_ATOM_INT(_28740)) {
        if (_28740 == 0) {
            goto LB; // [157] 206
        }
    }
    else {
        if (DBL_PTR(_28740)->dbl == 0.0) {
            goto LB; // [157] 206
        }
    }
    _2 = (int)SEQ_PTR(_tok_56174);
    _28742 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_28742)) {
        _28743 = (_28742 != 411);
    }
    else {
        _28743 = binary_op(NOTEQ, _28742, 411);
    }
    _28742 = NOVALUE;
    if (_28743 == 0) {
        DeRef(_28743);
        _28743 = NOVALUE;
        goto LB; // [174] 206
    }
    else {
        if (!IS_ATOM_INT(_28743) && DBL_PTR(_28743)->dbl == 0.0){
            DeRef(_28743);
            _28743 = NOVALUE;
            goto LB; // [174] 206
        }
        DeRef(_28743);
        _28743 = NOVALUE;
    }
    DeRef(_28743);
    _28743 = NOVALUE;

    /** 						if id = OR then*/
    if (_id_56175 != 9)
    goto LC; // [181] 195

    /** 							emit_op(SC2_OR)*/
    _41emit_op(144);
    goto LD; // [192] 219
LC: 

    /** 							emit_op(SC2_AND)*/
    _41emit_op(142);
    goto LD; // [203] 219
LB: 

    /** 						SC1_type = id -- if/while/elsif must patch*/
    _39SC1_type_54122 = _id_56175;

    /** 						emit_op(SC2_NULL)*/
    _41emit_op(145);
LD: 

    /** 					if TRANSLATE then*/
    if (_35TRANSLATE_15887 == 0)
    {
        goto LE; // [223] 234
    }
    else{
    }

    /** 						emit_op(NOP1)   -- to get label here*/
    _41emit_op(159);
LE: 

    /** 					backpatch(patch, length(Code)+1)*/
    if (IS_SEQUENCE(_35Code_16332)){
            _28745 = SEQ_PTR(_35Code_16332)->length;
    }
    else {
        _28745 = 1;
    }
    _28746 = _28745 + 1;
    _28745 = NOVALUE;
    _41backpatch(_patch_56176, _28746);
    _28746 = NOVALUE;
    goto LF; // [249] 267
LA: 

    /** 					emit_op(id)*/
    _41emit_op(_id_56175);
    goto LF; // [258] 267
L9: 

    /** 				emit_op(id)*/
    _41emit_op(_id_56175);
LF: 
L8: 

    /** 		id = tok[T_ID]*/
    _2 = (int)SEQ_PTR(_tok_56174);
    _id_56175 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_id_56175)){
        _id_56175 = (long)DBL_PTR(_id_56175)->dbl;
    }

    /** 		if not find(id, boolOps) then*/
    _28748 = find_from(_id_56175, _39boolOps_56164, 1);
    if (_28748 != 0)
    goto L1; // [287] 38
    _28748 = NOVALUE;

    /** 			exit*/
    goto L2; // [292] 300

    /** 	end while*/
    goto L1; // [297] 38
L2: 

    /** 	putback(tok)*/
    Ref(_tok_56174);
    _39putback(_tok_56174);

    /** 	SC1_patch = patch -- extra line*/
    _39SC1_patch_54121 = _patch_56176;

    /** end procedure*/
    DeRef(_tok_56174);
    DeRef(_28740);
    _28740 = NOVALUE;
    return;
    ;
}


void _39TypeCheck(int _var_56251)
{
    int _which_type_56252 = NOVALUE;
    int _ref_56262 = NOVALUE;
    int _ref_56295 = NOVALUE;
    int _28804 = NOVALUE;
    int _28803 = NOVALUE;
    int _28802 = NOVALUE;
    int _28801 = NOVALUE;
    int _28800 = NOVALUE;
    int _28798 = NOVALUE;
    int _28797 = NOVALUE;
    int _28796 = NOVALUE;
    int _28795 = NOVALUE;
    int _28794 = NOVALUE;
    int _28793 = NOVALUE;
    int _28791 = NOVALUE;
    int _28790 = NOVALUE;
    int _28787 = NOVALUE;
    int _28786 = NOVALUE;
    int _28785 = NOVALUE;
    int _28784 = NOVALUE;
    int _28779 = NOVALUE;
    int _28778 = NOVALUE;
    int _28774 = NOVALUE;
    int _28772 = NOVALUE;
    int _28771 = NOVALUE;
    int _28770 = NOVALUE;
    int _28768 = NOVALUE;
    int _28767 = NOVALUE;
    int _28766 = NOVALUE;
    int _28765 = NOVALUE;
    int _28764 = NOVALUE;
    int _28763 = NOVALUE;
    int _28760 = NOVALUE;
    int _28758 = NOVALUE;
    int _28756 = NOVALUE;
    int _28755 = NOVALUE;
    int _28754 = NOVALUE;
    int _28752 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if var < 0 or SymTab[var][S_SCOPE] = SC_UNDEFINED then*/
    _28752 = (_var_56251 < 0);
    if (_28752 != 0) {
        goto L1; // [9] 36
    }
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _28754 = (int)*(((s1_ptr)_2)->base + _var_56251);
    _2 = (int)SEQ_PTR(_28754);
    _28755 = (int)*(((s1_ptr)_2)->base + 4);
    _28754 = NOVALUE;
    if (IS_ATOM_INT(_28755)) {
        _28756 = (_28755 == 9);
    }
    else {
        _28756 = binary_op(EQUALS, _28755, 9);
    }
    _28755 = NOVALUE;
    if (_28756 == 0) {
        DeRef(_28756);
        _28756 = NOVALUE;
        goto L2; // [32] 76
    }
    else {
        if (!IS_ATOM_INT(_28756) && DBL_PTR(_28756)->dbl == 0.0){
            DeRef(_28756);
            _28756 = NOVALUE;
            goto L2; // [32] 76
        }
        DeRef(_28756);
        _28756 = NOVALUE;
    }
    DeRef(_28756);
    _28756 = NOVALUE;
L1: 

    /** 		integer ref = new_forward_reference( TYPE_CHECK, var, TYPE_CHECK_FORWARD )*/
    _ref_56262 = _38new_forward_reference(65, _var_56251, 197);
    if (!IS_ATOM_INT(_ref_56262)) {
        _1 = (long)(DBL_PTR(_ref_56262)->dbl);
        DeRefDS(_ref_56262);
        _ref_56262 = _1;
    }

    /** 		Code &= { TYPE_CHECK_FORWARD, var, OpTypeCheck }*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 197;
    *((int *)(_2+8)) = _var_56251;
    *((int *)(_2+12)) = _35OpTypeCheck_16314;
    _28758 = MAKE_SEQ(_1);
    Concat((object_ptr)&_35Code_16332, _35Code_16332, _28758);
    DeRefDS(_28758);
    _28758 = NOVALUE;

    /** 		return*/
    DeRef(_28752);
    _28752 = NOVALUE;
    return;
L2: 

    /** 	which_type = SymTab[var][S_VTYPE]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _28760 = (int)*(((s1_ptr)_2)->base + _var_56251);
    _2 = (int)SEQ_PTR(_28760);
    _which_type_56252 = (int)*(((s1_ptr)_2)->base + 15);
    if (!IS_ATOM_INT(_which_type_56252)){
        _which_type_56252 = (long)DBL_PTR(_which_type_56252)->dbl;
    }
    _28760 = NOVALUE;

    /** 	if which_type = 0 then*/
    if (_which_type_56252 != 0)
    goto L3; // [96] 106

    /** 		return	-- Not a typed identifier.*/
    DeRef(_28752);
    _28752 = NOVALUE;
    return;
L3: 

    /** 	if which_type > 0 and length(SymTab[which_type]) < S_TOKEN then*/
    _28763 = (_which_type_56252 > 0);
    if (_28763 == 0) {
        goto L4; // [112] 141
    }
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _28765 = (int)*(((s1_ptr)_2)->base + _which_type_56252);
    if (IS_SEQUENCE(_28765)){
            _28766 = SEQ_PTR(_28765)->length;
    }
    else {
        _28766 = 1;
    }
    _28765 = NOVALUE;
    if (IS_ATOM_INT(_35S_TOKEN_15922)) {
        _28767 = (_28766 < _35S_TOKEN_15922);
    }
    else {
        _28767 = binary_op(LESS, _28766, _35S_TOKEN_15922);
    }
    _28766 = NOVALUE;
    if (_28767 == 0) {
        DeRef(_28767);
        _28767 = NOVALUE;
        goto L4; // [132] 141
    }
    else {
        if (!IS_ATOM_INT(_28767) && DBL_PTR(_28767)->dbl == 0.0){
            DeRef(_28767);
            _28767 = NOVALUE;
            goto L4; // [132] 141
        }
        DeRef(_28767);
        _28767 = NOVALUE;
    }
    DeRef(_28767);
    _28767 = NOVALUE;

    /** 		return	-- Not a typed identifier.*/
    DeRef(_28752);
    _28752 = NOVALUE;
    DeRef(_28763);
    _28763 = NOVALUE;
    _28765 = NOVALUE;
    return;
L4: 

    /** 	if which_type < 0 or SymTab[which_type][S_TOKEN] = VARIABLE  then*/
    _28768 = (_which_type_56252 < 0);
    if (_28768 != 0) {
        goto L5; // [147] 174
    }
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _28770 = (int)*(((s1_ptr)_2)->base + _which_type_56252);
    _2 = (int)SEQ_PTR(_28770);
    if (!IS_ATOM_INT(_35S_TOKEN_15922)){
        _28771 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TOKEN_15922)->dbl));
    }
    else{
        _28771 = (int)*(((s1_ptr)_2)->base + _35S_TOKEN_15922);
    }
    _28770 = NOVALUE;
    if (IS_ATOM_INT(_28771)) {
        _28772 = (_28771 == -100);
    }
    else {
        _28772 = binary_op(EQUALS, _28771, -100);
    }
    _28771 = NOVALUE;
    if (_28772 == 0) {
        DeRef(_28772);
        _28772 = NOVALUE;
        goto L6; // [170] 214
    }
    else {
        if (!IS_ATOM_INT(_28772) && DBL_PTR(_28772)->dbl == 0.0){
            DeRef(_28772);
            _28772 = NOVALUE;
            goto L6; // [170] 214
        }
        DeRef(_28772);
        _28772 = NOVALUE;
    }
    DeRef(_28772);
    _28772 = NOVALUE;
L5: 

    /** 		integer ref = new_forward_reference( TYPE_CHECK, which_type, TYPE )*/
    _ref_56295 = _38new_forward_reference(65, _which_type_56252, 504);
    if (!IS_ATOM_INT(_ref_56295)) {
        _1 = (long)(DBL_PTR(_ref_56295)->dbl);
        DeRefDS(_ref_56295);
        _ref_56295 = _1;
    }

    /** 		Code &= { TYPE_CHECK_FORWARD, var, OpTypeCheck }*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 197;
    *((int *)(_2+8)) = _var_56251;
    *((int *)(_2+12)) = _35OpTypeCheck_16314;
    _28774 = MAKE_SEQ(_1);
    Concat((object_ptr)&_35Code_16332, _35Code_16332, _28774);
    DeRefDS(_28774);
    _28774 = NOVALUE;

    /** 		return*/
    DeRef(_28752);
    _28752 = NOVALUE;
    DeRef(_28763);
    _28763 = NOVALUE;
    _28765 = NOVALUE;
    DeRef(_28768);
    _28768 = NOVALUE;
    return;
L6: 

    /** 	if TRANSLATE then*/
    if (_35TRANSLATE_15887 == 0)
    {
        goto L7; // [220] 317
    }
    else{
    }

    /** 		if OpTypeCheck then*/
    if (_35OpTypeCheck_16314 == 0)
    {
        goto L8; // [227] 481
    }
    else{
    }

    /** 			switch which_type do*/
    if( _39_56309_cases == 0 ){
        _39_56309_cases = 1;
        SEQ_PTR( _28776 )->base[1] = _53object_type_46091;
        SEQ_PTR( _28776 )->base[2] = _53sequence_type_46095;
        SEQ_PTR( _28776 )->base[3] = _53atom_type_46093;
        SEQ_PTR( _28776 )->base[4] = _53integer_type_46097;
    }
    _1 = find(_which_type_56252, _28776);
    switch ( _1 ){ 

        /** 				case object_type, sequence_type, atom_type then*/
        case 1:
        case 2:
        case 3:

        /** 				case integer_type then*/
        goto L8; // [247] 481
        case 4:

        /** 					op_info1 = var*/
        _41op_info1_50222 = _var_56251;

        /** 					emit_op(INTEGER_CHECK)*/
        _41emit_op(96);
        goto L8; // [265] 481

        /** 				case else*/
        case 0:

        /** 					if SymTab[which_type][S_EFFECT] then*/
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _28778 = (int)*(((s1_ptr)_2)->base + _which_type_56252);
        _2 = (int)SEQ_PTR(_28778);
        _28779 = (int)*(((s1_ptr)_2)->base + 23);
        _28778 = NOVALUE;
        if (_28779 == 0) {
            _28779 = NOVALUE;
            goto L9; // [285] 312
        }
        else {
            if (!IS_ATOM_INT(_28779) && DBL_PTR(_28779)->dbl == 0.0){
                _28779 = NOVALUE;
                goto L9; // [285] 312
            }
            _28779 = NOVALUE;
        }
        _28779 = NOVALUE;

        /** 						emit_opnd(var)*/
        _41emit_opnd(_var_56251);

        /** 						op_info1 = which_type*/
        _41op_info1_50222 = _which_type_56252;

        /** 						emit_or_inline()*/
        _67emit_or_inline();

        /** 						emit_op(TYPE_CHECK)*/
        _41emit_op(65);
L9: 
    ;}    goto L8; // [314] 481
L7: 

    /** 		if OpTypeCheck then*/
    if (_35OpTypeCheck_16314 == 0)
    {
        goto LA; // [321] 480
    }
    else{
    }

    /** 			if which_type != object_type then*/
    if (_which_type_56252 == _53object_type_46091)
    goto LB; // [328] 479

    /** 				if which_type = integer_type then*/
    if (_which_type_56252 != _53integer_type_46097)
    goto LC; // [336] 357

    /** 						op_info1 = var*/
    _41op_info1_50222 = _var_56251;

    /** 						emit_op(INTEGER_CHECK)*/
    _41emit_op(96);
    goto LD; // [354] 478
LC: 

    /** 				elsif which_type = sequence_type then*/
    if (_which_type_56252 != _53sequence_type_46095)
    goto LE; // [361] 382

    /** 						op_info1 = var*/
    _41op_info1_50222 = _var_56251;

    /** 						emit_op(SEQUENCE_CHECK)*/
    _41emit_op(97);
    goto LD; // [379] 478
LE: 

    /** 				elsif which_type = atom_type then*/
    if (_which_type_56252 != _53atom_type_46093)
    goto LF; // [386] 407

    /** 						op_info1 = var*/
    _41op_info1_50222 = _var_56251;

    /** 						emit_op(ATOM_CHECK)*/
    _41emit_op(101);
    goto LD; // [404] 478
LF: 

    /** 						if SymTab[SymTab[which_type][S_NEXT]][S_VTYPE] =*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _28784 = (int)*(((s1_ptr)_2)->base + _which_type_56252);
    _2 = (int)SEQ_PTR(_28784);
    _28785 = (int)*(((s1_ptr)_2)->base + 2);
    _28784 = NOVALUE;
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!IS_ATOM_INT(_28785)){
        _28786 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_28785)->dbl));
    }
    else{
        _28786 = (int)*(((s1_ptr)_2)->base + _28785);
    }
    _2 = (int)SEQ_PTR(_28786);
    _28787 = (int)*(((s1_ptr)_2)->base + 15);
    _28786 = NOVALUE;
    if (binary_op_a(NOTEQ, _28787, _53integer_type_46097)){
        _28787 = NOVALUE;
        goto L10; // [435] 454
    }
    _28787 = NOVALUE;

    /** 							op_info1 = var*/
    _41op_info1_50222 = _var_56251;

    /** 							emit_op(INTEGER_CHECK) -- need integer conversion*/
    _41emit_op(96);
L10: 

    /** 						emit_opnd(var)*/
    _41emit_opnd(_var_56251);

    /** 						op_info1 = which_type*/
    _41op_info1_50222 = _which_type_56252;

    /** 						emit_or_inline()*/
    _67emit_or_inline();

    /** 						emit_op(TYPE_CHECK)*/
    _41emit_op(65);
LD: 
LB: 
LA: 
L8: 

    /** 	if TRANSLATE or not OpTypeCheck then*/
    if (_35TRANSLATE_15887 != 0) {
        goto L11; // [485] 499
    }
    _28790 = (_35OpTypeCheck_16314 == 0);
    if (_28790 == 0)
    {
        DeRef(_28790);
        _28790 = NOVALUE;
        goto L12; // [495] 620
    }
    else{
        DeRef(_28790);
        _28790 = NOVALUE;
    }
L11: 

    /** 		op_info1 = var*/
    _41op_info1_50222 = _var_56251;

    /** 		if which_type = sequence_type or*/
    _28791 = (_which_type_56252 == _53sequence_type_46095);
    if (_28791 != 0) {
        goto L13; // [514] 553
    }
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _28793 = (int)*(((s1_ptr)_2)->base + _which_type_56252);
    _2 = (int)SEQ_PTR(_28793);
    _28794 = (int)*(((s1_ptr)_2)->base + 2);
    _28793 = NOVALUE;
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!IS_ATOM_INT(_28794)){
        _28795 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_28794)->dbl));
    }
    else{
        _28795 = (int)*(((s1_ptr)_2)->base + _28794);
    }
    _2 = (int)SEQ_PTR(_28795);
    _28796 = (int)*(((s1_ptr)_2)->base + 15);
    _28795 = NOVALUE;
    if (IS_ATOM_INT(_28796)) {
        _28797 = (_28796 == _53sequence_type_46095);
    }
    else {
        _28797 = binary_op(EQUALS, _28796, _53sequence_type_46095);
    }
    _28796 = NOVALUE;
    if (_28797 == 0) {
        DeRef(_28797);
        _28797 = NOVALUE;
        goto L14; // [549] 563
    }
    else {
        if (!IS_ATOM_INT(_28797) && DBL_PTR(_28797)->dbl == 0.0){
            DeRef(_28797);
            _28797 = NOVALUE;
            goto L14; // [549] 563
        }
        DeRef(_28797);
        _28797 = NOVALUE;
    }
    DeRef(_28797);
    _28797 = NOVALUE;
L13: 

    /** 			emit_op(SEQUENCE_CHECK)*/
    _41emit_op(97);
    goto L15; // [560] 619
L14: 

    /** 		elsif which_type = integer_type or*/
    _28798 = (_which_type_56252 == _53integer_type_46097);
    if (_28798 != 0) {
        goto L16; // [571] 610
    }
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _28800 = (int)*(((s1_ptr)_2)->base + _which_type_56252);
    _2 = (int)SEQ_PTR(_28800);
    _28801 = (int)*(((s1_ptr)_2)->base + 2);
    _28800 = NOVALUE;
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!IS_ATOM_INT(_28801)){
        _28802 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_28801)->dbl));
    }
    else{
        _28802 = (int)*(((s1_ptr)_2)->base + _28801);
    }
    _2 = (int)SEQ_PTR(_28802);
    _28803 = (int)*(((s1_ptr)_2)->base + 15);
    _28802 = NOVALUE;
    if (IS_ATOM_INT(_28803)) {
        _28804 = (_28803 == _53integer_type_46097);
    }
    else {
        _28804 = binary_op(EQUALS, _28803, _53integer_type_46097);
    }
    _28803 = NOVALUE;
    if (_28804 == 0) {
        DeRef(_28804);
        _28804 = NOVALUE;
        goto L17; // [606] 618
    }
    else {
        if (!IS_ATOM_INT(_28804) && DBL_PTR(_28804)->dbl == 0.0){
            DeRef(_28804);
            _28804 = NOVALUE;
            goto L17; // [606] 618
        }
        DeRef(_28804);
        _28804 = NOVALUE;
    }
    DeRef(_28804);
    _28804 = NOVALUE;
L16: 

    /** 			emit_op(INTEGER_CHECK)*/
    _41emit_op(96);
L17: 
L15: 
L12: 

    /** end procedure*/
    DeRef(_28752);
    _28752 = NOVALUE;
    DeRef(_28763);
    _28763 = NOVALUE;
    _28765 = NOVALUE;
    DeRef(_28768);
    _28768 = NOVALUE;
    _28785 = NOVALUE;
    DeRef(_28791);
    _28791 = NOVALUE;
    _28794 = NOVALUE;
    DeRef(_28798);
    _28798 = NOVALUE;
    _28801 = NOVALUE;
    return;
    ;
}


void _39Assignment(int _left_var_56416)
{
    int _tok_56418 = NOVALUE;
    int _subs_56419 = NOVALUE;
    int _slice_56420 = NOVALUE;
    int _assign_op_56421 = NOVALUE;
    int _subs1_patch_56422 = NOVALUE;
    int _dangerous_56424 = NOVALUE;
    int _lname_56548 = NOVALUE;
    int _temp_len_56565 = NOVALUE;
    int _28903 = NOVALUE;
    int _28902 = NOVALUE;
    int _28901 = NOVALUE;
    int _28900 = NOVALUE;
    int _28899 = NOVALUE;
    int _28898 = NOVALUE;
    int _28897 = NOVALUE;
    int _28896 = NOVALUE;
    int _28887 = NOVALUE;
    int _28886 = NOVALUE;
    int _28885 = NOVALUE;
    int _28884 = NOVALUE;
    int _28883 = NOVALUE;
    int _28882 = NOVALUE;
    int _28881 = NOVALUE;
    int _28880 = NOVALUE;
    int _28879 = NOVALUE;
    int _28878 = NOVALUE;
    int _28877 = NOVALUE;
    int _28876 = NOVALUE;
    int _28875 = NOVALUE;
    int _28874 = NOVALUE;
    int _28873 = NOVALUE;
    int _28871 = NOVALUE;
    int _28870 = NOVALUE;
    int _28869 = NOVALUE;
    int _28867 = NOVALUE;
    int _28862 = NOVALUE;
    int _28861 = NOVALUE;
    int _28858 = NOVALUE;
    int _28857 = NOVALUE;
    int _28855 = NOVALUE;
    int _28849 = NOVALUE;
    int _28844 = NOVALUE;
    int _28841 = NOVALUE;
    int _28840 = NOVALUE;
    int _28837 = NOVALUE;
    int _28834 = NOVALUE;
    int _28833 = NOVALUE;
    int _28832 = NOVALUE;
    int _28830 = NOVALUE;
    int _28829 = NOVALUE;
    int _28828 = NOVALUE;
    int _28827 = NOVALUE;
    int _28826 = NOVALUE;
    int _28825 = NOVALUE;
    int _28823 = NOVALUE;
    int _28822 = NOVALUE;
    int _28821 = NOVALUE;
    int _28820 = NOVALUE;
    int _28818 = NOVALUE;
    int _28817 = NOVALUE;
    int _28816 = NOVALUE;
    int _28815 = NOVALUE;
    int _28814 = NOVALUE;
    int _28812 = NOVALUE;
    int _28811 = NOVALUE;
    int _28810 = NOVALUE;
    int _28807 = NOVALUE;
    int _28806 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	integer subs, slice, assign_op, subs1_patch*/

    /** 	left_sym = left_var[T_SYM]*/
    _2 = (int)SEQ_PTR(_left_var_56416);
    _39left_sym_54158 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_39left_sym_54158)){
        _39left_sym_54158 = (long)DBL_PTR(_39left_sym_54158)->dbl;
    }

    /** 	if SymTab[left_sym][S_SCOPE] = SC_UNDEFINED then*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _28806 = (int)*(((s1_ptr)_2)->base + _39left_sym_54158);
    _2 = (int)SEQ_PTR(_28806);
    _28807 = (int)*(((s1_ptr)_2)->base + 4);
    _28806 = NOVALUE;
    if (binary_op_a(NOTEQ, _28807, 9)){
        _28807 = NOVALUE;
        goto L1; // [31] 54
    }
    _28807 = NOVALUE;

    /** 		Forward_var( left_var, ,ASSIGN )*/
    Ref(_left_var_56416);
    _39Forward_var(_left_var_56416, -1, 18);

    /** 		left_sym = Pop() -- pops off what forward var emitted, because it gets emitted later*/
    _0 = _41Pop();
    _39left_sym_54158 = _0;
    if (!IS_ATOM_INT(_39left_sym_54158)) {
        _1 = (long)(DBL_PTR(_39left_sym_54158)->dbl);
        DeRefDS(_39left_sym_54158);
        _39left_sym_54158 = _1;
    }
    goto L2; // [51] 267
L1: 

    /** 		UndefinedVar(left_sym)*/
    _39UndefinedVar(_39left_sym_54158);

    /** 		if SymTab[left_sym][S_SCOPE] = SC_LOOP_VAR or*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _28810 = (int)*(((s1_ptr)_2)->base + _39left_sym_54158);
    _2 = (int)SEQ_PTR(_28810);
    _28811 = (int)*(((s1_ptr)_2)->base + 4);
    _28810 = NOVALUE;
    if (IS_ATOM_INT(_28811)) {
        _28812 = (_28811 == 2);
    }
    else {
        _28812 = binary_op(EQUALS, _28811, 2);
    }
    _28811 = NOVALUE;
    if (IS_ATOM_INT(_28812)) {
        if (_28812 != 0) {
            goto L3; // [83] 112
        }
    }
    else {
        if (DBL_PTR(_28812)->dbl != 0.0) {
            goto L3; // [83] 112
        }
    }
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _28814 = (int)*(((s1_ptr)_2)->base + _39left_sym_54158);
    _2 = (int)SEQ_PTR(_28814);
    _28815 = (int)*(((s1_ptr)_2)->base + 4);
    _28814 = NOVALUE;
    if (IS_ATOM_INT(_28815)) {
        _28816 = (_28815 == 4);
    }
    else {
        _28816 = binary_op(EQUALS, _28815, 4);
    }
    _28815 = NOVALUE;
    if (_28816 == 0) {
        DeRef(_28816);
        _28816 = NOVALUE;
        goto L4; // [108] 122
    }
    else {
        if (!IS_ATOM_INT(_28816) && DBL_PTR(_28816)->dbl == 0.0){
            DeRef(_28816);
            _28816 = NOVALUE;
            goto L4; // [108] 122
        }
        DeRef(_28816);
        _28816 = NOVALUE;
    }
    DeRef(_28816);
    _28816 = NOVALUE;
L3: 

    /** 			CompileErr(109)*/
    RefDS(_22023);
    _44CompileErr(109, _22023, 0);
    goto L5; // [119] 229
L4: 

    /** 		elsif SymTab[left_sym][S_MODE] = M_CONSTANT then*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _28817 = (int)*(((s1_ptr)_2)->base + _39left_sym_54158);
    _2 = (int)SEQ_PTR(_28817);
    _28818 = (int)*(((s1_ptr)_2)->base + 3);
    _28817 = NOVALUE;
    if (binary_op_a(NOTEQ, _28818, 2)){
        _28818 = NOVALUE;
        goto L6; // [140] 154
    }
    _28818 = NOVALUE;

    /** 			CompileErr(110)*/
    RefDS(_22023);
    _44CompileErr(110, _22023, 0);
    goto L5; // [151] 229
L6: 

    /** 		elsif find(SymTab[left_sym][S_SCOPE], SCOPE_TYPES) then*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _28820 = (int)*(((s1_ptr)_2)->base + _39left_sym_54158);
    _2 = (int)SEQ_PTR(_28820);
    _28821 = (int)*(((s1_ptr)_2)->base + 4);
    _28820 = NOVALUE;
    _28822 = find_from(_28821, _39SCOPE_TYPES_54108, 1);
    _28821 = NOVALUE;
    if (_28822 == 0)
    {
        _28822 = NOVALUE;
        goto L7; // [177] 228
    }
    else{
        _28822 = NOVALUE;
    }

    /** 			SymTab[CurrentSub][S_EFFECT] = or_bits(SymTab[CurrentSub][S_EFFECT],*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_35CurrentSub_16252 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _28825 = (int)*(((s1_ptr)_2)->base + _35CurrentSub_16252);
    _2 = (int)SEQ_PTR(_28825);
    _28826 = (int)*(((s1_ptr)_2)->base + 23);
    _28825 = NOVALUE;
    _28827 = (_39left_sym_54158 % 29);
    _28828 = power(2, _28827);
    _28827 = NOVALUE;
    if (IS_ATOM_INT(_28826) && IS_ATOM_INT(_28828)) {
        {unsigned long tu;
             tu = (unsigned long)_28826 | (unsigned long)_28828;
             _28829 = MAKE_UINT(tu);
        }
    }
    else {
        _28829 = binary_op(OR_BITS, _28826, _28828);
    }
    _28826 = NOVALUE;
    DeRef(_28828);
    _28828 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 23);
    _1 = *(int *)_2;
    *(int *)_2 = _28829;
    if( _1 != _28829 ){
        DeRef(_1);
    }
    _28829 = NOVALUE;
    _28823 = NOVALUE;
L7: 
L5: 

    /** 		SymTab[left_sym][S_USAGE] = or_bits(SymTab[left_sym][S_USAGE], U_WRITTEN)*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_39left_sym_54158 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _28832 = (int)*(((s1_ptr)_2)->base + _39left_sym_54158);
    _2 = (int)SEQ_PTR(_28832);
    _28833 = (int)*(((s1_ptr)_2)->base + 5);
    _28832 = NOVALUE;
    if (IS_ATOM_INT(_28833)) {
        {unsigned long tu;
             tu = (unsigned long)_28833 | (unsigned long)2;
             _28834 = MAKE_UINT(tu);
        }
    }
    else {
        _28834 = binary_op(OR_BITS, _28833, 2);
    }
    _28833 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = _28834;
    if( _1 != _28834 ){
        DeRef(_1);
    }
    _28834 = NOVALUE;
    _28830 = NOVALUE;
L2: 

    /** 	tok = next_token()*/
    _0 = _tok_56418;
    _tok_56418 = _39next_token();
    DeRef(_0);

    /** 	subs = 0*/
    _subs_56419 = 0;

    /** 	slice = FALSE*/
    _slice_56420 = _13FALSE_434;

    /** 	dangerous = FALSE*/
    _dangerous_56424 = _13FALSE_434;

    /** 	side_effect_calls = 0*/
    _39side_effect_calls_54154 = 0;

    /** 	emit_opnd(left_sym)*/
    _41emit_opnd(_39left_sym_54158);

    /** 	current_sequence = append(current_sequence, left_sym)*/
    Append(&_41current_sequence_50230, _41current_sequence_50230, _39left_sym_54158);

    /** 	while tok[T_ID] = LEFT_SQUARE do*/
L8: 
    _2 = (int)SEQ_PTR(_tok_56418);
    _28837 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28837, -28)){
        _28837 = NOVALUE;
        goto L9; // [330] 522
    }
    _28837 = NOVALUE;

    /** 		subs_depth += 1*/
    _39subs_depth_54159 = _39subs_depth_54159 + 1;

    /** 		if lhs_ptr then*/
    if (_41lhs_ptr_50232 == 0)
    {
        goto LA; // [346] 404
    }
    else{
    }

    /** 			current_sequence = head( current_sequence, length( current_sequence ) - 1 )*/
    if (IS_SEQUENCE(_41current_sequence_50230)){
            _28840 = SEQ_PTR(_41current_sequence_50230)->length;
    }
    else {
        _28840 = 1;
    }
    _28841 = _28840 - 1;
    _28840 = NOVALUE;
    {
        int len = SEQ_PTR(_41current_sequence_50230)->length;
        int size = (IS_ATOM_INT(_28841)) ? _28841 : (long)(DBL_PTR(_28841)->dbl);
        if (size <= 0) _41current_sequence_50230 = MAKE_SEQ(NewS1(0));
        else if (len <= size) {
            RefDS(_41current_sequence_50230);
            DeRef(_41current_sequence_50230);
            _41current_sequence_50230 = _41current_sequence_50230;
        }
        else Head(SEQ_PTR(_41current_sequence_50230),size+1,&_41current_sequence_50230);
    }
    _28841 = NOVALUE;

    /** 			if subs = 1 then*/
    if (_subs_56419 != 1)
    goto LB; // [370] 395

    /** 				subs1_patch = length(Code)+1*/
    if (IS_SEQUENCE(_35Code_16332)){
            _28844 = SEQ_PTR(_35Code_16332)->length;
    }
    else {
        _28844 = 1;
    }
    _subs1_patch_56422 = _28844 + 1;
    _28844 = NOVALUE;

    /** 				emit_op(LHS_SUBS1) -- creates new current_sequence*/
    _41emit_op(161);
    goto LC; // [392] 403
LB: 

    /** 				emit_op(LHS_SUBS) -- adds to current_sequence*/
    _41emit_op(95);
LC: 
LA: 

    /** 		subs += 1*/
    _subs_56419 = _subs_56419 + 1;

    /** 		if subs = 1 then*/
    if (_subs_56419 != 1)
    goto LD; // [412] 427

    /** 			InitCheck(left_sym, TRUE)*/
    _39InitCheck(_39left_sym_54158, _13TRUE_436);
LD: 

    /** 		Expr()*/
    _39Expr();

    /** 		tok = next_token()*/
    _0 = _tok_56418;
    _tok_56418 = _39next_token();
    DeRef(_0);

    /** 		if tok[T_ID] = SLICE then*/
    _2 = (int)SEQ_PTR(_tok_56418);
    _28849 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28849, 513)){
        _28849 = NOVALUE;
        goto LE; // [446] 483
    }
    _28849 = NOVALUE;

    /** 			Expr()*/
    _39Expr();

    /** 			slice = TRUE*/
    _slice_56420 = _13TRUE_436;

    /** 			tok_match(RIGHT_SQUARE)*/
    _39tok_match(-29, 0);

    /** 			tok = next_token()*/
    _0 = _tok_56418;
    _tok_56418 = _39next_token();
    DeRef(_0);

    /** 			exit  -- no further subs or slices allowed*/
    goto L9; // [478] 522
    goto LF; // [480] 505
LE: 

    /** 			putback(tok)*/
    Ref(_tok_56418);
    _39putback(_tok_56418);

    /** 			tok_match(RIGHT_SQUARE)*/
    _39tok_match(-29, 0);

    /** 			subs_depth -= 1*/
    _39subs_depth_54159 = _39subs_depth_54159 - 1;
LF: 

    /** 		tok = next_token()*/
    _0 = _tok_56418;
    _tok_56418 = _39next_token();
    DeRef(_0);

    /** 		lhs_ptr = TRUE*/
    _41lhs_ptr_50232 = _13TRUE_436;

    /** 	end while*/
    goto L8; // [519] 322
L9: 

    /** 	lhs_ptr = FALSE*/
    _41lhs_ptr_50232 = _13FALSE_434;

    /** 	assign_op = tok[T_ID]*/
    _2 = (int)SEQ_PTR(_tok_56418);
    _assign_op_56421 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_assign_op_56421)){
        _assign_op_56421 = (long)DBL_PTR(_assign_op_56421)->dbl;
    }

    /** 	if not find(assign_op, ASSIGN_OPS) then*/
    _28855 = find_from(_assign_op_56421, _39ASSIGN_OPS_54100, 1);
    if (_28855 != 0)
    goto L10; // [548] 608
    _28855 = NOVALUE;

    /** 		sequence lname = SymTab[left_var[T_SYM]][S_NAME]*/
    _2 = (int)SEQ_PTR(_left_var_56416);
    _28857 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!IS_ATOM_INT(_28857)){
        _28858 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_28857)->dbl));
    }
    else{
        _28858 = (int)*(((s1_ptr)_2)->base + _28857);
    }
    DeRef(_lname_56548);
    _2 = (int)SEQ_PTR(_28858);
    if (!IS_ATOM_INT(_35S_NAME_15917)){
        _lname_56548 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15917)->dbl));
    }
    else{
        _lname_56548 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15917);
    }
    Ref(_lname_56548);
    _28858 = NOVALUE;

    /** 		if assign_op = COLON then*/
    if (_assign_op_56421 != -23)
    goto L11; // [577] 595

    /** 			CompileErr(133, {lname})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_lname_56548);
    *((int *)(_2+4)) = _lname_56548;
    _28861 = MAKE_SEQ(_1);
    _44CompileErr(133, _28861, 0);
    _28861 = NOVALUE;
    goto L12; // [592] 607
L11: 

    /** 			CompileErr(76, {lname})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_lname_56548);
    *((int *)(_2+4)) = _lname_56548;
    _28862 = MAKE_SEQ(_1);
    _44CompileErr(76, _28862, 0);
    _28862 = NOVALUE;
L12: 
L10: 
    DeRef(_lname_56548);
    _lname_56548 = NOVALUE;

    /** 	if subs = 0 then*/
    if (_subs_56419 != 0)
    goto L13; // [612] 740

    /** 		integer temp_len = length(Code)*/
    if (IS_SEQUENCE(_35Code_16332)){
            _temp_len_56565 = SEQ_PTR(_35Code_16332)->length;
    }
    else {
        _temp_len_56565 = 1;
    }

    /** 		if assign_op = EQUALS then*/
    if (_assign_op_56421 != 3)
    goto L14; // [627] 648

    /** 			Expr() -- RHS expression*/
    _39Expr();

    /** 			InitCheck(left_sym, FALSE)*/
    _39InitCheck(_39left_sym_54158, _13FALSE_434);
    goto L15; // [645] 721
L14: 

    /** 			InitCheck(left_sym, TRUE)*/
    _39InitCheck(_39left_sym_54158, _13TRUE_436);

    /** 			if left_sym > 0 then*/
    if (_39left_sym_54158 <= 0)
    goto L16; // [662] 704

    /** 				SymTab[left_sym][S_USAGE] = or_bits(SymTab[left_sym][S_USAGE], U_READ)*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_39left_sym_54158 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _28869 = (int)*(((s1_ptr)_2)->base + _39left_sym_54158);
    _2 = (int)SEQ_PTR(_28869);
    _28870 = (int)*(((s1_ptr)_2)->base + 5);
    _28869 = NOVALUE;
    if (IS_ATOM_INT(_28870)) {
        {unsigned long tu;
             tu = (unsigned long)_28870 | (unsigned long)1;
             _28871 = MAKE_UINT(tu);
        }
    }
    else {
        _28871 = binary_op(OR_BITS, _28870, 1);
    }
    _28870 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = _28871;
    if( _1 != _28871 ){
        DeRef(_1);
    }
    _28871 = NOVALUE;
    _28867 = NOVALUE;
L16: 

    /** 			emit_opnd(left_sym)*/
    _41emit_opnd(_39left_sym_54158);

    /** 			Expr() -- RHS expression*/
    _39Expr();

    /** 			emit_assign_op(assign_op)*/
    _41emit_assign_op(_assign_op_56421);
L15: 

    /** 		emit_op(ASSIGN)*/
    _41emit_op(18);

    /** 		TypeCheck(left_sym)*/
    _39TypeCheck(_39left_sym_54158);
    goto L17; // [737] 1164
L13: 

    /** 		factors = 0*/
    _39factors_54155 = 0;

    /** 		lhs_subs_level = -1*/
    _39lhs_subs_level_54156 = -1;

    /** 		Expr() -- RHS expression*/
    _39Expr();

    /** 		if subs > 1 then*/
    if (_subs_56419 <= 1)
    goto L18; // [756] 895

    /** 			if left_sym < 0 or SymTab[left_sym][S_SCOPE] != SC_PRIVATE and*/
    _28873 = (_39left_sym_54158 < 0);
    if (_28873 != 0) {
        _28874 = 1;
        goto L19; // [768] 796
    }
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _28875 = (int)*(((s1_ptr)_2)->base + _39left_sym_54158);
    _2 = (int)SEQ_PTR(_28875);
    _28876 = (int)*(((s1_ptr)_2)->base + 4);
    _28875 = NOVALUE;
    if (IS_ATOM_INT(_28876)) {
        _28877 = (_28876 != 3);
    }
    else {
        _28877 = binary_op(NOTEQ, _28876, 3);
    }
    _28876 = NOVALUE;
    if (IS_ATOM_INT(_28877))
    _28874 = (_28877 != 0);
    else
    _28874 = DBL_PTR(_28877)->dbl != 0.0;
L19: 
    if (_28874 == 0) {
        goto L1A; // [796] 830
    }
    _28879 = (_39left_sym_54158 % 29);
    _28880 = power(2, _28879);
    _28879 = NOVALUE;
    if (IS_ATOM_INT(_28880)) {
        {unsigned long tu;
             tu = (unsigned long)_39side_effect_calls_54154 & (unsigned long)_28880;
             _28881 = MAKE_UINT(tu);
        }
    }
    else {
        temp_d.dbl = (double)_39side_effect_calls_54154;
        _28881 = Dand_bits(&temp_d, DBL_PTR(_28880));
    }
    DeRef(_28880);
    _28880 = NOVALUE;
    if (_28881 == 0) {
        DeRef(_28881);
        _28881 = NOVALUE;
        goto L1A; // [819] 830
    }
    else {
        if (!IS_ATOM_INT(_28881) && DBL_PTR(_28881)->dbl == 0.0){
            DeRef(_28881);
            _28881 = NOVALUE;
            goto L1A; // [819] 830
        }
        DeRef(_28881);
        _28881 = NOVALUE;
    }
    DeRef(_28881);
    _28881 = NOVALUE;

    /** 				dangerous = TRUE*/
    _dangerous_56424 = _13TRUE_436;
L1A: 

    /** 			if factors = 1 and*/
    _28882 = (_39factors_54155 == 1);
    if (_28882 == 0) {
        _28883 = 0;
        goto L1B; // [838] 852
    }
    _28884 = (_39lhs_subs_level_54156 >= 0);
    _28883 = (_28884 != 0);
L1B: 
    if (_28883 == 0) {
        goto L1C; // [852] 878
    }
    _28886 = _subs_56419 + _slice_56420;
    if ((long)((unsigned long)_28886 + (unsigned long)HIGH_BITS) >= 0) 
    _28886 = NewDouble((double)_28886);
    if (IS_ATOM_INT(_28886)) {
        _28887 = (_39lhs_subs_level_54156 < _28886);
    }
    else {
        _28887 = ((double)_39lhs_subs_level_54156 < DBL_PTR(_28886)->dbl);
    }
    DeRef(_28886);
    _28886 = NOVALUE;
    if (_28887 == 0)
    {
        DeRef(_28887);
        _28887 = NOVALUE;
        goto L1C; // [867] 878
    }
    else{
        DeRef(_28887);
        _28887 = NOVALUE;
    }

    /** 				dangerous = TRUE*/
    _dangerous_56424 = _13TRUE_436;
L1C: 

    /** 			if dangerous then*/
    if (_dangerous_56424 == 0)
    {
        goto L1D; // [880] 894
    }
    else{
    }

    /** 				backpatch(subs1_patch, LHS_SUBS1_COPY)*/
    _41backpatch(_subs1_patch_56422, 166);
L1D: 
L18: 

    /** 		if slice then*/
    if (_slice_56420 == 0)
    {
        goto L1E; // [897] 965
    }
    else{
    }

    /** 			if assign_op != EQUALS then*/
    if (_assign_op_56421 == 3)
    goto L1F; // [904] 938

    /** 				if subs = 1 then*/
    if (_subs_56419 != 1)
    goto L20; // [910] 924

    /** 					emit_op(ASSIGN_OP_SLICE)*/
    _41emit_op(150);
    goto L21; // [921] 932
L20: 

    /** 					emit_op(PASSIGN_OP_SLICE)*/
    _41emit_op(165);
L21: 

    /** 				emit_assign_op(assign_op)*/
    _41emit_assign_op(_assign_op_56421);
L1F: 

    /** 			if subs = 1 then*/
    if (_subs_56419 != 1)
    goto L22; // [940] 954

    /** 				emit_op(ASSIGN_SLICE)*/
    _41emit_op(45);
    goto L23; // [951] 1055
L22: 

    /** 				emit_op(PASSIGN_SLICE)*/
    _41emit_op(163);
    goto L23; // [962] 1055
L1E: 

    /** 			if assign_op = EQUALS then*/
    if (_assign_op_56421 != 3)
    goto L24; // [969] 1000

    /** 				if subs = 1 then*/
    if (_subs_56419 != 1)
    goto L25; // [975] 989

    /** 					emit_op(ASSIGN_SUBS)*/
    _41emit_op(16);
    goto L26; // [986] 1054
L25: 

    /** 					emit_op(PASSIGN_SUBS)*/
    _41emit_op(162);
    goto L26; // [997] 1054
L24: 

    /** 				if subs = 1 then*/
    if (_subs_56419 != 1)
    goto L27; // [1002] 1016

    /** 					emit_op(ASSIGN_OP_SUBS)*/
    _41emit_op(149);
    goto L28; // [1013] 1024
L27: 

    /** 					emit_op(PASSIGN_OP_SUBS)*/
    _41emit_op(164);
L28: 

    /** 				emit_assign_op(assign_op)*/
    _41emit_assign_op(_assign_op_56421);

    /** 				if subs = 1 then*/
    if (_subs_56419 != 1)
    goto L29; // [1031] 1045

    /** 					emit_op(ASSIGN_SUBS2)*/
    _41emit_op(148);
    goto L2A; // [1042] 1053
L29: 

    /** 					emit_op(PASSIGN_SUBS)*/
    _41emit_op(162);
L2A: 
L26: 
L23: 

    /** 		if subs > 1 then*/
    if (_subs_56419 <= 1)
    goto L2B; // [1057] 1109

    /** 			if dangerous then*/
    if (_dangerous_56424 == 0)
    {
        goto L2C; // [1063] 1100
    }
    else{
    }

    /** 				emit_opnd(left_sym)*/
    _41emit_opnd(_39left_sym_54158);

    /** 				emit_opnd(lhs_subs1_copy_temp) -- will be freed*/
    _41emit_opnd(_41lhs_subs1_copy_temp_50235);

    /** 				emit_temp( lhs_subs1_copy_temp, NEW_REFERENCE )*/
    _41emit_temp(_41lhs_subs1_copy_temp_50235, 1);

    /** 				emit_op(ASSIGN)*/
    _41emit_op(18);
    goto L2D; // [1097] 1108
L2C: 

    /** 				TempFree(lhs_subs1_copy_temp)*/
    _41TempFree(_41lhs_subs1_copy_temp_50235);
L2D: 
L2B: 

    /** 		if OpTypeCheck and (left_sym < 0 or SymTab[left_sym][S_VTYPE] != sequence_type) then*/
    if (_35OpTypeCheck_16314 == 0) {
        goto L2E; // [1113] 1163
    }
    _28897 = (_39left_sym_54158 < 0);
    if (_28897 != 0) {
        DeRef(_28898);
        _28898 = 1;
        goto L2F; // [1123] 1151
    }
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _28899 = (int)*(((s1_ptr)_2)->base + _39left_sym_54158);
    _2 = (int)SEQ_PTR(_28899);
    _28900 = (int)*(((s1_ptr)_2)->base + 15);
    _28899 = NOVALUE;
    if (IS_ATOM_INT(_28900)) {
        _28901 = (_28900 != _53sequence_type_46095);
    }
    else {
        _28901 = binary_op(NOTEQ, _28900, _53sequence_type_46095);
    }
    _28900 = NOVALUE;
    if (IS_ATOM_INT(_28901))
    _28898 = (_28901 != 0);
    else
    _28898 = DBL_PTR(_28901)->dbl != 0.0;
L2F: 
    if (_28898 == 0)
    {
        _28898 = NOVALUE;
        goto L2E; // [1152] 1163
    }
    else{
        _28898 = NOVALUE;
    }

    /** 			TypeCheck(left_sym)*/
    _39TypeCheck(_39left_sym_54158);
L2E: 
L17: 

    /** 	current_sequence = head( current_sequence, length( current_sequence ) - 1 )*/
    if (IS_SEQUENCE(_41current_sequence_50230)){
            _28902 = SEQ_PTR(_41current_sequence_50230)->length;
    }
    else {
        _28902 = 1;
    }
    _28903 = _28902 - 1;
    _28902 = NOVALUE;
    {
        int len = SEQ_PTR(_41current_sequence_50230)->length;
        int size = (IS_ATOM_INT(_28903)) ? _28903 : (long)(DBL_PTR(_28903)->dbl);
        if (size <= 0) _41current_sequence_50230 = MAKE_SEQ(NewS1(0));
        else if (len <= size) {
            RefDS(_41current_sequence_50230);
            DeRef(_41current_sequence_50230);
            _41current_sequence_50230 = _41current_sequence_50230;
        }
        else Head(SEQ_PTR(_41current_sequence_50230),size+1,&_41current_sequence_50230);
    }
    _28903 = NOVALUE;

    /** 	if not TRANSLATE then*/
    if (_35TRANSLATE_15887 != 0)
    goto L30; // [1187] 1213

    /** 		if OpTrace then*/
    if (_35OpTrace_16313 == 0)
    {
        goto L31; // [1194] 1212
    }
    else{
    }

    /** 			emit_op(DISPLAY_VAR)*/
    _41emit_op(87);

    /** 			emit_addr(left_sym)*/
    _41emit_addr(_39left_sym_54158);
L31: 
L30: 

    /** end procedure*/
    DeRef(_left_var_56416);
    DeRef(_tok_56418);
    _28857 = NOVALUE;
    DeRef(_28812);
    _28812 = NOVALUE;
    DeRef(_28873);
    _28873 = NOVALUE;
    DeRef(_28882);
    _28882 = NOVALUE;
    DeRef(_28877);
    _28877 = NOVALUE;
    DeRef(_28884);
    _28884 = NOVALUE;
    DeRef(_28897);
    _28897 = NOVALUE;
    DeRef(_28901);
    _28901 = NOVALUE;
    return;
    ;
}


void _39Return_statement()
{
    int _tok_56707 = NOVALUE;
    int _pop_56708 = NOVALUE;
    int _last_op_56714 = NOVALUE;
    int _last_pc_56717 = NOVALUE;
    int _is_tail_56720 = NOVALUE;
    int _28937 = NOVALUE;
    int _28935 = NOVALUE;
    int _28934 = NOVALUE;
    int _28933 = NOVALUE;
    int _28932 = NOVALUE;
    int _28930 = NOVALUE;
    int _28929 = NOVALUE;
    int _28928 = NOVALUE;
    int _28927 = NOVALUE;
    int _28926 = NOVALUE;
    int _28925 = NOVALUE;
    int _28924 = NOVALUE;
    int _28923 = NOVALUE;
    int _28919 = NOVALUE;
    int _28918 = NOVALUE;
    int _28916 = NOVALUE;
    int _28915 = NOVALUE;
    int _28914 = NOVALUE;
    int _28913 = NOVALUE;
    int _28912 = NOVALUE;
    int _28911 = NOVALUE;
    int _28910 = NOVALUE;
    int _28909 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer pop*/

    /** 	if CurrentSub = TopLevelSub then*/
    if (_35CurrentSub_16252 != _35TopLevelSub_16251)
    goto L1; // [9] 21

    /** 		CompileErr(130)*/
    RefDS(_22023);
    _44CompileErr(130, _22023, 0);
L1: 

    /** 	integer*/

    /** 		last_op = Last_op(),*/
    _last_op_56714 = _41Last_op();
    if (!IS_ATOM_INT(_last_op_56714)) {
        _1 = (long)(DBL_PTR(_last_op_56714)->dbl);
        DeRefDS(_last_op_56714);
        _last_op_56714 = _1;
    }

    /** 		last_pc = Last_pc(),*/
    _last_pc_56717 = _41Last_pc();
    if (!IS_ATOM_INT(_last_pc_56717)) {
        _1 = (long)(DBL_PTR(_last_pc_56717)->dbl);
        DeRefDS(_last_pc_56717);
        _last_pc_56717 = _1;
    }

    /** 		is_tail = 0*/
    _is_tail_56720 = 0;

    /** 	if last_op = PROC and length(Code) > last_pc and Code[last_pc+1] = CurrentSub then*/
    _28909 = (_last_op_56714 == 27);
    if (_28909 == 0) {
        _28910 = 0;
        goto L2; // [50] 67
    }
    if (IS_SEQUENCE(_35Code_16332)){
            _28911 = SEQ_PTR(_35Code_16332)->length;
    }
    else {
        _28911 = 1;
    }
    _28912 = (_28911 > _last_pc_56717);
    _28911 = NOVALUE;
    _28910 = (_28912 != 0);
L2: 
    if (_28910 == 0) {
        goto L3; // [67] 97
    }
    _28914 = _last_pc_56717 + 1;
    _2 = (int)SEQ_PTR(_35Code_16332);
    _28915 = (int)*(((s1_ptr)_2)->base + _28914);
    if (IS_ATOM_INT(_28915)) {
        _28916 = (_28915 == _35CurrentSub_16252);
    }
    else {
        _28916 = binary_op(EQUALS, _28915, _35CurrentSub_16252);
    }
    _28915 = NOVALUE;
    if (_28916 == 0) {
        DeRef(_28916);
        _28916 = NOVALUE;
        goto L3; // [88] 97
    }
    else {
        if (!IS_ATOM_INT(_28916) && DBL_PTR(_28916)->dbl == 0.0){
            DeRef(_28916);
            _28916 = NOVALUE;
            goto L3; // [88] 97
        }
        DeRef(_28916);
        _28916 = NOVALUE;
    }
    DeRef(_28916);
    _28916 = NOVALUE;

    /** 		is_tail = 1*/
    _is_tail_56720 = 1;
L3: 

    /** 	if not TRANSLATE then*/
    if (_35TRANSLATE_15887 != 0)
    goto L4; // [101] 127

    /** 		if OpTrace then*/
    if (_35OpTrace_16313 == 0)
    {
        goto L5; // [108] 126
    }
    else{
    }

    /** 			emit_op(ERASE_PRIVATE_NAMES)*/
    _41emit_op(88);

    /** 			emit_addr(CurrentSub)*/
    _41emit_addr(_35CurrentSub_16252);
L5: 
L4: 

    /** 	if SymTab[CurrentSub][S_TOKEN] != PROC then*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _28918 = (int)*(((s1_ptr)_2)->base + _35CurrentSub_16252);
    _2 = (int)SEQ_PTR(_28918);
    if (!IS_ATOM_INT(_35S_TOKEN_15922)){
        _28919 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TOKEN_15922)->dbl));
    }
    else{
        _28919 = (int)*(((s1_ptr)_2)->base + _35S_TOKEN_15922);
    }
    _28918 = NOVALUE;
    if (binary_op_a(EQUALS, _28919, 27)){
        _28919 = NOVALUE;
        goto L6; // [145] 271
    }
    _28919 = NOVALUE;

    /** 		Expr()*/
    _39Expr();

    /** 		last_op = Last_op()*/
    _last_op_56714 = _41Last_op();
    if (!IS_ATOM_INT(_last_op_56714)) {
        _1 = (long)(DBL_PTR(_last_op_56714)->dbl);
        DeRefDS(_last_op_56714);
        _last_op_56714 = _1;
    }

    /** 		last_pc = Last_pc()*/
    _last_pc_56717 = _41Last_pc();
    if (!IS_ATOM_INT(_last_pc_56717)) {
        _1 = (long)(DBL_PTR(_last_pc_56717)->dbl);
        DeRefDS(_last_pc_56717);
        _last_pc_56717 = _1;
    }

    /** 		if last_op = PROC and length(Code) > last_pc and Code[last_pc+1] = CurrentSub then*/
    _28923 = (_last_op_56714 == 27);
    if (_28923 == 0) {
        _28924 = 0;
        goto L7; // [175] 192
    }
    if (IS_SEQUENCE(_35Code_16332)){
            _28925 = SEQ_PTR(_35Code_16332)->length;
    }
    else {
        _28925 = 1;
    }
    _28926 = (_28925 > _last_pc_56717);
    _28925 = NOVALUE;
    _28924 = (_28926 != 0);
L7: 
    if (_28924 == 0) {
        goto L8; // [192] 251
    }
    _28928 = _last_pc_56717 + 1;
    _2 = (int)SEQ_PTR(_35Code_16332);
    _28929 = (int)*(((s1_ptr)_2)->base + _28928);
    if (IS_ATOM_INT(_28929)) {
        _28930 = (_28929 == _35CurrentSub_16252);
    }
    else {
        _28930 = binary_op(EQUALS, _28929, _35CurrentSub_16252);
    }
    _28929 = NOVALUE;
    if (_28930 == 0) {
        DeRef(_28930);
        _28930 = NOVALUE;
        goto L8; // [213] 251
    }
    else {
        if (!IS_ATOM_INT(_28930) && DBL_PTR(_28930)->dbl == 0.0){
            DeRef(_28930);
            _28930 = NOVALUE;
            goto L8; // [213] 251
        }
        DeRef(_28930);
        _28930 = NOVALUE;
    }
    DeRef(_28930);
    _28930 = NOVALUE;

    /** 			pop = Pop() -- prevent cg_stack (code generation stack) leakage*/
    _pop_56708 = _41Pop();
    if (!IS_ATOM_INT(_pop_56708)) {
        _1 = (long)(DBL_PTR(_pop_56708)->dbl);
        DeRefDS(_pop_56708);
        _pop_56708 = _1;
    }

    /** 			Code[Last_pc()] = PROC_TAIL*/
    _28932 = _41Last_pc();
    _2 = (int)SEQ_PTR(_35Code_16332);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _35Code_16332 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_28932))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_28932)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _28932);
    _1 = *(int *)_2;
    *(int *)_2 = 203;
    DeRef(_1);

    /** 			if object(pop_temps()) then end if*/
    _28933 = _41pop_temps();
    if( NOVALUE == _28933 ){
        _28934 = 0;
    }
    else{
        if (IS_ATOM_INT(_28933))
        _28934 = 1;
        else if (IS_ATOM_DBL(_28933)) {
             if (IS_ATOM_INT(DoubleToInt(_28933))) {
                 _28934 = 1;
                 } else {
                     _28934 = 2;
                } } else if (IS_SEQUENCE(_28933))
                _28934 = 3;
                else
                _28934 = 0;
            }
            DeRef(_28933);
            _28933 = NOVALUE;
            if (_28934 == 0)
            {
                _28934 = NOVALUE;
                goto L9; // [244] 298
            }
            else{
                _28934 = NOVALUE;
            }
            goto L9; // [248] 298
L8: 

            /** 			FuncReturn = TRUE*/
            _39FuncReturn_54125 = _13TRUE_436;

            /** 			emit_op(RETURNF)*/
            _41emit_op(28);
            goto L9; // [268] 298
L6: 

            /** 		if is_tail then*/
            if (_is_tail_56720 == 0)
            {
                goto LA; // [273] 290
            }
            else{
            }

            /** 			Code[Last_pc()] = PROC_TAIL*/
            _28935 = _41Last_pc();
            _2 = (int)SEQ_PTR(_35Code_16332);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _35Code_16332 = MAKE_SEQ(_2);
            }
            if (!IS_ATOM_INT(_28935))
            _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_28935)->dbl));
            else
            _2 = (int)(((s1_ptr)_2)->base + _28935);
            _1 = *(int *)_2;
            *(int *)_2 = 203;
            DeRef(_1);
LA: 

            /** 		emit_op(RETURNP)*/
            _41emit_op(29);
L9: 

            /** 	tok = next_token()*/
            _0 = _tok_56707;
            _tok_56707 = _39next_token();
            DeRef(_0);

            /** 	putback(tok)*/
            Ref(_tok_56707);
            _39putback(_tok_56707);

            /** 	NotReached(tok[T_ID], "return")*/
            _2 = (int)SEQ_PTR(_tok_56707);
            _28937 = (int)*(((s1_ptr)_2)->base + 1);
            Ref(_28937);
            RefDS(_26394);
            _39NotReached(_28937, _26394);
            _28937 = NOVALUE;

            /** end procedure*/
            DeRef(_tok_56707);
            DeRef(_28909);
            _28909 = NOVALUE;
            DeRef(_28912);
            _28912 = NOVALUE;
            DeRef(_28914);
            _28914 = NOVALUE;
            DeRef(_28923);
            _28923 = NOVALUE;
            DeRef(_28926);
            _28926 = NOVALUE;
            DeRef(_28928);
            _28928 = NOVALUE;
            DeRef(_28932);
            _28932 = NOVALUE;
            DeRef(_28935);
            _28935 = NOVALUE;
            return;
    ;
}


int _39exit_level(int _tok_56796, int _flag_56797)
{
    int _arg_56798 = NOVALUE;
    int _n_56799 = NOVALUE;
    int _num_labels_56800 = NOVALUE;
    int _negative_56801 = NOVALUE;
    int _labels_56802 = NOVALUE;
    int _28967 = NOVALUE;
    int _28966 = NOVALUE;
    int _28965 = NOVALUE;
    int _28964 = NOVALUE;
    int _28963 = NOVALUE;
    int _28959 = NOVALUE;
    int _28958 = NOVALUE;
    int _28957 = NOVALUE;
    int _28955 = NOVALUE;
    int _28954 = NOVALUE;
    int _28953 = NOVALUE;
    int _28952 = NOVALUE;
    int _28950 = NOVALUE;
    int _28945 = NOVALUE;
    int _28944 = NOVALUE;
    int _28942 = NOVALUE;
    int _28939 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer negative = 0*/
    _negative_56801 = 0;

    /** 	if flag then*/
    if (_flag_56797 == 0)
    {
        goto L1; // [10] 25
    }
    else{
    }

    /** 		labels = if_labels*/
    RefDS(_39if_labels_54146);
    DeRef(_labels_56802);
    _labels_56802 = _39if_labels_54146;
    goto L2; // [22] 35
L1: 

    /** 		labels = loop_labels*/
    RefDS(_39loop_labels_54145);
    DeRef(_labels_56802);
    _labels_56802 = _39loop_labels_54145;
L2: 

    /** 	num_labels = length(labels)*/
    if (IS_SEQUENCE(_labels_56802)){
            _num_labels_56800 = SEQ_PTR(_labels_56802)->length;
    }
    else {
        _num_labels_56800 = 1;
    }

    /** 	if tok[T_ID] = MINUS then*/
    _2 = (int)SEQ_PTR(_tok_56796);
    _28939 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28939, 10)){
        _28939 = NOVALUE;
        goto L3; // [52] 67
    }
    _28939 = NOVALUE;

    /** 		tok = next_token()*/
    _0 = _tok_56796;
    _tok_56796 = _39next_token();
    DeRef(_0);

    /** 		negative = 1*/
    _negative_56801 = 1;
L3: 

    /** 	if tok[T_ID]=ATOM then*/
    _2 = (int)SEQ_PTR(_tok_56796);
    _28942 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28942, 502)){
        _28942 = NOVALUE;
        goto L4; // [77] 178
    }
    _28942 = NOVALUE;

    /** 		arg = SymTab[tok[T_SYM]][S_OBJ]*/
    _2 = (int)SEQ_PTR(_tok_56796);
    _28944 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!IS_ATOM_INT(_28944)){
        _28945 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_28944)->dbl));
    }
    else{
        _28945 = (int)*(((s1_ptr)_2)->base + _28944);
    }
    DeRef(_arg_56798);
    _2 = (int)SEQ_PTR(_28945);
    _arg_56798 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_arg_56798);
    _28945 = NOVALUE;

    /** 		n = floor(arg)*/
    if (IS_ATOM_INT(_arg_56798))
    _n_56799 = e_floor(_arg_56798);
    else
    _n_56799 = unary_op(FLOOR, _arg_56798);
    if (!IS_ATOM_INT(_n_56799)) {
        _1 = (long)(DBL_PTR(_n_56799)->dbl);
        DeRefDS(_n_56799);
        _n_56799 = _1;
    }

    /** 		if negative then*/
    if (_negative_56801 == 0)
    {
        goto L5; // [110] 122
    }
    else{
    }

    /** 			n = num_labels - n*/
    _n_56799 = _num_labels_56800 - _n_56799;
    goto L6; // [119] 135
L5: 

    /** 		elsif n = 0 then*/
    if (_n_56799 != 0)
    goto L7; // [124] 134

    /** 			n = num_labels*/
    _n_56799 = _num_labels_56800;
L7: 
L6: 

    /** 		if n<=0 or n>num_labels then*/
    _28950 = (_n_56799 <= 0);
    if (_28950 != 0) {
        goto L8; // [141] 154
    }
    _28952 = (_n_56799 > _num_labels_56800);
    if (_28952 == 0)
    {
        DeRef(_28952);
        _28952 = NOVALUE;
        goto L9; // [150] 162
    }
    else{
        DeRef(_28952);
        _28952 = NOVALUE;
    }
L8: 

    /** 			CompileErr(87)*/
    RefDS(_22023);
    _44CompileErr(87, _22023, 0);
L9: 

    /** 		return {n, next_token()}*/
    _28953 = _39next_token();
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _n_56799;
    ((int *)_2)[2] = _28953;
    _28954 = MAKE_SEQ(_1);
    _28953 = NOVALUE;
    DeRef(_tok_56796);
    DeRef(_arg_56798);
    DeRef(_labels_56802);
    _28944 = NOVALUE;
    DeRef(_28950);
    _28950 = NOVALUE;
    return _28954;
    goto LA; // [175] 266
L4: 

    /** 	elsif tok[T_ID]=STRING then*/
    _2 = (int)SEQ_PTR(_tok_56796);
    _28955 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28955, 503)){
        _28955 = NOVALUE;
        goto LB; // [188] 255
    }
    _28955 = NOVALUE;

    /** 		n = find(SymTab[tok[T_SYM]][S_OBJ],labels)*/
    _2 = (int)SEQ_PTR(_tok_56796);
    _28957 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!IS_ATOM_INT(_28957)){
        _28958 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_28957)->dbl));
    }
    else{
        _28958 = (int)*(((s1_ptr)_2)->base + _28957);
    }
    _2 = (int)SEQ_PTR(_28958);
    _28959 = (int)*(((s1_ptr)_2)->base + 1);
    _28958 = NOVALUE;
    _n_56799 = find_from(_28959, _labels_56802, 1);
    _28959 = NOVALUE;

    /** 		if n = 0 then*/
    if (_n_56799 != 0)
    goto LC; // [219] 231

    /** 			CompileErr(152)*/
    RefDS(_22023);
    _44CompileErr(152, _22023, 0);
LC: 

    /** 		return {num_labels + 1 - n, next_token()}*/
    _28963 = _num_labels_56800 + 1;
    if (_28963 > MAXINT){
        _28963 = NewDouble((double)_28963);
    }
    if (IS_ATOM_INT(_28963)) {
        _28964 = _28963 - _n_56799;
        if ((long)((unsigned long)_28964 +(unsigned long) HIGH_BITS) >= 0){
            _28964 = NewDouble((double)_28964);
        }
    }
    else {
        _28964 = NewDouble(DBL_PTR(_28963)->dbl - (double)_n_56799);
    }
    DeRef(_28963);
    _28963 = NOVALUE;
    _28965 = _39next_token();
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _28964;
    ((int *)_2)[2] = _28965;
    _28966 = MAKE_SEQ(_1);
    _28965 = NOVALUE;
    _28964 = NOVALUE;
    DeRef(_tok_56796);
    DeRef(_arg_56798);
    DeRef(_labels_56802);
    _28944 = NOVALUE;
    DeRef(_28950);
    _28950 = NOVALUE;
    DeRef(_28954);
    _28954 = NOVALUE;
    _28957 = NOVALUE;
    return _28966;
    goto LA; // [252] 266
LB: 

    /** 		return {1, tok} -- no parameters*/
    Ref(_tok_56796);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = _tok_56796;
    _28967 = MAKE_SEQ(_1);
    DeRef(_tok_56796);
    DeRef(_arg_56798);
    DeRef(_labels_56802);
    _28944 = NOVALUE;
    DeRef(_28950);
    _28950 = NOVALUE;
    DeRef(_28954);
    _28954 = NOVALUE;
    _28957 = NOVALUE;
    DeRef(_28966);
    _28966 = NOVALUE;
    return _28967;
LA: 
    ;
}


void _39GLabel_statement()
{
    int _tok_56860 = NOVALUE;
    int _labbel_56861 = NOVALUE;
    int _laddr_56862 = NOVALUE;
    int _n_56863 = NOVALUE;
    int _28986 = NOVALUE;
    int _28984 = NOVALUE;
    int _28983 = NOVALUE;
    int _28982 = NOVALUE;
    int _28981 = NOVALUE;
    int _28979 = NOVALUE;
    int _28976 = NOVALUE;
    int _28974 = NOVALUE;
    int _28972 = NOVALUE;
    int _28971 = NOVALUE;
    int _28969 = NOVALUE;
    int _0, _1, _2;
    

    /** 	object labbel*/

    /** 	object laddr*/

    /** 	integer n*/

    /** 	tok = next_token()*/
    _0 = _tok_56860;
    _tok_56860 = _39next_token();
    DeRef(_0);

    /** 	if tok[T_ID] != STRING then*/
    _2 = (int)SEQ_PTR(_tok_56860);
    _28969 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _28969, 503)){
        _28969 = NOVALUE;
        goto L1; // [22] 34
    }
    _28969 = NOVALUE;

    /** 		CompileErr(35)*/
    RefDS(_22023);
    _44CompileErr(35, _22023, 0);
L1: 

    /** 	labbel = SymTab[tok[T_SYM]][S_OBJ]*/
    _2 = (int)SEQ_PTR(_tok_56860);
    _28971 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!IS_ATOM_INT(_28971)){
        _28972 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_28971)->dbl));
    }
    else{
        _28972 = (int)*(((s1_ptr)_2)->base + _28971);
    }
    DeRef(_labbel_56861);
    _2 = (int)SEQ_PTR(_28972);
    _labbel_56861 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_labbel_56861);
    _28972 = NOVALUE;

    /** 	laddr = length(Code) + 1*/
    if (IS_SEQUENCE(_35Code_16332)){
            _28974 = SEQ_PTR(_35Code_16332)->length;
    }
    else {
        _28974 = 1;
    }
    _laddr_56862 = _28974 + 1;
    _28974 = NOVALUE;

    /** 	if find(labbel, goto_labels) then*/
    _28976 = find_from(_labbel_56861, _39goto_labels_54128, 1);
    if (_28976 == 0)
    {
        _28976 = NOVALUE;
        goto L2; // [74] 85
    }
    else{
        _28976 = NOVALUE;
    }

    /** 		CompileErr(59)*/
    RefDS(_22023);
    _44CompileErr(59, _22023, 0);
L2: 

    /** 	goto_labels = append(goto_labels, labbel)*/
    Ref(_labbel_56861);
    Append(&_39goto_labels_54128, _39goto_labels_54128, _labbel_56861);

    /** 	goto_addr = append(goto_addr, laddr)*/
    Append(&_39goto_addr_54129, _39goto_addr_54129, _laddr_56862);

    /** 	label_block = append( label_block, top_block() )*/
    _28979 = _66top_block(0);
    Ref(_28979);
    Append(&_39label_block_54132, _39label_block_54132, _28979);
    DeRef(_28979);
    _28979 = NOVALUE;

    /** 	while n with entry do*/
    goto L3; // [115] 174
L4: 
    if (_n_56863 == 0)
    {
        goto L5; // [120] 188
    }
    else{
    }

    /** 		backpatch(goto_list[n], laddr)*/
    _2 = (int)SEQ_PTR(_35goto_list_16355);
    _28981 = (int)*(((s1_ptr)_2)->base + _n_56863);
    Ref(_28981);
    _41backpatch(_28981, _laddr_56862);
    _28981 = NOVALUE;

    /** 		set_glabel_block( goto_ref[n], top_block() )*/
    _2 = (int)SEQ_PTR(_39goto_ref_54131);
    _28982 = (int)*(((s1_ptr)_2)->base + _n_56863);
    _28983 = _66top_block(0);
    Ref(_28982);
    _38set_glabel_block(_28982, _28983);
    _28982 = NOVALUE;
    _28983 = NOVALUE;

    /** 		goto_delay[n] = "" --clear it*/
    RefDS(_22023);
    _2 = (int)SEQ_PTR(_35goto_delay_16354);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _35goto_delay_16354 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _n_56863);
    _1 = *(int *)_2;
    *(int *)_2 = _22023;
    DeRef(_1);

    /** 		goto_line[n] = {-1,""} --clear it*/
    RefDS(_22023);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -1;
    ((int *)_2)[2] = _22023;
    _28984 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_39goto_line_54127);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _39goto_line_54127 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _n_56863);
    _1 = *(int *)_2;
    *(int *)_2 = _28984;
    if( _1 != _28984 ){
        DeRef(_1);
    }
    _28984 = NOVALUE;

    /** 	entry*/
L3: 

    /** 		n = find(labbel, goto_delay)*/
    _n_56863 = find_from(_labbel_56861, _35goto_delay_16354, 1);

    /** 	end while*/
    goto L4; // [185] 118
L5: 

    /** 	force_uninitialize( map:get( goto_init, labbel, {} ) )*/
    Ref(_39goto_init_54134);
    Ref(_labbel_56861);
    RefDS(_22023);
    _28986 = _28get(_39goto_init_54134, _labbel_56861, _22023);
    _39force_uninitialize(_28986);
    _28986 = NOVALUE;

    /** 	if TRANSLATE then*/
    if (_35TRANSLATE_15887 == 0)
    {
        goto L6; // [205] 221
    }
    else{
    }

    /** 		emit_op(GLABEL)*/
    _41emit_op(189);

    /** 		emit_addr(laddr)*/
    _41emit_addr(_laddr_56862);
L6: 

    /** end procedure*/
    DeRef(_tok_56860);
    DeRef(_labbel_56861);
    _28971 = NOVALUE;
    return;
    ;
}


void _39Goto_statement()
{
    int _tok_56910 = NOVALUE;
    int _n_56911 = NOVALUE;
    int _num_labels_56912 = NOVALUE;
    int _31650 = NOVALUE;
    int _29025 = NOVALUE;
    int _29024 = NOVALUE;
    int _29021 = NOVALUE;
    int _29020 = NOVALUE;
    int _29019 = NOVALUE;
    int _29018 = NOVALUE;
    int _29017 = NOVALUE;
    int _29016 = NOVALUE;
    int _29015 = NOVALUE;
    int _29014 = NOVALUE;
    int _29013 = NOVALUE;
    int _29012 = NOVALUE;
    int _29011 = NOVALUE;
    int _29010 = NOVALUE;
    int _29008 = NOVALUE;
    int _29007 = NOVALUE;
    int _29005 = NOVALUE;
    int _29004 = NOVALUE;
    int _29002 = NOVALUE;
    int _29001 = NOVALUE;
    int _28999 = NOVALUE;
    int _28998 = NOVALUE;
    int _28997 = NOVALUE;
    int _28996 = NOVALUE;
    int _28993 = NOVALUE;
    int _28992 = NOVALUE;
    int _28991 = NOVALUE;
    int _28989 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer n*/

    /** 	integer num_labels*/

    /** 	tok = next_token()*/
    _0 = _tok_56910;
    _tok_56910 = _39next_token();
    DeRef(_0);

    /** 	num_labels = length(goto_labels)*/
    if (IS_SEQUENCE(_39goto_labels_54128)){
            _num_labels_56912 = SEQ_PTR(_39goto_labels_54128)->length;
    }
    else {
        _num_labels_56912 = 1;
    }

    /** 	if tok[T_ID]=STRING then*/
    _2 = (int)SEQ_PTR(_tok_56910);
    _28989 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28989, 503)){
        _28989 = NOVALUE;
        goto L1; // [27] 269
    }
    _28989 = NOVALUE;

    /** 		n = find(SymTab[tok[T_SYM]][S_OBJ],goto_labels)*/
    _2 = (int)SEQ_PTR(_tok_56910);
    _28991 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!IS_ATOM_INT(_28991)){
        _28992 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_28991)->dbl));
    }
    else{
        _28992 = (int)*(((s1_ptr)_2)->base + _28991);
    }
    _2 = (int)SEQ_PTR(_28992);
    _28993 = (int)*(((s1_ptr)_2)->base + 1);
    _28992 = NOVALUE;
    _n_56911 = find_from(_28993, _39goto_labels_54128, 1);
    _28993 = NOVALUE;

    /** 		if n = 0 then*/
    if (_n_56911 != 0)
    goto L2; // [60] 243

    /** 			goto_delay &= {SymTab[tok[T_SYM]][S_OBJ]}*/
    _2 = (int)SEQ_PTR(_tok_56910);
    _28996 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!IS_ATOM_INT(_28996)){
        _28997 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_28996)->dbl));
    }
    else{
        _28997 = (int)*(((s1_ptr)_2)->base + _28996);
    }
    _2 = (int)SEQ_PTR(_28997);
    _28998 = (int)*(((s1_ptr)_2)->base + 1);
    _28997 = NOVALUE;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_28998);
    *((int *)(_2+4)) = _28998;
    _28999 = MAKE_SEQ(_1);
    _28998 = NOVALUE;
    Concat((object_ptr)&_35goto_delay_16354, _35goto_delay_16354, _28999);
    DeRefDS(_28999);
    _28999 = NOVALUE;

    /** 			goto_list &= length(Code)+2 --not 1???*/
    if (IS_SEQUENCE(_35Code_16332)){
            _29001 = SEQ_PTR(_35Code_16332)->length;
    }
    else {
        _29001 = 1;
    }
    _29002 = _29001 + 2;
    _29001 = NOVALUE;
    Append(&_35goto_list_16355, _35goto_list_16355, _29002);
    _29002 = NOVALUE;

    /** 			goto_line &= {{line_number,ThisLine}}*/
    Ref(_44ThisLine_48518);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _35line_number_16245;
    ((int *)_2)[2] = _44ThisLine_48518;
    _29004 = MAKE_SEQ(_1);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _29004;
    _29005 = MAKE_SEQ(_1);
    _29004 = NOVALUE;
    Concat((object_ptr)&_39goto_line_54127, _39goto_line_54127, _29005);
    DeRefDS(_29005);
    _29005 = NOVALUE;

    /** 			goto_ref &= new_forward_reference( GOTO, top_block() )*/
    _29007 = _66top_block(0);
    _31650 = 188;
    _29008 = _38new_forward_reference(188, _29007, 188);
    _29007 = NOVALUE;
    _31650 = NOVALUE;
    if (IS_SEQUENCE(_39goto_ref_54131) && IS_ATOM(_29008)) {
        Ref(_29008);
        Append(&_39goto_ref_54131, _39goto_ref_54131, _29008);
    }
    else if (IS_ATOM(_39goto_ref_54131) && IS_SEQUENCE(_29008)) {
    }
    else {
        Concat((object_ptr)&_39goto_ref_54131, _39goto_ref_54131, _29008);
    }
    DeRef(_29008);
    _29008 = NOVALUE;

    /** 			map:put( goto_init, SymTab[tok[T_SYM]][S_OBJ], get_private_uninitialized() )*/
    _2 = (int)SEQ_PTR(_tok_56910);
    _29010 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!IS_ATOM_INT(_29010)){
        _29011 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_29010)->dbl));
    }
    else{
        _29011 = (int)*(((s1_ptr)_2)->base + _29010);
    }
    _2 = (int)SEQ_PTR(_29011);
    _29012 = (int)*(((s1_ptr)_2)->base + 1);
    _29011 = NOVALUE;
    _29013 = _39get_private_uninitialized();
    Ref(_39goto_init_54134);
    Ref(_29012);
    _28put(_39goto_init_54134, _29012, _29013, 1, 23);
    _29012 = NOVALUE;
    _29013 = NOVALUE;

    /** 			add_data( goto_ref[$], sym_obj( tok[T_SYM] ) )*/
    if (IS_SEQUENCE(_39goto_ref_54131)){
            _29014 = SEQ_PTR(_39goto_ref_54131)->length;
    }
    else {
        _29014 = 1;
    }
    _2 = (int)SEQ_PTR(_39goto_ref_54131);
    _29015 = (int)*(((s1_ptr)_2)->base + _29014);
    _2 = (int)SEQ_PTR(_tok_56910);
    _29016 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_29016);
    _29017 = _53sym_obj(_29016);
    _29016 = NOVALUE;
    Ref(_29015);
    _38add_data(_29015, _29017);
    _29015 = NOVALUE;
    _29017 = NOVALUE;

    /** 			set_line( goto_ref[$], line_number, ThisLine, bp )*/
    if (IS_SEQUENCE(_39goto_ref_54131)){
            _29018 = SEQ_PTR(_39goto_ref_54131)->length;
    }
    else {
        _29018 = 1;
    }
    _2 = (int)SEQ_PTR(_39goto_ref_54131);
    _29019 = (int)*(((s1_ptr)_2)->base + _29018);
    Ref(_29019);
    Ref(_44ThisLine_48518);
    _38set_line(_29019, _35line_number_16245, _44ThisLine_48518, _44bp_48522);
    _29019 = NOVALUE;
    goto L3; // [240] 261
L2: 

    /** 			Goto_block( top_block(), label_block[n] )*/
    _29020 = _66top_block(0);
    _2 = (int)SEQ_PTR(_39label_block_54132);
    _29021 = (int)*(((s1_ptr)_2)->base + _n_56911);
    Ref(_29021);
    _66Goto_block(_29020, _29021, 0);
    _29020 = NOVALUE;
    _29021 = NOVALUE;
L3: 

    /** 		tok = next_token()*/
    _0 = _tok_56910;
    _tok_56910 = _39next_token();
    DeRef(_0);
    goto L4; // [266] 277
L1: 

    /** 		CompileErr(96)*/
    RefDS(_22023);
    _44CompileErr(96, _22023, 0);
L4: 

    /** 	emit_op(GOTO)*/
    _41emit_op(188);

    /** 	if n = 0 then*/
    if (_n_56911 != 0)
    goto L5; // [288] 300

    /** 		emit_addr(0) -- to be back-patched*/
    _41emit_addr(0);
    goto L6; // [297] 312
L5: 

    /** 		emit_addr(goto_addr[n])*/
    _2 = (int)SEQ_PTR(_39goto_addr_54129);
    _29024 = (int)*(((s1_ptr)_2)->base + _n_56911);
    Ref(_29024);
    _41emit_addr(_29024);
    _29024 = NOVALUE;
L6: 

    /** 	putback(tok)*/
    Ref(_tok_56910);
    _39putback(_tok_56910);

    /** 	NotReached(tok[T_ID], "goto")*/
    _2 = (int)SEQ_PTR(_tok_56910);
    _29025 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_29025);
    RefDS(_26336);
    _39NotReached(_29025, _26336);
    _29025 = NOVALUE;

    /** end procedure*/
    DeRef(_tok_56910);
    _28991 = NOVALUE;
    _28996 = NOVALUE;
    _29010 = NOVALUE;
    return;
    ;
}


void _39Exit_statement()
{
    int _addr_inlined_AppendXList_at_63_57013 = NOVALUE;
    int _tok_56996 = NOVALUE;
    int _by_ref_56997 = NOVALUE;
    int _29033 = NOVALUE;
    int _29032 = NOVALUE;
    int _29031 = NOVALUE;
    int _29030 = NOVALUE;
    int _29028 = NOVALUE;
    int _29026 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence by_ref*/

    /** 	if not length(loop_stack) then*/
    if (IS_SEQUENCE(_39loop_stack_54151)){
            _29026 = SEQ_PTR(_39loop_stack_54151)->length;
    }
    else {
        _29026 = 1;
    }
    if (_29026 != 0)
    goto L1; // [10] 21
    _29026 = NOVALUE;

    /** 		CompileErr(88)*/
    RefDS(_22023);
    _44CompileErr(88, _22023, 0);
L1: 

    /** 	by_ref = exit_level(next_token(),0) -- can't pass tok by reference*/
    _29028 = _39next_token();
    _0 = _by_ref_56997;
    _by_ref_56997 = _39exit_level(_29028, 0);
    DeRef(_0);
    _29028 = NOVALUE;

    /** 	Leave_blocks( by_ref[1], LOOP_BLOCK )*/
    _2 = (int)SEQ_PTR(_by_ref_56997);
    _29030 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_29030);
    _66Leave_blocks(_29030, 1);
    _29030 = NOVALUE;

    /** 	emit_op(EXIT)*/
    _41emit_op(61);

    /** 	AppendXList(length(Code)+1)*/
    if (IS_SEQUENCE(_35Code_16332)){
            _29031 = SEQ_PTR(_35Code_16332)->length;
    }
    else {
        _29031 = 1;
    }
    _29032 = _29031 + 1;
    _29031 = NOVALUE;
    _addr_inlined_AppendXList_at_63_57013 = _29032;
    _29032 = NOVALUE;

    /** 	exit_list = append(exit_list, addr)*/
    Append(&_39exit_list_54137, _39exit_list_54137, _addr_inlined_AppendXList_at_63_57013);

    /** end procedure*/
    goto L2; // [78] 81
L2: 

    /** 	exit_delay &= by_ref[1]*/
    _2 = (int)SEQ_PTR(_by_ref_56997);
    _29033 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_39exit_delay_54138) && IS_ATOM(_29033)) {
        Ref(_29033);
        Append(&_39exit_delay_54138, _39exit_delay_54138, _29033);
    }
    else if (IS_ATOM(_39exit_delay_54138) && IS_SEQUENCE(_29033)) {
    }
    else {
        Concat((object_ptr)&_39exit_delay_54138, _39exit_delay_54138, _29033);
    }
    _29033 = NOVALUE;

    /** 	emit_forward_addr()    -- to be back-patched*/
    _39emit_forward_addr();

    /** 	tok = by_ref[2]*/
    DeRef(_tok_56996);
    _2 = (int)SEQ_PTR(_by_ref_56997);
    _tok_56996 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_tok_56996);

    /** 	putback(tok)*/
    Ref(_tok_56996);
    _39putback(_tok_56996);

    /** end procedure*/
    DeRef(_tok_56996);
    DeRefDS(_by_ref_56997);
    return;
    ;
}


void _39Continue_statement()
{
    int _addr_inlined_AppendNList_at_149_57057 = NOVALUE;
    int _tok_57020 = NOVALUE;
    int _by_ref_57021 = NOVALUE;
    int _loop_level_57022 = NOVALUE;
    int _29059 = NOVALUE;
    int _29056 = NOVALUE;
    int _29055 = NOVALUE;
    int _29054 = NOVALUE;
    int _29053 = NOVALUE;
    int _29052 = NOVALUE;
    int _29051 = NOVALUE;
    int _29049 = NOVALUE;
    int _29048 = NOVALUE;
    int _29047 = NOVALUE;
    int _29046 = NOVALUE;
    int _29045 = NOVALUE;
    int _29044 = NOVALUE;
    int _29043 = NOVALUE;
    int _29042 = NOVALUE;
    int _29040 = NOVALUE;
    int _29038 = NOVALUE;
    int _29036 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence by_ref*/

    /** 	integer loop_level*/

    /** 	if not length(loop_stack) then*/
    if (IS_SEQUENCE(_39loop_stack_54151)){
            _29036 = SEQ_PTR(_39loop_stack_54151)->length;
    }
    else {
        _29036 = 1;
    }
    if (_29036 != 0)
    goto L1; // [12] 23
    _29036 = NOVALUE;

    /** 		CompileErr(49)*/
    RefDS(_22023);
    _44CompileErr(49, _22023, 0);
L1: 

    /** 	by_ref = exit_level(next_token(),0) -- can't pass tok by reference*/
    _29038 = _39next_token();
    _0 = _by_ref_57021;
    _by_ref_57021 = _39exit_level(_29038, 0);
    DeRef(_0);
    _29038 = NOVALUE;

    /** 	Leave_blocks( by_ref[1], LOOP_BLOCK )*/
    _2 = (int)SEQ_PTR(_by_ref_57021);
    _29040 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_29040);
    _66Leave_blocks(_29040, 1);
    _29040 = NOVALUE;

    /** 	emit_op(ELSE)*/
    _41emit_op(23);

    /** 	loop_level = by_ref[1]*/
    _2 = (int)SEQ_PTR(_by_ref_57021);
    _loop_level_57022 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_loop_level_57022))
    _loop_level_57022 = (long)DBL_PTR(_loop_level_57022)->dbl;

    /** 	if continue_addr[$+1-loop_level] then -- address is known for while loops*/
    if (IS_SEQUENCE(_39continue_addr_54142)){
            _29042 = SEQ_PTR(_39continue_addr_54142)->length;
    }
    else {
        _29042 = 1;
    }
    _29043 = _29042 + 1;
    _29042 = NOVALUE;
    _29044 = _29043 - _loop_level_57022;
    _29043 = NOVALUE;
    _2 = (int)SEQ_PTR(_39continue_addr_54142);
    _29045 = (int)*(((s1_ptr)_2)->base + _29044);
    if (_29045 == 0)
    {
        _29045 = NOVALUE;
        goto L2; // [79] 138
    }
    else{
        _29045 = NOVALUE;
    }

    /** 		if continue_addr[$+1-loop_level] < 0 then*/
    if (IS_SEQUENCE(_39continue_addr_54142)){
            _29046 = SEQ_PTR(_39continue_addr_54142)->length;
    }
    else {
        _29046 = 1;
    }
    _29047 = _29046 + 1;
    _29046 = NOVALUE;
    _29048 = _29047 - _loop_level_57022;
    _29047 = NOVALUE;
    _2 = (int)SEQ_PTR(_39continue_addr_54142);
    _29049 = (int)*(((s1_ptr)_2)->base + _29048);
    if (_29049 >= 0)
    goto L3; // [101] 113

    /** 			CompileErr(49)*/
    RefDS(_22023);
    _44CompileErr(49, _22023, 0);
L3: 

    /** 		emit_addr(continue_addr[$+1-loop_level])*/
    if (IS_SEQUENCE(_39continue_addr_54142)){
            _29051 = SEQ_PTR(_39continue_addr_54142)->length;
    }
    else {
        _29051 = 1;
    }
    _29052 = _29051 + 1;
    _29051 = NOVALUE;
    _29053 = _29052 - _loop_level_57022;
    _29052 = NOVALUE;
    _2 = (int)SEQ_PTR(_39continue_addr_54142);
    _29054 = (int)*(((s1_ptr)_2)->base + _29053);
    _41emit_addr(_29054);
    _29054 = NOVALUE;
    goto L4; // [135] 182
L2: 

    /** 		AppendNList(length(Code)+1)*/
    if (IS_SEQUENCE(_35Code_16332)){
            _29055 = SEQ_PTR(_35Code_16332)->length;
    }
    else {
        _29055 = 1;
    }
    _29056 = _29055 + 1;
    _29055 = NOVALUE;
    _addr_inlined_AppendNList_at_149_57057 = _29056;
    _29056 = NOVALUE;

    /** 	continue_list = append(continue_list, addr)*/
    Append(&_39continue_list_54139, _39continue_list_54139, _addr_inlined_AppendNList_at_149_57057);

    /** end procedure*/
    goto L5; // [164] 167
L5: 

    /** 		continue_delay &= loop_level*/
    Append(&_39continue_delay_54140, _39continue_delay_54140, _loop_level_57022);

    /** 		emit_forward_addr()    -- to be back-patched*/
    _39emit_forward_addr();
L4: 

    /** 	tok = by_ref[2]*/
    DeRef(_tok_57020);
    _2 = (int)SEQ_PTR(_by_ref_57021);
    _tok_57020 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_tok_57020);

    /** 	putback(tok)*/
    Ref(_tok_57020);
    _39putback(_tok_57020);

    /** 	NotReached(tok[T_ID], "continue")*/
    _2 = (int)SEQ_PTR(_tok_57020);
    _29059 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_29059);
    RefDS(_26298);
    _39NotReached(_29059, _26298);
    _29059 = NOVALUE;

    /** end procedure*/
    DeRef(_tok_57020);
    DeRefDS(_by_ref_57021);
    _29049 = NOVALUE;
    DeRef(_29044);
    _29044 = NOVALUE;
    DeRef(_29048);
    _29048 = NOVALUE;
    DeRef(_29053);
    _29053 = NOVALUE;
    return;
    ;
}


void _39Retry_statement()
{
    int _by_ref_57064 = NOVALUE;
    int _tok_57066 = NOVALUE;
    int _29083 = NOVALUE;
    int _29081 = NOVALUE;
    int _29080 = NOVALUE;
    int _29079 = NOVALUE;
    int _29078 = NOVALUE;
    int _29077 = NOVALUE;
    int _29075 = NOVALUE;
    int _29074 = NOVALUE;
    int _29073 = NOVALUE;
    int _29072 = NOVALUE;
    int _29071 = NOVALUE;
    int _29069 = NOVALUE;
    int _29068 = NOVALUE;
    int _29067 = NOVALUE;
    int _29066 = NOVALUE;
    int _29065 = NOVALUE;
    int _29064 = NOVALUE;
    int _29062 = NOVALUE;
    int _29060 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not length(loop_stack) then*/
    if (IS_SEQUENCE(_39loop_stack_54151)){
            _29060 = SEQ_PTR(_39loop_stack_54151)->length;
    }
    else {
        _29060 = 1;
    }
    if (_29060 != 0)
    goto L1; // [8] 19
    _29060 = NOVALUE;

    /** 		CompileErr(131)*/
    RefDS(_22023);
    _44CompileErr(131, _22023, 0);
L1: 

    /** 	by_ref = exit_level(next_token(),0) -- can't pass tok by reference*/
    _29062 = _39next_token();
    _0 = _by_ref_57064;
    _by_ref_57064 = _39exit_level(_29062, 0);
    DeRef(_0);
    _29062 = NOVALUE;

    /** 	Leave_blocks( by_ref[1], LOOP_BLOCK )*/
    _2 = (int)SEQ_PTR(_by_ref_57064);
    _29064 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_29064);
    _66Leave_blocks(_29064, 1);
    _29064 = NOVALUE;

    /** 	if loop_stack[$+1-by_ref[1]]=FOR then*/
    if (IS_SEQUENCE(_39loop_stack_54151)){
            _29065 = SEQ_PTR(_39loop_stack_54151)->length;
    }
    else {
        _29065 = 1;
    }
    _29066 = _29065 + 1;
    _29065 = NOVALUE;
    _2 = (int)SEQ_PTR(_by_ref_57064);
    _29067 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_29067)) {
        _29068 = _29066 - _29067;
    }
    else {
        _29068 = binary_op(MINUS, _29066, _29067);
    }
    _29066 = NOVALUE;
    _29067 = NOVALUE;
    _2 = (int)SEQ_PTR(_39loop_stack_54151);
    if (!IS_ATOM_INT(_29068)){
        _29069 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_29068)->dbl));
    }
    else{
        _29069 = (int)*(((s1_ptr)_2)->base + _29068);
    }
    if (_29069 != 21)
    goto L2; // [68] 82

    /** 		emit_op(RETRY) -- for Translator to emit a label at the right place*/
    _41emit_op(184);
    goto L3; // [79] 125
L2: 

    /** 		if retry_addr[$+1-by_ref[1]] < 0 then*/
    if (IS_SEQUENCE(_39retry_addr_54143)){
            _29071 = SEQ_PTR(_39retry_addr_54143)->length;
    }
    else {
        _29071 = 1;
    }
    _29072 = _29071 + 1;
    _29071 = NOVALUE;
    _2 = (int)SEQ_PTR(_by_ref_57064);
    _29073 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_29073)) {
        _29074 = _29072 - _29073;
    }
    else {
        _29074 = binary_op(MINUS, _29072, _29073);
    }
    _29072 = NOVALUE;
    _29073 = NOVALUE;
    _2 = (int)SEQ_PTR(_39retry_addr_54143);
    if (!IS_ATOM_INT(_29074)){
        _29075 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_29074)->dbl));
    }
    else{
        _29075 = (int)*(((s1_ptr)_2)->base + _29074);
    }
    if (_29075 >= 0)
    goto L4; // [105] 117

    /** 			CompileErr(131)*/
    RefDS(_22023);
    _44CompileErr(131, _22023, 0);
L4: 

    /** 		emit_op(ELSE)*/
    _41emit_op(23);
L3: 

    /** 	emit_addr(retry_addr[$+1-by_ref[1]])*/
    if (IS_SEQUENCE(_39retry_addr_54143)){
            _29077 = SEQ_PTR(_39retry_addr_54143)->length;
    }
    else {
        _29077 = 1;
    }
    _29078 = _29077 + 1;
    _29077 = NOVALUE;
    _2 = (int)SEQ_PTR(_by_ref_57064);
    _29079 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_29079)) {
        _29080 = _29078 - _29079;
    }
    else {
        _29080 = binary_op(MINUS, _29078, _29079);
    }
    _29078 = NOVALUE;
    _29079 = NOVALUE;
    _2 = (int)SEQ_PTR(_39retry_addr_54143);
    if (!IS_ATOM_INT(_29080)){
        _29081 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_29080)->dbl));
    }
    else{
        _29081 = (int)*(((s1_ptr)_2)->base + _29080);
    }
    _41emit_addr(_29081);
    _29081 = NOVALUE;

    /** 	tok = by_ref[2]*/
    DeRef(_tok_57066);
    _2 = (int)SEQ_PTR(_by_ref_57064);
    _tok_57066 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_tok_57066);

    /** 	putback(tok)*/
    Ref(_tok_57066);
    _39putback(_tok_57066);

    /** 	NotReached(tok[T_ID], "retry")*/
    _2 = (int)SEQ_PTR(_tok_57066);
    _29083 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_29083);
    RefDS(_26392);
    _39NotReached(_29083, _26392);
    _29083 = NOVALUE;

    /** end procedure*/
    DeRefDS(_by_ref_57064);
    DeRef(_tok_57066);
    _29069 = NOVALUE;
    _29075 = NOVALUE;
    DeRef(_29068);
    _29068 = NOVALUE;
    DeRef(_29074);
    _29074 = NOVALUE;
    DeRef(_29080);
    _29080 = NOVALUE;
    return;
    ;
}


int _39in_switch()
{
    int _29088 = NOVALUE;
    int _29087 = NOVALUE;
    int _29086 = NOVALUE;
    int _29085 = NOVALUE;
    int _29084 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if length( if_stack ) and if_stack[$] = SWITCH then*/
    if (IS_SEQUENCE(_39if_stack_54152)){
            _29084 = SEQ_PTR(_39if_stack_54152)->length;
    }
    else {
        _29084 = 1;
    }
    if (_29084 == 0) {
        goto L1; // [8] 40
    }
    if (IS_SEQUENCE(_39if_stack_54152)){
            _29086 = SEQ_PTR(_39if_stack_54152)->length;
    }
    else {
        _29086 = 1;
    }
    _2 = (int)SEQ_PTR(_39if_stack_54152);
    _29087 = (int)*(((s1_ptr)_2)->base + _29086);
    _29088 = (_29087 == 185);
    _29087 = NOVALUE;
    if (_29088 == 0)
    {
        DeRef(_29088);
        _29088 = NOVALUE;
        goto L1; // [28] 40
    }
    else{
        DeRef(_29088);
        _29088 = NOVALUE;
    }

    /** 		return 1*/
    return 1;
    goto L2; // [37] 47
L1: 

    /** 		return 0*/
    return 0;
L2: 
    ;
}


void _39Break_statement()
{
    int _addr_inlined_AppendEList_at_63_57136 = NOVALUE;
    int _tok_57119 = NOVALUE;
    int _by_ref_57120 = NOVALUE;
    int _29099 = NOVALUE;
    int _29096 = NOVALUE;
    int _29095 = NOVALUE;
    int _29094 = NOVALUE;
    int _29093 = NOVALUE;
    int _29091 = NOVALUE;
    int _29089 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence by_ref*/

    /** 	if not length(if_labels) then*/
    if (IS_SEQUENCE(_39if_labels_54146)){
            _29089 = SEQ_PTR(_39if_labels_54146)->length;
    }
    else {
        _29089 = 1;
    }
    if (_29089 != 0)
    goto L1; // [10] 21
    _29089 = NOVALUE;

    /** 		CompileErr(40)*/
    RefDS(_22023);
    _44CompileErr(40, _22023, 0);
L1: 

    /** 	by_ref = exit_level(next_token(),1)*/
    _29091 = _39next_token();
    _0 = _by_ref_57120;
    _by_ref_57120 = _39exit_level(_29091, 1);
    DeRef(_0);
    _29091 = NOVALUE;

    /** 	Leave_blocks( by_ref[1], CONDITIONAL_BLOCK )*/
    _2 = (int)SEQ_PTR(_by_ref_57120);
    _29093 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_29093);
    _66Leave_blocks(_29093, 2);
    _29093 = NOVALUE;

    /** 	emit_op(ELSE)*/
    _41emit_op(23);

    /** 	AppendEList(length(Code)+1)*/
    if (IS_SEQUENCE(_35Code_16332)){
            _29094 = SEQ_PTR(_35Code_16332)->length;
    }
    else {
        _29094 = 1;
    }
    _29095 = _29094 + 1;
    _29094 = NOVALUE;
    _addr_inlined_AppendEList_at_63_57136 = _29095;
    _29095 = NOVALUE;

    /** 	break_list = append(break_list, addr)*/
    Append(&_39break_list_54135, _39break_list_54135, _addr_inlined_AppendEList_at_63_57136);

    /** end procedure*/
    goto L2; // [78] 81
L2: 

    /** 	break_delay &= by_ref[1]*/
    _2 = (int)SEQ_PTR(_by_ref_57120);
    _29096 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_39break_delay_54136) && IS_ATOM(_29096)) {
        Ref(_29096);
        Append(&_39break_delay_54136, _39break_delay_54136, _29096);
    }
    else if (IS_ATOM(_39break_delay_54136) && IS_SEQUENCE(_29096)) {
    }
    else {
        Concat((object_ptr)&_39break_delay_54136, _39break_delay_54136, _29096);
    }
    _29096 = NOVALUE;

    /** 	emit_forward_addr()    -- to be back-patched*/
    _39emit_forward_addr();

    /** 	tok = by_ref[2]*/
    DeRef(_tok_57119);
    _2 = (int)SEQ_PTR(_by_ref_57120);
    _tok_57119 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_tok_57119);

    /** 	putback(tok)*/
    Ref(_tok_57119);
    _39putback(_tok_57119);

    /** 	NotReached(tok[T_ID], "break")*/
    _2 = (int)SEQ_PTR(_tok_57119);
    _29099 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_29099);
    RefDS(_26282);
    _39NotReached(_29099, _26282);
    _29099 = NOVALUE;

    /** end procedure*/
    DeRef(_tok_57119);
    DeRefDS(_by_ref_57120);
    return;
    ;
}


int _39finish_block_header(int _opcode_57145)
{
    int _tok_57147 = NOVALUE;
    int _labbel_57148 = NOVALUE;
    int _has_entry_57149 = NOVALUE;
    int _29153 = NOVALUE;
    int _29152 = NOVALUE;
    int _29151 = NOVALUE;
    int _29150 = NOVALUE;
    int _29147 = NOVALUE;
    int _29142 = NOVALUE;
    int _29139 = NOVALUE;
    int _29137 = NOVALUE;
    int _29134 = NOVALUE;
    int _29133 = NOVALUE;
    int _29131 = NOVALUE;
    int _29128 = NOVALUE;
    int _29125 = NOVALUE;
    int _29124 = NOVALUE;
    int _29122 = NOVALUE;
    int _29120 = NOVALUE;
    int _29117 = NOVALUE;
    int _29114 = NOVALUE;
    int _29113 = NOVALUE;
    int _29111 = NOVALUE;
    int _29109 = NOVALUE;
    int _29108 = NOVALUE;
    int _29107 = NOVALUE;
    int _29104 = NOVALUE;
    int _29101 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	object labbel*/

    /** 	integer has_entry*/

    /** 	tok = next_token()*/
    _0 = _tok_57147;
    _tok_57147 = _39next_token();
    DeRef(_0);

    /** 	has_entry=0*/
    _has_entry_57149 = 0;

    /** 	if tok[T_ID] = WITH then*/
    _2 = (int)SEQ_PTR(_tok_57147);
    _29101 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29101, 420)){
        _29101 = NOVALUE;
        goto L1; // [27] 154
    }
    _29101 = NOVALUE;

    /** 		tok = next_token()*/
    _0 = _tok_57147;
    _tok_57147 = _39next_token();
    DeRef(_0);

    /** 		switch tok[T_ID] do*/
    _2 = (int)SEQ_PTR(_tok_57147);
    _29104 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_29104) ){
        goto L2; // [44] 136
    }
    if(!IS_ATOM_INT(_29104)){
        if( (DBL_PTR(_29104)->dbl != (double) ((int) DBL_PTR(_29104)->dbl) ) ){
            goto L2; // [44] 136
        }
        _0 = (int) DBL_PTR(_29104)->dbl;
    }
    else {
        _0 = _29104;
    };
    _29104 = NOVALUE;
    switch ( _0 ){ 

        /** 		    case ENTRY then*/
        case 424:

        /** 				if not (opcode = WHILE or opcode = LOOP) then*/
        _29107 = (_opcode_57145 == 47);
        if (_29107 != 0) {
            DeRef(_29108);
            _29108 = 1;
            goto L3; // [61] 75
        }
        _29109 = (_opcode_57145 == 422);
        _29108 = (_29109 != 0);
L3: 
        if (_29108 != 0)
        goto L4; // [75] 86
        _29108 = NOVALUE;

        /** 					CompileErr(14)*/
        RefDS(_22023);
        _44CompileErr(14, _22023, 0);
L4: 

        /** 			    has_entry = 1*/
        _has_entry_57149 = 1;
        goto L5; // [91] 146

        /** 			case FALLTHRU then*/
        case 431:

        /** 				if not opcode = SWITCH then*/
        _29111 = (_opcode_57145 == 0);
        if (_29111 != 185)
        goto L6; // [104] 116

        /** 					CompileErr(13)*/
        RefDS(_22023);
        _44CompileErr(13, _22023, 0);
L6: 

        /** 				switch_stack[$][SWITCH_FALLTHRU] = 1*/
        if (IS_SEQUENCE(_39switch_stack_54352)){
                _29113 = SEQ_PTR(_39switch_stack_54352)->length;
        }
        else {
            _29113 = 1;
        }
        _2 = (int)SEQ_PTR(_39switch_stack_54352);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _39switch_stack_54352 = MAKE_SEQ(_2);
        }
        _3 = (int)(_29113 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 5);
        _1 = *(int *)_2;
        *(int *)_2 = 1;
        DeRef(_1);
        _29114 = NOVALUE;
        goto L5; // [132] 146

        /** 			case else*/
        default:
L2: 

        /** 			    CompileErr(27)*/
        RefDS(_22023);
        _44CompileErr(27, _22023, 0);
    ;}L5: 

    /**         tok = next_token()*/
    _0 = _tok_57147;
    _tok_57147 = _39next_token();
    DeRef(_0);
    goto L7; // [151] 240
L1: 

    /** 	elsif tok[T_ID] = WITHOUT then*/
    _2 = (int)SEQ_PTR(_tok_57147);
    _29117 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29117, 421)){
        _29117 = NOVALUE;
        goto L8; // [164] 239
    }
    _29117 = NOVALUE;

    /** 		tok = next_token()*/
    _0 = _tok_57147;
    _tok_57147 = _39next_token();
    DeRef(_0);

    /** 		if tok[T_ID] = FALLTHRU then*/
    _2 = (int)SEQ_PTR(_tok_57147);
    _29120 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29120, 431)){
        _29120 = NOVALUE;
        goto L9; // [183] 225
    }
    _29120 = NOVALUE;

    /** 			if not opcode = SWITCH then*/
    _29122 = (_opcode_57145 == 0);
    if (_29122 != 185)
    goto LA; // [194] 206

    /** 				CompileErr(15)*/
    RefDS(_22023);
    _44CompileErr(15, _22023, 0);
LA: 

    /** 			switch_stack[$][SWITCH_FALLTHRU] = 0*/
    if (IS_SEQUENCE(_39switch_stack_54352)){
            _29124 = SEQ_PTR(_39switch_stack_54352)->length;
    }
    else {
        _29124 = 1;
    }
    _2 = (int)SEQ_PTR(_39switch_stack_54352);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _39switch_stack_54352 = MAKE_SEQ(_2);
    }
    _3 = (int)(_29124 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _29125 = NOVALUE;
    goto LB; // [222] 233
L9: 

    /** 			CompileErr(27)*/
    RefDS(_22023);
    _44CompileErr(27, _22023, 0);
LB: 

    /**         tok = next_token()*/
    _0 = _tok_57147;
    _tok_57147 = _39next_token();
    DeRef(_0);
L8: 
L7: 

    /** 	labbel=0*/
    DeRef(_labbel_57148);
    _labbel_57148 = 0;

    /** 	if tok[T_ID]=LABEL then*/
    _2 = (int)SEQ_PTR(_tok_57147);
    _29128 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29128, 419)){
        _29128 = NOVALUE;
        goto LC; // [255] 317
    }
    _29128 = NOVALUE;

    /** 		tok = next_token()*/
    _0 = _tok_57147;
    _tok_57147 = _39next_token();
    DeRef(_0);

    /** 		if tok[T_ID] != STRING then*/
    _2 = (int)SEQ_PTR(_tok_57147);
    _29131 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _29131, 503)){
        _29131 = NOVALUE;
        goto LD; // [274] 286
    }
    _29131 = NOVALUE;

    /** 			CompileErr(38)*/
    RefDS(_22023);
    _44CompileErr(38, _22023, 0);
LD: 

    /** 		labbel = SymTab[tok[T_SYM]][S_OBJ]*/
    _2 = (int)SEQ_PTR(_tok_57147);
    _29133 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!IS_ATOM_INT(_29133)){
        _29134 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_29133)->dbl));
    }
    else{
        _29134 = (int)*(((s1_ptr)_2)->base + _29133);
    }
    DeRef(_labbel_57148);
    _2 = (int)SEQ_PTR(_29134);
    _labbel_57148 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_labbel_57148);
    _29134 = NOVALUE;

    /** 		block_label( labbel )*/
    Ref(_labbel_57148);
    _66block_label(_labbel_57148);

    /** 		tok = next_token()*/
    _0 = _tok_57147;
    _tok_57147 = _39next_token();
    DeRef(_0);
LC: 

    /** 	if opcode = IF or opcode = SWITCH then*/
    _29137 = (_opcode_57145 == 20);
    if (_29137 != 0) {
        goto LE; // [325] 340
    }
    _29139 = (_opcode_57145 == 185);
    if (_29139 == 0)
    {
        DeRef(_29139);
        _29139 = NOVALUE;
        goto LF; // [336] 351
    }
    else{
        DeRef(_29139);
        _29139 = NOVALUE;
    }
LE: 

    /** 		if_labels = append(if_labels,labbel)*/
    Ref(_labbel_57148);
    Append(&_39if_labels_54146, _39if_labels_54146, _labbel_57148);
    goto L10; // [348] 360
LF: 

    /** 		loop_labels = append(loop_labels,labbel)*/
    Ref(_labbel_57148);
    Append(&_39loop_labels_54145, _39loop_labels_54145, _labbel_57148);
L10: 

    /** 	if block_index=length(block_list) then*/
    if (IS_SEQUENCE(_39block_list_54147)){
            _29142 = SEQ_PTR(_39block_list_54147)->length;
    }
    else {
        _29142 = 1;
    }
    if (_39block_index_54148 != _29142)
    goto L11; // [369] 392

    /** 	    block_list &= opcode*/
    Append(&_39block_list_54147, _39block_list_54147, _opcode_57145);

    /** 	    block_index += 1*/
    _39block_index_54148 = _39block_index_54148 + 1;
    goto L12; // [389] 411
L11: 

    /** 	    block_index += 1*/
    _39block_index_54148 = _39block_index_54148 + 1;

    /** 	    block_list[block_index] = opcode*/
    _2 = (int)SEQ_PTR(_39block_list_54147);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _39block_list_54147 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _39block_index_54148);
    *(int *)_2 = _opcode_57145;
L12: 

    /** 	if tok[T_ID]=ENTRY then*/
    _2 = (int)SEQ_PTR(_tok_57147);
    _29147 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29147, 424)){
        _29147 = NOVALUE;
        goto L13; // [421] 449
    }
    _29147 = NOVALUE;

    /** 	    if has_entry then*/
    if (_has_entry_57149 == 0)
    {
        goto L14; // [427] 438
    }
    else{
    }

    /** 	        CompileErr(64)*/
    RefDS(_22023);
    _44CompileErr(64, _22023, 0);
L14: 

    /** 	    has_entry=1*/
    _has_entry_57149 = 1;

    /** 	    tok=next_token()*/
    _0 = _tok_57147;
    _tok_57147 = _39next_token();
    DeRef(_0);
L13: 

    /** 	if has_entry and (opcode = IF or opcode = SWITCH) then*/
    if (_has_entry_57149 == 0) {
        goto L15; // [451] 487
    }
    _29151 = (_opcode_57145 == 20);
    if (_29151 != 0) {
        DeRef(_29152);
        _29152 = 1;
        goto L16; // [461] 475
    }
    _29153 = (_opcode_57145 == 185);
    _29152 = (_29153 != 0);
L16: 
    if (_29152 == 0)
    {
        _29152 = NOVALUE;
        goto L15; // [476] 487
    }
    else{
        _29152 = NOVALUE;
    }

    /** 		CompileErr(80)*/
    RefDS(_22023);
    _44CompileErr(80, _22023, 0);
L15: 

    /** 	if opcode = IF then*/
    if (_opcode_57145 != 20)
    goto L17; // [491] 507

    /** 		opcode = THEN*/
    _opcode_57145 = 410;
    goto L18; // [504] 517
L17: 

    /** 		opcode = DO*/
    _opcode_57145 = 411;
L18: 

    /** 	putback(tok)*/
    Ref(_tok_57147);
    _39putback(_tok_57147);

    /** 	tok_match(opcode)*/
    _39tok_match(_opcode_57145, 0);

    /** 	return has_entry*/
    DeRef(_tok_57147);
    DeRef(_labbel_57148);
    DeRef(_29107);
    _29107 = NOVALUE;
    DeRef(_29109);
    _29109 = NOVALUE;
    DeRef(_29111);
    _29111 = NOVALUE;
    DeRef(_29122);
    _29122 = NOVALUE;
    _29133 = NOVALUE;
    DeRef(_29137);
    _29137 = NOVALUE;
    DeRef(_29151);
    _29151 = NOVALUE;
    DeRef(_29153);
    _29153 = NOVALUE;
    return _has_entry_57149;
    ;
}


void _39If_statement()
{
    int _addr_inlined_AppendEList_at_624_57395 = NOVALUE;
    int _addr_inlined_AppendEList_at_260_57324 = NOVALUE;
    int _tok_57267 = NOVALUE;
    int _prev_false_57268 = NOVALUE;
    int _prev_false2_57269 = NOVALUE;
    int _elist_base_57270 = NOVALUE;
    int _temps_57278 = NOVALUE;
    int _31649 = NOVALUE;
    int _29219 = NOVALUE;
    int _29218 = NOVALUE;
    int _29215 = NOVALUE;
    int _29214 = NOVALUE;
    int _29212 = NOVALUE;
    int _29211 = NOVALUE;
    int _29210 = NOVALUE;
    int _29208 = NOVALUE;
    int _29207 = NOVALUE;
    int _29205 = NOVALUE;
    int _29204 = NOVALUE;
    int _29203 = NOVALUE;
    int _29201 = NOVALUE;
    int _29200 = NOVALUE;
    int _29198 = NOVALUE;
    int _29197 = NOVALUE;
    int _29196 = NOVALUE;
    int _29195 = NOVALUE;
    int _29193 = NOVALUE;
    int _29192 = NOVALUE;
    int _29189 = NOVALUE;
    int _29187 = NOVALUE;
    int _29186 = NOVALUE;
    int _29185 = NOVALUE;
    int _29182 = NOVALUE;
    int _29179 = NOVALUE;
    int _29178 = NOVALUE;
    int _29176 = NOVALUE;
    int _29175 = NOVALUE;
    int _29173 = NOVALUE;
    int _29172 = NOVALUE;
    int _29170 = NOVALUE;
    int _29167 = NOVALUE;
    int _29165 = NOVALUE;
    int _29164 = NOVALUE;
    int _29163 = NOVALUE;
    int _29159 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer prev_false*/

    /** 	integer prev_false2*/

    /** 	integer elist_base*/

    /** 	if_stack &= IF*/
    Append(&_39if_stack_54152, _39if_stack_54152, 20);

    /** 	Start_block( IF )*/
    _66Start_block(20, 0);

    /** 	elist_base = length(break_list)*/
    if (IS_SEQUENCE(_39break_list_54135)){
            _elist_base_57270 = SEQ_PTR(_39break_list_54135)->length;
    }
    else {
        _elist_base_57270 = 1;
    }

    /** 	short_circuit += 1*/
    _39short_circuit_54117 = _39short_circuit_54117 + 1;

    /** 	short_circuit_B = FALSE*/
    _39short_circuit_B_54119 = _13FALSE_434;

    /** 	SC1_type = 0*/
    _39SC1_type_54122 = 0;

    /** 	Expr()*/
    _39Expr();

    /** 	sequence temps = get_temps()*/
    _31649 = Repeat(_22023, 2);
    _0 = _temps_57278;
    _temps_57278 = _41get_temps(_31649);
    DeRef(_0);
    _31649 = NOVALUE;

    /** 	emit_op(IF)*/
    _41emit_op(20);

    /** 	prev_false = length(Code)+1*/
    if (IS_SEQUENCE(_35Code_16332)){
            _29159 = SEQ_PTR(_35Code_16332)->length;
    }
    else {
        _29159 = 1;
    }
    _prev_false_57268 = _29159 + 1;
    _29159 = NOVALUE;

    /** 	emit_forward_addr() -- to be patched*/
    _39emit_forward_addr();

    /** 	prev_false2=finish_block_header(IF)  -- 0*/
    _prev_false2_57269 = _39finish_block_header(20);
    if (!IS_ATOM_INT(_prev_false2_57269)) {
        _1 = (long)(DBL_PTR(_prev_false2_57269)->dbl);
        DeRefDS(_prev_false2_57269);
        _prev_false2_57269 = _1;
    }

    /** 	if SC1_type = OR then*/
    if (_39SC1_type_54122 != 9)
    goto L1; // [106] 159

    /** 		backpatch(SC1_patch-3, SC1_OR_IF)*/
    _29163 = _39SC1_patch_54121 - 3;
    if ((long)((unsigned long)_29163 +(unsigned long) HIGH_BITS) >= 0){
        _29163 = NewDouble((double)_29163);
    }
    _41backpatch(_29163, 147);
    _29163 = NOVALUE;

    /** 		if TRANSLATE then*/
    if (_35TRANSLATE_15887 == 0)
    {
        goto L2; // [128] 139
    }
    else{
    }

    /** 			emit_op(NOP1)  -- to get label here*/
    _41emit_op(159);
L2: 

    /** 		backpatch(SC1_patch, length(Code)+1)*/
    if (IS_SEQUENCE(_35Code_16332)){
            _29164 = SEQ_PTR(_35Code_16332)->length;
    }
    else {
        _29164 = 1;
    }
    _29165 = _29164 + 1;
    _29164 = NOVALUE;
    _41backpatch(_39SC1_patch_54121, _29165);
    _29165 = NOVALUE;
    goto L3; // [156] 192
L1: 

    /** 	elsif SC1_type = AND then*/
    if (_39SC1_type_54122 != 8)
    goto L4; // [165] 191

    /** 		backpatch(SC1_patch-3, SC1_AND_IF)*/
    _29167 = _39SC1_patch_54121 - 3;
    if ((long)((unsigned long)_29167 +(unsigned long) HIGH_BITS) >= 0){
        _29167 = NewDouble((double)_29167);
    }
    _41backpatch(_29167, 146);
    _29167 = NOVALUE;

    /** 		prev_false2 = SC1_patch*/
    _prev_false2_57269 = _39SC1_patch_54121;
L4: 
L3: 

    /** 	short_circuit -= 1*/
    _39short_circuit_54117 = _39short_circuit_54117 - 1;

    /** 	Statement_list()*/
    _39Statement_list();

    /** 	tok = next_token()*/
    _0 = _tok_57267;
    _tok_57267 = _39next_token();
    DeRef(_0);

    /** 	while tok[T_ID] = ELSIF do*/
L5: 
    _2 = (int)SEQ_PTR(_tok_57267);
    _29170 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29170, 414)){
        _29170 = NOVALUE;
        goto L6; // [222] 530
    }
    _29170 = NOVALUE;

    /** 		Sibling_block( IF )*/
    _66Sibling_block(20);

    /** 		emit_op(ELSE)*/
    _41emit_op(23);

    /** 		AppendEList(length(Code)+1)*/
    if (IS_SEQUENCE(_35Code_16332)){
            _29172 = SEQ_PTR(_35Code_16332)->length;
    }
    else {
        _29172 = 1;
    }
    _29173 = _29172 + 1;
    _29172 = NOVALUE;
    _addr_inlined_AppendEList_at_260_57324 = _29173;
    _29173 = NOVALUE;

    /** 	break_list = append(break_list, addr)*/
    Append(&_39break_list_54135, _39break_list_54135, _addr_inlined_AppendEList_at_260_57324);

    /** end procedure*/
    goto L7; // [266] 269
L7: 

    /** 		break_delay &= 1*/
    Append(&_39break_delay_54136, _39break_delay_54136, 1);

    /** 		emit_forward_addr()  -- to be patched*/
    _39emit_forward_addr();

    /** 		if TRANSLATE then*/
    if (_35TRANSLATE_15887 == 0)
    {
        goto L8; // [287] 298
    }
    else{
    }

    /** 			emit_op(NOP1)*/
    _41emit_op(159);
L8: 

    /** 		backpatch(prev_false, length(Code)+1)*/
    if (IS_SEQUENCE(_35Code_16332)){
            _29175 = SEQ_PTR(_35Code_16332)->length;
    }
    else {
        _29175 = 1;
    }
    _29176 = _29175 + 1;
    _29175 = NOVALUE;
    _41backpatch(_prev_false_57268, _29176);
    _29176 = NOVALUE;

    /** 		if prev_false2 != 0 then*/
    if (_prev_false2_57269 == 0)
    goto L9; // [315] 335

    /** 			backpatch(prev_false2, length(Code)+1)*/
    if (IS_SEQUENCE(_35Code_16332)){
            _29178 = SEQ_PTR(_35Code_16332)->length;
    }
    else {
        _29178 = 1;
    }
    _29179 = _29178 + 1;
    _29178 = NOVALUE;
    _41backpatch(_prev_false2_57269, _29179);
    _29179 = NOVALUE;
L9: 

    /** 		StartSourceLine(TRUE)*/
    _41StartSourceLine(_13TRUE_436, 0, 2);

    /** 		short_circuit += 1*/
    _39short_circuit_54117 = _39short_circuit_54117 + 1;

    /** 		short_circuit_B = FALSE*/
    _39short_circuit_B_54119 = _13FALSE_434;

    /** 		SC1_type = 0*/
    _39SC1_type_54122 = 0;

    /** 		push_temps( temps )*/
    RefDS(_temps_57278);
    _41push_temps(_temps_57278);

    /** 		Expr()*/
    _39Expr();

    /** 		temps = get_temps( temps )*/
    RefDS(_temps_57278);
    _0 = _temps_57278;
    _temps_57278 = _41get_temps(_temps_57278);
    DeRefDS(_0);

    /** 		emit_op(IF)*/
    _41emit_op(20);

    /** 		prev_false = length(Code)+1*/
    if (IS_SEQUENCE(_35Code_16332)){
            _29182 = SEQ_PTR(_35Code_16332)->length;
    }
    else {
        _29182 = 1;
    }
    _prev_false_57268 = _29182 + 1;
    _29182 = NOVALUE;

    /** 		prev_false2 = 0*/
    _prev_false2_57269 = 0;

    /** 		emit_forward_addr() -- to be patched*/
    _39emit_forward_addr();

    /** 		if SC1_type = OR then*/
    if (_39SC1_type_54122 != 9)
    goto LA; // [414] 467

    /** 			backpatch(SC1_patch-3, SC1_OR_IF)*/
    _29185 = _39SC1_patch_54121 - 3;
    if ((long)((unsigned long)_29185 +(unsigned long) HIGH_BITS) >= 0){
        _29185 = NewDouble((double)_29185);
    }
    _41backpatch(_29185, 147);
    _29185 = NOVALUE;

    /** 			if TRANSLATE then*/
    if (_35TRANSLATE_15887 == 0)
    {
        goto LB; // [436] 447
    }
    else{
    }

    /** 				emit_op(NOP1)*/
    _41emit_op(159);
LB: 

    /** 			backpatch(SC1_patch, length(Code)+1)*/
    if (IS_SEQUENCE(_35Code_16332)){
            _29186 = SEQ_PTR(_35Code_16332)->length;
    }
    else {
        _29186 = 1;
    }
    _29187 = _29186 + 1;
    _29186 = NOVALUE;
    _41backpatch(_39SC1_patch_54121, _29187);
    _29187 = NOVALUE;
    goto LC; // [464] 500
LA: 

    /** 		elsif SC1_type = AND then*/
    if (_39SC1_type_54122 != 8)
    goto LD; // [473] 499

    /** 			backpatch(SC1_patch-3, SC1_AND_IF)*/
    _29189 = _39SC1_patch_54121 - 3;
    if ((long)((unsigned long)_29189 +(unsigned long) HIGH_BITS) >= 0){
        _29189 = NewDouble((double)_29189);
    }
    _41backpatch(_29189, 146);
    _29189 = NOVALUE;

    /** 			prev_false2 = SC1_patch*/
    _prev_false2_57269 = _39SC1_patch_54121;
LD: 
LC: 

    /** 		short_circuit -= 1*/
    _39short_circuit_54117 = _39short_circuit_54117 - 1;

    /** 		tok_match(THEN)*/
    _39tok_match(410, 0);

    /** 		Statement_list()*/
    _39Statement_list();

    /** 		tok = next_token()*/
    _0 = _tok_57267;
    _tok_57267 = _39next_token();
    DeRef(_0);

    /** 	end while*/
    goto L5; // [527] 214
L6: 

    /** 	if tok[T_ID] = ELSE or length(temps[1]) then*/
    _2 = (int)SEQ_PTR(_tok_57267);
    _29192 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_29192)) {
        _29193 = (_29192 == 23);
    }
    else {
        _29193 = binary_op(EQUALS, _29192, 23);
    }
    _29192 = NOVALUE;
    if (IS_ATOM_INT(_29193)) {
        if (_29193 != 0) {
            goto LE; // [544] 560
        }
    }
    else {
        if (DBL_PTR(_29193)->dbl != 0.0) {
            goto LE; // [544] 560
        }
    }
    _2 = (int)SEQ_PTR(_temps_57278);
    _29195 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_29195)){
            _29196 = SEQ_PTR(_29195)->length;
    }
    else {
        _29196 = 1;
    }
    _29195 = NOVALUE;
    if (_29196 == 0)
    {
        _29196 = NOVALUE;
        goto LF; // [556] 715
    }
    else{
        _29196 = NOVALUE;
    }
LE: 

    /** 		Sibling_block( IF )*/
    _66Sibling_block(20);

    /** 		StartSourceLine(FALSE, , COVERAGE_SUPPRESS )*/
    _41StartSourceLine(_13FALSE_434, 0, 1);

    /** 		emit_op(ELSE)*/
    _41emit_op(23);

    /** 		AppendEList(length(Code)+1)*/
    if (IS_SEQUENCE(_35Code_16332)){
            _29197 = SEQ_PTR(_35Code_16332)->length;
    }
    else {
        _29197 = 1;
    }
    _29198 = _29197 + 1;
    _29197 = NOVALUE;
    _addr_inlined_AppendEList_at_624_57395 = _29198;
    _29198 = NOVALUE;

    /** 	break_list = append(break_list, addr)*/
    Append(&_39break_list_54135, _39break_list_54135, _addr_inlined_AppendEList_at_624_57395);

    /** end procedure*/
    goto L10; // [611] 614
L10: 

    /** 		break_delay &= 1*/
    Append(&_39break_delay_54136, _39break_delay_54136, 1);

    /** 		emit_forward_addr() -- to be patched*/
    _39emit_forward_addr();

    /** 		if TRANSLATE then*/
    if (_35TRANSLATE_15887 == 0)
    {
        goto L11; // [632] 643
    }
    else{
    }

    /** 			emit_op(NOP1)*/
    _41emit_op(159);
L11: 

    /** 		backpatch(prev_false, length(Code)+1)*/
    if (IS_SEQUENCE(_35Code_16332)){
            _29200 = SEQ_PTR(_35Code_16332)->length;
    }
    else {
        _29200 = 1;
    }
    _29201 = _29200 + 1;
    _29200 = NOVALUE;
    _41backpatch(_prev_false_57268, _29201);
    _29201 = NOVALUE;

    /** 		if prev_false2 != 0 then*/
    if (_prev_false2_57269 == 0)
    goto L12; // [660] 680

    /** 			backpatch(prev_false2, length(Code)+1)*/
    if (IS_SEQUENCE(_35Code_16332)){
            _29203 = SEQ_PTR(_35Code_16332)->length;
    }
    else {
        _29203 = 1;
    }
    _29204 = _29203 + 1;
    _29203 = NOVALUE;
    _41backpatch(_prev_false2_57269, _29204);
    _29204 = NOVALUE;
L12: 

    /** 		push_temps( temps )*/
    RefDS(_temps_57278);
    _41push_temps(_temps_57278);

    /** 		if tok[T_ID] = ELSE then*/
    _2 = (int)SEQ_PTR(_tok_57267);
    _29205 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29205, 23)){
        _29205 = NOVALUE;
        goto L13; // [695] 706
    }
    _29205 = NOVALUE;

    /** 			Statement_list()*/
    _39Statement_list();
    goto L14; // [703] 773
L13: 

    /** 			putback(tok)*/
    Ref(_tok_57267);
    _39putback(_tok_57267);
    goto L14; // [712] 773
LF: 

    /** 		putback(tok)*/
    Ref(_tok_57267);
    _39putback(_tok_57267);

    /** 		if TRANSLATE then*/
    if (_35TRANSLATE_15887 == 0)
    {
        goto L15; // [724] 735
    }
    else{
    }

    /** 			emit_op(NOP1)*/
    _41emit_op(159);
L15: 

    /** 		backpatch(prev_false, length(Code)+1)*/
    if (IS_SEQUENCE(_35Code_16332)){
            _29207 = SEQ_PTR(_35Code_16332)->length;
    }
    else {
        _29207 = 1;
    }
    _29208 = _29207 + 1;
    _29207 = NOVALUE;
    _41backpatch(_prev_false_57268, _29208);
    _29208 = NOVALUE;

    /** 		if prev_false2 != 0 then*/
    if (_prev_false2_57269 == 0)
    goto L16; // [752] 772

    /** 			backpatch(prev_false2, length(Code)+1)*/
    if (IS_SEQUENCE(_35Code_16332)){
            _29210 = SEQ_PTR(_35Code_16332)->length;
    }
    else {
        _29210 = 1;
    }
    _29211 = _29210 + 1;
    _29210 = NOVALUE;
    _41backpatch(_prev_false2_57269, _29211);
    _29211 = NOVALUE;
L16: 
L14: 

    /** 	tok_match(END)*/
    _39tok_match(402, 0);

    /** 	tok_match(IF, END)*/
    _39tok_match(20, 402);

    /** 	End_block( IF )*/
    _66End_block(20);

    /** 	if TRANSLATE then*/
    if (_35TRANSLATE_15887 == 0)
    {
        goto L17; // [802] 825
    }
    else{
    }

    /** 		if length(break_list) > elist_base then*/
    if (IS_SEQUENCE(_39break_list_54135)){
            _29212 = SEQ_PTR(_39break_list_54135)->length;
    }
    else {
        _29212 = 1;
    }
    if (_29212 <= _elist_base_57270)
    goto L18; // [812] 824

    /** 			emit_op(NOP1)  -- to emit label here*/
    _41emit_op(159);
L18: 
L17: 

    /** 	PatchEList(elist_base)*/
    _39PatchEList(_elist_base_57270);

    /** 	if_labels = if_labels[1..$-1]*/
    if (IS_SEQUENCE(_39if_labels_54146)){
            _29214 = SEQ_PTR(_39if_labels_54146)->length;
    }
    else {
        _29214 = 1;
    }
    _29215 = _29214 - 1;
    _29214 = NOVALUE;
    rhs_slice_target = (object_ptr)&_39if_labels_54146;
    RHS_Slice(_39if_labels_54146, 1, _29215);

    /** 	block_index -= 1*/
    _39block_index_54148 = _39block_index_54148 - 1;

    /** 	if_stack = if_stack[1..$-1]*/
    if (IS_SEQUENCE(_39if_stack_54152)){
            _29218 = SEQ_PTR(_39if_stack_54152)->length;
    }
    else {
        _29218 = 1;
    }
    _29219 = _29218 - 1;
    _29218 = NOVALUE;
    rhs_slice_target = (object_ptr)&_39if_stack_54152;
    RHS_Slice(_39if_stack_54152, 1, _29219);

    /** end procedure*/
    DeRef(_tok_57267);
    DeRef(_temps_57278);
    _29195 = NOVALUE;
    DeRef(_29193);
    _29193 = NOVALUE;
    _29215 = NOVALUE;
    _29219 = NOVALUE;
    return;
    ;
}


void _39exit_loop(int _exit_base_57455)
{
    int _29234 = NOVALUE;
    int _29233 = NOVALUE;
    int _29231 = NOVALUE;
    int _29230 = NOVALUE;
    int _29228 = NOVALUE;
    int _29227 = NOVALUE;
    int _29225 = NOVALUE;
    int _29224 = NOVALUE;
    int _29222 = NOVALUE;
    int _29221 = NOVALUE;
    int _0, _1, _2;
    

    /** 	PatchXList(exit_base)*/
    _39PatchXList(_exit_base_57455);

    /** 	loop_labels = loop_labels[1..$-1]*/
    if (IS_SEQUENCE(_39loop_labels_54145)){
            _29221 = SEQ_PTR(_39loop_labels_54145)->length;
    }
    else {
        _29221 = 1;
    }
    _29222 = _29221 - 1;
    _29221 = NOVALUE;
    rhs_slice_target = (object_ptr)&_39loop_labels_54145;
    RHS_Slice(_39loop_labels_54145, 1, _29222);

    /** 	loop_stack = loop_stack[1..$-1]*/
    if (IS_SEQUENCE(_39loop_stack_54151)){
            _29224 = SEQ_PTR(_39loop_stack_54151)->length;
    }
    else {
        _29224 = 1;
    }
    _29225 = _29224 - 1;
    _29224 = NOVALUE;
    rhs_slice_target = (object_ptr)&_39loop_stack_54151;
    RHS_Slice(_39loop_stack_54151, 1, _29225);

    /** 	continue_addr = continue_addr[1..$-1]*/
    if (IS_SEQUENCE(_39continue_addr_54142)){
            _29227 = SEQ_PTR(_39continue_addr_54142)->length;
    }
    else {
        _29227 = 1;
    }
    _29228 = _29227 - 1;
    _29227 = NOVALUE;
    rhs_slice_target = (object_ptr)&_39continue_addr_54142;
    RHS_Slice(_39continue_addr_54142, 1, _29228);

    /** 	retry_addr = retry_addr[1..$-1]*/
    if (IS_SEQUENCE(_39retry_addr_54143)){
            _29230 = SEQ_PTR(_39retry_addr_54143)->length;
    }
    else {
        _29230 = 1;
    }
    _29231 = _29230 - 1;
    _29230 = NOVALUE;
    rhs_slice_target = (object_ptr)&_39retry_addr_54143;
    RHS_Slice(_39retry_addr_54143, 1, _29231);

    /** 	entry_addr = entry_addr[1..$-1]*/
    if (IS_SEQUENCE(_39entry_addr_54141)){
            _29233 = SEQ_PTR(_39entry_addr_54141)->length;
    }
    else {
        _29233 = 1;
    }
    _29234 = _29233 - 1;
    _29233 = NOVALUE;
    rhs_slice_target = (object_ptr)&_39entry_addr_54141;
    RHS_Slice(_39entry_addr_54141, 1, _29234);

    /** 	block_index -= 1*/
    _39block_index_54148 = _39block_index_54148 - 1;

    /** end procedure*/
    _29222 = NOVALUE;
    _29225 = NOVALUE;
    _29228 = NOVALUE;
    _29231 = NOVALUE;
    _29234 = NOVALUE;
    return;
    ;
}


void _39push_switch()
{
    int _29238 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if_stack &= SWITCH*/
    Append(&_39if_stack_54152, _39if_stack_54152, 185);

    /** 	switch_stack = append( switch_stack, { {}, {}, 0, 0, 0, 0 })*/
    _1 = NewS1(6);
    _2 = (int)((s1_ptr)_1)->base;
    RefDSn(_22023, 2);
    *((int *)(_2+4)) = _22023;
    *((int *)(_2+8)) = _22023;
    *((int *)(_2+12)) = 0;
    *((int *)(_2+16)) = 0;
    *((int *)(_2+20)) = 0;
    *((int *)(_2+24)) = 0;
    _29238 = MAKE_SEQ(_1);
    RefDS(_29238);
    Append(&_39switch_stack_54352, _39switch_stack_54352, _29238);
    DeRefDS(_29238);
    _29238 = NOVALUE;

    /** end procedure*/
    return;
    ;
}


void _39pop_switch(int _break_base_57480)
{
    int _29253 = NOVALUE;
    int _29252 = NOVALUE;
    int _29250 = NOVALUE;
    int _29249 = NOVALUE;
    int _29247 = NOVALUE;
    int _29246 = NOVALUE;
    int _29244 = NOVALUE;
    int _29243 = NOVALUE;
    int _29242 = NOVALUE;
    int _29241 = NOVALUE;
    int _0, _1, _2;
    

    /** 	PatchEList( break_base )*/
    _39PatchEList(_break_base_57480);

    /** 	block_index -= 1*/
    _39block_index_54148 = _39block_index_54148 - 1;

    /** 	if length(switch_stack[$][SWITCH_CASES]) > 0 then*/
    if (IS_SEQUENCE(_39switch_stack_54352)){
            _29241 = SEQ_PTR(_39switch_stack_54352)->length;
    }
    else {
        _29241 = 1;
    }
    _2 = (int)SEQ_PTR(_39switch_stack_54352);
    _29242 = (int)*(((s1_ptr)_2)->base + _29241);
    _2 = (int)SEQ_PTR(_29242);
    _29243 = (int)*(((s1_ptr)_2)->base + 1);
    _29242 = NOVALUE;
    if (IS_SEQUENCE(_29243)){
            _29244 = SEQ_PTR(_29243)->length;
    }
    else {
        _29244 = 1;
    }
    _29243 = NOVALUE;
    if (_29244 <= 0)
    goto L1; // [34] 46

    /** 		End_block( CASE )*/
    _66End_block(186);
L1: 

    /** 	if_labels = if_labels[1..$-1]*/
    if (IS_SEQUENCE(_39if_labels_54146)){
            _29246 = SEQ_PTR(_39if_labels_54146)->length;
    }
    else {
        _29246 = 1;
    }
    _29247 = _29246 - 1;
    _29246 = NOVALUE;
    rhs_slice_target = (object_ptr)&_39if_labels_54146;
    RHS_Slice(_39if_labels_54146, 1, _29247);

    /** 	if_stack  = if_stack[1..$-1]*/
    if (IS_SEQUENCE(_39if_stack_54152)){
            _29249 = SEQ_PTR(_39if_stack_54152)->length;
    }
    else {
        _29249 = 1;
    }
    _29250 = _29249 - 1;
    _29249 = NOVALUE;
    rhs_slice_target = (object_ptr)&_39if_stack_54152;
    RHS_Slice(_39if_stack_54152, 1, _29250);

    /** 	switch_stack  = switch_stack[1..$-1]*/
    if (IS_SEQUENCE(_39switch_stack_54352)){
            _29252 = SEQ_PTR(_39switch_stack_54352)->length;
    }
    else {
        _29252 = 1;
    }
    _29253 = _29252 - 1;
    _29252 = NOVALUE;
    rhs_slice_target = (object_ptr)&_39switch_stack_54352;
    RHS_Slice(_39switch_stack_54352, 1, _29253);

    /** end procedure*/
    _29243 = NOVALUE;
    _29247 = NOVALUE;
    _29250 = NOVALUE;
    _29253 = NOVALUE;
    return;
    ;
}


void _39add_case(int _sym_57501, int _sign_57502)
{
    int _29279 = NOVALUE;
    int _29278 = NOVALUE;
    int _29277 = NOVALUE;
    int _29276 = NOVALUE;
    int _29275 = NOVALUE;
    int _29274 = NOVALUE;
    int _29273 = NOVALUE;
    int _29272 = NOVALUE;
    int _29270 = NOVALUE;
    int _29269 = NOVALUE;
    int _29268 = NOVALUE;
    int _29267 = NOVALUE;
    int _29266 = NOVALUE;
    int _29265 = NOVALUE;
    int _29263 = NOVALUE;
    int _29262 = NOVALUE;
    int _29260 = NOVALUE;
    int _29259 = NOVALUE;
    int _29258 = NOVALUE;
    int _29257 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	if sign < 0 then*/
    if (_sign_57502 >= 0)
    goto L1; // [5] 15

    /** 		sym = -sym*/
    _0 = _sym_57501;
    if (IS_ATOM_INT(_sym_57501)) {
        if ((unsigned long)_sym_57501 == 0xC0000000)
        _sym_57501 = (int)NewDouble((double)-0xC0000000);
        else
        _sym_57501 = - _sym_57501;
    }
    else {
        _sym_57501 = unary_op(UMINUS, _sym_57501);
    }
    DeRefi(_0);
L1: 

    /** 	if find(sym, switch_stack[$][SWITCH_CASES] ) = 0 then*/
    if (IS_SEQUENCE(_39switch_stack_54352)){
            _29257 = SEQ_PTR(_39switch_stack_54352)->length;
    }
    else {
        _29257 = 1;
    }
    _2 = (int)SEQ_PTR(_39switch_stack_54352);
    _29258 = (int)*(((s1_ptr)_2)->base + _29257);
    _2 = (int)SEQ_PTR(_29258);
    _29259 = (int)*(((s1_ptr)_2)->base + 1);
    _29258 = NOVALUE;
    _29260 = find_from(_sym_57501, _29259, 1);
    _29259 = NOVALUE;
    if (_29260 != 0)
    goto L2; // [35] 144

    /** 		switch_stack[$][SWITCH_CASES]       = append( switch_stack[$][SWITCH_CASES], sym )*/
    if (IS_SEQUENCE(_39switch_stack_54352)){
            _29262 = SEQ_PTR(_39switch_stack_54352)->length;
    }
    else {
        _29262 = 1;
    }
    _2 = (int)SEQ_PTR(_39switch_stack_54352);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _39switch_stack_54352 = MAKE_SEQ(_2);
    }
    _3 = (int)(_29262 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_39switch_stack_54352)){
            _29265 = SEQ_PTR(_39switch_stack_54352)->length;
    }
    else {
        _29265 = 1;
    }
    _2 = (int)SEQ_PTR(_39switch_stack_54352);
    _29266 = (int)*(((s1_ptr)_2)->base + _29265);
    _2 = (int)SEQ_PTR(_29266);
    _29267 = (int)*(((s1_ptr)_2)->base + 1);
    _29266 = NOVALUE;
    Ref(_sym_57501);
    Append(&_29268, _29267, _sym_57501);
    _29267 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _29268;
    if( _1 != _29268 ){
        DeRef(_1);
    }
    _29268 = NOVALUE;
    _29263 = NOVALUE;

    /** 		switch_stack[$][SWITCH_JUMP_TABLE] &= length(Code) + 1*/
    if (IS_SEQUENCE(_39switch_stack_54352)){
            _29269 = SEQ_PTR(_39switch_stack_54352)->length;
    }
    else {
        _29269 = 1;
    }
    _2 = (int)SEQ_PTR(_39switch_stack_54352);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _39switch_stack_54352 = MAKE_SEQ(_2);
    }
    _3 = (int)(_29269 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_35Code_16332)){
            _29272 = SEQ_PTR(_35Code_16332)->length;
    }
    else {
        _29272 = 1;
    }
    _29273 = _29272 + 1;
    _29272 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    _29274 = (int)*(((s1_ptr)_2)->base + 2);
    _29270 = NOVALUE;
    if (IS_SEQUENCE(_29274) && IS_ATOM(_29273)) {
        Append(&_29275, _29274, _29273);
    }
    else if (IS_ATOM(_29274) && IS_SEQUENCE(_29273)) {
    }
    else {
        Concat((object_ptr)&_29275, _29274, _29273);
        _29274 = NOVALUE;
    }
    _29274 = NOVALUE;
    _29273 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _29275;
    if( _1 != _29275 ){
        DeRef(_1);
    }
    _29275 = NOVALUE;
    _29270 = NOVALUE;

    /** 		if TRANSLATE then*/
    if (_35TRANSLATE_15887 == 0)
    {
        goto L3; // [109] 152
    }
    else{
    }

    /** 			emit_addr( CASE )*/
    _41emit_addr(186);

    /** 			emit_addr( length( switch_stack[$][SWITCH_CASES] ) )*/
    if (IS_SEQUENCE(_39switch_stack_54352)){
            _29276 = SEQ_PTR(_39switch_stack_54352)->length;
    }
    else {
        _29276 = 1;
    }
    _2 = (int)SEQ_PTR(_39switch_stack_54352);
    _29277 = (int)*(((s1_ptr)_2)->base + _29276);
    _2 = (int)SEQ_PTR(_29277);
    _29278 = (int)*(((s1_ptr)_2)->base + 1);
    _29277 = NOVALUE;
    if (IS_SEQUENCE(_29278)){
            _29279 = SEQ_PTR(_29278)->length;
    }
    else {
        _29279 = 1;
    }
    _29278 = NOVALUE;
    _41emit_addr(_29279);
    _29279 = NOVALUE;
    goto L3; // [141] 152
L2: 

    /** 		CompileErr( 63 )*/
    RefDS(_22023);
    _44CompileErr(63, _22023, 0);
L3: 

    /** end procedure*/
    DeRef(_sym_57501);
    _29278 = NOVALUE;
    return;
    ;
}


void _39case_else()
{
    int _29287 = NOVALUE;
    int _29286 = NOVALUE;
    int _29284 = NOVALUE;
    int _29283 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	switch_stack[$][SWITCH_ELSE] = length(Code) + 1*/
    if (IS_SEQUENCE(_39switch_stack_54352)){
            _29283 = SEQ_PTR(_39switch_stack_54352)->length;
    }
    else {
        _29283 = 1;
    }
    _2 = (int)SEQ_PTR(_39switch_stack_54352);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _39switch_stack_54352 = MAKE_SEQ(_2);
    }
    _3 = (int)(_29283 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_35Code_16332)){
            _29286 = SEQ_PTR(_35Code_16332)->length;
    }
    else {
        _29286 = 1;
    }
    _29287 = _29286 + 1;
    _29286 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = _29287;
    if( _1 != _29287 ){
        DeRef(_1);
    }
    _29287 = NOVALUE;
    _29284 = NOVALUE;

    /** 	if TRANSLATE then*/
    if (_35TRANSLATE_15887 == 0)
    {
        goto L1; // [30] 46
    }
    else{
    }

    /** 		emit_addr( CASE )*/
    _41emit_addr(186);

    /** 		emit_addr( 0 )*/
    _41emit_addr(0);
L1: 

    /** end procedure*/
    return;
    ;
}


void _39Case_statement()
{
    int _else_case_2__tmp_at145_57598 = NOVALUE;
    int _else_case_1__tmp_at145_57597 = NOVALUE;
    int _else_case_inlined_else_case_at_145_57596 = NOVALUE;
    int _tok_57560 = NOVALUE;
    int _condition_57562 = NOVALUE;
    int _start_line_57591 = NOVALUE;
    int _sign_57602 = NOVALUE;
    int _fwd_57615 = NOVALUE;
    int _symi_57625 = NOVALUE;
    int _fwdref_57694 = NOVALUE;
    int _31648 = NOVALUE;
    int _29369 = NOVALUE;
    int _29368 = NOVALUE;
    int _29367 = NOVALUE;
    int _29366 = NOVALUE;
    int _29365 = NOVALUE;
    int _29364 = NOVALUE;
    int _29362 = NOVALUE;
    int _29361 = NOVALUE;
    int _29360 = NOVALUE;
    int _29359 = NOVALUE;
    int _29358 = NOVALUE;
    int _29357 = NOVALUE;
    int _29355 = NOVALUE;
    int _29352 = NOVALUE;
    int _29349 = NOVALUE;
    int _29348 = NOVALUE;
    int _29347 = NOVALUE;
    int _29346 = NOVALUE;
    int _29343 = NOVALUE;
    int _29342 = NOVALUE;
    int _29341 = NOVALUE;
    int _29340 = NOVALUE;
    int _29337 = NOVALUE;
    int _29336 = NOVALUE;
    int _29335 = NOVALUE;
    int _29334 = NOVALUE;
    int _29332 = NOVALUE;
    int _29331 = NOVALUE;
    int _29330 = NOVALUE;
    int _29328 = NOVALUE;
    int _29327 = NOVALUE;
    int _29326 = NOVALUE;
    int _29325 = NOVALUE;
    int _29324 = NOVALUE;
    int _29322 = NOVALUE;
    int _29321 = NOVALUE;
    int _29319 = NOVALUE;
    int _29318 = NOVALUE;
    int _29317 = NOVALUE;
    int _29316 = NOVALUE;
    int _29312 = NOVALUE;
    int _29311 = NOVALUE;
    int _29310 = NOVALUE;
    int _29307 = NOVALUE;
    int _29304 = NOVALUE;
    int _29301 = NOVALUE;
    int _29300 = NOVALUE;
    int _29299 = NOVALUE;
    int _29298 = NOVALUE;
    int _29297 = NOVALUE;
    int _29296 = NOVALUE;
    int _29295 = NOVALUE;
    int _29293 = NOVALUE;
    int _29292 = NOVALUE;
    int _29291 = NOVALUE;
    int _29290 = NOVALUE;
    int _29288 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	if not in_switch() then*/
    _29288 = _39in_switch();
    if (IS_ATOM_INT(_29288)) {
        if (_29288 != 0){
            DeRef(_29288);
            _29288 = NOVALUE;
            goto L1; // [6] 17
        }
    }
    else {
        if (DBL_PTR(_29288)->dbl != 0.0){
            DeRef(_29288);
            _29288 = NOVALUE;
            goto L1; // [6] 17
        }
    }
    DeRef(_29288);
    _29288 = NOVALUE;

    /** 		CompileErr( 34 )*/
    RefDS(_22023);
    _44CompileErr(34, _22023, 0);
L1: 

    /** 	if length(switch_stack[$][SWITCH_CASES]) > 0 then*/
    if (IS_SEQUENCE(_39switch_stack_54352)){
            _29290 = SEQ_PTR(_39switch_stack_54352)->length;
    }
    else {
        _29290 = 1;
    }
    _2 = (int)SEQ_PTR(_39switch_stack_54352);
    _29291 = (int)*(((s1_ptr)_2)->base + _29290);
    _2 = (int)SEQ_PTR(_29291);
    _29292 = (int)*(((s1_ptr)_2)->base + 1);
    _29291 = NOVALUE;
    if (IS_SEQUENCE(_29292)){
            _29293 = SEQ_PTR(_29292)->length;
    }
    else {
        _29293 = 1;
    }
    _29292 = NOVALUE;
    if (_29293 <= 0)
    goto L2; // [35] 101

    /** 		Sibling_block( CASE )*/
    _66Sibling_block(186);

    /** 		if not switch_stack[$][SWITCH_FALLTHRU] and*/
    if (IS_SEQUENCE(_39switch_stack_54352)){
            _29295 = SEQ_PTR(_39switch_stack_54352)->length;
    }
    else {
        _29295 = 1;
    }
    _2 = (int)SEQ_PTR(_39switch_stack_54352);
    _29296 = (int)*(((s1_ptr)_2)->base + _29295);
    _2 = (int)SEQ_PTR(_29296);
    _29297 = (int)*(((s1_ptr)_2)->base + 5);
    _29296 = NOVALUE;
    if (IS_ATOM_INT(_29297)) {
        _29298 = (_29297 == 0);
    }
    else {
        _29298 = unary_op(NOT, _29297);
    }
    _29297 = NOVALUE;
    if (IS_ATOM_INT(_29298)) {
        if (_29298 == 0) {
            goto L3; // [64] 110
        }
    }
    else {
        if (DBL_PTR(_29298)->dbl == 0.0) {
            goto L3; // [64] 110
        }
    }
    _29300 = (_39fallthru_case_57556 == 0);
    if (_29300 == 0)
    {
        DeRef(_29300);
        _29300 = NOVALUE;
        goto L3; // [74] 110
    }
    else{
        DeRef(_29300);
        _29300 = NOVALUE;
    }

    /** 			putback( {CASE, 0} )*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 186;
    ((int *)_2)[2] = 0;
    _29301 = MAKE_SEQ(_1);
    _39putback(_29301);
    _29301 = NOVALUE;

    /** 			Break_statement()*/
    _39Break_statement();

    /** 			tok = next_token()*/
    _0 = _tok_57560;
    _tok_57560 = _39next_token();
    DeRef(_0);
    goto L3; // [98] 110
L2: 

    /** 		Start_block( CASE )*/
    _66Start_block(186, 0);
L3: 

    /** 	StartSourceLine(TRUE, , COVERAGE_SUPPRESS)*/
    _41StartSourceLine(_13TRUE_436, 0, 1);

    /** 	fallthru_case = 0*/
    _39fallthru_case_57556 = 0;

    /** 	integer start_line = line_number*/
    _start_line_57591 = _35line_number_16245;

    /** 	while 1 do*/
L4: 

    /** 		if else_case() then*/

    /** 	return switch_stack[$][SWITCH_ELSE]*/
    if (IS_SEQUENCE(_39switch_stack_54352)){
            _else_case_1__tmp_at145_57597 = SEQ_PTR(_39switch_stack_54352)->length;
    }
    else {
        _else_case_1__tmp_at145_57597 = 1;
    }
    DeRef(_else_case_2__tmp_at145_57598);
    _2 = (int)SEQ_PTR(_39switch_stack_54352);
    _else_case_2__tmp_at145_57598 = (int)*(((s1_ptr)_2)->base + _else_case_1__tmp_at145_57597);
    RefDS(_else_case_2__tmp_at145_57598);
    DeRef(_else_case_inlined_else_case_at_145_57596);
    _2 = (int)SEQ_PTR(_else_case_2__tmp_at145_57598);
    _else_case_inlined_else_case_at_145_57596 = (int)*(((s1_ptr)_2)->base + 3);
    Ref(_else_case_inlined_else_case_at_145_57596);
    DeRef(_else_case_2__tmp_at145_57598);
    _else_case_2__tmp_at145_57598 = NOVALUE;
    if (_else_case_inlined_else_case_at_145_57596 == 0) {
        goto L5; // [160] 171
    }
    else {
        if (!IS_ATOM_INT(_else_case_inlined_else_case_at_145_57596) && DBL_PTR(_else_case_inlined_else_case_at_145_57596)->dbl == 0.0){
            goto L5; // [160] 171
        }
    }

    /** 			CompileErr( 33 )*/
    RefDS(_22023);
    _44CompileErr(33, _22023, 0);
L5: 

    /** 		maybe_namespace()*/
    _61maybe_namespace();

    /** 		tok = next_token()*/
    _0 = _tok_57560;
    _tok_57560 = _39next_token();
    DeRef(_0);

    /** 		integer sign = 1*/
    _sign_57602 = 1;

    /** 		if tok[T_ID] = MINUS then*/
    _2 = (int)SEQ_PTR(_tok_57560);
    _29304 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29304, 10)){
        _29304 = NOVALUE;
        goto L6; // [195] 212
    }
    _29304 = NOVALUE;

    /** 			sign = -1*/
    _sign_57602 = -1;

    /** 			tok = next_token()*/
    _0 = _tok_57560;
    _tok_57560 = _39next_token();
    DeRef(_0);
    goto L7; // [209] 233
L6: 

    /** 		elsif tok[T_ID] = PLUS then*/
    _2 = (int)SEQ_PTR(_tok_57560);
    _29307 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29307, 11)){
        _29307 = NOVALUE;
        goto L8; // [222] 232
    }
    _29307 = NOVALUE;

    /** 			tok = next_token()*/
    _0 = _tok_57560;
    _tok_57560 = _39next_token();
    DeRef(_0);
L8: 
L7: 

    /** 		integer fwd*/

    /** 		if not find( tok[T_ID], {ATOM, STRING, ELSE} ) then*/
    _2 = (int)SEQ_PTR(_tok_57560);
    _29310 = (int)*(((s1_ptr)_2)->base + 1);
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 502;
    *((int *)(_2+8)) = 503;
    *((int *)(_2+12)) = 23;
    _29311 = MAKE_SEQ(_1);
    _29312 = find_from(_29310, _29311, 1);
    _29310 = NOVALUE;
    DeRefDS(_29311);
    _29311 = NOVALUE;
    if (_29312 != 0)
    goto L9; // [260] 435
    _29312 = NOVALUE;

    /** 			integer symi = tok[T_SYM]*/
    _2 = (int)SEQ_PTR(_tok_57560);
    _symi_57625 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_symi_57625)){
        _symi_57625 = (long)DBL_PTR(_symi_57625)->dbl;
    }

    /** 			fwd = -1*/
    _fwd_57615 = -1;

    /** 			if symi > 0 then*/
    if (_symi_57625 <= 0)
    goto LA; // [280] 430

    /** 				if find(tok[T_ID] , VAR_TOKS) then*/
    _2 = (int)SEQ_PTR(_tok_57560);
    _29316 = (int)*(((s1_ptr)_2)->base + 1);
    _29317 = find_from(_29316, _37VAR_TOKS_15880, 1);
    _29316 = NOVALUE;
    if (_29317 == 0)
    {
        _29317 = NOVALUE;
        goto LB; // [299] 429
    }
    else{
        _29317 = NOVALUE;
    }

    /** 					if SymTab[symi][S_SCOPE] = SC_UNDEFINED then*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _29318 = (int)*(((s1_ptr)_2)->base + _symi_57625);
    _2 = (int)SEQ_PTR(_29318);
    _29319 = (int)*(((s1_ptr)_2)->base + 4);
    _29318 = NOVALUE;
    if (binary_op_a(NOTEQ, _29319, 9)){
        _29319 = NOVALUE;
        goto LC; // [318] 330
    }
    _29319 = NOVALUE;

    /** 						fwd = symi*/
    _fwd_57615 = _symi_57625;
    goto LD; // [327] 428
LC: 

    /** 					elsif SymTab[symi][S_MODE] = M_CONSTANT then*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _29321 = (int)*(((s1_ptr)_2)->base + _symi_57625);
    _2 = (int)SEQ_PTR(_29321);
    _29322 = (int)*(((s1_ptr)_2)->base + 3);
    _29321 = NOVALUE;
    if (binary_op_a(NOTEQ, _29322, 2)){
        _29322 = NOVALUE;
        goto LE; // [346] 427
    }
    _29322 = NOVALUE;

    /** 						fwd = 0*/
    _fwd_57615 = 0;

    /** 						if SymTab[symi][S_CODE] then*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _29324 = (int)*(((s1_ptr)_2)->base + _symi_57625);
    _2 = (int)SEQ_PTR(_29324);
    if (!IS_ATOM_INT(_35S_CODE_15929)){
        _29325 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_CODE_15929)->dbl));
    }
    else{
        _29325 = (int)*(((s1_ptr)_2)->base + _35S_CODE_15929);
    }
    _29324 = NOVALUE;
    if (_29325 == 0) {
        _29325 = NOVALUE;
        goto LF; // [369] 393
    }
    else {
        if (!IS_ATOM_INT(_29325) && DBL_PTR(_29325)->dbl == 0.0){
            _29325 = NOVALUE;
            goto LF; // [369] 393
        }
        _29325 = NOVALUE;
    }
    _29325 = NOVALUE;

    /** 							tok[T_SYM] = SymTab[symi][S_CODE]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _29326 = (int)*(((s1_ptr)_2)->base + _symi_57625);
    _2 = (int)SEQ_PTR(_29326);
    if (!IS_ATOM_INT(_35S_CODE_15929)){
        _29327 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_CODE_15929)->dbl));
    }
    else{
        _29327 = (int)*(((s1_ptr)_2)->base + _35S_CODE_15929);
    }
    _29326 = NOVALUE;
    Ref(_29327);
    _2 = (int)SEQ_PTR(_tok_57560);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _tok_57560 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _29327;
    if( _1 != _29327 ){
        DeRef(_1);
    }
    _29327 = NOVALUE;
LF: 

    /** 						SymTab[symi][S_USAGE] = or_bits( SymTab[symi][S_USAGE], U_READ )*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_symi_57625 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _29330 = (int)*(((s1_ptr)_2)->base + _symi_57625);
    _2 = (int)SEQ_PTR(_29330);
    _29331 = (int)*(((s1_ptr)_2)->base + 5);
    _29330 = NOVALUE;
    if (IS_ATOM_INT(_29331)) {
        {unsigned long tu;
             tu = (unsigned long)_29331 | (unsigned long)1;
             _29332 = MAKE_UINT(tu);
        }
    }
    else {
        _29332 = binary_op(OR_BITS, _29331, 1);
    }
    _29331 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = _29332;
    if( _1 != _29332 ){
        DeRef(_1);
    }
    _29332 = NOVALUE;
    _29328 = NOVALUE;
LE: 
LD: 
LB: 
LA: 
    goto L10; // [432] 441
L9: 

    /** 			fwd = 0*/
    _fwd_57615 = 0;
L10: 

    /** 		if fwd < 0 then*/
    if (_fwd_57615 >= 0)
    goto L11; // [445] 471

    /** 			CompileErr( 91, {find_category(tok[T_ID])})*/
    _2 = (int)SEQ_PTR(_tok_57560);
    _29334 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_29334);
    _29335 = _63find_category(_29334);
    _29334 = NOVALUE;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _29335;
    _29336 = MAKE_SEQ(_1);
    _29335 = NOVALUE;
    _44CompileErr(91, _29336, 0);
    _29336 = NOVALUE;
L11: 

    /** 		if tok[T_ID] = ELSE then*/
    _2 = (int)SEQ_PTR(_tok_57560);
    _29337 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29337, 23)){
        _29337 = NOVALUE;
        goto L12; // [481] 542
    }
    _29337 = NOVALUE;

    /** 			if sign = -1 then*/
    if (_sign_57602 != -1)
    goto L13; // [487] 499

    /** 				CompileErr( 71 )*/
    RefDS(_22023);
    _44CompileErr(71, _22023, 0);
L13: 

    /** 			if length(switch_stack[$][SWITCH_CASES]) = 0 then*/
    if (IS_SEQUENCE(_39switch_stack_54352)){
            _29340 = SEQ_PTR(_39switch_stack_54352)->length;
    }
    else {
        _29340 = 1;
    }
    _2 = (int)SEQ_PTR(_39switch_stack_54352);
    _29341 = (int)*(((s1_ptr)_2)->base + _29340);
    _2 = (int)SEQ_PTR(_29341);
    _29342 = (int)*(((s1_ptr)_2)->base + 1);
    _29341 = NOVALUE;
    if (IS_SEQUENCE(_29342)){
            _29343 = SEQ_PTR(_29342)->length;
    }
    else {
        _29343 = 1;
    }
    _29342 = NOVALUE;
    if (_29343 != 0)
    goto L14; // [517] 529

    /** 				CompileErr( 44 )*/
    RefDS(_22023);
    _44CompileErr(44, _22023, 0);
L14: 

    /** 			case_else()*/
    _39case_else();

    /** 			exit*/
    goto L15; // [537] 777
    goto L16; // [539] 613
L12: 

    /** 		elsif fwd then*/
    if (_fwd_57615 == 0)
    {
        goto L17; // [544] 596
    }
    else{
    }

    /** 			integer fwdref = new_forward_reference( CASE, fwd )*/
    DeRef(_31648);
    _31648 = 186;
    _fwdref_57694 = _38new_forward_reference(186, _fwd_57615, 186);
    _31648 = NOVALUE;
    if (!IS_ATOM_INT(_fwdref_57694)) {
        _1 = (long)(DBL_PTR(_fwdref_57694)->dbl);
        DeRefDS(_fwdref_57694);
        _fwdref_57694 = _1;
    }

    /** 			add_case( {fwdref}, sign )*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _fwdref_57694;
    _29346 = MAKE_SEQ(_1);
    _39add_case(_29346, _sign_57602);
    _29346 = NOVALUE;

    /** 			fwd:set_data( fwdref, switch_stack[$][SWITCH_PC] )*/
    if (IS_SEQUENCE(_39switch_stack_54352)){
            _29347 = SEQ_PTR(_39switch_stack_54352)->length;
    }
    else {
        _29347 = 1;
    }
    _2 = (int)SEQ_PTR(_39switch_stack_54352);
    _29348 = (int)*(((s1_ptr)_2)->base + _29347);
    _2 = (int)SEQ_PTR(_29348);
    _29349 = (int)*(((s1_ptr)_2)->base + 4);
    _29348 = NOVALUE;
    Ref(_29349);
    _38set_data(_fwdref_57694, _29349);
    _29349 = NOVALUE;
    goto L16; // [593] 613
L17: 

    /** 			condition = tok[T_SYM]*/
    _2 = (int)SEQ_PTR(_tok_57560);
    _condition_57562 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_condition_57562)){
        _condition_57562 = (long)DBL_PTR(_condition_57562)->dbl;
    }

    /** 			add_case( condition, sign )*/
    _39add_case(_condition_57562, _sign_57602);
L16: 

    /** 		tok = next_token()*/
    _0 = _tok_57560;
    _tok_57560 = _39next_token();
    DeRef(_0);

    /** 		if tok[T_ID] = THEN then*/
    _2 = (int)SEQ_PTR(_tok_57560);
    _29352 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29352, 410)){
        _29352 = NOVALUE;
        goto L18; // [628] 732
    }
    _29352 = NOVALUE;

    /** 			tok = next_token()*/
    _0 = _tok_57560;
    _tok_57560 = _39next_token();
    DeRef(_0);

    /** 			if tok[T_ID] = CASE then*/
    _2 = (int)SEQ_PTR(_tok_57560);
    _29355 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29355, 186)){
        _29355 = NOVALUE;
        goto L19; // [647] 717
    }
    _29355 = NOVALUE;

    /** 				if switch_stack[$][SWITCH_FALLTHRU] then*/
    if (IS_SEQUENCE(_39switch_stack_54352)){
            _29357 = SEQ_PTR(_39switch_stack_54352)->length;
    }
    else {
        _29357 = 1;
    }
    _2 = (int)SEQ_PTR(_39switch_stack_54352);
    _29358 = (int)*(((s1_ptr)_2)->base + _29357);
    _2 = (int)SEQ_PTR(_29358);
    _29359 = (int)*(((s1_ptr)_2)->base + 5);
    _29358 = NOVALUE;
    if (_29359 == 0) {
        _29359 = NOVALUE;
        goto L1A; // [666] 681
    }
    else {
        if (!IS_ATOM_INT(_29359) && DBL_PTR(_29359)->dbl == 0.0){
            _29359 = NOVALUE;
            goto L1A; // [666] 681
        }
        _29359 = NOVALUE;
    }
    _29359 = NOVALUE;

    /** 					start_line = line_number*/
    _start_line_57591 = _35line_number_16245;
    goto L1B; // [678] 770
L1A: 

    /** 					putback( tok )*/
    Ref(_tok_57560);
    _39putback(_tok_57560);

    /** 					Warning(220, empty_case_warning_flag,*/
    _2 = (int)SEQ_PTR(_36known_files_15243);
    _29360 = (int)*(((s1_ptr)_2)->base + _35current_file_no_16244);
    Ref(_29360);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _29360;
    ((int *)_2)[2] = _start_line_57591;
    _29361 = MAKE_SEQ(_1);
    _29360 = NOVALUE;
    _44Warning(220, 2048, _29361);
    _29361 = NOVALUE;

    /** 					exit*/
    goto L15; // [711] 777
    goto L1B; // [714] 770
L19: 

    /** 				putback( tok )*/
    Ref(_tok_57560);
    _39putback(_tok_57560);

    /** 				exit*/
    goto L15; // [726] 777
    goto L1B; // [729] 770
L18: 

    /** 		elsif tok[T_ID] != COMMA then*/
    _2 = (int)SEQ_PTR(_tok_57560);
    _29362 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _29362, -30)){
        _29362 = NOVALUE;
        goto L1C; // [742] 769
    }
    _29362 = NOVALUE;

    /** 			CompileErr(66,{LexName(tok[T_ID])})*/
    _2 = (int)SEQ_PTR(_tok_57560);
    _29364 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_29364);
    RefDS(_26467);
    _29365 = _41LexName(_29364, _26467);
    _29364 = NOVALUE;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _29365;
    _29366 = MAKE_SEQ(_1);
    _29365 = NOVALUE;
    _44CompileErr(66, _29366, 0);
    _29366 = NOVALUE;
L1C: 
L1B: 

    /** 	end while*/
    goto L4; // [774] 140
L15: 

    /** 	StartSourceLine( TRUE )*/
    _41StartSourceLine(_13TRUE_436, 0, 2);

    /** 	emit_temp( switch_stack[$][SWITCH_VALUE], NEW_REFERENCE )*/
    if (IS_SEQUENCE(_39switch_stack_54352)){
            _29367 = SEQ_PTR(_39switch_stack_54352)->length;
    }
    else {
        _29367 = 1;
    }
    _2 = (int)SEQ_PTR(_39switch_stack_54352);
    _29368 = (int)*(((s1_ptr)_2)->base + _29367);
    _2 = (int)SEQ_PTR(_29368);
    _29369 = (int)*(((s1_ptr)_2)->base + 6);
    _29368 = NOVALUE;
    Ref(_29369);
    _41emit_temp(_29369, 1);
    _29369 = NOVALUE;

    /** 	flush_temps()*/
    RefDS(_22023);
    _41flush_temps(_22023);

    /** end procedure*/
    DeRef(_tok_57560);
    _29292 = NOVALUE;
    DeRef(_29298);
    _29298 = NOVALUE;
    _29342 = NOVALUE;
    return;
    ;
}


void _39Fallthru_statement()
{
    int _29370 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not in_switch() then*/
    _29370 = _39in_switch();
    if (IS_ATOM_INT(_29370)) {
        if (_29370 != 0){
            DeRef(_29370);
            _29370 = NOVALUE;
            goto L1; // [6] 17
        }
    }
    else {
        if (DBL_PTR(_29370)->dbl != 0.0){
            DeRef(_29370);
            _29370 = NOVALUE;
            goto L1; // [6] 17
        }
    }
    DeRef(_29370);
    _29370 = NOVALUE;

    /** 		CompileErr( 22 )*/
    RefDS(_22023);
    _44CompileErr(22, _22023, 0);
L1: 

    /** 	tok_match( CASE )*/
    _39tok_match(186, 0);

    /** 	fallthru_case = 1*/
    _39fallthru_case_57556 = 1;

    /** 	Case_statement()*/
    _39Case_statement();

    /** end procedure*/
    return;
    ;
}


void _39update_translator_info(int _sym_57760, int _all_ints_57761, int _has_integer_57762, int _has_atom_57763, int _has_sequence_57764)
{
    int _29395 = NOVALUE;
    int _29393 = NOVALUE;
    int _29391 = NOVALUE;
    int _29389 = NOVALUE;
    int _29387 = NOVALUE;
    int _29386 = NOVALUE;
    int _29384 = NOVALUE;
    int _29382 = NOVALUE;
    int _29381 = NOVALUE;
    int _29380 = NOVALUE;
    int _29379 = NOVALUE;
    int _29378 = NOVALUE;
    int _29376 = NOVALUE;
    int _29374 = NOVALUE;
    int _29372 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	SymTab[sym][S_MODE] = M_TEMP    -- override CONSTANT for compile*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_57760 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = 3;
    DeRef(_1);
    _29372 = NOVALUE;

    /** 	SymTab[sym][S_GTYPE] = TYPE_SEQUENCE*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_57760 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 36);
    _1 = *(int *)_2;
    *(int *)_2 = 8;
    DeRef(_1);
    _29374 = NOVALUE;

    /** 	SymTab[sym][S_SEQ_LEN] = length( SymTab[sym][S_OBJ] )*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_57760 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _29378 = (int)*(((s1_ptr)_2)->base + _sym_57760);
    _2 = (int)SEQ_PTR(_29378);
    _29379 = (int)*(((s1_ptr)_2)->base + 1);
    _29378 = NOVALUE;
    if (IS_SEQUENCE(_29379)){
            _29380 = SEQ_PTR(_29379)->length;
    }
    else {
        _29380 = 1;
    }
    _29379 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 32);
    _1 = *(int *)_2;
    *(int *)_2 = _29380;
    if( _1 != _29380 ){
        DeRef(_1);
    }
    _29380 = NOVALUE;
    _29376 = NOVALUE;

    /** 	if SymTab[sym][S_SEQ_LEN] > 0 then*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _29381 = (int)*(((s1_ptr)_2)->base + _sym_57760);
    _2 = (int)SEQ_PTR(_29381);
    _29382 = (int)*(((s1_ptr)_2)->base + 32);
    _29381 = NOVALUE;
    if (binary_op_a(LESSEQ, _29382, 0)){
        _29382 = NOVALUE;
        goto L1; // [89] 198
    }
    _29382 = NOVALUE;

    /** 		if all_ints then*/
    if (_all_ints_57761 == 0)
    {
        goto L2; // [95] 118
    }
    else{
    }

    /** 			SymTab[sym][S_SEQ_ELEM] = TYPE_INTEGER*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_57760 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 33);
    _1 = *(int *)_2;
    *(int *)_2 = 1;
    DeRef(_1);
    _29384 = NOVALUE;
    goto L3; // [115] 216
L2: 

    /** 		elsif has_atom + has_sequence + has_integer > 1 then*/
    _29386 = _has_atom_57763 + _has_sequence_57764;
    if ((long)((unsigned long)_29386 + (unsigned long)HIGH_BITS) >= 0) 
    _29386 = NewDouble((double)_29386);
    if (IS_ATOM_INT(_29386)) {
        _29387 = _29386 + _has_integer_57762;
        if ((long)((unsigned long)_29387 + (unsigned long)HIGH_BITS) >= 0) 
        _29387 = NewDouble((double)_29387);
    }
    else {
        _29387 = NewDouble(DBL_PTR(_29386)->dbl + (double)_has_integer_57762);
    }
    DeRef(_29386);
    _29386 = NOVALUE;
    if (binary_op_a(LESSEQ, _29387, 1)){
        DeRef(_29387);
        _29387 = NOVALUE;
        goto L4; // [128] 152
    }
    DeRef(_29387);
    _29387 = NOVALUE;

    /** 			SymTab[sym][S_SEQ_ELEM] = TYPE_OBJECT*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_57760 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 33);
    _1 = *(int *)_2;
    *(int *)_2 = 16;
    DeRef(_1);
    _29389 = NOVALUE;
    goto L3; // [149] 216
L4: 

    /** 		elsif has_atom then*/
    if (_has_atom_57763 == 0)
    {
        goto L5; // [154] 177
    }
    else{
    }

    /** 			SymTab[sym][S_SEQ_ELEM] = TYPE_ATOM*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_57760 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 33);
    _1 = *(int *)_2;
    *(int *)_2 = 4;
    DeRef(_1);
    _29391 = NOVALUE;
    goto L3; // [174] 216
L5: 

    /** 			SymTab[sym][S_SEQ_ELEM] = TYPE_SEQUENCE*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_57760 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 33);
    _1 = *(int *)_2;
    *(int *)_2 = 8;
    DeRef(_1);
    _29393 = NOVALUE;
    goto L3; // [195] 216
L1: 

    /** 		SymTab[sym][S_SEQ_ELEM] = TYPE_NULL*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_57760 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 33);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _29395 = NOVALUE;
L3: 

    /** end procedure*/
    _29379 = NOVALUE;
    return;
    ;
}


void _39optimize_switch(int _switch_pc_57825, int _else_bp_57826, int _cases_57827, int _jump_table_57828)
{
    int _values_57829 = NOVALUE;
    int _min_57833 = NOVALUE;
    int _max_57835 = NOVALUE;
    int _all_ints_57837 = NOVALUE;
    int _has_integer_57838 = NOVALUE;
    int _has_atom_57839 = NOVALUE;
    int _has_sequence_57840 = NOVALUE;
    int _has_unassigned_57841 = NOVALUE;
    int _has_fwdref_57842 = NOVALUE;
    int _sym_57849 = NOVALUE;
    int _sign_57851 = NOVALUE;
    int _else_target_57915 = NOVALUE;
    int _opcode_57918 = NOVALUE;
    int _delta_57924 = NOVALUE;
    int _jump_57934 = NOVALUE;
    int _switch_table_57938 = NOVALUE;
    int _offset_57941 = NOVALUE;
    int _29473 = NOVALUE;
    int _29472 = NOVALUE;
    int _29471 = NOVALUE;
    int _29470 = NOVALUE;
    int _29468 = NOVALUE;
    int _29466 = NOVALUE;
    int _29463 = NOVALUE;
    int _29462 = NOVALUE;
    int _29461 = NOVALUE;
    int _29460 = NOVALUE;
    int _29459 = NOVALUE;
    int _29458 = NOVALUE;
    int _29457 = NOVALUE;
    int _29454 = NOVALUE;
    int _29452 = NOVALUE;
    int _29451 = NOVALUE;
    int _29450 = NOVALUE;
    int _29449 = NOVALUE;
    int _29448 = NOVALUE;
    int _29447 = NOVALUE;
    int _29446 = NOVALUE;
    int _29442 = NOVALUE;
    int _29441 = NOVALUE;
    int _29439 = NOVALUE;
    int _29438 = NOVALUE;
    int _29437 = NOVALUE;
    int _29436 = NOVALUE;
    int _29435 = NOVALUE;
    int _29434 = NOVALUE;
    int _29433 = NOVALUE;
    int _29432 = NOVALUE;
    int _29431 = NOVALUE;
    int _29430 = NOVALUE;
    int _29428 = NOVALUE;
    int _29427 = NOVALUE;
    int _29423 = NOVALUE;
    int _29420 = NOVALUE;
    int _29419 = NOVALUE;
    int _29418 = NOVALUE;
    int _29416 = NOVALUE;
    int _29415 = NOVALUE;
    int _29414 = NOVALUE;
    int _29413 = NOVALUE;
    int _29412 = NOVALUE;
    int _29410 = NOVALUE;
    int _29409 = NOVALUE;
    int _29408 = NOVALUE;
    int _29404 = NOVALUE;
    int _29403 = NOVALUE;
    int _29402 = NOVALUE;
    int _29398 = NOVALUE;
    int _29397 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	sequence values = switch_stack[$][SWITCH_CASES]*/
    if (IS_SEQUENCE(_39switch_stack_54352)){
            _29397 = SEQ_PTR(_39switch_stack_54352)->length;
    }
    else {
        _29397 = 1;
    }
    _2 = (int)SEQ_PTR(_39switch_stack_54352);
    _29398 = (int)*(((s1_ptr)_2)->base + _29397);
    DeRef(_values_57829);
    _2 = (int)SEQ_PTR(_29398);
    _values_57829 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_values_57829);
    _29398 = NOVALUE;

    /** 	atom min =  1e+300*/
    RefDS(_29400);
    DeRef(_min_57833);
    _min_57833 = _29400;

    /** 	atom max = -1e+300*/
    RefDS(_29401);
    DeRef(_max_57835);
    _max_57835 = _29401;

    /** 	integer all_ints = 1*/
    _all_ints_57837 = 1;

    /** 	integer has_integer    = 0*/
    _has_integer_57838 = 0;

    /** 	integer has_atom       = 0*/
    _has_atom_57839 = 0;

    /** 	integer has_sequence   = 0*/
    _has_sequence_57840 = 0;

    /** 	integer has_unassigned = 0*/
    _has_unassigned_57841 = 0;

    /** 	integer has_fwdref     = 0*/
    _has_fwdref_57842 = 0;

    /** 	for i = 1 to length( values ) do*/
    if (IS_SEQUENCE(_values_57829)){
            _29402 = SEQ_PTR(_values_57829)->length;
    }
    else {
        _29402 = 1;
    }
    {
        int _i_57844;
        _i_57844 = 1;
L1: 
        if (_i_57844 > _29402){
            goto L2; // [71] 292
        }

        /** 		if sequence( values[i] ) then*/
        _2 = (int)SEQ_PTR(_values_57829);
        _29403 = (int)*(((s1_ptr)_2)->base + _i_57844);
        _29404 = IS_SEQUENCE(_29403);
        _29403 = NOVALUE;
        if (_29404 == 0)
        {
            _29404 = NOVALUE;
            goto L3; // [87] 100
        }
        else{
            _29404 = NOVALUE;
        }

        /** 			has_fwdref = 1*/
        _has_fwdref_57842 = 1;

        /** 			exit*/
        goto L2; // [97] 292
L3: 

        /** 		integer sym = values[i]*/
        _2 = (int)SEQ_PTR(_values_57829);
        _sym_57849 = (int)*(((s1_ptr)_2)->base + _i_57844);
        if (!IS_ATOM_INT(_sym_57849))
        _sym_57849 = (long)DBL_PTR(_sym_57849)->dbl;

        /** 		integer sign*/

        /** 		if sym < 0 then*/
        if (_sym_57849 >= 0)
        goto L4; // [110] 129

        /** 			sign = -1*/
        _sign_57851 = -1;

        /** 			sym = -sym*/
        _sym_57849 = - _sym_57849;
        goto L5; // [126] 135
L4: 

        /** 			sign = 1*/
        _sign_57851 = 1;
L5: 

        /** 		if not equal(SymTab[sym][S_OBJ], NOVALUE) then*/
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _29408 = (int)*(((s1_ptr)_2)->base + _sym_57849);
        _2 = (int)SEQ_PTR(_29408);
        _29409 = (int)*(((s1_ptr)_2)->base + 1);
        _29408 = NOVALUE;
        if (_29409 == _35NOVALUE_16099)
        _29410 = 1;
        else if (IS_ATOM_INT(_29409) && IS_ATOM_INT(_35NOVALUE_16099))
        _29410 = 0;
        else
        _29410 = (compare(_29409, _35NOVALUE_16099) == 0);
        _29409 = NOVALUE;
        if (_29410 != 0)
        goto L6; // [155] 271
        _29410 = NOVALUE;

        /** 			values[i] = sign * SymTab[sym][S_OBJ]*/
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _29412 = (int)*(((s1_ptr)_2)->base + _sym_57849);
        _2 = (int)SEQ_PTR(_29412);
        _29413 = (int)*(((s1_ptr)_2)->base + 1);
        _29412 = NOVALUE;
        if (IS_ATOM_INT(_29413)) {
            if (_sign_57851 == (short)_sign_57851 && _29413 <= INT15 && _29413 >= -INT15)
            _29414 = _sign_57851 * _29413;
            else
            _29414 = NewDouble(_sign_57851 * (double)_29413);
        }
        else {
            _29414 = binary_op(MULTIPLY, _sign_57851, _29413);
        }
        _29413 = NOVALUE;
        _2 = (int)SEQ_PTR(_values_57829);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _values_57829 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_57844);
        _1 = *(int *)_2;
        *(int *)_2 = _29414;
        if( _1 != _29414 ){
            DeRef(_1);
        }
        _29414 = NOVALUE;

        /** 			if not integer( values[i] ) then*/
        _2 = (int)SEQ_PTR(_values_57829);
        _29415 = (int)*(((s1_ptr)_2)->base + _i_57844);
        if (IS_ATOM_INT(_29415))
        _29416 = 1;
        else if (IS_ATOM_DBL(_29415))
        _29416 = IS_ATOM_INT(DoubleToInt(_29415));
        else
        _29416 = 0;
        _29415 = NOVALUE;
        if (_29416 != 0)
        goto L7; // [191] 228
        _29416 = NOVALUE;

        /** 				all_ints = 0*/
        _all_ints_57837 = 0;

        /** 				if atom( values[i] ) then*/
        _2 = (int)SEQ_PTR(_values_57829);
        _29418 = (int)*(((s1_ptr)_2)->base + _i_57844);
        _29419 = IS_ATOM(_29418);
        _29418 = NOVALUE;
        if (_29419 == 0)
        {
            _29419 = NOVALUE;
            goto L8; // [208] 219
        }
        else{
            _29419 = NOVALUE;
        }

        /** 					has_atom = 1*/
        _has_atom_57839 = 1;
        goto L9; // [216] 283
L8: 

        /** 					has_sequence = 1*/
        _has_sequence_57840 = 1;
        goto L9; // [225] 283
L7: 

        /** 				has_integer = 1*/
        _has_integer_57838 = 1;

        /** 				if values[i] < min then*/
        _2 = (int)SEQ_PTR(_values_57829);
        _29420 = (int)*(((s1_ptr)_2)->base + _i_57844);
        if (binary_op_a(GREATEREQ, _29420, _min_57833)){
            _29420 = NOVALUE;
            goto LA; // [239] 250
        }
        _29420 = NOVALUE;

        /** 					min = values[i]*/
        DeRef(_min_57833);
        _2 = (int)SEQ_PTR(_values_57829);
        _min_57833 = (int)*(((s1_ptr)_2)->base + _i_57844);
        Ref(_min_57833);
LA: 

        /** 				if values[i] > max then*/
        _2 = (int)SEQ_PTR(_values_57829);
        _29423 = (int)*(((s1_ptr)_2)->base + _i_57844);
        if (binary_op_a(LESSEQ, _29423, _max_57835)){
            _29423 = NOVALUE;
            goto L9; // [256] 283
        }
        _29423 = NOVALUE;

        /** 					max = values[i]*/
        DeRef(_max_57835);
        _2 = (int)SEQ_PTR(_values_57829);
        _max_57835 = (int)*(((s1_ptr)_2)->base + _i_57844);
        Ref(_max_57835);
        goto L9; // [268] 283
L6: 

        /** 			has_unassigned = 1*/
        _has_unassigned_57841 = 1;

        /** 			exit*/
        goto L2; // [280] 292
L9: 

        /** 	end for*/
        _i_57844 = _i_57844 + 1;
        goto L1; // [287] 78
L2: 
        ;
    }

    /** 	if has_unassigned or has_fwdref then*/
    if (_has_unassigned_57841 != 0) {
        goto LB; // [294] 303
    }
    if (_has_fwdref_57842 == 0)
    {
        goto LC; // [299] 321
    }
    else{
    }
LB: 

    /** 		values = switch_stack[$][SWITCH_CASES]*/
    if (IS_SEQUENCE(_39switch_stack_54352)){
            _29427 = SEQ_PTR(_39switch_stack_54352)->length;
    }
    else {
        _29427 = 1;
    }
    _2 = (int)SEQ_PTR(_39switch_stack_54352);
    _29428 = (int)*(((s1_ptr)_2)->base + _29427);
    DeRef(_values_57829);
    _2 = (int)SEQ_PTR(_29428);
    _values_57829 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_values_57829);
    _29428 = NOVALUE;
LC: 

    /** 	if switch_stack[$][SWITCH_ELSE] then*/
    if (IS_SEQUENCE(_39switch_stack_54352)){
            _29430 = SEQ_PTR(_39switch_stack_54352)->length;
    }
    else {
        _29430 = 1;
    }
    _2 = (int)SEQ_PTR(_39switch_stack_54352);
    _29431 = (int)*(((s1_ptr)_2)->base + _29430);
    _2 = (int)SEQ_PTR(_29431);
    _29432 = (int)*(((s1_ptr)_2)->base + 3);
    _29431 = NOVALUE;
    if (_29432 == 0) {
        _29432 = NOVALUE;
        goto LD; // [336] 363
    }
    else {
        if (!IS_ATOM_INT(_29432) && DBL_PTR(_29432)->dbl == 0.0){
            _29432 = NOVALUE;
            goto LD; // [336] 363
        }
        _29432 = NOVALUE;
    }
    _29432 = NOVALUE;

    /** 			Code[else_bp] = switch_stack[$][SWITCH_ELSE]*/
    if (IS_SEQUENCE(_39switch_stack_54352)){
            _29433 = SEQ_PTR(_39switch_stack_54352)->length;
    }
    else {
        _29433 = 1;
    }
    _2 = (int)SEQ_PTR(_39switch_stack_54352);
    _29434 = (int)*(((s1_ptr)_2)->base + _29433);
    _2 = (int)SEQ_PTR(_29434);
    _29435 = (int)*(((s1_ptr)_2)->base + 3);
    _29434 = NOVALUE;
    Ref(_29435);
    _2 = (int)SEQ_PTR(_35Code_16332);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _35Code_16332 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _else_bp_57826);
    _1 = *(int *)_2;
    *(int *)_2 = _29435;
    if( _1 != _29435 ){
        DeRef(_1);
    }
    _29435 = NOVALUE;
    goto LE; // [360] 387
LD: 

    /** 		Code[else_bp] = length(Code) + 1 + TRANSLATE*/
    if (IS_SEQUENCE(_35Code_16332)){
            _29436 = SEQ_PTR(_35Code_16332)->length;
    }
    else {
        _29436 = 1;
    }
    _29437 = _29436 + 1;
    _29436 = NOVALUE;
    _29438 = _29437 + _35TRANSLATE_15887;
    _29437 = NOVALUE;
    _2 = (int)SEQ_PTR(_35Code_16332);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _35Code_16332 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _else_bp_57826);
    _1 = *(int *)_2;
    *(int *)_2 = _29438;
    if( _1 != _29438 ){
        DeRef(_1);
    }
    _29438 = NOVALUE;
LE: 

    /** 	if TRANSLATE then*/
    if (_35TRANSLATE_15887 == 0)
    {
        goto LF; // [391] 418
    }
    else{
    }

    /** 		SymTab[cases][S_OBJ] &= 0*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_cases_57827 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    _29441 = (int)*(((s1_ptr)_2)->base + 1);
    _29439 = NOVALUE;
    if (IS_SEQUENCE(_29441) && IS_ATOM(0)) {
        Append(&_29442, _29441, 0);
    }
    else if (IS_ATOM(_29441) && IS_SEQUENCE(0)) {
    }
    else {
        Concat((object_ptr)&_29442, _29441, 0);
        _29441 = NOVALUE;
    }
    _29441 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _29442;
    if( _1 != _29442 ){
        DeRef(_1);
    }
    _29442 = NOVALUE;
    _29439 = NOVALUE;
LF: 

    /** 	integer else_target = Code[else_bp]*/
    _2 = (int)SEQ_PTR(_35Code_16332);
    _else_target_57915 = (int)*(((s1_ptr)_2)->base + _else_bp_57826);
    if (!IS_ATOM_INT(_else_target_57915)){
        _else_target_57915 = (long)DBL_PTR(_else_target_57915)->dbl;
    }

    /** 	integer opcode = SWITCH*/
    _opcode_57918 = 185;

    /** 	if has_unassigned or has_fwdref then*/
    if (_has_unassigned_57841 != 0) {
        goto L10; // [439] 448
    }
    if (_has_fwdref_57842 == 0)
    {
        goto L11; // [444] 460
    }
    else{
    }
L10: 

    /** 		opcode = SWITCH_RT*/
    _opcode_57918 = 202;
    goto L12; // [457] 630
L11: 

    /** 	elsif all_ints then*/
    if (_all_ints_57837 == 0)
    {
        goto L13; // [462] 627
    }
    else{
    }

    /** 		atom delta = max - min*/
    DeRef(_delta_57924);
    if (IS_ATOM_INT(_max_57835) && IS_ATOM_INT(_min_57833)) {
        _delta_57924 = _max_57835 - _min_57833;
        if ((long)((unsigned long)_delta_57924 +(unsigned long) HIGH_BITS) >= 0){
            _delta_57924 = NewDouble((double)_delta_57924);
        }
    }
    else {
        if (IS_ATOM_INT(_max_57835)) {
            _delta_57924 = NewDouble((double)_max_57835 - DBL_PTR(_min_57833)->dbl);
        }
        else {
            if (IS_ATOM_INT(_min_57833)) {
                _delta_57924 = NewDouble(DBL_PTR(_max_57835)->dbl - (double)_min_57833);
            }
            else
            _delta_57924 = NewDouble(DBL_PTR(_max_57835)->dbl - DBL_PTR(_min_57833)->dbl);
        }
    }

    /** 		if not TRANSLATE and  delta < 1024 and delta >= 0 then*/
    _29446 = (_35TRANSLATE_15887 == 0);
    if (_29446 == 0) {
        _29447 = 0;
        goto L14; // [478] 490
    }
    if (IS_ATOM_INT(_delta_57924)) {
        _29448 = (_delta_57924 < 1024);
    }
    else {
        _29448 = (DBL_PTR(_delta_57924)->dbl < (double)1024);
    }
    _29447 = (_29448 != 0);
L14: 
    if (_29447 == 0) {
        goto L15; // [490] 616
    }
    if (IS_ATOM_INT(_delta_57924)) {
        _29450 = (_delta_57924 >= 0);
    }
    else {
        _29450 = (DBL_PTR(_delta_57924)->dbl >= (double)0);
    }
    if (_29450 == 0)
    {
        DeRef(_29450);
        _29450 = NOVALUE;
        goto L15; // [499] 616
    }
    else{
        DeRef(_29450);
        _29450 = NOVALUE;
    }

    /** 			opcode = SWITCH_SPI*/
    _opcode_57918 = 192;

    /** 			sequence jump = switch_stack[$][SWITCH_JUMP_TABLE]*/
    if (IS_SEQUENCE(_39switch_stack_54352)){
            _29451 = SEQ_PTR(_39switch_stack_54352)->length;
    }
    else {
        _29451 = 1;
    }
    _2 = (int)SEQ_PTR(_39switch_stack_54352);
    _29452 = (int)*(((s1_ptr)_2)->base + _29451);
    DeRef(_jump_57934);
    _2 = (int)SEQ_PTR(_29452);
    _jump_57934 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_jump_57934);
    _29452 = NOVALUE;

    /** 			sequence switch_table = repeat( else_target, delta + 1 )*/
    if (IS_ATOM_INT(_delta_57924)) {
        _29454 = _delta_57924 + 1;
    }
    else
    _29454 = binary_op(PLUS, 1, _delta_57924);
    DeRef(_switch_table_57938);
    _switch_table_57938 = Repeat(_else_target_57915, _29454);
    DeRef(_29454);
    _29454 = NOVALUE;

    /** 			integer offset = min - 1*/
    if (IS_ATOM_INT(_min_57833)) {
        _offset_57941 = _min_57833 - 1;
    }
    else {
        _offset_57941 = NewDouble(DBL_PTR(_min_57833)->dbl - (double)1);
    }
    if (!IS_ATOM_INT(_offset_57941)) {
        _1 = (long)(DBL_PTR(_offset_57941)->dbl);
        DeRefDS(_offset_57941);
        _offset_57941 = _1;
    }

    /** 			for i = 1 to length( values ) do*/
    if (IS_SEQUENCE(_values_57829)){
            _29457 = SEQ_PTR(_values_57829)->length;
    }
    else {
        _29457 = 1;
    }
    {
        int _i_57944;
        _i_57944 = 1;
L16: 
        if (_i_57944 > _29457){
            goto L17; // [551] 583
        }

        /** 				switch_table[values[i] - offset] = jump[i]*/
        _2 = (int)SEQ_PTR(_values_57829);
        _29458 = (int)*(((s1_ptr)_2)->base + _i_57944);
        if (IS_ATOM_INT(_29458)) {
            _29459 = _29458 - _offset_57941;
            if ((long)((unsigned long)_29459 +(unsigned long) HIGH_BITS) >= 0){
                _29459 = NewDouble((double)_29459);
            }
        }
        else {
            _29459 = binary_op(MINUS, _29458, _offset_57941);
        }
        _29458 = NOVALUE;
        _2 = (int)SEQ_PTR(_jump_57934);
        _29460 = (int)*(((s1_ptr)_2)->base + _i_57944);
        Ref(_29460);
        _2 = (int)SEQ_PTR(_switch_table_57938);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _switch_table_57938 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_29459))
        _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_29459)->dbl));
        else
        _2 = (int)(((s1_ptr)_2)->base + _29459);
        _1 = *(int *)_2;
        *(int *)_2 = _29460;
        if( _1 != _29460 ){
            DeRef(_1);
        }
        _29460 = NOVALUE;

        /** 			end for*/
        _i_57944 = _i_57944 + 1;
        goto L16; // [578] 558
L17: 
        ;
    }

    /** 			Code[switch_pc + 2] = offset*/
    _29461 = _switch_pc_57825 + 2;
    _2 = (int)SEQ_PTR(_35Code_16332);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _35Code_16332 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _29461);
    _1 = *(int *)_2;
    *(int *)_2 = _offset_57941;
    DeRef(_1);

    /** 			switch_stack[$][SWITCH_JUMP_TABLE] = switch_table*/
    if (IS_SEQUENCE(_39switch_stack_54352)){
            _29462 = SEQ_PTR(_39switch_stack_54352)->length;
    }
    else {
        _29462 = 1;
    }
    _2 = (int)SEQ_PTR(_39switch_stack_54352);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _39switch_stack_54352 = MAKE_SEQ(_2);
    }
    _3 = (int)(_29462 + ((s1_ptr)_2)->base);
    RefDS(_switch_table_57938);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _switch_table_57938;
    DeRef(_1);
    _29463 = NOVALUE;
    DeRef(_jump_57934);
    _jump_57934 = NOVALUE;
    DeRefDS(_switch_table_57938);
    _switch_table_57938 = NOVALUE;
    goto L18; // [613] 626
L15: 

    /** 			opcode = SWITCH_I*/
    _opcode_57918 = 193;
L18: 
L13: 
    DeRef(_delta_57924);
    _delta_57924 = NOVALUE;
L12: 

    /** 	Code[switch_pc] = opcode*/
    _2 = (int)SEQ_PTR(_35Code_16332);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _35Code_16332 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _switch_pc_57825);
    _1 = *(int *)_2;
    *(int *)_2 = _opcode_57918;
    DeRef(_1);

    /** 	if opcode != SWITCH_SPI then*/
    if (_opcode_57918 == 192)
    goto L19; // [642] 679

    /** 		SymTab[cases][S_OBJ] = values*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_cases_57827 + ((s1_ptr)_2)->base);
    RefDS(_values_57829);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _values_57829;
    DeRef(_1);
    _29466 = NOVALUE;

    /** 		if TRANSLATE then*/
    if (_35TRANSLATE_15887 == 0)
    {
        goto L1A; // [665] 678
    }
    else{
    }

    /** 			update_translator_info( cases, all_ints, has_integer, has_atom, has_sequence )*/
    _39update_translator_info(_cases_57827, _all_ints_57837, _has_integer_57838, _has_atom_57839, _has_sequence_57840);
L1A: 
L19: 

    /** 	SymTab[jump_table][S_OBJ] = switch_stack[$][SWITCH_JUMP_TABLE] - switch_pc*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_jump_table_57828 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_39switch_stack_54352)){
            _29470 = SEQ_PTR(_39switch_stack_54352)->length;
    }
    else {
        _29470 = 1;
    }
    _2 = (int)SEQ_PTR(_39switch_stack_54352);
    _29471 = (int)*(((s1_ptr)_2)->base + _29470);
    _2 = (int)SEQ_PTR(_29471);
    _29472 = (int)*(((s1_ptr)_2)->base + 2);
    _29471 = NOVALUE;
    if (IS_ATOM_INT(_29472)) {
        _29473 = _29472 - _switch_pc_57825;
        if ((long)((unsigned long)_29473 +(unsigned long) HIGH_BITS) >= 0){
            _29473 = NewDouble((double)_29473);
        }
    }
    else {
        _29473 = binary_op(MINUS, _29472, _switch_pc_57825);
    }
    _29472 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _29473;
    if( _1 != _29473 ){
        DeRef(_1);
    }
    _29473 = NOVALUE;
    _29468 = NOVALUE;

    /** end procedure*/
    DeRef(_values_57829);
    DeRef(_min_57833);
    DeRef(_max_57835);
    DeRef(_29446);
    _29446 = NOVALUE;
    DeRef(_29448);
    _29448 = NOVALUE;
    DeRef(_29461);
    _29461 = NOVALUE;
    DeRef(_29459);
    _29459 = NOVALUE;
    return;
    ;
}


void _39Switch_statement()
{
    int _else_case_2__tmp_at250_58038 = NOVALUE;
    int _else_case_1__tmp_at250_58037 = NOVALUE;
    int _else_case_inlined_else_case_at_250_58036 = NOVALUE;
    int _break_base_57976 = NOVALUE;
    int _cases_57978 = NOVALUE;
    int _jump_table_57979 = NOVALUE;
    int _else_bp_57980 = NOVALUE;
    int _switch_pc_57981 = NOVALUE;
    int _t_58018 = NOVALUE;
    int _29504 = NOVALUE;
    int _29503 = NOVALUE;
    int _29502 = NOVALUE;
    int _29501 = NOVALUE;
    int _29500 = NOVALUE;
    int _29496 = NOVALUE;
    int _29492 = NOVALUE;
    int _29491 = NOVALUE;
    int _29489 = NOVALUE;
    int _29488 = NOVALUE;
    int _29486 = NOVALUE;
    int _29485 = NOVALUE;
    int _29483 = NOVALUE;
    int _29482 = NOVALUE;
    int _29481 = NOVALUE;
    int _29480 = NOVALUE;
    int _29479 = NOVALUE;
    int _29478 = NOVALUE;
    int _29476 = NOVALUE;
    int _29475 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	integer else_bp*/

    /** 	integer switch_pc*/

    /** 	push_switch()*/
    _39push_switch();

    /** 	break_base = length(break_list)*/
    if (IS_SEQUENCE(_39break_list_54135)){
            _break_base_57976 = SEQ_PTR(_39break_list_54135)->length;
    }
    else {
        _break_base_57976 = 1;
    }

    /** 	Expr()*/
    _39Expr();

    /** 	switch_stack[$][SWITCH_VALUE] = Top()*/
    if (IS_SEQUENCE(_39switch_stack_54352)){
            _29475 = SEQ_PTR(_39switch_stack_54352)->length;
    }
    else {
        _29475 = 1;
    }
    _2 = (int)SEQ_PTR(_39switch_stack_54352);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _39switch_stack_54352 = MAKE_SEQ(_2);
    }
    _3 = (int)(_29475 + ((s1_ptr)_2)->base);
    _29478 = _41Top();
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 6);
    _1 = *(int *)_2;
    *(int *)_2 = _29478;
    if( _1 != _29478 ){
        DeRef(_1);
    }
    _29478 = NOVALUE;
    _29476 = NOVALUE;

    /** 	clear_temp( switch_stack[$][SWITCH_VALUE] )*/
    if (IS_SEQUENCE(_39switch_stack_54352)){
            _29479 = SEQ_PTR(_39switch_stack_54352)->length;
    }
    else {
        _29479 = 1;
    }
    _2 = (int)SEQ_PTR(_39switch_stack_54352);
    _29480 = (int)*(((s1_ptr)_2)->base + _29479);
    _2 = (int)SEQ_PTR(_29480);
    _29481 = (int)*(((s1_ptr)_2)->base + 6);
    _29480 = NOVALUE;
    Ref(_29481);
    _41clear_temp(_29481);
    _29481 = NOVALUE;

    /** 	cases = NewStringSym( {-1, length(SymTab) } )*/
    if (IS_SEQUENCE(_36SymTab_15242)){
            _29482 = SEQ_PTR(_36SymTab_15242)->length;
    }
    else {
        _29482 = 1;
    }
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -1;
    ((int *)_2)[2] = _29482;
    _29483 = MAKE_SEQ(_1);
    _29482 = NOVALUE;
    _cases_57978 = _53NewStringSym(_29483);
    _29483 = NOVALUE;
    if (!IS_ATOM_INT(_cases_57978)) {
        _1 = (long)(DBL_PTR(_cases_57978)->dbl);
        DeRefDS(_cases_57978);
        _cases_57978 = _1;
    }

    /** 	emit_opnd( cases )*/
    _41emit_opnd(_cases_57978);

    /** 	jump_table = NewStringSym( {-2, length(SymTab) } )*/
    if (IS_SEQUENCE(_36SymTab_15242)){
            _29485 = SEQ_PTR(_36SymTab_15242)->length;
    }
    else {
        _29485 = 1;
    }
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -2;
    ((int *)_2)[2] = _29485;
    _29486 = MAKE_SEQ(_1);
    _29485 = NOVALUE;
    _jump_table_57979 = _53NewStringSym(_29486);
    _29486 = NOVALUE;
    if (!IS_ATOM_INT(_jump_table_57979)) {
        _1 = (long)(DBL_PTR(_jump_table_57979)->dbl);
        DeRefDS(_jump_table_57979);
        _jump_table_57979 = _1;
    }

    /** 	emit_opnd( jump_table )*/
    _41emit_opnd(_jump_table_57979);

    /** 	if finish_block_header(SWITCH) then end if*/
    _29488 = _39finish_block_header(185);
    if (_29488 == 0) {
        DeRef(_29488);
        _29488 = NOVALUE;
        goto L1; // [109] 113
    }
    else {
        if (!IS_ATOM_INT(_29488) && DBL_PTR(_29488)->dbl == 0.0){
            DeRef(_29488);
            _29488 = NOVALUE;
            goto L1; // [109] 113
        }
        DeRef(_29488);
        _29488 = NOVALUE;
    }
    DeRef(_29488);
    _29488 = NOVALUE;
L1: 

    /** 	switch_pc = length(Code) + 1*/
    if (IS_SEQUENCE(_35Code_16332)){
            _29489 = SEQ_PTR(_35Code_16332)->length;
    }
    else {
        _29489 = 1;
    }
    _switch_pc_57981 = _29489 + 1;
    _29489 = NOVALUE;

    /** 	switch_stack[$][SWITCH_PC] = switch_pc*/
    if (IS_SEQUENCE(_39switch_stack_54352)){
            _29491 = SEQ_PTR(_39switch_stack_54352)->length;
    }
    else {
        _29491 = 1;
    }
    _2 = (int)SEQ_PTR(_39switch_stack_54352);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _39switch_stack_54352 = MAKE_SEQ(_2);
    }
    _3 = (int)(_29491 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = _switch_pc_57981;
    DeRef(_1);
    _29492 = NOVALUE;

    /** 	emit_op(SWITCH)*/
    _41emit_op(185);

    /** 	emit_forward_addr()  -- the else*/
    _39emit_forward_addr();

    /** 	else_bp = length( Code )*/
    if (IS_SEQUENCE(_35Code_16332)){
            _else_bp_57980 = SEQ_PTR(_35Code_16332)->length;
    }
    else {
        _else_bp_57980 = 1;
    }

    /** 	t = next_token()*/
    _0 = _t_58018;
    _t_58018 = _39next_token();
    DeRef(_0);

    /** 	if t[T_ID] = CASE then*/
    _2 = (int)SEQ_PTR(_t_58018);
    _29496 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29496, 186)){
        _29496 = NOVALUE;
        goto L2; // [173] 188
    }
    _29496 = NOVALUE;

    /** 		Case_statement()*/
    _39Case_statement();

    /** 		Statement_list()*/
    _39Statement_list();
    goto L3; // [185] 194
L2: 

    /** 		putback(t)*/
    Ref(_t_58018);
    _39putback(_t_58018);
L3: 

    /** 	optimize_switch( switch_pc, else_bp, cases, jump_table )*/
    _39optimize_switch(_switch_pc_57981, _else_bp_57980, _cases_57978, _jump_table_57979);

    /** 	tok_match(END)*/
    _39tok_match(402, 0);

    /** 	tok_match(SWITCH, END)*/
    _39tok_match(185, 402);

    /** 	if TRANSLATE then*/
    if (_35TRANSLATE_15887 == 0)
    {
        goto L4; // [224] 235
    }
    else{
    }

    /** 		emit_op(NOPSWITCH)*/
    _41emit_op(187);
L4: 

    /** 	if not else_case() then*/

    /** 	return switch_stack[$][SWITCH_ELSE]*/
    if (IS_SEQUENCE(_39switch_stack_54352)){
            _else_case_1__tmp_at250_58037 = SEQ_PTR(_39switch_stack_54352)->length;
    }
    else {
        _else_case_1__tmp_at250_58037 = 1;
    }
    DeRef(_else_case_2__tmp_at250_58038);
    _2 = (int)SEQ_PTR(_39switch_stack_54352);
    _else_case_2__tmp_at250_58038 = (int)*(((s1_ptr)_2)->base + _else_case_1__tmp_at250_58037);
    RefDS(_else_case_2__tmp_at250_58038);
    DeRef(_else_case_inlined_else_case_at_250_58036);
    _2 = (int)SEQ_PTR(_else_case_2__tmp_at250_58038);
    _else_case_inlined_else_case_at_250_58036 = (int)*(((s1_ptr)_2)->base + 3);
    Ref(_else_case_inlined_else_case_at_250_58036);
    DeRef(_else_case_2__tmp_at250_58038);
    _else_case_2__tmp_at250_58038 = NOVALUE;
    if (IS_ATOM_INT(_else_case_inlined_else_case_at_250_58036)) {
        if (_else_case_inlined_else_case_at_250_58036 != 0){
            goto L5; // [255] 327
        }
    }
    else {
        if (DBL_PTR(_else_case_inlined_else_case_at_250_58036)->dbl != 0.0){
            goto L5; // [255] 327
        }
    }

    /** 		if not TRANSLATE then*/
    if (_35TRANSLATE_15887 != 0)
    goto L6; // [262] 303

    /** 			StartSourceLine( TRUE, , COVERAGE_SUPPRESS )*/
    _41StartSourceLine(_13TRUE_436, 0, 1);

    /** 			emit_temp( switch_stack[$][SWITCH_VALUE], NEW_REFERENCE )*/
    if (IS_SEQUENCE(_39switch_stack_54352)){
            _29500 = SEQ_PTR(_39switch_stack_54352)->length;
    }
    else {
        _29500 = 1;
    }
    _2 = (int)SEQ_PTR(_39switch_stack_54352);
    _29501 = (int)*(((s1_ptr)_2)->base + _29500);
    _2 = (int)SEQ_PTR(_29501);
    _29502 = (int)*(((s1_ptr)_2)->base + 6);
    _29501 = NOVALUE;
    Ref(_29502);
    _41emit_temp(_29502, 1);
    _29502 = NOVALUE;

    /** 			flush_temps()*/
    RefDS(_22023);
    _41flush_temps(_22023);
L6: 

    /** 		Warning(221, no_case_else_warning_flag,*/
    _2 = (int)SEQ_PTR(_36known_files_15243);
    _29503 = (int)*(((s1_ptr)_2)->base + _35current_file_no_16244);
    Ref(_29503);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _29503;
    ((int *)_2)[2] = _35line_number_16245;
    _29504 = MAKE_SEQ(_1);
    _29503 = NOVALUE;
    _44Warning(221, 4096, _29504);
    _29504 = NOVALUE;
L5: 

    /** 	pop_switch( break_base )*/
    _39pop_switch(_break_base_57976);

    /** end procedure*/
    DeRef(_t_58018);
    return;
    ;
}


int _39get_private_uninitialized()
{
    int _uninitialized_58061 = NOVALUE;
    int _s_58067 = NOVALUE;
    int _pu_58073 = NOVALUE;
    int _29521 = NOVALUE;
    int _29519 = NOVALUE;
    int _29518 = NOVALUE;
    int _29517 = NOVALUE;
    int _29516 = NOVALUE;
    int _29515 = NOVALUE;
    int _29514 = NOVALUE;
    int _29513 = NOVALUE;
    int _29512 = NOVALUE;
    int _29511 = NOVALUE;
    int _29510 = NOVALUE;
    int _29509 = NOVALUE;
    int _29506 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence uninitialized = {}*/
    RefDS(_22023);
    DeRefi(_uninitialized_58061);
    _uninitialized_58061 = _22023;

    /** 	if CurrentSub != TopLevelSub then*/
    if (_35CurrentSub_16252 == _35TopLevelSub_16251)
    goto L1; // [14] 149

    /** 		symtab_pointer s = SymTab[CurrentSub][S_NEXT]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _29506 = (int)*(((s1_ptr)_2)->base + _35CurrentSub_16252);
    _2 = (int)SEQ_PTR(_29506);
    _s_58067 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_58067)){
        _s_58067 = (long)DBL_PTR(_s_58067)->dbl;
    }
    _29506 = NOVALUE;

    /** 		sequence pu = { SC_PRIVATE, SC_UNDEFINED }*/
    DeRefi(_pu_58073);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 3;
    ((int *)_2)[2] = 9;
    _pu_58073 = MAKE_SEQ(_1);

    /** 		while s and find( SymTab[s][S_SCOPE], pu ) do*/
L2: 
    if (_s_58067 == 0) {
        goto L3; // [51] 148
    }
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _29510 = (int)*(((s1_ptr)_2)->base + _s_58067);
    _2 = (int)SEQ_PTR(_29510);
    _29511 = (int)*(((s1_ptr)_2)->base + 4);
    _29510 = NOVALUE;
    _29512 = find_from(_29511, _pu_58073, 1);
    _29511 = NOVALUE;
    if (_29512 == 0)
    {
        _29512 = NOVALUE;
        goto L3; // [73] 148
    }
    else{
        _29512 = NOVALUE;
    }

    /** 			if SymTab[s][S_SCOPE] = SC_PRIVATE and SymTab[s][S_INITLEVEL] = -1 then*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _29513 = (int)*(((s1_ptr)_2)->base + _s_58067);
    _2 = (int)SEQ_PTR(_29513);
    _29514 = (int)*(((s1_ptr)_2)->base + 4);
    _29513 = NOVALUE;
    if (IS_ATOM_INT(_29514)) {
        _29515 = (_29514 == 3);
    }
    else {
        _29515 = binary_op(EQUALS, _29514, 3);
    }
    _29514 = NOVALUE;
    if (IS_ATOM_INT(_29515)) {
        if (_29515 == 0) {
            goto L4; // [96] 127
        }
    }
    else {
        if (DBL_PTR(_29515)->dbl == 0.0) {
            goto L4; // [96] 127
        }
    }
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _29517 = (int)*(((s1_ptr)_2)->base + _s_58067);
    _2 = (int)SEQ_PTR(_29517);
    _29518 = (int)*(((s1_ptr)_2)->base + 14);
    _29517 = NOVALUE;
    if (IS_ATOM_INT(_29518)) {
        _29519 = (_29518 == -1);
    }
    else {
        _29519 = binary_op(EQUALS, _29518, -1);
    }
    _29518 = NOVALUE;
    if (_29519 == 0) {
        DeRef(_29519);
        _29519 = NOVALUE;
        goto L4; // [117] 127
    }
    else {
        if (!IS_ATOM_INT(_29519) && DBL_PTR(_29519)->dbl == 0.0){
            DeRef(_29519);
            _29519 = NOVALUE;
            goto L4; // [117] 127
        }
        DeRef(_29519);
        _29519 = NOVALUE;
    }
    DeRef(_29519);
    _29519 = NOVALUE;

    /** 				uninitialized &= s*/
    Append(&_uninitialized_58061, _uninitialized_58061, _s_58067);
L4: 

    /** 			s = SymTab[s][S_NEXT]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _29521 = (int)*(((s1_ptr)_2)->base + _s_58067);
    _2 = (int)SEQ_PTR(_29521);
    _s_58067 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_58067)){
        _s_58067 = (long)DBL_PTR(_s_58067)->dbl;
    }
    _29521 = NOVALUE;

    /** 		end while*/
    goto L2; // [145] 51
L3: 
L1: 
    DeRefi(_pu_58073);
    _pu_58073 = NOVALUE;

    /** 	return uninitialized*/
    DeRef(_29515);
    _29515 = NOVALUE;
    return _uninitialized_58061;
    ;
}


void _39While_statement()
{
    int _bp1_58104 = NOVALUE;
    int _bp2_58105 = NOVALUE;
    int _exit_base_58106 = NOVALUE;
    int _next_base_58107 = NOVALUE;
    int _uninitialized_58108 = NOVALUE;
    int _temps_58178 = NOVALUE;
    int _29557 = NOVALUE;
    int _29556 = NOVALUE;
    int _29555 = NOVALUE;
    int _29551 = NOVALUE;
    int _29550 = NOVALUE;
    int _29548 = NOVALUE;
    int _29546 = NOVALUE;
    int _29545 = NOVALUE;
    int _29544 = NOVALUE;
    int _29540 = NOVALUE;
    int _29538 = NOVALUE;
    int _29536 = NOVALUE;
    int _29530 = NOVALUE;
    int _29528 = NOVALUE;
    int _29527 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence uninitialized = get_private_uninitialized()*/
    _0 = _uninitialized_58108;
    _uninitialized_58108 = _39get_private_uninitialized();
    DeRef(_0);

    /** 	entry_stack = append( entry_stack, uninitialized )*/
    RefDS(_uninitialized_58108);
    Append(&_39entry_stack_54144, _39entry_stack_54144, _uninitialized_58108);

    /** 	Start_block( WHILE )*/
    _66Start_block(47, 0);

    /** 	exit_base = length(exit_list)*/
    if (IS_SEQUENCE(_39exit_list_54137)){
            _exit_base_58106 = SEQ_PTR(_39exit_list_54137)->length;
    }
    else {
        _exit_base_58106 = 1;
    }

    /** 	next_base = length(continue_list)*/
    if (IS_SEQUENCE(_39continue_list_54139)){
            _next_base_58107 = SEQ_PTR(_39continue_list_54139)->length;
    }
    else {
        _next_base_58107 = 1;
    }

    /** 	entry_addr &= length(Code)+1*/
    if (IS_SEQUENCE(_35Code_16332)){
            _29527 = SEQ_PTR(_35Code_16332)->length;
    }
    else {
        _29527 = 1;
    }
    _29528 = _29527 + 1;
    _29527 = NOVALUE;
    Append(&_39entry_addr_54141, _39entry_addr_54141, _29528);
    _29528 = NOVALUE;

    /** 	emit_op(NOP2) -- Entry_statement may patch this later*/
    _41emit_op(110);

    /** 	emit_addr(0)*/
    _41emit_addr(0);

    /** 	if TRANSLATE then*/
    if (_35TRANSLATE_15887 == 0)
    {
        goto L1; // [71] 82
    }
    else{
    }

    /** 		emit_op(NOPWHILE)*/
    _41emit_op(158);
L1: 

    /** 	bp1 = length(Code)+1*/
    if (IS_SEQUENCE(_35Code_16332)){
            _29530 = SEQ_PTR(_35Code_16332)->length;
    }
    else {
        _29530 = 1;
    }
    _bp1_58104 = _29530 + 1;
    _29530 = NOVALUE;

    /** 	continue_addr &= bp1*/
    Append(&_39continue_addr_54142, _39continue_addr_54142, _bp1_58104);

    /** 	short_circuit += 1*/
    _39short_circuit_54117 = _39short_circuit_54117 + 1;

    /** 	short_circuit_B = FALSE*/
    _39short_circuit_B_54119 = _13FALSE_434;

    /** 	SC1_type = 0*/
    _39SC1_type_54122 = 0;

    /** 	Expr()*/
    _39Expr();

    /** 	optimized_while = FALSE*/
    _41optimized_while_50224 = _13FALSE_434;

    /** 	emit_op(WHILE)*/
    _41emit_op(47);

    /** 	short_circuit -= 1*/
    _39short_circuit_54117 = _39short_circuit_54117 - 1;

    /** 	if not optimized_while then*/
    if (_41optimized_while_50224 != 0)
    goto L2; // [153] 174

    /** 		bp2 = length(Code)+1*/
    if (IS_SEQUENCE(_35Code_16332)){
            _29536 = SEQ_PTR(_35Code_16332)->length;
    }
    else {
        _29536 = 1;
    }
    _bp2_58105 = _29536 + 1;
    _29536 = NOVALUE;

    /** 		emit_forward_addr() -- will be patched*/
    _39emit_forward_addr();
    goto L3; // [171] 180
L2: 

    /** 		bp2 = 0*/
    _bp2_58105 = 0;
L3: 

    /** 	if finish_block_header(WHILE)=0 then*/
    _29538 = _39finish_block_header(47);
    if (binary_op_a(NOTEQ, _29538, 0)){
        DeRef(_29538);
        _29538 = NOVALUE;
        goto L4; // [188] 204
    }
    DeRef(_29538);
    _29538 = NOVALUE;

    /** 		entry_addr[$]=-1*/
    if (IS_SEQUENCE(_39entry_addr_54141)){
            _29540 = SEQ_PTR(_39entry_addr_54141)->length;
    }
    else {
        _29540 = 1;
    }
    _2 = (int)SEQ_PTR(_39entry_addr_54141);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _39entry_addr_54141 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _29540);
    *(int *)_2 = -1;
L4: 

    /** 	loop_stack &= WHILE*/
    Append(&_39loop_stack_54151, _39loop_stack_54151, 47);

    /** 	exit_base = length(exit_list)*/
    if (IS_SEQUENCE(_39exit_list_54137)){
            _exit_base_58106 = SEQ_PTR(_39exit_list_54137)->length;
    }
    else {
        _exit_base_58106 = 1;
    }

    /** 	if SC1_type = OR then*/
    if (_39SC1_type_54122 != 9)
    goto L5; // [227] 280

    /** 		backpatch(SC1_patch-3, SC1_OR_IF)*/
    _29544 = _39SC1_patch_54121 - 3;
    if ((long)((unsigned long)_29544 +(unsigned long) HIGH_BITS) >= 0){
        _29544 = NewDouble((double)_29544);
    }
    _41backpatch(_29544, 147);
    _29544 = NOVALUE;

    /** 		if TRANSLATE then*/
    if (_35TRANSLATE_15887 == 0)
    {
        goto L6; // [249] 260
    }
    else{
    }

    /** 			emit_op(NOP1)*/
    _41emit_op(159);
L6: 

    /** 		backpatch(SC1_patch, length(Code)+1)*/
    if (IS_SEQUENCE(_35Code_16332)){
            _29545 = SEQ_PTR(_35Code_16332)->length;
    }
    else {
        _29545 = 1;
    }
    _29546 = _29545 + 1;
    _29545 = NOVALUE;
    _41backpatch(_39SC1_patch_54121, _29546);
    _29546 = NOVALUE;
    goto L7; // [277] 331
L5: 

    /** 	elsif SC1_type = AND then*/
    if (_39SC1_type_54122 != 8)
    goto L8; // [286] 330

    /** 		backpatch(SC1_patch-3, SC1_AND_IF)*/
    _29548 = _39SC1_patch_54121 - 3;
    if ((long)((unsigned long)_29548 +(unsigned long) HIGH_BITS) >= 0){
        _29548 = NewDouble((double)_29548);
    }
    _41backpatch(_29548, 146);
    _29548 = NOVALUE;

    /** 		AppendXList(SC1_patch)*/

    /** 	exit_list = append(exit_list, addr)*/
    Append(&_39exit_list_54137, _39exit_list_54137, _39SC1_patch_54121);

    /** end procedure*/
    goto L9; // [318] 321
L9: 

    /** 		exit_delay &= 1*/
    Append(&_39exit_delay_54138, _39exit_delay_54138, 1);
L8: 
L7: 

    /** 	retry_addr &= length(Code)+1*/
    if (IS_SEQUENCE(_35Code_16332)){
            _29550 = SEQ_PTR(_35Code_16332)->length;
    }
    else {
        _29550 = 1;
    }
    _29551 = _29550 + 1;
    _29550 = NOVALUE;
    Append(&_39retry_addr_54143, _39retry_addr_54143, _29551);
    _29551 = NOVALUE;

    /** 	sequence temps = pop_temps()*/
    _0 = _temps_58178;
    _temps_58178 = _41pop_temps();
    DeRef(_0);

    /** 	push_temps( temps )*/
    RefDS(_temps_58178);
    _41push_temps(_temps_58178);

    /** 	Statement_list()*/
    _39Statement_list();

    /** 	PatchNList(next_base)*/
    _39PatchNList(_next_base_58107);

    /** 	tok_match(END)*/
    _39tok_match(402, 0);

    /** 	tok_match(WHILE, END)*/
    _39tok_match(47, 402);

    /** 	End_block( WHILE )*/
    _66End_block(47);

    /** 	StartSourceLine(TRUE)*/
    _41StartSourceLine(_13TRUE_436, 0, 2);

    /** 	emit_op(ENDWHILE)*/
    _41emit_op(22);

    /** 	emit_addr(bp1)*/
    _41emit_addr(_bp1_58104);

    /** 	if TRANSLATE then*/
    if (_35TRANSLATE_15887 == 0)
    {
        goto LA; // [419] 430
    }
    else{
    }

    /** 		emit_op(NOP1)*/
    _41emit_op(159);
LA: 

    /** 	if bp2 != 0 then*/
    if (_bp2_58105 == 0)
    goto LB; // [434] 454

    /** 		backpatch(bp2, length(Code)+1)*/
    if (IS_SEQUENCE(_35Code_16332)){
            _29555 = SEQ_PTR(_35Code_16332)->length;
    }
    else {
        _29555 = 1;
    }
    _29556 = _29555 + 1;
    _29555 = NOVALUE;
    _41backpatch(_bp2_58105, _29556);
    _29556 = NOVALUE;
LB: 

    /** 	exit_loop(exit_base)*/
    _39exit_loop(_exit_base_58106);

    /** 	entry_stack = remove( entry_stack, length( entry_stack ) )*/
    if (IS_SEQUENCE(_39entry_stack_54144)){
            _29557 = SEQ_PTR(_39entry_stack_54144)->length;
    }
    else {
        _29557 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_39entry_stack_54144);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_29557)) ? _29557 : (long)(DBL_PTR(_29557)->dbl);
        int stop = (IS_ATOM_INT(_29557)) ? _29557 : (long)(DBL_PTR(_29557)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_39entry_stack_54144), start, &_39entry_stack_54144 );
            }
            else Tail(SEQ_PTR(_39entry_stack_54144), stop+1, &_39entry_stack_54144);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_39entry_stack_54144), start, &_39entry_stack_54144);
        }
        else {
            assign_slice_seq = &assign_space;
            _39entry_stack_54144 = Remove_elements(start, stop, (SEQ_PTR(_39entry_stack_54144)->ref == 1));
        }
    }
    _29557 = NOVALUE;
    _29557 = NOVALUE;

    /** 	push_temps( temps )*/
    RefDS(_temps_58178);
    _41push_temps(_temps_58178);

    /** end procedure*/
    DeRef(_uninitialized_58108);
    DeRefDS(_temps_58178);
    return;
    ;
}


void _39Loop_statement()
{
    int _bp1_58208 = NOVALUE;
    int _exit_base_58209 = NOVALUE;
    int _next_base_58210 = NOVALUE;
    int _t_58212 = NOVALUE;
    int _uninitialized_58215 = NOVALUE;
    int _29581 = NOVALUE;
    int _29579 = NOVALUE;
    int _29578 = NOVALUE;
    int _29577 = NOVALUE;
    int _29571 = NOVALUE;
    int _29570 = NOVALUE;
    int _29568 = NOVALUE;
    int _29565 = NOVALUE;
    int _29564 = NOVALUE;
    int _29563 = NOVALUE;
    int _0, _1, _2;
    

    /** 	Start_block( LOOP )*/
    _66Start_block(422, 0);

    /** 	sequence uninitialized = get_private_uninitialized()*/
    _0 = _uninitialized_58215;
    _uninitialized_58215 = _39get_private_uninitialized();
    DeRef(_0);

    /** 	entry_stack = append( entry_stack, uninitialized )*/
    RefDS(_uninitialized_58215);
    Append(&_39entry_stack_54144, _39entry_stack_54144, _uninitialized_58215);

    /** 	exit_base = length(exit_list)*/
    if (IS_SEQUENCE(_39exit_list_54137)){
            _exit_base_58209 = SEQ_PTR(_39exit_list_54137)->length;
    }
    else {
        _exit_base_58209 = 1;
    }

    /** 	next_base = length(continue_list)*/
    if (IS_SEQUENCE(_39continue_list_54139)){
            _next_base_58210 = SEQ_PTR(_39continue_list_54139)->length;
    }
    else {
        _next_base_58210 = 1;
    }

    /** 	emit_op(NOP2) -- Entry_statement() may patch this*/
    _41emit_op(110);

    /** 	emit_addr(0)*/
    _41emit_addr(0);

    /** 	if finish_block_header(LOOP) then*/
    _29563 = _39finish_block_header(422);
    if (_29563 == 0) {
        DeRef(_29563);
        _29563 = NOVALUE;
        goto L1; // [58] 81
    }
    else {
        if (!IS_ATOM_INT(_29563) && DBL_PTR(_29563)->dbl == 0.0){
            DeRef(_29563);
            _29563 = NOVALUE;
            goto L1; // [58] 81
        }
        DeRef(_29563);
        _29563 = NOVALUE;
    }
    DeRef(_29563);
    _29563 = NOVALUE;

    /** 	    entry_addr &= length(Code)-1*/
    if (IS_SEQUENCE(_35Code_16332)){
            _29564 = SEQ_PTR(_35Code_16332)->length;
    }
    else {
        _29564 = 1;
    }
    _29565 = _29564 - 1;
    _29564 = NOVALUE;
    Append(&_39entry_addr_54141, _39entry_addr_54141, _29565);
    _29565 = NOVALUE;
    goto L2; // [78] 90
L1: 

    /** 		entry_addr &= -1*/
    Append(&_39entry_addr_54141, _39entry_addr_54141, -1);
L2: 

    /** 	if TRANSLATE then*/
    if (_35TRANSLATE_15887 == 0)
    {
        goto L3; // [94] 105
    }
    else{
    }

    /** 		emit_op(NOP1)*/
    _41emit_op(159);
L3: 

    /** 	bp1 = length(Code)+1*/
    if (IS_SEQUENCE(_35Code_16332)){
            _29568 = SEQ_PTR(_35Code_16332)->length;
    }
    else {
        _29568 = 1;
    }
    _bp1_58208 = _29568 + 1;
    _29568 = NOVALUE;

    /** 	retry_addr &= length(Code)+1*/
    if (IS_SEQUENCE(_35Code_16332)){
            _29570 = SEQ_PTR(_35Code_16332)->length;
    }
    else {
        _29570 = 1;
    }
    _29571 = _29570 + 1;
    _29570 = NOVALUE;
    Append(&_39retry_addr_54143, _39retry_addr_54143, _29571);
    _29571 = NOVALUE;

    /** 	continue_addr &= 0*/
    Append(&_39continue_addr_54142, _39continue_addr_54142, 0);

    /** 	loop_stack &= LOOP*/
    Append(&_39loop_stack_54151, _39loop_stack_54151, 422);

    /** 	Statement_list()*/
    _39Statement_list();

    /** 	End_block( LOOP )*/
    _66End_block(422);

    /** 	tok_match(UNTIL)*/
    _39tok_match(423, 0);

    /** 	if TRANSLATE then*/
    if (_35TRANSLATE_15887 == 0)
    {
        goto L4; // [174] 185
    }
    else{
    }

    /** 		emit_op(NOP1)*/
    _41emit_op(159);
L4: 

    /** 	PatchNList(next_base)*/
    _39PatchNList(_next_base_58210);

    /** 	StartSourceLine(TRUE)*/
    _41StartSourceLine(_13TRUE_436, 0, 2);

    /** 	short_circuit += 1*/
    _39short_circuit_54117 = _39short_circuit_54117 + 1;

    /** 	short_circuit_B = FALSE*/
    _39short_circuit_B_54119 = _13FALSE_434;

    /** 	SC1_type = 0*/
    _39SC1_type_54122 = 0;

    /** 	Expr()*/
    _39Expr();

    /** 	if SC1_type = OR then*/
    if (_39SC1_type_54122 != 9)
    goto L5; // [229] 282

    /** 		backpatch(SC1_patch-3, SC1_OR_IF)*/
    _29577 = _39SC1_patch_54121 - 3;
    if ((long)((unsigned long)_29577 +(unsigned long) HIGH_BITS) >= 0){
        _29577 = NewDouble((double)_29577);
    }
    _41backpatch(_29577, 147);
    _29577 = NOVALUE;

    /** 		if TRANSLATE then*/
    if (_35TRANSLATE_15887 == 0)
    {
        goto L6; // [251] 262
    }
    else{
    }

    /** 		    emit_op(NOP1)  -- to get label here*/
    _41emit_op(159);
L6: 

    /** 		backpatch(SC1_patch, length(Code)+1)*/
    if (IS_SEQUENCE(_35Code_16332)){
            _29578 = SEQ_PTR(_35Code_16332)->length;
    }
    else {
        _29578 = 1;
    }
    _29579 = _29578 + 1;
    _29578 = NOVALUE;
    _41backpatch(_39SC1_patch_54121, _29579);
    _29579 = NOVALUE;
    goto L7; // [279] 308
L5: 

    /** 	elsif SC1_type = AND then*/
    if (_39SC1_type_54122 != 8)
    goto L8; // [288] 307

    /** 		backpatch(SC1_patch-3, SC1_AND_IF)*/
    _29581 = _39SC1_patch_54121 - 3;
    if ((long)((unsigned long)_29581 +(unsigned long) HIGH_BITS) >= 0){
        _29581 = NewDouble((double)_29581);
    }
    _41backpatch(_29581, 146);
    _29581 = NOVALUE;
L8: 
L7: 

    /** 	short_circuit -= 1*/
    _39short_circuit_54117 = _39short_circuit_54117 - 1;

    /** 	emit_op(IF)*/
    _41emit_op(20);

    /** 	emit_addr(bp1)*/
    _41emit_addr(_bp1_58208);

    /** 	if TRANSLATE then*/
    if (_35TRANSLATE_15887 == 0)
    {
        goto L9; // [332] 343
    }
    else{
    }

    /** 		emit_op(NOP1)*/
    _41emit_op(159);
L9: 

    /** 	exit_loop(exit_base)*/
    _39exit_loop(_exit_base_58209);

    /** 	tok_match(END)*/
    _39tok_match(402, 0);

    /** 	tok_match(LOOP, END)*/
    _39tok_match(422, 402);

    /** end procedure*/
    DeRef(_uninitialized_58215);
    return;
    ;
}


void _39Ifdef_statement()
{
    int _option_58294 = NOVALUE;
    int _matched_58295 = NOVALUE;
    int _has_matched_58296 = NOVALUE;
    int _in_matched_58297 = NOVALUE;
    int _dead_ifdef_58298 = NOVALUE;
    int _in_elsedef_58299 = NOVALUE;
    int _tok_58301 = NOVALUE;
    int _keyw_58302 = NOVALUE;
    int _parser_id_58306 = NOVALUE;
    int _negate_58322 = NOVALUE;
    int _conjunction_58323 = NOVALUE;
    int _at_start_58324 = NOVALUE;
    int _prev_conj_58325 = NOVALUE;
    int _this_matched_58398 = NOVALUE;
    int _gotword_58414 = NOVALUE;
    int _gotthen_58415 = NOVALUE;
    int _if_lvl_58416 = NOVALUE;
    int _29698 = NOVALUE;
    int _29697 = NOVALUE;
    int _29693 = NOVALUE;
    int _29691 = NOVALUE;
    int _29688 = NOVALUE;
    int _29686 = NOVALUE;
    int _29685 = NOVALUE;
    int _29681 = NOVALUE;
    int _29678 = NOVALUE;
    int _29675 = NOVALUE;
    int _29671 = NOVALUE;
    int _29669 = NOVALUE;
    int _29668 = NOVALUE;
    int _29667 = NOVALUE;
    int _29666 = NOVALUE;
    int _29665 = NOVALUE;
    int _29664 = NOVALUE;
    int _29663 = NOVALUE;
    int _29659 = NOVALUE;
    int _29656 = NOVALUE;
    int _29655 = NOVALUE;
    int _29654 = NOVALUE;
    int _29650 = NOVALUE;
    int _29649 = NOVALUE;
    int _29648 = NOVALUE;
    int _29645 = NOVALUE;
    int _29642 = NOVALUE;
    int _29641 = NOVALUE;
    int _29640 = NOVALUE;
    int _29638 = NOVALUE;
    int _29627 = NOVALUE;
    int _29625 = NOVALUE;
    int _29624 = NOVALUE;
    int _29623 = NOVALUE;
    int _29622 = NOVALUE;
    int _29621 = NOVALUE;
    int _29620 = NOVALUE;
    int _29619 = NOVALUE;
    int _29616 = NOVALUE;
    int _29615 = NOVALUE;
    int _29613 = NOVALUE;
    int _29611 = NOVALUE;
    int _29610 = NOVALUE;
    int _29608 = NOVALUE;
    int _29606 = NOVALUE;
    int _29605 = NOVALUE;
    int _29603 = NOVALUE;
    int _29602 = NOVALUE;
    int _29601 = NOVALUE;
    int _29598 = NOVALUE;
    int _29596 = NOVALUE;
    int _29593 = NOVALUE;
    int _29592 = NOVALUE;
    int _29591 = NOVALUE;
    int _29589 = NOVALUE;
    int _29587 = NOVALUE;
    int _29586 = NOVALUE;
    int _29585 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer matched = 0, has_matched = 0,  in_matched = 0, dead_ifdef = 0, in_elsedef = 0*/
    _matched_58295 = 0;
    _has_matched_58296 = 0;
    _in_matched_58297 = 0;
    _dead_ifdef_58298 = 0;
    _in_elsedef_58299 = 0;

    /** 	sequence keyw ="ifdef"*/
    RefDS(_26344);
    DeRefi(_keyw_58302);
    _keyw_58302 = _26344;

    /** 	live_ifdef += 1*/
    _39live_ifdef_58290 = _39live_ifdef_58290 + 1;

    /** 	ifdef_lineno &= line_number*/
    Append(&_39ifdef_lineno_58291, _39ifdef_lineno_58291, _35line_number_16245);

    /** 	integer parser_id*/

    /** 	if CurrentSub != TopLevelSub or length(if_labels) or length(loop_labels) then*/
    _29585 = (_35CurrentSub_16252 != _35TopLevelSub_16251);
    if (_29585 != 0) {
        _29586 = 1;
        goto L1; // [55] 68
    }
    if (IS_SEQUENCE(_39if_labels_54146)){
            _29587 = SEQ_PTR(_39if_labels_54146)->length;
    }
    else {
        _29587 = 1;
    }
    _29586 = (_29587 != 0);
L1: 
    if (_29586 != 0) {
        goto L2; // [68] 82
    }
    if (IS_SEQUENCE(_39loop_labels_54145)){
            _29589 = SEQ_PTR(_39loop_labels_54145)->length;
    }
    else {
        _29589 = 1;
    }
    if (_29589 == 0)
    {
        _29589 = NOVALUE;
        goto L3; // [78] 92
    }
    else{
        _29589 = NOVALUE;
    }
L2: 

    /** 		parser_id = forward_Statement_list*/
    _parser_id_58306 = _39forward_Statement_list_57142;
    goto L4; // [89] 100
L3: 

    /** 		parser_id = top_level_parser*/
    _parser_id_58306 = _39top_level_parser_58289;
L4: 

    /** 	while 1 label "top" do*/
L5: 

    /** 		if matched = 0 and in_elsedef = 0 then*/
    _29591 = (_matched_58295 == 0);
    if (_29591 == 0) {
        goto L6; // [111] 632
    }
    _29593 = (_in_elsedef_58299 == 0);
    if (_29593 == 0)
    {
        DeRef(_29593);
        _29593 = NOVALUE;
        goto L6; // [120] 632
    }
    else{
        DeRef(_29593);
        _29593 = NOVALUE;
    }

    /** 			integer negate = 0, conjunction = 0*/
    _negate_58322 = 0;
    _conjunction_58323 = 0;

    /** 			integer at_start = 1*/
    _at_start_58324 = 1;

    /** 			sequence prev_conj = ""*/
    RefDS(_22023);
    DeRef(_prev_conj_58325);
    _prev_conj_58325 = _22023;

    /** 			while 1 label "deflist" do*/
L7: 

    /** 				option = StringToken()*/
    RefDS(_5);
    _0 = _option_58294;
    _option_58294 = _61StringToken(_5);
    DeRef(_0);

    /** 				if equal(option, "then") then*/
    if (_option_58294 == _26411)
    _29596 = 1;
    else if (IS_ATOM_INT(_option_58294) && IS_ATOM_INT(_26411))
    _29596 = 0;
    else
    _29596 = (compare(_option_58294, _26411) == 0);
    if (_29596 == 0)
    {
        _29596 = NOVALUE;
        goto L8; // [162] 234
    }
    else{
        _29596 = NOVALUE;
    }

    /** 					if at_start = 1 then*/
    if (_at_start_58324 != 1)
    goto L9; // [167] 185

    /** 						CompileErr(6, {keyw})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_keyw_58302);
    *((int *)(_2+4)) = _keyw_58302;
    _29598 = MAKE_SEQ(_1);
    _44CompileErr(6, _29598, 0);
    _29598 = NOVALUE;
    goto LA; // [182] 518
L9: 

    /** 					elsif conjunction = 0 then*/
    if (_conjunction_58323 != 0)
    goto LB; // [187] 219

    /** 						if negate = 0 then*/
    if (_negate_58322 != 0)
    goto LC; // [193] 204

    /** 							exit "deflist"*/
    goto LD; // [199] 606
    goto LA; // [201] 518
LC: 

    /** 							CompileErr(11, {keyw})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_keyw_58302);
    *((int *)(_2+4)) = _keyw_58302;
    _29601 = MAKE_SEQ(_1);
    _44CompileErr(11, _29601, 0);
    _29601 = NOVALUE;
    goto LA; // [216] 518
LB: 

    /** 						CompileErr(8, {keyw, prev_conj})*/
    RefDS(_prev_conj_58325);
    RefDS(_keyw_58302);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _keyw_58302;
    ((int *)_2)[2] = _prev_conj_58325;
    _29602 = MAKE_SEQ(_1);
    _44CompileErr(8, _29602, 0);
    _29602 = NOVALUE;
    goto LA; // [231] 518
L8: 

    /** 				elsif equal(option, "not") then*/
    if (_option_58294 == _26372)
    _29603 = 1;
    else if (IS_ATOM_INT(_option_58294) && IS_ATOM_INT(_26372))
    _29603 = 0;
    else
    _29603 = (compare(_option_58294, _26372) == 0);
    if (_29603 == 0)
    {
        _29603 = NOVALUE;
        goto LE; // [240] 276
    }
    else{
        _29603 = NOVALUE;
    }

    /** 					if negate = 0 then*/
    if (_negate_58322 != 0)
    goto LF; // [245] 261

    /** 						negate = 1*/
    _negate_58322 = 1;

    /** 						continue "deflist"*/
    goto L7; // [256] 148
    goto LA; // [258] 518
LF: 

    /** 						CompileErr(7, {keyw})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_keyw_58302);
    *((int *)(_2+4)) = _keyw_58302;
    _29605 = MAKE_SEQ(_1);
    _44CompileErr(7, _29605, 0);
    _29605 = NOVALUE;
    goto LA; // [273] 518
LE: 

    /** 				elsif equal(option, "and") then*/
    if (_option_58294 == _26276)
    _29606 = 1;
    else if (IS_ATOM_INT(_option_58294) && IS_ATOM_INT(_26276))
    _29606 = 0;
    else
    _29606 = (compare(_option_58294, _26276) == 0);
    if (_29606 == 0)
    {
        _29606 = NOVALUE;
        goto L10; // [282] 345
    }
    else{
        _29606 = NOVALUE;
    }

    /** 					if at_start = 1 then*/
    if (_at_start_58324 != 1)
    goto L11; // [287] 305

    /** 						CompileErr(2, {keyw})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_keyw_58302);
    *((int *)(_2+4)) = _keyw_58302;
    _29608 = MAKE_SEQ(_1);
    _44CompileErr(2, _29608, 0);
    _29608 = NOVALUE;
    goto LA; // [302] 518
L11: 

    /** 					elsif conjunction = 0 then*/
    if (_conjunction_58323 != 0)
    goto L12; // [307] 330

    /** 						conjunction = 1*/
    _conjunction_58323 = 1;

    /** 						prev_conj = option*/
    RefDS(_option_58294);
    DeRef(_prev_conj_58325);
    _prev_conj_58325 = _option_58294;

    /** 						continue "deflist"*/
    goto L7; // [325] 148
    goto LA; // [327] 518
L12: 

    /** 						CompileErr(10,{keyw,prev_conj})*/
    RefDS(_prev_conj_58325);
    RefDS(_keyw_58302);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _keyw_58302;
    ((int *)_2)[2] = _prev_conj_58325;
    _29610 = MAKE_SEQ(_1);
    _44CompileErr(10, _29610, 0);
    _29610 = NOVALUE;
    goto LA; // [342] 518
L10: 

    /** 				elsif equal(option, "or") then*/
    if (_option_58294 == _26376)
    _29611 = 1;
    else if (IS_ATOM_INT(_option_58294) && IS_ATOM_INT(_26376))
    _29611 = 0;
    else
    _29611 = (compare(_option_58294, _26376) == 0);
    if (_29611 == 0)
    {
        _29611 = NOVALUE;
        goto L13; // [351] 414
    }
    else{
        _29611 = NOVALUE;
    }

    /** 					if at_start = 1 then*/
    if (_at_start_58324 != 1)
    goto L14; // [356] 374

    /** 						CompileErr(6, {keyw})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_keyw_58302);
    *((int *)(_2+4)) = _keyw_58302;
    _29613 = MAKE_SEQ(_1);
    _44CompileErr(6, _29613, 0);
    _29613 = NOVALUE;
    goto LA; // [371] 518
L14: 

    /** 					elsif conjunction = 0 then*/
    if (_conjunction_58323 != 0)
    goto L15; // [376] 399

    /** 						conjunction = 2*/
    _conjunction_58323 = 2;

    /** 						prev_conj = option*/
    RefDS(_option_58294);
    DeRef(_prev_conj_58325);
    _prev_conj_58325 = _option_58294;

    /** 						continue "deflist"*/
    goto L7; // [394] 148
    goto LA; // [396] 518
L15: 

    /** 						CompileErr(9, {keyw, prev_conj})*/
    RefDS(_prev_conj_58325);
    RefDS(_keyw_58302);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _keyw_58302;
    ((int *)_2)[2] = _prev_conj_58325;
    _29615 = MAKE_SEQ(_1);
    _44CompileErr(9, _29615, 0);
    _29615 = NOVALUE;
    goto LA; // [411] 518
L13: 

    /** 				elsif length(option) = 0 then*/
    if (IS_SEQUENCE(_option_58294)){
            _29616 = SEQ_PTR(_option_58294)->length;
    }
    else {
        _29616 = 1;
    }
    if (_29616 != 0)
    goto L16; // [419] 454

    /** 					if at_start = 1 then*/
    if (_at_start_58324 != 1)
    goto L17; // [425] 443

    /** 						CompileErr(122, {keyw})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_keyw_58302);
    *((int *)(_2+4)) = _keyw_58302;
    _29619 = MAKE_SEQ(_1);
    _44CompileErr(122, _29619, 0);
    _29619 = NOVALUE;
    goto LA; // [440] 518
L17: 

    /** 						CompileErr(82)*/
    RefDS(_22023);
    _44CompileErr(82, _22023, 0);
    goto LA; // [451] 518
L16: 

    /** 				elsif not at_start and length(prev_conj) = 0 then*/
    _29620 = (_at_start_58324 == 0);
    if (_29620 == 0) {
        goto L18; // [459] 488
    }
    if (IS_SEQUENCE(_prev_conj_58325)){
            _29622 = SEQ_PTR(_prev_conj_58325)->length;
    }
    else {
        _29622 = 1;
    }
    _29623 = (_29622 == 0);
    _29622 = NOVALUE;
    if (_29623 == 0)
    {
        DeRef(_29623);
        _29623 = NOVALUE;
        goto L18; // [471] 488
    }
    else{
        DeRef(_29623);
        _29623 = NOVALUE;
    }

    /** 					CompileErr(4, {keyw})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_keyw_58302);
    *((int *)(_2+4)) = _keyw_58302;
    _29624 = MAKE_SEQ(_1);
    _44CompileErr(4, _29624, 0);
    _29624 = NOVALUE;
    goto LA; // [485] 518
L18: 

    /** 				elsif t_identifier(option) = 0 then*/
    RefDS(_option_58294);
    _29625 = _13t_identifier(_option_58294);
    if (binary_op_a(NOTEQ, _29625, 0)){
        DeRef(_29625);
        _29625 = NOVALUE;
        goto L19; // [494] 512
    }
    DeRef(_29625);
    _29625 = NOVALUE;

    /** 					CompileErr(3, {keyw})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_keyw_58302);
    *((int *)(_2+4)) = _keyw_58302;
    _29627 = MAKE_SEQ(_1);
    _44CompileErr(3, _29627, 0);
    _29627 = NOVALUE;
    goto LA; // [509] 518
L19: 

    /** 					at_start = 0*/
    _at_start_58324 = 0;
LA: 

    /** 				integer this_matched = find(option, OpDefines)*/
    _this_matched_58398 = find_from(_option_58294, _35OpDefines_16317, 1);

    /** 				if negate then*/
    if (_negate_58322 == 0)
    {
        goto L1A; // [529] 543
    }
    else{
    }

    /** 					this_matched = not this_matched*/
    _this_matched_58398 = (_this_matched_58398 == 0);

    /** 					negate = 0*/
    _negate_58322 = 0;
L1A: 

    /** 				if conjunction = 0 then*/
    if (_conjunction_58323 != 0)
    goto L1B; // [545] 557

    /** 					matched = this_matched*/
    _matched_58295 = _this_matched_58398;
    goto L1C; // [554] 599
L1B: 

    /** 					if conjunction = 1 then*/
    if (_conjunction_58323 != 1)
    goto L1D; // [559] 572

    /** 						matched = matched and this_matched*/
    _matched_58295 = (_matched_58295 != 0 && _this_matched_58398 != 0);
    goto L1E; // [569] 586
L1D: 

    /** 					elsif conjunction = 2 then*/
    if (_conjunction_58323 != 2)
    goto L1F; // [574] 585

    /** 						matched = matched or this_matched*/
    _matched_58295 = (_matched_58295 != 0 || _this_matched_58398 != 0);
L1F: 
L1E: 

    /** 					conjunction = 0*/
    _conjunction_58323 = 0;

    /** 					prev_conj = ""*/
    RefDS(_22023);
    DeRef(_prev_conj_58325);
    _prev_conj_58325 = _22023;
L1C: 

    /** 			end while*/
    goto L7; // [603] 148
LD: 

    /** 			in_matched = matched*/
    _in_matched_58297 = _matched_58295;

    /** 			if matched then*/
    if (_matched_58295 == 0)
    {
        goto L20; // [613] 631
    }
    else{
    }

    /** 				No_new_entry = 0*/
    _53No_new_entry_47263 = 0;

    /** 				call_proc(parser_id, {})*/
    _0 = (int)_00[_parser_id_58306].addr;
    (*(int (*)())_0)(
                         );
L20: 
L6: 
    DeRef(_prev_conj_58325);
    _prev_conj_58325 = NOVALUE;

    /** 		integer gotword = 0*/
    _gotword_58414 = 0;

    /** 		integer gotthen = 0*/
    _gotthen_58415 = 0;

    /** 		integer if_lvl  = 0*/
    _if_lvl_58416 = 0;

    /** 		No_new_entry = not matched*/
    _53No_new_entry_47263 = (_matched_58295 == 0);

    /** 		has_matched = has_matched or matched*/
    _has_matched_58296 = (_has_matched_58296 != 0 || _matched_58295 != 0);

    /** 		keyw = "elsifdef"*/
    RefDS(_26312);
    DeRefi(_keyw_58302);
    _keyw_58302 = _26312;

    /** 		while 1 do*/
L21: 

    /** 			tok = next_token()*/
    _0 = _tok_58301;
    _tok_58301 = _39next_token();
    DeRef(_0);

    /** 			if tok[T_ID] = END_OF_FILE then*/
    _2 = (int)SEQ_PTR(_tok_58301);
    _29638 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29638, -21)){
        _29638 = NOVALUE;
        goto L22; // [689] 712
    }
    _29638 = NOVALUE;

    /** 				CompileErr(65, ifdef_lineno[$])*/
    if (IS_SEQUENCE(_39ifdef_lineno_58291)){
            _29640 = SEQ_PTR(_39ifdef_lineno_58291)->length;
    }
    else {
        _29640 = 1;
    }
    _2 = (int)SEQ_PTR(_39ifdef_lineno_58291);
    _29641 = (int)*(((s1_ptr)_2)->base + _29640);
    _44CompileErr(65, _29641, 0);
    _29641 = NOVALUE;
    goto L21; // [709] 674
L22: 

    /** 			elsif tok[T_ID] = END then*/
    _2 = (int)SEQ_PTR(_tok_58301);
    _29642 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29642, 402)){
        _29642 = NOVALUE;
        goto L23; // [722] 844
    }
    _29642 = NOVALUE;

    /** 				tok = next_token()*/
    _0 = _tok_58301;
    _tok_58301 = _39next_token();
    DeRef(_0);

    /** 				if tok[T_ID] = IFDEF then*/
    _2 = (int)SEQ_PTR(_tok_58301);
    _29645 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29645, 407)){
        _29645 = NOVALUE;
        goto L24; // [741] 769
    }
    _29645 = NOVALUE;

    /** 					if dead_ifdef then*/
    if (_dead_ifdef_58298 == 0)
    {
        goto L25; // [747] 759
    }
    else{
    }

    /** 						dead_ifdef -= 1*/
    _dead_ifdef_58298 = _dead_ifdef_58298 - 1;
    goto L21; // [756] 674
L25: 

    /** 						exit "top"*/
    goto L26; // [763] 1312
    goto L21; // [766] 674
L24: 

    /** 				elsif in_matched then*/
    if (_in_matched_58297 == 0)
    {
        goto L27; // [771] 793
    }
    else{
    }

    /** 					CompileErr(75, ifdef_lineno[$])*/
    if (IS_SEQUENCE(_39ifdef_lineno_58291)){
            _29648 = SEQ_PTR(_39ifdef_lineno_58291)->length;
    }
    else {
        _29648 = 1;
    }
    _2 = (int)SEQ_PTR(_39ifdef_lineno_58291);
    _29649 = (int)*(((s1_ptr)_2)->base + _29648);
    _44CompileErr(75, _29649, 0);
    _29649 = NOVALUE;
    goto L21; // [790] 674
L27: 

    /** 					if tok[T_ID] = IF then*/
    _2 = (int)SEQ_PTR(_tok_58301);
    _29650 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29650, 20)){
        _29650 = NOVALUE;
        goto L21; // [803] 674
    }
    _29650 = NOVALUE;

    /** 						if if_lvl > 0 then*/
    if (_if_lvl_58416 <= 0)
    goto L28; // [809] 822

    /** 							if_lvl -= 1*/
    _if_lvl_58416 = _if_lvl_58416 - 1;
    goto L21; // [819] 674
L28: 

    /** 							CompileErr(111, ifdef_lineno[$])*/
    if (IS_SEQUENCE(_39ifdef_lineno_58291)){
            _29654 = SEQ_PTR(_39ifdef_lineno_58291)->length;
    }
    else {
        _29654 = 1;
    }
    _2 = (int)SEQ_PTR(_39ifdef_lineno_58291);
    _29655 = (int)*(((s1_ptr)_2)->base + _29654);
    _44CompileErr(111, _29655, 0);
    _29655 = NOVALUE;
    goto L21; // [841] 674
L23: 

    /** 			elsif tok[T_ID] = IF then*/
    _2 = (int)SEQ_PTR(_tok_58301);
    _29656 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29656, 20)){
        _29656 = NOVALUE;
        goto L29; // [854] 867
    }
    _29656 = NOVALUE;

    /** 				if_lvl += 1*/
    _if_lvl_58416 = _if_lvl_58416 + 1;
    goto L21; // [864] 674
L29: 

    /** 			elsif tok[T_ID] = ELSE then*/
    _2 = (int)SEQ_PTR(_tok_58301);
    _29659 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29659, 23)){
        _29659 = NOVALUE;
        goto L2A; // [877] 913
    }
    _29659 = NOVALUE;

    /** 				if not in_matched then*/
    if (_in_matched_58297 != 0)
    goto L21; // [883] 674

    /** 					if if_lvl = 0 then*/
    if (_if_lvl_58416 != 0)
    goto L21; // [888] 674

    /** 						CompileErr(108, ifdef_lineno[$])*/
    if (IS_SEQUENCE(_39ifdef_lineno_58291)){
            _29663 = SEQ_PTR(_39ifdef_lineno_58291)->length;
    }
    else {
        _29663 = 1;
    }
    _2 = (int)SEQ_PTR(_39ifdef_lineno_58291);
    _29664 = (int)*(((s1_ptr)_2)->base + _29663);
    _44CompileErr(108, _29664, 0);
    _29664 = NOVALUE;
    goto L21; // [910] 674
L2A: 

    /** 			elsif tok[T_ID] = ELSIFDEF and not dead_ifdef then*/
    _2 = (int)SEQ_PTR(_tok_58301);
    _29665 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_29665)) {
        _29666 = (_29665 == 408);
    }
    else {
        _29666 = binary_op(EQUALS, _29665, 408);
    }
    _29665 = NOVALUE;
    if (IS_ATOM_INT(_29666)) {
        if (_29666 == 0) {
            goto L2B; // [927] 1065
        }
    }
    else {
        if (DBL_PTR(_29666)->dbl == 0.0) {
            goto L2B; // [927] 1065
        }
    }
    _29668 = (_dead_ifdef_58298 == 0);
    if (_29668 == 0)
    {
        DeRef(_29668);
        _29668 = NOVALUE;
        goto L2B; // [935] 1065
    }
    else{
        DeRef(_29668);
        _29668 = NOVALUE;
    }

    /** 				if has_matched then*/
    if (_has_matched_58296 == 0)
    {
        goto L2C; // [940] 1305
    }
    else{
    }

    /** 					in_matched = 0*/
    _in_matched_58297 = 0;

    /** 					No_new_entry = 1*/
    _53No_new_entry_47263 = 1;

    /** 					gotword = 0*/
    _gotword_58414 = 0;

    /** 					gotthen = 0*/
    _gotthen_58415 = 0;

    /** 					while length(option) > 0 with entry do*/
    goto L2D; // [967] 1009
L2E: 
    if (IS_SEQUENCE(_option_58294)){
            _29669 = SEQ_PTR(_option_58294)->length;
    }
    else {
        _29669 = 1;
    }
    if (_29669 <= 0)
    goto L2F; // [975] 1022

    /** 						if equal(option, "then") then*/
    if (_option_58294 == _26411)
    _29671 = 1;
    else if (IS_ATOM_INT(_option_58294) && IS_ATOM_INT(_26411))
    _29671 = 0;
    else
    _29671 = (compare(_option_58294, _26411) == 0);
    if (_29671 == 0)
    {
        _29671 = NOVALUE;
        goto L30; // [985] 1000
    }
    else{
        _29671 = NOVALUE;
    }

    /** 							gotthen = 1*/
    _gotthen_58415 = 1;

    /** 							exit*/
    goto L2F; // [995] 1022
    goto L31; // [997] 1006
L30: 

    /** 							gotword = 1*/
    _gotword_58414 = 1;
L31: 

    /** 					entry*/
L2D: 

    /** 						option = StringToken()*/
    RefDS(_5);
    _0 = _option_58294;
    _option_58294 = _61StringToken(_5);
    DeRef(_0);

    /** 					end while*/
    goto L2E; // [1019] 970
L2F: 

    /** 					if gotword = 0 then*/
    if (_gotword_58414 != 0)
    goto L32; // [1024] 1036

    /** 						CompileErr(78)*/
    RefDS(_22023);
    _44CompileErr(78, _22023, 0);
L32: 

    /** 					if gotthen = 0 then*/
    if (_gotthen_58415 != 0)
    goto L33; // [1038] 1050

    /** 						CompileErr(77)*/
    RefDS(_22023);
    _44CompileErr(77, _22023, 0);
L33: 

    /** 					read_line()*/
    _61read_line();
    goto L21; // [1054] 674

    /** 					exit*/
    goto L2C; // [1059] 1305
    goto L21; // [1062] 674
L2B: 

    /** 			elsif tok[T_ID] = ELSEDEF then*/
    _2 = (int)SEQ_PTR(_tok_58301);
    _29675 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29675, 409)){
        _29675 = NOVALUE;
        goto L34; // [1075] 1235
    }
    _29675 = NOVALUE;

    /** 				gotword = line_number*/
    _gotword_58414 = _35line_number_16245;

    /** 				option = StringToken()*/
    RefDS(_5);
    _0 = _option_58294;
    _option_58294 = _61StringToken(_5);
    DeRef(_0);

    /** 				if length(option) > 0 then*/
    if (IS_SEQUENCE(_option_58294)){
            _29678 = SEQ_PTR(_option_58294)->length;
    }
    else {
        _29678 = 1;
    }
    if (_29678 <= 0)
    goto L35; // [1101] 1135

    /** 					if line_number = gotword then*/
    if (_35line_number_16245 != _gotword_58414)
    goto L36; // [1109] 1121

    /** 						CompileErr(116)*/
    RefDS(_22023);
    _44CompileErr(116, _22023, 0);
L36: 

    /** 					bp -= length(option)*/
    if (IS_SEQUENCE(_option_58294)){
            _29681 = SEQ_PTR(_option_58294)->length;
    }
    else {
        _29681 = 1;
    }
    _44bp_48522 = _44bp_48522 - _29681;
    _29681 = NOVALUE;
L35: 

    /** 				if not dead_ifdef then*/
    if (_dead_ifdef_58298 != 0)
    goto L21; // [1137] 674

    /** 					if has_matched then*/
    if (_has_matched_58296 == 0)
    {
        goto L37; // [1142] 1164
    }
    else{
    }

    /** 						in_matched = 0*/
    _in_matched_58297 = 0;

    /** 						No_new_entry = 1*/
    _53No_new_entry_47263 = 1;

    /** 						read_line()*/
    _61read_line();
    goto L21; // [1161] 674
L37: 

    /** 						No_new_entry = 0*/
    _53No_new_entry_47263 = 0;

    /** 						in_elsedef = 1*/
    _in_elsedef_58299 = 1;

    /** 						call_proc(parser_id, {})*/
    _0 = (int)_00[_parser_id_58306].addr;
    (*(int (*)())_0)(
                         );

    /** 						tok_match(END)*/
    _39tok_match(402, 0);

    /** 						tok_match(IFDEF, END)*/
    _39tok_match(407, 402);

    /** 						live_ifdef -= 1*/
    _39live_ifdef_58290 = _39live_ifdef_58290 - 1;

    /** 						ifdef_lineno = ifdef_lineno[1..$-1]*/
    if (IS_SEQUENCE(_39ifdef_lineno_58291)){
            _29685 = SEQ_PTR(_39ifdef_lineno_58291)->length;
    }
    else {
        _29685 = 1;
    }
    _29686 = _29685 - 1;
    _29685 = NOVALUE;
    rhs_slice_target = (object_ptr)&_39ifdef_lineno_58291;
    RHS_Slice(_39ifdef_lineno_58291, 1, _29686);

    /** 						return*/
    DeRef(_option_58294);
    DeRef(_tok_58301);
    DeRefi(_keyw_58302);
    DeRef(_29585);
    _29585 = NOVALUE;
    DeRef(_29591);
    _29591 = NOVALUE;
    DeRef(_29620);
    _29620 = NOVALUE;
    _29686 = NOVALUE;
    DeRef(_29666);
    _29666 = NOVALUE;
    return;
    goto L21; // [1232] 674
L34: 

    /** 			elsif tok[T_ID] = IFDEF then*/
    _2 = (int)SEQ_PTR(_tok_58301);
    _29688 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29688, 407)){
        _29688 = NOVALUE;
        goto L38; // [1245] 1258
    }
    _29688 = NOVALUE;

    /** 				dead_ifdef += 1*/
    _dead_ifdef_58298 = _dead_ifdef_58298 + 1;
    goto L21; // [1255] 674
L38: 

    /** 			elsif tok[T_ID] = INCLUDE then*/
    _2 = (int)SEQ_PTR(_tok_58301);
    _29691 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29691, 418)){
        _29691 = NOVALUE;
        goto L39; // [1268] 1279
    }
    _29691 = NOVALUE;

    /** 				read_line()*/
    _61read_line();
    goto L21; // [1276] 674
L39: 

    /** 			elsif tok[T_ID] = CASE then*/
    _2 = (int)SEQ_PTR(_tok_58301);
    _29693 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29693, 186)){
        _29693 = NOVALUE;
        goto L21; // [1289] 674
    }
    _29693 = NOVALUE;

    /** 				tok = next_token()*/
    _0 = _tok_58301;
    _tok_58301 = _39next_token();
    DeRef(_0);

    /** 		end while*/
    goto L21; // [1302] 674
L2C: 

    /** 	end while*/
    goto L5; // [1309] 105
L26: 

    /** 	live_ifdef -= 1*/
    _39live_ifdef_58290 = _39live_ifdef_58290 - 1;

    /** 	ifdef_lineno = ifdef_lineno[1..$-1]*/
    if (IS_SEQUENCE(_39ifdef_lineno_58291)){
            _29697 = SEQ_PTR(_39ifdef_lineno_58291)->length;
    }
    else {
        _29697 = 1;
    }
    _29698 = _29697 - 1;
    _29697 = NOVALUE;
    rhs_slice_target = (object_ptr)&_39ifdef_lineno_58291;
    RHS_Slice(_39ifdef_lineno_58291, 1, _29698);

    /** 	No_new_entry = 0*/
    _53No_new_entry_47263 = 0;

    /** end procedure*/
    DeRef(_option_58294);
    DeRef(_tok_58301);
    DeRefi(_keyw_58302);
    DeRef(_29585);
    _29585 = NOVALUE;
    DeRef(_29591);
    _29591 = NOVALUE;
    DeRef(_29620);
    _29620 = NOVALUE;
    DeRef(_29686);
    _29686 = NOVALUE;
    DeRef(_29666);
    _29666 = NOVALUE;
    _29698 = NOVALUE;
    return;
    ;
}


int _39SetPrivateScope(int _s_58562, int _type_sym_58564, int _n_58565)
{
    int _hashval_58566 = NOVALUE;
    int _scope_58567 = NOVALUE;
    int _t_58569 = NOVALUE;
    int _29719 = NOVALUE;
    int _29718 = NOVALUE;
    int _29717 = NOVALUE;
    int _29716 = NOVALUE;
    int _29715 = NOVALUE;
    int _29714 = NOVALUE;
    int _29711 = NOVALUE;
    int _29708 = NOVALUE;
    int _29706 = NOVALUE;
    int _29704 = NOVALUE;
    int _29700 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_s_58562)) {
        _1 = (long)(DBL_PTR(_s_58562)->dbl);
        DeRefDS(_s_58562);
        _s_58562 = _1;
    }

    /** 	scope = SymTab[s][S_SCOPE]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _29700 = (int)*(((s1_ptr)_2)->base + _s_58562);
    _2 = (int)SEQ_PTR(_29700);
    _scope_58567 = (int)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_scope_58567)){
        _scope_58567 = (long)DBL_PTR(_scope_58567)->dbl;
    }
    _29700 = NOVALUE;

    /** 	switch scope do*/
    _0 = _scope_58567;
    switch ( _0 ){ 

        /** 		case SC_PRIVATE then*/
        case 3:

        /** 			DefinedYet(s)*/
        _53DefinedYet(_s_58562);

        /** 			Block_var( s )*/
        _66Block_var(_s_58562);

        /** 			return s*/
        return _s_58562;
        goto L1; // [50] 260

        /** 		case SC_LOOP_VAR then*/
        case 2:

        /** 			DefinedYet(s)*/
        _53DefinedYet(_s_58562);

        /** 			return s*/
        return _s_58562;
        goto L1; // [67] 260

        /** 		case SC_UNDEFINED, SC_MULTIPLY_DEFINED then*/
        case 9:
        case 10:

        /** 			SymTab[s][S_SCOPE] = SC_PRIVATE*/
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _36SymTab_15242 = MAKE_SEQ(_2);
        }
        _3 = (int)(_s_58562 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 4);
        _1 = *(int *)_2;
        *(int *)_2 = 3;
        DeRef(_1);
        _29704 = NOVALUE;

        /** 			SymTab[s][S_VARNUM] = n*/
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _36SymTab_15242 = MAKE_SEQ(_2);
        }
        _3 = (int)(_s_58562 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 16);
        _1 = *(int *)_2;
        *(int *)_2 = _n_58565;
        DeRef(_1);
        _29706 = NOVALUE;

        /** 			SymTab[s][S_VTYPE] = type_sym*/
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _36SymTab_15242 = MAKE_SEQ(_2);
        }
        _3 = (int)(_s_58562 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 15);
        _1 = *(int *)_2;
        *(int *)_2 = _type_sym_58564;
        DeRef(_1);
        _29708 = NOVALUE;

        /** 			if type_sym < 0 then*/
        if (_type_sym_58564 >= 0)
        goto L2; // [124] 135

        /** 				register_forward_type( s, type_sym )*/
        _38register_forward_type(_s_58562, _type_sym_58564);
L2: 

        /** 			Block_var( s )*/
        _66Block_var(_s_58562);

        /** 			return s*/
        return _s_58562;
        goto L1; // [146] 260

        /** 		case SC_LOCAL, SC_GLOBAL, SC_PREDEF, SC_PUBLIC, SC_EXPORT then*/
        case 5:
        case 6:
        case 7:
        case 13:
        case 11:

        /** 			hashval = SymTab[s][S_HASHVAL]*/
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _29711 = (int)*(((s1_ptr)_2)->base + _s_58562);
        _2 = (int)SEQ_PTR(_29711);
        _hashval_58566 = (int)*(((s1_ptr)_2)->base + 11);
        if (!IS_ATOM_INT(_hashval_58566)){
            _hashval_58566 = (long)DBL_PTR(_hashval_58566)->dbl;
        }
        _29711 = NOVALUE;

        /** 			t = buckets[hashval]*/
        _2 = (int)SEQ_PTR(_53buckets_46087);
        _t_58569 = (int)*(((s1_ptr)_2)->base + _hashval_58566);
        if (!IS_ATOM_INT(_t_58569)){
            _t_58569 = (long)DBL_PTR(_t_58569)->dbl;
        }

        /** 			buckets[hashval] = NewEntry(SymTab[s][S_NAME], n, SC_PRIVATE,*/
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _29714 = (int)*(((s1_ptr)_2)->base + _s_58562);
        _2 = (int)SEQ_PTR(_29714);
        if (!IS_ATOM_INT(_35S_NAME_15917)){
            _29715 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15917)->dbl));
        }
        else{
            _29715 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15917);
        }
        _29714 = NOVALUE;
        Ref(_29715);
        _29716 = _53NewEntry(_29715, _n_58565, 3, -100, _hashval_58566, _t_58569, _type_sym_58564);
        _29715 = NOVALUE;
        _2 = (int)SEQ_PTR(_53buckets_46087);
        _2 = (int)(((s1_ptr)_2)->base + _hashval_58566);
        _1 = *(int *)_2;
        *(int *)_2 = _29716;
        if( _1 != _29716 ){
            DeRef(_1);
        }
        _29716 = NOVALUE;

        /** 			Block_var( buckets[hashval] )*/
        _2 = (int)SEQ_PTR(_53buckets_46087);
        _29717 = (int)*(((s1_ptr)_2)->base + _hashval_58566);
        Ref(_29717);
        _66Block_var(_29717);
        _29717 = NOVALUE;

        /** 			return buckets[hashval]*/
        _2 = (int)SEQ_PTR(_53buckets_46087);
        _29718 = (int)*(((s1_ptr)_2)->base + _hashval_58566);
        Ref(_29718);
        return _29718;
        goto L1; // [243] 260

        /** 		case else*/
        default:

        /** 			InternalErr(267, {scope})*/
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = _scope_58567;
        _29719 = MAKE_SEQ(_1);
        _44InternalErr(267, _29719);
        _29719 = NOVALUE;
    ;}L1: 

    /** 	return 0*/
    _29718 = NOVALUE;
    return 0;
    ;
}


void _39For_statement()
{
    int _bp1_58634 = NOVALUE;
    int _bp2_58635 = NOVALUE;
    int _exit_base_58636 = NOVALUE;
    int _next_base_58637 = NOVALUE;
    int _end_op_58638 = NOVALUE;
    int _tok_58640 = NOVALUE;
    int _loop_var_58641 = NOVALUE;
    int _loop_var_sym_58643 = NOVALUE;
    int _save_syms_58644 = NOVALUE;
    int _29766 = NOVALUE;
    int _29764 = NOVALUE;
    int _29763 = NOVALUE;
    int _29757 = NOVALUE;
    int _29755 = NOVALUE;
    int _29753 = NOVALUE;
    int _29752 = NOVALUE;
    int _29751 = NOVALUE;
    int _29750 = NOVALUE;
    int _29748 = NOVALUE;
    int _29746 = NOVALUE;
    int _29745 = NOVALUE;
    int _29744 = NOVALUE;
    int _29743 = NOVALUE;
    int _29741 = NOVALUE;
    int _29739 = NOVALUE;
    int _29735 = NOVALUE;
    int _29733 = NOVALUE;
    int _29730 = NOVALUE;
    int _29728 = NOVALUE;
    int _29722 = NOVALUE;
    int _29721 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	sequence save_syms*/

    /** 	Start_block( FOR )*/
    _66Start_block(21, 0);

    /** 	loop_var = next_token()*/
    _0 = _loop_var_58641;
    _loop_var_58641 = _39next_token();
    DeRef(_0);

    /** 	if not find(loop_var[T_ID], ADDR_TOKS) then*/
    _2 = (int)SEQ_PTR(_loop_var_58641);
    _29721 = (int)*(((s1_ptr)_2)->base + 1);
    _29722 = find_from(_29721, _37ADDR_TOKS_15874, 1);
    _29721 = NOVALUE;
    if (_29722 != 0)
    goto L1; // [31] 42
    _29722 = NOVALUE;

    /** 		CompileErr(28)*/
    RefDS(_22023);
    _44CompileErr(28, _22023, 0);
L1: 

    /** 	if BIND then*/
    if (_35BIND_15890 == 0)
    {
        goto L2; // [46] 55
    }
    else{
    }

    /** 		add_ref(loop_var)*/
    Ref(_loop_var_58641);
    _53add_ref(_loop_var_58641);
L2: 

    /** 	tok_match(EQUALS)*/
    _39tok_match(3, 0);

    /** 	exit_base = length(exit_list)*/
    if (IS_SEQUENCE(_39exit_list_54137)){
            _exit_base_58636 = SEQ_PTR(_39exit_list_54137)->length;
    }
    else {
        _exit_base_58636 = 1;
    }

    /** 	next_base = length(continue_list)*/
    if (IS_SEQUENCE(_39continue_list_54139)){
            _next_base_58637 = SEQ_PTR(_39continue_list_54139)->length;
    }
    else {
        _next_base_58637 = 1;
    }

    /** 	Expr()*/
    _39Expr();

    /** 	tok_match(TO)*/
    _39tok_match(403, 0);

    /** 	exit_base = length(exit_list)*/
    if (IS_SEQUENCE(_39exit_list_54137)){
            _exit_base_58636 = SEQ_PTR(_39exit_list_54137)->length;
    }
    else {
        _exit_base_58636 = 1;
    }

    /** 	Expr()*/
    _39Expr();

    /** 	tok = next_token()*/
    _0 = _tok_58640;
    _tok_58640 = _39next_token();
    DeRef(_0);

    /** 	if tok[T_ID] = BY then*/
    _2 = (int)SEQ_PTR(_tok_58640);
    _29728 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29728, 404)){
        _29728 = NOVALUE;
        goto L3; // [115] 135
    }
    _29728 = NOVALUE;

    /** 		Expr()*/
    _39Expr();

    /** 		end_op = ENDFOR_GENERAL -- will be set at runtime by FOR op*/
    _end_op_58638 = 39;
    goto L4; // [132] 159
L3: 

    /** 		emit_opnd(NewIntSym(1))*/
    _29730 = _53NewIntSym(1);
    _41emit_opnd(_29730);
    _29730 = NOVALUE;

    /** 		putback(tok)*/
    Ref(_tok_58640);
    _39putback(_tok_58640);

    /** 		end_op = ENDFOR_INT_UP1*/
    _end_op_58638 = 54;
L4: 

    /** 	loop_var_sym = loop_var[T_SYM]*/
    _2 = (int)SEQ_PTR(_loop_var_58641);
    _loop_var_sym_58643 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_loop_var_sym_58643)){
        _loop_var_sym_58643 = (long)DBL_PTR(_loop_var_sym_58643)->dbl;
    }

    /** 	if CurrentSub = TopLevelSub then*/
    if (_35CurrentSub_16252 != _35TopLevelSub_16251)
    goto L5; // [175] 221

    /** 		DefinedYet(loop_var_sym)*/
    _53DefinedYet(_loop_var_sym_58643);

    /** 		SymTab[loop_var_sym][S_SCOPE] = SC_GLOOP_VAR*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_loop_var_sym_58643 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = 4;
    DeRef(_1);
    _29733 = NOVALUE;

    /** 		SymTab[loop_var_sym][S_VTYPE] = object_type*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_loop_var_sym_58643 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 15);
    _1 = *(int *)_2;
    *(int *)_2 = _53object_type_46091;
    DeRef(_1);
    _29735 = NOVALUE;
    goto L6; // [218] 265
L5: 

    /** 		loop_var_sym = SetPrivateScope(loop_var_sym, object_type, param_num)*/
    _loop_var_sym_58643 = _39SetPrivateScope(_loop_var_sym_58643, _53object_type_46091, _39param_num_54126);
    if (!IS_ATOM_INT(_loop_var_sym_58643)) {
        _1 = (long)(DBL_PTR(_loop_var_sym_58643)->dbl);
        DeRefDS(_loop_var_sym_58643);
        _loop_var_sym_58643 = _1;
    }

    /** 		param_num += 1*/
    _39param_num_54126 = _39param_num_54126 + 1;

    /** 		SymTab[loop_var_sym][S_SCOPE] = SC_LOOP_VAR*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_loop_var_sym_58643 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = 2;
    DeRef(_1);
    _29739 = NOVALUE;

    /** 		Pop_block_var()*/
    _66Pop_block_var();
L6: 

    /** 	SymTab[loop_var_sym][S_USAGE] = or_bits(SymTab[loop_var_sym][S_USAGE], U_USED)*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_loop_var_sym_58643 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _29743 = (int)*(((s1_ptr)_2)->base + _loop_var_sym_58643);
    _2 = (int)SEQ_PTR(_29743);
    _29744 = (int)*(((s1_ptr)_2)->base + 5);
    _29743 = NOVALUE;
    if (IS_ATOM_INT(_29744)) {
        {unsigned long tu;
             tu = (unsigned long)_29744 | (unsigned long)3;
             _29745 = MAKE_UINT(tu);
        }
    }
    else {
        _29745 = binary_op(OR_BITS, _29744, 3);
    }
    _29744 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = _29745;
    if( _1 != _29745 ){
        DeRef(_1);
    }
    _29745 = NOVALUE;
    _29741 = NOVALUE;

    /** 	op_info1 = loop_var_sym*/
    _41op_info1_50222 = _loop_var_sym_58643;

    /** 	emit_op(FOR)*/
    _41emit_op(21);

    /** 	emit_addr(loop_var_sym)*/
    _41emit_addr(_loop_var_sym_58643);

    /** 	if finish_block_header(FOR) then*/
    _29746 = _39finish_block_header(21);
    if (_29746 == 0) {
        DeRef(_29746);
        _29746 = NOVALUE;
        goto L7; // [325] 336
    }
    else {
        if (!IS_ATOM_INT(_29746) && DBL_PTR(_29746)->dbl == 0.0){
            DeRef(_29746);
            _29746 = NOVALUE;
            goto L7; // [325] 336
        }
        DeRef(_29746);
        _29746 = NOVALUE;
    }
    DeRef(_29746);
    _29746 = NOVALUE;

    /** 		CompileErr(83)*/
    RefDS(_22023);
    _44CompileErr(83, _22023, 0);
L7: 

    /** 	entry_addr &= 0*/
    Append(&_39entry_addr_54141, _39entry_addr_54141, 0);

    /** 	bp1 = length(Code)+1*/
    if (IS_SEQUENCE(_35Code_16332)){
            _29748 = SEQ_PTR(_35Code_16332)->length;
    }
    else {
        _29748 = 1;
    }
    _bp1_58634 = _29748 + 1;
    _29748 = NOVALUE;

    /** 	emit_addr(0) -- will be patched - don't straighten*/
    _41emit_addr(0);

    /** 	save_syms = Code[$-5..$-3] -- could be temps, but can't get rid of them yet*/
    if (IS_SEQUENCE(_35Code_16332)){
            _29750 = SEQ_PTR(_35Code_16332)->length;
    }
    else {
        _29750 = 1;
    }
    _29751 = _29750 - 5;
    _29750 = NOVALUE;
    if (IS_SEQUENCE(_35Code_16332)){
            _29752 = SEQ_PTR(_35Code_16332)->length;
    }
    else {
        _29752 = 1;
    }
    _29753 = _29752 - 3;
    _29752 = NOVALUE;
    rhs_slice_target = (object_ptr)&_save_syms_58644;
    RHS_Slice(_35Code_16332, _29751, _29753);

    /** 	for i = 1 to 3 do*/
    {
        int _i_58732;
        _i_58732 = 1;
L8: 
        if (_i_58732 > 3){
            goto L9; // [385] 408
        }

        /** 		clear_temp( save_syms[i] )*/
        _2 = (int)SEQ_PTR(_save_syms_58644);
        _29755 = (int)*(((s1_ptr)_2)->base + _i_58732);
        Ref(_29755);
        _41clear_temp(_29755);
        _29755 = NOVALUE;

        /** 	end for*/
        _i_58732 = _i_58732 + 1;
        goto L8; // [403] 392
L9: 
        ;
    }

    /** 	flush_temps()*/
    RefDS(_22023);
    _41flush_temps(_22023);

    /** 	bp2 = length(Code)*/
    if (IS_SEQUENCE(_35Code_16332)){
            _bp2_58635 = SEQ_PTR(_35Code_16332)->length;
    }
    else {
        _bp2_58635 = 1;
    }

    /** 	retry_addr &= bp2 + 1*/
    _29757 = _bp2_58635 + 1;
    Append(&_39retry_addr_54143, _39retry_addr_54143, _29757);
    _29757 = NOVALUE;

    /** 	continue_addr &= 0*/
    Append(&_39continue_addr_54142, _39continue_addr_54142, 0);

    /** 	loop_stack &= FOR*/
    Append(&_39loop_stack_54151, _39loop_stack_54151, 21);

    /** 	if not TRANSLATE then*/
    if (_35TRANSLATE_15887 != 0)
    goto LA; // [454] 478

    /** 		if OpTrace then*/
    if (_35OpTrace_16313 == 0)
    {
        goto LB; // [461] 477
    }
    else{
    }

    /** 			emit_op(DISPLAY_VAR)*/
    _41emit_op(87);

    /** 			emit_addr(loop_var_sym)*/
    _41emit_addr(_loop_var_sym_58643);
LB: 
LA: 

    /** 	Statement_list()*/
    _39Statement_list();

    /** 	tok_match(END)*/
    _39tok_match(402, 0);

    /** 	tok_match(FOR, END)*/
    _39tok_match(21, 402);

    /** 	End_block( FOR )*/
    _66End_block(21);

    /** 	StartSourceLine(TRUE, TRANSLATE)*/
    _41StartSourceLine(_13TRUE_436, _35TRANSLATE_15887, 2);

    /** 	op_info1 = loop_var_sym*/
    _41op_info1_50222 = _loop_var_sym_58643;

    /** 	op_info2 = bp2 + 1*/
    _41op_info2_50223 = _bp2_58635 + 1;

    /** 	PatchNList(next_base)*/
    _39PatchNList(_next_base_58637);

    /** 	emit_op(end_op)*/
    _41emit_op(_end_op_58638);

    /** 	backpatch(bp1, length(Code)+1)*/
    if (IS_SEQUENCE(_35Code_16332)){
            _29763 = SEQ_PTR(_35Code_16332)->length;
    }
    else {
        _29763 = 1;
    }
    _29764 = _29763 + 1;
    _29763 = NOVALUE;
    _41backpatch(_bp1_58634, _29764);
    _29764 = NOVALUE;

    /** 	if not TRANSLATE then*/
    if (_35TRANSLATE_15887 != 0)
    goto LC; // [564] 588

    /** 		if OpTrace then*/
    if (_35OpTrace_16313 == 0)
    {
        goto LD; // [571] 587
    }
    else{
    }

    /** 			emit_op(ERASE_SYMBOL)*/
    _41emit_op(90);

    /** 			emit_addr(loop_var_sym)*/
    _41emit_addr(_loop_var_sym_58643);
LD: 
LC: 

    /** 	Hide(loop_var_sym)*/
    _53Hide(_loop_var_sym_58643);

    /** 	exit_loop(exit_base)*/
    _39exit_loop(_exit_base_58636);

    /** 	for i = 1 to 3 do*/
    {
        int _i_58778;
        _i_58778 = 1;
LE: 
        if (_i_58778 > 3){
            goto LF; // [600] 626
        }

        /** 		emit_temp( save_syms[i], NEW_REFERENCE )*/
        _2 = (int)SEQ_PTR(_save_syms_58644);
        _29766 = (int)*(((s1_ptr)_2)->base + _i_58778);
        Ref(_29766);
        _41emit_temp(_29766, 1);
        _29766 = NOVALUE;

        /** 	end for*/
        _i_58778 = _i_58778 + 1;
        goto LE; // [621] 607
LF: 
        ;
    }

    /** 	flush_temps()*/
    RefDS(_22023);
    _41flush_temps(_22023);

    /** end procedure*/
    DeRef(_tok_58640);
    DeRef(_loop_var_58641);
    DeRef(_save_syms_58644);
    DeRef(_29751);
    _29751 = NOVALUE;
    DeRef(_29753);
    _29753 = NOVALUE;
    return;
    ;
}


int _39CompileType(int _type_ptr_58786)
{
    int _t_58787 = NOVALUE;
    int _29777 = NOVALUE;
    int _29776 = NOVALUE;
    int _29775 = NOVALUE;
    int _29769 = NOVALUE;
    int _29768 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_type_ptr_58786)) {
        _1 = (long)(DBL_PTR(_type_ptr_58786)->dbl);
        DeRefDS(_type_ptr_58786);
        _type_ptr_58786 = _1;
    }

    /** 	if type_ptr < 0 then*/
    if (_type_ptr_58786 >= 0)
    goto L1; // [5] 16

    /** 		return type_ptr*/
    return _type_ptr_58786;
L1: 

    /** 	if SymTab[type_ptr][S_TOKEN] = OBJECT then*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _29768 = (int)*(((s1_ptr)_2)->base + _type_ptr_58786);
    _2 = (int)SEQ_PTR(_29768);
    if (!IS_ATOM_INT(_35S_TOKEN_15922)){
        _29769 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TOKEN_15922)->dbl));
    }
    else{
        _29769 = (int)*(((s1_ptr)_2)->base + _35S_TOKEN_15922);
    }
    _29768 = NOVALUE;
    if (binary_op_a(NOTEQ, _29769, 415)){
        _29769 = NOVALUE;
        goto L2; // [32] 47
    }
    _29769 = NOVALUE;

    /** 		return TYPE_OBJECT*/
    return 16;
    goto L3; // [44] 218
L2: 

    /** 	elsif type_ptr = integer_type then*/
    if (_type_ptr_58786 != _53integer_type_46097)
    goto L4; // [51] 66

    /** 		return TYPE_INTEGER*/
    return 1;
    goto L3; // [63] 218
L4: 

    /** 	elsif type_ptr = atom_type then*/
    if (_type_ptr_58786 != _53atom_type_46093)
    goto L5; // [70] 85

    /** 		return TYPE_ATOM*/
    return 4;
    goto L3; // [82] 218
L5: 

    /** 	elsif type_ptr = sequence_type then*/
    if (_type_ptr_58786 != _53sequence_type_46095)
    goto L6; // [89] 104

    /** 		return TYPE_SEQUENCE*/
    return 8;
    goto L3; // [101] 218
L6: 

    /** 	elsif type_ptr = object_type then*/
    if (_type_ptr_58786 != _53object_type_46091)
    goto L7; // [108] 123

    /** 		return TYPE_OBJECT*/
    return 16;
    goto L3; // [120] 218
L7: 

    /** 		t = SymTab[SymTab[type_ptr][S_NEXT]][S_VTYPE]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _29775 = (int)*(((s1_ptr)_2)->base + _type_ptr_58786);
    _2 = (int)SEQ_PTR(_29775);
    _29776 = (int)*(((s1_ptr)_2)->base + 2);
    _29775 = NOVALUE;
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!IS_ATOM_INT(_29776)){
        _29777 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_29776)->dbl));
    }
    else{
        _29777 = (int)*(((s1_ptr)_2)->base + _29776);
    }
    _2 = (int)SEQ_PTR(_29777);
    _t_58787 = (int)*(((s1_ptr)_2)->base + 15);
    if (!IS_ATOM_INT(_t_58787)){
        _t_58787 = (long)DBL_PTR(_t_58787)->dbl;
    }
    _29777 = NOVALUE;

    /** 		if t = integer_type then*/
    if (_t_58787 != _53integer_type_46097)
    goto L8; // [155] 170

    /** 			return TYPE_INTEGER*/
    _29776 = NOVALUE;
    return 1;
    goto L9; // [167] 217
L8: 

    /** 		elsif t = atom_type then*/
    if (_t_58787 != _53atom_type_46093)
    goto LA; // [174] 189

    /** 			return TYPE_ATOM*/
    _29776 = NOVALUE;
    return 4;
    goto L9; // [186] 217
LA: 

    /** 		elsif t = sequence_type then*/
    if (_t_58787 != _53sequence_type_46095)
    goto LB; // [193] 208

    /** 			return TYPE_SEQUENCE*/
    _29776 = NOVALUE;
    return 8;
    goto L9; // [205] 217
LB: 

    /** 			return TYPE_OBJECT*/
    _29776 = NOVALUE;
    return 16;
L9: 
L3: 
    ;
}


int _39get_assigned_sym()
{
    int _29790 = NOVALUE;
    int _29789 = NOVALUE;
    int _29788 = NOVALUE;
    int _29786 = NOVALUE;
    int _29785 = NOVALUE;
    int _29784 = NOVALUE;
    int _29783 = NOVALUE;
    int _29782 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not find( Code[$-2], {ASSIGN, ASSIGN_I}) then*/
    if (IS_SEQUENCE(_35Code_16332)){
            _29782 = SEQ_PTR(_35Code_16332)->length;
    }
    else {
        _29782 = 1;
    }
    _29783 = _29782 - 2;
    _29782 = NOVALUE;
    _2 = (int)SEQ_PTR(_35Code_16332);
    _29784 = (int)*(((s1_ptr)_2)->base + _29783);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 18;
    ((int *)_2)[2] = 113;
    _29785 = MAKE_SEQ(_1);
    _29786 = find_from(_29784, _29785, 1);
    _29784 = NOVALUE;
    DeRefDS(_29785);
    _29785 = NOVALUE;
    if (_29786 != 0)
    goto L1; // [29] 39
    _29786 = NOVALUE;

    /** 		return 0*/
    _29783 = NOVALUE;
    return 0;
L1: 

    /** 	return Code[$-1]*/
    if (IS_SEQUENCE(_35Code_16332)){
            _29788 = SEQ_PTR(_35Code_16332)->length;
    }
    else {
        _29788 = 1;
    }
    _29789 = _29788 - 1;
    _29788 = NOVALUE;
    _2 = (int)SEQ_PTR(_35Code_16332);
    _29790 = (int)*(((s1_ptr)_2)->base + _29789);
    Ref(_29790);
    DeRef(_29783);
    _29783 = NOVALUE;
    _29789 = NOVALUE;
    return _29790;
    ;
}


void _39Assign_Constant(int _sym_58856)
{
    int _valsym_58858 = NOVALUE;
    int _val_58861 = NOVALUE;
    int _29817 = NOVALUE;
    int _29816 = NOVALUE;
    int _29814 = NOVALUE;
    int _29813 = NOVALUE;
    int _29812 = NOVALUE;
    int _29810 = NOVALUE;
    int _29809 = NOVALUE;
    int _29808 = NOVALUE;
    int _29806 = NOVALUE;
    int _29805 = NOVALUE;
    int _29804 = NOVALUE;
    int _29802 = NOVALUE;
    int _29801 = NOVALUE;
    int _29800 = NOVALUE;
    int _29798 = NOVALUE;
    int _29796 = NOVALUE;
    int _29794 = NOVALUE;
    int _29792 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	symtab_index valsym = Pop() -- pop the sym for the constant, too*/
    _valsym_58858 = _41Pop();
    if (!IS_ATOM_INT(_valsym_58858)) {
        _1 = (long)(DBL_PTR(_valsym_58858)->dbl);
        DeRefDS(_valsym_58858);
        _valsym_58858 = _1;
    }

    /** 	object val = SymTab[valsym][S_OBJ]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _29792 = (int)*(((s1_ptr)_2)->base + _valsym_58858);
    DeRef(_val_58861);
    _2 = (int)SEQ_PTR(_29792);
    _val_58861 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_val_58861);
    _29792 = NOVALUE;

    /** 	SymTab[sym][S_OBJ] = val*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58856 + ((s1_ptr)_2)->base);
    Ref(_val_58861);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _val_58861;
    DeRef(_1);
    _29794 = NOVALUE;

    /** 	SymTab[sym][S_INITLEVEL] = 0*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58856 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 14);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _29796 = NOVALUE;

    /** 	if TRANSLATE then*/
    if (_35TRANSLATE_15887 == 0)
    {
        goto L1; // [58] 197
    }
    else{
    }

    /** 		SymTab[sym][S_GTYPE] = SymTab[valsym][S_GTYPE]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58856 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _29800 = (int)*(((s1_ptr)_2)->base + _valsym_58858);
    _2 = (int)SEQ_PTR(_29800);
    _29801 = (int)*(((s1_ptr)_2)->base + 36);
    _29800 = NOVALUE;
    Ref(_29801);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 36);
    _1 = *(int *)_2;
    *(int *)_2 = _29801;
    if( _1 != _29801 ){
        DeRef(_1);
    }
    _29801 = NOVALUE;
    _29798 = NOVALUE;

    /** 		SymTab[sym][S_SEQ_ELEM] = SymTab[valsym][S_SEQ_ELEM]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58856 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _29804 = (int)*(((s1_ptr)_2)->base + _valsym_58858);
    _2 = (int)SEQ_PTR(_29804);
    _29805 = (int)*(((s1_ptr)_2)->base + 33);
    _29804 = NOVALUE;
    Ref(_29805);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 33);
    _1 = *(int *)_2;
    *(int *)_2 = _29805;
    if( _1 != _29805 ){
        DeRef(_1);
    }
    _29805 = NOVALUE;
    _29802 = NOVALUE;

    /** 		SymTab[sym][S_OBJ_MIN] = SymTab[valsym][S_OBJ_MIN]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58856 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _29808 = (int)*(((s1_ptr)_2)->base + _valsym_58858);
    _2 = (int)SEQ_PTR(_29808);
    _29809 = (int)*(((s1_ptr)_2)->base + 30);
    _29808 = NOVALUE;
    Ref(_29809);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 30);
    _1 = *(int *)_2;
    *(int *)_2 = _29809;
    if( _1 != _29809 ){
        DeRef(_1);
    }
    _29809 = NOVALUE;
    _29806 = NOVALUE;

    /** 		SymTab[sym][S_OBJ_MAX] = SymTab[valsym][S_OBJ_MAX]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58856 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _29812 = (int)*(((s1_ptr)_2)->base + _valsym_58858);
    _2 = (int)SEQ_PTR(_29812);
    _29813 = (int)*(((s1_ptr)_2)->base + 31);
    _29812 = NOVALUE;
    Ref(_29813);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 31);
    _1 = *(int *)_2;
    *(int *)_2 = _29813;
    if( _1 != _29813 ){
        DeRef(_1);
    }
    _29813 = NOVALUE;
    _29810 = NOVALUE;

    /** 		SymTab[sym][S_SEQ_LEN] = SymTab[valsym][S_SEQ_LEN]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58856 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _29816 = (int)*(((s1_ptr)_2)->base + _valsym_58858);
    _2 = (int)SEQ_PTR(_29816);
    _29817 = (int)*(((s1_ptr)_2)->base + 32);
    _29816 = NOVALUE;
    Ref(_29817);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 32);
    _1 = *(int *)_2;
    *(int *)_2 = _29817;
    if( _1 != _29817 ){
        DeRef(_1);
    }
    _29817 = NOVALUE;
    _29814 = NOVALUE;
L1: 

    /** end procedure*/
    DeRef(_val_58861);
    return;
    ;
}


int _39Global_declaration(int _type_ptr_58918, int _scope_58919)
{
    int _new_symbols_58920 = NOVALUE;
    int _tok_58922 = NOVALUE;
    int _tsym_58923 = NOVALUE;
    int _prevtok_58924 = NOVALUE;
    int _sym_58926 = NOVALUE;
    int _valsym_58927 = NOVALUE;
    int _h_58928 = NOVALUE;
    int _count_58929 = NOVALUE;
    int _val_58930 = NOVALUE;
    int _usedval_58931 = NOVALUE;
    int _deltafunc_58932 = NOVALUE;
    int _delta_58933 = NOVALUE;
    int _is_fwd_ref_58934 = NOVALUE;
    int _ptok_58951 = NOVALUE;
    int _negate_58967 = NOVALUE;
    int _negate_59213 = NOVALUE;
    int _31647 = NOVALUE;
    int _31646 = NOVALUE;
    int _31645 = NOVALUE;
    int _30057 = NOVALUE;
    int _30055 = NOVALUE;
    int _30053 = NOVALUE;
    int _30051 = NOVALUE;
    int _30049 = NOVALUE;
    int _30046 = NOVALUE;
    int _30044 = NOVALUE;
    int _30043 = NOVALUE;
    int _30042 = NOVALUE;
    int _30041 = NOVALUE;
    int _30040 = NOVALUE;
    int _30039 = NOVALUE;
    int _30037 = NOVALUE;
    int _30033 = NOVALUE;
    int _30031 = NOVALUE;
    int _30029 = NOVALUE;
    int _30027 = NOVALUE;
    int _30025 = NOVALUE;
    int _30023 = NOVALUE;
    int _30022 = NOVALUE;
    int _30020 = NOVALUE;
    int _30019 = NOVALUE;
    int _30018 = NOVALUE;
    int _30016 = NOVALUE;
    int _30014 = NOVALUE;
    int _30012 = NOVALUE;
    int _30011 = NOVALUE;
    int _30010 = NOVALUE;
    int _30008 = NOVALUE;
    int _30007 = NOVALUE;
    int _30006 = NOVALUE;
    int _30004 = NOVALUE;
    int _30002 = NOVALUE;
    int _30000 = NOVALUE;
    int _29999 = NOVALUE;
    int _29998 = NOVALUE;
    int _29997 = NOVALUE;
    int _29996 = NOVALUE;
    int _29993 = NOVALUE;
    int _29991 = NOVALUE;
    int _29989 = NOVALUE;
    int _29988 = NOVALUE;
    int _29987 = NOVALUE;
    int _29983 = NOVALUE;
    int _29982 = NOVALUE;
    int _29981 = NOVALUE;
    int _29977 = NOVALUE;
    int _29976 = NOVALUE;
    int _29975 = NOVALUE;
    int _29973 = NOVALUE;
    int _29972 = NOVALUE;
    int _29971 = NOVALUE;
    int _29970 = NOVALUE;
    int _29969 = NOVALUE;
    int _29968 = NOVALUE;
    int _29967 = NOVALUE;
    int _29966 = NOVALUE;
    int _29965 = NOVALUE;
    int _29962 = NOVALUE;
    int _29960 = NOVALUE;
    int _29959 = NOVALUE;
    int _29957 = NOVALUE;
    int _29956 = NOVALUE;
    int _29954 = NOVALUE;
    int _29953 = NOVALUE;
    int _29952 = NOVALUE;
    int _29951 = NOVALUE;
    int _29949 = NOVALUE;
    int _29947 = NOVALUE;
    int _29945 = NOVALUE;
    int _29942 = NOVALUE;
    int _29939 = NOVALUE;
    int _29936 = NOVALUE;
    int _29934 = NOVALUE;
    int _29933 = NOVALUE;
    int _29932 = NOVALUE;
    int _29931 = NOVALUE;
    int _29929 = NOVALUE;
    int _29928 = NOVALUE;
    int _29927 = NOVALUE;
    int _29926 = NOVALUE;
    int _29922 = NOVALUE;
    int _29921 = NOVALUE;
    int _29920 = NOVALUE;
    int _29919 = NOVALUE;
    int _29918 = NOVALUE;
    int _29917 = NOVALUE;
    int _29914 = NOVALUE;
    int _29912 = NOVALUE;
    int _29911 = NOVALUE;
    int _29910 = NOVALUE;
    int _29909 = NOVALUE;
    int _29908 = NOVALUE;
    int _29905 = NOVALUE;
    int _29903 = NOVALUE;
    int _29901 = NOVALUE;
    int _29900 = NOVALUE;
    int _29899 = NOVALUE;
    int _29898 = NOVALUE;
    int _29897 = NOVALUE;
    int _29896 = NOVALUE;
    int _29895 = NOVALUE;
    int _29893 = NOVALUE;
    int _29890 = NOVALUE;
    int _29888 = NOVALUE;
    int _29887 = NOVALUE;
    int _29886 = NOVALUE;
    int _29885 = NOVALUE;
    int _29884 = NOVALUE;
    int _29883 = NOVALUE;
    int _29882 = NOVALUE;
    int _29881 = NOVALUE;
    int _29878 = NOVALUE;
    int _29877 = NOVALUE;
    int _29876 = NOVALUE;
    int _29874 = NOVALUE;
    int _29873 = NOVALUE;
    int _29872 = NOVALUE;
    int _29871 = NOVALUE;
    int _29870 = NOVALUE;
    int _29868 = NOVALUE;
    int _29867 = NOVALUE;
    int _29866 = NOVALUE;
    int _29864 = NOVALUE;
    int _29863 = NOVALUE;
    int _29861 = NOVALUE;
    int _29858 = NOVALUE;
    int _29856 = NOVALUE;
    int _29854 = NOVALUE;
    int _29846 = NOVALUE;
    int _29845 = NOVALUE;
    int _29843 = NOVALUE;
    int _29840 = NOVALUE;
    int _29833 = NOVALUE;
    int _29830 = NOVALUE;
    int _29829 = NOVALUE;
    int _29827 = NOVALUE;
    int _29823 = NOVALUE;
    int _29822 = NOVALUE;
    int _29821 = NOVALUE;
    int _29820 = NOVALUE;
    int _29819 = NOVALUE;
    int _29818 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_type_ptr_58918)) {
        _1 = (long)(DBL_PTR(_type_ptr_58918)->dbl);
        DeRefDS(_type_ptr_58918);
        _type_ptr_58918 = _1;
    }

    /** 	object tsym*/

    /** 	object prevtok = 0*/
    DeRef(_prevtok_58924);
    _prevtok_58924 = 0;

    /** 	integer h, count = 0*/
    _count_58929 = 0;

    /** 	atom val = 1, usedval*/
    DeRef(_val_58930);
    _val_58930 = 1;

    /** 	integer deltafunc = '+'*/
    _deltafunc_58932 = 43;

    /** 	atom delta = 1*/
    DeRef(_delta_58933);
    _delta_58933 = 1;

    /** 	new_symbols = {}*/
    RefDS(_22023);
    DeRefi(_new_symbols_58920);
    _new_symbols_58920 = _22023;

    /** 	integer is_fwd_ref = 0*/
    _is_fwd_ref_58934 = 0;

    /** 	if type_ptr > 0 and SymTab[type_ptr][S_SCOPE] = SC_UNDEFINED then*/
    _29818 = (_type_ptr_58918 > 0);
    if (_29818 == 0) {
        goto L1; // [50] 105
    }
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _29820 = (int)*(((s1_ptr)_2)->base + _type_ptr_58918);
    _2 = (int)SEQ_PTR(_29820);
    _29821 = (int)*(((s1_ptr)_2)->base + 4);
    _29820 = NOVALUE;
    if (IS_ATOM_INT(_29821)) {
        _29822 = (_29821 == 9);
    }
    else {
        _29822 = binary_op(EQUALS, _29821, 9);
    }
    _29821 = NOVALUE;
    if (_29822 == 0) {
        DeRef(_29822);
        _29822 = NOVALUE;
        goto L1; // [73] 105
    }
    else {
        if (!IS_ATOM_INT(_29822) && DBL_PTR(_29822)->dbl == 0.0){
            DeRef(_29822);
            _29822 = NOVALUE;
            goto L1; // [73] 105
        }
        DeRef(_29822);
        _29822 = NOVALUE;
    }
    DeRef(_29822);
    _29822 = NOVALUE;

    /** 		is_fwd_ref = 1*/
    _is_fwd_ref_58934 = 1;

    /** 		Hide(type_ptr)*/
    _53Hide(_type_ptr_58918);

    /** 		type_ptr = -new_forward_reference( TYPE, type_ptr )*/
    DeRef(_31647);
    _31647 = 504;
    _29823 = _38new_forward_reference(504, _type_ptr_58918, 504);
    _31647 = NOVALUE;
    if (IS_ATOM_INT(_29823)) {
        if ((unsigned long)_29823 == 0xC0000000)
        _type_ptr_58918 = (int)NewDouble((double)-0xC0000000);
        else
        _type_ptr_58918 = - _29823;
    }
    else {
        _type_ptr_58918 = unary_op(UMINUS, _29823);
    }
    DeRef(_29823);
    _29823 = NOVALUE;
    if (!IS_ATOM_INT(_type_ptr_58918)) {
        _1 = (long)(DBL_PTR(_type_ptr_58918)->dbl);
        DeRefDS(_type_ptr_58918);
        _type_ptr_58918 = _1;
    }
L1: 

    /** 	if type_ptr = -1 then*/
    if (_type_ptr_58918 != -1)
    goto L2; // [107] 423

    /** 		sequence ptok = next_token()*/
    _0 = _ptok_58951;
    _ptok_58951 = _39next_token();
    DeRef(_0);

    /** 		if ptok[T_ID] = TYPE_DECL then*/
    _2 = (int)SEQ_PTR(_ptok_58951);
    _29827 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29827, 416)){
        _29827 = NOVALUE;
        goto L3; // [128] 171
    }
    _29827 = NOVALUE;

    /** 			putback(keyfind("enum",-1))*/
    RefDS(_26320);
    DeRef(_31645);
    _31645 = _26320;
    _31646 = _53hashfn(_31645);
    _31645 = NOVALUE;
    RefDS(_26320);
    _29829 = _53keyfind(_26320, -1, _35current_file_no_16244, 0, _31646);
    _31646 = NOVALUE;
    _39putback(_29829);
    _29829 = NOVALUE;

    /** 			SubProg(TYPE_DECL, scope)*/
    _39SubProg(416, _scope_58919);

    /** 			return {}*/
    RefDS(_22023);
    DeRefDS(_ptok_58951);
    DeRefi(_new_symbols_58920);
    DeRef(_tok_58922);
    DeRef(_tsym_58923);
    DeRef(_prevtok_58924);
    DeRef(_val_58930);
    DeRef(_usedval_58931);
    DeRef(_delta_58933);
    DeRef(_29818);
    _29818 = NOVALUE;
    return _22023;
    goto L4; // [168] 422
L3: 

    /** 		elsif ptok[T_ID] = BY then*/
    _2 = (int)SEQ_PTR(_ptok_58951);
    _29830 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29830, 404)){
        _29830 = NOVALUE;
        goto L5; // [181] 416
    }
    _29830 = NOVALUE;

    /** 			integer negate = 0*/
    _negate_58967 = 0;

    /** 			ptok = next_token()*/
    _0 = _ptok_58951;
    _ptok_58951 = _39next_token();
    DeRefDS(_0);

    /** 			switch ptok[T_ID] do*/
    _2 = (int)SEQ_PTR(_ptok_58951);
    _29833 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_29833) ){
        goto L6; // [205] 284
    }
    if(!IS_ATOM_INT(_29833)){
        if( (DBL_PTR(_29833)->dbl != (double) ((int) DBL_PTR(_29833)->dbl) ) ){
            goto L6; // [205] 284
        }
        _0 = (int) DBL_PTR(_29833)->dbl;
    }
    else {
        _0 = _29833;
    };
    _29833 = NOVALUE;
    switch ( _0 ){ 

        /** 				case reserved:MULTIPLY then*/
        case 13:

        /** 					deltafunc = '*'*/
        _deltafunc_58932 = 42;

        /** 					ptok = next_token()*/
        _0 = _ptok_58951;
        _ptok_58951 = _39next_token();
        DeRef(_0);
        goto L7; // [226] 292

        /** 				case reserved:DIVIDE then*/
        case 14:

        /** 					deltafunc = '/'*/
        _deltafunc_58932 = 47;

        /** 					ptok = next_token()*/
        _0 = _ptok_58951;
        _ptok_58951 = _39next_token();
        DeRef(_0);
        goto L7; // [244] 292

        /** 				case MINUS then*/
        case 10:

        /** 					deltafunc = '-'*/
        _deltafunc_58932 = 45;

        /** 					ptok = next_token()*/
        _0 = _ptok_58951;
        _ptok_58951 = _39next_token();
        DeRef(_0);
        goto L7; // [262] 292

        /** 				case PLUS then*/
        case 11:

        /** 					deltafunc = '+'*/
        _deltafunc_58932 = 43;

        /** 					ptok = next_token()*/
        _0 = _ptok_58951;
        _ptok_58951 = _39next_token();
        DeRef(_0);
        goto L7; // [280] 292

        /** 				case else*/
        default:
L6: 

        /** 					deltafunc = '+'*/
        _deltafunc_58932 = 43;
    ;}L7: 

    /** 			if ptok[T_ID] = MINUS then*/
    _2 = (int)SEQ_PTR(_ptok_58951);
    _29840 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29840, 10)){
        _29840 = NOVALUE;
        goto L8; // [302] 319
    }
    _29840 = NOVALUE;

    /** 				negate = 1*/
    _negate_58967 = 1;

    /** 				ptok = next_token()*/
    _0 = _ptok_58951;
    _ptok_58951 = _39next_token();
    DeRefDS(_0);
L8: 

    /** 			if ptok[T_ID] != ATOM then*/
    _2 = (int)SEQ_PTR(_ptok_58951);
    _29843 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _29843, 502)){
        _29843 = NOVALUE;
        goto L9; // [329] 341
    }
    _29843 = NOVALUE;

    /** 				CompileErr( 344 )*/
    RefDS(_22023);
    _44CompileErr(344, _22023, 0);
L9: 

    /** 			delta = SymTab[ptok[T_SYM]][S_OBJ]*/
    _2 = (int)SEQ_PTR(_ptok_58951);
    _29845 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!IS_ATOM_INT(_29845)){
        _29846 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_29845)->dbl));
    }
    else{
        _29846 = (int)*(((s1_ptr)_2)->base + _29845);
    }
    DeRef(_delta_58933);
    _2 = (int)SEQ_PTR(_29846);
    _delta_58933 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_delta_58933);
    _29846 = NOVALUE;

    /** 			if negate then*/
    if (_negate_58967 == 0)
    {
        goto LA; // [363] 372
    }
    else{
    }

    /** 				delta = -delta*/
    _0 = _delta_58933;
    if (IS_ATOM_INT(_delta_58933)) {
        if ((unsigned long)_delta_58933 == 0xC0000000)
        _delta_58933 = (int)NewDouble((double)-0xC0000000);
        else
        _delta_58933 = - _delta_58933;
    }
    else {
        _delta_58933 = unary_op(UMINUS, _delta_58933);
    }
    DeRef(_0);
LA: 

    /** 			switch deltafunc do*/
    _0 = _deltafunc_58932;
    switch ( _0 ){ 

        /** 				case '/' then*/
        case 47:

        /** 					delta = 1 / delta*/
        _0 = _delta_58933;
        if (IS_ATOM_INT(_delta_58933)) {
            _delta_58933 = (1 % _delta_58933) ? NewDouble((double)1 / _delta_58933) : (1 / _delta_58933);
        }
        else {
            _delta_58933 = NewDouble((double)1 / DBL_PTR(_delta_58933)->dbl);
        }
        DeRef(_0);

        /** 					deltafunc = '*'*/
        _deltafunc_58932 = 42;
        goto LB; // [394] 411

        /** 				case '-' then*/
        case 45:

        /** 					delta = -delta*/
        _0 = _delta_58933;
        if (IS_ATOM_INT(_delta_58933)) {
            if ((unsigned long)_delta_58933 == 0xC0000000)
            _delta_58933 = (int)NewDouble((double)-0xC0000000);
            else
            _delta_58933 = - _delta_58933;
        }
        else {
            _delta_58933 = unary_op(UMINUS, _delta_58933);
        }
        DeRef(_0);

        /** 					deltafunc = '+'*/
        _deltafunc_58932 = 43;
    ;}LB: 
    goto L4; // [413] 422
L5: 

    /** 			putback(ptok)*/
    RefDS(_ptok_58951);
    _39putback(_ptok_58951);
L4: 
L2: 
    DeRef(_ptok_58951);
    _ptok_58951 = NOVALUE;

    /** 	valsym = 0*/
    _valsym_58927 = 0;

    /** 	while TRUE do*/
LC: 
    if (_13TRUE_436 == 0)
    {
        goto LD; // [439] 2282
    }
    else{
    }

    /** 		tok = next_token()*/
    _0 = _tok_58922;
    _tok_58922 = _39next_token();
    DeRef(_0);

    /** 		if tok[T_ID] = DOLLAR then*/
    _2 = (int)SEQ_PTR(_tok_58922);
    _29854 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29854, -22)){
        _29854 = NOVALUE;
        goto LE; // [457] 496
    }
    _29854 = NOVALUE;

    /** 			if not equal(prevtok, 0) then*/
    if (_prevtok_58924 == 0)
    _29856 = 1;
    else if (IS_ATOM_INT(_prevtok_58924) && IS_ATOM_INT(0))
    _29856 = 0;
    else
    _29856 = (compare(_prevtok_58924, 0) == 0);
    if (_29856 != 0)
    goto LF; // [467] 495
    _29856 = NOVALUE;

    /** 				if prevtok[T_ID] = COMMA then*/
    _2 = (int)SEQ_PTR(_prevtok_58924);
    _29858 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29858, -30)){
        _29858 = NOVALUE;
        goto L10; // [480] 494
    }
    _29858 = NOVALUE;

    /** 					tok = next_token()*/
    _0 = _tok_58922;
    _tok_58922 = _39next_token();
    DeRef(_0);

    /** 					exit*/
    goto LD; // [491] 2282
L10: 
LF: 
LE: 

    /** 		if tok[T_ID] = END_OF_FILE then*/
    _2 = (int)SEQ_PTR(_tok_58922);
    _29861 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29861, -21)){
        _29861 = NOVALUE;
        goto L11; // [506] 518
    }
    _29861 = NOVALUE;

    /** 			CompileErr( 32 )*/
    RefDS(_22023);
    _44CompileErr(32, _22023, 0);
L11: 

    /** 		if not find(tok[T_ID], ADDR_TOKS) then*/
    _2 = (int)SEQ_PTR(_tok_58922);
    _29863 = (int)*(((s1_ptr)_2)->base + 1);
    _29864 = find_from(_29863, _37ADDR_TOKS_15874, 1);
    _29863 = NOVALUE;
    if (_29864 != 0)
    goto L12; // [533] 558
    _29864 = NOVALUE;

    /** 			CompileErr(25, {find_category(tok[T_ID])} )*/
    _2 = (int)SEQ_PTR(_tok_58922);
    _29866 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_29866);
    _29867 = _63find_category(_29866);
    _29866 = NOVALUE;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _29867;
    _29868 = MAKE_SEQ(_1);
    _29867 = NOVALUE;
    _44CompileErr(25, _29868, 0);
    _29868 = NOVALUE;
L12: 

    /** 		sym = tok[T_SYM]*/
    _2 = (int)SEQ_PTR(_tok_58922);
    _sym_58926 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_sym_58926)){
        _sym_58926 = (long)DBL_PTR(_sym_58926)->dbl;
    }

    /** 		DefinedYet(sym)*/
    _53DefinedYet(_sym_58926);

    /** 		if find(SymTab[sym][S_SCOPE], {SC_GLOBAL, SC_PREDEF, SC_PUBLIC, SC_EXPORT}) then*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _29870 = (int)*(((s1_ptr)_2)->base + _sym_58926);
    _2 = (int)SEQ_PTR(_29870);
    _29871 = (int)*(((s1_ptr)_2)->base + 4);
    _29870 = NOVALUE;
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 6;
    *((int *)(_2+8)) = 7;
    *((int *)(_2+12)) = 13;
    *((int *)(_2+16)) = 11;
    _29872 = MAKE_SEQ(_1);
    _29873 = find_from(_29871, _29872, 1);
    _29871 = NOVALUE;
    DeRefDS(_29872);
    _29872 = NOVALUE;
    if (_29873 == 0)
    {
        _29873 = NOVALUE;
        goto L13; // [607] 669
    }
    else{
        _29873 = NOVALUE;
    }

    /** 			h = SymTab[sym][S_HASHVAL]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _29874 = (int)*(((s1_ptr)_2)->base + _sym_58926);
    _2 = (int)SEQ_PTR(_29874);
    _h_58928 = (int)*(((s1_ptr)_2)->base + 11);
    if (!IS_ATOM_INT(_h_58928)){
        _h_58928 = (long)DBL_PTR(_h_58928)->dbl;
    }
    _29874 = NOVALUE;

    /** 			sym = NewEntry(SymTab[sym][S_NAME], 0, 0, VARIABLE, h, buckets[h], 0)*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _29876 = (int)*(((s1_ptr)_2)->base + _sym_58926);
    _2 = (int)SEQ_PTR(_29876);
    if (!IS_ATOM_INT(_35S_NAME_15917)){
        _29877 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15917)->dbl));
    }
    else{
        _29877 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15917);
    }
    _29876 = NOVALUE;
    _2 = (int)SEQ_PTR(_53buckets_46087);
    _29878 = (int)*(((s1_ptr)_2)->base + _h_58928);
    Ref(_29877);
    Ref(_29878);
    _sym_58926 = _53NewEntry(_29877, 0, 0, -100, _h_58928, _29878, 0);
    _29877 = NOVALUE;
    _29878 = NOVALUE;
    if (!IS_ATOM_INT(_sym_58926)) {
        _1 = (long)(DBL_PTR(_sym_58926)->dbl);
        DeRefDS(_sym_58926);
        _sym_58926 = _1;
    }

    /** 			buckets[h] = sym*/
    _2 = (int)SEQ_PTR(_53buckets_46087);
    _2 = (int)(((s1_ptr)_2)->base + _h_58928);
    _1 = *(int *)_2;
    *(int *)_2 = _sym_58926;
    DeRef(_1);
L13: 

    /** 		new_symbols = append(new_symbols, sym)*/
    Append(&_new_symbols_58920, _new_symbols_58920, _sym_58926);

    /** 		Block_var( sym )*/
    _66Block_var(_sym_58926);

    /** 		if SymTab[sym][S_SCOPE] = SC_UNDEFINED and SymTab[sym][S_FILE_NO] != current_file_no then*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _29881 = (int)*(((s1_ptr)_2)->base + _sym_58926);
    _2 = (int)SEQ_PTR(_29881);
    _29882 = (int)*(((s1_ptr)_2)->base + 4);
    _29881 = NOVALUE;
    if (IS_ATOM_INT(_29882)) {
        _29883 = (_29882 == 9);
    }
    else {
        _29883 = binary_op(EQUALS, _29882, 9);
    }
    _29882 = NOVALUE;
    if (IS_ATOM_INT(_29883)) {
        if (_29883 == 0) {
            goto L14; // [700] 744
        }
    }
    else {
        if (DBL_PTR(_29883)->dbl == 0.0) {
            goto L14; // [700] 744
        }
    }
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _29885 = (int)*(((s1_ptr)_2)->base + _sym_58926);
    _2 = (int)SEQ_PTR(_29885);
    if (!IS_ATOM_INT(_35S_FILE_NO_15913)){
        _29886 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FILE_NO_15913)->dbl));
    }
    else{
        _29886 = (int)*(((s1_ptr)_2)->base + _35S_FILE_NO_15913);
    }
    _29885 = NOVALUE;
    if (IS_ATOM_INT(_29886)) {
        _29887 = (_29886 != _35current_file_no_16244);
    }
    else {
        _29887 = binary_op(NOTEQ, _29886, _35current_file_no_16244);
    }
    _29886 = NOVALUE;
    if (_29887 == 0) {
        DeRef(_29887);
        _29887 = NOVALUE;
        goto L14; // [723] 744
    }
    else {
        if (!IS_ATOM_INT(_29887) && DBL_PTR(_29887)->dbl == 0.0){
            DeRef(_29887);
            _29887 = NOVALUE;
            goto L14; // [723] 744
        }
        DeRef(_29887);
        _29887 = NOVALUE;
    }
    DeRef(_29887);
    _29887 = NOVALUE;

    /** 			SymTab[sym][S_FILE_NO] = current_file_no*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58926 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35S_FILE_NO_15913))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FILE_NO_15913)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _35S_FILE_NO_15913);
    _1 = *(int *)_2;
    *(int *)_2 = _35current_file_no_16244;
    DeRef(_1);
    _29888 = NOVALUE;
L14: 

    /** 		SymTab[sym][S_SCOPE] = scope*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58926 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = _scope_58919;
    DeRef(_1);
    _29890 = NOVALUE;

    /** 		if type_ptr = 0 then*/
    if (_type_ptr_58918 != 0)
    goto L15; // [761] 1096

    /** 			SymTab[sym][S_MODE] = M_CONSTANT*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58926 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = 2;
    DeRef(_1);
    _29893 = NOVALUE;

    /** 			buckets[SymTab[sym][S_HASHVAL]] = SymTab[sym][S_SAMEHASH]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _29895 = (int)*(((s1_ptr)_2)->base + _sym_58926);
    _2 = (int)SEQ_PTR(_29895);
    _29896 = (int)*(((s1_ptr)_2)->base + 11);
    _29895 = NOVALUE;
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _29897 = (int)*(((s1_ptr)_2)->base + _sym_58926);
    _2 = (int)SEQ_PTR(_29897);
    _29898 = (int)*(((s1_ptr)_2)->base + 9);
    _29897 = NOVALUE;
    Ref(_29898);
    _2 = (int)SEQ_PTR(_53buckets_46087);
    if (!IS_ATOM_INT(_29896))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_29896)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _29896);
    _1 = *(int *)_2;
    *(int *)_2 = _29898;
    if( _1 != _29898 ){
        DeRef(_1);
    }
    _29898 = NOVALUE;

    /** 			tok_match(EQUALS)*/
    _39tok_match(3, 0);

    /** 			StartSourceLine(FALSE, , COVERAGE_OVERRIDE)*/
    _41StartSourceLine(_13FALSE_434, 0, 3);

    /** 			emit_opnd(sym)*/
    _41emit_opnd(_sym_58926);

    /** 			Expr()  -- no new symbols can be defined in here*/
    _39Expr();

    /** 			buckets[SymTab[sym][S_HASHVAL]] = sym*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _29899 = (int)*(((s1_ptr)_2)->base + _sym_58926);
    _2 = (int)SEQ_PTR(_29899);
    _29900 = (int)*(((s1_ptr)_2)->base + 11);
    _29899 = NOVALUE;
    _2 = (int)SEQ_PTR(_53buckets_46087);
    if (!IS_ATOM_INT(_29900))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_29900)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _29900);
    _1 = *(int *)_2;
    *(int *)_2 = _sym_58926;
    DeRef(_1);

    /** 			SymTab[sym][S_USAGE] = U_WRITTEN*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58926 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = 2;
    DeRef(_1);
    _29901 = NOVALUE;

    /** 			if TRANSLATE then*/
    if (_35TRANSLATE_15887 == 0)
    {
        goto L16; // [883] 921
    }
    else{
    }

    /** 				SymTab[sym][S_GTYPE] = TYPE_OBJECT*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58926 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 36);
    _1 = *(int *)_2;
    *(int *)_2 = 16;
    DeRef(_1);
    _29903 = NOVALUE;

    /** 				SymTab[sym][S_OBJ] = NOVALUE     -- distinguish from literals*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58926 + ((s1_ptr)_2)->base);
    Ref(_35NOVALUE_16099);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _35NOVALUE_16099;
    DeRef(_1);
    _29905 = NOVALUE;
L16: 

    /** 			valsym = Top()*/
    _valsym_58927 = _41Top();
    if (!IS_ATOM_INT(_valsym_58927)) {
        _1 = (long)(DBL_PTR(_valsym_58927)->dbl);
        DeRefDS(_valsym_58927);
        _valsym_58927 = _1;
    }

    /** 			if valsym > 0 and compare( SymTab[valsym][S_OBJ], NOVALUE ) then*/
    _29908 = (_valsym_58927 > 0);
    if (_29908 == 0) {
        goto L17; // [934] 975
    }
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _29910 = (int)*(((s1_ptr)_2)->base + _valsym_58927);
    _2 = (int)SEQ_PTR(_29910);
    _29911 = (int)*(((s1_ptr)_2)->base + 1);
    _29910 = NOVALUE;
    if (IS_ATOM_INT(_29911) && IS_ATOM_INT(_35NOVALUE_16099)){
        _29912 = (_29911 < _35NOVALUE_16099) ? -1 : (_29911 > _35NOVALUE_16099);
    }
    else{
        _29912 = compare(_29911, _35NOVALUE_16099);
    }
    _29911 = NOVALUE;
    if (_29912 == 0)
    {
        _29912 = NOVALUE;
        goto L17; // [957] 975
    }
    else{
        _29912 = NOVALUE;
    }

    /** 				Assign_Constant( sym )*/
    _39Assign_Constant(_sym_58926);

    /** 				sym = Pop()*/
    _sym_58926 = _41Pop();
    if (!IS_ATOM_INT(_sym_58926)) {
        _1 = (long)(DBL_PTR(_sym_58926)->dbl);
        DeRefDS(_sym_58926);
        _sym_58926 = _1;
    }
    goto L18; // [972] 2248
L17: 

    /** 				emit_op(ASSIGN)*/
    _41emit_op(18);

    /** 				if Last_op() = ASSIGN then*/
    _29914 = _41Last_op();
    if (binary_op_a(NOTEQ, _29914, 18)){
        DeRef(_29914);
        _29914 = NOVALUE;
        goto L19; // [989] 1003
    }
    DeRef(_29914);
    _29914 = NOVALUE;

    /** 					valsym = get_assigned_sym()*/
    _valsym_58927 = _39get_assigned_sym();
    if (!IS_ATOM_INT(_valsym_58927)) {
        _1 = (long)(DBL_PTR(_valsym_58927)->dbl);
        DeRefDS(_valsym_58927);
        _valsym_58927 = _1;
    }
    goto L1A; // [1000] 1011
L19: 

    /** 					valsym = -1*/
    _valsym_58927 = -1;
L1A: 

    /** 				if valsym > 0 and compare( SymTab[valsym][S_OBJ], NOVALUE ) then*/
    _29917 = (_valsym_58927 > 0);
    if (_29917 == 0) {
        goto L1B; // [1017] 1059
    }
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _29919 = (int)*(((s1_ptr)_2)->base + _valsym_58927);
    _2 = (int)SEQ_PTR(_29919);
    _29920 = (int)*(((s1_ptr)_2)->base + 1);
    _29919 = NOVALUE;
    if (IS_ATOM_INT(_29920) && IS_ATOM_INT(_35NOVALUE_16099)){
        _29921 = (_29920 < _35NOVALUE_16099) ? -1 : (_29920 > _35NOVALUE_16099);
    }
    else{
        _29921 = compare(_29920, _35NOVALUE_16099);
    }
    _29920 = NOVALUE;
    if (_29921 == 0)
    {
        _29921 = NOVALUE;
        goto L1B; // [1040] 1059
    }
    else{
        _29921 = NOVALUE;
    }

    /** 					SymTab[sym][S_CODE] = valsym*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58926 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35S_CODE_15929))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_CODE_15929)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _35S_CODE_15929);
    _1 = *(int *)_2;
    *(int *)_2 = _valsym_58927;
    DeRef(_1);
    _29922 = NOVALUE;
L1B: 

    /** 				if TRANSLATE then*/
    if (_35TRANSLATE_15887 == 0)
    {
        goto L18; // [1063] 2248
    }
    else{
    }

    /** 					count += 1*/
    _count_58929 = _count_58929 + 1;

    /** 					if count = 10 then*/
    if (_count_58929 != 10)
    goto L18; // [1074] 2248

    /** 						count = 0*/
    _count_58929 = 0;

    /** 						emit_op( RETURNT )*/
    _41emit_op(34);
    goto L18; // [1093] 2248
L15: 

    /** 		elsif type_ptr = -1 and not is_fwd_ref then*/
    _29926 = (_type_ptr_58918 == -1);
    if (_29926 == 0) {
        goto L1C; // [1102] 2075
    }
    _29928 = (_is_fwd_ref_58934 == 0);
    if (_29928 == 0)
    {
        DeRef(_29928);
        _29928 = NOVALUE;
        goto L1C; // [1110] 2075
    }
    else{
        DeRef(_29928);
        _29928 = NOVALUE;
    }

    /** 			StartSourceLine(FALSE, , COVERAGE_OVERRIDE )*/
    _41StartSourceLine(_13FALSE_434, 0, 3);

    /** 			SymTab[sym][S_MODE] = M_CONSTANT*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58926 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = 2;
    DeRef(_1);
    _29929 = NOVALUE;

    /** 			buckets[SymTab[sym][S_HASHVAL]] = SymTab[sym][S_SAMEHASH]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _29931 = (int)*(((s1_ptr)_2)->base + _sym_58926);
    _2 = (int)SEQ_PTR(_29931);
    _29932 = (int)*(((s1_ptr)_2)->base + 11);
    _29931 = NOVALUE;
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _29933 = (int)*(((s1_ptr)_2)->base + _sym_58926);
    _2 = (int)SEQ_PTR(_29933);
    _29934 = (int)*(((s1_ptr)_2)->base + 9);
    _29933 = NOVALUE;
    Ref(_29934);
    _2 = (int)SEQ_PTR(_53buckets_46087);
    if (!IS_ATOM_INT(_29932))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_29932)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _29932);
    _1 = *(int *)_2;
    *(int *)_2 = _29934;
    if( _1 != _29934 ){
        DeRef(_1);
    }
    _29934 = NOVALUE;

    /** 			tok = next_token()*/
    _0 = _tok_58922;
    _tok_58922 = _39next_token();
    DeRef(_0);

    /** 			emit_opnd(sym)*/
    _41emit_opnd(_sym_58926);

    /** 			if tok[T_ID] = EQUALS then*/
    _2 = (int)SEQ_PTR(_tok_58922);
    _29936 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29936, 3)){
        _29936 = NOVALUE;
        goto L1D; // [1193] 1588
    }
    _29936 = NOVALUE;

    /** 				integer negate = 1*/
    _negate_59213 = 1;

    /** 				tok = next_token()*/
    _0 = _tok_58922;
    _tok_58922 = _39next_token();
    DeRef(_0);

    /** 				if tok[T_ID] = MINUS then*/
    _2 = (int)SEQ_PTR(_tok_58922);
    _29939 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29939, 10)){
        _29939 = NOVALUE;
        goto L1E; // [1217] 1232
    }
    _29939 = NOVALUE;

    /** 					negate = -1*/
    _negate_59213 = -1;

    /** 					tok = next_token()*/
    _0 = _tok_58922;
    _tok_58922 = _39next_token();
    DeRef(_0);
L1E: 

    /** 				if tok[T_ID] = ATOM then*/
    _2 = (int)SEQ_PTR(_tok_58922);
    _29942 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29942, 502)){
        _29942 = NOVALUE;
        goto L1F; // [1242] 1259
    }
    _29942 = NOVALUE;

    /** 					valsym = tok[T_SYM]*/
    _2 = (int)SEQ_PTR(_tok_58922);
    _valsym_58927 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_valsym_58927)){
        _valsym_58927 = (long)DBL_PTR(_valsym_58927)->dbl;
    }
    goto L20; // [1256] 1448
L1F: 

    /** 				elsif tok[T_SYM] > 0 then*/
    _2 = (int)SEQ_PTR(_tok_58922);
    _29945 = (int)*(((s1_ptr)_2)->base + 2);
    if (binary_op_a(LESSEQ, _29945, 0)){
        _29945 = NOVALUE;
        goto L21; // [1267] 1440
    }
    _29945 = NOVALUE;

    /** 					tsym = SymTab[tok[T_SYM]]*/
    _2 = (int)SEQ_PTR(_tok_58922);
    _29947 = (int)*(((s1_ptr)_2)->base + 2);
    DeRef(_tsym_58923);
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!IS_ATOM_INT(_29947)){
        _tsym_58923 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_29947)->dbl));
    }
    else{
        _tsym_58923 = (int)*(((s1_ptr)_2)->base + _29947);
    }
    Ref(_tsym_58923);

    /** 					if tsym[S_MODE] = M_CONSTANT then*/
    _2 = (int)SEQ_PTR(_tsym_58923);
    _29949 = (int)*(((s1_ptr)_2)->base + 3);
    if (binary_op_a(NOTEQ, _29949, 2)){
        _29949 = NOVALUE;
        goto L22; // [1295] 1403
    }
    _29949 = NOVALUE;

    /** 						if length(tsym) >= S_CODE and tsym[S_CODE] then*/
    if (IS_SEQUENCE(_tsym_58923)){
            _29951 = SEQ_PTR(_tsym_58923)->length;
    }
    else {
        _29951 = 1;
    }
    if (IS_ATOM_INT(_35S_CODE_15929)) {
        _29952 = (_29951 >= _35S_CODE_15929);
    }
    else {
        _29952 = binary_op(GREATEREQ, _29951, _35S_CODE_15929);
    }
    _29951 = NOVALUE;
    if (IS_ATOM_INT(_29952)) {
        if (_29952 == 0) {
            goto L23; // [1310] 1337
        }
    }
    else {
        if (DBL_PTR(_29952)->dbl == 0.0) {
            goto L23; // [1310] 1337
        }
    }
    _2 = (int)SEQ_PTR(_tsym_58923);
    if (!IS_ATOM_INT(_35S_CODE_15929)){
        _29954 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_CODE_15929)->dbl));
    }
    else{
        _29954 = (int)*(((s1_ptr)_2)->base + _35S_CODE_15929);
    }
    if (_29954 == 0) {
        _29954 = NOVALUE;
        goto L23; // [1321] 1337
    }
    else {
        if (!IS_ATOM_INT(_29954) && DBL_PTR(_29954)->dbl == 0.0){
            _29954 = NOVALUE;
            goto L23; // [1321] 1337
        }
        _29954 = NOVALUE;
    }
    _29954 = NOVALUE;

    /** 							valsym = tsym[S_CODE]*/
    _2 = (int)SEQ_PTR(_tsym_58923);
    if (!IS_ATOM_INT(_35S_CODE_15929)){
        _valsym_58927 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_CODE_15929)->dbl));
    }
    else{
        _valsym_58927 = (int)*(((s1_ptr)_2)->base + _35S_CODE_15929);
    }
    if (!IS_ATOM_INT(_valsym_58927)){
        _valsym_58927 = (long)DBL_PTR(_valsym_58927)->dbl;
    }
    goto L20; // [1334] 1448
L23: 

    /** 						elsif not equal( tsym[S_OBJ], NOVALUE ) then*/
    _2 = (int)SEQ_PTR(_tsym_58923);
    _29956 = (int)*(((s1_ptr)_2)->base + 1);
    if (_29956 == _35NOVALUE_16099)
    _29957 = 1;
    else if (IS_ATOM_INT(_29956) && IS_ATOM_INT(_35NOVALUE_16099))
    _29957 = 0;
    else
    _29957 = (compare(_29956, _35NOVALUE_16099) == 0);
    _29956 = NOVALUE;
    if (_29957 != 0)
    goto L24; // [1351] 1392
    _29957 = NOVALUE;

    /** 							if integer(tsym[S_OBJ]) then*/
    _2 = (int)SEQ_PTR(_tsym_58923);
    _29959 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_29959))
    _29960 = 1;
    else if (IS_ATOM_DBL(_29959))
    _29960 = IS_ATOM_INT(DoubleToInt(_29959));
    else
    _29960 = 0;
    _29959 = NOVALUE;
    if (_29960 == 0)
    {
        _29960 = NOVALUE;
        goto L25; // [1365] 1381
    }
    else{
        _29960 = NOVALUE;
    }

    /** 								valsym = tok[T_SYM]*/
    _2 = (int)SEQ_PTR(_tok_58922);
    _valsym_58927 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_valsym_58927)){
        _valsym_58927 = (long)DBL_PTR(_valsym_58927)->dbl;
    }
    goto L20; // [1378] 1448
L25: 

    /** 								CompileErr(30)*/
    RefDS(_22023);
    _44CompileErr(30, _22023, 0);
    goto L20; // [1389] 1448
L24: 

    /** 							CompileErr(70)*/
    RefDS(_22023);
    _44CompileErr(70, _22023, 0);
    goto L20; // [1400] 1448
L22: 

    /** 					elsif tsym[S_OBJ] = NOVALUE then*/
    _2 = (int)SEQ_PTR(_tsym_58923);
    _29962 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29962, _35NOVALUE_16099)){
        _29962 = NOVALUE;
        goto L26; // [1413] 1429
    }
    _29962 = NOVALUE;

    /** 						CompileErr(ENUM_FWD_REFERENCES_NOT_SUPPORTED)*/
    RefDS(_22023);
    _44CompileErr(331, _22023, 0);
    goto L20; // [1426] 1448
L26: 

    /** 						CompileErr(99)*/
    RefDS(_22023);
    _44CompileErr(99, _22023, 0);
    goto L20; // [1437] 1448
L21: 

    /** 						CompileErr(99)*/
    RefDS(_22023);
    _44CompileErr(99, _22023, 0);
L20: 

    /** 				valsym = tok[T_SYM]*/
    _2 = (int)SEQ_PTR(_tok_58922);
    _valsym_58927 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_valsym_58927)){
        _valsym_58927 = (long)DBL_PTR(_valsym_58927)->dbl;
    }

    /** 				if not atom( SymTab[valsym][S_OBJ] ) and tsym[S_SCOPE] != SC_UNDEFINED then*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _29965 = (int)*(((s1_ptr)_2)->base + _valsym_58927);
    _2 = (int)SEQ_PTR(_29965);
    _29966 = (int)*(((s1_ptr)_2)->base + 1);
    _29965 = NOVALUE;
    _29967 = IS_ATOM(_29966);
    _29966 = NOVALUE;
    _29968 = (_29967 == 0);
    _29967 = NOVALUE;
    if (_29968 == 0) {
        goto L27; // [1478] 1508
    }
    _2 = (int)SEQ_PTR(_tsym_58923);
    _29970 = (int)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_29970)) {
        _29971 = (_29970 != 9);
    }
    else {
        _29971 = binary_op(NOTEQ, _29970, 9);
    }
    _29970 = NOVALUE;
    if (_29971 == 0) {
        DeRef(_29971);
        _29971 = NOVALUE;
        goto L27; // [1497] 1508
    }
    else {
        if (!IS_ATOM_INT(_29971) && DBL_PTR(_29971)->dbl == 0.0){
            DeRef(_29971);
            _29971 = NOVALUE;
            goto L27; // [1497] 1508
        }
        DeRef(_29971);
        _29971 = NOVALUE;
    }
    DeRef(_29971);
    _29971 = NOVALUE;

    /** 					CompileErr(84)*/
    RefDS(_22023);
    _44CompileErr(84, _22023, 0);
L27: 

    /** 				val = SymTab[valsym][S_OBJ] * negate*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _29972 = (int)*(((s1_ptr)_2)->base + _valsym_58927);
    _2 = (int)SEQ_PTR(_29972);
    _29973 = (int)*(((s1_ptr)_2)->base + 1);
    _29972 = NOVALUE;
    DeRef(_val_58930);
    if (IS_ATOM_INT(_29973)) {
        if (_29973 == (short)_29973 && _negate_59213 <= INT15 && _negate_59213 >= -INT15)
        _val_58930 = _29973 * _negate_59213;
        else
        _val_58930 = NewDouble(_29973 * (double)_negate_59213);
    }
    else {
        _val_58930 = binary_op(MULTIPLY, _29973, _negate_59213);
    }
    _29973 = NOVALUE;

    /** 				if integer(val) then*/
    if (IS_ATOM_INT(_val_58930))
    _29975 = 1;
    else if (IS_ATOM_DBL(_val_58930))
    _29975 = IS_ATOM_INT(DoubleToInt(_val_58930));
    else
    _29975 = 0;
    if (_29975 == 0)
    {
        _29975 = NOVALUE;
        goto L28; // [1531] 1546
    }
    else{
        _29975 = NOVALUE;
    }

    /** 					Push(NewIntSym(val))*/
    Ref(_val_58930);
    _29976 = _53NewIntSym(_val_58930);
    _41Push(_29976);
    _29976 = NOVALUE;
    goto L29; // [1543] 1556
L28: 

    /** 					Push(NewDoubleSym(val))*/
    Ref(_val_58930);
    _29977 = _53NewDoubleSym(_val_58930);
    _41Push(_29977);
    _29977 = NOVALUE;
L29: 

    /** 				usedval = val*/
    Ref(_val_58930);
    DeRef(_usedval_58931);
    _usedval_58931 = _val_58930;

    /** 				if deltafunc = '+' then*/
    if (_deltafunc_58932 != 43)
    goto L2A; // [1563] 1576

    /** 					val += delta*/
    _0 = _val_58930;
    if (IS_ATOM_INT(_val_58930) && IS_ATOM_INT(_delta_58933)) {
        _val_58930 = _val_58930 + _delta_58933;
        if ((long)((unsigned long)_val_58930 + (unsigned long)HIGH_BITS) >= 0) 
        _val_58930 = NewDouble((double)_val_58930);
    }
    else {
        if (IS_ATOM_INT(_val_58930)) {
            _val_58930 = NewDouble((double)_val_58930 + DBL_PTR(_delta_58933)->dbl);
        }
        else {
            if (IS_ATOM_INT(_delta_58933)) {
                _val_58930 = NewDouble(DBL_PTR(_val_58930)->dbl + (double)_delta_58933);
            }
            else
            _val_58930 = NewDouble(DBL_PTR(_val_58930)->dbl + DBL_PTR(_delta_58933)->dbl);
        }
    }
    DeRef(_0);
    goto L2B; // [1573] 1583
L2A: 

    /** 					val *= delta*/
    _0 = _val_58930;
    if (IS_ATOM_INT(_val_58930) && IS_ATOM_INT(_delta_58933)) {
        if (_val_58930 == (short)_val_58930 && _delta_58933 <= INT15 && _delta_58933 >= -INT15)
        _val_58930 = _val_58930 * _delta_58933;
        else
        _val_58930 = NewDouble(_val_58930 * (double)_delta_58933);
    }
    else {
        if (IS_ATOM_INT(_val_58930)) {
            _val_58930 = NewDouble((double)_val_58930 * DBL_PTR(_delta_58933)->dbl);
        }
        else {
            if (IS_ATOM_INT(_delta_58933)) {
                _val_58930 = NewDouble(DBL_PTR(_val_58930)->dbl * (double)_delta_58933);
            }
            else
            _val_58930 = NewDouble(DBL_PTR(_val_58930)->dbl * DBL_PTR(_delta_58933)->dbl);
        }
    }
    DeRef(_0);
L2B: 
    goto L2C; // [1585] 1658
L1D: 

    /** 				putback(tok)*/
    Ref(_tok_58922);
    _39putback(_tok_58922);

    /** 				if integer(val) then*/
    if (IS_ATOM_INT(_val_58930))
    _29981 = 1;
    else if (IS_ATOM_DBL(_val_58930))
    _29981 = IS_ATOM_INT(DoubleToInt(_val_58930));
    else
    _29981 = 0;
    if (_29981 == 0)
    {
        _29981 = NOVALUE;
        goto L2D; // [1598] 1613
    }
    else{
        _29981 = NOVALUE;
    }

    /** 					Push(NewIntSym(val))*/
    Ref(_val_58930);
    _29982 = _53NewIntSym(_val_58930);
    _41Push(_29982);
    _29982 = NOVALUE;
    goto L2E; // [1610] 1623
L2D: 

    /** 					Push(NewDoubleSym(val))*/
    Ref(_val_58930);
    _29983 = _53NewDoubleSym(_val_58930);
    _41Push(_29983);
    _29983 = NOVALUE;
L2E: 

    /** 				usedval = val*/
    Ref(_val_58930);
    DeRef(_usedval_58931);
    _usedval_58931 = _val_58930;

    /** 				if deltafunc = '+' then*/
    if (_deltafunc_58932 != 43)
    goto L2F; // [1630] 1643

    /** 					val += delta*/
    _0 = _val_58930;
    if (IS_ATOM_INT(_val_58930) && IS_ATOM_INT(_delta_58933)) {
        _val_58930 = _val_58930 + _delta_58933;
        if ((long)((unsigned long)_val_58930 + (unsigned long)HIGH_BITS) >= 0) 
        _val_58930 = NewDouble((double)_val_58930);
    }
    else {
        if (IS_ATOM_INT(_val_58930)) {
            _val_58930 = NewDouble((double)_val_58930 + DBL_PTR(_delta_58933)->dbl);
        }
        else {
            if (IS_ATOM_INT(_delta_58933)) {
                _val_58930 = NewDouble(DBL_PTR(_val_58930)->dbl + (double)_delta_58933);
            }
            else
            _val_58930 = NewDouble(DBL_PTR(_val_58930)->dbl + DBL_PTR(_delta_58933)->dbl);
        }
    }
    DeRef(_0);
    goto L30; // [1640] 1650
L2F: 

    /** 					val *= delta*/
    _0 = _val_58930;
    if (IS_ATOM_INT(_val_58930) && IS_ATOM_INT(_delta_58933)) {
        if (_val_58930 == (short)_val_58930 && _delta_58933 <= INT15 && _delta_58933 >= -INT15)
        _val_58930 = _val_58930 * _delta_58933;
        else
        _val_58930 = NewDouble(_val_58930 * (double)_delta_58933);
    }
    else {
        if (IS_ATOM_INT(_val_58930)) {
            _val_58930 = NewDouble((double)_val_58930 * DBL_PTR(_delta_58933)->dbl);
        }
        else {
            if (IS_ATOM_INT(_delta_58933)) {
                _val_58930 = NewDouble(DBL_PTR(_val_58930)->dbl * (double)_delta_58933);
            }
            else
            _val_58930 = NewDouble(DBL_PTR(_val_58930)->dbl * DBL_PTR(_delta_58933)->dbl);
        }
    }
    DeRef(_0);
L30: 

    /** 				valsym = 0*/
    _valsym_58927 = 0;
L2C: 

    /** 			buckets[SymTab[sym][S_HASHVAL]] = sym*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _29987 = (int)*(((s1_ptr)_2)->base + _sym_58926);
    _2 = (int)SEQ_PTR(_29987);
    _29988 = (int)*(((s1_ptr)_2)->base + 11);
    _29987 = NOVALUE;
    _2 = (int)SEQ_PTR(_53buckets_46087);
    if (!IS_ATOM_INT(_29988))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_29988)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _29988);
    _1 = *(int *)_2;
    *(int *)_2 = _sym_58926;
    DeRef(_1);

    /** 			SymTab[sym][S_USAGE] = U_WRITTEN*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58926 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = 2;
    DeRef(_1);
    _29989 = NOVALUE;

    /** 			if TRANSLATE then*/
    if (_35TRANSLATE_15887 == 0)
    {
        goto L31; // [1699] 1737
    }
    else{
    }

    /** 				SymTab[sym][S_GTYPE] = TYPE_OBJECT*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58926 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 36);
    _1 = *(int *)_2;
    *(int *)_2 = 16;
    DeRef(_1);
    _29991 = NOVALUE;

    /** 				SymTab[sym][S_OBJ] = NOVALUE     -- distinguish from literals*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58926 + ((s1_ptr)_2)->base);
    Ref(_35NOVALUE_16099);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _35NOVALUE_16099;
    DeRef(_1);
    _29993 = NOVALUE;
L31: 

    /** 			if valsym < 0 then*/
    if (_valsym_58927 >= 0)
    goto L32; // [1739] 1744
L32: 

    /** 			if valsym and compare( SymTab[valsym][S_OBJ], NOVALUE ) then*/
    if (_valsym_58927 == 0) {
        goto L33; // [1746] 1926
    }
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _29997 = (int)*(((s1_ptr)_2)->base + _valsym_58927);
    _2 = (int)SEQ_PTR(_29997);
    _29998 = (int)*(((s1_ptr)_2)->base + 1);
    _29997 = NOVALUE;
    if (IS_ATOM_INT(_29998) && IS_ATOM_INT(_35NOVALUE_16099)){
        _29999 = (_29998 < _35NOVALUE_16099) ? -1 : (_29998 > _35NOVALUE_16099);
    }
    else{
        _29999 = compare(_29998, _35NOVALUE_16099);
    }
    _29998 = NOVALUE;
    if (_29999 == 0)
    {
        _29999 = NOVALUE;
        goto L33; // [1769] 1926
    }
    else{
        _29999 = NOVALUE;
    }

    /** 				SymTab[sym][S_CODE] = valsym*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58926 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35S_CODE_15929))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_CODE_15929)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _35S_CODE_15929);
    _1 = *(int *)_2;
    *(int *)_2 = _valsym_58927;
    DeRef(_1);
    _30000 = NOVALUE;

    /** 				SymTab[sym][S_OBJ]  = usedval*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58926 + ((s1_ptr)_2)->base);
    Ref(_usedval_58931);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _usedval_58931;
    DeRef(_1);
    _30002 = NOVALUE;

    /** 				if TRANSLATE then*/
    if (_35TRANSLATE_15887 == 0)
    {
        goto L34; // [1808] 2058
    }
    else{
    }

    /** 					SymTab[sym][S_GTYPE] = SymTab[valsym][S_GTYPE]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58926 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _30006 = (int)*(((s1_ptr)_2)->base + _valsym_58927);
    _2 = (int)SEQ_PTR(_30006);
    _30007 = (int)*(((s1_ptr)_2)->base + 36);
    _30006 = NOVALUE;
    Ref(_30007);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 36);
    _1 = *(int *)_2;
    *(int *)_2 = _30007;
    if( _1 != _30007 ){
        DeRef(_1);
    }
    _30007 = NOVALUE;
    _30004 = NOVALUE;

    /** 					SymTab[sym][S_SEQ_ELEM] = SymTab[valsym][S_SEQ_ELEM]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58926 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _30010 = (int)*(((s1_ptr)_2)->base + _valsym_58927);
    _2 = (int)SEQ_PTR(_30010);
    _30011 = (int)*(((s1_ptr)_2)->base + 33);
    _30010 = NOVALUE;
    Ref(_30011);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 33);
    _1 = *(int *)_2;
    *(int *)_2 = _30011;
    if( _1 != _30011 ){
        DeRef(_1);
    }
    _30011 = NOVALUE;
    _30008 = NOVALUE;

    /** 					SymTab[sym][S_OBJ_MIN] = usedval*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58926 + ((s1_ptr)_2)->base);
    Ref(_usedval_58931);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 30);
    _1 = *(int *)_2;
    *(int *)_2 = _usedval_58931;
    DeRef(_1);
    _30012 = NOVALUE;

    /** 					SymTab[sym][S_OBJ_MAX] = usedval*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58926 + ((s1_ptr)_2)->base);
    Ref(_usedval_58931);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 31);
    _1 = *(int *)_2;
    *(int *)_2 = _usedval_58931;
    DeRef(_1);
    _30014 = NOVALUE;

    /** 					SymTab[sym][S_SEQ_LEN] = SymTab[valsym][S_SEQ_LEN]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58926 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _30018 = (int)*(((s1_ptr)_2)->base + _valsym_58927);
    _2 = (int)SEQ_PTR(_30018);
    _30019 = (int)*(((s1_ptr)_2)->base + 32);
    _30018 = NOVALUE;
    Ref(_30019);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 32);
    _1 = *(int *)_2;
    *(int *)_2 = _30019;
    if( _1 != _30019 ){
        DeRef(_1);
    }
    _30019 = NOVALUE;
    _30016 = NOVALUE;
    goto L34; // [1923] 2058
L33: 

    /** 				SymTab[sym][S_OBJ] = usedval*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58926 + ((s1_ptr)_2)->base);
    Ref(_usedval_58931);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _usedval_58931;
    DeRef(_1);
    _30020 = NOVALUE;

    /** 				if TRANSLATE then*/
    if (_35TRANSLATE_15887 == 0)
    {
        goto L35; // [1947] 2057
    }
    else{
    }

    /** 					if integer( usedval ) then*/
    if (IS_ATOM_INT(_usedval_58931))
    _30022 = 1;
    else if (IS_ATOM_DBL(_usedval_58931))
    _30022 = IS_ATOM_INT(DoubleToInt(_usedval_58931));
    else
    _30022 = 0;
    if (_30022 == 0)
    {
        _30022 = NOVALUE;
        goto L36; // [1955] 1978
    }
    else{
        _30022 = NOVALUE;
    }

    /** 						SymTab[sym][S_GTYPE] = TYPE_INTEGER*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58926 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 36);
    _1 = *(int *)_2;
    *(int *)_2 = 1;
    DeRef(_1);
    _30023 = NOVALUE;
    goto L37; // [1975] 1996
L36: 

    /** 						SymTab[sym][S_GTYPE] = TYPE_DOUBLE*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58926 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 36);
    _1 = *(int *)_2;
    *(int *)_2 = 2;
    DeRef(_1);
    _30025 = NOVALUE;
L37: 

    /** 					SymTab[sym][S_SEQ_ELEM] = 0*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58926 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 33);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _30027 = NOVALUE;

    /** 					SymTab[sym][S_OBJ_MIN] = usedval*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58926 + ((s1_ptr)_2)->base);
    Ref(_usedval_58931);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 30);
    _1 = *(int *)_2;
    *(int *)_2 = _usedval_58931;
    DeRef(_1);
    _30029 = NOVALUE;

    /** 					SymTab[sym][S_OBJ_MAX] = usedval*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58926 + ((s1_ptr)_2)->base);
    Ref(_usedval_58931);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 31);
    _1 = *(int *)_2;
    *(int *)_2 = _usedval_58931;
    DeRef(_1);
    _30031 = NOVALUE;

    /** 					SymTab[sym][S_SEQ_LEN] = 0 --SymTab[valsym][S_SEQ_LEN]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58926 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 32);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _30033 = NOVALUE;
L35: 
L34: 

    /** 			valsym = Pop()*/
    _valsym_58927 = _41Pop();
    if (!IS_ATOM_INT(_valsym_58927)) {
        _1 = (long)(DBL_PTR(_valsym_58927)->dbl);
        DeRefDS(_valsym_58927);
        _valsym_58927 = _1;
    }

    /** 			valsym = Pop()*/
    _valsym_58927 = _41Pop();
    if (!IS_ATOM_INT(_valsym_58927)) {
        _1 = (long)(DBL_PTR(_valsym_58927)->dbl);
        DeRefDS(_valsym_58927);
        _valsym_58927 = _1;
    }
    goto L18; // [2072] 2248
L1C: 

    /** 			SymTab[sym][S_MODE] = M_NORMAL*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58926 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = 1;
    DeRef(_1);
    _30037 = NOVALUE;

    /** 			if type_ptr > 0 and SymTab[type_ptr][S_TOKEN] = OBJECT then*/
    _30039 = (_type_ptr_58918 > 0);
    if (_30039 == 0) {
        goto L38; // [2098] 2144
    }
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _30041 = (int)*(((s1_ptr)_2)->base + _type_ptr_58918);
    _2 = (int)SEQ_PTR(_30041);
    if (!IS_ATOM_INT(_35S_TOKEN_15922)){
        _30042 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TOKEN_15922)->dbl));
    }
    else{
        _30042 = (int)*(((s1_ptr)_2)->base + _35S_TOKEN_15922);
    }
    _30041 = NOVALUE;
    if (IS_ATOM_INT(_30042)) {
        _30043 = (_30042 == 415);
    }
    else {
        _30043 = binary_op(EQUALS, _30042, 415);
    }
    _30042 = NOVALUE;
    if (_30043 == 0) {
        DeRef(_30043);
        _30043 = NOVALUE;
        goto L38; // [2121] 2144
    }
    else {
        if (!IS_ATOM_INT(_30043) && DBL_PTR(_30043)->dbl == 0.0){
            DeRef(_30043);
            _30043 = NOVALUE;
            goto L38; // [2121] 2144
        }
        DeRef(_30043);
        _30043 = NOVALUE;
    }
    DeRef(_30043);
    _30043 = NOVALUE;

    /** 				SymTab[sym][S_VTYPE] = object_type*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58926 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 15);
    _1 = *(int *)_2;
    *(int *)_2 = _53object_type_46091;
    DeRef(_1);
    _30044 = NOVALUE;
    goto L39; // [2141] 2173
L38: 

    /** 				SymTab[sym][S_VTYPE] = type_ptr*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58926 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 15);
    _1 = *(int *)_2;
    *(int *)_2 = _type_ptr_58918;
    DeRef(_1);
    _30046 = NOVALUE;

    /** 				if type_ptr < 0 then*/
    if (_type_ptr_58918 >= 0)
    goto L3A; // [2161] 2172

    /** 					register_forward_type( sym, type_ptr )*/
    _38register_forward_type(_sym_58926, _type_ptr_58918);
L3A: 
L39: 

    /** 			if TRANSLATE then*/
    if (_35TRANSLATE_15887 == 0)
    {
        goto L3B; // [2177] 2200
    }
    else{
    }

    /** 				SymTab[sym][S_GTYPE] = CompileType(type_ptr)*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58926 + ((s1_ptr)_2)->base);
    _30051 = _39CompileType(_type_ptr_58918);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 36);
    _1 = *(int *)_2;
    *(int *)_2 = _30051;
    if( _1 != _30051 ){
        DeRef(_1);
    }
    _30051 = NOVALUE;
    _30049 = NOVALUE;
L3B: 

    /** 	   		tok = next_token()*/
    _0 = _tok_58922;
    _tok_58922 = _39next_token();
    DeRef(_0);

    /**    			putback(tok)*/
    Ref(_tok_58922);
    _39putback(_tok_58922);

    /** 	   		if tok[T_ID] = EQUALS then -- assign on declare*/
    _2 = (int)SEQ_PTR(_tok_58922);
    _30053 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30053, 3)){
        _30053 = NOVALUE;
        goto L3C; // [2220] 2247
    }
    _30053 = NOVALUE;

    /** 	   			StartSourceLine( FALSE, , COVERAGE_OVERRIDE )*/
    _41StartSourceLine(_13FALSE_434, 0, 3);

    /** 	   			Assignment({VARIABLE,sym})*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -100;
    ((int *)_2)[2] = _sym_58926;
    _30055 = MAKE_SEQ(_1);
    _39Assignment(_30055);
    _30055 = NOVALUE;
L3C: 
L18: 

    /** 		tok = next_token()*/
    _0 = _tok_58922;
    _tok_58922 = _39next_token();
    DeRef(_0);

    /** 		if tok[T_ID] != COMMA then*/
    _2 = (int)SEQ_PTR(_tok_58922);
    _30057 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _30057, -30)){
        _30057 = NOVALUE;
        goto L3D; // [2263] 2272
    }
    _30057 = NOVALUE;

    /** 			exit*/
    goto LD; // [2269] 2282
L3D: 

    /** 		prevtok = tok*/
    Ref(_tok_58922);
    DeRef(_prevtok_58924);
    _prevtok_58924 = _tok_58922;

    /** 	end while*/
    goto LC; // [2279] 437
LD: 

    /** 	putback(tok)*/
    Ref(_tok_58922);
    _39putback(_tok_58922);

    /** 	return new_symbols*/
    DeRef(_tok_58922);
    DeRef(_tsym_58923);
    DeRef(_prevtok_58924);
    DeRef(_val_58930);
    DeRef(_usedval_58931);
    DeRef(_delta_58933);
    DeRef(_29818);
    _29818 = NOVALUE;
    _29845 = NOVALUE;
    _29896 = NOVALUE;
    DeRef(_29883);
    _29883 = NOVALUE;
    _29900 = NOVALUE;
    DeRef(_29908);
    _29908 = NOVALUE;
    DeRef(_29917);
    _29917 = NOVALUE;
    DeRef(_29926);
    _29926 = NOVALUE;
    _29932 = NOVALUE;
    _29947 = NOVALUE;
    DeRef(_29952);
    _29952 = NOVALUE;
    DeRef(_29968);
    _29968 = NOVALUE;
    _29988 = NOVALUE;
    DeRef(_30039);
    _30039 = NOVALUE;
    return _new_symbols_58920;
    ;
}


void _39Private_declaration(int _type_sym_59495)
{
    int _tok_59497 = NOVALUE;
    int _sym_59499 = NOVALUE;
    int _31644 = NOVALUE;
    int _31643 = NOVALUE;
    int _31642 = NOVALUE;
    int _30083 = NOVALUE;
    int _30081 = NOVALUE;
    int _30079 = NOVALUE;
    int _30077 = NOVALUE;
    int _30075 = NOVALUE;
    int _30073 = NOVALUE;
    int _30071 = NOVALUE;
    int _30068 = NOVALUE;
    int _30066 = NOVALUE;
    int _30065 = NOVALUE;
    int _30062 = NOVALUE;
    int _30060 = NOVALUE;
    int _30059 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_type_sym_59495)) {
        _1 = (long)(DBL_PTR(_type_sym_59495)->dbl);
        DeRefDS(_type_sym_59495);
        _type_sym_59495 = _1;
    }

    /** 	if SymTab[type_sym][S_SCOPE] = SC_UNDEFINED then*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _30059 = (int)*(((s1_ptr)_2)->base + _type_sym_59495);
    _2 = (int)SEQ_PTR(_30059);
    _30060 = (int)*(((s1_ptr)_2)->base + 4);
    _30059 = NOVALUE;
    if (binary_op_a(NOTEQ, _30060, 9)){
        _30060 = NOVALUE;
        goto L1; // [19] 47
    }
    _30060 = NOVALUE;

    /** 		Hide( type_sym )*/
    _53Hide(_type_sym_59495);

    /** 		type_sym = -new_forward_reference( TYPE, type_sym )*/
    _31644 = 504;
    _30062 = _38new_forward_reference(504, _type_sym_59495, 504);
    _31644 = NOVALUE;
    if (IS_ATOM_INT(_30062)) {
        if ((unsigned long)_30062 == 0xC0000000)
        _type_sym_59495 = (int)NewDouble((double)-0xC0000000);
        else
        _type_sym_59495 = - _30062;
    }
    else {
        _type_sym_59495 = unary_op(UMINUS, _30062);
    }
    DeRef(_30062);
    _30062 = NOVALUE;
    if (!IS_ATOM_INT(_type_sym_59495)) {
        _1 = (long)(DBL_PTR(_type_sym_59495)->dbl);
        DeRefDS(_type_sym_59495);
        _type_sym_59495 = _1;
    }
L1: 

    /** 	while TRUE do*/
L2: 
    if (_13TRUE_436 == 0)
    {
        goto L3; // [54] 255
    }
    else{
    }

    /** 		tok = next_token()*/
    _0 = _tok_59497;
    _tok_59497 = _39next_token();
    DeRef(_0);

    /** 		if not find(tok[T_ID], ID_TOKS) then*/
    _2 = (int)SEQ_PTR(_tok_59497);
    _30065 = (int)*(((s1_ptr)_2)->base + 1);
    _30066 = find_from(_30065, _37ID_TOKS_15876, 1);
    _30065 = NOVALUE;
    if (_30066 != 0)
    goto L4; // [77] 88
    _30066 = NOVALUE;

    /** 			CompileErr(24)*/
    RefDS(_22023);
    _44CompileErr(24, _22023, 0);
L4: 

    /** 		sym = SetPrivateScope(tok[T_SYM], type_sym, param_num)*/
    _2 = (int)SEQ_PTR(_tok_59497);
    _30068 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_30068);
    _sym_59499 = _39SetPrivateScope(_30068, _type_sym_59495, _39param_num_54126);
    _30068 = NOVALUE;
    if (!IS_ATOM_INT(_sym_59499)) {
        _1 = (long)(DBL_PTR(_sym_59499)->dbl);
        DeRefDS(_sym_59499);
        _sym_59499 = _1;
    }

    /** 		param_num += 1*/
    _39param_num_54126 = _39param_num_54126 + 1;

    /** 		if TRANSLATE then*/
    if (_35TRANSLATE_15887 == 0)
    {
        goto L5; // [118] 141
    }
    else{
    }

    /** 			SymTab[sym][S_GTYPE] = CompileType(type_sym)*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_59499 + ((s1_ptr)_2)->base);
    _30073 = _39CompileType(_type_sym_59495);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 36);
    _1 = *(int *)_2;
    *(int *)_2 = _30073;
    if( _1 != _30073 ){
        DeRef(_1);
    }
    _30073 = NOVALUE;
    _30071 = NOVALUE;
L5: 

    /**    		tok = next_token()*/
    _0 = _tok_59497;
    _tok_59497 = _39next_token();
    DeRef(_0);

    /**    		if tok[T_ID] = EQUALS then -- assign on declare*/
    _2 = (int)SEQ_PTR(_tok_59497);
    _30075 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30075, 3)){
        _30075 = NOVALUE;
        goto L6; // [156] 231
    }
    _30075 = NOVALUE;

    /** 		    putback(tok)*/
    Ref(_tok_59497);
    _39putback(_tok_59497);

    /** 		    StartSourceLine( TRUE )*/
    _41StartSourceLine(_13TRUE_436, 0, 2);

    /** 		    Assignment({VARIABLE,sym})*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -100;
    ((int *)_2)[2] = _sym_59499;
    _30077 = MAKE_SEQ(_1);
    _39Assignment(_30077);
    _30077 = NOVALUE;

    /** 			tok = next_token()*/
    _0 = _tok_59497;
    _tok_59497 = _39next_token();
    DeRef(_0);

    /** 			if tok[T_ID]=IGNORED then*/
    _2 = (int)SEQ_PTR(_tok_59497);
    _30079 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30079, 509)){
        _30079 = NOVALUE;
        goto L7; // [200] 230
    }
    _30079 = NOVALUE;

    /** 				tok = keyfind(tok[T_SYM],-1)*/
    _2 = (int)SEQ_PTR(_tok_59497);
    _30081 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_30081);
    DeRef(_31642);
    _31642 = _30081;
    _31643 = _53hashfn(_31642);
    _31642 = NOVALUE;
    Ref(_30081);
    _0 = _tok_59497;
    _tok_59497 = _53keyfind(_30081, -1, _35current_file_no_16244, 0, _31643);
    DeRef(_0);
    _30081 = NOVALUE;
    _31643 = NOVALUE;
L7: 
L6: 

    /** 		if tok[T_ID] != COMMA then*/
    _2 = (int)SEQ_PTR(_tok_59497);
    _30083 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _30083, -30)){
        _30083 = NOVALUE;
        goto L2; // [241] 52
    }
    _30083 = NOVALUE;

    /** 			exit*/
    goto L3; // [247] 255

    /** 	end while*/
    goto L2; // [252] 52
L3: 

    /** 	putback(tok)*/
    Ref(_tok_59497);
    _39putback(_tok_59497);

    /** end procedure*/
    DeRef(_tok_59497);
    return;
    ;
}


void _39Procedure_call(int _tok_59561)
{
    int _n_59562 = NOVALUE;
    int _scope_59563 = NOVALUE;
    int _opcode_59564 = NOVALUE;
    int _temp_tok_59566 = NOVALUE;
    int _s_59568 = NOVALUE;
    int _sub_59569 = NOVALUE;
    int _30119 = NOVALUE;
    int _30114 = NOVALUE;
    int _30113 = NOVALUE;
    int _30112 = NOVALUE;
    int _30111 = NOVALUE;
    int _30110 = NOVALUE;
    int _30109 = NOVALUE;
    int _30108 = NOVALUE;
    int _30107 = NOVALUE;
    int _30106 = NOVALUE;
    int _30105 = NOVALUE;
    int _30104 = NOVALUE;
    int _30102 = NOVALUE;
    int _30101 = NOVALUE;
    int _30100 = NOVALUE;
    int _30099 = NOVALUE;
    int _30098 = NOVALUE;
    int _30097 = NOVALUE;
    int _30096 = NOVALUE;
    int _30094 = NOVALUE;
    int _30093 = NOVALUE;
    int _30092 = NOVALUE;
    int _30090 = NOVALUE;
    int _30088 = NOVALUE;
    int _30086 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	tok_match(LEFT_ROUND)*/
    _39tok_match(-26, 0);

    /** 	s = tok[T_SYM]*/
    _2 = (int)SEQ_PTR(_tok_59561);
    _s_59568 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_59568)){
        _s_59568 = (long)DBL_PTR(_s_59568)->dbl;
    }

    /** 	sub=s*/
    _sub_59569 = _s_59568;

    /** 	n = SymTab[s][S_NUM_ARGS]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _30086 = (int)*(((s1_ptr)_2)->base + _s_59568);
    _2 = (int)SEQ_PTR(_30086);
    if (!IS_ATOM_INT(_35S_NUM_ARGS_15968)){
        _n_59562 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NUM_ARGS_15968)->dbl));
    }
    else{
        _n_59562 = (int)*(((s1_ptr)_2)->base + _35S_NUM_ARGS_15968);
    }
    if (!IS_ATOM_INT(_n_59562)){
        _n_59562 = (long)DBL_PTR(_n_59562)->dbl;
    }
    _30086 = NOVALUE;

    /** 	scope = SymTab[s][S_SCOPE]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _30088 = (int)*(((s1_ptr)_2)->base + _s_59568);
    _2 = (int)SEQ_PTR(_30088);
    _scope_59563 = (int)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_scope_59563)){
        _scope_59563 = (long)DBL_PTR(_scope_59563)->dbl;
    }
    _30088 = NOVALUE;

    /** 	opcode = SymTab[s][S_OPCODE]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _30090 = (int)*(((s1_ptr)_2)->base + _s_59568);
    _2 = (int)SEQ_PTR(_30090);
    _opcode_59564 = (int)*(((s1_ptr)_2)->base + 21);
    if (!IS_ATOM_INT(_opcode_59564)){
        _opcode_59564 = (long)DBL_PTR(_opcode_59564)->dbl;
    }
    _30090 = NOVALUE;

    /** 	if SymTab[s][S_EFFECT] then*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _30092 = (int)*(((s1_ptr)_2)->base + _s_59568);
    _2 = (int)SEQ_PTR(_30092);
    _30093 = (int)*(((s1_ptr)_2)->base + 23);
    _30092 = NOVALUE;
    if (_30093 == 0) {
        _30093 = NOVALUE;
        goto L1; // [88] 139
    }
    else {
        if (!IS_ATOM_INT(_30093) && DBL_PTR(_30093)->dbl == 0.0){
            _30093 = NOVALUE;
            goto L1; // [88] 139
        }
        _30093 = NOVALUE;
    }
    _30093 = NOVALUE;

    /** 		SymTab[CurrentSub][S_EFFECT] = or_bits(SymTab[CurrentSub][S_EFFECT],*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_35CurrentSub_16252 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _30096 = (int)*(((s1_ptr)_2)->base + _35CurrentSub_16252);
    _2 = (int)SEQ_PTR(_30096);
    _30097 = (int)*(((s1_ptr)_2)->base + 23);
    _30096 = NOVALUE;
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _30098 = (int)*(((s1_ptr)_2)->base + _s_59568);
    _2 = (int)SEQ_PTR(_30098);
    _30099 = (int)*(((s1_ptr)_2)->base + 23);
    _30098 = NOVALUE;
    if (IS_ATOM_INT(_30097) && IS_ATOM_INT(_30099)) {
        {unsigned long tu;
             tu = (unsigned long)_30097 | (unsigned long)_30099;
             _30100 = MAKE_UINT(tu);
        }
    }
    else {
        _30100 = binary_op(OR_BITS, _30097, _30099);
    }
    _30097 = NOVALUE;
    _30099 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 23);
    _1 = *(int *)_2;
    *(int *)_2 = _30100;
    if( _1 != _30100 ){
        DeRef(_1);
    }
    _30100 = NOVALUE;
    _30094 = NOVALUE;
L1: 

    /** 	ParseArgs(s)*/
    _39ParseArgs(_s_59568);

    /** 	for i=1 to n+1 do*/
    _30101 = _n_59562 + 1;
    if (_30101 > MAXINT){
        _30101 = NewDouble((double)_30101);
    }
    {
        int _i_59606;
        _i_59606 = 1;
L2: 
        if (binary_op_a(GREATER, _i_59606, _30101)){
            goto L3; // [150] 180
        }

        /** 		s = SymTab[s][S_NEXT]*/
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _30102 = (int)*(((s1_ptr)_2)->base + _s_59568);
        _2 = (int)SEQ_PTR(_30102);
        _s_59568 = (int)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_s_59568)){
            _s_59568 = (long)DBL_PTR(_s_59568)->dbl;
        }
        _30102 = NOVALUE;

        /** 	end for*/
        _0 = _i_59606;
        if (IS_ATOM_INT(_i_59606)) {
            _i_59606 = _i_59606 + 1;
            if ((long)((unsigned long)_i_59606 +(unsigned long) HIGH_BITS) >= 0){
                _i_59606 = NewDouble((double)_i_59606);
            }
        }
        else {
            _i_59606 = binary_op_a(PLUS, _i_59606, 1);
        }
        DeRef(_0);
        goto L2; // [175] 157
L3: 
        ;
        DeRef(_i_59606);
    }

    /** 	while s and SymTab[s][S_SCOPE]=SC_PRIVATE do*/
L4: 
    if (_s_59568 == 0) {
        goto L5; // [185] 281
    }
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _30105 = (int)*(((s1_ptr)_2)->base + _s_59568);
    _2 = (int)SEQ_PTR(_30105);
    _30106 = (int)*(((s1_ptr)_2)->base + 4);
    _30105 = NOVALUE;
    if (IS_ATOM_INT(_30106)) {
        _30107 = (_30106 == 3);
    }
    else {
        _30107 = binary_op(EQUALS, _30106, 3);
    }
    _30106 = NOVALUE;
    if (_30107 <= 0) {
        if (_30107 == 0) {
            DeRef(_30107);
            _30107 = NOVALUE;
            goto L5; // [208] 281
        }
        else {
            if (!IS_ATOM_INT(_30107) && DBL_PTR(_30107)->dbl == 0.0){
                DeRef(_30107);
                _30107 = NOVALUE;
                goto L5; // [208] 281
            }
            DeRef(_30107);
            _30107 = NOVALUE;
        }
    }
    DeRef(_30107);
    _30107 = NOVALUE;

    /** 		if sequence(SymTab[s][S_CODE]) then*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _30108 = (int)*(((s1_ptr)_2)->base + _s_59568);
    _2 = (int)SEQ_PTR(_30108);
    if (!IS_ATOM_INT(_35S_CODE_15929)){
        _30109 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_CODE_15929)->dbl));
    }
    else{
        _30109 = (int)*(((s1_ptr)_2)->base + _35S_CODE_15929);
    }
    _30108 = NOVALUE;
    _30110 = IS_SEQUENCE(_30109);
    _30109 = NOVALUE;
    if (_30110 == 0)
    {
        _30110 = NOVALUE;
        goto L6; // [228] 260
    }
    else{
        _30110 = NOVALUE;
    }

    /** 			start_playback(SymTab[s][S_CODE])*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _30111 = (int)*(((s1_ptr)_2)->base + _s_59568);
    _2 = (int)SEQ_PTR(_30111);
    if (!IS_ATOM_INT(_35S_CODE_15929)){
        _30112 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_CODE_15929)->dbl));
    }
    else{
        _30112 = (int)*(((s1_ptr)_2)->base + _35S_CODE_15929);
    }
    _30111 = NOVALUE;
    Ref(_30112);
    _39start_playback(_30112);
    _30112 = NOVALUE;

    /** 			Assignment({VARIABLE,s})*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -100;
    ((int *)_2)[2] = _s_59568;
    _30113 = MAKE_SEQ(_1);
    _39Assignment(_30113);
    _30113 = NOVALUE;
L6: 

    /** 		s = SymTab[s][S_NEXT]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _30114 = (int)*(((s1_ptr)_2)->base + _s_59568);
    _2 = (int)SEQ_PTR(_30114);
    _s_59568 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_59568)){
        _s_59568 = (long)DBL_PTR(_s_59568)->dbl;
    }
    _30114 = NOVALUE;

    /** 	end while*/
    goto L4; // [278] 185
L5: 

    /** 	s = sub*/
    _s_59568 = _sub_59569;

    /** 	if scope = SC_PREDEF then*/
    if (_scope_59563 != 7)
    goto L7; // [292] 335

    /** 		emit_op(opcode)*/
    _41emit_op(_opcode_59564);

    /** 		if opcode = ABORT then*/
    if (_opcode_59564 != 126)
    goto L8; // [305] 370

    /** 			temp_tok = next_token()*/
    _0 = _temp_tok_59566;
    _temp_tok_59566 = _39next_token();
    DeRef(_0);

    /** 			putback(temp_tok)*/
    Ref(_temp_tok_59566);
    _39putback(_temp_tok_59566);

    /** 			NotReached(temp_tok[T_ID], "abort()")*/
    _2 = (int)SEQ_PTR(_temp_tok_59566);
    _30119 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_30119);
    RefDS(_27976);
    _39NotReached(_30119, _27976);
    _30119 = NOVALUE;
    goto L8; // [332] 370
L7: 

    /** 		op_info1 = s*/
    _41op_info1_50222 = _s_59568;

    /** 		emit_or_inline()*/
    _67emit_or_inline();

    /** 		if not TRANSLATE then*/
    if (_35TRANSLATE_15887 != 0)
    goto L9; // [350] 369

    /** 			if OpTrace then*/
    if (_35OpTrace_16313 == 0)
    {
        goto LA; // [357] 368
    }
    else{
    }

    /** 				emit_op(UPDATE_GLOBALS)*/
    _41emit_op(89);
LA: 
L9: 
L8: 

    /** end procedure*/
    DeRef(_tok_59561);
    DeRef(_temp_tok_59566);
    DeRef(_30101);
    _30101 = NOVALUE;
    return;
    ;
}


void _39Print_statement()
{
    int _30126 = NOVALUE;
    int _30125 = NOVALUE;
    int _30124 = NOVALUE;
    int _30122 = NOVALUE;
    int _30121 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	emit_opnd(NewIntSym(1)) -- stdout*/
    _30121 = _53NewIntSym(1);
    _41emit_opnd(_30121);
    _30121 = NOVALUE;

    /** 	Expr()*/
    _39Expr();

    /** 	emit_op(QPRINT)*/
    _41emit_op(36);

    /** 	SymTab[CurrentSub][S_EFFECT] = or_bits(SymTab[CurrentSub][S_EFFECT],*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_35CurrentSub_16252 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _30124 = (int)*(((s1_ptr)_2)->base + _35CurrentSub_16252);
    _2 = (int)SEQ_PTR(_30124);
    _30125 = (int)*(((s1_ptr)_2)->base + 23);
    _30124 = NOVALUE;
    if (IS_ATOM_INT(_30125)) {
        {unsigned long tu;
             tu = (unsigned long)_30125 | (unsigned long)536870912;
             _30126 = MAKE_UINT(tu);
        }
    }
    else {
        _30126 = binary_op(OR_BITS, _30125, 536870912);
    }
    _30125 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 23);
    _1 = *(int *)_2;
    *(int *)_2 = _30126;
    if( _1 != _30126 ){
        DeRef(_1);
    }
    _30126 = NOVALUE;
    _30122 = NOVALUE;

    /** end procedure*/
    return;
    ;
}


void _39Entry_statement()
{
    int _addr_59677 = NOVALUE;
    int _30151 = NOVALUE;
    int _30150 = NOVALUE;
    int _30149 = NOVALUE;
    int _30148 = NOVALUE;
    int _30147 = NOVALUE;
    int _30146 = NOVALUE;
    int _30145 = NOVALUE;
    int _30144 = NOVALUE;
    int _30140 = NOVALUE;
    int _30138 = NOVALUE;
    int _30137 = NOVALUE;
    int _30135 = NOVALUE;
    int _30134 = NOVALUE;
    int _30132 = NOVALUE;
    int _30131 = NOVALUE;
    int _30130 = NOVALUE;
    int _30128 = NOVALUE;
    int _30127 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not length(loop_stack) or block_index=0 then*/
    if (IS_SEQUENCE(_39loop_stack_54151)){
            _30127 = SEQ_PTR(_39loop_stack_54151)->length;
    }
    else {
        _30127 = 1;
    }
    _30128 = (_30127 == 0);
    _30127 = NOVALUE;
    if (_30128 != 0) {
        goto L1; // [11] 26
    }
    _30130 = (_39block_index_54148 == 0);
    if (_30130 == 0)
    {
        DeRef(_30130);
        _30130 = NOVALUE;
        goto L2; // [22] 34
    }
    else{
        DeRef(_30130);
        _30130 = NOVALUE;
    }
L1: 

    /** 		CompileErr(144)*/
    RefDS(_22023);
    _44CompileErr(144, _22023, 0);
L2: 

    /** 	if block_list[block_index]=IF or block_list[block_index]=SWITCH then*/
    _2 = (int)SEQ_PTR(_39block_list_54147);
    _30131 = (int)*(((s1_ptr)_2)->base + _39block_index_54148);
    _30132 = (_30131 == 20);
    _30131 = NOVALUE;
    if (_30132 != 0) {
        goto L3; // [50] 73
    }
    _2 = (int)SEQ_PTR(_39block_list_54147);
    _30134 = (int)*(((s1_ptr)_2)->base + _39block_index_54148);
    _30135 = (_30134 == 185);
    _30134 = NOVALUE;
    if (_30135 == 0)
    {
        DeRef(_30135);
        _30135 = NOVALUE;
        goto L4; // [69] 83
    }
    else{
        DeRef(_30135);
        _30135 = NOVALUE;
    }
L3: 

    /** 		CompileErr(143)*/
    RefDS(_22023);
    _44CompileErr(143, _22023, 0);
    goto L5; // [80] 109
L4: 

    /** 	elsif loop_stack[$] = FOR then  -- not allowed in an innermost for loop*/
    if (IS_SEQUENCE(_39loop_stack_54151)){
            _30137 = SEQ_PTR(_39loop_stack_54151)->length;
    }
    else {
        _30137 = 1;
    }
    _2 = (int)SEQ_PTR(_39loop_stack_54151);
    _30138 = (int)*(((s1_ptr)_2)->base + _30137);
    if (_30138 != 21)
    goto L6; // [96] 108

    /** 		CompileErr(142)*/
    RefDS(_22023);
    _44CompileErr(142, _22023, 0);
L6: 
L5: 

    /** 	addr = entry_addr[$]*/
    if (IS_SEQUENCE(_39entry_addr_54141)){
            _30140 = SEQ_PTR(_39entry_addr_54141)->length;
    }
    else {
        _30140 = 1;
    }
    _2 = (int)SEQ_PTR(_39entry_addr_54141);
    _addr_59677 = (int)*(((s1_ptr)_2)->base + _30140);

    /** 	if addr=0  then*/
    if (_addr_59677 != 0)
    goto L7; // [122] 136

    /** 		CompileErr(141)*/
    RefDS(_22023);
    _44CompileErr(141, _22023, 0);
    goto L8; // [133] 151
L7: 

    /** 	elsif addr<0 then*/
    if (_addr_59677 >= 0)
    goto L9; // [138] 150

    /** 		CompileErr(73)*/
    RefDS(_22023);
    _44CompileErr(73, _22023, 0);
L9: 
L8: 

    /** 	backpatch(addr,ELSE)*/
    _41backpatch(_addr_59677, 23);

    /** 	backpatch(addr+1,length(Code)+1+(TRANSLATE>0))*/
    _30144 = _addr_59677 + 1;
    if (_30144 > MAXINT){
        _30144 = NewDouble((double)_30144);
    }
    if (IS_SEQUENCE(_35Code_16332)){
            _30145 = SEQ_PTR(_35Code_16332)->length;
    }
    else {
        _30145 = 1;
    }
    _30146 = _30145 + 1;
    _30145 = NOVALUE;
    _30147 = (_35TRANSLATE_15887 > 0);
    _30148 = _30146 + _30147;
    _30146 = NOVALUE;
    _30147 = NOVALUE;
    _41backpatch(_30144, _30148);
    _30144 = NOVALUE;
    _30148 = NOVALUE;

    /** 	entry_addr[$] = 0*/
    if (IS_SEQUENCE(_39entry_addr_54141)){
            _30149 = SEQ_PTR(_39entry_addr_54141)->length;
    }
    else {
        _30149 = 1;
    }
    _2 = (int)SEQ_PTR(_39entry_addr_54141);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _39entry_addr_54141 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _30149);
    *(int *)_2 = 0;

    /** 	if TRANSLATE then*/
    if (_35TRANSLATE_15887 == 0)
    {
        goto LA; // [203] 214
    }
    else{
    }

    /** 	    emit_op(NOP1)*/
    _41emit_op(159);
LA: 

    /** 	force_uninitialize( entry_stack[$] )*/
    if (IS_SEQUENCE(_39entry_stack_54144)){
            _30150 = SEQ_PTR(_39entry_stack_54144)->length;
    }
    else {
        _30150 = 1;
    }
    _2 = (int)SEQ_PTR(_39entry_stack_54144);
    _30151 = (int)*(((s1_ptr)_2)->base + _30150);
    Ref(_30151);
    _39force_uninitialize(_30151);
    _30151 = NOVALUE;

    /** end procedure*/
    DeRef(_30128);
    _30128 = NOVALUE;
    _30138 = NOVALUE;
    DeRef(_30132);
    _30132 = NOVALUE;
    return;
    ;
}


void _39force_uninitialize(int _uninitialized_59728)
{
    int _30154 = NOVALUE;
    int _30153 = NOVALUE;
    int _30152 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	for i = 1 to length( uninitialized ) do*/
    if (IS_SEQUENCE(_uninitialized_59728)){
            _30152 = SEQ_PTR(_uninitialized_59728)->length;
    }
    else {
        _30152 = 1;
    }
    {
        int _i_59730;
        _i_59730 = 1;
L1: 
        if (_i_59730 > _30152){
            goto L2; // [8] 41
        }

        /** 		SymTab[uninitialized[i]][S_INITLEVEL] = -1*/
        _2 = (int)SEQ_PTR(_uninitialized_59728);
        _30153 = (int)*(((s1_ptr)_2)->base + _i_59730);
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _36SymTab_15242 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_30153))
        _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_30153)->dbl));
        else
        _3 = (int)(_30153 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 14);
        _1 = *(int *)_2;
        *(int *)_2 = -1;
        DeRef(_1);
        _30154 = NOVALUE;

        /** 	end for*/
        _i_59730 = _i_59730 + 1;
        goto L1; // [36] 15
L2: 
        ;
    }

    /** end procedure*/
    DeRefDS(_uninitialized_59728);
    _30153 = NOVALUE;
    return;
    ;
}


void _39Statement_list()
{
    int _tok_59740 = NOVALUE;
    int _id_59741 = NOVALUE;
    int _forward_59764 = NOVALUE;
    int _test_59913 = NOVALUE;
    int _30226 = NOVALUE;
    int _30225 = NOVALUE;
    int _30222 = NOVALUE;
    int _30220 = NOVALUE;
    int _30219 = NOVALUE;
    int _30216 = NOVALUE;
    int _30214 = NOVALUE;
    int _30213 = NOVALUE;
    int _30212 = NOVALUE;
    int _30209 = NOVALUE;
    int _30207 = NOVALUE;
    int _30205 = NOVALUE;
    int _30203 = NOVALUE;
    int _30185 = NOVALUE;
    int _30184 = NOVALUE;
    int _30182 = NOVALUE;
    int _30180 = NOVALUE;
    int _30179 = NOVALUE;
    int _30177 = NOVALUE;
    int _30175 = NOVALUE;
    int _30174 = NOVALUE;
    int _30173 = NOVALUE;
    int _30172 = NOVALUE;
    int _30167 = NOVALUE;
    int _30164 = NOVALUE;
    int _30163 = NOVALUE;
    int _30162 = NOVALUE;
    int _30161 = NOVALUE;
    int _30159 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer id*/

    /** 	stmt_nest += 1*/
    _39stmt_nest_54149 = _39stmt_nest_54149 + 1;

    /** 	while TRUE do*/
L1: 
    if (_13TRUE_436 == 0)
    {
        goto L2; // [18] 1093
    }
    else{
    }

    /** 		tok = next_token()*/
    _0 = _tok_59740;
    _tok_59740 = _39next_token();
    DeRef(_0);

    /** 		id = tok[T_ID]*/
    _2 = (int)SEQ_PTR(_tok_59740);
    _id_59741 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_id_59741)){
        _id_59741 = (long)DBL_PTR(_id_59741)->dbl;
    }

    /** 		if id = VARIABLE or id = QUALIFIED_VARIABLE then*/
    _30159 = (_id_59741 == -100);
    if (_30159 != 0) {
        goto L3; // [44] 59
    }
    _30161 = (_id_59741 == 512);
    if (_30161 == 0)
    {
        DeRef(_30161);
        _30161 = NOVALUE;
        goto L4; // [55] 229
    }
    else{
        DeRef(_30161);
        _30161 = NOVALUE;
    }
L3: 

    /** 			if SymTab[tok[T_SYM]][S_SCOPE] = SC_UNDEFINED then*/
    _2 = (int)SEQ_PTR(_tok_59740);
    _30162 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!IS_ATOM_INT(_30162)){
        _30163 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_30162)->dbl));
    }
    else{
        _30163 = (int)*(((s1_ptr)_2)->base + _30162);
    }
    _2 = (int)SEQ_PTR(_30163);
    _30164 = (int)*(((s1_ptr)_2)->base + 4);
    _30163 = NOVALUE;
    if (binary_op_a(NOTEQ, _30164, 9)){
        _30164 = NOVALUE;
        goto L5; // [81] 210
    }
    _30164 = NOVALUE;

    /** 				token forward = next_token()*/
    _0 = _forward_59764;
    _forward_59764 = _39next_token();
    DeRef(_0);

    /** 				switch forward[T_ID] do*/
    _2 = (int)SEQ_PTR(_forward_59764);
    _30167 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_30167) ){
        goto L6; // [98] 204
    }
    if(!IS_ATOM_INT(_30167)){
        if( (DBL_PTR(_30167)->dbl != (double) ((int) DBL_PTR(_30167)->dbl) ) ){
            goto L6; // [98] 204
        }
        _0 = (int) DBL_PTR(_30167)->dbl;
    }
    else {
        _0 = _30167;
    };
    _30167 = NOVALUE;
    switch ( _0 ){ 

        /** 					case LEFT_ROUND then*/
        case -26:

        /** 						StartSourceLine( TRUE )*/
        _41StartSourceLine(_13TRUE_436, 0, 2);

        /** 						Forward_call( tok )*/
        Ref(_tok_59740);
        _39Forward_call(_tok_59740, 195);

        /** 						flush_temps()*/
        RefDS(_22023);
        _41flush_temps(_22023);

        /** 						continue*/
        DeRef(_forward_59764);
        _forward_59764 = NOVALUE;
        goto L1; // [133] 16
        goto L6; // [135] 204

        /** 					case VARIABLE then*/
        case -100:

        /** 						putback( forward )*/
        Ref(_forward_59764);
        _39putback(_forward_59764);

        /** 						if param_num != -1 then*/
        if (_39param_num_54126 == -1)
        goto L7; // [150] 176

        /** 							param_num += 1*/
        _39param_num_54126 = _39param_num_54126 + 1;

        /** 							Private_declaration( tok[T_SYM] )*/
        _2 = (int)SEQ_PTR(_tok_59740);
        _30172 = (int)*(((s1_ptr)_2)->base + 2);
        Ref(_30172);
        _39Private_declaration(_30172);
        _30172 = NOVALUE;
        goto L8; // [173] 192
L7: 

        /** 							Global_declaration( tok[T_SYM], SC_LOCAL )*/
        _2 = (int)SEQ_PTR(_tok_59740);
        _30173 = (int)*(((s1_ptr)_2)->base + 2);
        Ref(_30173);
        _30174 = _39Global_declaration(_30173, 5);
        _30173 = NOVALUE;
L8: 

        /** 						flush_temps()*/
        RefDS(_22023);
        _41flush_temps(_22023);

        /** 						continue*/
        DeRef(_forward_59764);
        _forward_59764 = NOVALUE;
        goto L1; // [201] 16
    ;}L6: 

    /** 				putback( forward )*/
    Ref(_forward_59764);
    _39putback(_forward_59764);
L5: 
    DeRef(_forward_59764);
    _forward_59764 = NOVALUE;

    /** 			StartSourceLine(TRUE)*/
    _41StartSourceLine(_13TRUE_436, 0, 2);

    /** 			Assignment(tok)*/
    Ref(_tok_59740);
    _39Assignment(_tok_59740);
    goto L9; // [226] 1083
L4: 

    /** 		elsif id = PROC or id = QUALIFIED_PROC then*/
    _30175 = (_id_59741 == 27);
    if (_30175 != 0) {
        goto LA; // [237] 252
    }
    _30177 = (_id_59741 == 521);
    if (_30177 == 0)
    {
        DeRef(_30177);
        _30177 = NOVALUE;
        goto LB; // [248] 289
    }
    else{
        DeRef(_30177);
        _30177 = NOVALUE;
    }
LA: 

    /** 			if id = PROC then*/
    if (_id_59741 != 27)
    goto LC; // [256] 272

    /** 				UndefinedVar( tok[T_SYM] )*/
    _2 = (int)SEQ_PTR(_tok_59740);
    _30179 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_30179);
    _39UndefinedVar(_30179);
    _30179 = NOVALUE;
LC: 

    /** 			StartSourceLine(TRUE)*/
    _41StartSourceLine(_13TRUE_436, 0, 2);

    /** 			Procedure_call(tok)*/
    Ref(_tok_59740);
    _39Procedure_call(_tok_59740);
    goto L9; // [286] 1083
LB: 

    /** 		elsif id = FUNC or id = QUALIFIED_FUNC then*/
    _30180 = (_id_59741 == 501);
    if (_30180 != 0) {
        goto LD; // [297] 312
    }
    _30182 = (_id_59741 == 520);
    if (_30182 == 0)
    {
        DeRef(_30182);
        _30182 = NOVALUE;
        goto LE; // [308] 362
    }
    else{
        DeRef(_30182);
        _30182 = NOVALUE;
    }
LD: 

    /** 			if id = FUNC then*/
    if (_id_59741 != 501)
    goto LF; // [316] 332

    /** 				UndefinedVar( tok[T_SYM] )*/
    _2 = (int)SEQ_PTR(_tok_59740);
    _30184 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_30184);
    _39UndefinedVar(_30184);
    _30184 = NOVALUE;
LF: 

    /** 			StartSourceLine(TRUE)*/
    _41StartSourceLine(_13TRUE_436, 0, 2);

    /** 			Procedure_call(tok)*/
    Ref(_tok_59740);
    _39Procedure_call(_tok_59740);

    /** 			clear_op()*/
    _41clear_op();

    /** 			if Pop() then end if*/
    _30185 = _41Pop();
    if (_30185 == 0) {
        DeRef(_30185);
        _30185 = NOVALUE;
        goto L9; // [355] 1083
    }
    else {
        if (!IS_ATOM_INT(_30185) && DBL_PTR(_30185)->dbl == 0.0){
            DeRef(_30185);
            _30185 = NOVALUE;
            goto L9; // [355] 1083
        }
        DeRef(_30185);
        _30185 = NOVALUE;
    }
    DeRef(_30185);
    _30185 = NOVALUE;
    goto L9; // [359] 1083
LE: 

    /** 		elsif id = IF then*/
    if (_id_59741 != 20)
    goto L10; // [366] 386

    /** 			StartSourceLine(TRUE)*/
    _41StartSourceLine(_13TRUE_436, 0, 2);

    /** 			If_statement()*/
    _39If_statement();
    goto L9; // [383] 1083
L10: 

    /** 		elsif id = FOR then*/
    if (_id_59741 != 21)
    goto L11; // [390] 410

    /** 			StartSourceLine(TRUE)*/
    _41StartSourceLine(_13TRUE_436, 0, 2);

    /** 			For_statement()*/
    _39For_statement();
    goto L9; // [407] 1083
L11: 

    /** 		elsif id = RETURN then*/
    if (_id_59741 != 413)
    goto L12; // [414] 434

    /** 			StartSourceLine(TRUE)*/
    _41StartSourceLine(_13TRUE_436, 0, 2);

    /** 			Return_statement()*/
    _39Return_statement();
    goto L9; // [431] 1083
L12: 

    /** 		elsif id = LABEL then*/
    if (_id_59741 != 419)
    goto L13; // [438] 460

    /** 			StartSourceLine(TRUE, , COVERAGE_SUPPRESS )*/
    _41StartSourceLine(_13TRUE_436, 0, 1);

    /** 			GLabel_statement()*/
    _39GLabel_statement();
    goto L9; // [457] 1083
L13: 

    /** 		elsif id = GOTO then*/
    if (_id_59741 != 188)
    goto L14; // [464] 484

    /** 			StartSourceLine(TRUE)*/
    _41StartSourceLine(_13TRUE_436, 0, 2);

    /** 			Goto_statement()*/
    _39Goto_statement();
    goto L9; // [481] 1083
L14: 

    /** 		elsif id = EXIT then*/
    if (_id_59741 != 61)
    goto L15; // [488] 508

    /** 			StartSourceLine(TRUE)*/
    _41StartSourceLine(_13TRUE_436, 0, 2);

    /** 			Exit_statement()*/
    _39Exit_statement();
    goto L9; // [505] 1083
L15: 

    /** 		elsif id = BREAK then*/
    if (_id_59741 != 425)
    goto L16; // [512] 532

    /** 			StartSourceLine(TRUE)*/
    _41StartSourceLine(_13TRUE_436, 0, 2);

    /** 			Break_statement()*/
    _39Break_statement();
    goto L9; // [529] 1083
L16: 

    /** 		elsif id = WHILE then*/
    if (_id_59741 != 47)
    goto L17; // [536] 556

    /** 			StartSourceLine(TRUE)*/
    _41StartSourceLine(_13TRUE_436, 0, 2);

    /** 			While_statement()*/
    _39While_statement();
    goto L9; // [553] 1083
L17: 

    /** 		elsif id = LOOP then*/
    if (_id_59741 != 422)
    goto L18; // [560] 580

    /** 		    StartSourceLine(TRUE)*/
    _41StartSourceLine(_13TRUE_436, 0, 2);

    /** 	        Loop_statement()*/
    _39Loop_statement();
    goto L9; // [577] 1083
L18: 

    /** 		elsif id = ENTRY then*/
    if (_id_59741 != 424)
    goto L19; // [584] 606

    /** 		    StartSourceLine(TRUE, , COVERAGE_SUPPRESS )*/
    _41StartSourceLine(_13TRUE_436, 0, 1);

    /** 		    Entry_statement()*/
    _39Entry_statement();
    goto L9; // [603] 1083
L19: 

    /** 		elsif id = QUESTION_MARK then*/
    if (_id_59741 != -31)
    goto L1A; // [610] 630

    /** 			StartSourceLine(TRUE)*/
    _41StartSourceLine(_13TRUE_436, 0, 2);

    /** 			Print_statement()*/
    _39Print_statement();
    goto L9; // [627] 1083
L1A: 

    /** 		elsif id = CONTINUE then*/
    if (_id_59741 != 426)
    goto L1B; // [634] 654

    /** 			StartSourceLine(TRUE)*/
    _41StartSourceLine(_13TRUE_436, 0, 2);

    /** 			Continue_statement()*/
    _39Continue_statement();
    goto L9; // [651] 1083
L1B: 

    /** 		elsif id = RETRY then*/
    if (_id_59741 != 184)
    goto L1C; // [658] 678

    /** 			StartSourceLine(TRUE)*/
    _41StartSourceLine(_13TRUE_436, 0, 2);

    /** 			Retry_statement()*/
    _39Retry_statement();
    goto L9; // [675] 1083
L1C: 

    /** 		elsif id = IFDEF then*/
    if (_id_59741 != 407)
    goto L1D; // [682] 702

    /** 			StartSourceLine(TRUE)*/
    _41StartSourceLine(_13TRUE_436, 0, 2);

    /** 			Ifdef_statement()*/
    _39Ifdef_statement();
    goto L9; // [699] 1083
L1D: 

    /** 		elsif id = CASE then*/
    if (_id_59741 != 186)
    goto L1E; // [706] 717

    /** 			Case_statement()*/
    _39Case_statement();
    goto L9; // [714] 1083
L1E: 

    /** 		elsif id = SWITCH then*/
    if (_id_59741 != 185)
    goto L1F; // [721] 741

    /** 			StartSourceLine(TRUE)*/
    _41StartSourceLine(_13TRUE_436, 0, 2);

    /** 			Switch_statement()*/
    _39Switch_statement();
    goto L9; // [738] 1083
L1F: 

    /** 		elsif id = FALLTHRU then*/
    if (_id_59741 != 431)
    goto L20; // [745] 756

    /** 			Fallthru_statement()*/
    _39Fallthru_statement();
    goto L9; // [753] 1083
L20: 

    /** 		elsif id = TYPE or id = QUALIFIED_TYPE then*/
    _30203 = (_id_59741 == 504);
    if (_30203 != 0) {
        goto L21; // [764] 779
    }
    _30205 = (_id_59741 == 522);
    if (_30205 == 0)
    {
        DeRef(_30205);
        _30205 = NOVALUE;
        goto L22; // [775] 904
    }
    else{
        DeRef(_30205);
        _30205 = NOVALUE;
    }
L21: 

    /** 			StartSourceLine(TRUE)*/
    _41StartSourceLine(_13TRUE_436, 0, 2);

    /** 			token test = next_token()*/
    _0 = _test_59913;
    _test_59913 = _39next_token();
    DeRef(_0);

    /** 			putback( test )*/
    Ref(_test_59913);
    _39putback(_test_59913);

    /** 			if test[T_ID] = LEFT_ROUND then*/
    _2 = (int)SEQ_PTR(_test_59913);
    _30207 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30207, -26)){
        _30207 = NOVALUE;
        goto L23; // [808] 852
    }
    _30207 = NOVALUE;

    /** 				StartSourceLine( TRUE )*/
    _41StartSourceLine(_13TRUE_436, 0, 2);

    /** 				Procedure_call(tok)*/
    Ref(_tok_59740);
    _39Procedure_call(_tok_59740);

    /** 				clear_op()*/
    _41clear_op();

    /** 				if Pop() then end if*/
    _30209 = _41Pop();
    if (_30209 == 0) {
        DeRef(_30209);
        _30209 = NOVALUE;
        goto L24; // [835] 839
    }
    else {
        if (!IS_ATOM_INT(_30209) && DBL_PTR(_30209)->dbl == 0.0){
            DeRef(_30209);
            _30209 = NOVALUE;
            goto L24; // [835] 839
        }
        DeRef(_30209);
        _30209 = NOVALUE;
    }
    DeRef(_30209);
    _30209 = NOVALUE;
L24: 

    /** 				ExecCommand()*/
    _39ExecCommand();

    /** 				continue*/
    DeRef(_test_59913);
    _test_59913 = NOVALUE;
    goto L1; // [847] 16
    goto L25; // [849] 899
L23: 

    /** 				if param_num != -1 then*/
    if (_39param_num_54126 == -1)
    goto L26; // [856] 882

    /** 					param_num += 1*/
    _39param_num_54126 = _39param_num_54126 + 1;

    /** 					Private_declaration( tok[T_SYM] )*/
    _2 = (int)SEQ_PTR(_tok_59740);
    _30212 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_30212);
    _39Private_declaration(_30212);
    _30212 = NOVALUE;
    goto L27; // [879] 898
L26: 

    /** 					Global_declaration( tok[T_SYM], SC_LOCAL )*/
    _2 = (int)SEQ_PTR(_tok_59740);
    _30213 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_30213);
    _30214 = _39Global_declaration(_30213, 5);
    _30213 = NOVALUE;
L27: 
L25: 
    DeRef(_test_59913);
    _test_59913 = NOVALUE;
    goto L9; // [901] 1083
L22: 

    /** 			if id = ELSE then*/
    if (_id_59741 != 23)
    goto L28; // [908] 962

    /** 				if length(if_stack) = 0 then*/
    if (IS_SEQUENCE(_39if_stack_54152)){
            _30216 = SEQ_PTR(_39if_stack_54152)->length;
    }
    else {
        _30216 = 1;
    }
    if (_30216 != 0)
    goto L29; // [919] 1019

    /** 					if live_ifdef > 0 then*/
    if (_39live_ifdef_58290 <= 0)
    goto L2A; // [927] 950

    /** 						CompileErr(134, ifdef_lineno[$])*/
    if (IS_SEQUENCE(_39ifdef_lineno_58291)){
            _30219 = SEQ_PTR(_39ifdef_lineno_58291)->length;
    }
    else {
        _30219 = 1;
    }
    _2 = (int)SEQ_PTR(_39ifdef_lineno_58291);
    _30220 = (int)*(((s1_ptr)_2)->base + _30219);
    _44CompileErr(134, _30220, 0);
    _30220 = NOVALUE;
    goto L29; // [947] 1019
L2A: 

    /** 						CompileErr(118)*/
    RefDS(_22023);
    _44CompileErr(118, _22023, 0);
    goto L29; // [959] 1019
L28: 

    /** 			elsif id = ELSIF then*/
    if (_id_59741 != 414)
    goto L2B; // [966] 1018

    /** 				if length(if_stack) = 0 then*/
    if (IS_SEQUENCE(_39if_stack_54152)){
            _30222 = SEQ_PTR(_39if_stack_54152)->length;
    }
    else {
        _30222 = 1;
    }
    if (_30222 != 0)
    goto L2C; // [977] 1017

    /** 					if live_ifdef > 0 then*/
    if (_39live_ifdef_58290 <= 0)
    goto L2D; // [985] 1008

    /** 						CompileErr(139, ifdef_lineno[$])*/
    if (IS_SEQUENCE(_39ifdef_lineno_58291)){
            _30225 = SEQ_PTR(_39ifdef_lineno_58291)->length;
    }
    else {
        _30225 = 1;
    }
    _2 = (int)SEQ_PTR(_39ifdef_lineno_58291);
    _30226 = (int)*(((s1_ptr)_2)->base + _30225);
    _44CompileErr(139, _30226, 0);
    _30226 = NOVALUE;
    goto L2E; // [1005] 1016
L2D: 

    /** 						CompileErr(119)*/
    RefDS(_22023);
    _44CompileErr(119, _22023, 0);
L2E: 
L2C: 
L2B: 
L29: 

    /** 			putback( tok )*/
    Ref(_tok_59740);
    _39putback(_tok_59740);

    /** 			switch id do*/
    _0 = _id_59741;
    switch ( _0 ){ 

        /** 				case END, ELSEDEF, ELSIFDEF, ELSIF, ELSE, UNTIL then*/
        case 402:
        case 409:
        case 408:
        case 414:
        case 23:
        case 423:

        /** 					stmt_nest -= 1*/
        _39stmt_nest_54149 = _39stmt_nest_54149 - 1;

        /** 					InitDelete()*/
        _39InitDelete();

        /** 					flush_temps()*/
        RefDS(_22023);
        _41flush_temps(_22023);

        /** 					return*/
        DeRef(_tok_59740);
        DeRef(_30159);
        _30159 = NOVALUE;
        _30162 = NOVALUE;
        DeRef(_30175);
        _30175 = NOVALUE;
        DeRef(_30174);
        _30174 = NOVALUE;
        DeRef(_30180);
        _30180 = NOVALUE;
        DeRef(_30203);
        _30203 = NOVALUE;
        DeRef(_30214);
        _30214 = NOVALUE;
        return;
        goto L2F; // [1067] 1082

        /** 				case else*/
        default:

        /** 					tok_match( END )*/
        _39tok_match(402, 0);
    ;}L2F: 
L9: 

    /** 		flush_temps()*/
    RefDS(_22023);
    _41flush_temps(_22023);

    /** 	end while*/
    goto L1; // [1090] 16
L2: 

    /** end procedure*/
    DeRef(_tok_59740);
    DeRef(_30159);
    _30159 = NOVALUE;
    _30162 = NOVALUE;
    DeRef(_30175);
    _30175 = NOVALUE;
    DeRef(_30174);
    _30174 = NOVALUE;
    DeRef(_30180);
    _30180 = NOVALUE;
    DeRef(_30203);
    _30203 = NOVALUE;
    DeRef(_30214);
    _30214 = NOVALUE;
    return;
    ;
}


void _39SubProg(int _prog_type_59983, int _scope_59984)
{
    int _h_59985 = NOVALUE;
    int _pt_59986 = NOVALUE;
    int _p_59988 = NOVALUE;
    int _type_sym_59989 = NOVALUE;
    int _sym_59990 = NOVALUE;
    int _tok_59992 = NOVALUE;
    int _prog_name_59993 = NOVALUE;
    int _first_def_arg_59994 = NOVALUE;
    int _again_59995 = NOVALUE;
    int _type_enum_59996 = NOVALUE;
    int _seq_sym_59997 = NOVALUE;
    int _i1_sym_59998 = NOVALUE;
    int _enum_syms_59999 = NOVALUE;
    int _type_enum_gline_60000 = NOVALUE;
    int _real_gline_60001 = NOVALUE;
    int _tsym_60012 = NOVALUE;
    int _seq_symbol_60023 = NOVALUE;
    int _middle_def_args_60222 = NOVALUE;
    int _last_nda_60223 = NOVALUE;
    int _start_def_60224 = NOVALUE;
    int _last_link_60226 = NOVALUE;
    int _temptok_60253 = NOVALUE;
    int _undef_type_60255 = NOVALUE;
    int _tokcat_60304 = NOVALUE;
    int _31641 = NOVALUE;
    int _31640 = NOVALUE;
    int _31639 = NOVALUE;
    int _31638 = NOVALUE;
    int _31637 = NOVALUE;
    int _31636 = NOVALUE;
    int _31635 = NOVALUE;
    int _31634 = NOVALUE;
    int _31633 = NOVALUE;
    int _30491 = NOVALUE;
    int _30489 = NOVALUE;
    int _30488 = NOVALUE;
    int _30486 = NOVALUE;
    int _30485 = NOVALUE;
    int _30484 = NOVALUE;
    int _30483 = NOVALUE;
    int _30482 = NOVALUE;
    int _30480 = NOVALUE;
    int _30479 = NOVALUE;
    int _30476 = NOVALUE;
    int _30475 = NOVALUE;
    int _30474 = NOVALUE;
    int _30473 = NOVALUE;
    int _30471 = NOVALUE;
    int _30461 = NOVALUE;
    int _30459 = NOVALUE;
    int _30458 = NOVALUE;
    int _30457 = NOVALUE;
    int _30456 = NOVALUE;
    int _30453 = NOVALUE;
    int _30452 = NOVALUE;
    int _30451 = NOVALUE;
    int _30449 = NOVALUE;
    int _30446 = NOVALUE;
    int _30445 = NOVALUE;
    int _30444 = NOVALUE;
    int _30442 = NOVALUE;
    int _30441 = NOVALUE;
    int _30438 = NOVALUE;
    int _30436 = NOVALUE;
    int _30434 = NOVALUE;
    int _30433 = NOVALUE;
    int _30432 = NOVALUE;
    int _30431 = NOVALUE;
    int _30429 = NOVALUE;
    int _30428 = NOVALUE;
    int _30427 = NOVALUE;
    int _30426 = NOVALUE;
    int _30425 = NOVALUE;
    int _30424 = NOVALUE;
    int _30421 = NOVALUE;
    int _30419 = NOVALUE;
    int _30417 = NOVALUE;
    int _30415 = NOVALUE;
    int _30413 = NOVALUE;
    int _30410 = NOVALUE;
    int _30408 = NOVALUE;
    int _30407 = NOVALUE;
    int _30404 = NOVALUE;
    int _30400 = NOVALUE;
    int _30399 = NOVALUE;
    int _30397 = NOVALUE;
    int _30395 = NOVALUE;
    int _30393 = NOVALUE;
    int _30391 = NOVALUE;
    int _30389 = NOVALUE;
    int _30387 = NOVALUE;
    int _30386 = NOVALUE;
    int _30385 = NOVALUE;
    int _30384 = NOVALUE;
    int _30383 = NOVALUE;
    int _30382 = NOVALUE;
    int _30381 = NOVALUE;
    int _30380 = NOVALUE;
    int _30379 = NOVALUE;
    int _30378 = NOVALUE;
    int _30377 = NOVALUE;
    int _30376 = NOVALUE;
    int _30373 = NOVALUE;
    int _30372 = NOVALUE;
    int _30371 = NOVALUE;
    int _30370 = NOVALUE;
    int _30369 = NOVALUE;
    int _30368 = NOVALUE;
    int _30367 = NOVALUE;
    int _30366 = NOVALUE;
    int _30365 = NOVALUE;
    int _30364 = NOVALUE;
    int _30363 = NOVALUE;
    int _30362 = NOVALUE;
    int _30361 = NOVALUE;
    int _30360 = NOVALUE;
    int _30359 = NOVALUE;
    int _30357 = NOVALUE;
    int _30355 = NOVALUE;
    int _30354 = NOVALUE;
    int _30349 = NOVALUE;
    int _30348 = NOVALUE;
    int _30346 = NOVALUE;
    int _30345 = NOVALUE;
    int _30344 = NOVALUE;
    int _30343 = NOVALUE;
    int _30342 = NOVALUE;
    int _30341 = NOVALUE;
    int _30340 = NOVALUE;
    int _30339 = NOVALUE;
    int _30338 = NOVALUE;
    int _30337 = NOVALUE;
    int _30335 = NOVALUE;
    int _30334 = NOVALUE;
    int _30332 = NOVALUE;
    int _30331 = NOVALUE;
    int _30330 = NOVALUE;
    int _30329 = NOVALUE;
    int _30328 = NOVALUE;
    int _30327 = NOVALUE;
    int _30326 = NOVALUE;
    int _30324 = NOVALUE;
    int _30321 = NOVALUE;
    int _30319 = NOVALUE;
    int _30317 = NOVALUE;
    int _30315 = NOVALUE;
    int _30313 = NOVALUE;
    int _30311 = NOVALUE;
    int _30309 = NOVALUE;
    int _30307 = NOVALUE;
    int _30305 = NOVALUE;
    int _30304 = NOVALUE;
    int _30303 = NOVALUE;
    int _30302 = NOVALUE;
    int _30301 = NOVALUE;
    int _30300 = NOVALUE;
    int _30299 = NOVALUE;
    int _30297 = NOVALUE;
    int _30296 = NOVALUE;
    int _30294 = NOVALUE;
    int _30292 = NOVALUE;
    int _30290 = NOVALUE;
    int _30289 = NOVALUE;
    int _30286 = NOVALUE;
    int _30285 = NOVALUE;
    int _30284 = NOVALUE;
    int _30283 = NOVALUE;
    int _30282 = NOVALUE;
    int _30280 = NOVALUE;
    int _30279 = NOVALUE;
    int _30278 = NOVALUE;
    int _30277 = NOVALUE;
    int _30276 = NOVALUE;
    int _30274 = NOVALUE;
    int _30273 = NOVALUE;
    int _30272 = NOVALUE;
    int _30270 = NOVALUE;
    int _30269 = NOVALUE;
    int _30268 = NOVALUE;
    int _30267 = NOVALUE;
    int _30263 = NOVALUE;
    int _30262 = NOVALUE;
    int _30261 = NOVALUE;
    int _30259 = NOVALUE;
    int _30258 = NOVALUE;
    int _30257 = NOVALUE;
    int _30256 = NOVALUE;
    int _30255 = NOVALUE;
    int _30254 = NOVALUE;
    int _30250 = NOVALUE;
    int _30249 = NOVALUE;
    int _30248 = NOVALUE;
    int _30246 = NOVALUE;
    int _30245 = NOVALUE;
    int _30244 = NOVALUE;
    int _30242 = NOVALUE;
    int _30241 = NOVALUE;
    int _30239 = NOVALUE;
    int _30238 = NOVALUE;
    int _30237 = NOVALUE;
    int _30233 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_prog_type_59983)) {
        _1 = (long)(DBL_PTR(_prog_type_59983)->dbl);
        DeRefDS(_prog_type_59983);
        _prog_type_59983 = _1;
    }

    /** 	integer first_def_arg*/

    /** 	integer again*/

    /** 	integer type_enum*/

    /** 	object seq_sym*/

    /** 	object i1_sym*/

    /** 	sequence enum_syms = {}*/
    RefDS(_22023);
    DeRef(_enum_syms_59999);
    _enum_syms_59999 = _22023;

    /** 	integer type_enum_gline, real_gline*/

    /** 	LeaveTopLevel()*/
    _39LeaveTopLevel();

    /** 	prog_name = next_token()*/
    _0 = _prog_name_59993;
    _prog_name_59993 = _39next_token();
    DeRef(_0);

    /** 	if prog_name[T_ID] = END_OF_FILE then*/
    _2 = (int)SEQ_PTR(_prog_name_59993);
    _30233 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30233, -21)){
        _30233 = NOVALUE;
        goto L1; // [43] 55
    }
    _30233 = NOVALUE;

    /** 		CompileErr( 32 )*/
    RefDS(_22023);
    _44CompileErr(32, _22023, 0);
L1: 

    /** 	type_enum =  0*/
    _type_enum_59996 = 0;

    /** 	if prog_type = TYPE_DECL then*/
    if (_prog_type_59983 != 416)
    goto L2; // [64] 316

    /** 		object tsym = prog_name[T_SYM]*/
    DeRef(_tsym_60012);
    _2 = (int)SEQ_PTR(_prog_name_59993);
    _tsym_60012 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_tsym_60012);

    /** 		if equal(sym_name(prog_name[T_SYM]),"enum") then*/
    _2 = (int)SEQ_PTR(_prog_name_59993);
    _30237 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_30237);
    _30238 = _53sym_name(_30237);
    _30237 = NOVALUE;
    if (_30238 == _26320)
    _30239 = 1;
    else if (IS_ATOM_INT(_30238) && IS_ATOM_INT(_26320))
    _30239 = 0;
    else
    _30239 = (compare(_30238, _26320) == 0);
    DeRef(_30238);
    _30238 = NOVALUE;
    if (_30239 == 0)
    {
        _30239 = NOVALUE;
        goto L3; // [92] 313
    }
    else{
        _30239 = NOVALUE;
    }

    /** 			EnterTopLevel( FALSE )*/
    _39EnterTopLevel(_13FALSE_434);

    /** 			type_enum_gline = gline_number*/
    _type_enum_gline_60000 = _35gline_number_16249;

    /** 			type_enum = 1*/
    _type_enum_59996 = 1;

    /** 			sequence seq_symbol*/

    /** 			prog_name = next_token()*/
    _0 = _prog_name_59993;
    _prog_name_59993 = _39next_token();
    DeRef(_0);

    /** 			if not find(prog_name[T_ID], ADDR_TOKS) then*/
    _2 = (int)SEQ_PTR(_prog_name_59993);
    _30241 = (int)*(((s1_ptr)_2)->base + 1);
    _30242 = find_from(_30241, _37ADDR_TOKS_15874, 1);
    _30241 = NOVALUE;
    if (_30242 != 0)
    goto L4; // [138] 163
    _30242 = NOVALUE;

    /** 				CompileErr(25, {find_category(prog_name[T_ID])} )*/
    _2 = (int)SEQ_PTR(_prog_name_59993);
    _30244 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_30244);
    _30245 = _63find_category(_30244);
    _30244 = NOVALUE;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _30245;
    _30246 = MAKE_SEQ(_1);
    _30245 = NOVALUE;
    _44CompileErr(25, _30246, 0);
    _30246 = NOVALUE;
L4: 

    /** 			enum_syms = Global_declaration(-1, scope)*/
    _0 = _enum_syms_59999;
    _enum_syms_59999 = _39Global_declaration(-1, _scope_59984);
    DeRef(_0);

    /** 			seq_symbol = enum_syms*/
    RefDS(_enum_syms_59999);
    DeRef(_seq_symbol_60023);
    _seq_symbol_60023 = _enum_syms_59999;

    /** 			for i = 1 to length( enum_syms ) do*/
    if (IS_SEQUENCE(_enum_syms_59999)){
            _30248 = SEQ_PTR(_enum_syms_59999)->length;
    }
    else {
        _30248 = 1;
    }
    {
        int _i_60039;
        _i_60039 = 1;
L5: 
        if (_i_60039 > _30248){
            goto L6; // [184] 212
        }

        /** 				seq_symbol[i] = sym_obj(enum_syms[i])*/
        _2 = (int)SEQ_PTR(_enum_syms_59999);
        _30249 = (int)*(((s1_ptr)_2)->base + _i_60039);
        Ref(_30249);
        _30250 = _53sym_obj(_30249);
        _30249 = NOVALUE;
        _2 = (int)SEQ_PTR(_seq_symbol_60023);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _seq_symbol_60023 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_60039);
        _1 = *(int *)_2;
        *(int *)_2 = _30250;
        if( _1 != _30250 ){
            DeRef(_1);
        }
        _30250 = NOVALUE;

        /** 			end for*/
        _i_60039 = _i_60039 + 1;
        goto L5; // [207] 191
L6: 
        ;
    }

    /** 			i1_sym = keyfind("i1",-1)*/
    RefDS(_30251);
    DeRef(_31640);
    _31640 = _30251;
    _31641 = _53hashfn(_31640);
    _31640 = NOVALUE;
    RefDS(_30251);
    _0 = _i1_sym_59998;
    _i1_sym_59998 = _53keyfind(_30251, -1, _35current_file_no_16244, 0, _31641);
    DeRef(_0);
    _31641 = NOVALUE;

    /** 			seq_sym = NewStringSym(seq_symbol)*/
    RefDS(_seq_symbol_60023);
    _0 = _seq_sym_59997;
    _seq_sym_59997 = _53NewStringSym(_seq_symbol_60023);
    DeRef(_0);

    /** 			putback(keyfind("return",-1))*/
    RefDS(_26394);
    DeRef(_31638);
    _31638 = _26394;
    _31639 = _53hashfn(_31638);
    _31638 = NOVALUE;
    RefDS(_26394);
    _30254 = _53keyfind(_26394, -1, _35current_file_no_16244, 0, _31639);
    _31639 = NOVALUE;
    _39putback(_30254);
    _30254 = NOVALUE;

    /** 			putback({RIGHT_ROUND,0})*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -27;
    ((int *)_2)[2] = 0;
    _30255 = MAKE_SEQ(_1);
    _39putback(_30255);
    _30255 = NOVALUE;

    /** 			putback(i1_sym)*/
    Ref(_i1_sym_59998);
    _39putback(_i1_sym_59998);

    /** 			putback(keyfind("object",-1))*/
    RefDS(_24651);
    DeRef(_31636);
    _31636 = _24651;
    _31637 = _53hashfn(_31636);
    _31636 = NOVALUE;
    RefDS(_24651);
    _30256 = _53keyfind(_24651, -1, _35current_file_no_16244, 0, _31637);
    _31637 = NOVALUE;
    _39putback(_30256);
    _30256 = NOVALUE;

    /** 			putback({LEFT_ROUND,0})*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -26;
    ((int *)_2)[2] = 0;
    _30257 = MAKE_SEQ(_1);
    _39putback(_30257);
    _30257 = NOVALUE;

    /** 			LeaveTopLevel()*/
    _39LeaveTopLevel();
L3: 
    DeRef(_seq_symbol_60023);
    _seq_symbol_60023 = NOVALUE;
L2: 
    DeRef(_tsym_60012);
    _tsym_60012 = NOVALUE;

    /** 	if not find(prog_name[T_ID], ADDR_TOKS) then*/
    _2 = (int)SEQ_PTR(_prog_name_59993);
    _30258 = (int)*(((s1_ptr)_2)->base + 1);
    _30259 = find_from(_30258, _37ADDR_TOKS_15874, 1);
    _30258 = NOVALUE;
    if (_30259 != 0)
    goto L7; // [333] 358
    _30259 = NOVALUE;

    /** 		CompileErr(25, {find_category(prog_name[T_ID])} )*/
    _2 = (int)SEQ_PTR(_prog_name_59993);
    _30261 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_30261);
    _30262 = _63find_category(_30261);
    _30261 = NOVALUE;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _30262;
    _30263 = MAKE_SEQ(_1);
    _30262 = NOVALUE;
    _44CompileErr(25, _30263, 0);
    _30263 = NOVALUE;
L7: 

    /** 	p = prog_name[T_SYM]*/
    _2 = (int)SEQ_PTR(_prog_name_59993);
    _p_59988 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_p_59988)){
        _p_59988 = (long)DBL_PTR(_p_59988)->dbl;
    }

    /** 	DefinedYet(p)*/
    _53DefinedYet(_p_59988);

    /** 	if prog_type = PROCEDURE then*/
    if (_prog_type_59983 != 405)
    goto L8; // [377] 393

    /** 		pt = PROC*/
    _pt_59986 = 27;
    goto L9; // [390] 423
L8: 

    /** 	elsif prog_type = FUNCTION then*/
    if (_prog_type_59983 != 406)
    goto LA; // [397] 413

    /** 		pt = FUNC*/
    _pt_59986 = 501;
    goto L9; // [410] 423
LA: 

    /** 		pt = TYPE*/
    _pt_59986 = 504;
L9: 

    /** 	clear_fwd_refs()*/
    _38clear_fwd_refs();

    /** 	if find(SymTab[p][S_SCOPE], {SC_PREDEF, SC_GLOBAL, SC_PUBLIC, SC_EXPORT, SC_OVERRIDE}) then*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _30267 = (int)*(((s1_ptr)_2)->base + _p_59988);
    _2 = (int)SEQ_PTR(_30267);
    _30268 = (int)*(((s1_ptr)_2)->base + 4);
    _30267 = NOVALUE;
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 7;
    *((int *)(_2+8)) = 6;
    *((int *)(_2+12)) = 13;
    *((int *)(_2+16)) = 11;
    *((int *)(_2+20)) = 12;
    _30269 = MAKE_SEQ(_1);
    _30270 = find_from(_30268, _30269, 1);
    _30268 = NOVALUE;
    DeRefDS(_30269);
    _30269 = NOVALUE;
    if (_30270 == 0)
    {
        _30270 = NOVALUE;
        goto LB; // [464] 660
    }
    else{
        _30270 = NOVALUE;
    }

    /** 		if scope = SC_OVERRIDE then*/
    if (_scope_59984 != 12)
    goto LC; // [471] 597

    /** 			if SymTab[p][S_SCOPE] = SC_PREDEF or SymTab[p][S_SCOPE] = SC_OVERRIDE then*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _30272 = (int)*(((s1_ptr)_2)->base + _p_59988);
    _2 = (int)SEQ_PTR(_30272);
    _30273 = (int)*(((s1_ptr)_2)->base + 4);
    _30272 = NOVALUE;
    if (IS_ATOM_INT(_30273)) {
        _30274 = (_30273 == 7);
    }
    else {
        _30274 = binary_op(EQUALS, _30273, 7);
    }
    _30273 = NOVALUE;
    if (IS_ATOM_INT(_30274)) {
        if (_30274 != 0) {
            goto LD; // [495] 522
        }
    }
    else {
        if (DBL_PTR(_30274)->dbl != 0.0) {
            goto LD; // [495] 522
        }
    }
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _30276 = (int)*(((s1_ptr)_2)->base + _p_59988);
    _2 = (int)SEQ_PTR(_30276);
    _30277 = (int)*(((s1_ptr)_2)->base + 4);
    _30276 = NOVALUE;
    if (IS_ATOM_INT(_30277)) {
        _30278 = (_30277 == 12);
    }
    else {
        _30278 = binary_op(EQUALS, _30277, 12);
    }
    _30277 = NOVALUE;
    if (_30278 == 0) {
        DeRef(_30278);
        _30278 = NOVALUE;
        goto LE; // [518] 596
    }
    else {
        if (!IS_ATOM_INT(_30278) && DBL_PTR(_30278)->dbl == 0.0){
            DeRef(_30278);
            _30278 = NOVALUE;
            goto LE; // [518] 596
        }
        DeRef(_30278);
        _30278 = NOVALUE;
    }
    DeRef(_30278);
    _30278 = NOVALUE;
LD: 

    /** 					if SymTab[p][S_SCOPE] = SC_OVERRIDE then*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _30279 = (int)*(((s1_ptr)_2)->base + _p_59988);
    _2 = (int)SEQ_PTR(_30279);
    _30280 = (int)*(((s1_ptr)_2)->base + 4);
    _30279 = NOVALUE;
    if (binary_op_a(NOTEQ, _30280, 12)){
        _30280 = NOVALUE;
        goto LF; // [538] 550
    }
    _30280 = NOVALUE;

    /** 						again = 223*/
    _again_59995 = 223;
    goto L10; // [547] 556
LF: 

    /** 						again = 222*/
    _again_59995 = 222;
L10: 

    /** 					Warning(again, override_warning_flag,*/
    _2 = (int)SEQ_PTR(_36known_files_15243);
    _30282 = (int)*(((s1_ptr)_2)->base + _35current_file_no_16244);
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _30283 = (int)*(((s1_ptr)_2)->base + _p_59988);
    _2 = (int)SEQ_PTR(_30283);
    if (!IS_ATOM_INT(_35S_NAME_15917)){
        _30284 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15917)->dbl));
    }
    else{
        _30284 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15917);
    }
    _30283 = NOVALUE;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_30282);
    *((int *)(_2+4)) = _30282;
    *((int *)(_2+8)) = _35line_number_16245;
    Ref(_30284);
    *((int *)(_2+12)) = _30284;
    _30285 = MAKE_SEQ(_1);
    _30284 = NOVALUE;
    _30282 = NOVALUE;
    _44Warning(_again_59995, 4, _30285);
    _30285 = NOVALUE;
LE: 
LC: 

    /** 		h = SymTab[p][S_HASHVAL]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _30286 = (int)*(((s1_ptr)_2)->base + _p_59988);
    _2 = (int)SEQ_PTR(_30286);
    _h_59985 = (int)*(((s1_ptr)_2)->base + 11);
    if (!IS_ATOM_INT(_h_59985)){
        _h_59985 = (long)DBL_PTR(_h_59985)->dbl;
    }
    _30286 = NOVALUE;

    /** 		sym = buckets[h]*/
    _2 = (int)SEQ_PTR(_53buckets_46087);
    _sym_59990 = (int)*(((s1_ptr)_2)->base + _h_59985);
    if (!IS_ATOM_INT(_sym_59990)){
        _sym_59990 = (long)DBL_PTR(_sym_59990)->dbl;
    }

    /** 		p = NewEntry(SymTab[p][S_NAME], 0, 0, pt, h, sym, 0)*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _30289 = (int)*(((s1_ptr)_2)->base + _p_59988);
    _2 = (int)SEQ_PTR(_30289);
    if (!IS_ATOM_INT(_35S_NAME_15917)){
        _30290 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15917)->dbl));
    }
    else{
        _30290 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15917);
    }
    _30289 = NOVALUE;
    Ref(_30290);
    _p_59988 = _53NewEntry(_30290, 0, 0, _pt_59986, _h_59985, _sym_59990, 0);
    _30290 = NOVALUE;
    if (!IS_ATOM_INT(_p_59988)) {
        _1 = (long)(DBL_PTR(_p_59988)->dbl);
        DeRefDS(_p_59988);
        _p_59988 = _1;
    }

    /** 		buckets[h] = p*/
    _2 = (int)SEQ_PTR(_53buckets_46087);
    _2 = (int)(((s1_ptr)_2)->base + _h_59985);
    _1 = *(int *)_2;
    *(int *)_2 = _p_59988;
    DeRef(_1);
LB: 

    /** 	Start_block( pt, p )*/
    _66Start_block(_pt_59986, _p_59988);

    /** 	CurrentSub = p*/
    _35CurrentSub_16252 = _p_59988;

    /** 	first_def_arg = 0*/
    _first_def_arg_59994 = 0;

    /** 	temps_allocated = 0*/
    _53temps_allocated_46611 = 0;

    /** 	SymTab[p][S_SCOPE] = scope*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_59988 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = _scope_59984;
    DeRef(_1);
    _30292 = NOVALUE;

    /** 	SymTab[p][S_TOKEN] = pt*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_59988 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35S_TOKEN_15922))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TOKEN_15922)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _35S_TOKEN_15922);
    _1 = *(int *)_2;
    *(int *)_2 = _pt_59986;
    DeRef(_1);
    _30294 = NOVALUE;

    /** 	if length(SymTab[p]) < SIZEOF_ROUTINE_ENTRY then*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _30296 = (int)*(((s1_ptr)_2)->base + _p_59988);
    if (IS_SEQUENCE(_30296)){
            _30297 = SEQ_PTR(_30296)->length;
    }
    else {
        _30297 = 1;
    }
    _30296 = NOVALUE;
    if (_30297 >= _35SIZEOF_ROUTINE_ENTRY_16043)
    goto L11; // [730] 772

    /** 		SymTab[p] = SymTab[p] & repeat(0, SIZEOF_ROUTINE_ENTRY -*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _30299 = (int)*(((s1_ptr)_2)->base + _p_59988);
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _30300 = (int)*(((s1_ptr)_2)->base + _p_59988);
    if (IS_SEQUENCE(_30300)){
            _30301 = SEQ_PTR(_30300)->length;
    }
    else {
        _30301 = 1;
    }
    _30300 = NOVALUE;
    _30302 = _35SIZEOF_ROUTINE_ENTRY_16043 - _30301;
    _30301 = NOVALUE;
    _30303 = Repeat(0, _30302);
    _30302 = NOVALUE;
    if (IS_SEQUENCE(_30299) && IS_ATOM(_30303)) {
    }
    else if (IS_ATOM(_30299) && IS_SEQUENCE(_30303)) {
        Ref(_30299);
        Prepend(&_30304, _30303, _30299);
    }
    else {
        Concat((object_ptr)&_30304, _30299, _30303);
        _30299 = NOVALUE;
    }
    _30299 = NOVALUE;
    DeRefDS(_30303);
    _30303 = NOVALUE;
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _p_59988);
    _1 = *(int *)_2;
    *(int *)_2 = _30304;
    if( _1 != _30304 ){
        DeRef(_1);
    }
    _30304 = NOVALUE;
L11: 

    /** 	SymTab[p][S_CODE] = 0*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_59988 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35S_CODE_15929))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_CODE_15929)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _35S_CODE_15929);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _30305 = NOVALUE;

    /** 	SymTab[p][S_LINETAB] = 0*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_59988 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35S_LINETAB_15952))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_LINETAB_15952)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _35S_LINETAB_15952);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _30307 = NOVALUE;

    /** 	SymTab[p][S_EFFECT] = E_PURE*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_59988 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 23);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _30309 = NOVALUE;

    /** 	SymTab[p][S_REFLIST] = {}*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_59988 + ((s1_ptr)_2)->base);
    RefDS(_22023);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 24);
    _1 = *(int *)_2;
    *(int *)_2 = _22023;
    DeRef(_1);
    _30311 = NOVALUE;

    /** 	SymTab[p][S_FIRSTLINE] = gline_number*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_59988 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35S_FIRSTLINE_15957))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FIRSTLINE_15957)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _35S_FIRSTLINE_15957);
    _1 = *(int *)_2;
    *(int *)_2 = _35gline_number_16249;
    DeRef(_1);
    _30313 = NOVALUE;

    /** 	SymTab[p][S_TEMPS] = 0*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_59988 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35S_TEMPS_15962))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TEMPS_15962)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _35S_TEMPS_15962);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _30315 = NOVALUE;

    /** 	SymTab[p][S_RESIDENT_TASK] = 0*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_59988 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 25);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _30317 = NOVALUE;

    /** 	SymTab[p][S_SAVED_PRIVATES] = {}*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_59988 + ((s1_ptr)_2)->base);
    RefDS(_22023);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 26);
    _1 = *(int *)_2;
    *(int *)_2 = _22023;
    DeRef(_1);
    _30319 = NOVALUE;

    /** 	if type_enum then*/
    if (_type_enum_59996 == 0)
    {
        goto L12; // [898] 955
    }
    else{
    }

    /** 		SymTab[p][S_FIRSTLINE] = type_enum_gline*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_59988 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35S_FIRSTLINE_15957))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FIRSTLINE_15957)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _35S_FIRSTLINE_15957);
    _1 = *(int *)_2;
    *(int *)_2 = _type_enum_gline_60000;
    DeRef(_1);
    _30321 = NOVALUE;

    /** 		real_gline = gline_number*/
    _real_gline_60001 = _35gline_number_16249;

    /** 		gline_number = type_enum_gline*/
    _35gline_number_16249 = _type_enum_gline_60000;

    /** 		StartSourceLine( FALSE, , COVERAGE_OVERRIDE )*/
    _41StartSourceLine(_13FALSE_434, 0, 3);

    /** 		gline_number = real_gline*/
    _35gline_number_16249 = _real_gline_60001;
    goto L13; // [952] 967
L12: 

    /** 		StartSourceLine(FALSE, , COVERAGE_OVERRIDE)*/
    _41StartSourceLine(_13FALSE_434, 0, 3);
L13: 

    /** 	tok_match(LEFT_ROUND)*/
    _39tok_match(-26, 0);

    /** 	tok = next_token()*/
    _0 = _tok_59992;
    _tok_59992 = _39next_token();
    DeRef(_0);

    /** 	param_num = 0*/
    _39param_num_54126 = 0;

    /** 	sequence middle_def_args = {}*/
    RefDS(_22023);
    DeRef(_middle_def_args_60222);
    _middle_def_args_60222 = _22023;

    /** 	integer last_nda = 0, start_def = 0*/
    _last_nda_60223 = 0;
    _start_def_60224 = 0;

    /** 	symtab_index last_link = p*/
    _last_link_60226 = _p_59988;

    /** 	while tok[T_ID] != RIGHT_ROUND do*/
L14: 
    _2 = (int)SEQ_PTR(_tok_59992);
    _30324 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _30324, -27)){
        _30324 = NOVALUE;
        goto L15; // [1020] 1793
    }
    _30324 = NOVALUE;

    /** 		if tok[T_ID] != TYPE and tok[T_ID] != QUALIFIED_TYPE then*/
    _2 = (int)SEQ_PTR(_tok_59992);
    _30326 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_30326)) {
        _30327 = (_30326 != 504);
    }
    else {
        _30327 = binary_op(NOTEQ, _30326, 504);
    }
    _30326 = NOVALUE;
    if (IS_ATOM_INT(_30327)) {
        if (_30327 == 0) {
            goto L16; // [1038] 1262
        }
    }
    else {
        if (DBL_PTR(_30327)->dbl == 0.0) {
            goto L16; // [1038] 1262
        }
    }
    _2 = (int)SEQ_PTR(_tok_59992);
    _30329 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_30329)) {
        _30330 = (_30329 != 522);
    }
    else {
        _30330 = binary_op(NOTEQ, _30329, 522);
    }
    _30329 = NOVALUE;
    if (_30330 == 0) {
        DeRef(_30330);
        _30330 = NOVALUE;
        goto L16; // [1055] 1262
    }
    else {
        if (!IS_ATOM_INT(_30330) && DBL_PTR(_30330)->dbl == 0.0){
            DeRef(_30330);
            _30330 = NOVALUE;
            goto L16; // [1055] 1262
        }
        DeRef(_30330);
        _30330 = NOVALUE;
    }
    DeRef(_30330);
    _30330 = NOVALUE;

    /** 			if tok[T_ID] = VARIABLE or tok[T_ID] = QUALIFIED_VARIABLE then*/
    _2 = (int)SEQ_PTR(_tok_59992);
    _30331 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_30331)) {
        _30332 = (_30331 == -100);
    }
    else {
        _30332 = binary_op(EQUALS, _30331, -100);
    }
    _30331 = NOVALUE;
    if (IS_ATOM_INT(_30332)) {
        if (_30332 != 0) {
            goto L17; // [1072] 1093
        }
    }
    else {
        if (DBL_PTR(_30332)->dbl != 0.0) {
            goto L17; // [1072] 1093
        }
    }
    _2 = (int)SEQ_PTR(_tok_59992);
    _30334 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_30334)) {
        _30335 = (_30334 == 512);
    }
    else {
        _30335 = binary_op(EQUALS, _30334, 512);
    }
    _30334 = NOVALUE;
    if (_30335 == 0) {
        DeRef(_30335);
        _30335 = NOVALUE;
        goto L18; // [1089] 1253
    }
    else {
        if (!IS_ATOM_INT(_30335) && DBL_PTR(_30335)->dbl == 0.0){
            DeRef(_30335);
            _30335 = NOVALUE;
            goto L18; // [1089] 1253
        }
        DeRef(_30335);
        _30335 = NOVALUE;
    }
    DeRef(_30335);
    _30335 = NOVALUE;
L17: 

    /** 				token temptok = next_token()*/
    _0 = _temptok_60253;
    _temptok_60253 = _39next_token();
    DeRef(_0);

    /** 				integer undef_type = 0*/
    _undef_type_60255 = 0;

    /** 				if temptok[T_ID] != TYPE and temptok[T_ID] != QUALIFIED_TYPE then*/
    _2 = (int)SEQ_PTR(_temptok_60253);
    _30337 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_30337)) {
        _30338 = (_30337 != 504);
    }
    else {
        _30338 = binary_op(NOTEQ, _30337, 504);
    }
    _30337 = NOVALUE;
    if (IS_ATOM_INT(_30338)) {
        if (_30338 == 0) {
            goto L19; // [1117] 1218
        }
    }
    else {
        if (DBL_PTR(_30338)->dbl == 0.0) {
            goto L19; // [1117] 1218
        }
    }
    _2 = (int)SEQ_PTR(_temptok_60253);
    _30340 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_30340)) {
        _30341 = (_30340 != 522);
    }
    else {
        _30341 = binary_op(NOTEQ, _30340, 522);
    }
    _30340 = NOVALUE;
    if (_30341 == 0) {
        DeRef(_30341);
        _30341 = NOVALUE;
        goto L19; // [1134] 1218
    }
    else {
        if (!IS_ATOM_INT(_30341) && DBL_PTR(_30341)->dbl == 0.0){
            DeRef(_30341);
            _30341 = NOVALUE;
            goto L19; // [1134] 1218
        }
        DeRef(_30341);
        _30341 = NOVALUE;
    }
    DeRef(_30341);
    _30341 = NOVALUE;

    /** 					if find( temptok[T_ID], FULL_ID_TOKS) then*/
    _2 = (int)SEQ_PTR(_temptok_60253);
    _30342 = (int)*(((s1_ptr)_2)->base + 1);
    _30343 = find_from(_30342, _37FULL_ID_TOKS_15878, 1);
    _30342 = NOVALUE;
    if (_30343 == 0)
    {
        _30343 = NOVALUE;
        goto L1A; // [1152] 1217
    }
    else{
        _30343 = NOVALUE;
    }

    /** 						if SymTab[tok[T_SYM]][S_SCOPE] = SC_UNDEFINED then*/
    _2 = (int)SEQ_PTR(_tok_59992);
    _30344 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!IS_ATOM_INT(_30344)){
        _30345 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_30344)->dbl));
    }
    else{
        _30345 = (int)*(((s1_ptr)_2)->base + _30344);
    }
    _2 = (int)SEQ_PTR(_30345);
    _30346 = (int)*(((s1_ptr)_2)->base + 4);
    _30345 = NOVALUE;
    if (binary_op_a(NOTEQ, _30346, 9)){
        _30346 = NOVALUE;
        goto L1B; // [1177] 1208
    }
    _30346 = NOVALUE;

    /** 							undef_type = - new_forward_reference( TYPE, tok[T_SYM] )*/
    _2 = (int)SEQ_PTR(_tok_59992);
    _30348 = (int)*(((s1_ptr)_2)->base + 2);
    DeRef(_31635);
    _31635 = 504;
    Ref(_30348);
    _30349 = _38new_forward_reference(504, _30348, 504);
    _30348 = NOVALUE;
    _31635 = NOVALUE;
    if (IS_ATOM_INT(_30349)) {
        if ((unsigned long)_30349 == 0xC0000000)
        _undef_type_60255 = (int)NewDouble((double)-0xC0000000);
        else
        _undef_type_60255 = - _30349;
    }
    else {
        _undef_type_60255 = unary_op(UMINUS, _30349);
    }
    DeRef(_30349);
    _30349 = NOVALUE;
    if (!IS_ATOM_INT(_undef_type_60255)) {
        _1 = (long)(DBL_PTR(_undef_type_60255)->dbl);
        DeRefDS(_undef_type_60255);
        _undef_type_60255 = _1;
    }
    goto L1C; // [1205] 1216
L1B: 

    /** 							CompileErr(37)*/
    RefDS(_22023);
    _44CompileErr(37, _22023, 0);
L1C: 
L1A: 
L19: 

    /** 				putback(temptok) -- Return whatever came after the name back onto the token stream.*/
    Ref(_temptok_60253);
    _39putback(_temptok_60253);

    /** 				if undef_type != 0 then*/
    if (_undef_type_60255 == 0)
    goto L1D; // [1225] 1240

    /** 					tok[T_SYM] = undef_type*/
    _2 = (int)SEQ_PTR(_tok_59992);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _tok_59992 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _undef_type_60255;
    DeRef(_1);
    goto L1E; // [1237] 1248
L1D: 

    /** 					CompileErr(37)*/
    RefDS(_22023);
    _44CompileErr(37, _22023, 0);
L1E: 
    DeRef(_temptok_60253);
    _temptok_60253 = NOVALUE;
    goto L1F; // [1250] 1261
L18: 

    /** 				CompileErr(37)*/
    RefDS(_22023);
    _44CompileErr(37, _22023, 0);
L1F: 
L16: 

    /** 		type_sym = tok[T_SYM]*/
    _2 = (int)SEQ_PTR(_tok_59992);
    _type_sym_59989 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_type_sym_59989)){
        _type_sym_59989 = (long)DBL_PTR(_type_sym_59989)->dbl;
    }

    /** 		tok = next_token()*/
    _0 = _tok_59992;
    _tok_59992 = _39next_token();
    DeRef(_0);

    /** 		if not find(tok[T_ID], ID_TOKS) then*/
    _2 = (int)SEQ_PTR(_tok_59992);
    _30354 = (int)*(((s1_ptr)_2)->base + 1);
    _30355 = find_from(_30354, _37ID_TOKS_15876, 1);
    _30354 = NOVALUE;
    if (_30355 != 0)
    goto L20; // [1292] 1406
    _30355 = NOVALUE;

    /** 			sequence tokcat = find_category(tok[T_ID])*/
    _2 = (int)SEQ_PTR(_tok_59992);
    _30357 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_30357);
    _0 = _tokcat_60304;
    _tokcat_60304 = _63find_category(_30357);
    DeRef(_0);
    _30357 = NOVALUE;

    /** 			if tok[T_SYM] != 0 and length(SymTab[tok[T_SYM]]) >= S_NAME then*/
    _2 = (int)SEQ_PTR(_tok_59992);
    _30359 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_30359)) {
        _30360 = (_30359 != 0);
    }
    else {
        _30360 = binary_op(NOTEQ, _30359, 0);
    }
    _30359 = NOVALUE;
    if (IS_ATOM_INT(_30360)) {
        if (_30360 == 0) {
            goto L21; // [1321] 1382
        }
    }
    else {
        if (DBL_PTR(_30360)->dbl == 0.0) {
            goto L21; // [1321] 1382
        }
    }
    _2 = (int)SEQ_PTR(_tok_59992);
    _30362 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!IS_ATOM_INT(_30362)){
        _30363 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_30362)->dbl));
    }
    else{
        _30363 = (int)*(((s1_ptr)_2)->base + _30362);
    }
    if (IS_SEQUENCE(_30363)){
            _30364 = SEQ_PTR(_30363)->length;
    }
    else {
        _30364 = 1;
    }
    _30363 = NOVALUE;
    if (IS_ATOM_INT(_35S_NAME_15917)) {
        _30365 = (_30364 >= _35S_NAME_15917);
    }
    else {
        _30365 = binary_op(GREATEREQ, _30364, _35S_NAME_15917);
    }
    _30364 = NOVALUE;
    if (_30365 == 0) {
        DeRef(_30365);
        _30365 = NOVALUE;
        goto L21; // [1347] 1382
    }
    else {
        if (!IS_ATOM_INT(_30365) && DBL_PTR(_30365)->dbl == 0.0){
            DeRef(_30365);
            _30365 = NOVALUE;
            goto L21; // [1347] 1382
        }
        DeRef(_30365);
        _30365 = NOVALUE;
    }
    DeRef(_30365);
    _30365 = NOVALUE;

    /** 				CompileErr(90, {tokcat, SymTab[tok[T_SYM]][S_NAME]})*/
    _2 = (int)SEQ_PTR(_tok_59992);
    _30366 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!IS_ATOM_INT(_30366)){
        _30367 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_30366)->dbl));
    }
    else{
        _30367 = (int)*(((s1_ptr)_2)->base + _30366);
    }
    _2 = (int)SEQ_PTR(_30367);
    if (!IS_ATOM_INT(_35S_NAME_15917)){
        _30368 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15917)->dbl));
    }
    else{
        _30368 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15917);
    }
    _30367 = NOVALUE;
    Ref(_30368);
    RefDS(_tokcat_60304);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _tokcat_60304;
    ((int *)_2)[2] = _30368;
    _30369 = MAKE_SEQ(_1);
    _30368 = NOVALUE;
    _44CompileErr(90, _30369, 0);
    _30369 = NOVALUE;
    goto L22; // [1379] 1405
L21: 

    /** 				CompileErr(92, {LexName(tok[T_ID])})*/
    _2 = (int)SEQ_PTR(_tok_59992);
    _30370 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_30370);
    RefDS(_26467);
    _30371 = _41LexName(_30370, _26467);
    _30370 = NOVALUE;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _30371;
    _30372 = MAKE_SEQ(_1);
    _30371 = NOVALUE;
    _44CompileErr(92, _30372, 0);
    _30372 = NOVALUE;
L22: 
L20: 
    DeRef(_tokcat_60304);
    _tokcat_60304 = NOVALUE;

    /** 		sym = SetPrivateScope(tok[T_SYM], type_sym, param_num)*/
    _2 = (int)SEQ_PTR(_tok_59992);
    _30373 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_30373);
    _sym_59990 = _39SetPrivateScope(_30373, _type_sym_59989, _39param_num_54126);
    _30373 = NOVALUE;
    if (!IS_ATOM_INT(_sym_59990)) {
        _1 = (long)(DBL_PTR(_sym_59990)->dbl);
        DeRefDS(_sym_59990);
        _sym_59990 = _1;
    }

    /** 		param_num += 1*/
    _39param_num_54126 = _39param_num_54126 + 1;

    /** 		if SymTab[last_link][S_NEXT] != sym*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _30376 = (int)*(((s1_ptr)_2)->base + _last_link_60226);
    _2 = (int)SEQ_PTR(_30376);
    _30377 = (int)*(((s1_ptr)_2)->base + 2);
    _30376 = NOVALUE;
    if (IS_ATOM_INT(_30377)) {
        _30378 = (_30377 != _sym_59990);
    }
    else {
        _30378 = binary_op(NOTEQ, _30377, _sym_59990);
    }
    _30377 = NOVALUE;
    if (IS_ATOM_INT(_30378)) {
        if (_30378 == 0) {
            goto L23; // [1452] 1533
        }
    }
    else {
        if (DBL_PTR(_30378)->dbl == 0.0) {
            goto L23; // [1452] 1533
        }
    }
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _30380 = (int)*(((s1_ptr)_2)->base + _last_link_60226);
    _2 = (int)SEQ_PTR(_30380);
    _30381 = (int)*(((s1_ptr)_2)->base + 2);
    _30380 = NOVALUE;
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!IS_ATOM_INT(_30381)){
        _30382 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_30381)->dbl));
    }
    else{
        _30382 = (int)*(((s1_ptr)_2)->base + _30381);
    }
    _2 = (int)SEQ_PTR(_30382);
    _30383 = (int)*(((s1_ptr)_2)->base + 4);
    _30382 = NOVALUE;
    if (IS_ATOM_INT(_30383)) {
        _30384 = (_30383 == 9);
    }
    else {
        _30384 = binary_op(EQUALS, _30383, 9);
    }
    _30383 = NOVALUE;
    if (_30384 == 0) {
        DeRef(_30384);
        _30384 = NOVALUE;
        goto L23; // [1487] 1533
    }
    else {
        if (!IS_ATOM_INT(_30384) && DBL_PTR(_30384)->dbl == 0.0){
            DeRef(_30384);
            _30384 = NOVALUE;
            goto L23; // [1487] 1533
        }
        DeRef(_30384);
        _30384 = NOVALUE;
    }
    DeRef(_30384);
    _30384 = NOVALUE;

    /** 			SymTab[SymTab[last_link][S_NEXT]][S_NEXT] = 0*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _30385 = (int)*(((s1_ptr)_2)->base + _last_link_60226);
    _2 = (int)SEQ_PTR(_30385);
    _30386 = (int)*(((s1_ptr)_2)->base + 2);
    _30385 = NOVALUE;
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_30386))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_30386)->dbl));
    else
    _3 = (int)(_30386 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _30387 = NOVALUE;

    /** 			SymTab[last_link][S_NEXT] = sym*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_last_link_60226 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _sym_59990;
    DeRef(_1);
    _30389 = NOVALUE;
L23: 

    /** 		last_link = sym*/
    _last_link_60226 = _sym_59990;

    /** 		if TRANSLATE then*/
    if (_35TRANSLATE_15887 == 0)
    {
        goto L24; // [1544] 1567
    }
    else{
    }

    /** 			SymTab[sym][S_GTYPE] = CompileType(type_sym)*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_59990 + ((s1_ptr)_2)->base);
    _30393 = _39CompileType(_type_sym_59989);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 36);
    _1 = *(int *)_2;
    *(int *)_2 = _30393;
    if( _1 != _30393 ){
        DeRef(_1);
    }
    _30393 = NOVALUE;
    _30391 = NOVALUE;
L24: 

    /** 		tok = next_token()*/
    _0 = _tok_59992;
    _tok_59992 = _39next_token();
    DeRef(_0);

    /** 		if tok[T_ID] = EQUALS then -- defaulted parameter*/
    _2 = (int)SEQ_PTR(_tok_59992);
    _30395 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30395, 3)){
        _30395 = NOVALUE;
        goto L25; // [1582] 1664
    }
    _30395 = NOVALUE;

    /** 			start_recording()*/
    _39start_recording();

    /** 			Expr()*/
    _39Expr();

    /** 			SymTab[sym][S_CODE] = restore_parser()*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_59990 + ((s1_ptr)_2)->base);
    _30399 = _39restore_parser();
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35S_CODE_15929))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_CODE_15929)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _35S_CODE_15929);
    _1 = *(int *)_2;
    *(int *)_2 = _30399;
    if( _1 != _30399 ){
        DeRef(_1);
    }
    _30399 = NOVALUE;
    _30397 = NOVALUE;

    /** 			if Pop() then end if -- don't leak the default argument*/
    _30400 = _41Pop();
    if (_30400 == 0) {
        DeRef(_30400);
        _30400 = NOVALUE;
        goto L26; // [1617] 1621
    }
    else {
        if (!IS_ATOM_INT(_30400) && DBL_PTR(_30400)->dbl == 0.0){
            DeRef(_30400);
            _30400 = NOVALUE;
            goto L26; // [1617] 1621
        }
        DeRef(_30400);
        _30400 = NOVALUE;
    }
    DeRef(_30400);
    _30400 = NOVALUE;
L26: 

    /** 			tok = next_token()*/
    _0 = _tok_59992;
    _tok_59992 = _39next_token();
    DeRef(_0);

    /** 			if first_def_arg = 0 then*/
    if (_first_def_arg_59994 != 0)
    goto L27; // [1628] 1640

    /** 				first_def_arg = param_num*/
    _first_def_arg_59994 = _39param_num_54126;
L27: 

    /** 			previous_op = -1 -- no interferences betwen defparms, or them and subsequent code*/
    _35previous_op_16342 = -1;

    /** 			if start_def = 0 then*/
    if (_start_def_60224 != 0)
    goto L28; // [1649] 1721

    /** 				start_def = param_num*/
    _start_def_60224 = _39param_num_54126;
    goto L28; // [1661] 1721
L25: 

    /** 			last_nda = param_num*/
    _last_nda_60223 = _39param_num_54126;

    /** 			if start_def then*/
    if (_start_def_60224 == 0)
    {
        goto L29; // [1673] 1720
    }
    else{
    }

    /** 				if start_def = param_num-1 then*/
    _30404 = _39param_num_54126 - 1;
    if ((long)((unsigned long)_30404 +(unsigned long) HIGH_BITS) >= 0){
        _30404 = NewDouble((double)_30404);
    }
    if (binary_op_a(NOTEQ, _start_def_60224, _30404)){
        DeRef(_30404);
        _30404 = NOVALUE;
        goto L2A; // [1684] 1697
    }
    DeRef(_30404);
    _30404 = NOVALUE;

    /** 					middle_def_args &= start_def*/
    Append(&_middle_def_args_60222, _middle_def_args_60222, _start_def_60224);
    goto L2B; // [1694] 1714
L2A: 

    /** 					middle_def_args = append(middle_def_args, {start_def, param_num-1})*/
    _30407 = _39param_num_54126 - 1;
    if ((long)((unsigned long)_30407 +(unsigned long) HIGH_BITS) >= 0){
        _30407 = NewDouble((double)_30407);
    }
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _start_def_60224;
    ((int *)_2)[2] = _30407;
    _30408 = MAKE_SEQ(_1);
    _30407 = NOVALUE;
    RefDS(_30408);
    Append(&_middle_def_args_60222, _middle_def_args_60222, _30408);
    DeRefDS(_30408);
    _30408 = NOVALUE;
L2B: 

    /** 				start_def = 0*/
    _start_def_60224 = 0;
L29: 
L28: 

    /** 		if tok[T_ID] = COMMA then*/
    _2 = (int)SEQ_PTR(_tok_59992);
    _30410 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30410, -30)){
        _30410 = NOVALUE;
        goto L2C; // [1731] 1765
    }
    _30410 = NOVALUE;

    /** 			tok = next_token()*/
    _0 = _tok_59992;
    _tok_59992 = _39next_token();
    DeRef(_0);

    /** 			if tok[T_ID] = RIGHT_ROUND then*/
    _2 = (int)SEQ_PTR(_tok_59992);
    _30413 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30413, -27)){
        _30413 = NOVALUE;
        goto L14; // [1750] 1012
    }
    _30413 = NOVALUE;

    /** 				CompileErr(85)*/
    RefDS(_22023);
    _44CompileErr(85, _22023, 0);
    goto L14; // [1762] 1012
L2C: 

    /** 		elsif tok[T_ID] != RIGHT_ROUND then*/
    _2 = (int)SEQ_PTR(_tok_59992);
    _30415 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _30415, -27)){
        _30415 = NOVALUE;
        goto L14; // [1775] 1012
    }
    _30415 = NOVALUE;

    /** 			CompileErr(41)*/
    RefDS(_22023);
    _44CompileErr(41, _22023, 0);

    /** 	end while*/
    goto L14; // [1790] 1012
L15: 

    /** 	Code = {} -- removes any spurious code emitted while recording parameters*/
    RefDS(_22023);
    DeRef(_35Code_16332);
    _35Code_16332 = _22023;

    /** 	SymTab[p][S_NUM_ARGS] = param_num*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_59988 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35S_NUM_ARGS_15968))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NUM_ARGS_15968)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _35S_NUM_ARGS_15968);
    _1 = *(int *)_2;
    *(int *)_2 = _39param_num_54126;
    DeRef(_1);
    _30417 = NOVALUE;

    /** 	SymTab[p][S_DEF_ARGS] = {first_def_arg, last_nda, middle_def_args}*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_59988 + ((s1_ptr)_2)->base);
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _first_def_arg_59994;
    *((int *)(_2+8)) = _last_nda_60223;
    RefDS(_middle_def_args_60222);
    *((int *)(_2+12)) = _middle_def_args_60222;
    _30421 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 28);
    _1 = *(int *)_2;
    *(int *)_2 = _30421;
    if( _1 != _30421 ){
        DeRef(_1);
    }
    _30421 = NOVALUE;
    _30419 = NOVALUE;

    /** 	if TRANSLATE then*/
    if (_35TRANSLATE_15887 == 0)
    {
        goto L2D; // [1842] 1876
    }
    else{
    }

    /** 		if param_num > max_params then*/
    if (_39param_num_54126 <= _41max_params_50228)
    goto L2E; // [1851] 1865

    /** 			max_params = param_num*/
    _41max_params_50228 = _39param_num_54126;
L2E: 

    /** 		num_routines += 1*/
    _35num_routines_16253 = _35num_routines_16253 + 1;
L2D: 

    /** 	if SymTab[p][S_TOKEN] = TYPE and param_num != 1 then*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _30424 = (int)*(((s1_ptr)_2)->base + _p_59988);
    _2 = (int)SEQ_PTR(_30424);
    if (!IS_ATOM_INT(_35S_TOKEN_15922)){
        _30425 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TOKEN_15922)->dbl));
    }
    else{
        _30425 = (int)*(((s1_ptr)_2)->base + _35S_TOKEN_15922);
    }
    _30424 = NOVALUE;
    if (IS_ATOM_INT(_30425)) {
        _30426 = (_30425 == 504);
    }
    else {
        _30426 = binary_op(EQUALS, _30425, 504);
    }
    _30425 = NOVALUE;
    if (IS_ATOM_INT(_30426)) {
        if (_30426 == 0) {
            goto L2F; // [1896] 1918
        }
    }
    else {
        if (DBL_PTR(_30426)->dbl == 0.0) {
            goto L2F; // [1896] 1918
        }
    }
    _30428 = (_39param_num_54126 != 1);
    if (_30428 == 0)
    {
        DeRef(_30428);
        _30428 = NOVALUE;
        goto L2F; // [1907] 1918
    }
    else{
        DeRef(_30428);
        _30428 = NOVALUE;
    }

    /** 		CompileErr(148)*/
    RefDS(_22023);
    _44CompileErr(148, _22023, 0);
L2F: 

    /** 	include_routine()*/
    _50include_routine();

    /** 	sym = SymTab[p][S_NEXT]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _30429 = (int)*(((s1_ptr)_2)->base + _p_59988);
    _2 = (int)SEQ_PTR(_30429);
    _sym_59990 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_sym_59990)){
        _sym_59990 = (long)DBL_PTR(_sym_59990)->dbl;
    }
    _30429 = NOVALUE;

    /** 	for i = 1 to SymTab[p][S_NUM_ARGS] do*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _30431 = (int)*(((s1_ptr)_2)->base + _p_59988);
    _2 = (int)SEQ_PTR(_30431);
    if (!IS_ATOM_INT(_35S_NUM_ARGS_15968)){
        _30432 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NUM_ARGS_15968)->dbl));
    }
    else{
        _30432 = (int)*(((s1_ptr)_2)->base + _35S_NUM_ARGS_15968);
    }
    _30431 = NOVALUE;
    {
        int _i_60458;
        _i_60458 = 1;
L30: 
        if (binary_op_a(GREATER, _i_60458, _30432)){
            goto L31; // [1952] 2031
        }

        /** 		while SymTab[sym][S_SCOPE] != SC_PRIVATE do*/
L32: 
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _30433 = (int)*(((s1_ptr)_2)->base + _sym_59990);
        _2 = (int)SEQ_PTR(_30433);
        _30434 = (int)*(((s1_ptr)_2)->base + 4);
        _30433 = NOVALUE;
        if (binary_op_a(EQUALS, _30434, 3)){
            _30434 = NOVALUE;
            goto L33; // [1978] 2003
        }
        _30434 = NOVALUE;

        /** 			sym = SymTab[sym][S_NEXT]*/
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _30436 = (int)*(((s1_ptr)_2)->base + _sym_59990);
        _2 = (int)SEQ_PTR(_30436);
        _sym_59990 = (int)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_sym_59990)){
            _sym_59990 = (long)DBL_PTR(_sym_59990)->dbl;
        }
        _30436 = NOVALUE;

        /** 		end while*/
        goto L32; // [2000] 1964
L33: 

        /** 		TypeCheck(sym)*/
        _39TypeCheck(_sym_59990);

        /** 		sym = SymTab[sym][S_NEXT]*/
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _30438 = (int)*(((s1_ptr)_2)->base + _sym_59990);
        _2 = (int)SEQ_PTR(_30438);
        _sym_59990 = (int)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_sym_59990)){
            _sym_59990 = (long)DBL_PTR(_sym_59990)->dbl;
        }
        _30438 = NOVALUE;

        /** 	end for*/
        _0 = _i_60458;
        if (IS_ATOM_INT(_i_60458)) {
            _i_60458 = _i_60458 + 1;
            if ((long)((unsigned long)_i_60458 +(unsigned long) HIGH_BITS) >= 0){
                _i_60458 = NewDouble((double)_i_60458);
            }
        }
        else {
            _i_60458 = binary_op_a(PLUS, _i_60458, 1);
        }
        DeRef(_0);
        goto L30; // [2026] 1959
L31: 
        ;
        DeRef(_i_60458);
    }

    /** 	tok = next_token()*/
    _0 = _tok_59992;
    _tok_59992 = _39next_token();
    DeRef(_0);

    /** 	while tok[T_ID] = TYPE or tok[T_ID] = QUALIFIED_TYPE do*/
L34: 
    _2 = (int)SEQ_PTR(_tok_59992);
    _30441 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_30441)) {
        _30442 = (_30441 == 504);
    }
    else {
        _30442 = binary_op(EQUALS, _30441, 504);
    }
    _30441 = NOVALUE;
    if (IS_ATOM_INT(_30442)) {
        if (_30442 != 0) {
            goto L35; // [2053] 2074
        }
    }
    else {
        if (DBL_PTR(_30442)->dbl != 0.0) {
            goto L35; // [2053] 2074
        }
    }
    _2 = (int)SEQ_PTR(_tok_59992);
    _30444 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_30444)) {
        _30445 = (_30444 == 522);
    }
    else {
        _30445 = binary_op(EQUALS, _30444, 522);
    }
    _30444 = NOVALUE;
    if (_30445 <= 0) {
        if (_30445 == 0) {
            DeRef(_30445);
            _30445 = NOVALUE;
            goto L36; // [2070] 2095
        }
        else {
            if (!IS_ATOM_INT(_30445) && DBL_PTR(_30445)->dbl == 0.0){
                DeRef(_30445);
                _30445 = NOVALUE;
                goto L36; // [2070] 2095
            }
            DeRef(_30445);
            _30445 = NOVALUE;
        }
    }
    DeRef(_30445);
    _30445 = NOVALUE;
L35: 

    /** 		Private_declaration(tok[T_SYM])*/
    _2 = (int)SEQ_PTR(_tok_59992);
    _30446 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_30446);
    _39Private_declaration(_30446);
    _30446 = NOVALUE;

    /** 		tok = next_token()*/
    _0 = _tok_59992;
    _tok_59992 = _39next_token();
    DeRef(_0);

    /** 	end while*/
    goto L34; // [2092] 2041
L36: 

    /** 	if not TRANSLATE then*/
    if (_35TRANSLATE_15887 != 0)
    goto L37; // [2099] 2202

    /** 		if OpTrace then*/
    if (_35OpTrace_16313 == 0)
    {
        goto L38; // [2106] 2201
    }
    else{
    }

    /** 			emit_op(ERASE_PRIVATE_NAMES)*/
    _41emit_op(88);

    /** 			emit_addr(p)*/
    _41emit_addr(_p_59988);

    /** 			sym = SymTab[p][S_NEXT]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _30449 = (int)*(((s1_ptr)_2)->base + _p_59988);
    _2 = (int)SEQ_PTR(_30449);
    _sym_59990 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_sym_59990)){
        _sym_59990 = (long)DBL_PTR(_sym_59990)->dbl;
    }
    _30449 = NOVALUE;

    /** 			for i = 1 to SymTab[p][S_NUM_ARGS] do*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _30451 = (int)*(((s1_ptr)_2)->base + _p_59988);
    _2 = (int)SEQ_PTR(_30451);
    if (!IS_ATOM_INT(_35S_NUM_ARGS_15968)){
        _30452 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NUM_ARGS_15968)->dbl));
    }
    else{
        _30452 = (int)*(((s1_ptr)_2)->base + _35S_NUM_ARGS_15968);
    }
    _30451 = NOVALUE;
    {
        int _i_60505;
        _i_60505 = 1;
L39: 
        if (binary_op_a(GREATER, _i_60505, _30452)){
            goto L3A; // [2151] 2193
        }

        /** 				emit_op(DISPLAY_VAR)*/
        _41emit_op(87);

        /** 				emit_addr(sym)*/
        _41emit_addr(_sym_59990);

        /** 				sym = SymTab[sym][S_NEXT]*/
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _30453 = (int)*(((s1_ptr)_2)->base + _sym_59990);
        _2 = (int)SEQ_PTR(_30453);
        _sym_59990 = (int)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_sym_59990)){
            _sym_59990 = (long)DBL_PTR(_sym_59990)->dbl;
        }
        _30453 = NOVALUE;

        /** 			end for*/
        _0 = _i_60505;
        if (IS_ATOM_INT(_i_60505)) {
            _i_60505 = _i_60505 + 1;
            if ((long)((unsigned long)_i_60505 +(unsigned long) HIGH_BITS) >= 0){
                _i_60505 = NewDouble((double)_i_60505);
            }
        }
        else {
            _i_60505 = binary_op_a(PLUS, _i_60505, 1);
        }
        DeRef(_0);
        goto L39; // [2188] 2158
L3A: 
        ;
        DeRef(_i_60505);
    }

    /** 			emit_op(UPDATE_GLOBALS)*/
    _41emit_op(89);
L38: 
L37: 

    /** 	putback(tok)*/
    Ref(_tok_59992);
    _39putback(_tok_59992);

    /** 	FuncReturn = FALSE*/
    _39FuncReturn_54125 = _13FALSE_434;

    /** 	if type_enum then*/
    if (_type_enum_59996 == 0)
    {
        goto L3B; // [2218] 2387
    }
    else{
    }

    /** 		stmt_nest += 1*/
    _39stmt_nest_54149 = _39stmt_nest_54149 + 1;

    /** 		tok_match(RETURN)*/
    _39tok_match(413, 0);

    /** 		putback({RIGHT_ROUND,0})*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -27;
    ((int *)_2)[2] = 0;
    _30456 = MAKE_SEQ(_1);
    _39putback(_30456);
    _30456 = NOVALUE;

    /** 		putback({VARIABLE,seq_sym})*/
    Ref(_seq_sym_59997);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -100;
    ((int *)_2)[2] = _seq_sym_59997;
    _30457 = MAKE_SEQ(_1);
    _39putback(_30457);
    _30457 = NOVALUE;

    /** 		putback({COMMA,0})*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -30;
    ((int *)_2)[2] = 0;
    _30458 = MAKE_SEQ(_1);
    _39putback(_30458);
    _30458 = NOVALUE;

    /** 		putback(i1_sym)*/
    Ref(_i1_sym_59998);
    _39putback(_i1_sym_59998);

    /** 		putback({LEFT_ROUND,0})*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -26;
    ((int *)_2)[2] = 0;
    _30459 = MAKE_SEQ(_1);
    _39putback(_30459);
    _30459 = NOVALUE;

    /** 		putback(keyfind("find",-1))*/
    RefDS(_30460);
    DeRef(_31633);
    _31633 = _30460;
    _31634 = _53hashfn(_31633);
    _31633 = NOVALUE;
    RefDS(_30460);
    _30461 = _53keyfind(_30460, -1, _35current_file_no_16244, 0, _31634);
    _31634 = NOVALUE;
    _39putback(_30461);
    _30461 = NOVALUE;

    /** 		if not TRANSLATE then*/
    if (_35TRANSLATE_15887 != 0)
    goto L3C; // [2316] 2342

    /** 			if OpTrace then*/
    if (_35OpTrace_16313 == 0)
    {
        goto L3D; // [2323] 2341
    }
    else{
    }

    /** 				emit_op(ERASE_PRIVATE_NAMES)*/
    _41emit_op(88);

    /** 				emit_addr(CurrentSub)*/
    _41emit_addr(_35CurrentSub_16252);
L3D: 
L3C: 

    /** 		Expr()*/
    _39Expr();

    /** 		FuncReturn = TRUE*/
    _39FuncReturn_54125 = _13TRUE_436;

    /** 		emit_op(RETURNF)*/
    _41emit_op(28);

    /** 		flush_temps()*/
    RefDS(_22023);
    _41flush_temps(_22023);

    /** 		stmt_nest -= 1*/
    _39stmt_nest_54149 = _39stmt_nest_54149 - 1;

    /** 		InitDelete()*/
    _39InitDelete();

    /** 		flush_temps()*/
    RefDS(_22023);
    _41flush_temps(_22023);
    goto L3E; // [2384] 2400
L3B: 

    /** 		Statement_list()*/
    _39Statement_list();

    /** 		tok_match(END)*/
    _39tok_match(402, 0);
L3E: 

    /** 	tok_match(prog_type, END)*/
    _39tok_match(_prog_type_59983, 402);

    /** 	if prog_type != PROCEDURE then*/
    if (_prog_type_59983 == 405)
    goto L3F; // [2412] 2460

    /** 		if not FuncReturn then*/
    if (_39FuncReturn_54125 != 0)
    goto L40; // [2420] 2450

    /** 			if prog_type = FUNCTION then*/
    if (_prog_type_59983 != 406)
    goto L41; // [2427] 2441

    /** 				CompileErr(120)*/
    RefDS(_22023);
    _44CompileErr(120, _22023, 0);
    goto L42; // [2438] 2449
L41: 

    /** 				CompileErr(149)*/
    RefDS(_22023);
    _44CompileErr(149, _22023, 0);
L42: 
L40: 

    /** 		emit_op(BADRETURNF) -- function/type shouldn't reach here*/
    _41emit_op(43);
    goto L43; // [2457] 2520
L3F: 

    /** 		StartSourceLine(TRUE)*/
    _41StartSourceLine(_13TRUE_436, 0, 2);

    /** 		if not TRANSLATE then*/
    if (_35TRANSLATE_15887 != 0)
    goto L44; // [2473] 2497

    /** 			if OpTrace then*/
    if (_35OpTrace_16313 == 0)
    {
        goto L45; // [2480] 2496
    }
    else{
    }

    /** 				emit_op(ERASE_PRIVATE_NAMES)*/
    _41emit_op(88);

    /** 				emit_addr(p)*/
    _41emit_addr(_p_59988);
L45: 
L44: 

    /** 		emit_op(RETURNP)*/
    _41emit_op(29);

    /** 		if TRANSLATE then*/
    if (_35TRANSLATE_15887 == 0)
    {
        goto L46; // [2508] 2519
    }
    else{
    }

    /** 			emit_op(BADRETURNF) -- just to mark end of procedure*/
    _41emit_op(43);
L46: 
L43: 

    /** 	Drop_block( pt )*/
    _66Drop_block(_pt_59986);

    /** 	if Strict_Override > 0 then*/
    if (_35Strict_Override_16310 <= 0)
    goto L47; // [2529] 2544

    /** 		Strict_Override -= 1	-- Reset at the end of each routine.*/
    _35Strict_Override_16310 = _35Strict_Override_16310 - 1;
L47: 

    /** 	SymTab[p][S_STACK_SPACE] += temps_allocated + param_num*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_59988 + ((s1_ptr)_2)->base);
    _30473 = _53temps_allocated_46611 + _39param_num_54126;
    if ((long)((unsigned long)_30473 + (unsigned long)HIGH_BITS) >= 0) 
    _30473 = NewDouble((double)_30473);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!IS_ATOM_INT(_35S_STACK_SPACE_15977)){
        _30474 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_STACK_SPACE_15977)->dbl));
    }
    else{
        _30474 = (int)*(((s1_ptr)_2)->base + _35S_STACK_SPACE_15977);
    }
    _30471 = NOVALUE;
    if (IS_ATOM_INT(_30474) && IS_ATOM_INT(_30473)) {
        _30475 = _30474 + _30473;
        if ((long)((unsigned long)_30475 + (unsigned long)HIGH_BITS) >= 0) 
        _30475 = NewDouble((double)_30475);
    }
    else {
        _30475 = binary_op(PLUS, _30474, _30473);
    }
    _30474 = NOVALUE;
    DeRef(_30473);
    _30473 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35S_STACK_SPACE_15977))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_STACK_SPACE_15977)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _35S_STACK_SPACE_15977);
    _1 = *(int *)_2;
    *(int *)_2 = _30475;
    if( _1 != _30475 ){
        DeRef(_1);
    }
    _30475 = NOVALUE;
    _30471 = NOVALUE;

    /** 	if temps_allocated + param_num > max_stack_per_call then*/
    _30476 = _53temps_allocated_46611 + _39param_num_54126;
    if ((long)((unsigned long)_30476 + (unsigned long)HIGH_BITS) >= 0) 
    _30476 = NewDouble((double)_30476);
    if (binary_op_a(LESSEQ, _30476, _35max_stack_per_call_16343)){
        DeRef(_30476);
        _30476 = NOVALUE;
        goto L48; // [2587] 2604
    }
    DeRef(_30476);
    _30476 = NOVALUE;

    /** 		max_stack_per_call = temps_allocated + param_num*/
    _35max_stack_per_call_16343 = _53temps_allocated_46611 + _39param_num_54126;
L48: 

    /** 	param_num = -1*/
    _39param_num_54126 = -1;

    /** 	StraightenBranches()*/
    _39StraightenBranches();

    /** 	check_inline( p )*/
    _67check_inline(_p_59988);

    /** 	param_num = -1*/
    _39param_num_54126 = -1;

    /** 	EnterTopLevel()*/
    _39EnterTopLevel(1);

    /** 	if length( enum_syms ) then*/
    if (IS_SEQUENCE(_enum_syms_59999)){
            _30479 = SEQ_PTR(_enum_syms_59999)->length;
    }
    else {
        _30479 = 1;
    }
    if (_30479 == 0)
    {
        _30479 = NOVALUE;
        goto L49; // [2633] 2720
    }
    else{
        _30479 = NOVALUE;
    }

    /** 		SymTab[p][S_NEXT] = SymTab[enum_syms[$]][S_NEXT]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_59988 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_enum_syms_59999)){
            _30482 = SEQ_PTR(_enum_syms_59999)->length;
    }
    else {
        _30482 = 1;
    }
    _2 = (int)SEQ_PTR(_enum_syms_59999);
    _30483 = (int)*(((s1_ptr)_2)->base + _30482);
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!IS_ATOM_INT(_30483)){
        _30484 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_30483)->dbl));
    }
    else{
        _30484 = (int)*(((s1_ptr)_2)->base + _30483);
    }
    _2 = (int)SEQ_PTR(_30484);
    _30485 = (int)*(((s1_ptr)_2)->base + 2);
    _30484 = NOVALUE;
    Ref(_30485);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _30485;
    if( _1 != _30485 ){
        DeRef(_1);
    }
    _30485 = NOVALUE;
    _30480 = NOVALUE;

    /** 		SymTab[last_sym][S_NEXT] = enum_syms[1]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_53last_sym_46100 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_enum_syms_59999);
    _30488 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_30488);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _30488;
    if( _1 != _30488 ){
        DeRef(_1);
    }
    _30488 = NOVALUE;
    _30486 = NOVALUE;

    /** 		last_sym = enum_syms[$]*/
    if (IS_SEQUENCE(_enum_syms_59999)){
            _30489 = SEQ_PTR(_enum_syms_59999)->length;
    }
    else {
        _30489 = 1;
    }
    _2 = (int)SEQ_PTR(_enum_syms_59999);
    _53last_sym_46100 = (int)*(((s1_ptr)_2)->base + _30489);
    if (!IS_ATOM_INT(_53last_sym_46100)){
        _53last_sym_46100 = (long)DBL_PTR(_53last_sym_46100)->dbl;
    }

    /** 		SymTab[last_sym][S_NEXT] = 0*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_53last_sym_46100 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _30491 = NOVALUE;
L49: 

    /** end procedure*/
    DeRef(_tok_59992);
    DeRef(_prog_name_59993);
    DeRef(_seq_sym_59997);
    DeRef(_i1_sym_59998);
    DeRef(_enum_syms_59999);
    DeRef(_middle_def_args_60222);
    _30296 = NOVALUE;
    DeRef(_30274);
    _30274 = NOVALUE;
    _30344 = NOVALUE;
    _30300 = NOVALUE;
    DeRef(_30327);
    _30327 = NOVALUE;
    DeRef(_30332);
    _30332 = NOVALUE;
    DeRef(_30338);
    _30338 = NOVALUE;
    _30362 = NOVALUE;
    DeRef(_30360);
    _30360 = NOVALUE;
    _30363 = NOVALUE;
    _30366 = NOVALUE;
    _30381 = NOVALUE;
    DeRef(_30378);
    _30378 = NOVALUE;
    _30386 = NOVALUE;
    _30432 = NOVALUE;
    DeRef(_30426);
    _30426 = NOVALUE;
    _30452 = NOVALUE;
    DeRef(_30442);
    _30442 = NOVALUE;
    _30483 = NOVALUE;
    return;
    ;
}


void _39InitGlobals()
{
    int _30510 = NOVALUE;
    int _30508 = NOVALUE;
    int _30507 = NOVALUE;
    int _30506 = NOVALUE;
    int _30505 = NOVALUE;
    int _30504 = NOVALUE;
    int _30503 = NOVALUE;
    int _30501 = NOVALUE;
    int _30500 = NOVALUE;
    int _30499 = NOVALUE;
    int _30498 = NOVALUE;
    int _30496 = NOVALUE;
    int _30495 = NOVALUE;
    int _30494 = NOVALUE;
    int _0, _1, _2;
    

    /** 	ResetTP()*/
    _61ResetTP();

    /** 	OpTypeCheck = TRUE*/
    _35OpTypeCheck_16314 = _13TRUE_436;

    /** 	OpDefines &= {*/
    _30494 = _32version_major();
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _30494;
    _30495 = MAKE_SEQ(_1);
    _30494 = NOVALUE;
    _30496 = EPrintf(-9999999, _30493, _30495);
    DeRefDS(_30495);
    _30495 = NOVALUE;
    _30498 = _32version_major();
    _30499 = _32version_minor();
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _30498;
    ((int *)_2)[2] = _30499;
    _30500 = MAKE_SEQ(_1);
    _30499 = NOVALUE;
    _30498 = NOVALUE;
    _30501 = EPrintf(-9999999, _30497, _30500);
    DeRefDS(_30500);
    _30500 = NOVALUE;
    _30503 = _32version_major();
    _30504 = _32version_minor();
    _30505 = _32version_patch();
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _30503;
    *((int *)(_2+8)) = _30504;
    *((int *)(_2+12)) = _30505;
    _30506 = MAKE_SEQ(_1);
    _30505 = NOVALUE;
    _30504 = NOVALUE;
    _30503 = NOVALUE;
    _30507 = EPrintf(-9999999, _30502, _30506);
    DeRefDS(_30506);
    _30506 = NOVALUE;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _30496;
    *((int *)(_2+8)) = _30501;
    *((int *)(_2+12)) = _30507;
    _30508 = MAKE_SEQ(_1);
    _30507 = NOVALUE;
    _30501 = NOVALUE;
    _30496 = NOVALUE;
    Concat((object_ptr)&_35OpDefines_16317, _35OpDefines_16317, _30508);
    DeRefDS(_30508);
    _30508 = NOVALUE;

    /** 	OpDefines &= GetPlatformDefines()*/
    _30510 = _40GetPlatformDefines(0);
    if (IS_SEQUENCE(_35OpDefines_16317) && IS_ATOM(_30510)) {
        Ref(_30510);
        Append(&_35OpDefines_16317, _35OpDefines_16317, _30510);
    }
    else if (IS_ATOM(_35OpDefines_16317) && IS_SEQUENCE(_30510)) {
    }
    else {
        Concat((object_ptr)&_35OpDefines_16317, _35OpDefines_16317, _30510);
    }
    DeRef(_30510);
    _30510 = NOVALUE;

    /** 	OpInline = DEFAULT_INLINE*/
    _35OpInline_16318 = 30;

    /** 	OpIndirectInclude = 1*/
    _35OpIndirectInclude_16319 = 1;

    /** end procedure*/
    return;
    ;
}


void _39not_supported_compile(int _feature_60670)
{
    int _30512 = NOVALUE;
    int _0, _1, _2;
    

    /** 	CompileErr(5, {feature, version_name})*/
    RefDS(_35version_name_15901);
    RefDS(_feature_60670);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _feature_60670;
    ((int *)_2)[2] = _35version_name_15901;
    _30512 = MAKE_SEQ(_1);
    _44CompileErr(5, _30512, 0);
    _30512 = NOVALUE;

    /** end procedure*/
    DeRefDSi(_feature_60670);
    return;
    ;
}


void _39SetWith(int _on_off_60676)
{
    int _option_60677 = NOVALUE;
    int _idx_60678 = NOVALUE;
    int _reset_flags_60679 = NOVALUE;
    int _tok_60731 = NOVALUE;
    int _good_sofar_60779 = NOVALUE;
    int _tok_60782 = NOVALUE;
    int _warning_extra_60784 = NOVALUE;
    int _endlist_60875 = NOVALUE;
    int _tok_61019 = NOVALUE;
    int _30659 = NOVALUE;
    int _30657 = NOVALUE;
    int _30656 = NOVALUE;
    int _30655 = NOVALUE;
    int _30654 = NOVALUE;
    int _30651 = NOVALUE;
    int _30650 = NOVALUE;
    int _30649 = NOVALUE;
    int _30647 = NOVALUE;
    int _30645 = NOVALUE;
    int _30642 = NOVALUE;
    int _30640 = NOVALUE;
    int _30639 = NOVALUE;
    int _30638 = NOVALUE;
    int _30637 = NOVALUE;
    int _30636 = NOVALUE;
    int _30632 = NOVALUE;
    int _30630 = NOVALUE;
    int _30628 = NOVALUE;
    int _30624 = NOVALUE;
    int _30619 = NOVALUE;
    int _30618 = NOVALUE;
    int _30612 = NOVALUE;
    int _30611 = NOVALUE;
    int _30610 = NOVALUE;
    int _30609 = NOVALUE;
    int _30608 = NOVALUE;
    int _30607 = NOVALUE;
    int _30606 = NOVALUE;
    int _30605 = NOVALUE;
    int _30604 = NOVALUE;
    int _30603 = NOVALUE;
    int _30601 = NOVALUE;
    int _30600 = NOVALUE;
    int _30598 = NOVALUE;
    int _30597 = NOVALUE;
    int _30596 = NOVALUE;
    int _30594 = NOVALUE;
    int _30593 = NOVALUE;
    int _30591 = NOVALUE;
    int _30588 = NOVALUE;
    int _30586 = NOVALUE;
    int _30583 = NOVALUE;
    int _30582 = NOVALUE;
    int _30581 = NOVALUE;
    int _30580 = NOVALUE;
    int _30573 = NOVALUE;
    int _30572 = NOVALUE;
    int _30570 = NOVALUE;
    int _30567 = NOVALUE;
    int _30566 = NOVALUE;
    int _30564 = NOVALUE;
    int _30563 = NOVALUE;
    int _30562 = NOVALUE;
    int _30561 = NOVALUE;
    int _30560 = NOVALUE;
    int _30559 = NOVALUE;
    int _30556 = NOVALUE;
    int _30555 = NOVALUE;
    int _30554 = NOVALUE;
    int _30553 = NOVALUE;
    int _30552 = NOVALUE;
    int _30551 = NOVALUE;
    int _30548 = NOVALUE;
    int _30547 = NOVALUE;
    int _30546 = NOVALUE;
    int _30544 = NOVALUE;
    int _30541 = NOVALUE;
    int _30539 = NOVALUE;
    int _30538 = NOVALUE;
    int _30536 = NOVALUE;
    int _30535 = NOVALUE;
    int _30534 = NOVALUE;
    int _30533 = NOVALUE;
    int _30532 = NOVALUE;
    int _30531 = NOVALUE;
    int _30529 = NOVALUE;
    int _30526 = NOVALUE;
    int _30525 = NOVALUE;
    int _30524 = NOVALUE;
    int _30523 = NOVALUE;
    int _30521 = NOVALUE;
    int _30520 = NOVALUE;
    int _30519 = NOVALUE;
    int _30518 = NOVALUE;
    int _30516 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer reset_flags = 1*/
    _reset_flags_60679 = 1;

    /** 	option = StringToken("&+=")*/
    RefDS(_30513);
    _0 = _option_60677;
    _option_60677 = _61StringToken(_30513);
    DeRef(_0);

    /** 	if equal(option, "type_check") then*/
    if (_option_60677 == _30515)
    _30516 = 1;
    else if (IS_ATOM_INT(_option_60677) && IS_ATOM_INT(_30515))
    _30516 = 0;
    else
    _30516 = (compare(_option_60677, _30515) == 0);
    if (_30516 == 0)
    {
        _30516 = NOVALUE;
        goto L1; // [22] 35
    }
    else{
        _30516 = NOVALUE;
    }

    /** 		OpTypeCheck = on_off*/
    _35OpTypeCheck_16314 = _on_off_60676;
    goto L2; // [32] 1521
L1: 

    /** 	elsif equal(option, "profile") then*/
    if (_option_60677 == _30517)
    _30518 = 1;
    else if (IS_ATOM_INT(_option_60677) && IS_ATOM_INT(_30517))
    _30518 = 0;
    else
    _30518 = (compare(_option_60677, _30517) == 0);
    if (_30518 == 0)
    {
        _30518 = NOVALUE;
        goto L3; // [41] 121
    }
    else{
        _30518 = NOVALUE;
    }

    /** 		if not TRANSLATE and not BIND then*/
    _30519 = (_35TRANSLATE_15887 == 0);
    if (_30519 == 0) {
        goto L2; // [51] 1521
    }
    _30521 = (_35BIND_15890 == 0);
    if (_30521 == 0)
    {
        DeRef(_30521);
        _30521 = NOVALUE;
        goto L2; // [61] 1521
    }
    else{
        DeRef(_30521);
        _30521 = NOVALUE;
    }

    /** 			OpProfileStatement = on_off*/
    _35OpProfileStatement_16315 = _on_off_60676;

    /** 			if OpProfileStatement then*/
    if (_35OpProfileStatement_16315 == 0)
    {
        goto L2; // [75] 1521
    }
    else{
    }

    /** 				if AnyTimeProfile then*/
    if (_36AnyTimeProfile_15264 == 0)
    {
        goto L4; // [82] 106
    }
    else{
    }

    /** 					Warning(224, mixed_profile_warning_flag)*/
    RefDS(_22023);
    _44Warning(224, 1024, _22023);

    /** 					OpProfileStatement = FALSE*/
    _35OpProfileStatement_16315 = _13FALSE_434;
    goto L2; // [103] 1521
L4: 

    /** 					AnyStatementProfile = TRUE*/
    _36AnyStatementProfile_15265 = _13TRUE_436;
    goto L2; // [118] 1521
L3: 

    /** 	elsif equal(option, "profile_time") then*/
    if (_option_60677 == _30522)
    _30523 = 1;
    else if (IS_ATOM_INT(_option_60677) && IS_ATOM_INT(_30522))
    _30523 = 0;
    else
    _30523 = (compare(_option_60677, _30522) == 0);
    if (_30523 == 0)
    {
        _30523 = NOVALUE;
        goto L5; // [127] 361
    }
    else{
        _30523 = NOVALUE;
    }

    /** 		if not TRANSLATE and not BIND then*/
    _30524 = (_35TRANSLATE_15887 == 0);
    if (_30524 == 0) {
        goto L2; // [137] 1521
    }
    _30526 = (_35BIND_15890 == 0);
    if (_30526 == 0)
    {
        DeRef(_30526);
        _30526 = NOVALUE;
        goto L2; // [147] 1521
    }
    else{
        DeRef(_30526);
        _30526 = NOVALUE;
    }

    /** 			if not IWINDOWS then*/
    if (_40IWINDOWS_16387 != 0)
    goto L6; // [154] 169

    /** 				if on_off then*/
    if (_on_off_60676 == 0)
    {
        goto L7; // [159] 168
    }
    else{
    }

    /** 					not_supported_compile("profile_time")*/
    RefDS(_30522);
    _39not_supported_compile(_30522);
L7: 
L6: 

    /** 			OpProfileTime = on_off*/
    _35OpProfileTime_16316 = _on_off_60676;

    /** 			if OpProfileTime then*/
    if (_35OpProfileTime_16316 == 0)
    {
        goto L8; // [180] 355
    }
    else{
    }

    /** 				if AnyStatementProfile then*/
    if (_36AnyStatementProfile_15265 == 0)
    {
        goto L9; // [187] 209
    }
    else{
    }

    /** 					Warning(224,mixed_profile_warning_flag)*/
    RefDS(_22023);
    _44Warning(224, 1024, _22023);

    /** 					OpProfileTime = FALSE*/
    _35OpProfileTime_16316 = _13FALSE_434;
L9: 

    /** 				token tok = next_token()*/
    _0 = _tok_60731;
    _tok_60731 = _39next_token();
    DeRef(_0);

    /** 				if tok[T_ID] = ATOM then*/
    _2 = (int)SEQ_PTR(_tok_60731);
    _30529 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30529, 502)){
        _30529 = NOVALUE;
        goto LA; // [224] 316
    }
    _30529 = NOVALUE;

    /** 					if integer(SymTab[tok[T_SYM]][S_OBJ]) then*/
    _2 = (int)SEQ_PTR(_tok_60731);
    _30531 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!IS_ATOM_INT(_30531)){
        _30532 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_30531)->dbl));
    }
    else{
        _30532 = (int)*(((s1_ptr)_2)->base + _30531);
    }
    _2 = (int)SEQ_PTR(_30532);
    _30533 = (int)*(((s1_ptr)_2)->base + 1);
    _30532 = NOVALUE;
    if (IS_ATOM_INT(_30533))
    _30534 = 1;
    else if (IS_ATOM_DBL(_30533))
    _30534 = IS_ATOM_INT(DoubleToInt(_30533));
    else
    _30534 = 0;
    _30533 = NOVALUE;
    if (_30534 == 0)
    {
        _30534 = NOVALUE;
        goto LB; // [251] 279
    }
    else{
        _30534 = NOVALUE;
    }

    /** 						sample_size = SymTab[tok[T_SYM]][S_OBJ]*/
    _2 = (int)SEQ_PTR(_tok_60731);
    _30535 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!IS_ATOM_INT(_30535)){
        _30536 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_30535)->dbl));
    }
    else{
        _30536 = (int)*(((s1_ptr)_2)->base + _30535);
    }
    _2 = (int)SEQ_PTR(_30536);
    _35sample_size_16344 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_35sample_size_16344)){
        _35sample_size_16344 = (long)DBL_PTR(_35sample_size_16344)->dbl;
    }
    _30536 = NOVALUE;
    goto LC; // [276] 287
LB: 

    /** 						sample_size = -1*/
    _35sample_size_16344 = -1;
LC: 

    /** 					if sample_size < 1 and OpProfileTime then*/
    _30538 = (_35sample_size_16344 < 1);
    if (_30538 == 0) {
        goto LD; // [295] 329
    }
    if (_35OpProfileTime_16316 == 0)
    {
        goto LD; // [302] 329
    }
    else{
    }

    /** 						CompileErr(136)*/
    RefDS(_22023);
    _44CompileErr(136, _22023, 0);
    goto LD; // [313] 329
LA: 

    /** 					putback(tok)*/
    Ref(_tok_60731);
    _39putback(_tok_60731);

    /** 					sample_size = DEFAULT_SAMPLE_SIZE*/
    _35sample_size_16344 = 25000;
LD: 

    /** 				if OpProfileTime then*/
    if (_35OpProfileTime_16316 == 0)
    {
        goto LE; // [333] 354
    }
    else{
    }

    /** 					if IWINDOWS then*/
    if (_40IWINDOWS_16387 == 0)
    {
        goto LF; // [340] 353
    }
    else{
    }

    /** 						AnyTimeProfile = TRUE*/
    _36AnyTimeProfile_15264 = _13TRUE_436;
LF: 
LE: 
L8: 
    DeRef(_tok_60731);
    _tok_60731 = NOVALUE;
    goto L2; // [358] 1521
L5: 

    /** 	elsif equal(option, "trace") then*/
    if (_option_60677 == _30540)
    _30541 = 1;
    else if (IS_ATOM_INT(_option_60677) && IS_ATOM_INT(_30540))
    _30541 = 0;
    else
    _30541 = (compare(_option_60677, _30540) == 0);
    if (_30541 == 0)
    {
        _30541 = NOVALUE;
        goto L10; // [367] 388
    }
    else{
        _30541 = NOVALUE;
    }

    /** 		if not BIND then*/
    if (_35BIND_15890 != 0)
    goto L2; // [374] 1521

    /** 			OpTrace = on_off*/
    _35OpTrace_16313 = _on_off_60676;
    goto L2; // [385] 1521
L10: 

    /** 	elsif equal(option, "warning") then*/
    if (_option_60677 == _30543)
    _30544 = 1;
    else if (IS_ATOM_INT(_option_60677) && IS_ATOM_INT(_30543))
    _30544 = 0;
    else
    _30544 = (compare(_option_60677, _30543) == 0);
    if (_30544 == 0)
    {
        _30544 = NOVALUE;
        goto L11; // [394] 1234
    }
    else{
        _30544 = NOVALUE;
    }

    /** 		integer good_sofar = line_number*/
    _good_sofar_60779 = _35line_number_16245;

    /** 		reset_flags = 1*/
    _reset_flags_60679 = 1;

    /** 		token tok = next_token()*/
    _0 = _tok_60782;
    _tok_60782 = _39next_token();
    DeRef(_0);

    /** 		integer warning_extra = 1*/
    _warning_extra_60784 = 1;

    /** 		if find(tok[T_ID], {CONCAT_EQUALS, PLUS_EQUALS}) != 0 then*/
    _2 = (int)SEQ_PTR(_tok_60782);
    _30546 = (int)*(((s1_ptr)_2)->base + 1);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 519;
    ((int *)_2)[2] = 515;
    _30547 = MAKE_SEQ(_1);
    _30548 = find_from(_30546, _30547, 1);
    _30546 = NOVALUE;
    DeRefDS(_30547);
    _30547 = NOVALUE;
    if (_30548 == 0)
    goto L12; // [442] 501

    /** 			tok = next_token()*/
    _0 = _tok_60782;
    _tok_60782 = _39next_token();
    DeRef(_0);

    /** 			if tok[T_ID] != LEFT_BRACE and tok[T_ID] != LEFT_ROUND then*/
    _2 = (int)SEQ_PTR(_tok_60782);
    _30551 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_30551)) {
        _30552 = (_30551 != -24);
    }
    else {
        _30552 = binary_op(NOTEQ, _30551, -24);
    }
    _30551 = NOVALUE;
    if (IS_ATOM_INT(_30552)) {
        if (_30552 == 0) {
            goto L13; // [465] 493
        }
    }
    else {
        if (DBL_PTR(_30552)->dbl == 0.0) {
            goto L13; // [465] 493
        }
    }
    _2 = (int)SEQ_PTR(_tok_60782);
    _30554 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_30554)) {
        _30555 = (_30554 != -26);
    }
    else {
        _30555 = binary_op(NOTEQ, _30554, -26);
    }
    _30554 = NOVALUE;
    if (_30555 == 0) {
        DeRef(_30555);
        _30555 = NOVALUE;
        goto L13; // [482] 493
    }
    else {
        if (!IS_ATOM_INT(_30555) && DBL_PTR(_30555)->dbl == 0.0){
            DeRef(_30555);
            _30555 = NOVALUE;
            goto L13; // [482] 493
        }
        DeRef(_30555);
        _30555 = NOVALUE;
    }
    DeRef(_30555);
    _30555 = NOVALUE;

    /** 				CompileErr(160)*/
    RefDS(_22023);
    _44CompileErr(160, _22023, 0);
L13: 

    /** 			reset_flags = 0*/
    _reset_flags_60679 = 0;
    goto L14; // [498] 727
L12: 

    /** 		elsif tok[T_ID] = EQUALS then*/
    _2 = (int)SEQ_PTR(_tok_60782);
    _30556 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30556, 3)){
        _30556 = NOVALUE;
        goto L15; // [511] 570
    }
    _30556 = NOVALUE;

    /** 			tok = next_token()*/
    _0 = _tok_60782;
    _tok_60782 = _39next_token();
    DeRef(_0);

    /** 			if tok[T_ID] != LEFT_BRACE and tok[T_ID] != LEFT_ROUND then*/
    _2 = (int)SEQ_PTR(_tok_60782);
    _30559 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_30559)) {
        _30560 = (_30559 != -24);
    }
    else {
        _30560 = binary_op(NOTEQ, _30559, -24);
    }
    _30559 = NOVALUE;
    if (IS_ATOM_INT(_30560)) {
        if (_30560 == 0) {
            goto L16; // [534] 562
        }
    }
    else {
        if (DBL_PTR(_30560)->dbl == 0.0) {
            goto L16; // [534] 562
        }
    }
    _2 = (int)SEQ_PTR(_tok_60782);
    _30562 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_30562)) {
        _30563 = (_30562 != -26);
    }
    else {
        _30563 = binary_op(NOTEQ, _30562, -26);
    }
    _30562 = NOVALUE;
    if (_30563 == 0) {
        DeRef(_30563);
        _30563 = NOVALUE;
        goto L16; // [551] 562
    }
    else {
        if (!IS_ATOM_INT(_30563) && DBL_PTR(_30563)->dbl == 0.0){
            DeRef(_30563);
            _30563 = NOVALUE;
            goto L16; // [551] 562
        }
        DeRef(_30563);
        _30563 = NOVALUE;
    }
    DeRef(_30563);
    _30563 = NOVALUE;

    /** 				CompileErr(160)*/
    RefDS(_22023);
    _44CompileErr(160, _22023, 0);
L16: 

    /** 			reset_flags = 1*/
    _reset_flags_60679 = 1;
    goto L14; // [567] 727
L15: 

    /** 		elsif tok[T_ID] = VARIABLE then*/
    _2 = (int)SEQ_PTR(_tok_60782);
    _30564 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30564, -100)){
        _30564 = NOVALUE;
        goto L17; // [580] 726
    }
    _30564 = NOVALUE;

    /** 			option = SymTab[tok[T_SYM]][S_NAME]*/
    _2 = (int)SEQ_PTR(_tok_60782);
    _30566 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!IS_ATOM_INT(_30566)){
        _30567 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_30566)->dbl));
    }
    else{
        _30567 = (int)*(((s1_ptr)_2)->base + _30566);
    }
    DeRef(_option_60677);
    _2 = (int)SEQ_PTR(_30567);
    if (!IS_ATOM_INT(_35S_NAME_15917)){
        _option_60677 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15917)->dbl));
    }
    else{
        _option_60677 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15917);
    }
    Ref(_option_60677);
    _30567 = NOVALUE;

    /** 			if equal(option, "save") then*/
    if (_option_60677 == _30569)
    _30570 = 1;
    else if (IS_ATOM_INT(_option_60677) && IS_ATOM_INT(_30569))
    _30570 = 0;
    else
    _30570 = (compare(_option_60677, _30569) == 0);
    if (_30570 == 0)
    {
        _30570 = NOVALUE;
        goto L18; // [612] 636
    }
    else{
        _30570 = NOVALUE;
    }

    /** 				prev_OpWarning = OpWarning*/
    _35prev_OpWarning_16312 = _35OpWarning_16311;

    /** 				warning_extra = FALSE*/
    _warning_extra_60784 = _13FALSE_434;
    goto L19; // [633] 725
L18: 

    /** 			elsif equal(option, "restore") then*/
    if (_option_60677 == _30571)
    _30572 = 1;
    else if (IS_ATOM_INT(_option_60677) && IS_ATOM_INT(_30571))
    _30572 = 0;
    else
    _30572 = (compare(_option_60677, _30571) == 0);
    if (_30572 == 0)
    {
        _30572 = NOVALUE;
        goto L1A; // [642] 666
    }
    else{
        _30572 = NOVALUE;
    }

    /** 				OpWarning = prev_OpWarning*/
    _35OpWarning_16311 = _35prev_OpWarning_16312;

    /** 				warning_extra = FALSE*/
    _warning_extra_60784 = _13FALSE_434;
    goto L19; // [663] 725
L1A: 

    /** 			elsif equal(option, "strict") then*/
    if (_option_60677 == _25561)
    _30573 = 1;
    else if (IS_ATOM_INT(_option_60677) && IS_ATOM_INT(_25561))
    _30573 = 0;
    else
    _30573 = (compare(_option_60677, _25561) == 0);
    if (_30573 == 0)
    {
        _30573 = NOVALUE;
        goto L1B; // [672] 724
    }
    else{
        _30573 = NOVALUE;
    }

    /** 				if on_off = 0 then*/
    if (_on_off_60676 != 0)
    goto L1C; // [677] 694

    /** 					Strict_Override += 1*/
    _35Strict_Override_16310 = _35Strict_Override_16310 + 1;
    goto L1D; // [691] 714
L1C: 

    /** 				elsif Strict_Override > 0 then*/
    if (_35Strict_Override_16310 <= 0)
    goto L1E; // [698] 713

    /** 					Strict_Override -= 1*/
    _35Strict_Override_16310 = _35Strict_Override_16310 - 1;
L1E: 
L1D: 

    /** 				warning_extra = FALSE*/
    _warning_extra_60784 = _13FALSE_434;
L1B: 
L19: 
L17: 
L14: 

    /** 		if warning_extra = TRUE then*/
    if (_warning_extra_60784 != _13TRUE_436)
    goto L1F; // [731] 1229

    /** 			if reset_flags then*/
    if (_reset_flags_60679 == 0)
    {
        goto L20; // [737] 769
    }
    else{
    }

    /** 				if on_off = 0 then*/
    if (_on_off_60676 != 0)
    goto L21; // [742] 758

    /** 					OpWarning = no_warning_flag*/
    _35OpWarning_16311 = 0;
    goto L22; // [755] 768
L21: 

    /** 					OpWarning = all_warning_flag*/
    _35OpWarning_16311 = 32767;
L22: 
L20: 

    /** 			if find(tok[T_ID], {LEFT_BRACE, LEFT_ROUND}) then*/
    _2 = (int)SEQ_PTR(_tok_60782);
    _30580 = (int)*(((s1_ptr)_2)->base + 1);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -24;
    ((int *)_2)[2] = -26;
    _30581 = MAKE_SEQ(_1);
    _30582 = find_from(_30580, _30581, 1);
    _30580 = NOVALUE;
    DeRefDS(_30581);
    _30581 = NOVALUE;
    if (_30582 == 0)
    {
        _30582 = NOVALUE;
        goto L23; // [790] 1222
    }
    else{
        _30582 = NOVALUE;
    }

    /** 				integer endlist*/

    /** 				if tok[T_ID] = LEFT_BRACE then*/
    _2 = (int)SEQ_PTR(_tok_60782);
    _30583 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30583, -24)){
        _30583 = NOVALUE;
        goto L24; // [805] 821
    }
    _30583 = NOVALUE;

    /** 					endlist = RIGHT_BRACE*/
    _endlist_60875 = -25;
    goto L25; // [818] 831
L24: 

    /** 					endlist = RIGHT_ROUND*/
    _endlist_60875 = -27;
L25: 

    /** 				tok = next_token()*/
    _0 = _tok_60782;
    _tok_60782 = _39next_token();
    DeRef(_0);

    /** 				while tok[T_ID] != endlist do*/
L26: 
    _2 = (int)SEQ_PTR(_tok_60782);
    _30586 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _30586, _endlist_60875)){
        _30586 = NOVALUE;
        goto L27; // [849] 1217
    }
    _30586 = NOVALUE;

    /** 					if tok[T_ID] = COMMA then*/
    _2 = (int)SEQ_PTR(_tok_60782);
    _30588 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30588, -30)){
        _30588 = NOVALUE;
        goto L28; // [863] 877
    }
    _30588 = NOVALUE;

    /** 						tok = next_token()*/
    _0 = _tok_60782;
    _tok_60782 = _39next_token();
    DeRef(_0);

    /** 						continue*/
    goto L26; // [874] 841
L28: 

    /** 					if tok[T_ID] = STRING then*/
    _2 = (int)SEQ_PTR(_tok_60782);
    _30591 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30591, 503)){
        _30591 = NOVALUE;
        goto L29; // [887] 916
    }
    _30591 = NOVALUE;

    /** 						option = SymTab[tok[T_SYM]][S_OBJ]*/
    _2 = (int)SEQ_PTR(_tok_60782);
    _30593 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!IS_ATOM_INT(_30593)){
        _30594 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_30593)->dbl));
    }
    else{
        _30594 = (int)*(((s1_ptr)_2)->base + _30593);
    }
    DeRef(_option_60677);
    _2 = (int)SEQ_PTR(_30594);
    _option_60677 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_option_60677);
    _30594 = NOVALUE;
    goto L2A; // [913] 1064
L29: 

    /** 					elsif length(SymTab[tok[T_SYM]]) >= S_NAME then*/
    _2 = (int)SEQ_PTR(_tok_60782);
    _30596 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!IS_ATOM_INT(_30596)){
        _30597 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_30596)->dbl));
    }
    else{
        _30597 = (int)*(((s1_ptr)_2)->base + _30596);
    }
    if (IS_SEQUENCE(_30597)){
            _30598 = SEQ_PTR(_30597)->length;
    }
    else {
        _30598 = 1;
    }
    _30597 = NOVALUE;
    if (binary_op_a(LESS, _30598, _35S_NAME_15917)){
        _30598 = NOVALUE;
        goto L2B; // [935] 964
    }
    _30598 = NOVALUE;

    /** 						option = SymTab[tok[T_SYM]][S_NAME]*/
    _2 = (int)SEQ_PTR(_tok_60782);
    _30600 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!IS_ATOM_INT(_30600)){
        _30601 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_30600)->dbl));
    }
    else{
        _30601 = (int)*(((s1_ptr)_2)->base + _30600);
    }
    DeRef(_option_60677);
    _2 = (int)SEQ_PTR(_30601);
    if (!IS_ATOM_INT(_35S_NAME_15917)){
        _option_60677 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15917)->dbl));
    }
    else{
        _option_60677 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15917);
    }
    Ref(_option_60677);
    _30601 = NOVALUE;
    goto L2A; // [961] 1064
L2B: 

    /** 						option = ""*/
    RefDS(_22023);
    DeRef(_option_60677);
    _option_60677 = _22023;

    /** 						for k = 1 to length(keylist) do*/
    if (IS_SEQUENCE(_63keylist_22829)){
            _30603 = SEQ_PTR(_63keylist_22829)->length;
    }
    else {
        _30603 = 1;
    }
    {
        int _k_60922;
        _k_60922 = 1;
L2C: 
        if (_k_60922 > _30603){
            goto L2D; // [978] 1063
        }

        /** 							if keylist[k][S_SCOPE] = SC_KEYWORD and*/
        _2 = (int)SEQ_PTR(_63keylist_22829);
        _30604 = (int)*(((s1_ptr)_2)->base + _k_60922);
        _2 = (int)SEQ_PTR(_30604);
        _30605 = (int)*(((s1_ptr)_2)->base + 4);
        _30604 = NOVALUE;
        if (IS_ATOM_INT(_30605)) {
            _30606 = (_30605 == 8);
        }
        else {
            _30606 = binary_op(EQUALS, _30605, 8);
        }
        _30605 = NOVALUE;
        if (IS_ATOM_INT(_30606)) {
            if (_30606 == 0) {
                goto L2E; // [1005] 1056
            }
        }
        else {
            if (DBL_PTR(_30606)->dbl == 0.0) {
                goto L2E; // [1005] 1056
            }
        }
        _2 = (int)SEQ_PTR(_63keylist_22829);
        _30608 = (int)*(((s1_ptr)_2)->base + _k_60922);
        _2 = (int)SEQ_PTR(_30608);
        if (!IS_ATOM_INT(_35S_TOKEN_15922)){
            _30609 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TOKEN_15922)->dbl));
        }
        else{
            _30609 = (int)*(((s1_ptr)_2)->base + _35S_TOKEN_15922);
        }
        _30608 = NOVALUE;
        _2 = (int)SEQ_PTR(_tok_60782);
        _30610 = (int)*(((s1_ptr)_2)->base + 1);
        if (IS_ATOM_INT(_30609) && IS_ATOM_INT(_30610)) {
            _30611 = (_30609 == _30610);
        }
        else {
            _30611 = binary_op(EQUALS, _30609, _30610);
        }
        _30609 = NOVALUE;
        _30610 = NOVALUE;
        if (_30611 == 0) {
            DeRef(_30611);
            _30611 = NOVALUE;
            goto L2E; // [1032] 1056
        }
        else {
            if (!IS_ATOM_INT(_30611) && DBL_PTR(_30611)->dbl == 0.0){
                DeRef(_30611);
                _30611 = NOVALUE;
                goto L2E; // [1032] 1056
            }
            DeRef(_30611);
            _30611 = NOVALUE;
        }
        DeRef(_30611);
        _30611 = NOVALUE;

        /** 									option = keylist[k][S_NAME]*/
        _2 = (int)SEQ_PTR(_63keylist_22829);
        _30612 = (int)*(((s1_ptr)_2)->base + _k_60922);
        DeRef(_option_60677);
        _2 = (int)SEQ_PTR(_30612);
        if (!IS_ATOM_INT(_35S_NAME_15917)){
            _option_60677 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15917)->dbl));
        }
        else{
            _option_60677 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15917);
        }
        Ref(_option_60677);
        _30612 = NOVALUE;

        /** 									exit*/
        goto L2D; // [1053] 1063
L2E: 

        /** 						end for*/
        _k_60922 = _k_60922 + 1;
        goto L2C; // [1058] 985
L2D: 
        ;
    }
L2A: 

    /** 					idx = find(option, warning_names)*/
    _idx_60678 = find_from(_option_60677, _35warning_names_16288, 1);

    /** 					if idx = 0 then*/
    if (_idx_60678 != 0)
    goto L2F; // [1075] 1128

    /** 	 					if good_sofar != line_number then*/
    if (_good_sofar_60779 == _35line_number_16245)
    goto L30; // [1083] 1095

    /**  							CompileErr(147)*/
    RefDS(_22023);
    _44CompileErr(147, _22023, 0);
L30: 

    /** 						Warning(225, 0,*/
    _2 = (int)SEQ_PTR(_36known_files_15243);
    _30618 = (int)*(((s1_ptr)_2)->base + _35current_file_no_16244);
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_30618);
    *((int *)(_2+4)) = _30618;
    *((int *)(_2+8)) = _35line_number_16245;
    RefDS(_option_60677);
    *((int *)(_2+12)) = _option_60677;
    _30619 = MAKE_SEQ(_1);
    _30618 = NOVALUE;
    _44Warning(225, 0, _30619);
    _30619 = NOVALUE;

    /** 						tok = next_token()*/
    _0 = _tok_60782;
    _tok_60782 = _39next_token();
    DeRef(_0);

    /** 						continue*/
    goto L26; // [1125] 841
L2F: 

    /** 					idx = warning_flags[idx]*/
    _2 = (int)SEQ_PTR(_35warning_flags_16286);
    _idx_60678 = (int)*(((s1_ptr)_2)->base + _idx_60678);

    /** 					if idx = 0 then*/
    if (_idx_60678 != 0)
    goto L31; // [1140] 1174

    /** 						if on_off then*/
    if (_on_off_60676 == 0)
    {
        goto L32; // [1146] 1161
    }
    else{
    }

    /** 							OpWarning = no_warning_flag*/
    _35OpWarning_16311 = 0;
    goto L33; // [1158] 1207
L32: 

    /** 						    OpWarning = all_warning_flag*/
    _35OpWarning_16311 = 32767;
    goto L33; // [1171] 1207
L31: 

    /** 						if on_off then*/
    if (_on_off_60676 == 0)
    {
        goto L34; // [1176] 1192
    }
    else{
    }

    /** 							OpWarning = or_bits(OpWarning, idx)*/
    {unsigned long tu;
         tu = (unsigned long)_35OpWarning_16311 | (unsigned long)_idx_60678;
         _35OpWarning_16311 = MAKE_UINT(tu);
    }
    if (!IS_ATOM_INT(_35OpWarning_16311)) {
        _1 = (long)(DBL_PTR(_35OpWarning_16311)->dbl);
        DeRefDS(_35OpWarning_16311);
        _35OpWarning_16311 = _1;
    }
    goto L35; // [1189] 1206
L34: 

    /** 						    OpWarning = and_bits(OpWarning, not_bits(idx))*/
    _30624 = not_bits(_idx_60678);
    if (IS_ATOM_INT(_30624)) {
        {unsigned long tu;
             tu = (unsigned long)_35OpWarning_16311 & (unsigned long)_30624;
             _35OpWarning_16311 = MAKE_UINT(tu);
        }
    }
    else {
        temp_d.dbl = (double)_35OpWarning_16311;
        _35OpWarning_16311 = Dand_bits(&temp_d, DBL_PTR(_30624));
    }
    DeRef(_30624);
    _30624 = NOVALUE;
    if (!IS_ATOM_INT(_35OpWarning_16311)) {
        _1 = (long)(DBL_PTR(_35OpWarning_16311)->dbl);
        DeRefDS(_35OpWarning_16311);
        _35OpWarning_16311 = _1;
    }
L35: 
L33: 

    /** 					tok = next_token()*/
    _0 = _tok_60782;
    _tok_60782 = _39next_token();
    DeRef(_0);

    /** 				end while*/
    goto L26; // [1214] 841
L27: 
    goto L36; // [1219] 1228
L23: 

    /** 				putback(tok)*/
    Ref(_tok_60782);
    _39putback(_tok_60782);
L36: 
L1F: 
    DeRef(_tok_60782);
    _tok_60782 = NOVALUE;
    goto L2; // [1231] 1521
L11: 

    /** 	elsif equal(option, "define") then*/
    if (_option_60677 == _30627)
    _30628 = 1;
    else if (IS_ATOM_INT(_option_60677) && IS_ATOM_INT(_30627))
    _30628 = 0;
    else
    _30628 = (compare(_option_60677, _30627) == 0);
    if (_30628 == 0)
    {
        _30628 = NOVALUE;
        goto L37; // [1240] 1363
    }
    else{
        _30628 = NOVALUE;
    }

    /** 		option = StringToken()*/
    RefDS(_5);
    _0 = _option_60677;
    _option_60677 = _61StringToken(_5);
    DeRefDS(_0);

    /** 		if length(option) = 0 then*/
    if (IS_SEQUENCE(_option_60677)){
            _30630 = SEQ_PTR(_option_60677)->length;
    }
    else {
        _30630 = 1;
    }
    if (_30630 != 0)
    goto L38; // [1256] 1270

    /** 			CompileErr(81)*/
    RefDS(_22023);
    _44CompileErr(81, _22023, 0);
    goto L39; // [1267] 1288
L38: 

    /** 		elsif not t_identifier(option) then*/
    RefDS(_option_60677);
    _30632 = _13t_identifier(_option_60677);
    if (IS_ATOM_INT(_30632)) {
        if (_30632 != 0){
            DeRef(_30632);
            _30632 = NOVALUE;
            goto L3A; // [1276] 1287
        }
    }
    else {
        if (DBL_PTR(_30632)->dbl != 0.0){
            DeRef(_30632);
            _30632 = NOVALUE;
            goto L3A; // [1276] 1287
        }
    }
    DeRef(_30632);
    _30632 = NOVALUE;

    /** 			CompileErr(61)*/
    RefDS(_22023);
    _44CompileErr(61, _22023, 0);
L3A: 
L39: 

    /** 		if on_off = 0 then*/
    if (_on_off_60676 != 0)
    goto L3B; // [1290] 1345

    /** 			idx = find(option, OpDefines)*/
    _idx_60678 = find_from(_option_60677, _35OpDefines_16317, 1);

    /** 			if idx then*/
    if (_idx_60678 == 0)
    {
        goto L2; // [1305] 1521
    }
    else{
    }

    /** 				OpDefines = OpDefines[1..idx-1]&OpDefines[idx+1..$]*/
    _30636 = _idx_60678 - 1;
    rhs_slice_target = (object_ptr)&_30637;
    RHS_Slice(_35OpDefines_16317, 1, _30636);
    _30638 = _idx_60678 + 1;
    if (IS_SEQUENCE(_35OpDefines_16317)){
            _30639 = SEQ_PTR(_35OpDefines_16317)->length;
    }
    else {
        _30639 = 1;
    }
    rhs_slice_target = (object_ptr)&_30640;
    RHS_Slice(_35OpDefines_16317, _30638, _30639);
    Concat((object_ptr)&_35OpDefines_16317, _30637, _30640);
    DeRefDS(_30637);
    _30637 = NOVALUE;
    DeRef(_30637);
    _30637 = NOVALUE;
    DeRefDS(_30640);
    _30640 = NOVALUE;
    goto L2; // [1342] 1521
L3B: 

    /** 			OpDefines &= {option}*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_option_60677);
    *((int *)(_2+4)) = _option_60677;
    _30642 = MAKE_SEQ(_1);
    Concat((object_ptr)&_35OpDefines_16317, _35OpDefines_16317, _30642);
    DeRefDS(_30642);
    _30642 = NOVALUE;
    goto L2; // [1360] 1521
L37: 

    /** 	elsif equal(option, "inline") then*/
    if (_option_60677 == _30644)
    _30645 = 1;
    else if (IS_ATOM_INT(_option_60677) && IS_ATOM_INT(_30644))
    _30645 = 0;
    else
    _30645 = (compare(_option_60677, _30644) == 0);
    if (_30645 == 0)
    {
        _30645 = NOVALUE;
        goto L3C; // [1369] 1455
    }
    else{
        _30645 = NOVALUE;
    }

    /** 		if on_off then*/
    if (_on_off_60676 == 0)
    {
        goto L3D; // [1374] 1444
    }
    else{
    }

    /** 			token tok = next_token()*/
    _0 = _tok_61019;
    _tok_61019 = _39next_token();
    DeRef(_0);

    /** 			if tok[T_ID] = ATOM then*/
    _2 = (int)SEQ_PTR(_tok_61019);
    _30647 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30647, 502)){
        _30647 = NOVALUE;
        goto L3E; // [1392] 1424
    }
    _30647 = NOVALUE;

    /** 				OpInline = floor( SymTab[tok[T_SYM]][S_OBJ] )*/
    _2 = (int)SEQ_PTR(_tok_61019);
    _30649 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!IS_ATOM_INT(_30649)){
        _30650 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_30649)->dbl));
    }
    else{
        _30650 = (int)*(((s1_ptr)_2)->base + _30649);
    }
    _2 = (int)SEQ_PTR(_30650);
    _30651 = (int)*(((s1_ptr)_2)->base + 1);
    _30650 = NOVALUE;
    if (IS_ATOM_INT(_30651))
    _35OpInline_16318 = e_floor(_30651);
    else
    _35OpInline_16318 = unary_op(FLOOR, _30651);
    _30651 = NOVALUE;
    if (!IS_ATOM_INT(_35OpInline_16318)) {
        _1 = (long)(DBL_PTR(_35OpInline_16318)->dbl);
        DeRefDS(_35OpInline_16318);
        _35OpInline_16318 = _1;
    }
    goto L3F; // [1421] 1439
L3E: 

    /** 				putback(tok)*/
    Ref(_tok_61019);
    _39putback(_tok_61019);

    /** 				OpInline = DEFAULT_INLINE*/
    _35OpInline_16318 = 30;
L3F: 
    DeRef(_tok_61019);
    _tok_61019 = NOVALUE;
    goto L2; // [1441] 1521
L3D: 

    /** 			OpInline = 0*/
    _35OpInline_16318 = 0;
    goto L2; // [1452] 1521
L3C: 

    /** 	elsif equal( option, "indirect_includes" ) then*/
    if (_option_60677 == _30653)
    _30654 = 1;
    else if (IS_ATOM_INT(_option_60677) && IS_ATOM_INT(_30653))
    _30654 = 0;
    else
    _30654 = (compare(_option_60677, _30653) == 0);
    if (_30654 == 0)
    {
        _30654 = NOVALUE;
        goto L40; // [1461] 1474
    }
    else{
        _30654 = NOVALUE;
    }

    /** 		OpIndirectInclude = on_off*/
    _35OpIndirectInclude_16319 = _on_off_60676;
    goto L2; // [1471] 1521
L40: 

    /** 	elsif equal(option, "batch") then*/
    if (_option_60677 == _25558)
    _30655 = 1;
    else if (IS_ATOM_INT(_option_60677) && IS_ATOM_INT(_25558))
    _30655 = 0;
    else
    _30655 = (compare(_option_60677, _25558) == 0);
    if (_30655 == 0)
    {
        _30655 = NOVALUE;
        goto L41; // [1480] 1493
    }
    else{
        _30655 = NOVALUE;
    }

    /** 		batch_job = on_off*/
    _35batch_job_16257 = _on_off_60676;
    goto L2; // [1490] 1521
L41: 

    /** 	elsif integer(to_number(option, -1)) then*/
    RefDS(_option_60677);
    _30656 = _15to_number(_option_60677, -1);
    if (IS_ATOM_INT(_30656))
    _30657 = 1;
    else if (IS_ATOM_DBL(_30656))
    _30657 = IS_ATOM_INT(DoubleToInt(_30656));
    else
    _30657 = 0;
    DeRef(_30656);
    _30656 = NOVALUE;
    if (_30657 == 0)
    {
        _30657 = NOVALUE;
        goto L42; // [1503] 1509
    }
    else{
        _30657 = NOVALUE;
    }
    goto L2; // [1506] 1521
L42: 

    /** 		CompileErr(154, {option})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_option_60677);
    *((int *)(_2+4)) = _option_60677;
    _30659 = MAKE_SEQ(_1);
    _44CompileErr(154, _30659, 0);
    _30659 = NOVALUE;
L2: 

    /** end procedure*/
    DeRef(_option_60677);
    DeRef(_30519);
    _30519 = NOVALUE;
    DeRef(_30524);
    _30524 = NOVALUE;
    _30531 = NOVALUE;
    _30535 = NOVALUE;
    DeRef(_30538);
    _30538 = NOVALUE;
    _30566 = NOVALUE;
    DeRef(_30552);
    _30552 = NOVALUE;
    DeRef(_30560);
    _30560 = NOVALUE;
    _30593 = NOVALUE;
    _30596 = NOVALUE;
    _30597 = NOVALUE;
    _30600 = NOVALUE;
    DeRef(_30636);
    _30636 = NOVALUE;
    DeRef(_30606);
    _30606 = NOVALUE;
    _30649 = NOVALUE;
    DeRef(_30638);
    _30638 = NOVALUE;
    return;
    ;
}


void _39ExecCommand()
{
    int _0, _1, _2;
    

    /** 	if TRANSLATE then*/
    if (_35TRANSLATE_15887 == 0)
    {
        goto L1; // [5] 16
    }
    else{
    }

    /** 		emit_op(RETURNT)*/
    _41emit_op(34);
L1: 

    /** 	StraightenBranches()  -- straighten top-level*/
    _39StraightenBranches();

    /** end procedure*/
    return;
    ;
}


int _39undefined_var(int _tok_61063, int _scope_61064)
{
    int _forward_61066 = NOVALUE;
    int _30665 = NOVALUE;
    int _30664 = NOVALUE;
    int _30661 = NOVALUE;
    int _0, _1, _2;
    

    /** 	token forward = next_token()*/
    _0 = _forward_61066;
    _forward_61066 = _39next_token();
    DeRef(_0);

    /** 		switch forward[T_ID] do*/
    _2 = (int)SEQ_PTR(_forward_61066);
    _30661 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_30661) ){
        goto L1; // [16] 82
    }
    if(!IS_ATOM_INT(_30661)){
        if( (DBL_PTR(_30661)->dbl != (double) ((int) DBL_PTR(_30661)->dbl) ) ){
            goto L1; // [16] 82
        }
        _0 = (int) DBL_PTR(_30661)->dbl;
    }
    else {
        _0 = _30661;
    };
    _30661 = NOVALUE;
    switch ( _0 ){ 

        /** 			case LEFT_ROUND then*/
        case -26:

        /** 				StartSourceLine( TRUE )*/
        _41StartSourceLine(_13TRUE_436, 0, 2);

        /** 				Forward_call( tok )*/
        Ref(_tok_61063);
        _39Forward_call(_tok_61063, 195);

        /** 				return 1*/
        DeRef(_tok_61063);
        DeRef(_forward_61066);
        return 1;
        goto L2; // [48] 96

        /** 			case VARIABLE then*/
        case -100:

        /** 				putback( forward )*/
        Ref(_forward_61066);
        _39putback(_forward_61066);

        /** 				Global_declaration( tok[T_SYM], scope )*/
        _2 = (int)SEQ_PTR(_tok_61063);
        _30664 = (int)*(((s1_ptr)_2)->base + 2);
        Ref(_30664);
        _30665 = _39Global_declaration(_30664, _scope_61064);
        _30664 = NOVALUE;

        /** 				return 1*/
        DeRef(_tok_61063);
        DeRef(_forward_61066);
        DeRef(_30665);
        _30665 = NOVALUE;
        return 1;
        goto L2; // [78] 96

        /** 			case else*/
        default:
L1: 

        /** 				putback( forward )*/
        Ref(_forward_61066);
        _39putback(_forward_61066);

        /** 				return 0*/
        DeRef(_tok_61063);
        DeRef(_forward_61066);
        DeRef(_30665);
        _30665 = NOVALUE;
        return 0;
    ;}L2: 
    ;
}


void _39real_parser(int _nested_61085)
{
    int _tok_61087 = NOVALUE;
    int _id_61088 = NOVALUE;
    int _scope_61089 = NOVALUE;
    int _test_61230 = NOVALUE;
    int _30798 = NOVALUE;
    int _30796 = NOVALUE;
    int _30795 = NOVALUE;
    int _30794 = NOVALUE;
    int _30793 = NOVALUE;
    int _30792 = NOVALUE;
    int _30791 = NOVALUE;
    int _30790 = NOVALUE;
    int _30785 = NOVALUE;
    int _30784 = NOVALUE;
    int _30781 = NOVALUE;
    int _30779 = NOVALUE;
    int _30778 = NOVALUE;
    int _30775 = NOVALUE;
    int _30762 = NOVALUE;
    int _30755 = NOVALUE;
    int _30754 = NOVALUE;
    int _30752 = NOVALUE;
    int _30750 = NOVALUE;
    int _30749 = NOVALUE;
    int _30747 = NOVALUE;
    int _30745 = NOVALUE;
    int _30740 = NOVALUE;
    int _30738 = NOVALUE;
    int _30736 = NOVALUE;
    int _30735 = NOVALUE;
    int _30734 = NOVALUE;
    int _30732 = NOVALUE;
    int _30730 = NOVALUE;
    int _30728 = NOVALUE;
    int _30726 = NOVALUE;
    int _30725 = NOVALUE;
    int _30724 = NOVALUE;
    int _30723 = NOVALUE;
    int _30722 = NOVALUE;
    int _30721 = NOVALUE;
    int _30720 = NOVALUE;
    int _30719 = NOVALUE;
    int _30718 = NOVALUE;
    int _30717 = NOVALUE;
    int _30716 = NOVALUE;
    int _30715 = NOVALUE;
    int _30714 = NOVALUE;
    int _30713 = NOVALUE;
    int _30711 = NOVALUE;
    int _30710 = NOVALUE;
    int _30709 = NOVALUE;
    int _30708 = NOVALUE;
    int _30706 = NOVALUE;
    int _30704 = NOVALUE;
    int _30703 = NOVALUE;
    int _30702 = NOVALUE;
    int _30700 = NOVALUE;
    int _30693 = NOVALUE;
    int _30691 = NOVALUE;
    int _30690 = NOVALUE;
    int _30689 = NOVALUE;
    int _30688 = NOVALUE;
    int _30687 = NOVALUE;
    int _30686 = NOVALUE;
    int _30685 = NOVALUE;
    int _30683 = NOVALUE;
    int _30682 = NOVALUE;
    int _30681 = NOVALUE;
    int _30680 = NOVALUE;
    int _30679 = NOVALUE;
    int _30678 = NOVALUE;
    int _30677 = NOVALUE;
    int _30676 = NOVALUE;
    int _30675 = NOVALUE;
    int _30674 = NOVALUE;
    int _30672 = NOVALUE;
    int _30668 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_nested_61085)) {
        _1 = (long)(DBL_PTR(_nested_61085)->dbl);
        DeRefDS(_nested_61085);
        _nested_61085 = _1;
    }

    /** 	integer id*/

    /** 	integer scope*/

    /** 	while TRUE do  -- infinite loop until scanner aborts*/
L1: 
    if (_13TRUE_436 == 0)
    {
        goto L2; // [14] 1811
    }
    else{
    }

    /** 		if OpInline = 25000 then*/
    if (_35OpInline_16318 != 25000)
    goto L3; // [21] 35

    /** 			CompileErr("OpInline went nuts: [1]", OpInline )*/
    RefDS(_30667);
    _44CompileErr(_30667, _35OpInline_16318, 0);
L3: 

    /** 		start_index = length(Code)+1*/
    if (IS_SEQUENCE(_35Code_16332)){
            _30668 = SEQ_PTR(_35Code_16332)->length;
    }
    else {
        _30668 = 1;
    }
    _39start_index_54123 = _30668 + 1;
    _30668 = NOVALUE;

    /** 		tok = next_token()*/
    _0 = _tok_61087;
    _tok_61087 = _39next_token();
    DeRef(_0);

    /** 		id = tok[T_ID]*/
    _2 = (int)SEQ_PTR(_tok_61087);
    _id_61088 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_id_61088)){
        _id_61088 = (long)DBL_PTR(_id_61088)->dbl;
    }

    /** 		if id = VARIABLE or id = QUALIFIED_VARIABLE then*/
    _30672 = (_id_61088 == -100);
    if (_30672 != 0) {
        goto L4; // [69] 84
    }
    _30674 = (_id_61088 == 512);
    if (_30674 == 0)
    {
        DeRef(_30674);
        _30674 = NOVALUE;
        goto L5; // [80] 151
    }
    else{
        DeRef(_30674);
        _30674 = NOVALUE;
    }
L4: 

    /** 			if SymTab[tok[T_SYM]][S_SCOPE] = SC_UNDEFINED*/
    _2 = (int)SEQ_PTR(_tok_61087);
    _30675 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!IS_ATOM_INT(_30675)){
        _30676 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_30675)->dbl));
    }
    else{
        _30676 = (int)*(((s1_ptr)_2)->base + _30675);
    }
    _2 = (int)SEQ_PTR(_30676);
    _30677 = (int)*(((s1_ptr)_2)->base + 4);
    _30676 = NOVALUE;
    if (IS_ATOM_INT(_30677)) {
        _30678 = (_30677 == 9);
    }
    else {
        _30678 = binary_op(EQUALS, _30677, 9);
    }
    _30677 = NOVALUE;
    if (IS_ATOM_INT(_30678)) {
        if (_30678 == 0) {
            goto L6; // [110] 130
        }
    }
    else {
        if (DBL_PTR(_30678)->dbl == 0.0) {
            goto L6; // [110] 130
        }
    }
    Ref(_tok_61087);
    _30680 = _39undefined_var(_tok_61087, 5);
    if (_30680 == 0) {
        DeRef(_30680);
        _30680 = NOVALUE;
        goto L6; // [122] 130
    }
    else {
        if (!IS_ATOM_INT(_30680) && DBL_PTR(_30680)->dbl == 0.0){
            DeRef(_30680);
            _30680 = NOVALUE;
            goto L6; // [122] 130
        }
        DeRef(_30680);
        _30680 = NOVALUE;
    }
    DeRef(_30680);
    _30680 = NOVALUE;

    /** 				continue*/
    goto L1; // [127] 12
L6: 

    /** 			StartSourceLine(TRUE)*/
    _41StartSourceLine(_13TRUE_436, 0, 2);

    /** 			Assignment(tok)*/
    Ref(_tok_61087);
    _39Assignment(_tok_61087);

    /** 			ExecCommand()*/
    _39ExecCommand();
    goto L7; // [148] 1801
L5: 

    /** 		elsif id = PROCEDURE or id = FUNCTION or id = TYPE_DECL then*/
    _30681 = (_id_61088 == 405);
    if (_30681 != 0) {
        _30682 = 1;
        goto L8; // [159] 173
    }
    _30683 = (_id_61088 == 406);
    _30682 = (_30683 != 0);
L8: 
    if (_30682 != 0) {
        goto L9; // [173] 188
    }
    _30685 = (_id_61088 == 416);
    if (_30685 == 0)
    {
        DeRef(_30685);
        _30685 = NOVALUE;
        goto LA; // [184] 205
    }
    else{
        DeRef(_30685);
        _30685 = NOVALUE;
    }
L9: 

    /** 			SubProg(tok[T_ID], SC_LOCAL)*/
    _2 = (int)SEQ_PTR(_tok_61087);
    _30686 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_30686);
    _39SubProg(_30686, 5);
    _30686 = NOVALUE;
    goto L7; // [202] 1801
LA: 

    /** 		elsif id = GLOBAL or id = EXPORT or id = OVERRIDE or id = PUBLIC then*/
    _30687 = (_id_61088 == 412);
    if (_30687 != 0) {
        _30688 = 1;
        goto LB; // [213] 227
    }
    _30689 = (_id_61088 == 428);
    _30688 = (_30689 != 0);
LB: 
    if (_30688 != 0) {
        _30690 = 1;
        goto LC; // [227] 241
    }
    _30691 = (_id_61088 == 429);
    _30690 = (_30691 != 0);
LC: 
    if (_30690 != 0) {
        goto LD; // [241] 256
    }
    _30693 = (_id_61088 == 430);
    if (_30693 == 0)
    {
        DeRef(_30693);
        _30693 = NOVALUE;
        goto LE; // [252] 626
    }
    else{
        DeRef(_30693);
        _30693 = NOVALUE;
    }
LD: 

    /** 			if id = GLOBAL then*/
    if (_id_61088 != 412)
    goto LF; // [260] 276

    /** 			    scope = SC_GLOBAL*/
    _scope_61089 = 6;
    goto L10; // [273] 335
LF: 

    /** 			elsif id = EXPORT then*/
    if (_id_61088 != 428)
    goto L11; // [280] 296

    /** 				scope = SC_EXPORT*/
    _scope_61089 = 11;
    goto L10; // [293] 335
L11: 

    /** 			elsif id = OVERRIDE then*/
    if (_id_61088 != 429)
    goto L12; // [300] 316

    /** 				scope = SC_OVERRIDE*/
    _scope_61089 = 12;
    goto L10; // [313] 335
L12: 

    /** 			elsif id = PUBLIC then*/
    if (_id_61088 != 430)
    goto L13; // [320] 334

    /** 				scope = SC_PUBLIC*/
    _scope_61089 = 13;
L13: 
L10: 

    /** 			tok = next_token()*/
    _0 = _tok_61087;
    _tok_61087 = _39next_token();
    DeRef(_0);

    /** 			id = tok[T_ID]*/
    _2 = (int)SEQ_PTR(_tok_61087);
    _id_61088 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_id_61088)){
        _id_61088 = (long)DBL_PTR(_id_61088)->dbl;
    }

    /** 			if id = TYPE or id = QUALIFIED_TYPE then*/
    _30700 = (_id_61088 == 504);
    if (_30700 != 0) {
        goto L14; // [358] 373
    }
    _30702 = (_id_61088 == 522);
    if (_30702 == 0)
    {
        DeRef(_30702);
        _30702 = NOVALUE;
        goto L15; // [369] 391
    }
    else{
        DeRef(_30702);
        _30702 = NOVALUE;
    }
L14: 

    /** 				Global_declaration(tok[T_SYM], scope )*/
    _2 = (int)SEQ_PTR(_tok_61087);
    _30703 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_30703);
    _30704 = _39Global_declaration(_30703, _scope_61089);
    _30703 = NOVALUE;
    goto L7; // [388] 1801
L15: 

    /** 			elsif id = CONSTANT then*/
    if (_id_61088 != 417)
    goto L16; // [395] 415

    /** 				Global_declaration(0, scope )*/
    _30706 = _39Global_declaration(0, _scope_61089);

    /** 				ExecCommand()*/
    _39ExecCommand();
    goto L7; // [412] 1801
L16: 

    /** 			elsif id = ENUM then*/
    if (_id_61088 != 427)
    goto L17; // [419] 439

    /** 				Global_declaration(-1, scope )*/
    _30708 = _39Global_declaration(-1, _scope_61089);

    /** 				ExecCommand()*/
    _39ExecCommand();
    goto L7; // [436] 1801
L17: 

    /** 			elsif id = PROCEDURE or id = FUNCTION or id = TYPE_DECL then*/
    _30709 = (_id_61088 == 405);
    if (_30709 != 0) {
        _30710 = 1;
        goto L18; // [447] 461
    }
    _30711 = (_id_61088 == 406);
    _30710 = (_30711 != 0);
L18: 
    if (_30710 != 0) {
        goto L19; // [461] 476
    }
    _30713 = (_id_61088 == 416);
    if (_30713 == 0)
    {
        DeRef(_30713);
        _30713 = NOVALUE;
        goto L1A; // [472] 487
    }
    else{
        DeRef(_30713);
        _30713 = NOVALUE;
    }
L19: 

    /** 				SubProg(id, scope )*/
    _39SubProg(_id_61088, _scope_61089);
    goto L7; // [484] 1801
L1A: 

    /** 			elsif (scope = SC_PUBLIC) and id = INCLUDE then*/
    _30714 = (_scope_61089 == 13);
    if (_30714 == 0) {
        goto L1B; // [497] 523
    }
    _30716 = (_id_61088 == 418);
    if (_30716 == 0)
    {
        DeRef(_30716);
        _30716 = NOVALUE;
        goto L1B; // [508] 523
    }
    else{
        DeRef(_30716);
        _30716 = NOVALUE;
    }

    /** 				IncludeScan( 1 )*/
    _61IncludeScan(1);

    /** 				PushGoto()*/
    _39PushGoto();
    goto L7; // [520] 1801
L1B: 

    /** 			elsif (id = VARIABLE or id = QUALIFIED_VARIABLE)*/
    _30717 = (_id_61088 == -100);
    if (_30717 != 0) {
        _30718 = 1;
        goto L1C; // [531] 545
    }
    _30719 = (_id_61088 == 512);
    _30718 = (_30719 != 0);
L1C: 
    if (_30718 == 0) {
        _30720 = 0;
        goto L1D; // [545] 577
    }
    _2 = (int)SEQ_PTR(_tok_61087);
    _30721 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!IS_ATOM_INT(_30721)){
        _30722 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_30721)->dbl));
    }
    else{
        _30722 = (int)*(((s1_ptr)_2)->base + _30721);
    }
    _2 = (int)SEQ_PTR(_30722);
    _30723 = (int)*(((s1_ptr)_2)->base + 4);
    _30722 = NOVALUE;
    if (IS_ATOM_INT(_30723)) {
        _30724 = (_30723 == 9);
    }
    else {
        _30724 = binary_op(EQUALS, _30723, 9);
    }
    _30723 = NOVALUE;
    if (IS_ATOM_INT(_30724))
    _30720 = (_30724 != 0);
    else
    _30720 = DBL_PTR(_30724)->dbl != 0.0;
L1D: 
    if (_30720 == 0) {
        goto L1E; // [577] 597
    }
    Ref(_tok_61087);
    _30726 = _39undefined_var(_tok_61087, _scope_61089);
    if (_30726 == 0) {
        DeRef(_30726);
        _30726 = NOVALUE;
        goto L1E; // [587] 597
    }
    else {
        if (!IS_ATOM_INT(_30726) && DBL_PTR(_30726)->dbl == 0.0){
            DeRef(_30726);
            _30726 = NOVALUE;
            goto L1E; // [587] 597
        }
        DeRef(_30726);
        _30726 = NOVALUE;
    }
    DeRef(_30726);
    _30726 = NOVALUE;

    /** 				continue*/
    goto L1; // [592] 12
    goto L7; // [594] 1801
L1E: 

    /** 			elsif scope = SC_GLOBAL then*/
    if (_scope_61089 != 6)
    goto L1F; // [601] 615

    /** 				CompileErr( 18 )*/
    RefDS(_22023);
    _44CompileErr(18, _22023, 0);
    goto L7; // [612] 1801
L1F: 

    /** 				CompileErr( 16 )*/
    RefDS(_22023);
    _44CompileErr(16, _22023, 0);
    goto L7; // [623] 1801
LE: 

    /** 		elsif id = TYPE or id = QUALIFIED_TYPE then*/
    _30728 = (_id_61088 == 504);
    if (_30728 != 0) {
        goto L20; // [634] 649
    }
    _30730 = (_id_61088 == 522);
    if (_30730 == 0)
    {
        DeRef(_30730);
        _30730 = NOVALUE;
        goto L21; // [645] 734
    }
    else{
        DeRef(_30730);
        _30730 = NOVALUE;
    }
L20: 

    /** 			token test = next_token()*/
    _0 = _test_61230;
    _test_61230 = _39next_token();
    DeRef(_0);

    /** 			putback( test )*/
    Ref(_test_61230);
    _39putback(_test_61230);

    /** 			if test[T_ID] = LEFT_ROUND then*/
    _2 = (int)SEQ_PTR(_test_61230);
    _30732 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30732, -26)){
        _30732 = NOVALUE;
        goto L22; // [669] 707
    }
    _30732 = NOVALUE;

    /** 					StartSourceLine( TRUE )*/
    _41StartSourceLine(_13TRUE_436, 0, 2);

    /** 					Procedure_call(tok)*/
    Ref(_tok_61087);
    _39Procedure_call(_tok_61087);

    /** 					clear_op()*/
    _41clear_op();

    /** 					if Pop() then end if*/
    _30734 = _41Pop();
    if (_30734 == 0) {
        DeRef(_30734);
        _30734 = NOVALUE;
        goto L23; // [696] 700
    }
    else {
        if (!IS_ATOM_INT(_30734) && DBL_PTR(_30734)->dbl == 0.0){
            DeRef(_30734);
            _30734 = NOVALUE;
            goto L23; // [696] 700
        }
        DeRef(_30734);
        _30734 = NOVALUE;
    }
    DeRef(_30734);
    _30734 = NOVALUE;
L23: 

    /** 					ExecCommand()*/
    _39ExecCommand();
    goto L24; // [704] 723
L22: 

    /** 				Global_declaration( tok[T_SYM], SC_LOCAL )*/
    _2 = (int)SEQ_PTR(_tok_61087);
    _30735 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_30735);
    _30736 = _39Global_declaration(_30735, 5);
    _30735 = NOVALUE;
L24: 

    /** 			continue*/
    DeRef(_test_61230);
    _test_61230 = NOVALUE;
    goto L1; // [727] 12
    goto L7; // [731] 1801
L21: 

    /** 		elsif id = CONSTANT then*/
    if (_id_61088 != 417)
    goto L25; // [738] 758

    /** 			Global_declaration(0, SC_LOCAL)*/
    _30738 = _39Global_declaration(0, 5);

    /** 			ExecCommand()*/
    _39ExecCommand();
    goto L7; // [755] 1801
L25: 

    /** 		elsif id = ENUM then*/
    if (_id_61088 != 427)
    goto L26; // [762] 782

    /** 			Global_declaration(-1, SC_LOCAL)*/
    _30740 = _39Global_declaration(-1, 5);

    /** 			ExecCommand()*/
    _39ExecCommand();
    goto L7; // [779] 1801
L26: 

    /** 		elsif id = IF then*/
    if (_id_61088 != 20)
    goto L27; // [786] 810

    /** 			StartSourceLine(TRUE)*/
    _41StartSourceLine(_13TRUE_436, 0, 2);

    /** 			If_statement()*/
    _39If_statement();

    /** 			ExecCommand()*/
    _39ExecCommand();
    goto L7; // [807] 1801
L27: 

    /** 		elsif id = FOR then*/
    if (_id_61088 != 21)
    goto L28; // [814] 838

    /** 			StartSourceLine(TRUE)*/
    _41StartSourceLine(_13TRUE_436, 0, 2);

    /** 			For_statement()*/
    _39For_statement();

    /** 			ExecCommand()*/
    _39ExecCommand();
    goto L7; // [835] 1801
L28: 

    /** 		elsif id = WHILE then*/
    if (_id_61088 != 47)
    goto L29; // [842] 866

    /** 			StartSourceLine(TRUE)*/
    _41StartSourceLine(_13TRUE_436, 0, 2);

    /** 			While_statement()*/
    _39While_statement();

    /** 			ExecCommand()*/
    _39ExecCommand();
    goto L7; // [863] 1801
L29: 

    /** 		elsif id = LOOP then*/
    if (_id_61088 != 422)
    goto L2A; // [870] 894

    /** 		    StartSourceLine(TRUE)*/
    _41StartSourceLine(_13TRUE_436, 0, 2);

    /** 		    Loop_statement()*/
    _39Loop_statement();

    /** 		    ExecCommand()*/
    _39ExecCommand();
    goto L7; // [891] 1801
L2A: 

    /** 		elsif id = PROC or id = QUALIFIED_PROC then*/
    _30745 = (_id_61088 == 27);
    if (_30745 != 0) {
        goto L2B; // [902] 917
    }
    _30747 = (_id_61088 == 521);
    if (_30747 == 0)
    {
        DeRef(_30747);
        _30747 = NOVALUE;
        goto L2C; // [913] 958
    }
    else{
        DeRef(_30747);
        _30747 = NOVALUE;
    }
L2B: 

    /** 			StartSourceLine(TRUE)*/
    _41StartSourceLine(_13TRUE_436, 0, 2);

    /** 			if id = PROC then*/
    if (_id_61088 != 27)
    goto L2D; // [930] 946

    /** 				UndefinedVar( tok[T_SYM] )*/
    _2 = (int)SEQ_PTR(_tok_61087);
    _30749 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_30749);
    _39UndefinedVar(_30749);
    _30749 = NOVALUE;
L2D: 

    /** 			Procedure_call(tok)*/
    Ref(_tok_61087);
    _39Procedure_call(_tok_61087);

    /** 			ExecCommand()*/
    _39ExecCommand();
    goto L7; // [955] 1801
L2C: 

    /** 		elsif id = FUNC or id = QUALIFIED_FUNC then*/
    _30750 = (_id_61088 == 501);
    if (_30750 != 0) {
        goto L2E; // [966] 981
    }
    _30752 = (_id_61088 == 520);
    if (_30752 == 0)
    {
        DeRef(_30752);
        _30752 = NOVALUE;
        goto L2F; // [977] 1035
    }
    else{
        DeRef(_30752);
        _30752 = NOVALUE;
    }
L2E: 

    /** 			StartSourceLine(TRUE)*/
    _41StartSourceLine(_13TRUE_436, 0, 2);

    /** 			if id = FUNC then*/
    if (_id_61088 != 501)
    goto L30; // [994] 1010

    /** 				UndefinedVar( tok[T_SYM] )*/
    _2 = (int)SEQ_PTR(_tok_61087);
    _30754 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_30754);
    _39UndefinedVar(_30754);
    _30754 = NOVALUE;
L30: 

    /** 			Procedure_call(tok)*/
    Ref(_tok_61087);
    _39Procedure_call(_tok_61087);

    /** 			clear_op()*/
    _41clear_op();

    /** 			if Pop() then end if*/
    _30755 = _41Pop();
    if (_30755 == 0) {
        DeRef(_30755);
        _30755 = NOVALUE;
        goto L31; // [1024] 1028
    }
    else {
        if (!IS_ATOM_INT(_30755) && DBL_PTR(_30755)->dbl == 0.0){
            DeRef(_30755);
            _30755 = NOVALUE;
            goto L31; // [1024] 1028
        }
        DeRef(_30755);
        _30755 = NOVALUE;
    }
    DeRef(_30755);
    _30755 = NOVALUE;
L31: 

    /** 			ExecCommand()*/
    _39ExecCommand();
    goto L7; // [1032] 1801
L2F: 

    /** 		elsif id = RETURN then*/
    if (_id_61088 != 413)
    goto L32; // [1039] 1050

    /** 			Return_statement() -- will fail - not allowed at top level*/
    _39Return_statement();
    goto L7; // [1047] 1801
L32: 

    /** 		elsif id = EXIT then*/
    if (_id_61088 != 61)
    goto L33; // [1054] 1090

    /** 			if nested then*/
    if (_nested_61085 == 0)
    {
        goto L34; // [1060] 1079
    }
    else{
    }

    /** 			StartSourceLine(TRUE)*/
    _41StartSourceLine(_13TRUE_436, 0, 2);

    /** 			Exit_statement()*/
    _39Exit_statement();
    goto L7; // [1076] 1801
L34: 

    /** 			CompileErr(89)*/
    RefDS(_22023);
    _44CompileErr(89, _22023, 0);
    goto L7; // [1087] 1801
L33: 

    /** 		elsif id = INCLUDE then*/
    if (_id_61088 != 418)
    goto L35; // [1094] 1110

    /** 			IncludeScan( 0 )*/
    _61IncludeScan(0);

    /** 			PushGoto()*/
    _39PushGoto();
    goto L7; // [1107] 1801
L35: 

    /** 		elsif id = WITH then*/
    if (_id_61088 != 420)
    goto L36; // [1114] 1128

    /** 			SetWith(TRUE)*/
    _39SetWith(_13TRUE_436);
    goto L7; // [1125] 1801
L36: 

    /** 		elsif id = WITHOUT then*/
    if (_id_61088 != 421)
    goto L37; // [1132] 1146

    /** 			SetWith(FALSE)*/
    _39SetWith(_13FALSE_434);
    goto L7; // [1143] 1801
L37: 

    /** 		elsif id = END_OF_FILE then*/
    if (_id_61088 != -21)
    goto L38; // [1150] 1267

    /** 			if IncludePop() then*/
    _30762 = _61IncludePop();
    if (_30762 == 0) {
        DeRef(_30762);
        _30762 = NOVALUE;
        goto L39; // [1159] 1255
    }
    else {
        if (!IS_ATOM_INT(_30762) && DBL_PTR(_30762)->dbl == 0.0){
            DeRef(_30762);
            _30762 = NOVALUE;
            goto L39; // [1159] 1255
        }
        DeRef(_30762);
        _30762 = NOVALUE;
    }
    DeRef(_30762);
    _30762 = NOVALUE;

    /** 				backed_up_tok = {}*/
    RefDS(_22023);
    DeRef(_39backed_up_tok_54124);
    _39backed_up_tok_54124 = _22023;

    /** 				PopGoto()*/
    _39PopGoto();

    /** 				read_line()*/
    _61read_line();

    /** 				last_ForwardLine     = ThisLine*/
    Ref(_44ThisLine_48518);
    DeRef(_44last_ForwardLine_48521);
    _44last_ForwardLine_48521 = _44ThisLine_48518;

    /** 				last_fwd_line_number = line_number*/
    _35last_fwd_line_number_16248 = _35line_number_16245;

    /** 				last_forward_bp      = bp*/
    _44last_forward_bp_48525 = _44bp_48522;

    /** 				putback_ForwardLine     = ThisLine*/
    Ref(_44ThisLine_48518);
    DeRef(_44putback_ForwardLine_48520);
    _44putback_ForwardLine_48520 = _44ThisLine_48518;

    /** 				putback_fwd_line_number = line_number*/
    _35putback_fwd_line_number_16247 = _35line_number_16245;

    /** 				putback_forward_bp      = bp*/
    _44putback_forward_bp_48524 = _44bp_48522;

    /** 				ForwardLine     = ThisLine*/
    Ref(_44ThisLine_48518);
    DeRef(_44ForwardLine_48519);
    _44ForwardLine_48519 = _44ThisLine_48518;

    /** 				fwd_line_number = line_number*/
    _35fwd_line_number_16246 = _35line_number_16245;

    /** 				forward_bp      = bp*/
    _44forward_bp_48523 = _44bp_48522;
    goto L7; // [1252] 1801
L39: 

    /** 				CheckForUndefinedGotoLabels()*/
    _39CheckForUndefinedGotoLabels();

    /** 				exit -- all finished*/
    goto L2; // [1261] 1811
    goto L7; // [1264] 1801
L38: 

    /** 		elsif id = QUESTION_MARK then*/
    if (_id_61088 != -31)
    goto L3A; // [1271] 1295

    /** 			StartSourceLine(TRUE)*/
    _41StartSourceLine(_13TRUE_436, 0, 2);

    /** 			Print_statement()*/
    _39Print_statement();

    /** 			ExecCommand()*/
    _39ExecCommand();
    goto L7; // [1292] 1801
L3A: 

    /** 		elsif id = LABEL then*/
    if (_id_61088 != 419)
    goto L3B; // [1299] 1321

    /** 			StartSourceLine(TRUE, , COVERAGE_SUPPRESS)*/
    _41StartSourceLine(_13TRUE_436, 0, 1);

    /** 			GLabel_statement()*/
    _39GLabel_statement();
    goto L7; // [1318] 1801
L3B: 

    /** 		elsif id = GOTO then*/
    if (_id_61088 != 188)
    goto L3C; // [1325] 1345

    /** 			StartSourceLine(TRUE)*/
    _41StartSourceLine(_13TRUE_436, 0, 2);

    /** 			Goto_statement()*/
    _39Goto_statement();
    goto L7; // [1342] 1801
L3C: 

    /** 		elsif id = CONTINUE then*/
    if (_id_61088 != 426)
    goto L3D; // [1349] 1385

    /** 			if nested then*/
    if (_nested_61085 == 0)
    {
        goto L3E; // [1355] 1374
    }
    else{
    }

    /** 				StartSourceLine(TRUE)*/
    _41StartSourceLine(_13TRUE_436, 0, 2);

    /** 				Continue_statement()*/
    _39Continue_statement();
    goto L7; // [1371] 1801
L3E: 

    /** 				CompileErr(50)*/
    RefDS(_22023);
    _44CompileErr(50, _22023, 0);
    goto L7; // [1382] 1801
L3D: 

    /** 		elsif id = RETRY then*/
    if (_id_61088 != 184)
    goto L3F; // [1389] 1425

    /** 			if nested then*/
    if (_nested_61085 == 0)
    {
        goto L40; // [1395] 1414
    }
    else{
    }

    /** 				StartSourceLine(TRUE)*/
    _41StartSourceLine(_13TRUE_436, 0, 2);

    /** 				Retry_statement()*/
    _39Retry_statement();
    goto L7; // [1411] 1801
L40: 

    /** 				CompileErr(128)*/
    RefDS(_22023);
    _44CompileErr(128, _22023, 0);
    goto L7; // [1422] 1801
L3F: 

    /** 		elsif id = BREAK then*/
    if (_id_61088 != 425)
    goto L41; // [1429] 1465

    /** 			if nested then*/
    if (_nested_61085 == 0)
    {
        goto L42; // [1435] 1454
    }
    else{
    }

    /** 				StartSourceLine(TRUE)*/
    _41StartSourceLine(_13TRUE_436, 0, 2);

    /** 				Break_statement()*/
    _39Break_statement();
    goto L7; // [1451] 1801
L42: 

    /** 				CompileErr(39)*/
    RefDS(_22023);
    _44CompileErr(39, _22023, 0);
    goto L7; // [1462] 1801
L41: 

    /** 		elsif id = ENTRY then*/
    if (_id_61088 != 424)
    goto L43; // [1469] 1507

    /** 			if nested then*/
    if (_nested_61085 == 0)
    {
        goto L44; // [1475] 1496
    }
    else{
    }

    /** 			    StartSourceLine(TRUE, , COVERAGE_SUPPRESS)*/
    _41StartSourceLine(_13TRUE_436, 0, 1);

    /** 			    Entry_statement()*/
    _39Entry_statement();
    goto L7; // [1493] 1801
L44: 

    /** 				CompileErr(72)*/
    RefDS(_22023);
    _44CompileErr(72, _22023, 0);
    goto L7; // [1504] 1801
L43: 

    /** 		elsif id = IFDEF then*/
    if (_id_61088 != 407)
    goto L45; // [1511] 1531

    /** 			StartSourceLine(TRUE)*/
    _41StartSourceLine(_13TRUE_436, 0, 2);

    /** 			Ifdef_statement()*/
    _39Ifdef_statement();
    goto L7; // [1528] 1801
L45: 

    /** 		elsif id = CASE then*/
    if (_id_61088 != 186)
    goto L46; // [1535] 1546

    /** 			Case_statement()*/
    _39Case_statement();
    goto L7; // [1543] 1801
L46: 

    /** 		elsif id = SWITCH then*/
    if (_id_61088 != 185)
    goto L47; // [1550] 1570

    /** 			StartSourceLine(TRUE)*/
    _41StartSourceLine(_13TRUE_436, 0, 2);

    /** 			Switch_statement()*/
    _39Switch_statement();
    goto L7; // [1567] 1801
L47: 

    /** 		elsif id = ILLEGAL_CHAR then*/
    if (_id_61088 != -20)
    goto L48; // [1574] 1588

    /** 			CompileErr(102)*/
    RefDS(_22023);
    _44CompileErr(102, _22023, 0);
    goto L7; // [1585] 1801
L48: 

    /** 			if nested then*/
    if (_nested_61085 == 0)
    {
        goto L49; // [1590] 1742
    }
    else{
    }

    /** 				if id = ELSE then*/
    if (_id_61088 != 23)
    goto L4A; // [1597] 1651

    /** 					if length(if_stack) = 0 then*/
    if (IS_SEQUENCE(_39if_stack_54152)){
            _30775 = SEQ_PTR(_39if_stack_54152)->length;
    }
    else {
        _30775 = 1;
    }
    if (_30775 != 0)
    goto L4B; // [1608] 1708

    /** 						if live_ifdef > 0 then*/
    if (_39live_ifdef_58290 <= 0)
    goto L4C; // [1616] 1639

    /** 							CompileErr(134, ifdef_lineno[$])*/
    if (IS_SEQUENCE(_39ifdef_lineno_58291)){
            _30778 = SEQ_PTR(_39ifdef_lineno_58291)->length;
    }
    else {
        _30778 = 1;
    }
    _2 = (int)SEQ_PTR(_39ifdef_lineno_58291);
    _30779 = (int)*(((s1_ptr)_2)->base + _30778);
    _44CompileErr(134, _30779, 0);
    _30779 = NOVALUE;
    goto L4B; // [1636] 1708
L4C: 

    /** 							CompileErr(118)*/
    RefDS(_22023);
    _44CompileErr(118, _22023, 0);
    goto L4B; // [1648] 1708
L4A: 

    /** 				elsif id = ELSIF then*/
    if (_id_61088 != 414)
    goto L4D; // [1655] 1707

    /** 					if length(if_stack) = 0 then*/
    if (IS_SEQUENCE(_39if_stack_54152)){
            _30781 = SEQ_PTR(_39if_stack_54152)->length;
    }
    else {
        _30781 = 1;
    }
    if (_30781 != 0)
    goto L4E; // [1666] 1706

    /** 						if live_ifdef > 0 then*/
    if (_39live_ifdef_58290 <= 0)
    goto L4F; // [1674] 1697

    /** 							CompileErr(139, ifdef_lineno[$])*/
    if (IS_SEQUENCE(_39ifdef_lineno_58291)){
            _30784 = SEQ_PTR(_39ifdef_lineno_58291)->length;
    }
    else {
        _30784 = 1;
    }
    _2 = (int)SEQ_PTR(_39ifdef_lineno_58291);
    _30785 = (int)*(((s1_ptr)_2)->base + _30784);
    _44CompileErr(139, _30785, 0);
    _30785 = NOVALUE;
    goto L50; // [1694] 1705
L4F: 

    /** 							CompileErr(119)*/
    RefDS(_22023);
    _44CompileErr(119, _22023, 0);
L50: 
L4E: 
L4D: 
L4B: 

    /** 				putback(tok)*/
    Ref(_tok_61087);
    _39putback(_tok_61087);

    /** 				if stmt_nest > 0 then*/
    if (_39stmt_nest_54149 <= 0)
    goto L51; // [1717] 1734

    /** 					stmt_nest -= 1*/
    _39stmt_nest_54149 = _39stmt_nest_54149 - 1;

    /** 					InitDelete()*/
    _39InitDelete();
L51: 

    /** 				return*/
    DeRef(_tok_61087);
    DeRef(_30750);
    _30750 = NOVALUE;
    DeRef(_30708);
    _30708 = NOVALUE;
    DeRef(_30714);
    _30714 = NOVALUE;
    DeRef(_30738);
    _30738 = NOVALUE;
    DeRef(_30683);
    _30683 = NOVALUE;
    DeRef(_30711);
    _30711 = NOVALUE;
    DeRef(_30728);
    _30728 = NOVALUE;
    DeRef(_30704);
    _30704 = NOVALUE;
    DeRef(_30687);
    _30687 = NOVALUE;
    DeRef(_30717);
    _30717 = NOVALUE;
    DeRef(_30740);
    _30740 = NOVALUE;
    DeRef(_30736);
    _30736 = NOVALUE;
    DeRef(_30691);
    _30691 = NOVALUE;
    DeRef(_30700);
    _30700 = NOVALUE;
    DeRef(_30689);
    _30689 = NOVALUE;
    DeRef(_30709);
    _30709 = NOVALUE;
    DeRef(_30719);
    _30719 = NOVALUE;
    DeRef(_30681);
    _30681 = NOVALUE;
    DeRef(_30745);
    _30745 = NOVALUE;
    DeRef(_30706);
    _30706 = NOVALUE;
    DeRef(_30672);
    _30672 = NOVALUE;
    DeRef(_30678);
    _30678 = NOVALUE;
    _30675 = NOVALUE;
    DeRef(_30724);
    _30724 = NOVALUE;
    _30721 = NOVALUE;
    return;
    goto L52; // [1739] 1800
L49: 

    /** 				if id = END then*/
    if (_id_61088 != 402)
    goto L53; // [1746] 1777

    /** 					tok = next_token()*/
    _0 = _tok_61087;
    _tok_61087 = _39next_token();
    DeRef(_0);

    /** 					CompileErr(17, {find_token_text(tok[T_ID])})*/
    _2 = (int)SEQ_PTR(_tok_61087);
    _30790 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_30790);
    _30791 = _63find_token_text(_30790);
    _30790 = NOVALUE;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _30791;
    _30792 = MAKE_SEQ(_1);
    _30791 = NOVALUE;
    _44CompileErr(17, _30792, 0);
    _30792 = NOVALUE;
L53: 

    /** 				CompileErr(117, { match_replace(",", find_token_text(id), "") })*/
    _30793 = _63find_token_text(_id_61088);
    RefDS(_26290);
    RefDS(_22023);
    _30794 = _16match_replace(_26290, _30793, _22023, 0);
    _30793 = NOVALUE;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _30794;
    _30795 = MAKE_SEQ(_1);
    _30794 = NOVALUE;
    _44CompileErr(117, _30795, 0);
    _30795 = NOVALUE;
L52: 
L7: 

    /** 		flush_temps()*/
    RefDS(_22023);
    _41flush_temps(_22023);

    /** 	end while*/
    goto L1; // [1808] 12
L2: 

    /** 	emit_op(RETURNT)*/
    _41emit_op(34);

    /** 	clear_last()*/
    _41clear_last();

    /** 	StraightenBranches()*/
    _39StraightenBranches();

    /** 	SymTab[TopLevelSub][S_CODE] = Code*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_35TopLevelSub_16251 + ((s1_ptr)_2)->base);
    RefDS(_35Code_16332);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35S_CODE_15929))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_CODE_15929)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _35S_CODE_15929);
    _1 = *(int *)_2;
    *(int *)_2 = _35Code_16332;
    DeRef(_1);
    _30796 = NOVALUE;

    /** 	EndLineTable()*/
    _39EndLineTable();

    /** 	SymTab[TopLevelSub][S_LINETAB] = LineTable*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_35TopLevelSub_16251 + ((s1_ptr)_2)->base);
    RefDS(_35LineTable_16333);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35S_LINETAB_15952))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_LINETAB_15952)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _35S_LINETAB_15952);
    _1 = *(int *)_2;
    *(int *)_2 = _35LineTable_16333;
    DeRef(_1);
    _30798 = NOVALUE;

    /** end procedure*/
    DeRef(_tok_61087);
    DeRef(_30750);
    _30750 = NOVALUE;
    DeRef(_30708);
    _30708 = NOVALUE;
    DeRef(_30714);
    _30714 = NOVALUE;
    DeRef(_30738);
    _30738 = NOVALUE;
    DeRef(_30683);
    _30683 = NOVALUE;
    DeRef(_30711);
    _30711 = NOVALUE;
    DeRef(_30728);
    _30728 = NOVALUE;
    DeRef(_30704);
    _30704 = NOVALUE;
    DeRef(_30687);
    _30687 = NOVALUE;
    DeRef(_30717);
    _30717 = NOVALUE;
    DeRef(_30740);
    _30740 = NOVALUE;
    DeRef(_30736);
    _30736 = NOVALUE;
    DeRef(_30691);
    _30691 = NOVALUE;
    DeRef(_30700);
    _30700 = NOVALUE;
    DeRef(_30689);
    _30689 = NOVALUE;
    DeRef(_30709);
    _30709 = NOVALUE;
    DeRef(_30719);
    _30719 = NOVALUE;
    DeRef(_30681);
    _30681 = NOVALUE;
    DeRef(_30745);
    _30745 = NOVALUE;
    DeRef(_30706);
    _30706 = NOVALUE;
    DeRef(_30672);
    _30672 = NOVALUE;
    DeRef(_30678);
    _30678 = NOVALUE;
    _30675 = NOVALUE;
    DeRef(_30724);
    _30724 = NOVALUE;
    _30721 = NOVALUE;
    return;
    ;
}


void _39parser()
{
    int _0, _1, _2;
    

    /** 	real_parser(0)*/
    _39real_parser(0);

    /** 	mark_final_targets()*/
    _53mark_final_targets();

    /** 	resolve_unincluded_globals( 1 )*/
    _53resolve_unincluded_globals(1);

    /** 	Resolve_forward_references( 1 )*/
    _38Resolve_forward_references(1);

    /** 	inline_deferred_calls()*/
    _67inline_deferred_calls();

    /** 	End_block( PROC )*/
    _66End_block(27);

    /** 	Code = {}*/
    RefDS(_22023);
    DeRef(_35Code_16332);
    _35Code_16332 = _22023;

    /** 	LineTable = {}*/
    RefDS(_22023);
    DeRef(_35LineTable_16333);
    _35LineTable_16333 = _22023;

    /** end procedure*/
    return;
    ;
}


void _39nested_parser()
{
    int _0, _1, _2;
    

    /** 	real_parser(1)*/
    _39real_parser(1);

    /** end procedure*/
    return;
    ;
}



// 0xFD0AA6CD
