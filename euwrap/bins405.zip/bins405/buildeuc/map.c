// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int _28map(int _obj_p_11603)
{
    int _m__11607 = NOVALUE;
    int _6493 = NOVALUE;
    int _6492 = NOVALUE;
    int _6491 = NOVALUE;
    int _6490 = NOVALUE;
    int _6489 = NOVALUE;
    int _6488 = NOVALUE;
    int _6487 = NOVALUE;
    int _6486 = NOVALUE;
    int _6485 = NOVALUE;
    int _6484 = NOVALUE;
    int _6482 = NOVALUE;
    int _6481 = NOVALUE;
    int _6480 = NOVALUE;
    int _6479 = NOVALUE;
    int _6477 = NOVALUE;
    int _6476 = NOVALUE;
    int _6475 = NOVALUE;
    int _6474 = NOVALUE;
    int _6472 = NOVALUE;
    int _6471 = NOVALUE;
    int _6470 = NOVALUE;
    int _6469 = NOVALUE;
    int _6468 = NOVALUE;
    int _6467 = NOVALUE;
    int _6466 = NOVALUE;
    int _6465 = NOVALUE;
    int _6464 = NOVALUE;
    int _6463 = NOVALUE;
    int _6461 = NOVALUE;
    int _6459 = NOVALUE;
    int _6458 = NOVALUE;
    int _6456 = NOVALUE;
    int _6454 = NOVALUE;
    int _6453 = NOVALUE;
    int _6451 = NOVALUE;
    int _6450 = NOVALUE;
    int _6448 = NOVALUE;
    int _6446 = NOVALUE;
    int _6444 = NOVALUE;
    int _6441 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not eumem:valid(obj_p, "") then return 0 end if*/
    Ref(_obj_p_11603);
    RefDS(_5);
    _6441 = _29valid(_obj_p_11603, _5);
    if (IS_ATOM_INT(_6441)) {
        if (_6441 != 0){
            DeRef(_6441);
            _6441 = NOVALUE;
            goto L1; // [8] 16
        }
    }
    else {
        if (DBL_PTR(_6441)->dbl != 0.0){
            DeRef(_6441);
            _6441 = NOVALUE;
            goto L1; // [8] 16
        }
    }
    DeRef(_6441);
    _6441 = NOVALUE;
    DeRef(_obj_p_11603);
    DeRef(_m__11607);
    return 0;
L1: 

    /** 	object m_*/

    /** 	m_ = eumem:ram_space[obj_p]*/
    DeRef(_m__11607);
    _2 = (int)SEQ_PTR(_29ram_space_10710);
    if (!IS_ATOM_INT(_obj_p_11603)){
        _m__11607 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_obj_p_11603)->dbl));
    }
    else{
        _m__11607 = (int)*(((s1_ptr)_2)->base + _obj_p_11603);
    }
    Ref(_m__11607);

    /** 	if not sequence(m_) then return 0 end if*/
    _6444 = IS_SEQUENCE(_m__11607);
    if (_6444 != 0)
    goto L2; // [31] 39
    _6444 = NOVALUE;
    DeRef(_obj_p_11603);
    DeRef(_m__11607);
    return 0;
L2: 

    /** 	if length(m_) < 6 then return 0 end if*/
    if (IS_SEQUENCE(_m__11607)){
            _6446 = SEQ_PTR(_m__11607)->length;
    }
    else {
        _6446 = 1;
    }
    if (_6446 >= 6)
    goto L3; // [44] 53
    DeRef(_obj_p_11603);
    DeRef(_m__11607);
    return 0;
L3: 

    /** 	if length(m_) > 7 then return 0 end if*/
    if (IS_SEQUENCE(_m__11607)){
            _6448 = SEQ_PTR(_m__11607)->length;
    }
    else {
        _6448 = 1;
    }
    if (_6448 <= 7)
    goto L4; // [58] 67
    DeRef(_obj_p_11603);
    DeRef(_m__11607);
    return 0;
L4: 

    /** 	if not equal(m_[TYPE_TAG], type_is_map) then return 0 end if*/
    _2 = (int)SEQ_PTR(_m__11607);
    _6450 = (int)*(((s1_ptr)_2)->base + 1);
    if (_6450 == _28type_is_map_11582)
    _6451 = 1;
    else if (IS_ATOM_INT(_6450) && IS_ATOM_INT(_28type_is_map_11582))
    _6451 = 0;
    else
    _6451 = (compare(_6450, _28type_is_map_11582) == 0);
    _6450 = NOVALUE;
    if (_6451 != 0)
    goto L5; // [77] 85
    _6451 = NOVALUE;
    DeRef(_obj_p_11603);
    DeRef(_m__11607);
    return 0;
L5: 

    /** 	if not integer(m_[ELEMENT_COUNT]) then return 0 end if*/
    _2 = (int)SEQ_PTR(_m__11607);
    _6453 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_6453))
    _6454 = 1;
    else if (IS_ATOM_DBL(_6453))
    _6454 = IS_ATOM_INT(DoubleToInt(_6453));
    else
    _6454 = 0;
    _6453 = NOVALUE;
    if (_6454 != 0)
    goto L6; // [94] 102
    _6454 = NOVALUE;
    DeRef(_obj_p_11603);
    DeRef(_m__11607);
    return 0;
L6: 

    /** 	if m_[ELEMENT_COUNT] < 0 		then return 0 end if*/
    _2 = (int)SEQ_PTR(_m__11607);
    _6456 = (int)*(((s1_ptr)_2)->base + 2);
    if (binary_op_a(GREATEREQ, _6456, 0)){
        _6456 = NOVALUE;
        goto L7; // [108] 117
    }
    _6456 = NOVALUE;
    DeRef(_obj_p_11603);
    DeRef(_m__11607);
    return 0;
L7: 

    /** 	if not integer(m_[IN_USE]) then return 0 end if*/
    _2 = (int)SEQ_PTR(_m__11607);
    _6458 = (int)*(((s1_ptr)_2)->base + 3);
    if (IS_ATOM_INT(_6458))
    _6459 = 1;
    else if (IS_ATOM_DBL(_6458))
    _6459 = IS_ATOM_INT(DoubleToInt(_6458));
    else
    _6459 = 0;
    _6458 = NOVALUE;
    if (_6459 != 0)
    goto L8; // [126] 134
    _6459 = NOVALUE;
    DeRef(_obj_p_11603);
    DeRef(_m__11607);
    return 0;
L8: 

    /** 	if m_[IN_USE] < 0		then return 0 end if*/
    _2 = (int)SEQ_PTR(_m__11607);
    _6461 = (int)*(((s1_ptr)_2)->base + 3);
    if (binary_op_a(GREATEREQ, _6461, 0)){
        _6461 = NOVALUE;
        goto L9; // [140] 149
    }
    _6461 = NOVALUE;
    DeRef(_obj_p_11603);
    DeRef(_m__11607);
    return 0;
L9: 

    /** 	if equal(m_[MAP_TYPE],SMALLMAP) then*/
    _2 = (int)SEQ_PTR(_m__11607);
    _6463 = (int)*(((s1_ptr)_2)->base + 4);
    if (_6463 == 115)
    _6464 = 1;
    else if (IS_ATOM_INT(_6463) && IS_ATOM_INT(115))
    _6464 = 0;
    else
    _6464 = (compare(_6463, 115) == 0);
    _6463 = NOVALUE;
    if (_6464 == 0)
    {
        _6464 = NOVALUE;
        goto LA; // [159] 284
    }
    else{
        _6464 = NOVALUE;
    }

    /** 		if atom(m_[KEY_LIST]) 		then return 0 end if*/
    _2 = (int)SEQ_PTR(_m__11607);
    _6465 = (int)*(((s1_ptr)_2)->base + 5);
    _6466 = IS_ATOM(_6465);
    _6465 = NOVALUE;
    if (_6466 == 0)
    {
        _6466 = NOVALUE;
        goto LB; // [171] 179
    }
    else{
        _6466 = NOVALUE;
    }
    DeRef(_obj_p_11603);
    DeRef(_m__11607);
    return 0;
LB: 

    /** 		if atom(m_[VALUE_LIST]) 		then return 0 end if*/
    _2 = (int)SEQ_PTR(_m__11607);
    _6467 = (int)*(((s1_ptr)_2)->base + 6);
    _6468 = IS_ATOM(_6467);
    _6467 = NOVALUE;
    if (_6468 == 0)
    {
        _6468 = NOVALUE;
        goto LC; // [188] 196
    }
    else{
        _6468 = NOVALUE;
    }
    DeRef(_obj_p_11603);
    DeRef(_m__11607);
    return 0;
LC: 

    /** 		if atom(m_[FREE_LIST]) 		then return 0 end if*/
    _2 = (int)SEQ_PTR(_m__11607);
    _6469 = (int)*(((s1_ptr)_2)->base + 7);
    _6470 = IS_ATOM(_6469);
    _6469 = NOVALUE;
    if (_6470 == 0)
    {
        _6470 = NOVALUE;
        goto LD; // [205] 213
    }
    else{
        _6470 = NOVALUE;
    }
    DeRef(_obj_p_11603);
    DeRef(_m__11607);
    return 0;
LD: 

    /** 		if length(m_[KEY_LIST]) = 0  then return 0 end if*/
    _2 = (int)SEQ_PTR(_m__11607);
    _6471 = (int)*(((s1_ptr)_2)->base + 5);
    if (IS_SEQUENCE(_6471)){
            _6472 = SEQ_PTR(_6471)->length;
    }
    else {
        _6472 = 1;
    }
    _6471 = NOVALUE;
    if (_6472 != 0)
    goto LE; // [222] 231
    DeRef(_obj_p_11603);
    DeRef(_m__11607);
    _6471 = NOVALUE;
    return 0;
LE: 

    /** 		if length(m_[KEY_LIST]) != length(m_[VALUE_LIST]) then return 0 end if*/
    _2 = (int)SEQ_PTR(_m__11607);
    _6474 = (int)*(((s1_ptr)_2)->base + 5);
    if (IS_SEQUENCE(_6474)){
            _6475 = SEQ_PTR(_6474)->length;
    }
    else {
        _6475 = 1;
    }
    _6474 = NOVALUE;
    _2 = (int)SEQ_PTR(_m__11607);
    _6476 = (int)*(((s1_ptr)_2)->base + 6);
    if (IS_SEQUENCE(_6476)){
            _6477 = SEQ_PTR(_6476)->length;
    }
    else {
        _6477 = 1;
    }
    _6476 = NOVALUE;
    if (_6475 == _6477)
    goto LF; // [247] 256
    DeRef(_obj_p_11603);
    DeRef(_m__11607);
    _6471 = NOVALUE;
    _6474 = NOVALUE;
    _6476 = NOVALUE;
    return 0;
LF: 

    /** 		if length(m_[KEY_LIST]) != length(m_[FREE_LIST]) then return 0 end if*/
    _2 = (int)SEQ_PTR(_m__11607);
    _6479 = (int)*(((s1_ptr)_2)->base + 5);
    if (IS_SEQUENCE(_6479)){
            _6480 = SEQ_PTR(_6479)->length;
    }
    else {
        _6480 = 1;
    }
    _6479 = NOVALUE;
    _2 = (int)SEQ_PTR(_m__11607);
    _6481 = (int)*(((s1_ptr)_2)->base + 7);
    if (IS_SEQUENCE(_6481)){
            _6482 = SEQ_PTR(_6481)->length;
    }
    else {
        _6482 = 1;
    }
    _6481 = NOVALUE;
    if (_6480 == _6482)
    goto L10; // [272] 366
    DeRef(_obj_p_11603);
    DeRef(_m__11607);
    _6471 = NOVALUE;
    _6474 = NOVALUE;
    _6476 = NOVALUE;
    _6479 = NOVALUE;
    _6481 = NOVALUE;
    return 0;
    goto L10; // [281] 366
LA: 

    /** 	elsif  equal(m_[MAP_TYPE],LARGEMAP) then*/
    _2 = (int)SEQ_PTR(_m__11607);
    _6484 = (int)*(((s1_ptr)_2)->base + 4);
    if (_6484 == 76)
    _6485 = 1;
    else if (IS_ATOM_INT(_6484) && IS_ATOM_INT(76))
    _6485 = 0;
    else
    _6485 = (compare(_6484, 76) == 0);
    _6484 = NOVALUE;
    if (_6485 == 0)
    {
        _6485 = NOVALUE;
        goto L11; // [294] 359
    }
    else{
        _6485 = NOVALUE;
    }

    /** 		if atom(m_[KEY_BUCKETS]) 		then return 0 end if*/
    _2 = (int)SEQ_PTR(_m__11607);
    _6486 = (int)*(((s1_ptr)_2)->base + 5);
    _6487 = IS_ATOM(_6486);
    _6486 = NOVALUE;
    if (_6487 == 0)
    {
        _6487 = NOVALUE;
        goto L12; // [306] 314
    }
    else{
        _6487 = NOVALUE;
    }
    DeRef(_obj_p_11603);
    DeRef(_m__11607);
    _6471 = NOVALUE;
    _6474 = NOVALUE;
    _6476 = NOVALUE;
    _6479 = NOVALUE;
    _6481 = NOVALUE;
    return 0;
L12: 

    /** 		if atom(m_[VALUE_BUCKETS]) 		then return 0 end if*/
    _2 = (int)SEQ_PTR(_m__11607);
    _6488 = (int)*(((s1_ptr)_2)->base + 6);
    _6489 = IS_ATOM(_6488);
    _6488 = NOVALUE;
    if (_6489 == 0)
    {
        _6489 = NOVALUE;
        goto L13; // [323] 331
    }
    else{
        _6489 = NOVALUE;
    }
    DeRef(_obj_p_11603);
    DeRef(_m__11607);
    _6471 = NOVALUE;
    _6474 = NOVALUE;
    _6476 = NOVALUE;
    _6479 = NOVALUE;
    _6481 = NOVALUE;
    return 0;
L13: 

    /** 		if length(m_[KEY_BUCKETS]) != length(m_[VALUE_BUCKETS])	then return 0 end if*/
    _2 = (int)SEQ_PTR(_m__11607);
    _6490 = (int)*(((s1_ptr)_2)->base + 5);
    if (IS_SEQUENCE(_6490)){
            _6491 = SEQ_PTR(_6490)->length;
    }
    else {
        _6491 = 1;
    }
    _6490 = NOVALUE;
    _2 = (int)SEQ_PTR(_m__11607);
    _6492 = (int)*(((s1_ptr)_2)->base + 6);
    if (IS_SEQUENCE(_6492)){
            _6493 = SEQ_PTR(_6492)->length;
    }
    else {
        _6493 = 1;
    }
    _6492 = NOVALUE;
    if (_6491 == _6493)
    goto L10; // [347] 366
    DeRef(_obj_p_11603);
    DeRef(_m__11607);
    _6471 = NOVALUE;
    _6474 = NOVALUE;
    _6476 = NOVALUE;
    _6479 = NOVALUE;
    _6481 = NOVALUE;
    _6490 = NOVALUE;
    _6492 = NOVALUE;
    return 0;
    goto L10; // [356] 366
L11: 

    /** 		return 0*/
    DeRef(_obj_p_11603);
    DeRef(_m__11607);
    _6471 = NOVALUE;
    _6474 = NOVALUE;
    _6476 = NOVALUE;
    _6479 = NOVALUE;
    _6481 = NOVALUE;
    _6490 = NOVALUE;
    _6492 = NOVALUE;
    return 0;
L10: 

    /** 	return 1*/
    DeRef(_obj_p_11603);
    DeRef(_m__11607);
    _6471 = NOVALUE;
    _6474 = NOVALUE;
    _6476 = NOVALUE;
    _6479 = NOVALUE;
    _6481 = NOVALUE;
    _6490 = NOVALUE;
    _6492 = NOVALUE;
    return 1;
    ;
}


void _28rehash(int _the_map_p_11703, int _requested_bucket_size_p_11704)
{
    int _size__11705 = NOVALUE;
    int _index_2__11706 = NOVALUE;
    int _old_key_buckets__11707 = NOVALUE;
    int _old_val_buckets__11708 = NOVALUE;
    int _new_key_buckets__11709 = NOVALUE;
    int _new_val_buckets__11710 = NOVALUE;
    int _key__11711 = NOVALUE;
    int _value__11712 = NOVALUE;
    int _pos_11713 = NOVALUE;
    int _new_keys_11714 = NOVALUE;
    int _in_use_11715 = NOVALUE;
    int _elem_count_11716 = NOVALUE;
    int _calc_hash_1__tmp_at227_11759 = NOVALUE;
    int _calc_hash_inlined_calc_hash_at_227_11758 = NOVALUE;
    int _ret__inlined_calc_hash_at_227_11757 = NOVALUE;
    int _6561 = NOVALUE;
    int _6560 = NOVALUE;
    int _6559 = NOVALUE;
    int _6558 = NOVALUE;
    int _6557 = NOVALUE;
    int _6556 = NOVALUE;
    int _6555 = NOVALUE;
    int _6554 = NOVALUE;
    int _6553 = NOVALUE;
    int _6551 = NOVALUE;
    int _6550 = NOVALUE;
    int _6549 = NOVALUE;
    int _6546 = NOVALUE;
    int _6545 = NOVALUE;
    int _6543 = NOVALUE;
    int _6542 = NOVALUE;
    int _6541 = NOVALUE;
    int _6540 = NOVALUE;
    int _6538 = NOVALUE;
    int _6536 = NOVALUE;
    int _6534 = NOVALUE;
    int _6531 = NOVALUE;
    int _6529 = NOVALUE;
    int _6528 = NOVALUE;
    int _6527 = NOVALUE;
    int _6526 = NOVALUE;
    int _6524 = NOVALUE;
    int _6522 = NOVALUE;
    int _6520 = NOVALUE;
    int _6519 = NOVALUE;
    int _6517 = NOVALUE;
    int _6515 = NOVALUE;
    int _6512 = NOVALUE;
    int _6510 = NOVALUE;
    int _6509 = NOVALUE;
    int _6508 = NOVALUE;
    int _6507 = NOVALUE;
    int _6506 = NOVALUE;
    int _6503 = NOVALUE;
    int _6502 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	if eumem:ram_space[the_map_p][MAP_TYPE] = SMALLMAP then*/
    _2 = (int)SEQ_PTR(_29ram_space_10710);
    _6502 = (int)*(((s1_ptr)_2)->base + _the_map_p_11703);
    _2 = (int)SEQ_PTR(_6502);
    _6503 = (int)*(((s1_ptr)_2)->base + 4);
    _6502 = NOVALUE;
    if (binary_op_a(NOTEQ, _6503, 115)){
        _6503 = NOVALUE;
        goto L1; // [17] 27
    }
    _6503 = NOVALUE;

    /** 		return -- small maps are not hashed.*/
    DeRef(_old_key_buckets__11707);
    DeRef(_old_val_buckets__11708);
    DeRef(_new_key_buckets__11709);
    DeRef(_new_val_buckets__11710);
    DeRef(_key__11711);
    DeRef(_value__11712);
    DeRef(_new_keys_11714);
    return;
L1: 

    /** 	if requested_bucket_size_p <= 0 then*/
    if (_requested_bucket_size_p_11704 > 0)
    goto L2; // [29] 62

    /** 		size_ = floor(length(eumem:ram_space[the_map_p][KEY_BUCKETS]) * 3.5) + 1*/
    _2 = (int)SEQ_PTR(_29ram_space_10710);
    _6506 = (int)*(((s1_ptr)_2)->base + _the_map_p_11703);
    _2 = (int)SEQ_PTR(_6506);
    _6507 = (int)*(((s1_ptr)_2)->base + 5);
    _6506 = NOVALUE;
    if (IS_SEQUENCE(_6507)){
            _6508 = SEQ_PTR(_6507)->length;
    }
    else {
        _6508 = 1;
    }
    _6507 = NOVALUE;
    _6509 = NewDouble((double)_6508 * DBL_PTR(_6017)->dbl);
    _6508 = NOVALUE;
    _6510 = unary_op(FLOOR, _6509);
    DeRefDS(_6509);
    _6509 = NOVALUE;
    if (IS_ATOM_INT(_6510)) {
        _size__11705 = _6510 + 1;
    }
    else
    { // coercing _size__11705 to an integer 1
        _size__11705 = 1+(long)(DBL_PTR(_6510)->dbl);
        if( !IS_ATOM_INT(_size__11705) ){
            _size__11705 = (object)DBL_PTR(_size__11705)->dbl;
        }
    }
    DeRef(_6510);
    _6510 = NOVALUE;
    goto L3; // [59] 68
L2: 

    /** 		size_ = requested_bucket_size_p*/
    _size__11705 = _requested_bucket_size_p_11704;
L3: 

    /** 	size_ = primes:next_prime(size_, -size_, 2)	-- Allow up to 2 seconds to calc next prime.*/
    if ((unsigned long)_size__11705 == 0xC0000000)
    _6512 = (int)NewDouble((double)-0xC0000000);
    else
    _6512 = - _size__11705;
    _size__11705 = _30next_prime(_size__11705, _6512, 2);
    _6512 = NOVALUE;
    if (!IS_ATOM_INT(_size__11705)) {
        _1 = (long)(DBL_PTR(_size__11705)->dbl);
        DeRefDS(_size__11705);
        _size__11705 = _1;
    }

    /** 	if size_ < 0 then*/
    if (_size__11705 >= 0)
    goto L4; // [85] 95

    /** 		return  -- don't do anything. New size would take too long.*/
    DeRef(_old_key_buckets__11707);
    DeRef(_old_val_buckets__11708);
    DeRef(_new_key_buckets__11709);
    DeRef(_new_val_buckets__11710);
    DeRef(_key__11711);
    DeRef(_value__11712);
    DeRef(_new_keys_11714);
    _6507 = NOVALUE;
    return;
L4: 

    /** 	old_key_buckets_ = eumem:ram_space[the_map_p][KEY_BUCKETS]*/
    _2 = (int)SEQ_PTR(_29ram_space_10710);
    _6515 = (int)*(((s1_ptr)_2)->base + _the_map_p_11703);
    DeRef(_old_key_buckets__11707);
    _2 = (int)SEQ_PTR(_6515);
    _old_key_buckets__11707 = (int)*(((s1_ptr)_2)->base + 5);
    Ref(_old_key_buckets__11707);
    _6515 = NOVALUE;

    /** 	old_val_buckets_ = eumem:ram_space[the_map_p][VALUE_BUCKETS]*/
    _2 = (int)SEQ_PTR(_29ram_space_10710);
    _6517 = (int)*(((s1_ptr)_2)->base + _the_map_p_11703);
    DeRef(_old_val_buckets__11708);
    _2 = (int)SEQ_PTR(_6517);
    _old_val_buckets__11708 = (int)*(((s1_ptr)_2)->base + 6);
    Ref(_old_val_buckets__11708);
    _6517 = NOVALUE;

    /** 	new_key_buckets_ = repeat(repeat(1, threshold_size + 1), size_)*/
    _6519 = 24;
    _6520 = Repeat(1, 24);
    _6519 = NOVALUE;
    DeRef(_new_key_buckets__11709);
    _new_key_buckets__11709 = Repeat(_6520, _size__11705);
    DeRefDS(_6520);
    _6520 = NOVALUE;

    /** 	new_val_buckets_ = repeat(repeat(0, threshold_size), size_)*/
    _6522 = Repeat(0, 23);
    DeRef(_new_val_buckets__11710);
    _new_val_buckets__11710 = Repeat(_6522, _size__11705);
    DeRefDS(_6522);
    _6522 = NOVALUE;

    /** 	elem_count = eumem:ram_space[the_map_p][ELEMENT_COUNT]*/
    _2 = (int)SEQ_PTR(_29ram_space_10710);
    _6524 = (int)*(((s1_ptr)_2)->base + _the_map_p_11703);
    _2 = (int)SEQ_PTR(_6524);
    _elem_count_11716 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_elem_count_11716)){
        _elem_count_11716 = (long)DBL_PTR(_elem_count_11716)->dbl;
    }
    _6524 = NOVALUE;

    /** 	in_use = 0*/
    _in_use_11715 = 0;

    /** 	eumem:ram_space[the_map_p] = 0*/
    _2 = (int)SEQ_PTR(_29ram_space_10710);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29ram_space_10710 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _the_map_p_11703);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 	for index = 1 to length(old_key_buckets_) do*/
    if (IS_SEQUENCE(_old_key_buckets__11707)){
            _6526 = SEQ_PTR(_old_key_buckets__11707)->length;
    }
    else {
        _6526 = 1;
    }
    {
        int _index_11746;
        _index_11746 = 1;
L5: 
        if (_index_11746 > _6526){
            goto L6; // [183] 373
        }

        /** 		for entry_idx = 1 to length(old_key_buckets_[index]) do*/
        _2 = (int)SEQ_PTR(_old_key_buckets__11707);
        _6527 = (int)*(((s1_ptr)_2)->base + _index_11746);
        if (IS_SEQUENCE(_6527)){
                _6528 = SEQ_PTR(_6527)->length;
        }
        else {
            _6528 = 1;
        }
        _6527 = NOVALUE;
        {
            int _entry_idx_11749;
            _entry_idx_11749 = 1;
L7: 
            if (_entry_idx_11749 > _6528){
                goto L8; // [199] 366
            }

            /** 			key_ = old_key_buckets_[index][entry_idx]*/
            _2 = (int)SEQ_PTR(_old_key_buckets__11707);
            _6529 = (int)*(((s1_ptr)_2)->base + _index_11746);
            DeRef(_key__11711);
            _2 = (int)SEQ_PTR(_6529);
            _key__11711 = (int)*(((s1_ptr)_2)->base + _entry_idx_11749);
            Ref(_key__11711);
            _6529 = NOVALUE;

            /** 			value_ = old_val_buckets_[index][entry_idx]*/
            _2 = (int)SEQ_PTR(_old_val_buckets__11708);
            _6531 = (int)*(((s1_ptr)_2)->base + _index_11746);
            DeRef(_value__11712);
            _2 = (int)SEQ_PTR(_6531);
            _value__11712 = (int)*(((s1_ptr)_2)->base + _entry_idx_11749);
            Ref(_value__11712);
            _6531 = NOVALUE;

            /** 			index_2_ = calc_hash(key_, size_)*/

            /**     ret_ = hash(key_p, stdhash:HSIEH30)*/
            DeRef(_ret__inlined_calc_hash_at_227_11757);
            _ret__inlined_calc_hash_at_227_11757 = calc_hash(_key__11711, -6);
            if (!IS_ATOM_INT(_ret__inlined_calc_hash_at_227_11757)) {
                _1 = (long)(DBL_PTR(_ret__inlined_calc_hash_at_227_11757)->dbl);
                DeRefDS(_ret__inlined_calc_hash_at_227_11757);
                _ret__inlined_calc_hash_at_227_11757 = _1;
            }

            /** 	return remainder(ret_, max_hash_p) + 1 -- 1-based*/
            _calc_hash_1__tmp_at227_11759 = (_ret__inlined_calc_hash_at_227_11757 % _size__11705);
            _index_2__11706 = _calc_hash_1__tmp_at227_11759 + 1;
            DeRef(_ret__inlined_calc_hash_at_227_11757);
            _ret__inlined_calc_hash_at_227_11757 = NOVALUE;
            if (!IS_ATOM_INT(_index_2__11706)) {
                _1 = (long)(DBL_PTR(_index_2__11706)->dbl);
                DeRefDS(_index_2__11706);
                _index_2__11706 = _1;
            }

            /** 			new_keys = new_key_buckets_[index_2_]*/
            DeRef(_new_keys_11714);
            _2 = (int)SEQ_PTR(_new_key_buckets__11709);
            _new_keys_11714 = (int)*(((s1_ptr)_2)->base + _index_2__11706);
            RefDS(_new_keys_11714);

            /** 			pos = new_keys[$]*/
            if (IS_SEQUENCE(_new_keys_11714)){
                    _6534 = SEQ_PTR(_new_keys_11714)->length;
            }
            else {
                _6534 = 1;
            }
            _2 = (int)SEQ_PTR(_new_keys_11714);
            _pos_11713 = (int)*(((s1_ptr)_2)->base + _6534);
            if (!IS_ATOM_INT(_pos_11713))
            _pos_11713 = (long)DBL_PTR(_pos_11713)->dbl;

            /** 			if length(new_keys) = pos then*/
            if (IS_SEQUENCE(_new_keys_11714)){
                    _6536 = SEQ_PTR(_new_keys_11714)->length;
            }
            else {
                _6536 = 1;
            }
            if (_6536 != _pos_11713)
            goto L9; // [273] 310

            /** 				new_keys &= repeat(pos, threshold_size)*/
            _6538 = Repeat(_pos_11713, 23);
            Concat((object_ptr)&_new_keys_11714, _new_keys_11714, _6538);
            DeRefDS(_6538);
            _6538 = NOVALUE;

            /** 				new_val_buckets_[index_2_] &= repeat(0, threshold_size)*/
            _6540 = Repeat(0, 23);
            _2 = (int)SEQ_PTR(_new_val_buckets__11710);
            _6541 = (int)*(((s1_ptr)_2)->base + _index_2__11706);
            if (IS_SEQUENCE(_6541) && IS_ATOM(_6540)) {
            }
            else if (IS_ATOM(_6541) && IS_SEQUENCE(_6540)) {
                Ref(_6541);
                Prepend(&_6542, _6540, _6541);
            }
            else {
                Concat((object_ptr)&_6542, _6541, _6540);
                _6541 = NOVALUE;
            }
            _6541 = NOVALUE;
            DeRefDS(_6540);
            _6540 = NOVALUE;
            _2 = (int)SEQ_PTR(_new_val_buckets__11710);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _new_val_buckets__11710 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _index_2__11706);
            _1 = *(int *)_2;
            *(int *)_2 = _6542;
            if( _1 != _6542 ){
                DeRef(_1);
            }
            _6542 = NOVALUE;
L9: 

            /** 			new_keys[pos] = key_*/
            Ref(_key__11711);
            _2 = (int)SEQ_PTR(_new_keys_11714);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _new_keys_11714 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _pos_11713);
            _1 = *(int *)_2;
            *(int *)_2 = _key__11711;
            DeRef(_1);

            /** 			new_val_buckets_[index_2_][pos] = value_*/
            _2 = (int)SEQ_PTR(_new_val_buckets__11710);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _new_val_buckets__11710 = MAKE_SEQ(_2);
            }
            _3 = (int)(_index_2__11706 + ((s1_ptr)_2)->base);
            Ref(_value__11712);
            _2 = (int)SEQ_PTR(*(int *)_3);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                *(int *)_3 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _pos_11713);
            _1 = *(int *)_2;
            *(int *)_2 = _value__11712;
            DeRef(_1);
            _6543 = NOVALUE;

            /** 			new_keys[$] = pos + 1*/
            if (IS_SEQUENCE(_new_keys_11714)){
                    _6545 = SEQ_PTR(_new_keys_11714)->length;
            }
            else {
                _6545 = 1;
            }
            _6546 = _pos_11713 + 1;
            if (_6546 > MAXINT){
                _6546 = NewDouble((double)_6546);
            }
            _2 = (int)SEQ_PTR(_new_keys_11714);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _new_keys_11714 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _6545);
            _1 = *(int *)_2;
            *(int *)_2 = _6546;
            if( _1 != _6546 ){
                DeRef(_1);
            }
            _6546 = NOVALUE;

            /** 			new_key_buckets_[index_2_] = new_keys*/
            RefDS(_new_keys_11714);
            _2 = (int)SEQ_PTR(_new_key_buckets__11709);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _new_key_buckets__11709 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _index_2__11706);
            _1 = *(int *)_2;
            *(int *)_2 = _new_keys_11714;
            DeRefDS(_1);

            /** 			if pos = 1 then*/
            if (_pos_11713 != 1)
            goto LA; // [348] 359

            /** 				in_use += 1*/
            _in_use_11715 = _in_use_11715 + 1;
LA: 

            /** 		end for*/
            _entry_idx_11749 = _entry_idx_11749 + 1;
            goto L7; // [361] 206
L8: 
            ;
        }

        /** 	end for*/
        _index_11746 = _index_11746 + 1;
        goto L5; // [368] 190
L6: 
        ;
    }

    /** 	for index = 1 to length(new_key_buckets_) do*/
    if (IS_SEQUENCE(_new_key_buckets__11709)){
            _6549 = SEQ_PTR(_new_key_buckets__11709)->length;
    }
    else {
        _6549 = 1;
    }
    {
        int _index_11779;
        _index_11779 = 1;
LB: 
        if (_index_11779 > _6549){
            goto LC; // [378] 451
        }

        /** 		pos = new_key_buckets_[index][$]*/
        _2 = (int)SEQ_PTR(_new_key_buckets__11709);
        _6550 = (int)*(((s1_ptr)_2)->base + _index_11779);
        if (IS_SEQUENCE(_6550)){
                _6551 = SEQ_PTR(_6550)->length;
        }
        else {
            _6551 = 1;
        }
        _2 = (int)SEQ_PTR(_6550);
        _pos_11713 = (int)*(((s1_ptr)_2)->base + _6551);
        if (!IS_ATOM_INT(_pos_11713)){
            _pos_11713 = (long)DBL_PTR(_pos_11713)->dbl;
        }
        _6550 = NOVALUE;

        /** 		new_key_buckets_[index] = remove(new_key_buckets_[index], pos, */
        _2 = (int)SEQ_PTR(_new_key_buckets__11709);
        _6553 = (int)*(((s1_ptr)_2)->base + _index_11779);
        _2 = (int)SEQ_PTR(_new_key_buckets__11709);
        _6554 = (int)*(((s1_ptr)_2)->base + _index_11779);
        if (IS_SEQUENCE(_6554)){
                _6555 = SEQ_PTR(_6554)->length;
        }
        else {
            _6555 = 1;
        }
        _6554 = NOVALUE;
        {
            s1_ptr assign_space = SEQ_PTR(_6553);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_pos_11713)) ? _pos_11713 : (long)(DBL_PTR(_pos_11713)->dbl);
            int stop = (IS_ATOM_INT(_6555)) ? _6555 : (long)(DBL_PTR(_6555)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<0) {
                RefDS(_6553);
                DeRef(_6556);
                _6556 = _6553;
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_6553), start, &_6556 );
                }
                else Tail(SEQ_PTR(_6553), stop+1, &_6556);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_6553), start, &_6556);
            }
            else {
                assign_slice_seq = &assign_space;
                _1 = Remove_elements(start, stop, 0);
                DeRef(_6556);
                _6556 = _1;
            }
        }
        _6553 = NOVALUE;
        _6555 = NOVALUE;
        _2 = (int)SEQ_PTR(_new_key_buckets__11709);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _new_key_buckets__11709 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _index_11779);
        _1 = *(int *)_2;
        *(int *)_2 = _6556;
        if( _1 != _6556 ){
            DeRefDS(_1);
        }
        _6556 = NOVALUE;

        /** 		new_val_buckets_[index] = remove(new_val_buckets_[index], pos, */
        _2 = (int)SEQ_PTR(_new_val_buckets__11710);
        _6557 = (int)*(((s1_ptr)_2)->base + _index_11779);
        _2 = (int)SEQ_PTR(_new_val_buckets__11710);
        _6558 = (int)*(((s1_ptr)_2)->base + _index_11779);
        if (IS_SEQUENCE(_6558)){
                _6559 = SEQ_PTR(_6558)->length;
        }
        else {
            _6559 = 1;
        }
        _6558 = NOVALUE;
        {
            s1_ptr assign_space = SEQ_PTR(_6557);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_pos_11713)) ? _pos_11713 : (long)(DBL_PTR(_pos_11713)->dbl);
            int stop = (IS_ATOM_INT(_6559)) ? _6559 : (long)(DBL_PTR(_6559)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<0) {
                RefDS(_6557);
                DeRef(_6560);
                _6560 = _6557;
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_6557), start, &_6560 );
                }
                else Tail(SEQ_PTR(_6557), stop+1, &_6560);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_6557), start, &_6560);
            }
            else {
                assign_slice_seq = &assign_space;
                _1 = Remove_elements(start, stop, 0);
                DeRef(_6560);
                _6560 = _1;
            }
        }
        _6557 = NOVALUE;
        _6559 = NOVALUE;
        _2 = (int)SEQ_PTR(_new_val_buckets__11710);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _new_val_buckets__11710 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _index_11779);
        _1 = *(int *)_2;
        *(int *)_2 = _6560;
        if( _1 != _6560 ){
            DeRef(_1);
        }
        _6560 = NOVALUE;

        /** 	end for*/
        _index_11779 = _index_11779 + 1;
        goto LB; // [446] 385
LC: 
        ;
    }

    /** 	eumem:ram_space[the_map_p] = { */
    _1 = NewS1(6);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_28type_is_map_11582);
    *((int *)(_2+4)) = _28type_is_map_11582;
    *((int *)(_2+8)) = _elem_count_11716;
    *((int *)(_2+12)) = _in_use_11715;
    *((int *)(_2+16)) = 76;
    RefDS(_new_key_buckets__11709);
    *((int *)(_2+20)) = _new_key_buckets__11709;
    RefDS(_new_val_buckets__11710);
    *((int *)(_2+24)) = _new_val_buckets__11710;
    _6561 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_29ram_space_10710);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29ram_space_10710 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _the_map_p_11703);
    _1 = *(int *)_2;
    *(int *)_2 = _6561;
    if( _1 != _6561 ){
        DeRef(_1);
    }
    _6561 = NOVALUE;

    /** end procedure*/
    DeRef(_old_key_buckets__11707);
    DeRef(_old_val_buckets__11708);
    DeRefDS(_new_key_buckets__11709);
    DeRefDS(_new_val_buckets__11710);
    DeRef(_key__11711);
    DeRef(_value__11712);
    DeRef(_new_keys_11714);
    _6507 = NOVALUE;
    _6527 = NOVALUE;
    _6554 = NOVALUE;
    _6558 = NOVALUE;
    return;
    ;
}


int _28new(int _initial_size_p_11795)
{
    int _buckets__11797 = NOVALUE;
    int _new_map__11798 = NOVALUE;
    int _temp_map__11799 = NOVALUE;
    int _6574 = NOVALUE;
    int _6573 = NOVALUE;
    int _6572 = NOVALUE;
    int _6570 = NOVALUE;
    int _6569 = NOVALUE;
    int _6566 = NOVALUE;
    int _6565 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if initial_size_p < 3 then*/
    if (_initial_size_p_11795 >= 3)
    goto L1; // [5] 15

    /** 		initial_size_p = 3*/
    _initial_size_p_11795 = 3;
L1: 

    /** 	if initial_size_p > threshold_size then*/
    if (_initial_size_p_11795 <= 23)
    goto L2; // [19] 75

    /** 		buckets_ = floor((initial_size_p + threshold_size - 1) / threshold_size)*/
    _6565 = _initial_size_p_11795 + 23;
    if ((long)((unsigned long)_6565 + (unsigned long)HIGH_BITS) >= 0) 
    _6565 = NewDouble((double)_6565);
    if (IS_ATOM_INT(_6565)) {
        _6566 = _6565 - 1;
        if ((long)((unsigned long)_6566 +(unsigned long) HIGH_BITS) >= 0){
            _6566 = NewDouble((double)_6566);
        }
    }
    else {
        _6566 = NewDouble(DBL_PTR(_6565)->dbl - (double)1);
    }
    DeRef(_6565);
    _6565 = NOVALUE;
    if (IS_ATOM_INT(_6566)) {
        if (23 > 0 && _6566 >= 0) {
            _buckets__11797 = _6566 / 23;
        }
        else {
            temp_dbl = floor((double)_6566 / (double)23);
            _buckets__11797 = (long)temp_dbl;
        }
    }
    else {
        _2 = binary_op(DIVIDE, _6566, 23);
        _buckets__11797 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    DeRef(_6566);
    _6566 = NOVALUE;
    if (!IS_ATOM_INT(_buckets__11797)) {
        _1 = (long)(DBL_PTR(_buckets__11797)->dbl);
        DeRefDS(_buckets__11797);
        _buckets__11797 = _1;
    }

    /** 		buckets_ = primes:next_prime(buckets_)*/
    _buckets__11797 = _30next_prime(_buckets__11797, -1, 1);
    if (!IS_ATOM_INT(_buckets__11797)) {
        _1 = (long)(DBL_PTR(_buckets__11797)->dbl);
        DeRefDS(_buckets__11797);
        _buckets__11797 = _1;
    }

    /** 		new_map_ = { type_is_map, 0, 0, LARGEMAP, repeat({}, buckets_), repeat({}, buckets_) }*/
    _6569 = Repeat(_5, _buckets__11797);
    _6570 = Repeat(_5, _buckets__11797);
    _0 = _new_map__11798;
    _1 = NewS1(6);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_28type_is_map_11582);
    *((int *)(_2+4)) = _28type_is_map_11582;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = 0;
    *((int *)(_2+16)) = 76;
    *((int *)(_2+20)) = _6569;
    *((int *)(_2+24)) = _6570;
    _new_map__11798 = MAKE_SEQ(_1);
    DeRef(_0);
    _6570 = NOVALUE;
    _6569 = NOVALUE;
    goto L3; // [72] 100
L2: 

    /** 		new_map_ = {*/
    _6572 = Repeat(_28init_small_map_key_11598, _initial_size_p_11795);
    _6573 = Repeat(0, _initial_size_p_11795);
    _6574 = Repeat(0, _initial_size_p_11795);
    _0 = _new_map__11798;
    _1 = NewS1(7);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_28type_is_map_11582);
    *((int *)(_2+4)) = _28type_is_map_11582;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = 0;
    *((int *)(_2+16)) = 115;
    *((int *)(_2+20)) = _6572;
    *((int *)(_2+24)) = _6573;
    *((int *)(_2+28)) = _6574;
    _new_map__11798 = MAKE_SEQ(_1);
    DeRef(_0);
    _6574 = NOVALUE;
    _6573 = NOVALUE;
    _6572 = NOVALUE;
L3: 

    /** 	temp_map_ = eumem:malloc()*/
    _0 = _temp_map__11799;
    _temp_map__11799 = _29malloc(1, 1);
    DeRef(_0);

    /** 	eumem:ram_space[temp_map_] = new_map_*/
    RefDS(_new_map__11798);
    _2 = (int)SEQ_PTR(_29ram_space_10710);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29ram_space_10710 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_temp_map__11799))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_temp_map__11799)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _temp_map__11799);
    _1 = *(int *)_2;
    *(int *)_2 = _new_map__11798;
    DeRef(_1);

    /** 	return temp_map_*/
    DeRefDS(_new_map__11798);
    return _temp_map__11799;
    ;
}


int _28new_extra(int _the_map_p_11819, int _initial_size_p_11820)
{
    int _6578 = NOVALUE;
    int _6577 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if map(the_map_p) then*/
    Ref(_the_map_p_11819);
    _6577 = _28map(_the_map_p_11819);
    if (_6577 == 0) {
        DeRef(_6577);
        _6577 = NOVALUE;
        goto L1; // [9] 21
    }
    else {
        if (!IS_ATOM_INT(_6577) && DBL_PTR(_6577)->dbl == 0.0){
            DeRef(_6577);
            _6577 = NOVALUE;
            goto L1; // [9] 21
        }
        DeRef(_6577);
        _6577 = NOVALUE;
    }
    DeRef(_6577);
    _6577 = NOVALUE;

    /** 		return the_map_p*/
    return _the_map_p_11819;
    goto L2; // [18] 32
L1: 

    /** 		return new(initial_size_p)*/
    _6578 = _28new(_initial_size_p_11820);
    DeRef(_the_map_p_11819);
    return _6578;
L2: 
    ;
}


int _28has(int _the_map_p_11859, int _the_key_p_11860)
{
    int _index__11861 = NOVALUE;
    int _pos__11862 = NOVALUE;
    int _from__11863 = NOVALUE;
    int _calc_hash_1__tmp_at36_11875 = NOVALUE;
    int _calc_hash_inlined_calc_hash_at_36_11874 = NOVALUE;
    int _ret__inlined_calc_hash_at_36_11873 = NOVALUE;
    int _max_hash_p_inlined_calc_hash_at_33_11872 = NOVALUE;
    int _6616 = NOVALUE;
    int _6614 = NOVALUE;
    int _6613 = NOVALUE;
    int _6610 = NOVALUE;
    int _6609 = NOVALUE;
    int _6608 = NOVALUE;
    int _6606 = NOVALUE;
    int _6605 = NOVALUE;
    int _6603 = NOVALUE;
    int _6601 = NOVALUE;
    int _6600 = NOVALUE;
    int _6599 = NOVALUE;
    int _6598 = NOVALUE;
    int _6597 = NOVALUE;
    int _6596 = NOVALUE;
    int _6594 = NOVALUE;
    int _6593 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_the_map_p_11859)) {
        _1 = (long)(DBL_PTR(_the_map_p_11859)->dbl);
        DeRefDS(_the_map_p_11859);
        _the_map_p_11859 = _1;
    }

    /** 	if eumem:ram_space[the_map_p][MAP_TYPE] = LARGEMAP then*/
    _2 = (int)SEQ_PTR(_29ram_space_10710);
    _6593 = (int)*(((s1_ptr)_2)->base + _the_map_p_11859);
    _2 = (int)SEQ_PTR(_6593);
    _6594 = (int)*(((s1_ptr)_2)->base + 4);
    _6593 = NOVALUE;
    if (binary_op_a(NOTEQ, _6594, 76)){
        _6594 = NOVALUE;
        goto L1; // [15] 86
    }
    _6594 = NOVALUE;

    /** 		index_ = calc_hash(the_key_p, length(eumem:ram_space[the_map_p][KEY_BUCKETS]))*/
    _2 = (int)SEQ_PTR(_29ram_space_10710);
    _6596 = (int)*(((s1_ptr)_2)->base + _the_map_p_11859);
    _2 = (int)SEQ_PTR(_6596);
    _6597 = (int)*(((s1_ptr)_2)->base + 5);
    _6596 = NOVALUE;
    if (IS_SEQUENCE(_6597)){
            _6598 = SEQ_PTR(_6597)->length;
    }
    else {
        _6598 = 1;
    }
    _6597 = NOVALUE;
    _max_hash_p_inlined_calc_hash_at_33_11872 = _6598;
    _6598 = NOVALUE;

    /**     ret_ = hash(key_p, stdhash:HSIEH30)*/
    DeRef(_ret__inlined_calc_hash_at_36_11873);
    _ret__inlined_calc_hash_at_36_11873 = calc_hash(_the_key_p_11860, -6);
    if (!IS_ATOM_INT(_ret__inlined_calc_hash_at_36_11873)) {
        _1 = (long)(DBL_PTR(_ret__inlined_calc_hash_at_36_11873)->dbl);
        DeRefDS(_ret__inlined_calc_hash_at_36_11873);
        _ret__inlined_calc_hash_at_36_11873 = _1;
    }

    /** 	return remainder(ret_, max_hash_p) + 1 -- 1-based*/
    _calc_hash_1__tmp_at36_11875 = (_ret__inlined_calc_hash_at_36_11873 % _max_hash_p_inlined_calc_hash_at_33_11872);
    _index__11861 = _calc_hash_1__tmp_at36_11875 + 1;
    DeRef(_ret__inlined_calc_hash_at_36_11873);
    _ret__inlined_calc_hash_at_36_11873 = NOVALUE;
    if (!IS_ATOM_INT(_index__11861)) {
        _1 = (long)(DBL_PTR(_index__11861)->dbl);
        DeRefDS(_index__11861);
        _index__11861 = _1;
    }

    /** 		pos_ = find(the_key_p, eumem:ram_space[the_map_p][KEY_BUCKETS][index_])*/
    _2 = (int)SEQ_PTR(_29ram_space_10710);
    _6599 = (int)*(((s1_ptr)_2)->base + _the_map_p_11859);
    _2 = (int)SEQ_PTR(_6599);
    _6600 = (int)*(((s1_ptr)_2)->base + 5);
    _6599 = NOVALUE;
    _2 = (int)SEQ_PTR(_6600);
    _6601 = (int)*(((s1_ptr)_2)->base + _index__11861);
    _6600 = NOVALUE;
    _pos__11862 = find_from(_the_key_p_11860, _6601, 1);
    _6601 = NOVALUE;
    goto L2; // [83] 201
L1: 

    /** 		if equal(the_key_p, init_small_map_key) then*/
    if (_the_key_p_11860 == _28init_small_map_key_11598)
    _6603 = 1;
    else if (IS_ATOM_INT(_the_key_p_11860) && IS_ATOM_INT(_28init_small_map_key_11598))
    _6603 = 0;
    else
    _6603 = (compare(_the_key_p_11860, _28init_small_map_key_11598) == 0);
    if (_6603 == 0)
    {
        _6603 = NOVALUE;
        goto L3; // [92] 182
    }
    else{
        _6603 = NOVALUE;
    }

    /** 			from_ = 1*/
    _from__11863 = 1;

    /** 			while from_ > 0 do*/
L4: 
    if (_from__11863 <= 0)
    goto L5; // [105] 200

    /** 				pos_ = find(the_key_p, eumem:ram_space[the_map_p][KEY_LIST], from_)*/
    _2 = (int)SEQ_PTR(_29ram_space_10710);
    _6605 = (int)*(((s1_ptr)_2)->base + _the_map_p_11859);
    _2 = (int)SEQ_PTR(_6605);
    _6606 = (int)*(((s1_ptr)_2)->base + 5);
    _6605 = NOVALUE;
    _pos__11862 = find_from(_the_key_p_11860, _6606, _from__11863);
    _6606 = NOVALUE;

    /** 				if pos_ then*/
    if (_pos__11862 == 0)
    {
        goto L6; // [128] 161
    }
    else{
    }

    /** 					if eumem:ram_space[the_map_p][FREE_LIST][pos_] = 1 then*/
    _2 = (int)SEQ_PTR(_29ram_space_10710);
    _6608 = (int)*(((s1_ptr)_2)->base + _the_map_p_11859);
    _2 = (int)SEQ_PTR(_6608);
    _6609 = (int)*(((s1_ptr)_2)->base + 7);
    _6608 = NOVALUE;
    _2 = (int)SEQ_PTR(_6609);
    _6610 = (int)*(((s1_ptr)_2)->base + _pos__11862);
    _6609 = NOVALUE;
    if (binary_op_a(NOTEQ, _6610, 1)){
        _6610 = NOVALUE;
        goto L7; // [147] 168
    }
    _6610 = NOVALUE;

    /** 						return 1*/
    DeRef(_the_key_p_11860);
    _6597 = NOVALUE;
    return 1;
    goto L7; // [158] 168
L6: 

    /** 					return 0*/
    DeRef(_the_key_p_11860);
    _6597 = NOVALUE;
    return 0;
L7: 

    /** 				from_ = pos_ + 1*/
    _from__11863 = _pos__11862 + 1;

    /** 			end while*/
    goto L4; // [176] 105
    goto L5; // [179] 200
L3: 

    /** 			pos_ = find(the_key_p, eumem:ram_space[the_map_p][KEY_LIST])*/
    _2 = (int)SEQ_PTR(_29ram_space_10710);
    _6613 = (int)*(((s1_ptr)_2)->base + _the_map_p_11859);
    _2 = (int)SEQ_PTR(_6613);
    _6614 = (int)*(((s1_ptr)_2)->base + 5);
    _6613 = NOVALUE;
    _pos__11862 = find_from(_the_key_p_11860, _6614, 1);
    _6614 = NOVALUE;
L5: 
L2: 

    /** 	return (pos_  != 0)	*/
    _6616 = (_pos__11862 != 0);
    DeRef(_the_key_p_11860);
    _6597 = NOVALUE;
    return _6616;
    ;
}


int _28get(int _the_map_p_11903, int _the_key_p_11904, int _default_value_p_11905)
{
    int _bucket__11906 = NOVALUE;
    int _pos__11907 = NOVALUE;
    int _from__11908 = NOVALUE;
    int _themap_11909 = NOVALUE;
    int _thekeys_11914 = NOVALUE;
    int _calc_hash_1__tmp_at40_11921 = NOVALUE;
    int _calc_hash_inlined_calc_hash_at_40_11920 = NOVALUE;
    int _ret__inlined_calc_hash_at_40_11919 = NOVALUE;
    int _max_hash_p_inlined_calc_hash_at_37_11918 = NOVALUE;
    int _6641 = NOVALUE;
    int _6640 = NOVALUE;
    int _6638 = NOVALUE;
    int _6636 = NOVALUE;
    int _6635 = NOVALUE;
    int _6633 = NOVALUE;
    int _6632 = NOVALUE;
    int _6630 = NOVALUE;
    int _6628 = NOVALUE;
    int _6627 = NOVALUE;
    int _6626 = NOVALUE;
    int _6625 = NOVALUE;
    int _6622 = NOVALUE;
    int _6621 = NOVALUE;
    int _6618 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_the_map_p_11903)) {
        _1 = (long)(DBL_PTR(_the_map_p_11903)->dbl);
        DeRefDS(_the_map_p_11903);
        _the_map_p_11903 = _1;
    }

    /** 	themap = eumem:ram_space[the_map_p]*/
    DeRef(_themap_11909);
    _2 = (int)SEQ_PTR(_29ram_space_10710);
    _themap_11909 = (int)*(((s1_ptr)_2)->base + _the_map_p_11903);
    Ref(_themap_11909);

    /** 	if themap[MAP_TYPE] = LARGEMAP then*/
    _2 = (int)SEQ_PTR(_themap_11909);
    _6618 = (int)*(((s1_ptr)_2)->base + 4);
    if (binary_op_a(NOTEQ, _6618, 76)){
        _6618 = NOVALUE;
        goto L1; // [19] 113
    }
    _6618 = NOVALUE;

    /** 		sequence thekeys*/

    /** 		thekeys = themap[KEY_BUCKETS]*/
    DeRef(_thekeys_11914);
    _2 = (int)SEQ_PTR(_themap_11909);
    _thekeys_11914 = (int)*(((s1_ptr)_2)->base + 5);
    Ref(_thekeys_11914);

    /** 		bucket_ = calc_hash(the_key_p, length(thekeys))*/
    if (IS_SEQUENCE(_thekeys_11914)){
            _6621 = SEQ_PTR(_thekeys_11914)->length;
    }
    else {
        _6621 = 1;
    }
    _max_hash_p_inlined_calc_hash_at_37_11918 = _6621;
    _6621 = NOVALUE;

    /**     ret_ = hash(key_p, stdhash:HSIEH30)*/
    DeRef(_ret__inlined_calc_hash_at_40_11919);
    _ret__inlined_calc_hash_at_40_11919 = calc_hash(_the_key_p_11904, -6);
    if (!IS_ATOM_INT(_ret__inlined_calc_hash_at_40_11919)) {
        _1 = (long)(DBL_PTR(_ret__inlined_calc_hash_at_40_11919)->dbl);
        DeRefDS(_ret__inlined_calc_hash_at_40_11919);
        _ret__inlined_calc_hash_at_40_11919 = _1;
    }

    /** 	return remainder(ret_, max_hash_p) + 1 -- 1-based*/
    _calc_hash_1__tmp_at40_11921 = (_ret__inlined_calc_hash_at_40_11919 % _max_hash_p_inlined_calc_hash_at_37_11918);
    _bucket__11906 = _calc_hash_1__tmp_at40_11921 + 1;
    DeRef(_ret__inlined_calc_hash_at_40_11919);
    _ret__inlined_calc_hash_at_40_11919 = NOVALUE;
    if (!IS_ATOM_INT(_bucket__11906)) {
        _1 = (long)(DBL_PTR(_bucket__11906)->dbl);
        DeRefDS(_bucket__11906);
        _bucket__11906 = _1;
    }

    /** 		pos_ = find(the_key_p, thekeys[bucket_])*/
    _2 = (int)SEQ_PTR(_thekeys_11914);
    _6622 = (int)*(((s1_ptr)_2)->base + _bucket__11906);
    _pos__11907 = find_from(_the_key_p_11904, _6622, 1);
    _6622 = NOVALUE;

    /** 		if pos_ > 0 then*/
    if (_pos__11907 <= 0)
    goto L2; // [79] 102

    /** 			return themap[VALUE_BUCKETS][bucket_][pos_]*/
    _2 = (int)SEQ_PTR(_themap_11909);
    _6625 = (int)*(((s1_ptr)_2)->base + 6);
    _2 = (int)SEQ_PTR(_6625);
    _6626 = (int)*(((s1_ptr)_2)->base + _bucket__11906);
    _6625 = NOVALUE;
    _2 = (int)SEQ_PTR(_6626);
    _6627 = (int)*(((s1_ptr)_2)->base + _pos__11907);
    _6626 = NOVALUE;
    Ref(_6627);
    DeRefDS(_thekeys_11914);
    DeRef(_the_key_p_11904);
    DeRef(_default_value_p_11905);
    DeRefDS(_themap_11909);
    return _6627;
L2: 

    /** 		return default_value_p*/
    DeRef(_thekeys_11914);
    DeRef(_the_key_p_11904);
    DeRef(_themap_11909);
    _6627 = NOVALUE;
    return _default_value_p_11905;
    goto L3; // [110] 238
L1: 

    /** 		if equal(the_key_p, init_small_map_key) then*/
    if (_the_key_p_11904 == _28init_small_map_key_11598)
    _6628 = 1;
    else if (IS_ATOM_INT(_the_key_p_11904) && IS_ATOM_INT(_28init_small_map_key_11598))
    _6628 = 0;
    else
    _6628 = (compare(_the_key_p_11904, _28init_small_map_key_11598) == 0);
    if (_6628 == 0)
    {
        _6628 = NOVALUE;
        goto L4; // [119] 205
    }
    else{
        _6628 = NOVALUE;
    }

    /** 			from_ = 1*/
    _from__11908 = 1;

    /** 			while from_ > 0 do*/
L5: 
    if (_from__11908 <= 0)
    goto L6; // [132] 237

    /** 				pos_ = find(the_key_p, themap[KEY_LIST], from_)*/
    _2 = (int)SEQ_PTR(_themap_11909);
    _6630 = (int)*(((s1_ptr)_2)->base + 5);
    _pos__11907 = find_from(_the_key_p_11904, _6630, _from__11908);
    _6630 = NOVALUE;

    /** 				if pos_ then*/
    if (_pos__11907 == 0)
    {
        goto L7; // [149] 184
    }
    else{
    }

    /** 					if themap[FREE_LIST][pos_] = 1 then*/
    _2 = (int)SEQ_PTR(_themap_11909);
    _6632 = (int)*(((s1_ptr)_2)->base + 7);
    _2 = (int)SEQ_PTR(_6632);
    _6633 = (int)*(((s1_ptr)_2)->base + _pos__11907);
    _6632 = NOVALUE;
    if (binary_op_a(NOTEQ, _6633, 1)){
        _6633 = NOVALUE;
        goto L8; // [162] 191
    }
    _6633 = NOVALUE;

    /** 						return themap[VALUE_LIST][pos_]*/
    _2 = (int)SEQ_PTR(_themap_11909);
    _6635 = (int)*(((s1_ptr)_2)->base + 6);
    _2 = (int)SEQ_PTR(_6635);
    _6636 = (int)*(((s1_ptr)_2)->base + _pos__11907);
    _6635 = NOVALUE;
    Ref(_6636);
    DeRef(_the_key_p_11904);
    DeRef(_default_value_p_11905);
    DeRefDS(_themap_11909);
    _6627 = NOVALUE;
    return _6636;
    goto L8; // [181] 191
L7: 

    /** 					return default_value_p*/
    DeRef(_the_key_p_11904);
    DeRef(_themap_11909);
    _6627 = NOVALUE;
    _6636 = NOVALUE;
    return _default_value_p_11905;
L8: 

    /** 				from_ = pos_ + 1*/
    _from__11908 = _pos__11907 + 1;

    /** 			end while*/
    goto L5; // [199] 132
    goto L6; // [202] 237
L4: 

    /** 			pos_ = find(the_key_p, themap[KEY_LIST])*/
    _2 = (int)SEQ_PTR(_themap_11909);
    _6638 = (int)*(((s1_ptr)_2)->base + 5);
    _pos__11907 = find_from(_the_key_p_11904, _6638, 1);
    _6638 = NOVALUE;

    /** 			if pos_  then*/
    if (_pos__11907 == 0)
    {
        goto L9; // [218] 236
    }
    else{
    }

    /** 				return themap[VALUE_LIST][pos_]*/
    _2 = (int)SEQ_PTR(_themap_11909);
    _6640 = (int)*(((s1_ptr)_2)->base + 6);
    _2 = (int)SEQ_PTR(_6640);
    _6641 = (int)*(((s1_ptr)_2)->base + _pos__11907);
    _6640 = NOVALUE;
    Ref(_6641);
    DeRef(_the_key_p_11904);
    DeRef(_default_value_p_11905);
    DeRefDS(_themap_11909);
    _6627 = NOVALUE;
    _6636 = NOVALUE;
    return _6641;
L9: 
L6: 
L3: 

    /** 	return default_value_p*/
    DeRef(_the_key_p_11904);
    DeRef(_themap_11909);
    _6627 = NOVALUE;
    _6636 = NOVALUE;
    _6641 = NOVALUE;
    return _default_value_p_11905;
    ;
}


void _28put(int _the_map_p_11973, int _the_key_p_11974, int _the_value_p_11975, int _operation_p_11976, int _trigger_p_11977)
{
    int _index__11978 = NOVALUE;
    int _bucket__11979 = NOVALUE;
    int _average_length__11980 = NOVALUE;
    int _from__11981 = NOVALUE;
    int _map_data_11982 = NOVALUE;
    int _calc_hash_1__tmp_at46_11993 = NOVALUE;
    int _calc_hash_inlined_calc_hash_at_46_11992 = NOVALUE;
    int _ret__inlined_calc_hash_at_46_11991 = NOVALUE;
    int _max_hash_p_inlined_calc_hash_at_43_11990 = NOVALUE;
    int _data_12025 = NOVALUE;
    int _msg_inlined_crash_at_334_12041 = NOVALUE;
    int _msg_inlined_crash_at_379_12047 = NOVALUE;
    int _tmp_seqk_12061 = NOVALUE;
    int _tmp_seqv_12069 = NOVALUE;
    int _msg_inlined_crash_at_721_12105 = NOVALUE;
    int _msg_inlined_crash_at_1079_12168 = NOVALUE;
    int _6785 = NOVALUE;
    int _6784 = NOVALUE;
    int _6782 = NOVALUE;
    int _6781 = NOVALUE;
    int _6780 = NOVALUE;
    int _6779 = NOVALUE;
    int _6777 = NOVALUE;
    int _6776 = NOVALUE;
    int _6775 = NOVALUE;
    int _6773 = NOVALUE;
    int _6772 = NOVALUE;
    int _6771 = NOVALUE;
    int _6769 = NOVALUE;
    int _6768 = NOVALUE;
    int _6767 = NOVALUE;
    int _6765 = NOVALUE;
    int _6764 = NOVALUE;
    int _6763 = NOVALUE;
    int _6761 = NOVALUE;
    int _6759 = NOVALUE;
    int _6753 = NOVALUE;
    int _6752 = NOVALUE;
    int _6751 = NOVALUE;
    int _6750 = NOVALUE;
    int _6748 = NOVALUE;
    int _6746 = NOVALUE;
    int _6745 = NOVALUE;
    int _6744 = NOVALUE;
    int _6743 = NOVALUE;
    int _6742 = NOVALUE;
    int _6741 = NOVALUE;
    int _6738 = NOVALUE;
    int _6736 = NOVALUE;
    int _6733 = NOVALUE;
    int _6731 = NOVALUE;
    int _6728 = NOVALUE;
    int _6727 = NOVALUE;
    int _6725 = NOVALUE;
    int _6722 = NOVALUE;
    int _6721 = NOVALUE;
    int _6718 = NOVALUE;
    int _6715 = NOVALUE;
    int _6713 = NOVALUE;
    int _6711 = NOVALUE;
    int _6708 = NOVALUE;
    int _6706 = NOVALUE;
    int _6705 = NOVALUE;
    int _6704 = NOVALUE;
    int _6703 = NOVALUE;
    int _6702 = NOVALUE;
    int _6701 = NOVALUE;
    int _6700 = NOVALUE;
    int _6699 = NOVALUE;
    int _6698 = NOVALUE;
    int _6692 = NOVALUE;
    int _6690 = NOVALUE;
    int _6689 = NOVALUE;
    int _6687 = NOVALUE;
    int _6685 = NOVALUE;
    int _6682 = NOVALUE;
    int _6681 = NOVALUE;
    int _6680 = NOVALUE;
    int _6679 = NOVALUE;
    int _6677 = NOVALUE;
    int _6676 = NOVALUE;
    int _6675 = NOVALUE;
    int _6673 = NOVALUE;
    int _6672 = NOVALUE;
    int _6671 = NOVALUE;
    int _6669 = NOVALUE;
    int _6668 = NOVALUE;
    int _6667 = NOVALUE;
    int _6665 = NOVALUE;
    int _6663 = NOVALUE;
    int _6658 = NOVALUE;
    int _6657 = NOVALUE;
    int _6656 = NOVALUE;
    int _6655 = NOVALUE;
    int _6653 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_the_map_p_11973)) {
        _1 = (long)(DBL_PTR(_the_map_p_11973)->dbl);
        DeRefDS(_the_map_p_11973);
        _the_map_p_11973 = _1;
    }

    /** 	sequence map_data = eumem:ram_space[the_map_p]*/
    DeRef(_map_data_11982);
    _2 = (int)SEQ_PTR(_29ram_space_10710);
    _map_data_11982 = (int)*(((s1_ptr)_2)->base + _the_map_p_11973);
    Ref(_map_data_11982);

    /** 	eumem:ram_space[the_map_p] = 0*/
    _2 = (int)SEQ_PTR(_29ram_space_10710);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29ram_space_10710 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _the_map_p_11973);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 	if map_data[MAP_TYPE] = LARGEMAP then*/
    _2 = (int)SEQ_PTR(_map_data_11982);
    _6653 = (int)*(((s1_ptr)_2)->base + 4);
    if (binary_op_a(NOTEQ, _6653, 76)){
        _6653 = NOVALUE;
        goto L1; // [31] 618
    }
    _6653 = NOVALUE;

    /** 		bucket_ = calc_hash(the_key_p,  length(map_data[KEY_BUCKETS]))*/
    _2 = (int)SEQ_PTR(_map_data_11982);
    _6655 = (int)*(((s1_ptr)_2)->base + 5);
    if (IS_SEQUENCE(_6655)){
            _6656 = SEQ_PTR(_6655)->length;
    }
    else {
        _6656 = 1;
    }
    _6655 = NOVALUE;
    _max_hash_p_inlined_calc_hash_at_43_11990 = _6656;
    _6656 = NOVALUE;

    /**     ret_ = hash(key_p, stdhash:HSIEH30)*/
    DeRef(_ret__inlined_calc_hash_at_46_11991);
    _ret__inlined_calc_hash_at_46_11991 = calc_hash(_the_key_p_11974, -6);
    if (!IS_ATOM_INT(_ret__inlined_calc_hash_at_46_11991)) {
        _1 = (long)(DBL_PTR(_ret__inlined_calc_hash_at_46_11991)->dbl);
        DeRefDS(_ret__inlined_calc_hash_at_46_11991);
        _ret__inlined_calc_hash_at_46_11991 = _1;
    }

    /** 	return remainder(ret_, max_hash_p) + 1 -- 1-based*/
    _calc_hash_1__tmp_at46_11993 = (_ret__inlined_calc_hash_at_46_11991 % _max_hash_p_inlined_calc_hash_at_43_11990);
    _bucket__11979 = _calc_hash_1__tmp_at46_11993 + 1;
    DeRef(_ret__inlined_calc_hash_at_46_11991);
    _ret__inlined_calc_hash_at_46_11991 = NOVALUE;
    if (!IS_ATOM_INT(_bucket__11979)) {
        _1 = (long)(DBL_PTR(_bucket__11979)->dbl);
        DeRefDS(_bucket__11979);
        _bucket__11979 = _1;
    }

    /** 		index_ = find(the_key_p, map_data[KEY_BUCKETS][bucket_])*/
    _2 = (int)SEQ_PTR(_map_data_11982);
    _6657 = (int)*(((s1_ptr)_2)->base + 5);
    _2 = (int)SEQ_PTR(_6657);
    _6658 = (int)*(((s1_ptr)_2)->base + _bucket__11979);
    _6657 = NOVALUE;
    _index__11978 = find_from(_the_key_p_11974, _6658, 1);
    _6658 = NOVALUE;

    /** 		if index_ > 0 then*/
    if (_index__11978 <= 0)
    goto L2; // [89] 368

    /** 			switch operation_p do*/
    _0 = _operation_p_11976;
    switch ( _0 ){ 

        /** 				case PUT then*/
        case 1:

        /** 					map_data[VALUE_BUCKETS][bucket_][index_] = the_value_p*/
        _2 = (int)SEQ_PTR(_map_data_11982);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _map_data_11982 = MAKE_SEQ(_2);
        }
        _3 = (int)(6 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(object_ptr)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(object_ptr)_3 = MAKE_SEQ(_2);
        }
        _3 = (int)(_bucket__11979 + ((s1_ptr)_2)->base);
        _6663 = NOVALUE;
        Ref(_the_value_p_11975);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _index__11978);
        _1 = *(int *)_2;
        *(int *)_2 = _the_value_p_11975;
        DeRef(_1);
        _6663 = NOVALUE;
        goto L3; // [120] 354

        /** 				case ADD then*/
        case 2:

        /** 					map_data[VALUE_BUCKETS][bucket_][index_] += the_value_p*/
        _2 = (int)SEQ_PTR(_map_data_11982);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _map_data_11982 = MAKE_SEQ(_2);
        }
        _3 = (int)(6 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(object_ptr)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(object_ptr)_3 = MAKE_SEQ(_2);
        }
        _3 = (int)(_bucket__11979 + ((s1_ptr)_2)->base);
        _6665 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        _6667 = (int)*(((s1_ptr)_2)->base + _index__11978);
        _6665 = NOVALUE;
        if (IS_ATOM_INT(_6667) && IS_ATOM_INT(_the_value_p_11975)) {
            _6668 = _6667 + _the_value_p_11975;
            if ((long)((unsigned long)_6668 + (unsigned long)HIGH_BITS) >= 0) 
            _6668 = NewDouble((double)_6668);
        }
        else {
            _6668 = binary_op(PLUS, _6667, _the_value_p_11975);
        }
        _6667 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _index__11978);
        _1 = *(int *)_2;
        *(int *)_2 = _6668;
        if( _1 != _6668 ){
            DeRef(_1);
        }
        _6668 = NOVALUE;
        _6665 = NOVALUE;
        goto L3; // [150] 354

        /** 				case SUBTRACT then*/
        case 3:

        /** 					map_data[VALUE_BUCKETS][bucket_][index_] -= the_value_p*/
        _2 = (int)SEQ_PTR(_map_data_11982);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _map_data_11982 = MAKE_SEQ(_2);
        }
        _3 = (int)(6 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(object_ptr)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(object_ptr)_3 = MAKE_SEQ(_2);
        }
        _3 = (int)(_bucket__11979 + ((s1_ptr)_2)->base);
        _6669 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        _6671 = (int)*(((s1_ptr)_2)->base + _index__11978);
        _6669 = NOVALUE;
        if (IS_ATOM_INT(_6671) && IS_ATOM_INT(_the_value_p_11975)) {
            _6672 = _6671 - _the_value_p_11975;
            if ((long)((unsigned long)_6672 +(unsigned long) HIGH_BITS) >= 0){
                _6672 = NewDouble((double)_6672);
            }
        }
        else {
            _6672 = binary_op(MINUS, _6671, _the_value_p_11975);
        }
        _6671 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _index__11978);
        _1 = *(int *)_2;
        *(int *)_2 = _6672;
        if( _1 != _6672 ){
            DeRef(_1);
        }
        _6672 = NOVALUE;
        _6669 = NOVALUE;
        goto L3; // [180] 354

        /** 				case MULTIPLY then*/
        case 4:

        /** 					map_data[VALUE_BUCKETS][bucket_][index_] *= the_value_p*/
        _2 = (int)SEQ_PTR(_map_data_11982);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _map_data_11982 = MAKE_SEQ(_2);
        }
        _3 = (int)(6 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(object_ptr)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(object_ptr)_3 = MAKE_SEQ(_2);
        }
        _3 = (int)(_bucket__11979 + ((s1_ptr)_2)->base);
        _6673 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        _6675 = (int)*(((s1_ptr)_2)->base + _index__11978);
        _6673 = NOVALUE;
        if (IS_ATOM_INT(_6675) && IS_ATOM_INT(_the_value_p_11975)) {
            if (_6675 == (short)_6675 && _the_value_p_11975 <= INT15 && _the_value_p_11975 >= -INT15)
            _6676 = _6675 * _the_value_p_11975;
            else
            _6676 = NewDouble(_6675 * (double)_the_value_p_11975);
        }
        else {
            _6676 = binary_op(MULTIPLY, _6675, _the_value_p_11975);
        }
        _6675 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _index__11978);
        _1 = *(int *)_2;
        *(int *)_2 = _6676;
        if( _1 != _6676 ){
            DeRef(_1);
        }
        _6676 = NOVALUE;
        _6673 = NOVALUE;
        goto L3; // [210] 354

        /** 				case DIVIDE then*/
        case 5:

        /** 					map_data[VALUE_BUCKETS][bucket_][index_] /= the_value_p*/
        _2 = (int)SEQ_PTR(_map_data_11982);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _map_data_11982 = MAKE_SEQ(_2);
        }
        _3 = (int)(6 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(object_ptr)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(object_ptr)_3 = MAKE_SEQ(_2);
        }
        _3 = (int)(_bucket__11979 + ((s1_ptr)_2)->base);
        _6677 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        _6679 = (int)*(((s1_ptr)_2)->base + _index__11978);
        _6677 = NOVALUE;
        if (IS_ATOM_INT(_6679) && IS_ATOM_INT(_the_value_p_11975)) {
            _6680 = (_6679 % _the_value_p_11975) ? NewDouble((double)_6679 / _the_value_p_11975) : (_6679 / _the_value_p_11975);
        }
        else {
            _6680 = binary_op(DIVIDE, _6679, _the_value_p_11975);
        }
        _6679 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _index__11978);
        _1 = *(int *)_2;
        *(int *)_2 = _6680;
        if( _1 != _6680 ){
            DeRef(_1);
        }
        _6680 = NOVALUE;
        _6677 = NOVALUE;
        goto L3; // [240] 354

        /** 				case APPEND then*/
        case 6:

        /** 					sequence data = map_data[VALUE_BUCKETS][bucket_][index_]*/
        _2 = (int)SEQ_PTR(_map_data_11982);
        _6681 = (int)*(((s1_ptr)_2)->base + 6);
        _2 = (int)SEQ_PTR(_6681);
        _6682 = (int)*(((s1_ptr)_2)->base + _bucket__11979);
        _6681 = NOVALUE;
        DeRef(_data_12025);
        _2 = (int)SEQ_PTR(_6682);
        _data_12025 = (int)*(((s1_ptr)_2)->base + _index__11978);
        Ref(_data_12025);
        _6682 = NOVALUE;

        /** 					data = append( data, the_value_p )*/
        Ref(_the_value_p_11975);
        Append(&_data_12025, _data_12025, _the_value_p_11975);

        /** 					map_data[VALUE_BUCKETS][bucket_][index_] = data*/
        _2 = (int)SEQ_PTR(_map_data_11982);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _map_data_11982 = MAKE_SEQ(_2);
        }
        _3 = (int)(6 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(object_ptr)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(object_ptr)_3 = MAKE_SEQ(_2);
        }
        _3 = (int)(_bucket__11979 + ((s1_ptr)_2)->base);
        _6685 = NOVALUE;
        RefDS(_data_12025);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _index__11978);
        _1 = *(int *)_2;
        *(int *)_2 = _data_12025;
        DeRef(_1);
        _6685 = NOVALUE;
        DeRefDS(_data_12025);
        _data_12025 = NOVALUE;
        goto L3; // [286] 354

        /** 				case CONCAT then*/
        case 7:

        /** 					map_data[VALUE_BUCKETS][bucket_][index_] &= the_value_p*/
        _2 = (int)SEQ_PTR(_map_data_11982);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _map_data_11982 = MAKE_SEQ(_2);
        }
        _3 = (int)(6 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(object_ptr)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(object_ptr)_3 = MAKE_SEQ(_2);
        }
        _3 = (int)(_bucket__11979 + ((s1_ptr)_2)->base);
        _6687 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        _6689 = (int)*(((s1_ptr)_2)->base + _index__11978);
        _6687 = NOVALUE;
        if (IS_SEQUENCE(_6689) && IS_ATOM(_the_value_p_11975)) {
            Ref(_the_value_p_11975);
            Append(&_6690, _6689, _the_value_p_11975);
        }
        else if (IS_ATOM(_6689) && IS_SEQUENCE(_the_value_p_11975)) {
            Ref(_6689);
            Prepend(&_6690, _the_value_p_11975, _6689);
        }
        else {
            Concat((object_ptr)&_6690, _6689, _the_value_p_11975);
            _6689 = NOVALUE;
        }
        _6689 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _index__11978);
        _1 = *(int *)_2;
        *(int *)_2 = _6690;
        if( _1 != _6690 ){
            DeRef(_1);
        }
        _6690 = NOVALUE;
        _6687 = NOVALUE;
        goto L3; // [316] 354

        /** 				case LEAVE then*/
        case 8:

        /** 					operation_p = operation_p*/
        _operation_p_11976 = _operation_p_11976;
        goto L3; // [327] 354

        /** 				case else*/
        default:

        /** 					error:crash("Unknown operation given to map.e:put()")*/

        /** 	msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_334_12041);
        _msg_inlined_crash_at_334_12041 = EPrintf(-9999999, _6691, _5);

        /** 	machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_334_12041);

        /** end procedure*/
        goto L4; // [348] 351
L4: 
        DeRefi(_msg_inlined_crash_at_334_12041);
        _msg_inlined_crash_at_334_12041 = NOVALUE;
    ;}L3: 

    /** 			eumem:ram_space[the_map_p] = map_data*/
    RefDS(_map_data_11982);
    _2 = (int)SEQ_PTR(_29ram_space_10710);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29ram_space_10710 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _the_map_p_11973);
    _1 = *(int *)_2;
    *(int *)_2 = _map_data_11982;
    DeRef(_1);

    /** 			return*/
    DeRef(_tmp_seqk_12061);
    DeRef(_tmp_seqv_12069);
    DeRef(_the_key_p_11974);
    DeRef(_the_value_p_11975);
    DeRef(_average_length__11980);
    DeRefDS(_map_data_11982);
    _6655 = NOVALUE;
    return;
L2: 

    /** 		if not eu:find(operation_p, INIT_OPERATIONS) then*/
    _6692 = find_from(_operation_p_11976, _28INIT_OPERATIONS_11592, 1);
    if (_6692 != 0)
    goto L5; // [375] 399
    _6692 = NOVALUE;

    /** 				error:crash("Inappropriate initial operation given to map.e:put()")*/

    /** 	msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_379_12047);
    _msg_inlined_crash_at_379_12047 = EPrintf(-9999999, _6694, _5);

    /** 	machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_379_12047);

    /** end procedure*/
    goto L6; // [393] 396
L6: 
    DeRefi(_msg_inlined_crash_at_379_12047);
    _msg_inlined_crash_at_379_12047 = NOVALUE;
L5: 

    /** 		if operation_p = LEAVE then*/
    if (_operation_p_11976 != 8)
    goto L7; // [401] 419

    /** 			eumem:ram_space[the_map_p] = map_data*/
    RefDS(_map_data_11982);
    _2 = (int)SEQ_PTR(_29ram_space_10710);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29ram_space_10710 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _the_map_p_11973);
    _1 = *(int *)_2;
    *(int *)_2 = _map_data_11982;
    DeRef(_1);

    /** 			return*/
    DeRef(_tmp_seqk_12061);
    DeRef(_tmp_seqv_12069);
    DeRef(_the_key_p_11974);
    DeRef(_the_value_p_11975);
    DeRef(_average_length__11980);
    DeRefDS(_map_data_11982);
    _6655 = NOVALUE;
    return;
L7: 

    /** 		if operation_p = APPEND then*/
    if (_operation_p_11976 != 6)
    goto L8; // [421] 432

    /** 			the_value_p = { the_value_p }*/
    _0 = _the_value_p_11975;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_the_value_p_11975);
    *((int *)(_2+4)) = _the_value_p_11975;
    _the_value_p_11975 = MAKE_SEQ(_1);
    DeRef(_0);
L8: 

    /** 		map_data[IN_USE] += (length(map_data[KEY_BUCKETS][bucket_]) = 0)*/
    _2 = (int)SEQ_PTR(_map_data_11982);
    _6698 = (int)*(((s1_ptr)_2)->base + 5);
    _2 = (int)SEQ_PTR(_6698);
    _6699 = (int)*(((s1_ptr)_2)->base + _bucket__11979);
    _6698 = NOVALUE;
    if (IS_SEQUENCE(_6699)){
            _6700 = SEQ_PTR(_6699)->length;
    }
    else {
        _6700 = 1;
    }
    _6699 = NOVALUE;
    _6701 = (_6700 == 0);
    _6700 = NOVALUE;
    _2 = (int)SEQ_PTR(_map_data_11982);
    _6702 = (int)*(((s1_ptr)_2)->base + 3);
    if (IS_ATOM_INT(_6702)) {
        _6703 = _6702 + _6701;
        if ((long)((unsigned long)_6703 + (unsigned long)HIGH_BITS) >= 0) 
        _6703 = NewDouble((double)_6703);
    }
    else {
        _6703 = binary_op(PLUS, _6702, _6701);
    }
    _6702 = NOVALUE;
    _6701 = NOVALUE;
    _2 = (int)SEQ_PTR(_map_data_11982);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _map_data_11982 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = _6703;
    if( _1 != _6703 ){
        DeRef(_1);
    }
    _6703 = NOVALUE;

    /** 		map_data[ELEMENT_COUNT] += 1 -- elementCount		*/
    _2 = (int)SEQ_PTR(_map_data_11982);
    _6704 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_6704)) {
        _6705 = _6704 + 1;
        if (_6705 > MAXINT){
            _6705 = NewDouble((double)_6705);
        }
    }
    else
    _6705 = binary_op(PLUS, 1, _6704);
    _6704 = NOVALUE;
    _2 = (int)SEQ_PTR(_map_data_11982);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _map_data_11982 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _6705;
    if( _1 != _6705 ){
        DeRef(_1);
    }
    _6705 = NOVALUE;

    /** 		sequence tmp_seqk*/

    /** 		tmp_seqk = map_data[KEY_BUCKETS][bucket_]*/
    _2 = (int)SEQ_PTR(_map_data_11982);
    _6706 = (int)*(((s1_ptr)_2)->base + 5);
    DeRef(_tmp_seqk_12061);
    _2 = (int)SEQ_PTR(_6706);
    _tmp_seqk_12061 = (int)*(((s1_ptr)_2)->base + _bucket__11979);
    Ref(_tmp_seqk_12061);
    _6706 = NOVALUE;

    /** 		map_data[KEY_BUCKETS][bucket_] = 0*/
    _2 = (int)SEQ_PTR(_map_data_11982);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _map_data_11982 = MAKE_SEQ(_2);
    }
    _3 = (int)(5 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _bucket__11979);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _6708 = NOVALUE;

    /** 		tmp_seqk = append( tmp_seqk, the_key_p)*/
    Ref(_the_key_p_11974);
    Append(&_tmp_seqk_12061, _tmp_seqk_12061, _the_key_p_11974);

    /** 		map_data[KEY_BUCKETS][bucket_] = tmp_seqk*/
    _2 = (int)SEQ_PTR(_map_data_11982);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _map_data_11982 = MAKE_SEQ(_2);
    }
    _3 = (int)(5 + ((s1_ptr)_2)->base);
    RefDS(_tmp_seqk_12061);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _bucket__11979);
    _1 = *(int *)_2;
    *(int *)_2 = _tmp_seqk_12061;
    DeRef(_1);
    _6711 = NOVALUE;

    /** 		sequence tmp_seqv*/

    /** 		tmp_seqv = map_data[VALUE_BUCKETS][bucket_]*/
    _2 = (int)SEQ_PTR(_map_data_11982);
    _6713 = (int)*(((s1_ptr)_2)->base + 6);
    DeRef(_tmp_seqv_12069);
    _2 = (int)SEQ_PTR(_6713);
    _tmp_seqv_12069 = (int)*(((s1_ptr)_2)->base + _bucket__11979);
    Ref(_tmp_seqv_12069);
    _6713 = NOVALUE;

    /** 		map_data[VALUE_BUCKETS][bucket_] = 0*/
    _2 = (int)SEQ_PTR(_map_data_11982);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _map_data_11982 = MAKE_SEQ(_2);
    }
    _3 = (int)(6 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _bucket__11979);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _6715 = NOVALUE;

    /** 		tmp_seqv = append( tmp_seqv, the_value_p)*/
    Ref(_the_value_p_11975);
    Append(&_tmp_seqv_12069, _tmp_seqv_12069, _the_value_p_11975);

    /** 		map_data[VALUE_BUCKETS][bucket_] = tmp_seqv*/
    _2 = (int)SEQ_PTR(_map_data_11982);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _map_data_11982 = MAKE_SEQ(_2);
    }
    _3 = (int)(6 + ((s1_ptr)_2)->base);
    RefDS(_tmp_seqv_12069);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _bucket__11979);
    _1 = *(int *)_2;
    *(int *)_2 = _tmp_seqv_12069;
    DeRef(_1);
    _6718 = NOVALUE;

    /** 		eumem:ram_space[the_map_p] = map_data*/
    RefDS(_map_data_11982);
    _2 = (int)SEQ_PTR(_29ram_space_10710);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29ram_space_10710 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _the_map_p_11973);
    _1 = *(int *)_2;
    *(int *)_2 = _map_data_11982;
    DeRef(_1);

    /** 		if trigger_p > 0 then*/
    if (_trigger_p_11977 <= 0)
    goto L9; // [569] 608

    /** 			average_length_ = map_data[ELEMENT_COUNT] / map_data[IN_USE]*/
    _2 = (int)SEQ_PTR(_map_data_11982);
    _6721 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_map_data_11982);
    _6722 = (int)*(((s1_ptr)_2)->base + 3);
    DeRef(_average_length__11980);
    if (IS_ATOM_INT(_6721) && IS_ATOM_INT(_6722)) {
        _average_length__11980 = (_6721 % _6722) ? NewDouble((double)_6721 / _6722) : (_6721 / _6722);
    }
    else {
        _average_length__11980 = binary_op(DIVIDE, _6721, _6722);
    }
    _6721 = NOVALUE;
    _6722 = NOVALUE;

    /** 			if (average_length_ >= trigger_p) then*/
    if (binary_op_a(LESS, _average_length__11980, _trigger_p_11977)){
        goto LA; // [589] 607
    }

    /** 				map_data = {}*/
    RefDS(_5);
    DeRefDS(_map_data_11982);
    _map_data_11982 = _5;

    /** 				rehash(the_map_p)*/
    _28rehash(_the_map_p_11973, 0);
LA: 
L9: 

    /** 		return*/
    DeRef(_tmp_seqk_12061);
    DeRef(_tmp_seqv_12069);
    DeRef(_the_key_p_11974);
    DeRef(_the_value_p_11975);
    DeRef(_average_length__11980);
    DeRef(_map_data_11982);
    _6655 = NOVALUE;
    _6699 = NOVALUE;
    return;
    goto LB; // [615] 1112
L1: 

    /** 		if equal(the_key_p, init_small_map_key) then*/
    if (_the_key_p_11974 == _28init_small_map_key_11598)
    _6725 = 1;
    else if (IS_ATOM_INT(_the_key_p_11974) && IS_ATOM_INT(_28init_small_map_key_11598))
    _6725 = 0;
    else
    _6725 = (compare(_the_key_p_11974, _28init_small_map_key_11598) == 0);
    if (_6725 == 0)
    {
        _6725 = NOVALUE;
        goto LC; // [624] 690
    }
    else{
        _6725 = NOVALUE;
    }

    /** 			from_ = 1*/
    _from__11981 = 1;

    /** 			while index_ > 0 with entry do*/
    goto LD; // [634] 671
LE: 
    if (_index__11978 <= 0)
    goto LF; // [639] 702

    /** 				if map_data[FREE_LIST][index_] = 1 then*/
    _2 = (int)SEQ_PTR(_map_data_11982);
    _6727 = (int)*(((s1_ptr)_2)->base + 7);
    _2 = (int)SEQ_PTR(_6727);
    _6728 = (int)*(((s1_ptr)_2)->base + _index__11978);
    _6727 = NOVALUE;
    if (binary_op_a(NOTEQ, _6728, 1)){
        _6728 = NOVALUE;
        goto L10; // [653] 662
    }
    _6728 = NOVALUE;

    /** 					exit*/
    goto LF; // [659] 702
L10: 

    /** 				from_ = index_ + 1*/
    _from__11981 = _index__11978 + 1;

    /** 			  entry*/
LD: 

    /** 				index_ = find(the_key_p, map_data[KEY_LIST], from_)*/
    _2 = (int)SEQ_PTR(_map_data_11982);
    _6731 = (int)*(((s1_ptr)_2)->base + 5);
    _index__11978 = find_from(_the_key_p_11974, _6731, _from__11981);
    _6731 = NOVALUE;

    /** 			end while*/
    goto LE; // [684] 637
    goto LF; // [687] 702
LC: 

    /** 			index_ = find(the_key_p, map_data[KEY_LIST])*/
    _2 = (int)SEQ_PTR(_map_data_11982);
    _6733 = (int)*(((s1_ptr)_2)->base + 5);
    _index__11978 = find_from(_the_key_p_11974, _6733, 1);
    _6733 = NOVALUE;
LF: 

    /** 		if index_ = 0 then*/
    if (_index__11978 != 0)
    goto L11; // [706] 884

    /** 			if not eu:find(operation_p, INIT_OPERATIONS) then*/
    _6736 = find_from(_operation_p_11976, _28INIT_OPERATIONS_11592, 1);
    if (_6736 != 0)
    goto L12; // [717] 741
    _6736 = NOVALUE;

    /** 					error:crash("Inappropriate initial operation given to map.e:put()")*/

    /** 	msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_721_12105);
    _msg_inlined_crash_at_721_12105 = EPrintf(-9999999, _6694, _5);

    /** 	machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_721_12105);

    /** end procedure*/
    goto L13; // [735] 738
L13: 
    DeRefi(_msg_inlined_crash_at_721_12105);
    _msg_inlined_crash_at_721_12105 = NOVALUE;
L12: 

    /** 			index_ = find(0, map_data[FREE_LIST])*/
    _2 = (int)SEQ_PTR(_map_data_11982);
    _6738 = (int)*(((s1_ptr)_2)->base + 7);
    _index__11978 = find_from(0, _6738, 1);
    _6738 = NOVALUE;

    /** 			if index_ = 0 then*/
    if (_index__11978 != 0)
    goto L14; // [754] 808

    /** 				eumem:ram_space[the_map_p] = map_data*/
    RefDS(_map_data_11982);
    _2 = (int)SEQ_PTR(_29ram_space_10710);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29ram_space_10710 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _the_map_p_11973);
    _1 = *(int *)_2;
    *(int *)_2 = _map_data_11982;
    DeRef(_1);

    /** 				map_data = {}*/
    RefDS(_5);
    DeRefDS(_map_data_11982);
    _map_data_11982 = _5;

    /** 				convert_to_large_map(the_map_p)*/
    _28convert_to_large_map(_the_map_p_11973);

    /** 				put(the_map_p, the_key_p, the_value_p, operation_p, trigger_p)*/
    DeRef(_6741);
    _6741 = _the_map_p_11973;
    Ref(_the_key_p_11974);
    DeRef(_6742);
    _6742 = _the_key_p_11974;
    Ref(_the_value_p_11975);
    DeRef(_6743);
    _6743 = _the_value_p_11975;
    DeRef(_6744);
    _6744 = _operation_p_11976;
    DeRef(_6745);
    _6745 = _trigger_p_11977;
    _28put(_6741, _6742, _6743, _6744, _6745);
    _6741 = NOVALUE;
    _6742 = NOVALUE;
    _6743 = NOVALUE;
    _6744 = NOVALUE;
    _6745 = NOVALUE;

    /** 				return*/
    DeRef(_the_key_p_11974);
    DeRef(_the_value_p_11975);
    DeRef(_average_length__11980);
    DeRefDS(_map_data_11982);
    _6655 = NOVALUE;
    _6699 = NOVALUE;
    return;
L14: 

    /** 			map_data[KEY_LIST][index_] = the_key_p*/
    _2 = (int)SEQ_PTR(_map_data_11982);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _map_data_11982 = MAKE_SEQ(_2);
    }
    _3 = (int)(5 + ((s1_ptr)_2)->base);
    Ref(_the_key_p_11974);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _index__11978);
    _1 = *(int *)_2;
    *(int *)_2 = _the_key_p_11974;
    DeRef(_1);
    _6746 = NOVALUE;

    /** 			map_data[FREE_LIST][index_] = 1*/
    _2 = (int)SEQ_PTR(_map_data_11982);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _map_data_11982 = MAKE_SEQ(_2);
    }
    _3 = (int)(7 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _index__11978);
    _1 = *(int *)_2;
    *(int *)_2 = 1;
    DeRef(_1);
    _6748 = NOVALUE;

    /** 			map_data[IN_USE] += 1*/
    _2 = (int)SEQ_PTR(_map_data_11982);
    _6750 = (int)*(((s1_ptr)_2)->base + 3);
    if (IS_ATOM_INT(_6750)) {
        _6751 = _6750 + 1;
        if (_6751 > MAXINT){
            _6751 = NewDouble((double)_6751);
        }
    }
    else
    _6751 = binary_op(PLUS, 1, _6750);
    _6750 = NOVALUE;
    _2 = (int)SEQ_PTR(_map_data_11982);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _map_data_11982 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = _6751;
    if( _1 != _6751 ){
        DeRef(_1);
    }
    _6751 = NOVALUE;

    /** 			map_data[ELEMENT_COUNT] += 1*/
    _2 = (int)SEQ_PTR(_map_data_11982);
    _6752 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_6752)) {
        _6753 = _6752 + 1;
        if (_6753 > MAXINT){
            _6753 = NewDouble((double)_6753);
        }
    }
    else
    _6753 = binary_op(PLUS, 1, _6752);
    _6752 = NOVALUE;
    _2 = (int)SEQ_PTR(_map_data_11982);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _map_data_11982 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _6753;
    if( _1 != _6753 ){
        DeRef(_1);
    }
    _6753 = NOVALUE;

    /** 			if operation_p = APPEND then*/
    if (_operation_p_11976 != 6)
    goto L15; // [860] 871

    /** 				the_value_p = { the_value_p }*/
    _0 = _the_value_p_11975;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_the_value_p_11975);
    *((int *)(_2+4)) = _the_value_p_11975;
    _the_value_p_11975 = MAKE_SEQ(_1);
    DeRef(_0);
L15: 

    /** 			if operation_p != LEAVE then*/
    if (_operation_p_11976 == 8)
    goto L16; // [873] 883

    /** 				operation_p = PUT	-- Initially, nearly everything is a PUT.*/
    _operation_p_11976 = 1;
L16: 
L11: 

    /** 		switch operation_p do*/
    _0 = _operation_p_11976;
    switch ( _0 ){ 

        /** 			case PUT then*/
        case 1:

        /** 				map_data[VALUE_LIST][index_] = the_value_p*/
        _2 = (int)SEQ_PTR(_map_data_11982);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _map_data_11982 = MAKE_SEQ(_2);
        }
        _3 = (int)(6 + ((s1_ptr)_2)->base);
        Ref(_the_value_p_11975);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _index__11978);
        _1 = *(int *)_2;
        *(int *)_2 = _the_value_p_11975;
        DeRef(_1);
        _6759 = NOVALUE;
        goto L17; // [906] 1098

        /** 			case ADD then*/
        case 2:

        /** 				map_data[VALUE_LIST][index_] += the_value_p*/
        _2 = (int)SEQ_PTR(_map_data_11982);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _map_data_11982 = MAKE_SEQ(_2);
        }
        _3 = (int)(6 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        _6763 = (int)*(((s1_ptr)_2)->base + _index__11978);
        _6761 = NOVALUE;
        if (IS_ATOM_INT(_6763) && IS_ATOM_INT(_the_value_p_11975)) {
            _6764 = _6763 + _the_value_p_11975;
            if ((long)((unsigned long)_6764 + (unsigned long)HIGH_BITS) >= 0) 
            _6764 = NewDouble((double)_6764);
        }
        else {
            _6764 = binary_op(PLUS, _6763, _the_value_p_11975);
        }
        _6763 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _index__11978);
        _1 = *(int *)_2;
        *(int *)_2 = _6764;
        if( _1 != _6764 ){
            DeRef(_1);
        }
        _6764 = NOVALUE;
        _6761 = NOVALUE;
        goto L17; // [931] 1098

        /** 			case SUBTRACT then*/
        case 3:

        /** 				map_data[VALUE_LIST][index_] -= the_value_p*/
        _2 = (int)SEQ_PTR(_map_data_11982);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _map_data_11982 = MAKE_SEQ(_2);
        }
        _3 = (int)(6 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        _6767 = (int)*(((s1_ptr)_2)->base + _index__11978);
        _6765 = NOVALUE;
        if (IS_ATOM_INT(_6767) && IS_ATOM_INT(_the_value_p_11975)) {
            _6768 = _6767 - _the_value_p_11975;
            if ((long)((unsigned long)_6768 +(unsigned long) HIGH_BITS) >= 0){
                _6768 = NewDouble((double)_6768);
            }
        }
        else {
            _6768 = binary_op(MINUS, _6767, _the_value_p_11975);
        }
        _6767 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _index__11978);
        _1 = *(int *)_2;
        *(int *)_2 = _6768;
        if( _1 != _6768 ){
            DeRef(_1);
        }
        _6768 = NOVALUE;
        _6765 = NOVALUE;
        goto L17; // [956] 1098

        /** 			case MULTIPLY then*/
        case 4:

        /** 				map_data[VALUE_LIST][index_] *= the_value_p*/
        _2 = (int)SEQ_PTR(_map_data_11982);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _map_data_11982 = MAKE_SEQ(_2);
        }
        _3 = (int)(6 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        _6771 = (int)*(((s1_ptr)_2)->base + _index__11978);
        _6769 = NOVALUE;
        if (IS_ATOM_INT(_6771) && IS_ATOM_INT(_the_value_p_11975)) {
            if (_6771 == (short)_6771 && _the_value_p_11975 <= INT15 && _the_value_p_11975 >= -INT15)
            _6772 = _6771 * _the_value_p_11975;
            else
            _6772 = NewDouble(_6771 * (double)_the_value_p_11975);
        }
        else {
            _6772 = binary_op(MULTIPLY, _6771, _the_value_p_11975);
        }
        _6771 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _index__11978);
        _1 = *(int *)_2;
        *(int *)_2 = _6772;
        if( _1 != _6772 ){
            DeRef(_1);
        }
        _6772 = NOVALUE;
        _6769 = NOVALUE;
        goto L17; // [981] 1098

        /** 			case DIVIDE then*/
        case 5:

        /** 				map_data[VALUE_LIST][index_] /= the_value_p*/
        _2 = (int)SEQ_PTR(_map_data_11982);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _map_data_11982 = MAKE_SEQ(_2);
        }
        _3 = (int)(6 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        _6775 = (int)*(((s1_ptr)_2)->base + _index__11978);
        _6773 = NOVALUE;
        if (IS_ATOM_INT(_6775) && IS_ATOM_INT(_the_value_p_11975)) {
            _6776 = (_6775 % _the_value_p_11975) ? NewDouble((double)_6775 / _the_value_p_11975) : (_6775 / _the_value_p_11975);
        }
        else {
            _6776 = binary_op(DIVIDE, _6775, _the_value_p_11975);
        }
        _6775 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _index__11978);
        _1 = *(int *)_2;
        *(int *)_2 = _6776;
        if( _1 != _6776 ){
            DeRef(_1);
        }
        _6776 = NOVALUE;
        _6773 = NOVALUE;
        goto L17; // [1006] 1098

        /** 			case APPEND then*/
        case 6:

        /** 				map_data[VALUE_LIST][index_] = append( map_data[VALUE_LIST][index_], the_value_p )*/
        _2 = (int)SEQ_PTR(_map_data_11982);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _map_data_11982 = MAKE_SEQ(_2);
        }
        _3 = (int)(6 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(_map_data_11982);
        _6779 = (int)*(((s1_ptr)_2)->base + 6);
        _2 = (int)SEQ_PTR(_6779);
        _6780 = (int)*(((s1_ptr)_2)->base + _index__11978);
        _6779 = NOVALUE;
        Ref(_the_value_p_11975);
        Append(&_6781, _6780, _the_value_p_11975);
        _6780 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _index__11978);
        _1 = *(int *)_2;
        *(int *)_2 = _6781;
        if( _1 != _6781 ){
            DeRef(_1);
        }
        _6781 = NOVALUE;
        _6777 = NOVALUE;
        goto L17; // [1035] 1098

        /** 			case CONCAT then*/
        case 7:

        /** 				map_data[VALUE_LIST][index_] &= the_value_p*/
        _2 = (int)SEQ_PTR(_map_data_11982);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _map_data_11982 = MAKE_SEQ(_2);
        }
        _3 = (int)(6 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        _6784 = (int)*(((s1_ptr)_2)->base + _index__11978);
        _6782 = NOVALUE;
        if (IS_SEQUENCE(_6784) && IS_ATOM(_the_value_p_11975)) {
            Ref(_the_value_p_11975);
            Append(&_6785, _6784, _the_value_p_11975);
        }
        else if (IS_ATOM(_6784) && IS_SEQUENCE(_the_value_p_11975)) {
            Ref(_6784);
            Prepend(&_6785, _the_value_p_11975, _6784);
        }
        else {
            Concat((object_ptr)&_6785, _6784, _the_value_p_11975);
            _6784 = NOVALUE;
        }
        _6784 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _index__11978);
        _1 = *(int *)_2;
        *(int *)_2 = _6785;
        if( _1 != _6785 ){
            DeRef(_1);
        }
        _6785 = NOVALUE;
        _6782 = NOVALUE;
        goto L17; // [1060] 1098

        /** 			case LEAVE then*/
        case 8:

        /** 				operation_p = operation_p*/
        _operation_p_11976 = _operation_p_11976;
        goto L17; // [1071] 1098

        /** 			case else*/
        default:

        /** 				error:crash("Unknown operation given to map.e:put()")*/

        /** 	msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_1079_12168);
        _msg_inlined_crash_at_1079_12168 = EPrintf(-9999999, _6691, _5);

        /** 	machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_1079_12168);

        /** end procedure*/
        goto L18; // [1092] 1095
L18: 
        DeRefi(_msg_inlined_crash_at_1079_12168);
        _msg_inlined_crash_at_1079_12168 = NOVALUE;
    ;}L17: 

    /** 		eumem:ram_space[the_map_p] = map_data*/
    RefDS(_map_data_11982);
    _2 = (int)SEQ_PTR(_29ram_space_10710);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29ram_space_10710 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _the_map_p_11973);
    _1 = *(int *)_2;
    *(int *)_2 = _map_data_11982;
    DeRef(_1);

    /** 		return*/
    DeRef(_the_key_p_11974);
    DeRef(_the_value_p_11975);
    DeRef(_average_length__11980);
    DeRefDS(_map_data_11982);
    _6655 = NOVALUE;
    _6699 = NOVALUE;
    return;
LB: 

    /** end procedure*/
    DeRef(_the_key_p_11974);
    DeRef(_the_value_p_11975);
    DeRef(_average_length__11980);
    DeRef(_map_data_11982);
    _6655 = NOVALUE;
    _6699 = NOVALUE;
    return;
    ;
}


void _28nested_put(int _the_map_p_12171, int _the_keys_p_12172, int _the_value_p_12173, int _operation_p_12174, int _trigger_p_12175)
{
    int _temp_map__12176 = NOVALUE;
    int _6797 = NOVALUE;
    int _6796 = NOVALUE;
    int _6795 = NOVALUE;
    int _6794 = NOVALUE;
    int _6793 = NOVALUE;
    int _6792 = NOVALUE;
    int _6790 = NOVALUE;
    int _6789 = NOVALUE;
    int _6788 = NOVALUE;
    int _6786 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if length( the_keys_p ) = 1 then*/
    if (IS_SEQUENCE(_the_keys_p_12172)){
            _6786 = SEQ_PTR(_the_keys_p_12172)->length;
    }
    else {
        _6786 = 1;
    }
    if (_6786 != 1)
    goto L1; // [12] 32

    /** 		put( the_map_p, the_keys_p[1], the_value_p, operation_p, trigger_p )*/
    _2 = (int)SEQ_PTR(_the_keys_p_12172);
    _6788 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_the_map_p_12171);
    Ref(_6788);
    Ref(_the_value_p_12173);
    _28put(_the_map_p_12171, _6788, _the_value_p_12173, _operation_p_12174, _trigger_p_12175);
    _6788 = NOVALUE;
    goto L2; // [29] 89
L1: 

    /** 		temp_map_ = new_extra( get( the_map_p, the_keys_p[1] ) )*/
    _2 = (int)SEQ_PTR(_the_keys_p_12172);
    _6789 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_the_map_p_12171);
    Ref(_6789);
    _6790 = _28get(_the_map_p_12171, _6789, 0);
    _6789 = NOVALUE;
    _0 = _temp_map__12176;
    _temp_map__12176 = _28new_extra(_6790, 690);
    DeRef(_0);
    _6790 = NOVALUE;

    /** 		nested_put( temp_map_, the_keys_p[2..$], the_value_p, operation_p, trigger_p )*/
    if (IS_SEQUENCE(_the_keys_p_12172)){
            _6792 = SEQ_PTR(_the_keys_p_12172)->length;
    }
    else {
        _6792 = 1;
    }
    rhs_slice_target = (object_ptr)&_6793;
    RHS_Slice(_the_keys_p_12172, 2, _6792);
    Ref(_the_value_p_12173);
    DeRef(_6794);
    _6794 = _the_value_p_12173;
    DeRef(_6795);
    _6795 = _operation_p_12174;
    DeRef(_6796);
    _6796 = _trigger_p_12175;
    Ref(_temp_map__12176);
    _28nested_put(_temp_map__12176, _6793, _6794, _6795, _6796);
    _6793 = NOVALUE;
    _6794 = NOVALUE;
    _6795 = NOVALUE;
    _6796 = NOVALUE;

    /** 		put( the_map_p, the_keys_p[1], temp_map_, PUT, trigger_p )*/
    _2 = (int)SEQ_PTR(_the_keys_p_12172);
    _6797 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_the_map_p_12171);
    Ref(_6797);
    Ref(_temp_map__12176);
    _28put(_the_map_p_12171, _6797, _temp_map__12176, 1, _trigger_p_12175);
    _6797 = NOVALUE;
L2: 

    /** end procedure*/
    DeRef(_the_map_p_12171);
    DeRefDS(_the_keys_p_12172);
    DeRef(_the_value_p_12173);
    DeRef(_temp_map__12176);
    return;
    ;
}


void _28remove(int _the_map_p_12193, int _the_key_p_12194)
{
    int _index__12195 = NOVALUE;
    int _bucket__12196 = NOVALUE;
    int _temp_map__12197 = NOVALUE;
    int _from__12198 = NOVALUE;
    int _calc_hash_1__tmp_at40_12209 = NOVALUE;
    int _calc_hash_inlined_calc_hash_at_40_12208 = NOVALUE;
    int _ret__inlined_calc_hash_at_40_12207 = NOVALUE;
    int _max_hash_p_inlined_calc_hash_at_37_12206 = NOVALUE;
    int _6862 = NOVALUE;
    int _6861 = NOVALUE;
    int _6860 = NOVALUE;
    int _6859 = NOVALUE;
    int _6857 = NOVALUE;
    int _6855 = NOVALUE;
    int _6853 = NOVALUE;
    int _6851 = NOVALUE;
    int _6850 = NOVALUE;
    int _6848 = NOVALUE;
    int _6845 = NOVALUE;
    int _6844 = NOVALUE;
    int _6843 = NOVALUE;
    int _6842 = NOVALUE;
    int _6841 = NOVALUE;
    int _6840 = NOVALUE;
    int _6839 = NOVALUE;
    int _6838 = NOVALUE;
    int _6837 = NOVALUE;
    int _6836 = NOVALUE;
    int _6835 = NOVALUE;
    int _6834 = NOVALUE;
    int _6833 = NOVALUE;
    int _6831 = NOVALUE;
    int _6830 = NOVALUE;
    int _6829 = NOVALUE;
    int _6828 = NOVALUE;
    int _6827 = NOVALUE;
    int _6826 = NOVALUE;
    int _6825 = NOVALUE;
    int _6824 = NOVALUE;
    int _6823 = NOVALUE;
    int _6822 = NOVALUE;
    int _6821 = NOVALUE;
    int _6819 = NOVALUE;
    int _6817 = NOVALUE;
    int _6815 = NOVALUE;
    int _6814 = NOVALUE;
    int _6813 = NOVALUE;
    int _6811 = NOVALUE;
    int _6810 = NOVALUE;
    int _6809 = NOVALUE;
    int _6808 = NOVALUE;
    int _6807 = NOVALUE;
    int _6804 = NOVALUE;
    int _6803 = NOVALUE;
    int _6802 = NOVALUE;
    int _6801 = NOVALUE;
    int _6799 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	temp_map_ = eumem:ram_space[the_map_p]*/
    DeRef(_temp_map__12197);
    _2 = (int)SEQ_PTR(_29ram_space_10710);
    if (!IS_ATOM_INT(_the_map_p_12193)){
        _temp_map__12197 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_the_map_p_12193)->dbl));
    }
    else{
        _temp_map__12197 = (int)*(((s1_ptr)_2)->base + _the_map_p_12193);
    }
    Ref(_temp_map__12197);

    /** 	eumem:ram_space[the_map_p] = 0*/
    _2 = (int)SEQ_PTR(_29ram_space_10710);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29ram_space_10710 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_the_map_p_12193))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_the_map_p_12193)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _the_map_p_12193);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 	if temp_map_[MAP_TYPE] = LARGEMAP then*/
    _2 = (int)SEQ_PTR(_temp_map__12197);
    _6799 = (int)*(((s1_ptr)_2)->base + 4);
    if (binary_op_a(NOTEQ, _6799, 76)){
        _6799 = NOVALUE;
        goto L1; // [25] 305
    }
    _6799 = NOVALUE;

    /** 		bucket_ = calc_hash(the_key_p, length(temp_map_[KEY_BUCKETS]))*/
    _2 = (int)SEQ_PTR(_temp_map__12197);
    _6801 = (int)*(((s1_ptr)_2)->base + 5);
    if (IS_SEQUENCE(_6801)){
            _6802 = SEQ_PTR(_6801)->length;
    }
    else {
        _6802 = 1;
    }
    _6801 = NOVALUE;
    _max_hash_p_inlined_calc_hash_at_37_12206 = _6802;
    _6802 = NOVALUE;

    /**     ret_ = hash(key_p, stdhash:HSIEH30)*/
    DeRef(_ret__inlined_calc_hash_at_40_12207);
    _ret__inlined_calc_hash_at_40_12207 = calc_hash(_the_key_p_12194, -6);
    if (!IS_ATOM_INT(_ret__inlined_calc_hash_at_40_12207)) {
        _1 = (long)(DBL_PTR(_ret__inlined_calc_hash_at_40_12207)->dbl);
        DeRefDS(_ret__inlined_calc_hash_at_40_12207);
        _ret__inlined_calc_hash_at_40_12207 = _1;
    }

    /** 	return remainder(ret_, max_hash_p) + 1 -- 1-based*/
    _calc_hash_1__tmp_at40_12209 = (_ret__inlined_calc_hash_at_40_12207 % _max_hash_p_inlined_calc_hash_at_37_12206);
    _bucket__12196 = _calc_hash_1__tmp_at40_12209 + 1;
    DeRef(_ret__inlined_calc_hash_at_40_12207);
    _ret__inlined_calc_hash_at_40_12207 = NOVALUE;
    if (!IS_ATOM_INT(_bucket__12196)) {
        _1 = (long)(DBL_PTR(_bucket__12196)->dbl);
        DeRefDS(_bucket__12196);
        _bucket__12196 = _1;
    }

    /** 		index_ = find(the_key_p, temp_map_[KEY_BUCKETS][bucket_])*/
    _2 = (int)SEQ_PTR(_temp_map__12197);
    _6803 = (int)*(((s1_ptr)_2)->base + 5);
    _2 = (int)SEQ_PTR(_6803);
    _6804 = (int)*(((s1_ptr)_2)->base + _bucket__12196);
    _6803 = NOVALUE;
    _index__12195 = find_from(_the_key_p_12194, _6804, 1);
    _6804 = NOVALUE;

    /** 		if index_ != 0 then*/
    if (_index__12195 == 0)
    goto L2; // [83] 431

    /** 			temp_map_[ELEMENT_COUNT] -= 1*/
    _2 = (int)SEQ_PTR(_temp_map__12197);
    _6807 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_6807)) {
        _6808 = _6807 - 1;
        if ((long)((unsigned long)_6808 +(unsigned long) HIGH_BITS) >= 0){
            _6808 = NewDouble((double)_6808);
        }
    }
    else {
        _6808 = binary_op(MINUS, _6807, 1);
    }
    _6807 = NOVALUE;
    _2 = (int)SEQ_PTR(_temp_map__12197);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__12197 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _6808;
    if( _1 != _6808 ){
        DeRef(_1);
    }
    _6808 = NOVALUE;

    /** 			if length(temp_map_[KEY_BUCKETS][bucket_]) = 1 then*/
    _2 = (int)SEQ_PTR(_temp_map__12197);
    _6809 = (int)*(((s1_ptr)_2)->base + 5);
    _2 = (int)SEQ_PTR(_6809);
    _6810 = (int)*(((s1_ptr)_2)->base + _bucket__12196);
    _6809 = NOVALUE;
    if (IS_SEQUENCE(_6810)){
            _6811 = SEQ_PTR(_6810)->length;
    }
    else {
        _6811 = 1;
    }
    _6810 = NOVALUE;
    if (_6811 != 1)
    goto L3; // [114] 157

    /** 				temp_map_[IN_USE] -= 1*/
    _2 = (int)SEQ_PTR(_temp_map__12197);
    _6813 = (int)*(((s1_ptr)_2)->base + 3);
    if (IS_ATOM_INT(_6813)) {
        _6814 = _6813 - 1;
        if ((long)((unsigned long)_6814 +(unsigned long) HIGH_BITS) >= 0){
            _6814 = NewDouble((double)_6814);
        }
    }
    else {
        _6814 = binary_op(MINUS, _6813, 1);
    }
    _6813 = NOVALUE;
    _2 = (int)SEQ_PTR(_temp_map__12197);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__12197 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = _6814;
    if( _1 != _6814 ){
        DeRef(_1);
    }
    _6814 = NOVALUE;

    /** 				temp_map_[KEY_BUCKETS][bucket_] = {}*/
    _2 = (int)SEQ_PTR(_temp_map__12197);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__12197 = MAKE_SEQ(_2);
    }
    _3 = (int)(5 + ((s1_ptr)_2)->base);
    RefDS(_5);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _bucket__12196);
    _1 = *(int *)_2;
    *(int *)_2 = _5;
    DeRef(_1);
    _6815 = NOVALUE;

    /** 				temp_map_[VALUE_BUCKETS][bucket_] = {}*/
    _2 = (int)SEQ_PTR(_temp_map__12197);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__12197 = MAKE_SEQ(_2);
    }
    _3 = (int)(6 + ((s1_ptr)_2)->base);
    RefDS(_5);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _bucket__12196);
    _1 = *(int *)_2;
    *(int *)_2 = _5;
    DeRef(_1);
    _6817 = NOVALUE;
    goto L4; // [154] 262
L3: 

    /** 				temp_map_[VALUE_BUCKETS][bucket_] = temp_map_[VALUE_BUCKETS][bucket_][1 .. index_-1] & */
    _2 = (int)SEQ_PTR(_temp_map__12197);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__12197 = MAKE_SEQ(_2);
    }
    _3 = (int)(6 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_temp_map__12197);
    _6821 = (int)*(((s1_ptr)_2)->base + 6);
    _2 = (int)SEQ_PTR(_6821);
    _6822 = (int)*(((s1_ptr)_2)->base + _bucket__12196);
    _6821 = NOVALUE;
    _6823 = _index__12195 - 1;
    rhs_slice_target = (object_ptr)&_6824;
    RHS_Slice(_6822, 1, _6823);
    _6822 = NOVALUE;
    _2 = (int)SEQ_PTR(_temp_map__12197);
    _6825 = (int)*(((s1_ptr)_2)->base + 6);
    _2 = (int)SEQ_PTR(_6825);
    _6826 = (int)*(((s1_ptr)_2)->base + _bucket__12196);
    _6825 = NOVALUE;
    _6827 = _index__12195 + 1;
    if (_6827 > MAXINT){
        _6827 = NewDouble((double)_6827);
    }
    if (IS_SEQUENCE(_6826)){
            _6828 = SEQ_PTR(_6826)->length;
    }
    else {
        _6828 = 1;
    }
    rhs_slice_target = (object_ptr)&_6829;
    RHS_Slice(_6826, _6827, _6828);
    _6826 = NOVALUE;
    Concat((object_ptr)&_6830, _6824, _6829);
    DeRefDS(_6824);
    _6824 = NOVALUE;
    DeRef(_6824);
    _6824 = NOVALUE;
    DeRefDS(_6829);
    _6829 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _bucket__12196);
    _1 = *(int *)_2;
    *(int *)_2 = _6830;
    if( _1 != _6830 ){
        DeRef(_1);
    }
    _6830 = NOVALUE;
    _6819 = NOVALUE;

    /** 				temp_map_[KEY_BUCKETS][bucket_] = temp_map_[KEY_BUCKETS][bucket_][1 .. index_-1] & */
    _2 = (int)SEQ_PTR(_temp_map__12197);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__12197 = MAKE_SEQ(_2);
    }
    _3 = (int)(5 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_temp_map__12197);
    _6833 = (int)*(((s1_ptr)_2)->base + 5);
    _2 = (int)SEQ_PTR(_6833);
    _6834 = (int)*(((s1_ptr)_2)->base + _bucket__12196);
    _6833 = NOVALUE;
    _6835 = _index__12195 - 1;
    rhs_slice_target = (object_ptr)&_6836;
    RHS_Slice(_6834, 1, _6835);
    _6834 = NOVALUE;
    _2 = (int)SEQ_PTR(_temp_map__12197);
    _6837 = (int)*(((s1_ptr)_2)->base + 5);
    _2 = (int)SEQ_PTR(_6837);
    _6838 = (int)*(((s1_ptr)_2)->base + _bucket__12196);
    _6837 = NOVALUE;
    _6839 = _index__12195 + 1;
    if (_6839 > MAXINT){
        _6839 = NewDouble((double)_6839);
    }
    if (IS_SEQUENCE(_6838)){
            _6840 = SEQ_PTR(_6838)->length;
    }
    else {
        _6840 = 1;
    }
    rhs_slice_target = (object_ptr)&_6841;
    RHS_Slice(_6838, _6839, _6840);
    _6838 = NOVALUE;
    Concat((object_ptr)&_6842, _6836, _6841);
    DeRefDS(_6836);
    _6836 = NOVALUE;
    DeRef(_6836);
    _6836 = NOVALUE;
    DeRefDS(_6841);
    _6841 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _bucket__12196);
    _1 = *(int *)_2;
    *(int *)_2 = _6842;
    if( _1 != _6842 ){
        DeRef(_1);
    }
    _6842 = NOVALUE;
    _6831 = NOVALUE;
L4: 

    /** 			if temp_map_[ELEMENT_COUNT] < floor(51 * threshold_size / 100) then*/
    _2 = (int)SEQ_PTR(_temp_map__12197);
    _6843 = (int)*(((s1_ptr)_2)->base + 2);
    _6844 = 1173;
    _6845 = 11;
    _6844 = NOVALUE;
    if (binary_op_a(GREATEREQ, _6843, 11)){
        _6843 = NOVALUE;
        _6845 = NOVALUE;
        goto L2; // [278] 431
    }
    _6843 = NOVALUE;
    DeRef(_6845);
    _6845 = NOVALUE;

    /** 				eumem:ram_space[the_map_p] = temp_map_*/
    RefDS(_temp_map__12197);
    _2 = (int)SEQ_PTR(_29ram_space_10710);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29ram_space_10710 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_the_map_p_12193))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_the_map_p_12193)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _the_map_p_12193);
    _1 = *(int *)_2;
    *(int *)_2 = _temp_map__12197;
    DeRef(_1);

    /** 				convert_to_small_map(the_map_p)*/
    Ref(_the_map_p_12193);
    _28convert_to_small_map(_the_map_p_12193);

    /** 				return*/
    DeRef(_the_map_p_12193);
    DeRef(_the_key_p_12194);
    DeRefDS(_temp_map__12197);
    _6801 = NOVALUE;
    _6810 = NOVALUE;
    DeRef(_6823);
    _6823 = NOVALUE;
    DeRef(_6835);
    _6835 = NOVALUE;
    DeRef(_6827);
    _6827 = NOVALUE;
    DeRef(_6839);
    _6839 = NOVALUE;
    return;
    goto L2; // [302] 431
L1: 

    /** 		from_ = 1*/
    _from__12198 = 1;

    /** 		while from_ > 0 do*/
L5: 
    if (_from__12198 <= 0)
    goto L6; // [315] 430

    /** 			index_ = find(the_key_p, temp_map_[KEY_LIST], from_)*/
    _2 = (int)SEQ_PTR(_temp_map__12197);
    _6848 = (int)*(((s1_ptr)_2)->base + 5);
    _index__12195 = find_from(_the_key_p_12194, _6848, _from__12198);
    _6848 = NOVALUE;

    /** 			if index_ then*/
    if (_index__12195 == 0)
    {
        goto L6; // [332] 430
    }
    else{
    }

    /** 				if temp_map_[FREE_LIST][index_] = 1 then*/
    _2 = (int)SEQ_PTR(_temp_map__12197);
    _6850 = (int)*(((s1_ptr)_2)->base + 7);
    _2 = (int)SEQ_PTR(_6850);
    _6851 = (int)*(((s1_ptr)_2)->base + _index__12195);
    _6850 = NOVALUE;
    if (binary_op_a(NOTEQ, _6851, 1)){
        _6851 = NOVALUE;
        goto L7; // [345] 419
    }
    _6851 = NOVALUE;

    /** 					temp_map_[FREE_LIST][index_] = 0*/
    _2 = (int)SEQ_PTR(_temp_map__12197);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__12197 = MAKE_SEQ(_2);
    }
    _3 = (int)(7 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _index__12195);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _6853 = NOVALUE;

    /** 					temp_map_[KEY_LIST][index_] = init_small_map_key*/
    _2 = (int)SEQ_PTR(_temp_map__12197);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__12197 = MAKE_SEQ(_2);
    }
    _3 = (int)(5 + ((s1_ptr)_2)->base);
    RefDS(_28init_small_map_key_11598);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _index__12195);
    _1 = *(int *)_2;
    *(int *)_2 = _28init_small_map_key_11598;
    DeRef(_1);
    _6855 = NOVALUE;

    /** 					temp_map_[VALUE_LIST][index_] = 0*/
    _2 = (int)SEQ_PTR(_temp_map__12197);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__12197 = MAKE_SEQ(_2);
    }
    _3 = (int)(6 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _index__12195);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _6857 = NOVALUE;

    /** 					temp_map_[IN_USE] -= 1*/
    _2 = (int)SEQ_PTR(_temp_map__12197);
    _6859 = (int)*(((s1_ptr)_2)->base + 3);
    if (IS_ATOM_INT(_6859)) {
        _6860 = _6859 - 1;
        if ((long)((unsigned long)_6860 +(unsigned long) HIGH_BITS) >= 0){
            _6860 = NewDouble((double)_6860);
        }
    }
    else {
        _6860 = binary_op(MINUS, _6859, 1);
    }
    _6859 = NOVALUE;
    _2 = (int)SEQ_PTR(_temp_map__12197);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__12197 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = _6860;
    if( _1 != _6860 ){
        DeRef(_1);
    }
    _6860 = NOVALUE;

    /** 					temp_map_[ELEMENT_COUNT] -= 1*/
    _2 = (int)SEQ_PTR(_temp_map__12197);
    _6861 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_6861)) {
        _6862 = _6861 - 1;
        if ((long)((unsigned long)_6862 +(unsigned long) HIGH_BITS) >= 0){
            _6862 = NewDouble((double)_6862);
        }
    }
    else {
        _6862 = binary_op(MINUS, _6861, 1);
    }
    _6861 = NOVALUE;
    _2 = (int)SEQ_PTR(_temp_map__12197);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__12197 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _6862;
    if( _1 != _6862 ){
        DeRef(_1);
    }
    _6862 = NOVALUE;
    goto L7; // [411] 419

    /** 				exit*/
    goto L6; // [416] 430
L7: 

    /** 			from_ = index_ + 1*/
    _from__12198 = _index__12195 + 1;

    /** 		end while*/
    goto L5; // [427] 315
L6: 
L2: 

    /** 	eumem:ram_space[the_map_p] = temp_map_*/
    RefDS(_temp_map__12197);
    _2 = (int)SEQ_PTR(_29ram_space_10710);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29ram_space_10710 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_the_map_p_12193))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_the_map_p_12193)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _the_map_p_12193);
    _1 = *(int *)_2;
    *(int *)_2 = _temp_map__12197;
    DeRef(_1);

    /** end procedure*/
    DeRef(_the_map_p_12193);
    DeRef(_the_key_p_12194);
    DeRefDS(_temp_map__12197);
    _6801 = NOVALUE;
    _6810 = NOVALUE;
    DeRef(_6823);
    _6823 = NOVALUE;
    DeRef(_6835);
    _6835 = NOVALUE;
    DeRef(_6827);
    _6827 = NOVALUE;
    DeRef(_6839);
    _6839 = NOVALUE;
    return;
    ;
}


void _28clear(int _the_map_p_12283)
{
    int _temp_map__12284 = NOVALUE;
    int _6881 = NOVALUE;
    int _6880 = NOVALUE;
    int _6879 = NOVALUE;
    int _6878 = NOVALUE;
    int _6877 = NOVALUE;
    int _6876 = NOVALUE;
    int _6875 = NOVALUE;
    int _6874 = NOVALUE;
    int _6873 = NOVALUE;
    int _6872 = NOVALUE;
    int _6871 = NOVALUE;
    int _6870 = NOVALUE;
    int _6869 = NOVALUE;
    int _6868 = NOVALUE;
    int _6867 = NOVALUE;
    int _6865 = NOVALUE;
    int _0, _1, _2;
    

    /** 	temp_map_ = eumem:ram_space[the_map_p]*/
    DeRef(_temp_map__12284);
    _2 = (int)SEQ_PTR(_29ram_space_10710);
    if (!IS_ATOM_INT(_the_map_p_12283)){
        _temp_map__12284 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_the_map_p_12283)->dbl));
    }
    else{
        _temp_map__12284 = (int)*(((s1_ptr)_2)->base + _the_map_p_12283);
    }
    Ref(_temp_map__12284);

    /** 	if temp_map_[MAP_TYPE] = LARGEMAP then*/
    _2 = (int)SEQ_PTR(_temp_map__12284);
    _6865 = (int)*(((s1_ptr)_2)->base + 4);
    if (binary_op_a(NOTEQ, _6865, 76)){
        _6865 = NOVALUE;
        goto L1; // [17] 70
    }
    _6865 = NOVALUE;

    /** 		temp_map_[ELEMENT_COUNT] = 0*/
    _2 = (int)SEQ_PTR(_temp_map__12284);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__12284 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 		temp_map_[IN_USE] = 0*/
    _2 = (int)SEQ_PTR(_temp_map__12284);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__12284 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 		temp_map_[KEY_BUCKETS] = repeat({}, length(temp_map_[KEY_BUCKETS]))*/
    _2 = (int)SEQ_PTR(_temp_map__12284);
    _6867 = (int)*(((s1_ptr)_2)->base + 5);
    if (IS_SEQUENCE(_6867)){
            _6868 = SEQ_PTR(_6867)->length;
    }
    else {
        _6868 = 1;
    }
    _6867 = NOVALUE;
    _6869 = Repeat(_5, _6868);
    _6868 = NOVALUE;
    _2 = (int)SEQ_PTR(_temp_map__12284);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__12284 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = _6869;
    if( _1 != _6869 ){
        DeRef(_1);
    }
    _6869 = NOVALUE;

    /** 		temp_map_[VALUE_BUCKETS] = repeat({}, length(temp_map_[VALUE_BUCKETS]))*/
    _2 = (int)SEQ_PTR(_temp_map__12284);
    _6870 = (int)*(((s1_ptr)_2)->base + 6);
    if (IS_SEQUENCE(_6870)){
            _6871 = SEQ_PTR(_6870)->length;
    }
    else {
        _6871 = 1;
    }
    _6870 = NOVALUE;
    _6872 = Repeat(_5, _6871);
    _6871 = NOVALUE;
    _2 = (int)SEQ_PTR(_temp_map__12284);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__12284 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 6);
    _1 = *(int *)_2;
    *(int *)_2 = _6872;
    if( _1 != _6872 ){
        DeRef(_1);
    }
    _6872 = NOVALUE;
    goto L2; // [67] 134
L1: 

    /** 		temp_map_[ELEMENT_COUNT] = 0*/
    _2 = (int)SEQ_PTR(_temp_map__12284);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__12284 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 		temp_map_[IN_USE] = 0*/
    _2 = (int)SEQ_PTR(_temp_map__12284);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__12284 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 		temp_map_[KEY_LIST] = repeat(init_small_map_key, length(temp_map_[KEY_LIST]))*/
    _2 = (int)SEQ_PTR(_temp_map__12284);
    _6873 = (int)*(((s1_ptr)_2)->base + 5);
    if (IS_SEQUENCE(_6873)){
            _6874 = SEQ_PTR(_6873)->length;
    }
    else {
        _6874 = 1;
    }
    _6873 = NOVALUE;
    _6875 = Repeat(_28init_small_map_key_11598, _6874);
    _6874 = NOVALUE;
    _2 = (int)SEQ_PTR(_temp_map__12284);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__12284 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = _6875;
    if( _1 != _6875 ){
        DeRef(_1);
    }
    _6875 = NOVALUE;

    /** 		temp_map_[VALUE_LIST] = repeat(0, length(temp_map_[VALUE_LIST]))*/
    _2 = (int)SEQ_PTR(_temp_map__12284);
    _6876 = (int)*(((s1_ptr)_2)->base + 6);
    if (IS_SEQUENCE(_6876)){
            _6877 = SEQ_PTR(_6876)->length;
    }
    else {
        _6877 = 1;
    }
    _6876 = NOVALUE;
    _6878 = Repeat(0, _6877);
    _6877 = NOVALUE;
    _2 = (int)SEQ_PTR(_temp_map__12284);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__12284 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 6);
    _1 = *(int *)_2;
    *(int *)_2 = _6878;
    if( _1 != _6878 ){
        DeRef(_1);
    }
    _6878 = NOVALUE;

    /** 		temp_map_[FREE_LIST] = repeat(0, length(temp_map_[FREE_LIST]))*/
    _2 = (int)SEQ_PTR(_temp_map__12284);
    _6879 = (int)*(((s1_ptr)_2)->base + 7);
    if (IS_SEQUENCE(_6879)){
            _6880 = SEQ_PTR(_6879)->length;
    }
    else {
        _6880 = 1;
    }
    _6879 = NOVALUE;
    _6881 = Repeat(0, _6880);
    _6880 = NOVALUE;
    _2 = (int)SEQ_PTR(_temp_map__12284);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__12284 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 7);
    _1 = *(int *)_2;
    *(int *)_2 = _6881;
    if( _1 != _6881 ){
        DeRef(_1);
    }
    _6881 = NOVALUE;
L2: 

    /** 	eumem:ram_space[the_map_p] = temp_map_*/
    RefDS(_temp_map__12284);
    _2 = (int)SEQ_PTR(_29ram_space_10710);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29ram_space_10710 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_the_map_p_12283))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_the_map_p_12283)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _the_map_p_12283);
    _1 = *(int *)_2;
    *(int *)_2 = _temp_map__12284;
    DeRef(_1);

    /** end procedure*/
    DeRef(_the_map_p_12283);
    DeRefDS(_temp_map__12284);
    _6867 = NOVALUE;
    _6870 = NOVALUE;
    _6873 = NOVALUE;
    _6876 = NOVALUE;
    _6879 = NOVALUE;
    return;
    ;
}


int _28keys(int _the_map_p_12365, int _sorted_result_12366)
{
    int _buckets__12367 = NOVALUE;
    int _current_bucket__12368 = NOVALUE;
    int _results__12369 = NOVALUE;
    int _pos__12370 = NOVALUE;
    int _temp_map__12371 = NOVALUE;
    int _6939 = NOVALUE;
    int _6937 = NOVALUE;
    int _6936 = NOVALUE;
    int _6934 = NOVALUE;
    int _6933 = NOVALUE;
    int _6932 = NOVALUE;
    int _6931 = NOVALUE;
    int _6929 = NOVALUE;
    int _6928 = NOVALUE;
    int _6927 = NOVALUE;
    int _6926 = NOVALUE;
    int _6924 = NOVALUE;
    int _6922 = NOVALUE;
    int _6919 = NOVALUE;
    int _6917 = NOVALUE;
    int _0, _1, _2;
    

    /** 	temp_map_ = eumem:ram_space[the_map_p]*/
    DeRef(_temp_map__12371);
    _2 = (int)SEQ_PTR(_29ram_space_10710);
    if (!IS_ATOM_INT(_the_map_p_12365)){
        _temp_map__12371 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_the_map_p_12365)->dbl));
    }
    else{
        _temp_map__12371 = (int)*(((s1_ptr)_2)->base + _the_map_p_12365);
    }
    Ref(_temp_map__12371);

    /** 	results_ = repeat(0, temp_map_[ELEMENT_COUNT])*/
    _2 = (int)SEQ_PTR(_temp_map__12371);
    _6917 = (int)*(((s1_ptr)_2)->base + 2);
    DeRef(_results__12369);
    _results__12369 = Repeat(0, _6917);
    _6917 = NOVALUE;

    /** 	pos_ = 1*/
    _pos__12370 = 1;

    /** 	if temp_map_[MAP_TYPE] = LARGEMAP then*/
    _2 = (int)SEQ_PTR(_temp_map__12371);
    _6919 = (int)*(((s1_ptr)_2)->base + 4);
    if (binary_op_a(NOTEQ, _6919, 76)){
        _6919 = NOVALUE;
        goto L1; // [34] 113
    }
    _6919 = NOVALUE;

    /** 		buckets_ = temp_map_[KEY_BUCKETS]*/
    DeRef(_buckets__12367);
    _2 = (int)SEQ_PTR(_temp_map__12371);
    _buckets__12367 = (int)*(((s1_ptr)_2)->base + 5);
    Ref(_buckets__12367);

    /** 		for index = 1 to length(buckets_) do*/
    if (IS_SEQUENCE(_buckets__12367)){
            _6922 = SEQ_PTR(_buckets__12367)->length;
    }
    else {
        _6922 = 1;
    }
    {
        int _index_12380;
        _index_12380 = 1;
L2: 
        if (_index_12380 > _6922){
            goto L3; // [51] 110
        }

        /** 			current_bucket_ = buckets_[index]*/
        DeRef(_current_bucket__12368);
        _2 = (int)SEQ_PTR(_buckets__12367);
        _current_bucket__12368 = (int)*(((s1_ptr)_2)->base + _index_12380);
        Ref(_current_bucket__12368);

        /** 			if length(current_bucket_) > 0 then*/
        if (IS_SEQUENCE(_current_bucket__12368)){
                _6924 = SEQ_PTR(_current_bucket__12368)->length;
        }
        else {
            _6924 = 1;
        }
        if (_6924 <= 0)
        goto L4; // [71] 103

        /** 				results_[pos_ .. pos_ + length(current_bucket_) - 1] = current_bucket_*/
        if (IS_SEQUENCE(_current_bucket__12368)){
                _6926 = SEQ_PTR(_current_bucket__12368)->length;
        }
        else {
            _6926 = 1;
        }
        _6927 = _pos__12370 + _6926;
        if ((long)((unsigned long)_6927 + (unsigned long)HIGH_BITS) >= 0) 
        _6927 = NewDouble((double)_6927);
        _6926 = NOVALUE;
        if (IS_ATOM_INT(_6927)) {
            _6928 = _6927 - 1;
        }
        else {
            _6928 = NewDouble(DBL_PTR(_6927)->dbl - (double)1);
        }
        DeRef(_6927);
        _6927 = NOVALUE;
        assign_slice_seq = (s1_ptr *)&_results__12369;
        AssignSlice(_pos__12370, _6928, _current_bucket__12368);
        DeRef(_6928);
        _6928 = NOVALUE;

        /** 				pos_ += length(current_bucket_)*/
        if (IS_SEQUENCE(_current_bucket__12368)){
                _6929 = SEQ_PTR(_current_bucket__12368)->length;
        }
        else {
            _6929 = 1;
        }
        _pos__12370 = _pos__12370 + _6929;
        _6929 = NOVALUE;
L4: 

        /** 		end for*/
        _index_12380 = _index_12380 + 1;
        goto L2; // [105] 58
L3: 
        ;
    }
    goto L5; // [110] 172
L1: 

    /** 		for index = 1 to length(temp_map_[FREE_LIST]) do*/
    _2 = (int)SEQ_PTR(_temp_map__12371);
    _6931 = (int)*(((s1_ptr)_2)->base + 7);
    if (IS_SEQUENCE(_6931)){
            _6932 = SEQ_PTR(_6931)->length;
    }
    else {
        _6932 = 1;
    }
    _6931 = NOVALUE;
    {
        int _index_12393;
        _index_12393 = 1;
L6: 
        if (_index_12393 > _6932){
            goto L7; // [122] 171
        }

        /** 			if temp_map_[FREE_LIST][index] !=  0 then*/
        _2 = (int)SEQ_PTR(_temp_map__12371);
        _6933 = (int)*(((s1_ptr)_2)->base + 7);
        _2 = (int)SEQ_PTR(_6933);
        _6934 = (int)*(((s1_ptr)_2)->base + _index_12393);
        _6933 = NOVALUE;
        if (binary_op_a(EQUALS, _6934, 0)){
            _6934 = NOVALUE;
            goto L8; // [139] 164
        }
        _6934 = NOVALUE;

        /** 				results_[pos_] = temp_map_[KEY_LIST][index]*/
        _2 = (int)SEQ_PTR(_temp_map__12371);
        _6936 = (int)*(((s1_ptr)_2)->base + 5);
        _2 = (int)SEQ_PTR(_6936);
        _6937 = (int)*(((s1_ptr)_2)->base + _index_12393);
        _6936 = NOVALUE;
        Ref(_6937);
        _2 = (int)SEQ_PTR(_results__12369);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _results__12369 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _pos__12370);
        _1 = *(int *)_2;
        *(int *)_2 = _6937;
        if( _1 != _6937 ){
            DeRef(_1);
        }
        _6937 = NOVALUE;

        /** 				pos_ += 1*/
        _pos__12370 = _pos__12370 + 1;
L8: 

        /** 		end for*/
        _index_12393 = _index_12393 + 1;
        goto L6; // [166] 129
L7: 
        ;
    }
L5: 

    /** 	if sorted_result then*/
    if (_sorted_result_12366 == 0)
    {
        goto L9; // [174] 191
    }
    else{
    }

    /** 		return stdsort:sort(results_)*/
    RefDS(_results__12369);
    _6939 = _24sort(_results__12369, 1);
    DeRef(_the_map_p_12365);
    DeRef(_buckets__12367);
    DeRef(_current_bucket__12368);
    DeRefDS(_results__12369);
    DeRef(_temp_map__12371);
    _6931 = NOVALUE;
    return _6939;
    goto LA; // [188] 198
L9: 

    /** 		return results_*/
    DeRef(_the_map_p_12365);
    DeRef(_buckets__12367);
    DeRef(_current_bucket__12368);
    DeRef(_temp_map__12371);
    _6931 = NOVALUE;
    DeRef(_6939);
    _6939 = NOVALUE;
    return _results__12369;
LA: 
    ;
}


int _28values(int _the_map_12408, int _keys_12409, int _default_values_12410)
{
    int _buckets__12434 = NOVALUE;
    int _bucket__12435 = NOVALUE;
    int _results__12436 = NOVALUE;
    int _pos__12437 = NOVALUE;
    int _temp_map__12438 = NOVALUE;
    int _6979 = NOVALUE;
    int _6978 = NOVALUE;
    int _6976 = NOVALUE;
    int _6975 = NOVALUE;
    int _6974 = NOVALUE;
    int _6973 = NOVALUE;
    int _6971 = NOVALUE;
    int _6970 = NOVALUE;
    int _6969 = NOVALUE;
    int _6968 = NOVALUE;
    int _6966 = NOVALUE;
    int _6964 = NOVALUE;
    int _6961 = NOVALUE;
    int _6959 = NOVALUE;
    int _6957 = NOVALUE;
    int _6956 = NOVALUE;
    int _6955 = NOVALUE;
    int _6954 = NOVALUE;
    int _6952 = NOVALUE;
    int _6951 = NOVALUE;
    int _6950 = NOVALUE;
    int _6949 = NOVALUE;
    int _6948 = NOVALUE;
    int _6947 = NOVALUE;
    int _6945 = NOVALUE;
    int _6944 = NOVALUE;
    int _6942 = NOVALUE;
    int _6941 = NOVALUE;
    int _6940 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if sequence(keys) then*/
    _6940 = 0;
    if (_6940 == 0)
    {
        _6940 = NOVALUE;
        goto L1; // [6] 116
    }
    else{
        _6940 = NOVALUE;
    }

    /** 		if atom(default_values) then*/
    _6941 = 1;
    if (_6941 == 0)
    {
        _6941 = NOVALUE;
        goto L2; // [14] 29
    }
    else{
        _6941 = NOVALUE;
    }

    /** 			default_values = repeat(default_values, length(keys))*/
    _6942 = 1;
    _default_values_12410 = Repeat(0, 1);
    _6942 = NOVALUE;
    goto L3; // [26] 70
L2: 

    /** 		elsif length(default_values) < length(keys) then*/
    if (IS_SEQUENCE(_default_values_12410)){
            _6944 = SEQ_PTR(_default_values_12410)->length;
    }
    else {
        _6944 = 1;
    }
    if (IS_SEQUENCE(_keys_12409)){
            _6945 = SEQ_PTR(_keys_12409)->length;
    }
    else {
        _6945 = 1;
    }
    if (_6944 >= _6945)
    goto L4; // [37] 69

    /** 			default_values &= repeat(default_values[$], length(keys) - length(default_values))*/
    if (IS_SEQUENCE(_default_values_12410)){
            _6947 = SEQ_PTR(_default_values_12410)->length;
    }
    else {
        _6947 = 1;
    }
    _2 = (int)SEQ_PTR(_default_values_12410);
    _6948 = (int)*(((s1_ptr)_2)->base + _6947);
    if (IS_SEQUENCE(_keys_12409)){
            _6949 = SEQ_PTR(_keys_12409)->length;
    }
    else {
        _6949 = 1;
    }
    if (IS_SEQUENCE(_default_values_12410)){
            _6950 = SEQ_PTR(_default_values_12410)->length;
    }
    else {
        _6950 = 1;
    }
    _6951 = _6949 - _6950;
    _6949 = NOVALUE;
    _6950 = NOVALUE;
    _6952 = Repeat(_6948, _6951);
    _6948 = NOVALUE;
    _6951 = NOVALUE;
    if (IS_SEQUENCE(_default_values_12410) && IS_ATOM(_6952)) {
    }
    else if (IS_ATOM(_default_values_12410) && IS_SEQUENCE(_6952)) {
        Ref(_default_values_12410);
        Prepend(&_default_values_12410, _6952, _default_values_12410);
    }
    else {
        Concat((object_ptr)&_default_values_12410, _default_values_12410, _6952);
    }
    DeRefDS(_6952);
    _6952 = NOVALUE;
L4: 
L3: 

    /** 		for i = 1 to length(keys) do*/
    if (IS_SEQUENCE(_keys_12409)){
            _6954 = SEQ_PTR(_keys_12409)->length;
    }
    else {
        _6954 = 1;
    }
    {
        int _i_12429;
        _i_12429 = 1;
L5: 
        if (_i_12429 > _6954){
            goto L6; // [75] 109
        }

        /** 			keys[i] = get(the_map, keys[i], default_values[i])*/
        _2 = (int)SEQ_PTR(_keys_12409);
        _6955 = (int)*(((s1_ptr)_2)->base + _i_12429);
        _2 = (int)SEQ_PTR(_default_values_12410);
        _6956 = (int)*(((s1_ptr)_2)->base + _i_12429);
        Ref(_6955);
        Ref(_6956);
        _6957 = _28get(_the_map_12408, _6955, _6956);
        _6955 = NOVALUE;
        _6956 = NOVALUE;
        _2 = (int)SEQ_PTR(_keys_12409);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _keys_12409 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_12429);
        _1 = *(int *)_2;
        *(int *)_2 = _6957;
        if( _1 != _6957 ){
            DeRef(_1);
        }
        _6957 = NOVALUE;

        /** 		end for*/
        _i_12429 = _i_12429 + 1;
        goto L5; // [104] 82
L6: 
        ;
    }

    /** 		return keys*/
    DeRef(_default_values_12410);
    DeRef(_buckets__12434);
    DeRef(_bucket__12435);
    DeRef(_results__12436);
    DeRef(_temp_map__12438);
    return _keys_12409;
L1: 

    /** 	sequence buckets_*/

    /** 	sequence bucket_*/

    /** 	sequence results_*/

    /** 	integer pos_*/

    /** 	sequence temp_map_*/

    /** 	temp_map_ = eumem:ram_space[the_map]*/
    DeRef(_temp_map__12438);
    _2 = (int)SEQ_PTR(_29ram_space_10710);
    _temp_map__12438 = (int)*(((s1_ptr)_2)->base + _the_map_12408);
    Ref(_temp_map__12438);

    /** 	results_ = repeat(0, temp_map_[ELEMENT_COUNT])*/
    _2 = (int)SEQ_PTR(_temp_map__12438);
    _6959 = (int)*(((s1_ptr)_2)->base + 2);
    DeRef(_results__12436);
    _results__12436 = Repeat(0, _6959);
    _6959 = NOVALUE;

    /** 	pos_ = 1*/
    _pos__12437 = 1;

    /** 	if temp_map_[MAP_TYPE] = LARGEMAP then*/
    _2 = (int)SEQ_PTR(_temp_map__12438);
    _6961 = (int)*(((s1_ptr)_2)->base + 4);
    if (binary_op_a(NOTEQ, _6961, 76)){
        _6961 = NOVALUE;
        goto L7; // [157] 236
    }
    _6961 = NOVALUE;

    /** 		buckets_ = temp_map_[VALUE_BUCKETS]*/
    DeRef(_buckets__12434);
    _2 = (int)SEQ_PTR(_temp_map__12438);
    _buckets__12434 = (int)*(((s1_ptr)_2)->base + 6);
    Ref(_buckets__12434);

    /** 		for index = 1 to length(buckets_) do*/
    if (IS_SEQUENCE(_buckets__12434)){
            _6964 = SEQ_PTR(_buckets__12434)->length;
    }
    else {
        _6964 = 1;
    }
    {
        int _index_12447;
        _index_12447 = 1;
L8: 
        if (_index_12447 > _6964){
            goto L9; // [174] 233
        }

        /** 			bucket_ = buckets_[index]*/
        DeRef(_bucket__12435);
        _2 = (int)SEQ_PTR(_buckets__12434);
        _bucket__12435 = (int)*(((s1_ptr)_2)->base + _index_12447);
        Ref(_bucket__12435);

        /** 			if length(bucket_) > 0 then*/
        if (IS_SEQUENCE(_bucket__12435)){
                _6966 = SEQ_PTR(_bucket__12435)->length;
        }
        else {
            _6966 = 1;
        }
        if (_6966 <= 0)
        goto LA; // [194] 226

        /** 				results_[pos_ .. pos_ + length(bucket_) - 1] = bucket_*/
        if (IS_SEQUENCE(_bucket__12435)){
                _6968 = SEQ_PTR(_bucket__12435)->length;
        }
        else {
            _6968 = 1;
        }
        _6969 = _pos__12437 + _6968;
        if ((long)((unsigned long)_6969 + (unsigned long)HIGH_BITS) >= 0) 
        _6969 = NewDouble((double)_6969);
        _6968 = NOVALUE;
        if (IS_ATOM_INT(_6969)) {
            _6970 = _6969 - 1;
        }
        else {
            _6970 = NewDouble(DBL_PTR(_6969)->dbl - (double)1);
        }
        DeRef(_6969);
        _6969 = NOVALUE;
        assign_slice_seq = (s1_ptr *)&_results__12436;
        AssignSlice(_pos__12437, _6970, _bucket__12435);
        DeRef(_6970);
        _6970 = NOVALUE;

        /** 				pos_ += length(bucket_)*/
        if (IS_SEQUENCE(_bucket__12435)){
                _6971 = SEQ_PTR(_bucket__12435)->length;
        }
        else {
            _6971 = 1;
        }
        _pos__12437 = _pos__12437 + _6971;
        _6971 = NOVALUE;
LA: 

        /** 		end for*/
        _index_12447 = _index_12447 + 1;
        goto L8; // [228] 181
L9: 
        ;
    }
    goto LB; // [233] 295
L7: 

    /** 		for index = 1 to length(temp_map_[FREE_LIST]) do*/
    _2 = (int)SEQ_PTR(_temp_map__12438);
    _6973 = (int)*(((s1_ptr)_2)->base + 7);
    if (IS_SEQUENCE(_6973)){
            _6974 = SEQ_PTR(_6973)->length;
    }
    else {
        _6974 = 1;
    }
    _6973 = NOVALUE;
    {
        int _index_12460;
        _index_12460 = 1;
LC: 
        if (_index_12460 > _6974){
            goto LD; // [245] 294
        }

        /** 			if temp_map_[FREE_LIST][index] !=  0 then*/
        _2 = (int)SEQ_PTR(_temp_map__12438);
        _6975 = (int)*(((s1_ptr)_2)->base + 7);
        _2 = (int)SEQ_PTR(_6975);
        _6976 = (int)*(((s1_ptr)_2)->base + _index_12460);
        _6975 = NOVALUE;
        if (binary_op_a(EQUALS, _6976, 0)){
            _6976 = NOVALUE;
            goto LE; // [262] 287
        }
        _6976 = NOVALUE;

        /** 				results_[pos_] = temp_map_[VALUE_LIST][index]*/
        _2 = (int)SEQ_PTR(_temp_map__12438);
        _6978 = (int)*(((s1_ptr)_2)->base + 6);
        _2 = (int)SEQ_PTR(_6978);
        _6979 = (int)*(((s1_ptr)_2)->base + _index_12460);
        _6978 = NOVALUE;
        Ref(_6979);
        _2 = (int)SEQ_PTR(_results__12436);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _results__12436 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _pos__12437);
        _1 = *(int *)_2;
        *(int *)_2 = _6979;
        if( _1 != _6979 ){
            DeRef(_1);
        }
        _6979 = NOVALUE;

        /** 				pos_ += 1*/
        _pos__12437 = _pos__12437 + 1;
LE: 

        /** 		end for*/
        _index_12460 = _index_12460 + 1;
        goto LC; // [289] 252
LD: 
        ;
    }
LB: 

    /** 	return results_*/
    DeRef(_keys_12409);
    DeRef(_default_values_12410);
    DeRef(_buckets__12434);
    DeRef(_bucket__12435);
    DeRef(_temp_map__12438);
    _6973 = NOVALUE;
    return _results__12436;
    ;
}


int _28pairs(int _the_map_p_12472, int _sorted_result_12473)
{
    int _key_bucket__12474 = NOVALUE;
    int _value_bucket__12475 = NOVALUE;
    int _results__12476 = NOVALUE;
    int _pos__12477 = NOVALUE;
    int _temp_map__12478 = NOVALUE;
    int _7015 = NOVALUE;
    int _7013 = NOVALUE;
    int _7012 = NOVALUE;
    int _7010 = NOVALUE;
    int _7009 = NOVALUE;
    int _7008 = NOVALUE;
    int _7006 = NOVALUE;
    int _7004 = NOVALUE;
    int _7003 = NOVALUE;
    int _7002 = NOVALUE;
    int _7001 = NOVALUE;
    int _6999 = NOVALUE;
    int _6997 = NOVALUE;
    int _6996 = NOVALUE;
    int _6994 = NOVALUE;
    int _6993 = NOVALUE;
    int _6991 = NOVALUE;
    int _6989 = NOVALUE;
    int _6988 = NOVALUE;
    int _6987 = NOVALUE;
    int _6985 = NOVALUE;
    int _6983 = NOVALUE;
    int _6982 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	temp_map_ = eumem:ram_space[the_map_p]*/
    DeRef(_temp_map__12478);
    _2 = (int)SEQ_PTR(_29ram_space_10710);
    if (!IS_ATOM_INT(_the_map_p_12472)){
        _temp_map__12478 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_the_map_p_12472)->dbl));
    }
    else{
        _temp_map__12478 = (int)*(((s1_ptr)_2)->base + _the_map_p_12472);
    }
    Ref(_temp_map__12478);

    /** 	results_ = repeat({ 0, 0 }, temp_map_[ELEMENT_COUNT])*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = 0;
    _6982 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_temp_map__12478);
    _6983 = (int)*(((s1_ptr)_2)->base + 2);
    DeRef(_results__12476);
    _results__12476 = Repeat(_6982, _6983);
    DeRefDS(_6982);
    _6982 = NOVALUE;
    _6983 = NOVALUE;

    /** 	pos_ = 1*/
    _pos__12477 = 1;

    /** 	if temp_map_[MAP_TYPE] = LARGEMAP then*/
    _2 = (int)SEQ_PTR(_temp_map__12478);
    _6985 = (int)*(((s1_ptr)_2)->base + 4);
    if (binary_op_a(NOTEQ, _6985, 76)){
        _6985 = NOVALUE;
        goto L1; // [38] 147
    }
    _6985 = NOVALUE;

    /** 		for index = 1 to length(temp_map_[KEY_BUCKETS]) do*/
    _2 = (int)SEQ_PTR(_temp_map__12478);
    _6987 = (int)*(((s1_ptr)_2)->base + 5);
    if (IS_SEQUENCE(_6987)){
            _6988 = SEQ_PTR(_6987)->length;
    }
    else {
        _6988 = 1;
    }
    _6987 = NOVALUE;
    {
        int _index_12487;
        _index_12487 = 1;
L2: 
        if (_index_12487 > _6988){
            goto L3; // [51] 144
        }

        /** 			key_bucket_ = temp_map_[KEY_BUCKETS][index]*/
        _2 = (int)SEQ_PTR(_temp_map__12478);
        _6989 = (int)*(((s1_ptr)_2)->base + 5);
        DeRef(_key_bucket__12474);
        _2 = (int)SEQ_PTR(_6989);
        _key_bucket__12474 = (int)*(((s1_ptr)_2)->base + _index_12487);
        Ref(_key_bucket__12474);
        _6989 = NOVALUE;

        /** 			value_bucket_ = temp_map_[VALUE_BUCKETS][index]*/
        _2 = (int)SEQ_PTR(_temp_map__12478);
        _6991 = (int)*(((s1_ptr)_2)->base + 6);
        DeRef(_value_bucket__12475);
        _2 = (int)SEQ_PTR(_6991);
        _value_bucket__12475 = (int)*(((s1_ptr)_2)->base + _index_12487);
        Ref(_value_bucket__12475);
        _6991 = NOVALUE;

        /** 			for j = 1 to length(key_bucket_) do*/
        if (IS_SEQUENCE(_key_bucket__12474)){
                _6993 = SEQ_PTR(_key_bucket__12474)->length;
        }
        else {
            _6993 = 1;
        }
        {
            int _j_12495;
            _j_12495 = 1;
L4: 
            if (_j_12495 > _6993){
                goto L5; // [87] 137
            }

            /** 				results_[pos_][1] = key_bucket_[j]*/
            _2 = (int)SEQ_PTR(_results__12476);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _results__12476 = MAKE_SEQ(_2);
            }
            _3 = (int)(_pos__12477 + ((s1_ptr)_2)->base);
            _2 = (int)SEQ_PTR(_key_bucket__12474);
            _6996 = (int)*(((s1_ptr)_2)->base + _j_12495);
            Ref(_6996);
            _2 = (int)SEQ_PTR(*(int *)_3);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                *(int *)_3 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + 1);
            _1 = *(int *)_2;
            *(int *)_2 = _6996;
            if( _1 != _6996 ){
                DeRef(_1);
            }
            _6996 = NOVALUE;
            _6994 = NOVALUE;

            /** 				results_[pos_][2] = value_bucket_[j]*/
            _2 = (int)SEQ_PTR(_results__12476);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _results__12476 = MAKE_SEQ(_2);
            }
            _3 = (int)(_pos__12477 + ((s1_ptr)_2)->base);
            _2 = (int)SEQ_PTR(_value_bucket__12475);
            _6999 = (int)*(((s1_ptr)_2)->base + _j_12495);
            Ref(_6999);
            _2 = (int)SEQ_PTR(*(int *)_3);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                *(int *)_3 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + 2);
            _1 = *(int *)_2;
            *(int *)_2 = _6999;
            if( _1 != _6999 ){
                DeRef(_1);
            }
            _6999 = NOVALUE;
            _6997 = NOVALUE;

            /** 				pos_ += 1*/
            _pos__12477 = _pos__12477 + 1;

            /** 			end for*/
            _j_12495 = _j_12495 + 1;
            goto L4; // [132] 94
L5: 
            ;
        }

        /** 		end for*/
        _index_12487 = _index_12487 + 1;
        goto L2; // [139] 58
L3: 
        ;
    }
    goto L6; // [144] 230
L1: 

    /** 		for index = 1 to length(temp_map_[FREE_LIST]) do*/
    _2 = (int)SEQ_PTR(_temp_map__12478);
    _7001 = (int)*(((s1_ptr)_2)->base + 7);
    if (IS_SEQUENCE(_7001)){
            _7002 = SEQ_PTR(_7001)->length;
    }
    else {
        _7002 = 1;
    }
    _7001 = NOVALUE;
    {
        int _index_12506;
        _index_12506 = 1;
L7: 
        if (_index_12506 > _7002){
            goto L8; // [156] 229
        }

        /** 			if temp_map_[FREE_LIST][index] !=  0 then*/
        _2 = (int)SEQ_PTR(_temp_map__12478);
        _7003 = (int)*(((s1_ptr)_2)->base + 7);
        _2 = (int)SEQ_PTR(_7003);
        _7004 = (int)*(((s1_ptr)_2)->base + _index_12506);
        _7003 = NOVALUE;
        if (binary_op_a(EQUALS, _7004, 0)){
            _7004 = NOVALUE;
            goto L9; // [173] 222
        }
        _7004 = NOVALUE;

        /** 				results_[pos_][1] = temp_map_[KEY_LIST][index]*/
        _2 = (int)SEQ_PTR(_results__12476);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _results__12476 = MAKE_SEQ(_2);
        }
        _3 = (int)(_pos__12477 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(_temp_map__12478);
        _7008 = (int)*(((s1_ptr)_2)->base + 5);
        _2 = (int)SEQ_PTR(_7008);
        _7009 = (int)*(((s1_ptr)_2)->base + _index_12506);
        _7008 = NOVALUE;
        Ref(_7009);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 1);
        _1 = *(int *)_2;
        *(int *)_2 = _7009;
        if( _1 != _7009 ){
            DeRef(_1);
        }
        _7009 = NOVALUE;
        _7006 = NOVALUE;

        /** 				results_[pos_][2] = temp_map_[VALUE_LIST][index]*/
        _2 = (int)SEQ_PTR(_results__12476);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _results__12476 = MAKE_SEQ(_2);
        }
        _3 = (int)(_pos__12477 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(_temp_map__12478);
        _7012 = (int)*(((s1_ptr)_2)->base + 6);
        _2 = (int)SEQ_PTR(_7012);
        _7013 = (int)*(((s1_ptr)_2)->base + _index_12506);
        _7012 = NOVALUE;
        Ref(_7013);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 2);
        _1 = *(int *)_2;
        *(int *)_2 = _7013;
        if( _1 != _7013 ){
            DeRef(_1);
        }
        _7013 = NOVALUE;
        _7010 = NOVALUE;

        /** 				pos_ += 1*/
        _pos__12477 = _pos__12477 + 1;
L9: 

        /** 		end for	*/
        _index_12506 = _index_12506 + 1;
        goto L7; // [224] 163
L8: 
        ;
    }
L6: 

    /** 	if sorted_result then*/
    if (_sorted_result_12473 == 0)
    {
        goto LA; // [232] 249
    }
    else{
    }

    /** 		return stdsort:sort(results_)*/
    RefDS(_results__12476);
    _7015 = _24sort(_results__12476, 1);
    DeRef(_the_map_p_12472);
    DeRef(_key_bucket__12474);
    DeRef(_value_bucket__12475);
    DeRefDS(_results__12476);
    DeRef(_temp_map__12478);
    _6987 = NOVALUE;
    _7001 = NOVALUE;
    return _7015;
    goto LB; // [246] 256
LA: 

    /** 		return results_*/
    DeRef(_the_map_p_12472);
    DeRef(_key_bucket__12474);
    DeRef(_value_bucket__12475);
    DeRef(_temp_map__12478);
    _6987 = NOVALUE;
    _7001 = NOVALUE;
    DeRef(_7015);
    _7015 = NOVALUE;
    return _results__12476;
LB: 
    ;
}


void _28convert_to_large_map(int _the_map__12864)
{
    int _temp_map__12865 = NOVALUE;
    int _map_handle__12866 = NOVALUE;
    int _7219 = NOVALUE;
    int _7218 = NOVALUE;
    int _7217 = NOVALUE;
    int _7216 = NOVALUE;
    int _7215 = NOVALUE;
    int _7213 = NOVALUE;
    int _7212 = NOVALUE;
    int _7211 = NOVALUE;
    int _7210 = NOVALUE;
    int _0, _1, _2;
    

    /** 	temp_map_ = eumem:ram_space[the_map_]*/
    DeRef(_temp_map__12865);
    _2 = (int)SEQ_PTR(_29ram_space_10710);
    _temp_map__12865 = (int)*(((s1_ptr)_2)->base + _the_map__12864);
    Ref(_temp_map__12865);

    /** 	map_handle_ = new()*/
    _0 = _map_handle__12866;
    _map_handle__12866 = _28new(690);
    DeRef(_0);

    /** 	for index = 1 to length(temp_map_[FREE_LIST]) do*/
    _2 = (int)SEQ_PTR(_temp_map__12865);
    _7210 = (int)*(((s1_ptr)_2)->base + 7);
    if (IS_SEQUENCE(_7210)){
            _7211 = SEQ_PTR(_7210)->length;
    }
    else {
        _7211 = 1;
    }
    _7210 = NOVALUE;
    {
        int _index_12870;
        _index_12870 = 1;
L1: 
        if (_index_12870 > _7211){
            goto L2; // [28] 84
        }

        /** 		if temp_map_[FREE_LIST][index] !=  0 then*/
        _2 = (int)SEQ_PTR(_temp_map__12865);
        _7212 = (int)*(((s1_ptr)_2)->base + 7);
        _2 = (int)SEQ_PTR(_7212);
        _7213 = (int)*(((s1_ptr)_2)->base + _index_12870);
        _7212 = NOVALUE;
        if (binary_op_a(EQUALS, _7213, 0)){
            _7213 = NOVALUE;
            goto L3; // [45] 77
        }
        _7213 = NOVALUE;

        /** 			put(map_handle_, temp_map_[KEY_LIST][index], temp_map_[VALUE_LIST][index])*/
        _2 = (int)SEQ_PTR(_temp_map__12865);
        _7215 = (int)*(((s1_ptr)_2)->base + 5);
        _2 = (int)SEQ_PTR(_7215);
        _7216 = (int)*(((s1_ptr)_2)->base + _index_12870);
        _7215 = NOVALUE;
        _2 = (int)SEQ_PTR(_temp_map__12865);
        _7217 = (int)*(((s1_ptr)_2)->base + 6);
        _2 = (int)SEQ_PTR(_7217);
        _7218 = (int)*(((s1_ptr)_2)->base + _index_12870);
        _7217 = NOVALUE;
        Ref(_map_handle__12866);
        Ref(_7216);
        Ref(_7218);
        _28put(_map_handle__12866, _7216, _7218, 1, 23);
        _7216 = NOVALUE;
        _7218 = NOVALUE;
L3: 

        /** 	end for*/
        _index_12870 = _index_12870 + 1;
        goto L1; // [79] 35
L2: 
        ;
    }

    /** 	eumem:ram_space[the_map_] = eumem:ram_space[map_handle_]*/
    _2 = (int)SEQ_PTR(_29ram_space_10710);
    if (!IS_ATOM_INT(_map_handle__12866)){
        _7219 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_map_handle__12866)->dbl));
    }
    else{
        _7219 = (int)*(((s1_ptr)_2)->base + _map_handle__12866);
    }
    Ref(_7219);
    _2 = (int)SEQ_PTR(_29ram_space_10710);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29ram_space_10710 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _the_map__12864);
    _1 = *(int *)_2;
    *(int *)_2 = _7219;
    if( _1 != _7219 ){
        DeRef(_1);
    }
    _7219 = NOVALUE;

    /** end procedure*/
    DeRef(_temp_map__12865);
    DeRef(_map_handle__12866);
    _7210 = NOVALUE;
    return;
    ;
}


void _28convert_to_small_map(int _the_map__12884)
{
    int _keys__12885 = NOVALUE;
    int _values__12886 = NOVALUE;
    int _7228 = NOVALUE;
    int _7227 = NOVALUE;
    int _7226 = NOVALUE;
    int _7225 = NOVALUE;
    int _7224 = NOVALUE;
    int _7223 = NOVALUE;
    int _7222 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_the_map__12884)) {
        _1 = (long)(DBL_PTR(_the_map__12884)->dbl);
        DeRefDS(_the_map__12884);
        _the_map__12884 = _1;
    }

    /** 	keys_ = keys(the_map_)*/
    _0 = _keys__12885;
    _keys__12885 = _28keys(_the_map__12884, 0);
    DeRef(_0);

    /** 	values_ = values(the_map_)*/
    _0 = _values__12886;
    _values__12886 = _28values(_the_map__12884, 0, 0);
    DeRef(_0);

    /** 	eumem:ram_space[the_map_] = {*/
    _7222 = Repeat(_28init_small_map_key_11598, 23);
    _7223 = Repeat(0, 23);
    _7224 = Repeat(0, 23);
    _1 = NewS1(7);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_28type_is_map_11582);
    *((int *)(_2+4)) = _28type_is_map_11582;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = 0;
    *((int *)(_2+16)) = 115;
    *((int *)(_2+20)) = _7222;
    *((int *)(_2+24)) = _7223;
    *((int *)(_2+28)) = _7224;
    _7225 = MAKE_SEQ(_1);
    _7224 = NOVALUE;
    _7223 = NOVALUE;
    _7222 = NOVALUE;
    _2 = (int)SEQ_PTR(_29ram_space_10710);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29ram_space_10710 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _the_map__12884);
    _1 = *(int *)_2;
    *(int *)_2 = _7225;
    if( _1 != _7225 ){
        DeRef(_1);
    }
    _7225 = NOVALUE;

    /** 	for i = 1 to length(keys_) do*/
    if (IS_SEQUENCE(_keys__12885)){
            _7226 = SEQ_PTR(_keys__12885)->length;
    }
    else {
        _7226 = 1;
    }
    {
        int _i_12894;
        _i_12894 = 1;
L1: 
        if (_i_12894 > _7226){
            goto L2; // [63] 94
        }

        /** 		put(the_map_, keys_[i], values_[i], PUT, 0)*/
        _2 = (int)SEQ_PTR(_keys__12885);
        _7227 = (int)*(((s1_ptr)_2)->base + _i_12894);
        _2 = (int)SEQ_PTR(_values__12886);
        _7228 = (int)*(((s1_ptr)_2)->base + _i_12894);
        Ref(_7227);
        Ref(_7228);
        _28put(_the_map__12884, _7227, _7228, 1, 0);
        _7227 = NOVALUE;
        _7228 = NOVALUE;

        /** 	end for*/
        _i_12894 = _i_12894 + 1;
        goto L1; // [89] 70
L2: 
        ;
    }

    /** end procedure*/
    DeRef(_keys__12885);
    DeRef(_values__12886);
    return;
    ;
}



// 0x5C701BCA
