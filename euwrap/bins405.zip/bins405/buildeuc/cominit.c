// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

void _43add_options(int _new_options_48963)
{
    int _0, _1, _2;
    

    /** 	options = splice(options, new_options, COMMON_OPTIONS_SPLICE_IDX)*/
    {
        s1_ptr assign_space;
        insert_pos = 15;
        if (insert_pos <= 0) {
            Concat(&_43options_48959,_new_options_48963,_43options_48959);
        }
        else if (insert_pos > SEQ_PTR(_43options_48959)->length){
            Concat(&_43options_48959,_43options_48959,_new_options_48963);
        }
        else if (IS_SEQUENCE(_new_options_48963)) {
            if( _43options_48959 != _43options_48959 || SEQ_PTR( _43options_48959 )->ref != 1 ){
                DeRef( _43options_48959 );
                RefDS( _43options_48959 );
            }
            assign_space = Add_internal_space( _43options_48959, insert_pos,((s1_ptr)SEQ_PTR(_new_options_48963))->length);
            assign_slice_seq = &assign_space;
            assign_space = Copy_elements( insert_pos, SEQ_PTR(_new_options_48963), _43options_48959 == _43options_48959 );
            _43options_48959 = MAKE_SEQ( assign_space );
        }
        else {
            if( _43options_48959 != _43options_48959 && SEQ_PTR( _43options_48959 )->ref != 1 ){
                _43options_48959 = Insert( _43options_48959, _new_options_48963, insert_pos);
            }
            else {
                DeRef( _43options_48959 );
                RefDS( _43options_48959 );
                _43options_48959 = Insert( _43options_48959, _new_options_48963, insert_pos);
            }
        }
    }

    /** end procedure*/
    DeRefDS(_new_options_48963);
    return;
    ;
}


int _43get_options()
{
    int _0, _1, _2;
    

    /** 	return options*/
    RefDS(_43options_48959);
    return _43options_48959;
    ;
}


int _43get_common_options()
{
    int _0, _1, _2;
    

    /** 	return COMMON_OPTIONS*/
    RefDS(_43COMMON_OPTIONS_48857);
    return _43COMMON_OPTIONS_48857;
    ;
}


int _43get_switches()
{
    int _0, _1, _2;
    

    /** 	return switches*/
    RefDS(_43switches_48856);
    return _43switches_48856;
    ;
}


void _43show_copyrights()
{
    int _notices_48973 = NOVALUE;
    int _25587 = NOVALUE;
    int _25586 = NOVALUE;
    int _25584 = NOVALUE;
    int _25583 = NOVALUE;
    int _25582 = NOVALUE;
    int _25581 = NOVALUE;
    int _25579 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence notices = all_copyrights()*/
    _0 = _notices_48973;
    _notices_48973 = _32all_copyrights();
    DeRef(_0);

    /** 	for i = 1 to length(notices) do*/
    if (IS_SEQUENCE(_notices_48973)){
            _25579 = SEQ_PTR(_notices_48973)->length;
    }
    else {
        _25579 = 1;
    }
    {
        int _i_48977;
        _i_48977 = 1;
L1: 
        if (_i_48977 > _25579){
            goto L2; // [13] 60
        }

        /** 		printf(2, "%s\n  %s\n\n", { notices[i][1], match_replace("\n", notices[i][2], "\n  ") })*/
        _2 = (int)SEQ_PTR(_notices_48973);
        _25581 = (int)*(((s1_ptr)_2)->base + _i_48977);
        _2 = (int)SEQ_PTR(_25581);
        _25582 = (int)*(((s1_ptr)_2)->base + 1);
        _25581 = NOVALUE;
        _2 = (int)SEQ_PTR(_notices_48973);
        _25583 = (int)*(((s1_ptr)_2)->base + _i_48977);
        _2 = (int)SEQ_PTR(_25583);
        _25584 = (int)*(((s1_ptr)_2)->base + 2);
        _25583 = NOVALUE;
        RefDS(_22175);
        Ref(_25584);
        RefDS(_25585);
        _25586 = _16match_replace(_22175, _25584, _25585, 0);
        _25584 = NOVALUE;
        Ref(_25582);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _25582;
        ((int *)_2)[2] = _25586;
        _25587 = MAKE_SEQ(_1);
        _25586 = NOVALUE;
        _25582 = NOVALUE;
        EPrintf(2, _25580, _25587);
        DeRefDS(_25587);
        _25587 = NOVALUE;

        /** 	end for*/
        _i_48977 = _i_48977 + 1;
        goto L1; // [55] 20
L2: 
        ;
    }

    /** end procedure*/
    DeRef(_notices_48973);
    return;
    ;
}


void _43show_banner()
{
    int _version_type_inlined_version_type_at_206_49040 = NOVALUE;
    int _version_string_short_1__tmp_at190_49038 = NOVALUE;
    int _version_string_short_inlined_version_string_short_at_190_49037 = NOVALUE;
    int _version_revision_inlined_version_revision_at_121_49019 = NOVALUE;
    int _platform_name_inlined_platform_name_at_83_49011 = NOVALUE;
    int _prod_name_48990 = NOVALUE;
    int _memory_type_48991 = NOVALUE;
    int _misc_info_49009 = NOVALUE;
    int _EuConsole_49023 = NOVALUE;
    int _25611 = NOVALUE;
    int _25610 = NOVALUE;
    int _25609 = NOVALUE;
    int _25606 = NOVALUE;
    int _25605 = NOVALUE;
    int _25601 = NOVALUE;
    int _25600 = NOVALUE;
    int _25599 = NOVALUE;
    int _25597 = NOVALUE;
    int _25595 = NOVALUE;
    int _25594 = NOVALUE;
    int _25589 = NOVALUE;
    int _25588 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if INTERPRET and not BIND then*/
    if (_35INTERPRET_15884 == 0) {
        goto L1; // [5] 31
    }
    _25589 = (_35BIND_15890 == 0);
    if (_25589 == 0)
    {
        DeRef(_25589);
        _25589 = NOVALUE;
        goto L1; // [15] 31
    }
    else{
        DeRef(_25589);
        _25589 = NOVALUE;
    }

    /** 		prod_name = GetMsgText(270,0)*/
    RefDS(_22023);
    _0 = _prod_name_48990;
    _prod_name_48990 = _45GetMsgText(270, 0, _22023);
    DeRef(_0);
    goto L2; // [28] 70
L1: 

    /** 	elsif TRANSLATE then*/
    if (_35TRANSLATE_15887 == 0)
    {
        goto L3; // [35] 51
    }
    else{
    }

    /** 		prod_name = GetMsgText(271,0)*/
    RefDS(_22023);
    _0 = _prod_name_48990;
    _prod_name_48990 = _45GetMsgText(271, 0, _22023);
    DeRef(_0);
    goto L2; // [48] 70
L3: 

    /** 	elsif BIND then*/
    if (_35BIND_15890 == 0)
    {
        goto L4; // [55] 69
    }
    else{
    }

    /** 		prod_name = GetMsgText(272,0)*/
    RefDS(_22023);
    _0 = _prod_name_48990;
    _prod_name_48990 = _45GetMsgText(272, 0, _22023);
    DeRef(_0);
L4: 
L2: 

    /** 	ifdef EU_MANAGED_MEM then*/

    /** 		memory_type = GetMsgText(274,0)*/
    RefDS(_22023);
    _0 = _memory_type_48991;
    _memory_type_48991 = _45GetMsgText(274, 0, _22023);
    DeRef(_0);

    /** 	sequence misc_info = {*/

    /** 	ifdef WINDOWS then*/

    /** 		return "Windows"*/
    RefDS(_6366);
    DeRefi(_platform_name_inlined_platform_name_at_83_49011);
    _platform_name_inlined_platform_name_at_83_49011 = _6366;
    _25594 = _32version_date(0);
    _25595 = _32version_node(0);
    _0 = _misc_info_49009;
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_platform_name_inlined_platform_name_at_83_49011);
    *((int *)(_2+4)) = _platform_name_inlined_platform_name_at_83_49011;
    RefDS(_memory_type_48991);
    *((int *)(_2+8)) = _memory_type_48991;
    RefDS(_22023);
    *((int *)(_2+12)) = _22023;
    *((int *)(_2+16)) = _25594;
    *((int *)(_2+20)) = _25595;
    _misc_info_49009 = MAKE_SEQ(_1);
    DeRef(_0);
    _25595 = NOVALUE;
    _25594 = NOVALUE;

    /** 	if info:is_developmental then*/
    if (_32is_developmental_11447 == 0)
    {
        goto L5; // [114] 148
    }
    else{
    }

    /** 		misc_info[$] = sprintf("%d:%s", { info:version_revision(), info:version_node() })*/
    _25597 = 5;

    /** 	return version_info[REVISION]*/
    DeRef(_version_revision_inlined_version_revision_at_121_49019);
    _2 = (int)SEQ_PTR(_32version_info_11445);
    _version_revision_inlined_version_revision_at_121_49019 = (int)*(((s1_ptr)_2)->base + 6);
    Ref(_version_revision_inlined_version_revision_at_121_49019);
    _25599 = _32version_node(0);
    Ref(_version_revision_inlined_version_revision_at_121_49019);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _version_revision_inlined_version_revision_at_121_49019;
    ((int *)_2)[2] = _25599;
    _25600 = MAKE_SEQ(_1);
    _25599 = NOVALUE;
    _25601 = EPrintf(-9999999, _25598, _25600);
    DeRefDS(_25600);
    _25600 = NOVALUE;
    _2 = (int)SEQ_PTR(_misc_info_49009);
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = _25601;
    if( _1 != _25601 ){
        DeRef(_1);
    }
    _25601 = NOVALUE;
L5: 

    /** 	object EuConsole = getenv("EUCONS")*/
    DeRefi(_EuConsole_49023);
    _EuConsole_49023 = EGetEnv(_25602);

    /** 	if equal(EuConsole, "1") then*/
    if (_EuConsole_49023 == _25604)
    _25605 = 1;
    else if (IS_ATOM_INT(_EuConsole_49023) && IS_ATOM_INT(_25604))
    _25605 = 0;
    else
    _25605 = (compare(_EuConsole_49023, _25604) == 0);
    if (_25605 == 0)
    {
        _25605 = NOVALUE;
        goto L6; // [159] 177
    }
    else{
        _25605 = NOVALUE;
    }

    /** 		misc_info[3] = GetMsgText(275,0)*/
    RefDS(_22023);
    _25606 = _45GetMsgText(275, 0, _22023);
    _2 = (int)SEQ_PTR(_misc_info_49009);
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = _25606;
    if( _1 != _25606 ){
        DeRef(_1);
    }
    _25606 = NOVALUE;
    goto L7; // [174] 185
L6: 

    /** 		misc_info = remove(misc_info, 3)*/
    {
        s1_ptr assign_space = SEQ_PTR(_misc_info_49009);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(3)) ? 3 : (long)(DBL_PTR(3)->dbl);
        int stop = (IS_ATOM_INT(3)) ? 3 : (long)(DBL_PTR(3)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_misc_info_49009), start, &_misc_info_49009 );
            }
            else Tail(SEQ_PTR(_misc_info_49009), stop+1, &_misc_info_49009);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_misc_info_49009), start, &_misc_info_49009);
        }
        else {
            assign_slice_seq = &assign_space;
            _misc_info_49009 = Remove_elements(start, stop, (SEQ_PTR(_misc_info_49009)->ref == 1));
        }
    }
L7: 

    /** 	screen_output(STDERR, sprintf("%s v%s %s\n   %s, %s\n   Revision Date: %s, Id: %s\n", {*/

    /** 	return sprintf("%d.%d.%d", version_info[MAJ_VER..PAT_VER])*/
    rhs_slice_target = (object_ptr)&_version_string_short_1__tmp_at190_49038;
    RHS_Slice(_32version_info_11445, 1, 3);
    DeRefi(_version_string_short_inlined_version_string_short_at_190_49037);
    _version_string_short_inlined_version_string_short_at_190_49037 = EPrintf(-9999999, _6420, _version_string_short_1__tmp_at190_49038);
    DeRef(_version_string_short_1__tmp_at190_49038);
    _version_string_short_1__tmp_at190_49038 = NOVALUE;

    /** 	return version_info[VER_TYPE]*/
    DeRef(_version_type_inlined_version_type_at_206_49040);
    _2 = (int)SEQ_PTR(_32version_info_11445);
    _version_type_inlined_version_type_at_206_49040 = (int)*(((s1_ptr)_2)->base + 4);
    Ref(_version_type_inlined_version_type_at_206_49040);
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_prod_name_48990);
    *((int *)(_2+4)) = _prod_name_48990;
    RefDS(_version_string_short_inlined_version_string_short_at_190_49037);
    *((int *)(_2+8)) = _version_string_short_inlined_version_string_short_at_190_49037;
    Ref(_version_type_inlined_version_type_at_206_49040);
    *((int *)(_2+12)) = _version_type_inlined_version_type_at_206_49040;
    _25609 = MAKE_SEQ(_1);
    Concat((object_ptr)&_25610, _25609, _misc_info_49009);
    DeRefDS(_25609);
    _25609 = NOVALUE;
    DeRef(_25609);
    _25609 = NOVALUE;
    _25611 = EPrintf(-9999999, _25608, _25610);
    DeRefDS(_25610);
    _25610 = NOVALUE;
    _44screen_output(2, _25611);
    _25611 = NOVALUE;

    /** end procedure*/
    DeRefDS(_prod_name_48990);
    DeRef(_memory_type_48991);
    DeRefDS(_misc_info_49009);
    DeRefi(_EuConsole_49023);
    return;
    ;
}


int _43find_opt(int _name_type_49052, int _opt_49053, int _opts_49054)
{
    int _o_49058 = NOVALUE;
    int _has_case_49060 = NOVALUE;
    int _25624 = NOVALUE;
    int _25623 = NOVALUE;
    int _25622 = NOVALUE;
    int _25621 = NOVALUE;
    int _25620 = NOVALUE;
    int _25619 = NOVALUE;
    int _25618 = NOVALUE;
    int _25617 = NOVALUE;
    int _25616 = NOVALUE;
    int _25614 = NOVALUE;
    int _25612 = NOVALUE;
    int _0, _1, _2;
    

    /** 	for i = 1 to length(opts) do*/
    if (IS_SEQUENCE(_opts_49054)){
            _25612 = SEQ_PTR(_opts_49054)->length;
    }
    else {
        _25612 = 1;
    }
    {
        int _i_49056;
        _i_49056 = 1;
L1: 
        if (_i_49056 > _25612){
            goto L2; // [12] 113
        }

        /** 		sequence o = opts[i]		*/
        DeRef(_o_49058);
        _2 = (int)SEQ_PTR(_opts_49054);
        _o_49058 = (int)*(((s1_ptr)_2)->base + _i_49056);
        Ref(_o_49058);

        /** 		integer has_case = find(HAS_CASE, o[OPTIONS])*/
        _2 = (int)SEQ_PTR(_o_49058);
        _25614 = (int)*(((s1_ptr)_2)->base + 4);
        _has_case_49060 = find_from(99, _25614, 1);
        _25614 = NOVALUE;

        /** 		if has_case and equal(o[name_type], opt) then*/
        if (_has_case_49060 == 0) {
            goto L3; // [42] 67
        }
        _2 = (int)SEQ_PTR(_o_49058);
        _25617 = (int)*(((s1_ptr)_2)->base + _name_type_49052);
        if (_25617 == _opt_49053)
        _25618 = 1;
        else if (IS_ATOM_INT(_25617) && IS_ATOM_INT(_opt_49053))
        _25618 = 0;
        else
        _25618 = (compare(_25617, _opt_49053) == 0);
        _25617 = NOVALUE;
        if (_25618 == 0)
        {
            _25618 = NOVALUE;
            goto L3; // [55] 67
        }
        else{
            _25618 = NOVALUE;
        }

        /** 			return o*/
        DeRefDS(_opt_49053);
        DeRefDS(_opts_49054);
        return _o_49058;
        goto L4; // [64] 104
L3: 

        /** 		elsif not has_case and equal(text:lower(o[name_type]), text:lower(opt)) then*/
        _25619 = (_has_case_49060 == 0);
        if (_25619 == 0) {
            goto L5; // [72] 103
        }
        _2 = (int)SEQ_PTR(_o_49058);
        _25621 = (int)*(((s1_ptr)_2)->base + _name_type_49052);
        Ref(_25621);
        _25622 = _14lower(_25621);
        _25621 = NOVALUE;
        RefDS(_opt_49053);
        _25623 = _14lower(_opt_49053);
        if (_25622 == _25623)
        _25624 = 1;
        else if (IS_ATOM_INT(_25622) && IS_ATOM_INT(_25623))
        _25624 = 0;
        else
        _25624 = (compare(_25622, _25623) == 0);
        DeRef(_25622);
        _25622 = NOVALUE;
        DeRef(_25623);
        _25623 = NOVALUE;
        if (_25624 == 0)
        {
            _25624 = NOVALUE;
            goto L5; // [93] 103
        }
        else{
            _25624 = NOVALUE;
        }

        /** 			return o*/
        DeRefDS(_opt_49053);
        DeRefDS(_opts_49054);
        DeRef(_25619);
        _25619 = NOVALUE;
        return _o_49058;
L5: 
L4: 
        DeRef(_o_49058);
        _o_49058 = NOVALUE;

        /** 	end for*/
        _i_49056 = _i_49056 + 1;
        goto L1; // [108] 19
L2: 
        ;
    }

    /** 	return {}*/
    RefDS(_22023);
    DeRefDS(_opt_49053);
    DeRefDS(_opts_49054);
    DeRef(_25619);
    _25619 = NOVALUE;
    return _22023;
    ;
}


int _43merge_parameters(int _a_49077, int _b_49078, int _opts_49079, int _dedupe_49080)
{
    int _i_49081 = NOVALUE;
    int _opt_49085 = NOVALUE;
    int _this_opt_49091 = NOVALUE;
    int _bi_49092 = NOVALUE;
    int _beginLen_49152 = NOVALUE;
    int _first_extra_49174 = NOVALUE;
    int _opt_49178 = NOVALUE;
    int _this_opt_49183 = NOVALUE;
    int _25718 = NOVALUE;
    int _25717 = NOVALUE;
    int _25714 = NOVALUE;
    int _25713 = NOVALUE;
    int _25712 = NOVALUE;
    int _25710 = NOVALUE;
    int _25709 = NOVALUE;
    int _25708 = NOVALUE;
    int _25707 = NOVALUE;
    int _25705 = NOVALUE;
    int _25704 = NOVALUE;
    int _25702 = NOVALUE;
    int _25701 = NOVALUE;
    int _25700 = NOVALUE;
    int _25699 = NOVALUE;
    int _25698 = NOVALUE;
    int _25697 = NOVALUE;
    int _25696 = NOVALUE;
    int _25694 = NOVALUE;
    int _25691 = NOVALUE;
    int _25690 = NOVALUE;
    int _25685 = NOVALUE;
    int _25683 = NOVALUE;
    int _25682 = NOVALUE;
    int _25681 = NOVALUE;
    int _25680 = NOVALUE;
    int _25679 = NOVALUE;
    int _25678 = NOVALUE;
    int _25677 = NOVALUE;
    int _25676 = NOVALUE;
    int _25672 = NOVALUE;
    int _25671 = NOVALUE;
    int _25670 = NOVALUE;
    int _25669 = NOVALUE;
    int _25668 = NOVALUE;
    int _25667 = NOVALUE;
    int _25666 = NOVALUE;
    int _25665 = NOVALUE;
    int _25664 = NOVALUE;
    int _25663 = NOVALUE;
    int _25662 = NOVALUE;
    int _25661 = NOVALUE;
    int _25660 = NOVALUE;
    int _25659 = NOVALUE;
    int _25658 = NOVALUE;
    int _25656 = NOVALUE;
    int _25655 = NOVALUE;
    int _25654 = NOVALUE;
    int _25653 = NOVALUE;
    int _25652 = NOVALUE;
    int _25651 = NOVALUE;
    int _25650 = NOVALUE;
    int _25649 = NOVALUE;
    int _25647 = NOVALUE;
    int _25646 = NOVALUE;
    int _25645 = NOVALUE;
    int _25644 = NOVALUE;
    int _25642 = NOVALUE;
    int _25641 = NOVALUE;
    int _25640 = NOVALUE;
    int _25639 = NOVALUE;
    int _25638 = NOVALUE;
    int _25637 = NOVALUE;
    int _25636 = NOVALUE;
    int _25634 = NOVALUE;
    int _25633 = NOVALUE;
    int _25631 = NOVALUE;
    int _25628 = NOVALUE;
    int _25625 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_dedupe_49080)) {
        _1 = (long)(DBL_PTR(_dedupe_49080)->dbl);
        DeRefDS(_dedupe_49080);
        _dedupe_49080 = _1;
    }

    /** 	integer i = 1*/
    _i_49081 = 1;

    /** 	while i <= length(a) do*/
L1: 
    if (IS_SEQUENCE(_a_49077)){
            _25625 = SEQ_PTR(_a_49077)->length;
    }
    else {
        _25625 = 1;
    }
    if (_i_49081 > _25625)
    goto L2; // [22] 465

    /** 		sequence opt = a[i]*/
    DeRef(_opt_49085);
    _2 = (int)SEQ_PTR(_a_49077);
    _opt_49085 = (int)*(((s1_ptr)_2)->base + _i_49081);
    Ref(_opt_49085);

    /** 		if length(opt) < 2 then*/
    if (IS_SEQUENCE(_opt_49085)){
            _25628 = SEQ_PTR(_opt_49085)->length;
    }
    else {
        _25628 = 1;
    }
    if (_25628 >= 2)
    goto L3; // [39] 56

    /** 			i += 1*/
    _i_49081 = _i_49081 + 1;

    /** 			continue*/
    DeRefDS(_opt_49085);
    _opt_49085 = NOVALUE;
    DeRef(_this_opt_49091);
    _this_opt_49091 = NOVALUE;
    goto L1; // [53] 19
L3: 

    /** 		sequence this_opt = {}*/
    RefDS(_22023);
    DeRef(_this_opt_49091);
    _this_opt_49091 = _22023;

    /** 		integer bi = 0*/
    _bi_49092 = 0;

    /** 		if opt[2] = '-' then*/
    _2 = (int)SEQ_PTR(_opt_49085);
    _25631 = (int)*(((s1_ptr)_2)->base + 2);
    if (binary_op_a(NOTEQ, _25631, 45)){
        _25631 = NOVALUE;
        goto L4; // [74] 149
    }
    _25631 = NOVALUE;

    /** 			this_opt = find_opt(LONGNAME, opt[3..$], opts)*/
    if (IS_SEQUENCE(_opt_49085)){
            _25633 = SEQ_PTR(_opt_49085)->length;
    }
    else {
        _25633 = 1;
    }
    rhs_slice_target = (object_ptr)&_25634;
    RHS_Slice(_opt_49085, 3, _25633);
    RefDS(_opts_49079);
    _0 = _this_opt_49091;
    _this_opt_49091 = _43find_opt(2, _25634, _opts_49079);
    DeRefDS(_0);
    _25634 = NOVALUE;

    /** 			for j = 1 to length(b) do*/
    if (IS_SEQUENCE(_b_49078)){
            _25636 = SEQ_PTR(_b_49078)->length;
    }
    else {
        _25636 = 1;
    }
    {
        int _j_49100;
        _j_49100 = 1;
L5: 
        if (_j_49100 > _25636){
            goto L6; // [101] 146
        }

        /** 				if equal(text:lower(b[j]), text:lower(opt)) then*/
        _2 = (int)SEQ_PTR(_b_49078);
        _25637 = (int)*(((s1_ptr)_2)->base + _j_49100);
        Ref(_25637);
        _25638 = _14lower(_25637);
        _25637 = NOVALUE;
        RefDS(_opt_49085);
        _25639 = _14lower(_opt_49085);
        if (_25638 == _25639)
        _25640 = 1;
        else if (IS_ATOM_INT(_25638) && IS_ATOM_INT(_25639))
        _25640 = 0;
        else
        _25640 = (compare(_25638, _25639) == 0);
        DeRef(_25638);
        _25638 = NOVALUE;
        DeRef(_25639);
        _25639 = NOVALUE;
        if (_25640 == 0)
        {
            _25640 = NOVALUE;
            goto L7; // [126] 139
        }
        else{
            _25640 = NOVALUE;
        }

        /** 					bi = j*/
        _bi_49092 = _j_49100;

        /** 					exit*/
        goto L6; // [136] 146
L7: 

        /** 			end for*/
        _j_49100 = _j_49100 + 1;
        goto L5; // [141] 108
L6: 
        ;
    }
    goto L8; // [146] 292
L4: 

    /** 		elsif opt[1] = '-' or opt[1] = '/' then*/
    _2 = (int)SEQ_PTR(_opt_49085);
    _25641 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_25641)) {
        _25642 = (_25641 == 45);
    }
    else {
        _25642 = binary_op(EQUALS, _25641, 45);
    }
    _25641 = NOVALUE;
    if (IS_ATOM_INT(_25642)) {
        if (_25642 != 0) {
            goto L9; // [159] 176
        }
    }
    else {
        if (DBL_PTR(_25642)->dbl != 0.0) {
            goto L9; // [159] 176
        }
    }
    _2 = (int)SEQ_PTR(_opt_49085);
    _25644 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_25644)) {
        _25645 = (_25644 == 47);
    }
    else {
        _25645 = binary_op(EQUALS, _25644, 47);
    }
    _25644 = NOVALUE;
    if (_25645 == 0) {
        DeRef(_25645);
        _25645 = NOVALUE;
        goto LA; // [172] 291
    }
    else {
        if (!IS_ATOM_INT(_25645) && DBL_PTR(_25645)->dbl == 0.0){
            DeRef(_25645);
            _25645 = NOVALUE;
            goto LA; // [172] 291
        }
        DeRef(_25645);
        _25645 = NOVALUE;
    }
    DeRef(_25645);
    _25645 = NOVALUE;
L9: 

    /** 			this_opt = find_opt(SHORTNAME, opt[2..$], opts)*/
    if (IS_SEQUENCE(_opt_49085)){
            _25646 = SEQ_PTR(_opt_49085)->length;
    }
    else {
        _25646 = 1;
    }
    rhs_slice_target = (object_ptr)&_25647;
    RHS_Slice(_opt_49085, 2, _25646);
    RefDS(_opts_49079);
    _0 = _this_opt_49091;
    _this_opt_49091 = _43find_opt(1, _25647, _opts_49079);
    DeRef(_0);
    _25647 = NOVALUE;

    /** 			for j = 1 to length(b) do*/
    if (IS_SEQUENCE(_b_49078)){
            _25649 = SEQ_PTR(_b_49078)->length;
    }
    else {
        _25649 = 1;
    }
    {
        int _j_49117;
        _j_49117 = 1;
LB: 
        if (_j_49117 > _25649){
            goto LC; // [199] 290
        }

        /** 				if equal(text:lower(b[j]), '-' & text:lower(opt[2..$])) or */
        _2 = (int)SEQ_PTR(_b_49078);
        _25650 = (int)*(((s1_ptr)_2)->base + _j_49117);
        Ref(_25650);
        _25651 = _14lower(_25650);
        _25650 = NOVALUE;
        if (IS_SEQUENCE(_opt_49085)){
                _25652 = SEQ_PTR(_opt_49085)->length;
        }
        else {
            _25652 = 1;
        }
        rhs_slice_target = (object_ptr)&_25653;
        RHS_Slice(_opt_49085, 2, _25652);
        _25654 = _14lower(_25653);
        _25653 = NOVALUE;
        if (IS_SEQUENCE(45) && IS_ATOM(_25654)) {
        }
        else if (IS_ATOM(45) && IS_SEQUENCE(_25654)) {
            Prepend(&_25655, _25654, 45);
        }
        else {
            Concat((object_ptr)&_25655, 45, _25654);
        }
        DeRef(_25654);
        _25654 = NOVALUE;
        if (_25651 == _25655)
        _25656 = 1;
        else if (IS_ATOM_INT(_25651) && IS_ATOM_INT(_25655))
        _25656 = 0;
        else
        _25656 = (compare(_25651, _25655) == 0);
        DeRef(_25651);
        _25651 = NOVALUE;
        DeRefDS(_25655);
        _25655 = NOVALUE;
        if (_25656 != 0) {
            goto LD; // [236] 273
        }
        _2 = (int)SEQ_PTR(_b_49078);
        _25658 = (int)*(((s1_ptr)_2)->base + _j_49117);
        Ref(_25658);
        _25659 = _14lower(_25658);
        _25658 = NOVALUE;
        if (IS_SEQUENCE(_opt_49085)){
                _25660 = SEQ_PTR(_opt_49085)->length;
        }
        else {
            _25660 = 1;
        }
        rhs_slice_target = (object_ptr)&_25661;
        RHS_Slice(_opt_49085, 2, _25660);
        _25662 = _14lower(_25661);
        _25661 = NOVALUE;
        if (IS_SEQUENCE(47) && IS_ATOM(_25662)) {
        }
        else if (IS_ATOM(47) && IS_SEQUENCE(_25662)) {
            Prepend(&_25663, _25662, 47);
        }
        else {
            Concat((object_ptr)&_25663, 47, _25662);
        }
        DeRef(_25662);
        _25662 = NOVALUE;
        if (_25659 == _25663)
        _25664 = 1;
        else if (IS_ATOM_INT(_25659) && IS_ATOM_INT(_25663))
        _25664 = 0;
        else
        _25664 = (compare(_25659, _25663) == 0);
        DeRef(_25659);
        _25659 = NOVALUE;
        DeRefDS(_25663);
        _25663 = NOVALUE;
        if (_25664 == 0)
        {
            _25664 = NOVALUE;
            goto LE; // [269] 283
        }
        else{
            _25664 = NOVALUE;
        }
LD: 

        /** 					bi = j*/
        _bi_49092 = _j_49117;

        /** 					exit*/
        goto LC; // [280] 290
LE: 

        /** 			end for*/
        _j_49117 = _j_49117 + 1;
        goto LB; // [285] 206
LC: 
        ;
    }
LA: 
L8: 

    /** 		if length(this_opt) and not find(MULTIPLE, this_opt[OPTIONS]) then*/
    if (IS_SEQUENCE(_this_opt_49091)){
            _25665 = SEQ_PTR(_this_opt_49091)->length;
    }
    else {
        _25665 = 1;
    }
    if (_25665 == 0) {
        goto LF; // [297] 451
    }
    _2 = (int)SEQ_PTR(_this_opt_49091);
    _25667 = (int)*(((s1_ptr)_2)->base + 4);
    _25668 = find_from(42, _25667, 1);
    _25667 = NOVALUE;
    _25669 = (_25668 == 0);
    _25668 = NOVALUE;
    if (_25669 == 0)
    {
        DeRef(_25669);
        _25669 = NOVALUE;
        goto LF; // [316] 451
    }
    else{
        DeRef(_25669);
        _25669 = NOVALUE;
    }

    /** 			if bi then*/
    if (_bi_49092 == 0)
    {
        goto L10; // [321] 365
    }
    else{
    }

    /** 				if find(HAS_PARAMETER, this_opt[OPTIONS]) then*/
    _2 = (int)SEQ_PTR(_this_opt_49091);
    _25670 = (int)*(((s1_ptr)_2)->base + 4);
    _25671 = find_from(112, _25670, 1);
    _25670 = NOVALUE;
    if (_25671 == 0)
    {
        _25671 = NOVALUE;
        goto L11; // [337] 354
    }
    else{
        _25671 = NOVALUE;
    }

    /** 					a = remove(a, i, i + 1)*/
    _25672 = _i_49081 + 1;
    if (_25672 > MAXINT){
        _25672 = NewDouble((double)_25672);
    }
    {
        s1_ptr assign_space = SEQ_PTR(_a_49077);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_i_49081)) ? _i_49081 : (long)(DBL_PTR(_i_49081)->dbl);
        int stop = (IS_ATOM_INT(_25672)) ? _25672 : (long)(DBL_PTR(_25672)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_a_49077), start, &_a_49077 );
            }
            else Tail(SEQ_PTR(_a_49077), stop+1, &_a_49077);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_a_49077), start, &_a_49077);
        }
        else {
            assign_slice_seq = &assign_space;
            _a_49077 = Remove_elements(start, stop, (SEQ_PTR(_a_49077)->ref == 1));
        }
    }
    DeRef(_25672);
    _25672 = NOVALUE;
    goto L12; // [351] 458
L11: 

    /** 					a = remove(a, i)*/
    {
        s1_ptr assign_space = SEQ_PTR(_a_49077);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_i_49081)) ? _i_49081 : (long)(DBL_PTR(_i_49081)->dbl);
        int stop = (IS_ATOM_INT(_i_49081)) ? _i_49081 : (long)(DBL_PTR(_i_49081)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_a_49077), start, &_a_49077 );
            }
            else Tail(SEQ_PTR(_a_49077), stop+1, &_a_49077);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_a_49077), start, &_a_49077);
        }
        else {
            assign_slice_seq = &assign_space;
            _a_49077 = Remove_elements(start, stop, (SEQ_PTR(_a_49077)->ref == 1));
        }
    }
    goto L12; // [362] 458
L10: 

    /** 				integer beginLen = length(a)*/
    if (IS_SEQUENCE(_a_49077)){
            _beginLen_49152 = SEQ_PTR(_a_49077)->length;
    }
    else {
        _beginLen_49152 = 1;
    }

    /** 				if dedupe = 0 and i < beginLen then*/
    _25676 = (_dedupe_49080 == 0);
    if (_25676 == 0) {
        goto L13; // [376] 438
    }
    _25678 = (_i_49081 < _beginLen_49152);
    if (_25678 == 0)
    {
        DeRef(_25678);
        _25678 = NOVALUE;
        goto L13; // [385] 438
    }
    else{
        DeRef(_25678);
        _25678 = NOVALUE;
    }

    /** 					a = merge_parameters( a[i + 1..$], a[1..i], opts, 1)*/
    _25679 = _i_49081 + 1;
    if (_25679 > MAXINT){
        _25679 = NewDouble((double)_25679);
    }
    if (IS_SEQUENCE(_a_49077)){
            _25680 = SEQ_PTR(_a_49077)->length;
    }
    else {
        _25680 = 1;
    }
    rhs_slice_target = (object_ptr)&_25681;
    RHS_Slice(_a_49077, _25679, _25680);
    rhs_slice_target = (object_ptr)&_25682;
    RHS_Slice(_a_49077, 1, _i_49081);
    RefDS(_opts_49079);
    DeRef(_25683);
    _25683 = _opts_49079;
    _0 = _a_49077;
    _a_49077 = _43merge_parameters(_25681, _25682, _25683, 1);
    DeRefDS(_0);
    _25681 = NOVALUE;
    _25682 = NOVALUE;
    _25683 = NOVALUE;

    /** 					if beginLen = length(a) then*/
    if (IS_SEQUENCE(_a_49077)){
            _25685 = SEQ_PTR(_a_49077)->length;
    }
    else {
        _25685 = 1;
    }
    if (_beginLen_49152 != _25685)
    goto L14; // [424] 445

    /** 						i += 1*/
    _i_49081 = _i_49081 + 1;
    goto L14; // [435] 445
L13: 

    /** 					i += 1*/
    _i_49081 = _i_49081 + 1;
L14: 
    goto L12; // [448] 458
LF: 

    /** 			i += 1*/
    _i_49081 = _i_49081 + 1;
L12: 
    DeRef(_opt_49085);
    _opt_49085 = NOVALUE;
    DeRef(_this_opt_49091);
    _this_opt_49091 = NOVALUE;

    /** 	end while*/
    goto L1; // [462] 19
L2: 

    /** 	if dedupe then*/
    if (_dedupe_49080 == 0)
    {
        goto L15; // [467] 481
    }
    else{
    }

    /** 		return b & a*/
    Concat((object_ptr)&_25690, _b_49078, _a_49077);
    DeRefDS(_a_49077);
    DeRefDS(_b_49078);
    DeRefDS(_opts_49079);
    DeRef(_25676);
    _25676 = NOVALUE;
    DeRef(_25642);
    _25642 = NOVALUE;
    DeRef(_25679);
    _25679 = NOVALUE;
    return _25690;
L15: 

    /** 	integer first_extra = 0*/
    _first_extra_49174 = 0;

    /** 	i = 1*/
    _i_49081 = 1;

    /** 	while i <= length(b) do*/
L16: 
    if (IS_SEQUENCE(_b_49078)){
            _25691 = SEQ_PTR(_b_49078)->length;
    }
    else {
        _25691 = 1;
    }
    if (_i_49081 > _25691)
    goto L17; // [499] 692

    /** 		sequence opt = b[i]*/
    DeRef(_opt_49178);
    _2 = (int)SEQ_PTR(_b_49078);
    _opt_49178 = (int)*(((s1_ptr)_2)->base + _i_49081);
    Ref(_opt_49178);

    /** 		if length(opt) <= 1 then*/
    if (IS_SEQUENCE(_opt_49178)){
            _25694 = SEQ_PTR(_opt_49178)->length;
    }
    else {
        _25694 = 1;
    }
    if (_25694 > 1)
    goto L18; // [516] 532

    /** 			first_extra = i*/
    _first_extra_49174 = _i_49081;

    /** 			exit*/
    DeRefDS(_opt_49178);
    _opt_49178 = NOVALUE;
    DeRef(_this_opt_49183);
    _this_opt_49183 = NOVALUE;
    goto L17; // [529] 692
L18: 

    /** 		sequence this_opt = {}*/
    RefDS(_22023);
    DeRef(_this_opt_49183);
    _this_opt_49183 = _22023;

    /** 		if opt[2] = '-' and opt[1] = '-' then*/
    _2 = (int)SEQ_PTR(_opt_49178);
    _25696 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_25696)) {
        _25697 = (_25696 == 45);
    }
    else {
        _25697 = binary_op(EQUALS, _25696, 45);
    }
    _25696 = NOVALUE;
    if (IS_ATOM_INT(_25697)) {
        if (_25697 == 0) {
            goto L19; // [549] 586
        }
    }
    else {
        if (DBL_PTR(_25697)->dbl == 0.0) {
            goto L19; // [549] 586
        }
    }
    _2 = (int)SEQ_PTR(_opt_49178);
    _25699 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_25699)) {
        _25700 = (_25699 == 45);
    }
    else {
        _25700 = binary_op(EQUALS, _25699, 45);
    }
    _25699 = NOVALUE;
    if (_25700 == 0) {
        DeRef(_25700);
        _25700 = NOVALUE;
        goto L19; // [562] 586
    }
    else {
        if (!IS_ATOM_INT(_25700) && DBL_PTR(_25700)->dbl == 0.0){
            DeRef(_25700);
            _25700 = NOVALUE;
            goto L19; // [562] 586
        }
        DeRef(_25700);
        _25700 = NOVALUE;
    }
    DeRef(_25700);
    _25700 = NOVALUE;

    /** 			this_opt = find_opt(LONGNAME, opt[3..$], opts)*/
    if (IS_SEQUENCE(_opt_49178)){
            _25701 = SEQ_PTR(_opt_49178)->length;
    }
    else {
        _25701 = 1;
    }
    rhs_slice_target = (object_ptr)&_25702;
    RHS_Slice(_opt_49178, 3, _25701);
    RefDS(_opts_49079);
    _0 = _this_opt_49183;
    _this_opt_49183 = _43find_opt(2, _25702, _opts_49079);
    DeRef(_0);
    _25702 = NOVALUE;
    goto L1A; // [583] 633
L19: 

    /** 		elsif opt[1] = '-' or opt[1] = '/' then*/
    _2 = (int)SEQ_PTR(_opt_49178);
    _25704 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_25704)) {
        _25705 = (_25704 == 45);
    }
    else {
        _25705 = binary_op(EQUALS, _25704, 45);
    }
    _25704 = NOVALUE;
    if (IS_ATOM_INT(_25705)) {
        if (_25705 != 0) {
            goto L1B; // [596] 613
        }
    }
    else {
        if (DBL_PTR(_25705)->dbl != 0.0) {
            goto L1B; // [596] 613
        }
    }
    _2 = (int)SEQ_PTR(_opt_49178);
    _25707 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_25707)) {
        _25708 = (_25707 == 47);
    }
    else {
        _25708 = binary_op(EQUALS, _25707, 47);
    }
    _25707 = NOVALUE;
    if (_25708 == 0) {
        DeRef(_25708);
        _25708 = NOVALUE;
        goto L1C; // [609] 632
    }
    else {
        if (!IS_ATOM_INT(_25708) && DBL_PTR(_25708)->dbl == 0.0){
            DeRef(_25708);
            _25708 = NOVALUE;
            goto L1C; // [609] 632
        }
        DeRef(_25708);
        _25708 = NOVALUE;
    }
    DeRef(_25708);
    _25708 = NOVALUE;
L1B: 

    /** 			this_opt = find_opt(SHORTNAME, opt[2..$], opts)*/
    if (IS_SEQUENCE(_opt_49178)){
            _25709 = SEQ_PTR(_opt_49178)->length;
    }
    else {
        _25709 = 1;
    }
    rhs_slice_target = (object_ptr)&_25710;
    RHS_Slice(_opt_49178, 2, _25709);
    RefDS(_opts_49079);
    _0 = _this_opt_49183;
    _this_opt_49183 = _43find_opt(1, _25710, _opts_49079);
    DeRef(_0);
    _25710 = NOVALUE;
L1C: 
L1A: 

    /** 		if length(this_opt) then*/
    if (IS_SEQUENCE(_this_opt_49183)){
            _25712 = SEQ_PTR(_this_opt_49183)->length;
    }
    else {
        _25712 = 1;
    }
    if (_25712 == 0)
    {
        _25712 = NOVALUE;
        goto L1D; // [638] 667
    }
    else{
        _25712 = NOVALUE;
    }

    /** 			if find(HAS_PARAMETER, this_opt[OPTIONS]) then*/
    _2 = (int)SEQ_PTR(_this_opt_49183);
    _25713 = (int)*(((s1_ptr)_2)->base + 4);
    _25714 = find_from(112, _25713, 1);
    _25713 = NOVALUE;
    if (_25714 == 0)
    {
        _25714 = NOVALUE;
        goto L1E; // [654] 679
    }
    else{
        _25714 = NOVALUE;
    }

    /** 				i += 1*/
    _i_49081 = _i_49081 + 1;
    goto L1E; // [664] 679
L1D: 

    /** 			first_extra = i*/
    _first_extra_49174 = _i_49081;

    /** 			exit*/
    DeRef(_opt_49178);
    _opt_49178 = NOVALUE;
    DeRef(_this_opt_49183);
    _this_opt_49183 = NOVALUE;
    goto L17; // [676] 692
L1E: 

    /** 		i += 1*/
    _i_49081 = _i_49081 + 1;
    DeRef(_opt_49178);
    _opt_49178 = NOVALUE;
    DeRef(_this_opt_49183);
    _this_opt_49183 = NOVALUE;

    /** 	end while*/
    goto L16; // [689] 496
L17: 

    /** 	if first_extra then*/
    if (_first_extra_49174 == 0)
    {
        goto L1F; // [694] 709
    }
    else{
    }

    /** 		return splice(b, a, first_extra)*/
    {
        s1_ptr assign_space;
        insert_pos = _first_extra_49174;
        if (insert_pos <= 0) {
            Concat(&_25717,_a_49077,_b_49078);
        }
        else if (insert_pos > SEQ_PTR(_b_49078)->length){
            Concat(&_25717,_b_49078,_a_49077);
        }
        else if (IS_SEQUENCE(_a_49077)) {
            if( _25717 != _b_49078 || SEQ_PTR( _b_49078 )->ref != 1 ){
                DeRef( _25717 );
                RefDS( _b_49078 );
            }
            assign_space = Add_internal_space( _b_49078, insert_pos,((s1_ptr)SEQ_PTR(_a_49077))->length);
            assign_slice_seq = &assign_space;
            assign_space = Copy_elements( insert_pos, SEQ_PTR(_a_49077), _b_49078 == _25717 );
            _25717 = MAKE_SEQ( assign_space );
        }
        else {
            if( _25717 != _b_49078 && SEQ_PTR( _b_49078 )->ref != 1 ){
                _25717 = Insert( _b_49078, _a_49077, insert_pos);
            }
            else {
                DeRef( _25717 );
                RefDS( _b_49078 );
                _25717 = Insert( _b_49078, _a_49077, insert_pos);
            }
        }
    }
    DeRefDS(_a_49077);
    DeRefDS(_b_49078);
    DeRefDS(_opts_49079);
    DeRef(_25676);
    _25676 = NOVALUE;
    DeRef(_25642);
    _25642 = NOVALUE;
    DeRef(_25679);
    _25679 = NOVALUE;
    DeRef(_25690);
    _25690 = NOVALUE;
    DeRef(_25697);
    _25697 = NOVALUE;
    DeRef(_25705);
    _25705 = NOVALUE;
    return _25717;
L1F: 

    /** 	return b & a*/
    Concat((object_ptr)&_25718, _b_49078, _a_49077);
    DeRefDS(_a_49077);
    DeRefDS(_b_49078);
    DeRefDS(_opts_49079);
    DeRef(_25676);
    _25676 = NOVALUE;
    DeRef(_25642);
    _25642 = NOVALUE;
    DeRef(_25679);
    _25679 = NOVALUE;
    DeRef(_25690);
    _25690 = NOVALUE;
    DeRef(_25717);
    _25717 = NOVALUE;
    DeRef(_25697);
    _25697 = NOVALUE;
    DeRef(_25705);
    _25705 = NOVALUE;
    return _25718;
    ;
}


int _43validate_opt(int _opt_type_49216, int _arg_49217, int _args_49218, int _ix_49219)
{
    int _opt_49220 = NOVALUE;
    int _this_opt_49228 = NOVALUE;
    int _25737 = NOVALUE;
    int _25736 = NOVALUE;
    int _25735 = NOVALUE;
    int _25734 = NOVALUE;
    int _25733 = NOVALUE;
    int _25731 = NOVALUE;
    int _25730 = NOVALUE;
    int _25729 = NOVALUE;
    int _25728 = NOVALUE;
    int _25727 = NOVALUE;
    int _25725 = NOVALUE;
    int _25722 = NOVALUE;
    int _25720 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if opt_type = SHORTNAME then*/
    if (_opt_type_49216 != 1)
    goto L1; // [11] 28

    /** 		opt = arg[2..$]*/
    if (IS_SEQUENCE(_arg_49217)){
            _25720 = SEQ_PTR(_arg_49217)->length;
    }
    else {
        _25720 = 1;
    }
    rhs_slice_target = (object_ptr)&_opt_49220;
    RHS_Slice(_arg_49217, 2, _25720);
    goto L2; // [25] 39
L1: 

    /** 		opt = arg[3..$]*/
    if (IS_SEQUENCE(_arg_49217)){
            _25722 = SEQ_PTR(_arg_49217)->length;
    }
    else {
        _25722 = 1;
    }
    rhs_slice_target = (object_ptr)&_opt_49220;
    RHS_Slice(_arg_49217, 3, _25722);
L2: 

    /** 	sequence this_opt = find_opt( opt_type, opt, options )*/
    RefDS(_opt_49220);
    RefDS(_43options_48959);
    _0 = _this_opt_49228;
    _this_opt_49228 = _43find_opt(_opt_type_49216, _opt_49220, _43options_48959);
    DeRef(_0);

    /** 	if not length( this_opt ) then*/
    if (IS_SEQUENCE(_this_opt_49228)){
            _25725 = SEQ_PTR(_this_opt_49228)->length;
    }
    else {
        _25725 = 1;
    }
    if (_25725 != 0)
    goto L3; // [58] 72
    _25725 = NOVALUE;

    /** 		return { 0, 0 }*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = 0;
    _25727 = MAKE_SEQ(_1);
    DeRefDS(_arg_49217);
    DeRefDS(_args_49218);
    DeRefDS(_opt_49220);
    DeRefDS(_this_opt_49228);
    return _25727;
L3: 

    /** 	if find( HAS_PARAMETER, this_opt[OPTIONS] ) then*/
    _2 = (int)SEQ_PTR(_this_opt_49228);
    _25728 = (int)*(((s1_ptr)_2)->base + 4);
    _25729 = find_from(112, _25728, 1);
    _25728 = NOVALUE;
    if (_25729 == 0)
    {
        _25729 = NOVALUE;
        goto L4; // [85] 135
    }
    else{
        _25729 = NOVALUE;
    }

    /** 		if ix = length( args ) - 1 then*/
    if (IS_SEQUENCE(_args_49218)){
            _25730 = SEQ_PTR(_args_49218)->length;
    }
    else {
        _25730 = 1;
    }
    _25731 = _25730 - 1;
    _25730 = NOVALUE;
    if (_ix_49219 != _25731)
    goto L5; // [97] 117

    /** 			CompileErr( MISSING_CMD_PARAMETER, { arg } )*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_arg_49217);
    *((int *)(_2+4)) = _arg_49217;
    _25733 = MAKE_SEQ(_1);
    _44CompileErr(353, _25733, 0);
    _25733 = NOVALUE;
    goto L6; // [114] 150
L5: 

    /** 			return { ix, ix + 2 }*/
    _25734 = _ix_49219 + 2;
    if ((long)((unsigned long)_25734 + (unsigned long)HIGH_BITS) >= 0) 
    _25734 = NewDouble((double)_25734);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _ix_49219;
    ((int *)_2)[2] = _25734;
    _25735 = MAKE_SEQ(_1);
    _25734 = NOVALUE;
    DeRefDS(_arg_49217);
    DeRefDS(_args_49218);
    DeRef(_opt_49220);
    DeRef(_this_opt_49228);
    DeRef(_25727);
    _25727 = NOVALUE;
    DeRef(_25731);
    _25731 = NOVALUE;
    return _25735;
    goto L6; // [132] 150
L4: 

    /** 		return { ix, ix + 1 }*/
    _25736 = _ix_49219 + 1;
    if (_25736 > MAXINT){
        _25736 = NewDouble((double)_25736);
    }
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _ix_49219;
    ((int *)_2)[2] = _25736;
    _25737 = MAKE_SEQ(_1);
    _25736 = NOVALUE;
    DeRefDS(_arg_49217);
    DeRefDS(_args_49218);
    DeRef(_opt_49220);
    DeRef(_this_opt_49228);
    DeRef(_25727);
    _25727 = NOVALUE;
    DeRef(_25731);
    _25731 = NOVALUE;
    DeRef(_25735);
    _25735 = NOVALUE;
    return _25737;
L6: 
    ;
}


int _43find_next_opt(int _ix_49253, int _args_49254)
{
    int _arg_49258 = NOVALUE;
    int _25759 = NOVALUE;
    int _25758 = NOVALUE;
    int _25756 = NOVALUE;
    int _25755 = NOVALUE;
    int _25754 = NOVALUE;
    int _25753 = NOVALUE;
    int _25752 = NOVALUE;
    int _25751 = NOVALUE;
    int _25750 = NOVALUE;
    int _25749 = NOVALUE;
    int _25747 = NOVALUE;
    int _25745 = NOVALUE;
    int _25743 = NOVALUE;
    int _25741 = NOVALUE;
    int _25738 = NOVALUE;
    int _0, _1, _2;
    

    /** 	while ix < length( args ) do*/
L1: 
    if (IS_SEQUENCE(_args_49254)){
            _25738 = SEQ_PTR(_args_49254)->length;
    }
    else {
        _25738 = 1;
    }
    if (_ix_49253 >= _25738)
    goto L2; // [13] 157

    /** 		sequence arg = args[ix]*/
    DeRef(_arg_49258);
    _2 = (int)SEQ_PTR(_args_49254);
    _arg_49258 = (int)*(((s1_ptr)_2)->base + _ix_49253);
    Ref(_arg_49258);

    /** 		if length( arg ) > 1 then*/
    if (IS_SEQUENCE(_arg_49258)){
            _25741 = SEQ_PTR(_arg_49258)->length;
    }
    else {
        _25741 = 1;
    }
    if (_25741 <= 1)
    goto L3; // [30] 129

    /** 			if arg[1] = '-' then*/
    _2 = (int)SEQ_PTR(_arg_49258);
    _25743 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _25743, 45)){
        _25743 = NOVALUE;
        goto L4; // [40] 111
    }
    _25743 = NOVALUE;

    /** 				if arg[2] = '-' then*/
    _2 = (int)SEQ_PTR(_arg_49258);
    _25745 = (int)*(((s1_ptr)_2)->base + 2);
    if (binary_op_a(NOTEQ, _25745, 45)){
        _25745 = NOVALUE;
        goto L5; // [50] 94
    }
    _25745 = NOVALUE;

    /** 					if length( arg ) = 2 then*/
    if (IS_SEQUENCE(_arg_49258)){
            _25747 = SEQ_PTR(_arg_49258)->length;
    }
    else {
        _25747 = 1;
    }
    if (_25747 != 2)
    goto L6; // [59] 78

    /** 						return { 0, ix - 1 }*/
    _25749 = _ix_49253 - 1;
    if ((long)((unsigned long)_25749 +(unsigned long) HIGH_BITS) >= 0){
        _25749 = NewDouble((double)_25749);
    }
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = _25749;
    _25750 = MAKE_SEQ(_1);
    _25749 = NOVALUE;
    DeRefDS(_arg_49258);
    DeRefDS(_args_49254);
    return _25750;
L6: 

    /** 					return validate_opt( LONGNAME, arg, args, ix )*/
    RefDS(_arg_49258);
    RefDS(_args_49254);
    _25751 = _43validate_opt(2, _arg_49258, _args_49254, _ix_49253);
    DeRefDS(_arg_49258);
    DeRefDS(_args_49254);
    DeRef(_25750);
    _25750 = NOVALUE;
    return _25751;
    goto L7; // [91] 144
L5: 

    /** 					return validate_opt( SHORTNAME, arg, args, ix )*/
    RefDS(_arg_49258);
    RefDS(_args_49254);
    _25752 = _43validate_opt(1, _arg_49258, _args_49254, _ix_49253);
    DeRefDS(_arg_49258);
    DeRefDS(_args_49254);
    DeRef(_25750);
    _25750 = NOVALUE;
    DeRef(_25751);
    _25751 = NOVALUE;
    return _25752;
    goto L7; // [108] 144
L4: 

    /** 				return {0, ix-1}*/
    _25753 = _ix_49253 - 1;
    if ((long)((unsigned long)_25753 +(unsigned long) HIGH_BITS) >= 0){
        _25753 = NewDouble((double)_25753);
    }
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = _25753;
    _25754 = MAKE_SEQ(_1);
    _25753 = NOVALUE;
    DeRef(_arg_49258);
    DeRefDS(_args_49254);
    DeRef(_25750);
    _25750 = NOVALUE;
    DeRef(_25751);
    _25751 = NOVALUE;
    DeRef(_25752);
    _25752 = NOVALUE;
    return _25754;
    goto L7; // [126] 144
L3: 

    /** 			return { 0, ix-1 }*/
    _25755 = _ix_49253 - 1;
    if ((long)((unsigned long)_25755 +(unsigned long) HIGH_BITS) >= 0){
        _25755 = NewDouble((double)_25755);
    }
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = _25755;
    _25756 = MAKE_SEQ(_1);
    _25755 = NOVALUE;
    DeRef(_arg_49258);
    DeRefDS(_args_49254);
    DeRef(_25750);
    _25750 = NOVALUE;
    DeRef(_25751);
    _25751 = NOVALUE;
    DeRef(_25752);
    _25752 = NOVALUE;
    DeRef(_25754);
    _25754 = NOVALUE;
    return _25756;
L7: 

    /** 		ix += 1*/
    _ix_49253 = _ix_49253 + 1;
    DeRef(_arg_49258);
    _arg_49258 = NOVALUE;

    /** 	end while*/
    goto L1; // [154] 10
L2: 

    /** 	return {0, ix-1}*/
    _25758 = _ix_49253 - 1;
    if ((long)((unsigned long)_25758 +(unsigned long) HIGH_BITS) >= 0){
        _25758 = NewDouble((double)_25758);
    }
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = _25758;
    _25759 = MAKE_SEQ(_1);
    _25758 = NOVALUE;
    DeRefDS(_args_49254);
    DeRef(_25750);
    _25750 = NOVALUE;
    DeRef(_25751);
    _25751 = NOVALUE;
    DeRef(_25752);
    _25752 = NOVALUE;
    DeRef(_25754);
    _25754 = NOVALUE;
    DeRef(_25756);
    _25756 = NOVALUE;
    return _25759;
    ;
}


int _43expand_config_options(int _args_49288)
{
    int _idx_49289 = NOVALUE;
    int _next_idx_49290 = NOVALUE;
    int _files_49291 = NOVALUE;
    int _cmd_1_2_49292 = NOVALUE;
    int _25782 = NOVALUE;
    int _25781 = NOVALUE;
    int _25780 = NOVALUE;
    int _25779 = NOVALUE;
    int _25778 = NOVALUE;
    int _25777 = NOVALUE;
    int _25776 = NOVALUE;
    int _25775 = NOVALUE;
    int _25774 = NOVALUE;
    int _25769 = NOVALUE;
    int _25767 = NOVALUE;
    int _25766 = NOVALUE;
    int _25765 = NOVALUE;
    int _25763 = NOVALUE;
    int _25762 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer idx = 1*/
    _idx_49289 = 1;

    /** 	sequence files = {}*/
    RefDS(_22023);
    DeRef(_files_49291);
    _files_49291 = _22023;

    /** 	sequence cmd_1_2 = args[1..2]*/
    rhs_slice_target = (object_ptr)&_cmd_1_2_49292;
    RHS_Slice(_args_49288, 1, 2);

    /** 	args = remove( args, 1, 2 )*/
    {
        s1_ptr assign_space = SEQ_PTR(_args_49288);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(1)) ? 1 : (long)(DBL_PTR(1)->dbl);
        int stop = (IS_ATOM_INT(2)) ? 2 : (long)(DBL_PTR(2)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_args_49288), start, &_args_49288 );
            }
            else Tail(SEQ_PTR(_args_49288), stop+1, &_args_49288);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_args_49288), start, &_args_49288);
        }
        else {
            assign_slice_seq = &assign_space;
            _args_49288 = Remove_elements(start, stop, (SEQ_PTR(_args_49288)->ref == 1));
        }
    }

    /** 	while idx with entry do*/
    goto L1; // [31] 94
L2: 
    if (_idx_49289 == 0)
    {
        goto L3; // [34] 114
    }
    else{
    }

    /** 		if equal(upper(args[idx]), "-C") then*/
    _2 = (int)SEQ_PTR(_args_49288);
    _25762 = (int)*(((s1_ptr)_2)->base + _idx_49289);
    Ref(_25762);
    _25763 = _14upper(_25762);
    _25762 = NOVALUE;
    if (_25763 == _25764)
    _25765 = 1;
    else if (IS_ATOM_INT(_25763) && IS_ATOM_INT(_25764))
    _25765 = 0;
    else
    _25765 = (compare(_25763, _25764) == 0);
    DeRef(_25763);
    _25763 = NOVALUE;
    if (_25765 == 0)
    {
        _25765 = NOVALUE;
        goto L4; // [51] 82
    }
    else{
        _25765 = NOVALUE;
    }

    /** 			files = append( files, args[idx+1] )*/
    _25766 = _idx_49289 + 1;
    _2 = (int)SEQ_PTR(_args_49288);
    _25767 = (int)*(((s1_ptr)_2)->base + _25766);
    Ref(_25767);
    Append(&_files_49291, _files_49291, _25767);
    _25767 = NOVALUE;

    /** 			args = remove( args, idx, idx + 1 )*/
    _25769 = _idx_49289 + 1;
    if (_25769 > MAXINT){
        _25769 = NewDouble((double)_25769);
    }
    {
        s1_ptr assign_space = SEQ_PTR(_args_49288);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_idx_49289)) ? _idx_49289 : (long)(DBL_PTR(_idx_49289)->dbl);
        int stop = (IS_ATOM_INT(_25769)) ? _25769 : (long)(DBL_PTR(_25769)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_args_49288), start, &_args_49288 );
            }
            else Tail(SEQ_PTR(_args_49288), stop+1, &_args_49288);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_args_49288), start, &_args_49288);
        }
        else {
            assign_slice_seq = &assign_space;
            _args_49288 = Remove_elements(start, stop, (SEQ_PTR(_args_49288)->ref == 1));
        }
    }
    DeRef(_25769);
    _25769 = NOVALUE;
    goto L5; // [79] 91
L4: 

    /** 			idx = next_idx[2]*/
    _2 = (int)SEQ_PTR(_next_idx_49290);
    _idx_49289 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_idx_49289))
    _idx_49289 = (long)DBL_PTR(_idx_49289)->dbl;
L5: 

    /** 	entry*/
L1: 

    /** 		next_idx = find_next_opt( idx, args )*/
    RefDS(_args_49288);
    _0 = _next_idx_49290;
    _next_idx_49290 = _43find_next_opt(_idx_49289, _args_49288);
    DeRef(_0);

    /** 		idx = next_idx[1]*/
    _2 = (int)SEQ_PTR(_next_idx_49290);
    _idx_49289 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_idx_49289))
    _idx_49289 = (long)DBL_PTR(_idx_49289)->dbl;

    /** 	end while*/
    goto L2; // [111] 34
L3: 

    /** 	return cmd_1_2 & merge_parameters( GetDefaultArgs( files ), args[1..next_idx[2]], options, 1 ) & args[next_idx[2]+1..$]*/
    RefDS(_files_49291);
    _25774 = _42GetDefaultArgs(_files_49291);
    _2 = (int)SEQ_PTR(_next_idx_49290);
    _25775 = (int)*(((s1_ptr)_2)->base + 2);
    rhs_slice_target = (object_ptr)&_25776;
    RHS_Slice(_args_49288, 1, _25775);
    RefDS(_43options_48959);
    _25777 = _43merge_parameters(_25774, _25776, _43options_48959, 1);
    _25774 = NOVALUE;
    _25776 = NOVALUE;
    _2 = (int)SEQ_PTR(_next_idx_49290);
    _25778 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_25778)) {
        _25779 = _25778 + 1;
        if (_25779 > MAXINT){
            _25779 = NewDouble((double)_25779);
        }
    }
    else
    _25779 = binary_op(PLUS, 1, _25778);
    _25778 = NOVALUE;
    if (IS_SEQUENCE(_args_49288)){
            _25780 = SEQ_PTR(_args_49288)->length;
    }
    else {
        _25780 = 1;
    }
    rhs_slice_target = (object_ptr)&_25781;
    RHS_Slice(_args_49288, _25779, _25780);
    {
        int concat_list[3];

        concat_list[0] = _25781;
        concat_list[1] = _25777;
        concat_list[2] = _cmd_1_2_49292;
        Concat_N((object_ptr)&_25782, concat_list, 3);
    }
    DeRefDS(_25781);
    _25781 = NOVALUE;
    DeRef(_25777);
    _25777 = NOVALUE;
    DeRefDS(_args_49288);
    DeRefDS(_next_idx_49290);
    DeRefDS(_files_49291);
    DeRefDS(_cmd_1_2_49292);
    DeRef(_25766);
    _25766 = NOVALUE;
    _25775 = NOVALUE;
    DeRef(_25779);
    _25779 = NOVALUE;
    return _25782;
    ;
}


void _43handle_common_options(int _opts_49323)
{
    int _opt_keys_49324 = NOVALUE;
    int _option_w_49326 = NOVALUE;
    int _key_49330 = NOVALUE;
    int _val_49332 = NOVALUE;
    int _this_warn_49378 = NOVALUE;
    int _auto_add_warn_49380 = NOVALUE;
    int _n_49386 = NOVALUE;
    int _this_warn_49409 = NOVALUE;
    int _auto_add_warn_49411 = NOVALUE;
    int _n_49417 = NOVALUE;
    int _has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_618_49453 = NOVALUE;
    int _prompt_inlined_maybe_any_key_at_615_49452 = NOVALUE;
    int _has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_692_49465 = NOVALUE;
    int _prompt_inlined_maybe_any_key_at_689_49464 = NOVALUE;
    int _25835 = NOVALUE;
    int _25834 = NOVALUE;
    int _25833 = NOVALUE;
    int _25832 = NOVALUE;
    int _25831 = NOVALUE;
    int _25830 = NOVALUE;
    int _25829 = NOVALUE;
    int _25828 = NOVALUE;
    int _25827 = NOVALUE;
    int _25825 = NOVALUE;
    int _25823 = NOVALUE;
    int _25822 = NOVALUE;
    int _25821 = NOVALUE;
    int _25816 = NOVALUE;
    int _25814 = NOVALUE;
    int _25812 = NOVALUE;
    int _25809 = NOVALUE;
    int _25808 = NOVALUE;
    int _25803 = NOVALUE;
    int _25801 = NOVALUE;
    int _25799 = NOVALUE;
    int _25797 = NOVALUE;
    int _25796 = NOVALUE;
    int _25795 = NOVALUE;
    int _25794 = NOVALUE;
    int _25793 = NOVALUE;
    int _25792 = NOVALUE;
    int _25790 = NOVALUE;
    int _25789 = NOVALUE;
    int _25784 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence opt_keys = m:keys(opts)*/
    Ref(_opts_49323);
    _0 = _opt_keys_49324;
    _opt_keys_49324 = _28keys(_opts_49323, 0);
    DeRef(_0);

    /** 	integer option_w = 0*/
    _option_w_49326 = 0;

    /** 	for idx = 1 to length(opt_keys) do*/
    if (IS_SEQUENCE(_opt_keys_49324)){
            _25784 = SEQ_PTR(_opt_keys_49324)->length;
    }
    else {
        _25784 = 1;
    }
    {
        int _idx_49328;
        _idx_49328 = 1;
L1: 
        if (_idx_49328 > _25784){
            goto L2; // [20] 731
        }

        /** 		sequence key = opt_keys[idx]*/
        DeRef(_key_49330);
        _2 = (int)SEQ_PTR(_opt_keys_49324);
        _key_49330 = (int)*(((s1_ptr)_2)->base + _idx_49328);
        Ref(_key_49330);

        /** 		object val = m:get(opts, key)*/
        Ref(_opts_49323);
        RefDS(_key_49330);
        _0 = _val_49332;
        _val_49332 = _28get(_opts_49323, _key_49330, 0);
        DeRef(_0);

        /** 		switch key do*/
        _1 = find(_key_49330, _25787);
        switch ( _1 ){ 

            /** 			case "i" then*/
            case 1:

            /** 				for i = 1 to length(val) do*/
            if (IS_SEQUENCE(_val_49332)){
                    _25789 = SEQ_PTR(_val_49332)->length;
            }
            else {
                _25789 = 1;
            }
            {
                int _i_49338;
                _i_49338 = 1;
L3: 
                if (_i_49338 > _25789){
                    goto L4; // [59] 82
                }

                /** 					add_include_directory(val[i])*/
                _2 = (int)SEQ_PTR(_val_49332);
                _25790 = (int)*(((s1_ptr)_2)->base + _i_49338);
                Ref(_25790);
                _42add_include_directory(_25790);
                _25790 = NOVALUE;

                /** 				end for*/
                _i_49338 = _i_49338 + 1;
                goto L3; // [77] 66
L4: 
                ;
            }
            goto L5; // [82] 722

            /** 			case "d" then*/
            case 2:

            /** 				OpDefines &= val*/
            if (IS_SEQUENCE(_35OpDefines_16317) && IS_ATOM(_val_49332)) {
                Ref(_val_49332);
                Append(&_35OpDefines_16317, _35OpDefines_16317, _val_49332);
            }
            else if (IS_ATOM(_35OpDefines_16317) && IS_SEQUENCE(_val_49332)) {
            }
            else {
                Concat((object_ptr)&_35OpDefines_16317, _35OpDefines_16317, _val_49332);
            }
            goto L5; // [98] 722

            /** 			case "batch" then*/
            case 3:

            /** 				batch_job = 1*/
            _35batch_job_16257 = 1;
            goto L5; // [111] 722

            /** 			case "test" then*/
            case 4:

            /** 				test_only = 1*/
            _35test_only_16256 = 1;
            goto L5; // [124] 722

            /** 			case "strict" then*/
            case 5:

            /** 				Strict_is_on = 1*/
            _35Strict_is_on_16309 = 1;
            goto L5; // [137] 722

            /** 			case "p" then*/
            case 6:

            /** 				for i = 1 to length(val) do*/
            if (IS_SEQUENCE(_val_49332)){
                    _25792 = SEQ_PTR(_val_49332)->length;
            }
            else {
                _25792 = 1;
            }
            {
                int _i_49353;
                _i_49353 = 1;
L6: 
                if (_i_49353 > _25792){
                    goto L7; // [148] 173
                }

                /** 					add_preprocessor(val[i])*/
                _2 = (int)SEQ_PTR(_val_49332);
                _25793 = (int)*(((s1_ptr)_2)->base + _i_49353);
                Ref(_25793);
                _64add_preprocessor(_25793, 0, 0);
                _25793 = NOVALUE;

                /** 				end for*/
                _i_49353 = _i_49353 + 1;
                goto L6; // [168] 155
L7: 
                ;
            }
            goto L5; // [173] 722

            /** 			case "pf" then*/
            case 7:

            /** 				force_preprocessor = 1*/
            _36force_preprocessor_15260 = 1;
            goto L5; // [186] 722

            /** 			case "l" then*/
            case 8:

            /** 				for i = 1 to length(val) do*/
            if (IS_SEQUENCE(_val_49332)){
                    _25794 = SEQ_PTR(_val_49332)->length;
            }
            else {
                _25794 = 1;
            }
            {
                int _i_49361;
                _i_49361 = 1;
L8: 
                if (_i_49361 > _25794){
                    goto L9; // [197] 238
                }

                /** 					LocalizeQual = append(LocalizeQual, (filter(lower(val[i]), STDFLTR_ALPHA)))*/
                _2 = (int)SEQ_PTR(_val_49332);
                _25795 = (int)*(((s1_ptr)_2)->base + _i_49361);
                Ref(_25795);
                _25796 = _14lower(_25795);
                _25795 = NOVALUE;
                RefDS(_22023);
                RefDS(_5);
                _25797 = _23filter(_25796, _23STDFLTR_ALPHA_5094, _22023, _5);
                _25796 = NOVALUE;
                Ref(_25797);
                Append(&_36LocalizeQual_15261, _36LocalizeQual_15261, _25797);
                DeRef(_25797);
                _25797 = NOVALUE;

                /** 				end for*/
                _i_49361 = _i_49361 + 1;
                goto L8; // [233] 204
L9: 
                ;
            }
            goto L5; // [238] 722

            /** 			case "ldb" then*/
            case 9:

            /** 				LocalDB = val*/
            Ref(_val_49332);
            DeRef(_36LocalDB_15262);
            _36LocalDB_15262 = _val_49332;
            goto L5; // [251] 722

            /** 			case "w" then*/
            case 10:

            /** 				for i = 1 to length(val) do*/
            if (IS_SEQUENCE(_val_49332)){
                    _25799 = SEQ_PTR(_val_49332)->length;
            }
            else {
                _25799 = 1;
            }
            {
                int _i_49376;
                _i_49376 = 1;
LA: 
                if (_i_49376 > _25799){
                    goto LB; // [262] 392
                }

                /** 					sequence this_warn = val[i]*/
                DeRef(_this_warn_49378);
                _2 = (int)SEQ_PTR(_val_49332);
                _this_warn_49378 = (int)*(((s1_ptr)_2)->base + _i_49376);
                Ref(_this_warn_49378);

                /** 					integer auto_add_warn = 0*/
                _auto_add_warn_49380 = 0;

                /** 					if this_warn[1] = '+' then*/
                _2 = (int)SEQ_PTR(_this_warn_49378);
                _25801 = (int)*(((s1_ptr)_2)->base + 1);
                if (binary_op_a(NOTEQ, _25801, 43)){
                    _25801 = NOVALUE;
                    goto LC; // [288] 308
                }
                _25801 = NOVALUE;

                /** 						auto_add_warn = 1*/
                _auto_add_warn_49380 = 1;

                /** 						this_warn = this_warn[2 .. $]*/
                if (IS_SEQUENCE(_this_warn_49378)){
                        _25803 = SEQ_PTR(_this_warn_49378)->length;
                }
                else {
                    _25803 = 1;
                }
                rhs_slice_target = (object_ptr)&_this_warn_49378;
                RHS_Slice(_this_warn_49378, 2, _25803);
LC: 

                /** 					integer n = find(this_warn, warning_names)*/
                _n_49386 = find_from(_this_warn_49378, _35warning_names_16288, 1);

                /** 					if n != 0 then*/
                if (_n_49386 == 0)
                goto LD; // [319] 383

                /** 						if auto_add_warn or option_w = 1 then*/
                if (_auto_add_warn_49380 != 0) {
                    goto LE; // [325] 338
                }
                _25808 = (_option_w_49326 == 1);
                if (_25808 == 0)
                {
                    DeRef(_25808);
                    _25808 = NOVALUE;
                    goto LF; // [334] 357
                }
                else{
                    DeRef(_25808);
                    _25808 = NOVALUE;
                }
LE: 

                /** 							OpWarning = or_bits(OpWarning, warning_flags[n])*/
                _2 = (int)SEQ_PTR(_35warning_flags_16286);
                _25809 = (int)*(((s1_ptr)_2)->base + _n_49386);
                {unsigned long tu;
                     tu = (unsigned long)_35OpWarning_16311 | (unsigned long)_25809;
                     _35OpWarning_16311 = MAKE_UINT(tu);
                }
                _25809 = NOVALUE;
                if (!IS_ATOM_INT(_35OpWarning_16311)) {
                    _1 = (long)(DBL_PTR(_35OpWarning_16311)->dbl);
                    DeRefDS(_35OpWarning_16311);
                    _35OpWarning_16311 = _1;
                }
                goto L10; // [354] 373
LF: 

                /** 							option_w = 1*/
                _option_w_49326 = 1;

                /** 							OpWarning = warning_flags[n]*/
                _2 = (int)SEQ_PTR(_35warning_flags_16286);
                _35OpWarning_16311 = (int)*(((s1_ptr)_2)->base + _n_49386);
L10: 

                /** 						prev_OpWarning = OpWarning*/
                _35prev_OpWarning_16312 = _35OpWarning_16311;
LD: 
                DeRef(_this_warn_49378);
                _this_warn_49378 = NOVALUE;

                /** 				end for*/
                _i_49376 = _i_49376 + 1;
                goto LA; // [387] 269
LB: 
                ;
            }
            goto L5; // [392] 722

            /** 			case "x" then*/
            case 11:

            /** 				for i = 1 to length(val) do*/
            if (IS_SEQUENCE(_val_49332)){
                    _25812 = SEQ_PTR(_val_49332)->length;
            }
            else {
                _25812 = 1;
            }
            {
                int _i_49407;
                _i_49407 = 1;
L11: 
                if (_i_49407 > _25812){
                    goto L12; // [403] 542
                }

                /** 					sequence this_warn = val[i]*/
                DeRef(_this_warn_49409);
                _2 = (int)SEQ_PTR(_val_49332);
                _this_warn_49409 = (int)*(((s1_ptr)_2)->base + _i_49407);
                Ref(_this_warn_49409);

                /** 					integer auto_add_warn = 0*/
                _auto_add_warn_49411 = 0;

                /** 					if this_warn[1] = '+' then*/
                _2 = (int)SEQ_PTR(_this_warn_49409);
                _25814 = (int)*(((s1_ptr)_2)->base + 1);
                if (binary_op_a(NOTEQ, _25814, 43)){
                    _25814 = NOVALUE;
                    goto L13; // [429] 449
                }
                _25814 = NOVALUE;

                /** 						auto_add_warn = 1*/
                _auto_add_warn_49411 = 1;

                /** 						this_warn = this_warn[2 .. $]*/
                if (IS_SEQUENCE(_this_warn_49409)){
                        _25816 = SEQ_PTR(_this_warn_49409)->length;
                }
                else {
                    _25816 = 1;
                }
                rhs_slice_target = (object_ptr)&_this_warn_49409;
                RHS_Slice(_this_warn_49409, 2, _25816);
L13: 

                /** 					integer n = find(this_warn, warning_names)*/
                _n_49417 = find_from(_this_warn_49409, _35warning_names_16288, 1);

                /** 					if n != 0 then*/
                if (_n_49417 == 0)
                goto L14; // [460] 533

                /** 						if auto_add_warn or option_w = -1 then*/
                if (_auto_add_warn_49411 != 0) {
                    goto L15; // [466] 479
                }
                _25821 = (_option_w_49326 == -1);
                if (_25821 == 0)
                {
                    DeRef(_25821);
                    _25821 = NOVALUE;
                    goto L16; // [475] 501
                }
                else{
                    DeRef(_25821);
                    _25821 = NOVALUE;
                }
L15: 

                /** 							OpWarning = and_bits(OpWarning, not_bits(warning_flags[n]))*/
                _2 = (int)SEQ_PTR(_35warning_flags_16286);
                _25822 = (int)*(((s1_ptr)_2)->base + _n_49417);
                _25823 = not_bits(_25822);
                _25822 = NOVALUE;
                if (IS_ATOM_INT(_25823)) {
                    {unsigned long tu;
                         tu = (unsigned long)_35OpWarning_16311 & (unsigned long)_25823;
                         _35OpWarning_16311 = MAKE_UINT(tu);
                    }
                }
                else {
                    temp_d.dbl = (double)_35OpWarning_16311;
                    _35OpWarning_16311 = Dand_bits(&temp_d, DBL_PTR(_25823));
                }
                DeRef(_25823);
                _25823 = NOVALUE;
                if (!IS_ATOM_INT(_35OpWarning_16311)) {
                    _1 = (long)(DBL_PTR(_35OpWarning_16311)->dbl);
                    DeRefDS(_35OpWarning_16311);
                    _35OpWarning_16311 = _1;
                }
                goto L17; // [498] 523
L16: 

                /** 							option_w = -1*/
                _option_w_49326 = -1;

                /** 							OpWarning = all_warning_flag - warning_flags[n]*/
                _2 = (int)SEQ_PTR(_35warning_flags_16286);
                _25825 = (int)*(((s1_ptr)_2)->base + _n_49417);
                _35OpWarning_16311 = 32767 - _25825;
                _25825 = NOVALUE;
L17: 

                /** 						prev_OpWarning = OpWarning*/
                _35prev_OpWarning_16312 = _35OpWarning_16311;
L14: 
                DeRef(_this_warn_49409);
                _this_warn_49409 = NOVALUE;

                /** 				end for*/
                _i_49407 = _i_49407 + 1;
                goto L11; // [537] 410
L12: 
                ;
            }
            goto L5; // [542] 722

            /** 			case "wf" then*/
            case 12:

            /** 				TempWarningName = val*/
            Ref(_val_49332);
            DeRef(_35TempWarningName_16258);
            _35TempWarningName_16258 = _val_49332;

            /** 			  	error:warning_file(TempWarningName)*/
            Ref(_35TempWarningName_16258);
            _7warning_file(_35TempWarningName_16258);
            goto L5; // [560] 722

            /** 			case "v", "version" then*/
            case 13:
            case 14:

            /** 				show_banner()*/
            _43show_banner();

            /** 				if not batch_job and not test_only then*/
            _25827 = (_35batch_job_16257 == 0);
            if (_25827 == 0) {
                goto L18; // [579] 632
            }
            _25829 = (_35test_only_16256 == 0);
            if (_25829 == 0)
            {
                DeRef(_25829);
                _25829 = NOVALUE;
                goto L18; // [589] 632
            }
            else{
                DeRef(_25829);
                _25829 = NOVALUE;
            }

            /** 					console:maybe_any_key(GetMsgText(278,0), 2)*/
            RefDS(_22023);
            _25830 = _45GetMsgText(278, 0, _22023);
            DeRef(_prompt_inlined_maybe_any_key_at_615_49452);
            _prompt_inlined_maybe_any_key_at_615_49452 = _25830;
            _25830 = NOVALUE;

            /** 	if not has_console() then*/

            /** 	return machine_func(M_HAS_CONSOLE, 0)*/
            DeRef(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_618_49453);
            _has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_618_49453 = machine(99, 0);
            if (IS_ATOM_INT(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_618_49453)) {
                if (_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_618_49453 != 0){
                    goto L19; // [614] 629
                }
            }
            else {
                if (DBL_PTR(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_618_49453)->dbl != 0.0){
                    goto L19; // [614] 629
                }
            }

            /** 		any_key(prompt, con)*/
            Ref(_prompt_inlined_maybe_any_key_at_615_49452);
            _5any_key(_prompt_inlined_maybe_any_key_at_615_49452, 2);

            /** end procedure*/
            goto L19; // [626] 629
L19: 
            DeRef(_prompt_inlined_maybe_any_key_at_615_49452);
            _prompt_inlined_maybe_any_key_at_615_49452 = NOVALUE;
            DeRef(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_618_49453);
            _has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_618_49453 = NOVALUE;
L18: 

            /** 				abort(0)*/
            UserCleanup(0);
            goto L5; // [636] 722

            /** 			case "copyright" then*/
            case 15:

            /** 				show_copyrights()*/
            _43show_copyrights();

            /** 				if not batch_job and not test_only then*/
            _25831 = (_35batch_job_16257 == 0);
            if (_25831 == 0) {
                goto L1A; // [653] 706
            }
            _25833 = (_35test_only_16256 == 0);
            if (_25833 == 0)
            {
                DeRef(_25833);
                _25833 = NOVALUE;
                goto L1A; // [663] 706
            }
            else{
                DeRef(_25833);
                _25833 = NOVALUE;
            }

            /** 					console:maybe_any_key(GetMsgText(278,0), 2)*/
            RefDS(_22023);
            _25834 = _45GetMsgText(278, 0, _22023);
            DeRef(_prompt_inlined_maybe_any_key_at_689_49464);
            _prompt_inlined_maybe_any_key_at_689_49464 = _25834;
            _25834 = NOVALUE;

            /** 	if not has_console() then*/

            /** 	return machine_func(M_HAS_CONSOLE, 0)*/
            DeRef(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_692_49465);
            _has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_692_49465 = machine(99, 0);
            if (IS_ATOM_INT(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_692_49465)) {
                if (_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_692_49465 != 0){
                    goto L1B; // [688] 703
                }
            }
            else {
                if (DBL_PTR(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_692_49465)->dbl != 0.0){
                    goto L1B; // [688] 703
                }
            }

            /** 		any_key(prompt, con)*/
            Ref(_prompt_inlined_maybe_any_key_at_689_49464);
            _5any_key(_prompt_inlined_maybe_any_key_at_689_49464, 2);

            /** end procedure*/
            goto L1B; // [700] 703
L1B: 
            DeRef(_prompt_inlined_maybe_any_key_at_689_49464);
            _prompt_inlined_maybe_any_key_at_689_49464 = NOVALUE;
            DeRef(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_692_49465);
            _has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_692_49465 = NOVALUE;
L1A: 

            /** 				abort(0)*/
            UserCleanup(0);
            goto L5; // [710] 722

            /** 			case "eudir" then*/
            case 16:

            /** 				set_eudir( val )*/
            Ref(_val_49332);
            _36set_eudir(_val_49332);
        ;}L5: 
        DeRef(_key_49330);
        _key_49330 = NOVALUE;
        DeRef(_val_49332);
        _val_49332 = NOVALUE;

        /** 	end for*/
        _idx_49328 = _idx_49328 + 1;
        goto L1; // [726] 27
L2: 
        ;
    }

    /** 	if length(LocalizeQual) = 0 then*/
    if (IS_SEQUENCE(_36LocalizeQual_15261)){
            _25835 = SEQ_PTR(_36LocalizeQual_15261)->length;
    }
    else {
        _25835 = 1;
    }
    if (_25835 != 0)
    goto L1C; // [738] 751

    /** 		LocalizeQual = {"en"}*/
    _0 = _36LocalizeQual_15261;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_25837);
    *((int *)(_2+4)) = _25837;
    _36LocalizeQual_15261 = MAKE_SEQ(_1);
    DeRefDS(_0);
L1C: 

    /** end procedure*/
    DeRef(_opts_49323);
    DeRef(_opt_keys_49324);
    DeRef(_25827);
    _25827 = NOVALUE;
    DeRef(_25831);
    _25831 = NOVALUE;
    return;
    ;
}


void _43finalize_command_line(int _opts_49477)
{
    int _extras_49484 = NOVALUE;
    int _pairs_49489 = NOVALUE;
    int _pair_49494 = NOVALUE;
    int _25867 = NOVALUE;
    int _25865 = NOVALUE;
    int _25862 = NOVALUE;
    int _25861 = NOVALUE;
    int _25860 = NOVALUE;
    int _25859 = NOVALUE;
    int _25858 = NOVALUE;
    int _25857 = NOVALUE;
    int _25856 = NOVALUE;
    int _25855 = NOVALUE;
    int _25854 = NOVALUE;
    int _25853 = NOVALUE;
    int _25852 = NOVALUE;
    int _25851 = NOVALUE;
    int _25850 = NOVALUE;
    int _25849 = NOVALUE;
    int _25848 = NOVALUE;
    int _25847 = NOVALUE;
    int _25846 = NOVALUE;
    int _25845 = NOVALUE;
    int _25843 = NOVALUE;
    int _25840 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if Strict_is_on then -- overrides any -W/-X switches*/
    if (_35Strict_is_on_16309 == 0)
    {
        goto L1; // [5] 27
    }
    else{
    }

    /** 		OpWarning = all_warning_flag*/
    _35OpWarning_16311 = 32767;

    /** 		prev_OpWarning = OpWarning*/
    _35prev_OpWarning_16312 = 32767;
L1: 

    /** 	sequence extras = m:get(opts, cmdline:EXTRAS)*/
    Ref(_opts_49477);
    RefDS(_4EXTRAS_14119);
    _0 = _extras_49484;
    _extras_49484 = _28get(_opts_49477, _4EXTRAS_14119, 0);
    DeRef(_0);

    /** 	if length(extras) > 0 then*/
    if (IS_SEQUENCE(_extras_49484)){
            _25840 = SEQ_PTR(_extras_49484)->length;
    }
    else {
        _25840 = 1;
    }
    if (_25840 <= 0)
    goto L2; // [44] 270

    /** 		sequence pairs = m:pairs( opts )*/
    Ref(_opts_49477);
    _0 = _pairs_49489;
    _pairs_49489 = _28pairs(_opts_49477, 0);
    DeRef(_0);

    /** 		for i = 1 to length( pairs ) do*/
    if (IS_SEQUENCE(_pairs_49489)){
            _25843 = SEQ_PTR(_pairs_49489)->length;
    }
    else {
        _25843 = 1;
    }
    {
        int _i_49492;
        _i_49492 = 1;
L3: 
        if (_i_49492 > _25843){
            goto L4; // [62] 237
        }

        /** 			sequence pair = pairs[i]*/
        DeRef(_pair_49494);
        _2 = (int)SEQ_PTR(_pairs_49489);
        _pair_49494 = (int)*(((s1_ptr)_2)->base + _i_49492);
        Ref(_pair_49494);

        /** 			if equal( pair[1], cmdline:EXTRAS ) then*/
        _2 = (int)SEQ_PTR(_pair_49494);
        _25845 = (int)*(((s1_ptr)_2)->base + 1);
        if (_25845 == _4EXTRAS_14119)
        _25846 = 1;
        else if (IS_ATOM_INT(_25845) && IS_ATOM_INT(_4EXTRAS_14119))
        _25846 = 0;
        else
        _25846 = (compare(_25845, _4EXTRAS_14119) == 0);
        _25845 = NOVALUE;
        if (_25846 == 0)
        {
            _25846 = NOVALUE;
            goto L5; // [89] 99
        }
        else{
            _25846 = NOVALUE;
        }

        /** 				continue*/
        DeRefDS(_pair_49494);
        _pair_49494 = NOVALUE;
        goto L6; // [96] 232
L5: 

        /** 			pair[1] = prepend( pair[1], '-' )*/
        _2 = (int)SEQ_PTR(_pair_49494);
        _25847 = (int)*(((s1_ptr)_2)->base + 1);
        Prepend(&_25848, _25847, 45);
        _25847 = NOVALUE;
        _2 = (int)SEQ_PTR(_pair_49494);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _pair_49494 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 1);
        _1 = *(int *)_2;
        *(int *)_2 = _25848;
        if( _1 != _25848 ){
            DeRef(_1);
        }
        _25848 = NOVALUE;

        /** 			if sequence( pair[2] ) then*/
        _2 = (int)SEQ_PTR(_pair_49494);
        _25849 = (int)*(((s1_ptr)_2)->base + 2);
        _25850 = IS_SEQUENCE(_25849);
        _25849 = NOVALUE;
        if (_25850 == 0)
        {
            _25850 = NOVALUE;
            goto L7; // [122] 215
        }
        else{
            _25850 = NOVALUE;
        }

        /** 				if length( pair[2] ) and sequence( pair[2][1] ) then*/
        _2 = (int)SEQ_PTR(_pair_49494);
        _25851 = (int)*(((s1_ptr)_2)->base + 2);
        if (IS_SEQUENCE(_25851)){
                _25852 = SEQ_PTR(_25851)->length;
        }
        else {
            _25852 = 1;
        }
        _25851 = NOVALUE;
        if (_25852 == 0) {
            goto L8; // [134] 203
        }
        _2 = (int)SEQ_PTR(_pair_49494);
        _25854 = (int)*(((s1_ptr)_2)->base + 2);
        _2 = (int)SEQ_PTR(_25854);
        _25855 = (int)*(((s1_ptr)_2)->base + 1);
        _25854 = NOVALUE;
        _25856 = IS_SEQUENCE(_25855);
        _25855 = NOVALUE;
        if (_25856 == 0)
        {
            _25856 = NOVALUE;
            goto L8; // [150] 203
        }
        else{
            _25856 = NOVALUE;
        }

        /** 					for j = 1 to length( pair[2] ) do*/
        _2 = (int)SEQ_PTR(_pair_49494);
        _25857 = (int)*(((s1_ptr)_2)->base + 2);
        if (IS_SEQUENCE(_25857)){
                _25858 = SEQ_PTR(_25857)->length;
        }
        else {
            _25858 = 1;
        }
        _25857 = NOVALUE;
        {
            int _j_49512;
            _j_49512 = 1;
L9: 
            if (_j_49512 > _25858){
                goto LA; // [162] 200
            }

            /** 						switches &= { pair[1], pair[2][j] }*/
            _2 = (int)SEQ_PTR(_pair_49494);
            _25859 = (int)*(((s1_ptr)_2)->base + 1);
            _2 = (int)SEQ_PTR(_pair_49494);
            _25860 = (int)*(((s1_ptr)_2)->base + 2);
            _2 = (int)SEQ_PTR(_25860);
            _25861 = (int)*(((s1_ptr)_2)->base + _j_49512);
            _25860 = NOVALUE;
            Ref(_25861);
            Ref(_25859);
            _1 = NewS1(2);
            _2 = (int)((s1_ptr)_1)->base;
            ((int *)_2)[1] = _25859;
            ((int *)_2)[2] = _25861;
            _25862 = MAKE_SEQ(_1);
            _25861 = NOVALUE;
            _25859 = NOVALUE;
            Concat((object_ptr)&_43switches_48856, _43switches_48856, _25862);
            DeRefDS(_25862);
            _25862 = NOVALUE;

            /** 					end for*/
            _j_49512 = _j_49512 + 1;
            goto L9; // [195] 169
LA: 
            ;
        }
        goto LB; // [200] 228
L8: 

        /** 					switches &= pair*/
        Concat((object_ptr)&_43switches_48856, _43switches_48856, _pair_49494);
        goto LB; // [212] 228
L7: 

        /** 				switches = append( switches, pair[1] )*/
        _2 = (int)SEQ_PTR(_pair_49494);
        _25865 = (int)*(((s1_ptr)_2)->base + 1);
        Ref(_25865);
        Append(&_43switches_48856, _43switches_48856, _25865);
        _25865 = NOVALUE;
LB: 
        DeRef(_pair_49494);
        _pair_49494 = NOVALUE;

        /** 		end for*/
L6: 
        _i_49492 = _i_49492 + 1;
        goto L3; // [232] 69
L4: 
        ;
    }

    /** 		Argv = Argv[2..3] & extras*/
    rhs_slice_target = (object_ptr)&_25867;
    RHS_Slice(_35Argv_16255, 2, 3);
    Concat((object_ptr)&_35Argv_16255, _25867, _extras_49484);
    DeRefDS(_25867);
    _25867 = NOVALUE;
    DeRef(_25867);
    _25867 = NOVALUE;

    /** 		Argc = length(Argv)*/
    if (IS_SEQUENCE(_35Argv_16255)){
            _35Argc_16254 = SEQ_PTR(_35Argv_16255)->length;
    }
    else {
        _35Argc_16254 = 1;
    }

    /** 		src_name = extras[1]*/
    DeRef(_43src_name_48855);
    _2 = (int)SEQ_PTR(_extras_49484);
    _43src_name_48855 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_43src_name_48855);
L2: 
    DeRef(_pairs_49489);
    _pairs_49489 = NOVALUE;

    /** end procedure*/
    DeRef(_opts_49477);
    DeRef(_extras_49484);
    _25851 = NOVALUE;
    _25857 = NOVALUE;
    return;
    ;
}



// 0xE72BE926
