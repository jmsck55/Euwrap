// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int _42convert_from_OEM(int _s_49555)
{
    int _ls_49556 = NOVALUE;
    int _rc_49557 = NOVALUE;
    int _25893 = NOVALUE;
    int _25892 = NOVALUE;
    int _25890 = NOVALUE;
    int _25889 = NOVALUE;
    int _25886 = NOVALUE;
    int _25885 = NOVALUE;
    int _0, _1, _2;
    

    /** 	ls=length(s)*/
    if (IS_SEQUENCE(_s_49555)){
            _ls_49556 = SEQ_PTR(_s_49555)->length;
    }
    else {
        _ls_49556 = 1;
    }

    /** 	if ls>convert_length then*/
    if (_ls_49556 <= _42convert_length_49535)
    goto L1; // [12] 47

    /** 		free(convert_buffer)*/
    Ref(_42convert_buffer_49534);
    _9free(_42convert_buffer_49534);

    /** 		convert_length=and_bits(ls+15,-16)+1*/
    _25885 = _ls_49556 + 15;
    {unsigned long tu;
         tu = (unsigned long)_25885 & (unsigned long)-16;
         _25886 = MAKE_UINT(tu);
    }
    _25885 = NOVALUE;
    if (IS_ATOM_INT(_25886)) {
        _42convert_length_49535 = _25886 + 1;
    }
    else
    { // coercing _42convert_length_49535 to an integer 1
        _42convert_length_49535 = 1+(long)(DBL_PTR(_25886)->dbl);
        if( !IS_ATOM_INT(_42convert_length_49535) ){
            _42convert_length_49535 = (object)DBL_PTR(_42convert_length_49535)->dbl;
        }
    }
    DeRef(_25886);
    _25886 = NOVALUE;

    /** 		convert_buffer=allocate(convert_length)*/
    _0 = _9allocate(_42convert_length_49535, 0);
    DeRef(_42convert_buffer_49534);
    _42convert_buffer_49534 = _0;
L1: 

    /** 	poke(convert_buffer,s)*/
    if (IS_ATOM_INT(_42convert_buffer_49534)){
        poke_addr = (unsigned char *)_42convert_buffer_49534;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_42convert_buffer_49534)->dbl);
    }
    _1 = (int)SEQ_PTR(_s_49555);
    _1 = (int)((s1_ptr)_1)->base;
    while (1) {
        _1 += 4;
        _2 = *((int *)_1);
        if (IS_ATOM_INT(_2))
        *poke_addr++ = (unsigned char)_2;
        else if (_2 == NOVALUE)
        break;
        else {
            *poke_addr++ = (signed char)DBL_PTR(_2)->dbl;
        }
    }

    /** 	poke(convert_buffer+ls,0)*/
    if (IS_ATOM_INT(_42convert_buffer_49534)) {
        _25889 = _42convert_buffer_49534 + _ls_49556;
        if ((long)((unsigned long)_25889 + (unsigned long)HIGH_BITS) >= 0) 
        _25889 = NewDouble((double)_25889);
    }
    else {
        _25889 = NewDouble(DBL_PTR(_42convert_buffer_49534)->dbl + (double)_ls_49556);
    }
    if (IS_ATOM_INT(_25889)){
        poke_addr = (unsigned char *)_25889;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_25889)->dbl);
    }
    *poke_addr = (unsigned char)0;
    DeRef(_25889);
    _25889 = NOVALUE;

    /** 	rc=c_func(oem2char,{convert_buffer,convert_buffer}) -- always nonzero*/
    Ref(_42convert_buffer_49534);
    Ref(_42convert_buffer_49534);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _42convert_buffer_49534;
    ((int *)_2)[2] = _42convert_buffer_49534;
    _25890 = MAKE_SEQ(_1);
    _rc_49557 = call_c(1, _42oem2char_49533, _25890);
    DeRefDS(_25890);
    _25890 = NOVALUE;
    if (!IS_ATOM_INT(_rc_49557)) {
        _1 = (long)(DBL_PTR(_rc_49557)->dbl);
        DeRefDS(_rc_49557);
        _rc_49557 = _1;
    }

    /** 	return peek({convert_buffer,ls}) */
    Ref(_42convert_buffer_49534);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _42convert_buffer_49534;
    ((int *)_2)[2] = _ls_49556;
    _25892 = MAKE_SEQ(_1);
    _1 = (int)SEQ_PTR(_25892);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _25893 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    DeRefDS(_25892);
    _25892 = NOVALUE;
    DeRefDS(_s_49555);
    return _25893;
    ;
}


int _42exe_path()
{
    int _25897 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if sequence(exe_path_cache) then*/
    _25897 = IS_SEQUENCE(_42exe_path_cache_49587);
    if (_25897 == 0)
    {
        _25897 = NOVALUE;
        goto L1; // [8] 20
    }
    else{
        _25897 = NOVALUE;
    }

    /** 		return exe_path_cache*/
    Ref(_42exe_path_cache_49587);
    return _42exe_path_cache_49587;
L1: 

    /** 	exe_path_cache = command_line()*/
    DeRef(_42exe_path_cache_49587);
    _42exe_path_cache_49587 = Command_Line();

    /** 	exe_path_cache = exe_path_cache[1]*/
    _0 = _42exe_path_cache_49587;
    _2 = (int)SEQ_PTR(_42exe_path_cache_49587);
    _42exe_path_cache_49587 = (int)*(((s1_ptr)_2)->base + 1);
    RefDS(_42exe_path_cache_49587);
    DeRefDS(_0);

    /** 	return exe_path_cache*/
    RefDS(_42exe_path_cache_49587);
    return _42exe_path_cache_49587;
    ;
}


int _42check_cache(int _env_49599, int _inc_path_49600)
{
    int _delim_49601 = NOVALUE;
    int _pos_49602 = NOVALUE;
    int _25948 = NOVALUE;
    int _25947 = NOVALUE;
    int _25946 = NOVALUE;
    int _25945 = NOVALUE;
    int _25943 = NOVALUE;
    int _25942 = NOVALUE;
    int _25941 = NOVALUE;
    int _25940 = NOVALUE;
    int _25939 = NOVALUE;
    int _25938 = NOVALUE;
    int _25937 = NOVALUE;
    int _25936 = NOVALUE;
    int _25935 = NOVALUE;
    int _25934 = NOVALUE;
    int _25933 = NOVALUE;
    int _25929 = NOVALUE;
    int _25928 = NOVALUE;
    int _25927 = NOVALUE;
    int _25926 = NOVALUE;
    int _25925 = NOVALUE;
    int _25924 = NOVALUE;
    int _25923 = NOVALUE;
    int _25922 = NOVALUE;
    int _25920 = NOVALUE;
    int _25919 = NOVALUE;
    int _25918 = NOVALUE;
    int _25917 = NOVALUE;
    int _25916 = NOVALUE;
    int _25915 = NOVALUE;
    int _25913 = NOVALUE;
    int _25912 = NOVALUE;
    int _25911 = NOVALUE;
    int _25910 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not num_var then -- first time the var is accessed, add cache entry*/
    if (_42num_var_49576 != 0)
    goto L1; // [9] 94

    /** 		cache_vars = append(cache_vars,env)*/
    RefDS(_env_49599);
    Append(&_42cache_vars_49577, _42cache_vars_49577, _env_49599);

    /** 		cache_strings = append(cache_strings,inc_path)*/
    RefDS(_inc_path_49600);
    Append(&_42cache_strings_49578, _42cache_strings_49578, _inc_path_49600);

    /** 		cache_substrings = append(cache_substrings,{})*/
    RefDS(_22023);
    Append(&_42cache_substrings_49579, _42cache_substrings_49579, _22023);

    /** 		cache_starts = append(cache_starts,{})*/
    RefDS(_22023);
    Append(&_42cache_starts_49580, _42cache_starts_49580, _22023);

    /** 		cache_ends = append(cache_ends,{})*/
    RefDS(_22023);
    Append(&_42cache_ends_49581, _42cache_ends_49581, _22023);

    /** 		ifdef WINDOWS then*/

    /** 			cache_converted = append(cache_converted,{})*/
    RefDS(_22023);
    Append(&_42cache_converted_49582, _42cache_converted_49582, _22023);

    /** 		num_var = length(cache_vars)*/
    if (IS_SEQUENCE(_42cache_vars_49577)){
            _42num_var_49576 = SEQ_PTR(_42cache_vars_49577)->length;
    }
    else {
        _42num_var_49576 = 1;
    }

    /** 		cache_complete &= 0*/
    Append(&_42cache_complete_49583, _42cache_complete_49583, 0);

    /** 		cache_delims &= 0*/
    Append(&_42cache_delims_49584, _42cache_delims_49584, 0);

    /** 		return 0*/
    DeRefDS(_env_49599);
    DeRefDSi(_inc_path_49600);
    return 0;
    goto L2; // [91] 456
L1: 

    /** 		if compare(inc_path,cache_strings[num_var]) then*/
    _2 = (int)SEQ_PTR(_42cache_strings_49578);
    _25910 = (int)*(((s1_ptr)_2)->base + _42num_var_49576);
    if (IS_ATOM_INT(_inc_path_49600) && IS_ATOM_INT(_25910)){
        _25911 = (_inc_path_49600 < _25910) ? -1 : (_inc_path_49600 > _25910);
    }
    else{
        _25911 = compare(_inc_path_49600, _25910);
    }
    _25910 = NOVALUE;
    if (_25911 == 0)
    {
        _25911 = NOVALUE;
        goto L3; // [108] 455
    }
    else{
        _25911 = NOVALUE;
    }

    /** 			cache_strings[num_var] = inc_path*/
    RefDS(_inc_path_49600);
    _2 = (int)SEQ_PTR(_42cache_strings_49578);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _42cache_strings_49578 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _42num_var_49576);
    _1 = *(int *)_2;
    *(int *)_2 = _inc_path_49600;
    DeRefDS(_1);

    /** 			cache_complete[num_var] = 0*/
    _2 = (int)SEQ_PTR(_42cache_complete_49583);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _42cache_complete_49583 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _42num_var_49576);
    *(int *)_2 = 0;

    /** 			if match(cache_strings[num_var],inc_path)!=1 then -- try to salvage what we can*/
    _2 = (int)SEQ_PTR(_42cache_strings_49578);
    _25912 = (int)*(((s1_ptr)_2)->base + _42num_var_49576);
    _25913 = e_match_from(_25912, _inc_path_49600, 1);
    _25912 = NOVALUE;
    if (_25913 == 1)
    goto L4; // [146] 454

    /** 				pos = -1*/
    _pos_49602 = -1;

    /** 				for i=1 to length(cache_strings[num_var]) do*/
    _2 = (int)SEQ_PTR(_42cache_strings_49578);
    _25915 = (int)*(((s1_ptr)_2)->base + _42num_var_49576);
    if (IS_SEQUENCE(_25915)){
            _25916 = SEQ_PTR(_25915)->length;
    }
    else {
        _25916 = 1;
    }
    _25915 = NOVALUE;
    {
        int _i_49623;
        _i_49623 = 1;
L5: 
        if (_i_49623 > _25916){
            goto L6; // [168] 453
        }

        /** 					if cache_ends[num_var][i] > length(inc_path) or */
        _2 = (int)SEQ_PTR(_42cache_ends_49581);
        _25917 = (int)*(((s1_ptr)_2)->base + _42num_var_49576);
        _2 = (int)SEQ_PTR(_25917);
        _25918 = (int)*(((s1_ptr)_2)->base + _i_49623);
        _25917 = NOVALUE;
        if (IS_SEQUENCE(_inc_path_49600)){
                _25919 = SEQ_PTR(_inc_path_49600)->length;
        }
        else {
            _25919 = 1;
        }
        if (IS_ATOM_INT(_25918)) {
            _25920 = (_25918 > _25919);
        }
        else {
            _25920 = binary_op(GREATER, _25918, _25919);
        }
        _25918 = NOVALUE;
        _25919 = NOVALUE;
        if (IS_ATOM_INT(_25920)) {
            if (_25920 != 0) {
                goto L7; // [196] 250
            }
        }
        else {
            if (DBL_PTR(_25920)->dbl != 0.0) {
                goto L7; // [196] 250
            }
        }
        _2 = (int)SEQ_PTR(_42cache_substrings_49579);
        _25922 = (int)*(((s1_ptr)_2)->base + _42num_var_49576);
        _2 = (int)SEQ_PTR(_25922);
        _25923 = (int)*(((s1_ptr)_2)->base + _i_49623);
        _25922 = NOVALUE;
        _2 = (int)SEQ_PTR(_42cache_starts_49580);
        _25924 = (int)*(((s1_ptr)_2)->base + _42num_var_49576);
        _2 = (int)SEQ_PTR(_25924);
        _25925 = (int)*(((s1_ptr)_2)->base + _i_49623);
        _25924 = NOVALUE;
        _2 = (int)SEQ_PTR(_42cache_ends_49581);
        _25926 = (int)*(((s1_ptr)_2)->base + _42num_var_49576);
        _2 = (int)SEQ_PTR(_25926);
        _25927 = (int)*(((s1_ptr)_2)->base + _i_49623);
        _25926 = NOVALUE;
        rhs_slice_target = (object_ptr)&_25928;
        RHS_Slice(_inc_path_49600, _25925, _25927);
        if (IS_ATOM_INT(_25923) && IS_ATOM_INT(_25928)){
            _25929 = (_25923 < _25928) ? -1 : (_25923 > _25928);
        }
        else{
            _25929 = compare(_25923, _25928);
        }
        _25923 = NOVALUE;
        DeRefDS(_25928);
        _25928 = NOVALUE;
        if (_25929 == 0)
        {
            _25929 = NOVALUE;
            goto L8; // [246] 261
        }
        else{
            _25929 = NOVALUE;
        }
L7: 

        /** 						pos = i-1*/
        _pos_49602 = _i_49623 - 1;

        /** 						exit*/
        goto L6; // [258] 453
L8: 

        /** 					if pos = 0 then*/
        if (_pos_49602 != 0)
        goto L9; // [263] 276

        /** 						return 0*/
        DeRefDS(_env_49599);
        DeRefDSi(_inc_path_49600);
        _25915 = NOVALUE;
        DeRef(_25920);
        _25920 = NOVALUE;
        _25925 = NOVALUE;
        _25927 = NOVALUE;
        return 0;
        goto LA; // [273] 446
L9: 

        /** 					elsif pos >0 then -- crop cache data*/
        if (_pos_49602 <= 0)
        goto LB; // [278] 445

        /** 						cache_substrings[num_var] = cache_substrings[num_var][1..pos]*/
        _2 = (int)SEQ_PTR(_42cache_substrings_49579);
        _25933 = (int)*(((s1_ptr)_2)->base + _42num_var_49576);
        rhs_slice_target = (object_ptr)&_25934;
        RHS_Slice(_25933, 1, _pos_49602);
        _25933 = NOVALUE;
        _2 = (int)SEQ_PTR(_42cache_substrings_49579);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _42cache_substrings_49579 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _42num_var_49576);
        _1 = *(int *)_2;
        *(int *)_2 = _25934;
        if( _1 != _25934 ){
            DeRefDS(_1);
        }
        _25934 = NOVALUE;

        /** 						cache_starts[num_var] = cache_starts[num_var][1..pos]*/
        _2 = (int)SEQ_PTR(_42cache_starts_49580);
        _25935 = (int)*(((s1_ptr)_2)->base + _42num_var_49576);
        rhs_slice_target = (object_ptr)&_25936;
        RHS_Slice(_25935, 1, _pos_49602);
        _25935 = NOVALUE;
        _2 = (int)SEQ_PTR(_42cache_starts_49580);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _42cache_starts_49580 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _42num_var_49576);
        _1 = *(int *)_2;
        *(int *)_2 = _25936;
        if( _1 != _25936 ){
            DeRef(_1);
        }
        _25936 = NOVALUE;

        /** 						cache_ends[num_var] = cache_ends[num_var][1..pos]*/
        _2 = (int)SEQ_PTR(_42cache_ends_49581);
        _25937 = (int)*(((s1_ptr)_2)->base + _42num_var_49576);
        rhs_slice_target = (object_ptr)&_25938;
        RHS_Slice(_25937, 1, _pos_49602);
        _25937 = NOVALUE;
        _2 = (int)SEQ_PTR(_42cache_ends_49581);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _42cache_ends_49581 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _42num_var_49576);
        _1 = *(int *)_2;
        *(int *)_2 = _25938;
        if( _1 != _25938 ){
            DeRef(_1);
        }
        _25938 = NOVALUE;

        /** 						ifdef WINDOWS then*/

        /** 							cache_converted[num_var] = cache_converted[num_var][1..pos]*/
        _2 = (int)SEQ_PTR(_42cache_converted_49582);
        _25939 = (int)*(((s1_ptr)_2)->base + _42num_var_49576);
        rhs_slice_target = (object_ptr)&_25940;
        RHS_Slice(_25939, 1, _pos_49602);
        _25939 = NOVALUE;
        _2 = (int)SEQ_PTR(_42cache_converted_49582);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _42cache_converted_49582 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _42num_var_49576);
        _1 = *(int *)_2;
        *(int *)_2 = _25940;
        if( _1 != _25940 ){
            DeRef(_1);
        }
        _25940 = NOVALUE;

        /** 						delim = cache_ends[num_var][$]+1*/
        _2 = (int)SEQ_PTR(_42cache_ends_49581);
        _25941 = (int)*(((s1_ptr)_2)->base + _42num_var_49576);
        if (IS_SEQUENCE(_25941)){
                _25942 = SEQ_PTR(_25941)->length;
        }
        else {
            _25942 = 1;
        }
        _2 = (int)SEQ_PTR(_25941);
        _25943 = (int)*(((s1_ptr)_2)->base + _25942);
        _25941 = NOVALUE;
        if (IS_ATOM_INT(_25943)) {
            _delim_49601 = _25943 + 1;
        }
        else
        { // coercing _delim_49601 to an integer 1
            _delim_49601 = 1+(long)(DBL_PTR(_25943)->dbl);
            if( !IS_ATOM_INT(_delim_49601) ){
                _delim_49601 = (object)DBL_PTR(_delim_49601)->dbl;
            }
        }
        _25943 = NOVALUE;

        /** 						while delim <= length(inc_path) and delim != PATH_SEPARATOR do*/
LC: 
        if (IS_SEQUENCE(_inc_path_49600)){
                _25945 = SEQ_PTR(_inc_path_49600)->length;
        }
        else {
            _25945 = 1;
        }
        _25946 = (_delim_49601 <= _25945);
        _25945 = NOVALUE;
        if (_25946 == 0) {
            goto LD; // [409] 434
        }
        _25948 = (_delim_49601 != 59);
        if (_25948 == 0)
        {
            DeRef(_25948);
            _25948 = NOVALUE;
            goto LD; // [420] 434
        }
        else{
            DeRef(_25948);
            _25948 = NOVALUE;
        }

        /** 							delim+=1*/
        _delim_49601 = _delim_49601 + 1;

        /** 						end while*/
        goto LC; // [431] 402
LD: 

        /** 						cache_delims[num_var] = delim*/
        _2 = (int)SEQ_PTR(_42cache_delims_49584);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _42cache_delims_49584 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _42num_var_49576);
        *(int *)_2 = _delim_49601;
LB: 
LA: 

        /** 				end for*/
        _i_49623 = _i_49623 + 1;
        goto L5; // [448] 175
L6: 
        ;
    }
L4: 
L3: 
L2: 

    /** 	return 1*/
    DeRefDS(_env_49599);
    DeRefDSi(_inc_path_49600);
    _25915 = NOVALUE;
    DeRef(_25946);
    _25946 = NOVALUE;
    DeRef(_25920);
    _25920 = NOVALUE;
    _25925 = NOVALUE;
    _25927 = NOVALUE;
    return 1;
    ;
}


int _42get_conf_dirs()
{
    int _delimiter_49666 = NOVALUE;
    int _dirs_49667 = NOVALUE;
    int _25953 = NOVALUE;
    int _25951 = NOVALUE;
    int _25950 = NOVALUE;
    int _0, _1, _2;
    

    /** 	ifdef UNIX then*/

    /** 		delimiter = ';'*/
    _delimiter_49666 = 59;

    /** 	dirs = ""*/
    RefDS(_22023);
    DeRef(_dirs_49667);
    _dirs_49667 = _22023;

    /** 	for i = 1 to length(config_inc_paths) do*/
    if (IS_SEQUENCE(_42config_inc_paths_49585)){
            _25950 = SEQ_PTR(_42config_inc_paths_49585)->length;
    }
    else {
        _25950 = 1;
    }
    {
        int _i_49669;
        _i_49669 = 1;
L1: 
        if (_i_49669 > _25950){
            goto L2; // [22] 68
        }

        /** 		dirs &= config_inc_paths[i]*/
        _2 = (int)SEQ_PTR(_42config_inc_paths_49585);
        _25951 = (int)*(((s1_ptr)_2)->base + _i_49669);
        Concat((object_ptr)&_dirs_49667, _dirs_49667, _25951);
        _25951 = NOVALUE;

        /** 		if i != length(config_inc_paths) then*/
        if (IS_SEQUENCE(_42config_inc_paths_49585)){
                _25953 = SEQ_PTR(_42config_inc_paths_49585)->length;
        }
        else {
            _25953 = 1;
        }
        if (_i_49669 == _25953)
        goto L3; // [48] 61

        /** 			dirs &= delimiter*/
        Append(&_dirs_49667, _dirs_49667, _delimiter_49666);
L3: 

        /** 	end for*/
        _i_49669 = _i_49669 + 1;
        goto L1; // [63] 29
L2: 
        ;
    }

    /** 	return dirs*/
    return _dirs_49667;
    ;
}


int _42strip_file_from_path(int _full_path_49679)
{
    int _25959 = NOVALUE;
    int _25957 = NOVALUE;
    int _25956 = NOVALUE;
    int _0, _1, _2;
    

    /** 	for i = length(full_path) to 1 by -1 do*/
    if (IS_SEQUENCE(_full_path_49679)){
            _25956 = SEQ_PTR(_full_path_49679)->length;
    }
    else {
        _25956 = 1;
    }
    {
        int _i_49681;
        _i_49681 = _25956;
L1: 
        if (_i_49681 < 1){
            goto L2; // [8] 46
        }

        /** 		if full_path[i] = SLASH then*/
        _2 = (int)SEQ_PTR(_full_path_49679);
        _25957 = (int)*(((s1_ptr)_2)->base + _i_49681);
        if (binary_op_a(NOTEQ, _25957, 92)){
            _25957 = NOVALUE;
            goto L3; // [23] 39
        }
        _25957 = NOVALUE;

        /** 			return full_path[1..i]*/
        rhs_slice_target = (object_ptr)&_25959;
        RHS_Slice(_full_path_49679, 1, _i_49681);
        DeRefDS(_full_path_49679);
        return _25959;
L3: 

        /** 	end for*/
        _i_49681 = _i_49681 + -1;
        goto L1; // [41] 15
L2: 
        ;
    }

    /** 	return ""*/
    RefDS(_22023);
    DeRefDS(_full_path_49679);
    DeRef(_25959);
    _25959 = NOVALUE;
    return _22023;
    ;
}


int _42expand_path(int _path_49690, int _prefix_49691)
{
    int _absolute_49692 = NOVALUE;
    int _25974 = NOVALUE;
    int _25973 = NOVALUE;
    int _25972 = NOVALUE;
    int _25971 = NOVALUE;
    int _25970 = NOVALUE;
    int _25969 = NOVALUE;
    int _25965 = NOVALUE;
    int _25964 = NOVALUE;
    int _25963 = NOVALUE;
    int _25960 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not length(path) then*/
    if (IS_SEQUENCE(_path_49690)){
            _25960 = SEQ_PTR(_path_49690)->length;
    }
    else {
        _25960 = 1;
    }
    if (_25960 != 0)
    goto L1; // [10] 22
    _25960 = NOVALUE;

    /** 		return pwd*/
    RefDS(_42pwd_49588);
    DeRefDS(_path_49690);
    DeRefDS(_prefix_49691);
    return _42pwd_49588;
L1: 

    /** 	ifdef UNIX then*/

    /** 		absolute = find(path[1], SLASH_CHARS) or find(':', path)*/
    _2 = (int)SEQ_PTR(_path_49690);
    _25963 = (int)*(((s1_ptr)_2)->base + 1);
    _25964 = find_from(_25963, _40SLASH_CHARS_16402, 1);
    _25963 = NOVALUE;
    _25965 = find_from(58, _path_49690, 1);
    _absolute_49692 = (_25964 != 0 || _25965 != 0);
    _25964 = NOVALUE;
    _25965 = NOVALUE;

    /** 	if not absolute then*/
    if (_absolute_49692 != 0)
    goto L2; // [50] 64

    /** 		path = prefix & SLASH & path*/
    {
        int concat_list[3];

        concat_list[0] = _path_49690;
        concat_list[1] = 92;
        concat_list[2] = _prefix_49691;
        Concat_N((object_ptr)&_path_49690, concat_list, 3);
    }
L2: 

    /** 	if length(path) and not find(path[$], SLASH_CHARS) then*/
    if (IS_SEQUENCE(_path_49690)){
            _25969 = SEQ_PTR(_path_49690)->length;
    }
    else {
        _25969 = 1;
    }
    if (_25969 == 0) {
        goto L3; // [69] 103
    }
    if (IS_SEQUENCE(_path_49690)){
            _25971 = SEQ_PTR(_path_49690)->length;
    }
    else {
        _25971 = 1;
    }
    _2 = (int)SEQ_PTR(_path_49690);
    _25972 = (int)*(((s1_ptr)_2)->base + _25971);
    _25973 = find_from(_25972, _40SLASH_CHARS_16402, 1);
    _25972 = NOVALUE;
    _25974 = (_25973 == 0);
    _25973 = NOVALUE;
    if (_25974 == 0)
    {
        DeRef(_25974);
        _25974 = NOVALUE;
        goto L3; // [91] 103
    }
    else{
        DeRef(_25974);
        _25974 = NOVALUE;
    }

    /** 		path &= SLASH*/
    Append(&_path_49690, _path_49690, 92);
L3: 

    /** 	return path*/
    DeRefDS(_prefix_49691);
    return _path_49690;
    ;
}


void _42add_include_directory(int _path_49718)
{
    int _25977 = NOVALUE;
    int _0, _1, _2;
    

    /** 	path = expand_path( path, pwd )*/
    RefDS(_path_49718);
    RefDS(_42pwd_49588);
    _0 = _path_49718;
    _path_49718 = _42expand_path(_path_49718, _42pwd_49588);
    DeRefDS(_0);

    /** 	if not find( path, config_inc_paths ) then*/
    _25977 = find_from(_path_49718, _42config_inc_paths_49585, 1);
    if (_25977 != 0)
    goto L1; // [23] 35
    _25977 = NOVALUE;

    /** 		config_inc_paths = append( config_inc_paths, path )*/
    RefDS(_path_49718);
    Append(&_42config_inc_paths_49585, _42config_inc_paths_49585, _path_49718);
L1: 

    /** end procedure*/
    DeRefDS(_path_49718);
    return;
    ;
}


int _42load_euphoria_config(int _file_49727)
{
    int _fn_49728 = NOVALUE;
    int _in_49729 = NOVALUE;
    int _spos_49730 = NOVALUE;
    int _epos_49731 = NOVALUE;
    int _conf_path_49732 = NOVALUE;
    int _new_args_49733 = NOVALUE;
    int _arg_49734 = NOVALUE;
    int _parm_49735 = NOVALUE;
    int _section_49736 = NOVALUE;
    int _needed_49833 = NOVALUE;
    int _26074 = NOVALUE;
    int _26073 = NOVALUE;
    int _26070 = NOVALUE;
    int _26068 = NOVALUE;
    int _26067 = NOVALUE;
    int _26045 = NOVALUE;
    int _26042 = NOVALUE;
    int _26041 = NOVALUE;
    int _26039 = NOVALUE;
    int _26035 = NOVALUE;
    int _26033 = NOVALUE;
    int _26031 = NOVALUE;
    int _26029 = NOVALUE;
    int _26027 = NOVALUE;
    int _26025 = NOVALUE;
    int _26024 = NOVALUE;
    int _26023 = NOVALUE;
    int _26022 = NOVALUE;
    int _26021 = NOVALUE;
    int _26020 = NOVALUE;
    int _26019 = NOVALUE;
    int _26018 = NOVALUE;
    int _26016 = NOVALUE;
    int _26014 = NOVALUE;
    int _26012 = NOVALUE;
    int _26008 = NOVALUE;
    int _26007 = NOVALUE;
    int _26002 = NOVALUE;
    int _26000 = NOVALUE;
    int _25998 = NOVALUE;
    int _25997 = NOVALUE;
    int _25989 = NOVALUE;
    int _25983 = NOVALUE;
    int _25982 = NOVALUE;
    int _25980 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence new_args = {}*/
    RefDS(_22023);
    DeRef(_new_args_49733);
    _new_args_49733 = _22023;

    /** 	if file_type(file) = FILETYPE_DIRECTORY then*/
    RefDS(_file_49727);
    _25980 = _17file_type(_file_49727);
    if (binary_op_a(NOTEQ, _25980, 2)){
        DeRef(_25980);
        _25980 = NOVALUE;
        goto L1; // [18] 53
    }
    DeRef(_25980);
    _25980 = NOVALUE;

    /** 		if file[$] != SLASH then*/
    if (IS_SEQUENCE(_file_49727)){
            _25982 = SEQ_PTR(_file_49727)->length;
    }
    else {
        _25982 = 1;
    }
    _2 = (int)SEQ_PTR(_file_49727);
    _25983 = (int)*(((s1_ptr)_2)->base + _25982);
    if (binary_op_a(EQUALS, _25983, 92)){
        _25983 = NOVALUE;
        goto L2; // [33] 46
    }
    _25983 = NOVALUE;

    /** 			file &= SLASH*/
    Append(&_file_49727, _file_49727, 92);
L2: 

    /** 		file &= "eu.cfg"*/
    Concat((object_ptr)&_file_49727, _file_49727, _25986);
L1: 

    /** 	conf_path = canonical_path( file,,CORRECT )*/
    RefDS(_file_49727);
    _0 = _conf_path_49732;
    _conf_path_49732 = _17canonical_path(_file_49727, 0, 2);
    DeRef(_0);

    /** 	if find(conf_path, seen_conf) != 0 then*/
    _25989 = find_from(_conf_path_49732, _42seen_conf_49724, 1);
    if (_25989 == 0)
    goto L3; // [74] 85

    /** 		return {}*/
    RefDS(_22023);
    DeRefDS(_file_49727);
    DeRefi(_in_49729);
    DeRefDS(_conf_path_49732);
    DeRef(_new_args_49733);
    DeRefi(_arg_49734);
    DeRefi(_parm_49735);
    DeRef(_section_49736);
    return _22023;
L3: 

    /** 	seen_conf = append(seen_conf, conf_path)*/
    RefDS(_conf_path_49732);
    Append(&_42seen_conf_49724, _42seen_conf_49724, _conf_path_49732);

    /** 	section = "all"*/
    RefDS(_25992);
    DeRef(_section_49736);
    _section_49736 = _25992;

    /** 	fn = open( conf_path, "r" )*/
    _fn_49728 = EOpen(_conf_path_49732, _25993, 0);

    /** 	if fn = -1 then return {} end if*/
    if (_fn_49728 != -1)
    goto L4; // [109] 118
    RefDS(_22023);
    DeRefDS(_file_49727);
    DeRefi(_in_49729);
    DeRefDS(_conf_path_49732);
    DeRef(_new_args_49733);
    DeRefi(_arg_49734);
    DeRefi(_parm_49735);
    DeRefDSi(_section_49736);
    return _22023;
L4: 

    /** 	in = gets( fn )*/
    DeRefi(_in_49729);
    _in_49729 = EGets(_fn_49728);

    /** 	while sequence( in ) do*/
L5: 
    _25997 = IS_SEQUENCE(_in_49729);
    if (_25997 == 0)
    {
        _25997 = NOVALUE;
        goto L6; // [131] 768
    }
    else{
        _25997 = NOVALUE;
    }

    /** 		spos = 1*/
    _spos_49730 = 1;

    /** 		while spos <= length(in) do*/
L7: 
    if (IS_SEQUENCE(_in_49729)){
            _25998 = SEQ_PTR(_in_49729)->length;
    }
    else {
        _25998 = 1;
    }
    if (_spos_49730 > _25998)
    goto L8; // [147] 182

    /** 			if find( in[spos], "\n\r \t" ) = 0 then*/
    _2 = (int)SEQ_PTR(_in_49729);
    _26000 = (int)*(((s1_ptr)_2)->base + _spos_49730);
    _26002 = find_from(_26000, _26001, 1);
    _26000 = NOVALUE;
    if (_26002 != 0)
    goto L9; // [162] 171

    /** 				exit*/
    goto L8; // [168] 182
L9: 

    /** 			spos += 1*/
    _spos_49730 = _spos_49730 + 1;

    /** 		end while*/
    goto L7; // [179] 144
L8: 

    /** 		epos = length(in)*/
    if (IS_SEQUENCE(_in_49729)){
            _epos_49731 = SEQ_PTR(_in_49729)->length;
    }
    else {
        _epos_49731 = 1;
    }

    /** 		while epos >= spos do*/
LA: 
    if (_epos_49731 < _spos_49730)
    goto LB; // [192] 227

    /** 			if find( in[epos], "\n\r \t" ) = 0 then*/
    _2 = (int)SEQ_PTR(_in_49729);
    _26007 = (int)*(((s1_ptr)_2)->base + _epos_49731);
    _26008 = find_from(_26007, _26001, 1);
    _26007 = NOVALUE;
    if (_26008 != 0)
    goto LC; // [207] 216

    /** 				exit*/
    goto LB; // [213] 227
LC: 

    /** 			epos -= 1*/
    _epos_49731 = _epos_49731 - 1;

    /** 		end while*/
    goto LA; // [224] 192
LB: 

    /** 		in = in[spos .. epos]		*/
    rhs_slice_target = (object_ptr)&_in_49729;
    RHS_Slice(_in_49729, _spos_49730, _epos_49731);

    /** 		arg = ""*/
    RefDS(_22023);
    DeRefi(_arg_49734);
    _arg_49734 = _22023;

    /** 		parm = ""*/
    RefDS(_22023);
    DeRefi(_parm_49735);
    _parm_49735 = _22023;

    /** 		if length(in) > 0 then*/
    if (IS_SEQUENCE(_in_49729)){
            _26012 = SEQ_PTR(_in_49729)->length;
    }
    else {
        _26012 = 1;
    }
    if (_26012 <= 0)
    goto LD; // [253] 477

    /** 			if in[1] = '[' then*/
    _2 = (int)SEQ_PTR(_in_49729);
    _26014 = (int)*(((s1_ptr)_2)->base + 1);
    if (_26014 != 91)
    goto LE; // [263] 354

    /** 				section = in[2..$]*/
    if (IS_SEQUENCE(_in_49729)){
            _26016 = SEQ_PTR(_in_49729)->length;
    }
    else {
        _26016 = 1;
    }
    rhs_slice_target = (object_ptr)&_section_49736;
    RHS_Slice(_in_49729, 2, _26016);

    /** 				if length(section) > 0 and section[$] = ']' then*/
    if (IS_SEQUENCE(_section_49736)){
            _26018 = SEQ_PTR(_section_49736)->length;
    }
    else {
        _26018 = 1;
    }
    _26019 = (_26018 > 0);
    _26018 = NOVALUE;
    if (_26019 == 0) {
        goto LF; // [286] 320
    }
    if (IS_SEQUENCE(_section_49736)){
            _26021 = SEQ_PTR(_section_49736)->length;
    }
    else {
        _26021 = 1;
    }
    _2 = (int)SEQ_PTR(_section_49736);
    _26022 = (int)*(((s1_ptr)_2)->base + _26021);
    _26023 = (_26022 == 93);
    _26022 = NOVALUE;
    if (_26023 == 0)
    {
        DeRef(_26023);
        _26023 = NOVALUE;
        goto LF; // [302] 320
    }
    else{
        DeRef(_26023);
        _26023 = NOVALUE;
    }

    /** 					section = section[1..$-1]*/
    if (IS_SEQUENCE(_section_49736)){
            _26024 = SEQ_PTR(_section_49736)->length;
    }
    else {
        _26024 = 1;
    }
    _26025 = _26024 - 1;
    _26024 = NOVALUE;
    rhs_slice_target = (object_ptr)&_section_49736;
    RHS_Slice(_section_49736, 1, _26025);
LF: 

    /** 				section = lower(trim(section))*/
    RefDS(_section_49736);
    RefDS(_3890);
    _26027 = _14trim(_section_49736, _3890, 0);
    _0 = _section_49736;
    _section_49736 = _14lower(_26027);
    DeRefDS(_0);
    _26027 = NOVALUE;

    /** 				if length(section) = 0 then*/
    if (IS_SEQUENCE(_section_49736)){
            _26029 = SEQ_PTR(_section_49736)->length;
    }
    else {
        _26029 = 1;
    }
    if (_26029 != 0)
    goto L10; // [339] 476

    /** 					section = "all"*/
    RefDS(_25992);
    DeRefDS(_section_49736);
    _section_49736 = _25992;
    goto L10; // [351] 476
LE: 

    /** 			elsif length(in) > 2 then*/
    if (IS_SEQUENCE(_in_49729)){
            _26031 = SEQ_PTR(_in_49729)->length;
    }
    else {
        _26031 = 1;
    }
    if (_26031 <= 2)
    goto L11; // [359] 461

    /** 				if in[1] = '-' then*/
    _2 = (int)SEQ_PTR(_in_49729);
    _26033 = (int)*(((s1_ptr)_2)->base + 1);
    if (_26033 != 45)
    goto L12; // [369] 443

    /** 					if in[2] != '-' then*/
    _2 = (int)SEQ_PTR(_in_49729);
    _26035 = (int)*(((s1_ptr)_2)->base + 2);
    if (_26035 == 45)
    goto L10; // [379] 476

    /** 						spos = find(' ', in)*/
    _spos_49730 = find_from(32, _in_49729, 1);

    /** 						if spos = 0 then*/
    if (_spos_49730 != 0)
    goto L13; // [392] 413

    /** 							arg = in*/
    Ref(_in_49729);
    DeRefi(_arg_49734);
    _arg_49734 = _in_49729;

    /** 							parm = ""*/
    RefDS(_22023);
    DeRefi(_parm_49735);
    _parm_49735 = _22023;
    goto L10; // [410] 476
L13: 

    /** 							arg = in[1..spos - 1]*/
    _26039 = _spos_49730 - 1;
    rhs_slice_target = (object_ptr)&_arg_49734;
    RHS_Slice(_in_49729, 1, _26039);

    /** 							parm = in[spos + 1 .. $]*/
    _26041 = _spos_49730 + 1;
    if (_26041 > MAXINT){
        _26041 = NewDouble((double)_26041);
    }
    if (IS_SEQUENCE(_in_49729)){
            _26042 = SEQ_PTR(_in_49729)->length;
    }
    else {
        _26042 = 1;
    }
    rhs_slice_target = (object_ptr)&_parm_49735;
    RHS_Slice(_in_49729, _26041, _26042);
    goto L10; // [440] 476
L12: 

    /** 					arg = "-i"*/
    RefDS(_26044);
    DeRefi(_arg_49734);
    _arg_49734 = _26044;

    /** 					parm = in*/
    Ref(_in_49729);
    DeRefi(_parm_49735);
    _parm_49735 = _in_49729;
    goto L10; // [458] 476
L11: 

    /** 				arg = "-i"*/
    RefDS(_26044);
    DeRefi(_arg_49734);
    _arg_49734 = _26044;

    /** 				parm = in*/
    Ref(_in_49729);
    DeRefi(_parm_49735);
    _parm_49735 = _in_49729;
L10: 
LD: 

    /** 		if length(arg) > 0 then*/
    if (IS_SEQUENCE(_arg_49734)){
            _26045 = SEQ_PTR(_arg_49734)->length;
    }
    else {
        _26045 = 1;
    }
    if (_26045 <= 0)
    goto L14; // [482] 756

    /** 			integer needed = 0*/
    _needed_49833 = 0;

    /** 			switch section do*/
    _1 = find(_section_49736, _26047);
    switch ( _1 ){ 

        /** 				case "all" then*/
        case 1:

        /** 					needed = 1*/
        _needed_49833 = 1;
        goto L15; // [507] 691

        /** 				case "windows" then*/
        case 2:

        /** 					needed = TWINDOWS*/
        _needed_49833 = _40TWINDOWS_16388;
        goto L15; // [522] 691

        /** 				case "unix" then*/
        case 3:

        /** 					needed = TUNIX*/
        _needed_49833 = _40TUNIX_16392;
        goto L15; // [537] 691

        /** 				case "translate" then*/
        case 4:

        /** 					needed = TRANSLATE*/
        _needed_49833 = _35TRANSLATE_15887;
        goto L15; // [552] 691

        /** 				case "translate:windows" then*/
        case 5:

        /** 					needed = TRANSLATE and TWINDOWS*/
        _needed_49833 = (_35TRANSLATE_15887 != 0 && _40TWINDOWS_16388 != 0);
        goto L15; // [570] 691

        /** 				case "translate:unix" then*/
        case 6:

        /** 					needed = TRANSLATE and TUNIX*/
        _needed_49833 = (_35TRANSLATE_15887 != 0 && _40TUNIX_16392 != 0);
        goto L15; // [588] 691

        /** 				case "interpret" then*/
        case 7:

        /** 					needed = INTERPRET*/
        _needed_49833 = _35INTERPRET_15884;
        goto L15; // [603] 691

        /** 				case "interpret:windows" then*/
        case 8:

        /** 					needed = INTERPRET and TWINDOWS*/
        _needed_49833 = (_35INTERPRET_15884 != 0 && _40TWINDOWS_16388 != 0);
        goto L15; // [621] 691

        /** 				case "interpret:unix" then*/
        case 9:

        /** 					needed = INTERPRET and TUNIX*/
        _needed_49833 = (_35INTERPRET_15884 != 0 && _40TUNIX_16392 != 0);
        goto L15; // [639] 691

        /** 				case "bind" then*/
        case 10:

        /** 					needed = BIND*/
        _needed_49833 = _35BIND_15890;
        goto L15; // [654] 691

        /** 				case "bind:windows" then*/
        case 11:

        /** 					needed = BIND and TWINDOWS*/
        _needed_49833 = (_35BIND_15890 != 0 && _40TWINDOWS_16388 != 0);
        goto L15; // [672] 691

        /** 				case "bind:unix" then*/
        case 12:

        /** 					needed = BIND and TUNIX*/
        _needed_49833 = (_35BIND_15890 != 0 && _40TUNIX_16392 != 0);
    ;}L15: 

    /** 			if needed then*/
    if (_needed_49833 == 0)
    {
        goto L16; // [693] 755
    }
    else{
    }

    /** 				if equal(arg, "-c") then*/
    if (_arg_49734 == _26066)
    _26067 = 1;
    else if (IS_ATOM_INT(_arg_49734) && IS_ATOM_INT(_26066))
    _26067 = 0;
    else
    _26067 = (compare(_arg_49734, _26066) == 0);
    if (_26067 == 0)
    {
        _26067 = NOVALUE;
        goto L17; // [702] 728
    }
    else{
        _26067 = NOVALUE;
    }

    /** 					if length(parm) > 0 then*/
    if (IS_SEQUENCE(_parm_49735)){
            _26068 = SEQ_PTR(_parm_49735)->length;
    }
    else {
        _26068 = 1;
    }
    if (_26068 <= 0)
    goto L18; // [710] 754

    /** 						new_args &= load_euphoria_config(parm)*/
    RefDS(_parm_49735);
    _26070 = _42load_euphoria_config(_parm_49735);
    if (IS_SEQUENCE(_new_args_49733) && IS_ATOM(_26070)) {
        Ref(_26070);
        Append(&_new_args_49733, _new_args_49733, _26070);
    }
    else if (IS_ATOM(_new_args_49733) && IS_SEQUENCE(_26070)) {
    }
    else {
        Concat((object_ptr)&_new_args_49733, _new_args_49733, _26070);
    }
    DeRef(_26070);
    _26070 = NOVALUE;
    goto L18; // [725] 754
L17: 

    /** 					new_args = append(new_args, arg)*/
    RefDS(_arg_49734);
    Append(&_new_args_49733, _new_args_49733, _arg_49734);

    /** 					if length(parm > 0) then*/
    _26073 = binary_op(GREATER, _parm_49735, 0);
    if (IS_SEQUENCE(_26073)){
            _26074 = SEQ_PTR(_26073)->length;
    }
    else {
        _26074 = 1;
    }
    DeRefDS(_26073);
    _26073 = NOVALUE;
    if (_26074 == 0)
    {
        _26074 = NOVALUE;
        goto L19; // [743] 753
    }
    else{
        _26074 = NOVALUE;
    }

    /** 						new_args = append(new_args, parm)*/
    RefDS(_parm_49735);
    Append(&_new_args_49733, _new_args_49733, _parm_49735);
L19: 
L18: 
L16: 
L14: 

    /** 		in = gets( fn )*/
    DeRefi(_in_49729);
    _in_49729 = EGets(_fn_49728);

    /** 	end while*/
    goto L5; // [765] 128
L6: 

    /** 	close(fn)*/
    EClose(_fn_49728);

    /** 	return new_args*/
    DeRefDS(_file_49727);
    DeRefi(_in_49729);
    DeRef(_conf_path_49732);
    DeRefi(_arg_49734);
    DeRefi(_parm_49735);
    DeRef(_section_49736);
    _26014 = NOVALUE;
    DeRef(_26019);
    _26019 = NOVALUE;
    DeRef(_26025);
    _26025 = NOVALUE;
    _26033 = NOVALUE;
    _26035 = NOVALUE;
    DeRef(_26039);
    _26039 = NOVALUE;
    DeRef(_26041);
    _26041 = NOVALUE;
    _26073 = NOVALUE;
    return _new_args_49733;
    ;
}


int _42GetDefaultArgs(int _user_files_49900)
{
    int _env_49901 = NOVALUE;
    int _default_args_49902 = NOVALUE;
    int _conf_file_49903 = NOVALUE;
    int _cmd_options_49905 = NOVALUE;
    int _user_config_49911 = NOVALUE;
    int _26119 = NOVALUE;
    int _26118 = NOVALUE;
    int _26117 = NOVALUE;
    int _26114 = NOVALUE;
    int _26113 = NOVALUE;
    int _26112 = NOVALUE;
    int _26110 = NOVALUE;
    int _26106 = NOVALUE;
    int _26105 = NOVALUE;
    int _26104 = NOVALUE;
    int _26103 = NOVALUE;
    int _26099 = NOVALUE;
    int _26098 = NOVALUE;
    int _26097 = NOVALUE;
    int _26095 = NOVALUE;
    int _26089 = NOVALUE;
    int _26088 = NOVALUE;
    int _26086 = NOVALUE;
    int _26084 = NOVALUE;
    int _26083 = NOVALUE;
    int _26079 = NOVALUE;
    int _26078 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence default_args = {}*/
    RefDS(_22023);
    DeRef(_default_args_49902);
    _default_args_49902 = _22023;

    /** 	sequence conf_file = "eu.cfg"*/
    RefDS(_25986);
    DeRefi(_conf_file_49903);
    _conf_file_49903 = _25986;

    /** 	if loaded_config_inc_paths then return "" end if*/
    if (_42loaded_config_inc_paths_49586 == 0)
    {
        goto L1; // [21] 29
    }
    else{
    }
    RefDS(_22023);
    DeRefDS(_user_files_49900);
    DeRef(_env_49901);
    DeRefDS(_default_args_49902);
    DeRefDSi(_conf_file_49903);
    DeRef(_cmd_options_49905);
    return _22023;
L1: 

    /** 	loaded_config_inc_paths = 1*/
    _42loaded_config_inc_paths_49586 = 1;

    /** 	sequence cmd_options = get_options()*/
    _0 = _cmd_options_49905;
    _cmd_options_49905 = _43get_options();
    DeRef(_0);

    /** 	default_args = {}*/
    RefDS(_22023);
    DeRef(_default_args_49902);
    _default_args_49902 = _22023;

    /** 	for i = 1 to length( user_files ) do*/
    if (IS_SEQUENCE(_user_files_49900)){
            _26078 = SEQ_PTR(_user_files_49900)->length;
    }
    else {
        _26078 = 1;
    }
    {
        int _i_49909;
        _i_49909 = 1;
L2: 
        if (_i_49909 > _26078){
            goto L3; // [53] 92
        }

        /** 		sequence user_config = load_euphoria_config( user_files[i] )*/
        _2 = (int)SEQ_PTR(_user_files_49900);
        _26079 = (int)*(((s1_ptr)_2)->base + _i_49909);
        Ref(_26079);
        _0 = _user_config_49911;
        _user_config_49911 = _42load_euphoria_config(_26079);
        DeRef(_0);
        _26079 = NOVALUE;

        /** 		default_args = merge_parameters( user_config, default_args, cmd_options, 1 )*/
        RefDS(_user_config_49911);
        RefDS(_default_args_49902);
        RefDS(_cmd_options_49905);
        _0 = _default_args_49902;
        _default_args_49902 = _43merge_parameters(_user_config_49911, _default_args_49902, _cmd_options_49905, 1);
        DeRefDS(_0);
        DeRefDS(_user_config_49911);
        _user_config_49911 = NOVALUE;

        /** 	end for*/
        _i_49909 = _i_49909 + 1;
        goto L2; // [87] 60
L3: 
        ;
    }

    /** 	default_args = merge_parameters( load_euphoria_config("./" & conf_file), default_args, cmd_options, 1 )*/
    Concat((object_ptr)&_26083, _26082, _conf_file_49903);
    _26084 = _42load_euphoria_config(_26083);
    _26083 = NOVALUE;
    RefDS(_default_args_49902);
    RefDS(_cmd_options_49905);
    _0 = _default_args_49902;
    _default_args_49902 = _43merge_parameters(_26084, _default_args_49902, _cmd_options_49905, 1);
    DeRefDS(_0);
    _26084 = NOVALUE;

    /** 	env = strip_file_from_path( exe_path() )*/
    _26086 = _42exe_path();
    _0 = _env_49901;
    _env_49901 = _42strip_file_from_path(_26086);
    DeRef(_0);
    _26086 = NOVALUE;

    /** 	default_args = merge_parameters( load_euphoria_config( env & conf_file ), default_args, cmd_options, 1 )*/
    if (IS_SEQUENCE(_env_49901) && IS_ATOM(_conf_file_49903)) {
    }
    else if (IS_ATOM(_env_49901) && IS_SEQUENCE(_conf_file_49903)) {
        Ref(_env_49901);
        Prepend(&_26088, _conf_file_49903, _env_49901);
    }
    else {
        Concat((object_ptr)&_26088, _env_49901, _conf_file_49903);
    }
    _26089 = _42load_euphoria_config(_26088);
    _26088 = NOVALUE;
    RefDS(_default_args_49902);
    RefDS(_cmd_options_49905);
    _0 = _default_args_49902;
    _default_args_49902 = _43merge_parameters(_26089, _default_args_49902, _cmd_options_49905, 1);
    DeRefDS(_0);
    _26089 = NOVALUE;

    /** 	ifdef UNIX then*/

    /** 		env = getenv( "ALLUSERSPROFILE" )*/
    DeRef(_env_49901);
    _env_49901 = EGetEnv(_26093);

    /** 		if sequence(env) then*/
    _26095 = IS_SEQUENCE(_env_49901);
    if (_26095 == 0)
    {
        _26095 = NOVALUE;
        goto L4; // [151] 179
    }
    else{
        _26095 = NOVALUE;
    }

    /** 			default_args = merge_parameters( load_euphoria_config( expand_path( "euphoria", env ) & conf_file ), default_args, cmd_options, 1 )*/
    RefDS(_26096);
    Ref(_env_49901);
    _26097 = _42expand_path(_26096, _env_49901);
    if (IS_SEQUENCE(_26097) && IS_ATOM(_conf_file_49903)) {
    }
    else if (IS_ATOM(_26097) && IS_SEQUENCE(_conf_file_49903)) {
        Ref(_26097);
        Prepend(&_26098, _conf_file_49903, _26097);
    }
    else {
        Concat((object_ptr)&_26098, _26097, _conf_file_49903);
        DeRef(_26097);
        _26097 = NOVALUE;
    }
    DeRef(_26097);
    _26097 = NOVALUE;
    _26099 = _42load_euphoria_config(_26098);
    _26098 = NOVALUE;
    RefDS(_default_args_49902);
    RefDS(_cmd_options_49905);
    _0 = _default_args_49902;
    _default_args_49902 = _43merge_parameters(_26099, _default_args_49902, _cmd_options_49905, 1);
    DeRefDS(_0);
    _26099 = NOVALUE;
L4: 

    /** 		env = getenv( "APPDATA" )*/
    DeRef(_env_49901);
    _env_49901 = EGetEnv(_26101);

    /** 		if sequence(env) then*/
    _26103 = IS_SEQUENCE(_env_49901);
    if (_26103 == 0)
    {
        _26103 = NOVALUE;
        goto L5; // [189] 217
    }
    else{
        _26103 = NOVALUE;
    }

    /** 			default_args = merge_parameters( load_euphoria_config( expand_path( "euphoria", env ) & conf_file ), default_args, cmd_options, 1 )*/
    RefDS(_26096);
    Ref(_env_49901);
    _26104 = _42expand_path(_26096, _env_49901);
    if (IS_SEQUENCE(_26104) && IS_ATOM(_conf_file_49903)) {
    }
    else if (IS_ATOM(_26104) && IS_SEQUENCE(_conf_file_49903)) {
        Ref(_26104);
        Prepend(&_26105, _conf_file_49903, _26104);
    }
    else {
        Concat((object_ptr)&_26105, _26104, _conf_file_49903);
        DeRef(_26104);
        _26104 = NOVALUE;
    }
    DeRef(_26104);
    _26104 = NOVALUE;
    _26106 = _42load_euphoria_config(_26105);
    _26105 = NOVALUE;
    RefDS(_default_args_49902);
    RefDS(_cmd_options_49905);
    _0 = _default_args_49902;
    _default_args_49902 = _43merge_parameters(_26106, _default_args_49902, _cmd_options_49905, 1);
    DeRefDS(_0);
    _26106 = NOVALUE;
L5: 

    /** 		env = getenv( "HOMEPATH" )*/
    DeRef(_env_49901);
    _env_49901 = EGetEnv(_26108);

    /** 		if sequence(env) then*/
    _26110 = IS_SEQUENCE(_env_49901);
    if (_26110 == 0)
    {
        _26110 = NOVALUE;
        goto L6; // [227] 256
    }
    else{
        _26110 = NOVALUE;
    }

    /** 			default_args = merge_parameters( load_euphoria_config( getenv( "HOMEDRIVE" ) & env & "\\" & conf_file ), default_args, cmd_options, 1 )*/
    _26112 = EGetEnv(_26111);
    {
        int concat_list[4];

        concat_list[0] = _conf_file_49903;
        concat_list[1] = _23578;
        concat_list[2] = _env_49901;
        concat_list[3] = _26112;
        Concat_N((object_ptr)&_26113, concat_list, 4);
    }
    DeRef(_26112);
    _26112 = NOVALUE;
    _26114 = _42load_euphoria_config(_26113);
    _26113 = NOVALUE;
    RefDS(_default_args_49902);
    RefDS(_cmd_options_49905);
    _0 = _default_args_49902;
    _default_args_49902 = _43merge_parameters(_26114, _default_args_49902, _cmd_options_49905, 1);
    DeRefDS(_0);
    _26114 = NOVALUE;
L6: 

    /** 	env = get_eudir()*/
    _0 = _env_49901;
    _env_49901 = _36get_eudir();
    DeRef(_0);

    /** 	if sequence(env) then*/
    _26117 = IS_SEQUENCE(_env_49901);
    if (_26117 == 0)
    {
        _26117 = NOVALUE;
        goto L7; // [266] 291
    }
    else{
        _26117 = NOVALUE;
    }

    /** 		default_args = merge_parameters( load_euphoria_config(env & "/" & conf_file), default_args, cmd_options, 1 )*/
    {
        int concat_list[3];

        concat_list[0] = _conf_file_49903;
        concat_list[1] = _23466;
        concat_list[2] = _env_49901;
        Concat_N((object_ptr)&_26118, concat_list, 3);
    }
    _26119 = _42load_euphoria_config(_26118);
    _26118 = NOVALUE;
    RefDS(_default_args_49902);
    RefDS(_cmd_options_49905);
    _0 = _default_args_49902;
    _default_args_49902 = _43merge_parameters(_26119, _default_args_49902, _cmd_options_49905, 1);
    DeRefDS(_0);
    _26119 = NOVALUE;
L7: 

    /** 	return default_args*/
    DeRefDS(_user_files_49900);
    DeRef(_env_49901);
    DeRefi(_conf_file_49903);
    DeRef(_cmd_options_49905);
    return _default_args_49902;
    ;
}


int _42ConfPath(int _file_name_49968)
{
    int _file_path_49969 = NOVALUE;
    int _try_49970 = NOVALUE;
    int _26126 = NOVALUE;
    int _26122 = NOVALUE;
    int _26121 = NOVALUE;
    int _0, _1, _2;
    

    /** 	for i = 1 to length(config_inc_paths) do*/
    if (IS_SEQUENCE(_42config_inc_paths_49585)){
            _26121 = SEQ_PTR(_42config_inc_paths_49585)->length;
    }
    else {
        _26121 = 1;
    }
    {
        int _i_49972;
        _i_49972 = 1;
L1: 
        if (_i_49972 > _26121){
            goto L2; // [10] 60
        }

        /** 		file_path = config_inc_paths[i] & file_name*/
        _2 = (int)SEQ_PTR(_42config_inc_paths_49585);
        _26122 = (int)*(((s1_ptr)_2)->base + _i_49972);
        Concat((object_ptr)&_file_path_49969, _26122, _file_name_49968);
        _26122 = NOVALUE;
        _26122 = NOVALUE;

        /** 		try = open( file_path, "r" )*/
        _try_49970 = EOpen(_file_path_49969, _25993, 0);

        /** 		if try != -1 then*/
        if (_try_49970 == -1)
        goto L3; // [38] 53

        /** 			return {file_path, try}*/
        RefDS(_file_path_49969);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _file_path_49969;
        ((int *)_2)[2] = _try_49970;
        _26126 = MAKE_SEQ(_1);
        DeRefDS(_file_name_49968);
        DeRefDS(_file_path_49969);
        return _26126;
L3: 

        /** 	end for*/
        _i_49972 = _i_49972 + 1;
        goto L1; // [55] 17
L2: 
        ;
    }

    /** 	return -1*/
    DeRefDS(_file_name_49968);
    DeRef(_file_path_49969);
    DeRef(_26126);
    _26126 = NOVALUE;
    return -1;
    ;
}


int _42ScanPath(int _file_name_49982, int _env_49983, int _flag_49984)
{
    int _inc_path_49985 = NOVALUE;
    int _full_path_49986 = NOVALUE;
    int _file_path_49987 = NOVALUE;
    int _strings_49988 = NOVALUE;
    int _end_path_49989 = NOVALUE;
    int _start_path_49990 = NOVALUE;
    int _try_49991 = NOVALUE;
    int _use_cache_49992 = NOVALUE;
    int _pos_49993 = NOVALUE;
    int _26204 = NOVALUE;
    int _26203 = NOVALUE;
    int _26202 = NOVALUE;
    int _26201 = NOVALUE;
    int _26200 = NOVALUE;
    int _26199 = NOVALUE;
    int _26198 = NOVALUE;
    int _26197 = NOVALUE;
    int _26196 = NOVALUE;
    int _26195 = NOVALUE;
    int _26194 = NOVALUE;
    int _26193 = NOVALUE;
    int _26192 = NOVALUE;
    int _26191 = NOVALUE;
    int _26190 = NOVALUE;
    int _26189 = NOVALUE;
    int _26184 = NOVALUE;
    int _26183 = NOVALUE;
    int _26182 = NOVALUE;
    int _26181 = NOVALUE;
    int _26180 = NOVALUE;
    int _26176 = NOVALUE;
    int _26175 = NOVALUE;
    int _26174 = NOVALUE;
    int _26173 = NOVALUE;
    int _26172 = NOVALUE;
    int _26171 = NOVALUE;
    int _26169 = NOVALUE;
    int _26167 = NOVALUE;
    int _26166 = NOVALUE;
    int _26164 = NOVALUE;
    int _26163 = NOVALUE;
    int _26162 = NOVALUE;
    int _26159 = NOVALUE;
    int _26158 = NOVALUE;
    int _26156 = NOVALUE;
    int _26155 = NOVALUE;
    int _26154 = NOVALUE;
    int _26152 = NOVALUE;
    int _26150 = NOVALUE;
    int _26145 = NOVALUE;
    int _26144 = NOVALUE;
    int _26143 = NOVALUE;
    int _26142 = NOVALUE;
    int _26141 = NOVALUE;
    int _26136 = NOVALUE;
    int _26128 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_flag_49984)) {
        _1 = (long)(DBL_PTR(_flag_49984)->dbl);
        DeRefDS(_flag_49984);
        _flag_49984 = _1;
    }

    /** 	inc_path = getenv(env)*/
    DeRefi(_inc_path_49985);
    _inc_path_49985 = EGetEnv(_env_49983);

    /** 	if compare(inc_path,{})!=1 then -- nothing to do, just fail*/
    if (IS_ATOM_INT(_inc_path_49985) && IS_ATOM_INT(_22023)){
        _26128 = (_inc_path_49985 < _22023) ? -1 : (_inc_path_49985 > _22023);
    }
    else{
        _26128 = compare(_inc_path_49985, _22023);
    }
    if (_26128 == 1)
    goto L1; // [18] 29

    /** 		return -1*/
    DeRefDS(_file_name_49982);
    DeRefDS(_env_49983);
    DeRefi(_inc_path_49985);
    DeRef(_full_path_49986);
    DeRef(_file_path_49987);
    DeRef(_strings_49988);
    return -1;
L1: 

    /** 	num_var = find(env,cache_vars)*/
    _42num_var_49576 = find_from(_env_49983, _42cache_vars_49577, 1);

    /** 	use_cache = check_cache(env,inc_path)*/
    RefDS(_env_49983);
    Ref(_inc_path_49985);
    _use_cache_49992 = _42check_cache(_env_49983, _inc_path_49985);
    if (!IS_ATOM_INT(_use_cache_49992)) {
        _1 = (long)(DBL_PTR(_use_cache_49992)->dbl);
        DeRefDS(_use_cache_49992);
        _use_cache_49992 = _1;
    }

    /** 	inc_path = append(inc_path, PATH_SEPARATOR)*/
    Append(&_inc_path_49985, _inc_path_49985, 59);

    /** 	file_name = SLASH & file_name*/
    Prepend(&_file_name_49982, _file_name_49982, 92);

    /** 	if flag then*/
    if (_flag_49984 == 0)
    {
        goto L2; // [65] 77
    }
    else{
    }

    /** 		file_name = include_subfolder & file_name*/
    Concat((object_ptr)&_file_name_49982, _42include_subfolder_49572, _file_name_49982);
L2: 

    /** 	strings = cache_substrings[num_var]*/
    DeRef(_strings_49988);
    _2 = (int)SEQ_PTR(_42cache_substrings_49579);
    _strings_49988 = (int)*(((s1_ptr)_2)->base + _42num_var_49576);
    RefDS(_strings_49988);

    /** 	if use_cache then*/
    if (_use_cache_49992 == 0)
    {
        goto L3; // [91] 292
    }
    else{
    }

    /** 		for i=1 to length(strings) do*/
    if (IS_SEQUENCE(_strings_49988)){
            _26136 = SEQ_PTR(_strings_49988)->length;
    }
    else {
        _26136 = 1;
    }
    {
        int _i_50009;
        _i_50009 = 1;
L4: 
        if (_i_50009 > _26136){
            goto L5; // [99] 252
        }

        /** 			full_path = strings[i]*/
        DeRef(_full_path_49986);
        _2 = (int)SEQ_PTR(_strings_49988);
        _full_path_49986 = (int)*(((s1_ptr)_2)->base + _i_50009);
        Ref(_full_path_49986);

        /** 			file_path = full_path & file_name*/
        Concat((object_ptr)&_file_path_49987, _full_path_49986, _file_name_49982);

        /** 			try = open_locked(file_path)    */
        RefDS(_file_path_49987);
        _try_49991 = _36open_locked(_file_path_49987);
        if (!IS_ATOM_INT(_try_49991)) {
            _1 = (long)(DBL_PTR(_try_49991)->dbl);
            DeRefDS(_try_49991);
            _try_49991 = _1;
        }

        /** 			if try != -1 then*/
        if (_try_49991 == -1)
        goto L6; // [130] 145

        /** 				return {file_path,try}*/
        RefDS(_file_path_49987);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _file_path_49987;
        ((int *)_2)[2] = _try_49991;
        _26141 = MAKE_SEQ(_1);
        DeRefDS(_file_name_49982);
        DeRefDS(_env_49983);
        DeRefi(_inc_path_49985);
        DeRefDS(_full_path_49986);
        DeRefDS(_file_path_49987);
        DeRefDS(_strings_49988);
        return _26141;
L6: 

        /** 			ifdef WINDOWS then */

        /** 				if sequence(cache_converted[num_var][i]) then*/
        _2 = (int)SEQ_PTR(_42cache_converted_49582);
        _26142 = (int)*(((s1_ptr)_2)->base + _42num_var_49576);
        _2 = (int)SEQ_PTR(_26142);
        _26143 = (int)*(((s1_ptr)_2)->base + _i_50009);
        _26142 = NOVALUE;
        _26144 = IS_SEQUENCE(_26143);
        _26143 = NOVALUE;
        if (_26144 == 0)
        {
            _26144 = NOVALUE;
            goto L7; // [164] 245
        }
        else{
            _26144 = NOVALUE;
        }

        /** 					full_path = cache_converted[num_var][i]*/
        _2 = (int)SEQ_PTR(_42cache_converted_49582);
        _26145 = (int)*(((s1_ptr)_2)->base + _42num_var_49576);
        DeRef(_full_path_49986);
        _2 = (int)SEQ_PTR(_26145);
        _full_path_49986 = (int)*(((s1_ptr)_2)->base + _i_50009);
        Ref(_full_path_49986);
        _26145 = NOVALUE;

        /** 					file_path = full_path & file_name*/
        Concat((object_ptr)&_file_path_49987, _full_path_49986, _file_name_49982);

        /** 					try = open_locked(file_path)*/
        RefDS(_file_path_49987);
        _try_49991 = _36open_locked(_file_path_49987);
        if (!IS_ATOM_INT(_try_49991)) {
            _1 = (long)(DBL_PTR(_try_49991)->dbl);
            DeRefDS(_try_49991);
            _try_49991 = _1;
        }

        /** 					if try != -1 then*/
        if (_try_49991 == -1)
        goto L8; // [199] 244

        /** 						cache_converted[num_var][i] = 0*/
        _2 = (int)SEQ_PTR(_42cache_converted_49582);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _42cache_converted_49582 = MAKE_SEQ(_2);
        }
        _3 = (int)(_42num_var_49576 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_50009);
        _1 = *(int *)_2;
        *(int *)_2 = 0;
        DeRef(_1);
        _26150 = NOVALUE;

        /** 						cache_substrings[num_var][i] = full_path*/
        _2 = (int)SEQ_PTR(_42cache_substrings_49579);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _42cache_substrings_49579 = MAKE_SEQ(_2);
        }
        _3 = (int)(_42num_var_49576 + ((s1_ptr)_2)->base);
        RefDS(_full_path_49986);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_50009);
        _1 = *(int *)_2;
        *(int *)_2 = _full_path_49986;
        DeRef(_1);
        _26152 = NOVALUE;

        /** 						return {file_path,try}*/
        RefDS(_file_path_49987);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _file_path_49987;
        ((int *)_2)[2] = _try_49991;
        _26154 = MAKE_SEQ(_1);
        DeRefDS(_file_name_49982);
        DeRefDS(_env_49983);
        DeRefi(_inc_path_49985);
        DeRefDS(_full_path_49986);
        DeRefDS(_file_path_49987);
        DeRef(_strings_49988);
        DeRef(_26141);
        _26141 = NOVALUE;
        return _26154;
L8: 
L7: 

        /** 		end for*/
        _i_50009 = _i_50009 + 1;
        goto L4; // [247] 106
L5: 
        ;
    }

    /** 		if cache_complete[num_var] then -- nothing to scan*/
    _2 = (int)SEQ_PTR(_42cache_complete_49583);
    _26155 = (int)*(((s1_ptr)_2)->base + _42num_var_49576);
    if (_26155 == 0)
    {
        _26155 = NOVALUE;
        goto L9; // [262] 274
    }
    else{
        _26155 = NOVALUE;
    }

    /** 			return -1*/
    DeRefDS(_file_name_49982);
    DeRefDS(_env_49983);
    DeRefi(_inc_path_49985);
    DeRef(_full_path_49986);
    DeRef(_file_path_49987);
    DeRef(_strings_49988);
    DeRef(_26141);
    _26141 = NOVALUE;
    DeRef(_26154);
    _26154 = NOVALUE;
    return -1;
    goto LA; // [271] 298
L9: 

    /** 			pos = cache_delims[num_var]+1 -- scan remainder, starting from as far sa possible*/
    _2 = (int)SEQ_PTR(_42cache_delims_49584);
    _26156 = (int)*(((s1_ptr)_2)->base + _42num_var_49576);
    _pos_49993 = _26156 + 1;
    _26156 = NOVALUE;
    goto LA; // [289] 298
L3: 

    /** 		pos = 1*/
    _pos_49993 = 1;
LA: 

    /** 	start_path = 0*/
    _start_path_49990 = 0;

    /** 	for p = pos to length(inc_path) do*/
    if (IS_SEQUENCE(_inc_path_49985)){
            _26158 = SEQ_PTR(_inc_path_49985)->length;
    }
    else {
        _26158 = 1;
    }
    {
        int _p_50041;
        _p_50041 = _pos_49993;
LB: 
        if (_p_50041 > _26158){
            goto LC; // [310] 716
        }

        /** 		if inc_path[p] = PATH_SEPARATOR then*/
        _2 = (int)SEQ_PTR(_inc_path_49985);
        _26159 = (int)*(((s1_ptr)_2)->base + _p_50041);
        if (_26159 != 59)
        goto LD; // [325] 665

        /** 			cache_delims[num_var] = p*/
        _2 = (int)SEQ_PTR(_42cache_delims_49584);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _42cache_delims_49584 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _42num_var_49576);
        *(int *)_2 = _p_50041;

        /** 			end_path = p-1*/
        _end_path_49989 = _p_50041 - 1;

        /** 			while end_path >= start_path and find(inc_path[end_path], " \t" & SLASH_CHARS) do*/
LE: 
        _26162 = (_end_path_49989 >= _start_path_49990);
        if (_26162 == 0) {
            goto LF; // [354] 388
        }
        _2 = (int)SEQ_PTR(_inc_path_49985);
        _26164 = (int)*(((s1_ptr)_2)->base + _end_path_49989);
        Concat((object_ptr)&_26166, _26165, _40SLASH_CHARS_16402);
        _26167 = find_from(_26164, _26166, 1);
        _26164 = NOVALUE;
        DeRefDS(_26166);
        _26166 = NOVALUE;
        if (_26167 == 0)
        {
            _26167 = NOVALUE;
            goto LF; // [374] 388
        }
        else{
            _26167 = NOVALUE;
        }

        /** 				end_path-=1*/
        _end_path_49989 = _end_path_49989 - 1;

        /** 			end while*/
        goto LE; // [385] 350
LF: 

        /** 			if start_path and end_path then*/
        if (_start_path_49990 == 0) {
            goto L10; // [390] 709
        }
        if (_end_path_49989 == 0)
        {
            goto L10; // [395] 709
        }
        else{
        }

        /** 				full_path = inc_path[start_path..end_path]*/
        rhs_slice_target = (object_ptr)&_full_path_49986;
        RHS_Slice(_inc_path_49985, _start_path_49990, _end_path_49989);

        /** 				cache_substrings[num_var] = append(cache_substrings[num_var],full_path)*/
        _2 = (int)SEQ_PTR(_42cache_substrings_49579);
        _26171 = (int)*(((s1_ptr)_2)->base + _42num_var_49576);
        RefDS(_full_path_49986);
        Append(&_26172, _26171, _full_path_49986);
        _26171 = NOVALUE;
        _2 = (int)SEQ_PTR(_42cache_substrings_49579);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _42cache_substrings_49579 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _42num_var_49576);
        _1 = *(int *)_2;
        *(int *)_2 = _26172;
        if( _1 != _26172 ){
            DeRefDS(_1);
        }
        _26172 = NOVALUE;

        /** 				cache_starts[num_var] &= start_path*/
        _2 = (int)SEQ_PTR(_42cache_starts_49580);
        _26173 = (int)*(((s1_ptr)_2)->base + _42num_var_49576);
        if (IS_SEQUENCE(_26173) && IS_ATOM(_start_path_49990)) {
            Append(&_26174, _26173, _start_path_49990);
        }
        else if (IS_ATOM(_26173) && IS_SEQUENCE(_start_path_49990)) {
        }
        else {
            Concat((object_ptr)&_26174, _26173, _start_path_49990);
            _26173 = NOVALUE;
        }
        _26173 = NOVALUE;
        _2 = (int)SEQ_PTR(_42cache_starts_49580);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _42cache_starts_49580 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _42num_var_49576);
        _1 = *(int *)_2;
        *(int *)_2 = _26174;
        if( _1 != _26174 ){
            DeRef(_1);
        }
        _26174 = NOVALUE;

        /** 				cache_ends[num_var] &= end_path*/
        _2 = (int)SEQ_PTR(_42cache_ends_49581);
        _26175 = (int)*(((s1_ptr)_2)->base + _42num_var_49576);
        if (IS_SEQUENCE(_26175) && IS_ATOM(_end_path_49989)) {
            Append(&_26176, _26175, _end_path_49989);
        }
        else if (IS_ATOM(_26175) && IS_SEQUENCE(_end_path_49989)) {
        }
        else {
            Concat((object_ptr)&_26176, _26175, _end_path_49989);
            _26175 = NOVALUE;
        }
        _26175 = NOVALUE;
        _2 = (int)SEQ_PTR(_42cache_ends_49581);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _42cache_ends_49581 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _42num_var_49576);
        _1 = *(int *)_2;
        *(int *)_2 = _26176;
        if( _1 != _26176 ){
            DeRef(_1);
        }
        _26176 = NOVALUE;

        /** 				file_path = full_path & file_name  */
        Concat((object_ptr)&_file_path_49987, _full_path_49986, _file_name_49982);

        /** 				try = open_locked(file_path)*/
        RefDS(_file_path_49987);
        _try_49991 = _36open_locked(_file_path_49987);
        if (!IS_ATOM_INT(_try_49991)) {
            _1 = (long)(DBL_PTR(_try_49991)->dbl);
            DeRefDS(_try_49991);
            _try_49991 = _1;
        }

        /** 				if try != -1 then -- valid path, no point trying to convert*/
        if (_try_49991 == -1)
        goto L11; // [479] 514

        /** 					ifdef WINDOWS then*/

        /** 						cache_converted[num_var] &= 0*/
        _2 = (int)SEQ_PTR(_42cache_converted_49582);
        _26180 = (int)*(((s1_ptr)_2)->base + _42num_var_49576);
        if (IS_SEQUENCE(_26180) && IS_ATOM(0)) {
            Append(&_26181, _26180, 0);
        }
        else if (IS_ATOM(_26180) && IS_SEQUENCE(0)) {
        }
        else {
            Concat((object_ptr)&_26181, _26180, 0);
            _26180 = NOVALUE;
        }
        _26180 = NOVALUE;
        _2 = (int)SEQ_PTR(_42cache_converted_49582);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _42cache_converted_49582 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _42num_var_49576);
        _1 = *(int *)_2;
        *(int *)_2 = _26181;
        if( _1 != _26181 ){
            DeRef(_1);
        }
        _26181 = NOVALUE;

        /** 					return {file_path,try}*/
        RefDS(_file_path_49987);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _file_path_49987;
        ((int *)_2)[2] = _try_49991;
        _26182 = MAKE_SEQ(_1);
        DeRefDS(_file_name_49982);
        DeRefDS(_env_49983);
        DeRefi(_inc_path_49985);
        DeRefDSi(_full_path_49986);
        DeRefDS(_file_path_49987);
        DeRef(_strings_49988);
        DeRef(_26141);
        _26141 = NOVALUE;
        DeRef(_26154);
        _26154 = NOVALUE;
        _26159 = NOVALUE;
        DeRef(_26162);
        _26162 = NOVALUE;
        return _26182;
L11: 

        /** 				ifdef WINDOWS then*/

        /** 					if find(1, full_path>=128) then*/
        _26183 = binary_op(GREATEREQ, _full_path_49986, 128);
        _26184 = find_from(1, _26183, 1);
        DeRefDS(_26183);
        _26183 = NOVALUE;
        if (_26184 == 0)
        {
            _26184 = NOVALUE;
            goto L12; // [527] 637
        }
        else{
            _26184 = NOVALUE;
        }

        /** 						full_path = convert_from_OEM(full_path)*/
        RefDS(_full_path_49986);
        _0 = _full_path_49986;
        _full_path_49986 = _42convert_from_OEM(_full_path_49986);
        DeRefDS(_0);

        /** 						file_path = full_path & file_name*/
        Concat((object_ptr)&_file_path_49987, _full_path_49986, _file_name_49982);

        /** 						try = open_locked(file_path)*/
        RefDS(_file_path_49987);
        _try_49991 = _36open_locked(_file_path_49987);
        if (!IS_ATOM_INT(_try_49991)) {
            _1 = (long)(DBL_PTR(_try_49991)->dbl);
            DeRefDS(_try_49991);
            _try_49991 = _1;
        }

        /** 						if try != -1 then -- that was it; record translation as the valid path*/
        if (_try_49991 == -1)
        goto L13; // [554] 611

        /** 							cache_converted[num_var] &= 0*/
        _2 = (int)SEQ_PTR(_42cache_converted_49582);
        _26189 = (int)*(((s1_ptr)_2)->base + _42num_var_49576);
        if (IS_SEQUENCE(_26189) && IS_ATOM(0)) {
            Append(&_26190, _26189, 0);
        }
        else if (IS_ATOM(_26189) && IS_SEQUENCE(0)) {
        }
        else {
            Concat((object_ptr)&_26190, _26189, 0);
            _26189 = NOVALUE;
        }
        _26189 = NOVALUE;
        _2 = (int)SEQ_PTR(_42cache_converted_49582);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _42cache_converted_49582 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _42num_var_49576);
        _1 = *(int *)_2;
        *(int *)_2 = _26190;
        if( _1 != _26190 ){
            DeRef(_1);
        }
        _26190 = NOVALUE;

        /** 							cache_substrings[num_var] = append(cache_substrings[num_var],full_path)*/
        _2 = (int)SEQ_PTR(_42cache_substrings_49579);
        _26191 = (int)*(((s1_ptr)_2)->base + _42num_var_49576);
        RefDS(_full_path_49986);
        Append(&_26192, _26191, _full_path_49986);
        _26191 = NOVALUE;
        _2 = (int)SEQ_PTR(_42cache_substrings_49579);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _42cache_substrings_49579 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _42num_var_49576);
        _1 = *(int *)_2;
        *(int *)_2 = _26192;
        if( _1 != _26192 ){
            DeRefDS(_1);
        }
        _26192 = NOVALUE;

        /** 							return {file_path,try}*/
        RefDS(_file_path_49987);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _file_path_49987;
        ((int *)_2)[2] = _try_49991;
        _26193 = MAKE_SEQ(_1);
        DeRefDS(_file_name_49982);
        DeRefDS(_env_49983);
        DeRefi(_inc_path_49985);
        DeRefDS(_full_path_49986);
        DeRefDS(_file_path_49987);
        DeRef(_strings_49988);
        DeRef(_26141);
        _26141 = NOVALUE;
        DeRef(_26154);
        _26154 = NOVALUE;
        _26159 = NOVALUE;
        DeRef(_26162);
        _26162 = NOVALUE;
        DeRef(_26182);
        _26182 = NOVALUE;
        return _26193;
        goto L14; // [608] 656
L13: 

        /** 							cache_converted[num_var] = append(cache_converted[num_var],full_path)*/
        _2 = (int)SEQ_PTR(_42cache_converted_49582);
        _26194 = (int)*(((s1_ptr)_2)->base + _42num_var_49576);
        RefDS(_full_path_49986);
        Append(&_26195, _26194, _full_path_49986);
        _26194 = NOVALUE;
        _2 = (int)SEQ_PTR(_42cache_converted_49582);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _42cache_converted_49582 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _42num_var_49576);
        _1 = *(int *)_2;
        *(int *)_2 = _26195;
        if( _1 != _26195 ){
            DeRef(_1);
        }
        _26195 = NOVALUE;
        goto L14; // [634] 656
L12: 

        /** 						cache_converted[num_var] &= 0*/
        _2 = (int)SEQ_PTR(_42cache_converted_49582);
        _26196 = (int)*(((s1_ptr)_2)->base + _42num_var_49576);
        if (IS_SEQUENCE(_26196) && IS_ATOM(0)) {
            Append(&_26197, _26196, 0);
        }
        else if (IS_ATOM(_26196) && IS_SEQUENCE(0)) {
        }
        else {
            Concat((object_ptr)&_26197, _26196, 0);
            _26196 = NOVALUE;
        }
        _26196 = NOVALUE;
        _2 = (int)SEQ_PTR(_42cache_converted_49582);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _42cache_converted_49582 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _42num_var_49576);
        _1 = *(int *)_2;
        *(int *)_2 = _26197;
        if( _1 != _26197 ){
            DeRef(_1);
        }
        _26197 = NOVALUE;
L14: 

        /** 				start_path = 0*/
        _start_path_49990 = 0;
        goto L10; // [662] 709
LD: 

        /** 		elsif not start_path and (inc_path[p] != ' ' and inc_path[p] != '\t') then*/
        _26198 = (_start_path_49990 == 0);
        if (_26198 == 0) {
            goto L15; // [670] 708
        }
        _2 = (int)SEQ_PTR(_inc_path_49985);
        _26200 = (int)*(((s1_ptr)_2)->base + _p_50041);
        _26201 = (_26200 != 32);
        _26200 = NOVALUE;
        if (_26201 == 0) {
            DeRef(_26202);
            _26202 = 0;
            goto L16; // [682] 698
        }
        _2 = (int)SEQ_PTR(_inc_path_49985);
        _26203 = (int)*(((s1_ptr)_2)->base + _p_50041);
        _26204 = (_26203 != 9);
        _26203 = NOVALUE;
        _26202 = (_26204 != 0);
L16: 
        if (_26202 == 0)
        {
            _26202 = NOVALUE;
            goto L15; // [699] 708
        }
        else{
            _26202 = NOVALUE;
        }

        /** 			start_path = p*/
        _start_path_49990 = _p_50041;
L15: 
L10: 

        /** 	end for*/
        _p_50041 = _p_50041 + 1;
        goto LB; // [711] 317
LC: 
        ;
    }

    /** 	cache_complete[num_var] = 1*/
    _2 = (int)SEQ_PTR(_42cache_complete_49583);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _42cache_complete_49583 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _42num_var_49576);
    *(int *)_2 = 1;

    /** 	return -1*/
    DeRefDS(_file_name_49982);
    DeRefDS(_env_49983);
    DeRefi(_inc_path_49985);
    DeRef(_full_path_49986);
    DeRef(_file_path_49987);
    DeRef(_strings_49988);
    DeRef(_26141);
    _26141 = NOVALUE;
    DeRef(_26154);
    _26154 = NOVALUE;
    _26159 = NOVALUE;
    DeRef(_26162);
    _26162 = NOVALUE;
    DeRef(_26182);
    _26182 = NOVALUE;
    DeRef(_26193);
    _26193 = NOVALUE;
    DeRef(_26198);
    _26198 = NOVALUE;
    DeRef(_26201);
    _26201 = NOVALUE;
    DeRef(_26204);
    _26204 = NOVALUE;
    return -1;
    ;
}


int _42Include_paths(int _add_converted_50105)
{
    int _status_50106 = NOVALUE;
    int _pos_50107 = NOVALUE;
    int _inc_path_50108 = NOVALUE;
    int _full_path_50109 = NOVALUE;
    int _start_path_50110 = NOVALUE;
    int _end_path_50111 = NOVALUE;
    int _eudir_path_50127 = NOVALUE;
    int _26265 = NOVALUE;
    int _26264 = NOVALUE;
    int _26263 = NOVALUE;
    int _26262 = NOVALUE;
    int _26261 = NOVALUE;
    int _26260 = NOVALUE;
    int _26259 = NOVALUE;
    int _26257 = NOVALUE;
    int _26256 = NOVALUE;
    int _26255 = NOVALUE;
    int _26254 = NOVALUE;
    int _26253 = NOVALUE;
    int _26252 = NOVALUE;
    int _26251 = NOVALUE;
    int _26250 = NOVALUE;
    int _26249 = NOVALUE;
    int _26248 = NOVALUE;
    int _26247 = NOVALUE;
    int _26246 = NOVALUE;
    int _26245 = NOVALUE;
    int _26244 = NOVALUE;
    int _26243 = NOVALUE;
    int _26242 = NOVALUE;
    int _26241 = NOVALUE;
    int _26240 = NOVALUE;
    int _26239 = NOVALUE;
    int _26238 = NOVALUE;
    int _26237 = NOVALUE;
    int _26235 = NOVALUE;
    int _26233 = NOVALUE;
    int _26232 = NOVALUE;
    int _26231 = NOVALUE;
    int _26230 = NOVALUE;
    int _26229 = NOVALUE;
    int _26226 = NOVALUE;
    int _26225 = NOVALUE;
    int _26223 = NOVALUE;
    int _26221 = NOVALUE;
    int _26219 = NOVALUE;
    int _26218 = NOVALUE;
    int _26216 = NOVALUE;
    int _26213 = NOVALUE;
    int _26211 = NOVALUE;
    int _26206 = NOVALUE;
    int _26205 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_add_converted_50105)) {
        _1 = (long)(DBL_PTR(_add_converted_50105)->dbl);
        DeRefDS(_add_converted_50105);
        _add_converted_50105 = _1;
    }

    /** 	if length(include_Paths) then*/
    if (IS_SEQUENCE(_42include_Paths_50102)){
            _26205 = SEQ_PTR(_42include_Paths_50102)->length;
    }
    else {
        _26205 = 1;
    }
    if (_26205 == 0)
    {
        _26205 = NOVALUE;
        goto L1; // [10] 22
    }
    else{
        _26205 = NOVALUE;
    }

    /** 		return include_Paths*/
    RefDS(_42include_Paths_50102);
    DeRefi(_inc_path_50108);
    DeRefi(_full_path_50109);
    DeRef(_eudir_path_50127);
    return _42include_Paths_50102;
L1: 

    /** 	include_Paths = append(config_inc_paths, current_dir())*/
    _26206 = _17current_dir();
    Ref(_26206);
    Append(&_42include_Paths_50102, _42config_inc_paths_49585, _26206);
    DeRef(_26206);
    _26206 = NOVALUE;

    /** 	num_var = find("EUINC", cache_vars)*/
    _42num_var_49576 = find_from(_26208, _42cache_vars_49577, 1);

    /** 	inc_path = getenv("EUINC")*/
    DeRefi(_inc_path_50108);
    _inc_path_50108 = EGetEnv(_26208);

    /** 	if atom(inc_path) then*/
    _26211 = IS_ATOM(_inc_path_50108);
    if (_26211 == 0)
    {
        _26211 = NOVALUE;
        goto L2; // [52] 61
    }
    else{
        _26211 = NOVALUE;
    }

    /** 		inc_path = ""*/
    RefDS(_22023);
    DeRefi(_inc_path_50108);
    _inc_path_50108 = _22023;
L2: 

    /** 	status = check_cache("EUINC", inc_path)*/
    RefDS(_26208);
    Ref(_inc_path_50108);
    _status_50106 = _42check_cache(_26208, _inc_path_50108);
    if (!IS_ATOM_INT(_status_50106)) {
        _1 = (long)(DBL_PTR(_status_50106)->dbl);
        DeRefDS(_status_50106);
        _status_50106 = _1;
    }

    /** 	if length(inc_path) then*/
    if (IS_SEQUENCE(_inc_path_50108)){
            _26213 = SEQ_PTR(_inc_path_50108)->length;
    }
    else {
        _26213 = 1;
    }
    if (_26213 == 0)
    {
        _26213 = NOVALUE;
        goto L3; // [75] 87
    }
    else{
        _26213 = NOVALUE;
    }

    /** 		inc_path = append(inc_path, PATH_SEPARATOR)*/
    Append(&_inc_path_50108, _inc_path_50108, 59);
L3: 

    /** 	object eudir_path = get_eudir()*/
    _0 = _eudir_path_50127;
    _eudir_path_50127 = _36get_eudir();
    DeRef(_0);

    /** 	if sequence(eudir_path) then*/
    _26216 = IS_SEQUENCE(_eudir_path_50127);
    if (_26216 == 0)
    {
        _26216 = NOVALUE;
        goto L4; // [97] 117
    }
    else{
        _26216 = NOVALUE;
    }

    /** 		include_Paths = append(include_Paths, sprintf("%s/include", { eudir_path }))*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_eudir_path_50127);
    *((int *)(_2+4)) = _eudir_path_50127;
    _26218 = MAKE_SEQ(_1);
    _26219 = EPrintf(-9999999, _26217, _26218);
    DeRefDS(_26218);
    _26218 = NOVALUE;
    RefDS(_26219);
    Append(&_42include_Paths_50102, _42include_Paths_50102, _26219);
    DeRefDS(_26219);
    _26219 = NOVALUE;
L4: 

    /** 	if status then*/
    if (_status_50106 == 0)
    {
        goto L5; // [119] 161
    }
    else{
    }

    /** 		if cache_complete[num_var] then*/
    _2 = (int)SEQ_PTR(_42cache_complete_49583);
    _26221 = (int)*(((s1_ptr)_2)->base + _42num_var_49576);
    if (_26221 == 0)
    {
        _26221 = NOVALUE;
        goto L6; // [132] 144
    }
    else{
        _26221 = NOVALUE;
    }

    /** 			goto "cache done"*/
    goto G7;
L6: 

    /** 		pos = cache_delims[num_var]+1*/
    _2 = (int)SEQ_PTR(_42cache_delims_49584);
    _26223 = (int)*(((s1_ptr)_2)->base + _42num_var_49576);
    _pos_50107 = _26223 + 1;
    _26223 = NOVALUE;
    goto L8; // [158] 167
L5: 

    /**         pos = 1*/
    _pos_50107 = 1;
L8: 

    /** 	start_path = 0*/
    _start_path_50110 = 0;

    /** 	for p = pos to length(inc_path) do*/
    if (IS_SEQUENCE(_inc_path_50108)){
            _26225 = SEQ_PTR(_inc_path_50108)->length;
    }
    else {
        _26225 = 1;
    }
    {
        int _p_50144;
        _p_50144 = _pos_50107;
L9: 
        if (_p_50144 > _26225){
            goto LA; // [179] 456
        }

        /** 		if inc_path[p] = PATH_SEPARATOR then*/
        _2 = (int)SEQ_PTR(_inc_path_50108);
        _26226 = (int)*(((s1_ptr)_2)->base + _p_50144);
        if (_26226 != 59)
        goto LB; // [194] 405

        /** 			cache_delims[num_var] = p*/
        _2 = (int)SEQ_PTR(_42cache_delims_49584);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _42cache_delims_49584 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _42num_var_49576);
        *(int *)_2 = _p_50144;

        /** 			end_path = p-1*/
        _end_path_50111 = _p_50144 - 1;

        /** 			while end_path >= start_path and find(inc_path[end_path]," \t" & SLASH_CHARS) do*/
LC: 
        _26229 = (_end_path_50111 >= _start_path_50110);
        if (_26229 == 0) {
            goto LD; // [223] 257
        }
        _2 = (int)SEQ_PTR(_inc_path_50108);
        _26231 = (int)*(((s1_ptr)_2)->base + _end_path_50111);
        Concat((object_ptr)&_26232, _26165, _40SLASH_CHARS_16402);
        _26233 = find_from(_26231, _26232, 1);
        _26231 = NOVALUE;
        DeRefDS(_26232);
        _26232 = NOVALUE;
        if (_26233 == 0)
        {
            _26233 = NOVALUE;
            goto LD; // [243] 257
        }
        else{
            _26233 = NOVALUE;
        }

        /** 				end_path -= 1*/
        _end_path_50111 = _end_path_50111 - 1;

        /** 			end while*/
        goto LC; // [254] 219
LD: 

        /** 			if start_path and end_path then*/
        if (_start_path_50110 == 0) {
            goto LE; // [259] 449
        }
        if (_end_path_50111 == 0)
        {
            goto LE; // [264] 449
        }
        else{
        }

        /** 				full_path = inc_path[start_path..end_path]*/
        rhs_slice_target = (object_ptr)&_full_path_50109;
        RHS_Slice(_inc_path_50108, _start_path_50110, _end_path_50111);

        /** 				cache_substrings[num_var] = append(cache_substrings[num_var],full_path)*/
        _2 = (int)SEQ_PTR(_42cache_substrings_49579);
        _26237 = (int)*(((s1_ptr)_2)->base + _42num_var_49576);
        RefDS(_full_path_50109);
        Append(&_26238, _26237, _full_path_50109);
        _26237 = NOVALUE;
        _2 = (int)SEQ_PTR(_42cache_substrings_49579);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _42cache_substrings_49579 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _42num_var_49576);
        _1 = *(int *)_2;
        *(int *)_2 = _26238;
        if( _1 != _26238 ){
            DeRefDS(_1);
        }
        _26238 = NOVALUE;

        /** 				cache_starts[num_var] &= start_path*/
        _2 = (int)SEQ_PTR(_42cache_starts_49580);
        _26239 = (int)*(((s1_ptr)_2)->base + _42num_var_49576);
        if (IS_SEQUENCE(_26239) && IS_ATOM(_start_path_50110)) {
            Append(&_26240, _26239, _start_path_50110);
        }
        else if (IS_ATOM(_26239) && IS_SEQUENCE(_start_path_50110)) {
        }
        else {
            Concat((object_ptr)&_26240, _26239, _start_path_50110);
            _26239 = NOVALUE;
        }
        _26239 = NOVALUE;
        _2 = (int)SEQ_PTR(_42cache_starts_49580);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _42cache_starts_49580 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _42num_var_49576);
        _1 = *(int *)_2;
        *(int *)_2 = _26240;
        if( _1 != _26240 ){
            DeRef(_1);
        }
        _26240 = NOVALUE;

        /** 				cache_ends[num_var] &= end_path*/
        _2 = (int)SEQ_PTR(_42cache_ends_49581);
        _26241 = (int)*(((s1_ptr)_2)->base + _42num_var_49576);
        if (IS_SEQUENCE(_26241) && IS_ATOM(_end_path_50111)) {
            Append(&_26242, _26241, _end_path_50111);
        }
        else if (IS_ATOM(_26241) && IS_SEQUENCE(_end_path_50111)) {
        }
        else {
            Concat((object_ptr)&_26242, _26241, _end_path_50111);
            _26241 = NOVALUE;
        }
        _26241 = NOVALUE;
        _2 = (int)SEQ_PTR(_42cache_ends_49581);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _42cache_ends_49581 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _42num_var_49576);
        _1 = *(int *)_2;
        *(int *)_2 = _26242;
        if( _1 != _26242 ){
            DeRef(_1);
        }
        _26242 = NOVALUE;

        /** 				ifdef WINDOWS then*/

        /** 					if find(1, full_path>=128) then*/
        _26243 = binary_op(GREATEREQ, _full_path_50109, 128);
        _26244 = find_from(1, _26243, 1);
        DeRefDS(_26243);
        _26243 = NOVALUE;
        if (_26244 == 0)
        {
            _26244 = NOVALUE;
            goto LF; // [345] 377
        }
        else{
            _26244 = NOVALUE;
        }

        /** 						cache_converted[num_var] = append(cache_converted[num_var], */
        _2 = (int)SEQ_PTR(_42cache_converted_49582);
        _26245 = (int)*(((s1_ptr)_2)->base + _42num_var_49576);
        RefDS(_full_path_50109);
        _26246 = _42convert_from_OEM(_full_path_50109);
        Ref(_26246);
        Append(&_26247, _26245, _26246);
        _26245 = NOVALUE;
        DeRef(_26246);
        _26246 = NOVALUE;
        _2 = (int)SEQ_PTR(_42cache_converted_49582);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _42cache_converted_49582 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _42num_var_49576);
        _1 = *(int *)_2;
        *(int *)_2 = _26247;
        if( _1 != _26247 ){
            DeRef(_1);
        }
        _26247 = NOVALUE;
        goto L10; // [374] 396
LF: 

        /** 						cache_converted[num_var] &= 0*/
        _2 = (int)SEQ_PTR(_42cache_converted_49582);
        _26248 = (int)*(((s1_ptr)_2)->base + _42num_var_49576);
        if (IS_SEQUENCE(_26248) && IS_ATOM(0)) {
            Append(&_26249, _26248, 0);
        }
        else if (IS_ATOM(_26248) && IS_SEQUENCE(0)) {
        }
        else {
            Concat((object_ptr)&_26249, _26248, 0);
            _26248 = NOVALUE;
        }
        _26248 = NOVALUE;
        _2 = (int)SEQ_PTR(_42cache_converted_49582);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _42cache_converted_49582 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _42num_var_49576);
        _1 = *(int *)_2;
        *(int *)_2 = _26249;
        if( _1 != _26249 ){
            DeRef(_1);
        }
        _26249 = NOVALUE;
L10: 

        /** 				start_path = 0*/
        _start_path_50110 = 0;
        goto LE; // [402] 449
LB: 

        /** 		elsif not start_path and (inc_path[p] != ' ' and inc_path[p] != '\t') then*/
        _26250 = (_start_path_50110 == 0);
        if (_26250 == 0) {
            goto L11; // [410] 448
        }
        _2 = (int)SEQ_PTR(_inc_path_50108);
        _26252 = (int)*(((s1_ptr)_2)->base + _p_50144);
        _26253 = (_26252 != 32);
        _26252 = NOVALUE;
        if (_26253 == 0) {
            DeRef(_26254);
            _26254 = 0;
            goto L12; // [422] 438
        }
        _2 = (int)SEQ_PTR(_inc_path_50108);
        _26255 = (int)*(((s1_ptr)_2)->base + _p_50144);
        _26256 = (_26255 != 9);
        _26255 = NOVALUE;
        _26254 = (_26256 != 0);
L12: 
        if (_26254 == 0)
        {
            _26254 = NOVALUE;
            goto L11; // [439] 448
        }
        else{
            _26254 = NOVALUE;
        }

        /** 			start_path = p*/
        _start_path_50110 = _p_50144;
L11: 
LE: 

        /** 	end for*/
        _p_50144 = _p_50144 + 1;
        goto L9; // [451] 186
LA: 
        ;
    }

    /** label "cache done"*/
G7:

    /** 	include_Paths &= cache_substrings[num_var]*/
    _2 = (int)SEQ_PTR(_42cache_substrings_49579);
    _26257 = (int)*(((s1_ptr)_2)->base + _42num_var_49576);
    Concat((object_ptr)&_42include_Paths_50102, _42include_Paths_50102, _26257);
    _26257 = NOVALUE;

    /** 	cache_complete[num_var] = 1*/
    _2 = (int)SEQ_PTR(_42cache_complete_49583);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _42cache_complete_49583 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _42num_var_49576);
    *(int *)_2 = 1;

    /** 	ifdef WINDOWS then*/

    /** 		if add_converted then*/
    if (_add_converted_50105 == 0)
    {
        goto L13; // [490] 562
    }
    else{
    }

    /** 	    	for i=1 to length(cache_converted[num_var]) do*/
    _2 = (int)SEQ_PTR(_42cache_converted_49582);
    _26259 = (int)*(((s1_ptr)_2)->base + _42num_var_49576);
    if (IS_SEQUENCE(_26259)){
            _26260 = SEQ_PTR(_26259)->length;
    }
    else {
        _26260 = 1;
    }
    _26259 = NOVALUE;
    {
        int _i_50189;
        _i_50189 = 1;
L14: 
        if (_i_50189 > _26260){
            goto L15; // [506] 561
        }

        /** 	        	if sequence(cache_converted[num_var][i]) then*/
        _2 = (int)SEQ_PTR(_42cache_converted_49582);
        _26261 = (int)*(((s1_ptr)_2)->base + _42num_var_49576);
        _2 = (int)SEQ_PTR(_26261);
        _26262 = (int)*(((s1_ptr)_2)->base + _i_50189);
        _26261 = NOVALUE;
        _26263 = IS_SEQUENCE(_26262);
        _26262 = NOVALUE;
        if (_26263 == 0)
        {
            _26263 = NOVALUE;
            goto L16; // [530] 554
        }
        else{
            _26263 = NOVALUE;
        }

        /** 		        	include_Paths = append(include_Paths, cache_converted[num_var][i])*/
        _2 = (int)SEQ_PTR(_42cache_converted_49582);
        _26264 = (int)*(((s1_ptr)_2)->base + _42num_var_49576);
        _2 = (int)SEQ_PTR(_26264);
        _26265 = (int)*(((s1_ptr)_2)->base + _i_50189);
        _26264 = NOVALUE;
        Ref(_26265);
        Append(&_42include_Paths_50102, _42include_Paths_50102, _26265);
        _26265 = NOVALUE;
L16: 

        /** 			end for*/
        _i_50189 = _i_50189 + 1;
        goto L14; // [556] 513
L15: 
        ;
    }
L13: 

    /** 	return include_Paths*/
    RefDS(_42include_Paths_50102);
    DeRefi(_inc_path_50108);
    DeRefi(_full_path_50109);
    DeRef(_eudir_path_50127);
    _26226 = NOVALUE;
    DeRef(_26229);
    _26229 = NOVALUE;
    DeRef(_26250);
    _26250 = NOVALUE;
    _26259 = NOVALUE;
    DeRef(_26253);
    _26253 = NOVALUE;
    DeRef(_26256);
    _26256 = NOVALUE;
    return _42include_Paths_50102;
    ;
}


int _42e_path_find(int _name_50201)
{
    int _scan_result_50202 = NOVALUE;
    int _26275 = NOVALUE;
    int _26274 = NOVALUE;
    int _26273 = NOVALUE;
    int _26270 = NOVALUE;
    int _26269 = NOVALUE;
    int _26268 = NOVALUE;
    int _26267 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if file_exists(name) then*/
    RefDS(_name_50201);
    _26267 = _17file_exists(_name_50201);
    if (_26267 == 0) {
        DeRef(_26267);
        _26267 = NOVALUE;
        goto L1; // [9] 19
    }
    else {
        if (!IS_ATOM_INT(_26267) && DBL_PTR(_26267)->dbl == 0.0){
            DeRef(_26267);
            _26267 = NOVALUE;
            goto L1; // [9] 19
        }
        DeRef(_26267);
        _26267 = NOVALUE;
    }
    DeRef(_26267);
    _26267 = NOVALUE;

    /** 		return name*/
    DeRef(_scan_result_50202);
    return _name_50201;
L1: 

    /** 	for i = 1 to length(SLASH_CHARS) do*/
    if (IS_SEQUENCE(_40SLASH_CHARS_16402)){
            _26268 = SEQ_PTR(_40SLASH_CHARS_16402)->length;
    }
    else {
        _26268 = 1;
    }
    {
        int _i_50207;
        _i_50207 = 1;
L2: 
        if (_i_50207 > _26268){
            goto L3; // [26] 63
        }

        /** 		if find(SLASH_CHARS[i], name) then*/
        _2 = (int)SEQ_PTR(_40SLASH_CHARS_16402);
        _26269 = (int)*(((s1_ptr)_2)->base + _i_50207);
        _26270 = find_from(_26269, _name_50201, 1);
        _26269 = NOVALUE;
        if (_26270 == 0)
        {
            _26270 = NOVALUE;
            goto L4; // [46] 56
        }
        else{
            _26270 = NOVALUE;
        }

        /** 			return -1*/
        DeRefDS(_name_50201);
        DeRef(_scan_result_50202);
        return -1;
L4: 

        /** 	end for*/
        _i_50207 = _i_50207 + 1;
        goto L2; // [58] 33
L3: 
        ;
    }

    /** 	scan_result = ScanPath(name, "PATH", 0)*/
    RefDS(_name_50201);
    RefDS(_26271);
    _0 = _scan_result_50202;
    _scan_result_50202 = _42ScanPath(_name_50201, _26271, 0);
    DeRef(_0);

    /** 	if sequence(scan_result) then*/
    _26273 = IS_SEQUENCE(_scan_result_50202);
    if (_26273 == 0)
    {
        _26273 = NOVALUE;
        goto L5; // [76] 98
    }
    else{
        _26273 = NOVALUE;
    }

    /** 		close(scan_result[2])*/
    _2 = (int)SEQ_PTR(_scan_result_50202);
    _26274 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_26274))
    EClose(_26274);
    else
    EClose((int)DBL_PTR(_26274)->dbl);
    _26274 = NOVALUE;

    /** 		return scan_result[1]*/
    _2 = (int)SEQ_PTR(_scan_result_50202);
    _26275 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_26275);
    DeRefDS(_name_50201);
    DeRef(_scan_result_50202);
    return _26275;
L5: 

    /** 	return -1*/
    DeRefDS(_name_50201);
    DeRef(_scan_result_50202);
    _26275 = NOVALUE;
    return -1;
    ;
}



// 0xD1931EC7
