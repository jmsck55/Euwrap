// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int _23reverse(int _target_4470, int _pFrom_4471, int _pTo_4472)
{
    int _uppr_4473 = NOVALUE;
    int _n_4474 = NOVALUE;
    int _lLimit_4475 = NOVALUE;
    int _t_4476 = NOVALUE;
    int _2237 = NOVALUE;
    int _2236 = NOVALUE;
    int _2235 = NOVALUE;
    int _2233 = NOVALUE;
    int _2232 = NOVALUE;
    int _2230 = NOVALUE;
    int _2228 = NOVALUE;
    int _0, _1, _2;
    

    /** 	n = length(target)*/
    if (IS_SEQUENCE(_target_4470)){
            _n_4474 = SEQ_PTR(_target_4470)->length;
    }
    else {
        _n_4474 = 1;
    }

    /** 	if n < 2 then*/
    if (_n_4474 >= 2)
    goto L1; // [12] 23

    /** 		return target*/
    DeRef(_t_4476);
    return _target_4470;
L1: 

    /** 	if pFrom < 1 then*/
    if (_pFrom_4471 >= 1)
    goto L2; // [25] 35

    /** 		pFrom = 1*/
    _pFrom_4471 = 1;
L2: 

    /** 	if pTo < 1 then*/
    if (_pTo_4472 >= 1)
    goto L3; // [37] 48

    /** 		pTo = n + pTo*/
    _pTo_4472 = _n_4474 + _pTo_4472;
L3: 

    /** 	if pTo < pFrom or pFrom >= n then*/
    _2228 = (_pTo_4472 < _pFrom_4471);
    if (_2228 != 0) {
        goto L4; // [54] 67
    }
    _2230 = (_pFrom_4471 >= _n_4474);
    if (_2230 == 0)
    {
        DeRef(_2230);
        _2230 = NOVALUE;
        goto L5; // [63] 74
    }
    else{
        DeRef(_2230);
        _2230 = NOVALUE;
    }
L4: 

    /** 		return target*/
    DeRef(_t_4476);
    DeRef(_2228);
    _2228 = NOVALUE;
    return _target_4470;
L5: 

    /** 	if pTo > n then*/
    if (_pTo_4472 <= _n_4474)
    goto L6; // [76] 86

    /** 		pTo = n*/
    _pTo_4472 = _n_4474;
L6: 

    /** 	lLimit = floor((pFrom+pTo-1)/2)*/
    _2232 = _pFrom_4471 + _pTo_4472;
    if ((long)((unsigned long)_2232 + (unsigned long)HIGH_BITS) >= 0) 
    _2232 = NewDouble((double)_2232);
    if (IS_ATOM_INT(_2232)) {
        _2233 = _2232 - 1;
        if ((long)((unsigned long)_2233 +(unsigned long) HIGH_BITS) >= 0){
            _2233 = NewDouble((double)_2233);
        }
    }
    else {
        _2233 = NewDouble(DBL_PTR(_2232)->dbl - (double)1);
    }
    DeRef(_2232);
    _2232 = NOVALUE;
    if (IS_ATOM_INT(_2233)) {
        _lLimit_4475 = _2233 >> 1;
    }
    else {
        _1 = binary_op(DIVIDE, _2233, 2);
        _lLimit_4475 = unary_op(FLOOR, _1);
        DeRef(_1);
    }
    DeRef(_2233);
    _2233 = NOVALUE;
    if (!IS_ATOM_INT(_lLimit_4475)) {
        _1 = (long)(DBL_PTR(_lLimit_4475)->dbl);
        DeRefDS(_lLimit_4475);
        _lLimit_4475 = _1;
    }

    /** 	t = target*/
    Ref(_target_4470);
    DeRef(_t_4476);
    _t_4476 = _target_4470;

    /** 	uppr = pTo*/
    _uppr_4473 = _pTo_4472;

    /** 	for lowr = pFrom to lLimit do*/
    _2235 = _lLimit_4475;
    {
        int _lowr_4495;
        _lowr_4495 = _pFrom_4471;
L7: 
        if (_lowr_4495 > _2235){
            goto L8; // [119] 159
        }

        /** 		t[uppr] = target[lowr]*/
        _2 = (int)SEQ_PTR(_target_4470);
        _2236 = (int)*(((s1_ptr)_2)->base + _lowr_4495);
        Ref(_2236);
        _2 = (int)SEQ_PTR(_t_4476);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _t_4476 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _uppr_4473);
        _1 = *(int *)_2;
        *(int *)_2 = _2236;
        if( _1 != _2236 ){
            DeRef(_1);
        }
        _2236 = NOVALUE;

        /** 		t[lowr] = target[uppr]*/
        _2 = (int)SEQ_PTR(_target_4470);
        _2237 = (int)*(((s1_ptr)_2)->base + _uppr_4473);
        Ref(_2237);
        _2 = (int)SEQ_PTR(_t_4476);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _t_4476 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _lowr_4495);
        _1 = *(int *)_2;
        *(int *)_2 = _2237;
        if( _1 != _2237 ){
            DeRef(_1);
        }
        _2237 = NOVALUE;

        /** 		uppr -= 1*/
        _uppr_4473 = _uppr_4473 - 1;

        /** 	end for*/
        _lowr_4495 = _lowr_4495 + 1;
        goto L7; // [154] 126
L8: 
        ;
    }

    /** 	return t*/
    DeRef(_target_4470);
    DeRef(_2228);
    _2228 = NOVALUE;
    return _t_4476;
    ;
}


int _23pad_tail(int _target_4571, int _size_4572, int _ch_4573)
{
    int _2274 = NOVALUE;
    int _2273 = NOVALUE;
    int _2272 = NOVALUE;
    int _2271 = NOVALUE;
    int _2269 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if size <= length(target) then*/
    if (IS_SEQUENCE(_target_4571)){
            _2269 = SEQ_PTR(_target_4571)->length;
    }
    else {
        _2269 = 1;
    }
    if (_size_4572 > _2269)
    goto L1; // [8] 19

    /** 		return target*/
    return _target_4571;
L1: 

    /** 	return target & repeat(ch, size - length(target))*/
    if (IS_SEQUENCE(_target_4571)){
            _2271 = SEQ_PTR(_target_4571)->length;
    }
    else {
        _2271 = 1;
    }
    _2272 = _size_4572 - _2271;
    _2271 = NOVALUE;
    _2273 = Repeat(_ch_4573, _2272);
    _2272 = NOVALUE;
    if (IS_SEQUENCE(_target_4571) && IS_ATOM(_2273)) {
    }
    else if (IS_ATOM(_target_4571) && IS_SEQUENCE(_2273)) {
        Ref(_target_4571);
        Prepend(&_2274, _2273, _target_4571);
    }
    else {
        Concat((object_ptr)&_2274, _target_4571, _2273);
    }
    DeRefDS(_2273);
    _2273 = NOVALUE;
    DeRef(_target_4571);
    return _2274;
    ;
}


int _23filter(int _source_4825, int _rid_4826, int _userdata_4827, int _rangetype_4828)
{
    int _dest_4829 = NOVALUE;
    int _idx_4830 = NOVALUE;
    int _2588 = NOVALUE;
    int _2587 = NOVALUE;
    int _2585 = NOVALUE;
    int _2584 = NOVALUE;
    int _2583 = NOVALUE;
    int _2582 = NOVALUE;
    int _2581 = NOVALUE;
    int _2578 = NOVALUE;
    int _2577 = NOVALUE;
    int _2576 = NOVALUE;
    int _2575 = NOVALUE;
    int _2572 = NOVALUE;
    int _2571 = NOVALUE;
    int _2570 = NOVALUE;
    int _2569 = NOVALUE;
    int _2568 = NOVALUE;
    int _2565 = NOVALUE;
    int _2564 = NOVALUE;
    int _2563 = NOVALUE;
    int _2562 = NOVALUE;
    int _2559 = NOVALUE;
    int _2558 = NOVALUE;
    int _2557 = NOVALUE;
    int _2556 = NOVALUE;
    int _2555 = NOVALUE;
    int _2552 = NOVALUE;
    int _2551 = NOVALUE;
    int _2550 = NOVALUE;
    int _2549 = NOVALUE;
    int _2546 = NOVALUE;
    int _2545 = NOVALUE;
    int _2544 = NOVALUE;
    int _2543 = NOVALUE;
    int _2542 = NOVALUE;
    int _2539 = NOVALUE;
    int _2538 = NOVALUE;
    int _2537 = NOVALUE;
    int _2536 = NOVALUE;
    int _2533 = NOVALUE;
    int _2532 = NOVALUE;
    int _2531 = NOVALUE;
    int _2530 = NOVALUE;
    int _2529 = NOVALUE;
    int _2526 = NOVALUE;
    int _2525 = NOVALUE;
    int _2524 = NOVALUE;
    int _2520 = NOVALUE;
    int _2517 = NOVALUE;
    int _2516 = NOVALUE;
    int _2515 = NOVALUE;
    int _2513 = NOVALUE;
    int _2512 = NOVALUE;
    int _2511 = NOVALUE;
    int _2510 = NOVALUE;
    int _2509 = NOVALUE;
    int _2506 = NOVALUE;
    int _2505 = NOVALUE;
    int _2504 = NOVALUE;
    int _2502 = NOVALUE;
    int _2501 = NOVALUE;
    int _2500 = NOVALUE;
    int _2499 = NOVALUE;
    int _2498 = NOVALUE;
    int _2495 = NOVALUE;
    int _2494 = NOVALUE;
    int _2493 = NOVALUE;
    int _2491 = NOVALUE;
    int _2490 = NOVALUE;
    int _2489 = NOVALUE;
    int _2488 = NOVALUE;
    int _2487 = NOVALUE;
    int _2484 = NOVALUE;
    int _2483 = NOVALUE;
    int _2482 = NOVALUE;
    int _2480 = NOVALUE;
    int _2479 = NOVALUE;
    int _2478 = NOVALUE;
    int _2477 = NOVALUE;
    int _2476 = NOVALUE;
    int _2474 = NOVALUE;
    int _2473 = NOVALUE;
    int _2472 = NOVALUE;
    int _2468 = NOVALUE;
    int _2465 = NOVALUE;
    int _2464 = NOVALUE;
    int _2463 = NOVALUE;
    int _2460 = NOVALUE;
    int _2457 = NOVALUE;
    int _2456 = NOVALUE;
    int _2455 = NOVALUE;
    int _2452 = NOVALUE;
    int _2449 = NOVALUE;
    int _2448 = NOVALUE;
    int _2447 = NOVALUE;
    int _2444 = NOVALUE;
    int _2441 = NOVALUE;
    int _2440 = NOVALUE;
    int _2439 = NOVALUE;
    int _2435 = NOVALUE;
    int _2432 = NOVALUE;
    int _2431 = NOVALUE;
    int _2430 = NOVALUE;
    int _2427 = NOVALUE;
    int _2424 = NOVALUE;
    int _2423 = NOVALUE;
    int _2422 = NOVALUE;
    int _2416 = NOVALUE;
    int _2414 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if length(source) = 0 then*/
    if (IS_SEQUENCE(_source_4825)){
            _2414 = SEQ_PTR(_source_4825)->length;
    }
    else {
        _2414 = 1;
    }
    if (_2414 != 0)
    goto L1; // [8] 19

    /** 		return source*/
    DeRefDS(_userdata_4827);
    DeRefDS(_rangetype_4828);
    DeRef(_dest_4829);
    return _source_4825;
L1: 

    /** 	dest = repeat(0, length(source))*/
    if (IS_SEQUENCE(_source_4825)){
            _2416 = SEQ_PTR(_source_4825)->length;
    }
    else {
        _2416 = 1;
    }
    DeRef(_dest_4829);
    _dest_4829 = Repeat(0, _2416);
    _2416 = NOVALUE;

    /** 	idx = 0*/
    _idx_4830 = 0;

    /** 	switch rid do*/
    _1 = find(_rid_4826, _2418);
    switch ( _1 ){ 

        /** 		case "<", "lt" then*/
        case 1:
        case 2:

        /** 			for a = 1 to length(source) do*/
        if (IS_SEQUENCE(_source_4825)){
                _2422 = SEQ_PTR(_source_4825)->length;
        }
        else {
            _2422 = 1;
        }
        {
            int _a_4842;
            _a_4842 = 1;
L2: 
            if (_a_4842 > _2422){
                goto L3; // [51] 96
            }

            /** 				if compare(source[a], userdata) < 0 then*/
            _2 = (int)SEQ_PTR(_source_4825);
            _2423 = (int)*(((s1_ptr)_2)->base + _a_4842);
            if (IS_ATOM_INT(_2423) && IS_ATOM_INT(_userdata_4827)){
                _2424 = (_2423 < _userdata_4827) ? -1 : (_2423 > _userdata_4827);
            }
            else{
                _2424 = compare(_2423, _userdata_4827);
            }
            _2423 = NOVALUE;
            if (_2424 >= 0)
            goto L4; // [68] 89

            /** 					idx += 1*/
            _idx_4830 = _idx_4830 + 1;

            /** 					dest[idx] = source[a]*/
            _2 = (int)SEQ_PTR(_source_4825);
            _2427 = (int)*(((s1_ptr)_2)->base + _a_4842);
            Ref(_2427);
            _2 = (int)SEQ_PTR(_dest_4829);
            _2 = (int)(((s1_ptr)_2)->base + _idx_4830);
            _1 = *(int *)_2;
            *(int *)_2 = _2427;
            if( _1 != _2427 ){
                DeRef(_1);
            }
            _2427 = NOVALUE;
L4: 

            /** 			end for*/
            _a_4842 = _a_4842 + 1;
            goto L2; // [91] 58
L3: 
            ;
        }
        goto L5; // [96] 1304

        /** 		case "<=", "le" then*/
        case 3:
        case 4:

        /** 			for a = 1 to length(source) do*/
        if (IS_SEQUENCE(_source_4825)){
                _2430 = SEQ_PTR(_source_4825)->length;
        }
        else {
            _2430 = 1;
        }
        {
            int _a_4854;
            _a_4854 = 1;
L6: 
            if (_a_4854 > _2430){
                goto L7; // [109] 154
            }

            /** 				if compare(source[a], userdata) <= 0 then*/
            _2 = (int)SEQ_PTR(_source_4825);
            _2431 = (int)*(((s1_ptr)_2)->base + _a_4854);
            if (IS_ATOM_INT(_2431) && IS_ATOM_INT(_userdata_4827)){
                _2432 = (_2431 < _userdata_4827) ? -1 : (_2431 > _userdata_4827);
            }
            else{
                _2432 = compare(_2431, _userdata_4827);
            }
            _2431 = NOVALUE;
            if (_2432 > 0)
            goto L8; // [126] 147

            /** 					idx += 1*/
            _idx_4830 = _idx_4830 + 1;

            /** 					dest[idx] = source[a]*/
            _2 = (int)SEQ_PTR(_source_4825);
            _2435 = (int)*(((s1_ptr)_2)->base + _a_4854);
            Ref(_2435);
            _2 = (int)SEQ_PTR(_dest_4829);
            _2 = (int)(((s1_ptr)_2)->base + _idx_4830);
            _1 = *(int *)_2;
            *(int *)_2 = _2435;
            if( _1 != _2435 ){
                DeRef(_1);
            }
            _2435 = NOVALUE;
L8: 

            /** 			end for*/
            _a_4854 = _a_4854 + 1;
            goto L6; // [149] 116
L7: 
            ;
        }
        goto L5; // [154] 1304

        /** 		case "=", "==", "eq" then*/
        case 5:
        case 6:
        case 7:

        /** 			for a = 1 to length(source) do*/
        if (IS_SEQUENCE(_source_4825)){
                _2439 = SEQ_PTR(_source_4825)->length;
        }
        else {
            _2439 = 1;
        }
        {
            int _a_4867;
            _a_4867 = 1;
L9: 
            if (_a_4867 > _2439){
                goto LA; // [169] 214
            }

            /** 				if compare(source[a], userdata) = 0 then*/
            _2 = (int)SEQ_PTR(_source_4825);
            _2440 = (int)*(((s1_ptr)_2)->base + _a_4867);
            if (IS_ATOM_INT(_2440) && IS_ATOM_INT(_userdata_4827)){
                _2441 = (_2440 < _userdata_4827) ? -1 : (_2440 > _userdata_4827);
            }
            else{
                _2441 = compare(_2440, _userdata_4827);
            }
            _2440 = NOVALUE;
            if (_2441 != 0)
            goto LB; // [186] 207

            /** 					idx += 1*/
            _idx_4830 = _idx_4830 + 1;

            /** 					dest[idx] = source[a]*/
            _2 = (int)SEQ_PTR(_source_4825);
            _2444 = (int)*(((s1_ptr)_2)->base + _a_4867);
            Ref(_2444);
            _2 = (int)SEQ_PTR(_dest_4829);
            _2 = (int)(((s1_ptr)_2)->base + _idx_4830);
            _1 = *(int *)_2;
            *(int *)_2 = _2444;
            if( _1 != _2444 ){
                DeRef(_1);
            }
            _2444 = NOVALUE;
LB: 

            /** 			end for*/
            _a_4867 = _a_4867 + 1;
            goto L9; // [209] 176
LA: 
            ;
        }
        goto L5; // [214] 1304

        /** 		case "!=", "ne" then*/
        case 8:
        case 9:

        /** 			for a = 1 to length(source) do*/
        if (IS_SEQUENCE(_source_4825)){
                _2447 = SEQ_PTR(_source_4825)->length;
        }
        else {
            _2447 = 1;
        }
        {
            int _a_4879;
            _a_4879 = 1;
LC: 
            if (_a_4879 > _2447){
                goto LD; // [227] 272
            }

            /** 				if compare(source[a], userdata) != 0 then*/
            _2 = (int)SEQ_PTR(_source_4825);
            _2448 = (int)*(((s1_ptr)_2)->base + _a_4879);
            if (IS_ATOM_INT(_2448) && IS_ATOM_INT(_userdata_4827)){
                _2449 = (_2448 < _userdata_4827) ? -1 : (_2448 > _userdata_4827);
            }
            else{
                _2449 = compare(_2448, _userdata_4827);
            }
            _2448 = NOVALUE;
            if (_2449 == 0)
            goto LE; // [244] 265

            /** 					idx += 1*/
            _idx_4830 = _idx_4830 + 1;

            /** 					dest[idx] = source[a]*/
            _2 = (int)SEQ_PTR(_source_4825);
            _2452 = (int)*(((s1_ptr)_2)->base + _a_4879);
            Ref(_2452);
            _2 = (int)SEQ_PTR(_dest_4829);
            _2 = (int)(((s1_ptr)_2)->base + _idx_4830);
            _1 = *(int *)_2;
            *(int *)_2 = _2452;
            if( _1 != _2452 ){
                DeRef(_1);
            }
            _2452 = NOVALUE;
LE: 

            /** 			end for*/
            _a_4879 = _a_4879 + 1;
            goto LC; // [267] 234
LD: 
            ;
        }
        goto L5; // [272] 1304

        /** 		case ">", "gt" then*/
        case 10:
        case 11:

        /** 			for a = 1 to length(source) do*/
        if (IS_SEQUENCE(_source_4825)){
                _2455 = SEQ_PTR(_source_4825)->length;
        }
        else {
            _2455 = 1;
        }
        {
            int _a_4891;
            _a_4891 = 1;
LF: 
            if (_a_4891 > _2455){
                goto L10; // [285] 330
            }

            /** 				if compare(source[a], userdata) > 0 then*/
            _2 = (int)SEQ_PTR(_source_4825);
            _2456 = (int)*(((s1_ptr)_2)->base + _a_4891);
            if (IS_ATOM_INT(_2456) && IS_ATOM_INT(_userdata_4827)){
                _2457 = (_2456 < _userdata_4827) ? -1 : (_2456 > _userdata_4827);
            }
            else{
                _2457 = compare(_2456, _userdata_4827);
            }
            _2456 = NOVALUE;
            if (_2457 <= 0)
            goto L11; // [302] 323

            /** 					idx += 1*/
            _idx_4830 = _idx_4830 + 1;

            /** 					dest[idx] = source[a]*/
            _2 = (int)SEQ_PTR(_source_4825);
            _2460 = (int)*(((s1_ptr)_2)->base + _a_4891);
            Ref(_2460);
            _2 = (int)SEQ_PTR(_dest_4829);
            _2 = (int)(((s1_ptr)_2)->base + _idx_4830);
            _1 = *(int *)_2;
            *(int *)_2 = _2460;
            if( _1 != _2460 ){
                DeRef(_1);
            }
            _2460 = NOVALUE;
L11: 

            /** 			end for*/
            _a_4891 = _a_4891 + 1;
            goto LF; // [325] 292
L10: 
            ;
        }
        goto L5; // [330] 1304

        /** 		case ">=", "ge" then*/
        case 12:
        case 13:

        /** 			for a = 1 to length(source) do*/
        if (IS_SEQUENCE(_source_4825)){
                _2463 = SEQ_PTR(_source_4825)->length;
        }
        else {
            _2463 = 1;
        }
        {
            int _a_4903;
            _a_4903 = 1;
L12: 
            if (_a_4903 > _2463){
                goto L13; // [343] 388
            }

            /** 				if compare(source[a], userdata) >= 0 then*/
            _2 = (int)SEQ_PTR(_source_4825);
            _2464 = (int)*(((s1_ptr)_2)->base + _a_4903);
            if (IS_ATOM_INT(_2464) && IS_ATOM_INT(_userdata_4827)){
                _2465 = (_2464 < _userdata_4827) ? -1 : (_2464 > _userdata_4827);
            }
            else{
                _2465 = compare(_2464, _userdata_4827);
            }
            _2464 = NOVALUE;
            if (_2465 < 0)
            goto L14; // [360] 381

            /** 					idx += 1*/
            _idx_4830 = _idx_4830 + 1;

            /** 					dest[idx] = source[a]*/
            _2 = (int)SEQ_PTR(_source_4825);
            _2468 = (int)*(((s1_ptr)_2)->base + _a_4903);
            Ref(_2468);
            _2 = (int)SEQ_PTR(_dest_4829);
            _2 = (int)(((s1_ptr)_2)->base + _idx_4830);
            _1 = *(int *)_2;
            *(int *)_2 = _2468;
            if( _1 != _2468 ){
                DeRef(_1);
            }
            _2468 = NOVALUE;
L14: 

            /** 			end for*/
            _a_4903 = _a_4903 + 1;
            goto L12; // [383] 350
L13: 
            ;
        }
        goto L5; // [388] 1304

        /** 		case "in" then*/
        case 14:

        /** 			switch rangetype do*/
        _1 = find(_rangetype_4828, _2470);
        switch ( _1 ){ 

            /** 				case "" then*/
            case 1:

            /** 					for a = 1 to length(source) do*/
            if (IS_SEQUENCE(_source_4825)){
                    _2472 = SEQ_PTR(_source_4825)->length;
            }
            else {
                _2472 = 1;
            }
            {
                int _a_4917;
                _a_4917 = 1;
L15: 
                if (_a_4917 > _2472){
                    goto L16; // [410] 455
                }

                /** 						if find(source[a], userdata)  then*/
                _2 = (int)SEQ_PTR(_source_4825);
                _2473 = (int)*(((s1_ptr)_2)->base + _a_4917);
                _2474 = find_from(_2473, _userdata_4827, 1);
                _2473 = NOVALUE;
                if (_2474 == 0)
                {
                    _2474 = NOVALUE;
                    goto L17; // [428] 448
                }
                else{
                    _2474 = NOVALUE;
                }

                /** 							idx += 1*/
                _idx_4830 = _idx_4830 + 1;

                /** 							dest[idx] = source[a]*/
                _2 = (int)SEQ_PTR(_source_4825);
                _2476 = (int)*(((s1_ptr)_2)->base + _a_4917);
                Ref(_2476);
                _2 = (int)SEQ_PTR(_dest_4829);
                _2 = (int)(((s1_ptr)_2)->base + _idx_4830);
                _1 = *(int *)_2;
                *(int *)_2 = _2476;
                if( _1 != _2476 ){
                    DeRef(_1);
                }
                _2476 = NOVALUE;
L17: 

                /** 					end for*/
                _a_4917 = _a_4917 + 1;
                goto L15; // [450] 417
L16: 
                ;
            }
            goto L5; // [455] 1304

            /** 				case "[]" then*/
            case 2:

            /** 					for a = 1 to length(source) do*/
            if (IS_SEQUENCE(_source_4825)){
                    _2477 = SEQ_PTR(_source_4825)->length;
            }
            else {
                _2477 = 1;
            }
            {
                int _a_4926;
                _a_4926 = 1;
L18: 
                if (_a_4926 > _2477){
                    goto L19; // [466] 534
                }

                /** 						if compare(source[a], userdata[1]) >= 0 then*/
                _2 = (int)SEQ_PTR(_source_4825);
                _2478 = (int)*(((s1_ptr)_2)->base + _a_4926);
                _2 = (int)SEQ_PTR(_userdata_4827);
                _2479 = (int)*(((s1_ptr)_2)->base + 1);
                if (IS_ATOM_INT(_2478) && IS_ATOM_INT(_2479)){
                    _2480 = (_2478 < _2479) ? -1 : (_2478 > _2479);
                }
                else{
                    _2480 = compare(_2478, _2479);
                }
                _2478 = NOVALUE;
                _2479 = NOVALUE;
                if (_2480 < 0)
                goto L1A; // [487] 527

                /** 							if compare(source[a], userdata[2]) <= 0 then*/
                _2 = (int)SEQ_PTR(_source_4825);
                _2482 = (int)*(((s1_ptr)_2)->base + _a_4926);
                _2 = (int)SEQ_PTR(_userdata_4827);
                _2483 = (int)*(((s1_ptr)_2)->base + 2);
                if (IS_ATOM_INT(_2482) && IS_ATOM_INT(_2483)){
                    _2484 = (_2482 < _2483) ? -1 : (_2482 > _2483);
                }
                else{
                    _2484 = compare(_2482, _2483);
                }
                _2482 = NOVALUE;
                _2483 = NOVALUE;
                if (_2484 > 0)
                goto L1B; // [505] 526

                /** 								idx += 1*/
                _idx_4830 = _idx_4830 + 1;

                /** 								dest[idx] = source[a]*/
                _2 = (int)SEQ_PTR(_source_4825);
                _2487 = (int)*(((s1_ptr)_2)->base + _a_4926);
                Ref(_2487);
                _2 = (int)SEQ_PTR(_dest_4829);
                _2 = (int)(((s1_ptr)_2)->base + _idx_4830);
                _1 = *(int *)_2;
                *(int *)_2 = _2487;
                if( _1 != _2487 ){
                    DeRef(_1);
                }
                _2487 = NOVALUE;
L1B: 
L1A: 

                /** 					end for*/
                _a_4926 = _a_4926 + 1;
                goto L18; // [529] 473
L19: 
                ;
            }
            goto L5; // [534] 1304

            /** 				case "[)" then*/
            case 3:

            /** 					for a = 1 to length(source) do*/
            if (IS_SEQUENCE(_source_4825)){
                    _2488 = SEQ_PTR(_source_4825)->length;
            }
            else {
                _2488 = 1;
            }
            {
                int _a_4942;
                _a_4942 = 1;
L1C: 
                if (_a_4942 > _2488){
                    goto L1D; // [545] 613
                }

                /** 						if compare(source[a], userdata[1]) >= 0 then*/
                _2 = (int)SEQ_PTR(_source_4825);
                _2489 = (int)*(((s1_ptr)_2)->base + _a_4942);
                _2 = (int)SEQ_PTR(_userdata_4827);
                _2490 = (int)*(((s1_ptr)_2)->base + 1);
                if (IS_ATOM_INT(_2489) && IS_ATOM_INT(_2490)){
                    _2491 = (_2489 < _2490) ? -1 : (_2489 > _2490);
                }
                else{
                    _2491 = compare(_2489, _2490);
                }
                _2489 = NOVALUE;
                _2490 = NOVALUE;
                if (_2491 < 0)
                goto L1E; // [566] 606

                /** 							if compare(source[a], userdata[2]) < 0 then*/
                _2 = (int)SEQ_PTR(_source_4825);
                _2493 = (int)*(((s1_ptr)_2)->base + _a_4942);
                _2 = (int)SEQ_PTR(_userdata_4827);
                _2494 = (int)*(((s1_ptr)_2)->base + 2);
                if (IS_ATOM_INT(_2493) && IS_ATOM_INT(_2494)){
                    _2495 = (_2493 < _2494) ? -1 : (_2493 > _2494);
                }
                else{
                    _2495 = compare(_2493, _2494);
                }
                _2493 = NOVALUE;
                _2494 = NOVALUE;
                if (_2495 >= 0)
                goto L1F; // [584] 605

                /** 								idx += 1*/
                _idx_4830 = _idx_4830 + 1;

                /** 								dest[idx] = source[a]*/
                _2 = (int)SEQ_PTR(_source_4825);
                _2498 = (int)*(((s1_ptr)_2)->base + _a_4942);
                Ref(_2498);
                _2 = (int)SEQ_PTR(_dest_4829);
                _2 = (int)(((s1_ptr)_2)->base + _idx_4830);
                _1 = *(int *)_2;
                *(int *)_2 = _2498;
                if( _1 != _2498 ){
                    DeRef(_1);
                }
                _2498 = NOVALUE;
L1F: 
L1E: 

                /** 					end for*/
                _a_4942 = _a_4942 + 1;
                goto L1C; // [608] 552
L1D: 
                ;
            }
            goto L5; // [613] 1304

            /** 				case "(]" then*/
            case 4:

            /** 					for a = 1 to length(source) do*/
            if (IS_SEQUENCE(_source_4825)){
                    _2499 = SEQ_PTR(_source_4825)->length;
            }
            else {
                _2499 = 1;
            }
            {
                int _a_4958;
                _a_4958 = 1;
L20: 
                if (_a_4958 > _2499){
                    goto L21; // [624] 692
                }

                /** 						if compare(source[a], userdata[1]) > 0 then*/
                _2 = (int)SEQ_PTR(_source_4825);
                _2500 = (int)*(((s1_ptr)_2)->base + _a_4958);
                _2 = (int)SEQ_PTR(_userdata_4827);
                _2501 = (int)*(((s1_ptr)_2)->base + 1);
                if (IS_ATOM_INT(_2500) && IS_ATOM_INT(_2501)){
                    _2502 = (_2500 < _2501) ? -1 : (_2500 > _2501);
                }
                else{
                    _2502 = compare(_2500, _2501);
                }
                _2500 = NOVALUE;
                _2501 = NOVALUE;
                if (_2502 <= 0)
                goto L22; // [645] 685

                /** 							if compare(source[a], userdata[2]) <= 0 then*/
                _2 = (int)SEQ_PTR(_source_4825);
                _2504 = (int)*(((s1_ptr)_2)->base + _a_4958);
                _2 = (int)SEQ_PTR(_userdata_4827);
                _2505 = (int)*(((s1_ptr)_2)->base + 2);
                if (IS_ATOM_INT(_2504) && IS_ATOM_INT(_2505)){
                    _2506 = (_2504 < _2505) ? -1 : (_2504 > _2505);
                }
                else{
                    _2506 = compare(_2504, _2505);
                }
                _2504 = NOVALUE;
                _2505 = NOVALUE;
                if (_2506 > 0)
                goto L23; // [663] 684

                /** 								idx += 1*/
                _idx_4830 = _idx_4830 + 1;

                /** 								dest[idx] = source[a]*/
                _2 = (int)SEQ_PTR(_source_4825);
                _2509 = (int)*(((s1_ptr)_2)->base + _a_4958);
                Ref(_2509);
                _2 = (int)SEQ_PTR(_dest_4829);
                _2 = (int)(((s1_ptr)_2)->base + _idx_4830);
                _1 = *(int *)_2;
                *(int *)_2 = _2509;
                if( _1 != _2509 ){
                    DeRef(_1);
                }
                _2509 = NOVALUE;
L23: 
L22: 

                /** 					end for*/
                _a_4958 = _a_4958 + 1;
                goto L20; // [687] 631
L21: 
                ;
            }
            goto L5; // [692] 1304

            /** 				case "()" then*/
            case 5:

            /** 					for a = 1 to length(source) do*/
            if (IS_SEQUENCE(_source_4825)){
                    _2510 = SEQ_PTR(_source_4825)->length;
            }
            else {
                _2510 = 1;
            }
            {
                int _a_4974;
                _a_4974 = 1;
L24: 
                if (_a_4974 > _2510){
                    goto L25; // [703] 771
                }

                /** 						if compare(source[a], userdata[1]) > 0 then*/
                _2 = (int)SEQ_PTR(_source_4825);
                _2511 = (int)*(((s1_ptr)_2)->base + _a_4974);
                _2 = (int)SEQ_PTR(_userdata_4827);
                _2512 = (int)*(((s1_ptr)_2)->base + 1);
                if (IS_ATOM_INT(_2511) && IS_ATOM_INT(_2512)){
                    _2513 = (_2511 < _2512) ? -1 : (_2511 > _2512);
                }
                else{
                    _2513 = compare(_2511, _2512);
                }
                _2511 = NOVALUE;
                _2512 = NOVALUE;
                if (_2513 <= 0)
                goto L26; // [724] 764

                /** 							if compare(source[a], userdata[2]) < 0 then*/
                _2 = (int)SEQ_PTR(_source_4825);
                _2515 = (int)*(((s1_ptr)_2)->base + _a_4974);
                _2 = (int)SEQ_PTR(_userdata_4827);
                _2516 = (int)*(((s1_ptr)_2)->base + 2);
                if (IS_ATOM_INT(_2515) && IS_ATOM_INT(_2516)){
                    _2517 = (_2515 < _2516) ? -1 : (_2515 > _2516);
                }
                else{
                    _2517 = compare(_2515, _2516);
                }
                _2515 = NOVALUE;
                _2516 = NOVALUE;
                if (_2517 >= 0)
                goto L27; // [742] 763

                /** 								idx += 1*/
                _idx_4830 = _idx_4830 + 1;

                /** 								dest[idx] = source[a]*/
                _2 = (int)SEQ_PTR(_source_4825);
                _2520 = (int)*(((s1_ptr)_2)->base + _a_4974);
                Ref(_2520);
                _2 = (int)SEQ_PTR(_dest_4829);
                _2 = (int)(((s1_ptr)_2)->base + _idx_4830);
                _1 = *(int *)_2;
                *(int *)_2 = _2520;
                if( _1 != _2520 ){
                    DeRef(_1);
                }
                _2520 = NOVALUE;
L27: 
L26: 

                /** 					end for*/
                _a_4974 = _a_4974 + 1;
                goto L24; // [766] 710
L25: 
                ;
            }
            goto L5; // [771] 1304

            /** 				case else*/
            case 0:
        ;}        goto L5; // [778] 1304

        /** 		case "out" then*/
        case 15:

        /** 			switch rangetype do*/
        _1 = find(_rangetype_4828, _2522);
        switch ( _1 ){ 

            /** 				case "" then*/
            case 1:

            /** 					for a = 1 to length(source) do*/
            if (IS_SEQUENCE(_source_4825)){
                    _2524 = SEQ_PTR(_source_4825)->length;
            }
            else {
                _2524 = 1;
            }
            {
                int _a_4995;
                _a_4995 = 1;
L28: 
                if (_a_4995 > _2524){
                    goto L29; // [800] 845
                }

                /** 						if not find(source[a], userdata)  then*/
                _2 = (int)SEQ_PTR(_source_4825);
                _2525 = (int)*(((s1_ptr)_2)->base + _a_4995);
                _2526 = find_from(_2525, _userdata_4827, 1);
                _2525 = NOVALUE;
                if (_2526 != 0)
                goto L2A; // [818] 838
                _2526 = NOVALUE;

                /** 							idx += 1*/
                _idx_4830 = _idx_4830 + 1;

                /** 							dest[idx] = source[a]*/
                _2 = (int)SEQ_PTR(_source_4825);
                _2529 = (int)*(((s1_ptr)_2)->base + _a_4995);
                Ref(_2529);
                _2 = (int)SEQ_PTR(_dest_4829);
                _2 = (int)(((s1_ptr)_2)->base + _idx_4830);
                _1 = *(int *)_2;
                *(int *)_2 = _2529;
                if( _1 != _2529 ){
                    DeRef(_1);
                }
                _2529 = NOVALUE;
L2A: 

                /** 					end for*/
                _a_4995 = _a_4995 + 1;
                goto L28; // [840] 807
L29: 
                ;
            }
            goto L5; // [845] 1304

            /** 				case "[]" then*/
            case 2:

            /** 					for a = 1 to length(source) do*/
            if (IS_SEQUENCE(_source_4825)){
                    _2530 = SEQ_PTR(_source_4825)->length;
            }
            else {
                _2530 = 1;
            }
            {
                int _a_5005;
                _a_5005 = 1;
L2B: 
                if (_a_5005 > _2530){
                    goto L2C; // [856] 943
                }

                /** 						if compare(source[a], userdata[1]) < 0 then*/
                _2 = (int)SEQ_PTR(_source_4825);
                _2531 = (int)*(((s1_ptr)_2)->base + _a_5005);
                _2 = (int)SEQ_PTR(_userdata_4827);
                _2532 = (int)*(((s1_ptr)_2)->base + 1);
                if (IS_ATOM_INT(_2531) && IS_ATOM_INT(_2532)){
                    _2533 = (_2531 < _2532) ? -1 : (_2531 > _2532);
                }
                else{
                    _2533 = compare(_2531, _2532);
                }
                _2531 = NOVALUE;
                _2532 = NOVALUE;
                if (_2533 >= 0)
                goto L2D; // [877] 900

                /** 							idx += 1*/
                _idx_4830 = _idx_4830 + 1;

                /** 							dest[idx] = source[a]*/
                _2 = (int)SEQ_PTR(_source_4825);
                _2536 = (int)*(((s1_ptr)_2)->base + _a_5005);
                Ref(_2536);
                _2 = (int)SEQ_PTR(_dest_4829);
                _2 = (int)(((s1_ptr)_2)->base + _idx_4830);
                _1 = *(int *)_2;
                *(int *)_2 = _2536;
                if( _1 != _2536 ){
                    DeRef(_1);
                }
                _2536 = NOVALUE;
                goto L2E; // [897] 936
L2D: 

                /** 						elsif compare(source[a], userdata[2]) > 0 then*/
                _2 = (int)SEQ_PTR(_source_4825);
                _2537 = (int)*(((s1_ptr)_2)->base + _a_5005);
                _2 = (int)SEQ_PTR(_userdata_4827);
                _2538 = (int)*(((s1_ptr)_2)->base + 2);
                if (IS_ATOM_INT(_2537) && IS_ATOM_INT(_2538)){
                    _2539 = (_2537 < _2538) ? -1 : (_2537 > _2538);
                }
                else{
                    _2539 = compare(_2537, _2538);
                }
                _2537 = NOVALUE;
                _2538 = NOVALUE;
                if (_2539 <= 0)
                goto L2F; // [914] 935

                /** 							idx += 1*/
                _idx_4830 = _idx_4830 + 1;

                /** 							dest[idx] = source[a]*/
                _2 = (int)SEQ_PTR(_source_4825);
                _2542 = (int)*(((s1_ptr)_2)->base + _a_5005);
                Ref(_2542);
                _2 = (int)SEQ_PTR(_dest_4829);
                _2 = (int)(((s1_ptr)_2)->base + _idx_4830);
                _1 = *(int *)_2;
                *(int *)_2 = _2542;
                if( _1 != _2542 ){
                    DeRef(_1);
                }
                _2542 = NOVALUE;
L2F: 
L2E: 

                /** 					end for*/
                _a_5005 = _a_5005 + 1;
                goto L2B; // [938] 863
L2C: 
                ;
            }
            goto L5; // [943] 1304

            /** 				case "[)" then*/
            case 3:

            /** 					for a = 1 to length(source) do*/
            if (IS_SEQUENCE(_source_4825)){
                    _2543 = SEQ_PTR(_source_4825)->length;
            }
            else {
                _2543 = 1;
            }
            {
                int _a_5023;
                _a_5023 = 1;
L30: 
                if (_a_5023 > _2543){
                    goto L31; // [954] 1041
                }

                /** 						if compare(source[a], userdata[1]) < 0 then*/
                _2 = (int)SEQ_PTR(_source_4825);
                _2544 = (int)*(((s1_ptr)_2)->base + _a_5023);
                _2 = (int)SEQ_PTR(_userdata_4827);
                _2545 = (int)*(((s1_ptr)_2)->base + 1);
                if (IS_ATOM_INT(_2544) && IS_ATOM_INT(_2545)){
                    _2546 = (_2544 < _2545) ? -1 : (_2544 > _2545);
                }
                else{
                    _2546 = compare(_2544, _2545);
                }
                _2544 = NOVALUE;
                _2545 = NOVALUE;
                if (_2546 >= 0)
                goto L32; // [975] 998

                /** 							idx += 1*/
                _idx_4830 = _idx_4830 + 1;

                /** 							dest[idx] = source[a]*/
                _2 = (int)SEQ_PTR(_source_4825);
                _2549 = (int)*(((s1_ptr)_2)->base + _a_5023);
                Ref(_2549);
                _2 = (int)SEQ_PTR(_dest_4829);
                _2 = (int)(((s1_ptr)_2)->base + _idx_4830);
                _1 = *(int *)_2;
                *(int *)_2 = _2549;
                if( _1 != _2549 ){
                    DeRef(_1);
                }
                _2549 = NOVALUE;
                goto L33; // [995] 1034
L32: 

                /** 						elsif compare(source[a], userdata[2]) >= 0 then*/
                _2 = (int)SEQ_PTR(_source_4825);
                _2550 = (int)*(((s1_ptr)_2)->base + _a_5023);
                _2 = (int)SEQ_PTR(_userdata_4827);
                _2551 = (int)*(((s1_ptr)_2)->base + 2);
                if (IS_ATOM_INT(_2550) && IS_ATOM_INT(_2551)){
                    _2552 = (_2550 < _2551) ? -1 : (_2550 > _2551);
                }
                else{
                    _2552 = compare(_2550, _2551);
                }
                _2550 = NOVALUE;
                _2551 = NOVALUE;
                if (_2552 < 0)
                goto L34; // [1012] 1033

                /** 							idx += 1*/
                _idx_4830 = _idx_4830 + 1;

                /** 							dest[idx] = source[a]*/
                _2 = (int)SEQ_PTR(_source_4825);
                _2555 = (int)*(((s1_ptr)_2)->base + _a_5023);
                Ref(_2555);
                _2 = (int)SEQ_PTR(_dest_4829);
                _2 = (int)(((s1_ptr)_2)->base + _idx_4830);
                _1 = *(int *)_2;
                *(int *)_2 = _2555;
                if( _1 != _2555 ){
                    DeRef(_1);
                }
                _2555 = NOVALUE;
L34: 
L33: 

                /** 					end for*/
                _a_5023 = _a_5023 + 1;
                goto L30; // [1036] 961
L31: 
                ;
            }
            goto L5; // [1041] 1304

            /** 				case "(]" then*/
            case 4:

            /** 					for a = 1 to length(source) do*/
            if (IS_SEQUENCE(_source_4825)){
                    _2556 = SEQ_PTR(_source_4825)->length;
            }
            else {
                _2556 = 1;
            }
            {
                int _a_5041;
                _a_5041 = 1;
L35: 
                if (_a_5041 > _2556){
                    goto L36; // [1052] 1139
                }

                /** 						if compare(source[a], userdata[1]) <= 0 then*/
                _2 = (int)SEQ_PTR(_source_4825);
                _2557 = (int)*(((s1_ptr)_2)->base + _a_5041);
                _2 = (int)SEQ_PTR(_userdata_4827);
                _2558 = (int)*(((s1_ptr)_2)->base + 1);
                if (IS_ATOM_INT(_2557) && IS_ATOM_INT(_2558)){
                    _2559 = (_2557 < _2558) ? -1 : (_2557 > _2558);
                }
                else{
                    _2559 = compare(_2557, _2558);
                }
                _2557 = NOVALUE;
                _2558 = NOVALUE;
                if (_2559 > 0)
                goto L37; // [1073] 1096

                /** 							idx += 1*/
                _idx_4830 = _idx_4830 + 1;

                /** 							dest[idx] = source[a]*/
                _2 = (int)SEQ_PTR(_source_4825);
                _2562 = (int)*(((s1_ptr)_2)->base + _a_5041);
                Ref(_2562);
                _2 = (int)SEQ_PTR(_dest_4829);
                _2 = (int)(((s1_ptr)_2)->base + _idx_4830);
                _1 = *(int *)_2;
                *(int *)_2 = _2562;
                if( _1 != _2562 ){
                    DeRef(_1);
                }
                _2562 = NOVALUE;
                goto L38; // [1093] 1132
L37: 

                /** 						elsif compare(source[a], userdata[2]) > 0 then*/
                _2 = (int)SEQ_PTR(_source_4825);
                _2563 = (int)*(((s1_ptr)_2)->base + _a_5041);
                _2 = (int)SEQ_PTR(_userdata_4827);
                _2564 = (int)*(((s1_ptr)_2)->base + 2);
                if (IS_ATOM_INT(_2563) && IS_ATOM_INT(_2564)){
                    _2565 = (_2563 < _2564) ? -1 : (_2563 > _2564);
                }
                else{
                    _2565 = compare(_2563, _2564);
                }
                _2563 = NOVALUE;
                _2564 = NOVALUE;
                if (_2565 <= 0)
                goto L39; // [1110] 1131

                /** 							idx += 1*/
                _idx_4830 = _idx_4830 + 1;

                /** 							dest[idx] = source[a]*/
                _2 = (int)SEQ_PTR(_source_4825);
                _2568 = (int)*(((s1_ptr)_2)->base + _a_5041);
                Ref(_2568);
                _2 = (int)SEQ_PTR(_dest_4829);
                _2 = (int)(((s1_ptr)_2)->base + _idx_4830);
                _1 = *(int *)_2;
                *(int *)_2 = _2568;
                if( _1 != _2568 ){
                    DeRef(_1);
                }
                _2568 = NOVALUE;
L39: 
L38: 

                /** 					end for*/
                _a_5041 = _a_5041 + 1;
                goto L35; // [1134] 1059
L36: 
                ;
            }
            goto L5; // [1139] 1304

            /** 				case "()" then*/
            case 5:

            /** 					for a = 1 to length(source) do*/
            if (IS_SEQUENCE(_source_4825)){
                    _2569 = SEQ_PTR(_source_4825)->length;
            }
            else {
                _2569 = 1;
            }
            {
                int _a_5059;
                _a_5059 = 1;
L3A: 
                if (_a_5059 > _2569){
                    goto L3B; // [1150] 1237
                }

                /** 						if compare(source[a], userdata[1]) <= 0 then*/
                _2 = (int)SEQ_PTR(_source_4825);
                _2570 = (int)*(((s1_ptr)_2)->base + _a_5059);
                _2 = (int)SEQ_PTR(_userdata_4827);
                _2571 = (int)*(((s1_ptr)_2)->base + 1);
                if (IS_ATOM_INT(_2570) && IS_ATOM_INT(_2571)){
                    _2572 = (_2570 < _2571) ? -1 : (_2570 > _2571);
                }
                else{
                    _2572 = compare(_2570, _2571);
                }
                _2570 = NOVALUE;
                _2571 = NOVALUE;
                if (_2572 > 0)
                goto L3C; // [1171] 1194

                /** 							idx += 1*/
                _idx_4830 = _idx_4830 + 1;

                /** 							dest[idx] = source[a]*/
                _2 = (int)SEQ_PTR(_source_4825);
                _2575 = (int)*(((s1_ptr)_2)->base + _a_5059);
                Ref(_2575);
                _2 = (int)SEQ_PTR(_dest_4829);
                _2 = (int)(((s1_ptr)_2)->base + _idx_4830);
                _1 = *(int *)_2;
                *(int *)_2 = _2575;
                if( _1 != _2575 ){
                    DeRef(_1);
                }
                _2575 = NOVALUE;
                goto L3D; // [1191] 1230
L3C: 

                /** 						elsif compare(source[a], userdata[2]) >= 0 then*/
                _2 = (int)SEQ_PTR(_source_4825);
                _2576 = (int)*(((s1_ptr)_2)->base + _a_5059);
                _2 = (int)SEQ_PTR(_userdata_4827);
                _2577 = (int)*(((s1_ptr)_2)->base + 2);
                if (IS_ATOM_INT(_2576) && IS_ATOM_INT(_2577)){
                    _2578 = (_2576 < _2577) ? -1 : (_2576 > _2577);
                }
                else{
                    _2578 = compare(_2576, _2577);
                }
                _2576 = NOVALUE;
                _2577 = NOVALUE;
                if (_2578 < 0)
                goto L3E; // [1208] 1229

                /** 							idx += 1*/
                _idx_4830 = _idx_4830 + 1;

                /** 							dest[idx] = source[a]*/
                _2 = (int)SEQ_PTR(_source_4825);
                _2581 = (int)*(((s1_ptr)_2)->base + _a_5059);
                Ref(_2581);
                _2 = (int)SEQ_PTR(_dest_4829);
                _2 = (int)(((s1_ptr)_2)->base + _idx_4830);
                _1 = *(int *)_2;
                *(int *)_2 = _2581;
                if( _1 != _2581 ){
                    DeRef(_1);
                }
                _2581 = NOVALUE;
L3E: 
L3D: 

                /** 					end for*/
                _a_5059 = _a_5059 + 1;
                goto L3A; // [1232] 1157
L3B: 
                ;
            }
            goto L5; // [1237] 1304

            /** 				case else*/
            case 0:
        ;}        goto L5; // [1244] 1304

        /** 		case else*/
        case 0:

        /** 			for a = 1 to length(source) do*/
        if (IS_SEQUENCE(_source_4825)){
                _2582 = SEQ_PTR(_source_4825)->length;
        }
        else {
            _2582 = 1;
        }
        {
            int _a_5078;
            _a_5078 = 1;
L3F: 
            if (_a_5078 > _2582){
                goto L40; // [1255] 1303
            }

            /** 				if call_func(rid, {source[a], userdata}) then*/
            _2 = (int)SEQ_PTR(_source_4825);
            _2583 = (int)*(((s1_ptr)_2)->base + _a_5078);
            Ref(_userdata_4827);
            Ref(_2583);
            _1 = NewS1(2);
            _2 = (int)((s1_ptr)_1)->base;
            ((int *)_2)[1] = _2583;
            ((int *)_2)[2] = _userdata_4827;
            _2584 = MAKE_SEQ(_1);
            _2583 = NOVALUE;
            _1 = (int)SEQ_PTR(_2584);
            _2 = (int)((s1_ptr)_1)->base;
            _0 = (int)_00[_rid_4826].addr;
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            _1 = (*(int (*)())_0)(
                                *(int *)(_2+4), 
                                *(int *)(_2+8)
                                 );
            DeRef(_2585);
            _2585 = _1;
            DeRefDS(_2584);
            _2584 = NOVALUE;
            if (_2585 == 0) {
                DeRef(_2585);
                _2585 = NOVALUE;
                goto L41; // [1276] 1296
            }
            else {
                if (!IS_ATOM_INT(_2585) && DBL_PTR(_2585)->dbl == 0.0){
                    DeRef(_2585);
                    _2585 = NOVALUE;
                    goto L41; // [1276] 1296
                }
                DeRef(_2585);
                _2585 = NOVALUE;
            }
            DeRef(_2585);
            _2585 = NOVALUE;

            /** 					idx += 1*/
            _idx_4830 = _idx_4830 + 1;

            /** 					dest[idx] = source[a]*/
            _2 = (int)SEQ_PTR(_source_4825);
            _2587 = (int)*(((s1_ptr)_2)->base + _a_5078);
            Ref(_2587);
            _2 = (int)SEQ_PTR(_dest_4829);
            _2 = (int)(((s1_ptr)_2)->base + _idx_4830);
            _1 = *(int *)_2;
            *(int *)_2 = _2587;
            if( _1 != _2587 ){
                DeRef(_1);
            }
            _2587 = NOVALUE;
L41: 

            /** 			end for*/
            _a_5078 = _a_5078 + 1;
            goto L3F; // [1298] 1262
L40: 
            ;
        }
    ;}L5: 

    /** 	return dest[1..idx]*/
    rhs_slice_target = (object_ptr)&_2588;
    RHS_Slice(_dest_4829, 1, _idx_4830);
    DeRefDS(_source_4825);
    DeRef(_userdata_4827);
    DeRef(_rangetype_4828);
    DeRefDS(_dest_4829);
    return _2588;
    ;
}


int _23filter_alpha(int _elem_5090, int _ud_5091)
{
    int _2589 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return t_alpha(elem)*/
    Ref(_elem_5090);
    _2589 = _13t_alpha(_elem_5090);
    DeRef(_elem_5090);
    return _2589;
    ;
}


int _23split(int _st_5135, int _delim_5136, int _no_empty_5137, int _limit_5138)
{
    int _ret_5139 = NOVALUE;
    int _start_5140 = NOVALUE;
    int _pos_5141 = NOVALUE;
    int _k_5193 = NOVALUE;
    int _2657 = NOVALUE;
    int _2655 = NOVALUE;
    int _2654 = NOVALUE;
    int _2650 = NOVALUE;
    int _2649 = NOVALUE;
    int _2648 = NOVALUE;
    int _2645 = NOVALUE;
    int _2644 = NOVALUE;
    int _2639 = NOVALUE;
    int _2638 = NOVALUE;
    int _2634 = NOVALUE;
    int _2630 = NOVALUE;
    int _2628 = NOVALUE;
    int _2627 = NOVALUE;
    int _2623 = NOVALUE;
    int _2621 = NOVALUE;
    int _2620 = NOVALUE;
    int _2619 = NOVALUE;
    int _2618 = NOVALUE;
    int _2615 = NOVALUE;
    int _2614 = NOVALUE;
    int _2613 = NOVALUE;
    int _2612 = NOVALUE;
    int _2611 = NOVALUE;
    int _2609 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence ret = {}*/
    RefDS(_5);
    DeRef(_ret_5139);
    _ret_5139 = _5;

    /** 	if length(st) = 0 then*/
    if (IS_SEQUENCE(_st_5135)){
            _2609 = SEQ_PTR(_st_5135)->length;
    }
    else {
        _2609 = 1;
    }
    if (_2609 != 0)
    goto L1; // [19] 30

    /** 		return ret*/
    DeRefDS(_st_5135);
    DeRefi(_delim_5136);
    return _ret_5139;
L1: 

    /** 	if sequence(delim) then*/
    _2611 = IS_SEQUENCE(_delim_5136);
    if (_2611 == 0)
    {
        _2611 = NOVALUE;
        goto L2; // [35] 211
    }
    else{
        _2611 = NOVALUE;
    }

    /** 		if equal(delim, "") then*/
    if (_delim_5136 == _5)
    _2612 = 1;
    else if (IS_ATOM_INT(_delim_5136) && IS_ATOM_INT(_5))
    _2612 = 0;
    else
    _2612 = (compare(_delim_5136, _5) == 0);
    if (_2612 == 0)
    {
        _2612 = NOVALUE;
        goto L3; // [44] 127
    }
    else{
        _2612 = NOVALUE;
    }

    /** 			for i = 1 to length(st) do*/
    if (IS_SEQUENCE(_st_5135)){
            _2613 = SEQ_PTR(_st_5135)->length;
    }
    else {
        _2613 = 1;
    }
    {
        int _i_5150;
        _i_5150 = 1;
L4: 
        if (_i_5150 > _2613){
            goto L5; // [52] 120
        }

        /** 				st[i] = {st[i]}*/
        _2 = (int)SEQ_PTR(_st_5135);
        _2614 = (int)*(((s1_ptr)_2)->base + _i_5150);
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        Ref(_2614);
        *((int *)(_2+4)) = _2614;
        _2615 = MAKE_SEQ(_1);
        _2614 = NOVALUE;
        _2 = (int)SEQ_PTR(_st_5135);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _st_5135 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_5150);
        _1 = *(int *)_2;
        *(int *)_2 = _2615;
        if( _1 != _2615 ){
            DeRef(_1);
        }
        _2615 = NOVALUE;

        /** 				limit -= 1*/
        _limit_5138 = _limit_5138 - 1;

        /** 				if limit = 0 then*/
        if (_limit_5138 != 0)
        goto L6; // [81] 113

        /** 					st = append(st[1 .. i],st[i+1 .. $])*/
        rhs_slice_target = (object_ptr)&_2618;
        RHS_Slice(_st_5135, 1, _i_5150);
        _2619 = _i_5150 + 1;
        if (IS_SEQUENCE(_st_5135)){
                _2620 = SEQ_PTR(_st_5135)->length;
        }
        else {
            _2620 = 1;
        }
        rhs_slice_target = (object_ptr)&_2621;
        RHS_Slice(_st_5135, _2619, _2620);
        RefDS(_2621);
        Append(&_st_5135, _2618, _2621);
        DeRefDS(_2618);
        _2618 = NOVALUE;
        DeRefDS(_2621);
        _2621 = NOVALUE;

        /** 					exit*/
        goto L5; // [110] 120
L6: 

        /** 			end for*/
        _i_5150 = _i_5150 + 1;
        goto L4; // [115] 59
L5: 
        ;
    }

    /** 			return st*/
    DeRefi(_delim_5136);
    DeRef(_ret_5139);
    DeRef(_2619);
    _2619 = NOVALUE;
    return _st_5135;
L3: 

    /** 		start = 1*/
    _start_5140 = 1;

    /** 		while start <= length(st) do*/
L7: 
    if (IS_SEQUENCE(_st_5135)){
            _2623 = SEQ_PTR(_st_5135)->length;
    }
    else {
        _2623 = 1;
    }
    if (_start_5140 > _2623)
    goto L8; // [140] 290

    /** 			pos = match(delim, st, start)*/
    _pos_5141 = e_match_from(_delim_5136, _st_5135, _start_5140);

    /** 			if pos = 0 then*/
    if (_pos_5141 != 0)
    goto L9; // [153] 162

    /** 				exit*/
    goto L8; // [159] 290
L9: 

    /** 			ret = append(ret, st[start..pos-1])*/
    _2627 = _pos_5141 - 1;
    rhs_slice_target = (object_ptr)&_2628;
    RHS_Slice(_st_5135, _start_5140, _2627);
    RefDS(_2628);
    Append(&_ret_5139, _ret_5139, _2628);
    DeRefDS(_2628);
    _2628 = NOVALUE;

    /** 			start = pos+length(delim)*/
    if (IS_SEQUENCE(_delim_5136)){
            _2630 = SEQ_PTR(_delim_5136)->length;
    }
    else {
        _2630 = 1;
    }
    _start_5140 = _pos_5141 + _2630;
    _2630 = NOVALUE;

    /** 			limit -= 1*/
    _limit_5138 = _limit_5138 - 1;

    /** 			if limit = 0 then*/
    if (_limit_5138 != 0)
    goto L7; // [194] 137

    /** 				exit*/
    goto L8; // [200] 290

    /** 		end while*/
    goto L7; // [205] 137
    goto L8; // [208] 290
L2: 

    /** 		start = 1*/
    _start_5140 = 1;

    /** 		while start <= length(st) do*/
LA: 
    if (IS_SEQUENCE(_st_5135)){
            _2634 = SEQ_PTR(_st_5135)->length;
    }
    else {
        _2634 = 1;
    }
    if (_start_5140 > _2634)
    goto LB; // [224] 289

    /** 			pos = find(delim, st, start)*/
    _pos_5141 = find_from(_delim_5136, _st_5135, _start_5140);

    /** 			if pos = 0 then*/
    if (_pos_5141 != 0)
    goto LC; // [237] 246

    /** 				exit*/
    goto LB; // [243] 289
LC: 

    /** 			ret = append(ret, st[start..pos-1])*/
    _2638 = _pos_5141 - 1;
    rhs_slice_target = (object_ptr)&_2639;
    RHS_Slice(_st_5135, _start_5140, _2638);
    RefDS(_2639);
    Append(&_ret_5139, _ret_5139, _2639);
    DeRefDS(_2639);
    _2639 = NOVALUE;

    /** 			start = pos + 1*/
    _start_5140 = _pos_5141 + 1;

    /** 			limit -= 1*/
    _limit_5138 = _limit_5138 - 1;

    /** 			if limit = 0 then*/
    if (_limit_5138 != 0)
    goto LA; // [275] 221

    /** 				exit*/
    goto LB; // [281] 289

    /** 		end while*/
    goto LA; // [286] 221
LB: 
L8: 

    /** 	ret = append(ret, st[start..$])*/
    if (IS_SEQUENCE(_st_5135)){
            _2644 = SEQ_PTR(_st_5135)->length;
    }
    else {
        _2644 = 1;
    }
    rhs_slice_target = (object_ptr)&_2645;
    RHS_Slice(_st_5135, _start_5140, _2644);
    RefDS(_2645);
    Append(&_ret_5139, _ret_5139, _2645);
    DeRefDS(_2645);
    _2645 = NOVALUE;

    /** 	integer k = length(ret)*/
    if (IS_SEQUENCE(_ret_5139)){
            _k_5193 = SEQ_PTR(_ret_5139)->length;
    }
    else {
        _k_5193 = 1;
    }

    /** 	if no_empty then*/
    if (_no_empty_5137 == 0)
    {
        goto LD; // [313] 378
    }
    else{
    }

    /** 		k = 0*/
    _k_5193 = 0;

    /** 		for i = 1 to length(ret) do*/
    if (IS_SEQUENCE(_ret_5139)){
            _2648 = SEQ_PTR(_ret_5139)->length;
    }
    else {
        _2648 = 1;
    }
    {
        int _i_5197;
        _i_5197 = 1;
LE: 
        if (_i_5197 > _2648){
            goto LF; // [326] 377
        }

        /** 			if length(ret[i]) != 0 then*/
        _2 = (int)SEQ_PTR(_ret_5139);
        _2649 = (int)*(((s1_ptr)_2)->base + _i_5197);
        if (IS_SEQUENCE(_2649)){
                _2650 = SEQ_PTR(_2649)->length;
        }
        else {
            _2650 = 1;
        }
        _2649 = NOVALUE;
        if (_2650 == 0)
        goto L10; // [342] 370

        /** 				k += 1*/
        _k_5193 = _k_5193 + 1;

        /** 				if k != i then*/
        if (_k_5193 == _i_5197)
        goto L11; // [354] 369

        /** 					ret[k] = ret[i]*/
        _2 = (int)SEQ_PTR(_ret_5139);
        _2654 = (int)*(((s1_ptr)_2)->base + _i_5197);
        Ref(_2654);
        _2 = (int)SEQ_PTR(_ret_5139);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _ret_5139 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _k_5193);
        _1 = *(int *)_2;
        *(int *)_2 = _2654;
        if( _1 != _2654 ){
            DeRef(_1);
        }
        _2654 = NOVALUE;
L11: 
L10: 

        /** 		end for*/
        _i_5197 = _i_5197 + 1;
        goto LE; // [372] 333
LF: 
        ;
    }
LD: 

    /** 	if k < length(ret) then*/
    if (IS_SEQUENCE(_ret_5139)){
            _2655 = SEQ_PTR(_ret_5139)->length;
    }
    else {
        _2655 = 1;
    }
    if (_k_5193 >= _2655)
    goto L12; // [383] 401

    /** 		return ret[1 .. k]*/
    rhs_slice_target = (object_ptr)&_2657;
    RHS_Slice(_ret_5139, 1, _k_5193);
    DeRefDS(_st_5135);
    DeRefi(_delim_5136);
    DeRefDS(_ret_5139);
    DeRef(_2627);
    _2627 = NOVALUE;
    DeRef(_2619);
    _2619 = NOVALUE;
    DeRef(_2638);
    _2638 = NOVALUE;
    _2649 = NOVALUE;
    return _2657;
    goto L13; // [398] 408
L12: 

    /** 		return ret*/
    DeRefDS(_st_5135);
    DeRefi(_delim_5136);
    DeRef(_2627);
    _2627 = NOVALUE;
    DeRef(_2619);
    _2619 = NOVALUE;
    DeRef(_2638);
    _2638 = NOVALUE;
    _2649 = NOVALUE;
    DeRef(_2657);
    _2657 = NOVALUE;
    return _ret_5139;
L13: 
    ;
}


int _23join(int _items_5262, int _delim_5263)
{
    int _ret_5265 = NOVALUE;
    int _2692 = NOVALUE;
    int _2691 = NOVALUE;
    int _2689 = NOVALUE;
    int _2688 = NOVALUE;
    int _2687 = NOVALUE;
    int _2686 = NOVALUE;
    int _2684 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not length(items) then return {} end if*/
    if (IS_SEQUENCE(_items_5262)){
            _2684 = SEQ_PTR(_items_5262)->length;
    }
    else {
        _2684 = 1;
    }
    if (_2684 != 0)
    goto L1; // [8] 16
    _2684 = NOVALUE;
    RefDS(_5);
    DeRefDS(_items_5262);
    DeRef(_ret_5265);
    return _5;
L1: 

    /** 	ret = {}*/
    RefDS(_5);
    DeRef(_ret_5265);
    _ret_5265 = _5;

    /** 	for i=1 to length(items)-1 do*/
    if (IS_SEQUENCE(_items_5262)){
            _2686 = SEQ_PTR(_items_5262)->length;
    }
    else {
        _2686 = 1;
    }
    _2687 = _2686 - 1;
    _2686 = NOVALUE;
    {
        int _i_5270;
        _i_5270 = 1;
L2: 
        if (_i_5270 > _2687){
            goto L3; // [30] 58
        }

        /** 		ret &= items[i] & delim*/
        _2 = (int)SEQ_PTR(_items_5262);
        _2688 = (int)*(((s1_ptr)_2)->base + _i_5270);
        if (IS_SEQUENCE(_2688) && IS_ATOM(_delim_5263)) {
            Append(&_2689, _2688, _delim_5263);
        }
        else if (IS_ATOM(_2688) && IS_SEQUENCE(_delim_5263)) {
        }
        else {
            Concat((object_ptr)&_2689, _2688, _delim_5263);
            _2688 = NOVALUE;
        }
        _2688 = NOVALUE;
        if (IS_SEQUENCE(_ret_5265) && IS_ATOM(_2689)) {
        }
        else if (IS_ATOM(_ret_5265) && IS_SEQUENCE(_2689)) {
            Ref(_ret_5265);
            Prepend(&_ret_5265, _2689, _ret_5265);
        }
        else {
            Concat((object_ptr)&_ret_5265, _ret_5265, _2689);
        }
        DeRefDS(_2689);
        _2689 = NOVALUE;

        /** 	end for*/
        _i_5270 = _i_5270 + 1;
        goto L2; // [53] 37
L3: 
        ;
    }

    /** 	ret &= items[$]*/
    if (IS_SEQUENCE(_items_5262)){
            _2691 = SEQ_PTR(_items_5262)->length;
    }
    else {
        _2691 = 1;
    }
    _2 = (int)SEQ_PTR(_items_5262);
    _2692 = (int)*(((s1_ptr)_2)->base + _2691);
    if (IS_SEQUENCE(_ret_5265) && IS_ATOM(_2692)) {
        Ref(_2692);
        Append(&_ret_5265, _ret_5265, _2692);
    }
    else if (IS_ATOM(_ret_5265) && IS_SEQUENCE(_2692)) {
        Ref(_ret_5265);
        Prepend(&_ret_5265, _2692, _ret_5265);
    }
    else {
        Concat((object_ptr)&_ret_5265, _ret_5265, _2692);
    }
    _2692 = NOVALUE;

    /** 	return ret*/
    DeRefDS(_items_5262);
    DeRef(_2687);
    _2687 = NOVALUE;
    return _ret_5265;
    ;
}


int _23flatten(int _s_5372, int _delim_5373)
{
    int _ret_5374 = NOVALUE;
    int _x_5375 = NOVALUE;
    int _len_5376 = NOVALUE;
    int _pos_5377 = NOVALUE;
    int _temp_5395 = NOVALUE;
    int _2778 = NOVALUE;
    int _2777 = NOVALUE;
    int _2776 = NOVALUE;
    int _2774 = NOVALUE;
    int _2773 = NOVALUE;
    int _2772 = NOVALUE;
    int _2770 = NOVALUE;
    int _2768 = NOVALUE;
    int _2767 = NOVALUE;
    int _2766 = NOVALUE;
    int _2764 = NOVALUE;
    int _2763 = NOVALUE;
    int _2762 = NOVALUE;
    int _2761 = NOVALUE;
    int _2760 = NOVALUE;
    int _2759 = NOVALUE;
    int _2757 = NOVALUE;
    int _2756 = NOVALUE;
    int _0, _1, _2;
    

    /** 	ret = s*/
    RefDS(_s_5372);
    DeRef(_ret_5374);
    _ret_5374 = _s_5372;

    /** 	pos = 1*/
    _pos_5377 = 1;

    /** 	len = length(ret)*/
    if (IS_SEQUENCE(_ret_5374)){
            _len_5376 = SEQ_PTR(_ret_5374)->length;
    }
    else {
        _len_5376 = 1;
    }

    /** 	while pos <= len do*/
L1: 
    if (_pos_5377 > _len_5376)
    goto L2; // [25] 183

    /** 		x = ret[pos]*/
    DeRef(_x_5375);
    _2 = (int)SEQ_PTR(_ret_5374);
    _x_5375 = (int)*(((s1_ptr)_2)->base + _pos_5377);
    Ref(_x_5375);

    /** 		if sequence(x) then*/
    _2756 = IS_SEQUENCE(_x_5375);
    if (_2756 == 0)
    {
        _2756 = NOVALUE;
        goto L3; // [40] 171
    }
    else{
        _2756 = NOVALUE;
    }

    /** 			if length(delim) = 0 then*/
    if (IS_SEQUENCE(_delim_5373)){
            _2757 = SEQ_PTR(_delim_5373)->length;
    }
    else {
        _2757 = 1;
    }
    if (_2757 != 0)
    goto L4; // [48] 89

    /** 				ret = ret[1..pos-1] & flatten(x) & ret[pos+1 .. $]*/
    _2759 = _pos_5377 - 1;
    rhs_slice_target = (object_ptr)&_2760;
    RHS_Slice(_ret_5374, 1, _2759);
    Ref(_x_5375);
    RefDS(_5);
    _2761 = _23flatten(_x_5375, _5);
    _2762 = _pos_5377 + 1;
    if (_2762 > MAXINT){
        _2762 = NewDouble((double)_2762);
    }
    if (IS_SEQUENCE(_ret_5374)){
            _2763 = SEQ_PTR(_ret_5374)->length;
    }
    else {
        _2763 = 1;
    }
    rhs_slice_target = (object_ptr)&_2764;
    RHS_Slice(_ret_5374, _2762, _2763);
    {
        int concat_list[3];

        concat_list[0] = _2764;
        concat_list[1] = _2761;
        concat_list[2] = _2760;
        Concat_N((object_ptr)&_ret_5374, concat_list, 3);
    }
    DeRefDS(_2764);
    _2764 = NOVALUE;
    DeRef(_2761);
    _2761 = NOVALUE;
    DeRefDS(_2760);
    _2760 = NOVALUE;
    goto L5; // [86] 163
L4: 

    /** 				sequence temp = ret[1..pos-1] & flatten(x)*/
    _2766 = _pos_5377 - 1;
    rhs_slice_target = (object_ptr)&_2767;
    RHS_Slice(_ret_5374, 1, _2766);
    Ref(_x_5375);
    RefDS(_5);
    _2768 = _23flatten(_x_5375, _5);
    if (IS_SEQUENCE(_2767) && IS_ATOM(_2768)) {
        Ref(_2768);
        Append(&_temp_5395, _2767, _2768);
    }
    else if (IS_ATOM(_2767) && IS_SEQUENCE(_2768)) {
    }
    else {
        Concat((object_ptr)&_temp_5395, _2767, _2768);
        DeRefDS(_2767);
        _2767 = NOVALUE;
    }
    DeRef(_2767);
    _2767 = NOVALUE;
    DeRef(_2768);
    _2768 = NOVALUE;

    /** 				if pos != length(ret) then*/
    if (IS_SEQUENCE(_ret_5374)){
            _2770 = SEQ_PTR(_ret_5374)->length;
    }
    else {
        _2770 = 1;
    }
    if (_pos_5377 == _2770)
    goto L6; // [114] 141

    /** 					ret = temp &  delim & ret[pos+1 .. $]*/
    _2772 = _pos_5377 + 1;
    if (_2772 > MAXINT){
        _2772 = NewDouble((double)_2772);
    }
    if (IS_SEQUENCE(_ret_5374)){
            _2773 = SEQ_PTR(_ret_5374)->length;
    }
    else {
        _2773 = 1;
    }
    rhs_slice_target = (object_ptr)&_2774;
    RHS_Slice(_ret_5374, _2772, _2773);
    {
        int concat_list[3];

        concat_list[0] = _2774;
        concat_list[1] = _delim_5373;
        concat_list[2] = _temp_5395;
        Concat_N((object_ptr)&_ret_5374, concat_list, 3);
    }
    DeRefDS(_2774);
    _2774 = NOVALUE;
    goto L7; // [138] 160
L6: 

    /** 					ret = temp & ret[pos+1 .. $]*/
    _2776 = _pos_5377 + 1;
    if (_2776 > MAXINT){
        _2776 = NewDouble((double)_2776);
    }
    if (IS_SEQUENCE(_ret_5374)){
            _2777 = SEQ_PTR(_ret_5374)->length;
    }
    else {
        _2777 = 1;
    }
    rhs_slice_target = (object_ptr)&_2778;
    RHS_Slice(_ret_5374, _2776, _2777);
    Concat((object_ptr)&_ret_5374, _temp_5395, _2778);
    DeRefDS(_2778);
    _2778 = NOVALUE;
L7: 
    DeRef(_temp_5395);
    _temp_5395 = NOVALUE;
L5: 

    /** 			len = length(ret)*/
    if (IS_SEQUENCE(_ret_5374)){
            _len_5376 = SEQ_PTR(_ret_5374)->length;
    }
    else {
        _len_5376 = 1;
    }
    goto L1; // [168] 25
L3: 

    /** 			pos += 1*/
    _pos_5377 = _pos_5377 + 1;

    /** 	end while*/
    goto L1; // [180] 25
L2: 

    /** 	return ret*/
    DeRefDS(_s_5372);
    DeRefi(_delim_5373);
    DeRef(_x_5375);
    DeRef(_2759);
    _2759 = NOVALUE;
    DeRef(_2766);
    _2766 = NOVALUE;
    DeRef(_2772);
    _2772 = NOVALUE;
    DeRef(_2762);
    _2762 = NOVALUE;
    DeRef(_2776);
    _2776 = NOVALUE;
    return _ret_5374;
    ;
}



// 0x57389EA9
