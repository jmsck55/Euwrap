// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

void _26pretty_out(int _text_7554)
{
    int _4077 = NOVALUE;
    int _4075 = NOVALUE;
    int _4073 = NOVALUE;
    int _4072 = NOVALUE;
    int _0, _1, _2;
    

    /** 	pretty_line &= text*/
    if (IS_SEQUENCE(_26pretty_line_7551) && IS_ATOM(_text_7554)) {
        Ref(_text_7554);
        Append(&_26pretty_line_7551, _26pretty_line_7551, _text_7554);
    }
    else if (IS_ATOM(_26pretty_line_7551) && IS_SEQUENCE(_text_7554)) {
    }
    else {
        Concat((object_ptr)&_26pretty_line_7551, _26pretty_line_7551, _text_7554);
    }

    /** 	if equal(text, '\n') and pretty_printing then*/
    if (_text_7554 == 10)
    _4072 = 1;
    else if (IS_ATOM_INT(_text_7554) && IS_ATOM_INT(10))
    _4072 = 0;
    else
    _4072 = (compare(_text_7554, 10) == 0);
    if (_4072 == 0) {
        goto L1; // [15] 50
    }
    goto L1; // [22] 50

    /** 		puts(pretty_file, pretty_line)*/
    EPuts(_26pretty_file_7539, _26pretty_line_7551); // DJP 

    /** 		pretty_line = ""*/
    RefDS(_5);
    DeRefDS(_26pretty_line_7551);
    _26pretty_line_7551 = _5;

    /** 		pretty_line_count += 1*/
    _26pretty_line_count_7544 = _26pretty_line_count_7544 + 1;
L1: 

    /** 	if atom(text) then*/
    _4075 = IS_ATOM(_text_7554);
    if (_4075 == 0)
    {
        _4075 = NOVALUE;
        goto L2; // [55] 69
    }
    else{
        _4075 = NOVALUE;
    }

    /** 		pretty_chars += 1*/
    _26pretty_chars_7536 = _26pretty_chars_7536 + 1;
    goto L3; // [66] 81
L2: 

    /** 		pretty_chars += length(text)*/
    if (IS_SEQUENCE(_text_7554)){
            _4077 = SEQ_PTR(_text_7554)->length;
    }
    else {
        _4077 = 1;
    }
    _26pretty_chars_7536 = _26pretty_chars_7536 + _4077;
    _4077 = NOVALUE;
L3: 

    /** end procedure*/
    DeRef(_text_7554);
    return;
    ;
}


void _26cut_line(int _n_7568)
{
    int _4080 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not pretty_line_breaks then	*/
    if (_26pretty_line_breaks_7547 != 0)
    goto L1; // [7] 21

    /** 		pretty_chars = 0*/
    _26pretty_chars_7536 = 0;

    /** 		return*/
    return;
L1: 

    /** 	if pretty_chars + n > pretty_end_col then*/
    _4080 = _26pretty_chars_7536 + _n_7568;
    if ((long)((unsigned long)_4080 + (unsigned long)HIGH_BITS) >= 0) 
    _4080 = NewDouble((double)_4080);
    if (binary_op_a(LESSEQ, _4080, _26pretty_end_col_7535)){
        DeRef(_4080);
        _4080 = NOVALUE;
        goto L2; // [31] 46
    }
    DeRef(_4080);
    _4080 = NOVALUE;

    /** 		pretty_out('\n')*/
    _26pretty_out(10);

    /** 		pretty_chars = 0*/
    _26pretty_chars_7536 = 0;
L2: 

    /** end procedure*/
    return;
    ;
}


void _26indent()
{
    int _4088 = NOVALUE;
    int _4087 = NOVALUE;
    int _4086 = NOVALUE;
    int _4085 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if pretty_line_breaks = 0 then	*/
    if (_26pretty_line_breaks_7547 != 0)
    goto L1; // [5] 22

    /** 		pretty_chars = 0*/
    _26pretty_chars_7536 = 0;

    /** 		return*/
    return;
    goto L2; // [19] 85
L1: 

    /** 	elsif pretty_line_breaks = -1 then*/
    if (_26pretty_line_breaks_7547 != -1)
    goto L3; // [26] 38

    /** 		cut_line( 0 )*/
    _26cut_line(0);
    goto L2; // [35] 85
L3: 

    /** 		if pretty_chars > 0 then*/
    if (_26pretty_chars_7536 <= 0)
    goto L4; // [42] 57

    /** 			pretty_out('\n')*/
    _26pretty_out(10);

    /** 			pretty_chars = 0*/
    _26pretty_chars_7536 = 0;
L4: 

    /** 		pretty_out(repeat(' ', (pretty_start_col-1) + */
    _4085 = _26pretty_start_col_7537 - 1;
    if ((long)((unsigned long)_4085 +(unsigned long) HIGH_BITS) >= 0){
        _4085 = NewDouble((double)_4085);
    }
    if (_26pretty_level_7538 == (short)_26pretty_level_7538 && _26pretty_indent_7541 <= INT15 && _26pretty_indent_7541 >= -INT15)
    _4086 = _26pretty_level_7538 * _26pretty_indent_7541;
    else
    _4086 = NewDouble(_26pretty_level_7538 * (double)_26pretty_indent_7541);
    if (IS_ATOM_INT(_4085) && IS_ATOM_INT(_4086)) {
        _4087 = _4085 + _4086;
    }
    else {
        if (IS_ATOM_INT(_4085)) {
            _4087 = NewDouble((double)_4085 + DBL_PTR(_4086)->dbl);
        }
        else {
            if (IS_ATOM_INT(_4086)) {
                _4087 = NewDouble(DBL_PTR(_4085)->dbl + (double)_4086);
            }
            else
            _4087 = NewDouble(DBL_PTR(_4085)->dbl + DBL_PTR(_4086)->dbl);
        }
    }
    DeRef(_4085);
    _4085 = NOVALUE;
    DeRef(_4086);
    _4086 = NOVALUE;
    _4088 = Repeat(32, _4087);
    DeRef(_4087);
    _4087 = NOVALUE;
    _26pretty_out(_4088);
    _4088 = NOVALUE;
L2: 

    /** end procedure*/
    return;
    ;
}


int _26esc_char(int _a_7589)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_a_7589)) {
        _1 = (long)(DBL_PTR(_a_7589)->dbl);
        DeRefDS(_a_7589);
        _a_7589 = _1;
    }

    /** 	switch a do*/
    _0 = _a_7589;
    switch ( _0 ){ 

        /** 		case'\t' then*/
        case 9:

        /** 			return `\t`*/
        RefDS(_4091);
        return _4091;
        goto L1; // [20] 81

        /** 		case'\n' then*/
        case 10:

        /** 			return `\n`*/
        RefDS(_4092);
        return _4092;
        goto L1; // [32] 81

        /** 		case'\r' then*/
        case 13:

        /** 			return `\r`*/
        RefDS(_4093);
        return _4093;
        goto L1; // [44] 81

        /** 		case'\\' then*/
        case 92:

        /** 			return `\\`*/
        RefDS(_946);
        return _946;
        goto L1; // [56] 81

        /** 		case'"' then*/
        case 34:

        /** 			return `\"`*/
        RefDS(_4094);
        return _4094;
        goto L1; // [68] 81

        /** 		case else*/
        default:

        /** 			return a*/
        return _a_7589;
    ;}L1: 
    ;
}


void _26rPrint(int _a_7604)
{
    int _sbuff_7605 = NOVALUE;
    int _multi_line_7606 = NOVALUE;
    int _all_ascii_7607 = NOVALUE;
    int _4151 = NOVALUE;
    int _4150 = NOVALUE;
    int _4149 = NOVALUE;
    int _4148 = NOVALUE;
    int _4144 = NOVALUE;
    int _4143 = NOVALUE;
    int _4142 = NOVALUE;
    int _4141 = NOVALUE;
    int _4139 = NOVALUE;
    int _4138 = NOVALUE;
    int _4136 = NOVALUE;
    int _4135 = NOVALUE;
    int _4133 = NOVALUE;
    int _4132 = NOVALUE;
    int _4131 = NOVALUE;
    int _4130 = NOVALUE;
    int _4129 = NOVALUE;
    int _4128 = NOVALUE;
    int _4127 = NOVALUE;
    int _4126 = NOVALUE;
    int _4125 = NOVALUE;
    int _4124 = NOVALUE;
    int _4123 = NOVALUE;
    int _4122 = NOVALUE;
    int _4121 = NOVALUE;
    int _4120 = NOVALUE;
    int _4119 = NOVALUE;
    int _4118 = NOVALUE;
    int _4117 = NOVALUE;
    int _4113 = NOVALUE;
    int _4112 = NOVALUE;
    int _4111 = NOVALUE;
    int _4110 = NOVALUE;
    int _4109 = NOVALUE;
    int _4108 = NOVALUE;
    int _4106 = NOVALUE;
    int _4105 = NOVALUE;
    int _4101 = NOVALUE;
    int _4100 = NOVALUE;
    int _4099 = NOVALUE;
    int _4096 = NOVALUE;
    int _4095 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(a) then*/
    _4095 = IS_ATOM(_a_7604);
    if (_4095 == 0)
    {
        _4095 = NOVALUE;
        goto L1; // [6] 176
    }
    else{
        _4095 = NOVALUE;
    }

    /** 		if integer(a) then*/
    if (IS_ATOM_INT(_a_7604))
    _4096 = 1;
    else if (IS_ATOM_DBL(_a_7604))
    _4096 = IS_ATOM_INT(DoubleToInt(_a_7604));
    else
    _4096 = 0;
    if (_4096 == 0)
    {
        _4096 = NOVALUE;
        goto L2; // [14] 157
    }
    else{
        _4096 = NOVALUE;
    }

    /** 			sbuff = sprintf(pretty_int_format, a)*/
    DeRef(_sbuff_7605);
    _sbuff_7605 = EPrintf(-9999999, _26pretty_int_format_7550, _a_7604);

    /** 			if pretty_ascii then */
    if (_26pretty_ascii_7540 == 0)
    {
        goto L3; // [29] 166
    }
    else{
    }

    /** 				if pretty_ascii >= 3 then */
    if (_26pretty_ascii_7540 < 3)
    goto L4; // [36] 103

    /** 					if (a >= pretty_ascii_min and a <= pretty_ascii_max) then*/
    if (IS_ATOM_INT(_a_7604)) {
        _4099 = (_a_7604 >= _26pretty_ascii_min_7542);
    }
    else {
        _4099 = binary_op(GREATEREQ, _a_7604, _26pretty_ascii_min_7542);
    }
    if (IS_ATOM_INT(_4099)) {
        if (_4099 == 0) {
            _4100 = 0;
            goto L5; // [48] 62
        }
    }
    else {
        if (DBL_PTR(_4099)->dbl == 0.0) {
            _4100 = 0;
            goto L5; // [48] 62
        }
    }
    if (IS_ATOM_INT(_a_7604)) {
        _4101 = (_a_7604 <= _26pretty_ascii_max_7543);
    }
    else {
        _4101 = binary_op(LESSEQ, _a_7604, _26pretty_ascii_max_7543);
    }
    DeRef(_4100);
    if (IS_ATOM_INT(_4101))
    _4100 = (_4101 != 0);
    else
    _4100 = DBL_PTR(_4101)->dbl != 0.0;
L5: 
    if (_4100 == 0)
    {
        _4100 = NOVALUE;
        goto L6; // [62] 76
    }
    else{
        _4100 = NOVALUE;
    }

    /** 						sbuff = '\'' & a & '\''  -- display char only*/
    {
        int concat_list[3];

        concat_list[0] = 39;
        concat_list[1] = _a_7604;
        concat_list[2] = 39;
        Concat_N((object_ptr)&_sbuff_7605, concat_list, 3);
    }
    goto L3; // [73] 166
L6: 

    /** 					elsif find(a, "\t\n\r\\") then*/
    _4105 = find_from(_a_7604, _4104, 1);
    if (_4105 == 0)
    {
        _4105 = NOVALUE;
        goto L3; // [83] 166
    }
    else{
        _4105 = NOVALUE;
    }

    /** 						sbuff = '\'' & esc_char(a) & '\''  -- display char only*/
    Ref(_a_7604);
    _4106 = _26esc_char(_a_7604);
    {
        int concat_list[3];

        concat_list[0] = 39;
        concat_list[1] = _4106;
        concat_list[2] = 39;
        Concat_N((object_ptr)&_sbuff_7605, concat_list, 3);
    }
    DeRef(_4106);
    _4106 = NOVALUE;
    goto L3; // [100] 166
L4: 

    /** 					if (a >= pretty_ascii_min and a <= pretty_ascii_max) and pretty_ascii < 2 then*/
    if (IS_ATOM_INT(_a_7604)) {
        _4108 = (_a_7604 >= _26pretty_ascii_min_7542);
    }
    else {
        _4108 = binary_op(GREATEREQ, _a_7604, _26pretty_ascii_min_7542);
    }
    if (IS_ATOM_INT(_4108)) {
        if (_4108 == 0) {
            DeRef(_4109);
            _4109 = 0;
            goto L7; // [111] 125
        }
    }
    else {
        if (DBL_PTR(_4108)->dbl == 0.0) {
            DeRef(_4109);
            _4109 = 0;
            goto L7; // [111] 125
        }
    }
    if (IS_ATOM_INT(_a_7604)) {
        _4110 = (_a_7604 <= _26pretty_ascii_max_7543);
    }
    else {
        _4110 = binary_op(LESSEQ, _a_7604, _26pretty_ascii_max_7543);
    }
    DeRef(_4109);
    if (IS_ATOM_INT(_4110))
    _4109 = (_4110 != 0);
    else
    _4109 = DBL_PTR(_4110)->dbl != 0.0;
L7: 
    if (_4109 == 0) {
        goto L3; // [125] 166
    }
    _4112 = (_26pretty_ascii_7540 < 2);
    if (_4112 == 0)
    {
        DeRef(_4112);
        _4112 = NOVALUE;
        goto L3; // [136] 166
    }
    else{
        DeRef(_4112);
        _4112 = NOVALUE;
    }

    /** 						sbuff &= '\'' & a & '\'' -- add to numeric display*/
    {
        int concat_list[3];

        concat_list[0] = 39;
        concat_list[1] = _a_7604;
        concat_list[2] = 39;
        Concat_N((object_ptr)&_4113, concat_list, 3);
    }
    Concat((object_ptr)&_sbuff_7605, _sbuff_7605, _4113);
    DeRefDS(_4113);
    _4113 = NOVALUE;
    goto L3; // [154] 166
L2: 

    /** 			sbuff = sprintf(pretty_fp_format, a)*/
    DeRef(_sbuff_7605);
    _sbuff_7605 = EPrintf(-9999999, _26pretty_fp_format_7549, _a_7604);
L3: 

    /** 		pretty_out(sbuff)*/
    RefDS(_sbuff_7605);
    _26pretty_out(_sbuff_7605);
    goto L8; // [173] 535
L1: 

    /** 		cut_line(1)*/
    _26cut_line(1);

    /** 		multi_line = 0*/
    _multi_line_7606 = 0;

    /** 		all_ascii = pretty_ascii > 1*/
    _all_ascii_7607 = (_26pretty_ascii_7540 > 1);

    /** 		for i = 1 to length(a) do*/
    if (IS_SEQUENCE(_a_7604)){
            _4117 = SEQ_PTR(_a_7604)->length;
    }
    else {
        _4117 = 1;
    }
    {
        int _i_7641;
        _i_7641 = 1;
L9: 
        if (_i_7641 > _4117){
            goto LA; // [199] 345
        }

        /** 			if sequence(a[i]) and length(a[i]) > 0 then*/
        _2 = (int)SEQ_PTR(_a_7604);
        _4118 = (int)*(((s1_ptr)_2)->base + _i_7641);
        _4119 = IS_SEQUENCE(_4118);
        _4118 = NOVALUE;
        if (_4119 == 0) {
            goto LB; // [215] 249
        }
        _2 = (int)SEQ_PTR(_a_7604);
        _4121 = (int)*(((s1_ptr)_2)->base + _i_7641);
        if (IS_SEQUENCE(_4121)){
                _4122 = SEQ_PTR(_4121)->length;
        }
        else {
            _4122 = 1;
        }
        _4121 = NOVALUE;
        _4123 = (_4122 > 0);
        _4122 = NOVALUE;
        if (_4123 == 0)
        {
            DeRef(_4123);
            _4123 = NOVALUE;
            goto LB; // [231] 249
        }
        else{
            DeRef(_4123);
            _4123 = NOVALUE;
        }

        /** 				multi_line = 1*/
        _multi_line_7606 = 1;

        /** 				all_ascii = 0*/
        _all_ascii_7607 = 0;

        /** 				exit*/
        goto LA; // [246] 345
LB: 

        /** 			if not integer(a[i]) or*/
        _2 = (int)SEQ_PTR(_a_7604);
        _4124 = (int)*(((s1_ptr)_2)->base + _i_7641);
        if (IS_ATOM_INT(_4124))
        _4125 = 1;
        else if (IS_ATOM_DBL(_4124))
        _4125 = IS_ATOM_INT(DoubleToInt(_4124));
        else
        _4125 = 0;
        _4124 = NOVALUE;
        _4126 = (_4125 == 0);
        _4125 = NOVALUE;
        if (_4126 != 0) {
            _4127 = 1;
            goto LC; // [261] 313
        }
        _2 = (int)SEQ_PTR(_a_7604);
        _4128 = (int)*(((s1_ptr)_2)->base + _i_7641);
        if (IS_ATOM_INT(_4128)) {
            _4129 = (_4128 < _26pretty_ascii_min_7542);
        }
        else {
            _4129 = binary_op(LESS, _4128, _26pretty_ascii_min_7542);
        }
        _4128 = NOVALUE;
        if (IS_ATOM_INT(_4129)) {
            if (_4129 == 0) {
                DeRef(_4130);
                _4130 = 0;
                goto LD; // [275] 309
            }
        }
        else {
            if (DBL_PTR(_4129)->dbl == 0.0) {
                DeRef(_4130);
                _4130 = 0;
                goto LD; // [275] 309
            }
        }
        _4131 = (_26pretty_ascii_7540 < 2);
        if (_4131 != 0) {
            _4132 = 1;
            goto LE; // [285] 305
        }
        _2 = (int)SEQ_PTR(_a_7604);
        _4133 = (int)*(((s1_ptr)_2)->base + _i_7641);
        _4135 = find_from(_4133, _4134, 1);
        _4133 = NOVALUE;
        _4136 = (_4135 == 0);
        _4135 = NOVALUE;
        _4132 = (_4136 != 0);
LE: 
        DeRef(_4130);
        _4130 = (_4132 != 0);
LD: 
        _4127 = (_4130 != 0);
LC: 
        if (_4127 != 0) {
            goto LF; // [313] 332
        }
        _2 = (int)SEQ_PTR(_a_7604);
        _4138 = (int)*(((s1_ptr)_2)->base + _i_7641);
        if (IS_ATOM_INT(_4138)) {
            _4139 = (_4138 > _26pretty_ascii_max_7543);
        }
        else {
            _4139 = binary_op(GREATER, _4138, _26pretty_ascii_max_7543);
        }
        _4138 = NOVALUE;
        if (_4139 == 0) {
            DeRef(_4139);
            _4139 = NOVALUE;
            goto L10; // [328] 338
        }
        else {
            if (!IS_ATOM_INT(_4139) && DBL_PTR(_4139)->dbl == 0.0){
                DeRef(_4139);
                _4139 = NOVALUE;
                goto L10; // [328] 338
            }
            DeRef(_4139);
            _4139 = NOVALUE;
        }
        DeRef(_4139);
        _4139 = NOVALUE;
LF: 

        /** 				all_ascii = 0*/
        _all_ascii_7607 = 0;
L10: 

        /** 		end for*/
        _i_7641 = _i_7641 + 1;
        goto L9; // [340] 206
LA: 
        ;
    }

    /** 		if all_ascii then*/
    if (_all_ascii_7607 == 0)
    {
        goto L11; // [347] 358
    }
    else{
    }

    /** 			pretty_out('\"')*/
    _26pretty_out(34);
    goto L12; // [355] 364
L11: 

    /** 			pretty_out('{')*/
    _26pretty_out(123);
L12: 

    /** 		pretty_level += 1*/
    _26pretty_level_7538 = _26pretty_level_7538 + 1;

    /** 		for i = 1 to length(a) do*/
    if (IS_SEQUENCE(_a_7604)){
            _4141 = SEQ_PTR(_a_7604)->length;
    }
    else {
        _4141 = 1;
    }
    {
        int _i_7671;
        _i_7671 = 1;
L13: 
        if (_i_7671 > _4141){
            goto L14; // [377] 497
        }

        /** 			if multi_line then*/
        if (_multi_line_7606 == 0)
        {
            goto L15; // [386] 394
        }
        else{
        }

        /** 				indent()*/
        _26indent();
L15: 

        /** 			if all_ascii then*/
        if (_all_ascii_7607 == 0)
        {
            goto L16; // [396] 415
        }
        else{
        }

        /** 				pretty_out(esc_char(a[i]))*/
        _2 = (int)SEQ_PTR(_a_7604);
        _4142 = (int)*(((s1_ptr)_2)->base + _i_7671);
        Ref(_4142);
        _4143 = _26esc_char(_4142);
        _4142 = NOVALUE;
        _26pretty_out(_4143);
        _4143 = NOVALUE;
        goto L17; // [412] 425
L16: 

        /** 				rPrint(a[i])*/
        _2 = (int)SEQ_PTR(_a_7604);
        _4144 = (int)*(((s1_ptr)_2)->base + _i_7671);
        Ref(_4144);
        _26rPrint(_4144);
        _4144 = NOVALUE;
L17: 

        /** 			if pretty_line_count >= pretty_line_max then*/
        if (_26pretty_line_count_7544 < _26pretty_line_max_7545)
        goto L18; // [431] 459

        /** 				if not pretty_dots then*/
        if (_26pretty_dots_7546 != 0)
        goto L19; // [439] 448

        /** 					pretty_out(" ...")*/
        RefDS(_4147);
        _26pretty_out(_4147);
L19: 

        /** 				pretty_dots = 1*/
        _26pretty_dots_7546 = 1;

        /** 				return*/
        DeRef(_a_7604);
        DeRef(_sbuff_7605);
        DeRef(_4099);
        _4099 = NOVALUE;
        DeRef(_4101);
        _4101 = NOVALUE;
        DeRef(_4108);
        _4108 = NOVALUE;
        DeRef(_4110);
        _4110 = NOVALUE;
        _4121 = NOVALUE;
        DeRef(_4126);
        _4126 = NOVALUE;
        DeRef(_4131);
        _4131 = NOVALUE;
        DeRef(_4129);
        _4129 = NOVALUE;
        DeRef(_4136);
        _4136 = NOVALUE;
        return;
L18: 

        /** 			if i != length(a) and not all_ascii then*/
        if (IS_SEQUENCE(_a_7604)){
                _4148 = SEQ_PTR(_a_7604)->length;
        }
        else {
            _4148 = 1;
        }
        _4149 = (_i_7671 != _4148);
        _4148 = NOVALUE;
        if (_4149 == 0) {
            goto L1A; // [468] 490
        }
        _4151 = (_all_ascii_7607 == 0);
        if (_4151 == 0)
        {
            DeRef(_4151);
            _4151 = NOVALUE;
            goto L1A; // [476] 490
        }
        else{
            DeRef(_4151);
            _4151 = NOVALUE;
        }

        /** 				pretty_out(',')*/
        _26pretty_out(44);

        /** 				cut_line(6)*/
        _26cut_line(6);
L1A: 

        /** 		end for*/
        _i_7671 = _i_7671 + 1;
        goto L13; // [492] 384
L14: 
        ;
    }

    /** 		pretty_level -= 1*/
    _26pretty_level_7538 = _26pretty_level_7538 - 1;

    /** 		if multi_line then*/
    if (_multi_line_7606 == 0)
    {
        goto L1B; // [507] 515
    }
    else{
    }

    /** 			indent()*/
    _26indent();
L1B: 

    /** 		if all_ascii then*/
    if (_all_ascii_7607 == 0)
    {
        goto L1C; // [517] 528
    }
    else{
    }

    /** 			pretty_out('\"')*/
    _26pretty_out(34);
    goto L1D; // [525] 534
L1C: 

    /** 			pretty_out('}')*/
    _26pretty_out(125);
L1D: 
L8: 

    /** end procedure*/
    DeRef(_a_7604);
    DeRef(_sbuff_7605);
    DeRef(_4099);
    _4099 = NOVALUE;
    DeRef(_4101);
    _4101 = NOVALUE;
    DeRef(_4108);
    _4108 = NOVALUE;
    DeRef(_4110);
    _4110 = NOVALUE;
    _4121 = NOVALUE;
    DeRef(_4126);
    _4126 = NOVALUE;
    DeRef(_4131);
    _4131 = NOVALUE;
    DeRef(_4129);
    _4129 = NOVALUE;
    DeRef(_4136);
    _4136 = NOVALUE;
    DeRef(_4149);
    _4149 = NOVALUE;
    return;
    ;
}


void _26pretty(int _x_7710, int _options_7711)
{
    int _4158 = NOVALUE;
    int _4157 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if length(options) < length( PRETTY_DEFAULT ) then*/
    _4157 = 10;
    _4158 = 10;

    /** 	pretty_ascii = options[DISPLAY_ASCII] */
    _2 = (int)SEQ_PTR(_options_7711);
    _26pretty_ascii_7540 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_26pretty_ascii_7540))
    _26pretty_ascii_7540 = (long)DBL_PTR(_26pretty_ascii_7540)->dbl;

    /** 	pretty_indent = options[INDENT]*/
    _2 = (int)SEQ_PTR(_options_7711);
    _26pretty_indent_7541 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_26pretty_indent_7541))
    _26pretty_indent_7541 = (long)DBL_PTR(_26pretty_indent_7541)->dbl;

    /** 	pretty_start_col = options[START_COLUMN]*/
    _2 = (int)SEQ_PTR(_options_7711);
    _26pretty_start_col_7537 = (int)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_26pretty_start_col_7537))
    _26pretty_start_col_7537 = (long)DBL_PTR(_26pretty_start_col_7537)->dbl;

    /** 	pretty_end_col = options[WRAP]*/
    _2 = (int)SEQ_PTR(_options_7711);
    _26pretty_end_col_7535 = (int)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_26pretty_end_col_7535))
    _26pretty_end_col_7535 = (long)DBL_PTR(_26pretty_end_col_7535)->dbl;

    /** 	pretty_int_format = options[INT_FORMAT]*/
    DeRef(_26pretty_int_format_7550);
    _2 = (int)SEQ_PTR(_options_7711);
    _26pretty_int_format_7550 = (int)*(((s1_ptr)_2)->base + 5);
    Ref(_26pretty_int_format_7550);

    /** 	pretty_fp_format = options[FP_FORMAT]*/
    DeRef(_26pretty_fp_format_7549);
    _2 = (int)SEQ_PTR(_options_7711);
    _26pretty_fp_format_7549 = (int)*(((s1_ptr)_2)->base + 6);
    Ref(_26pretty_fp_format_7549);

    /** 	pretty_ascii_min = options[MIN_ASCII]*/
    _2 = (int)SEQ_PTR(_options_7711);
    _26pretty_ascii_min_7542 = (int)*(((s1_ptr)_2)->base + 7);
    if (!IS_ATOM_INT(_26pretty_ascii_min_7542))
    _26pretty_ascii_min_7542 = (long)DBL_PTR(_26pretty_ascii_min_7542)->dbl;

    /** 	pretty_ascii_max = options[MAX_ASCII]*/
    _2 = (int)SEQ_PTR(_options_7711);
    _26pretty_ascii_max_7543 = (int)*(((s1_ptr)_2)->base + 8);
    if (!IS_ATOM_INT(_26pretty_ascii_max_7543))
    _26pretty_ascii_max_7543 = (long)DBL_PTR(_26pretty_ascii_max_7543)->dbl;

    /** 	pretty_line_max = options[MAX_LINES]*/
    _2 = (int)SEQ_PTR(_options_7711);
    _26pretty_line_max_7545 = (int)*(((s1_ptr)_2)->base + 9);
    if (!IS_ATOM_INT(_26pretty_line_max_7545))
    _26pretty_line_max_7545 = (long)DBL_PTR(_26pretty_line_max_7545)->dbl;

    /** 	pretty_line_breaks = options[LINE_BREAKS]*/
    _2 = (int)SEQ_PTR(_options_7711);
    _26pretty_line_breaks_7547 = (int)*(((s1_ptr)_2)->base + 10);
    if (!IS_ATOM_INT(_26pretty_line_breaks_7547))
    _26pretty_line_breaks_7547 = (long)DBL_PTR(_26pretty_line_breaks_7547)->dbl;

    /** 	pretty_chars = pretty_start_col*/
    _26pretty_chars_7536 = _26pretty_start_col_7537;

    /** 	pretty_level = 0 */
    _26pretty_level_7538 = 0;

    /** 	pretty_line = ""*/
    RefDS(_5);
    DeRef(_26pretty_line_7551);
    _26pretty_line_7551 = _5;

    /** 	pretty_line_count = 0*/
    _26pretty_line_count_7544 = 0;

    /** 	pretty_dots = 0*/
    _26pretty_dots_7546 = 0;

    /** 	rPrint(x)*/
    Ref(_x_7710);
    _26rPrint(_x_7710);

    /** end procedure*/
    DeRef(_x_7710);
    DeRefDS(_options_7711);
    return;
    ;
}



// 0xDF15C4C0
