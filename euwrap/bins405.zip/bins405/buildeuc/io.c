// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int _8get_bytes(int _fn_9797, int _n_9798)
{
    int _s_9799 = NOVALUE;
    int _c_9800 = NOVALUE;
    int _first_9801 = NOVALUE;
    int _last_9802 = NOVALUE;
    int _5511 = NOVALUE;
    int _5508 = NOVALUE;
    int _5506 = NOVALUE;
    int _5505 = NOVALUE;
    int _5504 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_n_9798)) {
        _1 = (long)(DBL_PTR(_n_9798)->dbl);
        DeRefDS(_n_9798);
        _n_9798 = _1;
    }

    /** 	if n = 0 then*/
    if (_n_9798 != 0)
    goto L1; // [7] 18

    /** 		return {}*/
    RefDS(_5);
    DeRefi(_s_9799);
    return _5;
L1: 

    /** 	c = getc(fn)*/
    if (_fn_9797 != last_r_file_no) {
        last_r_file_ptr = which_file(_fn_9797, EF_READ);
        last_r_file_no = _fn_9797;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _c_9800 = getKBchar();
        }
        else
        _c_9800 = getc(last_r_file_ptr);
    }
    else
    _c_9800 = getc(last_r_file_ptr);

    /** 	if c = EOF then*/
    if (_c_9800 != -1)
    goto L2; // [25] 36

    /** 		return {}*/
    RefDS(_5);
    DeRefi(_s_9799);
    return _5;
L2: 

    /** 	s = repeat(c, n)*/
    DeRefi(_s_9799);
    _s_9799 = Repeat(_c_9800, _n_9798);

    /** 	last = 1*/
    _last_9802 = 1;

    /** 	while last < n do*/
L3: 
    if (_last_9802 >= _n_9798)
    goto L4; // [52] 159

    /** 		first = last+1*/
    _first_9801 = _last_9802 + 1;

    /** 		last  = last+CHUNK*/
    _last_9802 = _last_9802 + 100;

    /** 		if last > n then*/
    if (_last_9802 <= _n_9798)
    goto L5; // [70] 80

    /** 			last = n*/
    _last_9802 = _n_9798;
L5: 

    /** 		for i = first to last do*/
    _5504 = _last_9802;
    {
        int _i_9816;
        _i_9816 = _first_9801;
L6: 
        if (_i_9816 > _5504){
            goto L7; // [85] 108
        }

        /** 			s[i] = getc(fn)*/
        if (_fn_9797 != last_r_file_no) {
            last_r_file_ptr = which_file(_fn_9797, EF_READ);
            last_r_file_no = _fn_9797;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _5505 = getKBchar();
            }
            else
            _5505 = getc(last_r_file_ptr);
        }
        else
        _5505 = getc(last_r_file_ptr);
        _2 = (int)SEQ_PTR(_s_9799);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _s_9799 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_9816);
        *(int *)_2 = _5505;
        if( _1 != _5505 ){
        }
        _5505 = NOVALUE;

        /** 		end for*/
        _i_9816 = _i_9816 + 1;
        goto L6; // [103] 92
L7: 
        ;
    }

    /** 		if s[last] = EOF then*/
    _2 = (int)SEQ_PTR(_s_9799);
    _5506 = (int)*(((s1_ptr)_2)->base + _last_9802);
    if (_5506 != -1)
    goto L3; // [114] 52

    /** 			while s[last] = EOF do*/
L8: 
    _2 = (int)SEQ_PTR(_s_9799);
    _5508 = (int)*(((s1_ptr)_2)->base + _last_9802);
    if (_5508 != -1)
    goto L9; // [127] 142

    /** 				last -= 1*/
    _last_9802 = _last_9802 - 1;

    /** 			end while*/
    goto L8; // [139] 123
L9: 

    /** 			return s[1..last]*/
    rhs_slice_target = (object_ptr)&_5511;
    RHS_Slice(_s_9799, 1, _last_9802);
    DeRefDSi(_s_9799);
    _5506 = NOVALUE;
    _5508 = NOVALUE;
    return _5511;

    /** 	end while*/
    goto L3; // [156] 52
L4: 

    /** 	return s*/
    _5506 = NOVALUE;
    _5508 = NOVALUE;
    DeRef(_5511);
    _5511 = NOVALUE;
    return _s_9799;
    ;
}


int _8get_integer32(int _fh_9837)
{
    int _5520 = NOVALUE;
    int _5519 = NOVALUE;
    int _5518 = NOVALUE;
    int _5517 = NOVALUE;
    int _5516 = NOVALUE;
    int _0, _1, _2;
    

    /** 	poke(mem0, getc(fh))*/
    if (_fh_9837 != last_r_file_no) {
        last_r_file_ptr = which_file(_fh_9837, EF_READ);
        last_r_file_no = _fh_9837;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _5516 = getKBchar();
        }
        else
        _5516 = getc(last_r_file_ptr);
    }
    else
    _5516 = getc(last_r_file_ptr);
    if (IS_ATOM_INT(_8mem0_9827)){
        poke_addr = (unsigned char *)_8mem0_9827;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_8mem0_9827)->dbl);
    }
    *poke_addr = (unsigned char)_5516;
    _5516 = NOVALUE;

    /** 	poke(mem1, getc(fh))*/
    if (_fh_9837 != last_r_file_no) {
        last_r_file_ptr = which_file(_fh_9837, EF_READ);
        last_r_file_no = _fh_9837;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _5517 = getKBchar();
        }
        else
        _5517 = getc(last_r_file_ptr);
    }
    else
    _5517 = getc(last_r_file_ptr);
    if (IS_ATOM_INT(_8mem1_9828)){
        poke_addr = (unsigned char *)_8mem1_9828;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_8mem1_9828)->dbl);
    }
    *poke_addr = (unsigned char)_5517;
    _5517 = NOVALUE;

    /** 	poke(mem2, getc(fh))*/
    if (_fh_9837 != last_r_file_no) {
        last_r_file_ptr = which_file(_fh_9837, EF_READ);
        last_r_file_no = _fh_9837;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _5518 = getKBchar();
        }
        else
        _5518 = getc(last_r_file_ptr);
    }
    else
    _5518 = getc(last_r_file_ptr);
    if (IS_ATOM_INT(_8mem2_9829)){
        poke_addr = (unsigned char *)_8mem2_9829;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_8mem2_9829)->dbl);
    }
    *poke_addr = (unsigned char)_5518;
    _5518 = NOVALUE;

    /** 	poke(mem3, getc(fh))*/
    if (_fh_9837 != last_r_file_no) {
        last_r_file_ptr = which_file(_fh_9837, EF_READ);
        last_r_file_no = _fh_9837;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _5519 = getKBchar();
        }
        else
        _5519 = getc(last_r_file_ptr);
    }
    else
    _5519 = getc(last_r_file_ptr);
    if (IS_ATOM_INT(_8mem3_9830)){
        poke_addr = (unsigned char *)_8mem3_9830;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_8mem3_9830)->dbl);
    }
    *poke_addr = (unsigned char)_5519;
    _5519 = NOVALUE;

    /** 	return peek4u(mem0)*/
    if (IS_ATOM_INT(_8mem0_9827)) {
        _5520 = *(unsigned long *)_8mem0_9827;
        if ((unsigned)_5520 > (unsigned)MAXINT)
        _5520 = NewDouble((double)(unsigned long)_5520);
    }
    else {
        _5520 = *(unsigned long *)(unsigned long)(DBL_PTR(_8mem0_9827)->dbl);
        if ((unsigned)_5520 > (unsigned)MAXINT)
        _5520 = NewDouble((double)(unsigned long)_5520);
    }
    return _5520;
    ;
}


int _8get_integer16(int _fh_9845)
{
    int _5523 = NOVALUE;
    int _5522 = NOVALUE;
    int _5521 = NOVALUE;
    int _0, _1, _2;
    

    /** 	poke(mem0, getc(fh))*/
    if (_fh_9845 != last_r_file_no) {
        last_r_file_ptr = which_file(_fh_9845, EF_READ);
        last_r_file_no = _fh_9845;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _5521 = getKBchar();
        }
        else
        _5521 = getc(last_r_file_ptr);
    }
    else
    _5521 = getc(last_r_file_ptr);
    if (IS_ATOM_INT(_8mem0_9827)){
        poke_addr = (unsigned char *)_8mem0_9827;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_8mem0_9827)->dbl);
    }
    *poke_addr = (unsigned char)_5521;
    _5521 = NOVALUE;

    /** 	poke(mem1, getc(fh))*/
    if (_fh_9845 != last_r_file_no) {
        last_r_file_ptr = which_file(_fh_9845, EF_READ);
        last_r_file_no = _fh_9845;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _5522 = getKBchar();
        }
        else
        _5522 = getc(last_r_file_ptr);
    }
    else
    _5522 = getc(last_r_file_ptr);
    if (IS_ATOM_INT(_8mem1_9828)){
        poke_addr = (unsigned char *)_8mem1_9828;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_8mem1_9828)->dbl);
    }
    *poke_addr = (unsigned char)_5522;
    _5522 = NOVALUE;

    /** 	return peek2u(mem0)*/
    if (IS_ATOM_INT(_8mem0_9827)) {
        _5523 = *(unsigned short *)_8mem0_9827;
    }
    else {
        _5523 = *(unsigned short *)(unsigned long)(DBL_PTR(_8mem0_9827)->dbl);
    }
    return _5523;
    ;
}


int _8seek(int _fn_9938, int _pos_9939)
{
    int _5569 = NOVALUE;
    int _5568 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_9939);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _fn_9938;
    ((int *)_2)[2] = _pos_9939;
    _5568 = MAKE_SEQ(_1);
    _5569 = machine(19, _5568);
    DeRefDS(_5568);
    _5568 = NOVALUE;
    DeRef(_pos_9939);
    return _5569;
    ;
}


int _8where(int _fn_9944)
{
    int _5570 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return machine_func(M_WHERE, fn)*/
    _5570 = machine(20, _fn_9944);
    return _5570;
    ;
}


int _8read_lines(int _file_9963)
{
    int _fn_9964 = NOVALUE;
    int _ret_9965 = NOVALUE;
    int _y_9966 = NOVALUE;
    int _5592 = NOVALUE;
    int _5591 = NOVALUE;
    int _5590 = NOVALUE;
    int _5589 = NOVALUE;
    int _5584 = NOVALUE;
    int _5583 = NOVALUE;
    int _5581 = NOVALUE;
    int _5580 = NOVALUE;
    int _5579 = NOVALUE;
    int _5575 = NOVALUE;
    int _5574 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if sequence(file) then*/
    _5574 = 1;
    if (_5574 == 0)
    {
        _5574 = NOVALUE;
        goto L1; // [6] 37
    }
    else{
        _5574 = NOVALUE;
    }

    /** 		if length(file) = 0 then*/
    if (IS_SEQUENCE(_file_9963)){
            _5575 = SEQ_PTR(_file_9963)->length;
    }
    else {
        _5575 = 1;
    }
    if (_5575 != 0)
    goto L2; // [14] 26

    /** 			fn = 0*/
    DeRef(_fn_9964);
    _fn_9964 = 0;
    goto L3; // [23] 43
L2: 

    /** 			fn = open(file, "r")*/
    DeRef(_fn_9964);
    _fn_9964 = EOpen(_file_9963, _3889, 0);
    goto L3; // [34] 43
L1: 

    /** 		fn = file*/
    Ref(_file_9963);
    DeRef(_fn_9964);
    _fn_9964 = _file_9963;
L3: 

    /** 	if fn < 0 then return -1 end if*/
    if (binary_op_a(GREATEREQ, _fn_9964, 0)){
        goto L4; // [47] 56
    }
    DeRef(_file_9963);
    DeRef(_fn_9964);
    DeRef(_ret_9965);
    DeRefi(_y_9966);
    return -1;
L4: 

    /** 	ret = {}*/
    RefDS(_5);
    DeRef(_ret_9965);
    _ret_9965 = _5;

    /** 	while sequence(y) with entry do*/
    goto L5; // [63] 125
L6: 
    _5579 = IS_SEQUENCE(_y_9966);
    if (_5579 == 0)
    {
        _5579 = NOVALUE;
        goto L7; // [71] 135
    }
    else{
        _5579 = NOVALUE;
    }

    /** 		if y[$] = '\n' then*/
    if (IS_SEQUENCE(_y_9966)){
            _5580 = SEQ_PTR(_y_9966)->length;
    }
    else {
        _5580 = 1;
    }
    _2 = (int)SEQ_PTR(_y_9966);
    _5581 = (int)*(((s1_ptr)_2)->base + _5580);
    if (_5581 != 10)
    goto L8; // [83] 104

    /** 			y = y[1..$-1]*/
    if (IS_SEQUENCE(_y_9966)){
            _5583 = SEQ_PTR(_y_9966)->length;
    }
    else {
        _5583 = 1;
    }
    _5584 = _5583 - 1;
    _5583 = NOVALUE;
    rhs_slice_target = (object_ptr)&_y_9966;
    RHS_Slice(_y_9966, 1, _5584);

    /** 			ifdef UNIX then*/
L8: 

    /** 		ret = append(ret, y)*/
    Ref(_y_9966);
    Append(&_ret_9965, _ret_9965, _y_9966);

    /** 		if fn = 0 then*/
    if (binary_op_a(NOTEQ, _fn_9964, 0)){
        goto L9; // [112] 122
    }

    /** 			puts(2, '\n')*/
    EPuts(2, 10); // DJP 
L9: 

    /** 	entry*/
L5: 

    /** 		y = gets(fn)*/
    DeRefi(_y_9966);
    _y_9966 = EGets(_fn_9964);

    /** 	end while*/
    goto L6; // [132] 66
L7: 

    /** 	if sequence(file) and length(file) != 0 then*/
    _5589 = IS_SEQUENCE(_file_9963);
    if (_5589 == 0) {
        goto LA; // [140] 160
    }
    if (IS_SEQUENCE(_file_9963)){
            _5591 = SEQ_PTR(_file_9963)->length;
    }
    else {
        _5591 = 1;
    }
    _5592 = (_5591 != 0);
    _5591 = NOVALUE;
    if (_5592 == 0)
    {
        DeRef(_5592);
        _5592 = NOVALUE;
        goto LA; // [152] 160
    }
    else{
        DeRef(_5592);
        _5592 = NOVALUE;
    }

    /** 		close(fn)*/
    if (IS_ATOM_INT(_fn_9964))
    EClose(_fn_9964);
    else
    EClose((int)DBL_PTR(_fn_9964)->dbl);
LA: 

    /** 	return ret*/
    DeRef(_file_9963);
    DeRef(_fn_9964);
    DeRefi(_y_9966);
    _5581 = NOVALUE;
    DeRef(_5584);
    _5584 = NOVALUE;
    return _ret_9965;
    ;
}


int _8write_lines(int _file_10039, int _lines_10040)
{
    int _fn_10041 = NOVALUE;
    int _5622 = NOVALUE;
    int _5621 = NOVALUE;
    int _5620 = NOVALUE;
    int _5616 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if sequence(file) then*/
    _5616 = 1;
    if (_5616 == 0)
    {
        _5616 = NOVALUE;
        goto L1; // [8] 21
    }
    else{
        _5616 = NOVALUE;
    }

    /**     	fn = open(file, "w")*/
    DeRef(_fn_10041);
    _fn_10041 = EOpen(_file_10039, _5617, 0);
    goto L2; // [18] 27
L1: 

    /** 		fn = file*/
    Ref(_file_10039);
    DeRef(_fn_10041);
    _fn_10041 = _file_10039;
L2: 

    /** 	if fn < 0 then return -1 end if*/
    if (binary_op_a(GREATEREQ, _fn_10041, 0)){
        goto L3; // [31] 40
    }
    DeRef(_file_10039);
    DeRefDS(_lines_10040);
    DeRef(_fn_10041);
    return -1;
L3: 

    /** 	for i = 1 to length(lines) do*/
    if (IS_SEQUENCE(_lines_10040)){
            _5620 = SEQ_PTR(_lines_10040)->length;
    }
    else {
        _5620 = 1;
    }
    {
        int _i_10050;
        _i_10050 = 1;
L4: 
        if (_i_10050 > _5620){
            goto L5; // [45] 73
        }

        /** 		puts(fn, lines[i])*/
        _2 = (int)SEQ_PTR(_lines_10040);
        _5621 = (int)*(((s1_ptr)_2)->base + _i_10050);
        EPuts(_fn_10041, _5621); // DJP 
        _5621 = NOVALUE;

        /** 		puts(fn, '\n')*/
        EPuts(_fn_10041, 10); // DJP 

        /** 	end for*/
        _i_10050 = _i_10050 + 1;
        goto L4; // [68] 52
L5: 
        ;
    }

    /** 	if sequence(file) then*/
    _5622 = IS_SEQUENCE(_file_10039);
    if (_5622 == 0)
    {
        _5622 = NOVALUE;
        goto L6; // [78] 86
    }
    else{
        _5622 = NOVALUE;
    }

    /** 		close(fn)*/
    if (IS_ATOM_INT(_fn_10041))
    EClose(_fn_10041);
    else
    EClose((int)DBL_PTR(_fn_10041)->dbl);
L6: 

    /** 	return 1*/
    DeRef(_file_10039);
    DeRefDS(_lines_10040);
    DeRef(_fn_10041);
    return 1;
    ;
}


int _8write_file(int _file_10126, int _data_10127, int _as_text_10128)
{
    int _fn_10129 = NOVALUE;
    int _5672 = NOVALUE;
    int _5667 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if as_text != BINARY_MODE then*/

    /** 	if sequence(file) then*/
    _5667 = 1;
    if (_5667 == 0)
    {
        _5667 = NOVALUE;
        goto L1; // [151] 181
    }
    else{
        _5667 = NOVALUE;
    }

    /** 		if as_text = TEXT_MODE then*/

    /** 			fn = open(file, "wb")*/
    _fn_10129 = EOpen(_file_10126, _3215, 0);
    goto L2; // [178] 189
L1: 

    /** 		fn = file*/
    Ref(_file_10126);
    _fn_10129 = _file_10126;
    if (!IS_ATOM_INT(_fn_10129)) {
        _1 = (long)(DBL_PTR(_fn_10129)->dbl);
        DeRefDS(_fn_10129);
        _fn_10129 = _1;
    }
L2: 

    /** 	if fn < 0 then return -1 end if*/
    if (_fn_10129 >= 0)
    goto L3; // [193] 202
    DeRefi(_file_10126);
    DeRefDS(_data_10127);
    return -1;
L3: 

    /** 	puts(fn, data)*/
    EPuts(_fn_10129, _data_10127); // DJP 

    /** 	if sequence(file) then*/
    _5672 = IS_SEQUENCE(_file_10126);
    if (_5672 == 0)
    {
        _5672 = NOVALUE;
        goto L4; // [212] 220
    }
    else{
        _5672 = NOVALUE;
    }

    /** 		close(fn)*/
    EClose(_fn_10129);
L4: 

    /** 	return 1*/
    DeRefi(_file_10126);
    DeRefDS(_data_10127);
    return 1;
    ;
}


void _8writef(int _fm_10169, int _data_10170, int _fn_10171, int _data_not_string_10172)
{
    int _real_fn_10173 = NOVALUE;
    int _close_fn_10174 = NOVALUE;
    int _out_style_10175 = NOVALUE;
    int _ts_10178 = NOVALUE;
    int _msg_inlined_crash_at_163_10203 = NOVALUE;
    int _data_inlined_crash_at_160_10202 = NOVALUE;
    int _5692 = NOVALUE;
    int _5690 = NOVALUE;
    int _5689 = NOVALUE;
    int _5688 = NOVALUE;
    int _5682 = NOVALUE;
    int _5681 = NOVALUE;
    int _5680 = NOVALUE;
    int _5679 = NOVALUE;
    int _5678 = NOVALUE;
    int _5677 = NOVALUE;
    int _5675 = NOVALUE;
    int _5674 = NOVALUE;
    int _5673 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer real_fn = 0*/
    _real_fn_10173 = 0;

    /** 	integer close_fn = 0*/
    _close_fn_10174 = 0;

    /** 	sequence out_style = "w"*/
    RefDS(_5617);
    DeRefi(_out_style_10175);
    _out_style_10175 = _5617;

    /** 	if integer(fm) then*/
    _5673 = 1;
    if (_5673 == 0)
    {
        _5673 = NOVALUE;
        goto L1; // [23] 49
    }
    else{
        _5673 = NOVALUE;
    }

    /** 		object ts*/

    /** 		ts = fm*/
    _ts_10178 = _fm_10169;

    /** 		fm = data*/
    RefDS(_data_10170);
    _fm_10169 = _data_10170;

    /** 		data = fn*/
    RefDS(_fn_10171);
    DeRefDS(_data_10170);
    _data_10170 = _fn_10171;

    /** 		fn = ts*/
    DeRefDS(_fn_10171);
    _fn_10171 = _ts_10178;
L1: 

    /** 	if sequence(fn) then*/
    _5674 = IS_SEQUENCE(_fn_10171);
    if (_5674 == 0)
    {
        _5674 = NOVALUE;
        goto L2; // [56] 191
    }
    else{
        _5674 = NOVALUE;
    }

    /** 		if length(fn) = 2 then*/
    if (IS_SEQUENCE(_fn_10171)){
            _5675 = SEQ_PTR(_fn_10171)->length;
    }
    else {
        _5675 = 1;
    }
    if (_5675 != 2)
    goto L3; // [64] 142

    /** 			if sequence(fn[1]) then*/
    _2 = (int)SEQ_PTR(_fn_10171);
    _5677 = (int)*(((s1_ptr)_2)->base + 1);
    _5678 = IS_SEQUENCE(_5677);
    _5677 = NOVALUE;
    if (_5678 == 0)
    {
        _5678 = NOVALUE;
        goto L4; // [77] 141
    }
    else{
        _5678 = NOVALUE;
    }

    /** 				if equal(fn[2], 'a') then*/
    _2 = (int)SEQ_PTR(_fn_10171);
    _5679 = (int)*(((s1_ptr)_2)->base + 2);
    if (_5679 == 97)
    _5680 = 1;
    else if (IS_ATOM_INT(_5679) && IS_ATOM_INT(97))
    _5680 = 0;
    else
    _5680 = (compare(_5679, 97) == 0);
    _5679 = NOVALUE;
    if (_5680 == 0)
    {
        _5680 = NOVALUE;
        goto L5; // [90] 103
    }
    else{
        _5680 = NOVALUE;
    }

    /** 					out_style = "a"*/
    RefDS(_5623);
    DeRefi(_out_style_10175);
    _out_style_10175 = _5623;
    goto L6; // [100] 134
L5: 

    /** 				elsif not equal(fn[2], "a") then*/
    _2 = (int)SEQ_PTR(_fn_10171);
    _5681 = (int)*(((s1_ptr)_2)->base + 2);
    if (_5681 == _5623)
    _5682 = 1;
    else if (IS_ATOM_INT(_5681) && IS_ATOM_INT(_5623))
    _5682 = 0;
    else
    _5682 = (compare(_5681, _5623) == 0);
    _5681 = NOVALUE;
    if (_5682 != 0)
    goto L7; // [113] 126
    _5682 = NOVALUE;

    /** 					out_style = "w"*/
    RefDS(_5617);
    DeRefi(_out_style_10175);
    _out_style_10175 = _5617;
    goto L6; // [123] 134
L7: 

    /** 					out_style = "a"*/
    RefDS(_5623);
    DeRefi(_out_style_10175);
    _out_style_10175 = _5623;
L6: 

    /** 				fn = fn[1]*/
    _0 = _fn_10171;
    _2 = (int)SEQ_PTR(_fn_10171);
    _fn_10171 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_fn_10171);
    DeRef(_0);
L4: 
L3: 

    /** 		real_fn = open(fn, out_style)*/
    _real_fn_10173 = EOpen(_fn_10171, _out_style_10175, 0);

    /** 		if real_fn = -1 then*/
    if (_real_fn_10173 != -1)
    goto L8; // [151] 183

    /** 			error:crash("Unable to write to '%s'", {fn})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_fn_10171);
    *((int *)(_2+4)) = _fn_10171;
    _5688 = MAKE_SEQ(_1);
    DeRef(_data_inlined_crash_at_160_10202);
    _data_inlined_crash_at_160_10202 = _5688;
    _5688 = NOVALUE;

    /** 	msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_163_10203);
    _msg_inlined_crash_at_163_10203 = EPrintf(-9999999, _5687, _data_inlined_crash_at_160_10202);

    /** 	machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_163_10203);

    /** end procedure*/
    goto L9; // [177] 180
L9: 
    DeRef(_data_inlined_crash_at_160_10202);
    _data_inlined_crash_at_160_10202 = NOVALUE;
    DeRefi(_msg_inlined_crash_at_163_10203);
    _msg_inlined_crash_at_163_10203 = NOVALUE;
L8: 

    /** 		close_fn = 1*/
    _close_fn_10174 = 1;
    goto LA; // [188] 199
L2: 

    /** 		real_fn = fn*/
    Ref(_fn_10171);
    _real_fn_10173 = _fn_10171;
    if (!IS_ATOM_INT(_real_fn_10173)) {
        _1 = (long)(DBL_PTR(_real_fn_10173)->dbl);
        DeRefDS(_real_fn_10173);
        _real_fn_10173 = _1;
    }
LA: 

    /** 	if equal(data_not_string, 0) then*/
    if (_data_not_string_10172 == 0)
    _5689 = 1;
    else if (IS_ATOM_INT(_data_not_string_10172) && IS_ATOM_INT(0))
    _5689 = 0;
    else
    _5689 = (compare(_data_not_string_10172, 0) == 0);
    if (_5689 == 0)
    {
        _5689 = NOVALUE;
        goto LB; // [205] 225
    }
    else{
        _5689 = NOVALUE;
    }

    /** 		if types:t_display(data) then*/
    Ref(_data_10170);
    _5690 = _13t_display(_data_10170);
    if (_5690 == 0) {
        DeRef(_5690);
        _5690 = NOVALUE;
        goto LC; // [214] 224
    }
    else {
        if (!IS_ATOM_INT(_5690) && DBL_PTR(_5690)->dbl == 0.0){
            DeRef(_5690);
            _5690 = NOVALUE;
            goto LC; // [214] 224
        }
        DeRef(_5690);
        _5690 = NOVALUE;
    }
    DeRef(_5690);
    _5690 = NOVALUE;

    /** 			data = {data}*/
    _0 = _data_10170;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_data_10170);
    *((int *)(_2+4)) = _data_10170;
    _data_10170 = MAKE_SEQ(_1);
    DeRef(_0);
LC: 
LB: 

    /**     puts(real_fn, text:format( fm, data ) )*/
    Ref(_fm_10169);
    Ref(_data_10170);
    _5692 = _14format(_fm_10169, _data_10170);
    EPuts(_real_fn_10173, _5692); // DJP 
    DeRef(_5692);
    _5692 = NOVALUE;

    /**     if close_fn then*/
    if (_close_fn_10174 == 0)
    {
        goto LD; // [237] 245
    }
    else{
    }

    /**     	close(real_fn)*/
    EClose(_real_fn_10173);
LD: 

    /** end procedure*/
    DeRef(_fm_10169);
    DeRef(_data_10170);
    DeRef(_fn_10171);
    DeRefi(_out_style_10175);
    return;
    ;
}



// 0x9A880ACB
