// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

void _41Push(int _x_50477)
{
    int _26431 = NOVALUE;
    int _26429 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_x_50477)) {
        _1 = (long)(DBL_PTR(_x_50477)->dbl);
        DeRefDS(_x_50477);
        _x_50477 = _1;
    }

    /** 	cgi += 1*/
    _41cgi_50238 = _41cgi_50238 + 1;

    /** 	if cgi > length(cg_stack) then*/
    if (IS_SEQUENCE(_41cg_stack_50237)){
            _26429 = SEQ_PTR(_41cg_stack_50237)->length;
    }
    else {
        _26429 = 1;
    }
    if (_41cgi_50238 <= _26429)
    goto L1; // [20] 37

    /** 		cg_stack &= repeat(0, 400)*/
    _26431 = Repeat(0, 400);
    Concat((object_ptr)&_41cg_stack_50237, _41cg_stack_50237, _26431);
    DeRefDS(_26431);
    _26431 = NOVALUE;
L1: 

    /** 	cg_stack[cgi] = x*/
    _2 = (int)SEQ_PTR(_41cg_stack_50237);
    _2 = (int)(((s1_ptr)_2)->base + _41cgi_50238);
    _1 = *(int *)_2;
    *(int *)_2 = _x_50477;
    DeRef(_1);

    /** end procedure*/
    return;
    ;
}


int _41Top()
{
    int _26433 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return cg_stack[cgi]*/
    _2 = (int)SEQ_PTR(_41cg_stack_50237);
    _26433 = (int)*(((s1_ptr)_2)->base + _41cgi_50238);
    Ref(_26433);
    return _26433;
    ;
}


int _41Pop()
{
    int _t_50490 = NOVALUE;
    int _s_50496 = NOVALUE;
    int _26445 = NOVALUE;
    int _26443 = NOVALUE;
    int _26441 = NOVALUE;
    int _26438 = NOVALUE;
    int _26437 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	t = cg_stack[cgi]*/
    _2 = (int)SEQ_PTR(_41cg_stack_50237);
    _t_50490 = (int)*(((s1_ptr)_2)->base + _41cgi_50238);
    if (!IS_ATOM_INT(_t_50490)){
        _t_50490 = (long)DBL_PTR(_t_50490)->dbl;
    }

    /** 	cgi -= 1*/
    _41cgi_50238 = _41cgi_50238 - 1;

    /** 	if t > 0 then*/
    if (_t_50490 <= 0)
    goto L1; // [23] 116

    /** 		symtab_index s = t -- for type checking*/
    _s_50496 = _t_50490;

    /** 		if SymTab[t][S_MODE] = M_TEMP then*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _26437 = (int)*(((s1_ptr)_2)->base + _t_50490);
    _2 = (int)SEQ_PTR(_26437);
    _26438 = (int)*(((s1_ptr)_2)->base + 3);
    _26437 = NOVALUE;
    if (binary_op_a(NOTEQ, _26438, 3)){
        _26438 = NOVALUE;
        goto L2; // [50] 115
    }
    _26438 = NOVALUE;

    /** 			if use_private_list = 0 then  -- no problem with reusing the temp*/
    if (_35use_private_list_16357 != 0)
    goto L3; // [58] 82

    /** 				SymTab[t][S_SCOPE] = FREE -- mark it as being free*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_t_50490 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _26441 = NOVALUE;
    goto L4; // [79] 114
L3: 

    /** 			elsif find(t, private_sym) = 0 then*/
    _26443 = find_from(_t_50490, _35private_sym_16356, 1);
    if (_26443 != 0)
    goto L5; // [91] 113

    /** 				SymTab[t][S_SCOPE] = FREE -- mark it as being free*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_t_50490 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _26445 = NOVALUE;
L5: 
L4: 
L2: 
L1: 

    /** 	return t*/
    return _t_50490;
    ;
}


void _41TempKeep(int _x_50524)
{
    int _26452 = NOVALUE;
    int _26451 = NOVALUE;
    int _26450 = NOVALUE;
    int _26449 = NOVALUE;
    int _26448 = NOVALUE;
    int _26447 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_x_50524)) {
        _1 = (long)(DBL_PTR(_x_50524)->dbl);
        DeRefDS(_x_50524);
        _x_50524 = _1;
    }

    /** 	if x > 0 and SymTab[x][S_MODE] = M_TEMP then*/
    _26447 = (_x_50524 > 0);
    if (_26447 == 0) {
        goto L1; // [9] 53
    }
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _26449 = (int)*(((s1_ptr)_2)->base + _x_50524);
    _2 = (int)SEQ_PTR(_26449);
    _26450 = (int)*(((s1_ptr)_2)->base + 3);
    _26449 = NOVALUE;
    if (IS_ATOM_INT(_26450)) {
        _26451 = (_26450 == 3);
    }
    else {
        _26451 = binary_op(EQUALS, _26450, 3);
    }
    _26450 = NOVALUE;
    if (_26451 == 0) {
        DeRef(_26451);
        _26451 = NOVALUE;
        goto L1; // [32] 53
    }
    else {
        if (!IS_ATOM_INT(_26451) && DBL_PTR(_26451)->dbl == 0.0){
            DeRef(_26451);
            _26451 = NOVALUE;
            goto L1; // [32] 53
        }
        DeRef(_26451);
        _26451 = NOVALUE;
    }
    DeRef(_26451);
    _26451 = NOVALUE;

    /** 		SymTab[x][S_SCOPE] = IN_USE*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_x_50524 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = 1;
    DeRef(_1);
    _26452 = NOVALUE;
L1: 

    /** end procedure*/
    DeRef(_26447);
    _26447 = NOVALUE;
    return;
    ;
}


void _41TempFree(int _x_50542)
{
    int _26458 = NOVALUE;
    int _26456 = NOVALUE;
    int _26455 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_x_50542)) {
        _1 = (long)(DBL_PTR(_x_50542)->dbl);
        DeRefDS(_x_50542);
        _x_50542 = _1;
    }

    /** 	if x > 0 then*/
    if (_x_50542 <= 0)
    goto L1; // [5] 53

    /** 		if SymTab[x][S_MODE] = M_TEMP then*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _26455 = (int)*(((s1_ptr)_2)->base + _x_50542);
    _2 = (int)SEQ_PTR(_26455);
    _26456 = (int)*(((s1_ptr)_2)->base + 3);
    _26455 = NOVALUE;
    if (binary_op_a(NOTEQ, _26456, 3)){
        _26456 = NOVALUE;
        goto L2; // [25] 52
    }
    _26456 = NOVALUE;

    /** 			SymTab[x][S_SCOPE] = FREE*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_x_50542 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _26458 = NOVALUE;

    /** 			clear_temp( x )*/
    _41clear_temp(_x_50542);
L2: 
L1: 

    /** end procedure*/
    return;
    ;
}


void _41TempInteger(int _x_50561)
{
    int _26465 = NOVALUE;
    int _26464 = NOVALUE;
    int _26463 = NOVALUE;
    int _26462 = NOVALUE;
    int _26461 = NOVALUE;
    int _26460 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_x_50561)) {
        _1 = (long)(DBL_PTR(_x_50561)->dbl);
        DeRefDS(_x_50561);
        _x_50561 = _1;
    }

    /** 	if x > 0 and SymTab[x][S_MODE] = M_TEMP then*/
    _26460 = (_x_50561 > 0);
    if (_26460 == 0) {
        goto L1; // [9] 53
    }
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _26462 = (int)*(((s1_ptr)_2)->base + _x_50561);
    _2 = (int)SEQ_PTR(_26462);
    _26463 = (int)*(((s1_ptr)_2)->base + 3);
    _26462 = NOVALUE;
    if (IS_ATOM_INT(_26463)) {
        _26464 = (_26463 == 3);
    }
    else {
        _26464 = binary_op(EQUALS, _26463, 3);
    }
    _26463 = NOVALUE;
    if (_26464 == 0) {
        DeRef(_26464);
        _26464 = NOVALUE;
        goto L1; // [32] 53
    }
    else {
        if (!IS_ATOM_INT(_26464) && DBL_PTR(_26464)->dbl == 0.0){
            DeRef(_26464);
            _26464 = NOVALUE;
            goto L1; // [32] 53
        }
        DeRef(_26464);
        _26464 = NOVALUE;
    }
    DeRef(_26464);
    _26464 = NOVALUE;

    /** 		SymTab[x][S_USAGE] = T_INTEGER*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_x_50561 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = 1;
    DeRef(_1);
    _26465 = NOVALUE;
L1: 

    /** end procedure*/
    DeRef(_26460);
    _26460 = NOVALUE;
    return;
    ;
}


int _41LexName(int _t_50578, int _defname_50579)
{
    int _name_50581 = NOVALUE;
    int _26474 = NOVALUE;
    int _26472 = NOVALUE;
    int _26470 = NOVALUE;
    int _26469 = NOVALUE;
    int _26468 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_t_50578)) {
        _1 = (long)(DBL_PTR(_t_50578)->dbl);
        DeRefDS(_t_50578);
        _t_50578 = _1;
    }

    /** 	for i = 1 to length(token_name) do*/
    _26468 = 80;
    {
        int _i_50583;
        _i_50583 = 1;
L1: 
        if (_i_50583 > 80){
            goto L2; // [12] 82
        }

        /** 		if t = token_name[i][LEX_NUMBER] then*/
        _2 = (int)SEQ_PTR(_41token_name_50245);
        _26469 = (int)*(((s1_ptr)_2)->base + _i_50583);
        _2 = (int)SEQ_PTR(_26469);
        _26470 = (int)*(((s1_ptr)_2)->base + 1);
        _26469 = NOVALUE;
        if (binary_op_a(NOTEQ, _t_50578, _26470)){
            _26470 = NOVALUE;
            goto L3; // [31] 75
        }
        _26470 = NOVALUE;

        /** 			name = token_name[i][LEX_NAME]*/
        _2 = (int)SEQ_PTR(_41token_name_50245);
        _26472 = (int)*(((s1_ptr)_2)->base + _i_50583);
        DeRef(_name_50581);
        _2 = (int)SEQ_PTR(_26472);
        _name_50581 = (int)*(((s1_ptr)_2)->base + 2);
        Ref(_name_50581);
        _26472 = NOVALUE;

        /** 			if not find(' ', name) then*/
        _26474 = find_from(32, _name_50581, 1);
        if (_26474 != 0)
        goto L4; // [56] 68
        _26474 = NOVALUE;

        /** 				name = "'" & name & "'"*/
        {
            int concat_list[3];

            concat_list[0] = _26476;
            concat_list[1] = _name_50581;
            concat_list[2] = _26476;
            Concat_N((object_ptr)&_name_50581, concat_list, 3);
        }
L4: 

        /** 			return name*/
        DeRefDS(_defname_50579);
        return _name_50581;
L3: 

        /** 	end for*/
        _i_50583 = _i_50583 + 1;
        goto L1; // [77] 19
L2: 
        ;
    }

    /** 	return defname -- try to avoid this case*/
    DeRef(_name_50581);
    return _defname_50579;
    ;
}


void _41InitEmit()
{
    int _0, _1, _2;
    

    /** 	cg_stack = repeat(0, 400)*/
    DeRef(_41cg_stack_50237);
    _41cg_stack_50237 = Repeat(0, 400);

    /** 	cgi = 0*/
    _41cgi_50238 = 0;

    /** end procedure*/
    return;
    ;
}


int _41IsInteger(int _sym_50602)
{
    int _mode_50603 = NOVALUE;
    int _t_50605 = NOVALUE;
    int _pt_50606 = NOVALUE;
    int _26499 = NOVALUE;
    int _26498 = NOVALUE;
    int _26496 = NOVALUE;
    int _26495 = NOVALUE;
    int _26494 = NOVALUE;
    int _26492 = NOVALUE;
    int _26491 = NOVALUE;
    int _26490 = NOVALUE;
    int _26489 = NOVALUE;
    int _26487 = NOVALUE;
    int _26483 = NOVALUE;
    int _26480 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_sym_50602)) {
        _1 = (long)(DBL_PTR(_sym_50602)->dbl);
        DeRefDS(_sym_50602);
        _sym_50602 = _1;
    }

    /** 	if sym < 1 then*/
    if (_sym_50602 >= 1)
    goto L1; // [5] 16

    /** 		return 0*/
    return 0;
L1: 

    /** 	mode = SymTab[sym][S_MODE]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _26480 = (int)*(((s1_ptr)_2)->base + _sym_50602);
    _2 = (int)SEQ_PTR(_26480);
    _mode_50603 = (int)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_mode_50603)){
        _mode_50603 = (long)DBL_PTR(_mode_50603)->dbl;
    }
    _26480 = NOVALUE;

    /** 	if mode = M_NORMAL then*/
    if (_mode_50603 != 1)
    goto L2; // [36] 136

    /** 		t = SymTab[sym][S_VTYPE]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _26483 = (int)*(((s1_ptr)_2)->base + _sym_50602);
    _2 = (int)SEQ_PTR(_26483);
    _t_50605 = (int)*(((s1_ptr)_2)->base + 15);
    if (!IS_ATOM_INT(_t_50605)){
        _t_50605 = (long)DBL_PTR(_t_50605)->dbl;
    }
    _26483 = NOVALUE;

    /** 		if t = integer_type then*/
    if (_t_50605 != _53integer_type_46097)
    goto L3; // [60] 73

    /** 			return TRUE*/
    return _13TRUE_436;
L3: 

    /** 		if t > 0 then*/
    if (_t_50605 <= 0)
    goto L4; // [75] 215

    /** 			pt = SymTab[t][S_NEXT]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _26487 = (int)*(((s1_ptr)_2)->base + _t_50605);
    _2 = (int)SEQ_PTR(_26487);
    _pt_50606 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_pt_50606)){
        _pt_50606 = (long)DBL_PTR(_pt_50606)->dbl;
    }
    _26487 = NOVALUE;

    /** 			if pt and SymTab[pt][S_VTYPE] = integer_type then*/
    if (_pt_50606 == 0) {
        goto L4; // [97] 215
    }
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _26490 = (int)*(((s1_ptr)_2)->base + _pt_50606);
    _2 = (int)SEQ_PTR(_26490);
    _26491 = (int)*(((s1_ptr)_2)->base + 15);
    _26490 = NOVALUE;
    if (IS_ATOM_INT(_26491)) {
        _26492 = (_26491 == _53integer_type_46097);
    }
    else {
        _26492 = binary_op(EQUALS, _26491, _53integer_type_46097);
    }
    _26491 = NOVALUE;
    if (_26492 == 0) {
        DeRef(_26492);
        _26492 = NOVALUE;
        goto L4; // [120] 215
    }
    else {
        if (!IS_ATOM_INT(_26492) && DBL_PTR(_26492)->dbl == 0.0){
            DeRef(_26492);
            _26492 = NOVALUE;
            goto L4; // [120] 215
        }
        DeRef(_26492);
        _26492 = NOVALUE;
    }
    DeRef(_26492);
    _26492 = NOVALUE;

    /** 				return TRUE   -- usertype(integer x)*/
    return _13TRUE_436;
    goto L4; // [133] 215
L2: 

    /** 	elsif mode = M_CONSTANT then*/
    if (_mode_50603 != 2)
    goto L5; // [140] 176

    /** 		if integer(SymTab[sym][S_OBJ]) then  -- bug fixed: can't allow PLUS1_I op*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _26494 = (int)*(((s1_ptr)_2)->base + _sym_50602);
    _2 = (int)SEQ_PTR(_26494);
    _26495 = (int)*(((s1_ptr)_2)->base + 1);
    _26494 = NOVALUE;
    if (IS_ATOM_INT(_26495))
    _26496 = 1;
    else if (IS_ATOM_DBL(_26495))
    _26496 = IS_ATOM_INT(DoubleToInt(_26495));
    else
    _26496 = 0;
    _26495 = NOVALUE;
    if (_26496 == 0)
    {
        _26496 = NOVALUE;
        goto L4; // [161] 215
    }
    else{
        _26496 = NOVALUE;
    }

    /** 			return TRUE*/
    return _13TRUE_436;
    goto L4; // [173] 215
L5: 

    /** 	elsif mode = M_TEMP then*/
    if (_mode_50603 != 3)
    goto L6; // [180] 214

    /** 		if SymTab[sym][S_USAGE] = T_INTEGER then*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _26498 = (int)*(((s1_ptr)_2)->base + _sym_50602);
    _2 = (int)SEQ_PTR(_26498);
    _26499 = (int)*(((s1_ptr)_2)->base + 5);
    _26498 = NOVALUE;
    if (binary_op_a(NOTEQ, _26499, 1)){
        _26499 = NOVALUE;
        goto L7; // [200] 213
    }
    _26499 = NOVALUE;

    /** 			return TRUE*/
    return _13TRUE_436;
L7: 
L6: 
L4: 

    /** 	return FALSE*/
    return _13FALSE_434;
    ;
}


void _41emit(int _val_50663)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_val_50663)) {
        _1 = (long)(DBL_PTR(_val_50663)->dbl);
        DeRefDS(_val_50663);
        _val_50663 = _1;
    }

    /** 	Code = append(Code, val)*/
    Append(&_35Code_16332, _35Code_16332, _val_50663);

    /** end procedure*/
    return;
    ;
}


void _41emit_opnd(int _opnd_50670)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_opnd_50670)) {
        _1 = (long)(DBL_PTR(_opnd_50670)->dbl);
        DeRefDS(_opnd_50670);
        _opnd_50670 = _1;
    }

    /** 		Push(opnd)*/
    _41Push(_opnd_50670);

    /** 		previous_op = -1  -- N.B.*/
    _35previous_op_16342 = -1;

    /** end procedure*/
    return;
    ;
}


void _41emit_addr(int _x_50674)
{
    int _0, _1, _2;
    

    /** 		Code = append(Code, x)*/
    Ref(_x_50674);
    Append(&_35Code_16332, _35Code_16332, _x_50674);

    /** end procedure*/
    DeRef(_x_50674);
    return;
    ;
}


void _41emit_opcode(int _op_50680)
{
    int _0, _1, _2;
    

    /** 	Code = append(Code, op)*/
    Append(&_35Code_16332, _35Code_16332, _op_50680);

    /** end procedure*/
    return;
    ;
}


void _41emit_temp(int _tempsym_50714, int _referenced_50715)
{
    int _26530 = NOVALUE;
    int _26529 = NOVALUE;
    int _26528 = NOVALUE;
    int _26527 = NOVALUE;
    int _26526 = NOVALUE;
    int _26525 = NOVALUE;
    int _26524 = NOVALUE;
    int _26523 = NOVALUE;
    int _26522 = NOVALUE;
    int _26521 = NOVALUE;
    int _26520 = NOVALUE;
    int _26519 = NOVALUE;
    int _26518 = NOVALUE;
    int _26517 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_referenced_50715)) {
        _1 = (long)(DBL_PTR(_referenced_50715)->dbl);
        DeRefDS(_referenced_50715);
        _referenced_50715 = _1;
    }

    /** 	if not TRANSLATE  then -- translator has its own way of handling temps*/
    if (_35TRANSLATE_15887 != 0)
    goto L1; // [7] 129

    /** 		if sequence(tempsym) then*/
    _26517 = IS_SEQUENCE(_tempsym_50714);
    if (_26517 == 0)
    {
        _26517 = NOVALUE;
        goto L2; // [15] 53
    }
    else{
        _26517 = NOVALUE;
    }

    /** 			for i = 1 to length(tempsym) do*/
    if (IS_SEQUENCE(_tempsym_50714)){
            _26518 = SEQ_PTR(_tempsym_50714)->length;
    }
    else {
        _26518 = 1;
    }
    {
        int _i_50722;
        _i_50722 = 1;
L3: 
        if (_i_50722 > _26518){
            goto L4; // [23] 50
        }

        /** 				emit_temp( tempsym[i], referenced )*/
        _2 = (int)SEQ_PTR(_tempsym_50714);
        _26519 = (int)*(((s1_ptr)_2)->base + _i_50722);
        DeRef(_26520);
        _26520 = _referenced_50715;
        Ref(_26519);
        _41emit_temp(_26519, _26520);
        _26519 = NOVALUE;
        _26520 = NOVALUE;

        /** 			end for*/
        _i_50722 = _i_50722 + 1;
        goto L3; // [45] 30
L4: 
        ;
    }
    goto L5; // [50] 128
L2: 

    /** 		elsif tempsym > 0*/
    if (IS_ATOM_INT(_tempsym_50714)) {
        _26521 = (_tempsym_50714 > 0);
    }
    else {
        _26521 = binary_op(GREATER, _tempsym_50714, 0);
    }
    if (IS_ATOM_INT(_26521)) {
        if (_26521 == 0) {
            DeRef(_26522);
            _26522 = 0;
            goto L6; // [59] 77
        }
    }
    else {
        if (DBL_PTR(_26521)->dbl == 0.0) {
            DeRef(_26522);
            _26522 = 0;
            goto L6; // [59] 77
        }
    }
    Ref(_tempsym_50714);
    _26523 = _53sym_mode(_tempsym_50714);
    if (IS_ATOM_INT(_26523)) {
        _26524 = (_26523 == 3);
    }
    else {
        _26524 = binary_op(EQUALS, _26523, 3);
    }
    DeRef(_26523);
    _26523 = NOVALUE;
    DeRef(_26522);
    if (IS_ATOM_INT(_26524))
    _26522 = (_26524 != 0);
    else
    _26522 = DBL_PTR(_26524)->dbl != 0.0;
L6: 
    if (_26522 == 0) {
        _26525 = 0;
        goto L7; // [77] 92
    }
    Ref(_tempsym_50714);
    _26526 = _41IsInteger(_tempsym_50714);
    if (IS_ATOM_INT(_26526)) {
        _26527 = (_26526 == 0);
    }
    else {
        _26527 = unary_op(NOT, _26526);
    }
    DeRef(_26526);
    _26526 = NOVALUE;
    if (IS_ATOM_INT(_26527))
    _26525 = (_26527 != 0);
    else
    _26525 = DBL_PTR(_26527)->dbl != 0.0;
L7: 
    if (_26525 == 0) {
        goto L8; // [92] 127
    }
    _26529 = find_from(_tempsym_50714, _41emitted_temps_50710, 1);
    _26530 = (_26529 == 0);
    _26529 = NOVALUE;
    if (_26530 == 0)
    {
        DeRef(_26530);
        _26530 = NOVALUE;
        goto L8; // [107] 127
    }
    else{
        DeRef(_26530);
        _26530 = NOVALUE;
    }

    /** 			emitted_temps &= tempsym*/
    if (IS_SEQUENCE(_41emitted_temps_50710) && IS_ATOM(_tempsym_50714)) {
        Ref(_tempsym_50714);
        Append(&_41emitted_temps_50710, _41emitted_temps_50710, _tempsym_50714);
    }
    else if (IS_ATOM(_41emitted_temps_50710) && IS_SEQUENCE(_tempsym_50714)) {
    }
    else {
        Concat((object_ptr)&_41emitted_temps_50710, _41emitted_temps_50710, _tempsym_50714);
    }

    /** 			emitted_temp_referenced &= referenced*/
    Append(&_41emitted_temp_referenced_50711, _41emitted_temp_referenced_50711, _referenced_50715);
L8: 
L5: 
L1: 

    /** end procedure*/
    DeRef(_tempsym_50714);
    DeRef(_26521);
    _26521 = NOVALUE;
    DeRef(_26527);
    _26527 = NOVALUE;
    DeRef(_26524);
    _26524 = NOVALUE;
    return;
    ;
}


void _41flush_temps(int _except_for_50744)
{
    int _refs_50747 = NOVALUE;
    int _novalues_50748 = NOVALUE;
    int _sym_50753 = NOVALUE;
    int _26545 = NOVALUE;
    int _26544 = NOVALUE;
    int _26543 = NOVALUE;
    int _26542 = NOVALUE;
    int _26540 = NOVALUE;
    int _26536 = NOVALUE;
    int _26535 = NOVALUE;
    int _26533 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if TRANSLATE then*/
    if (_35TRANSLATE_15887 == 0)
    {
        goto L1; // [7] 16
    }
    else{
    }

    /** 		return*/
    DeRefDS(_except_for_50744);
    DeRef(_refs_50747);
    DeRefi(_novalues_50748);
    return;
L1: 

    /** 	sequence*/

    /** 		refs = {},*/
    RefDS(_22023);
    DeRef(_refs_50747);
    _refs_50747 = _22023;

    /** 		novalues = {}*/
    RefDS(_22023);
    DeRefi(_novalues_50748);
    _novalues_50748 = _22023;

    /** 	derefs = {}*/
    RefDS(_22023);
    DeRefi(_41derefs_50741);
    _41derefs_50741 = _22023;

    /** 	for i = 1 to length( emitted_temps ) do*/
    if (IS_SEQUENCE(_41emitted_temps_50710)){
            _26533 = SEQ_PTR(_41emitted_temps_50710)->length;
    }
    else {
        _26533 = 1;
    }
    {
        int _i_50750;
        _i_50750 = 1;
L2: 
        if (_i_50750 > _26533){
            goto L3; // [46] 119
        }

        /** 		symtab_index sym = emitted_temps[i]*/
        _2 = (int)SEQ_PTR(_41emitted_temps_50710);
        _sym_50753 = (int)*(((s1_ptr)_2)->base + _i_50750);
        if (!IS_ATOM_INT(_sym_50753)){
            _sym_50753 = (long)DBL_PTR(_sym_50753)->dbl;
        }

        /** 		if find( sym, except_for ) then*/
        _26535 = find_from(_sym_50753, _except_for_50744, 1);
        if (_26535 == 0)
        {
            _26535 = NOVALUE;
            goto L4; // [70] 80
        }
        else{
            _26535 = NOVALUE;
        }

        /** 			continue*/
        goto L5; // [77] 114
L4: 

        /** 		if emitted_temp_referenced[i] = NEW_REFERENCE then*/
        _2 = (int)SEQ_PTR(_41emitted_temp_referenced_50711);
        _26536 = (int)*(((s1_ptr)_2)->base + _i_50750);
        if (binary_op_a(NOTEQ, _26536, 1)){
            _26536 = NOVALUE;
            goto L6; // [88] 103
        }
        _26536 = NOVALUE;

        /** 			derefs &= sym*/
        Append(&_41derefs_50741, _41derefs_50741, _sym_50753);
        goto L7; // [100] 110
L6: 

        /** 			novalues &= sym*/
        Append(&_novalues_50748, _novalues_50748, _sym_50753);
L7: 

        /** 	end for*/
L5: 
        _i_50750 = _i_50750 + 1;
        goto L2; // [114] 53
L3: 
        ;
    }

    /** 	if not length( except_for ) then*/
    if (IS_SEQUENCE(_except_for_50744)){
            _26540 = SEQ_PTR(_except_for_50744)->length;
    }
    else {
        _26540 = 1;
    }
    if (_26540 != 0)
    goto L8; // [124] 132
    _26540 = NOVALUE;

    /** 		clear_last()*/
    _41clear_last();
L8: 

    /** 	for i = 1 to length( derefs ) do*/
    if (IS_SEQUENCE(_41derefs_50741)){
            _26542 = SEQ_PTR(_41derefs_50741)->length;
    }
    else {
        _26542 = 1;
    }
    {
        int _i_50768;
        _i_50768 = 1;
L9: 
        if (_i_50768 > _26542){
            goto LA; // [139] 171
        }

        /** 		emit( DEREF_TEMP )*/
        _41emit(208);

        /** 		emit( derefs[i] )*/
        _2 = (int)SEQ_PTR(_41derefs_50741);
        _26543 = (int)*(((s1_ptr)_2)->base + _i_50768);
        _41emit(_26543);
        _26543 = NOVALUE;

        /** 	end for*/
        _i_50768 = _i_50768 + 1;
        goto L9; // [166] 146
LA: 
        ;
    }

    /** 	for i = 1 to length( novalues ) do*/
    if (IS_SEQUENCE(_novalues_50748)){
            _26544 = SEQ_PTR(_novalues_50748)->length;
    }
    else {
        _26544 = 1;
    }
    {
        int _i_50773;
        _i_50773 = 1;
LB: 
        if (_i_50773 > _26544){
            goto LC; // [176] 206
        }

        /** 		emit( NOVALUE_TEMP )*/
        _41emit(209);

        /** 		emit( novalues[i] )*/
        _2 = (int)SEQ_PTR(_novalues_50748);
        _26545 = (int)*(((s1_ptr)_2)->base + _i_50773);
        _41emit(_26545);
        _26545 = NOVALUE;

        /** 	end for*/
        _i_50773 = _i_50773 + 1;
        goto LB; // [201] 183
LC: 
        ;
    }

    /** 	emitted_temps = {}*/
    RefDS(_22023);
    DeRef(_41emitted_temps_50710);
    _41emitted_temps_50710 = _22023;

    /** 	emitted_temp_referenced = {}*/
    RefDS(_22023);
    DeRef(_41emitted_temp_referenced_50711);
    _41emitted_temp_referenced_50711 = _22023;

    /** end procedure*/
    DeRefDS(_except_for_50744);
    DeRef(_refs_50747);
    DeRefi(_novalues_50748);
    return;
    ;
}


void _41flush_temp(int _temp_50780)
{
    int _except_for_50781 = NOVALUE;
    int _ix_50782 = NOVALUE;
    int _26547 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_temp_50780)) {
        _1 = (long)(DBL_PTR(_temp_50780)->dbl);
        DeRefDS(_temp_50780);
        _temp_50780 = _1;
    }

    /** 	sequence except_for = emitted_temps*/
    RefDS(_41emitted_temps_50710);
    DeRef(_except_for_50781);
    _except_for_50781 = _41emitted_temps_50710;

    /** 	integer ix = find( temp, emitted_temps )*/
    _ix_50782 = find_from(_temp_50780, _41emitted_temps_50710, 1);

    /** 	if ix then*/
    if (_ix_50782 == 0)
    {
        goto L1; // [23] 37
    }
    else{
    }

    /** 		flush_temps( remove( except_for, ix ) )*/
    {
        s1_ptr assign_space = SEQ_PTR(_except_for_50781);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_ix_50782)) ? _ix_50782 : (long)(DBL_PTR(_ix_50782)->dbl);
        int stop = (IS_ATOM_INT(_ix_50782)) ? _ix_50782 : (long)(DBL_PTR(_ix_50782)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
            RefDS(_except_for_50781);
            DeRef(_26547);
            _26547 = _except_for_50781;
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_except_for_50781), start, &_26547 );
            }
            else Tail(SEQ_PTR(_except_for_50781), stop+1, &_26547);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_except_for_50781), start, &_26547);
        }
        else {
            assign_slice_seq = &assign_space;
            _1 = Remove_elements(start, stop, 0);
            DeRef(_26547);
            _26547 = _1;
        }
    }
    _41flush_temps(_26547);
    _26547 = NOVALUE;
L1: 

    /** end procedure*/
    DeRef(_except_for_50781);
    return;
    ;
}


void _41check_for_temps()
{
    int _26554 = NOVALUE;
    int _26553 = NOVALUE;
    int _26552 = NOVALUE;
    int _26551 = NOVALUE;
    int _26549 = NOVALUE;
    int _26548 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if TRANSLATE or last_op < 1 or last_pc < 1 then*/
    if (_35TRANSLATE_15887 != 0) {
        _26548 = 1;
        goto L1; // [5] 19
    }
    _26549 = (_41last_op_51116 < 1);
    _26548 = (_26549 != 0);
L1: 
    if (_26548 != 0) {
        goto L2; // [19] 34
    }
    _26551 = (_41last_pc_51117 < 1);
    if (_26551 == 0)
    {
        DeRef(_26551);
        _26551 = NOVALUE;
        goto L3; // [30] 40
    }
    else{
        DeRef(_26551);
        _26551 = NOVALUE;
    }
L2: 

    /** 		return*/
    DeRef(_26549);
    _26549 = NOVALUE;
    return;
L3: 

    /** 	emit_temp( get_target_sym( current_op( last_pc ) ), op_temp_ref[last_op] )*/
    RefDS(_35Code_16332);
    _26552 = _65current_op(_41last_pc_51117, _35Code_16332);
    _26553 = _65get_target_sym(_26552);
    _26552 = NOVALUE;
    _2 = (int)SEQ_PTR(_41op_temp_ref_50932);
    _26554 = (int)*(((s1_ptr)_2)->base + _41last_op_51116);
    _41emit_temp(_26553, _26554);
    _26553 = NOVALUE;
    _26554 = NOVALUE;

    /** end procedure*/
    DeRef(_26549);
    _26549 = NOVALUE;
    return;
    ;
}


void _41clear_temp(int _tempsym_50807)
{
    int _ix_50808 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_tempsym_50807)) {
        _1 = (long)(DBL_PTR(_tempsym_50807)->dbl);
        DeRefDS(_tempsym_50807);
        _tempsym_50807 = _1;
    }

    /** 	integer ix = find( tempsym, emitted_temps )*/
    _ix_50808 = find_from(_tempsym_50807, _41emitted_temps_50710, 1);

    /** 	if ix then*/
    if (_ix_50808 == 0)
    {
        goto L1; // [14] 36
    }
    else{
    }

    /** 		emitted_temps = remove( emitted_temps, ix )*/
    {
        s1_ptr assign_space = SEQ_PTR(_41emitted_temps_50710);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_ix_50808)) ? _ix_50808 : (long)(DBL_PTR(_ix_50808)->dbl);
        int stop = (IS_ATOM_INT(_ix_50808)) ? _ix_50808 : (long)(DBL_PTR(_ix_50808)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_41emitted_temps_50710), start, &_41emitted_temps_50710 );
            }
            else Tail(SEQ_PTR(_41emitted_temps_50710), stop+1, &_41emitted_temps_50710);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_41emitted_temps_50710), start, &_41emitted_temps_50710);
        }
        else {
            assign_slice_seq = &assign_space;
            _41emitted_temps_50710 = Remove_elements(start, stop, (SEQ_PTR(_41emitted_temps_50710)->ref == 1));
        }
    }

    /** 		emitted_temp_referenced = remove( emitted_temp_referenced, ix )*/
    {
        s1_ptr assign_space = SEQ_PTR(_41emitted_temp_referenced_50711);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_ix_50808)) ? _ix_50808 : (long)(DBL_PTR(_ix_50808)->dbl);
        int stop = (IS_ATOM_INT(_ix_50808)) ? _ix_50808 : (long)(DBL_PTR(_ix_50808)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_41emitted_temp_referenced_50711), start, &_41emitted_temp_referenced_50711 );
            }
            else Tail(SEQ_PTR(_41emitted_temp_referenced_50711), stop+1, &_41emitted_temp_referenced_50711);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_41emitted_temp_referenced_50711), start, &_41emitted_temp_referenced_50711);
        }
        else {
            assign_slice_seq = &assign_space;
            _41emitted_temp_referenced_50711 = Remove_elements(start, stop, (SEQ_PTR(_41emitted_temp_referenced_50711)->ref == 1));
        }
    }
L1: 

    /** end procedure*/
    return;
    ;
}


int _41pop_temps()
{
    int _new_emitted_50815 = NOVALUE;
    int _new_referenced_50816 = NOVALUE;
    int _26558 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence new_emitted  = emitted_temps*/
    RefDS(_41emitted_temps_50710);
    DeRef(_new_emitted_50815);
    _new_emitted_50815 = _41emitted_temps_50710;

    /** 	sequence new_referenced = emitted_temp_referenced*/
    RefDS(_41emitted_temp_referenced_50711);
    DeRef(_new_referenced_50816);
    _new_referenced_50816 = _41emitted_temp_referenced_50711;

    /** 	emitted_temps  = {}*/
    RefDS(_22023);
    DeRefDS(_41emitted_temps_50710);
    _41emitted_temps_50710 = _22023;

    /** 	emitted_temp_referenced = {}*/
    RefDS(_22023);
    DeRefDS(_41emitted_temp_referenced_50711);
    _41emitted_temp_referenced_50711 = _22023;

    /** 	return { new_emitted, new_referenced }*/
    RefDS(_new_referenced_50816);
    RefDS(_new_emitted_50815);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _new_emitted_50815;
    ((int *)_2)[2] = _new_referenced_50816;
    _26558 = MAKE_SEQ(_1);
    DeRefDS(_new_emitted_50815);
    DeRefDS(_new_referenced_50816);
    return _26558;
    ;
}


int _41get_temps(int _add_to_50820)
{
    int _26563 = NOVALUE;
    int _26562 = NOVALUE;
    int _26561 = NOVALUE;
    int _26560 = NOVALUE;
    int _0, _1, _2;
    

    /** 	add_to[1] &= emitted_temps*/
    _2 = (int)SEQ_PTR(_add_to_50820);
    _26560 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_26560) && IS_ATOM(_41emitted_temps_50710)) {
    }
    else if (IS_ATOM(_26560) && IS_SEQUENCE(_41emitted_temps_50710)) {
        Ref(_26560);
        Prepend(&_26561, _41emitted_temps_50710, _26560);
    }
    else {
        Concat((object_ptr)&_26561, _26560, _41emitted_temps_50710);
        _26560 = NOVALUE;
    }
    _26560 = NOVALUE;
    _2 = (int)SEQ_PTR(_add_to_50820);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _add_to_50820 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _26561;
    if( _1 != _26561 ){
        DeRef(_1);
    }
    _26561 = NOVALUE;

    /** 	add_to[2] &= emitted_temp_referenced*/
    _2 = (int)SEQ_PTR(_add_to_50820);
    _26562 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_26562) && IS_ATOM(_41emitted_temp_referenced_50711)) {
    }
    else if (IS_ATOM(_26562) && IS_SEQUENCE(_41emitted_temp_referenced_50711)) {
        Ref(_26562);
        Prepend(&_26563, _41emitted_temp_referenced_50711, _26562);
    }
    else {
        Concat((object_ptr)&_26563, _26562, _41emitted_temp_referenced_50711);
        _26562 = NOVALUE;
    }
    _26562 = NOVALUE;
    _2 = (int)SEQ_PTR(_add_to_50820);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _add_to_50820 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _26563;
    if( _1 != _26563 ){
        DeRef(_1);
    }
    _26563 = NOVALUE;

    /** 	return add_to*/
    return _add_to_50820;
    ;
}


void _41push_temps(int _temps_50828)
{
    int _26566 = NOVALUE;
    int _26564 = NOVALUE;
    int _0, _1, _2;
    

    /** 	emitted_temps &= temps[1]*/
    _2 = (int)SEQ_PTR(_temps_50828);
    _26564 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_41emitted_temps_50710) && IS_ATOM(_26564)) {
        Ref(_26564);
        Append(&_41emitted_temps_50710, _41emitted_temps_50710, _26564);
    }
    else if (IS_ATOM(_41emitted_temps_50710) && IS_SEQUENCE(_26564)) {
    }
    else {
        Concat((object_ptr)&_41emitted_temps_50710, _41emitted_temps_50710, _26564);
    }
    _26564 = NOVALUE;

    /** 	emitted_temp_referenced &= temps[2]*/
    _2 = (int)SEQ_PTR(_temps_50828);
    _26566 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_41emitted_temp_referenced_50711) && IS_ATOM(_26566)) {
        Ref(_26566);
        Append(&_41emitted_temp_referenced_50711, _41emitted_temp_referenced_50711, _26566);
    }
    else if (IS_ATOM(_41emitted_temp_referenced_50711) && IS_SEQUENCE(_26566)) {
    }
    else {
        Concat((object_ptr)&_41emitted_temp_referenced_50711, _41emitted_temp_referenced_50711, _26566);
    }
    _26566 = NOVALUE;

    /** 	flush_temps()*/
    RefDS(_22023);
    _41flush_temps(_22023);

    /** end procedure*/
    DeRefDS(_temps_50828);
    return;
    ;
}


void _41backpatch(int _index_50835, int _val_50836)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_index_50835)) {
        _1 = (long)(DBL_PTR(_index_50835)->dbl);
        DeRefDS(_index_50835);
        _index_50835 = _1;
    }
    if (!IS_ATOM_INT(_val_50836)) {
        _1 = (long)(DBL_PTR(_val_50836)->dbl);
        DeRefDS(_val_50836);
        _val_50836 = _1;
    }

    /** 		Code[index] = val*/
    _2 = (int)SEQ_PTR(_35Code_16332);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _35Code_16332 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _index_50835);
    _1 = *(int *)_2;
    *(int *)_2 = _val_50836;
    DeRef(_1);

    /** end procedure*/
    return;
    ;
}


void _41cont11ii(int _op_51017, int _ii_51019)
{
    int _t_51020 = NOVALUE;
    int _source_51021 = NOVALUE;
    int _c_51022 = NOVALUE;
    int _26575 = NOVALUE;
    int _26574 = NOVALUE;
    int _26572 = NOVALUE;
    int _0, _1, _2;
    

    /** 	emit_opcode(op)*/
    _41emit_opcode(_op_51017);

    /** 	source = Pop()*/
    _source_51021 = _41Pop();
    if (!IS_ATOM_INT(_source_51021)) {
        _1 = (long)(DBL_PTR(_source_51021)->dbl);
        DeRefDS(_source_51021);
        _source_51021 = _1;
    }

    /** 	emit_addr(source)*/
    _41emit_addr(_source_51021);

    /** 	assignable = TRUE*/
    _41assignable_50240 = _13TRUE_436;

    /** 	t = op_result[op]*/
    _2 = (int)SEQ_PTR(_41op_result_50838);
    _t_51020 = (int)*(((s1_ptr)_2)->base + _op_51017);

    /** 	if t = T_INTEGER or (ii and IsInteger(source)) then*/
    _26572 = (_t_51020 == 1);
    if (_26572 != 0) {
        goto L1; // [43] 64
    }
    if (_ii_51019 == 0) {
        _26574 = 0;
        goto L2; // [47] 59
    }
    _26575 = _41IsInteger(_source_51021);
    if (IS_ATOM_INT(_26575))
    _26574 = (_26575 != 0);
    else
    _26574 = DBL_PTR(_26575)->dbl != 0.0;
L2: 
    if (_26574 == 0)
    {
        _26574 = NOVALUE;
        goto L3; // [60] 80
    }
    else{
        _26574 = NOVALUE;
    }
L1: 

    /** 		c = NewTempSym()*/
    _c_51022 = _53NewTempSym(0);
    if (!IS_ATOM_INT(_c_51022)) {
        _1 = (long)(DBL_PTR(_c_51022)->dbl);
        DeRefDS(_c_51022);
        _c_51022 = _1;
    }

    /** 		TempInteger(c)*/
    _41TempInteger(_c_51022);
    goto L4; // [77] 95
L3: 

    /** 		c = NewTempSym() -- allocate *after* checking opnd type*/
    _c_51022 = _53NewTempSym(0);
    if (!IS_ATOM_INT(_c_51022)) {
        _1 = (long)(DBL_PTR(_c_51022)->dbl);
        DeRefDS(_c_51022);
        _c_51022 = _1;
    }

    /** 		emit_temp( c, NEW_REFERENCE )*/
    _41emit_temp(_c_51022, 1);
L4: 

    /** 	Push(c)*/
    _41Push(_c_51022);

    /** 	emit_addr(c)*/
    _41emit_addr(_c_51022);

    /** end procedure*/
    DeRef(_26572);
    _26572 = NOVALUE;
    DeRef(_26575);
    _26575 = NOVALUE;
    return;
    ;
}


void _41cont21d(int _op_51039, int _a_51040, int _b_51041, int _ii_51043)
{
    int _c_51044 = NOVALUE;
    int _t_51045 = NOVALUE;
    int _26585 = NOVALUE;
    int _26584 = NOVALUE;
    int _26583 = NOVALUE;
    int _26582 = NOVALUE;
    int _26580 = NOVALUE;
    int _0, _1, _2;
    

    /** 	assignable = TRUE*/
    _41assignable_50240 = _13TRUE_436;

    /** 	t = op_result[op]*/
    _2 = (int)SEQ_PTR(_41op_result_50838);
    _t_51045 = (int)*(((s1_ptr)_2)->base + _op_51039);

    /** 	if op = C_FUNC then*/
    if (_op_51039 != 133)
    goto L1; // [26] 38

    /** 		emit_addr(CurrentSub)*/
    _41emit_addr(_35CurrentSub_16252);
L1: 

    /** 	if t = T_INTEGER or (ii and IsInteger(a) and IsInteger(b)) then*/
    _26580 = (_t_51045 == 1);
    if (_26580 != 0) {
        goto L2; // [46] 79
    }
    if (_ii_51043 == 0) {
        _26582 = 0;
        goto L3; // [50] 62
    }
    _26583 = _41IsInteger(_a_51040);
    if (IS_ATOM_INT(_26583))
    _26582 = (_26583 != 0);
    else
    _26582 = DBL_PTR(_26583)->dbl != 0.0;
L3: 
    if (_26582 == 0) {
        DeRef(_26584);
        _26584 = 0;
        goto L4; // [62] 74
    }
    _26585 = _41IsInteger(_b_51041);
    if (IS_ATOM_INT(_26585))
    _26584 = (_26585 != 0);
    else
    _26584 = DBL_PTR(_26585)->dbl != 0.0;
L4: 
    if (_26584 == 0)
    {
        _26584 = NOVALUE;
        goto L5; // [75] 95
    }
    else{
        _26584 = NOVALUE;
    }
L2: 

    /** 		c = NewTempSym()*/
    _c_51044 = _53NewTempSym(0);
    if (!IS_ATOM_INT(_c_51044)) {
        _1 = (long)(DBL_PTR(_c_51044)->dbl);
        DeRefDS(_c_51044);
        _c_51044 = _1;
    }

    /** 		TempInteger(c)*/
    _41TempInteger(_c_51044);
    goto L6; // [92] 110
L5: 

    /** 		c = NewTempSym() -- allocate *after* checking opnd types*/
    _c_51044 = _53NewTempSym(0);
    if (!IS_ATOM_INT(_c_51044)) {
        _1 = (long)(DBL_PTR(_c_51044)->dbl);
        DeRefDS(_c_51044);
        _c_51044 = _1;
    }

    /** 		emit_temp( c, NEW_REFERENCE )*/
    _41emit_temp(_c_51044, 1);
L6: 

    /** 	Push(c)*/
    _41Push(_c_51044);

    /** 	emit_addr(c)*/
    _41emit_addr(_c_51044);

    /** end procedure*/
    DeRef(_26580);
    _26580 = NOVALUE;
    DeRef(_26583);
    _26583 = NOVALUE;
    DeRef(_26585);
    _26585 = NOVALUE;
    return;
    ;
}


void _41cont21ii(int _op_51067, int _ii_51069)
{
    int _a_51070 = NOVALUE;
    int _b_51071 = NOVALUE;
    int _0, _1, _2;
    

    /** 	b = Pop()*/
    _b_51071 = _41Pop();
    if (!IS_ATOM_INT(_b_51071)) {
        _1 = (long)(DBL_PTR(_b_51071)->dbl);
        DeRefDS(_b_51071);
        _b_51071 = _1;
    }

    /** 	emit_opcode(op)*/
    _41emit_opcode(_op_51067);

    /** 	a = Pop()*/
    _a_51070 = _41Pop();
    if (!IS_ATOM_INT(_a_51070)) {
        _1 = (long)(DBL_PTR(_a_51070)->dbl);
        DeRefDS(_a_51070);
        _a_51070 = _1;
    }

    /** 	emit_addr(a)*/
    _41emit_addr(_a_51070);

    /** 	emit_addr(b)*/
    _41emit_addr(_b_51071);

    /** 	cont21d(op, a, b, ii)*/
    _41cont21d(_op_51067, _a_51070, _b_51071, _ii_51069);

    /** end procedure*/
    return;
    ;
}


int _41good_string(int _elements_51076)
{
    int _obj_51077 = NOVALUE;
    int _ep_51079 = NOVALUE;
    int _e_51081 = NOVALUE;
    int _element_vals_51082 = NOVALUE;
    int _26608 = NOVALUE;
    int _26607 = NOVALUE;
    int _26606 = NOVALUE;
    int _26605 = NOVALUE;
    int _26604 = NOVALUE;
    int _26603 = NOVALUE;
    int _26602 = NOVALUE;
    int _26601 = NOVALUE;
    int _26600 = NOVALUE;
    int _26599 = NOVALUE;
    int _26598 = NOVALUE;
    int _26596 = NOVALUE;
    int _26593 = NOVALUE;
    int _26592 = NOVALUE;
    int _26591 = NOVALUE;
    int _26590 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence element_vals*/

    /** 	if TRANSLATE and length(elements) > 10000 then*/
    if (_35TRANSLATE_15887 == 0) {
        goto L1; // [9] 31
    }
    if (IS_SEQUENCE(_elements_51076)){
            _26591 = SEQ_PTR(_elements_51076)->length;
    }
    else {
        _26591 = 1;
    }
    _26592 = (_26591 > 10000);
    _26591 = NOVALUE;
    if (_26592 == 0)
    {
        DeRef(_26592);
        _26592 = NOVALUE;
        goto L1; // [21] 31
    }
    else{
        DeRef(_26592);
        _26592 = NOVALUE;
    }

    /** 		return -1 -- A huge string might upset the C compiler.*/
    DeRefDS(_elements_51076);
    DeRef(_obj_51077);
    DeRef(_element_vals_51082);
    return -1;
L1: 

    /** 	element_vals = {}*/
    RefDS(_22023);
    DeRef(_element_vals_51082);
    _element_vals_51082 = _22023;

    /** 	for i = 1 to length(elements) do*/
    if (IS_SEQUENCE(_elements_51076)){
            _26593 = SEQ_PTR(_elements_51076)->length;
    }
    else {
        _26593 = 1;
    }
    {
        int _i_51089;
        _i_51089 = 1;
L2: 
        if (_i_51089 > _26593){
            goto L3; // [43] 183
        }

        /** 		ep = elements[i]*/
        _2 = (int)SEQ_PTR(_elements_51076);
        _ep_51079 = (int)*(((s1_ptr)_2)->base + _i_51089);
        if (!IS_ATOM_INT(_ep_51079)){
            _ep_51079 = (long)DBL_PTR(_ep_51079)->dbl;
        }

        /** 		if ep < 1 then*/
        if (_ep_51079 >= 1)
        goto L4; // [60] 71

        /** 			return -1*/
        DeRefDS(_elements_51076);
        DeRef(_obj_51077);
        DeRef(_element_vals_51082);
        return -1;
L4: 

        /** 		e = ep*/
        _e_51081 = _ep_51079;

        /** 		obj = SymTab[e][S_OBJ]*/
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _26596 = (int)*(((s1_ptr)_2)->base + _e_51081);
        DeRef(_obj_51077);
        _2 = (int)SEQ_PTR(_26596);
        _obj_51077 = (int)*(((s1_ptr)_2)->base + 1);
        Ref(_obj_51077);
        _26596 = NOVALUE;

        /** 		if SymTab[e][S_MODE] = M_CONSTANT and*/
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _26598 = (int)*(((s1_ptr)_2)->base + _e_51081);
        _2 = (int)SEQ_PTR(_26598);
        _26599 = (int)*(((s1_ptr)_2)->base + 3);
        _26598 = NOVALUE;
        if (IS_ATOM_INT(_26599)) {
            _26600 = (_26599 == 2);
        }
        else {
            _26600 = binary_op(EQUALS, _26599, 2);
        }
        _26599 = NOVALUE;
        if (IS_ATOM_INT(_26600)) {
            if (_26600 == 0) {
                DeRef(_26601);
                _26601 = 0;
                goto L5; // [112] 123
            }
        }
        else {
            if (DBL_PTR(_26600)->dbl == 0.0) {
                DeRef(_26601);
                _26601 = 0;
                goto L5; // [112] 123
            }
        }
        if (IS_ATOM_INT(_obj_51077))
        _26602 = 1;
        else if (IS_ATOM_DBL(_obj_51077))
        _26602 = IS_ATOM_INT(DoubleToInt(_obj_51077));
        else
        _26602 = 0;
        DeRef(_26601);
        _26601 = (_26602 != 0);
L5: 
        if (_26601 == 0) {
            goto L6; // [123] 169
        }
        _26604 = (_35TRANSLATE_15887 == 0);
        if (_26604 != 0) {
            DeRef(_26605);
            _26605 = 1;
            goto L7; // [132] 156
        }
        if (IS_ATOM_INT(_obj_51077)) {
            _26606 = (_obj_51077 >= 1);
        }
        else {
            _26606 = binary_op(GREATEREQ, _obj_51077, 1);
        }
        if (IS_ATOM_INT(_26606)) {
            if (_26606 == 0) {
                DeRef(_26607);
                _26607 = 0;
                goto L8; // [140] 152
            }
        }
        else {
            if (DBL_PTR(_26606)->dbl == 0.0) {
                DeRef(_26607);
                _26607 = 0;
                goto L8; // [140] 152
            }
        }
        if (IS_ATOM_INT(_obj_51077)) {
            _26608 = (_obj_51077 <= 255);
        }
        else {
            _26608 = binary_op(LESSEQ, _obj_51077, 255);
        }
        DeRef(_26607);
        if (IS_ATOM_INT(_26608))
        _26607 = (_26608 != 0);
        else
        _26607 = DBL_PTR(_26608)->dbl != 0.0;
L8: 
        DeRef(_26605);
        _26605 = (_26607 != 0);
L7: 
        if (_26605 == 0)
        {
            _26605 = NOVALUE;
            goto L6; // [157] 169
        }
        else{
            _26605 = NOVALUE;
        }

        /** 			element_vals = prepend(element_vals, obj)*/
        Ref(_obj_51077);
        Prepend(&_element_vals_51082, _element_vals_51082, _obj_51077);
        goto L9; // [166] 176
L6: 

        /** 			return -1*/
        DeRefDS(_elements_51076);
        DeRef(_obj_51077);
        DeRef(_element_vals_51082);
        DeRef(_26604);
        _26604 = NOVALUE;
        DeRef(_26600);
        _26600 = NOVALUE;
        DeRef(_26606);
        _26606 = NOVALUE;
        DeRef(_26608);
        _26608 = NOVALUE;
        return -1;
L9: 

        /** 	end for*/
        _i_51089 = _i_51089 + 1;
        goto L2; // [178] 50
L3: 
        ;
    }

    /** 	return element_vals*/
    DeRefDS(_elements_51076);
    DeRef(_obj_51077);
    DeRef(_26604);
    _26604 = NOVALUE;
    DeRef(_26600);
    _26600 = NOVALUE;
    DeRef(_26606);
    _26606 = NOVALUE;
    DeRef(_26608);
    _26608 = NOVALUE;
    return _element_vals_51082;
    ;
}


int _41Last_op()
{
    int _0, _1, _2;
    

    /** 	return last_op*/
    return _41last_op_51116;
    ;
}


int _41Last_pc()
{
    int _0, _1, _2;
    

    /** 	return last_pc*/
    return _41last_pc_51117;
    ;
}


void _41move_last_pc(int _amount_51124)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_amount_51124)) {
        _1 = (long)(DBL_PTR(_amount_51124)->dbl);
        DeRefDS(_amount_51124);
        _amount_51124 = _1;
    }

    /** 	if last_pc > 0 then*/
    if (_41last_pc_51117 <= 0)
    goto L1; // [7] 20

    /** 		last_pc += amount*/
    _41last_pc_51117 = _41last_pc_51117 + _amount_51124;
L1: 

    /** end procedure*/
    return;
    ;
}


void _41clear_last()
{
    int _0, _1, _2;
    

    /** 	last_op = 0*/
    _41last_op_51116 = 0;

    /** 	last_pc = 0*/
    _41last_pc_51117 = 0;

    /** end procedure*/
    return;
    ;
}


void _41clear_op()
{
    int _0, _1, _2;
    

    /** 	previous_op = -1*/
    _35previous_op_16342 = -1;

    /** 	assignable = FALSE*/
    _41assignable_50240 = _13FALSE_434;

    /** end procedure*/
    return;
    ;
}


void _41inlined_function()
{
    int _0, _1, _2;
    

    /** 	previous_op = PROC*/
    _35previous_op_16342 = 27;

    /** 	assignable = TRUE*/
    _41assignable_50240 = _13TRUE_436;

    /** 	inlined = TRUE*/
    _41inlined_51135 = _13TRUE_436;

    /** end procedure*/
    return;
    ;
}


void _41add_inline_target(int _pc_51146)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_pc_51146)) {
        _1 = (long)(DBL_PTR(_pc_51146)->dbl);
        DeRefDS(_pc_51146);
        _pc_51146 = _1;
    }

    /** 	inlined_targets &= pc*/
    Append(&_41inlined_targets_51143, _41inlined_targets_51143, _pc_51146);

    /** end procedure*/
    return;
    ;
}


void _41clear_inline_targets()
{
    int _0, _1, _2;
    

    /** 	inlined_targets = {}*/
    RefDS(_22023);
    DeRefi(_41inlined_targets_51143);
    _41inlined_targets_51143 = _22023;

    /** end procedure*/
    return;
    ;
}


void _41emit_inline(int _code_51152)
{
    int _0, _1, _2;
    

    /** 	last_pc = 0*/
    _41last_pc_51117 = 0;

    /** 	last_op = 0*/
    _41last_op_51116 = 0;

    /** 	Code &= code*/
    Concat((object_ptr)&_35Code_16332, _35Code_16332, _code_51152);

    /** end procedure*/
    DeRefDS(_code_51152);
    return;
    ;
}


void _41emit_op(int _op_51157)
{
    int _a_51159 = NOVALUE;
    int _b_51160 = NOVALUE;
    int _c_51161 = NOVALUE;
    int _d_51162 = NOVALUE;
    int _source_51163 = NOVALUE;
    int _target_51164 = NOVALUE;
    int _subsym_51165 = NOVALUE;
    int _lhs_var_51167 = NOVALUE;
    int _ib_51168 = NOVALUE;
    int _ic_51169 = NOVALUE;
    int _n_51170 = NOVALUE;
    int _obj_51171 = NOVALUE;
    int _elements_51172 = NOVALUE;
    int _element_vals_51173 = NOVALUE;
    int _last_pc_backup_51174 = NOVALUE;
    int _last_op_backup_51175 = NOVALUE;
    int _temp_51184 = NOVALUE;
    int _real_op_51472 = NOVALUE;
    int _ref_51479 = NOVALUE;
    int _paths_51509 = NOVALUE;
    int _if_code_51589 = NOVALUE;
    int _if_code_51628 = NOVALUE;
    int _Top_inlined_Top_at_5195_52195 = NOVALUE;
    int _element_52266 = NOVALUE;
    int _Top_inlined_Top_at_6750_52413 = NOVALUE;
    int _31660 = NOVALUE;
    int _31659 = NOVALUE;
    int _27189 = NOVALUE;
    int _27185 = NOVALUE;
    int _27182 = NOVALUE;
    int _27180 = NOVALUE;
    int _27174 = NOVALUE;
    int _27173 = NOVALUE;
    int _27172 = NOVALUE;
    int _27170 = NOVALUE;
    int _27168 = NOVALUE;
    int _27167 = NOVALUE;
    int _27166 = NOVALUE;
    int _27165 = NOVALUE;
    int _27164 = NOVALUE;
    int _27163 = NOVALUE;
    int _27162 = NOVALUE;
    int _27161 = NOVALUE;
    int _27160 = NOVALUE;
    int _27159 = NOVALUE;
    int _27158 = NOVALUE;
    int _27156 = NOVALUE;
    int _27155 = NOVALUE;
    int _27154 = NOVALUE;
    int _27152 = NOVALUE;
    int _27151 = NOVALUE;
    int _27150 = NOVALUE;
    int _27149 = NOVALUE;
    int _27148 = NOVALUE;
    int _27147 = NOVALUE;
    int _27146 = NOVALUE;
    int _27145 = NOVALUE;
    int _27144 = NOVALUE;
    int _27141 = NOVALUE;
    int _27138 = NOVALUE;
    int _27137 = NOVALUE;
    int _27136 = NOVALUE;
    int _27135 = NOVALUE;
    int _27133 = NOVALUE;
    int _27131 = NOVALUE;
    int _27119 = NOVALUE;
    int _27111 = NOVALUE;
    int _27108 = NOVALUE;
    int _27107 = NOVALUE;
    int _27106 = NOVALUE;
    int _27105 = NOVALUE;
    int _27102 = NOVALUE;
    int _27101 = NOVALUE;
    int _27100 = NOVALUE;
    int _27099 = NOVALUE;
    int _27098 = NOVALUE;
    int _27097 = NOVALUE;
    int _27096 = NOVALUE;
    int _27095 = NOVALUE;
    int _27094 = NOVALUE;
    int _27093 = NOVALUE;
    int _27092 = NOVALUE;
    int _27090 = NOVALUE;
    int _27086 = NOVALUE;
    int _27085 = NOVALUE;
    int _27084 = NOVALUE;
    int _27083 = NOVALUE;
    int _27082 = NOVALUE;
    int _27081 = NOVALUE;
    int _27080 = NOVALUE;
    int _27079 = NOVALUE;
    int _27078 = NOVALUE;
    int _27077 = NOVALUE;
    int _27076 = NOVALUE;
    int _27074 = NOVALUE;
    int _27069 = NOVALUE;
    int _27068 = NOVALUE;
    int _27066 = NOVALUE;
    int _27065 = NOVALUE;
    int _27064 = NOVALUE;
    int _27062 = NOVALUE;
    int _27059 = NOVALUE;
    int _27055 = NOVALUE;
    int _27052 = NOVALUE;
    int _27051 = NOVALUE;
    int _27050 = NOVALUE;
    int _27049 = NOVALUE;
    int _27048 = NOVALUE;
    int _27047 = NOVALUE;
    int _27045 = NOVALUE;
    int _27044 = NOVALUE;
    int _27042 = NOVALUE;
    int _27041 = NOVALUE;
    int _27040 = NOVALUE;
    int _27039 = NOVALUE;
    int _27038 = NOVALUE;
    int _27037 = NOVALUE;
    int _27036 = NOVALUE;
    int _27035 = NOVALUE;
    int _27034 = NOVALUE;
    int _27033 = NOVALUE;
    int _27031 = NOVALUE;
    int _27030 = NOVALUE;
    int _27029 = NOVALUE;
    int _27028 = NOVALUE;
    int _27027 = NOVALUE;
    int _27026 = NOVALUE;
    int _27025 = NOVALUE;
    int _27024 = NOVALUE;
    int _27023 = NOVALUE;
    int _27022 = NOVALUE;
    int _27021 = NOVALUE;
    int _27020 = NOVALUE;
    int _27019 = NOVALUE;
    int _27018 = NOVALUE;
    int _27017 = NOVALUE;
    int _27015 = NOVALUE;
    int _27012 = NOVALUE;
    int _27011 = NOVALUE;
    int _27010 = NOVALUE;
    int _27009 = NOVALUE;
    int _27008 = NOVALUE;
    int _27007 = NOVALUE;
    int _27006 = NOVALUE;
    int _27005 = NOVALUE;
    int _27004 = NOVALUE;
    int _27003 = NOVALUE;
    int _27002 = NOVALUE;
    int _27001 = NOVALUE;
    int _27000 = NOVALUE;
    int _26999 = NOVALUE;
    int _26998 = NOVALUE;
    int _26996 = NOVALUE;
    int _26992 = NOVALUE;
    int _26989 = NOVALUE;
    int _26987 = NOVALUE;
    int _26986 = NOVALUE;
    int _26984 = NOVALUE;
    int _26983 = NOVALUE;
    int _26982 = NOVALUE;
    int _26981 = NOVALUE;
    int _26980 = NOVALUE;
    int _26979 = NOVALUE;
    int _26978 = NOVALUE;
    int _26977 = NOVALUE;
    int _26976 = NOVALUE;
    int _26975 = NOVALUE;
    int _26974 = NOVALUE;
    int _26973 = NOVALUE;
    int _26972 = NOVALUE;
    int _26971 = NOVALUE;
    int _26970 = NOVALUE;
    int _26969 = NOVALUE;
    int _26968 = NOVALUE;
    int _26967 = NOVALUE;
    int _26966 = NOVALUE;
    int _26964 = NOVALUE;
    int _26962 = NOVALUE;
    int _26961 = NOVALUE;
    int _26959 = NOVALUE;
    int _26949 = NOVALUE;
    int _26948 = NOVALUE;
    int _26947 = NOVALUE;
    int _26946 = NOVALUE;
    int _26945 = NOVALUE;
    int _26944 = NOVALUE;
    int _26943 = NOVALUE;
    int _26942 = NOVALUE;
    int _26941 = NOVALUE;
    int _26940 = NOVALUE;
    int _26939 = NOVALUE;
    int _26938 = NOVALUE;
    int _26937 = NOVALUE;
    int _26936 = NOVALUE;
    int _26935 = NOVALUE;
    int _26934 = NOVALUE;
    int _26933 = NOVALUE;
    int _26932 = NOVALUE;
    int _26931 = NOVALUE;
    int _26930 = NOVALUE;
    int _26929 = NOVALUE;
    int _26928 = NOVALUE;
    int _26927 = NOVALUE;
    int _26926 = NOVALUE;
    int _26920 = NOVALUE;
    int _26919 = NOVALUE;
    int _26916 = NOVALUE;
    int _26913 = NOVALUE;
    int _26912 = NOVALUE;
    int _26911 = NOVALUE;
    int _26910 = NOVALUE;
    int _26909 = NOVALUE;
    int _26908 = NOVALUE;
    int _26907 = NOVALUE;
    int _26906 = NOVALUE;
    int _26905 = NOVALUE;
    int _26904 = NOVALUE;
    int _26902 = NOVALUE;
    int _26901 = NOVALUE;
    int _26900 = NOVALUE;
    int _26898 = NOVALUE;
    int _26896 = NOVALUE;
    int _26895 = NOVALUE;
    int _26894 = NOVALUE;
    int _26893 = NOVALUE;
    int _26892 = NOVALUE;
    int _26891 = NOVALUE;
    int _26890 = NOVALUE;
    int _26889 = NOVALUE;
    int _26888 = NOVALUE;
    int _26887 = NOVALUE;
    int _26885 = NOVALUE;
    int _26884 = NOVALUE;
    int _26882 = NOVALUE;
    int _26881 = NOVALUE;
    int _26880 = NOVALUE;
    int _26879 = NOVALUE;
    int _26878 = NOVALUE;
    int _26876 = NOVALUE;
    int _26875 = NOVALUE;
    int _26874 = NOVALUE;
    int _26873 = NOVALUE;
    int _26872 = NOVALUE;
    int _26871 = NOVALUE;
    int _26870 = NOVALUE;
    int _26869 = NOVALUE;
    int _26867 = NOVALUE;
    int _26866 = NOVALUE;
    int _26865 = NOVALUE;
    int _26864 = NOVALUE;
    int _26863 = NOVALUE;
    int _26861 = NOVALUE;
    int _26860 = NOVALUE;
    int _26858 = NOVALUE;
    int _26857 = NOVALUE;
    int _26856 = NOVALUE;
    int _26855 = NOVALUE;
    int _26854 = NOVALUE;
    int _26852 = NOVALUE;
    int _26850 = NOVALUE;
    int _26848 = NOVALUE;
    int _26847 = NOVALUE;
    int _26845 = NOVALUE;
    int _26844 = NOVALUE;
    int _26843 = NOVALUE;
    int _26842 = NOVALUE;
    int _26841 = NOVALUE;
    int _26840 = NOVALUE;
    int _26839 = NOVALUE;
    int _26838 = NOVALUE;
    int _26837 = NOVALUE;
    int _26836 = NOVALUE;
    int _26835 = NOVALUE;
    int _26834 = NOVALUE;
    int _26833 = NOVALUE;
    int _26832 = NOVALUE;
    int _26831 = NOVALUE;
    int _26830 = NOVALUE;
    int _26829 = NOVALUE;
    int _26826 = NOVALUE;
    int _26825 = NOVALUE;
    int _26823 = NOVALUE;
    int _26822 = NOVALUE;
    int _26821 = NOVALUE;
    int _26820 = NOVALUE;
    int _26819 = NOVALUE;
    int _26817 = NOVALUE;
    int _26815 = NOVALUE;
    int _26814 = NOVALUE;
    int _26813 = NOVALUE;
    int _26812 = NOVALUE;
    int _26811 = NOVALUE;
    int _26810 = NOVALUE;
    int _26809 = NOVALUE;
    int _26808 = NOVALUE;
    int _26807 = NOVALUE;
    int _26804 = NOVALUE;
    int _26803 = NOVALUE;
    int _26801 = NOVALUE;
    int _26800 = NOVALUE;
    int _26799 = NOVALUE;
    int _26798 = NOVALUE;
    int _26797 = NOVALUE;
    int _26794 = NOVALUE;
    int _26793 = NOVALUE;
    int _26792 = NOVALUE;
    int _26791 = NOVALUE;
    int _26790 = NOVALUE;
    int _26789 = NOVALUE;
    int _26788 = NOVALUE;
    int _26783 = NOVALUE;
    int _26782 = NOVALUE;
    int _26781 = NOVALUE;
    int _26779 = NOVALUE;
    int _26778 = NOVALUE;
    int _26776 = NOVALUE;
    int _26775 = NOVALUE;
    int _26770 = NOVALUE;
    int _26769 = NOVALUE;
    int _26768 = NOVALUE;
    int _26767 = NOVALUE;
    int _26766 = NOVALUE;
    int _26760 = NOVALUE;
    int _26759 = NOVALUE;
    int _26757 = NOVALUE;
    int _26756 = NOVALUE;
    int _26755 = NOVALUE;
    int _26754 = NOVALUE;
    int _26753 = NOVALUE;
    int _26752 = NOVALUE;
    int _26750 = NOVALUE;
    int _26749 = NOVALUE;
    int _26748 = NOVALUE;
    int _26747 = NOVALUE;
    int _26746 = NOVALUE;
    int _26745 = NOVALUE;
    int _26744 = NOVALUE;
    int _26743 = NOVALUE;
    int _26742 = NOVALUE;
    int _26741 = NOVALUE;
    int _26740 = NOVALUE;
    int _26739 = NOVALUE;
    int _26738 = NOVALUE;
    int _26737 = NOVALUE;
    int _26735 = NOVALUE;
    int _26734 = NOVALUE;
    int _26733 = NOVALUE;
    int _26732 = NOVALUE;
    int _26729 = NOVALUE;
    int _26728 = NOVALUE;
    int _26727 = NOVALUE;
    int _26726 = NOVALUE;
    int _26724 = NOVALUE;
    int _26723 = NOVALUE;
    int _26722 = NOVALUE;
    int _26721 = NOVALUE;
    int _26719 = NOVALUE;
    int _26718 = NOVALUE;
    int _26717 = NOVALUE;
    int _26716 = NOVALUE;
    int _26715 = NOVALUE;
    int _26714 = NOVALUE;
    int _26713 = NOVALUE;
    int _26712 = NOVALUE;
    int _26711 = NOVALUE;
    int _26710 = NOVALUE;
    int _26709 = NOVALUE;
    int _26708 = NOVALUE;
    int _26707 = NOVALUE;
    int _26706 = NOVALUE;
    int _26704 = NOVALUE;
    int _26703 = NOVALUE;
    int _26702 = NOVALUE;
    int _26701 = NOVALUE;
    int _26700 = NOVALUE;
    int _26698 = NOVALUE;
    int _26697 = NOVALUE;
    int _26696 = NOVALUE;
    int _26695 = NOVALUE;
    int _26694 = NOVALUE;
    int _26690 = NOVALUE;
    int _26689 = NOVALUE;
    int _26688 = NOVALUE;
    int _26687 = NOVALUE;
    int _26686 = NOVALUE;
    int _26684 = NOVALUE;
    int _26683 = NOVALUE;
    int _26682 = NOVALUE;
    int _26681 = NOVALUE;
    int _26680 = NOVALUE;
    int _26679 = NOVALUE;
    int _26678 = NOVALUE;
    int _26677 = NOVALUE;
    int _26676 = NOVALUE;
    int _26675 = NOVALUE;
    int _26674 = NOVALUE;
    int _26673 = NOVALUE;
    int _26672 = NOVALUE;
    int _26671 = NOVALUE;
    int _26670 = NOVALUE;
    int _26669 = NOVALUE;
    int _26668 = NOVALUE;
    int _26667 = NOVALUE;
    int _26665 = NOVALUE;
    int _26664 = NOVALUE;
    int _26663 = NOVALUE;
    int _26662 = NOVALUE;
    int _26661 = NOVALUE;
    int _26660 = NOVALUE;
    int _26659 = NOVALUE;
    int _26658 = NOVALUE;
    int _26657 = NOVALUE;
    int _26655 = NOVALUE;
    int _26654 = NOVALUE;
    int _26653 = NOVALUE;
    int _26651 = NOVALUE;
    int _26650 = NOVALUE;
    int _26648 = NOVALUE;
    int _26646 = NOVALUE;
    int _26645 = NOVALUE;
    int _26644 = NOVALUE;
    int _26643 = NOVALUE;
    int _26642 = NOVALUE;
    int _26641 = NOVALUE;
    int _26637 = NOVALUE;
    int _26636 = NOVALUE;
    int _26635 = NOVALUE;
    int _26633 = NOVALUE;
    int _26632 = NOVALUE;
    int _26631 = NOVALUE;
    int _26630 = NOVALUE;
    int _26629 = NOVALUE;
    int _26628 = NOVALUE;
    int _26627 = NOVALUE;
    int _26626 = NOVALUE;
    int _26625 = NOVALUE;
    int _26624 = NOVALUE;
    int _26623 = NOVALUE;
    int _26622 = NOVALUE;
    int _26621 = NOVALUE;
    int _26620 = NOVALUE;
    int _26619 = NOVALUE;
    int _26614 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_op_51157)) {
        _1 = (long)(DBL_PTR(_op_51157)->dbl);
        DeRefDS(_op_51157);
        _op_51157 = _1;
    }

    /** 	integer ib, ic, n*/

    /** 	object obj*/

    /** 	sequence elements*/

    /** 	object element_vals*/

    /** 	check_for_temps()*/
    _41check_for_temps();

    /** 	integer last_pc_backup = last_pc*/
    _last_pc_backup_51174 = _41last_pc_51117;

    /** 	integer last_op_backup = last_op*/
    _last_op_backup_51175 = _41last_op_51116;

    /** 	last_op = op*/
    _41last_op_51116 = _op_51157;

    /** 	last_pc = length(Code) + 1*/
    if (IS_SEQUENCE(_35Code_16332)){
            _26614 = SEQ_PTR(_35Code_16332)->length;
    }
    else {
        _26614 = 1;
    }
    _41last_pc_51117 = _26614 + 1;
    _26614 = NOVALUE;

    /** 	switch op label "EMIT" do*/
    _0 = _op_51157;
    switch ( _0 ){ 

        /** 	case ASSIGN then*/
        case 18:

        /** 		sequence temp = {}*/
        RefDS(_22023);
        DeRef(_temp_51184);
        _temp_51184 = _22023;

        /** 		if not TRANSLATE and*/
        _26619 = (_35TRANSLATE_15887 == 0);
        if (_26619 == 0) {
            goto L1; // [70] 202
        }
        _26621 = (_35previous_op_16342 == 92);
        if (_26621 != 0) {
            DeRef(_26622);
            _26622 = 1;
            goto L2; // [82] 98
        }
        _26623 = (_35previous_op_16342 == 25);
        _26622 = (_26623 != 0);
L2: 
        if (_26622 == 0)
        {
            _26622 = NOVALUE;
            goto L1; // [99] 202
        }
        else{
            _26622 = NOVALUE;
        }

        /** 			while Code[$-1] = DEREF_TEMP and find( Code[$], derefs ) do*/
L3: 
        if (IS_SEQUENCE(_35Code_16332)){
                _26624 = SEQ_PTR(_35Code_16332)->length;
        }
        else {
            _26624 = 1;
        }
        _26625 = _26624 - 1;
        _26624 = NOVALUE;
        _2 = (int)SEQ_PTR(_35Code_16332);
        _26626 = (int)*(((s1_ptr)_2)->base + _26625);
        if (IS_ATOM_INT(_26626)) {
            _26627 = (_26626 == 208);
        }
        else {
            _26627 = binary_op(EQUALS, _26626, 208);
        }
        _26626 = NOVALUE;
        if (IS_ATOM_INT(_26627)) {
            if (_26627 == 0) {
                goto L4; // [126] 201
            }
        }
        else {
            if (DBL_PTR(_26627)->dbl == 0.0) {
                goto L4; // [126] 201
            }
        }
        if (IS_SEQUENCE(_35Code_16332)){
                _26629 = SEQ_PTR(_35Code_16332)->length;
        }
        else {
            _26629 = 1;
        }
        _2 = (int)SEQ_PTR(_35Code_16332);
        _26630 = (int)*(((s1_ptr)_2)->base + _26629);
        _26631 = find_from(_26630, _41derefs_50741, 1);
        _26630 = NOVALUE;
        if (_26631 == 0)
        {
            _26631 = NOVALUE;
            goto L4; // [147] 201
        }
        else{
            _26631 = NOVALUE;
        }

        /** 				temp &= Code[$]*/
        if (IS_SEQUENCE(_35Code_16332)){
                _26632 = SEQ_PTR(_35Code_16332)->length;
        }
        else {
            _26632 = 1;
        }
        _2 = (int)SEQ_PTR(_35Code_16332);
        _26633 = (int)*(((s1_ptr)_2)->base + _26632);
        if (IS_SEQUENCE(_temp_51184) && IS_ATOM(_26633)) {
            Ref(_26633);
            Append(&_temp_51184, _temp_51184, _26633);
        }
        else if (IS_ATOM(_temp_51184) && IS_SEQUENCE(_26633)) {
        }
        else {
            Concat((object_ptr)&_temp_51184, _temp_51184, _26633);
        }
        _26633 = NOVALUE;

        /** 				Code = remove( Code, length(Code)-1, length(Code) )*/
        if (IS_SEQUENCE(_35Code_16332)){
                _26635 = SEQ_PTR(_35Code_16332)->length;
        }
        else {
            _26635 = 1;
        }
        _26636 = _26635 - 1;
        _26635 = NOVALUE;
        if (IS_SEQUENCE(_35Code_16332)){
                _26637 = SEQ_PTR(_35Code_16332)->length;
        }
        else {
            _26637 = 1;
        }
        {
            s1_ptr assign_space = SEQ_PTR(_35Code_16332);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_26636)) ? _26636 : (long)(DBL_PTR(_26636)->dbl);
            int stop = (IS_ATOM_INT(_26637)) ? _26637 : (long)(DBL_PTR(_26637)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<0) {
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_35Code_16332), start, &_35Code_16332 );
                }
                else Tail(SEQ_PTR(_35Code_16332), stop+1, &_35Code_16332);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_35Code_16332), start, &_35Code_16332);
            }
            else {
                assign_slice_seq = &assign_space;
                _35Code_16332 = Remove_elements(start, stop, (SEQ_PTR(_35Code_16332)->ref == 1));
            }
        }
        _26636 = NOVALUE;
        _26637 = NOVALUE;

        /** 				emit_temp( temp, NEW_REFERENCE )*/
        RefDS(_temp_51184);
        _41emit_temp(_temp_51184, 1);

        /** 			end while*/
        goto L3; // [198] 107
L4: 
L1: 

        /** 		source = Pop()*/
        _source_51163 = _41Pop();
        if (!IS_ATOM_INT(_source_51163)) {
            _1 = (long)(DBL_PTR(_source_51163)->dbl);
            DeRefDS(_source_51163);
            _source_51163 = _1;
        }

        /** 		target = Pop()*/
        _target_51164 = _41Pop();
        if (!IS_ATOM_INT(_target_51164)) {
            _1 = (long)(DBL_PTR(_target_51164)->dbl);
            DeRefDS(_target_51164);
            _target_51164 = _1;
        }

        /** 		if assignable then*/
        if (_41assignable_50240 == 0)
        {
            goto L5; // [220] 601
        }
        else{
        }

        /** 			if inlined then*/
        if (_41inlined_51135 == 0)
        {
            goto L6; // [227] 326
        }
        else{
        }

        /** 				inlined = 0*/
        _41inlined_51135 = 0;

        /** 				if length( inlined_targets ) then*/
        if (IS_SEQUENCE(_41inlined_targets_51143)){
                _26641 = SEQ_PTR(_41inlined_targets_51143)->length;
        }
        else {
            _26641 = 1;
        }
        if (_26641 == 0)
        {
            _26641 = NOVALUE;
            goto L7; // [242] 295
        }
        else{
            _26641 = NOVALUE;
        }

        /** 					for i = 1 to length( inlined_targets ) do*/
        if (IS_SEQUENCE(_41inlined_targets_51143)){
                _26642 = SEQ_PTR(_41inlined_targets_51143)->length;
        }
        else {
            _26642 = 1;
        }
        {
            int _i_51227;
            _i_51227 = 1;
L8: 
            if (_i_51227 > _26642){
                goto L9; // [252] 280
            }

            /** 						Code[inlined_targets[i]] = target*/
            _2 = (int)SEQ_PTR(_41inlined_targets_51143);
            _26643 = (int)*(((s1_ptr)_2)->base + _i_51227);
            _2 = (int)SEQ_PTR(_35Code_16332);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _35Code_16332 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _26643);
            _1 = *(int *)_2;
            *(int *)_2 = _target_51164;
            DeRef(_1);

            /** 					end for*/
            _i_51227 = _i_51227 + 1;
            goto L8; // [275] 259
L9: 
            ;
        }

        /** 					clear_inline_targets()*/

        /** 	inlined_targets = {}*/
        RefDS(_22023);
        DeRefi(_41inlined_targets_51143);
        _41inlined_targets_51143 = _22023;

        /** end procedure*/
        goto LA; // [291] 294
LA: 
L7: 

        /** 				assignable = FALSE*/
        _41assignable_50240 = _13FALSE_434;

        /** 				clear_last()*/

        /** 	last_op = 0*/
        _41last_op_51116 = 0;

        /** 	last_pc = 0*/
        _41last_pc_51117 = 0;

        /** end procedure*/
        goto LB; // [316] 319
LB: 

        /** 				break "EMIT"*/
        DeRef(_temp_51184);
        _temp_51184 = NOVALUE;
        goto LC; // [323] 7412
L6: 

        /** 			clear_temp( Code[$] )*/
        if (IS_SEQUENCE(_35Code_16332)){
                _26644 = SEQ_PTR(_35Code_16332)->length;
        }
        else {
            _26644 = 1;
        }
        _2 = (int)SEQ_PTR(_35Code_16332);
        _26645 = (int)*(((s1_ptr)_2)->base + _26644);
        Ref(_26645);
        _41clear_temp(_26645);
        _26645 = NOVALUE;

        /** 			Code = remove( Code, length( Code ) ) -- drop previous target*/
        if (IS_SEQUENCE(_35Code_16332)){
                _26646 = SEQ_PTR(_35Code_16332)->length;
        }
        else {
            _26646 = 1;
        }
        {
            s1_ptr assign_space = SEQ_PTR(_35Code_16332);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_26646)) ? _26646 : (long)(DBL_PTR(_26646)->dbl);
            int stop = (IS_ATOM_INT(_26646)) ? _26646 : (long)(DBL_PTR(_26646)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<0) {
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_35Code_16332), start, &_35Code_16332 );
                }
                else Tail(SEQ_PTR(_35Code_16332), stop+1, &_35Code_16332);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_35Code_16332), start, &_35Code_16332);
            }
            else {
                assign_slice_seq = &assign_space;
                _35Code_16332 = Remove_elements(start, stop, (SEQ_PTR(_35Code_16332)->ref == 1));
            }
        }
        _26646 = NOVALUE;
        _26646 = NOVALUE;

        /** 			op = previous_op -- keep same previous op*/
        _op_51157 = _35previous_op_16342;

        /** 			if IsInteger(target) then*/
        _26648 = _41IsInteger(_target_51164);
        if (_26648 == 0) {
            DeRef(_26648);
            _26648 = NOVALUE;
            goto LD; // [372] 588
        }
        else {
            if (!IS_ATOM_INT(_26648) && DBL_PTR(_26648)->dbl == 0.0){
                DeRef(_26648);
                _26648 = NOVALUE;
                goto LD; // [372] 588
            }
            DeRef(_26648);
            _26648 = NOVALUE;
        }
        DeRef(_26648);
        _26648 = NOVALUE;

        /** 				if previous_op = RHS_SUBS then*/
        if (_35previous_op_16342 != 25)
        goto LE; // [381] 412

        /** 					op = RHS_SUBS_I*/
        _op_51157 = 114;

        /** 					backpatch(length(Code) - 2, op)*/
        if (IS_SEQUENCE(_35Code_16332)){
                _26650 = SEQ_PTR(_35Code_16332)->length;
        }
        else {
            _26650 = 1;
        }
        _26651 = _26650 - 2;
        _26650 = NOVALUE;
        _41backpatch(_26651, 114);
        _26651 = NOVALUE;
        goto LF; // [409] 587
LE: 

        /** 				elsif previous_op = PLUS1 then*/
        if (_35previous_op_16342 != 93)
        goto L10; // [418] 449

        /** 					op = PLUS1_I*/
        _op_51157 = 117;

        /** 					backpatch(length(Code) - 2, op)*/
        if (IS_SEQUENCE(_35Code_16332)){
                _26653 = SEQ_PTR(_35Code_16332)->length;
        }
        else {
            _26653 = 1;
        }
        _26654 = _26653 - 2;
        _26653 = NOVALUE;
        _41backpatch(_26654, 117);
        _26654 = NOVALUE;
        goto LF; // [446] 587
L10: 

        /** 				elsif previous_op = PLUS or previous_op = MINUS then*/
        _26655 = (_35previous_op_16342 == 11);
        if (_26655 != 0) {
            goto L11; // [459] 476
        }
        _26657 = (_35previous_op_16342 == 10);
        if (_26657 == 0)
        {
            DeRef(_26657);
            _26657 = NOVALUE;
            goto L12; // [472] 567
        }
        else{
            DeRef(_26657);
            _26657 = NOVALUE;
        }
L11: 

        /** 					if IsInteger(Code[$]) and*/
        if (IS_SEQUENCE(_35Code_16332)){
                _26658 = SEQ_PTR(_35Code_16332)->length;
        }
        else {
            _26658 = 1;
        }
        _2 = (int)SEQ_PTR(_35Code_16332);
        _26659 = (int)*(((s1_ptr)_2)->base + _26658);
        Ref(_26659);
        _26660 = _41IsInteger(_26659);
        _26659 = NOVALUE;
        if (IS_ATOM_INT(_26660)) {
            if (_26660 == 0) {
                goto LF; // [491] 587
            }
        }
        else {
            if (DBL_PTR(_26660)->dbl == 0.0) {
                goto LF; // [491] 587
            }
        }
        if (IS_SEQUENCE(_35Code_16332)){
                _26662 = SEQ_PTR(_35Code_16332)->length;
        }
        else {
            _26662 = 1;
        }
        _26663 = _26662 - 1;
        _26662 = NOVALUE;
        _2 = (int)SEQ_PTR(_35Code_16332);
        _26664 = (int)*(((s1_ptr)_2)->base + _26663);
        Ref(_26664);
        _26665 = _41IsInteger(_26664);
        _26664 = NOVALUE;
        if (_26665 == 0) {
            DeRef(_26665);
            _26665 = NOVALUE;
            goto LF; // [513] 587
        }
        else {
            if (!IS_ATOM_INT(_26665) && DBL_PTR(_26665)->dbl == 0.0){
                DeRef(_26665);
                _26665 = NOVALUE;
                goto LF; // [513] 587
            }
            DeRef(_26665);
            _26665 = NOVALUE;
        }
        DeRef(_26665);
        _26665 = NOVALUE;

        /** 						if previous_op = PLUS then*/
        if (_35previous_op_16342 != 11)
        goto L13; // [522] 538

        /** 							op = PLUS_I*/
        _op_51157 = 115;
        goto L14; // [535] 548
L13: 

        /** 							op = MINUS_I*/
        _op_51157 = 116;
L14: 

        /** 						backpatch(length(Code) - 2, op)*/
        if (IS_SEQUENCE(_35Code_16332)){
                _26667 = SEQ_PTR(_35Code_16332)->length;
        }
        else {
            _26667 = 1;
        }
        _26668 = _26667 - 2;
        _26667 = NOVALUE;
        _41backpatch(_26668, _op_51157);
        _26668 = NOVALUE;
        goto LF; // [564] 587
L12: 

        /** 					if IsInteger(source) then*/
        _26669 = _41IsInteger(_source_51163);
        if (_26669 == 0) {
            DeRef(_26669);
            _26669 = NOVALUE;
            goto L15; // [573] 586
        }
        else {
            if (!IS_ATOM_INT(_26669) && DBL_PTR(_26669)->dbl == 0.0){
                DeRef(_26669);
                _26669 = NOVALUE;
                goto L15; // [573] 586
            }
            DeRef(_26669);
            _26669 = NOVALUE;
        }
        DeRef(_26669);
        _26669 = NOVALUE;

        /** 						op = ASSIGN_I -- fake to avoid subsequent check*/
        _op_51157 = 113;
L15: 
LF: 
LD: 

        /** 			last_op = last_op_backup*/
        _41last_op_51116 = _last_op_backup_51175;

        /** 			last_pc = last_pc_backup*/
        _41last_pc_51117 = _last_pc_backup_51174;
        goto L16; // [598] 743
L5: 

        /** 			if IsInteger(source) and IsInteger(target) then*/
        _26670 = _41IsInteger(_source_51163);
        if (IS_ATOM_INT(_26670)) {
            if (_26670 == 0) {
                goto L17; // [607] 629
            }
        }
        else {
            if (DBL_PTR(_26670)->dbl == 0.0) {
                goto L17; // [607] 629
            }
        }
        _26672 = _41IsInteger(_target_51164);
        if (_26672 == 0) {
            DeRef(_26672);
            _26672 = NOVALUE;
            goto L17; // [616] 629
        }
        else {
            if (!IS_ATOM_INT(_26672) && DBL_PTR(_26672)->dbl == 0.0){
                DeRef(_26672);
                _26672 = NOVALUE;
                goto L17; // [616] 629
            }
            DeRef(_26672);
            _26672 = NOVALUE;
        }
        DeRef(_26672);
        _26672 = NOVALUE;

        /** 				op = ASSIGN_I*/
        _op_51157 = 113;
L17: 

        /** 			if source > 0 and target > 0 and*/
        _26673 = (_source_51163 > 0);
        if (_26673 == 0) {
            _26674 = 0;
            goto L18; // [635] 647
        }
        _26675 = (_target_51164 > 0);
        _26674 = (_26675 != 0);
L18: 
        if (_26674 == 0) {
            _26676 = 0;
            goto L19; // [647] 673
        }
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _26677 = (int)*(((s1_ptr)_2)->base + _source_51163);
        _2 = (int)SEQ_PTR(_26677);
        _26678 = (int)*(((s1_ptr)_2)->base + 3);
        _26677 = NOVALUE;
        if (IS_ATOM_INT(_26678)) {
            _26679 = (_26678 == 2);
        }
        else {
            _26679 = binary_op(EQUALS, _26678, 2);
        }
        _26678 = NOVALUE;
        if (IS_ATOM_INT(_26679))
        _26676 = (_26679 != 0);
        else
        _26676 = DBL_PTR(_26679)->dbl != 0.0;
L19: 
        if (_26676 == 0) {
            goto L1A; // [673] 727
        }
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _26681 = (int)*(((s1_ptr)_2)->base + _target_51164);
        _2 = (int)SEQ_PTR(_26681);
        _26682 = (int)*(((s1_ptr)_2)->base + 3);
        _26681 = NOVALUE;
        if (IS_ATOM_INT(_26682)) {
            _26683 = (_26682 == 2);
        }
        else {
            _26683 = binary_op(EQUALS, _26682, 2);
        }
        _26682 = NOVALUE;
        if (_26683 == 0) {
            DeRef(_26683);
            _26683 = NOVALUE;
            goto L1A; // [696] 727
        }
        else {
            if (!IS_ATOM_INT(_26683) && DBL_PTR(_26683)->dbl == 0.0){
                DeRef(_26683);
                _26683 = NOVALUE;
                goto L1A; // [696] 727
            }
            DeRef(_26683);
            _26683 = NOVALUE;
        }
        DeRef(_26683);
        _26683 = NOVALUE;

        /** 				SymTab[target][S_OBJ] = SymTab[source][S_OBJ]*/
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _36SymTab_15242 = MAKE_SEQ(_2);
        }
        _3 = (int)(_target_51164 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _26686 = (int)*(((s1_ptr)_2)->base + _source_51163);
        _2 = (int)SEQ_PTR(_26686);
        _26687 = (int)*(((s1_ptr)_2)->base + 1);
        _26686 = NOVALUE;
        Ref(_26687);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 1);
        _1 = *(int *)_2;
        *(int *)_2 = _26687;
        if( _1 != _26687 ){
            DeRef(_1);
        }
        _26687 = NOVALUE;
        _26684 = NOVALUE;
L1A: 

        /** 			emit_opcode(op)*/
        _41emit_opcode(_op_51157);

        /** 			emit_addr(source)*/
        _41emit_addr(_source_51163);

        /** 			last_op = op*/
        _41last_op_51116 = _op_51157;
L16: 

        /** 		assignable = FALSE*/
        _41assignable_50240 = _13FALSE_434;

        /** 		emit_addr(target)*/
        _41emit_addr(_target_51164);

        /** 		if length(temp) then*/
        if (IS_SEQUENCE(_temp_51184)){
                _26688 = SEQ_PTR(_temp_51184)->length;
        }
        else {
            _26688 = 1;
        }
        if (_26688 == 0)
        {
            _26688 = NOVALUE;
            goto L1B; // [760] 792
        }
        else{
            _26688 = NOVALUE;
        }

        /** 			for i = 1 to length( temp ) do*/
        if (IS_SEQUENCE(_temp_51184)){
                _26689 = SEQ_PTR(_temp_51184)->length;
        }
        else {
            _26689 = 1;
        }
        {
            int _i_51330;
            _i_51330 = 1;
L1C: 
            if (_i_51330 > _26689){
                goto L1D; // [768] 791
            }

            /** 				flush_temp( temp[i] )*/
            _2 = (int)SEQ_PTR(_temp_51184);
            _26690 = (int)*(((s1_ptr)_2)->base + _i_51330);
            Ref(_26690);
            _41flush_temp(_26690);
            _26690 = NOVALUE;

            /** 			end for*/
            _i_51330 = _i_51330 + 1;
            goto L1C; // [786] 775
L1D: 
            ;
        }
L1B: 
        DeRef(_temp_51184);
        _temp_51184 = NOVALUE;
        goto LC; // [794] 7412

        /** 	case RHS_SUBS then*/
        case 25:

        /** 		b = Pop() -- subscript*/
        _b_51160 = _41Pop();
        if (!IS_ATOM_INT(_b_51160)) {
            _1 = (long)(DBL_PTR(_b_51160)->dbl);
            DeRefDS(_b_51160);
            _b_51160 = _1;
        }

        /** 		c = Pop() -- sequence*/
        _c_51161 = _41Pop();
        if (!IS_ATOM_INT(_c_51161)) {
            _1 = (long)(DBL_PTR(_c_51161)->dbl);
            DeRefDS(_c_51161);
            _c_51161 = _1;
        }

        /** 		target = NewTempSym() -- target*/
        _target_51164 = _53NewTempSym(0);
        if (!IS_ATOM_INT(_target_51164)) {
            _1 = (long)(DBL_PTR(_target_51164)->dbl);
            DeRefDS(_target_51164);
            _target_51164 = _1;
        }

        /** 		if c < 0 or length(SymTab[c]) < S_VTYPE or SymTab[c][S_VTYPE] < 0 then -- forward reference*/
        _26694 = (_c_51161 < 0);
        if (_26694 != 0) {
            _26695 = 1;
            goto L1E; // [828] 851
        }
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _26696 = (int)*(((s1_ptr)_2)->base + _c_51161);
        if (IS_SEQUENCE(_26696)){
                _26697 = SEQ_PTR(_26696)->length;
        }
        else {
            _26697 = 1;
        }
        _26696 = NOVALUE;
        _26698 = (_26697 < 15);
        _26697 = NOVALUE;
        _26695 = (_26698 != 0);
L1E: 
        if (_26695 != 0) {
            goto L1F; // [851] 876
        }
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _26700 = (int)*(((s1_ptr)_2)->base + _c_51161);
        _2 = (int)SEQ_PTR(_26700);
        _26701 = (int)*(((s1_ptr)_2)->base + 15);
        _26700 = NOVALUE;
        if (IS_ATOM_INT(_26701)) {
            _26702 = (_26701 < 0);
        }
        else {
            _26702 = binary_op(LESS, _26701, 0);
        }
        _26701 = NOVALUE;
        if (_26702 == 0) {
            DeRef(_26702);
            _26702 = NOVALUE;
            goto L20; // [872] 888
        }
        else {
            if (!IS_ATOM_INT(_26702) && DBL_PTR(_26702)->dbl == 0.0){
                DeRef(_26702);
                _26702 = NOVALUE;
                goto L20; // [872] 888
            }
            DeRef(_26702);
            _26702 = NOVALUE;
        }
        DeRef(_26702);
        _26702 = NOVALUE;
L1F: 

        /** 			op = RHS_SUBS_CHECK*/
        _op_51157 = 92;
        goto L21; // [885] 1049
L20: 

        /** 		elsif SymTab[c][S_MODE] = M_NORMAL then*/
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _26703 = (int)*(((s1_ptr)_2)->base + _c_51161);
        _2 = (int)SEQ_PTR(_26703);
        _26704 = (int)*(((s1_ptr)_2)->base + 3);
        _26703 = NOVALUE;
        if (binary_op_a(NOTEQ, _26704, 1)){
            _26704 = NOVALUE;
            goto L22; // [904] 991
        }
        _26704 = NOVALUE;

        /** 			if SymTab[c][S_VTYPE] != sequence_type and*/
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _26706 = (int)*(((s1_ptr)_2)->base + _c_51161);
        _2 = (int)SEQ_PTR(_26706);
        _26707 = (int)*(((s1_ptr)_2)->base + 15);
        _26706 = NOVALUE;
        if (IS_ATOM_INT(_26707)) {
            _26708 = (_26707 != _53sequence_type_46095);
        }
        else {
            _26708 = binary_op(NOTEQ, _26707, _53sequence_type_46095);
        }
        _26707 = NOVALUE;
        if (IS_ATOM_INT(_26708)) {
            if (_26708 == 0) {
                goto L21; // [928] 1049
            }
        }
        else {
            if (DBL_PTR(_26708)->dbl == 0.0) {
                goto L21; // [928] 1049
            }
        }
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _26710 = (int)*(((s1_ptr)_2)->base + _c_51161);
        _2 = (int)SEQ_PTR(_26710);
        _26711 = (int)*(((s1_ptr)_2)->base + 15);
        _26710 = NOVALUE;
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        if (!IS_ATOM_INT(_26711)){
            _26712 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26711)->dbl));
        }
        else{
            _26712 = (int)*(((s1_ptr)_2)->base + _26711);
        }
        _2 = (int)SEQ_PTR(_26712);
        _26713 = (int)*(((s1_ptr)_2)->base + 2);
        _26712 = NOVALUE;
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        if (!IS_ATOM_INT(_26713)){
            _26714 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26713)->dbl));
        }
        else{
            _26714 = (int)*(((s1_ptr)_2)->base + _26713);
        }
        _2 = (int)SEQ_PTR(_26714);
        _26715 = (int)*(((s1_ptr)_2)->base + 15);
        _26714 = NOVALUE;
        if (IS_ATOM_INT(_26715)) {
            _26716 = (_26715 != _53sequence_type_46095);
        }
        else {
            _26716 = binary_op(NOTEQ, _26715, _53sequence_type_46095);
        }
        _26715 = NOVALUE;
        if (_26716 == 0) {
            DeRef(_26716);
            _26716 = NOVALUE;
            goto L21; // [975] 1049
        }
        else {
            if (!IS_ATOM_INT(_26716) && DBL_PTR(_26716)->dbl == 0.0){
                DeRef(_26716);
                _26716 = NOVALUE;
                goto L21; // [975] 1049
            }
            DeRef(_26716);
            _26716 = NOVALUE;
        }
        DeRef(_26716);
        _26716 = NOVALUE;

        /** 				op = RHS_SUBS_CHECK*/
        _op_51157 = 92;
        goto L21; // [988] 1049
L22: 

        /** 		elsif SymTab[c][S_MODE] != M_CONSTANT or*/
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _26717 = (int)*(((s1_ptr)_2)->base + _c_51161);
        _2 = (int)SEQ_PTR(_26717);
        _26718 = (int)*(((s1_ptr)_2)->base + 3);
        _26717 = NOVALUE;
        if (IS_ATOM_INT(_26718)) {
            _26719 = (_26718 != 2);
        }
        else {
            _26719 = binary_op(NOTEQ, _26718, 2);
        }
        _26718 = NOVALUE;
        if (IS_ATOM_INT(_26719)) {
            if (_26719 != 0) {
                goto L23; // [1011] 1038
            }
        }
        else {
            if (DBL_PTR(_26719)->dbl != 0.0) {
                goto L23; // [1011] 1038
            }
        }
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _26721 = (int)*(((s1_ptr)_2)->base + _c_51161);
        _2 = (int)SEQ_PTR(_26721);
        _26722 = (int)*(((s1_ptr)_2)->base + 1);
        _26721 = NOVALUE;
        _26723 = IS_SEQUENCE(_26722);
        _26722 = NOVALUE;
        _26724 = (_26723 == 0);
        _26723 = NOVALUE;
        if (_26724 == 0)
        {
            DeRef(_26724);
            _26724 = NOVALUE;
            goto L24; // [1034] 1048
        }
        else{
            DeRef(_26724);
            _26724 = NOVALUE;
        }
L23: 

        /** 			op = RHS_SUBS_CHECK*/
        _op_51157 = 92;
L24: 
L21: 

        /** 		emit_opcode(op)*/
        _41emit_opcode(_op_51157);

        /** 		emit_addr(c)*/
        _41emit_addr(_c_51161);

        /** 		emit_addr(b)*/
        _41emit_addr(_b_51160);

        /** 		assignable = TRUE*/
        _41assignable_50240 = _13TRUE_436;

        /** 		Push(target)*/
        _41Push(_target_51164);

        /** 		emit_addr(target)*/
        _41emit_addr(_target_51164);

        /** 		emit_temp(target, NEW_REFERENCE)*/
        _41emit_temp(_target_51164, 1);

        /** 		current_sequence = append(current_sequence, target)*/
        Append(&_41current_sequence_50230, _41current_sequence_50230, _target_51164);

        /** 		flush_temp( Code[$-2] )*/
        if (IS_SEQUENCE(_35Code_16332)){
                _26726 = SEQ_PTR(_35Code_16332)->length;
        }
        else {
            _26726 = 1;
        }
        _26727 = _26726 - 2;
        _26726 = NOVALUE;
        _2 = (int)SEQ_PTR(_35Code_16332);
        _26728 = (int)*(((s1_ptr)_2)->base + _26727);
        Ref(_26728);
        _41flush_temp(_26728);
        _26728 = NOVALUE;
        goto LC; // [1113] 7412

        /** 	case PROC then -- procedure, function and type calls*/
        case 27:

        /** 		assignable = FALSE -- assume for now*/
        _41assignable_50240 = _13FALSE_434;

        /** 		subsym = op_info1*/
        _subsym_51165 = _41op_info1_50222;

        /** 		n = SymTab[subsym][S_NUM_ARGS]*/
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _26729 = (int)*(((s1_ptr)_2)->base + _subsym_51165);
        _2 = (int)SEQ_PTR(_26729);
        if (!IS_ATOM_INT(_35S_NUM_ARGS_15968)){
            _n_51170 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NUM_ARGS_15968)->dbl));
        }
        else{
            _n_51170 = (int)*(((s1_ptr)_2)->base + _35S_NUM_ARGS_15968);
        }
        if (!IS_ATOM_INT(_n_51170)){
            _n_51170 = (long)DBL_PTR(_n_51170)->dbl;
        }
        _26729 = NOVALUE;

        /** 		if subsym = CurrentSub then*/
        if (_subsym_51165 != _35CurrentSub_16252)
        goto L25; // [1155] 1340

        /** 			for i = cgi-n+1 to cgi do*/
        _26732 = _41cgi_50238 - _n_51170;
        if ((long)((unsigned long)_26732 +(unsigned long) HIGH_BITS) >= 0){
            _26732 = NewDouble((double)_26732);
        }
        if (IS_ATOM_INT(_26732)) {
            _26733 = _26732 + 1;
            if (_26733 > MAXINT){
                _26733 = NewDouble((double)_26733);
            }
        }
        else
        _26733 = binary_op(PLUS, 1, _26732);
        DeRef(_26732);
        _26732 = NOVALUE;
        _26734 = _41cgi_50238;
        {
            int _i_51416;
            Ref(_26733);
            _i_51416 = _26733;
L26: 
            if (binary_op_a(GREATER, _i_51416, _26734)){
                goto L27; // [1176] 1339
            }

            /** 				if cg_stack[i] > 0 then -- if it's a forward reference, it's not a private*/
            _2 = (int)SEQ_PTR(_41cg_stack_50237);
            if (!IS_ATOM_INT(_i_51416)){
                _26735 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_51416)->dbl));
            }
            else{
                _26735 = (int)*(((s1_ptr)_2)->base + _i_51416);
            }
            if (binary_op_a(LESSEQ, _26735, 0)){
                _26735 = NOVALUE;
                goto L28; // [1191] 1332
            }
            _26735 = NOVALUE;

            /** 					if SymTab[cg_stack[i]][S_SCOPE] = SC_PRIVATE and*/
            _2 = (int)SEQ_PTR(_41cg_stack_50237);
            if (!IS_ATOM_INT(_i_51416)){
                _26737 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_51416)->dbl));
            }
            else{
                _26737 = (int)*(((s1_ptr)_2)->base + _i_51416);
            }
            _2 = (int)SEQ_PTR(_36SymTab_15242);
            if (!IS_ATOM_INT(_26737)){
                _26738 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26737)->dbl));
            }
            else{
                _26738 = (int)*(((s1_ptr)_2)->base + _26737);
            }
            _2 = (int)SEQ_PTR(_26738);
            _26739 = (int)*(((s1_ptr)_2)->base + 4);
            _26738 = NOVALUE;
            if (IS_ATOM_INT(_26739)) {
                _26740 = (_26739 == 3);
            }
            else {
                _26740 = binary_op(EQUALS, _26739, 3);
            }
            _26739 = NOVALUE;
            if (IS_ATOM_INT(_26740)) {
                if (_26740 == 0) {
                    goto L29; // [1221] 1299
                }
            }
            else {
                if (DBL_PTR(_26740)->dbl == 0.0) {
                    goto L29; // [1221] 1299
                }
            }
            _2 = (int)SEQ_PTR(_41cg_stack_50237);
            if (!IS_ATOM_INT(_i_51416)){
                _26742 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_51416)->dbl));
            }
            else{
                _26742 = (int)*(((s1_ptr)_2)->base + _i_51416);
            }
            _2 = (int)SEQ_PTR(_36SymTab_15242);
            if (!IS_ATOM_INT(_26742)){
                _26743 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26742)->dbl));
            }
            else{
                _26743 = (int)*(((s1_ptr)_2)->base + _26742);
            }
            _2 = (int)SEQ_PTR(_26743);
            _26744 = (int)*(((s1_ptr)_2)->base + 16);
            _26743 = NOVALUE;
            if (IS_ATOM_INT(_26744) && IS_ATOM_INT(_i_51416)) {
                _26745 = (_26744 < _i_51416);
            }
            else {
                _26745 = binary_op(LESS, _26744, _i_51416);
            }
            _26744 = NOVALUE;
            if (_26745 == 0) {
                DeRef(_26745);
                _26745 = NOVALUE;
                goto L29; // [1248] 1299
            }
            else {
                if (!IS_ATOM_INT(_26745) && DBL_PTR(_26745)->dbl == 0.0){
                    DeRef(_26745);
                    _26745 = NOVALUE;
                    goto L29; // [1248] 1299
                }
                DeRef(_26745);
                _26745 = NOVALUE;
            }
            DeRef(_26745);
            _26745 = NOVALUE;

            /** 						emit_opcode(ASSIGN)*/
            _41emit_opcode(18);

            /** 						emit_addr(cg_stack[i])*/
            _2 = (int)SEQ_PTR(_41cg_stack_50237);
            if (!IS_ATOM_INT(_i_51416)){
                _26746 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_51416)->dbl));
            }
            else{
                _26746 = (int)*(((s1_ptr)_2)->base + _i_51416);
            }
            Ref(_26746);
            _41emit_addr(_26746);
            _26746 = NOVALUE;

            /** 						cg_stack[i] = NewTempSym()*/
            _26747 = _53NewTempSym(0);
            _2 = (int)SEQ_PTR(_41cg_stack_50237);
            if (!IS_ATOM_INT(_i_51416))
            _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_51416)->dbl));
            else
            _2 = (int)(((s1_ptr)_2)->base + _i_51416);
            _1 = *(int *)_2;
            *(int *)_2 = _26747;
            if( _1 != _26747 ){
                DeRef(_1);
            }
            _26747 = NOVALUE;

            /** 						emit_addr(cg_stack[i])*/
            _2 = (int)SEQ_PTR(_41cg_stack_50237);
            if (!IS_ATOM_INT(_i_51416)){
                _26748 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_51416)->dbl));
            }
            else{
                _26748 = (int)*(((s1_ptr)_2)->base + _i_51416);
            }
            Ref(_26748);
            _41emit_addr(_26748);
            _26748 = NOVALUE;

            /** 						check_for_temps()*/
            _41check_for_temps();
            goto L2A; // [1296] 1331
L29: 

            /** 					elsif sym_mode( cg_stack[i] ) = M_TEMP then*/
            _2 = (int)SEQ_PTR(_41cg_stack_50237);
            if (!IS_ATOM_INT(_i_51416)){
                _26749 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_51416)->dbl));
            }
            else{
                _26749 = (int)*(((s1_ptr)_2)->base + _i_51416);
            }
            Ref(_26749);
            _26750 = _53sym_mode(_26749);
            _26749 = NOVALUE;
            if (binary_op_a(NOTEQ, _26750, 3)){
                DeRef(_26750);
                _26750 = NOVALUE;
                goto L2B; // [1313] 1330
            }
            DeRef(_26750);
            _26750 = NOVALUE;

            /** 						emit_temp( cg_stack[i], NEW_REFERENCE )*/
            _2 = (int)SEQ_PTR(_41cg_stack_50237);
            if (!IS_ATOM_INT(_i_51416)){
                _26752 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_51416)->dbl));
            }
            else{
                _26752 = (int)*(((s1_ptr)_2)->base + _i_51416);
            }
            Ref(_26752);
            _41emit_temp(_26752, 1);
            _26752 = NOVALUE;
L2B: 
L2A: 
L28: 

            /** 			end for*/
            _0 = _i_51416;
            if (IS_ATOM_INT(_i_51416)) {
                _i_51416 = _i_51416 + 1;
                if ((long)((unsigned long)_i_51416 +(unsigned long) HIGH_BITS) >= 0){
                    _i_51416 = NewDouble((double)_i_51416);
                }
            }
            else {
                _i_51416 = binary_op_a(PLUS, _i_51416, 1);
            }
            DeRef(_0);
            goto L26; // [1334] 1183
L27: 
            ;
            DeRef(_i_51416);
        }
L25: 

        /** 		emit_opcode(op)*/
        _41emit_opcode(_op_51157);

        /** 		emit_addr(subsym)*/
        _41emit_addr(_subsym_51165);

        /** 		for i = cgi-n+1 to cgi do*/
        _26753 = _41cgi_50238 - _n_51170;
        if ((long)((unsigned long)_26753 +(unsigned long) HIGH_BITS) >= 0){
            _26753 = NewDouble((double)_26753);
        }
        if (IS_ATOM_INT(_26753)) {
            _26754 = _26753 + 1;
            if (_26754 > MAXINT){
                _26754 = NewDouble((double)_26754);
            }
        }
        else
        _26754 = binary_op(PLUS, 1, _26753);
        DeRef(_26753);
        _26753 = NOVALUE;
        _26755 = _41cgi_50238;
        {
            int _i_51451;
            Ref(_26754);
            _i_51451 = _26754;
L2C: 
            if (binary_op_a(GREATER, _i_51451, _26755)){
                goto L2D; // [1367] 1404
            }

            /** 			emit_addr(cg_stack[i])*/
            _2 = (int)SEQ_PTR(_41cg_stack_50237);
            if (!IS_ATOM_INT(_i_51451)){
                _26756 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_51451)->dbl));
            }
            else{
                _26756 = (int)*(((s1_ptr)_2)->base + _i_51451);
            }
            Ref(_26756);
            _41emit_addr(_26756);
            _26756 = NOVALUE;

            /** 			emit_temp( cg_stack[i], NEW_REFERENCE )*/
            _2 = (int)SEQ_PTR(_41cg_stack_50237);
            if (!IS_ATOM_INT(_i_51451)){
                _26757 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_51451)->dbl));
            }
            else{
                _26757 = (int)*(((s1_ptr)_2)->base + _i_51451);
            }
            Ref(_26757);
            _41emit_temp(_26757, 1);
            _26757 = NOVALUE;

            /** 		end for*/
            _0 = _i_51451;
            if (IS_ATOM_INT(_i_51451)) {
                _i_51451 = _i_51451 + 1;
                if ((long)((unsigned long)_i_51451 +(unsigned long) HIGH_BITS) >= 0){
                    _i_51451 = NewDouble((double)_i_51451);
                }
            }
            else {
                _i_51451 = binary_op_a(PLUS, _i_51451, 1);
            }
            DeRef(_0);
            goto L2C; // [1399] 1374
L2D: 
            ;
            DeRef(_i_51451);
        }

        /** 		cgi -= n*/
        _41cgi_50238 = _41cgi_50238 - _n_51170;

        /** 		if SymTab[subsym][S_TOKEN] != PROC then*/
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _26759 = (int)*(((s1_ptr)_2)->base + _subsym_51165);
        _2 = (int)SEQ_PTR(_26759);
        if (!IS_ATOM_INT(_35S_TOKEN_15922)){
            _26760 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TOKEN_15922)->dbl));
        }
        else{
            _26760 = (int)*(((s1_ptr)_2)->base + _35S_TOKEN_15922);
        }
        _26759 = NOVALUE;
        if (binary_op_a(EQUALS, _26760, 27)){
            _26760 = NOVALUE;
            goto LC; // [1428] 7412
        }
        _26760 = NOVALUE;

        /** 			assignable = TRUE*/
        _41assignable_50240 = _13TRUE_436;

        /** 			c = NewTempSym() -- put final result in temp*/
        _c_51161 = _53NewTempSym(0);
        if (!IS_ATOM_INT(_c_51161)) {
            _1 = (long)(DBL_PTR(_c_51161)->dbl);
            DeRefDS(_c_51161);
            _c_51161 = _1;
        }

        /** 			emit_temp( c, NEW_REFERENCE )*/
        _41emit_temp(_c_51161, 1);

        /** 			Push(c)*/
        _41Push(_c_51161);

        /** 			emit_addr(c)*/
        _41emit_addr(_c_51161);
        goto LC; // [1464] 7412

        /** 	case PROC_FORWARD, FUNC_FORWARD then*/
        case 195:
        case 196:

        /** 		assignable = FALSE -- assume for now*/
        _41assignable_50240 = _13FALSE_434;

        /** 		integer real_op*/

        /** 		if op = PROC_FORWARD then*/
        if (_op_51157 != 195)
        goto L2E; // [1485] 1501

        /** 			real_op = PROC*/
        _real_op_51472 = 27;
        goto L2F; // [1498] 1511
L2E: 

        /** 			real_op = FUNC*/
        _real_op_51472 = 501;
L2F: 

        /** 		integer ref*/

        /** 		ref = new_forward_reference( real_op, op_info1, real_op )*/
        _ref_51479 = _38new_forward_reference(_real_op_51472, _41op_info1_50222, _real_op_51472);
        if (!IS_ATOM_INT(_ref_51479)) {
            _1 = (long)(DBL_PTR(_ref_51479)->dbl);
            DeRefDS(_ref_51479);
            _ref_51479 = _1;
        }

        /** 		n = Pop() -- number of known args*/
        _n_51170 = _41Pop();
        if (!IS_ATOM_INT(_n_51170)) {
            _1 = (long)(DBL_PTR(_n_51170)->dbl);
            DeRefDS(_n_51170);
            _n_51170 = _1;
        }

        /** 		emit_opcode(op)*/
        _41emit_opcode(_op_51157);

        /** 		emit_addr(ref)*/
        _41emit_addr(_ref_51479);

        /** 		emit_addr( n ) -- this changes to be the "next" instruction*/
        _41emit_addr(_n_51170);

        /** 		for i = cgi-n+1 to cgi do*/
        _26766 = _41cgi_50238 - _n_51170;
        if ((long)((unsigned long)_26766 +(unsigned long) HIGH_BITS) >= 0){
            _26766 = NewDouble((double)_26766);
        }
        if (IS_ATOM_INT(_26766)) {
            _26767 = _26766 + 1;
            if (_26767 > MAXINT){
                _26767 = NewDouble((double)_26767);
            }
        }
        else
        _26767 = binary_op(PLUS, 1, _26766);
        DeRef(_26766);
        _26766 = NOVALUE;
        _26768 = _41cgi_50238;
        {
            int _i_51484;
            Ref(_26767);
            _i_51484 = _26767;
L30: 
            if (binary_op_a(GREATER, _i_51484, _26768)){
                goto L31; // [1566] 1603
            }

            /** 			emit_addr(cg_stack[i])*/
            _2 = (int)SEQ_PTR(_41cg_stack_50237);
            if (!IS_ATOM_INT(_i_51484)){
                _26769 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_51484)->dbl));
            }
            else{
                _26769 = (int)*(((s1_ptr)_2)->base + _i_51484);
            }
            Ref(_26769);
            _41emit_addr(_26769);
            _26769 = NOVALUE;

            /** 			emit_temp( cg_stack[i], NEW_REFERENCE )*/
            _2 = (int)SEQ_PTR(_41cg_stack_50237);
            if (!IS_ATOM_INT(_i_51484)){
                _26770 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_51484)->dbl));
            }
            else{
                _26770 = (int)*(((s1_ptr)_2)->base + _i_51484);
            }
            Ref(_26770);
            _41emit_temp(_26770, 1);
            _26770 = NOVALUE;

            /** 		end for*/
            _0 = _i_51484;
            if (IS_ATOM_INT(_i_51484)) {
                _i_51484 = _i_51484 + 1;
                if ((long)((unsigned long)_i_51484 +(unsigned long) HIGH_BITS) >= 0){
                    _i_51484 = NewDouble((double)_i_51484);
                }
            }
            else {
                _i_51484 = binary_op_a(PLUS, _i_51484, 1);
            }
            DeRef(_0);
            goto L30; // [1598] 1573
L31: 
            ;
            DeRef(_i_51484);
        }

        /** 		cgi -= n*/
        _41cgi_50238 = _41cgi_50238 - _n_51170;

        /** 		if op != PROC_FORWARD then*/
        if (_op_51157 == 195)
        goto L32; // [1615] 1651

        /** 			assignable = TRUE*/
        _41assignable_50240 = _13TRUE_436;

        /** 			c = NewTempSym() -- put final result in temp*/
        _c_51161 = _53NewTempSym(0);
        if (!IS_ATOM_INT(_c_51161)) {
            _1 = (long)(DBL_PTR(_c_51161)->dbl);
            DeRefDS(_c_51161);
            _c_51161 = _1;
        }

        /** 			Push(c)*/
        _41Push(_c_51161);

        /** 			emit_addr(c)*/
        _41emit_addr(_c_51161);

        /** 			emit_temp( c, NEW_REFERENCE )*/
        _41emit_temp(_c_51161, 1);
L32: 
        goto LC; // [1653] 7412

        /** 	case WARNING then*/
        case 506:

        /** 		assignable = FALSE*/
        _41assignable_50240 = _13FALSE_434;

        /** 	    a = Pop()*/
        _a_51159 = _41Pop();
        if (!IS_ATOM_INT(_a_51159)) {
            _1 = (long)(DBL_PTR(_a_51159)->dbl);
            DeRefDS(_a_51159);
            _a_51159 = _1;
        }

        /** 		Warning(SymTab[a][S_OBJ], custom_warning_flag,"")*/
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _26775 = (int)*(((s1_ptr)_2)->base + _a_51159);
        _2 = (int)SEQ_PTR(_26775);
        _26776 = (int)*(((s1_ptr)_2)->base + 1);
        _26775 = NOVALUE;
        Ref(_26776);
        RefDS(_22023);
        _44Warning(_26776, 64, _22023);
        _26776 = NOVALUE;
        goto LC; // [1694] 7412

        /** 	case INCLUDE_PATHS then*/
        case 507:

        /** 		sequence paths*/

        /** 		assignable = TRUE*/
        _41assignable_50240 = _13TRUE_436;

        /** 	    a = Pop()*/
        _a_51159 = _41Pop();
        if (!IS_ATOM_INT(_a_51159)) {
            _1 = (long)(DBL_PTR(_a_51159)->dbl);
            DeRefDS(_a_51159);
            _a_51159 = _1;
        }

        /** 	    emit_opcode(RIGHT_BRACE_N)*/
        _41emit_opcode(31);

        /** 	    paths = Include_paths(SymTab[a][S_OBJ])*/
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _26778 = (int)*(((s1_ptr)_2)->base + _a_51159);
        _2 = (int)SEQ_PTR(_26778);
        _26779 = (int)*(((s1_ptr)_2)->base + 1);
        _26778 = NOVALUE;
        Ref(_26779);
        _0 = _paths_51509;
        _paths_51509 = _42Include_paths(_26779);
        DeRef(_0);
        _26779 = NOVALUE;

        /** 	    emit(length(paths))*/
        if (IS_SEQUENCE(_paths_51509)){
                _26781 = SEQ_PTR(_paths_51509)->length;
        }
        else {
            _26781 = 1;
        }
        _41emit(_26781);
        _26781 = NOVALUE;

        /** 	    for i=length(paths) to 1 by -1 do*/
        if (IS_SEQUENCE(_paths_51509)){
                _26782 = SEQ_PTR(_paths_51509)->length;
        }
        else {
            _26782 = 1;
        }
        {
            int _i_51521;
            _i_51521 = _26782;
L33: 
            if (_i_51521 < 1){
                goto L34; // [1756] 1787
            }

            /** 	        c = NewStringSym(paths[i])*/
            _2 = (int)SEQ_PTR(_paths_51509);
            _26783 = (int)*(((s1_ptr)_2)->base + _i_51521);
            Ref(_26783);
            _c_51161 = _53NewStringSym(_26783);
            _26783 = NOVALUE;
            if (!IS_ATOM_INT(_c_51161)) {
                _1 = (long)(DBL_PTR(_c_51161)->dbl);
                DeRefDS(_c_51161);
                _c_51161 = _1;
            }

            /** 	        emit_addr(c)*/
            _41emit_addr(_c_51161);

            /** 	    end for*/
            _i_51521 = _i_51521 + -1;
            goto L33; // [1782] 1763
L34: 
            ;
        }

        /** 	    b = NewTempSym()*/
        _b_51160 = _53NewTempSym(0);
        if (!IS_ATOM_INT(_b_51160)) {
            _1 = (long)(DBL_PTR(_b_51160)->dbl);
            DeRefDS(_b_51160);
            _b_51160 = _1;
        }

        /** 		emit_temp(b, NEW_REFERENCE)*/
        _41emit_temp(_b_51160, 1);

        /** 	    Push(b)*/
        _41Push(_b_51160);

        /** 	    emit_addr(b)*/
        _41emit_addr(_b_51160);

        /** 		last_op = RIGHT_BRACE_N*/
        _41last_op_51116 = 31;

        /** 		op = last_op*/
        _op_51157 = 31;
        DeRef(_paths_51509);
        _paths_51509 = NOVALUE;
        goto LC; // [1829] 7412

        /** 	case NOP1, NOP2, NOPWHILE, PRIVATE_INIT_CHECK, GLOBAL_INIT_CHECK,*/
        case 159:
        case 110:
        case 158:
        case 30:
        case 109:
        case 58:
        case 59:
        case 61:
        case 184:
        case 22:
        case 23:
        case 188:
        case 189:
        case 88:
        case 43:
        case 90:
        case 89:
        case 87:
        case 135:
        case 156:
        case 169:
        case 175:
        case 174:
        case 187:
        case 210:
        case 211:

        /** 		emit_opcode(op)*/
        _41emit_opcode(_op_51157);

        /** 		assignable = FALSE*/
        _41assignable_50240 = _13FALSE_434;

        /** 		if op = UPDATE_GLOBALS then*/
        if (_op_51157 != 89)
        goto LC; // [1901] 7412

        /** 			last_op = last_op_backup*/
        _41last_op_51116 = _last_op_backup_51175;

        /** 			last_pc = last_pc_backup*/
        _41last_pc_51117 = _last_pc_backup_51174;
        goto LC; // [1916] 7412

        /** 	case IF, WHILE then*/
        case 20:
        case 47:

        /** 		a = Pop()*/
        _a_51159 = _41Pop();
        if (!IS_ATOM_INT(_a_51159)) {
            _1 = (long)(DBL_PTR(_a_51159)->dbl);
            DeRefDS(_a_51159);
            _a_51159 = _1;
        }

        /** 		assignable = FALSE*/
        _41assignable_50240 = _13FALSE_434;

        /** 		if previous_op >= LESS and previous_op <= NOT then*/
        _26788 = (_35previous_op_16342 >= 1);
        if (_26788 == 0) {
            goto L35; // [1948] 2240
        }
        _26790 = (_35previous_op_16342 <= 7);
        if (_26790 == 0)
        {
            DeRef(_26790);
            _26790 = NOVALUE;
            goto L35; // [1961] 2240
        }
        else{
            DeRef(_26790);
            _26790 = NOVALUE;
        }

        /** 			clear_temp( Code[$] )*/
        if (IS_SEQUENCE(_35Code_16332)){
                _26791 = SEQ_PTR(_35Code_16332)->length;
        }
        else {
            _26791 = 1;
        }
        _2 = (int)SEQ_PTR(_35Code_16332);
        _26792 = (int)*(((s1_ptr)_2)->base + _26791);
        Ref(_26792);
        _41clear_temp(_26792);
        _26792 = NOVALUE;

        /** 			Code = Code[1..$-1]*/
        if (IS_SEQUENCE(_35Code_16332)){
                _26793 = SEQ_PTR(_35Code_16332)->length;
        }
        else {
            _26793 = 1;
        }
        _26794 = _26793 - 1;
        _26793 = NOVALUE;
        rhs_slice_target = (object_ptr)&_35Code_16332;
        RHS_Slice(_35Code_16332, 1, _26794);

        /** 			if previous_op = NOT then*/
        if (_35previous_op_16342 != 7)
        goto L36; // [2002] 2082

        /** 				op = NOT_IFW*/
        _op_51157 = 108;

        /** 				backpatch(length(Code) - 1, op)*/
        if (IS_SEQUENCE(_35Code_16332)){
                _26797 = SEQ_PTR(_35Code_16332)->length;
        }
        else {
            _26797 = 1;
        }
        _26798 = _26797 - 1;
        _26797 = NOVALUE;
        _41backpatch(_26798, 108);
        _26798 = NOVALUE;

        /** 				sequence if_code = Code[$-1..$]*/
        if (IS_SEQUENCE(_35Code_16332)){
                _26799 = SEQ_PTR(_35Code_16332)->length;
        }
        else {
            _26799 = 1;
        }
        _26800 = _26799 - 1;
        _26799 = NOVALUE;
        if (IS_SEQUENCE(_35Code_16332)){
                _26801 = SEQ_PTR(_35Code_16332)->length;
        }
        else {
            _26801 = 1;
        }
        rhs_slice_target = (object_ptr)&_if_code_51589;
        RHS_Slice(_35Code_16332, _26800, _26801);

        /** 				Code = Code[1..$-2]*/
        if (IS_SEQUENCE(_35Code_16332)){
                _26803 = SEQ_PTR(_35Code_16332)->length;
        }
        else {
            _26803 = 1;
        }
        _26804 = _26803 - 2;
        _26803 = NOVALUE;
        rhs_slice_target = (object_ptr)&_35Code_16332;
        RHS_Slice(_35Code_16332, 1, _26804);

        /** 				Code &= if_code*/
        Concat((object_ptr)&_35Code_16332, _35Code_16332, _if_code_51589);
        DeRefDS(_if_code_51589);
        _if_code_51589 = NOVALUE;
        goto L37; // [2079] 2227
L36: 

        /** 				if IsInteger(Code[$-1]) and IsInteger(Code[$]) then*/
        if (IS_SEQUENCE(_35Code_16332)){
                _26807 = SEQ_PTR(_35Code_16332)->length;
        }
        else {
            _26807 = 1;
        }
        _26808 = _26807 - 1;
        _26807 = NOVALUE;
        _2 = (int)SEQ_PTR(_35Code_16332);
        _26809 = (int)*(((s1_ptr)_2)->base + _26808);
        Ref(_26809);
        _26810 = _41IsInteger(_26809);
        _26809 = NOVALUE;
        if (IS_ATOM_INT(_26810)) {
            if (_26810 == 0) {
                goto L38; // [2101] 2143
            }
        }
        else {
            if (DBL_PTR(_26810)->dbl == 0.0) {
                goto L38; // [2101] 2143
            }
        }
        if (IS_SEQUENCE(_35Code_16332)){
                _26812 = SEQ_PTR(_35Code_16332)->length;
        }
        else {
            _26812 = 1;
        }
        _2 = (int)SEQ_PTR(_35Code_16332);
        _26813 = (int)*(((s1_ptr)_2)->base + _26812);
        Ref(_26813);
        _26814 = _41IsInteger(_26813);
        _26813 = NOVALUE;
        if (_26814 == 0) {
            DeRef(_26814);
            _26814 = NOVALUE;
            goto L38; // [2119] 2143
        }
        else {
            if (!IS_ATOM_INT(_26814) && DBL_PTR(_26814)->dbl == 0.0){
                DeRef(_26814);
                _26814 = NOVALUE;
                goto L38; // [2119] 2143
            }
            DeRef(_26814);
            _26814 = NOVALUE;
        }
        DeRef(_26814);
        _26814 = NOVALUE;

        /** 					op = previous_op + LESS_IFW_I - LESS*/
        _26815 = _35previous_op_16342 + 119;
        if ((long)((unsigned long)_26815 + (unsigned long)HIGH_BITS) >= 0) 
        _26815 = NewDouble((double)_26815);
        if (IS_ATOM_INT(_26815)) {
            _op_51157 = _26815 - 1;
        }
        else {
            _op_51157 = NewDouble(DBL_PTR(_26815)->dbl - (double)1);
        }
        DeRef(_26815);
        _26815 = NOVALUE;
        if (!IS_ATOM_INT(_op_51157)) {
            _1 = (long)(DBL_PTR(_op_51157)->dbl);
            DeRefDS(_op_51157);
            _op_51157 = _1;
        }
        goto L39; // [2140] 2162
L38: 

        /** 					op = previous_op + LESS_IFW - LESS*/
        _26817 = _35previous_op_16342 + 102;
        if ((long)((unsigned long)_26817 + (unsigned long)HIGH_BITS) >= 0) 
        _26817 = NewDouble((double)_26817);
        if (IS_ATOM_INT(_26817)) {
            _op_51157 = _26817 - 1;
        }
        else {
            _op_51157 = NewDouble(DBL_PTR(_26817)->dbl - (double)1);
        }
        DeRef(_26817);
        _26817 = NOVALUE;
        if (!IS_ATOM_INT(_op_51157)) {
            _1 = (long)(DBL_PTR(_op_51157)->dbl);
            DeRefDS(_op_51157);
            _op_51157 = _1;
        }
L39: 

        /** 				backpatch(length(Code) - 2, op)*/
        if (IS_SEQUENCE(_35Code_16332)){
                _26819 = SEQ_PTR(_35Code_16332)->length;
        }
        else {
            _26819 = 1;
        }
        _26820 = _26819 - 2;
        _26819 = NOVALUE;
        _41backpatch(_26820, _op_51157);
        _26820 = NOVALUE;

        /** 				sequence if_code = Code[$-2..$]*/
        if (IS_SEQUENCE(_35Code_16332)){
                _26821 = SEQ_PTR(_35Code_16332)->length;
        }
        else {
            _26821 = 1;
        }
        _26822 = _26821 - 2;
        _26821 = NOVALUE;
        if (IS_SEQUENCE(_35Code_16332)){
                _26823 = SEQ_PTR(_35Code_16332)->length;
        }
        else {
            _26823 = 1;
        }
        rhs_slice_target = (object_ptr)&_if_code_51628;
        RHS_Slice(_35Code_16332, _26822, _26823);

        /** 				Code = Code[1..$-3]*/
        if (IS_SEQUENCE(_35Code_16332)){
                _26825 = SEQ_PTR(_35Code_16332)->length;
        }
        else {
            _26825 = 1;
        }
        _26826 = _26825 - 3;
        _26825 = NOVALUE;
        rhs_slice_target = (object_ptr)&_35Code_16332;
        RHS_Slice(_35Code_16332, 1, _26826);

        /** 				Code &= if_code*/
        Concat((object_ptr)&_35Code_16332, _35Code_16332, _if_code_51628);
        DeRefDS(_if_code_51628);
        _if_code_51628 = NOVALUE;
L37: 

        /** 			last_pc = last_pc_backup*/
        _41last_pc_51117 = _last_pc_backup_51174;

        /** 			last_op = op*/
        _41last_op_51116 = _op_51157;
        goto LC; // [2237] 7412
L35: 

        /** 		elsif op = WHILE and*/
        _26829 = (_op_51157 == 47);
        if (_26829 == 0) {
            _26830 = 0;
            goto L3A; // [2248] 2260
        }
        _26831 = (_a_51159 > 0);
        _26830 = (_26831 != 0);
L3A: 
        if (_26830 == 0) {
            _26832 = 0;
            goto L3B; // [2260] 2286
        }
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _26833 = (int)*(((s1_ptr)_2)->base + _a_51159);
        _2 = (int)SEQ_PTR(_26833);
        _26834 = (int)*(((s1_ptr)_2)->base + 3);
        _26833 = NOVALUE;
        if (IS_ATOM_INT(_26834)) {
            _26835 = (_26834 == 2);
        }
        else {
            _26835 = binary_op(EQUALS, _26834, 2);
        }
        _26834 = NOVALUE;
        if (IS_ATOM_INT(_26835))
        _26832 = (_26835 != 0);
        else
        _26832 = DBL_PTR(_26835)->dbl != 0.0;
L3B: 
        if (_26832 == 0) {
            _26836 = 0;
            goto L3C; // [2286] 2309
        }
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _26837 = (int)*(((s1_ptr)_2)->base + _a_51159);
        _2 = (int)SEQ_PTR(_26837);
        _26838 = (int)*(((s1_ptr)_2)->base + 1);
        _26837 = NOVALUE;
        if (IS_ATOM_INT(_26838))
        _26839 = 1;
        else if (IS_ATOM_DBL(_26838))
        _26839 = IS_ATOM_INT(DoubleToInt(_26838));
        else
        _26839 = 0;
        _26838 = NOVALUE;
        _26836 = (_26839 != 0);
L3C: 
        if (_26836 == 0) {
            goto L3D; // [2309] 2358
        }
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _26841 = (int)*(((s1_ptr)_2)->base + _a_51159);
        _2 = (int)SEQ_PTR(_26841);
        _26842 = (int)*(((s1_ptr)_2)->base + 1);
        _26841 = NOVALUE;
        if (_26842 == 0)
        _26843 = 1;
        else if (IS_ATOM_INT(_26842) && IS_ATOM_INT(0))
        _26843 = 0;
        else
        _26843 = (compare(_26842, 0) == 0);
        _26842 = NOVALUE;
        _26844 = (_26843 == 0);
        _26843 = NOVALUE;
        if (_26844 == 0)
        {
            DeRef(_26844);
            _26844 = NOVALUE;
            goto L3D; // [2333] 2358
        }
        else{
            DeRef(_26844);
            _26844 = NOVALUE;
        }

        /** 			optimized_while = TRUE   -- while TRUE ... emit nothing*/
        _41optimized_while_50224 = _13TRUE_436;

        /** 			last_pc = last_pc_backup*/
        _41last_pc_51117 = _last_pc_backup_51174;

        /** 			last_op = last_op_backup*/
        _41last_op_51116 = _last_op_backup_51175;
        goto LC; // [2355] 7412
L3D: 

        /** 			flush_temps( {a} )*/
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = _a_51159;
        _26845 = MAKE_SEQ(_1);
        _41flush_temps(_26845);
        _26845 = NOVALUE;

        /** 			emit_opcode(op)*/
        _41emit_opcode(_op_51157);

        /** 			emit_addr(a)*/
        _41emit_addr(_a_51159);
        goto LC; // [2378] 7412

        /** 	case INTEGER_CHECK then*/
        case 96:

        /** 		assignable = FALSE*/
        _41assignable_50240 = _13FALSE_434;

        /** 		if previous_op = ASSIGN then*/
        if (_35previous_op_16342 != 18)
        goto L3E; // [2397] 2456

        /** 			c = Code[$-1]*/
        if (IS_SEQUENCE(_35Code_16332)){
                _26847 = SEQ_PTR(_35Code_16332)->length;
        }
        else {
            _26847 = 1;
        }
        _26848 = _26847 - 1;
        _26847 = NOVALUE;
        _2 = (int)SEQ_PTR(_35Code_16332);
        _c_51161 = (int)*(((s1_ptr)_2)->base + _26848);
        if (!IS_ATOM_INT(_c_51161)){
            _c_51161 = (long)DBL_PTR(_c_51161)->dbl;
        }

        /** 			if not IsInteger(c) then*/
        _26850 = _41IsInteger(_c_51161);
        if (IS_ATOM_INT(_26850)) {
            if (_26850 != 0){
                DeRef(_26850);
                _26850 = NOVALUE;
                goto L3F; // [2424] 2442
            }
        }
        else {
            if (DBL_PTR(_26850)->dbl != 0.0){
                DeRef(_26850);
                _26850 = NOVALUE;
                goto L3F; // [2424] 2442
            }
        }
        DeRef(_26850);
        _26850 = NOVALUE;

        /** 				emit_opcode(op)*/
        _41emit_opcode(_op_51157);

        /** 				emit_addr(op_info1)*/
        _41emit_addr(_41op_info1_50222);
        goto L40; // [2439] 2513
L3F: 

        /** 				last_op = last_op_backup*/
        _41last_op_51116 = _last_op_backup_51175;

        /** 				last_pc = last_pc_backup*/
        _41last_pc_51117 = _last_pc_backup_51174;
        goto L40; // [2453] 2513
L3E: 

        /** 		elsif previous_op = -1 or*/
        _26852 = (_35previous_op_16342 == -1);
        if (_26852 != 0) {
            goto L41; // [2464] 2487
        }
        _2 = (int)SEQ_PTR(_41op_result_50838);
        _26854 = (int)*(((s1_ptr)_2)->base + _35previous_op_16342);
        _26855 = (_26854 != 1);
        _26854 = NOVALUE;
        if (_26855 == 0)
        {
            DeRef(_26855);
            _26855 = NOVALUE;
            goto L42; // [2483] 2502
        }
        else{
            DeRef(_26855);
            _26855 = NOVALUE;
        }
L41: 

        /** 			emit_opcode(op)*/
        _41emit_opcode(_op_51157);

        /** 			emit_addr(op_info1)*/
        _41emit_addr(_41op_info1_50222);
        goto L40; // [2499] 2513
L42: 

        /** 			last_op = last_op_backup*/
        _41last_op_51116 = _last_op_backup_51175;

        /** 			last_pc = last_pc_backup*/
        _41last_pc_51117 = _last_pc_backup_51174;
L40: 

        /** 		clear_temp( Code[$-1] )*/
        if (IS_SEQUENCE(_35Code_16332)){
                _26856 = SEQ_PTR(_35Code_16332)->length;
        }
        else {
            _26856 = 1;
        }
        _26857 = _26856 - 1;
        _26856 = NOVALUE;
        _2 = (int)SEQ_PTR(_35Code_16332);
        _26858 = (int)*(((s1_ptr)_2)->base + _26857);
        Ref(_26858);
        _41clear_temp(_26858);
        _26858 = NOVALUE;
        goto LC; // [2531] 7412

        /** 	case SEQUENCE_CHECK then*/
        case 97:

        /** 		assignable = FALSE*/
        _41assignable_50240 = _13FALSE_434;

        /** 		if previous_op = ASSIGN then*/
        if (_35previous_op_16342 != 18)
        goto L43; // [2550] 2677

        /** 			c = Code[$-1]*/
        if (IS_SEQUENCE(_35Code_16332)){
                _26860 = SEQ_PTR(_35Code_16332)->length;
        }
        else {
            _26860 = 1;
        }
        _26861 = _26860 - 1;
        _26860 = NOVALUE;
        _2 = (int)SEQ_PTR(_35Code_16332);
        _c_51161 = (int)*(((s1_ptr)_2)->base + _26861);
        if (!IS_ATOM_INT(_c_51161)){
            _c_51161 = (long)DBL_PTR(_c_51161)->dbl;
        }

        /** 			if c < 1 or*/
        _26863 = (_c_51161 < 1);
        if (_26863 != 0) {
            _26864 = 1;
            goto L44; // [2577] 2603
        }
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _26865 = (int)*(((s1_ptr)_2)->base + _c_51161);
        _2 = (int)SEQ_PTR(_26865);
        _26866 = (int)*(((s1_ptr)_2)->base + 3);
        _26865 = NOVALUE;
        if (IS_ATOM_INT(_26866)) {
            _26867 = (_26866 != 2);
        }
        else {
            _26867 = binary_op(NOTEQ, _26866, 2);
        }
        _26866 = NOVALUE;
        if (IS_ATOM_INT(_26867))
        _26864 = (_26867 != 0);
        else
        _26864 = DBL_PTR(_26867)->dbl != 0.0;
L44: 
        if (_26864 != 0) {
            goto L45; // [2603] 2630
        }
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _26869 = (int)*(((s1_ptr)_2)->base + _c_51161);
        _2 = (int)SEQ_PTR(_26869);
        _26870 = (int)*(((s1_ptr)_2)->base + 1);
        _26869 = NOVALUE;
        _26871 = IS_SEQUENCE(_26870);
        _26870 = NOVALUE;
        _26872 = (_26871 == 0);
        _26871 = NOVALUE;
        if (_26872 == 0)
        {
            DeRef(_26872);
            _26872 = NOVALUE;
            goto L46; // [2626] 2663
        }
        else{
            DeRef(_26872);
            _26872 = NOVALUE;
        }
L45: 

        /** 				emit_opcode(op)*/
        _41emit_opcode(_op_51157);

        /** 				emit_addr(op_info1)*/
        _41emit_addr(_41op_info1_50222);

        /** 				clear_temp( Code[$-1] )*/
        if (IS_SEQUENCE(_35Code_16332)){
                _26873 = SEQ_PTR(_35Code_16332)->length;
        }
        else {
            _26873 = 1;
        }
        _26874 = _26873 - 1;
        _26873 = NOVALUE;
        _2 = (int)SEQ_PTR(_35Code_16332);
        _26875 = (int)*(((s1_ptr)_2)->base + _26874);
        Ref(_26875);
        _41clear_temp(_26875);
        _26875 = NOVALUE;
        goto LC; // [2660] 7412
L46: 

        /** 				last_op = last_op_backup*/
        _41last_op_51116 = _last_op_backup_51175;

        /** 				last_pc = last_pc_backup*/
        _41last_pc_51117 = _last_pc_backup_51174;
        goto LC; // [2674] 7412
L43: 

        /** 		elsif previous_op = -1 or op_result[previous_op] != T_SEQUENCE then*/
        _26876 = (_35previous_op_16342 == -1);
        if (_26876 != 0) {
            goto L47; // [2685] 2708
        }
        _2 = (int)SEQ_PTR(_41op_result_50838);
        _26878 = (int)*(((s1_ptr)_2)->base + _35previous_op_16342);
        _26879 = (_26878 != 2);
        _26878 = NOVALUE;
        if (_26879 == 0)
        {
            DeRef(_26879);
            _26879 = NOVALUE;
            goto L48; // [2704] 2741
        }
        else{
            DeRef(_26879);
            _26879 = NOVALUE;
        }
L47: 

        /** 			emit_opcode(op)*/
        _41emit_opcode(_op_51157);

        /** 			emit_addr(op_info1)*/
        _41emit_addr(_41op_info1_50222);

        /** 			clear_temp( Code[$-1] )*/
        if (IS_SEQUENCE(_35Code_16332)){
                _26880 = SEQ_PTR(_35Code_16332)->length;
        }
        else {
            _26880 = 1;
        }
        _26881 = _26880 - 1;
        _26880 = NOVALUE;
        _2 = (int)SEQ_PTR(_35Code_16332);
        _26882 = (int)*(((s1_ptr)_2)->base + _26881);
        Ref(_26882);
        _41clear_temp(_26882);
        _26882 = NOVALUE;
        goto LC; // [2738] 7412
L48: 

        /** 			last_op = last_op_backup*/
        _41last_op_51116 = _last_op_backup_51175;

        /** 			last_pc = last_pc_backup*/
        _41last_pc_51117 = _last_pc_backup_51174;
        goto LC; // [2752] 7412

        /** 	case ATOM_CHECK then*/
        case 101:

        /** 		assignable = FALSE*/
        _41assignable_50240 = _13FALSE_434;

        /** 		if previous_op = ASSIGN then*/
        if (_35previous_op_16342 != 18)
        goto L49; // [2771] 2970

        /** 			c = Code[$-1]*/
        if (IS_SEQUENCE(_35Code_16332)){
                _26884 = SEQ_PTR(_35Code_16332)->length;
        }
        else {
            _26884 = 1;
        }
        _26885 = _26884 - 1;
        _26884 = NOVALUE;
        _2 = (int)SEQ_PTR(_35Code_16332);
        _c_51161 = (int)*(((s1_ptr)_2)->base + _26885);
        if (!IS_ATOM_INT(_c_51161)){
            _c_51161 = (long)DBL_PTR(_c_51161)->dbl;
        }

        /** 			if c > 1*/
        _26887 = (_c_51161 > 1);
        if (_26887 == 0) {
            goto L4A; // [2798] 2919
        }
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _26889 = (int)*(((s1_ptr)_2)->base + _c_51161);
        _2 = (int)SEQ_PTR(_26889);
        _26890 = (int)*(((s1_ptr)_2)->base + 3);
        _26889 = NOVALUE;
        if (IS_ATOM_INT(_26890)) {
            _26891 = (_26890 == 2);
        }
        else {
            _26891 = binary_op(EQUALS, _26890, 2);
        }
        _26890 = NOVALUE;
        if (_26891 == 0) {
            DeRef(_26891);
            _26891 = NOVALUE;
            goto L4A; // [2821] 2919
        }
        else {
            if (!IS_ATOM_INT(_26891) && DBL_PTR(_26891)->dbl == 0.0){
                DeRef(_26891);
                _26891 = NOVALUE;
                goto L4A; // [2821] 2919
            }
            DeRef(_26891);
            _26891 = NOVALUE;
        }
        DeRef(_26891);
        _26891 = NOVALUE;

        /** 				if sequence( SymTab[c][S_OBJ] ) then*/
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _26892 = (int)*(((s1_ptr)_2)->base + _c_51161);
        _2 = (int)SEQ_PTR(_26892);
        _26893 = (int)*(((s1_ptr)_2)->base + 1);
        _26892 = NOVALUE;
        _26894 = IS_SEQUENCE(_26893);
        _26893 = NOVALUE;
        if (_26894 == 0)
        {
            _26894 = NOVALUE;
            goto L4B; // [2841] 2870
        }
        else{
            _26894 = NOVALUE;
        }

        /** 					ThisLine = ExprLine*/
        RefDS(_39ExprLine_56169);
        DeRef(_44ThisLine_48518);
        _44ThisLine_48518 = _39ExprLine_56169;

        /** 					bp = expr_bp*/
        _44bp_48522 = _39expr_bp_56170;

        /** 					CompileErr( 346 )*/
        RefDS(_22023);
        _44CompileErr(346, _22023, 0);
        goto L4C; // [2867] 3049
L4B: 

        /** 				elsif SymTab[c][S_OBJ] = NOVALUE then*/
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _26895 = (int)*(((s1_ptr)_2)->base + _c_51161);
        _2 = (int)SEQ_PTR(_26895);
        _26896 = (int)*(((s1_ptr)_2)->base + 1);
        _26895 = NOVALUE;
        if (binary_op_a(NOTEQ, _26896, _35NOVALUE_16099)){
            _26896 = NOVALUE;
            goto L4D; // [2886] 2905
        }
        _26896 = NOVALUE;

        /** 					emit_opcode(op)*/
        _41emit_opcode(_op_51157);

        /** 					emit_addr(op_info1)*/
        _41emit_addr(_41op_info1_50222);
        goto L4C; // [2902] 3049
L4D: 

        /** 					last_op = last_op_backup*/
        _41last_op_51116 = _last_op_backup_51175;

        /** 					last_pc = last_pc_backup*/
        _41last_pc_51117 = _last_pc_backup_51174;
        goto L4C; // [2916] 3049
L4A: 

        /** 			elsif c < 1 */
        _26898 = (_c_51161 < 1);
        if (_26898 != 0) {
            goto L4E; // [2925] 2941
        }
        _26900 = _41IsInteger(_c_51161);
        if (IS_ATOM_INT(_26900)) {
            _26901 = (_26900 == 0);
        }
        else {
            _26901 = unary_op(NOT, _26900);
        }
        DeRef(_26900);
        _26900 = NOVALUE;
        if (_26901 == 0) {
            DeRef(_26901);
            _26901 = NOVALUE;
            goto L4F; // [2937] 2956
        }
        else {
            if (!IS_ATOM_INT(_26901) && DBL_PTR(_26901)->dbl == 0.0){
                DeRef(_26901);
                _26901 = NOVALUE;
                goto L4F; // [2937] 2956
            }
            DeRef(_26901);
            _26901 = NOVALUE;
        }
        DeRef(_26901);
        _26901 = NOVALUE;
L4E: 

        /** 				emit_opcode(op)*/
        _41emit_opcode(_op_51157);

        /** 				emit_addr(op_info1)*/
        _41emit_addr(_41op_info1_50222);
        goto L4C; // [2953] 3049
L4F: 

        /** 				last_op = last_op_backup*/
        _41last_op_51116 = _last_op_backup_51175;

        /** 				last_pc = last_pc_backup*/
        _41last_pc_51117 = _last_pc_backup_51174;
        goto L4C; // [2967] 3049
L49: 

        /** 		elsif previous_op = -1 or*/
        _26902 = (_35previous_op_16342 == -1);
        if (_26902 != 0) {
            goto L50; // [2978] 3023
        }
        _2 = (int)SEQ_PTR(_41op_result_50838);
        _26904 = (int)*(((s1_ptr)_2)->base + _35previous_op_16342);
        _26905 = (_26904 != 1);
        _26904 = NOVALUE;
        if (_26905 == 0) {
            DeRef(_26906);
            _26906 = 0;
            goto L51; // [2996] 3018
        }
        _2 = (int)SEQ_PTR(_41op_result_50838);
        _26907 = (int)*(((s1_ptr)_2)->base + _35previous_op_16342);
        _26908 = (_26907 != 3);
        _26907 = NOVALUE;
        _26906 = (_26908 != 0);
L51: 
        if (_26906 == 0)
        {
            _26906 = NOVALUE;
            goto L52; // [3019] 3038
        }
        else{
            _26906 = NOVALUE;
        }
L50: 

        /** 			emit_opcode(op)*/
        _41emit_opcode(_op_51157);

        /** 			emit_addr(op_info1)*/
        _41emit_addr(_41op_info1_50222);
        goto L4C; // [3035] 3049
L52: 

        /** 			last_op = last_op_backup*/
        _41last_op_51116 = _last_op_backup_51175;

        /** 			last_pc = last_pc_backup*/
        _41last_pc_51117 = _last_pc_backup_51174;
L4C: 

        /** 		clear_temp( Code[$-1] )*/
        if (IS_SEQUENCE(_35Code_16332)){
                _26909 = SEQ_PTR(_35Code_16332)->length;
        }
        else {
            _26909 = 1;
        }
        _26910 = _26909 - 1;
        _26909 = NOVALUE;
        _2 = (int)SEQ_PTR(_35Code_16332);
        _26911 = (int)*(((s1_ptr)_2)->base + _26910);
        Ref(_26911);
        _41clear_temp(_26911);
        _26911 = NOVALUE;
        goto LC; // [3067] 7412

        /** 	case RIGHT_BRACE_N then*/
        case 31:

        /** 		n = op_info1*/
        _n_51170 = _41op_info1_50222;

        /** 		elements = {}*/
        RefDS(_22023);
        DeRef(_elements_51172);
        _elements_51172 = _22023;

        /** 		for i = 1 to n do*/
        _26912 = _n_51170;
        {
            int _i_51808;
            _i_51808 = 1;
L53: 
            if (_i_51808 > _26912){
                goto L54; // [3092] 3115
            }

            /** 			elements = append(elements, Pop())*/
            _26913 = _41Pop();
            Ref(_26913);
            Append(&_elements_51172, _elements_51172, _26913);
            DeRef(_26913);
            _26913 = NOVALUE;

            /** 		end for*/
            _i_51808 = _i_51808 + 1;
            goto L53; // [3110] 3099
L54: 
            ;
        }

        /** 		element_vals = good_string(elements)*/
        RefDS(_elements_51172);
        _0 = _element_vals_51173;
        _element_vals_51173 = _41good_string(_elements_51172);
        DeRef(_0);

        /** 		if sequence(element_vals) then*/
        _26916 = IS_SEQUENCE(_element_vals_51173);
        if (_26916 == 0)
        {
            _26916 = NOVALUE;
            goto L55; // [3126] 3157
        }
        else{
            _26916 = NOVALUE;
        }

        /** 			c = NewStringSym(element_vals)  -- make a string literal*/
        Ref(_element_vals_51173);
        _c_51161 = _53NewStringSym(_element_vals_51173);
        if (!IS_ATOM_INT(_c_51161)) {
            _1 = (long)(DBL_PTR(_c_51161)->dbl);
            DeRefDS(_c_51161);
            _c_51161 = _1;
        }

        /** 			assignable = FALSE*/
        _41assignable_50240 = _13FALSE_434;

        /** 			last_op = last_op_backup*/
        _41last_op_51116 = _last_op_backup_51175;

        /** 			last_pc = last_pc_backup*/
        _41last_pc_51117 = _last_pc_backup_51174;
        goto L56; // [3154] 3248
L55: 

        /** 			if n = 2 then*/
        if (_n_51170 != 2)
        goto L57; // [3159] 3182

        /** 				emit_opcode(RIGHT_BRACE_2) -- faster op for two items*/
        _41emit_opcode(85);

        /** 				last_op = RIGHT_BRACE_2*/
        _41last_op_51116 = 85;
        goto L58; // [3179] 3193
L57: 

        /** 				emit_opcode(op)*/
        _41emit_opcode(_op_51157);

        /** 				emit(n)*/
        _41emit(_n_51170);
L58: 

        /** 			for i = 1 to n do*/
        _26919 = _n_51170;
        {
            int _i_51825;
            _i_51825 = 1;
L59: 
            if (_i_51825 > _26919){
                goto L5A; // [3198] 3221
            }

            /** 				emit_addr(elements[i])*/
            _2 = (int)SEQ_PTR(_elements_51172);
            _26920 = (int)*(((s1_ptr)_2)->base + _i_51825);
            Ref(_26920);
            _41emit_addr(_26920);
            _26920 = NOVALUE;

            /** 			end for*/
            _i_51825 = _i_51825 + 1;
            goto L59; // [3216] 3205
L5A: 
            ;
        }

        /** 			c = NewTempSym()*/
        _c_51161 = _53NewTempSym(0);
        if (!IS_ATOM_INT(_c_51161)) {
            _1 = (long)(DBL_PTR(_c_51161)->dbl);
            DeRefDS(_c_51161);
            _c_51161 = _1;
        }

        /** 			emit_addr(c)*/
        _41emit_addr(_c_51161);

        /** 			emit_temp( c, NEW_REFERENCE )*/
        _41emit_temp(_c_51161, 1);

        /** 			assignable = TRUE*/
        _41assignable_50240 = _13TRUE_436;
L56: 

        /** 		Push(c)*/
        _41Push(_c_51161);
        goto LC; // [3253] 7412

        /** 	case ASSIGN_SUBS2,      -- can't change the op*/
        case 148:
        case 16:
        case 162:

        /** 		b = Pop() -- rhs value*/
        _b_51160 = _41Pop();
        if (!IS_ATOM_INT(_b_51160)) {
            _1 = (long)(DBL_PTR(_b_51160)->dbl);
            DeRefDS(_b_51160);
            _b_51160 = _1;
        }

        /** 		a = Pop() -- subscript*/
        _a_51159 = _41Pop();
        if (!IS_ATOM_INT(_a_51159)) {
            _1 = (long)(DBL_PTR(_a_51159)->dbl);
            DeRefDS(_a_51159);
            _a_51159 = _1;
        }

        /** 		c = Pop() -- sequence*/
        _c_51161 = _41Pop();
        if (!IS_ATOM_INT(_c_51161)) {
            _1 = (long)(DBL_PTR(_c_51161)->dbl);
            DeRefDS(_c_51161);
            _c_51161 = _1;
        }

        /** 		if op = ASSIGN_SUBS then*/
        if (_op_51157 != 16)
        goto L5B; // [3288] 3480

        /** 			if (previous_op != LHS_SUBS) and*/
        _26926 = (_35previous_op_16342 != 95);
        if (_26926 == 0) {
            _26927 = 0;
            goto L5C; // [3302] 3314
        }
        _26928 = (_c_51161 > 0);
        _26927 = (_26928 != 0);
L5C: 
        if (_26927 == 0) {
            goto L5D; // [3314] 3452
        }
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _26930 = (int)*(((s1_ptr)_2)->base + _c_51161);
        _2 = (int)SEQ_PTR(_26930);
        _26931 = (int)*(((s1_ptr)_2)->base + 3);
        _26930 = NOVALUE;
        if (IS_ATOM_INT(_26931)) {
            _26932 = (_26931 != 1);
        }
        else {
            _26932 = binary_op(NOTEQ, _26931, 1);
        }
        _26931 = NOVALUE;
        if (IS_ATOM_INT(_26932)) {
            if (_26932 != 0) {
                DeRef(_26933);
                _26933 = 1;
                goto L5E; // [3336] 3436
            }
        }
        else {
            if (DBL_PTR(_26932)->dbl != 0.0) {
                DeRef(_26933);
                _26933 = 1;
                goto L5E; // [3336] 3436
            }
        }
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _26934 = (int)*(((s1_ptr)_2)->base + _c_51161);
        _2 = (int)SEQ_PTR(_26934);
        _26935 = (int)*(((s1_ptr)_2)->base + 15);
        _26934 = NOVALUE;
        if (IS_ATOM_INT(_26935)) {
            _26936 = (_26935 != _53sequence_type_46095);
        }
        else {
            _26936 = binary_op(NOTEQ, _26935, _53sequence_type_46095);
        }
        _26935 = NOVALUE;
        if (IS_ATOM_INT(_26936)) {
            if (_26936 == 0) {
                DeRef(_26937);
                _26937 = 0;
                goto L5F; // [3358] 3432
            }
        }
        else {
            if (DBL_PTR(_26936)->dbl == 0.0) {
                DeRef(_26937);
                _26937 = 0;
                goto L5F; // [3358] 3432
            }
        }
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _26938 = (int)*(((s1_ptr)_2)->base + _c_51161);
        _2 = (int)SEQ_PTR(_26938);
        _26939 = (int)*(((s1_ptr)_2)->base + 15);
        _26938 = NOVALUE;
        if (IS_ATOM_INT(_26939)) {
            _26940 = (_26939 > 0);
        }
        else {
            _26940 = binary_op(GREATER, _26939, 0);
        }
        _26939 = NOVALUE;
        if (IS_ATOM_INT(_26940)) {
            if (_26940 == 0) {
                DeRef(_26941);
                _26941 = 0;
                goto L60; // [3378] 3428
            }
        }
        else {
            if (DBL_PTR(_26940)->dbl == 0.0) {
                DeRef(_26941);
                _26941 = 0;
                goto L60; // [3378] 3428
            }
        }
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _26942 = (int)*(((s1_ptr)_2)->base + _c_51161);
        _2 = (int)SEQ_PTR(_26942);
        _26943 = (int)*(((s1_ptr)_2)->base + 15);
        _26942 = NOVALUE;
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        if (!IS_ATOM_INT(_26943)){
            _26944 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26943)->dbl));
        }
        else{
            _26944 = (int)*(((s1_ptr)_2)->base + _26943);
        }
        _2 = (int)SEQ_PTR(_26944);
        _26945 = (int)*(((s1_ptr)_2)->base + 2);
        _26944 = NOVALUE;
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        if (!IS_ATOM_INT(_26945)){
            _26946 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26945)->dbl));
        }
        else{
            _26946 = (int)*(((s1_ptr)_2)->base + _26945);
        }
        _2 = (int)SEQ_PTR(_26946);
        _26947 = (int)*(((s1_ptr)_2)->base + 15);
        _26946 = NOVALUE;
        if (IS_ATOM_INT(_26947)) {
            _26948 = (_26947 != _53sequence_type_46095);
        }
        else {
            _26948 = binary_op(NOTEQ, _26947, _53sequence_type_46095);
        }
        _26947 = NOVALUE;
        DeRef(_26941);
        if (IS_ATOM_INT(_26948))
        _26941 = (_26948 != 0);
        else
        _26941 = DBL_PTR(_26948)->dbl != 0.0;
L60: 
        DeRef(_26937);
        _26937 = (_26941 != 0);
L5F: 
        DeRef(_26933);
        _26933 = (_26937 != 0);
L5E: 
        if (_26933 == 0)
        {
            _26933 = NOVALUE;
            goto L5D; // [3437] 3452
        }
        else{
            _26933 = NOVALUE;
        }

        /** 				op = ASSIGN_SUBS_CHECK*/
        _op_51157 = 84;
        goto L61; // [3449] 3472
L5D: 

        /** 				if IsInteger(b) then*/
        _26949 = _41IsInteger(_b_51160);
        if (_26949 == 0) {
            DeRef(_26949);
            _26949 = NOVALUE;
            goto L62; // [3458] 3471
        }
        else {
            if (!IS_ATOM_INT(_26949) && DBL_PTR(_26949)->dbl == 0.0){
                DeRef(_26949);
                _26949 = NOVALUE;
                goto L62; // [3458] 3471
            }
            DeRef(_26949);
            _26949 = NOVALUE;
        }
        DeRef(_26949);
        _26949 = NOVALUE;

        /** 					op = ASSIGN_SUBS_I*/
        _op_51157 = 118;
L62: 
L61: 

        /** 			emit_opcode(op)*/
        _41emit_opcode(_op_51157);
        goto L63; // [3477] 3506
L5B: 

        /** 		elsif op = PASSIGN_SUBS then*/
        if (_op_51157 != 162)
        goto L64; // [3484] 3498

        /** 			emit_opcode(PASSIGN_SUBS) -- always*/
        _41emit_opcode(162);
        goto L63; // [3495] 3506
L64: 

        /** 			emit_opcode(ASSIGN_SUBS) -- always*/
        _41emit_opcode(16);
L63: 

        /** 		emit_addr(c) -- sequence*/
        _41emit_addr(_c_51161);

        /** 		emit_addr(a) -- subscript*/
        _41emit_addr(_a_51159);

        /** 		emit_addr(b) -- rhs value*/
        _41emit_addr(_b_51160);

        /** 		assignable = FALSE*/
        _41assignable_50240 = _13FALSE_434;
        goto LC; // [3528] 7412

        /** 	case LHS_SUBS, LHS_SUBS1, LHS_SUBS1_COPY then*/
        case 95:
        case 161:
        case 166:

        /** 		a = Pop() -- subs*/
        _a_51159 = _41Pop();
        if (!IS_ATOM_INT(_a_51159)) {
            _1 = (long)(DBL_PTR(_a_51159)->dbl);
            DeRefDS(_a_51159);
            _a_51159 = _1;
        }

        /** 		lhs_var = Pop() -- sequence*/
        _lhs_var_51167 = _41Pop();
        if (!IS_ATOM_INT(_lhs_var_51167)) {
            _1 = (long)(DBL_PTR(_lhs_var_51167)->dbl);
            DeRefDS(_lhs_var_51167);
            _lhs_var_51167 = _1;
        }

        /** 		emit_opcode(op)*/
        _41emit_opcode(_op_51157);

        /** 		emit_addr(lhs_var)*/
        _41emit_addr(_lhs_var_51167);

        /** 		emit_addr(a)*/
        _41emit_addr(_a_51159);

        /** 		if op = LHS_SUBS then*/
        if (_op_51157 != 95)
        goto L65; // [3571] 3602

        /** 			TempKeep(lhs_var) -- should be lhs_target_temp*/
        _41TempKeep(_lhs_var_51167);

        /** 			emit_addr(lhs_target_temp)*/
        _41emit_addr(_41lhs_target_temp_50236);

        /** 			Push(lhs_target_temp)*/
        _41Push(_41lhs_target_temp_50236);

        /** 			emit_addr(0) -- place holder*/
        _41emit_addr(0);
        goto L66; // [3599] 3656
L65: 

        /** 			lhs_target_temp = NewTempSym() -- use same temp for all subscripts*/
        _0 = _53NewTempSym(0);
        _41lhs_target_temp_50236 = _0;
        if (!IS_ATOM_INT(_41lhs_target_temp_50236)) {
            _1 = (long)(DBL_PTR(_41lhs_target_temp_50236)->dbl);
            DeRefDS(_41lhs_target_temp_50236);
            _41lhs_target_temp_50236 = _1;
        }

        /** 			emit_addr(lhs_target_temp) -- target temp holds pointer to sequence*/
        _41emit_addr(_41lhs_target_temp_50236);

        /** 			emit_temp(lhs_target_temp, NEW_REFERENCE )*/
        _41emit_temp(_41lhs_target_temp_50236, 1);

        /** 			Push(lhs_target_temp)*/
        _41Push(_41lhs_target_temp_50236);

        /** 			lhs_subs1_copy_temp = NewTempSym() -- place to copy (may be ignored)*/
        _0 = _53NewTempSym(0);
        _41lhs_subs1_copy_temp_50235 = _0;
        if (!IS_ATOM_INT(_41lhs_subs1_copy_temp_50235)) {
            _1 = (long)(DBL_PTR(_41lhs_subs1_copy_temp_50235)->dbl);
            DeRefDS(_41lhs_subs1_copy_temp_50235);
            _41lhs_subs1_copy_temp_50235 = _1;
        }

        /** 			emit_addr(lhs_subs1_copy_temp)*/
        _41emit_addr(_41lhs_subs1_copy_temp_50235);

        /** 			emit_temp( lhs_subs1_copy_temp, NEW_REFERENCE )*/
        _41emit_temp(_41lhs_subs1_copy_temp_50235, 1);
L66: 

        /** 		current_sequence = append(current_sequence, lhs_target_temp)*/
        Append(&_41current_sequence_50230, _41current_sequence_50230, _41lhs_target_temp_50236);

        /** 		assignable = FALSE  -- need to update current_sequence like in RHS_SUBS*/
        _41assignable_50240 = _13FALSE_434;
        goto LC; // [3673] 7412

        /** 	case RAND, PEEK, PEEK4S, PEEK4U, NOT_BITS, NOT,*/
        case 62:
        case 127:
        case 139:
        case 140:
        case 51:
        case 7:
        case 173:
        case 180:
        case 179:
        case 181:
        case 182:

        /** 		cont11ii(op, TRUE)*/
        _41cont11ii(_op_51157, _13TRUE_436);
        goto LC; // [3707] 7412

        /** 	case UMINUS then*/
        case 12:

        /** 		a = Pop()*/
        _a_51159 = _41Pop();
        if (!IS_ATOM_INT(_a_51159)) {
            _1 = (long)(DBL_PTR(_a_51159)->dbl);
            DeRefDS(_a_51159);
            _a_51159 = _1;
        }

        /** 		if a > 0 then*/
        if (_a_51159 <= 0)
        goto L67; // [3722] 3968

        /** 			obj = SymTab[a][S_OBJ]*/
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _26959 = (int)*(((s1_ptr)_2)->base + _a_51159);
        DeRef(_obj_51171);
        _2 = (int)SEQ_PTR(_26959);
        _obj_51171 = (int)*(((s1_ptr)_2)->base + 1);
        Ref(_obj_51171);
        _26959 = NOVALUE;

        /** 			if SymTab[a][S_MODE] = M_CONSTANT then*/
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _26961 = (int)*(((s1_ptr)_2)->base + _a_51159);
        _2 = (int)SEQ_PTR(_26961);
        _26962 = (int)*(((s1_ptr)_2)->base + 3);
        _26961 = NOVALUE;
        if (binary_op_a(NOTEQ, _26962, 2)){
            _26962 = NOVALUE;
            goto L68; // [3756] 3880
        }
        _26962 = NOVALUE;

        /** 				if integer(obj) then*/
        if (IS_ATOM_INT(_obj_51171))
        _26964 = 1;
        else if (IS_ATOM_DBL(_obj_51171))
        _26964 = IS_ATOM_INT(DoubleToInt(_obj_51171));
        else
        _26964 = 0;
        if (_26964 == 0)
        {
            _26964 = NOVALUE;
            goto L69; // [3765] 3819
        }
        else{
            _26964 = NOVALUE;
        }

        /** 					if obj = MININT then*/
        if (binary_op_a(NOTEQ, _obj_51171, -1073741824)){
            goto L6A; // [3772] 3793
        }

        /** 						Push(NewDoubleSym(-MININT))*/
        if ((unsigned long)-1073741824 == 0xC0000000)
        _26966 = (int)NewDouble((double)-0xC0000000);
        else
        _26966 = - -1073741824;
        _26967 = _53NewDoubleSym(_26966);
        _26966 = NOVALUE;
        _41Push(_26967);
        _26967 = NOVALUE;
        goto L6B; // [3790] 3806
L6A: 

        /** 						Push(NewIntSym(-obj))*/
        if (IS_ATOM_INT(_obj_51171)) {
            if ((unsigned long)_obj_51171 == 0xC0000000)
            _26968 = (int)NewDouble((double)-0xC0000000);
            else
            _26968 = - _obj_51171;
        }
        else {
            _26968 = unary_op(UMINUS, _obj_51171);
        }
        _26969 = _53NewIntSym(_26968);
        _26968 = NOVALUE;
        _41Push(_26969);
        _26969 = NOVALUE;
L6B: 

        /** 					last_pc = last_pc_backup*/
        _41last_pc_51117 = _last_pc_backup_51174;

        /** 					last_op = last_op_backup*/
        _41last_op_51116 = _last_op_backup_51175;
        goto LC; // [3816] 7412
L69: 

        /** 				elsif atom(obj) and obj != NOVALUE then*/
        _26970 = IS_ATOM(_obj_51171);
        if (_26970 == 0) {
            goto L6C; // [3824] 3863
        }
        if (IS_ATOM_INT(_obj_51171) && IS_ATOM_INT(_35NOVALUE_16099)) {
            _26972 = (_obj_51171 != _35NOVALUE_16099);
        }
        else {
            _26972 = binary_op(NOTEQ, _obj_51171, _35NOVALUE_16099);
        }
        if (_26972 == 0) {
            DeRef(_26972);
            _26972 = NOVALUE;
            goto L6C; // [3835] 3863
        }
        else {
            if (!IS_ATOM_INT(_26972) && DBL_PTR(_26972)->dbl == 0.0){
                DeRef(_26972);
                _26972 = NOVALUE;
                goto L6C; // [3835] 3863
            }
            DeRef(_26972);
            _26972 = NOVALUE;
        }
        DeRef(_26972);
        _26972 = NOVALUE;

        /** 					Push(NewDoubleSym(-obj))*/
        if (IS_ATOM_INT(_obj_51171)) {
            if ((unsigned long)_obj_51171 == 0xC0000000)
            _26973 = (int)NewDouble((double)-0xC0000000);
            else
            _26973 = - _obj_51171;
        }
        else {
            _26973 = unary_op(UMINUS, _obj_51171);
        }
        _26974 = _53NewDoubleSym(_26973);
        _26973 = NOVALUE;
        _41Push(_26974);
        _26974 = NOVALUE;

        /** 					last_pc = last_pc_backup*/
        _41last_pc_51117 = _last_pc_backup_51174;

        /** 					last_op = last_op_backup*/
        _41last_op_51116 = _last_op_backup_51175;
        goto LC; // [3860] 7412
L6C: 

        /** 					Push(a)*/
        _41Push(_a_51159);

        /** 					cont11ii(op, FALSE)*/
        _41cont11ii(_op_51157, _13FALSE_434);
        goto LC; // [3877] 7412
L68: 

        /** 			elsif TRANSLATE and SymTab[a][S_MODE] = M_TEMP and*/
        if (_35TRANSLATE_15887 == 0) {
            _26975 = 0;
            goto L6D; // [3884] 3910
        }
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _26976 = (int)*(((s1_ptr)_2)->base + _a_51159);
        _2 = (int)SEQ_PTR(_26976);
        _26977 = (int)*(((s1_ptr)_2)->base + 3);
        _26976 = NOVALUE;
        if (IS_ATOM_INT(_26977)) {
            _26978 = (_26977 == 3);
        }
        else {
            _26978 = binary_op(EQUALS, _26977, 3);
        }
        _26977 = NOVALUE;
        if (IS_ATOM_INT(_26978))
        _26975 = (_26978 != 0);
        else
        _26975 = DBL_PTR(_26978)->dbl != 0.0;
L6D: 
        if (_26975 == 0) {
            goto L6E; // [3910] 3951
        }
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _26980 = (int)*(((s1_ptr)_2)->base + _a_51159);
        _2 = (int)SEQ_PTR(_26980);
        _26981 = (int)*(((s1_ptr)_2)->base + 36);
        _26980 = NOVALUE;
        if (IS_ATOM_INT(_26981)) {
            _26982 = (_26981 == 2);
        }
        else {
            _26982 = binary_op(EQUALS, _26981, 2);
        }
        _26981 = NOVALUE;
        if (_26982 == 0) {
            DeRef(_26982);
            _26982 = NOVALUE;
            goto L6E; // [3933] 3951
        }
        else {
            if (!IS_ATOM_INT(_26982) && DBL_PTR(_26982)->dbl == 0.0){
                DeRef(_26982);
                _26982 = NOVALUE;
                goto L6E; // [3933] 3951
            }
            DeRef(_26982);
            _26982 = NOVALUE;
        }
        DeRef(_26982);
        _26982 = NOVALUE;

        /** 				Push(NewDoubleSym(-obj))*/
        if (IS_ATOM_INT(_obj_51171)) {
            if ((unsigned long)_obj_51171 == 0xC0000000)
            _26983 = (int)NewDouble((double)-0xC0000000);
            else
            _26983 = - _obj_51171;
        }
        else {
            _26983 = unary_op(UMINUS, _obj_51171);
        }
        _26984 = _53NewDoubleSym(_26983);
        _26983 = NOVALUE;
        _41Push(_26984);
        _26984 = NOVALUE;
        goto LC; // [3948] 7412
L6E: 

        /** 				Push(a)*/
        _41Push(_a_51159);

        /** 				cont11ii(op, FALSE)*/
        _41cont11ii(_op_51157, _13FALSE_434);
        goto LC; // [3965] 7412
L67: 

        /** 			Push(a)*/
        _41Push(_a_51159);

        /** 			cont11ii(op, FALSE)*/
        _41cont11ii(_op_51157, _13FALSE_434);
        goto LC; // [3982] 7412

        /** 	case LENGTH, GETC, SQRT, SIN, COS, TAN, ARCTAN, LOG, GETS, GETENV then*/
        case 42:
        case 33:
        case 41:
        case 80:
        case 81:
        case 82:
        case 73:
        case 74:
        case 17:
        case 91:

        /** 		cont11ii(op, FALSE)*/
        _41cont11ii(_op_51157, _13FALSE_434);
        goto LC; // [4014] 7412

        /** 	case IS_AN_INTEGER, IS_AN_ATOM, IS_A_SEQUENCE, IS_AN_OBJECT then*/
        case 94:
        case 67:
        case 68:
        case 40:

        /** 		cont11ii(op, FALSE)*/
        _41cont11ii(_op_51157, _13FALSE_434);
        goto LC; // [4034] 7412

        /** 	case ROUTINE_ID then*/
        case 134:

        /** 		emit_opcode(op)*/
        _41emit_opcode(_op_51157);

        /** 		source = Pop()*/
        _source_51163 = _41Pop();
        if (!IS_ATOM_INT(_source_51163)) {
            _1 = (long)(DBL_PTR(_source_51163)->dbl);
            DeRefDS(_source_51163);
            _source_51163 = _1;
        }

        /** 		if TRANSLATE then*/
        if (_35TRANSLATE_15887 == 0)
        {
            goto L6F; // [4056] 4100
        }
        else{
        }

        /** 			emit_addr(num_routines-1)*/
        _26986 = _35num_routines_16253 - 1;
        if ((long)((unsigned long)_26986 +(unsigned long) HIGH_BITS) >= 0){
            _26986 = NewDouble((double)_26986);
        }
        _41emit_addr(_26986);
        _26986 = NOVALUE;

        /** 			last_routine_id = num_routines*/
        _41last_routine_id_50227 = _35num_routines_16253;

        /** 			last_max_params = max_params*/
        _41last_max_params_50229 = _41max_params_50228;

        /** 			MarkTargets(source, S_RI_TARGET)*/
        _31660 = _53MarkTargets(_source_51163, 53);
        DeRef(_31660);
        _31660 = NOVALUE;
        goto L70; // [4097] 4137
L6F: 

        /** 			emit_addr(CurrentSub)*/
        _41emit_addr(_35CurrentSub_16252);

        /** 			emit_addr(length(SymTab))*/
        if (IS_SEQUENCE(_36SymTab_15242)){
                _26987 = SEQ_PTR(_36SymTab_15242)->length;
        }
        else {
            _26987 = 1;
        }
        _41emit_addr(_26987);
        _26987 = NOVALUE;

        /** 			if BIND then*/
        if (_35BIND_15890 == 0)
        {
            goto L71; // [4121] 4136
        }
        else{
        }

        /** 				MarkTargets(source, S_NREFS)*/
        _31659 = _53MarkTargets(_source_51163, 12);
        DeRef(_31659);
        _31659 = NOVALUE;
L71: 
L70: 

        /** 		emit_addr(source)*/
        _41emit_addr(_source_51163);

        /** 		emit_addr(current_file_no)  -- necessary at top level*/
        _41emit_addr(_35current_file_no_16244);

        /** 		assignable = TRUE*/
        _41assignable_50240 = _13TRUE_436;

        /** 		c = NewTempSym()*/
        _c_51161 = _53NewTempSym(0);
        if (!IS_ATOM_INT(_c_51161)) {
            _1 = (long)(DBL_PTR(_c_51161)->dbl);
            DeRefDS(_c_51161);
            _c_51161 = _1;
        }

        /** 		TempInteger(c) -- result will always be an integer*/
        _41TempInteger(_c_51161);

        /** 		Push(c)*/
        _41Push(_c_51161);

        /** 		emit_addr(c)*/
        _41emit_addr(_c_51161);
        goto LC; // [4179] 7412

        /** 	case SC1_OR, SC1_AND then*/
        case 143:
        case 141:

        /** 		emit_opcode(op)*/
        _41emit_opcode(_op_51157);

        /** 		emit_addr(Pop())*/
        _26989 = _41Pop();
        _41emit_addr(_26989);
        _26989 = NOVALUE;

        /** 		c = NewTempSym()*/
        _c_51161 = _53NewTempSym(0);
        if (!IS_ATOM_INT(_c_51161)) {
            _1 = (long)(DBL_PTR(_c_51161)->dbl);
            DeRefDS(_c_51161);
            _c_51161 = _1;
        }

        /** 		Push(c)*/
        _41Push(_c_51161);

        /** 		emit_addr(c)*/
        _41emit_addr(_c_51161);

        /** 		assignable = FALSE*/
        _41assignable_50240 = _13FALSE_434;
        goto LC; // [4225] 7412

        /** 	case SYSTEM, PUTS, PRINT, QPRINT, POSITION, MACHINE_PROC,*/
        case 99:
        case 44:
        case 19:
        case 36:
        case 60:
        case 112:
        case 132:
        case 128:
        case 138:
        case 168:
        case 178:

        /** 		emit_opcode(op)*/
        _41emit_opcode(_op_51157);

        /** 		b = Pop()*/
        _b_51160 = _41Pop();
        if (!IS_ATOM_INT(_b_51160)) {
            _1 = (long)(DBL_PTR(_b_51160)->dbl);
            DeRefDS(_b_51160);
            _b_51160 = _1;
        }

        /** 		emit_addr(Pop())*/
        _26992 = _41Pop();
        _41emit_addr(_26992);
        _26992 = NOVALUE;

        /** 		emit_addr(b)*/
        _41emit_addr(_b_51160);

        /** 		if op = C_PROC then*/
        if (_op_51157 != 132)
        goto L72; // [4280] 4292

        /** 			emit_addr(CurrentSub)*/
        _41emit_addr(_35CurrentSub_16252);
L72: 

        /** 		assignable = FALSE*/
        _41assignable_50240 = _13FALSE_434;
        goto LC; // [4299] 7412

        /** 	case EQUALS, LESS, GREATER, NOTEQ, LESSEQ, GREATEREQ,*/
        case 3:
        case 1:
        case 6:
        case 4:
        case 5:
        case 2:
        case 8:
        case 9:
        case 152:
        case 71:
        case 56:
        case 24:
        case 26:

        /** 		cont21ii(op, TRUE)  -- both integer args => integer result*/
        _41cont21ii(_op_51157, _13TRUE_436);
        goto LC; // [4337] 7412

        /** 	case PLUS then -- elsif op = PLUS then*/
        case 11:

        /** 		b = Pop()*/
        _b_51160 = _41Pop();
        if (!IS_ATOM_INT(_b_51160)) {
            _1 = (long)(DBL_PTR(_b_51160)->dbl);
            DeRefDS(_b_51160);
            _b_51160 = _1;
        }

        /** 		a = Pop()*/
        _a_51159 = _41Pop();
        if (!IS_ATOM_INT(_a_51159)) {
            _1 = (long)(DBL_PTR(_a_51159)->dbl);
            DeRefDS(_a_51159);
            _a_51159 = _1;
        }

        /** 		if b < 1 or a < 1 then*/
        _26996 = (_b_51160 < 1);
        if (_26996 != 0) {
            goto L73; // [4363] 4376
        }
        _26998 = (_a_51159 < 1);
        if (_26998 == 0)
        {
            DeRef(_26998);
            _26998 = NOVALUE;
            goto L74; // [4372] 4397
        }
        else{
            DeRef(_26998);
            _26998 = NOVALUE;
        }
L73: 

        /** 			Push(a)*/
        _41Push(_a_51159);

        /** 			Push(b)*/
        _41Push(_b_51160);

        /** 			cont21ii(op, FALSE)*/
        _41cont21ii(_op_51157, _13FALSE_434);
        goto LC; // [4394] 7412
L74: 

        /** 		elsif SymTab[b][S_MODE] = M_CONSTANT and equal(SymTab[b][S_OBJ], 1) then*/
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _26999 = (int)*(((s1_ptr)_2)->base + _b_51160);
        _2 = (int)SEQ_PTR(_26999);
        _27000 = (int)*(((s1_ptr)_2)->base + 3);
        _26999 = NOVALUE;
        if (IS_ATOM_INT(_27000)) {
            _27001 = (_27000 == 2);
        }
        else {
            _27001 = binary_op(EQUALS, _27000, 2);
        }
        _27000 = NOVALUE;
        if (IS_ATOM_INT(_27001)) {
            if (_27001 == 0) {
                goto L75; // [4417] 4478
            }
        }
        else {
            if (DBL_PTR(_27001)->dbl == 0.0) {
                goto L75; // [4417] 4478
            }
        }
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _27003 = (int)*(((s1_ptr)_2)->base + _b_51160);
        _2 = (int)SEQ_PTR(_27003);
        _27004 = (int)*(((s1_ptr)_2)->base + 1);
        _27003 = NOVALUE;
        if (_27004 == 1)
        _27005 = 1;
        else if (IS_ATOM_INT(_27004) && IS_ATOM_INT(1))
        _27005 = 0;
        else
        _27005 = (compare(_27004, 1) == 0);
        _27004 = NOVALUE;
        if (_27005 == 0)
        {
            _27005 = NOVALUE;
            goto L75; // [4438] 4478
        }
        else{
            _27005 = NOVALUE;
        }

        /** 			op = PLUS1*/
        _op_51157 = 93;

        /** 			emit_opcode(op)*/
        _41emit_opcode(93);

        /** 			emit_addr(a)*/
        _41emit_addr(_a_51159);

        /** 			emit_addr(0)*/
        _41emit_addr(0);

        /** 			cont21d(op, a, b, FALSE)*/
        _41cont21d(93, _a_51159, _b_51160, _13FALSE_434);
        goto LC; // [4475] 7412
L75: 

        /** 		elsif SymTab[a][S_MODE] = M_CONSTANT and equal(SymTab[a][S_OBJ], 1) then*/
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _27006 = (int)*(((s1_ptr)_2)->base + _a_51159);
        _2 = (int)SEQ_PTR(_27006);
        _27007 = (int)*(((s1_ptr)_2)->base + 3);
        _27006 = NOVALUE;
        if (IS_ATOM_INT(_27007)) {
            _27008 = (_27007 == 2);
        }
        else {
            _27008 = binary_op(EQUALS, _27007, 2);
        }
        _27007 = NOVALUE;
        if (IS_ATOM_INT(_27008)) {
            if (_27008 == 0) {
                goto L76; // [4498] 4559
            }
        }
        else {
            if (DBL_PTR(_27008)->dbl == 0.0) {
                goto L76; // [4498] 4559
            }
        }
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _27010 = (int)*(((s1_ptr)_2)->base + _a_51159);
        _2 = (int)SEQ_PTR(_27010);
        _27011 = (int)*(((s1_ptr)_2)->base + 1);
        _27010 = NOVALUE;
        if (_27011 == 1)
        _27012 = 1;
        else if (IS_ATOM_INT(_27011) && IS_ATOM_INT(1))
        _27012 = 0;
        else
        _27012 = (compare(_27011, 1) == 0);
        _27011 = NOVALUE;
        if (_27012 == 0)
        {
            _27012 = NOVALUE;
            goto L76; // [4519] 4559
        }
        else{
            _27012 = NOVALUE;
        }

        /** 			op = PLUS1*/
        _op_51157 = 93;

        /** 			emit_opcode(op)*/
        _41emit_opcode(93);

        /** 			emit_addr(b)*/
        _41emit_addr(_b_51160);

        /** 			emit_addr(0)*/
        _41emit_addr(0);

        /** 			cont21d(op, a, b, FALSE)*/
        _41cont21d(93, _a_51159, _b_51160, _13FALSE_434);
        goto LC; // [4556] 7412
L76: 

        /** 			Push(a)*/
        _41Push(_a_51159);

        /** 			Push(b)*/
        _41Push(_b_51160);

        /** 			cont21ii(op, FALSE)*/
        _41cont21ii(_op_51157, _13FALSE_434);
        goto LC; // [4578] 7412

        /** 	case rw:MULTIPLY then*/
        case 13:

        /** 		b = Pop()*/
        _b_51160 = _41Pop();
        if (!IS_ATOM_INT(_b_51160)) {
            _1 = (long)(DBL_PTR(_b_51160)->dbl);
            DeRefDS(_b_51160);
            _b_51160 = _1;
        }

        /** 		a = Pop()*/
        _a_51159 = _41Pop();
        if (!IS_ATOM_INT(_a_51159)) {
            _1 = (long)(DBL_PTR(_a_51159)->dbl);
            DeRefDS(_a_51159);
            _a_51159 = _1;
        }

        /** 		if a < 1 or b < 1 then*/
        _27015 = (_a_51159 < 1);
        if (_27015 != 0) {
            goto L77; // [4604] 4617
        }
        _27017 = (_b_51160 < 1);
        if (_27017 == 0)
        {
            DeRef(_27017);
            _27017 = NOVALUE;
            goto L78; // [4613] 4638
        }
        else{
            DeRef(_27017);
            _27017 = NOVALUE;
        }
L77: 

        /** 			Push(a)*/
        _41Push(_a_51159);

        /** 			Push(b)*/
        _41Push(_b_51160);

        /** 			cont21ii(op, FALSE)*/
        _41cont21ii(_op_51157, _13FALSE_434);
        goto LC; // [4635] 7412
L78: 

        /** 		elsif SymTab[b][S_MODE] = M_CONSTANT and equal(SymTab[b][S_OBJ], 2) then*/
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _27018 = (int)*(((s1_ptr)_2)->base + _b_51160);
        _2 = (int)SEQ_PTR(_27018);
        _27019 = (int)*(((s1_ptr)_2)->base + 3);
        _27018 = NOVALUE;
        if (IS_ATOM_INT(_27019)) {
            _27020 = (_27019 == 2);
        }
        else {
            _27020 = binary_op(EQUALS, _27019, 2);
        }
        _27019 = NOVALUE;
        if (IS_ATOM_INT(_27020)) {
            if (_27020 == 0) {
                goto L79; // [4658] 4719
            }
        }
        else {
            if (DBL_PTR(_27020)->dbl == 0.0) {
                goto L79; // [4658] 4719
            }
        }
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _27022 = (int)*(((s1_ptr)_2)->base + _b_51160);
        _2 = (int)SEQ_PTR(_27022);
        _27023 = (int)*(((s1_ptr)_2)->base + 1);
        _27022 = NOVALUE;
        if (_27023 == 2)
        _27024 = 1;
        else if (IS_ATOM_INT(_27023) && IS_ATOM_INT(2))
        _27024 = 0;
        else
        _27024 = (compare(_27023, 2) == 0);
        _27023 = NOVALUE;
        if (_27024 == 0)
        {
            _27024 = NOVALUE;
            goto L79; // [4679] 4719
        }
        else{
            _27024 = NOVALUE;
        }

        /** 			op = PLUS*/
        _op_51157 = 11;

        /** 			emit_opcode(op)*/
        _41emit_opcode(11);

        /** 			emit_addr(a)*/
        _41emit_addr(_a_51159);

        /** 			emit_addr(a)*/
        _41emit_addr(_a_51159);

        /** 			cont21d(op, a, b, FALSE)*/
        _41cont21d(11, _a_51159, _b_51160, _13FALSE_434);
        goto LC; // [4716] 7412
L79: 

        /** 		elsif SymTab[a][S_MODE] = M_CONSTANT and equal(SymTab[a][S_OBJ], 2) then*/
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _27025 = (int)*(((s1_ptr)_2)->base + _a_51159);
        _2 = (int)SEQ_PTR(_27025);
        _27026 = (int)*(((s1_ptr)_2)->base + 3);
        _27025 = NOVALUE;
        if (IS_ATOM_INT(_27026)) {
            _27027 = (_27026 == 2);
        }
        else {
            _27027 = binary_op(EQUALS, _27026, 2);
        }
        _27026 = NOVALUE;
        if (IS_ATOM_INT(_27027)) {
            if (_27027 == 0) {
                goto L7A; // [4739] 4800
            }
        }
        else {
            if (DBL_PTR(_27027)->dbl == 0.0) {
                goto L7A; // [4739] 4800
            }
        }
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _27029 = (int)*(((s1_ptr)_2)->base + _a_51159);
        _2 = (int)SEQ_PTR(_27029);
        _27030 = (int)*(((s1_ptr)_2)->base + 1);
        _27029 = NOVALUE;
        if (_27030 == 2)
        _27031 = 1;
        else if (IS_ATOM_INT(_27030) && IS_ATOM_INT(2))
        _27031 = 0;
        else
        _27031 = (compare(_27030, 2) == 0);
        _27030 = NOVALUE;
        if (_27031 == 0)
        {
            _27031 = NOVALUE;
            goto L7A; // [4760] 4800
        }
        else{
            _27031 = NOVALUE;
        }

        /** 			op = PLUS*/
        _op_51157 = 11;

        /** 			emit_opcode(op)*/
        _41emit_opcode(11);

        /** 			emit_addr(b)*/
        _41emit_addr(_b_51160);

        /** 			emit_addr(b)*/
        _41emit_addr(_b_51160);

        /** 			cont21d(op, a, b, FALSE)*/
        _41cont21d(11, _a_51159, _b_51160, _13FALSE_434);
        goto LC; // [4797] 7412
L7A: 

        /** 			Push(a)*/
        _41Push(_a_51159);

        /** 			Push(b)*/
        _41Push(_b_51160);

        /** 			cont21ii(op, FALSE)*/
        _41cont21ii(_op_51157, _13FALSE_434);
        goto LC; // [4819] 7412

        /** 	case rw:DIVIDE then*/
        case 14:

        /** 		b = Pop()*/
        _b_51160 = _41Pop();
        if (!IS_ATOM_INT(_b_51160)) {
            _1 = (long)(DBL_PTR(_b_51160)->dbl);
            DeRefDS(_b_51160);
            _b_51160 = _1;
        }

        /** 		if b > 0 and SymTab[b][S_MODE] = M_CONSTANT and equal(SymTab[b][S_OBJ], 2) then*/
        _27033 = (_b_51160 > 0);
        if (_27033 == 0) {
            _27034 = 0;
            goto L7B; // [4838] 4864
        }
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _27035 = (int)*(((s1_ptr)_2)->base + _b_51160);
        _2 = (int)SEQ_PTR(_27035);
        _27036 = (int)*(((s1_ptr)_2)->base + 3);
        _27035 = NOVALUE;
        if (IS_ATOM_INT(_27036)) {
            _27037 = (_27036 == 2);
        }
        else {
            _27037 = binary_op(EQUALS, _27036, 2);
        }
        _27036 = NOVALUE;
        if (IS_ATOM_INT(_27037))
        _27034 = (_27037 != 0);
        else
        _27034 = DBL_PTR(_27037)->dbl != 0.0;
L7B: 
        if (_27034 == 0) {
            goto L7C; // [4864] 4935
        }
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _27039 = (int)*(((s1_ptr)_2)->base + _b_51160);
        _2 = (int)SEQ_PTR(_27039);
        _27040 = (int)*(((s1_ptr)_2)->base + 1);
        _27039 = NOVALUE;
        if (_27040 == 2)
        _27041 = 1;
        else if (IS_ATOM_INT(_27040) && IS_ATOM_INT(2))
        _27041 = 0;
        else
        _27041 = (compare(_27040, 2) == 0);
        _27040 = NOVALUE;
        if (_27041 == 0)
        {
            _27041 = NOVALUE;
            goto L7C; // [4885] 4935
        }
        else{
            _27041 = NOVALUE;
        }

        /** 			op = DIV2*/
        _op_51157 = 98;

        /** 			emit_opcode(op)*/
        _41emit_opcode(98);

        /** 			emit_addr(Pop()) -- n.b. "a" hasn't been set*/
        _27042 = _41Pop();
        _41emit_addr(_27042);
        _27042 = NOVALUE;

        /** 			a = 0*/
        _a_51159 = 0;

        /** 			emit_addr(0)*/
        _41emit_addr(0);

        /** 			cont21d(op, a, b, FALSE)  -- could have fractional result*/
        _41cont21d(98, 0, _b_51160, _13FALSE_434);
        goto LC; // [4932] 7412
L7C: 

        /** 			Push(b)*/
        _41Push(_b_51160);

        /** 			cont21ii(op, FALSE)*/
        _41cont21ii(_op_51157, _13FALSE_434);
        goto LC; // [4949] 7412

        /** 	case FLOOR then*/
        case 83:

        /** 		if previous_op = rw:DIVIDE then*/
        if (_35previous_op_16342 != 14)
        goto L7D; // [4959] 5007

        /** 			op = FLOOR_DIV*/
        _op_51157 = 63;

        /** 			backpatch(length(Code) - 3, op)*/
        if (IS_SEQUENCE(_35Code_16332)){
                _27044 = SEQ_PTR(_35Code_16332)->length;
        }
        else {
            _27044 = 1;
        }
        _27045 = _27044 - 3;
        _27044 = NOVALUE;
        _41backpatch(_27045, 63);
        _27045 = NOVALUE;

        /** 			assignable = TRUE*/
        _41assignable_50240 = _13TRUE_436;

        /** 			last_op = op*/
        _41last_op_51116 = 63;

        /** 			last_pc = last_pc_backup*/
        _41last_pc_51117 = _last_pc_backup_51174;
        goto LC; // [5004] 7412
L7D: 

        /** 		elsif previous_op = DIV2 then*/
        if (_35previous_op_16342 != 98)
        goto L7E; // [5013] 5100

        /** 			op = FLOOR_DIV2*/
        _op_51157 = 66;

        /** 			backpatch(length(Code) - 3, op)*/
        if (IS_SEQUENCE(_35Code_16332)){
                _27047 = SEQ_PTR(_35Code_16332)->length;
        }
        else {
            _27047 = 1;
        }
        _27048 = _27047 - 3;
        _27047 = NOVALUE;
        _41backpatch(_27048, 66);
        _27048 = NOVALUE;

        /** 			assignable = TRUE*/
        _41assignable_50240 = _13TRUE_436;

        /** 			if IsInteger(Code[$-2]) then*/
        if (IS_SEQUENCE(_35Code_16332)){
                _27049 = SEQ_PTR(_35Code_16332)->length;
        }
        else {
            _27049 = 1;
        }
        _27050 = _27049 - 2;
        _27049 = NOVALUE;
        _2 = (int)SEQ_PTR(_35Code_16332);
        _27051 = (int)*(((s1_ptr)_2)->base + _27050);
        Ref(_27051);
        _27052 = _41IsInteger(_27051);
        _27051 = NOVALUE;
        if (_27052 == 0) {
            DeRef(_27052);
            _27052 = NOVALUE;
            goto L7F; // [5067] 5087
        }
        else {
            if (!IS_ATOM_INT(_27052) && DBL_PTR(_27052)->dbl == 0.0){
                DeRef(_27052);
                _27052 = NOVALUE;
                goto L7F; // [5067] 5087
            }
            DeRef(_27052);
            _27052 = NOVALUE;
        }
        DeRef(_27052);
        _27052 = NOVALUE;

        /** 				TempInteger(Top()) --mark temp as integer type*/

        /** 	return cg_stack[cgi]*/
        DeRef(_Top_inlined_Top_at_5195_52195);
        _2 = (int)SEQ_PTR(_41cg_stack_50237);
        _Top_inlined_Top_at_5195_52195 = (int)*(((s1_ptr)_2)->base + _41cgi_50238);
        Ref(_Top_inlined_Top_at_5195_52195);
        Ref(_Top_inlined_Top_at_5195_52195);
        _41TempInteger(_Top_inlined_Top_at_5195_52195);
L7F: 

        /** 			last_op = op*/
        _41last_op_51116 = _op_51157;

        /** 			last_pc = last_pc_backup*/
        _41last_pc_51117 = _last_pc_backup_51174;
        goto LC; // [5097] 7412
L7E: 

        /** 			cont11ii(op, TRUE)*/
        _41cont11ii(_op_51157, _13TRUE_436);
        goto LC; // [5109] 7412

        /** 	case MINUS, rw:APPEND, PREPEND, COMPARE, EQUAL,*/
        case 10:
        case 35:
        case 57:
        case 76:
        case 153:
        case 154:
        case 15:
        case 32:
        case 111:
        case 133:
        case 53:
        case 167:
        case 194:
        case 198:
        case 199:
        case 204:

        /** 		cont21ii(op, FALSE)*/
        _41cont21ii(_op_51157, _13FALSE_434);
        goto LC; // [5153] 7412

        /** 	case SC2_NULL then  -- correct the stack - we aren't emitting anything*/
        case 145:

        /** 		c = Pop()*/
        _c_51161 = _41Pop();
        if (!IS_ATOM_INT(_c_51161)) {
            _1 = (long)(DBL_PTR(_c_51161)->dbl);
            DeRefDS(_c_51161);
            _c_51161 = _1;
        }

        /** 		TempKeep(c)*/
        _41TempKeep(_c_51161);

        /** 		b = Pop()  -- remove SC1's temp*/
        _b_51160 = _41Pop();
        if (!IS_ATOM_INT(_b_51160)) {
            _1 = (long)(DBL_PTR(_b_51160)->dbl);
            DeRefDS(_b_51160);
            _b_51160 = _1;
        }

        /** 		Push(c)*/
        _41Push(_c_51161);

        /** 		assignable = FALSE*/
        _41assignable_50240 = _13FALSE_434;

        /** 		last_op = last_op_backup*/
        _41last_op_51116 = _last_op_backup_51175;

        /** 		last_pc = last_pc_backup*/
        _41last_pc_51117 = _last_pc_backup_51174;
        goto LC; // [5200] 7412

        /** 	case SC2_AND, SC2_OR then*/
        case 142:
        case 144:

        /** 		emit_opcode(op)*/
        _41emit_opcode(_op_51157);

        /** 		emit_addr(Pop())*/
        _27055 = _41Pop();
        _41emit_addr(_27055);
        _27055 = NOVALUE;

        /** 		c = Pop()*/
        _c_51161 = _41Pop();
        if (!IS_ATOM_INT(_c_51161)) {
            _1 = (long)(DBL_PTR(_c_51161)->dbl);
            DeRefDS(_c_51161);
            _c_51161 = _1;
        }

        /** 		TempKeep(c)*/
        _41TempKeep(_c_51161);

        /** 		emit_addr(c) -- target*/
        _41emit_addr(_c_51161);

        /** 		TempInteger(c)*/
        _41TempInteger(_c_51161);

        /** 		Push(c)*/
        _41Push(_c_51161);

        /** 		assignable = FALSE*/
        _41assignable_50240 = _13FALSE_434;
        goto LC; // [5255] 7412

        /** 	case MEM_COPY, MEM_SET, PRINTF then*/
        case 130:
        case 131:
        case 38:

        /** 		emit_opcode(op)*/
        _41emit_opcode(_op_51157);

        /** 		c = Pop()*/
        _c_51161 = _41Pop();
        if (!IS_ATOM_INT(_c_51161)) {
            _1 = (long)(DBL_PTR(_c_51161)->dbl);
            DeRefDS(_c_51161);
            _c_51161 = _1;
        }

        /** 		b = Pop()*/
        _b_51160 = _41Pop();
        if (!IS_ATOM_INT(_b_51160)) {
            _1 = (long)(DBL_PTR(_b_51160)->dbl);
            DeRefDS(_b_51160);
            _b_51160 = _1;
        }

        /** 		emit_addr(Pop())*/
        _27059 = _41Pop();
        _41emit_addr(_27059);
        _27059 = NOVALUE;

        /** 		emit_addr(b)*/
        _41emit_addr(_b_51160);

        /** 		emit_addr(c)*/
        _41emit_addr(_c_51161);

        /** 		assignable = FALSE*/
        _41assignable_50240 = _13FALSE_434;
        goto LC; // [5309] 7412

        /** 	case RHS_SLICE, FIND, MATCH, FIND_FROM, MATCH_FROM, SPLICE, INSERT, REMOVE, OPEN then*/
        case 46:
        case 77:
        case 78:
        case 176:
        case 177:
        case 190:
        case 191:
        case 200:
        case 37:

        /** 		emit_opcode(op)*/
        _41emit_opcode(_op_51157);

        /** 		c = Pop()*/
        _c_51161 = _41Pop();
        if (!IS_ATOM_INT(_c_51161)) {
            _1 = (long)(DBL_PTR(_c_51161)->dbl);
            DeRefDS(_c_51161);
            _c_51161 = _1;
        }

        /** 		b = Pop()*/
        _b_51160 = _41Pop();
        if (!IS_ATOM_INT(_b_51160)) {
            _1 = (long)(DBL_PTR(_b_51160)->dbl);
            DeRefDS(_b_51160);
            _b_51160 = _1;
        }

        /** 		emit_addr(Pop())*/
        _27062 = _41Pop();
        _41emit_addr(_27062);
        _27062 = NOVALUE;

        /** 		emit_addr(b)*/
        _41emit_addr(_b_51160);

        /** 		emit_addr(c)*/
        _41emit_addr(_c_51161);

        /** 		c = NewTempSym()*/
        _c_51161 = _53NewTempSym(0);
        if (!IS_ATOM_INT(_c_51161)) {
            _1 = (long)(DBL_PTR(_c_51161)->dbl);
            DeRefDS(_c_51161);
            _c_51161 = _1;
        }

        /** 		if op = FIND or op = FIND_FROM or op = OPEN then*/
        _27064 = (_op_51157 == 77);
        if (_27064 != 0) {
            _27065 = 1;
            goto L80; // [5384] 5398
        }
        _27066 = (_op_51157 == 176);
        _27065 = (_27066 != 0);
L80: 
        if (_27065 != 0) {
            goto L81; // [5398] 5413
        }
        _27068 = (_op_51157 == 37);
        if (_27068 == 0)
        {
            DeRef(_27068);
            _27068 = NOVALUE;
            goto L82; // [5409] 5421
        }
        else{
            DeRef(_27068);
            _27068 = NOVALUE;
        }
L81: 

        /** 			TempInteger( c )*/
        _41TempInteger(_c_51161);
        goto L83; // [5418] 5428
L82: 

        /** 			emit_temp( c, NEW_REFERENCE )*/
        _41emit_temp(_c_51161, 1);
L83: 

        /** 		assignable = TRUE*/
        _41assignable_50240 = _13TRUE_436;

        /** 		Push(c)*/
        _41Push(_c_51161);

        /** 		emit_addr(c)*/
        _41emit_addr(_c_51161);
        goto LC; // [5445] 7412

        /** 	case CONCAT_N then     -- concatenate 3 or more items*/
        case 157:

        /** 		n = op_info1  -- number of items to concatenate*/
        _n_51170 = _41op_info1_50222;

        /** 		emit_opcode(CONCAT_N)*/
        _41emit_opcode(157);

        /** 		emit(n)*/
        _41emit(_n_51170);

        /** 		for i = 1 to n do*/
        _27069 = _n_51170;
        {
            int _i_52263;
            _i_52263 = 1;
L84: 
            if (_i_52263 > _27069){
                goto L85; // [5475] 5503
            }

            /** 			symtab_index element = Pop()*/
            _element_52266 = _41Pop();
            if (!IS_ATOM_INT(_element_52266)) {
                _1 = (long)(DBL_PTR(_element_52266)->dbl);
                DeRefDS(_element_52266);
                _element_52266 = _1;
            }

            /** 			emit_addr( element )  -- reverse order*/
            _41emit_addr(_element_52266);

            /** 		end for*/
            _i_52263 = _i_52263 + 1;
            goto L84; // [5498] 5482
L85: 
            ;
        }

        /** 		c = NewTempSym()*/
        _c_51161 = _53NewTempSym(0);
        if (!IS_ATOM_INT(_c_51161)) {
            _1 = (long)(DBL_PTR(_c_51161)->dbl);
            DeRefDS(_c_51161);
            _c_51161 = _1;
        }

        /** 		emit_addr(c)*/
        _41emit_addr(_c_51161);

        /** 		emit_temp( c, NEW_REFERENCE )*/
        _41emit_temp(_c_51161, 1);

        /** 		assignable = TRUE*/
        _41assignable_50240 = _13TRUE_436;

        /** 		Push(c)*/
        _41Push(_c_51161);
        goto LC; // [5534] 7412

        /** 	case FOR then*/
        case 21:

        /** 		c = Pop() -- increment*/
        _c_51161 = _41Pop();
        if (!IS_ATOM_INT(_c_51161)) {
            _1 = (long)(DBL_PTR(_c_51161)->dbl);
            DeRefDS(_c_51161);
            _c_51161 = _1;
        }

        /** 		TempKeep(c)*/
        _41TempKeep(_c_51161);

        /** 		ic = IsInteger(c)*/
        _ic_51169 = _41IsInteger(_c_51161);
        if (!IS_ATOM_INT(_ic_51169)) {
            _1 = (long)(DBL_PTR(_ic_51169)->dbl);
            DeRefDS(_ic_51169);
            _ic_51169 = _1;
        }

        /** 		if c < 1 or*/
        _27074 = (_c_51161 < 1);
        if (_27074 != 0) {
            goto L86; // [5566] 5645
        }
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _27076 = (int)*(((s1_ptr)_2)->base + _c_51161);
        _2 = (int)SEQ_PTR(_27076);
        _27077 = (int)*(((s1_ptr)_2)->base + 3);
        _27076 = NOVALUE;
        if (IS_ATOM_INT(_27077)) {
            _27078 = (_27077 == 1);
        }
        else {
            _27078 = binary_op(EQUALS, _27077, 1);
        }
        _27077 = NOVALUE;
        if (IS_ATOM_INT(_27078)) {
            if (_27078 == 0) {
                DeRef(_27079);
                _27079 = 0;
                goto L87; // [5588] 5614
            }
        }
        else {
            if (DBL_PTR(_27078)->dbl == 0.0) {
                DeRef(_27079);
                _27079 = 0;
                goto L87; // [5588] 5614
            }
        }
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _27080 = (int)*(((s1_ptr)_2)->base + _c_51161);
        _2 = (int)SEQ_PTR(_27080);
        _27081 = (int)*(((s1_ptr)_2)->base + 4);
        _27080 = NOVALUE;
        if (IS_ATOM_INT(_27081)) {
            _27082 = (_27081 != 2);
        }
        else {
            _27082 = binary_op(NOTEQ, _27081, 2);
        }
        _27081 = NOVALUE;
        DeRef(_27079);
        if (IS_ATOM_INT(_27082))
        _27079 = (_27082 != 0);
        else
        _27079 = DBL_PTR(_27082)->dbl != 0.0;
L87: 
        if (_27079 == 0) {
            DeRef(_27083);
            _27083 = 0;
            goto L88; // [5614] 5640
        }
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _27084 = (int)*(((s1_ptr)_2)->base + _c_51161);
        _2 = (int)SEQ_PTR(_27084);
        _27085 = (int)*(((s1_ptr)_2)->base + 4);
        _27084 = NOVALUE;
        if (IS_ATOM_INT(_27085)) {
            _27086 = (_27085 != 4);
        }
        else {
            _27086 = binary_op(NOTEQ, _27085, 4);
        }
        _27085 = NOVALUE;
        if (IS_ATOM_INT(_27086))
        _27083 = (_27086 != 0);
        else
        _27083 = DBL_PTR(_27086)->dbl != 0.0;
L88: 
        if (_27083 == 0)
        {
            _27083 = NOVALUE;
            goto L89; // [5641] 5682
        }
        else{
            _27083 = NOVALUE;
        }
L86: 

        /** 			emit_opcode(ASSIGN)*/
        _41emit_opcode(18);

        /** 			emit_addr(c)*/
        _41emit_addr(_c_51161);

        /** 			c = NewTempSym()*/
        _c_51161 = _53NewTempSym(0);
        if (!IS_ATOM_INT(_c_51161)) {
            _1 = (long)(DBL_PTR(_c_51161)->dbl);
            DeRefDS(_c_51161);
            _c_51161 = _1;
        }

        /** 			if ic then*/
        if (_ic_51169 == 0)
        {
            goto L8A; // [5667] 5676
        }
        else{
        }

        /** 				TempInteger( c )*/
        _41TempInteger(_c_51161);
L8A: 

        /** 			emit_addr(c)*/
        _41emit_addr(_c_51161);
L89: 

        /** 		b = Pop() -- limit*/
        _b_51160 = _41Pop();
        if (!IS_ATOM_INT(_b_51160)) {
            _1 = (long)(DBL_PTR(_b_51160)->dbl);
            DeRefDS(_b_51160);
            _b_51160 = _1;
        }

        /** 		TempKeep(b)*/
        _41TempKeep(_b_51160);

        /** 		ib = IsInteger(b)*/
        _ib_51168 = _41IsInteger(_b_51160);
        if (!IS_ATOM_INT(_ib_51168)) {
            _1 = (long)(DBL_PTR(_ib_51168)->dbl);
            DeRefDS(_ib_51168);
            _ib_51168 = _1;
        }

        /** 		if b < 1 or*/
        _27090 = (_b_51160 < 1);
        if (_27090 != 0) {
            goto L8B; // [5708] 5787
        }
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _27092 = (int)*(((s1_ptr)_2)->base + _b_51160);
        _2 = (int)SEQ_PTR(_27092);
        _27093 = (int)*(((s1_ptr)_2)->base + 3);
        _27092 = NOVALUE;
        if (IS_ATOM_INT(_27093)) {
            _27094 = (_27093 == 1);
        }
        else {
            _27094 = binary_op(EQUALS, _27093, 1);
        }
        _27093 = NOVALUE;
        if (IS_ATOM_INT(_27094)) {
            if (_27094 == 0) {
                DeRef(_27095);
                _27095 = 0;
                goto L8C; // [5730] 5756
            }
        }
        else {
            if (DBL_PTR(_27094)->dbl == 0.0) {
                DeRef(_27095);
                _27095 = 0;
                goto L8C; // [5730] 5756
            }
        }
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _27096 = (int)*(((s1_ptr)_2)->base + _b_51160);
        _2 = (int)SEQ_PTR(_27096);
        _27097 = (int)*(((s1_ptr)_2)->base + 4);
        _27096 = NOVALUE;
        if (IS_ATOM_INT(_27097)) {
            _27098 = (_27097 != 2);
        }
        else {
            _27098 = binary_op(NOTEQ, _27097, 2);
        }
        _27097 = NOVALUE;
        DeRef(_27095);
        if (IS_ATOM_INT(_27098))
        _27095 = (_27098 != 0);
        else
        _27095 = DBL_PTR(_27098)->dbl != 0.0;
L8C: 
        if (_27095 == 0) {
            DeRef(_27099);
            _27099 = 0;
            goto L8D; // [5756] 5782
        }
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _27100 = (int)*(((s1_ptr)_2)->base + _b_51160);
        _2 = (int)SEQ_PTR(_27100);
        _27101 = (int)*(((s1_ptr)_2)->base + 4);
        _27100 = NOVALUE;
        if (IS_ATOM_INT(_27101)) {
            _27102 = (_27101 != 4);
        }
        else {
            _27102 = binary_op(NOTEQ, _27101, 4);
        }
        _27101 = NOVALUE;
        if (IS_ATOM_INT(_27102))
        _27099 = (_27102 != 0);
        else
        _27099 = DBL_PTR(_27102)->dbl != 0.0;
L8D: 
        if (_27099 == 0)
        {
            _27099 = NOVALUE;
            goto L8E; // [5783] 5824
        }
        else{
            _27099 = NOVALUE;
        }
L8B: 

        /** 			emit_opcode(ASSIGN)*/
        _41emit_opcode(18);

        /** 			emit_addr(b)*/
        _41emit_addr(_b_51160);

        /** 			b = NewTempSym()*/
        _b_51160 = _53NewTempSym(0);
        if (!IS_ATOM_INT(_b_51160)) {
            _1 = (long)(DBL_PTR(_b_51160)->dbl);
            DeRefDS(_b_51160);
            _b_51160 = _1;
        }

        /** 			if ib then*/
        if (_ib_51168 == 0)
        {
            goto L8F; // [5809] 5818
        }
        else{
        }

        /** 				TempInteger( b )*/
        _41TempInteger(_b_51160);
L8F: 

        /** 			emit_addr(b)*/
        _41emit_addr(_b_51160);
L8E: 

        /** 		a = Pop() -- initial value*/
        _a_51159 = _41Pop();
        if (!IS_ATOM_INT(_a_51159)) {
            _1 = (long)(DBL_PTR(_a_51159)->dbl);
            DeRefDS(_a_51159);
            _a_51159 = _1;
        }

        /** 		if IsInteger(a) and ib and ic then*/
        _27105 = _41IsInteger(_a_51159);
        if (IS_ATOM_INT(_27105)) {
            if (_27105 == 0) {
                DeRef(_27106);
                _27106 = 0;
                goto L90; // [5837] 5845
            }
        }
        else {
            if (DBL_PTR(_27105)->dbl == 0.0) {
                DeRef(_27106);
                _27106 = 0;
                goto L90; // [5837] 5845
            }
        }
        DeRef(_27106);
        _27106 = (_ib_51168 != 0);
L90: 
        if (_27106 == 0) {
            goto L91; // [5845] 5884
        }
        if (_ic_51169 == 0)
        {
            goto L91; // [5850] 5884
        }
        else{
        }

        /** 			SymTab[op_info1][S_VTYPE] = integer_type*/
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _36SymTab_15242 = MAKE_SEQ(_2);
        }
        _3 = (int)(_41op_info1_50222 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 15);
        _1 = *(int *)_2;
        *(int *)_2 = _53integer_type_46097;
        DeRef(_1);
        _27108 = NOVALUE;

        /** 			op = FOR_I*/
        _op_51157 = 125;
        goto L92; // [5881] 5894
L91: 

        /** 			op = FOR*/
        _op_51157 = 21;
L92: 

        /** 		emit_opcode(op)*/
        _41emit_opcode(_op_51157);

        /** 		emit_addr(c)*/
        _41emit_addr(_c_51161);

        /** 		emit_addr(b)*/
        _41emit_addr(_b_51160);

        /** 		emit_addr(a)*/
        _41emit_addr(_a_51159);

        /** 		emit_addr(CurrentSub) -- in case recursion check is needed*/
        _41emit_addr(_35CurrentSub_16252);

        /** 		Push(b)*/
        _41Push(_b_51160);

        /** 		Push(c)*/
        _41Push(_c_51161);

        /** 		assignable = FALSE*/
        _41assignable_50240 = _13FALSE_434;
        goto LC; // [5938] 7412

        /** 	case ENDFOR_GENERAL, ENDFOR_INT_UP1 then  -- all ENDFORs*/
        case 39:
        case 54:

        /** 		emit_opcode(op) -- will be patched at runtime*/
        _41emit_opcode(_op_51157);

        /** 		a = Pop()*/
        _a_51159 = _41Pop();
        if (!IS_ATOM_INT(_a_51159)) {
            _1 = (long)(DBL_PTR(_a_51159)->dbl);
            DeRefDS(_a_51159);
            _a_51159 = _1;
        }

        /** 		emit_addr(op_info2) -- address of top of loop*/
        _41emit_addr(_41op_info2_50223);

        /** 		emit_addr(Pop())    -- limit*/
        _27111 = _41Pop();
        _41emit_addr(_27111);
        _27111 = NOVALUE;

        /** 		emit_addr(op_info1) -- loop var*/
        _41emit_addr(_41op_info1_50222);

        /** 		emit_addr(a)        -- increment - not always used -*/
        _41emit_addr(_a_51159);

        /** 		assignable = FALSE*/
        _41assignable_50240 = _13FALSE_434;
        goto LC; // [5992] 7412

        /** 	case ASSIGN_OP_SUBS, PASSIGN_OP_SUBS then*/
        case 149:
        case 164:

        /** 		b = Pop()      -- rhs value, keep on stack*/
        _b_51160 = _41Pop();
        if (!IS_ATOM_INT(_b_51160)) {
            _1 = (long)(DBL_PTR(_b_51160)->dbl);
            DeRefDS(_b_51160);
            _b_51160 = _1;
        }

        /** 		TempKeep(b)*/
        _41TempKeep(_b_51160);

        /** 		a = Pop()      -- subscript, keep on stack*/
        _a_51159 = _41Pop();
        if (!IS_ATOM_INT(_a_51159)) {
            _1 = (long)(DBL_PTR(_a_51159)->dbl);
            DeRefDS(_a_51159);
            _a_51159 = _1;
        }

        /** 		TempKeep(a)*/
        _41TempKeep(_a_51159);

        /** 		c = Pop()      -- lhs sequence, keep on stack*/
        _c_51161 = _41Pop();
        if (!IS_ATOM_INT(_c_51161)) {
            _1 = (long)(DBL_PTR(_c_51161)->dbl);
            DeRefDS(_c_51161);
            _c_51161 = _1;
        }

        /** 		TempKeep(c)*/
        _41TempKeep(_c_51161);

        /** 		emit_opcode(op)*/
        _41emit_opcode(_op_51157);

        /** 		emit_addr(c)*/
        _41emit_addr(_c_51161);

        /** 		emit_addr(a)*/
        _41emit_addr(_a_51159);

        /** 		d = NewTempSym()*/
        _d_51162 = _53NewTempSym(0);
        if (!IS_ATOM_INT(_d_51162)) {
            _1 = (long)(DBL_PTR(_d_51162)->dbl);
            DeRefDS(_d_51162);
            _d_51162 = _1;
        }

        /** 		emit_addr(d)   -- place to store result*/
        _41emit_addr(_d_51162);

        /** 		emit_temp( d, NEW_REFERENCE )*/
        _41emit_temp(_d_51162, 1);

        /** 		Push(c)*/
        _41Push(_c_51161);

        /** 		Push(a)*/
        _41Push(_a_51159);

        /** 		Push(d)*/
        _41Push(_d_51162);

        /** 		Push(b)*/
        _41Push(_b_51160);

        /** 		assignable = FALSE*/
        _41assignable_50240 = _13FALSE_434;
        goto LC; // [6097] 7412

        /** 	case ASSIGN_SLICE, PASSIGN_SLICE then*/
        case 45:
        case 163:

        /** 		emit_opcode(op)*/
        _41emit_opcode(_op_51157);

        /** 		b = Pop() -- rhs value*/
        _b_51160 = _41Pop();
        if (!IS_ATOM_INT(_b_51160)) {
            _1 = (long)(DBL_PTR(_b_51160)->dbl);
            DeRefDS(_b_51160);
            _b_51160 = _1;
        }

        /** 		a = Pop() -- 2nd subs*/
        _a_51159 = _41Pop();
        if (!IS_ATOM_INT(_a_51159)) {
            _1 = (long)(DBL_PTR(_a_51159)->dbl);
            DeRefDS(_a_51159);
            _a_51159 = _1;
        }

        /** 		c = Pop() -- 1st subs*/
        _c_51161 = _41Pop();
        if (!IS_ATOM_INT(_c_51161)) {
            _1 = (long)(DBL_PTR(_c_51161)->dbl);
            DeRefDS(_c_51161);
            _c_51161 = _1;
        }

        /** 		emit_addr(Pop()) -- sequence*/
        _27119 = _41Pop();
        _41emit_addr(_27119);
        _27119 = NOVALUE;

        /** 		emit_addr(c)*/
        _41emit_addr(_c_51161);

        /** 		emit_addr(a)*/
        _41emit_addr(_a_51159);

        /** 		emit_addr(b)*/
        _41emit_addr(_b_51160);

        /** 		assignable = FALSE*/
        _41assignable_50240 = _13FALSE_434;
        goto LC; // [6161] 7412

        /** 	case REPLACE then*/
        case 201:

        /** 		emit_opcode(op)*/
        _41emit_opcode(_op_51157);

        /** 		b = Pop()  -- source*/
        _b_51160 = _41Pop();
        if (!IS_ATOM_INT(_b_51160)) {
            _1 = (long)(DBL_PTR(_b_51160)->dbl);
            DeRefDS(_b_51160);
            _b_51160 = _1;
        }

        /** 		a = Pop()  -- replacement*/
        _a_51159 = _41Pop();
        if (!IS_ATOM_INT(_a_51159)) {
            _1 = (long)(DBL_PTR(_a_51159)->dbl);
            DeRefDS(_a_51159);
            _a_51159 = _1;
        }

        /** 		c = Pop()  -- start of replaced slice*/
        _c_51161 = _41Pop();
        if (!IS_ATOM_INT(_c_51161)) {
            _1 = (long)(DBL_PTR(_c_51161)->dbl);
            DeRefDS(_c_51161);
            _c_51161 = _1;
        }

        /** 		d = Pop()  -- end of replaced slice*/
        _d_51162 = _41Pop();
        if (!IS_ATOM_INT(_d_51162)) {
            _1 = (long)(DBL_PTR(_d_51162)->dbl);
            DeRefDS(_d_51162);
            _d_51162 = _1;
        }

        /** 		emit_addr(d)*/
        _41emit_addr(_d_51162);

        /** 		emit_addr(c)*/
        _41emit_addr(_c_51161);

        /** 		emit_addr(a)*/
        _41emit_addr(_a_51159);

        /** 		emit_addr(b)*/
        _41emit_addr(_b_51160);

        /** 		c = NewTempSym()*/
        _c_51161 = _53NewTempSym(0);
        if (!IS_ATOM_INT(_c_51161)) {
            _1 = (long)(DBL_PTR(_c_51161)->dbl);
            DeRefDS(_c_51161);
            _c_51161 = _1;
        }

        /** 		Push(c)*/
        _41Push(_c_51161);

        /** 		emit_addr(c)     -- place to store result*/
        _41emit_addr(_c_51161);

        /** 		emit_temp( c, NEW_REFERENCE )*/
        _41emit_temp(_c_51161, 1);

        /** 		assignable = TRUE*/
        _41assignable_50240 = _13TRUE_436;
        goto LC; // [6251] 7412

        /** 	case ASSIGN_OP_SLICE, PASSIGN_OP_SLICE then*/
        case 150:
        case 165:

        /** 		emit_opcode(op)*/
        _41emit_opcode(_op_51157);

        /** 		b = Pop()        -- rhs value not used*/
        _b_51160 = _41Pop();
        if (!IS_ATOM_INT(_b_51160)) {
            _1 = (long)(DBL_PTR(_b_51160)->dbl);
            DeRefDS(_b_51160);
            _b_51160 = _1;
        }

        /** 		TempKeep(b)*/
        _41TempKeep(_b_51160);

        /** 		a = Pop()        -- 2nd subs*/
        _a_51159 = _41Pop();
        if (!IS_ATOM_INT(_a_51159)) {
            _1 = (long)(DBL_PTR(_a_51159)->dbl);
            DeRefDS(_a_51159);
            _a_51159 = _1;
        }

        /** 		TempKeep(a)*/
        _41TempKeep(_a_51159);

        /** 		c = Pop()        -- 1st subs*/
        _c_51161 = _41Pop();
        if (!IS_ATOM_INT(_c_51161)) {
            _1 = (long)(DBL_PTR(_c_51161)->dbl);
            DeRefDS(_c_51161);
            _c_51161 = _1;
        }

        /** 		TempKeep(c)*/
        _41TempKeep(_c_51161);

        /** 		d = Pop()*/
        _d_51162 = _41Pop();
        if (!IS_ATOM_INT(_d_51162)) {
            _1 = (long)(DBL_PTR(_d_51162)->dbl);
            DeRefDS(_d_51162);
            _d_51162 = _1;
        }

        /** 		TempKeep(d)      -- sequence*/
        _41TempKeep(_d_51162);

        /** 		emit_addr(d)*/
        _41emit_addr(_d_51162);

        /** 		Push(d)*/
        _41Push(_d_51162);

        /** 		emit_addr(c)*/
        _41emit_addr(_c_51161);

        /** 		Push(c)*/
        _41Push(_c_51161);

        /** 		emit_addr(a)*/
        _41emit_addr(_a_51159);

        /** 		Push(a)*/
        _41Push(_a_51159);

        /** 		c = NewTempSym()*/
        _c_51161 = _53NewTempSym(0);
        if (!IS_ATOM_INT(_c_51161)) {
            _1 = (long)(DBL_PTR(_c_51161)->dbl);
            DeRefDS(_c_51161);
            _c_51161 = _1;
        }

        /** 		Push(c)*/
        _41Push(_c_51161);

        /** 		emit_addr(c)     -- place to store result*/
        _41emit_addr(_c_51161);

        /** 		emit_temp( c, NEW_REFERENCE )*/
        _41emit_temp(_c_51161, 1);

        /** 		Push(b)*/
        _41Push(_b_51160);

        /** 		assignable = FALSE*/
        _41assignable_50240 = _13FALSE_434;
        goto LC; // [6378] 7412

        /** 	case CALL_PROC then*/
        case 136:

        /** 		emit_opcode(op)*/
        _41emit_opcode(_op_51157);

        /** 		b = Pop()*/
        _b_51160 = _41Pop();
        if (!IS_ATOM_INT(_b_51160)) {
            _1 = (long)(DBL_PTR(_b_51160)->dbl);
            DeRefDS(_b_51160);
            _b_51160 = _1;
        }

        /** 		emit_addr(Pop())*/
        _27131 = _41Pop();
        _41emit_addr(_27131);
        _27131 = NOVALUE;

        /** 		emit_addr(b)*/
        _41emit_addr(_b_51160);

        /** 		assignable = FALSE*/
        _41assignable_50240 = _13FALSE_434;
        goto LC; // [6416] 7412

        /** 	case CALL_FUNC then*/
        case 137:

        /** 		emit_opcode(op)*/
        _41emit_opcode(_op_51157);

        /** 		b = Pop()*/
        _b_51160 = _41Pop();
        if (!IS_ATOM_INT(_b_51160)) {
            _1 = (long)(DBL_PTR(_b_51160)->dbl);
            DeRefDS(_b_51160);
            _b_51160 = _1;
        }

        /** 		emit_addr(Pop())*/
        _27133 = _41Pop();
        _41emit_addr(_27133);
        _27133 = NOVALUE;

        /** 		emit_addr(b)*/
        _41emit_addr(_b_51160);

        /** 		assignable = TRUE*/
        _41assignable_50240 = _13TRUE_436;

        /** 		c = NewTempSym()*/
        _c_51161 = _53NewTempSym(0);
        if (!IS_ATOM_INT(_c_51161)) {
            _1 = (long)(DBL_PTR(_c_51161)->dbl);
            DeRefDS(_c_51161);
            _c_51161 = _1;
        }

        /** 		Push(c)*/
        _41Push(_c_51161);

        /** 		emit_addr(c)*/
        _41emit_addr(_c_51161);

        /** 		emit_temp( c, NEW_REFERENCE )*/
        _41emit_temp(_c_51161, 1);
        goto LC; // [6478] 7412

        /** 	case EXIT_BLOCK then*/
        case 206:

        /** 		emit_opcode( op )*/
        _41emit_opcode(_op_51157);

        /** 		emit_addr( Pop() )*/
        _27135 = _41Pop();
        _41emit_addr(_27135);
        _27135 = NOVALUE;

        /** 		assignable = FALSE*/
        _41assignable_50240 = _13FALSE_434;
        goto LC; // [6504] 7412

        /** 	case RETURNP then*/
        case 29:

        /** 		emit_opcode(op)*/
        _41emit_opcode(_op_51157);

        /** 		emit_addr(CurrentSub)*/
        _41emit_addr(_35CurrentSub_16252);

        /** 		emit_addr(top_block())*/
        _27136 = _66top_block(0);
        _41emit_addr(_27136);
        _27136 = NOVALUE;

        /** 		assignable = FALSE*/
        _41assignable_50240 = _13FALSE_434;
        goto LC; // [6538] 7412

        /** 	case RETURNF then*/
        case 28:

        /** 		clear_temp( Top() )*/

        /** 	return cg_stack[cgi]*/
        DeRef(_Top_inlined_Top_at_6750_52413);
        _2 = (int)SEQ_PTR(_41cg_stack_50237);
        _Top_inlined_Top_at_6750_52413 = (int)*(((s1_ptr)_2)->base + _41cgi_50238);
        Ref(_Top_inlined_Top_at_6750_52413);
        Ref(_Top_inlined_Top_at_6750_52413);
        _41clear_temp(_Top_inlined_Top_at_6750_52413);

        /** 		flush_temps()*/
        RefDS(_22023);
        _41flush_temps(_22023);

        /** 		emit_opcode(op)*/
        _41emit_opcode(_op_51157);

        /** 		emit_addr(CurrentSub)*/
        _41emit_addr(_35CurrentSub_16252);

        /** 		emit_addr(Least_block())*/
        _27137 = _66Least_block();
        _41emit_addr(_27137);
        _27137 = NOVALUE;

        /** 		emit_addr(Pop())*/
        _27138 = _41Pop();
        _41emit_addr(_27138);
        _27138 = NOVALUE;

        /** 		assignable = FALSE*/
        _41assignable_50240 = _13FALSE_434;
        goto LC; // [6600] 7412

        /** 	case RETURNT then*/
        case 34:

        /** 		emit_opcode(op)*/
        _41emit_opcode(_op_51157);

        /** 		assignable = FALSE*/
        _41assignable_50240 = _13FALSE_434;
        goto LC; // [6618] 7412

        /** 	case DATE, TIME, SPACE_USED, GET_KEY, TASK_LIST,*/
        case 69:
        case 70:
        case 75:
        case 79:
        case 172:
        case 100:
        case 183:

        /** 		emit_opcode(op)*/
        _41emit_opcode(_op_51157);

        /** 		c = NewTempSym()*/
        _c_51161 = _53NewTempSym(0);
        if (!IS_ATOM_INT(_c_51161)) {
            _1 = (long)(DBL_PTR(_c_51161)->dbl);
            DeRefDS(_c_51161);
            _c_51161 = _1;
        }

        /** 		assignable = TRUE*/
        _41assignable_50240 = _13TRUE_436;

        /** 		if op = GET_KEY then  -- it's in op_result as integer*/
        if (_op_51157 != 79)
        goto L93; // [6660] 6672

        /** 			TempInteger(c)*/
        _41TempInteger(_c_51161);
        goto L94; // [6669] 6679
L93: 

        /** 			emit_temp( c, NEW_REFERENCE )*/
        _41emit_temp(_c_51161, 1);
L94: 

        /** 		Push(c)*/
        _41Push(_c_51161);

        /** 		emit_addr(c)*/
        _41emit_addr(_c_51161);
        goto LC; // [6689] 7412

        /** 	case CLOSE, ABORT, CALL, DELETE_OBJECT then*/
        case 86:
        case 126:
        case 129:
        case 205:

        /** 		emit_opcode(op)*/
        _41emit_opcode(_op_51157);

        /** 		emit_addr(Pop())*/
        _27141 = _41Pop();
        _41emit_addr(_27141);
        _27141 = NOVALUE;

        /** 		assignable = FALSE*/
        _41assignable_50240 = _13FALSE_434;
        goto LC; // [6721] 7412

        /** 	case POWER then*/
        case 72:

        /** 		b = Pop()*/
        _b_51160 = _41Pop();
        if (!IS_ATOM_INT(_b_51160)) {
            _1 = (long)(DBL_PTR(_b_51160)->dbl);
            DeRefDS(_b_51160);
            _b_51160 = _1;
        }

        /** 		a = Pop()*/
        _a_51159 = _41Pop();
        if (!IS_ATOM_INT(_a_51159)) {
            _1 = (long)(DBL_PTR(_a_51159)->dbl);
            DeRefDS(_a_51159);
            _a_51159 = _1;
        }

        /** 		if b > 0 and SymTab[b][S_MODE] = M_CONSTANT and equal(SymTab[b][S_OBJ], 2) then*/
        _27144 = (_b_51160 > 0);
        if (_27144 == 0) {
            _27145 = 0;
            goto L95; // [6747] 6773
        }
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _27146 = (int)*(((s1_ptr)_2)->base + _b_51160);
        _2 = (int)SEQ_PTR(_27146);
        _27147 = (int)*(((s1_ptr)_2)->base + 3);
        _27146 = NOVALUE;
        if (IS_ATOM_INT(_27147)) {
            _27148 = (_27147 == 2);
        }
        else {
            _27148 = binary_op(EQUALS, _27147, 2);
        }
        _27147 = NOVALUE;
        if (IS_ATOM_INT(_27148))
        _27145 = (_27148 != 0);
        else
        _27145 = DBL_PTR(_27148)->dbl != 0.0;
L95: 
        if (_27145 == 0) {
            goto L96; // [6773] 6830
        }
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _27150 = (int)*(((s1_ptr)_2)->base + _b_51160);
        _2 = (int)SEQ_PTR(_27150);
        _27151 = (int)*(((s1_ptr)_2)->base + 1);
        _27150 = NOVALUE;
        if (_27151 == 2)
        _27152 = 1;
        else if (IS_ATOM_INT(_27151) && IS_ATOM_INT(2))
        _27152 = 0;
        else
        _27152 = (compare(_27151, 2) == 0);
        _27151 = NOVALUE;
        if (_27152 == 0)
        {
            _27152 = NOVALUE;
            goto L96; // [6794] 6830
        }
        else{
            _27152 = NOVALUE;
        }

        /** 			op = rw:MULTIPLY*/
        _op_51157 = 13;

        /** 			emit_opcode(op)*/
        _41emit_opcode(13);

        /** 			emit_addr(a)*/
        _41emit_addr(_a_51159);

        /** 			emit_addr(a)*/
        _41emit_addr(_a_51159);

        /** 			cont21d(op, a, b, FALSE)*/
        _41cont21d(13, _a_51159, _b_51160, _13FALSE_434);
        goto LC; // [6827] 7412
L96: 

        /** 			Push(a)*/
        _41Push(_a_51159);

        /** 			Push(b)*/
        _41Push(_b_51160);

        /** 			cont21ii(op, FALSE)*/
        _41cont21ii(_op_51157, _13FALSE_434);
        goto LC; // [6849] 7412

        /** 	case TYPE_CHECK then*/
        case 65:

        /** 		emit_opcode(op)*/
        _41emit_opcode(_op_51157);

        /** 		c = Pop()*/
        _c_51161 = _41Pop();
        if (!IS_ATOM_INT(_c_51161)) {
            _1 = (long)(DBL_PTR(_c_51161)->dbl);
            DeRefDS(_c_51161);
            _c_51161 = _1;
        }

        /** 		assignable = FALSE*/
        _41assignable_50240 = _13FALSE_434;
        goto LC; // [6874] 7412

        /** 	case DOLLAR then*/
        case -22:

        /** 		if current_sequence[$] < 0 or SymTab[current_sequence[$]][S_SCOPE] = SC_UNDEFINED then*/
        if (IS_SEQUENCE(_41current_sequence_50230)){
                _27154 = SEQ_PTR(_41current_sequence_50230)->length;
        }
        else {
            _27154 = 1;
        }
        _2 = (int)SEQ_PTR(_41current_sequence_50230);
        _27155 = (int)*(((s1_ptr)_2)->base + _27154);
        if (IS_ATOM_INT(_27155)) {
            _27156 = (_27155 < 0);
        }
        else {
            _27156 = binary_op(LESS, _27155, 0);
        }
        _27155 = NOVALUE;
        if (IS_ATOM_INT(_27156)) {
            if (_27156 != 0) {
                goto L97; // [6895] 6931
            }
        }
        else {
            if (DBL_PTR(_27156)->dbl != 0.0) {
                goto L97; // [6895] 6931
            }
        }
        if (IS_SEQUENCE(_41current_sequence_50230)){
                _27158 = SEQ_PTR(_41current_sequence_50230)->length;
        }
        else {
            _27158 = 1;
        }
        _2 = (int)SEQ_PTR(_41current_sequence_50230);
        _27159 = (int)*(((s1_ptr)_2)->base + _27158);
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        if (!IS_ATOM_INT(_27159)){
            _27160 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_27159)->dbl));
        }
        else{
            _27160 = (int)*(((s1_ptr)_2)->base + _27159);
        }
        _2 = (int)SEQ_PTR(_27160);
        _27161 = (int)*(((s1_ptr)_2)->base + 4);
        _27160 = NOVALUE;
        if (IS_ATOM_INT(_27161)) {
            _27162 = (_27161 == 9);
        }
        else {
            _27162 = binary_op(EQUALS, _27161, 9);
        }
        _27161 = NOVALUE;
        if (_27162 == 0) {
            DeRef(_27162);
            _27162 = NOVALUE;
            goto L98; // [6927] 7001
        }
        else {
            if (!IS_ATOM_INT(_27162) && DBL_PTR(_27162)->dbl == 0.0){
                DeRef(_27162);
                _27162 = NOVALUE;
                goto L98; // [6927] 7001
            }
            DeRef(_27162);
            _27162 = NOVALUE;
        }
        DeRef(_27162);
        _27162 = NOVALUE;
L97: 

        /** 			if lhs_ptr and length(current_sequence) = 1 then*/
        if (_41lhs_ptr_50232 == 0) {
            goto L99; // [6935] 6964
        }
        if (IS_SEQUENCE(_41current_sequence_50230)){
                _27164 = SEQ_PTR(_41current_sequence_50230)->length;
        }
        else {
            _27164 = 1;
        }
        _27165 = (_27164 == 1);
        _27164 = NOVALUE;
        if (_27165 == 0)
        {
            DeRef(_27165);
            _27165 = NOVALUE;
            goto L99; // [6949] 6964
        }
        else{
            DeRef(_27165);
            _27165 = NOVALUE;
        }

        /** 				c = PLENGTH*/
        _c_51161 = 160;
        goto L9A; // [6961] 6974
L99: 

        /** 				c = LENGTH*/
        _c_51161 = 42;
L9A: 

        /** 			c = - new_forward_reference( VARIABLE, current_sequence[$], c )*/
        if (IS_SEQUENCE(_41current_sequence_50230)){
                _27166 = SEQ_PTR(_41current_sequence_50230)->length;
        }
        else {
            _27166 = 1;
        }
        _2 = (int)SEQ_PTR(_41current_sequence_50230);
        _27167 = (int)*(((s1_ptr)_2)->base + _27166);
        Ref(_27167);
        _27168 = _38new_forward_reference(-100, _27167, _c_51161);
        _27167 = NOVALUE;
        if (IS_ATOM_INT(_27168)) {
            if ((unsigned long)_27168 == 0xC0000000)
            _c_51161 = (int)NewDouble((double)-0xC0000000);
            else
            _c_51161 = - _27168;
        }
        else {
            _c_51161 = unary_op(UMINUS, _27168);
        }
        DeRef(_27168);
        _27168 = NOVALUE;
        if (!IS_ATOM_INT(_c_51161)) {
            _1 = (long)(DBL_PTR(_c_51161)->dbl);
            DeRefDS(_c_51161);
            _c_51161 = _1;
        }
        goto L9B; // [6998] 7015
L98: 

        /** 			c = current_sequence[$]*/
        if (IS_SEQUENCE(_41current_sequence_50230)){
                _27170 = SEQ_PTR(_41current_sequence_50230)->length;
        }
        else {
            _27170 = 1;
        }
        _2 = (int)SEQ_PTR(_41current_sequence_50230);
        _c_51161 = (int)*(((s1_ptr)_2)->base + _27170);
        if (!IS_ATOM_INT(_c_51161)){
            _c_51161 = (long)DBL_PTR(_c_51161)->dbl;
        }
L9B: 

        /** 		if lhs_ptr and length(current_sequence) = 1 then*/
        if (_41lhs_ptr_50232 == 0) {
            goto L9C; // [7019] 7046
        }
        if (IS_SEQUENCE(_41current_sequence_50230)){
                _27173 = SEQ_PTR(_41current_sequence_50230)->length;
        }
        else {
            _27173 = 1;
        }
        _27174 = (_27173 == 1);
        _27173 = NOVALUE;
        if (_27174 == 0)
        {
            DeRef(_27174);
            _27174 = NOVALUE;
            goto L9C; // [7033] 7046
        }
        else{
            DeRef(_27174);
            _27174 = NOVALUE;
        }

        /** 			emit_opcode(PLENGTH)*/
        _41emit_opcode(160);
        goto L9D; // [7043] 7054
L9C: 

        /** 			emit_opcode(LENGTH)*/
        _41emit_opcode(42);
L9D: 

        /** 		emit_addr( c )*/
        _41emit_addr(_c_51161);

        /** 		c = NewTempSym()*/
        _c_51161 = _53NewTempSym(0);
        if (!IS_ATOM_INT(_c_51161)) {
            _1 = (long)(DBL_PTR(_c_51161)->dbl);
            DeRefDS(_c_51161);
            _c_51161 = _1;
        }

        /** 		TempInteger(c)*/
        _41TempInteger(_c_51161);

        /** 		Push(c)*/
        _41Push(_c_51161);

        /** 		emit_addr(c)*/
        _41emit_addr(_c_51161);

        /** 		assignable = FALSE -- it wouldn't be assigned anyway*/
        _41assignable_50240 = _13FALSE_434;
        goto LC; // [7089] 7412

        /** 	case TASK_SELF then*/
        case 170:

        /** 		c = NewTempSym()*/
        _c_51161 = _53NewTempSym(0);
        if (!IS_ATOM_INT(_c_51161)) {
            _1 = (long)(DBL_PTR(_c_51161)->dbl);
            DeRefDS(_c_51161);
            _c_51161 = _1;
        }

        /** 		Push(c)*/
        _41Push(_c_51161);

        /** 		emit_opcode(op)*/
        _41emit_opcode(_op_51157);

        /** 		emit_addr(c)*/
        _41emit_addr(_c_51161);

        /** 		assignable = TRUE*/
        _41assignable_50240 = _13TRUE_436;
        goto LC; // [7125] 7412

        /** 	case SWITCH then*/
        case 185:

        /** 		emit_opcode( op )*/
        _41emit_opcode(_op_51157);

        /** 		c = Pop()*/
        _c_51161 = _41Pop();
        if (!IS_ATOM_INT(_c_51161)) {
            _1 = (long)(DBL_PTR(_c_51161)->dbl);
            DeRefDS(_c_51161);
            _c_51161 = _1;
        }

        /** 		b = Pop()*/
        _b_51160 = _41Pop();
        if (!IS_ATOM_INT(_b_51160)) {
            _1 = (long)(DBL_PTR(_b_51160)->dbl);
            DeRefDS(_b_51160);
            _b_51160 = _1;
        }

        /** 		a = Pop()*/
        _a_51159 = _41Pop();
        if (!IS_ATOM_INT(_a_51159)) {
            _1 = (long)(DBL_PTR(_a_51159)->dbl);
            DeRefDS(_a_51159);
            _a_51159 = _1;
        }

        /** 		emit_addr( a ) -- Switch Expr*/
        _41emit_addr(_a_51159);

        /** 		emit_addr( b ) -- Case values*/
        _41emit_addr(_b_51160);

        /** 		emit_addr( c ) -- Jump table*/
        _41emit_addr(_c_51161);

        /** 		assignable = FALSE*/
        _41assignable_50240 = _13FALSE_434;
        goto LC; // [7179] 7412

        /** 	case CASE then*/
        case 186:

        /** 		emit_opcode( op )*/
        _41emit_opcode(_op_51157);

        /** 		emit( cg_stack[cgi] )  -- the case index*/
        _2 = (int)SEQ_PTR(_41cg_stack_50237);
        _27180 = (int)*(((s1_ptr)_2)->base + _41cgi_50238);
        Ref(_27180);
        _41emit(_27180);
        _27180 = NOVALUE;

        /** 		cgi -= 1*/
        _41cgi_50238 = _41cgi_50238 - 1;
        goto LC; // [7211] 7412

        /** 	case PLATFORM then*/
        case 155:

        /** 		if BIND and shroud_only then*/
        if (_35BIND_15890 == 0) {
            goto L9E; // [7221] 7269
        }
        if (_35shroud_only_16242 == 0)
        {
            goto L9E; // [7228] 7269
        }
        else{
        }

        /** 			c = NewTempSym()*/
        _c_51161 = _53NewTempSym(0);
        if (!IS_ATOM_INT(_c_51161)) {
            _1 = (long)(DBL_PTR(_c_51161)->dbl);
            DeRefDS(_c_51161);
            _c_51161 = _1;
        }

        /** 			TempInteger(c)*/
        _41TempInteger(_c_51161);

        /** 			Push(c)*/
        _41Push(_c_51161);

        /** 			emit_opcode(op)*/
        _41emit_opcode(_op_51157);

        /** 			emit_addr(c)*/
        _41emit_addr(_c_51161);

        /** 			assignable = TRUE*/
        _41assignable_50240 = _13TRUE_436;
        goto LC; // [7266] 7412
L9E: 

        /** 			n = host_platform()*/
        _n_51170 = _40host_platform();
        if (!IS_ATOM_INT(_n_51170)) {
            _1 = (long)(DBL_PTR(_n_51170)->dbl);
            DeRefDS(_n_51170);
            _n_51170 = _1;
        }

        /** 			Push(NewIntSym(n))*/
        _27185 = _53NewIntSym(_n_51170);
        _41Push(_27185);
        _27185 = NOVALUE;

        /** 			assignable = FALSE*/
        _41assignable_50240 = _13FALSE_434;
        goto LC; // [7293] 7412

        /** 	case PROFILE, TASK_SUSPEND then*/
        case 151:
        case 171:

        /** 		a = Pop()*/
        _a_51159 = _41Pop();
        if (!IS_ATOM_INT(_a_51159)) {
            _1 = (long)(DBL_PTR(_a_51159)->dbl);
            DeRefDS(_a_51159);
            _a_51159 = _1;
        }

        /** 		emit_opcode(op)*/
        _41emit_opcode(_op_51157);

        /** 		emit_addr(a)*/
        _41emit_addr(_a_51159);

        /** 		assignable = FALSE*/
        _41assignable_50240 = _13FALSE_434;
        goto LC; // [7325] 7412

        /** 	case TRACE then*/
        case 64:

        /** 		a = Pop()*/
        _a_51159 = _41Pop();
        if (!IS_ATOM_INT(_a_51159)) {
            _1 = (long)(DBL_PTR(_a_51159)->dbl);
            DeRefDS(_a_51159);
            _a_51159 = _1;
        }

        /** 		if OpTrace then*/
        if (_35OpTrace_16313 == 0)
        {
            goto L9F; // [7342] 7388
        }
        else{
        }

        /** 			emit_opcode(op)*/
        _41emit_opcode(_op_51157);

        /** 			emit_addr(a)*/
        _41emit_addr(_a_51159);

        /** 			if TRANSLATE then*/
        if (_35TRANSLATE_15887 == 0)
        {
            goto LA0; // [7359] 7387
        }
        else{
        }

        /** 				if not trace_called then*/
        if (_41trace_called_50225 != 0)
        goto LA1; // [7366] 7377

        /** 					Warning(217,0)*/
        RefDS(_22023);
        _44Warning(217, 0, _22023);
LA1: 

        /** 				trace_called = TRUE*/
        _41trace_called_50225 = _13TRUE_436;
LA0: 
L9F: 

        /** 		assignable = FALSE*/
        _41assignable_50240 = _13FALSE_434;
        goto LC; // [7395] 7412

        /** 	case else*/
        default:

        /** 		InternalErr(259, {op})*/
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = _op_51157;
        _27189 = MAKE_SEQ(_1);
        _44InternalErr(259, _27189);
        _27189 = NOVALUE;
    ;}LC: 

    /** 	previous_op = op*/
    _35previous_op_16342 = _op_51157;

    /** 	inlined = 0*/
    _41inlined_51135 = 0;

    /** end procedure*/
    DeRef(_obj_51171);
    DeRef(_elements_51172);
    DeRef(_element_vals_51173);
    DeRef(_26625);
    _26625 = NOVALUE;
    DeRef(_26928);
    _26928 = NOVALUE;
    DeRef(_27102);
    _27102 = NOVALUE;
    DeRef(_26898);
    _26898 = NOVALUE;
    DeRef(_27082);
    _27082 = NOVALUE;
    DeRef(_26623);
    _26623 = NOVALUE;
    DeRef(_26800);
    _26800 = NOVALUE;
    DeRef(_26822);
    _26822 = NOVALUE;
    DeRef(_26902);
    _26902 = NOVALUE;
    DeRef(_26876);
    _26876 = NOVALUE;
    DeRef(_26885);
    _26885 = NOVALUE;
    DeRef(_26908);
    _26908 = NOVALUE;
    DeRef(_26910);
    _26910 = NOVALUE;
    DeRef(_26804);
    _26804 = NOVALUE;
    DeRef(_26857);
    _26857 = NOVALUE;
    _26945 = NOVALUE;
    DeRef(_26978);
    _26978 = NOVALUE;
    DeRef(_26670);
    _26670 = NOVALUE;
    DeRef(_26694);
    _26694 = NOVALUE;
    _26696 = NOVALUE;
    DeRef(_26829);
    _26829 = NOVALUE;
    DeRef(_27050);
    _27050 = NOVALUE;
    DeRef(_26708);
    _26708 = NOVALUE;
    DeRef(_26727);
    _26727 = NOVALUE;
    DeRef(_26794);
    _26794 = NOVALUE;
    DeRef(_26874);
    _26874 = NOVALUE;
    DeRef(_26926);
    _26926 = NOVALUE;
    _26737 = NOVALUE;
    DeRef(_26835);
    _26835 = NOVALUE;
    DeRef(_26940);
    _26940 = NOVALUE;
    _26713 = NOVALUE;
    DeRef(_26936);
    _26936 = NOVALUE;
    DeRef(_27156);
    _27156 = NOVALUE;
    DeRef(_26679);
    _26679 = NOVALUE;
    DeRef(_26719);
    _26719 = NOVALUE;
    DeRef(_26867);
    _26867 = NOVALUE;
    DeRef(_27037);
    _27037 = NOVALUE;
    DeRef(_26905);
    _26905 = NOVALUE;
    DeRef(_27078);
    _27078 = NOVALUE;
    DeRef(_26655);
    _26655 = NOVALUE;
    DeRef(_26673);
    _26673 = NOVALUE;
    _26711 = NOVALUE;
    DeRef(_26863);
    _26863 = NOVALUE;
    DeRef(_27015);
    _27015 = NOVALUE;
    DeRef(_26619);
    _26619 = NOVALUE;
    DeRef(_27086);
    _27086 = NOVALUE;
    _27159 = NOVALUE;
    DeRef(_26627);
    _26627 = NOVALUE;
    DeRef(_26740);
    _26740 = NOVALUE;
    DeRef(_26808);
    _26808 = NOVALUE;
    DeRef(_26663);
    _26663 = NOVALUE;
    DeRef(_26852);
    _26852 = NOVALUE;
    DeRef(_27066);
    _27066 = NOVALUE;
    DeRef(_27105);
    _27105 = NOVALUE;
    DeRef(_26810);
    _26810 = NOVALUE;
    DeRef(_26848);
    _26848 = NOVALUE;
    DeRef(_27033);
    _27033 = NOVALUE;
    DeRef(_27144);
    _27144 = NOVALUE;
    DeRef(_26996);
    _26996 = NOVALUE;
    DeRef(_26788);
    _26788 = NOVALUE;
    DeRef(_26948);
    _26948 = NOVALUE;
    DeRef(_26675);
    _26675 = NOVALUE;
    DeRef(_26698);
    _26698 = NOVALUE;
    DeRef(_26767);
    _26767 = NOVALUE;
    _26943 = NOVALUE;
    DeRef(_27148);
    _27148 = NOVALUE;
    _26643 = NOVALUE;
    DeRef(_27064);
    _27064 = NOVALUE;
    _26742 = NOVALUE;
    DeRef(_26887);
    _26887 = NOVALUE;
    DeRef(_26932);
    _26932 = NOVALUE;
    DeRef(_27001);
    _27001 = NOVALUE;
    DeRef(_27020);
    _27020 = NOVALUE;
    DeRef(_27098);
    _27098 = NOVALUE;
    DeRef(_26831);
    _26831 = NOVALUE;
    DeRef(_26881);
    _26881 = NOVALUE;
    DeRef(_27008);
    _27008 = NOVALUE;
    DeRef(_26733);
    _26733 = NOVALUE;
    DeRef(_27090);
    _27090 = NOVALUE;
    DeRef(_26621);
    _26621 = NOVALUE;
    DeRef(_26660);
    _26660 = NOVALUE;
    DeRef(_26754);
    _26754 = NOVALUE;
    DeRef(_26826);
    _26826 = NOVALUE;
    DeRef(_26861);
    _26861 = NOVALUE;
    DeRef(_27027);
    _27027 = NOVALUE;
    DeRef(_27074);
    _27074 = NOVALUE;
    DeRef(_27094);
    _27094 = NOVALUE;
    return;
    ;
}


void _41emit_assign_op(int _op_52564)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_op_52564)) {
        _1 = (long)(DBL_PTR(_op_52564)->dbl);
        DeRefDS(_op_52564);
        _op_52564 = _1;
    }

    /** 	if op = PLUS_EQUALS then*/
    if (_op_52564 != 515)
    goto L1; // [7] 21

    /** 		emit_op(PLUS)*/
    _41emit_op(11);
    goto L2; // [18] 86
L1: 

    /** 	elsif op = MINUS_EQUALS then*/
    if (_op_52564 != 516)
    goto L3; // [25] 39

    /** 		emit_op(MINUS)*/
    _41emit_op(10);
    goto L2; // [36] 86
L3: 

    /** 	elsif op = MULTIPLY_EQUALS then*/
    if (_op_52564 != 517)
    goto L4; // [43] 55

    /** 		emit_op(rw:MULTIPLY)*/
    _41emit_op(13);
    goto L2; // [52] 86
L4: 

    /** 	elsif op = DIVIDE_EQUALS then*/
    if (_op_52564 != 518)
    goto L5; // [59] 71

    /** 		emit_op(rw:DIVIDE)*/
    _41emit_op(14);
    goto L2; // [68] 86
L5: 

    /** 	elsif op = CONCAT_EQUALS then*/
    if (_op_52564 != 519)
    goto L6; // [75] 85

    /** 		emit_op(rw:CONCAT)*/
    _41emit_op(15);
L6: 
L2: 

    /** end procedure*/
    return;
    ;
}


void _41StartSourceLine(int _sl_52584, int _dup_ok_52585, int _emit_coverage_52586)
{
    int _line_span_52589 = NOVALUE;
    int _27211 = NOVALUE;
    int _27209 = NOVALUE;
    int _27208 = NOVALUE;
    int _27207 = NOVALUE;
    int _27206 = NOVALUE;
    int _27205 = NOVALUE;
    int _27203 = NOVALUE;
    int _27200 = NOVALUE;
    int _27198 = NOVALUE;
    int _27197 = NOVALUE;
    int _27196 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_sl_52584)) {
        _1 = (long)(DBL_PTR(_sl_52584)->dbl);
        DeRefDS(_sl_52584);
        _sl_52584 = _1;
    }
    if (!IS_ATOM_INT(_dup_ok_52585)) {
        _1 = (long)(DBL_PTR(_dup_ok_52585)->dbl);
        DeRefDS(_dup_ok_52585);
        _dup_ok_52585 = _1;
    }
    if (!IS_ATOM_INT(_emit_coverage_52586)) {
        _1 = (long)(DBL_PTR(_emit_coverage_52586)->dbl);
        DeRefDS(_emit_coverage_52586);
        _emit_coverage_52586 = _1;
    }

    /** 	if gline_number = LastLineNumber then*/
    if (_35gline_number_16249 != _61LastLineNumber_23900)
    goto L1; // [13] 66

    /** 		if length(LineTable) then*/
    if (IS_SEQUENCE(_35LineTable_16333)){
            _27196 = SEQ_PTR(_35LineTable_16333)->length;
    }
    else {
        _27196 = 1;
    }
    if (_27196 == 0)
    {
        _27196 = NOVALUE;
        goto L2; // [24] 55
    }
    else{
        _27196 = NOVALUE;
    }

    /** 			if dup_ok then*/
    if (_dup_ok_52585 == 0)
    {
        goto L3; // [29] 47
    }
    else{
    }

    /** 				emit_op( STARTLINE )*/
    _41emit_op(58);

    /** 				emit_addr( gline_number )*/
    _41emit_addr(_35gline_number_16249);
L3: 

    /** 			return -- ignore duplicates*/
    return;
    goto L4; // [52] 65
L2: 

    /** 			sl = FALSE -- top-level new statement to execute on same line*/
    _sl_52584 = _13FALSE_434;
L4: 
L1: 

    /** 	LastLineNumber = gline_number*/
    _61LastLineNumber_23900 = _35gline_number_16249;

    /** 	line_span = gline_number - SymTab[CurrentSub][S_FIRSTLINE]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _27197 = (int)*(((s1_ptr)_2)->base + _35CurrentSub_16252);
    _2 = (int)SEQ_PTR(_27197);
    if (!IS_ATOM_INT(_35S_FIRSTLINE_15957)){
        _27198 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FIRSTLINE_15957)->dbl));
    }
    else{
        _27198 = (int)*(((s1_ptr)_2)->base + _35S_FIRSTLINE_15957);
    }
    _27197 = NOVALUE;
    if (IS_ATOM_INT(_27198)) {
        _line_span_52589 = _35gline_number_16249 - _27198;
    }
    else {
        _line_span_52589 = binary_op(MINUS, _35gline_number_16249, _27198);
    }
    _27198 = NOVALUE;
    if (!IS_ATOM_INT(_line_span_52589)) {
        _1 = (long)(DBL_PTR(_line_span_52589)->dbl);
        DeRefDS(_line_span_52589);
        _line_span_52589 = _1;
    }

    /** 	while length(LineTable) < line_span do*/
L5: 
    if (IS_SEQUENCE(_35LineTable_16333)){
            _27200 = SEQ_PTR(_35LineTable_16333)->length;
    }
    else {
        _27200 = 1;
    }
    if (_27200 >= _line_span_52589)
    goto L6; // [109] 128

    /** 		LineTable = append(LineTable, -1) -- filler*/
    Append(&_35LineTable_16333, _35LineTable_16333, -1);

    /** 	end while*/
    goto L5; // [125] 104
L6: 

    /** 	LineTable = append(LineTable, length(Code))*/
    if (IS_SEQUENCE(_35Code_16332)){
            _27203 = SEQ_PTR(_35Code_16332)->length;
    }
    else {
        _27203 = 1;
    }
    Append(&_35LineTable_16333, _35LineTable_16333, _27203);
    _27203 = NOVALUE;

    /** 	if sl and (TRANSLATE or (OpTrace or OpProfileStatement)) then*/
    if (_sl_52584 == 0) {
        goto L7; // [145] 190
    }
    if (_35TRANSLATE_15887 != 0) {
        DeRef(_27206);
        _27206 = 1;
        goto L8; // [151] 171
    }
    if (_35OpTrace_16313 != 0) {
        _27207 = 1;
        goto L9; // [157] 167
    }
    _27207 = (_35OpProfileStatement_16315 != 0);
L9: 
    DeRef(_27206);
    _27206 = (_27207 != 0);
L8: 
    if (_27206 == 0)
    {
        _27206 = NOVALUE;
        goto L7; // [172] 190
    }
    else{
        _27206 = NOVALUE;
    }

    /** 		emit_op(STARTLINE)*/
    _41emit_op(58);

    /** 		emit_addr(gline_number)*/
    _41emit_addr(_35gline_number_16249);
L7: 

    /** 	if (sl and emit_coverage = COVERAGE_INCLUDE) or emit_coverage = COVERAGE_OVERRIDE then*/
    if (_sl_52584 == 0) {
        _27208 = 0;
        goto LA; // [192] 206
    }
    _27209 = (_emit_coverage_52586 == 2);
    _27208 = (_27209 != 0);
LA: 
    if (_27208 != 0) {
        goto LB; // [206] 221
    }
    _27211 = (_emit_coverage_52586 == 3);
    if (_27211 == 0)
    {
        DeRef(_27211);
        _27211 = NOVALUE;
        goto LC; // [217] 229
    }
    else{
        DeRef(_27211);
        _27211 = NOVALUE;
    }
LB: 

    /** 		include_line( gline_number )*/
    _50include_line(_35gline_number_16249);
LC: 

    /** end procedure*/
    DeRef(_27209);
    _27209 = NOVALUE;
    return;
    ;
}


int _41has_forward_params(int _sym_52643)
{
    int _27217 = NOVALUE;
    int _27216 = NOVALUE;
    int _27215 = NOVALUE;
    int _27214 = NOVALUE;
    int _27213 = NOVALUE;
    int _27212 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_sym_52643)) {
        _1 = (long)(DBL_PTR(_sym_52643)->dbl);
        DeRefDS(_sym_52643);
        _sym_52643 = _1;
    }

    /** 	for i = cgi - (SymTab[sym][S_NUM_ARGS]-1) to cgi do*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _27212 = (int)*(((s1_ptr)_2)->base + _sym_52643);
    _2 = (int)SEQ_PTR(_27212);
    if (!IS_ATOM_INT(_35S_NUM_ARGS_15968)){
        _27213 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NUM_ARGS_15968)->dbl));
    }
    else{
        _27213 = (int)*(((s1_ptr)_2)->base + _35S_NUM_ARGS_15968);
    }
    _27212 = NOVALUE;
    if (IS_ATOM_INT(_27213)) {
        _27214 = _27213 - 1;
        if ((long)((unsigned long)_27214 +(unsigned long) HIGH_BITS) >= 0){
            _27214 = NewDouble((double)_27214);
        }
    }
    else {
        _27214 = binary_op(MINUS, _27213, 1);
    }
    _27213 = NOVALUE;
    if (IS_ATOM_INT(_27214)) {
        _27215 = _41cgi_50238 - _27214;
        if ((long)((unsigned long)_27215 +(unsigned long) HIGH_BITS) >= 0){
            _27215 = NewDouble((double)_27215);
        }
    }
    else {
        _27215 = binary_op(MINUS, _41cgi_50238, _27214);
    }
    DeRef(_27214);
    _27214 = NOVALUE;
    _27216 = _41cgi_50238;
    {
        int _i_52645;
        Ref(_27215);
        _i_52645 = _27215;
L1: 
        if (binary_op_a(GREATER, _i_52645, _27216)){
            goto L2; // [32] 65
        }

        /** 		if cg_stack[i] < 0 then*/
        _2 = (int)SEQ_PTR(_41cg_stack_50237);
        if (!IS_ATOM_INT(_i_52645)){
            _27217 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_52645)->dbl));
        }
        else{
            _27217 = (int)*(((s1_ptr)_2)->base + _i_52645);
        }
        if (binary_op_a(GREATEREQ, _27217, 0)){
            _27217 = NOVALUE;
            goto L3; // [47] 58
        }
        _27217 = NOVALUE;

        /** 			return 1*/
        DeRef(_i_52645);
        DeRef(_27215);
        _27215 = NOVALUE;
        return 1;
L3: 

        /** 	end for*/
        _0 = _i_52645;
        if (IS_ATOM_INT(_i_52645)) {
            _i_52645 = _i_52645 + 1;
            if ((long)((unsigned long)_i_52645 +(unsigned long) HIGH_BITS) >= 0){
                _i_52645 = NewDouble((double)_i_52645);
            }
        }
        else {
            _i_52645 = binary_op_a(PLUS, _i_52645, 1);
        }
        DeRef(_0);
        goto L1; // [60] 39
L2: 
        ;
        DeRef(_i_52645);
    }

    /** 	return 0*/
    DeRef(_27215);
    _27215 = NOVALUE;
    return 0;
    ;
}



// 0x010C296C
