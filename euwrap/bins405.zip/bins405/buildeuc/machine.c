// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int _9allocate(int _n_982, int _cleanup_983)
{
    int _iaddr_984 = NOVALUE;
    int _eaddr_985 = NOVALUE;
    int _371 = NOVALUE;
    int _370 = NOVALUE;
    int _0, _1, _2;
    

    /** 	ifdef DATA_EXECUTE then*/

    /** 		iaddr = eu:machine_func( memconst:M_ALLOC, n + memory:BORDER_SPACE * 2)*/
    _370 = 0;
    _371 = _n_982 + 0;
    _370 = NOVALUE;
    DeRef(_iaddr_984);
    _iaddr_984 = machine(16, _371);
    _371 = NOVALUE;

    /** 		eaddr = memory:prepare_block( iaddr, n, PAGE_READ_WRITE )*/
    Ref(_iaddr_984);
    _0 = _eaddr_985;
    _eaddr_985 = _11prepare_block(_iaddr_984, _n_982, 4);
    DeRef(_0);

    /** 	if cleanup then*/

    /** 	return eaddr*/
    DeRef(_iaddr_984);
    return _eaddr_985;
    ;
}


int _9allocate_data(int _n_995, int _cleanup_996)
{
    int _a_997 = NOVALUE;
    int _sla_999 = NOVALUE;
    int _376 = NOVALUE;
    int _375 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = eu:machine_func( memconst:M_ALLOC, n+BORDER_SPACE*2)*/
    _375 = 0;
    _376 = 4;
    _375 = NOVALUE;
    DeRef(_a_997);
    _a_997 = machine(16, 4);
    _376 = NOVALUE;

    /** 	sla = memory:prepare_block(a, n, PAGE_READ_WRITE )*/
    Ref(_a_997);
    _0 = _sla_999;
    _sla_999 = _11prepare_block(_a_997, 4, 4);
    DeRef(_0);

    /** 	if cleanup then*/

    /** 		return sla*/
    DeRef(_a_997);
    return _sla_999;
    ;
}


int _9VirtualAlloc(int _addr_1156, int _size_1157, int _allocation_type_1158, int _protect__1159)
{
    int _r1_1160 = NOVALUE;
    int _459 = NOVALUE;
    int _0, _1, _2;
    

    /** 		r1 = c_func( VirtualAlloc_rid, {addr, size, allocation_type, protect_ } )*/
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 0;
    *((int *)(_2+8)) = 1;
    Ref(_allocation_type_1158);
    *((int *)(_2+12)) = _allocation_type_1158;
    *((int *)(_2+16)) = 64;
    _459 = MAKE_SEQ(_1);
    DeRef(_r1_1160);
    _r1_1160 = call_c(1, _9VirtualAlloc_rid_1095, _459);
    DeRefDS(_459);
    _459 = NOVALUE;

    /** 		return r1*/
    DeRef(_allocation_type_1158);
    return _r1_1160;
    ;
}


int _9allocate_string(int _s_1179, int _cleanup_1180)
{
    int _mem_1181 = NOVALUE;
    int _466 = NOVALUE;
    int _465 = NOVALUE;
    int _463 = NOVALUE;
    int _462 = NOVALUE;
    int _0, _1, _2;
    

    /** 	mem = allocate( length(s) + 1) -- Thanks to Igor*/
    if (IS_SEQUENCE(_s_1179)){
            _462 = SEQ_PTR(_s_1179)->length;
    }
    else {
        _462 = 1;
    }
    _463 = _462 + 1;
    _462 = NOVALUE;
    _0 = _mem_1181;
    _mem_1181 = _9allocate(_463, 0);
    DeRef(_0);
    _463 = NOVALUE;

    /** 	if mem then*/
    if (_mem_1181 == 0) {
        goto L1; // [19] 54
    }
    else {
        if (!IS_ATOM_INT(_mem_1181) && DBL_PTR(_mem_1181)->dbl == 0.0){
            goto L1; // [19] 54
        }
    }

    /** 		poke(mem, s)*/
    if (IS_ATOM_INT(_mem_1181)){
        poke_addr = (unsigned char *)_mem_1181;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_mem_1181)->dbl);
    }
    _1 = (int)SEQ_PTR(_s_1179);
    _1 = (int)((s1_ptr)_1)->base;
    while (1) {
        _1 += 4;
        _2 = *((int *)_1);
        if (IS_ATOM_INT(_2))
        *poke_addr++ = (unsigned char)_2;
        else if (_2 == NOVALUE)
        break;
        else {
            *poke_addr++ = (signed char)DBL_PTR(_2)->dbl;
        }
    }

    /** 		poke(mem+length(s), 0)  -- Thanks to Aku*/
    if (IS_SEQUENCE(_s_1179)){
            _465 = SEQ_PTR(_s_1179)->length;
    }
    else {
        _465 = 1;
    }
    if (IS_ATOM_INT(_mem_1181)) {
        _466 = _mem_1181 + _465;
        if ((long)((unsigned long)_466 + (unsigned long)HIGH_BITS) >= 0) 
        _466 = NewDouble((double)_466);
    }
    else {
        _466 = NewDouble(DBL_PTR(_mem_1181)->dbl + (double)_465);
    }
    _465 = NOVALUE;
    if (IS_ATOM_INT(_466)){
        poke_addr = (unsigned char *)_466;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_466)->dbl);
    }
    *poke_addr = (unsigned char)0;
    DeRef(_466);
    _466 = NOVALUE;

    /** 		if cleanup then*/
L1: 

    /** 	return mem*/
    DeRefDS(_s_1179);
    return _mem_1181;
    ;
}


void _9free(int _addr_1288)
{
    int _msg_inlined_crash_at_27_1297 = NOVALUE;
    int _data_inlined_crash_at_24_1296 = NOVALUE;
    int _addr_inlined_deallocate_at_64_1303 = NOVALUE;
    int _msg_inlined_crash_at_106_1308 = NOVALUE;
    int _509 = NOVALUE;
    int _508 = NOVALUE;
    int _507 = NOVALUE;
    int _506 = NOVALUE;
    int _504 = NOVALUE;
    int _503 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if types:number_array (addr) then*/
    Ref(_addr_1288);
    _503 = _13number_array(_addr_1288);
    if (_503 == 0) {
        DeRef(_503);
        _503 = NOVALUE;
        goto L1; // [7] 97
    }
    else {
        if (!IS_ATOM_INT(_503) && DBL_PTR(_503)->dbl == 0.0){
            DeRef(_503);
            _503 = NOVALUE;
            goto L1; // [7] 97
        }
        DeRef(_503);
        _503 = NOVALUE;
    }
    DeRef(_503);
    _503 = NOVALUE;

    /** 		if types:ascii_string(addr) then*/
    Ref(_addr_1288);
    _504 = _13ascii_string(_addr_1288);
    if (_504 == 0) {
        DeRef(_504);
        _504 = NOVALUE;
        goto L2; // [16] 47
    }
    else {
        if (!IS_ATOM_INT(_504) && DBL_PTR(_504)->dbl == 0.0){
            DeRef(_504);
            _504 = NOVALUE;
            goto L2; // [16] 47
        }
        DeRef(_504);
        _504 = NOVALUE;
    }
    DeRef(_504);
    _504 = NOVALUE;

    /** 			error:crash("free(\"%s\") is not a valid address", {addr})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_addr_1288);
    *((int *)(_2+4)) = _addr_1288;
    _506 = MAKE_SEQ(_1);
    DeRef(_data_inlined_crash_at_24_1296);
    _data_inlined_crash_at_24_1296 = _506;
    _506 = NOVALUE;

    /** 	msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_27_1297);
    _msg_inlined_crash_at_27_1297 = EPrintf(-9999999, _505, _data_inlined_crash_at_24_1296);

    /** 	machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_27_1297);

    /** end procedure*/
    goto L3; // [41] 44
L3: 
    DeRef(_data_inlined_crash_at_24_1296);
    _data_inlined_crash_at_24_1296 = NOVALUE;
    DeRefi(_msg_inlined_crash_at_27_1297);
    _msg_inlined_crash_at_27_1297 = NOVALUE;
L2: 

    /** 		for i = 1 to length(addr) do*/
    if (IS_SEQUENCE(_addr_1288)){
            _507 = SEQ_PTR(_addr_1288)->length;
    }
    else {
        _507 = 1;
    }
    {
        int _i_1299;
        _i_1299 = 1;
L4: 
        if (_i_1299 > _507){
            goto L5; // [52] 89
        }

        /** 			memory:deallocate( addr[i] )*/
        _2 = (int)SEQ_PTR(_addr_1288);
        _508 = (int)*(((s1_ptr)_2)->base + _i_1299);
        Ref(_508);
        DeRef(_addr_inlined_deallocate_at_64_1303);
        _addr_inlined_deallocate_at_64_1303 = _508;
        _508 = NOVALUE;

        /** 	ifdef DATA_EXECUTE and WINDOWS then*/

        /**    	machine_proc( memconst:M_FREE, addr)*/
        machine(17, _addr_inlined_deallocate_at_64_1303);

        /** end procedure*/
        goto L6; // [77] 80
L6: 
        DeRef(_addr_inlined_deallocate_at_64_1303);
        _addr_inlined_deallocate_at_64_1303 = NOVALUE;

        /** 		end for*/
        _i_1299 = _i_1299 + 1;
        goto L4; // [84] 59
L5: 
        ;
    }

    /** 		return*/
    DeRef(_addr_1288);
    return;
    goto L7; // [94] 127
L1: 

    /** 	elsif sequence(addr) then*/
    _509 = IS_SEQUENCE(_addr_1288);
    if (_509 == 0)
    {
        _509 = NOVALUE;
        goto L8; // [102] 126
    }
    else{
        _509 = NOVALUE;
    }

    /** 		error:crash("free() called with nested sequence")*/

    /** 	msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_106_1308);
    _msg_inlined_crash_at_106_1308 = EPrintf(-9999999, _510, _5);

    /** 	machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_106_1308);

    /** end procedure*/
    goto L9; // [120] 123
L9: 
    DeRefi(_msg_inlined_crash_at_106_1308);
    _msg_inlined_crash_at_106_1308 = NOVALUE;
L8: 
L7: 

    /** 	if addr = 0 then*/
    if (binary_op_a(NOTEQ, _addr_1288, 0)){
        goto LA; // [129] 139
    }

    /** 		return*/
    DeRef(_addr_1288);
    return;
LA: 

    /** 	memory:deallocate( addr )*/

    /** 	ifdef DATA_EXECUTE and WINDOWS then*/

    /**    	machine_proc( memconst:M_FREE, addr)*/
    machine(17, _addr_1288);

    /** end procedure*/
    goto LB; // [150] 153
LB: 

    /** end procedure*/
    DeRef(_addr_1288);
    return;
    ;
}


void _9free_pointer_array(int _pointers_array_1316)
{
    int _saved_1317 = NOVALUE;
    int _ptr_1318 = NOVALUE;
    int _0, _1, _2;
    

    /** 	atom saved = pointers_array*/
    Ref(_pointers_array_1316);
    DeRef(_saved_1317);
    _saved_1317 = _pointers_array_1316;

    /** 	while ptr with entry do*/
    goto L1; // [8] 39
L2: 
    if (_ptr_1318 <= 0) {
        if (_ptr_1318 == 0) {
            goto L3; // [13] 49
        }
        else {
            if (!IS_ATOM_INT(_ptr_1318) && DBL_PTR(_ptr_1318)->dbl == 0.0){
                goto L3; // [13] 49
            }
        }
    }

    /** 		memory:deallocate( ptr )*/

    /** 	ifdef DATA_EXECUTE and WINDOWS then*/

    /**    	machine_proc( memconst:M_FREE, addr)*/
    machine(17, _ptr_1318);

    /** end procedure*/
    goto L4; // [27] 30
L4: 

    /** 		pointers_array += ADDRESS_LENGTH*/
    _0 = _pointers_array_1316;
    if (IS_ATOM_INT(_pointers_array_1316)) {
        _pointers_array_1316 = _pointers_array_1316 + 4;
        if ((long)((unsigned long)_pointers_array_1316 + (unsigned long)HIGH_BITS) >= 0) 
        _pointers_array_1316 = NewDouble((double)_pointers_array_1316);
    }
    else {
        _pointers_array_1316 = NewDouble(DBL_PTR(_pointers_array_1316)->dbl + (double)4);
    }
    DeRef(_0);

    /** 	entry*/
L1: 

    /** 		ptr = peek4u(pointers_array)*/
    DeRef(_ptr_1318);
    if (IS_ATOM_INT(_pointers_array_1316)) {
        _ptr_1318 = *(unsigned long *)_pointers_array_1316;
        if ((unsigned)_ptr_1318 > (unsigned)MAXINT)
        _ptr_1318 = NewDouble((double)(unsigned long)_ptr_1318);
    }
    else {
        _ptr_1318 = *(unsigned long *)(unsigned long)(DBL_PTR(_pointers_array_1316)->dbl);
        if ((unsigned)_ptr_1318 > (unsigned)MAXINT)
        _ptr_1318 = NewDouble((double)(unsigned long)_ptr_1318);
    }

    /** 	end while*/
    goto L2; // [46] 11
L3: 

    /** 	free(saved)*/
    Ref(_saved_1317);
    _9free(_saved_1317);

    /** end procedure*/
    DeRef(_pointers_array_1316);
    DeRef(_saved_1317);
    DeRef(_ptr_1318);
    return;
    ;
}



// 0xD959794F
