// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

void _44screen_output(int _f_48529, int _msg_48530)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_f_48529)) {
        _1 = (long)(DBL_PTR(_f_48529)->dbl);
        DeRefDS(_f_48529);
        _f_48529 = _1;
    }

    /** 	puts(f, msg)*/
    EPuts(_f_48529, _msg_48530); // DJP 

    /** end procedure*/
    DeRefDS(_msg_48530);
    return;
    ;
}


void _44Warning(int _msg_48533, int _mask_48534, int _args_48535)
{
    int _orig_mask_48536 = NOVALUE;
    int _text_48537 = NOVALUE;
    int _w_name_48538 = NOVALUE;
    int _25389 = NOVALUE;
    int _25387 = NOVALUE;
    int _25385 = NOVALUE;
    int _25382 = NOVALUE;
    int _25377 = NOVALUE;
    int _25375 = NOVALUE;
    int _25374 = NOVALUE;
    int _25373 = NOVALUE;
    int _25372 = NOVALUE;
    int _25370 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_mask_48534)) {
        _1 = (long)(DBL_PTR(_mask_48534)->dbl);
        DeRefDS(_mask_48534);
        _mask_48534 = _1;
    }

    /** 	if display_warnings = 0 then*/
    if (_44display_warnings_48517 != 0)
    goto L1; // [9] 19

    /** 		return*/
    DeRef(_msg_48533);
    DeRefDS(_args_48535);
    DeRef(_text_48537);
    DeRef(_w_name_48538);
    return;
L1: 

    /** 	if not Strict_is_on or Strict_Override then*/
    _25370 = (_35Strict_is_on_16309 == 0);
    if (_25370 != 0) {
        goto L2; // [26] 37
    }
    if (_35Strict_Override_16310 == 0)
    {
        goto L3; // [33] 56
    }
    else{
    }
L2: 

    /** 		if find(mask, strict_only_warnings) then*/
    _25372 = find_from(_mask_48534, _35strict_only_warnings_16307, 1);
    if (_25372 == 0)
    {
        _25372 = NOVALUE;
        goto L4; // [46] 55
    }
    else{
        _25372 = NOVALUE;
    }

    /** 			return*/
    DeRef(_msg_48533);
    DeRefDS(_args_48535);
    DeRef(_text_48537);
    DeRef(_w_name_48538);
    DeRef(_25370);
    _25370 = NOVALUE;
    return;
L4: 
L3: 

    /** 	orig_mask = mask -- =0 for non maskable warnings - none implemented so far*/
    _orig_mask_48536 = _mask_48534;

    /** 	if Strict_is_on and Strict_Override = 0 then*/
    if (_35Strict_is_on_16309 == 0) {
        goto L5; // [65] 85
    }
    _25374 = (_35Strict_Override_16310 == 0);
    if (_25374 == 0)
    {
        DeRef(_25374);
        _25374 = NOVALUE;
        goto L5; // [76] 85
    }
    else{
        DeRef(_25374);
        _25374 = NOVALUE;
    }

    /** 		mask = 0*/
    _mask_48534 = 0;
L5: 

    /** 	if mask = 0 or and_bits(OpWarning, mask) then*/
    _25375 = (_mask_48534 == 0);
    if (_25375 != 0) {
        goto L6; // [91] 106
    }
    {unsigned long tu;
         tu = (unsigned long)_35OpWarning_16311 & (unsigned long)_mask_48534;
         _25377 = MAKE_UINT(tu);
    }
    if (_25377 == 0) {
        DeRef(_25377);
        _25377 = NOVALUE;
        goto L7; // [102] 213
    }
    else {
        if (!IS_ATOM_INT(_25377) && DBL_PTR(_25377)->dbl == 0.0){
            DeRef(_25377);
            _25377 = NOVALUE;
            goto L7; // [102] 213
        }
        DeRef(_25377);
        _25377 = NOVALUE;
    }
    DeRef(_25377);
    _25377 = NOVALUE;
L6: 

    /** 		if orig_mask != 0 then*/
    if (_orig_mask_48536 == 0)
    goto L8; // [108] 122

    /** 			orig_mask = find(orig_mask,warning_flags)*/
    _orig_mask_48536 = find_from(_orig_mask_48536, _35warning_flags_16286, 1);
L8: 

    /** 		if orig_mask != 0 then*/
    if (_orig_mask_48536 == 0)
    goto L9; // [124] 145

    /** 			w_name = "{ " & warning_names[orig_mask] & " }"*/
    _2 = (int)SEQ_PTR(_35warning_names_16288);
    _25382 = (int)*(((s1_ptr)_2)->base + _orig_mask_48536);
    {
        int concat_list[3];

        concat_list[0] = _25383;
        concat_list[1] = _25382;
        concat_list[2] = _25381;
        Concat_N((object_ptr)&_w_name_48538, concat_list, 3);
    }
    _25382 = NOVALUE;
    goto LA; // [142] 153
L9: 

    /** 			w_name = "" -- not maskable*/
    RefDS(_22023);
    DeRef(_w_name_48538);
    _w_name_48538 = _22023;
LA: 

    /** 		if atom(msg) then*/
    _25385 = IS_ATOM(_msg_48533);
    if (_25385 == 0)
    {
        _25385 = NOVALUE;
        goto LB; // [158] 170
    }
    else{
        _25385 = NOVALUE;
    }

    /** 			msg = GetMsgText(msg, 1, args)*/
    Ref(_msg_48533);
    RefDS(_args_48535);
    _0 = _msg_48533;
    _msg_48533 = _45GetMsgText(_msg_48533, 1, _args_48535);
    DeRef(_0);
LB: 

    /** 		text = GetMsgText(204, 0, {w_name, msg})*/
    Ref(_msg_48533);
    RefDS(_w_name_48538);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _w_name_48538;
    ((int *)_2)[2] = _msg_48533;
    _25387 = MAKE_SEQ(_1);
    _0 = _text_48537;
    _text_48537 = _45GetMsgText(204, 0, _25387);
    DeRef(_0);
    _25387 = NOVALUE;

    /** 		if find(text, warning_list) then*/
    _25389 = find_from(_text_48537, _44warning_list_48526, 1);
    if (_25389 == 0)
    {
        _25389 = NOVALUE;
        goto LC; // [195] 204
    }
    else{
        _25389 = NOVALUE;
    }

    /** 			return -- duplicate*/
    DeRef(_msg_48533);
    DeRefDS(_args_48535);
    DeRefDS(_text_48537);
    DeRefDS(_w_name_48538);
    DeRef(_25370);
    _25370 = NOVALUE;
    DeRef(_25375);
    _25375 = NOVALUE;
    return;
LC: 

    /** 		warning_list = append(warning_list, text)*/
    RefDS(_text_48537);
    Append(&_44warning_list_48526, _44warning_list_48526, _text_48537);
L7: 

    /** end procedure*/
    DeRef(_msg_48533);
    DeRefDS(_args_48535);
    DeRef(_text_48537);
    DeRef(_w_name_48538);
    DeRef(_25370);
    _25370 = NOVALUE;
    DeRef(_25375);
    _25375 = NOVALUE;
    return;
    ;
}


void _44Log_warnings(int _policy_48583)
{
    int _25397 = NOVALUE;
    int _25396 = NOVALUE;
    int _25395 = NOVALUE;
    int _25394 = NOVALUE;
    int _25392 = NOVALUE;
    int _25391 = NOVALUE;
    int _0, _1, _2;
    

    /** 	display_warnings = 1*/
    _44display_warnings_48517 = 1;

    /** 	if sequence(policy) then*/
    _25391 = IS_SEQUENCE(_policy_48583);
    if (_25391 == 0)
    {
        _25391 = NOVALUE;
        goto L1; // [11] 34
    }
    else{
        _25391 = NOVALUE;
    }

    /** 		if length(policy)=0 then*/
    if (IS_SEQUENCE(_policy_48583)){
            _25392 = SEQ_PTR(_policy_48583)->length;
    }
    else {
        _25392 = 1;
    }
    if (_25392 != 0)
    goto L2; // [19] 82

    /** 			policy = STDERR*/
    DeRef(_policy_48583);
    _policy_48583 = 2;
    goto L2; // [31] 82
L1: 

    /** 		if policy >= 0 and policy < STDERR+1 then*/
    if (IS_ATOM_INT(_policy_48583)) {
        _25394 = (_policy_48583 >= 0);
    }
    else {
        _25394 = binary_op(GREATEREQ, _policy_48583, 0);
    }
    if (IS_ATOM_INT(_25394)) {
        if (_25394 == 0) {
            goto L3; // [40] 68
        }
    }
    else {
        if (DBL_PTR(_25394)->dbl == 0.0) {
            goto L3; // [40] 68
        }
    }
    _25396 = 3;
    if (IS_ATOM_INT(_policy_48583)) {
        _25397 = (_policy_48583 < 3);
    }
    else {
        _25397 = binary_op(LESS, _policy_48583, 3);
    }
    _25396 = NOVALUE;
    if (_25397 == 0) {
        DeRef(_25397);
        _25397 = NOVALUE;
        goto L3; // [55] 68
    }
    else {
        if (!IS_ATOM_INT(_25397) && DBL_PTR(_25397)->dbl == 0.0){
            DeRef(_25397);
            _25397 = NOVALUE;
            goto L3; // [55] 68
        }
        DeRef(_25397);
        _25397 = NOVALUE;
    }
    DeRef(_25397);
    _25397 = NOVALUE;

    /** 			policy  = STDERR*/
    DeRef(_policy_48583);
    _policy_48583 = 2;
    goto L4; // [65] 81
L3: 

    /** 		elsif policy < 0 then*/
    if (binary_op_a(GREATEREQ, _policy_48583, 0)){
        goto L5; // [70] 80
    }

    /** 			display_warnings = 0*/
    _44display_warnings_48517 = 0;
L5: 
L4: 
L2: 

    /** end procedure*/
    DeRef(_policy_48583);
    DeRef(_25394);
    _25394 = NOVALUE;
    return;
    ;
}


int _44ShowWarnings()
{
    int _c_48602 = NOVALUE;
    int _errfile_48603 = NOVALUE;
    int _twf_48604 = NOVALUE;
    int _25428 = NOVALUE;
    int _25425 = NOVALUE;
    int _25424 = NOVALUE;
    int _25423 = NOVALUE;
    int _25422 = NOVALUE;
    int _25421 = NOVALUE;
    int _25420 = NOVALUE;
    int _25418 = NOVALUE;
    int _25417 = NOVALUE;
    int _25416 = NOVALUE;
    int _25414 = NOVALUE;
    int _25413 = NOVALUE;
    int _25412 = NOVALUE;
    int _25411 = NOVALUE;
    int _25409 = NOVALUE;
    int _25405 = NOVALUE;
    int _25403 = NOVALUE;
    int _25402 = NOVALUE;
    int _25401 = NOVALUE;
    int _25399 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if display_warnings = 0 or length(warning_list) = 0 then*/
    _25399 = (_44display_warnings_48517 == 0);
    if (_25399 != 0) {
        goto L1; // [9] 27
    }
    if (IS_SEQUENCE(_44warning_list_48526)){
            _25401 = SEQ_PTR(_44warning_list_48526)->length;
    }
    else {
        _25401 = 1;
    }
    _25402 = (_25401 == 0);
    _25401 = NOVALUE;
    if (_25402 == 0)
    {
        DeRef(_25402);
        _25402 = NOVALUE;
        goto L2; // [23] 39
    }
    else{
        DeRef(_25402);
        _25402 = NOVALUE;
    }
L1: 

    /** 		return length(warning_list)*/
    if (IS_SEQUENCE(_44warning_list_48526)){
            _25403 = SEQ_PTR(_44warning_list_48526)->length;
    }
    else {
        _25403 = 1;
    }
    DeRef(_25399);
    _25399 = NOVALUE;
    return _25403;
L2: 

    /** 	if TempErrFile > 0 then*/
    if (_44TempErrFile_48515 <= 0)
    goto L3; // [43] 57

    /** 		errfile = TempErrFile*/
    _errfile_48603 = _44TempErrFile_48515;
    goto L4; // [54] 67
L3: 

    /** 		errfile = STDERR*/
    _errfile_48603 = 2;
L4: 

    /** 	if not integer(TempWarningName) then*/
    if (IS_ATOM_INT(_35TempWarningName_16258))
    _25405 = 1;
    else if (IS_ATOM_DBL(_35TempWarningName_16258))
    _25405 = IS_ATOM_INT(DoubleToInt(_35TempWarningName_16258));
    else
    _25405 = 0;
    if (_25405 != 0)
    goto L5; // [74] 179
    _25405 = NOVALUE;

    /** 		twf = open(TempWarningName,"w")*/
    _twf_48604 = EOpen(_35TempWarningName_16258, _22129, 0);

    /** 		if twf = -1 then*/
    if (_twf_48604 != -1)
    goto L6; // [88] 136

    /** 			ShowMsg(errfile, 205, {TempWarningName})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_35TempWarningName_16258);
    *((int *)(_2+4)) = _35TempWarningName_16258;
    _25409 = MAKE_SEQ(_1);
    _45ShowMsg(_errfile_48603, 205, _25409, 1);
    _25409 = NOVALUE;

    /** 			if errfile != STDERR then*/
    if (_errfile_48603 == 2)
    goto L7; // [112] 173

    /** 				ShowMsg(STDERR, 205, {TempWarningName})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_35TempWarningName_16258);
    *((int *)(_2+4)) = _35TempWarningName_16258;
    _25411 = MAKE_SEQ(_1);
    _45ShowMsg(2, 205, _25411, 1);
    _25411 = NOVALUE;
    goto L7; // [133] 173
L6: 

    /** 			for i = 1 to length(warning_list) do*/
    if (IS_SEQUENCE(_44warning_list_48526)){
            _25412 = SEQ_PTR(_44warning_list_48526)->length;
    }
    else {
        _25412 = 1;
    }
    {
        int _i_48635;
        _i_48635 = 1;
L8: 
        if (_i_48635 > _25412){
            goto L9; // [143] 168
        }

        /** 				puts(twf, warning_list[i])*/
        _2 = (int)SEQ_PTR(_44warning_list_48526);
        _25413 = (int)*(((s1_ptr)_2)->base + _i_48635);
        EPuts(_twf_48604, _25413); // DJP 
        _25413 = NOVALUE;

        /** 			end for*/
        _i_48635 = _i_48635 + 1;
        goto L8; // [163] 150
L9: 
        ;
    }

    /** 		    close(twf)*/
    EClose(_twf_48604);
L7: 

    /** 		TempWarningName = 99 -- Flag that we have done this already.*/
    DeRef(_35TempWarningName_16258);
    _35TempWarningName_16258 = 99;
L5: 

    /** 	if batch_job = 0 or errfile != STDERR then*/
    _25414 = (_35batch_job_16257 == 0);
    if (_25414 != 0) {
        goto LA; // [187] 204
    }
    _25416 = (_errfile_48603 != 2);
    if (_25416 == 0)
    {
        DeRef(_25416);
        _25416 = NOVALUE;
        goto LB; // [200] 311
    }
    else{
        DeRef(_25416);
        _25416 = NOVALUE;
    }
LA: 

    /** 		for i = 1 to length(warning_list) do*/
    if (IS_SEQUENCE(_44warning_list_48526)){
            _25417 = SEQ_PTR(_44warning_list_48526)->length;
    }
    else {
        _25417 = 1;
    }
    {
        int _i_48646;
        _i_48646 = 1;
LC: 
        if (_i_48646 > _25417){
            goto LD; // [211] 310
        }

        /** 			puts(errfile, warning_list[i])*/
        _2 = (int)SEQ_PTR(_44warning_list_48526);
        _25418 = (int)*(((s1_ptr)_2)->base + _i_48646);
        EPuts(_errfile_48603, _25418); // DJP 
        _25418 = NOVALUE;

        /** 			if errfile = STDERR then*/
        if (_errfile_48603 != 2)
        goto LE; // [235] 303

        /** 				if remainder(i, 20) = 0 and batch_job = 0 and test_only = 0 then*/
        _25420 = (_i_48646 % 20);
        _25421 = (_25420 == 0);
        _25420 = NOVALUE;
        if (_25421 == 0) {
            _25422 = 0;
            goto LF; // [249] 263
        }
        _25423 = (_35batch_job_16257 == 0);
        _25422 = (_25423 != 0);
LF: 
        if (_25422 == 0) {
            goto L10; // [263] 302
        }
        _25425 = (_35test_only_16256 == 0);
        if (_25425 == 0)
        {
            DeRef(_25425);
            _25425 = NOVALUE;
            goto L10; // [274] 302
        }
        else{
            DeRef(_25425);
            _25425 = NOVALUE;
        }

        /** 					ShowMsg(errfile, 206)*/
        RefDS(_22023);
        _45ShowMsg(_errfile_48603, 206, _22023, 1);

        /** 					c = getc(0)*/
        if (0 != last_r_file_no) {
            last_r_file_ptr = which_file(0, EF_READ);
            last_r_file_no = 0;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _c_48602 = getKBchar();
            }
            else
            _c_48602 = getc(last_r_file_ptr);
        }
        else
        _c_48602 = getc(last_r_file_ptr);

        /** 					if c = 'q' then*/
        if (_c_48602 != 113)
        goto L11; // [292] 301

        /** 						exit*/
        goto LD; // [298] 310
L11: 
L10: 
LE: 

        /** 		end for*/
        _i_48646 = _i_48646 + 1;
        goto LC; // [305] 218
LD: 
        ;
    }
LB: 

    /** 	return length(warning_list)*/
    if (IS_SEQUENCE(_44warning_list_48526)){
            _25428 = SEQ_PTR(_44warning_list_48526)->length;
    }
    else {
        _25428 = 1;
    }
    DeRef(_25399);
    _25399 = NOVALUE;
    DeRef(_25414);
    _25414 = NOVALUE;
    DeRef(_25423);
    _25423 = NOVALUE;
    DeRef(_25421);
    _25421 = NOVALUE;
    return _25428;
    ;
}


void _44ShowDefines(int _errfile_48668)
{
    int _c_48669 = NOVALUE;
    int _25442 = NOVALUE;
    int _25441 = NOVALUE;
    int _25439 = NOVALUE;
    int _25438 = NOVALUE;
    int _25435 = NOVALUE;
    int _25434 = NOVALUE;
    int _25433 = NOVALUE;
    int _25432 = NOVALUE;
    int _25431 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_errfile_48668)) {
        _1 = (long)(DBL_PTR(_errfile_48668)->dbl);
        DeRefDS(_errfile_48668);
        _errfile_48668 = _1;
    }

    /** 	if errfile=0 then*/
    if (_errfile_48668 != 0)
    goto L1; // [5] 19

    /** 		errfile = STDERR*/
    _errfile_48668 = 2;
L1: 

    /** 	puts(errfile, format("\n--- [1] ---\n", {GetMsgText(207,0)}))*/
    RefDS(_22023);
    _25431 = _45GetMsgText(207, 0, _22023);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _25431;
    _25432 = MAKE_SEQ(_1);
    _25431 = NOVALUE;
    RefDS(_25430);
    _25433 = _14format(_25430, _25432);
    _25432 = NOVALUE;
    EPuts(_errfile_48668, _25433); // DJP 
    DeRef(_25433);
    _25433 = NOVALUE;

    /** 	for i = 1 to length(OpDefines) do*/
    if (IS_SEQUENCE(_35OpDefines_16317)){
            _25434 = SEQ_PTR(_35OpDefines_16317)->length;
    }
    else {
        _25434 = 1;
    }
    {
        int _i_48680;
        _i_48680 = 1;
L2: 
        if (_i_48680 > _25434){
            goto L3; // [46] 98
        }

        /** 		if find(OpDefines[i], {"_PLAT_START", "_PLAT_STOP"}) = 0 then*/
        _2 = (int)SEQ_PTR(_35OpDefines_16317);
        _25435 = (int)*(((s1_ptr)_2)->base + _i_48680);
        RefDS(_25437);
        RefDS(_25436);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _25436;
        ((int *)_2)[2] = _25437;
        _25438 = MAKE_SEQ(_1);
        _25439 = find_from(_25435, _25438, 1);
        _25435 = NOVALUE;
        DeRefDS(_25438);
        _25438 = NOVALUE;
        if (_25439 != 0)
        goto L4; // [70] 91

        /** 			printf(errfile, "%s\n", {OpDefines[i]})*/
        _2 = (int)SEQ_PTR(_35OpDefines_16317);
        _25441 = (int)*(((s1_ptr)_2)->base + _i_48680);
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        Ref(_25441);
        *((int *)(_2+4)) = _25441;
        _25442 = MAKE_SEQ(_1);
        _25441 = NOVALUE;
        EPrintf(_errfile_48668, _25311, _25442);
        DeRefDS(_25442);
        _25442 = NOVALUE;
L4: 

        /** 	end for*/
        _i_48680 = _i_48680 + 1;
        goto L2; // [93] 53
L3: 
        ;
    }

    /** 	puts(errfile, "-------------------\n")*/
    EPuts(_errfile_48668, _25443); // DJP 

    /** end procedure*/
    return;
    ;
}


void _44Cleanup(int _status_48697)
{
    int _w_48698 = NOVALUE;
    int _show_error_48699 = NOVALUE;
    int _25457 = NOVALUE;
    int _25456 = NOVALUE;
    int _25455 = NOVALUE;
    int _25454 = NOVALUE;
    int _25453 = NOVALUE;
    int _25452 = NOVALUE;
    int _25451 = NOVALUE;
    int _25450 = NOVALUE;
    int _25449 = NOVALUE;
    int _25448 = NOVALUE;
    int _25444 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_status_48697)) {
        _1 = (long)(DBL_PTR(_status_48697)->dbl);
        DeRefDS(_status_48697);
        _status_48697 = _1;
    }

    /** 	integer w, show_error = 0*/
    _show_error_48699 = 0;

    /** 	ifdef EU_EX then*/

    /** 	show_error = 1*/
    _show_error_48699 = 1;

    /** 	if object(src_file) = 0 then*/
    if( NOVALUE == _35src_file_16365 ){
        _25444 = 0;
    }
    else{
        _25444 = 1;
    }
    if (_25444 != 0)
    goto L1; // [20] 34

    /** 		src_file = -1*/
    _35src_file_16365 = -1;
    goto L2; // [31] 57
L1: 

    /** 	elsif src_file >= 0 then*/
    if (_35src_file_16365 < 0)
    goto L3; // [38] 56

    /** 		close(src_file)*/
    EClose(_35src_file_16365);

    /** 		src_file = -1*/
    _35src_file_16365 = -1;
L3: 
L2: 

    /** 	w = ShowWarnings()*/
    _w_48698 = _44ShowWarnings();
    if (!IS_ATOM_INT(_w_48698)) {
        _1 = (long)(DBL_PTR(_w_48698)->dbl);
        DeRefDS(_w_48698);
        _w_48698 = _1;
    }

    /** 	if not TRANSLATE and (BIND or show_error) and (w or Errors) then*/
    _25448 = (_35TRANSLATE_15887 == 0);
    if (_25448 == 0) {
        _25449 = 0;
        goto L4; // [71] 89
    }
    if (_35BIND_15890 != 0) {
        _25450 = 1;
        goto L5; // [77] 85
    }
    _25450 = (_show_error_48699 != 0);
L5: 
    _25449 = (_25450 != 0);
L4: 
    if (_25449 == 0) {
        goto L6; // [89] 148
    }
    if (_w_48698 != 0) {
        DeRef(_25452);
        _25452 = 1;
        goto L7; // [93] 103
    }
    _25452 = (_44Errors_48514 != 0);
L7: 
    if (_25452 == 0)
    {
        _25452 = NOVALUE;
        goto L6; // [104] 148
    }
    else{
        _25452 = NOVALUE;
    }

    /** 		if not batch_job and not test_only then*/
    _25453 = (_35batch_job_16257 == 0);
    if (_25453 == 0) {
        goto L8; // [114] 147
    }
    _25455 = (_35test_only_16256 == 0);
    if (_25455 == 0)
    {
        DeRef(_25455);
        _25455 = NOVALUE;
        goto L8; // [124] 147
    }
    else{
        DeRef(_25455);
        _25455 = NOVALUE;
    }

    /** 			screen_output(STDERR, GetMsgText(208,0))*/
    RefDS(_22023);
    _25456 = _45GetMsgText(208, 0, _22023);
    _44screen_output(2, _25456);
    _25456 = NOVALUE;

    /** 			getc(0) -- wait*/
    if (0 != last_r_file_no) {
        last_r_file_ptr = which_file(0, EF_READ);
        last_r_file_no = 0;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _25457 = getKBchar();
        }
        else
        _25457 = getc(last_r_file_ptr);
    }
    else
    _25457 = getc(last_r_file_ptr);
L8: 
L6: 

    /** 	cleanup_open_includes()*/
    _61cleanup_open_includes();

    /** 	abort(status)*/
    UserCleanup(_status_48697);

    /** end procedure*/
    DeRef(_25448);
    _25448 = NOVALUE;
    DeRef(_25453);
    _25453 = NOVALUE;
    return;
    ;
}


void _44OpenErrFile()
{
    int _25464 = NOVALUE;
    int _25463 = NOVALUE;
    int _25461 = NOVALUE;
    int _0, _1, _2;
    

    /**     if TempErrFile != -1 then*/
    if (_44TempErrFile_48515 == -1)
    goto L1; // [5] 19

    /** 		TempErrFile = open(TempErrName, "w")*/
    _44TempErrFile_48515 = EOpen(_44TempErrName_48516, _22129, 0);
L1: 

    /** 	if TempErrFile = -1 then*/
    if (_44TempErrFile_48515 != -1)
    goto L2; // [23] 64

    /** 		if length(TempErrName) > 0 then*/
    _25461 = 6;

    /** 			screen_output(STDERR, GetMsgText(209, 0, {TempErrName}))*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_44TempErrName_48516);
    *((int *)(_2+4)) = _44TempErrName_48516;
    _25463 = MAKE_SEQ(_1);
    _25464 = _45GetMsgText(209, 0, _25463);
    _25463 = NOVALUE;
    _44screen_output(2, _25464);
    _25464 = NOVALUE;

    /** 		abort(1) -- with no clean up*/
    UserCleanup(1);
L2: 

    /** end procedure*/
    return;
    ;
}


void _44ShowErr(int _f_48746)
{
    int _msg_inlined_screen_output_at_41_48758 = NOVALUE;
    int _25471 = NOVALUE;
    int _25470 = NOVALUE;
    int _25469 = NOVALUE;
    int _25467 = NOVALUE;
    int _25465 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if length(known_files) = 0 then*/
    if (IS_SEQUENCE(_36known_files_15243)){
            _25465 = SEQ_PTR(_36known_files_15243)->length;
    }
    else {
        _25465 = 1;
    }
    if (_25465 != 0)
    goto L1; // [10] 20

    /** 		return*/
    return;
L1: 

    /** 	if ThisLine[1] = END_OF_FILE_CHAR then*/
    _2 = (int)SEQ_PTR(_44ThisLine_48518);
    _25467 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _25467, 26)){
        _25467 = NOVALUE;
        goto L2; // [30] 62
    }
    _25467 = NOVALUE;

    /** 		screen_output(f, GetMsgText(210,0))*/
    RefDS(_22023);
    _25469 = _45GetMsgText(210, 0, _22023);
    DeRef(_msg_inlined_screen_output_at_41_48758);
    _msg_inlined_screen_output_at_41_48758 = _25469;
    _25469 = NOVALUE;

    /** 	puts(f, msg)*/
    EPuts(_f_48746, _msg_inlined_screen_output_at_41_48758); // DJP 

    /** end procedure*/
    goto L3; // [54] 57
L3: 
    DeRef(_msg_inlined_screen_output_at_41_48758);
    _msg_inlined_screen_output_at_41_48758 = NOVALUE;
    goto L4; // [59] 79
L2: 

    /** 		screen_output(f, ThisLine)*/

    /** 	puts(f, msg)*/
    EPuts(_f_48746, _44ThisLine_48518); // DJP 

    /** end procedure*/
    goto L5; // [75] 78
L5: 
L4: 

    /** 	for i = 1 to bp-2 do -- bp-1 points to last character read*/
    _25470 = _44bp_48522 - 2;
    if ((long)((unsigned long)_25470 +(unsigned long) HIGH_BITS) >= 0){
        _25470 = NewDouble((double)_25470);
    }
    {
        int _i_48762;
        _i_48762 = 1;
L6: 
        if (binary_op_a(GREATER, _i_48762, _25470)){
            goto L7; // [87] 141
        }

        /** 		if ThisLine[i] = '\t' then*/
        _2 = (int)SEQ_PTR(_44ThisLine_48518);
        if (!IS_ATOM_INT(_i_48762)){
            _25471 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_48762)->dbl));
        }
        else{
            _25471 = (int)*(((s1_ptr)_2)->base + _i_48762);
        }
        if (binary_op_a(NOTEQ, _25471, 9)){
            _25471 = NOVALUE;
            goto L8; // [102] 121
        }
        _25471 = NOVALUE;

        /** 			screen_output(f, "\t")*/

        /** 	puts(f, msg)*/
        EPuts(_f_48746, _23815); // DJP 

        /** end procedure*/
        goto L9; // [115] 134
        goto L9; // [118] 134
L8: 

        /** 			screen_output(f, " ")*/

        /** 	puts(f, msg)*/
        EPuts(_f_48746, _23298); // DJP 

        /** end procedure*/
        goto LA; // [130] 133
LA: 
L9: 

        /** 	end for*/
        _0 = _i_48762;
        if (IS_ATOM_INT(_i_48762)) {
            _i_48762 = _i_48762 + 1;
            if ((long)((unsigned long)_i_48762 +(unsigned long) HIGH_BITS) >= 0){
                _i_48762 = NewDouble((double)_i_48762);
            }
        }
        else {
            _i_48762 = binary_op_a(PLUS, _i_48762, 1);
        }
        DeRef(_0);
        goto L6; // [136] 94
L7: 
        ;
        DeRef(_i_48762);
    }

    /** 	screen_output(f, "^\n\n")*/

    /** 	puts(f, msg)*/
    EPuts(_f_48746, _25473); // DJP 

    /** end procedure*/
    goto LB; // [150] 153
LB: 

    /** end procedure*/
    DeRef(_25470);
    _25470 = NOVALUE;
    return;
    ;
}


void _44CompileErr(int _msg_48774, int _args_48775, int _preproc_48776)
{
    int _errmsg_48777 = NOVALUE;
    int _25494 = NOVALUE;
    int _25490 = NOVALUE;
    int _25489 = NOVALUE;
    int _25488 = NOVALUE;
    int _25487 = NOVALUE;
    int _25486 = NOVALUE;
    int _25485 = NOVALUE;
    int _25483 = NOVALUE;
    int _25482 = NOVALUE;
    int _25480 = NOVALUE;
    int _25479 = NOVALUE;
    int _25478 = NOVALUE;
    int _25474 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_preproc_48776)) {
        _1 = (long)(DBL_PTR(_preproc_48776)->dbl);
        DeRefDS(_preproc_48776);
        _preproc_48776 = _1;
    }

    /** 	if integer(msg) then*/
    if (IS_ATOM_INT(_msg_48774))
    _25474 = 1;
    else if (IS_ATOM_DBL(_msg_48774))
    _25474 = IS_ATOM_INT(DoubleToInt(_msg_48774));
    else
    _25474 = 0;
    if (_25474 == 0)
    {
        _25474 = NOVALUE;
        goto L1; // [8] 20
    }
    else{
        _25474 = NOVALUE;
    }

    /** 		msg = GetMsgText(msg)*/
    Ref(_msg_48774);
    RefDS(_22023);
    _0 = _msg_48774;
    _msg_48774 = _45GetMsgText(_msg_48774, 1, _22023);
    DeRef(_0);
L1: 

    /** 	msg = format(msg, args)*/
    Ref(_msg_48774);
    Ref(_args_48775);
    _0 = _msg_48774;
    _msg_48774 = _14format(_msg_48774, _args_48775);
    DeRef(_0);

    /** 	Errors += 1*/
    _44Errors_48514 = _44Errors_48514 + 1;

    /** 	if not preproc and length(known_files) then*/
    _25478 = (_preproc_48776 == 0);
    if (_25478 == 0) {
        goto L2; // [40] 78
    }
    if (IS_SEQUENCE(_36known_files_15243)){
            _25480 = SEQ_PTR(_36known_files_15243)->length;
    }
    else {
        _25480 = 1;
    }
    if (_25480 == 0)
    {
        _25480 = NOVALUE;
        goto L2; // [50] 78
    }
    else{
        _25480 = NOVALUE;
    }

    /** 		errmsg = sprintf("%s:%d\n%s\n", {known_files[current_file_no],*/
    _2 = (int)SEQ_PTR(_36known_files_15243);
    _25482 = (int)*(((s1_ptr)_2)->base + _35current_file_no_16244);
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_25482);
    *((int *)(_2+4)) = _25482;
    *((int *)(_2+8)) = _35line_number_16245;
    Ref(_msg_48774);
    *((int *)(_2+12)) = _msg_48774;
    _25483 = MAKE_SEQ(_1);
    _25482 = NOVALUE;
    DeRef(_errmsg_48777);
    _errmsg_48777 = EPrintf(-9999999, _25481, _25483);
    DeRefDS(_25483);
    _25483 = NOVALUE;
    goto L3; // [75] 121
L2: 

    /** 		errmsg = msg*/
    Ref(_msg_48774);
    DeRef(_errmsg_48777);
    _errmsg_48777 = _msg_48774;

    /** 		if length(msg) > 0 and msg[$] != '\n' then*/
    if (IS_SEQUENCE(_msg_48774)){
            _25485 = SEQ_PTR(_msg_48774)->length;
    }
    else {
        _25485 = 1;
    }
    _25486 = (_25485 > 0);
    _25485 = NOVALUE;
    if (_25486 == 0) {
        goto L4; // [94] 120
    }
    if (IS_SEQUENCE(_msg_48774)){
            _25488 = SEQ_PTR(_msg_48774)->length;
    }
    else {
        _25488 = 1;
    }
    _2 = (int)SEQ_PTR(_msg_48774);
    _25489 = (int)*(((s1_ptr)_2)->base + _25488);
    if (IS_ATOM_INT(_25489)) {
        _25490 = (_25489 != 10);
    }
    else {
        _25490 = binary_op(NOTEQ, _25489, 10);
    }
    _25489 = NOVALUE;
    if (_25490 == 0) {
        DeRef(_25490);
        _25490 = NOVALUE;
        goto L4; // [110] 120
    }
    else {
        if (!IS_ATOM_INT(_25490) && DBL_PTR(_25490)->dbl == 0.0){
            DeRef(_25490);
            _25490 = NOVALUE;
            goto L4; // [110] 120
        }
        DeRef(_25490);
        _25490 = NOVALUE;
    }
    DeRef(_25490);
    _25490 = NOVALUE;

    /** 			errmsg &= '\n'*/
    Append(&_errmsg_48777, _errmsg_48777, 10);
L4: 
L3: 

    /** 	if not preproc then*/
    if (_preproc_48776 != 0)
    goto L5; // [123] 131

    /** 		OpenErrFile() -- exits if error filename is ""*/
    _44OpenErrFile();
L5: 

    /** 	screen_output(STDERR, errmsg)*/
    RefDS(_errmsg_48777);
    _44screen_output(2, _errmsg_48777);

    /** 	if not preproc then*/
    if (_preproc_48776 != 0)
    goto L6; // [143] 196

    /** 		ShowErr(STDERR)*/
    _44ShowErr(2);

    /** 		puts(TempErrFile, errmsg)*/
    EPuts(_44TempErrFile_48515, _errmsg_48777); // DJP 

    /** 		ShowErr(TempErrFile)*/
    _44ShowErr(_44TempErrFile_48515);

    /** 		ShowWarnings()*/
    _25494 = _44ShowWarnings();

    /** 		ShowDefines(TempErrFile)*/
    _44ShowDefines(_44TempErrFile_48515);

    /** 		close(TempErrFile)*/
    EClose(_44TempErrFile_48515);

    /** 		TempErrFile = -2*/
    _44TempErrFile_48515 = -2;

    /** 		Cleanup(1)*/
    _44Cleanup(1);
L6: 

    /** end procedure*/
    DeRef(_msg_48774);
    DeRef(_args_48775);
    DeRef(_errmsg_48777);
    DeRef(_25478);
    _25478 = NOVALUE;
    DeRef(_25486);
    _25486 = NOVALUE;
    DeRef(_25494);
    _25494 = NOVALUE;
    return;
    ;
}


void _44InternalErr(int _msgno_48820, int _args_48821)
{
    int _msg_48822 = NOVALUE;
    int _25509 = NOVALUE;
    int _25508 = NOVALUE;
    int _25507 = NOVALUE;
    int _25506 = NOVALUE;
    int _25505 = NOVALUE;
    int _25504 = NOVALUE;
    int _25503 = NOVALUE;
    int _25502 = NOVALUE;
    int _25501 = NOVALUE;
    int _25500 = NOVALUE;
    int _25499 = NOVALUE;
    int _25496 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_msgno_48820)) {
        _1 = (long)(DBL_PTR(_msgno_48820)->dbl);
        DeRefDS(_msgno_48820);
        _msgno_48820 = _1;
    }

    /** 	if atom(args) then*/
    _25496 = IS_ATOM(_args_48821);
    if (_25496 == 0)
    {
        _25496 = NOVALUE;
        goto L1; // [8] 18
    }
    else{
        _25496 = NOVALUE;
    }

    /** 		args = {args}*/
    _0 = _args_48821;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_args_48821);
    *((int *)(_2+4)) = _args_48821;
    _args_48821 = MAKE_SEQ(_1);
    DeRef(_0);
L1: 

    /** 	msg = GetMsgText(msgno, 1, args)*/
    Ref(_args_48821);
    _0 = _msg_48822;
    _msg_48822 = _45GetMsgText(_msgno_48820, 1, _args_48821);
    DeRef(_0);

    /** 	if TRANSLATE then*/
    if (_35TRANSLATE_15887 == 0)
    {
        goto L2; // [32] 56
    }
    else{
    }

    /** 		screen_output(STDERR, GetMsgText(211, 1, {msg}))*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_msg_48822);
    *((int *)(_2+4)) = _msg_48822;
    _25499 = MAKE_SEQ(_1);
    _25500 = _45GetMsgText(211, 1, _25499);
    _25499 = NOVALUE;
    _44screen_output(2, _25500);
    _25500 = NOVALUE;
    goto L3; // [53] 87
L2: 

    /** 		screen_output(STDERR, GetMsgText(212, 1, {known_files[current_file_no], line_number, msg}))*/
    _2 = (int)SEQ_PTR(_36known_files_15243);
    _25501 = (int)*(((s1_ptr)_2)->base + _35current_file_no_16244);
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_25501);
    *((int *)(_2+4)) = _25501;
    *((int *)(_2+8)) = _35line_number_16245;
    RefDS(_msg_48822);
    *((int *)(_2+12)) = _msg_48822;
    _25502 = MAKE_SEQ(_1);
    _25501 = NOVALUE;
    _25503 = _45GetMsgText(212, 1, _25502);
    _25502 = NOVALUE;
    _44screen_output(2, _25503);
    _25503 = NOVALUE;
L3: 

    /** 	if not batch_job and not test_only then*/
    _25504 = (_35batch_job_16257 == 0);
    if (_25504 == 0) {
        goto L4; // [94] 127
    }
    _25506 = (_35test_only_16256 == 0);
    if (_25506 == 0)
    {
        DeRef(_25506);
        _25506 = NOVALUE;
        goto L4; // [104] 127
    }
    else{
        DeRef(_25506);
        _25506 = NOVALUE;
    }

    /** 		screen_output(STDERR, GetMsgText(208, 0))*/
    RefDS(_22023);
    _25507 = _45GetMsgText(208, 0, _22023);
    _44screen_output(2, _25507);
    _25507 = NOVALUE;

    /** 		getc(0)*/
    if (0 != last_r_file_no) {
        last_r_file_ptr = which_file(0, EF_READ);
        last_r_file_no = 0;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _25508 = getKBchar();
        }
        else
        _25508 = getc(last_r_file_ptr);
    }
    else
    _25508 = getc(last_r_file_ptr);
L4: 

    /** 	machine_proc(67, GetMsgText(213))*/
    RefDS(_22023);
    _25509 = _45GetMsgText(213, 1, _22023);
    machine(67, _25509);
    DeRef(_25509);
    _25509 = NOVALUE;

    /** end procedure*/
    DeRef(_args_48821);
    DeRef(_msg_48822);
    DeRef(_25504);
    _25504 = NOVALUE;
    return;
    ;
}



// 0x97B2AA03
