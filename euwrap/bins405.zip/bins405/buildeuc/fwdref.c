// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

void _38clear_fwd_refs()
{
    int _0, _1, _2;
    

    /** 	fwdref_count = 0*/
    _38fwdref_count_61521 = 0;

    /** end procedure*/
    return;
    ;
}


int _38get_fwdref_count()
{
    int _0, _1, _2;
    

    /** 	return fwdref_count*/
    return _38fwdref_count_61521;
    ;
}


void _38set_glabel_block(int _ref_61528, int _block_61530)
{
    int _30805 = NOVALUE;
    int _30804 = NOVALUE;
    int _30802 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_ref_61528)) {
        _1 = (long)(DBL_PTR(_ref_61528)->dbl);
        DeRefDS(_ref_61528);
        _ref_61528 = _1;
    }
    if (!IS_ATOM_INT(_block_61530)) {
        _1 = (long)(DBL_PTR(_block_61530)->dbl);
        DeRefDS(_block_61530);
        _block_61530 = _1;
    }

    /** 	forward_references[ref][FR_DATA] &= block*/
    _2 = (int)SEQ_PTR(_38forward_references_61501);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _38forward_references_61501 = MAKE_SEQ(_2);
    }
    _3 = (int)(_ref_61528 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    _30804 = (int)*(((s1_ptr)_2)->base + 12);
    _30802 = NOVALUE;
    if (IS_SEQUENCE(_30804) && IS_ATOM(_block_61530)) {
        Append(&_30805, _30804, _block_61530);
    }
    else if (IS_ATOM(_30804) && IS_SEQUENCE(_block_61530)) {
    }
    else {
        Concat((object_ptr)&_30805, _30804, _block_61530);
        _30804 = NOVALUE;
    }
    _30804 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 12);
    _1 = *(int *)_2;
    *(int *)_2 = _30805;
    if( _1 != _30805 ){
        DeRef(_1);
    }
    _30805 = NOVALUE;
    _30802 = NOVALUE;

    /** end procedure*/
    return;
    ;
}


void _38replace_code(int _code_61542, int _start_61543, int _finish_61544, int _subprog_61545)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_finish_61544)) {
        _1 = (long)(DBL_PTR(_finish_61544)->dbl);
        DeRefDS(_finish_61544);
        _finish_61544 = _1;
    }
    if (!IS_ATOM_INT(_subprog_61545)) {
        _1 = (long)(DBL_PTR(_subprog_61545)->dbl);
        DeRefDS(_subprog_61545);
        _subprog_61545 = _1;
    }

    /** 	shifting_sub = subprog*/
    _38shifting_sub_61520 = _subprog_61545;

    /** 	shift:replace_code( code, start, finish )*/
    RefDS(_code_61542);
    _65replace_code(_code_61542, _start_61543, _finish_61544);

    /** 	shifting_sub = 0*/
    _38shifting_sub_61520 = 0;

    /** end procedure*/
    DeRefDS(_code_61542);
    return;
    ;
}


void _38resolved_reference(int _ref_61548)
{
    int _file_61549 = NOVALUE;
    int _subprog_61552 = NOVALUE;
    int _tx_61555 = NOVALUE;
    int _ax_61556 = NOVALUE;
    int _sp_61557 = NOVALUE;
    int _r_61572 = NOVALUE;
    int _r_61590 = NOVALUE;
    int _30829 = NOVALUE;
    int _30828 = NOVALUE;
    int _30827 = NOVALUE;
    int _30825 = NOVALUE;
    int _30822 = NOVALUE;
    int _30820 = NOVALUE;
    int _30818 = NOVALUE;
    int _30817 = NOVALUE;
    int _30815 = NOVALUE;
    int _30813 = NOVALUE;
    int _30811 = NOVALUE;
    int _30810 = NOVALUE;
    int _30808 = NOVALUE;
    int _30806 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 		file    = forward_references[ref][FR_FILE],*/
    _2 = (int)SEQ_PTR(_38forward_references_61501);
    _30806 = (int)*(((s1_ptr)_2)->base + _ref_61548);
    _2 = (int)SEQ_PTR(_30806);
    _file_61549 = (int)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_file_61549)){
        _file_61549 = (long)DBL_PTR(_file_61549)->dbl;
    }
    _30806 = NOVALUE;

    /** 		subprog = forward_references[ref][FR_SUBPROG]*/
    _2 = (int)SEQ_PTR(_38forward_references_61501);
    _30808 = (int)*(((s1_ptr)_2)->base + _ref_61548);
    _2 = (int)SEQ_PTR(_30808);
    _subprog_61552 = (int)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_subprog_61552)){
        _subprog_61552 = (long)DBL_PTR(_subprog_61552)->dbl;
    }
    _30808 = NOVALUE;

    /** 		tx = 0,*/
    _tx_61555 = 0;

    /** 		ax = 0,*/
    _ax_61556 = 0;

    /** 		sp = 0*/
    _sp_61557 = 0;

    /** 	if forward_references[ref][FR_SUBPROG] = TopLevelSub then*/
    _2 = (int)SEQ_PTR(_38forward_references_61501);
    _30810 = (int)*(((s1_ptr)_2)->base + _ref_61548);
    _2 = (int)SEQ_PTR(_30810);
    _30811 = (int)*(((s1_ptr)_2)->base + 4);
    _30810 = NOVALUE;
    if (binary_op_a(NOTEQ, _30811, _35TopLevelSub_16251)){
        _30811 = NOVALUE;
        goto L1; // [60] 80
    }
    _30811 = NOVALUE;

    /** 		tx = find( ref, toplevel_references[file] )*/
    _2 = (int)SEQ_PTR(_38toplevel_references_61504);
    _30813 = (int)*(((s1_ptr)_2)->base + _file_61549);
    _tx_61555 = find_from(_ref_61548, _30813, 1);
    _30813 = NOVALUE;
    goto L2; // [77] 111
L1: 

    /** 		sp = find( subprog, active_subprogs[file] )*/
    _2 = (int)SEQ_PTR(_38active_subprogs_61502);
    _30815 = (int)*(((s1_ptr)_2)->base + _file_61549);
    _sp_61557 = find_from(_subprog_61552, _30815, 1);
    _30815 = NOVALUE;

    /** 		ax = find( ref, active_references[file][sp] )*/
    _2 = (int)SEQ_PTR(_38active_references_61503);
    _30817 = (int)*(((s1_ptr)_2)->base + _file_61549);
    _2 = (int)SEQ_PTR(_30817);
    _30818 = (int)*(((s1_ptr)_2)->base + _sp_61557);
    _30817 = NOVALUE;
    _ax_61556 = find_from(_ref_61548, _30818, 1);
    _30818 = NOVALUE;
L2: 

    /** 	if ax then*/
    if (_ax_61556 == 0)
    {
        goto L3; // [113] 253
    }
    else{
    }

    /** 		sequence r = active_references[file][sp] */
    _2 = (int)SEQ_PTR(_38active_references_61503);
    _30820 = (int)*(((s1_ptr)_2)->base + _file_61549);
    DeRef(_r_61572);
    _2 = (int)SEQ_PTR(_30820);
    _r_61572 = (int)*(((s1_ptr)_2)->base + _sp_61557);
    Ref(_r_61572);
    _30820 = NOVALUE;

    /** 		active_references[file][sp] = 0*/
    _2 = (int)SEQ_PTR(_38active_references_61503);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _38active_references_61503 = MAKE_SEQ(_2);
    }
    _3 = (int)(_file_61549 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _sp_61557);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _30822 = NOVALUE;

    /** 		r = remove( r, ax )*/
    {
        s1_ptr assign_space = SEQ_PTR(_r_61572);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_ax_61556)) ? _ax_61556 : (long)(DBL_PTR(_ax_61556)->dbl);
        int stop = (IS_ATOM_INT(_ax_61556)) ? _ax_61556 : (long)(DBL_PTR(_ax_61556)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_r_61572), start, &_r_61572 );
            }
            else Tail(SEQ_PTR(_r_61572), stop+1, &_r_61572);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_r_61572), start, &_r_61572);
        }
        else {
            assign_slice_seq = &assign_space;
            _r_61572 = Remove_elements(start, stop, (SEQ_PTR(_r_61572)->ref == 1));
        }
    }

    /** 		active_references[file][sp] = r*/
    _2 = (int)SEQ_PTR(_38active_references_61503);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _38active_references_61503 = MAKE_SEQ(_2);
    }
    _3 = (int)(_file_61549 + ((s1_ptr)_2)->base);
    RefDS(_r_61572);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _sp_61557);
    _1 = *(int *)_2;
    *(int *)_2 = _r_61572;
    DeRef(_1);
    _30825 = NOVALUE;

    /** 		if not length( active_references[file][sp] ) then*/
    _2 = (int)SEQ_PTR(_38active_references_61503);
    _30827 = (int)*(((s1_ptr)_2)->base + _file_61549);
    _2 = (int)SEQ_PTR(_30827);
    _30828 = (int)*(((s1_ptr)_2)->base + _sp_61557);
    _30827 = NOVALUE;
    if (IS_SEQUENCE(_30828)){
            _30829 = SEQ_PTR(_30828)->length;
    }
    else {
        _30829 = 1;
    }
    _30828 = NOVALUE;
    if (_30829 != 0)
    goto L4; // [178] 248
    _30829 = NOVALUE;

    /** 			r = active_references[file]*/
    DeRefDS(_r_61572);
    _2 = (int)SEQ_PTR(_38active_references_61503);
    _r_61572 = (int)*(((s1_ptr)_2)->base + _file_61549);
    Ref(_r_61572);

    /** 			active_references[file] = 0*/
    _2 = (int)SEQ_PTR(_38active_references_61503);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _38active_references_61503 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _file_61549);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 			r = remove( r, sp )*/
    {
        s1_ptr assign_space = SEQ_PTR(_r_61572);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_sp_61557)) ? _sp_61557 : (long)(DBL_PTR(_sp_61557)->dbl);
        int stop = (IS_ATOM_INT(_sp_61557)) ? _sp_61557 : (long)(DBL_PTR(_sp_61557)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_r_61572), start, &_r_61572 );
            }
            else Tail(SEQ_PTR(_r_61572), stop+1, &_r_61572);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_r_61572), start, &_r_61572);
        }
        else {
            assign_slice_seq = &assign_space;
            _r_61572 = Remove_elements(start, stop, (SEQ_PTR(_r_61572)->ref == 1));
        }
    }

    /** 			active_references[file] = r*/
    RefDS(_r_61572);
    _2 = (int)SEQ_PTR(_38active_references_61503);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _38active_references_61503 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _file_61549);
    _1 = *(int *)_2;
    *(int *)_2 = _r_61572;
    DeRef(_1);

    /** 			r = active_subprogs[file]*/
    DeRefDS(_r_61572);
    _2 = (int)SEQ_PTR(_38active_subprogs_61502);
    _r_61572 = (int)*(((s1_ptr)_2)->base + _file_61549);
    Ref(_r_61572);

    /** 			active_subprogs[file] = 0*/
    _2 = (int)SEQ_PTR(_38active_subprogs_61502);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _38active_subprogs_61502 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _file_61549);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 			r = remove( r,   sp )*/
    {
        s1_ptr assign_space = SEQ_PTR(_r_61572);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_sp_61557)) ? _sp_61557 : (long)(DBL_PTR(_sp_61557)->dbl);
        int stop = (IS_ATOM_INT(_sp_61557)) ? _sp_61557 : (long)(DBL_PTR(_sp_61557)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_r_61572), start, &_r_61572 );
            }
            else Tail(SEQ_PTR(_r_61572), stop+1, &_r_61572);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_r_61572), start, &_r_61572);
        }
        else {
            assign_slice_seq = &assign_space;
            _r_61572 = Remove_elements(start, stop, (SEQ_PTR(_r_61572)->ref == 1));
        }
    }

    /** 			active_subprogs[file] = r*/
    RefDS(_r_61572);
    _2 = (int)SEQ_PTR(_38active_subprogs_61502);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _38active_subprogs_61502 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _file_61549);
    _1 = *(int *)_2;
    *(int *)_2 = _r_61572;
    DeRef(_1);
L4: 
    DeRef(_r_61572);
    _r_61572 = NOVALUE;
    goto L5; // [250] 303
L3: 

    /** 	elsif tx then*/
    if (_tx_61555 == 0)
    {
        goto L6; // [255] 296
    }
    else{
    }

    /** 		sequence r = toplevel_references[file]*/
    DeRef(_r_61590);
    _2 = (int)SEQ_PTR(_38toplevel_references_61504);
    _r_61590 = (int)*(((s1_ptr)_2)->base + _file_61549);
    Ref(_r_61590);

    /** 		toplevel_references[file] = 0*/
    _2 = (int)SEQ_PTR(_38toplevel_references_61504);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _38toplevel_references_61504 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _file_61549);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 		r = remove( r, tx )*/
    {
        s1_ptr assign_space = SEQ_PTR(_r_61590);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_tx_61555)) ? _tx_61555 : (long)(DBL_PTR(_tx_61555)->dbl);
        int stop = (IS_ATOM_INT(_tx_61555)) ? _tx_61555 : (long)(DBL_PTR(_tx_61555)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_r_61590), start, &_r_61590 );
            }
            else Tail(SEQ_PTR(_r_61590), stop+1, &_r_61590);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_r_61590), start, &_r_61590);
        }
        else {
            assign_slice_seq = &assign_space;
            _r_61590 = Remove_elements(start, stop, (SEQ_PTR(_r_61590)->ref == 1));
        }
    }

    /** 		toplevel_references[file] = r*/
    RefDS(_r_61590);
    _2 = (int)SEQ_PTR(_38toplevel_references_61504);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _38toplevel_references_61504 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _file_61549);
    _1 = *(int *)_2;
    *(int *)_2 = _r_61590;
    DeRef(_1);
    DeRefDS(_r_61590);
    _r_61590 = NOVALUE;
    goto L5; // [293] 303
L6: 

    /** 		InternalErr( 260 )*/
    RefDS(_22023);
    _44InternalErr(260, _22023);
L5: 

    /** 	inactive_references &= ref*/
    Append(&_38inactive_references_61505, _38inactive_references_61505, _ref_61548);

    /** 	forward_references[ref] = 0*/
    _2 = (int)SEQ_PTR(_38forward_references_61501);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _38forward_references_61501 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _ref_61548);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** end procedure*/
    _30828 = NOVALUE;
    return;
    ;
}


void _38set_code(int _ref_61604)
{
    int _30845 = NOVALUE;
    int _30843 = NOVALUE;
    int _30841 = NOVALUE;
    int _30838 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	patch_code_sub = forward_references[ref][FR_SUBPROG]*/
    _2 = (int)SEQ_PTR(_38forward_references_61501);
    _30838 = (int)*(((s1_ptr)_2)->base + _ref_61604);
    _2 = (int)SEQ_PTR(_30838);
    _38patch_code_sub_61599 = (int)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_38patch_code_sub_61599)){
        _38patch_code_sub_61599 = (long)DBL_PTR(_38patch_code_sub_61599)->dbl;
    }
    _30838 = NOVALUE;

    /** 	if patch_code_sub != CurrentSub then*/
    if (_38patch_code_sub_61599 == _35CurrentSub_16252)
    goto L1; // [23] 119

    /** 		patch_code_temp = Code*/
    RefDS(_35Code_16332);
    DeRef(_38patch_code_temp_61596);
    _38patch_code_temp_61596 = _35Code_16332;

    /** 		patch_linetab_temp = LineTable*/
    RefDS(_35LineTable_16333);
    DeRef(_38patch_linetab_temp_61597);
    _38patch_linetab_temp_61597 = _35LineTable_16333;

    /** 		Code = SymTab[patch_code_sub][S_CODE]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _30841 = (int)*(((s1_ptr)_2)->base + _38patch_code_sub_61599);
    DeRefDS(_35Code_16332);
    _2 = (int)SEQ_PTR(_30841);
    if (!IS_ATOM_INT(_35S_CODE_15929)){
        _35Code_16332 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_CODE_15929)->dbl));
    }
    else{
        _35Code_16332 = (int)*(((s1_ptr)_2)->base + _35S_CODE_15929);
    }
    Ref(_35Code_16332);
    _30841 = NOVALUE;

    /** 		SymTab[patch_code_sub][S_CODE] = 0*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_38patch_code_sub_61599 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35S_CODE_15929))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_CODE_15929)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _35S_CODE_15929);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _30843 = NOVALUE;

    /** 		LineTable = SymTab[patch_code_sub][S_LINETAB]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _30845 = (int)*(((s1_ptr)_2)->base + _38patch_code_sub_61599);
    DeRefDS(_35LineTable_16333);
    _2 = (int)SEQ_PTR(_30845);
    if (!IS_ATOM_INT(_35S_LINETAB_15952)){
        _35LineTable_16333 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_LINETAB_15952)->dbl));
    }
    else{
        _35LineTable_16333 = (int)*(((s1_ptr)_2)->base + _35S_LINETAB_15952);
    }
    Ref(_35LineTable_16333);
    _30845 = NOVALUE;

    /** 		patch_current_sub = CurrentSub*/
    _38patch_current_sub_61601 = _35CurrentSub_16252;

    /** 		CurrentSub = patch_code_sub*/
    _35CurrentSub_16252 = _38patch_code_sub_61599;
    goto L2; // [116] 129
L1: 

    /** 		patch_current_sub = patch_code_sub*/
    _38patch_current_sub_61601 = _38patch_code_sub_61599;
L2: 

    /** end procedure*/
    return;
    ;
}


void _38reset_code()
{
    int _30849 = NOVALUE;
    int _30847 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	SymTab[patch_code_sub][S_CODE] = Code*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_38patch_code_sub_61599 + ((s1_ptr)_2)->base);
    RefDS(_35Code_16332);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35S_CODE_15929))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_CODE_15929)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _35S_CODE_15929);
    _1 = *(int *)_2;
    *(int *)_2 = _35Code_16332;
    DeRef(_1);
    _30847 = NOVALUE;

    /** 	SymTab[patch_code_sub][S_LINETAB] = LineTable*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_38patch_code_sub_61599 + ((s1_ptr)_2)->base);
    RefDS(_35LineTable_16333);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35S_LINETAB_15952))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_LINETAB_15952)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _35S_LINETAB_15952);
    _1 = *(int *)_2;
    *(int *)_2 = _35LineTable_16333;
    DeRef(_1);
    _30849 = NOVALUE;

    /** 	if patch_code_sub != patch_current_sub then*/
    if (_38patch_code_sub_61599 == _38patch_current_sub_61601)
    goto L1; // [45] 77

    /** 		CurrentSub = patch_current_sub*/
    _35CurrentSub_16252 = _38patch_current_sub_61601;

    /** 		Code = patch_code_temp*/
    RefDS(_38patch_code_temp_61596);
    DeRefDS(_35Code_16332);
    _35Code_16332 = _38patch_code_temp_61596;

    /** 		LineTable = patch_linetab_temp*/
    RefDS(_38patch_linetab_temp_61597);
    DeRefDS(_35LineTable_16333);
    _35LineTable_16333 = _38patch_linetab_temp_61597;
L1: 

    /** 	patch_code_temp = {}*/
    RefDS(_22023);
    DeRef(_38patch_code_temp_61596);
    _38patch_code_temp_61596 = _22023;

    /** 	patch_linetab_temp = {}*/
    RefDS(_22023);
    DeRef(_38patch_linetab_temp_61597);
    _38patch_linetab_temp_61597 = _22023;

    /** end procedure*/
    return;
    ;
}


void _38set_data(int _ref_61648, int _data_61649)
{
    int _30852 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_ref_61648)) {
        _1 = (long)(DBL_PTR(_ref_61648)->dbl);
        DeRefDS(_ref_61648);
        _ref_61648 = _1;
    }

    /** 	forward_references[ref][FR_DATA] = data*/
    _2 = (int)SEQ_PTR(_38forward_references_61501);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _38forward_references_61501 = MAKE_SEQ(_2);
    }
    _3 = (int)(_ref_61648 + ((s1_ptr)_2)->base);
    Ref(_data_61649);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 12);
    _1 = *(int *)_2;
    *(int *)_2 = _data_61649;
    DeRef(_1);
    _30852 = NOVALUE;

    /** end procedure*/
    DeRef(_data_61649);
    return;
    ;
}


void _38add_data(int _ref_61654, int _data_61655)
{
    int _30858 = NOVALUE;
    int _30857 = NOVALUE;
    int _30856 = NOVALUE;
    int _30854 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_ref_61654)) {
        _1 = (long)(DBL_PTR(_ref_61654)->dbl);
        DeRefDS(_ref_61654);
        _ref_61654 = _1;
    }

    /** 	forward_references[ref][FR_DATA] = append( forward_references[ref][FR_DATA], data )*/
    _2 = (int)SEQ_PTR(_38forward_references_61501);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _38forward_references_61501 = MAKE_SEQ(_2);
    }
    _3 = (int)(_ref_61654 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_38forward_references_61501);
    _30856 = (int)*(((s1_ptr)_2)->base + _ref_61654);
    _2 = (int)SEQ_PTR(_30856);
    _30857 = (int)*(((s1_ptr)_2)->base + 12);
    _30856 = NOVALUE;
    Ref(_data_61655);
    Append(&_30858, _30857, _data_61655);
    _30857 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 12);
    _1 = *(int *)_2;
    *(int *)_2 = _30858;
    if( _1 != _30858 ){
        DeRef(_1);
    }
    _30858 = NOVALUE;
    _30854 = NOVALUE;

    /** end procedure*/
    DeRef(_data_61655);
    return;
    ;
}


void _38set_line(int _ref_61663, int _line_no_61664, int _this_line_61665, int _bp_61666)
{
    int _30863 = NOVALUE;
    int _30861 = NOVALUE;
    int _30859 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_ref_61663)) {
        _1 = (long)(DBL_PTR(_ref_61663)->dbl);
        DeRefDS(_ref_61663);
        _ref_61663 = _1;
    }
    if (!IS_ATOM_INT(_line_no_61664)) {
        _1 = (long)(DBL_PTR(_line_no_61664)->dbl);
        DeRefDS(_line_no_61664);
        _line_no_61664 = _1;
    }
    if (!IS_ATOM_INT(_bp_61666)) {
        _1 = (long)(DBL_PTR(_bp_61666)->dbl);
        DeRefDS(_bp_61666);
        _bp_61666 = _1;
    }

    /** 	forward_references[ref][FR_LINE] = line_no*/
    _2 = (int)SEQ_PTR(_38forward_references_61501);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _38forward_references_61501 = MAKE_SEQ(_2);
    }
    _3 = (int)(_ref_61663 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 6);
    _1 = *(int *)_2;
    *(int *)_2 = _line_no_61664;
    DeRef(_1);
    _30859 = NOVALUE;

    /** 	forward_references[ref][FR_THISLINE] = this_line*/
    _2 = (int)SEQ_PTR(_38forward_references_61501);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _38forward_references_61501 = MAKE_SEQ(_2);
    }
    _3 = (int)(_ref_61663 + ((s1_ptr)_2)->base);
    RefDS(_this_line_61665);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 7);
    _1 = *(int *)_2;
    *(int *)_2 = _this_line_61665;
    DeRef(_1);
    _30861 = NOVALUE;

    /** 	forward_references[ref][FR_BP] = bp*/
    _2 = (int)SEQ_PTR(_38forward_references_61501);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _38forward_references_61501 = MAKE_SEQ(_2);
    }
    _3 = (int)(_ref_61663 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 8);
    _1 = *(int *)_2;
    *(int *)_2 = _bp_61666;
    DeRef(_1);
    _30863 = NOVALUE;

    /** end procedure*/
    DeRefDS(_this_line_61665);
    return;
    ;
}


void _38add_private_symbol(int _sym_61678, int _name_61679)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_sym_61678)) {
        _1 = (long)(DBL_PTR(_sym_61678)->dbl);
        DeRefDS(_sym_61678);
        _sym_61678 = _1;
    }

    /** 	fwd_private_sym &= sym*/
    Append(&_38fwd_private_sym_61673, _38fwd_private_sym_61673, _sym_61678);

    /** 	fwd_private_name = append( fwd_private_name, name )*/
    RefDS(_name_61679);
    Append(&_38fwd_private_name_61674, _38fwd_private_name_61674, _name_61679);

    /** end procedure*/
    DeRefDS(_name_61679);
    return;
    ;
}


void _38patch_forward_goto(int _tok_61687, int _ref_61688)
{
    int _fr_61689 = NOVALUE;
    int _30879 = NOVALUE;
    int _30878 = NOVALUE;
    int _30877 = NOVALUE;
    int _30876 = NOVALUE;
    int _30875 = NOVALUE;
    int _30874 = NOVALUE;
    int _30873 = NOVALUE;
    int _30872 = NOVALUE;
    int _30870 = NOVALUE;
    int _30869 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence fr = forward_references[ref]*/
    DeRef(_fr_61689);
    _2 = (int)SEQ_PTR(_38forward_references_61501);
    _fr_61689 = (int)*(((s1_ptr)_2)->base + _ref_61688);
    Ref(_fr_61689);

    /** 	set_code( ref )*/
    _38set_code(_ref_61688);

    /** 	shifting_sub = fr[FR_SUBPROG]*/
    _2 = (int)SEQ_PTR(_fr_61689);
    _38shifting_sub_61520 = (int)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_38shifting_sub_61520))
    _38shifting_sub_61520 = (long)DBL_PTR(_38shifting_sub_61520)->dbl;

    /** 	if length( fr[FR_DATA] ) = 2 then*/
    _2 = (int)SEQ_PTR(_fr_61689);
    _30869 = (int)*(((s1_ptr)_2)->base + 12);
    if (IS_SEQUENCE(_30869)){
            _30870 = SEQ_PTR(_30869)->length;
    }
    else {
        _30870 = 1;
    }
    _30869 = NOVALUE;
    if (_30870 != 2)
    goto L1; // [33] 62

    /** 		prep_forward_error( ref )*/
    _38prep_forward_error(_ref_61688);

    /** 		CompileErr( 156, { fr[FR_DATA][2] })*/
    _2 = (int)SEQ_PTR(_fr_61689);
    _30872 = (int)*(((s1_ptr)_2)->base + 12);
    _2 = (int)SEQ_PTR(_30872);
    _30873 = (int)*(((s1_ptr)_2)->base + 2);
    _30872 = NOVALUE;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_30873);
    *((int *)(_2+4)) = _30873;
    _30874 = MAKE_SEQ(_1);
    _30873 = NOVALUE;
    _44CompileErr(156, _30874, 0);
    _30874 = NOVALUE;
L1: 

    /** 	Goto_block(  fr[FR_DATA][1], fr[FR_DATA][3], fr[FR_PC] )*/
    _2 = (int)SEQ_PTR(_fr_61689);
    _30875 = (int)*(((s1_ptr)_2)->base + 12);
    _2 = (int)SEQ_PTR(_30875);
    _30876 = (int)*(((s1_ptr)_2)->base + 1);
    _30875 = NOVALUE;
    _2 = (int)SEQ_PTR(_fr_61689);
    _30877 = (int)*(((s1_ptr)_2)->base + 12);
    _2 = (int)SEQ_PTR(_30877);
    _30878 = (int)*(((s1_ptr)_2)->base + 3);
    _30877 = NOVALUE;
    _2 = (int)SEQ_PTR(_fr_61689);
    _30879 = (int)*(((s1_ptr)_2)->base + 5);
    Ref(_30876);
    Ref(_30878);
    Ref(_30879);
    _66Goto_block(_30876, _30878, _30879);
    _30876 = NOVALUE;
    _30878 = NOVALUE;
    _30879 = NOVALUE;

    /** 	shifting_sub = 0*/
    _38shifting_sub_61520 = 0;

    /** 	reset_code()*/
    _38reset_code();

    /** 	resolved_reference( ref )*/
    _38resolved_reference(_ref_61688);

    /** end procedure*/
    DeRefDS(_fr_61689);
    _30869 = NOVALUE;
    return;
    ;
}


void _38patch_forward_call(int _tok_61710, int _ref_61711)
{
    int _fr_61712 = NOVALUE;
    int _sub_61715 = NOVALUE;
    int _defarg_61721 = NOVALUE;
    int _paramsym_61725 = NOVALUE;
    int _old_61728 = NOVALUE;
    int _tx_61732 = NOVALUE;
    int _code_sub_61742 = NOVALUE;
    int _args_61744 = NOVALUE;
    int _is_func_61749 = NOVALUE;
    int _real_file_61763 = NOVALUE;
    int _code_61767 = NOVALUE;
    int _temp_sub_61769 = NOVALUE;
    int _pc_61771 = NOVALUE;
    int _next_pc_61773 = NOVALUE;
    int _supplied_args_61774 = NOVALUE;
    int _name_61777 = NOVALUE;
    int _old_temps_allocated_61801 = NOVALUE;
    int _temp_target_61810 = NOVALUE;
    int _converted_code_61813 = NOVALUE;
    int _target_61829 = NOVALUE;
    int _has_defaults_61835 = NOVALUE;
    int _goto_target_61836 = NOVALUE;
    int _defarg_61839 = NOVALUE;
    int _code_len_61840 = NOVALUE;
    int _extra_default_args_61842 = NOVALUE;
    int _param_sym_61845 = NOVALUE;
    int _params_61846 = NOVALUE;
    int _orig_code_61848 = NOVALUE;
    int _orig_linetable_61849 = NOVALUE;
    int _ar_sp_61852 = NOVALUE;
    int _pre_refs_61856 = NOVALUE;
    int _old_fwd_params_61871 = NOVALUE;
    int _temp_shifting_sub_61912 = NOVALUE;
    int _new_code_61916 = NOVALUE;
    int _routine_type_61925 = NOVALUE;
    int _31632 = NOVALUE;
    int _31016 = NOVALUE;
    int _31015 = NOVALUE;
    int _31014 = NOVALUE;
    int _31012 = NOVALUE;
    int _31011 = NOVALUE;
    int _31010 = NOVALUE;
    int _31009 = NOVALUE;
    int _31008 = NOVALUE;
    int _31007 = NOVALUE;
    int _31006 = NOVALUE;
    int _31005 = NOVALUE;
    int _31004 = NOVALUE;
    int _31003 = NOVALUE;
    int _31002 = NOVALUE;
    int _31001 = NOVALUE;
    int _31000 = NOVALUE;
    int _30998 = NOVALUE;
    int _30997 = NOVALUE;
    int _30996 = NOVALUE;
    int _30995 = NOVALUE;
    int _30994 = NOVALUE;
    int _30993 = NOVALUE;
    int _30992 = NOVALUE;
    int _30991 = NOVALUE;
    int _30989 = NOVALUE;
    int _30986 = NOVALUE;
    int _30985 = NOVALUE;
    int _30984 = NOVALUE;
    int _30983 = NOVALUE;
    int _30978 = NOVALUE;
    int _30977 = NOVALUE;
    int _30976 = NOVALUE;
    int _30975 = NOVALUE;
    int _30974 = NOVALUE;
    int _30972 = NOVALUE;
    int _30971 = NOVALUE;
    int _30970 = NOVALUE;
    int _30969 = NOVALUE;
    int _30968 = NOVALUE;
    int _30967 = NOVALUE;
    int _30965 = NOVALUE;
    int _30964 = NOVALUE;
    int _30962 = NOVALUE;
    int _30961 = NOVALUE;
    int _30960 = NOVALUE;
    int _30959 = NOVALUE;
    int _30957 = NOVALUE;
    int _30955 = NOVALUE;
    int _30954 = NOVALUE;
    int _30953 = NOVALUE;
    int _30951 = NOVALUE;
    int _30950 = NOVALUE;
    int _30948 = NOVALUE;
    int _30946 = NOVALUE;
    int _30943 = NOVALUE;
    int _30939 = NOVALUE;
    int _30937 = NOVALUE;
    int _30936 = NOVALUE;
    int _30934 = NOVALUE;
    int _30933 = NOVALUE;
    int _30932 = NOVALUE;
    int _30931 = NOVALUE;
    int _30929 = NOVALUE;
    int _30928 = NOVALUE;
    int _30927 = NOVALUE;
    int _30926 = NOVALUE;
    int _30925 = NOVALUE;
    int _30923 = NOVALUE;
    int _30922 = NOVALUE;
    int _30921 = NOVALUE;
    int _30920 = NOVALUE;
    int _30919 = NOVALUE;
    int _30918 = NOVALUE;
    int _30917 = NOVALUE;
    int _30916 = NOVALUE;
    int _30915 = NOVALUE;
    int _30913 = NOVALUE;
    int _30912 = NOVALUE;
    int _30911 = NOVALUE;
    int _30910 = NOVALUE;
    int _30909 = NOVALUE;
    int _30906 = NOVALUE;
    int _30902 = NOVALUE;
    int _30901 = NOVALUE;
    int _30900 = NOVALUE;
    int _30899 = NOVALUE;
    int _30898 = NOVALUE;
    int _30897 = NOVALUE;
    int _30895 = NOVALUE;
    int _30892 = NOVALUE;
    int _30890 = NOVALUE;
    int _30889 = NOVALUE;
    int _30887 = NOVALUE;
    int _30884 = NOVALUE;
    int _30883 = NOVALUE;
    int _30882 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	sequence fr = forward_references[ref]*/
    DeRef(_fr_61712);
    _2 = (int)SEQ_PTR(_38forward_references_61501);
    _fr_61712 = (int)*(((s1_ptr)_2)->base + _ref_61711);
    Ref(_fr_61712);

    /** 	symtab_index sub = tok[T_SYM]*/
    _2 = (int)SEQ_PTR(_tok_61710);
    _sub_61715 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_sub_61715)){
        _sub_61715 = (long)DBL_PTR(_sub_61715)->dbl;
    }

    /** 	if sequence( fr[FR_DATA] ) then*/
    _2 = (int)SEQ_PTR(_fr_61712);
    _30882 = (int)*(((s1_ptr)_2)->base + 12);
    _30883 = IS_SEQUENCE(_30882);
    _30882 = NOVALUE;
    if (_30883 == 0)
    {
        _30883 = NOVALUE;
        goto L1; // [32] 117
    }
    else{
        _30883 = NOVALUE;
    }

    /** 		sequence defarg = fr[FR_DATA][1]*/
    _2 = (int)SEQ_PTR(_fr_61712);
    _30884 = (int)*(((s1_ptr)_2)->base + 12);
    DeRef(_defarg_61721);
    _2 = (int)SEQ_PTR(_30884);
    _defarg_61721 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_defarg_61721);
    _30884 = NOVALUE;

    /** 		symtab_index paramsym = defarg[2]*/
    _2 = (int)SEQ_PTR(_defarg_61721);
    _paramsym_61725 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_paramsym_61725)){
        _paramsym_61725 = (long)DBL_PTR(_paramsym_61725)->dbl;
    }

    /** 		token old = { RECORDED, defarg[3] }*/
    _2 = (int)SEQ_PTR(_defarg_61721);
    _30887 = (int)*(((s1_ptr)_2)->base + 3);
    Ref(_30887);
    DeRef(_old_61728);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 508;
    ((int *)_2)[2] = _30887;
    _old_61728 = MAKE_SEQ(_1);
    _30887 = NOVALUE;

    /** 		integer tx = find( old, SymTab[paramsym][S_CODE] )*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _30889 = (int)*(((s1_ptr)_2)->base + _paramsym_61725);
    _2 = (int)SEQ_PTR(_30889);
    if (!IS_ATOM_INT(_35S_CODE_15929)){
        _30890 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_CODE_15929)->dbl));
    }
    else{
        _30890 = (int)*(((s1_ptr)_2)->base + _35S_CODE_15929);
    }
    _30889 = NOVALUE;
    _tx_61732 = find_from(_old_61728, _30890, 1);
    _30890 = NOVALUE;

    /** 		SymTab[paramsym][S_CODE][tx] = tok*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_paramsym_61725 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(object_ptr)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(object_ptr)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35S_CODE_15929))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_CODE_15929)->dbl));
    else
    _3 = (int)(_35S_CODE_15929 + ((s1_ptr)_2)->base);
    _30892 = NOVALUE;
    Ref(_tok_61710);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _tx_61732);
    _1 = *(int *)_2;
    *(int *)_2 = _tok_61710;
    DeRef(_1);
    _30892 = NOVALUE;

    /** 		resolved_reference( ref )*/
    _38resolved_reference(_ref_61711);

    /** 		return*/
    DeRefDS(_defarg_61721);
    DeRefDS(_old_61728);
    DeRef(_tok_61710);
    DeRefDS(_fr_61712);
    DeRef(_code_61767);
    DeRef(_name_61777);
    DeRef(_params_61846);
    DeRef(_orig_code_61848);
    DeRef(_orig_linetable_61849);
    DeRef(_old_fwd_params_61871);
    DeRef(_new_code_61916);
    return;
L1: 
    DeRef(_defarg_61721);
    _defarg_61721 = NOVALUE;
    DeRef(_old_61728);
    _old_61728 = NOVALUE;

    /** 	integer code_sub = fr[FR_SUBPROG]*/
    _2 = (int)SEQ_PTR(_fr_61712);
    _code_sub_61742 = (int)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_code_sub_61742))
    _code_sub_61742 = (long)DBL_PTR(_code_sub_61742)->dbl;

    /** 	integer args = SymTab[sub][S_NUM_ARGS]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _30895 = (int)*(((s1_ptr)_2)->base + _sub_61715);
    _2 = (int)SEQ_PTR(_30895);
    if (!IS_ATOM_INT(_35S_NUM_ARGS_15968)){
        _args_61744 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NUM_ARGS_15968)->dbl));
    }
    else{
        _args_61744 = (int)*(((s1_ptr)_2)->base + _35S_NUM_ARGS_15968);
    }
    if (!IS_ATOM_INT(_args_61744)){
        _args_61744 = (long)DBL_PTR(_args_61744)->dbl;
    }
    _30895 = NOVALUE;

    /** 	integer is_func = (SymTab[sub][S_TOKEN] = FUNC) or (SymTab[sub][S_TOKEN] = TYPE)*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _30897 = (int)*(((s1_ptr)_2)->base + _sub_61715);
    _2 = (int)SEQ_PTR(_30897);
    if (!IS_ATOM_INT(_35S_TOKEN_15922)){
        _30898 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TOKEN_15922)->dbl));
    }
    else{
        _30898 = (int)*(((s1_ptr)_2)->base + _35S_TOKEN_15922);
    }
    _30897 = NOVALUE;
    if (IS_ATOM_INT(_30898)) {
        _30899 = (_30898 == 501);
    }
    else {
        _30899 = binary_op(EQUALS, _30898, 501);
    }
    _30898 = NOVALUE;
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _30900 = (int)*(((s1_ptr)_2)->base + _sub_61715);
    _2 = (int)SEQ_PTR(_30900);
    if (!IS_ATOM_INT(_35S_TOKEN_15922)){
        _30901 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TOKEN_15922)->dbl));
    }
    else{
        _30901 = (int)*(((s1_ptr)_2)->base + _35S_TOKEN_15922);
    }
    _30900 = NOVALUE;
    if (IS_ATOM_INT(_30901)) {
        _30902 = (_30901 == 504);
    }
    else {
        _30902 = binary_op(EQUALS, _30901, 504);
    }
    _30901 = NOVALUE;
    if (IS_ATOM_INT(_30899) && IS_ATOM_INT(_30902)) {
        _is_func_61749 = (_30899 != 0 || _30902 != 0);
    }
    else {
        _is_func_61749 = binary_op(OR, _30899, _30902);
    }
    DeRef(_30899);
    _30899 = NOVALUE;
    DeRef(_30902);
    _30902 = NOVALUE;
    if (!IS_ATOM_INT(_is_func_61749)) {
        _1 = (long)(DBL_PTR(_is_func_61749)->dbl);
        DeRefDS(_is_func_61749);
        _is_func_61749 = _1;
    }

    /** 	integer real_file = current_file_no*/
    _real_file_61763 = _35current_file_no_16244;

    /** 	current_file_no = fr[FR_FILE]*/
    _2 = (int)SEQ_PTR(_fr_61712);
    _35current_file_no_16244 = (int)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_35current_file_no_16244)){
        _35current_file_no_16244 = (long)DBL_PTR(_35current_file_no_16244)->dbl;
    }

    /** 	set_code( ref )*/
    _38set_code(_ref_61711);

    /** 	sequence code = Code*/
    RefDS(_35Code_16332);
    DeRef(_code_61767);
    _code_61767 = _35Code_16332;

    /** 	integer temp_sub = CurrentSub*/
    _temp_sub_61769 = _35CurrentSub_16252;

    /** 	integer pc = fr[FR_PC]*/
    _2 = (int)SEQ_PTR(_fr_61712);
    _pc_61771 = (int)*(((s1_ptr)_2)->base + 5);
    if (!IS_ATOM_INT(_pc_61771))
    _pc_61771 = (long)DBL_PTR(_pc_61771)->dbl;

    /** 	integer next_pc = pc*/
    _next_pc_61773 = _pc_61771;

    /** 	integer supplied_args = code[pc+2]*/
    _30906 = _pc_61771 + 2;
    _2 = (int)SEQ_PTR(_code_61767);
    _supplied_args_61774 = (int)*(((s1_ptr)_2)->base + _30906);
    if (!IS_ATOM_INT(_supplied_args_61774))
    _supplied_args_61774 = (long)DBL_PTR(_supplied_args_61774)->dbl;

    /** 	sequence name = fr[FR_NAME]*/
    DeRef(_name_61777);
    _2 = (int)SEQ_PTR(_fr_61712);
    _name_61777 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_name_61777);

    /** 	if Code[pc] != FUNC_FORWARD and Code[pc] != PROC_FORWARD then*/
    _2 = (int)SEQ_PTR(_35Code_16332);
    _30909 = (int)*(((s1_ptr)_2)->base + _pc_61771);
    if (IS_ATOM_INT(_30909)) {
        _30910 = (_30909 != 196);
    }
    else {
        _30910 = binary_op(NOTEQ, _30909, 196);
    }
    _30909 = NOVALUE;
    if (IS_ATOM_INT(_30910)) {
        if (_30910 == 0) {
            goto L2; // [268] 332
        }
    }
    else {
        if (DBL_PTR(_30910)->dbl == 0.0) {
            goto L2; // [268] 332
        }
    }
    _2 = (int)SEQ_PTR(_35Code_16332);
    _30912 = (int)*(((s1_ptr)_2)->base + _pc_61771);
    if (IS_ATOM_INT(_30912)) {
        _30913 = (_30912 != 195);
    }
    else {
        _30913 = binary_op(NOTEQ, _30912, 195);
    }
    _30912 = NOVALUE;
    if (_30913 == 0) {
        DeRef(_30913);
        _30913 = NOVALUE;
        goto L2; // [285] 332
    }
    else {
        if (!IS_ATOM_INT(_30913) && DBL_PTR(_30913)->dbl == 0.0){
            DeRef(_30913);
            _30913 = NOVALUE;
            goto L2; // [285] 332
        }
        DeRef(_30913);
        _30913 = NOVALUE;
    }
    DeRef(_30913);
    _30913 = NOVALUE;

    /** 		prep_forward_error( ref )*/
    _38prep_forward_error(_ref_61711);

    /** 		CompileErr( "The forward call to [4] wasn't where we thought it would be: [1]:[2]:[3]",*/
    _2 = (int)SEQ_PTR(_36known_files_15243);
    _30915 = (int)*(((s1_ptr)_2)->base + _35current_file_no_16244);
    _2 = (int)SEQ_PTR(_fr_61712);
    _30916 = (int)*(((s1_ptr)_2)->base + 4);
    Ref(_30916);
    _30917 = _53sym_name(_30916);
    _30916 = NOVALUE;
    _2 = (int)SEQ_PTR(_fr_61712);
    _30918 = (int)*(((s1_ptr)_2)->base + 6);
    _2 = (int)SEQ_PTR(_fr_61712);
    _30919 = (int)*(((s1_ptr)_2)->base + 2);
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_30915);
    *((int *)(_2+4)) = _30915;
    *((int *)(_2+8)) = _30917;
    Ref(_30918);
    *((int *)(_2+12)) = _30918;
    Ref(_30919);
    *((int *)(_2+16)) = _30919;
    _30920 = MAKE_SEQ(_1);
    _30919 = NOVALUE;
    _30918 = NOVALUE;
    _30917 = NOVALUE;
    _30915 = NOVALUE;
    RefDS(_30914);
    _44CompileErr(_30914, _30920, 0);
    _30920 = NOVALUE;
L2: 

    /** 	integer old_temps_allocated = temps_allocated*/
    _old_temps_allocated_61801 = _53temps_allocated_46611;

    /** 	temps_allocated = 0*/
    _53temps_allocated_46611 = 0;

    /** 	if is_func and fr[FR_OP] = PROC then*/
    if (_is_func_61749 == 0) {
        goto L3; // [350] 438
    }
    _2 = (int)SEQ_PTR(_fr_61712);
    _30922 = (int)*(((s1_ptr)_2)->base + 10);
    if (IS_ATOM_INT(_30922)) {
        _30923 = (_30922 == 27);
    }
    else {
        _30923 = binary_op(EQUALS, _30922, 27);
    }
    _30922 = NOVALUE;
    if (_30923 == 0) {
        DeRef(_30923);
        _30923 = NOVALUE;
        goto L3; // [365] 438
    }
    else {
        if (!IS_ATOM_INT(_30923) && DBL_PTR(_30923)->dbl == 0.0){
            DeRef(_30923);
            _30923 = NOVALUE;
            goto L3; // [365] 438
        }
        DeRef(_30923);
        _30923 = NOVALUE;
    }
    DeRef(_30923);
    _30923 = NOVALUE;

    /** 		symtab_index temp_target = NewTempSym()*/
    _temp_target_61810 = _53NewTempSym(0);
    if (!IS_ATOM_INT(_temp_target_61810)) {
        _1 = (long)(DBL_PTR(_temp_target_61810)->dbl);
        DeRefDS(_temp_target_61810);
        _temp_target_61810 = _1;
    }

    /** 		sequence converted_code = */
    _30925 = _pc_61771 + 1;
    if (_30925 > MAXINT){
        _30925 = NewDouble((double)_30925);
    }
    _30926 = _pc_61771 + 2;
    if ((long)((unsigned long)_30926 + (unsigned long)HIGH_BITS) >= 0) 
    _30926 = NewDouble((double)_30926);
    if (IS_ATOM_INT(_30926)) {
        _30927 = _30926 + _supplied_args_61774;
    }
    else {
        _30927 = NewDouble(DBL_PTR(_30926)->dbl + (double)_supplied_args_61774);
    }
    DeRef(_30926);
    _30926 = NOVALUE;
    rhs_slice_target = (object_ptr)&_30928;
    RHS_Slice(_35Code_16332, _30925, _30927);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 208;
    ((int *)_2)[2] = _temp_target_61810;
    _30929 = MAKE_SEQ(_1);
    {
        int concat_list[4];

        concat_list[0] = _30929;
        concat_list[1] = _temp_target_61810;
        concat_list[2] = _30928;
        concat_list[3] = 196;
        Concat_N((object_ptr)&_converted_code_61813, concat_list, 4);
    }
    DeRefDS(_30929);
    _30929 = NOVALUE;
    DeRefDS(_30928);
    _30928 = NOVALUE;

    /** 		replace_code( converted_code, pc, pc + 2 + supplied_args, code_sub )*/
    _30931 = _pc_61771 + 2;
    if ((long)((unsigned long)_30931 + (unsigned long)HIGH_BITS) >= 0) 
    _30931 = NewDouble((double)_30931);
    if (IS_ATOM_INT(_30931)) {
        _30932 = _30931 + _supplied_args_61774;
        if ((long)((unsigned long)_30932 + (unsigned long)HIGH_BITS) >= 0) 
        _30932 = NewDouble((double)_30932);
    }
    else {
        _30932 = NewDouble(DBL_PTR(_30931)->dbl + (double)_supplied_args_61774);
    }
    DeRef(_30931);
    _30931 = NOVALUE;
    RefDS(_converted_code_61813);
    _38replace_code(_converted_code_61813, _pc_61771, _30932, _code_sub_61742);
    _30932 = NOVALUE;

    /** 		code = Code*/
    RefDS(_35Code_16332);
    DeRef(_code_61767);
    _code_61767 = _35Code_16332;
L3: 
    DeRef(_converted_code_61813);
    _converted_code_61813 = NOVALUE;

    /** 	next_pc +=*/
    _30933 = 3 + _supplied_args_61774;
    if ((long)((unsigned long)_30933 + (unsigned long)HIGH_BITS) >= 0) 
    _30933 = NewDouble((double)_30933);
    if (IS_ATOM_INT(_30933)) {
        _30934 = _30933 + _is_func_61749;
        if ((long)((unsigned long)_30934 + (unsigned long)HIGH_BITS) >= 0) 
        _30934 = NewDouble((double)_30934);
    }
    else {
        _30934 = NewDouble(DBL_PTR(_30933)->dbl + (double)_is_func_61749);
    }
    DeRef(_30933);
    _30933 = NOVALUE;
    if (IS_ATOM_INT(_30934)) {
        _next_pc_61773 = _next_pc_61773 + _30934;
    }
    else {
        _next_pc_61773 = NewDouble((double)_next_pc_61773 + DBL_PTR(_30934)->dbl);
    }
    DeRef(_30934);
    _30934 = NOVALUE;
    if (!IS_ATOM_INT(_next_pc_61773)) {
        _1 = (long)(DBL_PTR(_next_pc_61773)->dbl);
        DeRefDS(_next_pc_61773);
        _next_pc_61773 = _1;
    }

    /** 	integer target*/

    /** 	if is_func then*/
    if (_is_func_61749 == 0)
    {
        goto L4; // [460] 482
    }
    else{
    }

    /** 		target = Code[pc + 3 + supplied_args]*/
    _30936 = _pc_61771 + 3;
    if ((long)((unsigned long)_30936 + (unsigned long)HIGH_BITS) >= 0) 
    _30936 = NewDouble((double)_30936);
    if (IS_ATOM_INT(_30936)) {
        _30937 = _30936 + _supplied_args_61774;
    }
    else {
        _30937 = NewDouble(DBL_PTR(_30936)->dbl + (double)_supplied_args_61774);
    }
    DeRef(_30936);
    _30936 = NOVALUE;
    _2 = (int)SEQ_PTR(_35Code_16332);
    if (!IS_ATOM_INT(_30937)){
        _target_61829 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_30937)->dbl));
    }
    else{
        _target_61829 = (int)*(((s1_ptr)_2)->base + _30937);
    }
    if (!IS_ATOM_INT(_target_61829)){
        _target_61829 = (long)DBL_PTR(_target_61829)->dbl;
    }
L4: 

    /** 	integer has_defaults = 0*/
    _has_defaults_61835 = 0;

    /** 	integer goto_target = length( code ) + 1*/
    if (IS_SEQUENCE(_code_61767)){
            _30939 = SEQ_PTR(_code_61767)->length;
    }
    else {
        _30939 = 1;
    }
    _goto_target_61836 = _30939 + 1;
    _30939 = NOVALUE;

    /** 	integer defarg = 0*/
    _defarg_61839 = 0;

    /** 	integer code_len = length(code)*/
    if (IS_SEQUENCE(_code_61767)){
            _code_len_61840 = SEQ_PTR(_code_61767)->length;
    }
    else {
        _code_len_61840 = 1;
    }

    /** 	integer extra_default_args = 0*/
    _extra_default_args_61842 = 0;

    /** 	set_dont_read( 1 )*/
    _61set_dont_read(1);

    /** 	reset_private_lists()*/

    /** 	fwd_private_sym  = {}*/
    RefDS(_22023);
    DeRefi(_38fwd_private_sym_61673);
    _38fwd_private_sym_61673 = _22023;

    /** 	fwd_private_name = {}*/
    RefDS(_22023);
    DeRef(_38fwd_private_name_61674);
    _38fwd_private_name_61674 = _22023;

    /** end procedure*/
    goto L5; // [534] 537
L5: 

    /** 	integer param_sym = sub*/
    _param_sym_61845 = _sub_61715;

    /** 	sequence params = repeat( 0, args )*/
    DeRef(_params_61846);
    _params_61846 = Repeat(0, _args_61744);

    /** 	sequence orig_code = code*/
    RefDS(_code_61767);
    DeRef(_orig_code_61848);
    _orig_code_61848 = _code_61767;

    /** 	sequence orig_linetable = LineTable*/
    RefDS(_35LineTable_16333);
    DeRef(_orig_linetable_61849);
    _orig_linetable_61849 = _35LineTable_16333;

    /** 	Code = {}*/
    RefDS(_22023);
    DeRef(_35Code_16332);
    _35Code_16332 = _22023;

    /** 	integer ar_sp = find( code_sub, active_subprogs[current_file_no] )*/
    _2 = (int)SEQ_PTR(_38active_subprogs_61502);
    _30943 = (int)*(((s1_ptr)_2)->base + _35current_file_no_16244);
    _ar_sp_61852 = find_from(_code_sub_61742, _30943, 1);
    _30943 = NOVALUE;

    /** 	integer pre_refs*/

    /** 	if code_sub = TopLevelSub then*/
    if (_code_sub_61742 != _35TopLevelSub_16251)
    goto L6; // [594] 614

    /** 		pre_refs = length( toplevel_references[current_file_no] )*/
    _2 = (int)SEQ_PTR(_38toplevel_references_61504);
    _30946 = (int)*(((s1_ptr)_2)->base + _35current_file_no_16244);
    if (IS_SEQUENCE(_30946)){
            _pre_refs_61856 = SEQ_PTR(_30946)->length;
    }
    else {
        _pre_refs_61856 = 1;
    }
    _30946 = NOVALUE;
    goto L7; // [611] 647
L6: 

    /** 		ar_sp = find( code_sub, active_subprogs[current_file_no] )*/
    _2 = (int)SEQ_PTR(_38active_subprogs_61502);
    _30948 = (int)*(((s1_ptr)_2)->base + _35current_file_no_16244);
    _ar_sp_61852 = find_from(_code_sub_61742, _30948, 1);
    _30948 = NOVALUE;

    /** 		pre_refs = length( active_references[current_file_no][ar_sp] )*/
    _2 = (int)SEQ_PTR(_38active_references_61503);
    _30950 = (int)*(((s1_ptr)_2)->base + _35current_file_no_16244);
    _2 = (int)SEQ_PTR(_30950);
    _30951 = (int)*(((s1_ptr)_2)->base + _ar_sp_61852);
    _30950 = NOVALUE;
    if (IS_SEQUENCE(_30951)){
            _pre_refs_61856 = SEQ_PTR(_30951)->length;
    }
    else {
        _pre_refs_61856 = 1;
    }
    _30951 = NOVALUE;
L7: 

    /** 	sequence old_fwd_params = {}*/
    RefDS(_22023);
    DeRef(_old_fwd_params_61871);
    _old_fwd_params_61871 = _22023;

    /** 	for i = pc + 3 to pc + args + 2 do*/
    _30953 = _pc_61771 + 3;
    if ((long)((unsigned long)_30953 + (unsigned long)HIGH_BITS) >= 0) 
    _30953 = NewDouble((double)_30953);
    _30954 = _pc_61771 + _args_61744;
    if ((long)((unsigned long)_30954 + (unsigned long)HIGH_BITS) >= 0) 
    _30954 = NewDouble((double)_30954);
    if (IS_ATOM_INT(_30954)) {
        _30955 = _30954 + 2;
        if ((long)((unsigned long)_30955 + (unsigned long)HIGH_BITS) >= 0) 
        _30955 = NewDouble((double)_30955);
    }
    else {
        _30955 = NewDouble(DBL_PTR(_30954)->dbl + (double)2);
    }
    DeRef(_30954);
    _30954 = NOVALUE;
    {
        int _i_61873;
        Ref(_30953);
        _i_61873 = _30953;
L8: 
        if (binary_op_a(GREATER, _i_61873, _30955)){
            goto L9; // [668] 829
        }

        /** 		defarg += 1*/
        _defarg_61839 = _defarg_61839 + 1;

        /** 		param_sym = SymTab[param_sym][S_NEXT]*/
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _30957 = (int)*(((s1_ptr)_2)->base + _param_sym_61845);
        _2 = (int)SEQ_PTR(_30957);
        _param_sym_61845 = (int)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_param_sym_61845)){
            _param_sym_61845 = (long)DBL_PTR(_param_sym_61845)->dbl;
        }
        _30957 = NOVALUE;

        /** 		if defarg > supplied_args or i > length( code ) or not code[i] then*/
        _30959 = (_defarg_61839 > _supplied_args_61774);
        if (_30959 != 0) {
            _30960 = 1;
            goto LA; // [703] 718
        }
        if (IS_SEQUENCE(_code_61767)){
                _30961 = SEQ_PTR(_code_61767)->length;
        }
        else {
            _30961 = 1;
        }
        if (IS_ATOM_INT(_i_61873)) {
            _30962 = (_i_61873 > _30961);
        }
        else {
            _30962 = (DBL_PTR(_i_61873)->dbl > (double)_30961);
        }
        _30961 = NOVALUE;
        _30960 = (_30962 != 0);
LA: 
        if (_30960 != 0) {
            goto LB; // [718] 734
        }
        _2 = (int)SEQ_PTR(_code_61767);
        if (!IS_ATOM_INT(_i_61873)){
            _30964 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_61873)->dbl));
        }
        else{
            _30964 = (int)*(((s1_ptr)_2)->base + _i_61873);
        }
        if (IS_ATOM_INT(_30964)) {
            _30965 = (_30964 == 0);
        }
        else {
            _30965 = unary_op(NOT, _30964);
        }
        _30964 = NOVALUE;
        if (_30965 == 0) {
            DeRef(_30965);
            _30965 = NOVALUE;
            goto LC; // [730] 784
        }
        else {
            if (!IS_ATOM_INT(_30965) && DBL_PTR(_30965)->dbl == 0.0){
                DeRef(_30965);
                _30965 = NOVALUE;
                goto LC; // [730] 784
            }
            DeRef(_30965);
            _30965 = NOVALUE;
        }
        DeRef(_30965);
        _30965 = NOVALUE;
LB: 

        /** 			has_defaults = 1*/
        _has_defaults_61835 = 1;

        /** 			extra_default_args += 1*/
        _extra_default_args_61842 = _extra_default_args_61842 + 1;

        /** 			show_params( sub )*/
        _53show_params(_sub_61715);

        /** 			set_error_info( ref )*/
        _38set_error_info(_ref_61711);

        /** 			Parse_default_arg(sub, defarg, fwd_private_name, fwd_private_sym) --call_proc( parse_arg_rid, { sub, defarg, fwd_private_name, fwd_private_sym } )*/
        RefDS(_38fwd_private_name_61674);
        RefDS(_38fwd_private_sym_61673);
        _39Parse_default_arg(_sub_61715, _defarg_61839, _38fwd_private_name_61674, _38fwd_private_sym_61673);

        /** 			hide_params( sub )*/
        _53hide_params(_sub_61715);

        /** 			params[defarg] = Pop()*/
        _30967 = _41Pop();
        _2 = (int)SEQ_PTR(_params_61846);
        _2 = (int)(((s1_ptr)_2)->base + _defarg_61839);
        _1 = *(int *)_2;
        *(int *)_2 = _30967;
        if( _1 != _30967 ){
            DeRef(_1);
        }
        _30967 = NOVALUE;
        goto LD; // [781] 822
LC: 

        /** 			extra_default_args = 0*/
        _extra_default_args_61842 = 0;

        /** 			add_private_symbol( code[i], SymTab[param_sym][S_NAME] )*/
        _2 = (int)SEQ_PTR(_code_61767);
        if (!IS_ATOM_INT(_i_61873)){
            _30968 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_61873)->dbl));
        }
        else{
            _30968 = (int)*(((s1_ptr)_2)->base + _i_61873);
        }
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _30969 = (int)*(((s1_ptr)_2)->base + _param_sym_61845);
        _2 = (int)SEQ_PTR(_30969);
        if (!IS_ATOM_INT(_35S_NAME_15917)){
            _30970 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15917)->dbl));
        }
        else{
            _30970 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15917);
        }
        _30969 = NOVALUE;
        Ref(_30968);
        Ref(_30970);
        _38add_private_symbol(_30968, _30970);
        _30968 = NOVALUE;
        _30970 = NOVALUE;

        /** 			params[defarg] = code[i]*/
        _2 = (int)SEQ_PTR(_code_61767);
        if (!IS_ATOM_INT(_i_61873)){
            _30971 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_61873)->dbl));
        }
        else{
            _30971 = (int)*(((s1_ptr)_2)->base + _i_61873);
        }
        Ref(_30971);
        _2 = (int)SEQ_PTR(_params_61846);
        _2 = (int)(((s1_ptr)_2)->base + _defarg_61839);
        _1 = *(int *)_2;
        *(int *)_2 = _30971;
        if( _1 != _30971 ){
            DeRef(_1);
        }
        _30971 = NOVALUE;
LD: 

        /** 	end for*/
        _0 = _i_61873;
        if (IS_ATOM_INT(_i_61873)) {
            _i_61873 = _i_61873 + 1;
            if ((long)((unsigned long)_i_61873 +(unsigned long) HIGH_BITS) >= 0){
                _i_61873 = NewDouble((double)_i_61873);
            }
        }
        else {
            _i_61873 = binary_op_a(PLUS, _i_61873, 1);
        }
        DeRef(_0);
        goto L8; // [824] 675
L9: 
        ;
        DeRef(_i_61873);
    }

    /** 	SymTab[code_sub][S_STACK_SPACE] += temps_allocated*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_code_sub_61742 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!IS_ATOM_INT(_35S_STACK_SPACE_15977)){
        _30974 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_STACK_SPACE_15977)->dbl));
    }
    else{
        _30974 = (int)*(((s1_ptr)_2)->base + _35S_STACK_SPACE_15977);
    }
    _30972 = NOVALUE;
    if (IS_ATOM_INT(_30974)) {
        _30975 = _30974 + _53temps_allocated_46611;
        if ((long)((unsigned long)_30975 + (unsigned long)HIGH_BITS) >= 0) 
        _30975 = NewDouble((double)_30975);
    }
    else {
        _30975 = binary_op(PLUS, _30974, _53temps_allocated_46611);
    }
    _30974 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35S_STACK_SPACE_15977))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_STACK_SPACE_15977)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _35S_STACK_SPACE_15977);
    _1 = *(int *)_2;
    *(int *)_2 = _30975;
    if( _1 != _30975 ){
        DeRef(_1);
    }
    _30975 = NOVALUE;
    _30972 = NOVALUE;

    /** 	temps_allocated = old_temps_allocated*/
    _53temps_allocated_46611 = _old_temps_allocated_61801;

    /** 	integer temp_shifting_sub = shifting_sub*/
    _temp_shifting_sub_61912 = _38shifting_sub_61520;

    /** 	shift( -pc, pc-1 )*/
    if ((unsigned long)_pc_61771 == 0xC0000000)
    _30976 = (int)NewDouble((double)-0xC0000000);
    else
    _30976 = - _pc_61771;
    _30977 = _pc_61771 - 1;
    if ((long)((unsigned long)_30977 +(unsigned long) HIGH_BITS) >= 0){
        _30977 = NewDouble((double)_30977);
    }
    Ref(_30976);
    DeRef(_31632);
    _31632 = _30976;
    _65shift(_30976, _30977, _31632);
    _30976 = NOVALUE;
    _30977 = NOVALUE;
    _31632 = NOVALUE;

    /** 	sequence new_code = Code*/
    RefDS(_35Code_16332);
    DeRef(_new_code_61916);
    _new_code_61916 = _35Code_16332;

    /** 	Code = orig_code*/
    RefDS(_orig_code_61848);
    DeRefDS(_35Code_16332);
    _35Code_16332 = _orig_code_61848;

    /** 	LineTable = orig_linetable*/
    RefDS(_orig_linetable_61849);
    DeRef(_35LineTable_16333);
    _35LineTable_16333 = _orig_linetable_61849;

    /** 	set_dont_read( 0 )*/
    _61set_dont_read(0);

    /** 	current_file_no = real_file*/
    _35current_file_no_16244 = _real_file_61763;

    /** 	if args != ( supplied_args + extra_default_args ) then*/
    _30978 = _supplied_args_61774 + _extra_default_args_61842;
    if ((long)((unsigned long)_30978 + (unsigned long)HIGH_BITS) >= 0) 
    _30978 = NewDouble((double)_30978);
    if (binary_op_a(EQUALS, _args_61744, _30978)){
        DeRef(_30978);
        _30978 = NOVALUE;
        goto LE; // [926] 1004
    }
    DeRef(_30978);
    _30978 = NOVALUE;

    /** 		sequence routine_type*/

    /** 		if is_func then */
    if (_is_func_61749 == 0)
    {
        goto LF; // [934] 947
    }
    else{
    }

    /** 			routine_type = "function"*/
    RefDS(_26330);
    DeRefi(_routine_type_61925);
    _routine_type_61925 = _26330;
    goto L10; // [944] 955
LF: 

    /** 			routine_type = "procedure"*/
    RefDS(_26384);
    DeRefi(_routine_type_61925);
    _routine_type_61925 = _26384;
L10: 

    /** 		current_file_no = fr[FR_FILE]*/
    _2 = (int)SEQ_PTR(_fr_61712);
    _35current_file_no_16244 = (int)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_35current_file_no_16244)){
        _35current_file_no_16244 = (long)DBL_PTR(_35current_file_no_16244)->dbl;
    }

    /** 		line_number = fr[FR_LINE]*/
    _2 = (int)SEQ_PTR(_fr_61712);
    _35line_number_16245 = (int)*(((s1_ptr)_2)->base + 6);
    if (!IS_ATOM_INT(_35line_number_16245)){
        _35line_number_16245 = (long)DBL_PTR(_35line_number_16245)->dbl;
    }

    /** 		CompileErr( 158,*/
    _2 = (int)SEQ_PTR(_36known_files_15243);
    _30983 = (int)*(((s1_ptr)_2)->base + _35current_file_no_16244);
    _30984 = _supplied_args_61774 + _extra_default_args_61842;
    if ((long)((unsigned long)_30984 + (unsigned long)HIGH_BITS) >= 0) 
    _30984 = NewDouble((double)_30984);
    _1 = NewS1(6);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_30983);
    *((int *)(_2+4)) = _30983;
    *((int *)(_2+8)) = _35line_number_16245;
    RefDS(_routine_type_61925);
    *((int *)(_2+12)) = _routine_type_61925;
    RefDS(_name_61777);
    *((int *)(_2+16)) = _name_61777;
    *((int *)(_2+20)) = _args_61744;
    *((int *)(_2+24)) = _30984;
    _30985 = MAKE_SEQ(_1);
    _30984 = NOVALUE;
    _30983 = NOVALUE;
    _44CompileErr(158, _30985, 0);
    _30985 = NOVALUE;
LE: 
    DeRefi(_routine_type_61925);
    _routine_type_61925 = NOVALUE;

    /** 	new_code &= PROC & sub & params*/
    {
        int concat_list[3];

        concat_list[0] = _params_61846;
        concat_list[1] = _sub_61715;
        concat_list[2] = 27;
        Concat_N((object_ptr)&_30986, concat_list, 3);
    }
    Concat((object_ptr)&_new_code_61916, _new_code_61916, _30986);
    DeRefDS(_30986);
    _30986 = NOVALUE;

    /** 	if is_func then*/
    if (_is_func_61749 == 0)
    {
        goto L11; // [1022] 1034
    }
    else{
    }

    /** 		new_code &= target*/
    Append(&_new_code_61916, _new_code_61916, _target_61829);
L11: 

    /** 	replace_code( new_code, pc, next_pc - 1, code_sub )*/
    _30989 = _next_pc_61773 - 1;
    if ((long)((unsigned long)_30989 +(unsigned long) HIGH_BITS) >= 0){
        _30989 = NewDouble((double)_30989);
    }
    RefDS(_new_code_61916);
    _38replace_code(_new_code_61916, _pc_61771, _30989, _code_sub_61742);
    _30989 = NOVALUE;

    /** 	if code_sub = TopLevelSub then*/
    if (_code_sub_61742 != _35TopLevelSub_16251)
    goto L12; // [1050] 1131

    /** 		for i = pre_refs + 1 to length( toplevel_references[fr[FR_FILE]] ) do*/
    _30991 = _pre_refs_61856 + 1;
    if (_30991 > MAXINT){
        _30991 = NewDouble((double)_30991);
    }
    _2 = (int)SEQ_PTR(_fr_61712);
    _30992 = (int)*(((s1_ptr)_2)->base + 3);
    _2 = (int)SEQ_PTR(_38toplevel_references_61504);
    if (!IS_ATOM_INT(_30992)){
        _30993 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_30992)->dbl));
    }
    else{
        _30993 = (int)*(((s1_ptr)_2)->base + _30992);
    }
    if (IS_SEQUENCE(_30993)){
            _30994 = SEQ_PTR(_30993)->length;
    }
    else {
        _30994 = 1;
    }
    _30993 = NOVALUE;
    {
        int _i_61950;
        Ref(_30991);
        _i_61950 = _30991;
L13: 
        if (binary_op_a(GREATER, _i_61950, _30994)){
            goto L14; // [1075] 1128
        }

        /** 			forward_references[toplevel_references[fr[FR_FILE]][i]][FR_PC] += pc - 1*/
        _2 = (int)SEQ_PTR(_fr_61712);
        _30995 = (int)*(((s1_ptr)_2)->base + 3);
        _2 = (int)SEQ_PTR(_38toplevel_references_61504);
        if (!IS_ATOM_INT(_30995)){
            _30996 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_30995)->dbl));
        }
        else{
            _30996 = (int)*(((s1_ptr)_2)->base + _30995);
        }
        _2 = (int)SEQ_PTR(_30996);
        if (!IS_ATOM_INT(_i_61950)){
            _30997 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_61950)->dbl));
        }
        else{
            _30997 = (int)*(((s1_ptr)_2)->base + _i_61950);
        }
        _30996 = NOVALUE;
        _2 = (int)SEQ_PTR(_38forward_references_61501);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _38forward_references_61501 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_30997))
        _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_30997)->dbl));
        else
        _3 = (int)(_30997 + ((s1_ptr)_2)->base);
        _31000 = _pc_61771 - 1;
        if ((long)((unsigned long)_31000 +(unsigned long) HIGH_BITS) >= 0){
            _31000 = NewDouble((double)_31000);
        }
        _2 = (int)SEQ_PTR(*(int *)_3);
        _31001 = (int)*(((s1_ptr)_2)->base + 5);
        _30998 = NOVALUE;
        if (IS_ATOM_INT(_31001) && IS_ATOM_INT(_31000)) {
            _31002 = _31001 + _31000;
            if ((long)((unsigned long)_31002 + (unsigned long)HIGH_BITS) >= 0) 
            _31002 = NewDouble((double)_31002);
        }
        else {
            _31002 = binary_op(PLUS, _31001, _31000);
        }
        _31001 = NOVALUE;
        DeRef(_31000);
        _31000 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 5);
        _1 = *(int *)_2;
        *(int *)_2 = _31002;
        if( _1 != _31002 ){
            DeRef(_1);
        }
        _31002 = NOVALUE;
        _30998 = NOVALUE;

        /** 		end for*/
        _0 = _i_61950;
        if (IS_ATOM_INT(_i_61950)) {
            _i_61950 = _i_61950 + 1;
            if ((long)((unsigned long)_i_61950 +(unsigned long) HIGH_BITS) >= 0){
                _i_61950 = NewDouble((double)_i_61950);
            }
        }
        else {
            _i_61950 = binary_op_a(PLUS, _i_61950, 1);
        }
        DeRef(_0);
        goto L13; // [1123] 1082
L14: 
        ;
        DeRef(_i_61950);
    }
    goto L15; // [1128] 1214
L12: 

    /** 		for i = pre_refs + 1 to length( active_references[fr[FR_FILE]][ar_sp] ) do*/
    _31003 = _pre_refs_61856 + 1;
    if (_31003 > MAXINT){
        _31003 = NewDouble((double)_31003);
    }
    _2 = (int)SEQ_PTR(_fr_61712);
    _31004 = (int)*(((s1_ptr)_2)->base + 3);
    _2 = (int)SEQ_PTR(_38active_references_61503);
    if (!IS_ATOM_INT(_31004)){
        _31005 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_31004)->dbl));
    }
    else{
        _31005 = (int)*(((s1_ptr)_2)->base + _31004);
    }
    _2 = (int)SEQ_PTR(_31005);
    _31006 = (int)*(((s1_ptr)_2)->base + _ar_sp_61852);
    _31005 = NOVALUE;
    if (IS_SEQUENCE(_31006)){
            _31007 = SEQ_PTR(_31006)->length;
    }
    else {
        _31007 = 1;
    }
    _31006 = NOVALUE;
    {
        int _i_61965;
        Ref(_31003);
        _i_61965 = _31003;
L16: 
        if (binary_op_a(GREATER, _i_61965, _31007)){
            goto L17; // [1156] 1213
        }

        /** 			forward_references[active_references[fr[FR_FILE]][ar_sp][i]][FR_PC] += pc - 1*/
        _2 = (int)SEQ_PTR(_fr_61712);
        _31008 = (int)*(((s1_ptr)_2)->base + 3);
        _2 = (int)SEQ_PTR(_38active_references_61503);
        if (!IS_ATOM_INT(_31008)){
            _31009 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_31008)->dbl));
        }
        else{
            _31009 = (int)*(((s1_ptr)_2)->base + _31008);
        }
        _2 = (int)SEQ_PTR(_31009);
        _31010 = (int)*(((s1_ptr)_2)->base + _ar_sp_61852);
        _31009 = NOVALUE;
        _2 = (int)SEQ_PTR(_31010);
        if (!IS_ATOM_INT(_i_61965)){
            _31011 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_61965)->dbl));
        }
        else{
            _31011 = (int)*(((s1_ptr)_2)->base + _i_61965);
        }
        _31010 = NOVALUE;
        _2 = (int)SEQ_PTR(_38forward_references_61501);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _38forward_references_61501 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_31011))
        _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_31011)->dbl));
        else
        _3 = (int)(_31011 + ((s1_ptr)_2)->base);
        _31014 = _pc_61771 - 1;
        if ((long)((unsigned long)_31014 +(unsigned long) HIGH_BITS) >= 0){
            _31014 = NewDouble((double)_31014);
        }
        _2 = (int)SEQ_PTR(*(int *)_3);
        _31015 = (int)*(((s1_ptr)_2)->base + 5);
        _31012 = NOVALUE;
        if (IS_ATOM_INT(_31015) && IS_ATOM_INT(_31014)) {
            _31016 = _31015 + _31014;
            if ((long)((unsigned long)_31016 + (unsigned long)HIGH_BITS) >= 0) 
            _31016 = NewDouble((double)_31016);
        }
        else {
            _31016 = binary_op(PLUS, _31015, _31014);
        }
        _31015 = NOVALUE;
        DeRef(_31014);
        _31014 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 5);
        _1 = *(int *)_2;
        *(int *)_2 = _31016;
        if( _1 != _31016 ){
            DeRef(_1);
        }
        _31016 = NOVALUE;
        _31012 = NOVALUE;

        /** 		end for*/
        _0 = _i_61965;
        if (IS_ATOM_INT(_i_61965)) {
            _i_61965 = _i_61965 + 1;
            if ((long)((unsigned long)_i_61965 +(unsigned long) HIGH_BITS) >= 0){
                _i_61965 = NewDouble((double)_i_61965);
            }
        }
        else {
            _i_61965 = binary_op_a(PLUS, _i_61965, 1);
        }
        DeRef(_0);
        goto L16; // [1208] 1163
L17: 
        ;
        DeRef(_i_61965);
    }
L15: 

    /** 	reset_code()*/
    _38reset_code();

    /** 	resolved_reference( ref )*/
    _38resolved_reference(_ref_61711);

    /** end procedure*/
    DeRef(_tok_61710);
    DeRef(_fr_61712);
    DeRef(_code_61767);
    DeRef(_name_61777);
    DeRef(_params_61846);
    DeRef(_orig_code_61848);
    DeRef(_orig_linetable_61849);
    DeRef(_old_fwd_params_61871);
    DeRef(_new_code_61916);
    _31011 = NOVALUE;
    _30946 = NOVALUE;
    DeRef(_30962);
    _30962 = NOVALUE;
    DeRef(_30910);
    _30910 = NOVALUE;
    DeRef(_30955);
    _30955 = NOVALUE;
    _30995 = NOVALUE;
    _30993 = NOVALUE;
    _31006 = NOVALUE;
    _30997 = NOVALUE;
    _31008 = NOVALUE;
    DeRef(_30927);
    _30927 = NOVALUE;
    _30951 = NOVALUE;
    DeRef(_30991);
    _30991 = NOVALUE;
    DeRef(_30925);
    _30925 = NOVALUE;
    DeRef(_30959);
    _30959 = NOVALUE;
    DeRef(_30937);
    _30937 = NOVALUE;
    _31004 = NOVALUE;
    DeRef(_30906);
    _30906 = NOVALUE;
    DeRef(_30953);
    _30953 = NOVALUE;
    DeRef(_31003);
    _31003 = NOVALUE;
    _30992 = NOVALUE;
    return;
    ;
}


void _38set_error_info(int _ref_61982)
{
    int _fr_61983 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence fr = forward_references[ref]*/
    DeRef(_fr_61983);
    _2 = (int)SEQ_PTR(_38forward_references_61501);
    _fr_61983 = (int)*(((s1_ptr)_2)->base + _ref_61982);
    Ref(_fr_61983);

    /** 	ThisLine        = fr[FR_THISLINE]*/
    DeRef(_44ThisLine_48518);
    _2 = (int)SEQ_PTR(_fr_61983);
    _44ThisLine_48518 = (int)*(((s1_ptr)_2)->base + 7);
    Ref(_44ThisLine_48518);

    /** 	bp              = fr[FR_BP]*/
    _2 = (int)SEQ_PTR(_fr_61983);
    _44bp_48522 = (int)*(((s1_ptr)_2)->base + 8);
    if (!IS_ATOM_INT(_44bp_48522)){
        _44bp_48522 = (long)DBL_PTR(_44bp_48522)->dbl;
    }

    /** 	line_number     = fr[FR_LINE]*/
    _2 = (int)SEQ_PTR(_fr_61983);
    _35line_number_16245 = (int)*(((s1_ptr)_2)->base + 6);
    if (!IS_ATOM_INT(_35line_number_16245)){
        _35line_number_16245 = (long)DBL_PTR(_35line_number_16245)->dbl;
    }

    /** 	current_file_no = fr[FR_FILE]*/
    _2 = (int)SEQ_PTR(_fr_61983);
    _35current_file_no_16244 = (int)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_35current_file_no_16244)){
        _35current_file_no_16244 = (long)DBL_PTR(_35current_file_no_16244)->dbl;
    }

    /** end procedure*/
    DeRefDS(_fr_61983);
    return;
    ;
}


void _38patch_forward_variable(int _tok_61996, int _ref_61997)
{
    int _fr_61998 = NOVALUE;
    int _sym_62001 = NOVALUE;
    int _pc_62053 = NOVALUE;
    int _vx_62057 = NOVALUE;
    int _d_62074 = NOVALUE;
    int _param_62084 = NOVALUE;
    int _old_62087 = NOVALUE;
    int _new_62092 = NOVALUE;
    int _31073 = NOVALUE;
    int _31072 = NOVALUE;
    int _31071 = NOVALUE;
    int _31069 = NOVALUE;
    int _31066 = NOVALUE;
    int _31064 = NOVALUE;
    int _31063 = NOVALUE;
    int _31062 = NOVALUE;
    int _31061 = NOVALUE;
    int _31059 = NOVALUE;
    int _31058 = NOVALUE;
    int _31057 = NOVALUE;
    int _31056 = NOVALUE;
    int _31055 = NOVALUE;
    int _31053 = NOVALUE;
    int _31051 = NOVALUE;
    int _31048 = NOVALUE;
    int _31047 = NOVALUE;
    int _31046 = NOVALUE;
    int _31044 = NOVALUE;
    int _31043 = NOVALUE;
    int _31042 = NOVALUE;
    int _31041 = NOVALUE;
    int _31039 = NOVALUE;
    int _31037 = NOVALUE;
    int _31036 = NOVALUE;
    int _31035 = NOVALUE;
    int _31034 = NOVALUE;
    int _31033 = NOVALUE;
    int _31032 = NOVALUE;
    int _31031 = NOVALUE;
    int _31030 = NOVALUE;
    int _31029 = NOVALUE;
    int _31028 = NOVALUE;
    int _31027 = NOVALUE;
    int _31026 = NOVALUE;
    int _31025 = NOVALUE;
    int _31024 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	sequence fr = forward_references[ref]*/
    DeRef(_fr_61998);
    _2 = (int)SEQ_PTR(_38forward_references_61501);
    _fr_61998 = (int)*(((s1_ptr)_2)->base + _ref_61997);
    Ref(_fr_61998);

    /** 	symtab_index sym = tok[T_SYM]*/
    _2 = (int)SEQ_PTR(_tok_61996);
    _sym_62001 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_sym_62001)){
        _sym_62001 = (long)DBL_PTR(_sym_62001)->dbl;
    }

    /** 	if SymTab[sym][S_FILE_NO] = fr[FR_FILE] */
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _31024 = (int)*(((s1_ptr)_2)->base + _sym_62001);
    _2 = (int)SEQ_PTR(_31024);
    if (!IS_ATOM_INT(_35S_FILE_NO_15913)){
        _31025 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FILE_NO_15913)->dbl));
    }
    else{
        _31025 = (int)*(((s1_ptr)_2)->base + _35S_FILE_NO_15913);
    }
    _31024 = NOVALUE;
    _2 = (int)SEQ_PTR(_fr_61998);
    _31026 = (int)*(((s1_ptr)_2)->base + 3);
    if (IS_ATOM_INT(_31025) && IS_ATOM_INT(_31026)) {
        _31027 = (_31025 == _31026);
    }
    else {
        _31027 = binary_op(EQUALS, _31025, _31026);
    }
    _31025 = NOVALUE;
    _31026 = NOVALUE;
    if (IS_ATOM_INT(_31027)) {
        if (_31027 == 0) {
            goto L1; // [45] 69
        }
    }
    else {
        if (DBL_PTR(_31027)->dbl == 0.0) {
            goto L1; // [45] 69
        }
    }
    _2 = (int)SEQ_PTR(_fr_61998);
    _31029 = (int)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_31029)) {
        _31030 = (_31029 == _35TopLevelSub_16251);
    }
    else {
        _31030 = binary_op(EQUALS, _31029, _35TopLevelSub_16251);
    }
    _31029 = NOVALUE;
    if (_31030 == 0) {
        DeRef(_31030);
        _31030 = NOVALUE;
        goto L1; // [60] 69
    }
    else {
        if (!IS_ATOM_INT(_31030) && DBL_PTR(_31030)->dbl == 0.0){
            DeRef(_31030);
            _31030 = NOVALUE;
            goto L1; // [60] 69
        }
        DeRef(_31030);
        _31030 = NOVALUE;
    }
    DeRef(_31030);
    _31030 = NOVALUE;

    /** 		return*/
    DeRef(_tok_61996);
    DeRef(_fr_61998);
    DeRef(_31027);
    _31027 = NOVALUE;
    return;
L1: 

    /** 	if fr[FR_OP] = ASSIGN and SymTab[sym][S_MODE] = M_CONSTANT then*/
    _2 = (int)SEQ_PTR(_fr_61998);
    _31031 = (int)*(((s1_ptr)_2)->base + 10);
    if (IS_ATOM_INT(_31031)) {
        _31032 = (_31031 == 18);
    }
    else {
        _31032 = binary_op(EQUALS, _31031, 18);
    }
    _31031 = NOVALUE;
    if (IS_ATOM_INT(_31032)) {
        if (_31032 == 0) {
            goto L2; // [81] 120
        }
    }
    else {
        if (DBL_PTR(_31032)->dbl == 0.0) {
            goto L2; // [81] 120
        }
    }
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _31034 = (int)*(((s1_ptr)_2)->base + _sym_62001);
    _2 = (int)SEQ_PTR(_31034);
    _31035 = (int)*(((s1_ptr)_2)->base + 3);
    _31034 = NOVALUE;
    if (IS_ATOM_INT(_31035)) {
        _31036 = (_31035 == 2);
    }
    else {
        _31036 = binary_op(EQUALS, _31035, 2);
    }
    _31035 = NOVALUE;
    if (_31036 == 0) {
        DeRef(_31036);
        _31036 = NOVALUE;
        goto L2; // [104] 120
    }
    else {
        if (!IS_ATOM_INT(_31036) && DBL_PTR(_31036)->dbl == 0.0){
            DeRef(_31036);
            _31036 = NOVALUE;
            goto L2; // [104] 120
        }
        DeRef(_31036);
        _31036 = NOVALUE;
    }
    DeRef(_31036);
    _31036 = NOVALUE;

    /** 		prep_forward_error( ref )*/
    _38prep_forward_error(_ref_61997);

    /** 		CompileErr( 110 )*/
    RefDS(_22023);
    _44CompileErr(110, _22023, 0);
L2: 

    /** 	if fr[FR_OP] = ASSIGN then*/
    _2 = (int)SEQ_PTR(_fr_61998);
    _31037 = (int)*(((s1_ptr)_2)->base + 10);
    if (binary_op_a(NOTEQ, _31037, 18)){
        _31037 = NOVALUE;
        goto L3; // [128] 168
    }
    _31037 = NOVALUE;

    /** 		SymTab[sym][S_USAGE] = or_bits( U_WRITTEN, SymTab[sym][S_USAGE] )*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_62001 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _31041 = (int)*(((s1_ptr)_2)->base + _sym_62001);
    _2 = (int)SEQ_PTR(_31041);
    _31042 = (int)*(((s1_ptr)_2)->base + 5);
    _31041 = NOVALUE;
    if (IS_ATOM_INT(_31042)) {
        {unsigned long tu;
             tu = (unsigned long)2 | (unsigned long)_31042;
             _31043 = MAKE_UINT(tu);
        }
    }
    else {
        _31043 = binary_op(OR_BITS, 2, _31042);
    }
    _31042 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = _31043;
    if( _1 != _31043 ){
        DeRef(_1);
    }
    _31043 = NOVALUE;
    _31039 = NOVALUE;
    goto L4; // [165] 202
L3: 

    /** 		SymTab[sym][S_USAGE] = or_bits( U_READ, SymTab[sym][S_USAGE] )*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_62001 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _31046 = (int)*(((s1_ptr)_2)->base + _sym_62001);
    _2 = (int)SEQ_PTR(_31046);
    _31047 = (int)*(((s1_ptr)_2)->base + 5);
    _31046 = NOVALUE;
    if (IS_ATOM_INT(_31047)) {
        {unsigned long tu;
             tu = (unsigned long)1 | (unsigned long)_31047;
             _31048 = MAKE_UINT(tu);
        }
    }
    else {
        _31048 = binary_op(OR_BITS, 1, _31047);
    }
    _31047 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = _31048;
    if( _1 != _31048 ){
        DeRef(_1);
    }
    _31048 = NOVALUE;
    _31044 = NOVALUE;
L4: 

    /** 	set_code( ref )*/
    _38set_code(_ref_61997);

    /** 	integer pc = fr[FR_PC]*/
    _2 = (int)SEQ_PTR(_fr_61998);
    _pc_62053 = (int)*(((s1_ptr)_2)->base + 5);
    if (!IS_ATOM_INT(_pc_62053))
    _pc_62053 = (long)DBL_PTR(_pc_62053)->dbl;

    /** 	if pc < 1 then*/
    if (_pc_62053 >= 1)
    goto L5; // [215] 225

    /** 		pc = 1*/
    _pc_62053 = 1;
L5: 

    /** 	integer vx = find( -ref, Code, pc )*/
    if ((unsigned long)_ref_61997 == 0xC0000000)
    _31051 = (int)NewDouble((double)-0xC0000000);
    else
    _31051 = - _ref_61997;
    _vx_62057 = find_from(_31051, _35Code_16332, _pc_62053);
    DeRef(_31051);
    _31051 = NOVALUE;

    /** 	if vx then*/
    if (_vx_62057 == 0)
    {
        goto L6; // [239] 281
    }
    else{
    }

    /** 		while vx do*/
L7: 
    if (_vx_62057 == 0)
    {
        goto L8; // [247] 275
    }
    else{
    }

    /** 			Code[vx] = sym*/
    _2 = (int)SEQ_PTR(_35Code_16332);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _35Code_16332 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _vx_62057);
    _1 = *(int *)_2;
    *(int *)_2 = _sym_62001;
    DeRef(_1);

    /** 			vx = find( -ref, Code, vx )*/
    if ((unsigned long)_ref_61997 == 0xC0000000)
    _31053 = (int)NewDouble((double)-0xC0000000);
    else
    _31053 = - _ref_61997;
    _vx_62057 = find_from(_31053, _35Code_16332, _vx_62057);
    DeRef(_31053);
    _31053 = NOVALUE;

    /** 		end while*/
    goto L7; // [272] 247
L8: 

    /** 		resolved_reference( ref )*/
    _38resolved_reference(_ref_61997);
L6: 

    /** 	if sequence( fr[FR_DATA] ) then*/
    _2 = (int)SEQ_PTR(_fr_61998);
    _31055 = (int)*(((s1_ptr)_2)->base + 12);
    _31056 = IS_SEQUENCE(_31055);
    _31055 = NOVALUE;
    if (_31056 == 0)
    {
        _31056 = NOVALUE;
        goto L9; // [290] 422
    }
    else{
        _31056 = NOVALUE;
    }

    /** 		for i = 1 to length( fr[FR_DATA] ) do*/
    _2 = (int)SEQ_PTR(_fr_61998);
    _31057 = (int)*(((s1_ptr)_2)->base + 12);
    if (IS_SEQUENCE(_31057)){
            _31058 = SEQ_PTR(_31057)->length;
    }
    else {
        _31058 = 1;
    }
    _31057 = NOVALUE;
    {
        int _i_62071;
        _i_62071 = 1;
LA: 
        if (_i_62071 > _31058){
            goto LB; // [302] 416
        }

        /** 			object d = fr[FR_DATA][i]*/
        _2 = (int)SEQ_PTR(_fr_61998);
        _31059 = (int)*(((s1_ptr)_2)->base + 12);
        DeRef(_d_62074);
        _2 = (int)SEQ_PTR(_31059);
        _d_62074 = (int)*(((s1_ptr)_2)->base + _i_62071);
        Ref(_d_62074);
        _31059 = NOVALUE;

        /** 			if sequence( d ) and d[1] = PAM_RECORD then*/
        _31061 = IS_SEQUENCE(_d_62074);
        if (_31061 == 0) {
            goto LC; // [324] 405
        }
        _2 = (int)SEQ_PTR(_d_62074);
        _31063 = (int)*(((s1_ptr)_2)->base + 1);
        if (IS_ATOM_INT(_31063)) {
            _31064 = (_31063 == 1);
        }
        else {
            _31064 = binary_op(EQUALS, _31063, 1);
        }
        _31063 = NOVALUE;
        if (_31064 == 0) {
            DeRef(_31064);
            _31064 = NOVALUE;
            goto LC; // [339] 405
        }
        else {
            if (!IS_ATOM_INT(_31064) && DBL_PTR(_31064)->dbl == 0.0){
                DeRef(_31064);
                _31064 = NOVALUE;
                goto LC; // [339] 405
            }
            DeRef(_31064);
            _31064 = NOVALUE;
        }
        DeRef(_31064);
        _31064 = NOVALUE;

        /** 				symtab_index param = d[2]*/
        _2 = (int)SEQ_PTR(_d_62074);
        _param_62084 = (int)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_param_62084)){
            _param_62084 = (long)DBL_PTR(_param_62084)->dbl;
        }

        /** 				token old = {RECORDED, d[3]}*/
        _2 = (int)SEQ_PTR(_d_62074);
        _31066 = (int)*(((s1_ptr)_2)->base + 3);
        Ref(_31066);
        DeRef(_old_62087);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = 508;
        ((int *)_2)[2] = _31066;
        _old_62087 = MAKE_SEQ(_1);
        _31066 = NOVALUE;

        /** 				token new = {VARIABLE, sym}*/
        DeRefi(_new_62092);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = -100;
        ((int *)_2)[2] = _sym_62001;
        _new_62092 = MAKE_SEQ(_1);

        /** 				SymTab[param][S_CODE] = find_replace( old, SymTab[param][S_CODE], new )*/
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _36SymTab_15242 = MAKE_SEQ(_2);
        }
        _3 = (int)(_param_62084 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _31071 = (int)*(((s1_ptr)_2)->base + _param_62084);
        _2 = (int)SEQ_PTR(_31071);
        if (!IS_ATOM_INT(_35S_CODE_15929)){
            _31072 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_CODE_15929)->dbl));
        }
        else{
            _31072 = (int)*(((s1_ptr)_2)->base + _35S_CODE_15929);
        }
        _31071 = NOVALUE;
        RefDS(_old_62087);
        Ref(_31072);
        RefDS(_new_62092);
        _31073 = _16find_replace(_old_62087, _31072, _new_62092, 0);
        _31072 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_35S_CODE_15929))
        _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_CODE_15929)->dbl));
        else
        _2 = (int)(((s1_ptr)_2)->base + _35S_CODE_15929);
        _1 = *(int *)_2;
        *(int *)_2 = _31073;
        if( _1 != _31073 ){
            DeRef(_1);
        }
        _31073 = NOVALUE;
        _31069 = NOVALUE;
LC: 
        DeRef(_old_62087);
        _old_62087 = NOVALUE;
        DeRefi(_new_62092);
        _new_62092 = NOVALUE;
        DeRef(_d_62074);
        _d_62074 = NOVALUE;

        /** 		end for*/
        _i_62071 = _i_62071 + 1;
        goto LA; // [411] 309
LB: 
        ;
    }

    /** 		resolved_reference( ref )*/
    _38resolved_reference(_ref_61997);
L9: 

    /** 	reset_code()*/
    _38reset_code();

    /** end procedure*/
    DeRef(_tok_61996);
    DeRef(_fr_61998);
    _31057 = NOVALUE;
    DeRef(_31032);
    _31032 = NOVALUE;
    DeRef(_31027);
    _31027 = NOVALUE;
    return;
    ;
}


void _38patch_forward_init_check(int _tok_62108, int _ref_62109)
{
    int _fr_62110 = NOVALUE;
    int _31081 = NOVALUE;
    int _31080 = NOVALUE;
    int _31079 = NOVALUE;
    int _31077 = NOVALUE;
    int _31076 = NOVALUE;
    int _31075 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence fr = forward_references[ref]*/
    DeRef(_fr_62110);
    _2 = (int)SEQ_PTR(_38forward_references_61501);
    _fr_62110 = (int)*(((s1_ptr)_2)->base + _ref_62109);
    Ref(_fr_62110);

    /** 	set_code( ref )*/
    _38set_code(_ref_62109);

    /** 	if sequence( fr[FR_DATA] ) then*/
    _2 = (int)SEQ_PTR(_fr_62110);
    _31075 = (int)*(((s1_ptr)_2)->base + 12);
    _31076 = IS_SEQUENCE(_31075);
    _31075 = NOVALUE;
    if (_31076 == 0)
    {
        _31076 = NOVALUE;
        goto L1; // [27] 38
    }
    else{
        _31076 = NOVALUE;
    }

    /** 		resolved_reference( ref )*/
    _38resolved_reference(_ref_62109);
    goto L2; // [35] 85
L1: 

    /** 	elsif fr[FR_PC] > 0 then*/
    _2 = (int)SEQ_PTR(_fr_62110);
    _31077 = (int)*(((s1_ptr)_2)->base + 5);
    if (binary_op_a(LESSEQ, _31077, 0)){
        _31077 = NOVALUE;
        goto L3; // [44] 78
    }
    _31077 = NOVALUE;

    /** 		Code[fr[FR_PC]+1] = tok[T_SYM]*/
    _2 = (int)SEQ_PTR(_fr_62110);
    _31079 = (int)*(((s1_ptr)_2)->base + 5);
    if (IS_ATOM_INT(_31079)) {
        _31080 = _31079 + 1;
        if (_31080 > MAXINT){
            _31080 = NewDouble((double)_31080);
        }
    }
    else
    _31080 = binary_op(PLUS, 1, _31079);
    _31079 = NOVALUE;
    _2 = (int)SEQ_PTR(_tok_62108);
    _31081 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_31081);
    _2 = (int)SEQ_PTR(_35Code_16332);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _35Code_16332 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_31080))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_31080)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _31080);
    _1 = *(int *)_2;
    *(int *)_2 = _31081;
    if( _1 != _31081 ){
        DeRef(_1);
    }
    _31081 = NOVALUE;

    /** 		resolved_reference( ref )*/
    _38resolved_reference(_ref_62109);
    goto L2; // [75] 85
L3: 

    /** 		forward_error( tok, ref )*/
    Ref(_tok_62108);
    _38forward_error(_tok_62108, _ref_62109);
L2: 

    /** 	reset_code()*/
    _38reset_code();

    /** end procedure*/
    DeRef(_tok_62108);
    DeRef(_fr_62110);
    DeRef(_31080);
    _31080 = NOVALUE;
    return;
    ;
}


int _38expected_name(int _id_62127)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id_62127)) {
        _1 = (long)(DBL_PTR(_id_62127)->dbl);
        DeRefDS(_id_62127);
        _id_62127 = _1;
    }

    /** 	switch id with fallthru do*/
    _0 = _id_62127;
    switch ( _0 ){ 

        /** 		case PROC then*/
        case 27:
        case 195:

        /** 			return "a procedure"*/
        RefDS(_26382);
        return _26382;

        /** 		case FUNC then*/
        case 501:
        case 196:

        /** 			return "a function"*/
        RefDS(_26328);
        return _26328;

        /** 		case VARIABLE then*/
        case -100:

        /** 			return "a variable, constant or enum"*/
        RefDS(_31084);
        return _31084;

        /** 		case else*/
        default:

        /** 			return "something"*/
        RefDS(_31085);
        return _31085;
    ;}    ;
}


void _38patch_forward_type(int _tok_62144, int _ref_62145)
{
    int _fr_62146 = NOVALUE;
    int _syms_62148 = NOVALUE;
    int _31097 = NOVALUE;
    int _31096 = NOVALUE;
    int _31094 = NOVALUE;
    int _31093 = NOVALUE;
    int _31092 = NOVALUE;
    int _31090 = NOVALUE;
    int _31089 = NOVALUE;
    int _31088 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	sequence fr = forward_references[ref]*/
    DeRef(_fr_62146);
    _2 = (int)SEQ_PTR(_38forward_references_61501);
    _fr_62146 = (int)*(((s1_ptr)_2)->base + _ref_62145);
    Ref(_fr_62146);

    /** 	sequence syms = fr[FR_DATA]*/
    DeRef(_syms_62148);
    _2 = (int)SEQ_PTR(_fr_62146);
    _syms_62148 = (int)*(((s1_ptr)_2)->base + 12);
    Ref(_syms_62148);

    /** 	for i = 2 to length( syms ) do*/
    if (IS_SEQUENCE(_syms_62148)){
            _31088 = SEQ_PTR(_syms_62148)->length;
    }
    else {
        _31088 = 1;
    }
    {
        int _i_62151;
        _i_62151 = 2;
L1: 
        if (_i_62151 > _31088){
            goto L2; // [26] 102
        }

        /** 		SymTab[syms[i]][S_VTYPE] = tok[T_SYM]*/
        _2 = (int)SEQ_PTR(_syms_62148);
        _31089 = (int)*(((s1_ptr)_2)->base + _i_62151);
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _36SymTab_15242 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_31089))
        _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_31089)->dbl));
        else
        _3 = (int)(_31089 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(_tok_62144);
        _31092 = (int)*(((s1_ptr)_2)->base + 2);
        Ref(_31092);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 15);
        _1 = *(int *)_2;
        *(int *)_2 = _31092;
        if( _1 != _31092 ){
            DeRef(_1);
        }
        _31092 = NOVALUE;
        _31090 = NOVALUE;

        /** 		if TRANSLATE then*/
        if (_35TRANSLATE_15887 == 0)
        {
            goto L3; // [62] 95
        }
        else{
        }

        /** 			SymTab[syms[i]][S_GTYPE] = CompileType(tok[T_SYM])*/
        _2 = (int)SEQ_PTR(_syms_62148);
        _31093 = (int)*(((s1_ptr)_2)->base + _i_62151);
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _36SymTab_15242 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_31093))
        _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_31093)->dbl));
        else
        _3 = (int)(_31093 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(_tok_62144);
        _31096 = (int)*(((s1_ptr)_2)->base + 2);
        Ref(_31096);
        _31097 = _39CompileType(_31096);
        _31096 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 36);
        _1 = *(int *)_2;
        *(int *)_2 = _31097;
        if( _1 != _31097 ){
            DeRef(_1);
        }
        _31097 = NOVALUE;
        _31094 = NOVALUE;
L3: 

        /** 	end for*/
        _i_62151 = _i_62151 + 1;
        goto L1; // [97] 33
L2: 
        ;
    }

    /** 	resolved_reference( ref )*/
    _38resolved_reference(_ref_62145);

    /** end procedure*/
    DeRef(_tok_62144);
    DeRef(_fr_62146);
    DeRef(_syms_62148);
    _31089 = NOVALUE;
    _31093 = NOVALUE;
    return;
    ;
}


void _38patch_forward_case(int _tok_62174, int _ref_62175)
{
    int _fr_62176 = NOVALUE;
    int _switch_pc_62178 = NOVALUE;
    int _case_sym_62181 = NOVALUE;
    int _case_values_62210 = NOVALUE;
    int _cx_62215 = NOVALUE;
    int _negative_62223 = NOVALUE;
    int _31135 = NOVALUE;
    int _31134 = NOVALUE;
    int _31133 = NOVALUE;
    int _31132 = NOVALUE;
    int _31131 = NOVALUE;
    int _31130 = NOVALUE;
    int _31128 = NOVALUE;
    int _31126 = NOVALUE;
    int _31125 = NOVALUE;
    int _31123 = NOVALUE;
    int _31122 = NOVALUE;
    int _31119 = NOVALUE;
    int _31117 = NOVALUE;
    int _31116 = NOVALUE;
    int _31115 = NOVALUE;
    int _31114 = NOVALUE;
    int _31113 = NOVALUE;
    int _31112 = NOVALUE;
    int _31111 = NOVALUE;
    int _31110 = NOVALUE;
    int _31109 = NOVALUE;
    int _31107 = NOVALUE;
    int _31106 = NOVALUE;
    int _31105 = NOVALUE;
    int _31104 = NOVALUE;
    int _31102 = NOVALUE;
    int _31100 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	sequence fr = forward_references[ref]*/
    DeRef(_fr_62176);
    _2 = (int)SEQ_PTR(_38forward_references_61501);
    _fr_62176 = (int)*(((s1_ptr)_2)->base + _ref_62175);
    Ref(_fr_62176);

    /** 	integer switch_pc = fr[FR_DATA]*/
    _2 = (int)SEQ_PTR(_fr_62176);
    _switch_pc_62178 = (int)*(((s1_ptr)_2)->base + 12);
    if (!IS_ATOM_INT(_switch_pc_62178))
    _switch_pc_62178 = (long)DBL_PTR(_switch_pc_62178)->dbl;

    /** 	if fr[FR_SUBPROG] = TopLevelSub then*/
    _2 = (int)SEQ_PTR(_fr_62176);
    _31100 = (int)*(((s1_ptr)_2)->base + 4);
    if (binary_op_a(NOTEQ, _31100, _35TopLevelSub_16251)){
        _31100 = NOVALUE;
        goto L1; // [27] 48
    }
    _31100 = NOVALUE;

    /** 		case_sym = Code[switch_pc + 2]*/
    _31102 = _switch_pc_62178 + 2;
    _2 = (int)SEQ_PTR(_35Code_16332);
    _case_sym_62181 = (int)*(((s1_ptr)_2)->base + _31102);
    if (!IS_ATOM_INT(_case_sym_62181)){
        _case_sym_62181 = (long)DBL_PTR(_case_sym_62181)->dbl;
    }
    goto L2; // [45] 77
L1: 

    /** 		case_sym = SymTab[fr[FR_SUBPROG]][S_CODE][switch_pc + 2]*/
    _2 = (int)SEQ_PTR(_fr_62176);
    _31104 = (int)*(((s1_ptr)_2)->base + 4);
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!IS_ATOM_INT(_31104)){
        _31105 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_31104)->dbl));
    }
    else{
        _31105 = (int)*(((s1_ptr)_2)->base + _31104);
    }
    _2 = (int)SEQ_PTR(_31105);
    if (!IS_ATOM_INT(_35S_CODE_15929)){
        _31106 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_CODE_15929)->dbl));
    }
    else{
        _31106 = (int)*(((s1_ptr)_2)->base + _35S_CODE_15929);
    }
    _31105 = NOVALUE;
    _31107 = _switch_pc_62178 + 2;
    _2 = (int)SEQ_PTR(_31106);
    _case_sym_62181 = (int)*(((s1_ptr)_2)->base + _31107);
    if (!IS_ATOM_INT(_case_sym_62181)){
        _case_sym_62181 = (long)DBL_PTR(_case_sym_62181)->dbl;
    }
    _31106 = NOVALUE;
L2: 

    /** 	if SymTab[tok[T_SYM]][S_FILE_NO] = fr[FR_FILE] and fr[FR_SUBPROG] = TopLevelSub then*/
    _2 = (int)SEQ_PTR(_tok_62174);
    _31109 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!IS_ATOM_INT(_31109)){
        _31110 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_31109)->dbl));
    }
    else{
        _31110 = (int)*(((s1_ptr)_2)->base + _31109);
    }
    _2 = (int)SEQ_PTR(_31110);
    if (!IS_ATOM_INT(_35S_FILE_NO_15913)){
        _31111 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FILE_NO_15913)->dbl));
    }
    else{
        _31111 = (int)*(((s1_ptr)_2)->base + _35S_FILE_NO_15913);
    }
    _31110 = NOVALUE;
    _2 = (int)SEQ_PTR(_fr_62176);
    _31112 = (int)*(((s1_ptr)_2)->base + 3);
    if (IS_ATOM_INT(_31111) && IS_ATOM_INT(_31112)) {
        _31113 = (_31111 == _31112);
    }
    else {
        _31113 = binary_op(EQUALS, _31111, _31112);
    }
    _31111 = NOVALUE;
    _31112 = NOVALUE;
    if (IS_ATOM_INT(_31113)) {
        if (_31113 == 0) {
            goto L3; // [105] 129
        }
    }
    else {
        if (DBL_PTR(_31113)->dbl == 0.0) {
            goto L3; // [105] 129
        }
    }
    _2 = (int)SEQ_PTR(_fr_62176);
    _31115 = (int)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_31115)) {
        _31116 = (_31115 == _35TopLevelSub_16251);
    }
    else {
        _31116 = binary_op(EQUALS, _31115, _35TopLevelSub_16251);
    }
    _31115 = NOVALUE;
    if (_31116 == 0) {
        DeRef(_31116);
        _31116 = NOVALUE;
        goto L3; // [120] 129
    }
    else {
        if (!IS_ATOM_INT(_31116) && DBL_PTR(_31116)->dbl == 0.0){
            DeRef(_31116);
            _31116 = NOVALUE;
            goto L3; // [120] 129
        }
        DeRef(_31116);
        _31116 = NOVALUE;
    }
    DeRef(_31116);
    _31116 = NOVALUE;

    /** 		return*/
    DeRef(_tok_62174);
    DeRef(_fr_62176);
    DeRef(_case_values_62210);
    DeRef(_31102);
    _31102 = NOVALUE;
    _31104 = NOVALUE;
    _31109 = NOVALUE;
    DeRef(_31107);
    _31107 = NOVALUE;
    DeRef(_31113);
    _31113 = NOVALUE;
    return;
L3: 

    /** 	sequence case_values = SymTab[case_sym][S_OBJ]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _31117 = (int)*(((s1_ptr)_2)->base + _case_sym_62181);
    DeRef(_case_values_62210);
    _2 = (int)SEQ_PTR(_31117);
    _case_values_62210 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_case_values_62210);
    _31117 = NOVALUE;

    /** 	integer cx = find( { ref }, case_values )*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _ref_62175;
    _31119 = MAKE_SEQ(_1);
    _cx_62215 = find_from(_31119, _case_values_62210, 1);
    DeRefDS(_31119);
    _31119 = NOVALUE;

    /** 	if not cx then*/
    if (_cx_62215 != 0)
    goto L4; // [160] 178

    /** 		cx = find( { -ref }, case_values )*/
    if ((unsigned long)_ref_62175 == 0xC0000000)
    _31122 = (int)NewDouble((double)-0xC0000000);
    else
    _31122 = - _ref_62175;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _31122;
    _31123 = MAKE_SEQ(_1);
    _31122 = NOVALUE;
    _cx_62215 = find_from(_31123, _case_values_62210, 1);
    DeRefDS(_31123);
    _31123 = NOVALUE;
L4: 

    /**  	ifdef DEBUG then	*/

    /** 	integer negative = 0*/
    _negative_62223 = 0;

    /** 	if case_values[cx][1] < 0 then*/
    _2 = (int)SEQ_PTR(_case_values_62210);
    _31125 = (int)*(((s1_ptr)_2)->base + _cx_62215);
    _2 = (int)SEQ_PTR(_31125);
    _31126 = (int)*(((s1_ptr)_2)->base + 1);
    _31125 = NOVALUE;
    if (binary_op_a(GREATEREQ, _31126, 0)){
        _31126 = NOVALUE;
        goto L5; // [195] 224
    }
    _31126 = NOVALUE;

    /** 		negative = 1*/
    _negative_62223 = 1;

    /** 		case_values[cx][1] *= -1*/
    _2 = (int)SEQ_PTR(_case_values_62210);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _case_values_62210 = MAKE_SEQ(_2);
    }
    _3 = (int)(_cx_62215 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    _31130 = (int)*(((s1_ptr)_2)->base + 1);
    _31128 = NOVALUE;
    if (IS_ATOM_INT(_31130)) {
        if (_31130 == (short)_31130)
        _31131 = _31130 * -1;
        else
        _31131 = NewDouble(_31130 * (double)-1);
    }
    else {
        _31131 = binary_op(MULTIPLY, _31130, -1);
    }
    _31130 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _31131;
    if( _1 != _31131 ){
        DeRef(_1);
    }
    _31131 = NOVALUE;
    _31128 = NOVALUE;
L5: 

    /** 	if negative then*/
    if (_negative_62223 == 0)
    {
        goto L6; // [226] 247
    }
    else{
    }

    /** 		case_values[cx] = - tok[T_SYM]*/
    _2 = (int)SEQ_PTR(_tok_62174);
    _31132 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_31132)) {
        if ((unsigned long)_31132 == 0xC0000000)
        _31133 = (int)NewDouble((double)-0xC0000000);
        else
        _31133 = - _31132;
    }
    else {
        _31133 = unary_op(UMINUS, _31132);
    }
    _31132 = NOVALUE;
    _2 = (int)SEQ_PTR(_case_values_62210);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _case_values_62210 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _cx_62215);
    _1 = *(int *)_2;
    *(int *)_2 = _31133;
    if( _1 != _31133 ){
        DeRef(_1);
    }
    _31133 = NOVALUE;
    goto L7; // [244] 260
L6: 

    /** 		case_values[cx] = tok[T_SYM]*/
    _2 = (int)SEQ_PTR(_tok_62174);
    _31134 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_31134);
    _2 = (int)SEQ_PTR(_case_values_62210);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _case_values_62210 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _cx_62215);
    _1 = *(int *)_2;
    *(int *)_2 = _31134;
    if( _1 != _31134 ){
        DeRef(_1);
    }
    _31134 = NOVALUE;
L7: 

    /** 	SymTab[case_sym][S_OBJ] = case_values*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_case_sym_62181 + ((s1_ptr)_2)->base);
    RefDS(_case_values_62210);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _case_values_62210;
    DeRef(_1);
    _31135 = NOVALUE;

    /** 	resolved_reference( ref )*/
    _38resolved_reference(_ref_62175);

    /** end procedure*/
    DeRef(_tok_62174);
    DeRef(_fr_62176);
    DeRefDS(_case_values_62210);
    DeRef(_31102);
    _31102 = NOVALUE;
    _31104 = NOVALUE;
    _31109 = NOVALUE;
    DeRef(_31107);
    _31107 = NOVALUE;
    DeRef(_31113);
    _31113 = NOVALUE;
    return;
    ;
}


void _38patch_forward_type_check(int _tok_62246, int _ref_62247)
{
    int _fr_62248 = NOVALUE;
    int _which_type_62251 = NOVALUE;
    int _var_62253 = NOVALUE;
    int _pc_62286 = NOVALUE;
    int _with_type_check_62288 = NOVALUE;
    int _c_62318 = NOVALUE;
    int _subprog_inlined_insert_code_at_332_62327 = NOVALUE;
    int _code_inlined_insert_code_at_329_62326 = NOVALUE;
    int _subprog_inlined_insert_code_at_415_62343 = NOVALUE;
    int _code_inlined_insert_code_at_412_62342 = NOVALUE;
    int _subprog_inlined_insert_code_at_477_62353 = NOVALUE;
    int _code_inlined_insert_code_at_474_62352 = NOVALUE;
    int _subprog_inlined_insert_code_at_539_62363 = NOVALUE;
    int _code_inlined_insert_code_at_536_62362 = NOVALUE;
    int _start_pc_62370 = NOVALUE;
    int _subprog_inlined_insert_code_at_647_62387 = NOVALUE;
    int _code_inlined_insert_code_at_644_62386 = NOVALUE;
    int _c_62390 = NOVALUE;
    int _subprog_inlined_insert_code_at_741_62406 = NOVALUE;
    int _code_inlined_insert_code_at_738_62405 = NOVALUE;
    int _start_pc_62417 = NOVALUE;
    int _subprog_inlined_insert_code_at_886_62437 = NOVALUE;
    int _code_inlined_insert_code_at_883_62436 = NOVALUE;
    int _subprog_inlined_insert_code_at_987_62458 = NOVALUE;
    int _code_inlined_insert_code_at_984_62457 = NOVALUE;
    int _31225 = NOVALUE;
    int _31224 = NOVALUE;
    int _31223 = NOVALUE;
    int _31222 = NOVALUE;
    int _31221 = NOVALUE;
    int _31220 = NOVALUE;
    int _31219 = NOVALUE;
    int _31217 = NOVALUE;
    int _31215 = NOVALUE;
    int _31214 = NOVALUE;
    int _31213 = NOVALUE;
    int _31212 = NOVALUE;
    int _31211 = NOVALUE;
    int _31210 = NOVALUE;
    int _31209 = NOVALUE;
    int _31207 = NOVALUE;
    int _31206 = NOVALUE;
    int _31205 = NOVALUE;
    int _31204 = NOVALUE;
    int _31203 = NOVALUE;
    int _31202 = NOVALUE;
    int _31200 = NOVALUE;
    int _31199 = NOVALUE;
    int _31198 = NOVALUE;
    int _31197 = NOVALUE;
    int _31195 = NOVALUE;
    int _31194 = NOVALUE;
    int _31191 = NOVALUE;
    int _31190 = NOVALUE;
    int _31188 = NOVALUE;
    int _31187 = NOVALUE;
    int _31186 = NOVALUE;
    int _31185 = NOVALUE;
    int _31184 = NOVALUE;
    int _31183 = NOVALUE;
    int _31181 = NOVALUE;
    int _31180 = NOVALUE;
    int _31177 = NOVALUE;
    int _31176 = NOVALUE;
    int _31173 = NOVALUE;
    int _31172 = NOVALUE;
    int _31168 = NOVALUE;
    int _31167 = NOVALUE;
    int _31165 = NOVALUE;
    int _31164 = NOVALUE;
    int _31162 = NOVALUE;
    int _31161 = NOVALUE;
    int _31158 = NOVALUE;
    int _31155 = NOVALUE;
    int _31153 = NOVALUE;
    int _31150 = NOVALUE;
    int _31149 = NOVALUE;
    int _31146 = NOVALUE;
    int _31141 = NOVALUE;
    int _31140 = NOVALUE;
    int _31138 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	sequence fr = forward_references[ref]*/
    DeRef(_fr_62248);
    _2 = (int)SEQ_PTR(_38forward_references_61501);
    _fr_62248 = (int)*(((s1_ptr)_2)->base + _ref_62247);
    Ref(_fr_62248);

    /** 	if fr[FR_OP] = TYPE_CHECK_FORWARD then*/
    _2 = (int)SEQ_PTR(_fr_62248);
    _31138 = (int)*(((s1_ptr)_2)->base + 10);
    if (binary_op_a(NOTEQ, _31138, 197)){
        _31138 = NOVALUE;
        goto L1; // [21] 86
    }
    _31138 = NOVALUE;

    /** 		which_type = SymTab[tok[T_SYM]][S_VTYPE]*/
    _2 = (int)SEQ_PTR(_tok_62246);
    _31140 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!IS_ATOM_INT(_31140)){
        _31141 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_31140)->dbl));
    }
    else{
        _31141 = (int)*(((s1_ptr)_2)->base + _31140);
    }
    _2 = (int)SEQ_PTR(_31141);
    _which_type_62251 = (int)*(((s1_ptr)_2)->base + 15);
    if (!IS_ATOM_INT(_which_type_62251)){
        _which_type_62251 = (long)DBL_PTR(_which_type_62251)->dbl;
    }
    _31141 = NOVALUE;

    /** 		if not which_type then*/
    if (_which_type_62251 != 0)
    goto L2; // [49] 72

    /** 			which_type = tok[T_SYM]*/
    _2 = (int)SEQ_PTR(_tok_62246);
    _which_type_62251 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_which_type_62251)){
        _which_type_62251 = (long)DBL_PTR(_which_type_62251)->dbl;
    }

    /** 			var = 0*/
    _var_62253 = 0;
    goto L3; // [69] 144
L2: 

    /** 			var = tok[T_SYM]*/
    _2 = (int)SEQ_PTR(_tok_62246);
    _var_62253 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_var_62253)){
        _var_62253 = (long)DBL_PTR(_var_62253)->dbl;
    }
    goto L3; // [83] 144
L1: 

    /** 	elsif fr[FR_OP] = TYPE then*/
    _2 = (int)SEQ_PTR(_fr_62248);
    _31146 = (int)*(((s1_ptr)_2)->base + 10);
    if (binary_op_a(NOTEQ, _31146, 504)){
        _31146 = NOVALUE;
        goto L4; // [94] 118
    }
    _31146 = NOVALUE;

    /** 		which_type = tok[T_SYM]*/
    _2 = (int)SEQ_PTR(_tok_62246);
    _which_type_62251 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_which_type_62251)){
        _which_type_62251 = (long)DBL_PTR(_which_type_62251)->dbl;
    }

    /** 		var = 0*/
    _var_62253 = 0;
    goto L3; // [115] 144
L4: 

    /** 		prep_forward_error( ref )*/
    _38prep_forward_error(_ref_62247);

    /** 		InternalErr( 262, { TYPE_CHECK, TYPE_CHECK_FORWARD, fr[FR_OP] })*/
    _2 = (int)SEQ_PTR(_fr_62248);
    _31149 = (int)*(((s1_ptr)_2)->base + 10);
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 65;
    *((int *)(_2+8)) = 197;
    Ref(_31149);
    *((int *)(_2+12)) = _31149;
    _31150 = MAKE_SEQ(_1);
    _31149 = NOVALUE;
    _44InternalErr(262, _31150);
    _31150 = NOVALUE;
L3: 

    /** 	if which_type < 0 then*/
    if (_which_type_62251 >= 0)
    goto L5; // [148] 158

    /** 		return*/
    DeRef(_tok_62246);
    DeRef(_fr_62248);
    _31140 = NOVALUE;
    return;
L5: 

    /** 	set_code( ref )*/
    _38set_code(_ref_62247);

    /** 	integer pc = fr[FR_PC]*/
    _2 = (int)SEQ_PTR(_fr_62248);
    _pc_62286 = (int)*(((s1_ptr)_2)->base + 5);
    if (!IS_ATOM_INT(_pc_62286))
    _pc_62286 = (long)DBL_PTR(_pc_62286)->dbl;

    /** 	integer with_type_check = Code[pc + 2]*/
    _31153 = _pc_62286 + 2;
    _2 = (int)SEQ_PTR(_35Code_16332);
    _with_type_check_62288 = (int)*(((s1_ptr)_2)->base + _31153);
    if (!IS_ATOM_INT(_with_type_check_62288)){
        _with_type_check_62288 = (long)DBL_PTR(_with_type_check_62288)->dbl;
    }

    /** 	if Code[pc] != TYPE_CHECK_FORWARD then*/
    _2 = (int)SEQ_PTR(_35Code_16332);
    _31155 = (int)*(((s1_ptr)_2)->base + _pc_62286);
    if (binary_op_a(EQUALS, _31155, 197)){
        _31155 = NOVALUE;
        goto L6; // [193] 204
    }
    _31155 = NOVALUE;

    /** 		forward_error( tok, ref )*/
    Ref(_tok_62246);
    _38forward_error(_tok_62246, _ref_62247);
L6: 

    /** 	if not var then*/
    if (_var_62253 != 0)
    goto L7; // [208] 226

    /** 		var = Code[pc+1]*/
    _31158 = _pc_62286 + 1;
    _2 = (int)SEQ_PTR(_35Code_16332);
    _var_62253 = (int)*(((s1_ptr)_2)->base + _31158);
    if (!IS_ATOM_INT(_var_62253)){
        _var_62253 = (long)DBL_PTR(_var_62253)->dbl;
    }
L7: 

    /** 	if var < 0 then*/
    if (_var_62253 >= 0)
    goto L8; // [228] 238

    /** 		return*/
    DeRef(_tok_62246);
    DeRef(_fr_62248);
    _31140 = NOVALUE;
    DeRef(_31153);
    _31153 = NOVALUE;
    DeRef(_31158);
    _31158 = NOVALUE;
    return;
L8: 

    /** 	replace_code( {}, pc, pc + 2, fr[FR_SUBPROG])*/
    _31161 = _pc_62286 + 2;
    if ((long)((unsigned long)_31161 + (unsigned long)HIGH_BITS) >= 0) 
    _31161 = NewDouble((double)_31161);
    _2 = (int)SEQ_PTR(_fr_62248);
    _31162 = (int)*(((s1_ptr)_2)->base + 4);
    RefDS(_22023);
    Ref(_31162);
    _38replace_code(_22023, _pc_62286, _31161, _31162);
    _31161 = NOVALUE;
    _31162 = NOVALUE;

    /** 	if TRANSLATE then*/
    if (_35TRANSLATE_15887 == 0)
    {
        goto L9; // [258] 364
    }
    else{
    }

    /** 		if with_type_check then*/
    if (_with_type_check_62288 == 0)
    {
        goto LA; // [263] 771
    }
    else{
    }

    /** 			if which_type != object_type then*/
    if (_which_type_62251 == _53object_type_46091)
    goto LA; // [270] 771

    /** 				if SymTab[which_type][S_EFFECT] then*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _31164 = (int)*(((s1_ptr)_2)->base + _which_type_62251);
    _2 = (int)SEQ_PTR(_31164);
    _31165 = (int)*(((s1_ptr)_2)->base + 23);
    _31164 = NOVALUE;
    if (_31165 == 0) {
        _31165 = NOVALUE;
        goto LB; // [288] 357
    }
    else {
        if (!IS_ATOM_INT(_31165) && DBL_PTR(_31165)->dbl == 0.0){
            _31165 = NOVALUE;
            goto LB; // [288] 357
        }
        _31165 = NOVALUE;
    }
    _31165 = NOVALUE;

    /** 					integer c = NewTempSym()*/
    _c_62318 = _53NewTempSym(0);
    if (!IS_ATOM_INT(_c_62318)) {
        _1 = (long)(DBL_PTR(_c_62318)->dbl);
        DeRefDS(_c_62318);
        _c_62318 = _1;
    }

    /** 					insert_code( { PROC, which_type, var, c, TYPE_CHECK }, pc, fr[FR_SUBPROG] )*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 27;
    *((int *)(_2+8)) = _which_type_62251;
    *((int *)(_2+12)) = _var_62253;
    *((int *)(_2+16)) = _c_62318;
    *((int *)(_2+20)) = 65;
    _31167 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_fr_62248);
    _31168 = (int)*(((s1_ptr)_2)->base + 4);
    DeRefi(_code_inlined_insert_code_at_329_62326);
    _code_inlined_insert_code_at_329_62326 = _31167;
    _31167 = NOVALUE;
    Ref(_31168);
    DeRef(_subprog_inlined_insert_code_at_332_62327);
    _subprog_inlined_insert_code_at_332_62327 = _31168;
    _31168 = NOVALUE;
    if (!IS_ATOM_INT(_subprog_inlined_insert_code_at_332_62327)) {
        _1 = (long)(DBL_PTR(_subprog_inlined_insert_code_at_332_62327)->dbl);
        DeRefDS(_subprog_inlined_insert_code_at_332_62327);
        _subprog_inlined_insert_code_at_332_62327 = _1;
    }

    /** 	shifting_sub = subprog*/
    _38shifting_sub_61520 = _subprog_inlined_insert_code_at_332_62327;

    /** 	shift:insert_code( code, index )*/
    RefDS(_code_inlined_insert_code_at_329_62326);
    _65insert_code(_code_inlined_insert_code_at_329_62326, _pc_62286);

    /** 	shifting_sub = 0*/
    _38shifting_sub_61520 = 0;

    /** end procedure*/
    goto LC; // [345] 348
LC: 
    DeRefi(_code_inlined_insert_code_at_329_62326);
    _code_inlined_insert_code_at_329_62326 = NOVALUE;
    DeRef(_subprog_inlined_insert_code_at_332_62327);
    _subprog_inlined_insert_code_at_332_62327 = NOVALUE;

    /** 					pc += 5*/
    _pc_62286 = _pc_62286 + 5;
LB: 
    goto LA; // [361] 771
L9: 

    /** 		if with_type_check then*/
    if (_with_type_check_62288 == 0)
    {
        goto LD; // [366] 770
    }
    else{
    }

    /** 			if which_type = object_type then*/
    if (_which_type_62251 != _53object_type_46091)
    goto LE; // [373] 380
    goto LF; // [377] 769
LE: 

    /** 				if which_type = integer_type then*/
    if (_which_type_62251 != _53integer_type_46097)
    goto L10; // [384] 442

    /** 					insert_code( { INTEGER_CHECK, var }, pc, fr[FR_SUBPROG] )*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 96;
    ((int *)_2)[2] = _var_62253;
    _31172 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_fr_62248);
    _31173 = (int)*(((s1_ptr)_2)->base + 4);
    DeRefi(_code_inlined_insert_code_at_412_62342);
    _code_inlined_insert_code_at_412_62342 = _31172;
    _31172 = NOVALUE;
    Ref(_31173);
    DeRef(_subprog_inlined_insert_code_at_415_62343);
    _subprog_inlined_insert_code_at_415_62343 = _31173;
    _31173 = NOVALUE;
    if (!IS_ATOM_INT(_subprog_inlined_insert_code_at_415_62343)) {
        _1 = (long)(DBL_PTR(_subprog_inlined_insert_code_at_415_62343)->dbl);
        DeRefDS(_subprog_inlined_insert_code_at_415_62343);
        _subprog_inlined_insert_code_at_415_62343 = _1;
    }

    /** 	shifting_sub = subprog*/
    _38shifting_sub_61520 = _subprog_inlined_insert_code_at_415_62343;

    /** 	shift:insert_code( code, index )*/
    RefDS(_code_inlined_insert_code_at_412_62342);
    _65insert_code(_code_inlined_insert_code_at_412_62342, _pc_62286);

    /** 	shifting_sub = 0*/
    _38shifting_sub_61520 = 0;

    /** end procedure*/
    goto L11; // [428] 431
L11: 
    DeRefi(_code_inlined_insert_code_at_412_62342);
    _code_inlined_insert_code_at_412_62342 = NOVALUE;
    DeRef(_subprog_inlined_insert_code_at_415_62343);
    _subprog_inlined_insert_code_at_415_62343 = NOVALUE;

    /** 					pc += 2*/
    _pc_62286 = _pc_62286 + 2;
    goto L12; // [439] 768
L10: 

    /** 				elsif which_type = sequence_type then*/
    if (_which_type_62251 != _53sequence_type_46095)
    goto L13; // [446] 504

    /** 					insert_code( { SEQUENCE_CHECK, var }, pc, fr[FR_SUBPROG])*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 97;
    ((int *)_2)[2] = _var_62253;
    _31176 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_fr_62248);
    _31177 = (int)*(((s1_ptr)_2)->base + 4);
    DeRefi(_code_inlined_insert_code_at_474_62352);
    _code_inlined_insert_code_at_474_62352 = _31176;
    _31176 = NOVALUE;
    Ref(_31177);
    DeRef(_subprog_inlined_insert_code_at_477_62353);
    _subprog_inlined_insert_code_at_477_62353 = _31177;
    _31177 = NOVALUE;
    if (!IS_ATOM_INT(_subprog_inlined_insert_code_at_477_62353)) {
        _1 = (long)(DBL_PTR(_subprog_inlined_insert_code_at_477_62353)->dbl);
        DeRefDS(_subprog_inlined_insert_code_at_477_62353);
        _subprog_inlined_insert_code_at_477_62353 = _1;
    }

    /** 	shifting_sub = subprog*/
    _38shifting_sub_61520 = _subprog_inlined_insert_code_at_477_62353;

    /** 	shift:insert_code( code, index )*/
    RefDS(_code_inlined_insert_code_at_474_62352);
    _65insert_code(_code_inlined_insert_code_at_474_62352, _pc_62286);

    /** 	shifting_sub = 0*/
    _38shifting_sub_61520 = 0;

    /** end procedure*/
    goto L14; // [490] 493
L14: 
    DeRefi(_code_inlined_insert_code_at_474_62352);
    _code_inlined_insert_code_at_474_62352 = NOVALUE;
    DeRef(_subprog_inlined_insert_code_at_477_62353);
    _subprog_inlined_insert_code_at_477_62353 = NOVALUE;

    /** 					pc += 2*/
    _pc_62286 = _pc_62286 + 2;
    goto L12; // [501] 768
L13: 

    /** 				elsif which_type = atom_type then*/
    if (_which_type_62251 != _53atom_type_46093)
    goto L15; // [508] 566

    /** 					insert_code( { ATOM_CHECK, var }, pc, fr[FR_SUBPROG] )*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 101;
    ((int *)_2)[2] = _var_62253;
    _31180 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_fr_62248);
    _31181 = (int)*(((s1_ptr)_2)->base + 4);
    DeRefi(_code_inlined_insert_code_at_536_62362);
    _code_inlined_insert_code_at_536_62362 = _31180;
    _31180 = NOVALUE;
    Ref(_31181);
    DeRef(_subprog_inlined_insert_code_at_539_62363);
    _subprog_inlined_insert_code_at_539_62363 = _31181;
    _31181 = NOVALUE;
    if (!IS_ATOM_INT(_subprog_inlined_insert_code_at_539_62363)) {
        _1 = (long)(DBL_PTR(_subprog_inlined_insert_code_at_539_62363)->dbl);
        DeRefDS(_subprog_inlined_insert_code_at_539_62363);
        _subprog_inlined_insert_code_at_539_62363 = _1;
    }

    /** 	shifting_sub = subprog*/
    _38shifting_sub_61520 = _subprog_inlined_insert_code_at_539_62363;

    /** 	shift:insert_code( code, index )*/
    RefDS(_code_inlined_insert_code_at_536_62362);
    _65insert_code(_code_inlined_insert_code_at_536_62362, _pc_62286);

    /** 	shifting_sub = 0*/
    _38shifting_sub_61520 = 0;

    /** end procedure*/
    goto L16; // [552] 555
L16: 
    DeRefi(_code_inlined_insert_code_at_536_62362);
    _code_inlined_insert_code_at_536_62362 = NOVALUE;
    DeRef(_subprog_inlined_insert_code_at_539_62363);
    _subprog_inlined_insert_code_at_539_62363 = NOVALUE;

    /** 					pc += 2*/
    _pc_62286 = _pc_62286 + 2;
    goto L12; // [563] 768
L15: 

    /** 				elsif SymTab[which_type][S_NEXT] then*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _31183 = (int)*(((s1_ptr)_2)->base + _which_type_62251);
    _2 = (int)SEQ_PTR(_31183);
    _31184 = (int)*(((s1_ptr)_2)->base + 2);
    _31183 = NOVALUE;
    if (_31184 == 0) {
        _31184 = NOVALUE;
        goto L17; // [580] 765
    }
    else {
        if (!IS_ATOM_INT(_31184) && DBL_PTR(_31184)->dbl == 0.0){
            _31184 = NOVALUE;
            goto L17; // [580] 765
        }
        _31184 = NOVALUE;
    }
    _31184 = NOVALUE;

    /** 					integer start_pc = pc*/
    _start_pc_62370 = _pc_62286;

    /** 					if SymTab[SymTab[which_type][S_NEXT]][S_VTYPE] = integer_type then*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _31185 = (int)*(((s1_ptr)_2)->base + _which_type_62251);
    _2 = (int)SEQ_PTR(_31185);
    _31186 = (int)*(((s1_ptr)_2)->base + 2);
    _31185 = NOVALUE;
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!IS_ATOM_INT(_31186)){
        _31187 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_31186)->dbl));
    }
    else{
        _31187 = (int)*(((s1_ptr)_2)->base + _31186);
    }
    _2 = (int)SEQ_PTR(_31187);
    _31188 = (int)*(((s1_ptr)_2)->base + 15);
    _31187 = NOVALUE;
    if (binary_op_a(NOTEQ, _31188, _53integer_type_46097)){
        _31188 = NOVALUE;
        goto L18; // [616] 672
    }
    _31188 = NOVALUE;

    /** 						insert_code( { INTEGER_CHECK, var }, pc, fr[FR_SUBPROG] )*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 96;
    ((int *)_2)[2] = _var_62253;
    _31190 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_fr_62248);
    _31191 = (int)*(((s1_ptr)_2)->base + 4);
    DeRefi(_code_inlined_insert_code_at_644_62386);
    _code_inlined_insert_code_at_644_62386 = _31190;
    _31190 = NOVALUE;
    Ref(_31191);
    DeRef(_subprog_inlined_insert_code_at_647_62387);
    _subprog_inlined_insert_code_at_647_62387 = _31191;
    _31191 = NOVALUE;
    if (!IS_ATOM_INT(_subprog_inlined_insert_code_at_647_62387)) {
        _1 = (long)(DBL_PTR(_subprog_inlined_insert_code_at_647_62387)->dbl);
        DeRefDS(_subprog_inlined_insert_code_at_647_62387);
        _subprog_inlined_insert_code_at_647_62387 = _1;
    }

    /** 	shifting_sub = subprog*/
    _38shifting_sub_61520 = _subprog_inlined_insert_code_at_647_62387;

    /** 	shift:insert_code( code, index )*/
    RefDS(_code_inlined_insert_code_at_644_62386);
    _65insert_code(_code_inlined_insert_code_at_644_62386, _pc_62286);

    /** 	shifting_sub = 0*/
    _38shifting_sub_61520 = 0;

    /** end procedure*/
    goto L19; // [660] 663
L19: 
    DeRefi(_code_inlined_insert_code_at_644_62386);
    _code_inlined_insert_code_at_644_62386 = NOVALUE;
    DeRef(_subprog_inlined_insert_code_at_647_62387);
    _subprog_inlined_insert_code_at_647_62387 = NOVALUE;

    /** 						pc += 2*/
    _pc_62286 = _pc_62286 + 2;
L18: 

    /** 					symtab_index c = NewTempSym()*/
    _c_62390 = _53NewTempSym(0);
    if (!IS_ATOM_INT(_c_62390)) {
        _1 = (long)(DBL_PTR(_c_62390)->dbl);
        DeRefDS(_c_62390);
        _c_62390 = _1;
    }

    /** 					SymTab[fr[FR_SUBPROG]][S_STACK_SPACE] += 1*/
    _2 = (int)SEQ_PTR(_fr_62248);
    _31194 = (int)*(((s1_ptr)_2)->base + 4);
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_31194))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_31194)->dbl));
    else
    _3 = (int)(_31194 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!IS_ATOM_INT(_35S_STACK_SPACE_15977)){
        _31197 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_STACK_SPACE_15977)->dbl));
    }
    else{
        _31197 = (int)*(((s1_ptr)_2)->base + _35S_STACK_SPACE_15977);
    }
    _31195 = NOVALUE;
    if (IS_ATOM_INT(_31197)) {
        _31198 = _31197 + 1;
        if (_31198 > MAXINT){
            _31198 = NewDouble((double)_31198);
        }
    }
    else
    _31198 = binary_op(PLUS, 1, _31197);
    _31197 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35S_STACK_SPACE_15977))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_STACK_SPACE_15977)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _35S_STACK_SPACE_15977);
    _1 = *(int *)_2;
    *(int *)_2 = _31198;
    if( _1 != _31198 ){
        DeRef(_1);
    }
    _31198 = NOVALUE;
    _31195 = NOVALUE;

    /** 					insert_code( { PROC, which_type, var, c, TYPE_CHECK }, pc, fr[FR_SUBPROG] )*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 27;
    *((int *)(_2+8)) = _which_type_62251;
    *((int *)(_2+12)) = _var_62253;
    *((int *)(_2+16)) = _c_62390;
    *((int *)(_2+20)) = 65;
    _31199 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_fr_62248);
    _31200 = (int)*(((s1_ptr)_2)->base + 4);
    DeRefi(_code_inlined_insert_code_at_738_62405);
    _code_inlined_insert_code_at_738_62405 = _31199;
    _31199 = NOVALUE;
    Ref(_31200);
    DeRef(_subprog_inlined_insert_code_at_741_62406);
    _subprog_inlined_insert_code_at_741_62406 = _31200;
    _31200 = NOVALUE;
    if (!IS_ATOM_INT(_subprog_inlined_insert_code_at_741_62406)) {
        _1 = (long)(DBL_PTR(_subprog_inlined_insert_code_at_741_62406)->dbl);
        DeRefDS(_subprog_inlined_insert_code_at_741_62406);
        _subprog_inlined_insert_code_at_741_62406 = _1;
    }

    /** 	shifting_sub = subprog*/
    _38shifting_sub_61520 = _subprog_inlined_insert_code_at_741_62406;

    /** 	shift:insert_code( code, index )*/
    RefDS(_code_inlined_insert_code_at_738_62405);
    _65insert_code(_code_inlined_insert_code_at_738_62405, _pc_62286);

    /** 	shifting_sub = 0*/
    _38shifting_sub_61520 = 0;

    /** end procedure*/
    goto L1A; // [753] 756
L1A: 
    DeRefi(_code_inlined_insert_code_at_738_62405);
    _code_inlined_insert_code_at_738_62405 = NOVALUE;
    DeRef(_subprog_inlined_insert_code_at_741_62406);
    _subprog_inlined_insert_code_at_741_62406 = NOVALUE;

    /** 					pc += 4*/
    _pc_62286 = _pc_62286 + 4;
L17: 
L12: 
LF: 
LD: 
LA: 

    /** 	if (TRANSLATE or not with_type_check) and SymTab[which_type][S_NEXT] then*/
    if (_35TRANSLATE_15887 != 0) {
        _31202 = 1;
        goto L1B; // [775] 786
    }
    _31203 = (_with_type_check_62288 == 0);
    _31202 = (_31203 != 0);
L1B: 
    if (_31202 == 0) {
        goto L1C; // [786] 1013
    }
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _31205 = (int)*(((s1_ptr)_2)->base + _which_type_62251);
    _2 = (int)SEQ_PTR(_31205);
    _31206 = (int)*(((s1_ptr)_2)->base + 2);
    _31205 = NOVALUE;
    if (_31206 == 0) {
        _31206 = NOVALUE;
        goto L1C; // [803] 1013
    }
    else {
        if (!IS_ATOM_INT(_31206) && DBL_PTR(_31206)->dbl == 0.0){
            _31206 = NOVALUE;
            goto L1C; // [803] 1013
        }
        _31206 = NOVALUE;
    }
    _31206 = NOVALUE;

    /** 		integer start_pc = pc*/
    _start_pc_62417 = _pc_62286;

    /** 		if which_type = sequence_type or*/
    _31207 = (_which_type_62251 == _53sequence_type_46095);
    if (_31207 != 0) {
        goto L1D; // [819] 858
    }
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _31209 = (int)*(((s1_ptr)_2)->base + _which_type_62251);
    _2 = (int)SEQ_PTR(_31209);
    _31210 = (int)*(((s1_ptr)_2)->base + 2);
    _31209 = NOVALUE;
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!IS_ATOM_INT(_31210)){
        _31211 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_31210)->dbl));
    }
    else{
        _31211 = (int)*(((s1_ptr)_2)->base + _31210);
    }
    _2 = (int)SEQ_PTR(_31211);
    _31212 = (int)*(((s1_ptr)_2)->base + 15);
    _31211 = NOVALUE;
    if (IS_ATOM_INT(_31212)) {
        _31213 = (_31212 == _53sequence_type_46095);
    }
    else {
        _31213 = binary_op(EQUALS, _31212, _53sequence_type_46095);
    }
    _31212 = NOVALUE;
    if (_31213 == 0) {
        DeRef(_31213);
        _31213 = NOVALUE;
        goto L1E; // [854] 912
    }
    else {
        if (!IS_ATOM_INT(_31213) && DBL_PTR(_31213)->dbl == 0.0){
            DeRef(_31213);
            _31213 = NOVALUE;
            goto L1E; // [854] 912
        }
        DeRef(_31213);
        _31213 = NOVALUE;
    }
    DeRef(_31213);
    _31213 = NOVALUE;
L1D: 

    /** 			insert_code( { SEQUENCE_CHECK, var }, pc, fr[FR_SUBPROG] )*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 97;
    ((int *)_2)[2] = _var_62253;
    _31214 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_fr_62248);
    _31215 = (int)*(((s1_ptr)_2)->base + 4);
    DeRefi(_code_inlined_insert_code_at_883_62436);
    _code_inlined_insert_code_at_883_62436 = _31214;
    _31214 = NOVALUE;
    Ref(_31215);
    DeRef(_subprog_inlined_insert_code_at_886_62437);
    _subprog_inlined_insert_code_at_886_62437 = _31215;
    _31215 = NOVALUE;
    if (!IS_ATOM_INT(_subprog_inlined_insert_code_at_886_62437)) {
        _1 = (long)(DBL_PTR(_subprog_inlined_insert_code_at_886_62437)->dbl);
        DeRefDS(_subprog_inlined_insert_code_at_886_62437);
        _subprog_inlined_insert_code_at_886_62437 = _1;
    }

    /** 	shifting_sub = subprog*/
    _38shifting_sub_61520 = _subprog_inlined_insert_code_at_886_62437;

    /** 	shift:insert_code( code, index )*/
    RefDS(_code_inlined_insert_code_at_883_62436);
    _65insert_code(_code_inlined_insert_code_at_883_62436, _pc_62286);

    /** 	shifting_sub = 0*/
    _38shifting_sub_61520 = 0;

    /** end procedure*/
    goto L1F; // [898] 901
L1F: 
    DeRefi(_code_inlined_insert_code_at_883_62436);
    _code_inlined_insert_code_at_883_62436 = NOVALUE;
    DeRef(_subprog_inlined_insert_code_at_886_62437);
    _subprog_inlined_insert_code_at_886_62437 = NOVALUE;

    /** 			pc += 2*/
    _pc_62286 = _pc_62286 + 2;
    goto L20; // [909] 1012
L1E: 

    /** 		elsif which_type = integer_type or*/
    _31217 = (_which_type_62251 == _53integer_type_46097);
    if (_31217 != 0) {
        goto L21; // [920] 959
    }
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _31219 = (int)*(((s1_ptr)_2)->base + _which_type_62251);
    _2 = (int)SEQ_PTR(_31219);
    _31220 = (int)*(((s1_ptr)_2)->base + 2);
    _31219 = NOVALUE;
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!IS_ATOM_INT(_31220)){
        _31221 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_31220)->dbl));
    }
    else{
        _31221 = (int)*(((s1_ptr)_2)->base + _31220);
    }
    _2 = (int)SEQ_PTR(_31221);
    _31222 = (int)*(((s1_ptr)_2)->base + 15);
    _31221 = NOVALUE;
    if (IS_ATOM_INT(_31222)) {
        _31223 = (_31222 == _53integer_type_46097);
    }
    else {
        _31223 = binary_op(EQUALS, _31222, _53integer_type_46097);
    }
    _31222 = NOVALUE;
    if (_31223 == 0) {
        DeRef(_31223);
        _31223 = NOVALUE;
        goto L22; // [955] 1011
    }
    else {
        if (!IS_ATOM_INT(_31223) && DBL_PTR(_31223)->dbl == 0.0){
            DeRef(_31223);
            _31223 = NOVALUE;
            goto L22; // [955] 1011
        }
        DeRef(_31223);
        _31223 = NOVALUE;
    }
    DeRef(_31223);
    _31223 = NOVALUE;
L21: 

    /** 			insert_code( { INTEGER_CHECK, var }, pc, fr[FR_SUBPROG] )*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 96;
    ((int *)_2)[2] = _var_62253;
    _31224 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_fr_62248);
    _31225 = (int)*(((s1_ptr)_2)->base + 4);
    DeRefi(_code_inlined_insert_code_at_984_62457);
    _code_inlined_insert_code_at_984_62457 = _31224;
    _31224 = NOVALUE;
    Ref(_31225);
    DeRef(_subprog_inlined_insert_code_at_987_62458);
    _subprog_inlined_insert_code_at_987_62458 = _31225;
    _31225 = NOVALUE;
    if (!IS_ATOM_INT(_subprog_inlined_insert_code_at_987_62458)) {
        _1 = (long)(DBL_PTR(_subprog_inlined_insert_code_at_987_62458)->dbl);
        DeRefDS(_subprog_inlined_insert_code_at_987_62458);
        _subprog_inlined_insert_code_at_987_62458 = _1;
    }

    /** 	shifting_sub = subprog*/
    _38shifting_sub_61520 = _subprog_inlined_insert_code_at_987_62458;

    /** 	shift:insert_code( code, index )*/
    RefDS(_code_inlined_insert_code_at_984_62457);
    _65insert_code(_code_inlined_insert_code_at_984_62457, _pc_62286);

    /** 	shifting_sub = 0*/
    _38shifting_sub_61520 = 0;

    /** end procedure*/
    goto L23; // [999] 1002
L23: 
    DeRefi(_code_inlined_insert_code_at_984_62457);
    _code_inlined_insert_code_at_984_62457 = NOVALUE;
    DeRef(_subprog_inlined_insert_code_at_987_62458);
    _subprog_inlined_insert_code_at_987_62458 = NOVALUE;

    /** 			pc += 4*/
    _pc_62286 = _pc_62286 + 4;
L22: 
L20: 
L1C: 

    /** 	resolved_reference( ref )*/
    _38resolved_reference(_ref_62247);

    /** 	reset_code()*/
    _38reset_code();

    /** end procedure*/
    DeRef(_tok_62246);
    DeRef(_fr_62248);
    _31140 = NOVALUE;
    DeRef(_31153);
    _31153 = NOVALUE;
    DeRef(_31158);
    _31158 = NOVALUE;
    _31186 = NOVALUE;
    _31194 = NOVALUE;
    DeRef(_31203);
    _31203 = NOVALUE;
    DeRef(_31207);
    _31207 = NOVALUE;
    _31210 = NOVALUE;
    DeRef(_31217);
    _31217 = NOVALUE;
    _31220 = NOVALUE;
    return;
    ;
}


void _38prep_forward_error(int _ref_62462)
{
    int _31233 = NOVALUE;
    int _31231 = NOVALUE;
    int _31229 = NOVALUE;
    int _31227 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_ref_62462)) {
        _1 = (long)(DBL_PTR(_ref_62462)->dbl);
        DeRefDS(_ref_62462);
        _ref_62462 = _1;
    }

    /** 	ThisLine = forward_references[ref][FR_THISLINE]*/
    _2 = (int)SEQ_PTR(_38forward_references_61501);
    _31227 = (int)*(((s1_ptr)_2)->base + _ref_62462);
    DeRef(_44ThisLine_48518);
    _2 = (int)SEQ_PTR(_31227);
    _44ThisLine_48518 = (int)*(((s1_ptr)_2)->base + 7);
    Ref(_44ThisLine_48518);
    _31227 = NOVALUE;

    /** 	bp = forward_references[ref][FR_BP]*/
    _2 = (int)SEQ_PTR(_38forward_references_61501);
    _31229 = (int)*(((s1_ptr)_2)->base + _ref_62462);
    _2 = (int)SEQ_PTR(_31229);
    _44bp_48522 = (int)*(((s1_ptr)_2)->base + 8);
    if (!IS_ATOM_INT(_44bp_48522)){
        _44bp_48522 = (long)DBL_PTR(_44bp_48522)->dbl;
    }
    _31229 = NOVALUE;

    /** 	line_number = forward_references[ref][FR_LINE]*/
    _2 = (int)SEQ_PTR(_38forward_references_61501);
    _31231 = (int)*(((s1_ptr)_2)->base + _ref_62462);
    _2 = (int)SEQ_PTR(_31231);
    _35line_number_16245 = (int)*(((s1_ptr)_2)->base + 6);
    if (!IS_ATOM_INT(_35line_number_16245)){
        _35line_number_16245 = (long)DBL_PTR(_35line_number_16245)->dbl;
    }
    _31231 = NOVALUE;

    /** 	current_file_no = forward_references[ref][FR_FILE]*/
    _2 = (int)SEQ_PTR(_38forward_references_61501);
    _31233 = (int)*(((s1_ptr)_2)->base + _ref_62462);
    _2 = (int)SEQ_PTR(_31233);
    _35current_file_no_16244 = (int)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_35current_file_no_16244)){
        _35current_file_no_16244 = (long)DBL_PTR(_35current_file_no_16244)->dbl;
    }
    _31233 = NOVALUE;

    /** end procedure*/
    return;
    ;
}


void _38forward_error(int _tok_62478, int _ref_62479)
{
    int _31240 = NOVALUE;
    int _31239 = NOVALUE;
    int _31238 = NOVALUE;
    int _31237 = NOVALUE;
    int _31236 = NOVALUE;
    int _31235 = NOVALUE;
    int _0, _1, _2;
    

    /** 	prep_forward_error( ref )*/
    _38prep_forward_error(_ref_62479);

    /** 	CompileErr(68, { expected_name( forward_references[ref][FR_TYPE] ),*/
    _2 = (int)SEQ_PTR(_38forward_references_61501);
    _31235 = (int)*(((s1_ptr)_2)->base + _ref_62479);
    _2 = (int)SEQ_PTR(_31235);
    _31236 = (int)*(((s1_ptr)_2)->base + 1);
    _31235 = NOVALUE;
    Ref(_31236);
    _31237 = _38expected_name(_31236);
    _31236 = NOVALUE;
    _2 = (int)SEQ_PTR(_tok_62478);
    _31238 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_31238);
    _31239 = _38expected_name(_31238);
    _31238 = NOVALUE;
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _31237;
    ((int *)_2)[2] = _31239;
    _31240 = MAKE_SEQ(_1);
    _31239 = NOVALUE;
    _31237 = NOVALUE;
    _44CompileErr(68, _31240, 0);
    _31240 = NOVALUE;

    /** end procedure*/
    DeRef(_tok_62478);
    return;
    ;
}


int _38find_reference(int _fr_62490)
{
    int _name_62491 = NOVALUE;
    int _file_62493 = NOVALUE;
    int _ns_file_62495 = NOVALUE;
    int _ix_62496 = NOVALUE;
    int _ns_62499 = NOVALUE;
    int _ns_tok_62503 = NOVALUE;
    int _tok_62515 = NOVALUE;
    int _31251 = NOVALUE;
    int _31248 = NOVALUE;
    int _31246 = NOVALUE;
    int _31244 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence name = fr[FR_NAME]*/
    DeRef(_name_62491);
    _2 = (int)SEQ_PTR(_fr_62490);
    _name_62491 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_name_62491);

    /** 	integer file  = fr[FR_FILE]*/
    _2 = (int)SEQ_PTR(_fr_62490);
    _file_62493 = (int)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_file_62493))
    _file_62493 = (long)DBL_PTR(_file_62493)->dbl;

    /** 	integer ns_file = -1*/
    _ns_file_62495 = -1;

    /** 	integer ix = find( ':', name )*/
    _ix_62496 = find_from(58, _name_62491, 1);

    /** 	if ix then*/
    if (_ix_62496 == 0)
    {
        goto L1; // [31] 85
    }
    else{
    }

    /** 		sequence ns = name[1..ix-1]*/
    _31244 = _ix_62496 - 1;
    rhs_slice_target = (object_ptr)&_ns_62499;
    RHS_Slice(_name_62491, 1, _31244);

    /** 		token ns_tok = keyfind( ns, ns_file, file, 1, fr[FR_HASHVAL] )*/
    _2 = (int)SEQ_PTR(_fr_62490);
    _31246 = (int)*(((s1_ptr)_2)->base + 11);
    RefDS(_ns_62499);
    Ref(_31246);
    _0 = _ns_tok_62503;
    _ns_tok_62503 = _53keyfind(_ns_62499, -1, _file_62493, 1, _31246);
    DeRef(_0);
    _31246 = NOVALUE;

    /** 		if ns_tok[T_ID] != NAMESPACE then*/
    _2 = (int)SEQ_PTR(_ns_tok_62503);
    _31248 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _31248, 523)){
        _31248 = NOVALUE;
        goto L2; // [69] 80
    }
    _31248 = NOVALUE;

    /** 			return ns_tok*/
    DeRefDS(_ns_62499);
    DeRefDS(_fr_62490);
    DeRefDS(_name_62491);
    DeRef(_tok_62515);
    _31244 = NOVALUE;
    return _ns_tok_62503;
L2: 
    DeRef(_ns_62499);
    _ns_62499 = NOVALUE;
    DeRef(_ns_tok_62503);
    _ns_tok_62503 = NOVALUE;
    goto L3; // [82] 92
L1: 

    /** 		ns_file = fr[FR_QUALIFIED]*/
    _2 = (int)SEQ_PTR(_fr_62490);
    _ns_file_62495 = (int)*(((s1_ptr)_2)->base + 9);
    if (!IS_ATOM_INT(_ns_file_62495))
    _ns_file_62495 = (long)DBL_PTR(_ns_file_62495)->dbl;
L3: 

    /** 	No_new_entry = 1*/
    _53No_new_entry_47263 = 1;

    /** 	object tok = keyfind( name, ns_file, file, , fr[FR_HASHVAL] )*/
    _2 = (int)SEQ_PTR(_fr_62490);
    _31251 = (int)*(((s1_ptr)_2)->base + 11);
    RefDS(_name_62491);
    Ref(_31251);
    _0 = _tok_62515;
    _tok_62515 = _53keyfind(_name_62491, _ns_file_62495, _file_62493, 0, _31251);
    DeRef(_0);
    _31251 = NOVALUE;

    /** 	No_new_entry = 0*/
    _53No_new_entry_47263 = 0;

    /** 	return tok*/
    DeRefDS(_fr_62490);
    DeRefDS(_name_62491);
    DeRef(_31244);
    _31244 = NOVALUE;
    return _tok_62515;
    ;
}


void _38register_forward_type(int _sym_62523, int _ref_62524)
{
    int _31258 = NOVALUE;
    int _31257 = NOVALUE;
    int _31255 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_sym_62523)) {
        _1 = (long)(DBL_PTR(_sym_62523)->dbl);
        DeRefDS(_sym_62523);
        _sym_62523 = _1;
    }
    if (!IS_ATOM_INT(_ref_62524)) {
        _1 = (long)(DBL_PTR(_ref_62524)->dbl);
        DeRefDS(_ref_62524);
        _ref_62524 = _1;
    }

    /** 	if ref < 0 then*/
    if (_ref_62524 >= 0)
    goto L1; // [7] 19

    /** 		ref = -ref*/
    _ref_62524 = - _ref_62524;
L1: 

    /** 	forward_references[ref][FR_DATA] &= sym*/
    _2 = (int)SEQ_PTR(_38forward_references_61501);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _38forward_references_61501 = MAKE_SEQ(_2);
    }
    _3 = (int)(_ref_62524 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    _31257 = (int)*(((s1_ptr)_2)->base + 12);
    _31255 = NOVALUE;
    if (IS_SEQUENCE(_31257) && IS_ATOM(_sym_62523)) {
        Append(&_31258, _31257, _sym_62523);
    }
    else if (IS_ATOM(_31257) && IS_SEQUENCE(_sym_62523)) {
    }
    else {
        Concat((object_ptr)&_31258, _31257, _sym_62523);
        _31257 = NOVALUE;
    }
    _31257 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 12);
    _1 = *(int *)_2;
    *(int *)_2 = _31258;
    if( _1 != _31258 ){
        DeRef(_1);
    }
    _31258 = NOVALUE;
    _31255 = NOVALUE;

    /** end procedure*/
    return;
    ;
}


int _38forward_reference(int _ref_62534)
{
    int _31271 = NOVALUE;
    int _31270 = NOVALUE;
    int _31269 = NOVALUE;
    int _31268 = NOVALUE;
    int _31267 = NOVALUE;
    int _31266 = NOVALUE;
    int _31265 = NOVALUE;
    int _31263 = NOVALUE;
    int _31262 = NOVALUE;
    int _31261 = NOVALUE;
    int _31260 = NOVALUE;
    int _31259 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_ref_62534)) {
        _1 = (long)(DBL_PTR(_ref_62534)->dbl);
        DeRefDS(_ref_62534);
        _ref_62534 = _1;
    }

    /** 	if 0 > ref and ref >= -length( forward_references ) then*/
    _31259 = (0 > _ref_62534);
    if (_31259 == 0) {
        goto L1; // [9] 91
    }
    if (IS_SEQUENCE(_38forward_references_61501)){
            _31261 = SEQ_PTR(_38forward_references_61501)->length;
    }
    else {
        _31261 = 1;
    }
    _31262 = - _31261;
    _31263 = (_ref_62534 >= _31262);
    _31262 = NOVALUE;
    if (_31263 == 0)
    {
        DeRef(_31263);
        _31263 = NOVALUE;
        goto L1; // [26] 91
    }
    else{
        DeRef(_31263);
        _31263 = NOVALUE;
    }

    /** 		ref = -ref*/
    _ref_62534 = - _ref_62534;

    /** 		if integer(forward_references[ref][FR_FILE]) and*/
    _2 = (int)SEQ_PTR(_38forward_references_61501);
    _31265 = (int)*(((s1_ptr)_2)->base + _ref_62534);
    _2 = (int)SEQ_PTR(_31265);
    _31266 = (int)*(((s1_ptr)_2)->base + 3);
    _31265 = NOVALUE;
    if (IS_ATOM_INT(_31266))
    _31267 = 1;
    else if (IS_ATOM_DBL(_31266))
    _31267 = IS_ATOM_INT(DoubleToInt(_31266));
    else
    _31267 = 0;
    _31266 = NOVALUE;
    if (_31267 == 0) {
        goto L2; // [51] 81
    }
    _2 = (int)SEQ_PTR(_38forward_references_61501);
    _31269 = (int)*(((s1_ptr)_2)->base + _ref_62534);
    _2 = (int)SEQ_PTR(_31269);
    _31270 = (int)*(((s1_ptr)_2)->base + 5);
    _31269 = NOVALUE;
    if (IS_ATOM_INT(_31270))
    _31271 = 1;
    else if (IS_ATOM_DBL(_31270))
    _31271 = IS_ATOM_INT(DoubleToInt(_31270));
    else
    _31271 = 0;
    _31270 = NOVALUE;
    if (_31271 == 0)
    {
        _31271 = NOVALUE;
        goto L2; // [69] 81
    }
    else{
        _31271 = NOVALUE;
    }

    /** 				return 1*/
    DeRef(_31259);
    _31259 = NOVALUE;
    return 1;
    goto L3; // [78] 98
L2: 

    /** 			return 0*/
    DeRef(_31259);
    _31259 = NOVALUE;
    return 0;
    goto L3; // [88] 98
L1: 

    /** 		return 0*/
    DeRef(_31259);
    _31259 = NOVALUE;
    return 0;
L3: 
    ;
}


int _38new_forward_reference(int _fwd_op_62554, int _sym_62556, int _op_62557)
{
    int _ref_62558 = NOVALUE;
    int _len_62559 = NOVALUE;
    int _hashval_62589 = NOVALUE;
    int _default_sym_62664 = NOVALUE;
    int _param_62667 = NOVALUE;
    int _set_data_2__tmp_at578_62684 = NOVALUE;
    int _set_data_1__tmp_at578_62683 = NOVALUE;
    int _data_inlined_set_data_at_575_62682 = NOVALUE;
    int _31344 = NOVALUE;
    int _31343 = NOVALUE;
    int _31342 = NOVALUE;
    int _31339 = NOVALUE;
    int _31337 = NOVALUE;
    int _31336 = NOVALUE;
    int _31334 = NOVALUE;
    int _31333 = NOVALUE;
    int _31332 = NOVALUE;
    int _31330 = NOVALUE;
    int _31328 = NOVALUE;
    int _31326 = NOVALUE;
    int _31323 = NOVALUE;
    int _31322 = NOVALUE;
    int _31320 = NOVALUE;
    int _31318 = NOVALUE;
    int _31316 = NOVALUE;
    int _31314 = NOVALUE;
    int _31313 = NOVALUE;
    int _31312 = NOVALUE;
    int _31310 = NOVALUE;
    int _31307 = NOVALUE;
    int _31305 = NOVALUE;
    int _31303 = NOVALUE;
    int _31302 = NOVALUE;
    int _31301 = NOVALUE;
    int _31300 = NOVALUE;
    int _31298 = NOVALUE;
    int _31295 = NOVALUE;
    int _31294 = NOVALUE;
    int _31293 = NOVALUE;
    int _31291 = NOVALUE;
    int _31290 = NOVALUE;
    int _31289 = NOVALUE;
    int _31288 = NOVALUE;
    int _31286 = NOVALUE;
    int _31285 = NOVALUE;
    int _31284 = NOVALUE;
    int _31283 = NOVALUE;
    int _31281 = NOVALUE;
    int _31278 = NOVALUE;
    int _31277 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_fwd_op_62554)) {
        _1 = (long)(DBL_PTR(_fwd_op_62554)->dbl);
        DeRefDS(_fwd_op_62554);
        _fwd_op_62554 = _1;
    }
    if (!IS_ATOM_INT(_sym_62556)) {
        _1 = (long)(DBL_PTR(_sym_62556)->dbl);
        DeRefDS(_sym_62556);
        _sym_62556 = _1;
    }
    if (!IS_ATOM_INT(_op_62557)) {
        _1 = (long)(DBL_PTR(_op_62557)->dbl);
        DeRefDS(_op_62557);
        _op_62557 = _1;
    }

    /** 		len = length( inactive_references )*/
    if (IS_SEQUENCE(_38inactive_references_61505)){
            _len_62559 = SEQ_PTR(_38inactive_references_61505)->length;
    }
    else {
        _len_62559 = 1;
    }

    /** 	if len then*/
    if (_len_62559 == 0)
    {
        goto L1; // [16] 39
    }
    else{
    }

    /** 		ref = inactive_references[len]*/
    _2 = (int)SEQ_PTR(_38inactive_references_61505);
    _ref_62558 = (int)*(((s1_ptr)_2)->base + _len_62559);
    if (!IS_ATOM_INT(_ref_62558))
    _ref_62558 = (long)DBL_PTR(_ref_62558)->dbl;

    /** 		inactive_references = remove( inactive_references, len, len )*/
    {
        s1_ptr assign_space = SEQ_PTR(_38inactive_references_61505);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_len_62559)) ? _len_62559 : (long)(DBL_PTR(_len_62559)->dbl);
        int stop = (IS_ATOM_INT(_len_62559)) ? _len_62559 : (long)(DBL_PTR(_len_62559)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_38inactive_references_61505), start, &_38inactive_references_61505 );
            }
            else Tail(SEQ_PTR(_38inactive_references_61505), stop+1, &_38inactive_references_61505);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_38inactive_references_61505), start, &_38inactive_references_61505);
        }
        else {
            assign_slice_seq = &assign_space;
            _38inactive_references_61505 = Remove_elements(start, stop, (SEQ_PTR(_38inactive_references_61505)->ref == 1));
        }
    }
    goto L2; // [36] 55
L1: 

    /** 		forward_references &= 0*/
    Append(&_38forward_references_61501, _38forward_references_61501, 0);

    /** 		ref = length( forward_references )*/
    if (IS_SEQUENCE(_38forward_references_61501)){
            _ref_62558 = SEQ_PTR(_38forward_references_61501)->length;
    }
    else {
        _ref_62558 = 1;
    }
L2: 

    /** 	forward_references[ref] = repeat( 0, FR_SIZE )*/
    _31277 = Repeat(0, 12);
    _2 = (int)SEQ_PTR(_38forward_references_61501);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _38forward_references_61501 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _ref_62558);
    _1 = *(int *)_2;
    *(int *)_2 = _31277;
    if( _1 != _31277 ){
        DeRef(_1);
    }
    _31277 = NOVALUE;

    /** 	forward_references[ref][FR_TYPE]      = fwd_op*/
    _2 = (int)SEQ_PTR(_38forward_references_61501);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _38forward_references_61501 = MAKE_SEQ(_2);
    }
    _3 = (int)(_ref_62558 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _fwd_op_62554;
    DeRef(_1);
    _31278 = NOVALUE;

    /** 	if sym < 0 then*/
    if (_sym_62556 >= 0)
    goto L3; // [84] 143

    /** 		forward_references[ref][FR_NAME] = forward_references[-sym][FR_NAME]*/
    _2 = (int)SEQ_PTR(_38forward_references_61501);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _38forward_references_61501 = MAKE_SEQ(_2);
    }
    _3 = (int)(_ref_62558 + ((s1_ptr)_2)->base);
    if ((unsigned long)_sym_62556 == 0xC0000000)
    _31283 = (int)NewDouble((double)-0xC0000000);
    else
    _31283 = - _sym_62556;
    _2 = (int)SEQ_PTR(_38forward_references_61501);
    if (!IS_ATOM_INT(_31283)){
        _31284 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_31283)->dbl));
    }
    else{
        _31284 = (int)*(((s1_ptr)_2)->base + _31283);
    }
    _2 = (int)SEQ_PTR(_31284);
    _31285 = (int)*(((s1_ptr)_2)->base + 2);
    _31284 = NOVALUE;
    Ref(_31285);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _31285;
    if( _1 != _31285 ){
        DeRef(_1);
    }
    _31285 = NOVALUE;
    _31281 = NOVALUE;

    /** 		forward_references[ref][FR_HASHVAL] = forward_references[-sym][FR_HASHVAL]*/
    _2 = (int)SEQ_PTR(_38forward_references_61501);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _38forward_references_61501 = MAKE_SEQ(_2);
    }
    _3 = (int)(_ref_62558 + ((s1_ptr)_2)->base);
    if ((unsigned long)_sym_62556 == 0xC0000000)
    _31288 = (int)NewDouble((double)-0xC0000000);
    else
    _31288 = - _sym_62556;
    _2 = (int)SEQ_PTR(_38forward_references_61501);
    if (!IS_ATOM_INT(_31288)){
        _31289 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_31288)->dbl));
    }
    else{
        _31289 = (int)*(((s1_ptr)_2)->base + _31288);
    }
    _2 = (int)SEQ_PTR(_31289);
    _31290 = (int)*(((s1_ptr)_2)->base + 11);
    _31289 = NOVALUE;
    Ref(_31290);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 11);
    _1 = *(int *)_2;
    *(int *)_2 = _31290;
    if( _1 != _31290 ){
        DeRef(_1);
    }
    _31290 = NOVALUE;
    _31286 = NOVALUE;
    goto L4; // [140] 242
L3: 

    /** 		forward_references[ref][FR_NAME] = SymTab[sym][S_NAME]*/
    _2 = (int)SEQ_PTR(_38forward_references_61501);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _38forward_references_61501 = MAKE_SEQ(_2);
    }
    _3 = (int)(_ref_62558 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _31293 = (int)*(((s1_ptr)_2)->base + _sym_62556);
    _2 = (int)SEQ_PTR(_31293);
    if (!IS_ATOM_INT(_35S_NAME_15917)){
        _31294 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15917)->dbl));
    }
    else{
        _31294 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15917);
    }
    _31293 = NOVALUE;
    Ref(_31294);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _31294;
    if( _1 != _31294 ){
        DeRef(_1);
    }
    _31294 = NOVALUE;
    _31291 = NOVALUE;

    /** 		integer hashval = SymTab[sym][S_HASHVAL]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _31295 = (int)*(((s1_ptr)_2)->base + _sym_62556);
    _2 = (int)SEQ_PTR(_31295);
    _hashval_62589 = (int)*(((s1_ptr)_2)->base + 11);
    if (!IS_ATOM_INT(_hashval_62589)){
        _hashval_62589 = (long)DBL_PTR(_hashval_62589)->dbl;
    }
    _31295 = NOVALUE;

    /** 		if 0 = hashval then*/
    if (0 != _hashval_62589)
    goto L5; // [186] 220

    /** 			forward_references[ref][FR_HASHVAL] = hashfn( forward_references[ref][FR_NAME] )*/
    _2 = (int)SEQ_PTR(_38forward_references_61501);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _38forward_references_61501 = MAKE_SEQ(_2);
    }
    _3 = (int)(_ref_62558 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_38forward_references_61501);
    _31300 = (int)*(((s1_ptr)_2)->base + _ref_62558);
    _2 = (int)SEQ_PTR(_31300);
    _31301 = (int)*(((s1_ptr)_2)->base + 2);
    _31300 = NOVALUE;
    Ref(_31301);
    _31302 = _53hashfn(_31301);
    _31301 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 11);
    _1 = *(int *)_2;
    *(int *)_2 = _31302;
    if( _1 != _31302 ){
        DeRef(_1);
    }
    _31302 = NOVALUE;
    _31298 = NOVALUE;
    goto L6; // [217] 239
L5: 

    /** 			forward_references[ref][FR_HASHVAL] = hashval*/
    _2 = (int)SEQ_PTR(_38forward_references_61501);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _38forward_references_61501 = MAKE_SEQ(_2);
    }
    _3 = (int)(_ref_62558 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 11);
    _1 = *(int *)_2;
    *(int *)_2 = _hashval_62589;
    DeRef(_1);
    _31303 = NOVALUE;

    /** 			remove_symbol( sym )*/
    _53remove_symbol(_sym_62556);
L6: 
L4: 

    /** 	forward_references[ref][FR_FILE]      = current_file_no*/
    _2 = (int)SEQ_PTR(_38forward_references_61501);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _38forward_references_61501 = MAKE_SEQ(_2);
    }
    _3 = (int)(_ref_62558 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = _35current_file_no_16244;
    DeRef(_1);
    _31305 = NOVALUE;

    /** 	forward_references[ref][FR_SUBPROG]   = CurrentSub*/
    _2 = (int)SEQ_PTR(_38forward_references_61501);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _38forward_references_61501 = MAKE_SEQ(_2);
    }
    _3 = (int)(_ref_62558 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = _35CurrentSub_16252;
    DeRef(_1);
    _31307 = NOVALUE;

    /** 	if fwd_op != TYPE then*/
    if (_fwd_op_62554 == 504)
    goto L7; // [276] 303

    /** 		forward_references[ref][FR_PC]        = length( Code ) + 1*/
    _2 = (int)SEQ_PTR(_38forward_references_61501);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _38forward_references_61501 = MAKE_SEQ(_2);
    }
    _3 = (int)(_ref_62558 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_35Code_16332)){
            _31312 = SEQ_PTR(_35Code_16332)->length;
    }
    else {
        _31312 = 1;
    }
    _31313 = _31312 + 1;
    _31312 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = _31313;
    if( _1 != _31313 ){
        DeRef(_1);
    }
    _31313 = NOVALUE;
    _31310 = NOVALUE;
L7: 

    /** 	forward_references[ref][FR_LINE]      = fwd_line_number*/
    _2 = (int)SEQ_PTR(_38forward_references_61501);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _38forward_references_61501 = MAKE_SEQ(_2);
    }
    _3 = (int)(_ref_62558 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 6);
    _1 = *(int *)_2;
    *(int *)_2 = _35fwd_line_number_16246;
    DeRef(_1);
    _31314 = NOVALUE;

    /** 	forward_references[ref][FR_THISLINE]  = ForwardLine*/
    _2 = (int)SEQ_PTR(_38forward_references_61501);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _38forward_references_61501 = MAKE_SEQ(_2);
    }
    _3 = (int)(_ref_62558 + ((s1_ptr)_2)->base);
    Ref(_44ForwardLine_48519);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 7);
    _1 = *(int *)_2;
    *(int *)_2 = _44ForwardLine_48519;
    DeRef(_1);
    _31316 = NOVALUE;

    /** 	forward_references[ref][FR_BP]        = forward_bp*/
    _2 = (int)SEQ_PTR(_38forward_references_61501);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _38forward_references_61501 = MAKE_SEQ(_2);
    }
    _3 = (int)(_ref_62558 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 8);
    _1 = *(int *)_2;
    *(int *)_2 = _44forward_bp_48523;
    DeRef(_1);
    _31318 = NOVALUE;

    /** 	forward_references[ref][FR_QUALIFIED] = get_qualified_fwd()*/
    _2 = (int)SEQ_PTR(_38forward_references_61501);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _38forward_references_61501 = MAKE_SEQ(_2);
    }
    _3 = (int)(_ref_62558 + ((s1_ptr)_2)->base);
    _31322 = _61get_qualified_fwd();
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 9);
    _1 = *(int *)_2;
    *(int *)_2 = _31322;
    if( _1 != _31322 ){
        DeRef(_1);
    }
    _31322 = NOVALUE;
    _31320 = NOVALUE;

    /** 	forward_references[ref][FR_OP]        = op*/
    _2 = (int)SEQ_PTR(_38forward_references_61501);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _38forward_references_61501 = MAKE_SEQ(_2);
    }
    _3 = (int)(_ref_62558 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 10);
    _1 = *(int *)_2;
    *(int *)_2 = _op_62557;
    DeRef(_1);
    _31323 = NOVALUE;

    /** 	if op = GOTO then*/
    if (_op_62557 != 188)
    goto L8; // [381] 403

    /** 		forward_references[ref][FR_DATA] = { sym }*/
    _2 = (int)SEQ_PTR(_38forward_references_61501);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _38forward_references_61501 = MAKE_SEQ(_2);
    }
    _3 = (int)(_ref_62558 + ((s1_ptr)_2)->base);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _sym_62556;
    _31328 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 12);
    _1 = *(int *)_2;
    *(int *)_2 = _31328;
    if( _1 != _31328 ){
        DeRef(_1);
    }
    _31328 = NOVALUE;
    _31326 = NOVALUE;
L8: 

    /** 	if CurrentSub = TopLevelSub then*/
    if (_35CurrentSub_16252 != _35TopLevelSub_16251)
    goto L9; // [409] 471

    /** 		if length( toplevel_references ) < current_file_no then*/
    if (IS_SEQUENCE(_38toplevel_references_61504)){
            _31330 = SEQ_PTR(_38toplevel_references_61504)->length;
    }
    else {
        _31330 = 1;
    }
    if (_31330 >= _35current_file_no_16244)
    goto LA; // [422] 450

    /** 			toplevel_references &= repeat( {}, current_file_no - length( toplevel_references ) )*/
    if (IS_SEQUENCE(_38toplevel_references_61504)){
            _31332 = SEQ_PTR(_38toplevel_references_61504)->length;
    }
    else {
        _31332 = 1;
    }
    _31333 = _35current_file_no_16244 - _31332;
    _31332 = NOVALUE;
    _31334 = Repeat(_22023, _31333);
    _31333 = NOVALUE;
    Concat((object_ptr)&_38toplevel_references_61504, _38toplevel_references_61504, _31334);
    DeRefDS(_31334);
    _31334 = NOVALUE;
LA: 

    /** 		toplevel_references[current_file_no] &= ref*/
    _2 = (int)SEQ_PTR(_38toplevel_references_61504);
    _31336 = (int)*(((s1_ptr)_2)->base + _35current_file_no_16244);
    if (IS_SEQUENCE(_31336) && IS_ATOM(_ref_62558)) {
        Append(&_31337, _31336, _ref_62558);
    }
    else if (IS_ATOM(_31336) && IS_SEQUENCE(_ref_62558)) {
    }
    else {
        Concat((object_ptr)&_31337, _31336, _ref_62558);
        _31336 = NOVALUE;
    }
    _31336 = NOVALUE;
    _2 = (int)SEQ_PTR(_38toplevel_references_61504);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _38toplevel_references_61504 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _35current_file_no_16244);
    _1 = *(int *)_2;
    *(int *)_2 = _31337;
    if( _1 != _31337 ){
        DeRef(_1);
    }
    _31337 = NOVALUE;
    goto LB; // [468] 595
L9: 

    /** 		add_active_reference( ref )*/
    _38add_active_reference(_ref_62558, _35current_file_no_16244);

    /** 		if Parser_mode = PAM_RECORD then*/
    if (_35Parser_mode_16349 != 1)
    goto LC; // [485] 592

    /** 			symtab_pointer default_sym = CurrentSub*/
    _default_sym_62664 = _35CurrentSub_16252;

    /** 			symtab_pointer param = 0*/
    _param_62667 = 0;

    /** 			while default_sym with entry do*/
    goto LD; // [507] 536
LE: 
    if (_default_sym_62664 == 0)
    {
        goto LF; // [510] 549
    }
    else{
    }

    /** 				if sym_scope( default_sym ) = SC_PRIVATE then*/
    _31339 = _53sym_scope(_default_sym_62664);
    if (binary_op_a(NOTEQ, _31339, 3)){
        DeRef(_31339);
        _31339 = NOVALUE;
        goto L10; // [521] 533
    }
    DeRef(_31339);
    _31339 = NOVALUE;

    /** 					param = default_sym*/
    _param_62667 = _default_sym_62664;
L10: 

    /** 			entry*/
LD: 

    /** 				default_sym = sym_next( default_sym )*/
    _default_sym_62664 = _53sym_next(_default_sym_62664);
    if (!IS_ATOM_INT(_default_sym_62664)) {
        _1 = (long)(DBL_PTR(_default_sym_62664)->dbl);
        DeRefDS(_default_sym_62664);
        _default_sym_62664 = _1;
    }

    /** 			end while*/
    goto LE; // [546] 510
LF: 

    /** 			set_data( ref, {{ PAM_RECORD, param, length( Recorded_sym ) }} )*/
    if (IS_SEQUENCE(_35Recorded_sym_16352)){
            _31342 = SEQ_PTR(_35Recorded_sym_16352)->length;
    }
    else {
        _31342 = 1;
    }
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = _param_62667;
    *((int *)(_2+12)) = _31342;
    _31343 = MAKE_SEQ(_1);
    _31342 = NOVALUE;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _31343;
    _31344 = MAKE_SEQ(_1);
    _31343 = NOVALUE;
    DeRef(_data_inlined_set_data_at_575_62682);
    _data_inlined_set_data_at_575_62682 = _31344;
    _31344 = NOVALUE;

    /** 	forward_references[ref][FR_DATA] = data*/
    _2 = (int)SEQ_PTR(_38forward_references_61501);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _38forward_references_61501 = MAKE_SEQ(_2);
    }
    _3 = (int)(_ref_62558 + ((s1_ptr)_2)->base);
    RefDS(_data_inlined_set_data_at_575_62682);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 12);
    _1 = *(int *)_2;
    *(int *)_2 = _data_inlined_set_data_at_575_62682;
    DeRef(_1);

    /** end procedure*/
    goto L11; // [586] 589
L11: 
    DeRef(_data_inlined_set_data_at_575_62682);
    _data_inlined_set_data_at_575_62682 = NOVALUE;
LC: 
LB: 

    /** 	fwdref_count += 1*/
    _38fwdref_count_61521 = _38fwdref_count_61521 + 1;

    /** 	return ref*/
    DeRef(_31283);
    _31283 = NOVALUE;
    DeRef(_31288);
    _31288 = NOVALUE;
    return _ref_62558;
    ;
}


void _38add_active_reference(int _ref_62688, int _file_no_62689)
{
    int _sp_62703 = NOVALUE;
    int _31368 = NOVALUE;
    int _31367 = NOVALUE;
    int _31365 = NOVALUE;
    int _31364 = NOVALUE;
    int _31363 = NOVALUE;
    int _31361 = NOVALUE;
    int _31360 = NOVALUE;
    int _31359 = NOVALUE;
    int _31356 = NOVALUE;
    int _31354 = NOVALUE;
    int _31353 = NOVALUE;
    int _31352 = NOVALUE;
    int _31350 = NOVALUE;
    int _31349 = NOVALUE;
    int _31348 = NOVALUE;
    int _31346 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	if length( active_references ) < file_no then*/
    if (IS_SEQUENCE(_38active_references_61503)){
            _31346 = SEQ_PTR(_38active_references_61503)->length;
    }
    else {
        _31346 = 1;
    }
    if (_31346 >= _file_no_62689)
    goto L1; // [12] 59

    /** 		active_references &= repeat( {}, file_no - length( active_references ) )*/
    if (IS_SEQUENCE(_38active_references_61503)){
            _31348 = SEQ_PTR(_38active_references_61503)->length;
    }
    else {
        _31348 = 1;
    }
    _31349 = _file_no_62689 - _31348;
    _31348 = NOVALUE;
    _31350 = Repeat(_22023, _31349);
    _31349 = NOVALUE;
    Concat((object_ptr)&_38active_references_61503, _38active_references_61503, _31350);
    DeRefDS(_31350);
    _31350 = NOVALUE;

    /** 		active_subprogs   &= repeat( {}, file_no - length( active_subprogs ) )*/
    if (IS_SEQUENCE(_38active_subprogs_61502)){
            _31352 = SEQ_PTR(_38active_subprogs_61502)->length;
    }
    else {
        _31352 = 1;
    }
    _31353 = _file_no_62689 - _31352;
    _31352 = NOVALUE;
    _31354 = Repeat(_22023, _31353);
    _31353 = NOVALUE;
    Concat((object_ptr)&_38active_subprogs_61502, _38active_subprogs_61502, _31354);
    DeRefDS(_31354);
    _31354 = NOVALUE;
L1: 

    /** 	integer sp = find( CurrentSub, active_subprogs[file_no] )*/
    _2 = (int)SEQ_PTR(_38active_subprogs_61502);
    _31356 = (int)*(((s1_ptr)_2)->base + _file_no_62689);
    _sp_62703 = find_from(_35CurrentSub_16252, _31356, 1);
    _31356 = NOVALUE;

    /** 	if not sp then*/
    if (_sp_62703 != 0)
    goto L2; // [76] 127

    /** 		active_subprogs[file_no] &= CurrentSub*/
    _2 = (int)SEQ_PTR(_38active_subprogs_61502);
    _31359 = (int)*(((s1_ptr)_2)->base + _file_no_62689);
    if (IS_SEQUENCE(_31359) && IS_ATOM(_35CurrentSub_16252)) {
        Append(&_31360, _31359, _35CurrentSub_16252);
    }
    else if (IS_ATOM(_31359) && IS_SEQUENCE(_35CurrentSub_16252)) {
    }
    else {
        Concat((object_ptr)&_31360, _31359, _35CurrentSub_16252);
        _31359 = NOVALUE;
    }
    _31359 = NOVALUE;
    _2 = (int)SEQ_PTR(_38active_subprogs_61502);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _38active_subprogs_61502 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _file_no_62689);
    _1 = *(int *)_2;
    *(int *)_2 = _31360;
    if( _1 != _31360 ){
        DeRef(_1);
    }
    _31360 = NOVALUE;

    /** 		sp = length( active_subprogs[file_no] )*/
    _2 = (int)SEQ_PTR(_38active_subprogs_61502);
    _31361 = (int)*(((s1_ptr)_2)->base + _file_no_62689);
    if (IS_SEQUENCE(_31361)){
            _sp_62703 = SEQ_PTR(_31361)->length;
    }
    else {
        _sp_62703 = 1;
    }
    _31361 = NOVALUE;

    /** 		active_references[file_no] = append( active_references[file_no], {} )*/
    _2 = (int)SEQ_PTR(_38active_references_61503);
    _31363 = (int)*(((s1_ptr)_2)->base + _file_no_62689);
    RefDS(_22023);
    Append(&_31364, _31363, _22023);
    _31363 = NOVALUE;
    _2 = (int)SEQ_PTR(_38active_references_61503);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _38active_references_61503 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _file_no_62689);
    _1 = *(int *)_2;
    *(int *)_2 = _31364;
    if( _1 != _31364 ){
        DeRef(_1);
    }
    _31364 = NOVALUE;
L2: 

    /** 	active_references[file_no][sp] &= ref*/
    _2 = (int)SEQ_PTR(_38active_references_61503);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _38active_references_61503 = MAKE_SEQ(_2);
    }
    _3 = (int)(_file_no_62689 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    _31367 = (int)*(((s1_ptr)_2)->base + _sp_62703);
    _31365 = NOVALUE;
    if (IS_SEQUENCE(_31367) && IS_ATOM(_ref_62688)) {
        Append(&_31368, _31367, _ref_62688);
    }
    else if (IS_ATOM(_31367) && IS_SEQUENCE(_ref_62688)) {
    }
    else {
        Concat((object_ptr)&_31368, _31367, _ref_62688);
        _31367 = NOVALUE;
    }
    _31367 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _sp_62703);
    _1 = *(int *)_2;
    *(int *)_2 = _31368;
    if( _1 != _31368 ){
        DeRef(_1);
    }
    _31368 = NOVALUE;
    _31365 = NOVALUE;

    /** end procedure*/
    _31361 = NOVALUE;
    return;
    ;
}


int _38resolve_file(int _refs_62740, int _report_errors_62741, int _unincluded_ok_62742)
{
    int _errors_62743 = NOVALUE;
    int _ref_62747 = NOVALUE;
    int _fr_62749 = NOVALUE;
    int _tok_62762 = NOVALUE;
    int _code_sub_62770 = NOVALUE;
    int _fr_type_62772 = NOVALUE;
    int _sym_tok_62774 = NOVALUE;
    int _31422 = NOVALUE;
    int _31421 = NOVALUE;
    int _31420 = NOVALUE;
    int _31419 = NOVALUE;
    int _31418 = NOVALUE;
    int _31417 = NOVALUE;
    int _31412 = NOVALUE;
    int _31411 = NOVALUE;
    int _31410 = NOVALUE;
    int _31408 = NOVALUE;
    int _31407 = NOVALUE;
    int _31404 = NOVALUE;
    int _31403 = NOVALUE;
    int _31402 = NOVALUE;
    int _31398 = NOVALUE;
    int _31397 = NOVALUE;
    int _31389 = NOVALUE;
    int _31387 = NOVALUE;
    int _31386 = NOVALUE;
    int _31385 = NOVALUE;
    int _31384 = NOVALUE;
    int _31383 = NOVALUE;
    int _31382 = NOVALUE;
    int _31379 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence errors = {}*/
    RefDS(_22023);
    DeRefi(_errors_62743);
    _errors_62743 = _22023;

    /** 	for ar = length( refs ) to 1 by -1 do*/
    if (IS_SEQUENCE(_refs_62740)){
            _31379 = SEQ_PTR(_refs_62740)->length;
    }
    else {
        _31379 = 1;
    }
    {
        int _ar_62745;
        _ar_62745 = _31379;
L1: 
        if (_ar_62745 < 1){
            goto L2; // [19] 481
        }

        /** 		integer ref = refs[ar]*/
        _2 = (int)SEQ_PTR(_refs_62740);
        _ref_62747 = (int)*(((s1_ptr)_2)->base + _ar_62745);
        if (!IS_ATOM_INT(_ref_62747))
        _ref_62747 = (long)DBL_PTR(_ref_62747)->dbl;

        /** 		sequence fr = forward_references[ref]*/
        DeRef(_fr_62749);
        _2 = (int)SEQ_PTR(_38forward_references_61501);
        _fr_62749 = (int)*(((s1_ptr)_2)->base + _ref_62747);
        Ref(_fr_62749);

        /** 		if include_matrix[fr[FR_FILE]][current_file_no] = NOT_INCLUDED and not unincluded_ok then*/
        _2 = (int)SEQ_PTR(_fr_62749);
        _31382 = (int)*(((s1_ptr)_2)->base + 3);
        _2 = (int)SEQ_PTR(_36include_matrix_15249);
        if (!IS_ATOM_INT(_31382)){
            _31383 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_31382)->dbl));
        }
        else{
            _31383 = (int)*(((s1_ptr)_2)->base + _31382);
        }
        _2 = (int)SEQ_PTR(_31383);
        _31384 = (int)*(((s1_ptr)_2)->base + _35current_file_no_16244);
        _31383 = NOVALUE;
        if (IS_ATOM_INT(_31384)) {
            _31385 = (_31384 == 0);
        }
        else {
            _31385 = binary_op(EQUALS, _31384, 0);
        }
        _31384 = NOVALUE;
        if (IS_ATOM_INT(_31385)) {
            if (_31385 == 0) {
                goto L3; // [66] 84
            }
        }
        else {
            if (DBL_PTR(_31385)->dbl == 0.0) {
                goto L3; // [66] 84
            }
        }
        _31387 = (_unincluded_ok_62742 == 0);
        if (_31387 == 0)
        {
            DeRef(_31387);
            _31387 = NOVALUE;
            goto L3; // [74] 84
        }
        else{
            DeRef(_31387);
            _31387 = NOVALUE;
        }

        /** 			continue*/
        DeRef(_fr_62749);
        _fr_62749 = NOVALUE;
        DeRef(_tok_62762);
        _tok_62762 = NOVALUE;
        goto L4; // [81] 476
L3: 

        /** 		token tok = find_reference( fr )*/
        RefDS(_fr_62749);
        _0 = _tok_62762;
        _tok_62762 = _38find_reference(_fr_62749);
        DeRef(_0);

        /** 		if tok[T_ID] = IGNORED then*/
        _2 = (int)SEQ_PTR(_tok_62762);
        _31389 = (int)*(((s1_ptr)_2)->base + 1);
        if (binary_op_a(NOTEQ, _31389, 509)){
            _31389 = NOVALUE;
            goto L5; // [100] 117
        }
        _31389 = NOVALUE;

        /** 			errors &= ref*/
        Append(&_errors_62743, _errors_62743, _ref_62747);

        /** 			continue*/
        DeRefDS(_fr_62749);
        _fr_62749 = NOVALUE;
        DeRef(_tok_62762);
        _tok_62762 = NOVALUE;
        goto L4; // [114] 476
L5: 

        /** 		integer code_sub = fr[FR_SUBPROG]*/
        _2 = (int)SEQ_PTR(_fr_62749);
        _code_sub_62770 = (int)*(((s1_ptr)_2)->base + 4);
        if (!IS_ATOM_INT(_code_sub_62770))
        _code_sub_62770 = (long)DBL_PTR(_code_sub_62770)->dbl;

        /** 		integer fr_type  = fr[FR_TYPE]*/
        _2 = (int)SEQ_PTR(_fr_62749);
        _fr_type_62772 = (int)*(((s1_ptr)_2)->base + 1);
        if (!IS_ATOM_INT(_fr_type_62772))
        _fr_type_62772 = (long)DBL_PTR(_fr_type_62772)->dbl;

        /** 		integer sym_tok*/

        /** 		switch fr_type label "fr_type" do*/
        _0 = _fr_type_62772;
        switch ( _0 ){ 

            /** 			case PROC, FUNC then*/
            case 27:
            case 501:

            /** 				sym_tok = SymTab[tok[T_SYM]][S_TOKEN]*/
            _2 = (int)SEQ_PTR(_tok_62762);
            _31397 = (int)*(((s1_ptr)_2)->base + 2);
            _2 = (int)SEQ_PTR(_36SymTab_15242);
            if (!IS_ATOM_INT(_31397)){
                _31398 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_31397)->dbl));
            }
            else{
                _31398 = (int)*(((s1_ptr)_2)->base + _31397);
            }
            _2 = (int)SEQ_PTR(_31398);
            if (!IS_ATOM_INT(_35S_TOKEN_15922)){
                _sym_tok_62774 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TOKEN_15922)->dbl));
            }
            else{
                _sym_tok_62774 = (int)*(((s1_ptr)_2)->base + _35S_TOKEN_15922);
            }
            if (!IS_ATOM_INT(_sym_tok_62774)){
                _sym_tok_62774 = (long)DBL_PTR(_sym_tok_62774)->dbl;
            }
            _31398 = NOVALUE;

            /** 				if sym_tok = TYPE then*/
            if (_sym_tok_62774 != 504)
            goto L6; // [170] 184

            /** 					sym_tok = FUNC*/
            _sym_tok_62774 = 501;
L6: 

            /** 				if sym_tok != fr_type then*/
            if (_sym_tok_62774 == _fr_type_62772)
            goto L7; // [186] 220

            /** 					if sym_tok != FUNC and fr_type != PROC then*/
            _31402 = (_sym_tok_62774 != 501);
            if (_31402 == 0) {
                goto L8; // [198] 219
            }
            _31404 = (_fr_type_62772 != 27);
            if (_31404 == 0)
            {
                DeRef(_31404);
                _31404 = NOVALUE;
                goto L8; // [209] 219
            }
            else{
                DeRef(_31404);
                _31404 = NOVALUE;
            }

            /** 						forward_error( tok, ref )*/
            Ref(_tok_62762);
            _38forward_error(_tok_62762, _ref_62747);
L8: 
L7: 

            /** 				switch sym_tok do*/
            _0 = _sym_tok_62774;
            switch ( _0 ){ 

                /** 					case PROC, FUNC then*/
                case 27:
                case 501:

                /** 						patch_forward_call( tok, ref )*/
                Ref(_tok_62762);
                _38patch_forward_call(_tok_62762, _ref_62747);

                /** 						break "fr_type"*/
                goto L9; // [241] 446
                goto L9; // [243] 446

                /** 					case else*/
                default:

                /** 						forward_error( tok, ref )*/
                Ref(_tok_62762);
                _38forward_error(_tok_62762, _ref_62747);
            ;}            goto L9; // [256] 446

            /** 			case VARIABLE then*/
            case -100:

            /** 				sym_tok = SymTab[tok[T_SYM]][S_TOKEN]*/
            _2 = (int)SEQ_PTR(_tok_62762);
            _31407 = (int)*(((s1_ptr)_2)->base + 2);
            _2 = (int)SEQ_PTR(_36SymTab_15242);
            if (!IS_ATOM_INT(_31407)){
                _31408 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_31407)->dbl));
            }
            else{
                _31408 = (int)*(((s1_ptr)_2)->base + _31407);
            }
            _2 = (int)SEQ_PTR(_31408);
            if (!IS_ATOM_INT(_35S_TOKEN_15922)){
                _sym_tok_62774 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TOKEN_15922)->dbl));
            }
            else{
                _sym_tok_62774 = (int)*(((s1_ptr)_2)->base + _35S_TOKEN_15922);
            }
            if (!IS_ATOM_INT(_sym_tok_62774)){
                _sym_tok_62774 = (long)DBL_PTR(_sym_tok_62774)->dbl;
            }
            _31408 = NOVALUE;

            /** 				if SymTab[tok[T_SYM]][S_SCOPE] = SC_UNDEFINED then*/
            _2 = (int)SEQ_PTR(_tok_62762);
            _31410 = (int)*(((s1_ptr)_2)->base + 2);
            _2 = (int)SEQ_PTR(_36SymTab_15242);
            if (!IS_ATOM_INT(_31410)){
                _31411 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_31410)->dbl));
            }
            else{
                _31411 = (int)*(((s1_ptr)_2)->base + _31410);
            }
            _2 = (int)SEQ_PTR(_31411);
            _31412 = (int)*(((s1_ptr)_2)->base + 4);
            _31411 = NOVALUE;
            if (binary_op_a(NOTEQ, _31412, 9)){
                _31412 = NOVALUE;
                goto LA; // [306] 323
            }
            _31412 = NOVALUE;

            /** 					errors &= ref*/
            Append(&_errors_62743, _errors_62743, _ref_62747);

            /** 					continue*/
            DeRef(_fr_62749);
            _fr_62749 = NOVALUE;
            DeRef(_tok_62762);
            _tok_62762 = NOVALUE;
            goto L4; // [320] 476
LA: 

            /** 				switch sym_tok do*/
            _0 = _sym_tok_62774;
            switch ( _0 ){ 

                /** 					case CONSTANT, ENUM, VARIABLE then*/
                case 417:
                case 427:
                case -100:

                /** 						patch_forward_variable( tok, ref )*/
                Ref(_tok_62762);
                _38patch_forward_variable(_tok_62762, _ref_62747);

                /** 						break "fr_type"*/
                goto L9; // [346] 446
                goto L9; // [348] 446

                /** 					case else*/
                default:

                /** 						forward_error( tok, ref )*/
                Ref(_tok_62762);
                _38forward_error(_tok_62762, _ref_62747);
            ;}            goto L9; // [361] 446

            /** 			case TYPE_CHECK then*/
            case 65:

            /** 				patch_forward_type_check( tok, ref )*/
            Ref(_tok_62762);
            _38patch_forward_type_check(_tok_62762, _ref_62747);
            goto L9; // [373] 446

            /** 			case GLOBAL_INIT_CHECK then*/
            case 109:

            /** 				patch_forward_init_check( tok, ref )*/
            Ref(_tok_62762);
            _38patch_forward_init_check(_tok_62762, _ref_62747);
            goto L9; // [385] 446

            /** 			case CASE then*/
            case 186:

            /** 				patch_forward_case( tok, ref )*/
            Ref(_tok_62762);
            _38patch_forward_case(_tok_62762, _ref_62747);
            goto L9; // [397] 446

            /** 			case TYPE then*/
            case 504:

            /** 				patch_forward_type( tok, ref )*/
            Ref(_tok_62762);
            _38patch_forward_type(_tok_62762, _ref_62747);
            goto L9; // [409] 446

            /** 			case GOTO then*/
            case 188:

            /** 				patch_forward_goto( tok, ref )*/
            Ref(_tok_62762);
            _38patch_forward_goto(_tok_62762, _ref_62747);
            goto L9; // [421] 446

            /** 			case else*/
            default:

            /** 				InternalErr( 263, {fr[FR_TYPE], fr[FR_NAME]})*/
            _2 = (int)SEQ_PTR(_fr_62749);
            _31417 = (int)*(((s1_ptr)_2)->base + 1);
            _2 = (int)SEQ_PTR(_fr_62749);
            _31418 = (int)*(((s1_ptr)_2)->base + 2);
            Ref(_31418);
            Ref(_31417);
            _1 = NewS1(2);
            _2 = (int)((s1_ptr)_1)->base;
            ((int *)_2)[1] = _31417;
            ((int *)_2)[2] = _31418;
            _31419 = MAKE_SEQ(_1);
            _31418 = NOVALUE;
            _31417 = NOVALUE;
            _44InternalErr(263, _31419);
            _31419 = NOVALUE;
        ;}L9: 

        /** 		if report_errors and sequence( forward_references[ref] ) then*/
        if (_report_errors_62741 == 0) {
            goto LB; // [448] 472
        }
        _2 = (int)SEQ_PTR(_38forward_references_61501);
        _31421 = (int)*(((s1_ptr)_2)->base + _ref_62747);
        _31422 = IS_SEQUENCE(_31421);
        _31421 = NOVALUE;
        if (_31422 == 0)
        {
            _31422 = NOVALUE;
            goto LB; // [462] 472
        }
        else{
            _31422 = NOVALUE;
        }

        /** 			errors &= ref*/
        Append(&_errors_62743, _errors_62743, _ref_62747);
LB: 
        DeRef(_fr_62749);
        _fr_62749 = NOVALUE;
        DeRef(_tok_62762);
        _tok_62762 = NOVALUE;

        /** 	end for*/
L4: 
        _ar_62745 = _ar_62745 + -1;
        goto L1; // [476] 26
L2: 
        ;
    }

    /** 	return errors*/
    DeRefDS(_refs_62740);
    _31382 = NOVALUE;
    _31397 = NOVALUE;
    DeRef(_31385);
    _31385 = NOVALUE;
    DeRef(_31402);
    _31402 = NOVALUE;
    _31407 = NOVALUE;
    _31410 = NOVALUE;
    return _errors_62743;
    ;
}


int _38file_name_based_symindex_compare(int _si1_62852, int _si2_62853)
{
    int _fn1_62874 = NOVALUE;
    int _fn2_62879 = NOVALUE;
    int _31451 = NOVALUE;
    int _31450 = NOVALUE;
    int _31449 = NOVALUE;
    int _31448 = NOVALUE;
    int _31447 = NOVALUE;
    int _31446 = NOVALUE;
    int _31445 = NOVALUE;
    int _31444 = NOVALUE;
    int _31443 = NOVALUE;
    int _31442 = NOVALUE;
    int _31441 = NOVALUE;
    int _31440 = NOVALUE;
    int _31438 = NOVALUE;
    int _31436 = NOVALUE;
    int _31435 = NOVALUE;
    int _31434 = NOVALUE;
    int _31433 = NOVALUE;
    int _31432 = NOVALUE;
    int _31431 = NOVALUE;
    int _31430 = NOVALUE;
    int _31429 = NOVALUE;
    int _31428 = NOVALUE;
    int _31427 = NOVALUE;
    int _31425 = NOVALUE;
    int _31424 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_si1_62852)) {
        _1 = (long)(DBL_PTR(_si1_62852)->dbl);
        DeRefDS(_si1_62852);
        _si1_62852 = _1;
    }
    if (!IS_ATOM_INT(_si2_62853)) {
        _1 = (long)(DBL_PTR(_si2_62853)->dbl);
        DeRefDS(_si2_62853);
        _si2_62853 = _1;
    }

    /** 	if not symtab_index(si1) or not symtab_index(si2) then*/
    _31424 = _35symtab_index(_si1_62852);
    if (IS_ATOM_INT(_31424)) {
        _31425 = (_31424 == 0);
    }
    else {
        _31425 = unary_op(NOT, _31424);
    }
    DeRef(_31424);
    _31424 = NOVALUE;
    if (IS_ATOM_INT(_31425)) {
        if (_31425 != 0) {
            goto L1; // [14] 30
        }
    }
    else {
        if (DBL_PTR(_31425)->dbl != 0.0) {
            goto L1; // [14] 30
        }
    }
    _31427 = _35symtab_index(_si2_62853);
    if (IS_ATOM_INT(_31427)) {
        _31428 = (_31427 == 0);
    }
    else {
        _31428 = unary_op(NOT, _31427);
    }
    DeRef(_31427);
    _31427 = NOVALUE;
    if (_31428 == 0) {
        DeRef(_31428);
        _31428 = NOVALUE;
        goto L2; // [26] 37
    }
    else {
        if (!IS_ATOM_INT(_31428) && DBL_PTR(_31428)->dbl == 0.0){
            DeRef(_31428);
            _31428 = NOVALUE;
            goto L2; // [26] 37
        }
        DeRef(_31428);
        _31428 = NOVALUE;
    }
    DeRef(_31428);
    _31428 = NOVALUE;
L1: 

    /** 		return 1 -- put non symbols last*/
    DeRef(_31425);
    _31425 = NOVALUE;
    return 1;
L2: 

    /** 	if S_FILE_NO <= length(SymTab[si1]) and S_FILE_NO <= length(SymTab[si2]) then*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _31429 = (int)*(((s1_ptr)_2)->base + _si1_62852);
    if (IS_SEQUENCE(_31429)){
            _31430 = SEQ_PTR(_31429)->length;
    }
    else {
        _31430 = 1;
    }
    _31429 = NOVALUE;
    if (IS_ATOM_INT(_35S_FILE_NO_15913)) {
        _31431 = (_35S_FILE_NO_15913 <= _31430);
    }
    else {
        _31431 = binary_op(LESSEQ, _35S_FILE_NO_15913, _31430);
    }
    _31430 = NOVALUE;
    if (IS_ATOM_INT(_31431)) {
        if (_31431 == 0) {
            goto L3; // [54] 186
        }
    }
    else {
        if (DBL_PTR(_31431)->dbl == 0.0) {
            goto L3; // [54] 186
        }
    }
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _31433 = (int)*(((s1_ptr)_2)->base + _si2_62853);
    if (IS_SEQUENCE(_31433)){
            _31434 = SEQ_PTR(_31433)->length;
    }
    else {
        _31434 = 1;
    }
    _31433 = NOVALUE;
    if (IS_ATOM_INT(_35S_FILE_NO_15913)) {
        _31435 = (_35S_FILE_NO_15913 <= _31434);
    }
    else {
        _31435 = binary_op(LESSEQ, _35S_FILE_NO_15913, _31434);
    }
    _31434 = NOVALUE;
    if (_31435 == 0) {
        DeRef(_31435);
        _31435 = NOVALUE;
        goto L3; // [74] 186
    }
    else {
        if (!IS_ATOM_INT(_31435) && DBL_PTR(_31435)->dbl == 0.0){
            DeRef(_31435);
            _31435 = NOVALUE;
            goto L3; // [74] 186
        }
        DeRef(_31435);
        _31435 = NOVALUE;
    }
    DeRef(_31435);
    _31435 = NOVALUE;

    /** 		integer fn1 = SymTab[si1][S_FILE_NO], fn2 = SymTab[si2][S_FILE_NO]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _31436 = (int)*(((s1_ptr)_2)->base + _si1_62852);
    _2 = (int)SEQ_PTR(_31436);
    if (!IS_ATOM_INT(_35S_FILE_NO_15913)){
        _fn1_62874 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FILE_NO_15913)->dbl));
    }
    else{
        _fn1_62874 = (int)*(((s1_ptr)_2)->base + _35S_FILE_NO_15913);
    }
    if (!IS_ATOM_INT(_fn1_62874)){
        _fn1_62874 = (long)DBL_PTR(_fn1_62874)->dbl;
    }
    _31436 = NOVALUE;
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _31438 = (int)*(((s1_ptr)_2)->base + _si2_62853);
    _2 = (int)SEQ_PTR(_31438);
    if (!IS_ATOM_INT(_35S_FILE_NO_15913)){
        _fn2_62879 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FILE_NO_15913)->dbl));
    }
    else{
        _fn2_62879 = (int)*(((s1_ptr)_2)->base + _35S_FILE_NO_15913);
    }
    if (!IS_ATOM_INT(_fn2_62879)){
        _fn2_62879 = (long)DBL_PTR(_fn2_62879)->dbl;
    }
    _31438 = NOVALUE;

    /** 		if find(1,{fn1,fn2} > length(known_files) or {fn1,fn2} <= 0) then*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _fn1_62874;
    ((int *)_2)[2] = _fn2_62879;
    _31440 = MAKE_SEQ(_1);
    if (IS_SEQUENCE(_36known_files_15243)){
            _31441 = SEQ_PTR(_36known_files_15243)->length;
    }
    else {
        _31441 = 1;
    }
    _31442 = binary_op(GREATER, _31440, _31441);
    DeRefDS(_31440);
    _31440 = NOVALUE;
    _31441 = NOVALUE;
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _fn1_62874;
    ((int *)_2)[2] = _fn2_62879;
    _31443 = MAKE_SEQ(_1);
    _31444 = binary_op(LESSEQ, _31443, 0);
    DeRefDS(_31443);
    _31443 = NOVALUE;
    _31445 = binary_op(OR, _31442, _31444);
    DeRefDS(_31442);
    _31442 = NOVALUE;
    DeRefDS(_31444);
    _31444 = NOVALUE;
    _31446 = find_from(1, _31445, 1);
    DeRefDS(_31445);
    _31445 = NOVALUE;
    if (_31446 == 0)
    {
        _31446 = NOVALUE;
        goto L4; // [139] 149
    }
    else{
        _31446 = NOVALUE;
    }

    /** 			return 1*/
    DeRef(_31425);
    _31425 = NOVALUE;
    _31429 = NOVALUE;
    DeRef(_31431);
    _31431 = NOVALUE;
    _31433 = NOVALUE;
    return 1;
L4: 

    /** 		return compare(abbreviate_path(known_files[fn1]),*/
    _2 = (int)SEQ_PTR(_36known_files_15243);
    _31447 = (int)*(((s1_ptr)_2)->base + _fn1_62874);
    Ref(_31447);
    RefDS(_22023);
    _31448 = _17abbreviate_path(_31447, _22023);
    _31447 = NOVALUE;
    _2 = (int)SEQ_PTR(_36known_files_15243);
    _31449 = (int)*(((s1_ptr)_2)->base + _fn2_62879);
    Ref(_31449);
    RefDS(_22023);
    _31450 = _17abbreviate_path(_31449, _22023);
    _31449 = NOVALUE;
    if (IS_ATOM_INT(_31448) && IS_ATOM_INT(_31450)){
        _31451 = (_31448 < _31450) ? -1 : (_31448 > _31450);
    }
    else{
        _31451 = compare(_31448, _31450);
    }
    DeRef(_31448);
    _31448 = NOVALUE;
    DeRef(_31450);
    _31450 = NOVALUE;
    DeRef(_31425);
    _31425 = NOVALUE;
    _31429 = NOVALUE;
    DeRef(_31431);
    _31431 = NOVALUE;
    _31433 = NOVALUE;
    return _31451;
    goto L5; // [183] 193
L3: 

    /** 		return 1 -- put non-names last*/
    DeRef(_31425);
    _31425 = NOVALUE;
    _31429 = NOVALUE;
    DeRef(_31431);
    _31431 = NOVALUE;
    _31433 = NOVALUE;
    return 1;
L5: 
    ;
}


void _38Resolve_forward_references(int _report_errors_62905)
{
    int _errors_62906 = NOVALUE;
    int _unincluded_ok_62907 = NOVALUE;
    int _msg_62968 = NOVALUE;
    int _errloc_62969 = NOVALUE;
    int _ref_62974 = NOVALUE;
    int _tok_62990 = NOVALUE;
    int _THIS_SCOPE_62992 = NOVALUE;
    int _THESE_GLOBALS_62993 = NOVALUE;
    int _syms_63051 = NOVALUE;
    int _s_63072 = NOVALUE;
    int _31582 = NOVALUE;
    int _31580 = NOVALUE;
    int _31575 = NOVALUE;
    int _31572 = NOVALUE;
    int _31570 = NOVALUE;
    int _31569 = NOVALUE;
    int _31568 = NOVALUE;
    int _31567 = NOVALUE;
    int _31566 = NOVALUE;
    int _31565 = NOVALUE;
    int _31564 = NOVALUE;
    int _31562 = NOVALUE;
    int _31561 = NOVALUE;
    int _31560 = NOVALUE;
    int _31558 = NOVALUE;
    int _31556 = NOVALUE;
    int _31555 = NOVALUE;
    int _31554 = NOVALUE;
    int _31553 = NOVALUE;
    int _31552 = NOVALUE;
    int _31551 = NOVALUE;
    int _31548 = NOVALUE;
    int _31544 = NOVALUE;
    int _31543 = NOVALUE;
    int _31542 = NOVALUE;
    int _31541 = NOVALUE;
    int _31540 = NOVALUE;
    int _31539 = NOVALUE;
    int _31536 = NOVALUE;
    int _31535 = NOVALUE;
    int _31534 = NOVALUE;
    int _31533 = NOVALUE;
    int _31532 = NOVALUE;
    int _31531 = NOVALUE;
    int _31528 = NOVALUE;
    int _31527 = NOVALUE;
    int _31526 = NOVALUE;
    int _31525 = NOVALUE;
    int _31524 = NOVALUE;
    int _31523 = NOVALUE;
    int _31522 = NOVALUE;
    int _31521 = NOVALUE;
    int _31520 = NOVALUE;
    int _31519 = NOVALUE;
    int _31516 = NOVALUE;
    int _31514 = NOVALUE;
    int _31511 = NOVALUE;
    int _31509 = NOVALUE;
    int _31507 = NOVALUE;
    int _31506 = NOVALUE;
    int _31504 = NOVALUE;
    int _31503 = NOVALUE;
    int _31502 = NOVALUE;
    int _31501 = NOVALUE;
    int _31500 = NOVALUE;
    int _31498 = NOVALUE;
    int _31497 = NOVALUE;
    int _31495 = NOVALUE;
    int _31494 = NOVALUE;
    int _31492 = NOVALUE;
    int _31491 = NOVALUE;
    int _31489 = NOVALUE;
    int _31488 = NOVALUE;
    int _31487 = NOVALUE;
    int _31486 = NOVALUE;
    int _31485 = NOVALUE;
    int _31484 = NOVALUE;
    int _31483 = NOVALUE;
    int _31482 = NOVALUE;
    int _31481 = NOVALUE;
    int _31480 = NOVALUE;
    int _31479 = NOVALUE;
    int _31478 = NOVALUE;
    int _31477 = NOVALUE;
    int _31476 = NOVALUE;
    int _31475 = NOVALUE;
    int _31474 = NOVALUE;
    int _31472 = NOVALUE;
    int _31471 = NOVALUE;
    int _31470 = NOVALUE;
    int _31469 = NOVALUE;
    int _31467 = NOVALUE;
    int _31466 = NOVALUE;
    int _31464 = NOVALUE;
    int _31463 = NOVALUE;
    int _31462 = NOVALUE;
    int _31461 = NOVALUE;
    int _31459 = NOVALUE;
    int _31458 = NOVALUE;
    int _31457 = NOVALUE;
    int _31456 = NOVALUE;
    int _31454 = NOVALUE;
    int _31453 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_report_errors_62905)) {
        _1 = (long)(DBL_PTR(_report_errors_62905)->dbl);
        DeRefDS(_report_errors_62905);
        _report_errors_62905 = _1;
    }

    /** 	sequence errors = {}*/
    RefDS(_22023);
    DeRef(_errors_62906);
    _errors_62906 = _22023;

    /** 	integer unincluded_ok = get_resolve_unincluded_globals()*/
    _unincluded_ok_62907 = _53get_resolve_unincluded_globals();
    if (!IS_ATOM_INT(_unincluded_ok_62907)) {
        _1 = (long)(DBL_PTR(_unincluded_ok_62907)->dbl);
        DeRefDS(_unincluded_ok_62907);
        _unincluded_ok_62907 = _1;
    }

    /** 	if length( active_references ) < length( known_files ) then*/
    if (IS_SEQUENCE(_38active_references_61503)){
            _31453 = SEQ_PTR(_38active_references_61503)->length;
    }
    else {
        _31453 = 1;
    }
    if (IS_SEQUENCE(_36known_files_15243)){
            _31454 = SEQ_PTR(_36known_files_15243)->length;
    }
    else {
        _31454 = 1;
    }
    if (_31453 >= _31454)
    goto L1; // [29] 86

    /** 		active_references &= repeat( {}, length( known_files ) - length( active_references ) )*/
    if (IS_SEQUENCE(_36known_files_15243)){
            _31456 = SEQ_PTR(_36known_files_15243)->length;
    }
    else {
        _31456 = 1;
    }
    if (IS_SEQUENCE(_38active_references_61503)){
            _31457 = SEQ_PTR(_38active_references_61503)->length;
    }
    else {
        _31457 = 1;
    }
    _31458 = _31456 - _31457;
    _31456 = NOVALUE;
    _31457 = NOVALUE;
    _31459 = Repeat(_22023, _31458);
    _31458 = NOVALUE;
    Concat((object_ptr)&_38active_references_61503, _38active_references_61503, _31459);
    DeRefDS(_31459);
    _31459 = NOVALUE;

    /** 		active_subprogs   &= repeat( {}, length( known_files ) - length( active_subprogs ) )*/
    if (IS_SEQUENCE(_36known_files_15243)){
            _31461 = SEQ_PTR(_36known_files_15243)->length;
    }
    else {
        _31461 = 1;
    }
    if (IS_SEQUENCE(_38active_subprogs_61502)){
            _31462 = SEQ_PTR(_38active_subprogs_61502)->length;
    }
    else {
        _31462 = 1;
    }
    _31463 = _31461 - _31462;
    _31461 = NOVALUE;
    _31462 = NOVALUE;
    _31464 = Repeat(_22023, _31463);
    _31463 = NOVALUE;
    Concat((object_ptr)&_38active_subprogs_61502, _38active_subprogs_61502, _31464);
    DeRefDS(_31464);
    _31464 = NOVALUE;
L1: 

    /** 	if length( toplevel_references ) < length( known_files ) then*/
    if (IS_SEQUENCE(_38toplevel_references_61504)){
            _31466 = SEQ_PTR(_38toplevel_references_61504)->length;
    }
    else {
        _31466 = 1;
    }
    if (IS_SEQUENCE(_36known_files_15243)){
            _31467 = SEQ_PTR(_36known_files_15243)->length;
    }
    else {
        _31467 = 1;
    }
    if (_31466 >= _31467)
    goto L2; // [98] 129

    /** 		toplevel_references &= repeat( {}, length( known_files ) - length( toplevel_references ) )*/
    if (IS_SEQUENCE(_36known_files_15243)){
            _31469 = SEQ_PTR(_36known_files_15243)->length;
    }
    else {
        _31469 = 1;
    }
    if (IS_SEQUENCE(_38toplevel_references_61504)){
            _31470 = SEQ_PTR(_38toplevel_references_61504)->length;
    }
    else {
        _31470 = 1;
    }
    _31471 = _31469 - _31470;
    _31469 = NOVALUE;
    _31470 = NOVALUE;
    _31472 = Repeat(_22023, _31471);
    _31471 = NOVALUE;
    Concat((object_ptr)&_38toplevel_references_61504, _38toplevel_references_61504, _31472);
    DeRefDS(_31472);
    _31472 = NOVALUE;
L2: 

    /** 	for i = 1 to length( active_subprogs ) do*/
    if (IS_SEQUENCE(_38active_subprogs_61502)){
            _31474 = SEQ_PTR(_38active_subprogs_61502)->length;
    }
    else {
        _31474 = 1;
    }
    {
        int _i_62939;
        _i_62939 = 1;
L3: 
        if (_i_62939 > _31474){
            goto L4; // [136] 280
        }

        /** 		if (length( active_subprogs[i] ) or length(toplevel_references[i])) */
        _2 = (int)SEQ_PTR(_38active_subprogs_61502);
        _31475 = (int)*(((s1_ptr)_2)->base + _i_62939);
        if (IS_SEQUENCE(_31475)){
                _31476 = SEQ_PTR(_31475)->length;
        }
        else {
            _31476 = 1;
        }
        _31475 = NOVALUE;
        if (_31476 != 0) {
            _31477 = 1;
            goto L5; // [154] 171
        }
        _2 = (int)SEQ_PTR(_38toplevel_references_61504);
        _31478 = (int)*(((s1_ptr)_2)->base + _i_62939);
        if (IS_SEQUENCE(_31478)){
                _31479 = SEQ_PTR(_31478)->length;
        }
        else {
            _31479 = 1;
        }
        _31478 = NOVALUE;
        _31477 = (_31479 != 0);
L5: 
        if (_31477 == 0) {
            goto L6; // [171] 273
        }
        _31481 = (_i_62939 == _35current_file_no_16244);
        if (_31481 != 0) {
            _31482 = 1;
            goto L7; // [181] 195
        }
        _2 = (int)SEQ_PTR(_36finished_files_15245);
        _31483 = (int)*(((s1_ptr)_2)->base + _i_62939);
        _31482 = (_31483 != 0);
L7: 
        if (_31482 != 0) {
            DeRef(_31484);
            _31484 = 1;
            goto L8; // [195] 203
        }
        _31484 = (_unincluded_ok_62907 != 0);
L8: 
        if (_31484 == 0)
        {
            _31484 = NOVALUE;
            goto L6; // [204] 273
        }
        else{
            _31484 = NOVALUE;
        }

        /** 			for j = length( active_references[i] ) to 1 by -1 do*/
        _2 = (int)SEQ_PTR(_38active_references_61503);
        _31485 = (int)*(((s1_ptr)_2)->base + _i_62939);
        if (IS_SEQUENCE(_31485)){
                _31486 = SEQ_PTR(_31485)->length;
        }
        else {
            _31486 = 1;
        }
        _31485 = NOVALUE;
        {
            int _j_62955;
            _j_62955 = _31486;
L9: 
            if (_j_62955 < 1){
                goto LA; // [218] 254
            }

            /** 				errors &= resolve_file( active_references[i][j], report_errors, unincluded_ok )*/
            _2 = (int)SEQ_PTR(_38active_references_61503);
            _31487 = (int)*(((s1_ptr)_2)->base + _i_62939);
            _2 = (int)SEQ_PTR(_31487);
            _31488 = (int)*(((s1_ptr)_2)->base + _j_62955);
            _31487 = NOVALUE;
            Ref(_31488);
            _31489 = _38resolve_file(_31488, _report_errors_62905, _unincluded_ok_62907);
            _31488 = NOVALUE;
            if (IS_SEQUENCE(_errors_62906) && IS_ATOM(_31489)) {
                Ref(_31489);
                Append(&_errors_62906, _errors_62906, _31489);
            }
            else if (IS_ATOM(_errors_62906) && IS_SEQUENCE(_31489)) {
            }
            else {
                Concat((object_ptr)&_errors_62906, _errors_62906, _31489);
            }
            DeRef(_31489);
            _31489 = NOVALUE;

            /** 			end for*/
            _j_62955 = _j_62955 + -1;
            goto L9; // [249] 225
LA: 
            ;
        }

        /** 			errors &= resolve_file( toplevel_references[i], report_errors, unincluded_ok )*/
        _2 = (int)SEQ_PTR(_38toplevel_references_61504);
        _31491 = (int)*(((s1_ptr)_2)->base + _i_62939);
        Ref(_31491);
        _31492 = _38resolve_file(_31491, _report_errors_62905, _unincluded_ok_62907);
        _31491 = NOVALUE;
        if (IS_SEQUENCE(_errors_62906) && IS_ATOM(_31492)) {
            Ref(_31492);
            Append(&_errors_62906, _errors_62906, _31492);
        }
        else if (IS_ATOM(_errors_62906) && IS_SEQUENCE(_31492)) {
        }
        else {
            Concat((object_ptr)&_errors_62906, _errors_62906, _31492);
        }
        DeRef(_31492);
        _31492 = NOVALUE;
L6: 

        /** 	end for*/
        _i_62939 = _i_62939 + 1;
        goto L3; // [275] 143
L4: 
        ;
    }

    /** 	if report_errors and length( errors ) then*/
    if (_report_errors_62905 == 0) {
        goto LB; // [282] 854
    }
    if (IS_SEQUENCE(_errors_62906)){
            _31495 = SEQ_PTR(_errors_62906)->length;
    }
    else {
        _31495 = 1;
    }
    if (_31495 == 0)
    {
        _31495 = NOVALUE;
        goto LB; // [290] 854
    }
    else{
        _31495 = NOVALUE;
    }

    /** 		sequence msg = ""*/
    RefDS(_22023);
    DeRefi(_msg_62968);
    _msg_62968 = _22023;

    /** 		sequence errloc = "Internal Error - Unknown Error Message"*/
    RefDS(_31496);
    DeRefi(_errloc_62969);
    _errloc_62969 = _31496;

    /** 		for e = length(errors) to 1 by -1 do*/
    if (IS_SEQUENCE(_errors_62906)){
            _31497 = SEQ_PTR(_errors_62906)->length;
    }
    else {
        _31497 = 1;
    }
    {
        int _e_62972;
        _e_62972 = _31497;
LC: 
        if (_e_62972 < 1){
            goto LD; // [312] 828
        }

        /** 			sequence ref = forward_references[errors[e]]*/
        _2 = (int)SEQ_PTR(_errors_62906);
        _31498 = (int)*(((s1_ptr)_2)->base + _e_62972);
        DeRef(_ref_62974);
        _2 = (int)SEQ_PTR(_38forward_references_61501);
        if (!IS_ATOM_INT(_31498)){
            _ref_62974 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_31498)->dbl));
        }
        else{
            _ref_62974 = (int)*(((s1_ptr)_2)->base + _31498);
        }
        Ref(_ref_62974);

        /** 			if (ref[FR_TYPE] = TYPE_CHECK and ref[FR_OP] = TYPE_CHECK) or ref[FR_TYPE] = GLOBAL_INIT_CHECK then*/
        _2 = (int)SEQ_PTR(_ref_62974);
        _31500 = (int)*(((s1_ptr)_2)->base + 1);
        if (IS_ATOM_INT(_31500)) {
            _31501 = (_31500 == 65);
        }
        else {
            _31501 = binary_op(EQUALS, _31500, 65);
        }
        _31500 = NOVALUE;
        if (IS_ATOM_INT(_31501)) {
            if (_31501 == 0) {
                DeRef(_31502);
                _31502 = 0;
                goto LE; // [345] 363
            }
        }
        else {
            if (DBL_PTR(_31501)->dbl == 0.0) {
                DeRef(_31502);
                _31502 = 0;
                goto LE; // [345] 363
            }
        }
        _2 = (int)SEQ_PTR(_ref_62974);
        _31503 = (int)*(((s1_ptr)_2)->base + 10);
        if (IS_ATOM_INT(_31503)) {
            _31504 = (_31503 == 65);
        }
        else {
            _31504 = binary_op(EQUALS, _31503, 65);
        }
        _31503 = NOVALUE;
        DeRef(_31502);
        if (IS_ATOM_INT(_31504))
        _31502 = (_31504 != 0);
        else
        _31502 = DBL_PTR(_31504)->dbl != 0.0;
LE: 
        if (_31502 != 0) {
            goto LF; // [363] 382
        }
        _2 = (int)SEQ_PTR(_ref_62974);
        _31506 = (int)*(((s1_ptr)_2)->base + 1);
        if (IS_ATOM_INT(_31506)) {
            _31507 = (_31506 == 109);
        }
        else {
            _31507 = binary_op(EQUALS, _31506, 109);
        }
        _31506 = NOVALUE;
        if (_31507 == 0) {
            DeRef(_31507);
            _31507 = NOVALUE;
            goto L10; // [378] 391
        }
        else {
            if (!IS_ATOM_INT(_31507) && DBL_PTR(_31507)->dbl == 0.0){
                DeRef(_31507);
                _31507 = NOVALUE;
                goto L10; // [378] 391
            }
            DeRef(_31507);
            _31507 = NOVALUE;
        }
        DeRef(_31507);
        _31507 = NOVALUE;
LF: 

        /** 				continue*/
        DeRef(_ref_62974);
        _ref_62974 = NOVALUE;
        goto L11; // [386] 823
        goto L12; // [388] 789
L10: 

        /** 				object tok = find_reference(ref)*/
        RefDS(_ref_62974);
        _0 = _tok_62990;
        _tok_62990 = _38find_reference(_ref_62974);
        DeRef(_0);

        /** 				integer THIS_SCOPE = 3*/
        _THIS_SCOPE_62992 = 3;

        /** 				integer THESE_GLOBALS = 4*/
        _THESE_GLOBALS_62993 = 4;

        /** 				if tok[T_ID] = IGNORED then*/
        _2 = (int)SEQ_PTR(_tok_62990);
        _31509 = (int)*(((s1_ptr)_2)->base + 1);
        if (binary_op_a(NOTEQ, _31509, 509)){
            _31509 = NOVALUE;
            goto L13; // [417] 760
        }
        _31509 = NOVALUE;

        /** 					switch tok[THIS_SCOPE] do*/
        _2 = (int)SEQ_PTR(_tok_62990);
        _31511 = (int)*(((s1_ptr)_2)->base + 3);
        if (IS_SEQUENCE(_31511) ){
            goto L14; // [427] 756
        }
        if(!IS_ATOM_INT(_31511)){
            if( (DBL_PTR(_31511)->dbl != (double) ((int) DBL_PTR(_31511)->dbl) ) ){
                goto L14; // [427] 756
            }
            _0 = (int) DBL_PTR(_31511)->dbl;
        }
        else {
            _0 = _31511;
        };
        _31511 = NOVALUE;
        switch ( _0 ){ 

            /** 						case SC_UNDEFINED then*/
            case 9:

            /** 							if ref[FR_QUALIFIED] != -1 then*/
            _2 = (int)SEQ_PTR(_ref_62974);
            _31514 = (int)*(((s1_ptr)_2)->base + 9);
            if (binary_op_a(EQUALS, _31514, -1)){
                _31514 = NOVALUE;
                goto L15; // [442] 556
            }
            _31514 = NOVALUE;

            /** 								if ref[FR_QUALIFIED] > 0 then*/
            _2 = (int)SEQ_PTR(_ref_62974);
            _31516 = (int)*(((s1_ptr)_2)->base + 9);
            if (binary_op_a(LESSEQ, _31516, 0)){
                _31516 = NOVALUE;
                goto L16; // [452] 517
            }
            _31516 = NOVALUE;

            /** 									errloc = sprintf("\t\'%s\' (%s:%d) was not declared in \'%s\'.\n", */
            _2 = (int)SEQ_PTR(_ref_62974);
            _31519 = (int)*(((s1_ptr)_2)->base + 2);
            _2 = (int)SEQ_PTR(_ref_62974);
            _31520 = (int)*(((s1_ptr)_2)->base + 3);
            _2 = (int)SEQ_PTR(_36known_files_15243);
            if (!IS_ATOM_INT(_31520)){
                _31521 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_31520)->dbl));
            }
            else{
                _31521 = (int)*(((s1_ptr)_2)->base + _31520);
            }
            Ref(_31521);
            RefDS(_22023);
            _31522 = _17abbreviate_path(_31521, _22023);
            _31521 = NOVALUE;
            _2 = (int)SEQ_PTR(_ref_62974);
            _31523 = (int)*(((s1_ptr)_2)->base + 6);
            _2 = (int)SEQ_PTR(_ref_62974);
            _31524 = (int)*(((s1_ptr)_2)->base + 9);
            _2 = (int)SEQ_PTR(_36known_files_15243);
            if (!IS_ATOM_INT(_31524)){
                _31525 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_31524)->dbl));
            }
            else{
                _31525 = (int)*(((s1_ptr)_2)->base + _31524);
            }
            Ref(_31525);
            RefDS(_22023);
            _31526 = _17abbreviate_path(_31525, _22023);
            _31525 = NOVALUE;
            _31527 = _16find_replace(92, _31526, 47, 0);
            _31526 = NOVALUE;
            _1 = NewS1(4);
            _2 = (int)((s1_ptr)_1)->base;
            Ref(_31519);
            *((int *)(_2+4)) = _31519;
            *((int *)(_2+8)) = _31522;
            Ref(_31523);
            *((int *)(_2+12)) = _31523;
            *((int *)(_2+16)) = _31527;
            _31528 = MAKE_SEQ(_1);
            _31527 = NOVALUE;
            _31523 = NOVALUE;
            _31522 = NOVALUE;
            _31519 = NOVALUE;
            DeRefi(_errloc_62969);
            _errloc_62969 = EPrintf(-9999999, _31518, _31528);
            DeRefDS(_31528);
            _31528 = NOVALUE;
            goto L17; // [514] 759
L16: 

            /** 									errloc = sprintf("\t\'%s\' (%s:%d) is not a builtin.\n", */
            _2 = (int)SEQ_PTR(_ref_62974);
            _31531 = (int)*(((s1_ptr)_2)->base + 2);
            _2 = (int)SEQ_PTR(_ref_62974);
            _31532 = (int)*(((s1_ptr)_2)->base + 3);
            _2 = (int)SEQ_PTR(_36known_files_15243);
            if (!IS_ATOM_INT(_31532)){
                _31533 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_31532)->dbl));
            }
            else{
                _31533 = (int)*(((s1_ptr)_2)->base + _31532);
            }
            Ref(_31533);
            RefDS(_22023);
            _31534 = _17abbreviate_path(_31533, _22023);
            _31533 = NOVALUE;
            _2 = (int)SEQ_PTR(_ref_62974);
            _31535 = (int)*(((s1_ptr)_2)->base + 6);
            _1 = NewS1(3);
            _2 = (int)((s1_ptr)_1)->base;
            Ref(_31531);
            *((int *)(_2+4)) = _31531;
            *((int *)(_2+8)) = _31534;
            Ref(_31535);
            *((int *)(_2+12)) = _31535;
            _31536 = MAKE_SEQ(_1);
            _31535 = NOVALUE;
            _31534 = NOVALUE;
            _31531 = NOVALUE;
            DeRefi(_errloc_62969);
            _errloc_62969 = EPrintf(-9999999, _31530, _31536);
            DeRefDS(_31536);
            _31536 = NOVALUE;
            goto L17; // [553] 759
L15: 

            /** 								errloc = sprintf("\t\'%s\' (%s:%d) has not been declared.\n", */
            _2 = (int)SEQ_PTR(_ref_62974);
            _31539 = (int)*(((s1_ptr)_2)->base + 2);
            _2 = (int)SEQ_PTR(_ref_62974);
            _31540 = (int)*(((s1_ptr)_2)->base + 3);
            _2 = (int)SEQ_PTR(_36known_files_15243);
            if (!IS_ATOM_INT(_31540)){
                _31541 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_31540)->dbl));
            }
            else{
                _31541 = (int)*(((s1_ptr)_2)->base + _31540);
            }
            Ref(_31541);
            RefDS(_22023);
            _31542 = _17abbreviate_path(_31541, _22023);
            _31541 = NOVALUE;
            _2 = (int)SEQ_PTR(_ref_62974);
            _31543 = (int)*(((s1_ptr)_2)->base + 6);
            _1 = NewS1(3);
            _2 = (int)((s1_ptr)_1)->base;
            Ref(_31539);
            *((int *)(_2+4)) = _31539;
            *((int *)(_2+8)) = _31542;
            Ref(_31543);
            *((int *)(_2+12)) = _31543;
            _31544 = MAKE_SEQ(_1);
            _31543 = NOVALUE;
            _31542 = NOVALUE;
            _31539 = NOVALUE;
            DeRefi(_errloc_62969);
            _errloc_62969 = EPrintf(-9999999, _31538, _31544);
            DeRefDS(_31544);
            _31544 = NOVALUE;
            goto L17; // [592] 759

            /** 						case SC_MULTIPLY_DEFINED then*/
            case 10:

            /** 							sequence syms = tok[THESE_GLOBALS] -- there should be no forward references in here.*/
            DeRef(_syms_63051);
            _2 = (int)SEQ_PTR(_tok_62990);
            _syms_63051 = (int)*(((s1_ptr)_2)->base + _THESE_GLOBALS_62993);
            Ref(_syms_63051);

            /** 							syms = custom_sort(routine_id("file_name_based_symindex_compare"), syms,, ASCENDING)*/
            _31548 = CRoutineId(1339, 38, _31547);
            RefDS(_syms_63051);
            RefDS(_22023);
            _0 = _syms_63051;
            _syms_63051 = _24custom_sort(_31548, _syms_63051, _22023, 1);
            DeRefDS(_0);
            _31548 = NOVALUE;

            /** 							errloc = sprintf("\t\'%s\' (%s:%d) has been declared more than once.\n", */
            _2 = (int)SEQ_PTR(_ref_62974);
            _31551 = (int)*(((s1_ptr)_2)->base + 2);
            _2 = (int)SEQ_PTR(_ref_62974);
            _31552 = (int)*(((s1_ptr)_2)->base + 3);
            _2 = (int)SEQ_PTR(_36known_files_15243);
            if (!IS_ATOM_INT(_31552)){
                _31553 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_31552)->dbl));
            }
            else{
                _31553 = (int)*(((s1_ptr)_2)->base + _31552);
            }
            Ref(_31553);
            RefDS(_22023);
            _31554 = _17abbreviate_path(_31553, _22023);
            _31553 = NOVALUE;
            _2 = (int)SEQ_PTR(_ref_62974);
            _31555 = (int)*(((s1_ptr)_2)->base + 6);
            _1 = NewS1(3);
            _2 = (int)((s1_ptr)_1)->base;
            Ref(_31551);
            *((int *)(_2+4)) = _31551;
            *((int *)(_2+8)) = _31554;
            Ref(_31555);
            *((int *)(_2+12)) = _31555;
            _31556 = MAKE_SEQ(_1);
            _31555 = NOVALUE;
            _31554 = NOVALUE;
            _31551 = NOVALUE;
            DeRefi(_errloc_62969);
            _errloc_62969 = EPrintf(-9999999, _31550, _31556);
            DeRefDS(_31556);
            _31556 = NOVALUE;

            /** 							for si = 1 to length(syms) do*/
            if (IS_SEQUENCE(_syms_63051)){
                    _31558 = SEQ_PTR(_syms_63051)->length;
            }
            else {
                _31558 = 1;
            }
            {
                int _si_63069;
                _si_63069 = 1;
L18: 
                if (_si_63069 > _31558){
                    goto L19; // [664] 750
                }

                /** 								symtab_index s = syms[si] */
                _2 = (int)SEQ_PTR(_syms_63051);
                _s_63072 = (int)*(((s1_ptr)_2)->base + _si_63069);
                if (!IS_ATOM_INT(_s_63072)){
                    _s_63072 = (long)DBL_PTR(_s_63072)->dbl;
                }

                /** 								if equal(ref[FR_NAME], sym_name(s)) then*/
                _2 = (int)SEQ_PTR(_ref_62974);
                _31560 = (int)*(((s1_ptr)_2)->base + 2);
                _31561 = _53sym_name(_s_63072);
                if (_31560 == _31561)
                _31562 = 1;
                else if (IS_ATOM_INT(_31560) && IS_ATOM_INT(_31561))
                _31562 = 0;
                else
                _31562 = (compare(_31560, _31561) == 0);
                _31560 = NOVALUE;
                DeRef(_31561);
                _31561 = NOVALUE;
                if (_31562 == 0)
                {
                    _31562 = NOVALUE;
                    goto L1A; // [693] 741
                }
                else{
                    _31562 = NOVALUE;
                }

                /** 									errloc &= sprintf("\t\tin %s\n", */
                _2 = (int)SEQ_PTR(_36SymTab_15242);
                _31564 = (int)*(((s1_ptr)_2)->base + _s_63072);
                _2 = (int)SEQ_PTR(_31564);
                if (!IS_ATOM_INT(_35S_FILE_NO_15913)){
                    _31565 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FILE_NO_15913)->dbl));
                }
                else{
                    _31565 = (int)*(((s1_ptr)_2)->base + _35S_FILE_NO_15913);
                }
                _31564 = NOVALUE;
                _2 = (int)SEQ_PTR(_36known_files_15243);
                if (!IS_ATOM_INT(_31565)){
                    _31566 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_31565)->dbl));
                }
                else{
                    _31566 = (int)*(((s1_ptr)_2)->base + _31565);
                }
                Ref(_31566);
                RefDS(_22023);
                _31567 = _17abbreviate_path(_31566, _22023);
                _31566 = NOVALUE;
                _31568 = _16find_replace(92, _31567, 47, 0);
                _31567 = NOVALUE;
                _1 = NewS1(1);
                _2 = (int)((s1_ptr)_1)->base;
                *((int *)(_2+4)) = _31568;
                _31569 = MAKE_SEQ(_1);
                _31568 = NOVALUE;
                _31570 = EPrintf(-9999999, _31563, _31569);
                DeRefDS(_31569);
                _31569 = NOVALUE;
                Concat((object_ptr)&_errloc_62969, _errloc_62969, _31570);
                DeRefDS(_31570);
                _31570 = NOVALUE;
L1A: 

                /** 							end for*/
                _si_63069 = _si_63069 + 1;
                goto L18; // [745] 671
L19: 
                ;
            }
            DeRef(_syms_63051);
            _syms_63051 = NOVALUE;
            goto L17; // [752] 759

            /** 						case else */
            default:
L14: 
        ;}L17: 
L13: 

        /** 				if not match(errloc, msg) then*/
        _31572 = e_match_from(_errloc_62969, _msg_62968, 1);
        if (_31572 != 0)
        goto L1B; // [767] 786
        _31572 = NOVALUE;

        /** 					msg &= errloc*/
        Concat((object_ptr)&_msg_62968, _msg_62968, _errloc_62969);

        /** 					prep_forward_error( errors[e] )*/
        _2 = (int)SEQ_PTR(_errors_62906);
        _31575 = (int)*(((s1_ptr)_2)->base + _e_62972);
        Ref(_31575);
        _38prep_forward_error(_31575);
        _31575 = NOVALUE;
L1B: 
        DeRef(_tok_62990);
        _tok_62990 = NOVALUE;
L12: 

        /** 			ThisLine    = ref[FR_THISLINE]*/
        DeRef(_44ThisLine_48518);
        _2 = (int)SEQ_PTR(_ref_62974);
        _44ThisLine_48518 = (int)*(((s1_ptr)_2)->base + 7);
        Ref(_44ThisLine_48518);

        /** 			bp          = ref[FR_BP]*/
        _2 = (int)SEQ_PTR(_ref_62974);
        _44bp_48522 = (int)*(((s1_ptr)_2)->base + 8);
        if (!IS_ATOM_INT(_44bp_48522)){
            _44bp_48522 = (long)DBL_PTR(_44bp_48522)->dbl;
        }

        /** 			CurrentSub  = ref[FR_SUBPROG]*/
        _2 = (int)SEQ_PTR(_ref_62974);
        _35CurrentSub_16252 = (int)*(((s1_ptr)_2)->base + 4);
        if (!IS_ATOM_INT(_35CurrentSub_16252)){
            _35CurrentSub_16252 = (long)DBL_PTR(_35CurrentSub_16252)->dbl;
        }

        /** 			line_number = ref[FR_LINE]*/
        _2 = (int)SEQ_PTR(_ref_62974);
        _35line_number_16245 = (int)*(((s1_ptr)_2)->base + 6);
        if (!IS_ATOM_INT(_35line_number_16245)){
            _35line_number_16245 = (long)DBL_PTR(_35line_number_16245)->dbl;
        }
        DeRefDS(_ref_62974);
        _ref_62974 = NOVALUE;

        /** 		end for*/
L11: 
        _e_62972 = _e_62972 + -1;
        goto LC; // [823] 319
LD: 
        ;
    }

    /** 		if length(msg) > 0 then*/
    if (IS_SEQUENCE(_msg_62968)){
            _31580 = SEQ_PTR(_msg_62968)->length;
    }
    else {
        _31580 = 1;
    }
    if (_31580 <= 0)
    goto L1C; // [833] 849

    /** 			CompileErr( 74, {msg} )*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_msg_62968);
    *((int *)(_2+4)) = _msg_62968;
    _31582 = MAKE_SEQ(_1);
    _44CompileErr(74, _31582, 0);
    _31582 = NOVALUE;
L1C: 
    DeRefi(_msg_62968);
    _msg_62968 = NOVALUE;
    DeRefi(_errloc_62969);
    _errloc_62969 = NOVALUE;
    goto L1D; // [851] 889
LB: 

    /** 	elsif report_errors then*/
    if (_report_errors_62905 == 0)
    {
        goto L1E; // [856] 888
    }
    else{
    }

    /** 		forward_references  = {}*/
    RefDS(_22023);
    DeRef(_38forward_references_61501);
    _38forward_references_61501 = _22023;

    /** 		active_references   = {}*/
    RefDS(_22023);
    DeRef(_38active_references_61503);
    _38active_references_61503 = _22023;

    /** 		toplevel_references = {}*/
    RefDS(_22023);
    DeRef(_38toplevel_references_61504);
    _38toplevel_references_61504 = _22023;

    /** 		inactive_references = {}*/
    RefDS(_22023);
    DeRef(_38inactive_references_61505);
    _38inactive_references_61505 = _22023;
L1E: 
L1D: 

    /** 	clear_last()*/
    _41clear_last();

    /** end procedure*/
    DeRef(_errors_62906);
    _31475 = NOVALUE;
    _31478 = NOVALUE;
    DeRef(_31481);
    _31481 = NOVALUE;
    _31483 = NOVALUE;
    _31485 = NOVALUE;
    _31498 = NOVALUE;
    _31565 = NOVALUE;
    DeRef(_31501);
    _31501 = NOVALUE;
    DeRef(_31504);
    _31504 = NOVALUE;
    _31520 = NOVALUE;
    _31532 = NOVALUE;
    _31540 = NOVALUE;
    _31524 = NOVALUE;
    _31552 = NOVALUE;
    return;
    ;
}


void _38shift_these(int _refs_63116, int _pc_63117, int _amount_63118)
{
    int _fr_63122 = NOVALUE;
    int _31600 = NOVALUE;
    int _31599 = NOVALUE;
    int _31598 = NOVALUE;
    int _31597 = NOVALUE;
    int _31596 = NOVALUE;
    int _31595 = NOVALUE;
    int _31594 = NOVALUE;
    int _31593 = NOVALUE;
    int _31592 = NOVALUE;
    int _31591 = NOVALUE;
    int _31589 = NOVALUE;
    int _31587 = NOVALUE;
    int _31586 = NOVALUE;
    int _31584 = NOVALUE;
    int _31583 = NOVALUE;
    int _0, _1, _2;
    

    /** 	for i = length( refs ) to 1 by -1 do*/
    if (IS_SEQUENCE(_refs_63116)){
            _31583 = SEQ_PTR(_refs_63116)->length;
    }
    else {
        _31583 = 1;
    }
    {
        int _i_63120;
        _i_63120 = _31583;
L1: 
        if (_i_63120 < 1){
            goto L2; // [12] 147
        }

        /** 		sequence fr = forward_references[refs[i]]*/
        _2 = (int)SEQ_PTR(_refs_63116);
        _31584 = (int)*(((s1_ptr)_2)->base + _i_63120);
        DeRef(_fr_63122);
        _2 = (int)SEQ_PTR(_38forward_references_61501);
        if (!IS_ATOM_INT(_31584)){
            _fr_63122 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_31584)->dbl));
        }
        else{
            _fr_63122 = (int)*(((s1_ptr)_2)->base + _31584);
        }
        Ref(_fr_63122);

        /** 		forward_references[refs[i]] = 0*/
        _2 = (int)SEQ_PTR(_refs_63116);
        _31586 = (int)*(((s1_ptr)_2)->base + _i_63120);
        _2 = (int)SEQ_PTR(_38forward_references_61501);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _38forward_references_61501 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_31586))
        _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_31586)->dbl));
        else
        _2 = (int)(((s1_ptr)_2)->base + _31586);
        _1 = *(int *)_2;
        *(int *)_2 = 0;
        DeRef(_1);

        /** 		if fr[FR_SUBPROG] = shifting_sub then*/
        _2 = (int)SEQ_PTR(_fr_63122);
        _31587 = (int)*(((s1_ptr)_2)->base + 4);
        if (binary_op_a(NOTEQ, _31587, _38shifting_sub_61520)){
            _31587 = NOVALUE;
            goto L3; // [53] 126
        }
        _31587 = NOVALUE;

        /** 			if fr[FR_PC] >= pc then*/
        _2 = (int)SEQ_PTR(_fr_63122);
        _31589 = (int)*(((s1_ptr)_2)->base + 5);
        if (binary_op_a(LESS, _31589, _pc_63117)){
            _31589 = NOVALUE;
            goto L4; // [63] 125
        }
        _31589 = NOVALUE;

        /** 				fr[FR_PC] += amount*/
        _2 = (int)SEQ_PTR(_fr_63122);
        _31591 = (int)*(((s1_ptr)_2)->base + 5);
        if (IS_ATOM_INT(_31591)) {
            _31592 = _31591 + _amount_63118;
            if ((long)((unsigned long)_31592 + (unsigned long)HIGH_BITS) >= 0) 
            _31592 = NewDouble((double)_31592);
        }
        else {
            _31592 = binary_op(PLUS, _31591, _amount_63118);
        }
        _31591 = NOVALUE;
        _2 = (int)SEQ_PTR(_fr_63122);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _fr_63122 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 5);
        _1 = *(int *)_2;
        *(int *)_2 = _31592;
        if( _1 != _31592 ){
            DeRef(_1);
        }
        _31592 = NOVALUE;

        /** 				if fr[FR_TYPE] = CASE*/
        _2 = (int)SEQ_PTR(_fr_63122);
        _31593 = (int)*(((s1_ptr)_2)->base + 1);
        if (IS_ATOM_INT(_31593)) {
            _31594 = (_31593 == 186);
        }
        else {
            _31594 = binary_op(EQUALS, _31593, 186);
        }
        _31593 = NOVALUE;
        if (IS_ATOM_INT(_31594)) {
            if (_31594 == 0) {
                goto L5; // [93] 124
            }
        }
        else {
            if (DBL_PTR(_31594)->dbl == 0.0) {
                goto L5; // [93] 124
            }
        }
        _2 = (int)SEQ_PTR(_fr_63122);
        _31596 = (int)*(((s1_ptr)_2)->base + 12);
        if (IS_ATOM_INT(_31596)) {
            _31597 = (_31596 >= _pc_63117);
        }
        else {
            _31597 = binary_op(GREATEREQ, _31596, _pc_63117);
        }
        _31596 = NOVALUE;
        if (_31597 == 0) {
            DeRef(_31597);
            _31597 = NOVALUE;
            goto L5; // [106] 124
        }
        else {
            if (!IS_ATOM_INT(_31597) && DBL_PTR(_31597)->dbl == 0.0){
                DeRef(_31597);
                _31597 = NOVALUE;
                goto L5; // [106] 124
            }
            DeRef(_31597);
            _31597 = NOVALUE;
        }
        DeRef(_31597);
        _31597 = NOVALUE;

        /** 					fr[FR_DATA] += amount*/
        _2 = (int)SEQ_PTR(_fr_63122);
        _31598 = (int)*(((s1_ptr)_2)->base + 12);
        if (IS_ATOM_INT(_31598)) {
            _31599 = _31598 + _amount_63118;
            if ((long)((unsigned long)_31599 + (unsigned long)HIGH_BITS) >= 0) 
            _31599 = NewDouble((double)_31599);
        }
        else {
            _31599 = binary_op(PLUS, _31598, _amount_63118);
        }
        _31598 = NOVALUE;
        _2 = (int)SEQ_PTR(_fr_63122);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _fr_63122 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 12);
        _1 = *(int *)_2;
        *(int *)_2 = _31599;
        if( _1 != _31599 ){
            DeRef(_1);
        }
        _31599 = NOVALUE;
L5: 
L4: 
L3: 

        /** 		forward_references[refs[i]] = fr*/
        _2 = (int)SEQ_PTR(_refs_63116);
        _31600 = (int)*(((s1_ptr)_2)->base + _i_63120);
        RefDS(_fr_63122);
        _2 = (int)SEQ_PTR(_38forward_references_61501);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _38forward_references_61501 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_31600))
        _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_31600)->dbl));
        else
        _2 = (int)(((s1_ptr)_2)->base + _31600);
        _1 = *(int *)_2;
        *(int *)_2 = _fr_63122;
        DeRef(_1);
        DeRefDS(_fr_63122);
        _fr_63122 = NOVALUE;

        /** 	end for*/
        _i_63120 = _i_63120 + -1;
        goto L1; // [142] 19
L2: 
        ;
    }

    /** end procedure*/
    DeRefDS(_refs_63116);
    _31584 = NOVALUE;
    _31586 = NOVALUE;
    _31600 = NOVALUE;
    DeRef(_31594);
    _31594 = NOVALUE;
    return;
    ;
}


void _38shift_top(int _refs_63146, int _pc_63147, int _amount_63148)
{
    int _fr_63152 = NOVALUE;
    int _31616 = NOVALUE;
    int _31615 = NOVALUE;
    int _31614 = NOVALUE;
    int _31613 = NOVALUE;
    int _31612 = NOVALUE;
    int _31611 = NOVALUE;
    int _31610 = NOVALUE;
    int _31609 = NOVALUE;
    int _31608 = NOVALUE;
    int _31607 = NOVALUE;
    int _31605 = NOVALUE;
    int _31604 = NOVALUE;
    int _31602 = NOVALUE;
    int _31601 = NOVALUE;
    int _0, _1, _2;
    

    /** 	for i = length( refs ) to 1 by -1 do*/
    if (IS_SEQUENCE(_refs_63146)){
            _31601 = SEQ_PTR(_refs_63146)->length;
    }
    else {
        _31601 = 1;
    }
    {
        int _i_63150;
        _i_63150 = _31601;
L1: 
        if (_i_63150 < 1){
            goto L2; // [12] 134
        }

        /** 		sequence fr = forward_references[refs[i]]*/
        _2 = (int)SEQ_PTR(_refs_63146);
        _31602 = (int)*(((s1_ptr)_2)->base + _i_63150);
        DeRef(_fr_63152);
        _2 = (int)SEQ_PTR(_38forward_references_61501);
        if (!IS_ATOM_INT(_31602)){
            _fr_63152 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_31602)->dbl));
        }
        else{
            _fr_63152 = (int)*(((s1_ptr)_2)->base + _31602);
        }
        Ref(_fr_63152);

        /** 		forward_references[refs[i]] = 0*/
        _2 = (int)SEQ_PTR(_refs_63146);
        _31604 = (int)*(((s1_ptr)_2)->base + _i_63150);
        _2 = (int)SEQ_PTR(_38forward_references_61501);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _38forward_references_61501 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_31604))
        _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_31604)->dbl));
        else
        _2 = (int)(((s1_ptr)_2)->base + _31604);
        _1 = *(int *)_2;
        *(int *)_2 = 0;
        DeRef(_1);

        /** 		if fr[FR_PC] >= pc then*/
        _2 = (int)SEQ_PTR(_fr_63152);
        _31605 = (int)*(((s1_ptr)_2)->base + 5);
        if (binary_op_a(LESS, _31605, _pc_63147)){
            _31605 = NOVALUE;
            goto L3; // [51] 113
        }
        _31605 = NOVALUE;

        /** 			fr[FR_PC] += amount*/
        _2 = (int)SEQ_PTR(_fr_63152);
        _31607 = (int)*(((s1_ptr)_2)->base + 5);
        if (IS_ATOM_INT(_31607)) {
            _31608 = _31607 + _amount_63148;
            if ((long)((unsigned long)_31608 + (unsigned long)HIGH_BITS) >= 0) 
            _31608 = NewDouble((double)_31608);
        }
        else {
            _31608 = binary_op(PLUS, _31607, _amount_63148);
        }
        _31607 = NOVALUE;
        _2 = (int)SEQ_PTR(_fr_63152);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _fr_63152 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 5);
        _1 = *(int *)_2;
        *(int *)_2 = _31608;
        if( _1 != _31608 ){
            DeRef(_1);
        }
        _31608 = NOVALUE;

        /** 			if fr[FR_TYPE] = CASE*/
        _2 = (int)SEQ_PTR(_fr_63152);
        _31609 = (int)*(((s1_ptr)_2)->base + 1);
        if (IS_ATOM_INT(_31609)) {
            _31610 = (_31609 == 186);
        }
        else {
            _31610 = binary_op(EQUALS, _31609, 186);
        }
        _31609 = NOVALUE;
        if (IS_ATOM_INT(_31610)) {
            if (_31610 == 0) {
                goto L4; // [81] 112
            }
        }
        else {
            if (DBL_PTR(_31610)->dbl == 0.0) {
                goto L4; // [81] 112
            }
        }
        _2 = (int)SEQ_PTR(_fr_63152);
        _31612 = (int)*(((s1_ptr)_2)->base + 12);
        if (IS_ATOM_INT(_31612)) {
            _31613 = (_31612 >= _pc_63147);
        }
        else {
            _31613 = binary_op(GREATEREQ, _31612, _pc_63147);
        }
        _31612 = NOVALUE;
        if (_31613 == 0) {
            DeRef(_31613);
            _31613 = NOVALUE;
            goto L4; // [94] 112
        }
        else {
            if (!IS_ATOM_INT(_31613) && DBL_PTR(_31613)->dbl == 0.0){
                DeRef(_31613);
                _31613 = NOVALUE;
                goto L4; // [94] 112
            }
            DeRef(_31613);
            _31613 = NOVALUE;
        }
        DeRef(_31613);
        _31613 = NOVALUE;

        /** 				fr[FR_DATA] += amount*/
        _2 = (int)SEQ_PTR(_fr_63152);
        _31614 = (int)*(((s1_ptr)_2)->base + 12);
        if (IS_ATOM_INT(_31614)) {
            _31615 = _31614 + _amount_63148;
            if ((long)((unsigned long)_31615 + (unsigned long)HIGH_BITS) >= 0) 
            _31615 = NewDouble((double)_31615);
        }
        else {
            _31615 = binary_op(PLUS, _31614, _amount_63148);
        }
        _31614 = NOVALUE;
        _2 = (int)SEQ_PTR(_fr_63152);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _fr_63152 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 12);
        _1 = *(int *)_2;
        *(int *)_2 = _31615;
        if( _1 != _31615 ){
            DeRef(_1);
        }
        _31615 = NOVALUE;
L4: 
L3: 

        /** 		forward_references[refs[i]] = fr*/
        _2 = (int)SEQ_PTR(_refs_63146);
        _31616 = (int)*(((s1_ptr)_2)->base + _i_63150);
        RefDS(_fr_63152);
        _2 = (int)SEQ_PTR(_38forward_references_61501);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _38forward_references_61501 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_31616))
        _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_31616)->dbl));
        else
        _2 = (int)(((s1_ptr)_2)->base + _31616);
        _1 = *(int *)_2;
        *(int *)_2 = _fr_63152;
        DeRef(_1);
        DeRefDS(_fr_63152);
        _fr_63152 = NOVALUE;

        /** 	end for*/
        _i_63150 = _i_63150 + -1;
        goto L1; // [129] 19
L2: 
        ;
    }

    /** end procedure*/
    DeRefDS(_refs_63146);
    _31602 = NOVALUE;
    _31604 = NOVALUE;
    _31616 = NOVALUE;
    DeRef(_31610);
    _31610 = NOVALUE;
    return;
    ;
}


void _38shift_fwd_refs(int _pc_63173, int _amount_63174)
{
    int _file_63185 = NOVALUE;
    int _sp_63190 = NOVALUE;
    int _31626 = NOVALUE;
    int _31625 = NOVALUE;
    int _31623 = NOVALUE;
    int _31621 = NOVALUE;
    int _31620 = NOVALUE;
    int _31619 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_pc_63173)) {
        _1 = (long)(DBL_PTR(_pc_63173)->dbl);
        DeRefDS(_pc_63173);
        _pc_63173 = _1;
    }
    if (!IS_ATOM_INT(_amount_63174)) {
        _1 = (long)(DBL_PTR(_amount_63174)->dbl);
        DeRefDS(_amount_63174);
        _amount_63174 = _1;
    }

    /** 	if not shifting_sub then*/
    if (_38shifting_sub_61520 != 0)
    goto L1; // [9] 18

    /** 		return*/
    return;
L1: 

    /** 	if shifting_sub = TopLevelSub then*/
    if (_38shifting_sub_61520 != _35TopLevelSub_16251)
    goto L2; // [24] 65

    /** 		for file = 1 to length( toplevel_references ) do*/
    if (IS_SEQUENCE(_38toplevel_references_61504)){
            _31619 = SEQ_PTR(_38toplevel_references_61504)->length;
    }
    else {
        _31619 = 1;
    }
    {
        int _file_63181;
        _file_63181 = 1;
L3: 
        if (_file_63181 > _31619){
            goto L4; // [35] 62
        }

        /** 			shift_top( toplevel_references[file], pc, amount )*/
        _2 = (int)SEQ_PTR(_38toplevel_references_61504);
        _31620 = (int)*(((s1_ptr)_2)->base + _file_63181);
        Ref(_31620);
        _38shift_top(_31620, _pc_63173, _amount_63174);
        _31620 = NOVALUE;

        /** 		end for*/
        _file_63181 = _file_63181 + 1;
        goto L3; // [57] 42
L4: 
        ;
    }
    goto L5; // [62] 118
L2: 

    /** 		integer file = SymTab[shifting_sub][S_FILE_NO]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _31621 = (int)*(((s1_ptr)_2)->base + _38shifting_sub_61520);
    _2 = (int)SEQ_PTR(_31621);
    if (!IS_ATOM_INT(_35S_FILE_NO_15913)){
        _file_63185 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FILE_NO_15913)->dbl));
    }
    else{
        _file_63185 = (int)*(((s1_ptr)_2)->base + _35S_FILE_NO_15913);
    }
    if (!IS_ATOM_INT(_file_63185)){
        _file_63185 = (long)DBL_PTR(_file_63185)->dbl;
    }
    _31621 = NOVALUE;

    /** 		integer sp   = find( shifting_sub, active_subprogs[file] )*/
    _2 = (int)SEQ_PTR(_38active_subprogs_61502);
    _31623 = (int)*(((s1_ptr)_2)->base + _file_63185);
    _sp_63190 = find_from(_38shifting_sub_61520, _31623, 1);
    _31623 = NOVALUE;

    /** 		shift_these( active_references[file][sp], pc, amount )*/
    _2 = (int)SEQ_PTR(_38active_references_61503);
    _31625 = (int)*(((s1_ptr)_2)->base + _file_63185);
    _2 = (int)SEQ_PTR(_31625);
    _31626 = (int)*(((s1_ptr)_2)->base + _sp_63190);
    _31625 = NOVALUE;
    Ref(_31626);
    _38shift_these(_31626, _pc_63173, _amount_63174);
    _31626 = NOVALUE;
L5: 

    /** end procedure*/
    return;
    ;
}



// 0xA25E1670
