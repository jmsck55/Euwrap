// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int _3extract_options(int _s_63258)
{
    int _0, _1, _2;
    

    /** 	return s*/
    return _s_63258;
    ;
}


void _3transoptions()
{
    int _tranopts_63385 = NOVALUE;
    int _opts_63395 = NOVALUE;
    int _opt_keys_63401 = NOVALUE;
    int _option_w_63403 = NOVALUE;
    int _key_63407 = NOVALUE;
    int _val_63409 = NOVALUE;
    int _tmp_63502 = NOVALUE;
    int _tmp_63522 = NOVALUE;
    int _31881 = NOVALUE;
    int _31880 = NOVALUE;
    int _31879 = NOVALUE;
    int _31878 = NOVALUE;
    int _31876 = NOVALUE;
    int _31875 = NOVALUE;
    int _31874 = NOVALUE;
    int _31873 = NOVALUE;
    int _31872 = NOVALUE;
    int _31871 = NOVALUE;
    int _31866 = NOVALUE;
    int _31865 = NOVALUE;
    int _31864 = NOVALUE;
    int _31861 = NOVALUE;
    int _31860 = NOVALUE;
    int _31859 = NOVALUE;
    int _31858 = NOVALUE;
    int _31857 = NOVALUE;
    int _31854 = NOVALUE;
    int _31851 = NOVALUE;
    int _31850 = NOVALUE;
    int _31849 = NOVALUE;
    int _31848 = NOVALUE;
    int _31846 = NOVALUE;
    int _31843 = NOVALUE;
    int _31842 = NOVALUE;
    int _31841 = NOVALUE;
    int _31840 = NOVALUE;
    int _31839 = NOVALUE;
    int _31838 = NOVALUE;
    int _31837 = NOVALUE;
    int _31836 = NOVALUE;
    int _31835 = NOVALUE;
    int _31834 = NOVALUE;
    int _31833 = NOVALUE;
    int _31832 = NOVALUE;
    int _31831 = NOVALUE;
    int _31829 = NOVALUE;
    int _31827 = NOVALUE;
    int _31825 = NOVALUE;
    int _31824 = NOVALUE;
    int _31823 = NOVALUE;
    int _31822 = NOVALUE;
    int _31821 = NOVALUE;
    int _31820 = NOVALUE;
    int _31817 = NOVALUE;
    int _31816 = NOVALUE;
    int _31815 = NOVALUE;
    int _31812 = NOVALUE;
    int _31809 = NOVALUE;
    int _31808 = NOVALUE;
    int _31806 = NOVALUE;
    int _31804 = NOVALUE;
    int _31802 = NOVALUE;
    int _31792 = NOVALUE;
    int _31790 = NOVALUE;
    int _31787 = NOVALUE;
    int _31785 = NOVALUE;
    int _31783 = NOVALUE;
    int _31782 = NOVALUE;
    int _31781 = NOVALUE;
    int _31780 = NOVALUE;
    int _31779 = NOVALUE;
    int _31774 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence tranopts = get_options()*/
    _0 = _tranopts_63385;
    _tranopts_63385 = _43get_options();
    DeRef(_0);

    /** 	Argv = expand_config_options( Argv )*/
    RefDS(_35Argv_16255);
    _0 = _43expand_config_options(_35Argv_16255);
    DeRefDS(_35Argv_16255);
    _35Argv_16255 = _0;

    /** 	Argc = length(Argv)*/
    if (IS_SEQUENCE(_35Argv_16255)){
            _35Argc_16254 = SEQ_PTR(_35Argv_16255)->length;
    }
    else {
        _35Argc_16254 = 1;
    }

    /** 	map:map opts = cmd_parse( tranopts, NO_HELP_ON_ERROR, Argv)*/
    RefDS(_tranopts_63385);
    RefDS(_35Argv_16255);
    _0 = _opts_63395;
    _opts_63395 = _4cmd_parse(_tranopts_63385, 10, _35Argv_16255);
    DeRef(_0);

    /** 	handle_common_options(opts)*/
    Ref(_opts_63395);
    _43handle_common_options(_opts_63395);

    /** 	sequence opt_keys = map:keys(opts)*/
    Ref(_opts_63395);
    _0 = _opt_keys_63401;
    _opt_keys_63401 = _28keys(_opts_63395, 0);
    DeRef(_0);

    /** 	integer option_w = 0*/
    _option_w_63403 = 0;

    /** 	for idx = 1 to length(opt_keys) do*/
    if (IS_SEQUENCE(_opt_keys_63401)){
            _31774 = SEQ_PTR(_opt_keys_63401)->length;
    }
    else {
        _31774 = 1;
    }
    {
        int _idx_63405;
        _idx_63405 = 1;
L1: 
        if (_idx_63405 > _31774){
            goto L2; // [63] 739
        }

        /** 		sequence key = opt_keys[idx]*/
        DeRef(_key_63407);
        _2 = (int)SEQ_PTR(_opt_keys_63401);
        _key_63407 = (int)*(((s1_ptr)_2)->base + _idx_63405);
        Ref(_key_63407);

        /** 		object val = map:get(opts, key)*/
        Ref(_opts_63395);
        RefDS(_key_63407);
        _0 = _val_63409;
        _val_63409 = _28get(_opts_63395, _key_63407, 0);
        DeRef(_0);

        /** 		switch key do*/
        _1 = find(_key_63407, _31777);
        switch ( _1 ){ 

            /** 			case "silent" then*/
            case 1:

            /** 				silent = TRUE*/
            _35silent_16359 = _13TRUE_436;
            goto L3; // [104] 730

            /** 			case "verbose" then*/
            case 2:

            /** 				verbose = TRUE*/
            _35verbose_16362 = _13TRUE_436;
            goto L3; // [117] 730

            /** 			case "rc-file" then*/
            case 3:

            /** 				rc_file[D_NAME] = canonical_path(val)*/
            Ref(_val_63409);
            _31779 = _17canonical_path(_val_63409, 0, 0);
            _2 = (int)SEQ_PTR(_55rc_file_44330);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _55rc_file_44330 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + 1);
            _1 = *(int *)_2;
            *(int *)_2 = _31779;
            if( _1 != _31779 ){
                DeRef(_1);
            }
            _31779 = NOVALUE;

            /** 				rc_file[D_ALTNAME] = adjust_for_command_line_passing((rc_file[D_NAME]))*/
            _2 = (int)SEQ_PTR(_55rc_file_44330);
            _31780 = (int)*(((s1_ptr)_2)->base + 1);
            Ref(_31780);
            _31781 = _55adjust_for_command_line_passing(_31780);
            _31780 = NOVALUE;
            _2 = (int)SEQ_PTR(_55rc_file_44330);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _55rc_file_44330 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + 11);
            _1 = *(int *)_2;
            *(int *)_2 = _31781;
            if( _1 != _31781 ){
                DeRef(_1);
            }
            _31781 = NOVALUE;

            /** 				if not file_exists(rc_file[D_NAME]) then*/
            _2 = (int)SEQ_PTR(_55rc_file_44330);
            _31782 = (int)*(((s1_ptr)_2)->base + 1);
            Ref(_31782);
            _31783 = _17file_exists(_31782);
            _31782 = NOVALUE;
            if (IS_ATOM_INT(_31783)) {
                if (_31783 != 0){
                    DeRef(_31783);
                    _31783 = NOVALUE;
                    goto L3; // [175] 730
                }
            }
            else {
                if (DBL_PTR(_31783)->dbl != 0.0){
                    DeRef(_31783);
                    _31783 = NOVALUE;
                    goto L3; // [175] 730
                }
            }
            DeRef(_31783);
            _31783 = NOVALUE;

            /** 					ShowMsg(2, 349, { val })*/
            _1 = NewS1(1);
            _2 = (int)((s1_ptr)_1)->base;
            Ref(_val_63409);
            *((int *)(_2+4)) = _val_63409;
            _31785 = MAKE_SEQ(_1);
            _45ShowMsg(2, 349, _31785, 1);
            _31785 = NOVALUE;

            /** 					abort(1)*/
            UserCleanup(1);
            goto L3; // [195] 730

            /** 			case "cflags" then*/
            case 4:

            /** 				cflags = val*/
            Ref(_val_63409);
            DeRef(_55cflags_44339);
            _55cflags_44339 = _val_63409;
            goto L3; // [208] 730

            /** 			case "lflags" then*/
            case 5:

            /** 				lflags = val*/
            Ref(_val_63409);
            DeRef(_55lflags_44340);
            _55lflags_44340 = _val_63409;
            goto L3; // [221] 730

            /** 			case "wat" then*/
            case 6:

            /** 				compiler_type = COMPILER_WATCOM*/
            _55compiler_type_44322 = 2;
            goto L3; // [236] 730

            /** 			case "gcc" then*/
            case 7:

            /** 				compiler_type = COMPILER_GCC*/
            _55compiler_type_44322 = 1;
            goto L3; // [251] 730

            /** 			case "com" then*/
            case 8:

            /** 				compiler_dir = val*/
            Ref(_val_63409);
            DeRef(_55compiler_dir_44323);
            _55compiler_dir_44323 = _val_63409;
            goto L3; // [264] 730

            /** 			case "con" then*/
            case 9:

            /** 				con_option = TRUE*/
            _57con_option_41678 = _13TRUE_436;

            /** 				OpDefines &= { "CONSOLE" }*/
            _1 = NewS1(1);
            _2 = (int)((s1_ptr)_1)->base;
            RefDS(_31786);
            *((int *)(_2+4)) = _31786;
            _31787 = MAKE_SEQ(_1);
            Concat((object_ptr)&_35OpDefines_16317, _35OpDefines_16317, _31787);
            DeRefDS(_31787);
            _31787 = NOVALUE;
            goto L3; // [291] 730

            /** 			case "dll", "so" then*/
            case 10:
            case 11:

            /** 				dll_option = TRUE*/
            _57dll_option_41676 = _13TRUE_436;

            /** 				OpDefines &= { "EUC_DLL" }*/
            _1 = NewS1(1);
            _2 = (int)((s1_ptr)_1)->base;
            RefDS(_31789);
            *((int *)(_2+4)) = _31789;
            _31790 = MAKE_SEQ(_1);
            Concat((object_ptr)&_35OpDefines_16317, _35OpDefines_16317, _31790);
            DeRefDS(_31790);
            _31790 = NOVALUE;
            goto L3; // [320] 730

            /** 			case "plat" then*/
            case 12:

            /** 				switch upper(val) do*/
            Ref(_val_63409);
            _31792 = _14upper(_val_63409);
            _1 = find(_31792, _31793);
            DeRef(_31792);
            _31792 = NOVALUE;
            switch ( _1 ){ 

                /** 					case "WINDOWS" then*/
                case 1:

                /** 						set_host_platform( WIN32 )*/
                _40set_host_platform(2);
                goto L3; // [348] 730

                /** 					case "LINUX" then*/
                case 2:

                /** 						set_host_platform( ULINUX )*/
                _40set_host_platform(3);
                goto L3; // [361] 730

                /** 					case "FREEBSD" then*/
                case 3:

                /** 						set_host_platform( UFREEBSD )*/
                _40set_host_platform(8);
                goto L3; // [374] 730

                /** 					case "OSX" then*/
                case 4:

                /** 						set_host_platform( UOSX )*/
                _40set_host_platform(4);
                goto L3; // [387] 730

                /** 					case "OPENBSD" then*/
                case 5:

                /** 						set_host_platform( UOPENBSD )*/
                _40set_host_platform(6);
                goto L3; // [400] 730

                /** 					case "NETBSD" then*/
                case 6:

                /** 						set_host_platform( UNETBSD )*/
                _40set_host_platform(7);
                goto L3; // [413] 730

                /** 					case else*/
                case 0:

                /** 						ShowMsg(2, 201, { val, "WINDOWS, LINUX, FREEBSD, OSX, OPENBSD, NETBSD" })*/
                RefDS(_31801);
                Ref(_val_63409);
                _1 = NewS1(2);
                _2 = (int)((s1_ptr)_1)->base;
                ((int *)_2)[1] = _val_63409;
                ((int *)_2)[2] = _31801;
                _31802 = MAKE_SEQ(_1);
                _45ShowMsg(2, 201, _31802, 1);
                _31802 = NOVALUE;

                /** 						abort(1)*/
                UserCleanup(1);
            ;}            goto L3; // [436] 730

            /** 			case "lib" then*/
            case 13:

            /** 				user_library = val*/
            Ref(_val_63409);
            DeRef(_57user_library_41688);
            _57user_library_41688 = _val_63409;
            goto L3; // [449] 730

            /** 			case "stack" then*/
            case 14:

            /** 				sequence tmp = value(val)*/
            Ref(_val_63409);
            _0 = _tmp_63502;
            _tmp_63502 = _6value(_val_63409, 1, _6GET_SHORT_ANSWER_10641);
            DeRef(_0);

            /** 				if tmp[1] = GET_SUCCESS then*/
            _2 = (int)SEQ_PTR(_tmp_63502);
            _31804 = (int)*(((s1_ptr)_2)->base + 1);
            if (binary_op_a(NOTEQ, _31804, 0)){
                _31804 = NOVALUE;
                goto L4; // [475] 507
            }
            _31804 = NOVALUE;

            /** 					if tmp[2] >= 16384 then*/
            _2 = (int)SEQ_PTR(_tmp_63502);
            _31806 = (int)*(((s1_ptr)_2)->base + 2);
            if (binary_op_a(LESS, _31806, 16384)){
                _31806 = NOVALUE;
                goto L5; // [485] 506
            }
            _31806 = NOVALUE;

            /** 						total_stack_size = floor(tmp[2] / 4) * 4*/
            _2 = (int)SEQ_PTR(_tmp_63502);
            _31808 = (int)*(((s1_ptr)_2)->base + 2);
            if (IS_ATOM_INT(_31808)) {
                if (4 > 0 && _31808 >= 0) {
                    _31809 = _31808 / 4;
                }
                else {
                    temp_dbl = floor((double)_31808 / (double)4);
                    if (_31808 != MININT)
                    _31809 = (long)temp_dbl;
                    else
                    _31809 = NewDouble(temp_dbl);
                }
            }
            else {
                _2 = binary_op(DIVIDE, _31808, 4);
                _31809 = unary_op(FLOOR, _2);
                DeRef(_2);
            }
            _31808 = NOVALUE;
            if (IS_ATOM_INT(_31809)) {
                _57total_stack_size_41690 = _31809 * 4;
            }
            else {
                _57total_stack_size_41690 = binary_op(MULTIPLY, _31809, 4);
            }
            DeRef(_31809);
            _31809 = NOVALUE;
            if (!IS_ATOM_INT(_57total_stack_size_41690)) {
                _1 = (long)(DBL_PTR(_57total_stack_size_41690)->dbl);
                DeRefDS(_57total_stack_size_41690);
                _57total_stack_size_41690 = _1;
            }
L5: 
L4: 
            DeRef(_tmp_63502);
            _tmp_63502 = NOVALUE;
            goto L3; // [509] 730

            /** 			case "debug" then*/
            case 15:

            /** 				debug_option = TRUE*/
            _57debug_option_41686 = _13TRUE_436;

            /** 				keep = TRUE -- you'll need the sources to debug*/
            _57keep_41683 = _13TRUE_436;
            goto L3; // [529] 730

            /** 			case "maxsize" then*/
            case 16:

            /** 				sequence tmp = value(val)*/
            Ref(_val_63409);
            _0 = _tmp_63522;
            _tmp_63522 = _6value(_val_63409, 1, _6GET_SHORT_ANSWER_10641);
            DeRef(_0);

            /** 				if tmp[1] = GET_SUCCESS then*/
            _2 = (int)SEQ_PTR(_tmp_63522);
            _31812 = (int)*(((s1_ptr)_2)->base + 1);
            if (binary_op_a(NOTEQ, _31812, 0)){
                _31812 = NOVALUE;
                goto L6; // [555] 570
            }
            _31812 = NOVALUE;

            /** 					max_cfile_size = tmp[2]*/
            _2 = (int)SEQ_PTR(_tmp_63522);
            _55max_cfile_size_44337 = (int)*(((s1_ptr)_2)->base + 2);
            if (!IS_ATOM_INT(_55max_cfile_size_44337)){
                _55max_cfile_size_44337 = (long)DBL_PTR(_55max_cfile_size_44337)->dbl;
            }
            goto L7; // [567] 583
L6: 

            /** 					ShowMsg(2, 202)*/
            RefDS(_22023);
            _45ShowMsg(2, 202, _22023, 1);

            /** 					abort(1)*/
            UserCleanup(1);
L7: 
            DeRef(_tmp_63522);
            _tmp_63522 = NOVALUE;
            goto L3; // [585] 730

            /** 			case "keep" then*/
            case 17:

            /** 				keep = TRUE*/
            _57keep_41683 = _13TRUE_436;
            goto L3; // [598] 730

            /** 			case "makefile-partial" then*/
            case 18:

            /** 				build_system_type = BUILD_MAKEFILE_PARTIAL*/
            _55build_system_type_44318 = 1;
            goto L3; // [613] 730

            /** 			case "makefile" then*/
            case 19:

            /** 				build_system_type = BUILD_MAKEFILE_FULL*/
            _55build_system_type_44318 = 2;
            goto L3; // [628] 730

            /** 			case "nobuild" then*/
            case 20:

            /** 				build_system_type = BUILD_NONE*/
            _55build_system_type_44318 = 0;
            goto L3; // [643] 730

            /** 			case "build-dir" then*/
            case 21:

            /** 				output_dir = val*/
            Ref(_val_63409);
            DeRef(_57output_dir_41689);
            _57output_dir_41689 = _val_63409;

            /** 				if find(output_dir[$], "/\\") = 0 then*/
            if (IS_SEQUENCE(_57output_dir_41689)){
                    _31815 = SEQ_PTR(_57output_dir_41689)->length;
            }
            else {
                _31815 = 1;
            }
            _2 = (int)SEQ_PTR(_57output_dir_41689);
            _31816 = (int)*(((s1_ptr)_2)->base + _31815);
            _31817 = find_from(_31816, _23777, 1);
            _31816 = NOVALUE;
            if (_31817 != 0)
            goto L3; // [672] 730

            /** 					output_dir &= '/'*/
            Append(&_57output_dir_41689, _57output_dir_41689, 47);
            goto L3; // [687] 730

            /** 			case "force-build" then*/
            case 22:

            /** 				force_build = 1*/
            _55force_build_44341 = 1;
            goto L3; // [700] 730

            /** 			case "o" then*/
            case 23:

            /** 				exe_name[D_NAME] = val*/
            Ref(_val_63409);
            _2 = (int)SEQ_PTR(_55exe_name_44324);
            _2 = (int)(((s1_ptr)_2)->base + 1);
            _1 = *(int *)_2;
            *(int *)_2 = _val_63409;
            DeRef(_1);
            goto L3; // [716] 730

            /** 			case "no-cygwin" then*/
            case 24:

            /** 				mno_cygwin = 1*/
            _55mno_cygwin_44343 = 1;
        ;}L3: 
        DeRef(_key_63407);
        _key_63407 = NOVALUE;
        DeRef(_val_63409);
        _val_63409 = NOVALUE;

        /** 	end for*/
        _idx_63405 = _idx_63405 + 1;
        goto L1; // [734] 70
L2: 
        ;
    }

    /** 	if compiler_type != COMPILER_GCC and not equal(user_library,"") then*/
    _31820 = (_55compiler_type_44322 != 1);
    if (_31820 == 0) {
        goto L8; // [749] 840
    }
    if (_57user_library_41688 == _22023)
    _31822 = 1;
    else if (IS_ATOM_INT(_57user_library_41688) && IS_ATOM_INT(_22023))
    _31822 = 0;
    else
    _31822 = (compare(_57user_library_41688, _22023) == 0);
    _31823 = (_31822 == 0);
    _31822 = NOVALUE;
    if (_31823 == 0)
    {
        DeRef(_31823);
        _31823 = NOVALUE;
        goto L8; // [763] 840
    }
    else{
        DeRef(_31823);
        _31823 = NOVALUE;
    }

    /** 		if not file_exists(canonical_path(user_library)) then*/
    RefDS(_57user_library_41688);
    _31824 = _17canonical_path(_57user_library_41688, 0, 0);
    _31825 = _17file_exists(_31824);
    _31824 = NOVALUE;
    if (IS_ATOM_INT(_31825)) {
        if (_31825 != 0){
            DeRef(_31825);
            _31825 = NOVALUE;
            goto L9; // [780] 826
        }
    }
    else {
        if (DBL_PTR(_31825)->dbl != 0.0){
            DeRef(_31825);
            _31825 = NOVALUE;
            goto L9; // [780] 826
        }
    }
    DeRef(_31825);
    _31825 = NOVALUE;

    /** 			ShowMsg(2, 348, { user_library })*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_57user_library_41688);
    *((int *)(_2+4)) = _57user_library_41688;
    _31827 = MAKE_SEQ(_1);
    _45ShowMsg(2, 348, _31827, 1);
    _31827 = NOVALUE;

    /** 			if force_build or build_system_type = BUILD_DIRECT then*/
    if (_55force_build_44341 != 0) {
        goto LA; // [801] 818
    }
    _31829 = (_55build_system_type_44318 == 3);
    if (_31829 == 0)
    {
        DeRef(_31829);
        _31829 = NOVALUE;
        goto LB; // [814] 839
    }
    else{
        DeRef(_31829);
        _31829 = NOVALUE;
    }
LA: 

    /** 				abort(1)*/
    UserCleanup(1);
    goto LB; // [823] 839
L9: 

    /** 			user_library = canonical_path(user_library)*/
    RefDS(_57user_library_41688);
    _0 = _17canonical_path(_57user_library_41688, 0, 0);
    DeRefDS(_57user_library_41688);
    _57user_library_41688 = _0;
LB: 
L8: 

    /** 	if length(exe_name[D_NAME]) and not absolute_path(exe_name[D_NAME]) then*/
    _2 = (int)SEQ_PTR(_55exe_name_44324);
    _31831 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_31831)){
            _31832 = SEQ_PTR(_31831)->length;
    }
    else {
        _31832 = 1;
    }
    _31831 = NOVALUE;
    if (_31832 == 0) {
        goto LC; // [853] 906
    }
    _2 = (int)SEQ_PTR(_55exe_name_44324);
    _31834 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_31834);
    _31835 = _17absolute_path(_31834);
    _31834 = NOVALUE;
    if (IS_ATOM_INT(_31835)) {
        _31836 = (_31835 == 0);
    }
    else {
        _31836 = unary_op(NOT, _31835);
    }
    DeRef(_31835);
    _31835 = NOVALUE;
    if (_31836 == 0) {
        DeRef(_31836);
        _31836 = NOVALUE;
        goto LC; // [873] 906
    }
    else {
        if (!IS_ATOM_INT(_31836) && DBL_PTR(_31836)->dbl == 0.0){
            DeRef(_31836);
            _31836 = NOVALUE;
            goto LC; // [873] 906
        }
        DeRef(_31836);
        _31836 = NOVALUE;
    }
    DeRef(_31836);
    _31836 = NOVALUE;

    /** 		exe_name[D_NAME] = current_dir() & SLASH & exe_name[D_NAME]*/
    _31837 = _17current_dir();
    _2 = (int)SEQ_PTR(_55exe_name_44324);
    _31838 = (int)*(((s1_ptr)_2)->base + 1);
    {
        int concat_list[3];

        concat_list[0] = _31838;
        concat_list[1] = 92;
        concat_list[2] = _31837;
        Concat_N((object_ptr)&_31839, concat_list, 3);
    }
    _31838 = NOVALUE;
    DeRef(_31837);
    _31837 = NOVALUE;
    _2 = (int)SEQ_PTR(_55exe_name_44324);
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _31839;
    if( _1 != _31839 ){
        DeRef(_1);
    }
    _31839 = NOVALUE;
LC: 

    /** 	exe_name[D_ALTNAME] = adjust_for_command_line_passing(exe_name[D_NAME])*/
    _2 = (int)SEQ_PTR(_55exe_name_44324);
    _31840 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_31840);
    _31841 = _55adjust_for_command_line_passing(_31840);
    _31840 = NOVALUE;
    _2 = (int)SEQ_PTR(_55exe_name_44324);
    _2 = (int)(((s1_ptr)_2)->base + 11);
    _1 = *(int *)_2;
    *(int *)_2 = _31841;
    if( _1 != _31841 ){
        DeRef(_1);
    }
    _31841 = NOVALUE;

    /** 	if length(map:get(opts, OPT_EXTRAS)) = 0 then*/
    Ref(_opts_63395);
    RefDS(_4OPT_EXTRAS_14123);
    _31842 = _28get(_opts_63395, _4OPT_EXTRAS_14123, 0);
    if (IS_SEQUENCE(_31842)){
            _31843 = SEQ_PTR(_31842)->length;
    }
    else {
        _31843 = 1;
    }
    DeRef(_31842);
    _31842 = NOVALUE;
    if (_31843 != 0)
    goto LD; // [941] 962

    /** 		show_banner()*/
    _43show_banner();

    /** 		ShowMsg(2, 203)*/
    RefDS(_22023);
    _45ShowMsg(2, 203, _22023, 1);

    /** 		abort(1)*/
    UserCleanup(1);
LD: 

    /** 	OpDefines &= { "EUC" }*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_31845);
    *((int *)(_2+4)) = _31845;
    _31846 = MAKE_SEQ(_1);
    Concat((object_ptr)&_35OpDefines_16317, _35OpDefines_16317, _31846);
    DeRefDS(_31846);
    _31846 = NOVALUE;

    /** 	if host_platform() = WIN32 and not con_option then*/
    _31848 = _40host_platform();
    if (IS_ATOM_INT(_31848)) {
        _31849 = (_31848 == 2);
    }
    else {
        _31849 = binary_op(EQUALS, _31848, 2);
    }
    DeRef(_31848);
    _31848 = NOVALUE;
    if (IS_ATOM_INT(_31849)) {
        if (_31849 == 0) {
            goto LE; // [987] 1013
        }
    }
    else {
        if (DBL_PTR(_31849)->dbl == 0.0) {
            goto LE; // [987] 1013
        }
    }
    _31851 = (_57con_option_41678 == 0);
    if (_31851 == 0)
    {
        DeRef(_31851);
        _31851 = NOVALUE;
        goto LE; // [997] 1013
    }
    else{
        DeRef(_31851);
        _31851 = NOVALUE;
    }

    /** 		OpDefines = append( OpDefines, "GUI" )*/
    RefDS(_31852);
    Append(&_35OpDefines_16317, _35OpDefines_16317, _31852);
    goto LF; // [1010] 1037
LE: 

    /** 	elsif not find( "CONSOLE", OpDefines ) then*/
    _31854 = find_from(_31786, _35OpDefines_16317, 1);
    if (_31854 != 0)
    goto L10; // [1022] 1036
    _31854 = NOVALUE;

    /** 		OpDefines = append( OpDefines, "CONSOLE" )*/
    RefDS(_31786);
    Append(&_35OpDefines_16317, _35OpDefines_16317, _31786);
L10: 
LF: 

    /** 	ifdef not EUDIS then*/

    /** 		if build_system_type = BUILD_DIRECT and length(output_dir) = 0 then*/
    _31857 = (_55build_system_type_44318 == 3);
    if (_31857 == 0) {
        goto L11; // [1049] 1147
    }
    if (IS_SEQUENCE(_57output_dir_41689)){
            _31859 = SEQ_PTR(_57output_dir_41689)->length;
    }
    else {
        _31859 = 1;
    }
    _31860 = (_31859 == 0);
    _31859 = NOVALUE;
    if (_31860 == 0)
    {
        DeRef(_31860);
        _31860 = NOVALUE;
        goto L11; // [1063] 1147
    }
    else{
        DeRef(_31860);
        _31860 = NOVALUE;
    }

    /** 			output_dir = temp_file("." & SLASH, "build-", "")*/
    Append(&_31861, _23097, 92);
    RefDS(_31862);
    RefDS(_22023);
    _0 = _17temp_file(_31861, _31862, _22023, 0);
    DeRef(_57output_dir_41689);
    _57output_dir_41689 = _0;
    _31861 = NOVALUE;

    /** 			if find(output_dir[$], "/\\") = 0 then*/
    if (IS_SEQUENCE(_57output_dir_41689)){
            _31864 = SEQ_PTR(_57output_dir_41689)->length;
    }
    else {
        _31864 = 1;
    }
    _2 = (int)SEQ_PTR(_57output_dir_41689);
    _31865 = (int)*(((s1_ptr)_2)->base + _31864);
    _31866 = find_from(_31865, _23777, 1);
    _31865 = NOVALUE;
    if (_31866 != 0)
    goto L12; // [1099] 1114

    /** 				output_dir &= '/'*/
    Append(&_57output_dir_41689, _57output_dir_41689, 47);
L12: 

    /** 			if not silent then*/
    if (_35silent_16359 != 0)
    goto L13; // [1118] 1139

    /** 				printf(1, "Build directory: %s\n", { abbreviate_path(output_dir) })*/
    RefDS(_57output_dir_41689);
    RefDS(_22023);
    _31871 = _17abbreviate_path(_57output_dir_41689, _22023);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _31871;
    _31872 = MAKE_SEQ(_1);
    _31871 = NOVALUE;
    EPrintf(1, _31870, _31872);
    DeRefDS(_31872);
    _31872 = NOVALUE;
L13: 

    /** 			remove_output_dir = 1*/
    _55remove_output_dir_44342 = 1;
L11: 

    /** 	if length(rc_file[D_NAME]) then*/
    _2 = (int)SEQ_PTR(_55rc_file_44330);
    _31873 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_31873)){
            _31874 = SEQ_PTR(_31873)->length;
    }
    else {
        _31874 = 1;
    }
    _31873 = NOVALUE;
    if (_31874 == 0)
    {
        _31874 = NOVALUE;
        goto L14; // [1160] 1222
    }
    else{
        _31874 = NOVALUE;
    }

    /** 		res_file[D_NAME] = canonical_path(output_dir & filebase(rc_file[D_NAME]) & ".res")*/
    _2 = (int)SEQ_PTR(_55rc_file_44330);
    _31875 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_31875);
    _31876 = _17filebase(_31875);
    _31875 = NOVALUE;
    {
        int concat_list[3];

        concat_list[0] = _31877;
        concat_list[1] = _31876;
        concat_list[2] = _57output_dir_41689;
        Concat_N((object_ptr)&_31878, concat_list, 3);
    }
    DeRef(_31876);
    _31876 = NOVALUE;
    _31879 = _17canonical_path(_31878, 0, 0);
    _31878 = NOVALUE;
    _2 = (int)SEQ_PTR(_55res_file_44336);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _55res_file_44336 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _31879;
    if( _1 != _31879 ){
        DeRef(_1);
    }
    _31879 = NOVALUE;

    /** 		res_file[D_ALTNAME] = adjust_for_command_line_passing(res_file[D_NAME])*/
    _2 = (int)SEQ_PTR(_55res_file_44336);
    _31880 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_31880);
    _31881 = _55adjust_for_command_line_passing(_31880);
    _31880 = NOVALUE;
    _2 = (int)SEQ_PTR(_55res_file_44336);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _55res_file_44336 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 11);
    _1 = *(int *)_2;
    *(int *)_2 = _31881;
    if( _1 != _31881 ){
        DeRef(_1);
    }
    _31881 = NOVALUE;
L14: 

    /** 	finalize_command_line(opts)*/
    Ref(_opts_63395);
    _43finalize_command_line(_opts_63395);

    /** end procedure*/
    DeRef(_tranopts_63385);
    DeRef(_opts_63395);
    DeRef(_opt_keys_63401);
    DeRef(_31820);
    _31820 = NOVALUE;
    _31831 = NOVALUE;
    _31842 = NOVALUE;
    DeRef(_31857);
    _31857 = NOVALUE;
    DeRef(_31849);
    _31849 = NOVALUE;
    _31873 = NOVALUE;
    return;
    ;
}


void _3OpenCFiles()
{
    int _31937 = NOVALUE;
    int _31893 = NOVALUE;
    int _31887 = NOVALUE;
    int _31885 = NOVALUE;
    int _31884 = NOVALUE;
    int _31883 = NOVALUE;
    int _31882 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if sequence(output_dir) and length(output_dir) > 0 then*/
    _31882 = 1;
    if (_31882 == 0) {
        goto L1; // [8] 38
    }
    if (IS_SEQUENCE(_57output_dir_41689)){
            _31884 = SEQ_PTR(_57output_dir_41689)->length;
    }
    else {
        _31884 = 1;
    }
    _31885 = (_31884 > 0);
    _31884 = NOVALUE;
    if (_31885 == 0)
    {
        DeRef(_31885);
        _31885 = NOVALUE;
        goto L1; // [22] 38
    }
    else{
        DeRef(_31885);
        _31885 = NOVALUE;
    }

    /** 		create_directory(output_dir)*/
    RefDS(_57output_dir_41689);
    _31937 = _17create_directory(_57output_dir_41689, 448, 1);
    DeRef(_31937);
    _31937 = NOVALUE;
L1: 

    /** 	c_code = open(output_dir & "init-.c", "w")*/
    Concat((object_ptr)&_31887, _57output_dir_41689, _31886);
    _54c_code_45491 = EOpen(_31887, _22129, 0);
    DeRefDS(_31887);
    _31887 = NOVALUE;

    /** 	if c_code = -1 then*/
    if (_54c_code_45491 != -1)
    goto L2; // [57] 69

    /** 		CompileErr(55)*/
    RefDS(_22023);
    _44CompileErr(55, _22023, 0);
L2: 

    /** 	add_file("init-.c")*/
    RefDS(_31886);
    RefDS(_22023);
    _57add_file(_31886, _22023);

    /** 	emit_c_output = TRUE*/
    _54emit_c_output_45488 = _13TRUE_436;

    /** 	c_puts("#include \"")*/
    RefDS(_31890);
    _54c_puts(_31890);

    /** 	c_puts("include/euphoria.h\"\n")*/
    RefDS(_31891);
    _54c_puts(_31891);

    /** 	c_puts("#include \"main-.h\"\n\n")*/
    RefDS(_22134);
    _54c_puts(_22134);

    /** 	c_h = open(output_dir & "main-.h", "w")*/
    Concat((object_ptr)&_31893, _57output_dir_41689, _31892);
    _54c_h_45492 = EOpen(_31893, _22129, 0);
    DeRefDS(_31893);
    _31893 = NOVALUE;

    /** 	if c_h = -1 then*/
    if (_54c_h_45492 != -1)
    goto L3; // [116] 128

    /** 		CompileErr(47)*/
    RefDS(_22023);
    _44CompileErr(47, _22023, 0);
L3: 

    /** 	add_file("main-.h")*/
    RefDS(_31892);
    RefDS(_22023);
    _57add_file(_31892, _22023);

    /** end procedure*/
    return;
    ;
}


void _3InitBackEnd(int _c_63745)
{
    int _31926 = NOVALUE;
    int _31925 = NOVALUE;
    int _31923 = NOVALUE;
    int _31922 = NOVALUE;
    int _31921 = NOVALUE;
    int _31920 = NOVALUE;
    int _31919 = NOVALUE;
    int _31916 = NOVALUE;
    int _31915 = NOVALUE;
    int _31912 = NOVALUE;
    int _31911 = NOVALUE;
    int _31908 = NOVALUE;
    int _31907 = NOVALUE;
    int _31905 = NOVALUE;
    int _31902 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_c_63745)) {
        _1 = (long)(DBL_PTR(_c_63745)->dbl);
        DeRefDS(_c_63745);
        _c_63745 = _1;
    }

    /** 	if c = 1 then*/
    if (_c_63745 != 1)
    goto L1; // [5] 19

    /** 		OpenCFiles()*/
    _3OpenCFiles();

    /** 		return*/
    return;
L1: 

    /** 	init_opcodes()*/
    _58init_opcodes();

    /** 	transoptions()*/
    _3transoptions();

    /** 	if compiler_type = COMPILER_UNKNOWN then*/
    if (_55compiler_type_44322 != 0)
    goto L2; // [33] 75

    /** 		if TWINDOWS then*/
    if (_40TWINDOWS_16388 == 0)
    {
        goto L3; // [41] 56
    }
    else{
    }

    /** 			compiler_type = COMPILER_WATCOM*/
    _55compiler_type_44322 = 2;
    goto L4; // [53] 74
L3: 

    /** 		elsif TUNIX then*/
    if (_40TUNIX_16392 == 0)
    {
        goto L5; // [60] 73
    }
    else{
    }

    /** 			compiler_type = COMPILER_GCC*/
    _55compiler_type_44322 = 1;
L5: 
L4: 
L2: 

    /** 	switch compiler_type do*/
    _0 = _55compiler_type_44322;
    switch ( _0 ){ 

        /** 	  	case COMPILER_GCC then*/
        case 1:

        /** 			break -- to avoid empty block warning*/
        goto L6; // [90] 328
        goto L6; // [92] 328

        /** 		case COMPILER_WATCOM then*/
        case 2:

        /** 			wat_path = getenv("WATCOM")*/
        DeRefi(_35wat_path_16321);
        _35wat_path_16321 = EGetEnv(_31900);

        /** 			if atom(wat_path) then*/
        _31902 = IS_ATOM(_35wat_path_16321);
        if (_31902 == 0)
        {
            _31902 = NOVALUE;
            goto L7; // [110] 146
        }
        else{
            _31902 = NOVALUE;
        }

        /** 				if build_system_type = BUILD_DIRECT then*/
        if (_55build_system_type_44318 != 3)
        goto L8; // [119] 133

        /** 					CompileErr(159)*/
        RefDS(_22023);
        _44CompileErr(159, _22023, 0);
        goto L6; // [130] 328
L8: 

        /** 					Warning(159, translator_warning_flag)*/
        RefDS(_22023);
        _44Warning(159, 128, _22023);
        goto L6; // [143] 328
L7: 

        /** 			elsif find(' ', wat_path) then*/
        _31905 = find_from(32, _35wat_path_16321, 1);
        if (_31905 == 0)
        {
            _31905 = NOVALUE;
            goto L9; // [155] 170
        }
        else{
            _31905 = NOVALUE;
        }

        /** 				Warning( 214, translator_warning_flag)*/
        RefDS(_22023);
        _44Warning(214, 128, _22023);
        goto L6; // [167] 328
L9: 

        /** 			elsif atom(getenv("INCLUDE")) then*/
        _31907 = EGetEnv(_31906);
        _31908 = IS_ATOM(_31907);
        DeRef(_31907);
        _31907 = NOVALUE;
        if (_31908 == 0)
        {
            _31908 = NOVALUE;
            goto LA; // [178] 193
        }
        else{
            _31908 = NOVALUE;
        }

        /** 				Warning( 215, translator_warning_flag )*/
        RefDS(_22023);
        _44Warning(215, 128, _22023);
        goto L6; // [190] 328
LA: 

        /** 			elsif not file_exists(wat_path & SLASH & "binnt" & SLASH & "wcc386.exe") then*/
        {
            int concat_list[5];

            concat_list[0] = _31910;
            concat_list[1] = 92;
            concat_list[2] = _31909;
            concat_list[3] = 92;
            concat_list[4] = _35wat_path_16321;
            Concat_N((object_ptr)&_31911, concat_list, 5);
        }
        _31912 = _17file_exists(_31911);
        _31911 = NOVALUE;
        if (IS_ATOM_INT(_31912)) {
            if (_31912 != 0){
                DeRef(_31912);
                _31912 = NOVALUE;
                goto LB; // [213] 261
            }
        }
        else {
            if (DBL_PTR(_31912)->dbl != 0.0){
                DeRef(_31912);
                _31912 = NOVALUE;
                goto LB; // [213] 261
            }
        }
        DeRef(_31912);
        _31912 = NOVALUE;

        /** 				if build_system_type = BUILD_DIRECT then*/
        if (_55build_system_type_44318 != 3)
        goto LC; // [222] 242

        /** 					CompileErr( 352, {wat_path})*/
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        Ref(_35wat_path_16321);
        *((int *)(_2+4)) = _35wat_path_16321;
        _31915 = MAKE_SEQ(_1);
        _44CompileErr(352, _31915, 0);
        _31915 = NOVALUE;
        goto L6; // [239] 328
LC: 

        /** 					Warning( 352, translator_warning_flag, {wat_path})*/
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        Ref(_35wat_path_16321);
        *((int *)(_2+4)) = _35wat_path_16321;
        _31916 = MAKE_SEQ(_1);
        _44Warning(352, 128, _31916);
        _31916 = NOVALUE;
        goto L6; // [258] 328
LB: 

        /** 			elsif match(upper(wat_path & "\\H;" & wat_path & "\\H\\NT"),*/
        {
            int concat_list[4];

            concat_list[0] = _31918;
            concat_list[1] = _35wat_path_16321;
            concat_list[2] = _31917;
            concat_list[3] = _35wat_path_16321;
            Concat_N((object_ptr)&_31919, concat_list, 4);
        }
        _31920 = _14upper(_31919);
        _31919 = NOVALUE;
        _31921 = EGetEnv(_31906);
        _31922 = _14upper(_31921);
        _31921 = NOVALUE;
        _31923 = e_match_from(_31920, _31922, 1);
        DeRef(_31920);
        _31920 = NOVALUE;
        DeRef(_31922);
        _31922 = NOVALUE;
        if (_31923 == 1)
        goto L6; // [290] 328

        /** 				Warning( 216, translator_warning_flag, {wat_path,getenv("INCLUDE")} )*/
        _31925 = EGetEnv(_31906);
        Ref(_35wat_path_16321);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _35wat_path_16321;
        ((int *)_2)[2] = _31925;
        _31926 = MAKE_SEQ(_1);
        _31925 = NOVALUE;
        _44Warning(216, 128, _31926);
        _31926 = NOVALUE;
        goto L6; // [314] 328

        /** 		case else*/
        default:

        /** 			CompileErr(150)*/
        RefDS(_22023);
        _44CompileErr(150, _22023, 0);
    ;}L6: 

    /** end procedure*/
    return;
    ;
}


void _3CheckPlatform()
{
    int _31933 = NOVALUE;
    int _31931 = NOVALUE;
    int _31930 = NOVALUE;
    int _0, _1, _2;
    

    /** 	OpDefines = eu:remove(OpDefines,*/
    _31930 = find_from(_25436, _35OpDefines_16317, 1);
    _31931 = find_from(_25437, _35OpDefines_16317, 1);
    {
        s1_ptr assign_space = SEQ_PTR(_35OpDefines_16317);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_31930)) ? _31930 : (long)(DBL_PTR(_31930)->dbl);
        int stop = (IS_ATOM_INT(_31931)) ? _31931 : (long)(DBL_PTR(_31931)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_35OpDefines_16317), start, &_35OpDefines_16317 );
            }
            else Tail(SEQ_PTR(_35OpDefines_16317), stop+1, &_35OpDefines_16317);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_35OpDefines_16317), start, &_35OpDefines_16317);
        }
        else {
            assign_slice_seq = &assign_space;
            _35OpDefines_16317 = Remove_elements(start, stop, (SEQ_PTR(_35OpDefines_16317)->ref == 1));
        }
    }
    _31930 = NOVALUE;
    _31931 = NOVALUE;

    /** 	OpDefines &= GetPlatformDefines(1)*/
    _31933 = _40GetPlatformDefines(1);
    if (IS_SEQUENCE(_35OpDefines_16317) && IS_ATOM(_31933)) {
        Ref(_31933);
        Append(&_35OpDefines_16317, _35OpDefines_16317, _31933);
    }
    else if (IS_ATOM(_35OpDefines_16317) && IS_SEQUENCE(_31933)) {
    }
    else {
        Concat((object_ptr)&_35OpDefines_16317, _35OpDefines_16317, _31933);
    }
    DeRef(_31933);
    _31933 = NOVALUE;

    /** end procedure*/
    return;
    ;
}



// 0xD3EA3066
