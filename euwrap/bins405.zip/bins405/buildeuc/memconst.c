// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int _10valid_memory_protection_constant(int _x_287)
{
    int _38 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return find( x, MEMORY_PROTECTION )*/
    _38 = find_from(_x_287, _10MEMORY_PROTECTION_283, 1);
    DeRef(_x_287);
    return _38;
    ;
}


int _10test_read(int _protection_291)
{
    int _40 = NOVALUE;
    int _0, _1, _2;
    

    /** 	ifdef UNIX then*/

    /** 		return find( protection, { PAGE_EXECUTE_READ, PAGE_EXECUTE_READWRITE,  */
    _40 = find_from(_protection_291, _39, 1);
    DeRef(_protection_291);
    return _40;
    ;
}


int _10test_write(int _protection_296)
{
    int _42 = NOVALUE;
    int _0, _1, _2;
    

    /** 	ifdef UNIX then*/

    /** 		return find( protection, { PAGE_EXECUTE_READWRITE,*/
    _42 = find_from(_protection_296, _41, 1);
    DeRef(_protection_296);
    return _42;
    ;
}


int _10test_exec(int _protection_301)
{
    int _44 = NOVALUE;
    int _0, _1, _2;
    

    /** 	ifdef UNIX then*/

    /** 		return find(protection,{PAGE_EXECUTE,*/
    _44 = find_from(_protection_301, _43, 1);
    DeRef(_protection_301);
    return _44;
    ;
}


int _10valid_wordsize(int _i_306)
{
    int _46 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return find(i, {1,2,4})*/
    _46 = find_from(_i_306, _45, 1);
    DeRef(_i_306);
    return _46;
    ;
}



// 0x6FDF7E7D
