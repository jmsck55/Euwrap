// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int _36open_locked(int _file_path_15272)
{
    int _fh_15273 = NOVALUE;
    int _0, _1, _2;
    

    /** 	fh = open(file_path, "u")*/
    _fh_15273 = EOpen(_file_path_15272, _8628, 0);

    /** 	if fh = -1 then*/
    if (_fh_15273 != -1)
    goto L1; // [12] 24

    /** 		fh = open(file_path, "r")*/
    _fh_15273 = EOpen(_file_path_15272, _3889, 0);
L1: 

    /** 	return fh*/
    DeRefDS(_file_path_15272);
    return _fh_15273;
    ;
}


int _36get_eudir()
{
    int _possible_paths_15290 = NOVALUE;
    int _homepath_15295 = NOVALUE;
    int _homedrive_15297 = NOVALUE;
    int _possible_path_15320 = NOVALUE;
    int _possible_path_15334 = NOVALUE;
    int _file_check_15348 = NOVALUE;
    int _8679 = NOVALUE;
    int _8678 = NOVALUE;
    int _8677 = NOVALUE;
    int _8675 = NOVALUE;
    int _8673 = NOVALUE;
    int _8671 = NOVALUE;
    int _8670 = NOVALUE;
    int _8669 = NOVALUE;
    int _8668 = NOVALUE;
    int _8667 = NOVALUE;
    int _8665 = NOVALUE;
    int _8663 = NOVALUE;
    int _8662 = NOVALUE;
    int _8658 = NOVALUE;
    int _8656 = NOVALUE;
    int _8653 = NOVALUE;
    int _8652 = NOVALUE;
    int _8651 = NOVALUE;
    int _8650 = NOVALUE;
    int _8649 = NOVALUE;
    int _8648 = NOVALUE;
    int _8647 = NOVALUE;
    int _8646 = NOVALUE;
    int _8645 = NOVALUE;
    int _8634 = NOVALUE;
    int _8632 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if sequence(eudir) then*/
    _8632 = IS_SEQUENCE(_36eudir_15268);
    if (_8632 == 0)
    {
        _8632 = NOVALUE;
        goto L1; // [8] 20
    }
    else{
        _8632 = NOVALUE;
    }

    /** 		return eudir*/
    Ref(_36eudir_15268);
    DeRef(_possible_paths_15290);
    DeRefi(_homepath_15295);
    DeRefi(_homedrive_15297);
    return _36eudir_15268;
L1: 

    /** 	eudir = getenv("EUDIR")*/
    DeRef(_36eudir_15268);
    _36eudir_15268 = EGetEnv(_3795);

    /** 	if sequence(eudir) then*/
    _8634 = IS_SEQUENCE(_36eudir_15268);
    if (_8634 == 0)
    {
        _8634 = NOVALUE;
        goto L2; // [32] 44
    }
    else{
        _8634 = NOVALUE;
    }

    /** 		return eudir*/
    Ref(_36eudir_15268);
    DeRef(_possible_paths_15290);
    DeRefi(_homepath_15295);
    DeRefi(_homedrive_15297);
    return _36eudir_15268;
L2: 

    /** 	ifdef UNIX then*/

    /** 		sequence possible_paths = {*/
    _0 = _possible_paths_15290;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_8639);
    *((int *)(_2+4)) = _8639;
    RefDS(_8640);
    *((int *)(_2+8)) = _8640;
    RefDS(_8641);
    *((int *)(_2+12)) = _8641;
    _possible_paths_15290 = MAKE_SEQ(_1);
    DeRef(_0);

    /** 		object homepath = getenv("HOMEPATH")*/
    DeRefi(_homepath_15295);
    _homepath_15295 = EGetEnv(_3428);

    /** 		object homedrive = getenv("HOMEDRIVE")*/
    DeRefi(_homedrive_15297);
    _homedrive_15297 = EGetEnv(_3426);

    /** 		if sequence(homepath) and sequence(homedrive) then*/
    _8645 = IS_SEQUENCE(_homepath_15295);
    if (_8645 == 0) {
        goto L3; // [69] 134
    }
    _8647 = IS_SEQUENCE(_homedrive_15297);
    if (_8647 == 0)
    {
        _8647 = NOVALUE;
        goto L3; // [77] 134
    }
    else{
        _8647 = NOVALUE;
    }

    /** 			if length(homepath) and not equal(homepath[$], SLASH) then*/
    if (IS_SEQUENCE(_homepath_15295)){
            _8648 = SEQ_PTR(_homepath_15295)->length;
    }
    else {
        _8648 = 1;
    }
    if (_8648 == 0) {
        goto L4; // [85] 118
    }
    if (IS_SEQUENCE(_homepath_15295)){
            _8650 = SEQ_PTR(_homepath_15295)->length;
    }
    else {
        _8650 = 1;
    }
    _2 = (int)SEQ_PTR(_homepath_15295);
    _8651 = (int)*(((s1_ptr)_2)->base + _8650);
    if (_8651 == 92)
    _8652 = 1;
    else if (IS_ATOM_INT(_8651) && IS_ATOM_INT(92))
    _8652 = 0;
    else
    _8652 = (compare(_8651, 92) == 0);
    _8651 = NOVALUE;
    _8653 = (_8652 == 0);
    _8652 = NOVALUE;
    if (_8653 == 0)
    {
        DeRef(_8653);
        _8653 = NOVALUE;
        goto L4; // [106] 118
    }
    else{
        DeRef(_8653);
        _8653 = NOVALUE;
    }

    /** 				homepath &= SLASH*/
    if (IS_SEQUENCE(_homepath_15295) && IS_ATOM(92)) {
        Append(&_homepath_15295, _homepath_15295, 92);
    }
    else if (IS_ATOM(_homepath_15295) && IS_SEQUENCE(92)) {
    }
    else {
        Concat((object_ptr)&_homepath_15295, _homepath_15295, 92);
    }
L4: 

    /** 			possible_paths = append(possible_paths, homedrive & SLASH & homepath & "euphoria")*/
    {
        int concat_list[4];

        concat_list[0] = _8655;
        concat_list[1] = _homepath_15295;
        concat_list[2] = 92;
        concat_list[3] = _homedrive_15297;
        Concat_N((object_ptr)&_8656, concat_list, 4);
    }
    RefDS(_8656);
    Append(&_possible_paths_15290, _possible_paths_15290, _8656);
    DeRefDS(_8656);
    _8656 = NOVALUE;
L3: 

    /** 	for i = 1 to length(possible_paths) do*/
    if (IS_SEQUENCE(_possible_paths_15290)){
            _8658 = SEQ_PTR(_possible_paths_15290)->length;
    }
    else {
        _8658 = 1;
    }
    {
        int _i_15318;
        _i_15318 = 1;
L5: 
        if (_i_15318 > _8658){
            goto L6; // [141] 200
        }

        /** 		sequence possible_path = possible_paths[i]*/
        DeRef(_possible_path_15320);
        _2 = (int)SEQ_PTR(_possible_paths_15290);
        _possible_path_15320 = (int)*(((s1_ptr)_2)->base + _i_15318);
        RefDS(_possible_path_15320);

        /** 		if file_exists(possible_path & SLASH & "include" & SLASH & "euphoria.h") then*/
        {
            int concat_list[5];

            concat_list[0] = _8661;
            concat_list[1] = 92;
            concat_list[2] = _8660;
            concat_list[3] = 92;
            concat_list[4] = _possible_path_15320;
            Concat_N((object_ptr)&_8662, concat_list, 5);
        }
        _8663 = _17file_exists(_8662);
        _8662 = NOVALUE;
        if (_8663 == 0) {
            DeRef(_8663);
            _8663 = NOVALUE;
            goto L7; // [174] 191
        }
        else {
            if (!IS_ATOM_INT(_8663) && DBL_PTR(_8663)->dbl == 0.0){
                DeRef(_8663);
                _8663 = NOVALUE;
                goto L7; // [174] 191
            }
            DeRef(_8663);
            _8663 = NOVALUE;
        }
        DeRef(_8663);
        _8663 = NOVALUE;

        /** 			eudir = possible_path*/
        RefDS(_possible_path_15320);
        DeRef(_36eudir_15268);
        _36eudir_15268 = _possible_path_15320;

        /** 			return eudir*/
        RefDS(_36eudir_15268);
        DeRefDS(_possible_path_15320);
        DeRefDS(_possible_paths_15290);
        DeRefi(_homepath_15295);
        DeRefi(_homedrive_15297);
        return _36eudir_15268;
L7: 
        DeRef(_possible_path_15320);
        _possible_path_15320 = NOVALUE;

        /** 	end for*/
        _i_15318 = _i_15318 + 1;
        goto L5; // [195] 148
L6: 
        ;
    }

    /** 	possible_paths = include_paths(0)*/
    _0 = _possible_paths_15290;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_3819);
    *((int *)(_2+4)) = _3819;
    RefDS(_3818);
    *((int *)(_2+8)) = _3818;
    RefDS(_3817);
    *((int *)(_2+12)) = _3817;
    _possible_paths_15290 = MAKE_SEQ(_1);
    DeRef(_0);

    /** 	for i = 1 to length(possible_paths) do*/
    _8665 = 3;
    {
        int _i_15332;
        _i_15332 = 1;
L8: 
        if (_i_15332 > 3){
            goto L9; // [213] 338
        }

        /** 		sequence possible_path = possible_paths[i]*/
        DeRef(_possible_path_15334);
        _2 = (int)SEQ_PTR(_possible_paths_15290);
        _possible_path_15334 = (int)*(((s1_ptr)_2)->base + _i_15332);
        RefDS(_possible_path_15334);

        /** 		if equal(possible_path[$], SLASH) then*/
        if (IS_SEQUENCE(_possible_path_15334)){
                _8667 = SEQ_PTR(_possible_path_15334)->length;
        }
        else {
            _8667 = 1;
        }
        _2 = (int)SEQ_PTR(_possible_path_15334);
        _8668 = (int)*(((s1_ptr)_2)->base + _8667);
        if (_8668 == 92)
        _8669 = 1;
        else if (IS_ATOM_INT(_8668) && IS_ATOM_INT(92))
        _8669 = 0;
        else
        _8669 = (compare(_8668, 92) == 0);
        _8668 = NOVALUE;
        if (_8669 == 0)
        {
            _8669 = NOVALUE;
            goto LA; // [243] 261
        }
        else{
            _8669 = NOVALUE;
        }

        /** 			possible_path = possible_path[1..$-1]*/
        if (IS_SEQUENCE(_possible_path_15334)){
                _8670 = SEQ_PTR(_possible_path_15334)->length;
        }
        else {
            _8670 = 1;
        }
        _8671 = _8670 - 1;
        _8670 = NOVALUE;
        rhs_slice_target = (object_ptr)&_possible_path_15334;
        RHS_Slice(_possible_path_15334, 1, _8671);
LA: 

        /** 		if not ends("include", possible_path) then*/
        RefDS(_8660);
        RefDS(_possible_path_15334);
        _8673 = _16ends(_8660, _possible_path_15334);
        if (IS_ATOM_INT(_8673)) {
            if (_8673 != 0){
                DeRef(_8673);
                _8673 = NOVALUE;
                goto LB; // [268] 278
            }
        }
        else {
            if (DBL_PTR(_8673)->dbl != 0.0){
                DeRef(_8673);
                _8673 = NOVALUE;
                goto LB; // [268] 278
            }
        }
        DeRef(_8673);
        _8673 = NOVALUE;

        /** 			continue*/
        DeRefDS(_possible_path_15334);
        _possible_path_15334 = NOVALUE;
        DeRef(_file_check_15348);
        _file_check_15348 = NOVALUE;
        goto LC; // [275] 333
LB: 

        /** 		sequence file_check = possible_path*/
        RefDS(_possible_path_15334);
        DeRef(_file_check_15348);
        _file_check_15348 = _possible_path_15334;

        /** 		file_check &= SLASH & "euphoria.h"*/
        Prepend(&_8675, _8661, 92);
        Concat((object_ptr)&_file_check_15348, _file_check_15348, _8675);
        DeRefDS(_8675);
        _8675 = NOVALUE;

        /** 		if file_exists(file_check) then*/
        RefDS(_file_check_15348);
        _8677 = _17file_exists(_file_check_15348);
        if (_8677 == 0) {
            DeRef(_8677);
            _8677 = NOVALUE;
            goto LD; // [303] 329
        }
        else {
            if (!IS_ATOM_INT(_8677) && DBL_PTR(_8677)->dbl == 0.0){
                DeRef(_8677);
                _8677 = NOVALUE;
                goto LD; // [303] 329
            }
            DeRef(_8677);
            _8677 = NOVALUE;
        }
        DeRef(_8677);
        _8677 = NOVALUE;

        /** 			eudir = possible_path[1..$-8] -- strip SLASH & "include"*/
        if (IS_SEQUENCE(_possible_path_15334)){
                _8678 = SEQ_PTR(_possible_path_15334)->length;
        }
        else {
            _8678 = 1;
        }
        _8679 = _8678 - 8;
        _8678 = NOVALUE;
        rhs_slice_target = (object_ptr)&_36eudir_15268;
        RHS_Slice(_possible_path_15334, 1, _8679);

        /** 			return eudir*/
        RefDS(_36eudir_15268);
        DeRefDS(_possible_path_15334);
        DeRefDS(_file_check_15348);
        DeRef(_possible_paths_15290);
        DeRefi(_homepath_15295);
        DeRefi(_homedrive_15297);
        DeRef(_8671);
        _8671 = NOVALUE;
        _8679 = NOVALUE;
        return _36eudir_15268;
LD: 
        DeRef(_possible_path_15334);
        _possible_path_15334 = NOVALUE;
        DeRef(_file_check_15348);
        _file_check_15348 = NOVALUE;

        /** 	end for*/
LC: 
        _i_15332 = _i_15332 + 1;
        goto L8; // [333] 220
L9: 
        ;
    }

    /** 	return ""*/
    RefDS(_5);
    DeRef(_possible_paths_15290);
    DeRefi(_homepath_15295);
    DeRefi(_homedrive_15297);
    DeRef(_8671);
    _8671 = NOVALUE;
    DeRef(_8679);
    _8679 = NOVALUE;
    return _5;
    ;
}


void _36set_eudir(int _new_eudir_15360)
{
    int _0, _1, _2;
    

    /** 	eudir = new_eudir*/
    RefDS(_new_eudir_15360);
    DeRef(_36eudir_15268);
    _36eudir_15268 = _new_eudir_15360;

    /** 	cmdline_eudir = 1*/
    _36cmdline_eudir_15269 = 1;

    /** end procedure*/
    DeRefDS(_new_eudir_15360);
    return;
    ;
}


int _36is_eudir_from_cmdline()
{
    int _0, _1, _2;
    

    /** 	return cmdline_eudir*/
    return _36cmdline_eudir_15269;
    ;
}



// 0xAD401405
