// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int _17find_first_wildcard(int _name_6000, int _from_6001)
{
    int _asterisk_at_6002 = NOVALUE;
    int _question_at_6004 = NOVALUE;
    int _first_wildcard_at_6006 = NOVALUE;
    int _3141 = NOVALUE;
    int _3140 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer asterisk_at = eu:find('*', name, from)*/
    _asterisk_at_6002 = find_from(42, _name_6000, 1);

    /** 	integer question_at = eu:find('?', name, from)*/
    _question_at_6004 = find_from(63, _name_6000, 1);

    /** 	integer first_wildcard_at = asterisk_at*/
    _first_wildcard_at_6006 = _asterisk_at_6002;

    /** 	if asterisk_at or question_at then*/
    if (_asterisk_at_6002 != 0) {
        goto L1; // [26] 35
    }
    if (_question_at_6004 == 0)
    {
        goto L2; // [31] 56
    }
    else{
    }
L1: 

    /** 		if question_at and question_at < asterisk_at then*/
    if (_question_at_6004 == 0) {
        goto L3; // [37] 55
    }
    _3141 = (_question_at_6004 < _asterisk_at_6002);
    if (_3141 == 0)
    {
        DeRef(_3141);
        _3141 = NOVALUE;
        goto L3; // [46] 55
    }
    else{
        DeRef(_3141);
        _3141 = NOVALUE;
    }

    /** 			first_wildcard_at = question_at*/
    _first_wildcard_at_6006 = _question_at_6004;
L3: 
L2: 

    /** 	return first_wildcard_at*/
    DeRefDS(_name_6000);
    return _first_wildcard_at_6006;
    ;
}


int _17dir(int _name_6014)
{
    int _3142 = NOVALUE;
    int _0, _1, _2;
    

    /** 	ifdef WINDOWS then*/

    /** 		return machine_func(M_DIR, name)*/
    _3142 = machine(22, _name_6014);
    DeRefDS(_name_6014);
    return _3142;
    ;
}


int _17current_dir()
{
    int _3144 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return machine_func(M_CURRENT_DIR, 0)*/
    _3144 = machine(23, 0);
    return _3144;
    ;
}


int _17chdir(int _newdir_6022)
{
    int _3145 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return machine_func(M_CHDIR, newdir)*/
    _3145 = machine(63, _newdir_6022);
    DeRefDS(_newdir_6022);
    return _3145;
    ;
}


int _17create_directory(int _name_6113, int _mode_6114, int _mkparent_6116)
{
    int _pname_6117 = NOVALUE;
    int _ret_6118 = NOVALUE;
    int _pos_6119 = NOVALUE;
    int _3213 = NOVALUE;
    int _3210 = NOVALUE;
    int _3209 = NOVALUE;
    int _3208 = NOVALUE;
    int _3207 = NOVALUE;
    int _3204 = NOVALUE;
    int _3201 = NOVALUE;
    int _3200 = NOVALUE;
    int _3198 = NOVALUE;
    int _3197 = NOVALUE;
    int _3195 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if length(name) = 0 then*/
    if (IS_SEQUENCE(_name_6113)){
            _3195 = SEQ_PTR(_name_6113)->length;
    }
    else {
        _3195 = 1;
    }
    if (_3195 != 0)
    goto L1; // [12] 23

    /** 		return 0 -- failed*/
    DeRefDS(_name_6113);
    DeRef(_pname_6117);
    DeRef(_ret_6118);
    return 0;
L1: 

    /** 	if name[$] = SLASH then*/
    if (IS_SEQUENCE(_name_6113)){
            _3197 = SEQ_PTR(_name_6113)->length;
    }
    else {
        _3197 = 1;
    }
    _2 = (int)SEQ_PTR(_name_6113);
    _3198 = (int)*(((s1_ptr)_2)->base + _3197);
    if (binary_op_a(NOTEQ, _3198, 92)){
        _3198 = NOVALUE;
        goto L2; // [32] 51
    }
    _3198 = NOVALUE;

    /** 		name = name[1 .. $-1]*/
    if (IS_SEQUENCE(_name_6113)){
            _3200 = SEQ_PTR(_name_6113)->length;
    }
    else {
        _3200 = 1;
    }
    _3201 = _3200 - 1;
    _3200 = NOVALUE;
    rhs_slice_target = (object_ptr)&_name_6113;
    RHS_Slice(_name_6113, 1, _3201);
L2: 

    /** 	if mkparent != 0 then*/
    if (_mkparent_6116 == 0)
    goto L3; // [53] 101

    /** 		pos = search:rfind(SLASH, name)*/
    if (IS_SEQUENCE(_name_6113)){
            _3204 = SEQ_PTR(_name_6113)->length;
    }
    else {
        _3204 = 1;
    }
    RefDS(_name_6113);
    _pos_6119 = _16rfind(92, _name_6113, _3204);
    _3204 = NOVALUE;
    if (!IS_ATOM_INT(_pos_6119)) {
        _1 = (long)(DBL_PTR(_pos_6119)->dbl);
        DeRefDS(_pos_6119);
        _pos_6119 = _1;
    }

    /** 		if pos != 0 then*/
    if (_pos_6119 == 0)
    goto L4; // [72] 100

    /** 			ret = create_directory(name[1.. pos-1], mode, mkparent)*/
    _3207 = _pos_6119 - 1;
    rhs_slice_target = (object_ptr)&_3208;
    RHS_Slice(_name_6113, 1, _3207);
    DeRef(_3209);
    _3209 = _mode_6114;
    DeRef(_3210);
    _3210 = _mkparent_6116;
    _0 = _ret_6118;
    _ret_6118 = _17create_directory(_3208, _3209, _3210);
    DeRef(_0);
    _3208 = NOVALUE;
    _3209 = NOVALUE;
    _3210 = NOVALUE;
L4: 
L3: 

    /** 	pname = machine:allocate_string(name)*/
    RefDS(_name_6113);
    _0 = _pname_6117;
    _pname_6117 = _9allocate_string(_name_6113, 0);
    DeRef(_0);

    /** 	ifdef UNIX then*/

    /** 		ret = c_func(xCreateDirectory, {pname, 0})*/
    Ref(_pname_6117);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _pname_6117;
    ((int *)_2)[2] = 0;
    _3213 = MAKE_SEQ(_1);
    DeRef(_ret_6118);
    _ret_6118 = call_c(1, _17xCreateDirectory_5950, _3213);
    DeRefDS(_3213);
    _3213 = NOVALUE;

    /** 		mode = mode -- get rid of not used warning*/
    _mode_6114 = _mode_6114;

    /** 	return ret*/
    DeRefDS(_name_6113);
    DeRef(_pname_6117);
    DeRef(_3201);
    _3201 = NOVALUE;
    DeRef(_3207);
    _3207 = NOVALUE;
    return _ret_6118;
    ;
}


int _17delete_file(int _name_6155)
{
    int _pfilename_6156 = NOVALUE;
    int _success_6158 = NOVALUE;
    int _3219 = NOVALUE;
    int _0, _1, _2;
    

    /** 	atom pfilename = machine:allocate_string(name)*/
    RefDS(_name_6155);
    _0 = _pfilename_6156;
    _pfilename_6156 = _9allocate_string(_name_6155, 0);
    DeRef(_0);

    /** 	integer success = c_func(xDeleteFile, {pfilename})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_pfilename_6156);
    *((int *)(_2+4)) = _pfilename_6156;
    _3219 = MAKE_SEQ(_1);
    _success_6158 = call_c(1, _17xDeleteFile_5946, _3219);
    DeRefDS(_3219);
    _3219 = NOVALUE;
    if (!IS_ATOM_INT(_success_6158)) {
        _1 = (long)(DBL_PTR(_success_6158)->dbl);
        DeRefDS(_success_6158);
        _success_6158 = _1;
    }

    /** 	ifdef UNIX then*/

    /** 	machine:free(pfilename)*/
    Ref(_pfilename_6156);
    _9free(_pfilename_6156);

    /** 	return success*/
    DeRefDS(_name_6155);
    DeRef(_pfilename_6156);
    return _success_6158;
    ;
}


int _17curdir(int _drive_id_6163)
{
    int _lCurDir_6164 = NOVALUE;
    int _lOrigDir_6165 = NOVALUE;
    int _lDrive_6166 = NOVALUE;
    int _current_dir_inlined_current_dir_at_25_6171 = NOVALUE;
    int _chdir_inlined_chdir_at_55_6174 = NOVALUE;
    int _current_dir_inlined_current_dir_at_77_6177 = NOVALUE;
    int _chdir_inlined_chdir_at_109_6184 = NOVALUE;
    int _newdir_inlined_chdir_at_106_6183 = NOVALUE;
    int _3227 = NOVALUE;
    int _3226 = NOVALUE;
    int _3225 = NOVALUE;
    int _3223 = NOVALUE;
    int _3221 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_drive_id_6163)) {
        _1 = (long)(DBL_PTR(_drive_id_6163)->dbl);
        DeRefDS(_drive_id_6163);
        _drive_id_6163 = _1;
    }

    /** 	ifdef not LINUX then*/

    /** 	    sequence lOrigDir = ""*/
    RefDS(_5);
    DeRefi(_lOrigDir_6165);
    _lOrigDir_6165 = _5;

    /** 	    sequence lDrive*/

    /** 	    if t_alpha(drive_id) then*/
    _3221 = _13t_alpha(_drive_id_6163);
    if (_3221 == 0) {
        DeRef(_3221);
        _3221 = NOVALUE;
        goto L1; // [20] 75
    }
    else {
        if (!IS_ATOM_INT(_3221) && DBL_PTR(_3221)->dbl == 0.0){
            DeRef(_3221);
            _3221 = NOVALUE;
            goto L1; // [20] 75
        }
        DeRef(_3221);
        _3221 = NOVALUE;
    }
    DeRef(_3221);
    _3221 = NOVALUE;

    /** 		    lOrigDir =  current_dir()*/

    /** 	return machine_func(M_CURRENT_DIR, 0)*/
    DeRefDSi(_lOrigDir_6165);
    _lOrigDir_6165 = machine(23, 0);

    /** 		    lDrive = "  "*/
    RefDS(_150);
    DeRefi(_lDrive_6166);
    _lDrive_6166 = _150;

    /** 		    lDrive[1] = drive_id*/
    _2 = (int)SEQ_PTR(_lDrive_6166);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _lDrive_6166 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    *(int *)_2 = _drive_id_6163;

    /** 		    lDrive[2] = ':'*/
    _2 = (int)SEQ_PTR(_lDrive_6166);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _lDrive_6166 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    *(int *)_2 = 58;

    /** 		    if chdir(lDrive) = 0 then*/

    /** 	return machine_func(M_CHDIR, newdir)*/
    _chdir_inlined_chdir_at_55_6174 = machine(63, _lDrive_6166);
    if (_chdir_inlined_chdir_at_55_6174 != 0)
    goto L2; // [62] 74

    /** 		    	lOrigDir = ""*/
    RefDS(_5);
    DeRefi(_lOrigDir_6165);
    _lOrigDir_6165 = _5;
L2: 
L1: 

    /**     lCurDir = current_dir()*/

    /** 	return machine_func(M_CURRENT_DIR, 0)*/
    DeRefi(_lCurDir_6164);
    _lCurDir_6164 = machine(23, 0);

    /** 	ifdef not LINUX then*/

    /** 		if length(lOrigDir) > 0 then*/
    if (IS_SEQUENCE(_lOrigDir_6165)){
            _3223 = SEQ_PTR(_lOrigDir_6165)->length;
    }
    else {
        _3223 = 1;
    }
    if (_3223 <= 0)
    goto L3; // [95] 121

    /** 	    	chdir(lOrigDir[1..2])*/
    rhs_slice_target = (object_ptr)&_3225;
    RHS_Slice(_lOrigDir_6165, 1, 2);
    DeRefi(_newdir_inlined_chdir_at_106_6183);
    _newdir_inlined_chdir_at_106_6183 = _3225;
    _3225 = NOVALUE;

    /** 	return machine_func(M_CHDIR, newdir)*/
    _chdir_inlined_chdir_at_109_6184 = machine(63, _newdir_inlined_chdir_at_106_6183);
    DeRefi(_newdir_inlined_chdir_at_106_6183);
    _newdir_inlined_chdir_at_106_6183 = NOVALUE;
L3: 

    /** 	if (lCurDir[$] != SLASH) then*/
    if (IS_SEQUENCE(_lCurDir_6164)){
            _3226 = SEQ_PTR(_lCurDir_6164)->length;
    }
    else {
        _3226 = 1;
    }
    _2 = (int)SEQ_PTR(_lCurDir_6164);
    _3227 = (int)*(((s1_ptr)_2)->base + _3226);
    if (_3227 == 92)
    goto L4; // [130] 141

    /** 		lCurDir &= SLASH*/
    Append(&_lCurDir_6164, _lCurDir_6164, 92);
L4: 

    /** 	return lCurDir*/
    DeRefi(_lOrigDir_6165);
    DeRefi(_lDrive_6166);
    _3227 = NOVALUE;
    return _lCurDir_6164;
    ;
}


int _17remove_directory(int _dir_name_6265, int _force_6266)
{
    int _pname_6267 = NOVALUE;
    int _ret_6268 = NOVALUE;
    int _files_6269 = NOVALUE;
    int _D_NAME_6270 = NOVALUE;
    int _D_ATTRIBUTES_6271 = NOVALUE;
    int _dir_inlined_dir_at_97_6292 = NOVALUE;
    int _3318 = NOVALUE;
    int _3314 = NOVALUE;
    int _3313 = NOVALUE;
    int _3312 = NOVALUE;
    int _3310 = NOVALUE;
    int _3309 = NOVALUE;
    int _3308 = NOVALUE;
    int _3307 = NOVALUE;
    int _3306 = NOVALUE;
    int _3305 = NOVALUE;
    int _3304 = NOVALUE;
    int _3303 = NOVALUE;
    int _3299 = NOVALUE;
    int _3297 = NOVALUE;
    int _3296 = NOVALUE;
    int _3295 = NOVALUE;
    int _3293 = NOVALUE;
    int _3292 = NOVALUE;
    int _3291 = NOVALUE;
    int _3289 = NOVALUE;
    int _3288 = NOVALUE;
    int _3286 = NOVALUE;
    int _3284 = NOVALUE;
    int _3282 = NOVALUE;
    int _3280 = NOVALUE;
    int _3279 = NOVALUE;
    int _3277 = NOVALUE;
    int _3276 = NOVALUE;
    int _3274 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer D_NAME = 1, D_ATTRIBUTES = 2*/
    _D_NAME_6270 = 1;
    _D_ATTRIBUTES_6271 = 2;

    /**  	if length(dir_name) > 0 then*/
    if (IS_SEQUENCE(_dir_name_6265)){
            _3274 = SEQ_PTR(_dir_name_6265)->length;
    }
    else {
        _3274 = 1;
    }
    if (_3274 <= 0)
    goto L1; // [18] 51

    /** 		if dir_name[$] = SLASH then*/
    if (IS_SEQUENCE(_dir_name_6265)){
            _3276 = SEQ_PTR(_dir_name_6265)->length;
    }
    else {
        _3276 = 1;
    }
    _2 = (int)SEQ_PTR(_dir_name_6265);
    _3277 = (int)*(((s1_ptr)_2)->base + _3276);
    if (binary_op_a(NOTEQ, _3277, 92)){
        _3277 = NOVALUE;
        goto L2; // [31] 50
    }
    _3277 = NOVALUE;

    /** 			dir_name = dir_name[1 .. $-1]*/
    if (IS_SEQUENCE(_dir_name_6265)){
            _3279 = SEQ_PTR(_dir_name_6265)->length;
    }
    else {
        _3279 = 1;
    }
    _3280 = _3279 - 1;
    _3279 = NOVALUE;
    rhs_slice_target = (object_ptr)&_dir_name_6265;
    RHS_Slice(_dir_name_6265, 1, _3280);
L2: 
L1: 

    /** 	if length(dir_name) = 0 then*/
    if (IS_SEQUENCE(_dir_name_6265)){
            _3282 = SEQ_PTR(_dir_name_6265)->length;
    }
    else {
        _3282 = 1;
    }
    if (_3282 != 0)
    goto L3; // [56] 67

    /** 		return 0	-- nothing specified to delete.*/
    DeRefDS(_dir_name_6265);
    DeRef(_pname_6267);
    DeRef(_ret_6268);
    DeRef(_files_6269);
    DeRef(_3280);
    _3280 = NOVALUE;
    return 0;
L3: 

    /** 	ifdef WINDOWS then*/

    /** 		if length(dir_name) = 2 then*/
    if (IS_SEQUENCE(_dir_name_6265)){
            _3284 = SEQ_PTR(_dir_name_6265)->length;
    }
    else {
        _3284 = 1;
    }
    if (_3284 != 2)
    goto L4; // [74] 96

    /** 			if dir_name[2] = ':' then*/
    _2 = (int)SEQ_PTR(_dir_name_6265);
    _3286 = (int)*(((s1_ptr)_2)->base + 2);
    if (binary_op_a(NOTEQ, _3286, 58)){
        _3286 = NOVALUE;
        goto L5; // [84] 95
    }
    _3286 = NOVALUE;

    /** 				return 0 -- nothing specified to delete*/
    DeRefDS(_dir_name_6265);
    DeRef(_pname_6267);
    DeRef(_ret_6268);
    DeRef(_files_6269);
    DeRef(_3280);
    _3280 = NOVALUE;
    return 0;
L5: 
L4: 

    /** 	files = dir(dir_name)*/

    /** 	ifdef WINDOWS then*/

    /** 		return machine_func(M_DIR, name)*/
    DeRef(_files_6269);
    _files_6269 = machine(22, _dir_name_6265);

    /** 	if atom(files) then*/
    _3288 = IS_ATOM(_files_6269);
    if (_3288 == 0)
    {
        _3288 = NOVALUE;
        goto L6; // [112] 122
    }
    else{
        _3288 = NOVALUE;
    }

    /** 		return 0*/
    DeRefDS(_dir_name_6265);
    DeRef(_pname_6267);
    DeRef(_ret_6268);
    DeRef(_files_6269);
    DeRef(_3280);
    _3280 = NOVALUE;
    return 0;
L6: 

    /** 	if length( files ) < 2 then*/
    if (IS_SEQUENCE(_files_6269)){
            _3289 = SEQ_PTR(_files_6269)->length;
    }
    else {
        _3289 = 1;
    }
    if (_3289 >= 2)
    goto L7; // [127] 138

    /** 		return 0	-- Supplied dir_name was not a directory*/
    DeRefDS(_dir_name_6265);
    DeRef(_pname_6267);
    DeRef(_ret_6268);
    DeRef(_files_6269);
    DeRef(_3280);
    _3280 = NOVALUE;
    return 0;
L7: 

    /** 	ifdef WINDOWS then*/

    /** 		if not equal(files[1][D_NAME], ".") then*/
    _2 = (int)SEQ_PTR(_files_6269);
    _3291 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_3291);
    _3292 = (int)*(((s1_ptr)_2)->base + _D_NAME_6270);
    _3291 = NOVALUE;
    if (_3292 == _3143)
    _3293 = 1;
    else if (IS_ATOM_INT(_3292) && IS_ATOM_INT(_3143))
    _3293 = 0;
    else
    _3293 = (compare(_3292, _3143) == 0);
    _3292 = NOVALUE;
    if (_3293 != 0)
    goto L8; // [154] 164
    _3293 = NOVALUE;

    /** 			return 0 -- Supplied name was not a directory*/
    DeRefDS(_dir_name_6265);
    DeRef(_pname_6267);
    DeRef(_ret_6268);
    DeRef(_files_6269);
    DeRef(_3280);
    _3280 = NOVALUE;
    return 0;
L8: 

    /** 		if not eu:find('d', files[1][D_ATTRIBUTES]) then*/
    _2 = (int)SEQ_PTR(_files_6269);
    _3295 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_3295);
    _3296 = (int)*(((s1_ptr)_2)->base + _D_ATTRIBUTES_6271);
    _3295 = NOVALUE;
    _3297 = find_from(100, _3296, 1);
    _3296 = NOVALUE;
    if (_3297 != 0)
    goto L9; // [179] 189
    _3297 = NOVALUE;

    /** 			return 0 -- Supplied name was not a directory*/
    DeRefDS(_dir_name_6265);
    DeRef(_pname_6267);
    DeRef(_ret_6268);
    DeRef(_files_6269);
    DeRef(_3280);
    _3280 = NOVALUE;
    return 0;
L9: 

    /** 		if length(files) > 2 then*/
    if (IS_SEQUENCE(_files_6269)){
            _3299 = SEQ_PTR(_files_6269)->length;
    }
    else {
        _3299 = 1;
    }
    if (_3299 <= 2)
    goto LA; // [194] 211

    /** 			if not force then*/
    if (_force_6266 != 0)
    goto LB; // [200] 210

    /** 				return 0 -- Directory is not already emptied.*/
    DeRefDS(_dir_name_6265);
    DeRef(_pname_6267);
    DeRef(_ret_6268);
    DeRef(_files_6269);
    DeRef(_3280);
    _3280 = NOVALUE;
    return 0;
LB: 
LA: 

    /** 	dir_name &= SLASH*/
    Append(&_dir_name_6265, _dir_name_6265, 92);

    /** 	ifdef WINDOWS then*/

    /** 		for i = 3 to length(files) do*/
    if (IS_SEQUENCE(_files_6269)){
            _3303 = SEQ_PTR(_files_6269)->length;
    }
    else {
        _3303 = 1;
    }
    {
        int _i_6315;
        _i_6315 = 3;
LC: 
        if (_i_6315 > _3303){
            goto LD; // [224] 316
        }

        /** 			if eu:find('d', files[i][D_ATTRIBUTES]) then*/
        _2 = (int)SEQ_PTR(_files_6269);
        _3304 = (int)*(((s1_ptr)_2)->base + _i_6315);
        _2 = (int)SEQ_PTR(_3304);
        _3305 = (int)*(((s1_ptr)_2)->base + _D_ATTRIBUTES_6271);
        _3304 = NOVALUE;
        _3306 = find_from(100, _3305, 1);
        _3305 = NOVALUE;
        if (_3306 == 0)
        {
            _3306 = NOVALUE;
            goto LE; // [246] 276
        }
        else{
            _3306 = NOVALUE;
        }

        /** 				ret = remove_directory(dir_name & files[i][D_NAME] & SLASH, force)*/
        _2 = (int)SEQ_PTR(_files_6269);
        _3307 = (int)*(((s1_ptr)_2)->base + _i_6315);
        _2 = (int)SEQ_PTR(_3307);
        _3308 = (int)*(((s1_ptr)_2)->base + _D_NAME_6270);
        _3307 = NOVALUE;
        {
            int concat_list[3];

            concat_list[0] = 92;
            concat_list[1] = _3308;
            concat_list[2] = _dir_name_6265;
            Concat_N((object_ptr)&_3309, concat_list, 3);
        }
        _3308 = NOVALUE;
        DeRef(_3310);
        _3310 = _force_6266;
        _0 = _ret_6268;
        _ret_6268 = _17remove_directory(_3309, _3310);
        DeRef(_0);
        _3309 = NOVALUE;
        _3310 = NOVALUE;
        goto LF; // [273] 295
LE: 

        /** 				ret = delete_file(dir_name & files[i][D_NAME])*/
        _2 = (int)SEQ_PTR(_files_6269);
        _3312 = (int)*(((s1_ptr)_2)->base + _i_6315);
        _2 = (int)SEQ_PTR(_3312);
        _3313 = (int)*(((s1_ptr)_2)->base + _D_NAME_6270);
        _3312 = NOVALUE;
        if (IS_SEQUENCE(_dir_name_6265) && IS_ATOM(_3313)) {
            Ref(_3313);
            Append(&_3314, _dir_name_6265, _3313);
        }
        else if (IS_ATOM(_dir_name_6265) && IS_SEQUENCE(_3313)) {
        }
        else {
            Concat((object_ptr)&_3314, _dir_name_6265, _3313);
        }
        _3313 = NOVALUE;
        _0 = _ret_6268;
        _ret_6268 = _17delete_file(_3314);
        DeRef(_0);
        _3314 = NOVALUE;
LF: 

        /** 			if not ret then*/
        if (IS_ATOM_INT(_ret_6268)) {
            if (_ret_6268 != 0){
                goto L10; // [299] 309
            }
        }
        else {
            if (DBL_PTR(_ret_6268)->dbl != 0.0){
                goto L10; // [299] 309
            }
        }

        /** 				return 0*/
        DeRefDS(_dir_name_6265);
        DeRef(_pname_6267);
        DeRef(_ret_6268);
        DeRef(_files_6269);
        DeRef(_3280);
        _3280 = NOVALUE;
        return 0;
L10: 

        /** 		end for*/
        _i_6315 = _i_6315 + 1;
        goto LC; // [311] 231
LD: 
        ;
    }

    /** 	pname = machine:allocate_string(dir_name)*/
    RefDS(_dir_name_6265);
    _0 = _pname_6267;
    _pname_6267 = _9allocate_string(_dir_name_6265, 0);
    DeRef(_0);

    /** 	ret = c_func(xRemoveDirectory, {pname})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_pname_6267);
    *((int *)(_2+4)) = _pname_6267;
    _3318 = MAKE_SEQ(_1);
    DeRef(_ret_6268);
    _ret_6268 = call_c(1, _17xRemoveDirectory_5957, _3318);
    DeRefDS(_3318);
    _3318 = NOVALUE;

    /** 	ifdef UNIX then*/

    /** 	machine:free(pname)*/
    Ref(_pname_6267);
    _9free(_pname_6267);

    /** 	return ret*/
    DeRefDS(_dir_name_6265);
    DeRef(_pname_6267);
    DeRef(_files_6269);
    DeRef(_3280);
    _3280 = NOVALUE;
    return _ret_6268;
    ;
}


int _17pathinfo(int _path_6343, int _std_slash_6344)
{
    int _slash_6345 = NOVALUE;
    int _period_6346 = NOVALUE;
    int _ch_6347 = NOVALUE;
    int _dir_name_6348 = NOVALUE;
    int _file_name_6349 = NOVALUE;
    int _file_ext_6350 = NOVALUE;
    int _file_full_6351 = NOVALUE;
    int _drive_id_6352 = NOVALUE;
    int _from_slash_6392 = NOVALUE;
    int _3352 = NOVALUE;
    int _3345 = NOVALUE;
    int _3344 = NOVALUE;
    int _3341 = NOVALUE;
    int _3340 = NOVALUE;
    int _3338 = NOVALUE;
    int _3337 = NOVALUE;
    int _3334 = NOVALUE;
    int _3333 = NOVALUE;
    int _3331 = NOVALUE;
    int _3327 = NOVALUE;
    int _3325 = NOVALUE;
    int _3324 = NOVALUE;
    int _3323 = NOVALUE;
    int _3322 = NOVALUE;
    int _3320 = NOVALUE;
    int _0, _1, _2;
    

    /** 	dir_name  = ""*/
    RefDS(_5);
    DeRef(_dir_name_6348);
    _dir_name_6348 = _5;

    /** 	file_name = ""*/
    RefDS(_5);
    DeRef(_file_name_6349);
    _file_name_6349 = _5;

    /** 	file_ext  = ""*/
    RefDS(_5);
    DeRef(_file_ext_6350);
    _file_ext_6350 = _5;

    /** 	file_full = ""*/
    RefDS(_5);
    DeRef(_file_full_6351);
    _file_full_6351 = _5;

    /** 	drive_id  = ""*/
    RefDS(_5);
    DeRef(_drive_id_6352);
    _drive_id_6352 = _5;

    /** 	slash = 0*/
    _slash_6345 = 0;

    /** 	period = 0*/
    _period_6346 = 0;

    /** 	for i = length(path) to 1 by -1 do*/
    if (IS_SEQUENCE(_path_6343)){
            _3320 = SEQ_PTR(_path_6343)->length;
    }
    else {
        _3320 = 1;
    }
    {
        int _i_6354;
        _i_6354 = _3320;
L1: 
        if (_i_6354 < 1){
            goto L2; // [55] 122
        }

        /** 		ch = path[i]*/
        _2 = (int)SEQ_PTR(_path_6343);
        _ch_6347 = (int)*(((s1_ptr)_2)->base + _i_6354);
        if (!IS_ATOM_INT(_ch_6347))
        _ch_6347 = (long)DBL_PTR(_ch_6347)->dbl;

        /** 		if period = 0 and ch = '.' then*/
        _3322 = (_period_6346 == 0);
        if (_3322 == 0) {
            goto L3; // [74] 94
        }
        _3324 = (_ch_6347 == 46);
        if (_3324 == 0)
        {
            DeRef(_3324);
            _3324 = NOVALUE;
            goto L3; // [83] 94
        }
        else{
            DeRef(_3324);
            _3324 = NOVALUE;
        }

        /** 			period = i*/
        _period_6346 = _i_6354;
        goto L4; // [91] 115
L3: 

        /** 		elsif eu:find(ch, SLASHES) then*/
        _3325 = find_from(_ch_6347, _17SLASHES_5976, 1);
        if (_3325 == 0)
        {
            _3325 = NOVALUE;
            goto L5; // [101] 114
        }
        else{
            _3325 = NOVALUE;
        }

        /** 			slash = i*/
        _slash_6345 = _i_6354;

        /** 			exit*/
        goto L2; // [111] 122
L5: 
L4: 

        /** 	end for*/
        _i_6354 = _i_6354 + -1;
        goto L1; // [117] 62
L2: 
        ;
    }

    /** 	if slash > 0 then*/
    if (_slash_6345 <= 0)
    goto L6; // [124] 181

    /** 		dir_name = path[1..slash-1]*/
    _3327 = _slash_6345 - 1;
    rhs_slice_target = (object_ptr)&_dir_name_6348;
    RHS_Slice(_path_6343, 1, _3327);

    /** 		ifdef not UNIX then*/

    /** 			ch = eu:find(':', dir_name)*/
    _ch_6347 = find_from(58, _dir_name_6348, 1);

    /** 			if ch != 0 then*/
    if (_ch_6347 == 0)
    goto L7; // [150] 180

    /** 				drive_id = dir_name[1..ch-1]*/
    _3331 = _ch_6347 - 1;
    rhs_slice_target = (object_ptr)&_drive_id_6352;
    RHS_Slice(_dir_name_6348, 1, _3331);

    /** 				dir_name = dir_name[ch+1..$]*/
    _3333 = _ch_6347 + 1;
    if (IS_SEQUENCE(_dir_name_6348)){
            _3334 = SEQ_PTR(_dir_name_6348)->length;
    }
    else {
        _3334 = 1;
    }
    rhs_slice_target = (object_ptr)&_dir_name_6348;
    RHS_Slice(_dir_name_6348, _3333, _3334);
L7: 
L6: 

    /** 	if period > 0 then*/
    if (_period_6346 <= 0)
    goto L8; // [183] 227

    /** 		file_name = path[slash+1..period-1]*/
    _3337 = _slash_6345 + 1;
    if (_3337 > MAXINT){
        _3337 = NewDouble((double)_3337);
    }
    _3338 = _period_6346 - 1;
    rhs_slice_target = (object_ptr)&_file_name_6349;
    RHS_Slice(_path_6343, _3337, _3338);

    /** 		file_ext = path[period+1..$]*/
    _3340 = _period_6346 + 1;
    if (_3340 > MAXINT){
        _3340 = NewDouble((double)_3340);
    }
    if (IS_SEQUENCE(_path_6343)){
            _3341 = SEQ_PTR(_path_6343)->length;
    }
    else {
        _3341 = 1;
    }
    rhs_slice_target = (object_ptr)&_file_ext_6350;
    RHS_Slice(_path_6343, _3340, _3341);

    /** 		file_full = file_name & '.' & file_ext*/
    {
        int concat_list[3];

        concat_list[0] = _file_ext_6350;
        concat_list[1] = 46;
        concat_list[2] = _file_name_6349;
        Concat_N((object_ptr)&_file_full_6351, concat_list, 3);
    }
    goto L9; // [224] 249
L8: 

    /** 		file_name = path[slash+1..$]*/
    _3344 = _slash_6345 + 1;
    if (_3344 > MAXINT){
        _3344 = NewDouble((double)_3344);
    }
    if (IS_SEQUENCE(_path_6343)){
            _3345 = SEQ_PTR(_path_6343)->length;
    }
    else {
        _3345 = 1;
    }
    rhs_slice_target = (object_ptr)&_file_name_6349;
    RHS_Slice(_path_6343, _3344, _3345);

    /** 		file_full = file_name*/
    RefDS(_file_name_6349);
    DeRef(_file_full_6351);
    _file_full_6351 = _file_name_6349;
L9: 

    /** 	if std_slash != 0 then*/
    if (_std_slash_6344 == 0)
    goto LA; // [251] 317

    /** 		if std_slash < 0 then*/
    if (_std_slash_6344 >= 0)
    goto LB; // [257] 293

    /** 			std_slash = SLASH*/
    _std_slash_6344 = 92;

    /** 			ifdef UNIX then*/

    /** 			sequence from_slash = "/"*/
    RefDS(_3127);
    DeRefi(_from_slash_6392);
    _from_slash_6392 = _3127;

    /** 			dir_name = search:match_replace(from_slash, dir_name, std_slash)*/
    RefDS(_from_slash_6392);
    RefDS(_dir_name_6348);
    _0 = _dir_name_6348;
    _dir_name_6348 = _16match_replace(_from_slash_6392, _dir_name_6348, 92, 0);
    DeRefDS(_0);
    DeRefDSi(_from_slash_6392);
    _from_slash_6392 = NOVALUE;
    goto LC; // [290] 316
LB: 

    /** 			dir_name = search:match_replace("\\", dir_name, std_slash)*/
    RefDS(_945);
    RefDS(_dir_name_6348);
    _0 = _dir_name_6348;
    _dir_name_6348 = _16match_replace(_945, _dir_name_6348, _std_slash_6344, 0);
    DeRefDS(_0);

    /** 			dir_name = search:match_replace("/", dir_name, std_slash)*/
    RefDS(_3127);
    RefDS(_dir_name_6348);
    _0 = _dir_name_6348;
    _dir_name_6348 = _16match_replace(_3127, _dir_name_6348, _std_slash_6344, 0);
    DeRefDS(_0);
LC: 
LA: 

    /** 	return {dir_name, file_full, file_name, file_ext, drive_id}*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_dir_name_6348);
    *((int *)(_2+4)) = _dir_name_6348;
    RefDS(_file_full_6351);
    *((int *)(_2+8)) = _file_full_6351;
    RefDS(_file_name_6349);
    *((int *)(_2+12)) = _file_name_6349;
    RefDS(_file_ext_6350);
    *((int *)(_2+16)) = _file_ext_6350;
    RefDS(_drive_id_6352);
    *((int *)(_2+20)) = _drive_id_6352;
    _3352 = MAKE_SEQ(_1);
    DeRefDS(_path_6343);
    DeRefDS(_dir_name_6348);
    DeRefDS(_file_name_6349);
    DeRefDS(_file_ext_6350);
    DeRefDS(_file_full_6351);
    DeRefDS(_drive_id_6352);
    DeRef(_3322);
    _3322 = NOVALUE;
    DeRef(_3327);
    _3327 = NOVALUE;
    DeRef(_3331);
    _3331 = NOVALUE;
    DeRef(_3333);
    _3333 = NOVALUE;
    DeRef(_3337);
    _3337 = NOVALUE;
    DeRef(_3338);
    _3338 = NOVALUE;
    DeRef(_3340);
    _3340 = NOVALUE;
    DeRef(_3344);
    _3344 = NOVALUE;
    return _3352;
    ;
}


int _17dirname(int _path_6400, int _pcd_6401)
{
    int _data_6402 = NOVALUE;
    int _3357 = NOVALUE;
    int _3355 = NOVALUE;
    int _3354 = NOVALUE;
    int _0, _1, _2;
    

    /** 	data = pathinfo(path)*/
    RefDS(_path_6400);
    _0 = _data_6402;
    _data_6402 = _17pathinfo(_path_6400, 0);
    DeRef(_0);

    /** 	if pcd then*/
    if (_pcd_6401 == 0)
    {
        goto L1; // [16] 40
    }
    else{
    }

    /** 		if length(data[1]) = 0 then*/
    _2 = (int)SEQ_PTR(_data_6402);
    _3354 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_3354)){
            _3355 = SEQ_PTR(_3354)->length;
    }
    else {
        _3355 = 1;
    }
    _3354 = NOVALUE;
    if (_3355 != 0)
    goto L2; // [28] 39

    /** 			return "."*/
    RefDS(_3143);
    DeRefDS(_path_6400);
    DeRefDS(_data_6402);
    _3354 = NOVALUE;
    return _3143;
L2: 
L1: 

    /** 	return data[1]*/
    _2 = (int)SEQ_PTR(_data_6402);
    _3357 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_3357);
    DeRefDS(_path_6400);
    DeRefDS(_data_6402);
    _3354 = NOVALUE;
    return _3357;
    ;
}


int _17filebase(int _path_6429)
{
    int _data_6430 = NOVALUE;
    int _3366 = NOVALUE;
    int _0, _1, _2;
    

    /** 	data = pathinfo(path)*/
    RefDS(_path_6429);
    _0 = _data_6430;
    _data_6430 = _17pathinfo(_path_6429, 0);
    DeRef(_0);

    /** 	return data[3]*/
    _2 = (int)SEQ_PTR(_data_6430);
    _3366 = (int)*(((s1_ptr)_2)->base + 3);
    Ref(_3366);
    DeRefDS(_path_6429);
    DeRefDS(_data_6430);
    return _3366;
    ;
}


int _17fileext(int _path_6435)
{
    int _data_6436 = NOVALUE;
    int _3368 = NOVALUE;
    int _0, _1, _2;
    

    /** 	data = pathinfo(path)*/
    RefDS(_path_6435);
    _0 = _data_6436;
    _data_6436 = _17pathinfo(_path_6435, 0);
    DeRef(_0);

    /** 	return data[4]*/
    _2 = (int)SEQ_PTR(_data_6436);
    _3368 = (int)*(((s1_ptr)_2)->base + 4);
    Ref(_3368);
    DeRefDS(_path_6435);
    DeRefDS(_data_6436);
    return _3368;
    ;
}


int _17defaultext(int _path_6447, int _defext_6448)
{
    int _3383 = NOVALUE;
    int _3380 = NOVALUE;
    int _3378 = NOVALUE;
    int _3377 = NOVALUE;
    int _3376 = NOVALUE;
    int _3374 = NOVALUE;
    int _3373 = NOVALUE;
    int _3371 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if length(defext) = 0 then*/
    _3371 = 3;

    /** 	for i = length(path) to 1 by -1 do*/
    if (IS_SEQUENCE(_path_6447)){
            _3373 = SEQ_PTR(_path_6447)->length;
    }
    else {
        _3373 = 1;
    }
    {
        int _i_6453;
        _i_6453 = _3373;
L1: 
        if (_i_6453 < 1){
            goto L2; // [26] 95
        }

        /** 		if path[i] = '.' then*/
        _2 = (int)SEQ_PTR(_path_6447);
        _3374 = (int)*(((s1_ptr)_2)->base + _i_6453);
        if (binary_op_a(NOTEQ, _3374, 46)){
            _3374 = NOVALUE;
            goto L3; // [39] 50
        }
        _3374 = NOVALUE;

        /** 			return path*/
        DeRefDSi(_defext_6448);
        return _path_6447;
L3: 

        /** 		if find(path[i], SLASHES) then*/
        _2 = (int)SEQ_PTR(_path_6447);
        _3376 = (int)*(((s1_ptr)_2)->base + _i_6453);
        _3377 = find_from(_3376, _17SLASHES_5976, 1);
        _3376 = NOVALUE;
        if (_3377 == 0)
        {
            _3377 = NOVALUE;
            goto L4; // [61] 88
        }
        else{
            _3377 = NOVALUE;
        }

        /** 			if i = length(path) then*/
        if (IS_SEQUENCE(_path_6447)){
                _3378 = SEQ_PTR(_path_6447)->length;
        }
        else {
            _3378 = 1;
        }
        if (_i_6453 != _3378)
        goto L2; // [69] 95

        /** 				return path*/
        DeRefDSi(_defext_6448);
        return _path_6447;
        goto L5; // [79] 87

        /** 				exit*/
        goto L2; // [84] 95
L5: 
L4: 

        /** 	end for*/
        _i_6453 = _i_6453 + -1;
        goto L1; // [90] 33
L2: 
        ;
    }

    /** 	if defext[1] != '.' then*/
    _2 = (int)SEQ_PTR(_defext_6448);
    _3380 = (int)*(((s1_ptr)_2)->base + 1);
    if (_3380 == 46)
    goto L6; // [101] 112

    /** 		path &= '.'*/
    Append(&_path_6447, _path_6447, 46);
L6: 

    /** 	return path & defext*/
    Concat((object_ptr)&_3383, _path_6447, _defext_6448);
    DeRefDS(_path_6447);
    DeRefDSi(_defext_6448);
    _3380 = NOVALUE;
    return _3383;
    ;
}


int _17absolute_path(int _filename_6472)
{
    int _3395 = NOVALUE;
    int _3394 = NOVALUE;
    int _3392 = NOVALUE;
    int _3390 = NOVALUE;
    int _3388 = NOVALUE;
    int _3387 = NOVALUE;
    int _3386 = NOVALUE;
    int _3384 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if length(filename) = 0 then*/
    if (IS_SEQUENCE(_filename_6472)){
            _3384 = SEQ_PTR(_filename_6472)->length;
    }
    else {
        _3384 = 1;
    }
    if (_3384 != 0)
    goto L1; // [8] 19

    /** 		return 0*/
    DeRefDS(_filename_6472);
    return 0;
L1: 

    /** 	if eu:find(filename[1], SLASHES) then*/
    _2 = (int)SEQ_PTR(_filename_6472);
    _3386 = (int)*(((s1_ptr)_2)->base + 1);
    _3387 = find_from(_3386, _17SLASHES_5976, 1);
    _3386 = NOVALUE;
    if (_3387 == 0)
    {
        _3387 = NOVALUE;
        goto L2; // [30] 40
    }
    else{
        _3387 = NOVALUE;
    }

    /** 		return 1*/
    DeRefDS(_filename_6472);
    return 1;
L2: 

    /** 	ifdef WINDOWS then*/

    /** 		if length(filename) = 1 then*/
    if (IS_SEQUENCE(_filename_6472)){
            _3388 = SEQ_PTR(_filename_6472)->length;
    }
    else {
        _3388 = 1;
    }
    if (_3388 != 1)
    goto L3; // [47] 58

    /** 			return 0*/
    DeRefDS(_filename_6472);
    return 0;
L3: 

    /** 		if filename[2] != ':' then*/
    _2 = (int)SEQ_PTR(_filename_6472);
    _3390 = (int)*(((s1_ptr)_2)->base + 2);
    if (binary_op_a(EQUALS, _3390, 58)){
        _3390 = NOVALUE;
        goto L4; // [64] 75
    }
    _3390 = NOVALUE;

    /** 			return 0*/
    DeRefDS(_filename_6472);
    return 0;
L4: 

    /** 		if length(filename) < 3 then*/
    if (IS_SEQUENCE(_filename_6472)){
            _3392 = SEQ_PTR(_filename_6472)->length;
    }
    else {
        _3392 = 1;
    }
    if (_3392 >= 3)
    goto L5; // [80] 91

    /** 			return 0*/
    DeRefDS(_filename_6472);
    return 0;
L5: 

    /** 		if eu:find(filename[3], SLASHES) then*/
    _2 = (int)SEQ_PTR(_filename_6472);
    _3394 = (int)*(((s1_ptr)_2)->base + 3);
    _3395 = find_from(_3394, _17SLASHES_5976, 1);
    _3394 = NOVALUE;
    if (_3395 == 0)
    {
        _3395 = NOVALUE;
        goto L6; // [102] 112
    }
    else{
        _3395 = NOVALUE;
    }

    /** 			return 1*/
    DeRefDS(_filename_6472);
    return 1;
L6: 

    /** 	return 0*/
    DeRefDS(_filename_6472);
    return 0;
    ;
}


int _17canonical_path(int _path_in_6511, int _directory_given_6512, int _case_flags_6513)
{
    int _lPath_6514 = NOVALUE;
    int _lPosA_6515 = NOVALUE;
    int _lPosB_6516 = NOVALUE;
    int _lLevel_6517 = NOVALUE;
    int _lHome_6518 = NOVALUE;
    int _lDrive_6519 = NOVALUE;
    int _current_dir_inlined_current_dir_at_300_6579 = NOVALUE;
    int _driveid_inlined_driveid_at_307_6582 = NOVALUE;
    int _data_inlined_driveid_at_307_6581 = NOVALUE;
    int _wildcard_suffix_6584 = NOVALUE;
    int _first_wildcard_at_6585 = NOVALUE;
    int _last_slash_6588 = NOVALUE;
    int _sl_6660 = NOVALUE;
    int _short_name_6663 = NOVALUE;
    int _correct_name_6666 = NOVALUE;
    int _lower_name_6669 = NOVALUE;
    int _part_6685 = NOVALUE;
    int _list_6689 = NOVALUE;
    int _dir_inlined_dir_at_867_6693 = NOVALUE;
    int _name_inlined_dir_at_864_6692 = NOVALUE;
    int _supplied_name_6694 = NOVALUE;
    int _read_name_6713 = NOVALUE;
    int _read_name_6738 = NOVALUE;
    int _3616 = NOVALUE;
    int _3613 = NOVALUE;
    int _3609 = NOVALUE;
    int _3608 = NOVALUE;
    int _3606 = NOVALUE;
    int _3605 = NOVALUE;
    int _3604 = NOVALUE;
    int _3603 = NOVALUE;
    int _3602 = NOVALUE;
    int _3600 = NOVALUE;
    int _3599 = NOVALUE;
    int _3598 = NOVALUE;
    int _3597 = NOVALUE;
    int _3596 = NOVALUE;
    int _3595 = NOVALUE;
    int _3594 = NOVALUE;
    int _3593 = NOVALUE;
    int _3591 = NOVALUE;
    int _3590 = NOVALUE;
    int _3589 = NOVALUE;
    int _3588 = NOVALUE;
    int _3587 = NOVALUE;
    int _3586 = NOVALUE;
    int _3585 = NOVALUE;
    int _3584 = NOVALUE;
    int _3583 = NOVALUE;
    int _3581 = NOVALUE;
    int _3580 = NOVALUE;
    int _3579 = NOVALUE;
    int _3578 = NOVALUE;
    int _3577 = NOVALUE;
    int _3576 = NOVALUE;
    int _3575 = NOVALUE;
    int _3574 = NOVALUE;
    int _3573 = NOVALUE;
    int _3572 = NOVALUE;
    int _3571 = NOVALUE;
    int _3570 = NOVALUE;
    int _3569 = NOVALUE;
    int _3568 = NOVALUE;
    int _3567 = NOVALUE;
    int _3565 = NOVALUE;
    int _3564 = NOVALUE;
    int _3563 = NOVALUE;
    int _3562 = NOVALUE;
    int _3561 = NOVALUE;
    int _3559 = NOVALUE;
    int _3558 = NOVALUE;
    int _3557 = NOVALUE;
    int _3556 = NOVALUE;
    int _3555 = NOVALUE;
    int _3554 = NOVALUE;
    int _3553 = NOVALUE;
    int _3552 = NOVALUE;
    int _3551 = NOVALUE;
    int _3550 = NOVALUE;
    int _3549 = NOVALUE;
    int _3548 = NOVALUE;
    int _3547 = NOVALUE;
    int _3545 = NOVALUE;
    int _3544 = NOVALUE;
    int _3542 = NOVALUE;
    int _3541 = NOVALUE;
    int _3540 = NOVALUE;
    int _3539 = NOVALUE;
    int _3538 = NOVALUE;
    int _3536 = NOVALUE;
    int _3535 = NOVALUE;
    int _3534 = NOVALUE;
    int _3533 = NOVALUE;
    int _3532 = NOVALUE;
    int _3531 = NOVALUE;
    int _3529 = NOVALUE;
    int _3528 = NOVALUE;
    int _3526 = NOVALUE;
    int _3525 = NOVALUE;
    int _3523 = NOVALUE;
    int _3522 = NOVALUE;
    int _3521 = NOVALUE;
    int _3519 = NOVALUE;
    int _3518 = NOVALUE;
    int _3516 = NOVALUE;
    int _3514 = NOVALUE;
    int _3512 = NOVALUE;
    int _3505 = NOVALUE;
    int _3502 = NOVALUE;
    int _3501 = NOVALUE;
    int _3500 = NOVALUE;
    int _3499 = NOVALUE;
    int _3493 = NOVALUE;
    int _3489 = NOVALUE;
    int _3488 = NOVALUE;
    int _3487 = NOVALUE;
    int _3486 = NOVALUE;
    int _3485 = NOVALUE;
    int _3483 = NOVALUE;
    int _3480 = NOVALUE;
    int _3479 = NOVALUE;
    int _3478 = NOVALUE;
    int _3477 = NOVALUE;
    int _3476 = NOVALUE;
    int _3475 = NOVALUE;
    int _3473 = NOVALUE;
    int _3472 = NOVALUE;
    int _3470 = NOVALUE;
    int _3468 = NOVALUE;
    int _3467 = NOVALUE;
    int _3466 = NOVALUE;
    int _3464 = NOVALUE;
    int _3463 = NOVALUE;
    int _3462 = NOVALUE;
    int _3461 = NOVALUE;
    int _3459 = NOVALUE;
    int _3457 = NOVALUE;
    int _3452 = NOVALUE;
    int _3450 = NOVALUE;
    int _3449 = NOVALUE;
    int _3448 = NOVALUE;
    int _3447 = NOVALUE;
    int _3446 = NOVALUE;
    int _3444 = NOVALUE;
    int _3443 = NOVALUE;
    int _3441 = NOVALUE;
    int _3440 = NOVALUE;
    int _3439 = NOVALUE;
    int _3438 = NOVALUE;
    int _3437 = NOVALUE;
    int _3436 = NOVALUE;
    int _3435 = NOVALUE;
    int _3432 = NOVALUE;
    int _3431 = NOVALUE;
    int _3429 = NOVALUE;
    int _3427 = NOVALUE;
    int _3425 = NOVALUE;
    int _3422 = NOVALUE;
    int _3421 = NOVALUE;
    int _3420 = NOVALUE;
    int _3419 = NOVALUE;
    int _3418 = NOVALUE;
    int _3416 = NOVALUE;
    int _3415 = NOVALUE;
    int _3414 = NOVALUE;
    int _3413 = NOVALUE;
    int _3412 = NOVALUE;
    int _3411 = NOVALUE;
    int _3410 = NOVALUE;
    int _3409 = NOVALUE;
    int _3408 = NOVALUE;
    int _3407 = NOVALUE;
    int _3406 = NOVALUE;
    int _0, _1, _2;
    

    /**     sequence lPath = ""*/
    RefDS(_5);
    DeRef(_lPath_6514);
    _lPath_6514 = _5;

    /**     integer lPosA = -1*/
    _lPosA_6515 = -1;

    /**     integer lPosB = -1*/
    _lPosB_6516 = -1;

    /**     sequence lLevel = ""*/
    RefDS(_5);
    DeRefi(_lLevel_6517);
    _lLevel_6517 = _5;

    /**     path_in = path_in*/
    RefDS(_path_in_6511);
    DeRefDS(_path_in_6511);
    _path_in_6511 = _path_in_6511;

    /** 	ifdef UNIX then*/

    /** 	    sequence lDrive*/

    /** 	    lPath = match_replace("/", path_in, SLASH)*/
    RefDS(_3127);
    RefDS(_path_in_6511);
    _0 = _lPath_6514;
    _lPath_6514 = _16match_replace(_3127, _path_in_6511, 92, 0);
    DeRefDS(_0);

    /**     if (length(lPath) > 2 and lPath[1] = '"' and lPath[$] = '"') then*/
    if (IS_SEQUENCE(_lPath_6514)){
            _3406 = SEQ_PTR(_lPath_6514)->length;
    }
    else {
        _3406 = 1;
    }
    _3407 = (_3406 > 2);
    _3406 = NOVALUE;
    if (_3407 == 0) {
        _3408 = 0;
        goto L1; // [62] 78
    }
    _2 = (int)SEQ_PTR(_lPath_6514);
    _3409 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_3409)) {
        _3410 = (_3409 == 34);
    }
    else {
        _3410 = binary_op(EQUALS, _3409, 34);
    }
    _3409 = NOVALUE;
    if (IS_ATOM_INT(_3410))
    _3408 = (_3410 != 0);
    else
    _3408 = DBL_PTR(_3410)->dbl != 0.0;
L1: 
    if (_3408 == 0) {
        DeRef(_3411);
        _3411 = 0;
        goto L2; // [78] 97
    }
    if (IS_SEQUENCE(_lPath_6514)){
            _3412 = SEQ_PTR(_lPath_6514)->length;
    }
    else {
        _3412 = 1;
    }
    _2 = (int)SEQ_PTR(_lPath_6514);
    _3413 = (int)*(((s1_ptr)_2)->base + _3412);
    if (IS_ATOM_INT(_3413)) {
        _3414 = (_3413 == 34);
    }
    else {
        _3414 = binary_op(EQUALS, _3413, 34);
    }
    _3413 = NOVALUE;
    if (IS_ATOM_INT(_3414))
    _3411 = (_3414 != 0);
    else
    _3411 = DBL_PTR(_3414)->dbl != 0.0;
L2: 
    if (_3411 == 0)
    {
        _3411 = NOVALUE;
        goto L3; // [97] 115
    }
    else{
        _3411 = NOVALUE;
    }

    /**         lPath = lPath[2..$-1]*/
    if (IS_SEQUENCE(_lPath_6514)){
            _3415 = SEQ_PTR(_lPath_6514)->length;
    }
    else {
        _3415 = 1;
    }
    _3416 = _3415 - 1;
    _3415 = NOVALUE;
    rhs_slice_target = (object_ptr)&_lPath_6514;
    RHS_Slice(_lPath_6514, 2, _3416);
L3: 

    /**     if (length(lPath) > 0 and lPath[1] = '~') then*/
    if (IS_SEQUENCE(_lPath_6514)){
            _3418 = SEQ_PTR(_lPath_6514)->length;
    }
    else {
        _3418 = 1;
    }
    _3419 = (_3418 > 0);
    _3418 = NOVALUE;
    if (_3419 == 0) {
        DeRef(_3420);
        _3420 = 0;
        goto L4; // [124] 140
    }
    _2 = (int)SEQ_PTR(_lPath_6514);
    _3421 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_3421)) {
        _3422 = (_3421 == 126);
    }
    else {
        _3422 = binary_op(EQUALS, _3421, 126);
    }
    _3421 = NOVALUE;
    if (IS_ATOM_INT(_3422))
    _3420 = (_3422 != 0);
    else
    _3420 = DBL_PTR(_3422)->dbl != 0.0;
L4: 
    if (_3420 == 0)
    {
        _3420 = NOVALUE;
        goto L5; // [140] 249
    }
    else{
        _3420 = NOVALUE;
    }

    /** 		lHome = getenv("HOME")*/
    DeRef(_lHome_6518);
    _lHome_6518 = EGetEnv(_3423);

    /** 		ifdef WINDOWS then*/

    /** 			if atom(lHome) then*/
    _3425 = IS_ATOM(_lHome_6518);
    if (_3425 == 0)
    {
        _3425 = NOVALUE;
        goto L6; // [155] 171
    }
    else{
        _3425 = NOVALUE;
    }

    /** 				lHome = getenv("HOMEDRIVE") & getenv("HOMEPATH")*/
    _3427 = EGetEnv(_3426);
    _3429 = EGetEnv(_3428);
    if (IS_SEQUENCE(_3427) && IS_ATOM(_3429)) {
        Ref(_3429);
        Append(&_lHome_6518, _3427, _3429);
    }
    else if (IS_ATOM(_3427) && IS_SEQUENCE(_3429)) {
        Ref(_3427);
        Prepend(&_lHome_6518, _3429, _3427);
    }
    else {
        Concat((object_ptr)&_lHome_6518, _3427, _3429);
        DeRef(_3427);
        _3427 = NOVALUE;
    }
    DeRef(_3427);
    _3427 = NOVALUE;
    DeRef(_3429);
    _3429 = NOVALUE;
L6: 

    /** 		if lHome[$] != SLASH then*/
    if (IS_SEQUENCE(_lHome_6518)){
            _3431 = SEQ_PTR(_lHome_6518)->length;
    }
    else {
        _3431 = 1;
    }
    _2 = (int)SEQ_PTR(_lHome_6518);
    _3432 = (int)*(((s1_ptr)_2)->base + _3431);
    if (binary_op_a(EQUALS, _3432, 92)){
        _3432 = NOVALUE;
        goto L7; // [180] 191
    }
    _3432 = NOVALUE;

    /** 			lHome &= SLASH*/
    if (IS_SEQUENCE(_lHome_6518) && IS_ATOM(92)) {
        Append(&_lHome_6518, _lHome_6518, 92);
    }
    else if (IS_ATOM(_lHome_6518) && IS_SEQUENCE(92)) {
    }
    else {
        Concat((object_ptr)&_lHome_6518, _lHome_6518, 92);
    }
L7: 

    /** 		if length(lPath) > 1 and lPath[2] = SLASH then*/
    if (IS_SEQUENCE(_lPath_6514)){
            _3435 = SEQ_PTR(_lPath_6514)->length;
    }
    else {
        _3435 = 1;
    }
    _3436 = (_3435 > 1);
    _3435 = NOVALUE;
    if (_3436 == 0) {
        goto L8; // [200] 233
    }
    _2 = (int)SEQ_PTR(_lPath_6514);
    _3438 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_3438)) {
        _3439 = (_3438 == 92);
    }
    else {
        _3439 = binary_op(EQUALS, _3438, 92);
    }
    _3438 = NOVALUE;
    if (_3439 == 0) {
        DeRef(_3439);
        _3439 = NOVALUE;
        goto L8; // [213] 233
    }
    else {
        if (!IS_ATOM_INT(_3439) && DBL_PTR(_3439)->dbl == 0.0){
            DeRef(_3439);
            _3439 = NOVALUE;
            goto L8; // [213] 233
        }
        DeRef(_3439);
        _3439 = NOVALUE;
    }
    DeRef(_3439);
    _3439 = NOVALUE;

    /** 			lPath = lHome & lPath[3 .. $]*/
    if (IS_SEQUENCE(_lPath_6514)){
            _3440 = SEQ_PTR(_lPath_6514)->length;
    }
    else {
        _3440 = 1;
    }
    rhs_slice_target = (object_ptr)&_3441;
    RHS_Slice(_lPath_6514, 3, _3440);
    if (IS_SEQUENCE(_lHome_6518) && IS_ATOM(_3441)) {
    }
    else if (IS_ATOM(_lHome_6518) && IS_SEQUENCE(_3441)) {
        Ref(_lHome_6518);
        Prepend(&_lPath_6514, _3441, _lHome_6518);
    }
    else {
        Concat((object_ptr)&_lPath_6514, _lHome_6518, _3441);
    }
    DeRefDS(_3441);
    _3441 = NOVALUE;
    goto L9; // [230] 248
L8: 

    /** 			lPath = lHome & lPath[2 .. $]*/
    if (IS_SEQUENCE(_lPath_6514)){
            _3443 = SEQ_PTR(_lPath_6514)->length;
    }
    else {
        _3443 = 1;
    }
    rhs_slice_target = (object_ptr)&_3444;
    RHS_Slice(_lPath_6514, 2, _3443);
    if (IS_SEQUENCE(_lHome_6518) && IS_ATOM(_3444)) {
    }
    else if (IS_ATOM(_lHome_6518) && IS_SEQUENCE(_3444)) {
        Ref(_lHome_6518);
        Prepend(&_lPath_6514, _3444, _lHome_6518);
    }
    else {
        Concat((object_ptr)&_lPath_6514, _lHome_6518, _3444);
    }
    DeRefDS(_3444);
    _3444 = NOVALUE;
L9: 
L5: 

    /** 	ifdef WINDOWS then*/

    /** 	    if ( (length(lPath) > 1) and (lPath[2] = ':' ) ) then*/
    if (IS_SEQUENCE(_lPath_6514)){
            _3446 = SEQ_PTR(_lPath_6514)->length;
    }
    else {
        _3446 = 1;
    }
    _3447 = (_3446 > 1);
    _3446 = NOVALUE;
    if (_3447 == 0) {
        DeRef(_3448);
        _3448 = 0;
        goto LA; // [260] 276
    }
    _2 = (int)SEQ_PTR(_lPath_6514);
    _3449 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_3449)) {
        _3450 = (_3449 == 58);
    }
    else {
        _3450 = binary_op(EQUALS, _3449, 58);
    }
    _3449 = NOVALUE;
    if (IS_ATOM_INT(_3450))
    _3448 = (_3450 != 0);
    else
    _3448 = DBL_PTR(_3450)->dbl != 0.0;
LA: 
    if (_3448 == 0)
    {
        _3448 = NOVALUE;
        goto LB; // [276] 299
    }
    else{
        _3448 = NOVALUE;
    }

    /** 			lDrive = lPath[1..2]*/
    rhs_slice_target = (object_ptr)&_lDrive_6519;
    RHS_Slice(_lPath_6514, 1, 2);

    /** 			lPath = lPath[3..$]*/
    if (IS_SEQUENCE(_lPath_6514)){
            _3452 = SEQ_PTR(_lPath_6514)->length;
    }
    else {
        _3452 = 1;
    }
    rhs_slice_target = (object_ptr)&_lPath_6514;
    RHS_Slice(_lPath_6514, 3, _3452);
    goto LC; // [296] 333
LB: 

    /** 			lDrive = driveid(current_dir()) & ':'*/

    /** 	return machine_func(M_CURRENT_DIR, 0)*/
    DeRefi(_current_dir_inlined_current_dir_at_300_6579);
    _current_dir_inlined_current_dir_at_300_6579 = machine(23, 0);

    /** 	data = pathinfo(path)*/
    RefDS(_current_dir_inlined_current_dir_at_300_6579);
    _0 = _data_inlined_driveid_at_307_6581;
    _data_inlined_driveid_at_307_6581 = _17pathinfo(_current_dir_inlined_current_dir_at_300_6579, 0);
    DeRef(_0);

    /** 	return data[5]*/
    DeRef(_driveid_inlined_driveid_at_307_6582);
    _2 = (int)SEQ_PTR(_data_inlined_driveid_at_307_6581);
    _driveid_inlined_driveid_at_307_6582 = (int)*(((s1_ptr)_2)->base + 5);
    Ref(_driveid_inlined_driveid_at_307_6582);
    DeRef(_data_inlined_driveid_at_307_6581);
    _data_inlined_driveid_at_307_6581 = NOVALUE;
    if (IS_SEQUENCE(_driveid_inlined_driveid_at_307_6582) && IS_ATOM(58)) {
        Append(&_lDrive_6519, _driveid_inlined_driveid_at_307_6582, 58);
    }
    else if (IS_ATOM(_driveid_inlined_driveid_at_307_6582) && IS_SEQUENCE(58)) {
    }
    else {
        Concat((object_ptr)&_lDrive_6519, _driveid_inlined_driveid_at_307_6582, 58);
    }
LC: 

    /** 	sequence wildcard_suffix*/

    /** 	integer first_wildcard_at = find_first_wildcard( lPath )*/
    RefDS(_lPath_6514);
    _first_wildcard_at_6585 = _17find_first_wildcard(_lPath_6514, 1);
    if (!IS_ATOM_INT(_first_wildcard_at_6585)) {
        _1 = (long)(DBL_PTR(_first_wildcard_at_6585)->dbl);
        DeRefDS(_first_wildcard_at_6585);
        _first_wildcard_at_6585 = _1;
    }

    /** 	if first_wildcard_at then*/
    if (_first_wildcard_at_6585 == 0)
    {
        goto LD; // [346] 407
    }
    else{
    }

    /** 		integer last_slash = search:rfind( SLASH, lPath, first_wildcard_at )*/
    RefDS(_lPath_6514);
    _last_slash_6588 = _16rfind(92, _lPath_6514, _first_wildcard_at_6585);
    if (!IS_ATOM_INT(_last_slash_6588)) {
        _1 = (long)(DBL_PTR(_last_slash_6588)->dbl);
        DeRefDS(_last_slash_6588);
        _last_slash_6588 = _1;
    }

    /** 		if last_slash then*/
    if (_last_slash_6588 == 0)
    {
        goto LE; // [361] 387
    }
    else{
    }

    /** 			wildcard_suffix = lPath[last_slash..$]*/
    if (IS_SEQUENCE(_lPath_6514)){
            _3457 = SEQ_PTR(_lPath_6514)->length;
    }
    else {
        _3457 = 1;
    }
    rhs_slice_target = (object_ptr)&_wildcard_suffix_6584;
    RHS_Slice(_lPath_6514, _last_slash_6588, _3457);

    /** 			lPath = remove( lPath, last_slash, length( lPath ) )*/
    if (IS_SEQUENCE(_lPath_6514)){
            _3459 = SEQ_PTR(_lPath_6514)->length;
    }
    else {
        _3459 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_lPath_6514);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_last_slash_6588)) ? _last_slash_6588 : (long)(DBL_PTR(_last_slash_6588)->dbl);
        int stop = (IS_ATOM_INT(_3459)) ? _3459 : (long)(DBL_PTR(_3459)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_lPath_6514), start, &_lPath_6514 );
            }
            else Tail(SEQ_PTR(_lPath_6514), stop+1, &_lPath_6514);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_lPath_6514), start, &_lPath_6514);
        }
        else {
            assign_slice_seq = &assign_space;
            _lPath_6514 = Remove_elements(start, stop, (SEQ_PTR(_lPath_6514)->ref == 1));
        }
    }
    _3459 = NOVALUE;
    goto LF; // [384] 402
LE: 

    /** 			wildcard_suffix = lPath*/
    RefDS(_lPath_6514);
    DeRef(_wildcard_suffix_6584);
    _wildcard_suffix_6584 = _lPath_6514;

    /** 			lPath = ""*/
    RefDS(_5);
    DeRefDS(_lPath_6514);
    _lPath_6514 = _5;
LF: 
    goto L10; // [404] 415
LD: 

    /** 		wildcard_suffix = ""*/
    RefDS(_5);
    DeRef(_wildcard_suffix_6584);
    _wildcard_suffix_6584 = _5;
L10: 

    /** 	if ((length(lPath) = 0) or not find(lPath[1], "/\\")) then*/
    if (IS_SEQUENCE(_lPath_6514)){
            _3461 = SEQ_PTR(_lPath_6514)->length;
    }
    else {
        _3461 = 1;
    }
    _3462 = (_3461 == 0);
    _3461 = NOVALUE;
    if (_3462 != 0) {
        DeRef(_3463);
        _3463 = 1;
        goto L11; // [424] 444
    }
    _2 = (int)SEQ_PTR(_lPath_6514);
    _3464 = (int)*(((s1_ptr)_2)->base + 1);
    _3466 = find_from(_3464, _3465, 1);
    _3464 = NOVALUE;
    _3467 = (_3466 == 0);
    _3466 = NOVALUE;
    _3463 = (_3467 != 0);
L11: 
    if (_3463 == 0)
    {
        _3463 = NOVALUE;
        goto L12; // [444] 545
    }
    else{
        _3463 = NOVALUE;
    }

    /** 		ifdef UNIX then*/

    /** 			if (length(lDrive) = 0) then*/
    if (IS_SEQUENCE(_lDrive_6519)){
            _3468 = SEQ_PTR(_lDrive_6519)->length;
    }
    else {
        _3468 = 1;
    }
    if (_3468 != 0)
    goto L13; // [456] 473

    /** 				lPath = curdir() & lPath*/
    _3470 = _17curdir(0);
    if (IS_SEQUENCE(_3470) && IS_ATOM(_lPath_6514)) {
    }
    else if (IS_ATOM(_3470) && IS_SEQUENCE(_lPath_6514)) {
        Ref(_3470);
        Prepend(&_lPath_6514, _lPath_6514, _3470);
    }
    else {
        Concat((object_ptr)&_lPath_6514, _3470, _lPath_6514);
        DeRef(_3470);
        _3470 = NOVALUE;
    }
    DeRef(_3470);
    _3470 = NOVALUE;
    goto L14; // [470] 488
L13: 

    /** 				lPath = curdir(lDrive[1]) & lPath*/
    _2 = (int)SEQ_PTR(_lDrive_6519);
    _3472 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_3472);
    _3473 = _17curdir(_3472);
    _3472 = NOVALUE;
    if (IS_SEQUENCE(_3473) && IS_ATOM(_lPath_6514)) {
    }
    else if (IS_ATOM(_3473) && IS_SEQUENCE(_lPath_6514)) {
        Ref(_3473);
        Prepend(&_lPath_6514, _lPath_6514, _3473);
    }
    else {
        Concat((object_ptr)&_lPath_6514, _3473, _lPath_6514);
        DeRef(_3473);
        _3473 = NOVALUE;
    }
    DeRef(_3473);
    _3473 = NOVALUE;
L14: 

    /** 			if ( (length(lPath) > 1) and (lPath[2] = ':' ) ) then*/
    if (IS_SEQUENCE(_lPath_6514)){
            _3475 = SEQ_PTR(_lPath_6514)->length;
    }
    else {
        _3475 = 1;
    }
    _3476 = (_3475 > 1);
    _3475 = NOVALUE;
    if (_3476 == 0) {
        DeRef(_3477);
        _3477 = 0;
        goto L15; // [497] 513
    }
    _2 = (int)SEQ_PTR(_lPath_6514);
    _3478 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_3478)) {
        _3479 = (_3478 == 58);
    }
    else {
        _3479 = binary_op(EQUALS, _3478, 58);
    }
    _3478 = NOVALUE;
    if (IS_ATOM_INT(_3479))
    _3477 = (_3479 != 0);
    else
    _3477 = DBL_PTR(_3479)->dbl != 0.0;
L15: 
    if (_3477 == 0)
    {
        _3477 = NOVALUE;
        goto L16; // [513] 544
    }
    else{
        _3477 = NOVALUE;
    }

    /** 				if (length(lDrive) = 0) then*/
    if (IS_SEQUENCE(_lDrive_6519)){
            _3480 = SEQ_PTR(_lDrive_6519)->length;
    }
    else {
        _3480 = 1;
    }
    if (_3480 != 0)
    goto L17; // [521] 533

    /** 					lDrive = lPath[1..2]*/
    rhs_slice_target = (object_ptr)&_lDrive_6519;
    RHS_Slice(_lPath_6514, 1, 2);
L17: 

    /** 				lPath = lPath[3..$]*/
    if (IS_SEQUENCE(_lPath_6514)){
            _3483 = SEQ_PTR(_lPath_6514)->length;
    }
    else {
        _3483 = 1;
    }
    rhs_slice_target = (object_ptr)&_lPath_6514;
    RHS_Slice(_lPath_6514, 3, _3483);
L16: 
L12: 

    /** 	if ((directory_given != 0) and (lPath[$] != SLASH) ) then*/
    _3485 = (_directory_given_6512 != 0);
    if (_3485 == 0) {
        DeRef(_3486);
        _3486 = 0;
        goto L18; // [551] 570
    }
    if (IS_SEQUENCE(_lPath_6514)){
            _3487 = SEQ_PTR(_lPath_6514)->length;
    }
    else {
        _3487 = 1;
    }
    _2 = (int)SEQ_PTR(_lPath_6514);
    _3488 = (int)*(((s1_ptr)_2)->base + _3487);
    if (IS_ATOM_INT(_3488)) {
        _3489 = (_3488 != 92);
    }
    else {
        _3489 = binary_op(NOTEQ, _3488, 92);
    }
    _3488 = NOVALUE;
    if (IS_ATOM_INT(_3489))
    _3486 = (_3489 != 0);
    else
    _3486 = DBL_PTR(_3489)->dbl != 0.0;
L18: 
    if (_3486 == 0)
    {
        _3486 = NOVALUE;
        goto L19; // [570] 580
    }
    else{
        _3486 = NOVALUE;
    }

    /** 		lPath &= SLASH*/
    Append(&_lPath_6514, _lPath_6514, 92);
L19: 

    /** 	lLevel = SLASH & '.' & SLASH*/
    {
        int concat_list[3];

        concat_list[0] = 92;
        concat_list[1] = 46;
        concat_list[2] = 92;
        Concat_N((object_ptr)&_lLevel_6517, concat_list, 3);
    }

    /** 	lPosA = 1*/
    _lPosA_6515 = 1;

    /** 	while( lPosA != 0 ) with entry do*/
    goto L1A; // [595] 616
L1B: 
    if (_lPosA_6515 == 0)
    goto L1C; // [598] 628

    /** 		lPath = eu:remove(lPath, lPosA, lPosA + 1)*/
    _3493 = _lPosA_6515 + 1;
    if (_3493 > MAXINT){
        _3493 = NewDouble((double)_3493);
    }
    {
        s1_ptr assign_space = SEQ_PTR(_lPath_6514);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_lPosA_6515)) ? _lPosA_6515 : (long)(DBL_PTR(_lPosA_6515)->dbl);
        int stop = (IS_ATOM_INT(_3493)) ? _3493 : (long)(DBL_PTR(_3493)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_lPath_6514), start, &_lPath_6514 );
            }
            else Tail(SEQ_PTR(_lPath_6514), stop+1, &_lPath_6514);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_lPath_6514), start, &_lPath_6514);
        }
        else {
            assign_slice_seq = &assign_space;
            _lPath_6514 = Remove_elements(start, stop, (SEQ_PTR(_lPath_6514)->ref == 1));
        }
    }
    DeRef(_3493);
    _3493 = NOVALUE;

    /** 	  entry*/
L1A: 

    /** 		lPosA = match(lLevel, lPath, lPosA )*/
    _lPosA_6515 = e_match_from(_lLevel_6517, _lPath_6514, _lPosA_6515);

    /** 	end while*/
    goto L1B; // [625] 598
L1C: 

    /** 	lLevel = SLASH & ".." & SLASH*/
    {
        int concat_list[3];

        concat_list[0] = 92;
        concat_list[1] = _3174;
        concat_list[2] = 92;
        Concat_N((object_ptr)&_lLevel_6517, concat_list, 3);
    }

    /** 	lPosB = 1*/
    _lPosB_6516 = 1;

    /** 	while( lPosA != 0 ) with entry do*/
    goto L1D; // [643] 721
L1E: 
    if (_lPosA_6515 == 0)
    goto L1F; // [646] 733

    /** 		lPosB = lPosA-1*/
    _lPosB_6516 = _lPosA_6515 - 1;

    /** 		while((lPosB > 0) and (lPath[lPosB] != SLASH)) do*/
L20: 
    _3499 = (_lPosB_6516 > 0);
    if (_3499 == 0) {
        DeRef(_3500);
        _3500 = 0;
        goto L21; // [665] 681
    }
    _2 = (int)SEQ_PTR(_lPath_6514);
    _3501 = (int)*(((s1_ptr)_2)->base + _lPosB_6516);
    if (IS_ATOM_INT(_3501)) {
        _3502 = (_3501 != 92);
    }
    else {
        _3502 = binary_op(NOTEQ, _3501, 92);
    }
    _3501 = NOVALUE;
    if (IS_ATOM_INT(_3502))
    _3500 = (_3502 != 0);
    else
    _3500 = DBL_PTR(_3502)->dbl != 0.0;
L21: 
    if (_3500 == 0)
    {
        _3500 = NOVALUE;
        goto L22; // [681] 695
    }
    else{
        _3500 = NOVALUE;
    }

    /** 			lPosB -= 1*/
    _lPosB_6516 = _lPosB_6516 - 1;

    /** 		end while*/
    goto L20; // [692] 661
L22: 

    /** 		if (lPosB <= 0) then*/
    if (_lPosB_6516 > 0)
    goto L23; // [697] 707

    /** 			lPosB = 1*/
    _lPosB_6516 = 1;
L23: 

    /** 		lPath = eu:remove(lPath, lPosB, lPosA + 2)*/
    _3505 = _lPosA_6515 + 2;
    if ((long)((unsigned long)_3505 + (unsigned long)HIGH_BITS) >= 0) 
    _3505 = NewDouble((double)_3505);
    {
        s1_ptr assign_space = SEQ_PTR(_lPath_6514);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_lPosB_6516)) ? _lPosB_6516 : (long)(DBL_PTR(_lPosB_6516)->dbl);
        int stop = (IS_ATOM_INT(_3505)) ? _3505 : (long)(DBL_PTR(_3505)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_lPath_6514), start, &_lPath_6514 );
            }
            else Tail(SEQ_PTR(_lPath_6514), stop+1, &_lPath_6514);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_lPath_6514), start, &_lPath_6514);
        }
        else {
            assign_slice_seq = &assign_space;
            _lPath_6514 = Remove_elements(start, stop, (SEQ_PTR(_lPath_6514)->ref == 1));
        }
    }
    DeRef(_3505);
    _3505 = NOVALUE;

    /** 	  entry*/
L1D: 

    /** 		lPosA = match(lLevel, lPath, lPosB )*/
    _lPosA_6515 = e_match_from(_lLevel_6517, _lPath_6514, _lPosB_6516);

    /** 	end while*/
    goto L1E; // [730] 646
L1F: 

    /** 	if case_flags = TO_LOWER then*/
    if (_case_flags_6513 != 1)
    goto L24; // [735] 750

    /** 		lPath = lower( lPath )*/
    RefDS(_lPath_6514);
    _0 = _lPath_6514;
    _lPath_6514 = _14lower(_lPath_6514);
    DeRefDS(_0);
    goto L25; // [747] 1355
L24: 

    /** 	elsif case_flags != AS_IS then*/
    if (_case_flags_6513 == 0)
    goto L26; // [752] 1352

    /** 		sequence sl = find_all(SLASH,lPath) -- split apart lPath*/
    RefDS(_lPath_6514);
    _0 = _sl_6660;
    _sl_6660 = _16find_all(92, _lPath_6514, 1);
    DeRef(_0);

    /** 		integer short_name = and_bits(TO_SHORT,case_flags)=TO_SHORT*/
    {unsigned long tu;
         tu = (unsigned long)4 & (unsigned long)_case_flags_6513;
         _3512 = MAKE_UINT(tu);
    }
    if (IS_ATOM_INT(_3512)) {
        _short_name_6663 = (_3512 == 4);
    }
    else {
        _short_name_6663 = (DBL_PTR(_3512)->dbl == (double)4);
    }
    DeRef(_3512);
    _3512 = NOVALUE;

    /** 		integer correct_name = and_bits(case_flags,CORRECT)=CORRECT*/
    {unsigned long tu;
         tu = (unsigned long)_case_flags_6513 & (unsigned long)2;
         _3514 = MAKE_UINT(tu);
    }
    if (IS_ATOM_INT(_3514)) {
        _correct_name_6666 = (_3514 == 2);
    }
    else {
        _correct_name_6666 = (DBL_PTR(_3514)->dbl == (double)2);
    }
    DeRef(_3514);
    _3514 = NOVALUE;

    /** 		integer lower_name = and_bits(TO_LOWER,case_flags)=TO_LOWER*/
    {unsigned long tu;
         tu = (unsigned long)1 & (unsigned long)_case_flags_6513;
         _3516 = MAKE_UINT(tu);
    }
    if (IS_ATOM_INT(_3516)) {
        _lower_name_6669 = (_3516 == 1);
    }
    else {
        _lower_name_6669 = (DBL_PTR(_3516)->dbl == (double)1);
    }
    DeRef(_3516);
    _3516 = NOVALUE;

    /** 		if lPath[$] != SLASH then*/
    if (IS_SEQUENCE(_lPath_6514)){
            _3518 = SEQ_PTR(_lPath_6514)->length;
    }
    else {
        _3518 = 1;
    }
    _2 = (int)SEQ_PTR(_lPath_6514);
    _3519 = (int)*(((s1_ptr)_2)->base + _3518);
    if (binary_op_a(EQUALS, _3519, 92)){
        _3519 = NOVALUE;
        goto L27; // [805] 827
    }
    _3519 = NOVALUE;

    /** 			sl = sl & {length(lPath)+1}*/
    if (IS_SEQUENCE(_lPath_6514)){
            _3521 = SEQ_PTR(_lPath_6514)->length;
    }
    else {
        _3521 = 1;
    }
    _3522 = _3521 + 1;
    _3521 = NOVALUE;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _3522;
    _3523 = MAKE_SEQ(_1);
    _3522 = NOVALUE;
    Concat((object_ptr)&_sl_6660, _sl_6660, _3523);
    DeRefDS(_3523);
    _3523 = NOVALUE;
L27: 

    /** 		for i = length(sl)-1 to 1 by -1 label "partloop" do*/
    if (IS_SEQUENCE(_sl_6660)){
            _3525 = SEQ_PTR(_sl_6660)->length;
    }
    else {
        _3525 = 1;
    }
    _3526 = _3525 - 1;
    _3525 = NOVALUE;
    {
        int _i_6681;
        _i_6681 = _3526;
L28: 
        if (_i_6681 < 1){
            goto L29; // [836] 1317
        }

        /** 			sequence part = lPath[1..sl[i]-1]*/
        _2 = (int)SEQ_PTR(_sl_6660);
        _3528 = (int)*(((s1_ptr)_2)->base + _i_6681);
        if (IS_ATOM_INT(_3528)) {
            _3529 = _3528 - 1;
        }
        else {
            _3529 = binary_op(MINUS, _3528, 1);
        }
        _3528 = NOVALUE;
        rhs_slice_target = (object_ptr)&_part_6685;
        RHS_Slice(_lPath_6514, 1, _3529);

        /** 			object list = dir( part & SLASH )*/
        Append(&_3531, _part_6685, 92);
        DeRef(_name_inlined_dir_at_864_6692);
        _name_inlined_dir_at_864_6692 = _3531;
        _3531 = NOVALUE;

        /** 	ifdef WINDOWS then*/

        /** 		return machine_func(M_DIR, name)*/
        DeRef(_list_6689);
        _list_6689 = machine(22, _name_inlined_dir_at_864_6692);
        DeRef(_name_inlined_dir_at_864_6692);
        _name_inlined_dir_at_864_6692 = NOVALUE;

        /** 			sequence supplied_name = lPath[sl[i]+1..sl[i+1]-1]*/
        _2 = (int)SEQ_PTR(_sl_6660);
        _3532 = (int)*(((s1_ptr)_2)->base + _i_6681);
        if (IS_ATOM_INT(_3532)) {
            _3533 = _3532 + 1;
            if (_3533 > MAXINT){
                _3533 = NewDouble((double)_3533);
            }
        }
        else
        _3533 = binary_op(PLUS, 1, _3532);
        _3532 = NOVALUE;
        _3534 = _i_6681 + 1;
        _2 = (int)SEQ_PTR(_sl_6660);
        _3535 = (int)*(((s1_ptr)_2)->base + _3534);
        if (IS_ATOM_INT(_3535)) {
            _3536 = _3535 - 1;
        }
        else {
            _3536 = binary_op(MINUS, _3535, 1);
        }
        _3535 = NOVALUE;
        rhs_slice_target = (object_ptr)&_supplied_name_6694;
        RHS_Slice(_lPath_6514, _3533, _3536);

        /** 			if atom(list) then*/
        _3538 = IS_ATOM(_list_6689);
        if (_3538 == 0)
        {
            _3538 = NOVALUE;
            goto L2A; // [912] 950
        }
        else{
            _3538 = NOVALUE;
        }

        /** 				if lower_name then*/
        if (_lower_name_6669 == 0)
        {
            goto L2B; // [917] 943
        }
        else{
        }

        /** 					lPath = part & lower(lPath[sl[i]..$])*/
        _2 = (int)SEQ_PTR(_sl_6660);
        _3539 = (int)*(((s1_ptr)_2)->base + _i_6681);
        if (IS_SEQUENCE(_lPath_6514)){
                _3540 = SEQ_PTR(_lPath_6514)->length;
        }
        else {
            _3540 = 1;
        }
        rhs_slice_target = (object_ptr)&_3541;
        RHS_Slice(_lPath_6514, _3539, _3540);
        _3542 = _14lower(_3541);
        _3541 = NOVALUE;
        if (IS_SEQUENCE(_part_6685) && IS_ATOM(_3542)) {
            Ref(_3542);
            Append(&_lPath_6514, _part_6685, _3542);
        }
        else if (IS_ATOM(_part_6685) && IS_SEQUENCE(_3542)) {
        }
        else {
            Concat((object_ptr)&_lPath_6514, _part_6685, _3542);
        }
        DeRef(_3542);
        _3542 = NOVALUE;
L2B: 

        /** 				continue*/
        DeRef(_part_6685);
        _part_6685 = NOVALUE;
        DeRef(_list_6689);
        _list_6689 = NOVALUE;
        DeRef(_supplied_name_6694);
        _supplied_name_6694 = NOVALUE;
        goto L2C; // [947] 1312
L2A: 

        /** 			for j = 1 to length(list) do*/
        if (IS_SEQUENCE(_list_6689)){
                _3544 = SEQ_PTR(_list_6689)->length;
        }
        else {
            _3544 = 1;
        }
        {
            int _j_6711;
            _j_6711 = 1;
L2D: 
            if (_j_6711 > _3544){
                goto L2E; // [955] 1080
            }

            /** 				sequence read_name = list[j][D_NAME]*/
            _2 = (int)SEQ_PTR(_list_6689);
            _3545 = (int)*(((s1_ptr)_2)->base + _j_6711);
            DeRef(_read_name_6713);
            _2 = (int)SEQ_PTR(_3545);
            _read_name_6713 = (int)*(((s1_ptr)_2)->base + 1);
            Ref(_read_name_6713);
            _3545 = NOVALUE;

            /** 				if equal(read_name, supplied_name) then*/
            if (_read_name_6713 == _supplied_name_6694)
            _3547 = 1;
            else if (IS_ATOM_INT(_read_name_6713) && IS_ATOM_INT(_supplied_name_6694))
            _3547 = 0;
            else
            _3547 = (compare(_read_name_6713, _supplied_name_6694) == 0);
            if (_3547 == 0)
            {
                _3547 = NOVALUE;
                goto L2F; // [980] 1071
            }
            else{
                _3547 = NOVALUE;
            }

            /** 					if short_name and sequence(list[j][D_ALTNAME]) then*/
            if (_short_name_6663 == 0) {
                goto L30; // [985] 1062
            }
            _2 = (int)SEQ_PTR(_list_6689);
            _3549 = (int)*(((s1_ptr)_2)->base + _j_6711);
            _2 = (int)SEQ_PTR(_3549);
            _3550 = (int)*(((s1_ptr)_2)->base + 11);
            _3549 = NOVALUE;
            _3551 = IS_SEQUENCE(_3550);
            _3550 = NOVALUE;
            if (_3551 == 0)
            {
                _3551 = NOVALUE;
                goto L30; // [1001] 1062
            }
            else{
                _3551 = NOVALUE;
            }

            /** 						lPath = lPath[1..sl[i]] & list[j][D_ALTNAME] & lPath[sl[i+1]..$]*/
            _2 = (int)SEQ_PTR(_sl_6660);
            _3552 = (int)*(((s1_ptr)_2)->base + _i_6681);
            rhs_slice_target = (object_ptr)&_3553;
            RHS_Slice(_lPath_6514, 1, _3552);
            _2 = (int)SEQ_PTR(_list_6689);
            _3554 = (int)*(((s1_ptr)_2)->base + _j_6711);
            _2 = (int)SEQ_PTR(_3554);
            _3555 = (int)*(((s1_ptr)_2)->base + 11);
            _3554 = NOVALUE;
            _3556 = _i_6681 + 1;
            _2 = (int)SEQ_PTR(_sl_6660);
            _3557 = (int)*(((s1_ptr)_2)->base + _3556);
            if (IS_SEQUENCE(_lPath_6514)){
                    _3558 = SEQ_PTR(_lPath_6514)->length;
            }
            else {
                _3558 = 1;
            }
            rhs_slice_target = (object_ptr)&_3559;
            RHS_Slice(_lPath_6514, _3557, _3558);
            {
                int concat_list[3];

                concat_list[0] = _3559;
                concat_list[1] = _3555;
                concat_list[2] = _3553;
                Concat_N((object_ptr)&_lPath_6514, concat_list, 3);
            }
            DeRefDS(_3559);
            _3559 = NOVALUE;
            _3555 = NOVALUE;
            DeRefDS(_3553);
            _3553 = NOVALUE;

            /** 						sl[$] = length(lPath)+1*/
            if (IS_SEQUENCE(_sl_6660)){
                    _3561 = SEQ_PTR(_sl_6660)->length;
            }
            else {
                _3561 = 1;
            }
            if (IS_SEQUENCE(_lPath_6514)){
                    _3562 = SEQ_PTR(_lPath_6514)->length;
            }
            else {
                _3562 = 1;
            }
            _3563 = _3562 + 1;
            _3562 = NOVALUE;
            _2 = (int)SEQ_PTR(_sl_6660);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _sl_6660 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _3561);
            _1 = *(int *)_2;
            *(int *)_2 = _3563;
            if( _1 != _3563 ){
                DeRef(_1);
            }
            _3563 = NOVALUE;
L30: 

            /** 					continue "partloop"*/
            DeRef(_read_name_6713);
            _read_name_6713 = NOVALUE;
            DeRef(_part_6685);
            _part_6685 = NOVALUE;
            DeRef(_list_6689);
            _list_6689 = NOVALUE;
            DeRef(_supplied_name_6694);
            _supplied_name_6694 = NOVALUE;
            goto L2C; // [1068] 1312
L2F: 
            DeRef(_read_name_6713);
            _read_name_6713 = NOVALUE;

            /** 			end for*/
            _j_6711 = _j_6711 + 1;
            goto L2D; // [1075] 962
L2E: 
            ;
        }

        /** 			for j = 1 to length(list) do*/
        if (IS_SEQUENCE(_list_6689)){
                _3564 = SEQ_PTR(_list_6689)->length;
        }
        else {
            _3564 = 1;
        }
        {
            int _j_6736;
            _j_6736 = 1;
L31: 
            if (_j_6736 > _3564){
                goto L32; // [1085] 1257
            }

            /** 				sequence read_name = list[j][D_NAME]*/
            _2 = (int)SEQ_PTR(_list_6689);
            _3565 = (int)*(((s1_ptr)_2)->base + _j_6736);
            DeRef(_read_name_6738);
            _2 = (int)SEQ_PTR(_3565);
            _read_name_6738 = (int)*(((s1_ptr)_2)->base + 1);
            Ref(_read_name_6738);
            _3565 = NOVALUE;

            /** 				if equal(lower(read_name), lower(supplied_name)) then*/
            RefDS(_read_name_6738);
            _3567 = _14lower(_read_name_6738);
            RefDS(_supplied_name_6694);
            _3568 = _14lower(_supplied_name_6694);
            if (_3567 == _3568)
            _3569 = 1;
            else if (IS_ATOM_INT(_3567) && IS_ATOM_INT(_3568))
            _3569 = 0;
            else
            _3569 = (compare(_3567, _3568) == 0);
            DeRef(_3567);
            _3567 = NOVALUE;
            DeRef(_3568);
            _3568 = NOVALUE;
            if (_3569 == 0)
            {
                _3569 = NOVALUE;
                goto L33; // [1118] 1248
            }
            else{
                _3569 = NOVALUE;
            }

            /** 					if short_name and sequence(list[j][D_ALTNAME]) then*/
            if (_short_name_6663 == 0) {
                goto L34; // [1123] 1200
            }
            _2 = (int)SEQ_PTR(_list_6689);
            _3571 = (int)*(((s1_ptr)_2)->base + _j_6736);
            _2 = (int)SEQ_PTR(_3571);
            _3572 = (int)*(((s1_ptr)_2)->base + 11);
            _3571 = NOVALUE;
            _3573 = IS_SEQUENCE(_3572);
            _3572 = NOVALUE;
            if (_3573 == 0)
            {
                _3573 = NOVALUE;
                goto L34; // [1139] 1200
            }
            else{
                _3573 = NOVALUE;
            }

            /** 						lPath = lPath[1..sl[i]] & list[j][D_ALTNAME] & lPath[sl[i+1]..$]*/
            _2 = (int)SEQ_PTR(_sl_6660);
            _3574 = (int)*(((s1_ptr)_2)->base + _i_6681);
            rhs_slice_target = (object_ptr)&_3575;
            RHS_Slice(_lPath_6514, 1, _3574);
            _2 = (int)SEQ_PTR(_list_6689);
            _3576 = (int)*(((s1_ptr)_2)->base + _j_6736);
            _2 = (int)SEQ_PTR(_3576);
            _3577 = (int)*(((s1_ptr)_2)->base + 11);
            _3576 = NOVALUE;
            _3578 = _i_6681 + 1;
            _2 = (int)SEQ_PTR(_sl_6660);
            _3579 = (int)*(((s1_ptr)_2)->base + _3578);
            if (IS_SEQUENCE(_lPath_6514)){
                    _3580 = SEQ_PTR(_lPath_6514)->length;
            }
            else {
                _3580 = 1;
            }
            rhs_slice_target = (object_ptr)&_3581;
            RHS_Slice(_lPath_6514, _3579, _3580);
            {
                int concat_list[3];

                concat_list[0] = _3581;
                concat_list[1] = _3577;
                concat_list[2] = _3575;
                Concat_N((object_ptr)&_lPath_6514, concat_list, 3);
            }
            DeRefDS(_3581);
            _3581 = NOVALUE;
            _3577 = NOVALUE;
            DeRefDS(_3575);
            _3575 = NOVALUE;

            /** 						sl[$] = length(lPath)+1*/
            if (IS_SEQUENCE(_sl_6660)){
                    _3583 = SEQ_PTR(_sl_6660)->length;
            }
            else {
                _3583 = 1;
            }
            if (IS_SEQUENCE(_lPath_6514)){
                    _3584 = SEQ_PTR(_lPath_6514)->length;
            }
            else {
                _3584 = 1;
            }
            _3585 = _3584 + 1;
            _3584 = NOVALUE;
            _2 = (int)SEQ_PTR(_sl_6660);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _sl_6660 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _3583);
            _1 = *(int *)_2;
            *(int *)_2 = _3585;
            if( _1 != _3585 ){
                DeRef(_1);
            }
            _3585 = NOVALUE;
L34: 

            /** 					if correct_name then*/
            if (_correct_name_6666 == 0)
            {
                goto L35; // [1202] 1239
            }
            else{
            }

            /** 						lPath = lPath[1..sl[i]] & read_name & lPath[sl[i+1]..$]*/
            _2 = (int)SEQ_PTR(_sl_6660);
            _3586 = (int)*(((s1_ptr)_2)->base + _i_6681);
            rhs_slice_target = (object_ptr)&_3587;
            RHS_Slice(_lPath_6514, 1, _3586);
            _3588 = _i_6681 + 1;
            _2 = (int)SEQ_PTR(_sl_6660);
            _3589 = (int)*(((s1_ptr)_2)->base + _3588);
            if (IS_SEQUENCE(_lPath_6514)){
                    _3590 = SEQ_PTR(_lPath_6514)->length;
            }
            else {
                _3590 = 1;
            }
            rhs_slice_target = (object_ptr)&_3591;
            RHS_Slice(_lPath_6514, _3589, _3590);
            {
                int concat_list[3];

                concat_list[0] = _3591;
                concat_list[1] = _read_name_6738;
                concat_list[2] = _3587;
                Concat_N((object_ptr)&_lPath_6514, concat_list, 3);
            }
            DeRefDS(_3591);
            _3591 = NOVALUE;
            DeRefDS(_3587);
            _3587 = NOVALUE;
L35: 

            /** 					continue "partloop"*/
            DeRef(_read_name_6738);
            _read_name_6738 = NOVALUE;
            DeRef(_part_6685);
            _part_6685 = NOVALUE;
            DeRef(_list_6689);
            _list_6689 = NOVALUE;
            DeRef(_supplied_name_6694);
            _supplied_name_6694 = NOVALUE;
            goto L2C; // [1245] 1312
L33: 
            DeRef(_read_name_6738);
            _read_name_6738 = NOVALUE;

            /** 			end for*/
            _j_6736 = _j_6736 + 1;
            goto L31; // [1252] 1092
L32: 
            ;
        }

        /** 			if and_bits(TO_LOWER,case_flags) then*/
        {unsigned long tu;
             tu = (unsigned long)1 & (unsigned long)_case_flags_6513;
             _3593 = MAKE_UINT(tu);
        }
        if (_3593 == 0) {
            DeRef(_3593);
            _3593 = NOVALUE;
            goto L36; // [1263] 1302
        }
        else {
            if (!IS_ATOM_INT(_3593) && DBL_PTR(_3593)->dbl == 0.0){
                DeRef(_3593);
                _3593 = NOVALUE;
                goto L36; // [1263] 1302
            }
            DeRef(_3593);
            _3593 = NOVALUE;
        }
        DeRef(_3593);
        _3593 = NOVALUE;

        /** 				lPath = lPath[1..sl[i]-1] & lower(lPath[sl[i]..$])*/
        _2 = (int)SEQ_PTR(_sl_6660);
        _3594 = (int)*(((s1_ptr)_2)->base + _i_6681);
        if (IS_ATOM_INT(_3594)) {
            _3595 = _3594 - 1;
        }
        else {
            _3595 = binary_op(MINUS, _3594, 1);
        }
        _3594 = NOVALUE;
        rhs_slice_target = (object_ptr)&_3596;
        RHS_Slice(_lPath_6514, 1, _3595);
        _2 = (int)SEQ_PTR(_sl_6660);
        _3597 = (int)*(((s1_ptr)_2)->base + _i_6681);
        if (IS_SEQUENCE(_lPath_6514)){
                _3598 = SEQ_PTR(_lPath_6514)->length;
        }
        else {
            _3598 = 1;
        }
        rhs_slice_target = (object_ptr)&_3599;
        RHS_Slice(_lPath_6514, _3597, _3598);
        _3600 = _14lower(_3599);
        _3599 = NOVALUE;
        if (IS_SEQUENCE(_3596) && IS_ATOM(_3600)) {
            Ref(_3600);
            Append(&_lPath_6514, _3596, _3600);
        }
        else if (IS_ATOM(_3596) && IS_SEQUENCE(_3600)) {
        }
        else {
            Concat((object_ptr)&_lPath_6514, _3596, _3600);
            DeRefDS(_3596);
            _3596 = NOVALUE;
        }
        DeRef(_3596);
        _3596 = NOVALUE;
        DeRef(_3600);
        _3600 = NOVALUE;
L36: 

        /** 			exit*/
        DeRef(_part_6685);
        _part_6685 = NOVALUE;
        DeRef(_list_6689);
        _list_6689 = NOVALUE;
        DeRef(_supplied_name_6694);
        _supplied_name_6694 = NOVALUE;
        goto L29; // [1306] 1317

        /** 		end for*/
L2C: 
        _i_6681 = _i_6681 + -1;
        goto L28; // [1312] 843
L29: 
        ;
    }

    /** 		if and_bits(case_flags,or_bits(CORRECT,TO_LOWER))=TO_LOWER and length(lPath) then*/
    {unsigned long tu;
         tu = (unsigned long)2 | (unsigned long)1;
         _3602 = MAKE_UINT(tu);
    }
    if (IS_ATOM_INT(_3602)) {
        {unsigned long tu;
             tu = (unsigned long)_case_flags_6513 & (unsigned long)_3602;
             _3603 = MAKE_UINT(tu);
        }
    }
    else {
        temp_d.dbl = (double)_case_flags_6513;
        _3603 = Dand_bits(&temp_d, DBL_PTR(_3602));
    }
    DeRef(_3602);
    _3602 = NOVALUE;
    if (IS_ATOM_INT(_3603)) {
        _3604 = (_3603 == 1);
    }
    else {
        _3604 = (DBL_PTR(_3603)->dbl == (double)1);
    }
    DeRef(_3603);
    _3603 = NOVALUE;
    if (_3604 == 0) {
        goto L37; // [1331] 1351
    }
    if (IS_SEQUENCE(_lPath_6514)){
            _3606 = SEQ_PTR(_lPath_6514)->length;
    }
    else {
        _3606 = 1;
    }
    if (_3606 == 0)
    {
        _3606 = NOVALUE;
        goto L37; // [1339] 1351
    }
    else{
        _3606 = NOVALUE;
    }

    /** 			lPath = lower(lPath)*/
    RefDS(_lPath_6514);
    _0 = _lPath_6514;
    _lPath_6514 = _14lower(_lPath_6514);
    DeRefDS(_0);
L37: 
L26: 
    DeRef(_sl_6660);
    _sl_6660 = NOVALUE;
L25: 

    /** 	ifdef WINDOWS then*/

    /** 		if and_bits(CORRECT,case_flags) then*/
    {unsigned long tu;
         tu = (unsigned long)2 & (unsigned long)_case_flags_6513;
         _3608 = MAKE_UINT(tu);
    }
    if (_3608 == 0) {
        DeRef(_3608);
        _3608 = NOVALUE;
        goto L38; // [1363] 1405
    }
    else {
        if (!IS_ATOM_INT(_3608) && DBL_PTR(_3608)->dbl == 0.0){
            DeRef(_3608);
            _3608 = NOVALUE;
            goto L38; // [1363] 1405
        }
        DeRef(_3608);
        _3608 = NOVALUE;
    }
    DeRef(_3608);
    _3608 = NOVALUE;

    /** 			if or_bits(system_drive_case,'A') = 'a' then*/
    if (IS_ATOM_INT(_17system_drive_case_6497)) {
        {unsigned long tu;
             tu = (unsigned long)_17system_drive_case_6497 | (unsigned long)65;
             _3609 = MAKE_UINT(tu);
        }
    }
    else {
        temp_d.dbl = (double)65;
        _3609 = Dor_bits(DBL_PTR(_17system_drive_case_6497), &temp_d);
    }
    if (binary_op_a(NOTEQ, _3609, 97)){
        DeRef(_3609);
        _3609 = NOVALUE;
        goto L39; // [1374] 1391
    }
    DeRef(_3609);
    _3609 = NOVALUE;

    /** 				lDrive = lower(lDrive)*/
    RefDS(_lDrive_6519);
    _0 = _lDrive_6519;
    _lDrive_6519 = _14lower(_lDrive_6519);
    DeRefDS(_0);
    goto L3A; // [1388] 1426
L39: 

    /** 				lDrive = upper(lDrive)*/
    RefDS(_lDrive_6519);
    _0 = _lDrive_6519;
    _lDrive_6519 = _14upper(_lDrive_6519);
    DeRefDS(_0);
    goto L3A; // [1402] 1426
L38: 

    /** 		elsif and_bits(TO_LOWER,case_flags) then*/
    {unsigned long tu;
         tu = (unsigned long)1 & (unsigned long)_case_flags_6513;
         _3613 = MAKE_UINT(tu);
    }
    if (_3613 == 0) {
        DeRef(_3613);
        _3613 = NOVALUE;
        goto L3B; // [1411] 1425
    }
    else {
        if (!IS_ATOM_INT(_3613) && DBL_PTR(_3613)->dbl == 0.0){
            DeRef(_3613);
            _3613 = NOVALUE;
            goto L3B; // [1411] 1425
        }
        DeRef(_3613);
        _3613 = NOVALUE;
    }
    DeRef(_3613);
    _3613 = NOVALUE;

    /** 			lDrive = lower(lDrive)*/
    RefDS(_lDrive_6519);
    _0 = _lDrive_6519;
    _lDrive_6519 = _14lower(_lDrive_6519);
    DeRefDS(_0);
L3B: 
L3A: 

    /** 		lPath = lDrive & lPath*/
    Concat((object_ptr)&_lPath_6514, _lDrive_6519, _lPath_6514);

    /** 	return lPath & wildcard_suffix*/
    Concat((object_ptr)&_3616, _lPath_6514, _wildcard_suffix_6584);
    DeRefDS(_path_in_6511);
    DeRefDS(_lPath_6514);
    DeRefi(_lLevel_6517);
    DeRef(_lHome_6518);
    DeRefDS(_lDrive_6519);
    DeRefDS(_wildcard_suffix_6584);
    DeRef(_3407);
    _3407 = NOVALUE;
    DeRef(_3489);
    _3489 = NOVALUE;
    _3539 = NOVALUE;
    _3586 = NOVALUE;
    DeRef(_3467);
    _3467 = NOVALUE;
    _3579 = NOVALUE;
    DeRef(_3526);
    _3526 = NOVALUE;
    _3557 = NOVALUE;
    DeRef(_3419);
    _3419 = NOVALUE;
    DeRef(_3485);
    _3485 = NOVALUE;
    DeRef(_3595);
    _3595 = NOVALUE;
    DeRef(_3410);
    _3410 = NOVALUE;
    DeRef(_3533);
    _3533 = NOVALUE;
    DeRef(_3436);
    _3436 = NOVALUE;
    DeRef(_3578);
    _3578 = NOVALUE;
    _3597 = NOVALUE;
    DeRef(_3479);
    _3479 = NOVALUE;
    _3552 = NOVALUE;
    DeRef(_3588);
    _3588 = NOVALUE;
    DeRef(_3604);
    _3604 = NOVALUE;
    DeRef(_3556);
    _3556 = NOVALUE;
    DeRef(_3414);
    _3414 = NOVALUE;
    DeRef(_3447);
    _3447 = NOVALUE;
    DeRef(_3502);
    _3502 = NOVALUE;
    DeRef(_3529);
    _3529 = NOVALUE;
    DeRef(_3462);
    _3462 = NOVALUE;
    DeRef(_3536);
    _3536 = NOVALUE;
    DeRef(_3416);
    _3416 = NOVALUE;
    _3589 = NOVALUE;
    DeRef(_3534);
    _3534 = NOVALUE;
    DeRef(_3450);
    _3450 = NOVALUE;
    DeRef(_3476);
    _3476 = NOVALUE;
    _3574 = NOVALUE;
    DeRef(_3422);
    _3422 = NOVALUE;
    DeRef(_3499);
    _3499 = NOVALUE;
    return _3616;
    ;
}


int _17fs_case(int _s_6809)
{
    int _3617 = NOVALUE;
    int _0, _1, _2;
    

    /** 	ifdef WINDOWS then*/

    /** 		return lower(s)*/
    RefDS(_s_6809);
    _3617 = _14lower(_s_6809);
    DeRefDS(_s_6809);
    return _3617;
    ;
}


int _17abbreviate_path(int _orig_path_6814, int _base_paths_6815)
{
    int _expanded_path_6816 = NOVALUE;
    int _lowered_expanded_path_6826 = NOVALUE;
    int _3662 = NOVALUE;
    int _3661 = NOVALUE;
    int _3658 = NOVALUE;
    int _3657 = NOVALUE;
    int _3656 = NOVALUE;
    int _3655 = NOVALUE;
    int _3654 = NOVALUE;
    int _3652 = NOVALUE;
    int _3651 = NOVALUE;
    int _3650 = NOVALUE;
    int _3649 = NOVALUE;
    int _3648 = NOVALUE;
    int _3647 = NOVALUE;
    int _3646 = NOVALUE;
    int _3645 = NOVALUE;
    int _3644 = NOVALUE;
    int _3641 = NOVALUE;
    int _3640 = NOVALUE;
    int _3638 = NOVALUE;
    int _3637 = NOVALUE;
    int _3636 = NOVALUE;
    int _3635 = NOVALUE;
    int _3634 = NOVALUE;
    int _3633 = NOVALUE;
    int _3632 = NOVALUE;
    int _3631 = NOVALUE;
    int _3630 = NOVALUE;
    int _3629 = NOVALUE;
    int _3628 = NOVALUE;
    int _3627 = NOVALUE;
    int _3626 = NOVALUE;
    int _3623 = NOVALUE;
    int _3622 = NOVALUE;
    int _3621 = NOVALUE;
    int _3619 = NOVALUE;
    int _0, _1, _2;
    

    /** 	expanded_path = canonical_path(orig_path)*/
    RefDS(_orig_path_6814);
    _0 = _expanded_path_6816;
    _expanded_path_6816 = _17canonical_path(_orig_path_6814, 0, 0);
    DeRef(_0);

    /** 	base_paths = append(base_paths, curdir())*/
    _3619 = _17curdir(0);
    Ref(_3619);
    Append(&_base_paths_6815, _base_paths_6815, _3619);
    DeRef(_3619);
    _3619 = NOVALUE;

    /** 	for i = 1 to length(base_paths) do*/
    _3621 = 1;
    {
        int _i_6821;
        _i_6821 = 1;
L1: 
        if (_i_6821 > 1){
            goto L2; // [30] 60
        }

        /** 		base_paths[i] = canonical_path(base_paths[i], 1) -- assume each base path is meant to be a directory.*/
        _2 = (int)SEQ_PTR(_base_paths_6815);
        _3622 = (int)*(((s1_ptr)_2)->base + 1);
        Ref(_3622);
        _3623 = _17canonical_path(_3622, 1, 0);
        _3622 = NOVALUE;
        _2 = (int)SEQ_PTR(_base_paths_6815);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _base_paths_6815 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 1);
        _1 = *(int *)_2;
        *(int *)_2 = _3623;
        if( _1 != _3623 ){
            DeRef(_1);
        }
        _3623 = NOVALUE;

        /** 	end for*/
        _i_6821 = 1 + 1;
        goto L1; // [55] 37
L2: 
        ;
    }

    /** 	base_paths = fs_case(base_paths)*/
    RefDS(_base_paths_6815);
    _0 = _base_paths_6815;
    _base_paths_6815 = _17fs_case(_base_paths_6815);
    DeRefDS(_0);

    /** 	sequence lowered_expanded_path = fs_case(expanded_path)*/
    RefDS(_expanded_path_6816);
    _0 = _lowered_expanded_path_6826;
    _lowered_expanded_path_6826 = _17fs_case(_expanded_path_6816);
    DeRef(_0);

    /** 	for i = 1 to length(base_paths) do*/
    if (IS_SEQUENCE(_base_paths_6815)){
            _3626 = SEQ_PTR(_base_paths_6815)->length;
    }
    else {
        _3626 = 1;
    }
    {
        int _i_6829;
        _i_6829 = 1;
L3: 
        if (_i_6829 > _3626){
            goto L4; // [81] 135
        }

        /** 		if search:begins(base_paths[i], lowered_expanded_path) then*/
        _2 = (int)SEQ_PTR(_base_paths_6815);
        _3627 = (int)*(((s1_ptr)_2)->base + _i_6829);
        Ref(_3627);
        RefDS(_lowered_expanded_path_6826);
        _3628 = _16begins(_3627, _lowered_expanded_path_6826);
        _3627 = NOVALUE;
        if (_3628 == 0) {
            DeRef(_3628);
            _3628 = NOVALUE;
            goto L5; // [99] 128
        }
        else {
            if (!IS_ATOM_INT(_3628) && DBL_PTR(_3628)->dbl == 0.0){
                DeRef(_3628);
                _3628 = NOVALUE;
                goto L5; // [99] 128
            }
            DeRef(_3628);
            _3628 = NOVALUE;
        }
        DeRef(_3628);
        _3628 = NOVALUE;

        /** 			return expanded_path[length(base_paths[i]) + 1 .. $]*/
        _2 = (int)SEQ_PTR(_base_paths_6815);
        _3629 = (int)*(((s1_ptr)_2)->base + _i_6829);
        if (IS_SEQUENCE(_3629)){
                _3630 = SEQ_PTR(_3629)->length;
        }
        else {
            _3630 = 1;
        }
        _3629 = NOVALUE;
        _3631 = _3630 + 1;
        _3630 = NOVALUE;
        if (IS_SEQUENCE(_expanded_path_6816)){
                _3632 = SEQ_PTR(_expanded_path_6816)->length;
        }
        else {
            _3632 = 1;
        }
        rhs_slice_target = (object_ptr)&_3633;
        RHS_Slice(_expanded_path_6816, _3631, _3632);
        DeRefDS(_orig_path_6814);
        DeRefDS(_base_paths_6815);
        DeRefDS(_expanded_path_6816);
        DeRefDS(_lowered_expanded_path_6826);
        _3629 = NOVALUE;
        _3631 = NOVALUE;
        return _3633;
L5: 

        /** 	end for*/
        _i_6829 = _i_6829 + 1;
        goto L3; // [130] 88
L4: 
        ;
    }

    /** 	ifdef WINDOWS then*/

    /** 		if not equal(base_paths[$][1], lowered_expanded_path[1]) then*/
    if (IS_SEQUENCE(_base_paths_6815)){
            _3634 = SEQ_PTR(_base_paths_6815)->length;
    }
    else {
        _3634 = 1;
    }
    _2 = (int)SEQ_PTR(_base_paths_6815);
    _3635 = (int)*(((s1_ptr)_2)->base + _3634);
    _2 = (int)SEQ_PTR(_3635);
    _3636 = (int)*(((s1_ptr)_2)->base + 1);
    _3635 = NOVALUE;
    _2 = (int)SEQ_PTR(_lowered_expanded_path_6826);
    _3637 = (int)*(((s1_ptr)_2)->base + 1);
    if (_3636 == _3637)
    _3638 = 1;
    else if (IS_ATOM_INT(_3636) && IS_ATOM_INT(_3637))
    _3638 = 0;
    else
    _3638 = (compare(_3636, _3637) == 0);
    _3636 = NOVALUE;
    _3637 = NOVALUE;
    if (_3638 != 0)
    goto L6; // [158] 168
    _3638 = NOVALUE;

    /** 			return orig_path*/
    DeRefDS(_base_paths_6815);
    DeRef(_expanded_path_6816);
    DeRefDS(_lowered_expanded_path_6826);
    _3629 = NOVALUE;
    DeRef(_3631);
    _3631 = NOVALUE;
    DeRef(_3633);
    _3633 = NOVALUE;
    return _orig_path_6814;
L6: 

    /** 	base_paths = stdseq:split(base_paths[$], SLASH)*/
    if (IS_SEQUENCE(_base_paths_6815)){
            _3640 = SEQ_PTR(_base_paths_6815)->length;
    }
    else {
        _3640 = 1;
    }
    _2 = (int)SEQ_PTR(_base_paths_6815);
    _3641 = (int)*(((s1_ptr)_2)->base + _3640);
    Ref(_3641);
    _0 = _base_paths_6815;
    _base_paths_6815 = _23split(_3641, 92, 0, 0);
    DeRefDS(_0);
    _3641 = NOVALUE;

    /** 	expanded_path = stdseq:split(expanded_path, SLASH)*/
    RefDS(_expanded_path_6816);
    _0 = _expanded_path_6816;
    _expanded_path_6816 = _23split(_expanded_path_6816, 92, 0, 0);
    DeRefDS(_0);

    /** 	lowered_expanded_path = ""*/
    RefDS(_5);
    DeRef(_lowered_expanded_path_6826);
    _lowered_expanded_path_6826 = _5;

    /** 	for i = 1 to math:min({length(expanded_path), length(base_paths) - 1}) do*/
    if (IS_SEQUENCE(_expanded_path_6816)){
            _3644 = SEQ_PTR(_expanded_path_6816)->length;
    }
    else {
        _3644 = 1;
    }
    if (IS_SEQUENCE(_base_paths_6815)){
            _3645 = SEQ_PTR(_base_paths_6815)->length;
    }
    else {
        _3645 = 1;
    }
    _3646 = _3645 - 1;
    _3645 = NOVALUE;
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _3644;
    ((int *)_2)[2] = _3646;
    _3647 = MAKE_SEQ(_1);
    _3646 = NOVALUE;
    _3644 = NOVALUE;
    _3648 = _20min(_3647);
    _3647 = NOVALUE;
    {
        int _i_6851;
        _i_6851 = 1;
L7: 
        if (binary_op_a(GREATER, _i_6851, _3648)){
            goto L8; // [224] 317
        }

        /** 		if not equal(fs_case(expanded_path[i]), base_paths[i]) then*/
        _2 = (int)SEQ_PTR(_expanded_path_6816);
        if (!IS_ATOM_INT(_i_6851)){
            _3649 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_6851)->dbl));
        }
        else{
            _3649 = (int)*(((s1_ptr)_2)->base + _i_6851);
        }
        Ref(_3649);
        _3650 = _17fs_case(_3649);
        _3649 = NOVALUE;
        _2 = (int)SEQ_PTR(_base_paths_6815);
        if (!IS_ATOM_INT(_i_6851)){
            _3651 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_6851)->dbl));
        }
        else{
            _3651 = (int)*(((s1_ptr)_2)->base + _i_6851);
        }
        if (_3650 == _3651)
        _3652 = 1;
        else if (IS_ATOM_INT(_3650) && IS_ATOM_INT(_3651))
        _3652 = 0;
        else
        _3652 = (compare(_3650, _3651) == 0);
        DeRef(_3650);
        _3650 = NOVALUE;
        _3651 = NOVALUE;
        if (_3652 != 0)
        goto L9; // [249] 310
        _3652 = NOVALUE;

        /** 			expanded_path = repeat("..", length(base_paths) - i) & expanded_path[i .. $]*/
        if (IS_SEQUENCE(_base_paths_6815)){
                _3654 = SEQ_PTR(_base_paths_6815)->length;
        }
        else {
            _3654 = 1;
        }
        if (IS_ATOM_INT(_i_6851)) {
            _3655 = _3654 - _i_6851;
        }
        else {
            _3655 = NewDouble((double)_3654 - DBL_PTR(_i_6851)->dbl);
        }
        _3654 = NOVALUE;
        _3656 = Repeat(_3174, _3655);
        DeRef(_3655);
        _3655 = NOVALUE;
        if (IS_SEQUENCE(_expanded_path_6816)){
                _3657 = SEQ_PTR(_expanded_path_6816)->length;
        }
        else {
            _3657 = 1;
        }
        rhs_slice_target = (object_ptr)&_3658;
        RHS_Slice(_expanded_path_6816, _i_6851, _3657);
        Concat((object_ptr)&_expanded_path_6816, _3656, _3658);
        DeRefDS(_3656);
        _3656 = NOVALUE;
        DeRef(_3656);
        _3656 = NOVALUE;
        DeRefDS(_3658);
        _3658 = NOVALUE;

        /** 			expanded_path = stdseq:join(expanded_path, SLASH)*/
        RefDS(_expanded_path_6816);
        _0 = _expanded_path_6816;
        _expanded_path_6816 = _23join(_expanded_path_6816, 92);
        DeRefDS(_0);

        /** 			if length(expanded_path) < length(orig_path) then*/
        if (IS_SEQUENCE(_expanded_path_6816)){
                _3661 = SEQ_PTR(_expanded_path_6816)->length;
        }
        else {
            _3661 = 1;
        }
        if (IS_SEQUENCE(_orig_path_6814)){
                _3662 = SEQ_PTR(_orig_path_6814)->length;
        }
        else {
            _3662 = 1;
        }
        if (_3661 >= _3662)
        goto L8; // [294] 317

        /** 		  		return expanded_path*/
        DeRef(_i_6851);
        DeRefDS(_orig_path_6814);
        DeRefDS(_base_paths_6815);
        DeRef(_lowered_expanded_path_6826);
        _3629 = NOVALUE;
        DeRef(_3631);
        _3631 = NOVALUE;
        DeRef(_3633);
        _3633 = NOVALUE;
        DeRef(_3648);
        _3648 = NOVALUE;
        return _expanded_path_6816;

        /** 			exit*/
        goto L8; // [307] 317
L9: 

        /** 	end for*/
        _0 = _i_6851;
        if (IS_ATOM_INT(_i_6851)) {
            _i_6851 = _i_6851 + 1;
            if ((long)((unsigned long)_i_6851 +(unsigned long) HIGH_BITS) >= 0){
                _i_6851 = NewDouble((double)_i_6851);
            }
        }
        else {
            _i_6851 = binary_op_a(PLUS, _i_6851, 1);
        }
        DeRef(_0);
        goto L7; // [312] 231
L8: 
        ;
        DeRef(_i_6851);
    }

    /** 	return orig_path*/
    DeRefDS(_base_paths_6815);
    DeRef(_expanded_path_6816);
    DeRef(_lowered_expanded_path_6826);
    _3629 = NOVALUE;
    DeRef(_3631);
    _3631 = NOVALUE;
    DeRef(_3633);
    _3633 = NOVALUE;
    DeRef(_3648);
    _3648 = NOVALUE;
    return _orig_path_6814;
    ;
}


int _17file_type(int _filename_6911)
{
    int _dirfil_6912 = NOVALUE;
    int _dir_inlined_dir_at_64_6925 = NOVALUE;
    int _3703 = NOVALUE;
    int _3702 = NOVALUE;
    int _3701 = NOVALUE;
    int _3700 = NOVALUE;
    int _3699 = NOVALUE;
    int _3697 = NOVALUE;
    int _3696 = NOVALUE;
    int _3695 = NOVALUE;
    int _3694 = NOVALUE;
    int _3693 = NOVALUE;
    int _3692 = NOVALUE;
    int _3691 = NOVALUE;
    int _3689 = NOVALUE;
    int _3688 = NOVALUE;
    int _3687 = NOVALUE;
    int _3686 = NOVALUE;
    int _3685 = NOVALUE;
    int _3684 = NOVALUE;
    int _3682 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if eu:find('*', filename) or eu:find('?', filename) then return FILETYPE_UNDEFINED end if*/
    _3682 = find_from(42, _filename_6911, 1);
    if (_3682 != 0) {
        goto L1; // [10] 24
    }
    _3684 = find_from(63, _filename_6911, 1);
    if (_3684 == 0)
    {
        _3684 = NOVALUE;
        goto L2; // [20] 29
    }
    else{
        _3684 = NOVALUE;
    }
L1: 
    DeRefDS(_filename_6911);
    DeRef(_dirfil_6912);
    return -1;
L2: 

    /** 	ifdef WINDOWS then*/

    /** 		if length(filename) = 2 and filename[2] = ':' then*/
    if (IS_SEQUENCE(_filename_6911)){
            _3685 = SEQ_PTR(_filename_6911)->length;
    }
    else {
        _3685 = 1;
    }
    _3686 = (_3685 == 2);
    _3685 = NOVALUE;
    if (_3686 == 0) {
        goto L3; // [40] 63
    }
    _2 = (int)SEQ_PTR(_filename_6911);
    _3688 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_3688)) {
        _3689 = (_3688 == 58);
    }
    else {
        _3689 = binary_op(EQUALS, _3688, 58);
    }
    _3688 = NOVALUE;
    if (_3689 == 0) {
        DeRef(_3689);
        _3689 = NOVALUE;
        goto L3; // [53] 63
    }
    else {
        if (!IS_ATOM_INT(_3689) && DBL_PTR(_3689)->dbl == 0.0){
            DeRef(_3689);
            _3689 = NOVALUE;
            goto L3; // [53] 63
        }
        DeRef(_3689);
        _3689 = NOVALUE;
    }
    DeRef(_3689);
    _3689 = NOVALUE;

    /** 			filename &= "\\"*/
    Concat((object_ptr)&_filename_6911, _filename_6911, _945);
L3: 

    /** 	dirfil = dir(filename)*/

    /** 	ifdef WINDOWS then*/

    /** 		return machine_func(M_DIR, name)*/
    DeRef(_dirfil_6912);
    _dirfil_6912 = machine(22, _filename_6911);

    /** 	if sequence(dirfil) then*/
    _3691 = IS_SEQUENCE(_dirfil_6912);
    if (_3691 == 0)
    {
        _3691 = NOVALUE;
        goto L4; // [79] 163
    }
    else{
        _3691 = NOVALUE;
    }

    /** 		if length( dirfil ) > 1 or eu:find('d', dirfil[1][2]) or (length(filename)=3 and filename[2]=':') then*/
    if (IS_SEQUENCE(_dirfil_6912)){
            _3692 = SEQ_PTR(_dirfil_6912)->length;
    }
    else {
        _3692 = 1;
    }
    _3693 = (_3692 > 1);
    _3692 = NOVALUE;
    if (_3693 != 0) {
        _3694 = 1;
        goto L5; // [91] 112
    }
    _2 = (int)SEQ_PTR(_dirfil_6912);
    _3695 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_3695);
    _3696 = (int)*(((s1_ptr)_2)->base + 2);
    _3695 = NOVALUE;
    _3697 = find_from(100, _3696, 1);
    _3696 = NOVALUE;
    _3694 = (_3697 != 0);
L5: 
    if (_3694 != 0) {
        goto L6; // [112] 144
    }
    if (IS_SEQUENCE(_filename_6911)){
            _3699 = SEQ_PTR(_filename_6911)->length;
    }
    else {
        _3699 = 1;
    }
    _3700 = (_3699 == 3);
    _3699 = NOVALUE;
    if (_3700 == 0) {
        DeRef(_3701);
        _3701 = 0;
        goto L7; // [123] 139
    }
    _2 = (int)SEQ_PTR(_filename_6911);
    _3702 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_3702)) {
        _3703 = (_3702 == 58);
    }
    else {
        _3703 = binary_op(EQUALS, _3702, 58);
    }
    _3702 = NOVALUE;
    if (IS_ATOM_INT(_3703))
    _3701 = (_3703 != 0);
    else
    _3701 = DBL_PTR(_3703)->dbl != 0.0;
L7: 
    if (_3701 == 0)
    {
        _3701 = NOVALUE;
        goto L8; // [140] 153
    }
    else{
        _3701 = NOVALUE;
    }
L6: 

    /** 			return FILETYPE_DIRECTORY*/
    DeRefDS(_filename_6911);
    DeRef(_dirfil_6912);
    DeRef(_3686);
    _3686 = NOVALUE;
    DeRef(_3693);
    _3693 = NOVALUE;
    DeRef(_3700);
    _3700 = NOVALUE;
    DeRef(_3703);
    _3703 = NOVALUE;
    return 2;
    goto L9; // [150] 170
L8: 

    /** 			return FILETYPE_FILE*/
    DeRefDS(_filename_6911);
    DeRef(_dirfil_6912);
    DeRef(_3686);
    _3686 = NOVALUE;
    DeRef(_3693);
    _3693 = NOVALUE;
    DeRef(_3700);
    _3700 = NOVALUE;
    DeRef(_3703);
    _3703 = NOVALUE;
    return 1;
    goto L9; // [160] 170
L4: 

    /** 		return FILETYPE_NOT_FOUND*/
    DeRefDS(_filename_6911);
    DeRef(_dirfil_6912);
    DeRef(_3686);
    _3686 = NOVALUE;
    DeRef(_3693);
    _3693 = NOVALUE;
    DeRef(_3700);
    _3700 = NOVALUE;
    DeRef(_3703);
    _3703 = NOVALUE;
    return 0;
L9: 
    ;
}


int _17file_exists(int _name_6959)
{
    int _pName_6962 = NOVALUE;
    int _r_6965 = NOVALUE;
    int _3708 = NOVALUE;
    int _3706 = NOVALUE;
    int _3704 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(name) then*/
    _3704 = IS_ATOM(_name_6959);
    if (_3704 == 0)
    {
        _3704 = NOVALUE;
        goto L1; // [6] 16
    }
    else{
        _3704 = NOVALUE;
    }

    /** 		return 0*/
    DeRef(_name_6959);
    DeRef(_pName_6962);
    DeRef(_r_6965);
    return 0;
L1: 

    /** 	ifdef WINDOWS then*/

    /** 		atom pName = allocate_string(name)*/
    Ref(_name_6959);
    _0 = _pName_6962;
    _pName_6962 = _9allocate_string(_name_6959, 0);
    DeRef(_0);

    /** 		atom r = c_func(xGetFileAttributes, {pName})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_pName_6962);
    *((int *)(_2+4)) = _pName_6962;
    _3706 = MAKE_SEQ(_1);
    DeRef(_r_6965);
    _r_6965 = call_c(1, _17xGetFileAttributes_5961, _3706);
    DeRefDS(_3706);
    _3706 = NOVALUE;

    /** 		free(pName)*/
    Ref(_pName_6962);
    _9free(_pName_6962);

    /** 		return r > 0*/
    if (IS_ATOM_INT(_r_6965)) {
        _3708 = (_r_6965 > 0);
    }
    else {
        _3708 = (DBL_PTR(_r_6965)->dbl > (double)0);
    }
    DeRef(_name_6959);
    DeRef(_pName_6962);
    DeRef(_r_6965);
    return _3708;
    ;
}


int _17file_timestamp(int _fname_6972)
{
    int _d_6973 = NOVALUE;
    int _dir_inlined_dir_at_4_6975 = NOVALUE;
    int _3722 = NOVALUE;
    int _3721 = NOVALUE;
    int _3720 = NOVALUE;
    int _3719 = NOVALUE;
    int _3718 = NOVALUE;
    int _3717 = NOVALUE;
    int _3716 = NOVALUE;
    int _3715 = NOVALUE;
    int _3714 = NOVALUE;
    int _3713 = NOVALUE;
    int _3712 = NOVALUE;
    int _3711 = NOVALUE;
    int _3710 = NOVALUE;
    int _3709 = NOVALUE;
    int _0, _1, _2;
    

    /** 	object d = dir(fname)*/

    /** 	ifdef WINDOWS then*/

    /** 		return machine_func(M_DIR, name)*/
    DeRef(_d_6973);
    _d_6973 = machine(22, _fname_6972);

    /** 	if atom(d) then return -1 end if*/
    _3709 = IS_ATOM(_d_6973);
    if (_3709 == 0)
    {
        _3709 = NOVALUE;
        goto L1; // [19] 27
    }
    else{
        _3709 = NOVALUE;
    }
    DeRefDS(_fname_6972);
    DeRef(_d_6973);
    return -1;
L1: 

    /** 	return datetime:new(d[1][D_YEAR], d[1][D_MONTH], d[1][D_DAY],*/
    _2 = (int)SEQ_PTR(_d_6973);
    _3710 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_3710);
    _3711 = (int)*(((s1_ptr)_2)->base + 4);
    _3710 = NOVALUE;
    _2 = (int)SEQ_PTR(_d_6973);
    _3712 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_3712);
    _3713 = (int)*(((s1_ptr)_2)->base + 5);
    _3712 = NOVALUE;
    _2 = (int)SEQ_PTR(_d_6973);
    _3714 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_3714);
    _3715 = (int)*(((s1_ptr)_2)->base + 6);
    _3714 = NOVALUE;
    _2 = (int)SEQ_PTR(_d_6973);
    _3716 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_3716);
    _3717 = (int)*(((s1_ptr)_2)->base + 7);
    _3716 = NOVALUE;
    _2 = (int)SEQ_PTR(_d_6973);
    _3718 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_3718);
    _3719 = (int)*(((s1_ptr)_2)->base + 8);
    _3718 = NOVALUE;
    _2 = (int)SEQ_PTR(_d_6973);
    _3720 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_3720);
    _3721 = (int)*(((s1_ptr)_2)->base + 9);
    _3720 = NOVALUE;
    Ref(_3711);
    Ref(_3713);
    Ref(_3715);
    Ref(_3717);
    Ref(_3719);
    Ref(_3721);
    _3722 = _18new(_3711, _3713, _3715, _3717, _3719, _3721);
    _3711 = NOVALUE;
    _3713 = NOVALUE;
    _3715 = NOVALUE;
    _3717 = NOVALUE;
    _3719 = NOVALUE;
    _3721 = NOVALUE;
    DeRefDS(_fname_6972);
    DeRef(_d_6973);
    return _3722;
    ;
}


int _17locate_file(int _filename_7104, int _search_list_7105, int _subdir_7106)
{
    int _extra_paths_7107 = NOVALUE;
    int _this_path_7108 = NOVALUE;
    int _3858 = NOVALUE;
    int _3857 = NOVALUE;
    int _3855 = NOVALUE;
    int _3853 = NOVALUE;
    int _3851 = NOVALUE;
    int _3850 = NOVALUE;
    int _3849 = NOVALUE;
    int _3847 = NOVALUE;
    int _3846 = NOVALUE;
    int _3845 = NOVALUE;
    int _3843 = NOVALUE;
    int _3842 = NOVALUE;
    int _3841 = NOVALUE;
    int _3838 = NOVALUE;
    int _3837 = NOVALUE;
    int _3835 = NOVALUE;
    int _3833 = NOVALUE;
    int _3832 = NOVALUE;
    int _3829 = NOVALUE;
    int _3824 = NOVALUE;
    int _3820 = NOVALUE;
    int _3813 = NOVALUE;
    int _3810 = NOVALUE;
    int _3807 = NOVALUE;
    int _3806 = NOVALUE;
    int _3802 = NOVALUE;
    int _3799 = NOVALUE;
    int _3797 = NOVALUE;
    int _3793 = NOVALUE;
    int _3791 = NOVALUE;
    int _3790 = NOVALUE;
    int _3788 = NOVALUE;
    int _3787 = NOVALUE;
    int _3784 = NOVALUE;
    int _3783 = NOVALUE;
    int _3780 = NOVALUE;
    int _3778 = NOVALUE;
    int _3777 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if absolute_path(filename) then*/
    RefDS(_filename_7104);
    _3777 = _17absolute_path(_filename_7104);
    if (_3777 == 0) {
        DeRef(_3777);
        _3777 = NOVALUE;
        goto L1; // [13] 23
    }
    else {
        if (!IS_ATOM_INT(_3777) && DBL_PTR(_3777)->dbl == 0.0){
            DeRef(_3777);
            _3777 = NOVALUE;
            goto L1; // [13] 23
        }
        DeRef(_3777);
        _3777 = NOVALUE;
    }
    DeRef(_3777);
    _3777 = NOVALUE;

    /** 		return filename*/
    DeRefDS(_search_list_7105);
    DeRefDS(_subdir_7106);
    DeRef(_extra_paths_7107);
    DeRef(_this_path_7108);
    return _filename_7104;
L1: 

    /** 	if length(search_list) = 0 then*/
    if (IS_SEQUENCE(_search_list_7105)){
            _3778 = SEQ_PTR(_search_list_7105)->length;
    }
    else {
        _3778 = 1;
    }
    if (_3778 != 0)
    goto L2; // [28] 277

    /** 		search_list = append(search_list, "." & SLASH)*/
    Append(&_3780, _3143, 92);
    RefDS(_3780);
    Append(&_search_list_7105, _search_list_7105, _3780);
    DeRefDS(_3780);
    _3780 = NOVALUE;

    /** 		extra_paths = command_line()*/
    DeRef(_extra_paths_7107);
    _extra_paths_7107 = Command_Line();

    /** 		extra_paths = canonical_path(dirname(extra_paths[2]), 1)*/
    _2 = (int)SEQ_PTR(_extra_paths_7107);
    _3783 = (int)*(((s1_ptr)_2)->base + 2);
    RefDS(_3783);
    _3784 = _17dirname(_3783, 0);
    _3783 = NOVALUE;
    _0 = _extra_paths_7107;
    _extra_paths_7107 = _17canonical_path(_3784, 1, 0);
    DeRefDS(_0);
    _3784 = NOVALUE;

    /** 		search_list = append(search_list, extra_paths)*/
    Ref(_extra_paths_7107);
    Append(&_search_list_7105, _search_list_7105, _extra_paths_7107);

    /** 		ifdef UNIX then*/

    /** 			extra_paths = getenv("HOMEDRIVE") & getenv("HOMEPATH")*/
    _3787 = EGetEnv(_3426);
    _3788 = EGetEnv(_3428);
    if (IS_SEQUENCE(_3787) && IS_ATOM(_3788)) {
        Ref(_3788);
        Append(&_extra_paths_7107, _3787, _3788);
    }
    else if (IS_ATOM(_3787) && IS_SEQUENCE(_3788)) {
        Ref(_3787);
        Prepend(&_extra_paths_7107, _3788, _3787);
    }
    else {
        Concat((object_ptr)&_extra_paths_7107, _3787, _3788);
        DeRef(_3787);
        _3787 = NOVALUE;
    }
    DeRef(_3787);
    _3787 = NOVALUE;
    DeRef(_3788);
    _3788 = NOVALUE;

    /** 		if sequence(extra_paths) then*/
    _3790 = 1;
    if (_3790 == 0)
    {
        _3790 = NOVALUE;
        goto L3; // [88] 102
    }
    else{
        _3790 = NOVALUE;
    }

    /** 			search_list = append(search_list, extra_paths & SLASH)*/
    Append(&_3791, _extra_paths_7107, 92);
    RefDS(_3791);
    Append(&_search_list_7105, _search_list_7105, _3791);
    DeRefDS(_3791);
    _3791 = NOVALUE;
L3: 

    /** 		search_list = append(search_list, ".." & SLASH)*/
    Append(&_3793, _3174, 92);
    RefDS(_3793);
    Append(&_search_list_7105, _search_list_7105, _3793);
    DeRefDS(_3793);
    _3793 = NOVALUE;

    /** 		extra_paths = getenv("EUDIR")*/
    DeRef(_extra_paths_7107);
    _extra_paths_7107 = EGetEnv(_3795);

    /** 		if sequence(extra_paths) then*/
    _3797 = IS_SEQUENCE(_extra_paths_7107);
    if (_3797 == 0)
    {
        _3797 = NOVALUE;
        goto L4; // [122] 152
    }
    else{
        _3797 = NOVALUE;
    }

    /** 			search_list = append(search_list, extra_paths & SLASH & "bin" & SLASH)*/
    {
        int concat_list[4];

        concat_list[0] = 92;
        concat_list[1] = _3798;
        concat_list[2] = 92;
        concat_list[3] = _extra_paths_7107;
        Concat_N((object_ptr)&_3799, concat_list, 4);
    }
    RefDS(_3799);
    Append(&_search_list_7105, _search_list_7105, _3799);
    DeRefDS(_3799);
    _3799 = NOVALUE;

    /** 			search_list = append(search_list, extra_paths & SLASH & "docs" & SLASH)*/
    {
        int concat_list[4];

        concat_list[0] = 92;
        concat_list[1] = _3801;
        concat_list[2] = 92;
        concat_list[3] = _extra_paths_7107;
        Concat_N((object_ptr)&_3802, concat_list, 4);
    }
    RefDS(_3802);
    Append(&_search_list_7105, _search_list_7105, _3802);
    DeRefDS(_3802);
    _3802 = NOVALUE;
L4: 

    /** 		extra_paths = getenv("EUDIST")*/
    DeRef(_extra_paths_7107);
    _extra_paths_7107 = EGetEnv(_3804);

    /** 		if sequence(extra_paths) then*/
    _3806 = IS_SEQUENCE(_extra_paths_7107);
    if (_3806 == 0)
    {
        _3806 = NOVALUE;
        goto L5; // [162] 202
    }
    else{
        _3806 = NOVALUE;
    }

    /** 			search_list = append(search_list, extra_paths & SLASH)*/
    if (IS_SEQUENCE(_extra_paths_7107) && IS_ATOM(92)) {
        Append(&_3807, _extra_paths_7107, 92);
    }
    else if (IS_ATOM(_extra_paths_7107) && IS_SEQUENCE(92)) {
    }
    else {
        Concat((object_ptr)&_3807, _extra_paths_7107, 92);
    }
    RefDS(_3807);
    Append(&_search_list_7105, _search_list_7105, _3807);
    DeRefDS(_3807);
    _3807 = NOVALUE;

    /** 			search_list = append(search_list, extra_paths & SLASH & "etc" & SLASH)*/
    {
        int concat_list[4];

        concat_list[0] = 92;
        concat_list[1] = _3809;
        concat_list[2] = 92;
        concat_list[3] = _extra_paths_7107;
        Concat_N((object_ptr)&_3810, concat_list, 4);
    }
    RefDS(_3810);
    Append(&_search_list_7105, _search_list_7105, _3810);
    DeRefDS(_3810);
    _3810 = NOVALUE;

    /** 			search_list = append(search_list, extra_paths & SLASH & "data" & SLASH)*/
    {
        int concat_list[4];

        concat_list[0] = 92;
        concat_list[1] = _3812;
        concat_list[2] = 92;
        concat_list[3] = _extra_paths_7107;
        Concat_N((object_ptr)&_3813, concat_list, 4);
    }
    RefDS(_3813);
    Append(&_search_list_7105, _search_list_7105, _3813);
    DeRefDS(_3813);
    _3813 = NOVALUE;
L5: 

    /** 		ifdef UNIX then*/

    /** 		search_list &= include_paths(1)*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_3819);
    *((int *)(_2+4)) = _3819;
    RefDS(_3818);
    *((int *)(_2+8)) = _3818;
    RefDS(_3817);
    *((int *)(_2+12)) = _3817;
    _3820 = MAKE_SEQ(_1);
    Concat((object_ptr)&_search_list_7105, _search_list_7105, _3820);
    DeRefDS(_3820);
    _3820 = NOVALUE;

    /** 		extra_paths = getenv("USERPATH")*/
    DeRef(_extra_paths_7107);
    _extra_paths_7107 = EGetEnv(_3822);

    /** 		if sequence(extra_paths) then*/
    _3824 = IS_SEQUENCE(_extra_paths_7107);
    if (_3824 == 0)
    {
        _3824 = NOVALUE;
        goto L6; // [226] 245
    }
    else{
        _3824 = NOVALUE;
    }

    /** 			extra_paths = stdseq:split(extra_paths, PATHSEP)*/
    Ref(_extra_paths_7107);
    _0 = _extra_paths_7107;
    _extra_paths_7107 = _23split(_extra_paths_7107, 59, 0, 0);
    DeRefi(_0);

    /** 			search_list &= extra_paths*/
    if (IS_SEQUENCE(_search_list_7105) && IS_ATOM(_extra_paths_7107)) {
        Ref(_extra_paths_7107);
        Append(&_search_list_7105, _search_list_7105, _extra_paths_7107);
    }
    else if (IS_ATOM(_search_list_7105) && IS_SEQUENCE(_extra_paths_7107)) {
    }
    else {
        Concat((object_ptr)&_search_list_7105, _search_list_7105, _extra_paths_7107);
    }
L6: 

    /** 		extra_paths = getenv("PATH")*/
    DeRef(_extra_paths_7107);
    _extra_paths_7107 = EGetEnv(_3827);

    /** 		if sequence(extra_paths) then*/
    _3829 = IS_SEQUENCE(_extra_paths_7107);
    if (_3829 == 0)
    {
        _3829 = NOVALUE;
        goto L7; // [255] 302
    }
    else{
        _3829 = NOVALUE;
    }

    /** 			extra_paths = stdseq:split(extra_paths, PATHSEP)*/
    Ref(_extra_paths_7107);
    _0 = _extra_paths_7107;
    _extra_paths_7107 = _23split(_extra_paths_7107, 59, 0, 0);
    DeRefi(_0);

    /** 			search_list &= extra_paths*/
    if (IS_SEQUENCE(_search_list_7105) && IS_ATOM(_extra_paths_7107)) {
        Ref(_extra_paths_7107);
        Append(&_search_list_7105, _search_list_7105, _extra_paths_7107);
    }
    else if (IS_ATOM(_search_list_7105) && IS_SEQUENCE(_extra_paths_7107)) {
    }
    else {
        Concat((object_ptr)&_search_list_7105, _search_list_7105, _extra_paths_7107);
    }
    goto L7; // [274] 302
L2: 

    /** 		if integer(search_list[1]) then*/
    _2 = (int)SEQ_PTR(_search_list_7105);
    _3832 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_3832))
    _3833 = 1;
    else if (IS_ATOM_DBL(_3832))
    _3833 = IS_ATOM_INT(DoubleToInt(_3832));
    else
    _3833 = 0;
    _3832 = NOVALUE;
    if (_3833 == 0)
    {
        _3833 = NOVALUE;
        goto L8; // [286] 301
    }
    else{
        _3833 = NOVALUE;
    }

    /** 			search_list = stdseq:split(search_list, PATHSEP)*/
    RefDS(_search_list_7105);
    _0 = _search_list_7105;
    _search_list_7105 = _23split(_search_list_7105, 59, 0, 0);
    DeRefDS(_0);
L8: 
L7: 

    /** 	if length(subdir) > 0 then*/
    if (IS_SEQUENCE(_subdir_7106)){
            _3835 = SEQ_PTR(_subdir_7106)->length;
    }
    else {
        _3835 = 1;
    }
    if (_3835 <= 0)
    goto L9; // [307] 332

    /** 		if subdir[$] != SLASH then*/
    if (IS_SEQUENCE(_subdir_7106)){
            _3837 = SEQ_PTR(_subdir_7106)->length;
    }
    else {
        _3837 = 1;
    }
    _2 = (int)SEQ_PTR(_subdir_7106);
    _3838 = (int)*(((s1_ptr)_2)->base + _3837);
    if (binary_op_a(EQUALS, _3838, 92)){
        _3838 = NOVALUE;
        goto LA; // [320] 331
    }
    _3838 = NOVALUE;

    /** 			subdir &= SLASH*/
    Append(&_subdir_7106, _subdir_7106, 92);
LA: 
L9: 

    /** 	for i = 1 to length(search_list) do*/
    if (IS_SEQUENCE(_search_list_7105)){
            _3841 = SEQ_PTR(_search_list_7105)->length;
    }
    else {
        _3841 = 1;
    }
    {
        int _i_7185;
        _i_7185 = 1;
LB: 
        if (_i_7185 > _3841){
            goto LC; // [337] 460
        }

        /** 		if length(search_list[i]) = 0 then*/
        _2 = (int)SEQ_PTR(_search_list_7105);
        _3842 = (int)*(((s1_ptr)_2)->base + _i_7185);
        if (IS_SEQUENCE(_3842)){
                _3843 = SEQ_PTR(_3842)->length;
        }
        else {
            _3843 = 1;
        }
        _3842 = NOVALUE;
        if (_3843 != 0)
        goto LD; // [353] 362

        /** 			continue*/
        goto LE; // [359] 455
LD: 

        /** 		if search_list[i][$] != SLASH then*/
        _2 = (int)SEQ_PTR(_search_list_7105);
        _3845 = (int)*(((s1_ptr)_2)->base + _i_7185);
        if (IS_SEQUENCE(_3845)){
                _3846 = SEQ_PTR(_3845)->length;
        }
        else {
            _3846 = 1;
        }
        _2 = (int)SEQ_PTR(_3845);
        _3847 = (int)*(((s1_ptr)_2)->base + _3846);
        _3845 = NOVALUE;
        if (binary_op_a(EQUALS, _3847, 92)){
            _3847 = NOVALUE;
            goto LF; // [375] 394
        }
        _3847 = NOVALUE;

        /** 			search_list[i] &= SLASH*/
        _2 = (int)SEQ_PTR(_search_list_7105);
        _3849 = (int)*(((s1_ptr)_2)->base + _i_7185);
        if (IS_SEQUENCE(_3849) && IS_ATOM(92)) {
            Append(&_3850, _3849, 92);
        }
        else if (IS_ATOM(_3849) && IS_SEQUENCE(92)) {
        }
        else {
            Concat((object_ptr)&_3850, _3849, 92);
            _3849 = NOVALUE;
        }
        _3849 = NOVALUE;
        _2 = (int)SEQ_PTR(_search_list_7105);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _search_list_7105 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_7185);
        _1 = *(int *)_2;
        *(int *)_2 = _3850;
        if( _1 != _3850 ){
            DeRef(_1);
        }
        _3850 = NOVALUE;
LF: 

        /** 		if length(subdir) > 0 then*/
        if (IS_SEQUENCE(_subdir_7106)){
                _3851 = SEQ_PTR(_subdir_7106)->length;
        }
        else {
            _3851 = 1;
        }
        if (_3851 <= 0)
        goto L10; // [399] 418

        /** 			this_path = search_list[i] & subdir & filename*/
        _2 = (int)SEQ_PTR(_search_list_7105);
        _3853 = (int)*(((s1_ptr)_2)->base + _i_7185);
        {
            int concat_list[3];

            concat_list[0] = _filename_7104;
            concat_list[1] = _subdir_7106;
            concat_list[2] = _3853;
            Concat_N((object_ptr)&_this_path_7108, concat_list, 3);
        }
        _3853 = NOVALUE;
        goto L11; // [415] 429
L10: 

        /** 			this_path = search_list[i] & filename*/
        _2 = (int)SEQ_PTR(_search_list_7105);
        _3855 = (int)*(((s1_ptr)_2)->base + _i_7185);
        if (IS_SEQUENCE(_3855) && IS_ATOM(_filename_7104)) {
        }
        else if (IS_ATOM(_3855) && IS_SEQUENCE(_filename_7104)) {
            Ref(_3855);
            Prepend(&_this_path_7108, _filename_7104, _3855);
        }
        else {
            Concat((object_ptr)&_this_path_7108, _3855, _filename_7104);
            _3855 = NOVALUE;
        }
        _3855 = NOVALUE;
L11: 

        /** 		if file_exists(this_path) then*/
        RefDS(_this_path_7108);
        _3857 = _17file_exists(_this_path_7108);
        if (_3857 == 0) {
            DeRef(_3857);
            _3857 = NOVALUE;
            goto L12; // [437] 453
        }
        else {
            if (!IS_ATOM_INT(_3857) && DBL_PTR(_3857)->dbl == 0.0){
                DeRef(_3857);
                _3857 = NOVALUE;
                goto L12; // [437] 453
            }
            DeRef(_3857);
            _3857 = NOVALUE;
        }
        DeRef(_3857);
        _3857 = NOVALUE;

        /** 			return canonical_path(this_path)*/
        RefDS(_this_path_7108);
        _3858 = _17canonical_path(_this_path_7108, 0, 0);
        DeRefDS(_filename_7104);
        DeRefDS(_search_list_7105);
        DeRefDS(_subdir_7106);
        DeRef(_extra_paths_7107);
        DeRefDS(_this_path_7108);
        _3842 = NOVALUE;
        return _3858;
L12: 

        /** 	end for*/
LE: 
        _i_7185 = _i_7185 + 1;
        goto LB; // [455] 344
LC: 
        ;
    }

    /** 	return filename*/
    DeRefDS(_search_list_7105);
    DeRefDS(_subdir_7106);
    DeRef(_extra_paths_7107);
    DeRef(_this_path_7108);
    _3842 = NOVALUE;
    DeRef(_3858);
    _3858 = NOVALUE;
    return _filename_7104;
    ;
}


int _17count_files(int _orig_path_7263, int _dir_info_7264, int _inst_7265)
{
    int _pos_7266 = NOVALUE;
    int _ext_7267 = NOVALUE;
    int _fileext_inlined_fileext_at_223_7310 = NOVALUE;
    int _data_inlined_fileext_at_223_7309 = NOVALUE;
    int _path_inlined_fileext_at_220_7308 = NOVALUE;
    int _3955 = NOVALUE;
    int _3954 = NOVALUE;
    int _3953 = NOVALUE;
    int _3951 = NOVALUE;
    int _3950 = NOVALUE;
    int _3949 = NOVALUE;
    int _3948 = NOVALUE;
    int _3946 = NOVALUE;
    int _3945 = NOVALUE;
    int _3943 = NOVALUE;
    int _3942 = NOVALUE;
    int _3941 = NOVALUE;
    int _3940 = NOVALUE;
    int _3939 = NOVALUE;
    int _3938 = NOVALUE;
    int _3937 = NOVALUE;
    int _3935 = NOVALUE;
    int _3934 = NOVALUE;
    int _3932 = NOVALUE;
    int _3931 = NOVALUE;
    int _3930 = NOVALUE;
    int _3929 = NOVALUE;
    int _3928 = NOVALUE;
    int _3927 = NOVALUE;
    int _3926 = NOVALUE;
    int _3925 = NOVALUE;
    int _3924 = NOVALUE;
    int _3923 = NOVALUE;
    int _3922 = NOVALUE;
    int _3921 = NOVALUE;
    int _3920 = NOVALUE;
    int _3919 = NOVALUE;
    int _3917 = NOVALUE;
    int _3916 = NOVALUE;
    int _3915 = NOVALUE;
    int _3914 = NOVALUE;
    int _3912 = NOVALUE;
    int _3911 = NOVALUE;
    int _3910 = NOVALUE;
    int _3909 = NOVALUE;
    int _3908 = NOVALUE;
    int _3907 = NOVALUE;
    int _3906 = NOVALUE;
    int _3904 = NOVALUE;
    int _3903 = NOVALUE;
    int _3902 = NOVALUE;
    int _3901 = NOVALUE;
    int _3900 = NOVALUE;
    int _3899 = NOVALUE;
    int _3896 = NOVALUE;
    int _3895 = NOVALUE;
    int _3894 = NOVALUE;
    int _3893 = NOVALUE;
    int _3892 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	integer pos = 0*/
    _pos_7266 = 0;

    /** 	orig_path = orig_path*/
    RefDS(_orig_path_7263);
    DeRefDS(_orig_path_7263);
    _orig_path_7263 = _orig_path_7263;

    /** 	if equal(dir_info[D_NAME], ".") then*/
    _2 = (int)SEQ_PTR(_dir_info_7264);
    _3892 = (int)*(((s1_ptr)_2)->base + 1);
    if (_3892 == _3143)
    _3893 = 1;
    else if (IS_ATOM_INT(_3892) && IS_ATOM_INT(_3143))
    _3893 = 0;
    else
    _3893 = (compare(_3892, _3143) == 0);
    _3892 = NOVALUE;
    if (_3893 == 0)
    {
        _3893 = NOVALUE;
        goto L1; // [29] 39
    }
    else{
        _3893 = NOVALUE;
    }

    /** 		return 0*/
    DeRefDS(_orig_path_7263);
    DeRefDS(_dir_info_7264);
    DeRefDS(_inst_7265);
    DeRef(_ext_7267);
    return 0;
L1: 

    /** 	if equal(dir_info[D_NAME], "..") then*/
    _2 = (int)SEQ_PTR(_dir_info_7264);
    _3894 = (int)*(((s1_ptr)_2)->base + 1);
    if (_3894 == _3174)
    _3895 = 1;
    else if (IS_ATOM_INT(_3894) && IS_ATOM_INT(_3174))
    _3895 = 0;
    else
    _3895 = (compare(_3894, _3174) == 0);
    _3894 = NOVALUE;
    if (_3895 == 0)
    {
        _3895 = NOVALUE;
        goto L2; // [49] 59
    }
    else{
        _3895 = NOVALUE;
    }

    /** 		return 0*/
    DeRefDS(_orig_path_7263);
    DeRefDS(_dir_info_7264);
    DeRefDS(_inst_7265);
    DeRef(_ext_7267);
    return 0;
L2: 

    /** 	if inst[1] = 0 then -- count all is false*/
    _2 = (int)SEQ_PTR(_inst_7265);
    _3896 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _3896, 0)){
        _3896 = NOVALUE;
        goto L3; // [65] 112
    }
    _3896 = NOVALUE;

    /** 		if find('h', dir_info[D_ATTRIBUTES]) then*/
    _2 = (int)SEQ_PTR(_dir_info_7264);
    _3899 = (int)*(((s1_ptr)_2)->base + 2);
    _3900 = find_from(104, _3899, 1);
    _3899 = NOVALUE;
    if (_3900 == 0)
    {
        _3900 = NOVALUE;
        goto L4; // [80] 90
    }
    else{
        _3900 = NOVALUE;
    }

    /** 			return 0*/
    DeRefDS(_orig_path_7263);
    DeRefDS(_dir_info_7264);
    DeRefDS(_inst_7265);
    DeRef(_ext_7267);
    return 0;
L4: 

    /** 		if find('s', dir_info[D_ATTRIBUTES]) then*/
    _2 = (int)SEQ_PTR(_dir_info_7264);
    _3901 = (int)*(((s1_ptr)_2)->base + 2);
    _3902 = find_from(115, _3901, 1);
    _3901 = NOVALUE;
    if (_3902 == 0)
    {
        _3902 = NOVALUE;
        goto L5; // [101] 111
    }
    else{
        _3902 = NOVALUE;
    }

    /** 			return 0*/
    DeRefDS(_orig_path_7263);
    DeRefDS(_dir_info_7264);
    DeRefDS(_inst_7265);
    DeRef(_ext_7267);
    return 0;
L5: 
L3: 

    /** 	file_counters[inst[2]][COUNT_SIZE] += dir_info[D_SIZE]*/
    _2 = (int)SEQ_PTR(_inst_7265);
    _3903 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_17file_counters_7260);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _17file_counters_7260 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_3903))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_3903)->dbl));
    else
    _3 = (int)(_3903 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_dir_info_7264);
    _3906 = (int)*(((s1_ptr)_2)->base + 3);
    _2 = (int)SEQ_PTR(*(int *)_3);
    _3907 = (int)*(((s1_ptr)_2)->base + 3);
    _3904 = NOVALUE;
    if (IS_ATOM_INT(_3907) && IS_ATOM_INT(_3906)) {
        _3908 = _3907 + _3906;
        if ((long)((unsigned long)_3908 + (unsigned long)HIGH_BITS) >= 0) 
        _3908 = NewDouble((double)_3908);
    }
    else {
        _3908 = binary_op(PLUS, _3907, _3906);
    }
    _3907 = NOVALUE;
    _3906 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = _3908;
    if( _1 != _3908 ){
        DeRef(_1);
    }
    _3908 = NOVALUE;
    _3904 = NOVALUE;

    /** 	if find('d', dir_info[D_ATTRIBUTES]) then*/
    _2 = (int)SEQ_PTR(_dir_info_7264);
    _3909 = (int)*(((s1_ptr)_2)->base + 2);
    _3910 = find_from(100, _3909, 1);
    _3909 = NOVALUE;
    if (_3910 == 0)
    {
        _3910 = NOVALUE;
        goto L6; // [152] 183
    }
    else{
        _3910 = NOVALUE;
    }

    /** 		file_counters[inst[2]][COUNT_DIRS] += 1*/
    _2 = (int)SEQ_PTR(_inst_7265);
    _3911 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_17file_counters_7260);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _17file_counters_7260 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_3911))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_3911)->dbl));
    else
    _3 = (int)(_3911 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    _3914 = (int)*(((s1_ptr)_2)->base + 1);
    _3912 = NOVALUE;
    if (IS_ATOM_INT(_3914)) {
        _3915 = _3914 + 1;
        if (_3915 > MAXINT){
            _3915 = NewDouble((double)_3915);
        }
    }
    else
    _3915 = binary_op(PLUS, 1, _3914);
    _3914 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _3915;
    if( _1 != _3915 ){
        DeRef(_1);
    }
    _3915 = NOVALUE;
    _3912 = NOVALUE;
    goto L7; // [180] 464
L6: 

    /** 		file_counters[inst[2]][COUNT_FILES] += 1*/
    _2 = (int)SEQ_PTR(_inst_7265);
    _3916 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_17file_counters_7260);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _17file_counters_7260 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_3916))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_3916)->dbl));
    else
    _3 = (int)(_3916 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    _3919 = (int)*(((s1_ptr)_2)->base + 2);
    _3917 = NOVALUE;
    if (IS_ATOM_INT(_3919)) {
        _3920 = _3919 + 1;
        if (_3920 > MAXINT){
            _3920 = NewDouble((double)_3920);
        }
    }
    else
    _3920 = binary_op(PLUS, 1, _3919);
    _3919 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _3920;
    if( _1 != _3920 ){
        DeRef(_1);
    }
    _3920 = NOVALUE;
    _3917 = NOVALUE;

    /** 		ifdef not UNIX then*/

    /** 			ext = fileext(lower(dir_info[D_NAME]))*/
    _2 = (int)SEQ_PTR(_dir_info_7264);
    _3921 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_3921);
    _3922 = _14lower(_3921);
    _3921 = NOVALUE;
    DeRef(_path_inlined_fileext_at_220_7308);
    _path_inlined_fileext_at_220_7308 = _3922;
    _3922 = NOVALUE;

    /** 	data = pathinfo(path)*/
    Ref(_path_inlined_fileext_at_220_7308);
    _0 = _data_inlined_fileext_at_223_7309;
    _data_inlined_fileext_at_223_7309 = _17pathinfo(_path_inlined_fileext_at_220_7308, 0);
    DeRef(_0);

    /** 	return data[4]*/
    DeRef(_ext_7267);
    _2 = (int)SEQ_PTR(_data_inlined_fileext_at_223_7309);
    _ext_7267 = (int)*(((s1_ptr)_2)->base + 4);
    Ref(_ext_7267);
    DeRef(_path_inlined_fileext_at_220_7308);
    _path_inlined_fileext_at_220_7308 = NOVALUE;
    DeRef(_data_inlined_fileext_at_223_7309);
    _data_inlined_fileext_at_223_7309 = NOVALUE;

    /** 		pos = 0*/
    _pos_7266 = 0;

    /** 		for i = 1 to length(file_counters[inst[2]][COUNT_TYPES]) do*/
    _2 = (int)SEQ_PTR(_inst_7265);
    _3923 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_17file_counters_7260);
    if (!IS_ATOM_INT(_3923)){
        _3924 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_3923)->dbl));
    }
    else{
        _3924 = (int)*(((s1_ptr)_2)->base + _3923);
    }
    _2 = (int)SEQ_PTR(_3924);
    _3925 = (int)*(((s1_ptr)_2)->base + 4);
    _3924 = NOVALUE;
    if (IS_SEQUENCE(_3925)){
            _3926 = SEQ_PTR(_3925)->length;
    }
    else {
        _3926 = 1;
    }
    _3925 = NOVALUE;
    {
        int _i_7312;
        _i_7312 = 1;
L8: 
        if (_i_7312 > _3926){
            goto L9; // [269] 326
        }

        /** 			if equal(file_counters[inst[2]][COUNT_TYPES][i][EXT_NAME], ext) then*/
        _2 = (int)SEQ_PTR(_inst_7265);
        _3927 = (int)*(((s1_ptr)_2)->base + 2);
        _2 = (int)SEQ_PTR(_17file_counters_7260);
        if (!IS_ATOM_INT(_3927)){
            _3928 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_3927)->dbl));
        }
        else{
            _3928 = (int)*(((s1_ptr)_2)->base + _3927);
        }
        _2 = (int)SEQ_PTR(_3928);
        _3929 = (int)*(((s1_ptr)_2)->base + 4);
        _3928 = NOVALUE;
        _2 = (int)SEQ_PTR(_3929);
        _3930 = (int)*(((s1_ptr)_2)->base + _i_7312);
        _3929 = NOVALUE;
        _2 = (int)SEQ_PTR(_3930);
        _3931 = (int)*(((s1_ptr)_2)->base + 1);
        _3930 = NOVALUE;
        if (_3931 == _ext_7267)
        _3932 = 1;
        else if (IS_ATOM_INT(_3931) && IS_ATOM_INT(_ext_7267))
        _3932 = 0;
        else
        _3932 = (compare(_3931, _ext_7267) == 0);
        _3931 = NOVALUE;
        if (_3932 == 0)
        {
            _3932 = NOVALUE;
            goto LA; // [306] 319
        }
        else{
            _3932 = NOVALUE;
        }

        /** 				pos = i*/
        _pos_7266 = _i_7312;

        /** 				exit*/
        goto L9; // [316] 326
LA: 

        /** 		end for*/
        _i_7312 = _i_7312 + 1;
        goto L8; // [321] 276
L9: 
        ;
    }

    /** 		if pos = 0 then*/
    if (_pos_7266 != 0)
    goto LB; // [328] 389

    /** 			file_counters[inst[2]][COUNT_TYPES] &= {{ext, 0, 0}}*/
    _2 = (int)SEQ_PTR(_inst_7265);
    _3934 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_17file_counters_7260);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _17file_counters_7260 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_3934))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_3934)->dbl));
    else
    _3 = (int)(_3934 + ((s1_ptr)_2)->base);
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_ext_7267);
    *((int *)(_2+4)) = _ext_7267;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = 0;
    _3937 = MAKE_SEQ(_1);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _3937;
    _3938 = MAKE_SEQ(_1);
    _3937 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    _3939 = (int)*(((s1_ptr)_2)->base + 4);
    _3935 = NOVALUE;
    if (IS_SEQUENCE(_3939) && IS_ATOM(_3938)) {
    }
    else if (IS_ATOM(_3939) && IS_SEQUENCE(_3938)) {
        Ref(_3939);
        Prepend(&_3940, _3938, _3939);
    }
    else {
        Concat((object_ptr)&_3940, _3939, _3938);
        _3939 = NOVALUE;
    }
    _3939 = NOVALUE;
    DeRefDS(_3938);
    _3938 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = _3940;
    if( _1 != _3940 ){
        DeRef(_1);
    }
    _3940 = NOVALUE;
    _3935 = NOVALUE;

    /** 			pos = length(file_counters[inst[2]][COUNT_TYPES])*/
    _2 = (int)SEQ_PTR(_inst_7265);
    _3941 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_17file_counters_7260);
    if (!IS_ATOM_INT(_3941)){
        _3942 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_3941)->dbl));
    }
    else{
        _3942 = (int)*(((s1_ptr)_2)->base + _3941);
    }
    _2 = (int)SEQ_PTR(_3942);
    _3943 = (int)*(((s1_ptr)_2)->base + 4);
    _3942 = NOVALUE;
    if (IS_SEQUENCE(_3943)){
            _pos_7266 = SEQ_PTR(_3943)->length;
    }
    else {
        _pos_7266 = 1;
    }
    _3943 = NOVALUE;
LB: 

    /** 		file_counters[inst[2]][COUNT_TYPES][pos][EXT_COUNT] += 1*/
    _2 = (int)SEQ_PTR(_inst_7265);
    _3945 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_17file_counters_7260);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _17file_counters_7260 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_3945))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_3945)->dbl));
    else
    _3 = (int)(_3945 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(object_ptr)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(object_ptr)_3 = MAKE_SEQ(_2);
    }
    _3 = (int)(4 + ((s1_ptr)_2)->base);
    _3946 = NOVALUE;
    _2 = (int)SEQ_PTR(*(object_ptr)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(object_ptr)_3 = MAKE_SEQ(_2);
    }
    _3 = (int)(_pos_7266 + ((s1_ptr)_2)->base);
    _3946 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    _3948 = (int)*(((s1_ptr)_2)->base + 2);
    _3946 = NOVALUE;
    if (IS_ATOM_INT(_3948)) {
        _3949 = _3948 + 1;
        if (_3949 > MAXINT){
            _3949 = NewDouble((double)_3949);
        }
    }
    else
    _3949 = binary_op(PLUS, 1, _3948);
    _3948 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _3949;
    if( _1 != _3949 ){
        DeRef(_1);
    }
    _3949 = NOVALUE;
    _3946 = NOVALUE;

    /** 		file_counters[inst[2]][COUNT_TYPES][pos][EXT_SIZE] += dir_info[D_SIZE]*/
    _2 = (int)SEQ_PTR(_inst_7265);
    _3950 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_17file_counters_7260);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _17file_counters_7260 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_3950))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_3950)->dbl));
    else
    _3 = (int)(_3950 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(object_ptr)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(object_ptr)_3 = MAKE_SEQ(_2);
    }
    _3 = (int)(4 + ((s1_ptr)_2)->base);
    _3951 = NOVALUE;
    _2 = (int)SEQ_PTR(*(object_ptr)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(object_ptr)_3 = MAKE_SEQ(_2);
    }
    _3 = (int)(_pos_7266 + ((s1_ptr)_2)->base);
    _3951 = NOVALUE;
    _2 = (int)SEQ_PTR(_dir_info_7264);
    _3953 = (int)*(((s1_ptr)_2)->base + 3);
    _2 = (int)SEQ_PTR(*(int *)_3);
    _3954 = (int)*(((s1_ptr)_2)->base + 3);
    _3951 = NOVALUE;
    if (IS_ATOM_INT(_3954) && IS_ATOM_INT(_3953)) {
        _3955 = _3954 + _3953;
        if ((long)((unsigned long)_3955 + (unsigned long)HIGH_BITS) >= 0) 
        _3955 = NewDouble((double)_3955);
    }
    else {
        _3955 = binary_op(PLUS, _3954, _3953);
    }
    _3954 = NOVALUE;
    _3953 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = _3955;
    if( _1 != _3955 ){
        DeRef(_1);
    }
    _3955 = NOVALUE;
    _3951 = NOVALUE;
L7: 

    /** 	return 0*/
    DeRefDS(_orig_path_7263);
    DeRefDS(_dir_info_7264);
    DeRefDS(_inst_7265);
    DeRef(_ext_7267);
    _3903 = NOVALUE;
    _3911 = NOVALUE;
    _3916 = NOVALUE;
    _3923 = NOVALUE;
    _3925 = NOVALUE;
    _3927 = NOVALUE;
    _3934 = NOVALUE;
    _3941 = NOVALUE;
    _3943 = NOVALUE;
    _3945 = NOVALUE;
    _3950 = NOVALUE;
    return 0;
    ;
}


int _17temp_file(int _temp_location_7370, int _temp_prefix_7371, int _temp_extn_7372, int _reserve_temp_7374)
{
    int _randname_7375 = NOVALUE;
    int _envtmp_7379 = NOVALUE;
    int _tdir_7398 = NOVALUE;
    int _5696 = NOVALUE;
    int _4007 = NOVALUE;
    int _4005 = NOVALUE;
    int _4003 = NOVALUE;
    int _4001 = NOVALUE;
    int _4000 = NOVALUE;
    int _3999 = NOVALUE;
    int _3995 = NOVALUE;
    int _3994 = NOVALUE;
    int _3993 = NOVALUE;
    int _3992 = NOVALUE;
    int _3989 = NOVALUE;
    int _3988 = NOVALUE;
    int _3987 = NOVALUE;
    int _3982 = NOVALUE;
    int _3979 = NOVALUE;
    int _3976 = NOVALUE;
    int _3972 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if length(temp_location) = 0 then*/
    if (IS_SEQUENCE(_temp_location_7370)){
            _3972 = SEQ_PTR(_temp_location_7370)->length;
    }
    else {
        _3972 = 1;
    }
    if (_3972 != 0)
    goto L1; // [14] 67

    /** 		object envtmp*/

    /** 		envtmp = getenv("TEMP")*/
    DeRefi(_envtmp_7379);
    _envtmp_7379 = EGetEnv(_3974);

    /** 		if atom(envtmp) then*/
    _3976 = IS_ATOM(_envtmp_7379);
    if (_3976 == 0)
    {
        _3976 = NOVALUE;
        goto L2; // [30] 39
    }
    else{
        _3976 = NOVALUE;
    }

    /** 			envtmp = getenv("TMP")*/
    DeRefi(_envtmp_7379);
    _envtmp_7379 = EGetEnv(_3977);
L2: 

    /** 		ifdef WINDOWS then			*/

    /** 			if atom(envtmp) then*/
    _3979 = IS_ATOM(_envtmp_7379);
    if (_3979 == 0)
    {
        _3979 = NOVALUE;
        goto L3; // [46] 55
    }
    else{
        _3979 = NOVALUE;
    }

    /** 				envtmp = "C:\\temp\\"*/
    RefDS(_3980);
    DeRefi(_envtmp_7379);
    _envtmp_7379 = _3980;
L3: 

    /** 		temp_location = envtmp*/
    Ref(_envtmp_7379);
    DeRefDS(_temp_location_7370);
    _temp_location_7370 = _envtmp_7379;
    DeRefi(_envtmp_7379);
    _envtmp_7379 = NOVALUE;
    goto L4; // [64] 161
L1: 

    /** 		switch file_type(temp_location) do*/
    RefDS(_temp_location_7370);
    _3982 = _17file_type(_temp_location_7370);
    if (IS_SEQUENCE(_3982) ){
        goto L5; // [73] 150
    }
    if(!IS_ATOM_INT(_3982)){
        if( (DBL_PTR(_3982)->dbl != (double) ((int) DBL_PTR(_3982)->dbl) ) ){
            goto L5; // [73] 150
        }
        _0 = (int) DBL_PTR(_3982)->dbl;
    }
    else {
        _0 = _3982;
    };
    DeRef(_3982);
    _3982 = NOVALUE;
    switch ( _0 ){ 

        /** 			case FILETYPE_FILE then*/
        case 1:

        /** 				temp_location = dirname(temp_location, 1)*/
        RefDS(_temp_location_7370);
        _0 = _temp_location_7370;
        _temp_location_7370 = _17dirname(_temp_location_7370, 1);
        DeRefDS(_0);
        goto L6; // [91] 160

        /** 			case FILETYPE_DIRECTORY then*/
        case 2:

        /** 				temp_location = temp_location*/
        RefDS(_temp_location_7370);
        DeRefDS(_temp_location_7370);
        _temp_location_7370 = _temp_location_7370;
        goto L6; // [104] 160

        /** 			case FILETYPE_NOT_FOUND then*/
        case 0:

        /** 				object tdir = dirname(temp_location, 1)*/
        RefDS(_temp_location_7370);
        _0 = _tdir_7398;
        _tdir_7398 = _17dirname(_temp_location_7370, 1);
        DeRef(_0);

        /** 				if file_exists(tdir) then*/
        Ref(_tdir_7398);
        _3987 = _17file_exists(_tdir_7398);
        if (_3987 == 0) {
            DeRef(_3987);
            _3987 = NOVALUE;
            goto L7; // [123] 136
        }
        else {
            if (!IS_ATOM_INT(_3987) && DBL_PTR(_3987)->dbl == 0.0){
                DeRef(_3987);
                _3987 = NOVALUE;
                goto L7; // [123] 136
            }
            DeRef(_3987);
            _3987 = NOVALUE;
        }
        DeRef(_3987);
        _3987 = NOVALUE;

        /** 					temp_location = tdir*/
        Ref(_tdir_7398);
        DeRefDS(_temp_location_7370);
        _temp_location_7370 = _tdir_7398;
        goto L8; // [133] 144
L7: 

        /** 					temp_location = "."*/
        RefDS(_3143);
        DeRefDS(_temp_location_7370);
        _temp_location_7370 = _3143;
L8: 
        DeRef(_tdir_7398);
        _tdir_7398 = NOVALUE;
        goto L6; // [146] 160

        /** 			case else*/
        default:
L5: 

        /** 				temp_location = "."*/
        RefDS(_3143);
        DeRefDS(_temp_location_7370);
        _temp_location_7370 = _3143;
    ;}L6: 
L4: 

    /** 	if temp_location[$] != SLASH then*/
    if (IS_SEQUENCE(_temp_location_7370)){
            _3988 = SEQ_PTR(_temp_location_7370)->length;
    }
    else {
        _3988 = 1;
    }
    _2 = (int)SEQ_PTR(_temp_location_7370);
    _3989 = (int)*(((s1_ptr)_2)->base + _3988);
    if (binary_op_a(EQUALS, _3989, 92)){
        _3989 = NOVALUE;
        goto L9; // [170] 181
    }
    _3989 = NOVALUE;

    /** 		temp_location &= SLASH*/
    Append(&_temp_location_7370, _temp_location_7370, 92);
L9: 

    /** 	if length(temp_extn) and temp_extn[1] != '.' then*/
    if (IS_SEQUENCE(_temp_extn_7372)){
            _3992 = SEQ_PTR(_temp_extn_7372)->length;
    }
    else {
        _3992 = 1;
    }
    if (_3992 == 0) {
        goto LA; // [186] 209
    }
    _2 = (int)SEQ_PTR(_temp_extn_7372);
    _3994 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_3994)) {
        _3995 = (_3994 != 46);
    }
    else {
        _3995 = binary_op(NOTEQ, _3994, 46);
    }
    _3994 = NOVALUE;
    if (_3995 == 0) {
        DeRef(_3995);
        _3995 = NOVALUE;
        goto LA; // [199] 209
    }
    else {
        if (!IS_ATOM_INT(_3995) && DBL_PTR(_3995)->dbl == 0.0){
            DeRef(_3995);
            _3995 = NOVALUE;
            goto LA; // [199] 209
        }
        DeRef(_3995);
        _3995 = NOVALUE;
    }
    DeRef(_3995);
    _3995 = NOVALUE;

    /** 		temp_extn = '.' & temp_extn*/
    Prepend(&_temp_extn_7372, _temp_extn_7372, 46);
LA: 

    /** 	while 1 do*/
LB: 

    /** 		randname = sprintf("%s%s%06d%s", {temp_location, temp_prefix, rand(1_000_000) - 1, temp_extn})*/
    _3999 = good_rand() % ((unsigned)1000000) + 1;
    _4000 = _3999 - 1;
    _3999 = NOVALUE;
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_temp_location_7370);
    *((int *)(_2+4)) = _temp_location_7370;
    RefDS(_temp_prefix_7371);
    *((int *)(_2+8)) = _temp_prefix_7371;
    *((int *)(_2+12)) = _4000;
    RefDS(_temp_extn_7372);
    *((int *)(_2+16)) = _temp_extn_7372;
    _4001 = MAKE_SEQ(_1);
    _4000 = NOVALUE;
    DeRefi(_randname_7375);
    _randname_7375 = EPrintf(-9999999, _3997, _4001);
    DeRefDS(_4001);
    _4001 = NOVALUE;

    /** 		if not file_exists( randname ) then*/
    RefDS(_randname_7375);
    _4003 = _17file_exists(_randname_7375);
    if (IS_ATOM_INT(_4003)) {
        if (_4003 != 0){
            DeRef(_4003);
            _4003 = NOVALUE;
            goto LB; // [240] 214
        }
    }
    else {
        if (DBL_PTR(_4003)->dbl != 0.0){
            DeRef(_4003);
            _4003 = NOVALUE;
            goto LB; // [240] 214
        }
    }
    DeRef(_4003);
    _4003 = NOVALUE;

    /** 			exit*/
    goto LC; // [245] 253

    /** 	end while*/
    goto LB; // [250] 214
LC: 

    /** 	if reserve_temp then*/
    if (_reserve_temp_7374 == 0)
    {
        goto LD; // [255] 300
    }
    else{
    }

    /** 		if not file_exists(temp_location) then*/
    RefDS(_temp_location_7370);
    _4005 = _17file_exists(_temp_location_7370);
    if (IS_ATOM_INT(_4005)) {
        if (_4005 != 0){
            DeRef(_4005);
            _4005 = NOVALUE;
            goto LE; // [264] 287
        }
    }
    else {
        if (DBL_PTR(_4005)->dbl != 0.0){
            DeRef(_4005);
            _4005 = NOVALUE;
            goto LE; // [264] 287
        }
    }
    DeRef(_4005);
    _4005 = NOVALUE;

    /** 			if create_directory(temp_location) = 0 then*/
    RefDS(_temp_location_7370);
    _4007 = _17create_directory(_temp_location_7370, 448, 1);
    if (binary_op_a(NOTEQ, _4007, 0)){
        DeRef(_4007);
        _4007 = NOVALUE;
        goto LF; // [275] 286
    }
    DeRef(_4007);
    _4007 = NOVALUE;

    /** 				return ""*/
    RefDS(_5);
    DeRefDS(_temp_location_7370);
    DeRefDSi(_temp_prefix_7371);
    DeRefDS(_temp_extn_7372);
    DeRefi(_randname_7375);
    return _5;
LF: 
LE: 

    /** 		io:write_file(randname, "")*/
    RefDS(_randname_7375);
    RefDS(_5);
    _5696 = _8write_file(_randname_7375, _5, 1);
    DeRef(_5696);
    _5696 = NOVALUE;
LD: 

    /** 	return randname*/
    DeRefDS(_temp_location_7370);
    DeRefDSi(_temp_prefix_7371);
    DeRefDS(_temp_extn_7372);
    return _randname_7375;
    ;
}



// 0x0D5CB0EE
