// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

void _50check_coverage()
{
    int _25186 = NOVALUE;
    int _25185 = NOVALUE;
    int _25184 = NOVALUE;
    int _25183 = NOVALUE;
    int _25182 = NOVALUE;
    int _25181 = NOVALUE;
    int _0, _1, _2;
    

    /** 	for i = length( file_coverage ) + 1 to length( known_files ) do*/
    if (IS_SEQUENCE(_50file_coverage_48100)){
            _25181 = SEQ_PTR(_50file_coverage_48100)->length;
    }
    else {
        _25181 = 1;
    }
    _25182 = _25181 + 1;
    _25181 = NOVALUE;
    if (IS_SEQUENCE(_36known_files_15243)){
            _25183 = SEQ_PTR(_36known_files_15243)->length;
    }
    else {
        _25183 = 1;
    }
    {
        int _i_48111;
        _i_48111 = _25182;
L1: 
        if (_i_48111 > _25183){
            goto L2; // [17] 58
        }

        /** 		file_coverage &= find( canonical_path( known_files[i],,1 ), covered_files )*/
        _2 = (int)SEQ_PTR(_36known_files_15243);
        _25184 = (int)*(((s1_ptr)_2)->base + _i_48111);
        Ref(_25184);
        _25185 = _17canonical_path(_25184, 0, 1);
        _25184 = NOVALUE;
        _25186 = find_from(_25185, _50covered_files_48099, 1);
        DeRef(_25185);
        _25185 = NOVALUE;
        Append(&_50file_coverage_48100, _50file_coverage_48100, _25186);
        _25186 = NOVALUE;

        /** 	end for*/
        _i_48111 = _i_48111 + 1;
        goto L1; // [53] 24
L2: 
        ;
    }

    /** end procedure*/
    DeRef(_25182);
    _25182 = NOVALUE;
    return;
    ;
}


void _50init_coverage()
{
    int _cmd_48135 = NOVALUE;
    int _25204 = NOVALUE;
    int _25203 = NOVALUE;
    int _25201 = NOVALUE;
    int _25200 = NOVALUE;
    int _25199 = NOVALUE;
    int _25197 = NOVALUE;
    int _25195 = NOVALUE;
    int _25194 = NOVALUE;
    int _25192 = NOVALUE;
    int _25191 = NOVALUE;
    int _25190 = NOVALUE;
    int _25189 = NOVALUE;
    int _25188 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if initialized_coverage then*/
    if (_50initialized_coverage_48107 == 0)
    {
        goto L1; // [5] 14
    }
    else{
    }

    /** 		return*/
    return;
L1: 

    /** 	initialized_coverage = 1*/
    _50initialized_coverage_48107 = 1;

    /** 	for i = 1 to length( file_coverage ) do*/
    if (IS_SEQUENCE(_50file_coverage_48100)){
            _25188 = SEQ_PTR(_50file_coverage_48100)->length;
    }
    else {
        _25188 = 1;
    }
    {
        int _i_48126;
        _i_48126 = 1;
L2: 
        if (_i_48126 > _25188){
            goto L3; // [26] 67
        }

        /** 		file_coverage[i] = find( canonical_path( known_files[i],,1 ), covered_files )*/
        _2 = (int)SEQ_PTR(_36known_files_15243);
        _25189 = (int)*(((s1_ptr)_2)->base + _i_48126);
        Ref(_25189);
        _25190 = _17canonical_path(_25189, 0, 1);
        _25189 = NOVALUE;
        _25191 = find_from(_25190, _50covered_files_48099, 1);
        DeRef(_25190);
        _25190 = NOVALUE;
        _2 = (int)SEQ_PTR(_50file_coverage_48100);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _50file_coverage_48100 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_48126);
        *(int *)_2 = _25191;
        if( _1 != _25191 ){
        }
        _25191 = NOVALUE;

        /** 	end for*/
        _i_48126 = _i_48126 + 1;
        goto L2; // [62] 33
L3: 
        ;
    }

    /** 	if equal( coverage_db_name, "" ) then*/
    if (_50coverage_db_name_48101 == _22023)
    _25192 = 1;
    else if (IS_ATOM_INT(_50coverage_db_name_48101) && IS_ATOM_INT(_22023))
    _25192 = 0;
    else
    _25192 = (compare(_50coverage_db_name_48101, _22023) == 0);
    if (_25192 == 0)
    {
        _25192 = NOVALUE;
        goto L4; // [75] 105
    }
    else{
        _25192 = NOVALUE;
    }

    /** 		sequence cmd = command_line()*/
    DeRef(_cmd_48135);
    _cmd_48135 = Command_Line();

    /** 		coverage_db_name = canonical_path( filebase( cmd[2] ) & "-cvg.edb" )*/
    _2 = (int)SEQ_PTR(_cmd_48135);
    _25194 = (int)*(((s1_ptr)_2)->base + 2);
    RefDS(_25194);
    _25195 = _17filebase(_25194);
    _25194 = NOVALUE;
    if (IS_SEQUENCE(_25195) && IS_ATOM(_25196)) {
    }
    else if (IS_ATOM(_25195) && IS_SEQUENCE(_25196)) {
        Ref(_25195);
        Prepend(&_25197, _25196, _25195);
    }
    else {
        Concat((object_ptr)&_25197, _25195, _25196);
        DeRef(_25195);
        _25195 = NOVALUE;
    }
    DeRef(_25195);
    _25195 = NOVALUE;
    _0 = _17canonical_path(_25197, 0, 0);
    DeRefDS(_50coverage_db_name_48101);
    _50coverage_db_name_48101 = _0;
    _25197 = NOVALUE;
L4: 
    DeRef(_cmd_48135);
    _cmd_48135 = NOVALUE;

    /** 	if coverage_erase and file_exists( coverage_db_name ) then*/
    if (_50coverage_erase_48102 == 0) {
        goto L5; // [111] 151
    }
    RefDS(_50coverage_db_name_48101);
    _25200 = _17file_exists(_50coverage_db_name_48101);
    if (_25200 == 0) {
        DeRef(_25200);
        _25200 = NOVALUE;
        goto L5; // [122] 151
    }
    else {
        if (!IS_ATOM_INT(_25200) && DBL_PTR(_25200)->dbl == 0.0){
            DeRef(_25200);
            _25200 = NOVALUE;
            goto L5; // [122] 151
        }
        DeRef(_25200);
        _25200 = NOVALUE;
    }
    DeRef(_25200);
    _25200 = NOVALUE;

    /** 		if not delete_file( coverage_db_name ) then*/
    RefDS(_50coverage_db_name_48101);
    _25201 = _17delete_file(_50coverage_db_name_48101);
    if (IS_ATOM_INT(_25201)) {
        if (_25201 != 0){
            DeRef(_25201);
            _25201 = NOVALUE;
            goto L6; // [133] 150
        }
    }
    else {
        if (DBL_PTR(_25201)->dbl != 0.0){
            DeRef(_25201);
            _25201 = NOVALUE;
            goto L6; // [133] 150
        }
    }
    DeRef(_25201);
    _25201 = NOVALUE;

    /** 			CompileErr( 335, { coverage_db_name } )*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_50coverage_db_name_48101);
    *((int *)(_2+4)) = _50coverage_db_name_48101;
    _25203 = MAKE_SEQ(_1);
    _44CompileErr(335, _25203, 0);
    _25203 = NOVALUE;
L6: 
L5: 

    /** 	if db_open( coverage_db_name ) = DB_OK then*/
    RefDS(_50coverage_db_name_48101);
    _25204 = _49db_open(_50coverage_db_name_48101, 0);
    if (binary_op_a(NOTEQ, _25204, 0)){
        DeRef(_25204);
        _25204 = NOVALUE;
        goto L7; // [162] 175
    }
    DeRef(_25204);
    _25204 = NOVALUE;

    /** 		read_coverage_db()*/
    _50read_coverage_db();

    /** 		db_close()*/
    _49db_close();
L7: 

    /** end procedure*/
    return;
    ;
}


void _50write_map(int _coverage_48164, int _table_name_48165)
{
    int _keys_48187 = NOVALUE;
    int _rec_48192 = NOVALUE;
    int _val_48196 = NOVALUE;
    int _31662 = NOVALUE;
    int _25221 = NOVALUE;
    int _25218 = NOVALUE;
    int _25216 = NOVALUE;
    int _25215 = NOVALUE;
    int _25213 = NOVALUE;
    int _25212 = NOVALUE;
    int _25210 = NOVALUE;
    int _25208 = NOVALUE;
    int _25206 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if db_select( coverage_db_name, DB_LOCK_EXCLUSIVE) = DB_OK then*/
    RefDS(_50coverage_db_name_48101);
    _25206 = _49db_select(_50coverage_db_name_48101, 2);
    if (binary_op_a(NOTEQ, _25206, 0)){
        DeRef(_25206);
        _25206 = NOVALUE;
        goto L1; // [16] 61
    }
    DeRef(_25206);
    _25206 = NOVALUE;

    /** 		if db_select_table( table_name ) != DB_OK then*/
    RefDS(_table_name_48165);
    _25208 = _49db_select_table(_table_name_48165);
    if (binary_op_a(EQUALS, _25208, 0)){
        DeRef(_25208);
        _25208 = NOVALUE;
        goto L2; // [28] 73
    }
    DeRef(_25208);
    _25208 = NOVALUE;

    /** 			if db_create_table( table_name ) != DB_OK then*/
    RefDS(_table_name_48165);
    _25210 = _49db_create_table(_table_name_48165, 50);
    if (binary_op_a(EQUALS, _25210, 0)){
        DeRef(_25210);
        _25210 = NOVALUE;
        goto L2; // [41] 73
    }
    DeRef(_25210);
    _25210 = NOVALUE;

    /** 				CompileErr( 336, {table_name} )*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_table_name_48165);
    *((int *)(_2+4)) = _table_name_48165;
    _25212 = MAKE_SEQ(_1);
    _44CompileErr(336, _25212, 0);
    _25212 = NOVALUE;
    goto L2; // [58] 73
L1: 

    /** 		CompileErr( 336, {table_name} )*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_table_name_48165);
    *((int *)(_2+4)) = _table_name_48165;
    _25213 = MAKE_SEQ(_1);
    _44CompileErr(336, _25213, 0);
    _25213 = NOVALUE;
L2: 

    /** 	sequence keys = map:keys( coverage )*/
    Ref(_coverage_48164);
    _0 = _keys_48187;
    _keys_48187 = _28keys(_coverage_48164, 0);
    DeRef(_0);

    /** 	for i = 1 to length( keys ) do*/
    if (IS_SEQUENCE(_keys_48187)){
            _25215 = SEQ_PTR(_keys_48187)->length;
    }
    else {
        _25215 = 1;
    }
    {
        int _i_48190;
        _i_48190 = 1;
L3: 
        if (_i_48190 > _25215){
            goto L4; // [87] 167
        }

        /** 		integer rec = db_find_key( keys[i] )*/
        _2 = (int)SEQ_PTR(_keys_48187);
        _25216 = (int)*(((s1_ptr)_2)->base + _i_48190);
        Ref(_25216);
        RefDS(_49current_table_name_17374);
        _rec_48192 = _49db_find_key(_25216, _49current_table_name_17374);
        _25216 = NOVALUE;
        if (!IS_ATOM_INT(_rec_48192)) {
            _1 = (long)(DBL_PTR(_rec_48192)->dbl);
            DeRefDS(_rec_48192);
            _rec_48192 = _1;
        }

        /** 		integer val = map:get( coverage, keys[i] )*/
        _2 = (int)SEQ_PTR(_keys_48187);
        _25218 = (int)*(((s1_ptr)_2)->base + _i_48190);
        Ref(_coverage_48164);
        Ref(_25218);
        _val_48196 = _28get(_coverage_48164, _25218, 0);
        _25218 = NOVALUE;
        if (!IS_ATOM_INT(_val_48196)) {
            _1 = (long)(DBL_PTR(_val_48196)->dbl);
            DeRefDS(_val_48196);
            _val_48196 = _1;
        }

        /** 		if rec > 0 then*/
        if (_rec_48192 <= 0)
        goto L5; // [125] 141

        /** 			db_replace_data( rec, val )*/
        RefDS(_49current_table_name_17374);
        _49db_replace_data(_rec_48192, _val_48196, _49current_table_name_17374);
        goto L6; // [138] 158
L5: 

        /** 			db_insert( keys[i], val )*/
        _2 = (int)SEQ_PTR(_keys_48187);
        _25221 = (int)*(((s1_ptr)_2)->base + _i_48190);
        Ref(_25221);
        RefDS(_49current_table_name_17374);
        _31662 = _49db_insert(_25221, _val_48196, _49current_table_name_17374);
        _25221 = NOVALUE;
        DeRef(_31662);
        _31662 = NOVALUE;
L6: 

        /** 	end for*/
        _i_48190 = _i_48190 + 1;
        goto L3; // [162] 94
L4: 
        ;
    }

    /** end procedure*/
    DeRef(_coverage_48164);
    DeRefDS(_table_name_48165);
    DeRef(_keys_48187);
    return;
    ;
}


int _50write_coverage_db()
{
    int _25236 = NOVALUE;
    int _25235 = NOVALUE;
    int _25234 = NOVALUE;
    int _25233 = NOVALUE;
    int _25232 = NOVALUE;
    int _25231 = NOVALUE;
    int _25230 = NOVALUE;
    int _25229 = NOVALUE;
    int _25226 = NOVALUE;
    int _25224 = NOVALUE;
    int _25222 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if wrote_coverage then*/
    if (_50wrote_coverage_48205 == 0)
    {
        goto L1; // [5] 15
    }
    else{
    }

    /** 		return 1*/
    return 1;
L1: 

    /** 	wrote_coverage = 1*/
    _50wrote_coverage_48205 = 1;

    /** 	init_coverage()*/
    _50init_coverage();

    /** 	if not length( covered_files ) then*/
    if (IS_SEQUENCE(_50covered_files_48099)){
            _25222 = SEQ_PTR(_50covered_files_48099)->length;
    }
    else {
        _25222 = 1;
    }
    if (_25222 != 0)
    goto L2; // [31] 41
    _25222 = NOVALUE;

    /** 		return 1*/
    return 1;
L2: 

    /** 	if DB_OK != db_open( coverage_db_name, DB_LOCK_EXCLUSIVE) then*/
    RefDS(_50coverage_db_name_48101);
    _25224 = _49db_open(_50coverage_db_name_48101, 2);
    if (binary_op_a(EQUALS, 0, _25224)){
        DeRef(_25224);
        _25224 = NOVALUE;
        goto L3; // [54] 95
    }
    DeRef(_25224);
    _25224 = NOVALUE;

    /** 		if DB_OK != db_create( coverage_db_name ) then*/
    RefDS(_50coverage_db_name_48101);
    _25226 = _49db_create(_50coverage_db_name_48101, 0, 5, 5);
    if (binary_op_a(EQUALS, 0, _25226)){
        DeRef(_25226);
        _25226 = NOVALUE;
        goto L4; // [71] 94
    }
    DeRef(_25226);
    _25226 = NOVALUE;

    /** 			printf(2, "error opening %s\n", {coverage_db_name})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_50coverage_db_name_48101);
    *((int *)(_2+4)) = _50coverage_db_name_48101;
    _25229 = MAKE_SEQ(_1);
    EPrintf(2, _25228, _25229);
    DeRefDS(_25229);
    _25229 = NOVALUE;

    /** 			return 0*/
    return 0;
L4: 
L3: 

    /** 	process_lines()*/
    _50process_lines();

    /** 	for tx = 1 to length( routine_map ) do*/
    if (IS_SEQUENCE(_50routine_map_48105)){
            _25230 = SEQ_PTR(_50routine_map_48105)->length;
    }
    else {
        _25230 = 1;
    }
    {
        int _tx_48227;
        _tx_48227 = 1;
L5: 
        if (_tx_48227 > _25230){
            goto L6; // [106] 164
        }

        /** 		write_map( routine_map[tx], 'r' & covered_files[tx] )*/
        _2 = (int)SEQ_PTR(_50routine_map_48105);
        _25231 = (int)*(((s1_ptr)_2)->base + _tx_48227);
        _2 = (int)SEQ_PTR(_50covered_files_48099);
        _25232 = (int)*(((s1_ptr)_2)->base + _tx_48227);
        if (IS_SEQUENCE(114) && IS_ATOM(_25232)) {
        }
        else if (IS_ATOM(114) && IS_SEQUENCE(_25232)) {
            Prepend(&_25233, _25232, 114);
        }
        else {
            Concat((object_ptr)&_25233, 114, _25232);
        }
        _25232 = NOVALUE;
        Ref(_25231);
        _50write_map(_25231, _25233);
        _25231 = NOVALUE;
        _25233 = NOVALUE;

        /** 		write_map( line_map[tx],    'l' & covered_files[tx] )*/
        _2 = (int)SEQ_PTR(_50line_map_48104);
        _25234 = (int)*(((s1_ptr)_2)->base + _tx_48227);
        _2 = (int)SEQ_PTR(_50covered_files_48099);
        _25235 = (int)*(((s1_ptr)_2)->base + _tx_48227);
        if (IS_SEQUENCE(108) && IS_ATOM(_25235)) {
        }
        else if (IS_ATOM(108) && IS_SEQUENCE(_25235)) {
            Prepend(&_25236, _25235, 108);
        }
        else {
            Concat((object_ptr)&_25236, 108, _25235);
        }
        _25235 = NOVALUE;
        Ref(_25234);
        _50write_map(_25234, _25236);
        _25234 = NOVALUE;
        _25236 = NOVALUE;

        /** 	end for*/
        _tx_48227 = _tx_48227 + 1;
        goto L5; // [159] 113
L6: 
        ;
    }

    /** 	db_close()*/
    _49db_close();

    /** 	routine_map = {}*/
    RefDS(_22023);
    DeRef(_50routine_map_48105);
    _50routine_map_48105 = _22023;

    /** 	line_map    = {}*/
    RefDS(_22023);
    DeRef(_50line_map_48104);
    _50line_map_48104 = _22023;

    /** 	return 1*/
    return 1;
    ;
}


void _50read_coverage_db()
{
    int _tables_48238 = NOVALUE;
    int _name_48244 = NOVALUE;
    int _fx_48248 = NOVALUE;
    int _the_map_48255 = NOVALUE;
    int _31661 = NOVALUE;
    int _25252 = NOVALUE;
    int _25251 = NOVALUE;
    int _25250 = NOVALUE;
    int _25246 = NOVALUE;
    int _25245 = NOVALUE;
    int _25244 = NOVALUE;
    int _25240 = NOVALUE;
    int _25239 = NOVALUE;
    int _25238 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence tables = db_table_list()*/
    _0 = _tables_48238;
    _tables_48238 = _49db_table_list();
    DeRef(_0);

    /** 	for i = 1 to length( tables ) do*/
    if (IS_SEQUENCE(_tables_48238)){
            _25238 = SEQ_PTR(_tables_48238)->length;
    }
    else {
        _25238 = 1;
    }
    {
        int _i_48242;
        _i_48242 = 1;
L1: 
        if (_i_48242 > _25238){
            goto L2; // [13] 159
        }

        /** 		sequence name = tables[i][2..$]*/
        _2 = (int)SEQ_PTR(_tables_48238);
        _25239 = (int)*(((s1_ptr)_2)->base + _i_48242);
        if (IS_SEQUENCE(_25239)){
                _25240 = SEQ_PTR(_25239)->length;
        }
        else {
            _25240 = 1;
        }
        rhs_slice_target = (object_ptr)&_name_48244;
        RHS_Slice(_25239, 2, _25240);
        _25239 = NOVALUE;

        /** 		integer fx = find( name, covered_files )*/
        _fx_48248 = find_from(_name_48244, _50covered_files_48099, 1);

        /** 		if not fx then*/
        if (_fx_48248 != 0)
        goto L3; // [45] 55

        /** 			continue*/
        DeRefDS(_name_48244);
        _name_48244 = NOVALUE;
        DeRef(_the_map_48255);
        _the_map_48255 = NOVALUE;
        goto L4; // [52] 154
L3: 

        /** 		db_select_table( tables[i] )*/
        _2 = (int)SEQ_PTR(_tables_48238);
        _25244 = (int)*(((s1_ptr)_2)->base + _i_48242);
        Ref(_25244);
        _31661 = _49db_select_table(_25244);
        _25244 = NOVALUE;
        DeRef(_31661);
        _31661 = NOVALUE;

        /** 		if tables[i][1] = 'r' then*/
        _2 = (int)SEQ_PTR(_tables_48238);
        _25245 = (int)*(((s1_ptr)_2)->base + _i_48242);
        _2 = (int)SEQ_PTR(_25245);
        _25246 = (int)*(((s1_ptr)_2)->base + 1);
        _25245 = NOVALUE;
        if (binary_op_a(NOTEQ, _25246, 114)){
            _25246 = NOVALUE;
            goto L5; // [77] 92
        }
        _25246 = NOVALUE;

        /** 			the_map = routine_map[fx]*/
        DeRef(_the_map_48255);
        _2 = (int)SEQ_PTR(_50routine_map_48105);
        _the_map_48255 = (int)*(((s1_ptr)_2)->base + _fx_48248);
        Ref(_the_map_48255);
        goto L6; // [89] 101
L5: 

        /** 			the_map = line_map[fx]*/
        DeRef(_the_map_48255);
        _2 = (int)SEQ_PTR(_50line_map_48104);
        _the_map_48255 = (int)*(((s1_ptr)_2)->base + _fx_48248);
        Ref(_the_map_48255);
L6: 

        /** 		for j = 1 to db_table_size() do*/
        RefDS(_49current_table_name_17374);
        _25250 = _49db_table_size(_49current_table_name_17374);
        {
            int _j_48264;
            _j_48264 = 1;
L7: 
            if (binary_op_a(GREATER, _j_48264, _25250)){
                goto L8; // [109] 150
            }

            /** 			map:put( the_map, db_record_key( j ), db_record_data( j ), map:ADD )*/
            Ref(_j_48264);
            RefDS(_49current_table_name_17374);
            _25251 = _49db_record_key(_j_48264, _49current_table_name_17374);
            Ref(_j_48264);
            RefDS(_49current_table_name_17374);
            _25252 = _49db_record_data(_j_48264, _49current_table_name_17374);
            Ref(_the_map_48255);
            _28put(_the_map_48255, _25251, _25252, 2, 23);
            _25251 = NOVALUE;
            _25252 = NOVALUE;

            /** 		end for*/
            _0 = _j_48264;
            if (IS_ATOM_INT(_j_48264)) {
                _j_48264 = _j_48264 + 1;
                if ((long)((unsigned long)_j_48264 +(unsigned long) HIGH_BITS) >= 0){
                    _j_48264 = NewDouble((double)_j_48264);
                }
            }
            else {
                _j_48264 = binary_op_a(PLUS, _j_48264, 1);
            }
            DeRef(_0);
            goto L7; // [145] 116
L8: 
            ;
            DeRef(_j_48264);
        }
        DeRef(_name_48244);
        _name_48244 = NOVALUE;
        DeRef(_the_map_48255);
        _the_map_48255 = NOVALUE;

        /** 	end for*/
L4: 
        _i_48242 = _i_48242 + 1;
        goto L1; // [154] 20
L2: 
        ;
    }

    /** end procedure*/
    DeRef(_tables_48238);
    DeRef(_25250);
    _25250 = NOVALUE;
    return;
    ;
}


void _50coverage_db(int _name_48273)
{
    int _0, _1, _2;
    

    /** 	coverage_db_name = name*/
    RefDS(_name_48273);
    DeRef(_50coverage_db_name_48101);
    _50coverage_db_name_48101 = _name_48273;

    /** end procedure*/
    DeRefDS(_name_48273);
    return;
    ;
}


int _50coverage_on()
{
    int _25253 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return file_coverage[current_file_no]*/
    _2 = (int)SEQ_PTR(_50file_coverage_48100);
    _25253 = (int)*(((s1_ptr)_2)->base + _35current_file_no_16244);
    return _25253;
    ;
}


void _50new_covered_path(int _name_48285)
{
    int _25259 = NOVALUE;
    int _25257 = NOVALUE;
    int _0, _1, _2;
    

    /** 	covered_files = append( covered_files, name )*/
    RefDS(_name_48285);
    Append(&_50covered_files_48099, _50covered_files_48099, _name_48285);

    /** 	routine_map &= map:new()*/
    _25257 = _28new(690);
    if (IS_SEQUENCE(_50routine_map_48105) && IS_ATOM(_25257)) {
        Ref(_25257);
        Append(&_50routine_map_48105, _50routine_map_48105, _25257);
    }
    else if (IS_ATOM(_50routine_map_48105) && IS_SEQUENCE(_25257)) {
    }
    else {
        Concat((object_ptr)&_50routine_map_48105, _50routine_map_48105, _25257);
    }
    DeRef(_25257);
    _25257 = NOVALUE;

    /** 	line_map    &= map:new()*/
    _25259 = _28new(690);
    if (IS_SEQUENCE(_50line_map_48104) && IS_ATOM(_25259)) {
        Ref(_25259);
        Append(&_50line_map_48104, _50line_map_48104, _25259);
    }
    else if (IS_ATOM(_50line_map_48104) && IS_SEQUENCE(_25259)) {
    }
    else {
        Concat((object_ptr)&_50line_map_48104, _50line_map_48104, _25259);
    }
    DeRef(_25259);
    _25259 = NOVALUE;

    /** end procedure*/
    DeRefDS(_name_48285);
    return;
    ;
}


void _50add_coverage(int _cover_this_48293)
{
    int _path_48294 = NOVALUE;
    int _files_48303 = NOVALUE;
    int _subpath_48331 = NOVALUE;
    int _25294 = NOVALUE;
    int _25293 = NOVALUE;
    int _25292 = NOVALUE;
    int _25291 = NOVALUE;
    int _25290 = NOVALUE;
    int _25289 = NOVALUE;
    int _25288 = NOVALUE;
    int _25287 = NOVALUE;
    int _25286 = NOVALUE;
    int _25285 = NOVALUE;
    int _25284 = NOVALUE;
    int _25283 = NOVALUE;
    int _25281 = NOVALUE;
    int _25280 = NOVALUE;
    int _25279 = NOVALUE;
    int _25278 = NOVALUE;
    int _25277 = NOVALUE;
    int _25276 = NOVALUE;
    int _25275 = NOVALUE;
    int _25274 = NOVALUE;
    int _25272 = NOVALUE;
    int _25271 = NOVALUE;
    int _25270 = NOVALUE;
    int _25269 = NOVALUE;
    int _25268 = NOVALUE;
    int _25267 = NOVALUE;
    int _25266 = NOVALUE;
    int _25265 = NOVALUE;
    int _25262 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence path = canonical_path( cover_this,, CORRECT )*/
    RefDS(_cover_this_48293);
    _0 = _path_48294;
    _path_48294 = _17canonical_path(_cover_this_48293, 0, 2);
    DeRef(_0);

    /** 	if file_type( path ) = FILETYPE_DIRECTORY then*/
    RefDS(_path_48294);
    _25262 = _17file_type(_path_48294);
    if (binary_op_a(NOTEQ, _25262, 2)){
        DeRef(_25262);
        _25262 = NOVALUE;
        goto L1; // [23] 211
    }
    DeRef(_25262);
    _25262 = NOVALUE;

    /** 		sequence files = dir( path  )*/
    RefDS(_path_48294);
    _0 = _files_48303;
    _files_48303 = _17dir(_path_48294);
    DeRef(_0);

    /** 		for i = 1 to length( files ) do*/
    if (IS_SEQUENCE(_files_48303)){
            _25265 = SEQ_PTR(_files_48303)->length;
    }
    else {
        _25265 = 1;
    }
    {
        int _i_48307;
        _i_48307 = 1;
L2: 
        if (_i_48307 > _25265){
            goto L3; // [40] 206
        }

        /** 			if find( 'd', files[i][D_ATTRIBUTES] ) then*/
        _2 = (int)SEQ_PTR(_files_48303);
        _25266 = (int)*(((s1_ptr)_2)->base + _i_48307);
        _2 = (int)SEQ_PTR(_25266);
        _25267 = (int)*(((s1_ptr)_2)->base + 2);
        _25266 = NOVALUE;
        _25268 = find_from(100, _25267, 1);
        _25267 = NOVALUE;
        if (_25268 == 0)
        {
            _25268 = NOVALUE;
            goto L4; // [64] 118
        }
        else{
            _25268 = NOVALUE;
        }

        /** 				if not eu:find(files[i][D_NAME], {".", ".."}) then*/
        _2 = (int)SEQ_PTR(_files_48303);
        _25269 = (int)*(((s1_ptr)_2)->base + _i_48307);
        _2 = (int)SEQ_PTR(_25269);
        _25270 = (int)*(((s1_ptr)_2)->base + 1);
        _25269 = NOVALUE;
        RefDS(_23096);
        RefDS(_23097);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _23097;
        ((int *)_2)[2] = _23096;
        _25271 = MAKE_SEQ(_1);
        _25272 = find_from(_25270, _25271, 1);
        _25270 = NOVALUE;
        DeRefDS(_25271);
        _25271 = NOVALUE;
        if (_25272 != 0)
        goto L5; // [88] 199
        _25272 = NOVALUE;

        /** 					add_coverage( cover_this & SLASH & files[i][D_NAME] )*/
        _2 = (int)SEQ_PTR(_files_48303);
        _25274 = (int)*(((s1_ptr)_2)->base + _i_48307);
        _2 = (int)SEQ_PTR(_25274);
        _25275 = (int)*(((s1_ptr)_2)->base + 1);
        _25274 = NOVALUE;
        {
            int concat_list[3];

            concat_list[0] = _25275;
            concat_list[1] = 92;
            concat_list[2] = _cover_this_48293;
            Concat_N((object_ptr)&_25276, concat_list, 3);
        }
        _25275 = NOVALUE;
        _50add_coverage(_25276);
        _25276 = NOVALUE;
        goto L5; // [115] 199
L4: 

        /** 			elsif regex:has_match( eu_file, files[i][D_NAME] ) then*/
        _2 = (int)SEQ_PTR(_files_48303);
        _25277 = (int)*(((s1_ptr)_2)->base + _i_48307);
        _2 = (int)SEQ_PTR(_25277);
        _25278 = (int)*(((s1_ptr)_2)->base + 1);
        _25277 = NOVALUE;
        Ref(_50eu_file_48279);
        Ref(_25278);
        _25279 = _51has_match(_50eu_file_48279, _25278, 1, 0);
        _25278 = NOVALUE;
        if (_25279 == 0) {
            DeRef(_25279);
            _25279 = NOVALUE;
            goto L6; // [139] 196
        }
        else {
            if (!IS_ATOM_INT(_25279) && DBL_PTR(_25279)->dbl == 0.0){
                DeRef(_25279);
                _25279 = NOVALUE;
                goto L6; // [139] 196
            }
            DeRef(_25279);
            _25279 = NOVALUE;
        }
        DeRef(_25279);
        _25279 = NOVALUE;

        /** 				sequence subpath = path & SLASH & files[i][D_NAME]*/
        _2 = (int)SEQ_PTR(_files_48303);
        _25280 = (int)*(((s1_ptr)_2)->base + _i_48307);
        _2 = (int)SEQ_PTR(_25280);
        _25281 = (int)*(((s1_ptr)_2)->base + 1);
        _25280 = NOVALUE;
        {
            int concat_list[3];

            concat_list[0] = _25281;
            concat_list[1] = 92;
            concat_list[2] = _path_48294;
            Concat_N((object_ptr)&_subpath_48331, concat_list, 3);
        }
        _25281 = NOVALUE;

        /** 				if not find( subpath, covered_files ) and not excluded( subpath ) then*/
        _25283 = find_from(_subpath_48331, _50covered_files_48099, 1);
        _25284 = (_25283 == 0);
        _25283 = NOVALUE;
        if (_25284 == 0) {
            goto L7; // [174] 195
        }
        RefDS(_subpath_48331);
        _25286 = _50excluded(_subpath_48331);
        if (IS_ATOM_INT(_25286)) {
            _25287 = (_25286 == 0);
        }
        else {
            _25287 = unary_op(NOT, _25286);
        }
        DeRef(_25286);
        _25286 = NOVALUE;
        if (_25287 == 0) {
            DeRef(_25287);
            _25287 = NOVALUE;
            goto L7; // [186] 195
        }
        else {
            if (!IS_ATOM_INT(_25287) && DBL_PTR(_25287)->dbl == 0.0){
                DeRef(_25287);
                _25287 = NOVALUE;
                goto L7; // [186] 195
            }
            DeRef(_25287);
            _25287 = NOVALUE;
        }
        DeRef(_25287);
        _25287 = NOVALUE;

        /** 					new_covered_path( subpath )*/
        RefDS(_subpath_48331);
        _50new_covered_path(_subpath_48331);
L7: 
L6: 
        DeRef(_subpath_48331);
        _subpath_48331 = NOVALUE;
L5: 

        /** 		end for*/
        _i_48307 = _i_48307 + 1;
        goto L2; // [201] 47
L3: 
        ;
    }
    DeRef(_files_48303);
    _files_48303 = NOVALUE;
    goto L8; // [208] 262
L1: 

    /** 	elsif regex:has_match( eu_file, path ) and*/
    Ref(_50eu_file_48279);
    RefDS(_path_48294);
    _25288 = _51has_match(_50eu_file_48279, _path_48294, 1, 0);
    if (IS_ATOM_INT(_25288)) {
        if (_25288 == 0) {
            DeRef(_25289);
            _25289 = 0;
            goto L9; // [222] 240
        }
    }
    else {
        if (DBL_PTR(_25288)->dbl == 0.0) {
            DeRef(_25289);
            _25289 = 0;
            goto L9; // [222] 240
        }
    }
    _25290 = find_from(_path_48294, _50covered_files_48099, 1);
    _25291 = (_25290 == 0);
    _25290 = NOVALUE;
    DeRef(_25289);
    _25289 = (_25291 != 0);
L9: 
    if (_25289 == 0) {
        goto LA; // [240] 261
    }
    RefDS(_path_48294);
    _25293 = _50excluded(_path_48294);
    if (IS_ATOM_INT(_25293)) {
        _25294 = (_25293 == 0);
    }
    else {
        _25294 = unary_op(NOT, _25293);
    }
    DeRef(_25293);
    _25293 = NOVALUE;
    if (_25294 == 0) {
        DeRef(_25294);
        _25294 = NOVALUE;
        goto LA; // [252] 261
    }
    else {
        if (!IS_ATOM_INT(_25294) && DBL_PTR(_25294)->dbl == 0.0){
            DeRef(_25294);
            _25294 = NOVALUE;
            goto LA; // [252] 261
        }
        DeRef(_25294);
        _25294 = NOVALUE;
    }
    DeRef(_25294);
    _25294 = NOVALUE;

    /** 		new_covered_path( path )*/
    RefDS(_path_48294);
    _50new_covered_path(_path_48294);
LA: 
L8: 

    /** end procedure*/
    DeRefDS(_cover_this_48293);
    DeRef(_path_48294);
    DeRef(_25284);
    _25284 = NOVALUE;
    DeRef(_25288);
    _25288 = NOVALUE;
    DeRef(_25291);
    _25291 = NOVALUE;
    return;
    ;
}


int _50excluded(int _file_48355)
{
    int _25297 = NOVALUE;
    int _25296 = NOVALUE;
    int _25295 = NOVALUE;
    int _0, _1, _2;
    

    /** 	for i = 1 to length( exclusion_patterns ) do*/
    if (IS_SEQUENCE(_50exclusion_patterns_48103)){
            _25295 = SEQ_PTR(_50exclusion_patterns_48103)->length;
    }
    else {
        _25295 = 1;
    }
    {
        int _i_48357;
        _i_48357 = 1;
L1: 
        if (_i_48357 > _25295){
            goto L2; // [10] 49
        }

        /** 		if regex:has_match( exclusion_patterns[i], file ) then*/
        _2 = (int)SEQ_PTR(_50exclusion_patterns_48103);
        _25296 = (int)*(((s1_ptr)_2)->base + _i_48357);
        Ref(_25296);
        RefDS(_file_48355);
        _25297 = _51has_match(_25296, _file_48355, 1, 0);
        _25296 = NOVALUE;
        if (_25297 == 0) {
            DeRef(_25297);
            _25297 = NOVALUE;
            goto L3; // [32] 42
        }
        else {
            if (!IS_ATOM_INT(_25297) && DBL_PTR(_25297)->dbl == 0.0){
                DeRef(_25297);
                _25297 = NOVALUE;
                goto L3; // [32] 42
            }
            DeRef(_25297);
            _25297 = NOVALUE;
        }
        DeRef(_25297);
        _25297 = NOVALUE;

        /** 			return 1*/
        DeRefDS(_file_48355);
        return 1;
L3: 

        /** 	end for*/
        _i_48357 = _i_48357 + 1;
        goto L1; // [44] 17
L2: 
        ;
    }

    /** 	return 0*/
    DeRefDS(_file_48355);
    return 0;
    ;
}


void _50coverage_exclude(int _patterns_48364)
{
    int _ex_48369 = NOVALUE;
    int _fx_48376 = NOVALUE;
    int _25315 = NOVALUE;
    int _25314 = NOVALUE;
    int _25313 = NOVALUE;
    int _25312 = NOVALUE;
    int _25306 = NOVALUE;
    int _25305 = NOVALUE;
    int _25303 = NOVALUE;
    int _25301 = NOVALUE;
    int _25299 = NOVALUE;
    int _25298 = NOVALUE;
    int _0, _1, _2;
    

    /** 	for i = 1 to length( patterns ) do*/
    if (IS_SEQUENCE(_patterns_48364)){
            _25298 = SEQ_PTR(_patterns_48364)->length;
    }
    else {
        _25298 = 1;
    }
    {
        int _i_48366;
        _i_48366 = 1;
L1: 
        if (_i_48366 > _25298){
            goto L2; // [8] 161
        }

        /** 		regex ex = regex:new( patterns[i] )*/
        _2 = (int)SEQ_PTR(_patterns_48364);
        _25299 = (int)*(((s1_ptr)_2)->base + _i_48366);
        Ref(_25299);
        _0 = _ex_48369;
        _ex_48369 = _51new(_25299, 0);
        DeRef(_0);
        _25299 = NOVALUE;

        /** 		if regex( ex ) then*/
        Ref(_ex_48369);
        _25301 = _51regex(_ex_48369);
        if (_25301 == 0) {
            DeRef(_25301);
            _25301 = NOVALUE;
            goto L3; // [32] 127
        }
        else {
            if (!IS_ATOM_INT(_25301) && DBL_PTR(_25301)->dbl == 0.0){
                DeRef(_25301);
                _25301 = NOVALUE;
                goto L3; // [32] 127
            }
            DeRef(_25301);
            _25301 = NOVALUE;
        }
        DeRef(_25301);
        _25301 = NOVALUE;

        /** 			exclusion_patterns = append( exclusion_patterns, ex )*/
        Ref(_ex_48369);
        Append(&_50exclusion_patterns_48103, _50exclusion_patterns_48103, _ex_48369);

        /** 			integer fx = 1*/
        _fx_48376 = 1;

        /** 			while fx <= length( covered_files ) do*/
L4: 
        if (IS_SEQUENCE(_50covered_files_48099)){
                _25303 = SEQ_PTR(_50covered_files_48099)->length;
        }
        else {
            _25303 = 1;
        }
        if (_fx_48376 > _25303)
        goto L5; // [58] 122

        /** 				if regex:has_match( ex, covered_files[fx] ) then*/
        _2 = (int)SEQ_PTR(_50covered_files_48099);
        _25305 = (int)*(((s1_ptr)_2)->base + _fx_48376);
        Ref(_ex_48369);
        Ref(_25305);
        _25306 = _51has_match(_ex_48369, _25305, 1, 0);
        _25305 = NOVALUE;
        if (_25306 == 0) {
            DeRef(_25306);
            _25306 = NOVALUE;
            goto L6; // [77] 110
        }
        else {
            if (!IS_ATOM_INT(_25306) && DBL_PTR(_25306)->dbl == 0.0){
                DeRef(_25306);
                _25306 = NOVALUE;
                goto L6; // [77] 110
            }
            DeRef(_25306);
            _25306 = NOVALUE;
        }
        DeRef(_25306);
        _25306 = NOVALUE;

        /** 					covered_files = remove( covered_files, fx )*/
        {
            s1_ptr assign_space = SEQ_PTR(_50covered_files_48099);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_fx_48376)) ? _fx_48376 : (long)(DBL_PTR(_fx_48376)->dbl);
            int stop = (IS_ATOM_INT(_fx_48376)) ? _fx_48376 : (long)(DBL_PTR(_fx_48376)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<0) {
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_50covered_files_48099), start, &_50covered_files_48099 );
                }
                else Tail(SEQ_PTR(_50covered_files_48099), stop+1, &_50covered_files_48099);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_50covered_files_48099), start, &_50covered_files_48099);
            }
            else {
                assign_slice_seq = &assign_space;
                _50covered_files_48099 = Remove_elements(start, stop, (SEQ_PTR(_50covered_files_48099)->ref == 1));
            }
        }

        /** 					routine_map   = remove( routine_map, fx )*/
        {
            s1_ptr assign_space = SEQ_PTR(_50routine_map_48105);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_fx_48376)) ? _fx_48376 : (long)(DBL_PTR(_fx_48376)->dbl);
            int stop = (IS_ATOM_INT(_fx_48376)) ? _fx_48376 : (long)(DBL_PTR(_fx_48376)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<0) {
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_50routine_map_48105), start, &_50routine_map_48105 );
                }
                else Tail(SEQ_PTR(_50routine_map_48105), stop+1, &_50routine_map_48105);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_50routine_map_48105), start, &_50routine_map_48105);
            }
            else {
                assign_slice_seq = &assign_space;
                _50routine_map_48105 = Remove_elements(start, stop, (SEQ_PTR(_50routine_map_48105)->ref == 1));
            }
        }

        /** 					line_map      = remove( line_map, fx )*/
        {
            s1_ptr assign_space = SEQ_PTR(_50line_map_48104);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_fx_48376)) ? _fx_48376 : (long)(DBL_PTR(_fx_48376)->dbl);
            int stop = (IS_ATOM_INT(_fx_48376)) ? _fx_48376 : (long)(DBL_PTR(_fx_48376)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<0) {
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_50line_map_48104), start, &_50line_map_48104 );
                }
                else Tail(SEQ_PTR(_50line_map_48104), stop+1, &_50line_map_48104);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_50line_map_48104), start, &_50line_map_48104);
            }
            else {
                assign_slice_seq = &assign_space;
                _50line_map_48104 = Remove_elements(start, stop, (SEQ_PTR(_50line_map_48104)->ref == 1));
            }
        }
        goto L4; // [107] 53
L6: 

        /** 					fx += 1*/
        _fx_48376 = _fx_48376 + 1;

        /** 			end while*/
        goto L4; // [119] 53
L5: 
        goto L7; // [124] 152
L3: 

        /** 			printf( 2,"%s\n", { GetMsgText( 339, 1, {patterns[i]}) } )*/
        _2 = (int)SEQ_PTR(_patterns_48364);
        _25312 = (int)*(((s1_ptr)_2)->base + _i_48366);
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        Ref(_25312);
        *((int *)(_2+4)) = _25312;
        _25313 = MAKE_SEQ(_1);
        _25312 = NOVALUE;
        _25314 = _45GetMsgText(339, 1, _25313);
        _25313 = NOVALUE;
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = _25314;
        _25315 = MAKE_SEQ(_1);
        _25314 = NOVALUE;
        EPrintf(2, _25311, _25315);
        DeRefDS(_25315);
        _25315 = NOVALUE;
L7: 
        DeRef(_ex_48369);
        _ex_48369 = NOVALUE;

        /** 	end for*/
        _i_48366 = _i_48366 + 1;
        goto L1; // [156] 15
L2: 
        ;
    }

    /** end procedure*/
    DeRefDS(_patterns_48364);
    return;
    ;
}


void _50new_coverage_db()
{
    int _0, _1, _2;
    

    /** 	coverage_erase = 1*/
    _50coverage_erase_48102 = 1;

    /** end procedure*/
    return;
    ;
}


void _50include_line(int _line_number_48399)
{
    int _25316 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_line_number_48399)) {
        _1 = (long)(DBL_PTR(_line_number_48399)->dbl);
        DeRefDS(_line_number_48399);
        _line_number_48399 = _1;
    }

    /** 	if coverage_on() then*/
    _25316 = _50coverage_on();
    if (_25316 == 0) {
        DeRef(_25316);
        _25316 = NOVALUE;
        goto L1; // [8] 34
    }
    else {
        if (!IS_ATOM_INT(_25316) && DBL_PTR(_25316)->dbl == 0.0){
            DeRef(_25316);
            _25316 = NOVALUE;
            goto L1; // [8] 34
        }
        DeRef(_25316);
        _25316 = NOVALUE;
    }
    DeRef(_25316);
    _25316 = NOVALUE;

    /** 		emit_op( COVERAGE_LINE )*/
    _41emit_op(210);

    /** 		emit_addr( gline_number )*/
    _41emit_addr(_35gline_number_16249);

    /** 		included_lines &= line_number*/
    Append(&_50included_lines_48106, _50included_lines_48106, _line_number_48399);
L1: 

    /** end procedure*/
    return;
    ;
}


void _50include_routine()
{
    int _file_no_48415 = NOVALUE;
    int _25323 = NOVALUE;
    int _25322 = NOVALUE;
    int _25321 = NOVALUE;
    int _25319 = NOVALUE;
    int _25318 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if coverage_on() then*/
    _25318 = _50coverage_on();
    if (_25318 == 0) {
        DeRef(_25318);
        _25318 = NOVALUE;
        goto L1; // [6] 71
    }
    else {
        if (!IS_ATOM_INT(_25318) && DBL_PTR(_25318)->dbl == 0.0){
            DeRef(_25318);
            _25318 = NOVALUE;
            goto L1; // [6] 71
        }
        DeRef(_25318);
        _25318 = NOVALUE;
    }
    DeRef(_25318);
    _25318 = NOVALUE;

    /** 		emit_op( COVERAGE_ROUTINE )*/
    _41emit_op(211);

    /** 		emit_addr( CurrentSub )*/
    _41emit_addr(_35CurrentSub_16252);

    /** 		integer file_no = SymTab[CurrentSub][S_FILE_NO]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _25319 = (int)*(((s1_ptr)_2)->base + _35CurrentSub_16252);
    _2 = (int)SEQ_PTR(_25319);
    if (!IS_ATOM_INT(_35S_FILE_NO_15913)){
        _file_no_48415 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FILE_NO_15913)->dbl));
    }
    else{
        _file_no_48415 = (int)*(((s1_ptr)_2)->base + _35S_FILE_NO_15913);
    }
    if (!IS_ATOM_INT(_file_no_48415)){
        _file_no_48415 = (long)DBL_PTR(_file_no_48415)->dbl;
    }
    _25319 = NOVALUE;

    /** 		map:put( routine_map[file_coverage[file_no]], sym_name( CurrentSub ), 0, map:ADD )*/
    _2 = (int)SEQ_PTR(_50file_coverage_48100);
    _25321 = (int)*(((s1_ptr)_2)->base + _file_no_48415);
    _2 = (int)SEQ_PTR(_50routine_map_48105);
    _25322 = (int)*(((s1_ptr)_2)->base + _25321);
    _25323 = _53sym_name(_35CurrentSub_16252);
    Ref(_25322);
    _28put(_25322, _25323, 0, 2, 23);
    _25322 = NOVALUE;
    _25323 = NOVALUE;
L1: 

    /** end procedure*/
    _25321 = NOVALUE;
    return;
    ;
}


void _50process_lines()
{
    int _sline_48443 = NOVALUE;
    int _file_48447 = NOVALUE;
    int _line_48457 = NOVALUE;
    int _25341 = NOVALUE;
    int _25339 = NOVALUE;
    int _25338 = NOVALUE;
    int _25337 = NOVALUE;
    int _25336 = NOVALUE;
    int _25335 = NOVALUE;
    int _25333 = NOVALUE;
    int _25331 = NOVALUE;
    int _25330 = NOVALUE;
    int _25328 = NOVALUE;
    int _25327 = NOVALUE;
    int _25326 = NOVALUE;
    int _25324 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not length( included_lines ) then*/
    if (IS_SEQUENCE(_50included_lines_48106)){
            _25324 = SEQ_PTR(_50included_lines_48106)->length;
    }
    else {
        _25324 = 1;
    }
    if (_25324 != 0)
    goto L1; // [8] 17
    _25324 = NOVALUE;

    /** 		return*/
    return;
L1: 

    /** 	if atom(slist[$]) then*/
    if (IS_SEQUENCE(_35slist_16334)){
            _25326 = SEQ_PTR(_35slist_16334)->length;
    }
    else {
        _25326 = 1;
    }
    _2 = (int)SEQ_PTR(_35slist_16334);
    _25327 = (int)*(((s1_ptr)_2)->base + _25326);
    _25328 = IS_ATOM(_25327);
    _25327 = NOVALUE;
    if (_25328 == 0)
    {
        _25328 = NOVALUE;
        goto L2; // [31] 45
    }
    else{
        _25328 = NOVALUE;
    }

    /** 		slist = s_expand( slist )*/
    RefDS(_35slist_16334);
    _0 = _61s_expand(_35slist_16334);
    DeRefDS(_35slist_16334);
    _35slist_16334 = _0;
L2: 

    /** 	for i = 1 to length( included_lines ) do*/
    if (IS_SEQUENCE(_50included_lines_48106)){
            _25330 = SEQ_PTR(_50included_lines_48106)->length;
    }
    else {
        _25330 = 1;
    }
    {
        int _i_48441;
        _i_48441 = 1;
L3: 
        if (_i_48441 > _25330){
            goto L4; // [52] 159
        }

        /** 		sequence sline = slist[included_lines[i]]*/
        _2 = (int)SEQ_PTR(_50included_lines_48106);
        _25331 = (int)*(((s1_ptr)_2)->base + _i_48441);
        DeRef(_sline_48443);
        _2 = (int)SEQ_PTR(_35slist_16334);
        _sline_48443 = (int)*(((s1_ptr)_2)->base + _25331);
        Ref(_sline_48443);

        /** 		integer file = file_coverage[sline[LOCAL_FILE_NO]]*/
        _2 = (int)SEQ_PTR(_sline_48443);
        _25333 = (int)*(((s1_ptr)_2)->base + 3);
        _2 = (int)SEQ_PTR(_50file_coverage_48100);
        if (!IS_ATOM_INT(_25333)){
            _file_48447 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_25333)->dbl));
        }
        else{
            _file_48447 = (int)*(((s1_ptr)_2)->base + _25333);
        }

        /** 		if file and file <= length( line_map ) and line_map[file] then*/
        if (_file_48447 == 0) {
            _25335 = 0;
            goto L5; // [91] 108
        }
        if (IS_SEQUENCE(_50line_map_48104)){
                _25336 = SEQ_PTR(_50line_map_48104)->length;
        }
        else {
            _25336 = 1;
        }
        _25337 = (_file_48447 <= _25336);
        _25336 = NOVALUE;
        _25335 = (_25337 != 0);
L5: 
        if (_25335 == 0) {
            goto L6; // [108] 148
        }
        _2 = (int)SEQ_PTR(_50line_map_48104);
        _25339 = (int)*(((s1_ptr)_2)->base + _file_48447);
        if (_25339 == 0) {
            _25339 = NOVALUE;
            goto L6; // [119] 148
        }
        else {
            if (!IS_ATOM_INT(_25339) && DBL_PTR(_25339)->dbl == 0.0){
                _25339 = NOVALUE;
                goto L6; // [119] 148
            }
            _25339 = NOVALUE;
        }
        _25339 = NOVALUE;

        /** 			integer line = sline[LINE]*/
        _2 = (int)SEQ_PTR(_sline_48443);
        _line_48457 = (int)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_line_48457))
        _line_48457 = (long)DBL_PTR(_line_48457)->dbl;

        /** 			map:put( line_map[file], line, 0, map:ADD )*/
        _2 = (int)SEQ_PTR(_50line_map_48104);
        _25341 = (int)*(((s1_ptr)_2)->base + _file_48447);
        Ref(_25341);
        _28put(_25341, _line_48457, 0, 2, 23);
        _25341 = NOVALUE;
L6: 
        DeRef(_sline_48443);
        _sline_48443 = NOVALUE;

        /** 	end for*/
        _i_48441 = _i_48441 + 1;
        goto L3; // [154] 59
L4: 
        ;
    }

    /** end procedure*/
    _25331 = NOVALUE;
    _25333 = NOVALUE;
    DeRef(_25337);
    _25337 = NOVALUE;
    return;
    ;
}


void _50cover_line(int _gline_number_48463)
{
    int _sline_48473 = NOVALUE;
    int _file_48476 = NOVALUE;
    int _line_48481 = NOVALUE;
    int _25350 = NOVALUE;
    int _25347 = NOVALUE;
    int _25344 = NOVALUE;
    int _25343 = NOVALUE;
    int _25342 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_gline_number_48463)) {
        _1 = (long)(DBL_PTR(_gline_number_48463)->dbl);
        DeRefDS(_gline_number_48463);
        _gline_number_48463 = _1;
    }

    /** 	if atom(slist[$]) then*/
    if (IS_SEQUENCE(_35slist_16334)){
            _25342 = SEQ_PTR(_35slist_16334)->length;
    }
    else {
        _25342 = 1;
    }
    _2 = (int)SEQ_PTR(_35slist_16334);
    _25343 = (int)*(((s1_ptr)_2)->base + _25342);
    _25344 = IS_ATOM(_25343);
    _25343 = NOVALUE;
    if (_25344 == 0)
    {
        _25344 = NOVALUE;
        goto L1; // [17] 31
    }
    else{
        _25344 = NOVALUE;
    }

    /** 		slist = s_expand(slist)*/
    RefDS(_35slist_16334);
    _0 = _61s_expand(_35slist_16334);
    DeRefDS(_35slist_16334);
    _35slist_16334 = _0;
L1: 

    /** 	sequence sline = slist[gline_number]*/
    DeRef(_sline_48473);
    _2 = (int)SEQ_PTR(_35slist_16334);
    _sline_48473 = (int)*(((s1_ptr)_2)->base + _gline_number_48463);
    Ref(_sline_48473);

    /** 	integer file = file_coverage[sline[LOCAL_FILE_NO]]*/
    _2 = (int)SEQ_PTR(_sline_48473);
    _25347 = (int)*(((s1_ptr)_2)->base + 3);
    _2 = (int)SEQ_PTR(_50file_coverage_48100);
    if (!IS_ATOM_INT(_25347)){
        _file_48476 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_25347)->dbl));
    }
    else{
        _file_48476 = (int)*(((s1_ptr)_2)->base + _25347);
    }

    /** 	if file then*/
    if (_file_48476 == 0)
    {
        goto L2; // [57] 86
    }
    else{
    }

    /** 		integer line = sline[LINE]*/
    _2 = (int)SEQ_PTR(_sline_48473);
    _line_48481 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_line_48481))
    _line_48481 = (long)DBL_PTR(_line_48481)->dbl;

    /** 		map:put( line_map[file], line, 1, map:ADD )*/
    _2 = (int)SEQ_PTR(_50line_map_48104);
    _25350 = (int)*(((s1_ptr)_2)->base + _file_48476);
    Ref(_25350);
    _28put(_25350, _line_48481, 1, 2, 23);
    _25350 = NOVALUE;
L2: 

    /** end procedure*/
    DeRef(_sline_48473);
    _25347 = NOVALUE;
    return;
    ;
}


void _50cover_routine(int _sub_48488)
{
    int _file_no_48489 = NOVALUE;
    int _25355 = NOVALUE;
    int _25354 = NOVALUE;
    int _25353 = NOVALUE;
    int _25351 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_sub_48488)) {
        _1 = (long)(DBL_PTR(_sub_48488)->dbl);
        DeRefDS(_sub_48488);
        _sub_48488 = _1;
    }

    /** 	integer file_no = SymTab[sub][S_FILE_NO]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _25351 = (int)*(((s1_ptr)_2)->base + _sub_48488);
    _2 = (int)SEQ_PTR(_25351);
    if (!IS_ATOM_INT(_35S_FILE_NO_15913)){
        _file_no_48489 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FILE_NO_15913)->dbl));
    }
    else{
        _file_no_48489 = (int)*(((s1_ptr)_2)->base + _35S_FILE_NO_15913);
    }
    if (!IS_ATOM_INT(_file_no_48489)){
        _file_no_48489 = (long)DBL_PTR(_file_no_48489)->dbl;
    }
    _25351 = NOVALUE;

    /** 	map:put( routine_map[file_coverage[file_no]], sym_name( sub ), 1, map:ADD )*/
    _2 = (int)SEQ_PTR(_50file_coverage_48100);
    _25353 = (int)*(((s1_ptr)_2)->base + _file_no_48489);
    _2 = (int)SEQ_PTR(_50routine_map_48105);
    _25354 = (int)*(((s1_ptr)_2)->base + _25353);
    _25355 = _53sym_name(_sub_48488);
    Ref(_25354);
    _28put(_25354, _25355, 1, 2, 23);
    _25354 = NOVALUE;
    _25355 = NOVALUE;

    /** end procedure*/
    _25353 = NOVALUE;
    return;
    ;
}


int _50has_coverage()
{
    int _25356 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return length( covered_files )*/
    if (IS_SEQUENCE(_50covered_files_48099)){
            _25356 = SEQ_PTR(_50covered_files_48099)->length;
    }
    else {
        _25356 = 1;
    }
    return _25356;
    ;
}



// 0x326EBE5C
