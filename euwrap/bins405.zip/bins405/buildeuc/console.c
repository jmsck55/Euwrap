// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

void _5any_key(int _prompt_13633, int _con_13635)
{
    int _wait_key_inlined_wait_key_at_27_13640 = NOVALUE;
    int _7589 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not find(con, {1,2}) then*/
    _7589 = find_from(_con_13635, _7111, 1);
    if (_7589 != 0)
    goto L1; // [12] 21
    _7589 = NOVALUE;

    /** 		con = 1*/
    _con_13635 = 1;
L1: 

    /** 	puts(con, prompt)*/
    EPuts(_con_13635, _prompt_13633); // DJP 

    /** 	wait_key()*/

    /** 	return machine_func(M_WAIT_KEY, 0)*/
    _wait_key_inlined_wait_key_at_27_13640 = machine(26, 0);

    /** 	puts(con, "\n")*/
    EPuts(_con_13635, _3128); // DJP 

    /** end procedure*/
    DeRefDS(_prompt_13633);
    return;
    ;
}


void _5maybe_any_key(int _prompt_13643, int _con_13644)
{
    int _has_console_inlined_has_console_at_6_13647 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not has_console() then*/

    /** 	return machine_func(M_HAS_CONSOLE, 0)*/
    DeRef(_has_console_inlined_has_console_at_6_13647);
    _has_console_inlined_has_console_at_6_13647 = machine(99, 0);
    if (IS_ATOM_INT(_has_console_inlined_has_console_at_6_13647)) {
        if (_has_console_inlined_has_console_at_6_13647 != 0){
            goto L1; // [14] 24
        }
    }
    else {
        if (DBL_PTR(_has_console_inlined_has_console_at_6_13647)->dbl != 0.0){
            goto L1; // [14] 24
        }
    }

    /** 		any_key(prompt, con)*/
    RefDS(_prompt_13643);
    _5any_key(_prompt_13643, _con_13644);
L1: 

    /** end procedure*/
    DeRefDS(_prompt_13643);
    return;
    ;
}



// 0x02FCBAB6
