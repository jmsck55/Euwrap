// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int _16find_all(int _needle_1390, int _haystack_1391, int _start_1392)
{
    int _kx_1393 = NOVALUE;
    int _543 = NOVALUE;
    int _542 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer kx = 0*/
    _kx_1393 = 0;

    /** 	while start with entry do*/
    goto L1; // [12] 39
L2: 
    if (_start_1392 == 0)
    {
        goto L3; // [15] 51
    }
    else{
    }

    /** 		kx += 1*/
    _kx_1393 = _kx_1393 + 1;

    /** 		haystack[kx] = start*/
    _2 = (int)SEQ_PTR(_haystack_1391);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _haystack_1391 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _kx_1393);
    _1 = *(int *)_2;
    *(int *)_2 = _start_1392;
    DeRef(_1);

    /** 		start += 1*/
    _start_1392 = _start_1392 + 1;

    /** 	entry*/
L1: 

    /** 		start = find(needle, haystack, start)*/
    _start_1392 = find_from(_needle_1390, _haystack_1391, _start_1392);

    /** 	end while*/
    goto L2; // [48] 15
L3: 

    /** 	haystack = remove( haystack, kx+1, length( haystack ) )*/
    _542 = _kx_1393 + 1;
    if (_542 > MAXINT){
        _542 = NewDouble((double)_542);
    }
    if (IS_SEQUENCE(_haystack_1391)){
            _543 = SEQ_PTR(_haystack_1391)->length;
    }
    else {
        _543 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_haystack_1391);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_542)) ? _542 : (long)(DBL_PTR(_542)->dbl);
        int stop = (IS_ATOM_INT(_543)) ? _543 : (long)(DBL_PTR(_543)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_haystack_1391), start, &_haystack_1391 );
            }
            else Tail(SEQ_PTR(_haystack_1391), stop+1, &_haystack_1391);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_haystack_1391), start, &_haystack_1391);
        }
        else {
            assign_slice_seq = &assign_space;
            _haystack_1391 = Remove_elements(start, stop, (SEQ_PTR(_haystack_1391)->ref == 1));
        }
    }
    DeRef(_542);
    _542 = NOVALUE;
    _543 = NOVALUE;

    /** 	return haystack*/
    return _haystack_1391;
    ;
}


int _16rfind(int _needle_1508, int _haystack_1509, int _start_1510)
{
    int _len_1512 = NOVALUE;
    int _604 = NOVALUE;
    int _603 = NOVALUE;
    int _600 = NOVALUE;
    int _599 = NOVALUE;
    int _597 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer len = length(haystack)*/
    if (IS_SEQUENCE(_haystack_1509)){
            _len_1512 = SEQ_PTR(_haystack_1509)->length;
    }
    else {
        _len_1512 = 1;
    }

    /** 	if start = 0 then start = len end if*/
    if (_start_1510 != 0)
    goto L1; // [12] 20
    _start_1510 = _len_1512;
L1: 

    /** 	if (start > len) or (len + start < 1) then*/
    _597 = (_start_1510 > _len_1512);
    if (_597 != 0) {
        goto L2; // [26] 43
    }
    _599 = _len_1512 + _start_1510;
    if ((long)((unsigned long)_599 + (unsigned long)HIGH_BITS) >= 0) 
    _599 = NewDouble((double)_599);
    if (IS_ATOM_INT(_599)) {
        _600 = (_599 < 1);
    }
    else {
        _600 = (DBL_PTR(_599)->dbl < (double)1);
    }
    DeRef(_599);
    _599 = NOVALUE;
    if (_600 == 0)
    {
        DeRef(_600);
        _600 = NOVALUE;
        goto L3; // [39] 50
    }
    else{
        DeRef(_600);
        _600 = NOVALUE;
    }
L2: 

    /** 		return 0*/
    DeRef(_needle_1508);
    DeRefDS(_haystack_1509);
    DeRef(_597);
    _597 = NOVALUE;
    return 0;
L3: 

    /** 	if start < 1 then*/
    if (_start_1510 >= 1)
    goto L4; // [52] 63

    /** 		start = len + start*/
    _start_1510 = _len_1512 + _start_1510;
L4: 

    /** 	for i = start to 1 by -1 do*/
    {
        int _i_1525;
        _i_1525 = _start_1510;
L5: 
        if (_i_1525 < 1){
            goto L6; // [65] 99
        }

        /** 		if equal(haystack[i], needle) then*/
        _2 = (int)SEQ_PTR(_haystack_1509);
        _603 = (int)*(((s1_ptr)_2)->base + _i_1525);
        if (_603 == _needle_1508)
        _604 = 1;
        else if (IS_ATOM_INT(_603) && IS_ATOM_INT(_needle_1508))
        _604 = 0;
        else
        _604 = (compare(_603, _needle_1508) == 0);
        _603 = NOVALUE;
        if (_604 == 0)
        {
            _604 = NOVALUE;
            goto L7; // [82] 92
        }
        else{
            _604 = NOVALUE;
        }

        /** 			return i*/
        DeRef(_needle_1508);
        DeRefDS(_haystack_1509);
        DeRef(_597);
        _597 = NOVALUE;
        return _i_1525;
L7: 

        /** 	end for*/
        _i_1525 = _i_1525 + -1;
        goto L5; // [94] 72
L6: 
        ;
    }

    /** 	return 0*/
    DeRef(_needle_1508);
    DeRefDS(_haystack_1509);
    DeRef(_597);
    _597 = NOVALUE;
    return 0;
    ;
}


int _16find_replace(int _needle_1531, int _haystack_1532, int _replacement_1533, int _max_1534)
{
    int _posn_1535 = NOVALUE;
    int _608 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer posn = 0*/
    _posn_1535 = 0;

    /** 	while posn != 0 entry do */
    goto L1; // [12] 45
L2: 
    if (_posn_1535 == 0)
    goto L3; // [15] 61

    /** 		haystack[posn] = replacement*/
    Ref(_replacement_1533);
    _2 = (int)SEQ_PTR(_haystack_1532);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _haystack_1532 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _posn_1535);
    _1 = *(int *)_2;
    *(int *)_2 = _replacement_1533;
    DeRef(_1);

    /** 		max -= 1*/
    _max_1534 = _max_1534 - 1;

    /** 		if max = 0 then*/
    if (_max_1534 != 0)
    goto L4; // [33] 42

    /** 			exit*/
    goto L3; // [39] 61
L4: 

    /** 	entry*/
L1: 

    /** 		posn = find(needle, haystack, posn + 1)*/
    _608 = _posn_1535 + 1;
    if (_608 > MAXINT){
        _608 = NewDouble((double)_608);
    }
    _posn_1535 = find_from(_needle_1531, _haystack_1532, _608);
    DeRef(_608);
    _608 = NOVALUE;

    /** 	end while*/
    goto L2; // [58] 15
L3: 

    /** 	return haystack*/
    DeRef(_needle_1531);
    DeRefi(_replacement_1533);
    return _haystack_1532;
    ;
}


int _16match_replace(int _needle_1545, int _haystack_1546, int _replacement_1547, int _max_1548)
{
    int _posn_1549 = NOVALUE;
    int _needle_len_1550 = NOVALUE;
    int _replacement_len_1551 = NOVALUE;
    int _scan_from_1552 = NOVALUE;
    int _cnt_1553 = NOVALUE;
    int _620 = NOVALUE;
    int _617 = NOVALUE;
    int _615 = NOVALUE;
    int _613 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if max < 0 then*/

    /** 	cnt = length(haystack)*/
    if (IS_SEQUENCE(_haystack_1546)){
            _cnt_1553 = SEQ_PTR(_haystack_1546)->length;
    }
    else {
        _cnt_1553 = 1;
    }

    /** 	if max != 0 then*/

    /** 	if atom(needle) then*/
    _613 = IS_ATOM(_needle_1545);
    if (_613 == 0)
    {
        _613 = NOVALUE;
        goto L1; // [40] 50
    }
    else{
        _613 = NOVALUE;
    }

    /** 		needle = {needle}*/
    _0 = _needle_1545;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_needle_1545);
    *((int *)(_2+4)) = _needle_1545;
    _needle_1545 = MAKE_SEQ(_1);
    DeRef(_0);
L1: 

    /** 	if atom(replacement) then*/
    _615 = IS_ATOM(_replacement_1547);
    if (_615 == 0)
    {
        _615 = NOVALUE;
        goto L2; // [55] 65
    }
    else{
        _615 = NOVALUE;
    }

    /** 		replacement = {replacement}*/
    _0 = _replacement_1547;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_replacement_1547);
    *((int *)(_2+4)) = _replacement_1547;
    _replacement_1547 = MAKE_SEQ(_1);
    DeRef(_0);
L2: 

    /** 	needle_len = length(needle) - 1*/
    if (IS_SEQUENCE(_needle_1545)){
            _617 = SEQ_PTR(_needle_1545)->length;
    }
    else {
        _617 = 1;
    }
    _needle_len_1550 = _617 - 1;
    _617 = NOVALUE;

    /** 	replacement_len = length(replacement)*/
    if (IS_SEQUENCE(_replacement_1547)){
            _replacement_len_1551 = SEQ_PTR(_replacement_1547)->length;
    }
    else {
        _replacement_len_1551 = 1;
    }

    /** 	scan_from = 1*/
    _scan_from_1552 = 1;

    /** 	while posn with entry do*/
    goto L3; // [86] 132
L4: 
    if (_posn_1549 == 0)
    {
        goto L5; // [91] 144
    }
    else{
    }

    /** 		haystack = replace(haystack, replacement, posn, posn + needle_len)*/
    _620 = _posn_1549 + _needle_len_1550;
    if ((long)((unsigned long)_620 + (unsigned long)HIGH_BITS) >= 0) 
    _620 = NewDouble((double)_620);
    {
        int p1 = _haystack_1546;
        int p2 = _replacement_1547;
        int p3 = _posn_1549;
        int p4 = _620;
        struct replace_block replace_params;
        replace_params.copy_to   = &p1;
        replace_params.copy_from = &p2;
        replace_params.start     = &p3;
        replace_params.stop      = &p4;
        replace_params.target    = &_haystack_1546;
        Replace( &replace_params );
    }
    DeRef(_620);
    _620 = NOVALUE;

    /** 		cnt -= 1*/
    _cnt_1553 = _cnt_1553 - 1;

    /** 		if cnt = 0 then*/
    if (_cnt_1553 != 0)
    goto L6; // [114] 123

    /** 			exit*/
    goto L5; // [120] 144
L6: 

    /** 		scan_from = posn + replacement_len*/
    _scan_from_1552 = _posn_1549 + _replacement_len_1551;

    /** 	entry*/
L3: 

    /** 		posn = match(needle, haystack, scan_from)*/
    _posn_1549 = e_match_from(_needle_1545, _haystack_1546, _scan_from_1552);

    /** 	end while*/
    goto L4; // [141] 89
L5: 

    /** 	return haystack*/
    DeRef(_needle_1545);
    DeRef(_replacement_1547);
    return _haystack_1546;
    ;
}


int _16binary_search(int _needle_1578, int _haystack_1579, int _start_point_1580, int _end_point_1581)
{
    int _lo_1582 = NOVALUE;
    int _hi_1583 = NOVALUE;
    int _mid_1584 = NOVALUE;
    int _c_1585 = NOVALUE;
    int _646 = NOVALUE;
    int _638 = NOVALUE;
    int _636 = NOVALUE;
    int _633 = NOVALUE;
    int _632 = NOVALUE;
    int _631 = NOVALUE;
    int _630 = NOVALUE;
    int _627 = NOVALUE;
    int _0, _1, _2;
    

    /** 	lo = start_point*/
    _lo_1582 = 1;

    /** 	if end_point <= 0 then*/
    if (_end_point_1581 > 0)
    goto L1; // [14] 30

    /** 		hi = length(haystack) + end_point*/
    if (IS_SEQUENCE(_haystack_1579)){
            _627 = SEQ_PTR(_haystack_1579)->length;
    }
    else {
        _627 = 1;
    }
    _hi_1583 = _627 + _end_point_1581;
    _627 = NOVALUE;
    goto L2; // [27] 36
L1: 

    /** 		hi = end_point*/
    _hi_1583 = _end_point_1581;
L2: 

    /** 	if lo<1 then*/
    if (_lo_1582 >= 1)
    goto L3; // [38] 48

    /** 		lo=1*/
    _lo_1582 = 1;
L3: 

    /** 	if lo > hi and length(haystack) > 0 then*/
    _630 = (_lo_1582 > _hi_1583);
    if (_630 == 0) {
        goto L4; // [56] 77
    }
    if (IS_SEQUENCE(_haystack_1579)){
            _632 = SEQ_PTR(_haystack_1579)->length;
    }
    else {
        _632 = 1;
    }
    _633 = (_632 > 0);
    _632 = NOVALUE;
    if (_633 == 0)
    {
        DeRef(_633);
        _633 = NOVALUE;
        goto L4; // [68] 77
    }
    else{
        DeRef(_633);
        _633 = NOVALUE;
    }

    /** 		hi = length(haystack)*/
    if (IS_SEQUENCE(_haystack_1579)){
            _hi_1583 = SEQ_PTR(_haystack_1579)->length;
    }
    else {
        _hi_1583 = 1;
    }
L4: 

    /** 	mid = start_point*/
    _mid_1584 = _start_point_1580;

    /** 	c = 0*/
    _c_1585 = 0;

    /** 	while lo <= hi do*/
L5: 
    if (_lo_1582 > _hi_1583)
    goto L6; // [92] 160

    /** 		mid = floor((lo + hi) / 2)*/
    _636 = _lo_1582 + _hi_1583;
    if ((long)((unsigned long)_636 + (unsigned long)HIGH_BITS) >= 0) 
    _636 = NewDouble((double)_636);
    if (IS_ATOM_INT(_636)) {
        _mid_1584 = _636 >> 1;
    }
    else {
        _1 = binary_op(DIVIDE, _636, 2);
        _mid_1584 = unary_op(FLOOR, _1);
        DeRef(_1);
    }
    DeRef(_636);
    _636 = NOVALUE;
    if (!IS_ATOM_INT(_mid_1584)) {
        _1 = (long)(DBL_PTR(_mid_1584)->dbl);
        DeRefDS(_mid_1584);
        _mid_1584 = _1;
    }

    /** 		c = eu:compare(needle, haystack[mid])*/
    _2 = (int)SEQ_PTR(_haystack_1579);
    _638 = (int)*(((s1_ptr)_2)->base + _mid_1584);
    if (IS_ATOM_INT(_needle_1578) && IS_ATOM_INT(_638)){
        _c_1585 = (_needle_1578 < _638) ? -1 : (_needle_1578 > _638);
    }
    else{
        _c_1585 = compare(_needle_1578, _638);
    }
    _638 = NOVALUE;

    /** 		if c < 0 then*/
    if (_c_1585 >= 0)
    goto L7; // [120] 133

    /** 			hi = mid - 1*/
    _hi_1583 = _mid_1584 - 1;
    goto L5; // [130] 92
L7: 

    /** 		elsif c > 0 then*/
    if (_c_1585 <= 0)
    goto L8; // [135] 148

    /** 			lo = mid + 1*/
    _lo_1582 = _mid_1584 + 1;
    goto L5; // [145] 92
L8: 

    /** 			return mid*/
    DeRefDS(_haystack_1579);
    DeRef(_630);
    _630 = NOVALUE;
    return _mid_1584;

    /** 	end while*/
    goto L5; // [157] 92
L6: 

    /** 	if c > 0 then*/
    if (_c_1585 <= 0)
    goto L9; // [162] 173

    /** 		mid += 1*/
    _mid_1584 = _mid_1584 + 1;
L9: 

    /** 	return -mid*/
    if ((unsigned long)_mid_1584 == 0xC0000000)
    _646 = (int)NewDouble((double)-0xC0000000);
    else
    _646 = - _mid_1584;
    DeRefDS(_haystack_1579);
    DeRef(_630);
    _630 = NOVALUE;
    return _646;
    ;
}


int _16begins(int _sub_text_1666, int _full_text_1667)
{
    int _684 = NOVALUE;
    int _683 = NOVALUE;
    int _682 = NOVALUE;
    int _680 = NOVALUE;
    int _679 = NOVALUE;
    int _678 = NOVALUE;
    int _677 = NOVALUE;
    int _676 = NOVALUE;
    int _674 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if length(full_text) = 0 then*/
    if (IS_SEQUENCE(_full_text_1667)){
            _674 = SEQ_PTR(_full_text_1667)->length;
    }
    else {
        _674 = 1;
    }
    if (_674 != 0)
    goto L1; // [8] 19

    /** 		return 0*/
    DeRef(_sub_text_1666);
    DeRefDS(_full_text_1667);
    return 0;
L1: 

    /** 	if atom(sub_text) then*/
    _676 = IS_ATOM(_sub_text_1666);
    if (_676 == 0)
    {
        _676 = NOVALUE;
        goto L2; // [24] 57
    }
    else{
        _676 = NOVALUE;
    }

    /** 		if equal(sub_text, full_text[1]) then*/
    _2 = (int)SEQ_PTR(_full_text_1667);
    _677 = (int)*(((s1_ptr)_2)->base + 1);
    if (_sub_text_1666 == _677)
    _678 = 1;
    else if (IS_ATOM_INT(_sub_text_1666) && IS_ATOM_INT(_677))
    _678 = 0;
    else
    _678 = (compare(_sub_text_1666, _677) == 0);
    _677 = NOVALUE;
    if (_678 == 0)
    {
        _678 = NOVALUE;
        goto L3; // [37] 49
    }
    else{
        _678 = NOVALUE;
    }

    /** 			return 1*/
    DeRef(_sub_text_1666);
    DeRefDS(_full_text_1667);
    return 1;
    goto L4; // [46] 56
L3: 

    /** 			return 0*/
    DeRef(_sub_text_1666);
    DeRefDS(_full_text_1667);
    return 0;
L4: 
L2: 

    /** 	if length(sub_text) > length(full_text) then*/
    if (IS_SEQUENCE(_sub_text_1666)){
            _679 = SEQ_PTR(_sub_text_1666)->length;
    }
    else {
        _679 = 1;
    }
    if (IS_SEQUENCE(_full_text_1667)){
            _680 = SEQ_PTR(_full_text_1667)->length;
    }
    else {
        _680 = 1;
    }
    if (_679 <= _680)
    goto L5; // [65] 76

    /** 		return 0*/
    DeRef(_sub_text_1666);
    DeRefDS(_full_text_1667);
    return 0;
L5: 

    /** 	if equal(sub_text, full_text[1.. length(sub_text)]) then*/
    if (IS_SEQUENCE(_sub_text_1666)){
            _682 = SEQ_PTR(_sub_text_1666)->length;
    }
    else {
        _682 = 1;
    }
    rhs_slice_target = (object_ptr)&_683;
    RHS_Slice(_full_text_1667, 1, _682);
    if (_sub_text_1666 == _683)
    _684 = 1;
    else if (IS_ATOM_INT(_sub_text_1666) && IS_ATOM_INT(_683))
    _684 = 0;
    else
    _684 = (compare(_sub_text_1666, _683) == 0);
    DeRefDS(_683);
    _683 = NOVALUE;
    if (_684 == 0)
    {
        _684 = NOVALUE;
        goto L6; // [90] 102
    }
    else{
        _684 = NOVALUE;
    }

    /** 		return 1*/
    DeRef(_sub_text_1666);
    DeRefDS(_full_text_1667);
    return 1;
    goto L7; // [99] 109
L6: 

    /** 		return 0*/
    DeRef(_sub_text_1666);
    DeRefDS(_full_text_1667);
    return 0;
L7: 
    ;
}


int _16ends(int _sub_text_1688, int _full_text_1689)
{
    int _700 = NOVALUE;
    int _699 = NOVALUE;
    int _698 = NOVALUE;
    int _697 = NOVALUE;
    int _696 = NOVALUE;
    int _695 = NOVALUE;
    int _694 = NOVALUE;
    int _692 = NOVALUE;
    int _691 = NOVALUE;
    int _690 = NOVALUE;
    int _689 = NOVALUE;
    int _688 = NOVALUE;
    int _687 = NOVALUE;
    int _685 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if length(full_text) = 0 then*/
    if (IS_SEQUENCE(_full_text_1689)){
            _685 = SEQ_PTR(_full_text_1689)->length;
    }
    else {
        _685 = 1;
    }
    if (_685 != 0)
    goto L1; // [8] 19

    /** 		return 0*/
    DeRefDSi(_sub_text_1688);
    DeRefDS(_full_text_1689);
    return 0;
L1: 

    /** 	if atom(sub_text) then*/
    _687 = IS_ATOM(_sub_text_1688);
    if (_687 == 0)
    {
        _687 = NOVALUE;
        goto L2; // [24] 60
    }
    else{
        _687 = NOVALUE;
    }

    /** 		if equal(sub_text, full_text[$]) then*/
    if (IS_SEQUENCE(_full_text_1689)){
            _688 = SEQ_PTR(_full_text_1689)->length;
    }
    else {
        _688 = 1;
    }
    _2 = (int)SEQ_PTR(_full_text_1689);
    _689 = (int)*(((s1_ptr)_2)->base + _688);
    if (_sub_text_1688 == _689)
    _690 = 1;
    else if (IS_ATOM_INT(_sub_text_1688) && IS_ATOM_INT(_689))
    _690 = 0;
    else
    _690 = (compare(_sub_text_1688, _689) == 0);
    _689 = NOVALUE;
    if (_690 == 0)
    {
        _690 = NOVALUE;
        goto L3; // [40] 52
    }
    else{
        _690 = NOVALUE;
    }

    /** 			return 1*/
    DeRefi(_sub_text_1688);
    DeRefDS(_full_text_1689);
    return 1;
    goto L4; // [49] 59
L3: 

    /** 			return 0*/
    DeRefi(_sub_text_1688);
    DeRefDS(_full_text_1689);
    return 0;
L4: 
L2: 

    /** 	if length(sub_text) > length(full_text) then*/
    if (IS_SEQUENCE(_sub_text_1688)){
            _691 = SEQ_PTR(_sub_text_1688)->length;
    }
    else {
        _691 = 1;
    }
    if (IS_SEQUENCE(_full_text_1689)){
            _692 = SEQ_PTR(_full_text_1689)->length;
    }
    else {
        _692 = 1;
    }
    if (_691 <= _692)
    goto L5; // [68] 79

    /** 		return 0*/
    DeRefi(_sub_text_1688);
    DeRefDS(_full_text_1689);
    return 0;
L5: 

    /** 	if equal(sub_text, full_text[$ - length(sub_text) + 1 .. $]) then*/
    if (IS_SEQUENCE(_full_text_1689)){
            _694 = SEQ_PTR(_full_text_1689)->length;
    }
    else {
        _694 = 1;
    }
    if (IS_SEQUENCE(_sub_text_1688)){
            _695 = SEQ_PTR(_sub_text_1688)->length;
    }
    else {
        _695 = 1;
    }
    _696 = _694 - _695;
    _694 = NOVALUE;
    _695 = NOVALUE;
    _697 = _696 + 1;
    _696 = NOVALUE;
    if (IS_SEQUENCE(_full_text_1689)){
            _698 = SEQ_PTR(_full_text_1689)->length;
    }
    else {
        _698 = 1;
    }
    rhs_slice_target = (object_ptr)&_699;
    RHS_Slice(_full_text_1689, _697, _698);
    if (_sub_text_1688 == _699)
    _700 = 1;
    else if (IS_ATOM_INT(_sub_text_1688) && IS_ATOM_INT(_699))
    _700 = 0;
    else
    _700 = (compare(_sub_text_1688, _699) == 0);
    DeRefDS(_699);
    _699 = NOVALUE;
    if (_700 == 0)
    {
        _700 = NOVALUE;
        goto L6; // [107] 119
    }
    else{
        _700 = NOVALUE;
    }

    /** 		return 1*/
    DeRefi(_sub_text_1688);
    DeRefDS(_full_text_1689);
    _697 = NOVALUE;
    return 1;
    goto L7; // [116] 126
L6: 

    /** 		return 0*/
    DeRefi(_sub_text_1688);
    DeRefDS(_full_text_1689);
    DeRef(_697);
    _697 = NOVALUE;
    return 0;
L7: 
    ;
}



// 0x23794E60
