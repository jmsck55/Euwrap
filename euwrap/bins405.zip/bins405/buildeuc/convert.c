// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int _15int_to_bytes(int _x_1832)
{
    int _a_1833 = NOVALUE;
    int _b_1834 = NOVALUE;
    int _c_1835 = NOVALUE;
    int _d_1836 = NOVALUE;
    int _773 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = remainder(x, #100)*/
    if (IS_ATOM_INT(_x_1832)) {
        _a_1833 = (_x_1832 % 256);
    }
    else {
        temp_d.dbl = (double)256;
        _a_1833 = Dremainder(DBL_PTR(_x_1832), &temp_d);
    }
    if (!IS_ATOM_INT(_a_1833)) {
        _1 = (long)(DBL_PTR(_a_1833)->dbl);
        DeRefDS(_a_1833);
        _a_1833 = _1;
    }

    /** 	x = floor(x / #100)*/
    _0 = _x_1832;
    if (IS_ATOM_INT(_x_1832)) {
        if (256 > 0 && _x_1832 >= 0) {
            _x_1832 = _x_1832 / 256;
        }
        else {
            temp_dbl = floor((double)_x_1832 / (double)256);
            if (_x_1832 != MININT)
            _x_1832 = (long)temp_dbl;
            else
            _x_1832 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x_1832, 256);
        _x_1832 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    DeRef(_0);

    /** 	b = remainder(x, #100)*/
    if (IS_ATOM_INT(_x_1832)) {
        _b_1834 = (_x_1832 % 256);
    }
    else {
        temp_d.dbl = (double)256;
        _b_1834 = Dremainder(DBL_PTR(_x_1832), &temp_d);
    }
    if (!IS_ATOM_INT(_b_1834)) {
        _1 = (long)(DBL_PTR(_b_1834)->dbl);
        DeRefDS(_b_1834);
        _b_1834 = _1;
    }

    /** 	x = floor(x / #100)*/
    _0 = _x_1832;
    if (IS_ATOM_INT(_x_1832)) {
        if (256 > 0 && _x_1832 >= 0) {
            _x_1832 = _x_1832 / 256;
        }
        else {
            temp_dbl = floor((double)_x_1832 / (double)256);
            if (_x_1832 != MININT)
            _x_1832 = (long)temp_dbl;
            else
            _x_1832 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x_1832, 256);
        _x_1832 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    DeRef(_0);

    /** 	c = remainder(x, #100)*/
    if (IS_ATOM_INT(_x_1832)) {
        _c_1835 = (_x_1832 % 256);
    }
    else {
        temp_d.dbl = (double)256;
        _c_1835 = Dremainder(DBL_PTR(_x_1832), &temp_d);
    }
    if (!IS_ATOM_INT(_c_1835)) {
        _1 = (long)(DBL_PTR(_c_1835)->dbl);
        DeRefDS(_c_1835);
        _c_1835 = _1;
    }

    /** 	x = floor(x / #100)*/
    _0 = _x_1832;
    if (IS_ATOM_INT(_x_1832)) {
        if (256 > 0 && _x_1832 >= 0) {
            _x_1832 = _x_1832 / 256;
        }
        else {
            temp_dbl = floor((double)_x_1832 / (double)256);
            if (_x_1832 != MININT)
            _x_1832 = (long)temp_dbl;
            else
            _x_1832 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x_1832, 256);
        _x_1832 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    DeRef(_0);

    /** 	d = remainder(x, #100)*/
    if (IS_ATOM_INT(_x_1832)) {
        _d_1836 = (_x_1832 % 256);
    }
    else {
        temp_d.dbl = (double)256;
        _d_1836 = Dremainder(DBL_PTR(_x_1832), &temp_d);
    }
    if (!IS_ATOM_INT(_d_1836)) {
        _1 = (long)(DBL_PTR(_d_1836)->dbl);
        DeRefDS(_d_1836);
        _d_1836 = _1;
    }

    /** 	return {a,b,c,d}*/
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _a_1833;
    *((int *)(_2+8)) = _b_1834;
    *((int *)(_2+12)) = _c_1835;
    *((int *)(_2+16)) = _d_1836;
    _773 = MAKE_SEQ(_1);
    DeRef(_x_1832);
    return _773;
    ;
}


int _15int_to_bits(int _x_1874, int _nbits_1875)
{
    int _bits_1876 = NOVALUE;
    int _mask_1877 = NOVALUE;
    int _799 = NOVALUE;
    int _798 = NOVALUE;
    int _796 = NOVALUE;
    int _793 = NOVALUE;
    int _792 = NOVALUE;
    int _791 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if nbits < 1 then*/

    /** 	bits = repeat(0, nbits)*/
    DeRef(_bits_1876);
    _bits_1876 = Repeat(0, _nbits_1875);

    /** 	if nbits <= 32 then*/

    /** 		mask = 1*/
    DeRef(_mask_1877);
    _mask_1877 = 1;

    /** 		for i = 1 to nbits do*/
    _791 = _nbits_1875;
    {
        int _i_1884;
        _i_1884 = 1;
L1: 
        if (_i_1884 > _791){
            goto L2; // [38] 72
        }

        /** 			bits[i] = and_bits(x, mask) and 1*/
        if (IS_ATOM_INT(_x_1874) && IS_ATOM_INT(_mask_1877)) {
            {unsigned long tu;
                 tu = (unsigned long)_x_1874 & (unsigned long)_mask_1877;
                 _792 = MAKE_UINT(tu);
            }
        }
        else {
            if (IS_ATOM_INT(_x_1874)) {
                temp_d.dbl = (double)_x_1874;
                _792 = Dand_bits(&temp_d, DBL_PTR(_mask_1877));
            }
            else {
                if (IS_ATOM_INT(_mask_1877)) {
                    temp_d.dbl = (double)_mask_1877;
                    _792 = Dand_bits(DBL_PTR(_x_1874), &temp_d);
                }
                else
                _792 = Dand_bits(DBL_PTR(_x_1874), DBL_PTR(_mask_1877));
            }
        }
        if (IS_ATOM_INT(_792)) {
            _793 = (_792 != 0 && 1 != 0);
        }
        else {
            temp_d.dbl = (double)1;
            _793 = Dand(DBL_PTR(_792), &temp_d);
        }
        DeRef(_792);
        _792 = NOVALUE;
        _2 = (int)SEQ_PTR(_bits_1876);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _bits_1876 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_1884);
        _1 = *(int *)_2;
        *(int *)_2 = _793;
        if( _1 != _793 ){
            DeRef(_1);
        }
        _793 = NOVALUE;

        /** 			mask *= 2*/
        _0 = _mask_1877;
        if (IS_ATOM_INT(_mask_1877) && IS_ATOM_INT(_mask_1877)) {
            _mask_1877 = _mask_1877 + _mask_1877;
            if ((long)((unsigned long)_mask_1877 + (unsigned long)HIGH_BITS) >= 0) 
            _mask_1877 = NewDouble((double)_mask_1877);
        }
        else {
            if (IS_ATOM_INT(_mask_1877)) {
                _mask_1877 = NewDouble((double)_mask_1877 + DBL_PTR(_mask_1877)->dbl);
            }
            else {
                if (IS_ATOM_INT(_mask_1877)) {
                    _mask_1877 = NewDouble(DBL_PTR(_mask_1877)->dbl + (double)_mask_1877);
                }
                else
                _mask_1877 = NewDouble(DBL_PTR(_mask_1877)->dbl + DBL_PTR(_mask_1877)->dbl);
            }
        }
        DeRef(_0);

        /** 		end for*/
        _i_1884 = _i_1884 + 1;
        goto L1; // [67] 45
L2: 
        ;
    }
    goto L3; // [72] 128

    /** 		if x < 0 then*/
    if (binary_op_a(GREATEREQ, _x_1874, 0)){
        goto L4; // [77] 92
    }

    /** 			x += power(2, nbits) -- for 2's complement bit pattern*/
    _796 = power(2, _nbits_1875);
    _0 = _x_1874;
    if (IS_ATOM_INT(_x_1874) && IS_ATOM_INT(_796)) {
        _x_1874 = _x_1874 + _796;
        if ((long)((unsigned long)_x_1874 + (unsigned long)HIGH_BITS) >= 0) 
        _x_1874 = NewDouble((double)_x_1874);
    }
    else {
        if (IS_ATOM_INT(_x_1874)) {
            _x_1874 = NewDouble((double)_x_1874 + DBL_PTR(_796)->dbl);
        }
        else {
            if (IS_ATOM_INT(_796)) {
                _x_1874 = NewDouble(DBL_PTR(_x_1874)->dbl + (double)_796);
            }
            else
            _x_1874 = NewDouble(DBL_PTR(_x_1874)->dbl + DBL_PTR(_796)->dbl);
        }
    }
    DeRef(_0);
    DeRef(_796);
    _796 = NOVALUE;
L4: 

    /** 		for i = 1 to nbits do*/
    _798 = _nbits_1875;
    {
        int _i_1895;
        _i_1895 = 1;
L5: 
        if (_i_1895 > _798){
            goto L6; // [97] 127
        }

        /** 			bits[i] = remainder(x, 2)*/
        if (IS_ATOM_INT(_x_1874)) {
            _799 = (_x_1874 % 2);
        }
        else {
            temp_d.dbl = (double)2;
            _799 = Dremainder(DBL_PTR(_x_1874), &temp_d);
        }
        _2 = (int)SEQ_PTR(_bits_1876);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _bits_1876 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_1895);
        _1 = *(int *)_2;
        *(int *)_2 = _799;
        if( _1 != _799 ){
            DeRef(_1);
        }
        _799 = NOVALUE;

        /** 			x = floor(x / 2)*/
        _0 = _x_1874;
        if (IS_ATOM_INT(_x_1874)) {
            _x_1874 = _x_1874 >> 1;
        }
        else {
            _1 = binary_op(DIVIDE, _x_1874, 2);
            _x_1874 = unary_op(FLOOR, _1);
            DeRef(_1);
        }
        DeRef(_0);

        /** 		end for*/
        _i_1895 = _i_1895 + 1;
        goto L5; // [122] 104
L6: 
        ;
    }
L3: 

    /** 	return bits*/
    DeRef(_x_1874);
    DeRef(_mask_1877);
    return _bits_1876;
    ;
}


int _15bits_to_int(int _bits_1901)
{
    int _value_1902 = NOVALUE;
    int _p_1903 = NOVALUE;
    int _802 = NOVALUE;
    int _801 = NOVALUE;
    int _0, _1, _2;
    

    /** 	value = 0*/
    DeRef(_value_1902);
    _value_1902 = 0;

    /** 	p = 1*/
    DeRef(_p_1903);
    _p_1903 = 1;

    /** 	for i = 1 to length(bits) do*/
    if (IS_SEQUENCE(_bits_1901)){
            _801 = SEQ_PTR(_bits_1901)->length;
    }
    else {
        _801 = 1;
    }
    {
        int _i_1905;
        _i_1905 = 1;
L1: 
        if (_i_1905 > _801){
            goto L2; // [18] 54
        }

        /** 		if bits[i] then*/
        _2 = (int)SEQ_PTR(_bits_1901);
        _802 = (int)*(((s1_ptr)_2)->base + _i_1905);
        if (_802 == 0) {
            _802 = NOVALUE;
            goto L3; // [31] 41
        }
        else {
            if (!IS_ATOM_INT(_802) && DBL_PTR(_802)->dbl == 0.0){
                _802 = NOVALUE;
                goto L3; // [31] 41
            }
            _802 = NOVALUE;
        }
        _802 = NOVALUE;

        /** 			value += p*/
        _0 = _value_1902;
        if (IS_ATOM_INT(_value_1902) && IS_ATOM_INT(_p_1903)) {
            _value_1902 = _value_1902 + _p_1903;
            if ((long)((unsigned long)_value_1902 + (unsigned long)HIGH_BITS) >= 0) 
            _value_1902 = NewDouble((double)_value_1902);
        }
        else {
            if (IS_ATOM_INT(_value_1902)) {
                _value_1902 = NewDouble((double)_value_1902 + DBL_PTR(_p_1903)->dbl);
            }
            else {
                if (IS_ATOM_INT(_p_1903)) {
                    _value_1902 = NewDouble(DBL_PTR(_value_1902)->dbl + (double)_p_1903);
                }
                else
                _value_1902 = NewDouble(DBL_PTR(_value_1902)->dbl + DBL_PTR(_p_1903)->dbl);
            }
        }
        DeRef(_0);
L3: 

        /** 		p += p*/
        _0 = _p_1903;
        if (IS_ATOM_INT(_p_1903) && IS_ATOM_INT(_p_1903)) {
            _p_1903 = _p_1903 + _p_1903;
            if ((long)((unsigned long)_p_1903 + (unsigned long)HIGH_BITS) >= 0) 
            _p_1903 = NewDouble((double)_p_1903);
        }
        else {
            if (IS_ATOM_INT(_p_1903)) {
                _p_1903 = NewDouble((double)_p_1903 + DBL_PTR(_p_1903)->dbl);
            }
            else {
                if (IS_ATOM_INT(_p_1903)) {
                    _p_1903 = NewDouble(DBL_PTR(_p_1903)->dbl + (double)_p_1903);
                }
                else
                _p_1903 = NewDouble(DBL_PTR(_p_1903)->dbl + DBL_PTR(_p_1903)->dbl);
            }
        }
        DeRef(_0);

        /** 	end for*/
        _i_1905 = _i_1905 + 1;
        goto L1; // [49] 25
L2: 
        ;
    }

    /** 	return value*/
    DeRefDS(_bits_1901);
    DeRef(_p_1903);
    return _value_1902;
    ;
}


int _15atom_to_float64(int _a_1913)
{
    int _805 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return machine_func(M_A_TO_F64, a)*/
    _805 = machine(46, _a_1913);
    DeRef(_a_1913);
    return _805;
    ;
}


int _15atom_to_float32(int _a_1917)
{
    int _806 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return machine_func(M_A_TO_F32, a)*/
    _806 = machine(48, _a_1917);
    DeRef(_a_1917);
    return _806;
    ;
}


int _15float64_to_atom(int _ieee64_1921)
{
    int _807 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return machine_func(M_F64_TO_A, ieee64)*/
    _807 = machine(47, _ieee64_1921);
    DeRefDS(_ieee64_1921);
    return _807;
    ;
}


int _15float32_to_atom(int _ieee32_1925)
{
    int _808 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return machine_func(M_F32_TO_A, ieee32)*/
    _808 = machine(49, _ieee32_1925);
    DeRefDS(_ieee32_1925);
    return _808;
    ;
}


int _15to_number(int _text_in_2004, int _return_bad_pos_2005)
{
    int _lDotFound_2006 = NOVALUE;
    int _lSignFound_2007 = NOVALUE;
    int _lCharValue_2008 = NOVALUE;
    int _lBadPos_2009 = NOVALUE;
    int _lLeftSize_2010 = NOVALUE;
    int _lRightSize_2011 = NOVALUE;
    int _lLeftValue_2012 = NOVALUE;
    int _lRightValue_2013 = NOVALUE;
    int _lBase_2014 = NOVALUE;
    int _lPercent_2015 = NOVALUE;
    int _lResult_2016 = NOVALUE;
    int _lDigitCount_2017 = NOVALUE;
    int _lCurrencyFound_2018 = NOVALUE;
    int _lLastDigit_2019 = NOVALUE;
    int _lChar_2020 = NOVALUE;
    int _931 = NOVALUE;
    int _930 = NOVALUE;
    int _923 = NOVALUE;
    int _921 = NOVALUE;
    int _920 = NOVALUE;
    int _915 = NOVALUE;
    int _914 = NOVALUE;
    int _913 = NOVALUE;
    int _912 = NOVALUE;
    int _911 = NOVALUE;
    int _910 = NOVALUE;
    int _906 = NOVALUE;
    int _902 = NOVALUE;
    int _894 = NOVALUE;
    int _882 = NOVALUE;
    int _881 = NOVALUE;
    int _875 = NOVALUE;
    int _873 = NOVALUE;
    int _867 = NOVALUE;
    int _866 = NOVALUE;
    int _865 = NOVALUE;
    int _864 = NOVALUE;
    int _863 = NOVALUE;
    int _862 = NOVALUE;
    int _861 = NOVALUE;
    int _860 = NOVALUE;
    int _859 = NOVALUE;
    int _851 = NOVALUE;
    int _850 = NOVALUE;
    int _849 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer lDotFound = 0*/
    _lDotFound_2006 = 0;

    /** 	integer lSignFound = 2*/
    _lSignFound_2007 = 2;

    /** 	integer lBadPos = 0*/
    _lBadPos_2009 = 0;

    /** 	atom    lLeftSize = 0*/
    DeRef(_lLeftSize_2010);
    _lLeftSize_2010 = 0;

    /** 	atom    lRightSize = 1*/
    DeRef(_lRightSize_2011);
    _lRightSize_2011 = 1;

    /** 	atom    lLeftValue = 0*/
    DeRef(_lLeftValue_2012);
    _lLeftValue_2012 = 0;

    /** 	atom    lRightValue = 0*/
    DeRef(_lRightValue_2013);
    _lRightValue_2013 = 0;

    /** 	integer lBase = 10*/
    _lBase_2014 = 10;

    /** 	integer lPercent = 1*/
    _lPercent_2015 = 1;

    /** 	integer lDigitCount = 0*/
    _lDigitCount_2017 = 0;

    /** 	integer lCurrencyFound = 0*/
    _lCurrencyFound_2018 = 0;

    /** 	integer lLastDigit = 0*/
    _lLastDigit_2019 = 0;

    /** 	for i = 1 to length(text_in) do*/
    if (IS_SEQUENCE(_text_in_2004)){
            _849 = SEQ_PTR(_text_in_2004)->length;
    }
    else {
        _849 = 1;
    }
    {
        int _i_2022;
        _i_2022 = 1;
L1: 
        if (_i_2022 > _849){
            goto L2; // [70] 672
        }

        /** 		if not integer(text_in[i]) then*/
        _2 = (int)SEQ_PTR(_text_in_2004);
        _850 = (int)*(((s1_ptr)_2)->base + _i_2022);
        if (IS_ATOM_INT(_850))
        _851 = 1;
        else if (IS_ATOM_DBL(_850))
        _851 = IS_ATOM_INT(DoubleToInt(_850));
        else
        _851 = 0;
        _850 = NOVALUE;
        if (_851 != 0)
        goto L3; // [86] 94
        _851 = NOVALUE;

        /** 			exit*/
        goto L2; // [91] 672
L3: 

        /** 		lChar = text_in[i]*/
        _2 = (int)SEQ_PTR(_text_in_2004);
        _lChar_2020 = (int)*(((s1_ptr)_2)->base + _i_2022);
        if (!IS_ATOM_INT(_lChar_2020))
        _lChar_2020 = (long)DBL_PTR(_lChar_2020)->dbl;

        /** 		switch lChar do*/
        _0 = _lChar_2020;
        switch ( _0 ){ 

            /** 			case '-' then*/
            case 45:

            /** 				if lSignFound = 2 then*/
            if (_lSignFound_2007 != 2)
            goto L4; // [113] 130

            /** 					lSignFound = -1*/
            _lSignFound_2007 = -1;

            /** 					lLastDigit = lDigitCount*/
            _lLastDigit_2019 = _lDigitCount_2017;
            goto L5; // [127] 654
L4: 

            /** 					lBadPos = i*/
            _lBadPos_2009 = _i_2022;
            goto L5; // [136] 654

            /** 			case '+' then*/
            case 43:

            /** 				if lSignFound = 2 then*/
            if (_lSignFound_2007 != 2)
            goto L6; // [144] 161

            /** 					lSignFound = 1*/
            _lSignFound_2007 = 1;

            /** 					lLastDigit = lDigitCount*/
            _lLastDigit_2019 = _lDigitCount_2017;
            goto L5; // [158] 654
L6: 

            /** 					lBadPos = i*/
            _lBadPos_2009 = _i_2022;
            goto L5; // [167] 654

            /** 			case '#' then*/
            case 35:

            /** 				if lDigitCount = 0 and lBase = 10 then*/
            _859 = (_lDigitCount_2017 == 0);
            if (_859 == 0) {
                goto L7; // [179] 199
            }
            _861 = (_lBase_2014 == 10);
            if (_861 == 0)
            {
                DeRef(_861);
                _861 = NOVALUE;
                goto L7; // [188] 199
            }
            else{
                DeRef(_861);
                _861 = NOVALUE;
            }

            /** 					lBase = 16*/
            _lBase_2014 = 16;
            goto L5; // [196] 654
L7: 

            /** 					lBadPos = i*/
            _lBadPos_2009 = _i_2022;
            goto L5; // [205] 654

            /** 			case '@' then*/
            case 64:

            /** 				if lDigitCount = 0  and lBase = 10 then*/
            _862 = (_lDigitCount_2017 == 0);
            if (_862 == 0) {
                goto L8; // [217] 237
            }
            _864 = (_lBase_2014 == 10);
            if (_864 == 0)
            {
                DeRef(_864);
                _864 = NOVALUE;
                goto L8; // [226] 237
            }
            else{
                DeRef(_864);
                _864 = NOVALUE;
            }

            /** 					lBase = 8*/
            _lBase_2014 = 8;
            goto L5; // [234] 654
L8: 

            /** 					lBadPos = i*/
            _lBadPos_2009 = _i_2022;
            goto L5; // [243] 654

            /** 			case '!' then*/
            case 33:

            /** 				if lDigitCount = 0  and lBase = 10 then*/
            _865 = (_lDigitCount_2017 == 0);
            if (_865 == 0) {
                goto L9; // [255] 275
            }
            _867 = (_lBase_2014 == 10);
            if (_867 == 0)
            {
                DeRef(_867);
                _867 = NOVALUE;
                goto L9; // [264] 275
            }
            else{
                DeRef(_867);
                _867 = NOVALUE;
            }

            /** 					lBase = 2*/
            _lBase_2014 = 2;
            goto L5; // [272] 654
L9: 

            /** 					lBadPos = i*/
            _lBadPos_2009 = _i_2022;
            goto L5; // [281] 654

            /** 			case '$', '�', '�', '�', '�' then*/
            case 36:
            case 163:
            case 164:
            case 165:
            case 128:

            /** 				if lCurrencyFound = 0 then*/
            if (_lCurrencyFound_2018 != 0)
            goto LA; // [297] 314

            /** 					lCurrencyFound = 1*/
            _lCurrencyFound_2018 = 1;

            /** 					lLastDigit = lDigitCount*/
            _lLastDigit_2019 = _lDigitCount_2017;
            goto L5; // [311] 654
LA: 

            /** 					lBadPos = i*/
            _lBadPos_2009 = _i_2022;
            goto L5; // [320] 654

            /** 			case '_' then -- grouping character*/
            case 95:

            /** 				if lDigitCount = 0 or lLastDigit != 0 then*/
            _873 = (_lDigitCount_2017 == 0);
            if (_873 != 0) {
                goto LB; // [332] 345
            }
            _875 = (_lLastDigit_2019 != 0);
            if (_875 == 0)
            {
                DeRef(_875);
                _875 = NOVALUE;
                goto L5; // [341] 654
            }
            else{
                DeRef(_875);
                _875 = NOVALUE;
            }
LB: 

            /** 					lBadPos = i*/
            _lBadPos_2009 = _i_2022;
            goto L5; // [351] 654

            /** 			case '.', ',' then*/
            case 46:
            case 44:

            /** 				if lLastDigit = 0 then*/
            if (_lLastDigit_2019 != 0)
            goto LC; // [361] 400

            /** 					if decimal_mark = lChar then*/
            if (46 != _lChar_2020)
            goto L5; // [369] 654

            /** 						if lDotFound = 0 then*/
            if (_lDotFound_2006 != 0)
            goto LD; // [375] 387

            /** 							lDotFound = 1*/
            _lDotFound_2006 = 1;
            goto L5; // [384] 654
LD: 

            /** 							lBadPos = i*/
            _lBadPos_2009 = _i_2022;
            goto L5; // [393] 654
            goto L5; // [397] 654
LC: 

            /** 					lBadPos = i*/
            _lBadPos_2009 = _i_2022;
            goto L5; // [406] 654

            /** 			case '%' then*/
            case 37:

            /** 				lLastDigit = lDigitCount*/
            _lLastDigit_2019 = _lDigitCount_2017;

            /** 				if lPercent = 1 then*/
            if (_lPercent_2015 != 1)
            goto LE; // [419] 431

            /** 					lPercent = 100*/
            _lPercent_2015 = 100;
            goto L5; // [428] 654
LE: 

            /** 					if text_in[i-1] = '%' then*/
            _881 = _i_2022 - 1;
            _2 = (int)SEQ_PTR(_text_in_2004);
            _882 = (int)*(((s1_ptr)_2)->base + _881);
            if (binary_op_a(NOTEQ, _882, 37)){
                _882 = NOVALUE;
                goto LF; // [441] 456
            }
            _882 = NOVALUE;

            /** 						lPercent *= 10 -- Yes ten not one hundred.*/
            _lPercent_2015 = _lPercent_2015 * 10;
            goto L5; // [453] 654
LF: 

            /** 						lBadPos = i*/
            _lBadPos_2009 = _i_2022;
            goto L5; // [463] 654

            /** 			case '\t', ' ', #A0 then*/
            case 9:
            case 32:
            case 160:

            /** 				if lDigitCount = 0 then*/
            if (_lDigitCount_2017 != 0)
            goto L10; // [475] 482
            goto L5; // [479] 654
L10: 

            /** 					lLastDigit = i*/
            _lLastDigit_2019 = _i_2022;
            goto L5; // [488] 654

            /** 			case '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',*/
            case 48:
            case 49:
            case 50:
            case 51:
            case 52:
            case 53:
            case 54:
            case 55:
            case 56:
            case 57:
            case 65:
            case 66:
            case 67:
            case 68:
            case 69:
            case 70:
            case 97:
            case 98:
            case 99:
            case 100:
            case 101:
            case 102:

            /** 	            lCharValue = find(lChar, vDigits) - 1*/
            _894 = find_from(_lChar_2020, _15vDigits_1990, 1);
            _lCharValue_2008 = _894 - 1;
            _894 = NOVALUE;

            /** 	            if lCharValue > 15 then*/
            if (_lCharValue_2008 <= 15)
            goto L11; // [549] 560

            /** 	            	lCharValue -= 6*/
            _lCharValue_2008 = _lCharValue_2008 - 6;
L11: 

            /** 	            if lCharValue >= lBase then*/
            if (_lCharValue_2008 < _lBase_2014)
            goto L12; // [562] 574

            /** 	                lBadPos = i*/
            _lBadPos_2009 = _i_2022;
            goto L5; // [571] 654
L12: 

            /** 	            elsif lLastDigit != 0 then  -- shouldn't be any more digits*/
            if (_lLastDigit_2019 == 0)
            goto L13; // [576] 588

            /** 					lBadPos = i*/
            _lBadPos_2009 = _i_2022;
            goto L5; // [585] 654
L13: 

            /** 				elsif lDotFound = 1 then*/
            if (_lDotFound_2006 != 1)
            goto L14; // [590] 619

            /** 					lRightSize *= lBase*/
            _0 = _lRightSize_2011;
            if (IS_ATOM_INT(_lRightSize_2011)) {
                if (_lRightSize_2011 == (short)_lRightSize_2011 && _lBase_2014 <= INT15 && _lBase_2014 >= -INT15)
                _lRightSize_2011 = _lRightSize_2011 * _lBase_2014;
                else
                _lRightSize_2011 = NewDouble(_lRightSize_2011 * (double)_lBase_2014);
            }
            else {
                _lRightSize_2011 = NewDouble(DBL_PTR(_lRightSize_2011)->dbl * (double)_lBase_2014);
            }
            DeRef(_0);

            /** 					lRightValue = (lRightValue * lBase) + lCharValue*/
            if (IS_ATOM_INT(_lRightValue_2013)) {
                if (_lRightValue_2013 == (short)_lRightValue_2013 && _lBase_2014 <= INT15 && _lBase_2014 >= -INT15)
                _902 = _lRightValue_2013 * _lBase_2014;
                else
                _902 = NewDouble(_lRightValue_2013 * (double)_lBase_2014);
            }
            else {
                _902 = NewDouble(DBL_PTR(_lRightValue_2013)->dbl * (double)_lBase_2014);
            }
            DeRef(_lRightValue_2013);
            if (IS_ATOM_INT(_902)) {
                _lRightValue_2013 = _902 + _lCharValue_2008;
                if ((long)((unsigned long)_lRightValue_2013 + (unsigned long)HIGH_BITS) >= 0) 
                _lRightValue_2013 = NewDouble((double)_lRightValue_2013);
            }
            else {
                _lRightValue_2013 = NewDouble(DBL_PTR(_902)->dbl + (double)_lCharValue_2008);
            }
            DeRef(_902);
            _902 = NOVALUE;

            /** 					lDigitCount += 1*/
            _lDigitCount_2017 = _lDigitCount_2017 + 1;
            goto L5; // [616] 654
L14: 

            /** 					lLeftSize += 1*/
            _0 = _lLeftSize_2010;
            if (IS_ATOM_INT(_lLeftSize_2010)) {
                _lLeftSize_2010 = _lLeftSize_2010 + 1;
                if (_lLeftSize_2010 > MAXINT){
                    _lLeftSize_2010 = NewDouble((double)_lLeftSize_2010);
                }
            }
            else
            _lLeftSize_2010 = binary_op(PLUS, 1, _lLeftSize_2010);
            DeRef(_0);

            /** 					lLeftValue = (lLeftValue * lBase) + lCharValue*/
            if (IS_ATOM_INT(_lLeftValue_2012)) {
                if (_lLeftValue_2012 == (short)_lLeftValue_2012 && _lBase_2014 <= INT15 && _lBase_2014 >= -INT15)
                _906 = _lLeftValue_2012 * _lBase_2014;
                else
                _906 = NewDouble(_lLeftValue_2012 * (double)_lBase_2014);
            }
            else {
                _906 = NewDouble(DBL_PTR(_lLeftValue_2012)->dbl * (double)_lBase_2014);
            }
            DeRef(_lLeftValue_2012);
            if (IS_ATOM_INT(_906)) {
                _lLeftValue_2012 = _906 + _lCharValue_2008;
                if ((long)((unsigned long)_lLeftValue_2012 + (unsigned long)HIGH_BITS) >= 0) 
                _lLeftValue_2012 = NewDouble((double)_lLeftValue_2012);
            }
            else {
                _lLeftValue_2012 = NewDouble(DBL_PTR(_906)->dbl + (double)_lCharValue_2008);
            }
            DeRef(_906);
            _906 = NOVALUE;

            /** 					lDigitCount += 1*/
            _lDigitCount_2017 = _lDigitCount_2017 + 1;
            goto L5; // [642] 654

            /** 			case else*/
            default:

            /** 				lBadPos = i*/
            _lBadPos_2009 = _i_2022;
        ;}L5: 

        /** 		if lBadPos != 0 then*/
        if (_lBadPos_2009 == 0)
        goto L15; // [656] 665

        /** 			exit*/
        goto L2; // [662] 672
L15: 

        /** 	end for*/
        _i_2022 = _i_2022 + 1;
        goto L1; // [667] 77
L2: 
        ;
    }

    /** 	if lBadPos = 0 and lDigitCount = 0 then*/
    _910 = (_lBadPos_2009 == 0);
    if (_910 == 0) {
        goto L16; // [678] 696
    }
    _912 = (_lDigitCount_2017 == 0);
    if (_912 == 0)
    {
        DeRef(_912);
        _912 = NOVALUE;
        goto L16; // [687] 696
    }
    else{
        DeRef(_912);
        _912 = NOVALUE;
    }

    /** 		lBadPos = 1*/
    _lBadPos_2009 = 1;
L16: 

    /** 	if return_bad_pos = 0 and lBadPos != 0 then*/
    _913 = (_return_bad_pos_2005 == 0);
    if (_913 == 0) {
        goto L17; // [702] 721
    }
    _915 = (_lBadPos_2009 != 0);
    if (_915 == 0)
    {
        DeRef(_915);
        _915 = NOVALUE;
        goto L17; // [711] 721
    }
    else{
        DeRef(_915);
        _915 = NOVALUE;
    }

    /** 		return 0*/
    DeRefDS(_text_in_2004);
    DeRef(_lLeftSize_2010);
    DeRef(_lRightSize_2011);
    DeRef(_lLeftValue_2012);
    DeRef(_lRightValue_2013);
    DeRef(_lResult_2016);
    DeRef(_859);
    _859 = NOVALUE;
    DeRef(_862);
    _862 = NOVALUE;
    DeRef(_865);
    _865 = NOVALUE;
    DeRef(_873);
    _873 = NOVALUE;
    DeRef(_881);
    _881 = NOVALUE;
    DeRef(_910);
    _910 = NOVALUE;
    DeRef(_913);
    _913 = NOVALUE;
    return 0;
L17: 

    /** 	if lRightValue = 0 then*/
    if (binary_op_a(NOTEQ, _lRightValue_2013, 0)){
        goto L18; // [723] 751
    }

    /** 	    if lPercent != 1 then*/
    if (_lPercent_2015 == 1)
    goto L19; // [729] 742

    /** 			lResult = (lLeftValue / lPercent)*/
    DeRef(_lResult_2016);
    if (IS_ATOM_INT(_lLeftValue_2012)) {
        _lResult_2016 = (_lLeftValue_2012 % _lPercent_2015) ? NewDouble((double)_lLeftValue_2012 / _lPercent_2015) : (_lLeftValue_2012 / _lPercent_2015);
    }
    else {
        _lResult_2016 = NewDouble(DBL_PTR(_lLeftValue_2012)->dbl / (double)_lPercent_2015);
    }
    goto L1A; // [739] 786
L19: 

    /** 	        lResult = lLeftValue*/
    Ref(_lLeftValue_2012);
    DeRef(_lResult_2016);
    _lResult_2016 = _lLeftValue_2012;
    goto L1A; // [748] 786
L18: 

    /** 	    if lPercent != 1 then*/
    if (_lPercent_2015 == 1)
    goto L1B; // [753] 774

    /** 	        lResult = (lLeftValue  + (lRightValue / (lRightSize))) / lPercent*/
    if (IS_ATOM_INT(_lRightValue_2013) && IS_ATOM_INT(_lRightSize_2011)) {
        _920 = (_lRightValue_2013 % _lRightSize_2011) ? NewDouble((double)_lRightValue_2013 / _lRightSize_2011) : (_lRightValue_2013 / _lRightSize_2011);
    }
    else {
        if (IS_ATOM_INT(_lRightValue_2013)) {
            _920 = NewDouble((double)_lRightValue_2013 / DBL_PTR(_lRightSize_2011)->dbl);
        }
        else {
            if (IS_ATOM_INT(_lRightSize_2011)) {
                _920 = NewDouble(DBL_PTR(_lRightValue_2013)->dbl / (double)_lRightSize_2011);
            }
            else
            _920 = NewDouble(DBL_PTR(_lRightValue_2013)->dbl / DBL_PTR(_lRightSize_2011)->dbl);
        }
    }
    if (IS_ATOM_INT(_lLeftValue_2012) && IS_ATOM_INT(_920)) {
        _921 = _lLeftValue_2012 + _920;
        if ((long)((unsigned long)_921 + (unsigned long)HIGH_BITS) >= 0) 
        _921 = NewDouble((double)_921);
    }
    else {
        if (IS_ATOM_INT(_lLeftValue_2012)) {
            _921 = NewDouble((double)_lLeftValue_2012 + DBL_PTR(_920)->dbl);
        }
        else {
            if (IS_ATOM_INT(_920)) {
                _921 = NewDouble(DBL_PTR(_lLeftValue_2012)->dbl + (double)_920);
            }
            else
            _921 = NewDouble(DBL_PTR(_lLeftValue_2012)->dbl + DBL_PTR(_920)->dbl);
        }
    }
    DeRef(_920);
    _920 = NOVALUE;
    DeRef(_lResult_2016);
    if (IS_ATOM_INT(_921)) {
        _lResult_2016 = (_921 % _lPercent_2015) ? NewDouble((double)_921 / _lPercent_2015) : (_921 / _lPercent_2015);
    }
    else {
        _lResult_2016 = NewDouble(DBL_PTR(_921)->dbl / (double)_lPercent_2015);
    }
    DeRef(_921);
    _921 = NOVALUE;
    goto L1C; // [771] 785
L1B: 

    /** 	        lResult = lLeftValue + (lRightValue / lRightSize)*/
    if (IS_ATOM_INT(_lRightValue_2013) && IS_ATOM_INT(_lRightSize_2011)) {
        _923 = (_lRightValue_2013 % _lRightSize_2011) ? NewDouble((double)_lRightValue_2013 / _lRightSize_2011) : (_lRightValue_2013 / _lRightSize_2011);
    }
    else {
        if (IS_ATOM_INT(_lRightValue_2013)) {
            _923 = NewDouble((double)_lRightValue_2013 / DBL_PTR(_lRightSize_2011)->dbl);
        }
        else {
            if (IS_ATOM_INT(_lRightSize_2011)) {
                _923 = NewDouble(DBL_PTR(_lRightValue_2013)->dbl / (double)_lRightSize_2011);
            }
            else
            _923 = NewDouble(DBL_PTR(_lRightValue_2013)->dbl / DBL_PTR(_lRightSize_2011)->dbl);
        }
    }
    DeRef(_lResult_2016);
    if (IS_ATOM_INT(_lLeftValue_2012) && IS_ATOM_INT(_923)) {
        _lResult_2016 = _lLeftValue_2012 + _923;
        if ((long)((unsigned long)_lResult_2016 + (unsigned long)HIGH_BITS) >= 0) 
        _lResult_2016 = NewDouble((double)_lResult_2016);
    }
    else {
        if (IS_ATOM_INT(_lLeftValue_2012)) {
            _lResult_2016 = NewDouble((double)_lLeftValue_2012 + DBL_PTR(_923)->dbl);
        }
        else {
            if (IS_ATOM_INT(_923)) {
                _lResult_2016 = NewDouble(DBL_PTR(_lLeftValue_2012)->dbl + (double)_923);
            }
            else
            _lResult_2016 = NewDouble(DBL_PTR(_lLeftValue_2012)->dbl + DBL_PTR(_923)->dbl);
        }
    }
    DeRef(_923);
    _923 = NOVALUE;
L1C: 
L1A: 

    /** 	if lSignFound < 0 then*/
    if (_lSignFound_2007 >= 0)
    goto L1D; // [788] 800

    /** 		lResult = -lResult*/
    _0 = _lResult_2016;
    if (IS_ATOM_INT(_lResult_2016)) {
        if ((unsigned long)_lResult_2016 == 0xC0000000)
        _lResult_2016 = (int)NewDouble((double)-0xC0000000);
        else
        _lResult_2016 = - _lResult_2016;
    }
    else {
        _lResult_2016 = unary_op(UMINUS, _lResult_2016);
    }
    DeRef(_0);
L1D: 

    /** 	if return_bad_pos = 0 then*/
    if (_return_bad_pos_2005 != 0)
    goto L1E; // [802] 815

    /** 		return lResult*/
    DeRefDS(_text_in_2004);
    DeRef(_lLeftSize_2010);
    DeRef(_lRightSize_2011);
    DeRef(_lLeftValue_2012);
    DeRef(_lRightValue_2013);
    DeRef(_859);
    _859 = NOVALUE;
    DeRef(_862);
    _862 = NOVALUE;
    DeRef(_865);
    _865 = NOVALUE;
    DeRef(_873);
    _873 = NOVALUE;
    DeRef(_881);
    _881 = NOVALUE;
    DeRef(_910);
    _910 = NOVALUE;
    DeRef(_913);
    _913 = NOVALUE;
    return _lResult_2016;
L1E: 

    /** 	if return_bad_pos = -1 then*/
    if (_return_bad_pos_2005 != -1)
    goto L1F; // [817] 850

    /** 		if lBadPos = 0 then*/
    if (_lBadPos_2009 != 0)
    goto L20; // [823] 838

    /** 			return lResult*/
    DeRefDS(_text_in_2004);
    DeRef(_lLeftSize_2010);
    DeRef(_lRightSize_2011);
    DeRef(_lLeftValue_2012);
    DeRef(_lRightValue_2013);
    DeRef(_859);
    _859 = NOVALUE;
    DeRef(_862);
    _862 = NOVALUE;
    DeRef(_865);
    _865 = NOVALUE;
    DeRef(_873);
    _873 = NOVALUE;
    DeRef(_881);
    _881 = NOVALUE;
    DeRef(_910);
    _910 = NOVALUE;
    DeRef(_913);
    _913 = NOVALUE;
    return _lResult_2016;
    goto L21; // [835] 849
L20: 

    /** 			return {lBadPos}	*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _lBadPos_2009;
    _930 = MAKE_SEQ(_1);
    DeRefDS(_text_in_2004);
    DeRef(_lLeftSize_2010);
    DeRef(_lRightSize_2011);
    DeRef(_lLeftValue_2012);
    DeRef(_lRightValue_2013);
    DeRef(_lResult_2016);
    DeRef(_859);
    _859 = NOVALUE;
    DeRef(_862);
    _862 = NOVALUE;
    DeRef(_865);
    _865 = NOVALUE;
    DeRef(_873);
    _873 = NOVALUE;
    DeRef(_881);
    _881 = NOVALUE;
    DeRef(_910);
    _910 = NOVALUE;
    DeRef(_913);
    _913 = NOVALUE;
    return _930;
L21: 
L1F: 

    /** 	return {lResult, lBadPos}*/
    Ref(_lResult_2016);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _lResult_2016;
    ((int *)_2)[2] = _lBadPos_2009;
    _931 = MAKE_SEQ(_1);
    DeRefDS(_text_in_2004);
    DeRef(_lLeftSize_2010);
    DeRef(_lRightSize_2011);
    DeRef(_lLeftValue_2012);
    DeRef(_lRightValue_2013);
    DeRef(_lResult_2016);
    DeRef(_859);
    _859 = NOVALUE;
    DeRef(_862);
    _862 = NOVALUE;
    DeRef(_865);
    _865 = NOVALUE;
    DeRef(_873);
    _873 = NOVALUE;
    DeRef(_881);
    _881 = NOVALUE;
    DeRef(_910);
    _910 = NOVALUE;
    DeRef(_913);
    _913 = NOVALUE;
    DeRef(_930);
    _930 = NOVALUE;
    return _931;
    ;
}



// 0x16ED3345
