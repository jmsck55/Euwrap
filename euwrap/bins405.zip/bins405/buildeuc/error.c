// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

void _7warning_file(int _file_path_252)
{
    int _0, _1, _2;
    

    /** 	machine_proc(M_WARNING_FILE, file_path)*/
    machine(72, _file_path_252);

    /** end procedure*/
    DeRef(_file_path_252);
    return;
    ;
}



// 0x3E491124
