// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

void _35print_sym(int _s_16011)
{
    int _s_obj_16014 = NOVALUE;
    int _8934 = NOVALUE;
    int _8933 = NOVALUE;
    int _8929 = NOVALUE;
    int _8927 = NOVALUE;
    int _8926 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_s_16011)) {
        _1 = (long)(DBL_PTR(_s_16011)->dbl);
        DeRefDS(_s_16011);
        _s_16011 = _1;
    }

    /** 	printf(1,"[%d]:\n", {s} )*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _s_16011;
    _8926 = MAKE_SEQ(_1);
    EPrintf(1, _8925, _8926);
    DeRefDS(_8926);
    _8926 = NOVALUE;

    /** 	object s_obj = SymTab[s][S_OBJ]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _8927 = (int)*(((s1_ptr)_2)->base + _s_16011);
    DeRef(_s_obj_16014);
    _2 = (int)SEQ_PTR(_8927);
    _s_obj_16014 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_s_obj_16014);
    _8927 = NOVALUE;

    /** 	if equal(s_obj,NOVALUE) then */
    if (_s_obj_16014 == _35NOVALUE_16099)
    _8929 = 1;
    else if (IS_ATOM_INT(_s_obj_16014) && IS_ATOM_INT(_35NOVALUE_16099))
    _8929 = 0;
    else
    _8929 = (compare(_s_obj_16014, _35NOVALUE_16099) == 0);
    if (_8929 == 0)
    {
        _8929 = NOVALUE;
        goto L1; // [33] 44
    }
    else{
        _8929 = NOVALUE;
    }

    /** 		puts(1,"S_OBJ=>NOVALUE\n")*/
    EPuts(1, _8930); // DJP 
    goto L2; // [41] 55
L1: 

    /** 		puts(1,"S_OBJ=>")*/
    EPuts(1, _8931); // DJP 

    /** 		? s_obj		*/
    StdPrint(1, _s_obj_16014, 1);
L2: 

    /** 	puts(1,"S_MODE=>")*/
    EPuts(1, _8932); // DJP 

    /** 	switch SymTab[s][S_MODE] do*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _8933 = (int)*(((s1_ptr)_2)->base + _s_16011);
    _2 = (int)SEQ_PTR(_8933);
    _8934 = (int)*(((s1_ptr)_2)->base + 3);
    _8933 = NOVALUE;
    if (IS_SEQUENCE(_8934) ){
        goto L3; // [72] 120
    }
    if(!IS_ATOM_INT(_8934)){
        if( (DBL_PTR(_8934)->dbl != (double) ((int) DBL_PTR(_8934)->dbl) ) ){
            goto L3; // [72] 120
        }
        _0 = (int) DBL_PTR(_8934)->dbl;
    }
    else {
        _0 = _8934;
    };
    _8934 = NOVALUE;
    switch ( _0 ){ 

        /** 		case M_NORMAL then*/
        case 1:

        /** 			puts(1,"M_NORMAL")*/
        EPuts(1, _8937); // DJP 
        goto L3; // [86] 120

        /** 		case M_TEMP then*/
        case 3:

        /** 			puts(1,"M_TEMP")*/
        EPuts(1, _8938); // DJP 
        goto L3; // [97] 120

        /** 		case M_CONSTANT then*/
        case 2:

        /** 			puts(1,"M_CONSTANT")*/
        EPuts(1, _8939); // DJP 
        goto L3; // [108] 120

        /** 		case M_BLOCK then*/
        case 4:

        /** 			puts(1,"M_BLOCK")*/
        EPuts(1, _8940); // DJP 
    ;}L3: 

    /** 	puts(1,{10,10})*/
    EPuts(1, _8941); // DJP 

    /** end procedure*/
    DeRef(_s_obj_16014);
    return;
    ;
}


int _35symtab_entry(int _x_16104)
{
    int _8960 = NOVALUE;
    int _8959 = NOVALUE;
    int _8958 = NOVALUE;
    int _8957 = NOVALUE;
    int _8956 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return length(x) = SIZEOF_ROUTINE_ENTRY or*/
    if (IS_SEQUENCE(_x_16104)){
            _8956 = SEQ_PTR(_x_16104)->length;
    }
    else {
        _8956 = 1;
    }
    _8957 = (_8956 == _35SIZEOF_ROUTINE_ENTRY_16043);
    _8956 = NOVALUE;
    if (IS_SEQUENCE(_x_16104)){
            _8958 = SEQ_PTR(_x_16104)->length;
    }
    else {
        _8958 = 1;
    }
    _8959 = (_8958 == _35SIZEOF_VAR_ENTRY_16046);
    _8958 = NOVALUE;
    _8960 = (_8957 != 0 || _8959 != 0);
    _8957 = NOVALUE;
    _8959 = NOVALUE;
    DeRefDS(_x_16104);
    return _8960;
    ;
}


int _35symtab_index(int _x_16112)
{
    int _8969 = NOVALUE;
    int _8968 = NOVALUE;
    int _8967 = NOVALUE;
    int _8966 = NOVALUE;
    int _8965 = NOVALUE;
    int _8964 = NOVALUE;
    int _8962 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_x_16112)) {
        _1 = (long)(DBL_PTR(_x_16112)->dbl);
        DeRefDS(_x_16112);
        _x_16112 = _1;
    }

    /** 	if x = 0 then*/
    if (_x_16112 != 0)
    goto L1; // [5] 18

    /** 		return TRUE -- NULL value*/
    return _13TRUE_436;
L1: 

    /** 	if x < 0 or x > length(SymTab) then*/
    _8962 = (_x_16112 < 0);
    if (_8962 != 0) {
        goto L2; // [24] 42
    }
    if (IS_SEQUENCE(_36SymTab_15242)){
            _8964 = SEQ_PTR(_36SymTab_15242)->length;
    }
    else {
        _8964 = 1;
    }
    _8965 = (_x_16112 > _8964);
    _8964 = NOVALUE;
    if (_8965 == 0)
    {
        DeRef(_8965);
        _8965 = NOVALUE;
        goto L3; // [38] 51
    }
    else{
        DeRef(_8965);
        _8965 = NOVALUE;
    }
L2: 

    /** 		return FALSE*/
    DeRef(_8962);
    _8962 = NOVALUE;
    return _13FALSE_434;
L3: 

    /** 	return find(length(SymTab[x]), {SIZEOF_VAR_ENTRY, SIZEOF_ROUTINE_ENTRY,*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _8966 = (int)*(((s1_ptr)_2)->base + _x_16112);
    if (IS_SEQUENCE(_8966)){
            _8967 = SEQ_PTR(_8966)->length;
    }
    else {
        _8967 = 1;
    }
    _8966 = NOVALUE;
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _35SIZEOF_VAR_ENTRY_16046;
    *((int *)(_2+8)) = _35SIZEOF_ROUTINE_ENTRY_16043;
    *((int *)(_2+12)) = _35SIZEOF_TEMP_ENTRY_16052;
    *((int *)(_2+16)) = _35SIZEOF_BLOCK_ENTRY_16049;
    _8968 = MAKE_SEQ(_1);
    _8969 = find_from(_8967, _8968, 1);
    _8967 = NOVALUE;
    DeRefDS(_8968);
    _8968 = NOVALUE;
    DeRef(_8962);
    _8962 = NOVALUE;
    _8966 = NOVALUE;
    return _8969;
    ;
}


int _35temp_index(int _x_16130)
{
    int _8973 = NOVALUE;
    int _8972 = NOVALUE;
    int _8971 = NOVALUE;
    int _8970 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_x_16130)) {
        _1 = (long)(DBL_PTR(_x_16130)->dbl);
        DeRefDS(_x_16130);
        _x_16130 = _1;
    }

    /** 	return x >= 0 and x <= length(SymTab)*/
    _8970 = (_x_16130 >= 0);
    if (IS_SEQUENCE(_36SymTab_15242)){
            _8971 = SEQ_PTR(_36SymTab_15242)->length;
    }
    else {
        _8971 = 1;
    }
    _8972 = (_x_16130 <= _8971);
    _8971 = NOVALUE;
    _8973 = (_8970 != 0 && _8972 != 0);
    _8970 = NOVALUE;
    _8972 = NOVALUE;
    return _8973;
    ;
}


int _35token(int _t_16140)
{
    int _9016 = NOVALUE;
    int _9015 = NOVALUE;
    int _9014 = NOVALUE;
    int _9013 = NOVALUE;
    int _9012 = NOVALUE;
    int _9011 = NOVALUE;
    int _9010 = NOVALUE;
    int _9009 = NOVALUE;
    int _9008 = NOVALUE;
    int _9007 = NOVALUE;
    int _9006 = NOVALUE;
    int _9005 = NOVALUE;
    int _9004 = NOVALUE;
    int _9003 = NOVALUE;
    int _9002 = NOVALUE;
    int _9001 = NOVALUE;
    int _9000 = NOVALUE;
    int _8999 = NOVALUE;
    int _8998 = NOVALUE;
    int _8997 = NOVALUE;
    int _8996 = NOVALUE;
    int _8995 = NOVALUE;
    int _8994 = NOVALUE;
    int _8993 = NOVALUE;
    int _8992 = NOVALUE;
    int _8991 = NOVALUE;
    int _8990 = NOVALUE;
    int _8989 = NOVALUE;
    int _8988 = NOVALUE;
    int _8987 = NOVALUE;
    int _8986 = NOVALUE;
    int _8985 = NOVALUE;
    int _8984 = NOVALUE;
    int _8983 = NOVALUE;
    int _8982 = NOVALUE;
    int _8981 = NOVALUE;
    int _8980 = NOVALUE;
    int _8978 = NOVALUE;
    int _8977 = NOVALUE;
    int _8975 = NOVALUE;
    int _8974 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(t) then*/
    _8974 = IS_ATOM(_t_16140);
    if (_8974 == 0)
    {
        _8974 = NOVALUE;
        goto L1; // [6] 18
    }
    else{
        _8974 = NOVALUE;
    }

    /** 		return FALSE*/
    DeRef(_t_16140);
    return _13FALSE_434;
L1: 

    /** 	if length(t) != 2 then*/
    if (IS_SEQUENCE(_t_16140)){
            _8975 = SEQ_PTR(_t_16140)->length;
    }
    else {
        _8975 = 1;
    }
    if (_8975 == 2)
    goto L2; // [23] 36

    /** 		return FALSE*/
    DeRef(_t_16140);
    return _13FALSE_434;
L2: 

    /** 	if not integer(t[T_ID]) then*/
    _2 = (int)SEQ_PTR(_t_16140);
    _8977 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_8977))
    _8978 = 1;
    else if (IS_ATOM_DBL(_8977))
    _8978 = IS_ATOM_INT(DoubleToInt(_8977));
    else
    _8978 = 0;
    _8977 = NOVALUE;
    if (_8978 != 0)
    goto L3; // [45] 57
    _8978 = NOVALUE;

    /** 		return FALSE*/
    DeRef(_t_16140);
    return _13FALSE_434;
L3: 

    /** 	if t[T_ID] = VARIABLE and (t[T_SYM] < 0 or symtab_index(t[T_SYM])) then*/
    _2 = (int)SEQ_PTR(_t_16140);
    _8980 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_8980)) {
        _8981 = (_8980 == -100);
    }
    else {
        _8981 = binary_op(EQUALS, _8980, -100);
    }
    _8980 = NOVALUE;
    if (IS_ATOM_INT(_8981)) {
        if (_8981 == 0) {
            goto L4; // [69] 110
        }
    }
    else {
        if (DBL_PTR(_8981)->dbl == 0.0) {
            goto L4; // [69] 110
        }
    }
    _2 = (int)SEQ_PTR(_t_16140);
    _8983 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_8983)) {
        _8984 = (_8983 < 0);
    }
    else {
        _8984 = binary_op(LESS, _8983, 0);
    }
    _8983 = NOVALUE;
    if (IS_ATOM_INT(_8984)) {
        if (_8984 != 0) {
            DeRef(_8985);
            _8985 = 1;
            goto L5; // [81] 97
        }
    }
    else {
        if (DBL_PTR(_8984)->dbl != 0.0) {
            DeRef(_8985);
            _8985 = 1;
            goto L5; // [81] 97
        }
    }
    _2 = (int)SEQ_PTR(_t_16140);
    _8986 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_8986);
    _8987 = _35symtab_index(_8986);
    _8986 = NOVALUE;
    DeRef(_8985);
    if (IS_ATOM_INT(_8987))
    _8985 = (_8987 != 0);
    else
    _8985 = DBL_PTR(_8987)->dbl != 0.0;
L5: 
    if (_8985 == 0)
    {
        _8985 = NOVALUE;
        goto L4; // [98] 110
    }
    else{
        _8985 = NOVALUE;
    }

    /** 		return TRUE*/
    DeRef(_t_16140);
    DeRef(_8981);
    _8981 = NOVALUE;
    DeRef(_8984);
    _8984 = NOVALUE;
    DeRef(_8987);
    _8987 = NOVALUE;
    return _13TRUE_436;
L4: 

    /** 	if QUESTION_MARK <= t[T_ID] and t[T_ID] <= -1 then*/
    _2 = (int)SEQ_PTR(_t_16140);
    _8988 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_8988)) {
        _8989 = (-31 <= _8988);
    }
    else {
        _8989 = binary_op(LESSEQ, -31, _8988);
    }
    _8988 = NOVALUE;
    if (IS_ATOM_INT(_8989)) {
        if (_8989 == 0) {
            goto L6; // [122] 147
        }
    }
    else {
        if (DBL_PTR(_8989)->dbl == 0.0) {
            goto L6; // [122] 147
        }
    }
    _2 = (int)SEQ_PTR(_t_16140);
    _8991 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_8991)) {
        _8992 = (_8991 <= -1);
    }
    else {
        _8992 = binary_op(LESSEQ, _8991, -1);
    }
    _8991 = NOVALUE;
    if (_8992 == 0) {
        DeRef(_8992);
        _8992 = NOVALUE;
        goto L6; // [135] 147
    }
    else {
        if (!IS_ATOM_INT(_8992) && DBL_PTR(_8992)->dbl == 0.0){
            DeRef(_8992);
            _8992 = NOVALUE;
            goto L6; // [135] 147
        }
        DeRef(_8992);
        _8992 = NOVALUE;
    }
    DeRef(_8992);
    _8992 = NOVALUE;

    /** 		return TRUE*/
    DeRef(_t_16140);
    DeRef(_8981);
    _8981 = NOVALUE;
    DeRef(_8984);
    _8984 = NOVALUE;
    DeRef(_8987);
    _8987 = NOVALUE;
    DeRef(_8989);
    _8989 = NOVALUE;
    return _13TRUE_436;
L6: 

    /** 	if t[T_ID] >= 1 and t[T_ID] <= MAX_OPCODE then*/
    _2 = (int)SEQ_PTR(_t_16140);
    _8993 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_8993)) {
        _8994 = (_8993 >= 1);
    }
    else {
        _8994 = binary_op(GREATEREQ, _8993, 1);
    }
    _8993 = NOVALUE;
    if (IS_ATOM_INT(_8994)) {
        if (_8994 == 0) {
            goto L7; // [157] 184
        }
    }
    else {
        if (DBL_PTR(_8994)->dbl == 0.0) {
            goto L7; // [157] 184
        }
    }
    _2 = (int)SEQ_PTR(_t_16140);
    _8996 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_8996)) {
        _8997 = (_8996 <= 213);
    }
    else {
        _8997 = binary_op(LESSEQ, _8996, 213);
    }
    _8996 = NOVALUE;
    if (_8997 == 0) {
        DeRef(_8997);
        _8997 = NOVALUE;
        goto L7; // [172] 184
    }
    else {
        if (!IS_ATOM_INT(_8997) && DBL_PTR(_8997)->dbl == 0.0){
            DeRef(_8997);
            _8997 = NOVALUE;
            goto L7; // [172] 184
        }
        DeRef(_8997);
        _8997 = NOVALUE;
    }
    DeRef(_8997);
    _8997 = NOVALUE;

    /** 		return TRUE*/
    DeRef(_t_16140);
    DeRef(_8981);
    _8981 = NOVALUE;
    DeRef(_8984);
    _8984 = NOVALUE;
    DeRef(_8987);
    _8987 = NOVALUE;
    DeRef(_8989);
    _8989 = NOVALUE;
    DeRef(_8994);
    _8994 = NOVALUE;
    return _13TRUE_436;
L7: 

    /** 	if END <= t[T_ID] and t[T_ID] <=  ROUTINE then*/
    _2 = (int)SEQ_PTR(_t_16140);
    _8998 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_8998)) {
        _8999 = (402 <= _8998);
    }
    else {
        _8999 = binary_op(LESSEQ, 402, _8998);
    }
    _8998 = NOVALUE;
    if (IS_ATOM_INT(_8999)) {
        if (_8999 == 0) {
            goto L8; // [196] 280
        }
    }
    else {
        if (DBL_PTR(_8999)->dbl == 0.0) {
            goto L8; // [196] 280
        }
    }
    _2 = (int)SEQ_PTR(_t_16140);
    _9001 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_9001)) {
        _9002 = (_9001 <= 432);
    }
    else {
        _9002 = binary_op(LESSEQ, _9001, 432);
    }
    _9001 = NOVALUE;
    if (_9002 == 0) {
        DeRef(_9002);
        _9002 = NOVALUE;
        goto L8; // [211] 280
    }
    else {
        if (!IS_ATOM_INT(_9002) && DBL_PTR(_9002)->dbl == 0.0){
            DeRef(_9002);
            _9002 = NOVALUE;
            goto L8; // [211] 280
        }
        DeRef(_9002);
        _9002 = NOVALUE;
    }
    DeRef(_9002);
    _9002 = NOVALUE;

    /** 		if t[T_ID] != IGNORED and t[T_ID] < 500 and symtab_index(t[T_SYM]) = 0 then*/
    _2 = (int)SEQ_PTR(_t_16140);
    _9003 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_9003)) {
        _9004 = (_9003 != 509);
    }
    else {
        _9004 = binary_op(NOTEQ, _9003, 509);
    }
    _9003 = NOVALUE;
    if (IS_ATOM_INT(_9004)) {
        if (_9004 == 0) {
            DeRef(_9005);
            _9005 = 0;
            goto L9; // [226] 242
        }
    }
    else {
        if (DBL_PTR(_9004)->dbl == 0.0) {
            DeRef(_9005);
            _9005 = 0;
            goto L9; // [226] 242
        }
    }
    _2 = (int)SEQ_PTR(_t_16140);
    _9006 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_9006)) {
        _9007 = (_9006 < 500);
    }
    else {
        _9007 = binary_op(LESS, _9006, 500);
    }
    _9006 = NOVALUE;
    DeRef(_9005);
    if (IS_ATOM_INT(_9007))
    _9005 = (_9007 != 0);
    else
    _9005 = DBL_PTR(_9007)->dbl != 0.0;
L9: 
    if (_9005 == 0) {
        goto LA; // [242] 271
    }
    _2 = (int)SEQ_PTR(_t_16140);
    _9009 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_9009);
    _9010 = _35symtab_index(_9009);
    _9009 = NOVALUE;
    if (IS_ATOM_INT(_9010)) {
        _9011 = (_9010 == 0);
    }
    else {
        _9011 = binary_op(EQUALS, _9010, 0);
    }
    DeRef(_9010);
    _9010 = NOVALUE;
    if (_9011 == 0) {
        DeRef(_9011);
        _9011 = NOVALUE;
        goto LA; // [259] 271
    }
    else {
        if (!IS_ATOM_INT(_9011) && DBL_PTR(_9011)->dbl == 0.0){
            DeRef(_9011);
            _9011 = NOVALUE;
            goto LA; // [259] 271
        }
        DeRef(_9011);
        _9011 = NOVALUE;
    }
    DeRef(_9011);
    _9011 = NOVALUE;

    /** 			return FALSE*/
    DeRef(_t_16140);
    DeRef(_8981);
    _8981 = NOVALUE;
    DeRef(_8984);
    _8984 = NOVALUE;
    DeRef(_8987);
    _8987 = NOVALUE;
    DeRef(_8989);
    _8989 = NOVALUE;
    DeRef(_8994);
    _8994 = NOVALUE;
    DeRef(_8999);
    _8999 = NOVALUE;
    DeRef(_9004);
    _9004 = NOVALUE;
    DeRef(_9007);
    _9007 = NOVALUE;
    return _13FALSE_434;
LA: 

    /** 		return TRUE*/
    DeRef(_t_16140);
    DeRef(_8981);
    _8981 = NOVALUE;
    DeRef(_8984);
    _8984 = NOVALUE;
    DeRef(_8987);
    _8987 = NOVALUE;
    DeRef(_8989);
    _8989 = NOVALUE;
    DeRef(_8994);
    _8994 = NOVALUE;
    DeRef(_8999);
    _8999 = NOVALUE;
    DeRef(_9004);
    _9004 = NOVALUE;
    DeRef(_9007);
    _9007 = NOVALUE;
    return _13TRUE_436;
L8: 

    /** 	if FUNC <= t[T_ID] and t[T_ID] <= NAMESPACE then*/
    _2 = (int)SEQ_PTR(_t_16140);
    _9012 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_9012)) {
        _9013 = (501 <= _9012);
    }
    else {
        _9013 = binary_op(LESSEQ, 501, _9012);
    }
    _9012 = NOVALUE;
    if (IS_ATOM_INT(_9013)) {
        if (_9013 == 0) {
            goto LB; // [292] 319
        }
    }
    else {
        if (DBL_PTR(_9013)->dbl == 0.0) {
            goto LB; // [292] 319
        }
    }
    _2 = (int)SEQ_PTR(_t_16140);
    _9015 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_9015)) {
        _9016 = (_9015 <= 523);
    }
    else {
        _9016 = binary_op(LESSEQ, _9015, 523);
    }
    _9015 = NOVALUE;
    if (_9016 == 0) {
        DeRef(_9016);
        _9016 = NOVALUE;
        goto LB; // [307] 319
    }
    else {
        if (!IS_ATOM_INT(_9016) && DBL_PTR(_9016)->dbl == 0.0){
            DeRef(_9016);
            _9016 = NOVALUE;
            goto LB; // [307] 319
        }
        DeRef(_9016);
        _9016 = NOVALUE;
    }
    DeRef(_9016);
    _9016 = NOVALUE;

    /** 		return TRUE*/
    DeRef(_t_16140);
    DeRef(_8981);
    _8981 = NOVALUE;
    DeRef(_8984);
    _8984 = NOVALUE;
    DeRef(_8987);
    _8987 = NOVALUE;
    DeRef(_8989);
    _8989 = NOVALUE;
    DeRef(_8994);
    _8994 = NOVALUE;
    DeRef(_8999);
    _8999 = NOVALUE;
    DeRef(_9004);
    _9004 = NOVALUE;
    DeRef(_9007);
    _9007 = NOVALUE;
    DeRef(_9013);
    _9013 = NOVALUE;
    return _13TRUE_436;
LB: 

    /** 	return FALSE*/
    DeRef(_t_16140);
    DeRef(_8981);
    _8981 = NOVALUE;
    DeRef(_8984);
    _8984 = NOVALUE;
    DeRef(_8987);
    _8987 = NOVALUE;
    DeRef(_8989);
    _8989 = NOVALUE;
    DeRef(_8994);
    _8994 = NOVALUE;
    DeRef(_8999);
    _8999 = NOVALUE;
    DeRef(_9004);
    _9004 = NOVALUE;
    DeRef(_9007);
    _9007 = NOVALUE;
    DeRef(_9013);
    _9013 = NOVALUE;
    return _13FALSE_434;
    ;
}


int _35sequence_of_tokens(int _x_16213)
{
    int _t_16214 = NOVALUE;
    int _9018 = NOVALUE;
    int _9017 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(x) then*/
    _9017 = IS_ATOM(_x_16213);
    if (_9017 == 0)
    {
        _9017 = NOVALUE;
        goto L1; // [6] 18
    }
    else{
        _9017 = NOVALUE;
    }

    /** 		return FALSE*/
    DeRef(_x_16213);
    DeRef(_t_16214);
    return _13FALSE_434;
L1: 

    /** 	for i = 1 to length(x) do*/
    if (IS_SEQUENCE(_x_16213)){
            _9018 = SEQ_PTR(_x_16213)->length;
    }
    else {
        _9018 = 1;
    }
    {
        int _i_16219;
        _i_16219 = 1;
L2: 
        if (_i_16219 > _9018){
            goto L3; // [23] 48
        }

        /** 		type_i = i*/
        _35type_i_15900 = _i_16219;

        /** 		t = x[i]*/
        DeRef(_t_16214);
        _2 = (int)SEQ_PTR(_x_16213);
        _t_16214 = (int)*(((s1_ptr)_2)->base + _i_16219);
        Ref(_t_16214);

        /** 	end for*/
        _i_16219 = _i_16219 + 1;
        goto L2; // [43] 30
L3: 
        ;
    }

    /** 	return TRUE*/
    DeRef(_x_16213);
    DeRef(_t_16214);
    return _13TRUE_436;
    ;
}


int _35sequence_of_opcodes(int _s_16225)
{
    int _oc_16226 = NOVALUE;
    int _9021 = NOVALUE;
    int _9020 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(s) then*/
    _9020 = IS_ATOM(_s_16225);
    if (_9020 == 0)
    {
        _9020 = NOVALUE;
        goto L1; // [6] 18
    }
    else{
        _9020 = NOVALUE;
    }

    /** 		return FALSE*/
    DeRef(_s_16225);
    return _13FALSE_434;
L1: 

    /** 	for i = 1 to length(s) do*/
    if (IS_SEQUENCE(_s_16225)){
            _9021 = SEQ_PTR(_s_16225)->length;
    }
    else {
        _9021 = 1;
    }
    {
        int _i_16231;
        _i_16231 = 1;
L2: 
        if (_i_16231 > _9021){
            goto L3; // [23] 45
        }

        /** 		oc = s[i]*/
        _2 = (int)SEQ_PTR(_s_16225);
        _oc_16226 = (int)*(((s1_ptr)_2)->base + _i_16231);
        if (!IS_ATOM_INT(_oc_16226)){
            _oc_16226 = (long)DBL_PTR(_oc_16226)->dbl;
        }

        /** 	end for*/
        _i_16231 = _i_16231 + 1;
        goto L2; // [40] 30
L3: 
        ;
    }

    /** 	return TRUE*/
    DeRef(_s_16225);
    return _13TRUE_436;
    ;
}


int _35file(int _f_16237)
{
    int _9025 = NOVALUE;
    int _9024 = NOVALUE;
    int _9023 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_f_16237)) {
        _1 = (long)(DBL_PTR(_f_16237)->dbl);
        DeRefDS(_f_16237);
        _f_16237 = _1;
    }

    /** 	return f >= -1 and f < 100 -- rough limit*/
    _9023 = (_f_16237 >= -1);
    _9024 = (_f_16237 < 100);
    _9025 = (_9023 != 0 && _9024 != 0);
    _9023 = NOVALUE;
    _9024 = NOVALUE;
    return _9025;
    ;
}


int _35symtab_pointer(int _x_63198)
{
    int _31631 = NOVALUE;
    int _31630 = NOVALUE;
    int _31629 = NOVALUE;
    int _31628 = NOVALUE;
    int _31627 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_x_63198)) {
        _1 = (long)(DBL_PTR(_x_63198)->dbl);
        DeRefDS(_x_63198);
        _x_63198 = _1;
    }

    /** 	return x = -1 or symtab_index(x) or forward_reference(x)*/
    _31627 = (_x_63198 == -1);
    _31628 = _35symtab_index(_x_63198);
    if (IS_ATOM_INT(_31628)) {
        _31629 = (_31627 != 0 || _31628 != 0);
    }
    else {
        _31629 = binary_op(OR, _31627, _31628);
    }
    _31627 = NOVALUE;
    DeRef(_31628);
    _31628 = NOVALUE;
    _31630 = _38forward_reference(_x_63198);
    if (IS_ATOM_INT(_31629) && IS_ATOM_INT(_31630)) {
        _31631 = (_31629 != 0 || _31630 != 0);
    }
    else {
        _31631 = binary_op(OR, _31629, _31630);
    }
    DeRef(_31629);
    _31629 = NOVALUE;
    DeRef(_31630);
    _31630 = NOVALUE;
    return _31631;
    ;
}



// 0x52DD2653
