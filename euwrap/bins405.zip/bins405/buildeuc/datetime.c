// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int _18isLeap(int _year_2319)
{
    int _ly_2320 = NOVALUE;
    int _1041 = NOVALUE;
    int _1040 = NOVALUE;
    int _1039 = NOVALUE;
    int _1038 = NOVALUE;
    int _1037 = NOVALUE;
    int _1036 = NOVALUE;
    int _1035 = NOVALUE;
    int _1034 = NOVALUE;
    int _1033 = NOVALUE;
    int _1030 = NOVALUE;
    int _1028 = NOVALUE;
    int _1027 = NOVALUE;
    int _0, _1, _2;
    

    /** 		ly = (remainder(year, {4, 100, 400, 3200, 80000})=0)*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 4;
    *((int *)(_2+8)) = 100;
    *((int *)(_2+12)) = 400;
    *((int *)(_2+16)) = 3200;
    *((int *)(_2+20)) = 80000;
    _1027 = MAKE_SEQ(_1);
    _1028 = binary_op(REMAINDER, _year_2319, _1027);
    DeRefDS(_1027);
    _1027 = NOVALUE;
    DeRefi(_ly_2320);
    _ly_2320 = binary_op(EQUALS, _1028, 0);
    DeRefDS(_1028);
    _1028 = NOVALUE;

    /** 		if not ly[1] then return 0 end if*/
    _2 = (int)SEQ_PTR(_ly_2320);
    _1030 = (int)*(((s1_ptr)_2)->base + 1);
    if (_1030 != 0)
    goto L1; // [29] 37
    _1030 = NOVALUE;
    DeRefDSi(_ly_2320);
    return 0;
L1: 

    /** 		if year <= Gregorian_Reformation then*/
    if (_year_2319 > 1752)
    goto L2; // [39] 52

    /** 				return 1 -- ly[1] can't possibly be 0 here so set shortcut as '1'.*/
    DeRefi(_ly_2320);
    return 1;
    goto L3; // [49] 95
L2: 

    /** 				return ly[1] - ly[2] + ly[3] - ly[4] + ly[5]*/
    _2 = (int)SEQ_PTR(_ly_2320);
    _1033 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_ly_2320);
    _1034 = (int)*(((s1_ptr)_2)->base + 2);
    _1035 = _1033 - _1034;
    if ((long)((unsigned long)_1035 +(unsigned long) HIGH_BITS) >= 0){
        _1035 = NewDouble((double)_1035);
    }
    _1033 = NOVALUE;
    _1034 = NOVALUE;
    _2 = (int)SEQ_PTR(_ly_2320);
    _1036 = (int)*(((s1_ptr)_2)->base + 3);
    if (IS_ATOM_INT(_1035)) {
        _1037 = _1035 + _1036;
        if ((long)((unsigned long)_1037 + (unsigned long)HIGH_BITS) >= 0) 
        _1037 = NewDouble((double)_1037);
    }
    else {
        _1037 = NewDouble(DBL_PTR(_1035)->dbl + (double)_1036);
    }
    DeRef(_1035);
    _1035 = NOVALUE;
    _1036 = NOVALUE;
    _2 = (int)SEQ_PTR(_ly_2320);
    _1038 = (int)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_1037)) {
        _1039 = _1037 - _1038;
        if ((long)((unsigned long)_1039 +(unsigned long) HIGH_BITS) >= 0){
            _1039 = NewDouble((double)_1039);
        }
    }
    else {
        _1039 = NewDouble(DBL_PTR(_1037)->dbl - (double)_1038);
    }
    DeRef(_1037);
    _1037 = NOVALUE;
    _1038 = NOVALUE;
    _2 = (int)SEQ_PTR(_ly_2320);
    _1040 = (int)*(((s1_ptr)_2)->base + 5);
    if (IS_ATOM_INT(_1039)) {
        _1041 = _1039 + _1040;
        if ((long)((unsigned long)_1041 + (unsigned long)HIGH_BITS) >= 0) 
        _1041 = NewDouble((double)_1041);
    }
    else {
        _1041 = NewDouble(DBL_PTR(_1039)->dbl + (double)_1040);
    }
    DeRef(_1039);
    _1039 = NOVALUE;
    _1040 = NOVALUE;
    DeRefDSi(_ly_2320);
    return _1041;
L3: 
    ;
}


int _18daysInMonth(int _year_2344, int _month_2345)
{
    int _1049 = NOVALUE;
    int _1048 = NOVALUE;
    int _1047 = NOVALUE;
    int _1046 = NOVALUE;
    int _1044 = NOVALUE;
    int _1043 = NOVALUE;
    int _1042 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_month_2345)) {
        _1 = (long)(DBL_PTR(_month_2345)->dbl);
        DeRefDS(_month_2345);
        _month_2345 = _1;
    }

    /** 	if year = Gregorian_Reformation and month = 9 then*/
    _1042 = (_year_2344 == 1752);
    if (_1042 == 0) {
        goto L1; // [11] 32
    }
    _1044 = (_month_2345 == 9);
    if (_1044 == 0)
    {
        DeRef(_1044);
        _1044 = NOVALUE;
        goto L1; // [20] 32
    }
    else{
        DeRef(_1044);
        _1044 = NOVALUE;
    }

    /** 		return 19*/
    DeRef(_1042);
    _1042 = NOVALUE;
    return 19;
    goto L2; // [29] 70
L1: 

    /** 	elsif month != 2 then*/
    if (_month_2345 == 2)
    goto L3; // [34] 51

    /** 		return DaysPerMonth[month]*/
    _2 = (int)SEQ_PTR(_18DaysPerMonth_2301);
    _1046 = (int)*(((s1_ptr)_2)->base + _month_2345);
    Ref(_1046);
    DeRef(_1042);
    _1042 = NOVALUE;
    return _1046;
    goto L2; // [48] 70
L3: 

    /** 		return DaysPerMonth[month] + isLeap(year)*/
    _2 = (int)SEQ_PTR(_18DaysPerMonth_2301);
    _1047 = (int)*(((s1_ptr)_2)->base + _month_2345);
    _1048 = _18isLeap(_year_2344);
    if (IS_ATOM_INT(_1047) && IS_ATOM_INT(_1048)) {
        _1049 = _1047 + _1048;
        if ((long)((unsigned long)_1049 + (unsigned long)HIGH_BITS) >= 0) 
        _1049 = NewDouble((double)_1049);
    }
    else {
        _1049 = binary_op(PLUS, _1047, _1048);
    }
    _1047 = NOVALUE;
    DeRef(_1048);
    _1048 = NOVALUE;
    DeRef(_1042);
    _1042 = NOVALUE;
    _1046 = NOVALUE;
    return _1049;
L2: 
    ;
}


int _18julianDayOfYear(int _ymd_2368)
{
    int _year_2369 = NOVALUE;
    int _month_2370 = NOVALUE;
    int _day_2371 = NOVALUE;
    int _d_2372 = NOVALUE;
    int _1065 = NOVALUE;
    int _1064 = NOVALUE;
    int _1063 = NOVALUE;
    int _1060 = NOVALUE;
    int _1059 = NOVALUE;
    int _0, _1, _2;
    

    /** 	year = ymd[1]*/
    _2 = (int)SEQ_PTR(_ymd_2368);
    _year_2369 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_year_2369)){
        _year_2369 = (long)DBL_PTR(_year_2369)->dbl;
    }

    /** 	month = ymd[2]*/
    _2 = (int)SEQ_PTR(_ymd_2368);
    _month_2370 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_month_2370)){
        _month_2370 = (long)DBL_PTR(_month_2370)->dbl;
    }

    /** 	day = ymd[3]*/
    _2 = (int)SEQ_PTR(_ymd_2368);
    _day_2371 = (int)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_day_2371)){
        _day_2371 = (long)DBL_PTR(_day_2371)->dbl;
    }

    /** 	if month = 1 then return day end if*/
    if (_month_2370 != 1)
    goto L1; // [27] 36
    DeRef(_ymd_2368);
    return _day_2371;
L1: 

    /** 	d = 0*/
    _d_2372 = 0;

    /** 	for i = 1 to month - 1 do*/
    _1059 = _month_2370 - 1;
    if ((long)((unsigned long)_1059 +(unsigned long) HIGH_BITS) >= 0){
        _1059 = NewDouble((double)_1059);
    }
    {
        int _i_2379;
        _i_2379 = 1;
L2: 
        if (binary_op_a(GREATER, _i_2379, _1059)){
            goto L3; // [47] 74
        }

        /** 		d += daysInMonth(year, i)*/
        Ref(_i_2379);
        _1060 = _18daysInMonth(_year_2369, _i_2379);
        if (IS_ATOM_INT(_1060)) {
            _d_2372 = _d_2372 + _1060;
        }
        else {
            _d_2372 = binary_op(PLUS, _d_2372, _1060);
        }
        DeRef(_1060);
        _1060 = NOVALUE;
        if (!IS_ATOM_INT(_d_2372)) {
            _1 = (long)(DBL_PTR(_d_2372)->dbl);
            DeRefDS(_d_2372);
            _d_2372 = _1;
        }

        /** 	end for*/
        _0 = _i_2379;
        if (IS_ATOM_INT(_i_2379)) {
            _i_2379 = _i_2379 + 1;
            if ((long)((unsigned long)_i_2379 +(unsigned long) HIGH_BITS) >= 0){
                _i_2379 = NewDouble((double)_i_2379);
            }
        }
        else {
            _i_2379 = binary_op_a(PLUS, _i_2379, 1);
        }
        DeRef(_0);
        goto L2; // [69] 54
L3: 
        ;
        DeRef(_i_2379);
    }

    /** 	d += day*/
    _d_2372 = _d_2372 + _day_2371;

    /** 	if year = Gregorian_Reformation and month = 9 then*/
    _1063 = (_year_2369 == 1752);
    if (_1063 == 0) {
        goto L4; // [86] 128
    }
    _1065 = (_month_2370 == 9);
    if (_1065 == 0)
    {
        DeRef(_1065);
        _1065 = NOVALUE;
        goto L4; // [95] 128
    }
    else{
        DeRef(_1065);
        _1065 = NOVALUE;
    }

    /** 		if day > 13 then*/
    if (_day_2371 <= 13)
    goto L5; // [100] 113

    /** 			d -= 11*/
    _d_2372 = _d_2372 - 11;
    goto L6; // [110] 127
L5: 

    /** 		elsif day > 2 then*/
    if (_day_2371 <= 2)
    goto L7; // [115] 126

    /** 			return 0*/
    DeRef(_ymd_2368);
    DeRef(_1059);
    _1059 = NOVALUE;
    DeRef(_1063);
    _1063 = NOVALUE;
    return 0;
L7: 
L6: 
L4: 

    /** 	return d*/
    DeRef(_ymd_2368);
    DeRef(_1059);
    _1059 = NOVALUE;
    DeRef(_1063);
    _1063 = NOVALUE;
    return _d_2372;
    ;
}


int _18julianDay(int _ymd_2395)
{
    int _year_2396 = NOVALUE;
    int _j_2397 = NOVALUE;
    int _greg00_2398 = NOVALUE;
    int _1094 = NOVALUE;
    int _1091 = NOVALUE;
    int _1088 = NOVALUE;
    int _1087 = NOVALUE;
    int _1086 = NOVALUE;
    int _1085 = NOVALUE;
    int _1084 = NOVALUE;
    int _1083 = NOVALUE;
    int _1082 = NOVALUE;
    int _1081 = NOVALUE;
    int _1079 = NOVALUE;
    int _1078 = NOVALUE;
    int _1077 = NOVALUE;
    int _1076 = NOVALUE;
    int _1075 = NOVALUE;
    int _1074 = NOVALUE;
    int _1073 = NOVALUE;
    int _0, _1, _2;
    

    /** 	year = ymd[1]*/
    _2 = (int)SEQ_PTR(_ymd_2395);
    _year_2396 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_year_2396)){
        _year_2396 = (long)DBL_PTR(_year_2396)->dbl;
    }

    /** 	j = julianDayOfYear(ymd)*/
    Ref(_ymd_2395);
    _j_2397 = _18julianDayOfYear(_ymd_2395);
    if (!IS_ATOM_INT(_j_2397)) {
        _1 = (long)(DBL_PTR(_j_2397)->dbl);
        DeRefDS(_j_2397);
        _j_2397 = _1;
    }

    /** 	year  -= 1*/
    _year_2396 = _year_2396 - 1;

    /** 	greg00 = year - Gregorian_Reformation00*/
    _greg00_2398 = _year_2396 - 1700;

    /** 	j += (*/
    if (_year_2396 <= INT15 && _year_2396 >= -INT15)
    _1073 = 365 * _year_2396;
    else
    _1073 = NewDouble(365 * (double)_year_2396);
    if (4 > 0 && _year_2396 >= 0) {
        _1074 = _year_2396 / 4;
    }
    else {
        temp_dbl = floor((double)_year_2396 / (double)4);
        _1074 = (long)temp_dbl;
    }
    if (IS_ATOM_INT(_1073)) {
        _1075 = _1073 + _1074;
        if ((long)((unsigned long)_1075 + (unsigned long)HIGH_BITS) >= 0) 
        _1075 = NewDouble((double)_1075);
    }
    else {
        _1075 = NewDouble(DBL_PTR(_1073)->dbl + (double)_1074);
    }
    DeRef(_1073);
    _1073 = NOVALUE;
    _1074 = NOVALUE;
    _1076 = (_greg00_2398 > 0);
    if (100 > 0 && _greg00_2398 >= 0) {
        _1077 = _greg00_2398 / 100;
    }
    else {
        temp_dbl = floor((double)_greg00_2398 / (double)100);
        _1077 = (long)temp_dbl;
    }
    _1078 = - _1077;
    _1079 = (_greg00_2398 % 400) ? NewDouble((double)_greg00_2398 / 400) : (_greg00_2398 / 400);
    if (IS_ATOM_INT(_1079)) {
        _1081 = NewDouble((double)_1079 + DBL_PTR(_1080)->dbl);
    }
    else {
        _1081 = NewDouble(DBL_PTR(_1079)->dbl + DBL_PTR(_1080)->dbl);
    }
    DeRef(_1079);
    _1079 = NOVALUE;
    _1082 = unary_op(FLOOR, _1081);
    DeRefDS(_1081);
    _1081 = NOVALUE;
    if (IS_ATOM_INT(_1082)) {
        _1083 = _1078 + _1082;
        if ((long)((unsigned long)_1083 + (unsigned long)HIGH_BITS) >= 0) 
        _1083 = NewDouble((double)_1083);
    }
    else {
        _1083 = NewDouble((double)_1078 + DBL_PTR(_1082)->dbl);
    }
    _1078 = NOVALUE;
    DeRef(_1082);
    _1082 = NOVALUE;
    if (IS_ATOM_INT(_1083)) {
        if (_1083 <= INT15 && _1083 >= -INT15)
        _1084 = _1076 * _1083;
        else
        _1084 = NewDouble(_1076 * (double)_1083);
    }
    else {
        _1084 = NewDouble((double)_1076 * DBL_PTR(_1083)->dbl);
    }
    _1076 = NOVALUE;
    DeRef(_1083);
    _1083 = NOVALUE;
    if (IS_ATOM_INT(_1075) && IS_ATOM_INT(_1084)) {
        _1085 = _1075 + _1084;
        if ((long)((unsigned long)_1085 + (unsigned long)HIGH_BITS) >= 0) 
        _1085 = NewDouble((double)_1085);
    }
    else {
        if (IS_ATOM_INT(_1075)) {
            _1085 = NewDouble((double)_1075 + DBL_PTR(_1084)->dbl);
        }
        else {
            if (IS_ATOM_INT(_1084)) {
                _1085 = NewDouble(DBL_PTR(_1075)->dbl + (double)_1084);
            }
            else
            _1085 = NewDouble(DBL_PTR(_1075)->dbl + DBL_PTR(_1084)->dbl);
        }
    }
    DeRef(_1075);
    _1075 = NOVALUE;
    DeRef(_1084);
    _1084 = NOVALUE;
    _1086 = (_year_2396 >= 1752);
    _1087 = 11 * _1086;
    _1086 = NOVALUE;
    if (IS_ATOM_INT(_1085)) {
        _1088 = _1085 - _1087;
        if ((long)((unsigned long)_1088 +(unsigned long) HIGH_BITS) >= 0){
            _1088 = NewDouble((double)_1088);
        }
    }
    else {
        _1088 = NewDouble(DBL_PTR(_1085)->dbl - (double)_1087);
    }
    DeRef(_1085);
    _1085 = NOVALUE;
    _1087 = NOVALUE;
    if (IS_ATOM_INT(_1088)) {
        _j_2397 = _j_2397 + _1088;
    }
    else {
        _j_2397 = NewDouble((double)_j_2397 + DBL_PTR(_1088)->dbl);
    }
    DeRef(_1088);
    _1088 = NOVALUE;
    if (!IS_ATOM_INT(_j_2397)) {
        _1 = (long)(DBL_PTR(_j_2397)->dbl);
        DeRefDS(_j_2397);
        _j_2397 = _1;
    }

    /** 	if year >= 3200 then*/
    if (_year_2396 < 3200)
    goto L1; // [97] 133

    /** 		j -= floor(year/ 3200)*/
    if (3200 > 0 && _year_2396 >= 0) {
        _1091 = _year_2396 / 3200;
    }
    else {
        temp_dbl = floor((double)_year_2396 / (double)3200);
        _1091 = (long)temp_dbl;
    }
    _j_2397 = _j_2397 - _1091;
    _1091 = NOVALUE;

    /** 		if year >= 80000 then*/
    if (_year_2396 < 80000)
    goto L2; // [115] 132

    /** 			j += floor(year/80000)*/
    if (80000 > 0 && _year_2396 >= 0) {
        _1094 = _year_2396 / 80000;
    }
    else {
        temp_dbl = floor((double)_year_2396 / (double)80000);
        _1094 = (long)temp_dbl;
    }
    _j_2397 = _j_2397 + _1094;
    _1094 = NOVALUE;
L2: 
L1: 

    /** 	return j*/
    DeRef(_ymd_2395);
    DeRef(_1077);
    _1077 = NOVALUE;
    return _j_2397;
    ;
}


int _18datetimeToSeconds(int _dt_2484)
{
    int _1138 = NOVALUE;
    int _1137 = NOVALUE;
    int _1136 = NOVALUE;
    int _1135 = NOVALUE;
    int _1134 = NOVALUE;
    int _1133 = NOVALUE;
    int _1132 = NOVALUE;
    int _1130 = NOVALUE;
    int _1129 = NOVALUE;
    int _1128 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return julianDay(dt) * DayLengthInSeconds + (dt[4] * 60 + dt[5]) * 60 + dt[6]*/
    Ref(_dt_2484);
    _1128 = _18julianDay(_dt_2484);
    if (IS_ATOM_INT(_1128)) {
        _1129 = NewDouble(_1128 * (double)86400);
    }
    else {
        _1129 = binary_op(MULTIPLY, _1128, 86400);
    }
    DeRef(_1128);
    _1128 = NOVALUE;
    _2 = (int)SEQ_PTR(_dt_2484);
    _1130 = (int)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_1130)) {
        if (_1130 == (short)_1130)
        _1132 = _1130 * 60;
        else
        _1132 = NewDouble(_1130 * (double)60);
    }
    else {
        _1132 = binary_op(MULTIPLY, _1130, 60);
    }
    _1130 = NOVALUE;
    _2 = (int)SEQ_PTR(_dt_2484);
    _1133 = (int)*(((s1_ptr)_2)->base + 5);
    if (IS_ATOM_INT(_1132) && IS_ATOM_INT(_1133)) {
        _1134 = _1132 + _1133;
        if ((long)((unsigned long)_1134 + (unsigned long)HIGH_BITS) >= 0) 
        _1134 = NewDouble((double)_1134);
    }
    else {
        _1134 = binary_op(PLUS, _1132, _1133);
    }
    DeRef(_1132);
    _1132 = NOVALUE;
    _1133 = NOVALUE;
    if (IS_ATOM_INT(_1134)) {
        if (_1134 == (short)_1134)
        _1135 = _1134 * 60;
        else
        _1135 = NewDouble(_1134 * (double)60);
    }
    else {
        _1135 = binary_op(MULTIPLY, _1134, 60);
    }
    DeRef(_1134);
    _1134 = NOVALUE;
    if (IS_ATOM_INT(_1129) && IS_ATOM_INT(_1135)) {
        _1136 = _1129 + _1135;
        if ((long)((unsigned long)_1136 + (unsigned long)HIGH_BITS) >= 0) 
        _1136 = NewDouble((double)_1136);
    }
    else {
        _1136 = binary_op(PLUS, _1129, _1135);
    }
    DeRef(_1129);
    _1129 = NOVALUE;
    DeRef(_1135);
    _1135 = NOVALUE;
    _2 = (int)SEQ_PTR(_dt_2484);
    _1137 = (int)*(((s1_ptr)_2)->base + 6);
    if (IS_ATOM_INT(_1136) && IS_ATOM_INT(_1137)) {
        _1138 = _1136 + _1137;
        if ((long)((unsigned long)_1138 + (unsigned long)HIGH_BITS) >= 0) 
        _1138 = NewDouble((double)_1138);
    }
    else {
        _1138 = binary_op(PLUS, _1136, _1137);
    }
    DeRef(_1136);
    _1136 = NOVALUE;
    _1137 = NOVALUE;
    DeRef(_dt_2484);
    return _1138;
    ;
}


int _18from_date(int _src_2651)
{
    int _1253 = NOVALUE;
    int _1252 = NOVALUE;
    int _1251 = NOVALUE;
    int _1250 = NOVALUE;
    int _1249 = NOVALUE;
    int _1248 = NOVALUE;
    int _1247 = NOVALUE;
    int _1245 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return {src[YEAR]+1900, src[MONTH], src[DAY], src[HOUR], src[MINUTE], src[SECOND]}*/
    _2 = (int)SEQ_PTR(_src_2651);
    _1245 = (int)*(((s1_ptr)_2)->base + 1);
    _1247 = _1245 + 1900;
    if ((long)((unsigned long)_1247 + (unsigned long)HIGH_BITS) >= 0) 
    _1247 = NewDouble((double)_1247);
    _1245 = NOVALUE;
    _2 = (int)SEQ_PTR(_src_2651);
    _1248 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_src_2651);
    _1249 = (int)*(((s1_ptr)_2)->base + 3);
    _2 = (int)SEQ_PTR(_src_2651);
    _1250 = (int)*(((s1_ptr)_2)->base + 4);
    _2 = (int)SEQ_PTR(_src_2651);
    _1251 = (int)*(((s1_ptr)_2)->base + 5);
    _2 = (int)SEQ_PTR(_src_2651);
    _1252 = (int)*(((s1_ptr)_2)->base + 6);
    _1 = NewS1(6);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _1247;
    *((int *)(_2+8)) = _1248;
    *((int *)(_2+12)) = _1249;
    *((int *)(_2+16)) = _1250;
    *((int *)(_2+20)) = _1251;
    *((int *)(_2+24)) = _1252;
    _1253 = MAKE_SEQ(_1);
    _1252 = NOVALUE;
    _1251 = NOVALUE;
    _1250 = NOVALUE;
    _1249 = NOVALUE;
    _1248 = NOVALUE;
    _1247 = NOVALUE;
    DeRefDSi(_src_2651);
    return _1253;
    ;
}


int _18new(int _year_2681, int _month_2682, int _day_2683, int _hour_2684, int _minute_2685, int _second_2686)
{
    int _d_2687 = NOVALUE;
    int _now_1__tmp_at41_2694 = NOVALUE;
    int _now_inlined_now_at_41_2693 = NOVALUE;
    int _1269 = NOVALUE;
    int _1268 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_year_2681)) {
        _1 = (long)(DBL_PTR(_year_2681)->dbl);
        DeRefDS(_year_2681);
        _year_2681 = _1;
    }
    if (!IS_ATOM_INT(_month_2682)) {
        _1 = (long)(DBL_PTR(_month_2682)->dbl);
        DeRefDS(_month_2682);
        _month_2682 = _1;
    }
    if (!IS_ATOM_INT(_day_2683)) {
        _1 = (long)(DBL_PTR(_day_2683)->dbl);
        DeRefDS(_day_2683);
        _day_2683 = _1;
    }
    if (!IS_ATOM_INT(_hour_2684)) {
        _1 = (long)(DBL_PTR(_hour_2684)->dbl);
        DeRefDS(_hour_2684);
        _hour_2684 = _1;
    }
    if (!IS_ATOM_INT(_minute_2685)) {
        _1 = (long)(DBL_PTR(_minute_2685)->dbl);
        DeRefDS(_minute_2685);
        _minute_2685 = _1;
    }

    /** 	d = {year, month, day, hour, minute, second}*/
    _0 = _d_2687;
    _1 = NewS1(6);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _year_2681;
    *((int *)(_2+8)) = _month_2682;
    *((int *)(_2+12)) = _day_2683;
    *((int *)(_2+16)) = _hour_2684;
    *((int *)(_2+20)) = _minute_2685;
    Ref(_second_2686);
    *((int *)(_2+24)) = _second_2686;
    _d_2687 = MAKE_SEQ(_1);
    DeRef(_0);

    /** 	if equal(d, {0,0,0,0,0,0}) then*/
    _1 = NewS1(6);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 0;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = 0;
    *((int *)(_2+16)) = 0;
    *((int *)(_2+20)) = 0;
    *((int *)(_2+24)) = 0;
    _1268 = MAKE_SEQ(_1);
    if (_d_2687 == _1268)
    _1269 = 1;
    else if (IS_ATOM_INT(_d_2687) && IS_ATOM_INT(_1268))
    _1269 = 0;
    else
    _1269 = (compare(_d_2687, _1268) == 0);
    DeRefDS(_1268);
    _1268 = NOVALUE;
    if (_1269 == 0)
    {
        _1269 = NOVALUE;
        goto L1; // [37] 60
    }
    else{
        _1269 = NOVALUE;
    }

    /** 		return now()*/

    /** 	return from_date(date())*/
    DeRefi(_now_1__tmp_at41_2694);
    _now_1__tmp_at41_2694 = Date();
    RefDS(_now_1__tmp_at41_2694);
    _0 = _now_inlined_now_at_41_2693;
    _now_inlined_now_at_41_2693 = _18from_date(_now_1__tmp_at41_2694);
    DeRef(_0);
    DeRefi(_now_1__tmp_at41_2694);
    _now_1__tmp_at41_2694 = NOVALUE;
    DeRef(_second_2686);
    DeRef(_d_2687);
    return _now_inlined_now_at_41_2693;
    goto L2; // [57] 67
L1: 

    /** 		return d*/
    DeRef(_second_2686);
    return _d_2687;
L2: 
    ;
}



// 0xF721331B
