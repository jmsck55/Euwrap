// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int _56iif(int _test_21892, int _ifTrue_21893, int _ifFalse_21894)
{
    int _0, _1, _2;
    

    /** 	if test then*/
    if (_test_21892 == 0)
    {
        goto L1; // [3] 13
    }
    else{
    }

    /** 		return ifTrue*/
    DeRefDS(_ifFalse_21894);
    return _ifTrue_21893;
L1: 

    /** 	return ifFalse*/
    DeRef(_ifTrue_21893);
    return _ifFalse_21894;
    ;
}



// 0xECDE4918
