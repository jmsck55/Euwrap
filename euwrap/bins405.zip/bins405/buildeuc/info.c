// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int _32version_major()
{
    int _6381 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return version_info[MAJ_VER]*/
    _2 = (int)SEQ_PTR(_32version_info_11445);
    _6381 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_6381);
    return _6381;
    ;
}


int _32version_minor()
{
    int _6382 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return version_info[MIN_VER]*/
    _2 = (int)SEQ_PTR(_32version_info_11445);
    _6382 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_6382);
    return _6382;
    ;
}


int _32version_patch()
{
    int _6383 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return version_info[PAT_VER]*/
    _2 = (int)SEQ_PTR(_32version_info_11445);
    _6383 = (int)*(((s1_ptr)_2)->base + 3);
    Ref(_6383);
    return _6383;
    ;
}


int _32version_node(int _full_11483)
{
    int _6390 = NOVALUE;
    int _6389 = NOVALUE;
    int _6388 = NOVALUE;
    int _6387 = NOVALUE;
    int _6386 = NOVALUE;
    int _6385 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if full or length(version_info[NODE]) < 12 then*/
    if (0 != 0) {
        goto L1; // [5] 27
    }
    _2 = (int)SEQ_PTR(_32version_info_11445);
    _6385 = (int)*(((s1_ptr)_2)->base + 5);
    if (IS_SEQUENCE(_6385)){
            _6386 = SEQ_PTR(_6385)->length;
    }
    else {
        _6386 = 1;
    }
    _6385 = NOVALUE;
    _6387 = (_6386 < 12);
    _6386 = NOVALUE;
    if (_6387 == 0)
    {
        DeRef(_6387);
        _6387 = NOVALUE;
        goto L2; // [23] 40
    }
    else{
        DeRef(_6387);
        _6387 = NOVALUE;
    }
L1: 

    /** 		return version_info[NODE]*/
    _2 = (int)SEQ_PTR(_32version_info_11445);
    _6388 = (int)*(((s1_ptr)_2)->base + 5);
    Ref(_6388);
    _6385 = NOVALUE;
    return _6388;
L2: 

    /** 	return version_info[NODE][1..12]*/
    _2 = (int)SEQ_PTR(_32version_info_11445);
    _6389 = (int)*(((s1_ptr)_2)->base + 5);
    rhs_slice_target = (object_ptr)&_6390;
    RHS_Slice(_6389, 1, 12);
    _6389 = NOVALUE;
    _6385 = NOVALUE;
    _6388 = NOVALUE;
    return _6390;
    ;
}


int _32version_date(int _full_11497)
{
    int _6399 = NOVALUE;
    int _6398 = NOVALUE;
    int _6397 = NOVALUE;
    int _6396 = NOVALUE;
    int _6395 = NOVALUE;
    int _6394 = NOVALUE;
    int _6392 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if full or is_developmental or length(version_info[REVISION_DATE]) < 10 then*/
    if (_full_11497 != 0) {
        _6392 = 1;
        goto L1; // [5] 15
    }
    _6392 = (_32is_developmental_11447 != 0);
L1: 
    if (_6392 != 0) {
        goto L2; // [15] 37
    }
    _2 = (int)SEQ_PTR(_32version_info_11445);
    _6394 = (int)*(((s1_ptr)_2)->base + 7);
    if (IS_SEQUENCE(_6394)){
            _6395 = SEQ_PTR(_6394)->length;
    }
    else {
        _6395 = 1;
    }
    _6394 = NOVALUE;
    _6396 = (_6395 < 10);
    _6395 = NOVALUE;
    if (_6396 == 0)
    {
        DeRef(_6396);
        _6396 = NOVALUE;
        goto L3; // [33] 50
    }
    else{
        DeRef(_6396);
        _6396 = NOVALUE;
    }
L2: 

    /** 		return version_info[REVISION_DATE]*/
    _2 = (int)SEQ_PTR(_32version_info_11445);
    _6397 = (int)*(((s1_ptr)_2)->base + 7);
    Ref(_6397);
    _6394 = NOVALUE;
    return _6397;
L3: 

    /** 	return version_info[REVISION_DATE][1..10]*/
    _2 = (int)SEQ_PTR(_32version_info_11445);
    _6398 = (int)*(((s1_ptr)_2)->base + 7);
    rhs_slice_target = (object_ptr)&_6399;
    RHS_Slice(_6398, 1, 10);
    _6398 = NOVALUE;
    _6394 = NOVALUE;
    _6397 = NOVALUE;
    return _6399;
    ;
}


int _32version_string(int _full_11512)
{
    int _version_revision_inlined_version_revision_at_41_11521 = NOVALUE;
    int _6419 = NOVALUE;
    int _6418 = NOVALUE;
    int _6417 = NOVALUE;
    int _6416 = NOVALUE;
    int _6415 = NOVALUE;
    int _6414 = NOVALUE;
    int _6413 = NOVALUE;
    int _6412 = NOVALUE;
    int _6410 = NOVALUE;
    int _6409 = NOVALUE;
    int _6408 = NOVALUE;
    int _6407 = NOVALUE;
    int _6406 = NOVALUE;
    int _6405 = NOVALUE;
    int _6404 = NOVALUE;
    int _6403 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if full or is_developmental then*/
    if (0 != 0) {
        goto L1; // [5] 16
    }
    if (_32is_developmental_11447 == 0)
    {
        goto L2; // [12] 80
    }
    else{
    }
L1: 

    /** 		return sprintf("%d.%d.%d %s (%d:%s, %s)", {*/
    _2 = (int)SEQ_PTR(_32version_info_11445);
    _6403 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_32version_info_11445);
    _6404 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_32version_info_11445);
    _6405 = (int)*(((s1_ptr)_2)->base + 3);
    _2 = (int)SEQ_PTR(_32version_info_11445);
    _6406 = (int)*(((s1_ptr)_2)->base + 4);

    /** 	return version_info[REVISION]*/
    DeRef(_version_revision_inlined_version_revision_at_41_11521);
    _2 = (int)SEQ_PTR(_32version_info_11445);
    _version_revision_inlined_version_revision_at_41_11521 = (int)*(((s1_ptr)_2)->base + 6);
    Ref(_version_revision_inlined_version_revision_at_41_11521);
    _6407 = _32version_node(0);
    _6408 = _32version_date(_full_11512);
    _1 = NewS1(7);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_6403);
    *((int *)(_2+4)) = _6403;
    Ref(_6404);
    *((int *)(_2+8)) = _6404;
    Ref(_6405);
    *((int *)(_2+12)) = _6405;
    Ref(_6406);
    *((int *)(_2+16)) = _6406;
    Ref(_version_revision_inlined_version_revision_at_41_11521);
    *((int *)(_2+20)) = _version_revision_inlined_version_revision_at_41_11521;
    *((int *)(_2+24)) = _6407;
    *((int *)(_2+28)) = _6408;
    _6409 = MAKE_SEQ(_1);
    _6408 = NOVALUE;
    _6407 = NOVALUE;
    _6406 = NOVALUE;
    _6405 = NOVALUE;
    _6404 = NOVALUE;
    _6403 = NOVALUE;
    _6410 = EPrintf(-9999999, _6402, _6409);
    DeRefDS(_6409);
    _6409 = NOVALUE;
    return _6410;
    goto L3; // [77] 132
L2: 

    /** 		return sprintf("%d.%d.%d %s (%s, %s)", {*/
    _2 = (int)SEQ_PTR(_32version_info_11445);
    _6412 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_32version_info_11445);
    _6413 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_32version_info_11445);
    _6414 = (int)*(((s1_ptr)_2)->base + 3);
    _2 = (int)SEQ_PTR(_32version_info_11445);
    _6415 = (int)*(((s1_ptr)_2)->base + 4);
    _6416 = _32version_node(0);
    _6417 = _32version_date(_full_11512);
    _1 = NewS1(6);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_6412);
    *((int *)(_2+4)) = _6412;
    Ref(_6413);
    *((int *)(_2+8)) = _6413;
    Ref(_6414);
    *((int *)(_2+12)) = _6414;
    Ref(_6415);
    *((int *)(_2+16)) = _6415;
    *((int *)(_2+20)) = _6416;
    *((int *)(_2+24)) = _6417;
    _6418 = MAKE_SEQ(_1);
    _6417 = NOVALUE;
    _6416 = NOVALUE;
    _6415 = NOVALUE;
    _6414 = NOVALUE;
    _6413 = NOVALUE;
    _6412 = NOVALUE;
    _6419 = EPrintf(-9999999, _6411, _6418);
    DeRefDS(_6418);
    _6418 = NOVALUE;
    DeRef(_6410);
    _6410 = NOVALUE;
    return _6419;
L3: 
    ;
}


int _32euphoria_copyright()
{
    int _version_string_long_1__tmp_at2_11555 = NOVALUE;
    int _version_string_long_inlined_version_string_long_at_2_11554 = NOVALUE;
    int _platform_name_inlined_platform_name_at_8_inlined_version_string_long_at_2_11553 = NOVALUE;
    int _6429 = NOVALUE;
    int _6427 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return {*/

    /** 	return version_string(full) & " for " & platform_name()*/
    _0 = _version_string_long_1__tmp_at2_11555;
    _version_string_long_1__tmp_at2_11555 = _32version_string(0);
    DeRef(_0);

    /** 	ifdef WINDOWS then*/

    /** 		return "Windows"*/
    RefDS(_6366);
    DeRefi(_platform_name_inlined_platform_name_at_8_inlined_version_string_long_at_2_11553);
    _platform_name_inlined_platform_name_at_8_inlined_version_string_long_at_2_11553 = _6366;
    {
        int concat_list[3];

        concat_list[0] = _platform_name_inlined_platform_name_at_8_inlined_version_string_long_at_2_11553;
        concat_list[1] = _6424;
        concat_list[2] = _version_string_long_1__tmp_at2_11555;
        Concat_N((object_ptr)&_version_string_long_inlined_version_string_long_at_2_11554, concat_list, 3);
    }
    DeRefi(_platform_name_inlined_platform_name_at_8_inlined_version_string_long_at_2_11553);
    _platform_name_inlined_platform_name_at_8_inlined_version_string_long_at_2_11553 = NOVALUE;
    DeRef(_version_string_long_1__tmp_at2_11555);
    _version_string_long_1__tmp_at2_11555 = NOVALUE;
    Concat((object_ptr)&_6427, _6426, _version_string_long_inlined_version_string_long_at_2_11554);
    RefDS(_6428);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _6427;
    ((int *)_2)[2] = _6428;
    _6429 = MAKE_SEQ(_1);
    _6427 = NOVALUE;
    return _6429;
    ;
}


int _32all_copyrights()
{
    int _pcre_copyright_inlined_pcre_copyright_at_5_11568 = NOVALUE;
    int _6434 = NOVALUE;
    int _6433 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return {*/
    _6433 = _32euphoria_copyright();

    /** 	return {*/
    RefDS(_6431);
    RefDS(_6430);
    DeRef(_pcre_copyright_inlined_pcre_copyright_at_5_11568);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _6430;
    ((int *)_2)[2] = _6431;
    _pcre_copyright_inlined_pcre_copyright_at_5_11568 = MAKE_SEQ(_1);
    RefDS(_pcre_copyright_inlined_pcre_copyright_at_5_11568);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _6433;
    ((int *)_2)[2] = _pcre_copyright_inlined_pcre_copyright_at_5_11568;
    _6434 = MAKE_SEQ(_1);
    _6433 = NOVALUE;
    return _6434;
    ;
}



// 0xEBF5D963
