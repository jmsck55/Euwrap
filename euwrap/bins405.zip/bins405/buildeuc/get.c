// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

void _6get_ch()
{
    int _5706 = NOVALUE;
    int _5705 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if sequence(input_string) then*/
    _5705 = IS_SEQUENCE(_6input_string_10247);
    if (_5705 == 0)
    {
        _5705 = NOVALUE;
        goto L1; // [8] 56
    }
    else{
        _5705 = NOVALUE;
    }

    /** 		if string_next <= length(input_string) then*/
    if (IS_SEQUENCE(_6input_string_10247)){
            _5706 = SEQ_PTR(_6input_string_10247)->length;
    }
    else {
        _5706 = 1;
    }
    if (_6string_next_10248 > _5706)
    goto L2; // [20] 47

    /** 			ch = input_string[string_next]*/
    _2 = (int)SEQ_PTR(_6input_string_10247);
    _6ch_10249 = (int)*(((s1_ptr)_2)->base + _6string_next_10248);
    if (!IS_ATOM_INT(_6ch_10249)){
        _6ch_10249 = (long)DBL_PTR(_6ch_10249)->dbl;
    }

    /** 			string_next += 1*/
    _6string_next_10248 = _6string_next_10248 + 1;
    goto L3; // [44] 81
L2: 

    /** 			ch = GET_EOF*/
    _6ch_10249 = -1;
    goto L3; // [53] 81
L1: 

    /** 		ch = getc(input_file)*/
    if (_6input_file_10246 != last_r_file_no) {
        last_r_file_ptr = which_file(_6input_file_10246, EF_READ);
        last_r_file_no = _6input_file_10246;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _6ch_10249 = getKBchar();
        }
        else
        _6ch_10249 = getc(last_r_file_ptr);
    }
    else
    _6ch_10249 = getc(last_r_file_ptr);

    /** 		if ch = GET_EOF then*/
    if (_6ch_10249 != -1)
    goto L4; // [67] 80

    /** 			string_next += 1*/
    _6string_next_10248 = _6string_next_10248 + 1;
L4: 
L3: 

    /** end procedure*/
    return;
    ;
}


int _6escape_char(int _c_10276)
{
    int _i_10277 = NOVALUE;
    int _5718 = NOVALUE;
    int _0, _1, _2;
    

    /** 	i = find(c, ESCAPE_CHARS)*/
    _i_10277 = find_from(_c_10276, _6ESCAPE_CHARS_10270, 1);

    /** 	if i = 0 then*/
    if (_i_10277 != 0)
    goto L1; // [12] 25

    /** 		return GET_FAIL*/
    return 1;
    goto L2; // [22] 36
L1: 

    /** 		return ESCAPED_CHARS[i]*/
    _2 = (int)SEQ_PTR(_6ESCAPED_CHARS_10272);
    _5718 = (int)*(((s1_ptr)_2)->base + _i_10277);
    Ref(_5718);
    return _5718;
L2: 
    ;
}


int _6get_qchar()
{
    int _c_10285 = NOVALUE;
    int _5727 = NOVALUE;
    int _5726 = NOVALUE;
    int _5724 = NOVALUE;
    int _5722 = NOVALUE;
    int _0, _1, _2;
    

    /** 	get_ch()*/
    _6get_ch();

    /** 	c = ch*/
    _c_10285 = _6ch_10249;

    /** 	if ch = '\\' then*/
    if (_6ch_10249 != 92)
    goto L1; // [16] 54

    /** 		get_ch()*/
    _6get_ch();

    /** 		c = escape_char(ch)*/
    _c_10285 = _6escape_char(_6ch_10249);
    if (!IS_ATOM_INT(_c_10285)) {
        _1 = (long)(DBL_PTR(_c_10285)->dbl);
        DeRefDS(_c_10285);
        _c_10285 = _1;
    }

    /** 		if c = GET_FAIL then*/
    if (_c_10285 != 1)
    goto L2; // [36] 74

    /** 			return {GET_FAIL, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = 0;
    _5722 = MAKE_SEQ(_1);
    return _5722;
    goto L2; // [51] 74
L1: 

    /** 	elsif ch = '\'' then*/
    if (_6ch_10249 != 39)
    goto L3; // [58] 73

    /** 		return {GET_FAIL, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = 0;
    _5724 = MAKE_SEQ(_1);
    DeRef(_5722);
    _5722 = NOVALUE;
    return _5724;
L3: 
L2: 

    /** 	get_ch()*/
    _6get_ch();

    /** 	if ch != '\'' then*/
    if (_6ch_10249 == 39)
    goto L4; // [82] 99

    /** 		return {GET_FAIL, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = 0;
    _5726 = MAKE_SEQ(_1);
    DeRef(_5722);
    _5722 = NOVALUE;
    DeRef(_5724);
    _5724 = NOVALUE;
    return _5726;
    goto L5; // [96] 114
L4: 

    /** 		get_ch()*/
    _6get_ch();

    /** 		return {GET_SUCCESS, c}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = _c_10285;
    _5727 = MAKE_SEQ(_1);
    DeRef(_5722);
    _5722 = NOVALUE;
    DeRef(_5724);
    _5724 = NOVALUE;
    DeRef(_5726);
    _5726 = NOVALUE;
    return _5727;
L5: 
    ;
}


int _6get_string()
{
    int _text_10302 = NOVALUE;
    int _5737 = NOVALUE;
    int _5733 = NOVALUE;
    int _5731 = NOVALUE;
    int _5730 = NOVALUE;
    int _5728 = NOVALUE;
    int _0, _1, _2;
    

    /** 	text = ""*/
    RefDS(_5);
    DeRefi(_text_10302);
    _text_10302 = _5;

    /** 	while TRUE do*/
L1: 

    /** 		get_ch()*/
    _6get_ch();

    /** 		if ch = GET_EOF or ch = '\n' then*/
    _5728 = (_6ch_10249 == -1);
    if (_5728 != 0) {
        goto L2; // [25] 40
    }
    _5730 = (_6ch_10249 == 10);
    if (_5730 == 0)
    {
        DeRef(_5730);
        _5730 = NOVALUE;
        goto L3; // [36] 53
    }
    else{
        DeRef(_5730);
        _5730 = NOVALUE;
    }
L2: 

    /** 			return {GET_FAIL, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = 0;
    _5731 = MAKE_SEQ(_1);
    DeRefi(_text_10302);
    DeRef(_5728);
    _5728 = NOVALUE;
    return _5731;
    goto L4; // [50] 121
L3: 

    /** 		elsif ch = '"' then*/
    if (_6ch_10249 != 34)
    goto L5; // [57] 78

    /** 			get_ch()*/
    _6get_ch();

    /** 			return {GET_SUCCESS, text}*/
    RefDS(_text_10302);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = _text_10302;
    _5733 = MAKE_SEQ(_1);
    DeRefDSi(_text_10302);
    DeRef(_5728);
    _5728 = NOVALUE;
    DeRef(_5731);
    _5731 = NOVALUE;
    return _5733;
    goto L4; // [75] 121
L5: 

    /** 		elsif ch = '\\' then*/
    if (_6ch_10249 != 92)
    goto L6; // [82] 120

    /** 			get_ch()*/
    _6get_ch();

    /** 			ch = escape_char(ch)*/
    _0 = _6escape_char(_6ch_10249);
    _6ch_10249 = _0;
    if (!IS_ATOM_INT(_6ch_10249)) {
        _1 = (long)(DBL_PTR(_6ch_10249)->dbl);
        DeRefDS(_6ch_10249);
        _6ch_10249 = _1;
    }

    /** 			if ch = GET_FAIL then*/
    if (_6ch_10249 != 1)
    goto L7; // [104] 119

    /** 				return {GET_FAIL, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = 0;
    _5737 = MAKE_SEQ(_1);
    DeRefi(_text_10302);
    DeRef(_5728);
    _5728 = NOVALUE;
    DeRef(_5731);
    _5731 = NOVALUE;
    DeRef(_5733);
    _5733 = NOVALUE;
    return _5737;
L7: 
L6: 
L4: 

    /** 		text = text & ch*/
    Append(&_text_10302, _text_10302, _6ch_10249);

    /** 	end while*/
    goto L1; // [131] 13
    ;
}


int _6read_comment()
{
    int _5758 = NOVALUE;
    int _5757 = NOVALUE;
    int _5755 = NOVALUE;
    int _5753 = NOVALUE;
    int _5751 = NOVALUE;
    int _5750 = NOVALUE;
    int _5749 = NOVALUE;
    int _5747 = NOVALUE;
    int _5746 = NOVALUE;
    int _5745 = NOVALUE;
    int _5744 = NOVALUE;
    int _5743 = NOVALUE;
    int _5742 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(input_string) then*/
    _5742 = IS_ATOM(_6input_string_10247);
    if (_5742 == 0)
    {
        _5742 = NOVALUE;
        goto L1; // [8] 98
    }
    else{
        _5742 = NOVALUE;
    }

    /** 		while ch!='\n' and ch!='\r' and ch!=-1 do*/
L2: 
    _5743 = (_6ch_10249 != 10);
    if (_5743 == 0) {
        _5744 = 0;
        goto L3; // [22] 36
    }
    _5745 = (_6ch_10249 != 13);
    _5744 = (_5745 != 0);
L3: 
    if (_5744 == 0) {
        goto L4; // [36] 59
    }
    _5747 = (_6ch_10249 != -1);
    if (_5747 == 0)
    {
        DeRef(_5747);
        _5747 = NOVALUE;
        goto L4; // [47] 59
    }
    else{
        DeRef(_5747);
        _5747 = NOVALUE;
    }

    /** 			get_ch()*/
    _6get_ch();

    /** 		end while*/
    goto L2; // [56] 16
L4: 

    /** 		get_ch()*/
    _6get_ch();

    /** 		if ch=-1 then*/
    if (_6ch_10249 != -1)
    goto L5; // [67] 84

    /** 			return {GET_EOF, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -1;
    ((int *)_2)[2] = 0;
    _5749 = MAKE_SEQ(_1);
    DeRef(_5743);
    _5743 = NOVALUE;
    DeRef(_5745);
    _5745 = NOVALUE;
    return _5749;
    goto L6; // [81] 182
L5: 

    /** 			return {GET_IGNORE, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -2;
    ((int *)_2)[2] = 0;
    _5750 = MAKE_SEQ(_1);
    DeRef(_5743);
    _5743 = NOVALUE;
    DeRef(_5745);
    _5745 = NOVALUE;
    DeRef(_5749);
    _5749 = NOVALUE;
    return _5750;
    goto L6; // [95] 182
L1: 

    /** 		for i=string_next to length(input_string) do*/
    if (IS_SEQUENCE(_6input_string_10247)){
            _5751 = SEQ_PTR(_6input_string_10247)->length;
    }
    else {
        _5751 = 1;
    }
    {
        int _i_10343;
        _i_10343 = _6string_next_10248;
L7: 
        if (_i_10343 > _5751){
            goto L8; // [107] 171
        }

        /** 			ch=input_string[i]*/
        _2 = (int)SEQ_PTR(_6input_string_10247);
        _6ch_10249 = (int)*(((s1_ptr)_2)->base + _i_10343);
        if (!IS_ATOM_INT(_6ch_10249)){
            _6ch_10249 = (long)DBL_PTR(_6ch_10249)->dbl;
        }

        /** 			if ch='\n' or ch='\r' then*/
        _5753 = (_6ch_10249 == 10);
        if (_5753 != 0) {
            goto L9; // [132] 147
        }
        _5755 = (_6ch_10249 == 13);
        if (_5755 == 0)
        {
            DeRef(_5755);
            _5755 = NOVALUE;
            goto LA; // [143] 164
        }
        else{
            DeRef(_5755);
            _5755 = NOVALUE;
        }
L9: 

        /** 				string_next=i+1*/
        _6string_next_10248 = _i_10343 + 1;

        /** 				return {GET_IGNORE, 0}*/
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = -2;
        ((int *)_2)[2] = 0;
        _5757 = MAKE_SEQ(_1);
        DeRef(_5743);
        _5743 = NOVALUE;
        DeRef(_5745);
        _5745 = NOVALUE;
        DeRef(_5749);
        _5749 = NOVALUE;
        DeRef(_5750);
        _5750 = NOVALUE;
        DeRef(_5753);
        _5753 = NOVALUE;
        return _5757;
LA: 

        /** 		end for*/
        _i_10343 = _i_10343 + 1;
        goto L7; // [166] 114
L8: 
        ;
    }

    /** 		return {GET_EOF, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -1;
    ((int *)_2)[2] = 0;
    _5758 = MAKE_SEQ(_1);
    DeRef(_5743);
    _5743 = NOVALUE;
    DeRef(_5745);
    _5745 = NOVALUE;
    DeRef(_5749);
    _5749 = NOVALUE;
    DeRef(_5750);
    _5750 = NOVALUE;
    DeRef(_5753);
    _5753 = NOVALUE;
    DeRef(_5757);
    _5757 = NOVALUE;
    return _5758;
L6: 
    ;
}


int _6get_number()
{
    int _sign_10355 = NOVALUE;
    int _e_sign_10356 = NOVALUE;
    int _ndigits_10357 = NOVALUE;
    int _hex_digit_10358 = NOVALUE;
    int _mantissa_10359 = NOVALUE;
    int _dec_10360 = NOVALUE;
    int _e_mag_10361 = NOVALUE;
    int _5819 = NOVALUE;
    int _5817 = NOVALUE;
    int _5815 = NOVALUE;
    int _5812 = NOVALUE;
    int _5808 = NOVALUE;
    int _5806 = NOVALUE;
    int _5805 = NOVALUE;
    int _5804 = NOVALUE;
    int _5803 = NOVALUE;
    int _5802 = NOVALUE;
    int _5800 = NOVALUE;
    int _5799 = NOVALUE;
    int _5798 = NOVALUE;
    int _5795 = NOVALUE;
    int _5793 = NOVALUE;
    int _5791 = NOVALUE;
    int _5787 = NOVALUE;
    int _5786 = NOVALUE;
    int _5784 = NOVALUE;
    int _5783 = NOVALUE;
    int _5782 = NOVALUE;
    int _5779 = NOVALUE;
    int _5778 = NOVALUE;
    int _5776 = NOVALUE;
    int _5775 = NOVALUE;
    int _5774 = NOVALUE;
    int _5773 = NOVALUE;
    int _5772 = NOVALUE;
    int _5771 = NOVALUE;
    int _5768 = NOVALUE;
    int _5764 = NOVALUE;
    int _5761 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sign = +1*/
    _sign_10355 = 1;

    /** 	mantissa = 0*/
    DeRef(_mantissa_10359);
    _mantissa_10359 = 0;

    /** 	ndigits = 0*/
    _ndigits_10357 = 0;

    /** 	if ch = '-' then*/
    if (_6ch_10249 != 45)
    goto L1; // [20] 54

    /** 		sign = -1*/
    _sign_10355 = -1;

    /** 		get_ch()*/
    _6get_ch();

    /** 		if ch='-' then*/
    if (_6ch_10249 != 45)
    goto L2; // [37] 68

    /** 			return read_comment()*/
    _5761 = _6read_comment();
    DeRef(_dec_10360);
    DeRef(_e_mag_10361);
    return _5761;
    goto L2; // [51] 68
L1: 

    /** 	elsif ch = '+' then*/
    if (_6ch_10249 != 43)
    goto L3; // [58] 67

    /** 		get_ch()*/
    _6get_ch();
L3: 
L2: 

    /** 	if ch = '#' then*/
    if (_6ch_10249 != 35)
    goto L4; // [72] 170

    /** 		get_ch()*/
    _6get_ch();

    /** 		while TRUE do*/
L5: 

    /** 			hex_digit = find(ch, HEX_DIGITS)-1*/
    _5764 = find_from(_6ch_10249, _6HEX_DIGITS_10229, 1);
    _hex_digit_10358 = _5764 - 1;
    _5764 = NOVALUE;

    /** 			if hex_digit >= 0 then*/
    if (_hex_digit_10358 < 0)
    goto L6; // [102] 129

    /** 				ndigits += 1*/
    _ndigits_10357 = _ndigits_10357 + 1;

    /** 				mantissa = mantissa * 16 + hex_digit*/
    if (IS_ATOM_INT(_mantissa_10359)) {
        if (_mantissa_10359 == (short)_mantissa_10359)
        _5768 = _mantissa_10359 * 16;
        else
        _5768 = NewDouble(_mantissa_10359 * (double)16);
    }
    else {
        _5768 = NewDouble(DBL_PTR(_mantissa_10359)->dbl * (double)16);
    }
    DeRef(_mantissa_10359);
    if (IS_ATOM_INT(_5768)) {
        _mantissa_10359 = _5768 + _hex_digit_10358;
        if ((long)((unsigned long)_mantissa_10359 + (unsigned long)HIGH_BITS) >= 0) 
        _mantissa_10359 = NewDouble((double)_mantissa_10359);
    }
    else {
        _mantissa_10359 = NewDouble(DBL_PTR(_5768)->dbl + (double)_hex_digit_10358);
    }
    DeRef(_5768);
    _5768 = NOVALUE;

    /** 				get_ch()*/
    _6get_ch();
    goto L5; // [126] 85
L6: 

    /** 				if ndigits > 0 then*/
    if (_ndigits_10357 <= 0)
    goto L7; // [131] 152

    /** 					return {GET_SUCCESS, sign * mantissa}*/
    if (IS_ATOM_INT(_mantissa_10359)) {
        if (_sign_10355 == (short)_sign_10355 && _mantissa_10359 <= INT15 && _mantissa_10359 >= -INT15)
        _5771 = _sign_10355 * _mantissa_10359;
        else
        _5771 = NewDouble(_sign_10355 * (double)_mantissa_10359);
    }
    else {
        _5771 = NewDouble((double)_sign_10355 * DBL_PTR(_mantissa_10359)->dbl);
    }
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = _5771;
    _5772 = MAKE_SEQ(_1);
    _5771 = NOVALUE;
    DeRef(_mantissa_10359);
    DeRef(_dec_10360);
    DeRef(_e_mag_10361);
    DeRef(_5761);
    _5761 = NOVALUE;
    return _5772;
    goto L5; // [149] 85
L7: 

    /** 					return {GET_FAIL, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = 0;
    _5773 = MAKE_SEQ(_1);
    DeRef(_mantissa_10359);
    DeRef(_dec_10360);
    DeRef(_e_mag_10361);
    DeRef(_5761);
    _5761 = NOVALUE;
    DeRef(_5772);
    _5772 = NOVALUE;
    return _5773;

    /** 		end while*/
    goto L5; // [166] 85
L4: 

    /** 	while ch >= '0' and ch <= '9' do*/
L8: 
    _5774 = (_6ch_10249 >= 48);
    if (_5774 == 0) {
        goto L9; // [181] 226
    }
    _5776 = (_6ch_10249 <= 57);
    if (_5776 == 0)
    {
        DeRef(_5776);
        _5776 = NOVALUE;
        goto L9; // [192] 226
    }
    else{
        DeRef(_5776);
        _5776 = NOVALUE;
    }

    /** 		ndigits += 1*/
    _ndigits_10357 = _ndigits_10357 + 1;

    /** 		mantissa = mantissa * 10 + (ch - '0')*/
    if (IS_ATOM_INT(_mantissa_10359)) {
        if (_mantissa_10359 == (short)_mantissa_10359)
        _5778 = _mantissa_10359 * 10;
        else
        _5778 = NewDouble(_mantissa_10359 * (double)10);
    }
    else {
        _5778 = NewDouble(DBL_PTR(_mantissa_10359)->dbl * (double)10);
    }
    _5779 = _6ch_10249 - 48;
    if ((long)((unsigned long)_5779 +(unsigned long) HIGH_BITS) >= 0){
        _5779 = NewDouble((double)_5779);
    }
    DeRef(_mantissa_10359);
    if (IS_ATOM_INT(_5778) && IS_ATOM_INT(_5779)) {
        _mantissa_10359 = _5778 + _5779;
        if ((long)((unsigned long)_mantissa_10359 + (unsigned long)HIGH_BITS) >= 0) 
        _mantissa_10359 = NewDouble((double)_mantissa_10359);
    }
    else {
        if (IS_ATOM_INT(_5778)) {
            _mantissa_10359 = NewDouble((double)_5778 + DBL_PTR(_5779)->dbl);
        }
        else {
            if (IS_ATOM_INT(_5779)) {
                _mantissa_10359 = NewDouble(DBL_PTR(_5778)->dbl + (double)_5779);
            }
            else
            _mantissa_10359 = NewDouble(DBL_PTR(_5778)->dbl + DBL_PTR(_5779)->dbl);
        }
    }
    DeRef(_5778);
    _5778 = NOVALUE;
    DeRef(_5779);
    _5779 = NOVALUE;

    /** 		get_ch()*/
    _6get_ch();

    /** 	end while*/
    goto L8; // [223] 175
L9: 

    /** 	if ch = '.' then*/
    if (_6ch_10249 != 46)
    goto LA; // [230] 306

    /** 		get_ch()*/
    _6get_ch();

    /** 		dec = 10*/
    DeRef(_dec_10360);
    _dec_10360 = 10;

    /** 		while ch >= '0' and ch <= '9' do*/
LB: 
    _5782 = (_6ch_10249 >= 48);
    if (_5782 == 0) {
        goto LC; // [254] 305
    }
    _5784 = (_6ch_10249 <= 57);
    if (_5784 == 0)
    {
        DeRef(_5784);
        _5784 = NOVALUE;
        goto LC; // [265] 305
    }
    else{
        DeRef(_5784);
        _5784 = NOVALUE;
    }

    /** 			ndigits += 1*/
    _ndigits_10357 = _ndigits_10357 + 1;

    /** 			mantissa += (ch - '0') / dec*/
    _5786 = _6ch_10249 - 48;
    if ((long)((unsigned long)_5786 +(unsigned long) HIGH_BITS) >= 0){
        _5786 = NewDouble((double)_5786);
    }
    if (IS_ATOM_INT(_5786) && IS_ATOM_INT(_dec_10360)) {
        _5787 = (_5786 % _dec_10360) ? NewDouble((double)_5786 / _dec_10360) : (_5786 / _dec_10360);
    }
    else {
        if (IS_ATOM_INT(_5786)) {
            _5787 = NewDouble((double)_5786 / DBL_PTR(_dec_10360)->dbl);
        }
        else {
            if (IS_ATOM_INT(_dec_10360)) {
                _5787 = NewDouble(DBL_PTR(_5786)->dbl / (double)_dec_10360);
            }
            else
            _5787 = NewDouble(DBL_PTR(_5786)->dbl / DBL_PTR(_dec_10360)->dbl);
        }
    }
    DeRef(_5786);
    _5786 = NOVALUE;
    _0 = _mantissa_10359;
    if (IS_ATOM_INT(_mantissa_10359) && IS_ATOM_INT(_5787)) {
        _mantissa_10359 = _mantissa_10359 + _5787;
        if ((long)((unsigned long)_mantissa_10359 + (unsigned long)HIGH_BITS) >= 0) 
        _mantissa_10359 = NewDouble((double)_mantissa_10359);
    }
    else {
        if (IS_ATOM_INT(_mantissa_10359)) {
            _mantissa_10359 = NewDouble((double)_mantissa_10359 + DBL_PTR(_5787)->dbl);
        }
        else {
            if (IS_ATOM_INT(_5787)) {
                _mantissa_10359 = NewDouble(DBL_PTR(_mantissa_10359)->dbl + (double)_5787);
            }
            else
            _mantissa_10359 = NewDouble(DBL_PTR(_mantissa_10359)->dbl + DBL_PTR(_5787)->dbl);
        }
    }
    DeRef(_0);
    DeRef(_5787);
    _5787 = NOVALUE;

    /** 			dec *= 10*/
    _0 = _dec_10360;
    if (IS_ATOM_INT(_dec_10360)) {
        if (_dec_10360 == (short)_dec_10360)
        _dec_10360 = _dec_10360 * 10;
        else
        _dec_10360 = NewDouble(_dec_10360 * (double)10);
    }
    else {
        _dec_10360 = NewDouble(DBL_PTR(_dec_10360)->dbl * (double)10);
    }
    DeRef(_0);

    /** 			get_ch()*/
    _6get_ch();

    /** 		end while*/
    goto LB; // [302] 248
LC: 
LA: 

    /** 	if ndigits = 0 then*/
    if (_ndigits_10357 != 0)
    goto LD; // [308] 323

    /** 		return {GET_FAIL, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = 0;
    _5791 = MAKE_SEQ(_1);
    DeRef(_mantissa_10359);
    DeRef(_dec_10360);
    DeRef(_e_mag_10361);
    DeRef(_5761);
    _5761 = NOVALUE;
    DeRef(_5772);
    _5772 = NOVALUE;
    DeRef(_5773);
    _5773 = NOVALUE;
    DeRef(_5774);
    _5774 = NOVALUE;
    DeRef(_5782);
    _5782 = NOVALUE;
    return _5791;
LD: 

    /** 	mantissa = sign * mantissa*/
    _0 = _mantissa_10359;
    if (IS_ATOM_INT(_mantissa_10359)) {
        if (_sign_10355 == (short)_sign_10355 && _mantissa_10359 <= INT15 && _mantissa_10359 >= -INT15)
        _mantissa_10359 = _sign_10355 * _mantissa_10359;
        else
        _mantissa_10359 = NewDouble(_sign_10355 * (double)_mantissa_10359);
    }
    else {
        _mantissa_10359 = NewDouble((double)_sign_10355 * DBL_PTR(_mantissa_10359)->dbl);
    }
    DeRef(_0);

    /** 	if ch = 'e' or ch = 'E' then*/
    _5793 = (_6ch_10249 == 101);
    if (_5793 != 0) {
        goto LE; // [337] 352
    }
    _5795 = (_6ch_10249 == 69);
    if (_5795 == 0)
    {
        DeRef(_5795);
        _5795 = NOVALUE;
        goto LF; // [348] 573
    }
    else{
        DeRef(_5795);
        _5795 = NOVALUE;
    }
LE: 

    /** 		e_sign = +1*/
    _e_sign_10356 = 1;

    /** 		e_mag = 0*/
    DeRef(_e_mag_10361);
    _e_mag_10361 = 0;

    /** 		get_ch()*/
    _6get_ch();

    /** 		if ch = '-' then*/
    if (_6ch_10249 != 45)
    goto L10; // [370] 386

    /** 			e_sign = -1*/
    _e_sign_10356 = -1;

    /** 			get_ch()*/
    _6get_ch();
    goto L11; // [383] 400
L10: 

    /** 		elsif ch = '+' then*/
    if (_6ch_10249 != 43)
    goto L12; // [390] 399

    /** 			get_ch()*/
    _6get_ch();
L12: 
L11: 

    /** 		if ch >= '0' and ch <= '9' then*/
    _5798 = (_6ch_10249 >= 48);
    if (_5798 == 0) {
        goto L13; // [408] 487
    }
    _5800 = (_6ch_10249 <= 57);
    if (_5800 == 0)
    {
        DeRef(_5800);
        _5800 = NOVALUE;
        goto L13; // [419] 487
    }
    else{
        DeRef(_5800);
        _5800 = NOVALUE;
    }

    /** 			e_mag = ch - '0'*/
    DeRef(_e_mag_10361);
    _e_mag_10361 = _6ch_10249 - 48;
    if ((long)((unsigned long)_e_mag_10361 +(unsigned long) HIGH_BITS) >= 0){
        _e_mag_10361 = NewDouble((double)_e_mag_10361);
    }

    /** 			get_ch()*/
    _6get_ch();

    /** 			while ch >= '0' and ch <= '9' do*/
L14: 
    _5802 = (_6ch_10249 >= 48);
    if (_5802 == 0) {
        goto L15; // [445] 498
    }
    _5804 = (_6ch_10249 <= 57);
    if (_5804 == 0)
    {
        DeRef(_5804);
        _5804 = NOVALUE;
        goto L15; // [456] 498
    }
    else{
        DeRef(_5804);
        _5804 = NOVALUE;
    }

    /** 				e_mag = e_mag * 10 + ch - '0'*/
    if (IS_ATOM_INT(_e_mag_10361)) {
        if (_e_mag_10361 == (short)_e_mag_10361)
        _5805 = _e_mag_10361 * 10;
        else
        _5805 = NewDouble(_e_mag_10361 * (double)10);
    }
    else {
        _5805 = NewDouble(DBL_PTR(_e_mag_10361)->dbl * (double)10);
    }
    if (IS_ATOM_INT(_5805)) {
        _5806 = _5805 + _6ch_10249;
        if ((long)((unsigned long)_5806 + (unsigned long)HIGH_BITS) >= 0) 
        _5806 = NewDouble((double)_5806);
    }
    else {
        _5806 = NewDouble(DBL_PTR(_5805)->dbl + (double)_6ch_10249);
    }
    DeRef(_5805);
    _5805 = NOVALUE;
    DeRef(_e_mag_10361);
    if (IS_ATOM_INT(_5806)) {
        _e_mag_10361 = _5806 - 48;
        if ((long)((unsigned long)_e_mag_10361 +(unsigned long) HIGH_BITS) >= 0){
            _e_mag_10361 = NewDouble((double)_e_mag_10361);
        }
    }
    else {
        _e_mag_10361 = NewDouble(DBL_PTR(_5806)->dbl - (double)48);
    }
    DeRef(_5806);
    _5806 = NOVALUE;

    /** 				get_ch()*/
    _6get_ch();

    /** 			end while*/
    goto L14; // [481] 439
    goto L15; // [484] 498
L13: 

    /** 			return {GET_FAIL, 0} -- no exponent*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = 0;
    _5808 = MAKE_SEQ(_1);
    DeRef(_mantissa_10359);
    DeRef(_dec_10360);
    DeRef(_e_mag_10361);
    DeRef(_5761);
    _5761 = NOVALUE;
    DeRef(_5772);
    _5772 = NOVALUE;
    DeRef(_5773);
    _5773 = NOVALUE;
    DeRef(_5774);
    _5774 = NOVALUE;
    DeRef(_5782);
    _5782 = NOVALUE;
    DeRef(_5791);
    _5791 = NOVALUE;
    DeRef(_5793);
    _5793 = NOVALUE;
    DeRef(_5798);
    _5798 = NOVALUE;
    DeRef(_5802);
    _5802 = NOVALUE;
    return _5808;
L15: 

    /** 		e_mag *= e_sign*/
    _0 = _e_mag_10361;
    if (IS_ATOM_INT(_e_mag_10361)) {
        if (_e_mag_10361 == (short)_e_mag_10361 && _e_sign_10356 <= INT15 && _e_sign_10356 >= -INT15)
        _e_mag_10361 = _e_mag_10361 * _e_sign_10356;
        else
        _e_mag_10361 = NewDouble(_e_mag_10361 * (double)_e_sign_10356);
    }
    else {
        _e_mag_10361 = NewDouble(DBL_PTR(_e_mag_10361)->dbl * (double)_e_sign_10356);
    }
    DeRef(_0);

    /** 		if e_mag > 308 then*/
    if (binary_op_a(LESSEQ, _e_mag_10361, 308)){
        goto L16; // [506] 561
    }

    /** 			mantissa *= power(10, 308)*/
    _5812 = power(10, 308);
    _0 = _mantissa_10359;
    if (IS_ATOM_INT(_mantissa_10359) && IS_ATOM_INT(_5812)) {
        if (_mantissa_10359 == (short)_mantissa_10359 && _5812 <= INT15 && _5812 >= -INT15)
        _mantissa_10359 = _mantissa_10359 * _5812;
        else
        _mantissa_10359 = NewDouble(_mantissa_10359 * (double)_5812);
    }
    else {
        if (IS_ATOM_INT(_mantissa_10359)) {
            _mantissa_10359 = NewDouble((double)_mantissa_10359 * DBL_PTR(_5812)->dbl);
        }
        else {
            if (IS_ATOM_INT(_5812)) {
                _mantissa_10359 = NewDouble(DBL_PTR(_mantissa_10359)->dbl * (double)_5812);
            }
            else
            _mantissa_10359 = NewDouble(DBL_PTR(_mantissa_10359)->dbl * DBL_PTR(_5812)->dbl);
        }
    }
    DeRef(_0);
    DeRef(_5812);
    _5812 = NOVALUE;

    /** 			if e_mag > 1000 then*/
    if (binary_op_a(LESSEQ, _e_mag_10361, 1000)){
        goto L17; // [522] 532
    }

    /** 				e_mag = 1000*/
    DeRef(_e_mag_10361);
    _e_mag_10361 = 1000;
L17: 

    /** 			for i = 1 to e_mag - 308 do*/
    if (IS_ATOM_INT(_e_mag_10361)) {
        _5815 = _e_mag_10361 - 308;
        if ((long)((unsigned long)_5815 +(unsigned long) HIGH_BITS) >= 0){
            _5815 = NewDouble((double)_5815);
        }
    }
    else {
        _5815 = NewDouble(DBL_PTR(_e_mag_10361)->dbl - (double)308);
    }
    {
        int _i_10440;
        _i_10440 = 1;
L18: 
        if (binary_op_a(GREATER, _i_10440, _5815)){
            goto L19; // [538] 558
        }

        /** 				mantissa *= 10*/
        _0 = _mantissa_10359;
        if (IS_ATOM_INT(_mantissa_10359)) {
            if (_mantissa_10359 == (short)_mantissa_10359)
            _mantissa_10359 = _mantissa_10359 * 10;
            else
            _mantissa_10359 = NewDouble(_mantissa_10359 * (double)10);
        }
        else {
            _mantissa_10359 = NewDouble(DBL_PTR(_mantissa_10359)->dbl * (double)10);
        }
        DeRef(_0);

        /** 			end for*/
        _0 = _i_10440;
        if (IS_ATOM_INT(_i_10440)) {
            _i_10440 = _i_10440 + 1;
            if ((long)((unsigned long)_i_10440 +(unsigned long) HIGH_BITS) >= 0){
                _i_10440 = NewDouble((double)_i_10440);
            }
        }
        else {
            _i_10440 = binary_op_a(PLUS, _i_10440, 1);
        }
        DeRef(_0);
        goto L18; // [553] 545
L19: 
        ;
        DeRef(_i_10440);
    }
    goto L1A; // [558] 572
L16: 

    /** 			mantissa *= power(10, e_mag)*/
    if (IS_ATOM_INT(_e_mag_10361)) {
        _5817 = power(10, _e_mag_10361);
    }
    else {
        temp_d.dbl = (double)10;
        _5817 = Dpower(&temp_d, DBL_PTR(_e_mag_10361));
    }
    _0 = _mantissa_10359;
    if (IS_ATOM_INT(_mantissa_10359) && IS_ATOM_INT(_5817)) {
        if (_mantissa_10359 == (short)_mantissa_10359 && _5817 <= INT15 && _5817 >= -INT15)
        _mantissa_10359 = _mantissa_10359 * _5817;
        else
        _mantissa_10359 = NewDouble(_mantissa_10359 * (double)_5817);
    }
    else {
        if (IS_ATOM_INT(_mantissa_10359)) {
            _mantissa_10359 = NewDouble((double)_mantissa_10359 * DBL_PTR(_5817)->dbl);
        }
        else {
            if (IS_ATOM_INT(_5817)) {
                _mantissa_10359 = NewDouble(DBL_PTR(_mantissa_10359)->dbl * (double)_5817);
            }
            else
            _mantissa_10359 = NewDouble(DBL_PTR(_mantissa_10359)->dbl * DBL_PTR(_5817)->dbl);
        }
    }
    DeRef(_0);
    DeRef(_5817);
    _5817 = NOVALUE;
L1A: 
LF: 

    /** 	return {GET_SUCCESS, mantissa}*/
    Ref(_mantissa_10359);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = _mantissa_10359;
    _5819 = MAKE_SEQ(_1);
    DeRef(_mantissa_10359);
    DeRef(_dec_10360);
    DeRef(_e_mag_10361);
    DeRef(_5761);
    _5761 = NOVALUE;
    DeRef(_5772);
    _5772 = NOVALUE;
    DeRef(_5773);
    _5773 = NOVALUE;
    DeRef(_5774);
    _5774 = NOVALUE;
    DeRef(_5782);
    _5782 = NOVALUE;
    DeRef(_5791);
    _5791 = NOVALUE;
    DeRef(_5793);
    _5793 = NOVALUE;
    DeRef(_5798);
    _5798 = NOVALUE;
    DeRef(_5802);
    _5802 = NOVALUE;
    DeRef(_5808);
    _5808 = NOVALUE;
    DeRef(_5815);
    _5815 = NOVALUE;
    return _5819;
    ;
}


int _6Get()
{
    int _skip_blanks_1__tmp_at328_10493 = NOVALUE;
    int _skip_blanks_1__tmp_at177_10474 = NOVALUE;
    int _skip_blanks_1__tmp_at88_10465 = NOVALUE;
    int _s_10449 = NOVALUE;
    int _e_10450 = NOVALUE;
    int _e1_10451 = NOVALUE;
    int _5855 = NOVALUE;
    int _5854 = NOVALUE;
    int _5852 = NOVALUE;
    int _5850 = NOVALUE;
    int _5848 = NOVALUE;
    int _5846 = NOVALUE;
    int _5843 = NOVALUE;
    int _5841 = NOVALUE;
    int _5837 = NOVALUE;
    int _5833 = NOVALUE;
    int _5830 = NOVALUE;
    int _5829 = NOVALUE;
    int _5827 = NOVALUE;
    int _5825 = NOVALUE;
    int _5823 = NOVALUE;
    int _5822 = NOVALUE;
    int _5820 = NOVALUE;
    int _0, _1, _2;
    

    /** 	while find(ch, white_space) do*/
L1: 
    _5820 = find_from(_6ch_10249, _6white_space_10265, 1);
    if (_5820 == 0)
    {
        _5820 = NOVALUE;
        goto L2; // [13] 25
    }
    else{
        _5820 = NOVALUE;
    }

    /** 		get_ch()*/
    _6get_ch();

    /** 	end while*/
    goto L1; // [22] 6
L2: 

    /** 	if ch = -1 then -- string is made of whitespace only*/
    if (_6ch_10249 != -1)
    goto L3; // [29] 44

    /** 		return {GET_EOF, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -1;
    ((int *)_2)[2] = 0;
    _5822 = MAKE_SEQ(_1);
    DeRef(_s_10449);
    DeRef(_e_10450);
    return _5822;
L3: 

    /** 	while 1 do*/
L4: 

    /** 		if find(ch, START_NUMERIC) then*/
    _5823 = find_from(_6ch_10249, _6START_NUMERIC_10232, 1);
    if (_5823 == 0)
    {
        _5823 = NOVALUE;
        goto L5; // [60] 157
    }
    else{
        _5823 = NOVALUE;
    }

    /** 			e = get_number()*/
    _0 = _e_10450;
    _e_10450 = _6get_number();
    DeRef(_0);

    /** 			if e[1] != GET_IGNORE then -- either a number or something illegal was read, so exit: the other goto*/
    _2 = (int)SEQ_PTR(_e_10450);
    _5825 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _5825, -2)){
        _5825 = NOVALUE;
        goto L6; // [76] 87
    }
    _5825 = NOVALUE;

    /** 				return e*/
    DeRef(_s_10449);
    DeRef(_5822);
    _5822 = NOVALUE;
    return _e_10450;
L6: 

    /** 			skip_blanks()*/

    /** 	while find(ch, white_space) do*/
L7: 
    _skip_blanks_1__tmp_at88_10465 = find_from(_6ch_10249, _6white_space_10265, 1);
    if (_skip_blanks_1__tmp_at88_10465 == 0)
    {
        goto L8; // [101] 118
    }
    else{
    }

    /** 		get_ch()*/
    _6get_ch();

    /** 	end while*/
    goto L7; // [110] 94

    /** end procedure*/
    goto L8; // [115] 118
L8: 

    /** 			if ch=-1 or ch='}' then -- '}' is expected only in the "{--\n}" case*/
    _5827 = (_6ch_10249 == -1);
    if (_5827 != 0) {
        goto L9; // [128] 143
    }
    _5829 = (_6ch_10249 == 125);
    if (_5829 == 0)
    {
        DeRef(_5829);
        _5829 = NOVALUE;
        goto L4; // [139] 49
    }
    else{
        DeRef(_5829);
        _5829 = NOVALUE;
    }
L9: 

    /** 				return {GET_NOTHING, 0} -- just a comment*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -2;
    ((int *)_2)[2] = 0;
    _5830 = MAKE_SEQ(_1);
    DeRef(_s_10449);
    DeRef(_e_10450);
    DeRef(_5822);
    _5822 = NOVALUE;
    DeRef(_5827);
    _5827 = NOVALUE;
    return _5830;
    goto L4; // [154] 49
L5: 

    /** 		elsif ch = '{' then*/
    if (_6ch_10249 != 123)
    goto LA; // [161] 465

    /** 			s = {}*/
    RefDS(_5);
    DeRef(_s_10449);
    _s_10449 = _5;

    /** 			get_ch()*/
    _6get_ch();

    /** 			skip_blanks()*/

    /** 	while find(ch, white_space) do*/
LB: 
    _skip_blanks_1__tmp_at177_10474 = find_from(_6ch_10249, _6white_space_10265, 1);
    if (_skip_blanks_1__tmp_at177_10474 == 0)
    {
        goto LC; // [190] 207
    }
    else{
    }

    /** 		get_ch()*/
    _6get_ch();

    /** 	end while*/
    goto LB; // [199] 183

    /** end procedure*/
    goto LC; // [204] 207
LC: 

    /** 			if ch = '}' then -- empty sequence*/
    if (_6ch_10249 != 125)
    goto LD; // [213] 232

    /** 				get_ch()*/
    _6get_ch();

    /** 				return {GET_SUCCESS, s} -- empty sequence*/
    RefDS(_s_10449);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = _s_10449;
    _5833 = MAKE_SEQ(_1);
    DeRefDS(_s_10449);
    DeRef(_e_10450);
    DeRef(_5822);
    _5822 = NOVALUE;
    DeRef(_5827);
    _5827 = NOVALUE;
    DeRef(_5830);
    _5830 = NOVALUE;
    return _5833;
LD: 

    /** 			while TRUE do -- read: comment(s), element, comment(s), comma and so on till it terminates or errors out*/
LE: 

    /** 				while 1 do -- read zero or more comments and an element*/
LF: 

    /** 					e = Get() -- read next element, using standard function*/
    _0 = _e_10450;
    _e_10450 = _6Get();
    DeRef(_0);

    /** 					e1 = e[1]*/
    _2 = (int)SEQ_PTR(_e_10450);
    _e1_10451 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_e1_10451))
    _e1_10451 = (long)DBL_PTR(_e1_10451)->dbl;

    /** 					if e1 = GET_SUCCESS then*/
    if (_e1_10451 != 0)
    goto L10; // [257] 278

    /** 						s = append(s, e[2])*/
    _2 = (int)SEQ_PTR(_e_10450);
    _5837 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_5837);
    Append(&_s_10449, _s_10449, _5837);
    _5837 = NOVALUE;

    /** 						exit  -- element read and added to result*/
    goto L11; // [273] 322
    goto LF; // [275] 242
L10: 

    /** 					elsif e1 != GET_IGNORE then*/
    if (_e1_10451 == -2)
    goto L12; // [280] 293

    /** 						return e*/
    DeRef(_s_10449);
    DeRef(_5822);
    _5822 = NOVALUE;
    DeRef(_5827);
    _5827 = NOVALUE;
    DeRef(_5830);
    _5830 = NOVALUE;
    DeRef(_5833);
    _5833 = NOVALUE;
    return _e_10450;
    goto LF; // [290] 242
L12: 

    /** 					elsif ch='}' then*/
    if (_6ch_10249 != 125)
    goto LF; // [297] 242

    /** 						get_ch()*/
    _6get_ch();

    /** 						return {GET_SUCCESS, s} -- empty sequence*/
    RefDS(_s_10449);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = _s_10449;
    _5841 = MAKE_SEQ(_1);
    DeRefDS(_s_10449);
    DeRef(_e_10450);
    DeRef(_5822);
    _5822 = NOVALUE;
    DeRef(_5827);
    _5827 = NOVALUE;
    DeRef(_5830);
    _5830 = NOVALUE;
    DeRef(_5833);
    _5833 = NOVALUE;
    return _5841;

    /** 				end while*/
    goto LF; // [319] 242
L11: 

    /** 				while 1 do -- now read zero or more post element comments*/
L13: 

    /** 					skip_blanks()*/

    /** 	while find(ch, white_space) do*/
L14: 
    _skip_blanks_1__tmp_at328_10493 = find_from(_6ch_10249, _6white_space_10265, 1);
    if (_skip_blanks_1__tmp_at328_10493 == 0)
    {
        goto L15; // [341] 358
    }
    else{
    }

    /** 		get_ch()*/
    _6get_ch();

    /** 	end while*/
    goto L14; // [350] 334

    /** end procedure*/
    goto L15; // [355] 358
L15: 

    /** 					if ch = '}' then*/
    if (_6ch_10249 != 125)
    goto L16; // [364] 385

    /** 						get_ch()*/
    _6get_ch();

    /** 					return {GET_SUCCESS, s}*/
    RefDS(_s_10449);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = _s_10449;
    _5843 = MAKE_SEQ(_1);
    DeRefDS(_s_10449);
    DeRef(_e_10450);
    DeRef(_5822);
    _5822 = NOVALUE;
    DeRef(_5827);
    _5827 = NOVALUE;
    DeRef(_5830);
    _5830 = NOVALUE;
    DeRef(_5833);
    _5833 = NOVALUE;
    DeRef(_5841);
    _5841 = NOVALUE;
    return _5843;
    goto L13; // [382] 327
L16: 

    /** 					elsif ch!='-' then*/
    if (_6ch_10249 == 45)
    goto L17; // [389] 400

    /** 						exit*/
    goto L18; // [395] 434
    goto L13; // [397] 327
L17: 

    /** 						e = get_number() -- reads anything starting with '-'*/
    _0 = _e_10450;
    _e_10450 = _6get_number();
    DeRef(_0);

    /** 						if e[1] != GET_IGNORE then  -- it wasn't a comment, this is illegal*/
    _2 = (int)SEQ_PTR(_e_10450);
    _5846 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _5846, -2)){
        _5846 = NOVALUE;
        goto L13; // [413] 327
    }
    _5846 = NOVALUE;

    /** 							return {GET_FAIL, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = 0;
    _5848 = MAKE_SEQ(_1);
    DeRef(_s_10449);
    DeRefDS(_e_10450);
    DeRef(_5822);
    _5822 = NOVALUE;
    DeRef(_5827);
    _5827 = NOVALUE;
    DeRef(_5830);
    _5830 = NOVALUE;
    DeRef(_5833);
    _5833 = NOVALUE;
    DeRef(_5841);
    _5841 = NOVALUE;
    DeRef(_5843);
    _5843 = NOVALUE;
    return _5848;

    /** 			end while*/
    goto L13; // [431] 327
L18: 

    /** 				if ch != ',' then*/
    if (_6ch_10249 == 44)
    goto L19; // [438] 453

    /** 				return {GET_FAIL, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = 0;
    _5850 = MAKE_SEQ(_1);
    DeRef(_s_10449);
    DeRef(_e_10450);
    DeRef(_5822);
    _5822 = NOVALUE;
    DeRef(_5827);
    _5827 = NOVALUE;
    DeRef(_5830);
    _5830 = NOVALUE;
    DeRef(_5833);
    _5833 = NOVALUE;
    DeRef(_5841);
    _5841 = NOVALUE;
    DeRef(_5843);
    _5843 = NOVALUE;
    DeRef(_5848);
    _5848 = NOVALUE;
    return _5850;
L19: 

    /** 			get_ch() -- skip comma*/
    _6get_ch();

    /** 			end while*/
    goto LE; // [459] 237
    goto L4; // [462] 49
LA: 

    /** 		elsif ch = '\"' then*/
    if (_6ch_10249 != 34)
    goto L1A; // [469] 485

    /** 			return get_string()*/
    _5852 = _6get_string();
    DeRef(_s_10449);
    DeRef(_e_10450);
    DeRef(_5822);
    _5822 = NOVALUE;
    DeRef(_5827);
    _5827 = NOVALUE;
    DeRef(_5830);
    _5830 = NOVALUE;
    DeRef(_5833);
    _5833 = NOVALUE;
    DeRef(_5841);
    _5841 = NOVALUE;
    DeRef(_5843);
    _5843 = NOVALUE;
    DeRef(_5848);
    _5848 = NOVALUE;
    DeRef(_5850);
    _5850 = NOVALUE;
    return _5852;
    goto L4; // [482] 49
L1A: 

    /** 		elsif ch = '\'' then*/
    if (_6ch_10249 != 39)
    goto L1B; // [489] 505

    /** 			return get_qchar()*/
    _5854 = _6get_qchar();
    DeRef(_s_10449);
    DeRef(_e_10450);
    DeRef(_5822);
    _5822 = NOVALUE;
    DeRef(_5827);
    _5827 = NOVALUE;
    DeRef(_5830);
    _5830 = NOVALUE;
    DeRef(_5833);
    _5833 = NOVALUE;
    DeRef(_5841);
    _5841 = NOVALUE;
    DeRef(_5843);
    _5843 = NOVALUE;
    DeRef(_5848);
    _5848 = NOVALUE;
    DeRef(_5850);
    _5850 = NOVALUE;
    DeRef(_5852);
    _5852 = NOVALUE;
    return _5854;
    goto L4; // [502] 49
L1B: 

    /** 			return {GET_FAIL, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = 0;
    _5855 = MAKE_SEQ(_1);
    DeRef(_s_10449);
    DeRef(_e_10450);
    DeRef(_5822);
    _5822 = NOVALUE;
    DeRef(_5827);
    _5827 = NOVALUE;
    DeRef(_5830);
    _5830 = NOVALUE;
    DeRef(_5833);
    _5833 = NOVALUE;
    DeRef(_5841);
    _5841 = NOVALUE;
    DeRef(_5843);
    _5843 = NOVALUE;
    DeRef(_5848);
    _5848 = NOVALUE;
    DeRef(_5850);
    _5850 = NOVALUE;
    DeRef(_5852);
    _5852 = NOVALUE;
    DeRef(_5854);
    _5854 = NOVALUE;
    return _5855;

    /** 	end while*/
    goto L4; // [518] 49
    ;
}


int _6Get2()
{
    int _skip_blanks_1__tmp_at464_10590 = NOVALUE;
    int _skip_blanks_1__tmp_at233_10557 = NOVALUE;
    int _s_10519 = NOVALUE;
    int _e_10520 = NOVALUE;
    int _e1_10521 = NOVALUE;
    int _offset_10522 = NOVALUE;
    int _5947 = NOVALUE;
    int _5946 = NOVALUE;
    int _5945 = NOVALUE;
    int _5944 = NOVALUE;
    int _5943 = NOVALUE;
    int _5942 = NOVALUE;
    int _5941 = NOVALUE;
    int _5940 = NOVALUE;
    int _5939 = NOVALUE;
    int _5938 = NOVALUE;
    int _5937 = NOVALUE;
    int _5934 = NOVALUE;
    int _5933 = NOVALUE;
    int _5932 = NOVALUE;
    int _5931 = NOVALUE;
    int _5930 = NOVALUE;
    int _5929 = NOVALUE;
    int _5926 = NOVALUE;
    int _5925 = NOVALUE;
    int _5924 = NOVALUE;
    int _5923 = NOVALUE;
    int _5922 = NOVALUE;
    int _5920 = NOVALUE;
    int _5919 = NOVALUE;
    int _5918 = NOVALUE;
    int _5917 = NOVALUE;
    int _5916 = NOVALUE;
    int _5914 = NOVALUE;
    int _5911 = NOVALUE;
    int _5910 = NOVALUE;
    int _5909 = NOVALUE;
    int _5908 = NOVALUE;
    int _5907 = NOVALUE;
    int _5905 = NOVALUE;
    int _5904 = NOVALUE;
    int _5903 = NOVALUE;
    int _5902 = NOVALUE;
    int _5901 = NOVALUE;
    int _5899 = NOVALUE;
    int _5898 = NOVALUE;
    int _5897 = NOVALUE;
    int _5896 = NOVALUE;
    int _5895 = NOVALUE;
    int _5894 = NOVALUE;
    int _5891 = NOVALUE;
    int _5887 = NOVALUE;
    int _5886 = NOVALUE;
    int _5885 = NOVALUE;
    int _5884 = NOVALUE;
    int _5883 = NOVALUE;
    int _5880 = NOVALUE;
    int _5879 = NOVALUE;
    int _5878 = NOVALUE;
    int _5877 = NOVALUE;
    int _5876 = NOVALUE;
    int _5874 = NOVALUE;
    int _5873 = NOVALUE;
    int _5872 = NOVALUE;
    int _5871 = NOVALUE;
    int _5870 = NOVALUE;
    int _5869 = NOVALUE;
    int _5867 = NOVALUE;
    int _5865 = NOVALUE;
    int _5863 = NOVALUE;
    int _5862 = NOVALUE;
    int _5861 = NOVALUE;
    int _5860 = NOVALUE;
    int _5859 = NOVALUE;
    int _5857 = NOVALUE;
    int _0, _1, _2;
    

    /** 	offset = string_next-1*/
    _offset_10522 = _6string_next_10248 - 1;

    /** 	get_ch()*/
    _6get_ch();

    /** 	while find(ch, white_space) do*/
L1: 
    _5857 = find_from(_6ch_10249, _6white_space_10265, 1);
    if (_5857 == 0)
    {
        _5857 = NOVALUE;
        goto L2; // [25] 37
    }
    else{
        _5857 = NOVALUE;
    }

    /** 		get_ch()*/
    _6get_ch();

    /** 	end while*/
    goto L1; // [34] 18
L2: 

    /** 	if ch = -1 then -- string is made of whitespace only*/
    if (_6ch_10249 != -1)
    goto L3; // [41] 75

    /** 		return {GET_EOF, 0, string_next-1-offset ,string_next-1}*/
    _5859 = _6string_next_10248 - 1;
    if ((long)((unsigned long)_5859 +(unsigned long) HIGH_BITS) >= 0){
        _5859 = NewDouble((double)_5859);
    }
    if (IS_ATOM_INT(_5859)) {
        _5860 = _5859 - _offset_10522;
        if ((long)((unsigned long)_5860 +(unsigned long) HIGH_BITS) >= 0){
            _5860 = NewDouble((double)_5860);
        }
    }
    else {
        _5860 = NewDouble(DBL_PTR(_5859)->dbl - (double)_offset_10522);
    }
    DeRef(_5859);
    _5859 = NOVALUE;
    _5861 = _6string_next_10248 - 1;
    if ((long)((unsigned long)_5861 +(unsigned long) HIGH_BITS) >= 0){
        _5861 = NewDouble((double)_5861);
    }
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = -1;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = _5860;
    *((int *)(_2+16)) = _5861;
    _5862 = MAKE_SEQ(_1);
    _5861 = NOVALUE;
    _5860 = NOVALUE;
    DeRef(_s_10519);
    DeRef(_e_10520);
    return _5862;
L3: 

    /** 	leading_whitespace = string_next-2-offset -- index of the last whitespace: string_next points past the first non whitespace*/
    _5863 = _6string_next_10248 - 2;
    if ((long)((unsigned long)_5863 +(unsigned long) HIGH_BITS) >= 0){
        _5863 = NewDouble((double)_5863);
    }
    if (IS_ATOM_INT(_5863)) {
        _6leading_whitespace_10516 = _5863 - _offset_10522;
    }
    else {
        _6leading_whitespace_10516 = NewDouble(DBL_PTR(_5863)->dbl - (double)_offset_10522);
    }
    DeRef(_5863);
    _5863 = NOVALUE;
    if (!IS_ATOM_INT(_6leading_whitespace_10516)) {
        _1 = (long)(DBL_PTR(_6leading_whitespace_10516)->dbl);
        DeRefDS(_6leading_whitespace_10516);
        _6leading_whitespace_10516 = _1;
    }

    /** 	while 1 do*/
L4: 

    /** 		if find(ch, START_NUMERIC) then*/
    _5865 = find_from(_6ch_10249, _6START_NUMERIC_10232, 1);
    if (_5865 == 0)
    {
        _5865 = NOVALUE;
        goto L5; // [105] 213
    }
    else{
        _5865 = NOVALUE;
    }

    /** 			e = get_number()*/
    _0 = _e_10520;
    _e_10520 = _6get_number();
    DeRef(_0);

    /** 			if e[1] != GET_IGNORE then -- either a number or something illegal was read, so exit: the other goto*/
    _2 = (int)SEQ_PTR(_e_10520);
    _5867 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _5867, -2)){
        _5867 = NOVALUE;
        goto L6; // [121] 162
    }
    _5867 = NOVALUE;

    /** 				return e & {string_next-1-offset-(ch!=-1), leading_whitespace}*/
    _5869 = _6string_next_10248 - 1;
    if ((long)((unsigned long)_5869 +(unsigned long) HIGH_BITS) >= 0){
        _5869 = NewDouble((double)_5869);
    }
    if (IS_ATOM_INT(_5869)) {
        _5870 = _5869 - _offset_10522;
        if ((long)((unsigned long)_5870 +(unsigned long) HIGH_BITS) >= 0){
            _5870 = NewDouble((double)_5870);
        }
    }
    else {
        _5870 = NewDouble(DBL_PTR(_5869)->dbl - (double)_offset_10522);
    }
    DeRef(_5869);
    _5869 = NOVALUE;
    _5871 = (_6ch_10249 != -1);
    if (IS_ATOM_INT(_5870)) {
        _5872 = _5870 - _5871;
        if ((long)((unsigned long)_5872 +(unsigned long) HIGH_BITS) >= 0){
            _5872 = NewDouble((double)_5872);
        }
    }
    else {
        _5872 = NewDouble(DBL_PTR(_5870)->dbl - (double)_5871);
    }
    DeRef(_5870);
    _5870 = NOVALUE;
    _5871 = NOVALUE;
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _5872;
    ((int *)_2)[2] = _6leading_whitespace_10516;
    _5873 = MAKE_SEQ(_1);
    _5872 = NOVALUE;
    Concat((object_ptr)&_5874, _e_10520, _5873);
    DeRefDS(_5873);
    _5873 = NOVALUE;
    DeRef(_s_10519);
    DeRefDS(_e_10520);
    DeRef(_5862);
    _5862 = NOVALUE;
    return _5874;
L6: 

    /** 			get_ch()*/
    _6get_ch();

    /** 			if ch=-1 then*/
    if (_6ch_10249 != -1)
    goto L4; // [170] 94

    /** 				return {GET_NOTHING, 0, string_next-1-offset-(ch!=-1), leading_whitespace} -- empty sequence*/
    _5876 = _6string_next_10248 - 1;
    if ((long)((unsigned long)_5876 +(unsigned long) HIGH_BITS) >= 0){
        _5876 = NewDouble((double)_5876);
    }
    if (IS_ATOM_INT(_5876)) {
        _5877 = _5876 - _offset_10522;
        if ((long)((unsigned long)_5877 +(unsigned long) HIGH_BITS) >= 0){
            _5877 = NewDouble((double)_5877);
        }
    }
    else {
        _5877 = NewDouble(DBL_PTR(_5876)->dbl - (double)_offset_10522);
    }
    DeRef(_5876);
    _5876 = NOVALUE;
    _5878 = (_6ch_10249 != -1);
    if (IS_ATOM_INT(_5877)) {
        _5879 = _5877 - _5878;
        if ((long)((unsigned long)_5879 +(unsigned long) HIGH_BITS) >= 0){
            _5879 = NewDouble((double)_5879);
        }
    }
    else {
        _5879 = NewDouble(DBL_PTR(_5877)->dbl - (double)_5878);
    }
    DeRef(_5877);
    _5877 = NOVALUE;
    _5878 = NOVALUE;
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = -2;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = _5879;
    *((int *)(_2+16)) = _6leading_whitespace_10516;
    _5880 = MAKE_SEQ(_1);
    _5879 = NOVALUE;
    DeRef(_s_10519);
    DeRef(_e_10520);
    DeRef(_5862);
    _5862 = NOVALUE;
    DeRef(_5874);
    _5874 = NOVALUE;
    return _5880;
    goto L4; // [210] 94
L5: 

    /** 		elsif ch = '{' then*/
    if (_6ch_10249 != 123)
    goto L7; // [217] 676

    /** 			s = {}*/
    RefDS(_5);
    DeRef(_s_10519);
    _s_10519 = _5;

    /** 			get_ch()*/
    _6get_ch();

    /** 			skip_blanks()*/

    /** 	while find(ch, white_space) do*/
L8: 
    _skip_blanks_1__tmp_at233_10557 = find_from(_6ch_10249, _6white_space_10265, 1);
    if (_skip_blanks_1__tmp_at233_10557 == 0)
    {
        goto L9; // [246] 263
    }
    else{
    }

    /** 		get_ch()*/
    _6get_ch();

    /** 	end while*/
    goto L8; // [255] 239

    /** end procedure*/
    goto L9; // [260] 263
L9: 

    /** 			if ch = '}' then -- empty sequence*/
    if (_6ch_10249 != 125)
    goto LA; // [269] 313

    /** 				get_ch()*/
    _6get_ch();

    /** 				return {GET_SUCCESS, s, string_next-1-offset-(ch!=-1), leading_whitespace} -- empty sequence*/
    _5883 = _6string_next_10248 - 1;
    if ((long)((unsigned long)_5883 +(unsigned long) HIGH_BITS) >= 0){
        _5883 = NewDouble((double)_5883);
    }
    if (IS_ATOM_INT(_5883)) {
        _5884 = _5883 - _offset_10522;
        if ((long)((unsigned long)_5884 +(unsigned long) HIGH_BITS) >= 0){
            _5884 = NewDouble((double)_5884);
        }
    }
    else {
        _5884 = NewDouble(DBL_PTR(_5883)->dbl - (double)_offset_10522);
    }
    DeRef(_5883);
    _5883 = NOVALUE;
    _5885 = (_6ch_10249 != -1);
    if (IS_ATOM_INT(_5884)) {
        _5886 = _5884 - _5885;
        if ((long)((unsigned long)_5886 +(unsigned long) HIGH_BITS) >= 0){
            _5886 = NewDouble((double)_5886);
        }
    }
    else {
        _5886 = NewDouble(DBL_PTR(_5884)->dbl - (double)_5885);
    }
    DeRef(_5884);
    _5884 = NOVALUE;
    _5885 = NOVALUE;
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 0;
    RefDS(_s_10519);
    *((int *)(_2+8)) = _s_10519;
    *((int *)(_2+12)) = _5886;
    *((int *)(_2+16)) = _6leading_whitespace_10516;
    _5887 = MAKE_SEQ(_1);
    _5886 = NOVALUE;
    DeRefDS(_s_10519);
    DeRef(_e_10520);
    DeRef(_5862);
    _5862 = NOVALUE;
    DeRef(_5874);
    _5874 = NOVALUE;
    DeRef(_5880);
    _5880 = NOVALUE;
    return _5887;
LA: 

    /** 			while TRUE do -- read: comment(s), element, comment(s), comma and so on till it terminates or errors out*/
LB: 

    /** 				while 1 do -- read zero or more comments and an element*/
LC: 

    /** 					e = Get() -- read next element, using standard function*/
    _0 = _e_10520;
    _e_10520 = _6Get();
    DeRef(_0);

    /** 					e1 = e[1]*/
    _2 = (int)SEQ_PTR(_e_10520);
    _e1_10521 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_e1_10521))
    _e1_10521 = (long)DBL_PTR(_e1_10521)->dbl;

    /** 					if e1 = GET_SUCCESS then*/
    if (_e1_10521 != 0)
    goto LD; // [338] 359

    /** 						s = append(s, e[2])*/
    _2 = (int)SEQ_PTR(_e_10520);
    _5891 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_5891);
    Append(&_s_10519, _s_10519, _5891);
    _5891 = NOVALUE;

    /** 						exit  -- element read and added to result*/
    goto LE; // [354] 458
    goto LC; // [356] 323
LD: 

    /** 					elsif e1 != GET_IGNORE then*/
    if (_e1_10521 == -2)
    goto LF; // [361] 404

    /** 						return e & {string_next-1-offset-(ch!=-1), leading_whitespace}*/
    _5894 = _6string_next_10248 - 1;
    if ((long)((unsigned long)_5894 +(unsigned long) HIGH_BITS) >= 0){
        _5894 = NewDouble((double)_5894);
    }
    if (IS_ATOM_INT(_5894)) {
        _5895 = _5894 - _offset_10522;
        if ((long)((unsigned long)_5895 +(unsigned long) HIGH_BITS) >= 0){
            _5895 = NewDouble((double)_5895);
        }
    }
    else {
        _5895 = NewDouble(DBL_PTR(_5894)->dbl - (double)_offset_10522);
    }
    DeRef(_5894);
    _5894 = NOVALUE;
    _5896 = (_6ch_10249 != -1);
    if (IS_ATOM_INT(_5895)) {
        _5897 = _5895 - _5896;
        if ((long)((unsigned long)_5897 +(unsigned long) HIGH_BITS) >= 0){
            _5897 = NewDouble((double)_5897);
        }
    }
    else {
        _5897 = NewDouble(DBL_PTR(_5895)->dbl - (double)_5896);
    }
    DeRef(_5895);
    _5895 = NOVALUE;
    _5896 = NOVALUE;
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _5897;
    ((int *)_2)[2] = _6leading_whitespace_10516;
    _5898 = MAKE_SEQ(_1);
    _5897 = NOVALUE;
    Concat((object_ptr)&_5899, _e_10520, _5898);
    DeRefDS(_5898);
    _5898 = NOVALUE;
    DeRef(_s_10519);
    DeRefDS(_e_10520);
    DeRef(_5862);
    _5862 = NOVALUE;
    DeRef(_5874);
    _5874 = NOVALUE;
    DeRef(_5880);
    _5880 = NOVALUE;
    DeRef(_5887);
    _5887 = NOVALUE;
    return _5899;
    goto LC; // [401] 323
LF: 

    /** 					elsif ch='}' then*/
    if (_6ch_10249 != 125)
    goto LC; // [408] 323

    /** 						get_ch()*/
    _6get_ch();

    /** 						return {GET_SUCCESS, s, string_next-1-offset-(ch!=-1),leading_whitespace} -- empty sequence*/
    _5901 = _6string_next_10248 - 1;
    if ((long)((unsigned long)_5901 +(unsigned long) HIGH_BITS) >= 0){
        _5901 = NewDouble((double)_5901);
    }
    if (IS_ATOM_INT(_5901)) {
        _5902 = _5901 - _offset_10522;
        if ((long)((unsigned long)_5902 +(unsigned long) HIGH_BITS) >= 0){
            _5902 = NewDouble((double)_5902);
        }
    }
    else {
        _5902 = NewDouble(DBL_PTR(_5901)->dbl - (double)_offset_10522);
    }
    DeRef(_5901);
    _5901 = NOVALUE;
    _5903 = (_6ch_10249 != -1);
    if (IS_ATOM_INT(_5902)) {
        _5904 = _5902 - _5903;
        if ((long)((unsigned long)_5904 +(unsigned long) HIGH_BITS) >= 0){
            _5904 = NewDouble((double)_5904);
        }
    }
    else {
        _5904 = NewDouble(DBL_PTR(_5902)->dbl - (double)_5903);
    }
    DeRef(_5902);
    _5902 = NOVALUE;
    _5903 = NOVALUE;
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 0;
    RefDS(_s_10519);
    *((int *)(_2+8)) = _s_10519;
    *((int *)(_2+12)) = _5904;
    *((int *)(_2+16)) = _6leading_whitespace_10516;
    _5905 = MAKE_SEQ(_1);
    _5904 = NOVALUE;
    DeRefDS(_s_10519);
    DeRef(_e_10520);
    DeRef(_5862);
    _5862 = NOVALUE;
    DeRef(_5874);
    _5874 = NOVALUE;
    DeRef(_5880);
    _5880 = NOVALUE;
    DeRef(_5887);
    _5887 = NOVALUE;
    DeRef(_5899);
    _5899 = NOVALUE;
    return _5905;

    /** 				end while*/
    goto LC; // [455] 323
LE: 

    /** 				while 1 do -- now read zero or more post element comments*/
L10: 

    /** 					skip_blanks()*/

    /** 	while find(ch, white_space) do*/
L11: 
    _skip_blanks_1__tmp_at464_10590 = find_from(_6ch_10249, _6white_space_10265, 1);
    if (_skip_blanks_1__tmp_at464_10590 == 0)
    {
        goto L12; // [477] 494
    }
    else{
    }

    /** 		get_ch()*/
    _6get_ch();

    /** 	end while*/
    goto L11; // [486] 470

    /** end procedure*/
    goto L12; // [491] 494
L12: 

    /** 					if ch = '}' then*/
    if (_6ch_10249 != 125)
    goto L13; // [500] 546

    /** 						get_ch()*/
    _6get_ch();

    /** 					return {GET_SUCCESS, s, string_next-1-offset-(ch!=-1), leading_whitespace}*/
    _5907 = _6string_next_10248 - 1;
    if ((long)((unsigned long)_5907 +(unsigned long) HIGH_BITS) >= 0){
        _5907 = NewDouble((double)_5907);
    }
    if (IS_ATOM_INT(_5907)) {
        _5908 = _5907 - _offset_10522;
        if ((long)((unsigned long)_5908 +(unsigned long) HIGH_BITS) >= 0){
            _5908 = NewDouble((double)_5908);
        }
    }
    else {
        _5908 = NewDouble(DBL_PTR(_5907)->dbl - (double)_offset_10522);
    }
    DeRef(_5907);
    _5907 = NOVALUE;
    _5909 = (_6ch_10249 != -1);
    if (IS_ATOM_INT(_5908)) {
        _5910 = _5908 - _5909;
        if ((long)((unsigned long)_5910 +(unsigned long) HIGH_BITS) >= 0){
            _5910 = NewDouble((double)_5910);
        }
    }
    else {
        _5910 = NewDouble(DBL_PTR(_5908)->dbl - (double)_5909);
    }
    DeRef(_5908);
    _5908 = NOVALUE;
    _5909 = NOVALUE;
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 0;
    RefDS(_s_10519);
    *((int *)(_2+8)) = _s_10519;
    *((int *)(_2+12)) = _5910;
    *((int *)(_2+16)) = _6leading_whitespace_10516;
    _5911 = MAKE_SEQ(_1);
    _5910 = NOVALUE;
    DeRefDS(_s_10519);
    DeRef(_e_10520);
    DeRef(_5862);
    _5862 = NOVALUE;
    DeRef(_5874);
    _5874 = NOVALUE;
    DeRef(_5880);
    _5880 = NOVALUE;
    DeRef(_5887);
    _5887 = NOVALUE;
    DeRef(_5899);
    _5899 = NOVALUE;
    DeRef(_5905);
    _5905 = NOVALUE;
    return _5911;
    goto L10; // [543] 463
L13: 

    /** 					elsif ch!='-' then*/
    if (_6ch_10249 == 45)
    goto L14; // [550] 561

    /** 						exit*/
    goto L15; // [556] 620
    goto L10; // [558] 463
L14: 

    /** 						e = get_number() -- reads anything starting with '-'*/
    _0 = _e_10520;
    _e_10520 = _6get_number();
    DeRef(_0);

    /** 						if e[1] != GET_IGNORE then  -- it was not a comment, this is illegal*/
    _2 = (int)SEQ_PTR(_e_10520);
    _5914 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _5914, -2)){
        _5914 = NOVALUE;
        goto L10; // [574] 463
    }
    _5914 = NOVALUE;

    /** 							return {GET_FAIL, 0, string_next-1-offset-(ch!=-1),leading_whitespace}*/
    _5916 = _6string_next_10248 - 1;
    if ((long)((unsigned long)_5916 +(unsigned long) HIGH_BITS) >= 0){
        _5916 = NewDouble((double)_5916);
    }
    if (IS_ATOM_INT(_5916)) {
        _5917 = _5916 - _offset_10522;
        if ((long)((unsigned long)_5917 +(unsigned long) HIGH_BITS) >= 0){
            _5917 = NewDouble((double)_5917);
        }
    }
    else {
        _5917 = NewDouble(DBL_PTR(_5916)->dbl - (double)_offset_10522);
    }
    DeRef(_5916);
    _5916 = NOVALUE;
    _5918 = (_6ch_10249 != -1);
    if (IS_ATOM_INT(_5917)) {
        _5919 = _5917 - _5918;
        if ((long)((unsigned long)_5919 +(unsigned long) HIGH_BITS) >= 0){
            _5919 = NewDouble((double)_5919);
        }
    }
    else {
        _5919 = NewDouble(DBL_PTR(_5917)->dbl - (double)_5918);
    }
    DeRef(_5917);
    _5917 = NOVALUE;
    _5918 = NOVALUE;
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = _5919;
    *((int *)(_2+16)) = _6leading_whitespace_10516;
    _5920 = MAKE_SEQ(_1);
    _5919 = NOVALUE;
    DeRef(_s_10519);
    DeRefDS(_e_10520);
    DeRef(_5862);
    _5862 = NOVALUE;
    DeRef(_5874);
    _5874 = NOVALUE;
    DeRef(_5880);
    _5880 = NOVALUE;
    DeRef(_5887);
    _5887 = NOVALUE;
    DeRef(_5899);
    _5899 = NOVALUE;
    DeRef(_5905);
    _5905 = NOVALUE;
    DeRef(_5911);
    _5911 = NOVALUE;
    return _5920;

    /** 			end while*/
    goto L10; // [617] 463
L15: 

    /** 				if ch != ',' then*/
    if (_6ch_10249 == 44)
    goto L16; // [624] 664

    /** 				return {GET_FAIL, 0, string_next-1-offset-(ch!=-1), leading_whitespace}*/
    _5922 = _6string_next_10248 - 1;
    if ((long)((unsigned long)_5922 +(unsigned long) HIGH_BITS) >= 0){
        _5922 = NewDouble((double)_5922);
    }
    if (IS_ATOM_INT(_5922)) {
        _5923 = _5922 - _offset_10522;
        if ((long)((unsigned long)_5923 +(unsigned long) HIGH_BITS) >= 0){
            _5923 = NewDouble((double)_5923);
        }
    }
    else {
        _5923 = NewDouble(DBL_PTR(_5922)->dbl - (double)_offset_10522);
    }
    DeRef(_5922);
    _5922 = NOVALUE;
    _5924 = (_6ch_10249 != -1);
    if (IS_ATOM_INT(_5923)) {
        _5925 = _5923 - _5924;
        if ((long)((unsigned long)_5925 +(unsigned long) HIGH_BITS) >= 0){
            _5925 = NewDouble((double)_5925);
        }
    }
    else {
        _5925 = NewDouble(DBL_PTR(_5923)->dbl - (double)_5924);
    }
    DeRef(_5923);
    _5923 = NOVALUE;
    _5924 = NOVALUE;
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = _5925;
    *((int *)(_2+16)) = _6leading_whitespace_10516;
    _5926 = MAKE_SEQ(_1);
    _5925 = NOVALUE;
    DeRef(_s_10519);
    DeRef(_e_10520);
    DeRef(_5862);
    _5862 = NOVALUE;
    DeRef(_5874);
    _5874 = NOVALUE;
    DeRef(_5880);
    _5880 = NOVALUE;
    DeRef(_5887);
    _5887 = NOVALUE;
    DeRef(_5899);
    _5899 = NOVALUE;
    DeRef(_5905);
    _5905 = NOVALUE;
    DeRef(_5911);
    _5911 = NOVALUE;
    DeRef(_5920);
    _5920 = NOVALUE;
    return _5926;
L16: 

    /** 			get_ch() -- skip comma*/
    _6get_ch();

    /** 			end while*/
    goto LB; // [670] 318
    goto L4; // [673] 94
L7: 

    /** 		elsif ch = '\"' then*/
    if (_6ch_10249 != 34)
    goto L17; // [680] 730

    /** 			e = get_string()*/
    _0 = _e_10520;
    _e_10520 = _6get_string();
    DeRef(_0);

    /** 			return e & {string_next-1-offset-(ch!=-1), leading_whitespace}*/
    _5929 = _6string_next_10248 - 1;
    if ((long)((unsigned long)_5929 +(unsigned long) HIGH_BITS) >= 0){
        _5929 = NewDouble((double)_5929);
    }
    if (IS_ATOM_INT(_5929)) {
        _5930 = _5929 - _offset_10522;
        if ((long)((unsigned long)_5930 +(unsigned long) HIGH_BITS) >= 0){
            _5930 = NewDouble((double)_5930);
        }
    }
    else {
        _5930 = NewDouble(DBL_PTR(_5929)->dbl - (double)_offset_10522);
    }
    DeRef(_5929);
    _5929 = NOVALUE;
    _5931 = (_6ch_10249 != -1);
    if (IS_ATOM_INT(_5930)) {
        _5932 = _5930 - _5931;
        if ((long)((unsigned long)_5932 +(unsigned long) HIGH_BITS) >= 0){
            _5932 = NewDouble((double)_5932);
        }
    }
    else {
        _5932 = NewDouble(DBL_PTR(_5930)->dbl - (double)_5931);
    }
    DeRef(_5930);
    _5930 = NOVALUE;
    _5931 = NOVALUE;
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _5932;
    ((int *)_2)[2] = _6leading_whitespace_10516;
    _5933 = MAKE_SEQ(_1);
    _5932 = NOVALUE;
    Concat((object_ptr)&_5934, _e_10520, _5933);
    DeRefDS(_5933);
    _5933 = NOVALUE;
    DeRef(_s_10519);
    DeRefDS(_e_10520);
    DeRef(_5862);
    _5862 = NOVALUE;
    DeRef(_5874);
    _5874 = NOVALUE;
    DeRef(_5880);
    _5880 = NOVALUE;
    DeRef(_5887);
    _5887 = NOVALUE;
    DeRef(_5899);
    _5899 = NOVALUE;
    DeRef(_5905);
    _5905 = NOVALUE;
    DeRef(_5911);
    _5911 = NOVALUE;
    DeRef(_5920);
    _5920 = NOVALUE;
    DeRef(_5926);
    _5926 = NOVALUE;
    return _5934;
    goto L4; // [727] 94
L17: 

    /** 		elsif ch = '\'' then*/
    if (_6ch_10249 != 39)
    goto L18; // [734] 784

    /** 			e = get_qchar()*/
    _0 = _e_10520;
    _e_10520 = _6get_qchar();
    DeRef(_0);

    /** 			return e & {string_next-1-offset-(ch!=-1), leading_whitespace}*/
    _5937 = _6string_next_10248 - 1;
    if ((long)((unsigned long)_5937 +(unsigned long) HIGH_BITS) >= 0){
        _5937 = NewDouble((double)_5937);
    }
    if (IS_ATOM_INT(_5937)) {
        _5938 = _5937 - _offset_10522;
        if ((long)((unsigned long)_5938 +(unsigned long) HIGH_BITS) >= 0){
            _5938 = NewDouble((double)_5938);
        }
    }
    else {
        _5938 = NewDouble(DBL_PTR(_5937)->dbl - (double)_offset_10522);
    }
    DeRef(_5937);
    _5937 = NOVALUE;
    _5939 = (_6ch_10249 != -1);
    if (IS_ATOM_INT(_5938)) {
        _5940 = _5938 - _5939;
        if ((long)((unsigned long)_5940 +(unsigned long) HIGH_BITS) >= 0){
            _5940 = NewDouble((double)_5940);
        }
    }
    else {
        _5940 = NewDouble(DBL_PTR(_5938)->dbl - (double)_5939);
    }
    DeRef(_5938);
    _5938 = NOVALUE;
    _5939 = NOVALUE;
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _5940;
    ((int *)_2)[2] = _6leading_whitespace_10516;
    _5941 = MAKE_SEQ(_1);
    _5940 = NOVALUE;
    Concat((object_ptr)&_5942, _e_10520, _5941);
    DeRefDS(_5941);
    _5941 = NOVALUE;
    DeRef(_s_10519);
    DeRefDS(_e_10520);
    DeRef(_5862);
    _5862 = NOVALUE;
    DeRef(_5874);
    _5874 = NOVALUE;
    DeRef(_5880);
    _5880 = NOVALUE;
    DeRef(_5887);
    _5887 = NOVALUE;
    DeRef(_5899);
    _5899 = NOVALUE;
    DeRef(_5905);
    _5905 = NOVALUE;
    DeRef(_5911);
    _5911 = NOVALUE;
    DeRef(_5920);
    _5920 = NOVALUE;
    DeRef(_5926);
    _5926 = NOVALUE;
    DeRef(_5934);
    _5934 = NOVALUE;
    return _5942;
    goto L4; // [781] 94
L18: 

    /** 			return {GET_FAIL, 0, string_next-1-offset-(ch!=-1), leading_whitespace}*/
    _5943 = _6string_next_10248 - 1;
    if ((long)((unsigned long)_5943 +(unsigned long) HIGH_BITS) >= 0){
        _5943 = NewDouble((double)_5943);
    }
    if (IS_ATOM_INT(_5943)) {
        _5944 = _5943 - _offset_10522;
        if ((long)((unsigned long)_5944 +(unsigned long) HIGH_BITS) >= 0){
            _5944 = NewDouble((double)_5944);
        }
    }
    else {
        _5944 = NewDouble(DBL_PTR(_5943)->dbl - (double)_offset_10522);
    }
    DeRef(_5943);
    _5943 = NOVALUE;
    _5945 = (_6ch_10249 != -1);
    if (IS_ATOM_INT(_5944)) {
        _5946 = _5944 - _5945;
        if ((long)((unsigned long)_5946 +(unsigned long) HIGH_BITS) >= 0){
            _5946 = NewDouble((double)_5946);
        }
    }
    else {
        _5946 = NewDouble(DBL_PTR(_5944)->dbl - (double)_5945);
    }
    DeRef(_5944);
    _5944 = NOVALUE;
    _5945 = NOVALUE;
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = _5946;
    *((int *)(_2+16)) = _6leading_whitespace_10516;
    _5947 = MAKE_SEQ(_1);
    _5946 = NOVALUE;
    DeRef(_s_10519);
    DeRef(_e_10520);
    DeRef(_5862);
    _5862 = NOVALUE;
    DeRef(_5874);
    _5874 = NOVALUE;
    DeRef(_5880);
    _5880 = NOVALUE;
    DeRef(_5887);
    _5887 = NOVALUE;
    DeRef(_5899);
    _5899 = NOVALUE;
    DeRef(_5905);
    _5905 = NOVALUE;
    DeRef(_5911);
    _5911 = NOVALUE;
    DeRef(_5920);
    _5920 = NOVALUE;
    DeRef(_5926);
    _5926 = NOVALUE;
    DeRef(_5934);
    _5934 = NOVALUE;
    DeRef(_5942);
    _5942 = NOVALUE;
    return _5947;

    /** 	end while*/
    goto L4; // [822] 94
    ;
}


int _6get_value(int _target_10649, int _start_point_10650, int _answer_type_10651)
{
    int _msg_inlined_crash_at_35_10662 = NOVALUE;
    int _data_inlined_crash_at_32_10661 = NOVALUE;
    int _where_inlined_where_at_76_10668 = NOVALUE;
    int _seek_1__tmp_at90_10673 = NOVALUE;
    int _seek_inlined_seek_at_90_10672 = NOVALUE;
    int _pos_inlined_seek_at_87_10671 = NOVALUE;
    int _msg_inlined_crash_at_108_10676 = NOVALUE;
    int _5963 = NOVALUE;
    int _5960 = NOVALUE;
    int _5959 = NOVALUE;
    int _5958 = NOVALUE;
    int _5954 = NOVALUE;
    int _5953 = NOVALUE;
    int _5952 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if answer_type != GET_SHORT_ANSWER and answer_type != GET_LONG_ANSWER then*/
    _5952 = (_answer_type_10651 != _6GET_SHORT_ANSWER_10641);
    if (_5952 == 0) {
        goto L1; // [13] 55
    }
    _5954 = (_answer_type_10651 != _6GET_LONG_ANSWER_10644);
    if (_5954 == 0)
    {
        DeRef(_5954);
        _5954 = NOVALUE;
        goto L1; // [24] 55
    }
    else{
        DeRef(_5954);
        _5954 = NOVALUE;
    }

    /** 		error:crash("Invalid type of answer, please only use %s (the default) or %s.", {"GET_SHORT_ANSWER", "GET_LONG_ANSWER"})*/
    RefDS(_5957);
    RefDS(_5956);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _5956;
    ((int *)_2)[2] = _5957;
    _5958 = MAKE_SEQ(_1);
    DeRef(_data_inlined_crash_at_32_10661);
    _data_inlined_crash_at_32_10661 = _5958;
    _5958 = NOVALUE;

    /** 	msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_35_10662);
    _msg_inlined_crash_at_35_10662 = EPrintf(-9999999, _5955, _data_inlined_crash_at_32_10661);

    /** 	machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_35_10662);

    /** end procedure*/
    goto L2; // [49] 52
L2: 
    DeRef(_data_inlined_crash_at_32_10661);
    _data_inlined_crash_at_32_10661 = NOVALUE;
    DeRefi(_msg_inlined_crash_at_35_10662);
    _msg_inlined_crash_at_35_10662 = NOVALUE;
L1: 

    /** 	if atom(target) then -- get()*/
    _5959 = IS_ATOM(_target_10649);
    if (_5959 == 0)
    {
        _5959 = NOVALUE;
        goto L3; // [60] 142
    }
    else{
        _5959 = NOVALUE;
    }

    /** 		input_file = target*/
    Ref(_target_10649);
    _6input_file_10246 = _target_10649;
    if (!IS_ATOM_INT(_6input_file_10246)) {
        _1 = (long)(DBL_PTR(_6input_file_10246)->dbl);
        DeRefDS(_6input_file_10246);
        _6input_file_10246 = _1;
    }

    /** 		if start_point then*/
    if (_start_point_10650 == 0)
    {
        goto L4; // [72] 129
    }
    else{
    }

    /** 			if io:seek(target, io:where(target)+start_point) then*/

    /** 	return machine_func(M_WHERE, fn)*/
    DeRef(_where_inlined_where_at_76_10668);
    _where_inlined_where_at_76_10668 = machine(20, _target_10649);
    if (IS_ATOM_INT(_where_inlined_where_at_76_10668)) {
        _5960 = _where_inlined_where_at_76_10668 + _start_point_10650;
        if ((long)((unsigned long)_5960 + (unsigned long)HIGH_BITS) >= 0) 
        _5960 = NewDouble((double)_5960);
    }
    else {
        _5960 = NewDouble(DBL_PTR(_where_inlined_where_at_76_10668)->dbl + (double)_start_point_10650);
    }
    DeRef(_pos_inlined_seek_at_87_10671);
    _pos_inlined_seek_at_87_10671 = _5960;
    _5960 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_87_10671);
    Ref(_target_10649);
    DeRef(_seek_1__tmp_at90_10673);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _target_10649;
    ((int *)_2)[2] = _pos_inlined_seek_at_87_10671;
    _seek_1__tmp_at90_10673 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_90_10672 = machine(19, _seek_1__tmp_at90_10673);
    DeRef(_pos_inlined_seek_at_87_10671);
    _pos_inlined_seek_at_87_10671 = NOVALUE;
    DeRef(_seek_1__tmp_at90_10673);
    _seek_1__tmp_at90_10673 = NOVALUE;
    if (_seek_inlined_seek_at_90_10672 == 0)
    {
        goto L5; // [104] 128
    }
    else{
    }

    /** 				error:crash("Initial seek() for get() failed!")*/

    /** 	msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_108_10676);
    _msg_inlined_crash_at_108_10676 = EPrintf(-9999999, _5961, _5);

    /** 	machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_108_10676);

    /** end procedure*/
    goto L6; // [122] 125
L6: 
    DeRefi(_msg_inlined_crash_at_108_10676);
    _msg_inlined_crash_at_108_10676 = NOVALUE;
L5: 
L4: 

    /** 		string_next = 1*/
    _6string_next_10248 = 1;

    /** 		input_string = 0*/
    DeRef(_6input_string_10247);
    _6input_string_10247 = 0;
    goto L7; // [139] 153
L3: 

    /** 		input_string = target*/
    Ref(_target_10649);
    DeRef(_6input_string_10247);
    _6input_string_10247 = _target_10649;

    /** 		string_next = start_point*/
    _6string_next_10248 = _start_point_10650;
L7: 

    /** 	if answer_type = GET_SHORT_ANSWER then*/
    if (_answer_type_10651 != _6GET_SHORT_ANSWER_10641)
    goto L8; // [157] 166

    /** 		get_ch()*/
    _6get_ch();
L8: 

    /** 	return call_func(answer_type, {})*/
    _0 = (int)_00[_answer_type_10651].addr;
    _1 = (*(int (*)())_0)(
                         );
    DeRef(_5963);
    _5963 = _1;
    DeRef(_target_10649);
    DeRef(_5952);
    _5952 = NOVALUE;
    return _5963;
    ;
}


int _6value(int _st_10689, int _start_point_10690, int _answer_10691)
{
    int _5965 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return get_value(st, start_point, answer)*/
    RefDS(_st_10689);
    _5965 = _6get_value(_st_10689, 1, _answer_10691);
    DeRefDS(_st_10689);
    return _5965;
    ;
}



// 0xB1DDDE2E
