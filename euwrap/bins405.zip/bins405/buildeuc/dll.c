// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int _12open_dll(int _file_name_918)
{
    int _fh_928 = NOVALUE;
    int _353 = NOVALUE;
    int _351 = NOVALUE;
    int _350 = NOVALUE;
    int _349 = NOVALUE;
    int _348 = NOVALUE;
    int _347 = NOVALUE;
    int _346 = NOVALUE;
    int _345 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if length(file_name) > 0 and types:string(file_name) then*/
    if (IS_SEQUENCE(_file_name_918)){
            _345 = SEQ_PTR(_file_name_918)->length;
    }
    else {
        _345 = 1;
    }
    _346 = (_345 > 0);
    _345 = NOVALUE;
    if (_346 == 0) {
        goto L1; // [12] 35
    }
    RefDS(_file_name_918);
    _348 = _13string(_file_name_918);
    if (_348 == 0) {
        DeRef(_348);
        _348 = NOVALUE;
        goto L1; // [21] 35
    }
    else {
        if (!IS_ATOM_INT(_348) && DBL_PTR(_348)->dbl == 0.0){
            DeRef(_348);
            _348 = NOVALUE;
            goto L1; // [21] 35
        }
        DeRef(_348);
        _348 = NOVALUE;
    }
    DeRef(_348);
    _348 = NOVALUE;

    /** 		return machine_func(M_OPEN_DLL, file_name)*/
    _349 = machine(50, _file_name_918);
    DeRefDS(_file_name_918);
    DeRef(_346);
    _346 = NOVALUE;
    return _349;
L1: 

    /** 	for idx = 1 to length(file_name) do*/
    if (IS_SEQUENCE(_file_name_918)){
            _350 = SEQ_PTR(_file_name_918)->length;
    }
    else {
        _350 = 1;
    }
    {
        int _idx_926;
        _idx_926 = 1;
L2: 
        if (_idx_926 > _350){
            goto L3; // [40] 82
        }

        /** 		atom fh = machine_func(M_OPEN_DLL, file_name[idx])*/
        _2 = (int)SEQ_PTR(_file_name_918);
        _351 = (int)*(((s1_ptr)_2)->base + _idx_926);
        DeRef(_fh_928);
        _fh_928 = machine(50, _351);
        _351 = NOVALUE;

        /** 		if not fh = 0 then*/
        if (IS_ATOM_INT(_fh_928)) {
            _353 = (_fh_928 == 0);
        }
        else {
            _353 = unary_op(NOT, _fh_928);
        }
        if (_353 != 0)
        goto L4; // [62] 73

        /** 			return fh*/
        DeRefDS(_file_name_918);
        DeRef(_346);
        _346 = NOVALUE;
        DeRef(_349);
        _349 = NOVALUE;
        _353 = NOVALUE;
        return _fh_928;
L4: 
        DeRef(_fh_928);
        _fh_928 = NOVALUE;

        /** 	end for*/
        _idx_926 = _idx_926 + 1;
        goto L2; // [77] 47
L3: 
        ;
    }

    /** 	return 0*/
    DeRefDS(_file_name_918);
    DeRef(_346);
    _346 = NOVALUE;
    DeRef(_349);
    _349 = NOVALUE;
    DeRef(_353);
    _353 = NOVALUE;
    return 0;
    ;
}


int _12define_c_proc(int _lib_942, int _routine_name_943, int _arg_types_944)
{
    int _safe_address_inlined_safe_address_at_11_949 = NOVALUE;
    int _msg_inlined_crash_at_26_953 = NOVALUE;
    int _362 = NOVALUE;
    int _361 = NOVALUE;
    int _359 = NOVALUE;
    int _358 = NOVALUE;
    int _357 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(routine_name) and not machine:safe_address(routine_name, 1, machine:A_EXECUTE) then*/
    _357 = 0;
    if (_357 == 0) {
        goto L1; // [8] 46
    }

    /** 	return 1*/
    _safe_address_inlined_safe_address_at_11_949 = 1;
    _359 = (1 == 0);
    if (_359 == 0)
    {
        DeRef(_359);
        _359 = NOVALUE;
        goto L1; // [22] 46
    }
    else{
        DeRef(_359);
        _359 = NOVALUE;
    }

    /**         error:crash("A C function is being defined from Non-executable memory.")*/

    /** 	msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_26_953);
    _msg_inlined_crash_at_26_953 = EPrintf(-9999999, _360, _5);

    /** 	machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_26_953);

    /** end procedure*/
    goto L2; // [40] 43
L2: 
    DeRefi(_msg_inlined_crash_at_26_953);
    _msg_inlined_crash_at_26_953 = NOVALUE;
L1: 

    /** 	return machine_func(M_DEFINE_C, {lib, routine_name, arg_types, 0})*/
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_lib_942);
    *((int *)(_2+4)) = _lib_942;
    Ref(_routine_name_943);
    *((int *)(_2+8)) = _routine_name_943;
    RefDS(_arg_types_944);
    *((int *)(_2+12)) = _arg_types_944;
    *((int *)(_2+16)) = 0;
    _361 = MAKE_SEQ(_1);
    _362 = machine(51, _361);
    DeRefDS(_361);
    _361 = NOVALUE;
    DeRef(_lib_942);
    DeRefi(_routine_name_943);
    DeRefDSi(_arg_types_944);
    return _362;
    ;
}


int _12define_c_func(int _lib_958, int _routine_name_959, int _arg_types_960, int _return_type_961)
{
    int _safe_address_inlined_safe_address_at_11_966 = NOVALUE;
    int _msg_inlined_crash_at_26_969 = NOVALUE;
    int _367 = NOVALUE;
    int _366 = NOVALUE;
    int _365 = NOVALUE;
    int _364 = NOVALUE;
    int _363 = NOVALUE;
    int _0, _1, _2;
    

    /** 	  if atom(routine_name) and not machine:safe_address(routine_name, 1, machine:A_EXECUTE) then*/
    _363 = 0;
    if (_363 == 0) {
        goto L1; // [8] 46
    }

    /** 	return 1*/
    _safe_address_inlined_safe_address_at_11_966 = 1;
    _365 = (1 == 0);
    if (_365 == 0)
    {
        DeRef(_365);
        _365 = NOVALUE;
        goto L1; // [22] 46
    }
    else{
        DeRef(_365);
        _365 = NOVALUE;
    }

    /** 	      error:crash("A C function is being defined from Non-executable memory.")*/

    /** 	msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_26_969);
    _msg_inlined_crash_at_26_969 = EPrintf(-9999999, _360, _5);

    /** 	machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_26_969);

    /** end procedure*/
    goto L2; // [40] 43
L2: 
    DeRefi(_msg_inlined_crash_at_26_969);
    _msg_inlined_crash_at_26_969 = NOVALUE;
L1: 

    /** 	  return machine_func(M_DEFINE_C, {lib, routine_name, arg_types, return_type})*/
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_lib_958);
    *((int *)(_2+4)) = _lib_958;
    Ref(_routine_name_959);
    *((int *)(_2+8)) = _routine_name_959;
    RefDS(_arg_types_960);
    *((int *)(_2+12)) = _arg_types_960;
    *((int *)(_2+16)) = _return_type_961;
    _366 = MAKE_SEQ(_1);
    _367 = machine(51, _366);
    DeRefDS(_366);
    _366 = NOVALUE;
    DeRef(_lib_958);
    DeRefi(_routine_name_959);
    DeRefDSi(_arg_types_960);
    return _367;
    ;
}



// 0xDB9EA851
