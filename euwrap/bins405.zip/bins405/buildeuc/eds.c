// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

void _49fatal(int _errcode_17399, int _msg_17400, int _routine_name_17401, int _parms_17402)
{
    int _9886 = NOVALUE;
    int _0, _1, _2;
    

    /** 	vLastErrors = append(vLastErrors, {errcode, msg, routine_name, parms})*/
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _errcode_17399;
    RefDS(_msg_17400);
    *((int *)(_2+8)) = _msg_17400;
    RefDS(_routine_name_17401);
    *((int *)(_2+12)) = _routine_name_17401;
    RefDS(_parms_17402);
    *((int *)(_2+16)) = _parms_17402;
    _9886 = MAKE_SEQ(_1);
    RefDS(_9886);
    Append(&_49vLastErrors_17396, _49vLastErrors_17396, _9886);
    DeRefDS(_9886);
    _9886 = NOVALUE;

    /** 	if db_fatal_id >= 0 then*/

    /** end procedure*/
    DeRefDSi(_msg_17400);
    DeRefDSi(_routine_name_17401);
    DeRefDS(_parms_17402);
    return;
    ;
}


int _49get4()
{
    int _9902 = NOVALUE;
    int _9901 = NOVALUE;
    int _9900 = NOVALUE;
    int _9899 = NOVALUE;
    int _9898 = NOVALUE;
    int _0, _1, _2;
    

    /** 	poke(mem0, getc(current_db))*/
    if (_49current_db_17372 != last_r_file_no) {
        last_r_file_ptr = which_file(_49current_db_17372, EF_READ);
        last_r_file_no = _49current_db_17372;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _9898 = getKBchar();
        }
        else
        _9898 = getc(last_r_file_ptr);
    }
    else
    _9898 = getc(last_r_file_ptr);
    if (IS_ATOM_INT(_49mem0_17414)){
        poke_addr = (unsigned char *)_49mem0_17414;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_49mem0_17414)->dbl);
    }
    *poke_addr = (unsigned char)_9898;
    _9898 = NOVALUE;

    /** 	poke(mem1, getc(current_db))*/
    if (_49current_db_17372 != last_r_file_no) {
        last_r_file_ptr = which_file(_49current_db_17372, EF_READ);
        last_r_file_no = _49current_db_17372;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _9899 = getKBchar();
        }
        else
        _9899 = getc(last_r_file_ptr);
    }
    else
    _9899 = getc(last_r_file_ptr);
    if (IS_ATOM_INT(_49mem1_17415)){
        poke_addr = (unsigned char *)_49mem1_17415;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_49mem1_17415)->dbl);
    }
    *poke_addr = (unsigned char)_9899;
    _9899 = NOVALUE;

    /** 	poke(mem2, getc(current_db))*/
    if (_49current_db_17372 != last_r_file_no) {
        last_r_file_ptr = which_file(_49current_db_17372, EF_READ);
        last_r_file_no = _49current_db_17372;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _9900 = getKBchar();
        }
        else
        _9900 = getc(last_r_file_ptr);
    }
    else
    _9900 = getc(last_r_file_ptr);
    if (IS_ATOM_INT(_49mem2_17416)){
        poke_addr = (unsigned char *)_49mem2_17416;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_49mem2_17416)->dbl);
    }
    *poke_addr = (unsigned char)_9900;
    _9900 = NOVALUE;

    /** 	poke(mem3, getc(current_db))*/
    if (_49current_db_17372 != last_r_file_no) {
        last_r_file_ptr = which_file(_49current_db_17372, EF_READ);
        last_r_file_no = _49current_db_17372;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _9901 = getKBchar();
        }
        else
        _9901 = getc(last_r_file_ptr);
    }
    else
    _9901 = getc(last_r_file_ptr);
    if (IS_ATOM_INT(_49mem3_17417)){
        poke_addr = (unsigned char *)_49mem3_17417;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_49mem3_17417)->dbl);
    }
    *poke_addr = (unsigned char)_9901;
    _9901 = NOVALUE;

    /** 	return peek4u(mem0)*/
    if (IS_ATOM_INT(_49mem0_17414)) {
        _9902 = *(unsigned long *)_49mem0_17414;
        if ((unsigned)_9902 > (unsigned)MAXINT)
        _9902 = NewDouble((double)(unsigned long)_9902);
    }
    else {
        _9902 = *(unsigned long *)(unsigned long)(DBL_PTR(_49mem0_17414)->dbl);
        if ((unsigned)_9902 > (unsigned)MAXINT)
        _9902 = NewDouble((double)(unsigned long)_9902);
    }
    return _9902;
    ;
}


int _49get_string()
{
    int _where_inlined_where_at_31_17442 = NOVALUE;
    int _s_17431 = NOVALUE;
    int _c_17432 = NOVALUE;
    int _i_17433 = NOVALUE;
    int _9915 = NOVALUE;
    int _9912 = NOVALUE;
    int _9910 = NOVALUE;
    int _9908 = NOVALUE;
    int _0, _1, _2;
    

    /** 	s = repeat(0, 256)*/
    DeRefi(_s_17431);
    _s_17431 = Repeat(0, 256);

    /** 	i = 0*/
    _i_17433 = 0;

    /** 	while c with entry do*/
    goto L1; // [14] 89
L2: 
    if (_c_17432 == 0)
    {
        goto L3; // [19] 101
    }
    else{
    }

    /** 		if c = -1 then*/
    if (_c_17432 != -1)
    goto L4; // [24] 54

    /** 			fatal(MISSING_END, "string is missing 0 terminator", "get_string", {io:where(current_db)})*/

    /** 	return machine_func(M_WHERE, fn)*/
    DeRef(_where_inlined_where_at_31_17442);
    _where_inlined_where_at_31_17442 = machine(20, _49current_db_17372);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_where_inlined_where_at_31_17442);
    *((int *)(_2+4)) = _where_inlined_where_at_31_17442;
    _9908 = MAKE_SEQ(_1);
    RefDS(_9906);
    RefDS(_9907);
    _49fatal(900, _9906, _9907, _9908);
    _9908 = NOVALUE;

    /** 			exit*/
    goto L3; // [51] 101
L4: 

    /** 		i += 1*/
    _i_17433 = _i_17433 + 1;

    /** 		if i > length(s) then*/
    if (IS_SEQUENCE(_s_17431)){
            _9910 = SEQ_PTR(_s_17431)->length;
    }
    else {
        _9910 = 1;
    }
    if (_i_17433 <= _9910)
    goto L5; // [65] 80

    /** 			s &= repeat(0, 256)*/
    _9912 = Repeat(0, 256);
    Concat((object_ptr)&_s_17431, _s_17431, _9912);
    DeRefDS(_9912);
    _9912 = NOVALUE;
L5: 

    /** 		s[i] = c*/
    _2 = (int)SEQ_PTR(_s_17431);
    _2 = (int)(((s1_ptr)_2)->base + _i_17433);
    *(int *)_2 = _c_17432;

    /** 	  entry*/
L1: 

    /** 		c = getc(current_db)*/
    if (_49current_db_17372 != last_r_file_no) {
        last_r_file_ptr = which_file(_49current_db_17372, EF_READ);
        last_r_file_no = _49current_db_17372;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _c_17432 = getKBchar();
        }
        else
        _c_17432 = getc(last_r_file_ptr);
    }
    else
    _c_17432 = getc(last_r_file_ptr);

    /** 	end while*/
    goto L2; // [98] 17
L3: 

    /** 	return s[1..i]*/
    rhs_slice_target = (object_ptr)&_9915;
    RHS_Slice(_s_17431, 1, _i_17433);
    DeRefDSi(_s_17431);
    return _9915;
    ;
}


int _49equal_string(int _target_17454)
{
    int _c_17455 = NOVALUE;
    int _i_17456 = NOVALUE;
    int _where_inlined_where_at_27_17462 = NOVALUE;
    int _9926 = NOVALUE;
    int _9925 = NOVALUE;
    int _9922 = NOVALUE;
    int _9920 = NOVALUE;
    int _9918 = NOVALUE;
    int _0, _1, _2;
    

    /** 	i = 0*/
    _i_17456 = 0;

    /** 	while c with entry do*/
    goto L1; // [10] 94
L2: 
    if (_c_17455 == 0)
    {
        goto L3; // [15] 106
    }
    else{
    }

    /** 		if c = -1 then*/
    if (_c_17455 != -1)
    goto L4; // [20] 52

    /** 			fatal(MISSING_END, "string is missing 0 terminator", "equal_string", {io:where(current_db)})*/

    /** 	return machine_func(M_WHERE, fn)*/
    DeRef(_where_inlined_where_at_27_17462);
    _where_inlined_where_at_27_17462 = machine(20, _49current_db_17372);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_where_inlined_where_at_27_17462);
    *((int *)(_2+4)) = _where_inlined_where_at_27_17462;
    _9918 = MAKE_SEQ(_1);
    RefDS(_9906);
    RefDS(_9917);
    _49fatal(900, _9906, _9917, _9918);
    _9918 = NOVALUE;

    /** 			return DB_FATAL_FAIL*/
    DeRefDS(_target_17454);
    return -404;
L4: 

    /** 		i += 1*/
    _i_17456 = _i_17456 + 1;

    /** 		if i > length(target) then*/
    if (IS_SEQUENCE(_target_17454)){
            _9920 = SEQ_PTR(_target_17454)->length;
    }
    else {
        _9920 = 1;
    }
    if (_i_17456 <= _9920)
    goto L5; // [63] 74

    /** 			return 0*/
    DeRefDS(_target_17454);
    return 0;
L5: 

    /** 		if target[i] != c then*/
    _2 = (int)SEQ_PTR(_target_17454);
    _9922 = (int)*(((s1_ptr)_2)->base + _i_17456);
    if (binary_op_a(EQUALS, _9922, _c_17455)){
        _9922 = NOVALUE;
        goto L6; // [80] 91
    }
    _9922 = NOVALUE;

    /** 			return 0*/
    DeRefDS(_target_17454);
    return 0;
L6: 

    /** 	  entry*/
L1: 

    /** 		c = getc(current_db)*/
    if (_49current_db_17372 != last_r_file_no) {
        last_r_file_ptr = which_file(_49current_db_17372, EF_READ);
        last_r_file_no = _49current_db_17372;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _c_17455 = getKBchar();
        }
        else
        _c_17455 = getc(last_r_file_ptr);
    }
    else
    _c_17455 = getc(last_r_file_ptr);

    /** 	end while*/
    goto L2; // [103] 13
L3: 

    /** 	return (i = length(target))*/
    if (IS_SEQUENCE(_target_17454)){
            _9925 = SEQ_PTR(_target_17454)->length;
    }
    else {
        _9925 = 1;
    }
    _9926 = (_i_17456 == _9925);
    _9925 = NOVALUE;
    DeRefDS(_target_17454);
    return _9926;
    ;
}


int _49decompress(int _c_17513)
{
    int _s_17514 = NOVALUE;
    int _len_17515 = NOVALUE;
    int _float32_to_atom_inlined_float32_to_atom_at_176_17551 = NOVALUE;
    int _ieee32_inlined_float32_to_atom_at_173_17550 = NOVALUE;
    int _float64_to_atom_inlined_float64_to_atom_at_251_17564 = NOVALUE;
    int _ieee64_inlined_float64_to_atom_at_248_17563 = NOVALUE;
    int _9995 = NOVALUE;
    int _9994 = NOVALUE;
    int _9993 = NOVALUE;
    int _9990 = NOVALUE;
    int _9985 = NOVALUE;
    int _9984 = NOVALUE;
    int _9983 = NOVALUE;
    int _9982 = NOVALUE;
    int _9981 = NOVALUE;
    int _9980 = NOVALUE;
    int _9979 = NOVALUE;
    int _9978 = NOVALUE;
    int _9977 = NOVALUE;
    int _9976 = NOVALUE;
    int _9975 = NOVALUE;
    int _9974 = NOVALUE;
    int _9973 = NOVALUE;
    int _9972 = NOVALUE;
    int _9971 = NOVALUE;
    int _9970 = NOVALUE;
    int _9969 = NOVALUE;
    int _9968 = NOVALUE;
    int _9967 = NOVALUE;
    int _9966 = NOVALUE;
    int _9964 = NOVALUE;
    int _9963 = NOVALUE;
    int _9962 = NOVALUE;
    int _9961 = NOVALUE;
    int _9960 = NOVALUE;
    int _9959 = NOVALUE;
    int _9958 = NOVALUE;
    int _9957 = NOVALUE;
    int _9956 = NOVALUE;
    int _9953 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if c = 0 then*/
    if (_c_17513 != 0)
    goto L1; // [5] 34

    /** 		c = getc(current_db)*/
    if (_49current_db_17372 != last_r_file_no) {
        last_r_file_ptr = which_file(_49current_db_17372, EF_READ);
        last_r_file_no = _49current_db_17372;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _c_17513 = getKBchar();
        }
        else
        _c_17513 = getc(last_r_file_ptr);
    }
    else
    _c_17513 = getc(last_r_file_ptr);

    /** 		if c < I2B then*/
    if (_c_17513 >= 249)
    goto L2; // [18] 33

    /** 			return c + MIN1B*/
    _9953 = _c_17513 + -9;
    DeRef(_s_17514);
    return _9953;
L2: 
L1: 

    /** 	switch c with fallthru do*/
    _0 = _c_17513;
    switch ( _0 ){ 

        /** 		case I2B then*/
        case 249:

        /** 			return getc(current_db) +*/
        if (_49current_db_17372 != last_r_file_no) {
            last_r_file_ptr = which_file(_49current_db_17372, EF_READ);
            last_r_file_no = _49current_db_17372;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _9956 = getKBchar();
            }
            else
            _9956 = getc(last_r_file_ptr);
        }
        else
        _9956 = getc(last_r_file_ptr);
        if (_49current_db_17372 != last_r_file_no) {
            last_r_file_ptr = which_file(_49current_db_17372, EF_READ);
            last_r_file_no = _49current_db_17372;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _9957 = getKBchar();
            }
            else
            _9957 = getc(last_r_file_ptr);
        }
        else
        _9957 = getc(last_r_file_ptr);
        _9958 = 256 * _9957;
        _9957 = NOVALUE;
        _9959 = _9956 + _9958;
        _9956 = NOVALUE;
        _9958 = NOVALUE;
        _9960 = _9959 + _49MIN2B_17493;
        if ((long)((unsigned long)_9960 + (unsigned long)HIGH_BITS) >= 0) 
        _9960 = NewDouble((double)_9960);
        _9959 = NOVALUE;
        DeRef(_s_17514);
        DeRef(_9953);
        _9953 = NOVALUE;
        return _9960;

        /** 		case I3B then*/
        case 250:

        /** 			return getc(current_db) +*/
        if (_49current_db_17372 != last_r_file_no) {
            last_r_file_ptr = which_file(_49current_db_17372, EF_READ);
            last_r_file_no = _49current_db_17372;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _9961 = getKBchar();
            }
            else
            _9961 = getc(last_r_file_ptr);
        }
        else
        _9961 = getc(last_r_file_ptr);
        if (_49current_db_17372 != last_r_file_no) {
            last_r_file_ptr = which_file(_49current_db_17372, EF_READ);
            last_r_file_no = _49current_db_17372;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _9962 = getKBchar();
            }
            else
            _9962 = getc(last_r_file_ptr);
        }
        else
        _9962 = getc(last_r_file_ptr);
        _9963 = 256 * _9962;
        _9962 = NOVALUE;
        _9964 = _9961 + _9963;
        _9961 = NOVALUE;
        _9963 = NOVALUE;
        if (_49current_db_17372 != last_r_file_no) {
            last_r_file_ptr = which_file(_49current_db_17372, EF_READ);
            last_r_file_no = _49current_db_17372;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _9966 = getKBchar();
            }
            else
            _9966 = getc(last_r_file_ptr);
        }
        else
        _9966 = getc(last_r_file_ptr);
        _9967 = 65536 * _9966;
        _9966 = NOVALUE;
        _9968 = _9964 + _9967;
        _9964 = NOVALUE;
        _9967 = NOVALUE;
        _9969 = _9968 + _49MIN3B_17500;
        if ((long)((unsigned long)_9969 + (unsigned long)HIGH_BITS) >= 0) 
        _9969 = NewDouble((double)_9969);
        _9968 = NOVALUE;
        DeRef(_s_17514);
        DeRef(_9953);
        _9953 = NOVALUE;
        DeRef(_9960);
        _9960 = NOVALUE;
        return _9969;

        /** 		case I4B then*/
        case 251:

        /** 			return get4() + MIN4B*/
        _9970 = _49get4();
        if (IS_ATOM_INT(_9970) && IS_ATOM_INT(_49MIN4B_17507)) {
            _9971 = _9970 + _49MIN4B_17507;
            if ((long)((unsigned long)_9971 + (unsigned long)HIGH_BITS) >= 0) 
            _9971 = NewDouble((double)_9971);
        }
        else {
            _9971 = binary_op(PLUS, _9970, _49MIN4B_17507);
        }
        DeRef(_9970);
        _9970 = NOVALUE;
        DeRef(_s_17514);
        DeRef(_9953);
        _9953 = NOVALUE;
        DeRef(_9960);
        _9960 = NOVALUE;
        DeRef(_9969);
        _9969 = NOVALUE;
        return _9971;

        /** 		case F4B then*/
        case 252:

        /** 			return convert:float32_to_atom({getc(current_db), getc(current_db),*/
        if (_49current_db_17372 != last_r_file_no) {
            last_r_file_ptr = which_file(_49current_db_17372, EF_READ);
            last_r_file_no = _49current_db_17372;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _9972 = getKBchar();
            }
            else
            _9972 = getc(last_r_file_ptr);
        }
        else
        _9972 = getc(last_r_file_ptr);
        if (_49current_db_17372 != last_r_file_no) {
            last_r_file_ptr = which_file(_49current_db_17372, EF_READ);
            last_r_file_no = _49current_db_17372;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _9973 = getKBchar();
            }
            else
            _9973 = getc(last_r_file_ptr);
        }
        else
        _9973 = getc(last_r_file_ptr);
        if (_49current_db_17372 != last_r_file_no) {
            last_r_file_ptr = which_file(_49current_db_17372, EF_READ);
            last_r_file_no = _49current_db_17372;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _9974 = getKBchar();
            }
            else
            _9974 = getc(last_r_file_ptr);
        }
        else
        _9974 = getc(last_r_file_ptr);
        if (_49current_db_17372 != last_r_file_no) {
            last_r_file_ptr = which_file(_49current_db_17372, EF_READ);
            last_r_file_no = _49current_db_17372;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _9975 = getKBchar();
            }
            else
            _9975 = getc(last_r_file_ptr);
        }
        else
        _9975 = getc(last_r_file_ptr);
        _1 = NewS1(4);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = _9972;
        *((int *)(_2+8)) = _9973;
        *((int *)(_2+12)) = _9974;
        *((int *)(_2+16)) = _9975;
        _9976 = MAKE_SEQ(_1);
        _9975 = NOVALUE;
        _9974 = NOVALUE;
        _9973 = NOVALUE;
        _9972 = NOVALUE;
        DeRefi(_ieee32_inlined_float32_to_atom_at_173_17550);
        _ieee32_inlined_float32_to_atom_at_173_17550 = _9976;
        _9976 = NOVALUE;

        /** 	return machine_func(M_F32_TO_A, ieee32)*/
        DeRef(_float32_to_atom_inlined_float32_to_atom_at_176_17551);
        _float32_to_atom_inlined_float32_to_atom_at_176_17551 = machine(49, _ieee32_inlined_float32_to_atom_at_173_17550);
        DeRefi(_ieee32_inlined_float32_to_atom_at_173_17550);
        _ieee32_inlined_float32_to_atom_at_173_17550 = NOVALUE;
        DeRef(_s_17514);
        DeRef(_9953);
        _9953 = NOVALUE;
        DeRef(_9960);
        _9960 = NOVALUE;
        DeRef(_9969);
        _9969 = NOVALUE;
        DeRef(_9971);
        _9971 = NOVALUE;
        return _float32_to_atom_inlined_float32_to_atom_at_176_17551;

        /** 		case F8B then*/
        case 253:

        /** 			return convert:float64_to_atom({getc(current_db), getc(current_db),*/
        if (_49current_db_17372 != last_r_file_no) {
            last_r_file_ptr = which_file(_49current_db_17372, EF_READ);
            last_r_file_no = _49current_db_17372;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _9977 = getKBchar();
            }
            else
            _9977 = getc(last_r_file_ptr);
        }
        else
        _9977 = getc(last_r_file_ptr);
        if (_49current_db_17372 != last_r_file_no) {
            last_r_file_ptr = which_file(_49current_db_17372, EF_READ);
            last_r_file_no = _49current_db_17372;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _9978 = getKBchar();
            }
            else
            _9978 = getc(last_r_file_ptr);
        }
        else
        _9978 = getc(last_r_file_ptr);
        if (_49current_db_17372 != last_r_file_no) {
            last_r_file_ptr = which_file(_49current_db_17372, EF_READ);
            last_r_file_no = _49current_db_17372;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _9979 = getKBchar();
            }
            else
            _9979 = getc(last_r_file_ptr);
        }
        else
        _9979 = getc(last_r_file_ptr);
        if (_49current_db_17372 != last_r_file_no) {
            last_r_file_ptr = which_file(_49current_db_17372, EF_READ);
            last_r_file_no = _49current_db_17372;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _9980 = getKBchar();
            }
            else
            _9980 = getc(last_r_file_ptr);
        }
        else
        _9980 = getc(last_r_file_ptr);
        if (_49current_db_17372 != last_r_file_no) {
            last_r_file_ptr = which_file(_49current_db_17372, EF_READ);
            last_r_file_no = _49current_db_17372;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _9981 = getKBchar();
            }
            else
            _9981 = getc(last_r_file_ptr);
        }
        else
        _9981 = getc(last_r_file_ptr);
        if (_49current_db_17372 != last_r_file_no) {
            last_r_file_ptr = which_file(_49current_db_17372, EF_READ);
            last_r_file_no = _49current_db_17372;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _9982 = getKBchar();
            }
            else
            _9982 = getc(last_r_file_ptr);
        }
        else
        _9982 = getc(last_r_file_ptr);
        if (_49current_db_17372 != last_r_file_no) {
            last_r_file_ptr = which_file(_49current_db_17372, EF_READ);
            last_r_file_no = _49current_db_17372;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _9983 = getKBchar();
            }
            else
            _9983 = getc(last_r_file_ptr);
        }
        else
        _9983 = getc(last_r_file_ptr);
        if (_49current_db_17372 != last_r_file_no) {
            last_r_file_ptr = which_file(_49current_db_17372, EF_READ);
            last_r_file_no = _49current_db_17372;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _9984 = getKBchar();
            }
            else
            _9984 = getc(last_r_file_ptr);
        }
        else
        _9984 = getc(last_r_file_ptr);
        _1 = NewS1(8);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = _9977;
        *((int *)(_2+8)) = _9978;
        *((int *)(_2+12)) = _9979;
        *((int *)(_2+16)) = _9980;
        *((int *)(_2+20)) = _9981;
        *((int *)(_2+24)) = _9982;
        *((int *)(_2+28)) = _9983;
        *((int *)(_2+32)) = _9984;
        _9985 = MAKE_SEQ(_1);
        _9984 = NOVALUE;
        _9983 = NOVALUE;
        _9982 = NOVALUE;
        _9981 = NOVALUE;
        _9980 = NOVALUE;
        _9979 = NOVALUE;
        _9978 = NOVALUE;
        _9977 = NOVALUE;
        DeRefi(_ieee64_inlined_float64_to_atom_at_248_17563);
        _ieee64_inlined_float64_to_atom_at_248_17563 = _9985;
        _9985 = NOVALUE;

        /** 	return machine_func(M_F64_TO_A, ieee64)*/
        DeRef(_float64_to_atom_inlined_float64_to_atom_at_251_17564);
        _float64_to_atom_inlined_float64_to_atom_at_251_17564 = machine(47, _ieee64_inlined_float64_to_atom_at_248_17563);
        DeRefi(_ieee64_inlined_float64_to_atom_at_248_17563);
        _ieee64_inlined_float64_to_atom_at_248_17563 = NOVALUE;
        DeRef(_s_17514);
        DeRef(_9953);
        _9953 = NOVALUE;
        DeRef(_9960);
        _9960 = NOVALUE;
        DeRef(_9969);
        _9969 = NOVALUE;
        DeRef(_9971);
        _9971 = NOVALUE;
        return _float64_to_atom_inlined_float64_to_atom_at_251_17564;

        /** 		case else*/
        default:

        /** 			if c = S1B then*/
        if (_c_17513 != 254)
        goto L3; // [273] 287

        /** 				len = getc(current_db)*/
        if (_49current_db_17372 != last_r_file_no) {
            last_r_file_ptr = which_file(_49current_db_17372, EF_READ);
            last_r_file_no = _49current_db_17372;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _len_17515 = getKBchar();
            }
            else
            _len_17515 = getc(last_r_file_ptr);
        }
        else
        _len_17515 = getc(last_r_file_ptr);
        goto L4; // [284] 295
L3: 

        /** 				len = get4()*/
        _len_17515 = _49get4();
        if (!IS_ATOM_INT(_len_17515)) {
            _1 = (long)(DBL_PTR(_len_17515)->dbl);
            DeRefDS(_len_17515);
            _len_17515 = _1;
        }
L4: 

        /** 			s = repeat(0, len)*/
        DeRef(_s_17514);
        _s_17514 = Repeat(0, _len_17515);

        /** 			for i = 1 to len do*/
        _9990 = _len_17515;
        {
            int _i_17573;
            _i_17573 = 1;
L5: 
            if (_i_17573 > _9990){
                goto L6; // [308] 362
            }

            /** 				c = getc(current_db)*/
            if (_49current_db_17372 != last_r_file_no) {
                last_r_file_ptr = which_file(_49current_db_17372, EF_READ);
                last_r_file_no = _49current_db_17372;
            }
            if (last_r_file_ptr == xstdin) {
                show_console();
                if (in_from_keyb) {
                    _c_17513 = getKBchar();
                }
                else
                _c_17513 = getc(last_r_file_ptr);
            }
            else
            _c_17513 = getc(last_r_file_ptr);

            /** 				if c < I2B then*/
            if (_c_17513 >= 249)
            goto L7; // [324] 341

            /** 					s[i] = c + MIN1B*/
            _9993 = _c_17513 + -9;
            _2 = (int)SEQ_PTR(_s_17514);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _s_17514 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _i_17573);
            _1 = *(int *)_2;
            *(int *)_2 = _9993;
            if( _1 != _9993 ){
                DeRef(_1);
            }
            _9993 = NOVALUE;
            goto L8; // [338] 355
L7: 

            /** 					s[i] = decompress(c)*/
            DeRef(_9994);
            _9994 = _c_17513;
            _9995 = _49decompress(_9994);
            _9994 = NOVALUE;
            _2 = (int)SEQ_PTR(_s_17514);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _s_17514 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _i_17573);
            _1 = *(int *)_2;
            *(int *)_2 = _9995;
            if( _1 != _9995 ){
                DeRef(_1);
            }
            _9995 = NOVALUE;
L8: 

            /** 			end for*/
            _i_17573 = _i_17573 + 1;
            goto L5; // [357] 315
L6: 
            ;
        }

        /** 			return s*/
        DeRef(_9953);
        _9953 = NOVALUE;
        DeRef(_9960);
        _9960 = NOVALUE;
        DeRef(_9969);
        _9969 = NOVALUE;
        DeRef(_9971);
        _9971 = NOVALUE;
        return _s_17514;
    ;}    ;
}


int _49compress(int _x_17584)
{
    int _x4_17585 = NOVALUE;
    int _s_17586 = NOVALUE;
    int _atom_to_float32_inlined_atom_to_float32_at_192_17620 = NOVALUE;
    int _float32_to_atom_inlined_float32_to_atom_at_203_17623 = NOVALUE;
    int _atom_to_float64_inlined_atom_to_float64_at_229_17628 = NOVALUE;
    int _10034 = NOVALUE;
    int _10033 = NOVALUE;
    int _10032 = NOVALUE;
    int _10030 = NOVALUE;
    int _10029 = NOVALUE;
    int _10027 = NOVALUE;
    int _10025 = NOVALUE;
    int _10024 = NOVALUE;
    int _10023 = NOVALUE;
    int _10021 = NOVALUE;
    int _10020 = NOVALUE;
    int _10019 = NOVALUE;
    int _10018 = NOVALUE;
    int _10017 = NOVALUE;
    int _10016 = NOVALUE;
    int _10015 = NOVALUE;
    int _10014 = NOVALUE;
    int _10013 = NOVALUE;
    int _10011 = NOVALUE;
    int _10010 = NOVALUE;
    int _10009 = NOVALUE;
    int _10008 = NOVALUE;
    int _10007 = NOVALUE;
    int _10006 = NOVALUE;
    int _10004 = NOVALUE;
    int _10003 = NOVALUE;
    int _10002 = NOVALUE;
    int _10001 = NOVALUE;
    int _10000 = NOVALUE;
    int _9999 = NOVALUE;
    int _9998 = NOVALUE;
    int _9997 = NOVALUE;
    int _9996 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if integer(x) then*/
    if (IS_ATOM_INT(_x_17584))
    _9996 = 1;
    else if (IS_ATOM_DBL(_x_17584))
    _9996 = IS_ATOM_INT(DoubleToInt(_x_17584));
    else
    _9996 = 0;
    if (_9996 == 0)
    {
        _9996 = NOVALUE;
        goto L1; // [6] 183
    }
    else{
        _9996 = NOVALUE;
    }

    /** 		if x >= MIN1B and x <= MAX1B then*/
    if (IS_ATOM_INT(_x_17584)) {
        _9997 = (_x_17584 >= -9);
    }
    else {
        _9997 = binary_op(GREATEREQ, _x_17584, -9);
    }
    if (IS_ATOM_INT(_9997)) {
        if (_9997 == 0) {
            goto L2; // [15] 44
        }
    }
    else {
        if (DBL_PTR(_9997)->dbl == 0.0) {
            goto L2; // [15] 44
        }
    }
    if (IS_ATOM_INT(_x_17584)) {
        _9999 = (_x_17584 <= 239);
    }
    else {
        _9999 = binary_op(LESSEQ, _x_17584, 239);
    }
    if (_9999 == 0) {
        DeRef(_9999);
        _9999 = NOVALUE;
        goto L2; // [24] 44
    }
    else {
        if (!IS_ATOM_INT(_9999) && DBL_PTR(_9999)->dbl == 0.0){
            DeRef(_9999);
            _9999 = NOVALUE;
            goto L2; // [24] 44
        }
        DeRef(_9999);
        _9999 = NOVALUE;
    }
    DeRef(_9999);
    _9999 = NOVALUE;

    /** 			return {x - MIN1B}*/
    if (IS_ATOM_INT(_x_17584)) {
        _10000 = _x_17584 - -9;
        if ((long)((unsigned long)_10000 +(unsigned long) HIGH_BITS) >= 0){
            _10000 = NewDouble((double)_10000);
        }
    }
    else {
        _10000 = binary_op(MINUS, _x_17584, -9);
    }
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _10000;
    _10001 = MAKE_SEQ(_1);
    _10000 = NOVALUE;
    DeRef(_x_17584);
    DeRefi(_x4_17585);
    DeRef(_s_17586);
    DeRef(_9997);
    _9997 = NOVALUE;
    return _10001;
    goto L3; // [41] 328
L2: 

    /** 		elsif x >= MIN2B and x <= MAX2B then*/
    if (IS_ATOM_INT(_x_17584)) {
        _10002 = (_x_17584 >= _49MIN2B_17493);
    }
    else {
        _10002 = binary_op(GREATEREQ, _x_17584, _49MIN2B_17493);
    }
    if (IS_ATOM_INT(_10002)) {
        if (_10002 == 0) {
            goto L4; // [52] 97
        }
    }
    else {
        if (DBL_PTR(_10002)->dbl == 0.0) {
            goto L4; // [52] 97
        }
    }
    if (IS_ATOM_INT(_x_17584)) {
        _10004 = (_x_17584 <= 32767);
    }
    else {
        _10004 = binary_op(LESSEQ, _x_17584, 32767);
    }
    if (_10004 == 0) {
        DeRef(_10004);
        _10004 = NOVALUE;
        goto L4; // [63] 97
    }
    else {
        if (!IS_ATOM_INT(_10004) && DBL_PTR(_10004)->dbl == 0.0){
            DeRef(_10004);
            _10004 = NOVALUE;
            goto L4; // [63] 97
        }
        DeRef(_10004);
        _10004 = NOVALUE;
    }
    DeRef(_10004);
    _10004 = NOVALUE;

    /** 			x -= MIN2B*/
    _0 = _x_17584;
    if (IS_ATOM_INT(_x_17584)) {
        _x_17584 = _x_17584 - _49MIN2B_17493;
        if ((long)((unsigned long)_x_17584 +(unsigned long) HIGH_BITS) >= 0){
            _x_17584 = NewDouble((double)_x_17584);
        }
    }
    else {
        _x_17584 = binary_op(MINUS, _x_17584, _49MIN2B_17493);
    }
    DeRef(_0);

    /** 			return {I2B, and_bits(x, #FF), floor(x / #100)}*/
    if (IS_ATOM_INT(_x_17584)) {
        {unsigned long tu;
             tu = (unsigned long)_x_17584 & (unsigned long)255;
             _10006 = MAKE_UINT(tu);
        }
    }
    else {
        _10006 = binary_op(AND_BITS, _x_17584, 255);
    }
    if (IS_ATOM_INT(_x_17584)) {
        if (256 > 0 && _x_17584 >= 0) {
            _10007 = _x_17584 / 256;
        }
        else {
            temp_dbl = floor((double)_x_17584 / (double)256);
            if (_x_17584 != MININT)
            _10007 = (long)temp_dbl;
            else
            _10007 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x_17584, 256);
        _10007 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 249;
    *((int *)(_2+8)) = _10006;
    *((int *)(_2+12)) = _10007;
    _10008 = MAKE_SEQ(_1);
    _10007 = NOVALUE;
    _10006 = NOVALUE;
    DeRef(_x_17584);
    DeRefi(_x4_17585);
    DeRef(_s_17586);
    DeRef(_9997);
    _9997 = NOVALUE;
    DeRef(_10001);
    _10001 = NOVALUE;
    DeRef(_10002);
    _10002 = NOVALUE;
    return _10008;
    goto L3; // [94] 328
L4: 

    /** 		elsif x >= MIN3B and x <= MAX3B then*/
    if (IS_ATOM_INT(_x_17584)) {
        _10009 = (_x_17584 >= _49MIN3B_17500);
    }
    else {
        _10009 = binary_op(GREATEREQ, _x_17584, _49MIN3B_17500);
    }
    if (IS_ATOM_INT(_10009)) {
        if (_10009 == 0) {
            goto L5; // [105] 159
        }
    }
    else {
        if (DBL_PTR(_10009)->dbl == 0.0) {
            goto L5; // [105] 159
        }
    }
    if (IS_ATOM_INT(_x_17584)) {
        _10011 = (_x_17584 <= 8388607);
    }
    else {
        _10011 = binary_op(LESSEQ, _x_17584, 8388607);
    }
    if (_10011 == 0) {
        DeRef(_10011);
        _10011 = NOVALUE;
        goto L5; // [116] 159
    }
    else {
        if (!IS_ATOM_INT(_10011) && DBL_PTR(_10011)->dbl == 0.0){
            DeRef(_10011);
            _10011 = NOVALUE;
            goto L5; // [116] 159
        }
        DeRef(_10011);
        _10011 = NOVALUE;
    }
    DeRef(_10011);
    _10011 = NOVALUE;

    /** 			x -= MIN3B*/
    _0 = _x_17584;
    if (IS_ATOM_INT(_x_17584)) {
        _x_17584 = _x_17584 - _49MIN3B_17500;
        if ((long)((unsigned long)_x_17584 +(unsigned long) HIGH_BITS) >= 0){
            _x_17584 = NewDouble((double)_x_17584);
        }
    }
    else {
        _x_17584 = binary_op(MINUS, _x_17584, _49MIN3B_17500);
    }
    DeRef(_0);

    /** 			return {I3B, and_bits(x, #FF), and_bits(floor(x / #100), #FF), floor(x / #10000)}*/
    if (IS_ATOM_INT(_x_17584)) {
        {unsigned long tu;
             tu = (unsigned long)_x_17584 & (unsigned long)255;
             _10013 = MAKE_UINT(tu);
        }
    }
    else {
        _10013 = binary_op(AND_BITS, _x_17584, 255);
    }
    if (IS_ATOM_INT(_x_17584)) {
        if (256 > 0 && _x_17584 >= 0) {
            _10014 = _x_17584 / 256;
        }
        else {
            temp_dbl = floor((double)_x_17584 / (double)256);
            if (_x_17584 != MININT)
            _10014 = (long)temp_dbl;
            else
            _10014 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x_17584, 256);
        _10014 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    if (IS_ATOM_INT(_10014)) {
        {unsigned long tu;
             tu = (unsigned long)_10014 & (unsigned long)255;
             _10015 = MAKE_UINT(tu);
        }
    }
    else {
        _10015 = binary_op(AND_BITS, _10014, 255);
    }
    DeRef(_10014);
    _10014 = NOVALUE;
    if (IS_ATOM_INT(_x_17584)) {
        if (65536 > 0 && _x_17584 >= 0) {
            _10016 = _x_17584 / 65536;
        }
        else {
            temp_dbl = floor((double)_x_17584 / (double)65536);
            if (_x_17584 != MININT)
            _10016 = (long)temp_dbl;
            else
            _10016 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x_17584, 65536);
        _10016 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 250;
    *((int *)(_2+8)) = _10013;
    *((int *)(_2+12)) = _10015;
    *((int *)(_2+16)) = _10016;
    _10017 = MAKE_SEQ(_1);
    _10016 = NOVALUE;
    _10015 = NOVALUE;
    _10013 = NOVALUE;
    DeRef(_x_17584);
    DeRefi(_x4_17585);
    DeRef(_s_17586);
    DeRef(_9997);
    _9997 = NOVALUE;
    DeRef(_10001);
    _10001 = NOVALUE;
    DeRef(_10002);
    _10002 = NOVALUE;
    DeRef(_10008);
    _10008 = NOVALUE;
    DeRef(_10009);
    _10009 = NOVALUE;
    return _10017;
    goto L3; // [156] 328
L5: 

    /** 			return I4B & convert:int_to_bytes(x-MIN4B)*/
    if (IS_ATOM_INT(_x_17584) && IS_ATOM_INT(_49MIN4B_17507)) {
        _10018 = _x_17584 - _49MIN4B_17507;
        if ((long)((unsigned long)_10018 +(unsigned long) HIGH_BITS) >= 0){
            _10018 = NewDouble((double)_10018);
        }
    }
    else {
        _10018 = binary_op(MINUS, _x_17584, _49MIN4B_17507);
    }
    _10019 = _15int_to_bytes(_10018);
    _10018 = NOVALUE;
    if (IS_SEQUENCE(251) && IS_ATOM(_10019)) {
    }
    else if (IS_ATOM(251) && IS_SEQUENCE(_10019)) {
        Prepend(&_10020, _10019, 251);
    }
    else {
        Concat((object_ptr)&_10020, 251, _10019);
    }
    DeRef(_10019);
    _10019 = NOVALUE;
    DeRef(_x_17584);
    DeRefi(_x4_17585);
    DeRef(_s_17586);
    DeRef(_9997);
    _9997 = NOVALUE;
    DeRef(_10001);
    _10001 = NOVALUE;
    DeRef(_10002);
    _10002 = NOVALUE;
    DeRef(_10008);
    _10008 = NOVALUE;
    DeRef(_10009);
    _10009 = NOVALUE;
    DeRef(_10017);
    _10017 = NOVALUE;
    return _10020;
    goto L3; // [180] 328
L1: 

    /** 	elsif atom(x) then*/
    _10021 = IS_ATOM(_x_17584);
    if (_10021 == 0)
    {
        _10021 = NOVALUE;
        goto L6; // [188] 249
    }
    else{
        _10021 = NOVALUE;
    }

    /** 		x4 = convert:atom_to_float32(x)*/

    /** 	return machine_func(M_A_TO_F32, a)*/
    DeRefi(_x4_17585);
    _x4_17585 = machine(48, _x_17584);

    /** 		if x = convert:float32_to_atom(x4) then*/

    /** 	return machine_func(M_F32_TO_A, ieee32)*/
    DeRef(_float32_to_atom_inlined_float32_to_atom_at_203_17623);
    _float32_to_atom_inlined_float32_to_atom_at_203_17623 = machine(49, _x4_17585);
    if (binary_op_a(NOTEQ, _x_17584, _float32_to_atom_inlined_float32_to_atom_at_203_17623)){
        goto L7; // [211] 228
    }

    /** 			return F4B & x4*/
    Prepend(&_10023, _x4_17585, 252);
    DeRef(_x_17584);
    DeRefDSi(_x4_17585);
    DeRef(_s_17586);
    DeRef(_9997);
    _9997 = NOVALUE;
    DeRef(_10001);
    _10001 = NOVALUE;
    DeRef(_10002);
    _10002 = NOVALUE;
    DeRef(_10008);
    _10008 = NOVALUE;
    DeRef(_10009);
    _10009 = NOVALUE;
    DeRef(_10017);
    _10017 = NOVALUE;
    DeRef(_10020);
    _10020 = NOVALUE;
    return _10023;
    goto L3; // [225] 328
L7: 

    /** 			return F8B & convert:atom_to_float64(x)*/

    /** 	return machine_func(M_A_TO_F64, a)*/
    DeRefi(_atom_to_float64_inlined_atom_to_float64_at_229_17628);
    _atom_to_float64_inlined_atom_to_float64_at_229_17628 = machine(46, _x_17584);
    Prepend(&_10024, _atom_to_float64_inlined_atom_to_float64_at_229_17628, 253);
    DeRef(_x_17584);
    DeRefi(_x4_17585);
    DeRef(_s_17586);
    DeRef(_9997);
    _9997 = NOVALUE;
    DeRef(_10001);
    _10001 = NOVALUE;
    DeRef(_10002);
    _10002 = NOVALUE;
    DeRef(_10008);
    _10008 = NOVALUE;
    DeRef(_10009);
    _10009 = NOVALUE;
    DeRef(_10017);
    _10017 = NOVALUE;
    DeRef(_10020);
    _10020 = NOVALUE;
    DeRef(_10023);
    _10023 = NOVALUE;
    return _10024;
    goto L3; // [246] 328
L6: 

    /** 		if length(x) <= 255 then*/
    if (IS_SEQUENCE(_x_17584)){
            _10025 = SEQ_PTR(_x_17584)->length;
    }
    else {
        _10025 = 1;
    }
    if (_10025 > 255)
    goto L8; // [254] 270

    /** 			s = {S1B, length(x)}*/
    if (IS_SEQUENCE(_x_17584)){
            _10027 = SEQ_PTR(_x_17584)->length;
    }
    else {
        _10027 = 1;
    }
    DeRef(_s_17586);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 254;
    ((int *)_2)[2] = _10027;
    _s_17586 = MAKE_SEQ(_1);
    _10027 = NOVALUE;
    goto L9; // [267] 284
L8: 

    /** 			s = S4B & convert:int_to_bytes(length(x))*/
    if (IS_SEQUENCE(_x_17584)){
            _10029 = SEQ_PTR(_x_17584)->length;
    }
    else {
        _10029 = 1;
    }
    _10030 = _15int_to_bytes(_10029);
    _10029 = NOVALUE;
    if (IS_SEQUENCE(255) && IS_ATOM(_10030)) {
    }
    else if (IS_ATOM(255) && IS_SEQUENCE(_10030)) {
        Prepend(&_s_17586, _10030, 255);
    }
    else {
        Concat((object_ptr)&_s_17586, 255, _10030);
    }
    DeRef(_10030);
    _10030 = NOVALUE;
L9: 

    /** 		for i = 1 to length(x) do*/
    if (IS_SEQUENCE(_x_17584)){
            _10032 = SEQ_PTR(_x_17584)->length;
    }
    else {
        _10032 = 1;
    }
    {
        int _i_17641;
        _i_17641 = 1;
LA: 
        if (_i_17641 > _10032){
            goto LB; // [289] 319
        }

        /** 			s &= compress(x[i])*/
        _2 = (int)SEQ_PTR(_x_17584);
        _10033 = (int)*(((s1_ptr)_2)->base + _i_17641);
        Ref(_10033);
        _10034 = _49compress(_10033);
        _10033 = NOVALUE;
        if (IS_SEQUENCE(_s_17586) && IS_ATOM(_10034)) {
            Ref(_10034);
            Append(&_s_17586, _s_17586, _10034);
        }
        else if (IS_ATOM(_s_17586) && IS_SEQUENCE(_10034)) {
        }
        else {
            Concat((object_ptr)&_s_17586, _s_17586, _10034);
        }
        DeRef(_10034);
        _10034 = NOVALUE;

        /** 		end for*/
        _i_17641 = _i_17641 + 1;
        goto LA; // [314] 296
LB: 
        ;
    }

    /** 		return s*/
    DeRef(_x_17584);
    DeRefi(_x4_17585);
    DeRef(_9997);
    _9997 = NOVALUE;
    DeRef(_10001);
    _10001 = NOVALUE;
    DeRef(_10002);
    _10002 = NOVALUE;
    DeRef(_10008);
    _10008 = NOVALUE;
    DeRef(_10009);
    _10009 = NOVALUE;
    DeRef(_10017);
    _10017 = NOVALUE;
    DeRef(_10020);
    _10020 = NOVALUE;
    DeRef(_10023);
    _10023 = NOVALUE;
    DeRef(_10024);
    _10024 = NOVALUE;
    return _s_17586;
L3: 
    ;
}


int _49db_allocate(int _n_18025)
{
    int _free_list_18026 = NOVALUE;
    int _size_18027 = NOVALUE;
    int _size_ptr_18028 = NOVALUE;
    int _addr_18029 = NOVALUE;
    int _free_count_18030 = NOVALUE;
    int _remaining_18031 = NOVALUE;
    int _seek_1__tmp_at4_18034 = NOVALUE;
    int _seek_inlined_seek_at_4_18033 = NOVALUE;
    int _seek_1__tmp_at39_18041 = NOVALUE;
    int _seek_inlined_seek_at_39_18040 = NOVALUE;
    int _seek_1__tmp_at111_18058 = NOVALUE;
    int _seek_inlined_seek_at_111_18057 = NOVALUE;
    int _pos_inlined_seek_at_108_18056 = NOVALUE;
    int _put4_1__tmp_at137_18063 = NOVALUE;
    int _x_inlined_put4_at_134_18062 = NOVALUE;
    int _seek_1__tmp_at167_18066 = NOVALUE;
    int _seek_inlined_seek_at_167_18065 = NOVALUE;
    int _put4_1__tmp_at193_18071 = NOVALUE;
    int _x_inlined_put4_at_190_18070 = NOVALUE;
    int _seek_1__tmp_at244_18079 = NOVALUE;
    int _seek_inlined_seek_at_244_18078 = NOVALUE;
    int _pos_inlined_seek_at_241_18077 = NOVALUE;
    int _put4_1__tmp_at266_18083 = NOVALUE;
    int _x_inlined_put4_at_263_18082 = NOVALUE;
    int _seek_1__tmp_at333_18094 = NOVALUE;
    int _seek_inlined_seek_at_333_18093 = NOVALUE;
    int _pos_inlined_seek_at_330_18092 = NOVALUE;
    int _seek_1__tmp_at364_18098 = NOVALUE;
    int _seek_inlined_seek_at_364_18097 = NOVALUE;
    int _put4_1__tmp_at386_18102 = NOVALUE;
    int _x_inlined_put4_at_383_18101 = NOVALUE;
    int _seek_1__tmp_at423_18107 = NOVALUE;
    int _seek_inlined_seek_at_423_18106 = NOVALUE;
    int _pos_inlined_seek_at_420_18105 = NOVALUE;
    int _put4_1__tmp_at438_18109 = NOVALUE;
    int _seek_1__tmp_at490_18113 = NOVALUE;
    int _seek_inlined_seek_at_490_18112 = NOVALUE;
    int _put4_1__tmp_at512_18117 = NOVALUE;
    int _x_inlined_put4_at_509_18116 = NOVALUE;
    int _where_inlined_where_at_542_18119 = NOVALUE;
    int _10246 = NOVALUE;
    int _10244 = NOVALUE;
    int _10243 = NOVALUE;
    int _10242 = NOVALUE;
    int _10241 = NOVALUE;
    int _10240 = NOVALUE;
    int _10238 = NOVALUE;
    int _10237 = NOVALUE;
    int _10236 = NOVALUE;
    int _10235 = NOVALUE;
    int _10233 = NOVALUE;
    int _10232 = NOVALUE;
    int _10231 = NOVALUE;
    int _10230 = NOVALUE;
    int _10229 = NOVALUE;
    int _10228 = NOVALUE;
    int _10227 = NOVALUE;
    int _10225 = NOVALUE;
    int _10223 = NOVALUE;
    int _10220 = NOVALUE;
    int _0, _1, _2;
    

    /** 	io:seek(current_db, FREE_COUNT)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at4_18034);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _49current_db_17372;
    ((int *)_2)[2] = 7;
    _seek_1__tmp_at4_18034 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_4_18033 = machine(19, _seek_1__tmp_at4_18034);
    DeRefi(_seek_1__tmp_at4_18034);
    _seek_1__tmp_at4_18034 = NOVALUE;

    /** 	free_count = get4()*/
    _free_count_18030 = _49get4();
    if (!IS_ATOM_INT(_free_count_18030)) {
        _1 = (long)(DBL_PTR(_free_count_18030)->dbl);
        DeRefDS(_free_count_18030);
        _free_count_18030 = _1;
    }

    /** 	if free_count > 0 then*/
    if (_free_count_18030 <= 0)
    goto L1; // [27] 487

    /** 		free_list = get4()*/
    _0 = _free_list_18026;
    _free_list_18026 = _49get4();
    DeRef(_0);

    /** 		io:seek(current_db, free_list)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_free_list_18026);
    DeRef(_seek_1__tmp_at39_18041);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _49current_db_17372;
    ((int *)_2)[2] = _free_list_18026;
    _seek_1__tmp_at39_18041 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_39_18040 = machine(19, _seek_1__tmp_at39_18041);
    DeRef(_seek_1__tmp_at39_18041);
    _seek_1__tmp_at39_18041 = NOVALUE;

    /** 		size_ptr = free_list + 4*/
    DeRef(_size_ptr_18028);
    if (IS_ATOM_INT(_free_list_18026)) {
        _size_ptr_18028 = _free_list_18026 + 4;
        if ((long)((unsigned long)_size_ptr_18028 + (unsigned long)HIGH_BITS) >= 0) 
        _size_ptr_18028 = NewDouble((double)_size_ptr_18028);
    }
    else {
        _size_ptr_18028 = NewDouble(DBL_PTR(_free_list_18026)->dbl + (double)4);
    }

    /** 		for i = 1 to free_count do*/
    _10220 = _free_count_18030;
    {
        int _i_18044;
        _i_18044 = 1;
L2: 
        if (_i_18044 > _10220){
            goto L3; // [64] 486
        }

        /** 			addr = get4()*/
        _0 = _addr_18029;
        _addr_18029 = _49get4();
        DeRef(_0);

        /** 			size = get4()*/
        _0 = _size_18027;
        _size_18027 = _49get4();
        DeRef(_0);

        /** 			if size >= n+4 then*/
        if (IS_ATOM_INT(_n_18025)) {
            _10223 = _n_18025 + 4;
            if ((long)((unsigned long)_10223 + (unsigned long)HIGH_BITS) >= 0) 
            _10223 = NewDouble((double)_10223);
        }
        else {
            _10223 = NewDouble(DBL_PTR(_n_18025)->dbl + (double)4);
        }
        if (binary_op_a(LESS, _size_18027, _10223)){
            DeRef(_10223);
            _10223 = NOVALUE;
            goto L4; // [87] 473
        }
        DeRef(_10223);
        _10223 = NOVALUE;

        /** 				if size >= n+16 then*/
        if (IS_ATOM_INT(_n_18025)) {
            _10225 = _n_18025 + 16;
            if ((long)((unsigned long)_10225 + (unsigned long)HIGH_BITS) >= 0) 
            _10225 = NewDouble((double)_10225);
        }
        else {
            _10225 = NewDouble(DBL_PTR(_n_18025)->dbl + (double)16);
        }
        if (binary_op_a(LESS, _size_18027, _10225)){
            DeRef(_10225);
            _10225 = NOVALUE;
            goto L5; // [97] 296
        }
        DeRef(_10225);
        _10225 = NOVALUE;

        /** 					io:seek(current_db, addr - 4)*/
        if (IS_ATOM_INT(_addr_18029)) {
            _10227 = _addr_18029 - 4;
            if ((long)((unsigned long)_10227 +(unsigned long) HIGH_BITS) >= 0){
                _10227 = NewDouble((double)_10227);
            }
        }
        else {
            _10227 = NewDouble(DBL_PTR(_addr_18029)->dbl - (double)4);
        }
        DeRef(_pos_inlined_seek_at_108_18056);
        _pos_inlined_seek_at_108_18056 = _10227;
        _10227 = NOVALUE;

        /** 	return machine_func(M_SEEK, {fn, pos})*/
        Ref(_pos_inlined_seek_at_108_18056);
        DeRef(_seek_1__tmp_at111_18058);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _49current_db_17372;
        ((int *)_2)[2] = _pos_inlined_seek_at_108_18056;
        _seek_1__tmp_at111_18058 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_111_18057 = machine(19, _seek_1__tmp_at111_18058);
        DeRef(_pos_inlined_seek_at_108_18056);
        _pos_inlined_seek_at_108_18056 = NOVALUE;
        DeRef(_seek_1__tmp_at111_18058);
        _seek_1__tmp_at111_18058 = NOVALUE;

        /** 					put4(size-n-4) -- shrink the block*/
        if (IS_ATOM_INT(_size_18027) && IS_ATOM_INT(_n_18025)) {
            _10228 = _size_18027 - _n_18025;
            if ((long)((unsigned long)_10228 +(unsigned long) HIGH_BITS) >= 0){
                _10228 = NewDouble((double)_10228);
            }
        }
        else {
            if (IS_ATOM_INT(_size_18027)) {
                _10228 = NewDouble((double)_size_18027 - DBL_PTR(_n_18025)->dbl);
            }
            else {
                if (IS_ATOM_INT(_n_18025)) {
                    _10228 = NewDouble(DBL_PTR(_size_18027)->dbl - (double)_n_18025);
                }
                else
                _10228 = NewDouble(DBL_PTR(_size_18027)->dbl - DBL_PTR(_n_18025)->dbl);
            }
        }
        if (IS_ATOM_INT(_10228)) {
            _10229 = _10228 - 4;
            if ((long)((unsigned long)_10229 +(unsigned long) HIGH_BITS) >= 0){
                _10229 = NewDouble((double)_10229);
            }
        }
        else {
            _10229 = NewDouble(DBL_PTR(_10228)->dbl - (double)4);
        }
        DeRef(_10228);
        _10228 = NOVALUE;
        DeRef(_x_inlined_put4_at_134_18062);
        _x_inlined_put4_at_134_18062 = _10229;
        _10229 = NOVALUE;

        /** 	poke4(mem0, x) -- faster than doing divides etc.*/
        if (IS_ATOM_INT(_49mem0_17414)){
            poke4_addr = (unsigned long *)_49mem0_17414;
        }
        else {
            poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_49mem0_17414)->dbl);
        }
        if (IS_ATOM_INT(_x_inlined_put4_at_134_18062)) {
            *poke4_addr = (unsigned long)_x_inlined_put4_at_134_18062;
        }
        else {
            *poke4_addr = (unsigned long)DBL_PTR(_x_inlined_put4_at_134_18062)->dbl;
        }

        /** 	puts(current_db, peek(memseq))*/
        DeRefi(_put4_1__tmp_at137_18063);
        _1 = (int)SEQ_PTR(_49memseq_17649);
        poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        poke4_addr = (unsigned long *)NewS1(_2);
        _put4_1__tmp_at137_18063 = MAKE_SEQ(poke4_addr);
        poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
        while (--_2 >= 0) {
            poke4_addr++;
            _1 = (int)(unsigned char)*poke_addr++;
            *(int *)poke4_addr = _1;
        }
        EPuts(_49current_db_17372, _put4_1__tmp_at137_18063); // DJP 

        /** end procedure*/
        goto L6; // [159] 162
L6: 
        DeRef(_x_inlined_put4_at_134_18062);
        _x_inlined_put4_at_134_18062 = NOVALUE;
        DeRefi(_put4_1__tmp_at137_18063);
        _put4_1__tmp_at137_18063 = NOVALUE;

        /** 					io:seek(current_db, size_ptr)*/

        /** 	return machine_func(M_SEEK, {fn, pos})*/
        Ref(_size_ptr_18028);
        DeRef(_seek_1__tmp_at167_18066);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _49current_db_17372;
        ((int *)_2)[2] = _size_ptr_18028;
        _seek_1__tmp_at167_18066 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_167_18065 = machine(19, _seek_1__tmp_at167_18066);
        DeRef(_seek_1__tmp_at167_18066);
        _seek_1__tmp_at167_18066 = NOVALUE;

        /** 					put4(size-n-4) -- update size on free list too*/
        if (IS_ATOM_INT(_size_18027) && IS_ATOM_INT(_n_18025)) {
            _10230 = _size_18027 - _n_18025;
            if ((long)((unsigned long)_10230 +(unsigned long) HIGH_BITS) >= 0){
                _10230 = NewDouble((double)_10230);
            }
        }
        else {
            if (IS_ATOM_INT(_size_18027)) {
                _10230 = NewDouble((double)_size_18027 - DBL_PTR(_n_18025)->dbl);
            }
            else {
                if (IS_ATOM_INT(_n_18025)) {
                    _10230 = NewDouble(DBL_PTR(_size_18027)->dbl - (double)_n_18025);
                }
                else
                _10230 = NewDouble(DBL_PTR(_size_18027)->dbl - DBL_PTR(_n_18025)->dbl);
            }
        }
        if (IS_ATOM_INT(_10230)) {
            _10231 = _10230 - 4;
            if ((long)((unsigned long)_10231 +(unsigned long) HIGH_BITS) >= 0){
                _10231 = NewDouble((double)_10231);
            }
        }
        else {
            _10231 = NewDouble(DBL_PTR(_10230)->dbl - (double)4);
        }
        DeRef(_10230);
        _10230 = NOVALUE;
        DeRef(_x_inlined_put4_at_190_18070);
        _x_inlined_put4_at_190_18070 = _10231;
        _10231 = NOVALUE;

        /** 	poke4(mem0, x) -- faster than doing divides etc.*/
        if (IS_ATOM_INT(_49mem0_17414)){
            poke4_addr = (unsigned long *)_49mem0_17414;
        }
        else {
            poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_49mem0_17414)->dbl);
        }
        if (IS_ATOM_INT(_x_inlined_put4_at_190_18070)) {
            *poke4_addr = (unsigned long)_x_inlined_put4_at_190_18070;
        }
        else {
            *poke4_addr = (unsigned long)DBL_PTR(_x_inlined_put4_at_190_18070)->dbl;
        }

        /** 	puts(current_db, peek(memseq))*/
        DeRefi(_put4_1__tmp_at193_18071);
        _1 = (int)SEQ_PTR(_49memseq_17649);
        poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        poke4_addr = (unsigned long *)NewS1(_2);
        _put4_1__tmp_at193_18071 = MAKE_SEQ(poke4_addr);
        poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
        while (--_2 >= 0) {
            poke4_addr++;
            _1 = (int)(unsigned char)*poke_addr++;
            *(int *)poke4_addr = _1;
        }
        EPuts(_49current_db_17372, _put4_1__tmp_at193_18071); // DJP 

        /** end procedure*/
        goto L7; // [215] 218
L7: 
        DeRef(_x_inlined_put4_at_190_18070);
        _x_inlined_put4_at_190_18070 = NOVALUE;
        DeRefi(_put4_1__tmp_at193_18071);
        _put4_1__tmp_at193_18071 = NOVALUE;

        /** 					addr += size-n-4*/
        if (IS_ATOM_INT(_size_18027) && IS_ATOM_INT(_n_18025)) {
            _10232 = _size_18027 - _n_18025;
            if ((long)((unsigned long)_10232 +(unsigned long) HIGH_BITS) >= 0){
                _10232 = NewDouble((double)_10232);
            }
        }
        else {
            if (IS_ATOM_INT(_size_18027)) {
                _10232 = NewDouble((double)_size_18027 - DBL_PTR(_n_18025)->dbl);
            }
            else {
                if (IS_ATOM_INT(_n_18025)) {
                    _10232 = NewDouble(DBL_PTR(_size_18027)->dbl - (double)_n_18025);
                }
                else
                _10232 = NewDouble(DBL_PTR(_size_18027)->dbl - DBL_PTR(_n_18025)->dbl);
            }
        }
        if (IS_ATOM_INT(_10232)) {
            _10233 = _10232 - 4;
            if ((long)((unsigned long)_10233 +(unsigned long) HIGH_BITS) >= 0){
                _10233 = NewDouble((double)_10233);
            }
        }
        else {
            _10233 = NewDouble(DBL_PTR(_10232)->dbl - (double)4);
        }
        DeRef(_10232);
        _10232 = NOVALUE;
        _0 = _addr_18029;
        if (IS_ATOM_INT(_addr_18029) && IS_ATOM_INT(_10233)) {
            _addr_18029 = _addr_18029 + _10233;
            if ((long)((unsigned long)_addr_18029 + (unsigned long)HIGH_BITS) >= 0) 
            _addr_18029 = NewDouble((double)_addr_18029);
        }
        else {
            if (IS_ATOM_INT(_addr_18029)) {
                _addr_18029 = NewDouble((double)_addr_18029 + DBL_PTR(_10233)->dbl);
            }
            else {
                if (IS_ATOM_INT(_10233)) {
                    _addr_18029 = NewDouble(DBL_PTR(_addr_18029)->dbl + (double)_10233);
                }
                else
                _addr_18029 = NewDouble(DBL_PTR(_addr_18029)->dbl + DBL_PTR(_10233)->dbl);
            }
        }
        DeRef(_0);
        DeRef(_10233);
        _10233 = NOVALUE;

        /** 					io:seek(current_db, addr - 4) */
        if (IS_ATOM_INT(_addr_18029)) {
            _10235 = _addr_18029 - 4;
            if ((long)((unsigned long)_10235 +(unsigned long) HIGH_BITS) >= 0){
                _10235 = NewDouble((double)_10235);
            }
        }
        else {
            _10235 = NewDouble(DBL_PTR(_addr_18029)->dbl - (double)4);
        }
        DeRef(_pos_inlined_seek_at_241_18077);
        _pos_inlined_seek_at_241_18077 = _10235;
        _10235 = NOVALUE;

        /** 	return machine_func(M_SEEK, {fn, pos})*/
        Ref(_pos_inlined_seek_at_241_18077);
        DeRef(_seek_1__tmp_at244_18079);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _49current_db_17372;
        ((int *)_2)[2] = _pos_inlined_seek_at_241_18077;
        _seek_1__tmp_at244_18079 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_244_18078 = machine(19, _seek_1__tmp_at244_18079);
        DeRef(_pos_inlined_seek_at_241_18077);
        _pos_inlined_seek_at_241_18077 = NOVALUE;
        DeRef(_seek_1__tmp_at244_18079);
        _seek_1__tmp_at244_18079 = NOVALUE;

        /** 					put4(n+4)*/
        if (IS_ATOM_INT(_n_18025)) {
            _10236 = _n_18025 + 4;
            if ((long)((unsigned long)_10236 + (unsigned long)HIGH_BITS) >= 0) 
            _10236 = NewDouble((double)_10236);
        }
        else {
            _10236 = NewDouble(DBL_PTR(_n_18025)->dbl + (double)4);
        }
        DeRef(_x_inlined_put4_at_263_18082);
        _x_inlined_put4_at_263_18082 = _10236;
        _10236 = NOVALUE;

        /** 	poke4(mem0, x) -- faster than doing divides etc.*/
        if (IS_ATOM_INT(_49mem0_17414)){
            poke4_addr = (unsigned long *)_49mem0_17414;
        }
        else {
            poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_49mem0_17414)->dbl);
        }
        if (IS_ATOM_INT(_x_inlined_put4_at_263_18082)) {
            *poke4_addr = (unsigned long)_x_inlined_put4_at_263_18082;
        }
        else {
            *poke4_addr = (unsigned long)DBL_PTR(_x_inlined_put4_at_263_18082)->dbl;
        }

        /** 	puts(current_db, peek(memseq))*/
        DeRefi(_put4_1__tmp_at266_18083);
        _1 = (int)SEQ_PTR(_49memseq_17649);
        poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        poke4_addr = (unsigned long *)NewS1(_2);
        _put4_1__tmp_at266_18083 = MAKE_SEQ(poke4_addr);
        poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
        while (--_2 >= 0) {
            poke4_addr++;
            _1 = (int)(unsigned char)*poke_addr++;
            *(int *)poke4_addr = _1;
        }
        EPuts(_49current_db_17372, _put4_1__tmp_at266_18083); // DJP 

        /** end procedure*/
        goto L8; // [288] 291
L8: 
        DeRef(_x_inlined_put4_at_263_18082);
        _x_inlined_put4_at_263_18082 = NOVALUE;
        DeRefi(_put4_1__tmp_at266_18083);
        _put4_1__tmp_at266_18083 = NOVALUE;
        goto L9; // [293] 466
L5: 

        /** 					remaining = io:get_bytes(current_db, (free_count-i) * 8)*/
        _10237 = _free_count_18030 - _i_18044;
        if ((long)((unsigned long)_10237 +(unsigned long) HIGH_BITS) >= 0){
            _10237 = NewDouble((double)_10237);
        }
        if (IS_ATOM_INT(_10237)) {
            if (_10237 == (short)_10237)
            _10238 = _10237 * 8;
            else
            _10238 = NewDouble(_10237 * (double)8);
        }
        else {
            _10238 = NewDouble(DBL_PTR(_10237)->dbl * (double)8);
        }
        DeRef(_10237);
        _10237 = NOVALUE;
        _0 = _remaining_18031;
        _remaining_18031 = _8get_bytes(_49current_db_17372, _10238);
        DeRef(_0);
        _10238 = NOVALUE;

        /** 					io:seek(current_db, free_list+8*(i-1))*/
        _10240 = _i_18044 - 1;
        if (_10240 <= INT15)
        _10241 = 8 * _10240;
        else
        _10241 = NewDouble(8 * (double)_10240);
        _10240 = NOVALUE;
        if (IS_ATOM_INT(_free_list_18026) && IS_ATOM_INT(_10241)) {
            _10242 = _free_list_18026 + _10241;
            if ((long)((unsigned long)_10242 + (unsigned long)HIGH_BITS) >= 0) 
            _10242 = NewDouble((double)_10242);
        }
        else {
            if (IS_ATOM_INT(_free_list_18026)) {
                _10242 = NewDouble((double)_free_list_18026 + DBL_PTR(_10241)->dbl);
            }
            else {
                if (IS_ATOM_INT(_10241)) {
                    _10242 = NewDouble(DBL_PTR(_free_list_18026)->dbl + (double)_10241);
                }
                else
                _10242 = NewDouble(DBL_PTR(_free_list_18026)->dbl + DBL_PTR(_10241)->dbl);
            }
        }
        DeRef(_10241);
        _10241 = NOVALUE;
        DeRef(_pos_inlined_seek_at_330_18092);
        _pos_inlined_seek_at_330_18092 = _10242;
        _10242 = NOVALUE;

        /** 	return machine_func(M_SEEK, {fn, pos})*/
        Ref(_pos_inlined_seek_at_330_18092);
        DeRef(_seek_1__tmp_at333_18094);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _49current_db_17372;
        ((int *)_2)[2] = _pos_inlined_seek_at_330_18092;
        _seek_1__tmp_at333_18094 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_333_18093 = machine(19, _seek_1__tmp_at333_18094);
        DeRef(_pos_inlined_seek_at_330_18092);
        _pos_inlined_seek_at_330_18092 = NOVALUE;
        DeRef(_seek_1__tmp_at333_18094);
        _seek_1__tmp_at333_18094 = NOVALUE;

        /** 					putn(remaining)*/

        /** 	puts(current_db, s)*/
        EPuts(_49current_db_17372, _remaining_18031); // DJP 

        /** end procedure*/
        goto LA; // [358] 361
LA: 

        /** 					io:seek(current_db, FREE_COUNT)*/

        /** 	return machine_func(M_SEEK, {fn, pos})*/
        DeRefi(_seek_1__tmp_at364_18098);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _49current_db_17372;
        ((int *)_2)[2] = 7;
        _seek_1__tmp_at364_18098 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_364_18097 = machine(19, _seek_1__tmp_at364_18098);
        DeRefi(_seek_1__tmp_at364_18098);
        _seek_1__tmp_at364_18098 = NOVALUE;

        /** 					put4(free_count-1)*/
        _10243 = _free_count_18030 - 1;
        if ((long)((unsigned long)_10243 +(unsigned long) HIGH_BITS) >= 0){
            _10243 = NewDouble((double)_10243);
        }
        DeRef(_x_inlined_put4_at_383_18101);
        _x_inlined_put4_at_383_18101 = _10243;
        _10243 = NOVALUE;

        /** 	poke4(mem0, x) -- faster than doing divides etc.*/
        if (IS_ATOM_INT(_49mem0_17414)){
            poke4_addr = (unsigned long *)_49mem0_17414;
        }
        else {
            poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_49mem0_17414)->dbl);
        }
        if (IS_ATOM_INT(_x_inlined_put4_at_383_18101)) {
            *poke4_addr = (unsigned long)_x_inlined_put4_at_383_18101;
        }
        else {
            *poke4_addr = (unsigned long)DBL_PTR(_x_inlined_put4_at_383_18101)->dbl;
        }

        /** 	puts(current_db, peek(memseq))*/
        DeRefi(_put4_1__tmp_at386_18102);
        _1 = (int)SEQ_PTR(_49memseq_17649);
        poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        poke4_addr = (unsigned long *)NewS1(_2);
        _put4_1__tmp_at386_18102 = MAKE_SEQ(poke4_addr);
        poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
        while (--_2 >= 0) {
            poke4_addr++;
            _1 = (int)(unsigned char)*poke_addr++;
            *(int *)poke4_addr = _1;
        }
        EPuts(_49current_db_17372, _put4_1__tmp_at386_18102); // DJP 

        /** end procedure*/
        goto LB; // [408] 411
LB: 
        DeRef(_x_inlined_put4_at_383_18101);
        _x_inlined_put4_at_383_18101 = NOVALUE;
        DeRefi(_put4_1__tmp_at386_18102);
        _put4_1__tmp_at386_18102 = NOVALUE;

        /** 					io:seek(current_db, addr - 4)*/
        if (IS_ATOM_INT(_addr_18029)) {
            _10244 = _addr_18029 - 4;
            if ((long)((unsigned long)_10244 +(unsigned long) HIGH_BITS) >= 0){
                _10244 = NewDouble((double)_10244);
            }
        }
        else {
            _10244 = NewDouble(DBL_PTR(_addr_18029)->dbl - (double)4);
        }
        DeRef(_pos_inlined_seek_at_420_18105);
        _pos_inlined_seek_at_420_18105 = _10244;
        _10244 = NOVALUE;

        /** 	return machine_func(M_SEEK, {fn, pos})*/
        Ref(_pos_inlined_seek_at_420_18105);
        DeRef(_seek_1__tmp_at423_18107);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _49current_db_17372;
        ((int *)_2)[2] = _pos_inlined_seek_at_420_18105;
        _seek_1__tmp_at423_18107 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_423_18106 = machine(19, _seek_1__tmp_at423_18107);
        DeRef(_pos_inlined_seek_at_420_18105);
        _pos_inlined_seek_at_420_18105 = NOVALUE;
        DeRef(_seek_1__tmp_at423_18107);
        _seek_1__tmp_at423_18107 = NOVALUE;

        /** 					put4(size) -- in case size was not updated by db_free()*/

        /** 	poke4(mem0, x) -- faster than doing divides etc.*/
        if (IS_ATOM_INT(_49mem0_17414)){
            poke4_addr = (unsigned long *)_49mem0_17414;
        }
        else {
            poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_49mem0_17414)->dbl);
        }
        if (IS_ATOM_INT(_size_18027)) {
            *poke4_addr = (unsigned long)_size_18027;
        }
        else {
            *poke4_addr = (unsigned long)DBL_PTR(_size_18027)->dbl;
        }

        /** 	puts(current_db, peek(memseq))*/
        DeRefi(_put4_1__tmp_at438_18109);
        _1 = (int)SEQ_PTR(_49memseq_17649);
        poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        poke4_addr = (unsigned long *)NewS1(_2);
        _put4_1__tmp_at438_18109 = MAKE_SEQ(poke4_addr);
        poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
        while (--_2 >= 0) {
            poke4_addr++;
            _1 = (int)(unsigned char)*poke_addr++;
            *(int *)poke4_addr = _1;
        }
        EPuts(_49current_db_17372, _put4_1__tmp_at438_18109); // DJP 

        /** end procedure*/
        goto LC; // [460] 463
LC: 
        DeRefi(_put4_1__tmp_at438_18109);
        _put4_1__tmp_at438_18109 = NOVALUE;
L9: 

        /** 				return addr*/
        DeRef(_n_18025);
        DeRef(_free_list_18026);
        DeRef(_size_18027);
        DeRef(_size_ptr_18028);
        DeRef(_remaining_18031);
        return _addr_18029;
L4: 

        /** 			size_ptr += 8*/
        _0 = _size_ptr_18028;
        if (IS_ATOM_INT(_size_ptr_18028)) {
            _size_ptr_18028 = _size_ptr_18028 + 8;
            if ((long)((unsigned long)_size_ptr_18028 + (unsigned long)HIGH_BITS) >= 0) 
            _size_ptr_18028 = NewDouble((double)_size_ptr_18028);
        }
        else {
            _size_ptr_18028 = NewDouble(DBL_PTR(_size_ptr_18028)->dbl + (double)8);
        }
        DeRef(_0);

        /** 		end for*/
        _i_18044 = _i_18044 + 1;
        goto L2; // [481] 71
L3: 
        ;
    }
L1: 

    /** 	io:seek(current_db, -1)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at490_18113);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _49current_db_17372;
    ((int *)_2)[2] = -1;
    _seek_1__tmp_at490_18113 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_490_18112 = machine(19, _seek_1__tmp_at490_18113);
    DeRefi(_seek_1__tmp_at490_18113);
    _seek_1__tmp_at490_18113 = NOVALUE;

    /** 	put4(n+4)*/
    if (IS_ATOM_INT(_n_18025)) {
        _10246 = _n_18025 + 4;
        if ((long)((unsigned long)_10246 + (unsigned long)HIGH_BITS) >= 0) 
        _10246 = NewDouble((double)_10246);
    }
    else {
        _10246 = NewDouble(DBL_PTR(_n_18025)->dbl + (double)4);
    }
    DeRef(_x_inlined_put4_at_509_18116);
    _x_inlined_put4_at_509_18116 = _10246;
    _10246 = NOVALUE;

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_49mem0_17414)){
        poke4_addr = (unsigned long *)_49mem0_17414;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_49mem0_17414)->dbl);
    }
    if (IS_ATOM_INT(_x_inlined_put4_at_509_18116)) {
        *poke4_addr = (unsigned long)_x_inlined_put4_at_509_18116;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_x_inlined_put4_at_509_18116)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at512_18117);
    _1 = (int)SEQ_PTR(_49memseq_17649);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at512_18117 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_49current_db_17372, _put4_1__tmp_at512_18117); // DJP 

    /** end procedure*/
    goto LD; // [534] 537
LD: 
    DeRef(_x_inlined_put4_at_509_18116);
    _x_inlined_put4_at_509_18116 = NOVALUE;
    DeRefi(_put4_1__tmp_at512_18117);
    _put4_1__tmp_at512_18117 = NOVALUE;

    /** 	return io:where(current_db)*/

    /** 	return machine_func(M_WHERE, fn)*/
    DeRef(_where_inlined_where_at_542_18119);
    _where_inlined_where_at_542_18119 = machine(20, _49current_db_17372);
    DeRef(_n_18025);
    DeRef(_free_list_18026);
    DeRef(_size_18027);
    DeRef(_size_ptr_18028);
    DeRef(_addr_18029);
    DeRef(_remaining_18031);
    return _where_inlined_where_at_542_18119;
    ;
}


void _49db_free(int _p_18122)
{
    int _psize_18123 = NOVALUE;
    int _i_18124 = NOVALUE;
    int _size_18125 = NOVALUE;
    int _addr_18126 = NOVALUE;
    int _free_list_18127 = NOVALUE;
    int _free_list_space_18128 = NOVALUE;
    int _new_space_18129 = NOVALUE;
    int _to_be_freed_18130 = NOVALUE;
    int _prev_addr_18131 = NOVALUE;
    int _prev_size_18132 = NOVALUE;
    int _free_count_18133 = NOVALUE;
    int _remaining_18134 = NOVALUE;
    int _seek_1__tmp_at11_18139 = NOVALUE;
    int _seek_inlined_seek_at_11_18138 = NOVALUE;
    int _pos_inlined_seek_at_8_18137 = NOVALUE;
    int _seek_1__tmp_at33_18143 = NOVALUE;
    int _seek_inlined_seek_at_33_18142 = NOVALUE;
    int _seek_1__tmp_at69_18150 = NOVALUE;
    int _seek_inlined_seek_at_69_18149 = NOVALUE;
    int _pos_inlined_seek_at_66_18148 = NOVALUE;
    int _seek_1__tmp_at133_18163 = NOVALUE;
    int _seek_inlined_seek_at_133_18162 = NOVALUE;
    int _seek_1__tmp_at157_18167 = NOVALUE;
    int _seek_inlined_seek_at_157_18166 = NOVALUE;
    int _put4_1__tmp_at172_18169 = NOVALUE;
    int _seek_1__tmp_at202_18172 = NOVALUE;
    int _seek_inlined_seek_at_202_18171 = NOVALUE;
    int _seek_1__tmp_at234_18177 = NOVALUE;
    int _seek_inlined_seek_at_234_18176 = NOVALUE;
    int _s_inlined_putn_at_274_18183 = NOVALUE;
    int _seek_1__tmp_at297_18186 = NOVALUE;
    int _seek_inlined_seek_at_297_18185 = NOVALUE;
    int _seek_1__tmp_at430_18207 = NOVALUE;
    int _seek_inlined_seek_at_430_18206 = NOVALUE;
    int _pos_inlined_seek_at_427_18205 = NOVALUE;
    int _put4_1__tmp_at482_18217 = NOVALUE;
    int _x_inlined_put4_at_479_18216 = NOVALUE;
    int _seek_1__tmp_at523_18223 = NOVALUE;
    int _seek_inlined_seek_at_523_18222 = NOVALUE;
    int _pos_inlined_seek_at_520_18221 = NOVALUE;
    int _seek_1__tmp_at574_18233 = NOVALUE;
    int _seek_inlined_seek_at_574_18232 = NOVALUE;
    int _pos_inlined_seek_at_571_18231 = NOVALUE;
    int _seek_1__tmp_at611_18238 = NOVALUE;
    int _seek_inlined_seek_at_611_18237 = NOVALUE;
    int _put4_1__tmp_at626_18240 = NOVALUE;
    int _put4_1__tmp_at664_18245 = NOVALUE;
    int _x_inlined_put4_at_661_18244 = NOVALUE;
    int _seek_1__tmp_at737_18257 = NOVALUE;
    int _seek_inlined_seek_at_737_18256 = NOVALUE;
    int _pos_inlined_seek_at_734_18255 = NOVALUE;
    int _put4_1__tmp_at752_18259 = NOVALUE;
    int _put4_1__tmp_at789_18263 = NOVALUE;
    int _x_inlined_put4_at_786_18262 = NOVALUE;
    int _seek_1__tmp_at837_18271 = NOVALUE;
    int _seek_inlined_seek_at_837_18270 = NOVALUE;
    int _pos_inlined_seek_at_834_18269 = NOVALUE;
    int _seek_1__tmp_at883_18279 = NOVALUE;
    int _seek_inlined_seek_at_883_18278 = NOVALUE;
    int _put4_1__tmp_at898_18281 = NOVALUE;
    int _seek_1__tmp_at943_18288 = NOVALUE;
    int _seek_inlined_seek_at_943_18287 = NOVALUE;
    int _pos_inlined_seek_at_940_18286 = NOVALUE;
    int _put4_1__tmp_at958_18290 = NOVALUE;
    int _put4_1__tmp_at986_18292 = NOVALUE;
    int _10314 = NOVALUE;
    int _10313 = NOVALUE;
    int _10312 = NOVALUE;
    int _10309 = NOVALUE;
    int _10308 = NOVALUE;
    int _10307 = NOVALUE;
    int _10306 = NOVALUE;
    int _10305 = NOVALUE;
    int _10304 = NOVALUE;
    int _10303 = NOVALUE;
    int _10302 = NOVALUE;
    int _10301 = NOVALUE;
    int _10300 = NOVALUE;
    int _10299 = NOVALUE;
    int _10298 = NOVALUE;
    int _10297 = NOVALUE;
    int _10296 = NOVALUE;
    int _10295 = NOVALUE;
    int _10293 = NOVALUE;
    int _10292 = NOVALUE;
    int _10291 = NOVALUE;
    int _10289 = NOVALUE;
    int _10288 = NOVALUE;
    int _10287 = NOVALUE;
    int _10286 = NOVALUE;
    int _10285 = NOVALUE;
    int _10284 = NOVALUE;
    int _10283 = NOVALUE;
    int _10282 = NOVALUE;
    int _10281 = NOVALUE;
    int _10280 = NOVALUE;
    int _10279 = NOVALUE;
    int _10278 = NOVALUE;
    int _10277 = NOVALUE;
    int _10276 = NOVALUE;
    int _10275 = NOVALUE;
    int _10274 = NOVALUE;
    int _10273 = NOVALUE;
    int _10272 = NOVALUE;
    int _10266 = NOVALUE;
    int _10265 = NOVALUE;
    int _10264 = NOVALUE;
    int _10262 = NOVALUE;
    int _10258 = NOVALUE;
    int _10257 = NOVALUE;
    int _10255 = NOVALUE;
    int _10254 = NOVALUE;
    int _10252 = NOVALUE;
    int _10251 = NOVALUE;
    int _10247 = NOVALUE;
    int _0, _1, _2;
    

    /** 	io:seek(current_db, p-4)*/
    if (IS_ATOM_INT(_p_18122)) {
        _10247 = _p_18122 - 4;
        if ((long)((unsigned long)_10247 +(unsigned long) HIGH_BITS) >= 0){
            _10247 = NewDouble((double)_10247);
        }
    }
    else {
        _10247 = NewDouble(DBL_PTR(_p_18122)->dbl - (double)4);
    }
    DeRef(_pos_inlined_seek_at_8_18137);
    _pos_inlined_seek_at_8_18137 = _10247;
    _10247 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_8_18137);
    DeRef(_seek_1__tmp_at11_18139);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _49current_db_17372;
    ((int *)_2)[2] = _pos_inlined_seek_at_8_18137;
    _seek_1__tmp_at11_18139 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_11_18138 = machine(19, _seek_1__tmp_at11_18139);
    DeRef(_pos_inlined_seek_at_8_18137);
    _pos_inlined_seek_at_8_18137 = NOVALUE;
    DeRef(_seek_1__tmp_at11_18139);
    _seek_1__tmp_at11_18139 = NOVALUE;

    /** 	psize = get4()*/
    _0 = _psize_18123;
    _psize_18123 = _49get4();
    DeRef(_0);

    /** 	io:seek(current_db, FREE_COUNT)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at33_18143);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _49current_db_17372;
    ((int *)_2)[2] = 7;
    _seek_1__tmp_at33_18143 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_33_18142 = machine(19, _seek_1__tmp_at33_18143);
    DeRefi(_seek_1__tmp_at33_18143);
    _seek_1__tmp_at33_18143 = NOVALUE;

    /** 	free_count = get4()*/
    _free_count_18133 = _49get4();
    if (!IS_ATOM_INT(_free_count_18133)) {
        _1 = (long)(DBL_PTR(_free_count_18133)->dbl);
        DeRefDS(_free_count_18133);
        _free_count_18133 = _1;
    }

    /** 	free_list = get4()*/
    _0 = _free_list_18127;
    _free_list_18127 = _49get4();
    DeRef(_0);

    /** 	io:seek(current_db, free_list - 4)*/
    if (IS_ATOM_INT(_free_list_18127)) {
        _10251 = _free_list_18127 - 4;
        if ((long)((unsigned long)_10251 +(unsigned long) HIGH_BITS) >= 0){
            _10251 = NewDouble((double)_10251);
        }
    }
    else {
        _10251 = NewDouble(DBL_PTR(_free_list_18127)->dbl - (double)4);
    }
    DeRef(_pos_inlined_seek_at_66_18148);
    _pos_inlined_seek_at_66_18148 = _10251;
    _10251 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_66_18148);
    DeRef(_seek_1__tmp_at69_18150);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _49current_db_17372;
    ((int *)_2)[2] = _pos_inlined_seek_at_66_18148;
    _seek_1__tmp_at69_18150 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_69_18149 = machine(19, _seek_1__tmp_at69_18150);
    DeRef(_pos_inlined_seek_at_66_18148);
    _pos_inlined_seek_at_66_18148 = NOVALUE;
    DeRef(_seek_1__tmp_at69_18150);
    _seek_1__tmp_at69_18150 = NOVALUE;

    /** 	free_list_space = get4()-4*/
    _10252 = _49get4();
    DeRef(_free_list_space_18128);
    if (IS_ATOM_INT(_10252)) {
        _free_list_space_18128 = _10252 - 4;
        if ((long)((unsigned long)_free_list_space_18128 +(unsigned long) HIGH_BITS) >= 0){
            _free_list_space_18128 = NewDouble((double)_free_list_space_18128);
        }
    }
    else {
        _free_list_space_18128 = binary_op(MINUS, _10252, 4);
    }
    DeRef(_10252);
    _10252 = NOVALUE;

    /** 	if free_list_space < 8 * (free_count+1) then*/
    _10254 = _free_count_18133 + 1;
    if (_10254 > MAXINT){
        _10254 = NewDouble((double)_10254);
    }
    if (IS_ATOM_INT(_10254)) {
        if (_10254 <= INT15 && _10254 >= -INT15)
        _10255 = 8 * _10254;
        else
        _10255 = NewDouble(8 * (double)_10254);
    }
    else {
        _10255 = NewDouble((double)8 * DBL_PTR(_10254)->dbl);
    }
    DeRef(_10254);
    _10254 = NOVALUE;
    if (binary_op_a(GREATEREQ, _free_list_space_18128, _10255)){
        DeRef(_10255);
        _10255 = NOVALUE;
        goto L1; // [102] 314
    }
    DeRef(_10255);
    _10255 = NOVALUE;

    /** 		new_space = floor(free_list_space + free_list_space / 2)*/
    if (IS_ATOM_INT(_free_list_space_18128)) {
        if (_free_list_space_18128 & 1) {
            _10257 = NewDouble((_free_list_space_18128 >> 1) + 0.5);
        }
        else
        _10257 = _free_list_space_18128 >> 1;
    }
    else {
        _10257 = binary_op(DIVIDE, _free_list_space_18128, 2);
    }
    if (IS_ATOM_INT(_free_list_space_18128) && IS_ATOM_INT(_10257)) {
        _10258 = _free_list_space_18128 + _10257;
        if ((long)((unsigned long)_10258 + (unsigned long)HIGH_BITS) >= 0) 
        _10258 = NewDouble((double)_10258);
    }
    else {
        if (IS_ATOM_INT(_free_list_space_18128)) {
            _10258 = NewDouble((double)_free_list_space_18128 + DBL_PTR(_10257)->dbl);
        }
        else {
            if (IS_ATOM_INT(_10257)) {
                _10258 = NewDouble(DBL_PTR(_free_list_space_18128)->dbl + (double)_10257);
            }
            else
            _10258 = NewDouble(DBL_PTR(_free_list_space_18128)->dbl + DBL_PTR(_10257)->dbl);
        }
    }
    DeRef(_10257);
    _10257 = NOVALUE;
    DeRef(_new_space_18129);
    if (IS_ATOM_INT(_10258))
    _new_space_18129 = e_floor(_10258);
    else
    _new_space_18129 = unary_op(FLOOR, _10258);
    DeRef(_10258);
    _10258 = NOVALUE;

    /** 		to_be_freed = free_list*/
    Ref(_free_list_18127);
    DeRef(_to_be_freed_18130);
    _to_be_freed_18130 = _free_list_18127;

    /** 		free_list = db_allocate(new_space)*/
    Ref(_new_space_18129);
    _0 = _free_list_18127;
    _free_list_18127 = _49db_allocate(_new_space_18129);
    DeRef(_0);

    /** 		io:seek(current_db, FREE_COUNT)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at133_18163);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _49current_db_17372;
    ((int *)_2)[2] = 7;
    _seek_1__tmp_at133_18163 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_133_18162 = machine(19, _seek_1__tmp_at133_18163);
    DeRefi(_seek_1__tmp_at133_18163);
    _seek_1__tmp_at133_18163 = NOVALUE;

    /** 		free_count = get4() -- db_allocate may have changed it*/
    _free_count_18133 = _49get4();
    if (!IS_ATOM_INT(_free_count_18133)) {
        _1 = (long)(DBL_PTR(_free_count_18133)->dbl);
        DeRefDS(_free_count_18133);
        _free_count_18133 = _1;
    }

    /** 		io:seek(current_db, FREE_LIST)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at157_18167);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _49current_db_17372;
    ((int *)_2)[2] = 11;
    _seek_1__tmp_at157_18167 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_157_18166 = machine(19, _seek_1__tmp_at157_18167);
    DeRefi(_seek_1__tmp_at157_18167);
    _seek_1__tmp_at157_18167 = NOVALUE;

    /** 		put4(free_list)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_49mem0_17414)){
        poke4_addr = (unsigned long *)_49mem0_17414;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_49mem0_17414)->dbl);
    }
    if (IS_ATOM_INT(_free_list_18127)) {
        *poke4_addr = (unsigned long)_free_list_18127;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_free_list_18127)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at172_18169);
    _1 = (int)SEQ_PTR(_49memseq_17649);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at172_18169 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_49current_db_17372, _put4_1__tmp_at172_18169); // DJP 

    /** end procedure*/
    goto L2; // [194] 197
L2: 
    DeRefi(_put4_1__tmp_at172_18169);
    _put4_1__tmp_at172_18169 = NOVALUE;

    /** 		io:seek(current_db, to_be_freed)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_to_be_freed_18130);
    DeRef(_seek_1__tmp_at202_18172);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _49current_db_17372;
    ((int *)_2)[2] = _to_be_freed_18130;
    _seek_1__tmp_at202_18172 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_202_18171 = machine(19, _seek_1__tmp_at202_18172);
    DeRef(_seek_1__tmp_at202_18172);
    _seek_1__tmp_at202_18172 = NOVALUE;

    /** 		remaining = io:get_bytes(current_db, 8*free_count)*/
    if (_free_count_18133 <= INT15 && _free_count_18133 >= -INT15)
    _10262 = 8 * _free_count_18133;
    else
    _10262 = NewDouble(8 * (double)_free_count_18133);
    _0 = _remaining_18134;
    _remaining_18134 = _8get_bytes(_49current_db_17372, _10262);
    DeRef(_0);
    _10262 = NOVALUE;

    /** 		io:seek(current_db, free_list)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_free_list_18127);
    DeRef(_seek_1__tmp_at234_18177);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _49current_db_17372;
    ((int *)_2)[2] = _free_list_18127;
    _seek_1__tmp_at234_18177 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_234_18176 = machine(19, _seek_1__tmp_at234_18177);
    DeRef(_seek_1__tmp_at234_18177);
    _seek_1__tmp_at234_18177 = NOVALUE;

    /** 		putn(remaining)*/

    /** 	puts(current_db, s)*/
    EPuts(_49current_db_17372, _remaining_18134); // DJP 

    /** end procedure*/
    goto L3; // [259] 262
L3: 

    /** 		putn(repeat(0, new_space-length(remaining)))*/
    if (IS_SEQUENCE(_remaining_18134)){
            _10264 = SEQ_PTR(_remaining_18134)->length;
    }
    else {
        _10264 = 1;
    }
    if (IS_ATOM_INT(_new_space_18129)) {
        _10265 = _new_space_18129 - _10264;
    }
    else {
        _10265 = NewDouble(DBL_PTR(_new_space_18129)->dbl - (double)_10264);
    }
    _10264 = NOVALUE;
    _10266 = Repeat(0, _10265);
    DeRef(_10265);
    _10265 = NOVALUE;
    DeRefi(_s_inlined_putn_at_274_18183);
    _s_inlined_putn_at_274_18183 = _10266;
    _10266 = NOVALUE;

    /** 	puts(current_db, s)*/
    EPuts(_49current_db_17372, _s_inlined_putn_at_274_18183); // DJP 

    /** end procedure*/
    goto L4; // [289] 292
L4: 
    DeRefi(_s_inlined_putn_at_274_18183);
    _s_inlined_putn_at_274_18183 = NOVALUE;

    /** 		io:seek(current_db, free_list)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_free_list_18127);
    DeRef(_seek_1__tmp_at297_18186);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _49current_db_17372;
    ((int *)_2)[2] = _free_list_18127;
    _seek_1__tmp_at297_18186 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_297_18185 = machine(19, _seek_1__tmp_at297_18186);
    DeRef(_seek_1__tmp_at297_18186);
    _seek_1__tmp_at297_18186 = NOVALUE;
    goto L5; // [311] 320
L1: 

    /** 		new_space = 0*/
    DeRef(_new_space_18129);
    _new_space_18129 = 0;
L5: 

    /** 	i = 1*/
    DeRef(_i_18124);
    _i_18124 = 1;

    /** 	prev_addr = 0*/
    DeRef(_prev_addr_18131);
    _prev_addr_18131 = 0;

    /** 	prev_size = 0*/
    DeRef(_prev_size_18132);
    _prev_size_18132 = 0;

    /** 	while i <= free_count do*/
L6: 
    if (binary_op_a(GREATER, _i_18124, _free_count_18133)){
        goto L7; // [340] 386
    }

    /** 		addr = get4()*/
    _0 = _addr_18126;
    _addr_18126 = _49get4();
    DeRef(_0);

    /** 		size = get4()*/
    _0 = _size_18125;
    _size_18125 = _49get4();
    DeRef(_0);

    /** 		if p < addr then*/
    if (binary_op_a(GREATEREQ, _p_18122, _addr_18126)){
        goto L8; // [356] 365
    }

    /** 			exit*/
    goto L7; // [362] 386
L8: 

    /** 		prev_addr = addr*/
    Ref(_addr_18126);
    DeRef(_prev_addr_18131);
    _prev_addr_18131 = _addr_18126;

    /** 		prev_size = size*/
    Ref(_size_18125);
    DeRef(_prev_size_18132);
    _prev_size_18132 = _size_18125;

    /** 		i += 1*/
    _0 = _i_18124;
    if (IS_ATOM_INT(_i_18124)) {
        _i_18124 = _i_18124 + 1;
        if (_i_18124 > MAXINT){
            _i_18124 = NewDouble((double)_i_18124);
        }
    }
    else
    _i_18124 = binary_op(PLUS, 1, _i_18124);
    DeRef(_0);

    /** 	end while*/
    goto L6; // [383] 340
L7: 

    /** 	if i > 1 and prev_addr + prev_size = p then*/
    if (IS_ATOM_INT(_i_18124)) {
        _10272 = (_i_18124 > 1);
    }
    else {
        _10272 = (DBL_PTR(_i_18124)->dbl > (double)1);
    }
    if (_10272 == 0) {
        goto L9; // [392] 695
    }
    if (IS_ATOM_INT(_prev_addr_18131) && IS_ATOM_INT(_prev_size_18132)) {
        _10274 = _prev_addr_18131 + _prev_size_18132;
        if ((long)((unsigned long)_10274 + (unsigned long)HIGH_BITS) >= 0) 
        _10274 = NewDouble((double)_10274);
    }
    else {
        if (IS_ATOM_INT(_prev_addr_18131)) {
            _10274 = NewDouble((double)_prev_addr_18131 + DBL_PTR(_prev_size_18132)->dbl);
        }
        else {
            if (IS_ATOM_INT(_prev_size_18132)) {
                _10274 = NewDouble(DBL_PTR(_prev_addr_18131)->dbl + (double)_prev_size_18132);
            }
            else
            _10274 = NewDouble(DBL_PTR(_prev_addr_18131)->dbl + DBL_PTR(_prev_size_18132)->dbl);
        }
    }
    if (IS_ATOM_INT(_10274) && IS_ATOM_INT(_p_18122)) {
        _10275 = (_10274 == _p_18122);
    }
    else {
        if (IS_ATOM_INT(_10274)) {
            _10275 = ((double)_10274 == DBL_PTR(_p_18122)->dbl);
        }
        else {
            if (IS_ATOM_INT(_p_18122)) {
                _10275 = (DBL_PTR(_10274)->dbl == (double)_p_18122);
            }
            else
            _10275 = (DBL_PTR(_10274)->dbl == DBL_PTR(_p_18122)->dbl);
        }
    }
    DeRef(_10274);
    _10274 = NOVALUE;
    if (_10275 == 0)
    {
        DeRef(_10275);
        _10275 = NOVALUE;
        goto L9; // [405] 695
    }
    else{
        DeRef(_10275);
        _10275 = NOVALUE;
    }

    /** 		io:seek(current_db, free_list+(i-2)*8+4)*/
    if (IS_ATOM_INT(_i_18124)) {
        _10276 = _i_18124 - 2;
        if ((long)((unsigned long)_10276 +(unsigned long) HIGH_BITS) >= 0){
            _10276 = NewDouble((double)_10276);
        }
    }
    else {
        _10276 = NewDouble(DBL_PTR(_i_18124)->dbl - (double)2);
    }
    if (IS_ATOM_INT(_10276)) {
        if (_10276 == (short)_10276)
        _10277 = _10276 * 8;
        else
        _10277 = NewDouble(_10276 * (double)8);
    }
    else {
        _10277 = NewDouble(DBL_PTR(_10276)->dbl * (double)8);
    }
    DeRef(_10276);
    _10276 = NOVALUE;
    if (IS_ATOM_INT(_free_list_18127) && IS_ATOM_INT(_10277)) {
        _10278 = _free_list_18127 + _10277;
        if ((long)((unsigned long)_10278 + (unsigned long)HIGH_BITS) >= 0) 
        _10278 = NewDouble((double)_10278);
    }
    else {
        if (IS_ATOM_INT(_free_list_18127)) {
            _10278 = NewDouble((double)_free_list_18127 + DBL_PTR(_10277)->dbl);
        }
        else {
            if (IS_ATOM_INT(_10277)) {
                _10278 = NewDouble(DBL_PTR(_free_list_18127)->dbl + (double)_10277);
            }
            else
            _10278 = NewDouble(DBL_PTR(_free_list_18127)->dbl + DBL_PTR(_10277)->dbl);
        }
    }
    DeRef(_10277);
    _10277 = NOVALUE;
    if (IS_ATOM_INT(_10278)) {
        _10279 = _10278 + 4;
        if ((long)((unsigned long)_10279 + (unsigned long)HIGH_BITS) >= 0) 
        _10279 = NewDouble((double)_10279);
    }
    else {
        _10279 = NewDouble(DBL_PTR(_10278)->dbl + (double)4);
    }
    DeRef(_10278);
    _10278 = NOVALUE;
    DeRef(_pos_inlined_seek_at_427_18205);
    _pos_inlined_seek_at_427_18205 = _10279;
    _10279 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_427_18205);
    DeRef(_seek_1__tmp_at430_18207);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _49current_db_17372;
    ((int *)_2)[2] = _pos_inlined_seek_at_427_18205;
    _seek_1__tmp_at430_18207 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_430_18206 = machine(19, _seek_1__tmp_at430_18207);
    DeRef(_pos_inlined_seek_at_427_18205);
    _pos_inlined_seek_at_427_18205 = NOVALUE;
    DeRef(_seek_1__tmp_at430_18207);
    _seek_1__tmp_at430_18207 = NOVALUE;

    /** 		if i < free_count and p + psize = addr then*/
    if (IS_ATOM_INT(_i_18124)) {
        _10280 = (_i_18124 < _free_count_18133);
    }
    else {
        _10280 = (DBL_PTR(_i_18124)->dbl < (double)_free_count_18133);
    }
    if (_10280 == 0) {
        goto LA; // [450] 656
    }
    if (IS_ATOM_INT(_p_18122) && IS_ATOM_INT(_psize_18123)) {
        _10282 = _p_18122 + _psize_18123;
        if ((long)((unsigned long)_10282 + (unsigned long)HIGH_BITS) >= 0) 
        _10282 = NewDouble((double)_10282);
    }
    else {
        if (IS_ATOM_INT(_p_18122)) {
            _10282 = NewDouble((double)_p_18122 + DBL_PTR(_psize_18123)->dbl);
        }
        else {
            if (IS_ATOM_INT(_psize_18123)) {
                _10282 = NewDouble(DBL_PTR(_p_18122)->dbl + (double)_psize_18123);
            }
            else
            _10282 = NewDouble(DBL_PTR(_p_18122)->dbl + DBL_PTR(_psize_18123)->dbl);
        }
    }
    if (IS_ATOM_INT(_10282) && IS_ATOM_INT(_addr_18126)) {
        _10283 = (_10282 == _addr_18126);
    }
    else {
        if (IS_ATOM_INT(_10282)) {
            _10283 = ((double)_10282 == DBL_PTR(_addr_18126)->dbl);
        }
        else {
            if (IS_ATOM_INT(_addr_18126)) {
                _10283 = (DBL_PTR(_10282)->dbl == (double)_addr_18126);
            }
            else
            _10283 = (DBL_PTR(_10282)->dbl == DBL_PTR(_addr_18126)->dbl);
        }
    }
    DeRef(_10282);
    _10282 = NOVALUE;
    if (_10283 == 0)
    {
        DeRef(_10283);
        _10283 = NOVALUE;
        goto LA; // [465] 656
    }
    else{
        DeRef(_10283);
        _10283 = NOVALUE;
    }

    /** 			put4(prev_size+psize+size) -- update size on free list (only)*/
    if (IS_ATOM_INT(_prev_size_18132) && IS_ATOM_INT(_psize_18123)) {
        _10284 = _prev_size_18132 + _psize_18123;
        if ((long)((unsigned long)_10284 + (unsigned long)HIGH_BITS) >= 0) 
        _10284 = NewDouble((double)_10284);
    }
    else {
        if (IS_ATOM_INT(_prev_size_18132)) {
            _10284 = NewDouble((double)_prev_size_18132 + DBL_PTR(_psize_18123)->dbl);
        }
        else {
            if (IS_ATOM_INT(_psize_18123)) {
                _10284 = NewDouble(DBL_PTR(_prev_size_18132)->dbl + (double)_psize_18123);
            }
            else
            _10284 = NewDouble(DBL_PTR(_prev_size_18132)->dbl + DBL_PTR(_psize_18123)->dbl);
        }
    }
    if (IS_ATOM_INT(_10284) && IS_ATOM_INT(_size_18125)) {
        _10285 = _10284 + _size_18125;
        if ((long)((unsigned long)_10285 + (unsigned long)HIGH_BITS) >= 0) 
        _10285 = NewDouble((double)_10285);
    }
    else {
        if (IS_ATOM_INT(_10284)) {
            _10285 = NewDouble((double)_10284 + DBL_PTR(_size_18125)->dbl);
        }
        else {
            if (IS_ATOM_INT(_size_18125)) {
                _10285 = NewDouble(DBL_PTR(_10284)->dbl + (double)_size_18125);
            }
            else
            _10285 = NewDouble(DBL_PTR(_10284)->dbl + DBL_PTR(_size_18125)->dbl);
        }
    }
    DeRef(_10284);
    _10284 = NOVALUE;
    DeRef(_x_inlined_put4_at_479_18216);
    _x_inlined_put4_at_479_18216 = _10285;
    _10285 = NOVALUE;

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_49mem0_17414)){
        poke4_addr = (unsigned long *)_49mem0_17414;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_49mem0_17414)->dbl);
    }
    if (IS_ATOM_INT(_x_inlined_put4_at_479_18216)) {
        *poke4_addr = (unsigned long)_x_inlined_put4_at_479_18216;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_x_inlined_put4_at_479_18216)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at482_18217);
    _1 = (int)SEQ_PTR(_49memseq_17649);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at482_18217 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_49current_db_17372, _put4_1__tmp_at482_18217); // DJP 

    /** end procedure*/
    goto LB; // [504] 507
LB: 
    DeRef(_x_inlined_put4_at_479_18216);
    _x_inlined_put4_at_479_18216 = NOVALUE;
    DeRefi(_put4_1__tmp_at482_18217);
    _put4_1__tmp_at482_18217 = NOVALUE;

    /** 			io:seek(current_db, free_list+i*8)*/
    if (IS_ATOM_INT(_i_18124)) {
        if (_i_18124 == (short)_i_18124)
        _10286 = _i_18124 * 8;
        else
        _10286 = NewDouble(_i_18124 * (double)8);
    }
    else {
        _10286 = NewDouble(DBL_PTR(_i_18124)->dbl * (double)8);
    }
    if (IS_ATOM_INT(_free_list_18127) && IS_ATOM_INT(_10286)) {
        _10287 = _free_list_18127 + _10286;
        if ((long)((unsigned long)_10287 + (unsigned long)HIGH_BITS) >= 0) 
        _10287 = NewDouble((double)_10287);
    }
    else {
        if (IS_ATOM_INT(_free_list_18127)) {
            _10287 = NewDouble((double)_free_list_18127 + DBL_PTR(_10286)->dbl);
        }
        else {
            if (IS_ATOM_INT(_10286)) {
                _10287 = NewDouble(DBL_PTR(_free_list_18127)->dbl + (double)_10286);
            }
            else
            _10287 = NewDouble(DBL_PTR(_free_list_18127)->dbl + DBL_PTR(_10286)->dbl);
        }
    }
    DeRef(_10286);
    _10286 = NOVALUE;
    DeRef(_pos_inlined_seek_at_520_18221);
    _pos_inlined_seek_at_520_18221 = _10287;
    _10287 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_520_18221);
    DeRef(_seek_1__tmp_at523_18223);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _49current_db_17372;
    ((int *)_2)[2] = _pos_inlined_seek_at_520_18221;
    _seek_1__tmp_at523_18223 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_523_18222 = machine(19, _seek_1__tmp_at523_18223);
    DeRef(_pos_inlined_seek_at_520_18221);
    _pos_inlined_seek_at_520_18221 = NOVALUE;
    DeRef(_seek_1__tmp_at523_18223);
    _seek_1__tmp_at523_18223 = NOVALUE;

    /** 			remaining = io:get_bytes(current_db, (free_count-i)*8)*/
    if (IS_ATOM_INT(_i_18124)) {
        _10288 = _free_count_18133 - _i_18124;
        if ((long)((unsigned long)_10288 +(unsigned long) HIGH_BITS) >= 0){
            _10288 = NewDouble((double)_10288);
        }
    }
    else {
        _10288 = NewDouble((double)_free_count_18133 - DBL_PTR(_i_18124)->dbl);
    }
    if (IS_ATOM_INT(_10288)) {
        if (_10288 == (short)_10288)
        _10289 = _10288 * 8;
        else
        _10289 = NewDouble(_10288 * (double)8);
    }
    else {
        _10289 = NewDouble(DBL_PTR(_10288)->dbl * (double)8);
    }
    DeRef(_10288);
    _10288 = NOVALUE;
    _0 = _remaining_18134;
    _remaining_18134 = _8get_bytes(_49current_db_17372, _10289);
    DeRef(_0);
    _10289 = NOVALUE;

    /** 			io:seek(current_db, free_list+(i-1)*8)*/
    if (IS_ATOM_INT(_i_18124)) {
        _10291 = _i_18124 - 1;
        if ((long)((unsigned long)_10291 +(unsigned long) HIGH_BITS) >= 0){
            _10291 = NewDouble((double)_10291);
        }
    }
    else {
        _10291 = NewDouble(DBL_PTR(_i_18124)->dbl - (double)1);
    }
    if (IS_ATOM_INT(_10291)) {
        if (_10291 == (short)_10291)
        _10292 = _10291 * 8;
        else
        _10292 = NewDouble(_10291 * (double)8);
    }
    else {
        _10292 = NewDouble(DBL_PTR(_10291)->dbl * (double)8);
    }
    DeRef(_10291);
    _10291 = NOVALUE;
    if (IS_ATOM_INT(_free_list_18127) && IS_ATOM_INT(_10292)) {
        _10293 = _free_list_18127 + _10292;
        if ((long)((unsigned long)_10293 + (unsigned long)HIGH_BITS) >= 0) 
        _10293 = NewDouble((double)_10293);
    }
    else {
        if (IS_ATOM_INT(_free_list_18127)) {
            _10293 = NewDouble((double)_free_list_18127 + DBL_PTR(_10292)->dbl);
        }
        else {
            if (IS_ATOM_INT(_10292)) {
                _10293 = NewDouble(DBL_PTR(_free_list_18127)->dbl + (double)_10292);
            }
            else
            _10293 = NewDouble(DBL_PTR(_free_list_18127)->dbl + DBL_PTR(_10292)->dbl);
        }
    }
    DeRef(_10292);
    _10292 = NOVALUE;
    DeRef(_pos_inlined_seek_at_571_18231);
    _pos_inlined_seek_at_571_18231 = _10293;
    _10293 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_571_18231);
    DeRef(_seek_1__tmp_at574_18233);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _49current_db_17372;
    ((int *)_2)[2] = _pos_inlined_seek_at_571_18231;
    _seek_1__tmp_at574_18233 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_574_18232 = machine(19, _seek_1__tmp_at574_18233);
    DeRef(_pos_inlined_seek_at_571_18231);
    _pos_inlined_seek_at_571_18231 = NOVALUE;
    DeRef(_seek_1__tmp_at574_18233);
    _seek_1__tmp_at574_18233 = NOVALUE;

    /** 			putn(remaining)*/

    /** 	puts(current_db, s)*/
    EPuts(_49current_db_17372, _remaining_18134); // DJP 

    /** end procedure*/
    goto LC; // [599] 602
LC: 

    /** 			free_count -= 1*/
    _free_count_18133 = _free_count_18133 - 1;

    /** 			io:seek(current_db, FREE_COUNT)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at611_18238);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _49current_db_17372;
    ((int *)_2)[2] = 7;
    _seek_1__tmp_at611_18238 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_611_18237 = machine(19, _seek_1__tmp_at611_18238);
    DeRefi(_seek_1__tmp_at611_18238);
    _seek_1__tmp_at611_18238 = NOVALUE;

    /** 			put4(free_count)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_49mem0_17414)){
        poke4_addr = (unsigned long *)_49mem0_17414;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_49mem0_17414)->dbl);
    }
    *poke4_addr = (unsigned long)_free_count_18133;

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at626_18240);
    _1 = (int)SEQ_PTR(_49memseq_17649);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at626_18240 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_49current_db_17372, _put4_1__tmp_at626_18240); // DJP 

    /** end procedure*/
    goto LD; // [648] 651
LD: 
    DeRefi(_put4_1__tmp_at626_18240);
    _put4_1__tmp_at626_18240 = NOVALUE;
    goto LE; // [653] 1028
LA: 

    /** 			put4(prev_size+psize) -- increase previous size on free list (only)*/
    if (IS_ATOM_INT(_prev_size_18132) && IS_ATOM_INT(_psize_18123)) {
        _10295 = _prev_size_18132 + _psize_18123;
        if ((long)((unsigned long)_10295 + (unsigned long)HIGH_BITS) >= 0) 
        _10295 = NewDouble((double)_10295);
    }
    else {
        if (IS_ATOM_INT(_prev_size_18132)) {
            _10295 = NewDouble((double)_prev_size_18132 + DBL_PTR(_psize_18123)->dbl);
        }
        else {
            if (IS_ATOM_INT(_psize_18123)) {
                _10295 = NewDouble(DBL_PTR(_prev_size_18132)->dbl + (double)_psize_18123);
            }
            else
            _10295 = NewDouble(DBL_PTR(_prev_size_18132)->dbl + DBL_PTR(_psize_18123)->dbl);
        }
    }
    DeRef(_x_inlined_put4_at_661_18244);
    _x_inlined_put4_at_661_18244 = _10295;
    _10295 = NOVALUE;

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_49mem0_17414)){
        poke4_addr = (unsigned long *)_49mem0_17414;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_49mem0_17414)->dbl);
    }
    if (IS_ATOM_INT(_x_inlined_put4_at_661_18244)) {
        *poke4_addr = (unsigned long)_x_inlined_put4_at_661_18244;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_x_inlined_put4_at_661_18244)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at664_18245);
    _1 = (int)SEQ_PTR(_49memseq_17649);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at664_18245 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_49current_db_17372, _put4_1__tmp_at664_18245); // DJP 

    /** end procedure*/
    goto LF; // [686] 689
LF: 
    DeRef(_x_inlined_put4_at_661_18244);
    _x_inlined_put4_at_661_18244 = NOVALUE;
    DeRefi(_put4_1__tmp_at664_18245);
    _put4_1__tmp_at664_18245 = NOVALUE;
    goto LE; // [692] 1028
L9: 

    /** 	elsif i < free_count and p + psize = addr then*/
    if (IS_ATOM_INT(_i_18124)) {
        _10296 = (_i_18124 < _free_count_18133);
    }
    else {
        _10296 = (DBL_PTR(_i_18124)->dbl < (double)_free_count_18133);
    }
    if (_10296 == 0) {
        goto L10; // [701] 819
    }
    if (IS_ATOM_INT(_p_18122) && IS_ATOM_INT(_psize_18123)) {
        _10298 = _p_18122 + _psize_18123;
        if ((long)((unsigned long)_10298 + (unsigned long)HIGH_BITS) >= 0) 
        _10298 = NewDouble((double)_10298);
    }
    else {
        if (IS_ATOM_INT(_p_18122)) {
            _10298 = NewDouble((double)_p_18122 + DBL_PTR(_psize_18123)->dbl);
        }
        else {
            if (IS_ATOM_INT(_psize_18123)) {
                _10298 = NewDouble(DBL_PTR(_p_18122)->dbl + (double)_psize_18123);
            }
            else
            _10298 = NewDouble(DBL_PTR(_p_18122)->dbl + DBL_PTR(_psize_18123)->dbl);
        }
    }
    if (IS_ATOM_INT(_10298) && IS_ATOM_INT(_addr_18126)) {
        _10299 = (_10298 == _addr_18126);
    }
    else {
        if (IS_ATOM_INT(_10298)) {
            _10299 = ((double)_10298 == DBL_PTR(_addr_18126)->dbl);
        }
        else {
            if (IS_ATOM_INT(_addr_18126)) {
                _10299 = (DBL_PTR(_10298)->dbl == (double)_addr_18126);
            }
            else
            _10299 = (DBL_PTR(_10298)->dbl == DBL_PTR(_addr_18126)->dbl);
        }
    }
    DeRef(_10298);
    _10298 = NOVALUE;
    if (_10299 == 0)
    {
        DeRef(_10299);
        _10299 = NOVALUE;
        goto L10; // [716] 819
    }
    else{
        DeRef(_10299);
        _10299 = NOVALUE;
    }

    /** 		io:seek(current_db, free_list+(i-1)*8)*/
    if (IS_ATOM_INT(_i_18124)) {
        _10300 = _i_18124 - 1;
        if ((long)((unsigned long)_10300 +(unsigned long) HIGH_BITS) >= 0){
            _10300 = NewDouble((double)_10300);
        }
    }
    else {
        _10300 = NewDouble(DBL_PTR(_i_18124)->dbl - (double)1);
    }
    if (IS_ATOM_INT(_10300)) {
        if (_10300 == (short)_10300)
        _10301 = _10300 * 8;
        else
        _10301 = NewDouble(_10300 * (double)8);
    }
    else {
        _10301 = NewDouble(DBL_PTR(_10300)->dbl * (double)8);
    }
    DeRef(_10300);
    _10300 = NOVALUE;
    if (IS_ATOM_INT(_free_list_18127) && IS_ATOM_INT(_10301)) {
        _10302 = _free_list_18127 + _10301;
        if ((long)((unsigned long)_10302 + (unsigned long)HIGH_BITS) >= 0) 
        _10302 = NewDouble((double)_10302);
    }
    else {
        if (IS_ATOM_INT(_free_list_18127)) {
            _10302 = NewDouble((double)_free_list_18127 + DBL_PTR(_10301)->dbl);
        }
        else {
            if (IS_ATOM_INT(_10301)) {
                _10302 = NewDouble(DBL_PTR(_free_list_18127)->dbl + (double)_10301);
            }
            else
            _10302 = NewDouble(DBL_PTR(_free_list_18127)->dbl + DBL_PTR(_10301)->dbl);
        }
    }
    DeRef(_10301);
    _10301 = NOVALUE;
    DeRef(_pos_inlined_seek_at_734_18255);
    _pos_inlined_seek_at_734_18255 = _10302;
    _10302 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_734_18255);
    DeRef(_seek_1__tmp_at737_18257);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _49current_db_17372;
    ((int *)_2)[2] = _pos_inlined_seek_at_734_18255;
    _seek_1__tmp_at737_18257 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_737_18256 = machine(19, _seek_1__tmp_at737_18257);
    DeRef(_pos_inlined_seek_at_734_18255);
    _pos_inlined_seek_at_734_18255 = NOVALUE;
    DeRef(_seek_1__tmp_at737_18257);
    _seek_1__tmp_at737_18257 = NOVALUE;

    /** 		put4(p)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_49mem0_17414)){
        poke4_addr = (unsigned long *)_49mem0_17414;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_49mem0_17414)->dbl);
    }
    if (IS_ATOM_INT(_p_18122)) {
        *poke4_addr = (unsigned long)_p_18122;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_p_18122)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at752_18259);
    _1 = (int)SEQ_PTR(_49memseq_17649);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at752_18259 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_49current_db_17372, _put4_1__tmp_at752_18259); // DJP 

    /** end procedure*/
    goto L11; // [774] 777
L11: 
    DeRefi(_put4_1__tmp_at752_18259);
    _put4_1__tmp_at752_18259 = NOVALUE;

    /** 		put4(psize+size)*/
    if (IS_ATOM_INT(_psize_18123) && IS_ATOM_INT(_size_18125)) {
        _10303 = _psize_18123 + _size_18125;
        if ((long)((unsigned long)_10303 + (unsigned long)HIGH_BITS) >= 0) 
        _10303 = NewDouble((double)_10303);
    }
    else {
        if (IS_ATOM_INT(_psize_18123)) {
            _10303 = NewDouble((double)_psize_18123 + DBL_PTR(_size_18125)->dbl);
        }
        else {
            if (IS_ATOM_INT(_size_18125)) {
                _10303 = NewDouble(DBL_PTR(_psize_18123)->dbl + (double)_size_18125);
            }
            else
            _10303 = NewDouble(DBL_PTR(_psize_18123)->dbl + DBL_PTR(_size_18125)->dbl);
        }
    }
    DeRef(_x_inlined_put4_at_786_18262);
    _x_inlined_put4_at_786_18262 = _10303;
    _10303 = NOVALUE;

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_49mem0_17414)){
        poke4_addr = (unsigned long *)_49mem0_17414;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_49mem0_17414)->dbl);
    }
    if (IS_ATOM_INT(_x_inlined_put4_at_786_18262)) {
        *poke4_addr = (unsigned long)_x_inlined_put4_at_786_18262;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_x_inlined_put4_at_786_18262)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at789_18263);
    _1 = (int)SEQ_PTR(_49memseq_17649);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at789_18263 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_49current_db_17372, _put4_1__tmp_at789_18263); // DJP 

    /** end procedure*/
    goto L12; // [811] 814
L12: 
    DeRef(_x_inlined_put4_at_786_18262);
    _x_inlined_put4_at_786_18262 = NOVALUE;
    DeRefi(_put4_1__tmp_at789_18263);
    _put4_1__tmp_at789_18263 = NOVALUE;
    goto LE; // [816] 1028
L10: 

    /** 		io:seek(current_db, free_list+(i-1)*8)*/
    if (IS_ATOM_INT(_i_18124)) {
        _10304 = _i_18124 - 1;
        if ((long)((unsigned long)_10304 +(unsigned long) HIGH_BITS) >= 0){
            _10304 = NewDouble((double)_10304);
        }
    }
    else {
        _10304 = NewDouble(DBL_PTR(_i_18124)->dbl - (double)1);
    }
    if (IS_ATOM_INT(_10304)) {
        if (_10304 == (short)_10304)
        _10305 = _10304 * 8;
        else
        _10305 = NewDouble(_10304 * (double)8);
    }
    else {
        _10305 = NewDouble(DBL_PTR(_10304)->dbl * (double)8);
    }
    DeRef(_10304);
    _10304 = NOVALUE;
    if (IS_ATOM_INT(_free_list_18127) && IS_ATOM_INT(_10305)) {
        _10306 = _free_list_18127 + _10305;
        if ((long)((unsigned long)_10306 + (unsigned long)HIGH_BITS) >= 0) 
        _10306 = NewDouble((double)_10306);
    }
    else {
        if (IS_ATOM_INT(_free_list_18127)) {
            _10306 = NewDouble((double)_free_list_18127 + DBL_PTR(_10305)->dbl);
        }
        else {
            if (IS_ATOM_INT(_10305)) {
                _10306 = NewDouble(DBL_PTR(_free_list_18127)->dbl + (double)_10305);
            }
            else
            _10306 = NewDouble(DBL_PTR(_free_list_18127)->dbl + DBL_PTR(_10305)->dbl);
        }
    }
    DeRef(_10305);
    _10305 = NOVALUE;
    DeRef(_pos_inlined_seek_at_834_18269);
    _pos_inlined_seek_at_834_18269 = _10306;
    _10306 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_834_18269);
    DeRef(_seek_1__tmp_at837_18271);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _49current_db_17372;
    ((int *)_2)[2] = _pos_inlined_seek_at_834_18269;
    _seek_1__tmp_at837_18271 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_837_18270 = machine(19, _seek_1__tmp_at837_18271);
    DeRef(_pos_inlined_seek_at_834_18269);
    _pos_inlined_seek_at_834_18269 = NOVALUE;
    DeRef(_seek_1__tmp_at837_18271);
    _seek_1__tmp_at837_18271 = NOVALUE;

    /** 		remaining = io:get_bytes(current_db, (free_count-i+1)*8)*/
    if (IS_ATOM_INT(_i_18124)) {
        _10307 = _free_count_18133 - _i_18124;
        if ((long)((unsigned long)_10307 +(unsigned long) HIGH_BITS) >= 0){
            _10307 = NewDouble((double)_10307);
        }
    }
    else {
        _10307 = NewDouble((double)_free_count_18133 - DBL_PTR(_i_18124)->dbl);
    }
    if (IS_ATOM_INT(_10307)) {
        _10308 = _10307 + 1;
        if (_10308 > MAXINT){
            _10308 = NewDouble((double)_10308);
        }
    }
    else
    _10308 = binary_op(PLUS, 1, _10307);
    DeRef(_10307);
    _10307 = NOVALUE;
    if (IS_ATOM_INT(_10308)) {
        if (_10308 == (short)_10308)
        _10309 = _10308 * 8;
        else
        _10309 = NewDouble(_10308 * (double)8);
    }
    else {
        _10309 = NewDouble(DBL_PTR(_10308)->dbl * (double)8);
    }
    DeRef(_10308);
    _10308 = NOVALUE;
    _0 = _remaining_18134;
    _remaining_18134 = _8get_bytes(_49current_db_17372, _10309);
    DeRef(_0);
    _10309 = NOVALUE;

    /** 		free_count += 1*/
    _free_count_18133 = _free_count_18133 + 1;

    /** 		io:seek(current_db, FREE_COUNT)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at883_18279);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _49current_db_17372;
    ((int *)_2)[2] = 7;
    _seek_1__tmp_at883_18279 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_883_18278 = machine(19, _seek_1__tmp_at883_18279);
    DeRefi(_seek_1__tmp_at883_18279);
    _seek_1__tmp_at883_18279 = NOVALUE;

    /** 		put4(free_count)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_49mem0_17414)){
        poke4_addr = (unsigned long *)_49mem0_17414;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_49mem0_17414)->dbl);
    }
    *poke4_addr = (unsigned long)_free_count_18133;

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at898_18281);
    _1 = (int)SEQ_PTR(_49memseq_17649);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at898_18281 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_49current_db_17372, _put4_1__tmp_at898_18281); // DJP 

    /** end procedure*/
    goto L13; // [920] 923
L13: 
    DeRefi(_put4_1__tmp_at898_18281);
    _put4_1__tmp_at898_18281 = NOVALUE;

    /** 		io:seek(current_db, free_list+(i-1)*8)*/
    if (IS_ATOM_INT(_i_18124)) {
        _10312 = _i_18124 - 1;
        if ((long)((unsigned long)_10312 +(unsigned long) HIGH_BITS) >= 0){
            _10312 = NewDouble((double)_10312);
        }
    }
    else {
        _10312 = NewDouble(DBL_PTR(_i_18124)->dbl - (double)1);
    }
    if (IS_ATOM_INT(_10312)) {
        if (_10312 == (short)_10312)
        _10313 = _10312 * 8;
        else
        _10313 = NewDouble(_10312 * (double)8);
    }
    else {
        _10313 = NewDouble(DBL_PTR(_10312)->dbl * (double)8);
    }
    DeRef(_10312);
    _10312 = NOVALUE;
    if (IS_ATOM_INT(_free_list_18127) && IS_ATOM_INT(_10313)) {
        _10314 = _free_list_18127 + _10313;
        if ((long)((unsigned long)_10314 + (unsigned long)HIGH_BITS) >= 0) 
        _10314 = NewDouble((double)_10314);
    }
    else {
        if (IS_ATOM_INT(_free_list_18127)) {
            _10314 = NewDouble((double)_free_list_18127 + DBL_PTR(_10313)->dbl);
        }
        else {
            if (IS_ATOM_INT(_10313)) {
                _10314 = NewDouble(DBL_PTR(_free_list_18127)->dbl + (double)_10313);
            }
            else
            _10314 = NewDouble(DBL_PTR(_free_list_18127)->dbl + DBL_PTR(_10313)->dbl);
        }
    }
    DeRef(_10313);
    _10313 = NOVALUE;
    DeRef(_pos_inlined_seek_at_940_18286);
    _pos_inlined_seek_at_940_18286 = _10314;
    _10314 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_940_18286);
    DeRef(_seek_1__tmp_at943_18288);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _49current_db_17372;
    ((int *)_2)[2] = _pos_inlined_seek_at_940_18286;
    _seek_1__tmp_at943_18288 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_943_18287 = machine(19, _seek_1__tmp_at943_18288);
    DeRef(_pos_inlined_seek_at_940_18286);
    _pos_inlined_seek_at_940_18286 = NOVALUE;
    DeRef(_seek_1__tmp_at943_18288);
    _seek_1__tmp_at943_18288 = NOVALUE;

    /** 		put4(p)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_49mem0_17414)){
        poke4_addr = (unsigned long *)_49mem0_17414;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_49mem0_17414)->dbl);
    }
    if (IS_ATOM_INT(_p_18122)) {
        *poke4_addr = (unsigned long)_p_18122;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_p_18122)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at958_18290);
    _1 = (int)SEQ_PTR(_49memseq_17649);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at958_18290 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_49current_db_17372, _put4_1__tmp_at958_18290); // DJP 

    /** end procedure*/
    goto L14; // [980] 983
L14: 
    DeRefi(_put4_1__tmp_at958_18290);
    _put4_1__tmp_at958_18290 = NOVALUE;

    /** 		put4(psize)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_49mem0_17414)){
        poke4_addr = (unsigned long *)_49mem0_17414;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_49mem0_17414)->dbl);
    }
    if (IS_ATOM_INT(_psize_18123)) {
        *poke4_addr = (unsigned long)_psize_18123;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_psize_18123)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at986_18292);
    _1 = (int)SEQ_PTR(_49memseq_17649);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at986_18292 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_49current_db_17372, _put4_1__tmp_at986_18292); // DJP 

    /** end procedure*/
    goto L15; // [1008] 1011
L15: 
    DeRefi(_put4_1__tmp_at986_18292);
    _put4_1__tmp_at986_18292 = NOVALUE;

    /** 		putn(remaining)*/

    /** 	puts(current_db, s)*/
    EPuts(_49current_db_17372, _remaining_18134); // DJP 

    /** end procedure*/
    goto L16; // [1024] 1027
L16: 
LE: 

    /** 	if new_space then*/
    if (_new_space_18129 == 0) {
        goto L17; // [1032] 1043
    }
    else {
        if (!IS_ATOM_INT(_new_space_18129) && DBL_PTR(_new_space_18129)->dbl == 0.0){
            goto L17; // [1032] 1043
        }
    }

    /** 		db_free(to_be_freed) -- free the old space*/
    Ref(_to_be_freed_18130);
    _49db_free(_to_be_freed_18130);
L17: 

    /** end procedure*/
    DeRef(_p_18122);
    DeRef(_psize_18123);
    DeRef(_i_18124);
    DeRef(_size_18125);
    DeRef(_addr_18126);
    DeRef(_free_list_18127);
    DeRef(_free_list_space_18128);
    DeRef(_new_space_18129);
    DeRef(_to_be_freed_18130);
    DeRef(_prev_addr_18131);
    DeRef(_prev_size_18132);
    DeRef(_remaining_18134);
    DeRef(_10272);
    _10272 = NOVALUE;
    DeRef(_10280);
    _10280 = NOVALUE;
    DeRef(_10296);
    _10296 = NOVALUE;
    return;
    ;
}


void _49save_keys()
{
    int _k_18297 = NOVALUE;
    int _10321 = NOVALUE;
    int _10317 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if caching_option = 1 then*/

    /** 		if current_table_pos > 0 then*/
    if (binary_op_a(LESSEQ, _49current_table_pos_17373, 0)){
        goto L1; // [13] 81
    }

    /** 			k = eu:find({current_db, current_table_pos}, cache_index)*/
    Ref(_49current_table_pos_17373);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _49current_db_17372;
    ((int *)_2)[2] = _49current_table_pos_17373;
    _10317 = MAKE_SEQ(_1);
    _k_18297 = find_from(_10317, _49cache_index_17381, 1);
    DeRefDS(_10317);
    _10317 = NOVALUE;

    /** 			if k != 0 then*/
    if (_k_18297 == 0)
    goto L2; // [36] 53

    /** 				key_cache[k] = key_pointers*/
    RefDS(_49key_pointers_17379);
    _2 = (int)SEQ_PTR(_49key_cache_17380);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _49key_cache_17380 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _k_18297);
    _1 = *(int *)_2;
    *(int *)_2 = _49key_pointers_17379;
    DeRef(_1);
    goto L3; // [50] 80
L2: 

    /** 				key_cache = append(key_cache, key_pointers)*/
    RefDS(_49key_pointers_17379);
    Append(&_49key_cache_17380, _49key_cache_17380, _49key_pointers_17379);

    /** 				cache_index = append(cache_index, {current_db, current_table_pos})*/
    Ref(_49current_table_pos_17373);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _49current_db_17372;
    ((int *)_2)[2] = _49current_table_pos_17373;
    _10321 = MAKE_SEQ(_1);
    RefDS(_10321);
    Append(&_49cache_index_17381, _49cache_index_17381, _10321);
    DeRefDS(_10321);
    _10321 = NOVALUE;
L3: 
L1: 

    /** end procedure*/
    return;
    ;
}


int _49db_create(int _path_18394, int _lock_method_18395, int _init_tables_18396, int _init_free_18397)
{
    int _db_18398 = NOVALUE;
    int _lock_file_1__tmp_at222_18438 = NOVALUE;
    int _lock_file_inlined_lock_file_at_222_18437 = NOVALUE;
    int _put4_1__tmp_at342_18447 = NOVALUE;
    int _put4_1__tmp_at370_18449 = NOVALUE;
    int _put4_1__tmp_at413_18455 = NOVALUE;
    int _x_inlined_put4_at_410_18454 = NOVALUE;
    int _put4_1__tmp_at452_18460 = NOVALUE;
    int _x_inlined_put4_at_449_18459 = NOVALUE;
    int _put4_1__tmp_at480_18462 = NOVALUE;
    int _s_inlined_putn_at_516_18466 = NOVALUE;
    int _put4_1__tmp_at548_18471 = NOVALUE;
    int _x_inlined_put4_at_545_18470 = NOVALUE;
    int _s_inlined_putn_at_584_18475 = NOVALUE;
    int _10420 = NOVALUE;
    int _10419 = NOVALUE;
    int _10418 = NOVALUE;
    int _10417 = NOVALUE;
    int _10416 = NOVALUE;
    int _10415 = NOVALUE;
    int _10414 = NOVALUE;
    int _10413 = NOVALUE;
    int _10412 = NOVALUE;
    int _10411 = NOVALUE;
    int _10410 = NOVALUE;
    int _10392 = NOVALUE;
    int _10390 = NOVALUE;
    int _10389 = NOVALUE;
    int _10387 = NOVALUE;
    int _10386 = NOVALUE;
    int _10384 = NOVALUE;
    int _10383 = NOVALUE;
    int _10381 = NOVALUE;
    int _0, _1, _2;
    

    /** 	db = find(path, Known_Aliases)*/
    _db_18398 = find_from(_path_18394, _49Known_Aliases_17393, 1);

    /** 	if db then*/
    if (_db_18398 == 0)
    {
        goto L1; // [20] 94
    }
    else{
    }

    /** 		path = Alias_Details[db][1]*/
    _2 = (int)SEQ_PTR(_49Alias_Details_17394);
    _10381 = (int)*(((s1_ptr)_2)->base + _db_18398);
    DeRefDS(_path_18394);
    _2 = (int)SEQ_PTR(_10381);
    _path_18394 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_path_18394);
    _10381 = NOVALUE;

    /** 		lock_method = Alias_Details[db][2][CONNECT_LOCK]*/
    _2 = (int)SEQ_PTR(_49Alias_Details_17394);
    _10383 = (int)*(((s1_ptr)_2)->base + _db_18398);
    _2 = (int)SEQ_PTR(_10383);
    _10384 = (int)*(((s1_ptr)_2)->base + 2);
    _10383 = NOVALUE;
    _2 = (int)SEQ_PTR(_10384);
    _lock_method_18395 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_lock_method_18395)){
        _lock_method_18395 = (long)DBL_PTR(_lock_method_18395)->dbl;
    }
    _10384 = NOVALUE;

    /** 		init_tables = Alias_Details[db][2][CONNECT_TABLES]*/
    _2 = (int)SEQ_PTR(_49Alias_Details_17394);
    _10386 = (int)*(((s1_ptr)_2)->base + _db_18398);
    _2 = (int)SEQ_PTR(_10386);
    _10387 = (int)*(((s1_ptr)_2)->base + 2);
    _10386 = NOVALUE;
    _2 = (int)SEQ_PTR(_10387);
    _init_tables_18396 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_init_tables_18396)){
        _init_tables_18396 = (long)DBL_PTR(_init_tables_18396)->dbl;
    }
    _10387 = NOVALUE;

    /** 		init_free = Alias_Details[db][2][CONNECT_FREE]*/
    _2 = (int)SEQ_PTR(_49Alias_Details_17394);
    _10389 = (int)*(((s1_ptr)_2)->base + _db_18398);
    _2 = (int)SEQ_PTR(_10389);
    _10390 = (int)*(((s1_ptr)_2)->base + 2);
    _10389 = NOVALUE;
    _2 = (int)SEQ_PTR(_10390);
    _init_free_18397 = (int)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_init_free_18397)){
        _init_free_18397 = (long)DBL_PTR(_init_free_18397)->dbl;
    }
    _10390 = NOVALUE;
    goto L2; // [91] 134
L1: 

    /** 		path = filesys:canonical_path( defaultext(path, "edb") )*/
    RefDS(_path_18394);
    RefDS(_10375);
    _10392 = _17defaultext(_path_18394, _10375);
    _0 = _path_18394;
    _path_18394 = _17canonical_path(_10392, 0, 0);
    DeRefDS(_0);
    _10392 = NOVALUE;

    /** 		if init_tables < 1 then*/
    if (_init_tables_18396 >= 1)
    goto L3; // [111] 121

    /** 			init_tables = 1*/
    _init_tables_18396 = 1;
L3: 

    /** 		if init_free < 0 then*/
    if (_init_free_18397 >= 0)
    goto L4; // [123] 133

    /** 			init_free = 0*/
    _init_free_18397 = 0;
L4: 
L2: 

    /** 	db = open(path, "rb")*/
    _db_18398 = EOpen(_path_18394, _3739, 0);

    /** 	if db != -1 then*/
    if (_db_18398 == -1)
    goto L5; // [143] 158

    /** 		close(db)*/
    EClose(_db_18398);

    /** 		return DB_EXISTS_ALREADY*/
    DeRefDS(_path_18394);
    return -2;
L5: 

    /** 	db = open(path, "wb")*/
    _db_18398 = EOpen(_path_18394, _10398, 0);

    /** 	if db = -1 then*/
    if (_db_18398 != -1)
    goto L6; // [167] 178

    /** 		return DB_OPEN_FAIL*/
    DeRefDS(_path_18394);
    return -1;
L6: 

    /** 	close(db)*/
    EClose(_db_18398);

    /** 	db = open(path, "ub")*/
    _db_18398 = EOpen(_path_18394, _10401, 0);

    /** 	if db = -1 then*/
    if (_db_18398 != -1)
    goto L7; // [191] 202

    /** 		return DB_OPEN_FAIL*/
    DeRefDS(_path_18394);
    return -1;
L7: 

    /** 	if lock_method = DB_LOCK_SHARED then*/
    if (_lock_method_18395 != 1)
    goto L8; // [204] 214

    /** 		lock_method = DB_LOCK_NO*/
    _lock_method_18395 = 0;
L8: 

    /** 	if lock_method = DB_LOCK_EXCLUSIVE then*/
    if (_lock_method_18395 != 2)
    goto L9; // [216] 248

    /** 		if not io:lock_file(db, io:LOCK_EXCLUSIVE, {}) then*/

    /** 	return machine_func(M_LOCK_FILE, {fn, t, r})*/
    _0 = _lock_file_1__tmp_at222_18438;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _db_18398;
    *((int *)(_2+8)) = 2;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    _lock_file_1__tmp_at222_18438 = MAKE_SEQ(_1);
    DeRef(_0);
    _lock_file_inlined_lock_file_at_222_18437 = machine(61, _lock_file_1__tmp_at222_18438);
    DeRef(_lock_file_1__tmp_at222_18438);
    _lock_file_1__tmp_at222_18438 = NOVALUE;
    if (_lock_file_inlined_lock_file_at_222_18437 != 0)
    goto LA; // [237] 247

    /** 			return DB_LOCK_FAIL*/
    DeRefDS(_path_18394);
    return -3;
LA: 
L9: 

    /** 	save_keys()*/
    _49save_keys();

    /** 	current_db = db*/
    _49current_db_17372 = _db_18398;

    /** 	current_lock = lock_method*/
    _49current_lock_17378 = _lock_method_18395;

    /** 	current_table_pos = -1*/
    DeRef(_49current_table_pos_17373);
    _49current_table_pos_17373 = -1;

    /** 	current_table_name = ""*/
    RefDS(_5);
    DeRef(_49current_table_name_17374);
    _49current_table_name_17374 = _5;

    /** 	db_names = append(db_names, path)*/
    RefDS(_path_18394);
    Append(&_49db_names_17375, _49db_names_17375, _path_18394);

    /** 	db_lock_methods = append(db_lock_methods, lock_method)*/
    Append(&_49db_lock_methods_17377, _49db_lock_methods_17377, _lock_method_18395);

    /** 	db_file_nums = append(db_file_nums, db)*/
    Append(&_49db_file_nums_17376, _49db_file_nums_17376, _db_18398);

    /** 	put1(DB_MAGIC) -- so we know what type of file it is*/

    /** 	puts(current_db, x)*/
    EPuts(_49current_db_17372, 77); // DJP 

    /** end procedure*/
    goto LB; // [309] 312
LB: 

    /** 	put1(DB_MAJOR) -- major version*/

    /** 	puts(current_db, x)*/
    EPuts(_49current_db_17372, 4); // DJP 

    /** end procedure*/
    goto LC; // [323] 326
LC: 

    /** 	put1(DB_MINOR) -- minor version*/

    /** 	puts(current_db, x)*/
    EPuts(_49current_db_17372, 0); // DJP 

    /** end procedure*/
    goto LD; // [337] 340
LD: 

    /** 	put4(19)  -- pointer to tables*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_49mem0_17414)){
        poke4_addr = (unsigned long *)_49mem0_17414;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_49mem0_17414)->dbl);
    }
    *poke4_addr = (unsigned long)19;

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at342_18447);
    _1 = (int)SEQ_PTR(_49memseq_17649);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at342_18447 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_49current_db_17372, _put4_1__tmp_at342_18447); // DJP 

    /** end procedure*/
    goto LE; // [363] 366
LE: 
    DeRefi(_put4_1__tmp_at342_18447);
    _put4_1__tmp_at342_18447 = NOVALUE;

    /** 	put4(0)   -- number of free blocks*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_49mem0_17414)){
        poke4_addr = (unsigned long *)_49mem0_17414;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_49mem0_17414)->dbl);
    }
    *poke4_addr = (unsigned long)0;

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at370_18449);
    _1 = (int)SEQ_PTR(_49memseq_17649);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at370_18449 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_49current_db_17372, _put4_1__tmp_at370_18449); // DJP 

    /** end procedure*/
    goto LF; // [391] 394
LF: 
    DeRefi(_put4_1__tmp_at370_18449);
    _put4_1__tmp_at370_18449 = NOVALUE;

    /** 	put4(23 + init_tables * SIZEOF_TABLE_HEADER + 4)   -- pointer to free list*/
    if (_init_tables_18396 == (short)_init_tables_18396)
    _10410 = _init_tables_18396 * 16;
    else
    _10410 = NewDouble(_init_tables_18396 * (double)16);
    if (IS_ATOM_INT(_10410)) {
        _10411 = 23 + _10410;
        if ((long)((unsigned long)_10411 + (unsigned long)HIGH_BITS) >= 0) 
        _10411 = NewDouble((double)_10411);
    }
    else {
        _10411 = NewDouble((double)23 + DBL_PTR(_10410)->dbl);
    }
    DeRef(_10410);
    _10410 = NOVALUE;
    if (IS_ATOM_INT(_10411)) {
        _10412 = _10411 + 4;
        if ((long)((unsigned long)_10412 + (unsigned long)HIGH_BITS) >= 0) 
        _10412 = NewDouble((double)_10412);
    }
    else {
        _10412 = NewDouble(DBL_PTR(_10411)->dbl + (double)4);
    }
    DeRef(_10411);
    _10411 = NOVALUE;
    DeRef(_x_inlined_put4_at_410_18454);
    _x_inlined_put4_at_410_18454 = _10412;
    _10412 = NOVALUE;

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_49mem0_17414)){
        poke4_addr = (unsigned long *)_49mem0_17414;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_49mem0_17414)->dbl);
    }
    if (IS_ATOM_INT(_x_inlined_put4_at_410_18454)) {
        *poke4_addr = (unsigned long)_x_inlined_put4_at_410_18454;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_x_inlined_put4_at_410_18454)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at413_18455);
    _1 = (int)SEQ_PTR(_49memseq_17649);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at413_18455 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_49current_db_17372, _put4_1__tmp_at413_18455); // DJP 

    /** end procedure*/
    goto L10; // [434] 437
L10: 
    DeRef(_x_inlined_put4_at_410_18454);
    _x_inlined_put4_at_410_18454 = NOVALUE;
    DeRefi(_put4_1__tmp_at413_18455);
    _put4_1__tmp_at413_18455 = NOVALUE;

    /** 	put4( 8 + init_tables * SIZEOF_TABLE_HEADER)  -- allocated size*/
    if (_init_tables_18396 == (short)_init_tables_18396)
    _10413 = _init_tables_18396 * 16;
    else
    _10413 = NewDouble(_init_tables_18396 * (double)16);
    if (IS_ATOM_INT(_10413)) {
        _10414 = 8 + _10413;
        if ((long)((unsigned long)_10414 + (unsigned long)HIGH_BITS) >= 0) 
        _10414 = NewDouble((double)_10414);
    }
    else {
        _10414 = NewDouble((double)8 + DBL_PTR(_10413)->dbl);
    }
    DeRef(_10413);
    _10413 = NOVALUE;
    DeRef(_x_inlined_put4_at_449_18459);
    _x_inlined_put4_at_449_18459 = _10414;
    _10414 = NOVALUE;

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_49mem0_17414)){
        poke4_addr = (unsigned long *)_49mem0_17414;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_49mem0_17414)->dbl);
    }
    if (IS_ATOM_INT(_x_inlined_put4_at_449_18459)) {
        *poke4_addr = (unsigned long)_x_inlined_put4_at_449_18459;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_x_inlined_put4_at_449_18459)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at452_18460);
    _1 = (int)SEQ_PTR(_49memseq_17649);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at452_18460 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_49current_db_17372, _put4_1__tmp_at452_18460); // DJP 

    /** end procedure*/
    goto L11; // [473] 476
L11: 
    DeRef(_x_inlined_put4_at_449_18459);
    _x_inlined_put4_at_449_18459 = NOVALUE;
    DeRefi(_put4_1__tmp_at452_18460);
    _put4_1__tmp_at452_18460 = NOVALUE;

    /** 	put4(0)   -- number of tables that currently exist*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_49mem0_17414)){
        poke4_addr = (unsigned long *)_49mem0_17414;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_49mem0_17414)->dbl);
    }
    *poke4_addr = (unsigned long)0;

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at480_18462);
    _1 = (int)SEQ_PTR(_49memseq_17649);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at480_18462 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_49current_db_17372, _put4_1__tmp_at480_18462); // DJP 

    /** end procedure*/
    goto L12; // [501] 504
L12: 
    DeRefi(_put4_1__tmp_at480_18462);
    _put4_1__tmp_at480_18462 = NOVALUE;

    /** 	putn(repeat(0, init_tables * SIZEOF_TABLE_HEADER))*/
    _10415 = _init_tables_18396 * 16;
    _10416 = Repeat(0, _10415);
    _10415 = NOVALUE;
    DeRefi(_s_inlined_putn_at_516_18466);
    _s_inlined_putn_at_516_18466 = _10416;
    _10416 = NOVALUE;

    /** 	puts(current_db, s)*/
    EPuts(_49current_db_17372, _s_inlined_putn_at_516_18466); // DJP 

    /** end procedure*/
    goto L13; // [530] 533
L13: 
    DeRefi(_s_inlined_putn_at_516_18466);
    _s_inlined_putn_at_516_18466 = NOVALUE;

    /** 	put4(4+init_free*8)   -- allocated size*/
    if (_init_free_18397 == (short)_init_free_18397)
    _10417 = _init_free_18397 * 8;
    else
    _10417 = NewDouble(_init_free_18397 * (double)8);
    if (IS_ATOM_INT(_10417)) {
        _10418 = 4 + _10417;
        if ((long)((unsigned long)_10418 + (unsigned long)HIGH_BITS) >= 0) 
        _10418 = NewDouble((double)_10418);
    }
    else {
        _10418 = NewDouble((double)4 + DBL_PTR(_10417)->dbl);
    }
    DeRef(_10417);
    _10417 = NOVALUE;
    DeRef(_x_inlined_put4_at_545_18470);
    _x_inlined_put4_at_545_18470 = _10418;
    _10418 = NOVALUE;

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_49mem0_17414)){
        poke4_addr = (unsigned long *)_49mem0_17414;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_49mem0_17414)->dbl);
    }
    if (IS_ATOM_INT(_x_inlined_put4_at_545_18470)) {
        *poke4_addr = (unsigned long)_x_inlined_put4_at_545_18470;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_x_inlined_put4_at_545_18470)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at548_18471);
    _1 = (int)SEQ_PTR(_49memseq_17649);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at548_18471 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_49current_db_17372, _put4_1__tmp_at548_18471); // DJP 

    /** end procedure*/
    goto L14; // [569] 572
L14: 
    DeRef(_x_inlined_put4_at_545_18470);
    _x_inlined_put4_at_545_18470 = NOVALUE;
    DeRefi(_put4_1__tmp_at548_18471);
    _put4_1__tmp_at548_18471 = NOVALUE;

    /** 	putn(repeat(0, init_free * 8))*/
    _10419 = _init_free_18397 * 8;
    _10420 = Repeat(0, _10419);
    _10419 = NOVALUE;
    DeRefi(_s_inlined_putn_at_584_18475);
    _s_inlined_putn_at_584_18475 = _10420;
    _10420 = NOVALUE;

    /** 	puts(current_db, s)*/
    EPuts(_49current_db_17372, _s_inlined_putn_at_584_18475); // DJP 

    /** end procedure*/
    goto L15; // [598] 601
L15: 
    DeRefi(_s_inlined_putn_at_584_18475);
    _s_inlined_putn_at_584_18475 = NOVALUE;

    /** 	return DB_OK*/
    DeRefDS(_path_18394);
    return 0;
    ;
}


int _49db_open(int _path_18478, int _lock_method_18479)
{
    int _db_18480 = NOVALUE;
    int _magic_18481 = NOVALUE;
    int _lock_file_1__tmp_at141_18508 = NOVALUE;
    int _lock_file_inlined_lock_file_at_141_18507 = NOVALUE;
    int _lock_file_1__tmp_at181_18515 = NOVALUE;
    int _lock_file_inlined_lock_file_at_181_18514 = NOVALUE;
    int _10431 = NOVALUE;
    int _10429 = NOVALUE;
    int _10427 = NOVALUE;
    int _10425 = NOVALUE;
    int _10424 = NOVALUE;
    int _10422 = NOVALUE;
    int _0, _1, _2;
    

    /** 	db = find(path, Known_Aliases)*/
    _db_18480 = find_from(_path_18478, _49Known_Aliases_17393, 1);

    /** 	if db then*/
    if (_db_18480 == 0)
    {
        goto L1; // [16] 54
    }
    else{
    }

    /** 		path = Alias_Details[db][1]*/
    _2 = (int)SEQ_PTR(_49Alias_Details_17394);
    _10422 = (int)*(((s1_ptr)_2)->base + _db_18480);
    DeRefDS(_path_18478);
    _2 = (int)SEQ_PTR(_10422);
    _path_18478 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_path_18478);
    _10422 = NOVALUE;

    /** 		lock_method = Alias_Details[db][2][CONNECT_LOCK]*/
    _2 = (int)SEQ_PTR(_49Alias_Details_17394);
    _10424 = (int)*(((s1_ptr)_2)->base + _db_18480);
    _2 = (int)SEQ_PTR(_10424);
    _10425 = (int)*(((s1_ptr)_2)->base + 2);
    _10424 = NOVALUE;
    _2 = (int)SEQ_PTR(_10425);
    _lock_method_18479 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_lock_method_18479)){
        _lock_method_18479 = (long)DBL_PTR(_lock_method_18479)->dbl;
    }
    _10425 = NOVALUE;
    goto L2; // [51] 70
L1: 

    /** 		path = filesys:canonical_path( filesys:defaultext(path, "edb") )*/
    RefDS(_path_18478);
    RefDS(_10375);
    _10427 = _17defaultext(_path_18478, _10375);
    _0 = _path_18478;
    _path_18478 = _17canonical_path(_10427, 0, 0);
    DeRefDS(_0);
    _10427 = NOVALUE;
L2: 

    /** 	if lock_method = DB_LOCK_NO or*/
    _10429 = (_lock_method_18479 == 0);
    if (_10429 != 0) {
        goto L3; // [76] 89
    }
    _10431 = (_lock_method_18479 == 2);
    if (_10431 == 0)
    {
        DeRef(_10431);
        _10431 = NOVALUE;
        goto L4; // [85] 99
    }
    else{
        DeRef(_10431);
        _10431 = NOVALUE;
    }
L3: 

    /** 		db = open(path, "ub")*/
    _db_18480 = EOpen(_path_18478, _10401, 0);
    goto L5; // [96] 107
L4: 

    /** 		db = open(path, "rb")*/
    _db_18480 = EOpen(_path_18478, _3739, 0);
L5: 

    /** ifdef WINDOWS then*/

    /** 	if lock_method = DB_LOCK_SHARED then*/
    if (_lock_method_18479 != 1)
    goto L6; // [111] 121

    /** 		lock_method = DB_LOCK_EXCLUSIVE*/
    _lock_method_18479 = 2;
L6: 

    /** 	if db = -1 then*/
    if (_db_18480 != -1)
    goto L7; // [123] 134

    /** 		return DB_OPEN_FAIL*/
    DeRefDS(_path_18478);
    DeRef(_10429);
    _10429 = NOVALUE;
    return -1;
L7: 

    /** 	if lock_method = DB_LOCK_EXCLUSIVE then*/
    if (_lock_method_18479 != 2)
    goto L8; // [136] 174

    /** 		if not io:lock_file(db, io:LOCK_EXCLUSIVE, {}) then*/

    /** 	return machine_func(M_LOCK_FILE, {fn, t, r})*/
    _0 = _lock_file_1__tmp_at141_18508;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _db_18480;
    *((int *)(_2+8)) = 2;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    _lock_file_1__tmp_at141_18508 = MAKE_SEQ(_1);
    DeRef(_0);
    _lock_file_inlined_lock_file_at_141_18507 = machine(61, _lock_file_1__tmp_at141_18508);
    DeRef(_lock_file_1__tmp_at141_18508);
    _lock_file_1__tmp_at141_18508 = NOVALUE;
    if (_lock_file_inlined_lock_file_at_141_18507 != 0)
    goto L9; // [157] 213

    /** 			close(db)*/
    EClose(_db_18480);

    /** 			return DB_LOCK_FAIL*/
    DeRefDS(_path_18478);
    DeRef(_10429);
    _10429 = NOVALUE;
    return -3;
    goto L9; // [171] 213
L8: 

    /** 	elsif lock_method = DB_LOCK_SHARED then*/
    if (_lock_method_18479 != 1)
    goto LA; // [176] 212

    /** 		if not io:lock_file(db, io:LOCK_SHARED, {}) then*/

    /** 	return machine_func(M_LOCK_FILE, {fn, t, r})*/
    _0 = _lock_file_1__tmp_at181_18515;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _db_18480;
    *((int *)(_2+8)) = 1;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    _lock_file_1__tmp_at181_18515 = MAKE_SEQ(_1);
    DeRef(_0);
    _lock_file_inlined_lock_file_at_181_18514 = machine(61, _lock_file_1__tmp_at181_18515);
    DeRef(_lock_file_1__tmp_at181_18515);
    _lock_file_1__tmp_at181_18515 = NOVALUE;
    if (_lock_file_inlined_lock_file_at_181_18514 != 0)
    goto LB; // [197] 211

    /** 			close(db)*/
    EClose(_db_18480);

    /** 			return DB_LOCK_FAIL*/
    DeRefDS(_path_18478);
    DeRef(_10429);
    _10429 = NOVALUE;
    return -3;
LB: 
LA: 
L9: 

    /** 	magic = getc(db)*/
    if (_db_18480 != last_r_file_no) {
        last_r_file_ptr = which_file(_db_18480, EF_READ);
        last_r_file_no = _db_18480;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _magic_18481 = getKBchar();
        }
        else
        _magic_18481 = getc(last_r_file_ptr);
    }
    else
    _magic_18481 = getc(last_r_file_ptr);

    /** 	if magic != DB_MAGIC then*/
    if (_magic_18481 == 77)
    goto LC; // [220] 235

    /** 		close(db)*/
    EClose(_db_18480);

    /** 		return DB_OPEN_FAIL*/
    DeRefDS(_path_18478);
    DeRef(_10429);
    _10429 = NOVALUE;
    return -1;
LC: 

    /** 	save_keys()*/
    _49save_keys();

    /** 	current_db = db */
    _49current_db_17372 = _db_18480;

    /** 	current_table_pos = -1*/
    DeRef(_49current_table_pos_17373);
    _49current_table_pos_17373 = -1;

    /** 	current_table_name = ""*/
    RefDS(_5);
    DeRef(_49current_table_name_17374);
    _49current_table_name_17374 = _5;

    /** 	current_lock = lock_method*/
    _49current_lock_17378 = _lock_method_18479;

    /** 	db_names = append(db_names, path)*/
    RefDS(_path_18478);
    Append(&_49db_names_17375, _49db_names_17375, _path_18478);

    /** 	db_lock_methods = append(db_lock_methods, lock_method)*/
    Append(&_49db_lock_methods_17377, _49db_lock_methods_17377, _lock_method_18479);

    /** 	db_file_nums = append(db_file_nums, db)*/
    Append(&_49db_file_nums_17376, _49db_file_nums_17376, _db_18480);

    /** 	return DB_OK*/
    DeRefDS(_path_18478);
    DeRef(_10429);
    _10429 = NOVALUE;
    return 0;
    ;
}


int _49db_select(int _path_18525, int _lock_method_18526)
{
    int _index_18527 = NOVALUE;
    int _10451 = NOVALUE;
    int _10449 = NOVALUE;
    int _10448 = NOVALUE;
    int _10446 = NOVALUE;
    int _0, _1, _2;
    

    /** 	index = find(path, Known_Aliases)*/
    _index_18527 = find_from(_path_18525, _49Known_Aliases_17393, 1);

    /** 	if index then*/
    if (_index_18527 == 0)
    {
        goto L1; // [16] 54
    }
    else{
    }

    /** 		path = Alias_Details[index][1]*/
    _2 = (int)SEQ_PTR(_49Alias_Details_17394);
    _10446 = (int)*(((s1_ptr)_2)->base + _index_18527);
    DeRefDS(_path_18525);
    _2 = (int)SEQ_PTR(_10446);
    _path_18525 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_path_18525);
    _10446 = NOVALUE;

    /** 		lock_method = Alias_Details[index][2][CONNECT_LOCK]*/
    _2 = (int)SEQ_PTR(_49Alias_Details_17394);
    _10448 = (int)*(((s1_ptr)_2)->base + _index_18527);
    _2 = (int)SEQ_PTR(_10448);
    _10449 = (int)*(((s1_ptr)_2)->base + 2);
    _10448 = NOVALUE;
    _2 = (int)SEQ_PTR(_10449);
    _lock_method_18526 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_lock_method_18526)){
        _lock_method_18526 = (long)DBL_PTR(_lock_method_18526)->dbl;
    }
    _10449 = NOVALUE;
    goto L2; // [51] 70
L1: 

    /** 		path = filesys:canonical_path( filesys:defaultext(path, "edb") )*/
    RefDS(_path_18525);
    RefDS(_10375);
    _10451 = _17defaultext(_path_18525, _10375);
    _0 = _path_18525;
    _path_18525 = _17canonical_path(_10451, 0, 0);
    DeRefDS(_0);
    _10451 = NOVALUE;
L2: 

    /** 	index = eu:find(path, db_names)*/
    _index_18527 = find_from(_path_18525, _49db_names_17375, 1);

    /** 	if index = 0 then*/
    if (_index_18527 != 0)
    goto L3; // [81] 130

    /** 		if lock_method = -1 then*/
    if (_lock_method_18526 != -1)
    goto L4; // [87] 98

    /** 			return DB_OPEN_FAIL*/
    DeRefDS(_path_18525);
    return -1;
L4: 

    /** 		index = db_open(path, lock_method)*/
    RefDS(_path_18525);
    _index_18527 = _49db_open(_path_18525, _lock_method_18526);
    if (!IS_ATOM_INT(_index_18527)) {
        _1 = (long)(DBL_PTR(_index_18527)->dbl);
        DeRefDS(_index_18527);
        _index_18527 = _1;
    }

    /** 		if index != DB_OK then*/
    if (_index_18527 == 0)
    goto L5; // [109] 120

    /** 			return index*/
    DeRefDS(_path_18525);
    return _index_18527;
L5: 

    /** 		index = eu:find(path, db_names)*/
    _index_18527 = find_from(_path_18525, _49db_names_17375, 1);
L3: 

    /** 	save_keys()*/
    _49save_keys();

    /** 	current_db = db_file_nums[index]*/
    _2 = (int)SEQ_PTR(_49db_file_nums_17376);
    _49current_db_17372 = (int)*(((s1_ptr)_2)->base + _index_18527);
    if (!IS_ATOM_INT(_49current_db_17372))
    _49current_db_17372 = (long)DBL_PTR(_49current_db_17372)->dbl;

    /** 	current_lock = db_lock_methods[index]*/
    _2 = (int)SEQ_PTR(_49db_lock_methods_17377);
    _49current_lock_17378 = (int)*(((s1_ptr)_2)->base + _index_18527);
    if (!IS_ATOM_INT(_49current_lock_17378))
    _49current_lock_17378 = (long)DBL_PTR(_49current_lock_17378)->dbl;

    /** 	current_table_pos = -1*/
    DeRef(_49current_table_pos_17373);
    _49current_table_pos_17373 = -1;

    /** 	current_table_name = ""*/
    RefDS(_5);
    DeRef(_49current_table_name_17374);
    _49current_table_name_17374 = _5;

    /** 	key_pointers = {}*/
    RefDS(_5);
    DeRef(_49key_pointers_17379);
    _49key_pointers_17379 = _5;

    /** 	return DB_OK*/
    DeRefDS(_path_18525);
    return 0;
    ;
}


void _49db_close()
{
    int _unlock_file_1__tmp_at25_18556 = NOVALUE;
    int _index_18551 = NOVALUE;
    int _10468 = NOVALUE;
    int _10467 = NOVALUE;
    int _10466 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if current_db = -1 then*/
    if (_49current_db_17372 != -1)
    goto L1; // [5] 15

    /** 		return*/
    return;
L1: 

    /** 	if current_lock then*/
    if (_49current_lock_17378 == 0)
    {
        goto L2; // [19] 43
    }
    else{
    }

    /** 		io:unlock_file(current_db, {})*/

    /** 	machine_proc(M_UNLOCK_FILE, {fn, r})*/
    RefDS(_5);
    DeRef(_unlock_file_1__tmp_at25_18556);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _49current_db_17372;
    ((int *)_2)[2] = _5;
    _unlock_file_1__tmp_at25_18556 = MAKE_SEQ(_1);
    machine(62, _unlock_file_1__tmp_at25_18556);

    /** end procedure*/
    goto L3; // [37] 40
L3: 
    DeRef(_unlock_file_1__tmp_at25_18556);
    _unlock_file_1__tmp_at25_18556 = NOVALUE;
L2: 

    /** 	close(current_db)*/
    EClose(_49current_db_17372);

    /** 	index = eu:find(current_db, db_file_nums)*/
    _index_18551 = find_from(_49current_db_17372, _49db_file_nums_17376, 1);

    /** 	db_names = remove(db_names, index)*/
    {
        s1_ptr assign_space = SEQ_PTR(_49db_names_17375);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_index_18551)) ? _index_18551 : (long)(DBL_PTR(_index_18551)->dbl);
        int stop = (IS_ATOM_INT(_index_18551)) ? _index_18551 : (long)(DBL_PTR(_index_18551)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_49db_names_17375), start, &_49db_names_17375 );
            }
            else Tail(SEQ_PTR(_49db_names_17375), stop+1, &_49db_names_17375);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_49db_names_17375), start, &_49db_names_17375);
        }
        else {
            assign_slice_seq = &assign_space;
            _49db_names_17375 = Remove_elements(start, stop, (SEQ_PTR(_49db_names_17375)->ref == 1));
        }
    }

    /** 	db_file_nums = remove(db_file_nums, index)*/
    {
        s1_ptr assign_space = SEQ_PTR(_49db_file_nums_17376);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_index_18551)) ? _index_18551 : (long)(DBL_PTR(_index_18551)->dbl);
        int stop = (IS_ATOM_INT(_index_18551)) ? _index_18551 : (long)(DBL_PTR(_index_18551)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_49db_file_nums_17376), start, &_49db_file_nums_17376 );
            }
            else Tail(SEQ_PTR(_49db_file_nums_17376), stop+1, &_49db_file_nums_17376);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_49db_file_nums_17376), start, &_49db_file_nums_17376);
        }
        else {
            assign_slice_seq = &assign_space;
            _49db_file_nums_17376 = Remove_elements(start, stop, (SEQ_PTR(_49db_file_nums_17376)->ref == 1));
        }
    }

    /** 	db_lock_methods = remove(db_lock_methods, index)*/
    {
        s1_ptr assign_space = SEQ_PTR(_49db_lock_methods_17377);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_index_18551)) ? _index_18551 : (long)(DBL_PTR(_index_18551)->dbl);
        int stop = (IS_ATOM_INT(_index_18551)) ? _index_18551 : (long)(DBL_PTR(_index_18551)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_49db_lock_methods_17377), start, &_49db_lock_methods_17377 );
            }
            else Tail(SEQ_PTR(_49db_lock_methods_17377), stop+1, &_49db_lock_methods_17377);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_49db_lock_methods_17377), start, &_49db_lock_methods_17377);
        }
        else {
            assign_slice_seq = &assign_space;
            _49db_lock_methods_17377 = Remove_elements(start, stop, (SEQ_PTR(_49db_lock_methods_17377)->ref == 1));
        }
    }

    /** 	for i = length(cache_index) to 1 by -1 do*/
    if (IS_SEQUENCE(_49cache_index_17381)){
            _10466 = SEQ_PTR(_49cache_index_17381)->length;
    }
    else {
        _10466 = 1;
    }
    {
        int _i_18562;
        _i_18562 = _10466;
L4: 
        if (_i_18562 < 1){
            goto L5; // [94] 145
        }

        /** 		if cache_index[i][1] = current_db then*/
        _2 = (int)SEQ_PTR(_49cache_index_17381);
        _10467 = (int)*(((s1_ptr)_2)->base + _i_18562);
        _2 = (int)SEQ_PTR(_10467);
        _10468 = (int)*(((s1_ptr)_2)->base + 1);
        _10467 = NOVALUE;
        if (binary_op_a(NOTEQ, _10468, _49current_db_17372)){
            _10468 = NOVALUE;
            goto L6; // [115] 138
        }
        _10468 = NOVALUE;

        /** 			cache_index = remove(cache_index, i)*/
        {
            s1_ptr assign_space = SEQ_PTR(_49cache_index_17381);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_i_18562)) ? _i_18562 : (long)(DBL_PTR(_i_18562)->dbl);
            int stop = (IS_ATOM_INT(_i_18562)) ? _i_18562 : (long)(DBL_PTR(_i_18562)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<0) {
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_49cache_index_17381), start, &_49cache_index_17381 );
                }
                else Tail(SEQ_PTR(_49cache_index_17381), stop+1, &_49cache_index_17381);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_49cache_index_17381), start, &_49cache_index_17381);
            }
            else {
                assign_slice_seq = &assign_space;
                _49cache_index_17381 = Remove_elements(start, stop, (SEQ_PTR(_49cache_index_17381)->ref == 1));
            }
        }

        /** 			key_cache = remove(key_cache, i)*/
        {
            s1_ptr assign_space = SEQ_PTR(_49key_cache_17380);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_i_18562)) ? _i_18562 : (long)(DBL_PTR(_i_18562)->dbl);
            int stop = (IS_ATOM_INT(_i_18562)) ? _i_18562 : (long)(DBL_PTR(_i_18562)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<0) {
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_49key_cache_17380), start, &_49key_cache_17380 );
                }
                else Tail(SEQ_PTR(_49key_cache_17380), stop+1, &_49key_cache_17380);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_49key_cache_17380), start, &_49key_cache_17380);
            }
            else {
                assign_slice_seq = &assign_space;
                _49key_cache_17380 = Remove_elements(start, stop, (SEQ_PTR(_49key_cache_17380)->ref == 1));
            }
        }
L6: 

        /** 	end for*/
        _i_18562 = _i_18562 + -1;
        goto L4; // [140] 101
L5: 
        ;
    }

    /** 	current_table_pos = -1*/
    DeRef(_49current_table_pos_17373);
    _49current_table_pos_17373 = -1;

    /** 	current_table_name = ""	*/
    RefDS(_5);
    DeRef(_49current_table_name_17374);
    _49current_table_name_17374 = _5;

    /** 	current_db = -1*/
    _49current_db_17372 = -1;

    /** 	key_pointers = {}*/
    RefDS(_5);
    DeRef(_49key_pointers_17379);
    _49key_pointers_17379 = _5;

    /** end procedure*/
    return;
    ;
}


int _49table_find(int _name_18572)
{
    int _tables_18573 = NOVALUE;
    int _nt_18574 = NOVALUE;
    int _t_header_18575 = NOVALUE;
    int _name_ptr_18576 = NOVALUE;
    int _seek_1__tmp_at6_18579 = NOVALUE;
    int _seek_inlined_seek_at_6_18578 = NOVALUE;
    int _seek_1__tmp_at44_18586 = NOVALUE;
    int _seek_inlined_seek_at_44_18585 = NOVALUE;
    int _seek_1__tmp_at84_18594 = NOVALUE;
    int _seek_inlined_seek_at_84_18593 = NOVALUE;
    int _seek_1__tmp_at106_18598 = NOVALUE;
    int _seek_inlined_seek_at_106_18597 = NOVALUE;
    int _10479 = NOVALUE;
    int _10477 = NOVALUE;
    int _10472 = NOVALUE;
    int _0, _1, _2;
    

    /** 	io:seek(current_db, TABLE_HEADERS)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at6_18579);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _49current_db_17372;
    ((int *)_2)[2] = 3;
    _seek_1__tmp_at6_18579 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_6_18578 = machine(19, _seek_1__tmp_at6_18579);
    DeRefi(_seek_1__tmp_at6_18579);
    _seek_1__tmp_at6_18579 = NOVALUE;

    /** 	if length(vLastErrors) > 0 then return -1 end if*/
    if (IS_SEQUENCE(_49vLastErrors_17396)){
            _10472 = SEQ_PTR(_49vLastErrors_17396)->length;
    }
    else {
        _10472 = 1;
    }
    if (_10472 <= 0)
    goto L1; // [27] 36
    DeRefDS(_name_18572);
    DeRef(_tables_18573);
    DeRef(_nt_18574);
    DeRef(_t_header_18575);
    DeRef(_name_ptr_18576);
    return -1;
L1: 

    /** 	tables = get4()*/
    _0 = _tables_18573;
    _tables_18573 = _49get4();
    DeRef(_0);

    /** 	io:seek(current_db, tables)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_tables_18573);
    DeRef(_seek_1__tmp_at44_18586);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _49current_db_17372;
    ((int *)_2)[2] = _tables_18573;
    _seek_1__tmp_at44_18586 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_44_18585 = machine(19, _seek_1__tmp_at44_18586);
    DeRef(_seek_1__tmp_at44_18586);
    _seek_1__tmp_at44_18586 = NOVALUE;

    /** 	nt = get4()*/
    _0 = _nt_18574;
    _nt_18574 = _49get4();
    DeRef(_0);

    /** 	t_header = tables+4*/
    DeRef(_t_header_18575);
    if (IS_ATOM_INT(_tables_18573)) {
        _t_header_18575 = _tables_18573 + 4;
        if ((long)((unsigned long)_t_header_18575 + (unsigned long)HIGH_BITS) >= 0) 
        _t_header_18575 = NewDouble((double)_t_header_18575);
    }
    else {
        _t_header_18575 = NewDouble(DBL_PTR(_tables_18573)->dbl + (double)4);
    }

    /** 	for i = 1 to nt do*/
    Ref(_nt_18574);
    DeRef(_10477);
    _10477 = _nt_18574;
    {
        int _i_18590;
        _i_18590 = 1;
L2: 
        if (binary_op_a(GREATER, _i_18590, _10477)){
            goto L3; // [74] 150
        }

        /** 		io:seek(current_db, t_header)*/

        /** 	return machine_func(M_SEEK, {fn, pos})*/
        Ref(_t_header_18575);
        DeRef(_seek_1__tmp_at84_18594);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _49current_db_17372;
        ((int *)_2)[2] = _t_header_18575;
        _seek_1__tmp_at84_18594 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_84_18593 = machine(19, _seek_1__tmp_at84_18594);
        DeRef(_seek_1__tmp_at84_18594);
        _seek_1__tmp_at84_18594 = NOVALUE;

        /** 		name_ptr = get4()*/
        _0 = _name_ptr_18576;
        _name_ptr_18576 = _49get4();
        DeRef(_0);

        /** 		io:seek(current_db, name_ptr)*/

        /** 	return machine_func(M_SEEK, {fn, pos})*/
        Ref(_name_ptr_18576);
        DeRef(_seek_1__tmp_at106_18598);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _49current_db_17372;
        ((int *)_2)[2] = _name_ptr_18576;
        _seek_1__tmp_at106_18598 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_106_18597 = machine(19, _seek_1__tmp_at106_18598);
        DeRef(_seek_1__tmp_at106_18598);
        _seek_1__tmp_at106_18598 = NOVALUE;

        /** 		if equal_string(name) > 0 then*/
        RefDS(_name_18572);
        _10479 = _49equal_string(_name_18572);
        if (binary_op_a(LESSEQ, _10479, 0)){
            DeRef(_10479);
            _10479 = NOVALUE;
            goto L4; // [126] 137
        }
        DeRef(_10479);
        _10479 = NOVALUE;

        /** 			return t_header*/
        DeRef(_i_18590);
        DeRefDS(_name_18572);
        DeRef(_tables_18573);
        DeRef(_nt_18574);
        DeRef(_name_ptr_18576);
        return _t_header_18575;
L4: 

        /** 		t_header += SIZEOF_TABLE_HEADER*/
        _0 = _t_header_18575;
        if (IS_ATOM_INT(_t_header_18575)) {
            _t_header_18575 = _t_header_18575 + 16;
            if ((long)((unsigned long)_t_header_18575 + (unsigned long)HIGH_BITS) >= 0) 
            _t_header_18575 = NewDouble((double)_t_header_18575);
        }
        else {
            _t_header_18575 = NewDouble(DBL_PTR(_t_header_18575)->dbl + (double)16);
        }
        DeRef(_0);

        /** 	end for*/
        _0 = _i_18590;
        if (IS_ATOM_INT(_i_18590)) {
            _i_18590 = _i_18590 + 1;
            if ((long)((unsigned long)_i_18590 +(unsigned long) HIGH_BITS) >= 0){
                _i_18590 = NewDouble((double)_i_18590);
            }
        }
        else {
            _i_18590 = binary_op_a(PLUS, _i_18590, 1);
        }
        DeRef(_0);
        goto L2; // [145] 81
L3: 
        ;
        DeRef(_i_18590);
    }

    /** 	return -1*/
    DeRefDS(_name_18572);
    DeRef(_tables_18573);
    DeRef(_nt_18574);
    DeRef(_t_header_18575);
    DeRef(_name_ptr_18576);
    return -1;
    ;
}


int _49db_select_table(int _name_18605)
{
    int _table_18606 = NOVALUE;
    int _nkeys_18607 = NOVALUE;
    int _index_18608 = NOVALUE;
    int _block_ptr_18609 = NOVALUE;
    int _block_size_18610 = NOVALUE;
    int _blocks_18611 = NOVALUE;
    int _k_18612 = NOVALUE;
    int _seek_1__tmp_at120_18631 = NOVALUE;
    int _seek_inlined_seek_at_120_18630 = NOVALUE;
    int _pos_inlined_seek_at_117_18629 = NOVALUE;
    int _seek_1__tmp_at178_18641 = NOVALUE;
    int _seek_inlined_seek_at_178_18640 = NOVALUE;
    int _seek_1__tmp_at205_18646 = NOVALUE;
    int _seek_inlined_seek_at_205_18645 = NOVALUE;
    int _10500 = NOVALUE;
    int _10499 = NOVALUE;
    int _10496 = NOVALUE;
    int _10491 = NOVALUE;
    int _10486 = NOVALUE;
    int _10482 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if equal(current_table_name, name) then*/
    if (_49current_table_name_17374 == _name_18605)
    _10482 = 1;
    else if (IS_ATOM_INT(_49current_table_name_17374) && IS_ATOM_INT(_name_18605))
    _10482 = 0;
    else
    _10482 = (compare(_49current_table_name_17374, _name_18605) == 0);
    if (_10482 == 0)
    {
        _10482 = NOVALUE;
        goto L1; // [11] 21
    }
    else{
        _10482 = NOVALUE;
    }

    /** 		return DB_OK*/
    DeRefDS(_name_18605);
    DeRef(_table_18606);
    DeRef(_nkeys_18607);
    DeRef(_index_18608);
    DeRef(_block_ptr_18609);
    DeRef(_block_size_18610);
    return 0;
L1: 

    /** 	table = table_find(name)*/
    RefDS(_name_18605);
    _0 = _table_18606;
    _table_18606 = _49table_find(_name_18605);
    DeRef(_0);

    /** 	if table = -1 then*/
    if (binary_op_a(NOTEQ, _table_18606, -1)){
        goto L2; // [29] 40
    }

    /** 		return DB_OPEN_FAIL*/
    DeRefDS(_name_18605);
    DeRef(_table_18606);
    DeRef(_nkeys_18607);
    DeRef(_index_18608);
    DeRef(_block_ptr_18609);
    DeRef(_block_size_18610);
    return -1;
L2: 

    /** 	save_keys()*/
    _49save_keys();

    /** 	current_table_pos = table*/
    Ref(_table_18606);
    DeRef(_49current_table_pos_17373);
    _49current_table_pos_17373 = _table_18606;

    /** 	current_table_name = name*/
    RefDS(_name_18605);
    DeRef(_49current_table_name_17374);
    _49current_table_name_17374 = _name_18605;

    /** 	k = 0*/
    _k_18612 = 0;

    /** 	if caching_option = 1 then*/

    /** 		k = eu:find({current_db, current_table_pos}, cache_index)*/
    Ref(_49current_table_pos_17373);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _49current_db_17372;
    ((int *)_2)[2] = _49current_table_pos_17373;
    _10486 = MAKE_SEQ(_1);
    _k_18612 = find_from(_10486, _49cache_index_17381, 1);
    DeRefDS(_10486);
    _10486 = NOVALUE;

    /** 		if k != 0 then*/
    if (_k_18612 == 0)
    goto L3; // [88] 103

    /** 			key_pointers = key_cache[k]*/
    DeRef(_49key_pointers_17379);
    _2 = (int)SEQ_PTR(_49key_cache_17380);
    _49key_pointers_17379 = (int)*(((s1_ptr)_2)->base + _k_18612);
    Ref(_49key_pointers_17379);
L3: 

    /** 	if k = 0 then*/
    if (_k_18612 != 0)
    goto L4; // [106] 269

    /** 		io:seek(current_db, table+4)*/
    if (IS_ATOM_INT(_table_18606)) {
        _10491 = _table_18606 + 4;
        if ((long)((unsigned long)_10491 + (unsigned long)HIGH_BITS) >= 0) 
        _10491 = NewDouble((double)_10491);
    }
    else {
        _10491 = NewDouble(DBL_PTR(_table_18606)->dbl + (double)4);
    }
    DeRef(_pos_inlined_seek_at_117_18629);
    _pos_inlined_seek_at_117_18629 = _10491;
    _10491 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_117_18629);
    DeRef(_seek_1__tmp_at120_18631);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _49current_db_17372;
    ((int *)_2)[2] = _pos_inlined_seek_at_117_18629;
    _seek_1__tmp_at120_18631 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_120_18630 = machine(19, _seek_1__tmp_at120_18631);
    DeRef(_pos_inlined_seek_at_117_18629);
    _pos_inlined_seek_at_117_18629 = NOVALUE;
    DeRef(_seek_1__tmp_at120_18631);
    _seek_1__tmp_at120_18631 = NOVALUE;

    /** 		nkeys = get4()*/
    _0 = _nkeys_18607;
    _nkeys_18607 = _49get4();
    DeRef(_0);

    /** 		blocks = get4()*/
    _blocks_18611 = _49get4();
    if (!IS_ATOM_INT(_blocks_18611)) {
        _1 = (long)(DBL_PTR(_blocks_18611)->dbl);
        DeRefDS(_blocks_18611);
        _blocks_18611 = _1;
    }

    /** 		index = get4()*/
    _0 = _index_18608;
    _index_18608 = _49get4();
    DeRef(_0);

    /** 		key_pointers = repeat(0, nkeys)*/
    DeRef(_49key_pointers_17379);
    _49key_pointers_17379 = Repeat(0, _nkeys_18607);

    /** 		k = 1*/
    _k_18612 = 1;

    /** 		for b = 0 to blocks-1 do*/
    _10496 = _blocks_18611 - 1;
    if ((long)((unsigned long)_10496 +(unsigned long) HIGH_BITS) >= 0){
        _10496 = NewDouble((double)_10496);
    }
    {
        int _b_18637;
        _b_18637 = 0;
L5: 
        if (binary_op_a(GREATER, _b_18637, _10496)){
            goto L6; // [168] 268
        }

        /** 			io:seek(current_db, index)*/

        /** 	return machine_func(M_SEEK, {fn, pos})*/
        Ref(_index_18608);
        DeRef(_seek_1__tmp_at178_18641);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _49current_db_17372;
        ((int *)_2)[2] = _index_18608;
        _seek_1__tmp_at178_18641 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_178_18640 = machine(19, _seek_1__tmp_at178_18641);
        DeRef(_seek_1__tmp_at178_18641);
        _seek_1__tmp_at178_18641 = NOVALUE;

        /** 			block_size = get4()*/
        _0 = _block_size_18610;
        _block_size_18610 = _49get4();
        DeRef(_0);

        /** 			block_ptr = get4()*/
        _0 = _block_ptr_18609;
        _block_ptr_18609 = _49get4();
        DeRef(_0);

        /** 			io:seek(current_db, block_ptr)*/

        /** 	return machine_func(M_SEEK, {fn, pos})*/
        Ref(_block_ptr_18609);
        DeRef(_seek_1__tmp_at205_18646);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _49current_db_17372;
        ((int *)_2)[2] = _block_ptr_18609;
        _seek_1__tmp_at205_18646 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_205_18645 = machine(19, _seek_1__tmp_at205_18646);
        DeRef(_seek_1__tmp_at205_18646);
        _seek_1__tmp_at205_18646 = NOVALUE;

        /** 			for j = 1 to block_size do*/
        Ref(_block_size_18610);
        DeRef(_10499);
        _10499 = _block_size_18610;
        {
            int _j_18648;
            _j_18648 = 1;
L7: 
            if (binary_op_a(GREATER, _j_18648, _10499)){
                goto L8; // [224] 255
            }

            /** 				key_pointers[k] = get4()*/
            _10500 = _49get4();
            _2 = (int)SEQ_PTR(_49key_pointers_17379);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _49key_pointers_17379 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _k_18612);
            _1 = *(int *)_2;
            *(int *)_2 = _10500;
            if( _1 != _10500 ){
                DeRef(_1);
            }
            _10500 = NOVALUE;

            /** 				k += 1*/
            _k_18612 = _k_18612 + 1;

            /** 			end for*/
            _0 = _j_18648;
            if (IS_ATOM_INT(_j_18648)) {
                _j_18648 = _j_18648 + 1;
                if ((long)((unsigned long)_j_18648 +(unsigned long) HIGH_BITS) >= 0){
                    _j_18648 = NewDouble((double)_j_18648);
                }
            }
            else {
                _j_18648 = binary_op_a(PLUS, _j_18648, 1);
            }
            DeRef(_0);
            goto L7; // [250] 231
L8: 
            ;
            DeRef(_j_18648);
        }

        /** 			index += 8*/
        _0 = _index_18608;
        if (IS_ATOM_INT(_index_18608)) {
            _index_18608 = _index_18608 + 8;
            if ((long)((unsigned long)_index_18608 + (unsigned long)HIGH_BITS) >= 0) 
            _index_18608 = NewDouble((double)_index_18608);
        }
        else {
            _index_18608 = NewDouble(DBL_PTR(_index_18608)->dbl + (double)8);
        }
        DeRef(_0);

        /** 		end for*/
        _0 = _b_18637;
        if (IS_ATOM_INT(_b_18637)) {
            _b_18637 = _b_18637 + 1;
            if ((long)((unsigned long)_b_18637 +(unsigned long) HIGH_BITS) >= 0){
                _b_18637 = NewDouble((double)_b_18637);
            }
        }
        else {
            _b_18637 = binary_op_a(PLUS, _b_18637, 1);
        }
        DeRef(_0);
        goto L5; // [263] 175
L6: 
        ;
        DeRef(_b_18637);
    }
L4: 

    /** 	return DB_OK*/
    DeRefDS(_name_18605);
    DeRef(_table_18606);
    DeRef(_nkeys_18607);
    DeRef(_index_18608);
    DeRef(_block_ptr_18609);
    DeRef(_block_size_18610);
    DeRef(_10496);
    _10496 = NOVALUE;
    return 0;
    ;
}


int _49db_create_table(int _name_18657, int _init_records_18658)
{
    int _name_ptr_18659 = NOVALUE;
    int _nt_18660 = NOVALUE;
    int _tables_18661 = NOVALUE;
    int _newtables_18662 = NOVALUE;
    int _table_18663 = NOVALUE;
    int _records_ptr_18664 = NOVALUE;
    int _size_18665 = NOVALUE;
    int _newsize_18666 = NOVALUE;
    int _index_ptr_18667 = NOVALUE;
    int _remaining_18668 = NOVALUE;
    int _init_index_18669 = NOVALUE;
    int _seek_1__tmp_at68_18683 = NOVALUE;
    int _seek_inlined_seek_at_68_18682 = NOVALUE;
    int _seek_1__tmp_at97_18689 = NOVALUE;
    int _seek_inlined_seek_at_97_18688 = NOVALUE;
    int _pos_inlined_seek_at_94_18687 = NOVALUE;
    int _put4_1__tmp_at159_18702 = NOVALUE;
    int _seek_1__tmp_at196_18707 = NOVALUE;
    int _seek_inlined_seek_at_196_18706 = NOVALUE;
    int _pos_inlined_seek_at_193_18705 = NOVALUE;
    int _seek_1__tmp_at239_18715 = NOVALUE;
    int _seek_inlined_seek_at_239_18714 = NOVALUE;
    int _pos_inlined_seek_at_236_18713 = NOVALUE;
    int _s_inlined_putn_at_288_18723 = NOVALUE;
    int _seek_1__tmp_at316_18726 = NOVALUE;
    int _seek_inlined_seek_at_316_18725 = NOVALUE;
    int _put4_1__tmp_at331_18728 = NOVALUE;
    int _seek_1__tmp_at369_18732 = NOVALUE;
    int _seek_inlined_seek_at_369_18731 = NOVALUE;
    int _put4_1__tmp_at384_18734 = NOVALUE;
    int _s_inlined_putn_at_431_18740 = NOVALUE;
    int _put4_1__tmp_at462_18744 = NOVALUE;
    int _put4_1__tmp_at490_18746 = NOVALUE;
    int _s_inlined_putn_at_530_18751 = NOVALUE;
    int _s_inlined_putn_at_568_18757 = NOVALUE;
    int _seek_1__tmp_at610_18765 = NOVALUE;
    int _seek_inlined_seek_at_610_18764 = NOVALUE;
    int _pos_inlined_seek_at_607_18763 = NOVALUE;
    int _put4_1__tmp_at625_18767 = NOVALUE;
    int _put4_1__tmp_at653_18769 = NOVALUE;
    int _put4_1__tmp_at681_18771 = NOVALUE;
    int _put4_1__tmp_at709_18773 = NOVALUE;
    int _10549 = NOVALUE;
    int _10548 = NOVALUE;
    int _10547 = NOVALUE;
    int _10546 = NOVALUE;
    int _10545 = NOVALUE;
    int _10544 = NOVALUE;
    int _10542 = NOVALUE;
    int _10541 = NOVALUE;
    int _10540 = NOVALUE;
    int _10539 = NOVALUE;
    int _10538 = NOVALUE;
    int _10536 = NOVALUE;
    int _10535 = NOVALUE;
    int _10534 = NOVALUE;
    int _10532 = NOVALUE;
    int _10531 = NOVALUE;
    int _10530 = NOVALUE;
    int _10529 = NOVALUE;
    int _10528 = NOVALUE;
    int _10527 = NOVALUE;
    int _10526 = NOVALUE;
    int _10524 = NOVALUE;
    int _10523 = NOVALUE;
    int _10522 = NOVALUE;
    int _10519 = NOVALUE;
    int _10518 = NOVALUE;
    int _10516 = NOVALUE;
    int _10515 = NOVALUE;
    int _10513 = NOVALUE;
    int _10511 = NOVALUE;
    int _10508 = NOVALUE;
    int _10503 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not cstring(name) then*/
    RefDS(_name_18657);
    _10503 = _13cstring(_name_18657);
    if (IS_ATOM_INT(_10503)) {
        if (_10503 != 0){
            DeRef(_10503);
            _10503 = NOVALUE;
            goto L1; // [11] 21
        }
    }
    else {
        if (DBL_PTR(_10503)->dbl != 0.0){
            DeRef(_10503);
            _10503 = NOVALUE;
            goto L1; // [11] 21
        }
    }
    DeRef(_10503);
    _10503 = NOVALUE;

    /** 		return DB_BAD_NAME*/
    DeRefDS(_name_18657);
    DeRef(_name_ptr_18659);
    DeRef(_nt_18660);
    DeRef(_tables_18661);
    DeRef(_newtables_18662);
    DeRef(_table_18663);
    DeRef(_records_ptr_18664);
    DeRef(_size_18665);
    DeRef(_newsize_18666);
    DeRef(_index_ptr_18667);
    DeRef(_remaining_18668);
    return -4;
L1: 

    /** 	table = table_find(name)*/
    RefDS(_name_18657);
    _0 = _table_18663;
    _table_18663 = _49table_find(_name_18657);
    DeRef(_0);

    /** 	if table != -1 then*/
    if (binary_op_a(EQUALS, _table_18663, -1)){
        goto L2; // [29] 40
    }

    /** 		return DB_EXISTS_ALREADY*/
    DeRefDS(_name_18657);
    DeRef(_name_ptr_18659);
    DeRef(_nt_18660);
    DeRef(_tables_18661);
    DeRef(_newtables_18662);
    DeRef(_table_18663);
    DeRef(_records_ptr_18664);
    DeRef(_size_18665);
    DeRef(_newsize_18666);
    DeRef(_index_ptr_18667);
    DeRef(_remaining_18668);
    return -2;
L2: 

    /** 	if init_records < 1 then*/
    if (_init_records_18658 >= 1)
    goto L3; // [42] 52

    /** 		init_records = 1*/
    _init_records_18658 = 1;
L3: 

    /** 	init_index = math:min({init_records, MAX_INDEX})*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _init_records_18658;
    ((int *)_2)[2] = 10;
    _10508 = MAKE_SEQ(_1);
    _init_index_18669 = _20min(_10508);
    _10508 = NOVALUE;
    if (!IS_ATOM_INT(_init_index_18669)) {
        _1 = (long)(DBL_PTR(_init_index_18669)->dbl);
        DeRefDS(_init_index_18669);
        _init_index_18669 = _1;
    }

    /** 	io:seek(current_db, TABLE_HEADERS)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at68_18683);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _49current_db_17372;
    ((int *)_2)[2] = 3;
    _seek_1__tmp_at68_18683 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_68_18682 = machine(19, _seek_1__tmp_at68_18683);
    DeRefi(_seek_1__tmp_at68_18683);
    _seek_1__tmp_at68_18683 = NOVALUE;

    /** 	tables = get4()*/
    _0 = _tables_18661;
    _tables_18661 = _49get4();
    DeRef(_0);

    /** 	io:seek(current_db, tables-4)*/
    if (IS_ATOM_INT(_tables_18661)) {
        _10511 = _tables_18661 - 4;
        if ((long)((unsigned long)_10511 +(unsigned long) HIGH_BITS) >= 0){
            _10511 = NewDouble((double)_10511);
        }
    }
    else {
        _10511 = NewDouble(DBL_PTR(_tables_18661)->dbl - (double)4);
    }
    DeRef(_pos_inlined_seek_at_94_18687);
    _pos_inlined_seek_at_94_18687 = _10511;
    _10511 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_94_18687);
    DeRef(_seek_1__tmp_at97_18689);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _49current_db_17372;
    ((int *)_2)[2] = _pos_inlined_seek_at_94_18687;
    _seek_1__tmp_at97_18689 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_97_18688 = machine(19, _seek_1__tmp_at97_18689);
    DeRef(_pos_inlined_seek_at_94_18687);
    _pos_inlined_seek_at_94_18687 = NOVALUE;
    DeRef(_seek_1__tmp_at97_18689);
    _seek_1__tmp_at97_18689 = NOVALUE;

    /** 	size = get4()*/
    _0 = _size_18665;
    _size_18665 = _49get4();
    DeRef(_0);

    /** 	nt = get4()+1*/
    _10513 = _49get4();
    DeRef(_nt_18660);
    if (IS_ATOM_INT(_10513)) {
        _nt_18660 = _10513 + 1;
        if (_nt_18660 > MAXINT){
            _nt_18660 = NewDouble((double)_nt_18660);
        }
    }
    else
    _nt_18660 = binary_op(PLUS, 1, _10513);
    DeRef(_10513);
    _10513 = NOVALUE;

    /** 	if nt*SIZEOF_TABLE_HEADER + 8 > size then*/
    if (IS_ATOM_INT(_nt_18660)) {
        if (_nt_18660 == (short)_nt_18660)
        _10515 = _nt_18660 * 16;
        else
        _10515 = NewDouble(_nt_18660 * (double)16);
    }
    else {
        _10515 = NewDouble(DBL_PTR(_nt_18660)->dbl * (double)16);
    }
    if (IS_ATOM_INT(_10515)) {
        _10516 = _10515 + 8;
        if ((long)((unsigned long)_10516 + (unsigned long)HIGH_BITS) >= 0) 
        _10516 = NewDouble((double)_10516);
    }
    else {
        _10516 = NewDouble(DBL_PTR(_10515)->dbl + (double)8);
    }
    DeRef(_10515);
    _10515 = NOVALUE;
    if (binary_op_a(LESSEQ, _10516, _size_18665)){
        DeRef(_10516);
        _10516 = NOVALUE;
        goto L4; // [134] 365
    }
    DeRef(_10516);
    _10516 = NOVALUE;

    /** 		newsize = floor(size + size / 2)*/
    if (IS_ATOM_INT(_size_18665)) {
        if (_size_18665 & 1) {
            _10518 = NewDouble((_size_18665 >> 1) + 0.5);
        }
        else
        _10518 = _size_18665 >> 1;
    }
    else {
        _10518 = binary_op(DIVIDE, _size_18665, 2);
    }
    if (IS_ATOM_INT(_size_18665) && IS_ATOM_INT(_10518)) {
        _10519 = _size_18665 + _10518;
        if ((long)((unsigned long)_10519 + (unsigned long)HIGH_BITS) >= 0) 
        _10519 = NewDouble((double)_10519);
    }
    else {
        if (IS_ATOM_INT(_size_18665)) {
            _10519 = NewDouble((double)_size_18665 + DBL_PTR(_10518)->dbl);
        }
        else {
            if (IS_ATOM_INT(_10518)) {
                _10519 = NewDouble(DBL_PTR(_size_18665)->dbl + (double)_10518);
            }
            else
            _10519 = NewDouble(DBL_PTR(_size_18665)->dbl + DBL_PTR(_10518)->dbl);
        }
    }
    DeRef(_10518);
    _10518 = NOVALUE;
    DeRef(_newsize_18666);
    if (IS_ATOM_INT(_10519))
    _newsize_18666 = e_floor(_10519);
    else
    _newsize_18666 = unary_op(FLOOR, _10519);
    DeRef(_10519);
    _10519 = NOVALUE;

    /** 		newtables = db_allocate(newsize)*/
    Ref(_newsize_18666);
    _0 = _newtables_18662;
    _newtables_18662 = _49db_allocate(_newsize_18666);
    DeRef(_0);

    /** 		put4(nt)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_49mem0_17414)){
        poke4_addr = (unsigned long *)_49mem0_17414;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_49mem0_17414)->dbl);
    }
    if (IS_ATOM_INT(_nt_18660)) {
        *poke4_addr = (unsigned long)_nt_18660;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_nt_18660)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at159_18702);
    _1 = (int)SEQ_PTR(_49memseq_17649);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at159_18702 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_49current_db_17372, _put4_1__tmp_at159_18702); // DJP 

    /** end procedure*/
    goto L5; // [180] 183
L5: 
    DeRefi(_put4_1__tmp_at159_18702);
    _put4_1__tmp_at159_18702 = NOVALUE;

    /** 		io:seek(current_db, tables+4)*/
    if (IS_ATOM_INT(_tables_18661)) {
        _10522 = _tables_18661 + 4;
        if ((long)((unsigned long)_10522 + (unsigned long)HIGH_BITS) >= 0) 
        _10522 = NewDouble((double)_10522);
    }
    else {
        _10522 = NewDouble(DBL_PTR(_tables_18661)->dbl + (double)4);
    }
    DeRef(_pos_inlined_seek_at_193_18705);
    _pos_inlined_seek_at_193_18705 = _10522;
    _10522 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_193_18705);
    DeRef(_seek_1__tmp_at196_18707);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _49current_db_17372;
    ((int *)_2)[2] = _pos_inlined_seek_at_193_18705;
    _seek_1__tmp_at196_18707 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_196_18706 = machine(19, _seek_1__tmp_at196_18707);
    DeRef(_pos_inlined_seek_at_193_18705);
    _pos_inlined_seek_at_193_18705 = NOVALUE;
    DeRef(_seek_1__tmp_at196_18707);
    _seek_1__tmp_at196_18707 = NOVALUE;

    /** 		remaining = io:get_bytes(current_db, (nt-1)*SIZEOF_TABLE_HEADER)*/
    if (IS_ATOM_INT(_nt_18660)) {
        _10523 = _nt_18660 - 1;
        if ((long)((unsigned long)_10523 +(unsigned long) HIGH_BITS) >= 0){
            _10523 = NewDouble((double)_10523);
        }
    }
    else {
        _10523 = NewDouble(DBL_PTR(_nt_18660)->dbl - (double)1);
    }
    if (IS_ATOM_INT(_10523)) {
        if (_10523 == (short)_10523)
        _10524 = _10523 * 16;
        else
        _10524 = NewDouble(_10523 * (double)16);
    }
    else {
        _10524 = NewDouble(DBL_PTR(_10523)->dbl * (double)16);
    }
    DeRef(_10523);
    _10523 = NOVALUE;
    _0 = _remaining_18668;
    _remaining_18668 = _8get_bytes(_49current_db_17372, _10524);
    DeRef(_0);
    _10524 = NOVALUE;

    /** 		io:seek(current_db, newtables+4)*/
    if (IS_ATOM_INT(_newtables_18662)) {
        _10526 = _newtables_18662 + 4;
        if ((long)((unsigned long)_10526 + (unsigned long)HIGH_BITS) >= 0) 
        _10526 = NewDouble((double)_10526);
    }
    else {
        _10526 = NewDouble(DBL_PTR(_newtables_18662)->dbl + (double)4);
    }
    DeRef(_pos_inlined_seek_at_236_18713);
    _pos_inlined_seek_at_236_18713 = _10526;
    _10526 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_236_18713);
    DeRef(_seek_1__tmp_at239_18715);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _49current_db_17372;
    ((int *)_2)[2] = _pos_inlined_seek_at_236_18713;
    _seek_1__tmp_at239_18715 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_239_18714 = machine(19, _seek_1__tmp_at239_18715);
    DeRef(_pos_inlined_seek_at_236_18713);
    _pos_inlined_seek_at_236_18713 = NOVALUE;
    DeRef(_seek_1__tmp_at239_18715);
    _seek_1__tmp_at239_18715 = NOVALUE;

    /** 		putn(remaining)*/

    /** 	puts(current_db, s)*/
    EPuts(_49current_db_17372, _remaining_18668); // DJP 

    /** end procedure*/
    goto L6; // [263] 266
L6: 

    /** 		putn(repeat(0, newsize - 4 - (nt-1)*SIZEOF_TABLE_HEADER))*/
    if (IS_ATOM_INT(_newsize_18666)) {
        _10527 = _newsize_18666 - 4;
        if ((long)((unsigned long)_10527 +(unsigned long) HIGH_BITS) >= 0){
            _10527 = NewDouble((double)_10527);
        }
    }
    else {
        _10527 = NewDouble(DBL_PTR(_newsize_18666)->dbl - (double)4);
    }
    if (IS_ATOM_INT(_nt_18660)) {
        _10528 = _nt_18660 - 1;
        if ((long)((unsigned long)_10528 +(unsigned long) HIGH_BITS) >= 0){
            _10528 = NewDouble((double)_10528);
        }
    }
    else {
        _10528 = NewDouble(DBL_PTR(_nt_18660)->dbl - (double)1);
    }
    if (IS_ATOM_INT(_10528)) {
        if (_10528 == (short)_10528)
        _10529 = _10528 * 16;
        else
        _10529 = NewDouble(_10528 * (double)16);
    }
    else {
        _10529 = NewDouble(DBL_PTR(_10528)->dbl * (double)16);
    }
    DeRef(_10528);
    _10528 = NOVALUE;
    if (IS_ATOM_INT(_10527) && IS_ATOM_INT(_10529)) {
        _10530 = _10527 - _10529;
    }
    else {
        if (IS_ATOM_INT(_10527)) {
            _10530 = NewDouble((double)_10527 - DBL_PTR(_10529)->dbl);
        }
        else {
            if (IS_ATOM_INT(_10529)) {
                _10530 = NewDouble(DBL_PTR(_10527)->dbl - (double)_10529);
            }
            else
            _10530 = NewDouble(DBL_PTR(_10527)->dbl - DBL_PTR(_10529)->dbl);
        }
    }
    DeRef(_10527);
    _10527 = NOVALUE;
    DeRef(_10529);
    _10529 = NOVALUE;
    _10531 = Repeat(0, _10530);
    DeRef(_10530);
    _10530 = NOVALUE;
    DeRefi(_s_inlined_putn_at_288_18723);
    _s_inlined_putn_at_288_18723 = _10531;
    _10531 = NOVALUE;

    /** 	puts(current_db, s)*/
    EPuts(_49current_db_17372, _s_inlined_putn_at_288_18723); // DJP 

    /** end procedure*/
    goto L7; // [302] 305
L7: 
    DeRefi(_s_inlined_putn_at_288_18723);
    _s_inlined_putn_at_288_18723 = NOVALUE;

    /** 		db_free(tables)*/
    Ref(_tables_18661);
    _49db_free(_tables_18661);

    /** 		io:seek(current_db, TABLE_HEADERS)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at316_18726);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _49current_db_17372;
    ((int *)_2)[2] = 3;
    _seek_1__tmp_at316_18726 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_316_18725 = machine(19, _seek_1__tmp_at316_18726);
    DeRefi(_seek_1__tmp_at316_18726);
    _seek_1__tmp_at316_18726 = NOVALUE;

    /** 		put4(newtables)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_49mem0_17414)){
        poke4_addr = (unsigned long *)_49mem0_17414;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_49mem0_17414)->dbl);
    }
    if (IS_ATOM_INT(_newtables_18662)) {
        *poke4_addr = (unsigned long)_newtables_18662;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_newtables_18662)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at331_18728);
    _1 = (int)SEQ_PTR(_49memseq_17649);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at331_18728 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_49current_db_17372, _put4_1__tmp_at331_18728); // DJP 

    /** end procedure*/
    goto L8; // [352] 355
L8: 
    DeRefi(_put4_1__tmp_at331_18728);
    _put4_1__tmp_at331_18728 = NOVALUE;

    /** 		tables = newtables*/
    Ref(_newtables_18662);
    DeRef(_tables_18661);
    _tables_18661 = _newtables_18662;
    goto L9; // [362] 411
L4: 

    /** 		io:seek(current_db, tables)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_tables_18661);
    DeRef(_seek_1__tmp_at369_18732);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _49current_db_17372;
    ((int *)_2)[2] = _tables_18661;
    _seek_1__tmp_at369_18732 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_369_18731 = machine(19, _seek_1__tmp_at369_18732);
    DeRef(_seek_1__tmp_at369_18732);
    _seek_1__tmp_at369_18732 = NOVALUE;

    /** 		put4(nt)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_49mem0_17414)){
        poke4_addr = (unsigned long *)_49mem0_17414;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_49mem0_17414)->dbl);
    }
    if (IS_ATOM_INT(_nt_18660)) {
        *poke4_addr = (unsigned long)_nt_18660;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_nt_18660)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at384_18734);
    _1 = (int)SEQ_PTR(_49memseq_17649);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at384_18734 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_49current_db_17372, _put4_1__tmp_at384_18734); // DJP 

    /** end procedure*/
    goto LA; // [405] 408
LA: 
    DeRefi(_put4_1__tmp_at384_18734);
    _put4_1__tmp_at384_18734 = NOVALUE;
L9: 

    /** 	records_ptr = db_allocate(init_records * 4)*/
    if (_init_records_18658 == (short)_init_records_18658)
    _10532 = _init_records_18658 * 4;
    else
    _10532 = NewDouble(_init_records_18658 * (double)4);
    _0 = _records_ptr_18664;
    _records_ptr_18664 = _49db_allocate(_10532);
    DeRef(_0);
    _10532 = NOVALUE;

    /** 	putn(repeat(0, init_records * 4))*/
    _10534 = _init_records_18658 * 4;
    _10535 = Repeat(0, _10534);
    _10534 = NOVALUE;
    DeRefi(_s_inlined_putn_at_431_18740);
    _s_inlined_putn_at_431_18740 = _10535;
    _10535 = NOVALUE;

    /** 	puts(current_db, s)*/
    EPuts(_49current_db_17372, _s_inlined_putn_at_431_18740); // DJP 

    /** end procedure*/
    goto LB; // [445] 448
LB: 
    DeRefi(_s_inlined_putn_at_431_18740);
    _s_inlined_putn_at_431_18740 = NOVALUE;

    /** 	index_ptr = db_allocate(init_index * 8)*/
    if (_init_index_18669 == (short)_init_index_18669)
    _10536 = _init_index_18669 * 8;
    else
    _10536 = NewDouble(_init_index_18669 * (double)8);
    _0 = _index_ptr_18667;
    _index_ptr_18667 = _49db_allocate(_10536);
    DeRef(_0);
    _10536 = NOVALUE;

    /** 	put4(0)  -- 0 records*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_49mem0_17414)){
        poke4_addr = (unsigned long *)_49mem0_17414;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_49mem0_17414)->dbl);
    }
    *poke4_addr = (unsigned long)0;

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at462_18744);
    _1 = (int)SEQ_PTR(_49memseq_17649);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at462_18744 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_49current_db_17372, _put4_1__tmp_at462_18744); // DJP 

    /** end procedure*/
    goto LC; // [483] 486
LC: 
    DeRefi(_put4_1__tmp_at462_18744);
    _put4_1__tmp_at462_18744 = NOVALUE;

    /** 	put4(records_ptr) -- point to 1st block*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_49mem0_17414)){
        poke4_addr = (unsigned long *)_49mem0_17414;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_49mem0_17414)->dbl);
    }
    if (IS_ATOM_INT(_records_ptr_18664)) {
        *poke4_addr = (unsigned long)_records_ptr_18664;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_records_ptr_18664)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at490_18746);
    _1 = (int)SEQ_PTR(_49memseq_17649);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at490_18746 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_49current_db_17372, _put4_1__tmp_at490_18746); // DJP 

    /** end procedure*/
    goto LD; // [511] 514
LD: 
    DeRefi(_put4_1__tmp_at490_18746);
    _put4_1__tmp_at490_18746 = NOVALUE;

    /** 	putn(repeat(0, (init_index-1) * 8))*/
    _10538 = _init_index_18669 - 1;
    if ((long)((unsigned long)_10538 +(unsigned long) HIGH_BITS) >= 0){
        _10538 = NewDouble((double)_10538);
    }
    if (IS_ATOM_INT(_10538)) {
        _10539 = _10538 * 8;
    }
    else {
        _10539 = NewDouble(DBL_PTR(_10538)->dbl * (double)8);
    }
    DeRef(_10538);
    _10538 = NOVALUE;
    _10540 = Repeat(0, _10539);
    DeRef(_10539);
    _10539 = NOVALUE;
    DeRefi(_s_inlined_putn_at_530_18751);
    _s_inlined_putn_at_530_18751 = _10540;
    _10540 = NOVALUE;

    /** 	puts(current_db, s)*/
    EPuts(_49current_db_17372, _s_inlined_putn_at_530_18751); // DJP 

    /** end procedure*/
    goto LE; // [544] 547
LE: 
    DeRefi(_s_inlined_putn_at_530_18751);
    _s_inlined_putn_at_530_18751 = NOVALUE;

    /** 	name_ptr = db_allocate(length(name)+1)*/
    if (IS_SEQUENCE(_name_18657)){
            _10541 = SEQ_PTR(_name_18657)->length;
    }
    else {
        _10541 = 1;
    }
    _10542 = _10541 + 1;
    _10541 = NOVALUE;
    _0 = _name_ptr_18659;
    _name_ptr_18659 = _49db_allocate(_10542);
    DeRef(_0);
    _10542 = NOVALUE;

    /** 	putn(name & 0)*/
    Append(&_10544, _name_18657, 0);
    DeRef(_s_inlined_putn_at_568_18757);
    _s_inlined_putn_at_568_18757 = _10544;
    _10544 = NOVALUE;

    /** 	puts(current_db, s)*/
    EPuts(_49current_db_17372, _s_inlined_putn_at_568_18757); // DJP 

    /** end procedure*/
    goto LF; // [582] 585
LF: 
    DeRef(_s_inlined_putn_at_568_18757);
    _s_inlined_putn_at_568_18757 = NOVALUE;

    /** 	io:seek(current_db, tables+4+(nt-1)*SIZEOF_TABLE_HEADER)*/
    if (IS_ATOM_INT(_tables_18661)) {
        _10545 = _tables_18661 + 4;
        if ((long)((unsigned long)_10545 + (unsigned long)HIGH_BITS) >= 0) 
        _10545 = NewDouble((double)_10545);
    }
    else {
        _10545 = NewDouble(DBL_PTR(_tables_18661)->dbl + (double)4);
    }
    if (IS_ATOM_INT(_nt_18660)) {
        _10546 = _nt_18660 - 1;
        if ((long)((unsigned long)_10546 +(unsigned long) HIGH_BITS) >= 0){
            _10546 = NewDouble((double)_10546);
        }
    }
    else {
        _10546 = NewDouble(DBL_PTR(_nt_18660)->dbl - (double)1);
    }
    if (IS_ATOM_INT(_10546)) {
        if (_10546 == (short)_10546)
        _10547 = _10546 * 16;
        else
        _10547 = NewDouble(_10546 * (double)16);
    }
    else {
        _10547 = NewDouble(DBL_PTR(_10546)->dbl * (double)16);
    }
    DeRef(_10546);
    _10546 = NOVALUE;
    if (IS_ATOM_INT(_10545) && IS_ATOM_INT(_10547)) {
        _10548 = _10545 + _10547;
        if ((long)((unsigned long)_10548 + (unsigned long)HIGH_BITS) >= 0) 
        _10548 = NewDouble((double)_10548);
    }
    else {
        if (IS_ATOM_INT(_10545)) {
            _10548 = NewDouble((double)_10545 + DBL_PTR(_10547)->dbl);
        }
        else {
            if (IS_ATOM_INT(_10547)) {
                _10548 = NewDouble(DBL_PTR(_10545)->dbl + (double)_10547);
            }
            else
            _10548 = NewDouble(DBL_PTR(_10545)->dbl + DBL_PTR(_10547)->dbl);
        }
    }
    DeRef(_10545);
    _10545 = NOVALUE;
    DeRef(_10547);
    _10547 = NOVALUE;
    DeRef(_pos_inlined_seek_at_607_18763);
    _pos_inlined_seek_at_607_18763 = _10548;
    _10548 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_607_18763);
    DeRef(_seek_1__tmp_at610_18765);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _49current_db_17372;
    ((int *)_2)[2] = _pos_inlined_seek_at_607_18763;
    _seek_1__tmp_at610_18765 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_610_18764 = machine(19, _seek_1__tmp_at610_18765);
    DeRef(_pos_inlined_seek_at_607_18763);
    _pos_inlined_seek_at_607_18763 = NOVALUE;
    DeRef(_seek_1__tmp_at610_18765);
    _seek_1__tmp_at610_18765 = NOVALUE;

    /** 	put4(name_ptr)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_49mem0_17414)){
        poke4_addr = (unsigned long *)_49mem0_17414;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_49mem0_17414)->dbl);
    }
    if (IS_ATOM_INT(_name_ptr_18659)) {
        *poke4_addr = (unsigned long)_name_ptr_18659;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_name_ptr_18659)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at625_18767);
    _1 = (int)SEQ_PTR(_49memseq_17649);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at625_18767 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_49current_db_17372, _put4_1__tmp_at625_18767); // DJP 

    /** end procedure*/
    goto L10; // [646] 649
L10: 
    DeRefi(_put4_1__tmp_at625_18767);
    _put4_1__tmp_at625_18767 = NOVALUE;

    /** 	put4(0)  -- start with 0 records total*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_49mem0_17414)){
        poke4_addr = (unsigned long *)_49mem0_17414;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_49mem0_17414)->dbl);
    }
    *poke4_addr = (unsigned long)0;

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at653_18769);
    _1 = (int)SEQ_PTR(_49memseq_17649);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at653_18769 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_49current_db_17372, _put4_1__tmp_at653_18769); // DJP 

    /** end procedure*/
    goto L11; // [674] 677
L11: 
    DeRefi(_put4_1__tmp_at653_18769);
    _put4_1__tmp_at653_18769 = NOVALUE;

    /** 	put4(1)  -- start with 1 block of records in index*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_49mem0_17414)){
        poke4_addr = (unsigned long *)_49mem0_17414;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_49mem0_17414)->dbl);
    }
    *poke4_addr = (unsigned long)1;

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at681_18771);
    _1 = (int)SEQ_PTR(_49memseq_17649);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at681_18771 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_49current_db_17372, _put4_1__tmp_at681_18771); // DJP 

    /** end procedure*/
    goto L12; // [702] 705
L12: 
    DeRefi(_put4_1__tmp_at681_18771);
    _put4_1__tmp_at681_18771 = NOVALUE;

    /** 	put4(index_ptr)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_49mem0_17414)){
        poke4_addr = (unsigned long *)_49mem0_17414;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_49mem0_17414)->dbl);
    }
    if (IS_ATOM_INT(_index_ptr_18667)) {
        *poke4_addr = (unsigned long)_index_ptr_18667;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_index_ptr_18667)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at709_18773);
    _1 = (int)SEQ_PTR(_49memseq_17649);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at709_18773 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_49current_db_17372, _put4_1__tmp_at709_18773); // DJP 

    /** end procedure*/
    goto L13; // [730] 733
L13: 
    DeRefi(_put4_1__tmp_at709_18773);
    _put4_1__tmp_at709_18773 = NOVALUE;

    /** 	if db_select_table(name) then*/
    RefDS(_name_18657);
    _10549 = _49db_select_table(_name_18657);
    if (_10549 == 0) {
        DeRef(_10549);
        _10549 = NOVALUE;
        goto L14; // [741] 745
    }
    else {
        if (!IS_ATOM_INT(_10549) && DBL_PTR(_10549)->dbl == 0.0){
            DeRef(_10549);
            _10549 = NOVALUE;
            goto L14; // [741] 745
        }
        DeRef(_10549);
        _10549 = NOVALUE;
    }
    DeRef(_10549);
    _10549 = NOVALUE;
L14: 

    /** 	return DB_OK*/
    DeRefDS(_name_18657);
    DeRef(_name_ptr_18659);
    DeRef(_nt_18660);
    DeRef(_tables_18661);
    DeRef(_newtables_18662);
    DeRef(_table_18663);
    DeRef(_records_ptr_18664);
    DeRef(_size_18665);
    DeRef(_newsize_18666);
    DeRef(_index_ptr_18667);
    DeRef(_remaining_18668);
    return 0;
    ;
}


int _49db_table_list()
{
    int _seek_1__tmp_at120_19032 = NOVALUE;
    int _seek_inlined_seek_at_120_19031 = NOVALUE;
    int _seek_1__tmp_at98_19028 = NOVALUE;
    int _seek_inlined_seek_at_98_19027 = NOVALUE;
    int _pos_inlined_seek_at_95_19026 = NOVALUE;
    int _seek_1__tmp_at42_19016 = NOVALUE;
    int _seek_inlined_seek_at_42_19015 = NOVALUE;
    int _seek_1__tmp_at4_19009 = NOVALUE;
    int _seek_inlined_seek_at_4_19008 = NOVALUE;
    int _table_names_19003 = NOVALUE;
    int _tables_19004 = NOVALUE;
    int _nt_19005 = NOVALUE;
    int _name_19006 = NOVALUE;
    int _10648 = NOVALUE;
    int _10647 = NOVALUE;
    int _10645 = NOVALUE;
    int _10644 = NOVALUE;
    int _10643 = NOVALUE;
    int _10642 = NOVALUE;
    int _10637 = NOVALUE;
    int _0, _1, _2;
    

    /** 	io:seek(current_db, TABLE_HEADERS)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at4_19009);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _49current_db_17372;
    ((int *)_2)[2] = 3;
    _seek_1__tmp_at4_19009 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_4_19008 = machine(19, _seek_1__tmp_at4_19009);
    DeRefi(_seek_1__tmp_at4_19009);
    _seek_1__tmp_at4_19009 = NOVALUE;

    /** 	if length(vLastErrors) > 0 then return {} end if*/
    if (IS_SEQUENCE(_49vLastErrors_17396)){
            _10637 = SEQ_PTR(_49vLastErrors_17396)->length;
    }
    else {
        _10637 = 1;
    }
    if (_10637 <= 0)
    goto L1; // [25] 34
    RefDS(_5);
    DeRef(_table_names_19003);
    DeRef(_tables_19004);
    DeRef(_nt_19005);
    DeRef(_name_19006);
    return _5;
L1: 

    /** 	tables = get4()*/
    _0 = _tables_19004;
    _tables_19004 = _49get4();
    DeRef(_0);

    /** 	io:seek(current_db, tables)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_tables_19004);
    DeRef(_seek_1__tmp_at42_19016);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _49current_db_17372;
    ((int *)_2)[2] = _tables_19004;
    _seek_1__tmp_at42_19016 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_42_19015 = machine(19, _seek_1__tmp_at42_19016);
    DeRef(_seek_1__tmp_at42_19016);
    _seek_1__tmp_at42_19016 = NOVALUE;

    /** 	nt = get4()*/
    _0 = _nt_19005;
    _nt_19005 = _49get4();
    DeRef(_0);

    /** 	table_names = repeat(0, nt)*/
    DeRef(_table_names_19003);
    _table_names_19003 = Repeat(0, _nt_19005);

    /** 	for i = 0 to nt-1 do*/
    if (IS_ATOM_INT(_nt_19005)) {
        _10642 = _nt_19005 - 1;
        if ((long)((unsigned long)_10642 +(unsigned long) HIGH_BITS) >= 0){
            _10642 = NewDouble((double)_10642);
        }
    }
    else {
        _10642 = NewDouble(DBL_PTR(_nt_19005)->dbl - (double)1);
    }
    {
        int _i_19020;
        _i_19020 = 0;
L2: 
        if (binary_op_a(GREATER, _i_19020, _10642)){
            goto L3; // [73] 154
        }

        /** 		io:seek(current_db, tables + 4 + i*SIZEOF_TABLE_HEADER)*/
        if (IS_ATOM_INT(_tables_19004)) {
            _10643 = _tables_19004 + 4;
            if ((long)((unsigned long)_10643 + (unsigned long)HIGH_BITS) >= 0) 
            _10643 = NewDouble((double)_10643);
        }
        else {
            _10643 = NewDouble(DBL_PTR(_tables_19004)->dbl + (double)4);
        }
        if (IS_ATOM_INT(_i_19020)) {
            if (_i_19020 == (short)_i_19020)
            _10644 = _i_19020 * 16;
            else
            _10644 = NewDouble(_i_19020 * (double)16);
        }
        else {
            _10644 = NewDouble(DBL_PTR(_i_19020)->dbl * (double)16);
        }
        if (IS_ATOM_INT(_10643) && IS_ATOM_INT(_10644)) {
            _10645 = _10643 + _10644;
            if ((long)((unsigned long)_10645 + (unsigned long)HIGH_BITS) >= 0) 
            _10645 = NewDouble((double)_10645);
        }
        else {
            if (IS_ATOM_INT(_10643)) {
                _10645 = NewDouble((double)_10643 + DBL_PTR(_10644)->dbl);
            }
            else {
                if (IS_ATOM_INT(_10644)) {
                    _10645 = NewDouble(DBL_PTR(_10643)->dbl + (double)_10644);
                }
                else
                _10645 = NewDouble(DBL_PTR(_10643)->dbl + DBL_PTR(_10644)->dbl);
            }
        }
        DeRef(_10643);
        _10643 = NOVALUE;
        DeRef(_10644);
        _10644 = NOVALUE;
        DeRef(_pos_inlined_seek_at_95_19026);
        _pos_inlined_seek_at_95_19026 = _10645;
        _10645 = NOVALUE;

        /** 	return machine_func(M_SEEK, {fn, pos})*/
        Ref(_pos_inlined_seek_at_95_19026);
        DeRef(_seek_1__tmp_at98_19028);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _49current_db_17372;
        ((int *)_2)[2] = _pos_inlined_seek_at_95_19026;
        _seek_1__tmp_at98_19028 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_98_19027 = machine(19, _seek_1__tmp_at98_19028);
        DeRef(_pos_inlined_seek_at_95_19026);
        _pos_inlined_seek_at_95_19026 = NOVALUE;
        DeRef(_seek_1__tmp_at98_19028);
        _seek_1__tmp_at98_19028 = NOVALUE;

        /** 		name = get4()*/
        _0 = _name_19006;
        _name_19006 = _49get4();
        DeRef(_0);

        /** 		io:seek(current_db, name)*/

        /** 	return machine_func(M_SEEK, {fn, pos})*/
        Ref(_name_19006);
        DeRef(_seek_1__tmp_at120_19032);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _49current_db_17372;
        ((int *)_2)[2] = _name_19006;
        _seek_1__tmp_at120_19032 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_120_19031 = machine(19, _seek_1__tmp_at120_19032);
        DeRef(_seek_1__tmp_at120_19032);
        _seek_1__tmp_at120_19032 = NOVALUE;

        /** 		table_names[i+1] = get_string()*/
        if (IS_ATOM_INT(_i_19020)) {
            _10647 = _i_19020 + 1;
            if (_10647 > MAXINT){
                _10647 = NewDouble((double)_10647);
            }
        }
        else
        _10647 = binary_op(PLUS, 1, _i_19020);
        _10648 = _49get_string();
        _2 = (int)SEQ_PTR(_table_names_19003);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _table_names_19003 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_10647))
        _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_10647)->dbl));
        else
        _2 = (int)(((s1_ptr)_2)->base + _10647);
        _1 = *(int *)_2;
        *(int *)_2 = _10648;
        if( _1 != _10648 ){
            DeRef(_1);
        }
        _10648 = NOVALUE;

        /** 	end for*/
        _0 = _i_19020;
        if (IS_ATOM_INT(_i_19020)) {
            _i_19020 = _i_19020 + 1;
            if ((long)((unsigned long)_i_19020 +(unsigned long) HIGH_BITS) >= 0){
                _i_19020 = NewDouble((double)_i_19020);
            }
        }
        else {
            _i_19020 = binary_op_a(PLUS, _i_19020, 1);
        }
        DeRef(_0);
        goto L2; // [149] 80
L3: 
        ;
        DeRef(_i_19020);
    }

    /** 	return table_names*/
    DeRef(_tables_19004);
    DeRef(_nt_19005);
    DeRef(_name_19006);
    DeRef(_10642);
    _10642 = NOVALUE;
    DeRef(_10647);
    _10647 = NOVALUE;
    return _table_names_19003;
    ;
}


int _49key_value(int _ptr_19037)
{
    int _seek_1__tmp_at11_19042 = NOVALUE;
    int _seek_inlined_seek_at_11_19041 = NOVALUE;
    int _pos_inlined_seek_at_8_19040 = NOVALUE;
    int _10650 = NOVALUE;
    int _10649 = NOVALUE;
    int _0, _1, _2;
    

    /** 	io:seek(current_db, ptr+4) -- skip ptr to data*/
    if (IS_ATOM_INT(_ptr_19037)) {
        _10649 = _ptr_19037 + 4;
        if ((long)((unsigned long)_10649 + (unsigned long)HIGH_BITS) >= 0) 
        _10649 = NewDouble((double)_10649);
    }
    else {
        _10649 = NewDouble(DBL_PTR(_ptr_19037)->dbl + (double)4);
    }
    DeRef(_pos_inlined_seek_at_8_19040);
    _pos_inlined_seek_at_8_19040 = _10649;
    _10649 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_8_19040);
    DeRef(_seek_1__tmp_at11_19042);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _49current_db_17372;
    ((int *)_2)[2] = _pos_inlined_seek_at_8_19040;
    _seek_1__tmp_at11_19042 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_11_19041 = machine(19, _seek_1__tmp_at11_19042);
    DeRef(_pos_inlined_seek_at_8_19040);
    _pos_inlined_seek_at_8_19040 = NOVALUE;
    DeRef(_seek_1__tmp_at11_19042);
    _seek_1__tmp_at11_19042 = NOVALUE;

    /** 	return decompress(0)*/
    _10650 = _49decompress(0);
    DeRef(_ptr_19037);
    return _10650;
    ;
}


int _49db_find_key(int _key_19046, int _table_name_19047)
{
    int _lo_19048 = NOVALUE;
    int _hi_19049 = NOVALUE;
    int _mid_19050 = NOVALUE;
    int _c_19051 = NOVALUE;
    int _10674 = NOVALUE;
    int _10666 = NOVALUE;
    int _10665 = NOVALUE;
    int _10663 = NOVALUE;
    int _10660 = NOVALUE;
    int _10657 = NOVALUE;
    int _10653 = NOVALUE;
    int _10651 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not equal(table_name, current_table_name) then*/
    if (_table_name_19047 == _49current_table_name_17374)
    _10651 = 1;
    else if (IS_ATOM_INT(_table_name_19047) && IS_ATOM_INT(_49current_table_name_17374))
    _10651 = 0;
    else
    _10651 = (compare(_table_name_19047, _49current_table_name_17374) == 0);
    if (_10651 != 0)
    goto L1; // [9] 42
    _10651 = NOVALUE;

    /** 		if db_select_table(table_name) != DB_OK then*/
    RefDS(_table_name_19047);
    _10653 = _49db_select_table(_table_name_19047);
    if (binary_op_a(EQUALS, _10653, 0)){
        DeRef(_10653);
        _10653 = NOVALUE;
        goto L2; // [18] 41
    }
    DeRef(_10653);
    _10653 = NOVALUE;

    /** 			fatal(NO_TABLE, "invalid table name given", "db_find_key", {key, table_name})*/
    RefDS(_table_name_19047);
    Ref(_key_19046);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _key_19046;
    ((int *)_2)[2] = _table_name_19047;
    _10657 = MAKE_SEQ(_1);
    RefDS(_10655);
    RefDS(_10656);
    _49fatal(903, _10655, _10656, _10657);
    _10657 = NOVALUE;

    /** 			return 0*/
    DeRef(_key_19046);
    DeRefDS(_table_name_19047);
    return 0;
L2: 
L1: 

    /** 	if current_table_pos = -1 then*/
    if (binary_op_a(NOTEQ, _49current_table_pos_17373, -1)){
        goto L3; // [46] 69
    }

    /** 		fatal(NO_TABLE, "no table selected", "db_find_key", {key, table_name})*/
    Ref(_table_name_19047);
    Ref(_key_19046);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _key_19046;
    ((int *)_2)[2] = _table_name_19047;
    _10660 = MAKE_SEQ(_1);
    RefDS(_10659);
    RefDS(_10656);
    _49fatal(903, _10659, _10656, _10660);
    _10660 = NOVALUE;

    /** 		return 0*/
    DeRef(_key_19046);
    DeRef(_table_name_19047);
    return 0;
L3: 

    /** 	lo = 1*/
    _lo_19048 = 1;

    /** 	hi = length(key_pointers)*/
    if (IS_SEQUENCE(_49key_pointers_17379)){
            _hi_19049 = SEQ_PTR(_49key_pointers_17379)->length;
    }
    else {
        _hi_19049 = 1;
    }

    /** 	mid = 1*/
    _mid_19050 = 1;

    /** 	c = 0*/
    _c_19051 = 0;

    /** 	while lo <= hi do*/
L4: 
    if (_lo_19048 > _hi_19049)
    goto L5; // [96] 170

    /** 		mid = floor((lo + hi) / 2)*/
    _10663 = _lo_19048 + _hi_19049;
    if ((long)((unsigned long)_10663 + (unsigned long)HIGH_BITS) >= 0) 
    _10663 = NewDouble((double)_10663);
    if (IS_ATOM_INT(_10663)) {
        _mid_19050 = _10663 >> 1;
    }
    else {
        _1 = binary_op(DIVIDE, _10663, 2);
        _mid_19050 = unary_op(FLOOR, _1);
        DeRef(_1);
    }
    DeRef(_10663);
    _10663 = NOVALUE;
    if (!IS_ATOM_INT(_mid_19050)) {
        _1 = (long)(DBL_PTR(_mid_19050)->dbl);
        DeRefDS(_mid_19050);
        _mid_19050 = _1;
    }

    /** 		c = eu:compare(key, key_value(key_pointers[mid]))*/
    _2 = (int)SEQ_PTR(_49key_pointers_17379);
    _10665 = (int)*(((s1_ptr)_2)->base + _mid_19050);
    Ref(_10665);
    _10666 = _49key_value(_10665);
    _10665 = NOVALUE;
    if (IS_ATOM_INT(_key_19046) && IS_ATOM_INT(_10666)){
        _c_19051 = (_key_19046 < _10666) ? -1 : (_key_19046 > _10666);
    }
    else{
        _c_19051 = compare(_key_19046, _10666);
    }
    DeRef(_10666);
    _10666 = NOVALUE;

    /** 		if c < 0 then*/
    if (_c_19051 >= 0)
    goto L6; // [130] 143

    /** 			hi = mid - 1*/
    _hi_19049 = _mid_19050 - 1;
    goto L4; // [140] 96
L6: 

    /** 		elsif c > 0 then*/
    if (_c_19051 <= 0)
    goto L7; // [145] 158

    /** 			lo = mid + 1*/
    _lo_19048 = _mid_19050 + 1;
    goto L4; // [155] 96
L7: 

    /** 			return mid*/
    DeRef(_key_19046);
    DeRef(_table_name_19047);
    return _mid_19050;

    /** 	end while*/
    goto L4; // [167] 96
L5: 

    /** 	if c > 0 then*/
    if (_c_19051 <= 0)
    goto L8; // [172] 183

    /** 		mid += 1*/
    _mid_19050 = _mid_19050 + 1;
L8: 

    /** 	return -mid*/
    if ((unsigned long)_mid_19050 == 0xC0000000)
    _10674 = (int)NewDouble((double)-0xC0000000);
    else
    _10674 = - _mid_19050;
    DeRef(_key_19046);
    DeRef(_table_name_19047);
    return _10674;
    ;
}


int _49db_insert(int _key_19086, int _data_19087, int _table_name_19088)
{
    int _key_string_19089 = NOVALUE;
    int _data_string_19090 = NOVALUE;
    int _last_part_19091 = NOVALUE;
    int _remaining_19092 = NOVALUE;
    int _key_ptr_19093 = NOVALUE;
    int _data_ptr_19094 = NOVALUE;
    int _records_ptr_19095 = NOVALUE;
    int _nrecs_19096 = NOVALUE;
    int _current_block_19097 = NOVALUE;
    int _size_19098 = NOVALUE;
    int _new_size_19099 = NOVALUE;
    int _key_location_19100 = NOVALUE;
    int _new_block_19101 = NOVALUE;
    int _index_ptr_19102 = NOVALUE;
    int _new_index_ptr_19103 = NOVALUE;
    int _total_recs_19104 = NOVALUE;
    int _r_19105 = NOVALUE;
    int _blocks_19106 = NOVALUE;
    int _new_recs_19107 = NOVALUE;
    int _n_19108 = NOVALUE;
    int _put4_1__tmp_at79_19122 = NOVALUE;
    int _seek_1__tmp_at132_19128 = NOVALUE;
    int _seek_inlined_seek_at_132_19127 = NOVALUE;
    int _pos_inlined_seek_at_129_19126 = NOVALUE;
    int _seek_1__tmp_at174_19136 = NOVALUE;
    int _seek_inlined_seek_at_174_19135 = NOVALUE;
    int _pos_inlined_seek_at_171_19134 = NOVALUE;
    int _put4_1__tmp_at189_19138 = NOVALUE;
    int _seek_1__tmp_at317_19156 = NOVALUE;
    int _seek_inlined_seek_at_317_19155 = NOVALUE;
    int _pos_inlined_seek_at_314_19154 = NOVALUE;
    int _seek_1__tmp_at339_19160 = NOVALUE;
    int _seek_inlined_seek_at_339_19159 = NOVALUE;
    int _where_inlined_where_at_404_19169 = NOVALUE;
    int _seek_1__tmp_at448_19179 = NOVALUE;
    int _seek_inlined_seek_at_448_19178 = NOVALUE;
    int _pos_inlined_seek_at_445_19177 = NOVALUE;
    int _put4_1__tmp_at493_19188 = NOVALUE;
    int _x_inlined_put4_at_490_19187 = NOVALUE;
    int _seek_1__tmp_at530_19191 = NOVALUE;
    int _seek_inlined_seek_at_530_19190 = NOVALUE;
    int _put4_1__tmp_at551_19194 = NOVALUE;
    int _seek_1__tmp_at588_19199 = NOVALUE;
    int _seek_inlined_seek_at_588_19198 = NOVALUE;
    int _pos_inlined_seek_at_585_19197 = NOVALUE;
    int _seek_1__tmp_at690_19224 = NOVALUE;
    int _seek_inlined_seek_at_690_19223 = NOVALUE;
    int _pos_inlined_seek_at_687_19222 = NOVALUE;
    int _s_inlined_putn_at_751_19233 = NOVALUE;
    int _seek_1__tmp_at774_19236 = NOVALUE;
    int _seek_inlined_seek_at_774_19235 = NOVALUE;
    int _put4_1__tmp_at796_19240 = NOVALUE;
    int _x_inlined_put4_at_793_19239 = NOVALUE;
    int _seek_1__tmp_at833_19245 = NOVALUE;
    int _seek_inlined_seek_at_833_19244 = NOVALUE;
    int _pos_inlined_seek_at_830_19243 = NOVALUE;
    int _seek_1__tmp_at884_19255 = NOVALUE;
    int _seek_inlined_seek_at_884_19254 = NOVALUE;
    int _pos_inlined_seek_at_881_19253 = NOVALUE;
    int _put4_1__tmp_at899_19257 = NOVALUE;
    int _put4_1__tmp_at927_19259 = NOVALUE;
    int _seek_1__tmp_at980_19265 = NOVALUE;
    int _seek_inlined_seek_at_980_19264 = NOVALUE;
    int _pos_inlined_seek_at_977_19263 = NOVALUE;
    int _put4_1__tmp_at1001_19268 = NOVALUE;
    int _seek_1__tmp_at1038_19273 = NOVALUE;
    int _seek_inlined_seek_at_1038_19272 = NOVALUE;
    int _pos_inlined_seek_at_1035_19271 = NOVALUE;
    int _s_inlined_putn_at_1136_19291 = NOVALUE;
    int _seek_1__tmp_at1173_19296 = NOVALUE;
    int _seek_inlined_seek_at_1173_19295 = NOVALUE;
    int _pos_inlined_seek_at_1170_19294 = NOVALUE;
    int _put4_1__tmp_at1188_19298 = NOVALUE;
    int _10770 = NOVALUE;
    int _10769 = NOVALUE;
    int _10768 = NOVALUE;
    int _10767 = NOVALUE;
    int _10764 = NOVALUE;
    int _10763 = NOVALUE;
    int _10761 = NOVALUE;
    int _10759 = NOVALUE;
    int _10758 = NOVALUE;
    int _10756 = NOVALUE;
    int _10755 = NOVALUE;
    int _10753 = NOVALUE;
    int _10752 = NOVALUE;
    int _10750 = NOVALUE;
    int _10749 = NOVALUE;
    int _10748 = NOVALUE;
    int _10747 = NOVALUE;
    int _10746 = NOVALUE;
    int _10745 = NOVALUE;
    int _10744 = NOVALUE;
    int _10743 = NOVALUE;
    int _10742 = NOVALUE;
    int _10739 = NOVALUE;
    int _10738 = NOVALUE;
    int _10737 = NOVALUE;
    int _10736 = NOVALUE;
    int _10733 = NOVALUE;
    int _10730 = NOVALUE;
    int _10729 = NOVALUE;
    int _10728 = NOVALUE;
    int _10727 = NOVALUE;
    int _10723 = NOVALUE;
    int _10722 = NOVALUE;
    int _10720 = NOVALUE;
    int _10719 = NOVALUE;
    int _10717 = NOVALUE;
    int _10716 = NOVALUE;
    int _10715 = NOVALUE;
    int _10714 = NOVALUE;
    int _10713 = NOVALUE;
    int _10712 = NOVALUE;
    int _10711 = NOVALUE;
    int _10709 = NOVALUE;
    int _10706 = NOVALUE;
    int _10701 = NOVALUE;
    int _10699 = NOVALUE;
    int _10698 = NOVALUE;
    int _10696 = NOVALUE;
    int _10695 = NOVALUE;
    int _10694 = NOVALUE;
    int _10691 = NOVALUE;
    int _10689 = NOVALUE;
    int _10686 = NOVALUE;
    int _10685 = NOVALUE;
    int _10683 = NOVALUE;
    int _10682 = NOVALUE;
    int _10680 = NOVALUE;
    int _0, _1, _2;
    

    /** 	key_location = db_find_key(key, table_name) -- Let it set the current table if necessary*/
    Ref(_key_19086);
    RefDS(_table_name_19088);
    _0 = _key_location_19100;
    _key_location_19100 = _49db_find_key(_key_19086, _table_name_19088);
    DeRef(_0);

    /** 	if key_location > 0 then*/
    if (binary_op_a(LESSEQ, _key_location_19100, 0)){
        goto L1; // [10] 21
    }

    /** 		return DB_EXISTS_ALREADY*/
    DeRef(_key_19086);
    DeRefDS(_table_name_19088);
    DeRef(_key_string_19089);
    DeRef(_data_string_19090);
    DeRef(_last_part_19091);
    DeRef(_remaining_19092);
    DeRef(_key_ptr_19093);
    DeRef(_data_ptr_19094);
    DeRef(_records_ptr_19095);
    DeRef(_nrecs_19096);
    DeRef(_current_block_19097);
    DeRef(_size_19098);
    DeRef(_new_size_19099);
    DeRef(_key_location_19100);
    DeRef(_new_block_19101);
    DeRef(_index_ptr_19102);
    DeRef(_new_index_ptr_19103);
    DeRef(_total_recs_19104);
    return -2;
L1: 

    /** 	key_location = -key_location*/
    _0 = _key_location_19100;
    if (IS_ATOM_INT(_key_location_19100)) {
        if ((unsigned long)_key_location_19100 == 0xC0000000)
        _key_location_19100 = (int)NewDouble((double)-0xC0000000);
        else
        _key_location_19100 = - _key_location_19100;
    }
    else {
        _key_location_19100 = unary_op(UMINUS, _key_location_19100);
    }
    DeRef(_0);

    /** 	data_string = compress(data)*/
    _0 = _data_string_19090;
    _data_string_19090 = _49compress(_data_19087);
    DeRef(_0);

    /** 	key_string  = compress(key)*/
    Ref(_key_19086);
    _0 = _key_string_19089;
    _key_string_19089 = _49compress(_key_19086);
    DeRef(_0);

    /** 	data_ptr = db_allocate(length(data_string))*/
    if (IS_SEQUENCE(_data_string_19090)){
            _10680 = SEQ_PTR(_data_string_19090)->length;
    }
    else {
        _10680 = 1;
    }
    _0 = _data_ptr_19094;
    _data_ptr_19094 = _49db_allocate(_10680);
    DeRef(_0);
    _10680 = NOVALUE;

    /** 	putn(data_string)*/

    /** 	puts(current_db, s)*/
    EPuts(_49current_db_17372, _data_string_19090); // DJP 

    /** end procedure*/
    goto L2; // [62] 65
L2: 

    /** 	key_ptr = db_allocate(4+length(key_string))*/
    if (IS_SEQUENCE(_key_string_19089)){
            _10682 = SEQ_PTR(_key_string_19089)->length;
    }
    else {
        _10682 = 1;
    }
    _10683 = 4 + _10682;
    _10682 = NOVALUE;
    _0 = _key_ptr_19093;
    _key_ptr_19093 = _49db_allocate(_10683);
    DeRef(_0);
    _10683 = NOVALUE;

    /** 	put4(data_ptr)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_49mem0_17414)){
        poke4_addr = (unsigned long *)_49mem0_17414;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_49mem0_17414)->dbl);
    }
    if (IS_ATOM_INT(_data_ptr_19094)) {
        *poke4_addr = (unsigned long)_data_ptr_19094;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_data_ptr_19094)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at79_19122);
    _1 = (int)SEQ_PTR(_49memseq_17649);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at79_19122 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_49current_db_17372, _put4_1__tmp_at79_19122); // DJP 

    /** end procedure*/
    goto L3; // [101] 104
L3: 
    DeRefi(_put4_1__tmp_at79_19122);
    _put4_1__tmp_at79_19122 = NOVALUE;

    /** 	putn(key_string)*/

    /** 	puts(current_db, s)*/
    EPuts(_49current_db_17372, _key_string_19089); // DJP 

    /** end procedure*/
    goto L4; // [117] 120
L4: 

    /** 	io:seek(current_db, current_table_pos+4)*/
    if (IS_ATOM_INT(_49current_table_pos_17373)) {
        _10685 = _49current_table_pos_17373 + 4;
        if ((long)((unsigned long)_10685 + (unsigned long)HIGH_BITS) >= 0) 
        _10685 = NewDouble((double)_10685);
    }
    else {
        _10685 = NewDouble(DBL_PTR(_49current_table_pos_17373)->dbl + (double)4);
    }
    DeRef(_pos_inlined_seek_at_129_19126);
    _pos_inlined_seek_at_129_19126 = _10685;
    _10685 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_129_19126);
    DeRef(_seek_1__tmp_at132_19128);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _49current_db_17372;
    ((int *)_2)[2] = _pos_inlined_seek_at_129_19126;
    _seek_1__tmp_at132_19128 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_132_19127 = machine(19, _seek_1__tmp_at132_19128);
    DeRef(_pos_inlined_seek_at_129_19126);
    _pos_inlined_seek_at_129_19126 = NOVALUE;
    DeRef(_seek_1__tmp_at132_19128);
    _seek_1__tmp_at132_19128 = NOVALUE;

    /** 	total_recs = get4()+1*/
    _10686 = _49get4();
    DeRef(_total_recs_19104);
    if (IS_ATOM_INT(_10686)) {
        _total_recs_19104 = _10686 + 1;
        if (_total_recs_19104 > MAXINT){
            _total_recs_19104 = NewDouble((double)_total_recs_19104);
        }
    }
    else
    _total_recs_19104 = binary_op(PLUS, 1, _10686);
    DeRef(_10686);
    _10686 = NOVALUE;

    /** 	blocks = get4()*/
    _blocks_19106 = _49get4();
    if (!IS_ATOM_INT(_blocks_19106)) {
        _1 = (long)(DBL_PTR(_blocks_19106)->dbl);
        DeRefDS(_blocks_19106);
        _blocks_19106 = _1;
    }

    /** 	io:seek(current_db, current_table_pos+4)*/
    if (IS_ATOM_INT(_49current_table_pos_17373)) {
        _10689 = _49current_table_pos_17373 + 4;
        if ((long)((unsigned long)_10689 + (unsigned long)HIGH_BITS) >= 0) 
        _10689 = NewDouble((double)_10689);
    }
    else {
        _10689 = NewDouble(DBL_PTR(_49current_table_pos_17373)->dbl + (double)4);
    }
    DeRef(_pos_inlined_seek_at_171_19134);
    _pos_inlined_seek_at_171_19134 = _10689;
    _10689 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_171_19134);
    DeRef(_seek_1__tmp_at174_19136);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _49current_db_17372;
    ((int *)_2)[2] = _pos_inlined_seek_at_171_19134;
    _seek_1__tmp_at174_19136 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_174_19135 = machine(19, _seek_1__tmp_at174_19136);
    DeRef(_pos_inlined_seek_at_171_19134);
    _pos_inlined_seek_at_171_19134 = NOVALUE;
    DeRef(_seek_1__tmp_at174_19136);
    _seek_1__tmp_at174_19136 = NOVALUE;

    /** 	put4(total_recs)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_49mem0_17414)){
        poke4_addr = (unsigned long *)_49mem0_17414;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_49mem0_17414)->dbl);
    }
    if (IS_ATOM_INT(_total_recs_19104)) {
        *poke4_addr = (unsigned long)_total_recs_19104;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_total_recs_19104)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at189_19138);
    _1 = (int)SEQ_PTR(_49memseq_17649);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at189_19138 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_49current_db_17372, _put4_1__tmp_at189_19138); // DJP 

    /** end procedure*/
    goto L5; // [211] 214
L5: 
    DeRefi(_put4_1__tmp_at189_19138);
    _put4_1__tmp_at189_19138 = NOVALUE;

    /** 	n = length(key_pointers)*/
    if (IS_SEQUENCE(_49key_pointers_17379)){
            _n_19108 = SEQ_PTR(_49key_pointers_17379)->length;
    }
    else {
        _n_19108 = 1;
    }

    /** 	if key_location >= floor(n/2) then*/
    _10691 = _n_19108 >> 1;
    if (binary_op_a(LESS, _key_location_19100, _10691)){
        _10691 = NOVALUE;
        goto L6; // [229] 268
    }
    DeRef(_10691);
    _10691 = NOVALUE;

    /** 		key_pointers = append(key_pointers, 0)*/
    Append(&_49key_pointers_17379, _49key_pointers_17379, 0);

    /** 		key_pointers[key_location+1..n+1] = key_pointers[key_location..n]*/
    if (IS_ATOM_INT(_key_location_19100)) {
        _10694 = _key_location_19100 + 1;
        if (_10694 > MAXINT){
            _10694 = NewDouble((double)_10694);
        }
    }
    else
    _10694 = binary_op(PLUS, 1, _key_location_19100);
    _10695 = _n_19108 + 1;
    rhs_slice_target = (object_ptr)&_10696;
    RHS_Slice(_49key_pointers_17379, _key_location_19100, _n_19108);
    assign_slice_seq = (s1_ptr *)&_49key_pointers_17379;
    AssignSlice(_10694, _10695, _10696);
    DeRef(_10694);
    _10694 = NOVALUE;
    _10695 = NOVALUE;
    DeRefDS(_10696);
    _10696 = NOVALUE;
    goto L7; // [265] 297
L6: 

    /** 		key_pointers = prepend(key_pointers, 0)*/
    Prepend(&_49key_pointers_17379, _49key_pointers_17379, 0);

    /** 		key_pointers[1..key_location-1] = key_pointers[2..key_location]*/
    if (IS_ATOM_INT(_key_location_19100)) {
        _10698 = _key_location_19100 - 1;
        if ((long)((unsigned long)_10698 +(unsigned long) HIGH_BITS) >= 0){
            _10698 = NewDouble((double)_10698);
        }
    }
    else {
        _10698 = NewDouble(DBL_PTR(_key_location_19100)->dbl - (double)1);
    }
    rhs_slice_target = (object_ptr)&_10699;
    RHS_Slice(_49key_pointers_17379, 2, _key_location_19100);
    assign_slice_seq = (s1_ptr *)&_49key_pointers_17379;
    AssignSlice(1, _10698, _10699);
    DeRef(_10698);
    _10698 = NOVALUE;
    DeRefDS(_10699);
    _10699 = NOVALUE;
L7: 

    /** 	key_pointers[key_location] = key_ptr*/
    Ref(_key_ptr_19093);
    _2 = (int)SEQ_PTR(_49key_pointers_17379);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _49key_pointers_17379 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_key_location_19100))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_key_location_19100)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _key_location_19100);
    _1 = *(int *)_2;
    *(int *)_2 = _key_ptr_19093;
    DeRef(_1);

    /** 	io:seek(current_db, current_table_pos+12) -- get after put - seek is necessary*/
    if (IS_ATOM_INT(_49current_table_pos_17373)) {
        _10701 = _49current_table_pos_17373 + 12;
        if ((long)((unsigned long)_10701 + (unsigned long)HIGH_BITS) >= 0) 
        _10701 = NewDouble((double)_10701);
    }
    else {
        _10701 = NewDouble(DBL_PTR(_49current_table_pos_17373)->dbl + (double)12);
    }
    DeRef(_pos_inlined_seek_at_314_19154);
    _pos_inlined_seek_at_314_19154 = _10701;
    _10701 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_314_19154);
    DeRef(_seek_1__tmp_at317_19156);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _49current_db_17372;
    ((int *)_2)[2] = _pos_inlined_seek_at_314_19154;
    _seek_1__tmp_at317_19156 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_317_19155 = machine(19, _seek_1__tmp_at317_19156);
    DeRef(_pos_inlined_seek_at_314_19154);
    _pos_inlined_seek_at_314_19154 = NOVALUE;
    DeRef(_seek_1__tmp_at317_19156);
    _seek_1__tmp_at317_19156 = NOVALUE;

    /** 	index_ptr = get4()*/
    _0 = _index_ptr_19102;
    _index_ptr_19102 = _49get4();
    DeRef(_0);

    /** 	io:seek(current_db, index_ptr)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_index_ptr_19102);
    DeRef(_seek_1__tmp_at339_19160);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _49current_db_17372;
    ((int *)_2)[2] = _index_ptr_19102;
    _seek_1__tmp_at339_19160 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_339_19159 = machine(19, _seek_1__tmp_at339_19160);
    DeRef(_seek_1__tmp_at339_19160);
    _seek_1__tmp_at339_19160 = NOVALUE;

    /** 	r = 0*/
    _r_19105 = 0;

    /** 	while TRUE do*/
L8: 

    /** 		nrecs = get4()*/
    _0 = _nrecs_19096;
    _nrecs_19096 = _49get4();
    DeRef(_0);

    /** 		records_ptr = get4()*/
    _0 = _records_ptr_19095;
    _records_ptr_19095 = _49get4();
    DeRef(_0);

    /** 		r += nrecs*/
    if (IS_ATOM_INT(_nrecs_19096)) {
        _r_19105 = _r_19105 + _nrecs_19096;
    }
    else {
        _r_19105 = NewDouble((double)_r_19105 + DBL_PTR(_nrecs_19096)->dbl);
    }
    if (!IS_ATOM_INT(_r_19105)) {
        _1 = (long)(DBL_PTR(_r_19105)->dbl);
        DeRefDS(_r_19105);
        _r_19105 = _1;
    }

    /** 		if r + 1 >= key_location then*/
    _10706 = _r_19105 + 1;
    if (_10706 > MAXINT){
        _10706 = NewDouble((double)_10706);
    }
    if (binary_op_a(LESS, _10706, _key_location_19100)){
        DeRef(_10706);
        _10706 = NOVALUE;
        goto L8; // [387] 363
    }
    DeRef(_10706);
    _10706 = NOVALUE;

    /** 			exit*/
    goto L9; // [393] 401

    /** 	end while*/
    goto L8; // [398] 363
L9: 

    /** 	current_block = io:where(current_db)-8*/

    /** 	return machine_func(M_WHERE, fn)*/
    DeRef(_where_inlined_where_at_404_19169);
    _where_inlined_where_at_404_19169 = machine(20, _49current_db_17372);
    DeRef(_current_block_19097);
    if (IS_ATOM_INT(_where_inlined_where_at_404_19169)) {
        _current_block_19097 = _where_inlined_where_at_404_19169 - 8;
        if ((long)((unsigned long)_current_block_19097 +(unsigned long) HIGH_BITS) >= 0){
            _current_block_19097 = NewDouble((double)_current_block_19097);
        }
    }
    else {
        _current_block_19097 = NewDouble(DBL_PTR(_where_inlined_where_at_404_19169)->dbl - (double)8);
    }

    /** 	key_location -= (r-nrecs)*/
    if (IS_ATOM_INT(_nrecs_19096)) {
        _10709 = _r_19105 - _nrecs_19096;
        if ((long)((unsigned long)_10709 +(unsigned long) HIGH_BITS) >= 0){
            _10709 = NewDouble((double)_10709);
        }
    }
    else {
        _10709 = NewDouble((double)_r_19105 - DBL_PTR(_nrecs_19096)->dbl);
    }
    _0 = _key_location_19100;
    if (IS_ATOM_INT(_key_location_19100) && IS_ATOM_INT(_10709)) {
        _key_location_19100 = _key_location_19100 - _10709;
        if ((long)((unsigned long)_key_location_19100 +(unsigned long) HIGH_BITS) >= 0){
            _key_location_19100 = NewDouble((double)_key_location_19100);
        }
    }
    else {
        if (IS_ATOM_INT(_key_location_19100)) {
            _key_location_19100 = NewDouble((double)_key_location_19100 - DBL_PTR(_10709)->dbl);
        }
        else {
            if (IS_ATOM_INT(_10709)) {
                _key_location_19100 = NewDouble(DBL_PTR(_key_location_19100)->dbl - (double)_10709);
            }
            else
            _key_location_19100 = NewDouble(DBL_PTR(_key_location_19100)->dbl - DBL_PTR(_10709)->dbl);
        }
    }
    DeRef(_0);
    DeRef(_10709);
    _10709 = NOVALUE;

    /** 	io:seek(current_db, records_ptr+4*(key_location-1))*/
    if (IS_ATOM_INT(_key_location_19100)) {
        _10711 = _key_location_19100 - 1;
        if ((long)((unsigned long)_10711 +(unsigned long) HIGH_BITS) >= 0){
            _10711 = NewDouble((double)_10711);
        }
    }
    else {
        _10711 = NewDouble(DBL_PTR(_key_location_19100)->dbl - (double)1);
    }
    if (IS_ATOM_INT(_10711)) {
        if (_10711 <= INT15 && _10711 >= -INT15)
        _10712 = 4 * _10711;
        else
        _10712 = NewDouble(4 * (double)_10711);
    }
    else {
        _10712 = NewDouble((double)4 * DBL_PTR(_10711)->dbl);
    }
    DeRef(_10711);
    _10711 = NOVALUE;
    if (IS_ATOM_INT(_records_ptr_19095) && IS_ATOM_INT(_10712)) {
        _10713 = _records_ptr_19095 + _10712;
        if ((long)((unsigned long)_10713 + (unsigned long)HIGH_BITS) >= 0) 
        _10713 = NewDouble((double)_10713);
    }
    else {
        if (IS_ATOM_INT(_records_ptr_19095)) {
            _10713 = NewDouble((double)_records_ptr_19095 + DBL_PTR(_10712)->dbl);
        }
        else {
            if (IS_ATOM_INT(_10712)) {
                _10713 = NewDouble(DBL_PTR(_records_ptr_19095)->dbl + (double)_10712);
            }
            else
            _10713 = NewDouble(DBL_PTR(_records_ptr_19095)->dbl + DBL_PTR(_10712)->dbl);
        }
    }
    DeRef(_10712);
    _10712 = NOVALUE;
    DeRef(_pos_inlined_seek_at_445_19177);
    _pos_inlined_seek_at_445_19177 = _10713;
    _10713 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_445_19177);
    DeRef(_seek_1__tmp_at448_19179);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _49current_db_17372;
    ((int *)_2)[2] = _pos_inlined_seek_at_445_19177;
    _seek_1__tmp_at448_19179 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_448_19178 = machine(19, _seek_1__tmp_at448_19179);
    DeRef(_pos_inlined_seek_at_445_19177);
    _pos_inlined_seek_at_445_19177 = NOVALUE;
    DeRef(_seek_1__tmp_at448_19179);
    _seek_1__tmp_at448_19179 = NOVALUE;

    /** 	for i = key_location to nrecs+1 do*/
    if (IS_ATOM_INT(_nrecs_19096)) {
        _10714 = _nrecs_19096 + 1;
        if (_10714 > MAXINT){
            _10714 = NewDouble((double)_10714);
        }
    }
    else
    _10714 = binary_op(PLUS, 1, _nrecs_19096);
    {
        int _i_19181;
        Ref(_key_location_19100);
        _i_19181 = _key_location_19100;
LA: 
        if (binary_op_a(GREATER, _i_19181, _10714)){
            goto LB; // [468] 527
        }

        /** 		put4(key_pointers[i+r-nrecs])*/
        if (IS_ATOM_INT(_i_19181)) {
            _10715 = _i_19181 + _r_19105;
            if ((long)((unsigned long)_10715 + (unsigned long)HIGH_BITS) >= 0) 
            _10715 = NewDouble((double)_10715);
        }
        else {
            _10715 = NewDouble(DBL_PTR(_i_19181)->dbl + (double)_r_19105);
        }
        if (IS_ATOM_INT(_10715) && IS_ATOM_INT(_nrecs_19096)) {
            _10716 = _10715 - _nrecs_19096;
        }
        else {
            if (IS_ATOM_INT(_10715)) {
                _10716 = NewDouble((double)_10715 - DBL_PTR(_nrecs_19096)->dbl);
            }
            else {
                if (IS_ATOM_INT(_nrecs_19096)) {
                    _10716 = NewDouble(DBL_PTR(_10715)->dbl - (double)_nrecs_19096);
                }
                else
                _10716 = NewDouble(DBL_PTR(_10715)->dbl - DBL_PTR(_nrecs_19096)->dbl);
            }
        }
        DeRef(_10715);
        _10715 = NOVALUE;
        _2 = (int)SEQ_PTR(_49key_pointers_17379);
        if (!IS_ATOM_INT(_10716)){
            _10717 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_10716)->dbl));
        }
        else{
            _10717 = (int)*(((s1_ptr)_2)->base + _10716);
        }
        Ref(_10717);
        DeRef(_x_inlined_put4_at_490_19187);
        _x_inlined_put4_at_490_19187 = _10717;
        _10717 = NOVALUE;

        /** 	poke4(mem0, x) -- faster than doing divides etc.*/
        if (IS_ATOM_INT(_49mem0_17414)){
            poke4_addr = (unsigned long *)_49mem0_17414;
        }
        else {
            poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_49mem0_17414)->dbl);
        }
        if (IS_ATOM_INT(_x_inlined_put4_at_490_19187)) {
            *poke4_addr = (unsigned long)_x_inlined_put4_at_490_19187;
        }
        else if (IS_ATOM(_x_inlined_put4_at_490_19187)) {
            *poke4_addr = (unsigned long)DBL_PTR(_x_inlined_put4_at_490_19187)->dbl;
        }
        else {
            _1 = (int)SEQ_PTR(_x_inlined_put4_at_490_19187);
            _1 = (int)((s1_ptr)_1)->base;
            while (1) {
                _1 += 4;
                _2 = *((int *)_1);
                if (IS_ATOM_INT(_2))
                *(int *)poke4_addr++ = (unsigned long)_2;
                else if (_2 == NOVALUE)
                break;
                else {
                    *(int *)poke4_addr++ = (unsigned long)DBL_PTR(_2)->dbl;
                }
            }
        }

        /** 	puts(current_db, peek(memseq))*/
        DeRefi(_put4_1__tmp_at493_19188);
        _1 = (int)SEQ_PTR(_49memseq_17649);
        poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        poke4_addr = (unsigned long *)NewS1(_2);
        _put4_1__tmp_at493_19188 = MAKE_SEQ(poke4_addr);
        poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
        while (--_2 >= 0) {
            poke4_addr++;
            _1 = (int)(unsigned char)*poke_addr++;
            *(int *)poke4_addr = _1;
        }
        EPuts(_49current_db_17372, _put4_1__tmp_at493_19188); // DJP 

        /** end procedure*/
        goto LC; // [515] 518
LC: 
        DeRef(_x_inlined_put4_at_490_19187);
        _x_inlined_put4_at_490_19187 = NOVALUE;
        DeRefi(_put4_1__tmp_at493_19188);
        _put4_1__tmp_at493_19188 = NOVALUE;

        /** 	end for*/
        _0 = _i_19181;
        if (IS_ATOM_INT(_i_19181)) {
            _i_19181 = _i_19181 + 1;
            if ((long)((unsigned long)_i_19181 +(unsigned long) HIGH_BITS) >= 0){
                _i_19181 = NewDouble((double)_i_19181);
            }
        }
        else {
            _i_19181 = binary_op_a(PLUS, _i_19181, 1);
        }
        DeRef(_0);
        goto LA; // [522] 475
LB: 
        ;
        DeRef(_i_19181);
    }

    /** 	io:seek(current_db, current_block)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_current_block_19097);
    DeRef(_seek_1__tmp_at530_19191);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _49current_db_17372;
    ((int *)_2)[2] = _current_block_19097;
    _seek_1__tmp_at530_19191 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_530_19190 = machine(19, _seek_1__tmp_at530_19191);
    DeRef(_seek_1__tmp_at530_19191);
    _seek_1__tmp_at530_19191 = NOVALUE;

    /** 	nrecs += 1*/
    _0 = _nrecs_19096;
    if (IS_ATOM_INT(_nrecs_19096)) {
        _nrecs_19096 = _nrecs_19096 + 1;
        if (_nrecs_19096 > MAXINT){
            _nrecs_19096 = NewDouble((double)_nrecs_19096);
        }
    }
    else
    _nrecs_19096 = binary_op(PLUS, 1, _nrecs_19096);
    DeRef(_0);

    /** 	put4(nrecs)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_49mem0_17414)){
        poke4_addr = (unsigned long *)_49mem0_17414;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_49mem0_17414)->dbl);
    }
    if (IS_ATOM_INT(_nrecs_19096)) {
        *poke4_addr = (unsigned long)_nrecs_19096;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_nrecs_19096)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at551_19194);
    _1 = (int)SEQ_PTR(_49memseq_17649);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at551_19194 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_49current_db_17372, _put4_1__tmp_at551_19194); // DJP 

    /** end procedure*/
    goto LD; // [573] 576
LD: 
    DeRefi(_put4_1__tmp_at551_19194);
    _put4_1__tmp_at551_19194 = NOVALUE;

    /** 	io:seek(current_db, records_ptr - 4)*/
    if (IS_ATOM_INT(_records_ptr_19095)) {
        _10719 = _records_ptr_19095 - 4;
        if ((long)((unsigned long)_10719 +(unsigned long) HIGH_BITS) >= 0){
            _10719 = NewDouble((double)_10719);
        }
    }
    else {
        _10719 = NewDouble(DBL_PTR(_records_ptr_19095)->dbl - (double)4);
    }
    DeRef(_pos_inlined_seek_at_585_19197);
    _pos_inlined_seek_at_585_19197 = _10719;
    _10719 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_585_19197);
    DeRef(_seek_1__tmp_at588_19199);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _49current_db_17372;
    ((int *)_2)[2] = _pos_inlined_seek_at_585_19197;
    _seek_1__tmp_at588_19199 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_588_19198 = machine(19, _seek_1__tmp_at588_19199);
    DeRef(_pos_inlined_seek_at_585_19197);
    _pos_inlined_seek_at_585_19197 = NOVALUE;
    DeRef(_seek_1__tmp_at588_19199);
    _seek_1__tmp_at588_19199 = NOVALUE;

    /** 	size = get4() - 4*/
    _10720 = _49get4();
    DeRef(_size_19098);
    if (IS_ATOM_INT(_10720)) {
        _size_19098 = _10720 - 4;
        if ((long)((unsigned long)_size_19098 +(unsigned long) HIGH_BITS) >= 0){
            _size_19098 = NewDouble((double)_size_19098);
        }
    }
    else {
        _size_19098 = binary_op(MINUS, _10720, 4);
    }
    DeRef(_10720);
    _10720 = NOVALUE;

    /** 	if nrecs*4 > size-4 then*/
    if (IS_ATOM_INT(_nrecs_19096)) {
        if (_nrecs_19096 == (short)_nrecs_19096)
        _10722 = _nrecs_19096 * 4;
        else
        _10722 = NewDouble(_nrecs_19096 * (double)4);
    }
    else {
        _10722 = NewDouble(DBL_PTR(_nrecs_19096)->dbl * (double)4);
    }
    if (IS_ATOM_INT(_size_19098)) {
        _10723 = _size_19098 - 4;
        if ((long)((unsigned long)_10723 +(unsigned long) HIGH_BITS) >= 0){
            _10723 = NewDouble((double)_10723);
        }
    }
    else {
        _10723 = NewDouble(DBL_PTR(_size_19098)->dbl - (double)4);
    }
    if (binary_op_a(LESSEQ, _10722, _10723)){
        DeRef(_10722);
        _10722 = NOVALUE;
        DeRef(_10723);
        _10723 = NOVALUE;
        goto LE; // [621] 1217
    }
    DeRef(_10722);
    _10722 = NOVALUE;
    DeRef(_10723);
    _10723 = NOVALUE;

    /** 		new_size = 8 * (20 + floor(sqrt(1.5 * total_recs)))*/
    if (IS_ATOM_INT(_total_recs_19104)) {
        _10727 = NewDouble(DBL_PTR(_10726)->dbl * (double)_total_recs_19104);
    }
    else
    _10727 = NewDouble(DBL_PTR(_10726)->dbl * DBL_PTR(_total_recs_19104)->dbl);
    _10728 = unary_op(SQRT, _10727);
    DeRefDS(_10727);
    _10727 = NOVALUE;
    _10729 = unary_op(FLOOR, _10728);
    DeRefDS(_10728);
    _10728 = NOVALUE;
    if (IS_ATOM_INT(_10729)) {
        _10730 = 20 + _10729;
        if ((long)((unsigned long)_10730 + (unsigned long)HIGH_BITS) >= 0) 
        _10730 = NewDouble((double)_10730);
    }
    else {
        _10730 = NewDouble((double)20 + DBL_PTR(_10729)->dbl);
    }
    DeRef(_10729);
    _10729 = NOVALUE;
    DeRef(_new_size_19099);
    if (IS_ATOM_INT(_10730)) {
        if (_10730 <= INT15 && _10730 >= -INT15)
        _new_size_19099 = 8 * _10730;
        else
        _new_size_19099 = NewDouble(8 * (double)_10730);
    }
    else {
        _new_size_19099 = NewDouble((double)8 * DBL_PTR(_10730)->dbl);
    }
    DeRef(_10730);
    _10730 = NOVALUE;

    /** 		new_recs = floor(new_size/8)*/
    if (IS_ATOM_INT(_new_size_19099)) {
        if (8 > 0 && _new_size_19099 >= 0) {
            _new_recs_19107 = _new_size_19099 / 8;
        }
        else {
            temp_dbl = floor((double)_new_size_19099 / (double)8);
            _new_recs_19107 = (long)temp_dbl;
        }
    }
    else {
        _2 = binary_op(DIVIDE, _new_size_19099, 8);
        _new_recs_19107 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    if (!IS_ATOM_INT(_new_recs_19107)) {
        _1 = (long)(DBL_PTR(_new_recs_19107)->dbl);
        DeRefDS(_new_recs_19107);
        _new_recs_19107 = _1;
    }

    /** 		if new_recs > floor(nrecs/2) then*/
    if (IS_ATOM_INT(_nrecs_19096)) {
        _10733 = _nrecs_19096 >> 1;
    }
    else {
        _1 = binary_op(DIVIDE, _nrecs_19096, 2);
        _10733 = unary_op(FLOOR, _1);
        DeRef(_1);
    }
    if (binary_op_a(LESSEQ, _new_recs_19107, _10733)){
        DeRef(_10733);
        _10733 = NOVALUE;
        goto LF; // [659] 672
    }
    DeRef(_10733);
    _10733 = NOVALUE;

    /** 			new_recs = floor(nrecs/2)*/
    if (IS_ATOM_INT(_nrecs_19096)) {
        _new_recs_19107 = _nrecs_19096 >> 1;
    }
    else {
        _1 = binary_op(DIVIDE, _nrecs_19096, 2);
        _new_recs_19107 = unary_op(FLOOR, _1);
        DeRef(_1);
    }
    if (!IS_ATOM_INT(_new_recs_19107)) {
        _1 = (long)(DBL_PTR(_new_recs_19107)->dbl);
        DeRefDS(_new_recs_19107);
        _new_recs_19107 = _1;
    }
LF: 

    /** 		io:seek(current_db, records_ptr + (nrecs-new_recs)*4)*/
    if (IS_ATOM_INT(_nrecs_19096)) {
        _10736 = _nrecs_19096 - _new_recs_19107;
        if ((long)((unsigned long)_10736 +(unsigned long) HIGH_BITS) >= 0){
            _10736 = NewDouble((double)_10736);
        }
    }
    else {
        _10736 = NewDouble(DBL_PTR(_nrecs_19096)->dbl - (double)_new_recs_19107);
    }
    if (IS_ATOM_INT(_10736)) {
        if (_10736 == (short)_10736)
        _10737 = _10736 * 4;
        else
        _10737 = NewDouble(_10736 * (double)4);
    }
    else {
        _10737 = NewDouble(DBL_PTR(_10736)->dbl * (double)4);
    }
    DeRef(_10736);
    _10736 = NOVALUE;
    if (IS_ATOM_INT(_records_ptr_19095) && IS_ATOM_INT(_10737)) {
        _10738 = _records_ptr_19095 + _10737;
        if ((long)((unsigned long)_10738 + (unsigned long)HIGH_BITS) >= 0) 
        _10738 = NewDouble((double)_10738);
    }
    else {
        if (IS_ATOM_INT(_records_ptr_19095)) {
            _10738 = NewDouble((double)_records_ptr_19095 + DBL_PTR(_10737)->dbl);
        }
        else {
            if (IS_ATOM_INT(_10737)) {
                _10738 = NewDouble(DBL_PTR(_records_ptr_19095)->dbl + (double)_10737);
            }
            else
            _10738 = NewDouble(DBL_PTR(_records_ptr_19095)->dbl + DBL_PTR(_10737)->dbl);
        }
    }
    DeRef(_10737);
    _10737 = NOVALUE;
    DeRef(_pos_inlined_seek_at_687_19222);
    _pos_inlined_seek_at_687_19222 = _10738;
    _10738 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_687_19222);
    DeRef(_seek_1__tmp_at690_19224);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _49current_db_17372;
    ((int *)_2)[2] = _pos_inlined_seek_at_687_19222;
    _seek_1__tmp_at690_19224 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_690_19223 = machine(19, _seek_1__tmp_at690_19224);
    DeRef(_pos_inlined_seek_at_687_19222);
    _pos_inlined_seek_at_687_19222 = NOVALUE;
    DeRef(_seek_1__tmp_at690_19224);
    _seek_1__tmp_at690_19224 = NOVALUE;

    /** 		last_part = io:get_bytes(current_db, new_recs*4)*/
    if (_new_recs_19107 == (short)_new_recs_19107)
    _10739 = _new_recs_19107 * 4;
    else
    _10739 = NewDouble(_new_recs_19107 * (double)4);
    _0 = _last_part_19091;
    _last_part_19091 = _8get_bytes(_49current_db_17372, _10739);
    DeRef(_0);
    _10739 = NOVALUE;

    /** 		new_block = db_allocate(new_size)*/
    Ref(_new_size_19099);
    _0 = _new_block_19101;
    _new_block_19101 = _49db_allocate(_new_size_19099);
    DeRef(_0);

    /** 		putn(last_part)*/

    /** 	puts(current_db, s)*/
    EPuts(_49current_db_17372, _last_part_19091); // DJP 

    /** end procedure*/
    goto L10; // [736] 739
L10: 

    /** 		putn(repeat(0, new_size-length(last_part)))*/
    if (IS_SEQUENCE(_last_part_19091)){
            _10742 = SEQ_PTR(_last_part_19091)->length;
    }
    else {
        _10742 = 1;
    }
    if (IS_ATOM_INT(_new_size_19099)) {
        _10743 = _new_size_19099 - _10742;
    }
    else {
        _10743 = NewDouble(DBL_PTR(_new_size_19099)->dbl - (double)_10742);
    }
    _10742 = NOVALUE;
    _10744 = Repeat(0, _10743);
    DeRef(_10743);
    _10743 = NOVALUE;
    DeRefi(_s_inlined_putn_at_751_19233);
    _s_inlined_putn_at_751_19233 = _10744;
    _10744 = NOVALUE;

    /** 	puts(current_db, s)*/
    EPuts(_49current_db_17372, _s_inlined_putn_at_751_19233); // DJP 

    /** end procedure*/
    goto L11; // [766] 769
L11: 
    DeRefi(_s_inlined_putn_at_751_19233);
    _s_inlined_putn_at_751_19233 = NOVALUE;

    /** 		io:seek(current_db, current_block)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_current_block_19097);
    DeRef(_seek_1__tmp_at774_19236);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _49current_db_17372;
    ((int *)_2)[2] = _current_block_19097;
    _seek_1__tmp_at774_19236 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_774_19235 = machine(19, _seek_1__tmp_at774_19236);
    DeRef(_seek_1__tmp_at774_19236);
    _seek_1__tmp_at774_19236 = NOVALUE;

    /** 		put4(nrecs-new_recs)*/
    if (IS_ATOM_INT(_nrecs_19096)) {
        _10745 = _nrecs_19096 - _new_recs_19107;
        if ((long)((unsigned long)_10745 +(unsigned long) HIGH_BITS) >= 0){
            _10745 = NewDouble((double)_10745);
        }
    }
    else {
        _10745 = NewDouble(DBL_PTR(_nrecs_19096)->dbl - (double)_new_recs_19107);
    }
    DeRef(_x_inlined_put4_at_793_19239);
    _x_inlined_put4_at_793_19239 = _10745;
    _10745 = NOVALUE;

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_49mem0_17414)){
        poke4_addr = (unsigned long *)_49mem0_17414;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_49mem0_17414)->dbl);
    }
    if (IS_ATOM_INT(_x_inlined_put4_at_793_19239)) {
        *poke4_addr = (unsigned long)_x_inlined_put4_at_793_19239;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_x_inlined_put4_at_793_19239)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at796_19240);
    _1 = (int)SEQ_PTR(_49memseq_17649);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at796_19240 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_49current_db_17372, _put4_1__tmp_at796_19240); // DJP 

    /** end procedure*/
    goto L12; // [818] 821
L12: 
    DeRef(_x_inlined_put4_at_793_19239);
    _x_inlined_put4_at_793_19239 = NOVALUE;
    DeRefi(_put4_1__tmp_at796_19240);
    _put4_1__tmp_at796_19240 = NOVALUE;

    /** 		io:seek(current_db, current_block+8)*/
    if (IS_ATOM_INT(_current_block_19097)) {
        _10746 = _current_block_19097 + 8;
        if ((long)((unsigned long)_10746 + (unsigned long)HIGH_BITS) >= 0) 
        _10746 = NewDouble((double)_10746);
    }
    else {
        _10746 = NewDouble(DBL_PTR(_current_block_19097)->dbl + (double)8);
    }
    DeRef(_pos_inlined_seek_at_830_19243);
    _pos_inlined_seek_at_830_19243 = _10746;
    _10746 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_830_19243);
    DeRef(_seek_1__tmp_at833_19245);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _49current_db_17372;
    ((int *)_2)[2] = _pos_inlined_seek_at_830_19243;
    _seek_1__tmp_at833_19245 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_833_19244 = machine(19, _seek_1__tmp_at833_19245);
    DeRef(_pos_inlined_seek_at_830_19243);
    _pos_inlined_seek_at_830_19243 = NOVALUE;
    DeRef(_seek_1__tmp_at833_19245);
    _seek_1__tmp_at833_19245 = NOVALUE;

    /** 		remaining = io:get_bytes(current_db, index_ptr+blocks*8-(current_block+8))*/
    if (_blocks_19106 == (short)_blocks_19106)
    _10747 = _blocks_19106 * 8;
    else
    _10747 = NewDouble(_blocks_19106 * (double)8);
    if (IS_ATOM_INT(_index_ptr_19102) && IS_ATOM_INT(_10747)) {
        _10748 = _index_ptr_19102 + _10747;
        if ((long)((unsigned long)_10748 + (unsigned long)HIGH_BITS) >= 0) 
        _10748 = NewDouble((double)_10748);
    }
    else {
        if (IS_ATOM_INT(_index_ptr_19102)) {
            _10748 = NewDouble((double)_index_ptr_19102 + DBL_PTR(_10747)->dbl);
        }
        else {
            if (IS_ATOM_INT(_10747)) {
                _10748 = NewDouble(DBL_PTR(_index_ptr_19102)->dbl + (double)_10747);
            }
            else
            _10748 = NewDouble(DBL_PTR(_index_ptr_19102)->dbl + DBL_PTR(_10747)->dbl);
        }
    }
    DeRef(_10747);
    _10747 = NOVALUE;
    if (IS_ATOM_INT(_current_block_19097)) {
        _10749 = _current_block_19097 + 8;
        if ((long)((unsigned long)_10749 + (unsigned long)HIGH_BITS) >= 0) 
        _10749 = NewDouble((double)_10749);
    }
    else {
        _10749 = NewDouble(DBL_PTR(_current_block_19097)->dbl + (double)8);
    }
    if (IS_ATOM_INT(_10748) && IS_ATOM_INT(_10749)) {
        _10750 = _10748 - _10749;
        if ((long)((unsigned long)_10750 +(unsigned long) HIGH_BITS) >= 0){
            _10750 = NewDouble((double)_10750);
        }
    }
    else {
        if (IS_ATOM_INT(_10748)) {
            _10750 = NewDouble((double)_10748 - DBL_PTR(_10749)->dbl);
        }
        else {
            if (IS_ATOM_INT(_10749)) {
                _10750 = NewDouble(DBL_PTR(_10748)->dbl - (double)_10749);
            }
            else
            _10750 = NewDouble(DBL_PTR(_10748)->dbl - DBL_PTR(_10749)->dbl);
        }
    }
    DeRef(_10748);
    _10748 = NOVALUE;
    DeRef(_10749);
    _10749 = NOVALUE;
    _0 = _remaining_19092;
    _remaining_19092 = _8get_bytes(_49current_db_17372, _10750);
    DeRef(_0);
    _10750 = NOVALUE;

    /** 		io:seek(current_db, current_block+8)*/
    if (IS_ATOM_INT(_current_block_19097)) {
        _10752 = _current_block_19097 + 8;
        if ((long)((unsigned long)_10752 + (unsigned long)HIGH_BITS) >= 0) 
        _10752 = NewDouble((double)_10752);
    }
    else {
        _10752 = NewDouble(DBL_PTR(_current_block_19097)->dbl + (double)8);
    }
    DeRef(_pos_inlined_seek_at_881_19253);
    _pos_inlined_seek_at_881_19253 = _10752;
    _10752 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_881_19253);
    DeRef(_seek_1__tmp_at884_19255);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _49current_db_17372;
    ((int *)_2)[2] = _pos_inlined_seek_at_881_19253;
    _seek_1__tmp_at884_19255 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_884_19254 = machine(19, _seek_1__tmp_at884_19255);
    DeRef(_pos_inlined_seek_at_881_19253);
    _pos_inlined_seek_at_881_19253 = NOVALUE;
    DeRef(_seek_1__tmp_at884_19255);
    _seek_1__tmp_at884_19255 = NOVALUE;

    /** 		put4(new_recs)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_49mem0_17414)){
        poke4_addr = (unsigned long *)_49mem0_17414;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_49mem0_17414)->dbl);
    }
    *poke4_addr = (unsigned long)_new_recs_19107;

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at899_19257);
    _1 = (int)SEQ_PTR(_49memseq_17649);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at899_19257 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_49current_db_17372, _put4_1__tmp_at899_19257); // DJP 

    /** end procedure*/
    goto L13; // [921] 924
L13: 
    DeRefi(_put4_1__tmp_at899_19257);
    _put4_1__tmp_at899_19257 = NOVALUE;

    /** 		put4(new_block)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_49mem0_17414)){
        poke4_addr = (unsigned long *)_49mem0_17414;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_49mem0_17414)->dbl);
    }
    if (IS_ATOM_INT(_new_block_19101)) {
        *poke4_addr = (unsigned long)_new_block_19101;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_new_block_19101)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at927_19259);
    _1 = (int)SEQ_PTR(_49memseq_17649);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at927_19259 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_49current_db_17372, _put4_1__tmp_at927_19259); // DJP 

    /** end procedure*/
    goto L14; // [949] 952
L14: 
    DeRefi(_put4_1__tmp_at927_19259);
    _put4_1__tmp_at927_19259 = NOVALUE;

    /** 		putn(remaining)*/

    /** 	puts(current_db, s)*/
    EPuts(_49current_db_17372, _remaining_19092); // DJP 

    /** end procedure*/
    goto L15; // [965] 968
L15: 

    /** 		io:seek(current_db, current_table_pos+8)*/
    if (IS_ATOM_INT(_49current_table_pos_17373)) {
        _10753 = _49current_table_pos_17373 + 8;
        if ((long)((unsigned long)_10753 + (unsigned long)HIGH_BITS) >= 0) 
        _10753 = NewDouble((double)_10753);
    }
    else {
        _10753 = NewDouble(DBL_PTR(_49current_table_pos_17373)->dbl + (double)8);
    }
    DeRef(_pos_inlined_seek_at_977_19263);
    _pos_inlined_seek_at_977_19263 = _10753;
    _10753 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_977_19263);
    DeRef(_seek_1__tmp_at980_19265);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _49current_db_17372;
    ((int *)_2)[2] = _pos_inlined_seek_at_977_19263;
    _seek_1__tmp_at980_19265 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_980_19264 = machine(19, _seek_1__tmp_at980_19265);
    DeRef(_pos_inlined_seek_at_977_19263);
    _pos_inlined_seek_at_977_19263 = NOVALUE;
    DeRef(_seek_1__tmp_at980_19265);
    _seek_1__tmp_at980_19265 = NOVALUE;

    /** 		blocks += 1*/
    _blocks_19106 = _blocks_19106 + 1;

    /** 		put4(blocks)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_49mem0_17414)){
        poke4_addr = (unsigned long *)_49mem0_17414;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_49mem0_17414)->dbl);
    }
    *poke4_addr = (unsigned long)_blocks_19106;

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at1001_19268);
    _1 = (int)SEQ_PTR(_49memseq_17649);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at1001_19268 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_49current_db_17372, _put4_1__tmp_at1001_19268); // DJP 

    /** end procedure*/
    goto L16; // [1023] 1026
L16: 
    DeRefi(_put4_1__tmp_at1001_19268);
    _put4_1__tmp_at1001_19268 = NOVALUE;

    /** 		io:seek(current_db, index_ptr-4)*/
    if (IS_ATOM_INT(_index_ptr_19102)) {
        _10755 = _index_ptr_19102 - 4;
        if ((long)((unsigned long)_10755 +(unsigned long) HIGH_BITS) >= 0){
            _10755 = NewDouble((double)_10755);
        }
    }
    else {
        _10755 = NewDouble(DBL_PTR(_index_ptr_19102)->dbl - (double)4);
    }
    DeRef(_pos_inlined_seek_at_1035_19271);
    _pos_inlined_seek_at_1035_19271 = _10755;
    _10755 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_1035_19271);
    DeRef(_seek_1__tmp_at1038_19273);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _49current_db_17372;
    ((int *)_2)[2] = _pos_inlined_seek_at_1035_19271;
    _seek_1__tmp_at1038_19273 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_1038_19272 = machine(19, _seek_1__tmp_at1038_19273);
    DeRef(_pos_inlined_seek_at_1035_19271);
    _pos_inlined_seek_at_1035_19271 = NOVALUE;
    DeRef(_seek_1__tmp_at1038_19273);
    _seek_1__tmp_at1038_19273 = NOVALUE;

    /** 		size = get4() - 4*/
    _10756 = _49get4();
    DeRef(_size_19098);
    if (IS_ATOM_INT(_10756)) {
        _size_19098 = _10756 - 4;
        if ((long)((unsigned long)_size_19098 +(unsigned long) HIGH_BITS) >= 0){
            _size_19098 = NewDouble((double)_size_19098);
        }
    }
    else {
        _size_19098 = binary_op(MINUS, _10756, 4);
    }
    DeRef(_10756);
    _10756 = NOVALUE;

    /** 		if blocks*8 > size-8 then*/
    if (_blocks_19106 == (short)_blocks_19106)
    _10758 = _blocks_19106 * 8;
    else
    _10758 = NewDouble(_blocks_19106 * (double)8);
    if (IS_ATOM_INT(_size_19098)) {
        _10759 = _size_19098 - 8;
        if ((long)((unsigned long)_10759 +(unsigned long) HIGH_BITS) >= 0){
            _10759 = NewDouble((double)_10759);
        }
    }
    else {
        _10759 = NewDouble(DBL_PTR(_size_19098)->dbl - (double)8);
    }
    if (binary_op_a(LESSEQ, _10758, _10759)){
        DeRef(_10758);
        _10758 = NOVALUE;
        DeRef(_10759);
        _10759 = NOVALUE;
        goto L17; // [1071] 1216
    }
    DeRef(_10758);
    _10758 = NOVALUE;
    DeRef(_10759);
    _10759 = NOVALUE;

    /** 			remaining = io:get_bytes(current_db, blocks*8)*/
    if (_blocks_19106 == (short)_blocks_19106)
    _10761 = _blocks_19106 * 8;
    else
    _10761 = NewDouble(_blocks_19106 * (double)8);
    _0 = _remaining_19092;
    _remaining_19092 = _8get_bytes(_49current_db_17372, _10761);
    DeRef(_0);
    _10761 = NOVALUE;

    /** 			new_size = floor(size + size/2)*/
    if (IS_ATOM_INT(_size_19098)) {
        if (_size_19098 & 1) {
            _10763 = NewDouble((_size_19098 >> 1) + 0.5);
        }
        else
        _10763 = _size_19098 >> 1;
    }
    else {
        _10763 = binary_op(DIVIDE, _size_19098, 2);
    }
    if (IS_ATOM_INT(_size_19098) && IS_ATOM_INT(_10763)) {
        _10764 = _size_19098 + _10763;
        if ((long)((unsigned long)_10764 + (unsigned long)HIGH_BITS) >= 0) 
        _10764 = NewDouble((double)_10764);
    }
    else {
        if (IS_ATOM_INT(_size_19098)) {
            _10764 = NewDouble((double)_size_19098 + DBL_PTR(_10763)->dbl);
        }
        else {
            if (IS_ATOM_INT(_10763)) {
                _10764 = NewDouble(DBL_PTR(_size_19098)->dbl + (double)_10763);
            }
            else
            _10764 = NewDouble(DBL_PTR(_size_19098)->dbl + DBL_PTR(_10763)->dbl);
        }
    }
    DeRef(_10763);
    _10763 = NOVALUE;
    DeRef(_new_size_19099);
    if (IS_ATOM_INT(_10764))
    _new_size_19099 = e_floor(_10764);
    else
    _new_size_19099 = unary_op(FLOOR, _10764);
    DeRef(_10764);
    _10764 = NOVALUE;

    /** 			new_index_ptr = db_allocate(new_size)*/
    Ref(_new_size_19099);
    _0 = _new_index_ptr_19103;
    _new_index_ptr_19103 = _49db_allocate(_new_size_19099);
    DeRef(_0);

    /** 			putn(remaining)*/

    /** 	puts(current_db, s)*/
    EPuts(_49current_db_17372, _remaining_19092); // DJP 

    /** end procedure*/
    goto L18; // [1120] 1123
L18: 

    /** 			putn(repeat(0, new_size-blocks*8))*/
    if (_blocks_19106 == (short)_blocks_19106)
    _10767 = _blocks_19106 * 8;
    else
    _10767 = NewDouble(_blocks_19106 * (double)8);
    if (IS_ATOM_INT(_new_size_19099) && IS_ATOM_INT(_10767)) {
        _10768 = _new_size_19099 - _10767;
    }
    else {
        if (IS_ATOM_INT(_new_size_19099)) {
            _10768 = NewDouble((double)_new_size_19099 - DBL_PTR(_10767)->dbl);
        }
        else {
            if (IS_ATOM_INT(_10767)) {
                _10768 = NewDouble(DBL_PTR(_new_size_19099)->dbl - (double)_10767);
            }
            else
            _10768 = NewDouble(DBL_PTR(_new_size_19099)->dbl - DBL_PTR(_10767)->dbl);
        }
    }
    DeRef(_10767);
    _10767 = NOVALUE;
    _10769 = Repeat(0, _10768);
    DeRef(_10768);
    _10768 = NOVALUE;
    DeRefi(_s_inlined_putn_at_1136_19291);
    _s_inlined_putn_at_1136_19291 = _10769;
    _10769 = NOVALUE;

    /** 	puts(current_db, s)*/
    EPuts(_49current_db_17372, _s_inlined_putn_at_1136_19291); // DJP 

    /** end procedure*/
    goto L19; // [1151] 1154
L19: 
    DeRefi(_s_inlined_putn_at_1136_19291);
    _s_inlined_putn_at_1136_19291 = NOVALUE;

    /** 			db_free(index_ptr)*/
    Ref(_index_ptr_19102);
    _49db_free(_index_ptr_19102);

    /** 			io:seek(current_db, current_table_pos+12)*/
    if (IS_ATOM_INT(_49current_table_pos_17373)) {
        _10770 = _49current_table_pos_17373 + 12;
        if ((long)((unsigned long)_10770 + (unsigned long)HIGH_BITS) >= 0) 
        _10770 = NewDouble((double)_10770);
    }
    else {
        _10770 = NewDouble(DBL_PTR(_49current_table_pos_17373)->dbl + (double)12);
    }
    DeRef(_pos_inlined_seek_at_1170_19294);
    _pos_inlined_seek_at_1170_19294 = _10770;
    _10770 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_1170_19294);
    DeRef(_seek_1__tmp_at1173_19296);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _49current_db_17372;
    ((int *)_2)[2] = _pos_inlined_seek_at_1170_19294;
    _seek_1__tmp_at1173_19296 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_1173_19295 = machine(19, _seek_1__tmp_at1173_19296);
    DeRef(_pos_inlined_seek_at_1170_19294);
    _pos_inlined_seek_at_1170_19294 = NOVALUE;
    DeRef(_seek_1__tmp_at1173_19296);
    _seek_1__tmp_at1173_19296 = NOVALUE;

    /** 			put4(new_index_ptr)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_49mem0_17414)){
        poke4_addr = (unsigned long *)_49mem0_17414;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_49mem0_17414)->dbl);
    }
    if (IS_ATOM_INT(_new_index_ptr_19103)) {
        *poke4_addr = (unsigned long)_new_index_ptr_19103;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_new_index_ptr_19103)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at1188_19298);
    _1 = (int)SEQ_PTR(_49memseq_17649);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at1188_19298 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_49current_db_17372, _put4_1__tmp_at1188_19298); // DJP 

    /** end procedure*/
    goto L1A; // [1210] 1213
L1A: 
    DeRefi(_put4_1__tmp_at1188_19298);
    _put4_1__tmp_at1188_19298 = NOVALUE;
L17: 
LE: 

    /** 	return DB_OK*/
    DeRef(_key_19086);
    DeRef(_table_name_19088);
    DeRef(_key_string_19089);
    DeRef(_data_string_19090);
    DeRef(_last_part_19091);
    DeRef(_remaining_19092);
    DeRef(_key_ptr_19093);
    DeRef(_data_ptr_19094);
    DeRef(_records_ptr_19095);
    DeRef(_nrecs_19096);
    DeRef(_current_block_19097);
    DeRef(_size_19098);
    DeRef(_new_size_19099);
    DeRef(_key_location_19100);
    DeRef(_new_block_19101);
    DeRef(_index_ptr_19102);
    DeRef(_new_index_ptr_19103);
    DeRef(_total_recs_19104);
    DeRef(_10714);
    _10714 = NOVALUE;
    DeRef(_10716);
    _10716 = NOVALUE;
    return 0;
    ;
}


void _49db_replace_data(int _key_location_19433, int _data_19434, int _table_name_19435)
{
    int _10844 = NOVALUE;
    int _10843 = NOVALUE;
    int _10842 = NOVALUE;
    int _10841 = NOVALUE;
    int _10839 = NOVALUE;
    int _10838 = NOVALUE;
    int _10836 = NOVALUE;
    int _10833 = NOVALUE;
    int _10831 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not equal(table_name, current_table_name) then*/
    if (_table_name_19435 == _49current_table_name_17374)
    _10831 = 1;
    else if (IS_ATOM_INT(_table_name_19435) && IS_ATOM_INT(_49current_table_name_17374))
    _10831 = 0;
    else
    _10831 = (compare(_table_name_19435, _49current_table_name_17374) == 0);
    if (_10831 != 0)
    goto L1; // [11] 45
    _10831 = NOVALUE;

    /** 		if db_select_table(table_name) != DB_OK then*/
    RefDS(_table_name_19435);
    _10833 = _49db_select_table(_table_name_19435);
    if (binary_op_a(EQUALS, _10833, 0)){
        DeRef(_10833);
        _10833 = NOVALUE;
        goto L2; // [20] 44
    }
    DeRef(_10833);
    _10833 = NOVALUE;

    /** 			fatal(NO_TABLE, "invalid table name given", "db_replace_data", {key_location, data, table_name})*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _key_location_19433;
    *((int *)(_2+8)) = _data_19434;
    RefDS(_table_name_19435);
    *((int *)(_2+12)) = _table_name_19435;
    _10836 = MAKE_SEQ(_1);
    RefDS(_10655);
    RefDS(_10835);
    _49fatal(903, _10655, _10835, _10836);
    _10836 = NOVALUE;

    /** 			return*/
    DeRefDS(_table_name_19435);
    return;
L2: 
L1: 

    /** 	if current_table_pos = -1 then*/
    if (binary_op_a(NOTEQ, _49current_table_pos_17373, -1)){
        goto L3; // [49] 73
    }

    /** 		fatal(NO_TABLE, "no table selected", "db_replace_data", {key_location, data, table_name})*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _key_location_19433;
    *((int *)(_2+8)) = _data_19434;
    Ref(_table_name_19435);
    *((int *)(_2+12)) = _table_name_19435;
    _10838 = MAKE_SEQ(_1);
    RefDS(_10659);
    RefDS(_10835);
    _49fatal(903, _10659, _10835, _10838);
    _10838 = NOVALUE;

    /** 		return*/
    DeRef(_table_name_19435);
    return;
L3: 

    /** 	if key_location < 1 or key_location > length(key_pointers) then*/
    _10839 = (_key_location_19433 < 1);
    if (_10839 != 0) {
        goto L4; // [79] 97
    }
    if (IS_SEQUENCE(_49key_pointers_17379)){
            _10841 = SEQ_PTR(_49key_pointers_17379)->length;
    }
    else {
        _10841 = 1;
    }
    _10842 = (_key_location_19433 > _10841);
    _10841 = NOVALUE;
    if (_10842 == 0)
    {
        DeRef(_10842);
        _10842 = NOVALUE;
        goto L5; // [93] 117
    }
    else{
        DeRef(_10842);
        _10842 = NOVALUE;
    }
L4: 

    /** 		fatal(BAD_RECNO, "bad record number", "db_replace_data", {key_location, data, table_name})*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _key_location_19433;
    *((int *)(_2+8)) = _data_19434;
    Ref(_table_name_19435);
    *((int *)(_2+12)) = _table_name_19435;
    _10843 = MAKE_SEQ(_1);
    RefDS(_10783);
    RefDS(_10835);
    _49fatal(905, _10783, _10835, _10843);
    _10843 = NOVALUE;

    /** 		return*/
    DeRef(_table_name_19435);
    DeRef(_10839);
    _10839 = NOVALUE;
    return;
L5: 

    /** 	db_replace_recid(key_pointers[key_location], data)*/
    _2 = (int)SEQ_PTR(_49key_pointers_17379);
    _10844 = (int)*(((s1_ptr)_2)->base + _key_location_19433);
    Ref(_10844);
    _49db_replace_recid(_10844, _data_19434);
    _10844 = NOVALUE;

    /** end procedure*/
    DeRef(_table_name_19435);
    DeRef(_10839);
    _10839 = NOVALUE;
    return;
    ;
}


int _49db_table_size(int _table_name_19457)
{
    int _10853 = NOVALUE;
    int _10852 = NOVALUE;
    int _10850 = NOVALUE;
    int _10847 = NOVALUE;
    int _10845 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not equal(table_name, current_table_name) then*/
    if (_table_name_19457 == _49current_table_name_17374)
    _10845 = 1;
    else if (IS_ATOM_INT(_table_name_19457) && IS_ATOM_INT(_49current_table_name_17374))
    _10845 = 0;
    else
    _10845 = (compare(_table_name_19457, _49current_table_name_17374) == 0);
    if (_10845 != 0)
    goto L1; // [9] 42
    _10845 = NOVALUE;

    /** 		if db_select_table(table_name) != DB_OK then*/
    RefDS(_table_name_19457);
    _10847 = _49db_select_table(_table_name_19457);
    if (binary_op_a(EQUALS, _10847, 0)){
        DeRef(_10847);
        _10847 = NOVALUE;
        goto L2; // [18] 41
    }
    DeRef(_10847);
    _10847 = NOVALUE;

    /** 			fatal(NO_TABLE, "invalid table name given", "db_table_size", {table_name})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_table_name_19457);
    *((int *)(_2+4)) = _table_name_19457;
    _10850 = MAKE_SEQ(_1);
    RefDS(_10655);
    RefDS(_10849);
    _49fatal(903, _10655, _10849, _10850);
    _10850 = NOVALUE;

    /** 			return -1*/
    DeRefDS(_table_name_19457);
    return -1;
L2: 
L1: 

    /** 	if current_table_pos = -1 then*/
    if (binary_op_a(NOTEQ, _49current_table_pos_17373, -1)){
        goto L3; // [46] 69
    }

    /** 		fatal(NO_TABLE, "no table selected", "db_table_size", {table_name})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_table_name_19457);
    *((int *)(_2+4)) = _table_name_19457;
    _10852 = MAKE_SEQ(_1);
    RefDS(_10659);
    RefDS(_10849);
    _49fatal(903, _10659, _10849, _10852);
    _10852 = NOVALUE;

    /** 		return -1*/
    DeRef(_table_name_19457);
    return -1;
L3: 

    /** 	return length(key_pointers)*/
    if (IS_SEQUENCE(_49key_pointers_17379)){
            _10853 = SEQ_PTR(_49key_pointers_17379)->length;
    }
    else {
        _10853 = 1;
    }
    DeRef(_table_name_19457);
    return _10853;
    ;
}


int _49db_record_data(int _key_location_19472, int _table_name_19473)
{
    int _data_ptr_19474 = NOVALUE;
    int _data_value_19475 = NOVALUE;
    int _seek_1__tmp_at126_19497 = NOVALUE;
    int _seek_inlined_seek_at_126_19496 = NOVALUE;
    int _pos_inlined_seek_at_123_19495 = NOVALUE;
    int _seek_1__tmp_at164_19504 = NOVALUE;
    int _seek_inlined_seek_at_164_19503 = NOVALUE;
    int _10868 = NOVALUE;
    int _10867 = NOVALUE;
    int _10866 = NOVALUE;
    int _10865 = NOVALUE;
    int _10864 = NOVALUE;
    int _10862 = NOVALUE;
    int _10861 = NOVALUE;
    int _10859 = NOVALUE;
    int _10856 = NOVALUE;
    int _10854 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_key_location_19472)) {
        _1 = (long)(DBL_PTR(_key_location_19472)->dbl);
        DeRefDS(_key_location_19472);
        _key_location_19472 = _1;
    }

    /** 	if not equal(table_name, current_table_name) then*/
    if (_table_name_19473 == _49current_table_name_17374)
    _10854 = 1;
    else if (IS_ATOM_INT(_table_name_19473) && IS_ATOM_INT(_49current_table_name_17374))
    _10854 = 0;
    else
    _10854 = (compare(_table_name_19473, _49current_table_name_17374) == 0);
    if (_10854 != 0)
    goto L1; // [11] 44
    _10854 = NOVALUE;

    /** 		if db_select_table(table_name) != DB_OK then*/
    RefDS(_table_name_19473);
    _10856 = _49db_select_table(_table_name_19473);
    if (binary_op_a(EQUALS, _10856, 0)){
        DeRef(_10856);
        _10856 = NOVALUE;
        goto L2; // [20] 43
    }
    DeRef(_10856);
    _10856 = NOVALUE;

    /** 			fatal(NO_TABLE, "invalid table name given", "db_record_data", {key_location, table_name})*/
    RefDS(_table_name_19473);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _key_location_19472;
    ((int *)_2)[2] = _table_name_19473;
    _10859 = MAKE_SEQ(_1);
    RefDS(_10655);
    RefDS(_10858);
    _49fatal(903, _10655, _10858, _10859);
    _10859 = NOVALUE;

    /** 			return -1*/
    DeRefDS(_table_name_19473);
    DeRef(_data_ptr_19474);
    DeRef(_data_value_19475);
    return -1;
L2: 
L1: 

    /** 	if current_table_pos = -1 then*/
    if (binary_op_a(NOTEQ, _49current_table_pos_17373, -1)){
        goto L3; // [48] 71
    }

    /** 		fatal(NO_TABLE, "no table selected", "db_record_data", {key_location, table_name})*/
    Ref(_table_name_19473);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _key_location_19472;
    ((int *)_2)[2] = _table_name_19473;
    _10861 = MAKE_SEQ(_1);
    RefDS(_10659);
    RefDS(_10858);
    _49fatal(903, _10659, _10858, _10861);
    _10861 = NOVALUE;

    /** 		return -1*/
    DeRef(_table_name_19473);
    DeRef(_data_ptr_19474);
    DeRef(_data_value_19475);
    return -1;
L3: 

    /** 	if key_location < 1 or key_location > length(key_pointers) then*/
    _10862 = (_key_location_19472 < 1);
    if (_10862 != 0) {
        goto L4; // [77] 95
    }
    if (IS_SEQUENCE(_49key_pointers_17379)){
            _10864 = SEQ_PTR(_49key_pointers_17379)->length;
    }
    else {
        _10864 = 1;
    }
    _10865 = (_key_location_19472 > _10864);
    _10864 = NOVALUE;
    if (_10865 == 0)
    {
        DeRef(_10865);
        _10865 = NOVALUE;
        goto L5; // [91] 114
    }
    else{
        DeRef(_10865);
        _10865 = NOVALUE;
    }
L4: 

    /** 		fatal(BAD_RECNO, "bad record number", "db_record_data", {key_location, table_name})*/
    Ref(_table_name_19473);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _key_location_19472;
    ((int *)_2)[2] = _table_name_19473;
    _10866 = MAKE_SEQ(_1);
    RefDS(_10783);
    RefDS(_10858);
    _49fatal(905, _10783, _10858, _10866);
    _10866 = NOVALUE;

    /** 		return -1*/
    DeRef(_table_name_19473);
    DeRef(_data_ptr_19474);
    DeRef(_data_value_19475);
    DeRef(_10862);
    _10862 = NOVALUE;
    return -1;
L5: 

    /** 	io:seek(current_db, key_pointers[key_location])*/
    _2 = (int)SEQ_PTR(_49key_pointers_17379);
    _10867 = (int)*(((s1_ptr)_2)->base + _key_location_19472);
    Ref(_10867);
    DeRef(_pos_inlined_seek_at_123_19495);
    _pos_inlined_seek_at_123_19495 = _10867;
    _10867 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_123_19495);
    DeRef(_seek_1__tmp_at126_19497);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _49current_db_17372;
    ((int *)_2)[2] = _pos_inlined_seek_at_123_19495;
    _seek_1__tmp_at126_19497 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_126_19496 = machine(19, _seek_1__tmp_at126_19497);
    DeRef(_pos_inlined_seek_at_123_19495);
    _pos_inlined_seek_at_123_19495 = NOVALUE;
    DeRef(_seek_1__tmp_at126_19497);
    _seek_1__tmp_at126_19497 = NOVALUE;

    /** 	if length(vLastErrors) > 0 then return -1 end if*/
    if (IS_SEQUENCE(_49vLastErrors_17396)){
            _10868 = SEQ_PTR(_49vLastErrors_17396)->length;
    }
    else {
        _10868 = 1;
    }
    if (_10868 <= 0)
    goto L6; // [147] 156
    DeRef(_table_name_19473);
    DeRef(_data_ptr_19474);
    DeRef(_data_value_19475);
    DeRef(_10862);
    _10862 = NOVALUE;
    return -1;
L6: 

    /** 	data_ptr = get4()*/
    _0 = _data_ptr_19474;
    _data_ptr_19474 = _49get4();
    DeRef(_0);

    /** 	io:seek(current_db, data_ptr)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_data_ptr_19474);
    DeRef(_seek_1__tmp_at164_19504);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _49current_db_17372;
    ((int *)_2)[2] = _data_ptr_19474;
    _seek_1__tmp_at164_19504 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_164_19503 = machine(19, _seek_1__tmp_at164_19504);
    DeRef(_seek_1__tmp_at164_19504);
    _seek_1__tmp_at164_19504 = NOVALUE;

    /** 	data_value = decompress(0)*/
    _0 = _data_value_19475;
    _data_value_19475 = _49decompress(0);
    DeRef(_0);

    /** 	return data_value*/
    DeRef(_table_name_19473);
    DeRef(_data_ptr_19474);
    DeRef(_10862);
    _10862 = NOVALUE;
    return _data_value_19475;
    ;
}


int _49db_fetch_record(int _key_19508, int _table_name_19509)
{
    int _pos_19510 = NOVALUE;
    int _10874 = NOVALUE;
    int _0, _1, _2;
    

    /** 	pos = db_find_key(key, table_name)*/
    Ref(_key_19508);
    RefDS(_table_name_19509);
    _pos_19510 = _49db_find_key(_key_19508, _table_name_19509);
    if (!IS_ATOM_INT(_pos_19510)) {
        _1 = (long)(DBL_PTR(_pos_19510)->dbl);
        DeRefDS(_pos_19510);
        _pos_19510 = _1;
    }

    /** 	if pos > 0 then*/
    if (_pos_19510 <= 0)
    goto L1; // [12] 30

    /** 		return db_record_data(pos, table_name)*/
    RefDS(_table_name_19509);
    _10874 = _49db_record_data(_pos_19510, _table_name_19509);
    DeRef(_key_19508);
    DeRefDS(_table_name_19509);
    return _10874;
    goto L2; // [27] 37
L1: 

    /** 		return pos*/
    DeRef(_key_19508);
    DeRef(_table_name_19509);
    DeRef(_10874);
    _10874 = NOVALUE;
    return _pos_19510;
L2: 
    ;
}


int _49db_record_key(int _key_location_19518, int _table_name_19519)
{
    int _10889 = NOVALUE;
    int _10888 = NOVALUE;
    int _10887 = NOVALUE;
    int _10886 = NOVALUE;
    int _10885 = NOVALUE;
    int _10883 = NOVALUE;
    int _10882 = NOVALUE;
    int _10880 = NOVALUE;
    int _10877 = NOVALUE;
    int _10875 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_key_location_19518)) {
        _1 = (long)(DBL_PTR(_key_location_19518)->dbl);
        DeRefDS(_key_location_19518);
        _key_location_19518 = _1;
    }

    /** 	if not equal(table_name, current_table_name) then*/
    if (_table_name_19519 == _49current_table_name_17374)
    _10875 = 1;
    else if (IS_ATOM_INT(_table_name_19519) && IS_ATOM_INT(_49current_table_name_17374))
    _10875 = 0;
    else
    _10875 = (compare(_table_name_19519, _49current_table_name_17374) == 0);
    if (_10875 != 0)
    goto L1; // [11] 44
    _10875 = NOVALUE;

    /** 		if db_select_table(table_name) != DB_OK then*/
    RefDS(_table_name_19519);
    _10877 = _49db_select_table(_table_name_19519);
    if (binary_op_a(EQUALS, _10877, 0)){
        DeRef(_10877);
        _10877 = NOVALUE;
        goto L2; // [20] 43
    }
    DeRef(_10877);
    _10877 = NOVALUE;

    /** 			fatal(NO_TABLE, "invalid table name given", "db_record_key", {key_location, table_name})*/
    RefDS(_table_name_19519);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _key_location_19518;
    ((int *)_2)[2] = _table_name_19519;
    _10880 = MAKE_SEQ(_1);
    RefDS(_10655);
    RefDS(_10879);
    _49fatal(903, _10655, _10879, _10880);
    _10880 = NOVALUE;

    /** 			return -1*/
    DeRefDS(_table_name_19519);
    return -1;
L2: 
L1: 

    /** 	if current_table_pos = -1 then*/
    if (binary_op_a(NOTEQ, _49current_table_pos_17373, -1)){
        goto L3; // [48] 71
    }

    /** 		fatal(NO_TABLE, "no table selected", "db_record_key", {key_location, table_name})*/
    Ref(_table_name_19519);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _key_location_19518;
    ((int *)_2)[2] = _table_name_19519;
    _10882 = MAKE_SEQ(_1);
    RefDS(_10659);
    RefDS(_10879);
    _49fatal(903, _10659, _10879, _10882);
    _10882 = NOVALUE;

    /** 		return -1*/
    DeRef(_table_name_19519);
    return -1;
L3: 

    /** 	if key_location < 1 or key_location > length(key_pointers) then*/
    _10883 = (_key_location_19518 < 1);
    if (_10883 != 0) {
        goto L4; // [77] 95
    }
    if (IS_SEQUENCE(_49key_pointers_17379)){
            _10885 = SEQ_PTR(_49key_pointers_17379)->length;
    }
    else {
        _10885 = 1;
    }
    _10886 = (_key_location_19518 > _10885);
    _10885 = NOVALUE;
    if (_10886 == 0)
    {
        DeRef(_10886);
        _10886 = NOVALUE;
        goto L5; // [91] 114
    }
    else{
        DeRef(_10886);
        _10886 = NOVALUE;
    }
L4: 

    /** 		fatal(BAD_RECNO, "bad record number", "db_record_key", {key_location, table_name})*/
    Ref(_table_name_19519);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _key_location_19518;
    ((int *)_2)[2] = _table_name_19519;
    _10887 = MAKE_SEQ(_1);
    RefDS(_10783);
    RefDS(_10879);
    _49fatal(905, _10783, _10879, _10887);
    _10887 = NOVALUE;

    /** 		return -1*/
    DeRef(_table_name_19519);
    DeRef(_10883);
    _10883 = NOVALUE;
    return -1;
L5: 

    /** 	return key_value(key_pointers[key_location])*/
    _2 = (int)SEQ_PTR(_49key_pointers_17379);
    _10888 = (int)*(((s1_ptr)_2)->base + _key_location_19518);
    Ref(_10888);
    _10889 = _49key_value(_10888);
    _10888 = NOVALUE;
    DeRef(_table_name_19519);
    DeRef(_10883);
    _10883 = NOVALUE;
    return _10889;
    ;
}


void _49db_replace_recid(int _recid_19632, int _data_19633)
{
    int _old_size_19634 = NOVALUE;
    int _new_size_19635 = NOVALUE;
    int _data_ptr_19636 = NOVALUE;
    int _data_string_19637 = NOVALUE;
    int _put4_1__tmp_at111_19657 = NOVALUE;
    int _10988 = NOVALUE;
    int _10987 = NOVALUE;
    int _10986 = NOVALUE;
    int _10985 = NOVALUE;
    int _10984 = NOVALUE;
    int _10956 = NOVALUE;
    int _10954 = NOVALUE;
    int _10953 = NOVALUE;
    int _10952 = NOVALUE;
    int _10951 = NOVALUE;
    int _10950 = NOVALUE;
    int _10946 = NOVALUE;
    int _10945 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_recid_19632)) {
        _1 = (long)(DBL_PTR(_recid_19632)->dbl);
        DeRefDS(_recid_19632);
        _recid_19632 = _1;
    }

    /** 	seek(current_db, recid)*/
    _10988 = _8seek(_49current_db_17372, _recid_19632);
    DeRef(_10988);
    _10988 = NOVALUE;

    /** 	data_ptr = get4()*/
    _0 = _data_ptr_19636;
    _data_ptr_19636 = _49get4();
    DeRef(_0);

    /** 	seek(current_db, data_ptr-4)*/
    if (IS_ATOM_INT(_data_ptr_19636)) {
        _10945 = _data_ptr_19636 - 4;
        if ((long)((unsigned long)_10945 +(unsigned long) HIGH_BITS) >= 0){
            _10945 = NewDouble((double)_10945);
        }
    }
    else {
        _10945 = NewDouble(DBL_PTR(_data_ptr_19636)->dbl - (double)4);
    }
    _10987 = _8seek(_49current_db_17372, _10945);
    _10945 = NOVALUE;
    DeRef(_10987);
    _10987 = NOVALUE;

    /** 	old_size = get4()-4*/
    _10946 = _49get4();
    DeRef(_old_size_19634);
    if (IS_ATOM_INT(_10946)) {
        _old_size_19634 = _10946 - 4;
        if ((long)((unsigned long)_old_size_19634 +(unsigned long) HIGH_BITS) >= 0){
            _old_size_19634 = NewDouble((double)_old_size_19634);
        }
    }
    else {
        _old_size_19634 = binary_op(MINUS, _10946, 4);
    }
    DeRef(_10946);
    _10946 = NOVALUE;

    /** 	data_string = compress(data)*/
    _0 = _data_string_19637;
    _data_string_19637 = _49compress(_data_19633);
    DeRef(_0);

    /** 	new_size = length(data_string)*/
    if (IS_SEQUENCE(_data_string_19637)){
            _new_size_19635 = SEQ_PTR(_data_string_19637)->length;
    }
    else {
        _new_size_19635 = 1;
    }

    /** 	if new_size <= old_size and*/
    if (IS_ATOM_INT(_old_size_19634)) {
        _10950 = (_new_size_19635 <= _old_size_19634);
    }
    else {
        _10950 = ((double)_new_size_19635 <= DBL_PTR(_old_size_19634)->dbl);
    }
    if (_10950 == 0) {
        goto L1; // [62] 92
    }
    if (IS_ATOM_INT(_old_size_19634)) {
        _10952 = _old_size_19634 - 16;
        if ((long)((unsigned long)_10952 +(unsigned long) HIGH_BITS) >= 0){
            _10952 = NewDouble((double)_10952);
        }
    }
    else {
        _10952 = NewDouble(DBL_PTR(_old_size_19634)->dbl - (double)16);
    }
    if (IS_ATOM_INT(_10952)) {
        _10953 = (_new_size_19635 >= _10952);
    }
    else {
        _10953 = ((double)_new_size_19635 >= DBL_PTR(_10952)->dbl);
    }
    DeRef(_10952);
    _10952 = NOVALUE;
    if (_10953 == 0)
    {
        DeRef(_10953);
        _10953 = NOVALUE;
        goto L1; // [75] 92
    }
    else{
        DeRef(_10953);
        _10953 = NOVALUE;
    }

    /** 		seek(current_db, data_ptr)*/
    Ref(_data_ptr_19636);
    _10986 = _8seek(_49current_db_17372, _data_ptr_19636);
    DeRef(_10986);
    _10986 = NOVALUE;
    goto L2; // [89] 168
L1: 

    /** 		db_free(data_ptr)*/
    Ref(_data_ptr_19636);
    _49db_free(_data_ptr_19636);

    /** 		data_ptr = db_allocate(new_size + 8)*/
    _10954 = _new_size_19635 + 8;
    if ((long)((unsigned long)_10954 + (unsigned long)HIGH_BITS) >= 0) 
    _10954 = NewDouble((double)_10954);
    _0 = _data_ptr_19636;
    _data_ptr_19636 = _49db_allocate(_10954);
    DeRef(_0);
    _10954 = NOVALUE;

    /** 		seek(current_db, recid)*/
    _10985 = _8seek(_49current_db_17372, _recid_19632);
    DeRef(_10985);
    _10985 = NOVALUE;

    /** 		put4(data_ptr)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_49mem0_17414)){
        poke4_addr = (unsigned long *)_49mem0_17414;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_49mem0_17414)->dbl);
    }
    if (IS_ATOM_INT(_data_ptr_19636)) {
        *poke4_addr = (unsigned long)_data_ptr_19636;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_data_ptr_19636)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at111_19657);
    _1 = (int)SEQ_PTR(_49memseq_17649);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at111_19657 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_49current_db_17372, _put4_1__tmp_at111_19657); // DJP 

    /** end procedure*/
    goto L3; // [141] 144
L3: 
    DeRefi(_put4_1__tmp_at111_19657);
    _put4_1__tmp_at111_19657 = NOVALUE;

    /** 		seek(current_db, data_ptr)*/
    Ref(_data_ptr_19636);
    _10984 = _8seek(_49current_db_17372, _data_ptr_19636);
    DeRef(_10984);
    _10984 = NOVALUE;

    /** 		data_string &= repeat( 0, 8 )*/
    _10956 = Repeat(0, 8);
    Concat((object_ptr)&_data_string_19637, _data_string_19637, _10956);
    DeRefDS(_10956);
    _10956 = NOVALUE;
L2: 

    /** 	putn(data_string)*/

    /** 	puts(current_db, s)*/
    EPuts(_49current_db_17372, _data_string_19637); // DJP 

    /** end procedure*/
    goto L4; // [179] 182
L4: 

    /** end procedure*/
    DeRef(_old_size_19634);
    DeRef(_data_ptr_19636);
    DeRef(_data_string_19637);
    DeRef(_10950);
    _10950 = NOVALUE;
    return;
    ;
}



// 0x7A339A34
