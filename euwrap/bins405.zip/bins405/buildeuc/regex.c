// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int _51regex(int _o_21512)
{
    int _12456 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return sequence(o)*/
    _12456 = IS_SEQUENCE(_o_21512);
    DeRef(_o_21512);
    return _12456;
    ;
}


int _51new(int _pattern_21552, int _options_21553)
{
    int _12476 = NOVALUE;
    int _12475 = NOVALUE;
    int _12473 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if sequence(options) then */
    _12473 = 0;
    if (_12473 == 0)
    {
        _12473 = NOVALUE;
        goto L1; // [6] 16
    }
    else{
        _12473 = NOVALUE;
    }

    /** 		options = math:or_all(options) */
    _options_21553 = _20or_all(_options_21553);
L1: 

    /** 	return machine_func(M_PCRE_COMPILE, { pattern, options })*/
    Ref(_options_21553);
    Ref(_pattern_21552);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _pattern_21552;
    ((int *)_2)[2] = _options_21553;
    _12475 = MAKE_SEQ(_1);
    _12476 = machine(68, _12475);
    DeRefDS(_12475);
    _12475 = NOVALUE;
    DeRef(_pattern_21552);
    DeRef(_options_21553);
    return _12476;
    ;
}


int _51get_ovector_size(int _ex_21572, int _maxsize_21573)
{
    int _m_21574 = NOVALUE;
    int _12484 = NOVALUE;
    int _12481 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer m = machine_func(M_PCRE_GET_OVECTOR_SIZE, {ex})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_ex_21572);
    *((int *)(_2+4)) = _ex_21572;
    _12481 = MAKE_SEQ(_1);
    _m_21574 = machine(97, _12481);
    DeRefDS(_12481);
    _12481 = NOVALUE;
    if (!IS_ATOM_INT(_m_21574)) {
        _1 = (long)(DBL_PTR(_m_21574)->dbl);
        DeRefDS(_m_21574);
        _m_21574 = _1;
    }

    /** 	if (m > maxsize) then*/
    if (_m_21574 <= 30)
    goto L1; // [17] 28

    /** 		return maxsize*/
    DeRef(_ex_21572);
    return 30;
L1: 

    /** 	return m+1*/
    _12484 = _m_21574 + 1;
    if (_12484 > MAXINT){
        _12484 = NewDouble((double)_12484);
    }
    DeRef(_ex_21572);
    return _12484;
    ;
}


int _51find(int _re_21582, int _haystack_21584, int _from_21585, int _options_21586, int _size_21587)
{
    int _12491 = NOVALUE;
    int _12490 = NOVALUE;
    int _12489 = NOVALUE;
    int _12486 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_size_21587)) {
        _1 = (long)(DBL_PTR(_size_21587)->dbl);
        DeRefDS(_size_21587);
        _size_21587 = _1;
    }

    /** 	if sequence(options) then */
    _12486 = IS_SEQUENCE(_options_21586);
    if (_12486 == 0)
    {
        _12486 = NOVALUE;
        goto L1; // [10] 20
    }
    else{
        _12486 = NOVALUE;
    }

    /** 		options = math:or_all(options) */
    Ref(_options_21586);
    _0 = _options_21586;
    _options_21586 = _20or_all(_options_21586);
    DeRef(_0);
L1: 

    /** 	if size < 0 then*/
    if (_size_21587 >= 0)
    goto L2; // [22] 32

    /** 		size = 0*/
    _size_21587 = 0;
L2: 

    /** 	return machine_func(M_PCRE_EXEC, { re, haystack, length(haystack), options, from, size })*/
    if (IS_SEQUENCE(_haystack_21584)){
            _12489 = SEQ_PTR(_haystack_21584)->length;
    }
    else {
        _12489 = 1;
    }
    _1 = NewS1(6);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_re_21582);
    *((int *)(_2+4)) = _re_21582;
    Ref(_haystack_21584);
    *((int *)(_2+8)) = _haystack_21584;
    *((int *)(_2+12)) = _12489;
    Ref(_options_21586);
    *((int *)(_2+16)) = _options_21586;
    *((int *)(_2+20)) = _from_21585;
    *((int *)(_2+24)) = _size_21587;
    _12490 = MAKE_SEQ(_1);
    _12489 = NOVALUE;
    _12491 = machine(70, _12490);
    DeRefDS(_12490);
    _12490 = NOVALUE;
    DeRef(_re_21582);
    DeRef(_haystack_21584);
    DeRef(_options_21586);
    return _12491;
    ;
}


int _51find_all(int _re_21599, int _haystack_21601, int _from_21602, int _options_21603, int _size_21604)
{
    int _result_21611 = NOVALUE;
    int _results_21612 = NOVALUE;
    int _pHaystack_21613 = NOVALUE;
    int _12504 = NOVALUE;
    int _12503 = NOVALUE;
    int _12501 = NOVALUE;
    int _12499 = NOVALUE;
    int _12497 = NOVALUE;
    int _12493 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_size_21604)) {
        _1 = (long)(DBL_PTR(_size_21604)->dbl);
        DeRefDS(_size_21604);
        _size_21604 = _1;
    }

    /** 	if sequence(options) then */
    _12493 = IS_SEQUENCE(_options_21603);
    if (_12493 == 0)
    {
        _12493 = NOVALUE;
        goto L1; // [10] 20
    }
    else{
        _12493 = NOVALUE;
    }

    /** 		options = math:or_all(options) */
    Ref(_options_21603);
    _0 = _options_21603;
    _options_21603 = _20or_all(_options_21603);
    DeRef(_0);
L1: 

    /** 	if size < 0 then*/
    if (_size_21604 >= 0)
    goto L2; // [22] 32

    /** 		size = 0*/
    _size_21604 = 0;
L2: 

    /** 	object result*/

    /** 	sequence results = {}*/
    RefDS(_5);
    DeRef(_results_21612);
    _results_21612 = _5;

    /** 	atom pHaystack = machine:allocate_string(haystack)*/
    Ref(_haystack_21601);
    _0 = _pHaystack_21613;
    _pHaystack_21613 = _9allocate_string(_haystack_21601, 0);
    DeRef(_0);

    /** 	while sequence(result) with entry do*/
    goto L3; // [50] 94
L4: 
    _12497 = IS_SEQUENCE(_result_21611);
    if (_12497 == 0)
    {
        _12497 = NOVALUE;
        goto L5; // [58] 117
    }
    else{
        _12497 = NOVALUE;
    }

    /** 		results = append(results, result)*/
    Ref(_result_21611);
    Append(&_results_21612, _results_21612, _result_21611);

    /** 		from = math:max(result) + 1*/
    Ref(_result_21611);
    _12499 = _20max(_result_21611);
    if (IS_ATOM_INT(_12499)) {
        _from_21602 = _12499 + 1;
    }
    else
    { // coercing _from_21602 to an integer 1
        _from_21602 = 1+(long)(DBL_PTR(_12499)->dbl);
        if( !IS_ATOM_INT(_from_21602) ){
            _from_21602 = (object)DBL_PTR(_from_21602)->dbl;
        }
    }
    DeRef(_12499);
    _12499 = NOVALUE;

    /** 		if from > length(haystack) then*/
    if (IS_SEQUENCE(_haystack_21601)){
            _12501 = SEQ_PTR(_haystack_21601)->length;
    }
    else {
        _12501 = 1;
    }
    if (_from_21602 <= _12501)
    goto L6; // [82] 91

    /** 			exit*/
    goto L5; // [88] 117
L6: 

    /** 	entry*/
L3: 

    /** 		result = machine_func(M_PCRE_EXEC, { re, pHaystack, length(haystack), options, from, size })*/
    if (IS_SEQUENCE(_haystack_21601)){
            _12503 = SEQ_PTR(_haystack_21601)->length;
    }
    else {
        _12503 = 1;
    }
    _1 = NewS1(6);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_re_21599);
    *((int *)(_2+4)) = _re_21599;
    Ref(_pHaystack_21613);
    *((int *)(_2+8)) = _pHaystack_21613;
    *((int *)(_2+12)) = _12503;
    Ref(_options_21603);
    *((int *)(_2+16)) = _options_21603;
    *((int *)(_2+20)) = _from_21602;
    *((int *)(_2+24)) = _size_21604;
    _12504 = MAKE_SEQ(_1);
    _12503 = NOVALUE;
    DeRef(_result_21611);
    _result_21611 = machine(70, _12504);
    DeRefDS(_12504);
    _12504 = NOVALUE;

    /** 	end while*/
    goto L4; // [114] 53
L5: 

    /** 	machine:free(pHaystack)*/
    Ref(_pHaystack_21613);
    _9free(_pHaystack_21613);

    /** 	return results*/
    DeRef(_re_21599);
    DeRef(_haystack_21601);
    DeRef(_options_21603);
    DeRef(_result_21611);
    DeRef(_pHaystack_21613);
    return _results_21612;
    ;
}


int _51has_match(int _re_21628, int _haystack_21630, int _from_21631, int _options_21632)
{
    int _12508 = NOVALUE;
    int _12507 = NOVALUE;
    int _12506 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return sequence(find(re, haystack, from, options))*/
    Ref(_re_21628);
    _12506 = _51get_ovector_size(_re_21628, 30);
    Ref(_re_21628);
    Ref(_haystack_21630);
    _12507 = _51find(_re_21628, _haystack_21630, 1, 0, _12506);
    _12506 = NOVALUE;
    _12508 = IS_SEQUENCE(_12507);
    DeRef(_12507);
    _12507 = NOVALUE;
    DeRef(_re_21628);
    DeRef(_haystack_21630);
    return _12508;
    ;
}


int _51matches(int _re_21662, int _haystack_21664, int _from_21665, int _options_21666)
{
    int _str_offsets_21670 = NOVALUE;
    int _match_data_21672 = NOVALUE;
    int _tmp_21682 = NOVALUE;
    int _12545 = NOVALUE;
    int _12544 = NOVALUE;
    int _12543 = NOVALUE;
    int _12542 = NOVALUE;
    int _12541 = NOVALUE;
    int _12539 = NOVALUE;
    int _12538 = NOVALUE;
    int _12537 = NOVALUE;
    int _12536 = NOVALUE;
    int _12534 = NOVALUE;
    int _12533 = NOVALUE;
    int _12532 = NOVALUE;
    int _12531 = NOVALUE;
    int _12529 = NOVALUE;
    int _12528 = NOVALUE;
    int _12527 = NOVALUE;
    int _12524 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if sequence(options) then */
    _12524 = 0;
    if (_12524 == 0)
    {
        _12524 = NOVALUE;
        goto L1; // [8] 18
    }
    else{
        _12524 = NOVALUE;
    }

    /** 		options = math:or_all(options) */
    _options_21666 = _20or_all(0);
L1: 

    /** 	integer str_offsets = and_bits(STRING_OFFSETS, options)*/
    if (IS_ATOM_INT(_options_21666)) {
        {unsigned long tu;
             tu = (unsigned long)201326592 & (unsigned long)_options_21666;
             _str_offsets_21670 = MAKE_UINT(tu);
        }
    }
    else {
        _str_offsets_21670 = binary_op(AND_BITS, 201326592, _options_21666);
    }
    if (!IS_ATOM_INT(_str_offsets_21670)) {
        _1 = (long)(DBL_PTR(_str_offsets_21670)->dbl);
        DeRefDS(_str_offsets_21670);
        _str_offsets_21670 = _1;
    }

    /** 	object match_data = find(re, haystack, from, and_bits(options, not_bits(STRING_OFFSETS)))*/
    _12527 = not_bits(201326592);
    if (IS_ATOM_INT(_options_21666) && IS_ATOM_INT(_12527)) {
        {unsigned long tu;
             tu = (unsigned long)_options_21666 & (unsigned long)_12527;
             _12528 = MAKE_UINT(tu);
        }
    }
    else {
        _12528 = binary_op(AND_BITS, _options_21666, _12527);
    }
    DeRef(_12527);
    _12527 = NOVALUE;
    Ref(_re_21662);
    _12529 = _51get_ovector_size(_re_21662, 30);
    Ref(_re_21662);
    Ref(_haystack_21664);
    _0 = _match_data_21672;
    _match_data_21672 = _51find(_re_21662, _haystack_21664, _from_21665, _12528, _12529);
    DeRef(_0);
    _12528 = NOVALUE;
    _12529 = NOVALUE;

    /** 	if atom(match_data) then */
    _12531 = IS_ATOM(_match_data_21672);
    if (_12531 == 0)
    {
        _12531 = NOVALUE;
        goto L2; // [53] 63
    }
    else{
        _12531 = NOVALUE;
    }

    /** 		return ERROR_NOMATCH */
    DeRef(_re_21662);
    DeRef(_haystack_21664);
    DeRef(_options_21666);
    DeRef(_match_data_21672);
    return -1;
L2: 

    /** 	for i = 1 to length(match_data) do*/
    if (IS_SEQUENCE(_match_data_21672)){
            _12532 = SEQ_PTR(_match_data_21672)->length;
    }
    else {
        _12532 = 1;
    }
    {
        int _i_21680;
        _i_21680 = 1;
L3: 
        if (_i_21680 > _12532){
            goto L4; // [68] 181
        }

        /** 		sequence tmp*/

        /** 		if match_data[i][1] = 0 then*/
        _2 = (int)SEQ_PTR(_match_data_21672);
        _12533 = (int)*(((s1_ptr)_2)->base + _i_21680);
        _2 = (int)SEQ_PTR(_12533);
        _12534 = (int)*(((s1_ptr)_2)->base + 1);
        _12533 = NOVALUE;
        if (binary_op_a(NOTEQ, _12534, 0)){
            _12534 = NOVALUE;
            goto L5; // [87] 101
        }
        _12534 = NOVALUE;

        /** 			tmp = ""*/
        RefDS(_5);
        DeRef(_tmp_21682);
        _tmp_21682 = _5;
        goto L6; // [98] 125
L5: 

        /** 			tmp = haystack[match_data[i][1]..match_data[i][2]]*/
        _2 = (int)SEQ_PTR(_match_data_21672);
        _12536 = (int)*(((s1_ptr)_2)->base + _i_21680);
        _2 = (int)SEQ_PTR(_12536);
        _12537 = (int)*(((s1_ptr)_2)->base + 1);
        _12536 = NOVALUE;
        _2 = (int)SEQ_PTR(_match_data_21672);
        _12538 = (int)*(((s1_ptr)_2)->base + _i_21680);
        _2 = (int)SEQ_PTR(_12538);
        _12539 = (int)*(((s1_ptr)_2)->base + 2);
        _12538 = NOVALUE;
        rhs_slice_target = (object_ptr)&_tmp_21682;
        RHS_Slice(_haystack_21664, _12537, _12539);
L6: 

        /** 		if str_offsets then*/
        if (_str_offsets_21670 == 0)
        {
            goto L7; // [127] 163
        }
        else{
        }

        /** 			match_data[i] = { tmp, match_data[i][1], match_data[i][2] }*/
        _2 = (int)SEQ_PTR(_match_data_21672);
        _12541 = (int)*(((s1_ptr)_2)->base + _i_21680);
        _2 = (int)SEQ_PTR(_12541);
        _12542 = (int)*(((s1_ptr)_2)->base + 1);
        _12541 = NOVALUE;
        _2 = (int)SEQ_PTR(_match_data_21672);
        _12543 = (int)*(((s1_ptr)_2)->base + _i_21680);
        _2 = (int)SEQ_PTR(_12543);
        _12544 = (int)*(((s1_ptr)_2)->base + 2);
        _12543 = NOVALUE;
        _1 = NewS1(3);
        _2 = (int)((s1_ptr)_1)->base;
        RefDS(_tmp_21682);
        *((int *)(_2+4)) = _tmp_21682;
        Ref(_12542);
        *((int *)(_2+8)) = _12542;
        Ref(_12544);
        *((int *)(_2+12)) = _12544;
        _12545 = MAKE_SEQ(_1);
        _12544 = NOVALUE;
        _12542 = NOVALUE;
        _2 = (int)SEQ_PTR(_match_data_21672);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _match_data_21672 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_21680);
        _1 = *(int *)_2;
        *(int *)_2 = _12545;
        if( _1 != _12545 ){
            DeRef(_1);
        }
        _12545 = NOVALUE;
        goto L8; // [160] 172
L7: 

        /** 			match_data[i] = tmp*/
        RefDS(_tmp_21682);
        _2 = (int)SEQ_PTR(_match_data_21672);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _match_data_21672 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_21680);
        _1 = *(int *)_2;
        *(int *)_2 = _tmp_21682;
        DeRef(_1);
L8: 
        DeRef(_tmp_21682);
        _tmp_21682 = NOVALUE;

        /** 	end for*/
        _i_21680 = _i_21680 + 1;
        goto L3; // [176] 75
L4: 
        ;
    }

    /** 	return match_data*/
    DeRef(_re_21662);
    DeRef(_haystack_21664);
    DeRef(_options_21666);
    _12537 = NOVALUE;
    _12539 = NOVALUE;
    return _match_data_21672;
    ;
}


int _51split(int _re_21749, int _text_21751, int _from_21752, int _options_21753)
{
    int _12571 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return split_limit(re, text, 0, from, options)*/
    Ref(_re_21749);
    RefDS(_text_21751);
    _12571 = _51split_limit(_re_21749, _text_21751, 0, 1, 0);
    DeRef(_re_21749);
    DeRefDS(_text_21751);
    return _12571;
    ;
}


int _51split_limit(int _re_21758, int _text_21760, int _limit_21761, int _from_21762, int _options_21763)
{
    int _match_data_21767 = NOVALUE;
    int _result_21770 = NOVALUE;
    int _last_21771 = NOVALUE;
    int _a_21782 = NOVALUE;
    int _12597 = NOVALUE;
    int _12596 = NOVALUE;
    int _12595 = NOVALUE;
    int _12593 = NOVALUE;
    int _12591 = NOVALUE;
    int _12590 = NOVALUE;
    int _12589 = NOVALUE;
    int _12588 = NOVALUE;
    int _12587 = NOVALUE;
    int _12584 = NOVALUE;
    int _12583 = NOVALUE;
    int _12582 = NOVALUE;
    int _12579 = NOVALUE;
    int _12578 = NOVALUE;
    int _12576 = NOVALUE;
    int _12574 = NOVALUE;
    int _12572 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if sequence(options) then */
    _12572 = 0;
    if (_12572 == 0)
    {
        _12572 = NOVALUE;
        goto L1; // [10] 20
    }
    else{
        _12572 = NOVALUE;
    }

    /** 		options = math:or_all(options) */
    _options_21763 = _20or_all(0);
L1: 

    /** 	sequence match_data = find_all(re, text, from, options), result*/
    Ref(_re_21758);
    _12574 = _51get_ovector_size(_re_21758, 30);
    Ref(_re_21758);
    Ref(_text_21760);
    Ref(_options_21763);
    _0 = _match_data_21767;
    _match_data_21767 = _51find_all(_re_21758, _text_21760, _from_21762, _options_21763, _12574);
    DeRef(_0);
    _12574 = NOVALUE;

    /** 	integer last = 1*/
    _last_21771 = 1;

    /** 	if limit = 0 or limit > length(match_data) then*/
    _12576 = (_limit_21761 == 0);
    if (_12576 != 0) {
        goto L2; // [48] 64
    }
    if (IS_SEQUENCE(_match_data_21767)){
            _12578 = SEQ_PTR(_match_data_21767)->length;
    }
    else {
        _12578 = 1;
    }
    _12579 = (_limit_21761 > _12578);
    _12578 = NOVALUE;
    if (_12579 == 0)
    {
        DeRef(_12579);
        _12579 = NOVALUE;
        goto L3; // [60] 70
    }
    else{
        DeRef(_12579);
        _12579 = NOVALUE;
    }
L2: 

    /** 		limit = length(match_data)*/
    if (IS_SEQUENCE(_match_data_21767)){
            _limit_21761 = SEQ_PTR(_match_data_21767)->length;
    }
    else {
        _limit_21761 = 1;
    }
L3: 

    /** 	result = repeat(0, limit)*/
    DeRef(_result_21770);
    _result_21770 = Repeat(0, _limit_21761);

    /** 	for i = 1 to limit do*/
    _12582 = _limit_21761;
    {
        int _i_21780;
        _i_21780 = 1;
L4: 
        if (_i_21780 > _12582){
            goto L5; // [81] 164
        }

        /** 		integer a*/

        /** 		a = match_data[i][1][1]*/
        _2 = (int)SEQ_PTR(_match_data_21767);
        _12583 = (int)*(((s1_ptr)_2)->base + _i_21780);
        _2 = (int)SEQ_PTR(_12583);
        _12584 = (int)*(((s1_ptr)_2)->base + 1);
        _12583 = NOVALUE;
        _2 = (int)SEQ_PTR(_12584);
        _a_21782 = (int)*(((s1_ptr)_2)->base + 1);
        if (!IS_ATOM_INT(_a_21782)){
            _a_21782 = (long)DBL_PTR(_a_21782)->dbl;
        }
        _12584 = NOVALUE;

        /** 		if a = 0 then*/
        if (_a_21782 != 0)
        goto L6; // [108] 121

        /** 			result[i] = ""*/
        RefDS(_5);
        _2 = (int)SEQ_PTR(_result_21770);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _result_21770 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_21780);
        _1 = *(int *)_2;
        *(int *)_2 = _5;
        DeRef(_1);
        goto L7; // [118] 155
L6: 

        /** 			result[i] = text[last..a - 1]*/
        _12587 = _a_21782 - 1;
        rhs_slice_target = (object_ptr)&_12588;
        RHS_Slice(_text_21760, _last_21771, _12587);
        _2 = (int)SEQ_PTR(_result_21770);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _result_21770 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_21780);
        _1 = *(int *)_2;
        *(int *)_2 = _12588;
        if( _1 != _12588 ){
            DeRef(_1);
        }
        _12588 = NOVALUE;

        /** 			last = match_data[i][1][2] + 1*/
        _2 = (int)SEQ_PTR(_match_data_21767);
        _12589 = (int)*(((s1_ptr)_2)->base + _i_21780);
        _2 = (int)SEQ_PTR(_12589);
        _12590 = (int)*(((s1_ptr)_2)->base + 1);
        _12589 = NOVALUE;
        _2 = (int)SEQ_PTR(_12590);
        _12591 = (int)*(((s1_ptr)_2)->base + 2);
        _12590 = NOVALUE;
        if (IS_ATOM_INT(_12591)) {
            _last_21771 = _12591 + 1;
        }
        else
        { // coercing _last_21771 to an integer 1
            _last_21771 = 1+(long)(DBL_PTR(_12591)->dbl);
            if( !IS_ATOM_INT(_last_21771) ){
                _last_21771 = (object)DBL_PTR(_last_21771)->dbl;
            }
        }
        _12591 = NOVALUE;
L7: 

        /** 	end for*/
        _i_21780 = _i_21780 + 1;
        goto L4; // [159] 88
L5: 
        ;
    }

    /** 	if last < length(text) then*/
    if (IS_SEQUENCE(_text_21760)){
            _12593 = SEQ_PTR(_text_21760)->length;
    }
    else {
        _12593 = 1;
    }
    if (_last_21771 >= _12593)
    goto L8; // [169] 192

    /** 		result &= { text[last..$] }*/
    if (IS_SEQUENCE(_text_21760)){
            _12595 = SEQ_PTR(_text_21760)->length;
    }
    else {
        _12595 = 1;
    }
    rhs_slice_target = (object_ptr)&_12596;
    RHS_Slice(_text_21760, _last_21771, _12595);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _12596;
    _12597 = MAKE_SEQ(_1);
    _12596 = NOVALUE;
    Concat((object_ptr)&_result_21770, _result_21770, _12597);
    DeRefDS(_12597);
    _12597 = NOVALUE;
L8: 

    /** 	return result*/
    DeRef(_re_21758);
    DeRef(_text_21760);
    DeRef(_options_21763);
    DeRef(_match_data_21767);
    DeRef(_12576);
    _12576 = NOVALUE;
    DeRef(_12587);
    _12587 = NOVALUE;
    return _result_21770;
    ;
}


int _51find_replace(int _ex_21804, int _text_21806, int _replacement_21807, int _from_21808, int _options_21809)
{
    int _12599 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return find_replace_limit(ex, text, replacement, -1, from, options)*/
    Ref(_ex_21804);
    RefDS(_text_21806);
    RefDS(_replacement_21807);
    _12599 = _51find_replace_limit(_ex_21804, _text_21806, _replacement_21807, -1, 1, 0);
    DeRef(_ex_21804);
    DeRefDS(_text_21806);
    DeRefDS(_replacement_21807);
    return _12599;
    ;
}


int _51find_replace_limit(int _ex_21814, int _text_21816, int _replacement_21817, int _limit_21818, int _from_21819, int _options_21820)
{
    int _12603 = NOVALUE;
    int _12602 = NOVALUE;
    int _12600 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if sequence(options) then */
    _12600 = 0;
    if (_12600 == 0)
    {
        _12600 = NOVALUE;
        goto L1; // [12] 22
    }
    else{
        _12600 = NOVALUE;
    }

    /** 		options = math:or_all(options) */
    _options_21820 = _20or_all(0);
L1: 

    /**     return machine_func(M_PCRE_REPLACE, { ex, text, replacement, options, */
    _1 = NewS1(6);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_ex_21814);
    *((int *)(_2+4)) = _ex_21814;
    Ref(_text_21816);
    *((int *)(_2+8)) = _text_21816;
    RefDS(_replacement_21817);
    *((int *)(_2+12)) = _replacement_21817;
    Ref(_options_21820);
    *((int *)(_2+16)) = _options_21820;
    *((int *)(_2+20)) = _from_21819;
    *((int *)(_2+24)) = _limit_21818;
    _12602 = MAKE_SEQ(_1);
    _12603 = machine(71, _12602);
    DeRefDS(_12602);
    _12602 = NOVALUE;
    DeRef(_ex_21814);
    DeRef(_text_21816);
    DeRefDS(_replacement_21817);
    DeRef(_options_21820);
    return _12603;
    ;
}



// 0x915DAD1F
