// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int _14trim(int _source_8284, int _what_8285, int _ret_index_8286)
{
    int _rpos_8287 = NOVALUE;
    int _lpos_8288 = NOVALUE;
    int _4532 = NOVALUE;
    int _4530 = NOVALUE;
    int _4528 = NOVALUE;
    int _4526 = NOVALUE;
    int _4523 = NOVALUE;
    int _4522 = NOVALUE;
    int _4517 = NOVALUE;
    int _4516 = NOVALUE;
    int _4514 = NOVALUE;
    int _4512 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(what) then*/
    _4512 = 0;
    if (_4512 == 0)
    {
        _4512 = NOVALUE;
        goto L1; // [10] 20
    }
    else{
        _4512 = NOVALUE;
    }

    /** 		what = {what}*/
    _0 = _what_8285;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_what_8285);
    *((int *)(_2+4)) = _what_8285;
    _what_8285 = MAKE_SEQ(_1);
    DeRefDSi(_0);
L1: 

    /** 	lpos = 1*/
    _lpos_8288 = 1;

    /** 	while lpos <= length(source) do*/
L2: 
    if (IS_SEQUENCE(_source_8284)){
            _4514 = SEQ_PTR(_source_8284)->length;
    }
    else {
        _4514 = 1;
    }
    if (_lpos_8288 > _4514)
    goto L3; // [33] 67

    /** 		if not find(source[lpos], what) then*/
    _2 = (int)SEQ_PTR(_source_8284);
    _4516 = (int)*(((s1_ptr)_2)->base + _lpos_8288);
    _4517 = find_from(_4516, _what_8285, 1);
    _4516 = NOVALUE;
    if (_4517 != 0)
    goto L4; // [48] 56
    _4517 = NOVALUE;

    /** 			exit*/
    goto L3; // [53] 67
L4: 

    /** 		lpos += 1*/
    _lpos_8288 = _lpos_8288 + 1;

    /** 	end while*/
    goto L2; // [64] 30
L3: 

    /** 	rpos = length(source)*/
    if (IS_SEQUENCE(_source_8284)){
            _rpos_8287 = SEQ_PTR(_source_8284)->length;
    }
    else {
        _rpos_8287 = 1;
    }

    /** 	while rpos > lpos do*/
L5: 
    if (_rpos_8287 <= _lpos_8288)
    goto L6; // [77] 111

    /** 		if not find(source[rpos], what) then*/
    _2 = (int)SEQ_PTR(_source_8284);
    _4522 = (int)*(((s1_ptr)_2)->base + _rpos_8287);
    _4523 = find_from(_4522, _what_8285, 1);
    _4522 = NOVALUE;
    if (_4523 != 0)
    goto L7; // [92] 100
    _4523 = NOVALUE;

    /** 			exit*/
    goto L6; // [97] 111
L7: 

    /** 		rpos -= 1*/
    _rpos_8287 = _rpos_8287 - 1;

    /** 	end while*/
    goto L5; // [108] 77
L6: 

    /** 	if ret_index then*/
    if (_ret_index_8286 == 0)
    {
        goto L8; // [113] 129
    }
    else{
    }

    /** 		return {lpos, rpos}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _lpos_8288;
    ((int *)_2)[2] = _rpos_8287;
    _4526 = MAKE_SEQ(_1);
    DeRefDS(_source_8284);
    DeRef(_what_8285);
    return _4526;
    goto L9; // [126] 180
L8: 

    /** 		if lpos = 1 then*/
    if (_lpos_8288 != 1)
    goto LA; // [131] 152

    /** 			if rpos = length(source) then*/
    if (IS_SEQUENCE(_source_8284)){
            _4528 = SEQ_PTR(_source_8284)->length;
    }
    else {
        _4528 = 1;
    }
    if (_rpos_8287 != _4528)
    goto LB; // [140] 151

    /** 				return source*/
    DeRef(_what_8285);
    DeRef(_4526);
    _4526 = NOVALUE;
    return _source_8284;
LB: 
LA: 

    /** 		if lpos > length(source) then*/
    if (IS_SEQUENCE(_source_8284)){
            _4530 = SEQ_PTR(_source_8284)->length;
    }
    else {
        _4530 = 1;
    }
    if (_lpos_8288 <= _4530)
    goto LC; // [157] 168

    /** 			return {}*/
    RefDS(_5);
    DeRefDS(_source_8284);
    DeRef(_what_8285);
    DeRef(_4526);
    _4526 = NOVALUE;
    return _5;
LC: 

    /** 		return source[lpos..rpos]*/
    rhs_slice_target = (object_ptr)&_4532;
    RHS_Slice(_source_8284, _lpos_8288, _rpos_8287);
    DeRefDS(_source_8284);
    DeRef(_what_8285);
    DeRef(_4526);
    _4526 = NOVALUE;
    return _4532;
L9: 
    ;
}


int _14change_case(int _x_8495, int _api_8496)
{
    int _changed_text_8497 = NOVALUE;
    int _single_char_8498 = NOVALUE;
    int _len_8499 = NOVALUE;
    int _4663 = NOVALUE;
    int _4661 = NOVALUE;
    int _4659 = NOVALUE;
    int _4658 = NOVALUE;
    int _4655 = NOVALUE;
    int _4653 = NOVALUE;
    int _4651 = NOVALUE;
    int _4650 = NOVALUE;
    int _4649 = NOVALUE;
    int _4648 = NOVALUE;
    int _4647 = NOVALUE;
    int _4644 = NOVALUE;
    int _4642 = NOVALUE;
    int _0, _1, _2;
    

    /** 		integer single_char = 0*/
    _single_char_8498 = 0;

    /** 		if not string(x) then*/
    Ref(_x_8495);
    _4642 = _13string(_x_8495);
    if (IS_ATOM_INT(_4642)) {
        if (_4642 != 0){
            DeRef(_4642);
            _4642 = NOVALUE;
            goto L1; // [12] 95
        }
    }
    else {
        if (DBL_PTR(_4642)->dbl != 0.0){
            DeRef(_4642);
            _4642 = NOVALUE;
            goto L1; // [12] 95
        }
    }
    DeRef(_4642);
    _4642 = NOVALUE;

    /** 			if atom(x) then*/
    _4644 = IS_ATOM(_x_8495);
    if (_4644 == 0)
    {
        _4644 = NOVALUE;
        goto L2; // [20] 50
    }
    else{
        _4644 = NOVALUE;
    }

    /** 				if x = 0 then*/
    if (binary_op_a(NOTEQ, _x_8495, 0)){
        goto L3; // [25] 36
    }

    /** 					return 0*/
    DeRef(_x_8495);
    DeRef(_api_8496);
    DeRefi(_changed_text_8497);
    return 0;
L3: 

    /** 				x = {x}*/
    _0 = _x_8495;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_x_8495);
    *((int *)(_2+4)) = _x_8495;
    _x_8495 = MAKE_SEQ(_1);
    DeRef(_0);

    /** 				single_char = 1*/
    _single_char_8498 = 1;
    goto L4; // [47] 94
L2: 

    /** 				for i = 1 to length(x) do*/
    if (IS_SEQUENCE(_x_8495)){
            _4647 = SEQ_PTR(_x_8495)->length;
    }
    else {
        _4647 = 1;
    }
    {
        int _i_8511;
        _i_8511 = 1;
L5: 
        if (_i_8511 > _4647){
            goto L6; // [55] 87
        }

        /** 					x[i] = change_case(x[i], api)*/
        _2 = (int)SEQ_PTR(_x_8495);
        _4648 = (int)*(((s1_ptr)_2)->base + _i_8511);
        Ref(_api_8496);
        DeRef(_4649);
        _4649 = _api_8496;
        Ref(_4648);
        _4650 = _14change_case(_4648, _4649);
        _4648 = NOVALUE;
        _4649 = NOVALUE;
        _2 = (int)SEQ_PTR(_x_8495);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _x_8495 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_8511);
        _1 = *(int *)_2;
        *(int *)_2 = _4650;
        if( _1 != _4650 ){
            DeRef(_1);
        }
        _4650 = NOVALUE;

        /** 				end for*/
        _i_8511 = _i_8511 + 1;
        goto L5; // [82] 62
L6: 
        ;
    }

    /** 				return x*/
    DeRef(_api_8496);
    DeRefi(_changed_text_8497);
    return _x_8495;
L4: 
L1: 

    /** 		if length(x) = 0 then*/
    if (IS_SEQUENCE(_x_8495)){
            _4651 = SEQ_PTR(_x_8495)->length;
    }
    else {
        _4651 = 1;
    }
    if (_4651 != 0)
    goto L7; // [100] 111

    /** 			return x*/
    DeRef(_api_8496);
    DeRefi(_changed_text_8497);
    return _x_8495;
L7: 

    /** 		if length(x) >= tm_size then*/
    if (IS_SEQUENCE(_x_8495)){
            _4653 = SEQ_PTR(_x_8495)->length;
    }
    else {
        _4653 = 1;
    }
    if (_4653 < _14tm_size_8489)
    goto L8; // [118] 148

    /** 			tm_size = length(x) + 1*/
    if (IS_SEQUENCE(_x_8495)){
            _4655 = SEQ_PTR(_x_8495)->length;
    }
    else {
        _4655 = 1;
    }
    _14tm_size_8489 = _4655 + 1;
    _4655 = NOVALUE;

    /** 			free(temp_mem)*/
    Ref(_14temp_mem_8490);
    _9free(_14temp_mem_8490);

    /** 			temp_mem = allocate(tm_size)*/
    _0 = _9allocate(_14tm_size_8489, 0);
    DeRef(_14temp_mem_8490);
    _14temp_mem_8490 = _0;
L8: 

    /** 		poke(temp_mem, x)*/
    if (IS_ATOM_INT(_14temp_mem_8490)){
        poke_addr = (unsigned char *)_14temp_mem_8490;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_14temp_mem_8490)->dbl);
    }
    if (IS_ATOM_INT(_x_8495)) {
        *poke_addr = (unsigned char)_x_8495;
    }
    else if (IS_ATOM(_x_8495)) {
        *poke_addr = (signed char)DBL_PTR(_x_8495)->dbl;
    }
    else {
        _1 = (int)SEQ_PTR(_x_8495);
        _1 = (int)((s1_ptr)_1)->base;
        while (1) {
            _1 += 4;
            _2 = *((int *)_1);
            if (IS_ATOM_INT(_2))
            *poke_addr++ = (unsigned char)_2;
            else if (_2 == NOVALUE)
            break;
            else {
                *poke_addr++ = (signed char)DBL_PTR(_2)->dbl;
            }
        }
    }

    /** 		len = c_func(api, {temp_mem, length(x)} )*/
    if (IS_SEQUENCE(_x_8495)){
            _4658 = SEQ_PTR(_x_8495)->length;
    }
    else {
        _4658 = 1;
    }
    Ref(_14temp_mem_8490);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _14temp_mem_8490;
    ((int *)_2)[2] = _4658;
    _4659 = MAKE_SEQ(_1);
    _4658 = NOVALUE;
    _len_8499 = call_c(1, _api_8496, _4659);
    DeRefDS(_4659);
    _4659 = NOVALUE;
    if (!IS_ATOM_INT(_len_8499)) {
        _1 = (long)(DBL_PTR(_len_8499)->dbl);
        DeRefDS(_len_8499);
        _len_8499 = _1;
    }

    /** 		changed_text = peek({temp_mem, len})*/
    Ref(_14temp_mem_8490);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _14temp_mem_8490;
    ((int *)_2)[2] = _len_8499;
    _4661 = MAKE_SEQ(_1);
    DeRefi(_changed_text_8497);
    _1 = (int)SEQ_PTR(_4661);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _changed_text_8497 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    DeRefDS(_4661);
    _4661 = NOVALUE;

    /** 		if single_char then*/
    if (_single_char_8498 == 0)
    {
        goto L9; // [188] 204
    }
    else{
    }

    /** 			return changed_text[1]*/
    _2 = (int)SEQ_PTR(_changed_text_8497);
    _4663 = (int)*(((s1_ptr)_2)->base + 1);
    DeRef(_x_8495);
    DeRef(_api_8496);
    DeRefDSi(_changed_text_8497);
    return _4663;
    goto LA; // [201] 211
L9: 

    /** 			return changed_text*/
    DeRef(_x_8495);
    DeRef(_api_8496);
    _4663 = NOVALUE;
    return _changed_text_8497;
LA: 
    ;
}


int _14lower(int _x_8537)
{
    int _4667 = NOVALUE;
    int _4664 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if length(lower_case_SET) != 0 then*/
    _4664 = 0;

    /** 	ifdef WINDOWS then*/

    /** 		return change_case(x, api_CharLowerBuff)*/
    Ref(_x_8537);
    Ref(_14api_CharLowerBuff_8473);
    _4667 = _14change_case(_x_8537, _14api_CharLowerBuff_8473);
    DeRef(_x_8537);
    return _4667;
    ;
}


int _14upper(int _x_8545)
{
    int _4671 = NOVALUE;
    int _4668 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if length(upper_case_SET) != 0 then*/
    _4668 = 0;

    /** 	ifdef WINDOWS then*/

    /** 		return change_case(x, api_CharUpperBuff)*/
    Ref(_x_8545);
    Ref(_14api_CharUpperBuff_8481);
    _4671 = _14change_case(_x_8545, _14api_CharUpperBuff_8481);
    DeRef(_x_8545);
    return _4671;
    ;
}


int _14proper(int _x_8553)
{
    int _pos_8554 = NOVALUE;
    int _inword_8555 = NOVALUE;
    int _convert_8556 = NOVALUE;
    int _res_8557 = NOVALUE;
    int _4701 = NOVALUE;
    int _4700 = NOVALUE;
    int _4699 = NOVALUE;
    int _4698 = NOVALUE;
    int _4697 = NOVALUE;
    int _4696 = NOVALUE;
    int _4695 = NOVALUE;
    int _4694 = NOVALUE;
    int _4693 = NOVALUE;
    int _4692 = NOVALUE;
    int _4690 = NOVALUE;
    int _4689 = NOVALUE;
    int _4684 = NOVALUE;
    int _4681 = NOVALUE;
    int _4678 = NOVALUE;
    int _4675 = NOVALUE;
    int _4674 = NOVALUE;
    int _4673 = NOVALUE;
    int _4672 = NOVALUE;
    int _0, _1, _2;
    

    /** 	inword = 0	-- Initially not in a word*/
    _inword_8555 = 0;

    /** 	convert = 1	-- Initially convert text*/
    _convert_8556 = 1;

    /** 	res = x		-- Work on a copy of the original, in case we need to restore.*/
    RefDS(_x_8553);
    DeRef(_res_8557);
    _res_8557 = _x_8553;

    /** 	for i = 1 to length(res) do*/
    if (IS_SEQUENCE(_res_8557)){
            _4672 = SEQ_PTR(_res_8557)->length;
    }
    else {
        _4672 = 1;
    }
    {
        int _i_8559;
        _i_8559 = 1;
L1: 
        if (_i_8559 > _4672){
            goto L2; // [25] 298
        }

        /** 		if integer(res[i]) then*/
        _2 = (int)SEQ_PTR(_res_8557);
        _4673 = (int)*(((s1_ptr)_2)->base + _i_8559);
        if (IS_ATOM_INT(_4673))
        _4674 = 1;
        else if (IS_ATOM_DBL(_4673))
        _4674 = IS_ATOM_INT(DoubleToInt(_4673));
        else
        _4674 = 0;
        _4673 = NOVALUE;
        if (_4674 == 0)
        {
            _4674 = NOVALUE;
            goto L3; // [41] 209
        }
        else{
            _4674 = NOVALUE;
        }

        /** 			if convert then*/
        if (_convert_8556 == 0)
        {
            goto L4; // [46] 291
        }
        else{
        }

        /** 				pos = types:t_upper(res[i])*/
        _2 = (int)SEQ_PTR(_res_8557);
        _4675 = (int)*(((s1_ptr)_2)->base + _i_8559);
        Ref(_4675);
        _pos_8554 = _13t_upper(_4675);
        _4675 = NOVALUE;
        if (!IS_ATOM_INT(_pos_8554)) {
            _1 = (long)(DBL_PTR(_pos_8554)->dbl);
            DeRefDS(_pos_8554);
            _pos_8554 = _1;
        }

        /** 				if pos = 0 then*/
        if (_pos_8554 != 0)
        goto L5; // [63] 175

        /** 					pos = types:t_lower(res[i])*/
        _2 = (int)SEQ_PTR(_res_8557);
        _4678 = (int)*(((s1_ptr)_2)->base + _i_8559);
        Ref(_4678);
        _pos_8554 = _13t_lower(_4678);
        _4678 = NOVALUE;
        if (!IS_ATOM_INT(_pos_8554)) {
            _1 = (long)(DBL_PTR(_pos_8554)->dbl);
            DeRefDS(_pos_8554);
            _pos_8554 = _1;
        }

        /** 					if pos = 0 then*/
        if (_pos_8554 != 0)
        goto L6; // [81] 138

        /** 						pos = t_digit(res[i])*/
        _2 = (int)SEQ_PTR(_res_8557);
        _4681 = (int)*(((s1_ptr)_2)->base + _i_8559);
        Ref(_4681);
        _pos_8554 = _13t_digit(_4681);
        _4681 = NOVALUE;
        if (!IS_ATOM_INT(_pos_8554)) {
            _1 = (long)(DBL_PTR(_pos_8554)->dbl);
            DeRefDS(_pos_8554);
            _pos_8554 = _1;
        }

        /** 						if pos = 0 then*/
        if (_pos_8554 != 0)
        goto L4; // [99] 291

        /** 							pos = t_specword(res[i])*/
        _2 = (int)SEQ_PTR(_res_8557);
        _4684 = (int)*(((s1_ptr)_2)->base + _i_8559);
        Ref(_4684);
        _pos_8554 = _13t_specword(_4684);
        _4684 = NOVALUE;
        if (!IS_ATOM_INT(_pos_8554)) {
            _1 = (long)(DBL_PTR(_pos_8554)->dbl);
            DeRefDS(_pos_8554);
            _pos_8554 = _1;
        }

        /** 							if pos then*/
        if (_pos_8554 == 0)
        {
            goto L7; // [117] 128
        }
        else{
        }

        /** 								inword = 1*/
        _inword_8555 = 1;
        goto L4; // [125] 291
L7: 

        /** 								inword = 0*/
        _inword_8555 = 0;
        goto L4; // [135] 291
L6: 

        /** 						if inword = 0 then*/
        if (_inword_8555 != 0)
        goto L4; // [140] 291

        /** 							if pos <= 26 then*/
        if (_pos_8554 > 26)
        goto L8; // [146] 165

        /** 								res[i] = upper(res[i]) -- Convert to uppercase*/
        _2 = (int)SEQ_PTR(_res_8557);
        _4689 = (int)*(((s1_ptr)_2)->base + _i_8559);
        Ref(_4689);
        _4690 = _14upper(_4689);
        _4689 = NOVALUE;
        _2 = (int)SEQ_PTR(_res_8557);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _res_8557 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_8559);
        _1 = *(int *)_2;
        *(int *)_2 = _4690;
        if( _1 != _4690 ){
            DeRef(_1);
        }
        _4690 = NOVALUE;
L8: 

        /** 							inword = 1	-- now we are in a word*/
        _inword_8555 = 1;
        goto L4; // [172] 291
L5: 

        /** 					if inword = 1 then*/
        if (_inword_8555 != 1)
        goto L9; // [177] 198

        /** 						res[i] = lower(res[i]) -- Convert to lowercase*/
        _2 = (int)SEQ_PTR(_res_8557);
        _4692 = (int)*(((s1_ptr)_2)->base + _i_8559);
        Ref(_4692);
        _4693 = _14lower(_4692);
        _4692 = NOVALUE;
        _2 = (int)SEQ_PTR(_res_8557);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _res_8557 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_8559);
        _1 = *(int *)_2;
        *(int *)_2 = _4693;
        if( _1 != _4693 ){
            DeRef(_1);
        }
        _4693 = NOVALUE;
        goto L4; // [195] 291
L9: 

        /** 						inword = 1	-- now we are in a word*/
        _inword_8555 = 1;
        goto L4; // [206] 291
L3: 

        /** 			if convert then*/
        if (_convert_8556 == 0)
        {
            goto LA; // [211] 263
        }
        else{
        }

        /** 				for j = 1 to i-1 do*/
        _4694 = _i_8559 - 1;
        {
            int _j_8600;
            _j_8600 = 1;
LB: 
            if (_j_8600 > _4694){
                goto LC; // [220] 257
            }

            /** 					if atom(x[j]) then*/
            _2 = (int)SEQ_PTR(_x_8553);
            _4695 = (int)*(((s1_ptr)_2)->base + _j_8600);
            _4696 = IS_ATOM(_4695);
            _4695 = NOVALUE;
            if (_4696 == 0)
            {
                _4696 = NOVALUE;
                goto LD; // [236] 250
            }
            else{
                _4696 = NOVALUE;
            }

            /** 						res[j] = x[j]*/
            _2 = (int)SEQ_PTR(_x_8553);
            _4697 = (int)*(((s1_ptr)_2)->base + _j_8600);
            Ref(_4697);
            _2 = (int)SEQ_PTR(_res_8557);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _res_8557 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _j_8600);
            _1 = *(int *)_2;
            *(int *)_2 = _4697;
            if( _1 != _4697 ){
                DeRef(_1);
            }
            _4697 = NOVALUE;
LD: 

            /** 				end for*/
            _j_8600 = _j_8600 + 1;
            goto LB; // [252] 227
LC: 
            ;
        }

        /** 				convert = 0*/
        _convert_8556 = 0;
LA: 

        /** 			if sequence(res[i]) then*/
        _2 = (int)SEQ_PTR(_res_8557);
        _4698 = (int)*(((s1_ptr)_2)->base + _i_8559);
        _4699 = IS_SEQUENCE(_4698);
        _4698 = NOVALUE;
        if (_4699 == 0)
        {
            _4699 = NOVALUE;
            goto LE; // [272] 290
        }
        else{
            _4699 = NOVALUE;
        }

        /** 				res[i] = proper(res[i])	-- recursive conversion*/
        _2 = (int)SEQ_PTR(_res_8557);
        _4700 = (int)*(((s1_ptr)_2)->base + _i_8559);
        Ref(_4700);
        _4701 = _14proper(_4700);
        _4700 = NOVALUE;
        _2 = (int)SEQ_PTR(_res_8557);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _res_8557 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_8559);
        _1 = *(int *)_2;
        *(int *)_2 = _4701;
        if( _1 != _4701 ){
            DeRef(_1);
        }
        _4701 = NOVALUE;
LE: 
L4: 

        /** 	end for*/
        _i_8559 = _i_8559 + 1;
        goto L1; // [293] 32
L2: 
        ;
    }

    /** 	return res*/
    DeRefDS(_x_8553);
    DeRef(_4694);
    _4694 = NOVALUE;
    return _res_8557;
    ;
}


int _14quote(int _text_in_8876, int _quote_pair_8877, int _esc_8879, int _sp_8881)
{
    int _4972 = NOVALUE;
    int _4971 = NOVALUE;
    int _4970 = NOVALUE;
    int _4968 = NOVALUE;
    int _4967 = NOVALUE;
    int _4966 = NOVALUE;
    int _4964 = NOVALUE;
    int _4963 = NOVALUE;
    int _4962 = NOVALUE;
    int _4961 = NOVALUE;
    int _4960 = NOVALUE;
    int _4959 = NOVALUE;
    int _4958 = NOVALUE;
    int _4957 = NOVALUE;
    int _4956 = NOVALUE;
    int _4954 = NOVALUE;
    int _4953 = NOVALUE;
    int _4952 = NOVALUE;
    int _4950 = NOVALUE;
    int _4949 = NOVALUE;
    int _4948 = NOVALUE;
    int _4947 = NOVALUE;
    int _4946 = NOVALUE;
    int _4945 = NOVALUE;
    int _4944 = NOVALUE;
    int _4943 = NOVALUE;
    int _4942 = NOVALUE;
    int _4940 = NOVALUE;
    int _4939 = NOVALUE;
    int _4937 = NOVALUE;
    int _4936 = NOVALUE;
    int _4935 = NOVALUE;
    int _4933 = NOVALUE;
    int _4932 = NOVALUE;
    int _4931 = NOVALUE;
    int _4930 = NOVALUE;
    int _4929 = NOVALUE;
    int _4928 = NOVALUE;
    int _4927 = NOVALUE;
    int _4926 = NOVALUE;
    int _4925 = NOVALUE;
    int _4924 = NOVALUE;
    int _4923 = NOVALUE;
    int _4922 = NOVALUE;
    int _4921 = NOVALUE;
    int _4920 = NOVALUE;
    int _4919 = NOVALUE;
    int _4918 = NOVALUE;
    int _4917 = NOVALUE;
    int _4914 = NOVALUE;
    int _4913 = NOVALUE;
    int _4912 = NOVALUE;
    int _4911 = NOVALUE;
    int _4910 = NOVALUE;
    int _4909 = NOVALUE;
    int _4908 = NOVALUE;
    int _4907 = NOVALUE;
    int _4906 = NOVALUE;
    int _4905 = NOVALUE;
    int _4904 = NOVALUE;
    int _4903 = NOVALUE;
    int _4902 = NOVALUE;
    int _4901 = NOVALUE;
    int _4898 = NOVALUE;
    int _4896 = NOVALUE;
    int _4895 = NOVALUE;
    int _4893 = NOVALUE;
    int _4891 = NOVALUE;
    int _4890 = NOVALUE;
    int _4889 = NOVALUE;
    int _4887 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if length(text_in) = 0 then*/
    if (IS_SEQUENCE(_text_in_8876)){
            _4887 = SEQ_PTR(_text_in_8876)->length;
    }
    else {
        _4887 = 1;
    }
    if (_4887 != 0)
    goto L1; // [10] 21

    /** 		return text_in*/
    DeRef(_quote_pair_8877);
    DeRef(_sp_8881);
    return _text_in_8876;
L1: 

    /** 	if atom(quote_pair) then*/
    _4889 = IS_ATOM(_quote_pair_8877);
    if (_4889 == 0)
    {
        _4889 = NOVALUE;
        goto L2; // [26] 46
    }
    else{
        _4889 = NOVALUE;
    }

    /** 		quote_pair = {{quote_pair}, {quote_pair}}*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_quote_pair_8877);
    *((int *)(_2+4)) = _quote_pair_8877;
    _4890 = MAKE_SEQ(_1);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_quote_pair_8877);
    *((int *)(_2+4)) = _quote_pair_8877;
    _4891 = MAKE_SEQ(_1);
    DeRef(_quote_pair_8877);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _4890;
    ((int *)_2)[2] = _4891;
    _quote_pair_8877 = MAKE_SEQ(_1);
    _4891 = NOVALUE;
    _4890 = NOVALUE;
    goto L3; // [43] 89
L2: 

    /** 	elsif length(quote_pair) = 1 then*/
    if (IS_SEQUENCE(_quote_pair_8877)){
            _4893 = SEQ_PTR(_quote_pair_8877)->length;
    }
    else {
        _4893 = 1;
    }
    if (_4893 != 1)
    goto L4; // [51] 72

    /** 		quote_pair = {quote_pair[1], quote_pair[1]}*/
    _2 = (int)SEQ_PTR(_quote_pair_8877);
    _4895 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_quote_pair_8877);
    _4896 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_4896);
    Ref(_4895);
    DeRef(_quote_pair_8877);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _4895;
    ((int *)_2)[2] = _4896;
    _quote_pair_8877 = MAKE_SEQ(_1);
    _4896 = NOVALUE;
    _4895 = NOVALUE;
    goto L3; // [69] 89
L4: 

    /** 	elsif length(quote_pair) = 0 then*/
    if (IS_SEQUENCE(_quote_pair_8877)){
            _4898 = SEQ_PTR(_quote_pair_8877)->length;
    }
    else {
        _4898 = 1;
    }
    if (_4898 != 0)
    goto L5; // [77] 88

    /** 		quote_pair = {"\"", "\""}*/
    RefDS(_4879);
    RefDS(_4879);
    DeRef(_quote_pair_8877);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _4879;
    ((int *)_2)[2] = _4879;
    _quote_pair_8877 = MAKE_SEQ(_1);
L5: 
L3: 

    /** 	if sequence(text_in[1]) then*/
    _2 = (int)SEQ_PTR(_text_in_8876);
    _4901 = (int)*(((s1_ptr)_2)->base + 1);
    _4902 = IS_SEQUENCE(_4901);
    _4901 = NOVALUE;
    if (_4902 == 0)
    {
        _4902 = NOVALUE;
        goto L6; // [98] 166
    }
    else{
        _4902 = NOVALUE;
    }

    /** 		for i = 1 to length(text_in) do*/
    if (IS_SEQUENCE(_text_in_8876)){
            _4903 = SEQ_PTR(_text_in_8876)->length;
    }
    else {
        _4903 = 1;
    }
    {
        int _i_8904;
        _i_8904 = 1;
L7: 
        if (_i_8904 > _4903){
            goto L8; // [106] 159
        }

        /** 			if sequence(text_in[i]) then*/
        _2 = (int)SEQ_PTR(_text_in_8876);
        _4904 = (int)*(((s1_ptr)_2)->base + _i_8904);
        _4905 = IS_SEQUENCE(_4904);
        _4904 = NOVALUE;
        if (_4905 == 0)
        {
            _4905 = NOVALUE;
            goto L9; // [122] 152
        }
        else{
            _4905 = NOVALUE;
        }

        /** 				text_in[i] = quote(text_in[i], quote_pair, esc, sp)*/
        _2 = (int)SEQ_PTR(_text_in_8876);
        _4906 = (int)*(((s1_ptr)_2)->base + _i_8904);
        Ref(_quote_pair_8877);
        DeRef(_4907);
        _4907 = _quote_pair_8877;
        DeRef(_4908);
        _4908 = _esc_8879;
        Ref(_sp_8881);
        DeRef(_4909);
        _4909 = _sp_8881;
        Ref(_4906);
        _4910 = _14quote(_4906, _4907, _4908, _4909);
        _4906 = NOVALUE;
        _4907 = NOVALUE;
        _4908 = NOVALUE;
        _4909 = NOVALUE;
        _2 = (int)SEQ_PTR(_text_in_8876);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _text_in_8876 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_8904);
        _1 = *(int *)_2;
        *(int *)_2 = _4910;
        if( _1 != _4910 ){
            DeRef(_1);
        }
        _4910 = NOVALUE;
L9: 

        /** 		end for*/
        _i_8904 = _i_8904 + 1;
        goto L7; // [154] 113
L8: 
        ;
    }

    /** 		return text_in*/
    DeRef(_quote_pair_8877);
    DeRef(_sp_8881);
    return _text_in_8876;
L6: 

    /** 	for i = 1 to length(sp) do*/
    if (IS_SEQUENCE(_sp_8881)){
            _4911 = SEQ_PTR(_sp_8881)->length;
    }
    else {
        _4911 = 1;
    }
    {
        int _i_8915;
        _i_8915 = 1;
LA: 
        if (_i_8915 > _4911){
            goto LB; // [171] 220
        }

        /** 		if find(sp[i], text_in) then*/
        _2 = (int)SEQ_PTR(_sp_8881);
        _4912 = (int)*(((s1_ptr)_2)->base + _i_8915);
        _4913 = find_from(_4912, _text_in_8876, 1);
        _4912 = NOVALUE;
        if (_4913 == 0)
        {
            _4913 = NOVALUE;
            goto LC; // [189] 197
        }
        else{
            _4913 = NOVALUE;
        }

        /** 			exit*/
        goto LB; // [194] 220
LC: 

        /** 		if i = length(sp) then*/
        if (IS_SEQUENCE(_sp_8881)){
                _4914 = SEQ_PTR(_sp_8881)->length;
        }
        else {
            _4914 = 1;
        }
        if (_i_8915 != _4914)
        goto LD; // [202] 213

        /** 			return text_in*/
        DeRef(_quote_pair_8877);
        DeRef(_sp_8881);
        return _text_in_8876;
LD: 

        /** 	end for*/
        _i_8915 = _i_8915 + 1;
        goto LA; // [215] 178
LB: 
        ;
    }

    /** 	if esc >= 0  then*/
    if (_esc_8879 < 0)
    goto LE; // [222] 561

    /** 		if atom(quote_pair[1]) then*/
    _2 = (int)SEQ_PTR(_quote_pair_8877);
    _4917 = (int)*(((s1_ptr)_2)->base + 1);
    _4918 = IS_ATOM(_4917);
    _4917 = NOVALUE;
    if (_4918 == 0)
    {
        _4918 = NOVALUE;
        goto LF; // [235] 253
    }
    else{
        _4918 = NOVALUE;
    }

    /** 			quote_pair[1] = {quote_pair[1]}*/
    _2 = (int)SEQ_PTR(_quote_pair_8877);
    _4919 = (int)*(((s1_ptr)_2)->base + 1);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_4919);
    *((int *)(_2+4)) = _4919;
    _4920 = MAKE_SEQ(_1);
    _4919 = NOVALUE;
    _2 = (int)SEQ_PTR(_quote_pair_8877);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _quote_pair_8877 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _4920;
    if( _1 != _4920 ){
        DeRef(_1);
    }
    _4920 = NOVALUE;
LF: 

    /** 		if atom(quote_pair[2]) then*/
    _2 = (int)SEQ_PTR(_quote_pair_8877);
    _4921 = (int)*(((s1_ptr)_2)->base + 2);
    _4922 = IS_ATOM(_4921);
    _4921 = NOVALUE;
    if (_4922 == 0)
    {
        _4922 = NOVALUE;
        goto L10; // [262] 280
    }
    else{
        _4922 = NOVALUE;
    }

    /** 			quote_pair[2] = {quote_pair[2]}*/
    _2 = (int)SEQ_PTR(_quote_pair_8877);
    _4923 = (int)*(((s1_ptr)_2)->base + 2);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_4923);
    *((int *)(_2+4)) = _4923;
    _4924 = MAKE_SEQ(_1);
    _4923 = NOVALUE;
    _2 = (int)SEQ_PTR(_quote_pair_8877);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _quote_pair_8877 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _4924;
    if( _1 != _4924 ){
        DeRef(_1);
    }
    _4924 = NOVALUE;
L10: 

    /** 		if equal(quote_pair[1], quote_pair[2]) then*/
    _2 = (int)SEQ_PTR(_quote_pair_8877);
    _4925 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_quote_pair_8877);
    _4926 = (int)*(((s1_ptr)_2)->base + 2);
    if (_4925 == _4926)
    _4927 = 1;
    else if (IS_ATOM_INT(_4925) && IS_ATOM_INT(_4926))
    _4927 = 0;
    else
    _4927 = (compare(_4925, _4926) == 0);
    _4925 = NOVALUE;
    _4926 = NOVALUE;
    if (_4927 == 0)
    {
        _4927 = NOVALUE;
        goto L11; // [294] 372
    }
    else{
        _4927 = NOVALUE;
    }

    /** 			if match(quote_pair[1], text_in) then*/
    _2 = (int)SEQ_PTR(_quote_pair_8877);
    _4928 = (int)*(((s1_ptr)_2)->base + 1);
    _4929 = e_match_from(_4928, _text_in_8876, 1);
    _4928 = NOVALUE;
    if (_4929 == 0)
    {
        _4929 = NOVALUE;
        goto L12; // [308] 560
    }
    else{
        _4929 = NOVALUE;
    }

    /** 				if match(esc & quote_pair[1], text_in) then*/
    _2 = (int)SEQ_PTR(_quote_pair_8877);
    _4930 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_esc_8879) && IS_ATOM(_4930)) {
    }
    else if (IS_ATOM(_esc_8879) && IS_SEQUENCE(_4930)) {
        Prepend(&_4931, _4930, _esc_8879);
    }
    else {
        Concat((object_ptr)&_4931, _esc_8879, _4930);
    }
    _4930 = NOVALUE;
    _4932 = e_match_from(_4931, _text_in_8876, 1);
    DeRefDS(_4931);
    _4931 = NOVALUE;
    if (_4932 == 0)
    {
        _4932 = NOVALUE;
        goto L13; // [326] 345
    }
    else{
        _4932 = NOVALUE;
    }

    /** 					text_in = search:match_replace(esc, text_in, esc & esc)*/
    Concat((object_ptr)&_4933, _esc_8879, _esc_8879);
    RefDS(_text_in_8876);
    _0 = _text_in_8876;
    _text_in_8876 = _16match_replace(_esc_8879, _text_in_8876, _4933, 0);
    DeRefDS(_0);
    _4933 = NOVALUE;
L13: 

    /** 				text_in = search:match_replace(quote_pair[1], text_in, esc & quote_pair[1])*/
    _2 = (int)SEQ_PTR(_quote_pair_8877);
    _4935 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_quote_pair_8877);
    _4936 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_esc_8879) && IS_ATOM(_4936)) {
    }
    else if (IS_ATOM(_esc_8879) && IS_SEQUENCE(_4936)) {
        Prepend(&_4937, _4936, _esc_8879);
    }
    else {
        Concat((object_ptr)&_4937, _esc_8879, _4936);
    }
    _4936 = NOVALUE;
    Ref(_4935);
    RefDS(_text_in_8876);
    _0 = _text_in_8876;
    _text_in_8876 = _16match_replace(_4935, _text_in_8876, _4937, 0);
    DeRefDS(_0);
    _4935 = NOVALUE;
    _4937 = NOVALUE;
    goto L12; // [369] 560
L11: 

    /** 			if match(quote_pair[1], text_in) or*/
    _2 = (int)SEQ_PTR(_quote_pair_8877);
    _4939 = (int)*(((s1_ptr)_2)->base + 1);
    _4940 = e_match_from(_4939, _text_in_8876, 1);
    _4939 = NOVALUE;
    if (_4940 != 0) {
        goto L14; // [383] 401
    }
    _2 = (int)SEQ_PTR(_quote_pair_8877);
    _4942 = (int)*(((s1_ptr)_2)->base + 2);
    _4943 = e_match_from(_4942, _text_in_8876, 1);
    _4942 = NOVALUE;
    if (_4943 == 0)
    {
        _4943 = NOVALUE;
        goto L15; // [397] 473
    }
    else{
        _4943 = NOVALUE;
    }
L14: 

    /** 				if match(esc & quote_pair[1], text_in) then*/
    _2 = (int)SEQ_PTR(_quote_pair_8877);
    _4944 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_esc_8879) && IS_ATOM(_4944)) {
    }
    else if (IS_ATOM(_esc_8879) && IS_SEQUENCE(_4944)) {
        Prepend(&_4945, _4944, _esc_8879);
    }
    else {
        Concat((object_ptr)&_4945, _esc_8879, _4944);
    }
    _4944 = NOVALUE;
    _4946 = e_match_from(_4945, _text_in_8876, 1);
    DeRefDS(_4945);
    _4945 = NOVALUE;
    if (_4946 == 0)
    {
        _4946 = NOVALUE;
        goto L16; // [416] 449
    }
    else{
        _4946 = NOVALUE;
    }

    /** 					text_in = search:match_replace(esc & quote_pair[1], text_in, esc & esc & quote_pair[1])*/
    _2 = (int)SEQ_PTR(_quote_pair_8877);
    _4947 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_esc_8879) && IS_ATOM(_4947)) {
    }
    else if (IS_ATOM(_esc_8879) && IS_SEQUENCE(_4947)) {
        Prepend(&_4948, _4947, _esc_8879);
    }
    else {
        Concat((object_ptr)&_4948, _esc_8879, _4947);
    }
    _4947 = NOVALUE;
    _2 = (int)SEQ_PTR(_quote_pair_8877);
    _4949 = (int)*(((s1_ptr)_2)->base + 1);
    {
        int concat_list[3];

        concat_list[0] = _4949;
        concat_list[1] = _esc_8879;
        concat_list[2] = _esc_8879;
        Concat_N((object_ptr)&_4950, concat_list, 3);
    }
    _4949 = NOVALUE;
    RefDS(_text_in_8876);
    _0 = _text_in_8876;
    _text_in_8876 = _16match_replace(_4948, _text_in_8876, _4950, 0);
    DeRefDS(_0);
    _4948 = NOVALUE;
    _4950 = NOVALUE;
L16: 

    /** 				text_in = match_replace(quote_pair[1], text_in, esc & quote_pair[1])*/
    _2 = (int)SEQ_PTR(_quote_pair_8877);
    _4952 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_quote_pair_8877);
    _4953 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_esc_8879) && IS_ATOM(_4953)) {
    }
    else if (IS_ATOM(_esc_8879) && IS_SEQUENCE(_4953)) {
        Prepend(&_4954, _4953, _esc_8879);
    }
    else {
        Concat((object_ptr)&_4954, _esc_8879, _4953);
    }
    _4953 = NOVALUE;
    Ref(_4952);
    RefDS(_text_in_8876);
    _0 = _text_in_8876;
    _text_in_8876 = _16match_replace(_4952, _text_in_8876, _4954, 0);
    DeRefDS(_0);
    _4952 = NOVALUE;
    _4954 = NOVALUE;
L15: 

    /** 			if match(quote_pair[2], text_in) then*/
    _2 = (int)SEQ_PTR(_quote_pair_8877);
    _4956 = (int)*(((s1_ptr)_2)->base + 2);
    _4957 = e_match_from(_4956, _text_in_8876, 1);
    _4956 = NOVALUE;
    if (_4957 == 0)
    {
        _4957 = NOVALUE;
        goto L17; // [484] 559
    }
    else{
        _4957 = NOVALUE;
    }

    /** 				if match(esc & quote_pair[2], text_in) then*/
    _2 = (int)SEQ_PTR(_quote_pair_8877);
    _4958 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_esc_8879) && IS_ATOM(_4958)) {
    }
    else if (IS_ATOM(_esc_8879) && IS_SEQUENCE(_4958)) {
        Prepend(&_4959, _4958, _esc_8879);
    }
    else {
        Concat((object_ptr)&_4959, _esc_8879, _4958);
    }
    _4958 = NOVALUE;
    _4960 = e_match_from(_4959, _text_in_8876, 1);
    DeRefDS(_4959);
    _4959 = NOVALUE;
    if (_4960 == 0)
    {
        _4960 = NOVALUE;
        goto L18; // [502] 535
    }
    else{
        _4960 = NOVALUE;
    }

    /** 					text_in = search:match_replace(esc & quote_pair[2], text_in, esc & esc & quote_pair[2])*/
    _2 = (int)SEQ_PTR(_quote_pair_8877);
    _4961 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_esc_8879) && IS_ATOM(_4961)) {
    }
    else if (IS_ATOM(_esc_8879) && IS_SEQUENCE(_4961)) {
        Prepend(&_4962, _4961, _esc_8879);
    }
    else {
        Concat((object_ptr)&_4962, _esc_8879, _4961);
    }
    _4961 = NOVALUE;
    _2 = (int)SEQ_PTR(_quote_pair_8877);
    _4963 = (int)*(((s1_ptr)_2)->base + 2);
    {
        int concat_list[3];

        concat_list[0] = _4963;
        concat_list[1] = _esc_8879;
        concat_list[2] = _esc_8879;
        Concat_N((object_ptr)&_4964, concat_list, 3);
    }
    _4963 = NOVALUE;
    RefDS(_text_in_8876);
    _0 = _text_in_8876;
    _text_in_8876 = _16match_replace(_4962, _text_in_8876, _4964, 0);
    DeRefDS(_0);
    _4962 = NOVALUE;
    _4964 = NOVALUE;
L18: 

    /** 				text_in = search:match_replace(quote_pair[2], text_in, esc & quote_pair[2])*/
    _2 = (int)SEQ_PTR(_quote_pair_8877);
    _4966 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_quote_pair_8877);
    _4967 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_esc_8879) && IS_ATOM(_4967)) {
    }
    else if (IS_ATOM(_esc_8879) && IS_SEQUENCE(_4967)) {
        Prepend(&_4968, _4967, _esc_8879);
    }
    else {
        Concat((object_ptr)&_4968, _esc_8879, _4967);
    }
    _4967 = NOVALUE;
    Ref(_4966);
    RefDS(_text_in_8876);
    _0 = _text_in_8876;
    _text_in_8876 = _16match_replace(_4966, _text_in_8876, _4968, 0);
    DeRefDS(_0);
    _4966 = NOVALUE;
    _4968 = NOVALUE;
L17: 
L12: 
LE: 

    /** 	return quote_pair[1] & text_in & quote_pair[2]*/
    _2 = (int)SEQ_PTR(_quote_pair_8877);
    _4970 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_quote_pair_8877);
    _4971 = (int)*(((s1_ptr)_2)->base + 2);
    {
        int concat_list[3];

        concat_list[0] = _4971;
        concat_list[1] = _text_in_8876;
        concat_list[2] = _4970;
        Concat_N((object_ptr)&_4972, concat_list, 3);
    }
    _4971 = NOVALUE;
    _4970 = NOVALUE;
    DeRefDS(_text_in_8876);
    DeRef(_quote_pair_8877);
    DeRef(_sp_8881);
    return _4972;
    ;
}


int _14format(int _format_pattern_9097, int _arg_list_9098)
{
    int _result_9099 = NOVALUE;
    int _in_token_9100 = NOVALUE;
    int _tch_9101 = NOVALUE;
    int _i_9102 = NOVALUE;
    int _tend_9103 = NOVALUE;
    int _cap_9104 = NOVALUE;
    int _align_9105 = NOVALUE;
    int _psign_9106 = NOVALUE;
    int _msign_9107 = NOVALUE;
    int _zfill_9108 = NOVALUE;
    int _bwz_9109 = NOVALUE;
    int _spacer_9110 = NOVALUE;
    int _alt_9111 = NOVALUE;
    int _width_9112 = NOVALUE;
    int _decs_9113 = NOVALUE;
    int _pos_9114 = NOVALUE;
    int _argn_9115 = NOVALUE;
    int _argl_9116 = NOVALUE;
    int _trimming_9117 = NOVALUE;
    int _hexout_9118 = NOVALUE;
    int _binout_9119 = NOVALUE;
    int _tsep_9120 = NOVALUE;
    int _istext_9121 = NOVALUE;
    int _prevargv_9122 = NOVALUE;
    int _currargv_9123 = NOVALUE;
    int _idname_9124 = NOVALUE;
    int _envsym_9125 = NOVALUE;
    int _envvar_9126 = NOVALUE;
    int _ep_9127 = NOVALUE;
    int _sp_9200 = NOVALUE;
    int _sp_9236 = NOVALUE;
    int _argtext_9283 = NOVALUE;
    int _tempv_9506 = NOVALUE;
    int _pretty_sprint_inlined_pretty_sprint_at_2427_9561 = NOVALUE;
    int _options_inlined_pretty_sprint_at_2424_9560 = NOVALUE;
    int _pretty_sprint_inlined_pretty_sprint_at_2483_9568 = NOVALUE;
    int _options_inlined_pretty_sprint_at_2480_9567 = NOVALUE;
    int _x_inlined_pretty_sprint_at_2477_9566 = NOVALUE;
    int _msg_inlined_crash_at_2631_9590 = NOVALUE;
    int _dpos_9633 = NOVALUE;
    int _dist_9634 = NOVALUE;
    int _bracketed_9635 = NOVALUE;
    int _5464 = NOVALUE;
    int _5463 = NOVALUE;
    int _5462 = NOVALUE;
    int _5460 = NOVALUE;
    int _5459 = NOVALUE;
    int _5458 = NOVALUE;
    int _5455 = NOVALUE;
    int _5454 = NOVALUE;
    int _5451 = NOVALUE;
    int _5449 = NOVALUE;
    int _5446 = NOVALUE;
    int _5445 = NOVALUE;
    int _5444 = NOVALUE;
    int _5441 = NOVALUE;
    int _5438 = NOVALUE;
    int _5437 = NOVALUE;
    int _5436 = NOVALUE;
    int _5435 = NOVALUE;
    int _5432 = NOVALUE;
    int _5431 = NOVALUE;
    int _5430 = NOVALUE;
    int _5427 = NOVALUE;
    int _5425 = NOVALUE;
    int _5422 = NOVALUE;
    int _5421 = NOVALUE;
    int _5420 = NOVALUE;
    int _5419 = NOVALUE;
    int _5416 = NOVALUE;
    int _5411 = NOVALUE;
    int _5410 = NOVALUE;
    int _5409 = NOVALUE;
    int _5408 = NOVALUE;
    int _5402 = NOVALUE;
    int _5398 = NOVALUE;
    int _5397 = NOVALUE;
    int _5395 = NOVALUE;
    int _5393 = NOVALUE;
    int _5392 = NOVALUE;
    int _5391 = NOVALUE;
    int _5390 = NOVALUE;
    int _5389 = NOVALUE;
    int _5386 = NOVALUE;
    int _5383 = NOVALUE;
    int _5382 = NOVALUE;
    int _5379 = NOVALUE;
    int _5378 = NOVALUE;
    int _5377 = NOVALUE;
    int _5374 = NOVALUE;
    int _5372 = NOVALUE;
    int _5367 = NOVALUE;
    int _5366 = NOVALUE;
    int _5358 = NOVALUE;
    int _5354 = NOVALUE;
    int _5352 = NOVALUE;
    int _5351 = NOVALUE;
    int _5350 = NOVALUE;
    int _5347 = NOVALUE;
    int _5345 = NOVALUE;
    int _5344 = NOVALUE;
    int _5343 = NOVALUE;
    int _5341 = NOVALUE;
    int _5340 = NOVALUE;
    int _5339 = NOVALUE;
    int _5338 = NOVALUE;
    int _5335 = NOVALUE;
    int _5334 = NOVALUE;
    int _5333 = NOVALUE;
    int _5331 = NOVALUE;
    int _5330 = NOVALUE;
    int _5329 = NOVALUE;
    int _5328 = NOVALUE;
    int _5326 = NOVALUE;
    int _5324 = NOVALUE;
    int _5322 = NOVALUE;
    int _5320 = NOVALUE;
    int _5318 = NOVALUE;
    int _5316 = NOVALUE;
    int _5315 = NOVALUE;
    int _5314 = NOVALUE;
    int _5313 = NOVALUE;
    int _5312 = NOVALUE;
    int _5311 = NOVALUE;
    int _5309 = NOVALUE;
    int _5308 = NOVALUE;
    int _5306 = NOVALUE;
    int _5305 = NOVALUE;
    int _5303 = NOVALUE;
    int _5301 = NOVALUE;
    int _5300 = NOVALUE;
    int _5297 = NOVALUE;
    int _5295 = NOVALUE;
    int _5291 = NOVALUE;
    int _5289 = NOVALUE;
    int _5288 = NOVALUE;
    int _5287 = NOVALUE;
    int _5285 = NOVALUE;
    int _5284 = NOVALUE;
    int _5283 = NOVALUE;
    int _5282 = NOVALUE;
    int _5281 = NOVALUE;
    int _5279 = NOVALUE;
    int _5277 = NOVALUE;
    int _5276 = NOVALUE;
    int _5275 = NOVALUE;
    int _5274 = NOVALUE;
    int _5270 = NOVALUE;
    int _5267 = NOVALUE;
    int _5266 = NOVALUE;
    int _5263 = NOVALUE;
    int _5262 = NOVALUE;
    int _5261 = NOVALUE;
    int _5259 = NOVALUE;
    int _5258 = NOVALUE;
    int _5257 = NOVALUE;
    int _5256 = NOVALUE;
    int _5254 = NOVALUE;
    int _5252 = NOVALUE;
    int _5251 = NOVALUE;
    int _5250 = NOVALUE;
    int _5249 = NOVALUE;
    int _5248 = NOVALUE;
    int _5247 = NOVALUE;
    int _5245 = NOVALUE;
    int _5244 = NOVALUE;
    int _5243 = NOVALUE;
    int _5241 = NOVALUE;
    int _5240 = NOVALUE;
    int _5239 = NOVALUE;
    int _5238 = NOVALUE;
    int _5236 = NOVALUE;
    int _5233 = NOVALUE;
    int _5232 = NOVALUE;
    int _5230 = NOVALUE;
    int _5229 = NOVALUE;
    int _5227 = NOVALUE;
    int _5224 = NOVALUE;
    int _5223 = NOVALUE;
    int _5220 = NOVALUE;
    int _5218 = NOVALUE;
    int _5214 = NOVALUE;
    int _5212 = NOVALUE;
    int _5211 = NOVALUE;
    int _5210 = NOVALUE;
    int _5208 = NOVALUE;
    int _5206 = NOVALUE;
    int _5205 = NOVALUE;
    int _5204 = NOVALUE;
    int _5203 = NOVALUE;
    int _5202 = NOVALUE;
    int _5200 = NOVALUE;
    int _5198 = NOVALUE;
    int _5197 = NOVALUE;
    int _5196 = NOVALUE;
    int _5195 = NOVALUE;
    int _5193 = NOVALUE;
    int _5190 = NOVALUE;
    int _5188 = NOVALUE;
    int _5187 = NOVALUE;
    int _5185 = NOVALUE;
    int _5184 = NOVALUE;
    int _5183 = NOVALUE;
    int _5180 = NOVALUE;
    int _5179 = NOVALUE;
    int _5178 = NOVALUE;
    int _5177 = NOVALUE;
    int _5175 = NOVALUE;
    int _5174 = NOVALUE;
    int _5173 = NOVALUE;
    int _5172 = NOVALUE;
    int _5171 = NOVALUE;
    int _5168 = NOVALUE;
    int _5167 = NOVALUE;
    int _5166 = NOVALUE;
    int _5165 = NOVALUE;
    int _5163 = NOVALUE;
    int _5162 = NOVALUE;
    int _5161 = NOVALUE;
    int _5159 = NOVALUE;
    int _5158 = NOVALUE;
    int _5157 = NOVALUE;
    int _5155 = NOVALUE;
    int _5148 = NOVALUE;
    int _5146 = NOVALUE;
    int _5145 = NOVALUE;
    int _5138 = NOVALUE;
    int _5135 = NOVALUE;
    int _5131 = NOVALUE;
    int _5129 = NOVALUE;
    int _5128 = NOVALUE;
    int _5125 = NOVALUE;
    int _5123 = NOVALUE;
    int _5121 = NOVALUE;
    int _5118 = NOVALUE;
    int _5116 = NOVALUE;
    int _5115 = NOVALUE;
    int _5114 = NOVALUE;
    int _5113 = NOVALUE;
    int _5112 = NOVALUE;
    int _5109 = NOVALUE;
    int _5106 = NOVALUE;
    int _5105 = NOVALUE;
    int _5104 = NOVALUE;
    int _5101 = NOVALUE;
    int _5099 = NOVALUE;
    int _5097 = NOVALUE;
    int _5094 = NOVALUE;
    int _5093 = NOVALUE;
    int _5086 = NOVALUE;
    int _5083 = NOVALUE;
    int _5082 = NOVALUE;
    int _5074 = NOVALUE;
    int _5069 = NOVALUE;
    int _5066 = NOVALUE;
    int _5056 = NOVALUE;
    int _5054 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(arg_list) then*/
    _5054 = IS_ATOM(_arg_list_9098);
    if (_5054 == 0)
    {
        _5054 = NOVALUE;
        goto L1; // [8] 18
    }
    else{
        _5054 = NOVALUE;
    }

    /** 		arg_list = {arg_list}*/
    _0 = _arg_list_9098;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_arg_list_9098);
    *((int *)(_2+4)) = _arg_list_9098;
    _arg_list_9098 = MAKE_SEQ(_1);
    DeRef(_0);
L1: 

    /** 	result = ""*/
    RefDS(_5);
    DeRef(_result_9099);
    _result_9099 = _5;

    /** 	in_token = 0*/
    _in_token_9100 = 0;

    /** 	i = 0*/
    _i_9102 = 0;

    /** 	tend = 0*/
    _tend_9103 = 0;

    /** 	argl = 0*/
    _argl_9116 = 0;

    /** 	spacer = 0*/
    _spacer_9110 = 0;

    /** 	prevargv = 0*/
    DeRef(_prevargv_9122);
    _prevargv_9122 = 0;

    /**     while i < length(format_pattern) do*/
L2: 
    if (IS_SEQUENCE(_format_pattern_9097)){
            _5056 = SEQ_PTR(_format_pattern_9097)->length;
    }
    else {
        _5056 = 1;
    }
    if (_i_9102 >= _5056)
    goto L3; // [63] 3380

    /**     	i += 1*/
    _i_9102 = _i_9102 + 1;

    /**     	tch = format_pattern[i]*/
    _2 = (int)SEQ_PTR(_format_pattern_9097);
    _tch_9101 = (int)*(((s1_ptr)_2)->base + _i_9102);
    if (!IS_ATOM_INT(_tch_9101))
    _tch_9101 = (long)DBL_PTR(_tch_9101)->dbl;

    /**     	if not in_token then*/
    if (_in_token_9100 != 0)
    goto L4; // [81] 210

    /**     		if tch = '[' then*/
    if (_tch_9101 != 91)
    goto L5; // [86] 200

    /**     			in_token = 1*/
    _in_token_9100 = 1;

    /**     			tend = 0*/
    _tend_9103 = 0;

    /** 				cap = 0*/
    _cap_9104 = 0;

    /** 				align = 0*/
    _align_9105 = 0;

    /** 				psign = 0*/
    _psign_9106 = 0;

    /** 				msign = 0*/
    _msign_9107 = 0;

    /** 				zfill = 0*/
    _zfill_9108 = 0;

    /** 				bwz = 0*/
    _bwz_9109 = 0;

    /** 				spacer = 0*/
    _spacer_9110 = 0;

    /** 				alt = 0*/
    _alt_9111 = 0;

    /**     			width = 0*/
    _width_9112 = 0;

    /**     			decs = -1*/
    _decs_9113 = -1;

    /**     			argn = 0*/
    _argn_9115 = 0;

    /**     			hexout = 0*/
    _hexout_9118 = 0;

    /**     			binout = 0*/
    _binout_9119 = 0;

    /**     			trimming = 0*/
    _trimming_9117 = 0;

    /**     			tsep = 0*/
    _tsep_9120 = 0;

    /**     			istext = 0*/
    _istext_9121 = 0;

    /**     			idname = ""*/
    RefDS(_5);
    DeRef(_idname_9124);
    _idname_9124 = _5;

    /**     			envvar = ""*/
    RefDS(_5);
    DeRefi(_envvar_9126);
    _envvar_9126 = _5;

    /**     			envsym = ""*/
    RefDS(_5);
    DeRef(_envsym_9125);
    _envsym_9125 = _5;
    goto L2; // [197] 60
L5: 

    /**     			result &= tch*/
    Append(&_result_9099, _result_9099, _tch_9101);
    goto L2; // [207] 60
L4: 

    /** 			switch tch do*/
    _0 = _tch_9101;
    switch ( _0 ){ 

        /**     			case ']' then*/
        case 93:

        /**     				in_token = 0*/
        _in_token_9100 = 0;

        /**     				tend = i*/
        _tend_9103 = _i_9102;
        goto L6; // [231] 1072

        /**     			case '[' then*/
        case 91:

        /** 	    			result &= tch*/
        Append(&_result_9099, _result_9099, _tch_9101);

        /** 	    			while i < length(format_pattern) do*/
L7: 
        if (IS_SEQUENCE(_format_pattern_9097)){
                _5066 = SEQ_PTR(_format_pattern_9097)->length;
        }
        else {
            _5066 = 1;
        }
        if (_i_9102 >= _5066)
        goto L6; // [251] 1072

        /** 	    				i += 1*/
        _i_9102 = _i_9102 + 1;

        /** 	    				if format_pattern[i] = ']' then*/
        _2 = (int)SEQ_PTR(_format_pattern_9097);
        _5069 = (int)*(((s1_ptr)_2)->base + _i_9102);
        if (binary_op_a(NOTEQ, _5069, 93)){
            _5069 = NOVALUE;
            goto L7; // [267] 248
        }
        _5069 = NOVALUE;

        /** 	    					in_token = 0*/
        _in_token_9100 = 0;

        /** 	    					tend = 0*/
        _tend_9103 = 0;

        /** 	    					exit*/
        goto L6; // [283] 1072

        /** 	    			end while*/
        goto L7; // [288] 248
        goto L6; // [291] 1072

        /** 	    		case 'w', 'u', 'l' then*/
        case 119:
        case 117:
        case 108:

        /** 	    			cap = tch*/
        _cap_9104 = _tch_9101;
        goto L6; // [306] 1072

        /** 	    		case 'b' then*/
        case 98:

        /** 	    			bwz = 1*/
        _bwz_9109 = 1;
        goto L6; // [317] 1072

        /** 	    		case 's' then*/
        case 115:

        /** 	    			spacer = 1*/
        _spacer_9110 = 1;
        goto L6; // [328] 1072

        /** 	    		case 't' then*/
        case 116:

        /** 	    			trimming = 1*/
        _trimming_9117 = 1;
        goto L6; // [339] 1072

        /** 	    		case 'z' then*/
        case 122:

        /** 	    			zfill = 1*/
        _zfill_9108 = 1;
        goto L6; // [350] 1072

        /** 	    		case 'X' then*/
        case 88:

        /** 	    			hexout = 1*/
        _hexout_9118 = 1;
        goto L6; // [361] 1072

        /** 	    		case 'B' then*/
        case 66:

        /** 	    			binout = 1*/
        _binout_9119 = 1;
        goto L6; // [372] 1072

        /** 	    		case 'c', '<', '>' then*/
        case 99:
        case 60:
        case 62:

        /** 	    			align = tch*/
        _align_9105 = _tch_9101;
        goto L6; // [387] 1072

        /** 	    		case '+' then*/
        case 43:

        /** 	    			psign = 1*/
        _psign_9106 = 1;
        goto L6; // [398] 1072

        /** 	    		case '(' then*/
        case 40:

        /** 	    			msign = 1*/
        _msign_9107 = 1;
        goto L6; // [409] 1072

        /** 	    		case '?' then*/
        case 63:

        /** 	    			alt = 1*/
        _alt_9111 = 1;
        goto L6; // [420] 1072

        /** 	    		case 'T' then*/
        case 84:

        /** 	    			istext = 1*/
        _istext_9121 = 1;
        goto L6; // [431] 1072

        /** 	    		case ':' then*/
        case 58:

        /** 	    			while i < length(format_pattern) do*/
L8: 
        if (IS_SEQUENCE(_format_pattern_9097)){
                _5074 = SEQ_PTR(_format_pattern_9097)->length;
        }
        else {
            _5074 = 1;
        }
        if (_i_9102 >= _5074)
        goto L6; // [445] 1072

        /** 	    				i += 1*/
        _i_9102 = _i_9102 + 1;

        /** 	    				tch = format_pattern[i]*/
        _2 = (int)SEQ_PTR(_format_pattern_9097);
        _tch_9101 = (int)*(((s1_ptr)_2)->base + _i_9102);
        if (!IS_ATOM_INT(_tch_9101))
        _tch_9101 = (long)DBL_PTR(_tch_9101)->dbl;

        /** 	    				pos = find(tch, "0123456789")*/
        _pos_9114 = find_from(_tch_9101, _5078, 1);

        /** 	    				if pos = 0 then*/
        if (_pos_9114 != 0)
        goto L9; // [470] 485

        /** 	    					i -= 1*/
        _i_9102 = _i_9102 - 1;

        /** 	    					exit*/
        goto L6; // [482] 1072
L9: 

        /** 	    				width = width * 10 + pos - 1*/
        if (_width_9112 == (short)_width_9112)
        _5082 = _width_9112 * 10;
        else
        _5082 = NewDouble(_width_9112 * (double)10);
        if (IS_ATOM_INT(_5082)) {
            _5083 = _5082 + _pos_9114;
            if ((long)((unsigned long)_5083 + (unsigned long)HIGH_BITS) >= 0) 
            _5083 = NewDouble((double)_5083);
        }
        else {
            _5083 = NewDouble(DBL_PTR(_5082)->dbl + (double)_pos_9114);
        }
        DeRef(_5082);
        _5082 = NOVALUE;
        if (IS_ATOM_INT(_5083)) {
            _width_9112 = _5083 - 1;
        }
        else {
            _width_9112 = NewDouble(DBL_PTR(_5083)->dbl - (double)1);
        }
        DeRef(_5083);
        _5083 = NOVALUE;
        if (!IS_ATOM_INT(_width_9112)) {
            _1 = (long)(DBL_PTR(_width_9112)->dbl);
            DeRefDS(_width_9112);
            _width_9112 = _1;
        }

        /** 	    				if width = 0 then*/
        if (_width_9112 != 0)
        goto L8; // [505] 442

        /** 	    					zfill = '0'*/
        _zfill_9108 = 48;

        /** 	    			end while*/
        goto L8; // [517] 442
        goto L6; // [520] 1072

        /** 	    		case '.' then*/
        case 46:

        /** 	    			decs = 0*/
        _decs_9113 = 0;

        /** 	    			while i < length(format_pattern) do*/
LA: 
        if (IS_SEQUENCE(_format_pattern_9097)){
                _5086 = SEQ_PTR(_format_pattern_9097)->length;
        }
        else {
            _5086 = 1;
        }
        if (_i_9102 >= _5086)
        goto L6; // [539] 1072

        /** 	    				i += 1*/
        _i_9102 = _i_9102 + 1;

        /** 	    				tch = format_pattern[i]*/
        _2 = (int)SEQ_PTR(_format_pattern_9097);
        _tch_9101 = (int)*(((s1_ptr)_2)->base + _i_9102);
        if (!IS_ATOM_INT(_tch_9101))
        _tch_9101 = (long)DBL_PTR(_tch_9101)->dbl;

        /** 	    				pos = find(tch, "0123456789")*/
        _pos_9114 = find_from(_tch_9101, _5078, 1);

        /** 	    				if pos = 0 then*/
        if (_pos_9114 != 0)
        goto LB; // [564] 579

        /** 	    					i -= 1*/
        _i_9102 = _i_9102 - 1;

        /** 	    					exit*/
        goto L6; // [576] 1072
LB: 

        /** 	    				decs = decs * 10 + pos - 1*/
        if (_decs_9113 == (short)_decs_9113)
        _5093 = _decs_9113 * 10;
        else
        _5093 = NewDouble(_decs_9113 * (double)10);
        if (IS_ATOM_INT(_5093)) {
            _5094 = _5093 + _pos_9114;
            if ((long)((unsigned long)_5094 + (unsigned long)HIGH_BITS) >= 0) 
            _5094 = NewDouble((double)_5094);
        }
        else {
            _5094 = NewDouble(DBL_PTR(_5093)->dbl + (double)_pos_9114);
        }
        DeRef(_5093);
        _5093 = NOVALUE;
        if (IS_ATOM_INT(_5094)) {
            _decs_9113 = _5094 - 1;
        }
        else {
            _decs_9113 = NewDouble(DBL_PTR(_5094)->dbl - (double)1);
        }
        DeRef(_5094);
        _5094 = NOVALUE;
        if (!IS_ATOM_INT(_decs_9113)) {
            _1 = (long)(DBL_PTR(_decs_9113)->dbl);
            DeRefDS(_decs_9113);
            _decs_9113 = _1;
        }

        /** 	    			end while*/
        goto LA; // [597] 536
        goto L6; // [600] 1072

        /** 	    		case '{' then*/
        case 123:

        /** 	    			integer sp*/

        /** 	    			sp = i + 1*/
        _sp_9200 = _i_9102 + 1;

        /** 	    			i = sp*/
        _i_9102 = _sp_9200;

        /** 	    			while i < length(format_pattern) do*/
LC: 
        if (IS_SEQUENCE(_format_pattern_9097)){
                _5097 = SEQ_PTR(_format_pattern_9097)->length;
        }
        else {
            _5097 = 1;
        }
        if (_i_9102 >= _5097)
        goto LD; // [627] 672

        /** 	    				if format_pattern[i] = '}' then*/
        _2 = (int)SEQ_PTR(_format_pattern_9097);
        _5099 = (int)*(((s1_ptr)_2)->base + _i_9102);
        if (binary_op_a(NOTEQ, _5099, 125)){
            _5099 = NOVALUE;
            goto LE; // [637] 646
        }
        _5099 = NOVALUE;

        /** 	    					exit*/
        goto LD; // [643] 672
LE: 

        /** 	    				if format_pattern[i] = ']' then*/
        _2 = (int)SEQ_PTR(_format_pattern_9097);
        _5101 = (int)*(((s1_ptr)_2)->base + _i_9102);
        if (binary_op_a(NOTEQ, _5101, 93)){
            _5101 = NOVALUE;
            goto LF; // [652] 661
        }
        _5101 = NOVALUE;

        /** 	    					exit*/
        goto LD; // [658] 672
LF: 

        /** 	    				i += 1*/
        _i_9102 = _i_9102 + 1;

        /** 	    			end while*/
        goto LC; // [669] 624
LD: 

        /** 	    			idname = trim(format_pattern[sp .. i-1]) & '='*/
        _5104 = _i_9102 - 1;
        rhs_slice_target = (object_ptr)&_5105;
        RHS_Slice(_format_pattern_9097, _sp_9200, _5104);
        RefDS(_3890);
        _5106 = _14trim(_5105, _3890, 0);
        _5105 = NOVALUE;
        if (IS_SEQUENCE(_5106) && IS_ATOM(61)) {
            Append(&_idname_9124, _5106, 61);
        }
        else if (IS_ATOM(_5106) && IS_SEQUENCE(61)) {
        }
        else {
            Concat((object_ptr)&_idname_9124, _5106, 61);
            DeRef(_5106);
            _5106 = NOVALUE;
        }
        DeRef(_5106);
        _5106 = NOVALUE;

        /**     				if format_pattern[i] = ']' then*/
        _2 = (int)SEQ_PTR(_format_pattern_9097);
        _5109 = (int)*(((s1_ptr)_2)->base + _i_9102);
        if (binary_op_a(NOTEQ, _5109, 93)){
            _5109 = NOVALUE;
            goto L10; // [699] 710
        }
        _5109 = NOVALUE;

        /**     					i -= 1*/
        _i_9102 = _i_9102 - 1;
L10: 

        /**     				for j = 1 to length(arg_list) do*/
        if (IS_SEQUENCE(_arg_list_9098)){
                _5112 = SEQ_PTR(_arg_list_9098)->length;
        }
        else {
            _5112 = 1;
        }
        {
            int _j_9222;
            _j_9222 = 1;
L11: 
            if (_j_9222 > _5112){
                goto L12; // [715] 797
            }

            /**     					if sequence(arg_list[j]) then*/
            _2 = (int)SEQ_PTR(_arg_list_9098);
            _5113 = (int)*(((s1_ptr)_2)->base + _j_9222);
            _5114 = IS_SEQUENCE(_5113);
            _5113 = NOVALUE;
            if (_5114 == 0)
            {
                _5114 = NOVALUE;
                goto L13; // [731] 768
            }
            else{
                _5114 = NOVALUE;
            }

            /**     						if search:begins(idname, arg_list[j]) then*/
            _2 = (int)SEQ_PTR(_arg_list_9098);
            _5115 = (int)*(((s1_ptr)_2)->base + _j_9222);
            RefDS(_idname_9124);
            Ref(_5115);
            _5116 = _16begins(_idname_9124, _5115);
            _5115 = NOVALUE;
            if (_5116 == 0) {
                DeRef(_5116);
                _5116 = NOVALUE;
                goto L14; // [745] 767
            }
            else {
                if (!IS_ATOM_INT(_5116) && DBL_PTR(_5116)->dbl == 0.0){
                    DeRef(_5116);
                    _5116 = NOVALUE;
                    goto L14; // [745] 767
                }
                DeRef(_5116);
                _5116 = NOVALUE;
            }
            DeRef(_5116);
            _5116 = NOVALUE;

            /**     							if argn = 0 then*/
            if (_argn_9115 != 0)
            goto L15; // [752] 766

            /**     								argn = j*/
            _argn_9115 = _j_9222;

            /**     								exit*/
            goto L12; // [763] 797
L15: 
L14: 
L13: 

            /**     					if j = length(arg_list) then*/
            if (IS_SEQUENCE(_arg_list_9098)){
                    _5118 = SEQ_PTR(_arg_list_9098)->length;
            }
            else {
                _5118 = 1;
            }
            if (_j_9222 != _5118)
            goto L16; // [773] 790

            /**     						idname = ""*/
            RefDS(_5);
            DeRef(_idname_9124);
            _idname_9124 = _5;

            /**     						argn = -1*/
            _argn_9115 = -1;
L16: 

            /**     				end for*/
            _j_9222 = _j_9222 + 1;
            goto L11; // [792] 722
L12: 
            ;
        }
        goto L6; // [799] 1072

        /** 	    		case '%' then*/
        case 37:

        /** 	    			integer sp*/

        /** 	    			sp = i + 1*/
        _sp_9236 = _i_9102 + 1;

        /** 	    			i = sp*/
        _i_9102 = _sp_9236;

        /** 	    			while i < length(format_pattern) do*/
L17: 
        if (IS_SEQUENCE(_format_pattern_9097)){
                _5121 = SEQ_PTR(_format_pattern_9097)->length;
        }
        else {
            _5121 = 1;
        }
        if (_i_9102 >= _5121)
        goto L18; // [826] 871

        /** 	    				if format_pattern[i] = '%' then*/
        _2 = (int)SEQ_PTR(_format_pattern_9097);
        _5123 = (int)*(((s1_ptr)_2)->base + _i_9102);
        if (binary_op_a(NOTEQ, _5123, 37)){
            _5123 = NOVALUE;
            goto L19; // [836] 845
        }
        _5123 = NOVALUE;

        /** 	    					exit*/
        goto L18; // [842] 871
L19: 

        /** 	    				if format_pattern[i] = ']' then*/
        _2 = (int)SEQ_PTR(_format_pattern_9097);
        _5125 = (int)*(((s1_ptr)_2)->base + _i_9102);
        if (binary_op_a(NOTEQ, _5125, 93)){
            _5125 = NOVALUE;
            goto L1A; // [851] 860
        }
        _5125 = NOVALUE;

        /** 	    					exit*/
        goto L18; // [857] 871
L1A: 

        /** 	    				i += 1*/
        _i_9102 = _i_9102 + 1;

        /** 	    			end while*/
        goto L17; // [868] 823
L18: 

        /** 	    			envsym = trim(format_pattern[sp .. i-1])*/
        _5128 = _i_9102 - 1;
        rhs_slice_target = (object_ptr)&_5129;
        RHS_Slice(_format_pattern_9097, _sp_9236, _5128);
        RefDS(_3890);
        _0 = _envsym_9125;
        _envsym_9125 = _14trim(_5129, _3890, 0);
        DeRef(_0);
        _5129 = NOVALUE;

        /**     				if format_pattern[i] = ']' then*/
        _2 = (int)SEQ_PTR(_format_pattern_9097);
        _5131 = (int)*(((s1_ptr)_2)->base + _i_9102);
        if (binary_op_a(NOTEQ, _5131, 93)){
            _5131 = NOVALUE;
            goto L1B; // [894] 905
        }
        _5131 = NOVALUE;

        /**     					i -= 1*/
        _i_9102 = _i_9102 - 1;
L1B: 

        /**     				envvar = getenv(envsym)*/
        DeRefi(_envvar_9126);
        _envvar_9126 = EGetEnv(_envsym_9125);

        /**     				argn = -1*/
        _argn_9115 = -1;

        /**     				if atom(envvar) then*/
        _5135 = IS_ATOM(_envvar_9126);
        if (_5135 == 0)
        {
            _5135 = NOVALUE;
            goto L1C; // [920] 929
        }
        else{
            _5135 = NOVALUE;
        }

        /**     					envvar = ""*/
        RefDS(_5);
        DeRefi(_envvar_9126);
        _envvar_9126 = _5;
L1C: 
        goto L6; // [931] 1072

        /** 	    		case '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' then*/
        case 48:
        case 49:
        case 50:
        case 51:
        case 52:
        case 53:
        case 54:
        case 55:
        case 56:
        case 57:

        /** 	    			if argn = 0 then*/
        if (_argn_9115 != 0)
        goto L6; // [957] 1072

        /** 		    			i -= 1*/
        _i_9102 = _i_9102 - 1;

        /** 		    			while i < length(format_pattern) do*/
L1D: 
        if (IS_SEQUENCE(_format_pattern_9097)){
                _5138 = SEQ_PTR(_format_pattern_9097)->length;
        }
        else {
            _5138 = 1;
        }
        if (_i_9102 >= _5138)
        goto L6; // [975] 1072

        /** 		    				i += 1*/
        _i_9102 = _i_9102 + 1;

        /** 		    				tch = format_pattern[i]*/
        _2 = (int)SEQ_PTR(_format_pattern_9097);
        _tch_9101 = (int)*(((s1_ptr)_2)->base + _i_9102);
        if (!IS_ATOM_INT(_tch_9101))
        _tch_9101 = (long)DBL_PTR(_tch_9101)->dbl;

        /** 		    				pos = find(tch, "0123456789")*/
        _pos_9114 = find_from(_tch_9101, _5078, 1);

        /** 		    				if pos = 0 then*/
        if (_pos_9114 != 0)
        goto L1E; // [1000] 1015

        /** 		    					i -= 1*/
        _i_9102 = _i_9102 - 1;

        /** 		    					exit*/
        goto L6; // [1012] 1072
L1E: 

        /** 		    				argn = argn * 10 + pos - 1*/
        if (_argn_9115 == (short)_argn_9115)
        _5145 = _argn_9115 * 10;
        else
        _5145 = NewDouble(_argn_9115 * (double)10);
        if (IS_ATOM_INT(_5145)) {
            _5146 = _5145 + _pos_9114;
            if ((long)((unsigned long)_5146 + (unsigned long)HIGH_BITS) >= 0) 
            _5146 = NewDouble((double)_5146);
        }
        else {
            _5146 = NewDouble(DBL_PTR(_5145)->dbl + (double)_pos_9114);
        }
        DeRef(_5145);
        _5145 = NOVALUE;
        if (IS_ATOM_INT(_5146)) {
            _argn_9115 = _5146 - 1;
        }
        else {
            _argn_9115 = NewDouble(DBL_PTR(_5146)->dbl - (double)1);
        }
        DeRef(_5146);
        _5146 = NOVALUE;
        if (!IS_ATOM_INT(_argn_9115)) {
            _1 = (long)(DBL_PTR(_argn_9115)->dbl);
            DeRefDS(_argn_9115);
            _argn_9115 = _1;
        }

        /** 		    			end while*/
        goto L1D; // [1033] 972
        goto L6; // [1037] 1072

        /** 	    		case ',' then*/
        case 44:

        /** 	    			if i < length(format_pattern) then*/
        if (IS_SEQUENCE(_format_pattern_9097)){
                _5148 = SEQ_PTR(_format_pattern_9097)->length;
        }
        else {
            _5148 = 1;
        }
        if (_i_9102 >= _5148)
        goto L6; // [1048] 1072

        /** 	    				i +=1*/
        _i_9102 = _i_9102 + 1;

        /** 	    				tsep = format_pattern[i]*/
        _2 = (int)SEQ_PTR(_format_pattern_9097);
        _tsep_9120 = (int)*(((s1_ptr)_2)->base + _i_9102);
        if (!IS_ATOM_INT(_tsep_9120))
        _tsep_9120 = (long)DBL_PTR(_tsep_9120)->dbl;
        goto L6; // [1065] 1072

        /** 	    		case else*/
        default:
    ;}L6: 

    /**     		if tend > 0 then*/
    if (_tend_9103 <= 0)
    goto L1F; // [1074] 3372

    /**     			sequence argtext = ""*/
    RefDS(_5);
    DeRef(_argtext_9283);
    _argtext_9283 = _5;

    /**     			if argn = 0 then*/
    if (_argn_9115 != 0)
    goto L20; // [1089] 1100

    /**     				argn = argl + 1*/
    _argn_9115 = _argl_9116 + 1;
L20: 

    /**     			argl = argn*/
    _argl_9116 = _argn_9115;

    /**     			if argn < 1 or argn > length(arg_list) then*/
    _5155 = (_argn_9115 < 1);
    if (_5155 != 0) {
        goto L21; // [1111] 1127
    }
    if (IS_SEQUENCE(_arg_list_9098)){
            _5157 = SEQ_PTR(_arg_list_9098)->length;
    }
    else {
        _5157 = 1;
    }
    _5158 = (_argn_9115 > _5157);
    _5157 = NOVALUE;
    if (_5158 == 0)
    {
        DeRef(_5158);
        _5158 = NOVALUE;
        goto L22; // [1123] 1169
    }
    else{
        DeRef(_5158);
        _5158 = NOVALUE;
    }
L21: 

    /**     				if length(envvar) > 0 then*/
    if (IS_SEQUENCE(_envvar_9126)){
            _5159 = SEQ_PTR(_envvar_9126)->length;
    }
    else {
        _5159 = 1;
    }
    if (_5159 <= 0)
    goto L23; // [1134] 1153

    /**     					argtext = envvar*/
    Ref(_envvar_9126);
    DeRef(_argtext_9283);
    _argtext_9283 = _envvar_9126;

    /** 	    				currargv = envvar*/
    Ref(_envvar_9126);
    DeRef(_currargv_9123);
    _currargv_9123 = _envvar_9126;
    goto L24; // [1150] 2553
L23: 

    /**     					argtext = ""*/
    RefDS(_5);
    DeRef(_argtext_9283);
    _argtext_9283 = _5;

    /** 	    				currargv =""*/
    RefDS(_5);
    DeRef(_currargv_9123);
    _currargv_9123 = _5;
    goto L24; // [1166] 2553
L22: 

    /** 					if string(arg_list[argn]) then*/
    _2 = (int)SEQ_PTR(_arg_list_9098);
    _5161 = (int)*(((s1_ptr)_2)->base + _argn_9115);
    Ref(_5161);
    _5162 = _13string(_5161);
    _5161 = NOVALUE;
    if (_5162 == 0) {
        DeRef(_5162);
        _5162 = NOVALUE;
        goto L25; // [1179] 1229
    }
    else {
        if (!IS_ATOM_INT(_5162) && DBL_PTR(_5162)->dbl == 0.0){
            DeRef(_5162);
            _5162 = NOVALUE;
            goto L25; // [1179] 1229
        }
        DeRef(_5162);
        _5162 = NOVALUE;
    }
    DeRef(_5162);
    _5162 = NOVALUE;

    /** 						if length(idname) > 0 then*/
    if (IS_SEQUENCE(_idname_9124)){
            _5163 = SEQ_PTR(_idname_9124)->length;
    }
    else {
        _5163 = 1;
    }
    if (_5163 <= 0)
    goto L26; // [1189] 1217

    /** 							argtext = arg_list[argn][length(idname) + 1 .. $]*/
    _2 = (int)SEQ_PTR(_arg_list_9098);
    _5165 = (int)*(((s1_ptr)_2)->base + _argn_9115);
    if (IS_SEQUENCE(_idname_9124)){
            _5166 = SEQ_PTR(_idname_9124)->length;
    }
    else {
        _5166 = 1;
    }
    _5167 = _5166 + 1;
    _5166 = NOVALUE;
    if (IS_SEQUENCE(_5165)){
            _5168 = SEQ_PTR(_5165)->length;
    }
    else {
        _5168 = 1;
    }
    rhs_slice_target = (object_ptr)&_argtext_9283;
    RHS_Slice(_5165, _5167, _5168);
    _5165 = NOVALUE;
    goto L27; // [1214] 2546
L26: 

    /** 							argtext = arg_list[argn]*/
    DeRef(_argtext_9283);
    _2 = (int)SEQ_PTR(_arg_list_9098);
    _argtext_9283 = (int)*(((s1_ptr)_2)->base + _argn_9115);
    Ref(_argtext_9283);
    goto L27; // [1226] 2546
L25: 

    /** 					elsif integer(arg_list[argn]) then*/
    _2 = (int)SEQ_PTR(_arg_list_9098);
    _5171 = (int)*(((s1_ptr)_2)->base + _argn_9115);
    if (IS_ATOM_INT(_5171))
    _5172 = 1;
    else if (IS_ATOM_DBL(_5171))
    _5172 = IS_ATOM_INT(DoubleToInt(_5171));
    else
    _5172 = 0;
    _5171 = NOVALUE;
    if (_5172 == 0)
    {
        _5172 = NOVALUE;
        goto L28; // [1238] 1718
    }
    else{
        _5172 = NOVALUE;
    }

    /** 						if istext then*/
    if (_istext_9121 == 0)
    {
        goto L29; // [1245] 1269
    }
    else{
    }

    /** 							argtext = {and_bits(0xFFFF_FFFF, math:abs(arg_list[argn]))}*/
    _2 = (int)SEQ_PTR(_arg_list_9098);
    _5173 = (int)*(((s1_ptr)_2)->base + _argn_9115);
    Ref(_5173);
    _5174 = _20abs(_5173);
    _5173 = NOVALUE;
    _5175 = binary_op(AND_BITS, _1548, _5174);
    DeRef(_5174);
    _5174 = NOVALUE;
    _0 = _argtext_9283;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _5175;
    _argtext_9283 = MAKE_SEQ(_1);
    DeRef(_0);
    _5175 = NOVALUE;
    goto L27; // [1266] 2546
L29: 

    /** 						elsif bwz != 0 and arg_list[argn] = 0 then*/
    _5177 = (_bwz_9109 != 0);
    if (_5177 == 0) {
        goto L2A; // [1277] 1304
    }
    _2 = (int)SEQ_PTR(_arg_list_9098);
    _5179 = (int)*(((s1_ptr)_2)->base + _argn_9115);
    if (IS_ATOM_INT(_5179)) {
        _5180 = (_5179 == 0);
    }
    else {
        _5180 = binary_op(EQUALS, _5179, 0);
    }
    _5179 = NOVALUE;
    if (_5180 == 0) {
        DeRef(_5180);
        _5180 = NOVALUE;
        goto L2A; // [1290] 1304
    }
    else {
        if (!IS_ATOM_INT(_5180) && DBL_PTR(_5180)->dbl == 0.0){
            DeRef(_5180);
            _5180 = NOVALUE;
            goto L2A; // [1290] 1304
        }
        DeRef(_5180);
        _5180 = NOVALUE;
    }
    DeRef(_5180);
    _5180 = NOVALUE;

    /** 							argtext = repeat(' ', width)*/
    DeRef(_argtext_9283);
    _argtext_9283 = Repeat(32, _width_9112);
    goto L27; // [1301] 2546
L2A: 

    /** 						elsif binout = 1 then*/
    if (_binout_9119 != 1)
    goto L2B; // [1308] 1382

    /** 							argtext = stdseq:reverse( convert:int_to_bits(arg_list[argn], 32)) + '0'*/
    _2 = (int)SEQ_PTR(_arg_list_9098);
    _5183 = (int)*(((s1_ptr)_2)->base + _argn_9115);
    Ref(_5183);
    _5184 = _15int_to_bits(_5183, 32);
    _5183 = NOVALUE;
    _5185 = _23reverse(_5184, 1, 0);
    _5184 = NOVALUE;
    DeRef(_argtext_9283);
    if (IS_ATOM_INT(_5185)) {
        _argtext_9283 = _5185 + 48;
        if ((long)((unsigned long)_argtext_9283 + (unsigned long)HIGH_BITS) >= 0) 
        _argtext_9283 = NewDouble((double)_argtext_9283);
    }
    else {
        _argtext_9283 = binary_op(PLUS, _5185, 48);
    }
    DeRef(_5185);
    _5185 = NOVALUE;

    /** 							for ib = 1 to length(argtext) do*/
    if (IS_SEQUENCE(_argtext_9283)){
            _5187 = SEQ_PTR(_argtext_9283)->length;
    }
    else {
        _5187 = 1;
    }
    {
        int _ib_9332;
        _ib_9332 = 1;
L2C: 
        if (_ib_9332 > _5187){
            goto L2D; // [1340] 1379
        }

        /** 								if argtext[ib] = '1' then*/
        _2 = (int)SEQ_PTR(_argtext_9283);
        _5188 = (int)*(((s1_ptr)_2)->base + _ib_9332);
        if (binary_op_a(NOTEQ, _5188, 49)){
            _5188 = NOVALUE;
            goto L2E; // [1353] 1372
        }
        _5188 = NOVALUE;

        /** 									argtext = argtext[ib .. $]*/
        if (IS_SEQUENCE(_argtext_9283)){
                _5190 = SEQ_PTR(_argtext_9283)->length;
        }
        else {
            _5190 = 1;
        }
        rhs_slice_target = (object_ptr)&_argtext_9283;
        RHS_Slice(_argtext_9283, _ib_9332, _5190);

        /** 									exit*/
        goto L2D; // [1369] 1379
L2E: 

        /** 							end for*/
        _ib_9332 = _ib_9332 + 1;
        goto L2C; // [1374] 1347
L2D: 
        ;
    }
    goto L27; // [1379] 2546
L2B: 

    /** 						elsif hexout = 0 then*/
    if (_hexout_9118 != 0)
    goto L2F; // [1386] 1652

    /** 							argtext = sprintf("%d", arg_list[argn])*/
    _2 = (int)SEQ_PTR(_arg_list_9098);
    _5193 = (int)*(((s1_ptr)_2)->base + _argn_9115);
    DeRef(_argtext_9283);
    _argtext_9283 = EPrintf(-9999999, _954, _5193);
    _5193 = NOVALUE;

    /** 							if zfill != 0 and width > 0 then*/
    _5195 = (_zfill_9108 != 0);
    if (_5195 == 0) {
        goto L30; // [1408] 1505
    }
    _5197 = (_width_9112 > 0);
    if (_5197 == 0)
    {
        DeRef(_5197);
        _5197 = NOVALUE;
        goto L30; // [1419] 1505
    }
    else{
        DeRef(_5197);
        _5197 = NOVALUE;
    }

    /** 								if argtext[1] = '-' then*/
    _2 = (int)SEQ_PTR(_argtext_9283);
    _5198 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _5198, 45)){
        _5198 = NOVALUE;
        goto L31; // [1428] 1474
    }
    _5198 = NOVALUE;

    /** 									if width > length(argtext) then*/
    if (IS_SEQUENCE(_argtext_9283)){
            _5200 = SEQ_PTR(_argtext_9283)->length;
    }
    else {
        _5200 = 1;
    }
    if (_width_9112 <= _5200)
    goto L32; // [1439] 1504

    /** 										argtext = '-' & repeat('0', width - length(argtext)) & argtext[2..$]*/
    if (IS_SEQUENCE(_argtext_9283)){
            _5202 = SEQ_PTR(_argtext_9283)->length;
    }
    else {
        _5202 = 1;
    }
    _5203 = _width_9112 - _5202;
    _5202 = NOVALUE;
    _5204 = Repeat(48, _5203);
    _5203 = NOVALUE;
    if (IS_SEQUENCE(_argtext_9283)){
            _5205 = SEQ_PTR(_argtext_9283)->length;
    }
    else {
        _5205 = 1;
    }
    rhs_slice_target = (object_ptr)&_5206;
    RHS_Slice(_argtext_9283, 2, _5205);
    {
        int concat_list[3];

        concat_list[0] = _5206;
        concat_list[1] = _5204;
        concat_list[2] = 45;
        Concat_N((object_ptr)&_argtext_9283, concat_list, 3);
    }
    DeRefDS(_5206);
    _5206 = NOVALUE;
    DeRefDS(_5204);
    _5204 = NOVALUE;
    goto L32; // [1471] 1504
L31: 

    /** 									if width > length(argtext) then*/
    if (IS_SEQUENCE(_argtext_9283)){
            _5208 = SEQ_PTR(_argtext_9283)->length;
    }
    else {
        _5208 = 1;
    }
    if (_width_9112 <= _5208)
    goto L33; // [1481] 1503

    /** 										argtext = repeat('0', width - length(argtext)) & argtext*/
    if (IS_SEQUENCE(_argtext_9283)){
            _5210 = SEQ_PTR(_argtext_9283)->length;
    }
    else {
        _5210 = 1;
    }
    _5211 = _width_9112 - _5210;
    _5210 = NOVALUE;
    _5212 = Repeat(48, _5211);
    _5211 = NOVALUE;
    Concat((object_ptr)&_argtext_9283, _5212, _argtext_9283);
    DeRefDS(_5212);
    _5212 = NOVALUE;
    DeRef(_5212);
    _5212 = NOVALUE;
L33: 
L32: 
L30: 

    /** 							if arg_list[argn] > 0 then*/
    _2 = (int)SEQ_PTR(_arg_list_9098);
    _5214 = (int)*(((s1_ptr)_2)->base + _argn_9115);
    if (binary_op_a(LESSEQ, _5214, 0)){
        _5214 = NOVALUE;
        goto L34; // [1511] 1559
    }
    _5214 = NOVALUE;

    /** 								if psign then*/
    if (_psign_9106 == 0)
    {
        goto L27; // [1519] 2546
    }
    else{
    }

    /** 									if zfill = 0 then*/
    if (_zfill_9108 != 0)
    goto L35; // [1524] 1537

    /** 										argtext = '+' & argtext*/
    Prepend(&_argtext_9283, _argtext_9283, 43);
    goto L27; // [1534] 2546
L35: 

    /** 									elsif argtext[1] = '0' then*/
    _2 = (int)SEQ_PTR(_argtext_9283);
    _5218 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _5218, 48)){
        _5218 = NOVALUE;
        goto L27; // [1543] 2546
    }
    _5218 = NOVALUE;

    /** 										argtext[1] = '+'*/
    _2 = (int)SEQ_PTR(_argtext_9283);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _argtext_9283 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = 43;
    DeRef(_1);
    goto L27; // [1556] 2546
L34: 

    /** 							elsif arg_list[argn] < 0 then*/
    _2 = (int)SEQ_PTR(_arg_list_9098);
    _5220 = (int)*(((s1_ptr)_2)->base + _argn_9115);
    if (binary_op_a(GREATEREQ, _5220, 0)){
        _5220 = NOVALUE;
        goto L27; // [1565] 2546
    }
    _5220 = NOVALUE;

    /** 								if msign then*/
    if (_msign_9107 == 0)
    {
        goto L27; // [1573] 2546
    }
    else{
    }

    /** 									if zfill = 0 then*/
    if (_zfill_9108 != 0)
    goto L36; // [1578] 1601

    /** 										argtext = '(' & argtext[2..$] & ')'*/
    if (IS_SEQUENCE(_argtext_9283)){
            _5223 = SEQ_PTR(_argtext_9283)->length;
    }
    else {
        _5223 = 1;
    }
    rhs_slice_target = (object_ptr)&_5224;
    RHS_Slice(_argtext_9283, 2, _5223);
    {
        int concat_list[3];

        concat_list[0] = 41;
        concat_list[1] = _5224;
        concat_list[2] = 40;
        Concat_N((object_ptr)&_argtext_9283, concat_list, 3);
    }
    DeRefDS(_5224);
    _5224 = NOVALUE;
    goto L27; // [1598] 2546
L36: 

    /** 										if argtext[2] = '0' then*/
    _2 = (int)SEQ_PTR(_argtext_9283);
    _5227 = (int)*(((s1_ptr)_2)->base + 2);
    if (binary_op_a(NOTEQ, _5227, 48)){
        _5227 = NOVALUE;
        goto L37; // [1607] 1630
    }
    _5227 = NOVALUE;

    /** 											argtext = '(' & argtext[3..$] & ')'*/
    if (IS_SEQUENCE(_argtext_9283)){
            _5229 = SEQ_PTR(_argtext_9283)->length;
    }
    else {
        _5229 = 1;
    }
    rhs_slice_target = (object_ptr)&_5230;
    RHS_Slice(_argtext_9283, 3, _5229);
    {
        int concat_list[3];

        concat_list[0] = 41;
        concat_list[1] = _5230;
        concat_list[2] = 40;
        Concat_N((object_ptr)&_argtext_9283, concat_list, 3);
    }
    DeRefDS(_5230);
    _5230 = NOVALUE;
    goto L27; // [1627] 2546
L37: 

    /** 											argtext = argtext[2..$] & ')'*/
    if (IS_SEQUENCE(_argtext_9283)){
            _5232 = SEQ_PTR(_argtext_9283)->length;
    }
    else {
        _5232 = 1;
    }
    rhs_slice_target = (object_ptr)&_5233;
    RHS_Slice(_argtext_9283, 2, _5232);
    Append(&_argtext_9283, _5233, 41);
    DeRefDS(_5233);
    _5233 = NOVALUE;
    goto L27; // [1649] 2546
L2F: 

    /** 							argtext = sprintf("%x", arg_list[argn])*/
    _2 = (int)SEQ_PTR(_arg_list_9098);
    _5236 = (int)*(((s1_ptr)_2)->base + _argn_9115);
    DeRef(_argtext_9283);
    _argtext_9283 = EPrintf(-9999999, _5235, _5236);
    _5236 = NOVALUE;

    /** 							if zfill != 0 and width > 0 then*/
    _5238 = (_zfill_9108 != 0);
    if (_5238 == 0) {
        goto L27; // [1670] 2546
    }
    _5240 = (_width_9112 > 0);
    if (_5240 == 0)
    {
        DeRef(_5240);
        _5240 = NOVALUE;
        goto L27; // [1681] 2546
    }
    else{
        DeRef(_5240);
        _5240 = NOVALUE;
    }

    /** 								if width > length(argtext) then*/
    if (IS_SEQUENCE(_argtext_9283)){
            _5241 = SEQ_PTR(_argtext_9283)->length;
    }
    else {
        _5241 = 1;
    }
    if (_width_9112 <= _5241)
    goto L27; // [1691] 2546

    /** 									argtext = repeat('0', width - length(argtext)) & argtext*/
    if (IS_SEQUENCE(_argtext_9283)){
            _5243 = SEQ_PTR(_argtext_9283)->length;
    }
    else {
        _5243 = 1;
    }
    _5244 = _width_9112 - _5243;
    _5243 = NOVALUE;
    _5245 = Repeat(48, _5244);
    _5244 = NOVALUE;
    Concat((object_ptr)&_argtext_9283, _5245, _argtext_9283);
    DeRefDS(_5245);
    _5245 = NOVALUE;
    DeRef(_5245);
    _5245 = NOVALUE;
    goto L27; // [1715] 2546
L28: 

    /** 					elsif atom(arg_list[argn]) then*/
    _2 = (int)SEQ_PTR(_arg_list_9098);
    _5247 = (int)*(((s1_ptr)_2)->base + _argn_9115);
    _5248 = IS_ATOM(_5247);
    _5247 = NOVALUE;
    if (_5248 == 0)
    {
        _5248 = NOVALUE;
        goto L38; // [1727] 2130
    }
    else{
        _5248 = NOVALUE;
    }

    /** 						if istext then*/
    if (_istext_9121 == 0)
    {
        goto L39; // [1734] 1761
    }
    else{
    }

    /** 							argtext = {and_bits(0xFFFF_FFFF, math:abs(floor(arg_list[argn])))}*/
    _2 = (int)SEQ_PTR(_arg_list_9098);
    _5249 = (int)*(((s1_ptr)_2)->base + _argn_9115);
    if (IS_ATOM_INT(_5249))
    _5250 = e_floor(_5249);
    else
    _5250 = unary_op(FLOOR, _5249);
    _5249 = NOVALUE;
    _5251 = _20abs(_5250);
    _5250 = NOVALUE;
    _5252 = binary_op(AND_BITS, _1548, _5251);
    DeRef(_5251);
    _5251 = NOVALUE;
    _0 = _argtext_9283;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _5252;
    _argtext_9283 = MAKE_SEQ(_1);
    DeRef(_0);
    _5252 = NOVALUE;
    goto L27; // [1758] 2546
L39: 

    /** 							if hexout then*/
    if (_hexout_9118 == 0)
    {
        goto L3A; // [1765] 1833
    }
    else{
    }

    /** 								argtext = sprintf("%x", arg_list[argn])*/
    _2 = (int)SEQ_PTR(_arg_list_9098);
    _5254 = (int)*(((s1_ptr)_2)->base + _argn_9115);
    DeRef(_argtext_9283);
    _argtext_9283 = EPrintf(-9999999, _5235, _5254);
    _5254 = NOVALUE;

    /** 								if zfill != 0 and width > 0 then*/
    _5256 = (_zfill_9108 != 0);
    if (_5256 == 0) {
        goto L27; // [1786] 2546
    }
    _5258 = (_width_9112 > 0);
    if (_5258 == 0)
    {
        DeRef(_5258);
        _5258 = NOVALUE;
        goto L27; // [1797] 2546
    }
    else{
        DeRef(_5258);
        _5258 = NOVALUE;
    }

    /** 									if width > length(argtext) then*/
    if (IS_SEQUENCE(_argtext_9283)){
            _5259 = SEQ_PTR(_argtext_9283)->length;
    }
    else {
        _5259 = 1;
    }
    if (_width_9112 <= _5259)
    goto L27; // [1807] 2546

    /** 										argtext = repeat('0', width - length(argtext)) & argtext*/
    if (IS_SEQUENCE(_argtext_9283)){
            _5261 = SEQ_PTR(_argtext_9283)->length;
    }
    else {
        _5261 = 1;
    }
    _5262 = _width_9112 - _5261;
    _5261 = NOVALUE;
    _5263 = Repeat(48, _5262);
    _5262 = NOVALUE;
    Concat((object_ptr)&_argtext_9283, _5263, _argtext_9283);
    DeRefDS(_5263);
    _5263 = NOVALUE;
    DeRef(_5263);
    _5263 = NOVALUE;
    goto L27; // [1830] 2546
L3A: 

    /** 								argtext = trim(sprintf("%15.15g", arg_list[argn]))*/
    _2 = (int)SEQ_PTR(_arg_list_9098);
    _5266 = (int)*(((s1_ptr)_2)->base + _argn_9115);
    _5267 = EPrintf(-9999999, _5265, _5266);
    _5266 = NOVALUE;
    RefDS(_3890);
    _0 = _argtext_9283;
    _argtext_9283 = _14trim(_5267, _3890, 0);
    DeRef(_0);
    _5267 = NOVALUE;

    /** 								while ep != 0 with entry do*/
    goto L3B; // [1853] 1876
L3C: 
    if (_ep_9127 == 0)
    goto L3D; // [1858] 1888

    /** 									argtext = remove(argtext, ep+2)*/
    _5270 = _ep_9127 + 2;
    if ((long)((unsigned long)_5270 + (unsigned long)HIGH_BITS) >= 0) 
    _5270 = NewDouble((double)_5270);
    {
        s1_ptr assign_space = SEQ_PTR(_argtext_9283);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_5270)) ? _5270 : (long)(DBL_PTR(_5270)->dbl);
        int stop = (IS_ATOM_INT(_5270)) ? _5270 : (long)(DBL_PTR(_5270)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_argtext_9283), start, &_argtext_9283 );
            }
            else Tail(SEQ_PTR(_argtext_9283), stop+1, &_argtext_9283);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_argtext_9283), start, &_argtext_9283);
        }
        else {
            assign_slice_seq = &assign_space;
            _argtext_9283 = Remove_elements(start, stop, (SEQ_PTR(_argtext_9283)->ref == 1));
        }
    }
    DeRef(_5270);
    _5270 = NOVALUE;
    _5270 = NOVALUE;

    /** 								entry*/
L3B: 

    /** 									ep = match("e+0", argtext)*/
    _ep_9127 = e_match_from(_5272, _argtext_9283, 1);

    /** 								end while*/
    goto L3C; // [1885] 1856
L3D: 

    /** 								if zfill != 0 and width > 0 then*/
    _5274 = (_zfill_9108 != 0);
    if (_5274 == 0) {
        goto L3E; // [1896] 1981
    }
    _5276 = (_width_9112 > 0);
    if (_5276 == 0)
    {
        DeRef(_5276);
        _5276 = NOVALUE;
        goto L3E; // [1907] 1981
    }
    else{
        DeRef(_5276);
        _5276 = NOVALUE;
    }

    /** 									if width > length(argtext) then*/
    if (IS_SEQUENCE(_argtext_9283)){
            _5277 = SEQ_PTR(_argtext_9283)->length;
    }
    else {
        _5277 = 1;
    }
    if (_width_9112 <= _5277)
    goto L3F; // [1917] 1980

    /** 										if argtext[1] = '-' then*/
    _2 = (int)SEQ_PTR(_argtext_9283);
    _5279 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _5279, 45)){
        _5279 = NOVALUE;
        goto L40; // [1927] 1961
    }
    _5279 = NOVALUE;

    /** 											argtext = '-' & repeat('0', width - length(argtext)) & argtext[2..$]*/
    if (IS_SEQUENCE(_argtext_9283)){
            _5281 = SEQ_PTR(_argtext_9283)->length;
    }
    else {
        _5281 = 1;
    }
    _5282 = _width_9112 - _5281;
    _5281 = NOVALUE;
    _5283 = Repeat(48, _5282);
    _5282 = NOVALUE;
    if (IS_SEQUENCE(_argtext_9283)){
            _5284 = SEQ_PTR(_argtext_9283)->length;
    }
    else {
        _5284 = 1;
    }
    rhs_slice_target = (object_ptr)&_5285;
    RHS_Slice(_argtext_9283, 2, _5284);
    {
        int concat_list[3];

        concat_list[0] = _5285;
        concat_list[1] = _5283;
        concat_list[2] = 45;
        Concat_N((object_ptr)&_argtext_9283, concat_list, 3);
    }
    DeRefDS(_5285);
    _5285 = NOVALUE;
    DeRefDS(_5283);
    _5283 = NOVALUE;
    goto L41; // [1958] 1979
L40: 

    /** 											argtext = repeat('0', width - length(argtext)) & argtext*/
    if (IS_SEQUENCE(_argtext_9283)){
            _5287 = SEQ_PTR(_argtext_9283)->length;
    }
    else {
        _5287 = 1;
    }
    _5288 = _width_9112 - _5287;
    _5287 = NOVALUE;
    _5289 = Repeat(48, _5288);
    _5288 = NOVALUE;
    Concat((object_ptr)&_argtext_9283, _5289, _argtext_9283);
    DeRefDS(_5289);
    _5289 = NOVALUE;
    DeRef(_5289);
    _5289 = NOVALUE;
L41: 
L3F: 
L3E: 

    /** 								if arg_list[argn] > 0 then*/
    _2 = (int)SEQ_PTR(_arg_list_9098);
    _5291 = (int)*(((s1_ptr)_2)->base + _argn_9115);
    if (binary_op_a(LESSEQ, _5291, 0)){
        _5291 = NOVALUE;
        goto L42; // [1987] 2035
    }
    _5291 = NOVALUE;

    /** 									if psign  then*/
    if (_psign_9106 == 0)
    {
        goto L27; // [1995] 2546
    }
    else{
    }

    /** 										if zfill = 0 then*/
    if (_zfill_9108 != 0)
    goto L43; // [2000] 2013

    /** 											argtext = '+' & argtext*/
    Prepend(&_argtext_9283, _argtext_9283, 43);
    goto L27; // [2010] 2546
L43: 

    /** 										elsif argtext[1] = '0' then*/
    _2 = (int)SEQ_PTR(_argtext_9283);
    _5295 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _5295, 48)){
        _5295 = NOVALUE;
        goto L27; // [2019] 2546
    }
    _5295 = NOVALUE;

    /** 											argtext[1] = '+'*/
    _2 = (int)SEQ_PTR(_argtext_9283);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _argtext_9283 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = 43;
    DeRef(_1);
    goto L27; // [2032] 2546
L42: 

    /** 								elsif arg_list[argn] < 0 then*/
    _2 = (int)SEQ_PTR(_arg_list_9098);
    _5297 = (int)*(((s1_ptr)_2)->base + _argn_9115);
    if (binary_op_a(GREATEREQ, _5297, 0)){
        _5297 = NOVALUE;
        goto L27; // [2041] 2546
    }
    _5297 = NOVALUE;

    /** 									if msign then*/
    if (_msign_9107 == 0)
    {
        goto L27; // [2049] 2546
    }
    else{
    }

    /** 										if zfill = 0 then*/
    if (_zfill_9108 != 0)
    goto L44; // [2054] 2077

    /** 											argtext = '(' & argtext[2..$] & ')'*/
    if (IS_SEQUENCE(_argtext_9283)){
            _5300 = SEQ_PTR(_argtext_9283)->length;
    }
    else {
        _5300 = 1;
    }
    rhs_slice_target = (object_ptr)&_5301;
    RHS_Slice(_argtext_9283, 2, _5300);
    {
        int concat_list[3];

        concat_list[0] = 41;
        concat_list[1] = _5301;
        concat_list[2] = 40;
        Concat_N((object_ptr)&_argtext_9283, concat_list, 3);
    }
    DeRefDS(_5301);
    _5301 = NOVALUE;
    goto L27; // [2074] 2546
L44: 

    /** 											if argtext[2] = '0' then*/
    _2 = (int)SEQ_PTR(_argtext_9283);
    _5303 = (int)*(((s1_ptr)_2)->base + 2);
    if (binary_op_a(NOTEQ, _5303, 48)){
        _5303 = NOVALUE;
        goto L45; // [2083] 2106
    }
    _5303 = NOVALUE;

    /** 												argtext = '(' & argtext[3..$] & ')'*/
    if (IS_SEQUENCE(_argtext_9283)){
            _5305 = SEQ_PTR(_argtext_9283)->length;
    }
    else {
        _5305 = 1;
    }
    rhs_slice_target = (object_ptr)&_5306;
    RHS_Slice(_argtext_9283, 3, _5305);
    {
        int concat_list[3];

        concat_list[0] = 41;
        concat_list[1] = _5306;
        concat_list[2] = 40;
        Concat_N((object_ptr)&_argtext_9283, concat_list, 3);
    }
    DeRefDS(_5306);
    _5306 = NOVALUE;
    goto L27; // [2103] 2546
L45: 

    /** 												argtext = argtext[2..$] & ')'*/
    if (IS_SEQUENCE(_argtext_9283)){
            _5308 = SEQ_PTR(_argtext_9283)->length;
    }
    else {
        _5308 = 1;
    }
    rhs_slice_target = (object_ptr)&_5309;
    RHS_Slice(_argtext_9283, 2, _5308);
    Append(&_argtext_9283, _5309, 41);
    DeRefDS(_5309);
    _5309 = NOVALUE;
    goto L27; // [2127] 2546
L38: 

    /** 						if alt != 0 and length(arg_list[argn]) = 2 then*/
    _5311 = (_alt_9111 != 0);
    if (_5311 == 0) {
        goto L46; // [2138] 2457
    }
    _2 = (int)SEQ_PTR(_arg_list_9098);
    _5313 = (int)*(((s1_ptr)_2)->base + _argn_9115);
    if (IS_SEQUENCE(_5313)){
            _5314 = SEQ_PTR(_5313)->length;
    }
    else {
        _5314 = 1;
    }
    _5313 = NOVALUE;
    _5315 = (_5314 == 2);
    _5314 = NOVALUE;
    if (_5315 == 0)
    {
        DeRef(_5315);
        _5315 = NOVALUE;
        goto L46; // [2154] 2457
    }
    else{
        DeRef(_5315);
        _5315 = NOVALUE;
    }

    /** 							object tempv*/

    /** 							if atom(prevargv) then*/
    _5316 = IS_ATOM(_prevargv_9122);
    if (_5316 == 0)
    {
        _5316 = NOVALUE;
        goto L47; // [2164] 2200
    }
    else{
        _5316 = NOVALUE;
    }

    /** 								if prevargv != 1 then*/
    if (binary_op_a(EQUALS, _prevargv_9122, 1)){
        goto L48; // [2169] 2186
    }

    /** 									tempv = arg_list[argn][1]*/
    _2 = (int)SEQ_PTR(_arg_list_9098);
    _5318 = (int)*(((s1_ptr)_2)->base + _argn_9115);
    DeRef(_tempv_9506);
    _2 = (int)SEQ_PTR(_5318);
    _tempv_9506 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_tempv_9506);
    _5318 = NOVALUE;
    goto L49; // [2183] 2234
L48: 

    /** 									tempv = arg_list[argn][2]*/
    _2 = (int)SEQ_PTR(_arg_list_9098);
    _5320 = (int)*(((s1_ptr)_2)->base + _argn_9115);
    DeRef(_tempv_9506);
    _2 = (int)SEQ_PTR(_5320);
    _tempv_9506 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_tempv_9506);
    _5320 = NOVALUE;
    goto L49; // [2197] 2234
L47: 

    /** 								if length(prevargv) = 0 then*/
    if (IS_SEQUENCE(_prevargv_9122)){
            _5322 = SEQ_PTR(_prevargv_9122)->length;
    }
    else {
        _5322 = 1;
    }
    if (_5322 != 0)
    goto L4A; // [2205] 2222

    /** 									tempv = arg_list[argn][1]*/
    _2 = (int)SEQ_PTR(_arg_list_9098);
    _5324 = (int)*(((s1_ptr)_2)->base + _argn_9115);
    DeRef(_tempv_9506);
    _2 = (int)SEQ_PTR(_5324);
    _tempv_9506 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_tempv_9506);
    _5324 = NOVALUE;
    goto L4B; // [2219] 2233
L4A: 

    /** 									tempv = arg_list[argn][2]*/
    _2 = (int)SEQ_PTR(_arg_list_9098);
    _5326 = (int)*(((s1_ptr)_2)->base + _argn_9115);
    DeRef(_tempv_9506);
    _2 = (int)SEQ_PTR(_5326);
    _tempv_9506 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_tempv_9506);
    _5326 = NOVALUE;
L4B: 
L49: 

    /** 							if string(tempv) then*/
    Ref(_tempv_9506);
    _5328 = _13string(_tempv_9506);
    if (_5328 == 0) {
        DeRef(_5328);
        _5328 = NOVALUE;
        goto L4C; // [2242] 2255
    }
    else {
        if (!IS_ATOM_INT(_5328) && DBL_PTR(_5328)->dbl == 0.0){
            DeRef(_5328);
            _5328 = NOVALUE;
            goto L4C; // [2242] 2255
        }
        DeRef(_5328);
        _5328 = NOVALUE;
    }
    DeRef(_5328);
    _5328 = NOVALUE;

    /** 								argtext = tempv*/
    Ref(_tempv_9506);
    DeRef(_argtext_9283);
    _argtext_9283 = _tempv_9506;
    goto L4D; // [2252] 2452
L4C: 

    /** 							elsif integer(tempv) then*/
    if (IS_ATOM_INT(_tempv_9506))
    _5329 = 1;
    else if (IS_ATOM_DBL(_tempv_9506))
    _5329 = IS_ATOM_INT(DoubleToInt(_tempv_9506));
    else
    _5329 = 0;
    if (_5329 == 0)
    {
        _5329 = NOVALUE;
        goto L4E; // [2260] 2326
    }
    else{
        _5329 = NOVALUE;
    }

    /** 								if istext then*/
    if (_istext_9121 == 0)
    {
        goto L4F; // [2265] 2285
    }
    else{
    }

    /** 									argtext = {and_bits(0xFFFF_FFFF, math:abs(tempv))}*/
    Ref(_tempv_9506);
    _5330 = _20abs(_tempv_9506);
    _5331 = binary_op(AND_BITS, _1548, _5330);
    DeRef(_5330);
    _5330 = NOVALUE;
    _0 = _argtext_9283;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _5331;
    _argtext_9283 = MAKE_SEQ(_1);
    DeRef(_0);
    _5331 = NOVALUE;
    goto L4D; // [2282] 2452
L4F: 

    /** 								elsif bwz != 0 and tempv = 0 then*/
    _5333 = (_bwz_9109 != 0);
    if (_5333 == 0) {
        goto L50; // [2293] 2316
    }
    if (IS_ATOM_INT(_tempv_9506)) {
        _5335 = (_tempv_9506 == 0);
    }
    else {
        _5335 = binary_op(EQUALS, _tempv_9506, 0);
    }
    if (_5335 == 0) {
        DeRef(_5335);
        _5335 = NOVALUE;
        goto L50; // [2302] 2316
    }
    else {
        if (!IS_ATOM_INT(_5335) && DBL_PTR(_5335)->dbl == 0.0){
            DeRef(_5335);
            _5335 = NOVALUE;
            goto L50; // [2302] 2316
        }
        DeRef(_5335);
        _5335 = NOVALUE;
    }
    DeRef(_5335);
    _5335 = NOVALUE;

    /** 									argtext = repeat(' ', width)*/
    DeRef(_argtext_9283);
    _argtext_9283 = Repeat(32, _width_9112);
    goto L4D; // [2313] 2452
L50: 

    /** 									argtext = sprintf("%d", tempv)*/
    DeRef(_argtext_9283);
    _argtext_9283 = EPrintf(-9999999, _954, _tempv_9506);
    goto L4D; // [2323] 2452
L4E: 

    /** 							elsif atom(tempv) then*/
    _5338 = IS_ATOM(_tempv_9506);
    if (_5338 == 0)
    {
        _5338 = NOVALUE;
        goto L51; // [2331] 2408
    }
    else{
        _5338 = NOVALUE;
    }

    /** 								if istext then*/
    if (_istext_9121 == 0)
    {
        goto L52; // [2336] 2359
    }
    else{
    }

    /** 									argtext = {and_bits(0xFFFF_FFFF, math:abs(floor(tempv)))}*/
    if (IS_ATOM_INT(_tempv_9506))
    _5339 = e_floor(_tempv_9506);
    else
    _5339 = unary_op(FLOOR, _tempv_9506);
    _5340 = _20abs(_5339);
    _5339 = NOVALUE;
    _5341 = binary_op(AND_BITS, _1548, _5340);
    DeRef(_5340);
    _5340 = NOVALUE;
    _0 = _argtext_9283;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _5341;
    _argtext_9283 = MAKE_SEQ(_1);
    DeRef(_0);
    _5341 = NOVALUE;
    goto L4D; // [2356] 2452
L52: 

    /** 								elsif bwz != 0 and tempv = 0 then*/
    _5343 = (_bwz_9109 != 0);
    if (_5343 == 0) {
        goto L53; // [2367] 2390
    }
    if (IS_ATOM_INT(_tempv_9506)) {
        _5345 = (_tempv_9506 == 0);
    }
    else {
        _5345 = binary_op(EQUALS, _tempv_9506, 0);
    }
    if (_5345 == 0) {
        DeRef(_5345);
        _5345 = NOVALUE;
        goto L53; // [2376] 2390
    }
    else {
        if (!IS_ATOM_INT(_5345) && DBL_PTR(_5345)->dbl == 0.0){
            DeRef(_5345);
            _5345 = NOVALUE;
            goto L53; // [2376] 2390
        }
        DeRef(_5345);
        _5345 = NOVALUE;
    }
    DeRef(_5345);
    _5345 = NOVALUE;

    /** 									argtext = repeat(' ', width)*/
    DeRef(_argtext_9283);
    _argtext_9283 = Repeat(32, _width_9112);
    goto L4D; // [2387] 2452
L53: 

    /** 									argtext = trim(sprintf("%15.15g", tempv))*/
    _5347 = EPrintf(-9999999, _5265, _tempv_9506);
    RefDS(_3890);
    _0 = _argtext_9283;
    _argtext_9283 = _14trim(_5347, _3890, 0);
    DeRef(_0);
    _5347 = NOVALUE;
    goto L4D; // [2405] 2452
L51: 

    /** 								argtext = pretty:pretty_sprint( tempv,*/
    _1 = NewS1(10);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 2;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = 1;
    *((int *)(_2+16)) = 1000;
    RefDS(_954);
    *((int *)(_2+20)) = _954;
    RefDS(_5349);
    *((int *)(_2+24)) = _5349;
    *((int *)(_2+28)) = 32;
    *((int *)(_2+32)) = 127;
    *((int *)(_2+36)) = 1;
    *((int *)(_2+40)) = 0;
    _5350 = MAKE_SEQ(_1);
    DeRef(_options_inlined_pretty_sprint_at_2424_9560);
    _options_inlined_pretty_sprint_at_2424_9560 = _5350;
    _5350 = NOVALUE;

    /** 	pretty_printing = 0*/
    _26pretty_printing_7548 = 0;

    /** 	pretty( x, options )*/
    Ref(_tempv_9506);
    RefDS(_options_inlined_pretty_sprint_at_2424_9560);
    _26pretty(_tempv_9506, _options_inlined_pretty_sprint_at_2424_9560);

    /** 	return pretty_line*/
    RefDS(_26pretty_line_7551);
    DeRef(_argtext_9283);
    _argtext_9283 = _26pretty_line_7551;
    DeRef(_options_inlined_pretty_sprint_at_2424_9560);
    _options_inlined_pretty_sprint_at_2424_9560 = NOVALUE;
L4D: 
    DeRef(_tempv_9506);
    _tempv_9506 = NOVALUE;
    goto L54; // [2454] 2533
L46: 

    /** 							argtext = pretty:pretty_sprint( arg_list[argn],*/
    _2 = (int)SEQ_PTR(_arg_list_9098);
    _5351 = (int)*(((s1_ptr)_2)->base + _argn_9115);
    _1 = NewS1(10);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 2;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = 1;
    *((int *)(_2+16)) = 1000;
    RefDS(_954);
    *((int *)(_2+20)) = _954;
    RefDS(_5349);
    *((int *)(_2+24)) = _5349;
    *((int *)(_2+28)) = 32;
    *((int *)(_2+32)) = 127;
    *((int *)(_2+36)) = 1;
    *((int *)(_2+40)) = 0;
    _5352 = MAKE_SEQ(_1);
    Ref(_5351);
    DeRef(_x_inlined_pretty_sprint_at_2477_9566);
    _x_inlined_pretty_sprint_at_2477_9566 = _5351;
    _5351 = NOVALUE;
    DeRef(_options_inlined_pretty_sprint_at_2480_9567);
    _options_inlined_pretty_sprint_at_2480_9567 = _5352;
    _5352 = NOVALUE;

    /** 	pretty_printing = 0*/
    _26pretty_printing_7548 = 0;

    /** 	pretty( x, options )*/
    Ref(_x_inlined_pretty_sprint_at_2477_9566);
    RefDS(_options_inlined_pretty_sprint_at_2480_9567);
    _26pretty(_x_inlined_pretty_sprint_at_2477_9566, _options_inlined_pretty_sprint_at_2480_9567);

    /** 	return pretty_line*/
    RefDS(_26pretty_line_7551);
    DeRef(_argtext_9283);
    _argtext_9283 = _26pretty_line_7551;
    DeRef(_x_inlined_pretty_sprint_at_2477_9566);
    _x_inlined_pretty_sprint_at_2477_9566 = NOVALUE;
    DeRef(_options_inlined_pretty_sprint_at_2480_9567);
    _options_inlined_pretty_sprint_at_2480_9567 = NOVALUE;

    /** 						while ep != 0 with entry do*/
    goto L54; // [2510] 2533
L55: 
    if (_ep_9127 == 0)
    goto L56; // [2515] 2545

    /** 							argtext = remove(argtext, ep+2)*/
    _5354 = _ep_9127 + 2;
    if ((long)((unsigned long)_5354 + (unsigned long)HIGH_BITS) >= 0) 
    _5354 = NewDouble((double)_5354);
    {
        s1_ptr assign_space = SEQ_PTR(_argtext_9283);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_5354)) ? _5354 : (long)(DBL_PTR(_5354)->dbl);
        int stop = (IS_ATOM_INT(_5354)) ? _5354 : (long)(DBL_PTR(_5354)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_argtext_9283), start, &_argtext_9283 );
            }
            else Tail(SEQ_PTR(_argtext_9283), stop+1, &_argtext_9283);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_argtext_9283), start, &_argtext_9283);
        }
        else {
            assign_slice_seq = &assign_space;
            _argtext_9283 = Remove_elements(start, stop, (SEQ_PTR(_argtext_9283)->ref == 1));
        }
    }
    DeRef(_5354);
    _5354 = NOVALUE;
    _5354 = NOVALUE;

    /** 						entry*/
L54: 

    /** 							ep = match("e+0", argtext)*/
    _ep_9127 = e_match_from(_5272, _argtext_9283, 1);

    /** 						end while*/
    goto L55; // [2542] 2513
L56: 
L27: 

    /** 	    			currargv = arg_list[argn]*/
    DeRef(_currargv_9123);
    _2 = (int)SEQ_PTR(_arg_list_9098);
    _currargv_9123 = (int)*(((s1_ptr)_2)->base + _argn_9115);
    Ref(_currargv_9123);
L24: 

    /**     			if length(argtext) > 0 then*/
    if (IS_SEQUENCE(_argtext_9283)){
            _5358 = SEQ_PTR(_argtext_9283)->length;
    }
    else {
        _5358 = 1;
    }
    if (_5358 <= 0)
    goto L57; // [2558] 3328

    /**     				switch cap do*/
    _0 = _cap_9104;
    switch ( _0 ){ 

        /**     					case 'u' then*/
        case 117:

        /**     						argtext = upper(argtext)*/
        RefDS(_argtext_9283);
        _0 = _argtext_9283;
        _argtext_9283 = _14upper(_argtext_9283);
        DeRefDS(_0);
        goto L58; // [2583] 2649

        /**     					case 'l' then*/
        case 108:

        /**     						argtext = lower(argtext)*/
        RefDS(_argtext_9283);
        _0 = _argtext_9283;
        _argtext_9283 = _14lower(_argtext_9283);
        DeRefDS(_0);
        goto L58; // [2597] 2649

        /**     					case 'w' then*/
        case 119:

        /**     						argtext = proper(argtext)*/
        RefDS(_argtext_9283);
        _0 = _argtext_9283;
        _argtext_9283 = _14proper(_argtext_9283);
        DeRefDS(_0);
        goto L58; // [2611] 2649

        /**     					case 0 then*/
        case 0:

        /** 							cap = cap*/
        _cap_9104 = _cap_9104;
        goto L58; // [2622] 2649

        /**     					case else*/
        default:

        /**     						error:crash("logic error: 'cap' mode in format.")*/

        /** 	msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_2631_9590);
        _msg_inlined_crash_at_2631_9590 = EPrintf(-9999999, _5365, _5);

        /** 	machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_2631_9590);

        /** end procedure*/
        goto L59; // [2643] 2646
L59: 
        DeRefi(_msg_inlined_crash_at_2631_9590);
        _msg_inlined_crash_at_2631_9590 = NOVALUE;
    ;}L58: 

    /** 					if atom(currargv) then*/
    _5366 = IS_ATOM(_currargv_9123);
    if (_5366 == 0)
    {
        _5366 = NOVALUE;
        goto L5A; // [2656] 2795
    }
    else{
        _5366 = NOVALUE;
    }

    /** 						if find('e', argtext) = 0 then*/
    _5367 = find_from(101, _argtext_9283, 1);
    if (_5367 != 0)
    goto L5B; // [2666] 2794

    /** 							if decs != -1 then*/
    if (_decs_9113 == -1)
    goto L5C; // [2674] 2793

    /** 								pos = find('.', argtext)*/
    _pos_9114 = find_from(46, _argtext_9283, 1);

    /** 								if pos then*/
    if (_pos_9114 == 0)
    {
        goto L5D; // [2687] 2772
    }
    else{
    }

    /** 									if decs = 0 then*/
    if (_decs_9113 != 0)
    goto L5E; // [2692] 2710

    /** 										argtext = argtext [1 .. pos-1 ]*/
    _5372 = _pos_9114 - 1;
    rhs_slice_target = (object_ptr)&_argtext_9283;
    RHS_Slice(_argtext_9283, 1, _5372);
    goto L5F; // [2707] 2792
L5E: 

    /** 										pos = length(argtext) - pos*/
    if (IS_SEQUENCE(_argtext_9283)){
            _5374 = SEQ_PTR(_argtext_9283)->length;
    }
    else {
        _5374 = 1;
    }
    _pos_9114 = _5374 - _pos_9114;
    _5374 = NOVALUE;

    /** 										if pos > decs then*/
    if (_pos_9114 <= _decs_9113)
    goto L60; // [2721] 2746

    /** 											argtext = argtext[ 1 .. $ - pos + decs ]*/
    if (IS_SEQUENCE(_argtext_9283)){
            _5377 = SEQ_PTR(_argtext_9283)->length;
    }
    else {
        _5377 = 1;
    }
    _5378 = _5377 - _pos_9114;
    if ((long)((unsigned long)_5378 +(unsigned long) HIGH_BITS) >= 0){
        _5378 = NewDouble((double)_5378);
    }
    _5377 = NOVALUE;
    if (IS_ATOM_INT(_5378)) {
        _5379 = _5378 + _decs_9113;
    }
    else {
        _5379 = NewDouble(DBL_PTR(_5378)->dbl + (double)_decs_9113);
    }
    DeRef(_5378);
    _5378 = NOVALUE;
    rhs_slice_target = (object_ptr)&_argtext_9283;
    RHS_Slice(_argtext_9283, 1, _5379);
    goto L5F; // [2743] 2792
L60: 

    /** 										elsif pos < decs then*/
    if (_pos_9114 >= _decs_9113)
    goto L5F; // [2748] 2792

    /** 											argtext = argtext & repeat('0', decs - pos)*/
    _5382 = _decs_9113 - _pos_9114;
    _5383 = Repeat(48, _5382);
    _5382 = NOVALUE;
    Concat((object_ptr)&_argtext_9283, _argtext_9283, _5383);
    DeRefDS(_5383);
    _5383 = NOVALUE;
    goto L5F; // [2769] 2792
L5D: 

    /** 								elsif decs > 0 then*/
    if (_decs_9113 <= 0)
    goto L61; // [2774] 2791

    /** 									argtext = argtext & '.' & repeat('0', decs)*/
    _5386 = Repeat(48, _decs_9113);
    {
        int concat_list[3];

        concat_list[0] = _5386;
        concat_list[1] = 46;
        concat_list[2] = _argtext_9283;
        Concat_N((object_ptr)&_argtext_9283, concat_list, 3);
    }
    DeRefDS(_5386);
    _5386 = NOVALUE;
L61: 
L5F: 
L5C: 
L5B: 
L5A: 

    /**     				if align = 0 then*/
    if (_align_9105 != 0)
    goto L62; // [2799] 2826

    /**     					if atom(currargv) then*/
    _5389 = IS_ATOM(_currargv_9123);
    if (_5389 == 0)
    {
        _5389 = NOVALUE;
        goto L63; // [2808] 2819
    }
    else{
        _5389 = NOVALUE;
    }

    /**     						align = '>'*/
    _align_9105 = 62;
    goto L64; // [2816] 2825
L63: 

    /**     						align = '<'*/
    _align_9105 = 60;
L64: 
L62: 

    /**     				if atom(currargv) then*/
    _5390 = IS_ATOM(_currargv_9123);
    if (_5390 == 0)
    {
        _5390 = NOVALUE;
        goto L65; // [2831] 3032
    }
    else{
        _5390 = NOVALUE;
    }

    /** 	    				if tsep != 0 and zfill = 0 then*/
    _5391 = (_tsep_9120 != 0);
    if (_5391 == 0) {
        goto L66; // [2842] 3029
    }
    _5393 = (_zfill_9108 == 0);
    if (_5393 == 0)
    {
        DeRef(_5393);
        _5393 = NOVALUE;
        goto L66; // [2853] 3029
    }
    else{
        DeRef(_5393);
        _5393 = NOVALUE;
    }

    /** 	    					integer dpos*/

    /** 	    					integer dist*/

    /** 	    					integer bracketed*/

    /** 	    					if binout or hexout then*/
    if (_binout_9119 != 0) {
        goto L67; // [2866] 2875
    }
    if (_hexout_9118 == 0)
    {
        goto L68; // [2871] 2883
    }
    else{
    }
L67: 

    /** 	    						dist = 4*/
    _dist_9634 = 4;
    goto L69; // [2880] 2889
L68: 

    /** 	    						dist = 3*/
    _dist_9634 = 3;
L69: 

    /** 	    					bracketed = (argtext[1] = '(')*/
    _2 = (int)SEQ_PTR(_argtext_9283);
    _5395 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_5395)) {
        _bracketed_9635 = (_5395 == 40);
    }
    else {
        _bracketed_9635 = binary_op(EQUALS, _5395, 40);
    }
    _5395 = NOVALUE;
    if (!IS_ATOM_INT(_bracketed_9635)) {
        _1 = (long)(DBL_PTR(_bracketed_9635)->dbl);
        DeRefDS(_bracketed_9635);
        _bracketed_9635 = _1;
    }

    /** 	    					if bracketed then*/
    if (_bracketed_9635 == 0)
    {
        goto L6A; // [2903] 2921
    }
    else{
    }

    /** 	    						argtext = argtext[2 .. $-1]*/
    if (IS_SEQUENCE(_argtext_9283)){
            _5397 = SEQ_PTR(_argtext_9283)->length;
    }
    else {
        _5397 = 1;
    }
    _5398 = _5397 - 1;
    _5397 = NOVALUE;
    rhs_slice_target = (object_ptr)&_argtext_9283;
    RHS_Slice(_argtext_9283, 2, _5398);
L6A: 

    /** 	    					dpos = find('.', argtext)*/
    _dpos_9633 = find_from(46, _argtext_9283, 1);

    /** 	    					if dpos = 0 then*/
    if (_dpos_9633 != 0)
    goto L6B; // [2930] 2946

    /** 	    						dpos = length(argtext) + 1*/
    if (IS_SEQUENCE(_argtext_9283)){
            _5402 = SEQ_PTR(_argtext_9283)->length;
    }
    else {
        _5402 = 1;
    }
    _dpos_9633 = _5402 + 1;
    _5402 = NOVALUE;
    goto L6C; // [2943] 2960
L6B: 

    /** 	    						if tsep = '.' then*/
    if (_tsep_9120 != 46)
    goto L6D; // [2948] 2959

    /** 	    							argtext[dpos] = ','*/
    _2 = (int)SEQ_PTR(_argtext_9283);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _argtext_9283 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _dpos_9633);
    _1 = *(int *)_2;
    *(int *)_2 = 44;
    DeRef(_1);
L6D: 
L6C: 

    /** 	    					while dpos > dist do*/
L6E: 
    if (_dpos_9633 <= _dist_9634)
    goto L6F; // [2967] 3014

    /** 	    						dpos -= dist*/
    _dpos_9633 = _dpos_9633 - _dist_9634;

    /** 	    						if dpos > 1 then*/
    if (_dpos_9633 <= 1)
    goto L6E; // [2979] 2965

    /** 	    							argtext = argtext[1.. dpos - 1] & tsep & argtext[dpos .. $]*/
    _5408 = _dpos_9633 - 1;
    rhs_slice_target = (object_ptr)&_5409;
    RHS_Slice(_argtext_9283, 1, _5408);
    if (IS_SEQUENCE(_argtext_9283)){
            _5410 = SEQ_PTR(_argtext_9283)->length;
    }
    else {
        _5410 = 1;
    }
    rhs_slice_target = (object_ptr)&_5411;
    RHS_Slice(_argtext_9283, _dpos_9633, _5410);
    {
        int concat_list[3];

        concat_list[0] = _5411;
        concat_list[1] = _tsep_9120;
        concat_list[2] = _5409;
        Concat_N((object_ptr)&_argtext_9283, concat_list, 3);
    }
    DeRefDS(_5411);
    _5411 = NOVALUE;
    DeRefDS(_5409);
    _5409 = NOVALUE;

    /** 	    					end while*/
    goto L6E; // [3011] 2965
L6F: 

    /** 	    					if bracketed then*/
    if (_bracketed_9635 == 0)
    {
        goto L70; // [3016] 3028
    }
    else{
    }

    /** 	    						argtext = '(' & argtext & ')'*/
    {
        int concat_list[3];

        concat_list[0] = 41;
        concat_list[1] = _argtext_9283;
        concat_list[2] = 40;
        Concat_N((object_ptr)&_argtext_9283, concat_list, 3);
    }
L70: 
L66: 
L65: 

    /**     				if width <= 0 then*/
    if (_width_9112 > 0)
    goto L71; // [3036] 3046

    /**     					width = length(argtext)*/
    if (IS_SEQUENCE(_argtext_9283)){
            _width_9112 = SEQ_PTR(_argtext_9283)->length;
    }
    else {
        _width_9112 = 1;
    }
L71: 

    /**     				if width < length(argtext) then*/
    if (IS_SEQUENCE(_argtext_9283)){
            _5416 = SEQ_PTR(_argtext_9283)->length;
    }
    else {
        _5416 = 1;
    }
    if (_width_9112 >= _5416)
    goto L72; // [3051] 3182

    /**     					if align = '>' then*/
    if (_align_9105 != 62)
    goto L73; // [3057] 3085

    /**     						argtext = argtext[ $ - width + 1 .. $]*/
    if (IS_SEQUENCE(_argtext_9283)){
            _5419 = SEQ_PTR(_argtext_9283)->length;
    }
    else {
        _5419 = 1;
    }
    _5420 = _5419 - _width_9112;
    if ((long)((unsigned long)_5420 +(unsigned long) HIGH_BITS) >= 0){
        _5420 = NewDouble((double)_5420);
    }
    _5419 = NOVALUE;
    if (IS_ATOM_INT(_5420)) {
        _5421 = _5420 + 1;
        if (_5421 > MAXINT){
            _5421 = NewDouble((double)_5421);
        }
    }
    else
    _5421 = binary_op(PLUS, 1, _5420);
    DeRef(_5420);
    _5420 = NOVALUE;
    if (IS_SEQUENCE(_argtext_9283)){
            _5422 = SEQ_PTR(_argtext_9283)->length;
    }
    else {
        _5422 = 1;
    }
    rhs_slice_target = (object_ptr)&_argtext_9283;
    RHS_Slice(_argtext_9283, _5421, _5422);
    goto L74; // [3082] 3319
L73: 

    /**     					elsif align = 'c' then*/
    if (_align_9105 != 99)
    goto L75; // [3087] 3171

    /**     						pos = length(argtext) - width*/
    if (IS_SEQUENCE(_argtext_9283)){
            _5425 = SEQ_PTR(_argtext_9283)->length;
    }
    else {
        _5425 = 1;
    }
    _pos_9114 = _5425 - _width_9112;
    _5425 = NOVALUE;

    /**     						if remainder(pos, 2) = 0 then*/
    _5427 = (_pos_9114 % 2);
    if (_5427 != 0)
    goto L76; // [3106] 3139

    /**     							pos = pos / 2*/
    if (_pos_9114 & 1) {
        _pos_9114 = NewDouble((_pos_9114 >> 1) + 0.5);
    }
    else
    _pos_9114 = _pos_9114 >> 1;
    if (!IS_ATOM_INT(_pos_9114)) {
        _1 = (long)(DBL_PTR(_pos_9114)->dbl);
        DeRefDS(_pos_9114);
        _pos_9114 = _1;
    }

    /**     							argtext = argtext[ pos + 1 .. $ - pos ]*/
    _5430 = _pos_9114 + 1;
    if (_5430 > MAXINT){
        _5430 = NewDouble((double)_5430);
    }
    if (IS_SEQUENCE(_argtext_9283)){
            _5431 = SEQ_PTR(_argtext_9283)->length;
    }
    else {
        _5431 = 1;
    }
    _5432 = _5431 - _pos_9114;
    _5431 = NOVALUE;
    rhs_slice_target = (object_ptr)&_argtext_9283;
    RHS_Slice(_argtext_9283, _5430, _5432);
    goto L74; // [3136] 3319
L76: 

    /**     							pos = floor(pos / 2)*/
    _pos_9114 = _pos_9114 >> 1;

    /**     							argtext = argtext[ pos + 1 .. $ - pos - 1]*/
    _5435 = _pos_9114 + 1;
    if (_5435 > MAXINT){
        _5435 = NewDouble((double)_5435);
    }
    if (IS_SEQUENCE(_argtext_9283)){
            _5436 = SEQ_PTR(_argtext_9283)->length;
    }
    else {
        _5436 = 1;
    }
    _5437 = _5436 - _pos_9114;
    if ((long)((unsigned long)_5437 +(unsigned long) HIGH_BITS) >= 0){
        _5437 = NewDouble((double)_5437);
    }
    _5436 = NOVALUE;
    if (IS_ATOM_INT(_5437)) {
        _5438 = _5437 - 1;
    }
    else {
        _5438 = NewDouble(DBL_PTR(_5437)->dbl - (double)1);
    }
    DeRef(_5437);
    _5437 = NOVALUE;
    rhs_slice_target = (object_ptr)&_argtext_9283;
    RHS_Slice(_argtext_9283, _5435, _5438);
    goto L74; // [3168] 3319
L75: 

    /**     						argtext = argtext[ 1 .. width]*/
    rhs_slice_target = (object_ptr)&_argtext_9283;
    RHS_Slice(_argtext_9283, 1, _width_9112);
    goto L74; // [3179] 3319
L72: 

    /**     				elsif width > length(argtext) then*/
    if (IS_SEQUENCE(_argtext_9283)){
            _5441 = SEQ_PTR(_argtext_9283)->length;
    }
    else {
        _5441 = 1;
    }
    if (_width_9112 <= _5441)
    goto L77; // [3187] 3318

    /** 						if align = '>' then*/
    if (_align_9105 != 62)
    goto L78; // [3193] 3217

    /** 							argtext = repeat(' ', width - length(argtext)) & argtext*/
    if (IS_SEQUENCE(_argtext_9283)){
            _5444 = SEQ_PTR(_argtext_9283)->length;
    }
    else {
        _5444 = 1;
    }
    _5445 = _width_9112 - _5444;
    _5444 = NOVALUE;
    _5446 = Repeat(32, _5445);
    _5445 = NOVALUE;
    Concat((object_ptr)&_argtext_9283, _5446, _argtext_9283);
    DeRefDS(_5446);
    _5446 = NOVALUE;
    DeRef(_5446);
    _5446 = NOVALUE;
    goto L79; // [3214] 3317
L78: 

    /**     					elsif align = 'c' then*/
    if (_align_9105 != 99)
    goto L7A; // [3219] 3299

    /**     						pos = width - length(argtext)*/
    if (IS_SEQUENCE(_argtext_9283)){
            _5449 = SEQ_PTR(_argtext_9283)->length;
    }
    else {
        _5449 = 1;
    }
    _pos_9114 = _width_9112 - _5449;
    _5449 = NOVALUE;

    /**     						if remainder(pos, 2) = 0 then*/
    _5451 = (_pos_9114 % 2);
    if (_5451 != 0)
    goto L7B; // [3238] 3269

    /**     							pos = pos / 2*/
    if (_pos_9114 & 1) {
        _pos_9114 = NewDouble((_pos_9114 >> 1) + 0.5);
    }
    else
    _pos_9114 = _pos_9114 >> 1;
    if (!IS_ATOM_INT(_pos_9114)) {
        _1 = (long)(DBL_PTR(_pos_9114)->dbl);
        DeRefDS(_pos_9114);
        _pos_9114 = _1;
    }

    /**     							argtext = repeat(' ', pos) & argtext & repeat(' ', pos)*/
    _5454 = Repeat(32, _pos_9114);
    _5455 = Repeat(32, _pos_9114);
    {
        int concat_list[3];

        concat_list[0] = _5455;
        concat_list[1] = _argtext_9283;
        concat_list[2] = _5454;
        Concat_N((object_ptr)&_argtext_9283, concat_list, 3);
    }
    DeRefDS(_5455);
    _5455 = NOVALUE;
    DeRefDS(_5454);
    _5454 = NOVALUE;
    goto L79; // [3266] 3317
L7B: 

    /**     							pos = floor(pos / 2)*/
    _pos_9114 = _pos_9114 >> 1;

    /**     							argtext = repeat(' ', pos) & argtext & repeat(' ', pos + 1)*/
    _5458 = Repeat(32, _pos_9114);
    _5459 = _pos_9114 + 1;
    _5460 = Repeat(32, _5459);
    _5459 = NOVALUE;
    {
        int concat_list[3];

        concat_list[0] = _5460;
        concat_list[1] = _argtext_9283;
        concat_list[2] = _5458;
        Concat_N((object_ptr)&_argtext_9283, concat_list, 3);
    }
    DeRefDS(_5460);
    _5460 = NOVALUE;
    DeRefDS(_5458);
    _5458 = NOVALUE;
    goto L79; // [3296] 3317
L7A: 

    /** 							argtext = argtext & repeat(' ', width - length(argtext))*/
    if (IS_SEQUENCE(_argtext_9283)){
            _5462 = SEQ_PTR(_argtext_9283)->length;
    }
    else {
        _5462 = 1;
    }
    _5463 = _width_9112 - _5462;
    _5462 = NOVALUE;
    _5464 = Repeat(32, _5463);
    _5463 = NOVALUE;
    Concat((object_ptr)&_argtext_9283, _argtext_9283, _5464);
    DeRefDS(_5464);
    _5464 = NOVALUE;
L79: 
L77: 
L74: 

    /**     				result &= argtext*/
    Concat((object_ptr)&_result_9099, _result_9099, _argtext_9283);
    goto L7C; // [3325] 3341
L57: 

    /**     				if spacer then*/
    if (_spacer_9110 == 0)
    {
        goto L7D; // [3330] 3340
    }
    else{
    }

    /**     					result &= ' '*/
    Append(&_result_9099, _result_9099, 32);
L7D: 
L7C: 

    /**    				if trimming then*/
    if (_trimming_9117 == 0)
    {
        goto L7E; // [3345] 3359
    }
    else{
    }

    /**    					result = trim(result)*/
    RefDS(_result_9099);
    RefDS(_3890);
    _0 = _result_9099;
    _result_9099 = _14trim(_result_9099, _3890, 0);
    DeRefDS(_0);
L7E: 

    /**     			tend = 0*/
    _tend_9103 = 0;

    /** 		    	prevargv = currargv*/
    Ref(_currargv_9123);
    DeRef(_prevargv_9122);
    _prevargv_9122 = _currargv_9123;
L1F: 
    DeRef(_argtext_9283);
    _argtext_9283 = NOVALUE;

    /**     end while*/
    goto L2; // [3377] 60
L3: 

    /** 	return result*/
    DeRefDS(_format_pattern_9097);
    DeRef(_arg_list_9098);
    DeRef(_prevargv_9122);
    DeRef(_currargv_9123);
    DeRef(_idname_9124);
    DeRef(_envsym_9125);
    DeRefi(_envvar_9126);
    DeRef(_5438);
    _5438 = NOVALUE;
    DeRef(_5333);
    _5333 = NOVALUE;
    DeRef(_5372);
    _5372 = NOVALUE;
    DeRef(_5256);
    _5256 = NOVALUE;
    DeRef(_5274);
    _5274 = NOVALUE;
    DeRef(_5398);
    _5398 = NOVALUE;
    DeRef(_5177);
    _5177 = NOVALUE;
    DeRef(_5421);
    _5421 = NOVALUE;
    DeRef(_5432);
    _5432 = NOVALUE;
    DeRef(_5155);
    _5155 = NOVALUE;
    DeRef(_5379);
    _5379 = NOVALUE;
    DeRef(_5104);
    _5104 = NOVALUE;
    DeRef(_5238);
    _5238 = NOVALUE;
    DeRef(_5311);
    _5311 = NOVALUE;
    DeRef(_5195);
    _5195 = NOVALUE;
    DeRef(_5128);
    _5128 = NOVALUE;
    DeRef(_5430);
    _5430 = NOVALUE;
    DeRef(_5435);
    _5435 = NOVALUE;
    _5313 = NOVALUE;
    DeRef(_5408);
    _5408 = NOVALUE;
    DeRef(_5427);
    _5427 = NOVALUE;
    DeRef(_5391);
    _5391 = NOVALUE;
    DeRef(_5167);
    _5167 = NOVALUE;
    DeRef(_5343);
    _5343 = NOVALUE;
    DeRef(_5451);
    _5451 = NOVALUE;
    return _result_9099;
    ;
}



// 0x0784C510
