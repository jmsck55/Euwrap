// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int _55find_file(int _fname_44244)
{
    int _23470 = NOVALUE;
    int _23469 = NOVALUE;
    int _23468 = NOVALUE;
    int _23467 = NOVALUE;
    int _23465 = NOVALUE;
    int _23464 = NOVALUE;
    int _0, _1, _2;
    

    /** 	for i = 1 to length(inc_dirs) do*/
    _23464 = 4;
    {
        int _i_44246;
        _i_44246 = 1;
L1: 
        if (_i_44246 > 4){
            goto L2; // [10] 64
        }

        /** 		if file_exists(inc_dirs[i] & "/" & fname) then*/
        _2 = (int)SEQ_PTR(_55inc_dirs_44235);
        _23465 = (int)*(((s1_ptr)_2)->base + _i_44246);
        {
            int concat_list[3];

            concat_list[0] = _fname_44244;
            concat_list[1] = _23466;
            concat_list[2] = _23465;
            Concat_N((object_ptr)&_23467, concat_list, 3);
        }
        _23465 = NOVALUE;
        _23468 = _17file_exists(_23467);
        _23467 = NOVALUE;
        if (_23468 == 0) {
            DeRef(_23468);
            _23468 = NOVALUE;
            goto L3; // [35] 57
        }
        else {
            if (!IS_ATOM_INT(_23468) && DBL_PTR(_23468)->dbl == 0.0){
                DeRef(_23468);
                _23468 = NOVALUE;
                goto L3; // [35] 57
            }
            DeRef(_23468);
            _23468 = NOVALUE;
        }
        DeRef(_23468);
        _23468 = NOVALUE;

        /** 			return inc_dirs[i] & "/" & fname*/
        _2 = (int)SEQ_PTR(_55inc_dirs_44235);
        _23469 = (int)*(((s1_ptr)_2)->base + _i_44246);
        {
            int concat_list[3];

            concat_list[0] = _fname_44244;
            concat_list[1] = _23466;
            concat_list[2] = _23469;
            Concat_N((object_ptr)&_23470, concat_list, 3);
        }
        _23469 = NOVALUE;
        DeRefDS(_fname_44244);
        return _23470;
L3: 

        /** 	end for*/
        _i_44246 = _i_44246 + 1;
        goto L1; // [59] 17
L2: 
        ;
    }

    /** 	return 0*/
    DeRefDS(_fname_44244);
    DeRef(_23470);
    _23470 = NOVALUE;
    return 0;
    ;
}


int _55find_all_includes(int _fname_44258, int _includes_44259)
{
    int _lines_44260 = NOVALUE;
    int _m_44266 = NOVALUE;
    int _full_fname_44271 = NOVALUE;
    int _23483 = NOVALUE;
    int _23481 = NOVALUE;
    int _23479 = NOVALUE;
    int _23478 = NOVALUE;
    int _23476 = NOVALUE;
    int _23475 = NOVALUE;
    int _23473 = NOVALUE;
    int _23472 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence lines = read_lines(fname)*/
    RefDS(_fname_44258);
    _0 = _lines_44260;
    _lines_44260 = _8read_lines(_fname_44258);
    DeRef(_0);

    /** 	for i = 1 to length(lines) do*/
    if (IS_SEQUENCE(_lines_44260)){
            _23472 = SEQ_PTR(_lines_44260)->length;
    }
    else {
        _23472 = 1;
    }
    {
        int _i_44264;
        _i_44264 = 1;
L1: 
        if (_i_44264 > _23472){
            goto L2; // [18] 113
        }

        /** 		object m = regex:matches(re_include, lines[i])*/
        _2 = (int)SEQ_PTR(_lines_44260);
        _23473 = (int)*(((s1_ptr)_2)->base + _i_44264);
        Ref(_55re_include_44232);
        Ref(_23473);
        _0 = _m_44266;
        _m_44266 = _51matches(_55re_include_44232, _23473, 1, 0);
        DeRef(_0);
        _23473 = NOVALUE;

        /** 		if sequence(m) then*/
        _23475 = IS_SEQUENCE(_m_44266);
        if (_23475 == 0)
        {
            _23475 = NOVALUE;
            goto L3; // [45] 102
        }
        else{
            _23475 = NOVALUE;
        }

        /** 			object full_fname = find_file(m[3])*/
        _2 = (int)SEQ_PTR(_m_44266);
        _23476 = (int)*(((s1_ptr)_2)->base + 3);
        Ref(_23476);
        _0 = _full_fname_44271;
        _full_fname_44271 = _55find_file(_23476);
        DeRef(_0);
        _23476 = NOVALUE;

        /** 			if sequence(full_fname) then*/
        _23478 = IS_SEQUENCE(_full_fname_44271);
        if (_23478 == 0)
        {
            _23478 = NOVALUE;
            goto L4; // [63] 101
        }
        else{
            _23478 = NOVALUE;
        }

        /** 				if eu:find(full_fname, includes) = 0 then*/
        _23479 = find_from(_full_fname_44271, _includes_44259, 1);
        if (_23479 != 0)
        goto L5; // [73] 100

        /** 					includes &= { full_fname }*/
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        Ref(_full_fname_44271);
        *((int *)(_2+4)) = _full_fname_44271;
        _23481 = MAKE_SEQ(_1);
        Concat((object_ptr)&_includes_44259, _includes_44259, _23481);
        DeRefDS(_23481);
        _23481 = NOVALUE;

        /** 					includes = find_all_includes(full_fname, includes)*/
        RefDS(_includes_44259);
        DeRef(_23483);
        _23483 = _includes_44259;
        Ref(_full_fname_44271);
        _0 = _includes_44259;
        _includes_44259 = _55find_all_includes(_full_fname_44271, _23483);
        DeRefDS(_0);
        _23483 = NOVALUE;
L5: 
L4: 
L3: 
        DeRef(_full_fname_44271);
        _full_fname_44271 = NOVALUE;
        DeRef(_m_44266);
        _m_44266 = NOVALUE;

        /** 	end for*/
        _i_44264 = _i_44264 + 1;
        goto L1; // [108] 25
L2: 
        ;
    }

    /** 	return includes*/
    DeRefDS(_fname_44258);
    DeRef(_lines_44260);
    return _includes_44259;
    ;
}


int _55quick_has_changed(int _fname_44285)
{
    int _d1_44286 = NOVALUE;
    int _all_files_44296 = NOVALUE;
    int _d2_44302 = NOVALUE;
    int _diff_2__tmp_at88_44312 = NOVALUE;
    int _diff_1__tmp_at88_44311 = NOVALUE;
    int _diff_inlined_diff_at_88_44310 = NOVALUE;
    int _23495 = NOVALUE;
    int _23493 = NOVALUE;
    int _23492 = NOVALUE;
    int _23490 = NOVALUE;
    int _23489 = NOVALUE;
    int _23487 = NOVALUE;
    int _23485 = NOVALUE;
    int _0, _1, _2;
    

    /** 	object d1 = file_timestamp(output_dir & filebase(fname) & ".bld")*/
    RefDS(_fname_44285);
    _23485 = _17filebase(_fname_44285);
    {
        int concat_list[3];

        concat_list[0] = _23486;
        concat_list[1] = _23485;
        concat_list[2] = _57output_dir_41689;
        Concat_N((object_ptr)&_23487, concat_list, 3);
    }
    DeRef(_23485);
    _23485 = NOVALUE;
    _0 = _d1_44286;
    _d1_44286 = _17file_timestamp(_23487);
    DeRef(_0);
    _23487 = NOVALUE;

    /** 	if atom(d1) then*/
    _23489 = IS_ATOM(_d1_44286);
    if (_23489 == 0)
    {
        _23489 = NOVALUE;
        goto L1; // [26] 36
    }
    else{
        _23489 = NOVALUE;
    }

    /** 		return 1*/
    DeRefDS(_fname_44285);
    DeRef(_d1_44286);
    DeRef(_all_files_44296);
    return 1;
L1: 

    /** 	sequence all_files = append(find_all_includes(fname), fname)*/
    RefDS(_fname_44285);
    RefDS(_22023);
    _23490 = _55find_all_includes(_fname_44285, _22023);
    RefDS(_fname_44285);
    Append(&_all_files_44296, _23490, _fname_44285);
    DeRef(_23490);
    _23490 = NOVALUE;

    /** 	for i = 1 to length(all_files) do*/
    if (IS_SEQUENCE(_all_files_44296)){
            _23492 = SEQ_PTR(_all_files_44296)->length;
    }
    else {
        _23492 = 1;
    }
    {
        int _i_44300;
        _i_44300 = 1;
L2: 
        if (_i_44300 > _23492){
            goto L3; // [52] 123
        }

        /** 		object d2 = file_timestamp(all_files[i])*/
        _2 = (int)SEQ_PTR(_all_files_44296);
        _23493 = (int)*(((s1_ptr)_2)->base + _i_44300);
        Ref(_23493);
        _0 = _d2_44302;
        _d2_44302 = _17file_timestamp(_23493);
        DeRef(_0);
        _23493 = NOVALUE;

        /** 		if atom(d2) then*/
        _23495 = IS_ATOM(_d2_44302);
        if (_23495 == 0)
        {
            _23495 = NOVALUE;
            goto L4; // [74] 84
        }
        else{
            _23495 = NOVALUE;
        }

        /** 			return 1*/
        DeRef(_d2_44302);
        DeRefDS(_fname_44285);
        DeRef(_d1_44286);
        DeRefDS(_all_files_44296);
        return 1;
L4: 

        /** 		if datetime:diff(d1, d2) > 0 then*/

        /** 	return datetimeToSeconds(dt2) - datetimeToSeconds(dt1)*/
        Ref(_d2_44302);
        _0 = _diff_1__tmp_at88_44311;
        _diff_1__tmp_at88_44311 = _18datetimeToSeconds(_d2_44302);
        DeRef(_0);
        Ref(_d1_44286);
        _0 = _diff_2__tmp_at88_44312;
        _diff_2__tmp_at88_44312 = _18datetimeToSeconds(_d1_44286);
        DeRef(_0);
        DeRef(_diff_inlined_diff_at_88_44310);
        if (IS_ATOM_INT(_diff_1__tmp_at88_44311) && IS_ATOM_INT(_diff_2__tmp_at88_44312)) {
            _diff_inlined_diff_at_88_44310 = _diff_1__tmp_at88_44311 - _diff_2__tmp_at88_44312;
            if ((long)((unsigned long)_diff_inlined_diff_at_88_44310 +(unsigned long) HIGH_BITS) >= 0){
                _diff_inlined_diff_at_88_44310 = NewDouble((double)_diff_inlined_diff_at_88_44310);
            }
        }
        else {
            _diff_inlined_diff_at_88_44310 = binary_op(MINUS, _diff_1__tmp_at88_44311, _diff_2__tmp_at88_44312);
        }
        DeRef(_diff_1__tmp_at88_44311);
        _diff_1__tmp_at88_44311 = NOVALUE;
        DeRef(_diff_2__tmp_at88_44312);
        _diff_2__tmp_at88_44312 = NOVALUE;
        if (binary_op_a(LESSEQ, _diff_inlined_diff_at_88_44310, 0)){
            goto L5; // [103] 114
        }

        /** 			return 1*/
        DeRef(_d2_44302);
        DeRefDS(_fname_44285);
        DeRef(_d1_44286);
        DeRef(_all_files_44296);
        return 1;
L5: 
        DeRef(_d2_44302);
        _d2_44302 = NOVALUE;

        /** 	end for*/
        _i_44300 = _i_44300 + 1;
        goto L2; // [118] 59
L3: 
        ;
    }

    /** 	return 0*/
    DeRefDS(_fname_44285);
    DeRef(_d1_44286);
    DeRef(_all_files_44296);
    return 0;
    ;
}


void _55update_checksum(int _raw_data_44354)
{
    int _23503 = NOVALUE;
    int _0, _1, _2;
    

    /** 	cfile_check = xor_bits(cfile_check, hash( raw_data, stdhash:HSIEH32))*/
    _23503 = calc_hash(_raw_data_44354, -5);
    _0 = _55cfile_check_44338;
    if (IS_ATOM_INT(_55cfile_check_44338) && IS_ATOM_INT(_23503)) {
        {unsigned long tu;
             tu = (unsigned long)_55cfile_check_44338 ^ (unsigned long)_23503;
             _55cfile_check_44338 = MAKE_UINT(tu);
        }
    }
    else {
        if (IS_ATOM_INT(_55cfile_check_44338)) {
            temp_d.dbl = (double)_55cfile_check_44338;
            _55cfile_check_44338 = Dxor_bits(&temp_d, DBL_PTR(_23503));
        }
        else {
            if (IS_ATOM_INT(_23503)) {
                temp_d.dbl = (double)_23503;
                _55cfile_check_44338 = Dxor_bits(DBL_PTR(_55cfile_check_44338), &temp_d);
            }
            else
            _55cfile_check_44338 = Dxor_bits(DBL_PTR(_55cfile_check_44338), DBL_PTR(_23503));
        }
    }
    DeRef(_0);
    DeRef(_23503);
    _23503 = NOVALUE;

    /** end procedure*/
    DeRef(_raw_data_44354);
    return;
    ;
}


void _55write_checksum(int _file_44359)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_file_44359)) {
        _1 = (long)(DBL_PTR(_file_44359)->dbl);
        DeRefDS(_file_44359);
        _file_44359 = _1;
    }

    /** 	printf( file, "\n// 0x%08x\n", cfile_check )*/
    EPrintf(_file_44359, _23505, _55cfile_check_44338);

    /** 	cfile_check = 0*/
    DeRef(_55cfile_check_44338);
    _55cfile_check_44338 = 0;

    /** end procedure*/
    return;
    ;
}


int _55find_file_element(int _needle_44363, int _files_44364)
{
    int _23521 = NOVALUE;
    int _23520 = NOVALUE;
    int _23519 = NOVALUE;
    int _23518 = NOVALUE;
    int _23517 = NOVALUE;
    int _23516 = NOVALUE;
    int _23515 = NOVALUE;
    int _23514 = NOVALUE;
    int _23513 = NOVALUE;
    int _23512 = NOVALUE;
    int _23511 = NOVALUE;
    int _23510 = NOVALUE;
    int _23509 = NOVALUE;
    int _23508 = NOVALUE;
    int _23507 = NOVALUE;
    int _23506 = NOVALUE;
    int _0, _1, _2;
    

    /** 	for j = 1 to length(files) do*/
    if (IS_SEQUENCE(_files_44364)){
            _23506 = SEQ_PTR(_files_44364)->length;
    }
    else {
        _23506 = 1;
    }
    {
        int _j_44366;
        _j_44366 = 1;
L1: 
        if (_j_44366 > _23506){
            goto L2; // [10] 50
        }

        /** 		if equal(files[j][D_NAME],needle) then*/
        _2 = (int)SEQ_PTR(_files_44364);
        _23507 = (int)*(((s1_ptr)_2)->base + _j_44366);
        _2 = (int)SEQ_PTR(_23507);
        _23508 = (int)*(((s1_ptr)_2)->base + 1);
        _23507 = NOVALUE;
        if (_23508 == _needle_44363)
        _23509 = 1;
        else if (IS_ATOM_INT(_23508) && IS_ATOM_INT(_needle_44363))
        _23509 = 0;
        else
        _23509 = (compare(_23508, _needle_44363) == 0);
        _23508 = NOVALUE;
        if (_23509 == 0)
        {
            _23509 = NOVALUE;
            goto L3; // [33] 43
        }
        else{
            _23509 = NOVALUE;
        }

        /** 			return j*/
        DeRefDS(_needle_44363);
        DeRefDS(_files_44364);
        return _j_44366;
L3: 

        /** 	end for*/
        _j_44366 = _j_44366 + 1;
        goto L1; // [45] 17
L2: 
        ;
    }

    /** 	for j = 1 to length(files) do*/
    if (IS_SEQUENCE(_files_44364)){
            _23510 = SEQ_PTR(_files_44364)->length;
    }
    else {
        _23510 = 1;
    }
    {
        int _j_44374;
        _j_44374 = 1;
L4: 
        if (_j_44374 > _23510){
            goto L5; // [55] 103
        }

        /** 		if equal(lower(files[j][D_NAME]),lower(needle)) then*/
        _2 = (int)SEQ_PTR(_files_44364);
        _23511 = (int)*(((s1_ptr)_2)->base + _j_44374);
        _2 = (int)SEQ_PTR(_23511);
        _23512 = (int)*(((s1_ptr)_2)->base + 1);
        _23511 = NOVALUE;
        Ref(_23512);
        _23513 = _14lower(_23512);
        _23512 = NOVALUE;
        RefDS(_needle_44363);
        _23514 = _14lower(_needle_44363);
        if (_23513 == _23514)
        _23515 = 1;
        else if (IS_ATOM_INT(_23513) && IS_ATOM_INT(_23514))
        _23515 = 0;
        else
        _23515 = (compare(_23513, _23514) == 0);
        DeRef(_23513);
        _23513 = NOVALUE;
        DeRef(_23514);
        _23514 = NOVALUE;
        if (_23515 == 0)
        {
            _23515 = NOVALUE;
            goto L6; // [86] 96
        }
        else{
            _23515 = NOVALUE;
        }

        /** 			return j*/
        DeRefDS(_needle_44363);
        DeRefDS(_files_44364);
        return _j_44374;
L6: 

        /** 	end for*/
        _j_44374 = _j_44374 + 1;
        goto L4; // [98] 62
L5: 
        ;
    }

    /** 	for j = 1 to length(files) do*/
    if (IS_SEQUENCE(_files_44364)){
            _23516 = SEQ_PTR(_files_44364)->length;
    }
    else {
        _23516 = 1;
    }
    {
        int _j_44386;
        _j_44386 = 1;
L7: 
        if (_j_44386 > _23516){
            goto L8; // [108] 156
        }

        /** 		if equal(lower(files[j][D_ALTNAME]),lower(needle)) then*/
        _2 = (int)SEQ_PTR(_files_44364);
        _23517 = (int)*(((s1_ptr)_2)->base + _j_44386);
        _2 = (int)SEQ_PTR(_23517);
        _23518 = (int)*(((s1_ptr)_2)->base + 11);
        _23517 = NOVALUE;
        Ref(_23518);
        _23519 = _14lower(_23518);
        _23518 = NOVALUE;
        RefDS(_needle_44363);
        _23520 = _14lower(_needle_44363);
        if (_23519 == _23520)
        _23521 = 1;
        else if (IS_ATOM_INT(_23519) && IS_ATOM_INT(_23520))
        _23521 = 0;
        else
        _23521 = (compare(_23519, _23520) == 0);
        DeRef(_23519);
        _23519 = NOVALUE;
        DeRef(_23520);
        _23520 = NOVALUE;
        if (_23521 == 0)
        {
            _23521 = NOVALUE;
            goto L9; // [139] 149
        }
        else{
            _23521 = NOVALUE;
        }

        /** 			return j*/
        DeRefDS(_needle_44363);
        DeRefDS(_files_44364);
        return _j_44386;
L9: 

        /** 	end for*/
        _j_44386 = _j_44386 + 1;
        goto L7; // [151] 115
L8: 
        ;
    }

    /** 	return 0*/
    DeRefDS(_needle_44363);
    DeRefDS(_files_44364);
    return 0;
    ;
}


int _55adjust_for_command_line_passing(int _long_path_44407)
{
    int _slash_44408 = NOVALUE;
    int _longs_44416 = NOVALUE;
    int _short_path_44422 = NOVALUE;
    int _files_44428 = NOVALUE;
    int _file_location_44431 = NOVALUE;
    int _23560 = NOVALUE;
    int _23559 = NOVALUE;
    int _23557 = NOVALUE;
    int _23556 = NOVALUE;
    int _23554 = NOVALUE;
    int _23553 = NOVALUE;
    int _23551 = NOVALUE;
    int _23550 = NOVALUE;
    int _23547 = NOVALUE;
    int _23546 = NOVALUE;
    int _23544 = NOVALUE;
    int _23543 = NOVALUE;
    int _23542 = NOVALUE;
    int _23541 = NOVALUE;
    int _23540 = NOVALUE;
    int _23538 = NOVALUE;
    int _23537 = NOVALUE;
    int _23535 = NOVALUE;
    int _23533 = NOVALUE;
    int _23531 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if compiler_type = COMPILER_GCC then*/
    if (_55compiler_type_44322 != 1)
    goto L1; // [7] 19

    /** 		slash = '/'*/
    _slash_44408 = 47;
    goto L2; // [16] 45
L1: 

    /** 	elsif compiler_type = COMPILER_WATCOM then*/
    if (_55compiler_type_44322 != 2)
    goto L3; // [23] 35

    /** 		slash = '\\'*/
    _slash_44408 = 92;
    goto L2; // [32] 45
L3: 

    /** 		slash = SLASH*/
    _slash_44408 = 92;
L2: 

    /** 	ifdef UNIX then*/

    /** 		long_path = regex:find_replace(quote_pattern, long_path, "")*/
    Ref(_55quote_pattern_44400);
    RefDS(_long_path_44407);
    RefDS(_22023);
    _0 = _long_path_44407;
    _long_path_44407 = _51find_replace(_55quote_pattern_44400, _long_path_44407, _22023, 1, 0);
    DeRefDS(_0);

    /** 		sequence longs = split( slash_pattern, long_path )*/
    Ref(_55slash_pattern_44397);
    RefDS(_long_path_44407);
    _0 = _longs_44416;
    _longs_44416 = _51split(_55slash_pattern_44397, _long_path_44407, 1, 0);
    DeRef(_0);

    /** 		if length(longs)=0 then*/
    if (IS_SEQUENCE(_longs_44416)){
            _23531 = SEQ_PTR(_longs_44416)->length;
    }
    else {
        _23531 = 1;
    }
    if (_23531 != 0)
    goto L4; // [79] 90

    /** 			return long_path*/
    DeRefDS(_longs_44416);
    DeRef(_short_path_44422);
    return _long_path_44407;
L4: 

    /** 		sequence short_path = longs[1] & slash*/
    _2 = (int)SEQ_PTR(_longs_44416);
    _23533 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_23533) && IS_ATOM(_slash_44408)) {
        Append(&_short_path_44422, _23533, _slash_44408);
    }
    else if (IS_ATOM(_23533) && IS_SEQUENCE(_slash_44408)) {
    }
    else {
        Concat((object_ptr)&_short_path_44422, _23533, _slash_44408);
        _23533 = NOVALUE;
    }
    _23533 = NOVALUE;

    /** 		for i = 2 to length(longs) do*/
    if (IS_SEQUENCE(_longs_44416)){
            _23535 = SEQ_PTR(_longs_44416)->length;
    }
    else {
        _23535 = 1;
    }
    {
        int _i_44426;
        _i_44426 = 2;
L5: 
        if (_i_44426 > _23535){
            goto L6; // [107] 266
        }

        /** 			object files = dir(short_path)*/
        RefDS(_short_path_44422);
        _0 = _files_44428;
        _files_44428 = _17dir(_short_path_44422);
        DeRef(_0);

        /** 			integer file_location = 0*/
        _file_location_44431 = 0;

        /** 			if sequence(files) then*/
        _23537 = IS_SEQUENCE(_files_44428);
        if (_23537 == 0)
        {
            _23537 = NOVALUE;
            goto L7; // [130] 147
        }
        else{
            _23537 = NOVALUE;
        }

        /** 				file_location = find_file_element(longs[i], files)*/
        _2 = (int)SEQ_PTR(_longs_44416);
        _23538 = (int)*(((s1_ptr)_2)->base + _i_44426);
        Ref(_23538);
        Ref(_files_44428);
        _file_location_44431 = _55find_file_element(_23538, _files_44428);
        _23538 = NOVALUE;
        if (!IS_ATOM_INT(_file_location_44431)) {
            _1 = (long)(DBL_PTR(_file_location_44431)->dbl);
            DeRefDS(_file_location_44431);
            _file_location_44431 = _1;
        }
L7: 

        /** 			if file_location then*/
        if (_file_location_44431 == 0)
        {
            goto L8; // [149] 215
        }
        else{
        }

        /** 				if sequence(files[file_location][D_ALTNAME]) then*/
        _2 = (int)SEQ_PTR(_files_44428);
        _23540 = (int)*(((s1_ptr)_2)->base + _file_location_44431);
        _2 = (int)SEQ_PTR(_23540);
        _23541 = (int)*(((s1_ptr)_2)->base + 11);
        _23540 = NOVALUE;
        _23542 = IS_SEQUENCE(_23541);
        _23541 = NOVALUE;
        if (_23542 == 0)
        {
            _23542 = NOVALUE;
            goto L9; // [167] 189
        }
        else{
            _23542 = NOVALUE;
        }

        /** 					short_path &= files[file_location][D_ALTNAME]*/
        _2 = (int)SEQ_PTR(_files_44428);
        _23543 = (int)*(((s1_ptr)_2)->base + _file_location_44431);
        _2 = (int)SEQ_PTR(_23543);
        _23544 = (int)*(((s1_ptr)_2)->base + 11);
        _23543 = NOVALUE;
        if (IS_SEQUENCE(_short_path_44422) && IS_ATOM(_23544)) {
            Ref(_23544);
            Append(&_short_path_44422, _short_path_44422, _23544);
        }
        else if (IS_ATOM(_short_path_44422) && IS_SEQUENCE(_23544)) {
        }
        else {
            Concat((object_ptr)&_short_path_44422, _short_path_44422, _23544);
        }
        _23544 = NOVALUE;
        goto LA; // [186] 206
L9: 

        /** 					short_path &= files[file_location][D_NAME]*/
        _2 = (int)SEQ_PTR(_files_44428);
        _23546 = (int)*(((s1_ptr)_2)->base + _file_location_44431);
        _2 = (int)SEQ_PTR(_23546);
        _23547 = (int)*(((s1_ptr)_2)->base + 1);
        _23546 = NOVALUE;
        if (IS_SEQUENCE(_short_path_44422) && IS_ATOM(_23547)) {
            Ref(_23547);
            Append(&_short_path_44422, _short_path_44422, _23547);
        }
        else if (IS_ATOM(_short_path_44422) && IS_SEQUENCE(_23547)) {
        }
        else {
            Concat((object_ptr)&_short_path_44422, _short_path_44422, _23547);
        }
        _23547 = NOVALUE;
LA: 

        /** 				short_path &= slash*/
        Append(&_short_path_44422, _short_path_44422, _slash_44408);
        goto LB; // [212] 257
L8: 

        /** 				if not find(' ',longs[i]) then*/
        _2 = (int)SEQ_PTR(_longs_44416);
        _23550 = (int)*(((s1_ptr)_2)->base + _i_44426);
        _23551 = find_from(32, _23550, 1);
        _23550 = NOVALUE;
        if (_23551 != 0)
        goto LC; // [226] 250
        _23551 = NOVALUE;

        /** 					short_path &= longs[i] & slash*/
        _2 = (int)SEQ_PTR(_longs_44416);
        _23553 = (int)*(((s1_ptr)_2)->base + _i_44426);
        if (IS_SEQUENCE(_23553) && IS_ATOM(_slash_44408)) {
            Append(&_23554, _23553, _slash_44408);
        }
        else if (IS_ATOM(_23553) && IS_SEQUENCE(_slash_44408)) {
        }
        else {
            Concat((object_ptr)&_23554, _23553, _slash_44408);
            _23553 = NOVALUE;
        }
        _23553 = NOVALUE;
        Concat((object_ptr)&_short_path_44422, _short_path_44422, _23554);
        DeRefDS(_23554);
        _23554 = NOVALUE;

        /** 					continue*/
        DeRef(_files_44428);
        _files_44428 = NOVALUE;
        goto LD; // [247] 261
LC: 

        /** 				return 0*/
        DeRef(_files_44428);
        DeRefDS(_long_path_44407);
        DeRef(_longs_44416);
        DeRef(_short_path_44422);
        return 0;
LB: 
        DeRef(_files_44428);
        _files_44428 = NOVALUE;

        /** 		end for -- i*/
LD: 
        _i_44426 = _i_44426 + 1;
        goto L5; // [261] 114
L6: 
        ;
    }

    /** 		if short_path[$] = slash then*/
    if (IS_SEQUENCE(_short_path_44422)){
            _23556 = SEQ_PTR(_short_path_44422)->length;
    }
    else {
        _23556 = 1;
    }
    _2 = (int)SEQ_PTR(_short_path_44422);
    _23557 = (int)*(((s1_ptr)_2)->base + _23556);
    if (binary_op_a(NOTEQ, _23557, _slash_44408)){
        _23557 = NOVALUE;
        goto LE; // [275] 294
    }
    _23557 = NOVALUE;

    /** 			short_path = short_path[1..$-1]*/
    if (IS_SEQUENCE(_short_path_44422)){
            _23559 = SEQ_PTR(_short_path_44422)->length;
    }
    else {
        _23559 = 1;
    }
    _23560 = _23559 - 1;
    _23559 = NOVALUE;
    rhs_slice_target = (object_ptr)&_short_path_44422;
    RHS_Slice(_short_path_44422, 1, _23560);
LE: 

    /** 		return short_path*/
    DeRefDS(_long_path_44407);
    DeRef(_longs_44416);
    DeRef(_23560);
    _23560 = NOVALUE;
    return _short_path_44422;
    ;
}


int _55adjust_for_build_file(int _long_path_44469)
{
    int _short_path_44470 = NOVALUE;
    int _23568 = NOVALUE;
    int _23567 = NOVALUE;
    int _23566 = NOVALUE;
    int _23565 = NOVALUE;
    int _23564 = NOVALUE;
    int _23563 = NOVALUE;
    int _0, _1, _2;
    

    /**     object short_path = adjust_for_command_line_passing(long_path)*/
    RefDS(_long_path_44469);
    _0 = _short_path_44470;
    _short_path_44470 = _55adjust_for_command_line_passing(_long_path_44469);
    DeRef(_0);

    /**     if atom(short_path) then*/
    _23563 = IS_ATOM(_short_path_44470);
    if (_23563 == 0)
    {
        _23563 = NOVALUE;
        goto L1; // [14] 24
    }
    else{
        _23563 = NOVALUE;
    }

    /**     	return short_path*/
    DeRefDS(_long_path_44469);
    return _short_path_44470;
L1: 

    /** 	if compiler_type = COMPILER_GCC and build_system_type != BUILD_DIRECT and TWINDOWS then*/
    _23564 = (_55compiler_type_44322 == 1);
    if (_23564 == 0) {
        _23565 = 0;
        goto L2; // [32] 46
    }
    _23566 = (_55build_system_type_44318 != 3);
    _23565 = (_23566 != 0);
L2: 
    if (_23565 == 0) {
        goto L3; // [46] 69
    }
    if (_40TWINDOWS_16388 == 0)
    {
        goto L3; // [53] 69
    }
    else{
    }

    /** 		return windows_to_mingw_path(short_path)*/
    Ref(_short_path_44470);
    _23568 = _55windows_to_mingw_path(_short_path_44470);
    DeRefDS(_long_path_44469);
    DeRef(_short_path_44470);
    DeRef(_23564);
    _23564 = NOVALUE;
    DeRef(_23566);
    _23566 = NOVALUE;
    return _23568;
    goto L4; // [66] 76
L3: 

    /** 		return short_path*/
    DeRefDS(_long_path_44469);
    DeRef(_23564);
    _23564 = NOVALUE;
    DeRef(_23566);
    _23566 = NOVALUE;
    DeRef(_23568);
    _23568 = NOVALUE;
    return _short_path_44470;
L4: 
    ;
}


int _55setup_build()
{
    int _c_exe_44485 = NOVALUE;
    int _c_flags_44486 = NOVALUE;
    int _l_exe_44487 = NOVALUE;
    int _l_flags_44488 = NOVALUE;
    int _obj_ext_44489 = NOVALUE;
    int _exe_ext_44490 = NOVALUE;
    int _l_flags_begin_44491 = NOVALUE;
    int _rc_comp_44492 = NOVALUE;
    int _l_names_44493 = NOVALUE;
    int _l_ext_44494 = NOVALUE;
    int _t_slash_44495 = NOVALUE;
    int _eudir_44515 = NOVALUE;
    int _compile_dir_44573 = NOVALUE;
    int _23695 = NOVALUE;
    int _23694 = NOVALUE;
    int _23693 = NOVALUE;
    int _23690 = NOVALUE;
    int _23689 = NOVALUE;
    int _23686 = NOVALUE;
    int _23685 = NOVALUE;
    int _23678 = NOVALUE;
    int _23677 = NOVALUE;
    int _23672 = NOVALUE;
    int _23671 = NOVALUE;
    int _23666 = NOVALUE;
    int _23665 = NOVALUE;
    int _23662 = NOVALUE;
    int _23661 = NOVALUE;
    int _23651 = NOVALUE;
    int _23650 = NOVALUE;
    int _23635 = NOVALUE;
    int _23634 = NOVALUE;
    int _23630 = NOVALUE;
    int _23628 = NOVALUE;
    int _23627 = NOVALUE;
    int _23626 = NOVALUE;
    int _23625 = NOVALUE;
    int _23613 = NOVALUE;
    int _23612 = NOVALUE;
    int _23609 = NOVALUE;
    int _23597 = NOVALUE;
    int _23593 = NOVALUE;
    int _23590 = NOVALUE;
    int _23589 = NOVALUE;
    int _23588 = NOVALUE;
    int _23585 = NOVALUE;
    int _23584 = NOVALUE;
    int _23583 = NOVALUE;
    int _23580 = NOVALUE;
    int _23576 = NOVALUE;
    int _23569 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence c_exe   = "", c_flags = "", l_exe   = "", l_flags = "", obj_ext = "",*/
    RefDS(_22023);
    DeRefi(_c_exe_44485);
    _c_exe_44485 = _22023;
    RefDS(_22023);
    DeRef(_c_flags_44486);
    _c_flags_44486 = _22023;
    RefDS(_22023);
    DeRefi(_l_exe_44487);
    _l_exe_44487 = _22023;
    RefDS(_22023);
    DeRef(_l_flags_44488);
    _l_flags_44488 = _22023;
    RefDS(_22023);
    DeRefi(_obj_ext_44489);
    _obj_ext_44489 = _22023;

    /** 		exe_ext = "", l_flags_begin = "", rc_comp = "", l_names, l_ext, t_slash*/
    RefDS(_22023);
    DeRefi(_exe_ext_44490);
    _exe_ext_44490 = _22023;
    RefDS(_22023);
    DeRefi(_l_flags_begin_44491);
    _l_flags_begin_44491 = _22023;
    RefDS(_22023);
    DeRef(_rc_comp_44492);
    _rc_comp_44492 = _22023;

    /** 	if length(user_library) = 0 then*/
    if (IS_SEQUENCE(_57user_library_41688)){
            _23569 = SEQ_PTR(_57user_library_41688)->length;
    }
    else {
        _23569 = 1;
    }
    if (_23569 != 0)
    goto L1; // [52] 257

    /** 		if debug_option then*/
    if (_57debug_option_41686 == 0)
    {
        goto L2; // [60] 72
    }
    else{
    }

    /** 			l_names = { "eudbg", "eu" }*/
    RefDS(_23572);
    RefDS(_23571);
    DeRef(_l_names_44493);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _23571;
    ((int *)_2)[2] = _23572;
    _l_names_44493 = MAKE_SEQ(_1);
    goto L3; // [69] 79
L2: 

    /** 			l_names = { "eu", "eudbg" }*/
    RefDS(_23571);
    RefDS(_23572);
    DeRef(_l_names_44493);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _23572;
    ((int *)_2)[2] = _23571;
    _l_names_44493 = MAKE_SEQ(_1);
L3: 

    /** 		if TUNIX or compiler_type = COMPILER_GCC then*/
    if (_40TUNIX_16392 != 0) {
        goto L4; // [83] 98
    }
    _23576 = (_55compiler_type_44322 == 1);
    if (_23576 == 0)
    {
        DeRef(_23576);
        _23576 = NOVALUE;
        goto L5; // [94] 115
    }
    else{
        DeRef(_23576);
        _23576 = NOVALUE;
    }
L4: 

    /** 			l_ext = "a"*/
    RefDS(_22261);
    DeRefi(_l_ext_44494);
    _l_ext_44494 = _22261;

    /** 			t_slash = "/"*/
    RefDS(_23466);
    DeRefi(_t_slash_44495);
    _t_slash_44495 = _23466;
    goto L6; // [112] 138
L5: 

    /** 		elsif TWINDOWS then*/
    if (_40TWINDOWS_16388 == 0)
    {
        goto L7; // [119] 137
    }
    else{
    }

    /** 			l_ext = "lib"*/
    RefDS(_23577);
    DeRefi(_l_ext_44494);
    _l_ext_44494 = _23577;

    /** 			t_slash = "\\"*/
    RefDS(_23578);
    DeRefi(_t_slash_44495);
    _t_slash_44495 = _23578;
L7: 
L6: 

    /** 		object eudir = get_eucompiledir()*/
    _0 = _eudir_44515;
    _eudir_44515 = _57get_eucompiledir();
    DeRef(_0);

    /** 		if not file_exists(eudir) then*/
    Ref(_eudir_44515);
    _23580 = _17file_exists(_eudir_44515);
    if (IS_ATOM_INT(_23580)) {
        if (_23580 != 0){
            DeRef(_23580);
            _23580 = NOVALUE;
            goto L8; // [149] 170
        }
    }
    else {
        if (DBL_PTR(_23580)->dbl != 0.0){
            DeRef(_23580);
            _23580 = NOVALUE;
            goto L8; // [149] 170
        }
    }
    DeRef(_23580);
    _23580 = NOVALUE;

    /** 			printf(2,"Supplied directory \'%s\' is not a valid EUDIR\n",{get_eucompiledir()})*/
    _23583 = _57get_eucompiledir();
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _23583;
    _23584 = MAKE_SEQ(_1);
    _23583 = NOVALUE;
    EPrintf(2, _23582, _23584);
    DeRefDS(_23584);
    _23584 = NOVALUE;

    /** 			abort(1)*/
    UserCleanup(1);
L8: 

    /** 		for tk = 1 to length(l_names) label "translation kind" do*/
    _23585 = 2;
    {
        int _tk_44527;
        _tk_44527 = 1;
L9: 
        if (_tk_44527 > 2){
            goto LA; // [177] 256
        }

        /** 			user_library = eudir & sprintf("%sbin%s%s.%s",{t_slash, t_slash, l_names[tk],l_ext})*/
        _2 = (int)SEQ_PTR(_l_names_44493);
        _23588 = (int)*(((s1_ptr)_2)->base + _tk_44527);
        _1 = NewS1(4);
        _2 = (int)((s1_ptr)_1)->base;
        RefDSn(_t_slash_44495, 2);
        *((int *)(_2+4)) = _t_slash_44495;
        *((int *)(_2+8)) = _t_slash_44495;
        RefDS(_23588);
        *((int *)(_2+12)) = _23588;
        RefDS(_l_ext_44494);
        *((int *)(_2+16)) = _l_ext_44494;
        _23589 = MAKE_SEQ(_1);
        _23588 = NOVALUE;
        _23590 = EPrintf(-9999999, _23587, _23589);
        DeRefDS(_23589);
        _23589 = NOVALUE;
        if (IS_SEQUENCE(_eudir_44515) && IS_ATOM(_23590)) {
        }
        else if (IS_ATOM(_eudir_44515) && IS_SEQUENCE(_23590)) {
            Ref(_eudir_44515);
            Prepend(&_57user_library_41688, _23590, _eudir_44515);
        }
        else {
            Concat((object_ptr)&_57user_library_41688, _eudir_44515, _23590);
        }
        DeRefDS(_23590);
        _23590 = NOVALUE;

        /** 			if TUNIX or compiler_type = COMPILER_GCC then*/
        if (_40TUNIX_16392 != 0) {
            goto LB; // [215] 230
        }
        _23593 = (_55compiler_type_44322 == 1);
        if (_23593 == 0)
        {
            DeRef(_23593);
            _23593 = NOVALUE;
            goto LC; // [226] 233
        }
        else{
            DeRef(_23593);
            _23593 = NOVALUE;
        }
LB: 

        /** 				ifdef UNIX then*/
LC: 

        /** 			if file_exists(user_library) then*/
        RefDS(_57user_library_41688);
        _23597 = _17file_exists(_57user_library_41688);
        if (_23597 == 0) {
            DeRef(_23597);
            _23597 = NOVALUE;
            goto LD; // [241] 249
        }
        else {
            if (!IS_ATOM_INT(_23597) && DBL_PTR(_23597)->dbl == 0.0){
                DeRef(_23597);
                _23597 = NOVALUE;
                goto LD; // [241] 249
            }
            DeRef(_23597);
            _23597 = NOVALUE;
        }
        DeRef(_23597);
        _23597 = NOVALUE;

        /** 				exit "translation kind"*/
        goto LA; // [246] 256
LD: 

        /** 		end for -- tk*/
        _tk_44527 = _tk_44527 + 1;
        goto L9; // [251] 184
LA: 
        ;
    }
L1: 
    DeRef(_eudir_44515);
    _eudir_44515 = NOVALUE;

    /** 	user_library = adjust_for_build_file(user_library)*/
    RefDS(_57user_library_41688);
    _0 = _55adjust_for_build_file(_57user_library_41688);
    DeRefDS(_57user_library_41688);
    _57user_library_41688 = _0;

    /** 	if TWINDOWS then*/
    if (_40TWINDOWS_16388 == 0)
    {
        goto LE; // [273] 328
    }
    else{
    }

    /** 		if compiler_type = COMPILER_WATCOM then*/
    if (_55compiler_type_44322 != 2)
    goto LF; // [280] 293

    /** 			c_flags &= " /dEWINDOWS"*/
    Concat((object_ptr)&_c_flags_44486, _c_flags_44486, _23600);
    goto L10; // [290] 300
LF: 

    /** 			c_flags &= " -DEWINDOWS"*/
    Concat((object_ptr)&_c_flags_44486, _c_flags_44486, _23602);
L10: 

    /** 		if dll_option then*/
    if (_57dll_option_41676 == 0)
    {
        goto L11; // [304] 317
    }
    else{
    }

    /** 			exe_ext = ".dll"*/
    RefDS(_23604);
    DeRefi(_exe_ext_44490);
    _exe_ext_44490 = _23604;
    goto L12; // [314] 369
L11: 

    /** 			exe_ext = ".exe"*/
    RefDS(_23605);
    DeRefi(_exe_ext_44490);
    _exe_ext_44490 = _23605;
    goto L12; // [325] 369
LE: 

    /** 	elsif TOSX then*/
    if (_40TOSX_16396 == 0)
    {
        goto L13; // [332] 353
    }
    else{
    }

    /** 		if dll_option then*/
    if (_57dll_option_41676 == 0)
    {
        goto L12; // [339] 369
    }
    else{
    }

    /** 			exe_ext = ".dylib"*/
    RefDS(_23606);
    DeRefi(_exe_ext_44490);
    _exe_ext_44490 = _23606;
    goto L12; // [350] 369
L13: 

    /** 		if dll_option then*/
    if (_57dll_option_41676 == 0)
    {
        goto L14; // [357] 368
    }
    else{
    }

    /** 			exe_ext = ".so"*/
    RefDS(_23607);
    DeRefi(_exe_ext_44490);
    _exe_ext_44490 = _23607;
L14: 
L12: 

    /** 	object compile_dir = get_eucompiledir()*/
    _0 = _compile_dir_44573;
    _compile_dir_44573 = _57get_eucompiledir();
    DeRef(_0);

    /** 	if not file_exists(compile_dir) then*/
    Ref(_compile_dir_44573);
    _23609 = _17file_exists(_compile_dir_44573);
    if (IS_ATOM_INT(_23609)) {
        if (_23609 != 0){
            DeRef(_23609);
            _23609 = NOVALUE;
            goto L15; // [380] 401
        }
    }
    else {
        if (DBL_PTR(_23609)->dbl != 0.0){
            DeRef(_23609);
            _23609 = NOVALUE;
            goto L15; // [380] 401
        }
    }
    DeRef(_23609);
    _23609 = NOVALUE;

    /** 		printf(2,"Couldn't get include directory '%s'",{get_eucompiledir()})*/
    _23612 = _57get_eucompiledir();
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _23612;
    _23613 = MAKE_SEQ(_1);
    _23612 = NOVALUE;
    EPrintf(2, _23611, _23613);
    DeRefDS(_23613);
    _23613 = NOVALUE;

    /** 		abort(1)*/
    UserCleanup(1);
L15: 

    /** 	switch compiler_type do*/
    _0 = _55compiler_type_44322;
    switch ( _0 ){ 

        /** 		case COMPILER_GCC then*/
        case 1:

        /** 			c_exe = "gcc"*/
        RefDS(_23616);
        DeRefi(_c_exe_44485);
        _c_exe_44485 = _23616;

        /** 			l_exe = "gcc"*/
        RefDS(_23616);
        DeRefi(_l_exe_44487);
        _l_exe_44487 = _23616;

        /** 			obj_ext = "o"*/
        RefDS(_23617);
        DeRefi(_obj_ext_44489);
        _obj_ext_44489 = _23617;

        /** 			if debug_option then*/
        if (_57debug_option_41686 == 0)
        {
            goto L16; // [439] 451
        }
        else{
        }

        /** 				c_flags &= " -g3"*/
        Concat((object_ptr)&_c_flags_44486, _c_flags_44486, _23618);
        goto L17; // [448] 458
L16: 

        /** 				c_flags &= " -fomit-frame-pointer"*/
        Concat((object_ptr)&_c_flags_44486, _c_flags_44486, _23620);
L17: 

        /** 			if dll_option then*/
        if (_57dll_option_41676 == 0)
        {
            goto L18; // [462] 472
        }
        else{
        }

        /** 				c_flags &= " -fPIC"*/
        Concat((object_ptr)&_c_flags_44486, _c_flags_44486, _23622);
L18: 

        /** 			c_flags &= sprintf(" -c -w -fsigned-char -O2 -m32 -I%s -ffast-math",*/
        _23625 = _57get_eucompiledir();
        _23626 = _55adjust_for_build_file(_23625);
        _23625 = NOVALUE;
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = _23626;
        _23627 = MAKE_SEQ(_1);
        _23626 = NOVALUE;
        _23628 = EPrintf(-9999999, _23624, _23627);
        DeRefDS(_23627);
        _23627 = NOVALUE;
        Concat((object_ptr)&_c_flags_44486, _c_flags_44486, _23628);
        DeRefDS(_23628);
        _23628 = NOVALUE;

        /** 			if TWINDOWS and mno_cygwin then*/
        if (_40TWINDOWS_16388 == 0) {
            goto L19; // [497] 514
        }
        if (_55mno_cygwin_44343 == 0)
        {
            goto L19; // [504] 514
        }
        else{
        }

        /** 				c_flags &= " -mno-cygwin"*/
        Concat((object_ptr)&_c_flags_44486, _c_flags_44486, _23631);
L19: 

        /** 			l_flags = sprintf( "%s -m32 ", { adjust_for_build_file(user_library) })*/
        RefDS(_57user_library_41688);
        _23634 = _55adjust_for_build_file(_57user_library_41688);
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = _23634;
        _23635 = MAKE_SEQ(_1);
        _23634 = NOVALUE;
        DeRef(_l_flags_44488);
        _l_flags_44488 = EPrintf(-9999999, _23633, _23635);
        DeRefDS(_23635);
        _23635 = NOVALUE;

        /** 			if dll_option then*/
        if (_57dll_option_41676 == 0)
        {
            goto L1A; // [534] 544
        }
        else{
        }

        /** 				l_flags &= " -shared "*/
        Concat((object_ptr)&_l_flags_44488, _l_flags_44488, _23637);
L1A: 

        /** 			if TLINUX then*/
        if (_40TLINUX_16390 == 0)
        {
            goto L1B; // [548] 560
        }
        else{
        }

        /** 				l_flags &= " -ldl -lm -lpthread"*/
        Concat((object_ptr)&_l_flags_44488, _l_flags_44488, _23639);
        goto L1C; // [557] 629
L1B: 

        /** 			elsif TBSD then*/
        if (_40TBSD_16394 == 0)
        {
            goto L1D; // [564] 576
        }
        else{
        }

        /** 				l_flags &= " -lm -lpthread"*/
        Concat((object_ptr)&_l_flags_44488, _l_flags_44488, _23641);
        goto L1C; // [573] 629
L1D: 

        /** 			elsif TOSX then*/
        if (_40TOSX_16396 == 0)
        {
            goto L1E; // [580] 592
        }
        else{
        }

        /** 				l_flags &= " -lresolv"*/
        Concat((object_ptr)&_l_flags_44488, _l_flags_44488, _23643);
        goto L1C; // [589] 629
L1E: 

        /** 			elsif TWINDOWS then*/
        if (_40TWINDOWS_16388 == 0)
        {
            goto L1F; // [596] 628
        }
        else{
        }

        /** 				if mno_cygwin then*/
        if (_55mno_cygwin_44343 == 0)
        {
            goto L20; // [603] 613
        }
        else{
        }

        /** 					l_flags &= " -mno-cygwin"*/
        Concat((object_ptr)&_l_flags_44488, _l_flags_44488, _23631);
L20: 

        /** 				if not con_option then*/
        if (_57con_option_41678 != 0)
        goto L21; // [617] 627

        /** 					l_flags &= " -mwindows"*/
        Concat((object_ptr)&_l_flags_44488, _l_flags_44488, _23647);
L21: 
L1F: 
L1C: 

        /** 			rc_comp = "windres -DSRCDIR=\"" & adjust_for_build_file(current_dir()) & "\" [1] -O coff -o [2]"*/
        _23650 = _17current_dir();
        _23651 = _55adjust_for_build_file(_23650);
        _23650 = NOVALUE;
        {
            int concat_list[3];

            concat_list[0] = _23652;
            concat_list[1] = _23651;
            concat_list[2] = _23649;
            Concat_N((object_ptr)&_rc_comp_44492, concat_list, 3);
        }
        DeRef(_23651);
        _23651 = NOVALUE;
        goto L22; // [644] 843

        /** 		case COMPILER_WATCOM then*/
        case 2:

        /** 			c_exe = "wcc386"*/
        RefDS(_23654);
        DeRefi(_c_exe_44485);
        _c_exe_44485 = _23654;

        /** 			l_exe = "wlink"*/
        RefDS(_23655);
        DeRefi(_l_exe_44487);
        _l_exe_44487 = _23655;

        /** 			obj_ext = "obj"*/
        RefDS(_23656);
        DeRefi(_obj_ext_44489);
        _obj_ext_44489 = _23656;

        /** 			if debug_option then*/
        if (_57debug_option_41686 == 0)
        {
            goto L23; // [675] 692
        }
        else{
        }

        /** 				c_flags = " /d3"*/
        RefDS(_23657);
        DeRef(_c_flags_44486);
        _c_flags_44486 = _23657;

        /** 				l_flags_begin &= " DEBUG ALL "*/
        Concat((object_ptr)&_l_flags_begin_44491, _l_flags_begin_44491, _23658);
L23: 

        /** 			l_flags &= sprintf(" OPTION STACK=%d ", { total_stack_size })*/
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = _57total_stack_size_41690;
        _23661 = MAKE_SEQ(_1);
        _23662 = EPrintf(-9999999, _23660, _23661);
        DeRefDS(_23661);
        _23661 = NOVALUE;
        Concat((object_ptr)&_l_flags_44488, _l_flags_44488, _23662);
        DeRefDS(_23662);
        _23662 = NOVALUE;

        /** 			l_flags &= sprintf(" COMMIT STACK=%d ", { total_stack_size })*/
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = _57total_stack_size_41690;
        _23665 = MAKE_SEQ(_1);
        _23666 = EPrintf(-9999999, _23664, _23665);
        DeRefDS(_23665);
        _23665 = NOVALUE;
        Concat((object_ptr)&_l_flags_44488, _l_flags_44488, _23666);
        DeRefDS(_23666);
        _23666 = NOVALUE;

        /** 			l_flags &= " OPTION QUIET OPTION ELIMINATE OPTION CASEEXACT"*/
        Concat((object_ptr)&_l_flags_44488, _l_flags_44488, _23668);

        /** 			if dll_option then*/
        if (_57dll_option_41676 == 0)
        {
            goto L24; // [734] 760
        }
        else{
        }

        /** 				c_flags &= " /bd /bt=nt /mf /w0 /zq /j /zp4 /fp5 /fpi87 /5r /otimra /s /I" & adjust_for_build_file(compile_dir) */
        Ref(_compile_dir_44573);
        _23671 = _55adjust_for_build_file(_compile_dir_44573);
        if (IS_SEQUENCE(_23670) && IS_ATOM(_23671)) {
            Ref(_23671);
            Append(&_23672, _23670, _23671);
        }
        else if (IS_ATOM(_23670) && IS_SEQUENCE(_23671)) {
        }
        else {
            Concat((object_ptr)&_23672, _23670, _23671);
        }
        DeRef(_23671);
        _23671 = NOVALUE;
        Concat((object_ptr)&_c_flags_44486, _c_flags_44486, _23672);
        DeRefDS(_23672);
        _23672 = NOVALUE;

        /** 				l_flags &= " SYSTEM NT_DLL initinstance terminstance"*/
        Concat((object_ptr)&_l_flags_44488, _l_flags_44488, _23674);
        goto L25; // [757] 798
L24: 

        /** 				c_flags &= " /bt=nt /mf /w0 /zq /j /zp4 /fp5 /fpi87 /5r /otimra /s /I" & adjust_for_build_file(compile_dir)*/
        Ref(_compile_dir_44573);
        _23677 = _55adjust_for_build_file(_compile_dir_44573);
        if (IS_SEQUENCE(_23676) && IS_ATOM(_23677)) {
            Ref(_23677);
            Append(&_23678, _23676, _23677);
        }
        else if (IS_ATOM(_23676) && IS_SEQUENCE(_23677)) {
        }
        else {
            Concat((object_ptr)&_23678, _23676, _23677);
        }
        DeRef(_23677);
        _23677 = NOVALUE;
        Concat((object_ptr)&_c_flags_44486, _c_flags_44486, _23678);
        DeRefDS(_23678);
        _23678 = NOVALUE;

        /** 				if con_option then*/
        if (_57con_option_41678 == 0)
        {
            goto L26; // [778] 790
        }
        else{
        }

        /** 					l_flags = " SYSTEM NT" & l_flags*/
        Concat((object_ptr)&_l_flags_44488, _23680, _l_flags_44488);
        goto L27; // [787] 797
L26: 

        /** 					l_flags = " SYSTEM NT_WIN RUNTIME WINDOWS=4.0" & l_flags*/
        Concat((object_ptr)&_l_flags_44488, _23682, _l_flags_44488);
L27: 
L25: 

        /** 			l_flags &= sprintf(" FILE %s", { (user_library) })*/
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        RefDS(_57user_library_41688);
        *((int *)(_2+4)) = _57user_library_41688;
        _23685 = MAKE_SEQ(_1);
        _23686 = EPrintf(-9999999, _23684, _23685);
        DeRefDS(_23685);
        _23685 = NOVALUE;
        Concat((object_ptr)&_l_flags_44488, _l_flags_44488, _23686);
        DeRefDS(_23686);
        _23686 = NOVALUE;

        /** 			rc_comp = "wrc -DSRCDIR=\"" & adjust_for_build_file(current_dir()) & "\" -q -fo=[2] -ad [1] [3]"*/
        _23689 = _17current_dir();
        _23690 = _55adjust_for_build_file(_23689);
        _23689 = NOVALUE;
        {
            int concat_list[3];

            concat_list[0] = _23691;
            concat_list[1] = _23690;
            concat_list[2] = _23688;
            Concat_N((object_ptr)&_rc_comp_44492, concat_list, 3);
        }
        DeRef(_23690);
        _23690 = NOVALUE;
        goto L22; // [829] 843

        /** 		case else*/
        default:

        /** 			CompileErr(43)*/
        RefDS(_22023);
        _44CompileErr(43, _22023, 0);
    ;}L22: 

    /** 	if length(cflags) then*/
    if (IS_SEQUENCE(_55cflags_44339)){
            _23693 = SEQ_PTR(_55cflags_44339)->length;
    }
    else {
        _23693 = 1;
    }
    if (_23693 == 0)
    {
        _23693 = NOVALUE;
        goto L28; // [850] 863
    }
    else{
        _23693 = NOVALUE;
    }

    /** 		c_flags = cflags*/
    RefDS(_55cflags_44339);
    DeRef(_c_flags_44486);
    _c_flags_44486 = _55cflags_44339;
L28: 

    /** 	if length(lflags) then*/
    if (IS_SEQUENCE(_55lflags_44340)){
            _23694 = SEQ_PTR(_55lflags_44340)->length;
    }
    else {
        _23694 = 1;
    }
    if (_23694 == 0)
    {
        _23694 = NOVALUE;
        goto L29; // [870] 890
    }
    else{
        _23694 = NOVALUE;
    }

    /** 		l_flags = lflags*/
    RefDS(_55lflags_44340);
    DeRef(_l_flags_44488);
    _l_flags_44488 = _55lflags_44340;

    /** 		l_flags_begin = ""*/
    RefDS(_22023);
    DeRefi(_l_flags_begin_44491);
    _l_flags_begin_44491 = _22023;
L29: 

    /** 	return { */
    _1 = NewS1(8);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_c_exe_44485);
    *((int *)(_2+4)) = _c_exe_44485;
    RefDS(_c_flags_44486);
    *((int *)(_2+8)) = _c_flags_44486;
    RefDS(_l_exe_44487);
    *((int *)(_2+12)) = _l_exe_44487;
    RefDS(_l_flags_44488);
    *((int *)(_2+16)) = _l_flags_44488;
    RefDS(_obj_ext_44489);
    *((int *)(_2+20)) = _obj_ext_44489;
    RefDS(_exe_ext_44490);
    *((int *)(_2+24)) = _exe_ext_44490;
    RefDS(_l_flags_begin_44491);
    *((int *)(_2+28)) = _l_flags_begin_44491;
    RefDS(_rc_comp_44492);
    *((int *)(_2+32)) = _rc_comp_44492;
    _23695 = MAKE_SEQ(_1);
    DeRefDSi(_c_exe_44485);
    DeRefDS(_c_flags_44486);
    DeRefDSi(_l_exe_44487);
    DeRefDS(_l_flags_44488);
    DeRefDSi(_obj_ext_44489);
    DeRefDSi(_exe_ext_44490);
    DeRefDSi(_l_flags_begin_44491);
    DeRefDS(_rc_comp_44492);
    DeRef(_l_names_44493);
    DeRefi(_l_ext_44494);
    DeRefi(_t_slash_44495);
    DeRef(_compile_dir_44573);
    return _23695;
    ;
}


void _55ensure_exename(int _ext_44709)
{
    int _23702 = NOVALUE;
    int _23701 = NOVALUE;
    int _23700 = NOVALUE;
    int _23699 = NOVALUE;
    int _23697 = NOVALUE;
    int _23696 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if length(exe_name[D_ALTNAME]) = 0 then*/
    _2 = (int)SEQ_PTR(_55exe_name_44324);
    _23696 = (int)*(((s1_ptr)_2)->base + 11);
    if (IS_SEQUENCE(_23696)){
            _23697 = SEQ_PTR(_23696)->length;
    }
    else {
        _23697 = 1;
    }
    _23696 = NOVALUE;
    if (_23697 != 0)
    goto L1; // [16] 67

    /** 		exe_name[D_NAME] = current_dir() & SLASH & file0 & ext*/
    _23699 = _17current_dir();
    {
        int concat_list[4];

        concat_list[0] = _ext_44709;
        concat_list[1] = _57file0_43504;
        concat_list[2] = 92;
        concat_list[3] = _23699;
        Concat_N((object_ptr)&_23700, concat_list, 4);
    }
    DeRef(_23699);
    _23699 = NOVALUE;
    _2 = (int)SEQ_PTR(_55exe_name_44324);
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _23700;
    if( _1 != _23700 ){
        DeRef(_1);
    }
    _23700 = NOVALUE;

    /** 		exe_name[D_ALTNAME] = adjust_for_command_line_passing(exe_name[D_NAME])*/
    _2 = (int)SEQ_PTR(_55exe_name_44324);
    _23701 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_23701);
    _23702 = _55adjust_for_command_line_passing(_23701);
    _23701 = NOVALUE;
    _2 = (int)SEQ_PTR(_55exe_name_44324);
    _2 = (int)(((s1_ptr)_2)->base + 11);
    _1 = *(int *)_2;
    *(int *)_2 = _23702;
    if( _1 != _23702 ){
        DeRef(_1);
    }
    _23702 = NOVALUE;
L1: 

    /** end procedure*/
    DeRefDS(_ext_44709);
    _23696 = NOVALUE;
    return;
    ;
}


void _55write_objlink_file()
{
    int _settings_44727 = NOVALUE;
    int _fh_44729 = NOVALUE;
    int _s_44777 = NOVALUE;
    int _23751 = NOVALUE;
    int _23749 = NOVALUE;
    int _23748 = NOVALUE;
    int _23747 = NOVALUE;
    int _23746 = NOVALUE;
    int _23745 = NOVALUE;
    int _23744 = NOVALUE;
    int _23743 = NOVALUE;
    int _23742 = NOVALUE;
    int _23741 = NOVALUE;
    int _23740 = NOVALUE;
    int _23739 = NOVALUE;
    int _23738 = NOVALUE;
    int _23736 = NOVALUE;
    int _23735 = NOVALUE;
    int _23734 = NOVALUE;
    int _23733 = NOVALUE;
    int _23731 = NOVALUE;
    int _23730 = NOVALUE;
    int _23729 = NOVALUE;
    int _23728 = NOVALUE;
    int _23727 = NOVALUE;
    int _23726 = NOVALUE;
    int _23725 = NOVALUE;
    int _23724 = NOVALUE;
    int _23723 = NOVALUE;
    int _23720 = NOVALUE;
    int _23719 = NOVALUE;
    int _23716 = NOVALUE;
    int _23715 = NOVALUE;
    int _23714 = NOVALUE;
    int _23713 = NOVALUE;
    int _23712 = NOVALUE;
    int _23710 = NOVALUE;
    int _23709 = NOVALUE;
    int _23708 = NOVALUE;
    int _23705 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence settings = setup_build()*/
    _0 = _settings_44727;
    _settings_44727 = _55setup_build();
    DeRef(_0);

    /** 	integer fh = open(output_dir & file0 & ".lnk", "wb")*/
    {
        int concat_list[3];

        concat_list[0] = _23704;
        concat_list[1] = _57file0_43504;
        concat_list[2] = _57output_dir_41689;
        Concat_N((object_ptr)&_23705, concat_list, 3);
    }
    _fh_44729 = EOpen(_23705, _23706, 0);
    DeRefDS(_23705);
    _23705 = NOVALUE;

    /** 	ensure_exename(settings[SETUP_EXE_EXT])*/
    _2 = (int)SEQ_PTR(_settings_44727);
    _23708 = (int)*(((s1_ptr)_2)->base + 6);
    Ref(_23708);
    _55ensure_exename(_23708);
    _23708 = NOVALUE;

    /** 	if length(settings[SETUP_LFLAGS_BEGIN]) > 0 then*/
    _2 = (int)SEQ_PTR(_settings_44727);
    _23709 = (int)*(((s1_ptr)_2)->base + 7);
    if (IS_SEQUENCE(_23709)){
            _23710 = SEQ_PTR(_23709)->length;
    }
    else {
        _23710 = 1;
    }
    _23709 = NOVALUE;
    if (_23710 <= 0)
    goto L1; // [43] 63

    /** 		puts(fh, settings[SETUP_LFLAGS_BEGIN] & HOSTNL)*/
    _2 = (int)SEQ_PTR(_settings_44727);
    _23712 = (int)*(((s1_ptr)_2)->base + 7);
    if (IS_SEQUENCE(_23712) && IS_ATOM(_40HOSTNL_16403)) {
    }
    else if (IS_ATOM(_23712) && IS_SEQUENCE(_40HOSTNL_16403)) {
        Ref(_23712);
        Prepend(&_23713, _40HOSTNL_16403, _23712);
    }
    else {
        Concat((object_ptr)&_23713, _23712, _40HOSTNL_16403);
        _23712 = NOVALUE;
    }
    _23712 = NOVALUE;
    EPuts(_fh_44729, _23713); // DJP 
    DeRefDS(_23713);
    _23713 = NOVALUE;
L1: 

    /** 	for i = 1 to length(generated_files) do*/
    if (IS_SEQUENCE(_57generated_files_41680)){
            _23714 = SEQ_PTR(_57generated_files_41680)->length;
    }
    else {
        _23714 = 1;
    }
    {
        int _i_44745;
        _i_44745 = 1;
L2: 
        if (_i_44745 > _23714){
            goto L3; // [70] 132
        }

        /** 		if match(".o", generated_files[i]) then*/
        _2 = (int)SEQ_PTR(_57generated_files_41680);
        _23715 = (int)*(((s1_ptr)_2)->base + _i_44745);
        _23716 = e_match_from(_23058, _23715, 1);
        _23715 = NOVALUE;
        if (_23716 == 0)
        {
            _23716 = NOVALUE;
            goto L4; // [90] 125
        }
        else{
            _23716 = NOVALUE;
        }

        /** 			if compiler_type = COMPILER_WATCOM then*/
        if (_55compiler_type_44322 != 2)
        goto L5; // [97] 107

        /** 				puts(fh, "FILE ")*/
        EPuts(_fh_44729, _23718); // DJP 
L5: 

        /** 			puts(fh, generated_files[i] & HOSTNL)*/
        _2 = (int)SEQ_PTR(_57generated_files_41680);
        _23719 = (int)*(((s1_ptr)_2)->base + _i_44745);
        Concat((object_ptr)&_23720, _23719, _40HOSTNL_16403);
        _23719 = NOVALUE;
        _23719 = NOVALUE;
        EPuts(_fh_44729, _23720); // DJP 
        DeRefDS(_23720);
        _23720 = NOVALUE;
L4: 

        /** 	end for*/
        _i_44745 = _i_44745 + 1;
        goto L2; // [127] 77
L3: 
        ;
    }

    /** 	if compiler_type = COMPILER_WATCOM then*/
    if (_55compiler_type_44322 != 2)
    goto L6; // [136] 165

    /** 		printf(fh, "NAME '%s'" & HOSTNL, { exe_name[D_ALTNAME] })*/
    Concat((object_ptr)&_23723, _23722, _40HOSTNL_16403);
    _2 = (int)SEQ_PTR(_55exe_name_44324);
    _23724 = (int)*(((s1_ptr)_2)->base + 11);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_23724);
    *((int *)(_2+4)) = _23724;
    _23725 = MAKE_SEQ(_1);
    _23724 = NOVALUE;
    EPrintf(_fh_44729, _23723, _23725);
    DeRefDS(_23723);
    _23723 = NOVALUE;
    DeRefDS(_23725);
    _23725 = NOVALUE;
L6: 

    /** 	puts(fh, trim(settings[SETUP_LFLAGS] & HOSTNL))*/
    _2 = (int)SEQ_PTR(_settings_44727);
    _23726 = (int)*(((s1_ptr)_2)->base + 4);
    if (IS_SEQUENCE(_23726) && IS_ATOM(_40HOSTNL_16403)) {
    }
    else if (IS_ATOM(_23726) && IS_SEQUENCE(_40HOSTNL_16403)) {
        Ref(_23726);
        Prepend(&_23727, _40HOSTNL_16403, _23726);
    }
    else {
        Concat((object_ptr)&_23727, _23726, _40HOSTNL_16403);
        _23726 = NOVALUE;
    }
    _23726 = NOVALUE;
    RefDS(_3890);
    _23728 = _14trim(_23727, _3890, 0);
    _23727 = NOVALUE;
    EPuts(_fh_44729, _23728); // DJP 
    DeRef(_23728);
    _23728 = NOVALUE;

    /** 	if compiler_type = COMPILER_WATCOM and dll_option then*/
    _23729 = (_55compiler_type_44322 == 2);
    if (_23729 == 0) {
        goto L7; // [194] 361
    }
    if (_57dll_option_41676 == 0)
    {
        goto L7; // [201] 361
    }
    else{
    }

    /** 		puts(fh, HOSTNL)*/
    EPuts(_fh_44729, _40HOSTNL_16403); // DJP 

    /** 		object s = SymTab[TopLevelSub][S_NEXT]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _23731 = (int)*(((s1_ptr)_2)->base + _35TopLevelSub_16251);
    DeRef(_s_44777);
    _2 = (int)SEQ_PTR(_23731);
    _s_44777 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_s_44777);
    _23731 = NOVALUE;

    /** 		while s do*/
L8: 
    if (_s_44777 <= 0) {
        if (_s_44777 == 0) {
            goto L9; // [232] 360
        }
        else {
            if (!IS_ATOM_INT(_s_44777) && DBL_PTR(_s_44777)->dbl == 0.0){
                goto L9; // [232] 360
            }
        }
    }

    /** 			if eu:find(SymTab[s][S_TOKEN], RTN_TOKS) then*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!IS_ATOM_INT(_s_44777)){
        _23733 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_s_44777)->dbl));
    }
    else{
        _23733 = (int)*(((s1_ptr)_2)->base + _s_44777);
    }
    _2 = (int)SEQ_PTR(_23733);
    if (!IS_ATOM_INT(_35S_TOKEN_15922)){
        _23734 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TOKEN_15922)->dbl));
    }
    else{
        _23734 = (int)*(((s1_ptr)_2)->base + _35S_TOKEN_15922);
    }
    _23733 = NOVALUE;
    _23735 = find_from(_23734, _37RTN_TOKS_15870, 1);
    _23734 = NOVALUE;
    if (_23735 == 0)
    {
        _23735 = NOVALUE;
        goto LA; // [256] 341
    }
    else{
        _23735 = NOVALUE;
    }

    /** 				if is_exported( s ) then*/
    Ref(_s_44777);
    _23736 = _57is_exported(_s_44777);
    if (_23736 == 0) {
        DeRef(_23736);
        _23736 = NOVALUE;
        goto LB; // [265] 340
    }
    else {
        if (!IS_ATOM_INT(_23736) && DBL_PTR(_23736)->dbl == 0.0){
            DeRef(_23736);
            _23736 = NOVALUE;
            goto LB; // [265] 340
        }
        DeRef(_23736);
        _23736 = NOVALUE;
    }
    DeRef(_23736);
    _23736 = NOVALUE;

    /** 					printf(fh, "EXPORT %s='__%d%s@%d'" & HOSTNL,*/
    Concat((object_ptr)&_23738, _23737, _40HOSTNL_16403);
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!IS_ATOM_INT(_s_44777)){
        _23739 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_s_44777)->dbl));
    }
    else{
        _23739 = (int)*(((s1_ptr)_2)->base + _s_44777);
    }
    _2 = (int)SEQ_PTR(_23739);
    if (!IS_ATOM_INT(_35S_NAME_15917)){
        _23740 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15917)->dbl));
    }
    else{
        _23740 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15917);
    }
    _23739 = NOVALUE;
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!IS_ATOM_INT(_s_44777)){
        _23741 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_s_44777)->dbl));
    }
    else{
        _23741 = (int)*(((s1_ptr)_2)->base + _s_44777);
    }
    _2 = (int)SEQ_PTR(_23741);
    if (!IS_ATOM_INT(_35S_FILE_NO_15913)){
        _23742 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FILE_NO_15913)->dbl));
    }
    else{
        _23742 = (int)*(((s1_ptr)_2)->base + _35S_FILE_NO_15913);
    }
    _23741 = NOVALUE;
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!IS_ATOM_INT(_s_44777)){
        _23743 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_s_44777)->dbl));
    }
    else{
        _23743 = (int)*(((s1_ptr)_2)->base + _s_44777);
    }
    _2 = (int)SEQ_PTR(_23743);
    if (!IS_ATOM_INT(_35S_NAME_15917)){
        _23744 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15917)->dbl));
    }
    else{
        _23744 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15917);
    }
    _23743 = NOVALUE;
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!IS_ATOM_INT(_s_44777)){
        _23745 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_s_44777)->dbl));
    }
    else{
        _23745 = (int)*(((s1_ptr)_2)->base + _s_44777);
    }
    _2 = (int)SEQ_PTR(_23745);
    if (!IS_ATOM_INT(_35S_NUM_ARGS_15968)){
        _23746 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NUM_ARGS_15968)->dbl));
    }
    else{
        _23746 = (int)*(((s1_ptr)_2)->base + _35S_NUM_ARGS_15968);
    }
    _23745 = NOVALUE;
    if (IS_ATOM_INT(_23746)) {
        if (_23746 == (short)_23746)
        _23747 = _23746 * 4;
        else
        _23747 = NewDouble(_23746 * (double)4);
    }
    else {
        _23747 = binary_op(MULTIPLY, _23746, 4);
    }
    _23746 = NOVALUE;
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_23740);
    *((int *)(_2+4)) = _23740;
    Ref(_23742);
    *((int *)(_2+8)) = _23742;
    Ref(_23744);
    *((int *)(_2+12)) = _23744;
    *((int *)(_2+16)) = _23747;
    _23748 = MAKE_SEQ(_1);
    _23747 = NOVALUE;
    _23744 = NOVALUE;
    _23742 = NOVALUE;
    _23740 = NOVALUE;
    EPrintf(_fh_44729, _23738, _23748);
    DeRefDS(_23738);
    _23738 = NOVALUE;
    DeRefDS(_23748);
    _23748 = NOVALUE;
LB: 
LA: 

    /** 			s = SymTab[s][S_NEXT]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!IS_ATOM_INT(_s_44777)){
        _23749 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_s_44777)->dbl));
    }
    else{
        _23749 = (int)*(((s1_ptr)_2)->base + _s_44777);
    }
    DeRef(_s_44777);
    _2 = (int)SEQ_PTR(_23749);
    _s_44777 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_s_44777);
    _23749 = NOVALUE;

    /** 		end while*/
    goto L8; // [357] 232
L9: 
L7: 
    DeRef(_s_44777);
    _s_44777 = NOVALUE;

    /** 	close(fh)*/
    EClose(_fh_44729);

    /** 	generated_files = append(generated_files, file0 & ".lnk")*/
    Concat((object_ptr)&_23751, _57file0_43504, _23704);
    RefDS(_23751);
    Append(&_57generated_files_41680, _57generated_files_41680, _23751);
    DeRefDS(_23751);
    _23751 = NOVALUE;

    /** end procedure*/
    DeRef(_settings_44727);
    _23709 = NOVALUE;
    DeRef(_23729);
    _23729 = NOVALUE;
    return;
    ;
}


void _55write_makefile_srcobj_list(int _fh_44826)
{
    int _23776 = NOVALUE;
    int _23775 = NOVALUE;
    int _23774 = NOVALUE;
    int _23773 = NOVALUE;
    int _23772 = NOVALUE;
    int _23770 = NOVALUE;
    int _23769 = NOVALUE;
    int _23768 = NOVALUE;
    int _23767 = NOVALUE;
    int _23766 = NOVALUE;
    int _23765 = NOVALUE;
    int _23764 = NOVALUE;
    int _23762 = NOVALUE;
    int _23761 = NOVALUE;
    int _23759 = NOVALUE;
    int _23758 = NOVALUE;
    int _23757 = NOVALUE;
    int _23756 = NOVALUE;
    int _23755 = NOVALUE;
    int _23754 = NOVALUE;
    int _0, _1, _2;
    

    /** 	printf(fh, "%s_SOURCES =", { upper(file0) })*/
    RefDS(_57file0_43504);
    _23754 = _14upper(_57file0_43504);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _23754;
    _23755 = MAKE_SEQ(_1);
    _23754 = NOVALUE;
    EPrintf(_fh_44826, _23753, _23755);
    DeRefDS(_23755);
    _23755 = NOVALUE;

    /** 	for i = 1 to length(generated_files) do*/
    if (IS_SEQUENCE(_57generated_files_41680)){
            _23756 = SEQ_PTR(_57generated_files_41680)->length;
    }
    else {
        _23756 = 1;
    }
    {
        int _i_44833;
        _i_44833 = 1;
L1: 
        if (_i_44833 > _23756){
            goto L2; // [26] 75
        }

        /** 		if generated_files[i][$] = 'c' then*/
        _2 = (int)SEQ_PTR(_57generated_files_41680);
        _23757 = (int)*(((s1_ptr)_2)->base + _i_44833);
        if (IS_SEQUENCE(_23757)){
                _23758 = SEQ_PTR(_23757)->length;
        }
        else {
            _23758 = 1;
        }
        _2 = (int)SEQ_PTR(_23757);
        _23759 = (int)*(((s1_ptr)_2)->base + _23758);
        _23757 = NOVALUE;
        if (binary_op_a(NOTEQ, _23759, 99)){
            _23759 = NOVALUE;
            goto L3; // [48] 68
        }
        _23759 = NOVALUE;

        /** 			puts(fh, " " & generated_files[i])*/
        _2 = (int)SEQ_PTR(_57generated_files_41680);
        _23761 = (int)*(((s1_ptr)_2)->base + _i_44833);
        Concat((object_ptr)&_23762, _23298, _23761);
        _23761 = NOVALUE;
        EPuts(_fh_44826, _23762); // DJP 
        DeRefDS(_23762);
        _23762 = NOVALUE;
L3: 

        /** 	end for*/
        _i_44833 = _i_44833 + 1;
        goto L1; // [70] 33
L2: 
        ;
    }

    /** 	puts(fh, HOSTNL)*/
    EPuts(_fh_44826, _40HOSTNL_16403); // DJP 

    /** 	printf(fh, "%s_OBJECTS =", { upper(file0) })*/
    RefDS(_57file0_43504);
    _23764 = _14upper(_57file0_43504);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _23764;
    _23765 = MAKE_SEQ(_1);
    _23764 = NOVALUE;
    EPrintf(_fh_44826, _23763, _23765);
    DeRefDS(_23765);
    _23765 = NOVALUE;

    /** 	for i = 1 to length(generated_files) do*/
    if (IS_SEQUENCE(_57generated_files_41680)){
            _23766 = SEQ_PTR(_57generated_files_41680)->length;
    }
    else {
        _23766 = 1;
    }
    {
        int _i_44852;
        _i_44852 = 1;
L4: 
        if (_i_44852 > _23766){
            goto L5; // [105] 151
        }

        /** 		if match(".o", generated_files[i]) then*/
        _2 = (int)SEQ_PTR(_57generated_files_41680);
        _23767 = (int)*(((s1_ptr)_2)->base + _i_44852);
        _23768 = e_match_from(_23058, _23767, 1);
        _23767 = NOVALUE;
        if (_23768 == 0)
        {
            _23768 = NOVALUE;
            goto L6; // [125] 144
        }
        else{
            _23768 = NOVALUE;
        }

        /** 			puts(fh, " " & generated_files[i])*/
        _2 = (int)SEQ_PTR(_57generated_files_41680);
        _23769 = (int)*(((s1_ptr)_2)->base + _i_44852);
        Concat((object_ptr)&_23770, _23298, _23769);
        _23769 = NOVALUE;
        EPuts(_fh_44826, _23770); // DJP 
        DeRefDS(_23770);
        _23770 = NOVALUE;
L6: 

        /** 	end for*/
        _i_44852 = _i_44852 + 1;
        goto L4; // [146] 112
L5: 
        ;
    }

    /** 	puts(fh, HOSTNL)*/
    EPuts(_fh_44826, _40HOSTNL_16403); // DJP 

    /** 	printf(fh, "%s_GENERATED_FILES = ", { upper(file0) })*/
    RefDS(_57file0_43504);
    _23772 = _14upper(_57file0_43504);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _23772;
    _23773 = MAKE_SEQ(_1);
    _23772 = NOVALUE;
    EPrintf(_fh_44826, _23771, _23773);
    DeRefDS(_23773);
    _23773 = NOVALUE;

    /** 	for i = 1 to length(generated_files) do*/
    if (IS_SEQUENCE(_57generated_files_41680)){
            _23774 = SEQ_PTR(_57generated_files_41680)->length;
    }
    else {
        _23774 = 1;
    }
    {
        int _i_44869;
        _i_44869 = 1;
L7: 
        if (_i_44869 > _23774){
            goto L8; // [181] 210
        }

        /** 		puts(fh, " " & generated_files[i])*/
        _2 = (int)SEQ_PTR(_57generated_files_41680);
        _23775 = (int)*(((s1_ptr)_2)->base + _i_44869);
        Concat((object_ptr)&_23776, _23298, _23775);
        _23775 = NOVALUE;
        EPuts(_fh_44826, _23776); // DJP 
        DeRefDS(_23776);
        _23776 = NOVALUE;

        /** 	end for*/
        _i_44869 = _i_44869 + 1;
        goto L7; // [205] 188
L8: 
        ;
    }

    /** 	puts(fh, HOSTNL)*/
    EPuts(_fh_44826, _40HOSTNL_16403); // DJP 

    /** end procedure*/
    return;
    ;
}


int _55windows_to_mingw_path(int _s_44878)
{
    int _23778 = NOVALUE;
    int _0, _1, _2;
    

    /** 	ifdef TEST_FOR_WIN9X_ON_MING then*/

    /** 	return search:find_replace('\\',s,'/')*/
    RefDS(_s_44878);
    _23778 = _16find_replace(92, _s_44878, 47, 0);
    DeRefDS(_s_44878);
    return _23778;
    ;
}


void _55write_makefile_full()
{
    int _settings_44883 = NOVALUE;
    int _fh_44886 = NOVALUE;
    int _23902 = NOVALUE;
    int _23900 = NOVALUE;
    int _23898 = NOVALUE;
    int _23897 = NOVALUE;
    int _23896 = NOVALUE;
    int _23895 = NOVALUE;
    int _23894 = NOVALUE;
    int _23892 = NOVALUE;
    int _23891 = NOVALUE;
    int _23889 = NOVALUE;
    int _23888 = NOVALUE;
    int _23887 = NOVALUE;
    int _23886 = NOVALUE;
    int _23884 = NOVALUE;
    int _23883 = NOVALUE;
    int _23881 = NOVALUE;
    int _23880 = NOVALUE;
    int _23878 = NOVALUE;
    int _23877 = NOVALUE;
    int _23876 = NOVALUE;
    int _23875 = NOVALUE;
    int _23874 = NOVALUE;
    int _23873 = NOVALUE;
    int _23872 = NOVALUE;
    int _23871 = NOVALUE;
    int _23869 = NOVALUE;
    int _23868 = NOVALUE;
    int _23867 = NOVALUE;
    int _23866 = NOVALUE;
    int _23865 = NOVALUE;
    int _23864 = NOVALUE;
    int _23863 = NOVALUE;
    int _23862 = NOVALUE;
    int _23861 = NOVALUE;
    int _23860 = NOVALUE;
    int _23859 = NOVALUE;
    int _23858 = NOVALUE;
    int _23857 = NOVALUE;
    int _23855 = NOVALUE;
    int _23853 = NOVALUE;
    int _23851 = NOVALUE;
    int _23850 = NOVALUE;
    int _23849 = NOVALUE;
    int _23848 = NOVALUE;
    int _23847 = NOVALUE;
    int _23846 = NOVALUE;
    int _23845 = NOVALUE;
    int _23844 = NOVALUE;
    int _23843 = NOVALUE;
    int _23842 = NOVALUE;
    int _23841 = NOVALUE;
    int _23840 = NOVALUE;
    int _23839 = NOVALUE;
    int _23838 = NOVALUE;
    int _23836 = NOVALUE;
    int _23835 = NOVALUE;
    int _23834 = NOVALUE;
    int _23833 = NOVALUE;
    int _23832 = NOVALUE;
    int _23831 = NOVALUE;
    int _23830 = NOVALUE;
    int _23829 = NOVALUE;
    int _23828 = NOVALUE;
    int _23826 = NOVALUE;
    int _23825 = NOVALUE;
    int _23824 = NOVALUE;
    int _23823 = NOVALUE;
    int _23821 = NOVALUE;
    int _23820 = NOVALUE;
    int _23819 = NOVALUE;
    int _23818 = NOVALUE;
    int _23817 = NOVALUE;
    int _23816 = NOVALUE;
    int _23814 = NOVALUE;
    int _23813 = NOVALUE;
    int _23812 = NOVALUE;
    int _23811 = NOVALUE;
    int _23810 = NOVALUE;
    int _23809 = NOVALUE;
    int _23808 = NOVALUE;
    int _23806 = NOVALUE;
    int _23805 = NOVALUE;
    int _23804 = NOVALUE;
    int _23803 = NOVALUE;
    int _23800 = NOVALUE;
    int _23799 = NOVALUE;
    int _23798 = NOVALUE;
    int _23795 = NOVALUE;
    int _23794 = NOVALUE;
    int _23793 = NOVALUE;
    int _23791 = NOVALUE;
    int _23790 = NOVALUE;
    int _23789 = NOVALUE;
    int _23787 = NOVALUE;
    int _23786 = NOVALUE;
    int _23785 = NOVALUE;
    int _23782 = NOVALUE;
    int _23780 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence settings = setup_build()*/
    _0 = _settings_44883;
    _settings_44883 = _55setup_build();
    DeRef(_0);

    /** 	ensure_exename(settings[SETUP_EXE_EXT])*/
    _2 = (int)SEQ_PTR(_settings_44883);
    _23780 = (int)*(((s1_ptr)_2)->base + 6);
    Ref(_23780);
    _55ensure_exename(_23780);
    _23780 = NOVALUE;

    /** 	integer fh = open(output_dir & file0 & ".mak", "wb")*/
    {
        int concat_list[3];

        concat_list[0] = _23781;
        concat_list[1] = _57file0_43504;
        concat_list[2] = _57output_dir_41689;
        Concat_N((object_ptr)&_23782, concat_list, 3);
    }
    _fh_44886 = EOpen(_23782, _23706, 0);
    DeRefDS(_23782);
    _23782 = NOVALUE;

    /** 	printf(fh, "CC     = %s" & HOSTNL, { settings[SETUP_CEXE] })*/
    Concat((object_ptr)&_23785, _23784, _40HOSTNL_16403);
    _2 = (int)SEQ_PTR(_settings_44883);
    _23786 = (int)*(((s1_ptr)_2)->base + 1);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_23786);
    *((int *)(_2+4)) = _23786;
    _23787 = MAKE_SEQ(_1);
    _23786 = NOVALUE;
    EPrintf(_fh_44886, _23785, _23787);
    DeRefDS(_23785);
    _23785 = NOVALUE;
    DeRefDS(_23787);
    _23787 = NOVALUE;

    /** 	printf(fh, "CFLAGS = %s" & HOSTNL, { settings[SETUP_CFLAGS] })*/
    Concat((object_ptr)&_23789, _23788, _40HOSTNL_16403);
    _2 = (int)SEQ_PTR(_settings_44883);
    _23790 = (int)*(((s1_ptr)_2)->base + 2);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_23790);
    *((int *)(_2+4)) = _23790;
    _23791 = MAKE_SEQ(_1);
    _23790 = NOVALUE;
    EPrintf(_fh_44886, _23789, _23791);
    DeRefDS(_23789);
    _23789 = NOVALUE;
    DeRefDS(_23791);
    _23791 = NOVALUE;

    /** 	printf(fh, "LINKER = %s" & HOSTNL, { settings[SETUP_LEXE] })*/
    Concat((object_ptr)&_23793, _23792, _40HOSTNL_16403);
    _2 = (int)SEQ_PTR(_settings_44883);
    _23794 = (int)*(((s1_ptr)_2)->base + 3);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_23794);
    *((int *)(_2+4)) = _23794;
    _23795 = MAKE_SEQ(_1);
    _23794 = NOVALUE;
    EPrintf(_fh_44886, _23793, _23795);
    DeRefDS(_23793);
    _23793 = NOVALUE;
    DeRefDS(_23795);
    _23795 = NOVALUE;

    /** 	if compiler_type = COMPILER_GCC then*/
    if (_55compiler_type_44322 != 1)
    goto L1; // [98] 125

    /** 		printf(fh, "LFLAGS = %s" & HOSTNL, { settings[SETUP_LFLAGS] })*/
    Concat((object_ptr)&_23798, _23797, _40HOSTNL_16403);
    _2 = (int)SEQ_PTR(_settings_44883);
    _23799 = (int)*(((s1_ptr)_2)->base + 4);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_23799);
    *((int *)(_2+4)) = _23799;
    _23800 = MAKE_SEQ(_1);
    _23799 = NOVALUE;
    EPrintf(_fh_44886, _23798, _23800);
    DeRefDS(_23798);
    _23798 = NOVALUE;
    DeRefDS(_23800);
    _23800 = NOVALUE;
    goto L2; // [122] 130
L1: 

    /** 		write_objlink_file()*/
    _55write_objlink_file();
L2: 

    /** 	write_makefile_srcobj_list(fh)*/
    _55write_makefile_srcobj_list(_fh_44886);

    /** 	puts(fh, HOSTNL)*/
    EPuts(_fh_44886, _40HOSTNL_16403); // DJP 

    /** 	if compiler_type = COMPILER_WATCOM then*/
    if (_55compiler_type_44322 != 2)
    goto L3; // [146] 575

    /** 		printf(fh, "\"%s\" : $(%s_OBJECTS) %s" & HOSTNL, { */
    Concat((object_ptr)&_23803, _23802, _40HOSTNL_16403);
    _2 = (int)SEQ_PTR(_55exe_name_44324);
    _23804 = (int)*(((s1_ptr)_2)->base + 11);
    RefDS(_57file0_43504);
    _23805 = _14upper(_57file0_43504);
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_23804);
    *((int *)(_2+4)) = _23804;
    *((int *)(_2+8)) = _23805;
    RefDS(_57user_library_41688);
    *((int *)(_2+12)) = _57user_library_41688;
    _23806 = MAKE_SEQ(_1);
    _23805 = NOVALUE;
    _23804 = NOVALUE;
    EPrintf(_fh_44886, _23803, _23806);
    DeRefDS(_23803);
    _23803 = NOVALUE;
    DeRefDS(_23806);
    _23806 = NOVALUE;

    /** 		printf(fh, "\t$(LINKER) @%s.lnk" & HOSTNL, { file0 })*/
    Concat((object_ptr)&_23808, _23807, _40HOSTNL_16403);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_57file0_43504);
    *((int *)(_2+4)) = _57file0_43504;
    _23809 = MAKE_SEQ(_1);
    EPrintf(_fh_44886, _23808, _23809);
    DeRefDS(_23808);
    _23808 = NOVALUE;
    DeRefDS(_23809);
    _23809 = NOVALUE;

    /** 		if length(rc_file[D_ALTNAME]) and length(settings[SETUP_RC_COMPILER]) then*/
    _2 = (int)SEQ_PTR(_55rc_file_44330);
    _23810 = (int)*(((s1_ptr)_2)->base + 11);
    if (IS_SEQUENCE(_23810)){
            _23811 = SEQ_PTR(_23810)->length;
    }
    else {
        _23811 = 1;
    }
    _23810 = NOVALUE;
    if (_23811 == 0) {
        goto L4; // [215] 277
    }
    _2 = (int)SEQ_PTR(_settings_44883);
    _23813 = (int)*(((s1_ptr)_2)->base + 8);
    if (IS_SEQUENCE(_23813)){
            _23814 = SEQ_PTR(_23813)->length;
    }
    else {
        _23814 = 1;
    }
    _23813 = NOVALUE;
    if (_23814 == 0)
    {
        _23814 = NOVALUE;
        goto L4; // [227] 277
    }
    else{
        _23814 = NOVALUE;
    }

    /** 			writef(fh, "\t" & settings[SETUP_RC_COMPILER], { rc_file[D_ALTNAME], res_file[D_ALTNAME], exe_name[D_ALTNAME] })*/
    _2 = (int)SEQ_PTR(_settings_44883);
    _23816 = (int)*(((s1_ptr)_2)->base + 8);
    if (IS_SEQUENCE(_23815) && IS_ATOM(_23816)) {
        Ref(_23816);
        Append(&_23817, _23815, _23816);
    }
    else if (IS_ATOM(_23815) && IS_SEQUENCE(_23816)) {
    }
    else {
        Concat((object_ptr)&_23817, _23815, _23816);
    }
    _23816 = NOVALUE;
    _2 = (int)SEQ_PTR(_55rc_file_44330);
    _23818 = (int)*(((s1_ptr)_2)->base + 11);
    _2 = (int)SEQ_PTR(_55res_file_44336);
    _23819 = (int)*(((s1_ptr)_2)->base + 11);
    _2 = (int)SEQ_PTR(_55exe_name_44324);
    _23820 = (int)*(((s1_ptr)_2)->base + 11);
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_23818);
    *((int *)(_2+4)) = _23818;
    Ref(_23819);
    *((int *)(_2+8)) = _23819;
    Ref(_23820);
    *((int *)(_2+12)) = _23820;
    _23821 = MAKE_SEQ(_1);
    _23820 = NOVALUE;
    _23819 = NOVALUE;
    _23818 = NOVALUE;
    _8writef(_fh_44886, _23817, _23821, 0);
    _23817 = NOVALUE;
    _23821 = NOVALUE;
L4: 

    /** 		puts(fh, HOSTNL)*/
    EPuts(_fh_44886, _40HOSTNL_16403); // DJP 

    /** 		printf(fh, "%s-clean : .SYMBOLIC" & HOSTNL, { file0 })*/
    Concat((object_ptr)&_23823, _23822, _40HOSTNL_16403);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_57file0_43504);
    *((int *)(_2+4)) = _57file0_43504;
    _23824 = MAKE_SEQ(_1);
    EPrintf(_fh_44886, _23823, _23824);
    DeRefDS(_23823);
    _23823 = NOVALUE;
    DeRefDS(_23824);
    _23824 = NOVALUE;

    /** 		if length(res_file[D_ALTNAME]) then*/
    _2 = (int)SEQ_PTR(_55res_file_44336);
    _23825 = (int)*(((s1_ptr)_2)->base + 11);
    if (IS_SEQUENCE(_23825)){
            _23826 = SEQ_PTR(_23825)->length;
    }
    else {
        _23826 = 1;
    }
    _23825 = NOVALUE;
    if (_23826 == 0)
    {
        _23826 = NOVALUE;
        goto L5; // [315] 343
    }
    else{
        _23826 = NOVALUE;
    }

    /** 			printf(fh, "\tdel \"%s\"" & HOSTNL, { res_file[D_ALTNAME] })*/
    Concat((object_ptr)&_23828, _23827, _40HOSTNL_16403);
    _2 = (int)SEQ_PTR(_55res_file_44336);
    _23829 = (int)*(((s1_ptr)_2)->base + 11);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_23829);
    *((int *)(_2+4)) = _23829;
    _23830 = MAKE_SEQ(_1);
    _23829 = NOVALUE;
    EPrintf(_fh_44886, _23828, _23830);
    DeRefDS(_23828);
    _23828 = NOVALUE;
    DeRefDS(_23830);
    _23830 = NOVALUE;
L5: 

    /** 		for i = 1 to length(generated_files) do*/
    if (IS_SEQUENCE(_57generated_files_41680)){
            _23831 = SEQ_PTR(_57generated_files_41680)->length;
    }
    else {
        _23831 = 1;
    }
    {
        int _i_44968;
        _i_44968 = 1;
L6: 
        if (_i_44968 > _23831){
            goto L7; // [350] 403
        }

        /** 			if match(".o", generated_files[i]) then*/
        _2 = (int)SEQ_PTR(_57generated_files_41680);
        _23832 = (int)*(((s1_ptr)_2)->base + _i_44968);
        _23833 = e_match_from(_23058, _23832, 1);
        _23832 = NOVALUE;
        if (_23833 == 0)
        {
            _23833 = NOVALUE;
            goto L8; // [370] 396
        }
        else{
            _23833 = NOVALUE;
        }

        /** 				printf(fh, "\tdel \"%s\"" & HOSTNL, { generated_files[i] })*/
        Concat((object_ptr)&_23834, _23827, _40HOSTNL_16403);
        _2 = (int)SEQ_PTR(_57generated_files_41680);
        _23835 = (int)*(((s1_ptr)_2)->base + _i_44968);
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        RefDS(_23835);
        *((int *)(_2+4)) = _23835;
        _23836 = MAKE_SEQ(_1);
        _23835 = NOVALUE;
        EPrintf(_fh_44886, _23834, _23836);
        DeRefDS(_23834);
        _23834 = NOVALUE;
        DeRefDS(_23836);
        _23836 = NOVALUE;
L8: 

        /** 		end for*/
        _i_44968 = _i_44968 + 1;
        goto L6; // [398] 357
L7: 
        ;
    }

    /** 		puts(fh, HOSTNL)*/
    EPuts(_fh_44886, _40HOSTNL_16403); // DJP 

    /** 		printf(fh, "%s-clean-all : .SYMBOLIC" & HOSTNL, { file0 })*/
    Concat((object_ptr)&_23838, _23837, _40HOSTNL_16403);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_57file0_43504);
    *((int *)(_2+4)) = _57file0_43504;
    _23839 = MAKE_SEQ(_1);
    EPrintf(_fh_44886, _23838, _23839);
    DeRefDS(_23838);
    _23838 = NOVALUE;
    DeRefDS(_23839);
    _23839 = NOVALUE;

    /** 		printf(fh, "\tdel \"%s\"" & HOSTNL, { exe_name[D_ALTNAME] })*/
    Concat((object_ptr)&_23840, _23827, _40HOSTNL_16403);
    _2 = (int)SEQ_PTR(_55exe_name_44324);
    _23841 = (int)*(((s1_ptr)_2)->base + 11);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_23841);
    *((int *)(_2+4)) = _23841;
    _23842 = MAKE_SEQ(_1);
    _23841 = NOVALUE;
    EPrintf(_fh_44886, _23840, _23842);
    DeRefDS(_23840);
    _23840 = NOVALUE;
    DeRefDS(_23842);
    _23842 = NOVALUE;

    /** 		if length(res_file[D_ALTNAME]) then*/
    _2 = (int)SEQ_PTR(_55res_file_44336);
    _23843 = (int)*(((s1_ptr)_2)->base + 11);
    if (IS_SEQUENCE(_23843)){
            _23844 = SEQ_PTR(_23843)->length;
    }
    else {
        _23844 = 1;
    }
    _23843 = NOVALUE;
    if (_23844 == 0)
    {
        _23844 = NOVALUE;
        goto L9; // [465] 493
    }
    else{
        _23844 = NOVALUE;
    }

    /** 			printf(fh, "\tdel \"%s\"" & HOSTNL, { res_file[D_ALTNAME] })*/
    Concat((object_ptr)&_23845, _23827, _40HOSTNL_16403);
    _2 = (int)SEQ_PTR(_55res_file_44336);
    _23846 = (int)*(((s1_ptr)_2)->base + 11);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_23846);
    *((int *)(_2+4)) = _23846;
    _23847 = MAKE_SEQ(_1);
    _23846 = NOVALUE;
    EPrintf(_fh_44886, _23845, _23847);
    DeRefDS(_23845);
    _23845 = NOVALUE;
    DeRefDS(_23847);
    _23847 = NOVALUE;
L9: 

    /** 		for i = 1 to length(generated_files) do*/
    if (IS_SEQUENCE(_57generated_files_41680)){
            _23848 = SEQ_PTR(_57generated_files_41680)->length;
    }
    else {
        _23848 = 1;
    }
    {
        int _i_45001;
        _i_45001 = 1;
LA: 
        if (_i_45001 > _23848){
            goto LB; // [500] 536
        }

        /** 			printf(fh, "\tdel \"%s\"" & HOSTNL, { generated_files[i] })*/
        Concat((object_ptr)&_23849, _23827, _40HOSTNL_16403);
        _2 = (int)SEQ_PTR(_57generated_files_41680);
        _23850 = (int)*(((s1_ptr)_2)->base + _i_45001);
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        RefDS(_23850);
        *((int *)(_2+4)) = _23850;
        _23851 = MAKE_SEQ(_1);
        _23850 = NOVALUE;
        EPrintf(_fh_44886, _23849, _23851);
        DeRefDS(_23849);
        _23849 = NOVALUE;
        DeRefDS(_23851);
        _23851 = NOVALUE;

        /** 		end for*/
        _i_45001 = _i_45001 + 1;
        goto LA; // [531] 507
LB: 
        ;
    }

    /** 		puts(fh, HOSTNL)*/
    EPuts(_fh_44886, _40HOSTNL_16403); // DJP 

    /** 		puts(fh, ".c.obj : .autodepend" & HOSTNL)*/
    Concat((object_ptr)&_23853, _23852, _40HOSTNL_16403);
    EPuts(_fh_44886, _23853); // DJP 
    DeRefDS(_23853);
    _23853 = NOVALUE;

    /** 		puts(fh, "\t$(CC) $(CFLAGS) $<" & HOSTNL)*/
    Concat((object_ptr)&_23855, _23854, _40HOSTNL_16403);
    EPuts(_fh_44886, _23855); // DJP 
    DeRefDS(_23855);
    _23855 = NOVALUE;

    /** 		puts(fh, HOSTNL)*/
    EPuts(_fh_44886, _40HOSTNL_16403); // DJP 
    goto LC; // [572] 922
L3: 

    /** 		printf(fh, "%s: $(%s_OBJECTS) %s %s" & HOSTNL, { adjust_for_build_file(exe_name[D_ALTNAME]), upper(file0), user_library, rc_file[D_ALTNAME] })*/
    Concat((object_ptr)&_23857, _23856, _40HOSTNL_16403);
    _2 = (int)SEQ_PTR(_55exe_name_44324);
    _23858 = (int)*(((s1_ptr)_2)->base + 11);
    Ref(_23858);
    _23859 = _55adjust_for_build_file(_23858);
    _23858 = NOVALUE;
    RefDS(_57file0_43504);
    _23860 = _14upper(_57file0_43504);
    _2 = (int)SEQ_PTR(_55rc_file_44330);
    _23861 = (int)*(((s1_ptr)_2)->base + 11);
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _23859;
    *((int *)(_2+8)) = _23860;
    RefDS(_57user_library_41688);
    *((int *)(_2+12)) = _57user_library_41688;
    Ref(_23861);
    *((int *)(_2+16)) = _23861;
    _23862 = MAKE_SEQ(_1);
    _23861 = NOVALUE;
    _23860 = NOVALUE;
    _23859 = NOVALUE;
    EPrintf(_fh_44886, _23857, _23862);
    DeRefDS(_23857);
    _23857 = NOVALUE;
    DeRefDS(_23862);
    _23862 = NOVALUE;

    /** 		if length(rc_file[D_ALTNAME]) then*/
    _2 = (int)SEQ_PTR(_55rc_file_44330);
    _23863 = (int)*(((s1_ptr)_2)->base + 11);
    if (IS_SEQUENCE(_23863)){
            _23864 = SEQ_PTR(_23863)->length;
    }
    else {
        _23864 = 1;
    }
    _23863 = NOVALUE;
    if (_23864 == 0)
    {
        _23864 = NOVALUE;
        goto LD; // [635] 679
    }
    else{
        _23864 = NOVALUE;
    }

    /** 			writef(fh, "\t" & settings[SETUP_RC_COMPILER] & HOSTNL, { rc_file[D_ALTNAME], res_file[D_ALTNAME] })*/
    _2 = (int)SEQ_PTR(_settings_44883);
    _23865 = (int)*(((s1_ptr)_2)->base + 8);
    {
        int concat_list[3];

        concat_list[0] = _40HOSTNL_16403;
        concat_list[1] = _23865;
        concat_list[2] = _23815;
        Concat_N((object_ptr)&_23866, concat_list, 3);
    }
    _23865 = NOVALUE;
    _2 = (int)SEQ_PTR(_55rc_file_44330);
    _23867 = (int)*(((s1_ptr)_2)->base + 11);
    _2 = (int)SEQ_PTR(_55res_file_44336);
    _23868 = (int)*(((s1_ptr)_2)->base + 11);
    Ref(_23868);
    Ref(_23867);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _23867;
    ((int *)_2)[2] = _23868;
    _23869 = MAKE_SEQ(_1);
    _23868 = NOVALUE;
    _23867 = NOVALUE;
    _8writef(_fh_44886, _23866, _23869, 0);
    _23866 = NOVALUE;
    _23869 = NOVALUE;
LD: 

    /** 		printf(fh, "\t$(LINKER) -o %s $(%s_OBJECTS) %s $(LFLAGS)" & HOSTNL, {*/
    Concat((object_ptr)&_23871, _23870, _40HOSTNL_16403);
    _2 = (int)SEQ_PTR(_55exe_name_44324);
    _23872 = (int)*(((s1_ptr)_2)->base + 11);
    RefDS(_57file0_43504);
    _23873 = _14upper(_57file0_43504);
    _2 = (int)SEQ_PTR(_55res_file_44336);
    _23874 = (int)*(((s1_ptr)_2)->base + 11);
    if (IS_SEQUENCE(_23874)){
            _23875 = SEQ_PTR(_23874)->length;
    }
    else {
        _23875 = 1;
    }
    _23874 = NOVALUE;
    _2 = (int)SEQ_PTR(_55res_file_44336);
    _23876 = (int)*(((s1_ptr)_2)->base + 11);
    Ref(_23876);
    RefDS(_22023);
    _23877 = _56iif(_23875, _23876, _22023);
    _23875 = NOVALUE;
    _23876 = NOVALUE;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_23872);
    *((int *)(_2+4)) = _23872;
    *((int *)(_2+8)) = _23873;
    *((int *)(_2+12)) = _23877;
    _23878 = MAKE_SEQ(_1);
    _23877 = NOVALUE;
    _23873 = NOVALUE;
    _23872 = NOVALUE;
    EPrintf(_fh_44886, _23871, _23878);
    DeRefDS(_23871);
    _23871 = NOVALUE;
    DeRefDS(_23878);
    _23878 = NOVALUE;

    /** 		puts(fh, HOSTNL)*/
    EPuts(_fh_44886, _40HOSTNL_16403); // DJP 

    /** 		printf(fh, ".PHONY: %s-clean %s-clean-all" & HOSTNL, { file0, file0 })*/
    Concat((object_ptr)&_23880, _23879, _40HOSTNL_16403);
    RefDS(_57file0_43504);
    RefDS(_57file0_43504);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _57file0_43504;
    ((int *)_2)[2] = _57file0_43504;
    _23881 = MAKE_SEQ(_1);
    EPrintf(_fh_44886, _23880, _23881);
    DeRefDS(_23880);
    _23880 = NOVALUE;
    DeRefDS(_23881);
    _23881 = NOVALUE;

    /** 		puts(fh, HOSTNL)*/
    EPuts(_fh_44886, _40HOSTNL_16403); // DJP 

    /** 		printf(fh, "%s-clean:" & HOSTNL, { file0 })*/
    Concat((object_ptr)&_23883, _23882, _40HOSTNL_16403);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_57file0_43504);
    *((int *)(_2+4)) = _57file0_43504;
    _23884 = MAKE_SEQ(_1);
    EPrintf(_fh_44886, _23883, _23884);
    DeRefDS(_23883);
    _23883 = NOVALUE;
    DeRefDS(_23884);
    _23884 = NOVALUE;

    /** 		printf(fh, "\trm -rf $(%s_OBJECTS) %s" & HOSTNL, { upper(file0), res_file[D_ALTNAME] })*/
    Concat((object_ptr)&_23886, _23885, _40HOSTNL_16403);
    RefDS(_57file0_43504);
    _23887 = _14upper(_57file0_43504);
    _2 = (int)SEQ_PTR(_55res_file_44336);
    _23888 = (int)*(((s1_ptr)_2)->base + 11);
    Ref(_23888);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _23887;
    ((int *)_2)[2] = _23888;
    _23889 = MAKE_SEQ(_1);
    _23888 = NOVALUE;
    _23887 = NOVALUE;
    EPrintf(_fh_44886, _23886, _23889);
    DeRefDS(_23886);
    _23886 = NOVALUE;
    DeRefDS(_23889);
    _23889 = NOVALUE;

    /** 		puts(fh, HOSTNL)*/
    EPuts(_fh_44886, _40HOSTNL_16403); // DJP 

    /** 		printf(fh, "%s-clean-all: %s-clean" & HOSTNL, { file0, file0 })*/
    Concat((object_ptr)&_23891, _23890, _40HOSTNL_16403);
    RefDS(_57file0_43504);
    RefDS(_57file0_43504);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _57file0_43504;
    ((int *)_2)[2] = _57file0_43504;
    _23892 = MAKE_SEQ(_1);
    EPrintf(_fh_44886, _23891, _23892);
    DeRefDS(_23891);
    _23891 = NOVALUE;
    DeRefDS(_23892);
    _23892 = NOVALUE;

    /** 		printf(fh, "\trm -rf $(%s_SOURCES) %s %s" & HOSTNL, { upper(file0), res_file[D_ALTNAME], exe_name[D_ALTNAME] })*/
    Concat((object_ptr)&_23894, _23893, _40HOSTNL_16403);
    RefDS(_57file0_43504);
    _23895 = _14upper(_57file0_43504);
    _2 = (int)SEQ_PTR(_55res_file_44336);
    _23896 = (int)*(((s1_ptr)_2)->base + 11);
    _2 = (int)SEQ_PTR(_55exe_name_44324);
    _23897 = (int)*(((s1_ptr)_2)->base + 11);
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _23895;
    Ref(_23896);
    *((int *)(_2+8)) = _23896;
    Ref(_23897);
    *((int *)(_2+12)) = _23897;
    _23898 = MAKE_SEQ(_1);
    _23897 = NOVALUE;
    _23896 = NOVALUE;
    _23895 = NOVALUE;
    EPrintf(_fh_44886, _23894, _23898);
    DeRefDS(_23894);
    _23894 = NOVALUE;
    DeRefDS(_23898);
    _23898 = NOVALUE;

    /** 		puts(fh, HOSTNL)*/
    EPuts(_fh_44886, _40HOSTNL_16403); // DJP 

    /** 		puts(fh, "%.o: %.c" & HOSTNL)*/
    Concat((object_ptr)&_23900, _23899, _40HOSTNL_16403);
    EPuts(_fh_44886, _23900); // DJP 
    DeRefDS(_23900);
    _23900 = NOVALUE;

    /** 		puts(fh, "\t$(CC) $(CFLAGS) $*.c -o $*.o" & HOSTNL)*/
    Concat((object_ptr)&_23902, _23901, _40HOSTNL_16403);
    EPuts(_fh_44886, _23902); // DJP 
    DeRefDS(_23902);
    _23902 = NOVALUE;

    /** 		puts(fh, HOSTNL)*/
    EPuts(_fh_44886, _40HOSTNL_16403); // DJP 
LC: 

    /** 	close(fh)*/
    EClose(_fh_44886);

    /** end procedure*/
    DeRef(_settings_44883);
    _23810 = NOVALUE;
    _23813 = NOVALUE;
    _23825 = NOVALUE;
    _23843 = NOVALUE;
    _23863 = NOVALUE;
    _23874 = NOVALUE;
    return;
    ;
}


void _55write_makefile_partial()
{
    int _settings_45110 = NOVALUE;
    int _fh_45112 = NOVALUE;
    int _23904 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence settings = setup_build()*/
    _0 = _settings_45110;
    _settings_45110 = _55setup_build();
    DeRef(_0);

    /** 	integer fh = open(output_dir & file0 & ".mak", "wb")*/
    {
        int concat_list[3];

        concat_list[0] = _23781;
        concat_list[1] = _57file0_43504;
        concat_list[2] = _57output_dir_41689;
        Concat_N((object_ptr)&_23904, concat_list, 3);
    }
    _fh_45112 = EOpen(_23904, _23706, 0);
    DeRefDS(_23904);
    _23904 = NOVALUE;

    /** 	write_makefile_srcobj_list(fh)*/
    _55write_makefile_srcobj_list(_fh_45112);

    /** 	close(fh)*/
    EClose(_fh_45112);

    /** end procedure*/
    DeRefDS(_settings_45110);
    return;
    ;
}


void _55build_direct(int _link_only_45119, int _the_file0_45120)
{
    int _cmd_45126 = NOVALUE;
    int _objs_45127 = NOVALUE;
    int _settings_45128 = NOVALUE;
    int _cwd_45130 = NOVALUE;
    int _status_45133 = NOVALUE;
    int _link_files_45162 = NOVALUE;
    int _pdone_45188 = NOVALUE;
    int _files_45234 = NOVALUE;
    int _31669 = NOVALUE;
    int _31668 = NOVALUE;
    int _31667 = NOVALUE;
    int _31666 = NOVALUE;
    int _31665 = NOVALUE;
    int _31664 = NOVALUE;
    int _31663 = NOVALUE;
    int _24052 = NOVALUE;
    int _24051 = NOVALUE;
    int _24049 = NOVALUE;
    int _24048 = NOVALUE;
    int _24047 = NOVALUE;
    int _24046 = NOVALUE;
    int _24045 = NOVALUE;
    int _24044 = NOVALUE;
    int _24043 = NOVALUE;
    int _24042 = NOVALUE;
    int _24040 = NOVALUE;
    int _24039 = NOVALUE;
    int _24038 = NOVALUE;
    int _24037 = NOVALUE;
    int _24033 = NOVALUE;
    int _24032 = NOVALUE;
    int _24031 = NOVALUE;
    int _24030 = NOVALUE;
    int _24029 = NOVALUE;
    int _24028 = NOVALUE;
    int _24027 = NOVALUE;
    int _24026 = NOVALUE;
    int _24025 = NOVALUE;
    int _24024 = NOVALUE;
    int _24023 = NOVALUE;
    int _24022 = NOVALUE;
    int _24021 = NOVALUE;
    int _24020 = NOVALUE;
    int _24019 = NOVALUE;
    int _24016 = NOVALUE;
    int _24015 = NOVALUE;
    int _24014 = NOVALUE;
    int _24013 = NOVALUE;
    int _24010 = NOVALUE;
    int _24008 = NOVALUE;
    int _24007 = NOVALUE;
    int _24006 = NOVALUE;
    int _24005 = NOVALUE;
    int _24004 = NOVALUE;
    int _24003 = NOVALUE;
    int _24000 = NOVALUE;
    int _23999 = NOVALUE;
    int _23995 = NOVALUE;
    int _23994 = NOVALUE;
    int _23993 = NOVALUE;
    int _23989 = NOVALUE;
    int _23988 = NOVALUE;
    int _23987 = NOVALUE;
    int _23986 = NOVALUE;
    int _23985 = NOVALUE;
    int _23984 = NOVALUE;
    int _23983 = NOVALUE;
    int _23982 = NOVALUE;
    int _23981 = NOVALUE;
    int _23980 = NOVALUE;
    int _23979 = NOVALUE;
    int _23978 = NOVALUE;
    int _23976 = NOVALUE;
    int _23975 = NOVALUE;
    int _23974 = NOVALUE;
    int _23973 = NOVALUE;
    int _23972 = NOVALUE;
    int _23970 = NOVALUE;
    int _23969 = NOVALUE;
    int _23968 = NOVALUE;
    int _23967 = NOVALUE;
    int _23966 = NOVALUE;
    int _23964 = NOVALUE;
    int _23962 = NOVALUE;
    int _23961 = NOVALUE;
    int _23960 = NOVALUE;
    int _23959 = NOVALUE;
    int _23957 = NOVALUE;
    int _23956 = NOVALUE;
    int _23955 = NOVALUE;
    int _23952 = NOVALUE;
    int _23951 = NOVALUE;
    int _23950 = NOVALUE;
    int _23949 = NOVALUE;
    int _23948 = NOVALUE;
    int _23947 = NOVALUE;
    int _23946 = NOVALUE;
    int _23945 = NOVALUE;
    int _23944 = NOVALUE;
    int _23943 = NOVALUE;
    int _23940 = NOVALUE;
    int _23939 = NOVALUE;
    int _23936 = NOVALUE;
    int _23934 = NOVALUE;
    int _23933 = NOVALUE;
    int _23932 = NOVALUE;
    int _23931 = NOVALUE;
    int _23928 = NOVALUE;
    int _23927 = NOVALUE;
    int _23926 = NOVALUE;
    int _23925 = NOVALUE;
    int _23923 = NOVALUE;
    int _23922 = NOVALUE;
    int _23921 = NOVALUE;
    int _23920 = NOVALUE;
    int _23919 = NOVALUE;
    int _23916 = NOVALUE;
    int _23910 = NOVALUE;
    int _23906 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_link_only_45119)) {
        _1 = (long)(DBL_PTR(_link_only_45119)->dbl);
        DeRefDS(_link_only_45119);
        _link_only_45119 = _1;
    }

    /** 	if length(the_file0) then*/
    if (IS_SEQUENCE(_the_file0_45120)){
            _23906 = SEQ_PTR(_the_file0_45120)->length;
    }
    else {
        _23906 = 1;
    }
    if (_23906 == 0)
    {
        _23906 = NOVALUE;
        goto L1; // [10] 22
    }
    else{
        _23906 = NOVALUE;
    }

    /** 		file0 = filebase(the_file0)*/
    RefDS(_the_file0_45120);
    _0 = _17filebase(_the_file0_45120);
    DeRef(_57file0_43504);
    _57file0_43504 = _0;
L1: 

    /** 	sequence cmd, objs = "", settings = setup_build(), cwd = current_dir()*/
    RefDS(_22023);
    DeRef(_objs_45127);
    _objs_45127 = _22023;
    _0 = _settings_45128;
    _settings_45128 = _55setup_build();
    DeRef(_0);
    _0 = _cwd_45130;
    _cwd_45130 = _17current_dir();
    DeRef(_0);

    /** 	integer status*/

    /** 	ensure_exename(settings[SETUP_EXE_EXT])*/
    _2 = (int)SEQ_PTR(_settings_45128);
    _23910 = (int)*(((s1_ptr)_2)->base + 6);
    Ref(_23910);
    _55ensure_exename(_23910);
    _23910 = NOVALUE;

    /** 	if not link_only then*/
    if (_link_only_45119 != 0)
    goto L2; // [52] 120

    /** 		switch compiler_type do*/
    _0 = _55compiler_type_44322;
    switch ( _0 ){ 

        /** 			case COMPILER_GCC then*/
        case 1:

        /** 				if not silent then*/
        if (_35silent_16359 != 0)
        goto L3; // [72] 119

        /** 					ShowMsg(1, 176, {"GCC"})*/
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        RefDS(_23915);
        *((int *)(_2+4)) = _23915;
        _23916 = MAKE_SEQ(_1);
        _45ShowMsg(1, 176, _23916, 1);
        _23916 = NOVALUE;
        goto L3; // [88] 119

        /** 			case COMPILER_WATCOM then*/
        case 2:

        /** 				write_objlink_file()*/
        _55write_objlink_file();

        /** 				if not silent then*/
        if (_35silent_16359 != 0)
        goto L4; // [102] 118

        /** 					ShowMsg(1, 176, {"Watcom"})*/
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        RefDS(_23918);
        *((int *)(_2+4)) = _23918;
        _23919 = MAKE_SEQ(_1);
        _45ShowMsg(1, 176, _23919, 1);
        _23919 = NOVALUE;
L4: 
    ;}L3: 
L2: 

    /** 	if sequence(output_dir) and length(output_dir) > 0 then*/
    _23920 = 1;
    if (_23920 == 0) {
        goto L5; // [127] 155
    }
    if (IS_SEQUENCE(_57output_dir_41689)){
            _23922 = SEQ_PTR(_57output_dir_41689)->length;
    }
    else {
        _23922 = 1;
    }
    _23923 = (_23922 > 0);
    _23922 = NOVALUE;
    if (_23923 == 0)
    {
        DeRef(_23923);
        _23923 = NOVALUE;
        goto L5; // [141] 155
    }
    else{
        DeRef(_23923);
        _23923 = NOVALUE;
    }

    /** 		chdir(output_dir)*/
    RefDS(_57output_dir_41689);
    _31669 = _17chdir(_57output_dir_41689);
    DeRef(_31669);
    _31669 = NOVALUE;
L5: 

    /** 	sequence link_files = {}*/
    RefDS(_22023);
    DeRef(_link_files_45162);
    _link_files_45162 = _22023;

    /** 	if not link_only then*/
    if (_link_only_45119 != 0)
    goto L6; // [164] 468

    /** 		for i = 1 to length(generated_files) do*/
    if (IS_SEQUENCE(_57generated_files_41680)){
            _23925 = SEQ_PTR(_57generated_files_41680)->length;
    }
    else {
        _23925 = 1;
    }
    {
        int _i_45166;
        _i_45166 = 1;
L7: 
        if (_i_45166 > _23925){
            goto L8; // [174] 465
        }

        /** 			if generated_files[i][$] = 'c' then*/
        _2 = (int)SEQ_PTR(_57generated_files_41680);
        _23926 = (int)*(((s1_ptr)_2)->base + _i_45166);
        if (IS_SEQUENCE(_23926)){
                _23927 = SEQ_PTR(_23926)->length;
        }
        else {
            _23927 = 1;
        }
        _2 = (int)SEQ_PTR(_23926);
        _23928 = (int)*(((s1_ptr)_2)->base + _23927);
        _23926 = NOVALUE;
        if (binary_op_a(NOTEQ, _23928, 99)){
            _23928 = NOVALUE;
            goto L9; // [196] 424
        }
        _23928 = NOVALUE;

        /** 				cmd = sprintf("%s %s %s", { settings[SETUP_CEXE], settings[SETUP_CFLAGS],*/
        _2 = (int)SEQ_PTR(_settings_45128);
        _23931 = (int)*(((s1_ptr)_2)->base + 1);
        _2 = (int)SEQ_PTR(_settings_45128);
        _23932 = (int)*(((s1_ptr)_2)->base + 2);
        _2 = (int)SEQ_PTR(_57generated_files_41680);
        _23933 = (int)*(((s1_ptr)_2)->base + _i_45166);
        _1 = NewS1(3);
        _2 = (int)((s1_ptr)_1)->base;
        Ref(_23931);
        *((int *)(_2+4)) = _23931;
        Ref(_23932);
        *((int *)(_2+8)) = _23932;
        RefDS(_23933);
        *((int *)(_2+12)) = _23933;
        _23934 = MAKE_SEQ(_1);
        _23933 = NOVALUE;
        _23932 = NOVALUE;
        _23931 = NOVALUE;
        DeRef(_cmd_45126);
        _cmd_45126 = EPrintf(-9999999, _23930, _23934);
        DeRefDS(_23934);
        _23934 = NOVALUE;

        /** 				link_files = append(link_files, generated_files[i])*/
        _2 = (int)SEQ_PTR(_57generated_files_41680);
        _23936 = (int)*(((s1_ptr)_2)->base + _i_45166);
        RefDS(_23936);
        Append(&_link_files_45162, _link_files_45162, _23936);
        _23936 = NOVALUE;

        /** 				if not silent then*/
        if (_35silent_16359 != 0)
        goto LA; // [242] 364

        /** 					atom pdone = 100 * (i / length(generated_files))*/
        if (IS_SEQUENCE(_57generated_files_41680)){
                _23939 = SEQ_PTR(_57generated_files_41680)->length;
        }
        else {
            _23939 = 1;
        }
        _23940 = (_i_45166 % _23939) ? NewDouble((double)_i_45166 / _23939) : (_i_45166 / _23939);
        _23939 = NOVALUE;
        DeRef(_pdone_45188);
        if (IS_ATOM_INT(_23940)) {
            if (_23940 <= INT15 && _23940 >= -INT15)
            _pdone_45188 = 100 * _23940;
            else
            _pdone_45188 = NewDouble(100 * (double)_23940);
        }
        else {
            _pdone_45188 = NewDouble((double)100 * DBL_PTR(_23940)->dbl);
        }
        DeRef(_23940);
        _23940 = NOVALUE;

        /** 					if not verbose then*/
        if (_35verbose_16362 != 0)
        goto LB; // [264] 350

        /** 						if 0 and outdated_files[i] = 0 and force_build = 0 then*/
        if (0 == 0) {
            _23943 = 0;
            goto LC; // [269] 287
        }
        _2 = (int)SEQ_PTR(_57outdated_files_41681);
        _23944 = (int)*(((s1_ptr)_2)->base + _i_45166);
        if (IS_ATOM_INT(_23944)) {
            _23945 = (_23944 == 0);
        }
        else {
            _23945 = binary_op(EQUALS, _23944, 0);
        }
        _23944 = NOVALUE;
        if (IS_ATOM_INT(_23945))
        _23943 = (_23945 != 0);
        else
        _23943 = DBL_PTR(_23945)->dbl != 0.0;
LC: 
        if (_23943 == 0) {
            goto LD; // [287] 328
        }
        _23947 = (_55force_build_44341 == 0);
        if (_23947 == 0)
        {
            DeRef(_23947);
            _23947 = NOVALUE;
            goto LD; // [298] 328
        }
        else{
            DeRef(_23947);
            _23947 = NOVALUE;
        }

        /** 							ShowMsg(1, 325, { pdone, generated_files[i] })*/
        _2 = (int)SEQ_PTR(_57generated_files_41680);
        _23948 = (int)*(((s1_ptr)_2)->base + _i_45166);
        RefDS(_23948);
        Ref(_pdone_45188);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _pdone_45188;
        ((int *)_2)[2] = _23948;
        _23949 = MAKE_SEQ(_1);
        _23948 = NOVALUE;
        _45ShowMsg(1, 325, _23949, 1);
        _23949 = NOVALUE;

        /** 							continue*/
        DeRef(_pdone_45188);
        _pdone_45188 = NOVALUE;
        goto LE; // [323] 460
        goto LF; // [325] 363
LD: 

        /** 							ShowMsg(1, 163, { pdone, generated_files[i] })*/
        _2 = (int)SEQ_PTR(_57generated_files_41680);
        _23950 = (int)*(((s1_ptr)_2)->base + _i_45166);
        RefDS(_23950);
        Ref(_pdone_45188);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _pdone_45188;
        ((int *)_2)[2] = _23950;
        _23951 = MAKE_SEQ(_1);
        _23950 = NOVALUE;
        _45ShowMsg(1, 163, _23951, 1);
        _23951 = NOVALUE;
        goto LF; // [347] 363
LB: 

        /** 						ShowMsg(1, 163, { pdone, cmd })*/
        RefDS(_cmd_45126);
        Ref(_pdone_45188);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _pdone_45188;
        ((int *)_2)[2] = _cmd_45126;
        _23952 = MAKE_SEQ(_1);
        _45ShowMsg(1, 163, _23952, 1);
        _23952 = NOVALUE;
LF: 
LA: 
        DeRef(_pdone_45188);
        _pdone_45188 = NOVALUE;

        /** 				status = system_exec(cmd, 0)*/
        _status_45133 = system_exec_call(_cmd_45126, 0);

        /** 				if status != 0 then*/
        if (_status_45133 == 0)
        goto L10; // [374] 458

        /** 					ShowMsg(2, 164, { generated_files[i] })*/
        _2 = (int)SEQ_PTR(_57generated_files_41680);
        _23955 = (int)*(((s1_ptr)_2)->base + _i_45166);
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        RefDS(_23955);
        *((int *)(_2+4)) = _23955;
        _23956 = MAKE_SEQ(_1);
        _23955 = NOVALUE;
        _45ShowMsg(2, 164, _23956, 1);
        _23956 = NOVALUE;

        /** 					ShowMsg(2, 165, { status, cmd })*/
        RefDS(_cmd_45126);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _status_45133;
        ((int *)_2)[2] = _cmd_45126;
        _23957 = MAKE_SEQ(_1);
        _45ShowMsg(2, 165, _23957, 1);
        _23957 = NOVALUE;

        /** 					goto "build_direct_cleanup"*/
        goto G11;
        goto L10; // [421] 458
L9: 

        /** 			elsif match(".o", generated_files[i]) then*/
        _2 = (int)SEQ_PTR(_57generated_files_41680);
        _23959 = (int)*(((s1_ptr)_2)->base + _i_45166);
        _23960 = e_match_from(_23058, _23959, 1);
        _23959 = NOVALUE;
        if (_23960 == 0)
        {
            _23960 = NOVALUE;
            goto L12; // [437] 457
        }
        else{
            _23960 = NOVALUE;
        }

        /** 				objs &= " " & generated_files[i]*/
        _2 = (int)SEQ_PTR(_57generated_files_41680);
        _23961 = (int)*(((s1_ptr)_2)->base + _i_45166);
        Concat((object_ptr)&_23962, _23298, _23961);
        _23961 = NOVALUE;
        Concat((object_ptr)&_objs_45127, _objs_45127, _23962);
        DeRefDS(_23962);
        _23962 = NOVALUE;
L12: 
L10: 

        /** 		end for*/
LE: 
        _i_45166 = _i_45166 + 1;
        goto L7; // [460] 181
L8: 
        ;
    }
    goto L13; // [465] 527
L6: 

    /** 		object files = read_lines(file0 & ".bld")*/
    Concat((object_ptr)&_23964, _57file0_43504, _23486);
    _0 = _files_45234;
    _files_45234 = _8read_lines(_23964);
    DeRef(_0);
    _23964 = NOVALUE;

    /** 		for i = 1 to length(files) do*/
    if (IS_SEQUENCE(_files_45234)){
            _23966 = SEQ_PTR(_files_45234)->length;
    }
    else {
        _23966 = 1;
    }
    {
        int _i_45240;
        _i_45240 = 1;
L14: 
        if (_i_45240 > _23966){
            goto L15; // [485] 524
        }

        /** 			objs &= " " & filebase(files[i]) & "." & settings[SETUP_OBJ_EXT]*/
        _2 = (int)SEQ_PTR(_files_45234);
        _23967 = (int)*(((s1_ptr)_2)->base + _i_45240);
        Ref(_23967);
        _23968 = _17filebase(_23967);
        _23967 = NOVALUE;
        _2 = (int)SEQ_PTR(_settings_45128);
        _23969 = (int)*(((s1_ptr)_2)->base + 5);
        {
            int concat_list[4];

            concat_list[0] = _23969;
            concat_list[1] = _23097;
            concat_list[2] = _23968;
            concat_list[3] = _23298;
            Concat_N((object_ptr)&_23970, concat_list, 4);
        }
        _23969 = NOVALUE;
        DeRef(_23968);
        _23968 = NOVALUE;
        Concat((object_ptr)&_objs_45127, _objs_45127, _23970);
        DeRefDS(_23970);
        _23970 = NOVALUE;

        /** 		end for*/
        _i_45240 = _i_45240 + 1;
        goto L14; // [519] 492
L15: 
        ;
    }
    DeRef(_files_45234);
    _files_45234 = NOVALUE;
L13: 

    /** 	if keep and not link_only and length(link_files) then*/
    if (_57keep_41683 == 0) {
        _23972 = 0;
        goto L16; // [531] 542
    }
    _23973 = (_link_only_45119 == 0);
    _23972 = (_23973 != 0);
L16: 
    if (_23972 == 0) {
        goto L17; // [542] 571
    }
    if (IS_SEQUENCE(_link_files_45162)){
            _23975 = SEQ_PTR(_link_files_45162)->length;
    }
    else {
        _23975 = 1;
    }
    if (_23975 == 0)
    {
        _23975 = NOVALUE;
        goto L17; // [550] 571
    }
    else{
        _23975 = NOVALUE;
    }

    /** 		write_lines(file0 & ".bld", link_files)*/
    Concat((object_ptr)&_23976, _57file0_43504, _23486);
    RefDS(_link_files_45162);
    _31668 = _8write_lines(_23976, _link_files_45162);
    _23976 = NOVALUE;
    DeRef(_31668);
    _31668 = NOVALUE;
    goto L18; // [568] 595
L17: 

    /** 	elsif keep = 0 then*/
    if (_57keep_41683 != 0)
    goto L19; // [575] 594

    /** 		delete_file(file0 & ".bld")*/
    Concat((object_ptr)&_23978, _57file0_43504, _23486);
    _31667 = _17delete_file(_23978);
    _23978 = NOVALUE;
    DeRef(_31667);
    _31667 = NOVALUE;
L19: 
L18: 

    /** 	if length(rc_file[D_ALTNAME]) and length(settings[SETUP_RC_COMPILER]) and compiler_type = COMPILER_GCC then*/
    _2 = (int)SEQ_PTR(_55rc_file_44330);
    _23979 = (int)*(((s1_ptr)_2)->base + 11);
    if (IS_SEQUENCE(_23979)){
            _23980 = SEQ_PTR(_23979)->length;
    }
    else {
        _23980 = 1;
    }
    _23979 = NOVALUE;
    if (_23980 == 0) {
        _23981 = 0;
        goto L1A; // [608] 623
    }
    _2 = (int)SEQ_PTR(_settings_45128);
    _23982 = (int)*(((s1_ptr)_2)->base + 8);
    if (IS_SEQUENCE(_23982)){
            _23983 = SEQ_PTR(_23982)->length;
    }
    else {
        _23983 = 1;
    }
    _23982 = NOVALUE;
    _23981 = (_23983 != 0);
L1A: 
    if (_23981 == 0) {
        goto L1B; // [623] 724
    }
    _23985 = (_55compiler_type_44322 == 1);
    if (_23985 == 0)
    {
        DeRef(_23985);
        _23985 = NOVALUE;
        goto L1B; // [634] 724
    }
    else{
        DeRef(_23985);
        _23985 = NOVALUE;
    }

    /** 		cmd = text:format(settings[SETUP_RC_COMPILER], { rc_file[D_ALTNAME], res_file[D_ALTNAME] })*/
    _2 = (int)SEQ_PTR(_settings_45128);
    _23986 = (int)*(((s1_ptr)_2)->base + 8);
    _2 = (int)SEQ_PTR(_55rc_file_44330);
    _23987 = (int)*(((s1_ptr)_2)->base + 11);
    _2 = (int)SEQ_PTR(_55res_file_44336);
    _23988 = (int)*(((s1_ptr)_2)->base + 11);
    Ref(_23988);
    Ref(_23987);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _23987;
    ((int *)_2)[2] = _23988;
    _23989 = MAKE_SEQ(_1);
    _23988 = NOVALUE;
    _23987 = NOVALUE;
    Ref(_23986);
    _0 = _cmd_45126;
    _cmd_45126 = _14format(_23986, _23989);
    DeRef(_0);
    _23986 = NOVALUE;
    _23989 = NOVALUE;

    /** 		status = system_exec(cmd, 0)*/
    _status_45133 = system_exec_call(_cmd_45126, 0);

    /** 		if status != 0 then*/
    if (_status_45133 == 0)
    goto L1C; // [678] 723

    /** 			ShowMsg(2, 350, { rc_file[D_NAME] })*/
    _2 = (int)SEQ_PTR(_55rc_file_44330);
    _23993 = (int)*(((s1_ptr)_2)->base + 1);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_23993);
    *((int *)(_2+4)) = _23993;
    _23994 = MAKE_SEQ(_1);
    _23993 = NOVALUE;
    _45ShowMsg(2, 350, _23994, 1);
    _23994 = NOVALUE;

    /** 			ShowMsg(2, 169, { status, cmd })*/
    RefDS(_cmd_45126);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _status_45133;
    ((int *)_2)[2] = _cmd_45126;
    _23995 = MAKE_SEQ(_1);
    _45ShowMsg(2, 169, _23995, 1);
    _23995 = NOVALUE;

    /** 			goto "build_direct_cleanup"*/
    goto G11;
L1C: 
L1B: 

    /** 	switch compiler_type do*/
    _0 = _55compiler_type_44322;
    switch ( _0 ){ 

        /** 		case COMPILER_WATCOM then*/
        case 2:

        /** 			cmd = sprintf("%s @%s.lnk", { settings[SETUP_LEXE], file0 })*/
        _2 = (int)SEQ_PTR(_settings_45128);
        _23999 = (int)*(((s1_ptr)_2)->base + 3);
        RefDS(_57file0_43504);
        Ref(_23999);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _23999;
        ((int *)_2)[2] = _57file0_43504;
        _24000 = MAKE_SEQ(_1);
        _23999 = NOVALUE;
        DeRef(_cmd_45126);
        _cmd_45126 = EPrintf(-9999999, _23998, _24000);
        DeRefDS(_24000);
        _24000 = NOVALUE;
        goto L1D; // [753] 828

        /** 		case COMPILER_GCC then*/
        case 1:

        /** 			cmd = sprintf("%s -o %s %s %s %s", { */
        _2 = (int)SEQ_PTR(_settings_45128);
        _24003 = (int)*(((s1_ptr)_2)->base + 3);
        _2 = (int)SEQ_PTR(_55exe_name_44324);
        _24004 = (int)*(((s1_ptr)_2)->base + 11);
        Ref(_24004);
        _24005 = _55adjust_for_build_file(_24004);
        _24004 = NOVALUE;
        _2 = (int)SEQ_PTR(_55res_file_44336);
        _24006 = (int)*(((s1_ptr)_2)->base + 11);
        _2 = (int)SEQ_PTR(_settings_45128);
        _24007 = (int)*(((s1_ptr)_2)->base + 4);
        _1 = NewS1(5);
        _2 = (int)((s1_ptr)_1)->base;
        Ref(_24003);
        *((int *)(_2+4)) = _24003;
        *((int *)(_2+8)) = _24005;
        RefDS(_objs_45127);
        *((int *)(_2+12)) = _objs_45127;
        Ref(_24006);
        *((int *)(_2+16)) = _24006;
        Ref(_24007);
        *((int *)(_2+20)) = _24007;
        _24008 = MAKE_SEQ(_1);
        _24007 = NOVALUE;
        _24006 = NOVALUE;
        _24005 = NOVALUE;
        _24003 = NOVALUE;
        DeRef(_cmd_45126);
        _cmd_45126 = EPrintf(-9999999, _24002, _24008);
        DeRefDS(_24008);
        _24008 = NOVALUE;
        goto L1D; // [801] 828

        /** 		case else*/
        default:

        /** 			ShowMsg(2, 167, { compiler_type })*/
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = _55compiler_type_44322;
        _24010 = MAKE_SEQ(_1);
        _45ShowMsg(2, 167, _24010, 1);
        _24010 = NOVALUE;

        /** 			goto "build_direct_cleanup"*/
        goto G11;
    ;}L1D: 

    /** 	if not silent then*/
    if (_35silent_16359 != 0)
    goto L1E; // [832] 886

    /** 		if not verbose then*/
    if (_35verbose_16362 != 0)
    goto L1F; // [839] 870

    /** 			ShowMsg(1, 166, { abbreviate_path(exe_name[D_NAME]) })*/
    _2 = (int)SEQ_PTR(_55exe_name_44324);
    _24013 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_24013);
    RefDS(_22023);
    _24014 = _17abbreviate_path(_24013, _22023);
    _24013 = NOVALUE;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _24014;
    _24015 = MAKE_SEQ(_1);
    _24014 = NOVALUE;
    _45ShowMsg(1, 166, _24015, 1);
    _24015 = NOVALUE;
    goto L20; // [867] 885
L1F: 

    /** 			ShowMsg(1, 166, { cmd })*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_cmd_45126);
    *((int *)(_2+4)) = _cmd_45126;
    _24016 = MAKE_SEQ(_1);
    _45ShowMsg(1, 166, _24016, 1);
    _24016 = NOVALUE;
L20: 
L1E: 

    /** 	status = system_exec(cmd, 0)*/
    _status_45133 = system_exec_call(_cmd_45126, 0);

    /** 	if status != 0 then*/
    if (_status_45133 == 0)
    goto L21; // [896] 939

    /** 		ShowMsg(2, 168, { exe_name[D_NAME] })*/
    _2 = (int)SEQ_PTR(_55exe_name_44324);
    _24019 = (int)*(((s1_ptr)_2)->base + 1);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_24019);
    *((int *)(_2+4)) = _24019;
    _24020 = MAKE_SEQ(_1);
    _24019 = NOVALUE;
    _45ShowMsg(2, 168, _24020, 1);
    _24020 = NOVALUE;

    /** 		ShowMsg(2, 169, { status, cmd })*/
    RefDS(_cmd_45126);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _status_45133;
    ((int *)_2)[2] = _cmd_45126;
    _24021 = MAKE_SEQ(_1);
    _45ShowMsg(2, 169, _24021, 1);
    _24021 = NOVALUE;

    /** 		goto "build_direct_cleanup"*/
    goto G11;
L21: 

    /** 	if length(rc_file[D_ALTNAME]) and length(settings[SETUP_RC_COMPILER]) and compiler_type = COMPILER_WATCOM then*/
    _2 = (int)SEQ_PTR(_55rc_file_44330);
    _24022 = (int)*(((s1_ptr)_2)->base + 11);
    if (IS_SEQUENCE(_24022)){
            _24023 = SEQ_PTR(_24022)->length;
    }
    else {
        _24023 = 1;
    }
    _24022 = NOVALUE;
    if (_24023 == 0) {
        _24024 = 0;
        goto L22; // [952] 967
    }
    _2 = (int)SEQ_PTR(_settings_45128);
    _24025 = (int)*(((s1_ptr)_2)->base + 8);
    if (IS_SEQUENCE(_24025)){
            _24026 = SEQ_PTR(_24025)->length;
    }
    else {
        _24026 = 1;
    }
    _24025 = NOVALUE;
    _24024 = (_24026 != 0);
L22: 
    if (_24024 == 0) {
        goto L23; // [967] 1086
    }
    _24028 = (_55compiler_type_44322 == 2);
    if (_24028 == 0)
    {
        DeRef(_24028);
        _24028 = NOVALUE;
        goto L23; // [978] 1086
    }
    else{
        DeRef(_24028);
        _24028 = NOVALUE;
    }

    /** 		cmd = text:format(settings[SETUP_RC_COMPILER], { rc_file[D_ALTNAME], res_file[D_ALTNAME], exe_name[D_ALTNAME] })*/
    _2 = (int)SEQ_PTR(_settings_45128);
    _24029 = (int)*(((s1_ptr)_2)->base + 8);
    _2 = (int)SEQ_PTR(_55rc_file_44330);
    _24030 = (int)*(((s1_ptr)_2)->base + 11);
    _2 = (int)SEQ_PTR(_55res_file_44336);
    _24031 = (int)*(((s1_ptr)_2)->base + 11);
    _2 = (int)SEQ_PTR(_55exe_name_44324);
    _24032 = (int)*(((s1_ptr)_2)->base + 11);
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_24030);
    *((int *)(_2+4)) = _24030;
    Ref(_24031);
    *((int *)(_2+8)) = _24031;
    Ref(_24032);
    *((int *)(_2+12)) = _24032;
    _24033 = MAKE_SEQ(_1);
    _24032 = NOVALUE;
    _24031 = NOVALUE;
    _24030 = NOVALUE;
    Ref(_24029);
    _0 = _cmd_45126;
    _cmd_45126 = _14format(_24029, _24033);
    DeRef(_0);
    _24029 = NOVALUE;
    _24033 = NOVALUE;

    /** 		status = system_exec(cmd, 0)*/
    _status_45133 = system_exec_call(_cmd_45126, 0);

    /** 		if status != 0 then*/
    if (_status_45133 == 0)
    goto L24; // [1032] 1085

    /** 			ShowMsg(2, 187, { rc_file[D_NAME], exe_name[D_NAME] })*/
    _2 = (int)SEQ_PTR(_55rc_file_44330);
    _24037 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_55exe_name_44324);
    _24038 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_24038);
    Ref(_24037);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _24037;
    ((int *)_2)[2] = _24038;
    _24039 = MAKE_SEQ(_1);
    _24038 = NOVALUE;
    _24037 = NOVALUE;
    _45ShowMsg(2, 187, _24039, 1);
    _24039 = NOVALUE;

    /** 			ShowMsg(2, 169, { status, cmd })*/
    RefDS(_cmd_45126);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _status_45133;
    ((int *)_2)[2] = _cmd_45126;
    _24040 = MAKE_SEQ(_1);
    _45ShowMsg(2, 169, _24040, 1);
    _24040 = NOVALUE;

    /** 			goto "build_direct_cleanup"*/
    goto G11;
L24: 
L23: 

    /** label "build_direct_cleanup"*/
G11:

    /** 	if keep = 0 then*/
    if (_57keep_41683 != 0)
    goto L25; // [1094] 1241

    /** 		for i = 1 to length(generated_files) do*/
    if (IS_SEQUENCE(_57generated_files_41680)){
            _24042 = SEQ_PTR(_57generated_files_41680)->length;
    }
    else {
        _24042 = 1;
    }
    {
        int _i_45367;
        _i_45367 = 1;
L26: 
        if (_i_45367 > _24042){
            goto L27; // [1105] 1159
        }

        /** 			if verbose then*/
        if (_35verbose_16362 == 0)
        {
            goto L28; // [1116] 1138
        }
        else{
        }

        /** 				ShowMsg(1, 347, { generated_files[i] })*/
        _2 = (int)SEQ_PTR(_57generated_files_41680);
        _24043 = (int)*(((s1_ptr)_2)->base + _i_45367);
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        RefDS(_24043);
        *((int *)(_2+4)) = _24043;
        _24044 = MAKE_SEQ(_1);
        _24043 = NOVALUE;
        _45ShowMsg(1, 347, _24044, 1);
        _24044 = NOVALUE;
L28: 

        /** 			delete_file(generated_files[i])*/
        _2 = (int)SEQ_PTR(_57generated_files_41680);
        _24045 = (int)*(((s1_ptr)_2)->base + _i_45367);
        RefDS(_24045);
        _31666 = _17delete_file(_24045);
        _24045 = NOVALUE;
        DeRef(_31666);
        _31666 = NOVALUE;

        /** 		end for*/
        _i_45367 = _i_45367 + 1;
        goto L26; // [1154] 1112
L27: 
        ;
    }

    /** 		if length(res_file[D_ALTNAME]) then*/
    _2 = (int)SEQ_PTR(_55res_file_44336);
    _24046 = (int)*(((s1_ptr)_2)->base + 11);
    if (IS_SEQUENCE(_24046)){
            _24047 = SEQ_PTR(_24046)->length;
    }
    else {
        _24047 = 1;
    }
    _24046 = NOVALUE;
    if (_24047 == 0)
    {
        _24047 = NOVALUE;
        goto L29; // [1172] 1192
    }
    else{
        _24047 = NOVALUE;
    }

    /** 			delete_file(res_file[D_ALTNAME])*/
    _2 = (int)SEQ_PTR(_55res_file_44336);
    _24048 = (int)*(((s1_ptr)_2)->base + 11);
    Ref(_24048);
    _31665 = _17delete_file(_24048);
    _24048 = NOVALUE;
    DeRef(_31665);
    _31665 = NOVALUE;
L29: 

    /** 		if remove_output_dir then*/
    if (_55remove_output_dir_44342 == 0)
    {
        goto L2A; // [1196] 1240
    }
    else{
    }

    /** 			chdir(cwd)*/
    RefDS(_cwd_45130);
    _31664 = _17chdir(_cwd_45130);
    DeRef(_31664);
    _31664 = NOVALUE;

    /** 			if not remove_directory(output_dir) then*/
    RefDS(_57output_dir_41689);
    _24049 = _17remove_directory(_57output_dir_41689, 0);
    if (IS_ATOM_INT(_24049)) {
        if (_24049 != 0){
            DeRef(_24049);
            _24049 = NOVALUE;
            goto L2B; // [1216] 1239
        }
    }
    else {
        if (DBL_PTR(_24049)->dbl != 0.0){
            DeRef(_24049);
            _24049 = NOVALUE;
            goto L2B; // [1216] 1239
        }
    }
    DeRef(_24049);
    _24049 = NOVALUE;

    /** 				ShowMsg(2, 194, { abbreviate_path(output_dir) })*/
    RefDS(_57output_dir_41689);
    RefDS(_22023);
    _24051 = _17abbreviate_path(_57output_dir_41689, _22023);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _24051;
    _24052 = MAKE_SEQ(_1);
    _24051 = NOVALUE;
    _45ShowMsg(2, 194, _24052, 1);
    _24052 = NOVALUE;
L2B: 
L2A: 
L25: 

    /** 	chdir(cwd)*/
    RefDS(_cwd_45130);
    _31663 = _17chdir(_cwd_45130);
    DeRef(_31663);
    _31663 = NOVALUE;

    /** end procedure*/
    DeRefDS(_the_file0_45120);
    DeRef(_cmd_45126);
    DeRef(_objs_45127);
    DeRef(_settings_45128);
    DeRefDS(_cwd_45130);
    DeRef(_link_files_45162);
    DeRef(_23973);
    _23973 = NOVALUE;
    DeRef(_23945);
    _23945 = NOVALUE;
    _23979 = NOVALUE;
    _23982 = NOVALUE;
    _24022 = NOVALUE;
    _24025 = NOVALUE;
    _24046 = NOVALUE;
    return;
    ;
}


void _55write_buildfile()
{
    int _make_command_45407 = NOVALUE;
    int _settings_45447 = NOVALUE;
    int _24075 = NOVALUE;
    int _24074 = NOVALUE;
    int _24070 = NOVALUE;
    int _24069 = NOVALUE;
    int _24068 = NOVALUE;
    int _24066 = NOVALUE;
    int _24065 = NOVALUE;
    int _24064 = NOVALUE;
    int _24063 = NOVALUE;
    int _24062 = NOVALUE;
    int _24061 = NOVALUE;
    int _24060 = NOVALUE;
    int _24059 = NOVALUE;
    int _0, _1, _2;
    

    /** 	switch build_system_type do*/
    _0 = _55build_system_type_44318;
    switch ( _0 ){ 

        /** 		case BUILD_MAKEFILE_FULL then*/
        case 2:

        /** 			write_makefile_full()*/
        _55write_makefile_full();

        /** 			if not silent then*/
        if (_35silent_16359 != 0)
        goto L1; // [22] 136

        /** 				sequence make_command*/

        /** 				if compiler_type = COMPILER_WATCOM then*/
        if (_55compiler_type_44322 != 2)
        goto L2; // [31] 45

        /** 					make_command = "wmake /f "*/
        RefDS(_24057);
        DeRefi(_make_command_45407);
        _make_command_45407 = _24057;
        goto L3; // [42] 53
L2: 

        /** 					make_command = "make -f "*/
        RefDS(_24058);
        DeRefi(_make_command_45407);
        _make_command_45407 = _24058;
L3: 

        /** 				ShowMsg(1, 170, { cfile_count + 2 })*/
        _24059 = _35cfile_count_16322 + 2;
        if ((long)((unsigned long)_24059 + (unsigned long)HIGH_BITS) >= 0) 
        _24059 = NewDouble((double)_24059);
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = _24059;
        _24060 = MAKE_SEQ(_1);
        _24059 = NOVALUE;
        _45ShowMsg(1, 170, _24060, 1);
        _24060 = NOVALUE;

        /** 				if sequence(output_dir) and length(output_dir) > 0 then*/
        _24061 = 1;
        if (_24061 == 0) {
            goto L4; // [78] 118
        }
        if (IS_SEQUENCE(_57output_dir_41689)){
                _24063 = SEQ_PTR(_57output_dir_41689)->length;
        }
        else {
            _24063 = 1;
        }
        _24064 = (_24063 > 0);
        _24063 = NOVALUE;
        if (_24064 == 0)
        {
            DeRef(_24064);
            _24064 = NOVALUE;
            goto L4; // [92] 118
        }
        else{
            DeRef(_24064);
            _24064 = NOVALUE;
        }

        /** 					ShowMsg(1, 174, { output_dir, make_command, file0 })*/
        _1 = NewS1(3);
        _2 = (int)((s1_ptr)_1)->base;
        RefDS(_57output_dir_41689);
        *((int *)(_2+4)) = _57output_dir_41689;
        RefDS(_make_command_45407);
        *((int *)(_2+8)) = _make_command_45407;
        RefDS(_57file0_43504);
        *((int *)(_2+12)) = _57file0_43504;
        _24065 = MAKE_SEQ(_1);
        _45ShowMsg(1, 174, _24065, 1);
        _24065 = NOVALUE;
        goto L5; // [115] 135
L4: 

        /** 					ShowMsg(1, 172, { make_command, file0 })*/
        RefDS(_57file0_43504);
        RefDS(_make_command_45407);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _make_command_45407;
        ((int *)_2)[2] = _57file0_43504;
        _24066 = MAKE_SEQ(_1);
        _45ShowMsg(1, 172, _24066, 1);
        _24066 = NOVALUE;
L5: 
L1: 
        DeRefi(_make_command_45407);
        _make_command_45407 = NOVALUE;
        goto L6; // [138] 263

        /** 		case BUILD_MAKEFILE_PARTIAL then*/
        case 1:

        /** 			write_makefile_partial()*/
        _55write_makefile_partial();

        /** 			if not silent then*/
        if (_35silent_16359 != 0)
        goto L6; // [152] 263

        /** 				ShowMsg(1, 170, { cfile_count + 2 })*/
        _24068 = _35cfile_count_16322 + 2;
        if ((long)((unsigned long)_24068 + (unsigned long)HIGH_BITS) >= 0) 
        _24068 = NewDouble((double)_24068);
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = _24068;
        _24069 = MAKE_SEQ(_1);
        _24068 = NOVALUE;
        _45ShowMsg(1, 170, _24069, 1);
        _24069 = NOVALUE;

        /** 				ShowMsg(1, 173, { file0 })*/
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        RefDS(_57file0_43504);
        *((int *)(_2+4)) = _57file0_43504;
        _24070 = MAKE_SEQ(_1);
        _45ShowMsg(1, 173, _24070, 1);
        _24070 = NOVALUE;
        goto L6; // [188] 263

        /** 		case BUILD_DIRECT then*/
        case 3:

        /** 			build_direct()*/
        RefDS(_22023);
        _55build_direct(0, _22023);

        /** 			if not silent then*/
        if (_35silent_16359 != 0)
        goto L7; // [204] 215

        /** 				sequence settings = setup_build()*/
        _0 = _settings_45447;
        _settings_45447 = _55setup_build();
        DeRef(_0);
L7: 
        DeRef(_settings_45447);
        _settings_45447 = NOVALUE;
        goto L6; // [217] 263

        /** 		case BUILD_NONE then*/
        case 0:

        /** 			if not silent then*/
        if (_35silent_16359 != 0)
        goto L6; // [227] 263

        /** 				ShowMsg(1, 170, { cfile_count + 2 })*/
        _24074 = _35cfile_count_16322 + 2;
        if ((long)((unsigned long)_24074 + (unsigned long)HIGH_BITS) >= 0) 
        _24074 = NewDouble((double)_24074);
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = _24074;
        _24075 = MAKE_SEQ(_1);
        _24074 = NOVALUE;
        _45ShowMsg(1, 170, _24075, 1);
        _24075 = NOVALUE;
        goto L6; // [249] 263

        /** 		case else*/
        default:

        /** 			CompileErr(151)*/
        RefDS(_22023);
        _44CompileErr(151, _22023, 0);
    ;}L6: 

    /** end procedure*/
    return;
    ;
}



// 0xAB5C844B
