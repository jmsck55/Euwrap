// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

void _65init_op_info()
{
    int _SHORT_CIRCUIT_27005 = NOVALUE;
    int _15268 = NOVALUE;
    int _15267 = NOVALUE;
    int _15266 = NOVALUE;
    int _15265 = NOVALUE;
    int _15264 = NOVALUE;
    int _15263 = NOVALUE;
    int _15262 = NOVALUE;
    int _15261 = NOVALUE;
    int _15260 = NOVALUE;
    int _15259 = NOVALUE;
    int _15258 = NOVALUE;
    int _15257 = NOVALUE;
    int _15256 = NOVALUE;
    int _15255 = NOVALUE;
    int _15254 = NOVALUE;
    int _15253 = NOVALUE;
    int _15252 = NOVALUE;
    int _15250 = NOVALUE;
    int _15249 = NOVALUE;
    int _15248 = NOVALUE;
    int _15247 = NOVALUE;
    int _15246 = NOVALUE;
    int _15245 = NOVALUE;
    int _15244 = NOVALUE;
    int _15243 = NOVALUE;
    int _15242 = NOVALUE;
    int _15241 = NOVALUE;
    int _15240 = NOVALUE;
    int _15239 = NOVALUE;
    int _15238 = NOVALUE;
    int _15237 = NOVALUE;
    int _15236 = NOVALUE;
    int _15235 = NOVALUE;
    int _15234 = NOVALUE;
    int _15233 = NOVALUE;
    int _15232 = NOVALUE;
    int _15231 = NOVALUE;
    int _15230 = NOVALUE;
    int _15229 = NOVALUE;
    int _15228 = NOVALUE;
    int _15227 = NOVALUE;
    int _15226 = NOVALUE;
    int _15225 = NOVALUE;
    int _15224 = NOVALUE;
    int _15223 = NOVALUE;
    int _15222 = NOVALUE;
    int _15221 = NOVALUE;
    int _15220 = NOVALUE;
    int _15219 = NOVALUE;
    int _15218 = NOVALUE;
    int _15217 = NOVALUE;
    int _15216 = NOVALUE;
    int _15215 = NOVALUE;
    int _15214 = NOVALUE;
    int _15213 = NOVALUE;
    int _15212 = NOVALUE;
    int _15211 = NOVALUE;
    int _15210 = NOVALUE;
    int _15209 = NOVALUE;
    int _15208 = NOVALUE;
    int _15207 = NOVALUE;
    int _15206 = NOVALUE;
    int _15205 = NOVALUE;
    int _15204 = NOVALUE;
    int _15203 = NOVALUE;
    int _15202 = NOVALUE;
    int _15201 = NOVALUE;
    int _15200 = NOVALUE;
    int _15199 = NOVALUE;
    int _15198 = NOVALUE;
    int _15197 = NOVALUE;
    int _15196 = NOVALUE;
    int _15195 = NOVALUE;
    int _15194 = NOVALUE;
    int _15193 = NOVALUE;
    int _15192 = NOVALUE;
    int _15191 = NOVALUE;
    int _15190 = NOVALUE;
    int _15189 = NOVALUE;
    int _15188 = NOVALUE;
    int _15187 = NOVALUE;
    int _15186 = NOVALUE;
    int _15185 = NOVALUE;
    int _15184 = NOVALUE;
    int _15183 = NOVALUE;
    int _15182 = NOVALUE;
    int _15181 = NOVALUE;
    int _15180 = NOVALUE;
    int _15179 = NOVALUE;
    int _15178 = NOVALUE;
    int _15177 = NOVALUE;
    int _15176 = NOVALUE;
    int _15175 = NOVALUE;
    int _15174 = NOVALUE;
    int _15173 = NOVALUE;
    int _15172 = NOVALUE;
    int _15171 = NOVALUE;
    int _15170 = NOVALUE;
    int _15169 = NOVALUE;
    int _15168 = NOVALUE;
    int _15167 = NOVALUE;
    int _15166 = NOVALUE;
    int _15165 = NOVALUE;
    int _15164 = NOVALUE;
    int _15163 = NOVALUE;
    int _15162 = NOVALUE;
    int _15161 = NOVALUE;
    int _15160 = NOVALUE;
    int _15159 = NOVALUE;
    int _15158 = NOVALUE;
    int _15157 = NOVALUE;
    int _15156 = NOVALUE;
    int _15155 = NOVALUE;
    int _15154 = NOVALUE;
    int _15153 = NOVALUE;
    int _15152 = NOVALUE;
    int _15151 = NOVALUE;
    int _15150 = NOVALUE;
    int _15149 = NOVALUE;
    int _15148 = NOVALUE;
    int _15147 = NOVALUE;
    int _15146 = NOVALUE;
    int _15145 = NOVALUE;
    int _15144 = NOVALUE;
    int _15143 = NOVALUE;
    int _15142 = NOVALUE;
    int _15141 = NOVALUE;
    int _15140 = NOVALUE;
    int _15139 = NOVALUE;
    int _15137 = NOVALUE;
    int _15136 = NOVALUE;
    int _15135 = NOVALUE;
    int _15134 = NOVALUE;
    int _15133 = NOVALUE;
    int _15132 = NOVALUE;
    int _15131 = NOVALUE;
    int _15130 = NOVALUE;
    int _15129 = NOVALUE;
    int _15128 = NOVALUE;
    int _15127 = NOVALUE;
    int _15126 = NOVALUE;
    int _15125 = NOVALUE;
    int _15124 = NOVALUE;
    int _15123 = NOVALUE;
    int _15122 = NOVALUE;
    int _15121 = NOVALUE;
    int _15120 = NOVALUE;
    int _15119 = NOVALUE;
    int _15118 = NOVALUE;
    int _15117 = NOVALUE;
    int _15116 = NOVALUE;
    int _15115 = NOVALUE;
    int _15114 = NOVALUE;
    int _15113 = NOVALUE;
    int _15112 = NOVALUE;
    int _15111 = NOVALUE;
    int _15109 = NOVALUE;
    int _15108 = NOVALUE;
    int _15107 = NOVALUE;
    int _15106 = NOVALUE;
    int _15105 = NOVALUE;
    int _15104 = NOVALUE;
    int _15103 = NOVALUE;
    int _15102 = NOVALUE;
    int _15101 = NOVALUE;
    int _15100 = NOVALUE;
    int _15099 = NOVALUE;
    int _15098 = NOVALUE;
    int _15097 = NOVALUE;
    int _15096 = NOVALUE;
    int _15095 = NOVALUE;
    int _15094 = NOVALUE;
    int _15093 = NOVALUE;
    int _15092 = NOVALUE;
    int _15091 = NOVALUE;
    int _15090 = NOVALUE;
    int _15089 = NOVALUE;
    int _15088 = NOVALUE;
    int _15087 = NOVALUE;
    int _15086 = NOVALUE;
    int _15085 = NOVALUE;
    int _15084 = NOVALUE;
    int _15083 = NOVALUE;
    int _15082 = NOVALUE;
    int _15081 = NOVALUE;
    int _15080 = NOVALUE;
    int _15079 = NOVALUE;
    int _15078 = NOVALUE;
    int _15077 = NOVALUE;
    int _15076 = NOVALUE;
    int _15075 = NOVALUE;
    int _15074 = NOVALUE;
    int _15073 = NOVALUE;
    int _15072 = NOVALUE;
    int _15071 = NOVALUE;
    int _15070 = NOVALUE;
    int _15069 = NOVALUE;
    int _15068 = NOVALUE;
    int _15067 = NOVALUE;
    int _15066 = NOVALUE;
    int _15065 = NOVALUE;
    int _15064 = NOVALUE;
    int _15063 = NOVALUE;
    int _15062 = NOVALUE;
    int _15061 = NOVALUE;
    int _15060 = NOVALUE;
    int _15059 = NOVALUE;
    int _15058 = NOVALUE;
    int _15057 = NOVALUE;
    int _15056 = NOVALUE;
    int _15055 = NOVALUE;
    int _0, _1, _2;
    

    /** 	op_info = repeat( 0, MAX_OPCODE )*/
    DeRef(_65op_info_26607);
    _65op_info_26607 = Repeat(0, 213);

    /** 	op_info[ABORT               ] = { FIXED_SIZE, 2, {}, {}, {} }   -- ary: pun*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15055 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 126);
    *(int *)_2 = _15055;
    if( _1 != _15055 ){
    }
    _15055 = NOVALUE;

    /** 	op_info[AND                 ] = { FIXED_SIZE, 4, {}, {}, {} }   -- ary: bin*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15056 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 8);
    _1 = *(int *)_2;
    *(int *)_2 = _15056;
    if( _1 != _15056 ){
        DeRef(_1);
    }
    _15056 = NOVALUE;

    /** 	op_info[AND_BITS            ] = { FIXED_SIZE, 4, {}, {3}, {} }   -- ary: bin*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13414);
    *((int *)(_2+16)) = _13414;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15057 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 56);
    _1 = *(int *)_2;
    *(int *)_2 = _15057;
    if( _1 != _15057 ){
        DeRef(_1);
    }
    _15057 = NOVALUE;

    /** 	op_info[APPEND              ] = { FIXED_SIZE, 4, {}, {3}, {} }   -- ary: bin*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13414);
    *((int *)(_2+16)) = _13414;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15058 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 35);
    _1 = *(int *)_2;
    *(int *)_2 = _15058;
    if( _1 != _15058 ){
        DeRef(_1);
    }
    _15058 = NOVALUE;

    /** 	op_info[ARCTAN              ] = { FIXED_SIZE, 3, {}, {2}, {} }   -- ary: un*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13477);
    *((int *)(_2+16)) = _13477;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15059 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 73);
    _1 = *(int *)_2;
    *(int *)_2 = _15059;
    if( _1 != _15059 ){
        DeRef(_1);
    }
    _15059 = NOVALUE;

    /** 	op_info[ASSIGN              ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13477);
    *((int *)(_2+16)) = _13477;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15060 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 18);
    _1 = *(int *)_2;
    *(int *)_2 = _15060;
    if( _1 != _15060 ){
        DeRef(_1);
    }
    _15060 = NOVALUE;

    /** 	op_info[ASSIGN_I            ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13477);
    *((int *)(_2+16)) = _13477;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15061 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 113);
    _1 = *(int *)_2;
    *(int *)_2 = _15061;
    if( _1 != _15061 ){
        DeRef(_1);
    }
    _15061 = NOVALUE;

    /** 	op_info[ASSIGN_OP_SLICE     ] = { FIXED_SIZE, 5, {}, {4}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 5;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13637);
    *((int *)(_2+16)) = _13637;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15062 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 150);
    _1 = *(int *)_2;
    *(int *)_2 = _15062;
    if( _1 != _15062 ){
        DeRef(_1);
    }
    _15062 = NOVALUE;

    /** 	op_info[ASSIGN_OP_SUBS      ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13414);
    *((int *)(_2+16)) = _13414;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15063 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 149);
    _1 = *(int *)_2;
    *(int *)_2 = _15063;
    if( _1 != _15063 ){
        DeRef(_1);
    }
    _15063 = NOVALUE;

    /** 	op_info[ASSIGN_SLICE        ] = { FIXED_SIZE, 5, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 5;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13096);
    *((int *)(_2+16)) = _13096;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15064 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 45);
    _1 = *(int *)_2;
    *(int *)_2 = _15064;
    if( _1 != _15064 ){
        DeRef(_1);
    }
    _15064 = NOVALUE;

    /** 	op_info[ASSIGN_SUBS         ] = { FIXED_SIZE, 4, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13096);
    *((int *)(_2+16)) = _13096;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15065 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 16);
    _1 = *(int *)_2;
    *(int *)_2 = _15065;
    if( _1 != _15065 ){
        DeRef(_1);
    }
    _15065 = NOVALUE;

    /** 	op_info[ASSIGN_SUBS_CHECK   ] = { FIXED_SIZE, 4, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13096);
    *((int *)(_2+16)) = _13096;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15066 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 84);
    _1 = *(int *)_2;
    *(int *)_2 = _15066;
    if( _1 != _15066 ){
        DeRef(_1);
    }
    _15066 = NOVALUE;

    /** 	op_info[ASSIGN_SUBS_I       ] = { FIXED_SIZE, 4, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13096);
    *((int *)(_2+16)) = _13096;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15067 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 118);
    _1 = *(int *)_2;
    *(int *)_2 = _15067;
    if( _1 != _15067 ){
        DeRef(_1);
    }
    _15067 = NOVALUE;

    /** 	op_info[BADRETURNF          ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 1;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15068 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 43);
    _1 = *(int *)_2;
    *(int *)_2 = _15068;
    if( _1 != _15068 ){
        DeRef(_1);
    }
    _15068 = NOVALUE;

    /** 	op_info[CALL                ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15069 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 129);
    _1 = *(int *)_2;
    *(int *)_2 = _15069;
    if( _1 != _15069 ){
        DeRef(_1);
    }
    _15069 = NOVALUE;

    /** 	op_info[CALL_PROC           ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15070 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 136);
    _1 = *(int *)_2;
    *(int *)_2 = _15070;
    if( _1 != _15070 ){
        DeRef(_1);
    }
    _15070 = NOVALUE;

    /** 	op_info[CALL_FUNC           ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13414);
    *((int *)(_2+16)) = _13414;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15071 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 137);
    _1 = *(int *)_2;
    *(int *)_2 = _15071;
    if( _1 != _15071 ){
        DeRef(_1);
    }
    _15071 = NOVALUE;

    /** 	op_info[CASE                ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15072 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 186);
    _1 = *(int *)_2;
    *(int *)_2 = _15072;
    if( _1 != _15072 ){
        DeRef(_1);
    }
    _15072 = NOVALUE;

    /** 	op_info[CLEAR_SCREEN        ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 1;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15073 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 59);
    _1 = *(int *)_2;
    *(int *)_2 = _15073;
    if( _1 != _15073 ){
        DeRef(_1);
    }
    _15073 = NOVALUE;

    /** 	op_info[CLOSE               ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15074 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 86);
    _1 = *(int *)_2;
    *(int *)_2 = _15074;
    if( _1 != _15074 ){
        DeRef(_1);
    }
    _15074 = NOVALUE;

    /** 	op_info[COMMAND_LINE        ] = { FIXED_SIZE, 2, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13096);
    *((int *)(_2+16)) = _13096;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15075 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 100);
    _1 = *(int *)_2;
    *(int *)_2 = _15075;
    if( _1 != _15075 ){
        DeRef(_1);
    }
    _15075 = NOVALUE;

    /** 	op_info[COMPARE             ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13414);
    *((int *)(_2+16)) = _13414;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15076 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 76);
    _1 = *(int *)_2;
    *(int *)_2 = _15076;
    if( _1 != _15076 ){
        DeRef(_1);
    }
    _15076 = NOVALUE;

    /** 	op_info[CONCAT              ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13414);
    *((int *)(_2+16)) = _13414;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15077 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 15);
    _1 = *(int *)_2;
    *(int *)_2 = _15077;
    if( _1 != _15077 ){
        DeRef(_1);
    }
    _15077 = NOVALUE;

    /** 	op_info[COS                 ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13477);
    *((int *)(_2+16)) = _13477;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15078 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 81);
    _1 = *(int *)_2;
    *(int *)_2 = _15078;
    if( _1 != _15078 ){
        DeRef(_1);
    }
    _15078 = NOVALUE;

    /** 	op_info[COVERAGE_LINE       ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15079 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 210);
    _1 = *(int *)_2;
    *(int *)_2 = _15079;
    if( _1 != _15079 ){
        DeRef(_1);
    }
    _15079 = NOVALUE;

    /** 	op_info[COVERAGE_ROUTINE    ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15080 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 211);
    _1 = *(int *)_2;
    *(int *)_2 = _15080;
    if( _1 != _15080 ){
        DeRef(_1);
    }
    _15080 = NOVALUE;

    /** 	op_info[C_FUNC              ] = { FIXED_SIZE, 5, {}, {4}, {3} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 5;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13637);
    *((int *)(_2+16)) = _13637;
    RefDS(_13414);
    *((int *)(_2+20)) = _13414;
    _15081 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 133);
    _1 = *(int *)_2;
    *(int *)_2 = _15081;
    if( _1 != _15081 ){
        DeRef(_1);
    }
    _15081 = NOVALUE;

    /** 	op_info[C_PROC              ] = { FIXED_SIZE, 4, {}, {}, {3} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDSn(_5, 2);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    RefDS(_13414);
    *((int *)(_2+20)) = _13414;
    _15082 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 132);
    _1 = *(int *)_2;
    *(int *)_2 = _15082;
    if( _1 != _15082 ){
        DeRef(_1);
    }
    _15082 = NOVALUE;

    /** 	op_info[DATE                ] = { FIXED_SIZE, 2, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13096);
    *((int *)(_2+16)) = _13096;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15083 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 69);
    _1 = *(int *)_2;
    *(int *)_2 = _15083;
    if( _1 != _15083 ){
        DeRef(_1);
    }
    _15083 = NOVALUE;

    /** 	op_info[DELETE_ROUTINE      ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13414);
    *((int *)(_2+16)) = _13414;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15084 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 204);
    _1 = *(int *)_2;
    *(int *)_2 = _15084;
    if( _1 != _15084 ){
        DeRef(_1);
    }
    _15084 = NOVALUE;

    /** 	op_info[DELETE_OBJECT       ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15085 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 205);
    _1 = *(int *)_2;
    *(int *)_2 = _15085;
    if( _1 != _15085 ){
        DeRef(_1);
    }
    _15085 = NOVALUE;

    /** 	op_info[DIV2                ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13414);
    *((int *)(_2+16)) = _13414;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15086 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 98);
    _1 = *(int *)_2;
    *(int *)_2 = _15086;
    if( _1 != _15086 ){
        DeRef(_1);
    }
    _15086 = NOVALUE;

    /** 	op_info[DIVIDE              ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13414);
    *((int *)(_2+16)) = _13414;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15087 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 14);
    _1 = *(int *)_2;
    *(int *)_2 = _15087;
    if( _1 != _15087 ){
        DeRef(_1);
    }
    _15087 = NOVALUE;

    /** 	op_info[ELSE                ] = { FIXED_SIZE, 2, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDS(_13096);
    *((int *)(_2+12)) = _13096;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15088 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 23);
    _1 = *(int *)_2;
    *(int *)_2 = _15088;
    if( _1 != _15088 ){
        DeRef(_1);
    }
    _15088 = NOVALUE;

    /** 	op_info[EXIT                ] = { FIXED_SIZE, 2, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDS(_13096);
    *((int *)(_2+12)) = _13096;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15089 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 61);
    _1 = *(int *)_2;
    *(int *)_2 = _15089;
    if( _1 != _15089 ){
        DeRef(_1);
    }
    _15089 = NOVALUE;

    /** 	op_info[EXIT_BLOCK          ] = { FIXED_SIZE, 2, {},  {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15090 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 206);
    _1 = *(int *)_2;
    *(int *)_2 = _15090;
    if( _1 != _15090 ){
        DeRef(_1);
    }
    _15090 = NOVALUE;

    /** 	op_info[ENDWHILE            ] = { FIXED_SIZE, 2, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDS(_13096);
    *((int *)(_2+12)) = _13096;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15091 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 22);
    _1 = *(int *)_2;
    *(int *)_2 = _15091;
    if( _1 != _15091 ){
        DeRef(_1);
    }
    _15091 = NOVALUE;

    /** 	op_info[RETRY               ] = { FIXED_SIZE, 2, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDS(_13096);
    *((int *)(_2+12)) = _13096;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15092 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 184);
    _1 = *(int *)_2;
    *(int *)_2 = _15092;
    if( _1 != _15092 ){
        DeRef(_1);
    }
    _15092 = NOVALUE;

    /** 	op_info[GOTO                ] = { FIXED_SIZE, 2, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDS(_13096);
    *((int *)(_2+12)) = _13096;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15093 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 188);
    _1 = *(int *)_2;
    *(int *)_2 = _15093;
    if( _1 != _15093 ){
        DeRef(_1);
    }
    _15093 = NOVALUE;

    /** 	op_info[ENDFOR_GENERAL      ] = { FIXED_SIZE, 5, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 5;
    RefDS(_13096);
    *((int *)(_2+12)) = _13096;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15094 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 39);
    _1 = *(int *)_2;
    *(int *)_2 = _15094;
    if( _1 != _15094 ){
        DeRef(_1);
    }
    _15094 = NOVALUE;

    /** 	op_info[ENDFOR_UP           ] = { FIXED_SIZE, 4, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_13096);
    *((int *)(_2+12)) = _13096;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15095 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 49);
    _1 = *(int *)_2;
    *(int *)_2 = _15095;
    if( _1 != _15095 ){
        DeRef(_1);
    }
    _15095 = NOVALUE;

    /** 	op_info[ENDFOR_DOWN         ] = { FIXED_SIZE, 4, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_13096);
    *((int *)(_2+12)) = _13096;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15096 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 50);
    _1 = *(int *)_2;
    *(int *)_2 = _15096;
    if( _1 != _15096 ){
        DeRef(_1);
    }
    _15096 = NOVALUE;

    /** 	op_info[ENDFOR_INT_UP       ] = { FIXED_SIZE, 4, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_13096);
    *((int *)(_2+12)) = _13096;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15097 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 48);
    _1 = *(int *)_2;
    *(int *)_2 = _15097;
    if( _1 != _15097 ){
        DeRef(_1);
    }
    _15097 = NOVALUE;

    /** 	op_info[ENDFOR_INT_DOWN     ] = { FIXED_SIZE, 4, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_13096);
    *((int *)(_2+12)) = _13096;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15098 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 52);
    _1 = *(int *)_2;
    *(int *)_2 = _15098;
    if( _1 != _15098 ){
        DeRef(_1);
    }
    _15098 = NOVALUE;

    /** 	op_info[ENDFOR_INT_DOWN1    ] = { FIXED_SIZE, 4, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_13096);
    *((int *)(_2+12)) = _13096;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15099 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 55);
    _1 = *(int *)_2;
    *(int *)_2 = _15099;
    if( _1 != _15099 ){
        DeRef(_1);
    }
    _15099 = NOVALUE;

    /** 	op_info[ENDFOR_INT_UP1      ] = { FIXED_SIZE, 5, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 5;
    RefDS(_13096);
    *((int *)(_2+12)) = _13096;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15100 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 54);
    _1 = *(int *)_2;
    *(int *)_2 = _15100;
    if( _1 != _15100 ){
        DeRef(_1);
    }
    _15100 = NOVALUE;

    /** 	op_info[EQUAL               ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13414);
    *((int *)(_2+16)) = _13414;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15101 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 153);
    _1 = *(int *)_2;
    *(int *)_2 = _15101;
    if( _1 != _15101 ){
        DeRef(_1);
    }
    _15101 = NOVALUE;

    /** 	op_info[EQUALS              ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13414);
    *((int *)(_2+16)) = _13414;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15102 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = _15102;
    if( _1 != _15102 ){
        DeRef(_1);
    }
    _15102 = NOVALUE;

    /** 	op_info[EQUALS_IFW          ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_13414);
    *((int *)(_2+12)) = _13414;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15103 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 104);
    _1 = *(int *)_2;
    *(int *)_2 = _15103;
    if( _1 != _15103 ){
        DeRef(_1);
    }
    _15103 = NOVALUE;

    /** 	op_info[EQUALS_IFW_I        ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_13414);
    *((int *)(_2+12)) = _13414;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15104 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 121);
    _1 = *(int *)_2;
    *(int *)_2 = _15104;
    if( _1 != _15104 ){
        DeRef(_1);
    }
    _15104 = NOVALUE;

    /** 	op_info[FIND                ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13414);
    *((int *)(_2+16)) = _13414;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15105 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 77);
    _1 = *(int *)_2;
    *(int *)_2 = _15105;
    if( _1 != _15105 ){
        DeRef(_1);
    }
    _15105 = NOVALUE;

    /** 	op_info[FIND_FROM           ] = { FIXED_SIZE, 5, {}, {4}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 5;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13637);
    *((int *)(_2+16)) = _13637;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15106 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 176);
    _1 = *(int *)_2;
    *(int *)_2 = _15106;
    if( _1 != _15106 ){
        DeRef(_1);
    }
    _15106 = NOVALUE;

    /** 	op_info[FLOOR               ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13477);
    *((int *)(_2+16)) = _13477;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15107 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 83);
    _1 = *(int *)_2;
    *(int *)_2 = _15107;
    if( _1 != _15107 ){
        DeRef(_1);
    }
    _15107 = NOVALUE;

    /** 	op_info[FLOOR_DIV           ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13414);
    *((int *)(_2+16)) = _13414;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15108 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 63);
    _1 = *(int *)_2;
    *(int *)_2 = _15108;
    if( _1 != _15108 ){
        DeRef(_1);
    }
    _15108 = NOVALUE;

    /** 	op_info[FLOOR_DIV2          ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13414);
    *((int *)(_2+16)) = _13414;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15109 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 66);
    _1 = *(int *)_2;
    *(int *)_2 = _15109;
    if( _1 != _15109 ){
        DeRef(_1);
    }
    _15109 = NOVALUE;

    /** 	op_info[FOR                 ] = { FIXED_SIZE, 7, {6}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 7;
    RefDS(_15110);
    *((int *)(_2+12)) = _15110;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15111 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 21);
    _1 = *(int *)_2;
    *(int *)_2 = _15111;
    if( _1 != _15111 ){
        DeRef(_1);
    }
    _15111 = NOVALUE;

    /** 	op_info[FOR_I               ] = { FIXED_SIZE, 7, {6}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 7;
    RefDS(_15110);
    *((int *)(_2+12)) = _15110;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15112 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 125);
    _1 = *(int *)_2;
    *(int *)_2 = _15112;
    if( _1 != _15112 ){
        DeRef(_1);
    }
    _15112 = NOVALUE;

    /** 	op_info[GETC                ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13477);
    *((int *)(_2+16)) = _13477;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15113 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 33);
    _1 = *(int *)_2;
    *(int *)_2 = _15113;
    if( _1 != _15113 ){
        DeRef(_1);
    }
    _15113 = NOVALUE;

    /** 	op_info[GETENV              ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13477);
    *((int *)(_2+16)) = _13477;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15114 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 91);
    _1 = *(int *)_2;
    *(int *)_2 = _15114;
    if( _1 != _15114 ){
        DeRef(_1);
    }
    _15114 = NOVALUE;

    /** 	op_info[GETS                ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13477);
    *((int *)(_2+16)) = _13477;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15115 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 17);
    _1 = *(int *)_2;
    *(int *)_2 = _15115;
    if( _1 != _15115 ){
        DeRef(_1);
    }
    _15115 = NOVALUE;

    /** 	op_info[GET_KEY             ] = { FIXED_SIZE, 2, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13096);
    *((int *)(_2+16)) = _13096;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15116 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 79);
    _1 = *(int *)_2;
    *(int *)_2 = _15116;
    if( _1 != _15116 ){
        DeRef(_1);
    }
    _15116 = NOVALUE;

    /** 	op_info[GLABEL              ] = { FIXED_SIZE, 2, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDS(_13096);
    *((int *)(_2+12)) = _13096;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15117 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 189);
    _1 = *(int *)_2;
    *(int *)_2 = _15117;
    if( _1 != _15117 ){
        DeRef(_1);
    }
    _15117 = NOVALUE;

    /** 	op_info[GLOBAL_INIT_CHECK   ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15118 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 109);
    _1 = *(int *)_2;
    *(int *)_2 = _15118;
    if( _1 != _15118 ){
        DeRef(_1);
    }
    _15118 = NOVALUE;

    /** 	op_info[PRIVATE_INIT_CHECK  ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15119 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 30);
    _1 = *(int *)_2;
    *(int *)_2 = _15119;
    if( _1 != _15119 ){
        DeRef(_1);
    }
    _15119 = NOVALUE;

    /** 	op_info[GREATER             ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13414);
    *((int *)(_2+16)) = _13414;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15120 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 6);
    _1 = *(int *)_2;
    *(int *)_2 = _15120;
    if( _1 != _15120 ){
        DeRef(_1);
    }
    _15120 = NOVALUE;

    /** 	op_info[GREATEREQ           ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13414);
    *((int *)(_2+16)) = _13414;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15121 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _15121;
    if( _1 != _15121 ){
        DeRef(_1);
    }
    _15121 = NOVALUE;

    /** 	op_info[GREATEREQ_IFW       ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_13414);
    *((int *)(_2+12)) = _13414;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15122 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 103);
    _1 = *(int *)_2;
    *(int *)_2 = _15122;
    if( _1 != _15122 ){
        DeRef(_1);
    }
    _15122 = NOVALUE;

    /** 	op_info[GREATEREQ_IFW_I     ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_13414);
    *((int *)(_2+12)) = _13414;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15123 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 120);
    _1 = *(int *)_2;
    *(int *)_2 = _15123;
    if( _1 != _15123 ){
        DeRef(_1);
    }
    _15123 = NOVALUE;

    /** 	op_info[GREATER_IFW         ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_13414);
    *((int *)(_2+12)) = _13414;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15124 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 107);
    _1 = *(int *)_2;
    *(int *)_2 = _15124;
    if( _1 != _15124 ){
        DeRef(_1);
    }
    _15124 = NOVALUE;

    /** 	op_info[GREATER_IFW_I       ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_13414);
    *((int *)(_2+12)) = _13414;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15125 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 124);
    _1 = *(int *)_2;
    *(int *)_2 = _15125;
    if( _1 != _15125 ){
        DeRef(_1);
    }
    _15125 = NOVALUE;

    /** 	op_info[HASH                ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13414);
    *((int *)(_2+16)) = _13414;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15126 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 194);
    _1 = *(int *)_2;
    *(int *)_2 = _15126;
    if( _1 != _15126 ){
        DeRef(_1);
    }
    _15126 = NOVALUE;

    /** 	op_info[HEAD                ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13414);
    *((int *)(_2+16)) = _13414;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15127 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 198);
    _1 = *(int *)_2;
    *(int *)_2 = _15127;
    if( _1 != _15127 ){
        DeRef(_1);
    }
    _15127 = NOVALUE;

    /** 	op_info[IF                  ] = { FIXED_SIZE, 3, {2}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_13477);
    *((int *)(_2+12)) = _13477;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15128 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 20);
    _1 = *(int *)_2;
    *(int *)_2 = _15128;
    if( _1 != _15128 ){
        DeRef(_1);
    }
    _15128 = NOVALUE;

    /** 	op_info[INSERT              ] = { FIXED_SIZE, 5, {}, {4}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 5;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13637);
    *((int *)(_2+16)) = _13637;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15129 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 191);
    _1 = *(int *)_2;
    *(int *)_2 = _15129;
    if( _1 != _15129 ){
        DeRef(_1);
    }
    _15129 = NOVALUE;

    /** 	op_info[LENGTH              ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13477);
    *((int *)(_2+16)) = _13477;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15130 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 42);
    _1 = *(int *)_2;
    *(int *)_2 = _15130;
    if( _1 != _15130 ){
        DeRef(_1);
    }
    _15130 = NOVALUE;

    /** 	op_info[LESS                ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13414);
    *((int *)(_2+16)) = _13414;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15131 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _15131;
    if( _1 != _15131 ){
        DeRef(_1);
    }
    _15131 = NOVALUE;

    /** 	op_info[LESSEQ              ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13414);
    *((int *)(_2+16)) = _13414;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15132 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = _15132;
    if( _1 != _15132 ){
        DeRef(_1);
    }
    _15132 = NOVALUE;

    /** 	op_info[LESSEQ_IFW          ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_13414);
    *((int *)(_2+12)) = _13414;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15133 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 106);
    _1 = *(int *)_2;
    *(int *)_2 = _15133;
    if( _1 != _15133 ){
        DeRef(_1);
    }
    _15133 = NOVALUE;

    /** 	op_info[LESSEQ_IFW_I        ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_13414);
    *((int *)(_2+12)) = _13414;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15134 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 123);
    _1 = *(int *)_2;
    *(int *)_2 = _15134;
    if( _1 != _15134 ){
        DeRef(_1);
    }
    _15134 = NOVALUE;

    /** 	op_info[LESS_IFW            ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_13414);
    *((int *)(_2+12)) = _13414;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15135 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 102);
    _1 = *(int *)_2;
    *(int *)_2 = _15135;
    if( _1 != _15135 ){
        DeRef(_1);
    }
    _15135 = NOVALUE;

    /** 	op_info[LESS_IFW_I          ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_13414);
    *((int *)(_2+12)) = _13414;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15136 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 119);
    _1 = *(int *)_2;
    *(int *)_2 = _15136;
    if( _1 != _15136 ){
        DeRef(_1);
    }
    _15136 = NOVALUE;

    /** 	op_info[LHS_SUBS            ] = { FIXED_SIZE, 5, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 5;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13414);
    *((int *)(_2+16)) = _13414;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15137 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 95);
    _1 = *(int *)_2;
    *(int *)_2 = _15137;
    if( _1 != _15137 ){
        DeRef(_1);
    }
    _15137 = NOVALUE;

    /** 	op_info[LHS_SUBS1           ] = { FIXED_SIZE, 5, {}, {3,4}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 5;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_15138);
    *((int *)(_2+16)) = _15138;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15139 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 161);
    _1 = *(int *)_2;
    *(int *)_2 = _15139;
    if( _1 != _15139 ){
        DeRef(_1);
    }
    _15139 = NOVALUE;

    /** 	op_info[LHS_SUBS1_COPY      ] = { FIXED_SIZE, 5, {}, {3,4}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 5;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_15138);
    *((int *)(_2+16)) = _15138;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15140 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 166);
    _1 = *(int *)_2;
    *(int *)_2 = _15140;
    if( _1 != _15140 ){
        DeRef(_1);
    }
    _15140 = NOVALUE;

    /** 	op_info[LOG                 ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13477);
    *((int *)(_2+16)) = _13477;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15141 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 74);
    _1 = *(int *)_2;
    *(int *)_2 = _15141;
    if( _1 != _15141 ){
        DeRef(_1);
    }
    _15141 = NOVALUE;

    /** 	op_info[MACHINE_FUNC        ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13414);
    *((int *)(_2+16)) = _13414;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15142 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 111);
    _1 = *(int *)_2;
    *(int *)_2 = _15142;
    if( _1 != _15142 ){
        DeRef(_1);
    }
    _15142 = NOVALUE;

    /** 	op_info[MACHINE_PROC        ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15143 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 112);
    _1 = *(int *)_2;
    *(int *)_2 = _15143;
    if( _1 != _15143 ){
        DeRef(_1);
    }
    _15143 = NOVALUE;

    /** 	op_info[MATCH               ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13414);
    *((int *)(_2+16)) = _13414;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15144 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 78);
    _1 = *(int *)_2;
    *(int *)_2 = _15144;
    if( _1 != _15144 ){
        DeRef(_1);
    }
    _15144 = NOVALUE;

    /** 	op_info[MATCH_FROM          ] = { FIXED_SIZE, 5, {}, {4}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 5;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13637);
    *((int *)(_2+16)) = _13637;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15145 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 177);
    _1 = *(int *)_2;
    *(int *)_2 = _15145;
    if( _1 != _15145 ){
        DeRef(_1);
    }
    _15145 = NOVALUE;

    /** 	op_info[MEM_COPY            ] = { FIXED_SIZE, 4, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15146 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 130);
    _1 = *(int *)_2;
    *(int *)_2 = _15146;
    if( _1 != _15146 ){
        DeRef(_1);
    }
    _15146 = NOVALUE;

    /** 	op_info[MEM_SET             ] = { FIXED_SIZE, 4, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15147 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 131);
    _1 = *(int *)_2;
    *(int *)_2 = _15147;
    if( _1 != _15147 ){
        DeRef(_1);
    }
    _15147 = NOVALUE;

    /** 	op_info[MINUS               ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13414);
    *((int *)(_2+16)) = _13414;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15148 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 10);
    _1 = *(int *)_2;
    *(int *)_2 = _15148;
    if( _1 != _15148 ){
        DeRef(_1);
    }
    _15148 = NOVALUE;

    /** 	op_info[MINUS_I             ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13414);
    *((int *)(_2+16)) = _13414;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15149 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 116);
    _1 = *(int *)_2;
    *(int *)_2 = _15149;
    if( _1 != _15149 ){
        DeRef(_1);
    }
    _15149 = NOVALUE;

    /** 	op_info[MULTIPLY            ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13414);
    *((int *)(_2+16)) = _13414;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15150 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 13);
    _1 = *(int *)_2;
    *(int *)_2 = _15150;
    if( _1 != _15150 ){
        DeRef(_1);
    }
    _15150 = NOVALUE;

    /** 	op_info[NOP1                ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 1;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15151 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 159);
    _1 = *(int *)_2;
    *(int *)_2 = _15151;
    if( _1 != _15151 ){
        DeRef(_1);
    }
    _15151 = NOVALUE;

    /** 	op_info[NOPWHILE            ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 1;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15152 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 158);
    _1 = *(int *)_2;
    *(int *)_2 = _15152;
    if( _1 != _15152 ){
        DeRef(_1);
    }
    _15152 = NOVALUE;

    /** 	op_info[NOP2                ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15153 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 110);
    _1 = *(int *)_2;
    *(int *)_2 = _15153;
    if( _1 != _15153 ){
        DeRef(_1);
    }
    _15153 = NOVALUE;

    /** 	op_info[SC2_NULL            ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15154 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 145);
    _1 = *(int *)_2;
    *(int *)_2 = _15154;
    if( _1 != _15154 ){
        DeRef(_1);
    }
    _15154 = NOVALUE;

    /** 	op_info[ASSIGN_SUBS2        ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15155 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 148);
    _1 = *(int *)_2;
    *(int *)_2 = _15155;
    if( _1 != _15155 ){
        DeRef(_1);
    }
    _15155 = NOVALUE;

    /** 	op_info[PLATFORM            ] = { FIXED_SIZE, 2, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13096);
    *((int *)(_2+16)) = _13096;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15156 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 155);
    _1 = *(int *)_2;
    *(int *)_2 = _15156;
    if( _1 != _15156 ){
        DeRef(_1);
    }
    _15156 = NOVALUE;

    /** 	op_info[END_PARAM_CHECK     ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15157 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 156);
    _1 = *(int *)_2;
    *(int *)_2 = _15157;
    if( _1 != _15157 ){
        DeRef(_1);
    }
    _15157 = NOVALUE;

    /** 	op_info[NOPSWITCH           ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 1;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15158 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 187);
    _1 = *(int *)_2;
    *(int *)_2 = _15158;
    if( _1 != _15158 ){
        DeRef(_1);
    }
    _15158 = NOVALUE;

    /** 	op_info[NOT                 ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13477);
    *((int *)(_2+16)) = _13477;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15159 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 7);
    _1 = *(int *)_2;
    *(int *)_2 = _15159;
    if( _1 != _15159 ){
        DeRef(_1);
    }
    _15159 = NOVALUE;

    /** 	op_info[NOTEQ               ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13414);
    *((int *)(_2+16)) = _13414;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15160 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = _15160;
    if( _1 != _15160 ){
        DeRef(_1);
    }
    _15160 = NOVALUE;

    /** 	op_info[NOTEQ_IFW           ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_13414);
    *((int *)(_2+12)) = _13414;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15161 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 105);
    _1 = *(int *)_2;
    *(int *)_2 = _15161;
    if( _1 != _15161 ){
        DeRef(_1);
    }
    _15161 = NOVALUE;

    /** 	op_info[NOTEQ_IFW_I         ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_13414);
    *((int *)(_2+12)) = _13414;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15162 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 122);
    _1 = *(int *)_2;
    *(int *)_2 = _15162;
    if( _1 != _15162 ){
        DeRef(_1);
    }
    _15162 = NOVALUE;

    /** 	op_info[NOT_BITS            ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13477);
    *((int *)(_2+16)) = _13477;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15163 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 51);
    _1 = *(int *)_2;
    *(int *)_2 = _15163;
    if( _1 != _15163 ){
        DeRef(_1);
    }
    _15163 = NOVALUE;

    /** 	op_info[NOT_IFW             ] = { FIXED_SIZE, 3, {2}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_13477);
    *((int *)(_2+12)) = _13477;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15164 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 108);
    _1 = *(int *)_2;
    *(int *)_2 = _15164;
    if( _1 != _15164 ){
        DeRef(_1);
    }
    _15164 = NOVALUE;

    /** 	op_info[OPEN                ] = { FIXED_SIZE, 5, {}, {4}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 5;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13637);
    *((int *)(_2+16)) = _13637;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15165 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 37);
    _1 = *(int *)_2;
    *(int *)_2 = _15165;
    if( _1 != _15165 ){
        DeRef(_1);
    }
    _15165 = NOVALUE;

    /** 	op_info[OPTION_SWITCHES     ] = { FIXED_SIZE, 2, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13096);
    *((int *)(_2+16)) = _13096;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15166 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 183);
    _1 = *(int *)_2;
    *(int *)_2 = _15166;
    if( _1 != _15166 ){
        DeRef(_1);
    }
    _15166 = NOVALUE;

    /** 	op_info[OR                  ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13414);
    *((int *)(_2+16)) = _13414;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15167 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 9);
    _1 = *(int *)_2;
    *(int *)_2 = _15167;
    if( _1 != _15167 ){
        DeRef(_1);
    }
    _15167 = NOVALUE;

    /** 	op_info[OR_BITS             ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13414);
    *((int *)(_2+16)) = _13414;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15168 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 24);
    _1 = *(int *)_2;
    *(int *)_2 = _15168;
    if( _1 != _15168 ){
        DeRef(_1);
    }
    _15168 = NOVALUE;

    /** 	op_info[PASSIGN_OP_SLICE    ] = { FIXED_SIZE, 5, {}, {4}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 5;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13637);
    *((int *)(_2+16)) = _13637;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15169 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 165);
    _1 = *(int *)_2;
    *(int *)_2 = _15169;
    if( _1 != _15169 ){
        DeRef(_1);
    }
    _15169 = NOVALUE;

    /** 	op_info[PASSIGN_OP_SUBS     ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13414);
    *((int *)(_2+16)) = _13414;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15170 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 164);
    _1 = *(int *)_2;
    *(int *)_2 = _15170;
    if( _1 != _15170 ){
        DeRef(_1);
    }
    _15170 = NOVALUE;

    /** 	op_info[PASSIGN_SLICE       ] = { FIXED_SIZE, 5, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 5;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13096);
    *((int *)(_2+16)) = _13096;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15171 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 163);
    _1 = *(int *)_2;
    *(int *)_2 = _15171;
    if( _1 != _15171 ){
        DeRef(_1);
    }
    _15171 = NOVALUE;

    /** 	op_info[PASSIGN_SUBS        ] = { FIXED_SIZE, 4, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13096);
    *((int *)(_2+16)) = _13096;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15172 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 162);
    _1 = *(int *)_2;
    *(int *)_2 = _15172;
    if( _1 != _15172 ){
        DeRef(_1);
    }
    _15172 = NOVALUE;

    /** 	op_info[PEEK_STRING         ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13477);
    *((int *)(_2+16)) = _13477;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15173 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 182);
    _1 = *(int *)_2;
    *(int *)_2 = _15173;
    if( _1 != _15173 ){
        DeRef(_1);
    }
    _15173 = NOVALUE;

    /** 	op_info[PEEK2U              ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13477);
    *((int *)(_2+16)) = _13477;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15174 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 180);
    _1 = *(int *)_2;
    *(int *)_2 = _15174;
    if( _1 != _15174 ){
        DeRef(_1);
    }
    _15174 = NOVALUE;

    /** 	op_info[PEEK2S              ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13477);
    *((int *)(_2+16)) = _13477;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15175 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 179);
    _1 = *(int *)_2;
    *(int *)_2 = _15175;
    if( _1 != _15175 ){
        DeRef(_1);
    }
    _15175 = NOVALUE;

    /** 	op_info[PEEK4U              ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13477);
    *((int *)(_2+16)) = _13477;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15176 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 140);
    _1 = *(int *)_2;
    *(int *)_2 = _15176;
    if( _1 != _15176 ){
        DeRef(_1);
    }
    _15176 = NOVALUE;

    /** 	op_info[PEEK4S              ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13477);
    *((int *)(_2+16)) = _13477;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15177 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 139);
    _1 = *(int *)_2;
    *(int *)_2 = _15177;
    if( _1 != _15177 ){
        DeRef(_1);
    }
    _15177 = NOVALUE;

    /** 	op_info[PEEKS               ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13477);
    *((int *)(_2+16)) = _13477;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15178 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 181);
    _1 = *(int *)_2;
    *(int *)_2 = _15178;
    if( _1 != _15178 ){
        DeRef(_1);
    }
    _15178 = NOVALUE;

    /** 	op_info[PEEK                ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13477);
    *((int *)(_2+16)) = _13477;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15179 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 127);
    _1 = *(int *)_2;
    *(int *)_2 = _15179;
    if( _1 != _15179 ){
        DeRef(_1);
    }
    _15179 = NOVALUE;

    /** 	op_info[PLENGTH             ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13477);
    *((int *)(_2+16)) = _13477;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15180 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 160);
    _1 = *(int *)_2;
    *(int *)_2 = _15180;
    if( _1 != _15180 ){
        DeRef(_1);
    }
    _15180 = NOVALUE;

    /** 	op_info[PLUS                ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13414);
    *((int *)(_2+16)) = _13414;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15181 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 11);
    _1 = *(int *)_2;
    *(int *)_2 = _15181;
    if( _1 != _15181 ){
        DeRef(_1);
    }
    _15181 = NOVALUE;

    /** 	op_info[PLUS_I              ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13414);
    *((int *)(_2+16)) = _13414;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15182 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 115);
    _1 = *(int *)_2;
    *(int *)_2 = _15182;
    if( _1 != _15182 ){
        DeRef(_1);
    }
    _15182 = NOVALUE;

    /** 	op_info[PLUS1               ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13414);
    *((int *)(_2+16)) = _13414;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15183 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 93);
    _1 = *(int *)_2;
    *(int *)_2 = _15183;
    if( _1 != _15183 ){
        DeRef(_1);
    }
    _15183 = NOVALUE;

    /** 	op_info[PLUS1_I             ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13414);
    *((int *)(_2+16)) = _13414;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15184 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 117);
    _1 = *(int *)_2;
    *(int *)_2 = _15184;
    if( _1 != _15184 ){
        DeRef(_1);
    }
    _15184 = NOVALUE;

    /** 	op_info[POKE                ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15185 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 128);
    _1 = *(int *)_2;
    *(int *)_2 = _15185;
    if( _1 != _15185 ){
        DeRef(_1);
    }
    _15185 = NOVALUE;

    /** 	op_info[POKE2               ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15186 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 178);
    _1 = *(int *)_2;
    *(int *)_2 = _15186;
    if( _1 != _15186 ){
        DeRef(_1);
    }
    _15186 = NOVALUE;

    /** 	op_info[POKE4               ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15187 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 138);
    _1 = *(int *)_2;
    *(int *)_2 = _15187;
    if( _1 != _15187 ){
        DeRef(_1);
    }
    _15187 = NOVALUE;

    /** 	op_info[POSITION            ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15188 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 60);
    _1 = *(int *)_2;
    *(int *)_2 = _15188;
    if( _1 != _15188 ){
        DeRef(_1);
    }
    _15188 = NOVALUE;

    /** 	op_info[POWER               ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13414);
    *((int *)(_2+16)) = _13414;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15189 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 72);
    _1 = *(int *)_2;
    *(int *)_2 = _15189;
    if( _1 != _15189 ){
        DeRef(_1);
    }
    _15189 = NOVALUE;

    /** 	op_info[PREPEND             ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13414);
    *((int *)(_2+16)) = _13414;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15190 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 57);
    _1 = *(int *)_2;
    *(int *)_2 = _15190;
    if( _1 != _15190 ){
        DeRef(_1);
    }
    _15190 = NOVALUE;

    /** 	op_info[PRINT               ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15191 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 19);
    _1 = *(int *)_2;
    *(int *)_2 = _15191;
    if( _1 != _15191 ){
        DeRef(_1);
    }
    _15191 = NOVALUE;

    /** 	op_info[PRINTF              ] = { FIXED_SIZE, 4, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15192 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 38);
    _1 = *(int *)_2;
    *(int *)_2 = _15192;
    if( _1 != _15192 ){
        DeRef(_1);
    }
    _15192 = NOVALUE;

    /** 	op_info[PROFILE             ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15193 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 151);
    _1 = *(int *)_2;
    *(int *)_2 = _15193;
    if( _1 != _15193 ){
        DeRef(_1);
    }
    _15193 = NOVALUE;

    /** 	op_info[DISPLAY_VAR         ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15194 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 87);
    _1 = *(int *)_2;
    *(int *)_2 = _15194;
    if( _1 != _15194 ){
        DeRef(_1);
    }
    _15194 = NOVALUE;

    /** 	op_info[ERASE_PRIVATE_NAMES ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15195 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 88);
    _1 = *(int *)_2;
    *(int *)_2 = _15195;
    if( _1 != _15195 ){
        DeRef(_1);
    }
    _15195 = NOVALUE;

    /** 	op_info[ERASE_SYMBOL        ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15196 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 90);
    _1 = *(int *)_2;
    *(int *)_2 = _15196;
    if( _1 != _15196 ){
        DeRef(_1);
    }
    _15196 = NOVALUE;

    /** 	op_info[PUTS                ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15197 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 44);
    _1 = *(int *)_2;
    *(int *)_2 = _15197;
    if( _1 != _15197 ){
        DeRef(_1);
    }
    _15197 = NOVALUE;

    /** 	op_info[QPRINT              ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15198 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 36);
    _1 = *(int *)_2;
    *(int *)_2 = _15198;
    if( _1 != _15198 ){
        DeRef(_1);
    }
    _15198 = NOVALUE;

    /** 	op_info[RAND                ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13477);
    *((int *)(_2+16)) = _13477;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15199 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 62);
    _1 = *(int *)_2;
    *(int *)_2 = _15199;
    if( _1 != _15199 ){
        DeRef(_1);
    }
    _15199 = NOVALUE;

    /** 	op_info[REMAINDER           ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13414);
    *((int *)(_2+16)) = _13414;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15200 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 71);
    _1 = *(int *)_2;
    *(int *)_2 = _15200;
    if( _1 != _15200 ){
        DeRef(_1);
    }
    _15200 = NOVALUE;

    /** 	op_info[REMOVE              ] = { FIXED_SIZE, 5, {}, {4}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 5;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13637);
    *((int *)(_2+16)) = _13637;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15201 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 200);
    _1 = *(int *)_2;
    *(int *)_2 = _15201;
    if( _1 != _15201 ){
        DeRef(_1);
    }
    _15201 = NOVALUE;

    /** 	op_info[REPEAT              ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13414);
    *((int *)(_2+16)) = _13414;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15202 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 32);
    _1 = *(int *)_2;
    *(int *)_2 = _15202;
    if( _1 != _15202 ){
        DeRef(_1);
    }
    _15202 = NOVALUE;

    /** 	op_info[REPLACE             ] = { FIXED_SIZE, 6, {}, {5}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 6;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13125);
    *((int *)(_2+16)) = _13125;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15203 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 201);
    _1 = *(int *)_2;
    *(int *)_2 = _15203;
    if( _1 != _15203 ){
        DeRef(_1);
    }
    _15203 = NOVALUE;

    /** 	op_info[RETURNF             ] = { FIXED_SIZE, 4, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15204 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 28);
    _1 = *(int *)_2;
    *(int *)_2 = _15204;
    if( _1 != _15204 ){
        DeRef(_1);
    }
    _15204 = NOVALUE;

    /** 	op_info[RETURNP             ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15205 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 29);
    _1 = *(int *)_2;
    *(int *)_2 = _15205;
    if( _1 != _15205 ){
        DeRef(_1);
    }
    _15205 = NOVALUE;

    /** 	op_info[RETURNT             ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 1;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15206 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 34);
    _1 = *(int *)_2;
    *(int *)_2 = _15206;
    if( _1 != _15206 ){
        DeRef(_1);
    }
    _15206 = NOVALUE;

    /** 	op_info[RHS_SLICE           ] = { FIXED_SIZE, 5, {}, {4}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 5;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13637);
    *((int *)(_2+16)) = _13637;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15207 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 46);
    _1 = *(int *)_2;
    *(int *)_2 = _15207;
    if( _1 != _15207 ){
        DeRef(_1);
    }
    _15207 = NOVALUE;

    /** 	op_info[RHS_SUBS            ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13414);
    *((int *)(_2+16)) = _13414;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15208 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 25);
    _1 = *(int *)_2;
    *(int *)_2 = _15208;
    if( _1 != _15208 ){
        DeRef(_1);
    }
    _15208 = NOVALUE;

    /** 	op_info[RHS_SUBS_I          ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13414);
    *((int *)(_2+16)) = _13414;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15209 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 114);
    _1 = *(int *)_2;
    *(int *)_2 = _15209;
    if( _1 != _15209 ){
        DeRef(_1);
    }
    _15209 = NOVALUE;

    /** 	op_info[RHS_SUBS_CHECK      ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13414);
    *((int *)(_2+16)) = _13414;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15210 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 92);
    _1 = *(int *)_2;
    *(int *)_2 = _15210;
    if( _1 != _15210 ){
        DeRef(_1);
    }
    _15210 = NOVALUE;

    /** 	op_info[RIGHT_BRACE_2       ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13414);
    *((int *)(_2+16)) = _13414;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15211 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 85);
    _1 = *(int *)_2;
    *(int *)_2 = _15211;
    if( _1 != _15211 ){
        DeRef(_1);
    }
    _15211 = NOVALUE;

    /** 	op_info[ROUTINE_ID          ] = { FIXED_SIZE, 6 - TRANSLATE, {}, { 4 + not TRANSLATE }, {} }*/
    _15212 = 6 - _35TRANSLATE_15887;
    _15213 = (_35TRANSLATE_15887 == 0);
    _15214 = 4 + _15213;
    if ((long)((unsigned long)_15214 + (unsigned long)HIGH_BITS) >= 0) 
    _15214 = NewDouble((double)_15214);
    _15213 = NOVALUE;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _15214;
    _15215 = MAKE_SEQ(_1);
    _15214 = NOVALUE;
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = _15212;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _15215;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15216 = MAKE_SEQ(_1);
    _15215 = NOVALUE;
    _15212 = NOVALUE;
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 134);
    _1 = *(int *)_2;
    *(int *)_2 = _15216;
    if( _1 != _15216 ){
        DeRef(_1);
    }
    _15216 = NOVALUE;

    /** 	op_info[SC2_OR              ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15217 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 144);
    _1 = *(int *)_2;
    *(int *)_2 = _15217;
    if( _1 != _15217 ){
        DeRef(_1);
    }
    _15217 = NOVALUE;

    /** 	op_info[SC2_AND             ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15218 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 142);
    _1 = *(int *)_2;
    *(int *)_2 = _15218;
    if( _1 != _15218 ){
        DeRef(_1);
    }
    _15218 = NOVALUE;

    /** 	op_info[SIN                 ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13477);
    *((int *)(_2+16)) = _13477;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15219 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 80);
    _1 = *(int *)_2;
    *(int *)_2 = _15219;
    if( _1 != _15219 ){
        DeRef(_1);
    }
    _15219 = NOVALUE;

    /** 	op_info[SPACE_USED          ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15220 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 75);
    _1 = *(int *)_2;
    *(int *)_2 = _15220;
    if( _1 != _15220 ){
        DeRef(_1);
    }
    _15220 = NOVALUE;

    /** 	op_info[SPLICE              ] = { FIXED_SIZE, 5, {}, {4}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 5;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13637);
    *((int *)(_2+16)) = _13637;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15221 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 190);
    _1 = *(int *)_2;
    *(int *)_2 = _15221;
    if( _1 != _15221 ){
        DeRef(_1);
    }
    _15221 = NOVALUE;

    /** 	op_info[SPRINTF             ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13414);
    *((int *)(_2+16)) = _13414;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15222 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 53);
    _1 = *(int *)_2;
    *(int *)_2 = _15222;
    if( _1 != _15222 ){
        DeRef(_1);
    }
    _15222 = NOVALUE;

    /** 	op_info[SQRT                ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13477);
    *((int *)(_2+16)) = _13477;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15223 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 41);
    _1 = *(int *)_2;
    *(int *)_2 = _15223;
    if( _1 != _15223 ){
        DeRef(_1);
    }
    _15223 = NOVALUE;

    /** 	op_info[STARTLINE           ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15224 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 58);
    _1 = *(int *)_2;
    *(int *)_2 = _15224;
    if( _1 != _15224 ){
        DeRef(_1);
    }
    _15224 = NOVALUE;

    /** 	op_info[SWITCH              ] = { FIXED_SIZE, 5, {4}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 5;
    RefDS(_13637);
    *((int *)(_2+12)) = _13637;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15225 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 185);
    _1 = *(int *)_2;
    *(int *)_2 = _15225;
    if( _1 != _15225 ){
        DeRef(_1);
    }
    _15225 = NOVALUE;

    /** 	op_info[SWITCH_I            ] = { FIXED_SIZE, 5, {4}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 5;
    RefDS(_13637);
    *((int *)(_2+12)) = _13637;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15226 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 193);
    _1 = *(int *)_2;
    *(int *)_2 = _15226;
    if( _1 != _15226 ){
        DeRef(_1);
    }
    _15226 = NOVALUE;

    /** 	op_info[SWITCH_SPI          ] = { FIXED_SIZE, 5, {4}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 5;
    RefDS(_13637);
    *((int *)(_2+12)) = _13637;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15227 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 192);
    _1 = *(int *)_2;
    *(int *)_2 = _15227;
    if( _1 != _15227 ){
        DeRef(_1);
    }
    _15227 = NOVALUE;

    /** 	op_info[SWITCH_RT           ] = { FIXED_SIZE, 5, {4}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 5;
    RefDS(_13637);
    *((int *)(_2+12)) = _13637;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15228 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 202);
    _1 = *(int *)_2;
    *(int *)_2 = _15228;
    if( _1 != _15228 ){
        DeRef(_1);
    }
    _15228 = NOVALUE;

    /** 	op_info[SYSTEM              ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15229 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 99);
    _1 = *(int *)_2;
    *(int *)_2 = _15229;
    if( _1 != _15229 ){
        DeRef(_1);
    }
    _15229 = NOVALUE;

    /** 	op_info[SYSTEM_EXEC         ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13414);
    *((int *)(_2+16)) = _13414;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15230 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 154);
    _1 = *(int *)_2;
    *(int *)_2 = _15230;
    if( _1 != _15230 ){
        DeRef(_1);
    }
    _15230 = NOVALUE;

    /** 	op_info[TAIL                ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13414);
    *((int *)(_2+16)) = _13414;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15231 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 199);
    _1 = *(int *)_2;
    *(int *)_2 = _15231;
    if( _1 != _15231 ){
        DeRef(_1);
    }
    _15231 = NOVALUE;

    /** 	op_info[TAN                 ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13477);
    *((int *)(_2+16)) = _13477;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15232 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 82);
    _1 = *(int *)_2;
    *(int *)_2 = _15232;
    if( _1 != _15232 ){
        DeRef(_1);
    }
    _15232 = NOVALUE;

    /** 	op_info[TASK_CLOCK_START    ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 1;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15233 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 175);
    _1 = *(int *)_2;
    *(int *)_2 = _15233;
    if( _1 != _15233 ){
        DeRef(_1);
    }
    _15233 = NOVALUE;

    /** 	op_info[TASK_CLOCK_STOP     ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 1;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15234 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 174);
    _1 = *(int *)_2;
    *(int *)_2 = _15234;
    if( _1 != _15234 ){
        DeRef(_1);
    }
    _15234 = NOVALUE;

    /** 	op_info[TASK_CREATE         ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13414);
    *((int *)(_2+16)) = _13414;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15235 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 167);
    _1 = *(int *)_2;
    *(int *)_2 = _15235;
    if( _1 != _15235 ){
        DeRef(_1);
    }
    _15235 = NOVALUE;

    /** 	op_info[TASK_LIST           ] = { FIXED_SIZE, 2, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13096);
    *((int *)(_2+16)) = _13096;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15236 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 172);
    _1 = *(int *)_2;
    *(int *)_2 = _15236;
    if( _1 != _15236 ){
        DeRef(_1);
    }
    _15236 = NOVALUE;

    /** 	op_info[TASK_SCHEDULE       ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15237 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 168);
    _1 = *(int *)_2;
    *(int *)_2 = _15237;
    if( _1 != _15237 ){
        DeRef(_1);
    }
    _15237 = NOVALUE;

    /** 	op_info[TASK_SELF           ] = { FIXED_SIZE, 2, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13096);
    *((int *)(_2+16)) = _13096;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15238 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 170);
    _1 = *(int *)_2;
    *(int *)_2 = _15238;
    if( _1 != _15238 ){
        DeRef(_1);
    }
    _15238 = NOVALUE;

    /** 	op_info[TASK_STATUS         ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13477);
    *((int *)(_2+16)) = _13477;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15239 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 173);
    _1 = *(int *)_2;
    *(int *)_2 = _15239;
    if( _1 != _15239 ){
        DeRef(_1);
    }
    _15239 = NOVALUE;

    /** 	op_info[TASK_SUSPEND        ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15240 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 171);
    _1 = *(int *)_2;
    *(int *)_2 = _15240;
    if( _1 != _15240 ){
        DeRef(_1);
    }
    _15240 = NOVALUE;

    /** 	op_info[TASK_YIELD          ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 1;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15241 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 169);
    _1 = *(int *)_2;
    *(int *)_2 = _15241;
    if( _1 != _15241 ){
        DeRef(_1);
    }
    _15241 = NOVALUE;

    /** 	op_info[TIME                ] = { FIXED_SIZE, 2, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13096);
    *((int *)(_2+16)) = _13096;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15242 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 70);
    _1 = *(int *)_2;
    *(int *)_2 = _15242;
    if( _1 != _15242 ){
        DeRef(_1);
    }
    _15242 = NOVALUE;

    /** 	op_info[TRACE               ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15243 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 64);
    _1 = *(int *)_2;
    *(int *)_2 = _15243;
    if( _1 != _15243 ){
        DeRef(_1);
    }
    _15243 = NOVALUE;

    /** 	op_info[TYPE_CHECK          ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 1;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15244 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 65);
    _1 = *(int *)_2;
    *(int *)_2 = _15244;
    if( _1 != _15244 ){
        DeRef(_1);
    }
    _15244 = NOVALUE;

    /** 	op_info[UMINUS              ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13477);
    *((int *)(_2+16)) = _13477;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15245 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 12);
    _1 = *(int *)_2;
    *(int *)_2 = _15245;
    if( _1 != _15245 ){
        DeRef(_1);
    }
    _15245 = NOVALUE;

    /** 	op_info[UPDATE_GLOBALS      ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 1;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15246 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 89);
    _1 = *(int *)_2;
    *(int *)_2 = _15246;
    if( _1 != _15246 ){
        DeRef(_1);
    }
    _15246 = NOVALUE;

    /** 	op_info[WHILE               ] = { FIXED_SIZE, 3, {2}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_13477);
    *((int *)(_2+12)) = _13477;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15247 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 47);
    _1 = *(int *)_2;
    *(int *)_2 = _15247;
    if( _1 != _15247 ){
        DeRef(_1);
    }
    _15247 = NOVALUE;

    /** 	op_info[XOR                 ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13414);
    *((int *)(_2+16)) = _13414;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15248 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 152);
    _1 = *(int *)_2;
    *(int *)_2 = _15248;
    if( _1 != _15248 ){
        DeRef(_1);
    }
    _15248 = NOVALUE;

    /** 	op_info[XOR_BITS            ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13414);
    *((int *)(_2+16)) = _13414;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15249 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 26);
    _1 = *(int *)_2;
    *(int *)_2 = _15249;
    if( _1 != _15249 ){
        DeRef(_1);
    }
    _15249 = NOVALUE;

    /** 	op_info[TYPE_CHECK_FORWARD  ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15250 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 197);
    _1 = *(int *)_2;
    *(int *)_2 = _15250;
    if( _1 != _15250 ){
        DeRef(_1);
    }
    _15250 = NOVALUE;

    /** 	sequence SHORT_CIRCUIT = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _0 = _SHORT_CIRCUIT_27005;
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_13414);
    *((int *)(_2+12)) = _13414;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _SHORT_CIRCUIT_27005 = MAKE_SEQ(_1);
    DeRef(_0);

    /** 	op_info[SC1_AND_IF          ] = SHORT_CIRCUIT*/
    RefDS(_SHORT_CIRCUIT_27005);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 146);
    _1 = *(int *)_2;
    *(int *)_2 = _SHORT_CIRCUIT_27005;
    DeRef(_1);

    /** 	op_info[SC1_OR_IF           ] = SHORT_CIRCUIT*/
    RefDS(_SHORT_CIRCUIT_27005);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 147);
    _1 = *(int *)_2;
    *(int *)_2 = _SHORT_CIRCUIT_27005;
    DeRef(_1);

    /** 	op_info[SC1_AND             ] = SHORT_CIRCUIT*/
    RefDS(_SHORT_CIRCUIT_27005);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 141);
    _1 = *(int *)_2;
    *(int *)_2 = _SHORT_CIRCUIT_27005;
    DeRef(_1);

    /** 	op_info[SC1_OR              ] = SHORT_CIRCUIT*/
    RefDS(_SHORT_CIRCUIT_27005);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 143);
    _1 = *(int *)_2;
    *(int *)_2 = _SHORT_CIRCUIT_27005;
    DeRef(_1);

    /** 	op_info[ATOM_CHECK          ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15252 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 101);
    _1 = *(int *)_2;
    *(int *)_2 = _15252;
    if( _1 != _15252 ){
        DeRef(_1);
    }
    _15252 = NOVALUE;

    /** 	op_info[INTEGER_CHECK       ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15253 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 96);
    _1 = *(int *)_2;
    *(int *)_2 = _15253;
    if( _1 != _15253 ){
        DeRef(_1);
    }
    _15253 = NOVALUE;

    /** 	op_info[SEQUENCE_CHECK      ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15254 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 97);
    _1 = *(int *)_2;
    *(int *)_2 = _15254;
    if( _1 != _15254 ){
        DeRef(_1);
    }
    _15254 = NOVALUE;

    /** 	op_info[IS_AN_INTEGER       ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13477);
    *((int *)(_2+16)) = _13477;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15255 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 94);
    _1 = *(int *)_2;
    *(int *)_2 = _15255;
    if( _1 != _15255 ){
        DeRef(_1);
    }
    _15255 = NOVALUE;

    /** 	op_info[IS_AN_ATOM          ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13477);
    *((int *)(_2+16)) = _13477;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15256 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 67);
    _1 = *(int *)_2;
    *(int *)_2 = _15256;
    if( _1 != _15256 ){
        DeRef(_1);
    }
    _15256 = NOVALUE;

    /** 	op_info[IS_A_SEQUENCE       ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13477);
    *((int *)(_2+16)) = _13477;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15257 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 68);
    _1 = *(int *)_2;
    *(int *)_2 = _15257;
    if( _1 != _15257 ){
        DeRef(_1);
    }
    _15257 = NOVALUE;

    /** 	op_info[IS_AN_OBJECT        ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13477);
    *((int *)(_2+16)) = _13477;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15258 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 40);
    _1 = *(int *)_2;
    *(int *)_2 = _15258;
    if( _1 != _15258 ){
        DeRef(_1);
    }
    _15258 = NOVALUE;

    /** 	op_info[CALL_BACK_RETURN    ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 1;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15259 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 135);
    _1 = *(int *)_2;
    *(int *)_2 = _15259;
    if( _1 != _15259 ){
        DeRef(_1);
    }
    _15259 = NOVALUE;

    /** 	op_info[REF_TEMP            ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15260 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 207);
    _1 = *(int *)_2;
    *(int *)_2 = _15260;
    if( _1 != _15260 ){
        DeRef(_1);
    }
    _15260 = NOVALUE;

    /** 	op_info[DEREF_TEMP          ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15261 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 208);
    _1 = *(int *)_2;
    *(int *)_2 = _15261;
    if( _1 != _15261 ){
        DeRef(_1);
    }
    _15261 = NOVALUE;

    /** 	op_info[NOVALUE_TEMP        ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15262 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 209);
    _1 = *(int *)_2;
    *(int *)_2 = _15262;
    if( _1 != _15262 ){
        DeRef(_1);
    }
    _15262 = NOVALUE;

    /** 	op_info[PROC_FORWARD        ] = { VARIABLE_SIZE, 0, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 2;
    *((int *)(_2+8)) = 0;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15263 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 195);
    _1 = *(int *)_2;
    *(int *)_2 = _15263;
    if( _1 != _15263 ){
        DeRef(_1);
    }
    _15263 = NOVALUE;

    /** 	op_info[FUNC_FORWARD        ] = { VARIABLE_SIZE, 0, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 2;
    *((int *)(_2+8)) = 0;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15264 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 196);
    _1 = *(int *)_2;
    *(int *)_2 = _15264;
    if( _1 != _15264 ){
        DeRef(_1);
    }
    _15264 = NOVALUE;

    /** 	op_info[RIGHT_BRACE_N       ] = { VARIABLE_SIZE, 3, {}, {}, {} } -- target: [pc+1] + 2*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 2;
    *((int *)(_2+8)) = 3;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15265 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 31);
    _1 = *(int *)_2;
    *(int *)_2 = _15265;
    if( _1 != _15265 ){
        DeRef(_1);
    }
    _15265 = NOVALUE;

    /** 	op_info[CONCAT_N            ] = { VARIABLE_SIZE, 0, {}, {}, {} } -- target: [pc+1] + 2*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 2;
    *((int *)(_2+8)) = 0;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15266 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 157);
    _1 = *(int *)_2;
    *(int *)_2 = _15266;
    if( _1 != _15266 ){
        DeRef(_1);
    }
    _15266 = NOVALUE;

    /** 	op_info[PROC                ] = { VARIABLE_SIZE, 0, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 2;
    *((int *)(_2+8)) = 0;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15267 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 27);
    _1 = *(int *)_2;
    *(int *)_2 = _15267;
    if( _1 != _15267 ){
        DeRef(_1);
    }
    _15267 = NOVALUE;

    /** 	op_info[PROC_TAIL           ] = op_info[PROC]*/
    _2 = (int)SEQ_PTR(_65op_info_26607);
    _15268 = (int)*(((s1_ptr)_2)->base + 27);
    Ref(_15268);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26607 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 203);
    _1 = *(int *)_2;
    *(int *)_2 = _15268;
    if( _1 != _15268 ){
        DeRef(_1);
    }
    _15268 = NOVALUE;

    /** end procedure*/
    DeRefDS(_SHORT_CIRCUIT_27005);
    return;
    ;
}


int _65op_size(int _pc_27048, int _code_27049)
{
    int _op_27052 = NOVALUE;
    int _info_27054 = NOVALUE;
    int _int_27056 = NOVALUE;
    int _15293 = NOVALUE;
    int _15290 = NOVALUE;
    int _15287 = NOVALUE;
    int _15284 = NOVALUE;
    int _15283 = NOVALUE;
    int _15282 = NOVALUE;
    int _15281 = NOVALUE;
    int _15280 = NOVALUE;
    int _15279 = NOVALUE;
    int _15277 = NOVALUE;
    int _15276 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer op = code[pc]*/
    _2 = (int)SEQ_PTR(_code_27049);
    _op_27052 = (int)*(((s1_ptr)_2)->base + _pc_27048);
    if (!IS_ATOM_INT(_op_27052))
    _op_27052 = (long)DBL_PTR(_op_27052)->dbl;

    /** 	sequence info = op_info[op]*/
    DeRef(_info_27054);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    _info_27054 = (int)*(((s1_ptr)_2)->base + _op_27052);
    Ref(_info_27054);

    /** 	integer int = info[OP_SIZE_TYPE]*/
    _2 = (int)SEQ_PTR(_info_27054);
    _int_27056 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_int_27056))
    _int_27056 = (long)DBL_PTR(_int_27056)->dbl;

    /** 	if int = FIXED_SIZE then*/
    if (_int_27056 != 1)
    goto L1; // [29] 48

    /** 		int = info[OP_SIZE]*/
    _2 = (int)SEQ_PTR(_info_27054);
    _int_27056 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_int_27056))
    _int_27056 = (long)DBL_PTR(_int_27056)->dbl;

    /** 		return int*/
    DeRefDS(_code_27049);
    DeRefDS(_info_27054);
    return _int_27056;
    goto L2; // [45] 203
L1: 

    /** 		switch op do*/
    _0 = _op_27052;
    switch ( _0 ){ 

        /** 			case PROC, PROC_TAIL then*/
        case 27:
        case 203:

        /** 				info = SymTab[code[pc+1]]*/
        _15276 = _pc_27048 + 1;
        _2 = (int)SEQ_PTR(_code_27049);
        _15277 = (int)*(((s1_ptr)_2)->base + _15276);
        DeRef(_info_27054);
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        if (!IS_ATOM_INT(_15277)){
            _info_27054 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_15277)->dbl));
        }
        else{
            _info_27054 = (int)*(((s1_ptr)_2)->base + _15277);
        }
        Ref(_info_27054);

        /** 				return info[S_NUM_ARGS] + 2 + (info[S_TOKEN] != PROC)*/
        _2 = (int)SEQ_PTR(_info_27054);
        if (!IS_ATOM_INT(_35S_NUM_ARGS_15968)){
            _15279 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NUM_ARGS_15968)->dbl));
        }
        else{
            _15279 = (int)*(((s1_ptr)_2)->base + _35S_NUM_ARGS_15968);
        }
        if (IS_ATOM_INT(_15279)) {
            _15280 = _15279 + 2;
            if ((long)((unsigned long)_15280 + (unsigned long)HIGH_BITS) >= 0) 
            _15280 = NewDouble((double)_15280);
        }
        else {
            _15280 = binary_op(PLUS, _15279, 2);
        }
        _15279 = NOVALUE;
        _2 = (int)SEQ_PTR(_info_27054);
        if (!IS_ATOM_INT(_35S_TOKEN_15922)){
            _15281 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TOKEN_15922)->dbl));
        }
        else{
            _15281 = (int)*(((s1_ptr)_2)->base + _35S_TOKEN_15922);
        }
        if (IS_ATOM_INT(_15281)) {
            _15282 = (_15281 != 27);
        }
        else {
            _15282 = binary_op(NOTEQ, _15281, 27);
        }
        _15281 = NOVALUE;
        if (IS_ATOM_INT(_15280) && IS_ATOM_INT(_15282)) {
            _15283 = _15280 + _15282;
            if ((long)((unsigned long)_15283 + (unsigned long)HIGH_BITS) >= 0) 
            _15283 = NewDouble((double)_15283);
        }
        else {
            _15283 = binary_op(PLUS, _15280, _15282);
        }
        DeRef(_15280);
        _15280 = NOVALUE;
        DeRef(_15282);
        _15282 = NOVALUE;
        DeRefDS(_code_27049);
        DeRefDS(_info_27054);
        _15276 = NOVALUE;
        _15277 = NOVALUE;
        return _15283;
        goto L3; // [111] 196

        /** 			case PROC_FORWARD then*/
        case 195:

        /** 				int = code[pc+2]*/
        _15284 = _pc_27048 + 2;
        _2 = (int)SEQ_PTR(_code_27049);
        _int_27056 = (int)*(((s1_ptr)_2)->base + _15284);
        if (!IS_ATOM_INT(_int_27056))
        _int_27056 = (long)DBL_PTR(_int_27056)->dbl;

        /** 				int += 3*/
        _int_27056 = _int_27056 + 3;
        goto L3; // [133] 196

        /** 			case FUNC_FORWARD then*/
        case 196:

        /** 				int = code[pc+2]*/
        _15287 = _pc_27048 + 2;
        _2 = (int)SEQ_PTR(_code_27049);
        _int_27056 = (int)*(((s1_ptr)_2)->base + _15287);
        if (!IS_ATOM_INT(_int_27056))
        _int_27056 = (long)DBL_PTR(_int_27056)->dbl;

        /** 				int += 4*/
        _int_27056 = _int_27056 + 4;
        goto L3; // [155] 196

        /** 			case RIGHT_BRACE_N, CONCAT_N then*/
        case 31:
        case 157:

        /** 				int = code[pc+1]*/
        _15290 = _pc_27048 + 1;
        _2 = (int)SEQ_PTR(_code_27049);
        _int_27056 = (int)*(((s1_ptr)_2)->base + _15290);
        if (!IS_ATOM_INT(_int_27056))
        _int_27056 = (long)DBL_PTR(_int_27056)->dbl;

        /** 				int += 3*/
        _int_27056 = _int_27056 + 3;
        goto L3; // [179] 196

        /** 			case else*/
        default:

        /** 				InternalErr( 269, {op} )*/
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = _op_27052;
        _15293 = MAKE_SEQ(_1);
        _44InternalErr(269, _15293);
        _15293 = NOVALUE;
    ;}L3: 

    /** 		return int*/
    DeRefDS(_code_27049);
    DeRef(_info_27054);
    DeRef(_15276);
    _15276 = NOVALUE;
    _15277 = NOVALUE;
    DeRef(_15283);
    _15283 = NOVALUE;
    DeRef(_15284);
    _15284 = NOVALUE;
    DeRef(_15287);
    _15287 = NOVALUE;
    DeRef(_15290);
    _15290 = NOVALUE;
    return _int_27056;
L2: 
    ;
}


int _65advance(int _pc_27100, int _code_27101)
{
    int _15294 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_pc_27100)) {
        _1 = (long)(DBL_PTR(_pc_27100)->dbl);
        DeRefDS(_pc_27100);
        _pc_27100 = _1;
    }

    /** 	pc += op_size( pc, code )*/
    RefDS(_code_27101);
    _15294 = _65op_size(_pc_27100, _code_27101);
    if (IS_ATOM_INT(_15294)) {
        _pc_27100 = _pc_27100 + _15294;
    }
    else {
        _pc_27100 = binary_op(PLUS, _pc_27100, _15294);
    }
    DeRef(_15294);
    _15294 = NOVALUE;
    if (!IS_ATOM_INT(_pc_27100)) {
        _1 = (long)(DBL_PTR(_pc_27100)->dbl);
        DeRefDS(_pc_27100);
        _pc_27100 = _1;
    }

    /** 	return pc*/
    DeRefDS(_code_27101);
    return _pc_27100;
    ;
}


void _65shift_switch(int _pc_27108, int _start_27109, int _amount_27110)
{
    int _addr_27111 = NOVALUE;
    int _jump_27143 = NOVALUE;
    int _15330 = NOVALUE;
    int _15329 = NOVALUE;
    int _15328 = NOVALUE;
    int _15327 = NOVALUE;
    int _15326 = NOVALUE;
    int _15325 = NOVALUE;
    int _15324 = NOVALUE;
    int _15323 = NOVALUE;
    int _15322 = NOVALUE;
    int _15321 = NOVALUE;
    int _15320 = NOVALUE;
    int _15318 = NOVALUE;
    int _15317 = NOVALUE;
    int _15316 = NOVALUE;
    int _15315 = NOVALUE;
    int _15314 = NOVALUE;
    int _15313 = NOVALUE;
    int _15312 = NOVALUE;
    int _15311 = NOVALUE;
    int _15309 = NOVALUE;
    int _15308 = NOVALUE;
    int _15307 = NOVALUE;
    int _15306 = NOVALUE;
    int _15305 = NOVALUE;
    int _15302 = NOVALUE;
    int _15300 = NOVALUE;
    int _15299 = NOVALUE;
    int _15298 = NOVALUE;
    int _15297 = NOVALUE;
    int _15296 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	if sequence( Code[pc+4] ) then*/
    _15296 = _pc_27108 + 4;
    _2 = (int)SEQ_PTR(_35Code_16332);
    _15297 = (int)*(((s1_ptr)_2)->base + _15296);
    _15298 = IS_SEQUENCE(_15297);
    _15297 = NOVALUE;
    if (_15298 == 0)
    {
        _15298 = NOVALUE;
        goto L1; // [22] 46
    }
    else{
        _15298 = NOVALUE;
    }

    /** 		addr = Code[pc+4][2]*/
    _15299 = _pc_27108 + 4;
    _2 = (int)SEQ_PTR(_35Code_16332);
    _15300 = (int)*(((s1_ptr)_2)->base + _15299);
    _2 = (int)SEQ_PTR(_15300);
    _addr_27111 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_addr_27111)){
        _addr_27111 = (long)DBL_PTR(_addr_27111)->dbl;
    }
    _15300 = NOVALUE;
    goto L2; // [43] 61
L1: 

    /** 		addr = Code[pc+4]*/
    _15302 = _pc_27108 + 4;
    _2 = (int)SEQ_PTR(_35Code_16332);
    _addr_27111 = (int)*(((s1_ptr)_2)->base + _15302);
    if (!IS_ATOM_INT(_addr_27111)){
        _addr_27111 = (long)DBL_PTR(_addr_27111)->dbl;
    }
L2: 

    /** 	if start < addr then*/
    if (_start_27109 >= _addr_27111)
    goto L3; // [65] 137

    /** 		if sequence( Code[pc+4] ) then*/
    _15305 = _pc_27108 + 4;
    _2 = (int)SEQ_PTR(_35Code_16332);
    _15306 = (int)*(((s1_ptr)_2)->base + _15305);
    _15307 = IS_SEQUENCE(_15306);
    _15306 = NOVALUE;
    if (_15307 == 0)
    {
        _15307 = NOVALUE;
        goto L4; // [84] 115
    }
    else{
        _15307 = NOVALUE;
    }

    /** 			Code[pc+4][2] += amount*/
    _15308 = _pc_27108 + 4;
    _2 = (int)SEQ_PTR(_35Code_16332);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _35Code_16332 = MAKE_SEQ(_2);
    }
    _3 = (int)(_15308 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    _15311 = (int)*(((s1_ptr)_2)->base + 2);
    _15309 = NOVALUE;
    if (IS_ATOM_INT(_15311)) {
        _15312 = _15311 + _amount_27110;
        if ((long)((unsigned long)_15312 + (unsigned long)HIGH_BITS) >= 0) 
        _15312 = NewDouble((double)_15312);
    }
    else {
        _15312 = binary_op(PLUS, _15311, _amount_27110);
    }
    _15311 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _15312;
    if( _1 != _15312 ){
        DeRef(_1);
    }
    _15312 = NOVALUE;
    _15309 = NOVALUE;
    goto L5; // [112] 136
L4: 

    /** 			Code[pc+4] += amount*/
    _15313 = _pc_27108 + 4;
    _2 = (int)SEQ_PTR(_35Code_16332);
    _15314 = (int)*(((s1_ptr)_2)->base + _15313);
    if (IS_ATOM_INT(_15314)) {
        _15315 = _15314 + _amount_27110;
        if ((long)((unsigned long)_15315 + (unsigned long)HIGH_BITS) >= 0) 
        _15315 = NewDouble((double)_15315);
    }
    else {
        _15315 = binary_op(PLUS, _15314, _amount_27110);
    }
    _15314 = NOVALUE;
    _2 = (int)SEQ_PTR(_35Code_16332);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _35Code_16332 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _15313);
    _1 = *(int *)_2;
    *(int *)_2 = _15315;
    if( _1 != _15315 ){
        DeRef(_1);
    }
    _15315 = NOVALUE;
L5: 
L3: 

    /** 	sequence jump = SymTab[Code[pc+3]][S_OBJ]*/
    _15316 = _pc_27108 + 3;
    _2 = (int)SEQ_PTR(_35Code_16332);
    _15317 = (int)*(((s1_ptr)_2)->base + _15316);
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!IS_ATOM_INT(_15317)){
        _15318 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_15317)->dbl));
    }
    else{
        _15318 = (int)*(((s1_ptr)_2)->base + _15317);
    }
    DeRef(_jump_27143);
    _2 = (int)SEQ_PTR(_15318);
    _jump_27143 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_jump_27143);
    _15318 = NOVALUE;

    /** 	for i = 1 to length(jump) do*/
    if (IS_SEQUENCE(_jump_27143)){
            _15320 = SEQ_PTR(_jump_27143)->length;
    }
    else {
        _15320 = 1;
    }
    {
        int _i_27152;
        _i_27152 = 1;
L6: 
        if (_i_27152 > _15320){
            goto L7; // [168] 223
        }

        /** 		if start > pc and start < pc + jump[i] then*/
        _15321 = (_start_27109 > _pc_27108);
        if (_15321 == 0) {
            goto L8; // [181] 216
        }
        _2 = (int)SEQ_PTR(_jump_27143);
        _15323 = (int)*(((s1_ptr)_2)->base + _i_27152);
        if (IS_ATOM_INT(_15323)) {
            _15324 = _pc_27108 + _15323;
            if ((long)((unsigned long)_15324 + (unsigned long)HIGH_BITS) >= 0) 
            _15324 = NewDouble((double)_15324);
        }
        else {
            _15324 = binary_op(PLUS, _pc_27108, _15323);
        }
        _15323 = NOVALUE;
        if (IS_ATOM_INT(_15324)) {
            _15325 = (_start_27109 < _15324);
        }
        else {
            _15325 = binary_op(LESS, _start_27109, _15324);
        }
        DeRef(_15324);
        _15324 = NOVALUE;
        if (_15325 == 0) {
            DeRef(_15325);
            _15325 = NOVALUE;
            goto L8; // [198] 216
        }
        else {
            if (!IS_ATOM_INT(_15325) && DBL_PTR(_15325)->dbl == 0.0){
                DeRef(_15325);
                _15325 = NOVALUE;
                goto L8; // [198] 216
            }
            DeRef(_15325);
            _15325 = NOVALUE;
        }
        DeRef(_15325);
        _15325 = NOVALUE;

        /** 			jump[i] += amount*/
        _2 = (int)SEQ_PTR(_jump_27143);
        _15326 = (int)*(((s1_ptr)_2)->base + _i_27152);
        if (IS_ATOM_INT(_15326)) {
            _15327 = _15326 + _amount_27110;
            if ((long)((unsigned long)_15327 + (unsigned long)HIGH_BITS) >= 0) 
            _15327 = NewDouble((double)_15327);
        }
        else {
            _15327 = binary_op(PLUS, _15326, _amount_27110);
        }
        _15326 = NOVALUE;
        _2 = (int)SEQ_PTR(_jump_27143);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _jump_27143 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_27152);
        _1 = *(int *)_2;
        *(int *)_2 = _15327;
        if( _1 != _15327 ){
            DeRef(_1);
        }
        _15327 = NOVALUE;
L8: 

        /** 	end for*/
        _i_27152 = _i_27152 + 1;
        goto L6; // [218] 175
L7: 
        ;
    }

    /** 	SymTab[Code[pc+3]][S_OBJ] = jump*/
    _15328 = _pc_27108 + 3;
    _2 = (int)SEQ_PTR(_35Code_16332);
    _15329 = (int)*(((s1_ptr)_2)->base + _15328);
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_15329))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_15329)->dbl));
    else
    _3 = (int)(_15329 + ((s1_ptr)_2)->base);
    RefDS(_jump_27143);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _jump_27143;
    DeRef(_1);
    _15330 = NOVALUE;

    /** end procedure*/
    DeRefDS(_jump_27143);
    DeRef(_15296);
    _15296 = NOVALUE;
    DeRef(_15299);
    _15299 = NOVALUE;
    DeRef(_15302);
    _15302 = NOVALUE;
    DeRef(_15305);
    _15305 = NOVALUE;
    DeRef(_15308);
    _15308 = NOVALUE;
    DeRef(_15313);
    _15313 = NOVALUE;
    DeRef(_15316);
    _15316 = NOVALUE;
    _15317 = NOVALUE;
    DeRef(_15321);
    _15321 = NOVALUE;
    _15328 = NOVALUE;
    _15329 = NOVALUE;
    return;
    ;
}


void _65shift_addr(int _pc_27171, int _amount_27172, int _start_27173, int _bound_27174)
{
    int _int_27175 = NOVALUE;
    int _15345 = NOVALUE;
    int _15342 = NOVALUE;
    int _15338 = NOVALUE;
    int _15333 = NOVALUE;
    int _15332 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_pc_27171)) {
        _1 = (long)(DBL_PTR(_pc_27171)->dbl);
        DeRefDS(_pc_27171);
        _pc_27171 = _1;
    }

    /** 	if atom( Code[pc] ) then*/
    _2 = (int)SEQ_PTR(_35Code_16332);
    _15332 = (int)*(((s1_ptr)_2)->base + _pc_27171);
    _15333 = IS_ATOM(_15332);
    _15332 = NOVALUE;
    if (_15333 == 0)
    {
        _15333 = NOVALUE;
        goto L1; // [20] 75
    }
    else{
        _15333 = NOVALUE;
    }

    /** 		int = Code[pc]*/
    _2 = (int)SEQ_PTR(_35Code_16332);
    _int_27175 = (int)*(((s1_ptr)_2)->base + _pc_27171);
    if (!IS_ATOM_INT(_int_27175)){
        _int_27175 = (long)DBL_PTR(_int_27175)->dbl;
    }

    /** 		if int >= start then*/
    if (_int_27175 < _start_27173)
    goto L2; // [35] 139

    /** 			if int < bound then*/
    if (_int_27175 >= _bound_27174)
    goto L3; // [41] 56

    /** 				Code[pc] = start*/
    _2 = (int)SEQ_PTR(_35Code_16332);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _35Code_16332 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _pc_27171);
    _1 = *(int *)_2;
    *(int *)_2 = _start_27173;
    DeRef(_1);
    goto L2; // [53] 139
L3: 

    /** 				int += amount*/
    _int_27175 = _int_27175 + _amount_27172;

    /** 				Code[pc] = int*/
    _2 = (int)SEQ_PTR(_35Code_16332);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _35Code_16332 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _pc_27171);
    _1 = *(int *)_2;
    *(int *)_2 = _int_27175;
    DeRef(_1);
    goto L2; // [72] 139
L1: 

    /** 		int = Code[pc][2]*/
    _2 = (int)SEQ_PTR(_35Code_16332);
    _15338 = (int)*(((s1_ptr)_2)->base + _pc_27171);
    _2 = (int)SEQ_PTR(_15338);
    _int_27175 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_int_27175)){
        _int_27175 = (long)DBL_PTR(_int_27175)->dbl;
    }
    _15338 = NOVALUE;

    /** 		if int >= start then*/
    if (_int_27175 < _start_27173)
    goto L4; // [91] 138

    /** 			if int < bound then*/
    if (_int_27175 >= _bound_27174)
    goto L5; // [97] 117

    /** 				Code[pc][2] = start*/
    _2 = (int)SEQ_PTR(_35Code_16332);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _35Code_16332 = MAKE_SEQ(_2);
    }
    _3 = (int)(_pc_27171 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _start_27173;
    DeRef(_1);
    _15342 = NOVALUE;
    goto L6; // [114] 137
L5: 

    /** 				int += amount*/
    _int_27175 = _int_27175 + _amount_27172;

    /** 				Code[pc][2] = int*/
    _2 = (int)SEQ_PTR(_35Code_16332);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _35Code_16332 = MAKE_SEQ(_2);
    }
    _3 = (int)(_pc_27171 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _int_27175;
    DeRef(_1);
    _15345 = NOVALUE;
L6: 
L4: 
L2: 

    /** end procedure*/
    return;
    ;
}


void _65shift(int _start_27208, int _amount_27209, int _bound_27210)
{
    int _int_27213 = NOVALUE;
    int _pc_27226 = NOVALUE;
    int _op_27227 = NOVALUE;
    int _finish_27228 = NOVALUE;
    int _len_27231 = NOVALUE;
    int _addrs_27242 = NOVALUE;
    int _15367 = NOVALUE;
    int _15363 = NOVALUE;
    int _15361 = NOVALUE;
    int _15359 = NOVALUE;
    int _15357 = NOVALUE;
    int _15353 = NOVALUE;
    int _15348 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_start_27208)) {
        _1 = (long)(DBL_PTR(_start_27208)->dbl);
        DeRefDS(_start_27208);
        _start_27208 = _1;
    }
    if (!IS_ATOM_INT(_amount_27209)) {
        _1 = (long)(DBL_PTR(_amount_27209)->dbl);
        DeRefDS(_amount_27209);
        _amount_27209 = _1;
    }
    if (!IS_ATOM_INT(_bound_27210)) {
        _1 = (long)(DBL_PTR(_bound_27210)->dbl);
        DeRefDS(_bound_27210);
        _bound_27210 = _1;
    }

    /** 	if amount = 0 then*/
    if (_amount_27209 != 0)
    goto L1; // [9] 19

    /** 		return*/
    return;
L1: 

    /** 	integer int*/

    /** 	for i = length( LineTable ) to 1 by -1 do*/
    if (IS_SEQUENCE(_35LineTable_16333)){
            _15348 = SEQ_PTR(_35LineTable_16333)->length;
    }
    else {
        _15348 = 1;
    }
    {
        int _i_27215;
        _i_27215 = _15348;
L2: 
        if (_i_27215 < 1){
            goto L3; // [28] 84
        }

        /** 		int = LineTable[i]*/
        _2 = (int)SEQ_PTR(_35LineTable_16333);
        _int_27213 = (int)*(((s1_ptr)_2)->base + _i_27215);
        if (!IS_ATOM_INT(_int_27213)){
            _int_27213 = (long)DBL_PTR(_int_27213)->dbl;
        }

        /** 		if int > 0 then*/
        if (_int_27213 <= 0)
        goto L4; // [47] 77

        /** 			if int < start then*/
        if (_int_27213 >= _start_27208)
        goto L5; // [53] 62

        /** 				exit*/
        goto L3; // [59] 84
L5: 

        /** 			int += amount*/
        _int_27213 = _int_27213 + _amount_27209;

        /** 			LineTable[i] = int*/
        _2 = (int)SEQ_PTR(_35LineTable_16333);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _35LineTable_16333 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_27215);
        _1 = *(int *)_2;
        *(int *)_2 = _int_27213;
        DeRef(_1);
L4: 

        /** 	end for*/
        _i_27215 = _i_27215 + -1;
        goto L2; // [79] 35
L3: 
        ;
    }

    /** 	integer pc = 1*/
    _pc_27226 = 1;

    /** 	integer op*/

    /** 	integer finish = start + amount - 1*/
    _15353 = _start_27208 + _amount_27209;
    if ((long)((unsigned long)_15353 + (unsigned long)HIGH_BITS) >= 0) 
    _15353 = NewDouble((double)_15353);
    if (IS_ATOM_INT(_15353)) {
        _finish_27228 = _15353 - 1;
    }
    else {
        _finish_27228 = NewDouble(DBL_PTR(_15353)->dbl - (double)1);
    }
    DeRef(_15353);
    _15353 = NOVALUE;
    if (!IS_ATOM_INT(_finish_27228)) {
        _1 = (long)(DBL_PTR(_finish_27228)->dbl);
        DeRefDS(_finish_27228);
        _finish_27228 = _1;
    }

    /** 	integer len = length( Code )*/
    if (IS_SEQUENCE(_35Code_16332)){
            _len_27231 = SEQ_PTR(_35Code_16332)->length;
    }
    else {
        _len_27231 = 1;
    }

    /** 	while pc <= len do*/
L6: 
    if (_pc_27226 > _len_27231)
    goto L7; // [115] 251

    /** 		if pc < start or pc > finish then*/
    _15357 = (_pc_27226 < _start_27208);
    if (_15357 != 0) {
        goto L8; // [125] 138
    }
    _15359 = (_pc_27226 > _finish_27228);
    if (_15359 == 0)
    {
        DeRef(_15359);
        _15359 = NOVALUE;
        goto L9; // [134] 233
    }
    else{
        DeRef(_15359);
        _15359 = NOVALUE;
    }
L8: 

    /** 			op = Code[pc]*/
    _2 = (int)SEQ_PTR(_35Code_16332);
    _op_27227 = (int)*(((s1_ptr)_2)->base + _pc_27226);
    if (!IS_ATOM_INT(_op_27227)){
        _op_27227 = (long)DBL_PTR(_op_27227)->dbl;
    }

    /** 			sequence addrs = op_info[op][OP_ADDR]*/
    _2 = (int)SEQ_PTR(_65op_info_26607);
    _15361 = (int)*(((s1_ptr)_2)->base + _op_27227);
    DeRef(_addrs_27242);
    _2 = (int)SEQ_PTR(_15361);
    _addrs_27242 = (int)*(((s1_ptr)_2)->base + 3);
    Ref(_addrs_27242);
    _15361 = NOVALUE;

    /** 			for i = 1 to length( addrs ) do*/
    if (IS_SEQUENCE(_addrs_27242)){
            _15363 = SEQ_PTR(_addrs_27242)->length;
    }
    else {
        _15363 = 1;
    }
    {
        int _i_27246;
        _i_27246 = 1;
LA: 
        if (_i_27246 > _15363){
            goto LB; // [167] 232
        }

        /** 				switch op with fallthru do*/
        _0 = _op_27227;
        switch ( _0 ){ 

            /** 					case SWITCH then*/
            case 185:
            case 193:
            case 192:
            case 202:

            /** 						shift_switch( pc, start, amount )*/
            _65shift_switch(_pc_27226, _start_27208, _amount_27209);

            /** 						break*/
            goto LC; // [200] 225

            /** 					case else*/
            default:

            /** 						int = addrs[i]*/
            _2 = (int)SEQ_PTR(_addrs_27242);
            _int_27213 = (int)*(((s1_ptr)_2)->base + _i_27246);
            if (!IS_ATOM_INT(_int_27213))
            _int_27213 = (long)DBL_PTR(_int_27213)->dbl;

            /** 						shift_addr( pc + int, amount, start, bound )*/
            _15367 = _pc_27226 + _int_27213;
            if ((long)((unsigned long)_15367 + (unsigned long)HIGH_BITS) >= 0) 
            _15367 = NewDouble((double)_15367);
            _65shift_addr(_15367, _amount_27209, _start_27208, _bound_27210);
            _15367 = NOVALUE;
        ;}LC: 

        /** 			end for*/
        _i_27246 = _i_27246 + 1;
        goto LA; // [227] 174
LB: 
        ;
    }
L9: 
    DeRef(_addrs_27242);
    _addrs_27242 = NOVALUE;

    /** 		pc = advance( pc )*/
    RefDS(_35Code_16332);
    _pc_27226 = _65advance(_pc_27226, _35Code_16332);
    if (!IS_ATOM_INT(_pc_27226)) {
        _1 = (long)(DBL_PTR(_pc_27226)->dbl);
        DeRefDS(_pc_27226);
        _pc_27226 = _1;
    }

    /** 	end while*/
    goto L6; // [248] 115
L7: 

    /** 	shift_fwd_refs( start, amount )*/
    _38shift_fwd_refs(_start_27208, _amount_27209);

    /** 	move_last_pc( amount )*/
    _41move_last_pc(_amount_27209);

    /** end procedure*/
    DeRef(_15357);
    _15357 = NOVALUE;
    return;
    ;
}


void _65insert_code(int _code_27264, int _index_27265)
{
    int _15370 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_index_27265)) {
        _1 = (long)(DBL_PTR(_index_27265)->dbl);
        DeRefDS(_index_27265);
        _index_27265 = _1;
    }

    /** 	Code = splice( Code, code, index )*/
    {
        s1_ptr assign_space;
        insert_pos = _index_27265;
        if (insert_pos <= 0) {
            Concat(&_35Code_16332,_code_27264,_35Code_16332);
        }
        else if (insert_pos > SEQ_PTR(_35Code_16332)->length){
            Concat(&_35Code_16332,_35Code_16332,_code_27264);
        }
        else if (IS_SEQUENCE(_code_27264)) {
            if( _35Code_16332 != _35Code_16332 || SEQ_PTR( _35Code_16332 )->ref != 1 ){
                DeRef( _35Code_16332 );
                RefDS( _35Code_16332 );
            }
            assign_space = Add_internal_space( _35Code_16332, insert_pos,((s1_ptr)SEQ_PTR(_code_27264))->length);
            assign_slice_seq = &assign_space;
            assign_space = Copy_elements( insert_pos, SEQ_PTR(_code_27264), _35Code_16332 == _35Code_16332 );
            _35Code_16332 = MAKE_SEQ( assign_space );
        }
        else {
            if( _35Code_16332 != _35Code_16332 && SEQ_PTR( _35Code_16332 )->ref != 1 ){
                _35Code_16332 = Insert( _35Code_16332, _code_27264, insert_pos);
            }
            else {
                DeRef( _35Code_16332 );
                RefDS( _35Code_16332 );
                _35Code_16332 = Insert( _35Code_16332, _code_27264, insert_pos);
            }
        }
    }

    /** 	shift( index, length( code ) )*/
    if (IS_SEQUENCE(_code_27264)){
            _15370 = SEQ_PTR(_code_27264)->length;
    }
    else {
        _15370 = 1;
    }
    _65shift(_index_27265, _15370, _index_27265);
    _15370 = NOVALUE;

    /** end procedure*/
    DeRefDS(_code_27264);
    return;
    ;
}


void _65replace_code(int _code_27272, int _start_27273, int _finish_27274)
{
    int _15375 = NOVALUE;
    int _15374 = NOVALUE;
    int _15373 = NOVALUE;
    int _15372 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_start_27273)) {
        _1 = (long)(DBL_PTR(_start_27273)->dbl);
        DeRefDS(_start_27273);
        _start_27273 = _1;
    }
    if (!IS_ATOM_INT(_finish_27274)) {
        _1 = (long)(DBL_PTR(_finish_27274)->dbl);
        DeRefDS(_finish_27274);
        _finish_27274 = _1;
    }

    /** 	Code = replace( Code, code, start, finish )*/
    {
        int p1 = _35Code_16332;
        int p2 = _code_27272;
        int p3 = _start_27273;
        int p4 = _finish_27274;
        struct replace_block replace_params;
        replace_params.copy_to   = &p1;
        replace_params.copy_from = &p2;
        replace_params.start     = &p3;
        replace_params.stop      = &p4;
        replace_params.target    = &_35Code_16332;
        Replace( &replace_params );
    }

    /** 	shift( start, length( code ) - (finish - start + 1), finish )*/
    if (IS_SEQUENCE(_code_27272)){
            _15372 = SEQ_PTR(_code_27272)->length;
    }
    else {
        _15372 = 1;
    }
    _15373 = _finish_27274 - _start_27273;
    if ((long)((unsigned long)_15373 +(unsigned long) HIGH_BITS) >= 0){
        _15373 = NewDouble((double)_15373);
    }
    if (IS_ATOM_INT(_15373)) {
        _15374 = _15373 + 1;
        if (_15374 > MAXINT){
            _15374 = NewDouble((double)_15374);
        }
    }
    else
    _15374 = binary_op(PLUS, 1, _15373);
    DeRef(_15373);
    _15373 = NOVALUE;
    if (IS_ATOM_INT(_15374)) {
        _15375 = _15372 - _15374;
        if ((long)((unsigned long)_15375 +(unsigned long) HIGH_BITS) >= 0){
            _15375 = NewDouble((double)_15375);
        }
    }
    else {
        _15375 = NewDouble((double)_15372 - DBL_PTR(_15374)->dbl);
    }
    _15372 = NOVALUE;
    DeRef(_15374);
    _15374 = NOVALUE;
    _65shift(_start_27273, _15375, _finish_27274);
    _15375 = NOVALUE;

    /** end procedure*/
    DeRefDS(_code_27272);
    return;
    ;
}


int _65current_op(int _pc_27284, int _code_27285)
{
    int _15383 = NOVALUE;
    int _15382 = NOVALUE;
    int _15381 = NOVALUE;
    int _15380 = NOVALUE;
    int _15379 = NOVALUE;
    int _15377 = NOVALUE;
    int _15376 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_pc_27284)) {
        _1 = (long)(DBL_PTR(_pc_27284)->dbl);
        DeRefDS(_pc_27284);
        _pc_27284 = _1;
    }

    /** 	if pc > length(code) or pc < 1 then*/
    if (IS_SEQUENCE(_code_27285)){
            _15376 = SEQ_PTR(_code_27285)->length;
    }
    else {
        _15376 = 1;
    }
    _15377 = (_pc_27284 > _15376);
    _15376 = NOVALUE;
    if (_15377 != 0) {
        goto L1; // [14] 27
    }
    _15379 = (_pc_27284 < 1);
    if (_15379 == 0)
    {
        DeRef(_15379);
        _15379 = NOVALUE;
        goto L2; // [23] 34
    }
    else{
        DeRef(_15379);
        _15379 = NOVALUE;
    }
L1: 

    /** 		return {}*/
    RefDS(_5);
    DeRefDS(_code_27285);
    DeRef(_15377);
    _15377 = NOVALUE;
    return _5;
L2: 

    /** 	return code[pc..pc-1+op_size( pc, code )]*/
    _15380 = _pc_27284 - 1;
    if ((long)((unsigned long)_15380 +(unsigned long) HIGH_BITS) >= 0){
        _15380 = NewDouble((double)_15380);
    }
    RefDS(_code_27285);
    _15381 = _65op_size(_pc_27284, _code_27285);
    if (IS_ATOM_INT(_15380) && IS_ATOM_INT(_15381)) {
        _15382 = _15380 + _15381;
    }
    else {
        _15382 = binary_op(PLUS, _15380, _15381);
    }
    DeRef(_15380);
    _15380 = NOVALUE;
    DeRef(_15381);
    _15381 = NOVALUE;
    rhs_slice_target = (object_ptr)&_15383;
    RHS_Slice(_code_27285, _pc_27284, _15382);
    DeRefDS(_code_27285);
    DeRef(_15377);
    _15377 = NOVALUE;
    DeRef(_15382);
    _15382 = NOVALUE;
    return _15383;
    ;
}


int _65get_ops(int _pc_27299, int _offset_27300, int _num_ops_27301, int _code_27302)
{
    int _sign_27305 = NOVALUE;
    int _ops_27314 = NOVALUE;
    int _opx_27316 = NOVALUE;
    int _15400 = NOVALUE;
    int _15399 = NOVALUE;
    int _15395 = NOVALUE;
    int _15394 = NOVALUE;
    int _15393 = NOVALUE;
    int _15392 = NOVALUE;
    int _15391 = NOVALUE;
    int _15390 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_pc_27299)) {
        _1 = (long)(DBL_PTR(_pc_27299)->dbl);
        DeRefDS(_pc_27299);
        _pc_27299 = _1;
    }
    if (!IS_ATOM_INT(_offset_27300)) {
        _1 = (long)(DBL_PTR(_offset_27300)->dbl);
        DeRefDS(_offset_27300);
        _offset_27300 = _1;
    }
    if (!IS_ATOM_INT(_num_ops_27301)) {
        _1 = (long)(DBL_PTR(_num_ops_27301)->dbl);
        DeRefDS(_num_ops_27301);
        _num_ops_27301 = _1;
    }

    /** 	integer sign = offset >= 0*/
    _sign_27305 = (_offset_27300 >= 0);

    /** 	if not sign then*/
    if (_sign_27305 != 0)
    goto L1; // [17] 33

    /** 		offset = -offset*/
    _offset_27300 = - _offset_27300;

    /** 		sign = -1*/
    _sign_27305 = -1;
L1: 

    /** 	while offset do*/
L2: 
    if (_offset_27300 == 0)
    {
        goto L3; // [38] 63
    }
    else{
    }

    /** 		pc = advance( pc )*/
    RefDS(_35Code_16332);
    _pc_27299 = _65advance(_pc_27299, _35Code_16332);
    if (!IS_ATOM_INT(_pc_27299)) {
        _1 = (long)(DBL_PTR(_pc_27299)->dbl);
        DeRefDS(_pc_27299);
        _pc_27299 = _1;
    }

    /** 		offset -= sign*/
    _offset_27300 = _offset_27300 - _sign_27305;

    /** 	end while*/
    goto L2; // [60] 38
L3: 

    /** 	sequence ops = repeat( 0, num_ops )*/
    DeRef(_ops_27314);
    _ops_27314 = Repeat(0, _num_ops_27301);

    /** 	integer opx = 1*/
    _opx_27316 = 1;

    /** 	while num_ops and pc <= length(code) do*/
L4: 
    if (_num_ops_27301 == 0) {
        goto L5; // [79] 137
    }
    if (IS_SEQUENCE(_code_27302)){
            _15391 = SEQ_PTR(_code_27302)->length;
    }
    else {
        _15391 = 1;
    }
    _15392 = (_pc_27299 <= _15391);
    _15391 = NOVALUE;
    if (_15392 == 0)
    {
        DeRef(_15392);
        _15392 = NOVALUE;
        goto L5; // [91] 137
    }
    else{
        DeRef(_15392);
        _15392 = NOVALUE;
    }

    /** 		ops[opx] = current_op( pc )*/
    RefDS(_35Code_16332);
    _15393 = _65current_op(_pc_27299, _35Code_16332);
    _2 = (int)SEQ_PTR(_ops_27314);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _ops_27314 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _opx_27316);
    _1 = *(int *)_2;
    *(int *)_2 = _15393;
    if( _1 != _15393 ){
        DeRef(_1);
    }
    _15393 = NOVALUE;

    /** 		pc += length( ops[opx] )*/
    _2 = (int)SEQ_PTR(_ops_27314);
    _15394 = (int)*(((s1_ptr)_2)->base + _opx_27316);
    if (IS_SEQUENCE(_15394)){
            _15395 = SEQ_PTR(_15394)->length;
    }
    else {
        _15395 = 1;
    }
    _15394 = NOVALUE;
    _pc_27299 = _pc_27299 + _15395;
    _15395 = NOVALUE;

    /** 		opx += 1*/
    _opx_27316 = _opx_27316 + 1;

    /** 		num_ops -= 1*/
    _num_ops_27301 = _num_ops_27301 - 1;

    /** 	end while*/
    goto L4; // [134] 79
L5: 

    /** 	if num_ops then*/
    if (_num_ops_27301 == 0)
    {
        goto L6; // [139] 156
    }
    else{
    }

    /** 		ops = head( ops, length( ops ) - num_ops )*/
    if (IS_SEQUENCE(_ops_27314)){
            _15399 = SEQ_PTR(_ops_27314)->length;
    }
    else {
        _15399 = 1;
    }
    _15400 = _15399 - _num_ops_27301;
    if ((long)((unsigned long)_15400 +(unsigned long) HIGH_BITS) >= 0){
        _15400 = NewDouble((double)_15400);
    }
    _15399 = NOVALUE;
    {
        int len = SEQ_PTR(_ops_27314)->length;
        int size = (IS_ATOM_INT(_15400)) ? _15400 : (long)(DBL_PTR(_15400)->dbl);
        if (size <= 0) _ops_27314 = MAKE_SEQ(NewS1(0));
        else if (len <= size) {
            RefDS(_ops_27314);
            DeRef(_ops_27314);
            _ops_27314 = _ops_27314;
        }
        else Head(SEQ_PTR(_ops_27314),size+1,&_ops_27314);
    }
    DeRef(_15400);
    _15400 = NOVALUE;
L6: 

    /** 	return ops*/
    DeRefDS(_code_27302);
    _15394 = NOVALUE;
    return _ops_27314;
    ;
}


int _65find_ops(int _pc_27334, int _op_27335, int _code_27336)
{
    int _ops_27339 = NOVALUE;
    int _found_op_27343 = NOVALUE;
    int _15409 = NOVALUE;
    int _15407 = NOVALUE;
    int _15405 = NOVALUE;
    int _15402 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_pc_27334)) {
        _1 = (long)(DBL_PTR(_pc_27334)->dbl);
        DeRefDS(_pc_27334);
        _pc_27334 = _1;
    }
    if (!IS_ATOM_INT(_op_27335)) {
        _1 = (long)(DBL_PTR(_op_27335)->dbl);
        DeRefDS(_op_27335);
        _op_27335 = _1;
    }

    /** 	sequence ops = {}*/
    RefDS(_5);
    DeRef(_ops_27339);
    _ops_27339 = _5;

    /** 	while pc <= length(code) do*/
L1: 
    if (IS_SEQUENCE(_code_27336)){
            _15402 = SEQ_PTR(_code_27336)->length;
    }
    else {
        _15402 = 1;
    }
    if (_pc_27334 > _15402)
    goto L2; // [22] 74

    /** 		sequence found_op = current_op( pc )*/
    RefDS(_35Code_16332);
    _0 = _found_op_27343;
    _found_op_27343 = _65current_op(_pc_27334, _35Code_16332);
    DeRef(_0);

    /** 		if found_op[1] = op then*/
    _2 = (int)SEQ_PTR(_found_op_27343);
    _15405 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _15405, _op_27335)){
        _15405 = NOVALUE;
        goto L3; // [43] 58
    }
    _15405 = NOVALUE;

    /** 			ops = append( ops, { pc, found_op } )*/
    RefDS(_found_op_27343);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _pc_27334;
    ((int *)_2)[2] = _found_op_27343;
    _15407 = MAKE_SEQ(_1);
    RefDS(_15407);
    Append(&_ops_27339, _ops_27339, _15407);
    DeRefDS(_15407);
    _15407 = NOVALUE;
L3: 

    /** 		pc += length( found_op )*/
    if (IS_SEQUENCE(_found_op_27343)){
            _15409 = SEQ_PTR(_found_op_27343)->length;
    }
    else {
        _15409 = 1;
    }
    _pc_27334 = _pc_27334 + _15409;
    _15409 = NOVALUE;
    DeRefDS(_found_op_27343);
    _found_op_27343 = NOVALUE;

    /** 	end while*/
    goto L1; // [71] 19
L2: 

    /** 	return ops*/
    DeRefDS(_code_27336);
    return _ops_27339;
    ;
}


int _65get_target_sym(int _opseq_27355)
{
    int _op_27359 = NOVALUE;
    int _info_27361 = NOVALUE;
    int _targets_27377 = NOVALUE;
    int _sub_27392 = NOVALUE;
    int _15441 = NOVALUE;
    int _15440 = NOVALUE;
    int _15439 = NOVALUE;
    int _15438 = NOVALUE;
    int _15437 = NOVALUE;
    int _15436 = NOVALUE;
    int _15435 = NOVALUE;
    int _15433 = NOVALUE;
    int _15429 = NOVALUE;
    int _15428 = NOVALUE;
    int _15427 = NOVALUE;
    int _15426 = NOVALUE;
    int _15424 = NOVALUE;
    int _15423 = NOVALUE;
    int _15422 = NOVALUE;
    int _15421 = NOVALUE;
    int _15418 = NOVALUE;
    int _15417 = NOVALUE;
    int _15415 = NOVALUE;
    int _15411 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not length( opseq ) then*/
    if (IS_SEQUENCE(_opseq_27355)){
            _15411 = SEQ_PTR(_opseq_27355)->length;
    }
    else {
        _15411 = 1;
    }
    if (_15411 != 0)
    goto L1; // [8] 18
    _15411 = NOVALUE;

    /** 		return 0*/
    DeRefDS(_opseq_27355);
    DeRef(_info_27361);
    return 0;
L1: 

    /** 	integer op = opseq[1]*/
    _2 = (int)SEQ_PTR(_opseq_27355);
    _op_27359 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_op_27359))
    _op_27359 = (long)DBL_PTR(_op_27359)->dbl;

    /** 	sequence info = op_info[op]*/
    DeRef(_info_27361);
    _2 = (int)SEQ_PTR(_65op_info_26607);
    _info_27361 = (int)*(((s1_ptr)_2)->base + _op_27359);
    Ref(_info_27361);

    /** 	if info[OP_SIZE_TYPE] = FIXED_SIZE then*/
    _2 = (int)SEQ_PTR(_info_27361);
    _15415 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _15415, 1)){
        _15415 = NOVALUE;
        goto L2; // [40] 157
    }
    _15415 = NOVALUE;

    /** 		switch length( info[OP_TARGET] ) do*/
    _2 = (int)SEQ_PTR(_info_27361);
    _15417 = (int)*(((s1_ptr)_2)->base + 4);
    if (IS_SEQUENCE(_15417)){
            _15418 = SEQ_PTR(_15417)->length;
    }
    else {
        _15418 = 1;
    }
    _15417 = NOVALUE;
    _0 = _15418;
    _15418 = NOVALUE;
    switch ( _0 ){ 

        /** 			case 0 then*/
        case 0:

        /** 				break*/
        goto L3; // [64] 152
        goto L3; // [66] 152

        /** 			case 1 then*/
        case 1:

        /** 				return opseq[info[OP_TARGET][1]+1]*/
        _2 = (int)SEQ_PTR(_info_27361);
        _15421 = (int)*(((s1_ptr)_2)->base + 4);
        _2 = (int)SEQ_PTR(_15421);
        _15422 = (int)*(((s1_ptr)_2)->base + 1);
        _15421 = NOVALUE;
        if (IS_ATOM_INT(_15422)) {
            _15423 = _15422 + 1;
        }
        else
        _15423 = binary_op(PLUS, 1, _15422);
        _15422 = NOVALUE;
        _2 = (int)SEQ_PTR(_opseq_27355);
        if (!IS_ATOM_INT(_15423)){
            _15424 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_15423)->dbl));
        }
        else{
            _15424 = (int)*(((s1_ptr)_2)->base + _15423);
        }
        Ref(_15424);
        DeRefDS(_opseq_27355);
        DeRefDS(_info_27361);
        _15417 = NOVALUE;
        DeRef(_15423);
        _15423 = NOVALUE;
        return _15424;
        goto L3; // [94] 152

        /** 			case else*/
        default:

        /** 				sequence targets = info[OP_TARGET]*/
        DeRef(_targets_27377);
        _2 = (int)SEQ_PTR(_info_27361);
        _targets_27377 = (int)*(((s1_ptr)_2)->base + 4);
        Ref(_targets_27377);

        /** 				for i = 1 to length( targets ) do*/
        if (IS_SEQUENCE(_targets_27377)){
                _15426 = SEQ_PTR(_targets_27377)->length;
        }
        else {
            _15426 = 1;
        }
        {
            int _i_27380;
            _i_27380 = 1;
L4: 
            if (_i_27380 > _15426){
                goto L5; // [113] 145
            }

            /** 					targets[i] = opseq[targets[i] + 1]*/
            _2 = (int)SEQ_PTR(_targets_27377);
            _15427 = (int)*(((s1_ptr)_2)->base + _i_27380);
            if (IS_ATOM_INT(_15427)) {
                _15428 = _15427 + 1;
            }
            else
            _15428 = binary_op(PLUS, 1, _15427);
            _15427 = NOVALUE;
            _2 = (int)SEQ_PTR(_opseq_27355);
            if (!IS_ATOM_INT(_15428)){
                _15429 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_15428)->dbl));
            }
            else{
                _15429 = (int)*(((s1_ptr)_2)->base + _15428);
            }
            Ref(_15429);
            _2 = (int)SEQ_PTR(_targets_27377);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _targets_27377 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _i_27380);
            _1 = *(int *)_2;
            *(int *)_2 = _15429;
            if( _1 != _15429 ){
                DeRef(_1);
            }
            _15429 = NOVALUE;

            /** 				end for*/
            _i_27380 = _i_27380 + 1;
            goto L4; // [140] 120
L5: 
            ;
        }

        /** 				return targets*/
        DeRefDS(_opseq_27355);
        DeRef(_info_27361);
        _15417 = NOVALUE;
        _15424 = NOVALUE;
        DeRef(_15423);
        _15423 = NOVALUE;
        DeRef(_15428);
        _15428 = NOVALUE;
        return _targets_27377;
    ;}L3: 
    DeRef(_targets_27377);
    _targets_27377 = NOVALUE;
    goto L6; // [154] 253
L2: 

    /** 		switch op do*/
    _0 = _op_27359;
    switch ( _0 ){ 

        /** 			case PROC, PROC_TAIL then*/
        case 27:
        case 203:

        /** 				symtab_index sub = opseq[2]*/
        _2 = (int)SEQ_PTR(_opseq_27355);
        _sub_27392 = (int)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_sub_27392)){
            _sub_27392 = (long)DBL_PTR(_sub_27392)->dbl;
        }

        /** 				if sym_token( sub ) = FUNC then*/
        _15433 = _53sym_token(_sub_27392);
        if (binary_op_a(NOTEQ, _15433, 501)){
            DeRef(_15433);
            _15433 = NOVALUE;
            goto L7; // [186] 204
        }
        DeRef(_15433);
        _15433 = NOVALUE;

        /** 					return opseq[$]*/
        if (IS_SEQUENCE(_opseq_27355)){
                _15435 = SEQ_PTR(_opseq_27355)->length;
        }
        else {
            _15435 = 1;
        }
        _2 = (int)SEQ_PTR(_opseq_27355);
        _15436 = (int)*(((s1_ptr)_2)->base + _15435);
        Ref(_15436);
        DeRefDS(_opseq_27355);
        DeRef(_info_27361);
        _15417 = NOVALUE;
        _15424 = NOVALUE;
        DeRef(_15423);
        _15423 = NOVALUE;
        DeRef(_15428);
        _15428 = NOVALUE;
        return _15436;
L7: 
        goto L8; // [206] 252

        /** 			case FUNC_FORWARD then*/
        case 196:

        /** 				return opseq[$]*/
        if (IS_SEQUENCE(_opseq_27355)){
                _15437 = SEQ_PTR(_opseq_27355)->length;
        }
        else {
            _15437 = 1;
        }
        _2 = (int)SEQ_PTR(_opseq_27355);
        _15438 = (int)*(((s1_ptr)_2)->base + _15437);
        Ref(_15438);
        DeRefDS(_opseq_27355);
        DeRef(_info_27361);
        _15417 = NOVALUE;
        _15424 = NOVALUE;
        DeRef(_15423);
        _15423 = NOVALUE;
        _15436 = NOVALUE;
        DeRef(_15428);
        _15428 = NOVALUE;
        return _15438;
        goto L8; // [225] 252

        /** 			case RIGHT_BRACE_N, CONCAT_N then*/
        case 31:
        case 157:

        /** 				return opseq[opseq[2]+2]*/
        _2 = (int)SEQ_PTR(_opseq_27355);
        _15439 = (int)*(((s1_ptr)_2)->base + 2);
        if (IS_ATOM_INT(_15439)) {
            _15440 = _15439 + 2;
        }
        else {
            _15440 = binary_op(PLUS, _15439, 2);
        }
        _15439 = NOVALUE;
        _2 = (int)SEQ_PTR(_opseq_27355);
        if (!IS_ATOM_INT(_15440)){
            _15441 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_15440)->dbl));
        }
        else{
            _15441 = (int)*(((s1_ptr)_2)->base + _15440);
        }
        Ref(_15441);
        DeRefDS(_opseq_27355);
        DeRef(_info_27361);
        _15417 = NOVALUE;
        _15424 = NOVALUE;
        DeRef(_15423);
        _15423 = NOVALUE;
        _15436 = NOVALUE;
        DeRef(_15428);
        _15428 = NOVALUE;
        _15438 = NOVALUE;
        DeRef(_15440);
        _15440 = NOVALUE;
        return _15441;
    ;}L8: 
L6: 

    /** 	return 0*/
    DeRefDS(_opseq_27355);
    DeRef(_info_27361);
    _15417 = NOVALUE;
    _15424 = NOVALUE;
    DeRef(_15423);
    _15423 = NOVALUE;
    _15436 = NOVALUE;
    DeRef(_15428);
    _15428 = NOVALUE;
    _15438 = NOVALUE;
    _15441 = NOVALUE;
    DeRef(_15440);
    _15440 = NOVALUE;
    return 0;
    ;
}



// 0xA29BA438
