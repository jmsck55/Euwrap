// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

void _54c_putc(int _c_45501)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_c_45501)) {
        _1 = (long)(DBL_PTR(_c_45501)->dbl);
        DeRefDS(_c_45501);
        _c_45501 = _1;
    }

    /** 	if emit_c_output then*/
    if (_54emit_c_output_45488 == 0)
    {
        goto L1; // [7] 23
    }
    else{
    }

    /** 		puts(c_code, c)*/
    EPuts(_54c_code_45491, _c_45501); // DJP 

    /** 		update_checksum( c )*/
    _55update_checksum(_c_45501);
L1: 

    /** end procedure*/
    return;
    ;
}


void _54c_hputs(int _c_source_45506)
{
    int _0, _1, _2;
    

    /** 	if emit_c_output then*/
    if (_54emit_c_output_45488 == 0)
    {
        goto L1; // [7] 18
    }
    else{
    }

    /** 		puts(c_h, c_source)    */
    EPuts(_54c_h_45492, _c_source_45506); // DJP 
L1: 

    /** end procedure*/
    DeRefDS(_c_source_45506);
    return;
    ;
}


void _54c_puts(int _c_source_45510)
{
    int _0, _1, _2;
    

    /** 	if emit_c_output then*/
    if (_54emit_c_output_45488 == 0)
    {
        goto L1; // [7] 23
    }
    else{
    }

    /** 		puts(c_code, c_source)*/
    EPuts(_54c_code_45491, _c_source_45510); // DJP 

    /** 		update_checksum( c_source )*/
    RefDS(_c_source_45510);
    _55update_checksum(_c_source_45510);
L1: 

    /** end procedure*/
    DeRefDS(_c_source_45510);
    return;
    ;
}


void _54c_hprintf(int _format_45515, int _value_45516)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_value_45516)) {
        _1 = (long)(DBL_PTR(_value_45516)->dbl);
        DeRefDS(_value_45516);
        _value_45516 = _1;
    }

    /** 	if emit_c_output then*/
    if (_54emit_c_output_45488 == 0)
    {
        goto L1; // [9] 21
    }
    else{
    }

    /** 		printf(c_h, format, value)*/
    EPrintf(_54c_h_45492, _format_45515, _value_45516);
L1: 

    /** end procedure*/
    DeRefDS(_format_45515);
    return;
    ;
}


void _54c_printf(int _format_45520, int _value_45521)
{
    int _text_45523 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if emit_c_output then*/
    if (_54emit_c_output_45488 == 0)
    {
        goto L1; // [7] 29
    }
    else{
    }

    /** 		sequence text = sprintf( format, value )*/
    DeRefi(_text_45523);
    _text_45523 = EPrintf(-9999999, _format_45520, _value_45521);

    /** 		puts(c_code, text)*/
    EPuts(_54c_code_45491, _text_45523); // DJP 

    /** 		update_checksum( text )*/
    RefDS(_text_45523);
    _55update_checksum(_text_45523);
L1: 
    DeRefi(_text_45523);
    _text_45523 = NOVALUE;

    /** end procedure*/
    DeRefDS(_format_45520);
    DeRef(_value_45521);
    return;
    ;
}


void _54c_printf8(int _value_45534)
{
    int _buff_45535 = NOVALUE;
    int _neg_45536 = NOVALUE;
    int _p_45537 = NOVALUE;
    int _24109 = NOVALUE;
    int _24108 = NOVALUE;
    int _24107 = NOVALUE;
    int _24105 = NOVALUE;
    int _24104 = NOVALUE;
    int _24102 = NOVALUE;
    int _24101 = NOVALUE;
    int _24099 = NOVALUE;
    int _24098 = NOVALUE;
    int _24096 = NOVALUE;
    int _24094 = NOVALUE;
    int _24092 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if emit_c_output then*/
    if (_54emit_c_output_45488 == 0)
    {
        goto L1; // [5] 217
    }
    else{
    }

    /** 		neg = 0*/
    _neg_45536 = 0;

    /** 		buff = sprintf("%.16e", value)*/
    DeRef(_buff_45535);
    _buff_45535 = EPrintf(-9999999, _24090, _value_45534);

    /** 		if length(buff) < 10 then*/
    if (IS_SEQUENCE(_buff_45535)){
            _24092 = SEQ_PTR(_buff_45535)->length;
    }
    else {
        _24092 = 1;
    }
    if (_24092 >= 10)
    goto L2; // [24] 209

    /** 			p = 1*/
    _p_45537 = 1;

    /** 			while p <= length(buff) do*/
L3: 
    if (IS_SEQUENCE(_buff_45535)){
            _24094 = SEQ_PTR(_buff_45535)->length;
    }
    else {
        _24094 = 1;
    }
    if (_p_45537 > _24094)
    goto L4; // [41] 208

    /** 				if buff[p] = '-' then*/
    _2 = (int)SEQ_PTR(_buff_45535);
    _24096 = (int)*(((s1_ptr)_2)->base + _p_45537);
    if (binary_op_a(NOTEQ, _24096, 45)){
        _24096 = NOVALUE;
        goto L5; // [51] 63
    }
    _24096 = NOVALUE;

    /** 					neg = 1*/
    _neg_45536 = 1;
    goto L6; // [60] 197
L5: 

    /** 				elsif buff[p] = 'i' or buff[p] = 'I' then*/
    _2 = (int)SEQ_PTR(_buff_45535);
    _24098 = (int)*(((s1_ptr)_2)->base + _p_45537);
    if (IS_ATOM_INT(_24098)) {
        _24099 = (_24098 == 105);
    }
    else {
        _24099 = binary_op(EQUALS, _24098, 105);
    }
    _24098 = NOVALUE;
    if (IS_ATOM_INT(_24099)) {
        if (_24099 != 0) {
            goto L7; // [73] 90
        }
    }
    else {
        if (DBL_PTR(_24099)->dbl != 0.0) {
            goto L7; // [73] 90
        }
    }
    _2 = (int)SEQ_PTR(_buff_45535);
    _24101 = (int)*(((s1_ptr)_2)->base + _p_45537);
    if (IS_ATOM_INT(_24101)) {
        _24102 = (_24101 == 73);
    }
    else {
        _24102 = binary_op(EQUALS, _24101, 73);
    }
    _24101 = NOVALUE;
    if (_24102 == 0) {
        DeRef(_24102);
        _24102 = NOVALUE;
        goto L8; // [86] 114
    }
    else {
        if (!IS_ATOM_INT(_24102) && DBL_PTR(_24102)->dbl == 0.0){
            DeRef(_24102);
            _24102 = NOVALUE;
            goto L8; // [86] 114
        }
        DeRef(_24102);
        _24102 = NOVALUE;
    }
    DeRef(_24102);
    _24102 = NOVALUE;
L7: 

    /** 					buff = CREATE_INF*/
    RefDS(_54CREATE_INF_45526);
    DeRef(_buff_45535);
    _buff_45535 = _54CREATE_INF_45526;

    /** 					if neg then*/
    if (_neg_45536 == 0)
    {
        goto L4; // [97] 208
    }
    else{
    }

    /** 						buff = prepend(buff, '-')*/
    Prepend(&_buff_45535, _buff_45535, 45);

    /** 					exit*/
    goto L4; // [109] 208
    goto L6; // [111] 197
L8: 

    /** 				elsif buff[p] = 'n' or buff[p] = 'N' then*/
    _2 = (int)SEQ_PTR(_buff_45535);
    _24104 = (int)*(((s1_ptr)_2)->base + _p_45537);
    if (IS_ATOM_INT(_24104)) {
        _24105 = (_24104 == 110);
    }
    else {
        _24105 = binary_op(EQUALS, _24104, 110);
    }
    _24104 = NOVALUE;
    if (IS_ATOM_INT(_24105)) {
        if (_24105 != 0) {
            goto L9; // [124] 141
        }
    }
    else {
        if (DBL_PTR(_24105)->dbl != 0.0) {
            goto L9; // [124] 141
        }
    }
    _2 = (int)SEQ_PTR(_buff_45535);
    _24107 = (int)*(((s1_ptr)_2)->base + _p_45537);
    if (IS_ATOM_INT(_24107)) {
        _24108 = (_24107 == 78);
    }
    else {
        _24108 = binary_op(EQUALS, _24107, 78);
    }
    _24107 = NOVALUE;
    if (_24108 == 0) {
        DeRef(_24108);
        _24108 = NOVALUE;
        goto LA; // [137] 196
    }
    else {
        if (!IS_ATOM_INT(_24108) && DBL_PTR(_24108)->dbl == 0.0){
            DeRef(_24108);
            _24108 = NOVALUE;
            goto LA; // [137] 196
        }
        DeRef(_24108);
        _24108 = NOVALUE;
    }
    DeRef(_24108);
    _24108 = NOVALUE;
L9: 

    /** 					ifdef UNIX then*/

    /** 						if sequence(wat_path) then*/
    _24109 = IS_SEQUENCE(_35wat_path_16321);
    if (_24109 == 0)
    {
        _24109 = NOVALUE;
        goto LB; // [150] 173
    }
    else{
        _24109 = NOVALUE;
    }

    /** 							buff = CREATE_NAN2*/
    RefDS(_54CREATE_NAN2_45530);
    DeRef(_buff_45535);
    _buff_45535 = _54CREATE_NAN2_45530;

    /** 							if not neg then*/
    if (_neg_45536 != 0)
    goto L4; // [160] 208

    /** 								buff = prepend(buff, '-')*/
    Prepend(&_buff_45535, _buff_45535, 45);
    goto L4; // [170] 208
LB: 

    /** 							buff = CREATE_NAN1*/
    RefDS(_54CREATE_NAN1_45528);
    DeRef(_buff_45535);
    _buff_45535 = _54CREATE_NAN1_45528;

    /** 							if neg then*/
    if (_neg_45536 == 0)
    {
        goto L4; // [180] 208
    }
    else{
    }

    /** 								buff = prepend(buff, '-')*/
    Prepend(&_buff_45535, _buff_45535, 45);

    /** 						exit*/
    goto L4; // [193] 208
LA: 
L6: 

    /** 				p += 1*/
    _p_45537 = _p_45537 + 1;

    /** 			end while*/
    goto L3; // [205] 38
L4: 
L2: 

    /** 		puts(c_code, buff)*/
    EPuts(_54c_code_45491, _buff_45535); // DJP 
L1: 

    /** end procedure*/
    DeRef(_value_45534);
    DeRef(_buff_45535);
    DeRef(_24099);
    _24099 = NOVALUE;
    DeRef(_24105);
    _24105 = NOVALUE;
    return;
    ;
}


void _54adjust_indent_before(int _stmt_45580)
{
    int _i_45581 = NOVALUE;
    int _lb_45583 = NOVALUE;
    int _rb_45584 = NOVALUE;
    int _24126 = NOVALUE;
    int _24124 = NOVALUE;
    int _24122 = NOVALUE;
    int _24116 = NOVALUE;
    int _24115 = NOVALUE;
    int _0, _1, _2;
    

    /** 	lb = FALSE*/
    _lb_45583 = _13FALSE_434;

    /** 	rb = FALSE*/
    _rb_45584 = _13FALSE_434;

    /** 	for p = 1 to length(stmt) do*/
    if (IS_SEQUENCE(_stmt_45580)){
            _24115 = SEQ_PTR(_stmt_45580)->length;
    }
    else {
        _24115 = 1;
    }
    {
        int _p_45588;
        _p_45588 = 1;
L1: 
        if (_p_45588 > _24115){
            goto L2; // [22] 102
        }

        /** 		switch stmt[p] do*/
        _2 = (int)SEQ_PTR(_stmt_45580);
        _24116 = (int)*(((s1_ptr)_2)->base + _p_45588);
        if (IS_SEQUENCE(_24116) ){
            goto L3; // [35] 95
        }
        if(!IS_ATOM_INT(_24116)){
            if( (DBL_PTR(_24116)->dbl != (double) ((int) DBL_PTR(_24116)->dbl) ) ){
                goto L3; // [35] 95
            }
            _0 = (int) DBL_PTR(_24116)->dbl;
        }
        else {
            _0 = _24116;
        };
        _24116 = NOVALUE;
        switch ( _0 ){ 

            /** 			case '\n' then*/
            case 10:

            /** 				exit*/
            goto L2; // [46] 102
            goto L3; // [48] 95

            /** 			case  '}' then*/
            case 125:

            /** 				rb = TRUE*/
            _rb_45584 = _13TRUE_436;

            /** 				if lb then*/
            if (_lb_45583 == 0)
            {
                goto L3; // [63] 95
            }
            else{
            }

            /** 					exit*/
            goto L2; // [68] 102
            goto L3; // [71] 95

            /** 			case '{' then*/
            case 123:

            /** 				lb = TRUE*/
            _lb_45583 = _13TRUE_436;

            /** 				if rb then */
            if (_rb_45584 == 0)
            {
                goto L4; // [86] 94
            }
            else{
            }

            /** 					exit*/
            goto L2; // [91] 102
L4: 
        ;}L3: 

        /** 	end for*/
        _p_45588 = _p_45588 + 1;
        goto L1; // [97] 29
L2: 
        ;
    }

    /** 	if rb then*/
    if (_rb_45584 == 0)
    {
        goto L5; // [104] 122
    }
    else{
    }

    /** 		if not lb then*/
    if (_lb_45583 != 0)
    goto L6; // [109] 121

    /** 			indent -= 4*/
    _54indent_45574 = _54indent_45574 - 4;
L6: 
L5: 

    /** 	i = indent + temp_indent*/
    _i_45581 = _54indent_45574 + _54temp_indent_45575;

    /** 	while i >= length(big_blanks) do*/
L7: 
    if (IS_SEQUENCE(_54big_blanks_45576)){
            _24122 = SEQ_PTR(_54big_blanks_45576)->length;
    }
    else {
        _24122 = 1;
    }
    if (_i_45581 < _24122)
    goto L8; // [140] 163

    /** 		c_puts(big_blanks)*/
    RefDS(_54big_blanks_45576);
    _54c_puts(_54big_blanks_45576);

    /** 		i -= length(big_blanks)*/
    if (IS_SEQUENCE(_54big_blanks_45576)){
            _24124 = SEQ_PTR(_54big_blanks_45576)->length;
    }
    else {
        _24124 = 1;
    }
    _i_45581 = _i_45581 - _24124;
    _24124 = NOVALUE;

    /** 	end while*/
    goto L7; // [160] 137
L8: 

    /** 	c_puts(big_blanks[1..i])*/
    rhs_slice_target = (object_ptr)&_24126;
    RHS_Slice(_54big_blanks_45576, 1, _i_45581);
    _54c_puts(_24126);
    _24126 = NOVALUE;

    /** 	temp_indent = 0    */
    _54temp_indent_45575 = 0;

    /** end procedure*/
    DeRefDS(_stmt_45580);
    return;
    ;
}


void _54adjust_indent_after(int _stmt_45613)
{
    int _24147 = NOVALUE;
    int _24146 = NOVALUE;
    int _24144 = NOVALUE;
    int _24142 = NOVALUE;
    int _24141 = NOVALUE;
    int _24138 = NOVALUE;
    int _24136 = NOVALUE;
    int _24135 = NOVALUE;
    int _24132 = NOVALUE;
    int _24128 = NOVALUE;
    int _24127 = NOVALUE;
    int _0, _1, _2;
    

    /** 	for p = 1 to length(stmt) do*/
    if (IS_SEQUENCE(_stmt_45613)){
            _24127 = SEQ_PTR(_stmt_45613)->length;
    }
    else {
        _24127 = 1;
    }
    {
        int _p_45615;
        _p_45615 = 1;
L1: 
        if (_p_45615 > _24127){
            goto L2; // [8] 61
        }

        /** 		switch stmt[p] do*/
        _2 = (int)SEQ_PTR(_stmt_45613);
        _24128 = (int)*(((s1_ptr)_2)->base + _p_45615);
        if (IS_SEQUENCE(_24128) ){
            goto L3; // [21] 54
        }
        if(!IS_ATOM_INT(_24128)){
            if( (DBL_PTR(_24128)->dbl != (double) ((int) DBL_PTR(_24128)->dbl) ) ){
                goto L3; // [21] 54
            }
            _0 = (int) DBL_PTR(_24128)->dbl;
        }
        else {
            _0 = _24128;
        };
        _24128 = NOVALUE;
        switch ( _0 ){ 

            /** 			case '\n' then*/
            case 10:

            /** 				exit*/
            goto L2; // [32] 61
            goto L3; // [34] 54

            /** 			case '{' then*/
            case 123:

            /** 				indent += 4*/
            _54indent_45574 = _54indent_45574 + 4;

            /** 				return*/
            DeRefDS(_stmt_45613);
            return;
        ;}L3: 

        /** 	end for*/
        _p_45615 = _p_45615 + 1;
        goto L1; // [56] 15
L2: 
        ;
    }

    /** 	if length(stmt) < 3 then*/
    if (IS_SEQUENCE(_stmt_45613)){
            _24132 = SEQ_PTR(_stmt_45613)->length;
    }
    else {
        _24132 = 1;
    }
    if (_24132 >= 3)
    goto L4; // [66] 76

    /** 		return*/
    DeRefDS(_stmt_45613);
    return;
L4: 

    /** 	if not equal("if ", stmt[1..3]) then*/
    rhs_slice_target = (object_ptr)&_24135;
    RHS_Slice(_stmt_45613, 1, 3);
    if (_24134 == _24135)
    _24136 = 1;
    else if (IS_ATOM_INT(_24134) && IS_ATOM_INT(_24135))
    _24136 = 0;
    else
    _24136 = (compare(_24134, _24135) == 0);
    DeRefDS(_24135);
    _24135 = NOVALUE;
    if (_24136 != 0)
    goto L5; // [87] 96
    _24136 = NOVALUE;

    /** 		return*/
    DeRefDS(_stmt_45613);
    return;
L5: 

    /** 	if length(stmt) < 5 then*/
    if (IS_SEQUENCE(_stmt_45613)){
            _24138 = SEQ_PTR(_stmt_45613)->length;
    }
    else {
        _24138 = 1;
    }
    if (_24138 >= 5)
    goto L6; // [101] 111

    /** 		return*/
    DeRefDS(_stmt_45613);
    return;
L6: 

    /** 	if not equal("else", stmt[1..4]) then*/
    rhs_slice_target = (object_ptr)&_24141;
    RHS_Slice(_stmt_45613, 1, 4);
    if (_24140 == _24141)
    _24142 = 1;
    else if (IS_ATOM_INT(_24140) && IS_ATOM_INT(_24141))
    _24142 = 0;
    else
    _24142 = (compare(_24140, _24141) == 0);
    DeRefDS(_24141);
    _24141 = NOVALUE;
    if (_24142 != 0)
    goto L7; // [122] 131
    _24142 = NOVALUE;

    /** 		return*/
    DeRefDS(_stmt_45613);
    return;
L7: 

    /** 	if not find(stmt[5], {" \n"}) then*/
    _2 = (int)SEQ_PTR(_stmt_45613);
    _24144 = (int)*(((s1_ptr)_2)->base + 5);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_24145);
    *((int *)(_2+4)) = _24145;
    _24146 = MAKE_SEQ(_1);
    _24147 = find_from(_24144, _24146, 1);
    _24144 = NOVALUE;
    DeRefDS(_24146);
    _24146 = NOVALUE;
    if (_24147 != 0)
    goto L8; // [146] 155
    _24147 = NOVALUE;

    /** 		return*/
    DeRefDS(_stmt_45613);
    return;
L8: 

    /** 	temp_indent = 4*/
    _54temp_indent_45575 = 4;

    /** end procedure*/
    DeRefDS(_stmt_45613);
    return;
    ;
}



// 0xBAE7393D
