// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int _40host_platform()
{
    int _0, _1, _2;
    

    /** 	return ihost_platform*/
    return _40ihost_platform_16404;
    ;
}


void _40set_host_platform(int _plat_16411)
{
    int _9063 = NOVALUE;
    int _0, _1, _2;
    

    /** 	ihost_platform = floor(plat)*/
    _40ihost_platform_16404 = e_floor(_plat_16411);
    if (!IS_ATOM_INT(_40ihost_platform_16404)) {
        _1 = (long)(DBL_PTR(_40ihost_platform_16404)->dbl);
        DeRefDS(_40ihost_platform_16404);
        _40ihost_platform_16404 = _1;
    }

    /** 	TUNIX    = (find(ihost_platform, unices) != 0) */
    _9063 = find_from(_40ihost_platform_16404, _40unices_16407, 1);
    _40TUNIX_16392 = (_9063 != 0);
    _9063 = NOVALUE;

    /** 	TWINDOWS = (ihost_platform = WIN32)*/
    _40TWINDOWS_16388 = (_40ihost_platform_16404 == 2);

    /** 	TBSD     = (ihost_platform = UFREEBSD)*/
    _40TBSD_16394 = (_40ihost_platform_16404 == 8);

    /** 	TOSX     = (ihost_platform = UOSX)*/
    _40TOSX_16396 = (_40ihost_platform_16404 == 4);

    /** 	TLINUX   = (ihost_platform = ULINUX)*/
    _40TLINUX_16390 = (_40ihost_platform_16404 == 3);

    /** 	TOPENBSD = (ihost_platform = UOPENBSD)*/
    _40TOPENBSD_16398 = (_40ihost_platform_16404 == 6);

    /** 	TNETBSD  = (ihost_platform = UNETBSD)*/
    _40TNETBSD_16400 = (_40ihost_platform_16404 == 7);

    /** 	IUNIX    = TUNIX*/
    _40IUNIX_16391 = _40TUNIX_16392;

    /** 	IWINDOWS = TWINDOWS*/
    _40IWINDOWS_16387 = _40TWINDOWS_16388;

    /** 	IBSD     = TBSD*/
    _40IBSD_16393 = _40TBSD_16394;

    /** 	IOSX     = TOSX*/
    _40IOSX_16395 = _40TOSX_16396;

    /** 	ILINUX   = TLINUX*/
    _40ILINUX_16389 = _40TLINUX_16390;

    /** 	IOPENBSD = TOPENBSD*/
    _40IOPENBSD_16397 = _40TOPENBSD_16398;

    /** 	INETBSD  = TNETBSD*/
    _40INETBSD_16399 = _40TNETBSD_16400;

    /** 	if TUNIX then*/
    if (_40TUNIX_16392 == 0)
    {
        goto L1; // [148] 161
    }
    else{
    }

    /** 		HOSTNL = "\n"*/
    RefDS(_3128);
    DeRefi(_40HOSTNL_16403);
    _40HOSTNL_16403 = _3128;
    goto L2; // [158] 169
L1: 

    /** 		HOSTNL = "\r\n"*/
    RefDS(_3134);
    DeRefi(_40HOSTNL_16403);
    _40HOSTNL_16403 = _3134;
L2: 

    /** end procedure*/
    return;
    ;
}


int _40GetPlatformDefines(int _for_translator_16426)
{
    int _local_defines_16427 = NOVALUE;
    int _lcmds_16437 = NOVALUE;
    int _fh_16439 = NOVALUE;
    int _sk_16459 = NOVALUE;
    int _9164 = NOVALUE;
    int _9163 = NOVALUE;
    int _9161 = NOVALUE;
    int _9158 = NOVALUE;
    int _9156 = NOVALUE;
    int _9154 = NOVALUE;
    int _9153 = NOVALUE;
    int _9151 = NOVALUE;
    int _9149 = NOVALUE;
    int _9147 = NOVALUE;
    int _9146 = NOVALUE;
    int _9144 = NOVALUE;
    int _9142 = NOVALUE;
    int _9140 = NOVALUE;
    int _9139 = NOVALUE;
    int _9137 = NOVALUE;
    int _9134 = NOVALUE;
    int _9132 = NOVALUE;
    int _9131 = NOVALUE;
    int _9129 = NOVALUE;
    int _9127 = NOVALUE;
    int _9125 = NOVALUE;
    int _9124 = NOVALUE;
    int _9121 = NOVALUE;
    int _9119 = NOVALUE;
    int _9116 = NOVALUE;
    int _9112 = NOVALUE;
    int _9111 = NOVALUE;
    int _9106 = NOVALUE;
    int _9105 = NOVALUE;
    int _9092 = NOVALUE;
    int _9089 = NOVALUE;
    int _9086 = NOVALUE;
    int _9085 = NOVALUE;
    int _9084 = NOVALUE;
    int _9080 = NOVALUE;
    int _9077 = NOVALUE;
    int _9074 = NOVALUE;
    int _9072 = NOVALUE;
    int _9071 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence local_defines = {}*/
    RefDS(_5);
    DeRef(_local_defines_16427);
    _local_defines_16427 = _5;

    /** 	if (IWINDOWS and not for_translator) or (TWINDOWS and for_translator) then*/
    if (_40IWINDOWS_16387 == 0) {
        _9071 = 0;
        goto L1; // [14] 25
    }
    _9072 = (_for_translator_16426 == 0);
    _9071 = (_9072 != 0);
L1: 
    if (_9071 != 0) {
        goto L2; // [25] 44
    }
    if (_40TWINDOWS_16388 == 0) {
        DeRef(_9074);
        _9074 = 0;
        goto L3; // [31] 39
    }
    _9074 = (_for_translator_16426 != 0);
L3: 
    if (_9074 == 0)
    {
        _9074 = NOVALUE;
        goto L4; // [40] 326
    }
    else{
        _9074 = NOVALUE;
    }
L2: 

    /** 		local_defines &= {"WINDOWS", "WIN32"}*/
    RefDS(_9076);
    RefDS(_9075);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _9075;
    ((int *)_2)[2] = _9076;
    _9077 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_16427, _local_defines_16427, _9077);
    DeRefDS(_9077);
    _9077 = NOVALUE;

    /** 		sequence lcmds = command_line()*/
    DeRef(_lcmds_16437);
    _lcmds_16437 = Command_Line();

    /** 		integer fh*/

    /** 		fh = open(lcmds[1], "rb")*/
    _2 = (int)SEQ_PTR(_lcmds_16437);
    _9080 = (int)*(((s1_ptr)_2)->base + 1);
    _fh_16439 = EOpen(_9080, _3739, 0);
    _9080 = NOVALUE;

    /** 		if fh = -1 then*/
    if (_fh_16439 != -1)
    goto L5; // [73] 123

    /**  			if match("euiw", lower(lcmds[1])) != 0 then*/
    _2 = (int)SEQ_PTR(_lcmds_16437);
    _9084 = (int)*(((s1_ptr)_2)->base + 1);
    RefDS(_9084);
    _9085 = _14lower(_9084);
    _9084 = NOVALUE;
    _9086 = e_match_from(_9083, _9085, 1);
    DeRef(_9085);
    _9085 = NOVALUE;
    if (_9086 == 0)
    goto L6; // [92] 109

    /**  				local_defines &= { "GUI" }*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_9088);
    *((int *)(_2+4)) = _9088;
    _9089 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_16427, _local_defines_16427, _9089);
    DeRefDS(_9089);
    _9089 = NOVALUE;
    goto L7; // [106] 321
L6: 

    /**  				local_defines &= { "CONSOLE" }*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_9091);
    *((int *)(_2+4)) = _9091;
    _9092 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_16427, _local_defines_16427, _9092);
    DeRefDS(_9092);
    _9092 = NOVALUE;
    goto L7; // [120] 321
L5: 

    /** 			atom sk*/

    /** 			sk = seek(fh, #18) -- Fixed location of relocation table.*/
    _0 = _sk_16459;
    _sk_16459 = _8seek(_fh_16439, 24);
    DeRef(_0);

    /** 			sk = get_integer16(fh)*/
    _0 = _sk_16459;
    _sk_16459 = _8get_integer16(_fh_16439);
    DeRef(_0);

    /** 			if sk = #40 then*/
    if (binary_op_a(NOTEQ, _sk_16459, 64)){
        goto L8; // [140] 259
    }

    /** 				sk = seek(fh, #3C) -- Fixed location of COFF signature offset.*/
    _0 = _sk_16459;
    _sk_16459 = _8seek(_fh_16439, 60);
    DeRef(_0);

    /** 				sk = get_integer32(fh)*/
    _0 = _sk_16459;
    _sk_16459 = _8get_integer32(_fh_16439);
    DeRef(_0);

    /** 				sk = seek(fh, sk)*/
    Ref(_sk_16459);
    _0 = _sk_16459;
    _sk_16459 = _8seek(_fh_16439, _sk_16459);
    DeRef(_0);

    /** 				sk = get_integer16(fh)*/
    _0 = _sk_16459;
    _sk_16459 = _8get_integer16(_fh_16439);
    DeRef(_0);

    /** 				if sk = #4550 then -- "PE" in intel endian*/
    if (binary_op_a(NOTEQ, _sk_16459, 17744)){
        goto L9; // [172] 221
    }

    /** 					sk = get_integer16(fh)*/
    _0 = _sk_16459;
    _sk_16459 = _8get_integer16(_fh_16439);
    DeRef(_0);

    /** 					if sk = 0 then*/
    if (binary_op_a(NOTEQ, _sk_16459, 0)){
        goto LA; // [184] 212
    }

    /** 						sk = seek(fh, where(fh) + 88 )*/
    _9105 = _8where(_fh_16439);
    if (IS_ATOM_INT(_9105)) {
        _9106 = _9105 + 88;
        if ((long)((unsigned long)_9106 + (unsigned long)HIGH_BITS) >= 0) 
        _9106 = NewDouble((double)_9106);
    }
    else {
        _9106 = binary_op(PLUS, _9105, 88);
    }
    DeRef(_9105);
    _9105 = NOVALUE;
    _0 = _sk_16459;
    _sk_16459 = _8seek(_fh_16439, _9106);
    DeRef(_0);
    _9106 = NOVALUE;

    /** 						sk = get_integer16(fh)*/
    _0 = _sk_16459;
    _sk_16459 = _8get_integer16(_fh_16439);
    DeRef(_0);
    goto LB; // [209] 265
LA: 

    /** 						sk = 0	-- Don't know this format.*/
    DeRef(_sk_16459);
    _sk_16459 = 0;
    goto LB; // [218] 265
L9: 

    /** 				elsif sk = #454E then -- "NE" in intel endian*/
    if (binary_op_a(NOTEQ, _sk_16459, 17742)){
        goto LC; // [223] 250
    }

    /** 					sk = seek(fh, where(fh) + 54 )*/
    _9111 = _8where(_fh_16439);
    if (IS_ATOM_INT(_9111)) {
        _9112 = _9111 + 54;
        if ((long)((unsigned long)_9112 + (unsigned long)HIGH_BITS) >= 0) 
        _9112 = NewDouble((double)_9112);
    }
    else {
        _9112 = binary_op(PLUS, _9111, 54);
    }
    DeRef(_9111);
    _9111 = NOVALUE;
    _0 = _sk_16459;
    _sk_16459 = _8seek(_fh_16439, _9112);
    DeRef(_0);
    _9112 = NOVALUE;

    /** 					sk = getc(fh)*/
    DeRef(_sk_16459);
    if (_fh_16439 != last_r_file_no) {
        last_r_file_ptr = which_file(_fh_16439, EF_READ);
        last_r_file_no = _fh_16439;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _sk_16459 = getKBchar();
        }
        else
        _sk_16459 = getc(last_r_file_ptr);
    }
    else
    _sk_16459 = getc(last_r_file_ptr);
    goto LB; // [247] 265
LC: 

    /** 					sk = 0*/
    DeRef(_sk_16459);
    _sk_16459 = 0;
    goto LB; // [256] 265
L8: 

    /** 				sk = 0*/
    DeRef(_sk_16459);
    _sk_16459 = 0;
LB: 

    /** 			if sk = 2 then*/
    if (binary_op_a(NOTEQ, _sk_16459, 2)){
        goto LD; // [267] 284
    }

    /** 				local_defines &= { "GUI" }*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_9088);
    *((int *)(_2+4)) = _9088;
    _9116 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_16427, _local_defines_16427, _9116);
    DeRefDS(_9116);
    _9116 = NOVALUE;
    goto LE; // [281] 314
LD: 

    /** 			elsif sk = 3 then*/
    if (binary_op_a(NOTEQ, _sk_16459, 3)){
        goto LF; // [286] 303
    }

    /** 				local_defines &= { "CONSOLE" }*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_9091);
    *((int *)(_2+4)) = _9091;
    _9119 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_16427, _local_defines_16427, _9119);
    DeRefDS(_9119);
    _9119 = NOVALUE;
    goto LE; // [300] 314
LF: 

    /** 				local_defines &= { "UNKNOWN" }*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_7851);
    *((int *)(_2+4)) = _7851;
    _9121 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_16427, _local_defines_16427, _9121);
    DeRefDS(_9121);
    _9121 = NOVALUE;
LE: 

    /** 			close(fh)*/
    EClose(_fh_16439);
    DeRef(_sk_16459);
    _sk_16459 = NOVALUE;
L7: 
    DeRef(_lcmds_16437);
    _lcmds_16437 = NOVALUE;
    goto L10; // [323] 575
L4: 

    /** 		local_defines = append( local_defines, "CONSOLE" )*/
    RefDS(_9091);
    Append(&_local_defines_16427, _local_defines_16427, _9091);

    /** 		if (ILINUX and not for_translator) or (TLINUX and for_translator) then*/
    if (_40ILINUX_16389 == 0) {
        _9124 = 0;
        goto L11; // [336] 347
    }
    _9125 = (_for_translator_16426 == 0);
    _9124 = (_9125 != 0);
L11: 
    if (_9124 != 0) {
        goto L12; // [347] 366
    }
    if (_40TLINUX_16390 == 0) {
        DeRef(_9127);
        _9127 = 0;
        goto L13; // [353] 361
    }
    _9127 = (_for_translator_16426 != 0);
L13: 
    if (_9127 == 0)
    {
        _9127 = NOVALUE;
        goto L14; // [362] 379
    }
    else{
        _9127 = NOVALUE;
    }
L12: 

    /** 			local_defines &= {"UNIX", "LINUX"}*/
    RefDS(_9128);
    RefDS(_8888);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _8888;
    ((int *)_2)[2] = _9128;
    _9129 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_16427, _local_defines_16427, _9129);
    DeRefDS(_9129);
    _9129 = NOVALUE;
    goto L15; // [376] 574
L14: 

    /** 		elsif (IOSX and not for_translator) or (TOSX and for_translator) then*/
    if (_40IOSX_16395 == 0) {
        _9131 = 0;
        goto L16; // [383] 394
    }
    _9132 = (_for_translator_16426 == 0);
    _9131 = (_9132 != 0);
L16: 
    if (_9131 != 0) {
        goto L17; // [394] 413
    }
    if (_40TOSX_16396 == 0) {
        DeRef(_9134);
        _9134 = 0;
        goto L18; // [400] 408
    }
    _9134 = (_for_translator_16426 != 0);
L18: 
    if (_9134 == 0)
    {
        _9134 = NOVALUE;
        goto L19; // [409] 428
    }
    else{
        _9134 = NOVALUE;
    }
L17: 

    /** 			local_defines &= {"UNIX", "BSD", "OSX"}*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_8888);
    *((int *)(_2+4)) = _8888;
    RefDS(_9135);
    *((int *)(_2+8)) = _9135;
    RefDS(_9136);
    *((int *)(_2+12)) = _9136;
    _9137 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_16427, _local_defines_16427, _9137);
    DeRefDS(_9137);
    _9137 = NOVALUE;
    goto L15; // [425] 574
L19: 

    /** 		elsif (IOPENBSD and not for_translator) or (TOPENBSD and for_translator) then*/
    if (_40IOPENBSD_16397 == 0) {
        _9139 = 0;
        goto L1A; // [432] 443
    }
    _9140 = (_for_translator_16426 == 0);
    _9139 = (_9140 != 0);
L1A: 
    if (_9139 != 0) {
        goto L1B; // [443] 462
    }
    if (_40TOPENBSD_16398 == 0) {
        DeRef(_9142);
        _9142 = 0;
        goto L1C; // [449] 457
    }
    _9142 = (_for_translator_16426 != 0);
L1C: 
    if (_9142 == 0)
    {
        _9142 = NOVALUE;
        goto L1D; // [458] 477
    }
    else{
        _9142 = NOVALUE;
    }
L1B: 

    /** 			local_defines &= { "UNIX", "BSD", "OPENBSD"}*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_8888);
    *((int *)(_2+4)) = _8888;
    RefDS(_9135);
    *((int *)(_2+8)) = _9135;
    RefDS(_9143);
    *((int *)(_2+12)) = _9143;
    _9144 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_16427, _local_defines_16427, _9144);
    DeRefDS(_9144);
    _9144 = NOVALUE;
    goto L15; // [474] 574
L1D: 

    /** 		elsif (INETBSD and not for_translator) or (TNETBSD and for_translator) then*/
    if (_40INETBSD_16399 == 0) {
        _9146 = 0;
        goto L1E; // [481] 492
    }
    _9147 = (_for_translator_16426 == 0);
    _9146 = (_9147 != 0);
L1E: 
    if (_9146 != 0) {
        goto L1F; // [492] 511
    }
    if (_40TNETBSD_16400 == 0) {
        DeRef(_9149);
        _9149 = 0;
        goto L20; // [498] 506
    }
    _9149 = (_for_translator_16426 != 0);
L20: 
    if (_9149 == 0)
    {
        _9149 = NOVALUE;
        goto L21; // [507] 526
    }
    else{
        _9149 = NOVALUE;
    }
L1F: 

    /** 			local_defines &= { "UNIX", "BSD", "NETBSD"}*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_8888);
    *((int *)(_2+4)) = _8888;
    RefDS(_9135);
    *((int *)(_2+8)) = _9135;
    RefDS(_9150);
    *((int *)(_2+12)) = _9150;
    _9151 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_16427, _local_defines_16427, _9151);
    DeRefDS(_9151);
    _9151 = NOVALUE;
    goto L15; // [523] 574
L21: 

    /** 		elsif (IBSD and not for_translator) or (TBSD and for_translator) then*/
    if (_40IBSD_16393 == 0) {
        _9153 = 0;
        goto L22; // [530] 541
    }
    _9154 = (_for_translator_16426 == 0);
    _9153 = (_9154 != 0);
L22: 
    if (_9153 != 0) {
        goto L23; // [541] 560
    }
    if (_40TBSD_16394 == 0) {
        DeRef(_9156);
        _9156 = 0;
        goto L24; // [547] 555
    }
    _9156 = (_for_translator_16426 != 0);
L24: 
    if (_9156 == 0)
    {
        _9156 = NOVALUE;
        goto L25; // [556] 573
    }
    else{
        _9156 = NOVALUE;
    }
L23: 

    /** 			local_defines &= {"UNIX", "BSD", "FREEBSD"}*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_8888);
    *((int *)(_2+4)) = _8888;
    RefDS(_9135);
    *((int *)(_2+8)) = _9135;
    RefDS(_9157);
    *((int *)(_2+12)) = _9157;
    _9158 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_16427, _local_defines_16427, _9158);
    DeRefDS(_9158);
    _9158 = NOVALUE;
L25: 
L15: 
L10: 

    /** 	return { "_PLAT_START" } & local_defines & { "_PLAT_STOP" }*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_9160);
    *((int *)(_2+4)) = _9160;
    _9161 = MAKE_SEQ(_1);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_9162);
    *((int *)(_2+4)) = _9162;
    _9163 = MAKE_SEQ(_1);
    {
        int concat_list[3];

        concat_list[0] = _9163;
        concat_list[1] = _local_defines_16427;
        concat_list[2] = _9161;
        Concat_N((object_ptr)&_9164, concat_list, 3);
    }
    DeRefDS(_9163);
    _9163 = NOVALUE;
    DeRefDS(_9161);
    _9161 = NOVALUE;
    DeRefDS(_local_defines_16427);
    DeRef(_9072);
    _9072 = NOVALUE;
    DeRef(_9125);
    _9125 = NOVALUE;
    DeRef(_9132);
    _9132 = NOVALUE;
    DeRef(_9140);
    _9140 = NOVALUE;
    DeRef(_9147);
    _9147 = NOVALUE;
    DeRef(_9154);
    _9154 = NOVALUE;
    return _9164;
    ;
}



// 0xB3AF913C
