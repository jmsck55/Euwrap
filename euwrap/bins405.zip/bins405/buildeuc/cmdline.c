// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

void _4local_abort(int _lvl_14133)
{
    int _has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_17_14138 = NOVALUE;
    int _7863 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if length(pause_msg) != 0 then*/
    _7863 = 0;

    /** 	abort(lvl)*/
    UserCleanup(_lvl_14133);

    /** end procedure*/
    return;
    ;
}


int _4standardize_opts(int _opts_14141, int _auto_help_switches_14142)
{
    int _lExtras_14143 = NOVALUE;
    int _opt_14147 = NOVALUE;
    int _updated_14149 = NOVALUE;
    int _msg_inlined_crash_at_178_14181 = NOVALUE;
    int _msg_inlined_crash_at_354_14212 = NOVALUE;
    int _msg_inlined_crash_at_410_14221 = NOVALUE;
    int _msg_inlined_crash_at_460_14230 = NOVALUE;
    int _msg_inlined_crash_at_510_14239 = NOVALUE;
    int _msg_inlined_crash_at_560_14248 = NOVALUE;
    int _opt_14282 = NOVALUE;
    int _msg_inlined_crash_at_878_14301 = NOVALUE;
    int _data_inlined_crash_at_875_14300 = NOVALUE;
    int _msg_inlined_crash_at_967_14319 = NOVALUE;
    int _data_inlined_crash_at_964_14318 = NOVALUE;
    int _has_h_14320 = NOVALUE;
    int _has_help_14321 = NOVALUE;
    int _has_question_14322 = NOVALUE;
    int _appended_opts_14342 = NOVALUE;
    int _8040 = NOVALUE;
    int _8039 = NOVALUE;
    int _8037 = NOVALUE;
    int _8036 = NOVALUE;
    int _8035 = NOVALUE;
    int _8034 = NOVALUE;
    int _8033 = NOVALUE;
    int _8032 = NOVALUE;
    int _8031 = NOVALUE;
    int _8030 = NOVALUE;
    int _8029 = NOVALUE;
    int _8028 = NOVALUE;
    int _8027 = NOVALUE;
    int _8026 = NOVALUE;
    int _8024 = NOVALUE;
    int _8023 = NOVALUE;
    int _8022 = NOVALUE;
    int _8021 = NOVALUE;
    int _8020 = NOVALUE;
    int _8019 = NOVALUE;
    int _8018 = NOVALUE;
    int _8017 = NOVALUE;
    int _8016 = NOVALUE;
    int _8015 = NOVALUE;
    int _8014 = NOVALUE;
    int _8013 = NOVALUE;
    int _8011 = NOVALUE;
    int _8009 = NOVALUE;
    int _8008 = NOVALUE;
    int _8007 = NOVALUE;
    int _8006 = NOVALUE;
    int _8004 = NOVALUE;
    int _8002 = NOVALUE;
    int _7999 = NOVALUE;
    int _7996 = NOVALUE;
    int _7993 = NOVALUE;
    int _7991 = NOVALUE;
    int _7990 = NOVALUE;
    int _7989 = NOVALUE;
    int _7988 = NOVALUE;
    int _7986 = NOVALUE;
    int _7985 = NOVALUE;
    int _7984 = NOVALUE;
    int _7982 = NOVALUE;
    int _7981 = NOVALUE;
    int _7980 = NOVALUE;
    int _7978 = NOVALUE;
    int _7977 = NOVALUE;
    int _7976 = NOVALUE;
    int _7975 = NOVALUE;
    int _7974 = NOVALUE;
    int _7972 = NOVALUE;
    int _7971 = NOVALUE;
    int _7970 = NOVALUE;
    int _7969 = NOVALUE;
    int _7968 = NOVALUE;
    int _7967 = NOVALUE;
    int _7966 = NOVALUE;
    int _7965 = NOVALUE;
    int _7964 = NOVALUE;
    int _7963 = NOVALUE;
    int _7961 = NOVALUE;
    int _7960 = NOVALUE;
    int _7959 = NOVALUE;
    int _7958 = NOVALUE;
    int _7957 = NOVALUE;
    int _7956 = NOVALUE;
    int _7955 = NOVALUE;
    int _7954 = NOVALUE;
    int _7952 = NOVALUE;
    int _7951 = NOVALUE;
    int _7950 = NOVALUE;
    int _7949 = NOVALUE;
    int _7948 = NOVALUE;
    int _7947 = NOVALUE;
    int _7946 = NOVALUE;
    int _7945 = NOVALUE;
    int _7944 = NOVALUE;
    int _7943 = NOVALUE;
    int _7942 = NOVALUE;
    int _7941 = NOVALUE;
    int _7940 = NOVALUE;
    int _7939 = NOVALUE;
    int _7938 = NOVALUE;
    int _7936 = NOVALUE;
    int _7934 = NOVALUE;
    int _7933 = NOVALUE;
    int _7932 = NOVALUE;
    int _7931 = NOVALUE;
    int _7929 = NOVALUE;
    int _7928 = NOVALUE;
    int _7927 = NOVALUE;
    int _7926 = NOVALUE;
    int _7924 = NOVALUE;
    int _7923 = NOVALUE;
    int _7922 = NOVALUE;
    int _7921 = NOVALUE;
    int _7919 = NOVALUE;
    int _7918 = NOVALUE;
    int _7917 = NOVALUE;
    int _7916 = NOVALUE;
    int _7914 = NOVALUE;
    int _7913 = NOVALUE;
    int _7912 = NOVALUE;
    int _7911 = NOVALUE;
    int _7908 = NOVALUE;
    int _7907 = NOVALUE;
    int _7906 = NOVALUE;
    int _7905 = NOVALUE;
    int _7904 = NOVALUE;
    int _7903 = NOVALUE;
    int _7902 = NOVALUE;
    int _7901 = NOVALUE;
    int _7899 = NOVALUE;
    int _7898 = NOVALUE;
    int _7897 = NOVALUE;
    int _7896 = NOVALUE;
    int _7895 = NOVALUE;
    int _7894 = NOVALUE;
    int _7893 = NOVALUE;
    int _7892 = NOVALUE;
    int _7889 = NOVALUE;
    int _7888 = NOVALUE;
    int _7887 = NOVALUE;
    int _7886 = NOVALUE;
    int _7885 = NOVALUE;
    int _7884 = NOVALUE;
    int _7883 = NOVALUE;
    int _7882 = NOVALUE;
    int _7881 = NOVALUE;
    int _7880 = NOVALUE;
    int _7879 = NOVALUE;
    int _7878 = NOVALUE;
    int _7877 = NOVALUE;
    int _7876 = NOVALUE;
    int _7875 = NOVALUE;
    int _7874 = NOVALUE;
    int _7873 = NOVALUE;
    int _7871 = NOVALUE;
    int _7870 = NOVALUE;
    int _7869 = NOVALUE;
    int _7867 = NOVALUE;
    int _7865 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	integer lExtras = 0 -- Ensure that there is zero or one 'extras' record only.*/
    _lExtras_14143 = 0;

    /** 	for i = 1 to length(opts) do*/
    if (IS_SEQUENCE(_opts_14141)){
            _7865 = SEQ_PTR(_opts_14141)->length;
    }
    else {
        _7865 = 1;
    }
    {
        int _i_14145;
        _i_14145 = 1;
L1: 
        if (_i_14145 > _7865){
            goto L2; // [15] 795
        }

        /** 		sequence opt = opts[i]*/
        DeRef(_opt_14147);
        _2 = (int)SEQ_PTR(_opts_14141);
        _opt_14147 = (int)*(((s1_ptr)_2)->base + _i_14145);
        Ref(_opt_14147);

        /** 		integer updated = 0*/
        _updated_14149 = 0;

        /** 		if length(opt) < MAPNAME then*/
        if (IS_SEQUENCE(_opt_14147)){
                _7867 = SEQ_PTR(_opt_14147)->length;
        }
        else {
            _7867 = 1;
        }
        if (_7867 >= 6)
        goto L3; // [40] 67

        /** 			opt &= repeat(-1, MAPNAME - length(opt))*/
        if (IS_SEQUENCE(_opt_14147)){
                _7869 = SEQ_PTR(_opt_14147)->length;
        }
        else {
            _7869 = 1;
        }
        _7870 = 6 - _7869;
        _7869 = NOVALUE;
        _7871 = Repeat(-1, _7870);
        _7870 = NOVALUE;
        Concat((object_ptr)&_opt_14147, _opt_14147, _7871);
        DeRefDS(_7871);
        _7871 = NOVALUE;

        /** 			updated = 1*/
        _updated_14149 = 1;
L3: 

        /** 		if sequence(opt[SHORTNAME]) and length(opt[SHORTNAME]) = 0 then*/
        _2 = (int)SEQ_PTR(_opt_14147);
        _7873 = (int)*(((s1_ptr)_2)->base + 1);
        _7874 = IS_SEQUENCE(_7873);
        _7873 = NOVALUE;
        if (_7874 == 0) {
            goto L4; // [76] 107
        }
        _2 = (int)SEQ_PTR(_opt_14147);
        _7876 = (int)*(((s1_ptr)_2)->base + 1);
        if (IS_SEQUENCE(_7876)){
                _7877 = SEQ_PTR(_7876)->length;
        }
        else {
            _7877 = 1;
        }
        _7876 = NOVALUE;
        _7878 = (_7877 == 0);
        _7877 = NOVALUE;
        if (_7878 == 0)
        {
            DeRef(_7878);
            _7878 = NOVALUE;
            goto L4; // [92] 107
        }
        else{
            DeRef(_7878);
            _7878 = NOVALUE;
        }

        /** 			opt[SHORTNAME] = 0*/
        _2 = (int)SEQ_PTR(_opt_14147);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opt_14147 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 1);
        _1 = *(int *)_2;
        *(int *)_2 = 0;
        DeRef(_1);

        /** 			updated = 1*/
        _updated_14149 = 1;
L4: 

        /** 		if sequence(opt[LONGNAME]) and length(opt[LONGNAME]) = 0 then*/
        _2 = (int)SEQ_PTR(_opt_14147);
        _7879 = (int)*(((s1_ptr)_2)->base + 2);
        _7880 = IS_SEQUENCE(_7879);
        _7879 = NOVALUE;
        if (_7880 == 0) {
            goto L5; // [116] 147
        }
        _2 = (int)SEQ_PTR(_opt_14147);
        _7882 = (int)*(((s1_ptr)_2)->base + 2);
        if (IS_SEQUENCE(_7882)){
                _7883 = SEQ_PTR(_7882)->length;
        }
        else {
            _7883 = 1;
        }
        _7882 = NOVALUE;
        _7884 = (_7883 == 0);
        _7883 = NOVALUE;
        if (_7884 == 0)
        {
            DeRef(_7884);
            _7884 = NOVALUE;
            goto L5; // [132] 147
        }
        else{
            DeRef(_7884);
            _7884 = NOVALUE;
        }

        /** 			opt[LONGNAME] = 0*/
        _2 = (int)SEQ_PTR(_opt_14147);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opt_14147 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 2);
        _1 = *(int *)_2;
        *(int *)_2 = 0;
        DeRef(_1);

        /** 			updated = 1*/
        _updated_14149 = 1;
L5: 

        /** 		if atom(opt[LONGNAME]) and atom(opt[SHORTNAME]) then*/
        _2 = (int)SEQ_PTR(_opt_14147);
        _7885 = (int)*(((s1_ptr)_2)->base + 2);
        _7886 = IS_ATOM(_7885);
        _7885 = NOVALUE;
        if (_7886 == 0) {
            goto L6; // [156] 233
        }
        _2 = (int)SEQ_PTR(_opt_14147);
        _7888 = (int)*(((s1_ptr)_2)->base + 1);
        _7889 = IS_ATOM(_7888);
        _7888 = NOVALUE;
        if (_7889 == 0)
        {
            _7889 = NOVALUE;
            goto L6; // [168] 233
        }
        else{
            _7889 = NOVALUE;
        }

        /** 			if lExtras != 0 then*/
        if (_lExtras_14143 == 0)
        goto L7; // [173] 200

        /** 				error:crash("cmd_opts: There must be less than two 'extras' option records.\n")*/

        /** 	msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_178_14181);
        _msg_inlined_crash_at_178_14181 = EPrintf(-9999999, _7891, _5);

        /** 	machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_178_14181);

        /** end procedure*/
        goto L8; // [192] 195
L8: 
        DeRefi(_msg_inlined_crash_at_178_14181);
        _msg_inlined_crash_at_178_14181 = NOVALUE;
        goto L9; // [197] 232
L7: 

        /** 				lExtras = i*/
        _lExtras_14143 = _i_14145;

        /** 				if atom(opt[MAPNAME]) then*/
        _2 = (int)SEQ_PTR(_opt_14147);
        _7892 = (int)*(((s1_ptr)_2)->base + 6);
        _7893 = IS_ATOM(_7892);
        _7892 = NOVALUE;
        if (_7893 == 0)
        {
            _7893 = NOVALUE;
            goto LA; // [214] 231
        }
        else{
            _7893 = NOVALUE;
        }

        /** 					opt[MAPNAME] = EXTRAS*/
        RefDS(_4EXTRAS_14119);
        _2 = (int)SEQ_PTR(_opt_14147);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opt_14147 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 6);
        _1 = *(int *)_2;
        *(int *)_2 = _4EXTRAS_14119;
        DeRef(_1);

        /** 					updated = 1*/
        _updated_14149 = 1;
LA: 
L9: 
L6: 

        /** 		if atom(opt[DESCRIPTION]) then*/
        _2 = (int)SEQ_PTR(_opt_14147);
        _7894 = (int)*(((s1_ptr)_2)->base + 3);
        _7895 = IS_ATOM(_7894);
        _7894 = NOVALUE;
        if (_7895 == 0)
        {
            _7895 = NOVALUE;
            goto LB; // [242] 257
        }
        else{
            _7895 = NOVALUE;
        }

        /** 			opt[DESCRIPTION] = ""*/
        RefDS(_5);
        _2 = (int)SEQ_PTR(_opt_14147);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opt_14147 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 3);
        _1 = *(int *)_2;
        *(int *)_2 = _5;
        DeRef(_1);

        /** 			updated = 1*/
        _updated_14149 = 1;
LB: 

        /** 		if atom(opt[OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opt_14147);
        _7896 = (int)*(((s1_ptr)_2)->base + 4);
        _7897 = IS_ATOM(_7896);
        _7896 = NOVALUE;
        if (_7897 == 0)
        {
            _7897 = NOVALUE;
            goto LC; // [266] 310
        }
        else{
            _7897 = NOVALUE;
        }

        /** 			if equal(opt[OPTIONS], HAS_PARAMETER) then*/
        _2 = (int)SEQ_PTR(_opt_14147);
        _7898 = (int)*(((s1_ptr)_2)->base + 4);
        if (_7898 == 112)
        _7899 = 1;
        else if (IS_ATOM_INT(_7898) && IS_ATOM_INT(112))
        _7899 = 0;
        else
        _7899 = (compare(_7898, 112) == 0);
        _7898 = NOVALUE;
        if (_7899 == 0)
        {
            _7899 = NOVALUE;
            goto LD; // [279] 295
        }
        else{
            _7899 = NOVALUE;
        }

        /** 				opt[OPTIONS] = {HAS_PARAMETER,"x"}*/
        RefDS(_7900);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = 112;
        ((int *)_2)[2] = _7900;
        _7901 = MAKE_SEQ(_1);
        _2 = (int)SEQ_PTR(_opt_14147);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opt_14147 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 4);
        _1 = *(int *)_2;
        *(int *)_2 = _7901;
        if( _1 != _7901 ){
            DeRef(_1);
        }
        _7901 = NOVALUE;
        goto LE; // [292] 302
LD: 

        /** 				opt[OPTIONS] = {}*/
        RefDS(_5);
        _2 = (int)SEQ_PTR(_opt_14147);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opt_14147 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 4);
        _1 = *(int *)_2;
        *(int *)_2 = _5;
        DeRef(_1);
LE: 

        /** 			updated = 1*/
        _updated_14149 = 1;
        goto LF; // [307] 582
LC: 

        /** 			for j = 1 to length(opt[OPTIONS]) do*/
        _2 = (int)SEQ_PTR(_opt_14147);
        _7902 = (int)*(((s1_ptr)_2)->base + 4);
        if (IS_SEQUENCE(_7902)){
                _7903 = SEQ_PTR(_7902)->length;
        }
        else {
            _7903 = 1;
        }
        _7902 = NOVALUE;
        {
            int _j_14200;
            _j_14200 = 1;
L10: 
            if (_j_14200 > _7903){
                goto L11; // [319] 381
            }

            /** 				if find(opt[OPTIONS][j], opt[OPTIONS], j + 1) != 0 then*/
            _2 = (int)SEQ_PTR(_opt_14147);
            _7904 = (int)*(((s1_ptr)_2)->base + 4);
            _2 = (int)SEQ_PTR(_7904);
            _7905 = (int)*(((s1_ptr)_2)->base + _j_14200);
            _7904 = NOVALUE;
            _2 = (int)SEQ_PTR(_opt_14147);
            _7906 = (int)*(((s1_ptr)_2)->base + 4);
            _7907 = _j_14200 + 1;
            _7908 = find_from(_7905, _7906, _7907);
            _7905 = NOVALUE;
            _7906 = NOVALUE;
            _7907 = NOVALUE;
            if (_7908 == 0)
            goto L12; // [349] 374

            /** 					error:crash("cmd_opts: Duplicate processing options are not allowed in an option record.\n")*/

            /** 	msg = sprintf(fmt, data)*/
            DeRefi(_msg_inlined_crash_at_354_14212);
            _msg_inlined_crash_at_354_14212 = EPrintf(-9999999, _7910, _5);

            /** 	machine_proc(M_CRASH, msg)*/
            machine(67, _msg_inlined_crash_at_354_14212);

            /** end procedure*/
            goto L13; // [368] 371
L13: 
            DeRefi(_msg_inlined_crash_at_354_14212);
            _msg_inlined_crash_at_354_14212 = NOVALUE;
L12: 

            /** 			end for*/
            _j_14200 = _j_14200 + 1;
            goto L10; // [376] 326
L11: 
            ;
        }

        /** 			if find(HAS_PARAMETER, opt[OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opt_14147);
        _7911 = (int)*(((s1_ptr)_2)->base + 4);
        _7912 = find_from(112, _7911, 1);
        _7911 = NOVALUE;
        if (_7912 == 0)
        {
            _7912 = NOVALUE;
            goto L14; // [392] 431
        }
        else{
            _7912 = NOVALUE;
        }

        /** 				if find(NO_PARAMETER, opt[OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opt_14147);
        _7913 = (int)*(((s1_ptr)_2)->base + 4);
        _7914 = find_from(110, _7913, 1);
        _7913 = NOVALUE;
        if (_7914 == 0)
        {
            _7914 = NOVALUE;
            goto L15; // [406] 430
        }
        else{
            _7914 = NOVALUE;
        }

        /** 					error:crash("cmd_opts: Cannot have both HAS_PARAMETER and NO_PARAMETER in an option record.\n")*/

        /** 	msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_410_14221);
        _msg_inlined_crash_at_410_14221 = EPrintf(-9999999, _7915, _5);

        /** 	machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_410_14221);

        /** end procedure*/
        goto L16; // [424] 427
L16: 
        DeRefi(_msg_inlined_crash_at_410_14221);
        _msg_inlined_crash_at_410_14221 = NOVALUE;
L15: 
L14: 

        /** 			if find(HAS_CASE, opt[OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opt_14147);
        _7916 = (int)*(((s1_ptr)_2)->base + 4);
        _7917 = find_from(99, _7916, 1);
        _7916 = NOVALUE;
        if (_7917 == 0)
        {
            _7917 = NOVALUE;
            goto L17; // [442] 481
        }
        else{
            _7917 = NOVALUE;
        }

        /** 				if find(NO_CASE, opt[OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opt_14147);
        _7918 = (int)*(((s1_ptr)_2)->base + 4);
        _7919 = find_from(105, _7918, 1);
        _7918 = NOVALUE;
        if (_7919 == 0)
        {
            _7919 = NOVALUE;
            goto L18; // [456] 480
        }
        else{
            _7919 = NOVALUE;
        }

        /** 					error:crash("cmd_opts: Cannot have both HAS_CASE and NO_CASE in an option record.\n")*/

        /** 	msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_460_14230);
        _msg_inlined_crash_at_460_14230 = EPrintf(-9999999, _7920, _5);

        /** 	machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_460_14230);

        /** end procedure*/
        goto L19; // [474] 477
L19: 
        DeRefi(_msg_inlined_crash_at_460_14230);
        _msg_inlined_crash_at_460_14230 = NOVALUE;
L18: 
L17: 

        /** 			if find(MANDATORY, opt[OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opt_14147);
        _7921 = (int)*(((s1_ptr)_2)->base + 4);
        _7922 = find_from(109, _7921, 1);
        _7921 = NOVALUE;
        if (_7922 == 0)
        {
            _7922 = NOVALUE;
            goto L1A; // [492] 531
        }
        else{
            _7922 = NOVALUE;
        }

        /** 				if find(OPTIONAL, opt[OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opt_14147);
        _7923 = (int)*(((s1_ptr)_2)->base + 4);
        _7924 = find_from(111, _7923, 1);
        _7923 = NOVALUE;
        if (_7924 == 0)
        {
            _7924 = NOVALUE;
            goto L1B; // [506] 530
        }
        else{
            _7924 = NOVALUE;
        }

        /** 					error:crash("cmd_opts: Cannot have both MANDATORY and OPTIONAL in an option record.\n")*/

        /** 	msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_510_14239);
        _msg_inlined_crash_at_510_14239 = EPrintf(-9999999, _7925, _5);

        /** 	machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_510_14239);

        /** end procedure*/
        goto L1C; // [524] 527
L1C: 
        DeRefi(_msg_inlined_crash_at_510_14239);
        _msg_inlined_crash_at_510_14239 = NOVALUE;
L1B: 
L1A: 

        /** 			if find(ONCE, opt[OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opt_14147);
        _7926 = (int)*(((s1_ptr)_2)->base + 4);
        _7927 = find_from(49, _7926, 1);
        _7926 = NOVALUE;
        if (_7927 == 0)
        {
            _7927 = NOVALUE;
            goto L1D; // [542] 581
        }
        else{
            _7927 = NOVALUE;
        }

        /** 				if find(MULTIPLE, opt[OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opt_14147);
        _7928 = (int)*(((s1_ptr)_2)->base + 4);
        _7929 = find_from(42, _7928, 1);
        _7928 = NOVALUE;
        if (_7929 == 0)
        {
            _7929 = NOVALUE;
            goto L1E; // [556] 580
        }
        else{
            _7929 = NOVALUE;
        }

        /** 					error:crash("cmd_opts: Cannot have both ONCE and MULTIPLE in an option record.\n")*/

        /** 	msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_560_14248);
        _msg_inlined_crash_at_560_14248 = EPrintf(-9999999, _7930, _5);

        /** 	machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_560_14248);

        /** end procedure*/
        goto L1F; // [574] 577
L1F: 
        DeRefi(_msg_inlined_crash_at_560_14248);
        _msg_inlined_crash_at_560_14248 = NOVALUE;
L1E: 
L1D: 
LF: 

        /** 		if sequence(opt[CALLBACK]) then*/
        _2 = (int)SEQ_PTR(_opt_14147);
        _7931 = (int)*(((s1_ptr)_2)->base + 5);
        _7932 = IS_SEQUENCE(_7931);
        _7931 = NOVALUE;
        if (_7932 == 0)
        {
            _7932 = NOVALUE;
            goto L20; // [591] 608
        }
        else{
            _7932 = NOVALUE;
        }

        /** 			opt[CALLBACK] = -1*/
        _2 = (int)SEQ_PTR(_opt_14147);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opt_14147 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 5);
        _1 = *(int *)_2;
        *(int *)_2 = -1;
        DeRef(_1);

        /** 			updated = 1*/
        _updated_14149 = 1;
        goto L21; // [605] 657
L20: 

        /** 		elsif not integer(opt[CALLBACK]) then*/
        _2 = (int)SEQ_PTR(_opt_14147);
        _7933 = (int)*(((s1_ptr)_2)->base + 5);
        if (IS_ATOM_INT(_7933))
        _7934 = 1;
        else if (IS_ATOM_DBL(_7933))
        _7934 = IS_ATOM_INT(DoubleToInt(_7933));
        else
        _7934 = 0;
        _7933 = NOVALUE;
        if (_7934 != 0)
        goto L22; // [617] 634
        _7934 = NOVALUE;

        /** 			opt[CALLBACK] = -1*/
        _2 = (int)SEQ_PTR(_opt_14147);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opt_14147 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 5);
        _1 = *(int *)_2;
        *(int *)_2 = -1;
        DeRef(_1);

        /** 			updated = 1*/
        _updated_14149 = 1;
        goto L21; // [631] 657
L22: 

        /** 		elsif opt[CALLBACK] < 0 then*/
        _2 = (int)SEQ_PTR(_opt_14147);
        _7936 = (int)*(((s1_ptr)_2)->base + 5);
        if (binary_op_a(GREATEREQ, _7936, 0)){
            _7936 = NOVALUE;
            goto L23; // [640] 656
        }
        _7936 = NOVALUE;

        /** 			opt[CALLBACK] = -1*/
        _2 = (int)SEQ_PTR(_opt_14147);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opt_14147 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 5);
        _1 = *(int *)_2;
        *(int *)_2 = -1;
        DeRef(_1);

        /** 			updated = 1*/
        _updated_14149 = 1;
L23: 
L21: 

        /** 		if sequence(opt[MAPNAME]) and length(opt[MAPNAME]) = 0 then*/
        _2 = (int)SEQ_PTR(_opt_14147);
        _7938 = (int)*(((s1_ptr)_2)->base + 6);
        _7939 = IS_SEQUENCE(_7938);
        _7938 = NOVALUE;
        if (_7939 == 0) {
            goto L24; // [666] 697
        }
        _2 = (int)SEQ_PTR(_opt_14147);
        _7941 = (int)*(((s1_ptr)_2)->base + 6);
        if (IS_SEQUENCE(_7941)){
                _7942 = SEQ_PTR(_7941)->length;
        }
        else {
            _7942 = 1;
        }
        _7941 = NOVALUE;
        _7943 = (_7942 == 0);
        _7942 = NOVALUE;
        if (_7943 == 0)
        {
            DeRef(_7943);
            _7943 = NOVALUE;
            goto L24; // [682] 697
        }
        else{
            DeRef(_7943);
            _7943 = NOVALUE;
        }

        /** 			opt[MAPNAME] = 0*/
        _2 = (int)SEQ_PTR(_opt_14147);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opt_14147 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 6);
        _1 = *(int *)_2;
        *(int *)_2 = 0;
        DeRef(_1);

        /** 			updated = 1*/
        _updated_14149 = 1;
L24: 

        /** 		if atom(opt[MAPNAME]) then*/
        _2 = (int)SEQ_PTR(_opt_14147);
        _7944 = (int)*(((s1_ptr)_2)->base + 6);
        _7945 = IS_ATOM(_7944);
        _7944 = NOVALUE;
        if (_7945 == 0)
        {
            _7945 = NOVALUE;
            goto L25; // [706] 774
        }
        else{
            _7945 = NOVALUE;
        }

        /** 			if sequence(opt[LONGNAME]) then*/
        _2 = (int)SEQ_PTR(_opt_14147);
        _7946 = (int)*(((s1_ptr)_2)->base + 2);
        _7947 = IS_SEQUENCE(_7946);
        _7946 = NOVALUE;
        if (_7947 == 0)
        {
            _7947 = NOVALUE;
            goto L26; // [718] 734
        }
        else{
            _7947 = NOVALUE;
        }

        /** 				opt[MAPNAME] = opt[LONGNAME]*/
        _2 = (int)SEQ_PTR(_opt_14147);
        _7948 = (int)*(((s1_ptr)_2)->base + 2);
        Ref(_7948);
        _2 = (int)SEQ_PTR(_opt_14147);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opt_14147 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 6);
        _1 = *(int *)_2;
        *(int *)_2 = _7948;
        if( _1 != _7948 ){
            DeRef(_1);
        }
        _7948 = NOVALUE;
        goto L27; // [731] 768
L26: 

        /** 			elsif sequence(opt[SHORTNAME]) then*/
        _2 = (int)SEQ_PTR(_opt_14147);
        _7949 = (int)*(((s1_ptr)_2)->base + 1);
        _7950 = IS_SEQUENCE(_7949);
        _7949 = NOVALUE;
        if (_7950 == 0)
        {
            _7950 = NOVALUE;
            goto L28; // [743] 759
        }
        else{
            _7950 = NOVALUE;
        }

        /** 				opt[MAPNAME] = opt[SHORTNAME]*/
        _2 = (int)SEQ_PTR(_opt_14147);
        _7951 = (int)*(((s1_ptr)_2)->base + 1);
        Ref(_7951);
        _2 = (int)SEQ_PTR(_opt_14147);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opt_14147 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 6);
        _1 = *(int *)_2;
        *(int *)_2 = _7951;
        if( _1 != _7951 ){
            DeRef(_1);
        }
        _7951 = NOVALUE;
        goto L27; // [756] 768
L28: 

        /** 				opt[MAPNAME] = EXTRAS*/
        RefDS(_4EXTRAS_14119);
        _2 = (int)SEQ_PTR(_opt_14147);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opt_14147 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 6);
        _1 = *(int *)_2;
        *(int *)_2 = _4EXTRAS_14119;
        DeRef(_1);
L27: 

        /** 			updated = 1*/
        _updated_14149 = 1;
L25: 

        /** 		if updated then*/
        if (_updated_14149 == 0)
        {
            goto L29; // [776] 786
        }
        else{
        }

        /** 			opts[i] = opt*/
        RefDS(_opt_14147);
        _2 = (int)SEQ_PTR(_opts_14141);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opts_14141 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_14145);
        _1 = *(int *)_2;
        *(int *)_2 = _opt_14147;
        DeRef(_1);
L29: 
        DeRef(_opt_14147);
        _opt_14147 = NOVALUE;

        /** 	end for*/
        _i_14145 = _i_14145 + 1;
        goto L1; // [790] 22
L2: 
        ;
    }

    /** 	for i = 1 to length(opts) do*/
    if (IS_SEQUENCE(_opts_14141)){
            _7952 = SEQ_PTR(_opts_14141)->length;
    }
    else {
        _7952 = 1;
    }
    {
        int _i_14280;
        _i_14280 = 1;
L2A: 
        if (_i_14280 > _7952){
            goto L2B; // [800] 1004
        }

        /** 		sequence opt*/

        /** 		opt = opts[i]*/
        DeRef(_opt_14282);
        _2 = (int)SEQ_PTR(_opts_14141);
        _opt_14282 = (int)*(((s1_ptr)_2)->base + _i_14280);
        Ref(_opt_14282);

        /** 		if sequence(opt[SHORTNAME]) then*/
        _2 = (int)SEQ_PTR(_opt_14282);
        _7954 = (int)*(((s1_ptr)_2)->base + 1);
        _7955 = IS_SEQUENCE(_7954);
        _7954 = NOVALUE;
        if (_7955 == 0)
        {
            _7955 = NOVALUE;
            goto L2C; // [826] 906
        }
        else{
            _7955 = NOVALUE;
        }

        /** 			for j = i + 1 to length(opts) do*/
        _7956 = _i_14280 + 1;
        if (IS_SEQUENCE(_opts_14141)){
                _7957 = SEQ_PTR(_opts_14141)->length;
        }
        else {
            _7957 = 1;
        }
        {
            int _j_14288;
            _j_14288 = _7956;
L2D: 
            if (_j_14288 > _7957){
                goto L2E; // [838] 905
            }

            /** 				if equal(opt[SHORTNAME], opts[j][SHORTNAME]) then*/
            _2 = (int)SEQ_PTR(_opt_14282);
            _7958 = (int)*(((s1_ptr)_2)->base + 1);
            _2 = (int)SEQ_PTR(_opts_14141);
            _7959 = (int)*(((s1_ptr)_2)->base + _j_14288);
            _2 = (int)SEQ_PTR(_7959);
            _7960 = (int)*(((s1_ptr)_2)->base + 1);
            _7959 = NOVALUE;
            if (_7958 == _7960)
            _7961 = 1;
            else if (IS_ATOM_INT(_7958) && IS_ATOM_INT(_7960))
            _7961 = 0;
            else
            _7961 = (compare(_7958, _7960) == 0);
            _7958 = NOVALUE;
            _7960 = NOVALUE;
            if (_7961 == 0)
            {
                _7961 = NOVALUE;
                goto L2F; // [863] 898
            }
            else{
                _7961 = NOVALUE;
            }

            /** 					error:crash("cmd_opts: Duplicate Short Names (%s) are not allowed in an option record.\n",*/
            _2 = (int)SEQ_PTR(_opt_14282);
            _7963 = (int)*(((s1_ptr)_2)->base + 1);
            _1 = NewS1(1);
            _2 = (int)((s1_ptr)_1)->base;
            Ref(_7963);
            *((int *)(_2+4)) = _7963;
            _7964 = MAKE_SEQ(_1);
            _7963 = NOVALUE;
            DeRef(_data_inlined_crash_at_875_14300);
            _data_inlined_crash_at_875_14300 = _7964;
            _7964 = NOVALUE;

            /** 	msg = sprintf(fmt, data)*/
            DeRefi(_msg_inlined_crash_at_878_14301);
            _msg_inlined_crash_at_878_14301 = EPrintf(-9999999, _7962, _data_inlined_crash_at_875_14300);

            /** 	machine_proc(M_CRASH, msg)*/
            machine(67, _msg_inlined_crash_at_878_14301);

            /** end procedure*/
            goto L30; // [892] 895
L30: 
            DeRef(_data_inlined_crash_at_875_14300);
            _data_inlined_crash_at_875_14300 = NOVALUE;
            DeRefi(_msg_inlined_crash_at_878_14301);
            _msg_inlined_crash_at_878_14301 = NOVALUE;
L2F: 

            /** 			end for*/
            _j_14288 = _j_14288 + 1;
            goto L2D; // [900] 845
L2E: 
            ;
        }
L2C: 

        /** 		if sequence(opt[LONGNAME]) then*/
        _2 = (int)SEQ_PTR(_opt_14282);
        _7965 = (int)*(((s1_ptr)_2)->base + 2);
        _7966 = IS_SEQUENCE(_7965);
        _7965 = NOVALUE;
        if (_7966 == 0)
        {
            _7966 = NOVALUE;
            goto L31; // [915] 995
        }
        else{
            _7966 = NOVALUE;
        }

        /** 			for j = i + 1 to length(opts) do*/
        _7967 = _i_14280 + 1;
        if (IS_SEQUENCE(_opts_14141)){
                _7968 = SEQ_PTR(_opts_14141)->length;
        }
        else {
            _7968 = 1;
        }
        {
            int _j_14306;
            _j_14306 = _7967;
L32: 
            if (_j_14306 > _7968){
                goto L33; // [927] 994
            }

            /** 				if equal(opt[LONGNAME], opts[j][LONGNAME]) then*/
            _2 = (int)SEQ_PTR(_opt_14282);
            _7969 = (int)*(((s1_ptr)_2)->base + 2);
            _2 = (int)SEQ_PTR(_opts_14141);
            _7970 = (int)*(((s1_ptr)_2)->base + _j_14306);
            _2 = (int)SEQ_PTR(_7970);
            _7971 = (int)*(((s1_ptr)_2)->base + 2);
            _7970 = NOVALUE;
            if (_7969 == _7971)
            _7972 = 1;
            else if (IS_ATOM_INT(_7969) && IS_ATOM_INT(_7971))
            _7972 = 0;
            else
            _7972 = (compare(_7969, _7971) == 0);
            _7969 = NOVALUE;
            _7971 = NOVALUE;
            if (_7972 == 0)
            {
                _7972 = NOVALUE;
                goto L34; // [952] 987
            }
            else{
                _7972 = NOVALUE;
            }

            /** 					error:crash("cmd_opts: Duplicate Long Names (%s) are not allowed in an option record.\n",*/
            _2 = (int)SEQ_PTR(_opt_14282);
            _7974 = (int)*(((s1_ptr)_2)->base + 2);
            _1 = NewS1(1);
            _2 = (int)((s1_ptr)_1)->base;
            Ref(_7974);
            *((int *)(_2+4)) = _7974;
            _7975 = MAKE_SEQ(_1);
            _7974 = NOVALUE;
            DeRef(_data_inlined_crash_at_964_14318);
            _data_inlined_crash_at_964_14318 = _7975;
            _7975 = NOVALUE;

            /** 	msg = sprintf(fmt, data)*/
            DeRefi(_msg_inlined_crash_at_967_14319);
            _msg_inlined_crash_at_967_14319 = EPrintf(-9999999, _7973, _data_inlined_crash_at_964_14318);

            /** 	machine_proc(M_CRASH, msg)*/
            machine(67, _msg_inlined_crash_at_967_14319);

            /** end procedure*/
            goto L35; // [981] 984
L35: 
            DeRef(_data_inlined_crash_at_964_14318);
            _data_inlined_crash_at_964_14318 = NOVALUE;
            DeRefi(_msg_inlined_crash_at_967_14319);
            _msg_inlined_crash_at_967_14319 = NOVALUE;
L34: 

            /** 			end for*/
            _j_14306 = _j_14306 + 1;
            goto L32; // [989] 934
L33: 
            ;
        }
L31: 
        DeRef(_opt_14282);
        _opt_14282 = NOVALUE;

        /** 	end for*/
        _i_14280 = _i_14280 + 1;
        goto L2A; // [999] 807
L2B: 
        ;
    }

    /** 	integer has_h = 0, has_help = 0, has_question = 0*/
    _has_h_14320 = 0;
    _has_help_14321 = 0;
    _has_question_14322 = 0;

    /** 	for i = 1 to length(opts) do*/
    if (IS_SEQUENCE(_opts_14141)){
            _7976 = SEQ_PTR(_opts_14141)->length;
    }
    else {
        _7976 = 1;
    }
    {
        int _i_14324;
        _i_14324 = 1;
L36: 
        if (_i_14324 > _7976){
            goto L37; // [1020] 1106
        }

        /** 		if equal(opts[i][SHORTNAME], "h") then*/
        _2 = (int)SEQ_PTR(_opts_14141);
        _7977 = (int)*(((s1_ptr)_2)->base + _i_14324);
        _2 = (int)SEQ_PTR(_7977);
        _7978 = (int)*(((s1_ptr)_2)->base + 1);
        _7977 = NOVALUE;
        if (_7978 == _7979)
        _7980 = 1;
        else if (IS_ATOM_INT(_7978) && IS_ATOM_INT(_7979))
        _7980 = 0;
        else
        _7980 = (compare(_7978, _7979) == 0);
        _7978 = NOVALUE;
        if (_7980 == 0)
        {
            _7980 = NOVALUE;
            goto L38; // [1041] 1052
        }
        else{
            _7980 = NOVALUE;
        }

        /** 			has_h = 1*/
        _has_h_14320 = 1;
        goto L39; // [1049] 1076
L38: 

        /** 		elsif equal(opts[i][SHORTNAME], "?") then*/
        _2 = (int)SEQ_PTR(_opts_14141);
        _7981 = (int)*(((s1_ptr)_2)->base + _i_14324);
        _2 = (int)SEQ_PTR(_7981);
        _7982 = (int)*(((s1_ptr)_2)->base + 1);
        _7981 = NOVALUE;
        if (_7982 == _7983)
        _7984 = 1;
        else if (IS_ATOM_INT(_7982) && IS_ATOM_INT(_7983))
        _7984 = 0;
        else
        _7984 = (compare(_7982, _7983) == 0);
        _7982 = NOVALUE;
        if (_7984 == 0)
        {
            _7984 = NOVALUE;
            goto L3A; // [1066] 1075
        }
        else{
            _7984 = NOVALUE;
        }

        /** 			has_question = 1*/
        _has_question_14322 = 1;
L3A: 
L39: 

        /** 		if equal(opts[i][LONGNAME], "help") then*/
        _2 = (int)SEQ_PTR(_opts_14141);
        _7985 = (int)*(((s1_ptr)_2)->base + _i_14324);
        _2 = (int)SEQ_PTR(_7985);
        _7986 = (int)*(((s1_ptr)_2)->base + 2);
        _7985 = NOVALUE;
        if (_7986 == _7987)
        _7988 = 1;
        else if (IS_ATOM_INT(_7986) && IS_ATOM_INT(_7987))
        _7988 = 0;
        else
        _7988 = (compare(_7986, _7987) == 0);
        _7986 = NOVALUE;
        if (_7988 == 0)
        {
            _7988 = NOVALUE;
            goto L3B; // [1090] 1099
        }
        else{
            _7988 = NOVALUE;
        }

        /** 			has_help = 1*/
        _has_help_14321 = 1;
L3B: 

        /** 	end for*/
        _i_14324 = _i_14324 + 1;
        goto L36; // [1101] 1027
L37: 
        ;
    }

    /** 	if auto_help_switches then*/
    if (_auto_help_switches_14142 == 0)
    {
        goto L3C; // [1108] 1251
    }
    else{
    }

    /** 		integer appended_opts = 0*/
    _appended_opts_14342 = 0;

    /** 		if not has_h and not has_help then*/
    _7989 = (_has_h_14320 == 0);
    if (_7989 == 0) {
        goto L3D; // [1121] 1154
    }
    _7991 = (_has_help_14321 == 0);
    if (_7991 == 0)
    {
        DeRef(_7991);
        _7991 = NOVALUE;
        goto L3D; // [1129] 1154
    }
    else{
        DeRef(_7991);
        _7991 = NOVALUE;
    }

    /** 			opts = append(opts, {"h", "help", "Display the command options", {HELP}, -1})*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_7979);
    *((int *)(_2+4)) = _7979;
    RefDS(_7987);
    *((int *)(_2+8)) = _7987;
    RefDS(_7992);
    *((int *)(_2+12)) = _7992;
    RefDS(_7979);
    *((int *)(_2+16)) = _7979;
    *((int *)(_2+20)) = -1;
    _7993 = MAKE_SEQ(_1);
    RefDS(_7993);
    Append(&_opts_14141, _opts_14141, _7993);
    DeRefDS(_7993);
    _7993 = NOVALUE;

    /** 			appended_opts = 1*/
    _appended_opts_14342 = 1;
    goto L3E; // [1151] 1207
L3D: 

    /** 		elsif not has_h then*/
    if (_has_h_14320 != 0)
    goto L3F; // [1156] 1181

    /** 			opts = append(opts, {"h", 0, "Display the command options", {HELP}, -1})*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_7979);
    *((int *)(_2+4)) = _7979;
    *((int *)(_2+8)) = 0;
    RefDS(_7992);
    *((int *)(_2+12)) = _7992;
    RefDS(_7979);
    *((int *)(_2+16)) = _7979;
    *((int *)(_2+20)) = -1;
    _7996 = MAKE_SEQ(_1);
    RefDS(_7996);
    Append(&_opts_14141, _opts_14141, _7996);
    DeRefDS(_7996);
    _7996 = NOVALUE;

    /** 			appended_opts = 1*/
    _appended_opts_14342 = 1;
    goto L3E; // [1178] 1207
L3F: 

    /** 		elsif not has_help then*/
    if (_has_help_14321 != 0)
    goto L40; // [1183] 1206

    /** 			opts = append(opts, {0, "help", "Display the command options", {HELP}, -1})*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 0;
    RefDS(_7987);
    *((int *)(_2+8)) = _7987;
    RefDS(_7992);
    *((int *)(_2+12)) = _7992;
    RefDS(_7979);
    *((int *)(_2+16)) = _7979;
    *((int *)(_2+20)) = -1;
    _7999 = MAKE_SEQ(_1);
    RefDS(_7999);
    Append(&_opts_14141, _opts_14141, _7999);
    DeRefDS(_7999);
    _7999 = NOVALUE;

    /** 			appended_opts = 1*/
    _appended_opts_14342 = 1;
L40: 
L3E: 

    /** 		if not has_question then			*/
    if (_has_question_14322 != 0)
    goto L41; // [1209] 1232

    /** 			opts = append(opts, {"?", 0, "Display the command options", {HELP}, -1})*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_7983);
    *((int *)(_2+4)) = _7983;
    *((int *)(_2+8)) = 0;
    RefDS(_7992);
    *((int *)(_2+12)) = _7992;
    RefDS(_7979);
    *((int *)(_2+16)) = _7979;
    *((int *)(_2+20)) = -1;
    _8002 = MAKE_SEQ(_1);
    RefDS(_8002);
    Append(&_opts_14141, _opts_14141, _8002);
    DeRefDS(_8002);
    _8002 = NOVALUE;

    /** 			appended_opts = 1*/
    _appended_opts_14342 = 1;
L41: 

    /** 		if appended_opts then*/
    if (_appended_opts_14342 == 0)
    {
        goto L42; // [1234] 1250
    }
    else{
    }

    /** 			opts = standardize_opts(opts, 0)*/
    RefDS(_opts_14141);
    DeRef(_8004);
    _8004 = _opts_14141;
    _0 = _opts_14141;
    _opts_14141 = _4standardize_opts(_8004, 0);
    DeRefDS(_0);
    _8004 = NOVALUE;
L42: 
L3C: 

    /** 	for i = 1 to length(opts) do*/
    if (IS_SEQUENCE(_opts_14141)){
            _8006 = SEQ_PTR(_opts_14141)->length;
    }
    else {
        _8006 = 1;
    }
    {
        int _i_14366;
        _i_14366 = 1;
L43: 
        if (_i_14366 > _8006){
            goto L44; // [1258] 1434
        }

        /** 		if not find(HAS_PARAMETER, opts[i][OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opts_14141);
        _8007 = (int)*(((s1_ptr)_2)->base + _i_14366);
        _2 = (int)SEQ_PTR(_8007);
        _8008 = (int)*(((s1_ptr)_2)->base + 4);
        _8007 = NOVALUE;
        _8009 = find_from(112, _8008, 1);
        _8008 = NOVALUE;
        if (_8009 != 0)
        goto L45; // [1280] 1303
        _8009 = NOVALUE;

        /** 			opts[i][OPTIONS] &= NO_PARAMETER*/
        _2 = (int)SEQ_PTR(_opts_14141);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opts_14141 = MAKE_SEQ(_2);
        }
        _3 = (int)(_i_14366 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        _8013 = (int)*(((s1_ptr)_2)->base + 4);
        _8011 = NOVALUE;
        if (IS_SEQUENCE(_8013) && IS_ATOM(110)) {
            Append(&_8014, _8013, 110);
        }
        else if (IS_ATOM(_8013) && IS_SEQUENCE(110)) {
        }
        else {
            Concat((object_ptr)&_8014, _8013, 110);
            _8013 = NOVALUE;
        }
        _8013 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 4);
        _1 = *(int *)_2;
        *(int *)_2 = _8014;
        if( _1 != _8014 ){
            DeRef(_1);
        }
        _8014 = NOVALUE;
        _8011 = NOVALUE;
L45: 

        /** 		if not find(MULTIPLE, opts[i][OPTIONS]) and not find(ONCE, opts[i][OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opts_14141);
        _8015 = (int)*(((s1_ptr)_2)->base + _i_14366);
        _2 = (int)SEQ_PTR(_8015);
        _8016 = (int)*(((s1_ptr)_2)->base + 4);
        _8015 = NOVALUE;
        _8017 = find_from(42, _8016, 1);
        _8016 = NOVALUE;
        _8018 = (_8017 == 0);
        _8017 = NOVALUE;
        if (_8018 == 0) {
            goto L46; // [1321] 1365
        }
        _2 = (int)SEQ_PTR(_opts_14141);
        _8020 = (int)*(((s1_ptr)_2)->base + _i_14366);
        _2 = (int)SEQ_PTR(_8020);
        _8021 = (int)*(((s1_ptr)_2)->base + 4);
        _8020 = NOVALUE;
        _8022 = find_from(49, _8021, 1);
        _8021 = NOVALUE;
        _8023 = (_8022 == 0);
        _8022 = NOVALUE;
        if (_8023 == 0)
        {
            DeRef(_8023);
            _8023 = NOVALUE;
            goto L46; // [1342] 1365
        }
        else{
            DeRef(_8023);
            _8023 = NOVALUE;
        }

        /** 			opts[i][OPTIONS] &= ONCE*/
        _2 = (int)SEQ_PTR(_opts_14141);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opts_14141 = MAKE_SEQ(_2);
        }
        _3 = (int)(_i_14366 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        _8026 = (int)*(((s1_ptr)_2)->base + 4);
        _8024 = NOVALUE;
        if (IS_SEQUENCE(_8026) && IS_ATOM(49)) {
            Append(&_8027, _8026, 49);
        }
        else if (IS_ATOM(_8026) && IS_SEQUENCE(49)) {
        }
        else {
            Concat((object_ptr)&_8027, _8026, 49);
            _8026 = NOVALUE;
        }
        _8026 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 4);
        _1 = *(int *)_2;
        *(int *)_2 = _8027;
        if( _1 != _8027 ){
            DeRef(_1);
        }
        _8027 = NOVALUE;
        _8024 = NOVALUE;
L46: 

        /** 		if not find(HAS_CASE, opts[i][OPTIONS]) and not find(NO_CASE, opts[i][OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opts_14141);
        _8028 = (int)*(((s1_ptr)_2)->base + _i_14366);
        _2 = (int)SEQ_PTR(_8028);
        _8029 = (int)*(((s1_ptr)_2)->base + 4);
        _8028 = NOVALUE;
        _8030 = find_from(99, _8029, 1);
        _8029 = NOVALUE;
        _8031 = (_8030 == 0);
        _8030 = NOVALUE;
        if (_8031 == 0) {
            goto L47; // [1383] 1427
        }
        _2 = (int)SEQ_PTR(_opts_14141);
        _8033 = (int)*(((s1_ptr)_2)->base + _i_14366);
        _2 = (int)SEQ_PTR(_8033);
        _8034 = (int)*(((s1_ptr)_2)->base + 4);
        _8033 = NOVALUE;
        _8035 = find_from(105, _8034, 1);
        _8034 = NOVALUE;
        _8036 = (_8035 == 0);
        _8035 = NOVALUE;
        if (_8036 == 0)
        {
            DeRef(_8036);
            _8036 = NOVALUE;
            goto L47; // [1404] 1427
        }
        else{
            DeRef(_8036);
            _8036 = NOVALUE;
        }

        /** 			opts[i][OPTIONS] &= NO_CASE*/
        _2 = (int)SEQ_PTR(_opts_14141);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opts_14141 = MAKE_SEQ(_2);
        }
        _3 = (int)(_i_14366 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        _8039 = (int)*(((s1_ptr)_2)->base + 4);
        _8037 = NOVALUE;
        if (IS_SEQUENCE(_8039) && IS_ATOM(105)) {
            Append(&_8040, _8039, 105);
        }
        else if (IS_ATOM(_8039) && IS_SEQUENCE(105)) {
        }
        else {
            Concat((object_ptr)&_8040, _8039, 105);
            _8039 = NOVALUE;
        }
        _8039 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 4);
        _1 = *(int *)_2;
        *(int *)_2 = _8040;
        if( _1 != _8040 ){
            DeRef(_1);
        }
        _8040 = NOVALUE;
        _8037 = NOVALUE;
L47: 

        /** 	end for*/
        _i_14366 = _i_14366 + 1;
        goto L43; // [1429] 1265
L44: 
        ;
    }

    /** 	return opts*/
    _7876 = NOVALUE;
    _7882 = NOVALUE;
    _7902 = NOVALUE;
    _7941 = NOVALUE;
    DeRef(_7956);
    _7956 = NOVALUE;
    DeRef(_7967);
    _7967 = NOVALUE;
    DeRef(_7989);
    _7989 = NOVALUE;
    DeRef(_8018);
    _8018 = NOVALUE;
    DeRef(_8031);
    _8031 = NOVALUE;
    return _opts_14141;
    ;
}


void _4local_help(int _opts_14407, int _add_help_rid_14408, int _cmds_14409, int _std_14411, int _parse_options_14412)
{
    int _pad_size_14413 = NOVALUE;
    int _this_size_14414 = NOVALUE;
    int _cmd_14415 = NOVALUE;
    int _param_name_14416 = NOVALUE;
    int _has_param_14417 = NOVALUE;
    int _is_mandatory_14418 = NOVALUE;
    int _extras_mandatory_14419 = NOVALUE;
    int _extras_opt_14420 = NOVALUE;
    int _auto_help_14421 = NOVALUE;
    int _po_14422 = NOVALUE;
    int _msg_inlined_crash_at_94_14441 = NOVALUE;
    int _8230 = NOVALUE;
    int _8229 = NOVALUE;
    int _8228 = NOVALUE;
    int _8227 = NOVALUE;
    int _8225 = NOVALUE;
    int _8224 = NOVALUE;
    int _8223 = NOVALUE;
    int _8222 = NOVALUE;
    int _8221 = NOVALUE;
    int _8219 = NOVALUE;
    int _8217 = NOVALUE;
    int _8215 = NOVALUE;
    int _8213 = NOVALUE;
    int _8212 = NOVALUE;
    int _8211 = NOVALUE;
    int _8209 = NOVALUE;
    int _8208 = NOVALUE;
    int _8207 = NOVALUE;
    int _8204 = NOVALUE;
    int _8203 = NOVALUE;
    int _8202 = NOVALUE;
    int _8200 = NOVALUE;
    int _8199 = NOVALUE;
    int _8198 = NOVALUE;
    int _8196 = NOVALUE;
    int _8195 = NOVALUE;
    int _8194 = NOVALUE;
    int _8193 = NOVALUE;
    int _8192 = NOVALUE;
    int _8191 = NOVALUE;
    int _8190 = NOVALUE;
    int _8189 = NOVALUE;
    int _8186 = NOVALUE;
    int _8182 = NOVALUE;
    int _8179 = NOVALUE;
    int _8178 = NOVALUE;
    int _8177 = NOVALUE;
    int _8172 = NOVALUE;
    int _8171 = NOVALUE;
    int _8170 = NOVALUE;
    int _8169 = NOVALUE;
    int _8165 = NOVALUE;
    int _8162 = NOVALUE;
    int _8161 = NOVALUE;
    int _8160 = NOVALUE;
    int _8157 = NOVALUE;
    int _8156 = NOVALUE;
    int _8155 = NOVALUE;
    int _8153 = NOVALUE;
    int _8152 = NOVALUE;
    int _8151 = NOVALUE;
    int _8149 = NOVALUE;
    int _8148 = NOVALUE;
    int _8147 = NOVALUE;
    int _8146 = NOVALUE;
    int _8145 = NOVALUE;
    int _8144 = NOVALUE;
    int _8141 = NOVALUE;
    int _8140 = NOVALUE;
    int _8139 = NOVALUE;
    int _8136 = NOVALUE;
    int _8135 = NOVALUE;
    int _8134 = NOVALUE;
    int _8133 = NOVALUE;
    int _8132 = NOVALUE;
    int _8131 = NOVALUE;
    int _8130 = NOVALUE;
    int _8129 = NOVALUE;
    int _8128 = NOVALUE;
    int _8127 = NOVALUE;
    int _8126 = NOVALUE;
    int _8125 = NOVALUE;
    int _8120 = NOVALUE;
    int _8119 = NOVALUE;
    int _8117 = NOVALUE;
    int _8116 = NOVALUE;
    int _8115 = NOVALUE;
    int _8114 = NOVALUE;
    int _8113 = NOVALUE;
    int _8112 = NOVALUE;
    int _8110 = NOVALUE;
    int _8109 = NOVALUE;
    int _8108 = NOVALUE;
    int _8104 = NOVALUE;
    int _8103 = NOVALUE;
    int _8101 = NOVALUE;
    int _8100 = NOVALUE;
    int _8099 = NOVALUE;
    int _8098 = NOVALUE;
    int _8097 = NOVALUE;
    int _8096 = NOVALUE;
    int _8095 = NOVALUE;
    int _8092 = NOVALUE;
    int _8091 = NOVALUE;
    int _8090 = NOVALUE;
    int _8088 = NOVALUE;
    int _8086 = NOVALUE;
    int _8085 = NOVALUE;
    int _8084 = NOVALUE;
    int _8083 = NOVALUE;
    int _8082 = NOVALUE;
    int _8081 = NOVALUE;
    int _8078 = NOVALUE;
    int _8077 = NOVALUE;
    int _8076 = NOVALUE;
    int _8074 = NOVALUE;
    int _8073 = NOVALUE;
    int _8072 = NOVALUE;
    int _8071 = NOVALUE;
    int _8070 = NOVALUE;
    int _8069 = NOVALUE;
    int _8068 = NOVALUE;
    int _8067 = NOVALUE;
    int _8066 = NOVALUE;
    int _8065 = NOVALUE;
    int _8064 = NOVALUE;
    int _8063 = NOVALUE;
    int _8062 = NOVALUE;
    int _8061 = NOVALUE;
    int _8060 = NOVALUE;
    int _8059 = NOVALUE;
    int _8058 = NOVALUE;
    int _8057 = NOVALUE;
    int _8049 = NOVALUE;
    int _8046 = NOVALUE;
    int _8044 = NOVALUE;
    int _8042 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer extras_mandatory = 0*/
    _extras_mandatory_14419 = 0;

    /** 	integer extras_opt = 0*/
    _extras_opt_14420 = 0;

    /** 	integer auto_help = 1*/
    _auto_help_14421 = 1;

    /** 	integer po = 1*/
    _po_14422 = 1;

    /** 	if atom(parse_options) then*/
    _8042 = IS_ATOM(_parse_options_14412);
    if (_8042 == 0)
    {
        _8042 = NOVALUE;
        goto L1; // [32] 42
    }
    else{
        _8042 = NOVALUE;
    }

    /** 		parse_options = {parse_options}*/
    _0 = _parse_options_14412;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_parse_options_14412);
    *((int *)(_2+4)) = _parse_options_14412;
    _parse_options_14412 = MAKE_SEQ(_1);
    DeRefi(_0);
L1: 

    /** 	while po <= length(parse_options) do*/
L2: 
    if (IS_SEQUENCE(_parse_options_14412)){
            _8044 = SEQ_PTR(_parse_options_14412)->length;
    }
    else {
        _8044 = 1;
    }
    if (_po_14422 > _8044)
    goto L3; // [50] 143

    /** 		switch parse_options[po] do*/
    _2 = (int)SEQ_PTR(_parse_options_14412);
    _8046 = (int)*(((s1_ptr)_2)->base + _po_14422);
    if (IS_SEQUENCE(_8046) ){
        goto L4; // [60] 129
    }
    if(!IS_ATOM_INT(_8046)){
        if( (DBL_PTR(_8046)->dbl != (double) ((int) DBL_PTR(_8046)->dbl) ) ){
            goto L4; // [60] 129
        }
        _0 = (int) DBL_PTR(_8046)->dbl;
    }
    else {
        _0 = _8046;
    };
    _8046 = NOVALUE;
    switch ( _0 ){ 

        /** 			case HELP_RID then*/
        case 1:

        /** 				if po < length(parse_options) then*/
        if (IS_SEQUENCE(_parse_options_14412)){
                _8049 = SEQ_PTR(_parse_options_14412)->length;
        }
        else {
            _8049 = 1;
        }
        if (_po_14422 >= _8049)
        goto L5; // [74] 93

        /** 					po += 1*/
        _po_14422 = _po_14422 + 1;

        /** 					add_help_rid = parse_options[po]*/
        DeRef(_add_help_rid_14408);
        _2 = (int)SEQ_PTR(_parse_options_14412);
        _add_help_rid_14408 = (int)*(((s1_ptr)_2)->base + _po_14422);
        Ref(_add_help_rid_14408);
        goto L6; // [90] 132
L5: 

        /** 					error:crash("HELP_RID was given to cmd_parse with no routine_id")*/

        /** 	msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_94_14441);
        _msg_inlined_crash_at_94_14441 = EPrintf(-9999999, _8053, _5);

        /** 	machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_94_14441);

        /** end procedure*/
        goto L7; // [108] 111
L7: 
        DeRefi(_msg_inlined_crash_at_94_14441);
        _msg_inlined_crash_at_94_14441 = NOVALUE;
        goto L6; // [114] 132

        /** 			case NO_HELP then*/
        case 9:

        /** 				auto_help = 0*/
        _auto_help_14421 = 0;
        goto L6; // [125] 132

        /** 			case else*/
        default:
L4: 
    ;}L6: 

    /** 		po += 1*/
    _po_14422 = _po_14422 + 1;

    /** 	end while*/
    goto L2; // [140] 47
L3: 

    /** 	if std = 0 then*/
    if (_std_14411 != 0)
    goto L8; // [145] 159

    /** 		opts = standardize_opts(opts, auto_help)*/
    RefDS(_opts_14407);
    _0 = _opts_14407;
    _opts_14407 = _4standardize_opts(_opts_14407, _auto_help_14421);
    DeRefDS(_0);
L8: 

    /** 	pad_size = 0*/
    _pad_size_14413 = 0;

    /** 	for i = 1 to length(opts) do*/
    if (IS_SEQUENCE(_opts_14407)){
            _8057 = SEQ_PTR(_opts_14407)->length;
    }
    else {
        _8057 = 1;
    }
    {
        int _i_14449;
        _i_14449 = 1;
L9: 
        if (_i_14449 > _8057){
            goto LA; // [169] 562
        }

        /** 		this_size = 0*/
        _this_size_14414 = 0;

        /** 		param_name = ""*/
        RefDS(_5);
        DeRef(_param_name_14416);
        _param_name_14416 = _5;

        /** 		if atom(opts[i][SHORTNAME]) and atom(opts[i][LONGNAME]) then*/
        _2 = (int)SEQ_PTR(_opts_14407);
        _8058 = (int)*(((s1_ptr)_2)->base + _i_14449);
        _2 = (int)SEQ_PTR(_8058);
        _8059 = (int)*(((s1_ptr)_2)->base + 1);
        _8058 = NOVALUE;
        _8060 = IS_ATOM(_8059);
        _8059 = NOVALUE;
        if (_8060 == 0) {
            goto LB; // [201] 254
        }
        _2 = (int)SEQ_PTR(_opts_14407);
        _8062 = (int)*(((s1_ptr)_2)->base + _i_14449);
        _2 = (int)SEQ_PTR(_8062);
        _8063 = (int)*(((s1_ptr)_2)->base + 2);
        _8062 = NOVALUE;
        _8064 = IS_ATOM(_8063);
        _8063 = NOVALUE;
        if (_8064 == 0)
        {
            _8064 = NOVALUE;
            goto LB; // [217] 254
        }
        else{
            _8064 = NOVALUE;
        }

        /** 			extras_opt = i*/
        _extras_opt_14420 = _i_14449;

        /** 			if find(MANDATORY, opts[i][OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opts_14407);
        _8065 = (int)*(((s1_ptr)_2)->base + _i_14449);
        _2 = (int)SEQ_PTR(_8065);
        _8066 = (int)*(((s1_ptr)_2)->base + 4);
        _8065 = NOVALUE;
        _8067 = find_from(109, _8066, 1);
        _8066 = NOVALUE;
        if (_8067 == 0)
        {
            _8067 = NOVALUE;
            goto LC; // [240] 557
        }
        else{
            _8067 = NOVALUE;
        }

        /** 				extras_mandatory = 1*/
        _extras_mandatory_14419 = 1;

        /** 			continue*/
        goto LC; // [251] 557
LB: 

        /** 		if sequence(opts[i][SHORTNAME]) then*/
        _2 = (int)SEQ_PTR(_opts_14407);
        _8068 = (int)*(((s1_ptr)_2)->base + _i_14449);
        _2 = (int)SEQ_PTR(_8068);
        _8069 = (int)*(((s1_ptr)_2)->base + 1);
        _8068 = NOVALUE;
        _8070 = IS_SEQUENCE(_8069);
        _8069 = NOVALUE;
        if (_8070 == 0)
        {
            _8070 = NOVALUE;
            goto LD; // [267] 320
        }
        else{
            _8070 = NOVALUE;
        }

        /** 			this_size += length(opts[i][SHORTNAME]) + 1 -- Allow for "-"*/
        _2 = (int)SEQ_PTR(_opts_14407);
        _8071 = (int)*(((s1_ptr)_2)->base + _i_14449);
        _2 = (int)SEQ_PTR(_8071);
        _8072 = (int)*(((s1_ptr)_2)->base + 1);
        _8071 = NOVALUE;
        if (IS_SEQUENCE(_8072)){
                _8073 = SEQ_PTR(_8072)->length;
        }
        else {
            _8073 = 1;
        }
        _8072 = NOVALUE;
        _8074 = _8073 + 1;
        _8073 = NOVALUE;
        _this_size_14414 = _this_size_14414 + _8074;
        _8074 = NOVALUE;

        /** 			if find(MANDATORY, opts[i][OPTIONS]) = 0 then*/
        _2 = (int)SEQ_PTR(_opts_14407);
        _8076 = (int)*(((s1_ptr)_2)->base + _i_14449);
        _2 = (int)SEQ_PTR(_8076);
        _8077 = (int)*(((s1_ptr)_2)->base + 4);
        _8076 = NOVALUE;
        _8078 = find_from(109, _8077, 1);
        _8077 = NOVALUE;
        if (_8078 != 0)
        goto LE; // [308] 319

        /** 				this_size += 2 -- Allow for '[' ']'*/
        _this_size_14414 = _this_size_14414 + 2;
LE: 
LD: 

        /** 		if sequence(opts[i][LONGNAME]) then*/
        _2 = (int)SEQ_PTR(_opts_14407);
        _8081 = (int)*(((s1_ptr)_2)->base + _i_14449);
        _2 = (int)SEQ_PTR(_8081);
        _8082 = (int)*(((s1_ptr)_2)->base + 2);
        _8081 = NOVALUE;
        _8083 = IS_SEQUENCE(_8082);
        _8082 = NOVALUE;
        if (_8083 == 0)
        {
            _8083 = NOVALUE;
            goto LF; // [333] 386
        }
        else{
            _8083 = NOVALUE;
        }

        /** 			this_size += length(opts[i][LONGNAME]) + 2 -- Allow for "--"*/
        _2 = (int)SEQ_PTR(_opts_14407);
        _8084 = (int)*(((s1_ptr)_2)->base + _i_14449);
        _2 = (int)SEQ_PTR(_8084);
        _8085 = (int)*(((s1_ptr)_2)->base + 2);
        _8084 = NOVALUE;
        if (IS_SEQUENCE(_8085)){
                _8086 = SEQ_PTR(_8085)->length;
        }
        else {
            _8086 = 1;
        }
        _8085 = NOVALUE;
        _8088 = _8086 + 2;
        _8086 = NOVALUE;
        _this_size_14414 = _this_size_14414 + _8088;
        _8088 = NOVALUE;

        /** 			if find(MANDATORY, opts[i][OPTIONS]) = 0 then*/
        _2 = (int)SEQ_PTR(_opts_14407);
        _8090 = (int)*(((s1_ptr)_2)->base + _i_14449);
        _2 = (int)SEQ_PTR(_8090);
        _8091 = (int)*(((s1_ptr)_2)->base + 4);
        _8090 = NOVALUE;
        _8092 = find_from(109, _8091, 1);
        _8091 = NOVALUE;
        if (_8092 != 0)
        goto L10; // [374] 385

        /** 				this_size += 2 -- Allow for '[' ']'*/
        _this_size_14414 = _this_size_14414 + 2;
L10: 
LF: 

        /** 		if sequence(opts[i][SHORTNAME]) and sequence(opts[i][LONGNAME]) then*/
        _2 = (int)SEQ_PTR(_opts_14407);
        _8095 = (int)*(((s1_ptr)_2)->base + _i_14449);
        _2 = (int)SEQ_PTR(_8095);
        _8096 = (int)*(((s1_ptr)_2)->base + 1);
        _8095 = NOVALUE;
        _8097 = IS_SEQUENCE(_8096);
        _8096 = NOVALUE;
        if (_8097 == 0) {
            goto L11; // [399] 425
        }
        _2 = (int)SEQ_PTR(_opts_14407);
        _8099 = (int)*(((s1_ptr)_2)->base + _i_14449);
        _2 = (int)SEQ_PTR(_8099);
        _8100 = (int)*(((s1_ptr)_2)->base + 2);
        _8099 = NOVALUE;
        _8101 = IS_SEQUENCE(_8100);
        _8100 = NOVALUE;
        if (_8101 == 0)
        {
            _8101 = NOVALUE;
            goto L11; // [415] 425
        }
        else{
            _8101 = NOVALUE;
        }

        /** 			this_size += 2 -- Allow for ", " between short and long names*/
        _this_size_14414 = _this_size_14414 + 2;
L11: 

        /** 		has_param = find(HAS_PARAMETER, opts[i][OPTIONS])*/
        _2 = (int)SEQ_PTR(_opts_14407);
        _8103 = (int)*(((s1_ptr)_2)->base + _i_14449);
        _2 = (int)SEQ_PTR(_8103);
        _8104 = (int)*(((s1_ptr)_2)->base + 4);
        _8103 = NOVALUE;
        _has_param_14417 = find_from(112, _8104, 1);
        _8104 = NOVALUE;

        /** 		if has_param != 0 then*/
        if (_has_param_14417 == 0)
        goto L12; // [442] 543

        /** 			this_size += 1 -- Allow for " "*/
        _this_size_14414 = _this_size_14414 + 1;

        /** 			if has_param < length(opts[i][OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opts_14407);
        _8108 = (int)*(((s1_ptr)_2)->base + _i_14449);
        _2 = (int)SEQ_PTR(_8108);
        _8109 = (int)*(((s1_ptr)_2)->base + 4);
        _8108 = NOVALUE;
        if (IS_SEQUENCE(_8109)){
                _8110 = SEQ_PTR(_8109)->length;
        }
        else {
            _8110 = 1;
        }
        _8109 = NOVALUE;
        if (_has_param_14417 >= _8110)
        goto L13; // [465] 519

        /** 				if sequence(opts[i][OPTIONS][has_param]) then*/
        _2 = (int)SEQ_PTR(_opts_14407);
        _8112 = (int)*(((s1_ptr)_2)->base + _i_14449);
        _2 = (int)SEQ_PTR(_8112);
        _8113 = (int)*(((s1_ptr)_2)->base + 4);
        _8112 = NOVALUE;
        _2 = (int)SEQ_PTR(_8113);
        _8114 = (int)*(((s1_ptr)_2)->base + _has_param_14417);
        _8113 = NOVALUE;
        _8115 = IS_SEQUENCE(_8114);
        _8114 = NOVALUE;
        if (_8115 == 0)
        {
            _8115 = NOVALUE;
            goto L14; // [486] 508
        }
        else{
            _8115 = NOVALUE;
        }

        /** 					param_name = opts[i][OPTIONS][has_param]*/
        _2 = (int)SEQ_PTR(_opts_14407);
        _8116 = (int)*(((s1_ptr)_2)->base + _i_14449);
        _2 = (int)SEQ_PTR(_8116);
        _8117 = (int)*(((s1_ptr)_2)->base + 4);
        _8116 = NOVALUE;
        DeRef(_param_name_14416);
        _2 = (int)SEQ_PTR(_8117);
        _param_name_14416 = (int)*(((s1_ptr)_2)->base + _has_param_14417);
        Ref(_param_name_14416);
        _8117 = NOVALUE;
        goto L15; // [505] 527
L14: 

        /** 					param_name = "x"*/
        RefDS(_7900);
        DeRef(_param_name_14416);
        _param_name_14416 = _7900;
        goto L15; // [516] 527
L13: 

        /** 				param_name = "x"*/
        RefDS(_7900);
        DeRef(_param_name_14416);
        _param_name_14416 = _7900;
L15: 

        /** 			this_size += 2 + length(param_name)*/
        if (IS_SEQUENCE(_param_name_14416)){
                _8119 = SEQ_PTR(_param_name_14416)->length;
        }
        else {
            _8119 = 1;
        }
        _8120 = 2 + _8119;
        _8119 = NOVALUE;
        _this_size_14414 = _this_size_14414 + _8120;
        _8120 = NOVALUE;
L12: 

        /** 		if pad_size < this_size then*/
        if (_pad_size_14413 >= _this_size_14414)
        goto L16; // [545] 555

        /** 			pad_size = this_size*/
        _pad_size_14413 = _this_size_14414;
L16: 

        /** 	end for*/
LC: 
        _i_14449 = _i_14449 + 1;
        goto L9; // [557] 176
LA: 
        ;
    }

    /** 	pad_size += 3 -- Allow for minimum gap between cmd and its description*/
    _pad_size_14413 = _pad_size_14413 + 3;

    /** 	printf(1, "%s options:\n", {cmds[2]})*/
    _2 = (int)SEQ_PTR(_cmds_14409);
    _8125 = (int)*(((s1_ptr)_2)->base + 2);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_8125);
    *((int *)(_2+4)) = _8125;
    _8126 = MAKE_SEQ(_1);
    _8125 = NOVALUE;
    EPrintf(1, _8124, _8126);
    DeRefDS(_8126);
    _8126 = NOVALUE;

    /** 	for i = 1 to length(opts) do*/
    if (IS_SEQUENCE(_opts_14407)){
            _8127 = SEQ_PTR(_opts_14407)->length;
    }
    else {
        _8127 = 1;
    }
    {
        int _i_14533;
        _i_14533 = 1;
L17: 
        if (_i_14533 > _8127){
            goto L18; // [587] 1006
        }

        /** 		if atom(opts[i][SHORTNAME]) and atom(opts[i][LONGNAME]) then*/
        _2 = (int)SEQ_PTR(_opts_14407);
        _8128 = (int)*(((s1_ptr)_2)->base + _i_14533);
        _2 = (int)SEQ_PTR(_8128);
        _8129 = (int)*(((s1_ptr)_2)->base + 1);
        _8128 = NOVALUE;
        _8130 = IS_ATOM(_8129);
        _8129 = NOVALUE;
        if (_8130 == 0) {
            goto L19; // [607] 631
        }
        _2 = (int)SEQ_PTR(_opts_14407);
        _8132 = (int)*(((s1_ptr)_2)->base + _i_14533);
        _2 = (int)SEQ_PTR(_8132);
        _8133 = (int)*(((s1_ptr)_2)->base + 2);
        _8132 = NOVALUE;
        _8134 = IS_ATOM(_8133);
        _8133 = NOVALUE;
        if (_8134 == 0)
        {
            _8134 = NOVALUE;
            goto L19; // [623] 631
        }
        else{
            _8134 = NOVALUE;
        }

        /** 			continue*/
        goto L1A; // [628] 1001
L19: 

        /** 		has_param    = find(HAS_PARAMETER, opts[i][OPTIONS])*/
        _2 = (int)SEQ_PTR(_opts_14407);
        _8135 = (int)*(((s1_ptr)_2)->base + _i_14533);
        _2 = (int)SEQ_PTR(_8135);
        _8136 = (int)*(((s1_ptr)_2)->base + 4);
        _8135 = NOVALUE;
        _has_param_14417 = find_from(112, _8136, 1);
        _8136 = NOVALUE;

        /** 		if has_param != 0 then*/
        if (_has_param_14417 == 0)
        goto L1B; // [648] 734

        /** 			if has_param < length(opts[i][OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opts_14407);
        _8139 = (int)*(((s1_ptr)_2)->base + _i_14533);
        _2 = (int)SEQ_PTR(_8139);
        _8140 = (int)*(((s1_ptr)_2)->base + 4);
        _8139 = NOVALUE;
        if (IS_SEQUENCE(_8140)){
                _8141 = SEQ_PTR(_8140)->length;
        }
        else {
            _8141 = 1;
        }
        _8140 = NOVALUE;
        if (_has_param_14417 >= _8141)
        goto L1C; // [665] 725

        /** 				has_param += 1*/
        _has_param_14417 = _has_param_14417 + 1;

        /** 				if sequence(opts[i][OPTIONS][has_param]) then*/
        _2 = (int)SEQ_PTR(_opts_14407);
        _8144 = (int)*(((s1_ptr)_2)->base + _i_14533);
        _2 = (int)SEQ_PTR(_8144);
        _8145 = (int)*(((s1_ptr)_2)->base + 4);
        _8144 = NOVALUE;
        _2 = (int)SEQ_PTR(_8145);
        _8146 = (int)*(((s1_ptr)_2)->base + _has_param_14417);
        _8145 = NOVALUE;
        _8147 = IS_SEQUENCE(_8146);
        _8146 = NOVALUE;
        if (_8147 == 0)
        {
            _8147 = NOVALUE;
            goto L1D; // [692] 714
        }
        else{
            _8147 = NOVALUE;
        }

        /** 					param_name = opts[i][OPTIONS][has_param]*/
        _2 = (int)SEQ_PTR(_opts_14407);
        _8148 = (int)*(((s1_ptr)_2)->base + _i_14533);
        _2 = (int)SEQ_PTR(_8148);
        _8149 = (int)*(((s1_ptr)_2)->base + 4);
        _8148 = NOVALUE;
        DeRef(_param_name_14416);
        _2 = (int)SEQ_PTR(_8149);
        _param_name_14416 = (int)*(((s1_ptr)_2)->base + _has_param_14417);
        Ref(_param_name_14416);
        _8149 = NOVALUE;
        goto L1E; // [711] 733
L1D: 

        /** 					param_name = "x"*/
        RefDS(_7900);
        DeRef(_param_name_14416);
        _param_name_14416 = _7900;
        goto L1E; // [722] 733
L1C: 

        /** 				param_name = "x"*/
        RefDS(_7900);
        DeRef(_param_name_14416);
        _param_name_14416 = _7900;
L1E: 
L1B: 

        /** 		is_mandatory = (find(MANDATORY,     opts[i][OPTIONS]) != 0)*/
        _2 = (int)SEQ_PTR(_opts_14407);
        _8151 = (int)*(((s1_ptr)_2)->base + _i_14533);
        _2 = (int)SEQ_PTR(_8151);
        _8152 = (int)*(((s1_ptr)_2)->base + 4);
        _8151 = NOVALUE;
        _8153 = find_from(109, _8152, 1);
        _8152 = NOVALUE;
        _is_mandatory_14418 = (_8153 != 0);
        _8153 = NOVALUE;

        /** 		cmd = ""*/
        RefDS(_5);
        DeRef(_cmd_14415);
        _cmd_14415 = _5;

        /** 		if sequence(opts[i][SHORTNAME]) then*/
        _2 = (int)SEQ_PTR(_opts_14407);
        _8155 = (int)*(((s1_ptr)_2)->base + _i_14533);
        _2 = (int)SEQ_PTR(_8155);
        _8156 = (int)*(((s1_ptr)_2)->base + 1);
        _8155 = NOVALUE;
        _8157 = IS_SEQUENCE(_8156);
        _8156 = NOVALUE;
        if (_8157 == 0)
        {
            _8157 = NOVALUE;
            goto L1F; // [773] 838
        }
        else{
            _8157 = NOVALUE;
        }

        /** 			if not is_mandatory then*/
        if (_is_mandatory_14418 != 0)
        goto L20; // [778] 788

        /** 				cmd &= '['*/
        Append(&_cmd_14415, _cmd_14415, 91);
L20: 

        /** 			cmd &= '-' & opts[i][SHORTNAME]*/
        _2 = (int)SEQ_PTR(_opts_14407);
        _8160 = (int)*(((s1_ptr)_2)->base + _i_14533);
        _2 = (int)SEQ_PTR(_8160);
        _8161 = (int)*(((s1_ptr)_2)->base + 1);
        _8160 = NOVALUE;
        if (IS_SEQUENCE(45) && IS_ATOM(_8161)) {
        }
        else if (IS_ATOM(45) && IS_SEQUENCE(_8161)) {
            Prepend(&_8162, _8161, 45);
        }
        else {
            Concat((object_ptr)&_8162, 45, _8161);
        }
        _8161 = NOVALUE;
        Concat((object_ptr)&_cmd_14415, _cmd_14415, _8162);
        DeRefDS(_8162);
        _8162 = NOVALUE;

        /** 			if has_param != 0 then*/
        if (_has_param_14417 == 0)
        goto L21; // [808] 825

        /** 				cmd &= ' ' & param_name*/
        Prepend(&_8165, _param_name_14416, 32);
        Concat((object_ptr)&_cmd_14415, _cmd_14415, _8165);
        DeRefDS(_8165);
        _8165 = NOVALUE;
L21: 

        /** 			if not is_mandatory then*/
        if (_is_mandatory_14418 != 0)
        goto L22; // [827] 837

        /** 				cmd &= ']'*/
        Append(&_cmd_14415, _cmd_14415, 93);
L22: 
L1F: 

        /** 		if sequence(opts[i][LONGNAME]) then*/
        _2 = (int)SEQ_PTR(_opts_14407);
        _8169 = (int)*(((s1_ptr)_2)->base + _i_14533);
        _2 = (int)SEQ_PTR(_8169);
        _8170 = (int)*(((s1_ptr)_2)->base + 2);
        _8169 = NOVALUE;
        _8171 = IS_SEQUENCE(_8170);
        _8170 = NOVALUE;
        if (_8171 == 0)
        {
            _8171 = NOVALUE;
            goto L23; // [851] 930
        }
        else{
            _8171 = NOVALUE;
        }

        /** 			if length(cmd) > 0 then cmd &= ", " end if*/
        if (IS_SEQUENCE(_cmd_14415)){
                _8172 = SEQ_PTR(_cmd_14415)->length;
        }
        else {
            _8172 = 1;
        }
        if (_8172 <= 0)
        goto L24; // [859] 868
        Concat((object_ptr)&_cmd_14415, _cmd_14415, _972);
L24: 

        /** 			if not is_mandatory then*/
        if (_is_mandatory_14418 != 0)
        goto L25; // [870] 880

        /** 				cmd &= '['*/
        Append(&_cmd_14415, _cmd_14415, 91);
L25: 

        /** 			cmd &= "--" & opts[i][LONGNAME]*/
        _2 = (int)SEQ_PTR(_opts_14407);
        _8177 = (int)*(((s1_ptr)_2)->base + _i_14533);
        _2 = (int)SEQ_PTR(_8177);
        _8178 = (int)*(((s1_ptr)_2)->base + 2);
        _8177 = NOVALUE;
        if (IS_SEQUENCE(_7087) && IS_ATOM(_8178)) {
            Ref(_8178);
            Append(&_8179, _7087, _8178);
        }
        else if (IS_ATOM(_7087) && IS_SEQUENCE(_8178)) {
        }
        else {
            Concat((object_ptr)&_8179, _7087, _8178);
        }
        _8178 = NOVALUE;
        Concat((object_ptr)&_cmd_14415, _cmd_14415, _8179);
        DeRefDS(_8179);
        _8179 = NOVALUE;

        /** 			if has_param != 0 then*/
        if (_has_param_14417 == 0)
        goto L26; // [900] 917

        /** 				cmd &= '=' & param_name*/
        Prepend(&_8182, _param_name_14416, 61);
        Concat((object_ptr)&_cmd_14415, _cmd_14415, _8182);
        DeRefDS(_8182);
        _8182 = NOVALUE;
L26: 

        /** 			if not is_mandatory then*/
        if (_is_mandatory_14418 != 0)
        goto L27; // [919] 929

        /** 				cmd &= ']'*/
        Append(&_cmd_14415, _cmd_14415, 93);
L27: 
L23: 

        /** 		if length(cmd) > pad_size then*/
        if (IS_SEQUENCE(_cmd_14415)){
                _8186 = SEQ_PTR(_cmd_14415)->length;
        }
        else {
            _8186 = 1;
        }
        if (_8186 <= _pad_size_14413)
        goto L28; // [935] 966

        /** 			puts(1, "   " & cmd & '\n')*/
        {
            int concat_list[3];

            concat_list[0] = 10;
            concat_list[1] = _cmd_14415;
            concat_list[2] = _8188;
            Concat_N((object_ptr)&_8189, concat_list, 3);
        }
        EPuts(1, _8189); // DJP 
        DeRefDS(_8189);
        _8189 = NOVALUE;

        /** 			puts(1, repeat(' ', pad_size + 3))*/
        _8190 = _pad_size_14413 + 3;
        _8191 = Repeat(32, _8190);
        _8190 = NOVALUE;
        EPuts(1, _8191); // DJP 
        DeRefDS(_8191);
        _8191 = NOVALUE;
        goto L29; // [963] 982
L28: 

        /** 			puts(1, "   " & stdseq:pad_tail(cmd, pad_size))*/
        RefDS(_cmd_14415);
        _8192 = _23pad_tail(_cmd_14415, _pad_size_14413, 32);
        if (IS_SEQUENCE(_8188) && IS_ATOM(_8192)) {
            Ref(_8192);
            Append(&_8193, _8188, _8192);
        }
        else if (IS_ATOM(_8188) && IS_SEQUENCE(_8192)) {
        }
        else {
            Concat((object_ptr)&_8193, _8188, _8192);
        }
        DeRef(_8192);
        _8192 = NOVALUE;
        EPuts(1, _8193); // DJP 
        DeRefDS(_8193);
        _8193 = NOVALUE;
L29: 

        /** 		puts(1, opts[i][DESCRIPTION] & '\n')*/
        _2 = (int)SEQ_PTR(_opts_14407);
        _8194 = (int)*(((s1_ptr)_2)->base + _i_14533);
        _2 = (int)SEQ_PTR(_8194);
        _8195 = (int)*(((s1_ptr)_2)->base + 3);
        _8194 = NOVALUE;
        if (IS_SEQUENCE(_8195) && IS_ATOM(10)) {
            Append(&_8196, _8195, 10);
        }
        else if (IS_ATOM(_8195) && IS_SEQUENCE(10)) {
        }
        else {
            Concat((object_ptr)&_8196, _8195, 10);
            _8195 = NOVALUE;
        }
        _8195 = NOVALUE;
        EPuts(1, _8196); // DJP 
        DeRefDS(_8196);
        _8196 = NOVALUE;

        /** 	end for*/
L1A: 
        _i_14533 = _i_14533 + 1;
        goto L17; // [1001] 594
L18: 
        ;
    }

    /** 	if extras_mandatory != 0 then*/
    if (_extras_mandatory_14419 == 0)
    goto L2A; // [1008] 1063

    /** 		if length(opts[extras_opt][DESCRIPTION]) > 0 then*/
    _2 = (int)SEQ_PTR(_opts_14407);
    _8198 = (int)*(((s1_ptr)_2)->base + _extras_opt_14420);
    _2 = (int)SEQ_PTR(_8198);
    _8199 = (int)*(((s1_ptr)_2)->base + 3);
    _8198 = NOVALUE;
    if (IS_SEQUENCE(_8199)){
            _8200 = SEQ_PTR(_8199)->length;
    }
    else {
        _8200 = 1;
    }
    _8199 = NOVALUE;
    if (_8200 <= 0)
    goto L2B; // [1025] 1054

    /** 			puts(1, "\n" & opts[extras_opt][DESCRIPTION])*/
    _2 = (int)SEQ_PTR(_opts_14407);
    _8202 = (int)*(((s1_ptr)_2)->base + _extras_opt_14420);
    _2 = (int)SEQ_PTR(_8202);
    _8203 = (int)*(((s1_ptr)_2)->base + 3);
    _8202 = NOVALUE;
    if (IS_SEQUENCE(_3128) && IS_ATOM(_8203)) {
        Ref(_8203);
        Append(&_8204, _3128, _8203);
    }
    else if (IS_ATOM(_3128) && IS_SEQUENCE(_8203)) {
    }
    else {
        Concat((object_ptr)&_8204, _3128, _8203);
    }
    _8203 = NOVALUE;
    EPuts(1, _8204); // DJP 
    DeRefDS(_8204);
    _8204 = NOVALUE;

    /** 			puts(1, '\n')*/
    EPuts(1, 10); // DJP 
    goto L2C; // [1051] 1119
L2B: 

    /** 			puts(1, "One or more additional arguments are also required\n")*/
    EPuts(1, _8205); // DJP 
    goto L2C; // [1060] 1119
L2A: 

    /** 	elsif extras_opt > 0 then*/
    if (_extras_opt_14420 <= 0)
    goto L2D; // [1065] 1118

    /** 		if length(opts[extras_opt][DESCRIPTION]) > 0 then*/
    _2 = (int)SEQ_PTR(_opts_14407);
    _8207 = (int)*(((s1_ptr)_2)->base + _extras_opt_14420);
    _2 = (int)SEQ_PTR(_8207);
    _8208 = (int)*(((s1_ptr)_2)->base + 3);
    _8207 = NOVALUE;
    if (IS_SEQUENCE(_8208)){
            _8209 = SEQ_PTR(_8208)->length;
    }
    else {
        _8209 = 1;
    }
    _8208 = NOVALUE;
    if (_8209 <= 0)
    goto L2E; // [1082] 1111

    /** 			puts(1, "\n" & opts[extras_opt][DESCRIPTION])*/
    _2 = (int)SEQ_PTR(_opts_14407);
    _8211 = (int)*(((s1_ptr)_2)->base + _extras_opt_14420);
    _2 = (int)SEQ_PTR(_8211);
    _8212 = (int)*(((s1_ptr)_2)->base + 3);
    _8211 = NOVALUE;
    if (IS_SEQUENCE(_3128) && IS_ATOM(_8212)) {
        Ref(_8212);
        Append(&_8213, _3128, _8212);
    }
    else if (IS_ATOM(_3128) && IS_SEQUENCE(_8212)) {
    }
    else {
        Concat((object_ptr)&_8213, _3128, _8212);
    }
    _8212 = NOVALUE;
    EPuts(1, _8213); // DJP 
    DeRefDS(_8213);
    _8213 = NOVALUE;

    /** 			puts(1, '\n')*/
    EPuts(1, 10); // DJP 
    goto L2F; // [1108] 1117
L2E: 

    /** 			puts(1, "One or more additional arguments can be supplied.\n")*/
    EPuts(1, _8214); // DJP 
L2F: 
L2D: 
L2C: 

    /** 	if atom(add_help_rid) then*/
    _8215 = IS_ATOM(_add_help_rid_14408);
    if (_8215 == 0)
    {
        _8215 = NOVALUE;
        goto L30; // [1124] 1152
    }
    else{
        _8215 = NOVALUE;
    }

    /** 		if add_help_rid >= 0 then*/
    if (binary_op_a(LESS, _add_help_rid_14408, 0)){
        goto L31; // [1129] 1260
    }

    /** 			puts(1, "\n")*/
    EPuts(1, _3128); // DJP 

    /** 			call_proc(add_help_rid, {})*/
    _0 = (int)_00[_add_help_rid_14408].addr;
    (*(int (*)())_0)(
                         );

    /** 			puts(1, "\n")*/
    EPuts(1, _3128); // DJP 
    goto L31; // [1149] 1260
L30: 

    /** 		if length(add_help_rid) > 0 then*/
    if (IS_SEQUENCE(_add_help_rid_14408)){
            _8217 = SEQ_PTR(_add_help_rid_14408)->length;
    }
    else {
        _8217 = 1;
    }
    if (_8217 <= 0)
    goto L32; // [1157] 1259

    /** 			puts(1, "\n")*/
    EPuts(1, _3128); // DJP 

    /** 			if types:t_display(add_help_rid) then*/
    Ref(_add_help_rid_14408);
    _8219 = _13t_display(_add_help_rid_14408);
    if (_8219 == 0) {
        DeRef(_8219);
        _8219 = NOVALUE;
        goto L33; // [1172] 1182
    }
    else {
        if (!IS_ATOM_INT(_8219) && DBL_PTR(_8219)->dbl == 0.0){
            DeRef(_8219);
            _8219 = NOVALUE;
            goto L33; // [1172] 1182
        }
        DeRef(_8219);
        _8219 = NOVALUE;
    }
    DeRef(_8219);
    _8219 = NOVALUE;

    /** 				add_help_rid = {add_help_rid}*/
    _0 = _add_help_rid_14408;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_add_help_rid_14408);
    *((int *)(_2+4)) = _add_help_rid_14408;
    _add_help_rid_14408 = MAKE_SEQ(_1);
    DeRef(_0);
L33: 

    /** 			for i = 1 to length(add_help_rid) do*/
    if (IS_SEQUENCE(_add_help_rid_14408)){
            _8221 = SEQ_PTR(_add_help_rid_14408)->length;
    }
    else {
        _8221 = 1;
    }
    {
        int _i_14657;
        _i_14657 = 1;
L34: 
        if (_i_14657 > _8221){
            goto L35; // [1187] 1253
        }

        /** 				puts(1, add_help_rid[i])*/
        _2 = (int)SEQ_PTR(_add_help_rid_14408);
        _8222 = (int)*(((s1_ptr)_2)->base + _i_14657);
        EPuts(1, _8222); // DJP 
        _8222 = NOVALUE;

        /** 				if length(add_help_rid[i]) = 0 or add_help_rid[i][$] != '\n' then*/
        _2 = (int)SEQ_PTR(_add_help_rid_14408);
        _8223 = (int)*(((s1_ptr)_2)->base + _i_14657);
        if (IS_SEQUENCE(_8223)){
                _8224 = SEQ_PTR(_8223)->length;
        }
        else {
            _8224 = 1;
        }
        _8223 = NOVALUE;
        _8225 = (_8224 == 0);
        _8224 = NOVALUE;
        if (_8225 != 0) {
            goto L36; // [1216] 1240
        }
        _2 = (int)SEQ_PTR(_add_help_rid_14408);
        _8227 = (int)*(((s1_ptr)_2)->base + _i_14657);
        if (IS_SEQUENCE(_8227)){
                _8228 = SEQ_PTR(_8227)->length;
        }
        else {
            _8228 = 1;
        }
        _2 = (int)SEQ_PTR(_8227);
        _8229 = (int)*(((s1_ptr)_2)->base + _8228);
        _8227 = NOVALUE;
        if (IS_ATOM_INT(_8229)) {
            _8230 = (_8229 != 10);
        }
        else {
            _8230 = binary_op(NOTEQ, _8229, 10);
        }
        _8229 = NOVALUE;
        if (_8230 == 0) {
            DeRef(_8230);
            _8230 = NOVALUE;
            goto L37; // [1236] 1246
        }
        else {
            if (!IS_ATOM_INT(_8230) && DBL_PTR(_8230)->dbl == 0.0){
                DeRef(_8230);
                _8230 = NOVALUE;
                goto L37; // [1236] 1246
            }
            DeRef(_8230);
            _8230 = NOVALUE;
        }
        DeRef(_8230);
        _8230 = NOVALUE;
L36: 

        /** 					puts(1, '\n')*/
        EPuts(1, 10); // DJP 
L37: 

        /** 			end for*/
        _i_14657 = _i_14657 + 1;
        goto L34; // [1248] 1194
L35: 
        ;
    }

    /** 			puts(1, "\n")*/
    EPuts(1, _3128); // DJP 
L32: 
L31: 

    /** end procedure*/
    DeRefDS(_opts_14407);
    DeRef(_add_help_rid_14408);
    DeRefDS(_cmds_14409);
    DeRef(_parse_options_14412);
    DeRef(_cmd_14415);
    DeRef(_param_name_14416);
    _8072 = NOVALUE;
    _8085 = NOVALUE;
    _8109 = NOVALUE;
    _8140 = NOVALUE;
    _8199 = NOVALUE;
    _8208 = NOVALUE;
    _8223 = NOVALUE;
    DeRef(_8225);
    _8225 = NOVALUE;
    return;
    ;
}


int _4find_opt(int _opts_14678, int _opt_style_14679, int _cmd_text_14680)
{
    int _opt_name_14681 = NOVALUE;
    int _opt_param_14682 = NOVALUE;
    int _param_found_14683 = NOVALUE;
    int _reversed_14684 = NOVALUE;
    int _8332 = NOVALUE;
    int _8330 = NOVALUE;
    int _8329 = NOVALUE;
    int _8327 = NOVALUE;
    int _8326 = NOVALUE;
    int _8325 = NOVALUE;
    int _8324 = NOVALUE;
    int _8323 = NOVALUE;
    int _8320 = NOVALUE;
    int _8319 = NOVALUE;
    int _8318 = NOVALUE;
    int _8316 = NOVALUE;
    int _8315 = NOVALUE;
    int _8314 = NOVALUE;
    int _8313 = NOVALUE;
    int _8311 = NOVALUE;
    int _8310 = NOVALUE;
    int _8309 = NOVALUE;
    int _8308 = NOVALUE;
    int _8307 = NOVALUE;
    int _8306 = NOVALUE;
    int _8305 = NOVALUE;
    int _8304 = NOVALUE;
    int _8303 = NOVALUE;
    int _8302 = NOVALUE;
    int _8301 = NOVALUE;
    int _8300 = NOVALUE;
    int _8294 = NOVALUE;
    int _8293 = NOVALUE;
    int _8292 = NOVALUE;
    int _8284 = NOVALUE;
    int _8283 = NOVALUE;
    int _8281 = NOVALUE;
    int _8279 = NOVALUE;
    int _8278 = NOVALUE;
    int _8276 = NOVALUE;
    int _8275 = NOVALUE;
    int _8274 = NOVALUE;
    int _8273 = NOVALUE;
    int _8272 = NOVALUE;
    int _8270 = NOVALUE;
    int _8269 = NOVALUE;
    int _8267 = NOVALUE;
    int _8265 = NOVALUE;
    int _8264 = NOVALUE;
    int _8262 = NOVALUE;
    int _8261 = NOVALUE;
    int _8260 = NOVALUE;
    int _8259 = NOVALUE;
    int _8257 = NOVALUE;
    int _8256 = NOVALUE;
    int _8253 = NOVALUE;
    int _8251 = NOVALUE;
    int _8250 = NOVALUE;
    int _8248 = NOVALUE;
    int _8246 = NOVALUE;
    int _8244 = NOVALUE;
    int _8243 = NOVALUE;
    int _8241 = NOVALUE;
    int _8240 = NOVALUE;
    int _8239 = NOVALUE;
    int _8238 = NOVALUE;
    int _8237 = NOVALUE;
    int _8235 = NOVALUE;
    int _8234 = NOVALUE;
    int _8232 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer param_found = 0*/
    _param_found_14683 = 0;

    /** 	integer reversed = 0*/
    _reversed_14684 = 0;

    /** 	if length(cmd_text) >= 2 then*/
    if (IS_SEQUENCE(_cmd_text_14680)){
            _8232 = SEQ_PTR(_cmd_text_14680)->length;
    }
    else {
        _8232 = 1;
    }
    if (_8232 < 2)
    goto L1; // [20] 85

    /** 		if cmd_text[1] = '\'' or cmd_text[1] = '"' then*/
    _2 = (int)SEQ_PTR(_cmd_text_14680);
    _8234 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_8234)) {
        _8235 = (_8234 == 39);
    }
    else {
        _8235 = binary_op(EQUALS, _8234, 39);
    }
    _8234 = NOVALUE;
    if (IS_ATOM_INT(_8235)) {
        if (_8235 != 0) {
            goto L2; // [34] 51
        }
    }
    else {
        if (DBL_PTR(_8235)->dbl != 0.0) {
            goto L2; // [34] 51
        }
    }
    _2 = (int)SEQ_PTR(_cmd_text_14680);
    _8237 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_8237)) {
        _8238 = (_8237 == 34);
    }
    else {
        _8238 = binary_op(EQUALS, _8237, 34);
    }
    _8237 = NOVALUE;
    if (_8238 == 0) {
        DeRef(_8238);
        _8238 = NOVALUE;
        goto L3; // [47] 84
    }
    else {
        if (!IS_ATOM_INT(_8238) && DBL_PTR(_8238)->dbl == 0.0){
            DeRef(_8238);
            _8238 = NOVALUE;
            goto L3; // [47] 84
        }
        DeRef(_8238);
        _8238 = NOVALUE;
    }
    DeRef(_8238);
    _8238 = NOVALUE;
L2: 

    /** 			if cmd_text[$] = cmd_text[1] then*/
    if (IS_SEQUENCE(_cmd_text_14680)){
            _8239 = SEQ_PTR(_cmd_text_14680)->length;
    }
    else {
        _8239 = 1;
    }
    _2 = (int)SEQ_PTR(_cmd_text_14680);
    _8240 = (int)*(((s1_ptr)_2)->base + _8239);
    _2 = (int)SEQ_PTR(_cmd_text_14680);
    _8241 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _8240, _8241)){
        _8240 = NOVALUE;
        _8241 = NOVALUE;
        goto L4; // [64] 83
    }
    _8240 = NOVALUE;
    _8241 = NOVALUE;

    /** 				cmd_text = cmd_text[2 .. $-1]*/
    if (IS_SEQUENCE(_cmd_text_14680)){
            _8243 = SEQ_PTR(_cmd_text_14680)->length;
    }
    else {
        _8243 = 1;
    }
    _8244 = _8243 - 1;
    _8243 = NOVALUE;
    rhs_slice_target = (object_ptr)&_cmd_text_14680;
    RHS_Slice(_cmd_text_14680, 2, _8244);
L4: 
L3: 
L1: 

    /** 	if length(cmd_text) > 0 then*/
    if (IS_SEQUENCE(_cmd_text_14680)){
            _8246 = SEQ_PTR(_cmd_text_14680)->length;
    }
    else {
        _8246 = 1;
    }
    if (_8246 <= 0)
    goto L5; // [90] 125

    /** 		if find(cmd_text[1], "!-") then*/
    _2 = (int)SEQ_PTR(_cmd_text_14680);
    _8248 = (int)*(((s1_ptr)_2)->base + 1);
    _8250 = find_from(_8248, _8249, 1);
    _8248 = NOVALUE;
    if (_8250 == 0)
    {
        _8250 = NOVALUE;
        goto L6; // [105] 124
    }
    else{
        _8250 = NOVALUE;
    }

    /** 			reversed = 1*/
    _reversed_14684 = 1;

    /** 			cmd_text = cmd_text[2 .. $]*/
    if (IS_SEQUENCE(_cmd_text_14680)){
            _8251 = SEQ_PTR(_cmd_text_14680)->length;
    }
    else {
        _8251 = 1;
    }
    rhs_slice_target = (object_ptr)&_cmd_text_14680;
    RHS_Slice(_cmd_text_14680, 2, _8251);
L6: 
L5: 

    /** 	if length(cmd_text) < 1 then*/
    if (IS_SEQUENCE(_cmd_text_14680)){
            _8253 = SEQ_PTR(_cmd_text_14680)->length;
    }
    else {
        _8253 = 1;
    }
    if (_8253 >= 1)
    goto L7; // [130] 145

    /** 		return {-1, "Empty command text"}*/
    RefDS(_8255);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -1;
    ((int *)_2)[2] = _8255;
    _8256 = MAKE_SEQ(_1);
    DeRefDS(_opts_14678);
    DeRefDS(_opt_style_14679);
    DeRef(_cmd_text_14680);
    DeRef(_opt_name_14681);
    DeRef(_opt_param_14682);
    DeRef(_8244);
    _8244 = NOVALUE;
    DeRef(_8235);
    _8235 = NOVALUE;
    return _8256;
L7: 

    /** 	opt_name = repeat(' ', length(cmd_text))*/
    if (IS_SEQUENCE(_cmd_text_14680)){
            _8257 = SEQ_PTR(_cmd_text_14680)->length;
    }
    else {
        _8257 = 1;
    }
    DeRef(_opt_name_14681);
    _opt_name_14681 = Repeat(32, _8257);
    _8257 = NOVALUE;

    /** 	opt_param = 0*/
    DeRef(_opt_param_14682);
    _opt_param_14682 = 0;

    /** 	for i = 1 to length(cmd_text) do*/
    if (IS_SEQUENCE(_cmd_text_14680)){
            _8259 = SEQ_PTR(_cmd_text_14680)->length;
    }
    else {
        _8259 = 1;
    }
    {
        int _i_14719;
        _i_14719 = 1;
L8: 
        if (_i_14719 > _8259){
            goto L9; // [164] 320
        }

        /** 		if find(cmd_text[i], ":=") then*/
        _2 = (int)SEQ_PTR(_cmd_text_14680);
        _8260 = (int)*(((s1_ptr)_2)->base + _i_14719);
        _8261 = find_from(_8260, _4703, 1);
        _8260 = NOVALUE;
        if (_8261 == 0)
        {
            _8261 = NOVALUE;
            goto LA; // [182] 302
        }
        else{
            _8261 = NOVALUE;
        }

        /** 			opt_name = opt_name[1 .. i - 1]*/
        _8262 = _i_14719 - 1;
        rhs_slice_target = (object_ptr)&_opt_name_14681;
        RHS_Slice(_opt_name_14681, 1, _8262);

        /** 			opt_param = cmd_text[i + 1 .. $]*/
        _8264 = _i_14719 + 1;
        if (IS_SEQUENCE(_cmd_text_14680)){
                _8265 = SEQ_PTR(_cmd_text_14680)->length;
        }
        else {
            _8265 = 1;
        }
        rhs_slice_target = (object_ptr)&_opt_param_14682;
        RHS_Slice(_cmd_text_14680, _8264, _8265);

        /** 			if length(opt_param) >= 2 then*/
        if (IS_SEQUENCE(_opt_param_14682)){
                _8267 = SEQ_PTR(_opt_param_14682)->length;
        }
        else {
            _8267 = 1;
        }
        if (_8267 < 2)
        goto LB; // [215] 280

        /** 				if opt_param[1] = '\'' or opt_param[1] = '"' then*/
        _2 = (int)SEQ_PTR(_opt_param_14682);
        _8269 = (int)*(((s1_ptr)_2)->base + 1);
        if (IS_ATOM_INT(_8269)) {
            _8270 = (_8269 == 39);
        }
        else {
            _8270 = binary_op(EQUALS, _8269, 39);
        }
        _8269 = NOVALUE;
        if (IS_ATOM_INT(_8270)) {
            if (_8270 != 0) {
                goto LC; // [229] 246
            }
        }
        else {
            if (DBL_PTR(_8270)->dbl != 0.0) {
                goto LC; // [229] 246
            }
        }
        _2 = (int)SEQ_PTR(_opt_param_14682);
        _8272 = (int)*(((s1_ptr)_2)->base + 1);
        if (IS_ATOM_INT(_8272)) {
            _8273 = (_8272 == 34);
        }
        else {
            _8273 = binary_op(EQUALS, _8272, 34);
        }
        _8272 = NOVALUE;
        if (_8273 == 0) {
            DeRef(_8273);
            _8273 = NOVALUE;
            goto LD; // [242] 279
        }
        else {
            if (!IS_ATOM_INT(_8273) && DBL_PTR(_8273)->dbl == 0.0){
                DeRef(_8273);
                _8273 = NOVALUE;
                goto LD; // [242] 279
            }
            DeRef(_8273);
            _8273 = NOVALUE;
        }
        DeRef(_8273);
        _8273 = NOVALUE;
LC: 

        /** 					if opt_param[$] = opt_param[1] then*/
        if (IS_SEQUENCE(_opt_param_14682)){
                _8274 = SEQ_PTR(_opt_param_14682)->length;
        }
        else {
            _8274 = 1;
        }
        _2 = (int)SEQ_PTR(_opt_param_14682);
        _8275 = (int)*(((s1_ptr)_2)->base + _8274);
        _2 = (int)SEQ_PTR(_opt_param_14682);
        _8276 = (int)*(((s1_ptr)_2)->base + 1);
        if (binary_op_a(NOTEQ, _8275, _8276)){
            _8275 = NOVALUE;
            _8276 = NOVALUE;
            goto LE; // [259] 278
        }
        _8275 = NOVALUE;
        _8276 = NOVALUE;

        /** 						opt_param = opt_param[2 .. $-1]*/
        if (IS_SEQUENCE(_opt_param_14682)){
                _8278 = SEQ_PTR(_opt_param_14682)->length;
        }
        else {
            _8278 = 1;
        }
        _8279 = _8278 - 1;
        _8278 = NOVALUE;
        rhs_slice_target = (object_ptr)&_opt_param_14682;
        RHS_Slice(_opt_param_14682, 2, _8279);
LE: 
LD: 
LB: 

        /** 			if length(opt_param) > 0 then*/
        if (IS_SEQUENCE(_opt_param_14682)){
                _8281 = SEQ_PTR(_opt_param_14682)->length;
        }
        else {
            _8281 = 1;
        }
        if (_8281 <= 0)
        goto L9; // [285] 320

        /** 				param_found = 1*/
        _param_found_14683 = 1;

        /** 			exit*/
        goto L9; // [297] 320
        goto LF; // [299] 313
LA: 

        /** 			opt_name[i] = cmd_text[i]*/
        _2 = (int)SEQ_PTR(_cmd_text_14680);
        _8283 = (int)*(((s1_ptr)_2)->base + _i_14719);
        Ref(_8283);
        _2 = (int)SEQ_PTR(_opt_name_14681);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opt_name_14681 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_14719);
        _1 = *(int *)_2;
        *(int *)_2 = _8283;
        if( _1 != _8283 ){
            DeRef(_1);
        }
        _8283 = NOVALUE;
LF: 

        /** 	end for*/
        _i_14719 = _i_14719 + 1;
        goto L8; // [315] 171
L9: 
        ;
    }

    /** 	if param_found then*/
    if (_param_found_14683 == 0)
    {
        goto L10; // [322] 388
    }
    else{
    }

    /** 		if find( text:lower(opt_param), {"1", "on", "yes", "y", "true", "ok", "+"}) then*/
    Ref(_opt_param_14682);
    _8284 = _14lower(_opt_param_14682);
    _1 = NewS1(7);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_8285);
    *((int *)(_2+4)) = _8285;
    RefDS(_8286);
    *((int *)(_2+8)) = _8286;
    RefDS(_8287);
    *((int *)(_2+12)) = _8287;
    RefDS(_8288);
    *((int *)(_2+16)) = _8288;
    RefDS(_8289);
    *((int *)(_2+20)) = _8289;
    RefDS(_8290);
    *((int *)(_2+24)) = _8290;
    RefDS(_8291);
    *((int *)(_2+28)) = _8291;
    _8292 = MAKE_SEQ(_1);
    _8293 = find_from(_8284, _8292, 1);
    DeRef(_8284);
    _8284 = NOVALUE;
    DeRefDS(_8292);
    _8292 = NOVALUE;
    if (_8293 == 0)
    {
        _8293 = NOVALUE;
        goto L11; // [346] 357
    }
    else{
        _8293 = NOVALUE;
    }

    /** 			opt_param = 1*/
    DeRef(_opt_param_14682);
    _opt_param_14682 = 1;
    goto L12; // [354] 387
L11: 

    /** 		elsif find( text:lower(opt_param), {"0", "off", "no", "n", "false", "-"}) then*/
    Ref(_opt_param_14682);
    _8294 = _14lower(_opt_param_14682);
    _1 = NewS1(6);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_8295);
    *((int *)(_2+4)) = _8295;
    RefDS(_8296);
    *((int *)(_2+8)) = _8296;
    RefDS(_8297);
    *((int *)(_2+12)) = _8297;
    RefDS(_8298);
    *((int *)(_2+16)) = _8298;
    RefDS(_8299);
    *((int *)(_2+20)) = _8299;
    RefDS(_7063);
    *((int *)(_2+24)) = _7063;
    _8300 = MAKE_SEQ(_1);
    _8301 = find_from(_8294, _8300, 1);
    DeRef(_8294);
    _8294 = NOVALUE;
    DeRefDS(_8300);
    _8300 = NOVALUE;
    if (_8301 == 0)
    {
        _8301 = NOVALUE;
        goto L13; // [377] 386
    }
    else{
        _8301 = NOVALUE;
    }

    /** 			opt_param = 0*/
    DeRef(_opt_param_14682);
    _opt_param_14682 = 0;
L13: 
L12: 
L10: 

    /** 	for i = 1 to length(opts) do*/
    if (IS_SEQUENCE(_opts_14678)){
            _8302 = SEQ_PTR(_opts_14678)->length;
    }
    else {
        _8302 = 1;
    }
    {
        int _i_14773;
        _i_14773 = 1;
L14: 
        if (_i_14773 > _8302){
            goto L15; // [393] 592
        }

        /** 		if find(NO_CASE,  opts[i][OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opts_14678);
        _8303 = (int)*(((s1_ptr)_2)->base + _i_14773);
        _2 = (int)SEQ_PTR(_8303);
        _8304 = (int)*(((s1_ptr)_2)->base + 4);
        _8303 = NOVALUE;
        _8305 = find_from(105, _8304, 1);
        _8304 = NOVALUE;
        if (_8305 == 0)
        {
            _8305 = NOVALUE;
            goto L16; // [415] 455
        }
        else{
            _8305 = NOVALUE;
        }

        /** 			if not equal( text:lower(opt_name), text:lower(opts[i][opt_style[1]])) then*/
        RefDS(_opt_name_14681);
        _8306 = _14lower(_opt_name_14681);
        _2 = (int)SEQ_PTR(_opts_14678);
        _8307 = (int)*(((s1_ptr)_2)->base + _i_14773);
        _2 = (int)SEQ_PTR(_opt_style_14679);
        _8308 = (int)*(((s1_ptr)_2)->base + 1);
        _2 = (int)SEQ_PTR(_8307);
        if (!IS_ATOM_INT(_8308)){
            _8309 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_8308)->dbl));
        }
        else{
            _8309 = (int)*(((s1_ptr)_2)->base + _8308);
        }
        _8307 = NOVALUE;
        Ref(_8309);
        _8310 = _14lower(_8309);
        _8309 = NOVALUE;
        if (_8306 == _8310)
        _8311 = 1;
        else if (IS_ATOM_INT(_8306) && IS_ATOM_INT(_8310))
        _8311 = 0;
        else
        _8311 = (compare(_8306, _8310) == 0);
        DeRef(_8306);
        _8306 = NOVALUE;
        DeRef(_8310);
        _8310 = NOVALUE;
        if (_8311 != 0)
        goto L17; // [444] 482
        _8311 = NOVALUE;

        /** 				continue*/
        goto L18; // [449] 587
        goto L17; // [452] 482
L16: 

        /** 			if not equal(opt_name, opts[i][opt_style[1]]) then*/
        _2 = (int)SEQ_PTR(_opts_14678);
        _8313 = (int)*(((s1_ptr)_2)->base + _i_14773);
        _2 = (int)SEQ_PTR(_opt_style_14679);
        _8314 = (int)*(((s1_ptr)_2)->base + 1);
        _2 = (int)SEQ_PTR(_8313);
        if (!IS_ATOM_INT(_8314)){
            _8315 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_8314)->dbl));
        }
        else{
            _8315 = (int)*(((s1_ptr)_2)->base + _8314);
        }
        _8313 = NOVALUE;
        if (_opt_name_14681 == _8315)
        _8316 = 1;
        else if (IS_ATOM_INT(_opt_name_14681) && IS_ATOM_INT(_8315))
        _8316 = 0;
        else
        _8316 = (compare(_opt_name_14681, _8315) == 0);
        _8315 = NOVALUE;
        if (_8316 != 0)
        goto L19; // [473] 481
        _8316 = NOVALUE;

        /** 				continue*/
        goto L18; // [478] 587
L19: 
L17: 

        /** 		if find(HAS_PARAMETER,  opts[i][OPTIONS]) = 0 then*/
        _2 = (int)SEQ_PTR(_opts_14678);
        _8318 = (int)*(((s1_ptr)_2)->base + _i_14773);
        _2 = (int)SEQ_PTR(_8318);
        _8319 = (int)*(((s1_ptr)_2)->base + 4);
        _8318 = NOVALUE;
        _8320 = find_from(112, _8319, 1);
        _8319 = NOVALUE;
        if (_8320 != 0)
        goto L1A; // [497] 518

        /** 			if param_found then*/
        if (_param_found_14683 == 0)
        {
            goto L1B; // [503] 517
        }
        else{
        }

        /** 				return {0, "Option should not have a parameter"}*/
        RefDS(_8322);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = 0;
        ((int *)_2)[2] = _8322;
        _8323 = MAKE_SEQ(_1);
        DeRefDS(_opts_14678);
        DeRefDS(_opt_style_14679);
        DeRef(_cmd_text_14680);
        DeRef(_opt_name_14681);
        DeRef(_opt_param_14682);
        DeRef(_8244);
        _8244 = NOVALUE;
        DeRef(_8235);
        _8235 = NOVALUE;
        DeRef(_8256);
        _8256 = NOVALUE;
        DeRef(_8262);
        _8262 = NOVALUE;
        DeRef(_8264);
        _8264 = NOVALUE;
        DeRef(_8279);
        _8279 = NOVALUE;
        DeRef(_8270);
        _8270 = NOVALUE;
        _8314 = NOVALUE;
        _8308 = NOVALUE;
        return _8323;
L1B: 
L1A: 

        /** 		if param_found then*/
        if (_param_found_14683 == 0)
        {
            goto L1C; // [520] 539
        }
        else{
        }

        /** 			return {i, opt_name, reversed, opt_param}*/
        _1 = NewS1(4);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = _i_14773;
        RefDS(_opt_name_14681);
        *((int *)(_2+8)) = _opt_name_14681;
        *((int *)(_2+12)) = _reversed_14684;
        Ref(_opt_param_14682);
        *((int *)(_2+16)) = _opt_param_14682;
        _8324 = MAKE_SEQ(_1);
        DeRefDS(_opts_14678);
        DeRefDS(_opt_style_14679);
        DeRef(_cmd_text_14680);
        DeRefDS(_opt_name_14681);
        DeRef(_opt_param_14682);
        DeRef(_8244);
        _8244 = NOVALUE;
        DeRef(_8235);
        _8235 = NOVALUE;
        DeRef(_8256);
        _8256 = NOVALUE;
        DeRef(_8262);
        _8262 = NOVALUE;
        DeRef(_8264);
        _8264 = NOVALUE;
        DeRef(_8279);
        _8279 = NOVALUE;
        DeRef(_8270);
        _8270 = NOVALUE;
        DeRef(_8323);
        _8323 = NOVALUE;
        _8314 = NOVALUE;
        _8308 = NOVALUE;
        return _8324;
        goto L1D; // [536] 585
L1C: 

        /** 			if find(HAS_PARAMETER, opts[i][OPTIONS]) = 0 then*/
        _2 = (int)SEQ_PTR(_opts_14678);
        _8325 = (int)*(((s1_ptr)_2)->base + _i_14773);
        _2 = (int)SEQ_PTR(_8325);
        _8326 = (int)*(((s1_ptr)_2)->base + 4);
        _8325 = NOVALUE;
        _8327 = find_from(112, _8326, 1);
        _8326 = NOVALUE;
        if (_8327 != 0)
        goto L1E; // [554] 572

        /** 				return {i, opt_name, reversed, 1 }*/
        _1 = NewS1(4);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = _i_14773;
        RefDS(_opt_name_14681);
        *((int *)(_2+8)) = _opt_name_14681;
        *((int *)(_2+12)) = _reversed_14684;
        *((int *)(_2+16)) = 1;
        _8329 = MAKE_SEQ(_1);
        DeRefDS(_opts_14678);
        DeRefDS(_opt_style_14679);
        DeRef(_cmd_text_14680);
        DeRefDS(_opt_name_14681);
        DeRef(_opt_param_14682);
        DeRef(_8244);
        _8244 = NOVALUE;
        DeRef(_8235);
        _8235 = NOVALUE;
        DeRef(_8256);
        _8256 = NOVALUE;
        DeRef(_8262);
        _8262 = NOVALUE;
        DeRef(_8264);
        _8264 = NOVALUE;
        DeRef(_8279);
        _8279 = NOVALUE;
        DeRef(_8270);
        _8270 = NOVALUE;
        DeRef(_8323);
        _8323 = NOVALUE;
        _8314 = NOVALUE;
        _8308 = NOVALUE;
        DeRef(_8324);
        _8324 = NOVALUE;
        return _8329;
L1E: 

        /** 			return {i, opt_name, reversed}*/
        _1 = NewS1(3);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = _i_14773;
        RefDS(_opt_name_14681);
        *((int *)(_2+8)) = _opt_name_14681;
        *((int *)(_2+12)) = _reversed_14684;
        _8330 = MAKE_SEQ(_1);
        DeRefDS(_opts_14678);
        DeRefDS(_opt_style_14679);
        DeRef(_cmd_text_14680);
        DeRefDS(_opt_name_14681);
        DeRef(_opt_param_14682);
        DeRef(_8244);
        _8244 = NOVALUE;
        DeRef(_8235);
        _8235 = NOVALUE;
        DeRef(_8256);
        _8256 = NOVALUE;
        DeRef(_8262);
        _8262 = NOVALUE;
        DeRef(_8264);
        _8264 = NOVALUE;
        DeRef(_8279);
        _8279 = NOVALUE;
        DeRef(_8270);
        _8270 = NOVALUE;
        DeRef(_8323);
        _8323 = NOVALUE;
        _8314 = NOVALUE;
        _8308 = NOVALUE;
        DeRef(_8324);
        _8324 = NOVALUE;
        DeRef(_8329);
        _8329 = NOVALUE;
        return _8330;
L1D: 

        /** 	end for*/
L18: 
        _i_14773 = _i_14773 + 1;
        goto L14; // [587] 400
L15: 
        ;
    }

    /** 	return {0, "Unrecognised"}*/
    RefDS(_8331);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = _8331;
    _8332 = MAKE_SEQ(_1);
    DeRefDS(_opts_14678);
    DeRefDS(_opt_style_14679);
    DeRef(_cmd_text_14680);
    DeRef(_opt_name_14681);
    DeRef(_opt_param_14682);
    DeRef(_8244);
    _8244 = NOVALUE;
    DeRef(_8235);
    _8235 = NOVALUE;
    DeRef(_8256);
    _8256 = NOVALUE;
    DeRef(_8262);
    _8262 = NOVALUE;
    DeRef(_8264);
    _8264 = NOVALUE;
    DeRef(_8279);
    _8279 = NOVALUE;
    DeRef(_8270);
    _8270 = NOVALUE;
    DeRef(_8323);
    _8323 = NOVALUE;
    _8314 = NOVALUE;
    _8308 = NOVALUE;
    DeRef(_8324);
    _8324 = NOVALUE;
    DeRef(_8329);
    _8329 = NOVALUE;
    DeRef(_8330);
    _8330 = NOVALUE;
    return _8332;
    ;
}


int _4cmd_parse(int _opts_14816, int _parse_options_14817, int _cmds_14818)
{
    int _arg_idx_14820 = NOVALUE;
    int _opts_done_14821 = NOVALUE;
    int _cmd_14822 = NOVALUE;
    int _param_14823 = NOVALUE;
    int _find_result_14824 = NOVALUE;
    int _type__14825 = NOVALUE;
    int _from__14826 = NOVALUE;
    int _help_opts_14827 = NOVALUE;
    int _call_count_14828 = NOVALUE;
    int _add_help_rid_14829 = NOVALUE;
    int _validation_14830 = NOVALUE;
    int _has_extra_14831 = NOVALUE;
    int _use_at_14832 = NOVALUE;
    int _auto_help_14833 = NOVALUE;
    int _help_on_error_14834 = NOVALUE;
    int _po_14835 = NOVALUE;
    int _msg_inlined_crash_at_107_14853 = NOVALUE;
    int _msg_inlined_crash_at_237_14870 = NOVALUE;
    int _msg_inlined_crash_at_275_14877 = NOVALUE;
    int _fmt_inlined_crash_at_272_14876 = NOVALUE;
    int _parsed_opts_14882 = NOVALUE;
    int _at_cmds_14929 = NOVALUE;
    int _j_14930 = NOVALUE;
    int _cmdex_15015 = NOVALUE;
    int _opt_15079 = NOVALUE;
    int _map_add_operation_15082 = NOVALUE;
    int _pos_15121 = NOVALUE;
    int _ver_pos_15168 = NOVALUE;
    int _msg_inlined_crash_at_2040_15186 = NOVALUE;
    int _fmt_inlined_crash_at_2037_15185 = NOVALUE;
    int _8614 = NOVALUE;
    int _8613 = NOVALUE;
    int _8612 = NOVALUE;
    int _8609 = NOVALUE;
    int _8608 = NOVALUE;
    int _8607 = NOVALUE;
    int _8604 = NOVALUE;
    int _8603 = NOVALUE;
    int _8602 = NOVALUE;
    int _8601 = NOVALUE;
    int _8600 = NOVALUE;
    int _8599 = NOVALUE;
    int _8598 = NOVALUE;
    int _8597 = NOVALUE;
    int _8596 = NOVALUE;
    int _8595 = NOVALUE;
    int _8594 = NOVALUE;
    int _8593 = NOVALUE;
    int _8592 = NOVALUE;
    int _8591 = NOVALUE;
    int _8590 = NOVALUE;
    int _8589 = NOVALUE;
    int _8586 = NOVALUE;
    int _8585 = NOVALUE;
    int _8584 = NOVALUE;
    int _8581 = NOVALUE;
    int _8580 = NOVALUE;
    int _8578 = NOVALUE;
    int _8577 = NOVALUE;
    int _8576 = NOVALUE;
    int _8575 = NOVALUE;
    int _8574 = NOVALUE;
    int _8573 = NOVALUE;
    int _8572 = NOVALUE;
    int _8571 = NOVALUE;
    int _8569 = NOVALUE;
    int _8568 = NOVALUE;
    int _8566 = NOVALUE;
    int _8565 = NOVALUE;
    int _8564 = NOVALUE;
    int _8563 = NOVALUE;
    int _8562 = NOVALUE;
    int _8561 = NOVALUE;
    int _8560 = NOVALUE;
    int _8559 = NOVALUE;
    int _8557 = NOVALUE;
    int _8556 = NOVALUE;
    int _8555 = NOVALUE;
    int _8553 = NOVALUE;
    int _8551 = NOVALUE;
    int _8550 = NOVALUE;
    int _8549 = NOVALUE;
    int _8548 = NOVALUE;
    int _8547 = NOVALUE;
    int _8546 = NOVALUE;
    int _8545 = NOVALUE;
    int _8544 = NOVALUE;
    int _8543 = NOVALUE;
    int _8540 = NOVALUE;
    int _8537 = NOVALUE;
    int _8536 = NOVALUE;
    int _8534 = NOVALUE;
    int _8533 = NOVALUE;
    int _8532 = NOVALUE;
    int _8531 = NOVALUE;
    int _8530 = NOVALUE;
    int _8529 = NOVALUE;
    int _8528 = NOVALUE;
    int _8527 = NOVALUE;
    int _8526 = NOVALUE;
    int _8525 = NOVALUE;
    int _8524 = NOVALUE;
    int _8521 = NOVALUE;
    int _8518 = NOVALUE;
    int _8516 = NOVALUE;
    int _8515 = NOVALUE;
    int _8513 = NOVALUE;
    int _8512 = NOVALUE;
    int _8511 = NOVALUE;
    int _8509 = NOVALUE;
    int _8508 = NOVALUE;
    int _8507 = NOVALUE;
    int _8505 = NOVALUE;
    int _8503 = NOVALUE;
    int _8501 = NOVALUE;
    int _8499 = NOVALUE;
    int _8498 = NOVALUE;
    int _8497 = NOVALUE;
    int _8496 = NOVALUE;
    int _8495 = NOVALUE;
    int _8491 = NOVALUE;
    int _8489 = NOVALUE;
    int _8488 = NOVALUE;
    int _8487 = NOVALUE;
    int _8486 = NOVALUE;
    int _8485 = NOVALUE;
    int _8484 = NOVALUE;
    int _8482 = NOVALUE;
    int _8481 = NOVALUE;
    int _8480 = NOVALUE;
    int _8479 = NOVALUE;
    int _8478 = NOVALUE;
    int _8477 = NOVALUE;
    int _8476 = NOVALUE;
    int _8472 = NOVALUE;
    int _8471 = NOVALUE;
    int _8468 = NOVALUE;
    int _8467 = NOVALUE;
    int _8466 = NOVALUE;
    int _8465 = NOVALUE;
    int _8464 = NOVALUE;
    int _8463 = NOVALUE;
    int _8462 = NOVALUE;
    int _8461 = NOVALUE;
    int _8460 = NOVALUE;
    int _8459 = NOVALUE;
    int _8458 = NOVALUE;
    int _8457 = NOVALUE;
    int _8456 = NOVALUE;
    int _8455 = NOVALUE;
    int _8454 = NOVALUE;
    int _8453 = NOVALUE;
    int _8452 = NOVALUE;
    int _8451 = NOVALUE;
    int _8450 = NOVALUE;
    int _8449 = NOVALUE;
    int _8448 = NOVALUE;
    int _8447 = NOVALUE;
    int _8446 = NOVALUE;
    int _8445 = NOVALUE;
    int _8444 = NOVALUE;
    int _8443 = NOVALUE;
    int _8442 = NOVALUE;
    int _8441 = NOVALUE;
    int _8440 = NOVALUE;
    int _8439 = NOVALUE;
    int _8438 = NOVALUE;
    int _8437 = NOVALUE;
    int _8434 = NOVALUE;
    int _8433 = NOVALUE;
    int _8432 = NOVALUE;
    int _8431 = NOVALUE;
    int _8430 = NOVALUE;
    int _8428 = NOVALUE;
    int _8427 = NOVALUE;
    int _8424 = NOVALUE;
    int _8423 = NOVALUE;
    int _8422 = NOVALUE;
    int _8421 = NOVALUE;
    int _8420 = NOVALUE;
    int _8418 = NOVALUE;
    int _8417 = NOVALUE;
    int _8416 = NOVALUE;
    int _8415 = NOVALUE;
    int _8412 = NOVALUE;
    int _8410 = NOVALUE;
    int _8409 = NOVALUE;
    int _8408 = NOVALUE;
    int _8406 = NOVALUE;
    int _8404 = NOVALUE;
    int _8403 = NOVALUE;
    int _8400 = NOVALUE;
    int _8398 = NOVALUE;
    int _8397 = NOVALUE;
    int _8396 = NOVALUE;
    int _8395 = NOVALUE;
    int _8394 = NOVALUE;
    int _8393 = NOVALUE;
    int _8392 = NOVALUE;
    int _8391 = NOVALUE;
    int _8390 = NOVALUE;
    int _8389 = NOVALUE;
    int _8387 = NOVALUE;
    int _8383 = NOVALUE;
    int _8381 = NOVALUE;
    int _8380 = NOVALUE;
    int _8379 = NOVALUE;
    int _8376 = NOVALUE;
    int _8375 = NOVALUE;
    int _8374 = NOVALUE;
    int _8372 = NOVALUE;
    int _8371 = NOVALUE;
    int _8370 = NOVALUE;
    int _8369 = NOVALUE;
    int _8368 = NOVALUE;
    int _8366 = NOVALUE;
    int _8365 = NOVALUE;
    int _8364 = NOVALUE;
    int _8363 = NOVALUE;
    int _8362 = NOVALUE;
    int _8361 = NOVALUE;
    int _8360 = NOVALUE;
    int _8359 = NOVALUE;
    int _8358 = NOVALUE;
    int _8355 = NOVALUE;
    int _8352 = NOVALUE;
    int _8351 = NOVALUE;
    int _8345 = NOVALUE;
    int _8341 = NOVALUE;
    int _8338 = NOVALUE;
    int _8336 = NOVALUE;
    int _8334 = NOVALUE;
    int _0, _1, _2;
    

    /** 	object add_help_rid = -1*/
    _add_help_rid_14829 = -1;

    /** 	integer validation = VALIDATE_ALL*/
    _validation_14830 = 2;

    /** 	integer has_extra = 0*/
    _has_extra_14831 = 0;

    /** 	integer use_at = 1*/
    _use_at_14832 = 1;

    /** 	integer auto_help = 1*/
    _auto_help_14833 = 1;

    /** 	integer help_on_error = 1*/
    _help_on_error_14834 = 1;

    /** 	integer po = 1*/
    _po_14835 = 1;

    /** 	if atom(parse_options) then*/
    _8334 = 1;
    if (_8334 == 0)
    {
        _8334 = NOVALUE;
        goto L1; // [45] 55
    }
    else{
        _8334 = NOVALUE;
    }

    /** 		parse_options = {parse_options}*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 10;
    _parse_options_14817 = MAKE_SEQ(_1);
L1: 

    /** 	while po <= length(parse_options) do*/
L2: 
    _8336 = 1;
    if (_po_14835 > 1)
    goto L3; // [63] 308

    /** 		switch parse_options[po] do*/
    _2 = (int)SEQ_PTR(_parse_options_14817);
    _8338 = (int)*(((s1_ptr)_2)->base + _po_14835);
    _0 = _8338;
    _8338 = NOVALUE;
    switch ( _0 ){ 

        /** 			case HELP_RID then*/
        case 1:

        /** 				if po < length(parse_options) then*/
        _8341 = 1;
        if (_po_14835 >= 1)
        goto L4; // [87] 106

        /** 					po += 1*/
        _po_14835 = _po_14835 + 1;

        /** 					add_help_rid = parse_options[po]*/
        _2 = (int)SEQ_PTR(_parse_options_14817);
        _add_help_rid_14829 = (int)*(((s1_ptr)_2)->base + _po_14835);
        goto L5; // [103] 297
L4: 

        /** 					error:crash("HELP_RID was given to cmd_parse with no routine_id")*/

        /** 	msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_107_14853);
        _msg_inlined_crash_at_107_14853 = EPrintf(-9999999, _8053, _5);

        /** 	machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_107_14853);

        /** end procedure*/
        goto L6; // [121] 124
L6: 
        DeRefi(_msg_inlined_crash_at_107_14853);
        _msg_inlined_crash_at_107_14853 = NOVALUE;
        goto L5; // [127] 297

        /** 			case NO_HELP then*/
        case 9:

        /** 				auto_help = 0*/
        _auto_help_14833 = 0;
        goto L5; // [138] 297

        /** 			case NO_HELP_ON_ERROR then*/
        case 10:

        /** 				help_on_error = 0*/
        _help_on_error_14834 = 0;
        goto L5; // [149] 297

        /** 			case VALIDATE_ALL then*/
        case 2:

        /** 				validation = VALIDATE_ALL*/
        _validation_14830 = 2;
        goto L5; // [160] 297

        /** 			case NO_VALIDATION then*/
        case 3:

        /** 				validation = NO_VALIDATION*/
        _validation_14830 = 3;
        goto L5; // [171] 297

        /** 			case NO_VALIDATION_AFTER_FIRST_EXTRA then*/
        case 4:

        /** 				validation = NO_VALIDATION_AFTER_FIRST_EXTRA*/
        _validation_14830 = 4;
        goto L5; // [182] 297

        /** 			case NO_AT_EXPANSION then*/
        case 7:

        /** 				use_at = 0*/
        _use_at_14832 = 0;
        goto L5; // [193] 297

        /** 			case AT_EXPANSION then*/
        case 6:

        /** 				use_at = 1*/
        _use_at_14832 = 1;
        goto L5; // [204] 297

        /** 			case PAUSE_MSG then*/
        case 8:

        /** 				if po < length(parse_options) then*/
        _8345 = 1;
        if (_po_14835 >= 1)
        goto L7; // [215] 236

        /** 					po += 1*/
        _po_14835 = _po_14835 + 1;

        /** 					pause_msg = parse_options[po]*/
        DeRef(_4pause_msg_14130);
        _2 = (int)SEQ_PTR(_parse_options_14817);
        _4pause_msg_14130 = (int)*(((s1_ptr)_2)->base + _po_14835);
        goto L5; // [233] 297
L7: 

        /** 					error:crash("PAUSE_MSG was given to cmd_parse with no actually message text")*/

        /** 	msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_237_14870);
        _msg_inlined_crash_at_237_14870 = EPrintf(-9999999, _8349, _5);

        /** 	machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_237_14870);

        /** end procedure*/
        goto L8; // [251] 254
L8: 
        DeRefi(_msg_inlined_crash_at_237_14870);
        _msg_inlined_crash_at_237_14870 = NOVALUE;
        goto L5; // [257] 297

        /** 			case else*/
        default:

        /** 				error:crash(sprintf("Unrecognised cmdline PARSE OPTION - %d", parse_options[po]) )*/
        _2 = (int)SEQ_PTR(_parse_options_14817);
        _8351 = (int)*(((s1_ptr)_2)->base + _po_14835);
        _8352 = EPrintf(-9999999, _8350, _8351);
        _8351 = NOVALUE;
        DeRefi(_fmt_inlined_crash_at_272_14876);
        _fmt_inlined_crash_at_272_14876 = _8352;
        _8352 = NOVALUE;

        /** 	msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_275_14877);
        _msg_inlined_crash_at_275_14877 = EPrintf(-9999999, _fmt_inlined_crash_at_272_14876, _5);

        /** 	machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_275_14877);

        /** end procedure*/
        goto L9; // [291] 294
L9: 
        DeRefi(_fmt_inlined_crash_at_272_14876);
        _fmt_inlined_crash_at_272_14876 = NOVALUE;
        DeRefi(_msg_inlined_crash_at_275_14877);
        _msg_inlined_crash_at_275_14877 = NOVALUE;
    ;}L5: 

    /** 		po += 1*/
    _po_14835 = _po_14835 + 1;

    /** 	end while*/
    goto L2; // [305] 60
L3: 

    /** 	opts = standardize_opts(opts, auto_help)*/
    RefDS(_opts_14816);
    _0 = _opts_14816;
    _opts_14816 = _4standardize_opts(_opts_14816, _auto_help_14833);
    DeRefDS(_0);

    /** 	call_count = repeat(0, length(opts))*/
    if (IS_SEQUENCE(_opts_14816)){
            _8355 = SEQ_PTR(_opts_14816)->length;
    }
    else {
        _8355 = 1;
    }
    DeRef(_call_count_14828);
    _call_count_14828 = Repeat(0, _8355);
    _8355 = NOVALUE;

    /** 	map:map parsed_opts = map:new()*/
    _0 = _parsed_opts_14882;
    _parsed_opts_14882 = _28new(690);
    DeRef(_0);

    /** 	map:put(parsed_opts, EXTRAS, {})*/
    Ref(_parsed_opts_14882);
    RefDS(_4EXTRAS_14119);
    RefDS(_5);
    _28put(_parsed_opts_14882, _4EXTRAS_14119, _5, 1, 23);

    /** 	help_opts = {}*/
    RefDS(_5);
    DeRef(_help_opts_14827);
    _help_opts_14827 = _5;

    /** 	for i = 1 to length(opts) do*/
    if (IS_SEQUENCE(_opts_14816)){
            _8358 = SEQ_PTR(_opts_14816)->length;
    }
    else {
        _8358 = 1;
    }
    {
        int _i_14885;
        _i_14885 = 1;
LA: 
        if (_i_14885 > _8358){
            goto LB; // [357] 517
        }

        /** 		if find(HELP, opts[i][OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opts_14816);
        _8359 = (int)*(((s1_ptr)_2)->base + _i_14885);
        _2 = (int)SEQ_PTR(_8359);
        _8360 = (int)*(((s1_ptr)_2)->base + 4);
        _8359 = NOVALUE;
        _8361 = find_from(104, _8360, 1);
        _8360 = NOVALUE;
        if (_8361 == 0)
        {
            _8361 = NOVALUE;
            goto LC; // [379] 510
        }
        else{
            _8361 = NOVALUE;
        }

        /** 			if sequence(opts[i][SHORTNAME]) then*/
        _2 = (int)SEQ_PTR(_opts_14816);
        _8362 = (int)*(((s1_ptr)_2)->base + _i_14885);
        _2 = (int)SEQ_PTR(_8362);
        _8363 = (int)*(((s1_ptr)_2)->base + 1);
        _8362 = NOVALUE;
        _8364 = IS_SEQUENCE(_8363);
        _8363 = NOVALUE;
        if (_8364 == 0)
        {
            _8364 = NOVALUE;
            goto LD; // [395] 413
        }
        else{
            _8364 = NOVALUE;
        }

        /** 				help_opts = append(help_opts, opts[i][SHORTNAME])*/
        _2 = (int)SEQ_PTR(_opts_14816);
        _8365 = (int)*(((s1_ptr)_2)->base + _i_14885);
        _2 = (int)SEQ_PTR(_8365);
        _8366 = (int)*(((s1_ptr)_2)->base + 1);
        _8365 = NOVALUE;
        Ref(_8366);
        Append(&_help_opts_14827, _help_opts_14827, _8366);
        _8366 = NOVALUE;
LD: 

        /** 			if sequence(opts[i][LONGNAME]) then*/
        _2 = (int)SEQ_PTR(_opts_14816);
        _8368 = (int)*(((s1_ptr)_2)->base + _i_14885);
        _2 = (int)SEQ_PTR(_8368);
        _8369 = (int)*(((s1_ptr)_2)->base + 2);
        _8368 = NOVALUE;
        _8370 = IS_SEQUENCE(_8369);
        _8369 = NOVALUE;
        if (_8370 == 0)
        {
            _8370 = NOVALUE;
            goto LE; // [426] 444
        }
        else{
            _8370 = NOVALUE;
        }

        /** 				help_opts = append(help_opts, opts[i][LONGNAME])*/
        _2 = (int)SEQ_PTR(_opts_14816);
        _8371 = (int)*(((s1_ptr)_2)->base + _i_14885);
        _2 = (int)SEQ_PTR(_8371);
        _8372 = (int)*(((s1_ptr)_2)->base + 2);
        _8371 = NOVALUE;
        Ref(_8372);
        Append(&_help_opts_14827, _help_opts_14827, _8372);
        _8372 = NOVALUE;
LE: 

        /** 			if find(NO_CASE, opts[i][OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opts_14816);
        _8374 = (int)*(((s1_ptr)_2)->base + _i_14885);
        _2 = (int)SEQ_PTR(_8374);
        _8375 = (int)*(((s1_ptr)_2)->base + 4);
        _8374 = NOVALUE;
        _8376 = find_from(105, _8375, 1);
        _8375 = NOVALUE;
        if (_8376 == 0)
        {
            _8376 = NOVALUE;
            goto LF; // [459] 509
        }
        else{
            _8376 = NOVALUE;
        }

        /** 				help_opts = text:lower(help_opts)*/
        RefDS(_help_opts_14827);
        _0 = _help_opts_14827;
        _help_opts_14827 = _14lower(_help_opts_14827);
        DeRefDS(_0);

        /** 				arg_idx = length(help_opts)*/
        if (IS_SEQUENCE(_help_opts_14827)){
                _arg_idx_14820 = SEQ_PTR(_help_opts_14827)->length;
        }
        else {
            _arg_idx_14820 = 1;
        }

        /** 				for j = 1 to arg_idx do*/
        _8379 = _arg_idx_14820;
        {
            int _j_14912;
            _j_14912 = 1;
L10: 
            if (_j_14912 > _8379){
                goto L11; // [480] 508
            }

            /** 					help_opts = append( help_opts, text:upper(help_opts[j]) )*/
            _2 = (int)SEQ_PTR(_help_opts_14827);
            _8380 = (int)*(((s1_ptr)_2)->base + _j_14912);
            Ref(_8380);
            _8381 = _14upper(_8380);
            _8380 = NOVALUE;
            Ref(_8381);
            Append(&_help_opts_14827, _help_opts_14827, _8381);
            DeRef(_8381);
            _8381 = NOVALUE;

            /** 				end for*/
            _j_14912 = _j_14912 + 1;
            goto L10; // [503] 487
L11: 
            ;
        }
LF: 
LC: 

        /** 	end for*/
        _i_14885 = _i_14885 + 1;
        goto LA; // [512] 364
LB: 
        ;
    }

    /** 	arg_idx = 2*/
    _arg_idx_14820 = 2;

    /** 	opts_done = 0*/
    _opts_done_14821 = 0;

    /** 	while arg_idx < length(cmds) do*/
L12: 
    if (IS_SEQUENCE(_cmds_14818)){
            _8383 = SEQ_PTR(_cmds_14818)->length;
    }
    else {
        _8383 = 1;
    }
    if (_arg_idx_14820 >= _8383)
    goto L13; // [535] 2072

    /** 		arg_idx += 1*/
    _arg_idx_14820 = _arg_idx_14820 + 1;

    /** 		cmd = cmds[arg_idx]*/
    DeRef(_cmd_14822);
    _2 = (int)SEQ_PTR(_cmds_14818);
    _cmd_14822 = (int)*(((s1_ptr)_2)->base + _arg_idx_14820);
    Ref(_cmd_14822);

    /** 		if length(cmd) = 0 then*/
    if (IS_SEQUENCE(_cmd_14822)){
            _8387 = SEQ_PTR(_cmd_14822)->length;
    }
    else {
        _8387 = 1;
    }
    if (_8387 != 0)
    goto L14; // [558] 567

    /** 			continue*/
    goto L12; // [564] 532
L14: 

    /** 		if cmd[1] = '@' and use_at then*/
    _2 = (int)SEQ_PTR(_cmd_14822);
    _8389 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_8389)) {
        _8390 = (_8389 == 64);
    }
    else {
        _8390 = binary_op(EQUALS, _8389, 64);
    }
    _8389 = NOVALUE;
    if (IS_ATOM_INT(_8390)) {
        if (_8390 == 0) {
            goto L15; // [577] 1095
        }
    }
    else {
        if (DBL_PTR(_8390)->dbl == 0.0) {
            goto L15; // [577] 1095
        }
    }
    if (_use_at_14832 == 0)
    {
        goto L15; // [582] 1095
    }
    else{
    }

    /** 			object at_cmds*/

    /** 			integer j*/

    /** 			if length(cmd) > 2 and cmd[2] = '@' then*/
    if (IS_SEQUENCE(_cmd_14822)){
            _8392 = SEQ_PTR(_cmd_14822)->length;
    }
    else {
        _8392 = 1;
    }
    _8393 = (_8392 > 2);
    _8392 = NOVALUE;
    if (_8393 == 0) {
        goto L16; // [598] 660
    }
    _2 = (int)SEQ_PTR(_cmd_14822);
    _8395 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_8395)) {
        _8396 = (_8395 == 64);
    }
    else {
        _8396 = binary_op(EQUALS, _8395, 64);
    }
    _8395 = NOVALUE;
    if (_8396 == 0) {
        DeRef(_8396);
        _8396 = NOVALUE;
        goto L16; // [611] 660
    }
    else {
        if (!IS_ATOM_INT(_8396) && DBL_PTR(_8396)->dbl == 0.0){
            DeRef(_8396);
            _8396 = NOVALUE;
            goto L16; // [611] 660
        }
        DeRef(_8396);
        _8396 = NOVALUE;
    }
    DeRef(_8396);
    _8396 = NOVALUE;

    /** 				at_cmds = io:read_lines(cmd[3..$])*/
    if (IS_SEQUENCE(_cmd_14822)){
            _8397 = SEQ_PTR(_cmd_14822)->length;
    }
    else {
        _8397 = 1;
    }
    rhs_slice_target = (object_ptr)&_8398;
    RHS_Slice(_cmd_14822, 3, _8397);
    _0 = _at_cmds_14929;
    _at_cmds_14929 = _8read_lines(_8398);
    DeRef(_0);
    _8398 = NOVALUE;

    /** 				if equal(at_cmds, -1) then*/
    if (_at_cmds_14929 == -1)
    _8400 = 1;
    else if (IS_ATOM_INT(_at_cmds_14929) && IS_ATOM_INT(-1))
    _8400 = 0;
    else
    _8400 = (compare(_at_cmds_14929, -1) == 0);
    if (_8400 == 0)
    {
        _8400 = NOVALUE;
        goto L17; // [634] 738
    }
    else{
        _8400 = NOVALUE;
    }

    /** 					cmds = eu:remove(cmds, arg_idx)*/
    {
        s1_ptr assign_space = SEQ_PTR(_cmds_14818);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_arg_idx_14820)) ? _arg_idx_14820 : (long)(DBL_PTR(_arg_idx_14820)->dbl);
        int stop = (IS_ATOM_INT(_arg_idx_14820)) ? _arg_idx_14820 : (long)(DBL_PTR(_arg_idx_14820)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_cmds_14818), start, &_cmds_14818 );
            }
            else Tail(SEQ_PTR(_cmds_14818), stop+1, &_cmds_14818);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_cmds_14818), start, &_cmds_14818);
        }
        else {
            assign_slice_seq = &assign_space;
            _cmds_14818 = Remove_elements(start, stop, (SEQ_PTR(_cmds_14818)->ref == 1));
        }
    }

    /** 					arg_idx -= 1*/
    _arg_idx_14820 = _arg_idx_14820 - 1;

    /** 					continue*/
    DeRef(_at_cmds_14929);
    _at_cmds_14929 = NOVALUE;
    goto L12; // [654] 532
    goto L17; // [657] 738
L16: 

    /** 				at_cmds = io:read_lines(cmd[2..$])*/
    if (IS_SEQUENCE(_cmd_14822)){
            _8403 = SEQ_PTR(_cmd_14822)->length;
    }
    else {
        _8403 = 1;
    }
    rhs_slice_target = (object_ptr)&_8404;
    RHS_Slice(_cmd_14822, 2, _8403);
    _0 = _at_cmds_14929;
    _at_cmds_14929 = _8read_lines(_8404);
    DeRef(_0);
    _8404 = NOVALUE;

    /** 				if equal(at_cmds, -1) then*/
    if (_at_cmds_14929 == -1)
    _8406 = 1;
    else if (IS_ATOM_INT(_at_cmds_14929) && IS_ATOM_INT(-1))
    _8406 = 0;
    else
    _8406 = (compare(_at_cmds_14929, -1) == 0);
    if (_8406 == 0)
    {
        _8406 = NOVALUE;
        goto L18; // [680] 737
    }
    else{
        _8406 = NOVALUE;
    }

    /** 					printf(2, "Cannot access '@' argument file '%s'\n", {cmd[2..$]})*/
    if (IS_SEQUENCE(_cmd_14822)){
            _8408 = SEQ_PTR(_cmd_14822)->length;
    }
    else {
        _8408 = 1;
    }
    rhs_slice_target = (object_ptr)&_8409;
    RHS_Slice(_cmd_14822, 2, _8408);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _8409;
    _8410 = MAKE_SEQ(_1);
    _8409 = NOVALUE;
    EPrintf(2, _8407, _8410);
    DeRefDS(_8410);
    _8410 = NOVALUE;

    /** 					if help_on_error then*/
    if (_help_on_error_14834 == 0)
    {
        goto L19; // [703] 718
    }
    else{
    }

    /** 						local_help(opts, add_help_rid, cmds, 1, parse_options)*/
    RefDS(_opts_14816);
    RefDS(_cmds_14818);
    Ref(_parse_options_14817);
    _4local_help(_opts_14816, _add_help_rid_14829, _cmds_14818, 1, _parse_options_14817);
    goto L1A; // [715] 731
L19: 

    /** 					elsif auto_help then*/
    if (_auto_help_14833 == 0)
    {
        goto L1B; // [720] 730
    }
    else{
    }

    /** 						printf(2,"Try '--help' for more information.\n",{})*/
    EPrintf(2, _8411, _5);
L1B: 
L1A: 

    /** 					local_abort(1)*/
    _4local_abort(1);
L18: 
L17: 

    /** 			j = 0*/
    _j_14930 = 0;

    /** 			while j < length(at_cmds) do*/
L1C: 
    if (IS_SEQUENCE(_at_cmds_14929)){
            _8412 = SEQ_PTR(_at_cmds_14929)->length;
    }
    else {
        _8412 = 1;
    }
    if (_j_14930 >= _8412)
    goto L1D; // [753] 1074

    /** 				j += 1*/
    _j_14930 = _j_14930 + 1;

    /** 				at_cmds[j] = text:trim(at_cmds[j])*/
    _2 = (int)SEQ_PTR(_at_cmds_14929);
    _8415 = (int)*(((s1_ptr)_2)->base + _j_14930);
    Ref(_8415);
    RefDS(_3890);
    _8416 = _14trim(_8415, _3890, 0);
    _8415 = NOVALUE;
    _2 = (int)SEQ_PTR(_at_cmds_14929);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _at_cmds_14929 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _j_14930);
    _1 = *(int *)_2;
    *(int *)_2 = _8416;
    if( _1 != _8416 ){
        DeRef(_1);
    }
    _8416 = NOVALUE;

    /** 				if length(at_cmds[j]) = 0 then*/
    _2 = (int)SEQ_PTR(_at_cmds_14929);
    _8417 = (int)*(((s1_ptr)_2)->base + _j_14930);
    if (IS_SEQUENCE(_8417)){
            _8418 = SEQ_PTR(_8417)->length;
    }
    else {
        _8418 = 1;
    }
    _8417 = NOVALUE;
    if (_8418 != 0)
    goto L1E; // [788] 828

    /** 					at_cmds = at_cmds[1 .. j-1] & at_cmds[j+1 ..$]*/
    _8420 = _j_14930 - 1;
    rhs_slice_target = (object_ptr)&_8421;
    RHS_Slice(_at_cmds_14929, 1, _8420);
    _8422 = _j_14930 + 1;
    if (_8422 > MAXINT){
        _8422 = NewDouble((double)_8422);
    }
    if (IS_SEQUENCE(_at_cmds_14929)){
            _8423 = SEQ_PTR(_at_cmds_14929)->length;
    }
    else {
        _8423 = 1;
    }
    rhs_slice_target = (object_ptr)&_8424;
    RHS_Slice(_at_cmds_14929, _8422, _8423);
    Concat((object_ptr)&_at_cmds_14929, _8421, _8424);
    DeRefDS(_8421);
    _8421 = NOVALUE;
    DeRef(_8421);
    _8421 = NOVALUE;
    DeRefDS(_8424);
    _8424 = NOVALUE;

    /** 					j -= 1*/
    _j_14930 = _j_14930 - 1;
    goto L1C; // [825] 748
L1E: 

    /** 				elsif at_cmds[j][1] = '#' then*/
    _2 = (int)SEQ_PTR(_at_cmds_14929);
    _8427 = (int)*(((s1_ptr)_2)->base + _j_14930);
    _2 = (int)SEQ_PTR(_8427);
    _8428 = (int)*(((s1_ptr)_2)->base + 1);
    _8427 = NOVALUE;
    if (binary_op_a(NOTEQ, _8428, 35)){
        _8428 = NOVALUE;
        goto L1F; // [838] 878
    }
    _8428 = NOVALUE;

    /** 					at_cmds = at_cmds[1 .. j-1] & at_cmds[j+1 ..$]*/
    _8430 = _j_14930 - 1;
    rhs_slice_target = (object_ptr)&_8431;
    RHS_Slice(_at_cmds_14929, 1, _8430);
    _8432 = _j_14930 + 1;
    if (_8432 > MAXINT){
        _8432 = NewDouble((double)_8432);
    }
    if (IS_SEQUENCE(_at_cmds_14929)){
            _8433 = SEQ_PTR(_at_cmds_14929)->length;
    }
    else {
        _8433 = 1;
    }
    rhs_slice_target = (object_ptr)&_8434;
    RHS_Slice(_at_cmds_14929, _8432, _8433);
    Concat((object_ptr)&_at_cmds_14929, _8431, _8434);
    DeRefDS(_8431);
    _8431 = NOVALUE;
    DeRef(_8431);
    _8431 = NOVALUE;
    DeRefDS(_8434);
    _8434 = NOVALUE;

    /** 					j -= 1*/
    _j_14930 = _j_14930 - 1;
    goto L1C; // [875] 748
L1F: 

    /** 				elsif at_cmds[j][1] = '"' and at_cmds[j][$] = '"' and length(at_cmds[j]) >= 2 then*/
    _2 = (int)SEQ_PTR(_at_cmds_14929);
    _8437 = (int)*(((s1_ptr)_2)->base + _j_14930);
    _2 = (int)SEQ_PTR(_8437);
    _8438 = (int)*(((s1_ptr)_2)->base + 1);
    _8437 = NOVALUE;
    if (IS_ATOM_INT(_8438)) {
        _8439 = (_8438 == 34);
    }
    else {
        _8439 = binary_op(EQUALS, _8438, 34);
    }
    _8438 = NOVALUE;
    if (IS_ATOM_INT(_8439)) {
        if (_8439 == 0) {
            DeRef(_8440);
            _8440 = 0;
            goto L20; // [892] 915
        }
    }
    else {
        if (DBL_PTR(_8439)->dbl == 0.0) {
            DeRef(_8440);
            _8440 = 0;
            goto L20; // [892] 915
        }
    }
    _2 = (int)SEQ_PTR(_at_cmds_14929);
    _8441 = (int)*(((s1_ptr)_2)->base + _j_14930);
    if (IS_SEQUENCE(_8441)){
            _8442 = SEQ_PTR(_8441)->length;
    }
    else {
        _8442 = 1;
    }
    _2 = (int)SEQ_PTR(_8441);
    _8443 = (int)*(((s1_ptr)_2)->base + _8442);
    _8441 = NOVALUE;
    if (IS_ATOM_INT(_8443)) {
        _8444 = (_8443 == 34);
    }
    else {
        _8444 = binary_op(EQUALS, _8443, 34);
    }
    _8443 = NOVALUE;
    DeRef(_8440);
    if (IS_ATOM_INT(_8444))
    _8440 = (_8444 != 0);
    else
    _8440 = DBL_PTR(_8444)->dbl != 0.0;
L20: 
    if (_8440 == 0) {
        goto L21; // [915] 959
    }
    _2 = (int)SEQ_PTR(_at_cmds_14929);
    _8446 = (int)*(((s1_ptr)_2)->base + _j_14930);
    if (IS_SEQUENCE(_8446)){
            _8447 = SEQ_PTR(_8446)->length;
    }
    else {
        _8447 = 1;
    }
    _8446 = NOVALUE;
    _8448 = (_8447 >= 2);
    _8447 = NOVALUE;
    if (_8448 == 0)
    {
        DeRef(_8448);
        _8448 = NOVALUE;
        goto L21; // [931] 959
    }
    else{
        DeRef(_8448);
        _8448 = NOVALUE;
    }

    /** 					at_cmds[j] = at_cmds[j][2 .. $-1]*/
    _2 = (int)SEQ_PTR(_at_cmds_14929);
    _8449 = (int)*(((s1_ptr)_2)->base + _j_14930);
    if (IS_SEQUENCE(_8449)){
            _8450 = SEQ_PTR(_8449)->length;
    }
    else {
        _8450 = 1;
    }
    _8451 = _8450 - 1;
    _8450 = NOVALUE;
    rhs_slice_target = (object_ptr)&_8452;
    RHS_Slice(_8449, 2, _8451);
    _8449 = NOVALUE;
    _2 = (int)SEQ_PTR(_at_cmds_14929);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _at_cmds_14929 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _j_14930);
    _1 = *(int *)_2;
    *(int *)_2 = _8452;
    if( _1 != _8452 ){
        DeRef(_1);
    }
    _8452 = NOVALUE;
    goto L1C; // [956] 748
L21: 

    /** 				elsif at_cmds[j][1] = '\'' and at_cmds[j][$] = '\'' and length(at_cmds[j]) >= 2 then*/
    _2 = (int)SEQ_PTR(_at_cmds_14929);
    _8453 = (int)*(((s1_ptr)_2)->base + _j_14930);
    _2 = (int)SEQ_PTR(_8453);
    _8454 = (int)*(((s1_ptr)_2)->base + 1);
    _8453 = NOVALUE;
    if (IS_ATOM_INT(_8454)) {
        _8455 = (_8454 == 39);
    }
    else {
        _8455 = binary_op(EQUALS, _8454, 39);
    }
    _8454 = NOVALUE;
    if (IS_ATOM_INT(_8455)) {
        if (_8455 == 0) {
            DeRef(_8456);
            _8456 = 0;
            goto L22; // [973] 996
        }
    }
    else {
        if (DBL_PTR(_8455)->dbl == 0.0) {
            DeRef(_8456);
            _8456 = 0;
            goto L22; // [973] 996
        }
    }
    _2 = (int)SEQ_PTR(_at_cmds_14929);
    _8457 = (int)*(((s1_ptr)_2)->base + _j_14930);
    if (IS_SEQUENCE(_8457)){
            _8458 = SEQ_PTR(_8457)->length;
    }
    else {
        _8458 = 1;
    }
    _2 = (int)SEQ_PTR(_8457);
    _8459 = (int)*(((s1_ptr)_2)->base + _8458);
    _8457 = NOVALUE;
    if (IS_ATOM_INT(_8459)) {
        _8460 = (_8459 == 39);
    }
    else {
        _8460 = binary_op(EQUALS, _8459, 39);
    }
    _8459 = NOVALUE;
    DeRef(_8456);
    if (IS_ATOM_INT(_8460))
    _8456 = (_8460 != 0);
    else
    _8456 = DBL_PTR(_8460)->dbl != 0.0;
L22: 
    if (_8456 == 0) {
        goto L23; // [996] 1066
    }
    _2 = (int)SEQ_PTR(_at_cmds_14929);
    _8462 = (int)*(((s1_ptr)_2)->base + _j_14930);
    if (IS_SEQUENCE(_8462)){
            _8463 = SEQ_PTR(_8462)->length;
    }
    else {
        _8463 = 1;
    }
    _8462 = NOVALUE;
    _8464 = (_8463 >= 2);
    _8463 = NOVALUE;
    if (_8464 == 0)
    {
        DeRef(_8464);
        _8464 = NOVALUE;
        goto L23; // [1012] 1066
    }
    else{
        DeRef(_8464);
        _8464 = NOVALUE;
    }

    /** 					sequence cmdex = stdseq:split(at_cmds[j][2 .. $-1],' ', 1) -- Empty words removed.*/
    _2 = (int)SEQ_PTR(_at_cmds_14929);
    _8465 = (int)*(((s1_ptr)_2)->base + _j_14930);
    if (IS_SEQUENCE(_8465)){
            _8466 = SEQ_PTR(_8465)->length;
    }
    else {
        _8466 = 1;
    }
    _8467 = _8466 - 1;
    _8466 = NOVALUE;
    rhs_slice_target = (object_ptr)&_8468;
    RHS_Slice(_8465, 2, _8467);
    _8465 = NOVALUE;
    _0 = _cmdex_15015;
    _cmdex_15015 = _23split(_8468, 32, 1, 0);
    DeRef(_0);
    _8468 = NOVALUE;

    /** 					at_cmds = replace(at_cmds, cmdex, j)*/
    {
        int p1 = _at_cmds_14929;
        int p2 = _cmdex_15015;
        int p3 = _j_14930;
        int p4 = _j_14930;
        struct replace_block replace_params;
        replace_params.copy_to   = &p1;
        replace_params.copy_from = &p2;
        replace_params.start     = &p3;
        replace_params.stop      = &p4;
        replace_params.target    = &_at_cmds_14929;
        Replace( &replace_params );
    }

    /** 					j = j + length(cmdex) - 1*/
    if (IS_SEQUENCE(_cmdex_15015)){
            _8471 = SEQ_PTR(_cmdex_15015)->length;
    }
    else {
        _8471 = 1;
    }
    _8472 = _j_14930 + _8471;
    if ((long)((unsigned long)_8472 + (unsigned long)HIGH_BITS) >= 0) 
    _8472 = NewDouble((double)_8472);
    _8471 = NOVALUE;
    if (IS_ATOM_INT(_8472)) {
        _j_14930 = _8472 - 1;
    }
    else {
        _j_14930 = NewDouble(DBL_PTR(_8472)->dbl - (double)1);
    }
    DeRef(_8472);
    _8472 = NOVALUE;
    if (!IS_ATOM_INT(_j_14930)) {
        _1 = (long)(DBL_PTR(_j_14930)->dbl);
        DeRefDS(_j_14930);
        _j_14930 = _1;
    }
L23: 
    DeRef(_cmdex_15015);
    _cmdex_15015 = NOVALUE;

    /** 			end while*/
    goto L1C; // [1071] 748
L1D: 

    /** 			cmds = replace(cmds, at_cmds, arg_idx)*/
    {
        int p1 = _cmds_14818;
        int p2 = _at_cmds_14929;
        int p3 = _arg_idx_14820;
        int p4 = _arg_idx_14820;
        struct replace_block replace_params;
        replace_params.copy_to   = &p1;
        replace_params.copy_from = &p2;
        replace_params.start     = &p3;
        replace_params.stop      = &p4;
        replace_params.target    = &_cmds_14818;
        Replace( &replace_params );
    }

    /** 			arg_idx -= 1*/
    _arg_idx_14820 = _arg_idx_14820 - 1;

    /** 			continue*/
    DeRef(_at_cmds_14929);
    _at_cmds_14929 = NOVALUE;
    goto L12; // [1092] 532
L15: 
    DeRef(_at_cmds_14929);
    _at_cmds_14929 = NOVALUE;

    /** 		if (opts_done or find(cmd[1], os:CMD_SWITCHES) = 0 or length(cmd) = 1)*/
    if (_opts_done_14821 != 0) {
        _8476 = 1;
        goto L24; // [1099] 1120
    }
    _2 = (int)SEQ_PTR(_cmd_14822);
    _8477 = (int)*(((s1_ptr)_2)->base + 1);
    _8478 = find_from(_8477, _34CMD_SWITCHES_13912, 1);
    _8477 = NOVALUE;
    _8479 = (_8478 == 0);
    _8478 = NOVALUE;
    _8476 = (_8479 != 0);
L24: 
    if (_8476 != 0) {
        DeRef(_8480);
        _8480 = 1;
        goto L25; // [1120] 1135
    }
    if (IS_SEQUENCE(_cmd_14822)){
            _8481 = SEQ_PTR(_cmd_14822)->length;
    }
    else {
        _8481 = 1;
    }
    _8482 = (_8481 == 1);
    _8481 = NOVALUE;
    _8480 = (_8482 != 0);
L25: 
    if (_8480 == 0)
    {
        _8480 = NOVALUE;
        goto L26; // [1135] 1215
    }
    else{
        _8480 = NOVALUE;
    }

    /** 			map:put(parsed_opts, EXTRAS, cmd, map:APPEND)*/
    Ref(_parsed_opts_14882);
    RefDS(_4EXTRAS_14119);
    RefDS(_cmd_14822);
    _28put(_parsed_opts_14882, _4EXTRAS_14119, _cmd_14822, 6, 23);

    /** 			has_extra = 1*/
    _has_extra_14831 = 1;

    /** 			if validation = NO_VALIDATION_AFTER_FIRST_EXTRA then*/
    if (_validation_14830 != 4)
    goto L12; // [1158] 532

    /** 				for i = arg_idx + 1 to length(cmds) do*/
    _8484 = _arg_idx_14820 + 1;
    if (_8484 > MAXINT){
        _8484 = NewDouble((double)_8484);
    }
    if (IS_SEQUENCE(_cmds_14818)){
            _8485 = SEQ_PTR(_cmds_14818)->length;
    }
    else {
        _8485 = 1;
    }
    {
        int _i_15038;
        Ref(_8484);
        _i_15038 = _8484;
L27: 
        if (binary_op_a(GREATER, _i_15038, _8485)){
            goto L28; // [1171] 1202
        }

        /** 					map:put(parsed_opts, EXTRAS, cmds[i], map:APPEND)*/
        _2 = (int)SEQ_PTR(_cmds_14818);
        if (!IS_ATOM_INT(_i_15038)){
            _8486 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_15038)->dbl));
        }
        else{
            _8486 = (int)*(((s1_ptr)_2)->base + _i_15038);
        }
        Ref(_parsed_opts_14882);
        RefDS(_4EXTRAS_14119);
        Ref(_8486);
        _28put(_parsed_opts_14882, _4EXTRAS_14119, _8486, 6, 23);
        _8486 = NOVALUE;

        /** 				end for*/
        _0 = _i_15038;
        if (IS_ATOM_INT(_i_15038)) {
            _i_15038 = _i_15038 + 1;
            if ((long)((unsigned long)_i_15038 +(unsigned long) HIGH_BITS) >= 0){
                _i_15038 = NewDouble((double)_i_15038);
            }
        }
        else {
            _i_15038 = binary_op_a(PLUS, _i_15038, 1);
        }
        DeRef(_0);
        goto L27; // [1197] 1178
L28: 
        ;
        DeRef(_i_15038);
    }

    /** 				exit*/
    goto L13; // [1204] 2072
    goto L29; // [1206] 1214

    /** 				continue*/
    goto L12; // [1211] 532
L29: 
L26: 

    /** 		if equal(cmd, "--") then*/
    if (_cmd_14822 == _7087)
    _8487 = 1;
    else if (IS_ATOM_INT(_cmd_14822) && IS_ATOM_INT(_7087))
    _8487 = 0;
    else
    _8487 = (compare(_cmd_14822, _7087) == 0);
    if (_8487 == 0)
    {
        _8487 = NOVALUE;
        goto L2A; // [1221] 1234
    }
    else{
        _8487 = NOVALUE;
    }

    /** 			opts_done = 1*/
    _opts_done_14821 = 1;

    /** 			continue*/
    goto L12; // [1231] 532
L2A: 

    /** 		if equal(cmd[1..2], "--") then	  -- found --opt-name*/
    rhs_slice_target = (object_ptr)&_8488;
    RHS_Slice(_cmd_14822, 1, 2);
    if (_8488 == _7087)
    _8489 = 1;
    else if (IS_ATOM_INT(_8488) && IS_ATOM_INT(_7087))
    _8489 = 0;
    else
    _8489 = (compare(_8488, _7087) == 0);
    DeRefDS(_8488);
    _8488 = NOVALUE;
    if (_8489 == 0)
    {
        _8489 = NOVALUE;
        goto L2B; // [1245] 1262
    }
    else{
        _8489 = NOVALUE;
    }

    /** 			type_ = {LONGNAME, "--"}*/
    RefDS(_7087);
    DeRef(_type__14825);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 2;
    ((int *)_2)[2] = _7087;
    _type__14825 = MAKE_SEQ(_1);

    /** 			from_ = 3*/
    _from__14826 = 3;
    goto L2C; // [1259] 1298
L2B: 

    /** 		elsif cmd[1] = '-' then -- found -opt*/
    _2 = (int)SEQ_PTR(_cmd_14822);
    _8491 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _8491, 45)){
        _8491 = NOVALUE;
        goto L2D; // [1268] 1286
    }
    _8491 = NOVALUE;

    /** 			type_ = {SHORTNAME, "-"}*/
    RefDS(_7063);
    DeRef(_type__14825);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = _7063;
    _type__14825 = MAKE_SEQ(_1);

    /** 			from_ = 2*/
    _from__14826 = 2;
    goto L2C; // [1283] 1298
L2D: 

    /** 			type_ = {SHORTNAME, "/"}*/
    RefDS(_3127);
    DeRef(_type__14825);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = _3127;
    _type__14825 = MAKE_SEQ(_1);

    /** 			from_ = 2*/
    _from__14826 = 2;
L2C: 

    /** 		if find(cmd[from_..$], help_opts) then*/
    if (IS_SEQUENCE(_cmd_14822)){
            _8495 = SEQ_PTR(_cmd_14822)->length;
    }
    else {
        _8495 = 1;
    }
    rhs_slice_target = (object_ptr)&_8496;
    RHS_Slice(_cmd_14822, _from__14826, _8495);
    _8497 = find_from(_8496, _help_opts_14827, 1);
    DeRefDS(_8496);
    _8496 = NOVALUE;
    if (_8497 == 0)
    {
        _8497 = NOVALUE;
        goto L2E; // [1315] 1335
    }
    else{
        _8497 = NOVALUE;
    }

    /** 				local_help(opts, add_help_rid, cmds, 1, parse_options)*/
    RefDS(_opts_14816);
    RefDS(_cmds_14818);
    Ref(_parse_options_14817);
    _4local_help(_opts_14816, _add_help_rid_14829, _cmds_14818, 1, _parse_options_14817);

    /** 			ifdef UNITTEST then*/

    /** 			local_abort(0)*/
    _4local_abort(0);
L2E: 

    /** 		find_result = find_opt(opts, type_, cmd[from_..$])*/
    if (IS_SEQUENCE(_cmd_14822)){
            _8498 = SEQ_PTR(_cmd_14822)->length;
    }
    else {
        _8498 = 1;
    }
    rhs_slice_target = (object_ptr)&_8499;
    RHS_Slice(_cmd_14822, _from__14826, _8498);
    RefDS(_opts_14816);
    RefDS(_type__14825);
    _0 = _find_result_14824;
    _find_result_14824 = _4find_opt(_opts_14816, _type__14825, _8499);
    DeRef(_0);
    _8499 = NOVALUE;

    /** 		if find_result[1] < 0 then*/
    _2 = (int)SEQ_PTR(_find_result_14824);
    _8501 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(GREATEREQ, _8501, 0)){
        _8501 = NOVALUE;
        goto L2F; // [1361] 1370
    }
    _8501 = NOVALUE;

    /** 			continue -- Couldn't use this command argument for anything.*/
    goto L12; // [1367] 532
L2F: 

    /** 		if find_result[1] = 0 then*/
    _2 = (int)SEQ_PTR(_find_result_14824);
    _8503 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _8503, 0)){
        _8503 = NOVALUE;
        goto L30; // [1376] 1471
    }
    _8503 = NOVALUE;

    /** 			if validation = VALIDATE_ALL or*/
    _8505 = (_validation_14830 == 2);
    if (_8505 != 0) {
        goto L31; // [1386] 1411
    }
    _8507 = (_validation_14830 == 4);
    if (_8507 == 0) {
        DeRef(_8508);
        _8508 = 0;
        goto L32; // [1394] 1406
    }
    _8509 = (_has_extra_14831 == 0);
    _8508 = (_8509 != 0);
L32: 
    if (_8508 == 0)
    {
        _8508 = NOVALUE;
        goto L12; // [1407] 532
    }
    else{
        _8508 = NOVALUE;
    }
L31: 

    /** 				printf(1, "option '%s': %s\n", {cmd, find_result[2]})*/
    _2 = (int)SEQ_PTR(_find_result_14824);
    _8511 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_8511);
    RefDS(_cmd_14822);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _cmd_14822;
    ((int *)_2)[2] = _8511;
    _8512 = MAKE_SEQ(_1);
    _8511 = NOVALUE;
    EPrintf(1, _8510, _8512);
    DeRefDS(_8512);
    _8512 = NOVALUE;

    /** 				if help_on_error then*/
    if (_help_on_error_14834 == 0)
    {
        goto L33; // [1427] 1447
    }
    else{
    }

    /** 					puts(2,10)*/
    EPuts(2, 10); // DJP 

    /** 					local_help(opts, add_help_rid, cmds, 1, parse_options)*/
    RefDS(_opts_14816);
    RefDS(_cmds_14818);
    Ref(_parse_options_14817);
    _4local_help(_opts_14816, _add_help_rid_14829, _cmds_14818, 1, _parse_options_14817);
    goto L34; // [1444] 1460
L33: 

    /** 				elsif auto_help then*/
    if (_auto_help_14833 == 0)
    {
        goto L35; // [1449] 1459
    }
    else{
    }

    /** 					printf(2,"Try '--help' for more information.\n",{})               */
    EPrintf(2, _8411, _5);
L35: 
L34: 

    /** 				local_abort(1)*/
    _4local_abort(1);

    /** 			continue*/
    goto L12; // [1468] 532
L30: 

    /** 		sequence opt = opts[find_result[1]]*/
    _2 = (int)SEQ_PTR(_find_result_14824);
    _8513 = (int)*(((s1_ptr)_2)->base + 1);
    DeRef(_opt_15079);
    _2 = (int)SEQ_PTR(_opts_14816);
    if (!IS_ATOM_INT(_8513)){
        _opt_15079 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_8513)->dbl));
    }
    else{
        _opt_15079 = (int)*(((s1_ptr)_2)->base + _8513);
    }
    Ref(_opt_15079);

    /** 		integer map_add_operation = map:ADD*/
    _map_add_operation_15082 = 2;

    /** 		if find(HAS_PARAMETER, opt[OPTIONS]) != 0 then*/
    _2 = (int)SEQ_PTR(_opt_15079);
    _8515 = (int)*(((s1_ptr)_2)->base + 4);
    _8516 = find_from(112, _8515, 1);
    _8515 = NOVALUE;
    if (_8516 == 0)
    goto L36; // [1499] 1677

    /** 			map_add_operation = map:APPEND*/
    _map_add_operation_15082 = 6;

    /** 			if length(find_result) < 4 then*/
    if (IS_SEQUENCE(_find_result_14824)){
            _8518 = SEQ_PTR(_find_result_14824)->length;
    }
    else {
        _8518 = 1;
    }
    if (_8518 >= 4)
    goto L37; // [1513] 1667

    /** 				arg_idx += 1*/
    _arg_idx_14820 = _arg_idx_14820 + 1;

    /** 				if arg_idx <= length(cmds) then*/
    if (IS_SEQUENCE(_cmds_14818)){
            _8521 = SEQ_PTR(_cmds_14818)->length;
    }
    else {
        _8521 = 1;
    }
    if (_arg_idx_14820 > _8521)
    goto L38; // [1528] 1573

    /** 					param = cmds[arg_idx]*/
    DeRef(_param_14823);
    _2 = (int)SEQ_PTR(_cmds_14818);
    _param_14823 = (int)*(((s1_ptr)_2)->base + _arg_idx_14820);
    Ref(_param_14823);

    /** 					if length(param) = 2 and find(param[1], "-/") then*/
    if (IS_SEQUENCE(_param_14823)){
            _8524 = SEQ_PTR(_param_14823)->length;
    }
    else {
        _8524 = 1;
    }
    _8525 = (_8524 == 2);
    _8524 = NOVALUE;
    if (_8525 == 0) {
        goto L39; // [1547] 1579
    }
    _2 = (int)SEQ_PTR(_param_14823);
    _8527 = (int)*(((s1_ptr)_2)->base + 1);
    _8528 = find_from(_8527, _7740, 1);
    _8527 = NOVALUE;
    if (_8528 == 0)
    {
        _8528 = NOVALUE;
        goto L39; // [1561] 1579
    }
    else{
        _8528 = NOVALUE;
    }

    /** 						param = ""*/
    RefDS(_5);
    DeRef(_param_14823);
    _param_14823 = _5;
    goto L39; // [1570] 1579
L38: 

    /** 					param = ""*/
    RefDS(_5);
    DeRef(_param_14823);
    _param_14823 = _5;
L39: 

    /** 				if length(param) = 0 and (validation = VALIDATE_ALL or (*/
    if (IS_SEQUENCE(_param_14823)){
            _8529 = SEQ_PTR(_param_14823)->length;
    }
    else {
        _8529 = 1;
    }
    _8530 = (_8529 == 0);
    _8529 = NOVALUE;
    if (_8530 == 0) {
        goto L3A; // [1590] 1684
    }
    _8532 = (_validation_14830 == 2);
    if (_8532 != 0) {
        DeRef(_8533);
        _8533 = 1;
        goto L3B; // [1598] 1610
    }
    _8534 = (_validation_14830 == 4);
    _8533 = (_8534 != 0);
L3B: 
    if (_8533 == 0)
    {
        _8533 = NOVALUE;
        goto L3A; // [1611] 1684
    }
    else{
        _8533 = NOVALUE;
    }

    /** 					printf(1, "option '%s' must have a parameter\n", {find_result[2]})*/
    _2 = (int)SEQ_PTR(_find_result_14824);
    _8536 = (int)*(((s1_ptr)_2)->base + 2);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_8536);
    *((int *)(_2+4)) = _8536;
    _8537 = MAKE_SEQ(_1);
    _8536 = NOVALUE;
    EPrintf(1, _8535, _8537);
    DeRefDS(_8537);
    _8537 = NOVALUE;

    /** 					if help_on_error then*/
    if (_help_on_error_14834 == 0)
    {
        goto L3C; // [1630] 1645
    }
    else{
    }

    /** 						local_help(opts, add_help_rid, cmds, 1, parse_options)*/
    RefDS(_opts_14816);
    RefDS(_cmds_14818);
    Ref(_parse_options_14817);
    _4local_help(_opts_14816, _add_help_rid_14829, _cmds_14818, 1, _parse_options_14817);
    goto L3D; // [1642] 1658
L3C: 

    /** 					elsif auto_help then*/
    if (_auto_help_14833 == 0)
    {
        goto L3E; // [1647] 1657
    }
    else{
    }

    /** 						printf(2,"Try '--help' for more information.\n",{})          */
    EPrintf(2, _8411, _5);
L3E: 
L3D: 

    /** 					local_abort(1)*/
    _4local_abort(1);
    goto L3A; // [1664] 1684
L37: 

    /** 				param = find_result[4]*/
    DeRef(_param_14823);
    _2 = (int)SEQ_PTR(_find_result_14824);
    _param_14823 = (int)*(((s1_ptr)_2)->base + 4);
    Ref(_param_14823);
    goto L3A; // [1674] 1684
L36: 

    /** 			param = find_result[4]*/
    DeRef(_param_14823);
    _2 = (int)SEQ_PTR(_find_result_14824);
    _param_14823 = (int)*(((s1_ptr)_2)->base + 4);
    Ref(_param_14823);
L3A: 

    /** 		if opt[CALLBACK] >= 0 then*/
    _2 = (int)SEQ_PTR(_opt_15079);
    _8540 = (int)*(((s1_ptr)_2)->base + 5);
    if (binary_op_a(LESS, _8540, 0)){
        _8540 = NOVALUE;
        goto L3F; // [1690] 1763
    }
    _8540 = NOVALUE;

    /** 			integer pos = find_result[1]*/
    _2 = (int)SEQ_PTR(_find_result_14824);
    _pos_15121 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_pos_15121))
    _pos_15121 = (long)DBL_PTR(_pos_15121)->dbl;

    /** 			call_count[pos] += 1*/
    _2 = (int)SEQ_PTR(_call_count_14828);
    _8543 = (int)*(((s1_ptr)_2)->base + _pos_15121);
    if (IS_ATOM_INT(_8543)) {
        _8544 = _8543 + 1;
        if (_8544 > MAXINT){
            _8544 = NewDouble((double)_8544);
        }
    }
    else
    _8544 = binary_op(PLUS, 1, _8543);
    _8543 = NOVALUE;
    _2 = (int)SEQ_PTR(_call_count_14828);
    _2 = (int)(((s1_ptr)_2)->base + _pos_15121);
    _1 = *(int *)_2;
    *(int *)_2 = _8544;
    if( _1 != _8544 ){
        DeRef(_1);
    }
    _8544 = NOVALUE;

    /** 			if call_func(opt[CALLBACK], {{find_result[1], call_count[pos], param,  find_result[3]}}) = 0 then*/
    _2 = (int)SEQ_PTR(_opt_15079);
    _8545 = (int)*(((s1_ptr)_2)->base + 5);
    _2 = (int)SEQ_PTR(_find_result_14824);
    _8546 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_call_count_14828);
    _8547 = (int)*(((s1_ptr)_2)->base + _pos_15121);
    _2 = (int)SEQ_PTR(_find_result_14824);
    _8548 = (int)*(((s1_ptr)_2)->base + 3);
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_8546);
    *((int *)(_2+4)) = _8546;
    Ref(_8547);
    *((int *)(_2+8)) = _8547;
    Ref(_param_14823);
    *((int *)(_2+12)) = _param_14823;
    Ref(_8548);
    *((int *)(_2+16)) = _8548;
    _8549 = MAKE_SEQ(_1);
    _8548 = NOVALUE;
    _8547 = NOVALUE;
    _8546 = NOVALUE;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _8549;
    _8550 = MAKE_SEQ(_1);
    _8549 = NOVALUE;
    _1 = (int)SEQ_PTR(_8550);
    _2 = (int)((s1_ptr)_1)->base;
    _0 = (int)_00[_8545].addr;
    Ref(*(int *)(_2+4));
    _1 = (*(int (*)())_0)(
                        *(int *)(_2+4)
                         );
    DeRef(_8551);
    _8551 = _1;
    DeRefDS(_8550);
    _8550 = NOVALUE;
    if (binary_op_a(NOTEQ, _8551, 0)){
        DeRef(_8551);
        _8551 = NOVALUE;
        goto L40; // [1749] 1762
    }
    DeRef(_8551);
    _8551 = NOVALUE;

    /** 				continue*/
    DeRefDS(_opt_15079);
    _opt_15079 = NOVALUE;
    goto L12; // [1759] 532
L40: 
L3F: 

    /** 		if find_result[3] = 1 then*/
    _2 = (int)SEQ_PTR(_find_result_14824);
    _8553 = (int)*(((s1_ptr)_2)->base + 3);
    if (binary_op_a(NOTEQ, _8553, 1)){
        _8553 = NOVALUE;
        goto L41; // [1771] 1788
    }
    _8553 = NOVALUE;

    /** 			map:remove(parsed_opts, opt[MAPNAME])*/
    _2 = (int)SEQ_PTR(_opt_15079);
    _8555 = (int)*(((s1_ptr)_2)->base + 6);
    Ref(_parsed_opts_14882);
    Ref(_8555);
    _28remove(_parsed_opts_14882, _8555);
    _8555 = NOVALUE;
    goto L42; // [1785] 1965
L41: 

    /** 			if find(MULTIPLE, opt[OPTIONS]) = 0 then*/
    _2 = (int)SEQ_PTR(_opt_15079);
    _8556 = (int)*(((s1_ptr)_2)->base + 4);
    _8557 = find_from(42, _8556, 1);
    _8556 = NOVALUE;
    if (_8557 != 0)
    goto L43; // [1799] 1946

    /** 				if map:has(parsed_opts, opt[MAPNAME]) and (validation = VALIDATE_ALL or*/
    _2 = (int)SEQ_PTR(_opt_15079);
    _8559 = (int)*(((s1_ptr)_2)->base + 6);
    Ref(_parsed_opts_14882);
    Ref(_8559);
    _8560 = _28has(_parsed_opts_14882, _8559);
    _8559 = NOVALUE;
    if (IS_ATOM_INT(_8560)) {
        if (_8560 == 0) {
            goto L44; // [1814] 1925
        }
    }
    else {
        if (DBL_PTR(_8560)->dbl == 0.0) {
            goto L44; // [1814] 1925
        }
    }
    _8562 = (_validation_14830 == 2);
    if (_8562 != 0) {
        DeRef(_8563);
        _8563 = 1;
        goto L45; // [1822] 1834
    }
    _8564 = (_validation_14830 == 4);
    _8563 = (_8564 != 0);
L45: 
    if (_8563 == 0)
    {
        _8563 = NOVALUE;
        goto L44; // [1835] 1925
    }
    else{
        _8563 = NOVALUE;
    }

    /** 					if find(HAS_PARAMETER, opt[OPTIONS]) or find(ONCE, opt[OPTIONS]) then*/
    _2 = (int)SEQ_PTR(_opt_15079);
    _8565 = (int)*(((s1_ptr)_2)->base + 4);
    _8566 = find_from(112, _8565, 1);
    _8565 = NOVALUE;
    if (_8566 != 0) {
        goto L46; // [1849] 1867
    }
    _2 = (int)SEQ_PTR(_opt_15079);
    _8568 = (int)*(((s1_ptr)_2)->base + 4);
    _8569 = find_from(49, _8568, 1);
    _8568 = NOVALUE;
    if (_8569 == 0)
    {
        _8569 = NOVALUE;
        goto L47; // [1863] 1964
    }
    else{
        _8569 = NOVALUE;
    }
L46: 

    /** 						printf(1, "option '%s' must not occur more than once in the command line.\n", {find_result[2]})*/
    _2 = (int)SEQ_PTR(_find_result_14824);
    _8571 = (int)*(((s1_ptr)_2)->base + 2);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_8571);
    *((int *)(_2+4)) = _8571;
    _8572 = MAKE_SEQ(_1);
    _8571 = NOVALUE;
    EPrintf(1, _8570, _8572);
    DeRefDS(_8572);
    _8572 = NOVALUE;

    /** 						if help_on_error then*/
    if (_help_on_error_14834 == 0)
    {
        goto L48; // [1883] 1903
    }
    else{
    }

    /** 							puts(2,10)*/
    EPuts(2, 10); // DJP 

    /** 							local_help(opts, add_help_rid, cmds, 1, parse_options)*/
    RefDS(_opts_14816);
    RefDS(_cmds_14818);
    Ref(_parse_options_14817);
    _4local_help(_opts_14816, _add_help_rid_14829, _cmds_14818, 1, _parse_options_14817);
    goto L49; // [1900] 1916
L48: 

    /** 						elsif auto_help then*/
    if (_auto_help_14833 == 0)
    {
        goto L4A; // [1905] 1915
    }
    else{
    }

    /** 							printf(2,"Try '--help' for more information.\n",{})          */
    EPrintf(2, _8411, _5);
L4A: 
L49: 

    /** 						local_abort(1)*/
    _4local_abort(1);
    goto L47; // [1922] 1964
L44: 

    /** 					map:put(parsed_opts, opt[MAPNAME], param)*/
    _2 = (int)SEQ_PTR(_opt_15079);
    _8573 = (int)*(((s1_ptr)_2)->base + 6);
    Ref(_parsed_opts_14882);
    Ref(_8573);
    Ref(_param_14823);
    _28put(_parsed_opts_14882, _8573, _param_14823, 1, 23);
    _8573 = NOVALUE;
    goto L47; // [1943] 1964
L43: 

    /** 				map:put(parsed_opts, opt[MAPNAME], param, map_add_operation)*/
    _2 = (int)SEQ_PTR(_opt_15079);
    _8574 = (int)*(((s1_ptr)_2)->base + 6);
    Ref(_parsed_opts_14882);
    Ref(_8574);
    Ref(_param_14823);
    _28put(_parsed_opts_14882, _8574, _param_14823, _map_add_operation_15082, 23);
    _8574 = NOVALUE;
L47: 
L42: 

    /**         if find(VERSIONING, opt[OPTIONS]) then*/
    _2 = (int)SEQ_PTR(_opt_15079);
    _8575 = (int)*(((s1_ptr)_2)->base + 4);
    _8576 = find_from(118, _8575, 1);
    _8575 = NOVALUE;
    if (_8576 == 0)
    {
        _8576 = NOVALUE;
        goto L4B; // [1976] 2063
    }
    else{
        _8576 = NOVALUE;
    }

    /**             integer ver_pos = find(VERSIONING, opt[OPTIONS]) + 1*/
    _2 = (int)SEQ_PTR(_opt_15079);
    _8577 = (int)*(((s1_ptr)_2)->base + 4);
    _8578 = find_from(118, _8577, 1);
    _8577 = NOVALUE;
    _ver_pos_15168 = _8578 + 1;
    _8578 = NOVALUE;

    /**             if length(opt[OPTIONS]) >= ver_pos then*/
    _2 = (int)SEQ_PTR(_opt_15079);
    _8580 = (int)*(((s1_ptr)_2)->base + 4);
    if (IS_SEQUENCE(_8580)){
            _8581 = SEQ_PTR(_8580)->length;
    }
    else {
        _8581 = 1;
    }
    _8580 = NOVALUE;
    if (_8581 < _ver_pos_15168)
    goto L4C; // [2003] 2032

    /**                 printf(1, "%s\n", { opt[OPTIONS][ver_pos] })*/
    _2 = (int)SEQ_PTR(_opt_15079);
    _8584 = (int)*(((s1_ptr)_2)->base + 4);
    _2 = (int)SEQ_PTR(_8584);
    _8585 = (int)*(((s1_ptr)_2)->base + _ver_pos_15168);
    _8584 = NOVALUE;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_8585);
    *((int *)(_2+4)) = _8585;
    _8586 = MAKE_SEQ(_1);
    _8585 = NOVALUE;
    EPrintf(1, _8583, _8586);
    DeRefDS(_8586);
    _8586 = NOVALUE;

    /**                 abort(0)*/
    UserCleanup(0);
    goto L4D; // [2029] 2062
L4C: 

    /**                 error:crash("help options are incorrect,\n" &*/
    Concat((object_ptr)&_8589, _8587, _8588);
    DeRefi(_fmt_inlined_crash_at_2037_15185);
    _fmt_inlined_crash_at_2037_15185 = _8589;
    _8589 = NOVALUE;

    /** 	msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_2040_15186);
    _msg_inlined_crash_at_2040_15186 = EPrintf(-9999999, _fmt_inlined_crash_at_2037_15185, _5);

    /** 	machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_2040_15186);

    /** end procedure*/
    goto L4E; // [2056] 2059
L4E: 
    DeRefi(_fmt_inlined_crash_at_2037_15185);
    _fmt_inlined_crash_at_2037_15185 = NOVALUE;
    DeRefi(_msg_inlined_crash_at_2040_15186);
    _msg_inlined_crash_at_2040_15186 = NOVALUE;
L4D: 
L4B: 
    DeRef(_opt_15079);
    _opt_15079 = NOVALUE;

    /** 	end while*/
    goto L12; // [2069] 532
L13: 

    /** 	for i = 1 to length(opts) do*/
    if (IS_SEQUENCE(_opts_14816)){
            _8590 = SEQ_PTR(_opts_14816)->length;
    }
    else {
        _8590 = 1;
    }
    {
        int _i_15188;
        _i_15188 = 1;
L4F: 
        if (_i_15188 > _8590){
            goto L50; // [2077] 2292
        }

        /** 		if find(MANDATORY, opts[i][OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opts_14816);
        _8591 = (int)*(((s1_ptr)_2)->base + _i_15188);
        _2 = (int)SEQ_PTR(_8591);
        _8592 = (int)*(((s1_ptr)_2)->base + 4);
        _8591 = NOVALUE;
        _8593 = find_from(109, _8592, 1);
        _8592 = NOVALUE;
        if (_8593 == 0)
        {
            _8593 = NOVALUE;
            goto L51; // [2099] 2285
        }
        else{
            _8593 = NOVALUE;
        }

        /** 			if atom(opts[i][SHORTNAME]) and atom(opts[i][LONGNAME]) then*/
        _2 = (int)SEQ_PTR(_opts_14816);
        _8594 = (int)*(((s1_ptr)_2)->base + _i_15188);
        _2 = (int)SEQ_PTR(_8594);
        _8595 = (int)*(((s1_ptr)_2)->base + 1);
        _8594 = NOVALUE;
        _8596 = IS_ATOM(_8595);
        _8595 = NOVALUE;
        if (_8596 == 0) {
            goto L52; // [2115] 2206
        }
        _2 = (int)SEQ_PTR(_opts_14816);
        _8598 = (int)*(((s1_ptr)_2)->base + _i_15188);
        _2 = (int)SEQ_PTR(_8598);
        _8599 = (int)*(((s1_ptr)_2)->base + 2);
        _8598 = NOVALUE;
        _8600 = IS_ATOM(_8599);
        _8599 = NOVALUE;
        if (_8600 == 0)
        {
            _8600 = NOVALUE;
            goto L52; // [2131] 2206
        }
        else{
            _8600 = NOVALUE;
        }

        /** 				if length(map:get(parsed_opts, opts[i][MAPNAME])) = 0 then*/
        _2 = (int)SEQ_PTR(_opts_14816);
        _8601 = (int)*(((s1_ptr)_2)->base + _i_15188);
        _2 = (int)SEQ_PTR(_8601);
        _8602 = (int)*(((s1_ptr)_2)->base + 6);
        _8601 = NOVALUE;
        Ref(_parsed_opts_14882);
        Ref(_8602);
        _8603 = _28get(_parsed_opts_14882, _8602, 0);
        _8602 = NOVALUE;
        if (IS_SEQUENCE(_8603)){
                _8604 = SEQ_PTR(_8603)->length;
        }
        else {
            _8604 = 1;
        }
        DeRef(_8603);
        _8603 = NOVALUE;
        if (_8604 != 0)
        goto L53; // [2153] 2284

        /** 					puts(1, "Additional arguments were expected.\n")*/
        EPuts(1, _8606); // DJP 

        /** 					if help_on_error then*/
        if (_help_on_error_14834 == 0)
        {
            goto L54; // [2164] 2184
        }
        else{
        }

        /** 						puts(2,10)*/
        EPuts(2, 10); // DJP 

        /** 						local_help(opts, add_help_rid, cmds, 1, parse_options)*/
        RefDS(_opts_14816);
        RefDS(_cmds_14818);
        Ref(_parse_options_14817);
        _4local_help(_opts_14816, _add_help_rid_14829, _cmds_14818, 1, _parse_options_14817);
        goto L55; // [2181] 2197
L54: 

        /** 					elsif auto_help then*/
        if (_auto_help_14833 == 0)
        {
            goto L56; // [2186] 2196
        }
        else{
        }

        /** 						printf(2,"Try '--help' for more information.\n",{})          */
        EPrintf(2, _8411, _5);
L56: 
L55: 

        /** 					local_abort(1)*/
        _4local_abort(1);
        goto L53; // [2203] 2284
L52: 

        /** 				if not map:has(parsed_opts, opts[i][MAPNAME]) then*/
        _2 = (int)SEQ_PTR(_opts_14816);
        _8607 = (int)*(((s1_ptr)_2)->base + _i_15188);
        _2 = (int)SEQ_PTR(_8607);
        _8608 = (int)*(((s1_ptr)_2)->base + 6);
        _8607 = NOVALUE;
        Ref(_parsed_opts_14882);
        Ref(_8608);
        _8609 = _28has(_parsed_opts_14882, _8608);
        _8608 = NOVALUE;
        if (IS_ATOM_INT(_8609)) {
            if (_8609 != 0){
                DeRef(_8609);
                _8609 = NOVALUE;
                goto L57; // [2221] 2283
            }
        }
        else {
            if (DBL_PTR(_8609)->dbl != 0.0){
                DeRef(_8609);
                _8609 = NOVALUE;
                goto L57; // [2221] 2283
            }
        }
        DeRef(_8609);
        _8609 = NOVALUE;

        /** 					printf(1, "option '%s' is mandatory but was not supplied.\n", {opts[i][MAPNAME]})*/
        _2 = (int)SEQ_PTR(_opts_14816);
        _8612 = (int)*(((s1_ptr)_2)->base + _i_15188);
        _2 = (int)SEQ_PTR(_8612);
        _8613 = (int)*(((s1_ptr)_2)->base + 6);
        _8612 = NOVALUE;
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        Ref(_8613);
        *((int *)(_2+4)) = _8613;
        _8614 = MAKE_SEQ(_1);
        _8613 = NOVALUE;
        EPrintf(1, _8611, _8614);
        DeRefDS(_8614);
        _8614 = NOVALUE;

        /** 					if help_on_error then*/
        if (_help_on_error_14834 == 0)
        {
            goto L58; // [2244] 2264
        }
        else{
        }

        /** 						puts(2,10)*/
        EPuts(2, 10); // DJP 

        /** 						local_help(opts, add_help_rid, cmds, 1, parse_options)*/
        RefDS(_opts_14816);
        RefDS(_cmds_14818);
        Ref(_parse_options_14817);
        _4local_help(_opts_14816, _add_help_rid_14829, _cmds_14818, 1, _parse_options_14817);
        goto L59; // [2261] 2277
L58: 

        /** 					elsif auto_help then*/
        if (_auto_help_14833 == 0)
        {
            goto L5A; // [2266] 2276
        }
        else{
        }

        /** 						printf(2,"Try '--help' for more information.\n",{})          */
        EPrintf(2, _8411, _5);
L5A: 
L59: 

        /** 					local_abort(1)*/
        _4local_abort(1);
L57: 
L53: 
L51: 

        /** 	end for*/
        _i_15188 = _i_15188 + 1;
        goto L4F; // [2287] 2084
L50: 
        ;
    }

    /** 	return parsed_opts*/
    DeRefDS(_opts_14816);
    DeRefi(_parse_options_14817);
    DeRefDS(_cmds_14818);
    DeRef(_cmd_14822);
    DeRef(_param_14823);
    DeRef(_find_result_14824);
    DeRef(_type__14825);
    DeRef(_help_opts_14827);
    DeRef(_call_count_14828);
    DeRef(_8484);
    _8484 = NOVALUE;
    DeRef(_8390);
    _8390 = NOVALUE;
    DeRef(_8439);
    _8439 = NOVALUE;
    _8545 = NOVALUE;
    _8513 = NOVALUE;
    DeRef(_8525);
    _8525 = NOVALUE;
    DeRef(_8564);
    _8564 = NOVALUE;
    _8446 = NOVALUE;
    DeRef(_8479);
    _8479 = NOVALUE;
    DeRef(_8560);
    _8560 = NOVALUE;
    DeRef(_8430);
    _8430 = NOVALUE;
    DeRef(_8451);
    _8451 = NOVALUE;
    DeRef(_8562);
    _8562 = NOVALUE;
    DeRef(_8507);
    _8507 = NOVALUE;
    DeRef(_8534);
    _8534 = NOVALUE;
    DeRef(_8444);
    _8444 = NOVALUE;
    DeRef(_8509);
    _8509 = NOVALUE;
    DeRef(_8455);
    _8455 = NOVALUE;
    DeRef(_8505);
    _8505 = NOVALUE;
    DeRef(_8532);
    _8532 = NOVALUE;
    _8417 = NOVALUE;
    DeRef(_8467);
    _8467 = NOVALUE;
    DeRef(_8393);
    _8393 = NOVALUE;
    _8580 = NOVALUE;
    DeRef(_8460);
    _8460 = NOVALUE;
    DeRef(_8420);
    _8420 = NOVALUE;
    DeRef(_8422);
    _8422 = NOVALUE;
    _8462 = NOVALUE;
    DeRef(_8530);
    _8530 = NOVALUE;
    _8603 = NOVALUE;
    DeRef(_8432);
    _8432 = NOVALUE;
    DeRef(_8482);
    _8482 = NOVALUE;
    return _parsed_opts_14882;
    ;
}


int _4build_commandline(int _cmds_15225)
{
    int _8617 = NOVALUE;
    int _8616 = NOVALUE;
    int _8615 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return stdseq:flatten( text:quote( cmds,,'\\'," " ), " ")*/
    RefDS(_4879);
    RefDS(_4879);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _4879;
    ((int *)_2)[2] = _4879;
    _8615 = MAKE_SEQ(_1);
    RefDS(_cmds_15225);
    RefDS(_2683);
    _8616 = _14quote(_cmds_15225, _8615, 92, _2683);
    _8615 = NOVALUE;
    RefDS(_2683);
    _8617 = _23flatten(_8616, _2683);
    _8616 = NOVALUE;
    DeRefDS(_cmds_15225);
    return _8617;
    ;
}



// 0xB68C06D9
