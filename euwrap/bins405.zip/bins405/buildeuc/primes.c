// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int _30calc_primes(int _approx_limit_10772, int _time_limit_p_10773)
{
    int _result__10774 = NOVALUE;
    int _candidate__10775 = NOVALUE;
    int _pos__10776 = NOVALUE;
    int _time_out__10777 = NOVALUE;
    int _maxp__10778 = NOVALUE;
    int _maxf__10779 = NOVALUE;
    int _maxf_idx_10780 = NOVALUE;
    int _next_trigger_10781 = NOVALUE;
    int _growth_10782 = NOVALUE;
    int _6052 = NOVALUE;
    int _6049 = NOVALUE;
    int _6047 = NOVALUE;
    int _6044 = NOVALUE;
    int _6041 = NOVALUE;
    int _6038 = NOVALUE;
    int _6031 = NOVALUE;
    int _6029 = NOVALUE;
    int _6026 = NOVALUE;
    int _6023 = NOVALUE;
    int _6019 = NOVALUE;
    int _6018 = NOVALUE;
    int _6014 = NOVALUE;
    int _6008 = NOVALUE;
    int _6006 = NOVALUE;
    int _6004 = NOVALUE;
    int _5999 = NOVALUE;
    int _5998 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if approx_limit <= list_of_primes[$] then*/
    if (IS_SEQUENCE(_30list_of_primes_10768)){
            _5998 = SEQ_PTR(_30list_of_primes_10768)->length;
    }
    else {
        _5998 = 1;
    }
    _2 = (int)SEQ_PTR(_30list_of_primes_10768);
    _5999 = (int)*(((s1_ptr)_2)->base + _5998);
    if (binary_op_a(GREATER, _approx_limit_10772, _5999)){
        _5999 = NOVALUE;
        goto L1; // [14] 59
    }
    _5999 = NOVALUE;

    /** 		pos_ = search:binary_search(approx_limit, list_of_primes)*/
    RefDS(_30list_of_primes_10768);
    _pos__10776 = _16binary_search(_approx_limit_10772, _30list_of_primes_10768, 1, 0);
    if (!IS_ATOM_INT(_pos__10776)) {
        _1 = (long)(DBL_PTR(_pos__10776)->dbl);
        DeRefDS(_pos__10776);
        _pos__10776 = _1;
    }

    /** 		if pos_ < 0 then*/
    if (_pos__10776 >= 0)
    goto L2; // [33] 45

    /** 			pos_ = (-pos_)*/
    _pos__10776 = - _pos__10776;
L2: 

    /** 		return list_of_primes[1..pos_]*/
    rhs_slice_target = (object_ptr)&_6004;
    RHS_Slice(_30list_of_primes_10768, 1, _pos__10776);
    DeRef(_result__10774);
    DeRef(_time_out__10777);
    return _6004;
L1: 

    /** 	pos_ = length(list_of_primes)*/
    if (IS_SEQUENCE(_30list_of_primes_10768)){
            _pos__10776 = SEQ_PTR(_30list_of_primes_10768)->length;
    }
    else {
        _pos__10776 = 1;
    }

    /** 	candidate_ = list_of_primes[$]*/
    if (IS_SEQUENCE(_30list_of_primes_10768)){
            _6006 = SEQ_PTR(_30list_of_primes_10768)->length;
    }
    else {
        _6006 = 1;
    }
    _2 = (int)SEQ_PTR(_30list_of_primes_10768);
    _candidate__10775 = (int)*(((s1_ptr)_2)->base + _6006);
    if (!IS_ATOM_INT(_candidate__10775))
    _candidate__10775 = (long)DBL_PTR(_candidate__10775)->dbl;

    /** 	maxf_ = floor(power(candidate_, 0.5))*/
    temp_d.dbl = (double)_candidate__10775;
    _6008 = Dpower(&temp_d, DBL_PTR(_1690));
    _maxf__10779 = unary_op(FLOOR, _6008);
    DeRefDS(_6008);
    _6008 = NOVALUE;
    if (!IS_ATOM_INT(_maxf__10779)) {
        _1 = (long)(DBL_PTR(_maxf__10779)->dbl);
        DeRefDS(_maxf__10779);
        _maxf__10779 = _1;
    }

    /** 	maxf_idx = search:binary_search(maxf_, list_of_primes)*/
    RefDS(_30list_of_primes_10768);
    _maxf_idx_10780 = _16binary_search(_maxf__10779, _30list_of_primes_10768, 1, 0);
    if (!IS_ATOM_INT(_maxf_idx_10780)) {
        _1 = (long)(DBL_PTR(_maxf_idx_10780)->dbl);
        DeRefDS(_maxf_idx_10780);
        _maxf_idx_10780 = _1;
    }

    /** 	if maxf_idx < 0 then*/
    if (_maxf_idx_10780 >= 0)
    goto L3; // [103] 123

    /** 		maxf_idx = (-maxf_idx)*/
    _maxf_idx_10780 = - _maxf_idx_10780;

    /** 		maxf_ = list_of_primes[maxf_idx]*/
    _2 = (int)SEQ_PTR(_30list_of_primes_10768);
    _maxf__10779 = (int)*(((s1_ptr)_2)->base + _maxf_idx_10780);
    if (!IS_ATOM_INT(_maxf__10779))
    _maxf__10779 = (long)DBL_PTR(_maxf__10779)->dbl;
L3: 

    /** 	next_trigger = list_of_primes[maxf_idx+1]*/
    _6014 = _maxf_idx_10780 + 1;
    _2 = (int)SEQ_PTR(_30list_of_primes_10768);
    _next_trigger_10781 = (int)*(((s1_ptr)_2)->base + _6014);
    if (!IS_ATOM_INT(_next_trigger_10781))
    _next_trigger_10781 = (long)DBL_PTR(_next_trigger_10781)->dbl;

    /** 	next_trigger *= next_trigger*/
    _next_trigger_10781 = _next_trigger_10781 * _next_trigger_10781;

    /** 	growth = floor(approx_limit  / 3.5) - length(list_of_primes)*/
    _2 = binary_op(DIVIDE, _approx_limit_10772, _6017);
    _6018 = unary_op(FLOOR, _2);
    DeRef(_2);
    if (IS_SEQUENCE(_30list_of_primes_10768)){
            _6019 = SEQ_PTR(_30list_of_primes_10768)->length;
    }
    else {
        _6019 = 1;
    }
    if (IS_ATOM_INT(_6018)) {
        _growth_10782 = _6018 - _6019;
    }
    else {
        _growth_10782 = NewDouble(DBL_PTR(_6018)->dbl - (double)_6019);
    }
    DeRef(_6018);
    _6018 = NOVALUE;
    _6019 = NOVALUE;
    if (!IS_ATOM_INT(_growth_10782)) {
        _1 = (long)(DBL_PTR(_growth_10782)->dbl);
        DeRefDS(_growth_10782);
        _growth_10782 = _1;
    }

    /** 	if growth <= 0 then*/
    if (_growth_10782 > 0)
    goto L4; // [162] 174

    /** 		growth = length(list_of_primes)*/
    if (IS_SEQUENCE(_30list_of_primes_10768)){
            _growth_10782 = SEQ_PTR(_30list_of_primes_10768)->length;
    }
    else {
        _growth_10782 = 1;
    }
L4: 

    /** 	result_ = list_of_primes & repeat(0, growth)*/
    _6023 = Repeat(0, _growth_10782);
    Concat((object_ptr)&_result__10774, _30list_of_primes_10768, _6023);
    DeRefDS(_6023);
    _6023 = NOVALUE;

    /** 	if time_limit_p < 0 then*/
    if (_time_limit_p_10773 >= 0)
    goto L5; // [188] 203

    /** 		time_out_ = time() + 100_000_000*/
    DeRef(_6026);
    _6026 = NewDouble(current_time());
    DeRef(_time_out__10777);
    _time_out__10777 = NewDouble(DBL_PTR(_6026)->dbl + (double)100000000);
    DeRefDS(_6026);
    _6026 = NOVALUE;
    goto L6; // [200] 212
L5: 

    /** 		time_out_ = time() + time_limit_p*/
    DeRef(_6029);
    _6029 = NewDouble(current_time());
    DeRef(_time_out__10777);
    _time_out__10777 = NewDouble(DBL_PTR(_6029)->dbl + (double)_time_limit_p_10773);
    DeRefDS(_6029);
    _6029 = NOVALUE;
L6: 

    /** 	while time_out_ >= time()  label "MW" do*/
L7: 
    DeRef(_6031);
    _6031 = NewDouble(current_time());
    if (binary_op_a(LESS, _time_out__10777, _6031)){
        DeRefDS(_6031);
        _6031 = NOVALUE;
        goto L8; // [221] 370
    }
    DeRef(_6031);
    _6031 = NOVALUE;

    /** 		task_yield()*/
    task_yield();

    /** 		candidate_ += 2*/
    _candidate__10775 = _candidate__10775 + 2;

    /** 		if candidate_ >= next_trigger then*/
    if (_candidate__10775 < _next_trigger_10781)
    goto L9; // [236] 271

    /** 			maxf_idx += 1*/
    _maxf_idx_10780 = _maxf_idx_10780 + 1;

    /** 			maxf_ = result_[maxf_idx]*/
    _2 = (int)SEQ_PTR(_result__10774);
    _maxf__10779 = (int)*(((s1_ptr)_2)->base + _maxf_idx_10780);
    if (!IS_ATOM_INT(_maxf__10779))
    _maxf__10779 = (long)DBL_PTR(_maxf__10779)->dbl;

    /** 			next_trigger = result_[maxf_idx+1]*/
    _6038 = _maxf_idx_10780 + 1;
    _2 = (int)SEQ_PTR(_result__10774);
    _next_trigger_10781 = (int)*(((s1_ptr)_2)->base + _6038);
    if (!IS_ATOM_INT(_next_trigger_10781))
    _next_trigger_10781 = (long)DBL_PTR(_next_trigger_10781)->dbl;

    /** 			next_trigger *= next_trigger*/
    _next_trigger_10781 = _next_trigger_10781 * _next_trigger_10781;
L9: 

    /** 		for i = 2 to pos_ do*/
    _6041 = _pos__10776;
    {
        int _i_10835;
        _i_10835 = 2;
LA: 
        if (_i_10835 > _6041){
            goto LB; // [276] 322
        }

        /** 			maxp_ = result_[i]*/
        _2 = (int)SEQ_PTR(_result__10774);
        _maxp__10778 = (int)*(((s1_ptr)_2)->base + _i_10835);
        if (!IS_ATOM_INT(_maxp__10778))
        _maxp__10778 = (long)DBL_PTR(_maxp__10778)->dbl;

        /** 			if maxp_ > maxf_ then*/
        if (_maxp__10778 <= _maxf__10779)
        goto LC; // [291] 300

        /** 				exit*/
        goto LB; // [297] 322
LC: 

        /** 			if remainder(candidate_, maxp_) = 0 then*/
        _6044 = (_candidate__10775 % _maxp__10778);
        if (_6044 != 0)
        goto LD; // [306] 315

        /** 				continue "MW"*/
        goto L7; // [312] 217
LD: 

        /** 		end for*/
        _i_10835 = _i_10835 + 1;
        goto LA; // [317] 283
LB: 
        ;
    }

    /** 		pos_ += 1*/
    _pos__10776 = _pos__10776 + 1;

    /** 		if pos_ >= length(result_) then*/
    if (IS_SEQUENCE(_result__10774)){
            _6047 = SEQ_PTR(_result__10774)->length;
    }
    else {
        _6047 = 1;
    }
    if (_pos__10776 < _6047)
    goto LE; // [333] 348

    /** 			result_ &= repeat(0, 1000)*/
    _6049 = Repeat(0, 1000);
    Concat((object_ptr)&_result__10774, _result__10774, _6049);
    DeRefDS(_6049);
    _6049 = NOVALUE;
LE: 

    /** 		result_[pos_] = candidate_*/
    _2 = (int)SEQ_PTR(_result__10774);
    _2 = (int)(((s1_ptr)_2)->base + _pos__10776);
    _1 = *(int *)_2;
    *(int *)_2 = _candidate__10775;
    DeRef(_1);

    /** 		if candidate_ >= approx_limit then*/
    if (_candidate__10775 < _approx_limit_10772)
    goto L7; // [356] 217

    /** 			exit*/
    goto L8; // [362] 370

    /** 	end while*/
    goto L7; // [367] 217
L8: 

    /** 	return result_[1..pos_]*/
    rhs_slice_target = (object_ptr)&_6052;
    RHS_Slice(_result__10774, 1, _pos__10776);
    DeRefDS(_result__10774);
    DeRef(_time_out__10777);
    DeRef(_6004);
    _6004 = NOVALUE;
    DeRef(_6014);
    _6014 = NOVALUE;
    DeRef(_6038);
    _6038 = NOVALUE;
    DeRef(_6044);
    _6044 = NOVALUE;
    return _6052;
    ;
}


int _30next_prime(int _n_10854, int _fail_signal_p_10855, int _time_out_p_10856)
{
    int _i_10857 = NOVALUE;
    int _6072 = NOVALUE;
    int _6066 = NOVALUE;
    int _6065 = NOVALUE;
    int _6064 = NOVALUE;
    int _6063 = NOVALUE;
    int _6062 = NOVALUE;
    int _6059 = NOVALUE;
    int _6058 = NOVALUE;
    int _6055 = NOVALUE;
    int _6054 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if n < 0 then*/
    if (_n_10854 >= 0)
    goto L1; // [5] 16

    /** 		return fail_signal_p*/
    return _fail_signal_p_10855;
L1: 

    /** 	if list_of_primes[$] < n then*/
    if (IS_SEQUENCE(_30list_of_primes_10768)){
            _6054 = SEQ_PTR(_30list_of_primes_10768)->length;
    }
    else {
        _6054 = 1;
    }
    _2 = (int)SEQ_PTR(_30list_of_primes_10768);
    _6055 = (int)*(((s1_ptr)_2)->base + _6054);
    if (binary_op_a(GREATEREQ, _6055, _n_10854)){
        _6055 = NOVALUE;
        goto L2; // [27] 41
    }
    _6055 = NOVALUE;

    /** 		list_of_primes = calc_primes(n,time_out_p)*/
    _0 = _30calc_primes(_n_10854, _time_out_p_10856);
    DeRefDS(_30list_of_primes_10768);
    _30list_of_primes_10768 = _0;
L2: 

    /** 	if n > list_of_primes[$] then*/
    if (IS_SEQUENCE(_30list_of_primes_10768)){
            _6058 = SEQ_PTR(_30list_of_primes_10768)->length;
    }
    else {
        _6058 = 1;
    }
    _2 = (int)SEQ_PTR(_30list_of_primes_10768);
    _6059 = (int)*(((s1_ptr)_2)->base + _6058);
    if (binary_op_a(LESSEQ, _n_10854, _6059)){
        _6059 = NOVALUE;
        goto L3; // [52] 63
    }
    _6059 = NOVALUE;

    /** 		return fail_signal_p*/
    return _fail_signal_p_10855;
L3: 

    /** 	if n < 1009 and 1009 <= list_of_primes[$] then*/
    _6062 = (_n_10854 < 1009);
    if (_6062 == 0) {
        goto L4; // [69] 106
    }
    if (IS_SEQUENCE(_30list_of_primes_10768)){
            _6064 = SEQ_PTR(_30list_of_primes_10768)->length;
    }
    else {
        _6064 = 1;
    }
    _2 = (int)SEQ_PTR(_30list_of_primes_10768);
    _6065 = (int)*(((s1_ptr)_2)->base + _6064);
    if (IS_ATOM_INT(_6065)) {
        _6066 = (1009 <= _6065);
    }
    else {
        _6066 = binary_op(LESSEQ, 1009, _6065);
    }
    _6065 = NOVALUE;
    if (_6066 == 0) {
        DeRef(_6066);
        _6066 = NOVALUE;
        goto L4; // [87] 106
    }
    else {
        if (!IS_ATOM_INT(_6066) && DBL_PTR(_6066)->dbl == 0.0){
            DeRef(_6066);
            _6066 = NOVALUE;
            goto L4; // [87] 106
        }
        DeRef(_6066);
        _6066 = NOVALUE;
    }
    DeRef(_6066);
    _6066 = NOVALUE;

    /** 		i = search:binary_search(n, list_of_primes, ,169)*/
    RefDS(_30list_of_primes_10768);
    _i_10857 = _16binary_search(_n_10854, _30list_of_primes_10768, 1, 169);
    if (!IS_ATOM_INT(_i_10857)) {
        _1 = (long)(DBL_PTR(_i_10857)->dbl);
        DeRefDS(_i_10857);
        _i_10857 = _1;
    }
    goto L5; // [103] 120
L4: 

    /** 		i = search:binary_search(n, list_of_primes)*/
    RefDS(_30list_of_primes_10768);
    _i_10857 = _16binary_search(_n_10854, _30list_of_primes_10768, 1, 0);
    if (!IS_ATOM_INT(_i_10857)) {
        _1 = (long)(DBL_PTR(_i_10857)->dbl);
        DeRefDS(_i_10857);
        _i_10857 = _1;
    }
L5: 

    /** 	if i < 0 then*/
    if (_i_10857 >= 0)
    goto L6; // [124] 136

    /** 		i = (-i)*/
    _i_10857 = - _i_10857;
L6: 

    /** 	return list_of_primes[i]*/
    _2 = (int)SEQ_PTR(_30list_of_primes_10768);
    _6072 = (int)*(((s1_ptr)_2)->base + _i_10857);
    Ref(_6072);
    DeRef(_fail_signal_p_10855);
    DeRef(_6062);
    _6062 = NOVALUE;
    return _6072;
    ;
}



// 0xD482C31B
