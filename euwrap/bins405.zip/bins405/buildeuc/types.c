// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int _13char_test(int _test_data_474, int _char_set_475)
{
    int _lChr_476 = NOVALUE;
    int _127 = NOVALUE;
    int _126 = NOVALUE;
    int _125 = NOVALUE;
    int _124 = NOVALUE;
    int _123 = NOVALUE;
    int _122 = NOVALUE;
    int _121 = NOVALUE;
    int _120 = NOVALUE;
    int _119 = NOVALUE;
    int _118 = NOVALUE;
    int _117 = NOVALUE;
    int _114 = NOVALUE;
    int _113 = NOVALUE;
    int _112 = NOVALUE;
    int _111 = NOVALUE;
    int _109 = NOVALUE;
    int _107 = NOVALUE;
    int _106 = NOVALUE;
    int _105 = NOVALUE;
    int _104 = NOVALUE;
    int _103 = NOVALUE;
    int _102 = NOVALUE;
    int _101 = NOVALUE;
    int _100 = NOVALUE;
    int _99 = NOVALUE;
    int _98 = NOVALUE;
    int _97 = NOVALUE;
    int _96 = NOVALUE;
    int _95 = NOVALUE;
    int _94 = NOVALUE;
    int _93 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if integer(test_data) then*/
    if (IS_ATOM_INT(_test_data_474))
    _93 = 1;
    else if (IS_ATOM_DBL(_test_data_474))
    _93 = IS_ATOM_INT(DoubleToInt(_test_data_474));
    else
    _93 = 0;
    if (_93 == 0)
    {
        _93 = NOVALUE;
        goto L1; // [8] 115
    }
    else{
        _93 = NOVALUE;
    }

    /** 		if sequence(char_set[1]) then*/
    _2 = (int)SEQ_PTR(_char_set_475);
    _94 = (int)*(((s1_ptr)_2)->base + 1);
    _95 = IS_SEQUENCE(_94);
    _94 = NOVALUE;
    if (_95 == 0)
    {
        _95 = NOVALUE;
        goto L2; // [20] 96
    }
    else{
        _95 = NOVALUE;
    }

    /** 			for j = 1 to length(char_set) do*/
    if (IS_SEQUENCE(_char_set_475)){
            _96 = SEQ_PTR(_char_set_475)->length;
    }
    else {
        _96 = 1;
    }
    {
        int _j_483;
        _j_483 = 1;
L3: 
        if (_j_483 > _96){
            goto L4; // [28] 85
        }

        /** 				if test_data >= char_set[j][1] and test_data <= char_set[j][2] then */
        _2 = (int)SEQ_PTR(_char_set_475);
        _97 = (int)*(((s1_ptr)_2)->base + _j_483);
        _2 = (int)SEQ_PTR(_97);
        _98 = (int)*(((s1_ptr)_2)->base + 1);
        _97 = NOVALUE;
        if (IS_ATOM_INT(_test_data_474) && IS_ATOM_INT(_98)) {
            _99 = (_test_data_474 >= _98);
        }
        else {
            _99 = binary_op(GREATEREQ, _test_data_474, _98);
        }
        _98 = NOVALUE;
        if (IS_ATOM_INT(_99)) {
            if (_99 == 0) {
                goto L5; // [49] 78
            }
        }
        else {
            if (DBL_PTR(_99)->dbl == 0.0) {
                goto L5; // [49] 78
            }
        }
        _2 = (int)SEQ_PTR(_char_set_475);
        _101 = (int)*(((s1_ptr)_2)->base + _j_483);
        _2 = (int)SEQ_PTR(_101);
        _102 = (int)*(((s1_ptr)_2)->base + 2);
        _101 = NOVALUE;
        if (IS_ATOM_INT(_test_data_474) && IS_ATOM_INT(_102)) {
            _103 = (_test_data_474 <= _102);
        }
        else {
            _103 = binary_op(LESSEQ, _test_data_474, _102);
        }
        _102 = NOVALUE;
        if (_103 == 0) {
            DeRef(_103);
            _103 = NOVALUE;
            goto L5; // [66] 78
        }
        else {
            if (!IS_ATOM_INT(_103) && DBL_PTR(_103)->dbl == 0.0){
                DeRef(_103);
                _103 = NOVALUE;
                goto L5; // [66] 78
            }
            DeRef(_103);
            _103 = NOVALUE;
        }
        DeRef(_103);
        _103 = NOVALUE;

        /** 					return TRUE */
        DeRef(_test_data_474);
        DeRefDS(_char_set_475);
        DeRef(_99);
        _99 = NOVALUE;
        return _13TRUE_436;
L5: 

        /** 			end for*/
        _j_483 = _j_483 + 1;
        goto L3; // [80] 35
L4: 
        ;
    }

    /** 			return FALSE*/
    DeRef(_test_data_474);
    DeRefDS(_char_set_475);
    DeRef(_99);
    _99 = NOVALUE;
    return _13FALSE_434;
    goto L6; // [93] 328
L2: 

    /** 			return find(test_data, char_set) > 0*/
    _104 = find_from(_test_data_474, _char_set_475, 1);
    _105 = (_104 > 0);
    _104 = NOVALUE;
    DeRef(_test_data_474);
    DeRefDS(_char_set_475);
    DeRef(_99);
    _99 = NOVALUE;
    return _105;
    goto L6; // [112] 328
L1: 

    /** 	elsif sequence(test_data) then*/
    _106 = IS_SEQUENCE(_test_data_474);
    if (_106 == 0)
    {
        _106 = NOVALUE;
        goto L7; // [120] 319
    }
    else{
        _106 = NOVALUE;
    }

    /** 		if length(test_data) = 0 then */
    if (IS_SEQUENCE(_test_data_474)){
            _107 = SEQ_PTR(_test_data_474)->length;
    }
    else {
        _107 = 1;
    }
    if (_107 != 0)
    goto L8; // [128] 141

    /** 			return FALSE */
    DeRef(_test_data_474);
    DeRefDS(_char_set_475);
    DeRef(_105);
    _105 = NOVALUE;
    DeRef(_99);
    _99 = NOVALUE;
    return _13FALSE_434;
L8: 

    /** 		for i = 1 to length(test_data) label "NXTCHR" do*/
    if (IS_SEQUENCE(_test_data_474)){
            _109 = SEQ_PTR(_test_data_474)->length;
    }
    else {
        _109 = 1;
    }
    {
        int _i_502;
        _i_502 = 1;
L9: 
        if (_i_502 > _109){
            goto LA; // [146] 308
        }

        /** 			if sequence(test_data[i]) then */
        _2 = (int)SEQ_PTR(_test_data_474);
        _111 = (int)*(((s1_ptr)_2)->base + _i_502);
        _112 = IS_SEQUENCE(_111);
        _111 = NOVALUE;
        if (_112 == 0)
        {
            _112 = NOVALUE;
            goto LB; // [162] 174
        }
        else{
            _112 = NOVALUE;
        }

        /** 				return FALSE*/
        DeRef(_test_data_474);
        DeRefDS(_char_set_475);
        DeRef(_105);
        _105 = NOVALUE;
        DeRef(_99);
        _99 = NOVALUE;
        return _13FALSE_434;
LB: 

        /** 			if not integer(test_data[i]) then */
        _2 = (int)SEQ_PTR(_test_data_474);
        _113 = (int)*(((s1_ptr)_2)->base + _i_502);
        if (IS_ATOM_INT(_113))
        _114 = 1;
        else if (IS_ATOM_DBL(_113))
        _114 = IS_ATOM_INT(DoubleToInt(_113));
        else
        _114 = 0;
        _113 = NOVALUE;
        if (_114 != 0)
        goto LC; // [183] 195
        _114 = NOVALUE;

        /** 				return FALSE*/
        DeRef(_test_data_474);
        DeRefDS(_char_set_475);
        DeRef(_105);
        _105 = NOVALUE;
        DeRef(_99);
        _99 = NOVALUE;
        return _13FALSE_434;
LC: 

        /** 			lChr = test_data[i]*/
        _2 = (int)SEQ_PTR(_test_data_474);
        _lChr_476 = (int)*(((s1_ptr)_2)->base + _i_502);
        if (!IS_ATOM_INT(_lChr_476)){
            _lChr_476 = (long)DBL_PTR(_lChr_476)->dbl;
        }

        /** 			if sequence(char_set[1]) then*/
        _2 = (int)SEQ_PTR(_char_set_475);
        _117 = (int)*(((s1_ptr)_2)->base + 1);
        _118 = IS_SEQUENCE(_117);
        _117 = NOVALUE;
        if (_118 == 0)
        {
            _118 = NOVALUE;
            goto LD; // [212] 276
        }
        else{
            _118 = NOVALUE;
        }

        /** 				for j = 1 to length(char_set) do*/
        if (IS_SEQUENCE(_char_set_475)){
                _119 = SEQ_PTR(_char_set_475)->length;
        }
        else {
            _119 = 1;
        }
        {
            int _j_517;
            _j_517 = 1;
LE: 
            if (_j_517 > _119){
                goto LF; // [220] 273
            }

            /** 					if lChr >= char_set[j][1] and lChr <= char_set[j][2] then*/
            _2 = (int)SEQ_PTR(_char_set_475);
            _120 = (int)*(((s1_ptr)_2)->base + _j_517);
            _2 = (int)SEQ_PTR(_120);
            _121 = (int)*(((s1_ptr)_2)->base + 1);
            _120 = NOVALUE;
            if (IS_ATOM_INT(_121)) {
                _122 = (_lChr_476 >= _121);
            }
            else {
                _122 = binary_op(GREATEREQ, _lChr_476, _121);
            }
            _121 = NOVALUE;
            if (IS_ATOM_INT(_122)) {
                if (_122 == 0) {
                    goto L10; // [241] 266
                }
            }
            else {
                if (DBL_PTR(_122)->dbl == 0.0) {
                    goto L10; // [241] 266
                }
            }
            _2 = (int)SEQ_PTR(_char_set_475);
            _124 = (int)*(((s1_ptr)_2)->base + _j_517);
            _2 = (int)SEQ_PTR(_124);
            _125 = (int)*(((s1_ptr)_2)->base + 2);
            _124 = NOVALUE;
            if (IS_ATOM_INT(_125)) {
                _126 = (_lChr_476 <= _125);
            }
            else {
                _126 = binary_op(LESSEQ, _lChr_476, _125);
            }
            _125 = NOVALUE;
            if (_126 == 0) {
                DeRef(_126);
                _126 = NOVALUE;
                goto L10; // [258] 266
            }
            else {
                if (!IS_ATOM_INT(_126) && DBL_PTR(_126)->dbl == 0.0){
                    DeRef(_126);
                    _126 = NOVALUE;
                    goto L10; // [258] 266
                }
                DeRef(_126);
                _126 = NOVALUE;
            }
            DeRef(_126);
            _126 = NOVALUE;

            /** 						continue "NXTCHR" */
            goto L11; // [263] 303
L10: 

            /** 				end for*/
            _j_517 = _j_517 + 1;
            goto LE; // [268] 227
LF: 
            ;
        }
        goto L12; // [273] 293
LD: 

        /** 				if find(lChr, char_set) > 0 then*/
        _127 = find_from(_lChr_476, _char_set_475, 1);
        if (_127 <= 0)
        goto L13; // [283] 292

        /** 					continue "NXTCHR"*/
        goto L11; // [289] 303
L13: 
L12: 

        /** 			return FALSE*/
        DeRef(_test_data_474);
        DeRefDS(_char_set_475);
        DeRef(_105);
        _105 = NOVALUE;
        DeRef(_99);
        _99 = NOVALUE;
        DeRef(_122);
        _122 = NOVALUE;
        return _13FALSE_434;

        /** 		end for*/
L11: 
        _i_502 = _i_502 + 1;
        goto L9; // [303] 153
LA: 
        ;
    }

    /** 		return TRUE*/
    DeRef(_test_data_474);
    DeRefDS(_char_set_475);
    DeRef(_105);
    _105 = NOVALUE;
    DeRef(_99);
    _99 = NOVALUE;
    DeRef(_122);
    _122 = NOVALUE;
    return _13TRUE_436;
    goto L6; // [316] 328
L7: 

    /** 		return FALSE*/
    DeRef(_test_data_474);
    DeRefDS(_char_set_475);
    DeRef(_105);
    _105 = NOVALUE;
    DeRef(_99);
    _99 = NOVALUE;
    DeRef(_122);
    _122 = NOVALUE;
    return _13FALSE_434;
L6: 
    ;
}


void _13set_default_charsets()
{
    int _193 = NOVALUE;
    int _191 = NOVALUE;
    int _190 = NOVALUE;
    int _188 = NOVALUE;
    int _185 = NOVALUE;
    int _184 = NOVALUE;
    int _183 = NOVALUE;
    int _182 = NOVALUE;
    int _179 = NOVALUE;
    int _177 = NOVALUE;
    int _166 = NOVALUE;
    int _159 = NOVALUE;
    int _156 = NOVALUE;
    int _149 = NOVALUE;
    int _146 = NOVALUE;
    int _145 = NOVALUE;
    int _144 = NOVALUE;
    int _141 = NOVALUE;
    int _138 = NOVALUE;
    int _130 = NOVALUE;
    int _129 = NOVALUE;
    int _0, _1, _2;
    

    /** 	Defined_Sets = repeat(0, CS_LAST - CS_FIRST - 1)*/
    _129 = 20;
    _130 = 19;
    _129 = NOVALUE;
    DeRef(_13Defined_Sets_532);
    _13Defined_Sets_532 = Repeat(0, 19);
    _130 = NOVALUE;

    /** 	Defined_Sets[CS_Alphabetic	] = {{'a', 'z'}, {'A', 'Z'}}*/
    RefDS(_137);
    RefDS(_134);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _134;
    ((int *)_2)[2] = _137;
    _138 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_13Defined_Sets_532);
    _2 = (int)(((s1_ptr)_2)->base + 12);
    *(int *)_2 = _138;
    if( _1 != _138 ){
    }
    _138 = NOVALUE;

    /** 	Defined_Sets[CS_Alphanumeric] = {{'0', '9'}, {'a', 'z'}, {'A', 'Z'}}*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_140);
    *((int *)(_2+4)) = _140;
    RefDS(_134);
    *((int *)(_2+8)) = _134;
    RefDS(_137);
    *((int *)(_2+12)) = _137;
    _141 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_13Defined_Sets_532);
    _2 = (int)(((s1_ptr)_2)->base + 10);
    _1 = *(int *)_2;
    *(int *)_2 = _141;
    if( _1 != _141 ){
        DeRef(_1);
    }
    _141 = NOVALUE;

    /** 	Defined_Sets[CS_Identifier]   = {{'0', '9'}, {'a', 'z'}, {'A', 'Z'}, {'_', '_'}}*/
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_140);
    *((int *)(_2+4)) = _140;
    RefDS(_134);
    *((int *)(_2+8)) = _134;
    RefDS(_137);
    *((int *)(_2+12)) = _137;
    RefDS(_143);
    *((int *)(_2+16)) = _143;
    _144 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_13Defined_Sets_532);
    _2 = (int)(((s1_ptr)_2)->base + 11);
    _1 = *(int *)_2;
    *(int *)_2 = _144;
    if( _1 != _144 ){
        DeRef(_1);
    }
    _144 = NOVALUE;

    /** 	Defined_Sets[CS_Uppercase 	] = {{'A', 'Z'}}*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_137);
    *((int *)(_2+4)) = _137;
    _145 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_13Defined_Sets_532);
    _2 = (int)(((s1_ptr)_2)->base + 9);
    _1 = *(int *)_2;
    *(int *)_2 = _145;
    if( _1 != _145 ){
        DeRef(_1);
    }
    _145 = NOVALUE;

    /** 	Defined_Sets[CS_Lowercase 	] = {{'a', 'z'}}*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_134);
    *((int *)(_2+4)) = _134;
    _146 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_13Defined_Sets_532);
    _2 = (int)(((s1_ptr)_2)->base + 8);
    _1 = *(int *)_2;
    *(int *)_2 = _146;
    if( _1 != _146 ){
        DeRef(_1);
    }
    _146 = NOVALUE;

    /** 	Defined_Sets[CS_Printable 	] = {{' ', '~'}}*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_148);
    *((int *)(_2+4)) = _148;
    _149 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_13Defined_Sets_532);
    _2 = (int)(((s1_ptr)_2)->base + 6);
    _1 = *(int *)_2;
    *(int *)_2 = _149;
    if( _1 != _149 ){
        DeRef(_1);
    }
    _149 = NOVALUE;

    /** 	Defined_Sets[CS_Displayable ] = {{' ', '~'}, "  ", "\t\t", "\n\n", "\r\r", {8,8}, {7,7} }*/
    _1 = NewS1(7);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_148);
    *((int *)(_2+4)) = _148;
    RefDS(_150);
    *((int *)(_2+8)) = _150;
    RefDS(_151);
    *((int *)(_2+12)) = _151;
    RefDS(_152);
    *((int *)(_2+16)) = _152;
    RefDS(_153);
    *((int *)(_2+20)) = _153;
    RefDS(_154);
    *((int *)(_2+24)) = _154;
    RefDS(_155);
    *((int *)(_2+28)) = _155;
    _156 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_13Defined_Sets_532);
    _2 = (int)(((s1_ptr)_2)->base + 7);
    _1 = *(int *)_2;
    *(int *)_2 = _156;
    if( _1 != _156 ){
        DeRef(_1);
    }
    _156 = NOVALUE;

    /** 	Defined_Sets[CS_Whitespace 	] = " \t\n\r" & 11 & 160*/
    {
        int concat_list[3];

        concat_list[0] = 160;
        concat_list[1] = 11;
        concat_list[2] = _157;
        Concat_N((object_ptr)&_159, concat_list, 3);
    }
    _2 = (int)SEQ_PTR(_13Defined_Sets_532);
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = _159;
    if( _1 != _159 ){
        DeRef(_1);
    }
    _159 = NOVALUE;

    /** 	Defined_Sets[CS_Consonant 	] = "bcdfghjklmnpqrstvwxyzBCDFGHJKLMNPQRSTVWXYZ"*/
    RefDS(_160);
    _2 = (int)SEQ_PTR(_13Defined_Sets_532);
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _160;
    DeRef(_1);

    /** 	Defined_Sets[CS_Vowel 		] = "aeiouAEIOU"*/
    RefDS(_161);
    _2 = (int)SEQ_PTR(_13Defined_Sets_532);
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _161;
    DeRef(_1);

    /** 	Defined_Sets[CS_Hexadecimal ] = {{'0', '9'}, {'A', 'F'},{'a', 'f'}}*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_140);
    *((int *)(_2+4)) = _140;
    RefDS(_163);
    *((int *)(_2+8)) = _163;
    RefDS(_165);
    *((int *)(_2+12)) = _165;
    _166 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_13Defined_Sets_532);
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = _166;
    if( _1 != _166 ){
        DeRef(_1);
    }
    _166 = NOVALUE;

    /** 	Defined_Sets[CS_Punctuation ] = {{' ', '/'}, {':', '?'}, {'[', '`'}, {'{', '~'}}*/
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_168);
    *((int *)(_2+4)) = _168;
    RefDS(_171);
    *((int *)(_2+8)) = _171;
    RefDS(_174);
    *((int *)(_2+12)) = _174;
    RefDS(_176);
    *((int *)(_2+16)) = _176;
    _177 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_13Defined_Sets_532);
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = _177;
    if( _1 != _177 ){
        DeRef(_1);
    }
    _177 = NOVALUE;

    /** 	Defined_Sets[CS_Control 	] = {{0, 31}, {127, 127}}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = 31;
    _179 = MAKE_SEQ(_1);
    RefDS(_181);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _179;
    ((int *)_2)[2] = _181;
    _182 = MAKE_SEQ(_1);
    _179 = NOVALUE;
    _2 = (int)SEQ_PTR(_13Defined_Sets_532);
    _2 = (int)(((s1_ptr)_2)->base + 14);
    _1 = *(int *)_2;
    *(int *)_2 = _182;
    if( _1 != _182 ){
        DeRef(_1);
    }
    _182 = NOVALUE;

    /** 	Defined_Sets[CS_ASCII 		] = {{0, 127}}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = 127;
    _183 = MAKE_SEQ(_1);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _183;
    _184 = MAKE_SEQ(_1);
    _183 = NOVALUE;
    _2 = (int)SEQ_PTR(_13Defined_Sets_532);
    _2 = (int)(((s1_ptr)_2)->base + 13);
    _1 = *(int *)_2;
    *(int *)_2 = _184;
    if( _1 != _184 ){
        DeRef(_1);
    }
    _184 = NOVALUE;

    /** 	Defined_Sets[CS_Digit 		] = {{'0', '9'}}*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_140);
    *((int *)(_2+4)) = _140;
    _185 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_13Defined_Sets_532);
    _2 = (int)(((s1_ptr)_2)->base + 15);
    _1 = *(int *)_2;
    *(int *)_2 = _185;
    if( _1 != _185 ){
        DeRef(_1);
    }
    _185 = NOVALUE;

    /** 	Defined_Sets[CS_Graphic 	] = {{'!', '~'}}*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_187);
    *((int *)(_2+4)) = _187;
    _188 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_13Defined_Sets_532);
    _2 = (int)(((s1_ptr)_2)->base + 16);
    _1 = *(int *)_2;
    *(int *)_2 = _188;
    if( _1 != _188 ){
        DeRef(_1);
    }
    _188 = NOVALUE;

    /** 	Defined_Sets[CS_Bytes	 	] = {{0, 255}}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = 255;
    _190 = MAKE_SEQ(_1);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _190;
    _191 = MAKE_SEQ(_1);
    _190 = NOVALUE;
    _2 = (int)SEQ_PTR(_13Defined_Sets_532);
    _2 = (int)(((s1_ptr)_2)->base + 17);
    _1 = *(int *)_2;
    *(int *)_2 = _191;
    if( _1 != _191 ){
        DeRef(_1);
    }
    _191 = NOVALUE;

    /** 	Defined_Sets[CS_SpecWord 	] = "_"*/
    RefDS(_192);
    _2 = (int)SEQ_PTR(_13Defined_Sets_532);
    _2 = (int)(((s1_ptr)_2)->base + 18);
    _1 = *(int *)_2;
    *(int *)_2 = _192;
    DeRef(_1);

    /** 	Defined_Sets[CS_Boolean     ] = {TRUE,FALSE}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _13TRUE_436;
    ((int *)_2)[2] = _13FALSE_434;
    _193 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_13Defined_Sets_532);
    _2 = (int)(((s1_ptr)_2)->base + 19);
    _1 = *(int *)_2;
    *(int *)_2 = _193;
    if( _1 != _193 ){
        DeRef(_1);
    }
    _193 = NOVALUE;

    /** end procedure*/
    return;
    ;
}


int _13get_charsets()
{
    int _result__602 = NOVALUE;
    int _197 = NOVALUE;
    int _196 = NOVALUE;
    int _195 = NOVALUE;
    int _194 = NOVALUE;
    int _0, _1, _2;
    

    /** 	result_ = {}*/
    RefDS(_5);
    DeRef(_result__602);
    _result__602 = _5;

    /** 	for i = CS_FIRST + 1 to CS_LAST - 1 do*/
    _194 = 1;
    _195 = 19;
    {
        int _i_604;
        _i_604 = 1;
L1: 
        if (_i_604 > 19){
            goto L2; // [18] 48
        }

        /** 		result_ = append(result_, {i, Defined_Sets[i]} )*/
        _2 = (int)SEQ_PTR(_13Defined_Sets_532);
        _196 = (int)*(((s1_ptr)_2)->base + _i_604);
        Ref(_196);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _i_604;
        ((int *)_2)[2] = _196;
        _197 = MAKE_SEQ(_1);
        _196 = NOVALUE;
        RefDS(_197);
        Append(&_result__602, _result__602, _197);
        DeRefDS(_197);
        _197 = NOVALUE;

        /** 	end for*/
        _i_604 = _i_604 + 1;
        goto L1; // [43] 25
L2: 
        ;
    }

    /** 	return result_*/
    DeRef(_194);
    _194 = NOVALUE;
    DeRef(_195);
    _195 = NOVALUE;
    return _result__602;
    ;
}


void _13set_charsets(int _charset_list_612)
{
    int _220 = NOVALUE;
    int _219 = NOVALUE;
    int _218 = NOVALUE;
    int _217 = NOVALUE;
    int _216 = NOVALUE;
    int _215 = NOVALUE;
    int _214 = NOVALUE;
    int _213 = NOVALUE;
    int _212 = NOVALUE;
    int _211 = NOVALUE;
    int _210 = NOVALUE;
    int _209 = NOVALUE;
    int _208 = NOVALUE;
    int _207 = NOVALUE;
    int _206 = NOVALUE;
    int _205 = NOVALUE;
    int _204 = NOVALUE;
    int _203 = NOVALUE;
    int _202 = NOVALUE;
    int _201 = NOVALUE;
    int _200 = NOVALUE;
    int _199 = NOVALUE;
    int _0, _1, _2;
    

    /** 	for i = 1 to length(charset_list) do*/
    if (IS_SEQUENCE(_charset_list_612)){
            _199 = SEQ_PTR(_charset_list_612)->length;
    }
    else {
        _199 = 1;
    }
    {
        int _i_614;
        _i_614 = 1;
L1: 
        if (_i_614 > _199){
            goto L2; // [8] 129
        }

        /** 		if sequence(charset_list[i]) and length(charset_list[i]) = 2 then*/
        _2 = (int)SEQ_PTR(_charset_list_612);
        _200 = (int)*(((s1_ptr)_2)->base + _i_614);
        _201 = IS_SEQUENCE(_200);
        _200 = NOVALUE;
        if (_201 == 0) {
            goto L3; // [24] 122
        }
        _2 = (int)SEQ_PTR(_charset_list_612);
        _203 = (int)*(((s1_ptr)_2)->base + _i_614);
        if (IS_SEQUENCE(_203)){
                _204 = SEQ_PTR(_203)->length;
        }
        else {
            _204 = 1;
        }
        _203 = NOVALUE;
        _205 = (_204 == 2);
        _204 = NOVALUE;
        if (_205 == 0)
        {
            DeRef(_205);
            _205 = NOVALUE;
            goto L3; // [40] 122
        }
        else{
            DeRef(_205);
            _205 = NOVALUE;
        }

        /** 			if integer(charset_list[i][1]) and charset_list[i][1] > CS_FIRST and charset_list[i][1] < CS_LAST then*/
        _2 = (int)SEQ_PTR(_charset_list_612);
        _206 = (int)*(((s1_ptr)_2)->base + _i_614);
        _2 = (int)SEQ_PTR(_206);
        _207 = (int)*(((s1_ptr)_2)->base + 1);
        _206 = NOVALUE;
        if (IS_ATOM_INT(_207))
        _208 = 1;
        else if (IS_ATOM_DBL(_207))
        _208 = IS_ATOM_INT(DoubleToInt(_207));
        else
        _208 = 0;
        _207 = NOVALUE;
        if (_208 == 0) {
            _209 = 0;
            goto L4; // [56] 76
        }
        _2 = (int)SEQ_PTR(_charset_list_612);
        _210 = (int)*(((s1_ptr)_2)->base + _i_614);
        _2 = (int)SEQ_PTR(_210);
        _211 = (int)*(((s1_ptr)_2)->base + 1);
        _210 = NOVALUE;
        if (IS_ATOM_INT(_211)) {
            _212 = (_211 > 0);
        }
        else {
            _212 = binary_op(GREATER, _211, 0);
        }
        _211 = NOVALUE;
        if (IS_ATOM_INT(_212))
        _209 = (_212 != 0);
        else
        _209 = DBL_PTR(_212)->dbl != 0.0;
L4: 
        if (_209 == 0) {
            goto L5; // [76] 121
        }
        _2 = (int)SEQ_PTR(_charset_list_612);
        _214 = (int)*(((s1_ptr)_2)->base + _i_614);
        _2 = (int)SEQ_PTR(_214);
        _215 = (int)*(((s1_ptr)_2)->base + 1);
        _214 = NOVALUE;
        if (IS_ATOM_INT(_215)) {
            _216 = (_215 < 20);
        }
        else {
            _216 = binary_op(LESS, _215, 20);
        }
        _215 = NOVALUE;
        if (_216 == 0) {
            DeRef(_216);
            _216 = NOVALUE;
            goto L5; // [93] 121
        }
        else {
            if (!IS_ATOM_INT(_216) && DBL_PTR(_216)->dbl == 0.0){
                DeRef(_216);
                _216 = NOVALUE;
                goto L5; // [93] 121
            }
            DeRef(_216);
            _216 = NOVALUE;
        }
        DeRef(_216);
        _216 = NOVALUE;

        /** 				Defined_Sets[charset_list[i][1]] = charset_list[i][2]*/
        _2 = (int)SEQ_PTR(_charset_list_612);
        _217 = (int)*(((s1_ptr)_2)->base + _i_614);
        _2 = (int)SEQ_PTR(_217);
        _218 = (int)*(((s1_ptr)_2)->base + 1);
        _217 = NOVALUE;
        _2 = (int)SEQ_PTR(_charset_list_612);
        _219 = (int)*(((s1_ptr)_2)->base + _i_614);
        _2 = (int)SEQ_PTR(_219);
        _220 = (int)*(((s1_ptr)_2)->base + 2);
        _219 = NOVALUE;
        Ref(_220);
        _2 = (int)SEQ_PTR(_13Defined_Sets_532);
        if (!IS_ATOM_INT(_218))
        _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_218)->dbl));
        else
        _2 = (int)(((s1_ptr)_2)->base + _218);
        _1 = *(int *)_2;
        *(int *)_2 = _220;
        if( _1 != _220 ){
            DeRef(_1);
        }
        _220 = NOVALUE;
L5: 
L3: 

        /** 	end for*/
        _i_614 = _i_614 + 1;
        goto L1; // [124] 15
L2: 
        ;
    }

    /** end procedure*/
    DeRefDS(_charset_list_612);
    _203 = NOVALUE;
    _218 = NOVALUE;
    DeRef(_212);
    _212 = NOVALUE;
    return;
    ;
}


int _13boolean(int _test_data_641)
{
    int _223 = NOVALUE;
    int _222 = NOVALUE;
    int _221 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return find(test_data,{1,0}) != 0*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = 0;
    _221 = MAKE_SEQ(_1);
    _222 = find_from(_test_data_641, _221, 1);
    DeRefDS(_221);
    _221 = NOVALUE;
    _223 = (_222 != 0);
    _222 = NOVALUE;
    DeRef(_test_data_641);
    return _223;
    ;
}


int _13t_boolean(int _test_data_647)
{
    int _225 = NOVALUE;
    int _224 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return char_test(test_data, Defined_Sets[CS_Boolean])*/
    _2 = (int)SEQ_PTR(_13Defined_Sets_532);
    _224 = (int)*(((s1_ptr)_2)->base + 19);
    Ref(_test_data_647);
    Ref(_224);
    _225 = _13char_test(_test_data_647, _224);
    _224 = NOVALUE;
    DeRef(_test_data_647);
    return _225;
    ;
}


int _13t_alnum(int _test_data_652)
{
    int _227 = NOVALUE;
    int _226 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return char_test(test_data, Defined_Sets[CS_Alphanumeric])*/
    _2 = (int)SEQ_PTR(_13Defined_Sets_532);
    _226 = (int)*(((s1_ptr)_2)->base + 10);
    Ref(_test_data_652);
    Ref(_226);
    _227 = _13char_test(_test_data_652, _226);
    _226 = NOVALUE;
    DeRef(_test_data_652);
    return _227;
    ;
}


int _13t_identifier(int _test_data_657)
{
    int _237 = NOVALUE;
    int _236 = NOVALUE;
    int _235 = NOVALUE;
    int _234 = NOVALUE;
    int _233 = NOVALUE;
    int _232 = NOVALUE;
    int _231 = NOVALUE;
    int _230 = NOVALUE;
    int _229 = NOVALUE;
    int _228 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if t_digit(test_data) then*/
    Ref(_test_data_657);
    _228 = _13t_digit(_test_data_657);
    if (_228 == 0) {
        DeRef(_228);
        _228 = NOVALUE;
        goto L1; // [7] 19
    }
    else {
        if (!IS_ATOM_INT(_228) && DBL_PTR(_228)->dbl == 0.0){
            DeRef(_228);
            _228 = NOVALUE;
            goto L1; // [7] 19
        }
        DeRef(_228);
        _228 = NOVALUE;
    }
    DeRef(_228);
    _228 = NOVALUE;

    /** 		return 0*/
    DeRef(_test_data_657);
    return 0;
    goto L2; // [16] 63
L1: 

    /** 	elsif sequence(test_data) and length(test_data) > 0 and t_digit(test_data[1]) then*/
    _229 = IS_SEQUENCE(_test_data_657);
    if (_229 == 0) {
        _230 = 0;
        goto L3; // [24] 39
    }
    if (IS_SEQUENCE(_test_data_657)){
            _231 = SEQ_PTR(_test_data_657)->length;
    }
    else {
        _231 = 1;
    }
    _232 = (_231 > 0);
    _231 = NOVALUE;
    _230 = (_232 != 0);
L3: 
    if (_230 == 0) {
        goto L4; // [39] 62
    }
    _2 = (int)SEQ_PTR(_test_data_657);
    _234 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_234);
    _235 = _13t_digit(_234);
    _234 = NOVALUE;
    if (_235 == 0) {
        DeRef(_235);
        _235 = NOVALUE;
        goto L4; // [52] 62
    }
    else {
        if (!IS_ATOM_INT(_235) && DBL_PTR(_235)->dbl == 0.0){
            DeRef(_235);
            _235 = NOVALUE;
            goto L4; // [52] 62
        }
        DeRef(_235);
        _235 = NOVALUE;
    }
    DeRef(_235);
    _235 = NOVALUE;

    /** 		return 0*/
    DeRef(_test_data_657);
    DeRef(_232);
    _232 = NOVALUE;
    return 0;
L4: 
L2: 

    /** 	return char_test(test_data, Defined_Sets[CS_Identifier])*/
    _2 = (int)SEQ_PTR(_13Defined_Sets_532);
    _236 = (int)*(((s1_ptr)_2)->base + 11);
    Ref(_test_data_657);
    Ref(_236);
    _237 = _13char_test(_test_data_657, _236);
    _236 = NOVALUE;
    DeRef(_test_data_657);
    DeRef(_232);
    _232 = NOVALUE;
    return _237;
    ;
}


int _13t_alpha(int _test_data_674)
{
    int _239 = NOVALUE;
    int _238 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return char_test(test_data, Defined_Sets[CS_Alphabetic])*/
    _2 = (int)SEQ_PTR(_13Defined_Sets_532);
    _238 = (int)*(((s1_ptr)_2)->base + 12);
    Ref(_test_data_674);
    Ref(_238);
    _239 = _13char_test(_test_data_674, _238);
    _238 = NOVALUE;
    DeRef(_test_data_674);
    return _239;
    ;
}


int _13t_ascii(int _test_data_679)
{
    int _241 = NOVALUE;
    int _240 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return char_test(test_data, Defined_Sets[CS_ASCII])*/
    _2 = (int)SEQ_PTR(_13Defined_Sets_532);
    _240 = (int)*(((s1_ptr)_2)->base + 13);
    Ref(_test_data_679);
    Ref(_240);
    _241 = _13char_test(_test_data_679, _240);
    _240 = NOVALUE;
    DeRef(_test_data_679);
    return _241;
    ;
}


int _13t_cntrl(int _test_data_684)
{
    int _243 = NOVALUE;
    int _242 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return char_test(test_data, Defined_Sets[CS_Control])*/
    _2 = (int)SEQ_PTR(_13Defined_Sets_532);
    _242 = (int)*(((s1_ptr)_2)->base + 14);
    Ref(_test_data_684);
    Ref(_242);
    _243 = _13char_test(_test_data_684, _242);
    _242 = NOVALUE;
    DeRef(_test_data_684);
    return _243;
    ;
}


int _13t_digit(int _test_data_689)
{
    int _245 = NOVALUE;
    int _244 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return char_test(test_data, Defined_Sets[CS_Digit])*/
    _2 = (int)SEQ_PTR(_13Defined_Sets_532);
    _244 = (int)*(((s1_ptr)_2)->base + 15);
    Ref(_test_data_689);
    Ref(_244);
    _245 = _13char_test(_test_data_689, _244);
    _244 = NOVALUE;
    DeRef(_test_data_689);
    return _245;
    ;
}


int _13t_graph(int _test_data_694)
{
    int _247 = NOVALUE;
    int _246 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return char_test(test_data, Defined_Sets[CS_Graphic])*/
    _2 = (int)SEQ_PTR(_13Defined_Sets_532);
    _246 = (int)*(((s1_ptr)_2)->base + 16);
    Ref(_test_data_694);
    Ref(_246);
    _247 = _13char_test(_test_data_694, _246);
    _246 = NOVALUE;
    DeRef(_test_data_694);
    return _247;
    ;
}


int _13t_specword(int _test_data_699)
{
    int _249 = NOVALUE;
    int _248 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return char_test(test_data, Defined_Sets[CS_SpecWord])*/
    _2 = (int)SEQ_PTR(_13Defined_Sets_532);
    _248 = (int)*(((s1_ptr)_2)->base + 18);
    Ref(_test_data_699);
    Ref(_248);
    _249 = _13char_test(_test_data_699, _248);
    _248 = NOVALUE;
    DeRef(_test_data_699);
    return _249;
    ;
}


int _13t_bytearray(int _test_data_704)
{
    int _251 = NOVALUE;
    int _250 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return char_test(test_data, Defined_Sets[CS_Bytes])*/
    _2 = (int)SEQ_PTR(_13Defined_Sets_532);
    _250 = (int)*(((s1_ptr)_2)->base + 17);
    Ref(_test_data_704);
    Ref(_250);
    _251 = _13char_test(_test_data_704, _250);
    _250 = NOVALUE;
    DeRef(_test_data_704);
    return _251;
    ;
}


int _13t_lower(int _test_data_709)
{
    int _253 = NOVALUE;
    int _252 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return char_test(test_data, Defined_Sets[CS_Lowercase])*/
    _2 = (int)SEQ_PTR(_13Defined_Sets_532);
    _252 = (int)*(((s1_ptr)_2)->base + 8);
    Ref(_test_data_709);
    Ref(_252);
    _253 = _13char_test(_test_data_709, _252);
    _252 = NOVALUE;
    DeRef(_test_data_709);
    return _253;
    ;
}


int _13t_print(int _test_data_714)
{
    int _255 = NOVALUE;
    int _254 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return char_test(test_data, Defined_Sets[CS_Printable])*/
    _2 = (int)SEQ_PTR(_13Defined_Sets_532);
    _254 = (int)*(((s1_ptr)_2)->base + 6);
    Ref(_test_data_714);
    Ref(_254);
    _255 = _13char_test(_test_data_714, _254);
    _254 = NOVALUE;
    DeRef(_test_data_714);
    return _255;
    ;
}


int _13t_display(int _test_data_719)
{
    int _257 = NOVALUE;
    int _256 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return char_test(test_data, Defined_Sets[CS_Displayable])*/
    _2 = (int)SEQ_PTR(_13Defined_Sets_532);
    _256 = (int)*(((s1_ptr)_2)->base + 7);
    Ref(_test_data_719);
    Ref(_256);
    _257 = _13char_test(_test_data_719, _256);
    _256 = NOVALUE;
    DeRef(_test_data_719);
    return _257;
    ;
}


int _13t_punct(int _test_data_724)
{
    int _259 = NOVALUE;
    int _258 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return char_test(test_data, Defined_Sets[CS_Punctuation])*/
    _2 = (int)SEQ_PTR(_13Defined_Sets_532);
    _258 = (int)*(((s1_ptr)_2)->base + 5);
    Ref(_test_data_724);
    Ref(_258);
    _259 = _13char_test(_test_data_724, _258);
    _258 = NOVALUE;
    DeRef(_test_data_724);
    return _259;
    ;
}


int _13t_space(int _test_data_729)
{
    int _261 = NOVALUE;
    int _260 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return char_test(test_data, Defined_Sets[CS_Whitespace])*/
    _2 = (int)SEQ_PTR(_13Defined_Sets_532);
    _260 = (int)*(((s1_ptr)_2)->base + 4);
    Ref(_test_data_729);
    Ref(_260);
    _261 = _13char_test(_test_data_729, _260);
    _260 = NOVALUE;
    DeRef(_test_data_729);
    return _261;
    ;
}


int _13t_upper(int _test_data_734)
{
    int _263 = NOVALUE;
    int _262 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return char_test(test_data, Defined_Sets[CS_Uppercase])*/
    _2 = (int)SEQ_PTR(_13Defined_Sets_532);
    _262 = (int)*(((s1_ptr)_2)->base + 9);
    Ref(_test_data_734);
    Ref(_262);
    _263 = _13char_test(_test_data_734, _262);
    _262 = NOVALUE;
    DeRef(_test_data_734);
    return _263;
    ;
}


int _13t_xdigit(int _test_data_739)
{
    int _265 = NOVALUE;
    int _264 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return char_test(test_data, Defined_Sets[CS_Hexadecimal])*/
    _2 = (int)SEQ_PTR(_13Defined_Sets_532);
    _264 = (int)*(((s1_ptr)_2)->base + 3);
    Ref(_test_data_739);
    Ref(_264);
    _265 = _13char_test(_test_data_739, _264);
    _264 = NOVALUE;
    DeRef(_test_data_739);
    return _265;
    ;
}


int _13t_vowel(int _test_data_744)
{
    int _267 = NOVALUE;
    int _266 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return char_test(test_data, Defined_Sets[CS_Vowel])*/
    _2 = (int)SEQ_PTR(_13Defined_Sets_532);
    _266 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_test_data_744);
    Ref(_266);
    _267 = _13char_test(_test_data_744, _266);
    _266 = NOVALUE;
    DeRef(_test_data_744);
    return _267;
    ;
}


int _13t_consonant(int _test_data_749)
{
    int _269 = NOVALUE;
    int _268 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return char_test(test_data, Defined_Sets[CS_Consonant])*/
    _2 = (int)SEQ_PTR(_13Defined_Sets_532);
    _268 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_test_data_749);
    Ref(_268);
    _269 = _13char_test(_test_data_749, _268);
    _268 = NOVALUE;
    DeRef(_test_data_749);
    return _269;
    ;
}


int _13integer_array(int _x_754)
{
    int _274 = NOVALUE;
    int _273 = NOVALUE;
    int _272 = NOVALUE;
    int _270 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not sequence(x) then*/
    _270 = IS_SEQUENCE(_x_754);
    if (_270 != 0)
    goto L1; // [6] 16
    _270 = NOVALUE;

    /** 		return 0*/
    DeRef(_x_754);
    return 0;
L1: 

    /** 	for i = 1 to length(x) do*/
    if (IS_SEQUENCE(_x_754)){
            _272 = SEQ_PTR(_x_754)->length;
    }
    else {
        _272 = 1;
    }
    {
        int _i_759;
        _i_759 = 1;
L2: 
        if (_i_759 > _272){
            goto L3; // [21] 54
        }

        /** 		if not integer(x[i]) then*/
        _2 = (int)SEQ_PTR(_x_754);
        _273 = (int)*(((s1_ptr)_2)->base + _i_759);
        if (IS_ATOM_INT(_273))
        _274 = 1;
        else if (IS_ATOM_DBL(_273))
        _274 = IS_ATOM_INT(DoubleToInt(_273));
        else
        _274 = 0;
        _273 = NOVALUE;
        if (_274 != 0)
        goto L4; // [37] 47
        _274 = NOVALUE;

        /** 			return 0*/
        DeRef(_x_754);
        return 0;
L4: 

        /** 	end for*/
        _i_759 = _i_759 + 1;
        goto L2; // [49] 28
L3: 
        ;
    }

    /** 	return 1*/
    DeRef(_x_754);
    return 1;
    ;
}


int _13t_text(int _x_767)
{
    int _282 = NOVALUE;
    int _280 = NOVALUE;
    int _279 = NOVALUE;
    int _278 = NOVALUE;
    int _276 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not sequence(x) then*/
    _276 = IS_SEQUENCE(_x_767);
    if (_276 != 0)
    goto L1; // [6] 16
    _276 = NOVALUE;

    /** 		return 0*/
    DeRef(_x_767);
    return 0;
L1: 

    /** 	for i = 1 to length(x) do*/
    if (IS_SEQUENCE(_x_767)){
            _278 = SEQ_PTR(_x_767)->length;
    }
    else {
        _278 = 1;
    }
    {
        int _i_772;
        _i_772 = 1;
L2: 
        if (_i_772 > _278){
            goto L3; // [21] 71
        }

        /** 		if not integer(x[i]) then*/
        _2 = (int)SEQ_PTR(_x_767);
        _279 = (int)*(((s1_ptr)_2)->base + _i_772);
        if (IS_ATOM_INT(_279))
        _280 = 1;
        else if (IS_ATOM_DBL(_279))
        _280 = IS_ATOM_INT(DoubleToInt(_279));
        else
        _280 = 0;
        _279 = NOVALUE;
        if (_280 != 0)
        goto L4; // [37] 47
        _280 = NOVALUE;

        /** 			return 0*/
        DeRef(_x_767);
        return 0;
L4: 

        /** 		if x[i] < 0 then*/
        _2 = (int)SEQ_PTR(_x_767);
        _282 = (int)*(((s1_ptr)_2)->base + _i_772);
        if (binary_op_a(GREATEREQ, _282, 0)){
            _282 = NOVALUE;
            goto L5; // [53] 64
        }
        _282 = NOVALUE;

        /** 			return 0*/
        DeRef(_x_767);
        return 0;
L5: 

        /** 	end for*/
        _i_772 = _i_772 + 1;
        goto L2; // [66] 28
L3: 
        ;
    }

    /** 	return 1*/
    DeRef(_x_767);
    return 1;
    ;
}


int _13number_array(int _x_783)
{
    int _288 = NOVALUE;
    int _287 = NOVALUE;
    int _286 = NOVALUE;
    int _284 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not sequence(x) then*/
    _284 = IS_SEQUENCE(_x_783);
    if (_284 != 0)
    goto L1; // [6] 16
    _284 = NOVALUE;

    /** 		return 0*/
    DeRef(_x_783);
    return 0;
L1: 

    /** 	for i = 1 to length(x) do*/
    if (IS_SEQUENCE(_x_783)){
            _286 = SEQ_PTR(_x_783)->length;
    }
    else {
        _286 = 1;
    }
    {
        int _i_788;
        _i_788 = 1;
L2: 
        if (_i_788 > _286){
            goto L3; // [21] 54
        }

        /** 		if not atom(x[i]) then*/
        _2 = (int)SEQ_PTR(_x_783);
        _287 = (int)*(((s1_ptr)_2)->base + _i_788);
        _288 = IS_ATOM(_287);
        _287 = NOVALUE;
        if (_288 != 0)
        goto L4; // [37] 47
        _288 = NOVALUE;

        /** 			return 0*/
        DeRef(_x_783);
        return 0;
L4: 

        /** 	end for*/
        _i_788 = _i_788 + 1;
        goto L2; // [49] 28
L3: 
        ;
    }

    /** 	return 1*/
    DeRef(_x_783);
    return 1;
    ;
}


int _13sequence_array(int _x_796)
{
    int _294 = NOVALUE;
    int _293 = NOVALUE;
    int _292 = NOVALUE;
    int _290 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not sequence(x) then*/
    _290 = IS_SEQUENCE(_x_796);
    if (_290 != 0)
    goto L1; // [6] 16
    _290 = NOVALUE;

    /** 		return 0*/
    DeRef(_x_796);
    return 0;
L1: 

    /** 	for i = 1 to length(x) do*/
    if (IS_SEQUENCE(_x_796)){
            _292 = SEQ_PTR(_x_796)->length;
    }
    else {
        _292 = 1;
    }
    {
        int _i_801;
        _i_801 = 1;
L2: 
        if (_i_801 > _292){
            goto L3; // [21] 54
        }

        /** 		if not sequence(x[i]) then*/
        _2 = (int)SEQ_PTR(_x_796);
        _293 = (int)*(((s1_ptr)_2)->base + _i_801);
        _294 = IS_SEQUENCE(_293);
        _293 = NOVALUE;
        if (_294 != 0)
        goto L4; // [37] 47
        _294 = NOVALUE;

        /** 			return 0*/
        DeRef(_x_796);
        return 0;
L4: 

        /** 	end for*/
        _i_801 = _i_801 + 1;
        goto L2; // [49] 28
L3: 
        ;
    }

    /** 	return 1*/
    DeRef(_x_796);
    return 1;
    ;
}


int _13ascii_string(int _x_809)
{
    int _304 = NOVALUE;
    int _302 = NOVALUE;
    int _300 = NOVALUE;
    int _299 = NOVALUE;
    int _298 = NOVALUE;
    int _296 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not sequence(x) then*/
    _296 = IS_SEQUENCE(_x_809);
    if (_296 != 0)
    goto L1; // [6] 16
    _296 = NOVALUE;

    /** 		return 0*/
    DeRef(_x_809);
    return 0;
L1: 

    /** 	for i = 1 to length(x) do*/
    if (IS_SEQUENCE(_x_809)){
            _298 = SEQ_PTR(_x_809)->length;
    }
    else {
        _298 = 1;
    }
    {
        int _i_814;
        _i_814 = 1;
L2: 
        if (_i_814 > _298){
            goto L3; // [21] 88
        }

        /** 		if not integer(x[i]) then*/
        _2 = (int)SEQ_PTR(_x_809);
        _299 = (int)*(((s1_ptr)_2)->base + _i_814);
        if (IS_ATOM_INT(_299))
        _300 = 1;
        else if (IS_ATOM_DBL(_299))
        _300 = IS_ATOM_INT(DoubleToInt(_299));
        else
        _300 = 0;
        _299 = NOVALUE;
        if (_300 != 0)
        goto L4; // [37] 47
        _300 = NOVALUE;

        /** 			return 0*/
        DeRef(_x_809);
        return 0;
L4: 

        /** 		if x[i] < 0 then*/
        _2 = (int)SEQ_PTR(_x_809);
        _302 = (int)*(((s1_ptr)_2)->base + _i_814);
        if (binary_op_a(GREATEREQ, _302, 0)){
            _302 = NOVALUE;
            goto L5; // [53] 64
        }
        _302 = NOVALUE;

        /** 			return 0*/
        DeRef(_x_809);
        return 0;
L5: 

        /** 		if x[i] > 127 then*/
        _2 = (int)SEQ_PTR(_x_809);
        _304 = (int)*(((s1_ptr)_2)->base + _i_814);
        if (binary_op_a(LESSEQ, _304, 127)){
            _304 = NOVALUE;
            goto L6; // [70] 81
        }
        _304 = NOVALUE;

        /** 			return 0*/
        DeRef(_x_809);
        return 0;
L6: 

        /** 	end for*/
        _i_814 = _i_814 + 1;
        goto L2; // [83] 28
L3: 
        ;
    }

    /** 	return 1*/
    DeRef(_x_809);
    return 1;
    ;
}


int _13string(int _x_828)
{
    int _314 = NOVALUE;
    int _312 = NOVALUE;
    int _310 = NOVALUE;
    int _309 = NOVALUE;
    int _308 = NOVALUE;
    int _306 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not sequence(x) then*/
    _306 = IS_SEQUENCE(_x_828);
    if (_306 != 0)
    goto L1; // [6] 16
    _306 = NOVALUE;

    /** 		return 0*/
    DeRef(_x_828);
    return 0;
L1: 

    /** 	for i = 1 to length(x) do*/
    if (IS_SEQUENCE(_x_828)){
            _308 = SEQ_PTR(_x_828)->length;
    }
    else {
        _308 = 1;
    }
    {
        int _i_833;
        _i_833 = 1;
L2: 
        if (_i_833 > _308){
            goto L3; // [21] 88
        }

        /** 		if not integer(x[i]) then*/
        _2 = (int)SEQ_PTR(_x_828);
        _309 = (int)*(((s1_ptr)_2)->base + _i_833);
        if (IS_ATOM_INT(_309))
        _310 = 1;
        else if (IS_ATOM_DBL(_309))
        _310 = IS_ATOM_INT(DoubleToInt(_309));
        else
        _310 = 0;
        _309 = NOVALUE;
        if (_310 != 0)
        goto L4; // [37] 47
        _310 = NOVALUE;

        /** 			return 0*/
        DeRef(_x_828);
        return 0;
L4: 

        /** 		if x[i] < 0 then*/
        _2 = (int)SEQ_PTR(_x_828);
        _312 = (int)*(((s1_ptr)_2)->base + _i_833);
        if (binary_op_a(GREATEREQ, _312, 0)){
            _312 = NOVALUE;
            goto L5; // [53] 64
        }
        _312 = NOVALUE;

        /** 			return 0*/
        DeRef(_x_828);
        return 0;
L5: 

        /** 		if x[i] > 255 then*/
        _2 = (int)SEQ_PTR(_x_828);
        _314 = (int)*(((s1_ptr)_2)->base + _i_833);
        if (binary_op_a(LESSEQ, _314, 255)){
            _314 = NOVALUE;
            goto L6; // [70] 81
        }
        _314 = NOVALUE;

        /** 			return 0*/
        DeRef(_x_828);
        return 0;
L6: 

        /** 	end for*/
        _i_833 = _i_833 + 1;
        goto L2; // [83] 28
L3: 
        ;
    }

    /** 	return 1*/
    DeRef(_x_828);
    return 1;
    ;
}


int _13cstring(int _x_847)
{
    int _324 = NOVALUE;
    int _322 = NOVALUE;
    int _320 = NOVALUE;
    int _319 = NOVALUE;
    int _318 = NOVALUE;
    int _316 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not sequence(x) then*/
    _316 = IS_SEQUENCE(_x_847);
    if (_316 != 0)
    goto L1; // [6] 16
    _316 = NOVALUE;

    /** 		return 0*/
    DeRef(_x_847);
    return 0;
L1: 

    /** 	for i = 1 to length(x) do*/
    if (IS_SEQUENCE(_x_847)){
            _318 = SEQ_PTR(_x_847)->length;
    }
    else {
        _318 = 1;
    }
    {
        int _i_852;
        _i_852 = 1;
L2: 
        if (_i_852 > _318){
            goto L3; // [21] 88
        }

        /** 		if not integer(x[i]) then*/
        _2 = (int)SEQ_PTR(_x_847);
        _319 = (int)*(((s1_ptr)_2)->base + _i_852);
        if (IS_ATOM_INT(_319))
        _320 = 1;
        else if (IS_ATOM_DBL(_319))
        _320 = IS_ATOM_INT(DoubleToInt(_319));
        else
        _320 = 0;
        _319 = NOVALUE;
        if (_320 != 0)
        goto L4; // [37] 47
        _320 = NOVALUE;

        /** 			return 0*/
        DeRef(_x_847);
        return 0;
L4: 

        /** 		if x[i] <= 0 then*/
        _2 = (int)SEQ_PTR(_x_847);
        _322 = (int)*(((s1_ptr)_2)->base + _i_852);
        if (binary_op_a(GREATER, _322, 0)){
            _322 = NOVALUE;
            goto L5; // [53] 64
        }
        _322 = NOVALUE;

        /** 			return 0*/
        DeRef(_x_847);
        return 0;
L5: 

        /** 		if x[i] > 255 then*/
        _2 = (int)SEQ_PTR(_x_847);
        _324 = (int)*(((s1_ptr)_2)->base + _i_852);
        if (binary_op_a(LESSEQ, _324, 255)){
            _324 = NOVALUE;
            goto L6; // [70] 81
        }
        _324 = NOVALUE;

        /** 			return 0*/
        DeRef(_x_847);
        return 0;
L6: 

        /** 	end for*/
        _i_852 = _i_852 + 1;
        goto L2; // [83] 28
L3: 
        ;
    }

    /** 	return 1*/
    DeRef(_x_847);
    return 1;
    ;
}



// 0x2BBFDA3A
