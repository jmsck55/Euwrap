// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int _67advance(int _pc_52687, int _code_52688)
{
    int _27222 = NOVALUE;
    int _27220 = NOVALUE;
    int _0, _1, _2;
    

    /** 	prev_pc = pc*/
    _67prev_pc_52672 = _pc_52687;

    /** 	if pc > length( code ) then*/
    if (IS_SEQUENCE(_code_52688)){
            _27220 = SEQ_PTR(_code_52688)->length;
    }
    else {
        _27220 = 1;
    }
    if (_pc_52687 <= _27220)
    goto L1; // [15] 26

    /** 		return pc*/
    DeRefDS(_code_52688);
    return _pc_52687;
L1: 

    /** 	return shift:advance( pc, code )*/
    RefDS(_code_52688);
    _27222 = _65advance(_pc_52687, _code_52688);
    DeRefDS(_code_52688);
    return _27222;
    ;
}


void _67shift(int _start_52695, int _amount_52696, int _bound_52697)
{
    int _temp_LineTable_52698 = NOVALUE;
    int _temp_Code_52700 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_amount_52696)) {
        _1 = (long)(DBL_PTR(_amount_52696)->dbl);
        DeRefDS(_amount_52696);
        _amount_52696 = _1;
    }

    /** 		temp_LineTable = LineTable,*/
    RefDS(_35LineTable_16333);
    DeRef(_temp_LineTable_52698);
    _temp_LineTable_52698 = _35LineTable_16333;

    /** 		temp_Code = Code*/
    RefDS(_35Code_16332);
    DeRef(_temp_Code_52700);
    _temp_Code_52700 = _35Code_16332;

    /** 	LineTable = {}*/
    RefDS(_22023);
    DeRefDS(_35LineTable_16333);
    _35LineTable_16333 = _22023;

    /** 	Code = inline_code*/
    RefDS(_67inline_code_52664);
    DeRefDS(_35Code_16332);
    _35Code_16332 = _67inline_code_52664;

    /** 	inline_code = {}*/
    RefDS(_22023);
    DeRefDS(_67inline_code_52664);
    _67inline_code_52664 = _22023;

    /** 	shift:shift( start, amount, bound )*/
    _65shift(_start_52695, _amount_52696, _bound_52697);

    /** 	LineTable = temp_LineTable*/
    RefDS(_temp_LineTable_52698);
    DeRefDS(_35LineTable_16333);
    _35LineTable_16333 = _temp_LineTable_52698;

    /** 	inline_code = Code*/
    RefDS(_35Code_16332);
    DeRefDS(_67inline_code_52664);
    _67inline_code_52664 = _35Code_16332;

    /** 	Code = temp_Code*/
    RefDS(_temp_Code_52700);
    DeRefDS(_35Code_16332);
    _35Code_16332 = _temp_Code_52700;

    /** end procedure*/
    DeRefDS(_temp_LineTable_52698);
    DeRefDS(_temp_Code_52700);
    return;
    ;
}


void _67insert_code(int _code_52709, int _index_52710)
{
    int _27224 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_index_52710)) {
        _1 = (long)(DBL_PTR(_index_52710)->dbl);
        DeRefDS(_index_52710);
        _index_52710 = _1;
    }

    /** 	inline_code = splice( inline_code, code, index )*/
    {
        s1_ptr assign_space;
        insert_pos = _index_52710;
        if (insert_pos <= 0) {
            Concat(&_67inline_code_52664,_code_52709,_67inline_code_52664);
        }
        else if (insert_pos > SEQ_PTR(_67inline_code_52664)->length){
            Concat(&_67inline_code_52664,_67inline_code_52664,_code_52709);
        }
        else if (IS_SEQUENCE(_code_52709)) {
            if( _67inline_code_52664 != _67inline_code_52664 || SEQ_PTR( _67inline_code_52664 )->ref != 1 ){
                DeRef( _67inline_code_52664 );
                RefDS( _67inline_code_52664 );
            }
            assign_space = Add_internal_space( _67inline_code_52664, insert_pos,((s1_ptr)SEQ_PTR(_code_52709))->length);
            assign_slice_seq = &assign_space;
            assign_space = Copy_elements( insert_pos, SEQ_PTR(_code_52709), _67inline_code_52664 == _67inline_code_52664 );
            _67inline_code_52664 = MAKE_SEQ( assign_space );
        }
        else {
            if( _67inline_code_52664 != _67inline_code_52664 && SEQ_PTR( _67inline_code_52664 )->ref != 1 ){
                _67inline_code_52664 = Insert( _67inline_code_52664, _code_52709, insert_pos);
            }
            else {
                DeRef( _67inline_code_52664 );
                RefDS( _67inline_code_52664 );
                _67inline_code_52664 = Insert( _67inline_code_52664, _code_52709, insert_pos);
            }
        }
    }

    /** 	shift( index, length( code ) )*/
    if (IS_SEQUENCE(_code_52709)){
            _27224 = SEQ_PTR(_code_52709)->length;
    }
    else {
        _27224 = 1;
    }
    _67shift(_index_52710, _27224, _index_52710);
    _27224 = NOVALUE;

    /** end procedure*/
    DeRefDS(_code_52709);
    return;
    ;
}


void _67replace_code(int _code_52715, int _start_52716, int _finish_52717)
{
    int _27229 = NOVALUE;
    int _27228 = NOVALUE;
    int _27227 = NOVALUE;
    int _27226 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_start_52716)) {
        _1 = (long)(DBL_PTR(_start_52716)->dbl);
        DeRefDS(_start_52716);
        _start_52716 = _1;
    }
    if (!IS_ATOM_INT(_finish_52717)) {
        _1 = (long)(DBL_PTR(_finish_52717)->dbl);
        DeRefDS(_finish_52717);
        _finish_52717 = _1;
    }

    /** 	inline_code = replace( inline_code, code, start, finish )*/
    {
        int p1 = _67inline_code_52664;
        int p2 = _code_52715;
        int p3 = _start_52716;
        int p4 = _finish_52717;
        struct replace_block replace_params;
        replace_params.copy_to   = &p1;
        replace_params.copy_from = &p2;
        replace_params.start     = &p3;
        replace_params.stop      = &p4;
        replace_params.target    = &_67inline_code_52664;
        Replace( &replace_params );
    }

    /** 	shift( start , length( code ) - (finish - start + 1), finish )*/
    if (IS_SEQUENCE(_code_52715)){
            _27226 = SEQ_PTR(_code_52715)->length;
    }
    else {
        _27226 = 1;
    }
    _27227 = _finish_52717 - _start_52716;
    if ((long)((unsigned long)_27227 +(unsigned long) HIGH_BITS) >= 0){
        _27227 = NewDouble((double)_27227);
    }
    if (IS_ATOM_INT(_27227)) {
        _27228 = _27227 + 1;
        if (_27228 > MAXINT){
            _27228 = NewDouble((double)_27228);
        }
    }
    else
    _27228 = binary_op(PLUS, 1, _27227);
    DeRef(_27227);
    _27227 = NOVALUE;
    if (IS_ATOM_INT(_27228)) {
        _27229 = _27226 - _27228;
        if ((long)((unsigned long)_27229 +(unsigned long) HIGH_BITS) >= 0){
            _27229 = NewDouble((double)_27229);
        }
    }
    else {
        _27229 = NewDouble((double)_27226 - DBL_PTR(_27228)->dbl);
    }
    _27226 = NOVALUE;
    DeRef(_27228);
    _27228 = NOVALUE;
    _67shift(_start_52716, _27229, _finish_52717);
    _27229 = NOVALUE;

    /** end procedure*/
    DeRefDS(_code_52715);
    return;
    ;
}


void _67defer()
{
    int _dx_52725 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer dx = find( inline_sub, deferred_inline_decisions )*/
    _dx_52725 = find_from(_67inline_sub_52678, _67deferred_inline_decisions_52680, 1);

    /** 	if not dx then*/
    if (_dx_52725 != 0)
    goto L1; // [14] 36

    /** 		deferred_inline_decisions &= inline_sub*/
    Append(&_67deferred_inline_decisions_52680, _67deferred_inline_decisions_52680, _67inline_sub_52678);

    /** 		deferred_inline_calls = append( deferred_inline_calls, {} )*/
    RefDS(_22023);
    Append(&_67deferred_inline_calls_52681, _67deferred_inline_calls_52681, _22023);
L1: 

    /** end procedure*/
    return;
    ;
}


int _67new_inline_temp(int _sym_52734)
{
    int _27235 = NOVALUE;
    int _0, _1, _2;
    

    /** 	inline_temps &= sym*/
    Append(&_67inline_temps_52666, _67inline_temps_52666, _sym_52734);

    /** 	return length( inline_temps )*/
    if (IS_SEQUENCE(_67inline_temps_52666)){
            _27235 = SEQ_PTR(_67inline_temps_52666)->length;
    }
    else {
        _27235 = 1;
    }
    return _27235;
    ;
}


int _67get_inline_temp(int _sym_52740)
{
    int _temp_num_52741 = NOVALUE;
    int _27239 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer temp_num = find( sym, inline_params )*/
    _temp_num_52741 = find_from(_sym_52740, _67inline_params_52669, 1);

    /** 	if temp_num then*/
    if (_temp_num_52741 == 0)
    {
        goto L1; // [14] 24
    }
    else{
    }

    /** 		return temp_num*/
    return _temp_num_52741;
L1: 

    /** 	temp_num = find( sym, proc_vars )*/
    _temp_num_52741 = find_from(_sym_52740, _67proc_vars_52665, 1);

    /** 	if temp_num then*/
    if (_temp_num_52741 == 0)
    {
        goto L2; // [35] 45
    }
    else{
    }

    /** 		return temp_num*/
    return _temp_num_52741;
L2: 

    /** 	temp_num = find( sym, inline_temps )*/
    _temp_num_52741 = find_from(_sym_52740, _67inline_temps_52666, 1);

    /** 	if temp_num then*/
    if (_temp_num_52741 == 0)
    {
        goto L3; // [56] 66
    }
    else{
    }

    /** 		return temp_num*/
    return _temp_num_52741;
L3: 

    /** 	return new_inline_temp( sym )*/
    _27239 = _67new_inline_temp(_sym_52740);
    return _27239;
    ;
}


int _67generic_symbol(int _sym_52752)
{
    int _inline_type_52753 = NOVALUE;
    int _px_52754 = NOVALUE;
    int _eentry_52761 = NOVALUE;
    int _27248 = NOVALUE;
    int _27247 = NOVALUE;
    int _27246 = NOVALUE;
    int _27245 = NOVALUE;
    int _27243 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer px = find( sym, inline_params )*/
    _px_52754 = find_from(_sym_52752, _67inline_params_52669, 1);

    /** 	if px then*/
    if (_px_52754 == 0)
    {
        goto L1; // [14] 25
    }
    else{
    }

    /** 		inline_type = INLINE_PARAM*/
    _inline_type_52753 = 1;
    goto L2; // [22] 100
L1: 

    /** 		px = find( sym, proc_vars )*/
    _px_52754 = find_from(_sym_52752, _67proc_vars_52665, 1);

    /** 		if px then*/
    if (_px_52754 == 0)
    {
        goto L3; // [36] 47
    }
    else{
    }

    /** 			inline_type = INLINE_VAR*/
    _inline_type_52753 = 6;
    goto L4; // [44] 99
L3: 

    /** 			sequence eentry = SymTab[sym]*/
    DeRef(_eentry_52761);
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _eentry_52761 = (int)*(((s1_ptr)_2)->base + _sym_52752);
    Ref(_eentry_52761);

    /** 			if is_literal( sym ) or eentry[S_SCOPE] > SC_PRIVATE then*/
    _27243 = _67is_literal(_sym_52752);
    if (IS_ATOM_INT(_27243)) {
        if (_27243 != 0) {
            goto L5; // [63] 84
        }
    }
    else {
        if (DBL_PTR(_27243)->dbl != 0.0) {
            goto L5; // [63] 84
        }
    }
    _2 = (int)SEQ_PTR(_eentry_52761);
    _27245 = (int)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_27245)) {
        _27246 = (_27245 > 3);
    }
    else {
        _27246 = binary_op(GREATER, _27245, 3);
    }
    _27245 = NOVALUE;
    if (_27246 == 0) {
        DeRef(_27246);
        _27246 = NOVALUE;
        goto L6; // [80] 91
    }
    else {
        if (!IS_ATOM_INT(_27246) && DBL_PTR(_27246)->dbl == 0.0){
            DeRef(_27246);
            _27246 = NOVALUE;
            goto L6; // [80] 91
        }
        DeRef(_27246);
        _27246 = NOVALUE;
    }
    DeRef(_27246);
    _27246 = NOVALUE;
L5: 

    /** 				return sym*/
    DeRef(_eentry_52761);
    DeRef(_27243);
    _27243 = NOVALUE;
    return _sym_52752;
L6: 

    /** 			inline_type = INLINE_TEMP*/
    _inline_type_52753 = 2;
    DeRef(_eentry_52761);
    _eentry_52761 = NOVALUE;
L4: 
L2: 

    /** 	return { inline_type, get_inline_temp( sym ) }*/
    _27247 = _67get_inline_temp(_sym_52752);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _inline_type_52753;
    ((int *)_2)[2] = _27247;
    _27248 = MAKE_SEQ(_1);
    _27247 = NOVALUE;
    DeRef(_27243);
    _27243 = NOVALUE;
    return _27248;
    ;
}


int _67adjust_symbol(int _pc_52776)
{
    int _sym_52778 = NOVALUE;
    int _eentry_52784 = NOVALUE;
    int _27256 = NOVALUE;
    int _27254 = NOVALUE;
    int _27253 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_pc_52776)) {
        _1 = (long)(DBL_PTR(_pc_52776)->dbl);
        DeRefDS(_pc_52776);
        _pc_52776 = _1;
    }

    /** 	symtab_index sym = inline_code[pc]*/
    _2 = (int)SEQ_PTR(_67inline_code_52664);
    _sym_52778 = (int)*(((s1_ptr)_2)->base + _pc_52776);
    if (!IS_ATOM_INT(_sym_52778)){
        _sym_52778 = (long)DBL_PTR(_sym_52778)->dbl;
    }

    /** 	if sym < 0 then*/
    if (_sym_52778 >= 0)
    goto L1; // [15] 28

    /** 		return 0*/
    DeRef(_eentry_52784);
    return 0;
    goto L2; // [25] 41
L1: 

    /** 	elsif not sym then*/
    if (_sym_52778 != 0)
    goto L3; // [30] 40

    /** 		return 1*/
    DeRef(_eentry_52784);
    return 1;
L3: 
L2: 

    /** 	sequence eentry = SymTab[sym]*/
    DeRef(_eentry_52784);
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _eentry_52784 = (int)*(((s1_ptr)_2)->base + _sym_52778);
    Ref(_eentry_52784);

    /** 	if is_literal( sym ) then*/
    _27253 = _67is_literal(_sym_52778);
    if (_27253 == 0) {
        DeRef(_27253);
        _27253 = NOVALUE;
        goto L4; // [57] 69
    }
    else {
        if (!IS_ATOM_INT(_27253) && DBL_PTR(_27253)->dbl == 0.0){
            DeRef(_27253);
            _27253 = NOVALUE;
            goto L4; // [57] 69
        }
        DeRef(_27253);
        _27253 = NOVALUE;
    }
    DeRef(_27253);
    _27253 = NOVALUE;

    /** 		return 1*/
    DeRefDS(_eentry_52784);
    return 1;
    goto L5; // [66] 95
L4: 

    /** 	elsif eentry[S_SCOPE] = SC_UNDEFINED then*/
    _2 = (int)SEQ_PTR(_eentry_52784);
    _27254 = (int)*(((s1_ptr)_2)->base + 4);
    if (binary_op_a(NOTEQ, _27254, 9)){
        _27254 = NOVALUE;
        goto L6; // [79] 94
    }
    _27254 = NOVALUE;

    /** 		defer()*/
    _67defer();

    /** 		return 0*/
    DeRefDS(_eentry_52784);
    return 0;
L6: 
L5: 

    /** 	inline_code[pc] = generic_symbol( sym )*/
    _27256 = _67generic_symbol(_sym_52778);
    _2 = (int)SEQ_PTR(_67inline_code_52664);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _67inline_code_52664 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _pc_52776);
    _1 = *(int *)_2;
    *(int *)_2 = _27256;
    if( _1 != _27256 ){
        DeRef(_1);
    }
    _27256 = NOVALUE;

    /** 	return 1*/
    DeRef(_eentry_52784);
    return 1;
    ;
}


int _67check_for_param(int _pc_52798)
{
    int _px_52799 = NOVALUE;
    int _27259 = NOVALUE;
    int _27257 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_pc_52798)) {
        _1 = (long)(DBL_PTR(_pc_52798)->dbl);
        DeRefDS(_pc_52798);
        _pc_52798 = _1;
    }

    /** 	integer px = find( inline_code[pc], inline_params )*/
    _2 = (int)SEQ_PTR(_67inline_code_52664);
    _27257 = (int)*(((s1_ptr)_2)->base + _pc_52798);
    _px_52799 = find_from(_27257, _67inline_params_52669, 1);
    _27257 = NOVALUE;

    /** 	if px then*/
    if (_px_52799 == 0)
    {
        goto L1; // [20] 51
    }
    else{
    }

    /** 		if not find( px, assigned_params ) then*/
    _27259 = find_from(_px_52799, _67assigned_params_52670, 1);
    if (_27259 != 0)
    goto L2; // [32] 44
    _27259 = NOVALUE;

    /** 			assigned_params &= px*/
    Append(&_67assigned_params_52670, _67assigned_params_52670, _px_52799);
L2: 

    /** 		return 1*/
    return 1;
L1: 

    /** 	return 0*/
    return 0;
    ;
}


void _67check_target(int _pc_52809, int _op_52810)
{
    int _targets_52811 = NOVALUE;
    int _27268 = NOVALUE;
    int _27267 = NOVALUE;
    int _27266 = NOVALUE;
    int _27265 = NOVALUE;
    int _27264 = NOVALUE;
    int _27262 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence targets = op_info[op][OP_TARGET]*/
    _2 = (int)SEQ_PTR(_65op_info_26607);
    _27262 = (int)*(((s1_ptr)_2)->base + _op_52810);
    DeRef(_targets_52811);
    _2 = (int)SEQ_PTR(_27262);
    _targets_52811 = (int)*(((s1_ptr)_2)->base + 4);
    Ref(_targets_52811);
    _27262 = NOVALUE;

    /** 	if length( targets ) then*/
    if (IS_SEQUENCE(_targets_52811)){
            _27264 = SEQ_PTR(_targets_52811)->length;
    }
    else {
        _27264 = 1;
    }
    if (_27264 == 0)
    {
        _27264 = NOVALUE;
        goto L1; // [26] 72
    }
    else{
        _27264 = NOVALUE;
    }

    /** 	for i = 1 to length( targets ) do*/
    if (IS_SEQUENCE(_targets_52811)){
            _27265 = SEQ_PTR(_targets_52811)->length;
    }
    else {
        _27265 = 1;
    }
    {
        int _i_52819;
        _i_52819 = 1;
L2: 
        if (_i_52819 > _27265){
            goto L3; // [34] 71
        }

        /** 			if check_for_param( pc + targets[i] ) then*/
        _2 = (int)SEQ_PTR(_targets_52811);
        _27266 = (int)*(((s1_ptr)_2)->base + _i_52819);
        if (IS_ATOM_INT(_27266)) {
            _27267 = _pc_52809 + _27266;
            if ((long)((unsigned long)_27267 + (unsigned long)HIGH_BITS) >= 0) 
            _27267 = NewDouble((double)_27267);
        }
        else {
            _27267 = binary_op(PLUS, _pc_52809, _27266);
        }
        _27266 = NOVALUE;
        _27268 = _67check_for_param(_27267);
        _27267 = NOVALUE;
        if (_27268 == 0) {
            DeRef(_27268);
            _27268 = NOVALUE;
            goto L4; // [55] 64
        }
        else {
            if (!IS_ATOM_INT(_27268) && DBL_PTR(_27268)->dbl == 0.0){
                DeRef(_27268);
                _27268 = NOVALUE;
                goto L4; // [55] 64
            }
            DeRef(_27268);
            _27268 = NOVALUE;
        }
        DeRef(_27268);
        _27268 = NOVALUE;

        /** 				return*/
        DeRefDS(_targets_52811);
        return;
L4: 

        /** 		end for*/
        _i_52819 = _i_52819 + 1;
        goto L2; // [66] 41
L3: 
        ;
    }
L1: 

    /** end procedure*/
    DeRef(_targets_52811);
    return;
    ;
}


int _67adjust_il(int _pc_52827, int _op_52828)
{
    int _addr_52836 = NOVALUE;
    int _sub_52842 = NOVALUE;
    int _27293 = NOVALUE;
    int _27292 = NOVALUE;
    int _27291 = NOVALUE;
    int _27290 = NOVALUE;
    int _27289 = NOVALUE;
    int _27288 = NOVALUE;
    int _27287 = NOVALUE;
    int _27285 = NOVALUE;
    int _27284 = NOVALUE;
    int _27283 = NOVALUE;
    int _27282 = NOVALUE;
    int _27281 = NOVALUE;
    int _27280 = NOVALUE;
    int _27279 = NOVALUE;
    int _27278 = NOVALUE;
    int _27276 = NOVALUE;
    int _27275 = NOVALUE;
    int _27273 = NOVALUE;
    int _27272 = NOVALUE;
    int _27271 = NOVALUE;
    int _27270 = NOVALUE;
    int _27269 = NOVALUE;
    int _0, _1, _2;
    

    /** 	for i = 1 to op_info[op][OP_SIZE] - 1 do*/
    _2 = (int)SEQ_PTR(_65op_info_26607);
    _27269 = (int)*(((s1_ptr)_2)->base + _op_52828);
    _2 = (int)SEQ_PTR(_27269);
    _27270 = (int)*(((s1_ptr)_2)->base + 2);
    _27269 = NOVALUE;
    if (IS_ATOM_INT(_27270)) {
        _27271 = _27270 - 1;
        if ((long)((unsigned long)_27271 +(unsigned long) HIGH_BITS) >= 0){
            _27271 = NewDouble((double)_27271);
        }
    }
    else {
        _27271 = binary_op(MINUS, _27270, 1);
    }
    _27270 = NOVALUE;
    {
        int _i_52830;
        _i_52830 = 1;
L1: 
        if (binary_op_a(GREATER, _i_52830, _27271)){
            goto L2; // [23] 214
        }

        /** 		integer addr = find( i, op_info[op][OP_ADDR] )*/
        _2 = (int)SEQ_PTR(_65op_info_26607);
        _27272 = (int)*(((s1_ptr)_2)->base + _op_52828);
        _2 = (int)SEQ_PTR(_27272);
        _27273 = (int)*(((s1_ptr)_2)->base + 3);
        _27272 = NOVALUE;
        _addr_52836 = find_from(_i_52830, _27273, 1);
        _27273 = NOVALUE;

        /** 		integer sub  = find( i, op_info[op][OP_SUB] )*/
        _2 = (int)SEQ_PTR(_65op_info_26607);
        _27275 = (int)*(((s1_ptr)_2)->base + _op_52828);
        _2 = (int)SEQ_PTR(_27275);
        _27276 = (int)*(((s1_ptr)_2)->base + 5);
        _27275 = NOVALUE;
        _sub_52842 = find_from(_i_52830, _27276, 1);
        _27276 = NOVALUE;

        /** 		if addr then*/
        if (_addr_52836 == 0)
        {
            goto L3; // [70] 121
        }
        else{
        }

        /** 			if integer( inline_code[pc+i] ) then*/
        if (IS_ATOM_INT(_i_52830)) {
            _27278 = _pc_52827 + _i_52830;
        }
        else {
            _27278 = NewDouble((double)_pc_52827 + DBL_PTR(_i_52830)->dbl);
        }
        _2 = (int)SEQ_PTR(_67inline_code_52664);
        if (!IS_ATOM_INT(_27278)){
            _27279 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_27278)->dbl));
        }
        else{
            _27279 = (int)*(((s1_ptr)_2)->base + _27278);
        }
        if (IS_ATOM_INT(_27279))
        _27280 = 1;
        else if (IS_ATOM_DBL(_27279))
        _27280 = IS_ATOM_INT(DoubleToInt(_27279));
        else
        _27280 = 0;
        _27279 = NOVALUE;
        if (_27280 == 0)
        {
            _27280 = NOVALUE;
            goto L4; // [88] 205
        }
        else{
            _27280 = NOVALUE;
        }

        /** 				inline_code[pc + i] = { INLINE_ADDR, inline_code[pc + i] }*/
        if (IS_ATOM_INT(_i_52830)) {
            _27281 = _pc_52827 + _i_52830;
            if ((long)((unsigned long)_27281 + (unsigned long)HIGH_BITS) >= 0) 
            _27281 = NewDouble((double)_27281);
        }
        else {
            _27281 = NewDouble((double)_pc_52827 + DBL_PTR(_i_52830)->dbl);
        }
        if (IS_ATOM_INT(_i_52830)) {
            _27282 = _pc_52827 + _i_52830;
        }
        else {
            _27282 = NewDouble((double)_pc_52827 + DBL_PTR(_i_52830)->dbl);
        }
        _2 = (int)SEQ_PTR(_67inline_code_52664);
        if (!IS_ATOM_INT(_27282)){
            _27283 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_27282)->dbl));
        }
        else{
            _27283 = (int)*(((s1_ptr)_2)->base + _27282);
        }
        Ref(_27283);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = 4;
        ((int *)_2)[2] = _27283;
        _27284 = MAKE_SEQ(_1);
        _27283 = NOVALUE;
        _2 = (int)SEQ_PTR(_67inline_code_52664);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _67inline_code_52664 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_27281))
        _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_27281)->dbl));
        else
        _2 = (int)(((s1_ptr)_2)->base + _27281);
        _1 = *(int *)_2;
        *(int *)_2 = _27284;
        if( _1 != _27284 ){
            DeRef(_1);
        }
        _27284 = NOVALUE;
        goto L4; // [118] 205
L3: 

        /** 		elsif sub then*/
        if (_sub_52842 == 0)
        {
            goto L5; // [123] 141
        }
        else{
        }

        /** 			inline_code[pc+i] = {INLINE_SUB}*/
        if (IS_ATOM_INT(_i_52830)) {
            _27285 = _pc_52827 + _i_52830;
        }
        else {
            _27285 = NewDouble((double)_pc_52827 + DBL_PTR(_i_52830)->dbl);
        }
        RefDS(_27286);
        _2 = (int)SEQ_PTR(_67inline_code_52664);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _67inline_code_52664 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_27285))
        _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_27285)->dbl));
        else
        _2 = (int)(((s1_ptr)_2)->base + _27285);
        _1 = *(int *)_2;
        *(int *)_2 = _27286;
        DeRef(_1);
        goto L4; // [138] 205
L5: 

        /** 			if op != STARTLINE and op != COVERAGE_LINE and op != COVERAGE_ROUTINE then*/
        _27287 = (_op_52828 != 58);
        if (_27287 == 0) {
            _27288 = 0;
            goto L6; // [149] 163
        }
        _27289 = (_op_52828 != 210);
        _27288 = (_27289 != 0);
L6: 
        if (_27288 == 0) {
            goto L7; // [163] 204
        }
        _27291 = (_op_52828 != 211);
        if (_27291 == 0)
        {
            DeRef(_27291);
            _27291 = NOVALUE;
            goto L7; // [174] 204
        }
        else{
            DeRef(_27291);
            _27291 = NOVALUE;
        }

        /** 				check_target( pc, op )*/
        _67check_target(_pc_52827, _op_52828);

        /** 				if not adjust_symbol( pc + i ) then*/
        if (IS_ATOM_INT(_i_52830)) {
            _27292 = _pc_52827 + _i_52830;
            if ((long)((unsigned long)_27292 + (unsigned long)HIGH_BITS) >= 0) 
            _27292 = NewDouble((double)_27292);
        }
        else {
            _27292 = NewDouble((double)_pc_52827 + DBL_PTR(_i_52830)->dbl);
        }
        _27293 = _67adjust_symbol(_27292);
        _27292 = NOVALUE;
        if (IS_ATOM_INT(_27293)) {
            if (_27293 != 0){
                DeRef(_27293);
                _27293 = NOVALUE;
                goto L8; // [193] 203
            }
        }
        else {
            if (DBL_PTR(_27293)->dbl != 0.0){
                DeRef(_27293);
                _27293 = NOVALUE;
                goto L8; // [193] 203
            }
        }
        DeRef(_27293);
        _27293 = NOVALUE;

        /** 					return 0*/
        DeRef(_i_52830);
        DeRef(_27278);
        _27278 = NOVALUE;
        DeRef(_27271);
        _27271 = NOVALUE;
        DeRef(_27281);
        _27281 = NOVALUE;
        DeRef(_27282);
        _27282 = NOVALUE;
        DeRef(_27285);
        _27285 = NOVALUE;
        DeRef(_27287);
        _27287 = NOVALUE;
        DeRef(_27289);
        _27289 = NOVALUE;
        return 0;
L8: 
L7: 
L4: 

        /** 	end for*/
        _0 = _i_52830;
        if (IS_ATOM_INT(_i_52830)) {
            _i_52830 = _i_52830 + 1;
            if ((long)((unsigned long)_i_52830 +(unsigned long) HIGH_BITS) >= 0){
                _i_52830 = NewDouble((double)_i_52830);
            }
        }
        else {
            _i_52830 = binary_op_a(PLUS, _i_52830, 1);
        }
        DeRef(_0);
        goto L1; // [209] 30
L2: 
        ;
        DeRef(_i_52830);
    }

    /** 	return 1*/
    DeRef(_27278);
    _27278 = NOVALUE;
    DeRef(_27271);
    _27271 = NOVALUE;
    DeRef(_27281);
    _27281 = NOVALUE;
    DeRef(_27282);
    _27282 = NOVALUE;
    DeRef(_27285);
    _27285 = NOVALUE;
    DeRef(_27287);
    _27287 = NOVALUE;
    DeRef(_27289);
    _27289 = NOVALUE;
    return 1;
    ;
}


int _67is_temp(int _sym_52877)
{
    int _27304 = NOVALUE;
    int _27303 = NOVALUE;
    int _27302 = NOVALUE;
    int _27301 = NOVALUE;
    int _27300 = NOVALUE;
    int _27299 = NOVALUE;
    int _27298 = NOVALUE;
    int _27297 = NOVALUE;
    int _27296 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if sym <= 0 then*/
    if (_sym_52877 > 0)
    goto L1; // [5] 16

    /** 		return 0*/
    return 0;
L1: 

    /** 	return (SymTab[sym][S_MODE] = M_TEMP) and (not TRANSLATE or equal( NOVALUE, SymTab[sym][S_OBJ]) )*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _27296 = (int)*(((s1_ptr)_2)->base + _sym_52877);
    _2 = (int)SEQ_PTR(_27296);
    _27297 = (int)*(((s1_ptr)_2)->base + 3);
    _27296 = NOVALUE;
    if (IS_ATOM_INT(_27297)) {
        _27298 = (_27297 == 3);
    }
    else {
        _27298 = binary_op(EQUALS, _27297, 3);
    }
    _27297 = NOVALUE;
    _27299 = (_35TRANSLATE_15887 == 0);
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _27300 = (int)*(((s1_ptr)_2)->base + _sym_52877);
    _2 = (int)SEQ_PTR(_27300);
    _27301 = (int)*(((s1_ptr)_2)->base + 1);
    _27300 = NOVALUE;
    if (_35NOVALUE_16099 == _27301)
    _27302 = 1;
    else if (IS_ATOM_INT(_35NOVALUE_16099) && IS_ATOM_INT(_27301))
    _27302 = 0;
    else
    _27302 = (compare(_35NOVALUE_16099, _27301) == 0);
    _27301 = NOVALUE;
    _27303 = (_27299 != 0 || _27302 != 0);
    _27299 = NOVALUE;
    _27302 = NOVALUE;
    if (IS_ATOM_INT(_27298)) {
        _27304 = (_27298 != 0 && _27303 != 0);
    }
    else {
        _27304 = binary_op(AND, _27298, _27303);
    }
    DeRef(_27298);
    _27298 = NOVALUE;
    _27303 = NOVALUE;
    return _27304;
    ;
}


int _67is_literal(int _sym_52899)
{
    int _mode_52902 = NOVALUE;
    int _27319 = NOVALUE;
    int _27318 = NOVALUE;
    int _27317 = NOVALUE;
    int _27316 = NOVALUE;
    int _27315 = NOVALUE;
    int _27314 = NOVALUE;
    int _27312 = NOVALUE;
    int _27311 = NOVALUE;
    int _27310 = NOVALUE;
    int _27309 = NOVALUE;
    int _27308 = NOVALUE;
    int _27306 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if sym <= 0 then*/
    if (_sym_52899 > 0)
    goto L1; // [5] 16

    /** 		return 0*/
    return 0;
L1: 

    /** 	integer mode = SymTab[sym][S_MODE]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _27306 = (int)*(((s1_ptr)_2)->base + _sym_52899);
    _2 = (int)SEQ_PTR(_27306);
    _mode_52902 = (int)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_mode_52902)){
        _mode_52902 = (long)DBL_PTR(_mode_52902)->dbl;
    }
    _27306 = NOVALUE;

    /** 	if (mode = M_CONSTANT and eu:compare( NOVALUE, SymTab[sym][S_OBJ]) ) */
    _27308 = (_mode_52902 == 2);
    if (_27308 == 0) {
        _27309 = 0;
        goto L2; // [40] 66
    }
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _27310 = (int)*(((s1_ptr)_2)->base + _sym_52899);
    _2 = (int)SEQ_PTR(_27310);
    _27311 = (int)*(((s1_ptr)_2)->base + 1);
    _27310 = NOVALUE;
    if (IS_ATOM_INT(_35NOVALUE_16099) && IS_ATOM_INT(_27311)){
        _27312 = (_35NOVALUE_16099 < _27311) ? -1 : (_35NOVALUE_16099 > _27311);
    }
    else{
        _27312 = compare(_35NOVALUE_16099, _27311);
    }
    _27311 = NOVALUE;
    _27309 = (_27312 != 0);
L2: 
    if (_27309 != 0) {
        goto L3; // [66] 117
    }
    if (_35TRANSLATE_15887 == 0) {
        _27314 = 0;
        goto L4; // [72] 86
    }
    _27315 = (_mode_52902 == 3);
    _27314 = (_27315 != 0);
L4: 
    if (_27314 == 0) {
        DeRef(_27316);
        _27316 = 0;
        goto L5; // [86] 112
    }
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _27317 = (int)*(((s1_ptr)_2)->base + _sym_52899);
    _2 = (int)SEQ_PTR(_27317);
    _27318 = (int)*(((s1_ptr)_2)->base + 1);
    _27317 = NOVALUE;
    if (IS_ATOM_INT(_27318) && IS_ATOM_INT(_35NOVALUE_16099)){
        _27319 = (_27318 < _35NOVALUE_16099) ? -1 : (_27318 > _35NOVALUE_16099);
    }
    else{
        _27319 = compare(_27318, _35NOVALUE_16099);
    }
    _27318 = NOVALUE;
    _27316 = (_27319 != 0);
L5: 
    if (_27316 == 0)
    {
        _27316 = NOVALUE;
        goto L6; // [113] 126
    }
    else{
        _27316 = NOVALUE;
    }
L3: 

    /** 		return 1*/
    DeRef(_27308);
    _27308 = NOVALUE;
    DeRef(_27315);
    _27315 = NOVALUE;
    return 1;
    goto L7; // [123] 133
L6: 

    /** 		return 0*/
    DeRef(_27308);
    _27308 = NOVALUE;
    DeRef(_27315);
    _27315 = NOVALUE;
    return 0;
L7: 
    ;
}


int _67returnf(int _pc_52949)
{
    int _retsym_52951 = NOVALUE;
    int _code_52984 = NOVALUE;
    int _ret_pc_52985 = NOVALUE;
    int _code_53030 = NOVALUE;
    int _ret_pc_53044 = NOVALUE;
    int _27392 = NOVALUE;
    int _27391 = NOVALUE;
    int _27389 = NOVALUE;
    int _27387 = NOVALUE;
    int _27386 = NOVALUE;
    int _27384 = NOVALUE;
    int _27383 = NOVALUE;
    int _27381 = NOVALUE;
    int _27380 = NOVALUE;
    int _27379 = NOVALUE;
    int _27377 = NOVALUE;
    int _27376 = NOVALUE;
    int _27374 = NOVALUE;
    int _27372 = NOVALUE;
    int _27371 = NOVALUE;
    int _27369 = NOVALUE;
    int _27368 = NOVALUE;
    int _27366 = NOVALUE;
    int _27365 = NOVALUE;
    int _27364 = NOVALUE;
    int _27362 = NOVALUE;
    int _27361 = NOVALUE;
    int _27360 = NOVALUE;
    int _27359 = NOVALUE;
    int _27358 = NOVALUE;
    int _27356 = NOVALUE;
    int _27355 = NOVALUE;
    int _27354 = NOVALUE;
    int _27353 = NOVALUE;
    int _27351 = NOVALUE;
    int _27349 = NOVALUE;
    int _27348 = NOVALUE;
    int _27347 = NOVALUE;
    int _27346 = NOVALUE;
    int _27345 = NOVALUE;
    int _27344 = NOVALUE;
    int _27343 = NOVALUE;
    int _27342 = NOVALUE;
    int _27341 = NOVALUE;
    int _27339 = NOVALUE;
    int _27338 = NOVALUE;
    int _27337 = NOVALUE;
    int _27335 = NOVALUE;
    int _27334 = NOVALUE;
    int _27333 = NOVALUE;
    int _27332 = NOVALUE;
    int _27331 = NOVALUE;
    int _27330 = NOVALUE;
    int _27328 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	symtab_index retsym = inline_code[pc+3]*/
    _27328 = _pc_52949 + 3;
    _2 = (int)SEQ_PTR(_67inline_code_52664);
    _retsym_52951 = (int)*(((s1_ptr)_2)->base + _27328);
    if (!IS_ATOM_INT(_retsym_52951)){
        _retsym_52951 = (long)DBL_PTR(_retsym_52951)->dbl;
    }

    /** 	if equal( inline_code[$], BADRETURNF ) then*/
    if (IS_SEQUENCE(_67inline_code_52664)){
            _27330 = SEQ_PTR(_67inline_code_52664)->length;
    }
    else {
        _27330 = 1;
    }
    _2 = (int)SEQ_PTR(_67inline_code_52664);
    _27331 = (int)*(((s1_ptr)_2)->base + _27330);
    if (_27331 == 43)
    _27332 = 1;
    else if (IS_ATOM_INT(_27331) && IS_ATOM_INT(43))
    _27332 = 0;
    else
    _27332 = (compare(_27331, 43) == 0);
    _27331 = NOVALUE;
    if (_27332 == 0)
    {
        _27332 = NOVALUE;
        goto L1; // [34] 102
    }
    else{
        _27332 = NOVALUE;
    }

    /** 		if TRANSLATE then*/
    if (_35TRANSLATE_15887 == 0)
    {
        goto L2; // [41] 60
    }
    else{
    }

    /** 			inline_code[$] = NOP1*/
    if (IS_SEQUENCE(_67inline_code_52664)){
            _27333 = SEQ_PTR(_67inline_code_52664)->length;
    }
    else {
        _27333 = 1;
    }
    _2 = (int)SEQ_PTR(_67inline_code_52664);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _67inline_code_52664 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _27333);
    _1 = *(int *)_2;
    *(int *)_2 = 159;
    DeRef(_1);
    goto L3; // [57] 101
L2: 

    /** 		elsif SymTab[inline_sub][S_TOKEN] = PROC then*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _27334 = (int)*(((s1_ptr)_2)->base + _67inline_sub_52678);
    _2 = (int)SEQ_PTR(_27334);
    if (!IS_ATOM_INT(_35S_TOKEN_15922)){
        _27335 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TOKEN_15922)->dbl));
    }
    else{
        _27335 = (int)*(((s1_ptr)_2)->base + _35S_TOKEN_15922);
    }
    _27334 = NOVALUE;
    if (binary_op_a(NOTEQ, _27335, 27)){
        _27335 = NOVALUE;
        goto L4; // [78] 100
    }
    _27335 = NOVALUE;

    /** 			replace_code( {}, length(inline_code), length(inline_code) )*/
    if (IS_SEQUENCE(_67inline_code_52664)){
            _27337 = SEQ_PTR(_67inline_code_52664)->length;
    }
    else {
        _27337 = 1;
    }
    if (IS_SEQUENCE(_67inline_code_52664)){
            _27338 = SEQ_PTR(_67inline_code_52664)->length;
    }
    else {
        _27338 = 1;
    }
    RefDS(_22023);
    _67replace_code(_22023, _27337, _27338);
    _27337 = NOVALUE;
    _27338 = NOVALUE;
L4: 
L3: 
L1: 

    /** 	if is_temp( retsym ) */
    _27339 = _67is_temp(_retsym_52951);
    if (IS_ATOM_INT(_27339)) {
        if (_27339 != 0) {
            goto L5; // [108] 150
        }
    }
    else {
        if (DBL_PTR(_27339)->dbl != 0.0) {
            goto L5; // [108] 150
        }
    }
    _27341 = _67is_literal(_retsym_52951);
    if (IS_ATOM_INT(_27341)) {
        _27342 = (_27341 == 0);
    }
    else {
        _27342 = unary_op(NOT, _27341);
    }
    DeRef(_27341);
    _27341 = NOVALUE;
    if (IS_ATOM_INT(_27342)) {
        if (_27342 == 0) {
            DeRef(_27343);
            _27343 = 0;
            goto L6; // [119] 145
        }
    }
    else {
        if (DBL_PTR(_27342)->dbl == 0.0) {
            DeRef(_27343);
            _27343 = 0;
            goto L6; // [119] 145
        }
    }
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _27344 = (int)*(((s1_ptr)_2)->base + _retsym_52951);
    _2 = (int)SEQ_PTR(_27344);
    _27345 = (int)*(((s1_ptr)_2)->base + 4);
    _27344 = NOVALUE;
    if (IS_ATOM_INT(_27345)) {
        _27346 = (_27345 <= 3);
    }
    else {
        _27346 = binary_op(LESSEQ, _27345, 3);
    }
    _27345 = NOVALUE;
    DeRef(_27343);
    if (IS_ATOM_INT(_27346))
    _27343 = (_27346 != 0);
    else
    _27343 = DBL_PTR(_27346)->dbl != 0.0;
L6: 
    if (_27343 == 0)
    {
        _27343 = NOVALUE;
        goto L7; // [146] 393
    }
    else{
        _27343 = NOVALUE;
    }
L5: 

    /** 		sequence code = {}*/
    RefDS(_22023);
    DeRef(_code_52984);
    _code_52984 = _22023;

    /** 		integer ret_pc = 0*/
    _ret_pc_52985 = 0;

    /** 		if not (find( retsym, inline_params ) or find( retsym, proc_vars )) then*/
    _27347 = find_from(_retsym_52951, _67inline_params_52669, 1);
    if (_27347 != 0) {
        DeRef(_27348);
        _27348 = 1;
        goto L8; // [171] 186
    }
    _27349 = find_from(_retsym_52951, _67proc_vars_52665, 1);
    _27348 = (_27349 != 0);
L8: 
    if (_27348 != 0)
    goto L9; // [186] 206
    _27348 = NOVALUE;

    /** 			ret_pc = rfind( generic_symbol( retsym ), inline_code, pc )*/
    _27351 = _67generic_symbol(_retsym_52951);
    RefDS(_67inline_code_52664);
    _ret_pc_52985 = _16rfind(_27351, _67inline_code_52664, _pc_52949);
    _27351 = NOVALUE;
    if (!IS_ATOM_INT(_ret_pc_52985)) {
        _1 = (long)(DBL_PTR(_ret_pc_52985)->dbl);
        DeRefDS(_ret_pc_52985);
        _ret_pc_52985 = _1;
    }
L9: 

    /** 		if ret_pc and eu:compare( inline_code[ret_pc-1], PRIVATE_INIT_CHECK ) then*/
    if (_ret_pc_52985 == 0) {
        goto LA; // [208] 277
    }
    _27354 = _ret_pc_52985 - 1;
    _2 = (int)SEQ_PTR(_67inline_code_52664);
    _27355 = (int)*(((s1_ptr)_2)->base + _27354);
    if (IS_ATOM_INT(_27355) && IS_ATOM_INT(30)){
        _27356 = (_27355 < 30) ? -1 : (_27355 > 30);
    }
    else{
        _27356 = compare(_27355, 30);
    }
    _27355 = NOVALUE;
    if (_27356 == 0)
    {
        _27356 = NOVALUE;
        goto LA; // [229] 277
    }
    else{
        _27356 = NOVALUE;
    }

    /** 			inline_code[ret_pc] = {INLINE_TARGET}*/
    RefDS(_27357);
    _2 = (int)SEQ_PTR(_67inline_code_52664);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _67inline_code_52664 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _ret_pc_52985);
    _1 = *(int *)_2;
    *(int *)_2 = _27357;
    DeRef(_1);

    /** 			if equal( inline_code[ret_pc-1], REF_TEMP ) then*/
    _27358 = _ret_pc_52985 - 1;
    _2 = (int)SEQ_PTR(_67inline_code_52664);
    _27359 = (int)*(((s1_ptr)_2)->base + _27358);
    if (_27359 == 207)
    _27360 = 1;
    else if (IS_ATOM_INT(_27359) && IS_ATOM_INT(207))
    _27360 = 0;
    else
    _27360 = (compare(_27359, 207) == 0);
    _27359 = NOVALUE;
    if (_27360 == 0)
    {
        _27360 = NOVALUE;
        goto LB; // [258] 292
    }
    else{
        _27360 = NOVALUE;
    }

    /** 				inline_code[ret_pc-2] = {INLINE_TARGET}*/
    _27361 = _ret_pc_52985 - 2;
    RefDS(_27357);
    _2 = (int)SEQ_PTR(_67inline_code_52664);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _67inline_code_52664 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _27361);
    _1 = *(int *)_2;
    *(int *)_2 = _27357;
    DeRef(_1);
    goto LB; // [274] 292
LA: 

    /** 			code = {ASSIGN, generic_symbol( retsym ), {INLINE_TARGET}}*/
    _27362 = _67generic_symbol(_retsym_52951);
    _0 = _code_52984;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 18;
    *((int *)(_2+8)) = _27362;
    RefDS(_27357);
    *((int *)(_2+12)) = _27357;
    _code_52984 = MAKE_SEQ(_1);
    DeRef(_0);
    _27362 = NOVALUE;
LB: 

    /** 		if pc != length( inline_code ) - ( 3 + TRANSLATE ) then*/
    if (IS_SEQUENCE(_67inline_code_52664)){
            _27364 = SEQ_PTR(_67inline_code_52664)->length;
    }
    else {
        _27364 = 1;
    }
    _27365 = 3 + _35TRANSLATE_15887;
    _27366 = _27364 - _27365;
    _27364 = NOVALUE;
    _27365 = NOVALUE;
    if (_pc_52949 == _27366)
    goto LC; // [309] 330

    /** 			code &= { ELSE, {INLINE_ADDR, -1 }}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 4;
    ((int *)_2)[2] = -1;
    _27368 = MAKE_SEQ(_1);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 23;
    ((int *)_2)[2] = _27368;
    _27369 = MAKE_SEQ(_1);
    _27368 = NOVALUE;
    Concat((object_ptr)&_code_52984, _code_52984, _27369);
    DeRefDS(_27369);
    _27369 = NOVALUE;
LC: 

    /** 		replace_code( code, pc, pc + 3 )*/
    _27371 = _pc_52949 + 3;
    if ((long)((unsigned long)_27371 + (unsigned long)HIGH_BITS) >= 0) 
    _27371 = NewDouble((double)_27371);
    RefDS(_code_52984);
    _67replace_code(_code_52984, _pc_52949, _27371);
    _27371 = NOVALUE;

    /** 		ret_pc = find( { INLINE_ADDR, -1 }, inline_code, pc )*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 4;
    ((int *)_2)[2] = -1;
    _27372 = MAKE_SEQ(_1);
    _ret_pc_52985 = find_from(_27372, _67inline_code_52664, _pc_52949);
    DeRefDS(_27372);
    _27372 = NOVALUE;

    /** 		if ret_pc then*/
    if (_ret_pc_52985 == 0)
    {
        goto LD; // [356] 382
    }
    else{
    }

    /** 			inline_code[ret_pc][2] = length(inline_code) + 1*/
    _2 = (int)SEQ_PTR(_67inline_code_52664);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _67inline_code_52664 = MAKE_SEQ(_2);
    }
    _3 = (int)(_ret_pc_52985 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_67inline_code_52664)){
            _27376 = SEQ_PTR(_67inline_code_52664)->length;
    }
    else {
        _27376 = 1;
    }
    _27377 = _27376 + 1;
    _27376 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _27377;
    if( _1 != _27377 ){
        DeRef(_1);
    }
    _27377 = NOVALUE;
    _27374 = NOVALUE;
LD: 

    /** 		return 1*/
    DeRef(_code_52984);
    DeRef(_27328);
    _27328 = NOVALUE;
    DeRef(_27339);
    _27339 = NOVALUE;
    DeRef(_27342);
    _27342 = NOVALUE;
    DeRef(_27354);
    _27354 = NOVALUE;
    DeRef(_27346);
    _27346 = NOVALUE;
    DeRef(_27358);
    _27358 = NOVALUE;
    DeRef(_27361);
    _27361 = NOVALUE;
    DeRef(_27366);
    _27366 = NOVALUE;
    return 1;
    goto LE; // [390] 502
L7: 

    /** 		sequence code = {ASSIGN, retsym, {INLINE_TARGET}}*/
    _0 = _code_53030;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 18;
    *((int *)(_2+8)) = _retsym_52951;
    RefDS(_27357);
    *((int *)(_2+12)) = _27357;
    _code_53030 = MAKE_SEQ(_1);
    DeRef(_0);

    /** 		if pc != length( inline_code ) - ( 3 + TRANSLATE ) then*/
    if (IS_SEQUENCE(_67inline_code_52664)){
            _27379 = SEQ_PTR(_67inline_code_52664)->length;
    }
    else {
        _27379 = 1;
    }
    _27380 = 3 + _35TRANSLATE_15887;
    _27381 = _27379 - _27380;
    _27379 = NOVALUE;
    _27380 = NOVALUE;
    if (_pc_52949 == _27381)
    goto LF; // [420] 441

    /** 			code &= { ELSE, {INLINE_ADDR, -1 }}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 4;
    ((int *)_2)[2] = -1;
    _27383 = MAKE_SEQ(_1);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 23;
    ((int *)_2)[2] = _27383;
    _27384 = MAKE_SEQ(_1);
    _27383 = NOVALUE;
    Concat((object_ptr)&_code_53030, _code_53030, _27384);
    DeRefDS(_27384);
    _27384 = NOVALUE;
LF: 

    /** 		replace_code( code, pc, pc + 3 )*/
    _27386 = _pc_52949 + 3;
    if ((long)((unsigned long)_27386 + (unsigned long)HIGH_BITS) >= 0) 
    _27386 = NewDouble((double)_27386);
    RefDS(_code_53030);
    _67replace_code(_code_53030, _pc_52949, _27386);
    _27386 = NOVALUE;

    /** 		integer ret_pc = find( { INLINE_ADDR, -1 }, inline_code, pc )*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 4;
    ((int *)_2)[2] = -1;
    _27387 = MAKE_SEQ(_1);
    _ret_pc_53044 = find_from(_27387, _67inline_code_52664, _pc_52949);
    DeRefDS(_27387);
    _27387 = NOVALUE;

    /** 		if ret_pc then*/
    if (_ret_pc_53044 == 0)
    {
        goto L10; // [467] 493
    }
    else{
    }

    /** 			inline_code[ret_pc][2] = length(inline_code) + 1*/
    _2 = (int)SEQ_PTR(_67inline_code_52664);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _67inline_code_52664 = MAKE_SEQ(_2);
    }
    _3 = (int)(_ret_pc_53044 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_67inline_code_52664)){
            _27391 = SEQ_PTR(_67inline_code_52664)->length;
    }
    else {
        _27391 = 1;
    }
    _27392 = _27391 + 1;
    _27391 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _27392;
    if( _1 != _27392 ){
        DeRef(_1);
    }
    _27392 = NOVALUE;
    _27389 = NOVALUE;
L10: 

    /** 		return 1*/
    DeRef(_code_53030);
    DeRef(_27328);
    _27328 = NOVALUE;
    DeRef(_27339);
    _27339 = NOVALUE;
    DeRef(_27342);
    _27342 = NOVALUE;
    DeRef(_27354);
    _27354 = NOVALUE;
    DeRef(_27346);
    _27346 = NOVALUE;
    DeRef(_27358);
    _27358 = NOVALUE;
    DeRef(_27361);
    _27361 = NOVALUE;
    DeRef(_27366);
    _27366 = NOVALUE;
    DeRef(_27381);
    _27381 = NOVALUE;
    return 1;
LE: 

    /** 	return 0*/
    DeRef(_27328);
    _27328 = NOVALUE;
    DeRef(_27339);
    _27339 = NOVALUE;
    DeRef(_27342);
    _27342 = NOVALUE;
    DeRef(_27354);
    _27354 = NOVALUE;
    DeRef(_27346);
    _27346 = NOVALUE;
    DeRef(_27358);
    _27358 = NOVALUE;
    DeRef(_27361);
    _27361 = NOVALUE;
    DeRef(_27366);
    _27366 = NOVALUE;
    DeRef(_27381);
    _27381 = NOVALUE;
    return 0;
    ;
}


int _67inline_op(int _pc_53054)
{
    int _op_53055 = NOVALUE;
    int _code_53060 = NOVALUE;
    int _stlen_53093 = NOVALUE;
    int _file_53098 = NOVALUE;
    int _ok_53103 = NOVALUE;
    int _original_table_53126 = NOVALUE;
    int _jump_table_53130 = NOVALUE;
    int _27453 = NOVALUE;
    int _27452 = NOVALUE;
    int _27451 = NOVALUE;
    int _27450 = NOVALUE;
    int _27449 = NOVALUE;
    int _27448 = NOVALUE;
    int _27447 = NOVALUE;
    int _27446 = NOVALUE;
    int _27445 = NOVALUE;
    int _27444 = NOVALUE;
    int _27443 = NOVALUE;
    int _27442 = NOVALUE;
    int _27439 = NOVALUE;
    int _27438 = NOVALUE;
    int _27437 = NOVALUE;
    int _27436 = NOVALUE;
    int _27434 = NOVALUE;
    int _27432 = NOVALUE;
    int _27431 = NOVALUE;
    int _27429 = NOVALUE;
    int _27425 = NOVALUE;
    int _27424 = NOVALUE;
    int _27423 = NOVALUE;
    int _27422 = NOVALUE;
    int _27421 = NOVALUE;
    int _27420 = NOVALUE;
    int _27417 = NOVALUE;
    int _27416 = NOVALUE;
    int _27414 = NOVALUE;
    int _27413 = NOVALUE;
    int _27411 = NOVALUE;
    int _27409 = NOVALUE;
    int _27408 = NOVALUE;
    int _27407 = NOVALUE;
    int _27406 = NOVALUE;
    int _27405 = NOVALUE;
    int _27404 = NOVALUE;
    int _27403 = NOVALUE;
    int _27401 = NOVALUE;
    int _27400 = NOVALUE;
    int _27399 = NOVALUE;
    int _27397 = NOVALUE;
    int _27396 = NOVALUE;
    int _27395 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	integer op = inline_code[pc]*/
    _2 = (int)SEQ_PTR(_67inline_code_52664);
    _op_53055 = (int)*(((s1_ptr)_2)->base + _pc_53054);
    if (!IS_ATOM_INT(_op_53055))
    _op_53055 = (long)DBL_PTR(_op_53055)->dbl;

    /** 	if op = RETURNP then*/
    if (_op_53055 != 29)
    goto L1; // [15] 150

    /** 		sequence code = ""*/
    RefDS(_22023);
    DeRef(_code_53060);
    _code_53060 = _22023;

    /** 		if pc != length( inline_code ) - 1 - TRANSLATE then*/
    if (IS_SEQUENCE(_67inline_code_52664)){
            _27395 = SEQ_PTR(_67inline_code_52664)->length;
    }
    else {
        _27395 = 1;
    }
    _27396 = _27395 - 1;
    _27395 = NOVALUE;
    _27397 = _27396 - _35TRANSLATE_15887;
    _27396 = NOVALUE;
    if (_pc_53054 == _27397)
    goto L2; // [43] 92

    /** 			code = { ELSE, {INLINE_ADDR, length( inline_code ) + 1 }}*/
    if (IS_SEQUENCE(_67inline_code_52664)){
            _27399 = SEQ_PTR(_67inline_code_52664)->length;
    }
    else {
        _27399 = 1;
    }
    _27400 = _27399 + 1;
    _27399 = NOVALUE;
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 4;
    ((int *)_2)[2] = _27400;
    _27401 = MAKE_SEQ(_1);
    _27400 = NOVALUE;
    DeRefDS(_code_53060);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 23;
    ((int *)_2)[2] = _27401;
    _code_53060 = MAKE_SEQ(_1);
    _27401 = NOVALUE;

    /** 			if TRANSLATE then*/
    if (_35TRANSLATE_15887 == 0)
    {
        goto L3; // [72] 134
    }
    else{
    }

    /** 				inline_code[$] = NOP1*/
    if (IS_SEQUENCE(_67inline_code_52664)){
            _27403 = SEQ_PTR(_67inline_code_52664)->length;
    }
    else {
        _27403 = 1;
    }
    _2 = (int)SEQ_PTR(_67inline_code_52664);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _67inline_code_52664 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _27403);
    _1 = *(int *)_2;
    *(int *)_2 = 159;
    DeRef(_1);
    goto L3; // [89] 134
L2: 

    /** 		elsif TRANSLATE and inline_code[$] = BADRETURNF then*/
    if (_35TRANSLATE_15887 == 0) {
        goto L4; // [96] 133
    }
    if (IS_SEQUENCE(_67inline_code_52664)){
            _27405 = SEQ_PTR(_67inline_code_52664)->length;
    }
    else {
        _27405 = 1;
    }
    _2 = (int)SEQ_PTR(_67inline_code_52664);
    _27406 = (int)*(((s1_ptr)_2)->base + _27405);
    if (IS_ATOM_INT(_27406)) {
        _27407 = (_27406 == 43);
    }
    else {
        _27407 = binary_op(EQUALS, _27406, 43);
    }
    _27406 = NOVALUE;
    if (_27407 == 0) {
        DeRef(_27407);
        _27407 = NOVALUE;
        goto L4; // [116] 133
    }
    else {
        if (!IS_ATOM_INT(_27407) && DBL_PTR(_27407)->dbl == 0.0){
            DeRef(_27407);
            _27407 = NOVALUE;
            goto L4; // [116] 133
        }
        DeRef(_27407);
        _27407 = NOVALUE;
    }
    DeRef(_27407);
    _27407 = NOVALUE;

    /** 			inline_code[$] = NOP1*/
    if (IS_SEQUENCE(_67inline_code_52664)){
            _27408 = SEQ_PTR(_67inline_code_52664)->length;
    }
    else {
        _27408 = 1;
    }
    _2 = (int)SEQ_PTR(_67inline_code_52664);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _67inline_code_52664 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _27408);
    _1 = *(int *)_2;
    *(int *)_2 = 159;
    DeRef(_1);
L4: 
L3: 

    /** 		replace_code( code, pc, pc + 2 )*/
    _27409 = _pc_53054 + 2;
    if ((long)((unsigned long)_27409 + (unsigned long)HIGH_BITS) >= 0) 
    _27409 = NewDouble((double)_27409);
    RefDS(_code_53060);
    _67replace_code(_code_53060, _pc_53054, _27409);
    _27409 = NOVALUE;
    DeRefDS(_code_53060);
    _code_53060 = NOVALUE;
    goto L5; // [147] 526
L1: 

    /** 	elsif op = RETURNF then*/
    if (_op_53055 != 28)
    goto L6; // [154] 171

    /** 		return returnf( pc )*/
    _27411 = _67returnf(_pc_53054);
    DeRef(_27397);
    _27397 = NOVALUE;
    return _27411;
    goto L5; // [168] 526
L6: 

    /** 	elsif op = ROUTINE_ID then*/
    if (_op_53055 != 134)
    goto L7; // [175] 273

    /** 		integer*/

    /** 			stlen = inline_code[pc+2+TRANSLATE],*/
    _27413 = _pc_53054 + 2;
    if ((long)((unsigned long)_27413 + (unsigned long)HIGH_BITS) >= 0) 
    _27413 = NewDouble((double)_27413);
    if (IS_ATOM_INT(_27413)) {
        _27414 = _27413 + _35TRANSLATE_15887;
    }
    else {
        _27414 = NewDouble(DBL_PTR(_27413)->dbl + (double)_35TRANSLATE_15887);
    }
    DeRef(_27413);
    _27413 = NOVALUE;
    _2 = (int)SEQ_PTR(_67inline_code_52664);
    if (!IS_ATOM_INT(_27414)){
        _stlen_53093 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_27414)->dbl));
    }
    else{
        _stlen_53093 = (int)*(((s1_ptr)_2)->base + _27414);
    }
    if (!IS_ATOM_INT(_stlen_53093))
    _stlen_53093 = (long)DBL_PTR(_stlen_53093)->dbl;

    /** 			file  = inline_code[pc+4+TRANSLATE],*/
    _27416 = _pc_53054 + 4;
    if ((long)((unsigned long)_27416 + (unsigned long)HIGH_BITS) >= 0) 
    _27416 = NewDouble((double)_27416);
    if (IS_ATOM_INT(_27416)) {
        _27417 = _27416 + _35TRANSLATE_15887;
    }
    else {
        _27417 = NewDouble(DBL_PTR(_27416)->dbl + (double)_35TRANSLATE_15887);
    }
    DeRef(_27416);
    _27416 = NOVALUE;
    _2 = (int)SEQ_PTR(_67inline_code_52664);
    if (!IS_ATOM_INT(_27417)){
        _file_53098 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_27417)->dbl));
    }
    else{
        _file_53098 = (int)*(((s1_ptr)_2)->base + _27417);
    }
    if (!IS_ATOM_INT(_file_53098))
    _file_53098 = (long)DBL_PTR(_file_53098)->dbl;

    /** 			ok    = adjust_il( pc, op )*/
    _ok_53103 = _67adjust_il(_pc_53054, _op_53055);
    if (!IS_ATOM_INT(_ok_53103)) {
        _1 = (long)(DBL_PTR(_ok_53103)->dbl);
        DeRefDS(_ok_53103);
        _ok_53103 = _1;
    }

    /** 		inline_code[pc+2+TRANSLATE] = stlen*/
    _27420 = _pc_53054 + 2;
    if ((long)((unsigned long)_27420 + (unsigned long)HIGH_BITS) >= 0) 
    _27420 = NewDouble((double)_27420);
    if (IS_ATOM_INT(_27420)) {
        _27421 = _27420 + _35TRANSLATE_15887;
    }
    else {
        _27421 = NewDouble(DBL_PTR(_27420)->dbl + (double)_35TRANSLATE_15887);
    }
    DeRef(_27420);
    _27420 = NOVALUE;
    _2 = (int)SEQ_PTR(_67inline_code_52664);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _67inline_code_52664 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27421))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_27421)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _27421);
    _1 = *(int *)_2;
    *(int *)_2 = _stlen_53093;
    DeRef(_1);

    /** 		inline_code[pc+4+TRANSLATE] = file*/
    _27422 = _pc_53054 + 4;
    if ((long)((unsigned long)_27422 + (unsigned long)HIGH_BITS) >= 0) 
    _27422 = NewDouble((double)_27422);
    if (IS_ATOM_INT(_27422)) {
        _27423 = _27422 + _35TRANSLATE_15887;
    }
    else {
        _27423 = NewDouble(DBL_PTR(_27422)->dbl + (double)_35TRANSLATE_15887);
    }
    DeRef(_27422);
    _27422 = NOVALUE;
    _2 = (int)SEQ_PTR(_67inline_code_52664);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _67inline_code_52664 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27423))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_27423)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _27423);
    _1 = *(int *)_2;
    *(int *)_2 = _file_53098;
    DeRef(_1);

    /** 		return ok*/
    DeRef(_27411);
    _27411 = NOVALUE;
    DeRef(_27397);
    _27397 = NOVALUE;
    DeRef(_27414);
    _27414 = NOVALUE;
    DeRef(_27417);
    _27417 = NOVALUE;
    DeRef(_27421);
    _27421 = NOVALUE;
    DeRef(_27423);
    _27423 = NOVALUE;
    return _ok_53103;
    goto L5; // [270] 526
L7: 

    /** 	elsif op_info[op][OP_SIZE_TYPE] = FIXED_SIZE then*/
    _2 = (int)SEQ_PTR(_65op_info_26607);
    _27424 = (int)*(((s1_ptr)_2)->base + _op_53055);
    _2 = (int)SEQ_PTR(_27424);
    _27425 = (int)*(((s1_ptr)_2)->base + 1);
    _27424 = NOVALUE;
    if (binary_op_a(NOTEQ, _27425, 1)){
        _27425 = NOVALUE;
        goto L8; // [289] 397
    }
    _27425 = NOVALUE;

    /** 		switch op do*/
    _0 = _op_53055;
    switch ( _0 ){ 

        /** 			case SWITCH, SWITCH_RT, SWITCH_I, SWITCH_SPI then*/
        case 185:
        case 202:
        case 193:
        case 192:

        /** 				symtab_index original_table = inline_code[pc + 3]*/
        _27429 = _pc_53054 + 3;
        _2 = (int)SEQ_PTR(_67inline_code_52664);
        _original_table_53126 = (int)*(((s1_ptr)_2)->base + _27429);
        if (!IS_ATOM_INT(_original_table_53126)){
            _original_table_53126 = (long)DBL_PTR(_original_table_53126)->dbl;
        }

        /** 				symtab_index jump_table = NewStringSym( {-2, length(SymTab) } )*/
        if (IS_SEQUENCE(_36SymTab_15242)){
                _27431 = SEQ_PTR(_36SymTab_15242)->length;
        }
        else {
            _27431 = 1;
        }
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = -2;
        ((int *)_2)[2] = _27431;
        _27432 = MAKE_SEQ(_1);
        _27431 = NOVALUE;
        _jump_table_53130 = _53NewStringSym(_27432);
        _27432 = NOVALUE;
        if (!IS_ATOM_INT(_jump_table_53130)) {
            _1 = (long)(DBL_PTR(_jump_table_53130)->dbl);
            DeRefDS(_jump_table_53130);
            _jump_table_53130 = _1;
        }

        /** 				SymTab[jump_table][S_OBJ] = SymTab[original_table][S_OBJ]*/
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _36SymTab_15242 = MAKE_SEQ(_2);
        }
        _3 = (int)(_jump_table_53130 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _27436 = (int)*(((s1_ptr)_2)->base + _original_table_53126);
        _2 = (int)SEQ_PTR(_27436);
        _27437 = (int)*(((s1_ptr)_2)->base + 1);
        _27436 = NOVALUE;
        Ref(_27437);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 1);
        _1 = *(int *)_2;
        *(int *)_2 = _27437;
        if( _1 != _27437 ){
            DeRef(_1);
        }
        _27437 = NOVALUE;
        _27434 = NOVALUE;

        /** 				inline_code[pc+3] = jump_table*/
        _27438 = _pc_53054 + 3;
        _2 = (int)SEQ_PTR(_67inline_code_52664);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _67inline_code_52664 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _27438);
        _1 = *(int *)_2;
        *(int *)_2 = _jump_table_53130;
        DeRef(_1);
    ;}
    /** 		return adjust_il( pc, op )*/
    _27439 = _67adjust_il(_pc_53054, _op_53055);
    DeRef(_27411);
    _27411 = NOVALUE;
    DeRef(_27397);
    _27397 = NOVALUE;
    DeRef(_27429);
    _27429 = NOVALUE;
    DeRef(_27414);
    _27414 = NOVALUE;
    DeRef(_27417);
    _27417 = NOVALUE;
    DeRef(_27421);
    _27421 = NOVALUE;
    DeRef(_27423);
    _27423 = NOVALUE;
    DeRef(_27438);
    _27438 = NOVALUE;
    return _27439;
    goto L5; // [394] 526
L8: 

    /** 		switch op with fallthru do*/
    _0 = _op_53055;
    switch ( _0 ){ 

        /** 			case REF_TEMP then*/
        case 207:

        /** 				inline_code[pc+1] = {INLINE_TARGET}*/
        _27442 = _pc_53054 + 1;
        RefDS(_27357);
        _2 = (int)SEQ_PTR(_67inline_code_52664);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _67inline_code_52664 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _27442);
        _1 = *(int *)_2;
        *(int *)_2 = _27357;
        DeRef(_1);

        /** 			case CONCAT_N then*/
        case 157:
        case 31:

        /** 				if check_for_param( pc + 2 + inline_code[pc+1] ) then*/
        _27443 = _pc_53054 + 2;
        if ((long)((unsigned long)_27443 + (unsigned long)HIGH_BITS) >= 0) 
        _27443 = NewDouble((double)_27443);
        _27444 = _pc_53054 + 1;
        _2 = (int)SEQ_PTR(_67inline_code_52664);
        _27445 = (int)*(((s1_ptr)_2)->base + _27444);
        if (IS_ATOM_INT(_27443) && IS_ATOM_INT(_27445)) {
            _27446 = _27443 + _27445;
            if ((long)((unsigned long)_27446 + (unsigned long)HIGH_BITS) >= 0) 
            _27446 = NewDouble((double)_27446);
        }
        else {
            _27446 = binary_op(PLUS, _27443, _27445);
        }
        DeRef(_27443);
        _27443 = NOVALUE;
        _27445 = NOVALUE;
        _27447 = _67check_for_param(_27446);
        _27446 = NOVALUE;
        if (_27447 == 0) {
            DeRef(_27447);
            _27447 = NOVALUE;
            goto L9; // [450] 454
        }
        else {
            if (!IS_ATOM_INT(_27447) && DBL_PTR(_27447)->dbl == 0.0){
                DeRef(_27447);
                _27447 = NOVALUE;
                goto L9; // [450] 454
            }
            DeRef(_27447);
            _27447 = NOVALUE;
        }
        DeRef(_27447);
        _27447 = NOVALUE;
L9: 

        /** 				for i = pc + 2 to pc + 2 + inline_code[pc+1] do*/
        _27448 = _pc_53054 + 2;
        if ((long)((unsigned long)_27448 + (unsigned long)HIGH_BITS) >= 0) 
        _27448 = NewDouble((double)_27448);
        _27449 = _pc_53054 + 2;
        if ((long)((unsigned long)_27449 + (unsigned long)HIGH_BITS) >= 0) 
        _27449 = NewDouble((double)_27449);
        _27450 = _pc_53054 + 1;
        _2 = (int)SEQ_PTR(_67inline_code_52664);
        _27451 = (int)*(((s1_ptr)_2)->base + _27450);
        if (IS_ATOM_INT(_27449) && IS_ATOM_INT(_27451)) {
            _27452 = _27449 + _27451;
            if ((long)((unsigned long)_27452 + (unsigned long)HIGH_BITS) >= 0) 
            _27452 = NewDouble((double)_27452);
        }
        else {
            _27452 = binary_op(PLUS, _27449, _27451);
        }
        DeRef(_27449);
        _27449 = NOVALUE;
        _27451 = NOVALUE;
        {
            int _i_53162;
            Ref(_27448);
            _i_53162 = _27448;
LA: 
            if (binary_op_a(GREATER, _i_53162, _27452)){
                goto LB; // [478] 508
            }

            /** 					if not adjust_symbol( i ) then*/
            Ref(_i_53162);
            _27453 = _67adjust_symbol(_i_53162);
            if (IS_ATOM_INT(_27453)) {
                if (_27453 != 0){
                    DeRef(_27453);
                    _27453 = NOVALUE;
                    goto LC; // [491] 501
                }
            }
            else {
                if (DBL_PTR(_27453)->dbl != 0.0){
                    DeRef(_27453);
                    _27453 = NOVALUE;
                    goto LC; // [491] 501
                }
            }
            DeRef(_27453);
            _27453 = NOVALUE;

            /** 						return 0*/
            DeRef(_i_53162);
            DeRef(_27411);
            _27411 = NOVALUE;
            DeRef(_27397);
            _27397 = NOVALUE;
            DeRef(_27429);
            _27429 = NOVALUE;
            DeRef(_27414);
            _27414 = NOVALUE;
            DeRef(_27417);
            _27417 = NOVALUE;
            DeRef(_27421);
            _27421 = NOVALUE;
            DeRef(_27423);
            _27423 = NOVALUE;
            DeRef(_27438);
            _27438 = NOVALUE;
            DeRef(_27439);
            _27439 = NOVALUE;
            DeRef(_27442);
            _27442 = NOVALUE;
            DeRef(_27448);
            _27448 = NOVALUE;
            DeRef(_27444);
            _27444 = NOVALUE;
            DeRef(_27450);
            _27450 = NOVALUE;
            DeRef(_27452);
            _27452 = NOVALUE;
            return 0;
LC: 

            /** 				end for*/
            _0 = _i_53162;
            if (IS_ATOM_INT(_i_53162)) {
                _i_53162 = _i_53162 + 1;
                if ((long)((unsigned long)_i_53162 +(unsigned long) HIGH_BITS) >= 0){
                    _i_53162 = NewDouble((double)_i_53162);
                }
            }
            else {
                _i_53162 = binary_op_a(PLUS, _i_53162, 1);
            }
            DeRef(_0);
            goto LA; // [503] 485
LB: 
            ;
            DeRef(_i_53162);
        }

        /** 				return 1*/
        DeRef(_27411);
        _27411 = NOVALUE;
        DeRef(_27397);
        _27397 = NOVALUE;
        DeRef(_27429);
        _27429 = NOVALUE;
        DeRef(_27414);
        _27414 = NOVALUE;
        DeRef(_27417);
        _27417 = NOVALUE;
        DeRef(_27421);
        _27421 = NOVALUE;
        DeRef(_27423);
        _27423 = NOVALUE;
        DeRef(_27438);
        _27438 = NOVALUE;
        DeRef(_27439);
        _27439 = NOVALUE;
        DeRef(_27442);
        _27442 = NOVALUE;
        DeRef(_27448);
        _27448 = NOVALUE;
        DeRef(_27444);
        _27444 = NOVALUE;
        DeRef(_27450);
        _27450 = NOVALUE;
        DeRef(_27452);
        _27452 = NOVALUE;
        return 1;

        /** 			case else*/
        default:

        /** 				return 0*/
        DeRef(_27411);
        _27411 = NOVALUE;
        DeRef(_27397);
        _27397 = NOVALUE;
        DeRef(_27429);
        _27429 = NOVALUE;
        DeRef(_27414);
        _27414 = NOVALUE;
        DeRef(_27417);
        _27417 = NOVALUE;
        DeRef(_27421);
        _27421 = NOVALUE;
        DeRef(_27423);
        _27423 = NOVALUE;
        DeRef(_27438);
        _27438 = NOVALUE;
        DeRef(_27439);
        _27439 = NOVALUE;
        DeRef(_27442);
        _27442 = NOVALUE;
        DeRef(_27448);
        _27448 = NOVALUE;
        DeRef(_27444);
        _27444 = NOVALUE;
        DeRef(_27450);
        _27450 = NOVALUE;
        DeRef(_27452);
        _27452 = NOVALUE;
        return 0;
    ;}L5: 

    /** 	return 1*/
    DeRef(_27411);
    _27411 = NOVALUE;
    DeRef(_27397);
    _27397 = NOVALUE;
    DeRef(_27429);
    _27429 = NOVALUE;
    DeRef(_27414);
    _27414 = NOVALUE;
    DeRef(_27417);
    _27417 = NOVALUE;
    DeRef(_27421);
    _27421 = NOVALUE;
    DeRef(_27423);
    _27423 = NOVALUE;
    DeRef(_27438);
    _27438 = NOVALUE;
    DeRef(_27439);
    _27439 = NOVALUE;
    DeRef(_27442);
    _27442 = NOVALUE;
    DeRef(_27448);
    _27448 = NOVALUE;
    DeRef(_27444);
    _27444 = NOVALUE;
    DeRef(_27450);
    _27450 = NOVALUE;
    DeRef(_27452);
    _27452 = NOVALUE;
    return 1;
    ;
}


void _67restore_code()
{
    int _27455 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if length( temp_code ) then*/
    if (IS_SEQUENCE(_67temp_code_53172)){
            _27455 = SEQ_PTR(_67temp_code_53172)->length;
    }
    else {
        _27455 = 1;
    }
    if (_27455 == 0)
    {
        _27455 = NOVALUE;
        goto L1; // [8] 21
    }
    else{
        _27455 = NOVALUE;
    }

    /** 		Code = temp_code*/
    RefDS(_67temp_code_53172);
    DeRef(_35Code_16332);
    _35Code_16332 = _67temp_code_53172;
L1: 

    /** end procedure*/
    return;
    ;
}


void _67check_inline(int _sub_53181)
{
    int _pc_53210 = NOVALUE;
    int _s_53212 = NOVALUE;
    int _backpatch_op_53250 = NOVALUE;
    int _op_53254 = NOVALUE;
    int _rtn_idx_53265 = NOVALUE;
    int _args_53270 = NOVALUE;
    int _args_53302 = NOVALUE;
    int _values_53331 = NOVALUE;
    int _27542 = NOVALUE;
    int _27541 = NOVALUE;
    int _27539 = NOVALUE;
    int _27536 = NOVALUE;
    int _27534 = NOVALUE;
    int _27533 = NOVALUE;
    int _27532 = NOVALUE;
    int _27530 = NOVALUE;
    int _27529 = NOVALUE;
    int _27528 = NOVALUE;
    int _27527 = NOVALUE;
    int _27526 = NOVALUE;
    int _27525 = NOVALUE;
    int _27524 = NOVALUE;
    int _27523 = NOVALUE;
    int _27522 = NOVALUE;
    int _27520 = NOVALUE;
    int _27519 = NOVALUE;
    int _27518 = NOVALUE;
    int _27517 = NOVALUE;
    int _27516 = NOVALUE;
    int _27514 = NOVALUE;
    int _27513 = NOVALUE;
    int _27512 = NOVALUE;
    int _27511 = NOVALUE;
    int _27510 = NOVALUE;
    int _27508 = NOVALUE;
    int _27507 = NOVALUE;
    int _27506 = NOVALUE;
    int _27505 = NOVALUE;
    int _27504 = NOVALUE;
    int _27503 = NOVALUE;
    int _27502 = NOVALUE;
    int _27501 = NOVALUE;
    int _27500 = NOVALUE;
    int _27499 = NOVALUE;
    int _27498 = NOVALUE;
    int _27497 = NOVALUE;
    int _27496 = NOVALUE;
    int _27495 = NOVALUE;
    int _27493 = NOVALUE;
    int _27490 = NOVALUE;
    int _27485 = NOVALUE;
    int _27483 = NOVALUE;
    int _27480 = NOVALUE;
    int _27479 = NOVALUE;
    int _27478 = NOVALUE;
    int _27477 = NOVALUE;
    int _27476 = NOVALUE;
    int _27475 = NOVALUE;
    int _27474 = NOVALUE;
    int _27473 = NOVALUE;
    int _27471 = NOVALUE;
    int _27469 = NOVALUE;
    int _27468 = NOVALUE;
    int _27466 = NOVALUE;
    int _27464 = NOVALUE;
    int _27462 = NOVALUE;
    int _27460 = NOVALUE;
    int _27459 = NOVALUE;
    int _27458 = NOVALUE;
    int _27457 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_sub_53181)) {
        _1 = (long)(DBL_PTR(_sub_53181)->dbl);
        DeRefDS(_sub_53181);
        _sub_53181 = _1;
    }

    /** 	if OpTrace or SymTab[sub][S_TOKEN] = TYPE then*/
    if (_35OpTrace_16313 != 0) {
        goto L1; // [7] 34
    }
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _27457 = (int)*(((s1_ptr)_2)->base + _sub_53181);
    _2 = (int)SEQ_PTR(_27457);
    if (!IS_ATOM_INT(_35S_TOKEN_15922)){
        _27458 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TOKEN_15922)->dbl));
    }
    else{
        _27458 = (int)*(((s1_ptr)_2)->base + _35S_TOKEN_15922);
    }
    _27457 = NOVALUE;
    if (IS_ATOM_INT(_27458)) {
        _27459 = (_27458 == 504);
    }
    else {
        _27459 = binary_op(EQUALS, _27458, 504);
    }
    _27458 = NOVALUE;
    if (_27459 == 0) {
        DeRef(_27459);
        _27459 = NOVALUE;
        goto L2; // [30] 40
    }
    else {
        if (!IS_ATOM_INT(_27459) && DBL_PTR(_27459)->dbl == 0.0){
            DeRef(_27459);
            _27459 = NOVALUE;
            goto L2; // [30] 40
        }
        DeRef(_27459);
        _27459 = NOVALUE;
    }
    DeRef(_27459);
    _27459 = NOVALUE;
L1: 

    /** 		return*/
    DeRefi(_backpatch_op_53250);
    return;
L2: 

    /** 	inline_sub      = sub*/
    _67inline_sub_52678 = _sub_53181;

    /** 	if get_fwdref_count() then*/
    _27460 = _38get_fwdref_count();
    if (_27460 == 0) {
        DeRef(_27460);
        _27460 = NOVALUE;
        goto L3; // [52] 65
    }
    else {
        if (!IS_ATOM_INT(_27460) && DBL_PTR(_27460)->dbl == 0.0){
            DeRef(_27460);
            _27460 = NOVALUE;
            goto L3; // [52] 65
        }
        DeRef(_27460);
        _27460 = NOVALUE;
    }
    DeRef(_27460);
    _27460 = NOVALUE;

    /** 		defer()*/
    _67defer();

    /** 		return*/
    DeRefi(_backpatch_op_53250);
    return;
L3: 

    /** 	temp_code = ""*/
    RefDS(_22023);
    DeRef(_67temp_code_53172);
    _67temp_code_53172 = _22023;

    /** 	if sub != CurrentSub then*/
    if (_sub_53181 == _35CurrentSub_16252)
    goto L4; // [76] 99

    /** 		Code = SymTab[sub][S_CODE]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _27462 = (int)*(((s1_ptr)_2)->base + _sub_53181);
    DeRef(_35Code_16332);
    _2 = (int)SEQ_PTR(_27462);
    if (!IS_ATOM_INT(_35S_CODE_15929)){
        _35Code_16332 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_CODE_15929)->dbl));
    }
    else{
        _35Code_16332 = (int)*(((s1_ptr)_2)->base + _35S_CODE_15929);
    }
    Ref(_35Code_16332);
    _27462 = NOVALUE;
    goto L5; // [96] 109
L4: 

    /** 		temp_code = Code*/
    RefDS(_35Code_16332);
    DeRef(_67temp_code_53172);
    _67temp_code_53172 = _35Code_16332;
L5: 

    /** 	if length(Code) > OpInline then*/
    if (IS_SEQUENCE(_35Code_16332)){
            _27464 = SEQ_PTR(_35Code_16332)->length;
    }
    else {
        _27464 = 1;
    }
    if (_27464 <= _35OpInline_16318)
    goto L6; // [118] 128

    /** 		return*/
    DeRefi(_backpatch_op_53250);
    return;
L6: 

    /** 	inline_code     = Code*/
    RefDS(_35Code_16332);
    DeRef(_67inline_code_52664);
    _67inline_code_52664 = _35Code_16332;

    /** 	return_gotos    = 0*/
    _67return_gotos_52673 = 0;

    /** 	prev_pc         = 1*/
    _67prev_pc_52672 = 1;

    /** 	proc_vars       = {}*/
    RefDS(_22023);
    DeRefi(_67proc_vars_52665);
    _67proc_vars_52665 = _22023;

    /** 	inline_temps    = {}*/
    RefDS(_22023);
    DeRef(_67inline_temps_52666);
    _67inline_temps_52666 = _22023;

    /** 	inline_params   = {}*/
    RefDS(_22023);
    DeRefi(_67inline_params_52669);
    _67inline_params_52669 = _22023;

    /** 	assigned_params = {}*/
    RefDS(_22023);
    DeRef(_67assigned_params_52670);
    _67assigned_params_52670 = _22023;

    /** 	integer pc = 1*/
    _pc_53210 = 1;

    /** 	symtab_index s = SymTab[sub][S_NEXT]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _27466 = (int)*(((s1_ptr)_2)->base + _sub_53181);
    _2 = (int)SEQ_PTR(_27466);
    _s_53212 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_53212)){
        _s_53212 = (long)DBL_PTR(_s_53212)->dbl;
    }
    _27466 = NOVALUE;

    /** 	for p = 1 to SymTab[sub][S_NUM_ARGS] do*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _27468 = (int)*(((s1_ptr)_2)->base + _sub_53181);
    _2 = (int)SEQ_PTR(_27468);
    if (!IS_ATOM_INT(_35S_NUM_ARGS_15968)){
        _27469 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NUM_ARGS_15968)->dbl));
    }
    else{
        _27469 = (int)*(((s1_ptr)_2)->base + _35S_NUM_ARGS_15968);
    }
    _27468 = NOVALUE;
    {
        int _p_53218;
        _p_53218 = 1;
L7: 
        if (binary_op_a(GREATER, _p_53218, _27469)){
            goto L8; // [210] 248
        }

        /** 		inline_params &= s*/
        Append(&_67inline_params_52669, _67inline_params_52669, _s_53212);

        /** 		s = SymTab[s][S_NEXT]*/
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _27471 = (int)*(((s1_ptr)_2)->base + _s_53212);
        _2 = (int)SEQ_PTR(_27471);
        _s_53212 = (int)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_s_53212)){
            _s_53212 = (long)DBL_PTR(_s_53212)->dbl;
        }
        _27471 = NOVALUE;

        /** 	end for*/
        _0 = _p_53218;
        if (IS_ATOM_INT(_p_53218)) {
            _p_53218 = _p_53218 + 1;
            if ((long)((unsigned long)_p_53218 +(unsigned long) HIGH_BITS) >= 0){
                _p_53218 = NewDouble((double)_p_53218);
            }
        }
        else {
            _p_53218 = binary_op_a(PLUS, _p_53218, 1);
        }
        DeRef(_0);
        goto L7; // [243] 217
L8: 
        ;
        DeRef(_p_53218);
    }

    /** 	while s != 0 and */
L9: 
    _27473 = (_s_53212 != 0);
    if (_27473 == 0) {
        goto LA; // [257] 335
    }
    _27475 = _53sym_scope(_s_53212);
    if (IS_ATOM_INT(_27475)) {
        _27476 = (_27475 <= 3);
    }
    else {
        _27476 = binary_op(LESSEQ, _27475, 3);
    }
    DeRef(_27475);
    _27475 = NOVALUE;
    if (IS_ATOM_INT(_27476)) {
        if (_27476 != 0) {
            DeRef(_27477);
            _27477 = 1;
            goto LB; // [271] 289
        }
    }
    else {
        if (DBL_PTR(_27476)->dbl != 0.0) {
            DeRef(_27477);
            _27477 = 1;
            goto LB; // [271] 289
        }
    }
    _27478 = _53sym_scope(_s_53212);
    if (IS_ATOM_INT(_27478)) {
        _27479 = (_27478 == 9);
    }
    else {
        _27479 = binary_op(EQUALS, _27478, 9);
    }
    DeRef(_27478);
    _27478 = NOVALUE;
    DeRef(_27477);
    if (IS_ATOM_INT(_27479))
    _27477 = (_27479 != 0);
    else
    _27477 = DBL_PTR(_27479)->dbl != 0.0;
LB: 
    if (_27477 == 0)
    {
        _27477 = NOVALUE;
        goto LA; // [290] 335
    }
    else{
        _27477 = NOVALUE;
    }

    /** 		if sym_scope( s ) != SC_UNDEFINED then*/
    _27480 = _53sym_scope(_s_53212);
    if (binary_op_a(EQUALS, _27480, 9)){
        DeRef(_27480);
        _27480 = NOVALUE;
        goto LC; // [301] 314
    }
    DeRef(_27480);
    _27480 = NOVALUE;

    /** 			proc_vars &= s*/
    Append(&_67proc_vars_52665, _67proc_vars_52665, _s_53212);
LC: 

    /** 		s = SymTab[s][S_NEXT]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _27483 = (int)*(((s1_ptr)_2)->base + _s_53212);
    _2 = (int)SEQ_PTR(_27483);
    _s_53212 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_53212)){
        _s_53212 = (long)DBL_PTR(_s_53212)->dbl;
    }
    _27483 = NOVALUE;

    /** 	end while*/
    goto L9; // [332] 253
LA: 

    /** 	sequence backpatch_op = {}*/
    RefDS(_22023);
    DeRefi(_backpatch_op_53250);
    _backpatch_op_53250 = _22023;

    /** 	while pc < length( inline_code ) do*/
LD: 
    if (IS_SEQUENCE(_67inline_code_52664)){
            _27485 = SEQ_PTR(_67inline_code_52664)->length;
    }
    else {
        _27485 = 1;
    }
    if (_pc_53210 >= _27485)
    goto LE; // [352] 869

    /** 		integer op = inline_code[pc]*/
    _2 = (int)SEQ_PTR(_67inline_code_52664);
    _op_53254 = (int)*(((s1_ptr)_2)->base + _pc_53210);
    if (!IS_ATOM_INT(_op_53254))
    _op_53254 = (long)DBL_PTR(_op_53254)->dbl;

    /** 		switch op do*/
    _0 = _op_53254;
    switch ( _0 ){ 

        /** 			case PROC_FORWARD, FUNC_FORWARD then*/
        case 195:
        case 196:

        /** 				defer()*/
        _67defer();

        /** 				restore_code()*/
        _67restore_code();

        /** 				return*/
        DeRefi(_backpatch_op_53250);
        _27469 = NOVALUE;
        DeRef(_27473);
        _27473 = NOVALUE;
        DeRef(_27476);
        _27476 = NOVALUE;
        DeRef(_27479);
        _27479 = NOVALUE;
        return;
        goto LF; // [390] 851

        /** 			case PROC, FUNC then*/
        case 27:
        case 501:

        /** 				symtab_index rtn_idx = inline_code[pc+1]*/
        _27490 = _pc_53210 + 1;
        _2 = (int)SEQ_PTR(_67inline_code_52664);
        _rtn_idx_53265 = (int)*(((s1_ptr)_2)->base + _27490);
        if (!IS_ATOM_INT(_rtn_idx_53265)){
            _rtn_idx_53265 = (long)DBL_PTR(_rtn_idx_53265)->dbl;
        }

        /** 				if rtn_idx = sub then*/
        if (_rtn_idx_53265 != _sub_53181)
        goto L10; // [414] 428

        /** 					restore_code()*/
        _67restore_code();

        /** 					return*/
        DeRefi(_backpatch_op_53250);
        _27469 = NOVALUE;
        DeRef(_27473);
        _27473 = NOVALUE;
        _27490 = NOVALUE;
        DeRef(_27476);
        _27476 = NOVALUE;
        DeRef(_27479);
        _27479 = NOVALUE;
        return;
L10: 

        /** 				integer args = SymTab[rtn_idx][S_NUM_ARGS]*/
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _27493 = (int)*(((s1_ptr)_2)->base + _rtn_idx_53265);
        _2 = (int)SEQ_PTR(_27493);
        if (!IS_ATOM_INT(_35S_NUM_ARGS_15968)){
            _args_53270 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NUM_ARGS_15968)->dbl));
        }
        else{
            _args_53270 = (int)*(((s1_ptr)_2)->base + _35S_NUM_ARGS_15968);
        }
        if (!IS_ATOM_INT(_args_53270)){
            _args_53270 = (long)DBL_PTR(_args_53270)->dbl;
        }
        _27493 = NOVALUE;

        /** 				if SymTab[rtn_idx][S_TOKEN] != PROC and check_for_param( pc + args + 2 ) then*/
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _27495 = (int)*(((s1_ptr)_2)->base + _rtn_idx_53265);
        _2 = (int)SEQ_PTR(_27495);
        if (!IS_ATOM_INT(_35S_TOKEN_15922)){
            _27496 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TOKEN_15922)->dbl));
        }
        else{
            _27496 = (int)*(((s1_ptr)_2)->base + _35S_TOKEN_15922);
        }
        _27495 = NOVALUE;
        if (IS_ATOM_INT(_27496)) {
            _27497 = (_27496 != 27);
        }
        else {
            _27497 = binary_op(NOTEQ, _27496, 27);
        }
        _27496 = NOVALUE;
        if (IS_ATOM_INT(_27497)) {
            if (_27497 == 0) {
                goto L11; // [464] 485
            }
        }
        else {
            if (DBL_PTR(_27497)->dbl == 0.0) {
                goto L11; // [464] 485
            }
        }
        _27499 = _pc_53210 + _args_53270;
        if ((long)((unsigned long)_27499 + (unsigned long)HIGH_BITS) >= 0) 
        _27499 = NewDouble((double)_27499);
        if (IS_ATOM_INT(_27499)) {
            _27500 = _27499 + 2;
            if ((long)((unsigned long)_27500 + (unsigned long)HIGH_BITS) >= 0) 
            _27500 = NewDouble((double)_27500);
        }
        else {
            _27500 = NewDouble(DBL_PTR(_27499)->dbl + (double)2);
        }
        DeRef(_27499);
        _27499 = NOVALUE;
        _27501 = _67check_for_param(_27500);
        _27500 = NOVALUE;
        if (_27501 == 0) {
            DeRef(_27501);
            _27501 = NOVALUE;
            goto L11; // [481] 485
        }
        else {
            if (!IS_ATOM_INT(_27501) && DBL_PTR(_27501)->dbl == 0.0){
                DeRef(_27501);
                _27501 = NOVALUE;
                goto L11; // [481] 485
            }
            DeRef(_27501);
            _27501 = NOVALUE;
        }
        DeRef(_27501);
        _27501 = NOVALUE;
L11: 

        /** 				for i = 2 to args + 1 + (SymTab[rtn_idx][S_TOKEN] != PROC) do*/
        _27502 = _args_53270 + 1;
        if (_27502 > MAXINT){
            _27502 = NewDouble((double)_27502);
        }
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _27503 = (int)*(((s1_ptr)_2)->base + _rtn_idx_53265);
        _2 = (int)SEQ_PTR(_27503);
        if (!IS_ATOM_INT(_35S_TOKEN_15922)){
            _27504 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TOKEN_15922)->dbl));
        }
        else{
            _27504 = (int)*(((s1_ptr)_2)->base + _35S_TOKEN_15922);
        }
        _27503 = NOVALUE;
        if (IS_ATOM_INT(_27504)) {
            _27505 = (_27504 != 27);
        }
        else {
            _27505 = binary_op(NOTEQ, _27504, 27);
        }
        _27504 = NOVALUE;
        if (IS_ATOM_INT(_27502) && IS_ATOM_INT(_27505)) {
            _27506 = _27502 + _27505;
            if ((long)((unsigned long)_27506 + (unsigned long)HIGH_BITS) >= 0) 
            _27506 = NewDouble((double)_27506);
        }
        else {
            _27506 = binary_op(PLUS, _27502, _27505);
        }
        DeRef(_27502);
        _27502 = NOVALUE;
        DeRef(_27505);
        _27505 = NOVALUE;
        {
            int _i_53287;
            _i_53287 = 2;
L12: 
            if (binary_op_a(GREATER, _i_53287, _27506)){
                goto L13; // [513] 550
            }

            /** 					if not adjust_symbol( pc + i ) then */
            if (IS_ATOM_INT(_i_53287)) {
                _27507 = _pc_53210 + _i_53287;
                if ((long)((unsigned long)_27507 + (unsigned long)HIGH_BITS) >= 0) 
                _27507 = NewDouble((double)_27507);
            }
            else {
                _27507 = NewDouble((double)_pc_53210 + DBL_PTR(_i_53287)->dbl);
            }
            _27508 = _67adjust_symbol(_27507);
            _27507 = NOVALUE;
            if (IS_ATOM_INT(_27508)) {
                if (_27508 != 0){
                    DeRef(_27508);
                    _27508 = NOVALUE;
                    goto L14; // [530] 543
                }
            }
            else {
                if (DBL_PTR(_27508)->dbl != 0.0){
                    DeRef(_27508);
                    _27508 = NOVALUE;
                    goto L14; // [530] 543
                }
            }
            DeRef(_27508);
            _27508 = NOVALUE;

            /** 						defer()*/
            _67defer();

            /** 						return*/
            DeRef(_i_53287);
            DeRefi(_backpatch_op_53250);
            _27469 = NOVALUE;
            DeRef(_27473);
            _27473 = NOVALUE;
            DeRef(_27490);
            _27490 = NOVALUE;
            DeRef(_27476);
            _27476 = NOVALUE;
            DeRef(_27479);
            _27479 = NOVALUE;
            DeRef(_27497);
            _27497 = NOVALUE;
            DeRef(_27506);
            _27506 = NOVALUE;
            return;
L14: 

            /** 				end for*/
            _0 = _i_53287;
            if (IS_ATOM_INT(_i_53287)) {
                _i_53287 = _i_53287 + 1;
                if ((long)((unsigned long)_i_53287 +(unsigned long) HIGH_BITS) >= 0){
                    _i_53287 = NewDouble((double)_i_53287);
                }
            }
            else {
                _i_53287 = binary_op_a(PLUS, _i_53287, 1);
            }
            DeRef(_0);
            goto L12; // [545] 520
L13: 
            ;
            DeRef(_i_53287);
        }
        goto LF; // [552] 851

        /** 			case RIGHT_BRACE_N then*/
        case 31:

        /** 				sequence args = inline_code[pc+2..inline_code[pc+1] + pc + 1]*/
        _27510 = _pc_53210 + 2;
        if ((long)((unsigned long)_27510 + (unsigned long)HIGH_BITS) >= 0) 
        _27510 = NewDouble((double)_27510);
        _27511 = _pc_53210 + 1;
        _2 = (int)SEQ_PTR(_67inline_code_52664);
        _27512 = (int)*(((s1_ptr)_2)->base + _27511);
        if (IS_ATOM_INT(_27512)) {
            _27513 = _27512 + _pc_53210;
            if ((long)((unsigned long)_27513 + (unsigned long)HIGH_BITS) >= 0) 
            _27513 = NewDouble((double)_27513);
        }
        else {
            _27513 = binary_op(PLUS, _27512, _pc_53210);
        }
        _27512 = NOVALUE;
        if (IS_ATOM_INT(_27513)) {
            _27514 = _27513 + 1;
        }
        else
        _27514 = binary_op(PLUS, 1, _27513);
        DeRef(_27513);
        _27513 = NOVALUE;
        rhs_slice_target = (object_ptr)&_args_53302;
        RHS_Slice(_67inline_code_52664, _27510, _27514);

        /** 				for i = 1 to length(args) - 1 do*/
        if (IS_SEQUENCE(_args_53302)){
                _27516 = SEQ_PTR(_args_53302)->length;
        }
        else {
            _27516 = 1;
        }
        _27517 = _27516 - 1;
        _27516 = NOVALUE;
        {
            int _i_53310;
            _i_53310 = 1;
L15: 
            if (_i_53310 > _27517){
                goto L16; // [598] 644
            }

            /** 					if find( args[i], args, i + 1 ) then*/
            _2 = (int)SEQ_PTR(_args_53302);
            _27518 = (int)*(((s1_ptr)_2)->base + _i_53310);
            _27519 = _i_53310 + 1;
            _27520 = find_from(_27518, _args_53302, _27519);
            _27518 = NOVALUE;
            _27519 = NOVALUE;
            if (_27520 == 0)
            {
                _27520 = NOVALUE;
                goto L17; // [620] 637
            }
            else{
                _27520 = NOVALUE;
            }

            /** 						defer()*/
            _67defer();

            /** 						restore_code()*/
            _67restore_code();

            /** 						return*/
            DeRefDS(_args_53302);
            DeRefi(_backpatch_op_53250);
            _27469 = NOVALUE;
            DeRef(_27473);
            _27473 = NOVALUE;
            DeRef(_27490);
            _27490 = NOVALUE;
            DeRef(_27476);
            _27476 = NOVALUE;
            DeRef(_27479);
            _27479 = NOVALUE;
            DeRef(_27510);
            _27510 = NOVALUE;
            DeRef(_27497);
            _27497 = NOVALUE;
            DeRef(_27506);
            _27506 = NOVALUE;
            DeRef(_27511);
            _27511 = NOVALUE;
            DeRef(_27514);
            _27514 = NOVALUE;
            DeRef(_27517);
            _27517 = NOVALUE;
            return;
L17: 

            /** 				end for*/
            _i_53310 = _i_53310 + 1;
            goto L15; // [639] 605
L16: 
            ;
        }

        /** 				goto "inline op"*/
        DeRef(_args_53302);
        _args_53302 = NOVALUE;
        goto G18;
        goto LF; // [654] 851

        /** 			case RIGHT_BRACE_2 then*/
        case 85:

        /** 				if equal( inline_code[pc+1], inline_code[pc+2] ) then*/
        _27522 = _pc_53210 + 1;
        _2 = (int)SEQ_PTR(_67inline_code_52664);
        _27523 = (int)*(((s1_ptr)_2)->base + _27522);
        _27524 = _pc_53210 + 2;
        _2 = (int)SEQ_PTR(_67inline_code_52664);
        _27525 = (int)*(((s1_ptr)_2)->base + _27524);
        if (_27523 == _27525)
        _27526 = 1;
        else if (IS_ATOM_INT(_27523) && IS_ATOM_INT(_27525))
        _27526 = 0;
        else
        _27526 = (compare(_27523, _27525) == 0);
        _27523 = NOVALUE;
        _27525 = NOVALUE;
        if (_27526 == 0)
        {
            _27526 = NOVALUE;
            goto L19; // [686] 703
        }
        else{
            _27526 = NOVALUE;
        }

        /** 					defer()*/
        _67defer();

        /** 					restore_code()*/
        _67restore_code();

        /** 					return*/
        DeRefi(_backpatch_op_53250);
        _27469 = NOVALUE;
        DeRef(_27473);
        _27473 = NOVALUE;
        DeRef(_27490);
        _27490 = NOVALUE;
        DeRef(_27476);
        _27476 = NOVALUE;
        DeRef(_27479);
        _27479 = NOVALUE;
        DeRef(_27510);
        _27510 = NOVALUE;
        DeRef(_27497);
        _27497 = NOVALUE;
        DeRef(_27506);
        _27506 = NOVALUE;
        DeRef(_27511);
        _27511 = NOVALUE;
        DeRef(_27514);
        _27514 = NOVALUE;
        DeRef(_27517);
        _27517 = NOVALUE;
        _27522 = NOVALUE;
        _27524 = NOVALUE;
        return;
L19: 

        /** 				goto "inline op"*/
        goto G18;
        goto LF; // [711] 851

        /** 			case EXIT_BLOCK then*/
        case 206:

        /** 				replace_code( "", pc, pc + 1 )*/
        _27527 = _pc_53210 + 1;
        if (_27527 > MAXINT){
            _27527 = NewDouble((double)_27527);
        }
        RefDS(_22023);
        _67replace_code(_22023, _pc_53210, _27527);
        _27527 = NOVALUE;

        /** 				continue*/
        goto LD; // [732] 347
        goto LF; // [734] 851

        /** 			case SWITCH_RT then*/
        case 202:

        /** 				sequence values = SymTab[inline_code[pc+2]][S_OBJ]*/
        _27528 = _pc_53210 + 2;
        _2 = (int)SEQ_PTR(_67inline_code_52664);
        _27529 = (int)*(((s1_ptr)_2)->base + _27528);
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        if (!IS_ATOM_INT(_27529)){
            _27530 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_27529)->dbl));
        }
        else{
            _27530 = (int)*(((s1_ptr)_2)->base + _27529);
        }
        DeRef(_values_53331);
        _2 = (int)SEQ_PTR(_27530);
        _values_53331 = (int)*(((s1_ptr)_2)->base + 1);
        Ref(_values_53331);
        _27530 = NOVALUE;

        /** 				for i = 1 to length( values ) do*/
        if (IS_SEQUENCE(_values_53331)){
                _27532 = SEQ_PTR(_values_53331)->length;
        }
        else {
            _27532 = 1;
        }
        {
            int _i_53339;
            _i_53339 = 1;
L1A: 
            if (_i_53339 > _27532){
                goto L1B; // [771] 811
            }

            /** 					if sequence( values[i] ) then*/
            _2 = (int)SEQ_PTR(_values_53331);
            _27533 = (int)*(((s1_ptr)_2)->base + _i_53339);
            _27534 = IS_SEQUENCE(_27533);
            _27533 = NOVALUE;
            if (_27534 == 0)
            {
                _27534 = NOVALUE;
                goto L1C; // [787] 804
            }
            else{
                _27534 = NOVALUE;
            }

            /** 						defer()*/
            _67defer();

            /** 						restore_code()*/
            _67restore_code();

            /** 						return*/
            DeRefDS(_values_53331);
            DeRefi(_backpatch_op_53250);
            _27469 = NOVALUE;
            DeRef(_27473);
            _27473 = NOVALUE;
            DeRef(_27490);
            _27490 = NOVALUE;
            DeRef(_27476);
            _27476 = NOVALUE;
            DeRef(_27479);
            _27479 = NOVALUE;
            DeRef(_27510);
            _27510 = NOVALUE;
            DeRef(_27497);
            _27497 = NOVALUE;
            DeRef(_27506);
            _27506 = NOVALUE;
            DeRef(_27511);
            _27511 = NOVALUE;
            DeRef(_27514);
            _27514 = NOVALUE;
            DeRef(_27517);
            _27517 = NOVALUE;
            DeRef(_27522);
            _27522 = NOVALUE;
            DeRef(_27528);
            _27528 = NOVALUE;
            DeRef(_27524);
            _27524 = NOVALUE;
            _27529 = NOVALUE;
            return;
L1C: 

            /** 				end for*/
            _i_53339 = _i_53339 + 1;
            goto L1A; // [806] 778
L1B: 
            ;
        }

        /** 				backpatch_op = append( backpatch_op, pc )*/
        Append(&_backpatch_op_53250, _backpatch_op_53250, _pc_53210);
        DeRef(_values_53331);
        _values_53331 = NOVALUE;

        /** 			case else*/
        default:

        /** 			label "inline op"*/
G18:

        /** 				if not inline_op( pc ) then*/
        _27536 = _67inline_op(_pc_53210);
        if (IS_ATOM_INT(_27536)) {
            if (_27536 != 0){
                DeRef(_27536);
                _27536 = NOVALUE;
                goto L1D; // [833] 850
            }
        }
        else {
            if (DBL_PTR(_27536)->dbl != 0.0){
                DeRef(_27536);
                _27536 = NOVALUE;
                goto L1D; // [833] 850
            }
        }
        DeRef(_27536);
        _27536 = NOVALUE;

        /** 					defer()*/
        _67defer();

        /** 					restore_code()*/
        _67restore_code();

        /** 					return*/
        DeRefi(_backpatch_op_53250);
        _27469 = NOVALUE;
        DeRef(_27473);
        _27473 = NOVALUE;
        DeRef(_27490);
        _27490 = NOVALUE;
        DeRef(_27476);
        _27476 = NOVALUE;
        DeRef(_27479);
        _27479 = NOVALUE;
        DeRef(_27510);
        _27510 = NOVALUE;
        DeRef(_27497);
        _27497 = NOVALUE;
        DeRef(_27506);
        _27506 = NOVALUE;
        DeRef(_27511);
        _27511 = NOVALUE;
        DeRef(_27514);
        _27514 = NOVALUE;
        DeRef(_27517);
        _27517 = NOVALUE;
        DeRef(_27522);
        _27522 = NOVALUE;
        DeRef(_27528);
        _27528 = NOVALUE;
        DeRef(_27524);
        _27524 = NOVALUE;
        _27529 = NOVALUE;
        return;
L1D: 
    ;}LF: 

    /** 		pc = advance( pc, inline_code )*/
    RefDS(_67inline_code_52664);
    _pc_53210 = _67advance(_pc_53210, _67inline_code_52664);
    if (!IS_ATOM_INT(_pc_53210)) {
        _1 = (long)(DBL_PTR(_pc_53210)->dbl);
        DeRefDS(_pc_53210);
        _pc_53210 = _1;
    }

    /** 	end while*/
    goto LD; // [866] 347
LE: 

    /** 	SymTab[sub][S_INLINE] = { sort( assigned_params ), inline_code, backpatch_op }*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sub_53181 + ((s1_ptr)_2)->base);
    RefDS(_67assigned_params_52670);
    _27541 = _24sort(_67assigned_params_52670, 1);
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _27541;
    RefDS(_67inline_code_52664);
    *((int *)(_2+8)) = _67inline_code_52664;
    RefDS(_backpatch_op_53250);
    *((int *)(_2+12)) = _backpatch_op_53250;
    _27542 = MAKE_SEQ(_1);
    _27541 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 29);
    _1 = *(int *)_2;
    *(int *)_2 = _27542;
    if( _1 != _27542 ){
        DeRef(_1);
    }
    _27542 = NOVALUE;
    _27539 = NOVALUE;

    /** 	restore_code()*/
    _67restore_code();

    /** end procedure*/
    DeRefDSi(_backpatch_op_53250);
    _27469 = NOVALUE;
    DeRef(_27473);
    _27473 = NOVALUE;
    DeRef(_27490);
    _27490 = NOVALUE;
    DeRef(_27476);
    _27476 = NOVALUE;
    DeRef(_27479);
    _27479 = NOVALUE;
    DeRef(_27510);
    _27510 = NOVALUE;
    DeRef(_27497);
    _27497 = NOVALUE;
    DeRef(_27506);
    _27506 = NOVALUE;
    DeRef(_27511);
    _27511 = NOVALUE;
    DeRef(_27514);
    _27514 = NOVALUE;
    DeRef(_27517);
    _27517 = NOVALUE;
    DeRef(_27522);
    _27522 = NOVALUE;
    DeRef(_27528);
    _27528 = NOVALUE;
    DeRef(_27524);
    _27524 = NOVALUE;
    _27529 = NOVALUE;
    return;
    ;
}


void _67replace_temp(int _pc_53359)
{
    int _temp_num_53360 = NOVALUE;
    int _needed_53363 = NOVALUE;
    int _27555 = NOVALUE;
    int _27554 = NOVALUE;
    int _27553 = NOVALUE;
    int _27552 = NOVALUE;
    int _27550 = NOVALUE;
    int _27548 = NOVALUE;
    int _27545 = NOVALUE;
    int _27543 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer temp_num = inline_code[pc][2]*/
    _2 = (int)SEQ_PTR(_67inline_code_52664);
    _27543 = (int)*(((s1_ptr)_2)->base + _pc_53359);
    _2 = (int)SEQ_PTR(_27543);
    _temp_num_53360 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_temp_num_53360)){
        _temp_num_53360 = (long)DBL_PTR(_temp_num_53360)->dbl;
    }
    _27543 = NOVALUE;

    /** 	integer needed = temp_num - length( inline_temps )*/
    if (IS_SEQUENCE(_67inline_temps_52666)){
            _27545 = SEQ_PTR(_67inline_temps_52666)->length;
    }
    else {
        _27545 = 1;
    }
    _needed_53363 = _temp_num_53360 - _27545;
    _27545 = NOVALUE;

    /** 	if needed > 0 then*/
    if (_needed_53363 <= 0)
    goto L1; // [30] 47

    /** 		inline_temps &= repeat( 0, needed )*/
    _27548 = Repeat(0, _needed_53363);
    Concat((object_ptr)&_67inline_temps_52666, _67inline_temps_52666, _27548);
    DeRefDS(_27548);
    _27548 = NOVALUE;
L1: 

    /** 	if not inline_temps[temp_num] then*/
    _2 = (int)SEQ_PTR(_67inline_temps_52666);
    _27550 = (int)*(((s1_ptr)_2)->base + _temp_num_53360);
    if (IS_ATOM_INT(_27550)) {
        if (_27550 != 0){
            _27550 = NOVALUE;
            goto L2; // [55] 100
        }
    }
    else {
        if (DBL_PTR(_27550)->dbl != 0.0){
            _27550 = NOVALUE;
            goto L2; // [55] 100
        }
    }
    _27550 = NOVALUE;

    /** 		if TRANSLATE then*/
    if (_35TRANSLATE_15887 == 0)
    {
        goto L3; // [62] 84
    }
    else{
    }

    /** 			inline_temps[temp_num] = new_inline_var( -temp_num, 0 )*/
    if ((unsigned long)_temp_num_53360 == 0xC0000000)
    _27552 = (int)NewDouble((double)-0xC0000000);
    else
    _27552 = - _temp_num_53360;
    _27553 = _67new_inline_var(_27552, 0);
    _27552 = NOVALUE;
    _2 = (int)SEQ_PTR(_67inline_temps_52666);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _67inline_temps_52666 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _temp_num_53360);
    _1 = *(int *)_2;
    *(int *)_2 = _27553;
    if( _1 != _27553 ){
        DeRef(_1);
    }
    _27553 = NOVALUE;
    goto L4; // [81] 99
L3: 

    /** 			inline_temps[temp_num] = NewTempSym( TRUE )*/
    _27554 = _53NewTempSym(_13TRUE_436);
    _2 = (int)SEQ_PTR(_67inline_temps_52666);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _67inline_temps_52666 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _temp_num_53360);
    _1 = *(int *)_2;
    *(int *)_2 = _27554;
    if( _1 != _27554 ){
        DeRef(_1);
    }
    _27554 = NOVALUE;
L4: 
L2: 

    /** 	inline_code[pc] = inline_temps[temp_num]*/
    _2 = (int)SEQ_PTR(_67inline_temps_52666);
    _27555 = (int)*(((s1_ptr)_2)->base + _temp_num_53360);
    Ref(_27555);
    _2 = (int)SEQ_PTR(_67inline_code_52664);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _67inline_code_52664 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _pc_53359);
    _1 = *(int *)_2;
    *(int *)_2 = _27555;
    if( _1 != _27555 ){
        DeRef(_1);
    }
    _27555 = NOVALUE;

    /** end procedure*/
    return;
    ;
}


int _67get_param_sym(int _pc_53385)
{
    int _il_53386 = NOVALUE;
    int _px_53394 = NOVALUE;
    int _27562 = NOVALUE;
    int _27559 = NOVALUE;
    int _27558 = NOVALUE;
    int _27557 = NOVALUE;
    int _0, _1, _2;
    

    /** 	object il = inline_code[pc]*/
    DeRef(_il_53386);
    _2 = (int)SEQ_PTR(_67inline_code_52664);
    _il_53386 = (int)*(((s1_ptr)_2)->base + _pc_53385);
    Ref(_il_53386);

    /** 	if integer( il ) then*/
    if (IS_ATOM_INT(_il_53386))
    _27557 = 1;
    else if (IS_ATOM_DBL(_il_53386))
    _27557 = IS_ATOM_INT(DoubleToInt(_il_53386));
    else
    _27557 = 0;
    if (_27557 == 0)
    {
        _27557 = NOVALUE;
        goto L1; // [16] 34
    }
    else{
        _27557 = NOVALUE;
    }

    /** 		return inline_code[pc]*/
    _2 = (int)SEQ_PTR(_67inline_code_52664);
    _27558 = (int)*(((s1_ptr)_2)->base + _pc_53385);
    Ref(_27558);
    DeRef(_il_53386);
    return _27558;
    goto L2; // [31] 53
L1: 

    /** 	elsif length( il ) = 1 then*/
    if (IS_SEQUENCE(_il_53386)){
            _27559 = SEQ_PTR(_il_53386)->length;
    }
    else {
        _27559 = 1;
    }
    if (_27559 != 1)
    goto L3; // [39] 52

    /** 		return inline_target*/
    DeRef(_il_53386);
    _27558 = NOVALUE;
    return _67inline_target_52671;
L3: 
L2: 

    /** 	integer px = il[2]*/
    _2 = (int)SEQ_PTR(_il_53386);
    _px_53394 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_px_53394)){
        _px_53394 = (long)DBL_PTR(_px_53394)->dbl;
    }

    /** 	return passed_params[px]*/
    _2 = (int)SEQ_PTR(_67passed_params_52667);
    _27562 = (int)*(((s1_ptr)_2)->base + _px_53394);
    Ref(_27562);
    DeRef(_il_53386);
    _27558 = NOVALUE;
    return _27562;
    ;
}


int _67get_original_sym(int _pc_53399)
{
    int _il_53400 = NOVALUE;
    int _px_53408 = NOVALUE;
    int _27569 = NOVALUE;
    int _27566 = NOVALUE;
    int _27565 = NOVALUE;
    int _27564 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_pc_53399)) {
        _1 = (long)(DBL_PTR(_pc_53399)->dbl);
        DeRefDS(_pc_53399);
        _pc_53399 = _1;
    }

    /** 	object il = inline_code[pc]*/
    DeRef(_il_53400);
    _2 = (int)SEQ_PTR(_67inline_code_52664);
    _il_53400 = (int)*(((s1_ptr)_2)->base + _pc_53399);
    Ref(_il_53400);

    /** 	if integer( il ) then*/
    if (IS_ATOM_INT(_il_53400))
    _27564 = 1;
    else if (IS_ATOM_DBL(_il_53400))
    _27564 = IS_ATOM_INT(DoubleToInt(_il_53400));
    else
    _27564 = 0;
    if (_27564 == 0)
    {
        _27564 = NOVALUE;
        goto L1; // [16] 34
    }
    else{
        _27564 = NOVALUE;
    }

    /** 		return inline_code[pc]*/
    _2 = (int)SEQ_PTR(_67inline_code_52664);
    _27565 = (int)*(((s1_ptr)_2)->base + _pc_53399);
    Ref(_27565);
    DeRef(_il_53400);
    return _27565;
    goto L2; // [31] 53
L1: 

    /** 	elsif length( il ) = 1 then*/
    if (IS_SEQUENCE(_il_53400)){
            _27566 = SEQ_PTR(_il_53400)->length;
    }
    else {
        _27566 = 1;
    }
    if (_27566 != 1)
    goto L3; // [39] 52

    /** 		return inline_target*/
    DeRef(_il_53400);
    _27565 = NOVALUE;
    return _67inline_target_52671;
L3: 
L2: 

    /** 	integer px = il[2]*/
    _2 = (int)SEQ_PTR(_il_53400);
    _px_53408 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_px_53408)){
        _px_53408 = (long)DBL_PTR(_px_53408)->dbl;
    }

    /** 	return original_params[px]*/
    _2 = (int)SEQ_PTR(_67original_params_52668);
    _27569 = (int)*(((s1_ptr)_2)->base + _px_53408);
    Ref(_27569);
    DeRef(_il_53400);
    _27565 = NOVALUE;
    return _27569;
    ;
}


void _67replace_var(int _pc_53417)
{
    int _27573 = NOVALUE;
    int _27572 = NOVALUE;
    int _27571 = NOVALUE;
    int _0, _1, _2;
    

    /** 	inline_code[pc] = proc_vars[inline_code[pc][2]]*/
    _2 = (int)SEQ_PTR(_67inline_code_52664);
    _27571 = (int)*(((s1_ptr)_2)->base + _pc_53417);
    _2 = (int)SEQ_PTR(_27571);
    _27572 = (int)*(((s1_ptr)_2)->base + 2);
    _27571 = NOVALUE;
    _2 = (int)SEQ_PTR(_67proc_vars_52665);
    if (!IS_ATOM_INT(_27572)){
        _27573 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_27572)->dbl));
    }
    else{
        _27573 = (int)*(((s1_ptr)_2)->base + _27572);
    }
    _2 = (int)SEQ_PTR(_67inline_code_52664);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _67inline_code_52664 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _pc_53417);
    _1 = *(int *)_2;
    *(int *)_2 = _27573;
    if( _1 != _27573 ){
        DeRef(_1);
    }
    _27573 = NOVALUE;

    /** end procedure*/
    _27572 = NOVALUE;
    return;
    ;
}


void _67fix_switch_rt(int _pc_53423)
{
    int _value_table_53425 = NOVALUE;
    int _jump_table_53432 = NOVALUE;
    int _27593 = NOVALUE;
    int _27592 = NOVALUE;
    int _27591 = NOVALUE;
    int _27590 = NOVALUE;
    int _27589 = NOVALUE;
    int _27588 = NOVALUE;
    int _27586 = NOVALUE;
    int _27585 = NOVALUE;
    int _27584 = NOVALUE;
    int _27583 = NOVALUE;
    int _27582 = NOVALUE;
    int _27580 = NOVALUE;
    int _27578 = NOVALUE;
    int _27577 = NOVALUE;
    int _27575 = NOVALUE;
    int _27574 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	symtab_index value_table = NewStringSym( {-1, length(SymTab)} )*/
    if (IS_SEQUENCE(_36SymTab_15242)){
            _27574 = SEQ_PTR(_36SymTab_15242)->length;
    }
    else {
        _27574 = 1;
    }
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -1;
    ((int *)_2)[2] = _27574;
    _27575 = MAKE_SEQ(_1);
    _27574 = NOVALUE;
    _value_table_53425 = _53NewStringSym(_27575);
    _27575 = NOVALUE;
    if (!IS_ATOM_INT(_value_table_53425)) {
        _1 = (long)(DBL_PTR(_value_table_53425)->dbl);
        DeRefDS(_value_table_53425);
        _value_table_53425 = _1;
    }

    /** 	symtab_index jump_table  = NewStringSym( {-1, length(SymTab)} )*/
    if (IS_SEQUENCE(_36SymTab_15242)){
            _27577 = SEQ_PTR(_36SymTab_15242)->length;
    }
    else {
        _27577 = 1;
    }
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -1;
    ((int *)_2)[2] = _27577;
    _27578 = MAKE_SEQ(_1);
    _27577 = NOVALUE;
    _jump_table_53432 = _53NewStringSym(_27578);
    _27578 = NOVALUE;
    if (!IS_ATOM_INT(_jump_table_53432)) {
        _1 = (long)(DBL_PTR(_jump_table_53432)->dbl);
        DeRefDS(_jump_table_53432);
        _jump_table_53432 = _1;
    }

    /** 	SymTab[value_table][S_OBJ] = SymTab[inline_code[pc+2]][S_OBJ]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_value_table_53425 + ((s1_ptr)_2)->base);
    _27582 = _pc_53423 + 2;
    _2 = (int)SEQ_PTR(_67inline_code_52664);
    _27583 = (int)*(((s1_ptr)_2)->base + _27582);
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!IS_ATOM_INT(_27583)){
        _27584 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_27583)->dbl));
    }
    else{
        _27584 = (int)*(((s1_ptr)_2)->base + _27583);
    }
    _2 = (int)SEQ_PTR(_27584);
    _27585 = (int)*(((s1_ptr)_2)->base + 1);
    _27584 = NOVALUE;
    Ref(_27585);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _27585;
    if( _1 != _27585 ){
        DeRef(_1);
    }
    _27585 = NOVALUE;
    _27580 = NOVALUE;

    /** 	SymTab[jump_table][S_OBJ]  = SymTab[inline_code[pc+3]][S_OBJ]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_jump_table_53432 + ((s1_ptr)_2)->base);
    _27588 = _pc_53423 + 3;
    _2 = (int)SEQ_PTR(_67inline_code_52664);
    _27589 = (int)*(((s1_ptr)_2)->base + _27588);
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!IS_ATOM_INT(_27589)){
        _27590 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_27589)->dbl));
    }
    else{
        _27590 = (int)*(((s1_ptr)_2)->base + _27589);
    }
    _2 = (int)SEQ_PTR(_27590);
    _27591 = (int)*(((s1_ptr)_2)->base + 1);
    _27590 = NOVALUE;
    Ref(_27591);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _27591;
    if( _1 != _27591 ){
        DeRef(_1);
    }
    _27591 = NOVALUE;
    _27586 = NOVALUE;

    /** 	inline_code[pc+2] = value_table*/
    _27592 = _pc_53423 + 2;
    _2 = (int)SEQ_PTR(_67inline_code_52664);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _67inline_code_52664 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _27592);
    _1 = *(int *)_2;
    *(int *)_2 = _value_table_53425;
    DeRef(_1);

    /** 	inline_code[pc+3] = jump_table*/
    _27593 = _pc_53423 + 3;
    _2 = (int)SEQ_PTR(_67inline_code_52664);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _67inline_code_52664 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _27593);
    _1 = *(int *)_2;
    *(int *)_2 = _jump_table_53432;
    DeRef(_1);

    /** end procedure*/
    _27592 = NOVALUE;
    _27582 = NOVALUE;
    _27583 = NOVALUE;
    _27588 = NOVALUE;
    _27589 = NOVALUE;
    _27593 = NOVALUE;
    return;
    ;
}


void _67fixup_special_op(int _pc_53462)
{
    int _op_53463 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_pc_53462)) {
        _1 = (long)(DBL_PTR(_pc_53462)->dbl);
        DeRefDS(_pc_53462);
        _pc_53462 = _1;
    }

    /** 	integer op = inline_code[pc]*/
    _2 = (int)SEQ_PTR(_67inline_code_52664);
    _op_53463 = (int)*(((s1_ptr)_2)->base + _pc_53462);
    if (!IS_ATOM_INT(_op_53463))
    _op_53463 = (long)DBL_PTR(_op_53463)->dbl;

    /** 	switch op with fallthru do*/
    _0 = _op_53463;
    switch ( _0 ){ 

        /** 		case SWITCH_RT then*/
        case 202:

        /** 			fix_switch_rt( pc )*/
        _67fix_switch_rt(_pc_53462);

        /** 			break*/
        goto L1; // [29] 32
    ;}L1: 

    /** end procedure*/
    return;
    ;
}


int _67new_inline_var(int _ps_53474, int _reuse_53475)
{
    int _var_53477 = NOVALUE;
    int _vtype_53478 = NOVALUE;
    int _name_53479 = NOVALUE;
    int _s_53481 = NOVALUE;
    int _27656 = NOVALUE;
    int _27655 = NOVALUE;
    int _27653 = NOVALUE;
    int _27650 = NOVALUE;
    int _27649 = NOVALUE;
    int _27647 = NOVALUE;
    int _27644 = NOVALUE;
    int _27643 = NOVALUE;
    int _27642 = NOVALUE;
    int _27640 = NOVALUE;
    int _27635 = NOVALUE;
    int _27630 = NOVALUE;
    int _27629 = NOVALUE;
    int _27628 = NOVALUE;
    int _27627 = NOVALUE;
    int _27624 = NOVALUE;
    int _27622 = NOVALUE;
    int _27619 = NOVALUE;
    int _27614 = NOVALUE;
    int _27613 = NOVALUE;
    int _27612 = NOVALUE;
    int _27611 = NOVALUE;
    int _27610 = NOVALUE;
    int _27607 = NOVALUE;
    int _27606 = NOVALUE;
    int _27605 = NOVALUE;
    int _27604 = NOVALUE;
    int _27603 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_ps_53474)) {
        _1 = (long)(DBL_PTR(_ps_53474)->dbl);
        DeRefDS(_ps_53474);
        _ps_53474 = _1;
    }

    /** 		var = 0, */
    _var_53477 = 0;

    /** 	sequence name*/

    /** 	if reuse then*/

    /** 	if not var then*/

    /** 		if ps > 0 then*/
    if (_ps_53474 <= 0)
    goto L1; // [45] 222

    /** 			s = ps*/
    _s_53481 = _ps_53474;

    /** 			if TRANSLATE then*/
    if (_35TRANSLATE_15887 == 0)
    {
        goto L2; // [60] 102
    }
    else{
    }

    /** 				name = sprintf( "%s_inlined_%s", {SymTab[s][S_NAME], SymTab[inline_sub][S_NAME] })*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _27603 = (int)*(((s1_ptr)_2)->base + _s_53481);
    _2 = (int)SEQ_PTR(_27603);
    if (!IS_ATOM_INT(_35S_NAME_15917)){
        _27604 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15917)->dbl));
    }
    else{
        _27604 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15917);
    }
    _27603 = NOVALUE;
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _27605 = (int)*(((s1_ptr)_2)->base + _67inline_sub_52678);
    _2 = (int)SEQ_PTR(_27605);
    if (!IS_ATOM_INT(_35S_NAME_15917)){
        _27606 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15917)->dbl));
    }
    else{
        _27606 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15917);
    }
    _27605 = NOVALUE;
    Ref(_27606);
    Ref(_27604);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _27604;
    ((int *)_2)[2] = _27606;
    _27607 = MAKE_SEQ(_1);
    _27606 = NOVALUE;
    _27604 = NOVALUE;
    DeRefi(_name_53479);
    _name_53479 = EPrintf(-9999999, _27602, _27607);
    DeRefDS(_27607);
    _27607 = NOVALUE;
    goto L3; // [99] 139
L2: 

    /** 				name = sprintf( "%s (from inlined routine '%s'", {SymTab[s][S_NAME], SymTab[inline_sub][S_NAME] })*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _27610 = (int)*(((s1_ptr)_2)->base + _s_53481);
    _2 = (int)SEQ_PTR(_27610);
    if (!IS_ATOM_INT(_35S_NAME_15917)){
        _27611 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15917)->dbl));
    }
    else{
        _27611 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15917);
    }
    _27610 = NOVALUE;
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _27612 = (int)*(((s1_ptr)_2)->base + _67inline_sub_52678);
    _2 = (int)SEQ_PTR(_27612);
    if (!IS_ATOM_INT(_35S_NAME_15917)){
        _27613 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15917)->dbl));
    }
    else{
        _27613 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15917);
    }
    _27612 = NOVALUE;
    Ref(_27613);
    Ref(_27611);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _27611;
    ((int *)_2)[2] = _27613;
    _27614 = MAKE_SEQ(_1);
    _27613 = NOVALUE;
    _27611 = NOVALUE;
    DeRefi(_name_53479);
    _name_53479 = EPrintf(-9999999, _27609, _27614);
    DeRefDS(_27614);
    _27614 = NOVALUE;
L3: 

    /** 			if reuse then*/
    if (_reuse_53475 == 0)
    {
        goto L4; // [141] 163
    }
    else{
    }

    /** 				if not TRANSLATE then*/
    if (_35TRANSLATE_15887 != 0)
    goto L5; // [148] 203

    /** 					name &= ")"*/
    Concat((object_ptr)&_name_53479, _name_53479, _26397);
    goto L5; // [160] 203
L4: 

    /** 				if TRANSLATE then*/
    if (_35TRANSLATE_15887 == 0)
    {
        goto L6; // [167] 187
    }
    else{
    }

    /** 					name &= sprintf( "_at_%d", inline_start)*/
    _27619 = EPrintf(-9999999, _27618, _67inline_start_52676);
    Concat((object_ptr)&_name_53479, _name_53479, _27619);
    DeRefDS(_27619);
    _27619 = NOVALUE;
    goto L7; // [184] 202
L6: 

    /** 					name &= sprintf( " at %d)", inline_start)*/
    _27622 = EPrintf(-9999999, _27621, _67inline_start_52676);
    Concat((object_ptr)&_name_53479, _name_53479, _27622);
    DeRefDS(_27622);
    _27622 = NOVALUE;
L7: 
L5: 

    /** 			vtype = SymTab[s][S_VTYPE]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _27624 = (int)*(((s1_ptr)_2)->base + _s_53481);
    _2 = (int)SEQ_PTR(_27624);
    _vtype_53478 = (int)*(((s1_ptr)_2)->base + 15);
    if (!IS_ATOM_INT(_vtype_53478)){
        _vtype_53478 = (long)DBL_PTR(_vtype_53478)->dbl;
    }
    _27624 = NOVALUE;
    goto L8; // [219] 286
L1: 

    /** 			name = sprintf( "%s_%d", {SymTab[inline_sub][S_NAME], -ps})*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _27627 = (int)*(((s1_ptr)_2)->base + _67inline_sub_52678);
    _2 = (int)SEQ_PTR(_27627);
    if (!IS_ATOM_INT(_35S_NAME_15917)){
        _27628 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15917)->dbl));
    }
    else{
        _27628 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15917);
    }
    _27627 = NOVALUE;
    if ((unsigned long)_ps_53474 == 0xC0000000)
    _27629 = (int)NewDouble((double)-0xC0000000);
    else
    _27629 = - _ps_53474;
    Ref(_27628);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _27628;
    ((int *)_2)[2] = _27629;
    _27630 = MAKE_SEQ(_1);
    _27629 = NOVALUE;
    _27628 = NOVALUE;
    DeRefi(_name_53479);
    _name_53479 = EPrintf(-9999999, _27626, _27630);
    DeRefDS(_27630);
    _27630 = NOVALUE;

    /** 			if reuse then*/
    if (_reuse_53475 == 0)
    {
        goto L9; // [251] 263
    }
    else{
    }

    /** 				name &= "__tmp"*/
    Concat((object_ptr)&_name_53479, _name_53479, _27632);
    goto LA; // [260] 276
L9: 

    /** 				name &= sprintf( "__tmp_at%d", inline_start)*/
    _27635 = EPrintf(-9999999, _27634, _67inline_start_52676);
    Concat((object_ptr)&_name_53479, _name_53479, _27635);
    DeRefDS(_27635);
    _27635 = NOVALUE;
LA: 

    /** 			vtype = object_type*/
    _vtype_53478 = _53object_type_46091;
L8: 

    /** 		if CurrentSub = TopLevelSub then*/
    if (_35CurrentSub_16252 != _35TopLevelSub_16251)
    goto LB; // [292] 325

    /** 			var = NewEntry( name, varnum, SC_LOCAL, VARIABLE, INLINE_HASHVAL, 0, vtype )*/
    RefDS(_name_53479);
    _var_53477 = _53NewEntry(_name_53479, _67varnum_52675, 5, -100, 2004, 0, _vtype_53478);
    if (!IS_ATOM_INT(_var_53477)) {
        _1 = (long)(DBL_PTR(_var_53477)->dbl);
        DeRefDS(_var_53477);
        _var_53477 = _1;
    }
    goto LC; // [322] 416
LB: 

    /** 			var = NewBasicEntry( name, varnum, SC_PRIVATE, VARIABLE, INLINE_HASHVAL, 0, vtype )*/
    RefDS(_name_53479);
    _var_53477 = _53NewBasicEntry(_name_53479, _67varnum_52675, 3, -100, 2004, 0, _vtype_53478);
    if (!IS_ATOM_INT(_var_53477)) {
        _1 = (long)(DBL_PTR(_var_53477)->dbl);
        DeRefDS(_var_53477);
        _var_53477 = _1;
    }

    /** 			SymTab[var][S_NEXT] = SymTab[last_param][S_NEXT]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_var_53477 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _27642 = (int)*(((s1_ptr)_2)->base + _67last_param_52679);
    _2 = (int)SEQ_PTR(_27642);
    _27643 = (int)*(((s1_ptr)_2)->base + 2);
    _27642 = NOVALUE;
    Ref(_27643);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _27643;
    if( _1 != _27643 ){
        DeRef(_1);
    }
    _27643 = NOVALUE;
    _27640 = NOVALUE;

    /** 			SymTab[last_param][S_NEXT] = var*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_67last_param_52679 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _var_53477;
    DeRef(_1);
    _27644 = NOVALUE;

    /** 			if last_param = last_sym then*/
    if (_67last_param_52679 != _53last_sym_46100)
    goto LD; // [403] 415

    /** 				last_sym = var*/
    _53last_sym_46100 = _var_53477;
LD: 
LC: 

    /** 		if deferred_inlining then*/
    if (_67deferred_inlining_52674 == 0)
    {
        goto LE; // [420] 451
    }
    else{
    }

    /** 			SymTab[CurrentSub][S_STACK_SPACE] += 1*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_35CurrentSub_16252 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!IS_ATOM_INT(_35S_STACK_SPACE_15977)){
        _27649 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_STACK_SPACE_15977)->dbl));
    }
    else{
        _27649 = (int)*(((s1_ptr)_2)->base + _35S_STACK_SPACE_15977);
    }
    _27647 = NOVALUE;
    if (IS_ATOM_INT(_27649)) {
        _27650 = _27649 + 1;
        if (_27650 > MAXINT){
            _27650 = NewDouble((double)_27650);
        }
    }
    else
    _27650 = binary_op(PLUS, 1, _27649);
    _27649 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35S_STACK_SPACE_15977))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_STACK_SPACE_15977)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _35S_STACK_SPACE_15977);
    _1 = *(int *)_2;
    *(int *)_2 = _27650;
    if( _1 != _27650 ){
        DeRef(_1);
    }
    _27650 = NOVALUE;
    _27647 = NOVALUE;
    goto LF; // [448] 471
LE: 

    /** 			if param_num != -1 then*/
    if (_39param_num_54126 == -1)
    goto L10; // [455] 470

    /** 				param_num += 1*/
    _39param_num_54126 = _39param_num_54126 + 1;
L10: 
LF: 

    /** 		SymTab[var][S_USAGE] = U_USED*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_var_53477 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = 3;
    DeRef(_1);
    _27653 = NOVALUE;

    /** 		if reuse then*/
    if (_reuse_53475 == 0)
    {
        goto L11; // [490] 513
    }
    else{
    }

    /** 			map:nested_put( inline_var_map, {CurrentSub, ps }, var )*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _35CurrentSub_16252;
    ((int *)_2)[2] = _ps_53474;
    _27655 = MAKE_SEQ(_1);
    Ref(_67inline_var_map_52683);
    _28nested_put(_67inline_var_map_52683, _27655, _var_53477, 1, 23);
    _27655 = NOVALUE;
L11: 

    /** 	Block_var( var )*/
    _66Block_var(_var_53477);

    /** 	if BIND then*/
    if (_35BIND_15890 == 0)
    {
        goto L12; // [523] 538
    }
    else{
    }

    /** 		add_ref( {VARIABLE, var} )*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -100;
    ((int *)_2)[2] = _var_53477;
    _27656 = MAKE_SEQ(_1);
    _53add_ref(_27656);
    _27656 = NOVALUE;
L12: 

    /** 	return var*/
    DeRefi(_name_53479);
    return _var_53477;
    ;
}


int _67get_inlined_code(int _sub_53611, int _start_53612, int _deferred_53613)
{
    int _is_proc_53614 = NOVALUE;
    int _backpatches_53632 = NOVALUE;
    int _prolog_53638 = NOVALUE;
    int _epilog_53639 = NOVALUE;
    int _s_53655 = NOVALUE;
    int _last_sym_53678 = NOVALUE;
    int _int_sym_53705 = NOVALUE;
    int _param_53713 = NOVALUE;
    int _ax_53716 = NOVALUE;
    int _var_53723 = NOVALUE;
    int _final_target_53738 = NOVALUE;
    int _var_53757 = NOVALUE;
    int _create_target_var_53770 = NOVALUE;
    int _check_pc_53793 = NOVALUE;
    int _op_53797 = NOVALUE;
    int _sym_53806 = NOVALUE;
    int _check_result_53811 = NOVALUE;
    int _inline_type_53889 = NOVALUE;
    int _replace_param_1__tmp_at1341_53900 = NOVALUE;
    int _27811 = NOVALUE;
    int _27810 = NOVALUE;
    int _27809 = NOVALUE;
    int _27808 = NOVALUE;
    int _27807 = NOVALUE;
    int _27806 = NOVALUE;
    int _27805 = NOVALUE;
    int _27804 = NOVALUE;
    int _27802 = NOVALUE;
    int _27799 = NOVALUE;
    int _27796 = NOVALUE;
    int _27795 = NOVALUE;
    int _27794 = NOVALUE;
    int _27793 = NOVALUE;
    int _27792 = NOVALUE;
    int _27791 = NOVALUE;
    int _27790 = NOVALUE;
    int _27789 = NOVALUE;
    int _27785 = NOVALUE;
    int _27784 = NOVALUE;
    int _27783 = NOVALUE;
    int _27782 = NOVALUE;
    int _27778 = NOVALUE;
    int _27777 = NOVALUE;
    int _27776 = NOVALUE;
    int _27775 = NOVALUE;
    int _27774 = NOVALUE;
    int _27773 = NOVALUE;
    int _27772 = NOVALUE;
    int _27770 = NOVALUE;
    int _27769 = NOVALUE;
    int _27768 = NOVALUE;
    int _27767 = NOVALUE;
    int _27766 = NOVALUE;
    int _27765 = NOVALUE;
    int _27764 = NOVALUE;
    int _27763 = NOVALUE;
    int _27762 = NOVALUE;
    int _27761 = NOVALUE;
    int _27760 = NOVALUE;
    int _27758 = NOVALUE;
    int _27756 = NOVALUE;
    int _27754 = NOVALUE;
    int _27753 = NOVALUE;
    int _27751 = NOVALUE;
    int _27750 = NOVALUE;
    int _27747 = NOVALUE;
    int _27746 = NOVALUE;
    int _27744 = NOVALUE;
    int _27742 = NOVALUE;
    int _27737 = NOVALUE;
    int _27733 = NOVALUE;
    int _27730 = NOVALUE;
    int _27726 = NOVALUE;
    int _27719 = NOVALUE;
    int _27718 = NOVALUE;
    int _27717 = NOVALUE;
    int _27716 = NOVALUE;
    int _27715 = NOVALUE;
    int _27714 = NOVALUE;
    int _27713 = NOVALUE;
    int _27711 = NOVALUE;
    int _27706 = NOVALUE;
    int _27703 = NOVALUE;
    int _27698 = NOVALUE;
    int _27697 = NOVALUE;
    int _27695 = NOVALUE;
    int _27694 = NOVALUE;
    int _27693 = NOVALUE;
    int _27690 = NOVALUE;
    int _27689 = NOVALUE;
    int _27688 = NOVALUE;
    int _27687 = NOVALUE;
    int _27686 = NOVALUE;
    int _27685 = NOVALUE;
    int _27684 = NOVALUE;
    int _27682 = NOVALUE;
    int _27681 = NOVALUE;
    int _27680 = NOVALUE;
    int _27678 = NOVALUE;
    int _27676 = NOVALUE;
    int _27675 = NOVALUE;
    int _27674 = NOVALUE;
    int _27673 = NOVALUE;
    int _27672 = NOVALUE;
    int _27671 = NOVALUE;
    int _27670 = NOVALUE;
    int _27667 = NOVALUE;
    int _27666 = NOVALUE;
    int _27664 = NOVALUE;
    int _27663 = NOVALUE;
    int _27661 = NOVALUE;
    int _27660 = NOVALUE;
    int _27658 = NOVALUE;
    int _27657 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_sub_53611)) {
        _1 = (long)(DBL_PTR(_sub_53611)->dbl);
        DeRefDS(_sub_53611);
        _sub_53611 = _1;
    }
    if (!IS_ATOM_INT(_start_53612)) {
        _1 = (long)(DBL_PTR(_start_53612)->dbl);
        DeRefDS(_start_53612);
        _start_53612 = _1;
    }
    if (!IS_ATOM_INT(_deferred_53613)) {
        _1 = (long)(DBL_PTR(_deferred_53613)->dbl);
        DeRefDS(_deferred_53613);
        _deferred_53613 = _1;
    }

    /** 	integer is_proc = SymTab[sub][S_TOKEN] = PROC*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _27657 = (int)*(((s1_ptr)_2)->base + _sub_53611);
    _2 = (int)SEQ_PTR(_27657);
    if (!IS_ATOM_INT(_35S_TOKEN_15922)){
        _27658 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TOKEN_15922)->dbl));
    }
    else{
        _27658 = (int)*(((s1_ptr)_2)->base + _35S_TOKEN_15922);
    }
    _27657 = NOVALUE;
    if (IS_ATOM_INT(_27658)) {
        _is_proc_53614 = (_27658 == 27);
    }
    else {
        _is_proc_53614 = binary_op(EQUALS, _27658, 27);
    }
    _27658 = NOVALUE;
    if (!IS_ATOM_INT(_is_proc_53614)) {
        _1 = (long)(DBL_PTR(_is_proc_53614)->dbl);
        DeRefDS(_is_proc_53614);
        _is_proc_53614 = _1;
    }

    /** 	clear_inline_targets()*/
    _41clear_inline_targets();

    /** 	inline_temps = {}*/
    RefDS(_22023);
    DeRef(_67inline_temps_52666);
    _67inline_temps_52666 = _22023;

    /** 	inline_params = {}*/
    RefDS(_22023);
    DeRefi(_67inline_params_52669);
    _67inline_params_52669 = _22023;

    /** 	assigned_params      = SymTab[sub][S_INLINE][1]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _27660 = (int)*(((s1_ptr)_2)->base + _sub_53611);
    _2 = (int)SEQ_PTR(_27660);
    _27661 = (int)*(((s1_ptr)_2)->base + 29);
    _27660 = NOVALUE;
    DeRef(_67assigned_params_52670);
    _2 = (int)SEQ_PTR(_27661);
    _67assigned_params_52670 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_67assigned_params_52670);
    _27661 = NOVALUE;

    /** 	inline_code          = SymTab[sub][S_INLINE][2]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _27663 = (int)*(((s1_ptr)_2)->base + _sub_53611);
    _2 = (int)SEQ_PTR(_27663);
    _27664 = (int)*(((s1_ptr)_2)->base + 29);
    _27663 = NOVALUE;
    DeRef(_67inline_code_52664);
    _2 = (int)SEQ_PTR(_27664);
    _67inline_code_52664 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_67inline_code_52664);
    _27664 = NOVALUE;

    /** 	sequence backpatches = SymTab[sub][S_INLINE][3]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _27666 = (int)*(((s1_ptr)_2)->base + _sub_53611);
    _2 = (int)SEQ_PTR(_27666);
    _27667 = (int)*(((s1_ptr)_2)->base + 29);
    _27666 = NOVALUE;
    DeRef(_backpatches_53632);
    _2 = (int)SEQ_PTR(_27667);
    _backpatches_53632 = (int)*(((s1_ptr)_2)->base + 3);
    Ref(_backpatches_53632);
    _27667 = NOVALUE;

    /** 	passed_params = {}*/
    RefDS(_22023);
    DeRef(_67passed_params_52667);
    _67passed_params_52667 = _22023;

    /** 	original_params = {}*/
    RefDS(_22023);
    DeRef(_67original_params_52668);
    _67original_params_52668 = _22023;

    /** 	proc_vars = {}*/
    RefDS(_22023);
    DeRefi(_67proc_vars_52665);
    _67proc_vars_52665 = _22023;

    /** 	sequence prolog = {}*/
    RefDS(_22023);
    DeRefi(_prolog_53638);
    _prolog_53638 = _22023;

    /** 	sequence epilog = {}*/
    RefDS(_22023);
    DeRef(_epilog_53639);
    _epilog_53639 = _22023;

    /** 	Start_block( EXIT_BLOCK, sprintf("Inline-%s from %s @ %d", */
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _27670 = (int)*(((s1_ptr)_2)->base + _sub_53611);
    _2 = (int)SEQ_PTR(_27670);
    if (!IS_ATOM_INT(_35S_NAME_15917)){
        _27671 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15917)->dbl));
    }
    else{
        _27671 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15917);
    }
    _27670 = NOVALUE;
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _27672 = (int)*(((s1_ptr)_2)->base + _35CurrentSub_16252);
    _2 = (int)SEQ_PTR(_27672);
    if (!IS_ATOM_INT(_35S_NAME_15917)){
        _27673 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15917)->dbl));
    }
    else{
        _27673 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15917);
    }
    _27672 = NOVALUE;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_27671);
    *((int *)(_2+4)) = _27671;
    Ref(_27673);
    *((int *)(_2+8)) = _27673;
    *((int *)(_2+12)) = _start_53612;
    _27674 = MAKE_SEQ(_1);
    _27673 = NOVALUE;
    _27671 = NOVALUE;
    _27675 = EPrintf(-9999999, _27669, _27674);
    DeRefDS(_27674);
    _27674 = NOVALUE;
    _66Start_block(206, _27675);
    _27675 = NOVALUE;

    /** 	symtab_index s = SymTab[sub][S_NEXT]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _27676 = (int)*(((s1_ptr)_2)->base + _sub_53611);
    _2 = (int)SEQ_PTR(_27676);
    _s_53655 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_53655)){
        _s_53655 = (long)DBL_PTR(_s_53655)->dbl;
    }
    _27676 = NOVALUE;

    /** 	varnum = SymTab[CurrentSub][S_NUM_ARGS]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _27678 = (int)*(((s1_ptr)_2)->base + _35CurrentSub_16252);
    _2 = (int)SEQ_PTR(_27678);
    if (!IS_ATOM_INT(_35S_NUM_ARGS_15968)){
        _67varnum_52675 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NUM_ARGS_15968)->dbl));
    }
    else{
        _67varnum_52675 = (int)*(((s1_ptr)_2)->base + _35S_NUM_ARGS_15968);
    }
    if (!IS_ATOM_INT(_67varnum_52675)){
        _67varnum_52675 = (long)DBL_PTR(_67varnum_52675)->dbl;
    }
    _27678 = NOVALUE;

    /** 	inline_start = start*/
    _67inline_start_52676 = _start_53612;

    /** 	last_param = CurrentSub*/
    _67last_param_52679 = _35CurrentSub_16252;

    /** 	for p = 1 to SymTab[CurrentSub][S_NUM_ARGS] do*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _27680 = (int)*(((s1_ptr)_2)->base + _35CurrentSub_16252);
    _2 = (int)SEQ_PTR(_27680);
    if (!IS_ATOM_INT(_35S_NUM_ARGS_15968)){
        _27681 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NUM_ARGS_15968)->dbl));
    }
    else{
        _27681 = (int)*(((s1_ptr)_2)->base + _35S_NUM_ARGS_15968);
    }
    _27680 = NOVALUE;
    {
        int _p_53667;
        _p_53667 = 1;
L1: 
        if (binary_op_a(GREATER, _p_53667, _27681)){
            goto L2; // [250] 282
        }

        /** 		last_param = SymTab[last_param][S_NEXT]*/
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _27682 = (int)*(((s1_ptr)_2)->base + _67last_param_52679);
        _2 = (int)SEQ_PTR(_27682);
        _67last_param_52679 = (int)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_67last_param_52679)){
            _67last_param_52679 = (long)DBL_PTR(_67last_param_52679)->dbl;
        }
        _27682 = NOVALUE;

        /** 	end for*/
        _0 = _p_53667;
        if (IS_ATOM_INT(_p_53667)) {
            _p_53667 = _p_53667 + 1;
            if ((long)((unsigned long)_p_53667 +(unsigned long) HIGH_BITS) >= 0){
                _p_53667 = NewDouble((double)_p_53667);
            }
        }
        else {
            _p_53667 = binary_op_a(PLUS, _p_53667, 1);
        }
        DeRef(_0);
        goto L1; // [277] 257
L2: 
        ;
        DeRef(_p_53667);
    }

    /** 	symtab_index last_sym = last_param*/
    _last_sym_53678 = _67last_param_52679;

    /** 	while last_sym and */
L3: 
    if (_last_sym_53678 == 0) {
        goto L4; // [296] 368
    }
    _27685 = _53sym_scope(_last_sym_53678);
    if (IS_ATOM_INT(_27685)) {
        _27686 = (_27685 <= 3);
    }
    else {
        _27686 = binary_op(LESSEQ, _27685, 3);
    }
    DeRef(_27685);
    _27685 = NOVALUE;
    if (IS_ATOM_INT(_27686)) {
        if (_27686 != 0) {
            DeRef(_27687);
            _27687 = 1;
            goto L5; // [310] 328
        }
    }
    else {
        if (DBL_PTR(_27686)->dbl != 0.0) {
            DeRef(_27687);
            _27687 = 1;
            goto L5; // [310] 328
        }
    }
    _27688 = _53sym_scope(_last_sym_53678);
    if (IS_ATOM_INT(_27688)) {
        _27689 = (_27688 == 9);
    }
    else {
        _27689 = binary_op(EQUALS, _27688, 9);
    }
    DeRef(_27688);
    _27688 = NOVALUE;
    DeRef(_27687);
    if (IS_ATOM_INT(_27689))
    _27687 = (_27689 != 0);
    else
    _27687 = DBL_PTR(_27689)->dbl != 0.0;
L5: 
    if (_27687 == 0)
    {
        _27687 = NOVALUE;
        goto L4; // [329] 368
    }
    else{
        _27687 = NOVALUE;
    }

    /** 		last_param = last_sym*/
    _67last_param_52679 = _last_sym_53678;

    /** 		last_sym = SymTab[last_sym][S_NEXT]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _27690 = (int)*(((s1_ptr)_2)->base + _last_sym_53678);
    _2 = (int)SEQ_PTR(_27690);
    _last_sym_53678 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_last_sym_53678)){
        _last_sym_53678 = (long)DBL_PTR(_last_sym_53678)->dbl;
    }
    _27690 = NOVALUE;

    /** 		varnum += 1*/
    _67varnum_52675 = _67varnum_52675 + 1;

    /** 	end while*/
    goto L3; // [365] 296
L4: 

    /** 	for p = SymTab[sub][S_NUM_ARGS] to 1 by -1 do*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _27693 = (int)*(((s1_ptr)_2)->base + _sub_53611);
    _2 = (int)SEQ_PTR(_27693);
    if (!IS_ATOM_INT(_35S_NUM_ARGS_15968)){
        _27694 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NUM_ARGS_15968)->dbl));
    }
    else{
        _27694 = (int)*(((s1_ptr)_2)->base + _35S_NUM_ARGS_15968);
    }
    _27693 = NOVALUE;
    {
        int _p_53696;
        Ref(_27694);
        _p_53696 = _27694;
L6: 
        if (binary_op_a(LESS, _p_53696, 1)){
            goto L7; // [382] 407
        }

        /** 		passed_params = prepend( passed_params, Pop() )*/
        _27695 = _41Pop();
        Ref(_27695);
        Prepend(&_67passed_params_52667, _67passed_params_52667, _27695);
        DeRef(_27695);
        _27695 = NOVALUE;

        /** 	end for*/
        _0 = _p_53696;
        if (IS_ATOM_INT(_p_53696)) {
            _p_53696 = _p_53696 + -1;
            if ((long)((unsigned long)_p_53696 +(unsigned long) HIGH_BITS) >= 0){
                _p_53696 = NewDouble((double)_p_53696);
            }
        }
        else {
            _p_53696 = binary_op_a(PLUS, _p_53696, -1);
        }
        DeRef(_0);
        goto L6; // [402] 389
L7: 
        ;
        DeRef(_p_53696);
    }

    /** 	original_params = passed_params*/
    RefDS(_67passed_params_52667);
    DeRef(_67original_params_52668);
    _67original_params_52668 = _67passed_params_52667;

    /** 	symtab_index int_sym = 0*/
    _int_sym_53705 = 0;

    /** 	for p = 1 to SymTab[sub][S_NUM_ARGS] do*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _27697 = (int)*(((s1_ptr)_2)->base + _sub_53611);
    _2 = (int)SEQ_PTR(_27697);
    if (!IS_ATOM_INT(_35S_NUM_ARGS_15968)){
        _27698 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NUM_ARGS_15968)->dbl));
    }
    else{
        _27698 = (int)*(((s1_ptr)_2)->base + _35S_NUM_ARGS_15968);
    }
    _27697 = NOVALUE;
    {
        int _p_53707;
        _p_53707 = 1;
L8: 
        if (binary_op_a(GREATER, _p_53707, _27698)){
            goto L9; // [437] 575
        }

        /** 		symtab_index param = passed_params[p]*/
        _2 = (int)SEQ_PTR(_67passed_params_52667);
        if (!IS_ATOM_INT(_p_53707)){
            _param_53713 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_p_53707)->dbl));
        }
        else{
            _param_53713 = (int)*(((s1_ptr)_2)->base + _p_53707);
        }
        if (!IS_ATOM_INT(_param_53713)){
            _param_53713 = (long)DBL_PTR(_param_53713)->dbl;
        }

        /** 		inline_params &= s*/
        Append(&_67inline_params_52669, _67inline_params_52669, _s_53655);

        /** 		integer ax = find( p, assigned_params )*/
        _ax_53716 = find_from(_p_53707, _67assigned_params_52670, 1);

        /** 		if ax or is_temp( param ) then*/
        if (_ax_53716 != 0) {
            goto LA; // [473] 486
        }
        _27703 = _67is_temp(_param_53713);
        if (_27703 == 0) {
            DeRef(_27703);
            _27703 = NOVALUE;
            goto LB; // [482] 548
        }
        else {
            if (!IS_ATOM_INT(_27703) && DBL_PTR(_27703)->dbl == 0.0){
                DeRef(_27703);
                _27703 = NOVALUE;
                goto LB; // [482] 548
            }
            DeRef(_27703);
            _27703 = NOVALUE;
        }
        DeRef(_27703);
        _27703 = NOVALUE;
LA: 

        /** 			varnum += 1*/
        _67varnum_52675 = _67varnum_52675 + 1;

        /** 			symtab_index var = new_inline_var( s, 0 )*/
        _var_53723 = _67new_inline_var(_s_53655, 0);
        if (!IS_ATOM_INT(_var_53723)) {
            _1 = (long)(DBL_PTR(_var_53723)->dbl);
            DeRefDS(_var_53723);
            _var_53723 = _1;
        }

        /** 			prolog &= {ASSIGN, param, var}*/
        _1 = NewS1(3);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = 18;
        *((int *)(_2+8)) = _param_53713;
        *((int *)(_2+12)) = _var_53723;
        _27706 = MAKE_SEQ(_1);
        Concat((object_ptr)&_prolog_53638, _prolog_53638, _27706);
        DeRefDS(_27706);
        _27706 = NOVALUE;

        /** 			if not int_sym then*/
        if (_int_sym_53705 != 0)
        goto LC; // [519] 531

        /** 				int_sym = NewIntSym( 0 )*/
        _int_sym_53705 = _53NewIntSym(0);
        if (!IS_ATOM_INT(_int_sym_53705)) {
            _1 = (long)(DBL_PTR(_int_sym_53705)->dbl);
            DeRefDS(_int_sym_53705);
            _int_sym_53705 = _1;
        }
LC: 

        /** 			inline_start += 3*/
        _67inline_start_52676 = _67inline_start_52676 + 3;

        /** 			passed_params[p] = var*/
        _2 = (int)SEQ_PTR(_67passed_params_52667);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _67passed_params_52667 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_p_53707))
        _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_p_53707)->dbl));
        else
        _2 = (int)(((s1_ptr)_2)->base + _p_53707);
        _1 = *(int *)_2;
        *(int *)_2 = _var_53723;
        DeRef(_1);
LB: 

        /** 		s = SymTab[s][S_NEXT]*/
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _27711 = (int)*(((s1_ptr)_2)->base + _s_53655);
        _2 = (int)SEQ_PTR(_27711);
        _s_53655 = (int)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_s_53655)){
            _s_53655 = (long)DBL_PTR(_s_53655)->dbl;
        }
        _27711 = NOVALUE;

        /** 	end for*/
        _0 = _p_53707;
        if (IS_ATOM_INT(_p_53707)) {
            _p_53707 = _p_53707 + 1;
            if ((long)((unsigned long)_p_53707 +(unsigned long) HIGH_BITS) >= 0){
                _p_53707 = NewDouble((double)_p_53707);
            }
        }
        else {
            _p_53707 = binary_op_a(PLUS, _p_53707, 1);
        }
        DeRef(_0);
        goto L8; // [570] 444
L9: 
        ;
        DeRef(_p_53707);
    }

    /** 	symtab_index final_target = 0*/
    _final_target_53738 = 0;

    /** 	while s and */
LD: 
    if (_s_53655 == 0) {
        goto LE; // [587] 699
    }
    _27714 = _53sym_scope(_s_53655);
    if (IS_ATOM_INT(_27714)) {
        _27715 = (_27714 <= 3);
    }
    else {
        _27715 = binary_op(LESSEQ, _27714, 3);
    }
    DeRef(_27714);
    _27714 = NOVALUE;
    if (IS_ATOM_INT(_27715)) {
        if (_27715 != 0) {
            DeRef(_27716);
            _27716 = 1;
            goto LF; // [601] 619
        }
    }
    else {
        if (DBL_PTR(_27715)->dbl != 0.0) {
            DeRef(_27716);
            _27716 = 1;
            goto LF; // [601] 619
        }
    }
    _27717 = _53sym_scope(_s_53655);
    if (IS_ATOM_INT(_27717)) {
        _27718 = (_27717 == 9);
    }
    else {
        _27718 = binary_op(EQUALS, _27717, 9);
    }
    DeRef(_27717);
    _27717 = NOVALUE;
    DeRef(_27716);
    if (IS_ATOM_INT(_27718))
    _27716 = (_27718 != 0);
    else
    _27716 = DBL_PTR(_27718)->dbl != 0.0;
LF: 
    if (_27716 == 0)
    {
        _27716 = NOVALUE;
        goto LE; // [620] 699
    }
    else{
        _27716 = NOVALUE;
    }

    /** 		if sym_scope( s ) != SC_UNDEFINED then*/
    _27719 = _53sym_scope(_s_53655);
    if (binary_op_a(EQUALS, _27719, 9)){
        DeRef(_27719);
        _27719 = NOVALUE;
        goto L10; // [631] 676
    }
    DeRef(_27719);
    _27719 = NOVALUE;

    /** 			varnum += 1*/
    _67varnum_52675 = _67varnum_52675 + 1;

    /** 			symtab_index var = new_inline_var( s, 0 )*/
    _var_53757 = _67new_inline_var(_s_53655, 0);
    if (!IS_ATOM_INT(_var_53757)) {
        _1 = (long)(DBL_PTR(_var_53757)->dbl);
        DeRefDS(_var_53757);
        _var_53757 = _1;
    }

    /** 			proc_vars &= var*/
    Append(&_67proc_vars_52665, _67proc_vars_52665, _var_53757);

    /** 			if int_sym = 0 then*/
    if (_int_sym_53705 != 0)
    goto L11; // [662] 675

    /** 				int_sym = NewIntSym( 0 )*/
    _int_sym_53705 = _53NewIntSym(0);
    if (!IS_ATOM_INT(_int_sym_53705)) {
        _1 = (long)(DBL_PTR(_int_sym_53705)->dbl);
        DeRefDS(_int_sym_53705);
        _int_sym_53705 = _1;
    }
L11: 
L10: 

    /** 		s = SymTab[s][S_NEXT]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _27726 = (int)*(((s1_ptr)_2)->base + _s_53655);
    _2 = (int)SEQ_PTR(_27726);
    _s_53655 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_53655)){
        _s_53655 = (long)DBL_PTR(_s_53655)->dbl;
    }
    _27726 = NOVALUE;

    /** 	end while*/
    goto LD; // [696] 587
LE: 

    /** 	if not is_proc then*/
    if (_is_proc_53614 != 0)
    goto L12; // [701] 831

    /** 		integer create_target_var = 1*/
    _create_target_var_53770 = 1;

    /** 		if deferred then*/
    if (_deferred_53613 == 0)
    {
        goto L13; // [711] 751
    }
    else{
    }

    /** 			inline_target = Pop()*/
    _0 = _41Pop();
    _67inline_target_52671 = _0;
    if (!IS_ATOM_INT(_67inline_target_52671)) {
        _1 = (long)(DBL_PTR(_67inline_target_52671)->dbl);
        DeRefDS(_67inline_target_52671);
        _67inline_target_52671 = _1;
    }

    /** 			if is_temp( inline_target ) then*/
    _27730 = _67is_temp(_67inline_target_52671);
    if (_27730 == 0) {
        DeRef(_27730);
        _27730 = NOVALUE;
        goto L14; // [729] 744
    }
    else {
        if (!IS_ATOM_INT(_27730) && DBL_PTR(_27730)->dbl == 0.0){
            DeRef(_27730);
            _27730 = NOVALUE;
            goto L14; // [729] 744
        }
        DeRef(_27730);
        _27730 = NOVALUE;
    }
    DeRef(_27730);
    _27730 = NOVALUE;

    /** 				final_target = inline_target*/
    _final_target_53738 = _67inline_target_52671;
    goto L15; // [741] 750
L14: 

    /** 				create_target_var = 0*/
    _create_target_var_53770 = 0;
L15: 
L13: 

    /** 		if create_target_var then*/
    if (_create_target_var_53770 == 0)
    {
        goto L16; // [753] 816
    }
    else{
    }

    /** 			varnum += 1*/
    _67varnum_52675 = _67varnum_52675 + 1;

    /** 			if TRANSLATE then*/
    if (_35TRANSLATE_15887 == 0)
    {
        goto L17; // [768] 806
    }
    else{
    }

    /** 				inline_target = new_inline_var( sub, 0 )*/
    _0 = _67new_inline_var(_sub_53611, 0);
    _67inline_target_52671 = _0;
    if (!IS_ATOM_INT(_67inline_target_52671)) {
        _1 = (long)(DBL_PTR(_67inline_target_52671)->dbl);
        DeRefDS(_67inline_target_52671);
        _67inline_target_52671 = _1;
    }

    /** 				SymTab[inline_target][S_VTYPE] = object_type*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_67inline_target_52671 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 15);
    _1 = *(int *)_2;
    *(int *)_2 = _53object_type_46091;
    DeRef(_1);
    _27733 = NOVALUE;

    /** 				Pop_block_var()*/
    _66Pop_block_var();
    goto L18; // [803] 815
L17: 

    /** 				inline_target = NewTempSym()*/
    _0 = _53NewTempSym(0);
    _67inline_target_52671 = _0;
    if (!IS_ATOM_INT(_67inline_target_52671)) {
        _1 = (long)(DBL_PTR(_67inline_target_52671)->dbl);
        DeRefDS(_67inline_target_52671);
        _67inline_target_52671 = _1;
    }
L18: 
L16: 

    /** 		proc_vars &= inline_target*/
    Append(&_67proc_vars_52665, _67proc_vars_52665, _67inline_target_52671);
    goto L19; // [828] 837
L12: 

    /** 		inline_target = 0*/
    _67inline_target_52671 = 0;
L19: 

    /** 	integer check_pc = 1*/
    _check_pc_53793 = 1;

    /** 	while length(inline_code) > check_pc do*/
L1A: 
    if (IS_SEQUENCE(_67inline_code_52664)){
            _27737 = SEQ_PTR(_67inline_code_52664)->length;
    }
    else {
        _27737 = 1;
    }
    if (_27737 <= _check_pc_53793)
    goto L1B; // [852] 1216

    /** 		integer op = inline_code[check_pc]*/
    _2 = (int)SEQ_PTR(_67inline_code_52664);
    _op_53797 = (int)*(((s1_ptr)_2)->base + _check_pc_53793);
    if (!IS_ATOM_INT(_op_53797))
    _op_53797 = (long)DBL_PTR(_op_53797)->dbl;

    /** 		switch op with fallthru do*/
    _0 = _op_53797;
    switch ( _0 ){ 

        /** 			case ATOM_CHECK then*/
        case 101:
        case 97:
        case 96:

        /** 				symtab_index sym = get_original_sym( check_pc + 1 )*/
        _27742 = _check_pc_53793 + 1;
        if (_27742 > MAXINT){
            _27742 = NewDouble((double)_27742);
        }
        _sym_53806 = _67get_original_sym(_27742);
        _27742 = NOVALUE;
        if (!IS_ATOM_INT(_sym_53806)) {
            _1 = (long)(DBL_PTR(_sym_53806)->dbl);
            DeRefDS(_sym_53806);
            _sym_53806 = _1;
        }

        /** 				if is_literal( sym ) then*/
        _27744 = _67is_literal(_sym_53806);
        if (_27744 == 0) {
            DeRef(_27744);
            _27744 = NOVALUE;
            goto L1C; // [897] 1010
        }
        else {
            if (!IS_ATOM_INT(_27744) && DBL_PTR(_27744)->dbl == 0.0){
                DeRef(_27744);
                _27744 = NOVALUE;
                goto L1C; // [897] 1010
            }
            DeRef(_27744);
            _27744 = NOVALUE;
        }
        DeRef(_27744);
        _27744 = NOVALUE;

        /** 					integer check_result*/

        /** 					if op = INTEGER_CHECK then*/
        if (_op_53797 != 96)
        goto L1D; // [906] 930

        /** 						check_result = integer( SymTab[sym][S_OBJ] )*/
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _27746 = (int)*(((s1_ptr)_2)->base + _sym_53806);
        _2 = (int)SEQ_PTR(_27746);
        _27747 = (int)*(((s1_ptr)_2)->base + 1);
        _27746 = NOVALUE;
        if (IS_ATOM_INT(_27747))
        _check_result_53811 = 1;
        else if (IS_ATOM_DBL(_27747))
        _check_result_53811 = IS_ATOM_INT(DoubleToInt(_27747));
        else
        _check_result_53811 = 0;
        _27747 = NOVALUE;
        goto L1E; // [927] 976
L1D: 

        /** 					elsif op = SEQUENCE_CHECK then*/
        if (_op_53797 != 97)
        goto L1F; // [934] 958

        /** 						check_result = sequence( SymTab[sym][S_OBJ] )*/
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _27750 = (int)*(((s1_ptr)_2)->base + _sym_53806);
        _2 = (int)SEQ_PTR(_27750);
        _27751 = (int)*(((s1_ptr)_2)->base + 1);
        _27750 = NOVALUE;
        _check_result_53811 = IS_SEQUENCE(_27751);
        _27751 = NOVALUE;
        goto L1E; // [955] 976
L1F: 

        /** 						check_result = atom( SymTab[sym][S_OBJ] )*/
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _27753 = (int)*(((s1_ptr)_2)->base + _sym_53806);
        _2 = (int)SEQ_PTR(_27753);
        _27754 = (int)*(((s1_ptr)_2)->base + 1);
        _27753 = NOVALUE;
        _check_result_53811 = IS_ATOM(_27754);
        _27754 = NOVALUE;
L1E: 

        /** 					if check_result then*/
        if (_check_result_53811 == 0)
        {
            goto L20; // [980] 997
        }
        else{
        }

        /** 						replace_code( {}, check_pc, check_pc+1 )*/
        _27756 = _check_pc_53793 + 1;
        if (_27756 > MAXINT){
            _27756 = NewDouble((double)_27756);
        }
        RefDS(_22023);
        _67replace_code(_22023, _check_pc_53793, _27756);
        _27756 = NOVALUE;
        goto L21; // [994] 1005
L20: 

        /** 						CompileErr(146)*/
        RefDS(_22023);
        _44CompileErr(146, _22023, 0);
L21: 
        goto L22; // [1007] 1172
L1C: 

        /** 				elsif not is_temp( sym ) then*/
        _27758 = _67is_temp(_sym_53806);
        if (IS_ATOM_INT(_27758)) {
            if (_27758 != 0){
                DeRef(_27758);
                _27758 = NOVALUE;
                goto L23; // [1016] 1165
            }
        }
        else {
            if (DBL_PTR(_27758)->dbl != 0.0){
                DeRef(_27758);
                _27758 = NOVALUE;
                goto L23; // [1016] 1165
            }
        }
        DeRef(_27758);
        _27758 = NOVALUE;

        /** 					if (op = INTEGER_CHECK and SymTab[sym][S_VTYPE] = integer_type )*/
        _27760 = (_op_53797 == 96);
        if (_27760 == 0) {
            _27761 = 0;
            goto L24; // [1027] 1053
        }
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _27762 = (int)*(((s1_ptr)_2)->base + _sym_53806);
        _2 = (int)SEQ_PTR(_27762);
        _27763 = (int)*(((s1_ptr)_2)->base + 15);
        _27762 = NOVALUE;
        if (IS_ATOM_INT(_27763)) {
            _27764 = (_27763 == _53integer_type_46097);
        }
        else {
            _27764 = binary_op(EQUALS, _27763, _53integer_type_46097);
        }
        _27763 = NOVALUE;
        if (IS_ATOM_INT(_27764))
        _27761 = (_27764 != 0);
        else
        _27761 = DBL_PTR(_27764)->dbl != 0.0;
L24: 
        if (_27761 != 0) {
            _27765 = 1;
            goto L25; // [1053] 1093
        }
        _27766 = (_op_53797 == 97);
        if (_27766 == 0) {
            _27767 = 0;
            goto L26; // [1063] 1089
        }
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _27768 = (int)*(((s1_ptr)_2)->base + _sym_53806);
        _2 = (int)SEQ_PTR(_27768);
        _27769 = (int)*(((s1_ptr)_2)->base + 15);
        _27768 = NOVALUE;
        if (IS_ATOM_INT(_27769)) {
            _27770 = (_27769 == _53sequence_type_46095);
        }
        else {
            _27770 = binary_op(EQUALS, _27769, _53sequence_type_46095);
        }
        _27769 = NOVALUE;
        if (IS_ATOM_INT(_27770))
        _27767 = (_27770 != 0);
        else
        _27767 = DBL_PTR(_27770)->dbl != 0.0;
L26: 
        _27765 = (_27767 != 0);
L25: 
        if (_27765 != 0) {
            goto L27; // [1093] 1141
        }
        _27772 = (_op_53797 == 101);
        if (_27772 == 0) {
            DeRef(_27773);
            _27773 = 0;
            goto L28; // [1103] 1136
        }
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _27774 = (int)*(((s1_ptr)_2)->base + _sym_53806);
        _2 = (int)SEQ_PTR(_27774);
        _27775 = (int)*(((s1_ptr)_2)->base + 15);
        _27774 = NOVALUE;
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _53integer_type_46097;
        ((int *)_2)[2] = _53atom_type_46093;
        _27776 = MAKE_SEQ(_1);
        _27777 = find_from(_27775, _27776, 1);
        _27775 = NOVALUE;
        DeRefDS(_27776);
        _27776 = NOVALUE;
        _27773 = (_27777 != 0);
L28: 
        if (_27773 == 0)
        {
            _27773 = NOVALUE;
            goto L29; // [1137] 1155
        }
        else{
            _27773 = NOVALUE;
        }
L27: 

        /** 						replace_code( {}, check_pc, check_pc+1 )*/
        _27778 = _check_pc_53793 + 1;
        if (_27778 > MAXINT){
            _27778 = NewDouble((double)_27778);
        }
        RefDS(_22023);
        _67replace_code(_22023, _check_pc_53793, _27778);
        _27778 = NOVALUE;
        goto L22; // [1152] 1172
L29: 

        /** 						check_pc += 2*/
        _check_pc_53793 = _check_pc_53793 + 2;
        goto L22; // [1162] 1172
L23: 

        /** 					check_pc += 2*/
        _check_pc_53793 = _check_pc_53793 + 2;
L22: 

        /** 				continue*/
        goto L1A; // [1178] 847

        /** 			case STARTLINE then*/
        case 58:

        /** 				check_pc += 2*/
        _check_pc_53793 = _check_pc_53793 + 2;

        /** 				continue*/
        goto L1A; // [1196] 847

        /** 			case else*/
        default:

        /** 				exit*/
        goto L1B; // [1206] 1216
    ;}
    /** 	end while*/
    goto L1A; // [1213] 847
L1B: 

    /** 	for pc = 1 to length( inline_code ) do*/
    if (IS_SEQUENCE(_67inline_code_52664)){
            _27782 = SEQ_PTR(_67inline_code_52664)->length;
    }
    else {
        _27782 = 1;
    }
    {
        int _pc_53884;
        _pc_53884 = 1;
L2A: 
        if (_pc_53884 > _27782){
            goto L2B; // [1223] 1420
        }

        /** 		if sequence( inline_code[pc] ) then*/
        _2 = (int)SEQ_PTR(_67inline_code_52664);
        _27783 = (int)*(((s1_ptr)_2)->base + _pc_53884);
        _27784 = IS_SEQUENCE(_27783);
        _27783 = NOVALUE;
        if (_27784 == 0)
        {
            _27784 = NOVALUE;
            goto L2C; // [1241] 1411
        }
        else{
            _27784 = NOVALUE;
        }

        /** 			integer inline_type = inline_code[pc][1]*/
        _2 = (int)SEQ_PTR(_67inline_code_52664);
        _27785 = (int)*(((s1_ptr)_2)->base + _pc_53884);
        _2 = (int)SEQ_PTR(_27785);
        _inline_type_53889 = (int)*(((s1_ptr)_2)->base + 1);
        if (!IS_ATOM_INT(_inline_type_53889)){
            _inline_type_53889 = (long)DBL_PTR(_inline_type_53889)->dbl;
        }
        _27785 = NOVALUE;

        /** 			switch inline_type do*/
        _0 = _inline_type_53889;
        switch ( _0 ){ 

            /** 				case INLINE_SUB then*/
            case 5:

            /** 					inline_code[pc] = CurrentSub*/
            _2 = (int)SEQ_PTR(_67inline_code_52664);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _67inline_code_52664 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _pc_53884);
            _1 = *(int *)_2;
            *(int *)_2 = _35CurrentSub_16252;
            DeRef(_1);
            goto L2D; // [1279] 1410

            /** 				case INLINE_VAR then*/
            case 6:

            /** 					replace_var( pc )*/
            _67replace_var(_pc_53884);

            /** 					break*/
            goto L2D; // [1292] 1410
            goto L2D; // [1294] 1410

            /** 				case INLINE_TEMP then*/
            case 2:

            /** 					replace_temp( pc )*/
            _67replace_temp(_pc_53884);
            goto L2D; // [1305] 1410

            /** 				case INLINE_PARAM then*/
            case 1:

            /** 					replace_param( pc )*/

            /** 	inline_code[pc] = get_param_sym( pc )*/
            _0 = _replace_param_1__tmp_at1341_53900;
            _replace_param_1__tmp_at1341_53900 = _67get_param_sym(_pc_53884);
            DeRef(_0);
            Ref(_replace_param_1__tmp_at1341_53900);
            _2 = (int)SEQ_PTR(_67inline_code_52664);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _67inline_code_52664 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _pc_53884);
            _1 = *(int *)_2;
            *(int *)_2 = _replace_param_1__tmp_at1341_53900;
            DeRef(_1);

            /** end procedure*/
            goto L2E; // [1327] 1330
L2E: 
            DeRef(_replace_param_1__tmp_at1341_53900);
            _replace_param_1__tmp_at1341_53900 = NOVALUE;
            goto L2D; // [1332] 1410

            /** 				case INLINE_ADDR then*/
            case 4:

            /** 					inline_code[pc] = inline_start + inline_code[pc][2]*/
            _2 = (int)SEQ_PTR(_67inline_code_52664);
            _27789 = (int)*(((s1_ptr)_2)->base + _pc_53884);
            _2 = (int)SEQ_PTR(_27789);
            _27790 = (int)*(((s1_ptr)_2)->base + 2);
            _27789 = NOVALUE;
            if (IS_ATOM_INT(_27790)) {
                _27791 = _67inline_start_52676 + _27790;
                if ((long)((unsigned long)_27791 + (unsigned long)HIGH_BITS) >= 0) 
                _27791 = NewDouble((double)_27791);
            }
            else {
                _27791 = binary_op(PLUS, _67inline_start_52676, _27790);
            }
            _27790 = NOVALUE;
            _2 = (int)SEQ_PTR(_67inline_code_52664);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _67inline_code_52664 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _pc_53884);
            _1 = *(int *)_2;
            *(int *)_2 = _27791;
            if( _1 != _27791 ){
                DeRef(_1);
            }
            _27791 = NOVALUE;
            goto L2D; // [1362] 1410

            /** 				case INLINE_TARGET then*/
            case 3:

            /** 					inline_code[pc] = inline_target*/
            _2 = (int)SEQ_PTR(_67inline_code_52664);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _67inline_code_52664 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _pc_53884);
            _1 = *(int *)_2;
            *(int *)_2 = _67inline_target_52671;
            DeRef(_1);

            /** 					add_inline_target( pc + inline_start )*/
            _27792 = _pc_53884 + _67inline_start_52676;
            if ((long)((unsigned long)_27792 + (unsigned long)HIGH_BITS) >= 0) 
            _27792 = NewDouble((double)_27792);
            _41add_inline_target(_27792);
            _27792 = NOVALUE;

            /** 					break*/
            goto L2D; // [1391] 1410
            goto L2D; // [1393] 1410

            /** 				case else*/
            default:

            /** 					InternalErr( 265, {inline_type} )*/
            _1 = NewS1(1);
            _2 = (int)((s1_ptr)_1)->base;
            *((int *)(_2+4)) = _inline_type_53889;
            _27793 = MAKE_SEQ(_1);
            _44InternalErr(265, _27793);
            _27793 = NOVALUE;
        ;}L2D: 
L2C: 

        /** 	end for*/
        _pc_53884 = _pc_53884 + 1;
        goto L2A; // [1415] 1230
L2B: 
        ;
    }

    /** 	for i = 1 to length(backpatches) do*/
    if (IS_SEQUENCE(_backpatches_53632)){
            _27794 = SEQ_PTR(_backpatches_53632)->length;
    }
    else {
        _27794 = 1;
    }
    {
        int _i_53912;
        _i_53912 = 1;
L2F: 
        if (_i_53912 > _27794){
            goto L30; // [1425] 1448
        }

        /** 		fixup_special_op( backpatches[i] )*/
        _2 = (int)SEQ_PTR(_backpatches_53632);
        _27795 = (int)*(((s1_ptr)_2)->base + _i_53912);
        Ref(_27795);
        _67fixup_special_op(_27795);
        _27795 = NOVALUE;

        /** 	end for*/
        _i_53912 = _i_53912 + 1;
        goto L2F; // [1443] 1432
L30: 
        ;
    }

    /** 	epilog &= End_inline_block( EXIT_BLOCK )*/
    _27796 = _66End_inline_block(206);
    if (IS_SEQUENCE(_epilog_53639) && IS_ATOM(_27796)) {
        Ref(_27796);
        Append(&_epilog_53639, _epilog_53639, _27796);
    }
    else if (IS_ATOM(_epilog_53639) && IS_SEQUENCE(_27796)) {
    }
    else {
        Concat((object_ptr)&_epilog_53639, _epilog_53639, _27796);
    }
    DeRef(_27796);
    _27796 = NOVALUE;

    /** 	if is_proc then*/
    if (_is_proc_53614 == 0)
    {
        goto L31; // [1462] 1472
    }
    else{
    }

    /** 		clear_op()*/
    _41clear_op();
    goto L32; // [1469] 1595
L31: 

    /** 		if not deferred then*/
    if (_deferred_53613 != 0)
    goto L33; // [1474] 1489

    /** 			Push( inline_target )*/
    _41Push(_67inline_target_52671);

    /** 			inlined_function()*/
    _41inlined_function();
L33: 

    /** 		if final_target then*/
    if (_final_target_53738 == 0)
    {
        goto L34; // [1491] 1521
    }
    else{
    }

    /** 			epilog &= { ASSIGN, inline_target, final_target }*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 18;
    *((int *)(_2+8)) = _67inline_target_52671;
    *((int *)(_2+12)) = _final_target_53738;
    _27799 = MAKE_SEQ(_1);
    Concat((object_ptr)&_epilog_53639, _epilog_53639, _27799);
    DeRefDS(_27799);
    _27799 = NOVALUE;

    /** 			emit_temp( final_target, NEW_REFERENCE )*/
    _41emit_temp(_final_target_53738, 1);
    goto L35; // [1518] 1594
L34: 

    /** 			emit_temp( inline_target, NEW_REFERENCE )*/
    _41emit_temp(_67inline_target_52671, 1);

    /** 			if not TRANSLATE then*/
    if (_35TRANSLATE_15887 != 0)
    goto L36; // [1535] 1593

    /** 				epilog &= { ELSE, 0, PRIVATE_INIT_CHECK, inline_target }*/
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 23;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = 30;
    *((int *)(_2+16)) = _67inline_target_52671;
    _27802 = MAKE_SEQ(_1);
    Concat((object_ptr)&_epilog_53639, _epilog_53639, _27802);
    DeRefDS(_27802);
    _27802 = NOVALUE;

    /** 				epilog[$-2] = length(inline_code) + length(epilog) + inline_start + 1*/
    if (IS_SEQUENCE(_epilog_53639)){
            _27804 = SEQ_PTR(_epilog_53639)->length;
    }
    else {
        _27804 = 1;
    }
    _27805 = _27804 - 2;
    _27804 = NOVALUE;
    if (IS_SEQUENCE(_67inline_code_52664)){
            _27806 = SEQ_PTR(_67inline_code_52664)->length;
    }
    else {
        _27806 = 1;
    }
    if (IS_SEQUENCE(_epilog_53639)){
            _27807 = SEQ_PTR(_epilog_53639)->length;
    }
    else {
        _27807 = 1;
    }
    _27808 = _27806 + _27807;
    if ((long)((unsigned long)_27808 + (unsigned long)HIGH_BITS) >= 0) 
    _27808 = NewDouble((double)_27808);
    _27806 = NOVALUE;
    _27807 = NOVALUE;
    if (IS_ATOM_INT(_27808)) {
        _27809 = _27808 + _67inline_start_52676;
        if ((long)((unsigned long)_27809 + (unsigned long)HIGH_BITS) >= 0) 
        _27809 = NewDouble((double)_27809);
    }
    else {
        _27809 = NewDouble(DBL_PTR(_27808)->dbl + (double)_67inline_start_52676);
    }
    DeRef(_27808);
    _27808 = NOVALUE;
    if (IS_ATOM_INT(_27809)) {
        _27810 = _27809 + 1;
        if (_27810 > MAXINT){
            _27810 = NewDouble((double)_27810);
        }
    }
    else
    _27810 = binary_op(PLUS, 1, _27809);
    DeRef(_27809);
    _27809 = NOVALUE;
    _2 = (int)SEQ_PTR(_epilog_53639);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _epilog_53639 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _27805);
    _1 = *(int *)_2;
    *(int *)_2 = _27810;
    if( _1 != _27810 ){
        DeRef(_1);
    }
    _27810 = NOVALUE;
L36: 
L35: 
L32: 

    /** 	return prolog & inline_code & epilog*/
    {
        int concat_list[3];

        concat_list[0] = _epilog_53639;
        concat_list[1] = _67inline_code_52664;
        concat_list[2] = _prolog_53638;
        Concat_N((object_ptr)&_27811, concat_list, 3);
    }
    DeRef(_backpatches_53632);
    DeRefDSi(_prolog_53638);
    DeRefDS(_epilog_53639);
    _27681 = NOVALUE;
    _27694 = NOVALUE;
    DeRef(_27686);
    _27686 = NOVALUE;
    DeRef(_27689);
    _27689 = NOVALUE;
    _27698 = NOVALUE;
    DeRef(_27760);
    _27760 = NOVALUE;
    DeRef(_27715);
    _27715 = NOVALUE;
    DeRef(_27718);
    _27718 = NOVALUE;
    DeRef(_27766);
    _27766 = NOVALUE;
    DeRef(_27764);
    _27764 = NOVALUE;
    DeRef(_27772);
    _27772 = NOVALUE;
    DeRef(_27770);
    _27770 = NOVALUE;
    DeRef(_27805);
    _27805 = NOVALUE;
    return _27811;
    ;
}


void _67defer_call()
{
    int _defer_53952 = NOVALUE;
    int _27814 = NOVALUE;
    int _27813 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer defer = find( inline_sub, deferred_inline_decisions )*/
    _defer_53952 = find_from(_67inline_sub_52678, _67deferred_inline_decisions_52680, 1);

    /** 	if defer then*/
    if (_defer_53952 == 0)
    {
        goto L1; // [14] 36
    }
    else{
    }

    /** 		deferred_inline_calls[defer] &= CurrentSub*/
    _2 = (int)SEQ_PTR(_67deferred_inline_calls_52681);
    _27813 = (int)*(((s1_ptr)_2)->base + _defer_53952);
    if (IS_SEQUENCE(_27813) && IS_ATOM(_35CurrentSub_16252)) {
        Append(&_27814, _27813, _35CurrentSub_16252);
    }
    else if (IS_ATOM(_27813) && IS_SEQUENCE(_35CurrentSub_16252)) {
    }
    else {
        Concat((object_ptr)&_27814, _27813, _35CurrentSub_16252);
        _27813 = NOVALUE;
    }
    _27813 = NOVALUE;
    _2 = (int)SEQ_PTR(_67deferred_inline_calls_52681);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _67deferred_inline_calls_52681 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _defer_53952);
    _1 = *(int *)_2;
    *(int *)_2 = _27814;
    if( _1 != _27814 ){
        DeRef(_1);
    }
    _27814 = NOVALUE;
L1: 

    /** end procedure*/
    return;
    ;
}


void _67emit_or_inline()
{
    int _sub_53961 = NOVALUE;
    int _code_53980 = NOVALUE;
    int _27821 = NOVALUE;
    int _27820 = NOVALUE;
    int _27818 = NOVALUE;
    int _27817 = NOVALUE;
    int _27816 = NOVALUE;
    int _0, _1, _2;
    

    /** 	symtab_index sub = op_info1*/
    _sub_53961 = _41op_info1_50222;

    /** 	inline_sub = sub*/
    _67inline_sub_52678 = _sub_53961;

    /** 	if Parser_mode != PAM_NORMAL then*/
    if (_35Parser_mode_16349 == 0)
    goto L1; // [23] 42

    /** 		emit_op( PROC )*/
    _41emit_op(27);

    /** 		return*/
    DeRef(_code_53980);
    return;
    goto L2; // [39] 90
L1: 

    /** 	elsif atom( SymTab[sub][S_INLINE] ) or has_forward_params(sub) then*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _27816 = (int)*(((s1_ptr)_2)->base + _sub_53961);
    _2 = (int)SEQ_PTR(_27816);
    _27817 = (int)*(((s1_ptr)_2)->base + 29);
    _27816 = NOVALUE;
    _27818 = IS_ATOM(_27817);
    _27817 = NOVALUE;
    if (_27818 != 0) {
        goto L3; // [59] 72
    }
    _27820 = _41has_forward_params(_sub_53961);
    if (_27820 == 0) {
        DeRef(_27820);
        _27820 = NOVALUE;
        goto L4; // [68] 89
    }
    else {
        if (!IS_ATOM_INT(_27820) && DBL_PTR(_27820)->dbl == 0.0){
            DeRef(_27820);
            _27820 = NOVALUE;
            goto L4; // [68] 89
        }
        DeRef(_27820);
        _27820 = NOVALUE;
    }
    DeRef(_27820);
    _27820 = NOVALUE;
L3: 

    /** 		defer_call()*/
    _67defer_call();

    /** 		emit_op( PROC )*/
    _41emit_op(27);

    /** 		return*/
    DeRef(_code_53980);
    return;
L4: 
L2: 

    /** 	sequence code = get_inlined_code( sub, length(Code) )*/
    if (IS_SEQUENCE(_35Code_16332)){
            _27821 = SEQ_PTR(_35Code_16332)->length;
    }
    else {
        _27821 = 1;
    }
    _0 = _code_53980;
    _code_53980 = _67get_inlined_code(_sub_53961, _27821, 0);
    DeRef(_0);
    _27821 = NOVALUE;

    /** 	emit_inline( code )*/
    RefDS(_code_53980);
    _41emit_inline(_code_53980);

    /** 	clear_last()*/
    _41clear_last();

    /** end procedure*/
    DeRefDS(_code_53980);
    return;
    ;
}


void _67inline_deferred_calls()
{
    int _sub_53994 = NOVALUE;
    int _ix_54006 = NOVALUE;
    int _calling_sub_54008 = NOVALUE;
    int _code_54022 = NOVALUE;
    int _calls_54023 = NOVALUE;
    int _is_func_54027 = NOVALUE;
    int _offset_54034 = NOVALUE;
    int _op_54045 = NOVALUE;
    int _size_54048 = NOVALUE;
    int _27879 = NOVALUE;
    int _27877 = NOVALUE;
    int _27875 = NOVALUE;
    int _27874 = NOVALUE;
    int _27873 = NOVALUE;
    int _27871 = NOVALUE;
    int _27870 = NOVALUE;
    int _27869 = NOVALUE;
    int _27868 = NOVALUE;
    int _27867 = NOVALUE;
    int _27866 = NOVALUE;
    int _27865 = NOVALUE;
    int _27864 = NOVALUE;
    int _27863 = NOVALUE;
    int _27862 = NOVALUE;
    int _27860 = NOVALUE;
    int _27859 = NOVALUE;
    int _27858 = NOVALUE;
    int _27857 = NOVALUE;
    int _27855 = NOVALUE;
    int _27854 = NOVALUE;
    int _27853 = NOVALUE;
    int _27851 = NOVALUE;
    int _27849 = NOVALUE;
    int _27847 = NOVALUE;
    int _27845 = NOVALUE;
    int _27844 = NOVALUE;
    int _27843 = NOVALUE;
    int _27842 = NOVALUE;
    int _27840 = NOVALUE;
    int _27839 = NOVALUE;
    int _27836 = NOVALUE;
    int _27834 = NOVALUE;
    int _27832 = NOVALUE;
    int _27831 = NOVALUE;
    int _27830 = NOVALUE;
    int _27829 = NOVALUE;
    int _27828 = NOVALUE;
    int _27827 = NOVALUE;
    int _27825 = NOVALUE;
    int _27824 = NOVALUE;
    int _27823 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	deferred_inlining = 1*/
    _67deferred_inlining_52674 = 1;

    /** 	for i = 1 to length( deferred_inline_decisions ) do*/
    if (IS_SEQUENCE(_67deferred_inline_decisions_52680)){
            _27823 = SEQ_PTR(_67deferred_inline_decisions_52680)->length;
    }
    else {
        _27823 = 1;
    }
    {
        int _i_53989;
        _i_53989 = 1;
L1: 
        if (_i_53989 > _27823){
            goto L2; // [13] 476
        }

        /** 		if length( deferred_inline_calls[i] ) then*/
        _2 = (int)SEQ_PTR(_67deferred_inline_calls_52681);
        _27824 = (int)*(((s1_ptr)_2)->base + _i_53989);
        if (IS_SEQUENCE(_27824)){
                _27825 = SEQ_PTR(_27824)->length;
        }
        else {
            _27825 = 1;
        }
        _27824 = NOVALUE;
        if (_27825 == 0)
        {
            _27825 = NOVALUE;
            goto L3; // [31] 467
        }
        else{
            _27825 = NOVALUE;
        }

        /** 			integer sub = deferred_inline_decisions[i]*/
        _2 = (int)SEQ_PTR(_67deferred_inline_decisions_52680);
        _sub_53994 = (int)*(((s1_ptr)_2)->base + _i_53989);

        /** 			check_inline( sub )*/
        _67check_inline(_sub_53994);

        /** 			if atom( SymTab[sub][S_INLINE] ) then*/
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _27827 = (int)*(((s1_ptr)_2)->base + _sub_53994);
        _2 = (int)SEQ_PTR(_27827);
        _27828 = (int)*(((s1_ptr)_2)->base + 29);
        _27827 = NOVALUE;
        _27829 = IS_ATOM(_27828);
        _27828 = NOVALUE;
        if (_27829 == 0)
        {
            _27829 = NOVALUE;
            goto L4; // [64] 74
        }
        else{
            _27829 = NOVALUE;
        }

        /** 				continue*/
        goto L5; // [71] 471
L4: 

        /** 			for cx = 1 to length( deferred_inline_calls[i] ) do*/
        _2 = (int)SEQ_PTR(_67deferred_inline_calls_52681);
        _27830 = (int)*(((s1_ptr)_2)->base + _i_53989);
        if (IS_SEQUENCE(_27830)){
                _27831 = SEQ_PTR(_27830)->length;
        }
        else {
            _27831 = 1;
        }
        _27830 = NOVALUE;
        {
            int _cx_54003;
            _cx_54003 = 1;
L6: 
            if (_cx_54003 > _27831){
                goto L7; // [85] 466
            }

            /** 				integer ix = 1*/
            _ix_54006 = 1;

            /** 				symtab_index calling_sub = deferred_inline_calls[i][cx]*/
            _2 = (int)SEQ_PTR(_67deferred_inline_calls_52681);
            _27832 = (int)*(((s1_ptr)_2)->base + _i_53989);
            _2 = (int)SEQ_PTR(_27832);
            _calling_sub_54008 = (int)*(((s1_ptr)_2)->base + _cx_54003);
            if (!IS_ATOM_INT(_calling_sub_54008)){
                _calling_sub_54008 = (long)DBL_PTR(_calling_sub_54008)->dbl;
            }
            _27832 = NOVALUE;

            /** 				CurrentSub = calling_sub*/
            _35CurrentSub_16252 = _calling_sub_54008;

            /** 				Code = SymTab[calling_sub][S_CODE]*/
            _2 = (int)SEQ_PTR(_36SymTab_15242);
            _27834 = (int)*(((s1_ptr)_2)->base + _calling_sub_54008);
            DeRef(_35Code_16332);
            _2 = (int)SEQ_PTR(_27834);
            if (!IS_ATOM_INT(_35S_CODE_15929)){
                _35Code_16332 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_CODE_15929)->dbl));
            }
            else{
                _35Code_16332 = (int)*(((s1_ptr)_2)->base + _35S_CODE_15929);
            }
            Ref(_35Code_16332);
            _27834 = NOVALUE;

            /** 				LineTable = SymTab[calling_sub][S_LINETAB]*/
            _2 = (int)SEQ_PTR(_36SymTab_15242);
            _27836 = (int)*(((s1_ptr)_2)->base + _calling_sub_54008);
            DeRef(_35LineTable_16333);
            _2 = (int)SEQ_PTR(_27836);
            if (!IS_ATOM_INT(_35S_LINETAB_15952)){
                _35LineTable_16333 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_LINETAB_15952)->dbl));
            }
            else{
                _35LineTable_16333 = (int)*(((s1_ptr)_2)->base + _35S_LINETAB_15952);
            }
            Ref(_35LineTable_16333);
            _27836 = NOVALUE;

            /** 				sequence code = {}*/
            RefDS(_22023);
            DeRef(_code_54022);
            _code_54022 = _22023;

            /** 				sequence calls = find_ops( 1, PROC )*/
            RefDS(_35Code_16332);
            _0 = _calls_54023;
            _calls_54023 = _65find_ops(1, 27, _35Code_16332);
            DeRef(_0);

            /** 				integer is_func = SymTab[sub][S_TOKEN] != PROC */
            _2 = (int)SEQ_PTR(_36SymTab_15242);
            _27839 = (int)*(((s1_ptr)_2)->base + _sub_53994);
            _2 = (int)SEQ_PTR(_27839);
            if (!IS_ATOM_INT(_35S_TOKEN_15922)){
                _27840 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TOKEN_15922)->dbl));
            }
            else{
                _27840 = (int)*(((s1_ptr)_2)->base + _35S_TOKEN_15922);
            }
            _27839 = NOVALUE;
            if (IS_ATOM_INT(_27840)) {
                _is_func_54027 = (_27840 != 27);
            }
            else {
                _is_func_54027 = binary_op(NOTEQ, _27840, 27);
            }
            _27840 = NOVALUE;
            if (!IS_ATOM_INT(_is_func_54027)) {
                _1 = (long)(DBL_PTR(_is_func_54027)->dbl);
                DeRefDS(_is_func_54027);
                _is_func_54027 = _1;
            }

            /** 				integer offset = 0*/
            _offset_54034 = 0;

            /** 				for o = 1 to length( calls ) do*/
            if (IS_SEQUENCE(_calls_54023)){
                    _27842 = SEQ_PTR(_calls_54023)->length;
            }
            else {
                _27842 = 1;
            }
            {
                int _o_54036;
                _o_54036 = 1;
L8: 
                if (_o_54036 > _27842){
                    goto L9; // [203] 423
                }

                /** 					if calls[o][2][2] = sub then*/
                _2 = (int)SEQ_PTR(_calls_54023);
                _27843 = (int)*(((s1_ptr)_2)->base + _o_54036);
                _2 = (int)SEQ_PTR(_27843);
                _27844 = (int)*(((s1_ptr)_2)->base + 2);
                _27843 = NOVALUE;
                _2 = (int)SEQ_PTR(_27844);
                _27845 = (int)*(((s1_ptr)_2)->base + 2);
                _27844 = NOVALUE;
                if (binary_op_a(NOTEQ, _27845, _sub_53994)){
                    _27845 = NOVALUE;
                    goto LA; // [224] 414
                }
                _27845 = NOVALUE;

                /** 						ix = calls[o][1]*/
                _2 = (int)SEQ_PTR(_calls_54023);
                _27847 = (int)*(((s1_ptr)_2)->base + _o_54036);
                _2 = (int)SEQ_PTR(_27847);
                _ix_54006 = (int)*(((s1_ptr)_2)->base + 1);
                if (!IS_ATOM_INT(_ix_54006)){
                    _ix_54006 = (long)DBL_PTR(_ix_54006)->dbl;
                }
                _27847 = NOVALUE;

                /** 						sequence op = calls[o][2]*/
                _2 = (int)SEQ_PTR(_calls_54023);
                _27849 = (int)*(((s1_ptr)_2)->base + _o_54036);
                DeRef(_op_54045);
                _2 = (int)SEQ_PTR(_27849);
                _op_54045 = (int)*(((s1_ptr)_2)->base + 2);
                Ref(_op_54045);
                _27849 = NOVALUE;

                /** 						integer size = length( op ) - 1*/
                if (IS_SEQUENCE(_op_54045)){
                        _27851 = SEQ_PTR(_op_54045)->length;
                }
                else {
                    _27851 = 1;
                }
                _size_54048 = _27851 - 1;
                _27851 = NOVALUE;

                /** 						if is_func then*/
                if (_is_func_54027 == 0)
                {
                    goto LB; // [263] 289
                }
                else{
                }

                /** 							Push( op[$] )*/
                if (IS_SEQUENCE(_op_54045)){
                        _27853 = SEQ_PTR(_op_54045)->length;
                }
                else {
                    _27853 = 1;
                }
                _2 = (int)SEQ_PTR(_op_54045);
                _27854 = (int)*(((s1_ptr)_2)->base + _27853);
                Ref(_27854);
                _41Push(_27854);
                _27854 = NOVALUE;

                /** 							op = remove( op, length(op) )*/
                if (IS_SEQUENCE(_op_54045)){
                        _27855 = SEQ_PTR(_op_54045)->length;
                }
                else {
                    _27855 = 1;
                }
                {
                    s1_ptr assign_space = SEQ_PTR(_op_54045);
                    int len = assign_space->length;
                    int start = (IS_ATOM_INT(_27855)) ? _27855 : (long)(DBL_PTR(_27855)->dbl);
                    int stop = (IS_ATOM_INT(_27855)) ? _27855 : (long)(DBL_PTR(_27855)->dbl);
                    if (stop > len){
                        stop = len;
                    }
                    if (start > len || start > stop || stop<0) {
                    }
                    else if (start < 2) {
                        if (stop >= len) {
                            Head( SEQ_PTR(_op_54045), start, &_op_54045 );
                        }
                        else Tail(SEQ_PTR(_op_54045), stop+1, &_op_54045);
                    }
                    else if (stop >= len){
                        Head(SEQ_PTR(_op_54045), start, &_op_54045);
                    }
                    else {
                        assign_slice_seq = &assign_space;
                        _op_54045 = Remove_elements(start, stop, (SEQ_PTR(_op_54045)->ref == 1));
                    }
                }
                _27855 = NOVALUE;
                _27855 = NOVALUE;
LB: 

                /** 						for p = 3 to length( op ) do*/
                if (IS_SEQUENCE(_op_54045)){
                        _27857 = SEQ_PTR(_op_54045)->length;
                }
                else {
                    _27857 = 1;
                }
                {
                    int _p_54058;
                    _p_54058 = 3;
LC: 
                    if (_p_54058 > _27857){
                        goto LD; // [294] 317
                    }

                    /** 							Push( op[p] )*/
                    _2 = (int)SEQ_PTR(_op_54045);
                    _27858 = (int)*(((s1_ptr)_2)->base + _p_54058);
                    Ref(_27858);
                    _41Push(_27858);
                    _27858 = NOVALUE;

                    /** 						end for*/
                    _p_54058 = _p_54058 + 1;
                    goto LC; // [312] 301
LD: 
                    ;
                }

                /** 						code = get_inlined_code( sub, ix + offset - 1, 1 )*/
                _27859 = _ix_54006 + _offset_54034;
                if ((long)((unsigned long)_27859 + (unsigned long)HIGH_BITS) >= 0) 
                _27859 = NewDouble((double)_27859);
                if (IS_ATOM_INT(_27859)) {
                    _27860 = _27859 - 1;
                    if ((long)((unsigned long)_27860 +(unsigned long) HIGH_BITS) >= 0){
                        _27860 = NewDouble((double)_27860);
                    }
                }
                else {
                    _27860 = NewDouble(DBL_PTR(_27859)->dbl - (double)1);
                }
                DeRef(_27859);
                _27859 = NOVALUE;
                _0 = _code_54022;
                _code_54022 = _67get_inlined_code(_sub_53994, _27860, 1);
                DeRef(_0);
                _27860 = NOVALUE;

                /** 						shift:replace_code( repeat( NOP1, length(code) ), ix + offset, ix + offset + size )*/
                if (IS_SEQUENCE(_code_54022)){
                        _27862 = SEQ_PTR(_code_54022)->length;
                }
                else {
                    _27862 = 1;
                }
                _27863 = Repeat(159, _27862);
                _27862 = NOVALUE;
                _27864 = _ix_54006 + _offset_54034;
                if ((long)((unsigned long)_27864 + (unsigned long)HIGH_BITS) >= 0) 
                _27864 = NewDouble((double)_27864);
                _27865 = _ix_54006 + _offset_54034;
                if ((long)((unsigned long)_27865 + (unsigned long)HIGH_BITS) >= 0) 
                _27865 = NewDouble((double)_27865);
                if (IS_ATOM_INT(_27865)) {
                    _27866 = _27865 + _size_54048;
                    if ((long)((unsigned long)_27866 + (unsigned long)HIGH_BITS) >= 0) 
                    _27866 = NewDouble((double)_27866);
                }
                else {
                    _27866 = NewDouble(DBL_PTR(_27865)->dbl + (double)_size_54048);
                }
                DeRef(_27865);
                _27865 = NOVALUE;
                _65replace_code(_27863, _27864, _27866);
                _27863 = NOVALUE;
                _27864 = NOVALUE;
                _27866 = NOVALUE;

                /** 						Code = eu:replace( Code, code, ix + offset, ix + offset + length( code ) -1 )*/
                _27867 = _ix_54006 + _offset_54034;
                if ((long)((unsigned long)_27867 + (unsigned long)HIGH_BITS) >= 0) 
                _27867 = NewDouble((double)_27867);
                _27868 = _ix_54006 + _offset_54034;
                if ((long)((unsigned long)_27868 + (unsigned long)HIGH_BITS) >= 0) 
                _27868 = NewDouble((double)_27868);
                if (IS_SEQUENCE(_code_54022)){
                        _27869 = SEQ_PTR(_code_54022)->length;
                }
                else {
                    _27869 = 1;
                }
                if (IS_ATOM_INT(_27868)) {
                    _27870 = _27868 + _27869;
                    if ((long)((unsigned long)_27870 + (unsigned long)HIGH_BITS) >= 0) 
                    _27870 = NewDouble((double)_27870);
                }
                else {
                    _27870 = NewDouble(DBL_PTR(_27868)->dbl + (double)_27869);
                }
                DeRef(_27868);
                _27868 = NOVALUE;
                _27869 = NOVALUE;
                if (IS_ATOM_INT(_27870)) {
                    _27871 = _27870 - 1;
                    if ((long)((unsigned long)_27871 +(unsigned long) HIGH_BITS) >= 0){
                        _27871 = NewDouble((double)_27871);
                    }
                }
                else {
                    _27871 = NewDouble(DBL_PTR(_27870)->dbl - (double)1);
                }
                DeRef(_27870);
                _27870 = NOVALUE;
                {
                    int p1 = _35Code_16332;
                    int p2 = _code_54022;
                    int p3 = _27867;
                    int p4 = _27871;
                    struct replace_block replace_params;
                    replace_params.copy_to   = &p1;
                    replace_params.copy_from = &p2;
                    replace_params.start     = &p3;
                    replace_params.stop      = &p4;
                    replace_params.target    = &_35Code_16332;
                    Replace( &replace_params );
                }
                DeRef(_27867);
                _27867 = NOVALUE;
                DeRef(_27871);
                _27871 = NOVALUE;

                /** 						offset += length(code) - size - 1*/
                if (IS_SEQUENCE(_code_54022)){
                        _27873 = SEQ_PTR(_code_54022)->length;
                }
                else {
                    _27873 = 1;
                }
                _27874 = _27873 - _size_54048;
                if ((long)((unsigned long)_27874 +(unsigned long) HIGH_BITS) >= 0){
                    _27874 = NewDouble((double)_27874);
                }
                _27873 = NOVALUE;
                if (IS_ATOM_INT(_27874)) {
                    _27875 = _27874 - 1;
                    if ((long)((unsigned long)_27875 +(unsigned long) HIGH_BITS) >= 0){
                        _27875 = NewDouble((double)_27875);
                    }
                }
                else {
                    _27875 = NewDouble(DBL_PTR(_27874)->dbl - (double)1);
                }
                DeRef(_27874);
                _27874 = NOVALUE;
                if (IS_ATOM_INT(_27875)) {
                    _offset_54034 = _offset_54034 + _27875;
                }
                else {
                    _offset_54034 = NewDouble((double)_offset_54034 + DBL_PTR(_27875)->dbl);
                }
                DeRef(_27875);
                _27875 = NOVALUE;
                if (!IS_ATOM_INT(_offset_54034)) {
                    _1 = (long)(DBL_PTR(_offset_54034)->dbl);
                    DeRefDS(_offset_54034);
                    _offset_54034 = _1;
                }
LA: 
                DeRef(_op_54045);
                _op_54045 = NOVALUE;

                /** 				end for*/
                _o_54036 = _o_54036 + 1;
                goto L8; // [418] 210
L9: 
                ;
            }

            /** 				SymTab[calling_sub][S_CODE] = Code*/
            _2 = (int)SEQ_PTR(_36SymTab_15242);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _36SymTab_15242 = MAKE_SEQ(_2);
            }
            _3 = (int)(_calling_sub_54008 + ((s1_ptr)_2)->base);
            RefDS(_35Code_16332);
            _2 = (int)SEQ_PTR(*(int *)_3);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                *(int *)_3 = MAKE_SEQ(_2);
            }
            if (!IS_ATOM_INT(_35S_CODE_15929))
            _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_CODE_15929)->dbl));
            else
            _2 = (int)(((s1_ptr)_2)->base + _35S_CODE_15929);
            _1 = *(int *)_2;
            *(int *)_2 = _35Code_16332;
            DeRef(_1);
            _27877 = NOVALUE;

            /** 				SymTab[calling_sub][S_LINETAB] = LineTable*/
            _2 = (int)SEQ_PTR(_36SymTab_15242);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _36SymTab_15242 = MAKE_SEQ(_2);
            }
            _3 = (int)(_calling_sub_54008 + ((s1_ptr)_2)->base);
            RefDS(_35LineTable_16333);
            _2 = (int)SEQ_PTR(*(int *)_3);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                *(int *)_3 = MAKE_SEQ(_2);
            }
            if (!IS_ATOM_INT(_35S_LINETAB_15952))
            _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_LINETAB_15952)->dbl));
            else
            _2 = (int)(((s1_ptr)_2)->base + _35S_LINETAB_15952);
            _1 = *(int *)_2;
            *(int *)_2 = _35LineTable_16333;
            DeRef(_1);
            _27879 = NOVALUE;
            DeRef(_code_54022);
            _code_54022 = NOVALUE;
            DeRef(_calls_54023);
            _calls_54023 = NOVALUE;

            /** 			end for*/
            _cx_54003 = _cx_54003 + 1;
            goto L6; // [461] 92
L7: 
            ;
        }
L3: 

        /** 	end for*/
L5: 
        _i_53989 = _i_53989 + 1;
        goto L1; // [471] 20
L2: 
        ;
    }

    /** end procedure*/
    _27824 = NOVALUE;
    _27830 = NOVALUE;
    return;
    ;
}



// 0x26A31C62
