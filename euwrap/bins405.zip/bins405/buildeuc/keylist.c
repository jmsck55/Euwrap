// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int _63find_category(int _tokid_23653)
{
    int _catname_23654 = NOVALUE;
    int _13659 = NOVALUE;
    int _13658 = NOVALUE;
    int _13656 = NOVALUE;
    int _13655 = NOVALUE;
    int _13654 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_tokid_23653)) {
        _1 = (long)(DBL_PTR(_tokid_23653)->dbl);
        DeRefDS(_tokid_23653);
        _tokid_23653 = _1;
    }

    /** 	sequence catname = "reserved word"*/
    RefDS(_13653);
    DeRef(_catname_23654);
    _catname_23654 = _13653;

    /** 	for i = 1 to length(token_category) do*/
    _13654 = 73;
    {
        int _i_23657;
        _i_23657 = 1;
L1: 
        if (_i_23657 > 73){
            goto L2; // [17] 72
        }

        /** 		if token_category[i][1] = tokid then*/
        _2 = (int)SEQ_PTR(_37token_category_15797);
        _13655 = (int)*(((s1_ptr)_2)->base + _i_23657);
        _2 = (int)SEQ_PTR(_13655);
        _13656 = (int)*(((s1_ptr)_2)->base + 1);
        _13655 = NOVALUE;
        if (binary_op_a(NOTEQ, _13656, _tokid_23653)){
            _13656 = NOVALUE;
            goto L3; // [36] 65
        }
        _13656 = NOVALUE;

        /** 			catname = token_catname[token_category[i][2]]*/
        _2 = (int)SEQ_PTR(_37token_category_15797);
        _13658 = (int)*(((s1_ptr)_2)->base + _i_23657);
        _2 = (int)SEQ_PTR(_13658);
        _13659 = (int)*(((s1_ptr)_2)->base + 2);
        _13658 = NOVALUE;
        DeRef(_catname_23654);
        _2 = (int)SEQ_PTR(_37token_catname_15784);
        if (!IS_ATOM_INT(_13659)){
            _catname_23654 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_13659)->dbl));
        }
        else{
            _catname_23654 = (int)*(((s1_ptr)_2)->base + _13659);
        }
        RefDS(_catname_23654);

        /** 			exit*/
        goto L2; // [62] 72
L3: 

        /** 	end for*/
        _i_23657 = _i_23657 + 1;
        goto L1; // [67] 24
L2: 
        ;
    }

    /** 	return catname*/
    _13659 = NOVALUE;
    return _catname_23654;
    ;
}


int _63find_token_text(int _tokid_23672)
{
    int _13668 = NOVALUE;
    int _13666 = NOVALUE;
    int _13665 = NOVALUE;
    int _13663 = NOVALUE;
    int _13662 = NOVALUE;
    int _13661 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_tokid_23672)) {
        _1 = (long)(DBL_PTR(_tokid_23672)->dbl);
        DeRefDS(_tokid_23672);
        _tokid_23672 = _1;
    }

    /** 	for i = 1 to length(keylist) do*/
    if (IS_SEQUENCE(_63keylist_22829)){
            _13661 = SEQ_PTR(_63keylist_22829)->length;
    }
    else {
        _13661 = 1;
    }
    {
        int _i_23674;
        _i_23674 = 1;
L1: 
        if (_i_23674 > _13661){
            goto L2; // [10] 57
        }

        /** 		if keylist[i][3] = tokid then*/
        _2 = (int)SEQ_PTR(_63keylist_22829);
        _13662 = (int)*(((s1_ptr)_2)->base + _i_23674);
        _2 = (int)SEQ_PTR(_13662);
        _13663 = (int)*(((s1_ptr)_2)->base + 3);
        _13662 = NOVALUE;
        if (binary_op_a(NOTEQ, _13663, _tokid_23672)){
            _13663 = NOVALUE;
            goto L3; // [29] 50
        }
        _13663 = NOVALUE;

        /** 			return keylist[i][1]*/
        _2 = (int)SEQ_PTR(_63keylist_22829);
        _13665 = (int)*(((s1_ptr)_2)->base + _i_23674);
        _2 = (int)SEQ_PTR(_13665);
        _13666 = (int)*(((s1_ptr)_2)->base + 1);
        _13665 = NOVALUE;
        Ref(_13666);
        return _13666;
L3: 

        /** 	end for*/
        _i_23674 = _i_23674 + 1;
        goto L1; // [52] 17
L2: 
        ;
    }

    /** 	return LexName(tokid, "unknown word")*/
    RefDS(_13667);
    _13668 = _41LexName(_tokid_23672, _13667);
    _13666 = NOVALUE;
    return _13668;
    ;
}



// 0x8F7D72AB
