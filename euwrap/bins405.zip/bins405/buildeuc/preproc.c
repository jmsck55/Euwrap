// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int _64is_file_newer(int _f1_23693, int _f2_23694)
{
    int _d1_23695 = NOVALUE;
    int _d2_23698 = NOVALUE;
    int _diff_2__tmp_at33_23707 = NOVALUE;
    int _diff_1__tmp_at33_23706 = NOVALUE;
    int _diff_inlined_diff_at_33_23705 = NOVALUE;
    int _13671 = NOVALUE;
    int _0, _1, _2;
    

    /** 	object d1 = file_timestamp(f1)*/
    RefDS(_f1_23693);
    _0 = _d1_23695;
    _d1_23695 = _17file_timestamp(_f1_23693);
    DeRef(_0);

    /** 	object d2 = file_timestamp(f2)*/
    RefDS(_f2_23694);
    _0 = _d2_23698;
    _d2_23698 = _17file_timestamp(_f2_23694);
    DeRef(_0);

    /** 	if atom(d2) then return 1 end if*/
    _13671 = IS_ATOM(_d2_23698);
    if (_13671 == 0)
    {
        _13671 = NOVALUE;
        goto L1; // [22] 30
    }
    else{
        _13671 = NOVALUE;
    }
    DeRefDS(_f1_23693);
    DeRefDS(_f2_23694);
    DeRef(_d1_23695);
    DeRef(_d2_23698);
    return 1;
L1: 

    /** 	if dt:diff(d1, d2) < 0 then*/

    /** 	return datetimeToSeconds(dt2) - datetimeToSeconds(dt1)*/
    Ref(_d2_23698);
    _0 = _diff_1__tmp_at33_23706;
    _diff_1__tmp_at33_23706 = _18datetimeToSeconds(_d2_23698);
    DeRef(_0);
    Ref(_d1_23695);
    _0 = _diff_2__tmp_at33_23707;
    _diff_2__tmp_at33_23707 = _18datetimeToSeconds(_d1_23695);
    DeRef(_0);
    DeRef(_diff_inlined_diff_at_33_23705);
    if (IS_ATOM_INT(_diff_1__tmp_at33_23706) && IS_ATOM_INT(_diff_2__tmp_at33_23707)) {
        _diff_inlined_diff_at_33_23705 = _diff_1__tmp_at33_23706 - _diff_2__tmp_at33_23707;
        if ((long)((unsigned long)_diff_inlined_diff_at_33_23705 +(unsigned long) HIGH_BITS) >= 0){
            _diff_inlined_diff_at_33_23705 = NewDouble((double)_diff_inlined_diff_at_33_23705);
        }
    }
    else {
        _diff_inlined_diff_at_33_23705 = binary_op(MINUS, _diff_1__tmp_at33_23706, _diff_2__tmp_at33_23707);
    }
    DeRef(_diff_1__tmp_at33_23706);
    _diff_1__tmp_at33_23706 = NOVALUE;
    DeRef(_diff_2__tmp_at33_23707);
    _diff_2__tmp_at33_23707 = NOVALUE;
    if (binary_op_a(GREATEREQ, _diff_inlined_diff_at_33_23705, 0)){
        goto L2; // [49] 60
    }

    /** 		return 1*/
    DeRefDS(_f1_23693);
    DeRefDS(_f2_23694);
    DeRef(_d1_23695);
    DeRef(_d2_23698);
    return 1;
L2: 

    /** 	return 0*/
    DeRefDS(_f1_23693);
    DeRefDS(_f2_23694);
    DeRef(_d1_23695);
    DeRef(_d2_23698);
    return 0;
    ;
}


void _64add_preprocessor(int _file_ext_23711, int _command_23712, int _params_23713)
{
    int _tmp_23716 = NOVALUE;
    int _file_exts_23726 = NOVALUE;
    int _exts_23732 = NOVALUE;
    int _13688 = NOVALUE;
    int _13687 = NOVALUE;
    int _13686 = NOVALUE;
    int _13685 = NOVALUE;
    int _13683 = NOVALUE;
    int _13678 = NOVALUE;
    int _13673 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(command) then*/
    _13673 = 1;
    if (_13673 == 0)
    {
        _13673 = NOVALUE;
        goto L1; // [8] 53
    }
    else{
        _13673 = NOVALUE;
    }

    /** 		sequence tmp = split( file_ext, ":")*/
    RefDS(_file_ext_23711);
    RefDS(_13674);
    _0 = _tmp_23716;
    _tmp_23716 = _23split(_file_ext_23711, _13674, 0, 0);
    DeRef(_0);

    /** 		file_ext = tmp[1]*/
    DeRefDS(_file_ext_23711);
    _2 = (int)SEQ_PTR(_tmp_23716);
    _file_ext_23711 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_file_ext_23711);

    /** 		command = tmp[2]*/
    _2 = (int)SEQ_PTR(_tmp_23716);
    _command_23712 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_command_23712);

    /** 		if length(tmp) >= 3 then*/
    if (IS_SEQUENCE(_tmp_23716)){
            _13678 = SEQ_PTR(_tmp_23716)->length;
    }
    else {
        _13678 = 1;
    }
    if (_13678 < 3)
    goto L2; // [41] 52

    /** 			params = tmp[3]*/
    _2 = (int)SEQ_PTR(_tmp_23716);
    _params_23713 = (int)*(((s1_ptr)_2)->base + 3);
    Ref(_params_23713);
L2: 
L1: 
    DeRef(_tmp_23716);
    _tmp_23716 = NOVALUE;

    /** 	sequence file_exts = split( file_ext, "," )*/
    RefDS(_file_ext_23711);
    RefDS(_13681);
    _0 = _file_exts_23726;
    _file_exts_23726 = _23split(_file_ext_23711, _13681, 0, 0);
    DeRef(_0);

    /** 	if atom(params) then*/
    _13683 = IS_ATOM(_params_23713);
    if (_13683 == 0)
    {
        _13683 = NOVALUE;
        goto L3; // [71] 80
    }
    else{
        _13683 = NOVALUE;
    }

    /** 		params = ""*/
    RefDS(_5);
    DeRef(_params_23713);
    _params_23713 = _5;
L3: 

    /** 	sequence exts = split(file_ext, ",")*/
    RefDS(_file_ext_23711);
    RefDS(_13681);
    _0 = _exts_23732;
    _exts_23732 = _23split(_file_ext_23711, _13681, 0, 0);
    DeRef(_0);

    /** 	for i = 1 to length(exts) do*/
    if (IS_SEQUENCE(_exts_23732)){
            _13685 = SEQ_PTR(_exts_23732)->length;
    }
    else {
        _13685 = 1;
    }
    {
        int _i_23736;
        _i_23736 = 1;
L4: 
        if (_i_23736 > _13685){
            goto L5; // [96] 135
        }

        /** 		preprocessors &= { { exts[i], command, params, -1 } }*/
        _2 = (int)SEQ_PTR(_exts_23732);
        _13686 = (int)*(((s1_ptr)_2)->base + _i_23736);
        _1 = NewS1(4);
        _2 = (int)((s1_ptr)_1)->base;
        Ref(_13686);
        *((int *)(_2+4)) = _13686;
        Ref(_command_23712);
        *((int *)(_2+8)) = _command_23712;
        Ref(_params_23713);
        *((int *)(_2+12)) = _params_23713;
        *((int *)(_2+16)) = -1;
        _13687 = MAKE_SEQ(_1);
        _13686 = NOVALUE;
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = _13687;
        _13688 = MAKE_SEQ(_1);
        _13687 = NOVALUE;
        Concat((object_ptr)&_36preprocessors_15259, _36preprocessors_15259, _13688);
        DeRefDS(_13688);
        _13688 = NOVALUE;

        /** 	end for*/
        _i_23736 = _i_23736 + 1;
        goto L4; // [130] 103
L5: 
        ;
    }

    /** end procedure */
    DeRefDS(_file_ext_23711);
    DeRef(_command_23712);
    DeRef(_params_23713);
    DeRef(_file_exts_23726);
    DeRef(_exts_23732);
    return;
    ;
}


int _64maybe_preprocess(int _fname_23745)
{
    int _pp_23746 = NOVALUE;
    int _pp_id_23747 = NOVALUE;
    int _fext_23751 = NOVALUE;
    int _post_fname_23768 = NOVALUE;
    int _rid_23796 = NOVALUE;
    int _dll_id_23800 = NOVALUE;
    int _public_cmd_args_23836 = NOVALUE;
    int _cmd_args_23839 = NOVALUE;
    int _cmd_23868 = NOVALUE;
    int _pcmd_23873 = NOVALUE;
    int _result_23878 = NOVALUE;
    int _13767 = NOVALUE;
    int _13766 = NOVALUE;
    int _13761 = NOVALUE;
    int _13760 = NOVALUE;
    int _13758 = NOVALUE;
    int _13757 = NOVALUE;
    int _13755 = NOVALUE;
    int _13753 = NOVALUE;
    int _13752 = NOVALUE;
    int _13750 = NOVALUE;
    int _13747 = NOVALUE;
    int _13745 = NOVALUE;
    int _13743 = NOVALUE;
    int _13741 = NOVALUE;
    int _13740 = NOVALUE;
    int _13738 = NOVALUE;
    int _13737 = NOVALUE;
    int _13735 = NOVALUE;
    int _13732 = NOVALUE;
    int _13731 = NOVALUE;
    int _13730 = NOVALUE;
    int _13728 = NOVALUE;
    int _13724 = NOVALUE;
    int _13722 = NOVALUE;
    int _13721 = NOVALUE;
    int _13720 = NOVALUE;
    int _13716 = NOVALUE;
    int _13713 = NOVALUE;
    int _13712 = NOVALUE;
    int _13711 = NOVALUE;
    int _13709 = NOVALUE;
    int _13706 = NOVALUE;
    int _13704 = NOVALUE;
    int _13703 = NOVALUE;
    int _13701 = NOVALUE;
    int _13699 = NOVALUE;
    int _13697 = NOVALUE;
    int _13695 = NOVALUE;
    int _13694 = NOVALUE;
    int _13693 = NOVALUE;
    int _13692 = NOVALUE;
    int _13690 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	sequence pp = {}*/
    RefDS(_5);
    DeRef(_pp_23746);
    _pp_23746 = _5;

    /** 	if length(preprocessors) then*/
    if (IS_SEQUENCE(_36preprocessors_15259)){
            _13690 = SEQ_PTR(_36preprocessors_15259)->length;
    }
    else {
        _13690 = 1;
    }
    if (_13690 == 0)
    {
        _13690 = NOVALUE;
        goto L1; // [17] 89
    }
    else{
        _13690 = NOVALUE;
    }

    /** 		sequence fext = fileext(fname)*/
    RefDS(_fname_23745);
    _0 = _fext_23751;
    _fext_23751 = _17fileext(_fname_23745);
    DeRef(_0);

    /** 		for i = 1 to length(preprocessors) do*/
    if (IS_SEQUENCE(_36preprocessors_15259)){
            _13692 = SEQ_PTR(_36preprocessors_15259)->length;
    }
    else {
        _13692 = 1;
    }
    {
        int _i_23755;
        _i_23755 = 1;
L2: 
        if (_i_23755 > _13692){
            goto L3; // [35] 88
        }

        /** 			if equal(fext, preprocessors[i][1]) then*/
        _2 = (int)SEQ_PTR(_36preprocessors_15259);
        _13693 = (int)*(((s1_ptr)_2)->base + _i_23755);
        _2 = (int)SEQ_PTR(_13693);
        _13694 = (int)*(((s1_ptr)_2)->base + 1);
        _13693 = NOVALUE;
        if (_fext_23751 == _13694)
        _13695 = 1;
        else if (IS_ATOM_INT(_fext_23751) && IS_ATOM_INT(_13694))
        _13695 = 0;
        else
        _13695 = (compare(_fext_23751, _13694) == 0);
        _13694 = NOVALUE;
        if (_13695 == 0)
        {
            _13695 = NOVALUE;
            goto L4; // [58] 81
        }
        else{
            _13695 = NOVALUE;
        }

        /** 				pp_id = i*/
        _pp_id_23747 = _i_23755;

        /** 				pp = preprocessors[pp_id]*/
        DeRef(_pp_23746);
        _2 = (int)SEQ_PTR(_36preprocessors_15259);
        _pp_23746 = (int)*(((s1_ptr)_2)->base + _pp_id_23747);
        RefDS(_pp_23746);

        /** 				exit*/
        goto L3; // [78] 88
L4: 

        /** 		end for*/
        _i_23755 = _i_23755 + 1;
        goto L2; // [83] 42
L3: 
        ;
    }
L1: 
    DeRef(_fext_23751);
    _fext_23751 = NOVALUE;

    /** 	if length(pp) = 0 then */
    if (IS_SEQUENCE(_pp_23746)){
            _13697 = SEQ_PTR(_pp_23746)->length;
    }
    else {
        _13697 = 1;
    }
    if (_13697 != 0)
    goto L5; // [96] 107

    /** 		return fname*/
    DeRefDS(_pp_23746);
    DeRef(_post_fname_23768);
    return _fname_23745;
L5: 

    /** 	sequence post_fname = filebase(fname) & ".pp." & fileext(fname)*/
    RefDS(_fname_23745);
    _13699 = _17filebase(_fname_23745);
    RefDS(_fname_23745);
    _13701 = _17fileext(_fname_23745);
    {
        int concat_list[3];

        concat_list[0] = _13701;
        concat_list[1] = _13700;
        concat_list[2] = _13699;
        Concat_N((object_ptr)&_post_fname_23768, concat_list, 3);
    }
    DeRef(_13701);
    _13701 = NOVALUE;
    DeRef(_13699);
    _13699 = NOVALUE;

    /** 	if length(dirname(fname)) > 0 then*/
    RefDS(_fname_23745);
    _13703 = _17dirname(_fname_23745, 0);
    if (IS_SEQUENCE(_13703)){
            _13704 = SEQ_PTR(_13703)->length;
    }
    else {
        _13704 = 1;
    }
    DeRef(_13703);
    _13703 = NOVALUE;
    if (_13704 <= 0)
    goto L6; // [133] 153

    /** 		post_fname = dirname(fname) & SLASH & post_fname*/
    RefDS(_fname_23745);
    _13706 = _17dirname(_fname_23745, 0);
    {
        int concat_list[3];

        concat_list[0] = _post_fname_23768;
        concat_list[1] = 92;
        concat_list[2] = _13706;
        Concat_N((object_ptr)&_post_fname_23768, concat_list, 3);
    }
    DeRef(_13706);
    _13706 = NOVALUE;
L6: 

    /** 	if not force_preprocessor then*/
    if (_36force_preprocessor_15260 != 0)
    goto L7; // [157] 178

    /** 		if not is_file_newer(fname, post_fname) then*/
    RefDS(_fname_23745);
    RefDS(_post_fname_23768);
    _13709 = _64is_file_newer(_fname_23745, _post_fname_23768);
    if (IS_ATOM_INT(_13709)) {
        if (_13709 != 0){
            DeRef(_13709);
            _13709 = NOVALUE;
            goto L8; // [167] 177
        }
    }
    else {
        if (DBL_PTR(_13709)->dbl != 0.0){
            DeRef(_13709);
            _13709 = NOVALUE;
            goto L8; // [167] 177
        }
    }
    DeRef(_13709);
    _13709 = NOVALUE;

    /** 			return post_fname*/
    DeRefDS(_fname_23745);
    DeRef(_pp_23746);
    _13703 = NOVALUE;
    return _post_fname_23768;
L8: 
L7: 

    /** 	if equal(fileext(pp[PP_COMMAND]), SHARED_LIB_EXT) then*/
    _2 = (int)SEQ_PTR(_pp_23746);
    _13711 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_13711);
    _13712 = _17fileext(_13711);
    _13711 = NOVALUE;
    if (_13712 == _17SHARED_LIB_EXT_5983)
    _13713 = 1;
    else if (IS_ATOM_INT(_13712) && IS_ATOM_INT(_17SHARED_LIB_EXT_5983))
    _13713 = 0;
    else
    _13713 = (compare(_13712, _17SHARED_LIB_EXT_5983) == 0);
    DeRef(_13712);
    _13712 = NOVALUE;
    if (_13713 == 0)
    {
        _13713 = NOVALUE;
        goto L9; // [194] 348
    }
    else{
        _13713 = NOVALUE;
    }

    /** 		integer rid = pp[PP_RID]*/
    _2 = (int)SEQ_PTR(_pp_23746);
    _rid_23796 = (int)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_rid_23796))
    _rid_23796 = (long)DBL_PTR(_rid_23796)->dbl;

    /** 		if rid = -1 then*/
    if (_rid_23796 != -1)
    goto LA; // [205] 307

    /** 			integer dll_id = open_dll(pp[PP_COMMAND])*/
    _2 = (int)SEQ_PTR(_pp_23746);
    _13716 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_13716);
    _dll_id_23800 = _12open_dll(_13716);
    _13716 = NOVALUE;
    if (!IS_ATOM_INT(_dll_id_23800)) {
        _1 = (long)(DBL_PTR(_dll_id_23800)->dbl);
        DeRefDS(_dll_id_23800);
        _dll_id_23800 = _1;
    }

    /** 			if dll_id = -1 then*/
    if (_dll_id_23800 != -1)
    goto LB; // [223] 247

    /** 				CompileErr(sprintf("Preprocessor shared library '%s' could not be loaded\n",*/
    _2 = (int)SEQ_PTR(_pp_23746);
    _13720 = (int)*(((s1_ptr)_2)->base + 2);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_13720);
    *((int *)(_2+4)) = _13720;
    _13721 = MAKE_SEQ(_1);
    _13720 = NOVALUE;
    _13722 = EPrintf(-9999999, _13719, _13721);
    DeRefDS(_13721);
    _13721 = NOVALUE;
    RefDS(_22023);
    _44CompileErr(_13722, _22023, 1);
    _13722 = NOVALUE;
LB: 

    /** 			rid = define_c_func(dll_id, "preprocess", { E_SEQUENCE, E_SEQUENCE, E_SEQUENCE }, */
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 134217732;
    *((int *)(_2+8)) = 134217732;
    *((int *)(_2+12)) = 134217732;
    _13724 = MAKE_SEQ(_1);
    RefDS(_13723);
    _rid_23796 = _12define_c_func(_dll_id_23800, _13723, _13724, 100663300);
    _13724 = NOVALUE;
    if (!IS_ATOM_INT(_rid_23796)) {
        _1 = (long)(DBL_PTR(_rid_23796)->dbl);
        DeRefDS(_rid_23796);
        _rid_23796 = _1;
    }

    /** 			if rid = -1 then*/
    if (_rid_23796 != -1)
    goto LC; // [274] 291

    /** 				CompileErr("Preprocessor entry point cound not be found\n",,1)*/
    RefDS(_13727);
    RefDS(_22023);
    _44CompileErr(_13727, _22023, 1);

    /** 				Cleanup(1)*/
    _44Cleanup(1);
LC: 

    /** 			preprocessors[pp_id][PP_RID] = rid*/
    _2 = (int)SEQ_PTR(_36preprocessors_15259);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36preprocessors_15259 = MAKE_SEQ(_2);
    }
    _3 = (int)(_pp_id_23747 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = _rid_23796;
    DeRef(_1);
    _13728 = NOVALUE;
LA: 

    /** 		if c_func(rid, { fname, post_fname, pp[PP_PARAMS] }) != 0 then*/
    _2 = (int)SEQ_PTR(_pp_23746);
    _13730 = (int)*(((s1_ptr)_2)->base + 3);
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_fname_23745);
    *((int *)(_2+4)) = _fname_23745;
    RefDS(_post_fname_23768);
    *((int *)(_2+8)) = _post_fname_23768;
    Ref(_13730);
    *((int *)(_2+12)) = _13730;
    _13731 = MAKE_SEQ(_1);
    _13730 = NOVALUE;
    _13732 = call_c(1, _rid_23796, _13731);
    DeRefDS(_13731);
    _13731 = NOVALUE;
    if (binary_op_a(EQUALS, _13732, 0)){
        DeRef(_13732);
        _13732 = NOVALUE;
        goto LD; // [326] 343
    }
    DeRef(_13732);
    _13732 = NOVALUE;

    /** 			CompileErr("Preprocessor call failed\n",,1)*/
    RefDS(_13734);
    RefDS(_22023);
    _44CompileErr(_13734, _22023, 1);

    /** 			Cleanup(1)*/
    _44Cleanup(1);
LD: 
    goto LE; // [345] 520
L9: 

    /** 		sequence public_cmd_args = {pp[PP_COMMAND]}*/
    _2 = (int)SEQ_PTR(_pp_23746);
    _13735 = (int)*(((s1_ptr)_2)->base + 2);
    _0 = _public_cmd_args_23836;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_13735);
    *((int *)(_2+4)) = _13735;
    _public_cmd_args_23836 = MAKE_SEQ(_1);
    DeRef(_0);
    _13735 = NOVALUE;

    /** 		sequence cmd_args = {canonical_path(pp[PP_COMMAND],,TO_SHORT)}*/
    _2 = (int)SEQ_PTR(_pp_23746);
    _13737 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_13737);
    _13738 = _17canonical_path(_13737, 0, 4);
    _13737 = NOVALUE;
    _0 = _cmd_args_23839;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _13738;
    _cmd_args_23839 = MAKE_SEQ(_1);
    DeRef(_0);
    _13738 = NOVALUE;

    /** 		if equal(fileext(pp[PP_COMMAND]), "ex") then*/
    _2 = (int)SEQ_PTR(_pp_23746);
    _13740 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_13740);
    _13741 = _17fileext(_13740);
    _13740 = NOVALUE;
    if (_13741 == _13742)
    _13743 = 1;
    else if (IS_ATOM_INT(_13741) && IS_ATOM_INT(_13742))
    _13743 = 0;
    else
    _13743 = (compare(_13741, _13742) == 0);
    DeRef(_13741);
    _13741 = NOVALUE;
    if (_13743 == 0)
    {
        _13743 = NOVALUE;
        goto LF; // [390] 414
    }
    else{
        _13743 = NOVALUE;
    }

    /** 			public_cmd_args = { "eui" } & public_cmd_args*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_13744);
    *((int *)(_2+4)) = _13744;
    _13745 = MAKE_SEQ(_1);
    Concat((object_ptr)&_public_cmd_args_23836, _13745, _public_cmd_args_23836);
    DeRefDS(_13745);
    _13745 = NOVALUE;
    DeRef(_13745);
    _13745 = NOVALUE;

    /** 			cmd_args = { "eui" } & cmd_args*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_13744);
    *((int *)(_2+4)) = _13744;
    _13747 = MAKE_SEQ(_1);
    Concat((object_ptr)&_cmd_args_23839, _13747, _cmd_args_23839);
    DeRefDS(_13747);
    _13747 = NOVALUE;
    DeRef(_13747);
    _13747 = NOVALUE;
LF: 

    /** 		cmd_args &= { "-i", canonical_path(fname,,TO_SHORT), "-o", canonical_path(post_fname,,TO_SHORT) }*/
    RefDS(_fname_23745);
    _13750 = _17canonical_path(_fname_23745, 0, 4);
    RefDS(_post_fname_23768);
    _13752 = _17canonical_path(_post_fname_23768, 0, 4);
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_13749);
    *((int *)(_2+4)) = _13749;
    *((int *)(_2+8)) = _13750;
    RefDS(_13751);
    *((int *)(_2+12)) = _13751;
    *((int *)(_2+16)) = _13752;
    _13753 = MAKE_SEQ(_1);
    _13752 = NOVALUE;
    _13750 = NOVALUE;
    Concat((object_ptr)&_cmd_args_23839, _cmd_args_23839, _13753);
    DeRefDS(_13753);
    _13753 = NOVALUE;

    /** 		public_cmd_args &= { "-i", fname, "-o", post_fname }*/
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_13749);
    *((int *)(_2+4)) = _13749;
    RefDS(_fname_23745);
    *((int *)(_2+8)) = _fname_23745;
    RefDS(_13751);
    *((int *)(_2+12)) = _13751;
    RefDS(_post_fname_23768);
    *((int *)(_2+16)) = _post_fname_23768;
    _13755 = MAKE_SEQ(_1);
    Concat((object_ptr)&_public_cmd_args_23836, _public_cmd_args_23836, _13755);
    DeRefDS(_13755);
    _13755 = NOVALUE;

    /** 		sequence cmd = build_commandline( cmd_args ) & pp[PP_PARAMS]*/
    RefDS(_cmd_args_23839);
    _13757 = _4build_commandline(_cmd_args_23839);
    _2 = (int)SEQ_PTR(_pp_23746);
    _13758 = (int)*(((s1_ptr)_2)->base + 3);
    if (IS_SEQUENCE(_13757) && IS_ATOM(_13758)) {
        Ref(_13758);
        Append(&_cmd_23868, _13757, _13758);
    }
    else if (IS_ATOM(_13757) && IS_SEQUENCE(_13758)) {
        Ref(_13757);
        Prepend(&_cmd_23868, _13758, _13757);
    }
    else {
        Concat((object_ptr)&_cmd_23868, _13757, _13758);
        DeRef(_13757);
        _13757 = NOVALUE;
    }
    DeRef(_13757);
    _13757 = NOVALUE;
    _13758 = NOVALUE;

    /** 		sequence pcmd = build_commandline(public_cmd_args) & pp[PP_PARAMS]*/
    RefDS(_public_cmd_args_23836);
    _13760 = _4build_commandline(_public_cmd_args_23836);
    _2 = (int)SEQ_PTR(_pp_23746);
    _13761 = (int)*(((s1_ptr)_2)->base + 3);
    if (IS_SEQUENCE(_13760) && IS_ATOM(_13761)) {
        Ref(_13761);
        Append(&_pcmd_23873, _13760, _13761);
    }
    else if (IS_ATOM(_13760) && IS_SEQUENCE(_13761)) {
        Ref(_13760);
        Prepend(&_pcmd_23873, _13761, _13760);
    }
    else {
        Concat((object_ptr)&_pcmd_23873, _13760, _13761);
        DeRef(_13760);
        _13760 = NOVALUE;
    }
    DeRef(_13760);
    _13760 = NOVALUE;
    _13761 = NOVALUE;

    /** 		integer result = system_exec(cmd, 2)*/
    _result_23878 = system_exec_call(_cmd_23868, 2);

    /** 		if result != 0 then*/
    if (_result_23878 == 0)
    goto L10; // [492] 517

    /** 			CompileErr(sprintf("Preprocessor command failed (%d): %s\n", { result, pcmd } ),,1)*/
    RefDS(_pcmd_23873);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _result_23878;
    ((int *)_2)[2] = _pcmd_23873;
    _13766 = MAKE_SEQ(_1);
    _13767 = EPrintf(-9999999, _13765, _13766);
    DeRefDS(_13766);
    _13766 = NOVALUE;
    RefDS(_22023);
    _44CompileErr(_13767, _22023, 1);
    _13767 = NOVALUE;

    /** 			Cleanup(1)*/
    _44Cleanup(1);
L10: 
    DeRef(_public_cmd_args_23836);
    _public_cmd_args_23836 = NOVALUE;
    DeRef(_cmd_args_23839);
    _cmd_args_23839 = NOVALUE;
    DeRef(_cmd_23868);
    _cmd_23868 = NOVALUE;
    DeRef(_pcmd_23873);
    _pcmd_23873 = NOVALUE;
LE: 

    /** 	return post_fname*/
    DeRefDS(_fname_23745);
    DeRef(_pp_23746);
    _13703 = NOVALUE;
    return _post_fname_23768;
    ;
}



// 0x4DE7462E
