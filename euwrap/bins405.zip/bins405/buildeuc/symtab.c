// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int _53hashfn(int _name_46106)
{
    int _len_46107 = NOVALUE;
    int _val_46108 = NOVALUE;
    int _int_46109 = NOVALUE;
    int _24387 = NOVALUE;
    int _24386 = NOVALUE;
    int _24383 = NOVALUE;
    int _24382 = NOVALUE;
    int _24371 = NOVALUE;
    int _24367 = NOVALUE;
    int _0, _1, _2;
    

    /** 	len = length(name)*/
    if (IS_SEQUENCE(_name_46106)){
            _len_46107 = SEQ_PTR(_name_46106)->length;
    }
    else {
        _len_46107 = 1;
    }

    /** 	val = name[1]*/
    _2 = (int)SEQ_PTR(_name_46106);
    _val_46108 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_val_46108))
    _val_46108 = (long)DBL_PTR(_val_46108)->dbl;

    /** 	int = name[$]*/
    if (IS_SEQUENCE(_name_46106)){
            _24367 = SEQ_PTR(_name_46106)->length;
    }
    else {
        _24367 = 1;
    }
    _2 = (int)SEQ_PTR(_name_46106);
    _int_46109 = (int)*(((s1_ptr)_2)->base + _24367);
    if (!IS_ATOM_INT(_int_46109))
    _int_46109 = (long)DBL_PTR(_int_46109)->dbl;

    /** 	int *= 256*/
    _int_46109 = _int_46109 * 256;

    /** 	val *= 2*/
    _val_46108 = _val_46108 + _val_46108;

    /** 	val += int + len*/
    _24371 = _int_46109 + _len_46107;
    if ((long)((unsigned long)_24371 + (unsigned long)HIGH_BITS) >= 0) 
    _24371 = NewDouble((double)_24371);
    if (IS_ATOM_INT(_24371)) {
        _val_46108 = _val_46108 + _24371;
    }
    else {
        _val_46108 = NewDouble((double)_val_46108 + DBL_PTR(_24371)->dbl);
    }
    DeRef(_24371);
    _24371 = NOVALUE;
    if (!IS_ATOM_INT(_val_46108)) {
        _1 = (long)(DBL_PTR(_val_46108)->dbl);
        DeRefDS(_val_46108);
        _val_46108 = _1;
    }

    /** 	if len = 3 then*/
    if (_len_46107 != 3)
    goto L1; // [51] 78

    /** 		val *= 32*/
    _val_46108 = _val_46108 * 32;

    /** 		int = name[2]*/
    _2 = (int)SEQ_PTR(_name_46106);
    _int_46109 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_int_46109))
    _int_46109 = (long)DBL_PTR(_int_46109)->dbl;

    /** 		val += int*/
    _val_46108 = _val_46108 + _int_46109;
    goto L2; // [75] 133
L1: 

    /** 	elsif len > 3 then*/
    if (_len_46107 <= 3)
    goto L3; // [80] 132

    /** 		val *= 32*/
    _val_46108 = _val_46108 * 32;

    /** 		int = name[2]*/
    _2 = (int)SEQ_PTR(_name_46106);
    _int_46109 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_int_46109))
    _int_46109 = (long)DBL_PTR(_int_46109)->dbl;

    /** 		val += int*/
    _val_46108 = _val_46108 + _int_46109;

    /** 		val *= 32*/
    _val_46108 = _val_46108 * 32;

    /** 		int = name[$-1]*/
    if (IS_SEQUENCE(_name_46106)){
            _24382 = SEQ_PTR(_name_46106)->length;
    }
    else {
        _24382 = 1;
    }
    _24383 = _24382 - 1;
    _24382 = NOVALUE;
    _2 = (int)SEQ_PTR(_name_46106);
    _int_46109 = (int)*(((s1_ptr)_2)->base + _24383);
    if (!IS_ATOM_INT(_int_46109))
    _int_46109 = (long)DBL_PTR(_int_46109)->dbl;

    /** 		val += int*/
    _val_46108 = _val_46108 + _int_46109;
L3: 
L2: 

    /** 	return remainder(val, NBUCKETS) + 1*/
    _24386 = (_val_46108 % 2003);
    _24387 = _24386 + 1;
    _24386 = NOVALUE;
    DeRefDS(_name_46106);
    DeRef(_24383);
    _24383 = NOVALUE;
    return _24387;
    ;
}


void _53remove_symbol(int _sym_46138)
{
    int _hash_46139 = NOVALUE;
    int _st_ptr_46140 = NOVALUE;
    int _24402 = NOVALUE;
    int _24401 = NOVALUE;
    int _24399 = NOVALUE;
    int _24398 = NOVALUE;
    int _24397 = NOVALUE;
    int _24395 = NOVALUE;
    int _24393 = NOVALUE;
    int _24392 = NOVALUE;
    int _24391 = NOVALUE;
    int _24388 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_sym_46138)) {
        _1 = (long)(DBL_PTR(_sym_46138)->dbl);
        DeRefDS(_sym_46138);
        _sym_46138 = _1;
    }

    /** 	hash = SymTab[sym][S_HASHVAL]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _24388 = (int)*(((s1_ptr)_2)->base + _sym_46138);
    _2 = (int)SEQ_PTR(_24388);
    _hash_46139 = (int)*(((s1_ptr)_2)->base + 11);
    if (!IS_ATOM_INT(_hash_46139)){
        _hash_46139 = (long)DBL_PTR(_hash_46139)->dbl;
    }
    _24388 = NOVALUE;

    /** 	st_ptr = buckets[hash]*/
    _2 = (int)SEQ_PTR(_53buckets_46087);
    _st_ptr_46140 = (int)*(((s1_ptr)_2)->base + _hash_46139);
    if (!IS_ATOM_INT(_st_ptr_46140))
    _st_ptr_46140 = (long)DBL_PTR(_st_ptr_46140)->dbl;

    /** 	while st_ptr and st_ptr != sym do*/
L1: 
    if (_st_ptr_46140 == 0) {
        goto L2; // [32] 65
    }
    _24392 = (_st_ptr_46140 != _sym_46138);
    if (_24392 == 0)
    {
        DeRef(_24392);
        _24392 = NOVALUE;
        goto L2; // [41] 65
    }
    else{
        DeRef(_24392);
        _24392 = NOVALUE;
    }

    /** 		st_ptr = SymTab[st_ptr][S_SAMEHASH]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _24393 = (int)*(((s1_ptr)_2)->base + _st_ptr_46140);
    _2 = (int)SEQ_PTR(_24393);
    _st_ptr_46140 = (int)*(((s1_ptr)_2)->base + 9);
    if (!IS_ATOM_INT(_st_ptr_46140)){
        _st_ptr_46140 = (long)DBL_PTR(_st_ptr_46140)->dbl;
    }
    _24393 = NOVALUE;

    /** 	end while*/
    goto L1; // [62] 32
L2: 

    /** 	if st_ptr then*/
    if (_st_ptr_46140 == 0)
    {
        goto L3; // [67] 134
    }
    else{
    }

    /** 		if st_ptr = buckets[hash] then*/
    _2 = (int)SEQ_PTR(_53buckets_46087);
    _24395 = (int)*(((s1_ptr)_2)->base + _hash_46139);
    if (binary_op_a(NOTEQ, _st_ptr_46140, _24395)){
        _24395 = NOVALUE;
        goto L4; // [78] 105
    }
    _24395 = NOVALUE;

    /** 			buckets[hash] = SymTab[st_ptr][S_SAMEHASH]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _24397 = (int)*(((s1_ptr)_2)->base + _st_ptr_46140);
    _2 = (int)SEQ_PTR(_24397);
    _24398 = (int)*(((s1_ptr)_2)->base + 9);
    _24397 = NOVALUE;
    Ref(_24398);
    _2 = (int)SEQ_PTR(_53buckets_46087);
    _2 = (int)(((s1_ptr)_2)->base + _hash_46139);
    _1 = *(int *)_2;
    *(int *)_2 = _24398;
    if( _1 != _24398 ){
        DeRef(_1);
    }
    _24398 = NOVALUE;
    goto L5; // [102] 133
L4: 

    /** 			SymTab[st_ptr][S_SAMEHASH] = SymTab[sym][S_SAMEHASH]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_st_ptr_46140 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _24401 = (int)*(((s1_ptr)_2)->base + _sym_46138);
    _2 = (int)SEQ_PTR(_24401);
    _24402 = (int)*(((s1_ptr)_2)->base + 9);
    _24401 = NOVALUE;
    Ref(_24402);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 9);
    _1 = *(int *)_2;
    *(int *)_2 = _24402;
    if( _1 != _24402 ){
        DeRef(_1);
    }
    _24402 = NOVALUE;
    _24399 = NOVALUE;
L5: 
L3: 

    /** end procedure*/
    return;
    ;
}


int _53NewBasicEntry(int _name_46172, int _varnum_46173, int _scope_46174, int _token_46175, int _hashval_46176, int _samehash_46178, int _type_sym_46180)
{
    int _new_46181 = NOVALUE;
    int _24411 = NOVALUE;
    int _24409 = NOVALUE;
    int _24408 = NOVALUE;
    int _24407 = NOVALUE;
    int _24406 = NOVALUE;
    int _24405 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_varnum_46173)) {
        _1 = (long)(DBL_PTR(_varnum_46173)->dbl);
        DeRefDS(_varnum_46173);
        _varnum_46173 = _1;
    }
    if (!IS_ATOM_INT(_scope_46174)) {
        _1 = (long)(DBL_PTR(_scope_46174)->dbl);
        DeRefDS(_scope_46174);
        _scope_46174 = _1;
    }
    if (!IS_ATOM_INT(_token_46175)) {
        _1 = (long)(DBL_PTR(_token_46175)->dbl);
        DeRefDS(_token_46175);
        _token_46175 = _1;
    }
    if (!IS_ATOM_INT(_hashval_46176)) {
        _1 = (long)(DBL_PTR(_hashval_46176)->dbl);
        DeRefDS(_hashval_46176);
        _hashval_46176 = _1;
    }
    if (!IS_ATOM_INT(_samehash_46178)) {
        _1 = (long)(DBL_PTR(_samehash_46178)->dbl);
        DeRefDS(_samehash_46178);
        _samehash_46178 = _1;
    }
    if (!IS_ATOM_INT(_type_sym_46180)) {
        _1 = (long)(DBL_PTR(_type_sym_46180)->dbl);
        DeRefDS(_type_sym_46180);
        _type_sym_46180 = _1;
    }

    /** 	if TRANSLATE then*/
    if (_35TRANSLATE_15887 == 0)
    {
        goto L1; // [19] 33
    }
    else{
    }

    /** 		new = repeat(0, SIZEOF_ROUTINE_ENTRY)*/
    DeRef(_new_46181);
    _new_46181 = Repeat(0, _35SIZEOF_ROUTINE_ENTRY_16043);
    goto L2; // [30] 42
L1: 

    /** 		new = repeat(0, SIZEOF_VAR_ENTRY)*/
    DeRef(_new_46181);
    _new_46181 = Repeat(0, _35SIZEOF_VAR_ENTRY_16046);
L2: 

    /** 	new[S_NEXT] = 0*/
    _2 = (int)SEQ_PTR(_new_46181);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_46181 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 	new[S_NAME] = name*/
    RefDS(_name_46172);
    _2 = (int)SEQ_PTR(_new_46181);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_46181 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35S_NAME_15917))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15917)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _35S_NAME_15917);
    _1 = *(int *)_2;
    *(int *)_2 = _name_46172;
    DeRef(_1);

    /** 	new[S_SCOPE] = scope*/
    _2 = (int)SEQ_PTR(_new_46181);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_46181 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = _scope_46174;
    DeRef(_1);

    /** 	new[S_MODE] = M_NORMAL*/
    _2 = (int)SEQ_PTR(_new_46181);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_46181 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = 1;
    DeRef(_1);

    /** 	new[S_USAGE] = U_UNUSED*/
    _2 = (int)SEQ_PTR(_new_46181);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_46181 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 	new[S_FILE_NO] = current_file_no*/
    _2 = (int)SEQ_PTR(_new_46181);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_46181 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35S_FILE_NO_15913))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FILE_NO_15913)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _35S_FILE_NO_15913);
    _1 = *(int *)_2;
    *(int *)_2 = _35current_file_no_16244;
    DeRef(_1);

    /** 	if TRANSLATE then*/
    if (_35TRANSLATE_15887 == 0)
    {
        goto L3; // [102] 327
    }
    else{
    }

    /** 		new[S_GTYPE] = TYPE_OBJECT*/
    _2 = (int)SEQ_PTR(_new_46181);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_46181 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 36);
    _1 = *(int *)_2;
    *(int *)_2 = 16;
    DeRef(_1);

    /** 		new[S_GTYPE_NEW] = TYPE_NULL*/
    _2 = (int)SEQ_PTR(_new_46181);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_46181 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 38);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 		new[S_SEQ_ELEM] = TYPE_OBJECT*/
    _2 = (int)SEQ_PTR(_new_46181);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_46181 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 33);
    _1 = *(int *)_2;
    *(int *)_2 = 16;
    DeRef(_1);

    /** 		new[S_SEQ_ELEM_NEW] = TYPE_NULL -- starting point for ORing*/
    _2 = (int)SEQ_PTR(_new_46181);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_46181 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 40);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 		new[S_ARG_TYPE] = TYPE_OBJECT*/
    _2 = (int)SEQ_PTR(_new_46181);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_46181 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 43);
    _1 = *(int *)_2;
    *(int *)_2 = 16;
    DeRef(_1);

    /** 		new[S_ARG_TYPE_NEW] = TYPE_NULL*/
    _2 = (int)SEQ_PTR(_new_46181);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_46181 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 44);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 		new[S_ARG_SEQ_ELEM] = TYPE_OBJECT*/
    _2 = (int)SEQ_PTR(_new_46181);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_46181 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 45);
    _1 = *(int *)_2;
    *(int *)_2 = 16;
    DeRef(_1);

    /** 		new[S_ARG_SEQ_ELEM_NEW] = TYPE_NULL*/
    _2 = (int)SEQ_PTR(_new_46181);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_46181 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 46);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 		new[S_ARG_MIN] = NOVALUE*/
    Ref(_35NOVALUE_16099);
    _2 = (int)SEQ_PTR(_new_46181);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_46181 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 47);
    _1 = *(int *)_2;
    *(int *)_2 = _35NOVALUE_16099;
    DeRef(_1);

    /** 		new[S_ARG_MIN_NEW] = -NOVALUE*/
    if (IS_ATOM_INT(_35NOVALUE_16099)) {
        if ((unsigned long)_35NOVALUE_16099 == 0xC0000000)
        _24405 = (int)NewDouble((double)-0xC0000000);
        else
        _24405 = - _35NOVALUE_16099;
    }
    else {
        _24405 = unary_op(UMINUS, _35NOVALUE_16099);
    }
    _2 = (int)SEQ_PTR(_new_46181);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_46181 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 49);
    _1 = *(int *)_2;
    *(int *)_2 = _24405;
    if( _1 != _24405 ){
        DeRef(_1);
    }
    _24405 = NOVALUE;

    /** 		new[S_ARG_SEQ_LEN] = NOVALUE*/
    Ref(_35NOVALUE_16099);
    _2 = (int)SEQ_PTR(_new_46181);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_46181 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 51);
    _1 = *(int *)_2;
    *(int *)_2 = _35NOVALUE_16099;
    DeRef(_1);

    /** 		new[S_ARG_SEQ_LEN_NEW] = -NOVALUE*/
    if (IS_ATOM_INT(_35NOVALUE_16099)) {
        if ((unsigned long)_35NOVALUE_16099 == 0xC0000000)
        _24406 = (int)NewDouble((double)-0xC0000000);
        else
        _24406 = - _35NOVALUE_16099;
    }
    else {
        _24406 = unary_op(UMINUS, _35NOVALUE_16099);
    }
    _2 = (int)SEQ_PTR(_new_46181);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_46181 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 52);
    _1 = *(int *)_2;
    *(int *)_2 = _24406;
    if( _1 != _24406 ){
        DeRef(_1);
    }
    _24406 = NOVALUE;

    /** 		new[S_SEQ_LEN] = NOVALUE*/
    Ref(_35NOVALUE_16099);
    _2 = (int)SEQ_PTR(_new_46181);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_46181 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 32);
    _1 = *(int *)_2;
    *(int *)_2 = _35NOVALUE_16099;
    DeRef(_1);

    /** 		new[S_SEQ_LEN_NEW] = -NOVALUE -- no idea yet*/
    if (IS_ATOM_INT(_35NOVALUE_16099)) {
        if ((unsigned long)_35NOVALUE_16099 == 0xC0000000)
        _24407 = (int)NewDouble((double)-0xC0000000);
        else
        _24407 = - _35NOVALUE_16099;
    }
    else {
        _24407 = unary_op(UMINUS, _35NOVALUE_16099);
    }
    _2 = (int)SEQ_PTR(_new_46181);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_46181 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 39);
    _1 = *(int *)_2;
    *(int *)_2 = _24407;
    if( _1 != _24407 ){
        DeRef(_1);
    }
    _24407 = NOVALUE;

    /** 		new[S_NREFS] = 0*/
    _2 = (int)SEQ_PTR(_new_46181);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_46181 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 12);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 		new[S_ONE_REF] = TRUE          -- assume TRUE until we find otherwise*/
    _2 = (int)SEQ_PTR(_new_46181);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_46181 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 35);
    _1 = *(int *)_2;
    *(int *)_2 = _13TRUE_436;
    DeRef(_1);

    /** 		new[S_RI_TARGET] = 0*/
    _2 = (int)SEQ_PTR(_new_46181);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_46181 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 53);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 		new[S_OBJ_MIN] = MININT*/
    _2 = (int)SEQ_PTR(_new_46181);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_46181 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 30);
    _1 = *(int *)_2;
    *(int *)_2 = -1073741824;
    DeRef(_1);

    /** 		new[S_OBJ_MIN_NEW] = -NOVALUE -- no idea yet*/
    if (IS_ATOM_INT(_35NOVALUE_16099)) {
        if ((unsigned long)_35NOVALUE_16099 == 0xC0000000)
        _24408 = (int)NewDouble((double)-0xC0000000);
        else
        _24408 = - _35NOVALUE_16099;
    }
    else {
        _24408 = unary_op(UMINUS, _35NOVALUE_16099);
    }
    _2 = (int)SEQ_PTR(_new_46181);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_46181 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 41);
    _1 = *(int *)_2;
    *(int *)_2 = _24408;
    if( _1 != _24408 ){
        DeRef(_1);
    }
    _24408 = NOVALUE;

    /** 		new[S_OBJ_MAX] = MAXINT*/
    _2 = (int)SEQ_PTR(_new_46181);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_46181 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 31);
    _1 = *(int *)_2;
    *(int *)_2 = 1073741823;
    DeRef(_1);

    /** 		new[S_OBJ_MAX_NEW] = -NOVALUE -- missing from C code? (not needed)*/
    if (IS_ATOM_INT(_35NOVALUE_16099)) {
        if ((unsigned long)_35NOVALUE_16099 == 0xC0000000)
        _24409 = (int)NewDouble((double)-0xC0000000);
        else
        _24409 = - _35NOVALUE_16099;
    }
    else {
        _24409 = unary_op(UMINUS, _35NOVALUE_16099);
    }
    _2 = (int)SEQ_PTR(_new_46181);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_46181 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 42);
    _1 = *(int *)_2;
    *(int *)_2 = _24409;
    if( _1 != _24409 ){
        DeRef(_1);
    }
    _24409 = NOVALUE;
L3: 

    /** 	new[S_TOKEN] = token*/
    _2 = (int)SEQ_PTR(_new_46181);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_46181 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35S_TOKEN_15922))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TOKEN_15922)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _35S_TOKEN_15922);
    _1 = *(int *)_2;
    *(int *)_2 = _token_46175;
    DeRef(_1);

    /** 	new[S_VARNUM] = varnum*/
    _2 = (int)SEQ_PTR(_new_46181);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_46181 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 16);
    _1 = *(int *)_2;
    *(int *)_2 = _varnum_46173;
    DeRef(_1);

    /** 	new[S_INITLEVEL] = -1*/
    _2 = (int)SEQ_PTR(_new_46181);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_46181 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 14);
    _1 = *(int *)_2;
    *(int *)_2 = -1;
    DeRef(_1);

    /** 	new[S_VTYPE] = type_sym*/
    _2 = (int)SEQ_PTR(_new_46181);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_46181 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 15);
    _1 = *(int *)_2;
    *(int *)_2 = _type_sym_46180;
    DeRef(_1);

    /** 	new[S_HASHVAL] = hashval*/
    _2 = (int)SEQ_PTR(_new_46181);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_46181 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 11);
    _1 = *(int *)_2;
    *(int *)_2 = _hashval_46176;
    DeRef(_1);

    /** 	new[S_SAMEHASH] = samehash*/
    _2 = (int)SEQ_PTR(_new_46181);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_46181 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 9);
    _1 = *(int *)_2;
    *(int *)_2 = _samehash_46178;
    DeRef(_1);

    /** 	new[S_OBJ] = NOVALUE -- important*/
    Ref(_35NOVALUE_16099);
    _2 = (int)SEQ_PTR(_new_46181);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_46181 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _35NOVALUE_16099;
    DeRef(_1);

    /** 	SymTab = append(SymTab, new)*/
    RefDS(_new_46181);
    Append(&_36SymTab_15242, _36SymTab_15242, _new_46181);

    /** 	return length(SymTab)*/
    if (IS_SEQUENCE(_36SymTab_15242)){
            _24411 = SEQ_PTR(_36SymTab_15242)->length;
    }
    else {
        _24411 = 1;
    }
    DeRefDS(_name_46172);
    DeRefDS(_new_46181);
    return _24411;
    ;
}


int _53NewEntry(int _name_46260, int _varnum_46261, int _scope_46262, int _token_46263, int _hashval_46264, int _samehash_46266, int _type_sym_46268)
{
    int _new_46270 = NOVALUE;
    int _24413 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_varnum_46261)) {
        _1 = (long)(DBL_PTR(_varnum_46261)->dbl);
        DeRefDS(_varnum_46261);
        _varnum_46261 = _1;
    }
    if (!IS_ATOM_INT(_scope_46262)) {
        _1 = (long)(DBL_PTR(_scope_46262)->dbl);
        DeRefDS(_scope_46262);
        _scope_46262 = _1;
    }
    if (!IS_ATOM_INT(_token_46263)) {
        _1 = (long)(DBL_PTR(_token_46263)->dbl);
        DeRefDS(_token_46263);
        _token_46263 = _1;
    }
    if (!IS_ATOM_INT(_hashval_46264)) {
        _1 = (long)(DBL_PTR(_hashval_46264)->dbl);
        DeRefDS(_hashval_46264);
        _hashval_46264 = _1;
    }
    if (!IS_ATOM_INT(_samehash_46266)) {
        _1 = (long)(DBL_PTR(_samehash_46266)->dbl);
        DeRefDS(_samehash_46266);
        _samehash_46266 = _1;
    }
    if (!IS_ATOM_INT(_type_sym_46268)) {
        _1 = (long)(DBL_PTR(_type_sym_46268)->dbl);
        DeRefDS(_type_sym_46268);
        _type_sym_46268 = _1;
    }

    /** 	symtab_index new = NewBasicEntry( name, varnum, scope, token, hashval, samehash, type_sym )*/
    RefDS(_name_46260);
    _new_46270 = _53NewBasicEntry(_name_46260, _varnum_46261, _scope_46262, _token_46263, _hashval_46264, _samehash_46266, _type_sym_46268);
    if (!IS_ATOM_INT(_new_46270)) {
        _1 = (long)(DBL_PTR(_new_46270)->dbl);
        DeRefDS(_new_46270);
        _new_46270 = _1;
    }

    /** 	if last_sym then*/
    if (_53last_sym_46100 == 0)
    {
        goto L1; // [33] 54
    }
    else{
    }

    /** 		SymTab[last_sym][S_NEXT] = new*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_53last_sym_46100 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _new_46270;
    DeRef(_1);
    _24413 = NOVALUE;
L1: 

    /** 	last_sym = new*/
    _53last_sym_46100 = _new_46270;

    /** 	if type_sym < 0 then*/
    if (_type_sym_46268 >= 0)
    goto L2; // [63] 76

    /** 		register_forward_type( last_sym, type_sym )*/
    _38register_forward_type(_53last_sym_46100, _type_sym_46268);
L2: 

    /** 	return last_sym*/
    DeRefDS(_name_46260);
    return _53last_sym_46100;
    ;
}


int _53tmp_alloc()
{
    int _new_entry_46285 = NOVALUE;
    int _24427 = NOVALUE;
    int _24425 = NOVALUE;
    int _24422 = NOVALUE;
    int _24419 = NOVALUE;
    int _24418 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence new_entry = repeat( 0, SIZEOF_TEMP_ENTRY )*/
    DeRef(_new_entry_46285);
    _new_entry_46285 = Repeat(0, _35SIZEOF_TEMP_ENTRY_16052);

    /** 	new_entry[S_USAGE] = T_UNKNOWN*/
    _2 = (int)SEQ_PTR(_new_entry_46285);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_entry_46285 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    *(int *)_2 = 4;

    /** 	if TRANSLATE then*/
    if (_35TRANSLATE_15887 == 0)
    {
        goto L1; // [23] 132
    }
    else{
    }

    /** 		new_entry[S_GTYPE] = TYPE_OBJECT*/
    _2 = (int)SEQ_PTR(_new_entry_46285);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_entry_46285 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 36);
    *(int *)_2 = 16;

    /** 		new_entry[S_OBJ_MIN] = MININT*/
    _2 = (int)SEQ_PTR(_new_entry_46285);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_entry_46285 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 30);
    *(int *)_2 = -1073741824;

    /** 		new_entry[S_OBJ_MAX] = MAXINT*/
    _2 = (int)SEQ_PTR(_new_entry_46285);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_entry_46285 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 31);
    *(int *)_2 = 1073741823;

    /** 		new_entry[S_SEQ_LEN] = NOVALUE*/
    Ref(_35NOVALUE_16099);
    _2 = (int)SEQ_PTR(_new_entry_46285);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_entry_46285 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 32);
    *(int *)_2 = _35NOVALUE_16099;

    /** 		new_entry[S_SEQ_ELEM] = TYPE_OBJECT  -- other fields set later*/
    _2 = (int)SEQ_PTR(_new_entry_46285);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_entry_46285 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 33);
    _1 = *(int *)_2;
    *(int *)_2 = 16;
    DeRef(_1);

    /** 		if length(temp_name_type)+1 = 8087 then*/
    if (IS_SEQUENCE(_35temp_name_type_16326)){
            _24418 = SEQ_PTR(_35temp_name_type_16326)->length;
    }
    else {
        _24418 = 1;
    }
    _24419 = _24418 + 1;
    _24418 = NOVALUE;
    if (_24419 != 8087)
    goto L2; // [87] 106

    /** 			temp_name_type = append(temp_name_type, {0, 0})*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = 0;
    _24422 = MAKE_SEQ(_1);
    RefDS(_24422);
    Append(&_35temp_name_type_16326, _35temp_name_type_16326, _24422);
    DeRefDS(_24422);
    _24422 = NOVALUE;
L2: 

    /** 		temp_name_type = append(temp_name_type, TYPES_OBNL)*/
    RefDS(_54TYPES_OBNL_45485);
    Append(&_35temp_name_type_16326, _35temp_name_type_16326, _54TYPES_OBNL_45485);

    /** 		new_entry[S_TEMP_NAME] = length(temp_name_type)*/
    if (IS_SEQUENCE(_35temp_name_type_16326)){
            _24425 = SEQ_PTR(_35temp_name_type_16326)->length;
    }
    else {
        _24425 = 1;
    }
    _2 = (int)SEQ_PTR(_new_entry_46285);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_entry_46285 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 34);
    _1 = *(int *)_2;
    *(int *)_2 = _24425;
    if( _1 != _24425 ){
        DeRef(_1);
    }
    _24425 = NOVALUE;
L1: 

    /** 	SymTab = append(SymTab, new_entry )*/
    RefDS(_new_entry_46285);
    Append(&_36SymTab_15242, _36SymTab_15242, _new_entry_46285);

    /** 	return length( SymTab )*/
    if (IS_SEQUENCE(_36SymTab_15242)){
            _24427 = SEQ_PTR(_36SymTab_15242)->length;
    }
    else {
        _24427 = 1;
    }
    DeRefDS(_new_entry_46285);
    DeRef(_24419);
    _24419 = NOVALUE;
    return _24427;
    ;
}


void _53DefinedYet(int _sym_46354)
{
    int _24447 = NOVALUE;
    int _24446 = NOVALUE;
    int _24445 = NOVALUE;
    int _24443 = NOVALUE;
    int _24442 = NOVALUE;
    int _24440 = NOVALUE;
    int _24439 = NOVALUE;
    int _24438 = NOVALUE;
    int _24437 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_sym_46354)) {
        _1 = (long)(DBL_PTR(_sym_46354)->dbl);
        DeRefDS(_sym_46354);
        _sym_46354 = _1;
    }

    /** 	if not find(SymTab[sym][S_SCOPE],*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _24437 = (int)*(((s1_ptr)_2)->base + _sym_46354);
    _2 = (int)SEQ_PTR(_24437);
    _24438 = (int)*(((s1_ptr)_2)->base + 4);
    _24437 = NOVALUE;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 9;
    *((int *)(_2+8)) = 10;
    *((int *)(_2+12)) = 7;
    _24439 = MAKE_SEQ(_1);
    _24440 = find_from(_24438, _24439, 1);
    _24438 = NOVALUE;
    DeRefDS(_24439);
    _24439 = NOVALUE;
    if (_24440 != 0)
    goto L1; // [34] 82
    _24440 = NOVALUE;

    /** 		if SymTab[sym][S_FILE_NO] = current_file_no then*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _24442 = (int)*(((s1_ptr)_2)->base + _sym_46354);
    _2 = (int)SEQ_PTR(_24442);
    if (!IS_ATOM_INT(_35S_FILE_NO_15913)){
        _24443 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FILE_NO_15913)->dbl));
    }
    else{
        _24443 = (int)*(((s1_ptr)_2)->base + _35S_FILE_NO_15913);
    }
    _24442 = NOVALUE;
    if (binary_op_a(NOTEQ, _24443, _35current_file_no_16244)){
        _24443 = NOVALUE;
        goto L2; // [53] 81
    }
    _24443 = NOVALUE;

    /** 			CompileErr(31, {SymTab[sym][S_NAME]})*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _24445 = (int)*(((s1_ptr)_2)->base + _sym_46354);
    _2 = (int)SEQ_PTR(_24445);
    if (!IS_ATOM_INT(_35S_NAME_15917)){
        _24446 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15917)->dbl));
    }
    else{
        _24446 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15917);
    }
    _24445 = NOVALUE;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_24446);
    *((int *)(_2+4)) = _24446;
    _24447 = MAKE_SEQ(_1);
    _24446 = NOVALUE;
    _44CompileErr(31, _24447, 0);
    _24447 = NOVALUE;
L2: 
L1: 

    /** end procedure*/
    return;
    ;
}


int _53name_ext(int _s_46381)
{
    int _24454 = NOVALUE;
    int _24453 = NOVALUE;
    int _24452 = NOVALUE;
    int _24451 = NOVALUE;
    int _24449 = NOVALUE;
    int _24448 = NOVALUE;
    int _0, _1, _2;
    

    /** 	for i = length(s) to 1 by -1 do*/
    if (IS_SEQUENCE(_s_46381)){
            _24448 = SEQ_PTR(_s_46381)->length;
    }
    else {
        _24448 = 1;
    }
    {
        int _i_46383;
        _i_46383 = _24448;
L1: 
        if (_i_46383 < 1){
            goto L2; // [8] 55
        }

        /** 		if find(s[i], "/\\:") then*/
        _2 = (int)SEQ_PTR(_s_46381);
        _24449 = (int)*(((s1_ptr)_2)->base + _i_46383);
        _24451 = find_from(_24449, _24450, 1);
        _24449 = NOVALUE;
        if (_24451 == 0)
        {
            _24451 = NOVALUE;
            goto L3; // [26] 48
        }
        else{
            _24451 = NOVALUE;
        }

        /** 			return s[i+1 .. $]*/
        _24452 = _i_46383 + 1;
        if (IS_SEQUENCE(_s_46381)){
                _24453 = SEQ_PTR(_s_46381)->length;
        }
        else {
            _24453 = 1;
        }
        rhs_slice_target = (object_ptr)&_24454;
        RHS_Slice(_s_46381, _24452, _24453);
        DeRefDS(_s_46381);
        _24452 = NOVALUE;
        return _24454;
L3: 

        /** 	end for*/
        _i_46383 = _i_46383 + -1;
        goto L1; // [50] 15
L2: 
        ;
    }

    /** 	return s*/
    DeRef(_24452);
    _24452 = NOVALUE;
    DeRef(_24454);
    _24454 = NOVALUE;
    return _s_46381;
    ;
}


int _53NewStringSym(int _s_46400)
{
    int _p_46402 = NOVALUE;
    int _tp_46403 = NOVALUE;
    int _prev_46404 = NOVALUE;
    int _search_count_46405 = NOVALUE;
    int _24498 = NOVALUE;
    int _24496 = NOVALUE;
    int _24495 = NOVALUE;
    int _24494 = NOVALUE;
    int _24492 = NOVALUE;
    int _24491 = NOVALUE;
    int _24488 = NOVALUE;
    int _24486 = NOVALUE;
    int _24484 = NOVALUE;
    int _24483 = NOVALUE;
    int _24482 = NOVALUE;
    int _24480 = NOVALUE;
    int _24478 = NOVALUE;
    int _24476 = NOVALUE;
    int _24474 = NOVALUE;
    int _24471 = NOVALUE;
    int _24469 = NOVALUE;
    int _24468 = NOVALUE;
    int _24467 = NOVALUE;
    int _24465 = NOVALUE;
    int _24463 = NOVALUE;
    int _24462 = NOVALUE;
    int _24461 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	integer search_count*/

    /** 	tp = literal_init*/
    _tp_46403 = _53literal_init_46099;

    /** 	prev = 0*/
    _prev_46404 = 0;

    /** 	search_count = 0*/
    _search_count_46405 = 0;

    /** 	while tp != 0 do*/
L1: 
    if (_tp_46403 == 0)
    goto L2; // [31] 170

    /** 		search_count += 1*/
    _search_count_46405 = _search_count_46405 + 1;

    /** 		if search_count > SEARCH_LIMIT then  -- avoid n-squared algorithm*/
    if (binary_op_a(LESSEQ, _search_count_46405, _53SEARCH_LIMIT_46392)){
        goto L3; // [45] 54
    }

    /** 			exit*/
    goto L2; // [51] 170
L3: 

    /** 		if equal(s, SymTab[tp][S_OBJ]) then*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _24461 = (int)*(((s1_ptr)_2)->base + _tp_46403);
    _2 = (int)SEQ_PTR(_24461);
    _24462 = (int)*(((s1_ptr)_2)->base + 1);
    _24461 = NOVALUE;
    if (_s_46400 == _24462)
    _24463 = 1;
    else if (IS_ATOM_INT(_s_46400) && IS_ATOM_INT(_24462))
    _24463 = 0;
    else
    _24463 = (compare(_s_46400, _24462) == 0);
    _24462 = NOVALUE;
    if (_24463 == 0)
    {
        _24463 = NOVALUE;
        goto L4; // [72] 142
    }
    else{
        _24463 = NOVALUE;
    }

    /** 			if tp != literal_init then*/
    if (_tp_46403 == _53literal_init_46099)
    goto L5; // [79] 135

    /** 				SymTab[prev][S_NEXT] = SymTab[tp][S_NEXT]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_prev_46404 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _24467 = (int)*(((s1_ptr)_2)->base + _tp_46403);
    _2 = (int)SEQ_PTR(_24467);
    _24468 = (int)*(((s1_ptr)_2)->base + 2);
    _24467 = NOVALUE;
    Ref(_24468);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _24468;
    if( _1 != _24468 ){
        DeRef(_1);
    }
    _24468 = NOVALUE;
    _24465 = NOVALUE;

    /** 				SymTab[tp][S_NEXT] = literal_init*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_tp_46403 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _53literal_init_46099;
    DeRef(_1);
    _24469 = NOVALUE;

    /** 				literal_init = tp*/
    _53literal_init_46099 = _tp_46403;
L5: 

    /** 			return tp*/
    DeRefDS(_s_46400);
    return _tp_46403;
L4: 

    /** 		prev = tp*/
    _prev_46404 = _tp_46403;

    /** 		tp = SymTab[tp][S_NEXT]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _24471 = (int)*(((s1_ptr)_2)->base + _tp_46403);
    _2 = (int)SEQ_PTR(_24471);
    _tp_46403 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_tp_46403)){
        _tp_46403 = (long)DBL_PTR(_tp_46403)->dbl;
    }
    _24471 = NOVALUE;

    /** 	end while*/
    goto L1; // [167] 31
L2: 

    /** 	p = tmp_alloc()*/
    _p_46402 = _53tmp_alloc();
    if (!IS_ATOM_INT(_p_46402)) {
        _1 = (long)(DBL_PTR(_p_46402)->dbl);
        DeRefDS(_p_46402);
        _p_46402 = _1;
    }

    /** 	SymTab[p][S_OBJ] = s*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46402 + ((s1_ptr)_2)->base);
    RefDS(_s_46400);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _s_46400;
    DeRef(_1);
    _24474 = NOVALUE;

    /** 	if TRANSLATE then*/
    if (_35TRANSLATE_15887 == 0)
    {
        goto L6; // [196] 346
    }
    else{
    }

    /** 		SymTab[p][S_MODE] = M_TEMP    -- override CONSTANT for compile*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46402 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = 3;
    DeRef(_1);
    _24476 = NOVALUE;

    /** 		SymTab[p][S_GTYPE] = TYPE_SEQUENCE*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46402 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 36);
    _1 = *(int *)_2;
    *(int *)_2 = 8;
    DeRef(_1);
    _24478 = NOVALUE;

    /** 		SymTab[p][S_SEQ_LEN] = length(s)*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46402 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_s_46400)){
            _24482 = SEQ_PTR(_s_46400)->length;
    }
    else {
        _24482 = 1;
    }
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 32);
    _1 = *(int *)_2;
    *(int *)_2 = _24482;
    if( _1 != _24482 ){
        DeRef(_1);
    }
    _24482 = NOVALUE;
    _24480 = NOVALUE;

    /** 		if SymTab[p][S_SEQ_LEN] > 0 then*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _24483 = (int)*(((s1_ptr)_2)->base + _p_46402);
    _2 = (int)SEQ_PTR(_24483);
    _24484 = (int)*(((s1_ptr)_2)->base + 32);
    _24483 = NOVALUE;
    if (binary_op_a(LESSEQ, _24484, 0)){
        _24484 = NOVALUE;
        goto L7; // [265] 289
    }
    _24484 = NOVALUE;

    /** 			SymTab[p][S_SEQ_ELEM] = TYPE_INTEGER*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46402 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 33);
    _1 = *(int *)_2;
    *(int *)_2 = 1;
    DeRef(_1);
    _24486 = NOVALUE;
    goto L8; // [286] 307
L7: 

    /** 			SymTab[p][S_SEQ_ELEM] = TYPE_NULL*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46402 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 33);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _24488 = NOVALUE;
L8: 

    /** 		c_printf("int _%d;\n", SymTab[p][S_TEMP_NAME])*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _24491 = (int)*(((s1_ptr)_2)->base + _p_46402);
    _2 = (int)SEQ_PTR(_24491);
    _24492 = (int)*(((s1_ptr)_2)->base + 34);
    _24491 = NOVALUE;
    RefDS(_24490);
    Ref(_24492);
    _54c_printf(_24490, _24492);
    _24492 = NOVALUE;

    /** 		c_hprintf("extern int _%d;\n", SymTab[p][S_TEMP_NAME])*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _24494 = (int)*(((s1_ptr)_2)->base + _p_46402);
    _2 = (int)SEQ_PTR(_24494);
    _24495 = (int)*(((s1_ptr)_2)->base + 34);
    _24494 = NOVALUE;
    RefDS(_24493);
    Ref(_24495);
    _54c_hprintf(_24493, _24495);
    _24495 = NOVALUE;
    goto L9; // [343] 364
L6: 

    /** 		SymTab[p][S_MODE] = M_CONSTANT*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46402 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = 2;
    DeRef(_1);
    _24496 = NOVALUE;
L9: 

    /** 	SymTab[p][S_NEXT] = literal_init*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46402 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _53literal_init_46099;
    DeRef(_1);
    _24498 = NOVALUE;

    /** 	literal_init = p*/
    _53literal_init_46099 = _p_46402;

    /** 	return p*/
    DeRefDS(_s_46400);
    return _p_46402;
    ;
}


int _53NewIntSym(int _int_val_46498)
{
    int _p_46500 = NOVALUE;
    int _x_46501 = NOVALUE;
    int _24517 = NOVALUE;
    int _24515 = NOVALUE;
    int _24511 = NOVALUE;
    int _24509 = NOVALUE;
    int _24507 = NOVALUE;
    int _24505 = NOVALUE;
    int _24503 = NOVALUE;
    int _24501 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_int_val_46498)) {
        _1 = (long)(DBL_PTR(_int_val_46498)->dbl);
        DeRefDS(_int_val_46498);
        _int_val_46498 = _1;
    }

    /** 	integer x*/

    /** 	x = find(int_val, lastintval)*/
    _x_46501 = find_from(_int_val_46498, _53lastintval_46101, 1);

    /** 	if x then*/
    if (_x_46501 == 0)
    {
        goto L1; // [16] 34
    }
    else{
    }

    /** 		return lastintsym[x]  -- saves space, helps Translator reduce code size*/
    _2 = (int)SEQ_PTR(_53lastintsym_46102);
    _24501 = (int)*(((s1_ptr)_2)->base + _x_46501);
    return _24501;
    goto L2; // [31] 180
L1: 

    /** 		p = tmp_alloc()*/
    _p_46500 = _53tmp_alloc();
    if (!IS_ATOM_INT(_p_46500)) {
        _1 = (long)(DBL_PTR(_p_46500)->dbl);
        DeRefDS(_p_46500);
        _p_46500 = _1;
    }

    /** 		SymTab[p][S_MODE] = M_CONSTANT*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46500 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = 2;
    DeRef(_1);
    _24503 = NOVALUE;

    /** 		SymTab[p][S_OBJ] = int_val*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46500 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _int_val_46498;
    DeRef(_1);
    _24505 = NOVALUE;

    /** 		if TRANSLATE then*/
    if (_35TRANSLATE_15887 == 0)
    {
        goto L3; // [77] 128
    }
    else{
    }

    /** 			SymTab[p][S_OBJ_MIN] = int_val*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46500 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 30);
    _1 = *(int *)_2;
    *(int *)_2 = _int_val_46498;
    DeRef(_1);
    _24507 = NOVALUE;

    /** 			SymTab[p][S_OBJ_MAX] = int_val*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46500 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 31);
    _1 = *(int *)_2;
    *(int *)_2 = _int_val_46498;
    DeRef(_1);
    _24509 = NOVALUE;

    /** 			SymTab[p][S_GTYPE] = TYPE_INTEGER*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46500 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 36);
    _1 = *(int *)_2;
    *(int *)_2 = 1;
    DeRef(_1);
    _24511 = NOVALUE;
L3: 

    /** 		lastintval = prepend(lastintval, int_val)*/
    Prepend(&_53lastintval_46101, _53lastintval_46101, _int_val_46498);

    /** 		lastintsym = prepend(lastintsym, p)*/
    Prepend(&_53lastintsym_46102, _53lastintsym_46102, _p_46500);

    /** 		if length(lastintval) > SEARCH_LIMIT then*/
    if (IS_SEQUENCE(_53lastintval_46101)){
            _24515 = SEQ_PTR(_53lastintval_46101)->length;
    }
    else {
        _24515 = 1;
    }
    if (binary_op_a(LESSEQ, _24515, _53SEARCH_LIMIT_46392)){
        _24515 = NOVALUE;
        goto L4; // [153] 173
    }
    _24515 = NOVALUE;

    /** 			lastintval = lastintval[1..floor(SEARCH_LIMIT/2)]*/
    if (IS_ATOM_INT(_53SEARCH_LIMIT_46392)) {
        _24517 = _53SEARCH_LIMIT_46392 >> 1;
    }
    else {
        _1 = binary_op(DIVIDE, _53SEARCH_LIMIT_46392, 2);
        _24517 = unary_op(FLOOR, _1);
        DeRef(_1);
    }
    rhs_slice_target = (object_ptr)&_53lastintval_46101;
    RHS_Slice(_53lastintval_46101, 1, _24517);
L4: 

    /** 		return p*/
    _24501 = NOVALUE;
    DeRef(_24517);
    _24517 = NOVALUE;
    return _p_46500;
L2: 
    ;
}


int _53NewDoubleSym(int _d_46540)
{
    int _p_46542 = NOVALUE;
    int _tp_46543 = NOVALUE;
    int _prev_46544 = NOVALUE;
    int _search_count_46545 = NOVALUE;
    int _24547 = NOVALUE;
    int _24546 = NOVALUE;
    int _24545 = NOVALUE;
    int _24544 = NOVALUE;
    int _24543 = NOVALUE;
    int _24541 = NOVALUE;
    int _24539 = NOVALUE;
    int _24537 = NOVALUE;
    int _24535 = NOVALUE;
    int _24532 = NOVALUE;
    int _24530 = NOVALUE;
    int _24529 = NOVALUE;
    int _24528 = NOVALUE;
    int _24526 = NOVALUE;
    int _24524 = NOVALUE;
    int _24523 = NOVALUE;
    int _24522 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	integer search_count*/

    /** 	tp = literal_init*/
    _tp_46543 = _53literal_init_46099;

    /** 	prev = 0*/
    _prev_46544 = 0;

    /** 	search_count = 0*/
    _search_count_46545 = 0;

    /** 	while tp != 0 do*/
L1: 
    if (_tp_46543 == 0)
    goto L2; // [29] 168

    /** 		search_count += 1*/
    _search_count_46545 = _search_count_46545 + 1;

    /** 		if search_count > SEARCH_LIMIT then  -- avoid n-squared algorithm*/
    if (binary_op_a(LESSEQ, _search_count_46545, _53SEARCH_LIMIT_46392)){
        goto L3; // [43] 52
    }

    /** 			exit*/
    goto L2; // [49] 168
L3: 

    /** 		if equal(d, SymTab[tp][S_OBJ]) then*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _24522 = (int)*(((s1_ptr)_2)->base + _tp_46543);
    _2 = (int)SEQ_PTR(_24522);
    _24523 = (int)*(((s1_ptr)_2)->base + 1);
    _24522 = NOVALUE;
    if (_d_46540 == _24523)
    _24524 = 1;
    else if (IS_ATOM_INT(_d_46540) && IS_ATOM_INT(_24523))
    _24524 = 0;
    else
    _24524 = (compare(_d_46540, _24523) == 0);
    _24523 = NOVALUE;
    if (_24524 == 0)
    {
        _24524 = NOVALUE;
        goto L4; // [70] 140
    }
    else{
        _24524 = NOVALUE;
    }

    /** 			if tp != literal_init then*/
    if (_tp_46543 == _53literal_init_46099)
    goto L5; // [77] 133

    /** 				SymTab[prev][S_NEXT] = SymTab[tp][S_NEXT]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_prev_46544 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _24528 = (int)*(((s1_ptr)_2)->base + _tp_46543);
    _2 = (int)SEQ_PTR(_24528);
    _24529 = (int)*(((s1_ptr)_2)->base + 2);
    _24528 = NOVALUE;
    Ref(_24529);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _24529;
    if( _1 != _24529 ){
        DeRef(_1);
    }
    _24529 = NOVALUE;
    _24526 = NOVALUE;

    /** 				SymTab[tp][S_NEXT] = literal_init*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_tp_46543 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _53literal_init_46099;
    DeRef(_1);
    _24530 = NOVALUE;

    /** 				literal_init = tp*/
    _53literal_init_46099 = _tp_46543;
L5: 

    /** 			return tp*/
    DeRef(_d_46540);
    return _tp_46543;
L4: 

    /** 		prev = tp*/
    _prev_46544 = _tp_46543;

    /** 		tp = SymTab[tp][S_NEXT]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _24532 = (int)*(((s1_ptr)_2)->base + _tp_46543);
    _2 = (int)SEQ_PTR(_24532);
    _tp_46543 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_tp_46543)){
        _tp_46543 = (long)DBL_PTR(_tp_46543)->dbl;
    }
    _24532 = NOVALUE;

    /** 	end while*/
    goto L1; // [165] 29
L2: 

    /** 	p = tmp_alloc()*/
    _p_46542 = _53tmp_alloc();
    if (!IS_ATOM_INT(_p_46542)) {
        _1 = (long)(DBL_PTR(_p_46542)->dbl);
        DeRefDS(_p_46542);
        _p_46542 = _1;
    }

    /** 	SymTab[p][S_MODE] = M_CONSTANT*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46542 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = 2;
    DeRef(_1);
    _24535 = NOVALUE;

    /** 	SymTab[p][S_OBJ] = d*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46542 + ((s1_ptr)_2)->base);
    Ref(_d_46540);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _d_46540;
    DeRef(_1);
    _24537 = NOVALUE;

    /** 	if TRANSLATE then*/
    if (_35TRANSLATE_15887 == 0)
    {
        goto L6; // [211] 285
    }
    else{
    }

    /** 		SymTab[p][S_MODE] = M_TEMP  -- override CONSTANT for compile*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46542 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = 3;
    DeRef(_1);
    _24539 = NOVALUE;

    /** 		SymTab[p][S_GTYPE] = TYPE_DOUBLE*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46542 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 36);
    _1 = *(int *)_2;
    *(int *)_2 = 2;
    DeRef(_1);
    _24541 = NOVALUE;

    /** 		c_printf("int _%d;\n", SymTab[p][S_TEMP_NAME])*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _24543 = (int)*(((s1_ptr)_2)->base + _p_46542);
    _2 = (int)SEQ_PTR(_24543);
    _24544 = (int)*(((s1_ptr)_2)->base + 34);
    _24543 = NOVALUE;
    RefDS(_24490);
    Ref(_24544);
    _54c_printf(_24490, _24544);
    _24544 = NOVALUE;

    /** 		c_hprintf("extern int _%d;\n", SymTab[p][S_TEMP_NAME])*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _24545 = (int)*(((s1_ptr)_2)->base + _p_46542);
    _2 = (int)SEQ_PTR(_24545);
    _24546 = (int)*(((s1_ptr)_2)->base + 34);
    _24545 = NOVALUE;
    RefDS(_24493);
    Ref(_24546);
    _54c_hprintf(_24493, _24546);
    _24546 = NOVALUE;
L6: 

    /** 	SymTab[p][S_NEXT] = literal_init*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46542 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _53literal_init_46099;
    DeRef(_1);
    _24547 = NOVALUE;

    /** 	literal_init = p*/
    _53literal_init_46099 = _p_46542;

    /** 	return p*/
    DeRef(_d_46540);
    return _p_46542;
    ;
}


int _53NewTempSym(int _inlining_46614)
{
    int _p_46616 = NOVALUE;
    int _q_46617 = NOVALUE;
    int _24596 = NOVALUE;
    int _24594 = NOVALUE;
    int _24592 = NOVALUE;
    int _24590 = NOVALUE;
    int _24588 = NOVALUE;
    int _24586 = NOVALUE;
    int _24585 = NOVALUE;
    int _24584 = NOVALUE;
    int _24582 = NOVALUE;
    int _24581 = NOVALUE;
    int _24580 = NOVALUE;
    int _24578 = NOVALUE;
    int _24576 = NOVALUE;
    int _24573 = NOVALUE;
    int _24572 = NOVALUE;
    int _24571 = NOVALUE;
    int _24569 = NOVALUE;
    int _24567 = NOVALUE;
    int _24566 = NOVALUE;
    int _24565 = NOVALUE;
    int _24563 = NOVALUE;
    int _24561 = NOVALUE;
    int _24556 = NOVALUE;
    int _24555 = NOVALUE;
    int _24554 = NOVALUE;
    int _24553 = NOVALUE;
    int _24552 = NOVALUE;
    int _24551 = NOVALUE;
    int _24549 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_inlining_46614)) {
        _1 = (long)(DBL_PTR(_inlining_46614)->dbl);
        DeRefDS(_inlining_46614);
        _inlining_46614 = _1;
    }

    /** 	if inlining then*/
    if (_inlining_46614 == 0)
    {
        goto L1; // [5] 85
    }
    else{
    }

    /** 		p = SymTab[CurrentSub][S_TEMPS]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _24549 = (int)*(((s1_ptr)_2)->base + _35CurrentSub_16252);
    _2 = (int)SEQ_PTR(_24549);
    if (!IS_ATOM_INT(_35S_TEMPS_15962)){
        _p_46616 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TEMPS_15962)->dbl));
    }
    else{
        _p_46616 = (int)*(((s1_ptr)_2)->base + _35S_TEMPS_15962);
    }
    if (!IS_ATOM_INT(_p_46616)){
        _p_46616 = (long)DBL_PTR(_p_46616)->dbl;
    }
    _24549 = NOVALUE;

    /** 		while p != 0 and SymTab[p][S_SCOPE] != FREE do*/
L2: 
    _24551 = (_p_46616 != 0);
    if (_24551 == 0) {
        goto L3; // [35] 93
    }
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _24553 = (int)*(((s1_ptr)_2)->base + _p_46616);
    _2 = (int)SEQ_PTR(_24553);
    _24554 = (int)*(((s1_ptr)_2)->base + 4);
    _24553 = NOVALUE;
    if (IS_ATOM_INT(_24554)) {
        _24555 = (_24554 != 0);
    }
    else {
        _24555 = binary_op(NOTEQ, _24554, 0);
    }
    _24554 = NOVALUE;
    if (_24555 <= 0) {
        if (_24555 == 0) {
            DeRef(_24555);
            _24555 = NOVALUE;
            goto L3; // [58] 93
        }
        else {
            if (!IS_ATOM_INT(_24555) && DBL_PTR(_24555)->dbl == 0.0){
                DeRef(_24555);
                _24555 = NOVALUE;
                goto L3; // [58] 93
            }
            DeRef(_24555);
            _24555 = NOVALUE;
        }
    }
    DeRef(_24555);
    _24555 = NOVALUE;

    /** 			p = SymTab[p][S_NEXT]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _24556 = (int)*(((s1_ptr)_2)->base + _p_46616);
    _2 = (int)SEQ_PTR(_24556);
    _p_46616 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_p_46616)){
        _p_46616 = (long)DBL_PTR(_p_46616)->dbl;
    }
    _24556 = NOVALUE;

    /** 		end while*/
    goto L2; // [79] 31
    goto L3; // [82] 93
L1: 

    /** 		p = 0*/
    _p_46616 = 0;
L3: 

    /** 	if p = 0 then*/
    if (_p_46616 != 0)
    goto L4; // [97] 213

    /** 		temps_allocated += 1*/
    _53temps_allocated_46611 = _53temps_allocated_46611 + 1;

    /** 		p = tmp_alloc()*/
    _p_46616 = _53tmp_alloc();
    if (!IS_ATOM_INT(_p_46616)) {
        _1 = (long)(DBL_PTR(_p_46616)->dbl);
        DeRefDS(_p_46616);
        _p_46616 = _1;
    }

    /** 		SymTab[p][S_MODE] = M_TEMP*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46616 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = 3;
    DeRef(_1);
    _24561 = NOVALUE;

    /** 		SymTab[p][S_NEXT] = SymTab[CurrentSub][S_TEMPS]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46616 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _24565 = (int)*(((s1_ptr)_2)->base + _35CurrentSub_16252);
    _2 = (int)SEQ_PTR(_24565);
    if (!IS_ATOM_INT(_35S_TEMPS_15962)){
        _24566 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TEMPS_15962)->dbl));
    }
    else{
        _24566 = (int)*(((s1_ptr)_2)->base + _35S_TEMPS_15962);
    }
    _24565 = NOVALUE;
    Ref(_24566);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _24566;
    if( _1 != _24566 ){
        DeRef(_1);
    }
    _24566 = NOVALUE;
    _24563 = NOVALUE;

    /** 		SymTab[CurrentSub][S_TEMPS] = p*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_35CurrentSub_16252 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35S_TEMPS_15962))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TEMPS_15962)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _35S_TEMPS_15962);
    _1 = *(int *)_2;
    *(int *)_2 = _p_46616;
    DeRef(_1);
    _24567 = NOVALUE;

    /** 		if inlining then*/
    if (_inlining_46614 == 0)
    {
        goto L5; // [181] 343
    }
    else{
    }

    /** 			SymTab[CurrentSub][S_STACK_SPACE] += 1*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_35CurrentSub_16252 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!IS_ATOM_INT(_35S_STACK_SPACE_15977)){
        _24571 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_STACK_SPACE_15977)->dbl));
    }
    else{
        _24571 = (int)*(((s1_ptr)_2)->base + _35S_STACK_SPACE_15977);
    }
    _24569 = NOVALUE;
    if (IS_ATOM_INT(_24571)) {
        _24572 = _24571 + 1;
        if (_24572 > MAXINT){
            _24572 = NewDouble((double)_24572);
        }
    }
    else
    _24572 = binary_op(PLUS, 1, _24571);
    _24571 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35S_STACK_SPACE_15977))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_STACK_SPACE_15977)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _35S_STACK_SPACE_15977);
    _1 = *(int *)_2;
    *(int *)_2 = _24572;
    if( _1 != _24572 ){
        DeRef(_1);
    }
    _24572 = NOVALUE;
    _24569 = NOVALUE;
    goto L5; // [210] 343
L4: 

    /** 	elsif TRANSLATE then*/
    if (_35TRANSLATE_15887 == 0)
    {
        goto L6; // [217] 342
    }
    else{
    }

    /** 		SymTab[p][S_SCOPE] = DELETED*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46616 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = 2;
    DeRef(_1);
    _24573 = NOVALUE;

    /** 		q = tmp_alloc()*/
    _q_46617 = _53tmp_alloc();
    if (!IS_ATOM_INT(_q_46617)) {
        _1 = (long)(DBL_PTR(_q_46617)->dbl);
        DeRefDS(_q_46617);
        _q_46617 = _1;
    }

    /** 		SymTab[q][S_MODE] = M_TEMP*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_q_46617 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = 3;
    DeRef(_1);
    _24576 = NOVALUE;

    /** 		SymTab[q][S_TEMP_NAME] = SymTab[p][S_TEMP_NAME]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_q_46617 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _24580 = (int)*(((s1_ptr)_2)->base + _p_46616);
    _2 = (int)SEQ_PTR(_24580);
    _24581 = (int)*(((s1_ptr)_2)->base + 34);
    _24580 = NOVALUE;
    Ref(_24581);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 34);
    _1 = *(int *)_2;
    *(int *)_2 = _24581;
    if( _1 != _24581 ){
        DeRef(_1);
    }
    _24581 = NOVALUE;
    _24578 = NOVALUE;

    /** 		SymTab[q][S_NEXT] = SymTab[CurrentSub][S_TEMPS]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_q_46617 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _24584 = (int)*(((s1_ptr)_2)->base + _35CurrentSub_16252);
    _2 = (int)SEQ_PTR(_24584);
    if (!IS_ATOM_INT(_35S_TEMPS_15962)){
        _24585 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TEMPS_15962)->dbl));
    }
    else{
        _24585 = (int)*(((s1_ptr)_2)->base + _35S_TEMPS_15962);
    }
    _24584 = NOVALUE;
    Ref(_24585);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _24585;
    if( _1 != _24585 ){
        DeRef(_1);
    }
    _24585 = NOVALUE;
    _24582 = NOVALUE;

    /** 		SymTab[CurrentSub][S_TEMPS] = q*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_35CurrentSub_16252 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35S_TEMPS_15962))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TEMPS_15962)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _35S_TEMPS_15962);
    _1 = *(int *)_2;
    *(int *)_2 = _q_46617;
    DeRef(_1);
    _24586 = NOVALUE;

    /** 		p = q*/
    _p_46616 = _q_46617;
L6: 
L5: 

    /** 	if TRANSLATE then*/
    if (_35TRANSLATE_15887 == 0)
    {
        goto L7; // [347] 385
    }
    else{
    }

    /** 		SymTab[p][S_GTYPE] = TYPE_OBJECT*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46616 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 36);
    _1 = *(int *)_2;
    *(int *)_2 = 16;
    DeRef(_1);
    _24588 = NOVALUE;

    /** 		SymTab[p][S_SEQ_ELEM] = TYPE_OBJECT*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46616 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 33);
    _1 = *(int *)_2;
    *(int *)_2 = 16;
    DeRef(_1);
    _24590 = NOVALUE;
L7: 

    /** 	SymTab[p][S_OBJ] = NOVALUE*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46616 + ((s1_ptr)_2)->base);
    Ref(_35NOVALUE_16099);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _35NOVALUE_16099;
    DeRef(_1);
    _24592 = NOVALUE;

    /** 	SymTab[p][S_USAGE] = T_UNKNOWN*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46616 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = 4;
    DeRef(_1);
    _24594 = NOVALUE;

    /** 	SymTab[p][S_SCOPE] = IN_USE*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46616 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = 1;
    DeRef(_1);
    _24596 = NOVALUE;

    /** 	return p*/
    DeRef(_24551);
    _24551 = NOVALUE;
    return _p_46616;
    ;
}


void _53InitSymTab()
{
    int _hashval_46733 = NOVALUE;
    int _len_46734 = NOVALUE;
    int _s_46736 = NOVALUE;
    int _st_index_46737 = NOVALUE;
    int _kname_46738 = NOVALUE;
    int _fixups_46739 = NOVALUE;
    int _si_46879 = NOVALUE;
    int _sj_46880 = NOVALUE;
    int _25180 = NOVALUE;
    int _25179 = NOVALUE;
    int _24712 = NOVALUE;
    int _24711 = NOVALUE;
    int _24710 = NOVALUE;
    int _24709 = NOVALUE;
    int _24708 = NOVALUE;
    int _24706 = NOVALUE;
    int _24705 = NOVALUE;
    int _24704 = NOVALUE;
    int _24703 = NOVALUE;
    int _24701 = NOVALUE;
    int _24699 = NOVALUE;
    int _24697 = NOVALUE;
    int _24696 = NOVALUE;
    int _24694 = NOVALUE;
    int _24692 = NOVALUE;
    int _24690 = NOVALUE;
    int _24689 = NOVALUE;
    int _24687 = NOVALUE;
    int _24686 = NOVALUE;
    int _24685 = NOVALUE;
    int _24684 = NOVALUE;
    int _24683 = NOVALUE;
    int _24680 = NOVALUE;
    int _24679 = NOVALUE;
    int _24678 = NOVALUE;
    int _24676 = NOVALUE;
    int _24675 = NOVALUE;
    int _24674 = NOVALUE;
    int _24672 = NOVALUE;
    int _24671 = NOVALUE;
    int _24670 = NOVALUE;
    int _24667 = NOVALUE;
    int _24665 = NOVALUE;
    int _24663 = NOVALUE;
    int _24662 = NOVALUE;
    int _24659 = NOVALUE;
    int _24658 = NOVALUE;
    int _24656 = NOVALUE;
    int _24654 = NOVALUE;
    int _24652 = NOVALUE;
    int _24649 = NOVALUE;
    int _24648 = NOVALUE;
    int _24647 = NOVALUE;
    int _24644 = NOVALUE;
    int _24643 = NOVALUE;
    int _24641 = NOVALUE;
    int _24640 = NOVALUE;
    int _24638 = NOVALUE;
    int _24637 = NOVALUE;
    int _24636 = NOVALUE;
    int _24634 = NOVALUE;
    int _24632 = NOVALUE;
    int _24631 = NOVALUE;
    int _24629 = NOVALUE;
    int _24628 = NOVALUE;
    int _24627 = NOVALUE;
    int _24625 = NOVALUE;
    int _24624 = NOVALUE;
    int _24623 = NOVALUE;
    int _24621 = NOVALUE;
    int _24620 = NOVALUE;
    int _24619 = NOVALUE;
    int _24617 = NOVALUE;
    int _24616 = NOVALUE;
    int _24615 = NOVALUE;
    int _24614 = NOVALUE;
    int _24613 = NOVALUE;
    int _24612 = NOVALUE;
    int _24611 = NOVALUE;
    int _24610 = NOVALUE;
    int _24609 = NOVALUE;
    int _24608 = NOVALUE;
    int _24606 = NOVALUE;
    int _24605 = NOVALUE;
    int _24604 = NOVALUE;
    int _24603 = NOVALUE;
    int _24599 = NOVALUE;
    int _24598 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	sequence kname, fixups = {}*/
    RefDS(_22023);
    DeRefi(_fixups_46739);
    _fixups_46739 = _22023;

    /** 	for k = 1 to length(keylist) do*/
    if (IS_SEQUENCE(_63keylist_22829)){
            _24598 = SEQ_PTR(_63keylist_22829)->length;
    }
    else {
        _24598 = 1;
    }
    {
        int _k_46741;
        _k_46741 = 1;
L1: 
        if (_k_46741 > _24598){
            goto L2; // [15] 560
        }

        /** 		kname = keylist[k][K_NAME]*/
        _2 = (int)SEQ_PTR(_63keylist_22829);
        _24599 = (int)*(((s1_ptr)_2)->base + _k_46741);
        DeRef(_kname_46738);
        _2 = (int)SEQ_PTR(_24599);
        _kname_46738 = (int)*(((s1_ptr)_2)->base + 1);
        Ref(_kname_46738);
        _24599 = NOVALUE;

        /** 		len = length(kname)*/
        if (IS_SEQUENCE(_kname_46738)){
                _len_46734 = SEQ_PTR(_kname_46738)->length;
        }
        else {
            _len_46734 = 1;
        }

        /** 		hashval = hashfn(kname)*/
        RefDS(_kname_46738);
        _hashval_46733 = _53hashfn(_kname_46738);
        if (!IS_ATOM_INT(_hashval_46733)) {
            _1 = (long)(DBL_PTR(_hashval_46733)->dbl);
            DeRefDS(_hashval_46733);
            _hashval_46733 = _1;
        }

        /** 		st_index = NewEntry(kname,*/
        _2 = (int)SEQ_PTR(_63keylist_22829);
        _24603 = (int)*(((s1_ptr)_2)->base + _k_46741);
        _2 = (int)SEQ_PTR(_24603);
        _24604 = (int)*(((s1_ptr)_2)->base + 2);
        _24603 = NOVALUE;
        _2 = (int)SEQ_PTR(_63keylist_22829);
        _24605 = (int)*(((s1_ptr)_2)->base + _k_46741);
        _2 = (int)SEQ_PTR(_24605);
        _24606 = (int)*(((s1_ptr)_2)->base + 3);
        _24605 = NOVALUE;
        RefDS(_kname_46738);
        Ref(_24604);
        Ref(_24606);
        _st_index_46737 = _53NewEntry(_kname_46738, 0, _24604, _24606, _hashval_46733, 0, 0);
        _24604 = NOVALUE;
        _24606 = NOVALUE;
        if (!IS_ATOM_INT(_st_index_46737)) {
            _1 = (long)(DBL_PTR(_st_index_46737)->dbl);
            DeRefDS(_st_index_46737);
            _st_index_46737 = _1;
        }

        /** 		if find(keylist[k][K_TOKEN], RTN_TOKS) then*/
        _2 = (int)SEQ_PTR(_63keylist_22829);
        _24608 = (int)*(((s1_ptr)_2)->base + _k_46741);
        _2 = (int)SEQ_PTR(_24608);
        _24609 = (int)*(((s1_ptr)_2)->base + 3);
        _24608 = NOVALUE;
        _24610 = find_from(_24609, _37RTN_TOKS_15870, 1);
        _24609 = NOVALUE;
        if (_24610 == 0)
        {
            _24610 = NOVALUE;
            goto L3; // [110] 325
        }
        else{
            _24610 = NOVALUE;
        }

        /** 			SymTab[st_index] = SymTab[st_index] &*/
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _24611 = (int)*(((s1_ptr)_2)->base + _st_index_46737);
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _24612 = (int)*(((s1_ptr)_2)->base + _st_index_46737);
        if (IS_SEQUENCE(_24612)){
                _24613 = SEQ_PTR(_24612)->length;
        }
        else {
            _24613 = 1;
        }
        _24612 = NOVALUE;
        _24614 = _35SIZEOF_ROUTINE_ENTRY_16043 - _24613;
        _24613 = NOVALUE;
        _24615 = Repeat(0, _24614);
        _24614 = NOVALUE;
        if (IS_SEQUENCE(_24611) && IS_ATOM(_24615)) {
        }
        else if (IS_ATOM(_24611) && IS_SEQUENCE(_24615)) {
            Ref(_24611);
            Prepend(&_24616, _24615, _24611);
        }
        else {
            Concat((object_ptr)&_24616, _24611, _24615);
            _24611 = NOVALUE;
        }
        _24611 = NOVALUE;
        DeRefDS(_24615);
        _24615 = NOVALUE;
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _36SymTab_15242 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _st_index_46737);
        _1 = *(int *)_2;
        *(int *)_2 = _24616;
        if( _1 != _24616 ){
            DeRef(_1);
        }
        _24616 = NOVALUE;

        /** 			SymTab[st_index][S_NUM_ARGS] = keylist[k][K_NUM_ARGS]*/
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _36SymTab_15242 = MAKE_SEQ(_2);
        }
        _3 = (int)(_st_index_46737 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(_63keylist_22829);
        _24619 = (int)*(((s1_ptr)_2)->base + _k_46741);
        _2 = (int)SEQ_PTR(_24619);
        _24620 = (int)*(((s1_ptr)_2)->base + 5);
        _24619 = NOVALUE;
        Ref(_24620);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_35S_NUM_ARGS_15968))
        _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NUM_ARGS_15968)->dbl));
        else
        _2 = (int)(((s1_ptr)_2)->base + _35S_NUM_ARGS_15968);
        _1 = *(int *)_2;
        *(int *)_2 = _24620;
        if( _1 != _24620 ){
            DeRef(_1);
        }
        _24620 = NOVALUE;
        _24617 = NOVALUE;

        /** 			SymTab[st_index][S_OPCODE] = keylist[k][K_OPCODE]*/
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _36SymTab_15242 = MAKE_SEQ(_2);
        }
        _3 = (int)(_st_index_46737 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(_63keylist_22829);
        _24623 = (int)*(((s1_ptr)_2)->base + _k_46741);
        _2 = (int)SEQ_PTR(_24623);
        _24624 = (int)*(((s1_ptr)_2)->base + 4);
        _24623 = NOVALUE;
        Ref(_24624);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 21);
        _1 = *(int *)_2;
        *(int *)_2 = _24624;
        if( _1 != _24624 ){
            DeRef(_1);
        }
        _24624 = NOVALUE;
        _24621 = NOVALUE;

        /** 			SymTab[st_index][S_EFFECT] = keylist[k][K_EFFECT]*/
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _36SymTab_15242 = MAKE_SEQ(_2);
        }
        _3 = (int)(_st_index_46737 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(_63keylist_22829);
        _24627 = (int)*(((s1_ptr)_2)->base + _k_46741);
        _2 = (int)SEQ_PTR(_24627);
        _24628 = (int)*(((s1_ptr)_2)->base + 6);
        _24627 = NOVALUE;
        Ref(_24628);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 23);
        _1 = *(int *)_2;
        *(int *)_2 = _24628;
        if( _1 != _24628 ){
            DeRef(_1);
        }
        _24628 = NOVALUE;
        _24625 = NOVALUE;

        /** 			SymTab[st_index][S_REFLIST] = {}*/
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _36SymTab_15242 = MAKE_SEQ(_2);
        }
        _3 = (int)(_st_index_46737 + ((s1_ptr)_2)->base);
        RefDS(_22023);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 24);
        _1 = *(int *)_2;
        *(int *)_2 = _22023;
        DeRef(_1);
        _24629 = NOVALUE;

        /** 			if length(keylist[k]) > K_EFFECT then*/
        _2 = (int)SEQ_PTR(_63keylist_22829);
        _24631 = (int)*(((s1_ptr)_2)->base + _k_46741);
        if (IS_SEQUENCE(_24631)){
                _24632 = SEQ_PTR(_24631)->length;
        }
        else {
            _24632 = 1;
        }
        _24631 = NOVALUE;
        if (_24632 <= 6)
        goto L4; // [259] 324

        /** 			    SymTab[st_index][S_CODE] = keylist[k][K_CODE]*/
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _36SymTab_15242 = MAKE_SEQ(_2);
        }
        _3 = (int)(_st_index_46737 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(_63keylist_22829);
        _24636 = (int)*(((s1_ptr)_2)->base + _k_46741);
        _2 = (int)SEQ_PTR(_24636);
        _24637 = (int)*(((s1_ptr)_2)->base + 7);
        _24636 = NOVALUE;
        Ref(_24637);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_35S_CODE_15929))
        _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_CODE_15929)->dbl));
        else
        _2 = (int)(((s1_ptr)_2)->base + _35S_CODE_15929);
        _1 = *(int *)_2;
        *(int *)_2 = _24637;
        if( _1 != _24637 ){
            DeRef(_1);
        }
        _24637 = NOVALUE;
        _24634 = NOVALUE;

        /** 			    SymTab[st_index][S_DEF_ARGS] = keylist[k][K_DEF_ARGS]*/
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _36SymTab_15242 = MAKE_SEQ(_2);
        }
        _3 = (int)(_st_index_46737 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(_63keylist_22829);
        _24640 = (int)*(((s1_ptr)_2)->base + _k_46741);
        _2 = (int)SEQ_PTR(_24640);
        _24641 = (int)*(((s1_ptr)_2)->base + 8);
        _24640 = NOVALUE;
        Ref(_24641);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 28);
        _1 = *(int *)_2;
        *(int *)_2 = _24641;
        if( _1 != _24641 ){
            DeRef(_1);
        }
        _24641 = NOVALUE;
        _24638 = NOVALUE;

        /** 			    fixups &= st_index*/
        Append(&_fixups_46739, _fixups_46739, _st_index_46737);
L4: 
L3: 

        /** 		if keylist[k][K_TOKEN] = PROC then*/
        _2 = (int)SEQ_PTR(_63keylist_22829);
        _24643 = (int)*(((s1_ptr)_2)->base + _k_46741);
        _2 = (int)SEQ_PTR(_24643);
        _24644 = (int)*(((s1_ptr)_2)->base + 3);
        _24643 = NOVALUE;
        if (binary_op_a(NOTEQ, _24644, 27)){
            _24644 = NOVALUE;
            goto L5; // [341] 365
        }
        _24644 = NOVALUE;

        /** 			if equal(kname, "<TopLevel>") then*/
        if (_kname_46738 == _24646)
        _24647 = 1;
        else if (IS_ATOM_INT(_kname_46738) && IS_ATOM_INT(_24646))
        _24647 = 0;
        else
        _24647 = (compare(_kname_46738, _24646) == 0);
        if (_24647 == 0)
        {
            _24647 = NOVALUE;
            goto L6; // [351] 462
        }
        else{
            _24647 = NOVALUE;
        }

        /** 				TopLevelSub = st_index*/
        _35TopLevelSub_16251 = _st_index_46737;
        goto L6; // [362] 462
L5: 

        /** 		elsif keylist[k][K_TOKEN] = TYPE then*/
        _2 = (int)SEQ_PTR(_63keylist_22829);
        _24648 = (int)*(((s1_ptr)_2)->base + _k_46741);
        _2 = (int)SEQ_PTR(_24648);
        _24649 = (int)*(((s1_ptr)_2)->base + 3);
        _24648 = NOVALUE;
        if (binary_op_a(NOTEQ, _24649, 504)){
            _24649 = NOVALUE;
            goto L7; // [381] 461
        }
        _24649 = NOVALUE;

        /** 			if equal(kname, "object") then*/
        if (_kname_46738 == _24651)
        _24652 = 1;
        else if (IS_ATOM_INT(_kname_46738) && IS_ATOM_INT(_24651))
        _24652 = 0;
        else
        _24652 = (compare(_kname_46738, _24651) == 0);
        if (_24652 == 0)
        {
            _24652 = NOVALUE;
            goto L8; // [391] 404
        }
        else{
            _24652 = NOVALUE;
        }

        /** 				object_type = st_index*/
        _53object_type_46091 = _st_index_46737;
        goto L9; // [401] 460
L8: 

        /** 			elsif equal(kname, "atom") then*/
        if (_kname_46738 == _24653)
        _24654 = 1;
        else if (IS_ATOM_INT(_kname_46738) && IS_ATOM_INT(_24653))
        _24654 = 0;
        else
        _24654 = (compare(_kname_46738, _24653) == 0);
        if (_24654 == 0)
        {
            _24654 = NOVALUE;
            goto LA; // [410] 423
        }
        else{
            _24654 = NOVALUE;
        }

        /** 				atom_type = st_index*/
        _53atom_type_46093 = _st_index_46737;
        goto L9; // [420] 460
LA: 

        /** 			elsif equal(kname, "integer") then*/
        if (_kname_46738 == _24655)
        _24656 = 1;
        else if (IS_ATOM_INT(_kname_46738) && IS_ATOM_INT(_24655))
        _24656 = 0;
        else
        _24656 = (compare(_kname_46738, _24655) == 0);
        if (_24656 == 0)
        {
            _24656 = NOVALUE;
            goto LB; // [429] 442
        }
        else{
            _24656 = NOVALUE;
        }

        /** 				integer_type = st_index*/
        _53integer_type_46097 = _st_index_46737;
        goto L9; // [439] 460
LB: 

        /** 			elsif equal(kname, "sequence") then*/
        if (_kname_46738 == _24657)
        _24658 = 1;
        else if (IS_ATOM_INT(_kname_46738) && IS_ATOM_INT(_24657))
        _24658 = 0;
        else
        _24658 = (compare(_kname_46738, _24657) == 0);
        if (_24658 == 0)
        {
            _24658 = NOVALUE;
            goto LC; // [448] 459
        }
        else{
            _24658 = NOVALUE;
        }

        /** 				sequence_type = st_index*/
        _53sequence_type_46095 = _st_index_46737;
LC: 
L9: 
L7: 
L6: 

        /** 		if buckets[hashval] = 0 then*/
        _2 = (int)SEQ_PTR(_53buckets_46087);
        _24659 = (int)*(((s1_ptr)_2)->base + _hashval_46733);
        if (binary_op_a(NOTEQ, _24659, 0)){
            _24659 = NOVALUE;
            goto LD; // [470] 485
        }
        _24659 = NOVALUE;

        /** 			buckets[hashval] = st_index*/
        _2 = (int)SEQ_PTR(_53buckets_46087);
        _2 = (int)(((s1_ptr)_2)->base + _hashval_46733);
        _1 = *(int *)_2;
        *(int *)_2 = _st_index_46737;
        DeRef(_1);
        goto LE; // [482] 553
LD: 

        /** 			s = buckets[hashval]*/
        _2 = (int)SEQ_PTR(_53buckets_46087);
        _s_46736 = (int)*(((s1_ptr)_2)->base + _hashval_46733);
        if (!IS_ATOM_INT(_s_46736)){
            _s_46736 = (long)DBL_PTR(_s_46736)->dbl;
        }

        /** 			while SymTab[s][S_SAMEHASH] != 0 do*/
LF: 
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _24662 = (int)*(((s1_ptr)_2)->base + _s_46736);
        _2 = (int)SEQ_PTR(_24662);
        _24663 = (int)*(((s1_ptr)_2)->base + 9);
        _24662 = NOVALUE;
        if (binary_op_a(EQUALS, _24663, 0)){
            _24663 = NOVALUE;
            goto L10; // [512] 537
        }
        _24663 = NOVALUE;

        /** 				s = SymTab[s][S_SAMEHASH]*/
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _24665 = (int)*(((s1_ptr)_2)->base + _s_46736);
        _2 = (int)SEQ_PTR(_24665);
        _s_46736 = (int)*(((s1_ptr)_2)->base + 9);
        if (!IS_ATOM_INT(_s_46736)){
            _s_46736 = (long)DBL_PTR(_s_46736)->dbl;
        }
        _24665 = NOVALUE;

        /** 			end while*/
        goto LF; // [534] 500
L10: 

        /** 			SymTab[s][S_SAMEHASH] = st_index*/
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _36SymTab_15242 = MAKE_SEQ(_2);
        }
        _3 = (int)(_s_46736 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 9);
        _1 = *(int *)_2;
        *(int *)_2 = _st_index_46737;
        DeRef(_1);
        _24667 = NOVALUE;
LE: 

        /** 	end for*/
        _k_46741 = _k_46741 + 1;
        goto L1; // [555] 22
L2: 
        ;
    }

    /** 	file_start_sym = length(SymTab)*/
    if (IS_SEQUENCE(_36SymTab_15242)){
            _35file_start_sym_16250 = SEQ_PTR(_36SymTab_15242)->length;
    }
    else {
        _35file_start_sym_16250 = 1;
    }

    /** 	sequence si, sj*/

    /** 	CurrentSub = TopLevelSub*/
    _35CurrentSub_16252 = _35TopLevelSub_16251;

    /** 	for i=1 to length(fixups) do*/
    if (IS_SEQUENCE(_fixups_46739)){
            _24670 = SEQ_PTR(_fixups_46739)->length;
    }
    else {
        _24670 = 1;
    }
    {
        int _i_46884;
        _i_46884 = 1;
L11: 
        if (_i_46884 > _24670){
            goto L12; // [585] 945
        }

        /** 	    si = SymTab[fixups[i]][S_CODE] -- seq of either 0's or sequences of tokens*/
        _2 = (int)SEQ_PTR(_fixups_46739);
        _24671 = (int)*(((s1_ptr)_2)->base + _i_46884);
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _24672 = (int)*(((s1_ptr)_2)->base + _24671);
        DeRef(_si_46879);
        _2 = (int)SEQ_PTR(_24672);
        if (!IS_ATOM_INT(_35S_CODE_15929)){
            _si_46879 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_CODE_15929)->dbl));
        }
        else{
            _si_46879 = (int)*(((s1_ptr)_2)->base + _35S_CODE_15929);
        }
        Ref(_si_46879);
        _24672 = NOVALUE;

        /** 	    for j=1 to length(si) do*/
        if (IS_SEQUENCE(_si_46879)){
                _24674 = SEQ_PTR(_si_46879)->length;
        }
        else {
            _24674 = 1;
        }
        {
            int _j_46892;
            _j_46892 = 1;
L13: 
            if (_j_46892 > _24674){
                goto L14; // [617] 919
            }

            /** 	        if sequence(si[j]) then*/
            _2 = (int)SEQ_PTR(_si_46879);
            _24675 = (int)*(((s1_ptr)_2)->base + _j_46892);
            _24676 = IS_SEQUENCE(_24675);
            _24675 = NOVALUE;
            if (_24676 == 0)
            {
                _24676 = NOVALUE;
                goto L15; // [633] 912
            }
            else{
                _24676 = NOVALUE;
            }

            /** 	            sj = si[j] -- a sequence of tokens*/
            DeRef(_sj_46880);
            _2 = (int)SEQ_PTR(_si_46879);
            _sj_46880 = (int)*(((s1_ptr)_2)->base + _j_46892);
            Ref(_sj_46880);

            /** 				for ij=1 to length(sj) do*/
            if (IS_SEQUENCE(_sj_46880)){
                    _24678 = SEQ_PTR(_sj_46880)->length;
            }
            else {
                _24678 = 1;
            }
            {
                int _ij_46899;
                _ij_46899 = 1;
L16: 
                if (_ij_46899 > _24678){
                    goto L17; // [649] 905
                }

                /** 	                switch sj[ij][T_ID] with fallthru do*/
                _2 = (int)SEQ_PTR(_sj_46880);
                _24679 = (int)*(((s1_ptr)_2)->base + _ij_46899);
                _2 = (int)SEQ_PTR(_24679);
                _24680 = (int)*(((s1_ptr)_2)->base + 1);
                _24679 = NOVALUE;
                if (IS_SEQUENCE(_24680) ){
                    goto L18; // [668] 898
                }
                if(!IS_ATOM_INT(_24680)){
                    if( (DBL_PTR(_24680)->dbl != (double) ((int) DBL_PTR(_24680)->dbl) ) ){
                        goto L18; // [668] 898
                    }
                    _0 = (int) DBL_PTR(_24680)->dbl;
                }
                else {
                    _0 = _24680;
                };
                _24680 = NOVALUE;
                switch ( _0 ){ 

                    /** 	                    case ATOM then -- must create a lasting temp*/
                    case 502:

                    /** 	                    	if integer(sj[ij][T_SYM]) then*/
                    _2 = (int)SEQ_PTR(_sj_46880);
                    _24683 = (int)*(((s1_ptr)_2)->base + _ij_46899);
                    _2 = (int)SEQ_PTR(_24683);
                    _24684 = (int)*(((s1_ptr)_2)->base + 2);
                    _24683 = NOVALUE;
                    if (IS_ATOM_INT(_24684))
                    _24685 = 1;
                    else if (IS_ATOM_DBL(_24684))
                    _24685 = IS_ATOM_INT(DoubleToInt(_24684));
                    else
                    _24685 = 0;
                    _24684 = NOVALUE;
                    if (_24685 == 0)
                    {
                        _24685 = NOVALUE;
                        goto L19; // [692] 716
                    }
                    else{
                        _24685 = NOVALUE;
                    }

                    /** 								st_index = NewIntSym(sj[ij][T_SYM])*/
                    _2 = (int)SEQ_PTR(_sj_46880);
                    _24686 = (int)*(((s1_ptr)_2)->base + _ij_46899);
                    _2 = (int)SEQ_PTR(_24686);
                    _24687 = (int)*(((s1_ptr)_2)->base + 2);
                    _24686 = NOVALUE;
                    Ref(_24687);
                    _st_index_46737 = _53NewIntSym(_24687);
                    _24687 = NOVALUE;
                    if (!IS_ATOM_INT(_st_index_46737)) {
                        _1 = (long)(DBL_PTR(_st_index_46737)->dbl);
                        DeRefDS(_st_index_46737);
                        _st_index_46737 = _1;
                    }
                    goto L1A; // [713] 735
L19: 

                    /** 								st_index = NewDoubleSym(sj[ij][T_SYM])*/
                    _2 = (int)SEQ_PTR(_sj_46880);
                    _24689 = (int)*(((s1_ptr)_2)->base + _ij_46899);
                    _2 = (int)SEQ_PTR(_24689);
                    _24690 = (int)*(((s1_ptr)_2)->base + 2);
                    _24689 = NOVALUE;
                    Ref(_24690);
                    _st_index_46737 = _53NewDoubleSym(_24690);
                    _24690 = NOVALUE;
                    if (!IS_ATOM_INT(_st_index_46737)) {
                        _1 = (long)(DBL_PTR(_st_index_46737)->dbl);
                        DeRefDS(_st_index_46737);
                        _st_index_46737 = _1;
                    }
L1A: 

                    /** 							SymTab[st_index][S_SCOPE] = IN_USE -- TempKeep()*/
                    _2 = (int)SEQ_PTR(_36SymTab_15242);
                    if (!UNIQUE(_2)) {
                        _2 = (int)SequenceCopy((s1_ptr)_2);
                        _36SymTab_15242 = MAKE_SEQ(_2);
                    }
                    _3 = (int)(_st_index_46737 + ((s1_ptr)_2)->base);
                    _2 = (int)SEQ_PTR(*(int *)_3);
                    if (!UNIQUE(_2)) {
                        _2 = (int)SequenceCopy((s1_ptr)_2);
                        *(int *)_3 = MAKE_SEQ(_2);
                    }
                    _2 = (int)(((s1_ptr)_2)->base + 4);
                    _1 = *(int *)_2;
                    *(int *)_2 = 1;
                    DeRef(_1);
                    _24692 = NOVALUE;

                    /** 							sj[ij][T_SYM] = st_index*/
                    _2 = (int)SEQ_PTR(_sj_46880);
                    if (!UNIQUE(_2)) {
                        _2 = (int)SequenceCopy((s1_ptr)_2);
                        _sj_46880 = MAKE_SEQ(_2);
                    }
                    _3 = (int)(_ij_46899 + ((s1_ptr)_2)->base);
                    _2 = (int)SEQ_PTR(*(int *)_3);
                    if (!UNIQUE(_2)) {
                        _2 = (int)SequenceCopy((s1_ptr)_2);
                        *(int *)_3 = MAKE_SEQ(_2);
                    }
                    _2 = (int)(((s1_ptr)_2)->base + 2);
                    _1 = *(int *)_2;
                    *(int *)_2 = _st_index_46737;
                    DeRef(_1);
                    _24694 = NOVALUE;

                    /** 							break*/
                    goto L18; // [769] 898

                    /** 						case STRING then -- same*/
                    case 503:

                    /** 	                    	st_index = NewStringSym(sj[ij][T_SYM])*/
                    _2 = (int)SEQ_PTR(_sj_46880);
                    _24696 = (int)*(((s1_ptr)_2)->base + _ij_46899);
                    _2 = (int)SEQ_PTR(_24696);
                    _24697 = (int)*(((s1_ptr)_2)->base + 2);
                    _24696 = NOVALUE;
                    Ref(_24697);
                    _st_index_46737 = _53NewStringSym(_24697);
                    _24697 = NOVALUE;
                    if (!IS_ATOM_INT(_st_index_46737)) {
                        _1 = (long)(DBL_PTR(_st_index_46737)->dbl);
                        DeRefDS(_st_index_46737);
                        _st_index_46737 = _1;
                    }

                    /** 							SymTab[st_index][S_SCOPE] = IN_USE -- TempKeep()*/
                    _2 = (int)SEQ_PTR(_36SymTab_15242);
                    if (!UNIQUE(_2)) {
                        _2 = (int)SequenceCopy((s1_ptr)_2);
                        _36SymTab_15242 = MAKE_SEQ(_2);
                    }
                    _3 = (int)(_st_index_46737 + ((s1_ptr)_2)->base);
                    _2 = (int)SEQ_PTR(*(int *)_3);
                    if (!UNIQUE(_2)) {
                        _2 = (int)SequenceCopy((s1_ptr)_2);
                        *(int *)_3 = MAKE_SEQ(_2);
                    }
                    _2 = (int)(((s1_ptr)_2)->base + 4);
                    _1 = *(int *)_2;
                    *(int *)_2 = 1;
                    DeRef(_1);
                    _24699 = NOVALUE;

                    /** 							sj[ij][T_SYM] = st_index*/
                    _2 = (int)SEQ_PTR(_sj_46880);
                    if (!UNIQUE(_2)) {
                        _2 = (int)SequenceCopy((s1_ptr)_2);
                        _sj_46880 = MAKE_SEQ(_2);
                    }
                    _3 = (int)(_ij_46899 + ((s1_ptr)_2)->base);
                    _2 = (int)SEQ_PTR(*(int *)_3);
                    if (!UNIQUE(_2)) {
                        _2 = (int)SequenceCopy((s1_ptr)_2);
                        *(int *)_3 = MAKE_SEQ(_2);
                    }
                    _2 = (int)(((s1_ptr)_2)->base + 2);
                    _1 = *(int *)_2;
                    *(int *)_2 = _st_index_46737;
                    DeRef(_1);
                    _24701 = NOVALUE;

                    /** 							break*/
                    goto L18; // [825] 898

                    /** 						case BUILT_IN then -- name of a builtin in econd field*/
                    case 511:

                    /**                             sj[ij] = keyfind(sj[ij][T_SYM],-1)*/
                    _2 = (int)SEQ_PTR(_sj_46880);
                    _24703 = (int)*(((s1_ptr)_2)->base + _ij_46899);
                    _2 = (int)SEQ_PTR(_24703);
                    _24704 = (int)*(((s1_ptr)_2)->base + 2);
                    _24703 = NOVALUE;
                    Ref(_24704);
                    DeRef(_25179);
                    _25179 = _24704;
                    _25180 = _53hashfn(_25179);
                    _25179 = NOVALUE;
                    Ref(_24704);
                    _24705 = _53keyfind(_24704, -1, _35current_file_no_16244, 0, _25180);
                    _24704 = NOVALUE;
                    _25180 = NOVALUE;
                    _2 = (int)SEQ_PTR(_sj_46880);
                    if (!UNIQUE(_2)) {
                        _2 = (int)SequenceCopy((s1_ptr)_2);
                        _sj_46880 = MAKE_SEQ(_2);
                    }
                    _2 = (int)(((s1_ptr)_2)->base + _ij_46899);
                    _1 = *(int *)_2;
                    *(int *)_2 = _24705;
                    if( _1 != _24705 ){
                        DeRef(_1);
                    }
                    _24705 = NOVALUE;

                    /** 							break*/
                    goto L18; // [866] 898

                    /** 						case DEF_PARAM then*/
                    case 510:

                    /** 							sj[ij][T_SYM] &= fixups[i]*/
                    _2 = (int)SEQ_PTR(_sj_46880);
                    if (!UNIQUE(_2)) {
                        _2 = (int)SequenceCopy((s1_ptr)_2);
                        _sj_46880 = MAKE_SEQ(_2);
                    }
                    _3 = (int)(_ij_46899 + ((s1_ptr)_2)->base);
                    _2 = (int)SEQ_PTR(_fixups_46739);
                    _24708 = (int)*(((s1_ptr)_2)->base + _i_46884);
                    _2 = (int)SEQ_PTR(*(int *)_3);
                    _24709 = (int)*(((s1_ptr)_2)->base + 2);
                    _24706 = NOVALUE;
                    if (IS_SEQUENCE(_24709) && IS_ATOM(_24708)) {
                        Append(&_24710, _24709, _24708);
                    }
                    else if (IS_ATOM(_24709) && IS_SEQUENCE(_24708)) {
                    }
                    else {
                        Concat((object_ptr)&_24710, _24709, _24708);
                        _24709 = NOVALUE;
                    }
                    _24709 = NOVALUE;
                    _24708 = NOVALUE;
                    _2 = (int)SEQ_PTR(*(int *)_3);
                    if (!UNIQUE(_2)) {
                        _2 = (int)SequenceCopy((s1_ptr)_2);
                        *(int *)_3 = MAKE_SEQ(_2);
                    }
                    _2 = (int)(((s1_ptr)_2)->base + 2);
                    _1 = *(int *)_2;
                    *(int *)_2 = _24710;
                    if( _1 != _24710 ){
                        DeRef(_1);
                    }
                    _24710 = NOVALUE;
                    _24706 = NOVALUE;
                ;}L18: 

                /** 				end for*/
                _ij_46899 = _ij_46899 + 1;
                goto L16; // [900] 656
L17: 
                ;
            }

            /** 				si[j] = sj*/
            RefDS(_sj_46880);
            _2 = (int)SEQ_PTR(_si_46879);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _si_46879 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _j_46892);
            _1 = *(int *)_2;
            *(int *)_2 = _sj_46880;
            DeRef(_1);
L15: 

            /** 		end for*/
            _j_46892 = _j_46892 + 1;
            goto L13; // [914] 624
L14: 
            ;
        }

        /** 		SymTab[fixups[i]][S_CODE] = si*/
        _2 = (int)SEQ_PTR(_fixups_46739);
        _24711 = (int)*(((s1_ptr)_2)->base + _i_46884);
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _36SymTab_15242 = MAKE_SEQ(_2);
        }
        _3 = (int)(_24711 + ((s1_ptr)_2)->base);
        RefDS(_si_46879);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_35S_CODE_15929))
        _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_CODE_15929)->dbl));
        else
        _2 = (int)(((s1_ptr)_2)->base + _35S_CODE_15929);
        _1 = *(int *)_2;
        *(int *)_2 = _si_46879;
        DeRef(_1);
        _24712 = NOVALUE;

        /** 	end for*/
        _i_46884 = _i_46884 + 1;
        goto L11; // [940] 592
L12: 
        ;
    }

    /** end procedure*/
    DeRef(_kname_46738);
    DeRefi(_fixups_46739);
    DeRef(_si_46879);
    DeRef(_sj_46880);
    _24631 = NOVALUE;
    _24612 = NOVALUE;
    _24671 = NOVALUE;
    _24711 = NOVALUE;
    return;
    ;
}


void _53add_ref(int _tok_46967)
{
    int _s_46969 = NOVALUE;
    int _24728 = NOVALUE;
    int _24727 = NOVALUE;
    int _24725 = NOVALUE;
    int _24724 = NOVALUE;
    int _24723 = NOVALUE;
    int _24721 = NOVALUE;
    int _24720 = NOVALUE;
    int _24719 = NOVALUE;
    int _24718 = NOVALUE;
    int _24717 = NOVALUE;
    int _24716 = NOVALUE;
    int _24715 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	s = tok[T_SYM]*/
    _2 = (int)SEQ_PTR(_tok_46967);
    _s_46969 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_46969)){
        _s_46969 = (long)DBL_PTR(_s_46969)->dbl;
    }

    /** 	if s != CurrentSub and -- ignore self-ref's*/
    _24715 = (_s_46969 != _35CurrentSub_16252);
    if (_24715 == 0) {
        goto L1; // [19] 98
    }
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _24717 = (int)*(((s1_ptr)_2)->base + _35CurrentSub_16252);
    _2 = (int)SEQ_PTR(_24717);
    _24718 = (int)*(((s1_ptr)_2)->base + 24);
    _24717 = NOVALUE;
    _24719 = find_from(_s_46969, _24718, 1);
    _24718 = NOVALUE;
    _24720 = (_24719 == 0);
    _24719 = NOVALUE;
    if (_24720 == 0)
    {
        DeRef(_24720);
        _24720 = NOVALUE;
        goto L1; // [46] 98
    }
    else{
        DeRef(_24720);
        _24720 = NOVALUE;
    }

    /** 		SymTab[s][S_NREFS] += 1*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_s_46969 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    _24723 = (int)*(((s1_ptr)_2)->base + 12);
    _24721 = NOVALUE;
    if (IS_ATOM_INT(_24723)) {
        _24724 = _24723 + 1;
        if (_24724 > MAXINT){
            _24724 = NewDouble((double)_24724);
        }
    }
    else
    _24724 = binary_op(PLUS, 1, _24723);
    _24723 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 12);
    _1 = *(int *)_2;
    *(int *)_2 = _24724;
    if( _1 != _24724 ){
        DeRef(_1);
    }
    _24724 = NOVALUE;
    _24721 = NOVALUE;

    /** 		SymTab[CurrentSub][S_REFLIST] &= s*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_35CurrentSub_16252 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    _24727 = (int)*(((s1_ptr)_2)->base + 24);
    _24725 = NOVALUE;
    if (IS_SEQUENCE(_24727) && IS_ATOM(_s_46969)) {
        Append(&_24728, _24727, _s_46969);
    }
    else if (IS_ATOM(_24727) && IS_SEQUENCE(_s_46969)) {
    }
    else {
        Concat((object_ptr)&_24728, _24727, _s_46969);
        _24727 = NOVALUE;
    }
    _24727 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 24);
    _1 = *(int *)_2;
    *(int *)_2 = _24728;
    if( _1 != _24728 ){
        DeRef(_1);
    }
    _24728 = NOVALUE;
    _24725 = NOVALUE;
L1: 

    /** end procedure*/
    DeRef(_tok_46967);
    DeRef(_24715);
    _24715 = NOVALUE;
    return;
    ;
}


void _53mark_all(int _attribute_46999)
{
    int _p_47002 = NOVALUE;
    int _sym_file_47009 = NOVALUE;
    int _scope_47026 = NOVALUE;
    int _24760 = NOVALUE;
    int _24759 = NOVALUE;
    int _24758 = NOVALUE;
    int _24756 = NOVALUE;
    int _24754 = NOVALUE;
    int _24753 = NOVALUE;
    int _24752 = NOVALUE;
    int _24751 = NOVALUE;
    int _24750 = NOVALUE;
    int _24748 = NOVALUE;
    int _24747 = NOVALUE;
    int _24746 = NOVALUE;
    int _24745 = NOVALUE;
    int _24741 = NOVALUE;
    int _24740 = NOVALUE;
    int _24739 = NOVALUE;
    int _24737 = NOVALUE;
    int _24736 = NOVALUE;
    int _24734 = NOVALUE;
    int _24732 = NOVALUE;
    int _24729 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	if just_mark_everything_from then*/
    if (_53just_mark_everything_from_46996 == 0)
    {
        goto L1; // [7] 270
    }
    else{
    }

    /** 		symtab_pointer p = SymTab[just_mark_everything_from][S_NEXT]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _24729 = (int)*(((s1_ptr)_2)->base + _53just_mark_everything_from_46996);
    _2 = (int)SEQ_PTR(_24729);
    _p_47002 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_p_47002)){
        _p_47002 = (long)DBL_PTR(_p_47002)->dbl;
    }
    _24729 = NOVALUE;

    /** 		while p != 0 do*/
L2: 
    if (_p_47002 == 0)
    goto L3; // [33] 269

    /** 			integer sym_file = SymTab[p][S_FILE_NO]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _24732 = (int)*(((s1_ptr)_2)->base + _p_47002);
    _2 = (int)SEQ_PTR(_24732);
    if (!IS_ATOM_INT(_35S_FILE_NO_15913)){
        _sym_file_47009 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FILE_NO_15913)->dbl));
    }
    else{
        _sym_file_47009 = (int)*(((s1_ptr)_2)->base + _35S_FILE_NO_15913);
    }
    if (!IS_ATOM_INT(_sym_file_47009)){
        _sym_file_47009 = (long)DBL_PTR(_sym_file_47009)->dbl;
    }
    _24732 = NOVALUE;

    /** 			just_mark_everything_from = p*/
    _53just_mark_everything_from_46996 = _p_47002;

    /** 			if sym_file = current_file_no or find( sym_file, recheck_files ) then*/
    _24734 = (_sym_file_47009 == _35current_file_no_16244);
    if (_24734 != 0) {
        goto L4; // [68] 84
    }
    _24736 = find_from(_sym_file_47009, _53recheck_files_47069, 1);
    if (_24736 == 0)
    {
        _24736 = NOVALUE;
        goto L5; // [80] 108
    }
    else{
        _24736 = NOVALUE;
    }
L4: 

    /** 				SymTab[p][attribute] += 1*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_47002 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    _24739 = (int)*(((s1_ptr)_2)->base + _attribute_46999);
    _24737 = NOVALUE;
    if (IS_ATOM_INT(_24739)) {
        _24740 = _24739 + 1;
        if (_24740 > MAXINT){
            _24740 = NewDouble((double)_24740);
        }
    }
    else
    _24740 = binary_op(PLUS, 1, _24739);
    _24739 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _attribute_46999);
    _1 = *(int *)_2;
    *(int *)_2 = _24740;
    if( _1 != _24740 ){
        DeRef(_1);
    }
    _24740 = NOVALUE;
    _24737 = NOVALUE;
    goto L6; // [105] 246
L5: 

    /** 				integer scope = SymTab[p][S_SCOPE]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _24741 = (int)*(((s1_ptr)_2)->base + _p_47002);
    _2 = (int)SEQ_PTR(_24741);
    _scope_47026 = (int)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_scope_47026)){
        _scope_47026 = (long)DBL_PTR(_scope_47026)->dbl;
    }
    _24741 = NOVALUE;

    /** 				switch scope with fallthru do*/
    _0 = _scope_47026;
    switch ( _0 ){ 

        /** 					case SC_PUBLIC then*/
        case 13:

        /** 						if and_bits( DIRECT_OR_PUBLIC_INCLUDE, include_matrix[current_file_no][sym_file] ) then*/
        _2 = (int)SEQ_PTR(_36include_matrix_15249);
        _24745 = (int)*(((s1_ptr)_2)->base + _35current_file_no_16244);
        _2 = (int)SEQ_PTR(_24745);
        _24746 = (int)*(((s1_ptr)_2)->base + _sym_file_47009);
        _24745 = NOVALUE;
        if (IS_ATOM_INT(_24746)) {
            {unsigned long tu;
                 tu = (unsigned long)6 & (unsigned long)_24746;
                 _24747 = MAKE_UINT(tu);
            }
        }
        else {
            _24747 = binary_op(AND_BITS, 6, _24746);
        }
        _24746 = NOVALUE;
        if (_24747 == 0) {
            DeRef(_24747);
            _24747 = NOVALUE;
            goto L7; // [155] 243
        }
        else {
            if (!IS_ATOM_INT(_24747) && DBL_PTR(_24747)->dbl == 0.0){
                DeRef(_24747);
                _24747 = NOVALUE;
                goto L7; // [155] 243
            }
            DeRef(_24747);
            _24747 = NOVALUE;
        }
        DeRef(_24747);
        _24747 = NOVALUE;

        /** 							SymTab[p][attribute] += 1*/
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _36SymTab_15242 = MAKE_SEQ(_2);
        }
        _3 = (int)(_p_47002 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        _24750 = (int)*(((s1_ptr)_2)->base + _attribute_46999);
        _24748 = NOVALUE;
        if (IS_ATOM_INT(_24750)) {
            _24751 = _24750 + 1;
            if (_24751 > MAXINT){
                _24751 = NewDouble((double)_24751);
            }
        }
        else
        _24751 = binary_op(PLUS, 1, _24750);
        _24750 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _attribute_46999);
        _1 = *(int *)_2;
        *(int *)_2 = _24751;
        if( _1 != _24751 ){
            DeRef(_1);
        }
        _24751 = NOVALUE;
        _24748 = NOVALUE;

        /** 						break*/
        goto L7; // [182] 243

        /** 					case SC_EXPORT then*/
        case 11:

        /** 						if not and_bits( DIRECT_INCLUDE, include_matrix[current_file_no][sym_file] ) then*/
        _2 = (int)SEQ_PTR(_36include_matrix_15249);
        _24752 = (int)*(((s1_ptr)_2)->base + _35current_file_no_16244);
        _2 = (int)SEQ_PTR(_24752);
        _24753 = (int)*(((s1_ptr)_2)->base + _sym_file_47009);
        _24752 = NOVALUE;
        if (IS_ATOM_INT(_24753)) {
            {unsigned long tu;
                 tu = (unsigned long)2 & (unsigned long)_24753;
                 _24754 = MAKE_UINT(tu);
            }
        }
        else {
            _24754 = binary_op(AND_BITS, 2, _24753);
        }
        _24753 = NOVALUE;
        if (IS_ATOM_INT(_24754)) {
            if (_24754 != 0){
                DeRef(_24754);
                _24754 = NOVALUE;
                goto L8; // [208] 216
            }
        }
        else {
            if (DBL_PTR(_24754)->dbl != 0.0){
                DeRef(_24754);
                _24754 = NOVALUE;
                goto L8; // [208] 216
            }
        }
        DeRef(_24754);
        _24754 = NOVALUE;

        /** 							break*/
        goto L9; // [213] 217
L8: 
L9: 

        /** 					case SC_GLOBAL then*/
        case 6:

        /** 						SymTab[p][attribute] += 1*/
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _36SymTab_15242 = MAKE_SEQ(_2);
        }
        _3 = (int)(_p_47002 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        _24758 = (int)*(((s1_ptr)_2)->base + _attribute_46999);
        _24756 = NOVALUE;
        if (IS_ATOM_INT(_24758)) {
            _24759 = _24758 + 1;
            if (_24759 > MAXINT){
                _24759 = NewDouble((double)_24759);
            }
        }
        else
        _24759 = binary_op(PLUS, 1, _24758);
        _24758 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _attribute_46999);
        _1 = *(int *)_2;
        *(int *)_2 = _24759;
        if( _1 != _24759 ){
            DeRef(_1);
        }
        _24759 = NOVALUE;
        _24756 = NOVALUE;
    ;}L7: 
L6: 

    /** 			p = SymTab[p][S_NEXT]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _24760 = (int)*(((s1_ptr)_2)->base + _p_47002);
    _2 = (int)SEQ_PTR(_24760);
    _p_47002 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_p_47002)){
        _p_47002 = (long)DBL_PTR(_p_47002)->dbl;
    }
    _24760 = NOVALUE;

    /** 		end while*/
    goto L2; // [266] 33
L3: 
L1: 

    /** end procedure*/
    DeRef(_24734);
    _24734 = NOVALUE;
    return;
    ;
}


void _53mark_final_targets()
{
    int _marked_47084 = NOVALUE;
    int _24766 = NOVALUE;
    int _24764 = NOVALUE;
    int _24763 = NOVALUE;
    int _24762 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if just_mark_everything_from then*/
    if (_53just_mark_everything_from_46996 == 0)
    {
        goto L1; // [5] 44
    }
    else{
    }

    /** 		if TRANSLATE then*/
    if (_35TRANSLATE_15887 == 0)
    {
        goto L2; // [12] 25
    }
    else{
    }

    /** 			mark_all( S_RI_TARGET )*/
    _53mark_all(53);
    goto L3; // [22] 152
L2: 

    /** 		elsif BIND then*/
    if (_35BIND_15890 == 0)
    {
        goto L3; // [29] 152
    }
    else{
    }

    /** 			mark_all( S_NREFS )*/
    _53mark_all(12);
    goto L3; // [41] 152
L1: 

    /** 	elsif length( recheck_targets ) then*/
    if (IS_SEQUENCE(_53recheck_targets_47068)){
            _24762 = SEQ_PTR(_53recheck_targets_47068)->length;
    }
    else {
        _24762 = 1;
    }
    if (_24762 == 0)
    {
        _24762 = NOVALUE;
        goto L4; // [51] 151
    }
    else{
        _24762 = NOVALUE;
    }

    /** 		for i = length( recheck_targets ) to 1 by -1 do*/
    if (IS_SEQUENCE(_53recheck_targets_47068)){
            _24763 = SEQ_PTR(_53recheck_targets_47068)->length;
    }
    else {
        _24763 = 1;
    }
    {
        int _i_47082;
        _i_47082 = _24763;
L5: 
        if (_i_47082 < 1){
            goto L6; // [61] 150
        }

        /** 			integer marked = 0*/
        _marked_47084 = 0;

        /** 			if TRANSLATE then*/
        if (_35TRANSLATE_15887 == 0)
        {
            goto L7; // [77] 100
        }
        else{
        }

        /** 				marked = MarkTargets( recheck_targets[i], S_RI_TARGET )*/
        _2 = (int)SEQ_PTR(_53recheck_targets_47068);
        _24764 = (int)*(((s1_ptr)_2)->base + _i_47082);
        Ref(_24764);
        _marked_47084 = _53MarkTargets(_24764, 53);
        _24764 = NOVALUE;
        if (!IS_ATOM_INT(_marked_47084)) {
            _1 = (long)(DBL_PTR(_marked_47084)->dbl);
            DeRefDS(_marked_47084);
            _marked_47084 = _1;
        }
        goto L8; // [97] 126
L7: 

        /** 			elsif BIND then*/
        if (_35BIND_15890 == 0)
        {
            goto L9; // [104] 125
        }
        else{
        }

        /** 				marked = MarkTargets( recheck_targets[i], S_NREFS )*/
        _2 = (int)SEQ_PTR(_53recheck_targets_47068);
        _24766 = (int)*(((s1_ptr)_2)->base + _i_47082);
        Ref(_24766);
        _marked_47084 = _53MarkTargets(_24766, 12);
        _24766 = NOVALUE;
        if (!IS_ATOM_INT(_marked_47084)) {
            _1 = (long)(DBL_PTR(_marked_47084)->dbl);
            DeRefDS(_marked_47084);
            _marked_47084 = _1;
        }
L9: 
L8: 

        /** 			if marked then*/
        if (_marked_47084 == 0)
        {
            goto LA; // [128] 141
        }
        else{
        }

        /** 				recheck_targets = remove( recheck_targets, i )*/
        {
            s1_ptr assign_space = SEQ_PTR(_53recheck_targets_47068);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_i_47082)) ? _i_47082 : (long)(DBL_PTR(_i_47082)->dbl);
            int stop = (IS_ATOM_INT(_i_47082)) ? _i_47082 : (long)(DBL_PTR(_i_47082)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<0) {
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_53recheck_targets_47068), start, &_53recheck_targets_47068 );
                }
                else Tail(SEQ_PTR(_53recheck_targets_47068), stop+1, &_53recheck_targets_47068);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_53recheck_targets_47068), start, &_53recheck_targets_47068);
            }
            else {
                assign_slice_seq = &assign_space;
                _53recheck_targets_47068 = Remove_elements(start, stop, (SEQ_PTR(_53recheck_targets_47068)->ref == 1));
            }
        }
LA: 

        /** 		end for*/
        _i_47082 = _i_47082 + -1;
        goto L5; // [145] 68
L6: 
        ;
    }
L4: 
L3: 

    /** end procedure*/
    return;
    ;
}


int _53is_routine(int _sym_47102)
{
    int _tok_47103 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer tok = sym_token( sym )*/
    _tok_47103 = _53sym_token(_sym_47102);
    if (!IS_ATOM_INT(_tok_47103)) {
        _1 = (long)(DBL_PTR(_tok_47103)->dbl);
        DeRefDS(_tok_47103);
        _tok_47103 = _1;
    }

    /** 	switch tok do*/
    _0 = _tok_47103;
    switch ( _0 ){ 

        /** 		case FUNC, PROC, TYPE then*/
        case 501:
        case 27:
        case 504:

        /** 			return 1*/
        return 1;
        goto L1; // [32] 45

        /** 		case else*/
        default:

        /** 			return 0*/
        return 0;
    ;}L1: 
    ;
}


int _53is_visible(int _sym_47116, int _from_file_47117)
{
    int _scope_47118 = NOVALUE;
    int _sym_file_47121 = NOVALUE;
    int _visible_mask_47126 = NOVALUE;
    int _24780 = NOVALUE;
    int _24779 = NOVALUE;
    int _24778 = NOVALUE;
    int _24777 = NOVALUE;
    int _24773 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer scope = sym_scope( sym )*/
    _scope_47118 = _53sym_scope(_sym_47116);
    if (!IS_ATOM_INT(_scope_47118)) {
        _1 = (long)(DBL_PTR(_scope_47118)->dbl);
        DeRefDS(_scope_47118);
        _scope_47118 = _1;
    }

    /** 	integer sym_file = SymTab[sym][S_FILE_NO]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _24773 = (int)*(((s1_ptr)_2)->base + _sym_47116);
    _2 = (int)SEQ_PTR(_24773);
    if (!IS_ATOM_INT(_35S_FILE_NO_15913)){
        _sym_file_47121 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FILE_NO_15913)->dbl));
    }
    else{
        _sym_file_47121 = (int)*(((s1_ptr)_2)->base + _35S_FILE_NO_15913);
    }
    if (!IS_ATOM_INT(_sym_file_47121)){
        _sym_file_47121 = (long)DBL_PTR(_sym_file_47121)->dbl;
    }
    _24773 = NOVALUE;

    /** 	switch scope do*/
    _0 = _scope_47118;
    switch ( _0 ){ 

        /** 		case SC_PUBLIC then*/
        case 13:

        /** 			visible_mask = DIRECT_OR_PUBLIC_INCLUDE*/
        _visible_mask_47126 = 6;
        goto L1; // [49] 93

        /** 		case SC_EXPORT then*/
        case 11:

        /** 			visible_mask = DIRECT_INCLUDE*/
        _visible_mask_47126 = 2;
        goto L1; // [64] 93

        /** 		case SC_GLOBAL then*/
        case 6:

        /** 			return 1*/
        return 1;
        goto L1; // [76] 93

        /** 		case else*/
        default:

        /** 			return from_file = sym_file*/
        _24777 = (_from_file_47117 == _sym_file_47121);
        return _24777;
    ;}L1: 

    /** 	return and_bits( visible_mask, include_matrix[from_file][sym_file] )*/
    _2 = (int)SEQ_PTR(_36include_matrix_15249);
    _24778 = (int)*(((s1_ptr)_2)->base + _from_file_47117);
    _2 = (int)SEQ_PTR(_24778);
    _24779 = (int)*(((s1_ptr)_2)->base + _sym_file_47121);
    _24778 = NOVALUE;
    if (IS_ATOM_INT(_24779)) {
        {unsigned long tu;
             tu = (unsigned long)_visible_mask_47126 & (unsigned long)_24779;
             _24780 = MAKE_UINT(tu);
        }
    }
    else {
        _24780 = binary_op(AND_BITS, _visible_mask_47126, _24779);
    }
    _24779 = NOVALUE;
    DeRef(_24777);
    _24777 = NOVALUE;
    return _24780;
    ;
}


int _53MarkTargets(int _s_47146, int _attribute_47147)
{
    int _p_47149 = NOVALUE;
    int _sname_47150 = NOVALUE;
    int _string_47151 = NOVALUE;
    int _colon_47152 = NOVALUE;
    int _h_47153 = NOVALUE;
    int _scope_47154 = NOVALUE;
    int _found_47175 = NOVALUE;
    int _24832 = NOVALUE;
    int _24828 = NOVALUE;
    int _24826 = NOVALUE;
    int _24825 = NOVALUE;
    int _24824 = NOVALUE;
    int _24823 = NOVALUE;
    int _24821 = NOVALUE;
    int _24820 = NOVALUE;
    int _24819 = NOVALUE;
    int _24818 = NOVALUE;
    int _24817 = NOVALUE;
    int _24815 = NOVALUE;
    int _24814 = NOVALUE;
    int _24813 = NOVALUE;
    int _24811 = NOVALUE;
    int _24809 = NOVALUE;
    int _24807 = NOVALUE;
    int _24806 = NOVALUE;
    int _24805 = NOVALUE;
    int _24804 = NOVALUE;
    int _24802 = NOVALUE;
    int _24801 = NOVALUE;
    int _24800 = NOVALUE;
    int _24799 = NOVALUE;
    int _24797 = NOVALUE;
    int _24796 = NOVALUE;
    int _24792 = NOVALUE;
    int _24791 = NOVALUE;
    int _24790 = NOVALUE;
    int _24789 = NOVALUE;
    int _24788 = NOVALUE;
    int _24787 = NOVALUE;
    int _24786 = NOVALUE;
    int _24785 = NOVALUE;
    int _24784 = NOVALUE;
    int _24783 = NOVALUE;
    int _24782 = NOVALUE;
    int _24781 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_s_47146)) {
        _1 = (long)(DBL_PTR(_s_47146)->dbl);
        DeRefDS(_s_47146);
        _s_47146 = _1;
    }
    if (!IS_ATOM_INT(_attribute_47147)) {
        _1 = (long)(DBL_PTR(_attribute_47147)->dbl);
        DeRefDS(_attribute_47147);
        _attribute_47147 = _1;
    }

    /** 	sequence sname*/

    /** 	sequence string*/

    /** 	integer colon, h*/

    /** 	integer scope*/

    /** 	if (SymTab[s][S_MODE] = M_TEMP or*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _24781 = (int)*(((s1_ptr)_2)->base + _s_47146);
    _2 = (int)SEQ_PTR(_24781);
    _24782 = (int)*(((s1_ptr)_2)->base + 3);
    _24781 = NOVALUE;
    if (IS_ATOM_INT(_24782)) {
        _24783 = (_24782 == 3);
    }
    else {
        _24783 = binary_op(EQUALS, _24782, 3);
    }
    _24782 = NOVALUE;
    if (IS_ATOM_INT(_24783)) {
        if (_24783 != 0) {
            _24784 = 1;
            goto L1; // [33] 59
        }
    }
    else {
        if (DBL_PTR(_24783)->dbl != 0.0) {
            _24784 = 1;
            goto L1; // [33] 59
        }
    }
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _24785 = (int)*(((s1_ptr)_2)->base + _s_47146);
    _2 = (int)SEQ_PTR(_24785);
    _24786 = (int)*(((s1_ptr)_2)->base + 3);
    _24785 = NOVALUE;
    if (IS_ATOM_INT(_24786)) {
        _24787 = (_24786 == 2);
    }
    else {
        _24787 = binary_op(EQUALS, _24786, 2);
    }
    _24786 = NOVALUE;
    DeRef(_24784);
    if (IS_ATOM_INT(_24787))
    _24784 = (_24787 != 0);
    else
    _24784 = DBL_PTR(_24787)->dbl != 0.0;
L1: 
    if (_24784 == 0) {
        goto L2; // [59] 440
    }
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _24789 = (int)*(((s1_ptr)_2)->base + _s_47146);
    _2 = (int)SEQ_PTR(_24789);
    _24790 = (int)*(((s1_ptr)_2)->base + 1);
    _24789 = NOVALUE;
    _24791 = IS_SEQUENCE(_24790);
    _24790 = NOVALUE;
    if (_24791 == 0)
    {
        _24791 = NOVALUE;
        goto L2; // [79] 440
    }
    else{
        _24791 = NOVALUE;
    }

    /** 		integer found = 0*/
    _found_47175 = 0;

    /** 		string = SymTab[s][S_OBJ]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _24792 = (int)*(((s1_ptr)_2)->base + _s_47146);
    DeRef(_string_47151);
    _2 = (int)SEQ_PTR(_24792);
    _string_47151 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_string_47151);
    _24792 = NOVALUE;

    /** 		colon = find(':', string)*/
    _colon_47152 = find_from(58, _string_47151, 1);

    /** 		if colon = 0 then*/
    if (_colon_47152 != 0)
    goto L3; // [112] 126

    /** 			sname = string*/
    RefDS(_string_47151);
    DeRef(_sname_47150);
    _sname_47150 = _string_47151;
    goto L4; // [123] 200
L3: 

    /** 			sname = string[colon+1..$]  -- ignore namespace part*/
    _24796 = _colon_47152 + 1;
    if (_24796 > MAXINT){
        _24796 = NewDouble((double)_24796);
    }
    if (IS_SEQUENCE(_string_47151)){
            _24797 = SEQ_PTR(_string_47151)->length;
    }
    else {
        _24797 = 1;
    }
    rhs_slice_target = (object_ptr)&_sname_47150;
    RHS_Slice(_string_47151, _24796, _24797);

    /** 			while length(sname) and sname[1] = ' ' or sname[1] = '\t' do*/
L5: 
    if (IS_SEQUENCE(_sname_47150)){
            _24799 = SEQ_PTR(_sname_47150)->length;
    }
    else {
        _24799 = 1;
    }
    if (_24799 == 0) {
        _24800 = 0;
        goto L6; // [148] 164
    }
    _2 = (int)SEQ_PTR(_sname_47150);
    _24801 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_24801)) {
        _24802 = (_24801 == 32);
    }
    else {
        _24802 = binary_op(EQUALS, _24801, 32);
    }
    _24801 = NOVALUE;
    if (IS_ATOM_INT(_24802))
    _24800 = (_24802 != 0);
    else
    _24800 = DBL_PTR(_24802)->dbl != 0.0;
L6: 
    if (_24800 != 0) {
        goto L7; // [164] 181
    }
    _2 = (int)SEQ_PTR(_sname_47150);
    _24804 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_24804)) {
        _24805 = (_24804 == 9);
    }
    else {
        _24805 = binary_op(EQUALS, _24804, 9);
    }
    _24804 = NOVALUE;
    if (_24805 <= 0) {
        if (_24805 == 0) {
            DeRef(_24805);
            _24805 = NOVALUE;
            goto L8; // [177] 199
        }
        else {
            if (!IS_ATOM_INT(_24805) && DBL_PTR(_24805)->dbl == 0.0){
                DeRef(_24805);
                _24805 = NOVALUE;
                goto L8; // [177] 199
            }
            DeRef(_24805);
            _24805 = NOVALUE;
        }
    }
    DeRef(_24805);
    _24805 = NOVALUE;
L7: 

    /** 				sname = tail( sname, length( sname ) -1 )*/
    if (IS_SEQUENCE(_sname_47150)){
            _24806 = SEQ_PTR(_sname_47150)->length;
    }
    else {
        _24806 = 1;
    }
    _24807 = _24806 - 1;
    _24806 = NOVALUE;
    {
        int len = SEQ_PTR(_sname_47150)->length;
        int size = (IS_ATOM_INT(_24807)) ? _24807 : (long)(DBL_PTR(_24807)->dbl);
        if (size <= 0) {
            DeRef(_sname_47150);
            _sname_47150 = MAKE_SEQ(NewS1(0));
        }
        else if (len <= size) {
            RefDS(_sname_47150);
            DeRef(_sname_47150);
            _sname_47150 = _sname_47150;
        }
        else Tail(SEQ_PTR(_sname_47150), len-size+1, &_sname_47150);
    }
    _24807 = NOVALUE;

    /** 			end while*/
    goto L5; // [196] 145
L8: 
L4: 

    /** 		if length(sname) = 0 then*/
    if (IS_SEQUENCE(_sname_47150)){
            _24809 = SEQ_PTR(_sname_47150)->length;
    }
    else {
        _24809 = 1;
    }
    if (_24809 != 0)
    goto L9; // [207] 218

    /** 			return 1*/
    DeRefDS(_sname_47150);
    DeRef(_string_47151);
    DeRef(_24796);
    _24796 = NOVALUE;
    DeRef(_24783);
    _24783 = NOVALUE;
    DeRef(_24787);
    _24787 = NOVALUE;
    DeRef(_24802);
    _24802 = NOVALUE;
    return 1;
L9: 

    /** 		h = buckets[hashfn(sname)]*/
    RefDS(_sname_47150);
    _24811 = _53hashfn(_sname_47150);
    _2 = (int)SEQ_PTR(_53buckets_46087);
    if (!IS_ATOM_INT(_24811)){
        _h_47153 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_24811)->dbl));
    }
    else{
        _h_47153 = (int)*(((s1_ptr)_2)->base + _24811);
    }
    if (!IS_ATOM_INT(_h_47153))
    _h_47153 = (long)DBL_PTR(_h_47153)->dbl;

    /** 		while h do*/
LA: 
    if (_h_47153 == 0)
    {
        goto LB; // [235] 381
    }
    else{
    }

    /** 			if equal(sname, SymTab[h][S_NAME]) then*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _24813 = (int)*(((s1_ptr)_2)->base + _h_47153);
    _2 = (int)SEQ_PTR(_24813);
    if (!IS_ATOM_INT(_35S_NAME_15917)){
        _24814 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15917)->dbl));
    }
    else{
        _24814 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15917);
    }
    _24813 = NOVALUE;
    if (_sname_47150 == _24814)
    _24815 = 1;
    else if (IS_ATOM_INT(_sname_47150) && IS_ATOM_INT(_24814))
    _24815 = 0;
    else
    _24815 = (compare(_sname_47150, _24814) == 0);
    _24814 = NOVALUE;
    if (_24815 == 0)
    {
        _24815 = NOVALUE;
        goto LC; // [256] 360
    }
    else{
        _24815 = NOVALUE;
    }

    /** 				if attribute = S_NREFS then*/
    if (_attribute_47147 != 12)
    goto LD; // [263] 289

    /** 					if BIND then*/
    if (_35BIND_15890 == 0)
    {
        goto LE; // [271] 359
    }
    else{
    }

    /** 						add_ref({PROC, h})*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 27;
    ((int *)_2)[2] = _h_47153;
    _24817 = MAKE_SEQ(_1);
    _53add_ref(_24817);
    _24817 = NOVALUE;
    goto LE; // [286] 359
LD: 

    /** 				elsif is_routine( h ) and is_visible( h, current_file_no ) then*/
    _24818 = _53is_routine(_h_47153);
    if (IS_ATOM_INT(_24818)) {
        if (_24818 == 0) {
            goto LF; // [295] 358
        }
    }
    else {
        if (DBL_PTR(_24818)->dbl == 0.0) {
            goto LF; // [295] 358
        }
    }
    _24820 = _53is_visible(_h_47153, _35current_file_no_16244);
    if (_24820 == 0) {
        DeRef(_24820);
        _24820 = NOVALUE;
        goto LF; // [307] 358
    }
    else {
        if (!IS_ATOM_INT(_24820) && DBL_PTR(_24820)->dbl == 0.0){
            DeRef(_24820);
            _24820 = NOVALUE;
            goto LF; // [307] 358
        }
        DeRef(_24820);
        _24820 = NOVALUE;
    }
    DeRef(_24820);
    _24820 = NOVALUE;

    /** 					SymTab[h][attribute] += 1*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_h_47153 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    _24823 = (int)*(((s1_ptr)_2)->base + _attribute_47147);
    _24821 = NOVALUE;
    if (IS_ATOM_INT(_24823)) {
        _24824 = _24823 + 1;
        if (_24824 > MAXINT){
            _24824 = NewDouble((double)_24824);
        }
    }
    else
    _24824 = binary_op(PLUS, 1, _24823);
    _24823 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _attribute_47147);
    _1 = *(int *)_2;
    *(int *)_2 = _24824;
    if( _1 != _24824 ){
        DeRef(_1);
    }
    _24824 = NOVALUE;
    _24821 = NOVALUE;

    /** 					if current_file_no = SymTab[h][S_FILE_NO] then*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _24825 = (int)*(((s1_ptr)_2)->base + _h_47153);
    _2 = (int)SEQ_PTR(_24825);
    if (!IS_ATOM_INT(_35S_FILE_NO_15913)){
        _24826 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FILE_NO_15913)->dbl));
    }
    else{
        _24826 = (int)*(((s1_ptr)_2)->base + _35S_FILE_NO_15913);
    }
    _24825 = NOVALUE;
    if (binary_op_a(NOTEQ, _35current_file_no_16244, _24826)){
        _24826 = NOVALUE;
        goto L10; // [347] 357
    }
    _24826 = NOVALUE;

    /** 						found = 1*/
    _found_47175 = 1;
L10: 
LF: 
LE: 
LC: 

    /** 			h = SymTab[h][S_SAMEHASH]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _24828 = (int)*(((s1_ptr)_2)->base + _h_47153);
    _2 = (int)SEQ_PTR(_24828);
    _h_47153 = (int)*(((s1_ptr)_2)->base + 9);
    if (!IS_ATOM_INT(_h_47153)){
        _h_47153 = (long)DBL_PTR(_h_47153)->dbl;
    }
    _24828 = NOVALUE;

    /** 		end while*/
    goto LA; // [378] 235
LB: 

    /** 		if not found then*/
    if (_found_47175 != 0)
    goto L11; // [383] 429

    /** 			just_mark_everything_from = TopLevelSub*/
    _53just_mark_everything_from_46996 = _35TopLevelSub_16251;

    /** 			recheck_targets &= s*/
    Append(&_53recheck_targets_47068, _53recheck_targets_47068, _s_47146);

    /** 			if not find( current_file_no, recheck_files ) then*/
    _24832 = find_from(_35current_file_no_16244, _53recheck_files_47069, 1);
    if (_24832 != 0)
    goto L12; // [414] 428
    _24832 = NOVALUE;

    /** 				recheck_files &= current_file_no*/
    Append(&_53recheck_files_47069, _53recheck_files_47069, _35current_file_no_16244);
L12: 
L11: 

    /** 		return found*/
    DeRef(_sname_47150);
    DeRef(_string_47151);
    DeRef(_24796);
    _24796 = NOVALUE;
    DeRef(_24783);
    _24783 = NOVALUE;
    DeRef(_24787);
    _24787 = NOVALUE;
    DeRef(_24811);
    _24811 = NOVALUE;
    DeRef(_24802);
    _24802 = NOVALUE;
    DeRef(_24818);
    _24818 = NOVALUE;
    return _found_47175;
    goto L13; // [437] 469
L2: 

    /** 		if not just_mark_everything_from then*/
    if (_53just_mark_everything_from_46996 != 0)
    goto L14; // [444] 457

    /** 			just_mark_everything_from = TopLevelSub*/
    _53just_mark_everything_from_46996 = _35TopLevelSub_16251;
L14: 

    /** 		mark_all( attribute )*/
    _53mark_all(_attribute_47147);

    /** 		return 1*/
    DeRef(_sname_47150);
    DeRef(_string_47151);
    DeRef(_24796);
    _24796 = NOVALUE;
    DeRef(_24783);
    _24783 = NOVALUE;
    DeRef(_24787);
    _24787 = NOVALUE;
    DeRef(_24811);
    _24811 = NOVALUE;
    DeRef(_24802);
    _24802 = NOVALUE;
    DeRef(_24818);
    _24818 = NOVALUE;
    return 1;
L13: 
    ;
}


void _53resolve_unincluded_globals(int _ok_47260)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_ok_47260)) {
        _1 = (long)(DBL_PTR(_ok_47260)->dbl);
        DeRefDS(_ok_47260);
        _ok_47260 = _1;
    }

    /** 	Resolve_unincluded_globals = ok*/
    _53Resolve_unincluded_globals_47257 = _ok_47260;

    /** end procedure*/
    return;
    ;
}


int _53get_resolve_unincluded_globals()
{
    int _0, _1, _2;
    

    /** 	return Resolve_unincluded_globals*/
    return _53Resolve_unincluded_globals_47257;
    ;
}


int _53keyfind(int _word_47266, int _file_no_47267, int _scanning_file_47268, int _namespace_ok_47271, int _hashval_47272)
{
    int _msg_47274 = NOVALUE;
    int _b_name_47275 = NOVALUE;
    int _scope_47276 = NOVALUE;
    int _defined_47277 = NOVALUE;
    int _ix_47278 = NOVALUE;
    int _st_ptr_47280 = NOVALUE;
    int _st_builtin_47281 = NOVALUE;
    int _tok_47283 = NOVALUE;
    int _gtok_47284 = NOVALUE;
    int _any_symbol_47287 = NOVALUE;
    int _tok_file_47455 = NOVALUE;
    int _good_47462 = NOVALUE;
    int _include_type_47472 = NOVALUE;
    int _msg_file_47528 = NOVALUE;
    int _25027 = NOVALUE;
    int _25026 = NOVALUE;
    int _25024 = NOVALUE;
    int _25022 = NOVALUE;
    int _25021 = NOVALUE;
    int _25020 = NOVALUE;
    int _25019 = NOVALUE;
    int _25018 = NOVALUE;
    int _25016 = NOVALUE;
    int _25014 = NOVALUE;
    int _25013 = NOVALUE;
    int _25012 = NOVALUE;
    int _25011 = NOVALUE;
    int _25010 = NOVALUE;
    int _25009 = NOVALUE;
    int _25008 = NOVALUE;
    int _25007 = NOVALUE;
    int _25005 = NOVALUE;
    int _25004 = NOVALUE;
    int _25003 = NOVALUE;
    int _25002 = NOVALUE;
    int _25001 = NOVALUE;
    int _25000 = NOVALUE;
    int _24999 = NOVALUE;
    int _24998 = NOVALUE;
    int _24997 = NOVALUE;
    int _24996 = NOVALUE;
    int _24995 = NOVALUE;
    int _24994 = NOVALUE;
    int _24993 = NOVALUE;
    int _24992 = NOVALUE;
    int _24991 = NOVALUE;
    int _24990 = NOVALUE;
    int _24989 = NOVALUE;
    int _24987 = NOVALUE;
    int _24986 = NOVALUE;
    int _24983 = NOVALUE;
    int _24979 = NOVALUE;
    int _24977 = NOVALUE;
    int _24976 = NOVALUE;
    int _24975 = NOVALUE;
    int _24974 = NOVALUE;
    int _24973 = NOVALUE;
    int _24971 = NOVALUE;
    int _24970 = NOVALUE;
    int _24969 = NOVALUE;
    int _24968 = NOVALUE;
    int _24966 = NOVALUE;
    int _24963 = NOVALUE;
    int _24962 = NOVALUE;
    int _24961 = NOVALUE;
    int _24960 = NOVALUE;
    int _24958 = NOVALUE;
    int _24955 = NOVALUE;
    int _24954 = NOVALUE;
    int _24953 = NOVALUE;
    int _24952 = NOVALUE;
    int _24951 = NOVALUE;
    int _24950 = NOVALUE;
    int _24949 = NOVALUE;
    int _24946 = NOVALUE;
    int _24945 = NOVALUE;
    int _24943 = NOVALUE;
    int _24941 = NOVALUE;
    int _24939 = NOVALUE;
    int _24938 = NOVALUE;
    int _24937 = NOVALUE;
    int _24933 = NOVALUE;
    int _24932 = NOVALUE;
    int _24927 = NOVALUE;
    int _24925 = NOVALUE;
    int _24923 = NOVALUE;
    int _24922 = NOVALUE;
    int _24918 = NOVALUE;
    int _24917 = NOVALUE;
    int _24915 = NOVALUE;
    int _24914 = NOVALUE;
    int _24912 = NOVALUE;
    int _24911 = NOVALUE;
    int _24910 = NOVALUE;
    int _24909 = NOVALUE;
    int _24908 = NOVALUE;
    int _24906 = NOVALUE;
    int _24905 = NOVALUE;
    int _24904 = NOVALUE;
    int _24903 = NOVALUE;
    int _24902 = NOVALUE;
    int _24901 = NOVALUE;
    int _24900 = NOVALUE;
    int _24899 = NOVALUE;
    int _24898 = NOVALUE;
    int _24897 = NOVALUE;
    int _24896 = NOVALUE;
    int _24895 = NOVALUE;
    int _24894 = NOVALUE;
    int _24893 = NOVALUE;
    int _24892 = NOVALUE;
    int _24891 = NOVALUE;
    int _24890 = NOVALUE;
    int _24889 = NOVALUE;
    int _24888 = NOVALUE;
    int _24887 = NOVALUE;
    int _24886 = NOVALUE;
    int _24885 = NOVALUE;
    int _24883 = NOVALUE;
    int _24882 = NOVALUE;
    int _24880 = NOVALUE;
    int _24879 = NOVALUE;
    int _24878 = NOVALUE;
    int _24877 = NOVALUE;
    int _24876 = NOVALUE;
    int _24874 = NOVALUE;
    int _24873 = NOVALUE;
    int _24872 = NOVALUE;
    int _24870 = NOVALUE;
    int _24869 = NOVALUE;
    int _24868 = NOVALUE;
    int _24867 = NOVALUE;
    int _24866 = NOVALUE;
    int _24865 = NOVALUE;
    int _24864 = NOVALUE;
    int _24862 = NOVALUE;
    int _24861 = NOVALUE;
    int _24856 = NOVALUE;
    int _24853 = NOVALUE;
    int _24852 = NOVALUE;
    int _24851 = NOVALUE;
    int _24850 = NOVALUE;
    int _24849 = NOVALUE;
    int _24848 = NOVALUE;
    int _24847 = NOVALUE;
    int _24846 = NOVALUE;
    int _24845 = NOVALUE;
    int _24844 = NOVALUE;
    int _24843 = NOVALUE;
    int _24842 = NOVALUE;
    int _24841 = NOVALUE;
    int _24840 = NOVALUE;
    int _24839 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_file_no_47267)) {
        _1 = (long)(DBL_PTR(_file_no_47267)->dbl);
        DeRefDS(_file_no_47267);
        _file_no_47267 = _1;
    }
    if (!IS_ATOM_INT(_scanning_file_47268)) {
        _1 = (long)(DBL_PTR(_scanning_file_47268)->dbl);
        DeRefDS(_scanning_file_47268);
        _scanning_file_47268 = _1;
    }
    if (!IS_ATOM_INT(_namespace_ok_47271)) {
        _1 = (long)(DBL_PTR(_namespace_ok_47271)->dbl);
        DeRefDS(_namespace_ok_47271);
        _namespace_ok_47271 = _1;
    }
    if (!IS_ATOM_INT(_hashval_47272)) {
        _1 = (long)(DBL_PTR(_hashval_47272)->dbl);
        DeRefDS(_hashval_47272);
        _hashval_47272 = _1;
    }

    /** 	dup_globals = {}*/
    RefDS(_22023);
    DeRef(_53dup_globals_47252);
    _53dup_globals_47252 = _22023;

    /** 	dup_overrides = {}*/
    RefDS(_22023);
    DeRefi(_53dup_overrides_47253);
    _53dup_overrides_47253 = _22023;

    /** 	in_include_path = {}*/
    RefDS(_22023);
    DeRef(_53in_include_path_47254);
    _53in_include_path_47254 = _22023;

    /** 	symbol_resolution_warning = ""*/
    RefDS(_22023);
    DeRef(_35symbol_resolution_warning_16345);
    _35symbol_resolution_warning_16345 = _22023;

    /** 	st_builtin = 0*/
    _st_builtin_47281 = 0;

    /** 	ifdef EUDIS then*/

    /** 	st_ptr = buckets[hashval]*/
    _2 = (int)SEQ_PTR(_53buckets_46087);
    _st_ptr_47280 = (int)*(((s1_ptr)_2)->base + _hashval_47272);
    if (!IS_ATOM_INT(_st_ptr_47280)){
        _st_ptr_47280 = (long)DBL_PTR(_st_ptr_47280)->dbl;
    }

    /** 	integer any_symbol = namespace_ok = -1*/
    _any_symbol_47287 = (_namespace_ok_47271 == -1);

    /** 	while st_ptr do*/
L1: 
    if (_st_ptr_47280 == 0)
    {
        goto L2; // [69] 1033
    }
    else{
    }

    /** 		if SymTab[st_ptr][S_SCOPE] != SC_UNDEFINED */
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _24839 = (int)*(((s1_ptr)_2)->base + _st_ptr_47280);
    _2 = (int)SEQ_PTR(_24839);
    _24840 = (int)*(((s1_ptr)_2)->base + 4);
    _24839 = NOVALUE;
    if (IS_ATOM_INT(_24840)) {
        _24841 = (_24840 != 9);
    }
    else {
        _24841 = binary_op(NOTEQ, _24840, 9);
    }
    _24840 = NOVALUE;
    if (IS_ATOM_INT(_24841)) {
        if (_24841 == 0) {
            DeRef(_24842);
            _24842 = 0;
            goto L3; // [92] 116
        }
    }
    else {
        if (DBL_PTR(_24841)->dbl == 0.0) {
            DeRef(_24842);
            _24842 = 0;
            goto L3; // [92] 116
        }
    }
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _24843 = (int)*(((s1_ptr)_2)->base + _st_ptr_47280);
    _2 = (int)SEQ_PTR(_24843);
    if (!IS_ATOM_INT(_35S_NAME_15917)){
        _24844 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15917)->dbl));
    }
    else{
        _24844 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15917);
    }
    _24843 = NOVALUE;
    if (_word_47266 == _24844)
    _24845 = 1;
    else if (IS_ATOM_INT(_word_47266) && IS_ATOM_INT(_24844))
    _24845 = 0;
    else
    _24845 = (compare(_word_47266, _24844) == 0);
    _24844 = NOVALUE;
    DeRef(_24842);
    _24842 = (_24845 != 0);
L3: 
    if (_24842 == 0) {
        goto L4; // [116] 1012
    }
    if (_any_symbol_47287 != 0) {
        DeRef(_24847);
        _24847 = 1;
        goto L5; // [120] 150
    }
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _24848 = (int)*(((s1_ptr)_2)->base + _st_ptr_47280);
    _2 = (int)SEQ_PTR(_24848);
    if (!IS_ATOM_INT(_35S_TOKEN_15922)){
        _24849 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TOKEN_15922)->dbl));
    }
    else{
        _24849 = (int)*(((s1_ptr)_2)->base + _35S_TOKEN_15922);
    }
    _24848 = NOVALUE;
    if (IS_ATOM_INT(_24849)) {
        _24850 = (_24849 == 523);
    }
    else {
        _24850 = binary_op(EQUALS, _24849, 523);
    }
    _24849 = NOVALUE;
    if (IS_ATOM_INT(_24850)) {
        _24851 = (_namespace_ok_47271 == _24850);
    }
    else {
        _24851 = binary_op(EQUALS, _namespace_ok_47271, _24850);
    }
    DeRef(_24850);
    _24850 = NOVALUE;
    if (IS_ATOM_INT(_24851))
    _24847 = (_24851 != 0);
    else
    _24847 = DBL_PTR(_24851)->dbl != 0.0;
L5: 
    if (_24847 == 0)
    {
        _24847 = NOVALUE;
        goto L4; // [151] 1012
    }
    else{
        _24847 = NOVALUE;
    }

    /** 			tok = {SymTab[st_ptr][S_TOKEN], st_ptr}*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _24852 = (int)*(((s1_ptr)_2)->base + _st_ptr_47280);
    _2 = (int)SEQ_PTR(_24852);
    if (!IS_ATOM_INT(_35S_TOKEN_15922)){
        _24853 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TOKEN_15922)->dbl));
    }
    else{
        _24853 = (int)*(((s1_ptr)_2)->base + _35S_TOKEN_15922);
    }
    _24852 = NOVALUE;
    Ref(_24853);
    DeRef(_tok_47283);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _24853;
    ((int *)_2)[2] = _st_ptr_47280;
    _tok_47283 = MAKE_SEQ(_1);
    _24853 = NOVALUE;

    /** 			if file_no = -1 then*/
    if (_file_no_47267 != -1)
    goto L6; // [174] 714

    /** 				scope = SymTab[st_ptr][S_SCOPE]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _24856 = (int)*(((s1_ptr)_2)->base + _st_ptr_47280);
    _2 = (int)SEQ_PTR(_24856);
    _scope_47276 = (int)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_scope_47276)){
        _scope_47276 = (long)DBL_PTR(_scope_47276)->dbl;
    }
    _24856 = NOVALUE;

    /** 				switch scope with fallthru do*/
    _0 = _scope_47276;
    switch ( _0 ){ 

        /** 				case SC_OVERRIDE then*/
        case 12:

        /** 					dup_overrides &= st_ptr*/
        Append(&_53dup_overrides_47253, _53dup_overrides_47253, _st_ptr_47280);

        /** 					break*/
        goto L7; // [215] 1011

        /** 				case SC_PREDEF then*/
        case 7:

        /** 					st_builtin = st_ptr*/
        _st_builtin_47281 = _st_ptr_47280;

        /** 					break*/
        goto L7; // [230] 1011

        /** 				case SC_GLOBAL then*/
        case 6:

        /** 					if scanning_file = SymTab[st_ptr][S_FILE_NO] then*/
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _24861 = (int)*(((s1_ptr)_2)->base + _st_ptr_47280);
        _2 = (int)SEQ_PTR(_24861);
        if (!IS_ATOM_INT(_35S_FILE_NO_15913)){
            _24862 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FILE_NO_15913)->dbl));
        }
        else{
            _24862 = (int)*(((s1_ptr)_2)->base + _35S_FILE_NO_15913);
        }
        _24861 = NOVALUE;
        if (binary_op_a(NOTEQ, _scanning_file_47268, _24862)){
            _24862 = NOVALUE;
            goto L8; // [250] 274
        }
        _24862 = NOVALUE;

        /** 						if BIND then*/
        if (_35BIND_15890 == 0)
        {
            goto L9; // [258] 267
        }
        else{
        }

        /** 							add_ref(tok)*/
        Ref(_tok_47283);
        _53add_ref(_tok_47283);
L9: 

        /** 						return tok*/
        DeRefDS(_word_47266);
        DeRef(_msg_47274);
        DeRef(_b_name_47275);
        DeRef(_gtok_47284);
        DeRef(_24851);
        _24851 = NOVALUE;
        DeRef(_24841);
        _24841 = NOVALUE;
        return _tok_47283;
L8: 

        /** 					if Resolve_unincluded_globals */
        if (_53Resolve_unincluded_globals_47257 != 0) {
            _24864 = 1;
            goto LA; // [278] 322
        }
        _2 = (int)SEQ_PTR(_36finished_files_15245);
        _24865 = (int)*(((s1_ptr)_2)->base + _scanning_file_47268);
        if (_24865 == 0) {
            _24866 = 0;
            goto LB; // [288] 318
        }
        _2 = (int)SEQ_PTR(_36include_matrix_15249);
        _24867 = (int)*(((s1_ptr)_2)->base + _scanning_file_47268);
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _24868 = (int)*(((s1_ptr)_2)->base + _st_ptr_47280);
        _2 = (int)SEQ_PTR(_24868);
        if (!IS_ATOM_INT(_35S_FILE_NO_15913)){
            _24869 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FILE_NO_15913)->dbl));
        }
        else{
            _24869 = (int)*(((s1_ptr)_2)->base + _35S_FILE_NO_15913);
        }
        _24868 = NOVALUE;
        _2 = (int)SEQ_PTR(_24867);
        if (!IS_ATOM_INT(_24869)){
            _24870 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_24869)->dbl));
        }
        else{
            _24870 = (int)*(((s1_ptr)_2)->base + _24869);
        }
        _24867 = NOVALUE;
        if (IS_ATOM_INT(_24870))
        _24866 = (_24870 != 0);
        else
        _24866 = DBL_PTR(_24870)->dbl != 0.0;
LB: 
        _24864 = (_24866 != 0);
LA: 
        if (_24864 != 0) {
            goto LC; // [322] 349
        }
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _24872 = (int)*(((s1_ptr)_2)->base + _st_ptr_47280);
        _2 = (int)SEQ_PTR(_24872);
        if (!IS_ATOM_INT(_35S_TOKEN_15922)){
            _24873 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TOKEN_15922)->dbl));
        }
        else{
            _24873 = (int)*(((s1_ptr)_2)->base + _35S_TOKEN_15922);
        }
        _24872 = NOVALUE;
        if (IS_ATOM_INT(_24873)) {
            _24874 = (_24873 == 523);
        }
        else {
            _24874 = binary_op(EQUALS, _24873, 523);
        }
        _24873 = NOVALUE;
        if (_24874 == 0) {
            DeRef(_24874);
            _24874 = NOVALUE;
            goto L7; // [345] 1011
        }
        else {
            if (!IS_ATOM_INT(_24874) && DBL_PTR(_24874)->dbl == 0.0){
                DeRef(_24874);
                _24874 = NOVALUE;
                goto L7; // [345] 1011
            }
            DeRef(_24874);
            _24874 = NOVALUE;
        }
        DeRef(_24874);
        _24874 = NOVALUE;
LC: 

        /** 						gtok = tok*/
        Ref(_tok_47283);
        DeRef(_gtok_47284);
        _gtok_47284 = _tok_47283;

        /** 						dup_globals &= st_ptr*/
        Append(&_53dup_globals_47252, _53dup_globals_47252, _st_ptr_47280);

        /** 						in_include_path &= include_matrix[scanning_file][SymTab[st_ptr][S_FILE_NO]] != 0*/
        _2 = (int)SEQ_PTR(_36include_matrix_15249);
        _24876 = (int)*(((s1_ptr)_2)->base + _scanning_file_47268);
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _24877 = (int)*(((s1_ptr)_2)->base + _st_ptr_47280);
        _2 = (int)SEQ_PTR(_24877);
        if (!IS_ATOM_INT(_35S_FILE_NO_15913)){
            _24878 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FILE_NO_15913)->dbl));
        }
        else{
            _24878 = (int)*(((s1_ptr)_2)->base + _35S_FILE_NO_15913);
        }
        _24877 = NOVALUE;
        _2 = (int)SEQ_PTR(_24876);
        if (!IS_ATOM_INT(_24878)){
            _24879 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_24878)->dbl));
        }
        else{
            _24879 = (int)*(((s1_ptr)_2)->base + _24878);
        }
        _24876 = NOVALUE;
        if (IS_ATOM_INT(_24879)) {
            _24880 = (_24879 != 0);
        }
        else {
            _24880 = binary_op(NOTEQ, _24879, 0);
        }
        _24879 = NOVALUE;
        if (IS_SEQUENCE(_53in_include_path_47254) && IS_ATOM(_24880)) {
            Ref(_24880);
            Append(&_53in_include_path_47254, _53in_include_path_47254, _24880);
        }
        else if (IS_ATOM(_53in_include_path_47254) && IS_SEQUENCE(_24880)) {
        }
        else {
            Concat((object_ptr)&_53in_include_path_47254, _53in_include_path_47254, _24880);
        }
        DeRef(_24880);
        _24880 = NOVALUE;

        /** 					break*/
        goto L7; // [399] 1011

        /** 				case SC_PUBLIC, SC_EXPORT then*/
        case 13:
        case 11:

        /** 					if scanning_file = SymTab[st_ptr][S_FILE_NO] then*/
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _24882 = (int)*(((s1_ptr)_2)->base + _st_ptr_47280);
        _2 = (int)SEQ_PTR(_24882);
        if (!IS_ATOM_INT(_35S_FILE_NO_15913)){
            _24883 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FILE_NO_15913)->dbl));
        }
        else{
            _24883 = (int)*(((s1_ptr)_2)->base + _35S_FILE_NO_15913);
        }
        _24882 = NOVALUE;
        if (binary_op_a(NOTEQ, _scanning_file_47268, _24883)){
            _24883 = NOVALUE;
            goto LD; // [421] 445
        }
        _24883 = NOVALUE;

        /** 						if BIND then*/
        if (_35BIND_15890 == 0)
        {
            goto LE; // [429] 438
        }
        else{
        }

        /** 							add_ref(tok)*/
        Ref(_tok_47283);
        _53add_ref(_tok_47283);
LE: 

        /** 						return tok*/
        DeRefDS(_word_47266);
        DeRef(_msg_47274);
        DeRef(_b_name_47275);
        DeRef(_gtok_47284);
        DeRef(_24851);
        _24851 = NOVALUE;
        DeRef(_24841);
        _24841 = NOVALUE;
        _24865 = NOVALUE;
        _24870 = NOVALUE;
        _24869 = NOVALUE;
        _24878 = NOVALUE;
        return _tok_47283;
LD: 

        /** 					if (finished_files[scanning_file] -- everything this file needs has been read in*/
        _2 = (int)SEQ_PTR(_36finished_files_15245);
        _24885 = (int)*(((s1_ptr)_2)->base + _scanning_file_47268);
        if (_24885 != 0) {
            _24886 = 1;
            goto LF; // [453] 487
        }
        if (_namespace_ok_47271 == 0) {
            _24887 = 0;
            goto L10; // [457] 483
        }
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _24888 = (int)*(((s1_ptr)_2)->base + _st_ptr_47280);
        _2 = (int)SEQ_PTR(_24888);
        if (!IS_ATOM_INT(_35S_TOKEN_15922)){
            _24889 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TOKEN_15922)->dbl));
        }
        else{
            _24889 = (int)*(((s1_ptr)_2)->base + _35S_TOKEN_15922);
        }
        _24888 = NOVALUE;
        if (IS_ATOM_INT(_24889)) {
            _24890 = (_24889 == 523);
        }
        else {
            _24890 = binary_op(EQUALS, _24889, 523);
        }
        _24889 = NOVALUE;
        if (IS_ATOM_INT(_24890))
        _24887 = (_24890 != 0);
        else
        _24887 = DBL_PTR(_24890)->dbl != 0.0;
L10: 
        _24886 = (_24887 != 0);
LF: 
        if (_24886 == 0) {
            goto L7; // [487] 1011
        }
        _24892 = (_scope_47276 == 13);
        if (_24892 == 0) {
            _24893 = 0;
            goto L11; // [497] 533
        }
        _2 = (int)SEQ_PTR(_36include_matrix_15249);
        _24894 = (int)*(((s1_ptr)_2)->base + _scanning_file_47268);
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _24895 = (int)*(((s1_ptr)_2)->base + _st_ptr_47280);
        _2 = (int)SEQ_PTR(_24895);
        if (!IS_ATOM_INT(_35S_FILE_NO_15913)){
            _24896 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FILE_NO_15913)->dbl));
        }
        else{
            _24896 = (int)*(((s1_ptr)_2)->base + _35S_FILE_NO_15913);
        }
        _24895 = NOVALUE;
        _2 = (int)SEQ_PTR(_24894);
        if (!IS_ATOM_INT(_24896)){
            _24897 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_24896)->dbl));
        }
        else{
            _24897 = (int)*(((s1_ptr)_2)->base + _24896);
        }
        _24894 = NOVALUE;
        if (IS_ATOM_INT(_24897)) {
            {unsigned long tu;
                 tu = (unsigned long)6 & (unsigned long)_24897;
                 _24898 = MAKE_UINT(tu);
            }
        }
        else {
            _24898 = binary_op(AND_BITS, 6, _24897);
        }
        _24897 = NOVALUE;
        if (IS_ATOM_INT(_24898))
        _24893 = (_24898 != 0);
        else
        _24893 = DBL_PTR(_24898)->dbl != 0.0;
L11: 
        if (_24893 != 0) {
            DeRef(_24899);
            _24899 = 1;
            goto L12; // [533] 583
        }
        _24900 = (_scope_47276 == 11);
        if (_24900 == 0) {
            _24901 = 0;
            goto L13; // [543] 579
        }
        _2 = (int)SEQ_PTR(_36include_matrix_15249);
        _24902 = (int)*(((s1_ptr)_2)->base + _scanning_file_47268);
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _24903 = (int)*(((s1_ptr)_2)->base + _st_ptr_47280);
        _2 = (int)SEQ_PTR(_24903);
        if (!IS_ATOM_INT(_35S_FILE_NO_15913)){
            _24904 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FILE_NO_15913)->dbl));
        }
        else{
            _24904 = (int)*(((s1_ptr)_2)->base + _35S_FILE_NO_15913);
        }
        _24903 = NOVALUE;
        _2 = (int)SEQ_PTR(_24902);
        if (!IS_ATOM_INT(_24904)){
            _24905 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_24904)->dbl));
        }
        else{
            _24905 = (int)*(((s1_ptr)_2)->base + _24904);
        }
        _24902 = NOVALUE;
        if (IS_ATOM_INT(_24905)) {
            {unsigned long tu;
                 tu = (unsigned long)2 & (unsigned long)_24905;
                 _24906 = MAKE_UINT(tu);
            }
        }
        else {
            _24906 = binary_op(AND_BITS, 2, _24905);
        }
        _24905 = NOVALUE;
        if (IS_ATOM_INT(_24906))
        _24901 = (_24906 != 0);
        else
        _24901 = DBL_PTR(_24906)->dbl != 0.0;
L13: 
        DeRef(_24899);
        _24899 = (_24901 != 0);
L12: 
        if (_24899 == 0)
        {
            _24899 = NOVALUE;
            goto L7; // [584] 1011
        }
        else{
            _24899 = NOVALUE;
        }

        /** 						gtok = tok*/
        Ref(_tok_47283);
        DeRef(_gtok_47284);
        _gtok_47284 = _tok_47283;

        /** 						dup_globals &= st_ptr*/
        Append(&_53dup_globals_47252, _53dup_globals_47252, _st_ptr_47280);

        /** 						in_include_path &= include_matrix[scanning_file][SymTab[st_ptr][S_FILE_NO]] != 0 --symbol_in_include_path( st_ptr, scanning_file, {} )*/
        _2 = (int)SEQ_PTR(_36include_matrix_15249);
        _24908 = (int)*(((s1_ptr)_2)->base + _scanning_file_47268);
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _24909 = (int)*(((s1_ptr)_2)->base + _st_ptr_47280);
        _2 = (int)SEQ_PTR(_24909);
        if (!IS_ATOM_INT(_35S_FILE_NO_15913)){
            _24910 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FILE_NO_15913)->dbl));
        }
        else{
            _24910 = (int)*(((s1_ptr)_2)->base + _35S_FILE_NO_15913);
        }
        _24909 = NOVALUE;
        _2 = (int)SEQ_PTR(_24908);
        if (!IS_ATOM_INT(_24910)){
            _24911 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_24910)->dbl));
        }
        else{
            _24911 = (int)*(((s1_ptr)_2)->base + _24910);
        }
        _24908 = NOVALUE;
        if (IS_ATOM_INT(_24911)) {
            _24912 = (_24911 != 0);
        }
        else {
            _24912 = binary_op(NOTEQ, _24911, 0);
        }
        _24911 = NOVALUE;
        if (IS_SEQUENCE(_53in_include_path_47254) && IS_ATOM(_24912)) {
            Ref(_24912);
            Append(&_53in_include_path_47254, _53in_include_path_47254, _24912);
        }
        else if (IS_ATOM(_53in_include_path_47254) && IS_SEQUENCE(_24912)) {
        }
        else {
            Concat((object_ptr)&_53in_include_path_47254, _53in_include_path_47254, _24912);
        }
        DeRef(_24912);
        _24912 = NOVALUE;

        /** ifdef STDDEBUG then*/

        /** 					break*/
        goto L7; // [639] 1011

        /** 				case SC_LOCAL then*/
        case 5:

        /** 					if scanning_file = SymTab[st_ptr][S_FILE_NO] then*/
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _24914 = (int)*(((s1_ptr)_2)->base + _st_ptr_47280);
        _2 = (int)SEQ_PTR(_24914);
        if (!IS_ATOM_INT(_35S_FILE_NO_15913)){
            _24915 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FILE_NO_15913)->dbl));
        }
        else{
            _24915 = (int)*(((s1_ptr)_2)->base + _35S_FILE_NO_15913);
        }
        _24914 = NOVALUE;
        if (binary_op_a(NOTEQ, _scanning_file_47268, _24915)){
            _24915 = NOVALUE;
            goto L7; // [659] 1011
        }
        _24915 = NOVALUE;

        /** 						if BIND then*/
        if (_35BIND_15890 == 0)
        {
            goto L14; // [667] 676
        }
        else{
        }

        /** 							add_ref(tok)*/
        Ref(_tok_47283);
        _53add_ref(_tok_47283);
L14: 

        /** 						return tok*/
        DeRefDS(_word_47266);
        DeRef(_msg_47274);
        DeRef(_b_name_47275);
        DeRef(_gtok_47284);
        DeRef(_24851);
        _24851 = NOVALUE;
        DeRef(_24841);
        _24841 = NOVALUE;
        _24865 = NOVALUE;
        _24870 = NOVALUE;
        _24869 = NOVALUE;
        _24885 = NOVALUE;
        _24878 = NOVALUE;
        DeRef(_24892);
        _24892 = NOVALUE;
        DeRef(_24890);
        _24890 = NOVALUE;
        DeRef(_24900);
        _24900 = NOVALUE;
        _24896 = NOVALUE;
        DeRef(_24898);
        _24898 = NOVALUE;
        _24904 = NOVALUE;
        DeRef(_24906);
        _24906 = NOVALUE;
        _24910 = NOVALUE;
        return _tok_47283;

        /** 					break*/
        goto L7; // [685] 1011

        /** 				case else*/
        default:

        /** 					if BIND then*/
        if (_35BIND_15890 == 0)
        {
            goto L15; // [695] 704
        }
        else{
        }

        /** 						add_ref(tok)*/
        Ref(_tok_47283);
        _53add_ref(_tok_47283);
L15: 

        /** 					return tok -- keyword, private*/
        DeRefDS(_word_47266);
        DeRef(_msg_47274);
        DeRef(_b_name_47275);
        DeRef(_gtok_47284);
        DeRef(_24851);
        _24851 = NOVALUE;
        DeRef(_24841);
        _24841 = NOVALUE;
        _24865 = NOVALUE;
        _24870 = NOVALUE;
        _24869 = NOVALUE;
        _24885 = NOVALUE;
        _24878 = NOVALUE;
        DeRef(_24892);
        _24892 = NOVALUE;
        DeRef(_24890);
        _24890 = NOVALUE;
        DeRef(_24900);
        _24900 = NOVALUE;
        _24896 = NOVALUE;
        DeRef(_24898);
        _24898 = NOVALUE;
        _24904 = NOVALUE;
        DeRef(_24906);
        _24906 = NOVALUE;
        _24910 = NOVALUE;
        return _tok_47283;
    ;}    goto L7; // [711] 1011
L6: 

    /** 				scope = SymTab[tok[T_SYM]][S_SCOPE]*/
    _2 = (int)SEQ_PTR(_tok_47283);
    _24917 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!IS_ATOM_INT(_24917)){
        _24918 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_24917)->dbl));
    }
    else{
        _24918 = (int)*(((s1_ptr)_2)->base + _24917);
    }
    _2 = (int)SEQ_PTR(_24918);
    _scope_47276 = (int)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_scope_47276)){
        _scope_47276 = (long)DBL_PTR(_scope_47276)->dbl;
    }
    _24918 = NOVALUE;

    /** 				if not file_no then*/
    if (_file_no_47267 != 0)
    goto L16; // [738] 772

    /** 					if scope = SC_PREDEF then*/
    if (_scope_47276 != 7)
    goto L17; // [745] 1010

    /** 						if BIND then*/
    if (_35BIND_15890 == 0)
    {
        goto L18; // [753] 762
    }
    else{
    }

    /** 							add_ref( tok )*/
    Ref(_tok_47283);
    _53add_ref(_tok_47283);
L18: 

    /** 						return tok*/
    DeRefDS(_word_47266);
    DeRef(_msg_47274);
    DeRef(_b_name_47275);
    DeRef(_gtok_47284);
    DeRef(_24851);
    _24851 = NOVALUE;
    DeRef(_24841);
    _24841 = NOVALUE;
    _24865 = NOVALUE;
    _24870 = NOVALUE;
    _24869 = NOVALUE;
    _24885 = NOVALUE;
    _24878 = NOVALUE;
    DeRef(_24892);
    _24892 = NOVALUE;
    DeRef(_24890);
    _24890 = NOVALUE;
    DeRef(_24900);
    _24900 = NOVALUE;
    _24896 = NOVALUE;
    DeRef(_24898);
    _24898 = NOVALUE;
    _24917 = NOVALUE;
    _24904 = NOVALUE;
    DeRef(_24906);
    _24906 = NOVALUE;
    _24910 = NOVALUE;
    return _tok_47283;
    goto L17; // [769] 1010
L16: 

    /** 					integer tok_file = SymTab[tok[T_SYM]][S_FILE_NO]*/
    _2 = (int)SEQ_PTR(_tok_47283);
    _24922 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!IS_ATOM_INT(_24922)){
        _24923 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_24922)->dbl));
    }
    else{
        _24923 = (int)*(((s1_ptr)_2)->base + _24922);
    }
    _2 = (int)SEQ_PTR(_24923);
    if (!IS_ATOM_INT(_35S_FILE_NO_15913)){
        _tok_file_47455 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FILE_NO_15913)->dbl));
    }
    else{
        _tok_file_47455 = (int)*(((s1_ptr)_2)->base + _35S_FILE_NO_15913);
    }
    if (!IS_ATOM_INT(_tok_file_47455)){
        _tok_file_47455 = (long)DBL_PTR(_tok_file_47455)->dbl;
    }
    _24923 = NOVALUE;

    /** 					integer good = 0*/
    _good_47462 = 0;

    /** 					if scope = SC_PRIVATE or scope = SC_PREDEF then*/
    _24925 = (_scope_47276 == 3);
    if (_24925 != 0) {
        goto L19; // [807] 940
    }
    _24927 = (_scope_47276 == 7);
    if (_24927 == 0)
    {
        DeRef(_24927);
        _24927 = NOVALUE;
        goto L1A; // [818] 825
    }
    else{
        DeRef(_24927);
        _24927 = NOVALUE;
    }
    goto L19; // [822] 940
L1A: 

    /** 					elsif file_no = tok_file then*/
    if (_file_no_47267 != _tok_file_47455)
    goto L1B; // [827] 839

    /** 						good = 1*/
    _good_47462 = 1;
    goto L19; // [836] 940
L1B: 

    /** 						integer include_type = 0*/
    _include_type_47472 = 0;

    /** 						switch scope do*/
    _0 = _scope_47276;
    switch ( _0 ){ 

        /** 							case SC_GLOBAL then*/
        case 6:

        /** 								if Resolve_unincluded_globals then*/
        if (_53Resolve_unincluded_globals_47257 == 0)
        {
            goto L1C; // [859] 874
        }
        else{
        }

        /** 									include_type = ANY_INCLUDE*/
        _include_type_47472 = 7;
        goto L1D; // [871] 919
L1C: 

        /** 									include_type = DIRECT_OR_PUBLIC_INCLUDE*/
        _include_type_47472 = 6;
        goto L1D; // [884] 919

        /** 							case SC_PUBLIC then*/
        case 13:

        /** 								if tok_file != file_no then*/
        if (_tok_file_47455 == _file_no_47267)
        goto L1E; // [892] 908

        /** 									include_type = PUBLIC_INCLUDE*/
        _include_type_47472 = 4;
        goto L1F; // [905] 918
L1E: 

        /** 									include_type = DIRECT_OR_PUBLIC_INCLUDE*/
        _include_type_47472 = 6;
L1F: 
    ;}L1D: 

    /** 						good = and_bits( include_type, include_matrix[file_no][tok_file] )*/
    _2 = (int)SEQ_PTR(_36include_matrix_15249);
    _24932 = (int)*(((s1_ptr)_2)->base + _file_no_47267);
    _2 = (int)SEQ_PTR(_24932);
    _24933 = (int)*(((s1_ptr)_2)->base + _tok_file_47455);
    _24932 = NOVALUE;
    if (IS_ATOM_INT(_24933)) {
        {unsigned long tu;
             tu = (unsigned long)_include_type_47472 & (unsigned long)_24933;
             _good_47462 = MAKE_UINT(tu);
        }
    }
    else {
        _good_47462 = binary_op(AND_BITS, _include_type_47472, _24933);
    }
    _24933 = NOVALUE;
    if (!IS_ATOM_INT(_good_47462)) {
        _1 = (long)(DBL_PTR(_good_47462)->dbl);
        DeRefDS(_good_47462);
        _good_47462 = _1;
    }
L19: 

    /** 					if good then*/
    if (_good_47462 == 0)
    {
        goto L20; // [942] 1007
    }
    else{
    }

    /** 						if file_no = tok_file then*/
    if (_file_no_47267 != _tok_file_47455)
    goto L21; // [947] 971

    /** 							if BIND then*/
    if (_35BIND_15890 == 0)
    {
        goto L22; // [955] 964
    }
    else{
    }

    /** 								add_ref(tok)*/
    Ref(_tok_47283);
    _53add_ref(_tok_47283);
L22: 

    /** 							return tok*/
    DeRefDS(_word_47266);
    DeRef(_msg_47274);
    DeRef(_b_name_47275);
    DeRef(_gtok_47284);
    DeRef(_24851);
    _24851 = NOVALUE;
    DeRef(_24841);
    _24841 = NOVALUE;
    _24865 = NOVALUE;
    _24870 = NOVALUE;
    _24869 = NOVALUE;
    _24885 = NOVALUE;
    _24878 = NOVALUE;
    DeRef(_24892);
    _24892 = NOVALUE;
    DeRef(_24890);
    _24890 = NOVALUE;
    DeRef(_24900);
    _24900 = NOVALUE;
    _24896 = NOVALUE;
    DeRef(_24898);
    _24898 = NOVALUE;
    _24917 = NOVALUE;
    _24904 = NOVALUE;
    DeRef(_24906);
    _24906 = NOVALUE;
    _24910 = NOVALUE;
    _24922 = NOVALUE;
    DeRef(_24925);
    _24925 = NOVALUE;
    return _tok_47283;
L21: 

    /** 						gtok = tok*/
    Ref(_tok_47283);
    DeRef(_gtok_47284);
    _gtok_47284 = _tok_47283;

    /** 						dup_globals &= st_ptr*/
    Append(&_53dup_globals_47252, _53dup_globals_47252, _st_ptr_47280);

    /** 						in_include_path &= include_matrix[scanning_file][tok_file] != 0*/
    _2 = (int)SEQ_PTR(_36include_matrix_15249);
    _24937 = (int)*(((s1_ptr)_2)->base + _scanning_file_47268);
    _2 = (int)SEQ_PTR(_24937);
    _24938 = (int)*(((s1_ptr)_2)->base + _tok_file_47455);
    _24937 = NOVALUE;
    if (IS_ATOM_INT(_24938)) {
        _24939 = (_24938 != 0);
    }
    else {
        _24939 = binary_op(NOTEQ, _24938, 0);
    }
    _24938 = NOVALUE;
    if (IS_SEQUENCE(_53in_include_path_47254) && IS_ATOM(_24939)) {
        Ref(_24939);
        Append(&_53in_include_path_47254, _53in_include_path_47254, _24939);
    }
    else if (IS_ATOM(_53in_include_path_47254) && IS_SEQUENCE(_24939)) {
    }
    else {
        Concat((object_ptr)&_53in_include_path_47254, _53in_include_path_47254, _24939);
    }
    DeRef(_24939);
    _24939 = NOVALUE;
L20: 
L17: 
L7: 
L4: 

    /** 		st_ptr = SymTab[st_ptr][S_SAMEHASH]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _24941 = (int)*(((s1_ptr)_2)->base + _st_ptr_47280);
    _2 = (int)SEQ_PTR(_24941);
    _st_ptr_47280 = (int)*(((s1_ptr)_2)->base + 9);
    if (!IS_ATOM_INT(_st_ptr_47280)){
        _st_ptr_47280 = (long)DBL_PTR(_st_ptr_47280)->dbl;
    }
    _24941 = NOVALUE;

    /** 	end while*/
    goto L1; // [1030] 69
L2: 

    /** 	if length(dup_overrides) then*/
    if (IS_SEQUENCE(_53dup_overrides_47253)){
            _24943 = SEQ_PTR(_53dup_overrides_47253)->length;
    }
    else {
        _24943 = 1;
    }
    if (_24943 == 0)
    {
        _24943 = NOVALUE;
        goto L23; // [1040] 1093
    }
    else{
        _24943 = NOVALUE;
    }

    /** 		st_ptr = dup_overrides[1]*/
    _2 = (int)SEQ_PTR(_53dup_overrides_47253);
    _st_ptr_47280 = (int)*(((s1_ptr)_2)->base + 1);

    /** 		tok = {SymTab[st_ptr][S_TOKEN], st_ptr}*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _24945 = (int)*(((s1_ptr)_2)->base + _st_ptr_47280);
    _2 = (int)SEQ_PTR(_24945);
    if (!IS_ATOM_INT(_35S_TOKEN_15922)){
        _24946 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TOKEN_15922)->dbl));
    }
    else{
        _24946 = (int)*(((s1_ptr)_2)->base + _35S_TOKEN_15922);
    }
    _24945 = NOVALUE;
    Ref(_24946);
    DeRef(_tok_47283);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _24946;
    ((int *)_2)[2] = _st_ptr_47280;
    _tok_47283 = MAKE_SEQ(_1);
    _24946 = NOVALUE;

    /** 			if BIND then*/
    if (_35BIND_15890 == 0)
    {
        goto L24; // [1075] 1084
    }
    else{
    }

    /** 				add_ref(tok)*/
    RefDS(_tok_47283);
    _53add_ref(_tok_47283);
L24: 

    /** 			return tok*/
    DeRefDS(_word_47266);
    DeRef(_msg_47274);
    DeRef(_b_name_47275);
    DeRef(_gtok_47284);
    DeRef(_24851);
    _24851 = NOVALUE;
    DeRef(_24841);
    _24841 = NOVALUE;
    _24865 = NOVALUE;
    _24870 = NOVALUE;
    _24869 = NOVALUE;
    _24885 = NOVALUE;
    _24878 = NOVALUE;
    DeRef(_24892);
    _24892 = NOVALUE;
    DeRef(_24890);
    _24890 = NOVALUE;
    DeRef(_24900);
    _24900 = NOVALUE;
    _24896 = NOVALUE;
    DeRef(_24898);
    _24898 = NOVALUE;
    _24917 = NOVALUE;
    _24904 = NOVALUE;
    DeRef(_24906);
    _24906 = NOVALUE;
    _24910 = NOVALUE;
    _24922 = NOVALUE;
    DeRef(_24925);
    _24925 = NOVALUE;
    return _tok_47283;
    goto L25; // [1090] 1320
L23: 

    /** 	elsif st_builtin != 0 then*/
    if (_st_builtin_47281 == 0)
    goto L26; // [1095] 1319

    /** 		if length(dup_globals) and find(SymTab[st_builtin][S_NAME], builtin_warnings) = 0 then*/
    if (IS_SEQUENCE(_53dup_globals_47252)){
            _24949 = SEQ_PTR(_53dup_globals_47252)->length;
    }
    else {
        _24949 = 1;
    }
    if (_24949 == 0) {
        goto L27; // [1106] 1279
    }
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _24951 = (int)*(((s1_ptr)_2)->base + _st_builtin_47281);
    _2 = (int)SEQ_PTR(_24951);
    if (!IS_ATOM_INT(_35S_NAME_15917)){
        _24952 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15917)->dbl));
    }
    else{
        _24952 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15917);
    }
    _24951 = NOVALUE;
    _24953 = find_from(_24952, _53builtin_warnings_47256, 1);
    _24952 = NOVALUE;
    _24954 = (_24953 == 0);
    _24953 = NOVALUE;
    if (_24954 == 0)
    {
        DeRef(_24954);
        _24954 = NOVALUE;
        goto L27; // [1134] 1279
    }
    else{
        DeRef(_24954);
        _24954 = NOVALUE;
    }

    /** 			sequence msg_file */

    /** 			b_name = SymTab[st_builtin][S_NAME]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _24955 = (int)*(((s1_ptr)_2)->base + _st_builtin_47281);
    DeRef(_b_name_47275);
    _2 = (int)SEQ_PTR(_24955);
    if (!IS_ATOM_INT(_35S_NAME_15917)){
        _b_name_47275 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15917)->dbl));
    }
    else{
        _b_name_47275 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15917);
    }
    Ref(_b_name_47275);
    _24955 = NOVALUE;

    /** 			builtin_warnings = append(builtin_warnings, b_name)*/
    RefDS(_b_name_47275);
    Append(&_53builtin_warnings_47256, _53builtin_warnings_47256, _b_name_47275);

    /** 			if length(dup_globals) > 1 then*/
    if (IS_SEQUENCE(_53dup_globals_47252)){
            _24958 = SEQ_PTR(_53dup_globals_47252)->length;
    }
    else {
        _24958 = 1;
    }
    if (_24958 <= 1)
    goto L28; // [1170] 1184

    /** 				msg = "\n"*/
    RefDS(_22175);
    DeRef(_msg_47274);
    _msg_47274 = _22175;
    goto L29; // [1181] 1192
L28: 

    /** 				msg = ""*/
    RefDS(_22023);
    DeRef(_msg_47274);
    _msg_47274 = _22023;
L29: 

    /** 			for i = 1 to length(dup_globals) do*/
    if (IS_SEQUENCE(_53dup_globals_47252)){
            _24960 = SEQ_PTR(_53dup_globals_47252)->length;
    }
    else {
        _24960 = 1;
    }
    {
        int _i_47539;
        _i_47539 = 1;
L2A: 
        if (_i_47539 > _24960){
            goto L2B; // [1199] 1255
        }

        /** 				msg_file = known_files[SymTab[dup_globals[i]][S_FILE_NO]]*/
        _2 = (int)SEQ_PTR(_53dup_globals_47252);
        _24961 = (int)*(((s1_ptr)_2)->base + _i_47539);
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        if (!IS_ATOM_INT(_24961)){
            _24962 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_24961)->dbl));
        }
        else{
            _24962 = (int)*(((s1_ptr)_2)->base + _24961);
        }
        _2 = (int)SEQ_PTR(_24962);
        if (!IS_ATOM_INT(_35S_FILE_NO_15913)){
            _24963 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FILE_NO_15913)->dbl));
        }
        else{
            _24963 = (int)*(((s1_ptr)_2)->base + _35S_FILE_NO_15913);
        }
        _24962 = NOVALUE;
        DeRef(_msg_file_47528);
        _2 = (int)SEQ_PTR(_36known_files_15243);
        if (!IS_ATOM_INT(_24963)){
            _msg_file_47528 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_24963)->dbl));
        }
        else{
            _msg_file_47528 = (int)*(((s1_ptr)_2)->base + _24963);
        }
        Ref(_msg_file_47528);

        /** 				msg &= "    " & msg_file & "\n"*/
        {
            int concat_list[3];

            concat_list[0] = _22175;
            concat_list[1] = _msg_file_47528;
            concat_list[2] = _24965;
            Concat_N((object_ptr)&_24966, concat_list, 3);
        }
        Concat((object_ptr)&_msg_47274, _msg_47274, _24966);
        DeRefDS(_24966);
        _24966 = NOVALUE;

        /** 			end for*/
        _i_47539 = _i_47539 + 1;
        goto L2A; // [1250] 1206
L2B: 
        ;
    }

    /** 			Warning(234, builtin_chosen_warning_flag, {b_name, known_files[scanning_file], msg})*/
    _2 = (int)SEQ_PTR(_36known_files_15243);
    _24968 = (int)*(((s1_ptr)_2)->base + _scanning_file_47268);
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_b_name_47275);
    *((int *)(_2+4)) = _b_name_47275;
    Ref(_24968);
    *((int *)(_2+8)) = _24968;
    RefDS(_msg_47274);
    *((int *)(_2+12)) = _msg_47274;
    _24969 = MAKE_SEQ(_1);
    _24968 = NOVALUE;
    _44Warning(234, 8, _24969);
    _24969 = NOVALUE;
L27: 
    DeRef(_msg_file_47528);
    _msg_file_47528 = NOVALUE;

    /** 		tok = {SymTab[st_builtin][S_TOKEN], st_builtin}*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _24970 = (int)*(((s1_ptr)_2)->base + _st_builtin_47281);
    _2 = (int)SEQ_PTR(_24970);
    if (!IS_ATOM_INT(_35S_TOKEN_15922)){
        _24971 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TOKEN_15922)->dbl));
    }
    else{
        _24971 = (int)*(((s1_ptr)_2)->base + _35S_TOKEN_15922);
    }
    _24970 = NOVALUE;
    Ref(_24971);
    DeRef(_tok_47283);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _24971;
    ((int *)_2)[2] = _st_builtin_47281;
    _tok_47283 = MAKE_SEQ(_1);
    _24971 = NOVALUE;

    /** 		if BIND then*/
    if (_35BIND_15890 == 0)
    {
        goto L2C; // [1303] 1312
    }
    else{
    }

    /** 			add_ref(tok)*/
    RefDS(_tok_47283);
    _53add_ref(_tok_47283);
L2C: 

    /** 		return tok*/
    DeRefDS(_word_47266);
    DeRef(_msg_47274);
    DeRef(_b_name_47275);
    DeRef(_gtok_47284);
    DeRef(_24851);
    _24851 = NOVALUE;
    DeRef(_24841);
    _24841 = NOVALUE;
    _24865 = NOVALUE;
    _24870 = NOVALUE;
    _24869 = NOVALUE;
    _24885 = NOVALUE;
    _24878 = NOVALUE;
    DeRef(_24892);
    _24892 = NOVALUE;
    DeRef(_24890);
    _24890 = NOVALUE;
    DeRef(_24900);
    _24900 = NOVALUE;
    _24896 = NOVALUE;
    DeRef(_24898);
    _24898 = NOVALUE;
    _24917 = NOVALUE;
    _24904 = NOVALUE;
    DeRef(_24906);
    _24906 = NOVALUE;
    _24910 = NOVALUE;
    _24922 = NOVALUE;
    DeRef(_24925);
    _24925 = NOVALUE;
    _24961 = NOVALUE;
    _24963 = NOVALUE;
    return _tok_47283;
L26: 
L25: 

    /** ifdef STDDEBUG then*/

    /** 	if length(dup_globals) > 1 and find( 1, in_include_path ) then*/
    if (IS_SEQUENCE(_53dup_globals_47252)){
            _24973 = SEQ_PTR(_53dup_globals_47252)->length;
    }
    else {
        _24973 = 1;
    }
    _24974 = (_24973 > 1);
    _24973 = NOVALUE;
    if (_24974 == 0) {
        goto L2D; // [1333] 1452
    }
    _24976 = find_from(1, _53in_include_path_47254, 1);
    if (_24976 == 0)
    {
        _24976 = NOVALUE;
        goto L2D; // [1345] 1452
    }
    else{
        _24976 = NOVALUE;
    }

    /** 		ix = 1*/
    _ix_47278 = 1;

    /** 		while ix <= length(dup_globals) do*/
L2E: 
    if (IS_SEQUENCE(_53dup_globals_47252)){
            _24977 = SEQ_PTR(_53dup_globals_47252)->length;
    }
    else {
        _24977 = 1;
    }
    if (_ix_47278 > _24977)
    goto L2F; // [1363] 1411

    /** 			if in_include_path[ix] then*/
    _2 = (int)SEQ_PTR(_53in_include_path_47254);
    _24979 = (int)*(((s1_ptr)_2)->base + _ix_47278);
    if (_24979 == 0) {
        _24979 = NOVALUE;
        goto L30; // [1375] 1387
    }
    else {
        if (!IS_ATOM_INT(_24979) && DBL_PTR(_24979)->dbl == 0.0){
            _24979 = NOVALUE;
            goto L30; // [1375] 1387
        }
        _24979 = NOVALUE;
    }
    _24979 = NOVALUE;

    /** 				ix += 1*/
    _ix_47278 = _ix_47278 + 1;
    goto L2E; // [1384] 1358
L30: 

    /** 				dup_globals     = remove( dup_globals, ix )*/
    {
        s1_ptr assign_space = SEQ_PTR(_53dup_globals_47252);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_ix_47278)) ? _ix_47278 : (long)(DBL_PTR(_ix_47278)->dbl);
        int stop = (IS_ATOM_INT(_ix_47278)) ? _ix_47278 : (long)(DBL_PTR(_ix_47278)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_53dup_globals_47252), start, &_53dup_globals_47252 );
            }
            else Tail(SEQ_PTR(_53dup_globals_47252), stop+1, &_53dup_globals_47252);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_53dup_globals_47252), start, &_53dup_globals_47252);
        }
        else {
            assign_slice_seq = &assign_space;
            _53dup_globals_47252 = Remove_elements(start, stop, (SEQ_PTR(_53dup_globals_47252)->ref == 1));
        }
    }

    /** 				in_include_path = remove( in_include_path, ix )*/
    {
        s1_ptr assign_space = SEQ_PTR(_53in_include_path_47254);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_ix_47278)) ? _ix_47278 : (long)(DBL_PTR(_ix_47278)->dbl);
        int stop = (IS_ATOM_INT(_ix_47278)) ? _ix_47278 : (long)(DBL_PTR(_ix_47278)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_53in_include_path_47254), start, &_53in_include_path_47254 );
            }
            else Tail(SEQ_PTR(_53in_include_path_47254), stop+1, &_53in_include_path_47254);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_53in_include_path_47254), start, &_53in_include_path_47254);
        }
        else {
            assign_slice_seq = &assign_space;
            _53in_include_path_47254 = Remove_elements(start, stop, (SEQ_PTR(_53in_include_path_47254)->ref == 1));
        }
    }

    /** 		end while*/
    goto L2E; // [1408] 1358
L2F: 

    /** 		if length(dup_globals) = 1 then*/
    if (IS_SEQUENCE(_53dup_globals_47252)){
            _24983 = SEQ_PTR(_53dup_globals_47252)->length;
    }
    else {
        _24983 = 1;
    }
    if (_24983 != 1)
    goto L31; // [1418] 1451

    /** 				st_ptr = dup_globals[1]*/
    _2 = (int)SEQ_PTR(_53dup_globals_47252);
    _st_ptr_47280 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_st_ptr_47280)){
        _st_ptr_47280 = (long)DBL_PTR(_st_ptr_47280)->dbl;
    }

    /** 				gtok = {SymTab[st_ptr][S_TOKEN], st_ptr}*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _24986 = (int)*(((s1_ptr)_2)->base + _st_ptr_47280);
    _2 = (int)SEQ_PTR(_24986);
    if (!IS_ATOM_INT(_35S_TOKEN_15922)){
        _24987 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TOKEN_15922)->dbl));
    }
    else{
        _24987 = (int)*(((s1_ptr)_2)->base + _35S_TOKEN_15922);
    }
    _24986 = NOVALUE;
    Ref(_24987);
    DeRef(_gtok_47284);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _24987;
    ((int *)_2)[2] = _st_ptr_47280;
    _gtok_47284 = MAKE_SEQ(_1);
    _24987 = NOVALUE;
L31: 
L2D: 

    /** ifdef STDDEBUG then*/

    /** 	if length(dup_globals) = 1 and st_builtin = 0 then*/
    if (IS_SEQUENCE(_53dup_globals_47252)){
            _24989 = SEQ_PTR(_53dup_globals_47252)->length;
    }
    else {
        _24989 = 1;
    }
    _24990 = (_24989 == 1);
    _24989 = NOVALUE;
    if (_24990 == 0) {
        goto L32; // [1465] 1642
    }
    _24992 = (_st_builtin_47281 == 0);
    if (_24992 == 0)
    {
        DeRef(_24992);
        _24992 = NOVALUE;
        goto L32; // [1474] 1642
    }
    else{
        DeRef(_24992);
        _24992 = NOVALUE;
    }

    /** 		if BIND then*/
    if (_35BIND_15890 == 0)
    {
        goto L33; // [1481] 1492
    }
    else{
    }

    /** 			add_ref(gtok)*/
    Ref(_gtok_47284);
    _53add_ref(_gtok_47284);
L33: 

    /** 		if not in_include_path[1] and*/
    _2 = (int)SEQ_PTR(_53in_include_path_47254);
    _24993 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_24993)) {
        _24994 = (_24993 == 0);
    }
    else {
        _24994 = unary_op(NOT, _24993);
    }
    _24993 = NOVALUE;
    if (IS_ATOM_INT(_24994)) {
        if (_24994 == 0) {
            goto L34; // [1503] 1635
        }
    }
    else {
        if (DBL_PTR(_24994)->dbl == 0.0) {
            goto L34; // [1503] 1635
        }
    }
    _2 = (int)SEQ_PTR(_gtok_47284);
    _24996 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!IS_ATOM_INT(_24996)){
        _24997 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_24996)->dbl));
    }
    else{
        _24997 = (int)*(((s1_ptr)_2)->base + _24996);
    }
    _2 = (int)SEQ_PTR(_24997);
    if (!IS_ATOM_INT(_35S_FILE_NO_15913)){
        _24998 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FILE_NO_15913)->dbl));
    }
    else{
        _24998 = (int)*(((s1_ptr)_2)->base + _35S_FILE_NO_15913);
    }
    _24997 = NOVALUE;
    Ref(_24998);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _scanning_file_47268;
    ((int *)_2)[2] = _24998;
    _24999 = MAKE_SEQ(_1);
    _24998 = NOVALUE;
    _25000 = find_from(_24999, _53include_warnings_47255, 1);
    DeRefDS(_24999);
    _24999 = NOVALUE;
    _25001 = (_25000 == 0);
    _25000 = NOVALUE;
    if (_25001 == 0)
    {
        DeRef(_25001);
        _25001 = NOVALUE;
        goto L34; // [1542] 1635
    }
    else{
        DeRef(_25001);
        _25001 = NOVALUE;
    }

    /** 			include_warnings = prepend( include_warnings,*/
    _2 = (int)SEQ_PTR(_gtok_47284);
    _25002 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!IS_ATOM_INT(_25002)){
        _25003 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_25002)->dbl));
    }
    else{
        _25003 = (int)*(((s1_ptr)_2)->base + _25002);
    }
    _2 = (int)SEQ_PTR(_25003);
    if (!IS_ATOM_INT(_35S_FILE_NO_15913)){
        _25004 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FILE_NO_15913)->dbl));
    }
    else{
        _25004 = (int)*(((s1_ptr)_2)->base + _35S_FILE_NO_15913);
    }
    _25003 = NOVALUE;
    Ref(_25004);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _scanning_file_47268;
    ((int *)_2)[2] = _25004;
    _25005 = MAKE_SEQ(_1);
    _25004 = NOVALUE;
    RefDS(_25005);
    Prepend(&_53include_warnings_47255, _53include_warnings_47255, _25005);
    DeRefDS(_25005);
    _25005 = NOVALUE;

    /** ifdef STDDEBUG then*/

    /** 				symbol_resolution_warning = GetMsgText(233,0,*/
    _2 = (int)SEQ_PTR(_36known_files_15243);
    _25007 = (int)*(((s1_ptr)_2)->base + _scanning_file_47268);
    Ref(_25007);
    _25008 = _53name_ext(_25007);
    _25007 = NOVALUE;
    _2 = (int)SEQ_PTR(_gtok_47284);
    _25009 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!IS_ATOM_INT(_25009)){
        _25010 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_25009)->dbl));
    }
    else{
        _25010 = (int)*(((s1_ptr)_2)->base + _25009);
    }
    _2 = (int)SEQ_PTR(_25010);
    if (!IS_ATOM_INT(_35S_FILE_NO_15913)){
        _25011 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FILE_NO_15913)->dbl));
    }
    else{
        _25011 = (int)*(((s1_ptr)_2)->base + _35S_FILE_NO_15913);
    }
    _25010 = NOVALUE;
    _2 = (int)SEQ_PTR(_36known_files_15243);
    if (!IS_ATOM_INT(_25011)){
        _25012 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_25011)->dbl));
    }
    else{
        _25012 = (int)*(((s1_ptr)_2)->base + _25011);
    }
    Ref(_25012);
    _25013 = _53name_ext(_25012);
    _25012 = NOVALUE;
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _25008;
    *((int *)(_2+8)) = _35line_number_16245;
    RefDS(_word_47266);
    *((int *)(_2+12)) = _word_47266;
    *((int *)(_2+16)) = _25013;
    _25014 = MAKE_SEQ(_1);
    _25013 = NOVALUE;
    _25008 = NOVALUE;
    _0 = _45GetMsgText(233, 0, _25014);
    DeRef(_35symbol_resolution_warning_16345);
    _35symbol_resolution_warning_16345 = _0;
    _25014 = NOVALUE;
L34: 

    /** 		return gtok*/
    DeRefDS(_word_47266);
    DeRef(_msg_47274);
    DeRef(_b_name_47275);
    DeRef(_tok_47283);
    DeRef(_24906);
    _24906 = NOVALUE;
    DeRef(_24990);
    _24990 = NOVALUE;
    _25009 = NOVALUE;
    _24870 = NOVALUE;
    DeRef(_24900);
    _24900 = NOVALUE;
    DeRef(_24925);
    _24925 = NOVALUE;
    DeRef(_24898);
    _24898 = NOVALUE;
    _24910 = NOVALUE;
    _24865 = NOVALUE;
    _24869 = NOVALUE;
    DeRef(_24890);
    _24890 = NOVALUE;
    _24917 = NOVALUE;
    _24922 = NOVALUE;
    _25011 = NOVALUE;
    _24961 = NOVALUE;
    _24878 = NOVALUE;
    _25002 = NOVALUE;
    _24885 = NOVALUE;
    DeRef(_24994);
    _24994 = NOVALUE;
    _24996 = NOVALUE;
    _24896 = NOVALUE;
    DeRef(_24851);
    _24851 = NOVALUE;
    _24904 = NOVALUE;
    _24963 = NOVALUE;
    DeRef(_24892);
    _24892 = NOVALUE;
    DeRef(_24841);
    _24841 = NOVALUE;
    DeRef(_24974);
    _24974 = NOVALUE;
    return _gtok_47284;
L32: 

    /** 	if length(dup_globals) = 0 then*/
    if (IS_SEQUENCE(_53dup_globals_47252)){
            _25016 = SEQ_PTR(_53dup_globals_47252)->length;
    }
    else {
        _25016 = 1;
    }
    if (_25016 != 0)
    goto L35; // [1649] 1723

    /** 		defined = SC_UNDEFINED*/
    _defined_47277 = 9;

    /** 		if fwd_line_number then*/
    if (_35fwd_line_number_16246 == 0)
    {
        goto L36; // [1666] 1695
    }
    else{
    }

    /** 			last_ForwardLine     = ForwardLine*/
    Ref(_44ForwardLine_48519);
    DeRef(_44last_ForwardLine_48521);
    _44last_ForwardLine_48521 = _44ForwardLine_48519;

    /** 			last_forward_bp      = forward_bp*/
    _44last_forward_bp_48525 = _44forward_bp_48523;

    /** 			last_fwd_line_number = fwd_line_number*/
    _35last_fwd_line_number_16248 = _35fwd_line_number_16246;
L36: 

    /** 		ForwardLine = ThisLine*/
    Ref(_44ThisLine_48518);
    DeRef(_44ForwardLine_48519);
    _44ForwardLine_48519 = _44ThisLine_48518;

    /** 		forward_bp = bp*/
    _44forward_bp_48523 = _44bp_48522;

    /** 		fwd_line_number = line_number*/
    _35fwd_line_number_16246 = _35line_number_16245;
    goto L37; // [1720] 1766
L35: 

    /** 	elsif length(dup_globals) then*/
    if (IS_SEQUENCE(_53dup_globals_47252)){
            _25018 = SEQ_PTR(_53dup_globals_47252)->length;
    }
    else {
        _25018 = 1;
    }
    if (_25018 == 0)
    {
        _25018 = NOVALUE;
        goto L38; // [1730] 1745
    }
    else{
        _25018 = NOVALUE;
    }

    /** 		defined = SC_MULTIPLY_DEFINED*/
    _defined_47277 = 10;
    goto L37; // [1742] 1766
L38: 

    /** 	elsif length(dup_overrides) then*/
    if (IS_SEQUENCE(_53dup_overrides_47253)){
            _25019 = SEQ_PTR(_53dup_overrides_47253)->length;
    }
    else {
        _25019 = 1;
    }
    if (_25019 == 0)
    {
        _25019 = NOVALUE;
        goto L39; // [1752] 1765
    }
    else{
        _25019 = NOVALUE;
    }

    /** 		defined = SC_OVERRIDE*/
    _defined_47277 = 12;
L39: 
L37: 

    /** 	if No_new_entry then*/
    if (_53No_new_entry_47263 == 0)
    {
        goto L3A; // [1770] 1793
    }
    else{
    }

    /** 		return {IGNORED,word,defined,dup_globals}*/
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 509;
    RefDS(_word_47266);
    *((int *)(_2+8)) = _word_47266;
    *((int *)(_2+12)) = _defined_47277;
    RefDS(_53dup_globals_47252);
    *((int *)(_2+16)) = _53dup_globals_47252;
    _25020 = MAKE_SEQ(_1);
    DeRefDS(_word_47266);
    DeRef(_msg_47274);
    DeRef(_b_name_47275);
    DeRef(_tok_47283);
    DeRef(_gtok_47284);
    DeRef(_24906);
    _24906 = NOVALUE;
    DeRef(_24990);
    _24990 = NOVALUE;
    _25009 = NOVALUE;
    _24870 = NOVALUE;
    DeRef(_24900);
    _24900 = NOVALUE;
    DeRef(_24925);
    _24925 = NOVALUE;
    DeRef(_24898);
    _24898 = NOVALUE;
    _24910 = NOVALUE;
    _24865 = NOVALUE;
    _24869 = NOVALUE;
    DeRef(_24890);
    _24890 = NOVALUE;
    _24917 = NOVALUE;
    _24922 = NOVALUE;
    _25011 = NOVALUE;
    _24961 = NOVALUE;
    _24878 = NOVALUE;
    _25002 = NOVALUE;
    _24885 = NOVALUE;
    DeRef(_24994);
    _24994 = NOVALUE;
    _24996 = NOVALUE;
    _24896 = NOVALUE;
    DeRef(_24851);
    _24851 = NOVALUE;
    _24904 = NOVALUE;
    _24963 = NOVALUE;
    DeRef(_24892);
    _24892 = NOVALUE;
    DeRef(_24841);
    _24841 = NOVALUE;
    DeRef(_24974);
    _24974 = NOVALUE;
    return _25020;
L3A: 

    /** 	tok = {VARIABLE, NewEntry(word, 0, defined,*/
    _2 = (int)SEQ_PTR(_53buckets_46087);
    _25021 = (int)*(((s1_ptr)_2)->base + _hashval_47272);
    RefDS(_word_47266);
    Ref(_25021);
    _25022 = _53NewEntry(_word_47266, 0, _defined_47277, -100, _hashval_47272, _25021, 0);
    _25021 = NOVALUE;
    DeRef(_tok_47283);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -100;
    ((int *)_2)[2] = _25022;
    _tok_47283 = MAKE_SEQ(_1);
    _25022 = NOVALUE;

    /** 	buckets[hashval] = tok[T_SYM]*/
    _2 = (int)SEQ_PTR(_tok_47283);
    _25024 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_25024);
    _2 = (int)SEQ_PTR(_53buckets_46087);
    _2 = (int)(((s1_ptr)_2)->base + _hashval_47272);
    _1 = *(int *)_2;
    *(int *)_2 = _25024;
    if( _1 != _25024 ){
        DeRef(_1);
    }
    _25024 = NOVALUE;

    /** 	if file_no != -1 then*/
    if (_file_no_47267 == -1)
    goto L3B; // [1837] 1863

    /** 		SymTab[tok[T_SYM]][S_FILE_NO] = file_no*/
    _2 = (int)SEQ_PTR(_tok_47283);
    _25026 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_25026))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_25026)->dbl));
    else
    _3 = (int)(_25026 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35S_FILE_NO_15913))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FILE_NO_15913)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _35S_FILE_NO_15913);
    _1 = *(int *)_2;
    *(int *)_2 = _file_no_47267;
    DeRef(_1);
    _25027 = NOVALUE;
L3B: 

    /** 	return tok  -- no ref on newly declared symbol*/
    DeRefDS(_word_47266);
    DeRef(_msg_47274);
    DeRef(_b_name_47275);
    DeRef(_gtok_47284);
    DeRef(_24906);
    _24906 = NOVALUE;
    DeRef(_24990);
    _24990 = NOVALUE;
    _25009 = NOVALUE;
    DeRef(_25020);
    _25020 = NOVALUE;
    _24870 = NOVALUE;
    DeRef(_24900);
    _24900 = NOVALUE;
    DeRef(_24925);
    _24925 = NOVALUE;
    DeRef(_24898);
    _24898 = NOVALUE;
    _24910 = NOVALUE;
    _24865 = NOVALUE;
    _24869 = NOVALUE;
    DeRef(_24890);
    _24890 = NOVALUE;
    _24917 = NOVALUE;
    _24922 = NOVALUE;
    _25011 = NOVALUE;
    _24961 = NOVALUE;
    _24878 = NOVALUE;
    _25002 = NOVALUE;
    _24885 = NOVALUE;
    DeRef(_24994);
    _24994 = NOVALUE;
    _24996 = NOVALUE;
    _24896 = NOVALUE;
    DeRef(_24851);
    _24851 = NOVALUE;
    _24904 = NOVALUE;
    _24963 = NOVALUE;
    DeRef(_24892);
    _24892 = NOVALUE;
    DeRef(_24841);
    _24841 = NOVALUE;
    DeRef(_24974);
    _24974 = NOVALUE;
    _25026 = NOVALUE;
    return _tok_47283;
    ;
}


void _53Hide(int _s_47676)
{
    int _prev_47678 = NOVALUE;
    int _p_47679 = NOVALUE;
    int _25047 = NOVALUE;
    int _25046 = NOVALUE;
    int _25045 = NOVALUE;
    int _25043 = NOVALUE;
    int _25042 = NOVALUE;
    int _25041 = NOVALUE;
    int _25040 = NOVALUE;
    int _25039 = NOVALUE;
    int _25035 = NOVALUE;
    int _25034 = NOVALUE;
    int _25033 = NOVALUE;
    int _25032 = NOVALUE;
    int _25030 = NOVALUE;
    int _25029 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_s_47676)) {
        _1 = (long)(DBL_PTR(_s_47676)->dbl);
        DeRefDS(_s_47676);
        _s_47676 = _1;
    }

    /** 	p = buckets[SymTab[s][S_HASHVAL]]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _25029 = (int)*(((s1_ptr)_2)->base + _s_47676);
    _2 = (int)SEQ_PTR(_25029);
    _25030 = (int)*(((s1_ptr)_2)->base + 11);
    _25029 = NOVALUE;
    _2 = (int)SEQ_PTR(_53buckets_46087);
    if (!IS_ATOM_INT(_25030)){
        _p_47679 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_25030)->dbl));
    }
    else{
        _p_47679 = (int)*(((s1_ptr)_2)->base + _25030);
    }
    if (!IS_ATOM_INT(_p_47679)){
        _p_47679 = (long)DBL_PTR(_p_47679)->dbl;
    }

    /** 	prev = 0*/
    _prev_47678 = 0;

    /** 	while p != s and p != 0 do*/
L1: 
    _25032 = (_p_47679 != _s_47676);
    if (_25032 == 0) {
        goto L2; // [41] 81
    }
    _25034 = (_p_47679 != 0);
    if (_25034 == 0)
    {
        DeRef(_25034);
        _25034 = NOVALUE;
        goto L2; // [50] 81
    }
    else{
        DeRef(_25034);
        _25034 = NOVALUE;
    }

    /** 		prev = p*/
    _prev_47678 = _p_47679;

    /** 		p = SymTab[p][S_SAMEHASH]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _25035 = (int)*(((s1_ptr)_2)->base + _p_47679);
    _2 = (int)SEQ_PTR(_25035);
    _p_47679 = (int)*(((s1_ptr)_2)->base + 9);
    if (!IS_ATOM_INT(_p_47679)){
        _p_47679 = (long)DBL_PTR(_p_47679)->dbl;
    }
    _25035 = NOVALUE;

    /** 	end while*/
    goto L1; // [78] 37
L2: 

    /** 	if p = 0 then*/
    if (_p_47679 != 0)
    goto L3; // [83] 93

    /** 		return -- already hidden*/
    _25030 = NOVALUE;
    DeRef(_25032);
    _25032 = NOVALUE;
    return;
L3: 

    /** 	if prev = 0 then*/
    if (_prev_47678 != 0)
    goto L4; // [95] 134

    /** 		buckets[SymTab[s][S_HASHVAL]] = SymTab[s][S_SAMEHASH]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _25039 = (int)*(((s1_ptr)_2)->base + _s_47676);
    _2 = (int)SEQ_PTR(_25039);
    _25040 = (int)*(((s1_ptr)_2)->base + 11);
    _25039 = NOVALUE;
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _25041 = (int)*(((s1_ptr)_2)->base + _s_47676);
    _2 = (int)SEQ_PTR(_25041);
    _25042 = (int)*(((s1_ptr)_2)->base + 9);
    _25041 = NOVALUE;
    Ref(_25042);
    _2 = (int)SEQ_PTR(_53buckets_46087);
    if (!IS_ATOM_INT(_25040))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_25040)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _25040);
    _1 = *(int *)_2;
    *(int *)_2 = _25042;
    if( _1 != _25042 ){
        DeRef(_1);
    }
    _25042 = NOVALUE;
    goto L5; // [131] 162
L4: 

    /** 		SymTab[prev][S_SAMEHASH] = SymTab[s][S_SAMEHASH]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_prev_47678 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _25045 = (int)*(((s1_ptr)_2)->base + _s_47676);
    _2 = (int)SEQ_PTR(_25045);
    _25046 = (int)*(((s1_ptr)_2)->base + 9);
    _25045 = NOVALUE;
    Ref(_25046);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 9);
    _1 = *(int *)_2;
    *(int *)_2 = _25046;
    if( _1 != _25046 ){
        DeRef(_1);
    }
    _25046 = NOVALUE;
    _25043 = NOVALUE;
L5: 

    /** 	SymTab[s][S_SAMEHASH] = 0*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_s_47676 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 9);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _25047 = NOVALUE;

    /** end procedure*/
    _25030 = NOVALUE;
    DeRef(_25032);
    _25032 = NOVALUE;
    _25040 = NOVALUE;
    return;
    ;
}


void _53Show(int _s_47721)
{
    int _p_47723 = NOVALUE;
    int _25059 = NOVALUE;
    int _25058 = NOVALUE;
    int _25056 = NOVALUE;
    int _25055 = NOVALUE;
    int _25053 = NOVALUE;
    int _25052 = NOVALUE;
    int _25050 = NOVALUE;
    int _25049 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_s_47721)) {
        _1 = (long)(DBL_PTR(_s_47721)->dbl);
        DeRefDS(_s_47721);
        _s_47721 = _1;
    }

    /** 	p = buckets[SymTab[s][S_HASHVAL]]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _25049 = (int)*(((s1_ptr)_2)->base + _s_47721);
    _2 = (int)SEQ_PTR(_25049);
    _25050 = (int)*(((s1_ptr)_2)->base + 11);
    _25049 = NOVALUE;
    _2 = (int)SEQ_PTR(_53buckets_46087);
    if (!IS_ATOM_INT(_25050)){
        _p_47723 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_25050)->dbl));
    }
    else{
        _p_47723 = (int)*(((s1_ptr)_2)->base + _25050);
    }
    if (!IS_ATOM_INT(_p_47723)){
        _p_47723 = (long)DBL_PTR(_p_47723)->dbl;
    }

    /** 	if SymTab[s][S_SAMEHASH] or p = s then*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _25052 = (int)*(((s1_ptr)_2)->base + _s_47721);
    _2 = (int)SEQ_PTR(_25052);
    _25053 = (int)*(((s1_ptr)_2)->base + 9);
    _25052 = NOVALUE;
    if (IS_ATOM_INT(_25053)) {
        if (_25053 != 0) {
            goto L1; // [39] 52
        }
    }
    else {
        if (DBL_PTR(_25053)->dbl != 0.0) {
            goto L1; // [39] 52
        }
    }
    _25055 = (_p_47723 == _s_47721);
    if (_25055 == 0)
    {
        DeRef(_25055);
        _25055 = NOVALUE;
        goto L2; // [48] 58
    }
    else{
        DeRef(_25055);
        _25055 = NOVALUE;
    }
L1: 

    /** 		return*/
    _25050 = NOVALUE;
    _25053 = NOVALUE;
    return;
L2: 

    /** 	SymTab[s][S_SAMEHASH] = p*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_s_47721 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 9);
    _1 = *(int *)_2;
    *(int *)_2 = _p_47723;
    DeRef(_1);
    _25056 = NOVALUE;

    /** 	buckets[SymTab[s][S_HASHVAL]] = s*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _25058 = (int)*(((s1_ptr)_2)->base + _s_47721);
    _2 = (int)SEQ_PTR(_25058);
    _25059 = (int)*(((s1_ptr)_2)->base + 11);
    _25058 = NOVALUE;
    _2 = (int)SEQ_PTR(_53buckets_46087);
    if (!IS_ATOM_INT(_25059))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_25059)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _25059);
    _1 = *(int *)_2;
    *(int *)_2 = _s_47721;
    DeRef(_1);

    /** end procedure*/
    _25050 = NOVALUE;
    _25053 = NOVALUE;
    _25059 = NOVALUE;
    return;
    ;
}


void _53hide_params(int _s_47747)
{
    int _param_47749 = NOVALUE;
    int _25062 = NOVALUE;
    int _25061 = NOVALUE;
    int _25060 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_s_47747)) {
        _1 = (long)(DBL_PTR(_s_47747)->dbl);
        DeRefDS(_s_47747);
        _s_47747 = _1;
    }

    /** 	symtab_index param = s*/
    _param_47749 = _s_47747;

    /** 	for i = 1 to SymTab[s][S_NUM_ARGS] do*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _25060 = (int)*(((s1_ptr)_2)->base + _s_47747);
    _2 = (int)SEQ_PTR(_25060);
    if (!IS_ATOM_INT(_35S_NUM_ARGS_15968)){
        _25061 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NUM_ARGS_15968)->dbl));
    }
    else{
        _25061 = (int)*(((s1_ptr)_2)->base + _35S_NUM_ARGS_15968);
    }
    _25060 = NOVALUE;
    {
        int _i_47751;
        _i_47751 = 1;
L1: 
        if (binary_op_a(GREATER, _i_47751, _25061)){
            goto L2; // [24] 59
        }

        /** 		param = SymTab[s][S_NEXT]*/
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _25062 = (int)*(((s1_ptr)_2)->base + _s_47747);
        _2 = (int)SEQ_PTR(_25062);
        _param_47749 = (int)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_param_47749)){
            _param_47749 = (long)DBL_PTR(_param_47749)->dbl;
        }
        _25062 = NOVALUE;

        /** 		Hide( param )*/
        _53Hide(_param_47749);

        /** 	end for*/
        _0 = _i_47751;
        if (IS_ATOM_INT(_i_47751)) {
            _i_47751 = _i_47751 + 1;
            if ((long)((unsigned long)_i_47751 +(unsigned long) HIGH_BITS) >= 0){
                _i_47751 = NewDouble((double)_i_47751);
            }
        }
        else {
            _i_47751 = binary_op_a(PLUS, _i_47751, 1);
        }
        DeRef(_0);
        goto L1; // [54] 31
L2: 
        ;
        DeRef(_i_47751);
    }

    /** end procedure*/
    _25061 = NOVALUE;
    return;
    ;
}


void _53show_params(int _s_47763)
{
    int _param_47765 = NOVALUE;
    int _25066 = NOVALUE;
    int _25065 = NOVALUE;
    int _25064 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_s_47763)) {
        _1 = (long)(DBL_PTR(_s_47763)->dbl);
        DeRefDS(_s_47763);
        _s_47763 = _1;
    }

    /** 	symtab_index param = s*/
    _param_47765 = _s_47763;

    /** 	for i = 1 to SymTab[s][S_NUM_ARGS] do*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _25064 = (int)*(((s1_ptr)_2)->base + _s_47763);
    _2 = (int)SEQ_PTR(_25064);
    if (!IS_ATOM_INT(_35S_NUM_ARGS_15968)){
        _25065 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NUM_ARGS_15968)->dbl));
    }
    else{
        _25065 = (int)*(((s1_ptr)_2)->base + _35S_NUM_ARGS_15968);
    }
    _25064 = NOVALUE;
    {
        int _i_47767;
        _i_47767 = 1;
L1: 
        if (binary_op_a(GREATER, _i_47767, _25065)){
            goto L2; // [24] 59
        }

        /** 		param = SymTab[s][S_NEXT]*/
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _25066 = (int)*(((s1_ptr)_2)->base + _s_47763);
        _2 = (int)SEQ_PTR(_25066);
        _param_47765 = (int)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_param_47765)){
            _param_47765 = (long)DBL_PTR(_param_47765)->dbl;
        }
        _25066 = NOVALUE;

        /** 		Show( param )*/
        _53Show(_param_47765);

        /** 	end for*/
        _0 = _i_47767;
        if (IS_ATOM_INT(_i_47767)) {
            _i_47767 = _i_47767 + 1;
            if ((long)((unsigned long)_i_47767 +(unsigned long) HIGH_BITS) >= 0){
                _i_47767 = NewDouble((double)_i_47767);
            }
        }
        else {
            _i_47767 = binary_op_a(PLUS, _i_47767, 1);
        }
        DeRef(_0);
        goto L1; // [54] 31
L2: 
        ;
        DeRef(_i_47767);
    }

    /** end procedure*/
    _25065 = NOVALUE;
    return;
    ;
}


void _53LintCheck(int _s_47779)
{
    int _warn_level_47780 = NOVALUE;
    int _file_47781 = NOVALUE;
    int _vscope_47782 = NOVALUE;
    int _vname_47783 = NOVALUE;
    int _vusage_47784 = NOVALUE;
    int _25127 = NOVALUE;
    int _25126 = NOVALUE;
    int _25125 = NOVALUE;
    int _25124 = NOVALUE;
    int _25123 = NOVALUE;
    int _25122 = NOVALUE;
    int _25120 = NOVALUE;
    int _25119 = NOVALUE;
    int _25118 = NOVALUE;
    int _25117 = NOVALUE;
    int _25116 = NOVALUE;
    int _25115 = NOVALUE;
    int _25112 = NOVALUE;
    int _25111 = NOVALUE;
    int _25110 = NOVALUE;
    int _25109 = NOVALUE;
    int _25108 = NOVALUE;
    int _25107 = NOVALUE;
    int _25105 = NOVALUE;
    int _25103 = NOVALUE;
    int _25102 = NOVALUE;
    int _25100 = NOVALUE;
    int _25099 = NOVALUE;
    int _25097 = NOVALUE;
    int _25096 = NOVALUE;
    int _25095 = NOVALUE;
    int _25094 = NOVALUE;
    int _25092 = NOVALUE;
    int _25091 = NOVALUE;
    int _25087 = NOVALUE;
    int _25084 = NOVALUE;
    int _25083 = NOVALUE;
    int _25082 = NOVALUE;
    int _25081 = NOVALUE;
    int _25078 = NOVALUE;
    int _25077 = NOVALUE;
    int _25072 = NOVALUE;
    int _25070 = NOVALUE;
    int _25068 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_s_47779)) {
        _1 = (long)(DBL_PTR(_s_47779)->dbl);
        DeRefDS(_s_47779);
        _s_47779 = _1;
    }

    /** 	vusage = SymTab[s][S_USAGE]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _25068 = (int)*(((s1_ptr)_2)->base + _s_47779);
    _2 = (int)SEQ_PTR(_25068);
    _vusage_47784 = (int)*(((s1_ptr)_2)->base + 5);
    if (!IS_ATOM_INT(_vusage_47784)){
        _vusage_47784 = (long)DBL_PTR(_vusage_47784)->dbl;
    }
    _25068 = NOVALUE;

    /** 	vscope = SymTab[s][S_SCOPE]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _25070 = (int)*(((s1_ptr)_2)->base + _s_47779);
    _2 = (int)SEQ_PTR(_25070);
    _vscope_47782 = (int)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_vscope_47782)){
        _vscope_47782 = (long)DBL_PTR(_vscope_47782)->dbl;
    }
    _25070 = NOVALUE;

    /** 	vname = SymTab[s][S_NAME]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _25072 = (int)*(((s1_ptr)_2)->base + _s_47779);
    DeRef(_vname_47783);
    _2 = (int)SEQ_PTR(_25072);
    if (!IS_ATOM_INT(_35S_NAME_15917)){
        _vname_47783 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15917)->dbl));
    }
    else{
        _vname_47783 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15917);
    }
    Ref(_vname_47783);
    _25072 = NOVALUE;

    /** 	switch vusage do*/
    _0 = _vusage_47784;
    switch ( _0 ){ 

        /** 		case U_UNUSED then*/
        case 0:

        /** 			warn_level = 1*/
        _warn_level_47780 = 1;
        goto L1; // [67] 193

        /** 		case U_WRITTEN then -- Set but never read*/
        case 2:

        /** 			warn_level = 2*/
        _warn_level_47780 = 2;

        /** 			if vscope > SC_LOCAL then*/
        if (_vscope_47782 <= 5)
        goto L2; // [82] 94

        /** 				warn_level = 0 */
        _warn_level_47780 = 0;
        goto L1; // [91] 193
L2: 

        /** 			elsif SymTab[s][S_MODE] = M_CONSTANT then*/
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _25077 = (int)*(((s1_ptr)_2)->base + _s_47779);
        _2 = (int)SEQ_PTR(_25077);
        _25078 = (int)*(((s1_ptr)_2)->base + 3);
        _25077 = NOVALUE;
        if (binary_op_a(NOTEQ, _25078, 2)){
            _25078 = NOVALUE;
            goto L1; // [110] 193
        }
        _25078 = NOVALUE;

        /** 				if not Strict_is_on then*/
        if (_35Strict_is_on_16309 != 0)
        goto L1; // [118] 193

        /** 					warn_level = 0 */
        _warn_level_47780 = 0;
        goto L1; // [129] 193

        /** 		case U_READ then -- Read but never set*/
        case 1:

        /** 			if SymTab[s][S_VARNUM] >= SymTab[CurrentSub][S_NUM_ARGS] then*/
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _25081 = (int)*(((s1_ptr)_2)->base + _s_47779);
        _2 = (int)SEQ_PTR(_25081);
        _25082 = (int)*(((s1_ptr)_2)->base + 16);
        _25081 = NOVALUE;
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _25083 = (int)*(((s1_ptr)_2)->base + _35CurrentSub_16252);
        _2 = (int)SEQ_PTR(_25083);
        if (!IS_ATOM_INT(_35S_NUM_ARGS_15968)){
            _25084 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NUM_ARGS_15968)->dbl));
        }
        else{
            _25084 = (int)*(((s1_ptr)_2)->base + _35S_NUM_ARGS_15968);
        }
        _25083 = NOVALUE;
        if (binary_op_a(LESS, _25082, _25084)){
            _25082 = NOVALUE;
            _25084 = NOVALUE;
            goto L3; // [163] 175
        }
        _25082 = NOVALUE;
        _25084 = NOVALUE;

        /** 		    	warn_level = 3*/
        _warn_level_47780 = 3;
        goto L1; // [172] 193
L3: 

        /** 		    	warn_level = 0*/
        _warn_level_47780 = 0;
        goto L1; // [181] 193

        /** 	    case else*/
        default:

        /** 	    	warn_level = 0*/
        _warn_level_47780 = 0;
    ;}L1: 

    /** 	if warn_level = 0 then*/
    if (_warn_level_47780 != 0)
    goto L4; // [197] 207

    /** 		return*/
    DeRef(_file_47781);
    DeRef(_vname_47783);
    return;
L4: 

    /** 	file = abbreviate_path(known_files[current_file_no])*/
    _2 = (int)SEQ_PTR(_36known_files_15243);
    _25087 = (int)*(((s1_ptr)_2)->base + _35current_file_no_16244);
    Ref(_25087);
    RefDS(_22023);
    _0 = _file_47781;
    _file_47781 = _17abbreviate_path(_25087, _22023);
    DeRef(_0);
    _25087 = NOVALUE;

    /** 	if warn_level = 3 then*/
    if (_warn_level_47780 != 3)
    goto L5; // [226] 308

    /** 		if vscope = SC_LOCAL then*/
    if (_vscope_47782 != 5)
    goto L6; // [234] 275

    /** 			if current_file_no = SymTab[s][S_FILE_NO] then*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _25091 = (int)*(((s1_ptr)_2)->base + _s_47779);
    _2 = (int)SEQ_PTR(_25091);
    if (!IS_ATOM_INT(_35S_FILE_NO_15913)){
        _25092 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FILE_NO_15913)->dbl));
    }
    else{
        _25092 = (int)*(((s1_ptr)_2)->base + _35S_FILE_NO_15913);
    }
    _25091 = NOVALUE;
    if (binary_op_a(NOTEQ, _35current_file_no_16244, _25092)){
        _25092 = NOVALUE;
        goto L7; // [254] 602
    }
    _25092 = NOVALUE;

    /** 				Warning(226, no_value_warning_flag, {file,  vname})*/
    RefDS(_vname_47783);
    RefDS(_file_47781);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _file_47781;
    ((int *)_2)[2] = _vname_47783;
    _25094 = MAKE_SEQ(_1);
    _44Warning(226, 32, _25094);
    _25094 = NOVALUE;
    goto L7; // [272] 602
L6: 

    /** 			Warning(227, no_value_warning_flag, {file,  vname, SymTab[CurrentSub][S_NAME]})*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _25095 = (int)*(((s1_ptr)_2)->base + _35CurrentSub_16252);
    _2 = (int)SEQ_PTR(_25095);
    if (!IS_ATOM_INT(_35S_NAME_15917)){
        _25096 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15917)->dbl));
    }
    else{
        _25096 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15917);
    }
    _25095 = NOVALUE;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_file_47781);
    *((int *)(_2+4)) = _file_47781;
    RefDS(_vname_47783);
    *((int *)(_2+8)) = _vname_47783;
    Ref(_25096);
    *((int *)(_2+12)) = _25096;
    _25097 = MAKE_SEQ(_1);
    _25096 = NOVALUE;
    _44Warning(227, 32, _25097);
    _25097 = NOVALUE;
    goto L7; // [305] 602
L5: 

    /** 		if vscope = SC_LOCAL then*/
    if (_vscope_47782 != 5)
    goto L8; // [312] 412

    /** 			if current_file_no = SymTab[s][S_FILE_NO] then*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _25099 = (int)*(((s1_ptr)_2)->base + _s_47779);
    _2 = (int)SEQ_PTR(_25099);
    if (!IS_ATOM_INT(_35S_FILE_NO_15913)){
        _25100 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FILE_NO_15913)->dbl));
    }
    else{
        _25100 = (int)*(((s1_ptr)_2)->base + _35S_FILE_NO_15913);
    }
    _25099 = NOVALUE;
    if (binary_op_a(NOTEQ, _35current_file_no_16244, _25100)){
        _25100 = NOVALUE;
        goto L9; // [332] 601
    }
    _25100 = NOVALUE;

    /** 				if SymTab[s][S_MODE] = M_CONSTANT then*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _25102 = (int)*(((s1_ptr)_2)->base + _s_47779);
    _2 = (int)SEQ_PTR(_25102);
    _25103 = (int)*(((s1_ptr)_2)->base + 3);
    _25102 = NOVALUE;
    if (binary_op_a(NOTEQ, _25103, 2)){
        _25103 = NOVALUE;
        goto LA; // [352] 372
    }
    _25103 = NOVALUE;

    /** 					Warning(228, not_used_warning_flag, {file,  vname})*/
    RefDS(_vname_47783);
    RefDS(_file_47781);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _file_47781;
    ((int *)_2)[2] = _vname_47783;
    _25105 = MAKE_SEQ(_1);
    _44Warning(228, 16, _25105);
    _25105 = NOVALUE;
    goto L9; // [369] 601
LA: 

    /** 				elsif warn_level = 1 then*/
    if (_warn_level_47780 != 1)
    goto LB; // [374] 394

    /** 					Warning(229, not_used_warning_flag, {file,  vname})*/
    RefDS(_vname_47783);
    RefDS(_file_47781);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _file_47781;
    ((int *)_2)[2] = _vname_47783;
    _25107 = MAKE_SEQ(_1);
    _44Warning(229, 16, _25107);
    _25107 = NOVALUE;
    goto L9; // [391] 601
LB: 

    /** 					Warning(320, not_used_warning_flag, {file,  vname})*/
    RefDS(_vname_47783);
    RefDS(_file_47781);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _file_47781;
    ((int *)_2)[2] = _vname_47783;
    _25108 = MAKE_SEQ(_1);
    _44Warning(320, 16, _25108);
    _25108 = NOVALUE;
    goto L9; // [409] 601
L8: 

    /** 			if SymTab[s][S_VARNUM] < SymTab[CurrentSub][S_NUM_ARGS] then*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _25109 = (int)*(((s1_ptr)_2)->base + _s_47779);
    _2 = (int)SEQ_PTR(_25109);
    _25110 = (int)*(((s1_ptr)_2)->base + 16);
    _25109 = NOVALUE;
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _25111 = (int)*(((s1_ptr)_2)->base + _35CurrentSub_16252);
    _2 = (int)SEQ_PTR(_25111);
    if (!IS_ATOM_INT(_35S_NUM_ARGS_15968)){
        _25112 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NUM_ARGS_15968)->dbl));
    }
    else{
        _25112 = (int)*(((s1_ptr)_2)->base + _35S_NUM_ARGS_15968);
    }
    _25111 = NOVALUE;
    if (binary_op_a(GREATEREQ, _25110, _25112)){
        _25110 = NOVALUE;
        _25112 = NOVALUE;
        goto LC; // [440] 523
    }
    _25110 = NOVALUE;
    _25112 = NOVALUE;

    /** 				if warn_level = 1 then*/
    if (_warn_level_47780 != 1)
    goto LD; // [446] 490

    /** 					if Strict_is_on then*/
    if (_35Strict_is_on_16309 == 0)
    {
        goto LE; // [454] 600
    }
    else{
    }

    /** 						Warning(230, not_used_warning_flag, {file,  vname, SymTab[CurrentSub][S_NAME]})*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _25115 = (int)*(((s1_ptr)_2)->base + _35CurrentSub_16252);
    _2 = (int)SEQ_PTR(_25115);
    if (!IS_ATOM_INT(_35S_NAME_15917)){
        _25116 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15917)->dbl));
    }
    else{
        _25116 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15917);
    }
    _25115 = NOVALUE;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_file_47781);
    *((int *)(_2+4)) = _file_47781;
    RefDS(_vname_47783);
    *((int *)(_2+8)) = _vname_47783;
    Ref(_25116);
    *((int *)(_2+12)) = _25116;
    _25117 = MAKE_SEQ(_1);
    _25116 = NOVALUE;
    _44Warning(230, 16, _25117);
    _25117 = NOVALUE;
    goto LE; // [487] 600
LD: 

    /** 					Warning(321, not_used_warning_flag, {file,  vname, SymTab[CurrentSub][S_NAME]})*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _25118 = (int)*(((s1_ptr)_2)->base + _35CurrentSub_16252);
    _2 = (int)SEQ_PTR(_25118);
    if (!IS_ATOM_INT(_35S_NAME_15917)){
        _25119 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15917)->dbl));
    }
    else{
        _25119 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15917);
    }
    _25118 = NOVALUE;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_file_47781);
    *((int *)(_2+4)) = _file_47781;
    RefDS(_vname_47783);
    *((int *)(_2+8)) = _vname_47783;
    Ref(_25119);
    *((int *)(_2+12)) = _25119;
    _25120 = MAKE_SEQ(_1);
    _25119 = NOVALUE;
    _44Warning(321, 16, _25120);
    _25120 = NOVALUE;
    goto LE; // [520] 600
LC: 

    /** 				if warn_level = 1 then*/
    if (_warn_level_47780 != 1)
    goto LF; // [525] 569

    /** 					if Strict_is_on then*/
    if (_35Strict_is_on_16309 == 0)
    {
        goto L10; // [533] 599
    }
    else{
    }

    /** 						Warning(231, not_used_warning_flag, {file,  vname, SymTab[CurrentSub][S_NAME]})*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _25122 = (int)*(((s1_ptr)_2)->base + _35CurrentSub_16252);
    _2 = (int)SEQ_PTR(_25122);
    if (!IS_ATOM_INT(_35S_NAME_15917)){
        _25123 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15917)->dbl));
    }
    else{
        _25123 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15917);
    }
    _25122 = NOVALUE;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_file_47781);
    *((int *)(_2+4)) = _file_47781;
    RefDS(_vname_47783);
    *((int *)(_2+8)) = _vname_47783;
    Ref(_25123);
    *((int *)(_2+12)) = _25123;
    _25124 = MAKE_SEQ(_1);
    _25123 = NOVALUE;
    _44Warning(231, 16, _25124);
    _25124 = NOVALUE;
    goto L10; // [566] 599
LF: 

    /** 					Warning(322, not_used_warning_flag, {file,  vname, SymTab[CurrentSub][S_NAME]})*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _25125 = (int)*(((s1_ptr)_2)->base + _35CurrentSub_16252);
    _2 = (int)SEQ_PTR(_25125);
    if (!IS_ATOM_INT(_35S_NAME_15917)){
        _25126 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15917)->dbl));
    }
    else{
        _25126 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15917);
    }
    _25125 = NOVALUE;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_file_47781);
    *((int *)(_2+4)) = _file_47781;
    RefDS(_vname_47783);
    *((int *)(_2+8)) = _vname_47783;
    Ref(_25126);
    *((int *)(_2+12)) = _25126;
    _25127 = MAKE_SEQ(_1);
    _25126 = NOVALUE;
    _44Warning(322, 16, _25127);
    _25127 = NOVALUE;
L10: 
LE: 
L9: 
L7: 

    /** end procedure*/
    DeRef(_file_47781);
    DeRef(_vname_47783);
    return;
    ;
}


void _53HideLocals()
{
    int _s_47950 = NOVALUE;
    int _25138 = NOVALUE;
    int _25136 = NOVALUE;
    int _25135 = NOVALUE;
    int _25134 = NOVALUE;
    int _25133 = NOVALUE;
    int _25132 = NOVALUE;
    int _25131 = NOVALUE;
    int _25130 = NOVALUE;
    int _25129 = NOVALUE;
    int _25128 = NOVALUE;
    int _0, _1, _2;
    

    /** 	s = file_start_sym*/
    _s_47950 = _35file_start_sym_16250;

    /** 	while s do*/
L1: 
    if (_s_47950 == 0)
    {
        goto L2; // [15] 117
    }
    else{
    }

    /** 		if SymTab[s][S_SCOPE] = SC_LOCAL and*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _25128 = (int)*(((s1_ptr)_2)->base + _s_47950);
    _2 = (int)SEQ_PTR(_25128);
    _25129 = (int)*(((s1_ptr)_2)->base + 4);
    _25128 = NOVALUE;
    if (IS_ATOM_INT(_25129)) {
        _25130 = (_25129 == 5);
    }
    else {
        _25130 = binary_op(EQUALS, _25129, 5);
    }
    _25129 = NOVALUE;
    if (IS_ATOM_INT(_25130)) {
        if (_25130 == 0) {
            goto L3; // [38] 96
        }
    }
    else {
        if (DBL_PTR(_25130)->dbl == 0.0) {
            goto L3; // [38] 96
        }
    }
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _25132 = (int)*(((s1_ptr)_2)->base + _s_47950);
    _2 = (int)SEQ_PTR(_25132);
    if (!IS_ATOM_INT(_35S_FILE_NO_15913)){
        _25133 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FILE_NO_15913)->dbl));
    }
    else{
        _25133 = (int)*(((s1_ptr)_2)->base + _35S_FILE_NO_15913);
    }
    _25132 = NOVALUE;
    if (IS_ATOM_INT(_25133)) {
        _25134 = (_25133 == _35current_file_no_16244);
    }
    else {
        _25134 = binary_op(EQUALS, _25133, _35current_file_no_16244);
    }
    _25133 = NOVALUE;
    if (_25134 == 0) {
        DeRef(_25134);
        _25134 = NOVALUE;
        goto L3; // [61] 96
    }
    else {
        if (!IS_ATOM_INT(_25134) && DBL_PTR(_25134)->dbl == 0.0){
            DeRef(_25134);
            _25134 = NOVALUE;
            goto L3; // [61] 96
        }
        DeRef(_25134);
        _25134 = NOVALUE;
    }
    DeRef(_25134);
    _25134 = NOVALUE;

    /** 			Hide(s)*/
    _53Hide(_s_47950);

    /** 			if SymTab[s][S_TOKEN] = VARIABLE then*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _25135 = (int)*(((s1_ptr)_2)->base + _s_47950);
    _2 = (int)SEQ_PTR(_25135);
    if (!IS_ATOM_INT(_35S_TOKEN_15922)){
        _25136 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TOKEN_15922)->dbl));
    }
    else{
        _25136 = (int)*(((s1_ptr)_2)->base + _35S_TOKEN_15922);
    }
    _25135 = NOVALUE;
    if (binary_op_a(NOTEQ, _25136, -100)){
        _25136 = NOVALUE;
        goto L4; // [85] 95
    }
    _25136 = NOVALUE;

    /** 				LintCheck(s)*/
    _53LintCheck(_s_47950);
L4: 
L3: 

    /** 		s = SymTab[s][S_NEXT]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _25138 = (int)*(((s1_ptr)_2)->base + _s_47950);
    _2 = (int)SEQ_PTR(_25138);
    _s_47950 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_47950)){
        _s_47950 = (long)DBL_PTR(_s_47950)->dbl;
    }
    _25138 = NOVALUE;

    /** 	end while*/
    goto L1; // [114] 15
L2: 

    /** end procedure*/
    DeRef(_25130);
    _25130 = NOVALUE;
    return;
    ;
}


int _53sym_name(int _sym_47981)
{
    int _25141 = NOVALUE;
    int _25140 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_sym_47981)) {
        _1 = (long)(DBL_PTR(_sym_47981)->dbl);
        DeRefDS(_sym_47981);
        _sym_47981 = _1;
    }

    /** 	return SymTab[sym][S_NAME]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _25140 = (int)*(((s1_ptr)_2)->base + _sym_47981);
    _2 = (int)SEQ_PTR(_25140);
    if (!IS_ATOM_INT(_35S_NAME_15917)){
        _25141 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15917)->dbl));
    }
    else{
        _25141 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15917);
    }
    _25140 = NOVALUE;
    Ref(_25141);
    return _25141;
    ;
}


int _53sym_token(int _sym_47989)
{
    int _25143 = NOVALUE;
    int _25142 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_sym_47989)) {
        _1 = (long)(DBL_PTR(_sym_47989)->dbl);
        DeRefDS(_sym_47989);
        _sym_47989 = _1;
    }

    /** 	return SymTab[sym][S_TOKEN]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _25142 = (int)*(((s1_ptr)_2)->base + _sym_47989);
    _2 = (int)SEQ_PTR(_25142);
    if (!IS_ATOM_INT(_35S_TOKEN_15922)){
        _25143 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TOKEN_15922)->dbl));
    }
    else{
        _25143 = (int)*(((s1_ptr)_2)->base + _35S_TOKEN_15922);
    }
    _25142 = NOVALUE;
    Ref(_25143);
    return _25143;
    ;
}


int _53sym_scope(int _sym_47997)
{
    int _25145 = NOVALUE;
    int _25144 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_sym_47997)) {
        _1 = (long)(DBL_PTR(_sym_47997)->dbl);
        DeRefDS(_sym_47997);
        _sym_47997 = _1;
    }

    /** 	return SymTab[sym][S_SCOPE]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _25144 = (int)*(((s1_ptr)_2)->base + _sym_47997);
    _2 = (int)SEQ_PTR(_25144);
    _25145 = (int)*(((s1_ptr)_2)->base + 4);
    _25144 = NOVALUE;
    Ref(_25145);
    return _25145;
    ;
}


int _53sym_mode(int _sym_48005)
{
    int _25147 = NOVALUE;
    int _25146 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_sym_48005)) {
        _1 = (long)(DBL_PTR(_sym_48005)->dbl);
        DeRefDS(_sym_48005);
        _sym_48005 = _1;
    }

    /** 	return SymTab[sym][S_MODE]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _25146 = (int)*(((s1_ptr)_2)->base + _sym_48005);
    _2 = (int)SEQ_PTR(_25146);
    _25147 = (int)*(((s1_ptr)_2)->base + 3);
    _25146 = NOVALUE;
    Ref(_25147);
    return _25147;
    ;
}


int _53sym_obj(int _sym_48013)
{
    int _25149 = NOVALUE;
    int _25148 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_sym_48013)) {
        _1 = (long)(DBL_PTR(_sym_48013)->dbl);
        DeRefDS(_sym_48013);
        _sym_48013 = _1;
    }

    /** 	return SymTab[sym][S_OBJ]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _25148 = (int)*(((s1_ptr)_2)->base + _sym_48013);
    _2 = (int)SEQ_PTR(_25148);
    _25149 = (int)*(((s1_ptr)_2)->base + 1);
    _25148 = NOVALUE;
    Ref(_25149);
    return _25149;
    ;
}


int _53sym_next(int _sym_48021)
{
    int _25151 = NOVALUE;
    int _25150 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_sym_48021)) {
        _1 = (long)(DBL_PTR(_sym_48021)->dbl);
        DeRefDS(_sym_48021);
        _sym_48021 = _1;
    }

    /** 	return SymTab[sym][S_NEXT]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _25150 = (int)*(((s1_ptr)_2)->base + _sym_48021);
    _2 = (int)SEQ_PTR(_25150);
    _25151 = (int)*(((s1_ptr)_2)->base + 2);
    _25150 = NOVALUE;
    Ref(_25151);
    return _25151;
    ;
}


int _53sym_block(int _sym_48029)
{
    int _25153 = NOVALUE;
    int _25152 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_sym_48029)) {
        _1 = (long)(DBL_PTR(_sym_48029)->dbl);
        DeRefDS(_sym_48029);
        _sym_48029 = _1;
    }

    /** 	return SymTab[sym][S_BLOCK]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _25152 = (int)*(((s1_ptr)_2)->base + _sym_48029);
    _2 = (int)SEQ_PTR(_25152);
    if (!IS_ATOM_INT(_35S_BLOCK_15937)){
        _25153 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_BLOCK_15937)->dbl));
    }
    else{
        _25153 = (int)*(((s1_ptr)_2)->base + _35S_BLOCK_15937);
    }
    _25152 = NOVALUE;
    Ref(_25153);
    return _25153;
    ;
}


int _53sym_next_in_block(int _sym_48037)
{
    int _25155 = NOVALUE;
    int _25154 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_sym_48037)) {
        _1 = (long)(DBL_PTR(_sym_48037)->dbl);
        DeRefDS(_sym_48037);
        _sym_48037 = _1;
    }

    /** 	return SymTab[sym][S_NEXT_IN_BLOCK]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _25154 = (int)*(((s1_ptr)_2)->base + _sym_48037);
    _2 = (int)SEQ_PTR(_25154);
    if (!IS_ATOM_INT(_35S_NEXT_IN_BLOCK_15909)){
        _25155 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NEXT_IN_BLOCK_15909)->dbl));
    }
    else{
        _25155 = (int)*(((s1_ptr)_2)->base + _35S_NEXT_IN_BLOCK_15909);
    }
    _25154 = NOVALUE;
    Ref(_25155);
    return _25155;
    ;
}


int _53sym_usage(int _sym_48045)
{
    int _25157 = NOVALUE;
    int _25156 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_sym_48045)) {
        _1 = (long)(DBL_PTR(_sym_48045)->dbl);
        DeRefDS(_sym_48045);
        _sym_48045 = _1;
    }

    /** 	return SymTab[sym][S_USAGE]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _25156 = (int)*(((s1_ptr)_2)->base + _sym_48045);
    _2 = (int)SEQ_PTR(_25156);
    _25157 = (int)*(((s1_ptr)_2)->base + 5);
    _25156 = NOVALUE;
    Ref(_25157);
    return _25157;
    ;
}


int _53calc_stack_required(int _sub_48053)
{
    int _required_48054 = NOVALUE;
    int _arg_48059 = NOVALUE;
    int _25177 = NOVALUE;
    int _25173 = NOVALUE;
    int _25171 = NOVALUE;
    int _25169 = NOVALUE;
    int _25168 = NOVALUE;
    int _25167 = NOVALUE;
    int _25166 = NOVALUE;
    int _25165 = NOVALUE;
    int _25163 = NOVALUE;
    int _25162 = NOVALUE;
    int _25160 = NOVALUE;
    int _25158 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_sub_48053)) {
        _1 = (long)(DBL_PTR(_sub_48053)->dbl);
        DeRefDS(_sub_48053);
        _sub_48053 = _1;
    }

    /** 	integer required = SymTab[sub][S_NUM_ARGS]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _25158 = (int)*(((s1_ptr)_2)->base + _sub_48053);
    _2 = (int)SEQ_PTR(_25158);
    if (!IS_ATOM_INT(_35S_NUM_ARGS_15968)){
        _required_48054 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NUM_ARGS_15968)->dbl));
    }
    else{
        _required_48054 = (int)*(((s1_ptr)_2)->base + _35S_NUM_ARGS_15968);
    }
    if (!IS_ATOM_INT(_required_48054)){
        _required_48054 = (long)DBL_PTR(_required_48054)->dbl;
    }
    _25158 = NOVALUE;

    /** 	integer arg = SymTab[sub][S_NEXT]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _25160 = (int)*(((s1_ptr)_2)->base + _sub_48053);
    _2 = (int)SEQ_PTR(_25160);
    _arg_48059 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_arg_48059)){
        _arg_48059 = (long)DBL_PTR(_arg_48059)->dbl;
    }
    _25160 = NOVALUE;

    /** 	for i = 1 to required do*/
    _25162 = _required_48054;
    {
        int _i_48065;
        _i_48065 = 1;
L1: 
        if (_i_48065 > _25162){
            goto L2; // [40] 70
        }

        /** 		arg = SymTab[arg][S_NEXT]*/
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _25163 = (int)*(((s1_ptr)_2)->base + _arg_48059);
        _2 = (int)SEQ_PTR(_25163);
        _arg_48059 = (int)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_arg_48059)){
            _arg_48059 = (long)DBL_PTR(_arg_48059)->dbl;
        }
        _25163 = NOVALUE;

        /** 	end for*/
        _i_48065 = _i_48065 + 1;
        goto L1; // [65] 47
L2: 
        ;
    }

    /** 	while arg != 0 and SymTab[arg][S_SCOPE] <= SC_PRIVATE do*/
L3: 
    _25165 = (_arg_48059 != 0);
    if (_25165 == 0) {
        goto L4; // [79] 132
    }
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _25167 = (int)*(((s1_ptr)_2)->base + _arg_48059);
    _2 = (int)SEQ_PTR(_25167);
    _25168 = (int)*(((s1_ptr)_2)->base + 4);
    _25167 = NOVALUE;
    if (IS_ATOM_INT(_25168)) {
        _25169 = (_25168 <= 3);
    }
    else {
        _25169 = binary_op(LESSEQ, _25168, 3);
    }
    _25168 = NOVALUE;
    if (_25169 <= 0) {
        if (_25169 == 0) {
            DeRef(_25169);
            _25169 = NOVALUE;
            goto L4; // [102] 132
        }
        else {
            if (!IS_ATOM_INT(_25169) && DBL_PTR(_25169)->dbl == 0.0){
                DeRef(_25169);
                _25169 = NOVALUE;
                goto L4; // [102] 132
            }
            DeRef(_25169);
            _25169 = NOVALUE;
        }
    }
    DeRef(_25169);
    _25169 = NOVALUE;

    /** 		required += 1*/
    _required_48054 = _required_48054 + 1;

    /** 		arg = SymTab[arg][S_NEXT]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _25171 = (int)*(((s1_ptr)_2)->base + _arg_48059);
    _2 = (int)SEQ_PTR(_25171);
    _arg_48059 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_arg_48059)){
        _arg_48059 = (long)DBL_PTR(_arg_48059)->dbl;
    }
    _25171 = NOVALUE;

    /** 	end while*/
    goto L3; // [129] 75
L4: 

    /** 	arg = SymTab[sub][S_TEMPS]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _25173 = (int)*(((s1_ptr)_2)->base + _sub_48053);
    _2 = (int)SEQ_PTR(_25173);
    if (!IS_ATOM_INT(_35S_TEMPS_15962)){
        _arg_48059 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TEMPS_15962)->dbl));
    }
    else{
        _arg_48059 = (int)*(((s1_ptr)_2)->base + _35S_TEMPS_15962);
    }
    if (!IS_ATOM_INT(_arg_48059)){
        _arg_48059 = (long)DBL_PTR(_arg_48059)->dbl;
    }
    _25173 = NOVALUE;

    /** 	while arg != 0 do*/
L5: 
    if (_arg_48059 == 0)
    goto L6; // [153] 184

    /** 		required += 1*/
    _required_48054 = _required_48054 + 1;

    /** 		arg = SymTab[arg][S_NEXT]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _25177 = (int)*(((s1_ptr)_2)->base + _arg_48059);
    _2 = (int)SEQ_PTR(_25177);
    _arg_48059 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_arg_48059)){
        _arg_48059 = (long)DBL_PTR(_arg_48059)->dbl;
    }
    _25177 = NOVALUE;

    /** 	end while*/
    goto L5; // [181] 153
L6: 

    /** 	return required*/
    DeRef(_25165);
    _25165 = NOVALUE;
    return _required_48054;
    ;
}



// 0x93D1B63A
