// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

void _61set_qualified_fwd(int _fwd_23931)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_fwd_23931)) {
        _1 = (long)(DBL_PTR(_fwd_23931)->dbl);
        DeRefDS(_fwd_23931);
        _fwd_23931 = _1;
    }

    /** 	qualified_fwd = fwd*/
    _61qualified_fwd_23928 = _fwd_23931;

    /** end procedure*/
    return;
    ;
}


int _61get_qualified_fwd()
{
    int _fwd_23934 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer fwd = qualified_fwd*/
    _fwd_23934 = _61qualified_fwd_23928;

    /** 	set_qualified_fwd( -1 )*/

    /** 	qualified_fwd = fwd*/
    _61qualified_fwd_23928 = -1;

    /** end procedure*/
    goto L1; // [17] 20
L1: 

    /** 	return fwd*/
    return _fwd_23934;
    ;
}


void _61InitLex()
{
    int _13776 = NOVALUE;
    int _13775 = NOVALUE;
    int _13774 = NOVALUE;
    int _13772 = NOVALUE;
    int _13771 = NOVALUE;
    int _13770 = NOVALUE;
    int _13769 = NOVALUE;
    int _0, _1, _2;
    

    /** 	gline_number = 0*/
    _35gline_number_16249 = 0;

    /** 	line_number = 0*/
    _35line_number_16245 = 0;

    /** 	IncludeStk = {}*/
    RefDS(_5);
    DeRef(_61IncludeStk_23905);
    _61IncludeStk_23905 = _5;

    /** 	char_class = repeat(ILLEGAL_CHAR, 255)  -- we screen out the 0 character*/
    DeRefi(_61char_class_23903);
    _61char_class_23903 = Repeat(-20, 255);

    /** 	char_class['0'..'9'] = DIGIT*/
    assign_slice_seq = (s1_ptr *)&_61char_class_23903;
    AssignSlice(48, 57, -7);

    /** 	char_class['_']      = DIGIT*/
    _2 = (int)SEQ_PTR(_61char_class_23903);
    _2 = (int)(((s1_ptr)_2)->base + 95);
    *(int *)_2 = -7;

    /** 	char_class['a'..'z'] = LETTER*/
    assign_slice_seq = (s1_ptr *)&_61char_class_23903;
    AssignSlice(97, 122, -2);

    /** 	char_class['A'..'Z'] = LETTER*/
    assign_slice_seq = (s1_ptr *)&_61char_class_23903;
    AssignSlice(65, 90, -2);

    /** 	char_class[KEYWORD_BASE+1..KEYWORD_BASE+NUM_KEYWORDS] = KEYWORD*/
    _13769 = 129;
    _13770 = 152;
    assign_slice_seq = (s1_ptr *)&_61char_class_23903;
    AssignSlice(129, 152, -10);
    _13769 = NOVALUE;
    _13770 = NOVALUE;

    /** 	char_class[BUILTIN_BASE+1..BUILTIN_BASE+NUM_BUILTINS] = BUILTIN*/
    _13771 = 171;
    _13772 = 234;
    assign_slice_seq = (s1_ptr *)&_61char_class_23903;
    AssignSlice(171, 234, -9);
    _13771 = NOVALUE;
    _13772 = NOVALUE;

    /** 	char_class[' '] = BLANK*/
    _2 = (int)SEQ_PTR(_61char_class_23903);
    _2 = (int)(((s1_ptr)_2)->base + 32);
    *(int *)_2 = -8;

    /** 	char_class['\t'] = BLANK*/
    _2 = (int)SEQ_PTR(_61char_class_23903);
    _2 = (int)(((s1_ptr)_2)->base + 9);
    *(int *)_2 = -8;

    /** 	char_class['+'] = PLUS*/
    _2 = (int)SEQ_PTR(_61char_class_23903);
    _2 = (int)(((s1_ptr)_2)->base + 43);
    *(int *)_2 = 11;

    /** 	char_class['-'] = MINUS*/
    _2 = (int)SEQ_PTR(_61char_class_23903);
    _2 = (int)(((s1_ptr)_2)->base + 45);
    *(int *)_2 = 10;

    /** 	char_class['*'] = res:MULTIPLY*/
    _2 = (int)SEQ_PTR(_61char_class_23903);
    _2 = (int)(((s1_ptr)_2)->base + 42);
    *(int *)_2 = 13;

    /** 	char_class['/'] = res:DIVIDE*/
    _2 = (int)SEQ_PTR(_61char_class_23903);
    _2 = (int)(((s1_ptr)_2)->base + 47);
    *(int *)_2 = 14;

    /** 	char_class['='] = EQUALS*/
    _2 = (int)SEQ_PTR(_61char_class_23903);
    _2 = (int)(((s1_ptr)_2)->base + 61);
    *(int *)_2 = 3;

    /** 	char_class['<'] = LESS*/
    _2 = (int)SEQ_PTR(_61char_class_23903);
    _2 = (int)(((s1_ptr)_2)->base + 60);
    *(int *)_2 = 1;

    /** 	char_class['>'] = GREATER*/
    _2 = (int)SEQ_PTR(_61char_class_23903);
    _2 = (int)(((s1_ptr)_2)->base + 62);
    *(int *)_2 = 6;

    /** 	char_class['\''] = SINGLE_QUOTE*/
    _2 = (int)SEQ_PTR(_61char_class_23903);
    _2 = (int)(((s1_ptr)_2)->base + 39);
    *(int *)_2 = -5;

    /** 	char_class['"'] = DOUBLE_QUOTE*/
    _2 = (int)SEQ_PTR(_61char_class_23903);
    _2 = (int)(((s1_ptr)_2)->base + 34);
    *(int *)_2 = -4;

    /** 	char_class['`'] = BACK_QUOTE*/
    _2 = (int)SEQ_PTR(_61char_class_23903);
    _2 = (int)(((s1_ptr)_2)->base + 96);
    *(int *)_2 = -12;

    /** 	char_class['.'] = DOT*/
    _2 = (int)SEQ_PTR(_61char_class_23903);
    _2 = (int)(((s1_ptr)_2)->base + 46);
    *(int *)_2 = -3;

    /** 	char_class[':'] = COLON*/
    _2 = (int)SEQ_PTR(_61char_class_23903);
    _2 = (int)(((s1_ptr)_2)->base + 58);
    *(int *)_2 = -23;

    /** 	char_class['\r'] = NEWLINE*/
    _2 = (int)SEQ_PTR(_61char_class_23903);
    _2 = (int)(((s1_ptr)_2)->base + 13);
    *(int *)_2 = -6;

    /** 	char_class['\n'] = NEWLINE*/
    _2 = (int)SEQ_PTR(_61char_class_23903);
    _2 = (int)(((s1_ptr)_2)->base + 10);
    *(int *)_2 = -6;

    /** 	char_class['!'] = BANG*/
    _2 = (int)SEQ_PTR(_61char_class_23903);
    _2 = (int)(((s1_ptr)_2)->base + 33);
    *(int *)_2 = -1;

    /** 	char_class['{'] = LEFT_BRACE*/
    _2 = (int)SEQ_PTR(_61char_class_23903);
    _2 = (int)(((s1_ptr)_2)->base + 123);
    *(int *)_2 = -24;

    /** 	char_class['}'] = RIGHT_BRACE*/
    _2 = (int)SEQ_PTR(_61char_class_23903);
    _2 = (int)(((s1_ptr)_2)->base + 125);
    *(int *)_2 = -25;

    /** 	char_class['('] = LEFT_ROUND*/
    _2 = (int)SEQ_PTR(_61char_class_23903);
    _2 = (int)(((s1_ptr)_2)->base + 40);
    *(int *)_2 = -26;

    /** 	char_class[')'] = RIGHT_ROUND*/
    _2 = (int)SEQ_PTR(_61char_class_23903);
    _2 = (int)(((s1_ptr)_2)->base + 41);
    *(int *)_2 = -27;

    /** 	char_class['['] = LEFT_SQUARE*/
    _2 = (int)SEQ_PTR(_61char_class_23903);
    _2 = (int)(((s1_ptr)_2)->base + 91);
    *(int *)_2 = -28;

    /** 	char_class[']'] = RIGHT_SQUARE*/
    _2 = (int)SEQ_PTR(_61char_class_23903);
    _2 = (int)(((s1_ptr)_2)->base + 93);
    *(int *)_2 = -29;

    /** 	char_class['$'] = DOLLAR*/
    _2 = (int)SEQ_PTR(_61char_class_23903);
    _2 = (int)(((s1_ptr)_2)->base + 36);
    *(int *)_2 = -22;

    /** 	char_class[','] = COMMA*/
    _2 = (int)SEQ_PTR(_61char_class_23903);
    _2 = (int)(((s1_ptr)_2)->base + 44);
    *(int *)_2 = -30;

    /** 	char_class['&'] = res:CONCAT*/
    _2 = (int)SEQ_PTR(_61char_class_23903);
    _2 = (int)(((s1_ptr)_2)->base + 38);
    *(int *)_2 = 15;

    /** 	char_class['?'] = QUESTION_MARK*/
    _2 = (int)SEQ_PTR(_61char_class_23903);
    _2 = (int)(((s1_ptr)_2)->base + 63);
    *(int *)_2 = -31;

    /** 	char_class['#'] = NUMBER_SIGN*/
    _2 = (int)SEQ_PTR(_61char_class_23903);
    _2 = (int)(((s1_ptr)_2)->base + 35);
    *(int *)_2 = -11;

    /** 	char_class[END_OF_FILE_CHAR] = END_OF_FILE*/
    _2 = (int)SEQ_PTR(_61char_class_23903);
    _2 = (int)(((s1_ptr)_2)->base + 26);
    *(int *)_2 = -21;

    /** 	id_char = repeat(FALSE, 255)*/
    DeRefi(_61id_char_23904);
    _61id_char_23904 = Repeat(_13FALSE_434, 255);

    /** 	for i = 1 to 255 do*/
    {
        int _i_23982;
        _i_23982 = 1;
L1: 
        if (_i_23982 > 255){
            goto L2; // [407] 456
        }

        /** 		if find(char_class[i], {LETTER, DIGIT}) then*/
        _2 = (int)SEQ_PTR(_61char_class_23903);
        _13774 = (int)*(((s1_ptr)_2)->base + _i_23982);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = -2;
        ((int *)_2)[2] = -7;
        _13775 = MAKE_SEQ(_1);
        _13776 = find_from(_13774, _13775, 1);
        _13774 = NOVALUE;
        DeRefDS(_13775);
        _13775 = NOVALUE;
        if (_13776 == 0)
        {
            _13776 = NOVALUE;
            goto L3; // [435] 449
        }
        else{
            _13776 = NOVALUE;
        }

        /** 			id_char[i] = TRUE*/
        _2 = (int)SEQ_PTR(_61id_char_23904);
        _2 = (int)(((s1_ptr)_2)->base + _i_23982);
        *(int *)_2 = _13TRUE_436;
L3: 

        /** 	end for*/
        _i_23982 = _i_23982 + 1;
        goto L1; // [451] 414
L2: 
        ;
    }

    /** 	default_namespaces = {0}*/
    _0 = _61default_namespaces_23902;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 0;
    _61default_namespaces_23902 = MAKE_SEQ(_1);
    DeRef(_0);

    /** end procedure*/
    return;
    ;
}


void _61ResetTP()
{
    int _0, _1, _2;
    

    /** 	OpTrace = FALSE*/
    _35OpTrace_16313 = _13FALSE_434;

    /** 	OpProfileStatement = FALSE*/
    _35OpProfileStatement_16315 = _13FALSE_434;

    /** 	OpProfileTime = FALSE*/
    _35OpProfileTime_16316 = _13FALSE_434;

    /** 	AnyStatementProfile = FALSE*/
    _36AnyStatementProfile_15265 = _13FALSE_434;

    /** 	AnyTimeProfile = FALSE*/
    _36AnyTimeProfile_15264 = _13FALSE_434;

    /** end procedure*/
    return;
    ;
}


int _61pack_source(int _src_24012)
{
    int _start_24013 = NOVALUE;
    int _13800 = NOVALUE;
    int _13799 = NOVALUE;
    int _13798 = NOVALUE;
    int _13797 = NOVALUE;
    int _13795 = NOVALUE;
    int _13793 = NOVALUE;
    int _13792 = NOVALUE;
    int _13791 = NOVALUE;
    int _13787 = NOVALUE;
    int _13785 = NOVALUE;
    int _13784 = NOVALUE;
    int _13781 = NOVALUE;
    int _13780 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if equal(src, 0) then*/
    if (_src_24012 == 0)
    _13780 = 1;
    else if (IS_ATOM_INT(_src_24012) && IS_ATOM_INT(0))
    _13780 = 0;
    else
    _13780 = (compare(_src_24012, 0) == 0);
    if (_13780 == 0)
    {
        _13780 = NOVALUE;
        goto L1; // [7] 17
    }
    else{
        _13780 = NOVALUE;
    }

    /** 		return 0*/
    DeRef(_src_24012);
    return 0;
L1: 

    /** 	if length(src) >= SOURCE_CHUNK then*/
    if (IS_SEQUENCE(_src_24012)){
            _13781 = SEQ_PTR(_src_24012)->length;
    }
    else {
        _13781 = 1;
    }
    if (_13781 < 10000)
    goto L2; // [22] 34

    /** 		src = src[1..100] -- enough for trace or profile display*/
    rhs_slice_target = (object_ptr)&_src_24012;
    RHS_Slice(_src_24012, 1, 100);
L2: 

    /** 	if current_source_next + length(src) >= SOURCE_CHUNK then*/
    if (IS_SEQUENCE(_src_24012)){
            _13784 = SEQ_PTR(_src_24012)->length;
    }
    else {
        _13784 = 1;
    }
    _13785 = _61current_source_next_24008 + _13784;
    if ((long)((unsigned long)_13785 + (unsigned long)HIGH_BITS) >= 0) 
    _13785 = NewDouble((double)_13785);
    _13784 = NOVALUE;
    if (binary_op_a(LESS, _13785, 10000)){
        DeRef(_13785);
        _13785 = NOVALUE;
        goto L3; // [45] 94
    }
    DeRef(_13785);
    _13785 = NOVALUE;

    /** 		current_source = allocate(SOURCE_CHUNK + LINE_BUFLEN)*/
    _13787 = 10400;
    _0 = _9allocate(10400, 0);
    DeRef(_61current_source_24007);
    _61current_source_24007 = _0;
    _13787 = NOVALUE;

    /** 		if current_source = 0 then*/
    if (binary_op_a(NOTEQ, _61current_source_24007, 0)){
        goto L4; // [64] 76
    }

    /** 			CompileErr(123)*/
    RefDS(_22023);
    _44CompileErr(123, _22023, 0);
L4: 

    /** 		all_source = append(all_source, current_source)*/
    Ref(_61current_source_24007);
    Append(&_36all_source_15266, _36all_source_15266, _61current_source_24007);

    /** 		current_source_next = 1*/
    _61current_source_next_24008 = 1;
L3: 

    /** 	start = current_source_next*/
    _start_24013 = _61current_source_next_24008;

    /** 	poke(current_source+current_source_next, src)*/
    if (IS_ATOM_INT(_61current_source_24007)) {
        _13791 = _61current_source_24007 + _61current_source_next_24008;
        if ((long)((unsigned long)_13791 + (unsigned long)HIGH_BITS) >= 0) 
        _13791 = NewDouble((double)_13791);
    }
    else {
        _13791 = NewDouble(DBL_PTR(_61current_source_24007)->dbl + (double)_61current_source_next_24008);
    }
    if (IS_ATOM_INT(_13791)){
        poke_addr = (unsigned char *)_13791;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_13791)->dbl);
    }
    if (IS_ATOM_INT(_src_24012)) {
        *poke_addr = (unsigned char)_src_24012;
    }
    else if (IS_ATOM(_src_24012)) {
        *poke_addr = (signed char)DBL_PTR(_src_24012)->dbl;
    }
    else {
        _1 = (int)SEQ_PTR(_src_24012);
        _1 = (int)((s1_ptr)_1)->base;
        while (1) {
            _1 += 4;
            _2 = *((int *)_1);
            if (IS_ATOM_INT(_2))
            *poke_addr++ = (unsigned char)_2;
            else if (_2 == NOVALUE)
            break;
            else {
                *poke_addr++ = (signed char)DBL_PTR(_2)->dbl;
            }
        }
    }
    DeRef(_13791);
    _13791 = NOVALUE;

    /** 	current_source_next += length(src)-1*/
    if (IS_SEQUENCE(_src_24012)){
            _13792 = SEQ_PTR(_src_24012)->length;
    }
    else {
        _13792 = 1;
    }
    _13793 = _13792 - 1;
    _13792 = NOVALUE;
    _61current_source_next_24008 = _61current_source_next_24008 + _13793;
    _13793 = NOVALUE;

    /** 	poke(current_source+current_source_next, 0) -- overwrite \n*/
    if (IS_ATOM_INT(_61current_source_24007)) {
        _13795 = _61current_source_24007 + _61current_source_next_24008;
        if ((long)((unsigned long)_13795 + (unsigned long)HIGH_BITS) >= 0) 
        _13795 = NewDouble((double)_13795);
    }
    else {
        _13795 = NewDouble(DBL_PTR(_61current_source_24007)->dbl + (double)_61current_source_next_24008);
    }
    if (IS_ATOM_INT(_13795)){
        poke_addr = (unsigned char *)_13795;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_13795)->dbl);
    }
    *poke_addr = (unsigned char)0;
    DeRef(_13795);
    _13795 = NOVALUE;

    /** 	current_source_next += 1*/
    _61current_source_next_24008 = _61current_source_next_24008 + 1;

    /** 	return start + SOURCE_CHUNK * (length(all_source)-1)*/
    if (IS_SEQUENCE(_36all_source_15266)){
            _13797 = SEQ_PTR(_36all_source_15266)->length;
    }
    else {
        _13797 = 1;
    }
    _13798 = _13797 - 1;
    _13797 = NOVALUE;
    if (_13798 <= INT15)
    _13799 = 10000 * _13798;
    else
    _13799 = NewDouble(10000 * (double)_13798);
    _13798 = NOVALUE;
    if (IS_ATOM_INT(_13799)) {
        _13800 = _start_24013 + _13799;
        if ((long)((unsigned long)_13800 + (unsigned long)HIGH_BITS) >= 0) 
        _13800 = NewDouble((double)_13800);
    }
    else {
        _13800 = NewDouble((double)_start_24013 + DBL_PTR(_13799)->dbl);
    }
    DeRef(_13799);
    _13799 = NOVALUE;
    DeRef(_src_24012);
    return _13800;
    ;
}


int _61fetch_line(int _start_24046)
{
    int _line_24047 = NOVALUE;
    int _memdata_24048 = NOVALUE;
    int _c_24049 = NOVALUE;
    int _chunk_24050 = NOVALUE;
    int _p_24051 = NOVALUE;
    int _n_24052 = NOVALUE;
    int _m_24053 = NOVALUE;
    int _13825 = NOVALUE;
    int _13824 = NOVALUE;
    int _13822 = NOVALUE;
    int _13820 = NOVALUE;
    int _13814 = NOVALUE;
    int _13812 = NOVALUE;
    int _13808 = NOVALUE;
    int _13806 = NOVALUE;
    int _13803 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_start_24046)) {
        _1 = (long)(DBL_PTR(_start_24046)->dbl);
        DeRefDS(_start_24046);
        _start_24046 = _1;
    }

    /** 	if start = 0 then*/
    if (_start_24046 != 0)
    goto L1; // [5] 16

    /** 		return ""*/
    RefDS(_5);
    DeRef(_line_24047);
    DeRefi(_memdata_24048);
    DeRef(_p_24051);
    return _5;
L1: 

    /** 	line = repeat(0, LINE_BUFLEN)*/
    DeRef(_line_24047);
    _line_24047 = Repeat(0, 400);

    /** 	n = 0*/
    _n_24052 = 0;

    /** 	chunk = 1+floor(start / SOURCE_CHUNK)*/
    if (10000 > 0 && _start_24046 >= 0) {
        _13803 = _start_24046 / 10000;
    }
    else {
        temp_dbl = floor((double)_start_24046 / (double)10000);
        _13803 = (long)temp_dbl;
    }
    _chunk_24050 = _13803 + 1;
    _13803 = NOVALUE;

    /** 	start = remainder(start, SOURCE_CHUNK)*/
    _start_24046 = (_start_24046 % 10000);

    /** 	p = all_source[chunk] + start*/
    _2 = (int)SEQ_PTR(_36all_source_15266);
    _13806 = (int)*(((s1_ptr)_2)->base + _chunk_24050);
    DeRef(_p_24051);
    if (IS_ATOM_INT(_13806)) {
        _p_24051 = _13806 + _start_24046;
        if ((long)((unsigned long)_p_24051 + (unsigned long)HIGH_BITS) >= 0) 
        _p_24051 = NewDouble((double)_p_24051);
    }
    else {
        _p_24051 = NewDouble(DBL_PTR(_13806)->dbl + (double)_start_24046);
    }
    _13806 = NOVALUE;

    /** 	memdata = peek({p, LINE_BUFLEN})*/
    Ref(_p_24051);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _p_24051;
    ((int *)_2)[2] = 400;
    _13808 = MAKE_SEQ(_1);
    DeRefi(_memdata_24048);
    _1 = (int)SEQ_PTR(_13808);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _memdata_24048 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    DeRefDS(_13808);
    _13808 = NOVALUE;

    /** 	p += LINE_BUFLEN*/
    _0 = _p_24051;
    if (IS_ATOM_INT(_p_24051)) {
        _p_24051 = _p_24051 + 400;
        if ((long)((unsigned long)_p_24051 + (unsigned long)HIGH_BITS) >= 0) 
        _p_24051 = NewDouble((double)_p_24051);
    }
    else {
        _p_24051 = NewDouble(DBL_PTR(_p_24051)->dbl + (double)400);
    }
    DeRef(_0);

    /** 	m = 0*/
    _m_24053 = 0;

    /** 	while TRUE do*/
L2: 
    if (_13TRUE_436 == 0)
    {
        goto L3; // [84] 179
    }
    else{
    }

    /** 		m += 1*/
    _m_24053 = _m_24053 + 1;

    /** 		if m > length(memdata) then*/
    if (IS_SEQUENCE(_memdata_24048)){
            _13812 = SEQ_PTR(_memdata_24048)->length;
    }
    else {
        _13812 = 1;
    }
    if (_m_24053 <= _13812)
    goto L4; // [98] 125

    /** 			memdata = peek({p, LINE_BUFLEN})*/
    Ref(_p_24051);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _p_24051;
    ((int *)_2)[2] = 400;
    _13814 = MAKE_SEQ(_1);
    DeRefDSi(_memdata_24048);
    _1 = (int)SEQ_PTR(_13814);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _memdata_24048 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    DeRefDS(_13814);
    _13814 = NOVALUE;

    /** 			p += LINE_BUFLEN*/
    _0 = _p_24051;
    if (IS_ATOM_INT(_p_24051)) {
        _p_24051 = _p_24051 + 400;
        if ((long)((unsigned long)_p_24051 + (unsigned long)HIGH_BITS) >= 0) 
        _p_24051 = NewDouble((double)_p_24051);
    }
    else {
        _p_24051 = NewDouble(DBL_PTR(_p_24051)->dbl + (double)400);
    }
    DeRef(_0);

    /** 			m = 1*/
    _m_24053 = 1;
L4: 

    /** 		c = memdata[m]*/
    _2 = (int)SEQ_PTR(_memdata_24048);
    _c_24049 = (int)*(((s1_ptr)_2)->base + _m_24053);

    /** 		if c = 0 then*/
    if (_c_24049 != 0)
    goto L5; // [133] 142

    /** 			exit*/
    goto L3; // [139] 179
L5: 

    /** 		n += 1*/
    _n_24052 = _n_24052 + 1;

    /** 		if n > length(line) then*/
    if (IS_SEQUENCE(_line_24047)){
            _13820 = SEQ_PTR(_line_24047)->length;
    }
    else {
        _13820 = 1;
    }
    if (_n_24052 <= _13820)
    goto L6; // [153] 168

    /** 			line &= repeat(0, LINE_BUFLEN)*/
    _13822 = Repeat(0, 400);
    Concat((object_ptr)&_line_24047, _line_24047, _13822);
    DeRefDS(_13822);
    _13822 = NOVALUE;
L6: 

    /** 		line[n] = c*/
    _2 = (int)SEQ_PTR(_line_24047);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _line_24047 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _n_24052);
    _1 = *(int *)_2;
    *(int *)_2 = _c_24049;
    DeRef(_1);

    /** 	end while*/
    goto L2; // [176] 82
L3: 

    /** 	line = remove( line, n+1, length( line ) )*/
    _13824 = _n_24052 + 1;
    if (_13824 > MAXINT){
        _13824 = NewDouble((double)_13824);
    }
    if (IS_SEQUENCE(_line_24047)){
            _13825 = SEQ_PTR(_line_24047)->length;
    }
    else {
        _13825 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_line_24047);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_13824)) ? _13824 : (long)(DBL_PTR(_13824)->dbl);
        int stop = (IS_ATOM_INT(_13825)) ? _13825 : (long)(DBL_PTR(_13825)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_line_24047), start, &_line_24047 );
            }
            else Tail(SEQ_PTR(_line_24047), stop+1, &_line_24047);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_line_24047), start, &_line_24047);
        }
        else {
            assign_slice_seq = &assign_space;
            _line_24047 = Remove_elements(start, stop, (SEQ_PTR(_line_24047)->ref == 1));
        }
    }
    DeRef(_13824);
    _13824 = NOVALUE;
    _13825 = NOVALUE;

    /** 	return line*/
    DeRefi(_memdata_24048);
    DeRef(_p_24051);
    return _line_24047;
    ;
}


void _61AppendSourceLine()
{
    int _new_24089 = NOVALUE;
    int _old_24090 = NOVALUE;
    int _options_24091 = NOVALUE;
    int _src_24092 = NOVALUE;
    int _13866 = NOVALUE;
    int _13862 = NOVALUE;
    int _13860 = NOVALUE;
    int _13859 = NOVALUE;
    int _13856 = NOVALUE;
    int _13855 = NOVALUE;
    int _13854 = NOVALUE;
    int _13853 = NOVALUE;
    int _13852 = NOVALUE;
    int _13851 = NOVALUE;
    int _13850 = NOVALUE;
    int _13849 = NOVALUE;
    int _13848 = NOVALUE;
    int _13847 = NOVALUE;
    int _13846 = NOVALUE;
    int _13845 = NOVALUE;
    int _13844 = NOVALUE;
    int _13843 = NOVALUE;
    int _13842 = NOVALUE;
    int _13841 = NOVALUE;
    int _13840 = NOVALUE;
    int _13839 = NOVALUE;
    int _13837 = NOVALUE;
    int _13836 = NOVALUE;
    int _13835 = NOVALUE;
    int _13833 = NOVALUE;
    int _13828 = NOVALUE;
    int _13827 = NOVALUE;
    int _0, _1, _2;
    

    /** 	src = 0*/
    DeRef(_src_24092);
    _src_24092 = 0;

    /** 	options = 0*/
    _options_24091 = 0;

    /** 	if TRANSLATE or OpTrace or OpProfileStatement or OpProfileTime then*/
    if (_35TRANSLATE_15887 != 0) {
        _13827 = 1;
        goto L1; // [15] 25
    }
    _13827 = (_35OpTrace_16313 != 0);
L1: 
    if (_13827 != 0) {
        _13828 = 1;
        goto L2; // [25] 35
    }
    _13828 = (_35OpProfileStatement_16315 != 0);
L2: 
    if (_13828 != 0) {
        goto L3; // [35] 46
    }
    if (_35OpProfileTime_16316 == 0)
    {
        goto L4; // [42] 136
    }
    else{
    }
L3: 

    /** 		src = ThisLine*/
    Ref(_44ThisLine_48518);
    DeRef(_src_24092);
    _src_24092 = _44ThisLine_48518;

    /** 		if OpTrace then*/
    if (_35OpTrace_16313 == 0)
    {
        goto L5; // [57] 70
    }
    else{
    }

    /** 			options = SOP_TRACE*/
    _options_24091 = 1;
L5: 

    /** 		if OpProfileTime then*/
    if (_35OpProfileTime_16316 == 0)
    {
        goto L6; // [74] 88
    }
    else{
    }

    /** 			options = or_bits(options, SOP_PROFILE_TIME)*/
    {unsigned long tu;
         tu = (unsigned long)_options_24091 | (unsigned long)2;
         _options_24091 = MAKE_UINT(tu);
    }
    if (!IS_ATOM_INT(_options_24091)) {
        _1 = (long)(DBL_PTR(_options_24091)->dbl);
        DeRefDS(_options_24091);
        _options_24091 = _1;
    }
L6: 

    /** 		if OpProfileStatement then*/
    if (_35OpProfileStatement_16315 == 0)
    {
        goto L7; // [92] 106
    }
    else{
    }

    /** 			options = or_bits(options, SOP_PROFILE_STATEMENT)*/
    {unsigned long tu;
         tu = (unsigned long)_options_24091 | (unsigned long)4;
         _options_24091 = MAKE_UINT(tu);
    }
    if (!IS_ATOM_INT(_options_24091)) {
        _1 = (long)(DBL_PTR(_options_24091)->dbl);
        DeRefDS(_options_24091);
        _options_24091 = _1;
    }
L7: 

    /** 		if OpProfileStatement or OpProfileTime then*/
    if (_35OpProfileStatement_16315 != 0) {
        goto L8; // [110] 121
    }
    if (_35OpProfileTime_16316 == 0)
    {
        goto L9; // [117] 135
    }
    else{
    }
L8: 

    /** 			src = {0,0,0,0} & src*/
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 0;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = 0;
    *((int *)(_2+16)) = 0;
    _13833 = MAKE_SEQ(_1);
    if (IS_SEQUENCE(_13833) && IS_ATOM(_src_24092)) {
        Ref(_src_24092);
        Append(&_src_24092, _13833, _src_24092);
    }
    else if (IS_ATOM(_13833) && IS_SEQUENCE(_src_24092)) {
    }
    else {
        Concat((object_ptr)&_src_24092, _13833, _src_24092);
        DeRefDS(_13833);
        _13833 = NOVALUE;
    }
    DeRef(_13833);
    _13833 = NOVALUE;
L9: 
L4: 

    /** 	if length(slist) then*/
    if (IS_SEQUENCE(_35slist_16334)){
            _13835 = SEQ_PTR(_35slist_16334)->length;
    }
    else {
        _13835 = 1;
    }
    if (_13835 == 0)
    {
        _13835 = NOVALUE;
        goto LA; // [143] 345
    }
    else{
        _13835 = NOVALUE;
    }

    /** 		old = slist[$-1]*/
    if (IS_SEQUENCE(_35slist_16334)){
            _13836 = SEQ_PTR(_35slist_16334)->length;
    }
    else {
        _13836 = 1;
    }
    _13837 = _13836 - 1;
    _13836 = NOVALUE;
    DeRef(_old_24090);
    _2 = (int)SEQ_PTR(_35slist_16334);
    _old_24090 = (int)*(((s1_ptr)_2)->base + _13837);
    Ref(_old_24090);

    /** 		if equal(src, old[SRC]) and*/
    _2 = (int)SEQ_PTR(_old_24090);
    _13839 = (int)*(((s1_ptr)_2)->base + 1);
    if (_src_24092 == _13839)
    _13840 = 1;
    else if (IS_ATOM_INT(_src_24092) && IS_ATOM_INT(_13839))
    _13840 = 0;
    else
    _13840 = (compare(_src_24092, _13839) == 0);
    _13839 = NOVALUE;
    if (_13840 == 0) {
        _13841 = 0;
        goto LB; // [175] 195
    }
    _2 = (int)SEQ_PTR(_old_24090);
    _13842 = (int)*(((s1_ptr)_2)->base + 3);
    if (IS_ATOM_INT(_13842)) {
        _13843 = (_35current_file_no_16244 == _13842);
    }
    else {
        _13843 = binary_op(EQUALS, _35current_file_no_16244, _13842);
    }
    _13842 = NOVALUE;
    if (IS_ATOM_INT(_13843))
    _13841 = (_13843 != 0);
    else
    _13841 = DBL_PTR(_13843)->dbl != 0.0;
LB: 
    if (_13841 == 0) {
        _13844 = 0;
        goto LC; // [195] 232
    }
    _2 = (int)SEQ_PTR(_old_24090);
    _13845 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_13845)) {
        _13846 = _13845 + 1;
        if (_13846 > MAXINT){
            _13846 = NewDouble((double)_13846);
        }
    }
    else
    _13846 = binary_op(PLUS, 1, _13845);
    _13845 = NOVALUE;
    if (IS_SEQUENCE(_35slist_16334)){
            _13847 = SEQ_PTR(_35slist_16334)->length;
    }
    else {
        _13847 = 1;
    }
    _2 = (int)SEQ_PTR(_35slist_16334);
    _13848 = (int)*(((s1_ptr)_2)->base + _13847);
    if (IS_ATOM_INT(_13846) && IS_ATOM_INT(_13848)) {
        _13849 = _13846 + _13848;
        if ((long)((unsigned long)_13849 + (unsigned long)HIGH_BITS) >= 0) 
        _13849 = NewDouble((double)_13849);
    }
    else {
        _13849 = binary_op(PLUS, _13846, _13848);
    }
    DeRef(_13846);
    _13846 = NOVALUE;
    _13848 = NOVALUE;
    if (IS_ATOM_INT(_13849)) {
        _13850 = (_35line_number_16245 == _13849);
    }
    else {
        _13850 = binary_op(EQUALS, _35line_number_16245, _13849);
    }
    DeRef(_13849);
    _13849 = NOVALUE;
    if (IS_ATOM_INT(_13850))
    _13844 = (_13850 != 0);
    else
    _13844 = DBL_PTR(_13850)->dbl != 0.0;
LC: 
    if (_13844 == 0) {
        goto LD; // [232] 272
    }
    _2 = (int)SEQ_PTR(_old_24090);
    _13852 = (int)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_13852)) {
        _13853 = (_options_24091 == _13852);
    }
    else {
        _13853 = binary_op(EQUALS, _options_24091, _13852);
    }
    _13852 = NOVALUE;
    if (_13853 == 0) {
        DeRef(_13853);
        _13853 = NOVALUE;
        goto LD; // [247] 272
    }
    else {
        if (!IS_ATOM_INT(_13853) && DBL_PTR(_13853)->dbl == 0.0){
            DeRef(_13853);
            _13853 = NOVALUE;
            goto LD; // [247] 272
        }
        DeRef(_13853);
        _13853 = NOVALUE;
    }
    DeRef(_13853);
    _13853 = NOVALUE;

    /** 			slist[$] += 1*/
    if (IS_SEQUENCE(_35slist_16334)){
            _13854 = SEQ_PTR(_35slist_16334)->length;
    }
    else {
        _13854 = 1;
    }
    _2 = (int)SEQ_PTR(_35slist_16334);
    _13855 = (int)*(((s1_ptr)_2)->base + _13854);
    if (IS_ATOM_INT(_13855)) {
        _13856 = _13855 + 1;
        if (_13856 > MAXINT){
            _13856 = NewDouble((double)_13856);
        }
    }
    else
    _13856 = binary_op(PLUS, 1, _13855);
    _13855 = NOVALUE;
    _2 = (int)SEQ_PTR(_35slist_16334);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _35slist_16334 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _13854);
    _1 = *(int *)_2;
    *(int *)_2 = _13856;
    if( _1 != _13856 ){
        DeRef(_1);
    }
    _13856 = NOVALUE;
    goto LE; // [269] 371
LD: 

    /** 			src = pack_source(src)*/
    Ref(_src_24092);
    _0 = _src_24092;
    _src_24092 = _61pack_source(_src_24092);
    DeRef(_0);

    /** 			new = {src, line_number, current_file_no, options}*/
    _0 = _new_24089;
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_src_24092);
    *((int *)(_2+4)) = _src_24092;
    *((int *)(_2+8)) = _35line_number_16245;
    *((int *)(_2+12)) = _35current_file_no_16244;
    *((int *)(_2+16)) = _options_24091;
    _new_24089 = MAKE_SEQ(_1);
    DeRef(_0);

    /** 			if slist[$] = 0 then*/
    if (IS_SEQUENCE(_35slist_16334)){
            _13859 = SEQ_PTR(_35slist_16334)->length;
    }
    else {
        _13859 = 1;
    }
    _2 = (int)SEQ_PTR(_35slist_16334);
    _13860 = (int)*(((s1_ptr)_2)->base + _13859);
    if (binary_op_a(NOTEQ, _13860, 0)){
        _13860 = NOVALUE;
        goto LF; // [302] 320
    }
    _13860 = NOVALUE;

    /** 				slist[$] = new*/
    if (IS_SEQUENCE(_35slist_16334)){
            _13862 = SEQ_PTR(_35slist_16334)->length;
    }
    else {
        _13862 = 1;
    }
    RefDS(_new_24089);
    _2 = (int)SEQ_PTR(_35slist_16334);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _35slist_16334 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _13862);
    _1 = *(int *)_2;
    *(int *)_2 = _new_24089;
    DeRef(_1);
    goto L10; // [317] 331
LF: 

    /** 				slist = append(slist, new)*/
    RefDS(_new_24089);
    Append(&_35slist_16334, _35slist_16334, _new_24089);
L10: 

    /** 			slist = append(slist, 0)*/
    Append(&_35slist_16334, _35slist_16334, 0);
    goto LE; // [342] 371
LA: 

    /** 		src = pack_source(src)*/
    Ref(_src_24092);
    _0 = _src_24092;
    _src_24092 = _61pack_source(_src_24092);
    DeRef(_0);

    /** 		slist = {{src, line_number, current_file_no, options}, 0}*/
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_src_24092);
    *((int *)(_2+4)) = _src_24092;
    *((int *)(_2+8)) = _35line_number_16245;
    *((int *)(_2+12)) = _35current_file_no_16244;
    *((int *)(_2+16)) = _options_24091;
    _13866 = MAKE_SEQ(_1);
    DeRef(_35slist_16334);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _13866;
    ((int *)_2)[2] = 0;
    _35slist_16334 = MAKE_SEQ(_1);
    _13866 = NOVALUE;
LE: 

    /** end procedure*/
    DeRef(_new_24089);
    DeRef(_old_24090);
    DeRef(_src_24092);
    DeRef(_13837);
    _13837 = NOVALUE;
    DeRef(_13850);
    _13850 = NOVALUE;
    DeRef(_13843);
    _13843 = NOVALUE;
    return;
    ;
}


int _61s_expand(int _slist_24181)
{
    int _new_slist_24182 = NOVALUE;
    int _13880 = NOVALUE;
    int _13879 = NOVALUE;
    int _13878 = NOVALUE;
    int _13877 = NOVALUE;
    int _13875 = NOVALUE;
    int _13874 = NOVALUE;
    int _13873 = NOVALUE;
    int _13871 = NOVALUE;
    int _13870 = NOVALUE;
    int _13869 = NOVALUE;
    int _13868 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	new_slist = {}*/
    RefDS(_5);
    DeRef(_new_slist_24182);
    _new_slist_24182 = _5;

    /** 	for i = 1 to length(slist) do*/
    if (IS_SEQUENCE(_slist_24181)){
            _13868 = SEQ_PTR(_slist_24181)->length;
    }
    else {
        _13868 = 1;
    }
    {
        int _i_24184;
        _i_24184 = 1;
L1: 
        if (_i_24184 > _13868){
            goto L2; // [15] 114
        }

        /** 		if sequence(slist[i]) then*/
        _2 = (int)SEQ_PTR(_slist_24181);
        _13869 = (int)*(((s1_ptr)_2)->base + _i_24184);
        _13870 = IS_SEQUENCE(_13869);
        _13869 = NOVALUE;
        if (_13870 == 0)
        {
            _13870 = NOVALUE;
            goto L3; // [31] 47
        }
        else{
            _13870 = NOVALUE;
        }

        /** 			new_slist = append(new_slist, slist[i])*/
        _2 = (int)SEQ_PTR(_slist_24181);
        _13871 = (int)*(((s1_ptr)_2)->base + _i_24184);
        Ref(_13871);
        Append(&_new_slist_24182, _new_slist_24182, _13871);
        _13871 = NOVALUE;
        goto L4; // [44] 107
L3: 

        /** 			for j = 1 to slist[i] do*/
        _2 = (int)SEQ_PTR(_slist_24181);
        _13873 = (int)*(((s1_ptr)_2)->base + _i_24184);
        {
            int _j_24193;
            _j_24193 = 1;
L5: 
            if (binary_op_a(GREATER, _j_24193, _13873)){
                goto L6; // [53] 106
            }

            /** 				slist[i-1][LINE] += 1*/
            _13874 = _i_24184 - 1;
            _2 = (int)SEQ_PTR(_slist_24181);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _slist_24181 = MAKE_SEQ(_2);
            }
            _3 = (int)(_13874 + ((s1_ptr)_2)->base);
            _2 = (int)SEQ_PTR(*(int *)_3);
            _13877 = (int)*(((s1_ptr)_2)->base + 2);
            _13875 = NOVALUE;
            if (IS_ATOM_INT(_13877)) {
                _13878 = _13877 + 1;
                if (_13878 > MAXINT){
                    _13878 = NewDouble((double)_13878);
                }
            }
            else
            _13878 = binary_op(PLUS, 1, _13877);
            _13877 = NOVALUE;
            _2 = (int)SEQ_PTR(*(int *)_3);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                *(int *)_3 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + 2);
            _1 = *(int *)_2;
            *(int *)_2 = _13878;
            if( _1 != _13878 ){
                DeRef(_1);
            }
            _13878 = NOVALUE;
            _13875 = NOVALUE;

            /** 				new_slist = append(new_slist, slist[i-1])*/
            _13879 = _i_24184 - 1;
            _2 = (int)SEQ_PTR(_slist_24181);
            _13880 = (int)*(((s1_ptr)_2)->base + _13879);
            Ref(_13880);
            Append(&_new_slist_24182, _new_slist_24182, _13880);
            _13880 = NOVALUE;

            /** 			end for*/
            _0 = _j_24193;
            if (IS_ATOM_INT(_j_24193)) {
                _j_24193 = _j_24193 + 1;
                if ((long)((unsigned long)_j_24193 +(unsigned long) HIGH_BITS) >= 0){
                    _j_24193 = NewDouble((double)_j_24193);
                }
            }
            else {
                _j_24193 = binary_op_a(PLUS, _j_24193, 1);
            }
            DeRef(_0);
            goto L5; // [101] 60
L6: 
            ;
            DeRef(_j_24193);
        }
L4: 

        /** 	end for*/
        _i_24184 = _i_24184 + 1;
        goto L1; // [109] 22
L2: 
        ;
    }

    /** 	return new_slist*/
    DeRefDS(_slist_24181);
    _13873 = NOVALUE;
    DeRef(_13874);
    _13874 = NOVALUE;
    DeRef(_13879);
    _13879 = NOVALUE;
    return _new_slist_24182;
    ;
}


void _61set_dont_read(int _read_24208)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_read_24208)) {
        _1 = (long)(DBL_PTR(_read_24208)->dbl);
        DeRefDS(_read_24208);
        _read_24208 = _1;
    }

    /** 	dont_read = read*/
    _61dont_read_24205 = _read_24208;

    /** end procedure*/
    return;
    ;
}


void _61read_line()
{
    int _n_24211 = NOVALUE;
    int _13894 = NOVALUE;
    int _13893 = NOVALUE;
    int _13891 = NOVALUE;
    int _13890 = NOVALUE;
    int _13888 = NOVALUE;
    int _13887 = NOVALUE;
    int _0, _1, _2;
    

    /** 	line_number += 1*/
    _35line_number_16245 = _35line_number_16245 + 1;

    /** 	gline_number += 1*/
    _35gline_number_16249 = _35gline_number_16249 + 1;

    /** 	if dont_read then*/
    if (_61dont_read_24205 == 0)
    {
        goto L1; // [25] 36
    }
    else{
    }

    /** 		ThisLine = -1*/
    DeRef(_44ThisLine_48518);
    _44ThisLine_48518 = -1;
    goto L2; // [33] 108
L1: 

    /** 	elsif src_file < 0 then*/
    if (_35src_file_16365 >= 0)
    goto L3; // [40] 52

    /** 		ThisLine = -1*/
    DeRef(_44ThisLine_48518);
    _44ThisLine_48518 = -1;
    goto L2; // [49] 108
L3: 

    /** 		ThisLine = gets(src_file)*/
    DeRef(_44ThisLine_48518);
    _44ThisLine_48518 = EGets(_35src_file_16365);

    /** 		if sequence(ThisLine) and ends( {13,10}, ThisLine ) then*/
    _13887 = IS_SEQUENCE(_44ThisLine_48518);
    if (_13887 == 0) {
        goto L4; // [66] 107
    }
    RefDS(_13889);
    Ref(_44ThisLine_48518);
    _13890 = _16ends(_13889, _44ThisLine_48518);
    if (_13890 == 0) {
        DeRef(_13890);
        _13890 = NOVALUE;
        goto L4; // [78] 107
    }
    else {
        if (!IS_ATOM_INT(_13890) && DBL_PTR(_13890)->dbl == 0.0){
            DeRef(_13890);
            _13890 = NOVALUE;
            goto L4; // [78] 107
        }
        DeRef(_13890);
        _13890 = NOVALUE;
    }
    DeRef(_13890);
    _13890 = NOVALUE;

    /** 			ThisLine = remove(ThisLine, length(ThisLine))*/
    if (IS_SEQUENCE(_44ThisLine_48518)){
            _13891 = SEQ_PTR(_44ThisLine_48518)->length;
    }
    else {
        _13891 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_44ThisLine_48518);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_13891)) ? _13891 : (long)(DBL_PTR(_13891)->dbl);
        int stop = (IS_ATOM_INT(_13891)) ? _13891 : (long)(DBL_PTR(_13891)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_44ThisLine_48518), start, &_44ThisLine_48518 );
            }
            else Tail(SEQ_PTR(_44ThisLine_48518), stop+1, &_44ThisLine_48518);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_44ThisLine_48518), start, &_44ThisLine_48518);
        }
        else {
            assign_slice_seq = &assign_space;
            _44ThisLine_48518 = Remove_elements(start, stop, (SEQ_PTR(_44ThisLine_48518)->ref == 1));
        }
    }
    _13891 = NOVALUE;
    _13891 = NOVALUE;

    /** 			ThisLine[$] = 10*/
    if (IS_SEQUENCE(_44ThisLine_48518)){
            _13893 = SEQ_PTR(_44ThisLine_48518)->length;
    }
    else {
        _13893 = 1;
    }
    _2 = (int)SEQ_PTR(_44ThisLine_48518);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _44ThisLine_48518 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _13893);
    _1 = *(int *)_2;
    *(int *)_2 = 10;
    DeRef(_1);
L4: 
L2: 

    /** 	if atom(ThisLine) then*/
    _13894 = IS_ATOM(_44ThisLine_48518);
    if (_13894 == 0)
    {
        _13894 = NOVALUE;
        goto L5; // [115] 149
    }
    else{
        _13894 = NOVALUE;
    }

    /** 		ThisLine = {END_OF_FILE_CHAR}*/
    _0 = _44ThisLine_48518;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 26;
    _44ThisLine_48518 = MAKE_SEQ(_1);
    DeRef(_0);

    /** 		if src_file >= 0 then*/
    if (_35src_file_16365 < 0)
    goto L6; // [130] 141

    /** 			close(src_file)*/
    EClose(_35src_file_16365);
L6: 

    /** 		src_file = -1*/
    _35src_file_16365 = -1;
L5: 

    /** 	bp = 1*/
    _44bp_48522 = 1;

    /** 	AppendSourceLine()*/
    _61AppendSourceLine();

    /** end procedure*/
    return;
    ;
}


int _61getch()
{
    int _c_24255 = NOVALUE;
    int _0, _1, _2;
    

    /** 	c = ThisLine[bp]*/
    _2 = (int)SEQ_PTR(_44ThisLine_48518);
    _c_24255 = (int)*(((s1_ptr)_2)->base + _44bp_48522);
    if (!IS_ATOM_INT(_c_24255)){
        _c_24255 = (long)DBL_PTR(_c_24255)->dbl;
    }

    /** 	bp += 1*/
    _44bp_48522 = _44bp_48522 + 1;

    /** 	return c*/
    return _c_24255;
    ;
}


void _61ungetch()
{
    int _0, _1, _2;
    

    /** 	bp -= 1*/
    _44bp_48522 = _44bp_48522 - 1;

    /** end procedure*/
    return;
    ;
}


int _61get_file_path(int _s_24267)
{
    int _13905 = NOVALUE;
    int _13903 = NOVALUE;
    int _13902 = NOVALUE;
    int _13901 = NOVALUE;
    int _13900 = NOVALUE;
    int _0, _1, _2;
    

    /** 		for t=length(s) to 1 by -1 do*/
    if (IS_SEQUENCE(_s_24267)){
            _13900 = SEQ_PTR(_s_24267)->length;
    }
    else {
        _13900 = 1;
    }
    {
        int _t_24269;
        _t_24269 = _13900;
L1: 
        if (_t_24269 < 1){
            goto L2; // [8] 50
        }

        /** 				if find(s[t],SLASH_CHARS) then*/
        _2 = (int)SEQ_PTR(_s_24267);
        _13901 = (int)*(((s1_ptr)_2)->base + _t_24269);
        _13902 = find_from(_13901, _40SLASH_CHARS_16402, 1);
        _13901 = NOVALUE;
        if (_13902 == 0)
        {
            _13902 = NOVALUE;
            goto L3; // [28] 43
        }
        else{
            _13902 = NOVALUE;
        }

        /** 						return s[1..t]*/
        rhs_slice_target = (object_ptr)&_13903;
        RHS_Slice(_s_24267, 1, _t_24269);
        DeRefDS(_s_24267);
        return _13903;
L3: 

        /** 		end for*/
        _t_24269 = _t_24269 + -1;
        goto L1; // [45] 15
L2: 
        ;
    }

    /** 		return "." & SLASH*/
    Append(&_13905, _13904, 92);
    DeRefDS(_s_24267);
    DeRef(_13903);
    _13903 = NOVALUE;
    return _13905;
    ;
}


int _61find_file(int _fname_24281)
{
    int _try_24282 = NOVALUE;
    int _full_path_24283 = NOVALUE;
    int _errbuff_24284 = NOVALUE;
    int _currdir_24285 = NOVALUE;
    int _conf_path_24286 = NOVALUE;
    int _scan_result_24287 = NOVALUE;
    int _inc_path_24288 = NOVALUE;
    int _mainpath_24307 = NOVALUE;
    int _31681 = NOVALUE;
    int _31680 = NOVALUE;
    int _14002 = NOVALUE;
    int _14000 = NOVALUE;
    int _13999 = NOVALUE;
    int _13998 = NOVALUE;
    int _13996 = NOVALUE;
    int _13994 = NOVALUE;
    int _13992 = NOVALUE;
    int _13991 = NOVALUE;
    int _13989 = NOVALUE;
    int _13988 = NOVALUE;
    int _13985 = NOVALUE;
    int _13982 = NOVALUE;
    int _13981 = NOVALUE;
    int _13980 = NOVALUE;
    int _13979 = NOVALUE;
    int _13978 = NOVALUE;
    int _13977 = NOVALUE;
    int _13976 = NOVALUE;
    int _13975 = NOVALUE;
    int _13972 = NOVALUE;
    int _13971 = NOVALUE;
    int _13967 = NOVALUE;
    int _13964 = NOVALUE;
    int _13963 = NOVALUE;
    int _13962 = NOVALUE;
    int _13961 = NOVALUE;
    int _13960 = NOVALUE;
    int _13959 = NOVALUE;
    int _13958 = NOVALUE;
    int _13957 = NOVALUE;
    int _13954 = NOVALUE;
    int _13950 = NOVALUE;
    int _13948 = NOVALUE;
    int _13947 = NOVALUE;
    int _13946 = NOVALUE;
    int _13945 = NOVALUE;
    int _13944 = NOVALUE;
    int _13941 = NOVALUE;
    int _13940 = NOVALUE;
    int _13939 = NOVALUE;
    int _13938 = NOVALUE;
    int _13937 = NOVALUE;
    int _13936 = NOVALUE;
    int _13934 = NOVALUE;
    int _13933 = NOVALUE;
    int _13932 = NOVALUE;
    int _13931 = NOVALUE;
    int _13930 = NOVALUE;
    int _13928 = NOVALUE;
    int _13927 = NOVALUE;
    int _13924 = NOVALUE;
    int _13921 = NOVALUE;
    int _13919 = NOVALUE;
    int _13916 = NOVALUE;
    int _13914 = NOVALUE;
    int _13913 = NOVALUE;
    int _13910 = NOVALUE;
    int _13909 = NOVALUE;
    int _13907 = NOVALUE;
    int _13906 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if absolute_path(fname) then*/
    RefDS(_fname_24281);
    _13906 = _17absolute_path(_fname_24281);
    if (_13906 == 0) {
        DeRef(_13906);
        _13906 = NOVALUE;
        goto L1; // [9] 42
    }
    else {
        if (!IS_ATOM_INT(_13906) && DBL_PTR(_13906)->dbl == 0.0){
            DeRef(_13906);
            _13906 = NOVALUE;
            goto L1; // [9] 42
        }
        DeRef(_13906);
        _13906 = NOVALUE;
    }
    DeRef(_13906);
    _13906 = NOVALUE;

    /** 		if not file_exists(fname) then*/
    RefDS(_fname_24281);
    _13907 = _17file_exists(_fname_24281);
    if (IS_ATOM_INT(_13907)) {
        if (_13907 != 0){
            DeRef(_13907);
            _13907 = NOVALUE;
            goto L2; // [18] 35
        }
    }
    else {
        if (DBL_PTR(_13907)->dbl != 0.0){
            DeRef(_13907);
            _13907 = NOVALUE;
            goto L2; // [18] 35
        }
    }
    DeRef(_13907);
    _13907 = NOVALUE;

    /** 			CompileErr(51, {new_include_name})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_35new_include_name_16366);
    *((int *)(_2+4)) = _35new_include_name_16366;
    _13909 = MAKE_SEQ(_1);
    _44CompileErr(51, _13909, 0);
    _13909 = NOVALUE;
L2: 

    /** 		return fname*/
    DeRef(_full_path_24283);
    DeRef(_errbuff_24284);
    DeRef(_currdir_24285);
    DeRef(_conf_path_24286);
    DeRef(_scan_result_24287);
    DeRef(_inc_path_24288);
    DeRef(_mainpath_24307);
    return _fname_24281;
L1: 

    /** 	currdir = get_file_path( known_files[current_file_no] )*/
    _2 = (int)SEQ_PTR(_36known_files_15243);
    _13910 = (int)*(((s1_ptr)_2)->base + _35current_file_no_16244);
    Ref(_13910);
    _0 = _currdir_24285;
    _currdir_24285 = _61get_file_path(_13910);
    DeRef(_0);
    _13910 = NOVALUE;

    /** 	full_path = currdir & fname*/
    Concat((object_ptr)&_full_path_24283, _currdir_24285, _fname_24281);

    /** 	if file_exists(full_path) then*/
    RefDS(_full_path_24283);
    _13913 = _17file_exists(_full_path_24283);
    if (_13913 == 0) {
        DeRef(_13913);
        _13913 = NOVALUE;
        goto L3; // [70] 80
    }
    else {
        if (!IS_ATOM_INT(_13913) && DBL_PTR(_13913)->dbl == 0.0){
            DeRef(_13913);
            _13913 = NOVALUE;
            goto L3; // [70] 80
        }
        DeRef(_13913);
        _13913 = NOVALUE;
    }
    DeRef(_13913);
    _13913 = NOVALUE;

    /** 		return full_path*/
    DeRefDS(_fname_24281);
    DeRef(_errbuff_24284);
    DeRefDS(_currdir_24285);
    DeRef(_conf_path_24286);
    DeRef(_scan_result_24287);
    DeRef(_inc_path_24288);
    DeRef(_mainpath_24307);
    return _full_path_24283;
L3: 

    /** 	sequence mainpath = main_path[1..rfind(SLASH, main_path)]*/
    RefDS(_35main_path_16364);
    DeRef(_31680);
    _31680 = _35main_path_16364;
    if (IS_SEQUENCE(_31680)){
            _31681 = SEQ_PTR(_31680)->length;
    }
    else {
        _31681 = 1;
    }
    _31680 = NOVALUE;
    RefDS(_35main_path_16364);
    _13914 = _16rfind(92, _35main_path_16364, _31681);
    _31681 = NOVALUE;
    rhs_slice_target = (object_ptr)&_mainpath_24307;
    RHS_Slice(_35main_path_16364, 1, _13914);

    /** 	if not equal(mainpath, currdir) then*/
    if (_mainpath_24307 == _currdir_24285)
    _13916 = 1;
    else if (IS_ATOM_INT(_mainpath_24307) && IS_ATOM_INT(_currdir_24285))
    _13916 = 0;
    else
    _13916 = (compare(_mainpath_24307, _currdir_24285) == 0);
    if (_13916 != 0)
    goto L4; // [111] 139
    _13916 = NOVALUE;

    /** 		full_path = mainpath & new_include_name*/
    Concat((object_ptr)&_full_path_24283, _mainpath_24307, _35new_include_name_16366);

    /** 		if file_exists(full_path) then*/
    RefDS(_full_path_24283);
    _13919 = _17file_exists(_full_path_24283);
    if (_13919 == 0) {
        DeRef(_13919);
        _13919 = NOVALUE;
        goto L5; // [128] 138
    }
    else {
        if (!IS_ATOM_INT(_13919) && DBL_PTR(_13919)->dbl == 0.0){
            DeRef(_13919);
            _13919 = NOVALUE;
            goto L5; // [128] 138
        }
        DeRef(_13919);
        _13919 = NOVALUE;
    }
    DeRef(_13919);
    _13919 = NOVALUE;

    /** 			return full_path*/
    DeRefDS(_fname_24281);
    DeRef(_errbuff_24284);
    DeRefDS(_currdir_24285);
    DeRef(_conf_path_24286);
    DeRef(_scan_result_24287);
    DeRef(_inc_path_24288);
    DeRefDS(_mainpath_24307);
    _31680 = NOVALUE;
    DeRef(_13914);
    _13914 = NOVALUE;
    return _full_path_24283;
L5: 
L4: 

    /** 	scan_result = ConfPath(new_include_name)*/
    RefDS(_35new_include_name_16366);
    _0 = _scan_result_24287;
    _scan_result_24287 = _42ConfPath(_35new_include_name_16366);
    DeRef(_0);

    /** 	if atom(scan_result) then*/
    _13921 = IS_ATOM(_scan_result_24287);
    if (_13921 == 0)
    {
        _13921 = NOVALUE;
        goto L6; // [152] 164
    }
    else{
        _13921 = NOVALUE;
    }

    /** 		scan_result = ScanPath(fname,"EUINC",0)*/
    RefDS(_fname_24281);
    RefDS(_13922);
    _0 = _scan_result_24287;
    _scan_result_24287 = _42ScanPath(_fname_24281, _13922, 0);
    DeRef(_0);
L6: 

    /** 	if atom(scan_result) then*/
    _13924 = IS_ATOM(_scan_result_24287);
    if (_13924 == 0)
    {
        _13924 = NOVALUE;
        goto L7; // [169] 181
    }
    else{
        _13924 = NOVALUE;
    }

    /** 		scan_result = ScanPath(fname, "EUDIR",1)*/
    RefDS(_fname_24281);
    RefDS(_13925);
    _0 = _scan_result_24287;
    _scan_result_24287 = _42ScanPath(_fname_24281, _13925, 1);
    DeRef(_0);
L7: 

    /** 	if atom(scan_result) then*/
    _13927 = IS_ATOM(_scan_result_24287);
    if (_13927 == 0)
    {
        _13927 = NOVALUE;
        goto L8; // [186] 223
    }
    else{
        _13927 = NOVALUE;
    }

    /** 		full_path = get_eudir() & SLASH & "include" & SLASH & fname*/
    _13928 = _36get_eudir();
    {
        int concat_list[5];

        concat_list[0] = _fname_24281;
        concat_list[1] = 92;
        concat_list[2] = _13348;
        concat_list[3] = 92;
        concat_list[4] = _13928;
        Concat_N((object_ptr)&_full_path_24283, concat_list, 5);
    }
    DeRef(_13928);
    _13928 = NOVALUE;

    /** 		if file_exists(full_path) then*/
    RefDS(_full_path_24283);
    _13930 = _17file_exists(_full_path_24283);
    if (_13930 == 0) {
        DeRef(_13930);
        _13930 = NOVALUE;
        goto L9; // [212] 222
    }
    else {
        if (!IS_ATOM_INT(_13930) && DBL_PTR(_13930)->dbl == 0.0){
            DeRef(_13930);
            _13930 = NOVALUE;
            goto L9; // [212] 222
        }
        DeRef(_13930);
        _13930 = NOVALUE;
    }
    DeRef(_13930);
    _13930 = NOVALUE;

    /** 			return full_path*/
    DeRefDS(_fname_24281);
    DeRef(_errbuff_24284);
    DeRef(_currdir_24285);
    DeRef(_conf_path_24286);
    DeRef(_scan_result_24287);
    DeRef(_inc_path_24288);
    DeRef(_mainpath_24307);
    _31680 = NOVALUE;
    DeRef(_13914);
    _13914 = NOVALUE;
    return _full_path_24283;
L9: 
L8: 

    /** 	if sequence(scan_result) then*/
    _13931 = IS_SEQUENCE(_scan_result_24287);
    if (_13931 == 0)
    {
        _13931 = NOVALUE;
        goto LA; // [228] 250
    }
    else{
        _13931 = NOVALUE;
    }

    /** 		close(scan_result[2])*/
    _2 = (int)SEQ_PTR(_scan_result_24287);
    _13932 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_13932))
    EClose(_13932);
    else
    EClose((int)DBL_PTR(_13932)->dbl);
    _13932 = NOVALUE;

    /** 		return scan_result[1]*/
    _2 = (int)SEQ_PTR(_scan_result_24287);
    _13933 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_13933);
    DeRefDS(_fname_24281);
    DeRef(_full_path_24283);
    DeRef(_errbuff_24284);
    DeRef(_currdir_24285);
    DeRef(_conf_path_24286);
    DeRef(_scan_result_24287);
    DeRef(_inc_path_24288);
    DeRef(_mainpath_24307);
    _31680 = NOVALUE;
    DeRef(_13914);
    _13914 = NOVALUE;
    return _13933;
LA: 

    /** 	errbuff = ""*/
    RefDS(_5);
    DeRef(_errbuff_24284);
    _errbuff_24284 = _5;

    /** 	full_path = {}*/
    RefDS(_5);
    DeRef(_full_path_24283);
    _full_path_24283 = _5;

    /** 	if length(currdir) > 0 then*/
    if (IS_SEQUENCE(_currdir_24285)){
            _13934 = SEQ_PTR(_currdir_24285)->length;
    }
    else {
        _13934 = 1;
    }
    if (_13934 <= 0)
    goto LB; // [269] 321

    /** 		if find(currdir[$], SLASH_CHARS) then*/
    if (IS_SEQUENCE(_currdir_24285)){
            _13936 = SEQ_PTR(_currdir_24285)->length;
    }
    else {
        _13936 = 1;
    }
    _2 = (int)SEQ_PTR(_currdir_24285);
    _13937 = (int)*(((s1_ptr)_2)->base + _13936);
    _13938 = find_from(_13937, _40SLASH_CHARS_16402, 1);
    _13937 = NOVALUE;
    if (_13938 == 0)
    {
        _13938 = NOVALUE;
        goto LC; // [289] 313
    }
    else{
        _13938 = NOVALUE;
    }

    /** 			full_path = append(full_path, currdir[1..$-1])*/
    if (IS_SEQUENCE(_currdir_24285)){
            _13939 = SEQ_PTR(_currdir_24285)->length;
    }
    else {
        _13939 = 1;
    }
    _13940 = _13939 - 1;
    _13939 = NOVALUE;
    rhs_slice_target = (object_ptr)&_13941;
    RHS_Slice(_currdir_24285, 1, _13940);
    RefDS(_13941);
    Append(&_full_path_24283, _full_path_24283, _13941);
    DeRefDS(_13941);
    _13941 = NOVALUE;
    goto LD; // [310] 320
LC: 

    /** 			full_path = append(full_path, currdir)*/
    RefDS(_currdir_24285);
    Append(&_full_path_24283, _full_path_24283, _currdir_24285);
LD: 
LB: 

    /** 	if find(main_path[$], SLASH_CHARS) then*/
    if (IS_SEQUENCE(_35main_path_16364)){
            _13944 = SEQ_PTR(_35main_path_16364)->length;
    }
    else {
        _13944 = 1;
    }
    _2 = (int)SEQ_PTR(_35main_path_16364);
    _13945 = (int)*(((s1_ptr)_2)->base + _13944);
    _13946 = find_from(_13945, _40SLASH_CHARS_16402, 1);
    _13945 = NOVALUE;
    if (_13946 == 0)
    {
        _13946 = NOVALUE;
        goto LE; // [339] 361
    }
    else{
        _13946 = NOVALUE;
    }

    /** 		errbuff = main_path[1..$-1]  -- looks better*/
    if (IS_SEQUENCE(_35main_path_16364)){
            _13947 = SEQ_PTR(_35main_path_16364)->length;
    }
    else {
        _13947 = 1;
    }
    _13948 = _13947 - 1;
    _13947 = NOVALUE;
    rhs_slice_target = (object_ptr)&_errbuff_24284;
    RHS_Slice(_35main_path_16364, 1, _13948);
    goto LF; // [358] 371
LE: 

    /** 		errbuff = main_path*/
    RefDS(_35main_path_16364);
    DeRef(_errbuff_24284);
    _errbuff_24284 = _35main_path_16364;
LF: 

    /** 	if not find(errbuff, full_path) then*/
    _13950 = find_from(_errbuff_24284, _full_path_24283, 1);
    if (_13950 != 0)
    goto L10; // [378] 388
    _13950 = NOVALUE;

    /** 		full_path = append(full_path, errbuff)*/
    RefDS(_errbuff_24284);
    Append(&_full_path_24283, _full_path_24283, _errbuff_24284);
L10: 

    /** 	conf_path = get_conf_dirs()*/
    _0 = _conf_path_24286;
    _conf_path_24286 = _42get_conf_dirs();
    DeRef(_0);

    /** 	if length(conf_path) > 0 then*/
    if (IS_SEQUENCE(_conf_path_24286)){
            _13954 = SEQ_PTR(_conf_path_24286)->length;
    }
    else {
        _13954 = 1;
    }
    if (_13954 <= 0)
    goto L11; // [400] 507

    /** 		conf_path = split(conf_path, PATHSEP)*/
    RefDS(_conf_path_24286);
    _0 = _conf_path_24286;
    _conf_path_24286 = _23split(_conf_path_24286, 59, 0, 0);
    DeRefDS(_0);

    /** 		for i = 1 to length(conf_path) do*/
    if (IS_SEQUENCE(_conf_path_24286)){
            _13957 = SEQ_PTR(_conf_path_24286)->length;
    }
    else {
        _13957 = 1;
    }
    {
        int _i_24388;
        _i_24388 = 1;
L12: 
        if (_i_24388 > _13957){
            goto L13; // [422] 506
        }

        /** 			if find(conf_path[i][$], SLASH_CHARS) then*/
        _2 = (int)SEQ_PTR(_conf_path_24286);
        _13958 = (int)*(((s1_ptr)_2)->base + _i_24388);
        if (IS_SEQUENCE(_13958)){
                _13959 = SEQ_PTR(_13958)->length;
        }
        else {
            _13959 = 1;
        }
        _2 = (int)SEQ_PTR(_13958);
        _13960 = (int)*(((s1_ptr)_2)->base + _13959);
        _13958 = NOVALUE;
        _13961 = find_from(_13960, _40SLASH_CHARS_16402, 1);
        _13960 = NOVALUE;
        if (_13961 == 0)
        {
            _13961 = NOVALUE;
            goto L14; // [449] 473
        }
        else{
            _13961 = NOVALUE;
        }

        /** 				errbuff = conf_path[i][1..$-1]  -- looks better*/
        _2 = (int)SEQ_PTR(_conf_path_24286);
        _13962 = (int)*(((s1_ptr)_2)->base + _i_24388);
        if (IS_SEQUENCE(_13962)){
                _13963 = SEQ_PTR(_13962)->length;
        }
        else {
            _13963 = 1;
        }
        _13964 = _13963 - 1;
        _13963 = NOVALUE;
        rhs_slice_target = (object_ptr)&_errbuff_24284;
        RHS_Slice(_13962, 1, _13964);
        _13962 = NOVALUE;
        goto L15; // [470] 482
L14: 

        /** 				errbuff = conf_path[i]*/
        DeRef(_errbuff_24284);
        _2 = (int)SEQ_PTR(_conf_path_24286);
        _errbuff_24284 = (int)*(((s1_ptr)_2)->base + _i_24388);
        Ref(_errbuff_24284);
L15: 

        /** 			if not find(errbuff, full_path) then*/
        _13967 = find_from(_errbuff_24284, _full_path_24283, 1);
        if (_13967 != 0)
        goto L16; // [489] 499
        _13967 = NOVALUE;

        /** 				full_path = append(full_path, errbuff)*/
        RefDS(_errbuff_24284);
        Append(&_full_path_24283, _full_path_24283, _errbuff_24284);
L16: 

        /** 		end for*/
        _i_24388 = _i_24388 + 1;
        goto L12; // [501] 429
L13: 
        ;
    }
L11: 

    /** 	inc_path = getenv("EUINC")*/
    DeRef(_inc_path_24288);
    _inc_path_24288 = EGetEnv(_13922);

    /** 	if sequence(inc_path) then*/
    _13971 = IS_SEQUENCE(_inc_path_24288);
    if (_13971 == 0)
    {
        _13971 = NOVALUE;
        goto L17; // [517] 631
    }
    else{
        _13971 = NOVALUE;
    }

    /** 		if length(inc_path) > 0 then*/
    if (IS_SEQUENCE(_inc_path_24288)){
            _13972 = SEQ_PTR(_inc_path_24288)->length;
    }
    else {
        _13972 = 1;
    }
    if (_13972 <= 0)
    goto L18; // [525] 630

    /** 			inc_path = split(inc_path, PATHSEP)*/
    Ref(_inc_path_24288);
    _0 = _inc_path_24288;
    _inc_path_24288 = _23split(_inc_path_24288, 59, 0, 0);
    DeRefi(_0);

    /** 			for i = 1 to length(inc_path) do*/
    if (IS_SEQUENCE(_inc_path_24288)){
            _13975 = SEQ_PTR(_inc_path_24288)->length;
    }
    else {
        _13975 = 1;
    }
    {
        int _i_24416;
        _i_24416 = 1;
L19: 
        if (_i_24416 > _13975){
            goto L1A; // [545] 629
        }

        /** 				if find(inc_path[i][$], SLASH_CHARS) then*/
        _2 = (int)SEQ_PTR(_inc_path_24288);
        _13976 = (int)*(((s1_ptr)_2)->base + _i_24416);
        if (IS_SEQUENCE(_13976)){
                _13977 = SEQ_PTR(_13976)->length;
        }
        else {
            _13977 = 1;
        }
        _2 = (int)SEQ_PTR(_13976);
        _13978 = (int)*(((s1_ptr)_2)->base + _13977);
        _13976 = NOVALUE;
        _13979 = find_from(_13978, _40SLASH_CHARS_16402, 1);
        _13978 = NOVALUE;
        if (_13979 == 0)
        {
            _13979 = NOVALUE;
            goto L1B; // [572] 596
        }
        else{
            _13979 = NOVALUE;
        }

        /** 					errbuff = inc_path[i][1..$-1]  -- looks better*/
        _2 = (int)SEQ_PTR(_inc_path_24288);
        _13980 = (int)*(((s1_ptr)_2)->base + _i_24416);
        if (IS_SEQUENCE(_13980)){
                _13981 = SEQ_PTR(_13980)->length;
        }
        else {
            _13981 = 1;
        }
        _13982 = _13981 - 1;
        _13981 = NOVALUE;
        rhs_slice_target = (object_ptr)&_errbuff_24284;
        RHS_Slice(_13980, 1, _13982);
        _13980 = NOVALUE;
        goto L1C; // [593] 605
L1B: 

        /** 					errbuff = inc_path[i]*/
        DeRef(_errbuff_24284);
        _2 = (int)SEQ_PTR(_inc_path_24288);
        _errbuff_24284 = (int)*(((s1_ptr)_2)->base + _i_24416);
        Ref(_errbuff_24284);
L1C: 

        /** 				if not find(errbuff, full_path) then*/
        _13985 = find_from(_errbuff_24284, _full_path_24283, 1);
        if (_13985 != 0)
        goto L1D; // [612] 622
        _13985 = NOVALUE;

        /** 					full_path = append(full_path, errbuff)*/
        RefDS(_errbuff_24284);
        Append(&_full_path_24283, _full_path_24283, _errbuff_24284);
L1D: 

        /** 			end for*/
        _i_24416 = _i_24416 + 1;
        goto L19; // [624] 552
L1A: 
        ;
    }
L18: 
L17: 

    /** 	if length(get_eudir()) > 0 then*/
    _13988 = _36get_eudir();
    if (IS_SEQUENCE(_13988)){
            _13989 = SEQ_PTR(_13988)->length;
    }
    else {
        _13989 = 1;
    }
    DeRef(_13988);
    _13988 = NOVALUE;
    if (_13989 <= 0)
    goto L1E; // [639] 667

    /** 		if not find(get_eudir(), full_path) then*/
    _13991 = _36get_eudir();
    _13992 = find_from(_13991, _full_path_24283, 1);
    DeRef(_13991);
    _13991 = NOVALUE;
    if (_13992 != 0)
    goto L1F; // [653] 666
    _13992 = NOVALUE;

    /** 			full_path = append(full_path, get_eudir())*/
    _13994 = _36get_eudir();
    Ref(_13994);
    Append(&_full_path_24283, _full_path_24283, _13994);
    DeRef(_13994);
    _13994 = NOVALUE;
L1F: 
L1E: 

    /** 	errbuff = ""*/
    RefDS(_5);
    DeRef(_errbuff_24284);
    _errbuff_24284 = _5;

    /** 	for i = 1 to length(full_path) do*/
    if (IS_SEQUENCE(_full_path_24283)){
            _13996 = SEQ_PTR(_full_path_24283)->length;
    }
    else {
        _13996 = 1;
    }
    {
        int _i_24448;
        _i_24448 = 1;
L20: 
        if (_i_24448 > _13996){
            goto L21; // [679] 711
        }

        /** 		errbuff &= sprintf("\t%s\n", {full_path[i]})*/
        _2 = (int)SEQ_PTR(_full_path_24283);
        _13998 = (int)*(((s1_ptr)_2)->base + _i_24448);
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        Ref(_13998);
        *((int *)(_2+4)) = _13998;
        _13999 = MAKE_SEQ(_1);
        _13998 = NOVALUE;
        _14000 = EPrintf(-9999999, _13997, _13999);
        DeRefDS(_13999);
        _13999 = NOVALUE;
        Concat((object_ptr)&_errbuff_24284, _errbuff_24284, _14000);
        DeRefDS(_14000);
        _14000 = NOVALUE;

        /** 	end for*/
        _i_24448 = _i_24448 + 1;
        goto L20; // [706] 686
L21: 
        ;
    }

    /** 	CompileErr(52, {new_include_name, errbuff})*/
    RefDS(_errbuff_24284);
    RefDS(_35new_include_name_16366);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _35new_include_name_16366;
    ((int *)_2)[2] = _errbuff_24284;
    _14002 = MAKE_SEQ(_1);
    _44CompileErr(52, _14002, 0);
    _14002 = NOVALUE;
    ;
}


int _61path_open()
{
    int _fh_24460 = NOVALUE;
    int _0, _1, _2;
    

    /** 	new_include_name = find_file(new_include_name)*/
    RefDS(_35new_include_name_16366);
    _0 = _61find_file(_35new_include_name_16366);
    DeRefDS(_35new_include_name_16366);
    _35new_include_name_16366 = _0;

    /** 	new_include_name = maybe_preprocess(new_include_name)*/
    RefDS(_35new_include_name_16366);
    _0 = _64maybe_preprocess(_35new_include_name_16366);
    DeRefDS(_35new_include_name_16366);
    _35new_include_name_16366 = _0;

    /** 	fh = open_locked(new_include_name)*/
    RefDS(_35new_include_name_16366);
    _fh_24460 = _36open_locked(_35new_include_name_16366);
    if (!IS_ATOM_INT(_fh_24460)) {
        _1 = (long)(DBL_PTR(_fh_24460)->dbl);
        DeRefDS(_fh_24460);
        _fh_24460 = _1;
    }

    /** 	return fh*/
    return _fh_24460;
    ;
}


int _61NameSpace_declaration(int _sym_24488)
{
    int _h_24489 = NOVALUE;
    int _14026 = NOVALUE;
    int _14024 = NOVALUE;
    int _14022 = NOVALUE;
    int _14020 = NOVALUE;
    int _14019 = NOVALUE;
    int _14018 = NOVALUE;
    int _14016 = NOVALUE;
    int _14015 = NOVALUE;
    int _14014 = NOVALUE;
    int _14013 = NOVALUE;
    int _14012 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_sym_24488)) {
        _1 = (long)(DBL_PTR(_sym_24488)->dbl);
        DeRefDS(_sym_24488);
        _sym_24488 = _1;
    }

    /** 	DefinedYet(sym)*/
    _53DefinedYet(_sym_24488);

    /** 	if find(SymTab[sym][S_SCOPE], {SC_GLOBAL, SC_PUBLIC, SC_EXPORT, SC_PREDEF}) then*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _14012 = (int)*(((s1_ptr)_2)->base + _sym_24488);
    _2 = (int)SEQ_PTR(_14012);
    _14013 = (int)*(((s1_ptr)_2)->base + 4);
    _14012 = NOVALUE;
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 6;
    *((int *)(_2+8)) = 13;
    *((int *)(_2+12)) = 11;
    *((int *)(_2+16)) = 7;
    _14014 = MAKE_SEQ(_1);
    _14015 = find_from(_14013, _14014, 1);
    _14013 = NOVALUE;
    DeRefDS(_14014);
    _14014 = NOVALUE;
    if (_14015 == 0)
    {
        _14015 = NOVALUE;
        goto L1; // [42] 104
    }
    else{
        _14015 = NOVALUE;
    }

    /** 		h = SymTab[sym][S_HASHVAL]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _14016 = (int)*(((s1_ptr)_2)->base + _sym_24488);
    _2 = (int)SEQ_PTR(_14016);
    _h_24489 = (int)*(((s1_ptr)_2)->base + 11);
    if (!IS_ATOM_INT(_h_24489)){
        _h_24489 = (long)DBL_PTR(_h_24489)->dbl;
    }
    _14016 = NOVALUE;

    /** 		sym = NewEntry(SymTab[sym][S_NAME], 0, 0, VARIABLE, h, buckets[h], 0)*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _14018 = (int)*(((s1_ptr)_2)->base + _sym_24488);
    _2 = (int)SEQ_PTR(_14018);
    if (!IS_ATOM_INT(_35S_NAME_15917)){
        _14019 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15917)->dbl));
    }
    else{
        _14019 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15917);
    }
    _14018 = NOVALUE;
    _2 = (int)SEQ_PTR(_53buckets_46087);
    _14020 = (int)*(((s1_ptr)_2)->base + _h_24489);
    Ref(_14019);
    Ref(_14020);
    _sym_24488 = _53NewEntry(_14019, 0, 0, -100, _h_24489, _14020, 0);
    _14019 = NOVALUE;
    _14020 = NOVALUE;
    if (!IS_ATOM_INT(_sym_24488)) {
        _1 = (long)(DBL_PTR(_sym_24488)->dbl);
        DeRefDS(_sym_24488);
        _sym_24488 = _1;
    }

    /** 		buckets[h] = sym*/
    _2 = (int)SEQ_PTR(_53buckets_46087);
    _2 = (int)(((s1_ptr)_2)->base + _h_24489);
    _1 = *(int *)_2;
    *(int *)_2 = _sym_24488;
    DeRef(_1);
L1: 

    /** 	SymTab[sym][S_SCOPE] = SC_LOCAL*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_24488 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = 5;
    DeRef(_1);
    _14022 = NOVALUE;

    /** 	SymTab[sym][S_MODE] = M_CONSTANT*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_24488 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = 2;
    DeRef(_1);
    _14024 = NOVALUE;

    /** 	SymTab[sym][S_TOKEN] = NAMESPACE -- [S_OBJ] will get the file number referred-to*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_24488 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35S_TOKEN_15922))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TOKEN_15922)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _35S_TOKEN_15922);
    _1 = *(int *)_2;
    *(int *)_2 = 523;
    DeRef(_1);
    _14026 = NOVALUE;

    /** 	if TRANSLATE then*/
    if (_35TRANSLATE_15887 == 0)
    {
        goto L2; // [159] 173
    }
    else{
    }

    /** 		num_routines += 1 -- order of ns declaration relative to routines*/
    _35num_routines_16253 = _35num_routines_16253 + 1;
L2: 

    /** 	return sym*/
    return _sym_24488;
    ;
}


void _61default_namespace()
{
    int _tok_24539 = NOVALUE;
    int _sym_24541 = NOVALUE;
    int _14050 = NOVALUE;
    int _14049 = NOVALUE;
    int _14047 = NOVALUE;
    int _14045 = NOVALUE;
    int _14042 = NOVALUE;
    int _14039 = NOVALUE;
    int _14037 = NOVALUE;
    int _14035 = NOVALUE;
    int _14034 = NOVALUE;
    int _14033 = NOVALUE;
    int _14032 = NOVALUE;
    int _14031 = NOVALUE;
    int _14030 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	tok = call_func( scanner_rid, {} )*/
    _0 = (int)_00[_61scanner_rid_24535].addr;
    _1 = (*(int (*)())_0)(
                         );
    DeRef(_tok_24539);
    _tok_24539 = _1;

    /** 	if tok[T_ID] = VARIABLE and equal( SymTab[tok[T_SYM]][S_NAME], "namespace" ) then*/
    _2 = (int)SEQ_PTR(_tok_24539);
    _14030 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_14030)) {
        _14031 = (_14030 == -100);
    }
    else {
        _14031 = binary_op(EQUALS, _14030, -100);
    }
    _14030 = NOVALUE;
    if (IS_ATOM_INT(_14031)) {
        if (_14031 == 0) {
            goto L1; // [23] 177
        }
    }
    else {
        if (DBL_PTR(_14031)->dbl == 0.0) {
            goto L1; // [23] 177
        }
    }
    _2 = (int)SEQ_PTR(_tok_24539);
    _14033 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!IS_ATOM_INT(_14033)){
        _14034 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_14033)->dbl));
    }
    else{
        _14034 = (int)*(((s1_ptr)_2)->base + _14033);
    }
    _2 = (int)SEQ_PTR(_14034);
    if (!IS_ATOM_INT(_35S_NAME_15917)){
        _14035 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15917)->dbl));
    }
    else{
        _14035 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15917);
    }
    _14034 = NOVALUE;
    if (_14035 == _14036)
    _14037 = 1;
    else if (IS_ATOM_INT(_14035) && IS_ATOM_INT(_14036))
    _14037 = 0;
    else
    _14037 = (compare(_14035, _14036) == 0);
    _14035 = NOVALUE;
    if (_14037 == 0)
    {
        _14037 = NOVALUE;
        goto L1; // [50] 177
    }
    else{
        _14037 = NOVALUE;
    }

    /** 		tok = call_func( scanner_rid, {} )*/
    _0 = (int)_00[_61scanner_rid_24535].addr;
    _1 = (*(int (*)())_0)(
                         );
    DeRef(_tok_24539);
    _tok_24539 = _1;

    /** 		if tok[T_ID] != VARIABLE then*/
    _2 = (int)SEQ_PTR(_tok_24539);
    _14039 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _14039, -100)){
        _14039 = NOVALUE;
        goto L2; // [71] 83
    }
    _14039 = NOVALUE;

    /** 			CompileErr(114)*/
    RefDS(_22023);
    _44CompileErr(114, _22023, 0);
L2: 

    /** 		sym = tok[T_SYM]*/
    _2 = (int)SEQ_PTR(_tok_24539);
    _sym_24541 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_sym_24541)){
        _sym_24541 = (long)DBL_PTR(_sym_24541)->dbl;
    }

    /** 		SymTab[sym][S_FILE_NO] = current_file_no*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_24541 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35S_FILE_NO_15913))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FILE_NO_15913)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _35S_FILE_NO_15913);
    _1 = *(int *)_2;
    *(int *)_2 = _35current_file_no_16244;
    DeRef(_1);
    _14042 = NOVALUE;

    /** 		sym  = NameSpace_declaration( sym )*/
    _sym_24541 = _61NameSpace_declaration(_sym_24541);
    if (!IS_ATOM_INT(_sym_24541)) {
        _1 = (long)(DBL_PTR(_sym_24541)->dbl);
        DeRefDS(_sym_24541);
        _sym_24541 = _1;
    }

    /** 		SymTab[sym][S_OBJ] = current_file_no*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_24541 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _35current_file_no_16244;
    DeRef(_1);
    _14045 = NOVALUE;

    /** 		SymTab[sym][S_SCOPE] = SC_PUBLIC*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_24541 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = 13;
    DeRef(_1);
    _14047 = NOVALUE;

    /** 		default_namespaces[current_file_no] = SymTab[sym][S_NAME]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _14049 = (int)*(((s1_ptr)_2)->base + _sym_24541);
    _2 = (int)SEQ_PTR(_14049);
    if (!IS_ATOM_INT(_35S_NAME_15917)){
        _14050 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15917)->dbl));
    }
    else{
        _14050 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15917);
    }
    _14049 = NOVALUE;
    Ref(_14050);
    _2 = (int)SEQ_PTR(_61default_namespaces_23902);
    _2 = (int)(((s1_ptr)_2)->base + _35current_file_no_16244);
    _1 = *(int *)_2;
    *(int *)_2 = _14050;
    if( _1 != _14050 ){
        DeRef(_1);
    }
    _14050 = NOVALUE;
    goto L3; // [174] 185
L1: 

    /** 		bp = 1*/
    _44bp_48522 = 1;
L3: 

    /** end procedure*/
    DeRef(_tok_24539);
    _14033 = NOVALUE;
    DeRef(_14031);
    _14031 = NOVALUE;
    return;
    ;
}


void _61add_exports(int _from_file_24591, int _to_file_24592)
{
    int _exports_24593 = NOVALUE;
    int _direct_24594 = NOVALUE;
    int _14070 = NOVALUE;
    int _14069 = NOVALUE;
    int _14068 = NOVALUE;
    int _14067 = NOVALUE;
    int _14066 = NOVALUE;
    int _14064 = NOVALUE;
    int _14062 = NOVALUE;
    int _14061 = NOVALUE;
    int _14059 = NOVALUE;
    int _14058 = NOVALUE;
    int _14057 = NOVALUE;
    int _14055 = NOVALUE;
    int _14054 = NOVALUE;
    int _14053 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	direct = file_include[to_file]*/
    DeRef(_direct_24594);
    _2 = (int)SEQ_PTR(_36file_include_15247);
    _direct_24594 = (int)*(((s1_ptr)_2)->base + _to_file_24592);
    Ref(_direct_24594);

    /** 	exports = file_public[from_file]*/
    DeRef(_exports_24593);
    _2 = (int)SEQ_PTR(_36file_public_15253);
    _exports_24593 = (int)*(((s1_ptr)_2)->base + _from_file_24591);
    Ref(_exports_24593);

    /** 	for i = 1 to length(exports) do*/
    if (IS_SEQUENCE(_exports_24593)){
            _14053 = SEQ_PTR(_exports_24593)->length;
    }
    else {
        _14053 = 1;
    }
    {
        int _i_24600;
        _i_24600 = 1;
L1: 
        if (_i_24600 > _14053){
            goto L2; // [30] 127
        }

        /** 		if not find( exports[i], direct ) then*/
        _2 = (int)SEQ_PTR(_exports_24593);
        _14054 = (int)*(((s1_ptr)_2)->base + _i_24600);
        _14055 = find_from(_14054, _direct_24594, 1);
        _14054 = NOVALUE;
        if (_14055 != 0)
        goto L3; // [48] 120
        _14055 = NOVALUE;

        /** 			if not find( -exports[i], direct ) then*/
        _2 = (int)SEQ_PTR(_exports_24593);
        _14057 = (int)*(((s1_ptr)_2)->base + _i_24600);
        if (IS_ATOM_INT(_14057)) {
            if ((unsigned long)_14057 == 0xC0000000)
            _14058 = (int)NewDouble((double)-0xC0000000);
            else
            _14058 = - _14057;
        }
        else {
            _14058 = unary_op(UMINUS, _14057);
        }
        _14057 = NOVALUE;
        _14059 = find_from(_14058, _direct_24594, 1);
        DeRef(_14058);
        _14058 = NOVALUE;
        if (_14059 != 0)
        goto L4; // [65] 82
        _14059 = NOVALUE;

        /** 				direct &= -exports[i]*/
        _2 = (int)SEQ_PTR(_exports_24593);
        _14061 = (int)*(((s1_ptr)_2)->base + _i_24600);
        if (IS_ATOM_INT(_14061)) {
            if ((unsigned long)_14061 == 0xC0000000)
            _14062 = (int)NewDouble((double)-0xC0000000);
            else
            _14062 = - _14061;
        }
        else {
            _14062 = unary_op(UMINUS, _14061);
        }
        _14061 = NOVALUE;
        if (IS_SEQUENCE(_direct_24594) && IS_ATOM(_14062)) {
            Ref(_14062);
            Append(&_direct_24594, _direct_24594, _14062);
        }
        else if (IS_ATOM(_direct_24594) && IS_SEQUENCE(_14062)) {
        }
        else {
            Concat((object_ptr)&_direct_24594, _direct_24594, _14062);
        }
        DeRef(_14062);
        _14062 = NOVALUE;
L4: 

        /** 			include_matrix[to_file][exports[i]] = or_bits( PUBLIC_INCLUDE, include_matrix[to_file][exports[i]] )*/
        _2 = (int)SEQ_PTR(_36include_matrix_15249);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _36include_matrix_15249 = MAKE_SEQ(_2);
        }
        _3 = (int)(_to_file_24592 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(_exports_24593);
        _14066 = (int)*(((s1_ptr)_2)->base + _i_24600);
        _2 = (int)SEQ_PTR(_36include_matrix_15249);
        _14067 = (int)*(((s1_ptr)_2)->base + _to_file_24592);
        _2 = (int)SEQ_PTR(_exports_24593);
        _14068 = (int)*(((s1_ptr)_2)->base + _i_24600);
        _2 = (int)SEQ_PTR(_14067);
        if (!IS_ATOM_INT(_14068)){
            _14069 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_14068)->dbl));
        }
        else{
            _14069 = (int)*(((s1_ptr)_2)->base + _14068);
        }
        _14067 = NOVALUE;
        if (IS_ATOM_INT(_14069)) {
            {unsigned long tu;
                 tu = (unsigned long)4 | (unsigned long)_14069;
                 _14070 = MAKE_UINT(tu);
            }
        }
        else {
            _14070 = binary_op(OR_BITS, 4, _14069);
        }
        _14069 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_14066))
        _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_14066)->dbl));
        else
        _2 = (int)(((s1_ptr)_2)->base + _14066);
        _1 = *(int *)_2;
        *(int *)_2 = _14070;
        if( _1 != _14070 ){
            DeRef(_1);
        }
        _14070 = NOVALUE;
        _14064 = NOVALUE;
L3: 

        /** 	end for*/
        _i_24600 = _i_24600 + 1;
        goto L1; // [122] 37
L2: 
        ;
    }

    /** 	file_include[to_file] = direct*/
    RefDS(_direct_24594);
    _2 = (int)SEQ_PTR(_36file_include_15247);
    _2 = (int)(((s1_ptr)_2)->base + _to_file_24592);
    _1 = *(int *)_2;
    *(int *)_2 = _direct_24594;
    DeRef(_1);

    /** end procedure*/
    DeRef(_exports_24593);
    DeRefDS(_direct_24594);
    _14066 = NOVALUE;
    _14068 = NOVALUE;
    return;
    ;
}


void _61patch_exports(int _for_file_24627)
{
    int _export_len_24628 = NOVALUE;
    int _14081 = NOVALUE;
    int _14080 = NOVALUE;
    int _14078 = NOVALUE;
    int _14077 = NOVALUE;
    int _14076 = NOVALUE;
    int _14075 = NOVALUE;
    int _14073 = NOVALUE;
    int _14072 = NOVALUE;
    int _14071 = NOVALUE;
    int _0, _1, _2;
    

    /** 	for i = 1 to length(file_include) do*/
    if (IS_SEQUENCE(_36file_include_15247)){
            _14071 = SEQ_PTR(_36file_include_15247)->length;
    }
    else {
        _14071 = 1;
    }
    {
        int _i_24630;
        _i_24630 = 1;
L1: 
        if (_i_24630 > _14071){
            goto L2; // [10] 99
        }

        /** 		if find( for_file, file_include[i] ) or find( -for_file, file_include[i] ) then*/
        _2 = (int)SEQ_PTR(_36file_include_15247);
        _14072 = (int)*(((s1_ptr)_2)->base + _i_24630);
        _14073 = find_from(_for_file_24627, _14072, 1);
        _14072 = NOVALUE;
        if (_14073 != 0) {
            goto L3; // [30] 53
        }
        if ((unsigned long)_for_file_24627 == 0xC0000000)
        _14075 = (int)NewDouble((double)-0xC0000000);
        else
        _14075 = - _for_file_24627;
        _2 = (int)SEQ_PTR(_36file_include_15247);
        _14076 = (int)*(((s1_ptr)_2)->base + _i_24630);
        _14077 = find_from(_14075, _14076, 1);
        DeRef(_14075);
        _14075 = NOVALUE;
        _14076 = NOVALUE;
        if (_14077 == 0)
        {
            _14077 = NOVALUE;
            goto L4; // [49] 92
        }
        else{
            _14077 = NOVALUE;
        }
L3: 

        /** 			export_len = length( file_include[i] )*/
        _2 = (int)SEQ_PTR(_36file_include_15247);
        _14078 = (int)*(((s1_ptr)_2)->base + _i_24630);
        if (IS_SEQUENCE(_14078)){
                _export_len_24628 = SEQ_PTR(_14078)->length;
        }
        else {
            _export_len_24628 = 1;
        }
        _14078 = NOVALUE;

        /** 			add_exports( for_file, i )*/
        _61add_exports(_for_file_24627, _i_24630);

        /** 			if length( file_include[i] ) != export_len then*/
        _2 = (int)SEQ_PTR(_36file_include_15247);
        _14080 = (int)*(((s1_ptr)_2)->base + _i_24630);
        if (IS_SEQUENCE(_14080)){
                _14081 = SEQ_PTR(_14080)->length;
        }
        else {
            _14081 = 1;
        }
        _14080 = NOVALUE;
        if (_14081 == _export_len_24628)
        goto L5; // [81] 91

        /** 				patch_exports( i )*/
        _61patch_exports(_i_24630);
L5: 
L4: 

        /** 	end for*/
        _i_24630 = _i_24630 + 1;
        goto L1; // [94] 17
L2: 
        ;
    }

    /** end procedure*/
    _14078 = NOVALUE;
    _14080 = NOVALUE;
    return;
    ;
}


void _61update_include_matrix(int _included_file_24652, int _from_file_24653)
{
    int _add_public_24663 = NOVALUE;
    int _px_24681 = NOVALUE;
    int _indirect_24740 = NOVALUE;
    int _mask_24743 = NOVALUE;
    int _ix_24754 = NOVALUE;
    int _indirect_file_24758 = NOVALUE;
    int _14157 = NOVALUE;
    int _14156 = NOVALUE;
    int _14154 = NOVALUE;
    int _14153 = NOVALUE;
    int _14152 = NOVALUE;
    int _14151 = NOVALUE;
    int _14150 = NOVALUE;
    int _14149 = NOVALUE;
    int _14148 = NOVALUE;
    int _14147 = NOVALUE;
    int _14146 = NOVALUE;
    int _14143 = NOVALUE;
    int _14141 = NOVALUE;
    int _14140 = NOVALUE;
    int _14139 = NOVALUE;
    int _14137 = NOVALUE;
    int _14135 = NOVALUE;
    int _14134 = NOVALUE;
    int _14132 = NOVALUE;
    int _14131 = NOVALUE;
    int _14130 = NOVALUE;
    int _14129 = NOVALUE;
    int _14128 = NOVALUE;
    int _14126 = NOVALUE;
    int _14125 = NOVALUE;
    int _14124 = NOVALUE;
    int _14123 = NOVALUE;
    int _14122 = NOVALUE;
    int _14121 = NOVALUE;
    int _14119 = NOVALUE;
    int _14118 = NOVALUE;
    int _14117 = NOVALUE;
    int _14115 = NOVALUE;
    int _14114 = NOVALUE;
    int _14113 = NOVALUE;
    int _14112 = NOVALUE;
    int _14111 = NOVALUE;
    int _14110 = NOVALUE;
    int _14109 = NOVALUE;
    int _14108 = NOVALUE;
    int _14107 = NOVALUE;
    int _14106 = NOVALUE;
    int _14105 = NOVALUE;
    int _14103 = NOVALUE;
    int _14102 = NOVALUE;
    int _14100 = NOVALUE;
    int _14098 = NOVALUE;
    int _14096 = NOVALUE;
    int _14095 = NOVALUE;
    int _14094 = NOVALUE;
    int _14093 = NOVALUE;
    int _14091 = NOVALUE;
    int _14090 = NOVALUE;
    int _14089 = NOVALUE;
    int _14087 = NOVALUE;
    int _14086 = NOVALUE;
    int _14085 = NOVALUE;
    int _14083 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	include_matrix[from_file][included_file] = or_bits( DIRECT_INCLUDE, include_matrix[from_file][included_file] )*/
    _2 = (int)SEQ_PTR(_36include_matrix_15249);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36include_matrix_15249 = MAKE_SEQ(_2);
    }
    _3 = (int)(_from_file_24653 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_36include_matrix_15249);
    _14085 = (int)*(((s1_ptr)_2)->base + _from_file_24653);
    _2 = (int)SEQ_PTR(_14085);
    _14086 = (int)*(((s1_ptr)_2)->base + _included_file_24652);
    _14085 = NOVALUE;
    if (IS_ATOM_INT(_14086)) {
        {unsigned long tu;
             tu = (unsigned long)2 | (unsigned long)_14086;
             _14087 = MAKE_UINT(tu);
        }
    }
    else {
        _14087 = binary_op(OR_BITS, 2, _14086);
    }
    _14086 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _included_file_24652);
    _1 = *(int *)_2;
    *(int *)_2 = _14087;
    if( _1 != _14087 ){
        DeRef(_1);
    }
    _14087 = NOVALUE;
    _14083 = NOVALUE;

    /** 	if public_include then*/
    if (_61public_include_23899 == 0)
    {
        goto L1; // [38] 339
    }
    else{
    }

    /** 		sequence add_public = file_include_by[from_file]*/
    DeRef(_add_public_24663);
    _2 = (int)SEQ_PTR(_36file_include_by_15255);
    _add_public_24663 = (int)*(((s1_ptr)_2)->base + _from_file_24653);
    Ref(_add_public_24663);

    /** 		for i = 1 to length( add_public ) do*/
    if (IS_SEQUENCE(_add_public_24663)){
            _14089 = SEQ_PTR(_add_public_24663)->length;
    }
    else {
        _14089 = 1;
    }
    {
        int _i_24667;
        _i_24667 = 1;
L2: 
        if (_i_24667 > _14089){
            goto L3; // [56] 107
        }

        /** 			include_matrix[add_public[i]][included_file] =*/
        _2 = (int)SEQ_PTR(_add_public_24663);
        _14090 = (int)*(((s1_ptr)_2)->base + _i_24667);
        _2 = (int)SEQ_PTR(_36include_matrix_15249);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _36include_matrix_15249 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_14090))
        _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_14090)->dbl));
        else
        _3 = (int)(_14090 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(_add_public_24663);
        _14093 = (int)*(((s1_ptr)_2)->base + _i_24667);
        _2 = (int)SEQ_PTR(_36include_matrix_15249);
        if (!IS_ATOM_INT(_14093)){
            _14094 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_14093)->dbl));
        }
        else{
            _14094 = (int)*(((s1_ptr)_2)->base + _14093);
        }
        _2 = (int)SEQ_PTR(_14094);
        _14095 = (int)*(((s1_ptr)_2)->base + _included_file_24652);
        _14094 = NOVALUE;
        if (IS_ATOM_INT(_14095)) {
            {unsigned long tu;
                 tu = (unsigned long)4 | (unsigned long)_14095;
                 _14096 = MAKE_UINT(tu);
            }
        }
        else {
            _14096 = binary_op(OR_BITS, 4, _14095);
        }
        _14095 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _included_file_24652);
        _1 = *(int *)_2;
        *(int *)_2 = _14096;
        if( _1 != _14096 ){
            DeRef(_1);
        }
        _14096 = NOVALUE;
        _14091 = NOVALUE;

        /** 		end for*/
        _i_24667 = _i_24667 + 1;
        goto L2; // [102] 63
L3: 
        ;
    }

    /** 		add_public = file_public_by[from_file]*/
    DeRef(_add_public_24663);
    _2 = (int)SEQ_PTR(_36file_public_by_15257);
    _add_public_24663 = (int)*(((s1_ptr)_2)->base + _from_file_24653);
    Ref(_add_public_24663);

    /** 		integer px = length( add_public ) + 1*/
    if (IS_SEQUENCE(_add_public_24663)){
            _14098 = SEQ_PTR(_add_public_24663)->length;
    }
    else {
        _14098 = 1;
    }
    _px_24681 = _14098 + 1;
    _14098 = NOVALUE;

    /** 		while px <= length( add_public ) do*/
L4: 
    if (IS_SEQUENCE(_add_public_24663)){
            _14100 = SEQ_PTR(_add_public_24663)->length;
    }
    else {
        _14100 = 1;
    }
    if (_px_24681 > _14100)
    goto L5; // [134] 338

    /** 			include_matrix[add_public[px]][included_file] =*/
    _2 = (int)SEQ_PTR(_add_public_24663);
    _14102 = (int)*(((s1_ptr)_2)->base + _px_24681);
    _2 = (int)SEQ_PTR(_36include_matrix_15249);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36include_matrix_15249 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_14102))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_14102)->dbl));
    else
    _3 = (int)(_14102 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_add_public_24663);
    _14105 = (int)*(((s1_ptr)_2)->base + _px_24681);
    _2 = (int)SEQ_PTR(_36include_matrix_15249);
    if (!IS_ATOM_INT(_14105)){
        _14106 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_14105)->dbl));
    }
    else{
        _14106 = (int)*(((s1_ptr)_2)->base + _14105);
    }
    _2 = (int)SEQ_PTR(_14106);
    _14107 = (int)*(((s1_ptr)_2)->base + _included_file_24652);
    _14106 = NOVALUE;
    if (IS_ATOM_INT(_14107)) {
        {unsigned long tu;
             tu = (unsigned long)4 | (unsigned long)_14107;
             _14108 = MAKE_UINT(tu);
        }
    }
    else {
        _14108 = binary_op(OR_BITS, 4, _14107);
    }
    _14107 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _included_file_24652);
    _1 = *(int *)_2;
    *(int *)_2 = _14108;
    if( _1 != _14108 ){
        DeRef(_1);
    }
    _14108 = NOVALUE;
    _14103 = NOVALUE;

    /** 			for i = 1 to length( file_public_by[add_public[px]] ) do*/
    _2 = (int)SEQ_PTR(_add_public_24663);
    _14109 = (int)*(((s1_ptr)_2)->base + _px_24681);
    _2 = (int)SEQ_PTR(_36file_public_by_15257);
    if (!IS_ATOM_INT(_14109)){
        _14110 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_14109)->dbl));
    }
    else{
        _14110 = (int)*(((s1_ptr)_2)->base + _14109);
    }
    if (IS_SEQUENCE(_14110)){
            _14111 = SEQ_PTR(_14110)->length;
    }
    else {
        _14111 = 1;
    }
    _14110 = NOVALUE;
    {
        int _i_24698;
        _i_24698 = 1;
L6: 
        if (_i_24698 > _14111){
            goto L7; // [190] 249
        }

        /** 				if not find( file_public[add_public[px]][i], add_public ) then*/
        _2 = (int)SEQ_PTR(_add_public_24663);
        _14112 = (int)*(((s1_ptr)_2)->base + _px_24681);
        _2 = (int)SEQ_PTR(_36file_public_15253);
        if (!IS_ATOM_INT(_14112)){
            _14113 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_14112)->dbl));
        }
        else{
            _14113 = (int)*(((s1_ptr)_2)->base + _14112);
        }
        _2 = (int)SEQ_PTR(_14113);
        _14114 = (int)*(((s1_ptr)_2)->base + _i_24698);
        _14113 = NOVALUE;
        _14115 = find_from(_14114, _add_public_24663, 1);
        _14114 = NOVALUE;
        if (_14115 != 0)
        goto L8; // [218] 242
        _14115 = NOVALUE;

        /** 					add_public &= file_public[add_public[px]][i]*/
        _2 = (int)SEQ_PTR(_add_public_24663);
        _14117 = (int)*(((s1_ptr)_2)->base + _px_24681);
        _2 = (int)SEQ_PTR(_36file_public_15253);
        if (!IS_ATOM_INT(_14117)){
            _14118 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_14117)->dbl));
        }
        else{
            _14118 = (int)*(((s1_ptr)_2)->base + _14117);
        }
        _2 = (int)SEQ_PTR(_14118);
        _14119 = (int)*(((s1_ptr)_2)->base + _i_24698);
        _14118 = NOVALUE;
        if (IS_SEQUENCE(_add_public_24663) && IS_ATOM(_14119)) {
            Ref(_14119);
            Append(&_add_public_24663, _add_public_24663, _14119);
        }
        else if (IS_ATOM(_add_public_24663) && IS_SEQUENCE(_14119)) {
        }
        else {
            Concat((object_ptr)&_add_public_24663, _add_public_24663, _14119);
        }
        _14119 = NOVALUE;
L8: 

        /** 			end for*/
        _i_24698 = _i_24698 + 1;
        goto L6; // [244] 197
L7: 
        ;
    }

    /** 			for i = 1 to length( file_include_by[add_public[px]] ) do*/
    _2 = (int)SEQ_PTR(_add_public_24663);
    _14121 = (int)*(((s1_ptr)_2)->base + _px_24681);
    _2 = (int)SEQ_PTR(_36file_include_by_15255);
    if (!IS_ATOM_INT(_14121)){
        _14122 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_14121)->dbl));
    }
    else{
        _14122 = (int)*(((s1_ptr)_2)->base + _14121);
    }
    if (IS_SEQUENCE(_14122)){
            _14123 = SEQ_PTR(_14122)->length;
    }
    else {
        _14123 = 1;
    }
    _14122 = NOVALUE;
    {
        int _i_24716;
        _i_24716 = 1;
L9: 
        if (_i_24716 > _14123){
            goto LA; // [264] 327
        }

        /** 				include_matrix[file_include_by[add_public[px]]][included_file] =*/
        _2 = (int)SEQ_PTR(_add_public_24663);
        _14124 = (int)*(((s1_ptr)_2)->base + _px_24681);
        _2 = (int)SEQ_PTR(_36file_include_by_15255);
        if (!IS_ATOM_INT(_14124)){
            _14125 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_14124)->dbl));
        }
        else{
            _14125 = (int)*(((s1_ptr)_2)->base + _14124);
        }
        _2 = (int)SEQ_PTR(_36include_matrix_15249);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _36include_matrix_15249 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_14125))
        _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_14125)->dbl));
        else
        _3 = (int)(_14125 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(_add_public_24663);
        _14128 = (int)*(((s1_ptr)_2)->base + _px_24681);
        _2 = (int)SEQ_PTR(_36file_include_by_15255);
        if (!IS_ATOM_INT(_14128)){
            _14129 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_14128)->dbl));
        }
        else{
            _14129 = (int)*(((s1_ptr)_2)->base + _14128);
        }
        _2 = (int)SEQ_PTR(_36include_matrix_15249);
        if (!IS_ATOM_INT(_14129)){
            _14130 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_14129)->dbl));
        }
        else{
            _14130 = (int)*(((s1_ptr)_2)->base + _14129);
        }
        _2 = (int)SEQ_PTR(_14130);
        _14131 = (int)*(((s1_ptr)_2)->base + _included_file_24652);
        _14130 = NOVALUE;
        if (IS_ATOM_INT(_14131)) {
            {unsigned long tu;
                 tu = (unsigned long)4 | (unsigned long)_14131;
                 _14132 = MAKE_UINT(tu);
            }
        }
        else {
            _14132 = binary_op(OR_BITS, 4, _14131);
        }
        _14131 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _included_file_24652);
        _1 = *(int *)_2;
        *(int *)_2 = _14132;
        if( _1 != _14132 ){
            DeRef(_1);
        }
        _14132 = NOVALUE;
        _14126 = NOVALUE;

        /** 			end for*/
        _i_24716 = _i_24716 + 1;
        goto L9; // [322] 271
LA: 
        ;
    }

    /** 			px += 1*/
    _px_24681 = _px_24681 + 1;

    /** 		end while*/
    goto L4; // [335] 131
L5: 
L1: 
    DeRef(_add_public_24663);
    _add_public_24663 = NOVALUE;

    /** 	if indirect_include[from_file][included_file] then*/
    _2 = (int)SEQ_PTR(_36indirect_include_15251);
    _14134 = (int)*(((s1_ptr)_2)->base + _from_file_24653);
    _2 = (int)SEQ_PTR(_14134);
    _14135 = (int)*(((s1_ptr)_2)->base + _included_file_24652);
    _14134 = NOVALUE;
    if (_14135 == 0) {
        _14135 = NOVALUE;
        goto LB; // [353] 545
    }
    else {
        if (!IS_ATOM_INT(_14135) && DBL_PTR(_14135)->dbl == 0.0){
            _14135 = NOVALUE;
            goto LB; // [353] 545
        }
        _14135 = NOVALUE;
    }
    _14135 = NOVALUE;

    /** 		sequence indirect = file_include_by[from_file]*/
    DeRef(_indirect_24740);
    _2 = (int)SEQ_PTR(_36file_include_by_15255);
    _indirect_24740 = (int)*(((s1_ptr)_2)->base + _from_file_24653);
    Ref(_indirect_24740);

    /** 		sequence mask = include_matrix[included_file] != 0*/
    _2 = (int)SEQ_PTR(_36include_matrix_15249);
    _14137 = (int)*(((s1_ptr)_2)->base + _included_file_24652);
    DeRef(_mask_24743);
    if (IS_ATOM_INT(_14137)) {
        _mask_24743 = (_14137 != 0);
    }
    else {
        _mask_24743 = binary_op(NOTEQ, _14137, 0);
    }
    _14137 = NOVALUE;

    /** 		include_matrix[from_file] = or_bits( include_matrix[from_file], mask )*/
    _2 = (int)SEQ_PTR(_36include_matrix_15249);
    _14139 = (int)*(((s1_ptr)_2)->base + _from_file_24653);
    _14140 = binary_op(OR_BITS, _14139, _mask_24743);
    _14139 = NOVALUE;
    _2 = (int)SEQ_PTR(_36include_matrix_15249);
    _2 = (int)(((s1_ptr)_2)->base + _from_file_24653);
    _1 = *(int *)_2;
    *(int *)_2 = _14140;
    if( _1 != _14140 ){
        DeRef(_1);
    }
    _14140 = NOVALUE;

    /** 		mask = include_matrix[from_file] != 0*/
    _2 = (int)SEQ_PTR(_36include_matrix_15249);
    _14141 = (int)*(((s1_ptr)_2)->base + _from_file_24653);
    DeRefDS(_mask_24743);
    if (IS_ATOM_INT(_14141)) {
        _mask_24743 = (_14141 != 0);
    }
    else {
        _mask_24743 = binary_op(NOTEQ, _14141, 0);
    }
    _14141 = NOVALUE;

    /** 		integer ix = 1*/
    _ix_24754 = 1;

    /** 		while ix <= length(indirect) do*/
LC: 
    if (IS_SEQUENCE(_indirect_24740)){
            _14143 = SEQ_PTR(_indirect_24740)->length;
    }
    else {
        _14143 = 1;
    }
    if (_ix_24754 > _14143)
    goto LD; // [425] 544

    /** 			integer indirect_file = indirect[ix]*/
    _2 = (int)SEQ_PTR(_indirect_24740);
    _indirect_file_24758 = (int)*(((s1_ptr)_2)->base + _ix_24754);
    if (!IS_ATOM_INT(_indirect_file_24758))
    _indirect_file_24758 = (long)DBL_PTR(_indirect_file_24758)->dbl;

    /** 			if indirect_include[indirect_file][included_file] then*/
    _2 = (int)SEQ_PTR(_36indirect_include_15251);
    _14146 = (int)*(((s1_ptr)_2)->base + _indirect_file_24758);
    _2 = (int)SEQ_PTR(_14146);
    _14147 = (int)*(((s1_ptr)_2)->base + _included_file_24652);
    _14146 = NOVALUE;
    if (_14147 == 0) {
        _14147 = NOVALUE;
        goto LE; // [447] 531
    }
    else {
        if (!IS_ATOM_INT(_14147) && DBL_PTR(_14147)->dbl == 0.0){
            _14147 = NOVALUE;
            goto LE; // [447] 531
        }
        _14147 = NOVALUE;
    }
    _14147 = NOVALUE;

    /** 				include_matrix[indirect_file] =*/
    _2 = (int)SEQ_PTR(_36include_matrix_15249);
    _14148 = (int)*(((s1_ptr)_2)->base + _indirect_file_24758);
    _14149 = binary_op(OR_BITS, _mask_24743, _14148);
    _14148 = NOVALUE;
    _2 = (int)SEQ_PTR(_36include_matrix_15249);
    _2 = (int)(((s1_ptr)_2)->base + _indirect_file_24758);
    _1 = *(int *)_2;
    *(int *)_2 = _14149;
    if( _1 != _14149 ){
        DeRef(_1);
    }
    _14149 = NOVALUE;

    /** 				for i = 1 to length( file_include_by[indirect_file] ) do*/
    _2 = (int)SEQ_PTR(_36file_include_by_15255);
    _14150 = (int)*(((s1_ptr)_2)->base + _indirect_file_24758);
    if (IS_SEQUENCE(_14150)){
            _14151 = SEQ_PTR(_14150)->length;
    }
    else {
        _14151 = 1;
    }
    _14150 = NOVALUE;
    {
        int _i_24769;
        _i_24769 = 1;
LF: 
        if (_i_24769 > _14151){
            goto L10; // [479] 530
        }

        /** 					if not find( file_include_by[indirect_file][i], indirect ) then*/
        _2 = (int)SEQ_PTR(_36file_include_by_15255);
        _14152 = (int)*(((s1_ptr)_2)->base + _indirect_file_24758);
        _2 = (int)SEQ_PTR(_14152);
        _14153 = (int)*(((s1_ptr)_2)->base + _i_24769);
        _14152 = NOVALUE;
        _14154 = find_from(_14153, _indirect_24740, 1);
        _14153 = NOVALUE;
        if (_14154 != 0)
        goto L11; // [503] 523
        _14154 = NOVALUE;

        /** 						indirect &= file_include_by[indirect_file][i]*/
        _2 = (int)SEQ_PTR(_36file_include_by_15255);
        _14156 = (int)*(((s1_ptr)_2)->base + _indirect_file_24758);
        _2 = (int)SEQ_PTR(_14156);
        _14157 = (int)*(((s1_ptr)_2)->base + _i_24769);
        _14156 = NOVALUE;
        if (IS_SEQUENCE(_indirect_24740) && IS_ATOM(_14157)) {
            Ref(_14157);
            Append(&_indirect_24740, _indirect_24740, _14157);
        }
        else if (IS_ATOM(_indirect_24740) && IS_SEQUENCE(_14157)) {
        }
        else {
            Concat((object_ptr)&_indirect_24740, _indirect_24740, _14157);
        }
        _14157 = NOVALUE;
L11: 

        /** 				end for*/
        _i_24769 = _i_24769 + 1;
        goto LF; // [525] 486
L10: 
        ;
    }
LE: 

    /** 			ix += 1*/
    _ix_24754 = _ix_24754 + 1;

    /** 		end while*/
    goto LC; // [541] 422
LD: 
LB: 
    DeRef(_indirect_24740);
    _indirect_24740 = NOVALUE;
    DeRef(_mask_24743);
    _mask_24743 = NOVALUE;

    /** 	public_include = FALSE*/
    _61public_include_23899 = _13FALSE_434;

    /** end procedure*/
    _14090 = NOVALUE;
    _14102 = NOVALUE;
    _14093 = NOVALUE;
    _14109 = NOVALUE;
    _14105 = NOVALUE;
    _14110 = NOVALUE;
    _14112 = NOVALUE;
    _14117 = NOVALUE;
    _14121 = NOVALUE;
    _14122 = NOVALUE;
    _14124 = NOVALUE;
    _14125 = NOVALUE;
    _14150 = NOVALUE;
    _14128 = NOVALUE;
    _14129 = NOVALUE;
    return;
    ;
}


void _61add_include_by(int _by_file_24787, int _included_file_24788, int _is_public_24789)
{
    int _14204 = NOVALUE;
    int _14203 = NOVALUE;
    int _14202 = NOVALUE;
    int _14200 = NOVALUE;
    int _14199 = NOVALUE;
    int _14198 = NOVALUE;
    int _14197 = NOVALUE;
    int _14195 = NOVALUE;
    int _14194 = NOVALUE;
    int _14193 = NOVALUE;
    int _14192 = NOVALUE;
    int _14191 = NOVALUE;
    int _14190 = NOVALUE;
    int _14189 = NOVALUE;
    int _14188 = NOVALUE;
    int _14186 = NOVALUE;
    int _14185 = NOVALUE;
    int _14184 = NOVALUE;
    int _14183 = NOVALUE;
    int _14181 = NOVALUE;
    int _14180 = NOVALUE;
    int _14179 = NOVALUE;
    int _14178 = NOVALUE;
    int _14176 = NOVALUE;
    int _14175 = NOVALUE;
    int _14174 = NOVALUE;
    int _14173 = NOVALUE;
    int _14171 = NOVALUE;
    int _14170 = NOVALUE;
    int _14169 = NOVALUE;
    int _14168 = NOVALUE;
    int _14167 = NOVALUE;
    int _14165 = NOVALUE;
    int _14164 = NOVALUE;
    int _14163 = NOVALUE;
    int _14162 = NOVALUE;
    int _14160 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	include_matrix[by_file][included_file] = or_bits( DIRECT_INCLUDE, include_matrix[by_file][included_file] )*/
    _2 = (int)SEQ_PTR(_36include_matrix_15249);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36include_matrix_15249 = MAKE_SEQ(_2);
    }
    _3 = (int)(_by_file_24787 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_36include_matrix_15249);
    _14162 = (int)*(((s1_ptr)_2)->base + _by_file_24787);
    _2 = (int)SEQ_PTR(_14162);
    _14163 = (int)*(((s1_ptr)_2)->base + _included_file_24788);
    _14162 = NOVALUE;
    if (IS_ATOM_INT(_14163)) {
        {unsigned long tu;
             tu = (unsigned long)2 | (unsigned long)_14163;
             _14164 = MAKE_UINT(tu);
        }
    }
    else {
        _14164 = binary_op(OR_BITS, 2, _14163);
    }
    _14163 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _included_file_24788);
    _1 = *(int *)_2;
    *(int *)_2 = _14164;
    if( _1 != _14164 ){
        DeRef(_1);
    }
    _14164 = NOVALUE;
    _14160 = NOVALUE;

    /** 	if is_public then*/
    if (_is_public_24789 == 0)
    {
        goto L1; // [38] 71
    }
    else{
    }

    /** 		include_matrix[by_file][included_file] = or_bits( PUBLIC_INCLUDE, include_matrix[by_file][included_file] )*/
    _2 = (int)SEQ_PTR(_36include_matrix_15249);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36include_matrix_15249 = MAKE_SEQ(_2);
    }
    _3 = (int)(_by_file_24787 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_36include_matrix_15249);
    _14167 = (int)*(((s1_ptr)_2)->base + _by_file_24787);
    _2 = (int)SEQ_PTR(_14167);
    _14168 = (int)*(((s1_ptr)_2)->base + _included_file_24788);
    _14167 = NOVALUE;
    if (IS_ATOM_INT(_14168)) {
        {unsigned long tu;
             tu = (unsigned long)4 | (unsigned long)_14168;
             _14169 = MAKE_UINT(tu);
        }
    }
    else {
        _14169 = binary_op(OR_BITS, 4, _14168);
    }
    _14168 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _included_file_24788);
    _1 = *(int *)_2;
    *(int *)_2 = _14169;
    if( _1 != _14169 ){
        DeRef(_1);
    }
    _14169 = NOVALUE;
    _14165 = NOVALUE;
L1: 

    /** 	if not find( by_file, file_include_by[included_file] ) then*/
    _2 = (int)SEQ_PTR(_36file_include_by_15255);
    _14170 = (int)*(((s1_ptr)_2)->base + _included_file_24788);
    _14171 = find_from(_by_file_24787, _14170, 1);
    _14170 = NOVALUE;
    if (_14171 != 0)
    goto L2; // [84] 104
    _14171 = NOVALUE;

    /** 		file_include_by[included_file] &= by_file*/
    _2 = (int)SEQ_PTR(_36file_include_by_15255);
    _14173 = (int)*(((s1_ptr)_2)->base + _included_file_24788);
    if (IS_SEQUENCE(_14173) && IS_ATOM(_by_file_24787)) {
        Append(&_14174, _14173, _by_file_24787);
    }
    else if (IS_ATOM(_14173) && IS_SEQUENCE(_by_file_24787)) {
    }
    else {
        Concat((object_ptr)&_14174, _14173, _by_file_24787);
        _14173 = NOVALUE;
    }
    _14173 = NOVALUE;
    _2 = (int)SEQ_PTR(_36file_include_by_15255);
    _2 = (int)(((s1_ptr)_2)->base + _included_file_24788);
    _1 = *(int *)_2;
    *(int *)_2 = _14174;
    if( _1 != _14174 ){
        DeRef(_1);
    }
    _14174 = NOVALUE;
L2: 

    /** 	if not find( included_file, file_include[by_file] ) then*/
    _2 = (int)SEQ_PTR(_36file_include_15247);
    _14175 = (int)*(((s1_ptr)_2)->base + _by_file_24787);
    _14176 = find_from(_included_file_24788, _14175, 1);
    _14175 = NOVALUE;
    if (_14176 != 0)
    goto L3; // [117] 137
    _14176 = NOVALUE;

    /** 		file_include[by_file] &= included_file*/
    _2 = (int)SEQ_PTR(_36file_include_15247);
    _14178 = (int)*(((s1_ptr)_2)->base + _by_file_24787);
    if (IS_SEQUENCE(_14178) && IS_ATOM(_included_file_24788)) {
        Append(&_14179, _14178, _included_file_24788);
    }
    else if (IS_ATOM(_14178) && IS_SEQUENCE(_included_file_24788)) {
    }
    else {
        Concat((object_ptr)&_14179, _14178, _included_file_24788);
        _14178 = NOVALUE;
    }
    _14178 = NOVALUE;
    _2 = (int)SEQ_PTR(_36file_include_15247);
    _2 = (int)(((s1_ptr)_2)->base + _by_file_24787);
    _1 = *(int *)_2;
    *(int *)_2 = _14179;
    if( _1 != _14179 ){
        DeRef(_1);
    }
    _14179 = NOVALUE;
L3: 

    /** 	if is_public then*/
    if (_is_public_24789 == 0)
    {
        goto L4; // [139] 209
    }
    else{
    }

    /** 		if not find( by_file, file_public_by[included_file] ) then*/
    _2 = (int)SEQ_PTR(_36file_public_by_15257);
    _14180 = (int)*(((s1_ptr)_2)->base + _included_file_24788);
    _14181 = find_from(_by_file_24787, _14180, 1);
    _14180 = NOVALUE;
    if (_14181 != 0)
    goto L5; // [155] 175
    _14181 = NOVALUE;

    /** 			file_public_by[included_file] &= by_file*/
    _2 = (int)SEQ_PTR(_36file_public_by_15257);
    _14183 = (int)*(((s1_ptr)_2)->base + _included_file_24788);
    if (IS_SEQUENCE(_14183) && IS_ATOM(_by_file_24787)) {
        Append(&_14184, _14183, _by_file_24787);
    }
    else if (IS_ATOM(_14183) && IS_SEQUENCE(_by_file_24787)) {
    }
    else {
        Concat((object_ptr)&_14184, _14183, _by_file_24787);
        _14183 = NOVALUE;
    }
    _14183 = NOVALUE;
    _2 = (int)SEQ_PTR(_36file_public_by_15257);
    _2 = (int)(((s1_ptr)_2)->base + _included_file_24788);
    _1 = *(int *)_2;
    *(int *)_2 = _14184;
    if( _1 != _14184 ){
        DeRef(_1);
    }
    _14184 = NOVALUE;
L5: 

    /** 		if not find( included_file, file_public[by_file] ) then*/
    _2 = (int)SEQ_PTR(_36file_public_15253);
    _14185 = (int)*(((s1_ptr)_2)->base + _by_file_24787);
    _14186 = find_from(_included_file_24788, _14185, 1);
    _14185 = NOVALUE;
    if (_14186 != 0)
    goto L6; // [188] 208
    _14186 = NOVALUE;

    /** 			file_public[by_file] &= included_file*/
    _2 = (int)SEQ_PTR(_36file_public_15253);
    _14188 = (int)*(((s1_ptr)_2)->base + _by_file_24787);
    if (IS_SEQUENCE(_14188) && IS_ATOM(_included_file_24788)) {
        Append(&_14189, _14188, _included_file_24788);
    }
    else if (IS_ATOM(_14188) && IS_SEQUENCE(_included_file_24788)) {
    }
    else {
        Concat((object_ptr)&_14189, _14188, _included_file_24788);
        _14188 = NOVALUE;
    }
    _14188 = NOVALUE;
    _2 = (int)SEQ_PTR(_36file_public_15253);
    _2 = (int)(((s1_ptr)_2)->base + _by_file_24787);
    _1 = *(int *)_2;
    *(int *)_2 = _14189;
    if( _1 != _14189 ){
        DeRef(_1);
    }
    _14189 = NOVALUE;
L6: 
L4: 

    /** 	for propagate = 1 to length( include_matrix[included_file] ) do*/
    _2 = (int)SEQ_PTR(_36include_matrix_15249);
    _14190 = (int)*(((s1_ptr)_2)->base + _included_file_24788);
    if (IS_SEQUENCE(_14190)){
            _14191 = SEQ_PTR(_14190)->length;
    }
    else {
        _14191 = 1;
    }
    _14190 = NOVALUE;
    {
        int _propagate_24841;
        _propagate_24841 = 1;
L7: 
        if (_propagate_24841 > _14191){
            goto L8; // [220] 320
        }

        /** 		if and_bits( PUBLIC_INCLUDE, include_matrix[included_file][propagate] ) then*/
        _2 = (int)SEQ_PTR(_36include_matrix_15249);
        _14192 = (int)*(((s1_ptr)_2)->base + _included_file_24788);
        _2 = (int)SEQ_PTR(_14192);
        _14193 = (int)*(((s1_ptr)_2)->base + _propagate_24841);
        _14192 = NOVALUE;
        if (IS_ATOM_INT(_14193)) {
            {unsigned long tu;
                 tu = (unsigned long)4 & (unsigned long)_14193;
                 _14194 = MAKE_UINT(tu);
            }
        }
        else {
            _14194 = binary_op(AND_BITS, 4, _14193);
        }
        _14193 = NOVALUE;
        if (_14194 == 0) {
            DeRef(_14194);
            _14194 = NOVALUE;
            goto L9; // [245] 313
        }
        else {
            if (!IS_ATOM_INT(_14194) && DBL_PTR(_14194)->dbl == 0.0){
                DeRef(_14194);
                _14194 = NOVALUE;
                goto L9; // [245] 313
            }
            DeRef(_14194);
            _14194 = NOVALUE;
        }
        DeRef(_14194);
        _14194 = NOVALUE;

        /** 			include_matrix[by_file][propagate] = or_bits( DIRECT_INCLUDE, include_matrix[by_file][propagate] )*/
        _2 = (int)SEQ_PTR(_36include_matrix_15249);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _36include_matrix_15249 = MAKE_SEQ(_2);
        }
        _3 = (int)(_by_file_24787 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(_36include_matrix_15249);
        _14197 = (int)*(((s1_ptr)_2)->base + _by_file_24787);
        _2 = (int)SEQ_PTR(_14197);
        _14198 = (int)*(((s1_ptr)_2)->base + _propagate_24841);
        _14197 = NOVALUE;
        if (IS_ATOM_INT(_14198)) {
            {unsigned long tu;
                 tu = (unsigned long)2 | (unsigned long)_14198;
                 _14199 = MAKE_UINT(tu);
            }
        }
        else {
            _14199 = binary_op(OR_BITS, 2, _14198);
        }
        _14198 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _propagate_24841);
        _1 = *(int *)_2;
        *(int *)_2 = _14199;
        if( _1 != _14199 ){
            DeRef(_1);
        }
        _14199 = NOVALUE;
        _14195 = NOVALUE;

        /** 			if is_public then*/
        if (_is_public_24789 == 0)
        {
            goto LA; // [279] 312
        }
        else{
        }

        /** 				include_matrix[by_file][propagate] = or_bits( PUBLIC_INCLUDE, include_matrix[by_file][propagate] )*/
        _2 = (int)SEQ_PTR(_36include_matrix_15249);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _36include_matrix_15249 = MAKE_SEQ(_2);
        }
        _3 = (int)(_by_file_24787 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(_36include_matrix_15249);
        _14202 = (int)*(((s1_ptr)_2)->base + _by_file_24787);
        _2 = (int)SEQ_PTR(_14202);
        _14203 = (int)*(((s1_ptr)_2)->base + _propagate_24841);
        _14202 = NOVALUE;
        if (IS_ATOM_INT(_14203)) {
            {unsigned long tu;
                 tu = (unsigned long)4 | (unsigned long)_14203;
                 _14204 = MAKE_UINT(tu);
            }
        }
        else {
            _14204 = binary_op(OR_BITS, 4, _14203);
        }
        _14203 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _propagate_24841);
        _1 = *(int *)_2;
        *(int *)_2 = _14204;
        if( _1 != _14204 ){
            DeRef(_1);
        }
        _14204 = NOVALUE;
        _14200 = NOVALUE;
LA: 
L9: 

        /** 	end for*/
        _propagate_24841 = _propagate_24841 + 1;
        goto L7; // [315] 227
L8: 
        ;
    }

    /** end procedure*/
    _14190 = NOVALUE;
    return;
    ;
}


void _61IncludePush()
{
    int _new_file_handle_24870 = NOVALUE;
    int _old_file_no_24871 = NOVALUE;
    int _new_hash_24872 = NOVALUE;
    int _idx_24873 = NOVALUE;
    int _14291 = NOVALUE;
    int _14288 = NOVALUE;
    int _14286 = NOVALUE;
    int _14285 = NOVALUE;
    int _14284 = NOVALUE;
    int _14282 = NOVALUE;
    int _14281 = NOVALUE;
    int _14275 = NOVALUE;
    int _14274 = NOVALUE;
    int _14273 = NOVALUE;
    int _14272 = NOVALUE;
    int _14271 = NOVALUE;
    int _14270 = NOVALUE;
    int _14269 = NOVALUE;
    int _14266 = NOVALUE;
    int _14264 = NOVALUE;
    int _14262 = NOVALUE;
    int _14261 = NOVALUE;
    int _14260 = NOVALUE;
    int _14258 = NOVALUE;
    int _14257 = NOVALUE;
    int _14255 = NOVALUE;
    int _14254 = NOVALUE;
    int _14252 = NOVALUE;
    int _14251 = NOVALUE;
    int _14250 = NOVALUE;
    int _14249 = NOVALUE;
    int _14248 = NOVALUE;
    int _14247 = NOVALUE;
    int _14246 = NOVALUE;
    int _14242 = NOVALUE;
    int _14240 = NOVALUE;
    int _14239 = NOVALUE;
    int _14238 = NOVALUE;
    int _14237 = NOVALUE;
    int _14236 = NOVALUE;
    int _14235 = NOVALUE;
    int _14234 = NOVALUE;
    int _14233 = NOVALUE;
    int _14232 = NOVALUE;
    int _14230 = NOVALUE;
    int _14229 = NOVALUE;
    int _14228 = NOVALUE;
    int _14226 = NOVALUE;
    int _14225 = NOVALUE;
    int _14224 = NOVALUE;
    int _14223 = NOVALUE;
    int _14221 = NOVALUE;
    int _14220 = NOVALUE;
    int _14219 = NOVALUE;
    int _14218 = NOVALUE;
    int _14217 = NOVALUE;
    int _14215 = NOVALUE;
    int _14214 = NOVALUE;
    int _14213 = NOVALUE;
    int _14212 = NOVALUE;
    int _14210 = NOVALUE;
    int _14206 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	start_include = FALSE*/
    _61start_include_23896 = _13FALSE_434;

    /** 	new_file_handle = path_open() -- sets new_include_name to full path*/
    _new_file_handle_24870 = _61path_open();
    if (!IS_ATOM_INT(_new_file_handle_24870)) {
        _1 = (long)(DBL_PTR(_new_file_handle_24870)->dbl);
        DeRefDS(_new_file_handle_24870);
        _new_file_handle_24870 = _1;
    }

    /** 	new_hash = hash(canonical_path(new_include_name,,CORRECT), stdhash:HSIEH32)*/
    RefDS(_35new_include_name_16366);
    _14206 = _17canonical_path(_35new_include_name_16366, 0, 2);
    DeRef(_new_hash_24872);
    _new_hash_24872 = calc_hash(_14206, -5);
    DeRef(_14206);
    _14206 = NOVALUE;

    /** 	idx = find(new_hash, known_files_hash)*/
    _idx_24873 = find_from(_new_hash_24872, _36known_files_hash_15244, 1);

    /** 	if idx then*/
    if (_idx_24873 == 0)
    {
        goto L1; // [42] 335
    }
    else{
    }

    /** 		if new_include_space != 0 then*/
    if (_61new_include_space_23894 == 0)
    goto L2; // [49] 71

    /** 			SymTab[new_include_space][S_OBJ] = idx -- but note any namespace*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_61new_include_space_23894 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _idx_24873;
    DeRef(_1);
    _14210 = NOVALUE;
L2: 

    /** 		close(new_file_handle)*/
    EClose(_new_file_handle_24870);

    /** 		if find( -idx, file_include[current_file_no] ) then*/
    if ((unsigned long)_idx_24873 == 0xC0000000)
    _14212 = (int)NewDouble((double)-0xC0000000);
    else
    _14212 = - _idx_24873;
    _2 = (int)SEQ_PTR(_36file_include_15247);
    _14213 = (int)*(((s1_ptr)_2)->base + _35current_file_no_16244);
    _14214 = find_from(_14212, _14213, 1);
    DeRef(_14212);
    _14212 = NOVALUE;
    _14213 = NOVALUE;
    if (_14214 == 0)
    {
        _14214 = NOVALUE;
        goto L3; // [93] 130
    }
    else{
        _14214 = NOVALUE;
    }

    /** 			file_include[current_file_no][ find( -idx, file_include[current_file_no] ) ] = idx*/
    _2 = (int)SEQ_PTR(_36file_include_15247);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36file_include_15247 = MAKE_SEQ(_2);
    }
    _3 = (int)(_35current_file_no_16244 + ((s1_ptr)_2)->base);
    if ((unsigned long)_idx_24873 == 0xC0000000)
    _14217 = (int)NewDouble((double)-0xC0000000);
    else
    _14217 = - _idx_24873;
    _2 = (int)SEQ_PTR(_36file_include_15247);
    _14218 = (int)*(((s1_ptr)_2)->base + _35current_file_no_16244);
    _14219 = find_from(_14217, _14218, 1);
    DeRef(_14217);
    _14217 = NOVALUE;
    _14218 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _14219);
    _1 = *(int *)_2;
    *(int *)_2 = _idx_24873;
    DeRef(_1);
    _14215 = NOVALUE;
    goto L4; // [127] 228
L3: 

    /** 		elsif not find( idx, file_include[current_file_no] ) then*/
    _2 = (int)SEQ_PTR(_36file_include_15247);
    _14220 = (int)*(((s1_ptr)_2)->base + _35current_file_no_16244);
    _14221 = find_from(_idx_24873, _14220, 1);
    _14220 = NOVALUE;
    if (_14221 != 0)
    goto L5; // [145] 227
    _14221 = NOVALUE;

    /** 			file_include[current_file_no] &= idx*/
    _2 = (int)SEQ_PTR(_36file_include_15247);
    _14223 = (int)*(((s1_ptr)_2)->base + _35current_file_no_16244);
    if (IS_SEQUENCE(_14223) && IS_ATOM(_idx_24873)) {
        Append(&_14224, _14223, _idx_24873);
    }
    else if (IS_ATOM(_14223) && IS_SEQUENCE(_idx_24873)) {
    }
    else {
        Concat((object_ptr)&_14224, _14223, _idx_24873);
        _14223 = NOVALUE;
    }
    _14223 = NOVALUE;
    _2 = (int)SEQ_PTR(_36file_include_15247);
    _2 = (int)(((s1_ptr)_2)->base + _35current_file_no_16244);
    _1 = *(int *)_2;
    *(int *)_2 = _14224;
    if( _1 != _14224 ){
        DeRef(_1);
    }
    _14224 = NOVALUE;

    /** 			add_exports( idx, current_file_no )*/
    _61add_exports(_idx_24873, _35current_file_no_16244);

    /** 			if public_include then*/
    if (_61public_include_23899 == 0)
    {
        goto L6; // [178] 226
    }
    else{
    }

    /** 				if not find( idx, file_public[current_file_no] ) then*/
    _2 = (int)SEQ_PTR(_36file_public_15253);
    _14225 = (int)*(((s1_ptr)_2)->base + _35current_file_no_16244);
    _14226 = find_from(_idx_24873, _14225, 1);
    _14225 = NOVALUE;
    if (_14226 != 0)
    goto L7; // [196] 225
    _14226 = NOVALUE;

    /** 					file_public[current_file_no] &= idx*/
    _2 = (int)SEQ_PTR(_36file_public_15253);
    _14228 = (int)*(((s1_ptr)_2)->base + _35current_file_no_16244);
    if (IS_SEQUENCE(_14228) && IS_ATOM(_idx_24873)) {
        Append(&_14229, _14228, _idx_24873);
    }
    else if (IS_ATOM(_14228) && IS_SEQUENCE(_idx_24873)) {
    }
    else {
        Concat((object_ptr)&_14229, _14228, _idx_24873);
        _14228 = NOVALUE;
    }
    _14228 = NOVALUE;
    _2 = (int)SEQ_PTR(_36file_public_15253);
    _2 = (int)(((s1_ptr)_2)->base + _35current_file_no_16244);
    _1 = *(int *)_2;
    *(int *)_2 = _14229;
    if( _1 != _14229 ){
        DeRef(_1);
    }
    _14229 = NOVALUE;

    /** 					patch_exports( current_file_no )*/
    _61patch_exports(_35current_file_no_16244);
L7: 
L6: 
L5: 
L4: 

    /** 		indirect_include[current_file_no][idx] = OpIndirectInclude*/
    _2 = (int)SEQ_PTR(_36indirect_include_15251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36indirect_include_15251 = MAKE_SEQ(_2);
    }
    _3 = (int)(_35current_file_no_16244 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _idx_24873);
    _1 = *(int *)_2;
    *(int *)_2 = _35OpIndirectInclude_16319;
    DeRef(_1);
    _14230 = NOVALUE;

    /** 		add_include_by( current_file_no, idx, public_include )*/
    _61add_include_by(_35current_file_no_16244, _idx_24873, _61public_include_23899);

    /** 		update_include_matrix( idx, current_file_no )*/
    _61update_include_matrix(_idx_24873, _35current_file_no_16244);

    /** 		public_include = FALSE*/
    _61public_include_23899 = _13FALSE_434;

    /** 		read_line() -- we can't return without reading a line first*/
    _61read_line();

    /** 		if not find( idx, file_include_depend[current_file_no] ) and not finished_files[idx] then*/
    _2 = (int)SEQ_PTR(_36file_include_depend_15246);
    _14232 = (int)*(((s1_ptr)_2)->base + _35current_file_no_16244);
    _14233 = find_from(_idx_24873, _14232, 1);
    _14232 = NOVALUE;
    _14234 = (_14233 == 0);
    _14233 = NOVALUE;
    if (_14234 == 0) {
        goto L8; // [293] 329
    }
    _2 = (int)SEQ_PTR(_36finished_files_15245);
    _14236 = (int)*(((s1_ptr)_2)->base + _idx_24873);
    _14237 = (_14236 == 0);
    _14236 = NOVALUE;
    if (_14237 == 0)
    {
        DeRef(_14237);
        _14237 = NOVALUE;
        goto L8; // [307] 329
    }
    else{
        DeRef(_14237);
        _14237 = NOVALUE;
    }

    /** 			file_include_depend[current_file_no] &= idx*/
    _2 = (int)SEQ_PTR(_36file_include_depend_15246);
    _14238 = (int)*(((s1_ptr)_2)->base + _35current_file_no_16244);
    if (IS_SEQUENCE(_14238) && IS_ATOM(_idx_24873)) {
        Append(&_14239, _14238, _idx_24873);
    }
    else if (IS_ATOM(_14238) && IS_SEQUENCE(_idx_24873)) {
    }
    else {
        Concat((object_ptr)&_14239, _14238, _idx_24873);
        _14238 = NOVALUE;
    }
    _14238 = NOVALUE;
    _2 = (int)SEQ_PTR(_36file_include_depend_15246);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36file_include_depend_15246 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _35current_file_no_16244);
    _1 = *(int *)_2;
    *(int *)_2 = _14239;
    if( _1 != _14239 ){
        DeRef(_1);
    }
    _14239 = NOVALUE;
L8: 

    /** 		return -- ignore it*/
    DeRef(_new_hash_24872);
    DeRef(_14234);
    _14234 = NOVALUE;
    return;
L1: 

    /** 	if length(IncludeStk) >= INCLUDE_LIMIT then*/
    if (IS_SEQUENCE(_61IncludeStk_23905)){
            _14240 = SEQ_PTR(_61IncludeStk_23905)->length;
    }
    else {
        _14240 = 1;
    }
    if (_14240 < 30)
    goto L9; // [342] 354

    /** 		CompileErr(104)*/
    RefDS(_22023);
    _44CompileErr(104, _22023, 0);
L9: 

    /** 	IncludeStk = append(IncludeStk,*/
    _1 = NewS1(22);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _35current_file_no_16244;
    *((int *)(_2+8)) = _35line_number_16245;
    *((int *)(_2+12)) = _35src_file_16365;
    *((int *)(_2+16)) = _35file_start_sym_16250;
    *((int *)(_2+20)) = _35OpWarning_16311;
    *((int *)(_2+24)) = _35OpTrace_16313;
    *((int *)(_2+28)) = _35OpTypeCheck_16314;
    *((int *)(_2+32)) = _35OpProfileTime_16316;
    *((int *)(_2+36)) = _35OpProfileStatement_16315;
    RefDS(_35OpDefines_16317);
    *((int *)(_2+40)) = _35OpDefines_16317;
    *((int *)(_2+44)) = _35prev_OpWarning_16312;
    *((int *)(_2+48)) = _35OpInline_16318;
    *((int *)(_2+52)) = _35OpIndirectInclude_16319;
    *((int *)(_2+56)) = _35putback_fwd_line_number_16247;
    Ref(_44putback_ForwardLine_48520);
    *((int *)(_2+60)) = _44putback_ForwardLine_48520;
    *((int *)(_2+64)) = _44putback_forward_bp_48524;
    *((int *)(_2+68)) = _35last_fwd_line_number_16248;
    Ref(_44last_ForwardLine_48521);
    *((int *)(_2+72)) = _44last_ForwardLine_48521;
    *((int *)(_2+76)) = _44last_forward_bp_48525;
    Ref(_44ThisLine_48518);
    *((int *)(_2+80)) = _44ThisLine_48518;
    *((int *)(_2+84)) = _35fwd_line_number_16246;
    *((int *)(_2+88)) = _44forward_bp_48523;
    _14242 = MAKE_SEQ(_1);
    RefDS(_14242);
    Append(&_61IncludeStk_23905, _61IncludeStk_23905, _14242);
    DeRefDS(_14242);
    _14242 = NOVALUE;

    /** 	file_include = append( file_include, {} )*/
    RefDS(_5);
    Append(&_36file_include_15247, _36file_include_15247, _5);

    /** 	file_include_by = append( file_include_by, {} )*/
    RefDS(_5);
    Append(&_36file_include_by_15255, _36file_include_by_15255, _5);

    /** 	for i = 1 to length( include_matrix) do*/
    if (IS_SEQUENCE(_36include_matrix_15249)){
            _14246 = SEQ_PTR(_36include_matrix_15249)->length;
    }
    else {
        _14246 = 1;
    }
    {
        int _i_24985;
        _i_24985 = 1;
LA: 
        if (_i_24985 > _14246){
            goto LB; // [458] 504
        }

        /** 		include_matrix[i]   &= 0*/
        _2 = (int)SEQ_PTR(_36include_matrix_15249);
        _14247 = (int)*(((s1_ptr)_2)->base + _i_24985);
        if (IS_SEQUENCE(_14247) && IS_ATOM(0)) {
            Append(&_14248, _14247, 0);
        }
        else if (IS_ATOM(_14247) && IS_SEQUENCE(0)) {
        }
        else {
            Concat((object_ptr)&_14248, _14247, 0);
            _14247 = NOVALUE;
        }
        _14247 = NOVALUE;
        _2 = (int)SEQ_PTR(_36include_matrix_15249);
        _2 = (int)(((s1_ptr)_2)->base + _i_24985);
        _1 = *(int *)_2;
        *(int *)_2 = _14248;
        if( _1 != _14248 ){
            DeRef(_1);
        }
        _14248 = NOVALUE;

        /** 		indirect_include[i] &= 0*/
        _2 = (int)SEQ_PTR(_36indirect_include_15251);
        _14249 = (int)*(((s1_ptr)_2)->base + _i_24985);
        if (IS_SEQUENCE(_14249) && IS_ATOM(0)) {
            Append(&_14250, _14249, 0);
        }
        else if (IS_ATOM(_14249) && IS_SEQUENCE(0)) {
        }
        else {
            Concat((object_ptr)&_14250, _14249, 0);
            _14249 = NOVALUE;
        }
        _14249 = NOVALUE;
        _2 = (int)SEQ_PTR(_36indirect_include_15251);
        _2 = (int)(((s1_ptr)_2)->base + _i_24985);
        _1 = *(int *)_2;
        *(int *)_2 = _14250;
        if( _1 != _14250 ){
            DeRef(_1);
        }
        _14250 = NOVALUE;

        /** 	end for*/
        _i_24985 = _i_24985 + 1;
        goto LA; // [499] 465
LB: 
        ;
    }

    /** 	include_matrix = append( include_matrix, repeat( 0, length( file_include ) ) )*/
    if (IS_SEQUENCE(_36file_include_15247)){
            _14251 = SEQ_PTR(_36file_include_15247)->length;
    }
    else {
        _14251 = 1;
    }
    _14252 = Repeat(0, _14251);
    _14251 = NOVALUE;
    RefDS(_14252);
    Append(&_36include_matrix_15249, _36include_matrix_15249, _14252);
    DeRefDS(_14252);
    _14252 = NOVALUE;

    /** 	include_matrix[$][$] = DIRECT_INCLUDE*/
    if (IS_SEQUENCE(_36include_matrix_15249)){
            _14254 = SEQ_PTR(_36include_matrix_15249)->length;
    }
    else {
        _14254 = 1;
    }
    _2 = (int)SEQ_PTR(_36include_matrix_15249);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36include_matrix_15249 = MAKE_SEQ(_2);
    }
    _3 = (int)(_14254 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(*(object_ptr)_3)){
            _14257 = SEQ_PTR(*(object_ptr)_3)->length;
    }
    else {
        _14257 = 1;
    }
    _14255 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _14257);
    _1 = *(int *)_2;
    *(int *)_2 = 2;
    DeRef(_1);
    _14255 = NOVALUE;

    /** 	include_matrix[current_file_no][$] = DIRECT_INCLUDE*/
    _2 = (int)SEQ_PTR(_36include_matrix_15249);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36include_matrix_15249 = MAKE_SEQ(_2);
    }
    _3 = (int)(_35current_file_no_16244 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(*(object_ptr)_3)){
            _14260 = SEQ_PTR(*(object_ptr)_3)->length;
    }
    else {
        _14260 = 1;
    }
    _14258 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _14260);
    _1 = *(int *)_2;
    *(int *)_2 = 2;
    DeRef(_1);
    _14258 = NOVALUE;

    /** 	indirect_include = append( indirect_include, repeat( 0, length( file_include ) ) )*/
    if (IS_SEQUENCE(_36file_include_15247)){
            _14261 = SEQ_PTR(_36file_include_15247)->length;
    }
    else {
        _14261 = 1;
    }
    _14262 = Repeat(0, _14261);
    _14261 = NOVALUE;
    RefDS(_14262);
    Append(&_36indirect_include_15251, _36indirect_include_15251, _14262);
    DeRefDS(_14262);
    _14262 = NOVALUE;

    /** 	indirect_include[current_file_no][$] = OpIndirectInclude*/
    _2 = (int)SEQ_PTR(_36indirect_include_15251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36indirect_include_15251 = MAKE_SEQ(_2);
    }
    _3 = (int)(_35current_file_no_16244 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(*(object_ptr)_3)){
            _14266 = SEQ_PTR(*(object_ptr)_3)->length;
    }
    else {
        _14266 = 1;
    }
    _14264 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _14266);
    _1 = *(int *)_2;
    *(int *)_2 = _35OpIndirectInclude_16319;
    DeRef(_1);
    _14264 = NOVALUE;

    /** 	OpIndirectInclude = 1*/
    _35OpIndirectInclude_16319 = 1;

    /** 	file_public  = append( file_public, {} )*/
    RefDS(_5);
    Append(&_36file_public_15253, _36file_public_15253, _5);

    /** 	file_public_by = append( file_public_by, {} )*/
    RefDS(_5);
    Append(&_36file_public_by_15257, _36file_public_by_15257, _5);

    /** 	file_include[current_file_no] &= length( file_include )*/
    if (IS_SEQUENCE(_36file_include_15247)){
            _14269 = SEQ_PTR(_36file_include_15247)->length;
    }
    else {
        _14269 = 1;
    }
    _2 = (int)SEQ_PTR(_36file_include_15247);
    _14270 = (int)*(((s1_ptr)_2)->base + _35current_file_no_16244);
    if (IS_SEQUENCE(_14270) && IS_ATOM(_14269)) {
        Append(&_14271, _14270, _14269);
    }
    else if (IS_ATOM(_14270) && IS_SEQUENCE(_14269)) {
    }
    else {
        Concat((object_ptr)&_14271, _14270, _14269);
        _14270 = NOVALUE;
    }
    _14270 = NOVALUE;
    _14269 = NOVALUE;
    _2 = (int)SEQ_PTR(_36file_include_15247);
    _2 = (int)(((s1_ptr)_2)->base + _35current_file_no_16244);
    _1 = *(int *)_2;
    *(int *)_2 = _14271;
    if( _1 != _14271 ){
        DeRef(_1);
    }
    _14271 = NOVALUE;

    /** 	add_include_by( current_file_no, length(file_include), public_include )*/
    if (IS_SEQUENCE(_36file_include_15247)){
            _14272 = SEQ_PTR(_36file_include_15247)->length;
    }
    else {
        _14272 = 1;
    }
    _61add_include_by(_35current_file_no_16244, _14272, _61public_include_23899);
    _14272 = NOVALUE;

    /** 	if public_include then*/
    if (_61public_include_23899 == 0)
    {
        goto LC; // [673] 707
    }
    else{
    }

    /** 		file_public[current_file_no] &= length( file_public )*/
    if (IS_SEQUENCE(_36file_public_15253)){
            _14273 = SEQ_PTR(_36file_public_15253)->length;
    }
    else {
        _14273 = 1;
    }
    _2 = (int)SEQ_PTR(_36file_public_15253);
    _14274 = (int)*(((s1_ptr)_2)->base + _35current_file_no_16244);
    if (IS_SEQUENCE(_14274) && IS_ATOM(_14273)) {
        Append(&_14275, _14274, _14273);
    }
    else if (IS_ATOM(_14274) && IS_SEQUENCE(_14273)) {
    }
    else {
        Concat((object_ptr)&_14275, _14274, _14273);
        _14274 = NOVALUE;
    }
    _14274 = NOVALUE;
    _14273 = NOVALUE;
    _2 = (int)SEQ_PTR(_36file_public_15253);
    _2 = (int)(((s1_ptr)_2)->base + _35current_file_no_16244);
    _1 = *(int *)_2;
    *(int *)_2 = _14275;
    if( _1 != _14275 ){
        DeRef(_1);
    }
    _14275 = NOVALUE;

    /** 		patch_exports( current_file_no )*/
    _61patch_exports(_35current_file_no_16244);
LC: 

    /** ifdef STDDEBUG then*/

    /** 	src_file = new_file_handle*/
    _35src_file_16365 = _new_file_handle_24870;

    /** 	file_start_sym = last_sym*/
    _35file_start_sym_16250 = _53last_sym_46100;

    /** 	if current_file_no >= MAX_FILE then*/
    if (_35current_file_no_16244 < 256)
    goto LD; // [729] 741

    /** 		CompileErr(126)*/
    RefDS(_22023);
    _44CompileErr(126, _22023, 0);
LD: 

    /** 	known_files = append(known_files, new_include_name)*/
    RefDS(_35new_include_name_16366);
    Append(&_36known_files_15243, _36known_files_15243, _35new_include_name_16366);

    /** 	known_files_hash &= new_hash*/
    Ref(_new_hash_24872);
    Append(&_36known_files_hash_15244, _36known_files_hash_15244, _new_hash_24872);

    /** 	finished_files &= 0*/
    Append(&_36finished_files_15245, _36finished_files_15245, 0);

    /** 	file_include_depend = append( file_include_depend, { length( known_files ) } )*/
    if (IS_SEQUENCE(_36known_files_15243)){
            _14281 = SEQ_PTR(_36known_files_15243)->length;
    }
    else {
        _14281 = 1;
    }
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _14281;
    _14282 = MAKE_SEQ(_1);
    _14281 = NOVALUE;
    RefDS(_14282);
    Append(&_36file_include_depend_15246, _36file_include_depend_15246, _14282);
    DeRefDS(_14282);
    _14282 = NOVALUE;

    /** 	file_include_depend[current_file_no] &= length( known_files )*/
    if (IS_SEQUENCE(_36known_files_15243)){
            _14284 = SEQ_PTR(_36known_files_15243)->length;
    }
    else {
        _14284 = 1;
    }
    _2 = (int)SEQ_PTR(_36file_include_depend_15246);
    _14285 = (int)*(((s1_ptr)_2)->base + _35current_file_no_16244);
    if (IS_SEQUENCE(_14285) && IS_ATOM(_14284)) {
        Append(&_14286, _14285, _14284);
    }
    else if (IS_ATOM(_14285) && IS_SEQUENCE(_14284)) {
    }
    else {
        Concat((object_ptr)&_14286, _14285, _14284);
        _14285 = NOVALUE;
    }
    _14285 = NOVALUE;
    _14284 = NOVALUE;
    _2 = (int)SEQ_PTR(_36file_include_depend_15246);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36file_include_depend_15246 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _35current_file_no_16244);
    _1 = *(int *)_2;
    *(int *)_2 = _14286;
    if( _1 != _14286 ){
        DeRef(_1);
    }
    _14286 = NOVALUE;

    /** 	check_coverage()*/
    _50check_coverage();

    /** 	default_namespaces &= 0*/
    Append(&_61default_namespaces_23902, _61default_namespaces_23902, 0);

    /** 	update_include_matrix( length( file_include ), current_file_no )*/
    if (IS_SEQUENCE(_36file_include_15247)){
            _14288 = SEQ_PTR(_36file_include_15247)->length;
    }
    else {
        _14288 = 1;
    }
    _61update_include_matrix(_14288, _35current_file_no_16244);
    _14288 = NOVALUE;

    /** 	old_file_no = current_file_no*/
    _old_file_no_24871 = _35current_file_no_16244;

    /** 	current_file_no = length(known_files)*/
    if (IS_SEQUENCE(_36known_files_15243)){
            _35current_file_no_16244 = SEQ_PTR(_36known_files_15243)->length;
    }
    else {
        _35current_file_no_16244 = 1;
    }

    /** 	line_number = 0*/
    _35line_number_16245 = 0;

    /** 	read_line()*/
    _61read_line();

    /** 	if new_include_space != 0 then*/
    if (_61new_include_space_23894 == 0)
    goto LE; // [873] 897

    /** 		SymTab[new_include_space][S_OBJ] = current_file_no*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_61new_include_space_23894 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _35current_file_no_16244;
    DeRef(_1);
    _14291 = NOVALUE;
LE: 

    /** 	default_namespace( )*/
    _61default_namespace();

    /** end procedure*/
    DeRef(_new_hash_24872);
    DeRef(_14234);
    _14234 = NOVALUE;
    return;
    ;
}


void _61update_include_completion(int _file_no_25095)
{
    int _fx_25104 = NOVALUE;
    int _14301 = NOVALUE;
    int _14300 = NOVALUE;
    int _14299 = NOVALUE;
    int _14298 = NOVALUE;
    int _14296 = NOVALUE;
    int _14295 = NOVALUE;
    int _14294 = NOVALUE;
    int _14293 = NOVALUE;
    int _0, _1, _2;
    

    /** 	for i = 1 to length( file_include_depend ) do*/
    if (IS_SEQUENCE(_36file_include_depend_15246)){
            _14293 = SEQ_PTR(_36file_include_depend_15246)->length;
    }
    else {
        _14293 = 1;
    }
    {
        int _i_25097;
        _i_25097 = 1;
L1: 
        if (_i_25097 > _14293){
            goto L2; // [10] 114
        }

        /** 		if length( file_include_depend[i] ) then*/
        _2 = (int)SEQ_PTR(_36file_include_depend_15246);
        _14294 = (int)*(((s1_ptr)_2)->base + _i_25097);
        if (IS_SEQUENCE(_14294)){
                _14295 = SEQ_PTR(_14294)->length;
        }
        else {
            _14295 = 1;
        }
        _14294 = NOVALUE;
        if (_14295 == 0)
        {
            _14295 = NOVALUE;
            goto L3; // [28] 105
        }
        else{
            _14295 = NOVALUE;
        }

        /** 			integer fx = find( file_no, file_include_depend[i] )*/
        _2 = (int)SEQ_PTR(_36file_include_depend_15246);
        _14296 = (int)*(((s1_ptr)_2)->base + _i_25097);
        _fx_25104 = find_from(_file_no_25095, _14296, 1);
        _14296 = NOVALUE;

        /** 			if fx then*/
        if (_fx_25104 == 0)
        {
            goto L4; // [46] 104
        }
        else{
        }

        /** 				file_include_depend[i] = remove( file_include_depend[i], fx )*/
        _2 = (int)SEQ_PTR(_36file_include_depend_15246);
        _14298 = (int)*(((s1_ptr)_2)->base + _i_25097);
        {
            s1_ptr assign_space = SEQ_PTR(_14298);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_fx_25104)) ? _fx_25104 : (long)(DBL_PTR(_fx_25104)->dbl);
            int stop = (IS_ATOM_INT(_fx_25104)) ? _fx_25104 : (long)(DBL_PTR(_fx_25104)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<0) {
                RefDS(_14298);
                DeRef(_14299);
                _14299 = _14298;
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_14298), start, &_14299 );
                }
                else Tail(SEQ_PTR(_14298), stop+1, &_14299);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_14298), start, &_14299);
            }
            else {
                assign_slice_seq = &assign_space;
                _1 = Remove_elements(start, stop, 0);
                DeRef(_14299);
                _14299 = _1;
            }
        }
        _14298 = NOVALUE;
        _2 = (int)SEQ_PTR(_36file_include_depend_15246);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _36file_include_depend_15246 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_25097);
        _1 = *(int *)_2;
        *(int *)_2 = _14299;
        if( _1 != _14299 ){
            DeRef(_1);
        }
        _14299 = NOVALUE;

        /** 				if not length( file_include_depend[i] ) then*/
        _2 = (int)SEQ_PTR(_36file_include_depend_15246);
        _14300 = (int)*(((s1_ptr)_2)->base + _i_25097);
        if (IS_SEQUENCE(_14300)){
                _14301 = SEQ_PTR(_14300)->length;
        }
        else {
            _14301 = 1;
        }
        _14300 = NOVALUE;
        if (_14301 != 0)
        goto L5; // [79] 103
        _14301 = NOVALUE;

        /** 					finished_files[i] = 1*/
        _2 = (int)SEQ_PTR(_36finished_files_15245);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _36finished_files_15245 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_25097);
        *(int *)_2 = 1;

        /** 					if i != file_no then*/
        if (_i_25097 == _file_no_25095)
        goto L6; // [92] 102

        /** 						update_include_completion( i )*/
        _61update_include_completion(_i_25097);
L6: 
L5: 
L4: 
L3: 

        /** 	end for*/
        _i_25097 = _i_25097 + 1;
        goto L1; // [109] 17
L2: 
        ;
    }

    /** end procedure*/
    _14294 = NOVALUE;
    _14300 = NOVALUE;
    return;
    ;
}


int _61IncludePop()
{
    int _top_25135 = NOVALUE;
    int _14332 = NOVALUE;
    int _14330 = NOVALUE;
    int _14329 = NOVALUE;
    int _14307 = NOVALUE;
    int _14305 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	update_include_completion( current_file_no )*/
    _61update_include_completion(_35current_file_no_16244);

    /** 	Resolve_forward_references()*/
    _38Resolve_forward_references(0);

    /** 	HideLocals()*/
    _53HideLocals();

    /** 	if src_file >= 0 then*/
    if (_35src_file_16365 < 0)
    goto L1; // [21] 39

    /** 		close(src_file)*/
    EClose(_35src_file_16365);

    /** 		src_file = -1*/
    _35src_file_16365 = -1;
L1: 

    /** 	if length(IncludeStk) = 0 then*/
    if (IS_SEQUENCE(_61IncludeStk_23905)){
            _14305 = SEQ_PTR(_61IncludeStk_23905)->length;
    }
    else {
        _14305 = 1;
    }
    if (_14305 != 0)
    goto L2; // [46] 59

    /** 		return FALSE  -- the end*/
    DeRef(_top_25135);
    return _13FALSE_434;
L2: 

    /** 	sequence top = IncludeStk[$]*/
    if (IS_SEQUENCE(_61IncludeStk_23905)){
            _14307 = SEQ_PTR(_61IncludeStk_23905)->length;
    }
    else {
        _14307 = 1;
    }
    DeRef(_top_25135);
    _2 = (int)SEQ_PTR(_61IncludeStk_23905);
    _top_25135 = (int)*(((s1_ptr)_2)->base + _14307);
    RefDS(_top_25135);

    /** 	current_file_no    = top[FILE_NO]*/
    _2 = (int)SEQ_PTR(_top_25135);
    _35current_file_no_16244 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_35current_file_no_16244)){
        _35current_file_no_16244 = (long)DBL_PTR(_35current_file_no_16244)->dbl;
    }

    /** 	line_number        = top[LINE_NO]*/
    _2 = (int)SEQ_PTR(_top_25135);
    _35line_number_16245 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_35line_number_16245)){
        _35line_number_16245 = (long)DBL_PTR(_35line_number_16245)->dbl;
    }

    /** 	src_file           = top[FILE_PTR]*/
    _2 = (int)SEQ_PTR(_top_25135);
    _35src_file_16365 = (int)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_35src_file_16365)){
        _35src_file_16365 = (long)DBL_PTR(_35src_file_16365)->dbl;
    }

    /** 	file_start_sym     = top[FILE_START_SYM]*/
    _2 = (int)SEQ_PTR(_top_25135);
    _35file_start_sym_16250 = (int)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_35file_start_sym_16250)){
        _35file_start_sym_16250 = (long)DBL_PTR(_35file_start_sym_16250)->dbl;
    }

    /** 	OpWarning          = top[OP_WARNING]*/
    _2 = (int)SEQ_PTR(_top_25135);
    _35OpWarning_16311 = (int)*(((s1_ptr)_2)->base + 5);
    if (!IS_ATOM_INT(_35OpWarning_16311)){
        _35OpWarning_16311 = (long)DBL_PTR(_35OpWarning_16311)->dbl;
    }

    /** 	OpTrace            = top[OP_TRACE]*/
    _2 = (int)SEQ_PTR(_top_25135);
    _35OpTrace_16313 = (int)*(((s1_ptr)_2)->base + 6);
    if (!IS_ATOM_INT(_35OpTrace_16313)){
        _35OpTrace_16313 = (long)DBL_PTR(_35OpTrace_16313)->dbl;
    }

    /** 	OpTypeCheck        = top[OP_TYPE_CHECK]*/
    _2 = (int)SEQ_PTR(_top_25135);
    _35OpTypeCheck_16314 = (int)*(((s1_ptr)_2)->base + 7);
    if (!IS_ATOM_INT(_35OpTypeCheck_16314)){
        _35OpTypeCheck_16314 = (long)DBL_PTR(_35OpTypeCheck_16314)->dbl;
    }

    /** 	OpProfileTime      = top[OP_PROFILE_TIME]*/
    _2 = (int)SEQ_PTR(_top_25135);
    _35OpProfileTime_16316 = (int)*(((s1_ptr)_2)->base + 8);
    if (!IS_ATOM_INT(_35OpProfileTime_16316)){
        _35OpProfileTime_16316 = (long)DBL_PTR(_35OpProfileTime_16316)->dbl;
    }

    /** 	OpProfileStatement = top[OP_PROFILE_STATEMENT]*/
    _2 = (int)SEQ_PTR(_top_25135);
    _35OpProfileStatement_16315 = (int)*(((s1_ptr)_2)->base + 9);
    if (!IS_ATOM_INT(_35OpProfileStatement_16315)){
        _35OpProfileStatement_16315 = (long)DBL_PTR(_35OpProfileStatement_16315)->dbl;
    }

    /** 	OpDefines          = top[OP_DEFINES]*/
    DeRef(_35OpDefines_16317);
    _2 = (int)SEQ_PTR(_top_25135);
    _35OpDefines_16317 = (int)*(((s1_ptr)_2)->base + 10);
    Ref(_35OpDefines_16317);

    /** 	prev_OpWarning     = top[PREV_OP_WARNING]*/
    _2 = (int)SEQ_PTR(_top_25135);
    _35prev_OpWarning_16312 = (int)*(((s1_ptr)_2)->base + 11);
    if (!IS_ATOM_INT(_35prev_OpWarning_16312)){
        _35prev_OpWarning_16312 = (long)DBL_PTR(_35prev_OpWarning_16312)->dbl;
    }

    /** 	OpInline           = top[OP_INLINE]*/
    _2 = (int)SEQ_PTR(_top_25135);
    _35OpInline_16318 = (int)*(((s1_ptr)_2)->base + 12);
    if (!IS_ATOM_INT(_35OpInline_16318)){
        _35OpInline_16318 = (long)DBL_PTR(_35OpInline_16318)->dbl;
    }

    /** 	OpIndirectInclude  = top[OP_INDIRECT_INCLUDE]*/
    _2 = (int)SEQ_PTR(_top_25135);
    _35OpIndirectInclude_16319 = (int)*(((s1_ptr)_2)->base + 13);
    if (!IS_ATOM_INT(_35OpIndirectInclude_16319)){
        _35OpIndirectInclude_16319 = (long)DBL_PTR(_35OpIndirectInclude_16319)->dbl;
    }

    /** 	putback_fwd_line_number = line_number -- top[PUTBACK_FWD_LINE_NUMBER]*/
    _35putback_fwd_line_number_16247 = _35line_number_16245;

    /** 	putback_ForwardLine = top[PUTBACK_FORWARDLINE]*/
    DeRef(_44putback_ForwardLine_48520);
    _2 = (int)SEQ_PTR(_top_25135);
    _44putback_ForwardLine_48520 = (int)*(((s1_ptr)_2)->base + 15);
    Ref(_44putback_ForwardLine_48520);

    /** 	putback_forward_bp = top[PUTBACK_FORWARD_BP]*/
    _2 = (int)SEQ_PTR(_top_25135);
    _44putback_forward_bp_48524 = (int)*(((s1_ptr)_2)->base + 16);
    if (!IS_ATOM_INT(_44putback_forward_bp_48524)){
        _44putback_forward_bp_48524 = (long)DBL_PTR(_44putback_forward_bp_48524)->dbl;
    }

    /** 	last_fwd_line_number = top[LAST_FWD_LINE_NUMBER]*/
    _2 = (int)SEQ_PTR(_top_25135);
    _35last_fwd_line_number_16248 = (int)*(((s1_ptr)_2)->base + 17);
    if (!IS_ATOM_INT(_35last_fwd_line_number_16248)){
        _35last_fwd_line_number_16248 = (long)DBL_PTR(_35last_fwd_line_number_16248)->dbl;
    }

    /** 	last_ForwardLine = top[LAST_FORWARDLINE]*/
    DeRef(_44last_ForwardLine_48521);
    _2 = (int)SEQ_PTR(_top_25135);
    _44last_ForwardLine_48521 = (int)*(((s1_ptr)_2)->base + 18);
    Ref(_44last_ForwardLine_48521);

    /** 	last_forward_bp = top[LAST_FORWARD_BP]*/
    _2 = (int)SEQ_PTR(_top_25135);
    _44last_forward_bp_48525 = (int)*(((s1_ptr)_2)->base + 19);
    if (!IS_ATOM_INT(_44last_forward_bp_48525)){
        _44last_forward_bp_48525 = (long)DBL_PTR(_44last_forward_bp_48525)->dbl;
    }

    /** 	ThisLine = top[THISLINE]*/
    DeRef(_44ThisLine_48518);
    _2 = (int)SEQ_PTR(_top_25135);
    _44ThisLine_48518 = (int)*(((s1_ptr)_2)->base + 20);
    Ref(_44ThisLine_48518);

    /** 	fwd_line_number = line_number --top[FWD_LINE_NUMBER]*/
    _35fwd_line_number_16246 = _35line_number_16245;

    /** 	forward_bp = top[FORWARD_BP]*/
    _2 = (int)SEQ_PTR(_top_25135);
    _44forward_bp_48523 = (int)*(((s1_ptr)_2)->base + 22);
    if (!IS_ATOM_INT(_44forward_bp_48523)){
        _44forward_bp_48523 = (long)DBL_PTR(_44forward_bp_48523)->dbl;
    }

    /** 	ForwardLine = ThisLine*/
    Ref(_44ThisLine_48518);
    DeRef(_44ForwardLine_48519);
    _44ForwardLine_48519 = _44ThisLine_48518;

    /** 	putback_ForwardLine = ThisLine*/
    Ref(_44ThisLine_48518);
    DeRef(_44putback_ForwardLine_48520);
    _44putback_ForwardLine_48520 = _44ThisLine_48518;

    /** 	last_ForwardLine = ThisLine*/
    Ref(_44ThisLine_48518);
    DeRef(_44last_ForwardLine_48521);
    _44last_ForwardLine_48521 = _44ThisLine_48518;

    /** 	IncludeStk = IncludeStk[1..$-1]*/
    if (IS_SEQUENCE(_61IncludeStk_23905)){
            _14329 = SEQ_PTR(_61IncludeStk_23905)->length;
    }
    else {
        _14329 = 1;
    }
    _14330 = _14329 - 1;
    _14329 = NOVALUE;
    rhs_slice_target = (object_ptr)&_61IncludeStk_23905;
    RHS_Slice(_61IncludeStk_23905, 1, _14330);

    /** 	SymTab[TopLevelSub][S_CODE] = Code*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_35TopLevelSub_16251 + ((s1_ptr)_2)->base);
    RefDS(_35Code_16332);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35S_CODE_15929))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_CODE_15929)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _35S_CODE_15929);
    _1 = *(int *)_2;
    *(int *)_2 = _35Code_16332;
    DeRef(_1);
    _14332 = NOVALUE;

    /** 	return TRUE*/
    DeRefDS(_top_25135);
    _14330 = NOVALUE;
    return _13TRUE_436;
    ;
}


int _61MakeInt(int _text_25223, int _nBase_25224)
{
    int _num_25225 = NOVALUE;
    int _fnum_25226 = NOVALUE;
    int _digit_25227 = NOVALUE;
    int _maxchk_25228 = NOVALUE;
    int _14377 = NOVALUE;
    int _14375 = NOVALUE;
    int _14373 = NOVALUE;
    int _14370 = NOVALUE;
    int _14369 = NOVALUE;
    int _14368 = NOVALUE;
    int _14366 = NOVALUE;
    int _14364 = NOVALUE;
    int _14363 = NOVALUE;
    int _14360 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_nBase_25224)) {
        _1 = (long)(DBL_PTR(_nBase_25224)->dbl);
        DeRefDS(_nBase_25224);
        _nBase_25224 = _1;
    }

    /** 	switch nBase do*/
    _0 = _nBase_25224;
    switch ( _0 ){ 

        /** 		case 2 then*/
        case 2:

        /** 			maxchk = 536870911*/
        _maxchk_25228 = 536870911;
        goto L1; // [21] 82

        /** 		case 8 then*/
        case 8:

        /** 			maxchk = 134217727*/
        _maxchk_25228 = 134217727;
        goto L1; // [32] 82

        /** 		case 10 then*/
        case 10:

        /** 			num = find(text, common_int_text)*/
        _num_25225 = find_from(_text_25223, _61common_int_text_25198, 1);

        /** 			if num then*/
        if (_num_25225 == 0)
        {
            goto L2; // [49] 65
        }
        else{
        }

        /** 				return common_ints[num]*/
        _2 = (int)SEQ_PTR(_61common_ints_25218);
        _14360 = (int)*(((s1_ptr)_2)->base + _num_25225);
        DeRefDS(_text_25223);
        DeRef(_fnum_25226);
        return _14360;
L2: 

        /** 			maxchk = 107374181*/
        _maxchk_25228 = 107374181;
        goto L1; // [70] 82

        /** 		case 16 then*/
        case 16:

        /** 			maxchk = 67108863*/
        _maxchk_25228 = 67108863;
    ;}L1: 

    /** 	num = 0*/
    _num_25225 = 0;

    /** 	fnum = 0*/
    DeRef(_fnum_25226);
    _fnum_25226 = 0;

    /** 	for i = 1 to length(text) do*/
    if (IS_SEQUENCE(_text_25223)){
            _14363 = SEQ_PTR(_text_25223)->length;
    }
    else {
        _14363 = 1;
    }
    {
        int _i_25243;
        _i_25243 = 1;
L3: 
        if (_i_25243 > _14363){
            goto L4; // [97] 212
        }

        /** 		digit = (text[i] - '0')*/
        _2 = (int)SEQ_PTR(_text_25223);
        _14364 = (int)*(((s1_ptr)_2)->base + _i_25243);
        if (IS_ATOM_INT(_14364)) {
            _digit_25227 = _14364 - 48;
        }
        else {
            _digit_25227 = binary_op(MINUS, _14364, 48);
        }
        _14364 = NOVALUE;
        if (!IS_ATOM_INT(_digit_25227)) {
            _1 = (long)(DBL_PTR(_digit_25227)->dbl);
            DeRefDS(_digit_25227);
            _digit_25227 = _1;
        }

        /** 		if digit >= nBase or digit < 0 then*/
        _14366 = (_digit_25227 >= _nBase_25224);
        if (_14366 != 0) {
            goto L5; // [122] 135
        }
        _14368 = (_digit_25227 < 0);
        if (_14368 == 0)
        {
            DeRef(_14368);
            _14368 = NOVALUE;
            goto L6; // [131] 151
        }
        else{
            DeRef(_14368);
            _14368 = NOVALUE;
        }
L5: 

        /** 			CompileErr(62, {text[i],i})*/
        _2 = (int)SEQ_PTR(_text_25223);
        _14369 = (int)*(((s1_ptr)_2)->base + _i_25243);
        Ref(_14369);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _14369;
        ((int *)_2)[2] = _i_25243;
        _14370 = MAKE_SEQ(_1);
        _14369 = NOVALUE;
        _44CompileErr(62, _14370, 0);
        _14370 = NOVALUE;
L6: 

        /** 		if fnum = 0 then*/
        if (binary_op_a(NOTEQ, _fnum_25226, 0)){
            goto L7; // [153] 194
        }

        /** 			if num <= maxchk then*/
        if (_num_25225 > _maxchk_25228)
        goto L8; // [161] 180

        /** 				num = num * nBase + digit*/
        if (_num_25225 == (short)_num_25225 && _nBase_25224 <= INT15 && _nBase_25224 >= -INT15)
        _14373 = _num_25225 * _nBase_25224;
        else
        _14373 = NewDouble(_num_25225 * (double)_nBase_25224);
        if (IS_ATOM_INT(_14373)) {
            _num_25225 = _14373 + _digit_25227;
        }
        else {
            _num_25225 = NewDouble(DBL_PTR(_14373)->dbl + (double)_digit_25227);
        }
        DeRef(_14373);
        _14373 = NOVALUE;
        if (!IS_ATOM_INT(_num_25225)) {
            _1 = (long)(DBL_PTR(_num_25225)->dbl);
            DeRefDS(_num_25225);
            _num_25225 = _1;
        }
        goto L9; // [177] 205
L8: 

        /** 				fnum = num * nBase + digit*/
        if (_num_25225 == (short)_num_25225 && _nBase_25224 <= INT15 && _nBase_25224 >= -INT15)
        _14375 = _num_25225 * _nBase_25224;
        else
        _14375 = NewDouble(_num_25225 * (double)_nBase_25224);
        DeRef(_fnum_25226);
        if (IS_ATOM_INT(_14375)) {
            _fnum_25226 = _14375 + _digit_25227;
            if ((long)((unsigned long)_fnum_25226 + (unsigned long)HIGH_BITS) >= 0) 
            _fnum_25226 = NewDouble((double)_fnum_25226);
        }
        else {
            _fnum_25226 = NewDouble(DBL_PTR(_14375)->dbl + (double)_digit_25227);
        }
        DeRef(_14375);
        _14375 = NOVALUE;
        goto L9; // [191] 205
L7: 

        /** 			fnum = fnum * nBase + digit*/
        if (IS_ATOM_INT(_fnum_25226)) {
            if (_fnum_25226 == (short)_fnum_25226 && _nBase_25224 <= INT15 && _nBase_25224 >= -INT15)
            _14377 = _fnum_25226 * _nBase_25224;
            else
            _14377 = NewDouble(_fnum_25226 * (double)_nBase_25224);
        }
        else {
            _14377 = NewDouble(DBL_PTR(_fnum_25226)->dbl * (double)_nBase_25224);
        }
        DeRef(_fnum_25226);
        if (IS_ATOM_INT(_14377)) {
            _fnum_25226 = _14377 + _digit_25227;
            if ((long)((unsigned long)_fnum_25226 + (unsigned long)HIGH_BITS) >= 0) 
            _fnum_25226 = NewDouble((double)_fnum_25226);
        }
        else {
            _fnum_25226 = NewDouble(DBL_PTR(_14377)->dbl + (double)_digit_25227);
        }
        DeRef(_14377);
        _14377 = NOVALUE;
L9: 

        /** 	end for*/
        _i_25243 = _i_25243 + 1;
        goto L3; // [207] 104
L4: 
        ;
    }

    /** 	if fnum = 0 then*/
    if (binary_op_a(NOTEQ, _fnum_25226, 0)){
        goto LA; // [214] 227
    }

    /** 		return num*/
    DeRefDS(_text_25223);
    DeRef(_fnum_25226);
    _14360 = NOVALUE;
    DeRef(_14366);
    _14366 = NOVALUE;
    return _num_25225;
    goto LB; // [224] 234
LA: 

    /** 		return fnum*/
    DeRefDS(_text_25223);
    _14360 = NOVALUE;
    DeRef(_14366);
    _14366 = NOVALUE;
    return _fnum_25226;
LB: 
    ;
}


int _61GetHexChar(int _cnt_25271, int _errno_25272)
{
    int _val_25273 = NOVALUE;
    int _d_25274 = NOVALUE;
    int _14387 = NOVALUE;
    int _14386 = NOVALUE;
    int _14381 = NOVALUE;
    int _0, _1, _2;
    

    /** 	val = 0*/
    DeRef(_val_25273);
    _val_25273 = 0;

    /** 	while cnt > 0 do*/
L1: 
    if (_cnt_25271 <= 0)
    goto L2; // [15] 88

    /** 		d = find(getch(), "0123456789ABCDEFabcdef_")*/
    _14381 = _61getch();
    _d_25274 = find_from(_14381, _14382, 1);
    DeRef(_14381);
    _14381 = NOVALUE;

    /** 		if d = 0 then*/
    if (_d_25274 != 0)
    goto L3; // [31] 43

    /** 			CompileErr( errno )*/
    RefDS(_22023);
    _44CompileErr(_errno_25272, _22023, 0);
L3: 

    /** 		if d != 23 then*/
    if (_d_25274 == 23)
    goto L1; // [45] 15

    /** 			val = val * 16 + d - 1*/
    if (IS_ATOM_INT(_val_25273)) {
        if (_val_25273 == (short)_val_25273)
        _14386 = _val_25273 * 16;
        else
        _14386 = NewDouble(_val_25273 * (double)16);
    }
    else {
        _14386 = NewDouble(DBL_PTR(_val_25273)->dbl * (double)16);
    }
    if (IS_ATOM_INT(_14386)) {
        _14387 = _14386 + _d_25274;
        if ((long)((unsigned long)_14387 + (unsigned long)HIGH_BITS) >= 0) 
        _14387 = NewDouble((double)_14387);
    }
    else {
        _14387 = NewDouble(DBL_PTR(_14386)->dbl + (double)_d_25274);
    }
    DeRef(_14386);
    _14386 = NOVALUE;
    DeRef(_val_25273);
    if (IS_ATOM_INT(_14387)) {
        _val_25273 = _14387 - 1;
        if ((long)((unsigned long)_val_25273 +(unsigned long) HIGH_BITS) >= 0){
            _val_25273 = NewDouble((double)_val_25273);
        }
    }
    else {
        _val_25273 = NewDouble(DBL_PTR(_14387)->dbl - (double)1);
    }
    DeRef(_14387);
    _14387 = NOVALUE;

    /** 			if d > 16 then*/
    if (_d_25274 <= 16)
    goto L4; // [65] 76

    /** 				val -= 6*/
    _0 = _val_25273;
    if (IS_ATOM_INT(_val_25273)) {
        _val_25273 = _val_25273 - 6;
        if ((long)((unsigned long)_val_25273 +(unsigned long) HIGH_BITS) >= 0){
            _val_25273 = NewDouble((double)_val_25273);
        }
    }
    else {
        _val_25273 = NewDouble(DBL_PTR(_val_25273)->dbl - (double)6);
    }
    DeRef(_0);
L4: 

    /** 			cnt -= 1*/
    _cnt_25271 = _cnt_25271 - 1;

    /** 	end while*/
    goto L1; // [85] 15
L2: 

    /** 	return val*/
    return _val_25273;
    ;
}


int _61GetBinaryChar(int _delim_25294)
{
    int _val_25295 = NOVALUE;
    int _d_25296 = NOVALUE;
    int _vchars_25297 = NOVALUE;
    int _cnt_25300 = NOVALUE;
    int _14401 = NOVALUE;
    int _14400 = NOVALUE;
    int _14394 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence vchars = "01_ " & delim*/
    Append(&_vchars_25297, _14392, _delim_25294);

    /** 	integer cnt = 0*/
    _cnt_25300 = 0;

    /** 	val = 0*/
    DeRef(_val_25295);
    _val_25295 = 0;

    /** 	while 1 do*/
L1: 

    /** 		d = find(getch(), vchars)*/
    _14394 = _61getch();
    _d_25296 = find_from(_14394, _vchars_25297, 1);
    DeRef(_14394);
    _14394 = NOVALUE;

    /** 		if d = 0 then*/
    if (_d_25296 != 0)
    goto L2; // [36] 48

    /** 			CompileErr( 343 )*/
    RefDS(_22023);
    _44CompileErr(343, _22023, 0);
L2: 

    /** 		if d = 5 then*/
    if (_d_25296 != 5)
    goto L3; // [50] 63

    /** 			ungetch()*/
    _61ungetch();

    /** 			exit*/
    goto L4; // [60] 106
L3: 

    /** 		if d = 4 then*/
    if (_d_25296 != 4)
    goto L5; // [65] 74

    /** 			exit*/
    goto L4; // [71] 106
L5: 

    /** 		if d != 3 then*/
    if (_d_25296 == 3)
    goto L1; // [76] 24

    /** 			val = val * 2 + d - 1*/
    if (IS_ATOM_INT(_val_25295) && IS_ATOM_INT(_val_25295)) {
        _14400 = _val_25295 + _val_25295;
        if ((long)((unsigned long)_14400 + (unsigned long)HIGH_BITS) >= 0) 
        _14400 = NewDouble((double)_14400);
    }
    else {
        if (IS_ATOM_INT(_val_25295)) {
            _14400 = NewDouble((double)_val_25295 + DBL_PTR(_val_25295)->dbl);
        }
        else {
            if (IS_ATOM_INT(_val_25295)) {
                _14400 = NewDouble(DBL_PTR(_val_25295)->dbl + (double)_val_25295);
            }
            else
            _14400 = NewDouble(DBL_PTR(_val_25295)->dbl + DBL_PTR(_val_25295)->dbl);
        }
    }
    if (IS_ATOM_INT(_14400)) {
        _14401 = _14400 + _d_25296;
        if ((long)((unsigned long)_14401 + (unsigned long)HIGH_BITS) >= 0) 
        _14401 = NewDouble((double)_14401);
    }
    else {
        _14401 = NewDouble(DBL_PTR(_14400)->dbl + (double)_d_25296);
    }
    DeRef(_14400);
    _14400 = NOVALUE;
    DeRef(_val_25295);
    if (IS_ATOM_INT(_14401)) {
        _val_25295 = _14401 - 1;
        if ((long)((unsigned long)_val_25295 +(unsigned long) HIGH_BITS) >= 0){
            _val_25295 = NewDouble((double)_val_25295);
        }
    }
    else {
        _val_25295 = NewDouble(DBL_PTR(_14401)->dbl - (double)1);
    }
    DeRef(_14401);
    _14401 = NOVALUE;

    /** 			cnt += 1*/
    _cnt_25300 = _cnt_25300 + 1;

    /** 	end while*/
    goto L1; // [103] 24
L4: 

    /** 	if cnt = 0 then*/
    if (_cnt_25300 != 0)
    goto L6; // [108] 120

    /** 		CompileErr(343)*/
    RefDS(_22023);
    _44CompileErr(343, _22023, 0);
L6: 

    /** 	return val*/
    DeRefi(_vchars_25297);
    return _val_25295;
    ;
}


int _61EscapeChar(int _delim_25322)
{
    int _c_25323 = NOVALUE;
    int _0, _1, _2;
    

    /** 	c = getch()*/
    _0 = _c_25323;
    _c_25323 = _61getch();
    DeRef(_0);

    /** 	switch c do*/
    if (IS_SEQUENCE(_c_25323) ){
        goto L1; // [10] 135
    }
    if(!IS_ATOM_INT(_c_25323)){
        if( (DBL_PTR(_c_25323)->dbl != (double) ((int) DBL_PTR(_c_25323)->dbl) ) ){
            goto L1; // [10] 135
        }
        _0 = (int) DBL_PTR(_c_25323)->dbl;
    }
    else {
        _0 = _c_25323;
    };
    switch ( _0 ){ 

        /** 		case 'n' then*/
        case 110:

        /** 			c = 10 -- Newline*/
        DeRef(_c_25323);
        _c_25323 = 10;
        goto L2; // [24] 145

        /** 		case 't' then*/
        case 116:

        /** 			c = 9 -- Tabulator*/
        DeRef(_c_25323);
        _c_25323 = 9;
        goto L2; // [35] 145

        /** 		case '"', '\\', '\'' then*/
        case 34:
        case 92:
        case 39:

        /** 		case 'r' then*/
        goto L2; // [47] 145
        case 114:

        /** 			c = 13 -- Carriage Return*/
        DeRef(_c_25323);
        _c_25323 = 13;
        goto L2; // [56] 145

        /** 		case '0' then*/
        case 48:

        /** 			c = 0 -- Null*/
        DeRef(_c_25323);
        _c_25323 = 0;
        goto L2; // [67] 145

        /** 		case 'e', 'E' then*/
        case 101:
        case 69:

        /** 			c = 27 -- escape char.*/
        DeRef(_c_25323);
        _c_25323 = 27;
        goto L2; // [80] 145

        /** 		case 'x' then*/
        case 120:

        /** 			c = GetHexChar(2, 340)*/
        _0 = _c_25323;
        _c_25323 = _61GetHexChar(2, 340);
        DeRef(_0);
        goto L2; // [93] 145

        /** 		case 'u' then*/
        case 117:

        /** 			c = GetHexChar(4, 341)*/
        _0 = _c_25323;
        _c_25323 = _61GetHexChar(4, 341);
        DeRef(_0);
        goto L2; // [106] 145

        /** 		case 'U' then*/
        case 85:

        /** 			c = GetHexChar(8, 342)*/
        _0 = _c_25323;
        _c_25323 = _61GetHexChar(8, 342);
        DeRef(_0);
        goto L2; // [119] 145

        /** 		case 'b' then*/
        case 98:

        /** 			c = GetBinaryChar(delim)*/
        _0 = _c_25323;
        _c_25323 = _61GetBinaryChar(_delim_25322);
        DeRef(_0);
        goto L2; // [131] 145

        /** 		case else*/
        default:
L1: 

        /** 			CompileErr(155)*/
        RefDS(_22023);
        _44CompileErr(155, _22023, 0);
    ;}L2: 

    /** 	return c*/
    return _c_25323;
    ;
}


int _61my_sscanf(int _yytext_25346)
{
    int _e_sign_25347 = NOVALUE;
    int _ndigits_25348 = NOVALUE;
    int _e_mag_25349 = NOVALUE;
    int _mantissa_25350 = NOVALUE;
    int _c_25351 = NOVALUE;
    int _i_25352 = NOVALUE;
    int _dec_25353 = NOVALUE;
    int _frac_25383 = NOVALUE;
    int _14446 = NOVALUE;
    int _14441 = NOVALUE;
    int _14440 = NOVALUE;
    int _14438 = NOVALUE;
    int _14437 = NOVALUE;
    int _14436 = NOVALUE;
    int _14428 = NOVALUE;
    int _14427 = NOVALUE;
    int _14424 = NOVALUE;
    int _14423 = NOVALUE;
    int _14422 = NOVALUE;
    int _14418 = NOVALUE;
    int _14417 = NOVALUE;
    int _14415 = NOVALUE;
    int _14413 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if length(yytext) < 2 then*/
    if (IS_SEQUENCE(_yytext_25346)){
            _14413 = SEQ_PTR(_yytext_25346)->length;
    }
    else {
        _14413 = 1;
    }
    if (_14413 >= 2)
    goto L1; // [8] 20

    /** 		CompileErr(121)*/
    RefDS(_22023);
    _44CompileErr(121, _22023, 0);
L1: 

    /** 	if find( 'e', yytext ) or find( 'E', yytext ) then*/
    _14415 = find_from(101, _yytext_25346, 1);
    if (_14415 != 0) {
        goto L2; // [27] 41
    }
    _14417 = find_from(69, _yytext_25346, 1);
    if (_14417 == 0)
    {
        _14417 = NOVALUE;
        goto L3; // [37] 52
    }
    else{
        _14417 = NOVALUE;
    }
L2: 

    /** 		return scientific_to_atom( yytext )*/
    RefDS(_yytext_25346);
    _14418 = _62scientific_to_atom(_yytext_25346);
    DeRefDS(_yytext_25346);
    DeRef(_mantissa_25350);
    DeRef(_dec_25353);
    return _14418;
L3: 

    /** 	mantissa = 0.0*/
    RefDS(_14419);
    DeRef(_mantissa_25350);
    _mantissa_25350 = _14419;

    /** 	ndigits = 0*/
    _ndigits_25348 = 0;

    /** 	yytext &= 0 -- end marker*/
    Append(&_yytext_25346, _yytext_25346, 0);

    /** 	c = yytext[1]*/
    _2 = (int)SEQ_PTR(_yytext_25346);
    _c_25351 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_c_25351))
    _c_25351 = (long)DBL_PTR(_c_25351)->dbl;

    /** 	i = 2*/
    _i_25352 = 2;

    /** 	while c >= '0' and c <= '9' do*/
L4: 
    _14422 = (_c_25351 >= 48);
    if (_14422 == 0) {
        goto L5; // [88] 137
    }
    _14424 = (_c_25351 <= 57);
    if (_14424 == 0)
    {
        DeRef(_14424);
        _14424 = NOVALUE;
        goto L5; // [97] 137
    }
    else{
        DeRef(_14424);
        _14424 = NOVALUE;
    }

    /** 		ndigits += 1*/
    _ndigits_25348 = _ndigits_25348 + 1;

    /** 		mantissa = mantissa * 10.0 + (c - '0')*/
    if (IS_ATOM_INT(_mantissa_25350)) {
        _14427 = NewDouble((double)_mantissa_25350 * DBL_PTR(_14426)->dbl);
    }
    else {
        _14427 = NewDouble(DBL_PTR(_mantissa_25350)->dbl * DBL_PTR(_14426)->dbl);
    }
    _14428 = _c_25351 - 48;
    if ((long)((unsigned long)_14428 +(unsigned long) HIGH_BITS) >= 0){
        _14428 = NewDouble((double)_14428);
    }
    DeRef(_mantissa_25350);
    if (IS_ATOM_INT(_14428)) {
        _mantissa_25350 = NewDouble(DBL_PTR(_14427)->dbl + (double)_14428);
    }
    else
    _mantissa_25350 = NewDouble(DBL_PTR(_14427)->dbl + DBL_PTR(_14428)->dbl);
    DeRefDS(_14427);
    _14427 = NOVALUE;
    DeRef(_14428);
    _14428 = NOVALUE;

    /** 		c = yytext[i]*/
    _2 = (int)SEQ_PTR(_yytext_25346);
    _c_25351 = (int)*(((s1_ptr)_2)->base + _i_25352);
    if (!IS_ATOM_INT(_c_25351))
    _c_25351 = (long)DBL_PTR(_c_25351)->dbl;

    /** 		i += 1*/
    _i_25352 = _i_25352 + 1;

    /** 	end while*/
    goto L4; // [134] 84
L5: 

    /** 	if c = '.' then*/
    if (_c_25351 != 46)
    goto L6; // [139] 240

    /** 		c = yytext[i]*/
    _2 = (int)SEQ_PTR(_yytext_25346);
    _c_25351 = (int)*(((s1_ptr)_2)->base + _i_25352);
    if (!IS_ATOM_INT(_c_25351))
    _c_25351 = (long)DBL_PTR(_c_25351)->dbl;

    /** 		i += 1*/
    _i_25352 = _i_25352 + 1;

    /** 		dec = 1.0*/
    RefDS(_14435);
    DeRef(_dec_25353);
    _dec_25353 = _14435;

    /** 		atom frac = 0*/
    DeRef(_frac_25383);
    _frac_25383 = 0;

    /** 		while c >= '0' and c <= '9' do*/
L7: 
    _14436 = (_c_25351 >= 48);
    if (_14436 == 0) {
        goto L8; // [174] 229
    }
    _14438 = (_c_25351 <= 57);
    if (_14438 == 0)
    {
        DeRef(_14438);
        _14438 = NOVALUE;
        goto L8; // [183] 229
    }
    else{
        DeRef(_14438);
        _14438 = NOVALUE;
    }

    /** 			ndigits += 1*/
    _ndigits_25348 = _ndigits_25348 + 1;

    /** 			frac = frac * 10 + (c - '0')*/
    if (IS_ATOM_INT(_frac_25383)) {
        if (_frac_25383 == (short)_frac_25383)
        _14440 = _frac_25383 * 10;
        else
        _14440 = NewDouble(_frac_25383 * (double)10);
    }
    else {
        _14440 = NewDouble(DBL_PTR(_frac_25383)->dbl * (double)10);
    }
    _14441 = _c_25351 - 48;
    if ((long)((unsigned long)_14441 +(unsigned long) HIGH_BITS) >= 0){
        _14441 = NewDouble((double)_14441);
    }
    DeRef(_frac_25383);
    if (IS_ATOM_INT(_14440) && IS_ATOM_INT(_14441)) {
        _frac_25383 = _14440 + _14441;
        if ((long)((unsigned long)_frac_25383 + (unsigned long)HIGH_BITS) >= 0) 
        _frac_25383 = NewDouble((double)_frac_25383);
    }
    else {
        if (IS_ATOM_INT(_14440)) {
            _frac_25383 = NewDouble((double)_14440 + DBL_PTR(_14441)->dbl);
        }
        else {
            if (IS_ATOM_INT(_14441)) {
                _frac_25383 = NewDouble(DBL_PTR(_14440)->dbl + (double)_14441);
            }
            else
            _frac_25383 = NewDouble(DBL_PTR(_14440)->dbl + DBL_PTR(_14441)->dbl);
        }
    }
    DeRef(_14440);
    _14440 = NOVALUE;
    DeRef(_14441);
    _14441 = NOVALUE;

    /** 			dec *= 10.0*/
    _0 = _dec_25353;
    if (IS_ATOM_INT(_dec_25353)) {
        _dec_25353 = NewDouble((double)_dec_25353 * DBL_PTR(_14426)->dbl);
    }
    else {
        _dec_25353 = NewDouble(DBL_PTR(_dec_25353)->dbl * DBL_PTR(_14426)->dbl);
    }
    DeRef(_0);

    /** 			c = yytext[i]*/
    _2 = (int)SEQ_PTR(_yytext_25346);
    _c_25351 = (int)*(((s1_ptr)_2)->base + _i_25352);
    if (!IS_ATOM_INT(_c_25351))
    _c_25351 = (long)DBL_PTR(_c_25351)->dbl;

    /** 			i += 1*/
    _i_25352 = _i_25352 + 1;

    /** 		end while*/
    goto L7; // [226] 170
L8: 

    /** 		mantissa += frac / dec*/
    if (IS_ATOM_INT(_frac_25383) && IS_ATOM_INT(_dec_25353)) {
        _14446 = (_frac_25383 % _dec_25353) ? NewDouble((double)_frac_25383 / _dec_25353) : (_frac_25383 / _dec_25353);
    }
    else {
        if (IS_ATOM_INT(_frac_25383)) {
            _14446 = NewDouble((double)_frac_25383 / DBL_PTR(_dec_25353)->dbl);
        }
        else {
            if (IS_ATOM_INT(_dec_25353)) {
                _14446 = NewDouble(DBL_PTR(_frac_25383)->dbl / (double)_dec_25353);
            }
            else
            _14446 = NewDouble(DBL_PTR(_frac_25383)->dbl / DBL_PTR(_dec_25353)->dbl);
        }
    }
    _0 = _mantissa_25350;
    if (IS_ATOM_INT(_mantissa_25350) && IS_ATOM_INT(_14446)) {
        _mantissa_25350 = _mantissa_25350 + _14446;
        if ((long)((unsigned long)_mantissa_25350 + (unsigned long)HIGH_BITS) >= 0) 
        _mantissa_25350 = NewDouble((double)_mantissa_25350);
    }
    else {
        if (IS_ATOM_INT(_mantissa_25350)) {
            _mantissa_25350 = NewDouble((double)_mantissa_25350 + DBL_PTR(_14446)->dbl);
        }
        else {
            if (IS_ATOM_INT(_14446)) {
                _mantissa_25350 = NewDouble(DBL_PTR(_mantissa_25350)->dbl + (double)_14446);
            }
            else
            _mantissa_25350 = NewDouble(DBL_PTR(_mantissa_25350)->dbl + DBL_PTR(_14446)->dbl);
        }
    }
    DeRef(_0);
    DeRef(_14446);
    _14446 = NOVALUE;
L6: 
    DeRef(_frac_25383);
    _frac_25383 = NOVALUE;

    /** 	if ndigits = 0 then*/
    if (_ndigits_25348 != 0)
    goto L9; // [244] 256

    /** 		CompileErr(121)  -- no digits*/
    RefDS(_22023);
    _44CompileErr(121, _22023, 0);
L9: 

    /** 	return mantissa*/
    DeRefDS(_yytext_25346);
    DeRef(_dec_25353);
    DeRef(_14418);
    _14418 = NOVALUE;
    DeRef(_14422);
    _14422 = NOVALUE;
    DeRef(_14436);
    _14436 = NOVALUE;
    return _mantissa_25350;
    ;
}


void _61maybe_namespace()
{
    int _0, _1, _2;
    

    /** 	might_be_namespace = 1*/
    _61might_be_namespace_25400 = 1;

    /** end procedure*/
    return;
    ;
}


int _61ExtendedString(int _ech_25410)
{
    int _ch_25411 = NOVALUE;
    int _fch_25412 = NOVALUE;
    int _cline_25413 = NOVALUE;
    int _string_text_25414 = NOVALUE;
    int _trimming_25415 = NOVALUE;
    int _14499 = NOVALUE;
    int _14498 = NOVALUE;
    int _14496 = NOVALUE;
    int _14495 = NOVALUE;
    int _14494 = NOVALUE;
    int _14493 = NOVALUE;
    int _14492 = NOVALUE;
    int _14491 = NOVALUE;
    int _14490 = NOVALUE;
    int _14489 = NOVALUE;
    int _14487 = NOVALUE;
    int _14486 = NOVALUE;
    int _14485 = NOVALUE;
    int _14484 = NOVALUE;
    int _14483 = NOVALUE;
    int _14482 = NOVALUE;
    int _14479 = NOVALUE;
    int _14478 = NOVALUE;
    int _14477 = NOVALUE;
    int _14475 = NOVALUE;
    int _14474 = NOVALUE;
    int _14473 = NOVALUE;
    int _14472 = NOVALUE;
    int _14469 = NOVALUE;
    int _14454 = NOVALUE;
    int _14452 = NOVALUE;
    int _0, _1, _2;
    

    /** 	cline = line_number*/
    _cline_25413 = _35line_number_16245;

    /** 	string_text = ""*/
    RefDS(_5);
    DeRefi(_string_text_25414);
    _string_text_25414 = _5;

    /** 	trimming = 0*/
    _trimming_25415 = 0;

    /** 	ch = getch()*/
    _ch_25411 = _61getch();
    if (!IS_ATOM_INT(_ch_25411)) {
        _1 = (long)(DBL_PTR(_ch_25411)->dbl);
        DeRefDS(_ch_25411);
        _ch_25411 = _1;
    }

    /** 	if bp > length(ThisLine) then*/
    if (IS_SEQUENCE(_44ThisLine_48518)){
            _14452 = SEQ_PTR(_44ThisLine_48518)->length;
    }
    else {
        _14452 = 1;
    }
    if (_44bp_48522 <= _14452)
    goto L1; // [40] 101

    /** 		read_line()*/
    _61read_line();

    /** 		while ThisLine[bp] = '_' do*/
L2: 
    _2 = (int)SEQ_PTR(_44ThisLine_48518);
    _14454 = (int)*(((s1_ptr)_2)->base + _44bp_48522);
    if (binary_op_a(NOTEQ, _14454, 95)){
        _14454 = NOVALUE;
        goto L3; // [61] 86
    }
    _14454 = NOVALUE;

    /** 			trimming += 1*/
    _trimming_25415 = _trimming_25415 + 1;

    /** 			bp += 1*/
    _44bp_48522 = _44bp_48522 + 1;

    /** 		end while*/
    goto L2; // [83] 53
L3: 

    /** 		if trimming > 0 then*/
    if (_trimming_25415 <= 0)
    goto L4; // [88] 100

    /** 			ch = getch()*/
    _ch_25411 = _61getch();
    if (!IS_ATOM_INT(_ch_25411)) {
        _1 = (long)(DBL_PTR(_ch_25411)->dbl);
        DeRefDS(_ch_25411);
        _ch_25411 = _1;
    }
L4: 
L1: 

    /** 	while 1 do*/
L5: 

    /** 		if ch = END_OF_FILE_CHAR then*/
    if (_ch_25411 != 26)
    goto L6; // [110] 122

    /** 			CompileErr(129, cline)*/
    _44CompileErr(129, _cline_25413, 0);
L6: 

    /** 		if ch = ech then*/
    if (_ch_25411 != _ech_25410)
    goto L7; // [124] 180

    /** 			if ech != '"' then*/
    if (_ech_25410 == 34)
    goto L8; // [130] 139

    /** 				exit*/
    goto L9; // [136] 310
L8: 

    /** 			fch = getch()*/
    _fch_25412 = _61getch();
    if (!IS_ATOM_INT(_fch_25412)) {
        _1 = (long)(DBL_PTR(_fch_25412)->dbl);
        DeRefDS(_fch_25412);
        _fch_25412 = _1;
    }

    /** 			if fch = '"' then*/
    if (_fch_25412 != 34)
    goto LA; // [148] 175

    /** 				fch = getch()*/
    _fch_25412 = _61getch();
    if (!IS_ATOM_INT(_fch_25412)) {
        _1 = (long)(DBL_PTR(_fch_25412)->dbl);
        DeRefDS(_fch_25412);
        _fch_25412 = _1;
    }

    /** 				if fch = '"' then*/
    if (_fch_25412 != 34)
    goto LB; // [161] 170

    /** 					exit*/
    goto L9; // [167] 310
LB: 

    /** 				ungetch()*/
    _61ungetch();
LA: 

    /** 			ungetch()*/
    _61ungetch();
L7: 

    /** 		if ch != '\r' then*/
    if (_ch_25411 == 13)
    goto LC; // [182] 193

    /** 			string_text &= ch*/
    Append(&_string_text_25414, _string_text_25414, _ch_25411);
LC: 

    /** 		if bp > length(ThisLine) then*/
    if (IS_SEQUENCE(_44ThisLine_48518)){
            _14469 = SEQ_PTR(_44ThisLine_48518)->length;
    }
    else {
        _14469 = 1;
    }
    if (_44bp_48522 <= _14469)
    goto LD; // [202] 298

    /** 			read_line() -- sets bp to 1, btw.*/
    _61read_line();

    /** 			if trimming > 0 then*/
    if (_trimming_25415 <= 0)
    goto LE; // [212] 297

    /** 				while bp <= trimming and bp <= length(ThisLine) do*/
LF: 
    _14472 = (_44bp_48522 <= _trimming_25415);
    if (_14472 == 0) {
        goto L10; // [227] 296
    }
    if (IS_SEQUENCE(_44ThisLine_48518)){
            _14474 = SEQ_PTR(_44ThisLine_48518)->length;
    }
    else {
        _14474 = 1;
    }
    _14475 = (_44bp_48522 <= _14474);
    _14474 = NOVALUE;
    if (_14475 == 0)
    {
        DeRef(_14475);
        _14475 = NOVALUE;
        goto L10; // [243] 296
    }
    else{
        DeRef(_14475);
        _14475 = NOVALUE;
    }

    /** 					ch = ThisLine[bp]*/
    _2 = (int)SEQ_PTR(_44ThisLine_48518);
    _ch_25411 = (int)*(((s1_ptr)_2)->base + _44bp_48522);
    if (!IS_ATOM_INT(_ch_25411)){
        _ch_25411 = (long)DBL_PTR(_ch_25411)->dbl;
    }

    /** 					if ch != ' ' and ch != '\t' then*/
    _14477 = (_ch_25411 != 32);
    if (_14477 == 0) {
        goto L11; // [264] 281
    }
    _14479 = (_ch_25411 != 9);
    if (_14479 == 0)
    {
        DeRef(_14479);
        _14479 = NOVALUE;
        goto L11; // [273] 281
    }
    else{
        DeRef(_14479);
        _14479 = NOVALUE;
    }

    /** 						exit*/
    goto L10; // [278] 296
L11: 

    /** 					bp += 1*/
    _44bp_48522 = _44bp_48522 + 1;

    /** 				end while*/
    goto LF; // [293] 221
L10: 
LE: 
LD: 

    /** 		ch = getch()*/
    _ch_25411 = _61getch();
    if (!IS_ATOM_INT(_ch_25411)) {
        _1 = (long)(DBL_PTR(_ch_25411)->dbl);
        DeRefDS(_ch_25411);
        _ch_25411 = _1;
    }

    /** 	end while*/
    goto L5; // [307] 106
L9: 

    /** 	if length(string_text) > 0 and string_text[1] = '\n' then*/
    if (IS_SEQUENCE(_string_text_25414)){
            _14482 = SEQ_PTR(_string_text_25414)->length;
    }
    else {
        _14482 = 1;
    }
    _14483 = (_14482 > 0);
    _14482 = NOVALUE;
    if (_14483 == 0) {
        goto L12; // [319] 389
    }
    _2 = (int)SEQ_PTR(_string_text_25414);
    _14485 = (int)*(((s1_ptr)_2)->base + 1);
    _14486 = (_14485 == 10);
    _14485 = NOVALUE;
    if (_14486 == 0)
    {
        DeRef(_14486);
        _14486 = NOVALUE;
        goto L12; // [332] 389
    }
    else{
        DeRef(_14486);
        _14486 = NOVALUE;
    }

    /** 		string_text = string_text[2 .. $]*/
    if (IS_SEQUENCE(_string_text_25414)){
            _14487 = SEQ_PTR(_string_text_25414)->length;
    }
    else {
        _14487 = 1;
    }
    rhs_slice_target = (object_ptr)&_string_text_25414;
    RHS_Slice(_string_text_25414, 2, _14487);

    /** 		if length(string_text) > 0 and string_text[$] = '\n' then*/
    if (IS_SEQUENCE(_string_text_25414)){
            _14489 = SEQ_PTR(_string_text_25414)->length;
    }
    else {
        _14489 = 1;
    }
    _14490 = (_14489 > 0);
    _14489 = NOVALUE;
    if (_14490 == 0) {
        goto L13; // [354] 388
    }
    if (IS_SEQUENCE(_string_text_25414)){
            _14492 = SEQ_PTR(_string_text_25414)->length;
    }
    else {
        _14492 = 1;
    }
    _2 = (int)SEQ_PTR(_string_text_25414);
    _14493 = (int)*(((s1_ptr)_2)->base + _14492);
    _14494 = (_14493 == 10);
    _14493 = NOVALUE;
    if (_14494 == 0)
    {
        DeRef(_14494);
        _14494 = NOVALUE;
        goto L13; // [370] 388
    }
    else{
        DeRef(_14494);
        _14494 = NOVALUE;
    }

    /** 			string_text = string_text[1 .. $-1]*/
    if (IS_SEQUENCE(_string_text_25414)){
            _14495 = SEQ_PTR(_string_text_25414)->length;
    }
    else {
        _14495 = 1;
    }
    _14496 = _14495 - 1;
    _14495 = NOVALUE;
    rhs_slice_target = (object_ptr)&_string_text_25414;
    RHS_Slice(_string_text_25414, 1, _14496);
L13: 
L12: 

    /** 	return {STRING, NewStringSym(string_text)}*/
    RefDS(_string_text_25414);
    _14498 = _53NewStringSym(_string_text_25414);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 503;
    ((int *)_2)[2] = _14498;
    _14499 = MAKE_SEQ(_1);
    _14498 = NOVALUE;
    DeRefDSi(_string_text_25414);
    DeRef(_14472);
    _14472 = NOVALUE;
    DeRef(_14477);
    _14477 = NOVALUE;
    DeRef(_14483);
    _14483 = NOVALUE;
    DeRef(_14490);
    _14490 = NOVALUE;
    DeRef(_14496);
    _14496 = NOVALUE;
    return _14499;
    ;
}


int _61GetHexString(int _maxnibbles_25501)
{
    int _ch_25502 = NOVALUE;
    int _digit_25503 = NOVALUE;
    int _val_25504 = NOVALUE;
    int _cline_25505 = NOVALUE;
    int _nibble_25506 = NOVALUE;
    int _string_text_25507 = NOVALUE;
    int _14513 = NOVALUE;
    int _14512 = NOVALUE;
    int _0, _1, _2;
    

    /** 	cline = line_number*/
    _cline_25505 = _35line_number_16245;

    /** 	string_text = ""*/
    RefDS(_5);
    DeRef(_string_text_25507);
    _string_text_25507 = _5;

    /** 	nibble = 1*/
    _nibble_25506 = 1;

    /** 	val = -1*/
    DeRef(_val_25504);
    _val_25504 = -1;

    /** 	ch = getch()*/
    _ch_25502 = _61getch();
    if (!IS_ATOM_INT(_ch_25502)) {
        _1 = (long)(DBL_PTR(_ch_25502)->dbl);
        DeRefDS(_ch_25502);
        _ch_25502 = _1;
    }

    /** 	while 1 do*/
L1: 

    /** 		if ch = END_OF_FILE_CHAR then*/
    if (_ch_25502 != 26)
    goto L2; // [45] 57

    /** 			CompileErr(129, cline)*/
    _44CompileErr(129, _cline_25505, 0);
L2: 

    /** 		if ch = '"' then*/
    if (_ch_25502 != 34)
    goto L3; // [59] 68

    /** 			exit*/
    goto L4; // [65] 224
L3: 

    /** 		digit = find(ch, "0123456789ABCDEFabcdef_ \t\n\r")*/
    _digit_25503 = find_from(_ch_25502, _14503, 1);

    /** 		if digit = 0 then*/
    if (_digit_25503 != 0)
    goto L5; // [77] 89

    /** 			CompileErr(329)*/
    RefDS(_22023);
    _44CompileErr(329, _22023, 0);
L5: 

    /** 		if digit <= 23 then*/
    if (_digit_25503 > 23)
    goto L6; // [91] 177

    /** 			if digit != 23 then*/
    if (_digit_25503 == 23)
    goto L7; // [97] 212

    /** 				if digit > 16 then*/
    if (_digit_25503 <= 16)
    goto L8; // [103] 114

    /** 					digit -= 6*/
    _digit_25503 = _digit_25503 - 6;
L8: 

    /** 				if nibble = 1 then*/
    if (_nibble_25506 != 1)
    goto L9; // [116] 129

    /** 					val = digit - 1*/
    DeRef(_val_25504);
    _val_25504 = _digit_25503 - 1;
    if ((long)((unsigned long)_val_25504 +(unsigned long) HIGH_BITS) >= 0){
        _val_25504 = NewDouble((double)_val_25504);
    }
    goto LA; // [126] 167
L9: 

    /** 					val = val * 16 + digit - 1*/
    if (IS_ATOM_INT(_val_25504)) {
        if (_val_25504 == (short)_val_25504)
        _14512 = _val_25504 * 16;
        else
        _14512 = NewDouble(_val_25504 * (double)16);
    }
    else {
        _14512 = NewDouble(DBL_PTR(_val_25504)->dbl * (double)16);
    }
    if (IS_ATOM_INT(_14512)) {
        _14513 = _14512 + _digit_25503;
        if ((long)((unsigned long)_14513 + (unsigned long)HIGH_BITS) >= 0) 
        _14513 = NewDouble((double)_14513);
    }
    else {
        _14513 = NewDouble(DBL_PTR(_14512)->dbl + (double)_digit_25503);
    }
    DeRef(_14512);
    _14512 = NOVALUE;
    DeRef(_val_25504);
    if (IS_ATOM_INT(_14513)) {
        _val_25504 = _14513 - 1;
        if ((long)((unsigned long)_val_25504 +(unsigned long) HIGH_BITS) >= 0){
            _val_25504 = NewDouble((double)_val_25504);
        }
    }
    else {
        _val_25504 = NewDouble(DBL_PTR(_14513)->dbl - (double)1);
    }
    DeRef(_14513);
    _14513 = NOVALUE;

    /** 					if nibble = maxnibbles then*/
    if (_nibble_25506 != _maxnibbles_25501)
    goto LB; // [145] 166

    /** 						string_text &= val*/
    Ref(_val_25504);
    Append(&_string_text_25507, _string_text_25507, _val_25504);

    /** 						val = -1*/
    DeRef(_val_25504);
    _val_25504 = -1;

    /** 						nibble = 0*/
    _nibble_25506 = 0;
LB: 
LA: 

    /** 				nibble += 1*/
    _nibble_25506 = _nibble_25506 + 1;
    goto L7; // [174] 212
L6: 

    /** 			if val >= 0 then*/
    if (binary_op_a(LESS, _val_25504, 0)){
        goto LC; // [179] 195
    }

    /** 				string_text &= val*/
    Ref(_val_25504);
    Append(&_string_text_25507, _string_text_25507, _val_25504);

    /** 				val = -1*/
    DeRef(_val_25504);
    _val_25504 = -1;
LC: 

    /** 			nibble = 1*/
    _nibble_25506 = 1;

    /** 			if ch = '\n' then*/
    if (_ch_25502 != 10)
    goto LD; // [202] 211

    /** 				read_line()*/
    _61read_line();
LD: 
L7: 

    /** 		ch = getch()*/
    _ch_25502 = _61getch();
    if (!IS_ATOM_INT(_ch_25502)) {
        _1 = (long)(DBL_PTR(_ch_25502)->dbl);
        DeRefDS(_ch_25502);
        _ch_25502 = _1;
    }

    /** 	end while*/
    goto L1; // [221] 41
L4: 

    /** 	if val >= 0 then	*/
    if (binary_op_a(LESS, _val_25504, 0)){
        goto LE; // [226] 237
    }

    /** 		string_text &= val*/
    Ref(_val_25504);
    Append(&_string_text_25507, _string_text_25507, _val_25504);
LE: 

    /** 	return string_text*/
    DeRef(_val_25504);
    return _string_text_25507;
    ;
}


int _61GetBitString()
{
    int _ch_25552 = NOVALUE;
    int _digit_25553 = NOVALUE;
    int _val_25554 = NOVALUE;
    int _cline_25555 = NOVALUE;
    int _bitcnt_25556 = NOVALUE;
    int _string_text_25557 = NOVALUE;
    int _14535 = NOVALUE;
    int _14534 = NOVALUE;
    int _0, _1, _2;
    

    /** 	cline = line_number*/
    _cline_25555 = _35line_number_16245;

    /** 	string_text = ""*/
    RefDS(_5);
    DeRef(_string_text_25557);
    _string_text_25557 = _5;

    /** 	bitcnt = 1*/
    _bitcnt_25556 = 1;

    /** 	val = -1*/
    DeRef(_val_25554);
    _val_25554 = -1;

    /** 	ch = getch()*/
    _ch_25552 = _61getch();
    if (!IS_ATOM_INT(_ch_25552)) {
        _1 = (long)(DBL_PTR(_ch_25552)->dbl);
        DeRefDS(_ch_25552);
        _ch_25552 = _1;
    }

    /** 	while 1 do*/
L1: 

    /** 		if ch = END_OF_FILE_CHAR then*/
    if (_ch_25552 != 26)
    goto L2; // [43] 55

    /** 			CompileErr(129, cline)*/
    _44CompileErr(129, _cline_25555, 0);
L2: 

    /** 		if ch = '"' then*/
    if (_ch_25552 != 34)
    goto L3; // [57] 66

    /** 			exit*/
    goto L4; // [63] 186
L3: 

    /** 		digit = find(ch, "01_ \t\n\r")*/
    _digit_25553 = find_from(_ch_25552, _14527, 1);

    /** 		if digit = 0 then*/
    if (_digit_25553 != 0)
    goto L5; // [75] 87

    /** 			CompileErr(329)*/
    RefDS(_22023);
    _44CompileErr(329, _22023, 0);
L5: 

    /** 		if digit <= 3 then*/
    if (_digit_25553 > 3)
    goto L6; // [89] 139

    /** 			if digit != 3 then*/
    if (_digit_25553 == 3)
    goto L7; // [95] 174

    /** 				if bitcnt = 1 then*/
    if (_bitcnt_25556 != 1)
    goto L8; // [101] 114

    /** 					val = digit - 1*/
    DeRef(_val_25554);
    _val_25554 = _digit_25553 - 1;
    if ((long)((unsigned long)_val_25554 +(unsigned long) HIGH_BITS) >= 0){
        _val_25554 = NewDouble((double)_val_25554);
    }
    goto L9; // [111] 129
L8: 

    /** 					val = val * 2 + digit - 1*/
    if (IS_ATOM_INT(_val_25554) && IS_ATOM_INT(_val_25554)) {
        _14534 = _val_25554 + _val_25554;
        if ((long)((unsigned long)_14534 + (unsigned long)HIGH_BITS) >= 0) 
        _14534 = NewDouble((double)_14534);
    }
    else {
        if (IS_ATOM_INT(_val_25554)) {
            _14534 = NewDouble((double)_val_25554 + DBL_PTR(_val_25554)->dbl);
        }
        else {
            if (IS_ATOM_INT(_val_25554)) {
                _14534 = NewDouble(DBL_PTR(_val_25554)->dbl + (double)_val_25554);
            }
            else
            _14534 = NewDouble(DBL_PTR(_val_25554)->dbl + DBL_PTR(_val_25554)->dbl);
        }
    }
    if (IS_ATOM_INT(_14534)) {
        _14535 = _14534 + _digit_25553;
        if ((long)((unsigned long)_14535 + (unsigned long)HIGH_BITS) >= 0) 
        _14535 = NewDouble((double)_14535);
    }
    else {
        _14535 = NewDouble(DBL_PTR(_14534)->dbl + (double)_digit_25553);
    }
    DeRef(_14534);
    _14534 = NOVALUE;
    DeRef(_val_25554);
    if (IS_ATOM_INT(_14535)) {
        _val_25554 = _14535 - 1;
        if ((long)((unsigned long)_val_25554 +(unsigned long) HIGH_BITS) >= 0){
            _val_25554 = NewDouble((double)_val_25554);
        }
    }
    else {
        _val_25554 = NewDouble(DBL_PTR(_14535)->dbl - (double)1);
    }
    DeRef(_14535);
    _14535 = NOVALUE;
L9: 

    /** 				bitcnt += 1*/
    _bitcnt_25556 = _bitcnt_25556 + 1;
    goto L7; // [136] 174
L6: 

    /** 			if val >= 0 then*/
    if (binary_op_a(LESS, _val_25554, 0)){
        goto LA; // [141] 157
    }

    /** 				string_text &= val*/
    Ref(_val_25554);
    Append(&_string_text_25557, _string_text_25557, _val_25554);

    /** 				val = -1*/
    DeRef(_val_25554);
    _val_25554 = -1;
LA: 

    /** 			bitcnt = 1*/
    _bitcnt_25556 = 1;

    /** 			if ch = '\n' then*/
    if (_ch_25552 != 10)
    goto LB; // [164] 173

    /** 				read_line()*/
    _61read_line();
LB: 
L7: 

    /** 		ch = getch()*/
    _ch_25552 = _61getch();
    if (!IS_ATOM_INT(_ch_25552)) {
        _1 = (long)(DBL_PTR(_ch_25552)->dbl);
        DeRefDS(_ch_25552);
        _ch_25552 = _1;
    }

    /** 	end while*/
    goto L1; // [183] 39
L4: 

    /** 	if val >= 0 then	*/
    if (binary_op_a(LESS, _val_25554, 0)){
        goto LC; // [188] 199
    }

    /** 		string_text &= val*/
    Ref(_val_25554);
    Append(&_string_text_25557, _string_text_25557, _val_25554);
LC: 

    /** 	return string_text*/
    DeRef(_val_25554);
    return _string_text_25557;
    ;
}


int _61Scanner()
{
    int _fwd_inlined_set_qualified_fwd_at_441_25695 = NOVALUE;
    int _ch_25596 = NOVALUE;
    int _i_25597 = NOVALUE;
    int _sp_25598 = NOVALUE;
    int _prev_Nne_25599 = NOVALUE;
    int _pch_25600 = NOVALUE;
    int _cline_25601 = NOVALUE;
    int _yytext_25602 = NOVALUE;
    int _namespaces_25603 = NOVALUE;
    int _d_25604 = NOVALUE;
    int _tok_25606 = NOVALUE;
    int _is_int_25607 = NOVALUE;
    int _class_25608 = NOVALUE;
    int _name_25609 = NOVALUE;
    int _is_namespace_25668 = NOVALUE;
    int _basetype_25902 = NOVALUE;
    int _hdigit_25942 = NOVALUE;
    int _fch_26080 = NOVALUE;
    int _cnest_26257 = NOVALUE;
    int _ach_26286 = NOVALUE;
    int _31679 = NOVALUE;
    int _31678 = NOVALUE;
    int _31677 = NOVALUE;
    int _31676 = NOVALUE;
    int _31675 = NOVALUE;
    int _31674 = NOVALUE;
    int _31673 = NOVALUE;
    int _14931 = NOVALUE;
    int _14930 = NOVALUE;
    int _14928 = NOVALUE;
    int _14926 = NOVALUE;
    int _14925 = NOVALUE;
    int _14924 = NOVALUE;
    int _14922 = NOVALUE;
    int _14921 = NOVALUE;
    int _14920 = NOVALUE;
    int _14919 = NOVALUE;
    int _14917 = NOVALUE;
    int _14916 = NOVALUE;
    int _14914 = NOVALUE;
    int _14912 = NOVALUE;
    int _14911 = NOVALUE;
    int _14909 = NOVALUE;
    int _14907 = NOVALUE;
    int _14906 = NOVALUE;
    int _14904 = NOVALUE;
    int _14902 = NOVALUE;
    int _14901 = NOVALUE;
    int _14900 = NOVALUE;
    int _14899 = NOVALUE;
    int _14898 = NOVALUE;
    int _14896 = NOVALUE;
    int _14895 = NOVALUE;
    int _14885 = NOVALUE;
    int _14872 = NOVALUE;
    int _14868 = NOVALUE;
    int _14867 = NOVALUE;
    int _14863 = NOVALUE;
    int _14862 = NOVALUE;
    int _14861 = NOVALUE;
    int _14860 = NOVALUE;
    int _14858 = NOVALUE;
    int _14857 = NOVALUE;
    int _14854 = NOVALUE;
    int _14853 = NOVALUE;
    int _14852 = NOVALUE;
    int _14851 = NOVALUE;
    int _14850 = NOVALUE;
    int _14849 = NOVALUE;
    int _14847 = NOVALUE;
    int _14846 = NOVALUE;
    int _14845 = NOVALUE;
    int _14844 = NOVALUE;
    int _14843 = NOVALUE;
    int _14842 = NOVALUE;
    int _14840 = NOVALUE;
    int _14839 = NOVALUE;
    int _14836 = NOVALUE;
    int _14833 = NOVALUE;
    int _14828 = NOVALUE;
    int _14827 = NOVALUE;
    int _14826 = NOVALUE;
    int _14825 = NOVALUE;
    int _14824 = NOVALUE;
    int _14823 = NOVALUE;
    int _14821 = NOVALUE;
    int _14820 = NOVALUE;
    int _14819 = NOVALUE;
    int _14818 = NOVALUE;
    int _14817 = NOVALUE;
    int _14816 = NOVALUE;
    int _14814 = NOVALUE;
    int _14813 = NOVALUE;
    int _14810 = NOVALUE;
    int _14807 = NOVALUE;
    int _14805 = NOVALUE;
    int _14804 = NOVALUE;
    int _14800 = NOVALUE;
    int _14799 = NOVALUE;
    int _14795 = NOVALUE;
    int _14794 = NOVALUE;
    int _14793 = NOVALUE;
    int _14791 = NOVALUE;
    int _14786 = NOVALUE;
    int _14783 = NOVALUE;
    int _14782 = NOVALUE;
    int _14781 = NOVALUE;
    int _14780 = NOVALUE;
    int _14774 = NOVALUE;
    int _14772 = NOVALUE;
    int _14767 = NOVALUE;
    int _14766 = NOVALUE;
    int _14765 = NOVALUE;
    int _14764 = NOVALUE;
    int _14763 = NOVALUE;
    int _14762 = NOVALUE;
    int _14761 = NOVALUE;
    int _14759 = NOVALUE;
    int _14757 = NOVALUE;
    int _14756 = NOVALUE;
    int _14755 = NOVALUE;
    int _14754 = NOVALUE;
    int _14753 = NOVALUE;
    int _14751 = NOVALUE;
    int _14747 = NOVALUE;
    int _14746 = NOVALUE;
    int _14745 = NOVALUE;
    int _14744 = NOVALUE;
    int _14743 = NOVALUE;
    int _14741 = NOVALUE;
    int _14740 = NOVALUE;
    int _14738 = NOVALUE;
    int _14734 = NOVALUE;
    int _14731 = NOVALUE;
    int _14730 = NOVALUE;
    int _14728 = NOVALUE;
    int _14727 = NOVALUE;
    int _14726 = NOVALUE;
    int _14723 = NOVALUE;
    int _14721 = NOVALUE;
    int _14720 = NOVALUE;
    int _14716 = NOVALUE;
    int _14712 = NOVALUE;
    int _14709 = NOVALUE;
    int _14703 = NOVALUE;
    int _14695 = NOVALUE;
    int _14694 = NOVALUE;
    int _14693 = NOVALUE;
    int _14691 = NOVALUE;
    int _14688 = NOVALUE;
    int _14686 = NOVALUE;
    int _14684 = NOVALUE;
    int _14681 = NOVALUE;
    int _14678 = NOVALUE;
    int _14676 = NOVALUE;
    int _14674 = NOVALUE;
    int _14672 = NOVALUE;
    int _14671 = NOVALUE;
    int _14667 = NOVALUE;
    int _14664 = NOVALUE;
    int _14662 = NOVALUE;
    int _14659 = NOVALUE;
    int _14652 = NOVALUE;
    int _14650 = NOVALUE;
    int _14647 = NOVALUE;
    int _14641 = NOVALUE;
    int _14640 = NOVALUE;
    int _14639 = NOVALUE;
    int _14638 = NOVALUE;
    int _14637 = NOVALUE;
    int _14636 = NOVALUE;
    int _14635 = NOVALUE;
    int _14633 = NOVALUE;
    int _14631 = NOVALUE;
    int _14629 = NOVALUE;
    int _14627 = NOVALUE;
    int _14625 = NOVALUE;
    int _14624 = NOVALUE;
    int _14623 = NOVALUE;
    int _14622 = NOVALUE;
    int _14621 = NOVALUE;
    int _14619 = NOVALUE;
    int _14616 = NOVALUE;
    int _14614 = NOVALUE;
    int _14613 = NOVALUE;
    int _14612 = NOVALUE;
    int _14610 = NOVALUE;
    int _14605 = NOVALUE;
    int _14601 = NOVALUE;
    int _14598 = NOVALUE;
    int _14596 = NOVALUE;
    int _14595 = NOVALUE;
    int _14593 = NOVALUE;
    int _14591 = NOVALUE;
    int _14589 = NOVALUE;
    int _14588 = NOVALUE;
    int _14587 = NOVALUE;
    int _14585 = NOVALUE;
    int _14580 = NOVALUE;
    int _14577 = NOVALUE;
    int _14575 = NOVALUE;
    int _14572 = NOVALUE;
    int _14571 = NOVALUE;
    int _14569 = NOVALUE;
    int _14568 = NOVALUE;
    int _14567 = NOVALUE;
    int _14566 = NOVALUE;
    int _14565 = NOVALUE;
    int _14564 = NOVALUE;
    int _14563 = NOVALUE;
    int _14562 = NOVALUE;
    int _14561 = NOVALUE;
    int _14560 = NOVALUE;
    int _14559 = NOVALUE;
    int _14558 = NOVALUE;
    int _14557 = NOVALUE;
    int _14552 = NOVALUE;
    int _14550 = NOVALUE;
    int _14547 = NOVALUE;
    int _14545 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer is_int, class*/

    /** 	sequence name*/

    /** 	while TRUE do*/
L1: 
    if (_13TRUE_436 == 0)
    {
        goto L2; // [12] 3802
    }
    else{
    }

    /** 		ch = getch()*/
    _ch_25596 = _61getch();
    if (!IS_ATOM_INT(_ch_25596)) {
        _1 = (long)(DBL_PTR(_ch_25596)->dbl);
        DeRefDS(_ch_25596);
        _ch_25596 = _1;
    }

    /** 		while ch = ' ' or ch = '\t' do*/
L3: 
    _14545 = (_ch_25596 == 32);
    if (_14545 != 0) {
        goto L4; // [31] 44
    }
    _14547 = (_ch_25596 == 9);
    if (_14547 == 0)
    {
        DeRef(_14547);
        _14547 = NOVALUE;
        goto L5; // [40] 56
    }
    else{
        DeRef(_14547);
        _14547 = NOVALUE;
    }
L4: 

    /** 			ch = getch()*/
    _ch_25596 = _61getch();
    if (!IS_ATOM_INT(_ch_25596)) {
        _1 = (long)(DBL_PTR(_ch_25596)->dbl);
        DeRefDS(_ch_25596);
        _ch_25596 = _1;
    }

    /** 		end while*/
    goto L3; // [53] 27
L5: 

    /** 		class = char_class[ch]*/
    _2 = (int)SEQ_PTR(_61char_class_23903);
    _class_25608 = (int)*(((s1_ptr)_2)->base + _ch_25596);

    /** 		if class = LETTER or ch = '_' then*/
    _14550 = (_class_25608 == -2);
    if (_14550 != 0) {
        goto L6; // [72] 85
    }
    _14552 = (_ch_25596 == 95);
    if (_14552 == 0)
    {
        DeRef(_14552);
        _14552 = NOVALUE;
        goto L7; // [81] 1282
    }
    else{
        DeRef(_14552);
        _14552 = NOVALUE;
    }
L6: 

    /** 			sp = bp*/
    _sp_25598 = _44bp_48522;

    /** 			pch = ch*/
    _pch_25600 = _ch_25596;

    /** 			ch = getch()*/
    _ch_25596 = _61getch();
    if (!IS_ATOM_INT(_ch_25596)) {
        _1 = (long)(DBL_PTR(_ch_25596)->dbl);
        DeRefDS(_ch_25596);
        _ch_25596 = _1;
    }

    /** 			if ch = '"' then*/
    if (_ch_25596 != 34)
    goto L8; // [108] 222

    /** 				switch pch do*/
    _0 = _pch_25600;
    switch ( _0 ){ 

        /** 					case 'x' then*/
        case 120:

        /** 						return {STRING, NewStringSym(GetHexString(2))}*/
        _14557 = _61GetHexString(2);
        _14558 = _53NewStringSym(_14557);
        _14557 = NOVALUE;
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = 503;
        ((int *)_2)[2] = _14558;
        _14559 = MAKE_SEQ(_1);
        _14558 = NOVALUE;
        DeRef(_yytext_25602);
        DeRef(_namespaces_25603);
        DeRef(_d_25604);
        DeRef(_tok_25606);
        DeRef(_name_25609);
        DeRef(_14545);
        _14545 = NOVALUE;
        DeRef(_14550);
        _14550 = NOVALUE;
        return _14559;
        goto L9; // [143] 221

        /** 					case 'u' then*/
        case 117:

        /** 						return {STRING, NewStringSym(GetHexString(4))}*/
        _14560 = _61GetHexString(4);
        _14561 = _53NewStringSym(_14560);
        _14560 = NOVALUE;
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = 503;
        ((int *)_2)[2] = _14561;
        _14562 = MAKE_SEQ(_1);
        _14561 = NOVALUE;
        DeRef(_yytext_25602);
        DeRef(_namespaces_25603);
        DeRef(_d_25604);
        DeRef(_tok_25606);
        DeRef(_name_25609);
        DeRef(_14545);
        _14545 = NOVALUE;
        DeRef(_14550);
        _14550 = NOVALUE;
        DeRef(_14559);
        _14559 = NOVALUE;
        return _14562;
        goto L9; // [169] 221

        /** 					case 'U' then*/
        case 85:

        /** 						return {STRING, NewStringSym(GetHexString(8))}*/
        _14563 = _61GetHexString(8);
        _14564 = _53NewStringSym(_14563);
        _14563 = NOVALUE;
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = 503;
        ((int *)_2)[2] = _14564;
        _14565 = MAKE_SEQ(_1);
        _14564 = NOVALUE;
        DeRef(_yytext_25602);
        DeRef(_namespaces_25603);
        DeRef(_d_25604);
        DeRef(_tok_25606);
        DeRef(_name_25609);
        DeRef(_14545);
        _14545 = NOVALUE;
        DeRef(_14550);
        _14550 = NOVALUE;
        DeRef(_14559);
        _14559 = NOVALUE;
        DeRef(_14562);
        _14562 = NOVALUE;
        return _14565;
        goto L9; // [195] 221

        /** 					case 'b' then*/
        case 98:

        /** 						return {STRING, NewStringSym(GetBitString())}*/
        _14566 = _61GetBitString();
        _14567 = _53NewStringSym(_14566);
        _14566 = NOVALUE;
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = 503;
        ((int *)_2)[2] = _14567;
        _14568 = MAKE_SEQ(_1);
        _14567 = NOVALUE;
        DeRef(_yytext_25602);
        DeRef(_namespaces_25603);
        DeRef(_d_25604);
        DeRef(_tok_25606);
        DeRef(_name_25609);
        DeRef(_14545);
        _14545 = NOVALUE;
        DeRef(_14550);
        _14550 = NOVALUE;
        DeRef(_14559);
        _14559 = NOVALUE;
        DeRef(_14562);
        _14562 = NOVALUE;
        DeRef(_14565);
        _14565 = NOVALUE;
        return _14568;
    ;}L9: 
L8: 

    /** 			while id_char[ch] do*/
LA: 
    _2 = (int)SEQ_PTR(_61id_char_23904);
    _14569 = (int)*(((s1_ptr)_2)->base + _ch_25596);
    if (_14569 == 0)
    {
        _14569 = NOVALUE;
        goto LB; // [233] 248
    }
    else{
        _14569 = NOVALUE;
    }

    /** 				ch = getch()*/
    _ch_25596 = _61getch();
    if (!IS_ATOM_INT(_ch_25596)) {
        _1 = (long)(DBL_PTR(_ch_25596)->dbl);
        DeRefDS(_ch_25596);
        _ch_25596 = _1;
    }

    /** 			end while*/
    goto LA; // [245] 227
LB: 

    /** 			yytext = ThisLine[sp-1..bp-2]*/
    _14571 = _sp_25598 - 1;
    if ((long)((unsigned long)_14571 +(unsigned long) HIGH_BITS) >= 0){
        _14571 = NewDouble((double)_14571);
    }
    _14572 = _44bp_48522 - 2;
    rhs_slice_target = (object_ptr)&_yytext_25602;
    RHS_Slice(_44ThisLine_48518, _14571, _14572);

    /** 			ungetch()*/
    _61ungetch();

    /** 			ch = getch()*/
    _ch_25596 = _61getch();
    if (!IS_ATOM_INT(_ch_25596)) {
        _1 = (long)(DBL_PTR(_ch_25596)->dbl);
        DeRefDS(_ch_25596);
        _ch_25596 = _1;
    }

    /** 			while ch = ' ' or ch = '\t' do*/
LC: 
    _14575 = (_ch_25596 == 32);
    if (_14575 != 0) {
        goto LD; // [287] 300
    }
    _14577 = (_ch_25596 == 9);
    if (_14577 == 0)
    {
        DeRef(_14577);
        _14577 = NOVALUE;
        goto LE; // [296] 312
    }
    else{
        DeRef(_14577);
        _14577 = NOVALUE;
    }
LD: 

    /** 				ch = getch()*/
    _ch_25596 = _61getch();
    if (!IS_ATOM_INT(_ch_25596)) {
        _1 = (long)(DBL_PTR(_ch_25596)->dbl);
        DeRefDS(_ch_25596);
        _ch_25596 = _1;
    }

    /** 			end while*/
    goto LC; // [309] 283
LE: 

    /** 			integer is_namespace*/

    /** 			if might_be_namespace then*/
    if (_61might_be_namespace_25400 == 0)
    {
        goto LF; // [318] 361
    }
    else{
    }

    /** 				tok = keyfind(yytext, -1, , -1 )*/
    RefDS(_yytext_25602);
    _31679 = _53hashfn(_yytext_25602);
    RefDS(_yytext_25602);
    _0 = _tok_25606;
    _tok_25606 = _53keyfind(_yytext_25602, -1, _35current_file_no_16244, -1, _31679);
    DeRef(_0);
    _31679 = NOVALUE;

    /** 				is_namespace = tok[T_ID] = NAMESPACE*/
    _2 = (int)SEQ_PTR(_tok_25606);
    _14580 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_14580)) {
        _is_namespace_25668 = (_14580 == 523);
    }
    else {
        _is_namespace_25668 = binary_op(EQUALS, _14580, 523);
    }
    _14580 = NOVALUE;
    if (!IS_ATOM_INT(_is_namespace_25668)) {
        _1 = (long)(DBL_PTR(_is_namespace_25668)->dbl);
        DeRefDS(_is_namespace_25668);
        _is_namespace_25668 = _1;
    }

    /** 				might_be_namespace = 0*/
    _61might_be_namespace_25400 = 0;
    goto L10; // [358] 384
LF: 

    /** 				is_namespace = ch = ':'*/
    _is_namespace_25668 = (_ch_25596 == 58);

    /** 				tok = keyfind(yytext, -1, , is_namespace )*/
    RefDS(_yytext_25602);
    _31678 = _53hashfn(_yytext_25602);
    RefDS(_yytext_25602);
    _0 = _tok_25606;
    _tok_25606 = _53keyfind(_yytext_25602, -1, _35current_file_no_16244, _is_namespace_25668, _31678);
    DeRef(_0);
    _31678 = NOVALUE;
L10: 

    /** 			if not is_namespace then*/
    if (_is_namespace_25668 != 0)
    goto L11; // [388] 396

    /** 				ungetch()*/
    _61ungetch();
L11: 

    /** 			if is_namespace then*/
    if (_is_namespace_25668 == 0)
    {
        goto L12; // [398] 1119
    }
    else{
    }

    /** 				namespaces = yytext*/
    RefDS(_yytext_25602);
    DeRef(_namespaces_25603);
    _namespaces_25603 = _yytext_25602;

    /** 				if tok[T_ID] = NAMESPACE then -- known namespace*/
    _2 = (int)SEQ_PTR(_tok_25606);
    _14585 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _14585, 523)){
        _14585 = NOVALUE;
        goto L13; // [420] 974
    }
    _14585 = NOVALUE;

    /** 					set_qualified_fwd( SymTab[tok[T_SYM]][S_OBJ] )*/
    _2 = (int)SEQ_PTR(_tok_25606);
    _14587 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!IS_ATOM_INT(_14587)){
        _14588 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_14587)->dbl));
    }
    else{
        _14588 = (int)*(((s1_ptr)_2)->base + _14587);
    }
    _2 = (int)SEQ_PTR(_14588);
    _14589 = (int)*(((s1_ptr)_2)->base + 1);
    _14588 = NOVALUE;
    Ref(_14589);
    DeRef(_fwd_inlined_set_qualified_fwd_at_441_25695);
    _fwd_inlined_set_qualified_fwd_at_441_25695 = _14589;
    _14589 = NOVALUE;
    if (!IS_ATOM_INT(_fwd_inlined_set_qualified_fwd_at_441_25695)) {
        _1 = (long)(DBL_PTR(_fwd_inlined_set_qualified_fwd_at_441_25695)->dbl);
        DeRefDS(_fwd_inlined_set_qualified_fwd_at_441_25695);
        _fwd_inlined_set_qualified_fwd_at_441_25695 = _1;
    }

    /** 	qualified_fwd = fwd*/
    _61qualified_fwd_23928 = _fwd_inlined_set_qualified_fwd_at_441_25695;

    /** end procedure*/
    goto L14; // [456] 459
L14: 
    DeRef(_fwd_inlined_set_qualified_fwd_at_441_25695);
    _fwd_inlined_set_qualified_fwd_at_441_25695 = NOVALUE;

    /** 					ch = getch()*/
    _ch_25596 = _61getch();
    if (!IS_ATOM_INT(_ch_25596)) {
        _1 = (long)(DBL_PTR(_ch_25596)->dbl);
        DeRefDS(_ch_25596);
        _ch_25596 = _1;
    }

    /** 					while ch = ' ' or ch = '\t' do*/
L15: 
    _14591 = (_ch_25596 == 32);
    if (_14591 != 0) {
        goto L16; // [477] 490
    }
    _14593 = (_ch_25596 == 9);
    if (_14593 == 0)
    {
        DeRef(_14593);
        _14593 = NOVALUE;
        goto L17; // [486] 502
    }
    else{
        DeRef(_14593);
        _14593 = NOVALUE;
    }
L16: 

    /** 						ch = getch()*/
    _ch_25596 = _61getch();
    if (!IS_ATOM_INT(_ch_25596)) {
        _1 = (long)(DBL_PTR(_ch_25596)->dbl);
        DeRefDS(_ch_25596);
        _ch_25596 = _1;
    }

    /** 					end while*/
    goto L15; // [499] 473
L17: 

    /** 					yytext = ""*/
    RefDS(_5);
    DeRef(_yytext_25602);
    _yytext_25602 = _5;

    /** 					if char_class[ch] = LETTER or ch = '_' then*/
    _2 = (int)SEQ_PTR(_61char_class_23903);
    _14595 = (int)*(((s1_ptr)_2)->base + _ch_25596);
    _14596 = (_14595 == -2);
    _14595 = NOVALUE;
    if (_14596 != 0) {
        goto L18; // [523] 536
    }
    _14598 = (_ch_25596 == 95);
    if (_14598 == 0)
    {
        DeRef(_14598);
        _14598 = NOVALUE;
        goto L19; // [532] 589
    }
    else{
        DeRef(_14598);
        _14598 = NOVALUE;
    }
L18: 

    /** 						yytext &= ch*/
    Append(&_yytext_25602, _yytext_25602, _ch_25596);

    /** 						ch = getch()*/
    _ch_25596 = _61getch();
    if (!IS_ATOM_INT(_ch_25596)) {
        _1 = (long)(DBL_PTR(_ch_25596)->dbl);
        DeRefDS(_ch_25596);
        _ch_25596 = _1;
    }

    /** 						while id_char[ch] = TRUE do*/
L1A: 
    _2 = (int)SEQ_PTR(_61id_char_23904);
    _14601 = (int)*(((s1_ptr)_2)->base + _ch_25596);
    if (_14601 != _13TRUE_436)
    goto L1B; // [562] 584

    /** 							yytext &= ch*/
    Append(&_yytext_25602, _yytext_25602, _ch_25596);

    /** 							ch = getch()*/
    _ch_25596 = _61getch();
    if (!IS_ATOM_INT(_ch_25596)) {
        _1 = (long)(DBL_PTR(_ch_25596)->dbl);
        DeRefDS(_ch_25596);
        _ch_25596 = _1;
    }

    /** 						end while*/
    goto L1A; // [581] 554
L1B: 

    /** 						ungetch()*/
    _61ungetch();
L19: 

    /** 					if length(yytext) = 0 then*/
    if (IS_SEQUENCE(_yytext_25602)){
            _14605 = SEQ_PTR(_yytext_25602)->length;
    }
    else {
        _14605 = 1;
    }
    if (_14605 != 0)
    goto L1C; // [594] 606

    /** 						CompileErr(32)*/
    RefDS(_22023);
    _44CompileErr(32, _22023, 0);
L1C: 

    /** 				    if Parser_mode = PAM_RECORD then*/
    if (_35Parser_mode_16349 != 1)
    goto L1D; // [612] 773

    /** 		                Recorded = append(Recorded,yytext)*/
    RefDS(_yytext_25602);
    Append(&_35Recorded_16350, _35Recorded_16350, _yytext_25602);

    /** 		                Ns_recorded = append(Ns_recorded,namespaces)*/
    RefDS(_namespaces_25603);
    Append(&_35Ns_recorded_16351, _35Ns_recorded_16351, _namespaces_25603);

    /** 		                Ns_recorded_sym &= tok[T_SYM]*/
    _2 = (int)SEQ_PTR(_tok_25606);
    _14610 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_35Ns_recorded_sym_16353) && IS_ATOM(_14610)) {
        Ref(_14610);
        Append(&_35Ns_recorded_sym_16353, _35Ns_recorded_sym_16353, _14610);
    }
    else if (IS_ATOM(_35Ns_recorded_sym_16353) && IS_SEQUENCE(_14610)) {
    }
    else {
        Concat((object_ptr)&_35Ns_recorded_sym_16353, _35Ns_recorded_sym_16353, _14610);
    }
    _14610 = NOVALUE;

    /** 		                prev_Nne = No_new_entry*/
    _prev_Nne_25599 = _53No_new_entry_47263;

    /** 						No_new_entry = 1*/
    _53No_new_entry_47263 = 1;

    /** 						tok = keyfind(yytext, SymTab[tok[T_SYM]][S_OBJ])*/
    _2 = (int)SEQ_PTR(_tok_25606);
    _14612 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!IS_ATOM_INT(_14612)){
        _14613 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_14612)->dbl));
    }
    else{
        _14613 = (int)*(((s1_ptr)_2)->base + _14612);
    }
    _2 = (int)SEQ_PTR(_14613);
    _14614 = (int)*(((s1_ptr)_2)->base + 1);
    _14613 = NOVALUE;
    RefDS(_yytext_25602);
    _31677 = _53hashfn(_yytext_25602);
    RefDS(_yytext_25602);
    Ref(_14614);
    _0 = _tok_25606;
    _tok_25606 = _53keyfind(_yytext_25602, _14614, _35current_file_no_16244, 0, _31677);
    DeRef(_0);
    _14614 = NOVALUE;
    _31677 = NOVALUE;

    /** 						if tok[T_ID] = IGNORED then*/
    _2 = (int)SEQ_PTR(_tok_25606);
    _14616 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _14616, 509)){
        _14616 = NOVALUE;
        goto L1E; // [712] 729
    }
    _14616 = NOVALUE;

    /** 							Recorded_sym &= 0 -- must resolve on call site*/
    Append(&_35Recorded_sym_16352, _35Recorded_sym_16352, 0);
    goto L1F; // [726] 746
L1E: 

    /** 							Recorded_sym &= tok[T_SYM] -- fallback when symbol is undefined on call site*/
    _2 = (int)SEQ_PTR(_tok_25606);
    _14619 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_35Recorded_sym_16352) && IS_ATOM(_14619)) {
        Ref(_14619);
        Append(&_35Recorded_sym_16352, _35Recorded_sym_16352, _14619);
    }
    else if (IS_ATOM(_35Recorded_sym_16352) && IS_SEQUENCE(_14619)) {
    }
    else {
        Concat((object_ptr)&_35Recorded_sym_16352, _35Recorded_sym_16352, _14619);
    }
    _14619 = NOVALUE;
L1F: 

    /** 		                No_new_entry = prev_Nne*/
    _53No_new_entry_47263 = _prev_Nne_25599;

    /** 		                return {RECORDED,length(Recorded)}*/
    if (IS_SEQUENCE(_35Recorded_16350)){
            _14621 = SEQ_PTR(_35Recorded_16350)->length;
    }
    else {
        _14621 = 1;
    }
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 508;
    ((int *)_2)[2] = _14621;
    _14622 = MAKE_SEQ(_1);
    _14621 = NOVALUE;
    DeRef(_yytext_25602);
    DeRef(_namespaces_25603);
    DeRef(_d_25604);
    DeRef(_tok_25606);
    DeRef(_name_25609);
    DeRef(_14545);
    _14545 = NOVALUE;
    DeRef(_14550);
    _14550 = NOVALUE;
    DeRef(_14559);
    _14559 = NOVALUE;
    DeRef(_14562);
    _14562 = NOVALUE;
    DeRef(_14565);
    _14565 = NOVALUE;
    DeRef(_14568);
    _14568 = NOVALUE;
    DeRef(_14571);
    _14571 = NOVALUE;
    DeRef(_14572);
    _14572 = NOVALUE;
    DeRef(_14575);
    _14575 = NOVALUE;
    _14587 = NOVALUE;
    DeRef(_14591);
    _14591 = NOVALUE;
    _14601 = NOVALUE;
    DeRef(_14596);
    _14596 = NOVALUE;
    _14612 = NOVALUE;
    return _14622;
    goto L20; // [770] 915
L1D: 

    /** 						tok = keyfind(yytext, SymTab[tok[T_SYM]][S_OBJ])*/
    _2 = (int)SEQ_PTR(_tok_25606);
    _14623 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!IS_ATOM_INT(_14623)){
        _14624 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_14623)->dbl));
    }
    else{
        _14624 = (int)*(((s1_ptr)_2)->base + _14623);
    }
    _2 = (int)SEQ_PTR(_14624);
    _14625 = (int)*(((s1_ptr)_2)->base + 1);
    _14624 = NOVALUE;
    RefDS(_yytext_25602);
    _31676 = _53hashfn(_yytext_25602);
    RefDS(_yytext_25602);
    Ref(_14625);
    _0 = _tok_25606;
    _tok_25606 = _53keyfind(_yytext_25602, _14625, _35current_file_no_16244, 0, _31676);
    DeRef(_0);
    _14625 = NOVALUE;
    _31676 = NOVALUE;

    /** 						if tok[T_ID] = VARIABLE then*/
    _2 = (int)SEQ_PTR(_tok_25606);
    _14627 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _14627, -100)){
        _14627 = NOVALUE;
        goto L21; // [817] 834
    }
    _14627 = NOVALUE;

    /** 							tok[T_ID] = QUALIFIED_VARIABLE*/
    _2 = (int)SEQ_PTR(_tok_25606);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _tok_25606 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = 512;
    DeRef(_1);
    goto L22; // [831] 914
L21: 

    /** 						elsif tok[T_ID] = FUNC then*/
    _2 = (int)SEQ_PTR(_tok_25606);
    _14629 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _14629, 501)){
        _14629 = NOVALUE;
        goto L23; // [844] 861
    }
    _14629 = NOVALUE;

    /** 							tok[T_ID] = QUALIFIED_FUNC*/
    _2 = (int)SEQ_PTR(_tok_25606);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _tok_25606 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = 520;
    DeRef(_1);
    goto L22; // [858] 914
L23: 

    /** 						elsif tok[T_ID] = PROC then*/
    _2 = (int)SEQ_PTR(_tok_25606);
    _14631 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _14631, 27)){
        _14631 = NOVALUE;
        goto L24; // [871] 888
    }
    _14631 = NOVALUE;

    /** 							tok[T_ID] = QUALIFIED_PROC*/
    _2 = (int)SEQ_PTR(_tok_25606);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _tok_25606 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = 521;
    DeRef(_1);
    goto L22; // [885] 914
L24: 

    /** 						elsif tok[T_ID] = TYPE then*/
    _2 = (int)SEQ_PTR(_tok_25606);
    _14633 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _14633, 504)){
        _14633 = NOVALUE;
        goto L25; // [898] 913
    }
    _14633 = NOVALUE;

    /** 							tok[T_ID] = QUALIFIED_TYPE*/
    _2 = (int)SEQ_PTR(_tok_25606);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _tok_25606 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = 522;
    DeRef(_1);
L25: 
L22: 
L20: 

    /** 					if atom( tok[T_SYM] ) and  SymTab[tok[T_SYM]][S_SCOPE] != SC_UNDEFINED then*/
    _2 = (int)SEQ_PTR(_tok_25606);
    _14635 = (int)*(((s1_ptr)_2)->base + 2);
    _14636 = IS_ATOM(_14635);
    _14635 = NOVALUE;
    if (_14636 == 0) {
        goto L26; // [926] 1269
    }
    _2 = (int)SEQ_PTR(_tok_25606);
    _14638 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!IS_ATOM_INT(_14638)){
        _14639 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_14638)->dbl));
    }
    else{
        _14639 = (int)*(((s1_ptr)_2)->base + _14638);
    }
    _2 = (int)SEQ_PTR(_14639);
    _14640 = (int)*(((s1_ptr)_2)->base + 4);
    _14639 = NOVALUE;
    if (IS_ATOM_INT(_14640)) {
        _14641 = (_14640 != 9);
    }
    else {
        _14641 = binary_op(NOTEQ, _14640, 9);
    }
    _14640 = NOVALUE;
    if (_14641 == 0) {
        DeRef(_14641);
        _14641 = NOVALUE;
        goto L26; // [955] 1269
    }
    else {
        if (!IS_ATOM_INT(_14641) && DBL_PTR(_14641)->dbl == 0.0){
            DeRef(_14641);
            _14641 = NOVALUE;
            goto L26; // [955] 1269
        }
        DeRef(_14641);
        _14641 = NOVALUE;
    }
    DeRef(_14641);
    _14641 = NOVALUE;

    /** 						set_qualified_fwd( -1 )*/

    /** 	qualified_fwd = fwd*/
    _61qualified_fwd_23928 = -1;

    /** end procedure*/
    goto L26; // [967] 1269
    goto L26; // [971] 1269
L13: 

    /** 					ungetch()*/
    _61ungetch();

    /** 				    if Parser_mode = PAM_RECORD then*/
    if (_35Parser_mode_16349 != 1)
    goto L26; // [984] 1269

    /** 		                Ns_recorded &= 0*/
    Append(&_35Ns_recorded_16351, _35Ns_recorded_16351, 0);

    /** 		                Ns_recorded_sym &= 0*/
    Append(&_35Ns_recorded_sym_16353, _35Ns_recorded_sym_16353, 0);

    /** 		                Recorded = append(Recorded,yytext)*/
    RefDS(_yytext_25602);
    Append(&_35Recorded_16350, _35Recorded_16350, _yytext_25602);

    /** 		                prev_Nne = No_new_entry*/
    _prev_Nne_25599 = _53No_new_entry_47263;

    /** 						No_new_entry = 1*/
    _53No_new_entry_47263 = 1;

    /** 						tok = keyfind(yytext, -1)*/
    RefDS(_yytext_25602);
    _31675 = _53hashfn(_yytext_25602);
    RefDS(_yytext_25602);
    _0 = _tok_25606;
    _tok_25606 = _53keyfind(_yytext_25602, -1, _35current_file_no_16244, 0, _31675);
    DeRef(_0);
    _31675 = NOVALUE;

    /** 						if tok[T_ID] = IGNORED then*/
    _2 = (int)SEQ_PTR(_tok_25606);
    _14647 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _14647, 509)){
        _14647 = NOVALUE;
        goto L27; // [1060] 1077
    }
    _14647 = NOVALUE;

    /** 							Recorded_sym &= 0 -- must resolve on call site*/
    Append(&_35Recorded_sym_16352, _35Recorded_sym_16352, 0);
    goto L28; // [1074] 1094
L27: 

    /** 							Recorded_sym &= tok[T_SYM] -- fallback when symbol is undefined on call site*/
    _2 = (int)SEQ_PTR(_tok_25606);
    _14650 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_35Recorded_sym_16352) && IS_ATOM(_14650)) {
        Ref(_14650);
        Append(&_35Recorded_sym_16352, _35Recorded_sym_16352, _14650);
    }
    else if (IS_ATOM(_35Recorded_sym_16352) && IS_SEQUENCE(_14650)) {
    }
    else {
        Concat((object_ptr)&_35Recorded_sym_16352, _35Recorded_sym_16352, _14650);
    }
    _14650 = NOVALUE;
L28: 

    /** 		                No_new_entry = prev_Nne*/
    _53No_new_entry_47263 = _prev_Nne_25599;

    /** 		                tok = {RECORDED,length(Recorded)}*/
    if (IS_SEQUENCE(_35Recorded_16350)){
            _14652 = SEQ_PTR(_35Recorded_16350)->length;
    }
    else {
        _14652 = 1;
    }
    DeRef(_tok_25606);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 508;
    ((int *)_2)[2] = _14652;
    _tok_25606 = MAKE_SEQ(_1);
    _14652 = NOVALUE;
    goto L26; // [1116] 1269
L12: 

    /** 				set_qualified_fwd( -1 )*/

    /** 	qualified_fwd = fwd*/
    _61qualified_fwd_23928 = -1;

    /** end procedure*/
    goto L29; // [1128] 1131
L29: 

    /** 			    if Parser_mode = PAM_RECORD then*/
    if (_35Parser_mode_16349 != 1)
    goto L2A; // [1137] 1268

    /** 	                Ns_recorded_sym &= 0*/
    Append(&_35Ns_recorded_sym_16353, _35Ns_recorded_sym_16353, 0);

    /** 						Recorded = append(Recorded, yytext)*/
    RefDS(_yytext_25602);
    Append(&_35Recorded_16350, _35Recorded_16350, _yytext_25602);

    /** 		                Ns_recorded &= 0*/
    Append(&_35Ns_recorded_16351, _35Ns_recorded_16351, 0);

    /** 		                prev_Nne = No_new_entry*/
    _prev_Nne_25599 = _53No_new_entry_47263;

    /** 						No_new_entry = 1*/
    _53No_new_entry_47263 = 1;

    /** 						tok = keyfind(yytext, -1)*/
    RefDS(_yytext_25602);
    _31674 = _53hashfn(_yytext_25602);
    RefDS(_yytext_25602);
    _0 = _tok_25606;
    _tok_25606 = _53keyfind(_yytext_25602, -1, _35current_file_no_16244, 0, _31674);
    DeRef(_0);
    _31674 = NOVALUE;

    /** 						if tok[T_ID] = IGNORED then*/
    _2 = (int)SEQ_PTR(_tok_25606);
    _14659 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _14659, 509)){
        _14659 = NOVALUE;
        goto L2B; // [1213] 1230
    }
    _14659 = NOVALUE;

    /** 							Recorded_sym &= 0 -- must resolve on call site*/
    Append(&_35Recorded_sym_16352, _35Recorded_sym_16352, 0);
    goto L2C; // [1227] 1247
L2B: 

    /** 							Recorded_sym &= tok[T_SYM] -- fallback when symbol is undefined on call site*/
    _2 = (int)SEQ_PTR(_tok_25606);
    _14662 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_35Recorded_sym_16352) && IS_ATOM(_14662)) {
        Ref(_14662);
        Append(&_35Recorded_sym_16352, _35Recorded_sym_16352, _14662);
    }
    else if (IS_ATOM(_35Recorded_sym_16352) && IS_SEQUENCE(_14662)) {
    }
    else {
        Concat((object_ptr)&_35Recorded_sym_16352, _35Recorded_sym_16352, _14662);
    }
    _14662 = NOVALUE;
L2C: 

    /** 		                No_new_entry = prev_Nne*/
    _53No_new_entry_47263 = _prev_Nne_25599;

    /** 	                tok = {RECORDED, length(Recorded)}*/
    if (IS_SEQUENCE(_35Recorded_16350)){
            _14664 = SEQ_PTR(_35Recorded_16350)->length;
    }
    else {
        _14664 = 1;
    }
    DeRef(_tok_25606);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 508;
    ((int *)_2)[2] = _14664;
    _tok_25606 = MAKE_SEQ(_1);
    _14664 = NOVALUE;
L2A: 
L26: 

    /** 			return tok*/
    DeRef(_yytext_25602);
    DeRef(_namespaces_25603);
    DeRef(_d_25604);
    DeRef(_name_25609);
    DeRef(_14545);
    _14545 = NOVALUE;
    DeRef(_14550);
    _14550 = NOVALUE;
    DeRef(_14559);
    _14559 = NOVALUE;
    DeRef(_14562);
    _14562 = NOVALUE;
    DeRef(_14565);
    _14565 = NOVALUE;
    DeRef(_14568);
    _14568 = NOVALUE;
    DeRef(_14571);
    _14571 = NOVALUE;
    DeRef(_14572);
    _14572 = NOVALUE;
    DeRef(_14575);
    _14575 = NOVALUE;
    _14587 = NOVALUE;
    DeRef(_14591);
    _14591 = NOVALUE;
    _14601 = NOVALUE;
    DeRef(_14596);
    _14596 = NOVALUE;
    _14612 = NOVALUE;
    DeRef(_14622);
    _14622 = NOVALUE;
    _14623 = NOVALUE;
    _14638 = NOVALUE;
    return _tok_25606;
    goto L1; // [1279] 10
L7: 

    /** 		elsif class < ILLEGAL_CHAR then*/
    if (_class_25608 >= -20)
    goto L2D; // [1286] 1303

    /** 			return {class, 0}  -- brackets, punctuation, eof, illegal char etc.*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _class_25608;
    ((int *)_2)[2] = 0;
    _14667 = MAKE_SEQ(_1);
    DeRef(_yytext_25602);
    DeRef(_namespaces_25603);
    DeRef(_d_25604);
    DeRef(_tok_25606);
    DeRef(_name_25609);
    DeRef(_14545);
    _14545 = NOVALUE;
    DeRef(_14550);
    _14550 = NOVALUE;
    DeRef(_14559);
    _14559 = NOVALUE;
    DeRef(_14562);
    _14562 = NOVALUE;
    DeRef(_14565);
    _14565 = NOVALUE;
    DeRef(_14568);
    _14568 = NOVALUE;
    DeRef(_14571);
    _14571 = NOVALUE;
    DeRef(_14572);
    _14572 = NOVALUE;
    DeRef(_14575);
    _14575 = NOVALUE;
    _14587 = NOVALUE;
    DeRef(_14591);
    _14591 = NOVALUE;
    _14601 = NOVALUE;
    DeRef(_14596);
    _14596 = NOVALUE;
    _14612 = NOVALUE;
    DeRef(_14622);
    _14622 = NOVALUE;
    _14623 = NOVALUE;
    _14638 = NOVALUE;
    return _14667;
    goto L1; // [1300] 10
L2D: 

    /** 		elsif class = ILLEGAL_CHAR then*/
    if (_class_25608 != -20)
    goto L2E; // [1307] 1321

    /** 			CompileErr(101)*/
    RefDS(_22023);
    _44CompileErr(101, _22023, 0);
    goto L1; // [1318] 10
L2E: 

    /** 		elsif class = NEWLINE then*/
    if (_class_25608 != -6)
    goto L2F; // [1325] 1351

    /** 			if start_include then*/
    if (_61start_include_23896 == 0)
    {
        goto L30; // [1333] 1343
    }
    else{
    }

    /** 				IncludePush()*/
    _61IncludePush();
    goto L1; // [1340] 10
L30: 

    /** 				read_line()*/
    _61read_line();
    goto L1; // [1348] 10
L2F: 

    /** 		elsif class = EQUALS then*/
    if (_class_25608 != 3)
    goto L31; // [1355] 1372

    /** 			return {class, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _class_25608;
    ((int *)_2)[2] = 0;
    _14671 = MAKE_SEQ(_1);
    DeRef(_yytext_25602);
    DeRef(_namespaces_25603);
    DeRef(_d_25604);
    DeRef(_tok_25606);
    DeRef(_name_25609);
    DeRef(_14545);
    _14545 = NOVALUE;
    DeRef(_14550);
    _14550 = NOVALUE;
    DeRef(_14559);
    _14559 = NOVALUE;
    DeRef(_14562);
    _14562 = NOVALUE;
    DeRef(_14565);
    _14565 = NOVALUE;
    DeRef(_14568);
    _14568 = NOVALUE;
    DeRef(_14571);
    _14571 = NOVALUE;
    DeRef(_14572);
    _14572 = NOVALUE;
    DeRef(_14575);
    _14575 = NOVALUE;
    _14587 = NOVALUE;
    DeRef(_14591);
    _14591 = NOVALUE;
    _14601 = NOVALUE;
    DeRef(_14596);
    _14596 = NOVALUE;
    _14612 = NOVALUE;
    DeRef(_14622);
    _14622 = NOVALUE;
    _14623 = NOVALUE;
    _14638 = NOVALUE;
    DeRef(_14667);
    _14667 = NOVALUE;
    return _14671;
    goto L1; // [1369] 10
L31: 

    /** 		elsif class = DOT or class = DIGIT then*/
    _14672 = (_class_25608 == -3);
    if (_14672 != 0) {
        goto L32; // [1380] 1395
    }
    _14674 = (_class_25608 == -7);
    if (_14674 == 0)
    {
        DeRef(_14674);
        _14674 = NOVALUE;
        goto L33; // [1391] 2196
    }
    else{
        DeRef(_14674);
        _14674 = NOVALUE;
    }
L32: 

    /** 			integer basetype*/

    /** 			if class = DOT then*/
    if (_class_25608 != -3)
    goto L34; // [1401] 1435

    /** 				if getch() = '.' then*/
    _14676 = _61getch();
    if (binary_op_a(NOTEQ, _14676, 46)){
        DeRef(_14676);
        _14676 = NOVALUE;
        goto L35; // [1410] 1429
    }
    DeRef(_14676);
    _14676 = NOVALUE;

    /** 					return {SLICE, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 513;
    ((int *)_2)[2] = 0;
    _14678 = MAKE_SEQ(_1);
    DeRef(_yytext_25602);
    DeRef(_namespaces_25603);
    DeRef(_d_25604);
    DeRef(_tok_25606);
    DeRef(_name_25609);
    DeRef(_14545);
    _14545 = NOVALUE;
    DeRef(_14550);
    _14550 = NOVALUE;
    DeRef(_14559);
    _14559 = NOVALUE;
    DeRef(_14562);
    _14562 = NOVALUE;
    DeRef(_14565);
    _14565 = NOVALUE;
    DeRef(_14568);
    _14568 = NOVALUE;
    DeRef(_14571);
    _14571 = NOVALUE;
    DeRef(_14572);
    _14572 = NOVALUE;
    DeRef(_14575);
    _14575 = NOVALUE;
    _14587 = NOVALUE;
    DeRef(_14591);
    _14591 = NOVALUE;
    _14601 = NOVALUE;
    DeRef(_14596);
    _14596 = NOVALUE;
    _14612 = NOVALUE;
    DeRef(_14622);
    _14622 = NOVALUE;
    _14623 = NOVALUE;
    _14638 = NOVALUE;
    DeRef(_14667);
    _14667 = NOVALUE;
    DeRef(_14671);
    _14671 = NOVALUE;
    DeRef(_14672);
    _14672 = NOVALUE;
    return _14678;
    goto L36; // [1426] 1434
L35: 

    /** 					ungetch()*/
    _61ungetch();
L36: 
L34: 

    /** 			yytext = {ch}*/
    _0 = _yytext_25602;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _ch_25596;
    _yytext_25602 = MAKE_SEQ(_1);
    DeRef(_0);

    /** 			is_int = (ch != '.')*/
    _is_int_25607 = (_ch_25596 != 46);

    /** 			basetype = -1 -- default is decimal*/
    _basetype_25902 = -1;

    /** 			while 1 with entry do*/
    goto L37; // [1454] 1645
L38: 

    /** 				if char_class[ch] = DIGIT then*/
    _2 = (int)SEQ_PTR(_61char_class_23903);
    _14681 = (int)*(((s1_ptr)_2)->base + _ch_25596);
    if (_14681 != -7)
    goto L39; // [1467] 1480

    /** 					yytext &= ch*/
    Append(&_yytext_25602, _yytext_25602, _ch_25596);
    goto L3A; // [1477] 1642
L39: 

    /** 				elsif equal(yytext, "0") then*/
    if (_yytext_25602 == _14334)
    _14684 = 1;
    else if (IS_ATOM_INT(_yytext_25602) && IS_ATOM_INT(_14334))
    _14684 = 0;
    else
    _14684 = (compare(_yytext_25602, _14334) == 0);
    if (_14684 == 0)
    {
        _14684 = NOVALUE;
        goto L3B; // [1486] 1581
    }
    else{
        _14684 = NOVALUE;
    }

    /** 					basetype = find(ch, nbasecode)*/
    _basetype_25902 = find_from(_ch_25596, _61nbasecode_25404, 1);

    /** 					if basetype > length(nbase) then*/
    if (IS_SEQUENCE(_61nbase_25403)){
            _14686 = SEQ_PTR(_61nbase_25403)->length;
    }
    else {
        _14686 = 1;
    }
    if (_basetype_25902 <= _14686)
    goto L3C; // [1501] 1515

    /** 						basetype -= length(nbase)*/
    if (IS_SEQUENCE(_61nbase_25403)){
            _14688 = SEQ_PTR(_61nbase_25403)->length;
    }
    else {
        _14688 = 1;
    }
    _basetype_25902 = _basetype_25902 - _14688;
    _14688 = NOVALUE;
L3C: 

    /** 					if basetype = 0 then*/
    if (_basetype_25902 != 0)
    goto L3D; // [1517] 1572

    /** 						if char_class[ch] = LETTER then*/
    _2 = (int)SEQ_PTR(_61char_class_23903);
    _14691 = (int)*(((s1_ptr)_2)->base + _ch_25596);
    if (_14691 != -2)
    goto L3E; // [1531] 1562

    /** 							if ch != 'e' and ch != 'E' then*/
    _14693 = (_ch_25596 != 101);
    if (_14693 == 0) {
        goto L3F; // [1541] 1561
    }
    _14695 = (_ch_25596 != 69);
    if (_14695 == 0)
    {
        DeRef(_14695);
        _14695 = NOVALUE;
        goto L3F; // [1550] 1561
    }
    else{
        DeRef(_14695);
        _14695 = NOVALUE;
    }

    /** 								CompileErr(105, ch)*/
    _44CompileErr(105, _ch_25596, 0);
L3F: 
L3E: 

    /** 						basetype = -1 -- decimal*/
    _basetype_25902 = -1;

    /** 						exit*/
    goto L40; // [1569] 1657
L3D: 

    /** 					yytext &= '0'*/
    Append(&_yytext_25602, _yytext_25602, 48);
    goto L3A; // [1578] 1642
L3B: 

    /** 				elsif basetype = 4 then -- hexadecimal*/
    if (_basetype_25902 != 4)
    goto L40; // [1583] 1657

    /** 					integer hdigit*/

    /** 					hdigit = find(ch, "ABCDEFabcdef")*/
    _hdigit_25942 = find_from(_ch_25596, _14698, 1);

    /** 					if hdigit = 0 then*/
    if (_hdigit_25942 != 0)
    goto L41; // [1598] 1609

    /** 						exit*/
    goto L40; // [1606] 1657
L41: 

    /** 					if hdigit > 6 then*/
    if (_hdigit_25942 <= 6)
    goto L42; // [1611] 1622

    /** 						hdigit -= 6*/
    _hdigit_25942 = _hdigit_25942 - 6;
L42: 

    /** 					yytext &= hexasc[hdigit]*/
    _2 = (int)SEQ_PTR(_61hexasc_25406);
    _14703 = (int)*(((s1_ptr)_2)->base + _hdigit_25942);
    if (IS_SEQUENCE(_yytext_25602) && IS_ATOM(_14703)) {
        Ref(_14703);
        Append(&_yytext_25602, _yytext_25602, _14703);
    }
    else if (IS_ATOM(_yytext_25602) && IS_SEQUENCE(_14703)) {
    }
    else {
        Concat((object_ptr)&_yytext_25602, _yytext_25602, _14703);
    }
    _14703 = NOVALUE;
    goto L3A; // [1634] 1642

    /** 					exit*/
    goto L40; // [1639] 1657
L3A: 

    /** 			entry*/
L37: 

    /** 				ch = getch()*/
    _ch_25596 = _61getch();
    if (!IS_ATOM_INT(_ch_25596)) {
        _1 = (long)(DBL_PTR(_ch_25596)->dbl);
        DeRefDS(_ch_25596);
        _ch_25596 = _1;
    }

    /** 			end while*/
    goto L38; // [1654] 1457
L40: 

    /** 			if ch = '.' then*/
    if (_ch_25596 != 46)
    goto L43; // [1659] 1794

    /** 				ch = getch()*/
    _ch_25596 = _61getch();
    if (!IS_ATOM_INT(_ch_25596)) {
        _1 = (long)(DBL_PTR(_ch_25596)->dbl);
        DeRefDS(_ch_25596);
        _ch_25596 = _1;
    }

    /** 				if ch = '.' then*/
    if (_ch_25596 != 46)
    goto L44; // [1672] 1683

    /** 					ungetch()*/
    _61ungetch();
    goto L45; // [1680] 1793
L44: 

    /** 					is_int = FALSE*/
    _is_int_25607 = _13FALSE_434;

    /** 					if yytext[1] = '.' then*/
    _2 = (int)SEQ_PTR(_yytext_25602);
    _14709 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _14709, 46)){
        _14709 = NOVALUE;
        goto L46; // [1698] 1712
    }
    _14709 = NOVALUE;

    /** 						CompileErr(124)*/
    RefDS(_22023);
    _44CompileErr(124, _22023, 0);
    goto L47; // [1709] 1719
L46: 

    /** 						yytext &= '.'*/
    Append(&_yytext_25602, _yytext_25602, 46);
L47: 

    /** 					if char_class[ch] = DIGIT then*/
    _2 = (int)SEQ_PTR(_61char_class_23903);
    _14712 = (int)*(((s1_ptr)_2)->base + _ch_25596);
    if (_14712 != -7)
    goto L48; // [1729] 1784

    /** 						yytext &= ch*/
    Append(&_yytext_25602, _yytext_25602, _ch_25596);

    /** 						ch = getch()*/
    _ch_25596 = _61getch();
    if (!IS_ATOM_INT(_ch_25596)) {
        _1 = (long)(DBL_PTR(_ch_25596)->dbl);
        DeRefDS(_ch_25596);
        _ch_25596 = _1;
    }

    /** 						while char_class[ch] = DIGIT do*/
L49: 
    _2 = (int)SEQ_PTR(_61char_class_23903);
    _14716 = (int)*(((s1_ptr)_2)->base + _ch_25596);
    if (_14716 != -7)
    goto L4A; // [1759] 1792

    /** 							yytext &= ch*/
    Append(&_yytext_25602, _yytext_25602, _ch_25596);

    /** 							ch = getch()*/
    _ch_25596 = _61getch();
    if (!IS_ATOM_INT(_ch_25596)) {
        _1 = (long)(DBL_PTR(_ch_25596)->dbl);
        DeRefDS(_ch_25596);
        _ch_25596 = _1;
    }

    /** 						end while*/
    goto L49; // [1778] 1751
    goto L4A; // [1781] 1792
L48: 

    /** 						CompileErr(94)*/
    RefDS(_22023);
    _44CompileErr(94, _22023, 0);
L4A: 
L45: 
L43: 

    /** 			if basetype = -1 and find(ch, "eE") then*/
    _14720 = (_basetype_25902 == -1);
    if (_14720 == 0) {
        goto L4B; // [1800] 1936
    }
    _14723 = find_from(_ch_25596, _14722, 1);
    if (_14723 == 0)
    {
        _14723 = NOVALUE;
        goto L4B; // [1810] 1936
    }
    else{
        _14723 = NOVALUE;
    }

    /** 				is_int = FALSE*/
    _is_int_25607 = _13FALSE_434;

    /** 				yytext &= ch*/
    Append(&_yytext_25602, _yytext_25602, _ch_25596);

    /** 				ch = getch()*/
    _ch_25596 = _61getch();
    if (!IS_ATOM_INT(_ch_25596)) {
        _1 = (long)(DBL_PTR(_ch_25596)->dbl);
        DeRefDS(_ch_25596);
        _ch_25596 = _1;
    }

    /** 				if ch = '-' or ch = '+' or char_class[ch] = DIGIT then*/
    _14726 = (_ch_25596 == 45);
    if (_14726 != 0) {
        _14727 = 1;
        goto L4C; // [1841] 1853
    }
    _14728 = (_ch_25596 == 43);
    _14727 = (_14728 != 0);
L4C: 
    if (_14727 != 0) {
        goto L4D; // [1853] 1874
    }
    _2 = (int)SEQ_PTR(_61char_class_23903);
    _14730 = (int)*(((s1_ptr)_2)->base + _ch_25596);
    _14731 = (_14730 == -7);
    _14730 = NOVALUE;
    if (_14731 == 0)
    {
        DeRef(_14731);
        _14731 = NOVALUE;
        goto L4E; // [1870] 1883
    }
    else{
        DeRef(_14731);
        _14731 = NOVALUE;
    }
L4D: 

    /** 					yytext &= ch*/
    Append(&_yytext_25602, _yytext_25602, _ch_25596);
    goto L4F; // [1880] 1891
L4E: 

    /** 					CompileErr(86)*/
    RefDS(_22023);
    _44CompileErr(86, _22023, 0);
L4F: 

    /** 				ch = getch()*/
    _ch_25596 = _61getch();
    if (!IS_ATOM_INT(_ch_25596)) {
        _1 = (long)(DBL_PTR(_ch_25596)->dbl);
        DeRefDS(_ch_25596);
        _ch_25596 = _1;
    }

    /** 				while char_class[ch] = DIGIT do*/
L50: 
    _2 = (int)SEQ_PTR(_61char_class_23903);
    _14734 = (int)*(((s1_ptr)_2)->base + _ch_25596);
    if (_14734 != -7)
    goto L51; // [1911] 1967

    /** 					yytext &= ch*/
    Append(&_yytext_25602, _yytext_25602, _ch_25596);

    /** 					ch = getch()*/
    _ch_25596 = _61getch();
    if (!IS_ATOM_INT(_ch_25596)) {
        _1 = (long)(DBL_PTR(_ch_25596)->dbl);
        DeRefDS(_ch_25596);
        _ch_25596 = _1;
    }

    /** 				end while*/
    goto L50; // [1930] 1903
    goto L51; // [1933] 1967
L4B: 

    /** 			elsif char_class[ch] = LETTER then*/
    _2 = (int)SEQ_PTR(_61char_class_23903);
    _14738 = (int)*(((s1_ptr)_2)->base + _ch_25596);
    if (_14738 != -2)
    goto L52; // [1946] 1966

    /** 				CompileErr(127, {{ch}})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _ch_25596;
    _14740 = MAKE_SEQ(_1);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _14740;
    _14741 = MAKE_SEQ(_1);
    _14740 = NOVALUE;
    _44CompileErr(127, _14741, 0);
    _14741 = NOVALUE;
L52: 
L51: 

    /** 			ungetch()*/
    _61ungetch();

    /** 			while i != 0 with entry do*/
    goto L53; // [1973] 2012
L54: 
    if (_i_25597 == 0)
    goto L55; // [1978] 2024

    /** 			    yytext = yytext[1 .. i-1] & yytext[i+1 .. $]*/
    _14743 = _i_25597 - 1;
    rhs_slice_target = (object_ptr)&_14744;
    RHS_Slice(_yytext_25602, 1, _14743);
    _14745 = _i_25597 + 1;
    if (_14745 > MAXINT){
        _14745 = NewDouble((double)_14745);
    }
    if (IS_SEQUENCE(_yytext_25602)){
            _14746 = SEQ_PTR(_yytext_25602)->length;
    }
    else {
        _14746 = 1;
    }
    rhs_slice_target = (object_ptr)&_14747;
    RHS_Slice(_yytext_25602, _14745, _14746);
    Concat((object_ptr)&_yytext_25602, _14744, _14747);
    DeRefDS(_14744);
    _14744 = NOVALUE;
    DeRef(_14744);
    _14744 = NOVALUE;
    DeRefDS(_14747);
    _14747 = NOVALUE;

    /** 			  entry*/
L53: 

    /** 			    i = find('_', yytext)*/
    _i_25597 = find_from(95, _yytext_25602, 1);

    /** 			end while*/
    goto L54; // [2021] 1976
L55: 

    /** 			if is_int then*/
    if (_is_int_25607 == 0)
    {
        goto L56; // [2026] 2097
    }
    else{
    }

    /** 				if basetype = -1 then*/
    if (_basetype_25902 != -1)
    goto L57; // [2031] 2041

    /** 					basetype = 3 -- decimal*/
    _basetype_25902 = 3;
L57: 

    /** 				d = MakeInt(yytext, nbase[basetype])*/
    _2 = (int)SEQ_PTR(_61nbase_25403);
    _14751 = (int)*(((s1_ptr)_2)->base + _basetype_25902);
    RefDS(_yytext_25602);
    Ref(_14751);
    _0 = _d_25604;
    _d_25604 = _61MakeInt(_yytext_25602, _14751);
    DeRef(_0);
    _14751 = NOVALUE;

    /** 				if integer(d) then*/
    if (IS_ATOM_INT(_d_25604))
    _14753 = 1;
    else if (IS_ATOM_DBL(_d_25604))
    _14753 = IS_ATOM_INT(DoubleToInt(_d_25604));
    else
    _14753 = 0;
    if (_14753 == 0)
    {
        _14753 = NOVALUE;
        goto L58; // [2057] 2079
    }
    else{
        _14753 = NOVALUE;
    }

    /** 					return {ATOM, NewIntSym(d)}*/
    Ref(_d_25604);
    _14754 = _53NewIntSym(_d_25604);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 502;
    ((int *)_2)[2] = _14754;
    _14755 = MAKE_SEQ(_1);
    _14754 = NOVALUE;
    DeRefDS(_yytext_25602);
    DeRef(_namespaces_25603);
    DeRef(_d_25604);
    DeRef(_tok_25606);
    DeRef(_name_25609);
    _14716 = NOVALUE;
    DeRef(_14572);
    _14572 = NOVALUE;
    _14587 = NOVALUE;
    DeRef(_14728);
    _14728 = NOVALUE;
    _14691 = NOVALUE;
    DeRef(_14745);
    _14745 = NOVALUE;
    DeRef(_14575);
    _14575 = NOVALUE;
    DeRef(_14726);
    _14726 = NOVALUE;
    DeRef(_14622);
    _14622 = NOVALUE;
    DeRef(_14591);
    _14591 = NOVALUE;
    DeRef(_14672);
    _14672 = NOVALUE;
    _14738 = NOVALUE;
    DeRef(_14559);
    _14559 = NOVALUE;
    DeRef(_14596);
    _14596 = NOVALUE;
    _14638 = NOVALUE;
    DeRef(_14550);
    _14550 = NOVALUE;
    _14601 = NOVALUE;
    _14712 = NOVALUE;
    _14681 = NOVALUE;
    DeRef(_14545);
    _14545 = NOVALUE;
    DeRef(_14568);
    _14568 = NOVALUE;
    DeRef(_14571);
    _14571 = NOVALUE;
    _14612 = NOVALUE;
    _14734 = NOVALUE;
    DeRef(_14720);
    _14720 = NOVALUE;
    DeRef(_14667);
    _14667 = NOVALUE;
    DeRef(_14678);
    _14678 = NOVALUE;
    DeRef(_14562);
    _14562 = NOVALUE;
    _14623 = NOVALUE;
    DeRef(_14671);
    _14671 = NOVALUE;
    DeRef(_14565);
    _14565 = NOVALUE;
    DeRef(_14743);
    _14743 = NOVALUE;
    DeRef(_14693);
    _14693 = NOVALUE;
    return _14755;
    goto L59; // [2076] 2096
L58: 

    /** 					return {ATOM, NewDoubleSym(d)}*/
    Ref(_d_25604);
    _14756 = _53NewDoubleSym(_d_25604);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 502;
    ((int *)_2)[2] = _14756;
    _14757 = MAKE_SEQ(_1);
    _14756 = NOVALUE;
    DeRef(_yytext_25602);
    DeRef(_namespaces_25603);
    DeRef(_d_25604);
    DeRef(_tok_25606);
    DeRef(_name_25609);
    _14716 = NOVALUE;
    DeRef(_14572);
    _14572 = NOVALUE;
    _14587 = NOVALUE;
    DeRef(_14728);
    _14728 = NOVALUE;
    _14691 = NOVALUE;
    DeRef(_14745);
    _14745 = NOVALUE;
    DeRef(_14755);
    _14755 = NOVALUE;
    DeRef(_14575);
    _14575 = NOVALUE;
    DeRef(_14726);
    _14726 = NOVALUE;
    DeRef(_14622);
    _14622 = NOVALUE;
    DeRef(_14591);
    _14591 = NOVALUE;
    DeRef(_14672);
    _14672 = NOVALUE;
    _14738 = NOVALUE;
    DeRef(_14559);
    _14559 = NOVALUE;
    DeRef(_14596);
    _14596 = NOVALUE;
    _14638 = NOVALUE;
    DeRef(_14550);
    _14550 = NOVALUE;
    _14601 = NOVALUE;
    _14712 = NOVALUE;
    _14681 = NOVALUE;
    DeRef(_14545);
    _14545 = NOVALUE;
    DeRef(_14568);
    _14568 = NOVALUE;
    DeRef(_14571);
    _14571 = NOVALUE;
    _14612 = NOVALUE;
    _14734 = NOVALUE;
    DeRef(_14720);
    _14720 = NOVALUE;
    DeRef(_14667);
    _14667 = NOVALUE;
    DeRef(_14678);
    _14678 = NOVALUE;
    DeRef(_14562);
    _14562 = NOVALUE;
    _14623 = NOVALUE;
    DeRef(_14671);
    _14671 = NOVALUE;
    DeRef(_14565);
    _14565 = NOVALUE;
    DeRef(_14743);
    _14743 = NOVALUE;
    DeRef(_14693);
    _14693 = NOVALUE;
    return _14757;
L59: 
L56: 

    /** 			if basetype != -1 then*/
    if (_basetype_25902 == -1)
    goto L5A; // [2099] 2115

    /** 				CompileErr(125, nbasecode[basetype])*/
    _2 = (int)SEQ_PTR(_61nbasecode_25404);
    _14759 = (int)*(((s1_ptr)_2)->base + _basetype_25902);
    Ref(_14759);
    _44CompileErr(125, _14759, 0);
    _14759 = NOVALUE;
L5A: 

    /** 			d = my_sscanf(yytext)*/
    RefDS(_yytext_25602);
    _0 = _d_25604;
    _d_25604 = _61my_sscanf(_yytext_25602);
    DeRef(_0);

    /** 			if sequence(d) then*/
    _14761 = IS_SEQUENCE(_d_25604);
    if (_14761 == 0)
    {
        _14761 = NOVALUE;
        goto L5B; // [2126] 2139
    }
    else{
        _14761 = NOVALUE;
    }

    /** 				CompileErr(121)*/
    RefDS(_22023);
    _44CompileErr(121, _22023, 0);
    goto L5C; // [2136] 2191
L5B: 

    /** 			elsif is_int and d <= MAXINT_DBL then*/
    if (_is_int_25607 == 0) {
        goto L5D; // [2141] 2174
    }
    if (IS_ATOM_INT(_d_25604)) {
        _14763 = (_d_25604 <= 1073741823);
    }
    else {
        _14763 = binary_op(LESSEQ, _d_25604, 1073741823);
    }
    if (_14763 == 0) {
        DeRef(_14763);
        _14763 = NOVALUE;
        goto L5D; // [2152] 2174
    }
    else {
        if (!IS_ATOM_INT(_14763) && DBL_PTR(_14763)->dbl == 0.0){
            DeRef(_14763);
            _14763 = NOVALUE;
            goto L5D; // [2152] 2174
        }
        DeRef(_14763);
        _14763 = NOVALUE;
    }
    DeRef(_14763);
    _14763 = NOVALUE;

    /** 				return {ATOM, NewIntSym(d)}  -- 1 to 1.07 billion*/
    Ref(_d_25604);
    _14764 = _53NewIntSym(_d_25604);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 502;
    ((int *)_2)[2] = _14764;
    _14765 = MAKE_SEQ(_1);
    _14764 = NOVALUE;
    DeRef(_yytext_25602);
    DeRef(_namespaces_25603);
    DeRef(_d_25604);
    DeRef(_tok_25606);
    DeRef(_name_25609);
    _14716 = NOVALUE;
    DeRef(_14572);
    _14572 = NOVALUE;
    _14587 = NOVALUE;
    DeRef(_14728);
    _14728 = NOVALUE;
    _14691 = NOVALUE;
    DeRef(_14745);
    _14745 = NOVALUE;
    DeRef(_14755);
    _14755 = NOVALUE;
    DeRef(_14575);
    _14575 = NOVALUE;
    DeRef(_14726);
    _14726 = NOVALUE;
    DeRef(_14622);
    _14622 = NOVALUE;
    DeRef(_14591);
    _14591 = NOVALUE;
    DeRef(_14672);
    _14672 = NOVALUE;
    _14738 = NOVALUE;
    DeRef(_14559);
    _14559 = NOVALUE;
    DeRef(_14596);
    _14596 = NOVALUE;
    _14638 = NOVALUE;
    DeRef(_14550);
    _14550 = NOVALUE;
    _14601 = NOVALUE;
    _14712 = NOVALUE;
    DeRef(_14757);
    _14757 = NOVALUE;
    _14681 = NOVALUE;
    DeRef(_14545);
    _14545 = NOVALUE;
    DeRef(_14568);
    _14568 = NOVALUE;
    DeRef(_14571);
    _14571 = NOVALUE;
    _14612 = NOVALUE;
    _14734 = NOVALUE;
    DeRef(_14720);
    _14720 = NOVALUE;
    DeRef(_14667);
    _14667 = NOVALUE;
    DeRef(_14678);
    _14678 = NOVALUE;
    DeRef(_14562);
    _14562 = NOVALUE;
    _14623 = NOVALUE;
    DeRef(_14671);
    _14671 = NOVALUE;
    DeRef(_14565);
    _14565 = NOVALUE;
    DeRef(_14743);
    _14743 = NOVALUE;
    DeRef(_14693);
    _14693 = NOVALUE;
    return _14765;
    goto L5C; // [2171] 2191
L5D: 

    /** 				return {ATOM, NewDoubleSym(d)}*/
    Ref(_d_25604);
    _14766 = _53NewDoubleSym(_d_25604);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 502;
    ((int *)_2)[2] = _14766;
    _14767 = MAKE_SEQ(_1);
    _14766 = NOVALUE;
    DeRef(_yytext_25602);
    DeRef(_namespaces_25603);
    DeRef(_d_25604);
    DeRef(_tok_25606);
    DeRef(_name_25609);
    _14716 = NOVALUE;
    DeRef(_14765);
    _14765 = NOVALUE;
    DeRef(_14572);
    _14572 = NOVALUE;
    _14587 = NOVALUE;
    DeRef(_14728);
    _14728 = NOVALUE;
    _14691 = NOVALUE;
    DeRef(_14745);
    _14745 = NOVALUE;
    DeRef(_14755);
    _14755 = NOVALUE;
    DeRef(_14575);
    _14575 = NOVALUE;
    DeRef(_14726);
    _14726 = NOVALUE;
    DeRef(_14622);
    _14622 = NOVALUE;
    DeRef(_14591);
    _14591 = NOVALUE;
    DeRef(_14672);
    _14672 = NOVALUE;
    _14738 = NOVALUE;
    DeRef(_14559);
    _14559 = NOVALUE;
    DeRef(_14596);
    _14596 = NOVALUE;
    _14638 = NOVALUE;
    DeRef(_14550);
    _14550 = NOVALUE;
    _14601 = NOVALUE;
    _14712 = NOVALUE;
    DeRef(_14757);
    _14757 = NOVALUE;
    _14681 = NOVALUE;
    DeRef(_14545);
    _14545 = NOVALUE;
    DeRef(_14568);
    _14568 = NOVALUE;
    DeRef(_14571);
    _14571 = NOVALUE;
    _14612 = NOVALUE;
    _14734 = NOVALUE;
    DeRef(_14720);
    _14720 = NOVALUE;
    DeRef(_14667);
    _14667 = NOVALUE;
    DeRef(_14678);
    _14678 = NOVALUE;
    DeRef(_14562);
    _14562 = NOVALUE;
    _14623 = NOVALUE;
    DeRef(_14671);
    _14671 = NOVALUE;
    DeRef(_14565);
    _14565 = NOVALUE;
    DeRef(_14743);
    _14743 = NOVALUE;
    DeRef(_14693);
    _14693 = NOVALUE;
    return _14767;
L5C: 
    goto L1; // [2193] 10
L33: 

    /** 		elsif class = MINUS then*/
    if (_class_25608 != 10)
    goto L5E; // [2200] 2286

    /** 			ch = getch()*/
    _ch_25596 = _61getch();
    if (!IS_ATOM_INT(_ch_25596)) {
        _1 = (long)(DBL_PTR(_ch_25596)->dbl);
        DeRefDS(_ch_25596);
        _ch_25596 = _1;
    }

    /** 			if ch = '-' then*/
    if (_ch_25596 != 45)
    goto L5F; // [2213] 2239

    /** 				if start_include then*/
    if (_61start_include_23896 == 0)
    {
        goto L60; // [2221] 2231
    }
    else{
    }

    /** 					IncludePush()*/
    _61IncludePush();
    goto L1; // [2228] 10
L60: 

    /** 					read_line()*/
    _61read_line();
    goto L1; // [2236] 10
L5F: 

    /** 			elsif ch = '=' then*/
    if (_ch_25596 != 61)
    goto L61; // [2241] 2260

    /** 				return {MINUS_EQUALS, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 516;
    ((int *)_2)[2] = 0;
    _14772 = MAKE_SEQ(_1);
    DeRef(_yytext_25602);
    DeRef(_namespaces_25603);
    DeRef(_d_25604);
    DeRef(_tok_25606);
    DeRef(_name_25609);
    _14716 = NOVALUE;
    DeRef(_14765);
    _14765 = NOVALUE;
    DeRef(_14572);
    _14572 = NOVALUE;
    _14587 = NOVALUE;
    DeRef(_14728);
    _14728 = NOVALUE;
    _14691 = NOVALUE;
    DeRef(_14745);
    _14745 = NOVALUE;
    DeRef(_14755);
    _14755 = NOVALUE;
    DeRef(_14575);
    _14575 = NOVALUE;
    DeRef(_14726);
    _14726 = NOVALUE;
    DeRef(_14622);
    _14622 = NOVALUE;
    DeRef(_14591);
    _14591 = NOVALUE;
    DeRef(_14672);
    _14672 = NOVALUE;
    DeRef(_14767);
    _14767 = NOVALUE;
    _14738 = NOVALUE;
    DeRef(_14559);
    _14559 = NOVALUE;
    DeRef(_14596);
    _14596 = NOVALUE;
    _14638 = NOVALUE;
    DeRef(_14550);
    _14550 = NOVALUE;
    _14601 = NOVALUE;
    _14712 = NOVALUE;
    DeRef(_14757);
    _14757 = NOVALUE;
    _14681 = NOVALUE;
    DeRef(_14545);
    _14545 = NOVALUE;
    DeRef(_14568);
    _14568 = NOVALUE;
    DeRef(_14571);
    _14571 = NOVALUE;
    _14612 = NOVALUE;
    _14734 = NOVALUE;
    DeRef(_14720);
    _14720 = NOVALUE;
    DeRef(_14667);
    _14667 = NOVALUE;
    DeRef(_14678);
    _14678 = NOVALUE;
    DeRef(_14562);
    _14562 = NOVALUE;
    _14623 = NOVALUE;
    DeRef(_14671);
    _14671 = NOVALUE;
    DeRef(_14565);
    _14565 = NOVALUE;
    DeRef(_14743);
    _14743 = NOVALUE;
    DeRef(_14693);
    _14693 = NOVALUE;
    return _14772;
    goto L1; // [2257] 10
L61: 

    /** 				bp -= 1*/
    _44bp_48522 = _44bp_48522 - 1;

    /** 				return {MINUS, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 10;
    ((int *)_2)[2] = 0;
    _14774 = MAKE_SEQ(_1);
    DeRef(_yytext_25602);
    DeRef(_namespaces_25603);
    DeRef(_d_25604);
    DeRef(_tok_25606);
    DeRef(_name_25609);
    _14716 = NOVALUE;
    DeRef(_14765);
    _14765 = NOVALUE;
    DeRef(_14572);
    _14572 = NOVALUE;
    _14587 = NOVALUE;
    DeRef(_14728);
    _14728 = NOVALUE;
    _14691 = NOVALUE;
    DeRef(_14745);
    _14745 = NOVALUE;
    DeRef(_14755);
    _14755 = NOVALUE;
    DeRef(_14575);
    _14575 = NOVALUE;
    DeRef(_14726);
    _14726 = NOVALUE;
    DeRef(_14622);
    _14622 = NOVALUE;
    DeRef(_14591);
    _14591 = NOVALUE;
    DeRef(_14672);
    _14672 = NOVALUE;
    DeRef(_14767);
    _14767 = NOVALUE;
    _14738 = NOVALUE;
    DeRef(_14559);
    _14559 = NOVALUE;
    DeRef(_14596);
    _14596 = NOVALUE;
    _14638 = NOVALUE;
    DeRef(_14550);
    _14550 = NOVALUE;
    _14601 = NOVALUE;
    _14712 = NOVALUE;
    DeRef(_14757);
    _14757 = NOVALUE;
    _14681 = NOVALUE;
    DeRef(_14772);
    _14772 = NOVALUE;
    DeRef(_14545);
    _14545 = NOVALUE;
    DeRef(_14568);
    _14568 = NOVALUE;
    DeRef(_14571);
    _14571 = NOVALUE;
    _14612 = NOVALUE;
    _14734 = NOVALUE;
    DeRef(_14720);
    _14720 = NOVALUE;
    DeRef(_14667);
    _14667 = NOVALUE;
    DeRef(_14678);
    _14678 = NOVALUE;
    DeRef(_14562);
    _14562 = NOVALUE;
    _14623 = NOVALUE;
    DeRef(_14671);
    _14671 = NOVALUE;
    DeRef(_14565);
    _14565 = NOVALUE;
    DeRef(_14743);
    _14743 = NOVALUE;
    DeRef(_14693);
    _14693 = NOVALUE;
    return _14774;
    goto L1; // [2283] 10
L5E: 

    /** 		elsif class = DOUBLE_QUOTE then*/
    if (_class_25608 != -4)
    goto L62; // [2290] 2484

    /** 			integer fch*/

    /** 			ch = getch()*/
    _ch_25596 = _61getch();
    if (!IS_ATOM_INT(_ch_25596)) {
        _1 = (long)(DBL_PTR(_ch_25596)->dbl);
        DeRefDS(_ch_25596);
        _ch_25596 = _1;
    }

    /** 			if ch = '"' then*/
    if (_ch_25596 != 34)
    goto L63; // [2305] 2341

    /** 				fch = getch()*/
    _fch_26080 = _61getch();
    if (!IS_ATOM_INT(_fch_26080)) {
        _1 = (long)(DBL_PTR(_fch_26080)->dbl);
        DeRefDS(_fch_26080);
        _fch_26080 = _1;
    }

    /** 				if fch = '"' then*/
    if (_fch_26080 != 34)
    goto L64; // [2318] 2335

    /** 					return ExtendedString( fch )*/
    _14780 = _61ExtendedString(_fch_26080);
    DeRef(_yytext_25602);
    DeRef(_namespaces_25603);
    DeRef(_d_25604);
    DeRef(_tok_25606);
    DeRef(_name_25609);
    _14716 = NOVALUE;
    DeRef(_14765);
    _14765 = NOVALUE;
    DeRef(_14572);
    _14572 = NOVALUE;
    _14587 = NOVALUE;
    DeRef(_14728);
    _14728 = NOVALUE;
    _14691 = NOVALUE;
    DeRef(_14745);
    _14745 = NOVALUE;
    DeRef(_14755);
    _14755 = NOVALUE;
    DeRef(_14575);
    _14575 = NOVALUE;
    DeRef(_14726);
    _14726 = NOVALUE;
    DeRef(_14622);
    _14622 = NOVALUE;
    DeRef(_14591);
    _14591 = NOVALUE;
    DeRef(_14672);
    _14672 = NOVALUE;
    DeRef(_14767);
    _14767 = NOVALUE;
    _14738 = NOVALUE;
    DeRef(_14559);
    _14559 = NOVALUE;
    DeRef(_14596);
    _14596 = NOVALUE;
    _14638 = NOVALUE;
    DeRef(_14550);
    _14550 = NOVALUE;
    _14601 = NOVALUE;
    _14712 = NOVALUE;
    DeRef(_14757);
    _14757 = NOVALUE;
    _14681 = NOVALUE;
    DeRef(_14772);
    _14772 = NOVALUE;
    DeRef(_14545);
    _14545 = NOVALUE;
    DeRef(_14568);
    _14568 = NOVALUE;
    DeRef(_14571);
    _14571 = NOVALUE;
    _14612 = NOVALUE;
    _14734 = NOVALUE;
    DeRef(_14774);
    _14774 = NOVALUE;
    DeRef(_14720);
    _14720 = NOVALUE;
    DeRef(_14667);
    _14667 = NOVALUE;
    DeRef(_14678);
    _14678 = NOVALUE;
    DeRef(_14562);
    _14562 = NOVALUE;
    _14623 = NOVALUE;
    DeRef(_14671);
    _14671 = NOVALUE;
    DeRef(_14565);
    _14565 = NOVALUE;
    DeRef(_14743);
    _14743 = NOVALUE;
    DeRef(_14693);
    _14693 = NOVALUE;
    return _14780;
    goto L65; // [2332] 2340
L64: 

    /** 					ungetch()*/
    _61ungetch();
L65: 
L63: 

    /** 			yytext = ""*/
    RefDS(_5);
    DeRef(_yytext_25602);
    _yytext_25602 = _5;

    /** 			while ch != '\n' and ch != '\r' do -- can't be EOF*/
L66: 
    _14781 = (_ch_25596 != 10);
    if (_14781 == 0) {
        goto L67; // [2357] 2436
    }
    _14783 = (_ch_25596 != 13);
    if (_14783 == 0)
    {
        DeRef(_14783);
        _14783 = NOVALUE;
        goto L67; // [2366] 2436
    }
    else{
        DeRef(_14783);
        _14783 = NOVALUE;
    }

    /** 				if ch = '"' then*/
    if (_ch_25596 != 34)
    goto L68; // [2371] 2382

    /** 					exit*/
    goto L67; // [2377] 2436
    goto L69; // [2379] 2424
L68: 

    /** 				elsif ch = '\\' then*/
    if (_ch_25596 != 92)
    goto L6A; // [2384] 2401

    /** 					yytext &= EscapeChar('"')*/
    _14786 = _61EscapeChar(34);
    if (IS_SEQUENCE(_yytext_25602) && IS_ATOM(_14786)) {
        Ref(_14786);
        Append(&_yytext_25602, _yytext_25602, _14786);
    }
    else if (IS_ATOM(_yytext_25602) && IS_SEQUENCE(_14786)) {
    }
    else {
        Concat((object_ptr)&_yytext_25602, _yytext_25602, _14786);
    }
    DeRef(_14786);
    _14786 = NOVALUE;
    goto L69; // [2398] 2424
L6A: 

    /** 				elsif ch = '\t' then*/
    if (_ch_25596 != 9)
    goto L6B; // [2403] 2417

    /** 					CompileErr(145)*/
    RefDS(_22023);
    _44CompileErr(145, _22023, 0);
    goto L69; // [2414] 2424
L6B: 

    /** 					yytext &= ch*/
    Append(&_yytext_25602, _yytext_25602, _ch_25596);
L69: 

    /** 				ch = getch()*/
    _ch_25596 = _61getch();
    if (!IS_ATOM_INT(_ch_25596)) {
        _1 = (long)(DBL_PTR(_ch_25596)->dbl);
        DeRefDS(_ch_25596);
        _ch_25596 = _1;
    }

    /** 			end while*/
    goto L66; // [2433] 2353
L67: 

    /** 			if ch = '\n' or ch = '\r' then*/
    _14791 = (_ch_25596 == 10);
    if (_14791 != 0) {
        goto L6C; // [2442] 2455
    }
    _14793 = (_ch_25596 == 13);
    if (_14793 == 0)
    {
        DeRef(_14793);
        _14793 = NOVALUE;
        goto L6D; // [2451] 2463
    }
    else{
        DeRef(_14793);
        _14793 = NOVALUE;
    }
L6C: 

    /** 				CompileErr(67)*/
    RefDS(_22023);
    _44CompileErr(67, _22023, 0);
L6D: 

    /** 			return {STRING, NewStringSym(yytext)}*/
    RefDS(_yytext_25602);
    _14794 = _53NewStringSym(_yytext_25602);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 503;
    ((int *)_2)[2] = _14794;
    _14795 = MAKE_SEQ(_1);
    _14794 = NOVALUE;
    DeRefDS(_yytext_25602);
    DeRef(_namespaces_25603);
    DeRef(_d_25604);
    DeRef(_tok_25606);
    DeRef(_name_25609);
    _14716 = NOVALUE;
    DeRef(_14781);
    _14781 = NOVALUE;
    DeRef(_14765);
    _14765 = NOVALUE;
    DeRef(_14572);
    _14572 = NOVALUE;
    _14587 = NOVALUE;
    DeRef(_14780);
    _14780 = NOVALUE;
    DeRef(_14728);
    _14728 = NOVALUE;
    _14691 = NOVALUE;
    DeRef(_14745);
    _14745 = NOVALUE;
    DeRef(_14755);
    _14755 = NOVALUE;
    DeRef(_14575);
    _14575 = NOVALUE;
    DeRef(_14726);
    _14726 = NOVALUE;
    DeRef(_14622);
    _14622 = NOVALUE;
    DeRef(_14591);
    _14591 = NOVALUE;
    DeRef(_14672);
    _14672 = NOVALUE;
    DeRef(_14767);
    _14767 = NOVALUE;
    _14738 = NOVALUE;
    DeRef(_14559);
    _14559 = NOVALUE;
    DeRef(_14596);
    _14596 = NOVALUE;
    _14638 = NOVALUE;
    DeRef(_14550);
    _14550 = NOVALUE;
    _14601 = NOVALUE;
    _14712 = NOVALUE;
    DeRef(_14757);
    _14757 = NOVALUE;
    _14681 = NOVALUE;
    DeRef(_14772);
    _14772 = NOVALUE;
    DeRef(_14545);
    _14545 = NOVALUE;
    DeRef(_14568);
    _14568 = NOVALUE;
    DeRef(_14571);
    _14571 = NOVALUE;
    _14612 = NOVALUE;
    _14734 = NOVALUE;
    DeRef(_14774);
    _14774 = NOVALUE;
    DeRef(_14720);
    _14720 = NOVALUE;
    DeRef(_14667);
    _14667 = NOVALUE;
    DeRef(_14791);
    _14791 = NOVALUE;
    DeRef(_14678);
    _14678 = NOVALUE;
    DeRef(_14562);
    _14562 = NOVALUE;
    _14623 = NOVALUE;
    DeRef(_14671);
    _14671 = NOVALUE;
    DeRef(_14565);
    _14565 = NOVALUE;
    DeRef(_14743);
    _14743 = NOVALUE;
    DeRef(_14693);
    _14693 = NOVALUE;
    return _14795;
    goto L1; // [2481] 10
L62: 

    /** 		elsif class = PLUS then*/
    if (_class_25608 != 11)
    goto L6E; // [2488] 2540

    /** 			ch = getch()*/
    _ch_25596 = _61getch();
    if (!IS_ATOM_INT(_ch_25596)) {
        _1 = (long)(DBL_PTR(_ch_25596)->dbl);
        DeRefDS(_ch_25596);
        _ch_25596 = _1;
    }

    /** 			if ch = '=' then*/
    if (_ch_25596 != 61)
    goto L6F; // [2501] 2520

    /** 				return {PLUS_EQUALS, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 515;
    ((int *)_2)[2] = 0;
    _14799 = MAKE_SEQ(_1);
    DeRef(_yytext_25602);
    DeRef(_namespaces_25603);
    DeRef(_d_25604);
    DeRef(_tok_25606);
    DeRef(_name_25609);
    _14716 = NOVALUE;
    DeRef(_14781);
    _14781 = NOVALUE;
    DeRef(_14765);
    _14765 = NOVALUE;
    DeRef(_14572);
    _14572 = NOVALUE;
    _14587 = NOVALUE;
    DeRef(_14780);
    _14780 = NOVALUE;
    DeRef(_14728);
    _14728 = NOVALUE;
    _14691 = NOVALUE;
    DeRef(_14745);
    _14745 = NOVALUE;
    DeRef(_14755);
    _14755 = NOVALUE;
    DeRef(_14795);
    _14795 = NOVALUE;
    DeRef(_14575);
    _14575 = NOVALUE;
    DeRef(_14726);
    _14726 = NOVALUE;
    DeRef(_14622);
    _14622 = NOVALUE;
    DeRef(_14591);
    _14591 = NOVALUE;
    DeRef(_14672);
    _14672 = NOVALUE;
    DeRef(_14767);
    _14767 = NOVALUE;
    _14738 = NOVALUE;
    DeRef(_14559);
    _14559 = NOVALUE;
    DeRef(_14596);
    _14596 = NOVALUE;
    _14638 = NOVALUE;
    DeRef(_14550);
    _14550 = NOVALUE;
    _14601 = NOVALUE;
    _14712 = NOVALUE;
    DeRef(_14757);
    _14757 = NOVALUE;
    _14681 = NOVALUE;
    DeRef(_14772);
    _14772 = NOVALUE;
    DeRef(_14545);
    _14545 = NOVALUE;
    DeRef(_14568);
    _14568 = NOVALUE;
    DeRef(_14571);
    _14571 = NOVALUE;
    _14612 = NOVALUE;
    _14734 = NOVALUE;
    DeRef(_14774);
    _14774 = NOVALUE;
    DeRef(_14720);
    _14720 = NOVALUE;
    DeRef(_14667);
    _14667 = NOVALUE;
    DeRef(_14791);
    _14791 = NOVALUE;
    DeRef(_14678);
    _14678 = NOVALUE;
    DeRef(_14562);
    _14562 = NOVALUE;
    _14623 = NOVALUE;
    DeRef(_14671);
    _14671 = NOVALUE;
    DeRef(_14565);
    _14565 = NOVALUE;
    DeRef(_14743);
    _14743 = NOVALUE;
    DeRef(_14693);
    _14693 = NOVALUE;
    return _14799;
    goto L1; // [2517] 10
L6F: 

    /** 				ungetch()*/
    _61ungetch();

    /** 				return {PLUS, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 11;
    ((int *)_2)[2] = 0;
    _14800 = MAKE_SEQ(_1);
    DeRef(_yytext_25602);
    DeRef(_namespaces_25603);
    DeRef(_d_25604);
    DeRef(_tok_25606);
    DeRef(_name_25609);
    _14716 = NOVALUE;
    DeRef(_14781);
    _14781 = NOVALUE;
    DeRef(_14765);
    _14765 = NOVALUE;
    DeRef(_14572);
    _14572 = NOVALUE;
    _14587 = NOVALUE;
    DeRef(_14780);
    _14780 = NOVALUE;
    DeRef(_14728);
    _14728 = NOVALUE;
    _14691 = NOVALUE;
    DeRef(_14745);
    _14745 = NOVALUE;
    DeRef(_14755);
    _14755 = NOVALUE;
    DeRef(_14795);
    _14795 = NOVALUE;
    DeRef(_14575);
    _14575 = NOVALUE;
    DeRef(_14726);
    _14726 = NOVALUE;
    DeRef(_14622);
    _14622 = NOVALUE;
    DeRef(_14591);
    _14591 = NOVALUE;
    DeRef(_14672);
    _14672 = NOVALUE;
    DeRef(_14767);
    _14767 = NOVALUE;
    _14738 = NOVALUE;
    DeRef(_14559);
    _14559 = NOVALUE;
    DeRef(_14596);
    _14596 = NOVALUE;
    _14638 = NOVALUE;
    DeRef(_14550);
    _14550 = NOVALUE;
    _14601 = NOVALUE;
    _14712 = NOVALUE;
    DeRef(_14757);
    _14757 = NOVALUE;
    _14681 = NOVALUE;
    DeRef(_14772);
    _14772 = NOVALUE;
    DeRef(_14545);
    _14545 = NOVALUE;
    DeRef(_14568);
    _14568 = NOVALUE;
    DeRef(_14571);
    _14571 = NOVALUE;
    _14612 = NOVALUE;
    _14734 = NOVALUE;
    DeRef(_14774);
    _14774 = NOVALUE;
    DeRef(_14799);
    _14799 = NOVALUE;
    DeRef(_14720);
    _14720 = NOVALUE;
    DeRef(_14667);
    _14667 = NOVALUE;
    DeRef(_14791);
    _14791 = NOVALUE;
    DeRef(_14678);
    _14678 = NOVALUE;
    DeRef(_14562);
    _14562 = NOVALUE;
    _14623 = NOVALUE;
    DeRef(_14671);
    _14671 = NOVALUE;
    DeRef(_14565);
    _14565 = NOVALUE;
    DeRef(_14743);
    _14743 = NOVALUE;
    DeRef(_14693);
    _14693 = NOVALUE;
    return _14800;
    goto L1; // [2537] 10
L6E: 

    /** 		elsif class = res:CONCAT then*/
    if (_class_25608 != 15)
    goto L70; // [2542] 2592

    /** 			ch = getch()*/
    _ch_25596 = _61getch();
    if (!IS_ATOM_INT(_ch_25596)) {
        _1 = (long)(DBL_PTR(_ch_25596)->dbl);
        DeRefDS(_ch_25596);
        _ch_25596 = _1;
    }

    /** 			if ch = '=' then*/
    if (_ch_25596 != 61)
    goto L71; // [2555] 2574

    /** 				return {CONCAT_EQUALS, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 519;
    ((int *)_2)[2] = 0;
    _14804 = MAKE_SEQ(_1);
    DeRef(_yytext_25602);
    DeRef(_namespaces_25603);
    DeRef(_d_25604);
    DeRef(_tok_25606);
    DeRef(_name_25609);
    _14716 = NOVALUE;
    DeRef(_14781);
    _14781 = NOVALUE;
    DeRef(_14765);
    _14765 = NOVALUE;
    DeRef(_14800);
    _14800 = NOVALUE;
    DeRef(_14572);
    _14572 = NOVALUE;
    _14587 = NOVALUE;
    DeRef(_14780);
    _14780 = NOVALUE;
    DeRef(_14728);
    _14728 = NOVALUE;
    _14691 = NOVALUE;
    DeRef(_14745);
    _14745 = NOVALUE;
    DeRef(_14755);
    _14755 = NOVALUE;
    DeRef(_14795);
    _14795 = NOVALUE;
    DeRef(_14575);
    _14575 = NOVALUE;
    DeRef(_14726);
    _14726 = NOVALUE;
    DeRef(_14622);
    _14622 = NOVALUE;
    DeRef(_14591);
    _14591 = NOVALUE;
    DeRef(_14672);
    _14672 = NOVALUE;
    DeRef(_14767);
    _14767 = NOVALUE;
    _14738 = NOVALUE;
    DeRef(_14559);
    _14559 = NOVALUE;
    DeRef(_14596);
    _14596 = NOVALUE;
    _14638 = NOVALUE;
    DeRef(_14550);
    _14550 = NOVALUE;
    _14601 = NOVALUE;
    _14712 = NOVALUE;
    DeRef(_14757);
    _14757 = NOVALUE;
    _14681 = NOVALUE;
    DeRef(_14772);
    _14772 = NOVALUE;
    DeRef(_14545);
    _14545 = NOVALUE;
    DeRef(_14568);
    _14568 = NOVALUE;
    DeRef(_14571);
    _14571 = NOVALUE;
    _14612 = NOVALUE;
    _14734 = NOVALUE;
    DeRef(_14774);
    _14774 = NOVALUE;
    DeRef(_14799);
    _14799 = NOVALUE;
    DeRef(_14720);
    _14720 = NOVALUE;
    DeRef(_14667);
    _14667 = NOVALUE;
    DeRef(_14791);
    _14791 = NOVALUE;
    DeRef(_14678);
    _14678 = NOVALUE;
    DeRef(_14562);
    _14562 = NOVALUE;
    _14623 = NOVALUE;
    DeRef(_14671);
    _14671 = NOVALUE;
    DeRef(_14565);
    _14565 = NOVALUE;
    DeRef(_14743);
    _14743 = NOVALUE;
    DeRef(_14693);
    _14693 = NOVALUE;
    return _14804;
    goto L1; // [2571] 10
L71: 

    /** 				ungetch()*/
    _61ungetch();

    /** 				return {res:CONCAT, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 15;
    ((int *)_2)[2] = 0;
    _14805 = MAKE_SEQ(_1);
    DeRef(_yytext_25602);
    DeRef(_namespaces_25603);
    DeRef(_d_25604);
    DeRef(_tok_25606);
    DeRef(_name_25609);
    _14716 = NOVALUE;
    DeRef(_14781);
    _14781 = NOVALUE;
    DeRef(_14765);
    _14765 = NOVALUE;
    DeRef(_14800);
    _14800 = NOVALUE;
    DeRef(_14572);
    _14572 = NOVALUE;
    _14587 = NOVALUE;
    DeRef(_14780);
    _14780 = NOVALUE;
    DeRef(_14728);
    _14728 = NOVALUE;
    _14691 = NOVALUE;
    DeRef(_14745);
    _14745 = NOVALUE;
    DeRef(_14755);
    _14755 = NOVALUE;
    DeRef(_14795);
    _14795 = NOVALUE;
    DeRef(_14575);
    _14575 = NOVALUE;
    DeRef(_14726);
    _14726 = NOVALUE;
    DeRef(_14622);
    _14622 = NOVALUE;
    DeRef(_14591);
    _14591 = NOVALUE;
    DeRef(_14672);
    _14672 = NOVALUE;
    DeRef(_14767);
    _14767 = NOVALUE;
    _14738 = NOVALUE;
    DeRef(_14559);
    _14559 = NOVALUE;
    DeRef(_14596);
    _14596 = NOVALUE;
    _14638 = NOVALUE;
    DeRef(_14550);
    _14550 = NOVALUE;
    _14601 = NOVALUE;
    _14712 = NOVALUE;
    DeRef(_14757);
    _14757 = NOVALUE;
    _14681 = NOVALUE;
    DeRef(_14772);
    _14772 = NOVALUE;
    DeRef(_14545);
    _14545 = NOVALUE;
    DeRef(_14568);
    _14568 = NOVALUE;
    DeRef(_14571);
    _14571 = NOVALUE;
    _14612 = NOVALUE;
    _14734 = NOVALUE;
    DeRef(_14774);
    _14774 = NOVALUE;
    DeRef(_14799);
    _14799 = NOVALUE;
    DeRef(_14720);
    _14720 = NOVALUE;
    DeRef(_14804);
    _14804 = NOVALUE;
    DeRef(_14667);
    _14667 = NOVALUE;
    DeRef(_14791);
    _14791 = NOVALUE;
    DeRef(_14678);
    _14678 = NOVALUE;
    DeRef(_14562);
    _14562 = NOVALUE;
    _14623 = NOVALUE;
    DeRef(_14671);
    _14671 = NOVALUE;
    DeRef(_14565);
    _14565 = NOVALUE;
    DeRef(_14743);
    _14743 = NOVALUE;
    DeRef(_14693);
    _14693 = NOVALUE;
    return _14805;
    goto L1; // [2589] 10
L70: 

    /** 		elsif class = NUMBER_SIGN then*/
    if (_class_25608 != -11)
    goto L72; // [2596] 3114

    /** 			i = 0*/
    _i_25597 = 0;

    /** 			is_int = -1*/
    _is_int_25607 = -1;

    /** 			while i < MAXINT/32 do*/
L73: 
    _14807 = (1073741823 % 32) ? NewDouble((double)1073741823 / 32) : (1073741823 / 32);
    if (binary_op_a(GREATEREQ, _i_25597, _14807)){
        DeRef(_14807);
        _14807 = NOVALUE;
        goto L74; // [2621] 2791
    }
    DeRef(_14807);
    _14807 = NOVALUE;

    /** 				ch = getch()*/
    _ch_25596 = _61getch();
    if (!IS_ATOM_INT(_ch_25596)) {
        _1 = (long)(DBL_PTR(_ch_25596)->dbl);
        DeRefDS(_ch_25596);
        _ch_25596 = _1;
    }

    /** 				if char_class[ch] = DIGIT then*/
    _2 = (int)SEQ_PTR(_61char_class_23903);
    _14810 = (int)*(((s1_ptr)_2)->base + _ch_25596);
    if (_14810 != -7)
    goto L75; // [2642] 2681

    /** 					if ch != '_' then*/
    if (_ch_25596 == 95)
    goto L73; // [2648] 2615

    /** 						i = i * 16 + ch - '0'*/
    if (_i_25597 == (short)_i_25597)
    _14813 = _i_25597 * 16;
    else
    _14813 = NewDouble(_i_25597 * (double)16);
    if (IS_ATOM_INT(_14813)) {
        _14814 = _14813 + _ch_25596;
        if ((long)((unsigned long)_14814 + (unsigned long)HIGH_BITS) >= 0) 
        _14814 = NewDouble((double)_14814);
    }
    else {
        _14814 = NewDouble(DBL_PTR(_14813)->dbl + (double)_ch_25596);
    }
    DeRef(_14813);
    _14813 = NOVALUE;
    if (IS_ATOM_INT(_14814)) {
        _i_25597 = _14814 - 48;
    }
    else {
        _i_25597 = NewDouble(DBL_PTR(_14814)->dbl - (double)48);
    }
    DeRef(_14814);
    _14814 = NOVALUE;
    if (!IS_ATOM_INT(_i_25597)) {
        _1 = (long)(DBL_PTR(_i_25597)->dbl);
        DeRefDS(_i_25597);
        _i_25597 = _1;
    }

    /** 						is_int = TRUE*/
    _is_int_25607 = _13TRUE_436;
    goto L73; // [2678] 2615
L75: 

    /** 				elsif ch >= 'A' and ch <= 'F' then*/
    _14816 = (_ch_25596 >= 65);
    if (_14816 == 0) {
        goto L76; // [2687] 2731
    }
    _14818 = (_ch_25596 <= 70);
    if (_14818 == 0)
    {
        DeRef(_14818);
        _14818 = NOVALUE;
        goto L76; // [2696] 2731
    }
    else{
        DeRef(_14818);
        _14818 = NOVALUE;
    }

    /** 					i = (i * 16) + ch - ('A'-10)*/
    if (_i_25597 == (short)_i_25597)
    _14819 = _i_25597 * 16;
    else
    _14819 = NewDouble(_i_25597 * (double)16);
    if (IS_ATOM_INT(_14819)) {
        _14820 = _14819 + _ch_25596;
        if ((long)((unsigned long)_14820 + (unsigned long)HIGH_BITS) >= 0) 
        _14820 = NewDouble((double)_14820);
    }
    else {
        _14820 = NewDouble(DBL_PTR(_14819)->dbl + (double)_ch_25596);
    }
    DeRef(_14819);
    _14819 = NOVALUE;
    _14821 = 55;
    if (IS_ATOM_INT(_14820)) {
        _i_25597 = _14820 - 55;
    }
    else {
        _i_25597 = NewDouble(DBL_PTR(_14820)->dbl - (double)55);
    }
    DeRef(_14820);
    _14820 = NOVALUE;
    _14821 = NOVALUE;
    if (!IS_ATOM_INT(_i_25597)) {
        _1 = (long)(DBL_PTR(_i_25597)->dbl);
        DeRefDS(_i_25597);
        _i_25597 = _1;
    }

    /** 					is_int = TRUE*/
    _is_int_25607 = _13TRUE_436;
    goto L73; // [2728] 2615
L76: 

    /** 				elsif ch >= 'a' and ch <= 'f' then*/
    _14823 = (_ch_25596 >= 97);
    if (_14823 == 0) {
        goto L74; // [2737] 2791
    }
    _14825 = (_ch_25596 <= 102);
    if (_14825 == 0)
    {
        DeRef(_14825);
        _14825 = NOVALUE;
        goto L74; // [2746] 2791
    }
    else{
        DeRef(_14825);
        _14825 = NOVALUE;
    }

    /** 					i = (i * 16) + ch - ('a'-10)*/
    if (_i_25597 == (short)_i_25597)
    _14826 = _i_25597 * 16;
    else
    _14826 = NewDouble(_i_25597 * (double)16);
    if (IS_ATOM_INT(_14826)) {
        _14827 = _14826 + _ch_25596;
        if ((long)((unsigned long)_14827 + (unsigned long)HIGH_BITS) >= 0) 
        _14827 = NewDouble((double)_14827);
    }
    else {
        _14827 = NewDouble(DBL_PTR(_14826)->dbl + (double)_ch_25596);
    }
    DeRef(_14826);
    _14826 = NOVALUE;
    _14828 = 87;
    if (IS_ATOM_INT(_14827)) {
        _i_25597 = _14827 - 87;
    }
    else {
        _i_25597 = NewDouble(DBL_PTR(_14827)->dbl - (double)87);
    }
    DeRef(_14827);
    _14827 = NOVALUE;
    _14828 = NOVALUE;
    if (!IS_ATOM_INT(_i_25597)) {
        _1 = (long)(DBL_PTR(_i_25597)->dbl);
        DeRefDS(_i_25597);
        _i_25597 = _1;
    }

    /** 					is_int = TRUE*/
    _is_int_25607 = _13TRUE_436;
    goto L73; // [2778] 2615

    /** 					exit*/
    goto L74; // [2783] 2791

    /** 			end while*/
    goto L73; // [2788] 2615
L74: 

    /** 			if is_int = -1 then*/
    if (_is_int_25607 != -1)
    goto L77; // [2793] 2856

    /** 				if ch = '!' then*/
    if (_ch_25596 != 33)
    goto L78; // [2799] 2845

    /** 					if line_number > 1 then*/
    if (_35line_number_16245 <= 1)
    goto L79; // [2807] 2819

    /** 						CompileErr(161)*/
    RefDS(_22023);
    _44CompileErr(161, _22023, 0);
L79: 

    /** 					shebang = ThisLine*/
    Ref(_44ThisLine_48518);
    DeRef(_61shebang_23901);
    _61shebang_23901 = _44ThisLine_48518;

    /** 					if start_include then*/
    if (_61start_include_23896 == 0)
    {
        goto L7A; // [2830] 2838
    }
    else{
    }

    /** 						IncludePush()*/
    _61IncludePush();
L7A: 

    /** 					read_line()*/
    _61read_line();
    goto L1; // [2842] 10
L78: 

    /** 					CompileErr(97)*/
    RefDS(_22023);
    _44CompileErr(97, _22023, 0);
    goto L1; // [2853] 10
L77: 

    /** 				if i >= MAXINT/32 then*/
    _14833 = (1073741823 % 32) ? NewDouble((double)1073741823 / 32) : (1073741823 / 32);
    if (binary_op_a(LESS, _i_25597, _14833)){
        DeRef(_14833);
        _14833 = NOVALUE;
        goto L7B; // [2864] 3035
    }
    DeRef(_14833);
    _14833 = NOVALUE;

    /** 					d = i*/
    DeRef(_d_25604);
    _d_25604 = _i_25597;

    /** 					is_int = FALSE*/
    _is_int_25607 = _13FALSE_434;

    /** 					while TRUE do*/
L7C: 
    if (_13TRUE_436 == 0)
    {
        goto L7D; // [2889] 3034
    }
    else{
    }

    /** 						ch = getch()  -- eventually END_OF_FILE_CHAR or new-line*/
    _ch_25596 = _61getch();
    if (!IS_ATOM_INT(_ch_25596)) {
        _1 = (long)(DBL_PTR(_ch_25596)->dbl);
        DeRefDS(_ch_25596);
        _ch_25596 = _1;
    }

    /** 						if char_class[ch] = DIGIT then*/
    _2 = (int)SEQ_PTR(_61char_class_23903);
    _14836 = (int)*(((s1_ptr)_2)->base + _ch_25596);
    if (_14836 != -7)
    goto L7E; // [2909] 2937

    /** 							if ch != '_' then*/
    if (_ch_25596 == 95)
    goto L7C; // [2915] 2887

    /** 								d = (d * 16) + ch - '0'*/
    if (IS_ATOM_INT(_d_25604)) {
        if (_d_25604 == (short)_d_25604)
        _14839 = _d_25604 * 16;
        else
        _14839 = NewDouble(_d_25604 * (double)16);
    }
    else {
        _14839 = binary_op(MULTIPLY, _d_25604, 16);
    }
    if (IS_ATOM_INT(_14839)) {
        _14840 = _14839 + _ch_25596;
        if ((long)((unsigned long)_14840 + (unsigned long)HIGH_BITS) >= 0) 
        _14840 = NewDouble((double)_14840);
    }
    else {
        _14840 = binary_op(PLUS, _14839, _ch_25596);
    }
    DeRef(_14839);
    _14839 = NOVALUE;
    DeRef(_d_25604);
    if (IS_ATOM_INT(_14840)) {
        _d_25604 = _14840 - 48;
        if ((long)((unsigned long)_d_25604 +(unsigned long) HIGH_BITS) >= 0){
            _d_25604 = NewDouble((double)_d_25604);
        }
    }
    else {
        _d_25604 = binary_op(MINUS, _14840, 48);
    }
    DeRef(_14840);
    _14840 = NOVALUE;
    goto L7C; // [2934] 2887
L7E: 

    /** 						elsif ch >= 'A' and ch <= 'F' then*/
    _14842 = (_ch_25596 >= 65);
    if (_14842 == 0) {
        goto L7F; // [2943] 2976
    }
    _14844 = (_ch_25596 <= 70);
    if (_14844 == 0)
    {
        DeRef(_14844);
        _14844 = NOVALUE;
        goto L7F; // [2952] 2976
    }
    else{
        DeRef(_14844);
        _14844 = NOVALUE;
    }

    /** 							d = (d * 16) + ch - ('A'- 10)*/
    if (IS_ATOM_INT(_d_25604)) {
        if (_d_25604 == (short)_d_25604)
        _14845 = _d_25604 * 16;
        else
        _14845 = NewDouble(_d_25604 * (double)16);
    }
    else {
        _14845 = binary_op(MULTIPLY, _d_25604, 16);
    }
    if (IS_ATOM_INT(_14845)) {
        _14846 = _14845 + _ch_25596;
        if ((long)((unsigned long)_14846 + (unsigned long)HIGH_BITS) >= 0) 
        _14846 = NewDouble((double)_14846);
    }
    else {
        _14846 = binary_op(PLUS, _14845, _ch_25596);
    }
    DeRef(_14845);
    _14845 = NOVALUE;
    _14847 = 55;
    DeRef(_d_25604);
    if (IS_ATOM_INT(_14846)) {
        _d_25604 = _14846 - 55;
        if ((long)((unsigned long)_d_25604 +(unsigned long) HIGH_BITS) >= 0){
            _d_25604 = NewDouble((double)_d_25604);
        }
    }
    else {
        _d_25604 = binary_op(MINUS, _14846, 55);
    }
    DeRef(_14846);
    _14846 = NOVALUE;
    _14847 = NOVALUE;
    goto L7C; // [2973] 2887
L7F: 

    /** 						elsif ch >= 'a' and ch <= 'f' then*/
    _14849 = (_ch_25596 >= 97);
    if (_14849 == 0) {
        goto L80; // [2982] 3015
    }
    _14851 = (_ch_25596 <= 102);
    if (_14851 == 0)
    {
        DeRef(_14851);
        _14851 = NOVALUE;
        goto L80; // [2991] 3015
    }
    else{
        DeRef(_14851);
        _14851 = NOVALUE;
    }

    /** 							d = (d * 16) + ch - ('a'-10)*/
    if (IS_ATOM_INT(_d_25604)) {
        if (_d_25604 == (short)_d_25604)
        _14852 = _d_25604 * 16;
        else
        _14852 = NewDouble(_d_25604 * (double)16);
    }
    else {
        _14852 = binary_op(MULTIPLY, _d_25604, 16);
    }
    if (IS_ATOM_INT(_14852)) {
        _14853 = _14852 + _ch_25596;
        if ((long)((unsigned long)_14853 + (unsigned long)HIGH_BITS) >= 0) 
        _14853 = NewDouble((double)_14853);
    }
    else {
        _14853 = binary_op(PLUS, _14852, _ch_25596);
    }
    DeRef(_14852);
    _14852 = NOVALUE;
    _14854 = 87;
    DeRef(_d_25604);
    if (IS_ATOM_INT(_14853)) {
        _d_25604 = _14853 - 87;
        if ((long)((unsigned long)_d_25604 +(unsigned long) HIGH_BITS) >= 0){
            _d_25604 = NewDouble((double)_d_25604);
        }
    }
    else {
        _d_25604 = binary_op(MINUS, _14853, 87);
    }
    DeRef(_14853);
    _14853 = NOVALUE;
    _14854 = NOVALUE;
    goto L7C; // [3012] 2887
L80: 

    /** 						elsif ch = '_' then*/
    if (_ch_25596 != 95)
    goto L7D; // [3017] 3034
    goto L7C; // [3021] 2887

    /** 							exit*/
    goto L7D; // [3026] 3034

    /** 					end while*/
    goto L7C; // [3031] 2887
L7D: 
L7B: 

    /** 				ungetch()*/
    _61ungetch();

    /** 				if is_int then*/
    if (_is_int_25607 == 0)
    {
        goto L81; // [3041] 3063
    }
    else{
    }

    /** 					return {ATOM, NewIntSym(i)}*/
    _14857 = _53NewIntSym(_i_25597);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 502;
    ((int *)_2)[2] = _14857;
    _14858 = MAKE_SEQ(_1);
    _14857 = NOVALUE;
    DeRef(_yytext_25602);
    DeRef(_namespaces_25603);
    DeRef(_d_25604);
    DeRef(_tok_25606);
    DeRef(_name_25609);
    _14716 = NOVALUE;
    DeRef(_14781);
    _14781 = NOVALUE;
    DeRef(_14765);
    _14765 = NOVALUE;
    DeRef(_14800);
    _14800 = NOVALUE;
    DeRef(_14572);
    _14572 = NOVALUE;
    _14587 = NOVALUE;
    DeRef(_14780);
    _14780 = NOVALUE;
    DeRef(_14728);
    _14728 = NOVALUE;
    DeRef(_14849);
    _14849 = NOVALUE;
    _14691 = NOVALUE;
    DeRef(_14745);
    _14745 = NOVALUE;
    DeRef(_14755);
    _14755 = NOVALUE;
    DeRef(_14795);
    _14795 = NOVALUE;
    DeRef(_14575);
    _14575 = NOVALUE;
    DeRef(_14726);
    _14726 = NOVALUE;
    DeRef(_14622);
    _14622 = NOVALUE;
    DeRef(_14591);
    _14591 = NOVALUE;
    DeRef(_14672);
    _14672 = NOVALUE;
    DeRef(_14767);
    _14767 = NOVALUE;
    _14738 = NOVALUE;
    DeRef(_14559);
    _14559 = NOVALUE;
    DeRef(_14596);
    _14596 = NOVALUE;
    _14638 = NOVALUE;
    DeRef(_14550);
    _14550 = NOVALUE;
    _14601 = NOVALUE;
    _14712 = NOVALUE;
    DeRef(_14757);
    _14757 = NOVALUE;
    _14681 = NOVALUE;
    DeRef(_14772);
    _14772 = NOVALUE;
    _14810 = NOVALUE;
    DeRef(_14823);
    _14823 = NOVALUE;
    DeRef(_14545);
    _14545 = NOVALUE;
    DeRef(_14568);
    _14568 = NOVALUE;
    DeRef(_14571);
    _14571 = NOVALUE;
    _14612 = NOVALUE;
    _14734 = NOVALUE;
    DeRef(_14774);
    _14774 = NOVALUE;
    DeRef(_14799);
    _14799 = NOVALUE;
    DeRef(_14816);
    _14816 = NOVALUE;
    _14836 = NOVALUE;
    DeRef(_14720);
    _14720 = NOVALUE;
    DeRef(_14804);
    _14804 = NOVALUE;
    DeRef(_14667);
    _14667 = NOVALUE;
    DeRef(_14791);
    _14791 = NOVALUE;
    DeRef(_14805);
    _14805 = NOVALUE;
    DeRef(_14678);
    _14678 = NOVALUE;
    DeRef(_14562);
    _14562 = NOVALUE;
    _14623 = NOVALUE;
    DeRef(_14671);
    _14671 = NOVALUE;
    DeRef(_14842);
    _14842 = NOVALUE;
    DeRef(_14565);
    _14565 = NOVALUE;
    DeRef(_14743);
    _14743 = NOVALUE;
    DeRef(_14693);
    _14693 = NOVALUE;
    return _14858;
    goto L1; // [3060] 10
L81: 

    /** 					if d <= MAXINT_DBL then            -- d is always >= 0*/
    if (binary_op_a(GREATER, _d_25604, 1073741823)){
        goto L82; // [3069] 3092
    }

    /** 						return {ATOM, NewIntSym(d)}*/
    Ref(_d_25604);
    _14860 = _53NewIntSym(_d_25604);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 502;
    ((int *)_2)[2] = _14860;
    _14861 = MAKE_SEQ(_1);
    _14860 = NOVALUE;
    DeRef(_yytext_25602);
    DeRef(_namespaces_25603);
    DeRef(_d_25604);
    DeRef(_tok_25606);
    DeRef(_name_25609);
    _14716 = NOVALUE;
    DeRef(_14781);
    _14781 = NOVALUE;
    DeRef(_14765);
    _14765 = NOVALUE;
    DeRef(_14800);
    _14800 = NOVALUE;
    DeRef(_14572);
    _14572 = NOVALUE;
    _14587 = NOVALUE;
    DeRef(_14780);
    _14780 = NOVALUE;
    DeRef(_14728);
    _14728 = NOVALUE;
    DeRef(_14849);
    _14849 = NOVALUE;
    _14691 = NOVALUE;
    DeRef(_14745);
    _14745 = NOVALUE;
    DeRef(_14755);
    _14755 = NOVALUE;
    DeRef(_14795);
    _14795 = NOVALUE;
    DeRef(_14858);
    _14858 = NOVALUE;
    DeRef(_14575);
    _14575 = NOVALUE;
    DeRef(_14726);
    _14726 = NOVALUE;
    DeRef(_14622);
    _14622 = NOVALUE;
    DeRef(_14591);
    _14591 = NOVALUE;
    DeRef(_14672);
    _14672 = NOVALUE;
    DeRef(_14767);
    _14767 = NOVALUE;
    _14738 = NOVALUE;
    DeRef(_14559);
    _14559 = NOVALUE;
    DeRef(_14596);
    _14596 = NOVALUE;
    _14638 = NOVALUE;
    DeRef(_14550);
    _14550 = NOVALUE;
    _14601 = NOVALUE;
    _14712 = NOVALUE;
    DeRef(_14757);
    _14757 = NOVALUE;
    _14681 = NOVALUE;
    DeRef(_14772);
    _14772 = NOVALUE;
    _14810 = NOVALUE;
    DeRef(_14823);
    _14823 = NOVALUE;
    DeRef(_14545);
    _14545 = NOVALUE;
    DeRef(_14568);
    _14568 = NOVALUE;
    DeRef(_14571);
    _14571 = NOVALUE;
    _14612 = NOVALUE;
    _14734 = NOVALUE;
    DeRef(_14774);
    _14774 = NOVALUE;
    DeRef(_14799);
    _14799 = NOVALUE;
    DeRef(_14816);
    _14816 = NOVALUE;
    _14836 = NOVALUE;
    DeRef(_14720);
    _14720 = NOVALUE;
    DeRef(_14804);
    _14804 = NOVALUE;
    DeRef(_14667);
    _14667 = NOVALUE;
    DeRef(_14791);
    _14791 = NOVALUE;
    DeRef(_14805);
    _14805 = NOVALUE;
    DeRef(_14678);
    _14678 = NOVALUE;
    DeRef(_14562);
    _14562 = NOVALUE;
    _14623 = NOVALUE;
    DeRef(_14671);
    _14671 = NOVALUE;
    DeRef(_14842);
    _14842 = NOVALUE;
    DeRef(_14565);
    _14565 = NOVALUE;
    DeRef(_14743);
    _14743 = NOVALUE;
    DeRef(_14693);
    _14693 = NOVALUE;
    return _14861;
    goto L1; // [3089] 10
L82: 

    /** 						return {ATOM, NewDoubleSym(d)}*/
    Ref(_d_25604);
    _14862 = _53NewDoubleSym(_d_25604);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 502;
    ((int *)_2)[2] = _14862;
    _14863 = MAKE_SEQ(_1);
    _14862 = NOVALUE;
    DeRef(_yytext_25602);
    DeRef(_namespaces_25603);
    DeRef(_d_25604);
    DeRef(_tok_25606);
    DeRef(_name_25609);
    _14716 = NOVALUE;
    DeRef(_14781);
    _14781 = NOVALUE;
    DeRef(_14765);
    _14765 = NOVALUE;
    DeRef(_14800);
    _14800 = NOVALUE;
    DeRef(_14572);
    _14572 = NOVALUE;
    _14587 = NOVALUE;
    DeRef(_14780);
    _14780 = NOVALUE;
    DeRef(_14728);
    _14728 = NOVALUE;
    DeRef(_14849);
    _14849 = NOVALUE;
    _14691 = NOVALUE;
    DeRef(_14745);
    _14745 = NOVALUE;
    DeRef(_14755);
    _14755 = NOVALUE;
    DeRef(_14795);
    _14795 = NOVALUE;
    DeRef(_14858);
    _14858 = NOVALUE;
    DeRef(_14575);
    _14575 = NOVALUE;
    DeRef(_14726);
    _14726 = NOVALUE;
    DeRef(_14622);
    _14622 = NOVALUE;
    DeRef(_14591);
    _14591 = NOVALUE;
    DeRef(_14672);
    _14672 = NOVALUE;
    DeRef(_14767);
    _14767 = NOVALUE;
    _14738 = NOVALUE;
    DeRef(_14559);
    _14559 = NOVALUE;
    DeRef(_14596);
    _14596 = NOVALUE;
    _14638 = NOVALUE;
    DeRef(_14550);
    _14550 = NOVALUE;
    _14601 = NOVALUE;
    _14712 = NOVALUE;
    DeRef(_14757);
    _14757 = NOVALUE;
    _14681 = NOVALUE;
    DeRef(_14772);
    _14772 = NOVALUE;
    _14810 = NOVALUE;
    DeRef(_14823);
    _14823 = NOVALUE;
    DeRef(_14545);
    _14545 = NOVALUE;
    DeRef(_14568);
    _14568 = NOVALUE;
    DeRef(_14571);
    _14571 = NOVALUE;
    DeRef(_14861);
    _14861 = NOVALUE;
    _14612 = NOVALUE;
    _14734 = NOVALUE;
    DeRef(_14774);
    _14774 = NOVALUE;
    DeRef(_14799);
    _14799 = NOVALUE;
    DeRef(_14816);
    _14816 = NOVALUE;
    _14836 = NOVALUE;
    DeRef(_14720);
    _14720 = NOVALUE;
    DeRef(_14804);
    _14804 = NOVALUE;
    DeRef(_14667);
    _14667 = NOVALUE;
    DeRef(_14791);
    _14791 = NOVALUE;
    DeRef(_14805);
    _14805 = NOVALUE;
    DeRef(_14678);
    _14678 = NOVALUE;
    DeRef(_14562);
    _14562 = NOVALUE;
    _14623 = NOVALUE;
    DeRef(_14671);
    _14671 = NOVALUE;
    DeRef(_14842);
    _14842 = NOVALUE;
    DeRef(_14565);
    _14565 = NOVALUE;
    DeRef(_14743);
    _14743 = NOVALUE;
    DeRef(_14693);
    _14693 = NOVALUE;
    return _14863;
    goto L1; // [3111] 10
L72: 

    /** 		elsif class = res:MULTIPLY then*/
    if (_class_25608 != 13)
    goto L83; // [3116] 3166

    /** 			ch = getch()*/
    _ch_25596 = _61getch();
    if (!IS_ATOM_INT(_ch_25596)) {
        _1 = (long)(DBL_PTR(_ch_25596)->dbl);
        DeRefDS(_ch_25596);
        _ch_25596 = _1;
    }

    /** 			if ch = '=' then*/
    if (_ch_25596 != 61)
    goto L84; // [3129] 3148

    /** 				return {MULTIPLY_EQUALS, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 517;
    ((int *)_2)[2] = 0;
    _14867 = MAKE_SEQ(_1);
    DeRef(_yytext_25602);
    DeRef(_namespaces_25603);
    DeRef(_d_25604);
    DeRef(_tok_25606);
    DeRef(_name_25609);
    _14716 = NOVALUE;
    DeRef(_14781);
    _14781 = NOVALUE;
    DeRef(_14765);
    _14765 = NOVALUE;
    DeRef(_14800);
    _14800 = NOVALUE;
    DeRef(_14572);
    _14572 = NOVALUE;
    _14587 = NOVALUE;
    DeRef(_14780);
    _14780 = NOVALUE;
    DeRef(_14728);
    _14728 = NOVALUE;
    DeRef(_14849);
    _14849 = NOVALUE;
    _14691 = NOVALUE;
    DeRef(_14745);
    _14745 = NOVALUE;
    DeRef(_14755);
    _14755 = NOVALUE;
    DeRef(_14795);
    _14795 = NOVALUE;
    DeRef(_14858);
    _14858 = NOVALUE;
    DeRef(_14575);
    _14575 = NOVALUE;
    DeRef(_14726);
    _14726 = NOVALUE;
    DeRef(_14863);
    _14863 = NOVALUE;
    DeRef(_14622);
    _14622 = NOVALUE;
    DeRef(_14591);
    _14591 = NOVALUE;
    DeRef(_14672);
    _14672 = NOVALUE;
    DeRef(_14767);
    _14767 = NOVALUE;
    _14738 = NOVALUE;
    DeRef(_14559);
    _14559 = NOVALUE;
    DeRef(_14596);
    _14596 = NOVALUE;
    _14638 = NOVALUE;
    DeRef(_14550);
    _14550 = NOVALUE;
    _14601 = NOVALUE;
    _14712 = NOVALUE;
    DeRef(_14757);
    _14757 = NOVALUE;
    _14681 = NOVALUE;
    DeRef(_14772);
    _14772 = NOVALUE;
    _14810 = NOVALUE;
    DeRef(_14823);
    _14823 = NOVALUE;
    DeRef(_14545);
    _14545 = NOVALUE;
    DeRef(_14568);
    _14568 = NOVALUE;
    DeRef(_14571);
    _14571 = NOVALUE;
    DeRef(_14861);
    _14861 = NOVALUE;
    _14612 = NOVALUE;
    _14734 = NOVALUE;
    DeRef(_14774);
    _14774 = NOVALUE;
    DeRef(_14799);
    _14799 = NOVALUE;
    DeRef(_14816);
    _14816 = NOVALUE;
    _14836 = NOVALUE;
    DeRef(_14720);
    _14720 = NOVALUE;
    DeRef(_14804);
    _14804 = NOVALUE;
    DeRef(_14667);
    _14667 = NOVALUE;
    DeRef(_14791);
    _14791 = NOVALUE;
    DeRef(_14805);
    _14805 = NOVALUE;
    DeRef(_14678);
    _14678 = NOVALUE;
    DeRef(_14562);
    _14562 = NOVALUE;
    _14623 = NOVALUE;
    DeRef(_14671);
    _14671 = NOVALUE;
    DeRef(_14842);
    _14842 = NOVALUE;
    DeRef(_14565);
    _14565 = NOVALUE;
    DeRef(_14743);
    _14743 = NOVALUE;
    DeRef(_14693);
    _14693 = NOVALUE;
    return _14867;
    goto L1; // [3145] 10
L84: 

    /** 				ungetch()*/
    _61ungetch();

    /** 				return {res:MULTIPLY, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 13;
    ((int *)_2)[2] = 0;
    _14868 = MAKE_SEQ(_1);
    DeRef(_yytext_25602);
    DeRef(_namespaces_25603);
    DeRef(_d_25604);
    DeRef(_tok_25606);
    DeRef(_name_25609);
    _14716 = NOVALUE;
    DeRef(_14781);
    _14781 = NOVALUE;
    DeRef(_14765);
    _14765 = NOVALUE;
    DeRef(_14800);
    _14800 = NOVALUE;
    DeRef(_14572);
    _14572 = NOVALUE;
    _14587 = NOVALUE;
    DeRef(_14780);
    _14780 = NOVALUE;
    DeRef(_14728);
    _14728 = NOVALUE;
    DeRef(_14849);
    _14849 = NOVALUE;
    _14691 = NOVALUE;
    DeRef(_14745);
    _14745 = NOVALUE;
    DeRef(_14755);
    _14755 = NOVALUE;
    DeRef(_14795);
    _14795 = NOVALUE;
    DeRef(_14858);
    _14858 = NOVALUE;
    DeRef(_14575);
    _14575 = NOVALUE;
    DeRef(_14726);
    _14726 = NOVALUE;
    DeRef(_14863);
    _14863 = NOVALUE;
    DeRef(_14622);
    _14622 = NOVALUE;
    DeRef(_14591);
    _14591 = NOVALUE;
    DeRef(_14672);
    _14672 = NOVALUE;
    DeRef(_14767);
    _14767 = NOVALUE;
    DeRef(_14867);
    _14867 = NOVALUE;
    _14738 = NOVALUE;
    DeRef(_14559);
    _14559 = NOVALUE;
    DeRef(_14596);
    _14596 = NOVALUE;
    _14638 = NOVALUE;
    DeRef(_14550);
    _14550 = NOVALUE;
    _14601 = NOVALUE;
    _14712 = NOVALUE;
    DeRef(_14757);
    _14757 = NOVALUE;
    _14681 = NOVALUE;
    DeRef(_14772);
    _14772 = NOVALUE;
    _14810 = NOVALUE;
    DeRef(_14823);
    _14823 = NOVALUE;
    DeRef(_14545);
    _14545 = NOVALUE;
    DeRef(_14568);
    _14568 = NOVALUE;
    DeRef(_14571);
    _14571 = NOVALUE;
    DeRef(_14861);
    _14861 = NOVALUE;
    _14612 = NOVALUE;
    _14734 = NOVALUE;
    DeRef(_14774);
    _14774 = NOVALUE;
    DeRef(_14799);
    _14799 = NOVALUE;
    DeRef(_14816);
    _14816 = NOVALUE;
    _14836 = NOVALUE;
    DeRef(_14720);
    _14720 = NOVALUE;
    DeRef(_14804);
    _14804 = NOVALUE;
    DeRef(_14667);
    _14667 = NOVALUE;
    DeRef(_14791);
    _14791 = NOVALUE;
    DeRef(_14805);
    _14805 = NOVALUE;
    DeRef(_14678);
    _14678 = NOVALUE;
    DeRef(_14562);
    _14562 = NOVALUE;
    _14623 = NOVALUE;
    DeRef(_14671);
    _14671 = NOVALUE;
    DeRef(_14842);
    _14842 = NOVALUE;
    DeRef(_14565);
    _14565 = NOVALUE;
    DeRef(_14743);
    _14743 = NOVALUE;
    DeRef(_14693);
    _14693 = NOVALUE;
    return _14868;
    goto L1; // [3163] 10
L83: 

    /** 		elsif class = res:DIVIDE then*/
    if (_class_25608 != 14)
    goto L85; // [3168] 3370

    /** 			ch = getch()*/
    _ch_25596 = _61getch();
    if (!IS_ATOM_INT(_ch_25596)) {
        _1 = (long)(DBL_PTR(_ch_25596)->dbl);
        DeRefDS(_ch_25596);
        _ch_25596 = _1;
    }

    /** 			if ch = '=' then*/
    if (_ch_25596 != 61)
    goto L86; // [3181] 3200

    /** 				return {DIVIDE_EQUALS, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 518;
    ((int *)_2)[2] = 0;
    _14872 = MAKE_SEQ(_1);
    DeRef(_yytext_25602);
    DeRef(_namespaces_25603);
    DeRef(_d_25604);
    DeRef(_tok_25606);
    DeRef(_name_25609);
    _14716 = NOVALUE;
    DeRef(_14781);
    _14781 = NOVALUE;
    DeRef(_14765);
    _14765 = NOVALUE;
    DeRef(_14800);
    _14800 = NOVALUE;
    DeRef(_14572);
    _14572 = NOVALUE;
    _14587 = NOVALUE;
    DeRef(_14780);
    _14780 = NOVALUE;
    DeRef(_14728);
    _14728 = NOVALUE;
    DeRef(_14849);
    _14849 = NOVALUE;
    _14691 = NOVALUE;
    DeRef(_14745);
    _14745 = NOVALUE;
    DeRef(_14755);
    _14755 = NOVALUE;
    DeRef(_14868);
    _14868 = NOVALUE;
    DeRef(_14795);
    _14795 = NOVALUE;
    DeRef(_14858);
    _14858 = NOVALUE;
    DeRef(_14575);
    _14575 = NOVALUE;
    DeRef(_14726);
    _14726 = NOVALUE;
    DeRef(_14863);
    _14863 = NOVALUE;
    DeRef(_14622);
    _14622 = NOVALUE;
    DeRef(_14591);
    _14591 = NOVALUE;
    DeRef(_14672);
    _14672 = NOVALUE;
    DeRef(_14767);
    _14767 = NOVALUE;
    DeRef(_14867);
    _14867 = NOVALUE;
    _14738 = NOVALUE;
    DeRef(_14559);
    _14559 = NOVALUE;
    DeRef(_14596);
    _14596 = NOVALUE;
    _14638 = NOVALUE;
    DeRef(_14550);
    _14550 = NOVALUE;
    _14601 = NOVALUE;
    _14712 = NOVALUE;
    DeRef(_14757);
    _14757 = NOVALUE;
    _14681 = NOVALUE;
    DeRef(_14772);
    _14772 = NOVALUE;
    _14810 = NOVALUE;
    DeRef(_14823);
    _14823 = NOVALUE;
    DeRef(_14545);
    _14545 = NOVALUE;
    DeRef(_14568);
    _14568 = NOVALUE;
    DeRef(_14571);
    _14571 = NOVALUE;
    DeRef(_14861);
    _14861 = NOVALUE;
    _14612 = NOVALUE;
    _14734 = NOVALUE;
    DeRef(_14774);
    _14774 = NOVALUE;
    DeRef(_14799);
    _14799 = NOVALUE;
    DeRef(_14816);
    _14816 = NOVALUE;
    _14836 = NOVALUE;
    DeRef(_14720);
    _14720 = NOVALUE;
    DeRef(_14804);
    _14804 = NOVALUE;
    DeRef(_14667);
    _14667 = NOVALUE;
    DeRef(_14791);
    _14791 = NOVALUE;
    DeRef(_14805);
    _14805 = NOVALUE;
    DeRef(_14678);
    _14678 = NOVALUE;
    DeRef(_14562);
    _14562 = NOVALUE;
    _14623 = NOVALUE;
    DeRef(_14671);
    _14671 = NOVALUE;
    DeRef(_14842);
    _14842 = NOVALUE;
    DeRef(_14565);
    _14565 = NOVALUE;
    DeRef(_14743);
    _14743 = NOVALUE;
    DeRef(_14693);
    _14693 = NOVALUE;
    return _14872;
    goto L1; // [3197] 10
L86: 

    /** 			elsif ch = '*' then*/
    if (_ch_25596 != 42)
    goto L87; // [3202] 3352

    /** 				cline = line_number*/
    _cline_25601 = _35line_number_16245;

    /** 				integer cnest = 1*/
    _cnest_26257 = 1;

    /** 				while cnest > 0 do*/
L88: 
    if (_cnest_26257 <= 0)
    goto L89; // [3225] 3333

    /** 					ch = getch()*/
    _ch_25596 = _61getch();
    if (!IS_ATOM_INT(_ch_25596)) {
        _1 = (long)(DBL_PTR(_ch_25596)->dbl);
        DeRefDS(_ch_25596);
        _ch_25596 = _1;
    }

    /** 					switch ch do*/
    _0 = _ch_25596;
    switch ( _0 ){ 

        /** 						case  END_OF_FILE_CHAR then*/
        case 26:

        /** 							exit*/
        goto L89; // [3249] 3333
        goto L88; // [3251] 3225

        /** 						case '\n' then*/
        case 10:

        /** 							read_line()*/
        _61read_line();
        goto L88; // [3261] 3225

        /** 						case '*' then*/
        case 42:

        /** 							ch = getch()*/
        _ch_25596 = _61getch();
        if (!IS_ATOM_INT(_ch_25596)) {
            _1 = (long)(DBL_PTR(_ch_25596)->dbl);
            DeRefDS(_ch_25596);
            _ch_25596 = _1;
        }

        /** 							if ch = '/' then*/
        if (_ch_25596 != 47)
        goto L8A; // [3276] 3289

        /** 								cnest -= 1*/
        _cnest_26257 = _cnest_26257 - 1;
        goto L88; // [3286] 3225
L8A: 

        /** 								ungetch()*/
        _61ungetch();
        goto L88; // [3294] 3225

        /** 						case '/' then*/
        case 47:

        /** 							ch = getch()*/
        _ch_25596 = _61getch();
        if (!IS_ATOM_INT(_ch_25596)) {
            _1 = (long)(DBL_PTR(_ch_25596)->dbl);
            DeRefDS(_ch_25596);
            _ch_25596 = _1;
        }

        /** 							if ch = '*' then*/
        if (_ch_25596 != 42)
        goto L8B; // [3309] 3322

        /** 								cnest += 1*/
        _cnest_26257 = _cnest_26257 + 1;
        goto L8C; // [3319] 3327
L8B: 

        /** 								ungetch()*/
        _61ungetch();
L8C: 
    ;}
    /** 				end while*/
    goto L88; // [3330] 3225
L89: 

    /** 				if cnest > 0 then*/
    if (_cnest_26257 <= 0)
    goto L8D; // [3335] 3347

    /** 					CompileErr(42, cline)*/
    _44CompileErr(42, _cline_25601, 0);
L8D: 
    goto L1; // [3349] 10
L87: 

    /** 				ungetch()*/
    _61ungetch();

    /** 				return {res:DIVIDE, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 14;
    ((int *)_2)[2] = 0;
    _14885 = MAKE_SEQ(_1);
    DeRef(_yytext_25602);
    DeRef(_namespaces_25603);
    DeRef(_d_25604);
    DeRef(_tok_25606);
    DeRef(_name_25609);
    DeRef(_14872);
    _14872 = NOVALUE;
    _14716 = NOVALUE;
    DeRef(_14781);
    _14781 = NOVALUE;
    DeRef(_14765);
    _14765 = NOVALUE;
    DeRef(_14800);
    _14800 = NOVALUE;
    DeRef(_14572);
    _14572 = NOVALUE;
    _14587 = NOVALUE;
    DeRef(_14780);
    _14780 = NOVALUE;
    DeRef(_14728);
    _14728 = NOVALUE;
    DeRef(_14849);
    _14849 = NOVALUE;
    _14691 = NOVALUE;
    DeRef(_14745);
    _14745 = NOVALUE;
    DeRef(_14755);
    _14755 = NOVALUE;
    DeRef(_14868);
    _14868 = NOVALUE;
    DeRef(_14795);
    _14795 = NOVALUE;
    DeRef(_14858);
    _14858 = NOVALUE;
    DeRef(_14575);
    _14575 = NOVALUE;
    DeRef(_14726);
    _14726 = NOVALUE;
    DeRef(_14863);
    _14863 = NOVALUE;
    DeRef(_14622);
    _14622 = NOVALUE;
    DeRef(_14591);
    _14591 = NOVALUE;
    DeRef(_14672);
    _14672 = NOVALUE;
    DeRef(_14767);
    _14767 = NOVALUE;
    DeRef(_14867);
    _14867 = NOVALUE;
    _14738 = NOVALUE;
    DeRef(_14559);
    _14559 = NOVALUE;
    DeRef(_14596);
    _14596 = NOVALUE;
    _14638 = NOVALUE;
    DeRef(_14550);
    _14550 = NOVALUE;
    _14601 = NOVALUE;
    _14712 = NOVALUE;
    DeRef(_14757);
    _14757 = NOVALUE;
    _14681 = NOVALUE;
    DeRef(_14772);
    _14772 = NOVALUE;
    _14810 = NOVALUE;
    DeRef(_14823);
    _14823 = NOVALUE;
    DeRef(_14545);
    _14545 = NOVALUE;
    DeRef(_14568);
    _14568 = NOVALUE;
    DeRef(_14571);
    _14571 = NOVALUE;
    DeRef(_14861);
    _14861 = NOVALUE;
    _14612 = NOVALUE;
    _14734 = NOVALUE;
    DeRef(_14774);
    _14774 = NOVALUE;
    DeRef(_14799);
    _14799 = NOVALUE;
    DeRef(_14816);
    _14816 = NOVALUE;
    _14836 = NOVALUE;
    DeRef(_14720);
    _14720 = NOVALUE;
    DeRef(_14804);
    _14804 = NOVALUE;
    DeRef(_14667);
    _14667 = NOVALUE;
    DeRef(_14791);
    _14791 = NOVALUE;
    DeRef(_14805);
    _14805 = NOVALUE;
    DeRef(_14678);
    _14678 = NOVALUE;
    DeRef(_14562);
    _14562 = NOVALUE;
    _14623 = NOVALUE;
    DeRef(_14671);
    _14671 = NOVALUE;
    DeRef(_14842);
    _14842 = NOVALUE;
    DeRef(_14565);
    _14565 = NOVALUE;
    DeRef(_14743);
    _14743 = NOVALUE;
    DeRef(_14693);
    _14693 = NOVALUE;
    return _14885;
    goto L1; // [3367] 10
L85: 

    /** 		elsif class = SINGLE_QUOTE then*/
    if (_class_25608 != -5)
    goto L8E; // [3374] 3515

    /** 			atom ach = getch()*/
    _0 = _ach_26286;
    _ach_26286 = _61getch();
    DeRef(_0);

    /** 			if ach = '\\' then*/
    if (binary_op_a(NOTEQ, _ach_26286, 92)){
        goto L8F; // [3385] 3398
    }

    /** 				ach = EscapeChar('\'')*/
    _0 = _ach_26286;
    _ach_26286 = _61EscapeChar(39);
    DeRef(_0);
    goto L90; // [3395] 3449
L8F: 

    /** 			elsif ach = '\t' then*/
    if (binary_op_a(NOTEQ, _ach_26286, 9)){
        goto L91; // [3400] 3414
    }

    /** 				CompileErr(145)*/
    RefDS(_22023);
    _44CompileErr(145, _22023, 0);
    goto L90; // [3411] 3449
L91: 

    /** 			elsif ach = '\'' then*/
    if (binary_op_a(NOTEQ, _ach_26286, 39)){
        goto L92; // [3416] 3430
    }

    /** 				CompileErr(137)*/
    RefDS(_22023);
    _44CompileErr(137, _22023, 0);
    goto L90; // [3427] 3449
L92: 

    /** 			elsif ach = '\n' then*/
    if (binary_op_a(NOTEQ, _ach_26286, 10)){
        goto L93; // [3432] 3448
    }

    /** 				CompileErr(68, {"character", "end of line"})*/
    RefDS(_14894);
    RefDS(_14893);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _14893;
    ((int *)_2)[2] = _14894;
    _14895 = MAKE_SEQ(_1);
    _44CompileErr(68, _14895, 0);
    _14895 = NOVALUE;
L93: 
L90: 

    /** 			if getch() != '\'' then*/
    _14896 = _61getch();
    if (binary_op_a(EQUALS, _14896, 39)){
        DeRef(_14896);
        _14896 = NOVALUE;
        goto L94; // [3454] 3466
    }
    DeRef(_14896);
    _14896 = NOVALUE;

    /** 				CompileErr(56)*/
    RefDS(_22023);
    _44CompileErr(56, _22023, 0);
L94: 

    /** 			if integer(ach) then*/
    if (IS_ATOM_INT(_ach_26286))
    _14898 = 1;
    else if (IS_ATOM_DBL(_ach_26286))
    _14898 = IS_ATOM_INT(DoubleToInt(_ach_26286));
    else
    _14898 = 0;
    if (_14898 == 0)
    {
        _14898 = NOVALUE;
        goto L95; // [3471] 3493
    }
    else{
        _14898 = NOVALUE;
    }

    /** 				return {ATOM, NewIntSym(ach)}*/
    Ref(_ach_26286);
    _14899 = _53NewIntSym(_ach_26286);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 502;
    ((int *)_2)[2] = _14899;
    _14900 = MAKE_SEQ(_1);
    _14899 = NOVALUE;
    DeRef(_ach_26286);
    DeRef(_yytext_25602);
    DeRef(_namespaces_25603);
    DeRef(_d_25604);
    DeRef(_tok_25606);
    DeRef(_name_25609);
    DeRef(_14872);
    _14872 = NOVALUE;
    _14716 = NOVALUE;
    DeRef(_14781);
    _14781 = NOVALUE;
    DeRef(_14765);
    _14765 = NOVALUE;
    DeRef(_14800);
    _14800 = NOVALUE;
    DeRef(_14572);
    _14572 = NOVALUE;
    _14587 = NOVALUE;
    DeRef(_14780);
    _14780 = NOVALUE;
    DeRef(_14728);
    _14728 = NOVALUE;
    DeRef(_14849);
    _14849 = NOVALUE;
    DeRef(_14885);
    _14885 = NOVALUE;
    _14691 = NOVALUE;
    DeRef(_14745);
    _14745 = NOVALUE;
    DeRef(_14755);
    _14755 = NOVALUE;
    DeRef(_14868);
    _14868 = NOVALUE;
    DeRef(_14795);
    _14795 = NOVALUE;
    DeRef(_14858);
    _14858 = NOVALUE;
    DeRef(_14575);
    _14575 = NOVALUE;
    DeRef(_14726);
    _14726 = NOVALUE;
    DeRef(_14863);
    _14863 = NOVALUE;
    DeRef(_14622);
    _14622 = NOVALUE;
    DeRef(_14591);
    _14591 = NOVALUE;
    DeRef(_14672);
    _14672 = NOVALUE;
    DeRef(_14767);
    _14767 = NOVALUE;
    DeRef(_14867);
    _14867 = NOVALUE;
    _14738 = NOVALUE;
    DeRef(_14559);
    _14559 = NOVALUE;
    DeRef(_14596);
    _14596 = NOVALUE;
    _14638 = NOVALUE;
    DeRef(_14550);
    _14550 = NOVALUE;
    _14601 = NOVALUE;
    _14712 = NOVALUE;
    DeRef(_14757);
    _14757 = NOVALUE;
    _14681 = NOVALUE;
    DeRef(_14772);
    _14772 = NOVALUE;
    _14810 = NOVALUE;
    DeRef(_14823);
    _14823 = NOVALUE;
    DeRef(_14545);
    _14545 = NOVALUE;
    DeRef(_14568);
    _14568 = NOVALUE;
    DeRef(_14571);
    _14571 = NOVALUE;
    DeRef(_14861);
    _14861 = NOVALUE;
    _14612 = NOVALUE;
    _14734 = NOVALUE;
    DeRef(_14774);
    _14774 = NOVALUE;
    DeRef(_14799);
    _14799 = NOVALUE;
    DeRef(_14816);
    _14816 = NOVALUE;
    _14836 = NOVALUE;
    DeRef(_14720);
    _14720 = NOVALUE;
    DeRef(_14804);
    _14804 = NOVALUE;
    DeRef(_14667);
    _14667 = NOVALUE;
    DeRef(_14791);
    _14791 = NOVALUE;
    DeRef(_14805);
    _14805 = NOVALUE;
    DeRef(_14678);
    _14678 = NOVALUE;
    DeRef(_14562);
    _14562 = NOVALUE;
    _14623 = NOVALUE;
    DeRef(_14671);
    _14671 = NOVALUE;
    DeRef(_14842);
    _14842 = NOVALUE;
    DeRef(_14565);
    _14565 = NOVALUE;
    DeRef(_14743);
    _14743 = NOVALUE;
    DeRef(_14693);
    _14693 = NOVALUE;
    return _14900;
    goto L96; // [3490] 3510
L95: 

    /** 				return {ATOM, NewDoubleSym(ach)}*/
    Ref(_ach_26286);
    _14901 = _53NewDoubleSym(_ach_26286);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 502;
    ((int *)_2)[2] = _14901;
    _14902 = MAKE_SEQ(_1);
    _14901 = NOVALUE;
    DeRef(_ach_26286);
    DeRef(_yytext_25602);
    DeRef(_namespaces_25603);
    DeRef(_d_25604);
    DeRef(_tok_25606);
    DeRef(_name_25609);
    DeRef(_14872);
    _14872 = NOVALUE;
    _14716 = NOVALUE;
    DeRef(_14781);
    _14781 = NOVALUE;
    DeRef(_14765);
    _14765 = NOVALUE;
    DeRef(_14800);
    _14800 = NOVALUE;
    DeRef(_14572);
    _14572 = NOVALUE;
    _14587 = NOVALUE;
    DeRef(_14780);
    _14780 = NOVALUE;
    DeRef(_14728);
    _14728 = NOVALUE;
    DeRef(_14849);
    _14849 = NOVALUE;
    DeRef(_14885);
    _14885 = NOVALUE;
    _14691 = NOVALUE;
    DeRef(_14745);
    _14745 = NOVALUE;
    DeRef(_14755);
    _14755 = NOVALUE;
    DeRef(_14868);
    _14868 = NOVALUE;
    DeRef(_14795);
    _14795 = NOVALUE;
    DeRef(_14858);
    _14858 = NOVALUE;
    DeRef(_14575);
    _14575 = NOVALUE;
    DeRef(_14726);
    _14726 = NOVALUE;
    DeRef(_14863);
    _14863 = NOVALUE;
    DeRef(_14622);
    _14622 = NOVALUE;
    DeRef(_14591);
    _14591 = NOVALUE;
    DeRef(_14672);
    _14672 = NOVALUE;
    DeRef(_14767);
    _14767 = NOVALUE;
    DeRef(_14867);
    _14867 = NOVALUE;
    _14738 = NOVALUE;
    DeRef(_14559);
    _14559 = NOVALUE;
    DeRef(_14596);
    _14596 = NOVALUE;
    _14638 = NOVALUE;
    DeRef(_14550);
    _14550 = NOVALUE;
    _14601 = NOVALUE;
    _14712 = NOVALUE;
    DeRef(_14757);
    _14757 = NOVALUE;
    _14681 = NOVALUE;
    DeRef(_14772);
    _14772 = NOVALUE;
    _14810 = NOVALUE;
    DeRef(_14823);
    _14823 = NOVALUE;
    DeRef(_14545);
    _14545 = NOVALUE;
    DeRef(_14568);
    _14568 = NOVALUE;
    DeRef(_14571);
    _14571 = NOVALUE;
    DeRef(_14861);
    _14861 = NOVALUE;
    _14612 = NOVALUE;
    _14734 = NOVALUE;
    DeRef(_14774);
    _14774 = NOVALUE;
    DeRef(_14799);
    _14799 = NOVALUE;
    DeRef(_14816);
    _14816 = NOVALUE;
    _14836 = NOVALUE;
    DeRef(_14720);
    _14720 = NOVALUE;
    DeRef(_14804);
    _14804 = NOVALUE;
    DeRef(_14900);
    _14900 = NOVALUE;
    DeRef(_14667);
    _14667 = NOVALUE;
    DeRef(_14791);
    _14791 = NOVALUE;
    DeRef(_14805);
    _14805 = NOVALUE;
    DeRef(_14678);
    _14678 = NOVALUE;
    DeRef(_14562);
    _14562 = NOVALUE;
    _14623 = NOVALUE;
    DeRef(_14671);
    _14671 = NOVALUE;
    DeRef(_14842);
    _14842 = NOVALUE;
    DeRef(_14565);
    _14565 = NOVALUE;
    DeRef(_14743);
    _14743 = NOVALUE;
    DeRef(_14693);
    _14693 = NOVALUE;
    return _14902;
L96: 
    DeRef(_ach_26286);
    _ach_26286 = NOVALUE;
    goto L1; // [3512] 10
L8E: 

    /** 		elsif class = LESS then*/
    if (_class_25608 != 1)
    goto L97; // [3519] 3567

    /** 			if getch() = '=' then*/
    _14904 = _61getch();
    if (binary_op_a(NOTEQ, _14904, 61)){
        DeRef(_14904);
        _14904 = NOVALUE;
        goto L98; // [3528] 3547
    }
    DeRef(_14904);
    _14904 = NOVALUE;

    /** 				return {LESSEQ, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 5;
    ((int *)_2)[2] = 0;
    _14906 = MAKE_SEQ(_1);
    DeRef(_yytext_25602);
    DeRef(_namespaces_25603);
    DeRef(_d_25604);
    DeRef(_tok_25606);
    DeRef(_name_25609);
    DeRef(_14872);
    _14872 = NOVALUE;
    _14716 = NOVALUE;
    DeRef(_14781);
    _14781 = NOVALUE;
    DeRef(_14765);
    _14765 = NOVALUE;
    DeRef(_14800);
    _14800 = NOVALUE;
    DeRef(_14572);
    _14572 = NOVALUE;
    _14587 = NOVALUE;
    DeRef(_14780);
    _14780 = NOVALUE;
    DeRef(_14728);
    _14728 = NOVALUE;
    DeRef(_14849);
    _14849 = NOVALUE;
    DeRef(_14885);
    _14885 = NOVALUE;
    _14691 = NOVALUE;
    DeRef(_14745);
    _14745 = NOVALUE;
    DeRef(_14755);
    _14755 = NOVALUE;
    DeRef(_14868);
    _14868 = NOVALUE;
    DeRef(_14795);
    _14795 = NOVALUE;
    DeRef(_14858);
    _14858 = NOVALUE;
    DeRef(_14575);
    _14575 = NOVALUE;
    DeRef(_14726);
    _14726 = NOVALUE;
    DeRef(_14863);
    _14863 = NOVALUE;
    DeRef(_14622);
    _14622 = NOVALUE;
    DeRef(_14902);
    _14902 = NOVALUE;
    DeRef(_14591);
    _14591 = NOVALUE;
    DeRef(_14672);
    _14672 = NOVALUE;
    DeRef(_14767);
    _14767 = NOVALUE;
    DeRef(_14867);
    _14867 = NOVALUE;
    _14738 = NOVALUE;
    DeRef(_14559);
    _14559 = NOVALUE;
    DeRef(_14596);
    _14596 = NOVALUE;
    _14638 = NOVALUE;
    DeRef(_14550);
    _14550 = NOVALUE;
    _14601 = NOVALUE;
    _14712 = NOVALUE;
    DeRef(_14757);
    _14757 = NOVALUE;
    _14681 = NOVALUE;
    DeRef(_14772);
    _14772 = NOVALUE;
    _14810 = NOVALUE;
    DeRef(_14823);
    _14823 = NOVALUE;
    DeRef(_14545);
    _14545 = NOVALUE;
    DeRef(_14568);
    _14568 = NOVALUE;
    DeRef(_14571);
    _14571 = NOVALUE;
    DeRef(_14861);
    _14861 = NOVALUE;
    _14612 = NOVALUE;
    _14734 = NOVALUE;
    DeRef(_14774);
    _14774 = NOVALUE;
    DeRef(_14799);
    _14799 = NOVALUE;
    DeRef(_14816);
    _14816 = NOVALUE;
    _14836 = NOVALUE;
    DeRef(_14720);
    _14720 = NOVALUE;
    DeRef(_14804);
    _14804 = NOVALUE;
    DeRef(_14900);
    _14900 = NOVALUE;
    DeRef(_14667);
    _14667 = NOVALUE;
    DeRef(_14791);
    _14791 = NOVALUE;
    DeRef(_14805);
    _14805 = NOVALUE;
    DeRef(_14678);
    _14678 = NOVALUE;
    DeRef(_14562);
    _14562 = NOVALUE;
    _14623 = NOVALUE;
    DeRef(_14671);
    _14671 = NOVALUE;
    DeRef(_14842);
    _14842 = NOVALUE;
    DeRef(_14565);
    _14565 = NOVALUE;
    DeRef(_14743);
    _14743 = NOVALUE;
    DeRef(_14693);
    _14693 = NOVALUE;
    return _14906;
    goto L1; // [3544] 10
L98: 

    /** 				ungetch()*/
    _61ungetch();

    /** 				return {LESS, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = 0;
    _14907 = MAKE_SEQ(_1);
    DeRef(_yytext_25602);
    DeRef(_namespaces_25603);
    DeRef(_d_25604);
    DeRef(_tok_25606);
    DeRef(_name_25609);
    DeRef(_14872);
    _14872 = NOVALUE;
    _14716 = NOVALUE;
    DeRef(_14781);
    _14781 = NOVALUE;
    DeRef(_14765);
    _14765 = NOVALUE;
    DeRef(_14800);
    _14800 = NOVALUE;
    DeRef(_14572);
    _14572 = NOVALUE;
    _14587 = NOVALUE;
    DeRef(_14780);
    _14780 = NOVALUE;
    DeRef(_14728);
    _14728 = NOVALUE;
    DeRef(_14849);
    _14849 = NOVALUE;
    DeRef(_14885);
    _14885 = NOVALUE;
    _14691 = NOVALUE;
    DeRef(_14745);
    _14745 = NOVALUE;
    DeRef(_14755);
    _14755 = NOVALUE;
    DeRef(_14868);
    _14868 = NOVALUE;
    DeRef(_14795);
    _14795 = NOVALUE;
    DeRef(_14858);
    _14858 = NOVALUE;
    DeRef(_14575);
    _14575 = NOVALUE;
    DeRef(_14726);
    _14726 = NOVALUE;
    DeRef(_14863);
    _14863 = NOVALUE;
    DeRef(_14622);
    _14622 = NOVALUE;
    DeRef(_14902);
    _14902 = NOVALUE;
    DeRef(_14591);
    _14591 = NOVALUE;
    DeRef(_14672);
    _14672 = NOVALUE;
    DeRef(_14767);
    _14767 = NOVALUE;
    DeRef(_14867);
    _14867 = NOVALUE;
    _14738 = NOVALUE;
    DeRef(_14559);
    _14559 = NOVALUE;
    DeRef(_14596);
    _14596 = NOVALUE;
    _14638 = NOVALUE;
    DeRef(_14550);
    _14550 = NOVALUE;
    _14601 = NOVALUE;
    _14712 = NOVALUE;
    DeRef(_14757);
    _14757 = NOVALUE;
    _14681 = NOVALUE;
    DeRef(_14772);
    _14772 = NOVALUE;
    _14810 = NOVALUE;
    DeRef(_14823);
    _14823 = NOVALUE;
    DeRef(_14545);
    _14545 = NOVALUE;
    DeRef(_14568);
    _14568 = NOVALUE;
    DeRef(_14571);
    _14571 = NOVALUE;
    DeRef(_14861);
    _14861 = NOVALUE;
    _14612 = NOVALUE;
    _14734 = NOVALUE;
    DeRef(_14774);
    _14774 = NOVALUE;
    DeRef(_14799);
    _14799 = NOVALUE;
    DeRef(_14816);
    _14816 = NOVALUE;
    _14836 = NOVALUE;
    DeRef(_14720);
    _14720 = NOVALUE;
    DeRef(_14804);
    _14804 = NOVALUE;
    DeRef(_14900);
    _14900 = NOVALUE;
    DeRef(_14667);
    _14667 = NOVALUE;
    DeRef(_14791);
    _14791 = NOVALUE;
    DeRef(_14805);
    _14805 = NOVALUE;
    DeRef(_14678);
    _14678 = NOVALUE;
    DeRef(_14562);
    _14562 = NOVALUE;
    _14623 = NOVALUE;
    DeRef(_14671);
    _14671 = NOVALUE;
    DeRef(_14842);
    _14842 = NOVALUE;
    DeRef(_14565);
    _14565 = NOVALUE;
    DeRef(_14743);
    _14743 = NOVALUE;
    DeRef(_14906);
    _14906 = NOVALUE;
    DeRef(_14693);
    _14693 = NOVALUE;
    return _14907;
    goto L1; // [3564] 10
L97: 

    /** 		elsif class = GREATER then*/
    if (_class_25608 != 6)
    goto L99; // [3571] 3619

    /** 			if getch() = '=' then*/
    _14909 = _61getch();
    if (binary_op_a(NOTEQ, _14909, 61)){
        DeRef(_14909);
        _14909 = NOVALUE;
        goto L9A; // [3580] 3599
    }
    DeRef(_14909);
    _14909 = NOVALUE;

    /** 				return {GREATEREQ, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 2;
    ((int *)_2)[2] = 0;
    _14911 = MAKE_SEQ(_1);
    DeRef(_yytext_25602);
    DeRef(_namespaces_25603);
    DeRef(_d_25604);
    DeRef(_tok_25606);
    DeRef(_name_25609);
    DeRef(_14872);
    _14872 = NOVALUE;
    _14716 = NOVALUE;
    DeRef(_14781);
    _14781 = NOVALUE;
    DeRef(_14765);
    _14765 = NOVALUE;
    DeRef(_14800);
    _14800 = NOVALUE;
    DeRef(_14907);
    _14907 = NOVALUE;
    DeRef(_14572);
    _14572 = NOVALUE;
    _14587 = NOVALUE;
    DeRef(_14780);
    _14780 = NOVALUE;
    DeRef(_14728);
    _14728 = NOVALUE;
    DeRef(_14849);
    _14849 = NOVALUE;
    DeRef(_14885);
    _14885 = NOVALUE;
    _14691 = NOVALUE;
    DeRef(_14745);
    _14745 = NOVALUE;
    DeRef(_14755);
    _14755 = NOVALUE;
    DeRef(_14868);
    _14868 = NOVALUE;
    DeRef(_14795);
    _14795 = NOVALUE;
    DeRef(_14858);
    _14858 = NOVALUE;
    DeRef(_14575);
    _14575 = NOVALUE;
    DeRef(_14726);
    _14726 = NOVALUE;
    DeRef(_14863);
    _14863 = NOVALUE;
    DeRef(_14622);
    _14622 = NOVALUE;
    DeRef(_14902);
    _14902 = NOVALUE;
    DeRef(_14591);
    _14591 = NOVALUE;
    DeRef(_14672);
    _14672 = NOVALUE;
    DeRef(_14767);
    _14767 = NOVALUE;
    DeRef(_14867);
    _14867 = NOVALUE;
    _14738 = NOVALUE;
    DeRef(_14559);
    _14559 = NOVALUE;
    DeRef(_14596);
    _14596 = NOVALUE;
    _14638 = NOVALUE;
    DeRef(_14550);
    _14550 = NOVALUE;
    _14601 = NOVALUE;
    _14712 = NOVALUE;
    DeRef(_14757);
    _14757 = NOVALUE;
    _14681 = NOVALUE;
    DeRef(_14772);
    _14772 = NOVALUE;
    _14810 = NOVALUE;
    DeRef(_14823);
    _14823 = NOVALUE;
    DeRef(_14545);
    _14545 = NOVALUE;
    DeRef(_14568);
    _14568 = NOVALUE;
    DeRef(_14571);
    _14571 = NOVALUE;
    DeRef(_14861);
    _14861 = NOVALUE;
    _14612 = NOVALUE;
    _14734 = NOVALUE;
    DeRef(_14774);
    _14774 = NOVALUE;
    DeRef(_14799);
    _14799 = NOVALUE;
    DeRef(_14816);
    _14816 = NOVALUE;
    _14836 = NOVALUE;
    DeRef(_14720);
    _14720 = NOVALUE;
    DeRef(_14804);
    _14804 = NOVALUE;
    DeRef(_14900);
    _14900 = NOVALUE;
    DeRef(_14667);
    _14667 = NOVALUE;
    DeRef(_14791);
    _14791 = NOVALUE;
    DeRef(_14805);
    _14805 = NOVALUE;
    DeRef(_14678);
    _14678 = NOVALUE;
    DeRef(_14562);
    _14562 = NOVALUE;
    _14623 = NOVALUE;
    DeRef(_14671);
    _14671 = NOVALUE;
    DeRef(_14842);
    _14842 = NOVALUE;
    DeRef(_14565);
    _14565 = NOVALUE;
    DeRef(_14743);
    _14743 = NOVALUE;
    DeRef(_14906);
    _14906 = NOVALUE;
    DeRef(_14693);
    _14693 = NOVALUE;
    return _14911;
    goto L1; // [3596] 10
L9A: 

    /** 				ungetch()*/
    _61ungetch();

    /** 				return {GREATER, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 6;
    ((int *)_2)[2] = 0;
    _14912 = MAKE_SEQ(_1);
    DeRef(_yytext_25602);
    DeRef(_namespaces_25603);
    DeRef(_d_25604);
    DeRef(_tok_25606);
    DeRef(_name_25609);
    DeRef(_14872);
    _14872 = NOVALUE;
    _14716 = NOVALUE;
    DeRef(_14781);
    _14781 = NOVALUE;
    DeRef(_14765);
    _14765 = NOVALUE;
    DeRef(_14800);
    _14800 = NOVALUE;
    DeRef(_14907);
    _14907 = NOVALUE;
    DeRef(_14572);
    _14572 = NOVALUE;
    _14587 = NOVALUE;
    DeRef(_14780);
    _14780 = NOVALUE;
    DeRef(_14728);
    _14728 = NOVALUE;
    DeRef(_14849);
    _14849 = NOVALUE;
    DeRef(_14885);
    _14885 = NOVALUE;
    _14691 = NOVALUE;
    DeRef(_14745);
    _14745 = NOVALUE;
    DeRef(_14755);
    _14755 = NOVALUE;
    DeRef(_14868);
    _14868 = NOVALUE;
    DeRef(_14795);
    _14795 = NOVALUE;
    DeRef(_14858);
    _14858 = NOVALUE;
    DeRef(_14575);
    _14575 = NOVALUE;
    DeRef(_14726);
    _14726 = NOVALUE;
    DeRef(_14863);
    _14863 = NOVALUE;
    DeRef(_14622);
    _14622 = NOVALUE;
    DeRef(_14902);
    _14902 = NOVALUE;
    DeRef(_14591);
    _14591 = NOVALUE;
    DeRef(_14672);
    _14672 = NOVALUE;
    DeRef(_14767);
    _14767 = NOVALUE;
    DeRef(_14867);
    _14867 = NOVALUE;
    _14738 = NOVALUE;
    DeRef(_14559);
    _14559 = NOVALUE;
    DeRef(_14596);
    _14596 = NOVALUE;
    _14638 = NOVALUE;
    DeRef(_14550);
    _14550 = NOVALUE;
    _14601 = NOVALUE;
    _14712 = NOVALUE;
    DeRef(_14757);
    _14757 = NOVALUE;
    _14681 = NOVALUE;
    DeRef(_14772);
    _14772 = NOVALUE;
    _14810 = NOVALUE;
    DeRef(_14823);
    _14823 = NOVALUE;
    DeRef(_14545);
    _14545 = NOVALUE;
    DeRef(_14568);
    _14568 = NOVALUE;
    DeRef(_14571);
    _14571 = NOVALUE;
    DeRef(_14861);
    _14861 = NOVALUE;
    _14612 = NOVALUE;
    _14734 = NOVALUE;
    DeRef(_14774);
    _14774 = NOVALUE;
    DeRef(_14799);
    _14799 = NOVALUE;
    DeRef(_14816);
    _14816 = NOVALUE;
    _14836 = NOVALUE;
    DeRef(_14720);
    _14720 = NOVALUE;
    DeRef(_14804);
    _14804 = NOVALUE;
    DeRef(_14900);
    _14900 = NOVALUE;
    DeRef(_14911);
    _14911 = NOVALUE;
    DeRef(_14667);
    _14667 = NOVALUE;
    DeRef(_14791);
    _14791 = NOVALUE;
    DeRef(_14805);
    _14805 = NOVALUE;
    DeRef(_14678);
    _14678 = NOVALUE;
    DeRef(_14562);
    _14562 = NOVALUE;
    _14623 = NOVALUE;
    DeRef(_14671);
    _14671 = NOVALUE;
    DeRef(_14842);
    _14842 = NOVALUE;
    DeRef(_14565);
    _14565 = NOVALUE;
    DeRef(_14743);
    _14743 = NOVALUE;
    DeRef(_14906);
    _14906 = NOVALUE;
    DeRef(_14693);
    _14693 = NOVALUE;
    return _14912;
    goto L1; // [3616] 10
L99: 

    /** 		elsif class = BANG then*/
    if (_class_25608 != -1)
    goto L9B; // [3623] 3671

    /** 			if getch() = '=' then*/
    _14914 = _61getch();
    if (binary_op_a(NOTEQ, _14914, 61)){
        DeRef(_14914);
        _14914 = NOVALUE;
        goto L9C; // [3632] 3651
    }
    DeRef(_14914);
    _14914 = NOVALUE;

    /** 				return {NOTEQ, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 4;
    ((int *)_2)[2] = 0;
    _14916 = MAKE_SEQ(_1);
    DeRef(_yytext_25602);
    DeRef(_namespaces_25603);
    DeRef(_d_25604);
    DeRef(_tok_25606);
    DeRef(_name_25609);
    DeRef(_14872);
    _14872 = NOVALUE;
    _14716 = NOVALUE;
    DeRef(_14781);
    _14781 = NOVALUE;
    DeRef(_14765);
    _14765 = NOVALUE;
    DeRef(_14800);
    _14800 = NOVALUE;
    DeRef(_14907);
    _14907 = NOVALUE;
    DeRef(_14572);
    _14572 = NOVALUE;
    _14587 = NOVALUE;
    DeRef(_14780);
    _14780 = NOVALUE;
    DeRef(_14728);
    _14728 = NOVALUE;
    DeRef(_14849);
    _14849 = NOVALUE;
    DeRef(_14885);
    _14885 = NOVALUE;
    _14691 = NOVALUE;
    DeRef(_14745);
    _14745 = NOVALUE;
    DeRef(_14755);
    _14755 = NOVALUE;
    DeRef(_14868);
    _14868 = NOVALUE;
    DeRef(_14795);
    _14795 = NOVALUE;
    DeRef(_14858);
    _14858 = NOVALUE;
    DeRef(_14575);
    _14575 = NOVALUE;
    DeRef(_14726);
    _14726 = NOVALUE;
    DeRef(_14863);
    _14863 = NOVALUE;
    DeRef(_14622);
    _14622 = NOVALUE;
    DeRef(_14902);
    _14902 = NOVALUE;
    DeRef(_14591);
    _14591 = NOVALUE;
    DeRef(_14672);
    _14672 = NOVALUE;
    DeRef(_14767);
    _14767 = NOVALUE;
    DeRef(_14867);
    _14867 = NOVALUE;
    _14738 = NOVALUE;
    DeRef(_14559);
    _14559 = NOVALUE;
    DeRef(_14596);
    _14596 = NOVALUE;
    _14638 = NOVALUE;
    DeRef(_14912);
    _14912 = NOVALUE;
    DeRef(_14550);
    _14550 = NOVALUE;
    _14601 = NOVALUE;
    _14712 = NOVALUE;
    DeRef(_14757);
    _14757 = NOVALUE;
    _14681 = NOVALUE;
    DeRef(_14772);
    _14772 = NOVALUE;
    _14810 = NOVALUE;
    DeRef(_14823);
    _14823 = NOVALUE;
    DeRef(_14545);
    _14545 = NOVALUE;
    DeRef(_14568);
    _14568 = NOVALUE;
    DeRef(_14571);
    _14571 = NOVALUE;
    DeRef(_14861);
    _14861 = NOVALUE;
    _14612 = NOVALUE;
    _14734 = NOVALUE;
    DeRef(_14774);
    _14774 = NOVALUE;
    DeRef(_14799);
    _14799 = NOVALUE;
    DeRef(_14816);
    _14816 = NOVALUE;
    _14836 = NOVALUE;
    DeRef(_14720);
    _14720 = NOVALUE;
    DeRef(_14804);
    _14804 = NOVALUE;
    DeRef(_14900);
    _14900 = NOVALUE;
    DeRef(_14911);
    _14911 = NOVALUE;
    DeRef(_14667);
    _14667 = NOVALUE;
    DeRef(_14791);
    _14791 = NOVALUE;
    DeRef(_14805);
    _14805 = NOVALUE;
    DeRef(_14678);
    _14678 = NOVALUE;
    DeRef(_14562);
    _14562 = NOVALUE;
    _14623 = NOVALUE;
    DeRef(_14671);
    _14671 = NOVALUE;
    DeRef(_14842);
    _14842 = NOVALUE;
    DeRef(_14565);
    _14565 = NOVALUE;
    DeRef(_14743);
    _14743 = NOVALUE;
    DeRef(_14906);
    _14906 = NOVALUE;
    DeRef(_14693);
    _14693 = NOVALUE;
    return _14916;
    goto L1; // [3648] 10
L9C: 

    /** 				ungetch()*/
    _61ungetch();

    /** 				return {BANG, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -1;
    ((int *)_2)[2] = 0;
    _14917 = MAKE_SEQ(_1);
    DeRef(_yytext_25602);
    DeRef(_namespaces_25603);
    DeRef(_d_25604);
    DeRef(_tok_25606);
    DeRef(_name_25609);
    DeRef(_14872);
    _14872 = NOVALUE;
    _14716 = NOVALUE;
    DeRef(_14781);
    _14781 = NOVALUE;
    DeRef(_14765);
    _14765 = NOVALUE;
    DeRef(_14800);
    _14800 = NOVALUE;
    DeRef(_14907);
    _14907 = NOVALUE;
    DeRef(_14572);
    _14572 = NOVALUE;
    _14587 = NOVALUE;
    DeRef(_14780);
    _14780 = NOVALUE;
    DeRef(_14728);
    _14728 = NOVALUE;
    DeRef(_14849);
    _14849 = NOVALUE;
    DeRef(_14885);
    _14885 = NOVALUE;
    _14691 = NOVALUE;
    DeRef(_14745);
    _14745 = NOVALUE;
    DeRef(_14755);
    _14755 = NOVALUE;
    DeRef(_14868);
    _14868 = NOVALUE;
    DeRef(_14795);
    _14795 = NOVALUE;
    DeRef(_14858);
    _14858 = NOVALUE;
    DeRef(_14575);
    _14575 = NOVALUE;
    DeRef(_14726);
    _14726 = NOVALUE;
    DeRef(_14863);
    _14863 = NOVALUE;
    DeRef(_14622);
    _14622 = NOVALUE;
    DeRef(_14902);
    _14902 = NOVALUE;
    DeRef(_14591);
    _14591 = NOVALUE;
    DeRef(_14672);
    _14672 = NOVALUE;
    DeRef(_14767);
    _14767 = NOVALUE;
    DeRef(_14867);
    _14867 = NOVALUE;
    _14738 = NOVALUE;
    DeRef(_14559);
    _14559 = NOVALUE;
    DeRef(_14596);
    _14596 = NOVALUE;
    _14638 = NOVALUE;
    DeRef(_14912);
    _14912 = NOVALUE;
    DeRef(_14550);
    _14550 = NOVALUE;
    _14601 = NOVALUE;
    _14712 = NOVALUE;
    DeRef(_14757);
    _14757 = NOVALUE;
    _14681 = NOVALUE;
    DeRef(_14772);
    _14772 = NOVALUE;
    _14810 = NOVALUE;
    DeRef(_14823);
    _14823 = NOVALUE;
    DeRef(_14545);
    _14545 = NOVALUE;
    DeRef(_14568);
    _14568 = NOVALUE;
    DeRef(_14571);
    _14571 = NOVALUE;
    DeRef(_14861);
    _14861 = NOVALUE;
    DeRef(_14916);
    _14916 = NOVALUE;
    _14612 = NOVALUE;
    _14734 = NOVALUE;
    DeRef(_14774);
    _14774 = NOVALUE;
    DeRef(_14799);
    _14799 = NOVALUE;
    DeRef(_14816);
    _14816 = NOVALUE;
    _14836 = NOVALUE;
    DeRef(_14720);
    _14720 = NOVALUE;
    DeRef(_14804);
    _14804 = NOVALUE;
    DeRef(_14900);
    _14900 = NOVALUE;
    DeRef(_14911);
    _14911 = NOVALUE;
    DeRef(_14667);
    _14667 = NOVALUE;
    DeRef(_14791);
    _14791 = NOVALUE;
    DeRef(_14805);
    _14805 = NOVALUE;
    DeRef(_14678);
    _14678 = NOVALUE;
    DeRef(_14562);
    _14562 = NOVALUE;
    _14623 = NOVALUE;
    DeRef(_14671);
    _14671 = NOVALUE;
    DeRef(_14842);
    _14842 = NOVALUE;
    DeRef(_14565);
    _14565 = NOVALUE;
    DeRef(_14743);
    _14743 = NOVALUE;
    DeRef(_14906);
    _14906 = NOVALUE;
    DeRef(_14693);
    _14693 = NOVALUE;
    return _14917;
    goto L1; // [3668] 10
L9B: 

    /** 		elsif class = KEYWORD then*/
    if (_class_25608 != -10)
    goto L9D; // [3675] 3708

    /** 			return {keylist[ch - KEYWORD_BASE][K_TOKEN], 0}*/
    _14919 = _ch_25596 - 128;
    _2 = (int)SEQ_PTR(_63keylist_22829);
    _14920 = (int)*(((s1_ptr)_2)->base + _14919);
    _2 = (int)SEQ_PTR(_14920);
    _14921 = (int)*(((s1_ptr)_2)->base + 3);
    _14920 = NOVALUE;
    Ref(_14921);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _14921;
    ((int *)_2)[2] = 0;
    _14922 = MAKE_SEQ(_1);
    _14921 = NOVALUE;
    DeRef(_yytext_25602);
    DeRef(_namespaces_25603);
    DeRef(_d_25604);
    DeRef(_tok_25606);
    DeRef(_name_25609);
    DeRef(_14872);
    _14872 = NOVALUE;
    _14919 = NOVALUE;
    _14716 = NOVALUE;
    DeRef(_14781);
    _14781 = NOVALUE;
    DeRef(_14765);
    _14765 = NOVALUE;
    DeRef(_14800);
    _14800 = NOVALUE;
    DeRef(_14907);
    _14907 = NOVALUE;
    DeRef(_14572);
    _14572 = NOVALUE;
    _14587 = NOVALUE;
    DeRef(_14780);
    _14780 = NOVALUE;
    DeRef(_14728);
    _14728 = NOVALUE;
    DeRef(_14849);
    _14849 = NOVALUE;
    DeRef(_14885);
    _14885 = NOVALUE;
    _14691 = NOVALUE;
    DeRef(_14745);
    _14745 = NOVALUE;
    DeRef(_14755);
    _14755 = NOVALUE;
    DeRef(_14868);
    _14868 = NOVALUE;
    DeRef(_14795);
    _14795 = NOVALUE;
    DeRef(_14858);
    _14858 = NOVALUE;
    DeRef(_14575);
    _14575 = NOVALUE;
    DeRef(_14726);
    _14726 = NOVALUE;
    DeRef(_14863);
    _14863 = NOVALUE;
    DeRef(_14622);
    _14622 = NOVALUE;
    DeRef(_14902);
    _14902 = NOVALUE;
    DeRef(_14591);
    _14591 = NOVALUE;
    DeRef(_14672);
    _14672 = NOVALUE;
    DeRef(_14767);
    _14767 = NOVALUE;
    DeRef(_14867);
    _14867 = NOVALUE;
    _14738 = NOVALUE;
    DeRef(_14559);
    _14559 = NOVALUE;
    DeRef(_14596);
    _14596 = NOVALUE;
    _14638 = NOVALUE;
    DeRef(_14912);
    _14912 = NOVALUE;
    DeRef(_14550);
    _14550 = NOVALUE;
    _14601 = NOVALUE;
    _14712 = NOVALUE;
    DeRef(_14757);
    _14757 = NOVALUE;
    _14681 = NOVALUE;
    DeRef(_14772);
    _14772 = NOVALUE;
    _14810 = NOVALUE;
    DeRef(_14823);
    _14823 = NOVALUE;
    DeRef(_14545);
    _14545 = NOVALUE;
    DeRef(_14568);
    _14568 = NOVALUE;
    DeRef(_14571);
    _14571 = NOVALUE;
    DeRef(_14861);
    _14861 = NOVALUE;
    DeRef(_14916);
    _14916 = NOVALUE;
    _14612 = NOVALUE;
    _14734 = NOVALUE;
    DeRef(_14774);
    _14774 = NOVALUE;
    DeRef(_14799);
    _14799 = NOVALUE;
    DeRef(_14816);
    _14816 = NOVALUE;
    _14836 = NOVALUE;
    DeRef(_14720);
    _14720 = NOVALUE;
    DeRef(_14804);
    _14804 = NOVALUE;
    DeRef(_14900);
    _14900 = NOVALUE;
    DeRef(_14911);
    _14911 = NOVALUE;
    DeRef(_14667);
    _14667 = NOVALUE;
    DeRef(_14791);
    _14791 = NOVALUE;
    DeRef(_14805);
    _14805 = NOVALUE;
    DeRef(_14678);
    _14678 = NOVALUE;
    DeRef(_14562);
    _14562 = NOVALUE;
    _14623 = NOVALUE;
    DeRef(_14671);
    _14671 = NOVALUE;
    DeRef(_14842);
    _14842 = NOVALUE;
    DeRef(_14917);
    _14917 = NOVALUE;
    DeRef(_14565);
    _14565 = NOVALUE;
    DeRef(_14743);
    _14743 = NOVALUE;
    DeRef(_14906);
    _14906 = NOVALUE;
    DeRef(_14693);
    _14693 = NOVALUE;
    return _14922;
    goto L1; // [3705] 10
L9D: 

    /** 		elsif class = BUILTIN then*/
    if (_class_25608 != -9)
    goto L9E; // [3712] 3765

    /** 			name = keylist[ch - BUILTIN_BASE + NUM_KEYWORDS][K_NAME]*/
    _14924 = _ch_25596 - 170;
    if ((long)((unsigned long)_14924 +(unsigned long) HIGH_BITS) >= 0){
        _14924 = NewDouble((double)_14924);
    }
    if (IS_ATOM_INT(_14924)) {
        _14925 = _14924 + 24;
    }
    else {
        _14925 = NewDouble(DBL_PTR(_14924)->dbl + (double)24);
    }
    DeRef(_14924);
    _14924 = NOVALUE;
    _2 = (int)SEQ_PTR(_63keylist_22829);
    if (!IS_ATOM_INT(_14925)){
        _14926 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_14925)->dbl));
    }
    else{
        _14926 = (int)*(((s1_ptr)_2)->base + _14925);
    }
    DeRef(_name_25609);
    _2 = (int)SEQ_PTR(_14926);
    _name_25609 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_name_25609);
    _14926 = NOVALUE;

    /** 			return keyfind(name, -1)*/
    RefDS(_name_25609);
    _31673 = _53hashfn(_name_25609);
    RefDS(_name_25609);
    _14928 = _53keyfind(_name_25609, -1, _35current_file_no_16244, 0, _31673);
    _31673 = NOVALUE;
    DeRef(_yytext_25602);
    DeRef(_namespaces_25603);
    DeRef(_d_25604);
    DeRef(_tok_25606);
    DeRefDS(_name_25609);
    DeRef(_14872);
    _14872 = NOVALUE;
    DeRef(_14919);
    _14919 = NOVALUE;
    _14716 = NOVALUE;
    DeRef(_14781);
    _14781 = NOVALUE;
    DeRef(_14765);
    _14765 = NOVALUE;
    DeRef(_14800);
    _14800 = NOVALUE;
    DeRef(_14907);
    _14907 = NOVALUE;
    DeRef(_14572);
    _14572 = NOVALUE;
    _14587 = NOVALUE;
    DeRef(_14780);
    _14780 = NOVALUE;
    DeRef(_14728);
    _14728 = NOVALUE;
    DeRef(_14849);
    _14849 = NOVALUE;
    DeRef(_14885);
    _14885 = NOVALUE;
    _14691 = NOVALUE;
    DeRef(_14745);
    _14745 = NOVALUE;
    DeRef(_14755);
    _14755 = NOVALUE;
    DeRef(_14868);
    _14868 = NOVALUE;
    DeRef(_14922);
    _14922 = NOVALUE;
    DeRef(_14795);
    _14795 = NOVALUE;
    DeRef(_14858);
    _14858 = NOVALUE;
    DeRef(_14575);
    _14575 = NOVALUE;
    DeRef(_14726);
    _14726 = NOVALUE;
    DeRef(_14863);
    _14863 = NOVALUE;
    DeRef(_14622);
    _14622 = NOVALUE;
    DeRef(_14902);
    _14902 = NOVALUE;
    DeRef(_14591);
    _14591 = NOVALUE;
    DeRef(_14672);
    _14672 = NOVALUE;
    DeRef(_14767);
    _14767 = NOVALUE;
    DeRef(_14867);
    _14867 = NOVALUE;
    _14738 = NOVALUE;
    DeRef(_14559);
    _14559 = NOVALUE;
    DeRef(_14596);
    _14596 = NOVALUE;
    _14638 = NOVALUE;
    DeRef(_14912);
    _14912 = NOVALUE;
    DeRef(_14550);
    _14550 = NOVALUE;
    _14601 = NOVALUE;
    _14712 = NOVALUE;
    DeRef(_14757);
    _14757 = NOVALUE;
    _14681 = NOVALUE;
    DeRef(_14772);
    _14772 = NOVALUE;
    _14810 = NOVALUE;
    DeRef(_14823);
    _14823 = NOVALUE;
    DeRef(_14545);
    _14545 = NOVALUE;
    DeRef(_14568);
    _14568 = NOVALUE;
    DeRef(_14571);
    _14571 = NOVALUE;
    DeRef(_14861);
    _14861 = NOVALUE;
    DeRef(_14916);
    _14916 = NOVALUE;
    _14612 = NOVALUE;
    _14734 = NOVALUE;
    DeRef(_14774);
    _14774 = NOVALUE;
    DeRef(_14799);
    _14799 = NOVALUE;
    DeRef(_14816);
    _14816 = NOVALUE;
    _14836 = NOVALUE;
    DeRef(_14925);
    _14925 = NOVALUE;
    DeRef(_14720);
    _14720 = NOVALUE;
    DeRef(_14804);
    _14804 = NOVALUE;
    DeRef(_14900);
    _14900 = NOVALUE;
    DeRef(_14911);
    _14911 = NOVALUE;
    DeRef(_14667);
    _14667 = NOVALUE;
    DeRef(_14791);
    _14791 = NOVALUE;
    DeRef(_14805);
    _14805 = NOVALUE;
    DeRef(_14678);
    _14678 = NOVALUE;
    DeRef(_14562);
    _14562 = NOVALUE;
    _14623 = NOVALUE;
    DeRef(_14671);
    _14671 = NOVALUE;
    DeRef(_14842);
    _14842 = NOVALUE;
    DeRef(_14917);
    _14917 = NOVALUE;
    DeRef(_14565);
    _14565 = NOVALUE;
    DeRef(_14743);
    _14743 = NOVALUE;
    DeRef(_14906);
    _14906 = NOVALUE;
    DeRef(_14693);
    _14693 = NOVALUE;
    return _14928;
    goto L1; // [3762] 10
L9E: 

    /** 		elsif class = BACK_QUOTE then*/
    if (_class_25608 != -12)
    goto L9F; // [3769] 3786

    /** 			return ExtendedString( '`' )*/
    _14930 = _61ExtendedString(96);
    DeRef(_yytext_25602);
    DeRef(_namespaces_25603);
    DeRef(_d_25604);
    DeRef(_tok_25606);
    DeRef(_name_25609);
    DeRef(_14872);
    _14872 = NOVALUE;
    DeRef(_14919);
    _14919 = NOVALUE;
    _14716 = NOVALUE;
    DeRef(_14781);
    _14781 = NOVALUE;
    DeRef(_14765);
    _14765 = NOVALUE;
    DeRef(_14800);
    _14800 = NOVALUE;
    DeRef(_14907);
    _14907 = NOVALUE;
    DeRef(_14572);
    _14572 = NOVALUE;
    _14587 = NOVALUE;
    DeRef(_14780);
    _14780 = NOVALUE;
    DeRef(_14728);
    _14728 = NOVALUE;
    DeRef(_14849);
    _14849 = NOVALUE;
    DeRef(_14885);
    _14885 = NOVALUE;
    _14691 = NOVALUE;
    DeRef(_14745);
    _14745 = NOVALUE;
    DeRef(_14755);
    _14755 = NOVALUE;
    DeRef(_14868);
    _14868 = NOVALUE;
    DeRef(_14922);
    _14922 = NOVALUE;
    DeRef(_14795);
    _14795 = NOVALUE;
    DeRef(_14858);
    _14858 = NOVALUE;
    DeRef(_14575);
    _14575 = NOVALUE;
    DeRef(_14726);
    _14726 = NOVALUE;
    DeRef(_14863);
    _14863 = NOVALUE;
    DeRef(_14622);
    _14622 = NOVALUE;
    DeRef(_14902);
    _14902 = NOVALUE;
    DeRef(_14591);
    _14591 = NOVALUE;
    DeRef(_14672);
    _14672 = NOVALUE;
    DeRef(_14767);
    _14767 = NOVALUE;
    DeRef(_14867);
    _14867 = NOVALUE;
    _14738 = NOVALUE;
    DeRef(_14559);
    _14559 = NOVALUE;
    DeRef(_14596);
    _14596 = NOVALUE;
    _14638 = NOVALUE;
    DeRef(_14912);
    _14912 = NOVALUE;
    DeRef(_14550);
    _14550 = NOVALUE;
    _14601 = NOVALUE;
    _14712 = NOVALUE;
    DeRef(_14757);
    _14757 = NOVALUE;
    _14681 = NOVALUE;
    DeRef(_14772);
    _14772 = NOVALUE;
    DeRef(_14928);
    _14928 = NOVALUE;
    _14810 = NOVALUE;
    DeRef(_14823);
    _14823 = NOVALUE;
    DeRef(_14545);
    _14545 = NOVALUE;
    DeRef(_14568);
    _14568 = NOVALUE;
    DeRef(_14571);
    _14571 = NOVALUE;
    DeRef(_14861);
    _14861 = NOVALUE;
    DeRef(_14916);
    _14916 = NOVALUE;
    _14612 = NOVALUE;
    _14734 = NOVALUE;
    DeRef(_14774);
    _14774 = NOVALUE;
    DeRef(_14799);
    _14799 = NOVALUE;
    DeRef(_14816);
    _14816 = NOVALUE;
    _14836 = NOVALUE;
    DeRef(_14925);
    _14925 = NOVALUE;
    DeRef(_14720);
    _14720 = NOVALUE;
    DeRef(_14804);
    _14804 = NOVALUE;
    DeRef(_14900);
    _14900 = NOVALUE;
    DeRef(_14911);
    _14911 = NOVALUE;
    DeRef(_14667);
    _14667 = NOVALUE;
    DeRef(_14791);
    _14791 = NOVALUE;
    DeRef(_14805);
    _14805 = NOVALUE;
    DeRef(_14678);
    _14678 = NOVALUE;
    DeRef(_14562);
    _14562 = NOVALUE;
    _14623 = NOVALUE;
    DeRef(_14671);
    _14671 = NOVALUE;
    DeRef(_14842);
    _14842 = NOVALUE;
    DeRef(_14917);
    _14917 = NOVALUE;
    DeRef(_14565);
    _14565 = NOVALUE;
    DeRef(_14743);
    _14743 = NOVALUE;
    DeRef(_14906);
    _14906 = NOVALUE;
    DeRef(_14693);
    _14693 = NOVALUE;
    return _14930;
    goto L1; // [3783] 10
L9F: 

    /** 			InternalErr(268, {class})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _class_25608;
    _14931 = MAKE_SEQ(_1);
    _44InternalErr(268, _14931);
    _14931 = NOVALUE;

    /**    end while*/
    goto L1; // [3799] 10
L2: 
    ;
}


void _61eu_namespace()
{
    int _eu_tok_26383 = NOVALUE;
    int _eu_ns_26385 = NOVALUE;
    int _31672 = NOVALUE;
    int _31671 = NOVALUE;
    int _14940 = NOVALUE;
    int _14938 = NOVALUE;
    int _14936 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	eu_tok = keyfind("eu", -1, , 1)*/
    RefDS(_14934);
    _31671 = _14934;
    _31672 = _53hashfn(_31671);
    _31671 = NOVALUE;
    RefDS(_14934);
    _0 = _eu_tok_26383;
    _eu_tok_26383 = _53keyfind(_14934, -1, _35current_file_no_16244, 1, _31672);
    DeRef(_0);
    _31672 = NOVALUE;

    /** 	eu_ns  = NameSpace_declaration(eu_tok[T_SYM])*/
    _2 = (int)SEQ_PTR(_eu_tok_26383);
    _14936 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_14936);
    _eu_ns_26385 = _61NameSpace_declaration(_14936);
    _14936 = NOVALUE;
    if (!IS_ATOM_INT(_eu_ns_26385)) {
        _1 = (long)(DBL_PTR(_eu_ns_26385)->dbl);
        DeRefDS(_eu_ns_26385);
        _eu_ns_26385 = _1;
    }

    /** 	SymTab[eu_ns][S_OBJ] = 0*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_eu_ns_26385 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _14938 = NOVALUE;

    /** 	SymTab[eu_ns][S_SCOPE] = SC_GLOBAL*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_eu_ns_26385 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = 6;
    DeRef(_1);
    _14940 = NOVALUE;

    /** end procedure*/
    DeRef(_eu_tok_26383);
    return;
    ;
}


int _61StringToken(int _pDelims_26403)
{
    int _ch_26404 = NOVALUE;
    int _m_26405 = NOVALUE;
    int _gtext_26406 = NOVALUE;
    int _level_26437 = NOVALUE;
    int _14979 = NOVALUE;
    int _14977 = NOVALUE;
    int _14975 = NOVALUE;
    int _14956 = NOVALUE;
    int _14955 = NOVALUE;
    int _14949 = NOVALUE;
    int _14947 = NOVALUE;
    int _14945 = NOVALUE;
    int _14943 = NOVALUE;
    int _0, _1, _2;
    

    /** 	ch = getch()*/
    _ch_26404 = _61getch();
    if (!IS_ATOM_INT(_ch_26404)) {
        _1 = (long)(DBL_PTR(_ch_26404)->dbl);
        DeRefDS(_ch_26404);
        _ch_26404 = _1;
    }

    /** 	while ch = ' ' or ch = '\t' do*/
L1: 
    _14943 = (_ch_26404 == 32);
    if (_14943 != 0) {
        goto L2; // [19] 32
    }
    _14945 = (_ch_26404 == 9);
    if (_14945 == 0)
    {
        DeRef(_14945);
        _14945 = NOVALUE;
        goto L3; // [28] 44
    }
    else{
        DeRef(_14945);
        _14945 = NOVALUE;
    }
L2: 

    /** 		ch = getch()*/
    _ch_26404 = _61getch();
    if (!IS_ATOM_INT(_ch_26404)) {
        _1 = (long)(DBL_PTR(_ch_26404)->dbl);
        DeRefDS(_ch_26404);
        _ch_26404 = _1;
    }

    /** 	end while*/
    goto L1; // [41] 15
L3: 

    /** 	pDelims &= {' ', '\t', '\n', '\r', END_OF_FILE_CHAR}*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 32;
    *((int *)(_2+8)) = 9;
    *((int *)(_2+12)) = 10;
    *((int *)(_2+16)) = 13;
    *((int *)(_2+20)) = 26;
    _14947 = MAKE_SEQ(_1);
    Concat((object_ptr)&_pDelims_26403, _pDelims_26403, _14947);
    DeRefDS(_14947);
    _14947 = NOVALUE;

    /** 	gtext = ""*/
    RefDS(_5);
    DeRefi(_gtext_26406);
    _gtext_26406 = _5;

    /** 	while not find(ch,  pDelims) label "top" do*/
L4: 
    _14949 = find_from(_ch_26404, _pDelims_26403, 1);
    if (_14949 != 0)
    goto L5; // [77] 391
    _14949 = NOVALUE;

    /** 		if ch = '-' then*/
    if (_ch_26404 != 45)
    goto L6; // [82] 145

    /** 			ch = getch()*/
    _ch_26404 = _61getch();
    if (!IS_ATOM_INT(_ch_26404)) {
        _1 = (long)(DBL_PTR(_ch_26404)->dbl);
        DeRefDS(_ch_26404);
        _ch_26404 = _1;
    }

    /** 			if ch = '-' then*/
    if (_ch_26404 != 45)
    goto L7; // [95] 137

    /** 				while not find(ch, {'\n', END_OF_FILE_CHAR}) do*/
L8: 
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 10;
    ((int *)_2)[2] = 26;
    _14955 = MAKE_SEQ(_1);
    _14956 = find_from(_ch_26404, _14955, 1);
    DeRefDS(_14955);
    _14955 = NOVALUE;
    if (_14956 != 0)
    goto L5; // [115] 391
    _14956 = NOVALUE;

    /** 					ch = getch()*/
    _ch_26404 = _61getch();
    if (!IS_ATOM_INT(_ch_26404)) {
        _1 = (long)(DBL_PTR(_ch_26404)->dbl);
        DeRefDS(_ch_26404);
        _ch_26404 = _1;
    }

    /** 				end while*/
    goto L8; // [127] 104

    /** 				exit*/
    goto L5; // [132] 391
    goto L9; // [134] 373
L7: 

    /** 				ungetch()*/
    _61ungetch();
    goto L9; // [142] 373
L6: 

    /** 		elsif ch = '/' then*/
    if (_ch_26404 != 47)
    goto LA; // [147] 372

    /** 			ch = getch()*/
    _ch_26404 = _61getch();
    if (!IS_ATOM_INT(_ch_26404)) {
        _1 = (long)(DBL_PTR(_ch_26404)->dbl);
        DeRefDS(_ch_26404);
        _ch_26404 = _1;
    }

    /** 			if ch = '*' then*/
    if (_ch_26404 != 42)
    goto LB; // [160] 361

    /** 				integer level = 1*/
    _level_26437 = 1;

    /** 				while level > 0 do*/
LC: 
    if (_level_26437 <= 0)
    goto LD; // [174] 293

    /** 					ch = getch()*/
    _ch_26404 = _61getch();
    if (!IS_ATOM_INT(_ch_26404)) {
        _1 = (long)(DBL_PTR(_ch_26404)->dbl);
        DeRefDS(_ch_26404);
        _ch_26404 = _1;
    }

    /** 					if ch = '/' then*/
    if (_ch_26404 != 47)
    goto LE; // [187] 221

    /** 						ch = getch()*/
    _ch_26404 = _61getch();
    if (!IS_ATOM_INT(_ch_26404)) {
        _1 = (long)(DBL_PTR(_ch_26404)->dbl);
        DeRefDS(_ch_26404);
        _ch_26404 = _1;
    }

    /** 						if ch = '*' then*/
    if (_ch_26404 != 42)
    goto LF; // [200] 213

    /** 							level += 1*/
    _level_26437 = _level_26437 + 1;
    goto LC; // [210] 174
LF: 

    /** 							ungetch()*/
    _61ungetch();
    goto LC; // [218] 174
LE: 

    /** 					elsif ch = '*' then*/
    if (_ch_26404 != 42)
    goto L10; // [223] 257

    /** 						ch = getch()*/
    _ch_26404 = _61getch();
    if (!IS_ATOM_INT(_ch_26404)) {
        _1 = (long)(DBL_PTR(_ch_26404)->dbl);
        DeRefDS(_ch_26404);
        _ch_26404 = _1;
    }

    /** 						if ch = '/' then*/
    if (_ch_26404 != 47)
    goto L11; // [236] 249

    /** 							level -= 1*/
    _level_26437 = _level_26437 - 1;
    goto LC; // [246] 174
L11: 

    /** 							ungetch()*/
    _61ungetch();
    goto LC; // [254] 174
L10: 

    /** 					elsif ch = '\n' then*/
    if (_ch_26404 != 10)
    goto L12; // [259] 270

    /** 						read_line()*/
    _61read_line();
    goto LC; // [267] 174
L12: 

    /** 					elsif ch = END_OF_FILE_CHAR then*/
    if (_ch_26404 != 26)
    goto LC; // [274] 174

    /** 						ungetch()*/
    _61ungetch();

    /** 						exit*/
    goto LD; // [284] 293

    /** 				end while*/
    goto LC; // [290] 174
LD: 

    /** 				ch = getch()*/
    _ch_26404 = _61getch();
    if (!IS_ATOM_INT(_ch_26404)) {
        _1 = (long)(DBL_PTR(_ch_26404)->dbl);
        DeRefDS(_ch_26404);
        _ch_26404 = _1;
    }

    /** 				if length(gtext) = 0 then*/
    if (IS_SEQUENCE(_gtext_26406)){
            _14975 = SEQ_PTR(_gtext_26406)->length;
    }
    else {
        _14975 = 1;
    }
    if (_14975 != 0)
    goto L13; // [305] 350

    /** 					while ch = ' ' or ch = '\t' do*/
L14: 
    _14977 = (_ch_26404 == 32);
    if (_14977 != 0) {
        goto L15; // [318] 331
    }
    _14979 = (_ch_26404 == 9);
    if (_14979 == 0)
    {
        DeRef(_14979);
        _14979 = NOVALUE;
        goto L16; // [327] 343
    }
    else{
        DeRef(_14979);
        _14979 = NOVALUE;
    }
L15: 

    /** 						ch = getch()*/
    _ch_26404 = _61getch();
    if (!IS_ATOM_INT(_ch_26404)) {
        _1 = (long)(DBL_PTR(_ch_26404)->dbl);
        DeRefDS(_ch_26404);
        _ch_26404 = _1;
    }

    /** 					end while*/
    goto L14; // [340] 314
L16: 

    /** 					continue "top"*/
    goto L4; // [347] 72
L13: 

    /** 				exit*/
    goto L5; // [354] 391
    goto L17; // [358] 371
LB: 

    /** 				ungetch()*/
    _61ungetch();

    /** 				ch = '/'*/
    _ch_26404 = 47;
L17: 
LA: 
L9: 

    /** 		gtext &= ch*/
    Append(&_gtext_26406, _gtext_26406, _ch_26404);

    /** 		ch = getch()*/
    _ch_26404 = _61getch();
    if (!IS_ATOM_INT(_ch_26404)) {
        _1 = (long)(DBL_PTR(_ch_26404)->dbl);
        DeRefDS(_ch_26404);
        _ch_26404 = _1;
    }

    /** 	end while*/
    goto L4; // [388] 72
L5: 

    /** 	ungetch() -- put back end-word token.*/
    _61ungetch();

    /** 	return gtext*/
    DeRefDS(_pDelims_26403);
    DeRef(_14943);
    _14943 = NOVALUE;
    DeRef(_14977);
    _14977 = NOVALUE;
    return _gtext_26406;
    ;
}


void _61IncludeScan(int _is_public_26474)
{
    int _ch_26475 = NOVALUE;
    int _gtext_26476 = NOVALUE;
    int _s_26478 = NOVALUE;
    int _31670 = NOVALUE;
    int _15043 = NOVALUE;
    int _15042 = NOVALUE;
    int _15040 = NOVALUE;
    int _15038 = NOVALUE;
    int _15037 = NOVALUE;
    int _15032 = NOVALUE;
    int _15029 = NOVALUE;
    int _15027 = NOVALUE;
    int _15026 = NOVALUE;
    int _15024 = NOVALUE;
    int _15022 = NOVALUE;
    int _15020 = NOVALUE;
    int _15018 = NOVALUE;
    int _15012 = NOVALUE;
    int _15010 = NOVALUE;
    int _15004 = NOVALUE;
    int _15000 = NOVALUE;
    int _14999 = NOVALUE;
    int _14994 = NOVALUE;
    int _14991 = NOVALUE;
    int _14990 = NOVALUE;
    int _14986 = NOVALUE;
    int _14984 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_is_public_26474)) {
        _1 = (long)(DBL_PTR(_is_public_26474)->dbl);
        DeRefDS(_is_public_26474);
        _is_public_26474 = _1;
    }

    /** 	ch = getch()*/
    _ch_26475 = _61getch();
    if (!IS_ATOM_INT(_ch_26475)) {
        _1 = (long)(DBL_PTR(_ch_26475)->dbl);
        DeRefDS(_ch_26475);
        _ch_26475 = _1;
    }

    /** 	while ch = ' ' or ch = '\t' do*/
L1: 
    _14984 = (_ch_26475 == 32);
    if (_14984 != 0) {
        goto L2; // [19] 32
    }
    _14986 = (_ch_26475 == 9);
    if (_14986 == 0)
    {
        DeRef(_14986);
        _14986 = NOVALUE;
        goto L3; // [28] 44
    }
    else{
        DeRef(_14986);
        _14986 = NOVALUE;
    }
L2: 

    /** 		ch = getch()*/
    _ch_26475 = _61getch();
    if (!IS_ATOM_INT(_ch_26475)) {
        _1 = (long)(DBL_PTR(_ch_26475)->dbl);
        DeRefDS(_ch_26475);
        _ch_26475 = _1;
    }

    /** 	end while*/
    goto L1; // [41] 15
L3: 

    /** 	gtext = ""*/
    RefDS(_5);
    DeRef(_gtext_26476);
    _gtext_26476 = _5;

    /** 	if ch = '"' then*/
    if (_ch_26475 != 34)
    goto L4; // [53] 141

    /** 		ch = getch()*/
    _ch_26475 = _61getch();
    if (!IS_ATOM_INT(_ch_26475)) {
        _1 = (long)(DBL_PTR(_ch_26475)->dbl);
        DeRefDS(_ch_26475);
        _ch_26475 = _1;
    }

    /** 		while not find(ch, {'\n', '\r', '"', END_OF_FILE_CHAR}) do*/
L5: 
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 10;
    *((int *)(_2+8)) = 13;
    *((int *)(_2+12)) = 34;
    *((int *)(_2+16)) = 26;
    _14990 = MAKE_SEQ(_1);
    _14991 = find_from(_ch_26475, _14990, 1);
    DeRefDS(_14990);
    _14990 = NOVALUE;
    if (_14991 != 0)
    goto L6; // [83] 124
    _14991 = NOVALUE;

    /** 			if ch = '\\' then*/
    if (_ch_26475 != 92)
    goto L7; // [88] 105

    /** 				gtext &= EscapeChar('"')*/
    _14994 = _61EscapeChar(34);
    if (IS_SEQUENCE(_gtext_26476) && IS_ATOM(_14994)) {
        Ref(_14994);
        Append(&_gtext_26476, _gtext_26476, _14994);
    }
    else if (IS_ATOM(_gtext_26476) && IS_SEQUENCE(_14994)) {
    }
    else {
        Concat((object_ptr)&_gtext_26476, _gtext_26476, _14994);
    }
    DeRef(_14994);
    _14994 = NOVALUE;
    goto L8; // [102] 112
L7: 

    /** 				gtext &= ch*/
    Append(&_gtext_26476, _gtext_26476, _ch_26475);
L8: 

    /** 			ch = getch()*/
    _ch_26475 = _61getch();
    if (!IS_ATOM_INT(_ch_26475)) {
        _1 = (long)(DBL_PTR(_ch_26475)->dbl);
        DeRefDS(_ch_26475);
        _ch_26475 = _1;
    }

    /** 		end while*/
    goto L5; // [121] 69
L6: 

    /** 		if ch != '"' then*/
    if (_ch_26475 == 34)
    goto L9; // [126] 187

    /** 			CompileErr(115)*/
    RefDS(_22023);
    _44CompileErr(115, _22023, 0);
    goto L9; // [138] 187
L4: 

    /** 		while not find(ch, {' ', '\t', '\n', '\r', END_OF_FILE_CHAR}) do*/
LA: 
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 32;
    *((int *)(_2+8)) = 9;
    *((int *)(_2+12)) = 10;
    *((int *)(_2+16)) = 13;
    *((int *)(_2+20)) = 26;
    _14999 = MAKE_SEQ(_1);
    _15000 = find_from(_ch_26475, _14999, 1);
    DeRefDS(_14999);
    _14999 = NOVALUE;
    if (_15000 != 0)
    goto LB; // [161] 182
    _15000 = NOVALUE;

    /** 			gtext &= ch*/
    Append(&_gtext_26476, _gtext_26476, _ch_26475);

    /** 			ch = getch()*/
    _ch_26475 = _61getch();
    if (!IS_ATOM_INT(_ch_26475)) {
        _1 = (long)(DBL_PTR(_ch_26475)->dbl);
        DeRefDS(_ch_26475);
        _ch_26475 = _1;
    }

    /** 		end while*/
    goto LA; // [179] 146
LB: 

    /** 		ungetch()*/
    _61ungetch();
L9: 

    /** 	if length(gtext) = 0 then*/
    if (IS_SEQUENCE(_gtext_26476)){
            _15004 = SEQ_PTR(_gtext_26476)->length;
    }
    else {
        _15004 = 1;
    }
    if (_15004 != 0)
    goto LC; // [192] 204

    /** 		CompileErr(95)*/
    RefDS(_22023);
    _44CompileErr(95, _22023, 0);
LC: 

    /** 	ifdef WINDOWS then*/

    /** 		new_include_name = match_replace(`/`, gtext, `\`)*/
    RefDS(_15006);
    RefDS(_gtext_26476);
    RefDS(_15007);
    _0 = _16match_replace(_15006, _gtext_26476, _15007, 0);
    DeRef(_35new_include_name_16366);
    _35new_include_name_16366 = _0;

    /** 	ch = getch()*/
    _ch_26475 = _61getch();
    if (!IS_ATOM_INT(_ch_26475)) {
        _1 = (long)(DBL_PTR(_ch_26475)->dbl);
        DeRefDS(_ch_26475);
        _ch_26475 = _1;
    }

    /** 	while ch = ' ' or ch = '\t' do*/
LD: 
    _15010 = (_ch_26475 == 32);
    if (_15010 != 0) {
        goto LE; // [233] 246
    }
    _15012 = (_ch_26475 == 9);
    if (_15012 == 0)
    {
        DeRef(_15012);
        _15012 = NOVALUE;
        goto LF; // [242] 258
    }
    else{
        DeRef(_15012);
        _15012 = NOVALUE;
    }
LE: 

    /** 		ch = getch()*/
    _ch_26475 = _61getch();
    if (!IS_ATOM_INT(_ch_26475)) {
        _1 = (long)(DBL_PTR(_ch_26475)->dbl);
        DeRefDS(_ch_26475);
        _ch_26475 = _1;
    }

    /** 	end while*/
    goto LD; // [255] 229
LF: 

    /** 	new_include_space = 0*/
    _61new_include_space_23894 = 0;

    /** 	if ch = 'a' then*/
    if (_ch_26475 != 97)
    goto L10; // [267] 524

    /** 		ch = getch()*/
    _ch_26475 = _61getch();
    if (!IS_ATOM_INT(_ch_26475)) {
        _1 = (long)(DBL_PTR(_ch_26475)->dbl);
        DeRefDS(_ch_26475);
        _ch_26475 = _1;
    }

    /** 		if ch = 's' then*/
    if (_ch_26475 != 115)
    goto L11; // [280] 513

    /** 			ch = getch()*/
    _ch_26475 = _61getch();
    if (!IS_ATOM_INT(_ch_26475)) {
        _1 = (long)(DBL_PTR(_ch_26475)->dbl);
        DeRefDS(_ch_26475);
        _ch_26475 = _1;
    }

    /** 			if ch = ' ' or ch = '\t' then*/
    _15018 = (_ch_26475 == 32);
    if (_15018 != 0) {
        goto L12; // [297] 310
    }
    _15020 = (_ch_26475 == 9);
    if (_15020 == 0)
    {
        DeRef(_15020);
        _15020 = NOVALUE;
        goto L13; // [306] 502
    }
    else{
        DeRef(_15020);
        _15020 = NOVALUE;
    }
L12: 

    /** 				ch = getch()*/
    _ch_26475 = _61getch();
    if (!IS_ATOM_INT(_ch_26475)) {
        _1 = (long)(DBL_PTR(_ch_26475)->dbl);
        DeRefDS(_ch_26475);
        _ch_26475 = _1;
    }

    /** 				while ch = ' ' or ch = '\t' do*/
L14: 
    _15022 = (_ch_26475 == 32);
    if (_15022 != 0) {
        goto L15; // [326] 339
    }
    _15024 = (_ch_26475 == 9);
    if (_15024 == 0)
    {
        DeRef(_15024);
        _15024 = NOVALUE;
        goto L16; // [335] 351
    }
    else{
        DeRef(_15024);
        _15024 = NOVALUE;
    }
L15: 

    /** 					ch = getch()*/
    _ch_26475 = _61getch();
    if (!IS_ATOM_INT(_ch_26475)) {
        _1 = (long)(DBL_PTR(_ch_26475)->dbl);
        DeRefDS(_ch_26475);
        _ch_26475 = _1;
    }

    /** 				end while*/
    goto L14; // [348] 322
L16: 

    /** 				if char_class[ch] = LETTER or ch = '_' then*/
    _2 = (int)SEQ_PTR(_61char_class_23903);
    _15026 = (int)*(((s1_ptr)_2)->base + _ch_26475);
    _15027 = (_15026 == -2);
    _15026 = NOVALUE;
    if (_15027 != 0) {
        goto L17; // [365] 378
    }
    _15029 = (_ch_26475 == 95);
    if (_15029 == 0)
    {
        DeRef(_15029);
        _15029 = NOVALUE;
        goto L18; // [374] 491
    }
    else{
        DeRef(_15029);
        _15029 = NOVALUE;
    }
L17: 

    /** 					gtext = {ch}*/
    _0 = _gtext_26476;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _ch_26475;
    _gtext_26476 = MAKE_SEQ(_1);
    DeRef(_0);

    /** 					ch = getch()*/
    _ch_26475 = _61getch();
    if (!IS_ATOM_INT(_ch_26475)) {
        _1 = (long)(DBL_PTR(_ch_26475)->dbl);
        DeRefDS(_ch_26475);
        _ch_26475 = _1;
    }

    /** 					while id_char[ch] = TRUE do*/
L19: 
    _2 = (int)SEQ_PTR(_61id_char_23904);
    _15032 = (int)*(((s1_ptr)_2)->base + _ch_26475);
    if (_15032 != _13TRUE_436)
    goto L1A; // [404] 426

    /** 						gtext &= ch*/
    Append(&_gtext_26476, _gtext_26476, _ch_26475);

    /** 						ch = getch()*/
    _ch_26475 = _61getch();
    if (!IS_ATOM_INT(_ch_26475)) {
        _1 = (long)(DBL_PTR(_ch_26475)->dbl);
        DeRefDS(_ch_26475);
        _ch_26475 = _1;
    }

    /** 					end while*/
    goto L19; // [423] 396
L1A: 

    /** 					ungetch()*/
    _61ungetch();

    /** 					s = keyfind(gtext, -1, , 1)*/
    RefDS(_gtext_26476);
    _31670 = _53hashfn(_gtext_26476);
    RefDS(_gtext_26476);
    _0 = _s_26478;
    _s_26478 = _53keyfind(_gtext_26476, -1, _35current_file_no_16244, 1, _31670);
    DeRef(_0);
    _31670 = NOVALUE;

    /** 					if not find(s[T_ID], ID_TOKS) then*/
    _2 = (int)SEQ_PTR(_s_26478);
    _15037 = (int)*(((s1_ptr)_2)->base + 1);
    _15038 = find_from(_15037, _37ID_TOKS_15876, 1);
    _15037 = NOVALUE;
    if (_15038 != 0)
    goto L1B; // [463] 474
    _15038 = NOVALUE;

    /** 						CompileErr(36)*/
    RefDS(_22023);
    _44CompileErr(36, _22023, 0);
L1B: 

    /** 					new_include_space = NameSpace_declaration(s[T_SYM])*/
    _2 = (int)SEQ_PTR(_s_26478);
    _15040 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_15040);
    _0 = _61NameSpace_declaration(_15040);
    _61new_include_space_23894 = _0;
    _15040 = NOVALUE;
    if (!IS_ATOM_INT(_61new_include_space_23894)) {
        _1 = (long)(DBL_PTR(_61new_include_space_23894)->dbl);
        DeRefDS(_61new_include_space_23894);
        _61new_include_space_23894 = _1;
    }
    goto L1C; // [488] 633
L18: 

    /** 					CompileErr(113)*/
    RefDS(_22023);
    _44CompileErr(113, _22023, 0);
    goto L1C; // [499] 633
L13: 

    /** 				CompileErr(100)*/
    RefDS(_22023);
    _44CompileErr(100, _22023, 0);
    goto L1C; // [510] 633
L11: 

    /** 			CompileErr(100)*/
    RefDS(_22023);
    _44CompileErr(100, _22023, 0);
    goto L1C; // [521] 633
L10: 

    /** 	elsif find(ch, {'\n', '\r', END_OF_FILE_CHAR}) then*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 10;
    *((int *)(_2+8)) = 13;
    *((int *)(_2+12)) = 26;
    _15042 = MAKE_SEQ(_1);
    _15043 = find_from(_ch_26475, _15042, 1);
    DeRefDS(_15042);
    _15042 = NOVALUE;
    if (_15043 == 0)
    {
        _15043 = NOVALUE;
        goto L1D; // [539] 549
    }
    else{
        _15043 = NOVALUE;
    }

    /** 		ungetch()*/
    _61ungetch();
    goto L1C; // [546] 633
L1D: 

    /** 	elsif ch = '-' then*/
    if (_ch_26475 != 45)
    goto L1E; // [551] 587

    /** 		ch = getch()*/
    _ch_26475 = _61getch();
    if (!IS_ATOM_INT(_ch_26475)) {
        _1 = (long)(DBL_PTR(_ch_26475)->dbl);
        DeRefDS(_ch_26475);
        _ch_26475 = _1;
    }

    /** 		if ch != '-' then*/
    if (_ch_26475 == 45)
    goto L1F; // [564] 576

    /** 			CompileErr(100)*/
    RefDS(_22023);
    _44CompileErr(100, _22023, 0);
L1F: 

    /** 		ungetch()*/
    _61ungetch();

    /** 		ungetch()*/
    _61ungetch();
    goto L1C; // [584] 633
L1E: 

    /** 	elsif ch = '/' then*/
    if (_ch_26475 != 47)
    goto L20; // [589] 625

    /** 		ch = getch()*/
    _ch_26475 = _61getch();
    if (!IS_ATOM_INT(_ch_26475)) {
        _1 = (long)(DBL_PTR(_ch_26475)->dbl);
        DeRefDS(_ch_26475);
        _ch_26475 = _1;
    }

    /** 		if ch != '*' then*/
    if (_ch_26475 == 42)
    goto L21; // [602] 614

    /** 			CompileErr(100)*/
    RefDS(_22023);
    _44CompileErr(100, _22023, 0);
L21: 

    /** 		ungetch()*/
    _61ungetch();

    /** 		ungetch()*/
    _61ungetch();
    goto L1C; // [622] 633
L20: 

    /** 		CompileErr(100)*/
    RefDS(_22023);
    _44CompileErr(100, _22023, 0);
L1C: 

    /** 	start_include = TRUE -- let scanner know*/
    _61start_include_23896 = _13TRUE_436;

    /** 	public_include = is_public*/
    _61public_include_23899 = _is_public_26474;

    /** end procedure*/
    DeRef(_gtext_26476);
    DeRef(_s_26478);
    DeRef(_14984);
    _14984 = NOVALUE;
    DeRef(_15010);
    _15010 = NOVALUE;
    DeRef(_15018);
    _15018 = NOVALUE;
    DeRef(_15022);
    _15022 = NOVALUE;
    _15032 = NOVALUE;
    DeRef(_15027);
    _15027 = NOVALUE;
    return;
    ;
}


void _61main_file()
{
    int _0, _1, _2;
    

    /** 	ifdef STDDEBUG then*/

    /** 		read_line()*/
    _61read_line();

    /** 		default_namespace( )*/
    _61default_namespace();

    /** end procedure*/
    return;
    ;
}


void _61cleanup_open_includes()
{
    int _15053 = NOVALUE;
    int _15052 = NOVALUE;
    int _15051 = NOVALUE;
    int _0, _1, _2;
    

    /** 	for i = 1 to length( IncludeStk ) do*/
    if (IS_SEQUENCE(_61IncludeStk_23905)){
            _15051 = SEQ_PTR(_61IncludeStk_23905)->length;
    }
    else {
        _15051 = 1;
    }
    {
        int _i_26599;
        _i_26599 = 1;
L1: 
        if (_i_26599 > _15051){
            goto L2; // [8] 36
        }

        /** 		close( IncludeStk[i][FILE_PTR] )*/
        _2 = (int)SEQ_PTR(_61IncludeStk_23905);
        _15052 = (int)*(((s1_ptr)_2)->base + _i_26599);
        _2 = (int)SEQ_PTR(_15052);
        _15053 = (int)*(((s1_ptr)_2)->base + 3);
        _15052 = NOVALUE;
        if (IS_ATOM_INT(_15053))
        EClose(_15053);
        else
        EClose((int)DBL_PTR(_15053)->dbl);
        _15053 = NOVALUE;

        /** 	end for*/
        _i_26599 = _i_26599 + 1;
        goto L1; // [31] 15
L2: 
        ;
    }

    /** end procedure*/
    return;
    ;
}



// 0xE5C70CA6
