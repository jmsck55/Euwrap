// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int _59compress(int _x_21935)
{
    int _x4_21936 = NOVALUE;
    int _s_21937 = NOVALUE;
    int _12693 = NOVALUE;
    int _12692 = NOVALUE;
    int _12691 = NOVALUE;
    int _12689 = NOVALUE;
    int _12688 = NOVALUE;
    int _12686 = NOVALUE;
    int _12684 = NOVALUE;
    int _12683 = NOVALUE;
    int _12682 = NOVALUE;
    int _12681 = NOVALUE;
    int _12679 = NOVALUE;
    int _12677 = NOVALUE;
    int _12676 = NOVALUE;
    int _12675 = NOVALUE;
    int _12674 = NOVALUE;
    int _12673 = NOVALUE;
    int _12672 = NOVALUE;
    int _12671 = NOVALUE;
    int _12670 = NOVALUE;
    int _12669 = NOVALUE;
    int _12667 = NOVALUE;
    int _12666 = NOVALUE;
    int _12665 = NOVALUE;
    int _12664 = NOVALUE;
    int _12663 = NOVALUE;
    int _12662 = NOVALUE;
    int _12660 = NOVALUE;
    int _12659 = NOVALUE;
    int _12658 = NOVALUE;
    int _12657 = NOVALUE;
    int _12656 = NOVALUE;
    int _12655 = NOVALUE;
    int _12654 = NOVALUE;
    int _12653 = NOVALUE;
    int _12652 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if integer(x) then*/
    if (IS_ATOM_INT(_x_21935))
    _12652 = 1;
    else if (IS_ATOM_DBL(_x_21935))
    _12652 = IS_ATOM_INT(DoubleToInt(_x_21935));
    else
    _12652 = 0;
    if (_12652 == 0)
    {
        _12652 = NOVALUE;
        goto L1; // [6] 183
    }
    else{
        _12652 = NOVALUE;
    }

    /** 		if x >= MIN1B and x <= MAX1B then*/
    if (IS_ATOM_INT(_x_21935)) {
        _12653 = (_x_21935 >= -2);
    }
    else {
        _12653 = binary_op(GREATEREQ, _x_21935, -2);
    }
    if (IS_ATOM_INT(_12653)) {
        if (_12653 == 0) {
            goto L2; // [15] 44
        }
    }
    else {
        if (DBL_PTR(_12653)->dbl == 0.0) {
            goto L2; // [15] 44
        }
    }
    if (IS_ATOM_INT(_x_21935)) {
        _12655 = (_x_21935 <= 246);
    }
    else {
        _12655 = binary_op(LESSEQ, _x_21935, 246);
    }
    if (_12655 == 0) {
        DeRef(_12655);
        _12655 = NOVALUE;
        goto L2; // [24] 44
    }
    else {
        if (!IS_ATOM_INT(_12655) && DBL_PTR(_12655)->dbl == 0.0){
            DeRef(_12655);
            _12655 = NOVALUE;
            goto L2; // [24] 44
        }
        DeRef(_12655);
        _12655 = NOVALUE;
    }
    DeRef(_12655);
    _12655 = NOVALUE;

    /** 			return {x - MIN1B}*/
    if (IS_ATOM_INT(_x_21935)) {
        _12656 = _x_21935 - -2;
        if ((long)((unsigned long)_12656 +(unsigned long) HIGH_BITS) >= 0){
            _12656 = NewDouble((double)_12656);
        }
    }
    else {
        _12656 = binary_op(MINUS, _x_21935, -2);
    }
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _12656;
    _12657 = MAKE_SEQ(_1);
    _12656 = NOVALUE;
    DeRef(_x_21935);
    DeRef(_x4_21936);
    DeRef(_s_21937);
    DeRef(_12653);
    _12653 = NOVALUE;
    return _12657;
    goto L3; // [41] 319
L2: 

    /** 		elsif x >= MIN2B and x <= MAX2B then*/
    if (IS_ATOM_INT(_x_21935)) {
        _12658 = (_x_21935 >= _59MIN2B_21918);
    }
    else {
        _12658 = binary_op(GREATEREQ, _x_21935, _59MIN2B_21918);
    }
    if (IS_ATOM_INT(_12658)) {
        if (_12658 == 0) {
            goto L4; // [52] 97
        }
    }
    else {
        if (DBL_PTR(_12658)->dbl == 0.0) {
            goto L4; // [52] 97
        }
    }
    if (IS_ATOM_INT(_x_21935)) {
        _12660 = (_x_21935 <= 32767);
    }
    else {
        _12660 = binary_op(LESSEQ, _x_21935, 32767);
    }
    if (_12660 == 0) {
        DeRef(_12660);
        _12660 = NOVALUE;
        goto L4; // [63] 97
    }
    else {
        if (!IS_ATOM_INT(_12660) && DBL_PTR(_12660)->dbl == 0.0){
            DeRef(_12660);
            _12660 = NOVALUE;
            goto L4; // [63] 97
        }
        DeRef(_12660);
        _12660 = NOVALUE;
    }
    DeRef(_12660);
    _12660 = NOVALUE;

    /** 			x -= MIN2B*/
    _0 = _x_21935;
    if (IS_ATOM_INT(_x_21935)) {
        _x_21935 = _x_21935 - _59MIN2B_21918;
        if ((long)((unsigned long)_x_21935 +(unsigned long) HIGH_BITS) >= 0){
            _x_21935 = NewDouble((double)_x_21935);
        }
    }
    else {
        _x_21935 = binary_op(MINUS, _x_21935, _59MIN2B_21918);
    }
    DeRef(_0);

    /** 			return {I2B, and_bits(x, #FF), floor(x / #100)}*/
    if (IS_ATOM_INT(_x_21935)) {
        {unsigned long tu;
             tu = (unsigned long)_x_21935 & (unsigned long)255;
             _12662 = MAKE_UINT(tu);
        }
    }
    else {
        _12662 = binary_op(AND_BITS, _x_21935, 255);
    }
    if (IS_ATOM_INT(_x_21935)) {
        if (256 > 0 && _x_21935 >= 0) {
            _12663 = _x_21935 / 256;
        }
        else {
            temp_dbl = floor((double)_x_21935 / (double)256);
            if (_x_21935 != MININT)
            _12663 = (long)temp_dbl;
            else
            _12663 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x_21935, 256);
        _12663 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 249;
    *((int *)(_2+8)) = _12662;
    *((int *)(_2+12)) = _12663;
    _12664 = MAKE_SEQ(_1);
    _12663 = NOVALUE;
    _12662 = NOVALUE;
    DeRef(_x_21935);
    DeRef(_x4_21936);
    DeRef(_s_21937);
    DeRef(_12653);
    _12653 = NOVALUE;
    DeRef(_12657);
    _12657 = NOVALUE;
    DeRef(_12658);
    _12658 = NOVALUE;
    return _12664;
    goto L3; // [94] 319
L4: 

    /** 		elsif x >= MIN3B and x <= MAX3B then*/
    if (IS_ATOM_INT(_x_21935)) {
        _12665 = (_x_21935 >= _59MIN3B_21924);
    }
    else {
        _12665 = binary_op(GREATEREQ, _x_21935, _59MIN3B_21924);
    }
    if (IS_ATOM_INT(_12665)) {
        if (_12665 == 0) {
            goto L5; // [105] 159
        }
    }
    else {
        if (DBL_PTR(_12665)->dbl == 0.0) {
            goto L5; // [105] 159
        }
    }
    if (IS_ATOM_INT(_x_21935)) {
        _12667 = (_x_21935 <= 8388607);
    }
    else {
        _12667 = binary_op(LESSEQ, _x_21935, 8388607);
    }
    if (_12667 == 0) {
        DeRef(_12667);
        _12667 = NOVALUE;
        goto L5; // [116] 159
    }
    else {
        if (!IS_ATOM_INT(_12667) && DBL_PTR(_12667)->dbl == 0.0){
            DeRef(_12667);
            _12667 = NOVALUE;
            goto L5; // [116] 159
        }
        DeRef(_12667);
        _12667 = NOVALUE;
    }
    DeRef(_12667);
    _12667 = NOVALUE;

    /** 			x -= MIN3B*/
    _0 = _x_21935;
    if (IS_ATOM_INT(_x_21935)) {
        _x_21935 = _x_21935 - _59MIN3B_21924;
        if ((long)((unsigned long)_x_21935 +(unsigned long) HIGH_BITS) >= 0){
            _x_21935 = NewDouble((double)_x_21935);
        }
    }
    else {
        _x_21935 = binary_op(MINUS, _x_21935, _59MIN3B_21924);
    }
    DeRef(_0);

    /** 			return {I3B, and_bits(x, #FF), and_bits(floor(x / #100), #FF), floor(x / #10000)}*/
    if (IS_ATOM_INT(_x_21935)) {
        {unsigned long tu;
             tu = (unsigned long)_x_21935 & (unsigned long)255;
             _12669 = MAKE_UINT(tu);
        }
    }
    else {
        _12669 = binary_op(AND_BITS, _x_21935, 255);
    }
    if (IS_ATOM_INT(_x_21935)) {
        if (256 > 0 && _x_21935 >= 0) {
            _12670 = _x_21935 / 256;
        }
        else {
            temp_dbl = floor((double)_x_21935 / (double)256);
            if (_x_21935 != MININT)
            _12670 = (long)temp_dbl;
            else
            _12670 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x_21935, 256);
        _12670 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    if (IS_ATOM_INT(_12670)) {
        {unsigned long tu;
             tu = (unsigned long)_12670 & (unsigned long)255;
             _12671 = MAKE_UINT(tu);
        }
    }
    else {
        _12671 = binary_op(AND_BITS, _12670, 255);
    }
    DeRef(_12670);
    _12670 = NOVALUE;
    if (IS_ATOM_INT(_x_21935)) {
        if (65536 > 0 && _x_21935 >= 0) {
            _12672 = _x_21935 / 65536;
        }
        else {
            temp_dbl = floor((double)_x_21935 / (double)65536);
            if (_x_21935 != MININT)
            _12672 = (long)temp_dbl;
            else
            _12672 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x_21935, 65536);
        _12672 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 250;
    *((int *)(_2+8)) = _12669;
    *((int *)(_2+12)) = _12671;
    *((int *)(_2+16)) = _12672;
    _12673 = MAKE_SEQ(_1);
    _12672 = NOVALUE;
    _12671 = NOVALUE;
    _12669 = NOVALUE;
    DeRef(_x_21935);
    DeRef(_x4_21936);
    DeRef(_s_21937);
    DeRef(_12653);
    _12653 = NOVALUE;
    DeRef(_12657);
    _12657 = NOVALUE;
    DeRef(_12658);
    _12658 = NOVALUE;
    DeRef(_12664);
    _12664 = NOVALUE;
    DeRef(_12665);
    _12665 = NOVALUE;
    return _12673;
    goto L3; // [156] 319
L5: 

    /** 			return I4B & int_to_bytes(x-MIN4B)*/
    if (IS_ATOM_INT(_x_21935) && IS_ATOM_INT(_59MIN4B_21930)) {
        _12674 = _x_21935 - _59MIN4B_21930;
        if ((long)((unsigned long)_12674 +(unsigned long) HIGH_BITS) >= 0){
            _12674 = NewDouble((double)_12674);
        }
    }
    else {
        _12674 = binary_op(MINUS, _x_21935, _59MIN4B_21930);
    }
    _12675 = _15int_to_bytes(_12674);
    _12674 = NOVALUE;
    if (IS_SEQUENCE(251) && IS_ATOM(_12675)) {
    }
    else if (IS_ATOM(251) && IS_SEQUENCE(_12675)) {
        Prepend(&_12676, _12675, 251);
    }
    else {
        Concat((object_ptr)&_12676, 251, _12675);
    }
    DeRef(_12675);
    _12675 = NOVALUE;
    DeRef(_x_21935);
    DeRef(_x4_21936);
    DeRef(_s_21937);
    DeRef(_12653);
    _12653 = NOVALUE;
    DeRef(_12657);
    _12657 = NOVALUE;
    DeRef(_12658);
    _12658 = NOVALUE;
    DeRef(_12664);
    _12664 = NOVALUE;
    DeRef(_12665);
    _12665 = NOVALUE;
    DeRef(_12673);
    _12673 = NOVALUE;
    return _12676;
    goto L3; // [180] 319
L1: 

    /** 	elsif atom(x) then*/
    _12677 = IS_ATOM(_x_21935);
    if (_12677 == 0)
    {
        _12677 = NOVALUE;
        goto L6; // [188] 240
    }
    else{
        _12677 = NOVALUE;
    }

    /** 		x4 = atom_to_float32(x)*/
    Ref(_x_21935);
    _0 = _x4_21936;
    _x4_21936 = _15atom_to_float32(_x_21935);
    DeRef(_0);

    /** 		if x = float32_to_atom(x4) then*/
    RefDS(_x4_21936);
    _12679 = _15float32_to_atom(_x4_21936);
    if (binary_op_a(NOTEQ, _x_21935, _12679)){
        DeRef(_12679);
        _12679 = NOVALUE;
        goto L7; // [205] 222
    }
    DeRef(_12679);
    _12679 = NOVALUE;

    /** 			return F4B & x4*/
    Prepend(&_12681, _x4_21936, 252);
    DeRef(_x_21935);
    DeRefDS(_x4_21936);
    DeRef(_s_21937);
    DeRef(_12653);
    _12653 = NOVALUE;
    DeRef(_12657);
    _12657 = NOVALUE;
    DeRef(_12658);
    _12658 = NOVALUE;
    DeRef(_12664);
    _12664 = NOVALUE;
    DeRef(_12665);
    _12665 = NOVALUE;
    DeRef(_12673);
    _12673 = NOVALUE;
    DeRef(_12676);
    _12676 = NOVALUE;
    return _12681;
    goto L3; // [219] 319
L7: 

    /** 			return F8B & atom_to_float64(x)*/
    Ref(_x_21935);
    _12682 = _15atom_to_float64(_x_21935);
    if (IS_SEQUENCE(253) && IS_ATOM(_12682)) {
    }
    else if (IS_ATOM(253) && IS_SEQUENCE(_12682)) {
        Prepend(&_12683, _12682, 253);
    }
    else {
        Concat((object_ptr)&_12683, 253, _12682);
    }
    DeRef(_12682);
    _12682 = NOVALUE;
    DeRef(_x_21935);
    DeRef(_x4_21936);
    DeRef(_s_21937);
    DeRef(_12653);
    _12653 = NOVALUE;
    DeRef(_12657);
    _12657 = NOVALUE;
    DeRef(_12658);
    _12658 = NOVALUE;
    DeRef(_12664);
    _12664 = NOVALUE;
    DeRef(_12665);
    _12665 = NOVALUE;
    DeRef(_12673);
    _12673 = NOVALUE;
    DeRef(_12676);
    _12676 = NOVALUE;
    DeRef(_12681);
    _12681 = NOVALUE;
    return _12683;
    goto L3; // [237] 319
L6: 

    /** 		if length(x) <= 255 then*/
    if (IS_SEQUENCE(_x_21935)){
            _12684 = SEQ_PTR(_x_21935)->length;
    }
    else {
        _12684 = 1;
    }
    if (_12684 > 255)
    goto L8; // [245] 261

    /** 			s = {S1B, length(x)}*/
    if (IS_SEQUENCE(_x_21935)){
            _12686 = SEQ_PTR(_x_21935)->length;
    }
    else {
        _12686 = 1;
    }
    DeRef(_s_21937);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 254;
    ((int *)_2)[2] = _12686;
    _s_21937 = MAKE_SEQ(_1);
    _12686 = NOVALUE;
    goto L9; // [258] 275
L8: 

    /** 			s = S4B & int_to_bytes(length(x))*/
    if (IS_SEQUENCE(_x_21935)){
            _12688 = SEQ_PTR(_x_21935)->length;
    }
    else {
        _12688 = 1;
    }
    _12689 = _15int_to_bytes(_12688);
    _12688 = NOVALUE;
    if (IS_SEQUENCE(255) && IS_ATOM(_12689)) {
    }
    else if (IS_ATOM(255) && IS_SEQUENCE(_12689)) {
        Prepend(&_s_21937, _12689, 255);
    }
    else {
        Concat((object_ptr)&_s_21937, 255, _12689);
    }
    DeRef(_12689);
    _12689 = NOVALUE;
L9: 

    /** 		for i = 1 to length(x) do*/
    if (IS_SEQUENCE(_x_21935)){
            _12691 = SEQ_PTR(_x_21935)->length;
    }
    else {
        _12691 = 1;
    }
    {
        int _i_21994;
        _i_21994 = 1;
LA: 
        if (_i_21994 > _12691){
            goto LB; // [280] 310
        }

        /** 			s &= compress(x[i])*/
        _2 = (int)SEQ_PTR(_x_21935);
        _12692 = (int)*(((s1_ptr)_2)->base + _i_21994);
        Ref(_12692);
        _12693 = _59compress(_12692);
        _12692 = NOVALUE;
        if (IS_SEQUENCE(_s_21937) && IS_ATOM(_12693)) {
            Ref(_12693);
            Append(&_s_21937, _s_21937, _12693);
        }
        else if (IS_ATOM(_s_21937) && IS_SEQUENCE(_12693)) {
        }
        else {
            Concat((object_ptr)&_s_21937, _s_21937, _12693);
        }
        DeRef(_12693);
        _12693 = NOVALUE;

        /** 		end for*/
        _i_21994 = _i_21994 + 1;
        goto LA; // [305] 287
LB: 
        ;
    }

    /** 		return s*/
    DeRef(_x_21935);
    DeRef(_x4_21936);
    DeRef(_12653);
    _12653 = NOVALUE;
    DeRef(_12657);
    _12657 = NOVALUE;
    DeRef(_12658);
    _12658 = NOVALUE;
    DeRef(_12664);
    _12664 = NOVALUE;
    DeRef(_12665);
    _12665 = NOVALUE;
    DeRef(_12673);
    _12673 = NOVALUE;
    DeRef(_12676);
    _12676 = NOVALUE;
    DeRef(_12681);
    _12681 = NOVALUE;
    DeRef(_12683);
    _12683 = NOVALUE;
    return _s_21937;
L3: 
    ;
}


void _59init_compress()
{
    int _0, _1, _2;
    

    /** 	comp_cache = repeat({}, COMP_CACHE_SIZE)*/
    DeRef(_59comp_cache_22005);
    _59comp_cache_22005 = Repeat(_5, 64);

    /** end procedure*/
    return;
    ;
}


void _59fcompress(int _f_22011, int _x_22012)
{
    int _x4_22013 = NOVALUE;
    int _s_22014 = NOVALUE;
    int _p_22015 = NOVALUE;
    int _12745 = NOVALUE;
    int _12744 = NOVALUE;
    int _12743 = NOVALUE;
    int _12741 = NOVALUE;
    int _12740 = NOVALUE;
    int _12738 = NOVALUE;
    int _12736 = NOVALUE;
    int _12735 = NOVALUE;
    int _12734 = NOVALUE;
    int _12733 = NOVALUE;
    int _12731 = NOVALUE;
    int _12729 = NOVALUE;
    int _12728 = NOVALUE;
    int _12727 = NOVALUE;
    int _12726 = NOVALUE;
    int _12725 = NOVALUE;
    int _12724 = NOVALUE;
    int _12723 = NOVALUE;
    int _12722 = NOVALUE;
    int _12721 = NOVALUE;
    int _12719 = NOVALUE;
    int _12718 = NOVALUE;
    int _12717 = NOVALUE;
    int _12716 = NOVALUE;
    int _12715 = NOVALUE;
    int _12714 = NOVALUE;
    int _12712 = NOVALUE;
    int _12711 = NOVALUE;
    int _12710 = NOVALUE;
    int _12709 = NOVALUE;
    int _12708 = NOVALUE;
    int _12707 = NOVALUE;
    int _12705 = NOVALUE;
    int _12704 = NOVALUE;
    int _12703 = NOVALUE;
    int _12702 = NOVALUE;
    int _12701 = NOVALUE;
    int _12700 = NOVALUE;
    int _12699 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_f_22011)) {
        _1 = (long)(DBL_PTR(_f_22011)->dbl);
        DeRefDS(_f_22011);
        _f_22011 = _1;
    }

    /** 	if integer(x) then*/
    if (IS_ATOM_INT(_x_22012))
    _12699 = 1;
    else if (IS_ATOM_DBL(_x_22012))
    _12699 = IS_ATOM_INT(DoubleToInt(_x_22012));
    else
    _12699 = 0;
    if (_12699 == 0)
    {
        _12699 = NOVALUE;
        goto L1; // [8] 232
    }
    else{
        _12699 = NOVALUE;
    }

    /** 		if x >= MIN1B and x <= max1b then*/
    if (IS_ATOM_INT(_x_22012)) {
        _12700 = (_x_22012 >= -2);
    }
    else {
        _12700 = binary_op(GREATEREQ, _x_22012, -2);
    }
    if (IS_ATOM_INT(_12700)) {
        if (_12700 == 0) {
            goto L2; // [17] 43
        }
    }
    else {
        if (DBL_PTR(_12700)->dbl == 0.0) {
            goto L2; // [17] 43
        }
    }
    if (IS_ATOM_INT(_x_22012)) {
        _12702 = (_x_22012 <= 182);
    }
    else {
        _12702 = binary_op(LESSEQ, _x_22012, 182);
    }
    if (_12702 == 0) {
        DeRef(_12702);
        _12702 = NOVALUE;
        goto L2; // [28] 43
    }
    else {
        if (!IS_ATOM_INT(_12702) && DBL_PTR(_12702)->dbl == 0.0){
            DeRef(_12702);
            _12702 = NOVALUE;
            goto L2; // [28] 43
        }
        DeRef(_12702);
        _12702 = NOVALUE;
    }
    DeRef(_12702);
    _12702 = NOVALUE;

    /** 			puts(f, x - MIN1B) -- normal, quite small integer*/
    if (IS_ATOM_INT(_x_22012)) {
        _12703 = _x_22012 - -2;
        if ((long)((unsigned long)_12703 +(unsigned long) HIGH_BITS) >= 0){
            _12703 = NewDouble((double)_12703);
        }
    }
    else {
        _12703 = binary_op(MINUS, _x_22012, -2);
    }
    EPuts(_f_22011, _12703); // DJP 
    DeRef(_12703);
    _12703 = NOVALUE;
    goto L3; // [40] 362
L2: 

    /** 			p = 1 + and_bits(x, COMP_CACHE_SIZE-1)*/
    _12704 = 63;
    if (IS_ATOM_INT(_x_22012)) {
        {unsigned long tu;
             tu = (unsigned long)_x_22012 & (unsigned long)63;
             _12705 = MAKE_UINT(tu);
        }
    }
    else {
        _12705 = binary_op(AND_BITS, _x_22012, 63);
    }
    _12704 = NOVALUE;
    if (IS_ATOM_INT(_12705)) {
        _p_22015 = _12705 + 1;
    }
    else
    { // coercing _p_22015 to an integer 1
        _p_22015 = 1+(long)(DBL_PTR(_12705)->dbl);
        if( !IS_ATOM_INT(_p_22015) ){
            _p_22015 = (object)DBL_PTR(_p_22015)->dbl;
        }
    }
    DeRef(_12705);
    _12705 = NOVALUE;

    /** 			if equal(comp_cache[p], x) then*/
    _2 = (int)SEQ_PTR(_59comp_cache_22005);
    _12707 = (int)*(((s1_ptr)_2)->base + _p_22015);
    if (_12707 == _x_22012)
    _12708 = 1;
    else if (IS_ATOM_INT(_12707) && IS_ATOM_INT(_x_22012))
    _12708 = 0;
    else
    _12708 = (compare(_12707, _x_22012) == 0);
    _12707 = NOVALUE;
    if (_12708 == 0)
    {
        _12708 = NOVALUE;
        goto L4; // [69] 86
    }
    else{
        _12708 = NOVALUE;
    }

    /** 				puts(f, CACHE0 + p) -- output the cache slot number*/
    _12709 = 184 + _p_22015;
    if ((long)((unsigned long)_12709 + (unsigned long)HIGH_BITS) >= 0) 
    _12709 = NewDouble((double)_12709);
    EPuts(_f_22011, _12709); // DJP 
    DeRef(_12709);
    _12709 = NOVALUE;
    goto L3; // [83] 362
L4: 

    /** 				comp_cache[p] = x -- store it in cache slot p*/
    Ref(_x_22012);
    _2 = (int)SEQ_PTR(_59comp_cache_22005);
    _2 = (int)(((s1_ptr)_2)->base + _p_22015);
    _1 = *(int *)_2;
    *(int *)_2 = _x_22012;
    DeRef(_1);

    /** 				if x >= MIN2B and x <= MAX2B then*/
    if (IS_ATOM_INT(_x_22012)) {
        _12710 = (_x_22012 >= _59MIN2B_21918);
    }
    else {
        _12710 = binary_op(GREATEREQ, _x_22012, _59MIN2B_21918);
    }
    if (IS_ATOM_INT(_12710)) {
        if (_12710 == 0) {
            goto L5; // [102] 146
        }
    }
    else {
        if (DBL_PTR(_12710)->dbl == 0.0) {
            goto L5; // [102] 146
        }
    }
    if (IS_ATOM_INT(_x_22012)) {
        _12712 = (_x_22012 <= 32767);
    }
    else {
        _12712 = binary_op(LESSEQ, _x_22012, 32767);
    }
    if (_12712 == 0) {
        DeRef(_12712);
        _12712 = NOVALUE;
        goto L5; // [113] 146
    }
    else {
        if (!IS_ATOM_INT(_12712) && DBL_PTR(_12712)->dbl == 0.0){
            DeRef(_12712);
            _12712 = NOVALUE;
            goto L5; // [113] 146
        }
        DeRef(_12712);
        _12712 = NOVALUE;
    }
    DeRef(_12712);
    _12712 = NOVALUE;

    /** 					x -= MIN2B*/
    _0 = _x_22012;
    if (IS_ATOM_INT(_x_22012)) {
        _x_22012 = _x_22012 - _59MIN2B_21918;
        if ((long)((unsigned long)_x_22012 +(unsigned long) HIGH_BITS) >= 0){
            _x_22012 = NewDouble((double)_x_22012);
        }
    }
    else {
        _x_22012 = binary_op(MINUS, _x_22012, _59MIN2B_21918);
    }
    DeRef(_0);

    /** 					puts(f, {I2B, and_bits(x, #FF), floor(x / #100)})*/
    if (IS_ATOM_INT(_x_22012)) {
        {unsigned long tu;
             tu = (unsigned long)_x_22012 & (unsigned long)255;
             _12714 = MAKE_UINT(tu);
        }
    }
    else {
        _12714 = binary_op(AND_BITS, _x_22012, 255);
    }
    if (IS_ATOM_INT(_x_22012)) {
        if (256 > 0 && _x_22012 >= 0) {
            _12715 = _x_22012 / 256;
        }
        else {
            temp_dbl = floor((double)_x_22012 / (double)256);
            if (_x_22012 != MININT)
            _12715 = (long)temp_dbl;
            else
            _12715 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x_22012, 256);
        _12715 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 249;
    *((int *)(_2+8)) = _12714;
    *((int *)(_2+12)) = _12715;
    _12716 = MAKE_SEQ(_1);
    _12715 = NOVALUE;
    _12714 = NOVALUE;
    EPuts(_f_22011, _12716); // DJP 
    DeRefDS(_12716);
    _12716 = NOVALUE;
    goto L3; // [143] 362
L5: 

    /** 				elsif x >= MIN3B and x <= MAX3B then*/
    if (IS_ATOM_INT(_x_22012)) {
        _12717 = (_x_22012 >= _59MIN3B_21924);
    }
    else {
        _12717 = binary_op(GREATEREQ, _x_22012, _59MIN3B_21924);
    }
    if (IS_ATOM_INT(_12717)) {
        if (_12717 == 0) {
            goto L6; // [154] 207
        }
    }
    else {
        if (DBL_PTR(_12717)->dbl == 0.0) {
            goto L6; // [154] 207
        }
    }
    if (IS_ATOM_INT(_x_22012)) {
        _12719 = (_x_22012 <= 8388607);
    }
    else {
        _12719 = binary_op(LESSEQ, _x_22012, 8388607);
    }
    if (_12719 == 0) {
        DeRef(_12719);
        _12719 = NOVALUE;
        goto L6; // [165] 207
    }
    else {
        if (!IS_ATOM_INT(_12719) && DBL_PTR(_12719)->dbl == 0.0){
            DeRef(_12719);
            _12719 = NOVALUE;
            goto L6; // [165] 207
        }
        DeRef(_12719);
        _12719 = NOVALUE;
    }
    DeRef(_12719);
    _12719 = NOVALUE;

    /** 					x -= MIN3B*/
    _0 = _x_22012;
    if (IS_ATOM_INT(_x_22012)) {
        _x_22012 = _x_22012 - _59MIN3B_21924;
        if ((long)((unsigned long)_x_22012 +(unsigned long) HIGH_BITS) >= 0){
            _x_22012 = NewDouble((double)_x_22012);
        }
    }
    else {
        _x_22012 = binary_op(MINUS, _x_22012, _59MIN3B_21924);
    }
    DeRef(_0);

    /** 					puts(f, {I3B, and_bits(x, #FF), and_bits(floor(x / #100), #FF), floor(x / #10000)})*/
    if (IS_ATOM_INT(_x_22012)) {
        {unsigned long tu;
             tu = (unsigned long)_x_22012 & (unsigned long)255;
             _12721 = MAKE_UINT(tu);
        }
    }
    else {
        _12721 = binary_op(AND_BITS, _x_22012, 255);
    }
    if (IS_ATOM_INT(_x_22012)) {
        if (256 > 0 && _x_22012 >= 0) {
            _12722 = _x_22012 / 256;
        }
        else {
            temp_dbl = floor((double)_x_22012 / (double)256);
            if (_x_22012 != MININT)
            _12722 = (long)temp_dbl;
            else
            _12722 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x_22012, 256);
        _12722 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    if (IS_ATOM_INT(_12722)) {
        {unsigned long tu;
             tu = (unsigned long)_12722 & (unsigned long)255;
             _12723 = MAKE_UINT(tu);
        }
    }
    else {
        _12723 = binary_op(AND_BITS, _12722, 255);
    }
    DeRef(_12722);
    _12722 = NOVALUE;
    if (IS_ATOM_INT(_x_22012)) {
        if (65536 > 0 && _x_22012 >= 0) {
            _12724 = _x_22012 / 65536;
        }
        else {
            temp_dbl = floor((double)_x_22012 / (double)65536);
            if (_x_22012 != MININT)
            _12724 = (long)temp_dbl;
            else
            _12724 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x_22012, 65536);
        _12724 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 250;
    *((int *)(_2+8)) = _12721;
    *((int *)(_2+12)) = _12723;
    *((int *)(_2+16)) = _12724;
    _12725 = MAKE_SEQ(_1);
    _12724 = NOVALUE;
    _12723 = NOVALUE;
    _12721 = NOVALUE;
    EPuts(_f_22011, _12725); // DJP 
    DeRefDS(_12725);
    _12725 = NOVALUE;
    goto L3; // [204] 362
L6: 

    /** 					puts(f, I4B & int_to_bytes(x-MIN4B))*/
    if (IS_ATOM_INT(_x_22012) && IS_ATOM_INT(_59MIN4B_21930)) {
        _12726 = _x_22012 - _59MIN4B_21930;
        if ((long)((unsigned long)_12726 +(unsigned long) HIGH_BITS) >= 0){
            _12726 = NewDouble((double)_12726);
        }
    }
    else {
        _12726 = binary_op(MINUS, _x_22012, _59MIN4B_21930);
    }
    _12727 = _15int_to_bytes(_12726);
    _12726 = NOVALUE;
    if (IS_SEQUENCE(251) && IS_ATOM(_12727)) {
    }
    else if (IS_ATOM(251) && IS_SEQUENCE(_12727)) {
        Prepend(&_12728, _12727, 251);
    }
    else {
        Concat((object_ptr)&_12728, 251, _12727);
    }
    DeRef(_12727);
    _12727 = NOVALUE;
    EPuts(_f_22011, _12728); // DJP 
    DeRefDS(_12728);
    _12728 = NOVALUE;
    goto L3; // [229] 362
L1: 

    /** 	elsif atom(x) then*/
    _12729 = IS_ATOM(_x_22012);
    if (_12729 == 0)
    {
        _12729 = NOVALUE;
        goto L7; // [237] 287
    }
    else{
        _12729 = NOVALUE;
    }

    /** 		x4 = atom_to_float32(x)*/
    Ref(_x_22012);
    _0 = _x4_22013;
    _x4_22013 = _15atom_to_float32(_x_22012);
    DeRef(_0);

    /** 		if x = float32_to_atom(x4) then*/
    RefDS(_x4_22013);
    _12731 = _15float32_to_atom(_x4_22013);
    if (binary_op_a(NOTEQ, _x_22012, _12731)){
        DeRef(_12731);
        _12731 = NOVALUE;
        goto L8; // [254] 270
    }
    DeRef(_12731);
    _12731 = NOVALUE;

    /** 			puts(f, F4B & x4)*/
    Prepend(&_12733, _x4_22013, 252);
    EPuts(_f_22011, _12733); // DJP 
    DeRefDS(_12733);
    _12733 = NOVALUE;
    goto L3; // [267] 362
L8: 

    /** 			puts(f, F8B & atom_to_float64(x))*/
    Ref(_x_22012);
    _12734 = _15atom_to_float64(_x_22012);
    if (IS_SEQUENCE(253) && IS_ATOM(_12734)) {
    }
    else if (IS_ATOM(253) && IS_SEQUENCE(_12734)) {
        Prepend(&_12735, _12734, 253);
    }
    else {
        Concat((object_ptr)&_12735, 253, _12734);
    }
    DeRef(_12734);
    _12734 = NOVALUE;
    EPuts(_f_22011, _12735); // DJP 
    DeRefDS(_12735);
    _12735 = NOVALUE;
    goto L3; // [284] 362
L7: 

    /** 		if length(x) <= 255 then*/
    if (IS_SEQUENCE(_x_22012)){
            _12736 = SEQ_PTR(_x_22012)->length;
    }
    else {
        _12736 = 1;
    }
    if (_12736 > 255)
    goto L9; // [292] 308

    /** 			s = {S1B, length(x)}*/
    if (IS_SEQUENCE(_x_22012)){
            _12738 = SEQ_PTR(_x_22012)->length;
    }
    else {
        _12738 = 1;
    }
    DeRef(_s_22014);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 254;
    ((int *)_2)[2] = _12738;
    _s_22014 = MAKE_SEQ(_1);
    _12738 = NOVALUE;
    goto LA; // [305] 322
L9: 

    /** 			s = S4B & int_to_bytes(length(x))*/
    if (IS_SEQUENCE(_x_22012)){
            _12740 = SEQ_PTR(_x_22012)->length;
    }
    else {
        _12740 = 1;
    }
    _12741 = _15int_to_bytes(_12740);
    _12740 = NOVALUE;
    if (IS_SEQUENCE(255) && IS_ATOM(_12741)) {
    }
    else if (IS_ATOM(255) && IS_SEQUENCE(_12741)) {
        Prepend(&_s_22014, _12741, 255);
    }
    else {
        Concat((object_ptr)&_s_22014, 255, _12741);
    }
    DeRef(_12741);
    _12741 = NOVALUE;
LA: 

    /** 		puts(f, s)*/
    EPuts(_f_22011, _s_22014); // DJP 

    /** 		for i = 1 to length(x) do*/
    if (IS_SEQUENCE(_x_22012)){
            _12743 = SEQ_PTR(_x_22012)->length;
    }
    else {
        _12743 = 1;
    }
    {
        int _i_22080;
        _i_22080 = 1;
LB: 
        if (_i_22080 > _12743){
            goto LC; // [334] 361
        }

        /** 			fcompress(f, x[i])*/
        _2 = (int)SEQ_PTR(_x_22012);
        _12744 = (int)*(((s1_ptr)_2)->base + _i_22080);
        DeRef(_12745);
        _12745 = _f_22011;
        Ref(_12744);
        _59fcompress(_12745, _12744);
        _12745 = NOVALUE;
        _12744 = NOVALUE;

        /** 		end for*/
        _i_22080 = _i_22080 + 1;
        goto LB; // [356] 341
LC: 
        ;
    }
L3: 

    /** end procedure*/
    DeRef(_x_22012);
    DeRef(_x4_22013);
    DeRef(_s_22014);
    DeRef(_12700);
    _12700 = NOVALUE;
    DeRef(_12710);
    _12710 = NOVALUE;
    DeRef(_12717);
    _12717 = NOVALUE;
    return;
    ;
}


int _59get4()
{
    int _12754 = NOVALUE;
    int _12753 = NOVALUE;
    int _12752 = NOVALUE;
    int _12751 = NOVALUE;
    int _12750 = NOVALUE;
    int _0, _1, _2;
    

    /** 	poke(mem0, getc(current_db))*/
    if (_59current_db_22093 != last_r_file_no) {
        last_r_file_ptr = which_file(_59current_db_22093, EF_READ);
        last_r_file_no = _59current_db_22093;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _12750 = getKBchar();
        }
        else
        _12750 = getc(last_r_file_ptr);
    }
    else
    _12750 = getc(last_r_file_ptr);
    if (IS_ATOM_INT(_59mem0_22085)){
        poke_addr = (unsigned char *)_59mem0_22085;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_59mem0_22085)->dbl);
    }
    *poke_addr = (unsigned char)_12750;
    _12750 = NOVALUE;

    /** 	poke(mem1, getc(current_db))*/
    if (_59current_db_22093 != last_r_file_no) {
        last_r_file_ptr = which_file(_59current_db_22093, EF_READ);
        last_r_file_no = _59current_db_22093;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _12751 = getKBchar();
        }
        else
        _12751 = getc(last_r_file_ptr);
    }
    else
    _12751 = getc(last_r_file_ptr);
    if (IS_ATOM_INT(_59mem1_22086)){
        poke_addr = (unsigned char *)_59mem1_22086;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_59mem1_22086)->dbl);
    }
    *poke_addr = (unsigned char)_12751;
    _12751 = NOVALUE;

    /** 	poke(mem2, getc(current_db))*/
    if (_59current_db_22093 != last_r_file_no) {
        last_r_file_ptr = which_file(_59current_db_22093, EF_READ);
        last_r_file_no = _59current_db_22093;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _12752 = getKBchar();
        }
        else
        _12752 = getc(last_r_file_ptr);
    }
    else
    _12752 = getc(last_r_file_ptr);
    if (IS_ATOM_INT(_59mem2_22087)){
        poke_addr = (unsigned char *)_59mem2_22087;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_59mem2_22087)->dbl);
    }
    *poke_addr = (unsigned char)_12752;
    _12752 = NOVALUE;

    /** 	poke(mem3, getc(current_db))*/
    if (_59current_db_22093 != last_r_file_no) {
        last_r_file_ptr = which_file(_59current_db_22093, EF_READ);
        last_r_file_no = _59current_db_22093;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _12753 = getKBchar();
        }
        else
        _12753 = getc(last_r_file_ptr);
    }
    else
    _12753 = getc(last_r_file_ptr);
    if (IS_ATOM_INT(_59mem3_22088)){
        poke_addr = (unsigned char *)_59mem3_22088;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_59mem3_22088)->dbl);
    }
    *poke_addr = (unsigned char)_12753;
    _12753 = NOVALUE;

    /** 	return peek4u(mem0)*/
    if (IS_ATOM_INT(_59mem0_22085)) {
        _12754 = *(unsigned long *)_59mem0_22085;
        if ((unsigned)_12754 > (unsigned)MAXINT)
        _12754 = NewDouble((double)(unsigned long)_12754);
    }
    else {
        _12754 = *(unsigned long *)(unsigned long)(DBL_PTR(_59mem0_22085)->dbl);
        if ((unsigned)_12754 > (unsigned)MAXINT)
        _12754 = NewDouble((double)(unsigned long)_12754);
    }
    return _12754;
    ;
}


int _59fdecompress(int _c_22103)
{
    int _s_22104 = NOVALUE;
    int _len_22105 = NOVALUE;
    int _ival_22106 = NOVALUE;
    int _12822 = NOVALUE;
    int _12821 = NOVALUE;
    int _12820 = NOVALUE;
    int _12819 = NOVALUE;
    int _12817 = NOVALUE;
    int _12816 = NOVALUE;
    int _12812 = NOVALUE;
    int _12807 = NOVALUE;
    int _12806 = NOVALUE;
    int _12805 = NOVALUE;
    int _12804 = NOVALUE;
    int _12803 = NOVALUE;
    int _12802 = NOVALUE;
    int _12801 = NOVALUE;
    int _12800 = NOVALUE;
    int _12799 = NOVALUE;
    int _12798 = NOVALUE;
    int _12796 = NOVALUE;
    int _12795 = NOVALUE;
    int _12794 = NOVALUE;
    int _12793 = NOVALUE;
    int _12792 = NOVALUE;
    int _12791 = NOVALUE;
    int _12789 = NOVALUE;
    int _12788 = NOVALUE;
    int _12787 = NOVALUE;
    int _12785 = NOVALUE;
    int _12783 = NOVALUE;
    int _12782 = NOVALUE;
    int _12781 = NOVALUE;
    int _12779 = NOVALUE;
    int _12778 = NOVALUE;
    int _12777 = NOVALUE;
    int _12776 = NOVALUE;
    int _12775 = NOVALUE;
    int _12774 = NOVALUE;
    int _12773 = NOVALUE;
    int _12771 = NOVALUE;
    int _12770 = NOVALUE;
    int _12769 = NOVALUE;
    int _12767 = NOVALUE;
    int _12766 = NOVALUE;
    int _12765 = NOVALUE;
    int _12764 = NOVALUE;
    int _12762 = NOVALUE;
    int _12761 = NOVALUE;
    int _12759 = NOVALUE;
    int _12758 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_c_22103)) {
        _1 = (long)(DBL_PTR(_c_22103)->dbl);
        DeRefDS(_c_22103);
        _c_22103 = _1;
    }

    /** 	if c = 0 then*/
    if (_c_22103 != 0)
    goto L1; // [5] 70

    /** 		c = getc(current_db)*/
    if (_59current_db_22093 != last_r_file_no) {
        last_r_file_ptr = which_file(_59current_db_22093, EF_READ);
        last_r_file_no = _59current_db_22093;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _c_22103 = getKBchar();
        }
        else
        _c_22103 = getc(last_r_file_ptr);
    }
    else
    _c_22103 = getc(last_r_file_ptr);

    /** 		if c <= CACHE0 then*/
    if (_c_22103 > 184)
    goto L2; // [20] 37

    /** 			return c + MIN1B  -- a normal, quite small integer*/
    _12758 = _c_22103 + -2;
    DeRef(_s_22104);
    return _12758;
    goto L3; // [34] 69
L2: 

    /** 		elsif c <= CACHE0 + COMP_CACHE_SIZE then*/
    _12759 = 248;
    if (_c_22103 > 248)
    goto L4; // [45] 68

    /** 			return comp_cache[c-CACHE0]*/
    _12761 = _c_22103 - 184;
    _2 = (int)SEQ_PTR(_59comp_cache_22005);
    _12762 = (int)*(((s1_ptr)_2)->base + _12761);
    Ref(_12762);
    DeRef(_s_22104);
    DeRef(_12758);
    _12758 = NOVALUE;
    _12759 = NOVALUE;
    _12761 = NOVALUE;
    return _12762;
L4: 
L3: 
L1: 

    /** 	if c = I2B then*/
    if (_c_22103 != 249)
    goto L5; // [72] 133

    /** 		ival = getc(current_db) +*/
    if (_59current_db_22093 != last_r_file_no) {
        last_r_file_ptr = which_file(_59current_db_22093, EF_READ);
        last_r_file_no = _59current_db_22093;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _12764 = getKBchar();
        }
        else
        _12764 = getc(last_r_file_ptr);
    }
    else
    _12764 = getc(last_r_file_ptr);
    if (_59current_db_22093 != last_r_file_no) {
        last_r_file_ptr = which_file(_59current_db_22093, EF_READ);
        last_r_file_no = _59current_db_22093;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _12765 = getKBchar();
        }
        else
        _12765 = getc(last_r_file_ptr);
    }
    else
    _12765 = getc(last_r_file_ptr);
    _12766 = 256 * _12765;
    _12765 = NOVALUE;
    _12767 = _12764 + _12766;
    _12764 = NOVALUE;
    _12766 = NOVALUE;
    _ival_22106 = _12767 + _59MIN2B_21918;
    _12767 = NOVALUE;

    /** 		comp_cache[1 + and_bits(ival, COMP_CACHE_SIZE-1)] = ival*/
    _12769 = 63;
    {unsigned long tu;
         tu = (unsigned long)_ival_22106 & (unsigned long)63;
         _12770 = MAKE_UINT(tu);
    }
    _12769 = NOVALUE;
    if (IS_ATOM_INT(_12770)) {
        _12771 = _12770 + 1;
    }
    else
    _12771 = binary_op(PLUS, 1, _12770);
    DeRef(_12770);
    _12770 = NOVALUE;
    _2 = (int)SEQ_PTR(_59comp_cache_22005);
    if (!IS_ATOM_INT(_12771))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_12771)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _12771);
    _1 = *(int *)_2;
    *(int *)_2 = _ival_22106;
    DeRef(_1);

    /** 		return ival*/
    DeRef(_s_22104);
    DeRef(_12758);
    _12758 = NOVALUE;
    DeRef(_12759);
    _12759 = NOVALUE;
    DeRef(_12761);
    _12761 = NOVALUE;
    _12762 = NOVALUE;
    DeRef(_12771);
    _12771 = NOVALUE;
    return _ival_22106;
    goto L6; // [130] 514
L5: 

    /** 	elsif c = I3B then*/
    if (_c_22103 != 250)
    goto L7; // [135] 209

    /** 		ival = getc(current_db) +*/
    if (_59current_db_22093 != last_r_file_no) {
        last_r_file_ptr = which_file(_59current_db_22093, EF_READ);
        last_r_file_no = _59current_db_22093;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _12773 = getKBchar();
        }
        else
        _12773 = getc(last_r_file_ptr);
    }
    else
    _12773 = getc(last_r_file_ptr);
    if (_59current_db_22093 != last_r_file_no) {
        last_r_file_ptr = which_file(_59current_db_22093, EF_READ);
        last_r_file_no = _59current_db_22093;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _12774 = getKBchar();
        }
        else
        _12774 = getc(last_r_file_ptr);
    }
    else
    _12774 = getc(last_r_file_ptr);
    _12775 = 256 * _12774;
    _12774 = NOVALUE;
    _12776 = _12773 + _12775;
    _12773 = NOVALUE;
    _12775 = NOVALUE;
    if (_59current_db_22093 != last_r_file_no) {
        last_r_file_ptr = which_file(_59current_db_22093, EF_READ);
        last_r_file_no = _59current_db_22093;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _12777 = getKBchar();
        }
        else
        _12777 = getc(last_r_file_ptr);
    }
    else
    _12777 = getc(last_r_file_ptr);
    _12778 = 65536 * _12777;
    _12777 = NOVALUE;
    _12779 = _12776 + _12778;
    _12776 = NOVALUE;
    _12778 = NOVALUE;
    _ival_22106 = _12779 + _59MIN3B_21924;
    _12779 = NOVALUE;

    /** 		comp_cache[1 + and_bits(ival, COMP_CACHE_SIZE-1)] = ival*/
    _12781 = 63;
    {unsigned long tu;
         tu = (unsigned long)_ival_22106 & (unsigned long)63;
         _12782 = MAKE_UINT(tu);
    }
    _12781 = NOVALUE;
    if (IS_ATOM_INT(_12782)) {
        _12783 = _12782 + 1;
    }
    else
    _12783 = binary_op(PLUS, 1, _12782);
    DeRef(_12782);
    _12782 = NOVALUE;
    _2 = (int)SEQ_PTR(_59comp_cache_22005);
    if (!IS_ATOM_INT(_12783))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_12783)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _12783);
    _1 = *(int *)_2;
    *(int *)_2 = _ival_22106;
    DeRef(_1);

    /** 		return ival*/
    DeRef(_s_22104);
    DeRef(_12758);
    _12758 = NOVALUE;
    DeRef(_12759);
    _12759 = NOVALUE;
    DeRef(_12761);
    _12761 = NOVALUE;
    _12762 = NOVALUE;
    DeRef(_12771);
    _12771 = NOVALUE;
    DeRef(_12783);
    _12783 = NOVALUE;
    return _ival_22106;
    goto L6; // [206] 514
L7: 

    /** 	elsif c = I4B  then*/
    if (_c_22103 != 251)
    goto L8; // [211] 257

    /** 		ival = get4() + MIN4B*/
    _12785 = _59get4();
    if (IS_ATOM_INT(_12785) && IS_ATOM_INT(_59MIN4B_21930)) {
        _ival_22106 = _12785 + _59MIN4B_21930;
    }
    else {
        _ival_22106 = binary_op(PLUS, _12785, _59MIN4B_21930);
    }
    DeRef(_12785);
    _12785 = NOVALUE;
    if (!IS_ATOM_INT(_ival_22106)) {
        _1 = (long)(DBL_PTR(_ival_22106)->dbl);
        DeRefDS(_ival_22106);
        _ival_22106 = _1;
    }

    /** 		comp_cache[1 + and_bits(ival, COMP_CACHE_SIZE-1)] = ival*/
    _12787 = 63;
    {unsigned long tu;
         tu = (unsigned long)_ival_22106 & (unsigned long)63;
         _12788 = MAKE_UINT(tu);
    }
    _12787 = NOVALUE;
    if (IS_ATOM_INT(_12788)) {
        _12789 = _12788 + 1;
    }
    else
    _12789 = binary_op(PLUS, 1, _12788);
    DeRef(_12788);
    _12788 = NOVALUE;
    _2 = (int)SEQ_PTR(_59comp_cache_22005);
    if (!IS_ATOM_INT(_12789))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_12789)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _12789);
    _1 = *(int *)_2;
    *(int *)_2 = _ival_22106;
    DeRef(_1);

    /** 		return ival*/
    DeRef(_s_22104);
    DeRef(_12758);
    _12758 = NOVALUE;
    DeRef(_12759);
    _12759 = NOVALUE;
    DeRef(_12761);
    _12761 = NOVALUE;
    _12762 = NOVALUE;
    DeRef(_12771);
    _12771 = NOVALUE;
    DeRef(_12783);
    _12783 = NOVALUE;
    DeRef(_12789);
    _12789 = NOVALUE;
    return _ival_22106;
    goto L6; // [254] 514
L8: 

    /** 	elsif c = F4B then*/
    if (_c_22103 != 252)
    goto L9; // [259] 303

    /** 		return float32_to_atom({getc(current_db), getc(current_db),*/
    if (_59current_db_22093 != last_r_file_no) {
        last_r_file_ptr = which_file(_59current_db_22093, EF_READ);
        last_r_file_no = _59current_db_22093;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _12791 = getKBchar();
        }
        else
        _12791 = getc(last_r_file_ptr);
    }
    else
    _12791 = getc(last_r_file_ptr);
    if (_59current_db_22093 != last_r_file_no) {
        last_r_file_ptr = which_file(_59current_db_22093, EF_READ);
        last_r_file_no = _59current_db_22093;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _12792 = getKBchar();
        }
        else
        _12792 = getc(last_r_file_ptr);
    }
    else
    _12792 = getc(last_r_file_ptr);
    if (_59current_db_22093 != last_r_file_no) {
        last_r_file_ptr = which_file(_59current_db_22093, EF_READ);
        last_r_file_no = _59current_db_22093;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _12793 = getKBchar();
        }
        else
        _12793 = getc(last_r_file_ptr);
    }
    else
    _12793 = getc(last_r_file_ptr);
    if (_59current_db_22093 != last_r_file_no) {
        last_r_file_ptr = which_file(_59current_db_22093, EF_READ);
        last_r_file_no = _59current_db_22093;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _12794 = getKBchar();
        }
        else
        _12794 = getc(last_r_file_ptr);
    }
    else
    _12794 = getc(last_r_file_ptr);
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _12791;
    *((int *)(_2+8)) = _12792;
    *((int *)(_2+12)) = _12793;
    *((int *)(_2+16)) = _12794;
    _12795 = MAKE_SEQ(_1);
    _12794 = NOVALUE;
    _12793 = NOVALUE;
    _12792 = NOVALUE;
    _12791 = NOVALUE;
    _12796 = _15float32_to_atom(_12795);
    _12795 = NOVALUE;
    DeRef(_s_22104);
    DeRef(_12758);
    _12758 = NOVALUE;
    DeRef(_12759);
    _12759 = NOVALUE;
    DeRef(_12761);
    _12761 = NOVALUE;
    _12762 = NOVALUE;
    DeRef(_12771);
    _12771 = NOVALUE;
    DeRef(_12783);
    _12783 = NOVALUE;
    DeRef(_12789);
    _12789 = NOVALUE;
    return _12796;
    goto L6; // [300] 514
L9: 

    /** 	elsif c = F8B then*/
    if (_c_22103 != 253)
    goto LA; // [305] 373

    /** 		return float64_to_atom({getc(current_db), getc(current_db),*/
    if (_59current_db_22093 != last_r_file_no) {
        last_r_file_ptr = which_file(_59current_db_22093, EF_READ);
        last_r_file_no = _59current_db_22093;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _12798 = getKBchar();
        }
        else
        _12798 = getc(last_r_file_ptr);
    }
    else
    _12798 = getc(last_r_file_ptr);
    if (_59current_db_22093 != last_r_file_no) {
        last_r_file_ptr = which_file(_59current_db_22093, EF_READ);
        last_r_file_no = _59current_db_22093;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _12799 = getKBchar();
        }
        else
        _12799 = getc(last_r_file_ptr);
    }
    else
    _12799 = getc(last_r_file_ptr);
    if (_59current_db_22093 != last_r_file_no) {
        last_r_file_ptr = which_file(_59current_db_22093, EF_READ);
        last_r_file_no = _59current_db_22093;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _12800 = getKBchar();
        }
        else
        _12800 = getc(last_r_file_ptr);
    }
    else
    _12800 = getc(last_r_file_ptr);
    if (_59current_db_22093 != last_r_file_no) {
        last_r_file_ptr = which_file(_59current_db_22093, EF_READ);
        last_r_file_no = _59current_db_22093;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _12801 = getKBchar();
        }
        else
        _12801 = getc(last_r_file_ptr);
    }
    else
    _12801 = getc(last_r_file_ptr);
    if (_59current_db_22093 != last_r_file_no) {
        last_r_file_ptr = which_file(_59current_db_22093, EF_READ);
        last_r_file_no = _59current_db_22093;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _12802 = getKBchar();
        }
        else
        _12802 = getc(last_r_file_ptr);
    }
    else
    _12802 = getc(last_r_file_ptr);
    if (_59current_db_22093 != last_r_file_no) {
        last_r_file_ptr = which_file(_59current_db_22093, EF_READ);
        last_r_file_no = _59current_db_22093;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _12803 = getKBchar();
        }
        else
        _12803 = getc(last_r_file_ptr);
    }
    else
    _12803 = getc(last_r_file_ptr);
    if (_59current_db_22093 != last_r_file_no) {
        last_r_file_ptr = which_file(_59current_db_22093, EF_READ);
        last_r_file_no = _59current_db_22093;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _12804 = getKBchar();
        }
        else
        _12804 = getc(last_r_file_ptr);
    }
    else
    _12804 = getc(last_r_file_ptr);
    if (_59current_db_22093 != last_r_file_no) {
        last_r_file_ptr = which_file(_59current_db_22093, EF_READ);
        last_r_file_no = _59current_db_22093;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _12805 = getKBchar();
        }
        else
        _12805 = getc(last_r_file_ptr);
    }
    else
    _12805 = getc(last_r_file_ptr);
    _1 = NewS1(8);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _12798;
    *((int *)(_2+8)) = _12799;
    *((int *)(_2+12)) = _12800;
    *((int *)(_2+16)) = _12801;
    *((int *)(_2+20)) = _12802;
    *((int *)(_2+24)) = _12803;
    *((int *)(_2+28)) = _12804;
    *((int *)(_2+32)) = _12805;
    _12806 = MAKE_SEQ(_1);
    _12805 = NOVALUE;
    _12804 = NOVALUE;
    _12803 = NOVALUE;
    _12802 = NOVALUE;
    _12801 = NOVALUE;
    _12800 = NOVALUE;
    _12799 = NOVALUE;
    _12798 = NOVALUE;
    _12807 = _15float64_to_atom(_12806);
    _12806 = NOVALUE;
    DeRef(_s_22104);
    DeRef(_12758);
    _12758 = NOVALUE;
    DeRef(_12759);
    _12759 = NOVALUE;
    DeRef(_12761);
    _12761 = NOVALUE;
    _12762 = NOVALUE;
    DeRef(_12771);
    _12771 = NOVALUE;
    DeRef(_12783);
    _12783 = NOVALUE;
    DeRef(_12789);
    _12789 = NOVALUE;
    DeRef(_12796);
    _12796 = NOVALUE;
    return _12807;
    goto L6; // [370] 514
LA: 

    /** 		if c = S1B then*/
    if (_c_22103 != 254)
    goto LB; // [375] 389

    /** 			len = getc(current_db)*/
    if (_59current_db_22093 != last_r_file_no) {
        last_r_file_ptr = which_file(_59current_db_22093, EF_READ);
        last_r_file_no = _59current_db_22093;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _len_22105 = getKBchar();
        }
        else
        _len_22105 = getc(last_r_file_ptr);
    }
    else
    _len_22105 = getc(last_r_file_ptr);
    goto LC; // [386] 397
LB: 

    /** 			len = get4()*/
    _len_22105 = _59get4();
    if (!IS_ATOM_INT(_len_22105)) {
        _1 = (long)(DBL_PTR(_len_22105)->dbl);
        DeRefDS(_len_22105);
        _len_22105 = _1;
    }
LC: 

    /** 		s = repeat(0, len)*/
    DeRef(_s_22104);
    _s_22104 = Repeat(0, _len_22105);

    /** 		for i = 1 to len do*/
    _12812 = _len_22105;
    {
        int _i_22178;
        _i_22178 = 1;
LD: 
        if (_i_22178 > _12812){
            goto LE; // [410] 507
        }

        /** 			c = getc(current_db)*/
        if (_59current_db_22093 != last_r_file_no) {
            last_r_file_ptr = which_file(_59current_db_22093, EF_READ);
            last_r_file_no = _59current_db_22093;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _c_22103 = getKBchar();
            }
            else
            _c_22103 = getc(last_r_file_ptr);
        }
        else
        _c_22103 = getc(last_r_file_ptr);

        /** 			if c < I2B then*/
        if (_c_22103 >= 249)
        goto LF; // [426] 486

        /** 				if c <= CACHE0 then*/
        if (_c_22103 > 184)
        goto L10; // [434] 451

        /** 					s[i] = c + MIN1B*/
        _12816 = _c_22103 + -2;
        _2 = (int)SEQ_PTR(_s_22104);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _s_22104 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_22178);
        _1 = *(int *)_2;
        *(int *)_2 = _12816;
        if( _1 != _12816 ){
            DeRef(_1);
        }
        _12816 = NOVALUE;
        goto L11; // [448] 500
L10: 

        /** 				elsif c <= CACHE0 + COMP_CACHE_SIZE then*/
        _12817 = 248;
        if (_c_22103 > 248)
        goto L11; // [459] 500

        /** 					s[i] = comp_cache[c - CACHE0]*/
        _12819 = _c_22103 - 184;
        _2 = (int)SEQ_PTR(_59comp_cache_22005);
        _12820 = (int)*(((s1_ptr)_2)->base + _12819);
        Ref(_12820);
        _2 = (int)SEQ_PTR(_s_22104);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _s_22104 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_22178);
        _1 = *(int *)_2;
        *(int *)_2 = _12820;
        if( _1 != _12820 ){
            DeRef(_1);
        }
        _12820 = NOVALUE;
        goto L11; // [483] 500
LF: 

        /** 				s[i] = fdecompress(c)*/
        DeRef(_12821);
        _12821 = _c_22103;
        _12822 = _59fdecompress(_12821);
        _12821 = NOVALUE;
        _2 = (int)SEQ_PTR(_s_22104);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _s_22104 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_22178);
        _1 = *(int *)_2;
        *(int *)_2 = _12822;
        if( _1 != _12822 ){
            DeRef(_1);
        }
        _12822 = NOVALUE;
L11: 

        /** 		end for*/
        _i_22178 = _i_22178 + 1;
        goto LD; // [502] 417
LE: 
        ;
    }

    /** 		return s*/
    DeRef(_12758);
    _12758 = NOVALUE;
    DeRef(_12759);
    _12759 = NOVALUE;
    DeRef(_12761);
    _12761 = NOVALUE;
    _12762 = NOVALUE;
    DeRef(_12771);
    _12771 = NOVALUE;
    DeRef(_12783);
    _12783 = NOVALUE;
    DeRef(_12789);
    _12789 = NOVALUE;
    DeRef(_12817);
    _12817 = NOVALUE;
    DeRef(_12796);
    _12796 = NOVALUE;
    DeRef(_12807);
    _12807 = NOVALUE;
    DeRef(_12819);
    _12819 = NOVALUE;
    return _s_22104;
L6: 
    ;
}



// 0x75308296
