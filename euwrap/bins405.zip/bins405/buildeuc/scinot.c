// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int _62reverse(int _s_22412)
{
    int _lower_22413 = NOVALUE;
    int _n_22414 = NOVALUE;
    int _n2_22415 = NOVALUE;
    int _t_22416 = NOVALUE;
    int _13041 = NOVALUE;
    int _13040 = NOVALUE;
    int _13039 = NOVALUE;
    int _13036 = NOVALUE;
    int _0, _1, _2;
    

    /** 	n = length(s)*/
    if (IS_SEQUENCE(_s_22412)){
            _n_22414 = SEQ_PTR(_s_22412)->length;
    }
    else {
        _n_22414 = 1;
    }

    /** 	n2 = floor(n/2)+1*/
    _13036 = _n_22414 >> 1;
    _n2_22415 = _13036 + 1;
    _13036 = NOVALUE;

    /** 	t = repeat(0, n)*/
    DeRef(_t_22416);
    _t_22416 = Repeat(0, _n_22414);

    /** 	lower = 1*/
    _lower_22413 = 1;

    /** 	for upper = n to n2 by -1 do*/
    _13039 = _n2_22415;
    {
        int _upper_22422;
        _upper_22422 = _n_22414;
L1: 
        if (_upper_22422 < _13039){
            goto L2; // [34] 74
        }

        /** 		t[upper] = s[lower]*/
        _2 = (int)SEQ_PTR(_s_22412);
        _13040 = (int)*(((s1_ptr)_2)->base + _lower_22413);
        Ref(_13040);
        _2 = (int)SEQ_PTR(_t_22416);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _t_22416 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _upper_22422);
        _1 = *(int *)_2;
        *(int *)_2 = _13040;
        if( _1 != _13040 ){
            DeRef(_1);
        }
        _13040 = NOVALUE;

        /** 		t[lower] = s[upper]*/
        _2 = (int)SEQ_PTR(_s_22412);
        _13041 = (int)*(((s1_ptr)_2)->base + _upper_22422);
        Ref(_13041);
        _2 = (int)SEQ_PTR(_t_22416);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _t_22416 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _lower_22413);
        _1 = *(int *)_2;
        *(int *)_2 = _13041;
        if( _1 != _13041 ){
            DeRef(_1);
        }
        _13041 = NOVALUE;

        /** 		lower += 1*/
        _lower_22413 = _lower_22413 + 1;

        /** 	end for*/
        _upper_22422 = _upper_22422 + -1;
        goto L1; // [69] 41
L2: 
        ;
    }

    /** 	return t*/
    DeRefDS(_s_22412);
    return _t_22416;
    ;
}


int _62carry(int _a_22429, int _radix_22430)
{
    int _q_22431 = NOVALUE;
    int _r_22432 = NOVALUE;
    int _b_22433 = NOVALUE;
    int _rmax_22434 = NOVALUE;
    int _i_22435 = NOVALUE;
    int _13055 = NOVALUE;
    int _13054 = NOVALUE;
    int _13053 = NOVALUE;
    int _13050 = NOVALUE;
    int _13044 = NOVALUE;
    int _0, _1, _2;
    

    /** 		rmax = radix - 1*/
    DeRef(_rmax_22434);
    _rmax_22434 = _radix_22430 - 1;
    if ((long)((unsigned long)_rmax_22434 +(unsigned long) HIGH_BITS) >= 0){
        _rmax_22434 = NewDouble((double)_rmax_22434);
    }

    /** 		i = 1*/
    DeRef(_i_22435);
    _i_22435 = 1;

    /** 		while i <= length(a) do*/
L1: 
    if (IS_SEQUENCE(_a_22429)){
            _13044 = SEQ_PTR(_a_22429)->length;
    }
    else {
        _13044 = 1;
    }
    if (binary_op_a(GREATER, _i_22435, _13044)){
        _13044 = NOVALUE;
        goto L2; // [24] 104
    }
    _13044 = NOVALUE;

    /** 				b = a[i]*/
    DeRef(_b_22433);
    _2 = (int)SEQ_PTR(_a_22429);
    if (!IS_ATOM_INT(_i_22435)){
        _b_22433 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_22435)->dbl));
    }
    else{
        _b_22433 = (int)*(((s1_ptr)_2)->base + _i_22435);
    }
    Ref(_b_22433);

    /** 				if b > rmax then*/
    if (binary_op_a(LESSEQ, _b_22433, _rmax_22434)){
        goto L3; // [36] 93
    }

    /** 						q = floor( b / radix )*/
    DeRef(_q_22431);
    if (IS_ATOM_INT(_b_22433)) {
        if (_radix_22430 > 0 && _b_22433 >= 0) {
            _q_22431 = _b_22433 / _radix_22430;
        }
        else {
            temp_dbl = floor((double)_b_22433 / (double)_radix_22430);
            if (_b_22433 != MININT)
            _q_22431 = (long)temp_dbl;
            else
            _q_22431 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _b_22433, _radix_22430);
        _q_22431 = unary_op(FLOOR, _2);
        DeRef(_2);
    }

    /** 						r = remainder( b, radix )*/
    DeRef(_r_22432);
    if (IS_ATOM_INT(_b_22433)) {
        _r_22432 = (_b_22433 % _radix_22430);
    }
    else {
        temp_d.dbl = (double)_radix_22430;
        _r_22432 = Dremainder(DBL_PTR(_b_22433), &temp_d);
    }

    /** 						a[i] = r*/
    Ref(_r_22432);
    _2 = (int)SEQ_PTR(_a_22429);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _a_22429 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_i_22435))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_22435)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _i_22435);
    _1 = *(int *)_2;
    *(int *)_2 = _r_22432;
    DeRef(_1);

    /** 						if i = length(a) then*/
    if (IS_SEQUENCE(_a_22429)){
            _13050 = SEQ_PTR(_a_22429)->length;
    }
    else {
        _13050 = 1;
    }
    if (binary_op_a(NOTEQ, _i_22435, _13050)){
        _13050 = NOVALUE;
        goto L4; // [63] 74
    }
    _13050 = NOVALUE;

    /** 								a &= 0*/
    Append(&_a_22429, _a_22429, 0);
L4: 

    /** 						a[i+1] += q*/
    if (IS_ATOM_INT(_i_22435)) {
        _13053 = _i_22435 + 1;
    }
    else
    _13053 = binary_op(PLUS, 1, _i_22435);
    _2 = (int)SEQ_PTR(_a_22429);
    if (!IS_ATOM_INT(_13053)){
        _13054 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_13053)->dbl));
    }
    else{
        _13054 = (int)*(((s1_ptr)_2)->base + _13053);
    }
    if (IS_ATOM_INT(_13054) && IS_ATOM_INT(_q_22431)) {
        _13055 = _13054 + _q_22431;
        if ((long)((unsigned long)_13055 + (unsigned long)HIGH_BITS) >= 0) 
        _13055 = NewDouble((double)_13055);
    }
    else {
        _13055 = binary_op(PLUS, _13054, _q_22431);
    }
    _13054 = NOVALUE;
    _2 = (int)SEQ_PTR(_a_22429);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _a_22429 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_13053))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_13053)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _13053);
    _1 = *(int *)_2;
    *(int *)_2 = _13055;
    if( _1 != _13055 ){
        DeRef(_1);
    }
    _13055 = NOVALUE;
L3: 

    /** 				i += 1*/
    _0 = _i_22435;
    if (IS_ATOM_INT(_i_22435)) {
        _i_22435 = _i_22435 + 1;
        if (_i_22435 > MAXINT){
            _i_22435 = NewDouble((double)_i_22435);
        }
    }
    else
    _i_22435 = binary_op(PLUS, 1, _i_22435);
    DeRef(_0);

    /** 		end while*/
    goto L1; // [101] 21
L2: 

    /** 		return a*/
    DeRef(_q_22431);
    DeRef(_r_22432);
    DeRef(_b_22433);
    DeRef(_rmax_22434);
    DeRef(_i_22435);
    DeRef(_13053);
    _13053 = NOVALUE;
    return _a_22429;
    ;
}


int _62add(int _a_22455, int _b_22456)
{
    int _13073 = NOVALUE;
    int _13071 = NOVALUE;
    int _13070 = NOVALUE;
    int _13069 = NOVALUE;
    int _13068 = NOVALUE;
    int _13066 = NOVALUE;
    int _13065 = NOVALUE;
    int _13063 = NOVALUE;
    int _13062 = NOVALUE;
    int _13061 = NOVALUE;
    int _13060 = NOVALUE;
    int _13058 = NOVALUE;
    int _13057 = NOVALUE;
    int _0, _1, _2;
    

    /** 		if length(a) < length(b) then*/
    if (IS_SEQUENCE(_a_22455)){
            _13057 = SEQ_PTR(_a_22455)->length;
    }
    else {
        _13057 = 1;
    }
    if (IS_SEQUENCE(_b_22456)){
            _13058 = SEQ_PTR(_b_22456)->length;
    }
    else {
        _13058 = 1;
    }
    if (_13057 >= _13058)
    goto L1; // [13] 40

    /** 				a &= repeat( 0, length(b) - length(a) )*/
    if (IS_SEQUENCE(_b_22456)){
            _13060 = SEQ_PTR(_b_22456)->length;
    }
    else {
        _13060 = 1;
    }
    if (IS_SEQUENCE(_a_22455)){
            _13061 = SEQ_PTR(_a_22455)->length;
    }
    else {
        _13061 = 1;
    }
    _13062 = _13060 - _13061;
    _13060 = NOVALUE;
    _13061 = NOVALUE;
    _13063 = Repeat(0, _13062);
    _13062 = NOVALUE;
    Concat((object_ptr)&_a_22455, _a_22455, _13063);
    DeRefDS(_13063);
    _13063 = NOVALUE;
    goto L2; // [37] 74
L1: 

    /** 		elsif length(b) < length(a) then*/
    if (IS_SEQUENCE(_b_22456)){
            _13065 = SEQ_PTR(_b_22456)->length;
    }
    else {
        _13065 = 1;
    }
    if (IS_SEQUENCE(_a_22455)){
            _13066 = SEQ_PTR(_a_22455)->length;
    }
    else {
        _13066 = 1;
    }
    if (_13065 >= _13066)
    goto L3; // [48] 73

    /** 				b &= repeat( 0, length(a) - length(b) )*/
    if (IS_SEQUENCE(_a_22455)){
            _13068 = SEQ_PTR(_a_22455)->length;
    }
    else {
        _13068 = 1;
    }
    if (IS_SEQUENCE(_b_22456)){
            _13069 = SEQ_PTR(_b_22456)->length;
    }
    else {
        _13069 = 1;
    }
    _13070 = _13068 - _13069;
    _13068 = NOVALUE;
    _13069 = NOVALUE;
    _13071 = Repeat(0, _13070);
    _13070 = NOVALUE;
    Concat((object_ptr)&_b_22456, _b_22456, _13071);
    DeRefDS(_13071);
    _13071 = NOVALUE;
L3: 
L2: 

    /** 		return a + b*/
    _13073 = binary_op(PLUS, _a_22455, _b_22456);
    DeRefDS(_a_22455);
    DeRefDS(_b_22456);
    return _13073;
    ;
}


int _62borrow(int _a_22478, int _radix_22479)
{
    int _13081 = NOVALUE;
    int _13080 = NOVALUE;
    int _13079 = NOVALUE;
    int _13078 = NOVALUE;
    int _13077 = NOVALUE;
    int _13075 = NOVALUE;
    int _13074 = NOVALUE;
    int _0, _1, _2;
    

    /** 		for i = length(a) to 2 by -1 do*/
    if (IS_SEQUENCE(_a_22478)){
            _13074 = SEQ_PTR(_a_22478)->length;
    }
    else {
        _13074 = 1;
    }
    {
        int _i_22481;
        _i_22481 = _13074;
L1: 
        if (_i_22481 < 2){
            goto L2; // [10] 67
        }

        /** 				if a[i] < 0 then*/
        _2 = (int)SEQ_PTR(_a_22478);
        _13075 = (int)*(((s1_ptr)_2)->base + _i_22481);
        if (binary_op_a(GREATEREQ, _13075, 0)){
            _13075 = NOVALUE;
            goto L3; // [23] 60
        }
        _13075 = NOVALUE;

        /** 						a[i] += radix*/
        _2 = (int)SEQ_PTR(_a_22478);
        _13077 = (int)*(((s1_ptr)_2)->base + _i_22481);
        if (IS_ATOM_INT(_13077)) {
            _13078 = _13077 + _radix_22479;
            if ((long)((unsigned long)_13078 + (unsigned long)HIGH_BITS) >= 0) 
            _13078 = NewDouble((double)_13078);
        }
        else {
            _13078 = binary_op(PLUS, _13077, _radix_22479);
        }
        _13077 = NOVALUE;
        _2 = (int)SEQ_PTR(_a_22478);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _a_22478 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_22481);
        _1 = *(int *)_2;
        *(int *)_2 = _13078;
        if( _1 != _13078 ){
            DeRef(_1);
        }
        _13078 = NOVALUE;

        /** 						a[i-1] -= 1*/
        _13079 = _i_22481 - 1;
        _2 = (int)SEQ_PTR(_a_22478);
        _13080 = (int)*(((s1_ptr)_2)->base + _13079);
        if (IS_ATOM_INT(_13080)) {
            _13081 = _13080 - 1;
            if ((long)((unsigned long)_13081 +(unsigned long) HIGH_BITS) >= 0){
                _13081 = NewDouble((double)_13081);
            }
        }
        else {
            _13081 = binary_op(MINUS, _13080, 1);
        }
        _13080 = NOVALUE;
        _2 = (int)SEQ_PTR(_a_22478);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _a_22478 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _13079);
        _1 = *(int *)_2;
        *(int *)_2 = _13081;
        if( _1 != _13081 ){
            DeRef(_1);
        }
        _13081 = NOVALUE;
L3: 

        /** 		end for*/
        _i_22481 = _i_22481 + -1;
        goto L1; // [62] 17
L2: 
        ;
    }

    /** 		return a*/
    DeRef(_13079);
    _13079 = NOVALUE;
    return _a_22478;
    ;
}


int _62bits_to_bytes(int _bits_22493)
{
    int _bytes_22494 = NOVALUE;
    int _r_22495 = NOVALUE;
    int _13090 = NOVALUE;
    int _13089 = NOVALUE;
    int _13088 = NOVALUE;
    int _13087 = NOVALUE;
    int _13085 = NOVALUE;
    int _13084 = NOVALUE;
    int _13082 = NOVALUE;
    int _0, _1, _2;
    

    /** 		r = remainder( length(bits), 8 )*/
    if (IS_SEQUENCE(_bits_22493)){
            _13082 = SEQ_PTR(_bits_22493)->length;
    }
    else {
        _13082 = 1;
    }
    _r_22495 = (_13082 % 8);
    _13082 = NOVALUE;

    /** 		if r  then*/
    if (_r_22495 == 0)
    {
        goto L1; // [14] 32
    }
    else{
    }

    /** 				bits &= repeat( 0, 8 - r )*/
    _13084 = 8 - _r_22495;
    _13085 = Repeat(0, _13084);
    _13084 = NOVALUE;
    Concat((object_ptr)&_bits_22493, _bits_22493, _13085);
    DeRefDS(_13085);
    _13085 = NOVALUE;
L1: 

    /** 		bytes = {}*/
    RefDS(_5);
    DeRef(_bytes_22494);
    _bytes_22494 = _5;

    /** 		for i = 1 to length(bits) by 8 do*/
    if (IS_SEQUENCE(_bits_22493)){
            _13087 = SEQ_PTR(_bits_22493)->length;
    }
    else {
        _13087 = 1;
    }
    {
        int _i_22503;
        _i_22503 = 1;
L2: 
        if (_i_22503 > _13087){
            goto L3; // [44] 77
        }

        /** 				bytes &= bits_to_int( bits[i..i+7] )*/
        _13088 = _i_22503 + 7;
        rhs_slice_target = (object_ptr)&_13089;
        RHS_Slice(_bits_22493, _i_22503, _13088);
        _13090 = _15bits_to_int(_13089);
        _13089 = NOVALUE;
        if (IS_SEQUENCE(_bytes_22494) && IS_ATOM(_13090)) {
            Ref(_13090);
            Append(&_bytes_22494, _bytes_22494, _13090);
        }
        else if (IS_ATOM(_bytes_22494) && IS_SEQUENCE(_13090)) {
        }
        else {
            Concat((object_ptr)&_bytes_22494, _bytes_22494, _13090);
        }
        DeRef(_13090);
        _13090 = NOVALUE;

        /** 		end for*/
        _i_22503 = _i_22503 + 8;
        goto L2; // [72] 51
L3: 
        ;
    }

    /** 		return bytes*/
    DeRefDS(_bits_22493);
    DeRef(_13088);
    _13088 = NOVALUE;
    return _bytes_22494;
    ;
}


int _62bytes_to_bits(int _bytes_22512)
{
    int _bits_22513 = NOVALUE;
    int _13094 = NOVALUE;
    int _13093 = NOVALUE;
    int _13092 = NOVALUE;
    int _0, _1, _2;
    

    /** 		bits = {}*/
    RefDS(_5);
    DeRef(_bits_22513);
    _bits_22513 = _5;

    /** 		for i = 1 to length(bytes) do*/
    if (IS_SEQUENCE(_bytes_22512)){
            _13092 = SEQ_PTR(_bytes_22512)->length;
    }
    else {
        _13092 = 1;
    }
    {
        int _i_22515;
        _i_22515 = 1;
L1: 
        if (_i_22515 > _13092){
            goto L2; // [15] 44
        }

        /** 				bits &= int_to_bits( bytes[i], 8 )*/
        _2 = (int)SEQ_PTR(_bytes_22512);
        _13093 = (int)*(((s1_ptr)_2)->base + _i_22515);
        Ref(_13093);
        _13094 = _15int_to_bits(_13093, 8);
        _13093 = NOVALUE;
        if (IS_SEQUENCE(_bits_22513) && IS_ATOM(_13094)) {
            Ref(_13094);
            Append(&_bits_22513, _bits_22513, _13094);
        }
        else if (IS_ATOM(_bits_22513) && IS_SEQUENCE(_13094)) {
        }
        else {
            Concat((object_ptr)&_bits_22513, _bits_22513, _13094);
        }
        DeRef(_13094);
        _13094 = NOVALUE;

        /** 		end for*/
        _i_22515 = _i_22515 + 1;
        goto L1; // [39] 22
L2: 
        ;
    }

    /** 		return bits*/
    DeRefDS(_bytes_22512);
    return _bits_22513;
    ;
}


int _62convert_radix(int _number_22523, int _from_radix_22524, int _to_radix_22525)
{
    int _target_22526 = NOVALUE;
    int _base_22527 = NOVALUE;
    int _13101 = NOVALUE;
    int _13100 = NOVALUE;
    int _13099 = NOVALUE;
    int _13098 = NOVALUE;
    int _0, _1, _2;
    

    /** 		base = {1}*/
    RefDS(_13096);
    DeRef(_base_22527);
    _base_22527 = _13096;

    /** 		target = {0}*/
    _0 = _target_22526;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 0;
    _target_22526 = MAKE_SEQ(_1);
    DeRef(_0);

    /** 		for i = 1 to length(number) do*/
    if (IS_SEQUENCE(_number_22523)){
            _13098 = SEQ_PTR(_number_22523)->length;
    }
    else {
        _13098 = 1;
    }
    {
        int _i_22531;
        _i_22531 = 1;
L1: 
        if (_i_22531 > _13098){
            goto L2; // [25] 78
        }

        /** 				target = carry( add( base * number[i], target ), to_radix )*/
        _2 = (int)SEQ_PTR(_number_22523);
        _13099 = (int)*(((s1_ptr)_2)->base + _i_22531);
        _13100 = binary_op(MULTIPLY, _base_22527, _13099);
        _13099 = NOVALUE;
        RefDS(_target_22526);
        _13101 = _62add(_13100, _target_22526);
        _13100 = NOVALUE;
        _0 = _target_22526;
        _target_22526 = _62carry(_13101, _to_radix_22525);
        DeRefDS(_0);
        _13101 = NOVALUE;

        /** 				base *= from_radix*/
        _0 = _base_22527;
        _base_22527 = binary_op(MULTIPLY, _base_22527, _from_radix_22524);
        DeRefDS(_0);

        /** 				base = carry( base, to_radix )*/
        RefDS(_base_22527);
        _0 = _base_22527;
        _base_22527 = _62carry(_base_22527, _to_radix_22525);
        DeRefDS(_0);

        /** 		end for*/
        _i_22531 = _i_22531 + 1;
        goto L1; // [73] 32
L2: 
        ;
    }

    /** 		return target*/
    DeRefDS(_number_22523);
    DeRef(_base_22527);
    return _target_22526;
    ;
}


int _62half(int _decimal_22541)
{
    int _quotient_22542 = NOVALUE;
    int _q_22543 = NOVALUE;
    int _Q_22544 = NOVALUE;
    int _13122 = NOVALUE;
    int _13121 = NOVALUE;
    int _13120 = NOVALUE;
    int _13119 = NOVALUE;
    int _13118 = NOVALUE;
    int _13117 = NOVALUE;
    int _13114 = NOVALUE;
    int _13112 = NOVALUE;
    int _13111 = NOVALUE;
    int _13108 = NOVALUE;
    int _13107 = NOVALUE;
    int _13105 = NOVALUE;
    int _0, _1, _2;
    

    /** 		quotient = repeat( 0, length(decimal) )*/
    if (IS_SEQUENCE(_decimal_22541)){
            _13105 = SEQ_PTR(_decimal_22541)->length;
    }
    else {
        _13105 = 1;
    }
    DeRef(_quotient_22542);
    _quotient_22542 = Repeat(0, _13105);
    _13105 = NOVALUE;

    /** 		for i = 1 to length( decimal ) do*/
    if (IS_SEQUENCE(_decimal_22541)){
            _13107 = SEQ_PTR(_decimal_22541)->length;
    }
    else {
        _13107 = 1;
    }
    {
        int _i_22548;
        _i_22548 = 1;
L1: 
        if (_i_22548 > _13107){
            goto L2; // [17] 101
        }

        /** 				q = decimal[i] / 2*/
        _2 = (int)SEQ_PTR(_decimal_22541);
        _13108 = (int)*(((s1_ptr)_2)->base + _i_22548);
        DeRef(_q_22543);
        if (IS_ATOM_INT(_13108)) {
            if (_13108 & 1) {
                _q_22543 = NewDouble((_13108 >> 1) + 0.5);
            }
            else
            _q_22543 = _13108 >> 1;
        }
        else {
            _q_22543 = binary_op(DIVIDE, _13108, 2);
        }
        _13108 = NOVALUE;

        /** 				Q = floor( q )*/
        DeRef(_Q_22544);
        if (IS_ATOM_INT(_q_22543))
        _Q_22544 = e_floor(_q_22543);
        else
        _Q_22544 = unary_op(FLOOR, _q_22543);

        /** 				quotient[i] +=  Q*/
        _2 = (int)SEQ_PTR(_quotient_22542);
        _13111 = (int)*(((s1_ptr)_2)->base + _i_22548);
        if (IS_ATOM_INT(_13111) && IS_ATOM_INT(_Q_22544)) {
            _13112 = _13111 + _Q_22544;
            if ((long)((unsigned long)_13112 + (unsigned long)HIGH_BITS) >= 0) 
            _13112 = NewDouble((double)_13112);
        }
        else {
            _13112 = binary_op(PLUS, _13111, _Q_22544);
        }
        _13111 = NOVALUE;
        _2 = (int)SEQ_PTR(_quotient_22542);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _quotient_22542 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_22548);
        _1 = *(int *)_2;
        *(int *)_2 = _13112;
        if( _1 != _13112 ){
            DeRef(_1);
        }
        _13112 = NOVALUE;

        /** 				if q != Q then*/
        if (binary_op_a(EQUALS, _q_22543, _Q_22544)){
            goto L3; // [55] 94
        }

        /** 						if length(quotient) = i then*/
        if (IS_SEQUENCE(_quotient_22542)){
                _13114 = SEQ_PTR(_quotient_22542)->length;
        }
        else {
            _13114 = 1;
        }
        if (_13114 != _i_22548)
        goto L4; // [64] 75

        /** 								quotient &= 0*/
        Append(&_quotient_22542, _quotient_22542, 0);
L4: 

        /** 						quotient[i+1] += 5*/
        _13117 = _i_22548 + 1;
        _2 = (int)SEQ_PTR(_quotient_22542);
        _13118 = (int)*(((s1_ptr)_2)->base + _13117);
        if (IS_ATOM_INT(_13118)) {
            _13119 = _13118 + 5;
            if ((long)((unsigned long)_13119 + (unsigned long)HIGH_BITS) >= 0) 
            _13119 = NewDouble((double)_13119);
        }
        else {
            _13119 = binary_op(PLUS, _13118, 5);
        }
        _13118 = NOVALUE;
        _2 = (int)SEQ_PTR(_quotient_22542);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _quotient_22542 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _13117);
        _1 = *(int *)_2;
        *(int *)_2 = _13119;
        if( _1 != _13119 ){
            DeRef(_1);
        }
        _13119 = NOVALUE;
L3: 

        /** 		end for*/
        _i_22548 = _i_22548 + 1;
        goto L1; // [96] 24
L2: 
        ;
    }

    /** 		return reverse( carry( reverse( quotient ), 10 ) )*/
    RefDS(_quotient_22542);
    _13120 = _62reverse(_quotient_22542);
    _13121 = _62carry(_13120, 10);
    _13120 = NOVALUE;
    _13122 = _62reverse(_13121);
    _13121 = NOVALUE;
    DeRefDS(_decimal_22541);
    DeRefDS(_quotient_22542);
    DeRef(_q_22543);
    DeRef(_Q_22544);
    DeRef(_13117);
    _13117 = NOVALUE;
    return _13122;
    ;
}


int _62decimals_to_bits(int _decimals_22577)
{
    int _sub_22578 = NOVALUE;
    int _bits_22579 = NOVALUE;
    int _bit_22580 = NOVALUE;
    int _assigned_22581 = NOVALUE;
    int _13149 = NOVALUE;
    int _13145 = NOVALUE;
    int _13144 = NOVALUE;
    int _13143 = NOVALUE;
    int _13142 = NOVALUE;
    int _13140 = NOVALUE;
    int _13139 = NOVALUE;
    int _13138 = NOVALUE;
    int _13136 = NOVALUE;
    int _13134 = NOVALUE;
    int _13133 = NOVALUE;
    int _13132 = NOVALUE;
    int _13131 = NOVALUE;
    int _13129 = NOVALUE;
    int _13127 = NOVALUE;
    int _0, _1, _2;
    

    /** 		sub = {5}*/
    RefDS(_13125);
    DeRef(_sub_22578);
    _sub_22578 = _13125;

    /** 		bits = repeat( 0, 53 )*/
    DeRef(_bits_22579);
    _bits_22579 = Repeat(0, 53);

    /** 		bit = 1*/
    _bit_22580 = 1;

    /** 		assigned = 0*/
    _assigned_22581 = 0;

    /** 		if compare(decimals, bits) > 0 then */
    if (IS_ATOM_INT(_decimals_22577) && IS_ATOM_INT(_bits_22579)){
        _13127 = (_decimals_22577 < _bits_22579) ? -1 : (_decimals_22577 > _bits_22579);
    }
    else{
        _13127 = compare(_decimals_22577, _bits_22579);
    }
    if (_13127 <= 0)
    goto L1; // [32] 160

    /** 			while (not assigned) or (bit < find( 1, bits ) + 54)  do*/
L2: 
    _13129 = (_assigned_22581 == 0);
    if (_13129 != 0) {
        goto L3; // [44] 66
    }
    _13131 = find_from(1, _bits_22579, 1);
    _13132 = _13131 + 54;
    _13131 = NOVALUE;
    _13133 = (_bit_22580 < _13132);
    _13132 = NOVALUE;
    if (_13133 == 0)
    {
        DeRef(_13133);
        _13133 = NOVALUE;
        goto L4; // [62] 159
    }
    else{
        DeRef(_13133);
        _13133 = NOVALUE;
    }
L3: 

    /** 				if compare( sub, decimals ) <= 0 then*/
    if (IS_ATOM_INT(_sub_22578) && IS_ATOM_INT(_decimals_22577)){
        _13134 = (_sub_22578 < _decimals_22577) ? -1 : (_sub_22578 > _decimals_22577);
    }
    else{
        _13134 = compare(_sub_22578, _decimals_22577);
    }
    if (_13134 > 0)
    goto L5; // [72] 140

    /** 						assigned = 1*/
    _assigned_22581 = 1;

    /** 						if length( bits ) < bit then*/
    if (IS_SEQUENCE(_bits_22579)){
            _13136 = SEQ_PTR(_bits_22579)->length;
    }
    else {
        _13136 = 1;
    }
    if (_13136 >= _bit_22580)
    goto L6; // [86] 108

    /** 								bits &= repeat( 0, bit - length(bits)) */
    if (IS_SEQUENCE(_bits_22579)){
            _13138 = SEQ_PTR(_bits_22579)->length;
    }
    else {
        _13138 = 1;
    }
    _13139 = _bit_22580 - _13138;
    _13138 = NOVALUE;
    _13140 = Repeat(0, _13139);
    _13139 = NOVALUE;
    Concat((object_ptr)&_bits_22579, _bits_22579, _13140);
    DeRefDS(_13140);
    _13140 = NOVALUE;
L6: 

    /** 						bits[bit] += 1*/
    _2 = (int)SEQ_PTR(_bits_22579);
    _13142 = (int)*(((s1_ptr)_2)->base + _bit_22580);
    if (IS_ATOM_INT(_13142)) {
        _13143 = _13142 + 1;
        if (_13143 > MAXINT){
            _13143 = NewDouble((double)_13143);
        }
    }
    else
    _13143 = binary_op(PLUS, 1, _13142);
    _13142 = NOVALUE;
    _2 = (int)SEQ_PTR(_bits_22579);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _bits_22579 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _bit_22580);
    _1 = *(int *)_2;
    *(int *)_2 = _13143;
    if( _1 != _13143 ){
        DeRef(_1);
    }
    _13143 = NOVALUE;

    /** 						decimals = borrow( add( decimals, -sub ), 10 )*/
    _13144 = unary_op(UMINUS, _sub_22578);
    RefDS(_decimals_22577);
    _13145 = _62add(_decimals_22577, _13144);
    _13144 = NOVALUE;
    _0 = _decimals_22577;
    _decimals_22577 = _62borrow(_13145, 10);
    DeRefDS(_0);
    _13145 = NOVALUE;
L5: 

    /** 				sub = half( sub )*/
    RefDS(_sub_22578);
    _0 = _sub_22578;
    _sub_22578 = _62half(_sub_22578);
    DeRefDS(_0);

    /** 				bit += 1*/
    _bit_22580 = _bit_22580 + 1;

    /** 			end while*/
    goto L2; // [156] 41
L4: 
L1: 

    /** 		return reverse(bits)*/
    RefDS(_bits_22579);
    _13149 = _62reverse(_bits_22579);
    DeRefDS(_decimals_22577);
    DeRef(_sub_22578);
    DeRefDS(_bits_22579);
    DeRef(_13129);
    _13129 = NOVALUE;
    return _13149;
    ;
}


int _62string_to_int(int _s_22613)
{
    int _int_22614 = NOVALUE;
    int _13153 = NOVALUE;
    int _13152 = NOVALUE;
    int _13150 = NOVALUE;
    int _0, _1, _2;
    

    /** 		int = 0*/
    _int_22614 = 0;

    /** 		for i = 1 to length(s) do*/
    if (IS_SEQUENCE(_s_22613)){
            _13150 = SEQ_PTR(_s_22613)->length;
    }
    else {
        _13150 = 1;
    }
    {
        int _i_22616;
        _i_22616 = 1;
L1: 
        if (_i_22616 > _13150){
            goto L2; // [13] 51
        }

        /** 				int *= 10*/
        _int_22614 = _int_22614 * 10;

        /** 				int += s[i] - '0'*/
        _2 = (int)SEQ_PTR(_s_22613);
        _13152 = (int)*(((s1_ptr)_2)->base + _i_22616);
        if (IS_ATOM_INT(_13152)) {
            _13153 = _13152 - 48;
            if ((long)((unsigned long)_13153 +(unsigned long) HIGH_BITS) >= 0){
                _13153 = NewDouble((double)_13153);
            }
        }
        else {
            _13153 = binary_op(MINUS, _13152, 48);
        }
        _13152 = NOVALUE;
        if (IS_ATOM_INT(_13153)) {
            _int_22614 = _int_22614 + _13153;
        }
        else {
            _int_22614 = binary_op(PLUS, _int_22614, _13153);
        }
        DeRef(_13153);
        _13153 = NOVALUE;
        if (!IS_ATOM_INT(_int_22614)) {
            _1 = (long)(DBL_PTR(_int_22614)->dbl);
            DeRefDS(_int_22614);
            _int_22614 = _1;
        }

        /** 		end for*/
        _i_22616 = _i_22616 + 1;
        goto L1; // [46] 20
L2: 
        ;
    }

    /** 		return int*/
    DeRefDS(_s_22613);
    return _int_22614;
    ;
}


int _62trim_bits(int _bits_22624)
{
    int _13161 = NOVALUE;
    int _13160 = NOVALUE;
    int _13159 = NOVALUE;
    int _13158 = NOVALUE;
    int _13157 = NOVALUE;
    int _13156 = NOVALUE;
    int _13155 = NOVALUE;
    int _0, _1, _2;
    

    /** 		while length(bits) and not bits[$] do*/
L1: 
    if (IS_SEQUENCE(_bits_22624)){
            _13155 = SEQ_PTR(_bits_22624)->length;
    }
    else {
        _13155 = 1;
    }
    if (_13155 == 0) {
        goto L2; // [11] 48
    }
    if (IS_SEQUENCE(_bits_22624)){
            _13157 = SEQ_PTR(_bits_22624)->length;
    }
    else {
        _13157 = 1;
    }
    _2 = (int)SEQ_PTR(_bits_22624);
    _13158 = (int)*(((s1_ptr)_2)->base + _13157);
    if (IS_ATOM_INT(_13158)) {
        _13159 = (_13158 == 0);
    }
    else {
        _13159 = unary_op(NOT, _13158);
    }
    _13158 = NOVALUE;
    if (_13159 <= 0) {
        if (_13159 == 0) {
            DeRef(_13159);
            _13159 = NOVALUE;
            goto L2; // [26] 48
        }
        else {
            if (!IS_ATOM_INT(_13159) && DBL_PTR(_13159)->dbl == 0.0){
                DeRef(_13159);
                _13159 = NOVALUE;
                goto L2; // [26] 48
            }
            DeRef(_13159);
            _13159 = NOVALUE;
        }
    }
    DeRef(_13159);
    _13159 = NOVALUE;

    /** 				bits = bits[1..$-1]*/
    if (IS_SEQUENCE(_bits_22624)){
            _13160 = SEQ_PTR(_bits_22624)->length;
    }
    else {
        _13160 = 1;
    }
    _13161 = _13160 - 1;
    _13160 = NOVALUE;
    rhs_slice_target = (object_ptr)&_bits_22624;
    RHS_Slice(_bits_22624, 1, _13161);

    /** 		end while*/
    goto L1; // [45] 8
L2: 

    /** 		return bits*/
    DeRef(_13161);
    _13161 = NOVALUE;
    return _bits_22624;
    ;
}


int _62scientific_to_float64(int _s_22636)
{
    int _dp_22637 = NOVALUE;
    int _e_22638 = NOVALUE;
    int _exp_22639 = NOVALUE;
    int _int_bits_22640 = NOVALUE;
    int _frac_bits_22641 = NOVALUE;
    int _mbits_22642 = NOVALUE;
    int _ebits_22643 = NOVALUE;
    int _sbits_22644 = NOVALUE;
    int _13305 = NOVALUE;
    int _13304 = NOVALUE;
    int _13302 = NOVALUE;
    int _13300 = NOVALUE;
    int _13299 = NOVALUE;
    int _13298 = NOVALUE;
    int _13296 = NOVALUE;
    int _13295 = NOVALUE;
    int _13294 = NOVALUE;
    int _13293 = NOVALUE;
    int _13292 = NOVALUE;
    int _13291 = NOVALUE;
    int _13290 = NOVALUE;
    int _13288 = NOVALUE;
    int _13287 = NOVALUE;
    int _13286 = NOVALUE;
    int _13285 = NOVALUE;
    int _13283 = NOVALUE;
    int _13282 = NOVALUE;
    int _13281 = NOVALUE;
    int _13280 = NOVALUE;
    int _13279 = NOVALUE;
    int _13278 = NOVALUE;
    int _13277 = NOVALUE;
    int _13274 = NOVALUE;
    int _13271 = NOVALUE;
    int _13270 = NOVALUE;
    int _13269 = NOVALUE;
    int _13264 = NOVALUE;
    int _13263 = NOVALUE;
    int _13261 = NOVALUE;
    int _13260 = NOVALUE;
    int _13258 = NOVALUE;
    int _13256 = NOVALUE;
    int _13255 = NOVALUE;
    int _13254 = NOVALUE;
    int _13253 = NOVALUE;
    int _13252 = NOVALUE;
    int _13251 = NOVALUE;
    int _13250 = NOVALUE;
    int _13249 = NOVALUE;
    int _13247 = NOVALUE;
    int _13246 = NOVALUE;
    int _13245 = NOVALUE;
    int _13244 = NOVALUE;
    int _13242 = NOVALUE;
    int _13240 = NOVALUE;
    int _13239 = NOVALUE;
    int _13238 = NOVALUE;
    int _13237 = NOVALUE;
    int _13236 = NOVALUE;
    int _13234 = NOVALUE;
    int _13233 = NOVALUE;
    int _13232 = NOVALUE;
    int _13231 = NOVALUE;
    int _13230 = NOVALUE;
    int _13229 = NOVALUE;
    int _13227 = NOVALUE;
    int _13226 = NOVALUE;
    int _13225 = NOVALUE;
    int _13224 = NOVALUE;
    int _13223 = NOVALUE;
    int _13221 = NOVALUE;
    int _13220 = NOVALUE;
    int _13218 = NOVALUE;
    int _13217 = NOVALUE;
    int _13216 = NOVALUE;
    int _13215 = NOVALUE;
    int _13214 = NOVALUE;
    int _13212 = NOVALUE;
    int _13210 = NOVALUE;
    int _13209 = NOVALUE;
    int _13207 = NOVALUE;
    int _13206 = NOVALUE;
    int _13204 = NOVALUE;
    int _13201 = NOVALUE;
    int _13200 = NOVALUE;
    int _13199 = NOVALUE;
    int _13198 = NOVALUE;
    int _13197 = NOVALUE;
    int _13195 = NOVALUE;
    int _13194 = NOVALUE;
    int _13193 = NOVALUE;
    int _13192 = NOVALUE;
    int _13190 = NOVALUE;
    int _13189 = NOVALUE;
    int _13188 = NOVALUE;
    int _13187 = NOVALUE;
    int _13185 = NOVALUE;
    int _13184 = NOVALUE;
    int _13182 = NOVALUE;
    int _13181 = NOVALUE;
    int _13180 = NOVALUE;
    int _13179 = NOVALUE;
    int _13177 = NOVALUE;
    int _13176 = NOVALUE;
    int _13170 = NOVALUE;
    int _13168 = NOVALUE;
    int _13165 = NOVALUE;
    int _13163 = NOVALUE;
    int _0, _1, _2;
    

    /** 		if s[1] = '-' then*/
    _2 = (int)SEQ_PTR(_s_22636);
    _13163 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _13163, 45)){
        _13163 = NOVALUE;
        goto L1; // [9] 33
    }
    _13163 = NOVALUE;

    /** 				sbits = {1}*/
    RefDS(_13096);
    DeRefi(_sbits_22644);
    _sbits_22644 = _13096;

    /** 				s = s[2..$]*/
    if (IS_SEQUENCE(_s_22636)){
            _13165 = SEQ_PTR(_s_22636)->length;
    }
    else {
        _13165 = 1;
    }
    rhs_slice_target = (object_ptr)&_s_22636;
    RHS_Slice(_s_22636, 2, _13165);
    goto L2; // [30] 61
L1: 

    /** 				sbits = {0}*/
    _0 = _sbits_22644;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 0;
    _sbits_22644 = MAKE_SEQ(_1);
    DeRefi(_0);

    /** 				if s[1] = '+' then*/
    _2 = (int)SEQ_PTR(_s_22636);
    _13168 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _13168, 43)){
        _13168 = NOVALUE;
        goto L3; // [45] 60
    }
    _13168 = NOVALUE;

    /** 						s = s[2..$]*/
    if (IS_SEQUENCE(_s_22636)){
            _13170 = SEQ_PTR(_s_22636)->length;
    }
    else {
        _13170 = 1;
    }
    rhs_slice_target = (object_ptr)&_s_22636;
    RHS_Slice(_s_22636, 2, _13170);
L3: 
L2: 

    /** 		dp = find('.', s)*/
    _dp_22637 = find_from(46, _s_22636, 1);

    /** 		e = find( 'e', s )*/
    _e_22638 = find_from(101, _s_22636, 1);

    /** 		if not e then*/
    if (_e_22638 != 0)
    goto L4; // [77] 88

    /** 				e = find('E', s )*/
    _e_22638 = find_from(69, _s_22636, 1);
L4: 

    /** 		exp = 0*/
    _exp_22639 = 0;

    /** 		if s[e+1] = '-' then*/
    _13176 = _e_22638 + 1;
    _2 = (int)SEQ_PTR(_s_22636);
    _13177 = (int)*(((s1_ptr)_2)->base + _13176);
    if (binary_op_a(NOTEQ, _13177, 45)){
        _13177 = NOVALUE;
        goto L5; // [103] 134
    }
    _13177 = NOVALUE;

    /** 				exp -= string_to_int( s[e+2..$] )*/
    _13179 = _e_22638 + 2;
    if ((long)((unsigned long)_13179 + (unsigned long)HIGH_BITS) >= 0) 
    _13179 = NewDouble((double)_13179);
    if (IS_SEQUENCE(_s_22636)){
            _13180 = SEQ_PTR(_s_22636)->length;
    }
    else {
        _13180 = 1;
    }
    rhs_slice_target = (object_ptr)&_13181;
    RHS_Slice(_s_22636, _13179, _13180);
    _13182 = _62string_to_int(_13181);
    _13181 = NOVALUE;
    if (IS_ATOM_INT(_13182)) {
        _exp_22639 = _exp_22639 - _13182;
    }
    else {
        _exp_22639 = binary_op(MINUS, _exp_22639, _13182);
    }
    DeRef(_13182);
    _13182 = NOVALUE;
    if (!IS_ATOM_INT(_exp_22639)) {
        _1 = (long)(DBL_PTR(_exp_22639)->dbl);
        DeRefDS(_exp_22639);
        _exp_22639 = _1;
    }
    goto L6; // [131] 201
L5: 

    /** 				if s[e+1] = '+' then*/
    _13184 = _e_22638 + 1;
    _2 = (int)SEQ_PTR(_s_22636);
    _13185 = (int)*(((s1_ptr)_2)->base + _13184);
    if (binary_op_a(NOTEQ, _13185, 43)){
        _13185 = NOVALUE;
        goto L7; // [144] 175
    }
    _13185 = NOVALUE;

    /** 						exp += string_to_int( s[e+2..$] )*/
    _13187 = _e_22638 + 2;
    if ((long)((unsigned long)_13187 + (unsigned long)HIGH_BITS) >= 0) 
    _13187 = NewDouble((double)_13187);
    if (IS_SEQUENCE(_s_22636)){
            _13188 = SEQ_PTR(_s_22636)->length;
    }
    else {
        _13188 = 1;
    }
    rhs_slice_target = (object_ptr)&_13189;
    RHS_Slice(_s_22636, _13187, _13188);
    _13190 = _62string_to_int(_13189);
    _13189 = NOVALUE;
    if (IS_ATOM_INT(_13190)) {
        _exp_22639 = _exp_22639 + _13190;
    }
    else {
        _exp_22639 = binary_op(PLUS, _exp_22639, _13190);
    }
    DeRef(_13190);
    _13190 = NOVALUE;
    if (!IS_ATOM_INT(_exp_22639)) {
        _1 = (long)(DBL_PTR(_exp_22639)->dbl);
        DeRefDS(_exp_22639);
        _exp_22639 = _1;
    }
    goto L8; // [172] 200
L7: 

    /** 						exp += string_to_int( s[e+1..$] )*/
    _13192 = _e_22638 + 1;
    if (_13192 > MAXINT){
        _13192 = NewDouble((double)_13192);
    }
    if (IS_SEQUENCE(_s_22636)){
            _13193 = SEQ_PTR(_s_22636)->length;
    }
    else {
        _13193 = 1;
    }
    rhs_slice_target = (object_ptr)&_13194;
    RHS_Slice(_s_22636, _13192, _13193);
    _13195 = _62string_to_int(_13194);
    _13194 = NOVALUE;
    if (IS_ATOM_INT(_13195)) {
        _exp_22639 = _exp_22639 + _13195;
    }
    else {
        _exp_22639 = binary_op(PLUS, _exp_22639, _13195);
    }
    DeRef(_13195);
    _13195 = NOVALUE;
    if (!IS_ATOM_INT(_exp_22639)) {
        _1 = (long)(DBL_PTR(_exp_22639)->dbl);
        DeRefDS(_exp_22639);
        _exp_22639 = _1;
    }
L8: 
L6: 

    /** 		if dp then*/
    if (_dp_22637 == 0)
    {
        goto L9; // [203] 252
    }
    else{
    }

    /** 				s = s[1..dp-1] & s[dp+1..$]*/
    _13197 = _dp_22637 - 1;
    rhs_slice_target = (object_ptr)&_13198;
    RHS_Slice(_s_22636, 1, _13197);
    _13199 = _dp_22637 + 1;
    if (_13199 > MAXINT){
        _13199 = NewDouble((double)_13199);
    }
    if (IS_SEQUENCE(_s_22636)){
            _13200 = SEQ_PTR(_s_22636)->length;
    }
    else {
        _13200 = 1;
    }
    rhs_slice_target = (object_ptr)&_13201;
    RHS_Slice(_s_22636, _13199, _13200);
    Concat((object_ptr)&_s_22636, _13198, _13201);
    DeRefDS(_13198);
    _13198 = NOVALUE;
    DeRef(_13198);
    _13198 = NOVALUE;
    DeRefDS(_13201);
    _13201 = NOVALUE;

    /** 				e -= 1*/
    _e_22638 = _e_22638 - 1;

    /** 				exp -= e - dp*/
    _13204 = _e_22638 - _dp_22637;
    if ((long)((unsigned long)_13204 +(unsigned long) HIGH_BITS) >= 0){
        _13204 = NewDouble((double)_13204);
    }
    if (IS_ATOM_INT(_13204)) {
        _exp_22639 = _exp_22639 - _13204;
    }
    else {
        _exp_22639 = NewDouble((double)_exp_22639 - DBL_PTR(_13204)->dbl);
    }
    DeRef(_13204);
    _13204 = NOVALUE;
    if (!IS_ATOM_INT(_exp_22639)) {
        _1 = (long)(DBL_PTR(_exp_22639)->dbl);
        DeRefDS(_exp_22639);
        _exp_22639 = _1;
    }
L9: 

    /** 		s = s[1..e-1] - '0'*/
    _13206 = _e_22638 - 1;
    rhs_slice_target = (object_ptr)&_13207;
    RHS_Slice(_s_22636, 1, _13206);
    DeRefDS(_s_22636);
    _s_22636 = binary_op(MINUS, _13207, 48);
    DeRefDS(_13207);
    _13207 = NOVALUE;

    /** 		if not find(0, s = 0) then*/
    _13209 = binary_op(EQUALS, _s_22636, 0);
    _13210 = find_from(0, _13209, 1);
    DeRefDS(_13209);
    _13209 = NOVALUE;
    if (_13210 != 0)
    goto LA; // [280] 294
    _13210 = NOVALUE;

    /** 			return atom_to_float64(0)*/
    _13212 = _15atom_to_float64(0);
    DeRefDS(_s_22636);
    DeRef(_int_bits_22640);
    DeRef(_frac_bits_22641);
    DeRef(_mbits_22642);
    DeRef(_ebits_22643);
    DeRefi(_sbits_22644);
    DeRef(_13176);
    _13176 = NOVALUE;
    DeRef(_13179);
    _13179 = NOVALUE;
    DeRef(_13184);
    _13184 = NOVALUE;
    DeRef(_13187);
    _13187 = NOVALUE;
    DeRef(_13192);
    _13192 = NOVALUE;
    DeRef(_13197);
    _13197 = NOVALUE;
    _13206 = NOVALUE;
    DeRef(_13199);
    _13199 = NOVALUE;
    return _13212;
LA: 

    /** 		if exp >= 0 then*/
    if (_exp_22639 < 0)
    goto LB; // [296] 340

    /** 				int_bits = trim_bits( bytes_to_bits( convert_radix( repeat( 0, exp ) & reverse( s ), 10, #100 ) ) )*/
    _13214 = Repeat(0, _exp_22639);
    RefDS(_s_22636);
    _13215 = _62reverse(_s_22636);
    if (IS_SEQUENCE(_13214) && IS_ATOM(_13215)) {
        Ref(_13215);
        Append(&_13216, _13214, _13215);
    }
    else if (IS_ATOM(_13214) && IS_SEQUENCE(_13215)) {
    }
    else {
        Concat((object_ptr)&_13216, _13214, _13215);
        DeRefDS(_13214);
        _13214 = NOVALUE;
    }
    DeRef(_13214);
    _13214 = NOVALUE;
    DeRef(_13215);
    _13215 = NOVALUE;
    _13217 = _62convert_radix(_13216, 10, 256);
    _13216 = NOVALUE;
    _13218 = _62bytes_to_bits(_13217);
    _13217 = NOVALUE;
    _0 = _int_bits_22640;
    _int_bits_22640 = _62trim_bits(_13218);
    DeRef(_0);
    _13218 = NOVALUE;

    /** 				frac_bits = {}*/
    RefDS(_5);
    DeRef(_frac_bits_22641);
    _frac_bits_22641 = _5;
    goto LC; // [337] 451
LB: 

    /** 				if -exp > length(s) then*/
    if ((unsigned long)_exp_22639 == 0xC0000000)
    _13220 = (int)NewDouble((double)-0xC0000000);
    else
    _13220 = - _exp_22639;
    if (IS_SEQUENCE(_s_22636)){
            _13221 = SEQ_PTR(_s_22636)->length;
    }
    else {
        _13221 = 1;
    }
    if (binary_op_a(LESSEQ, _13220, _13221)){
        DeRef(_13220);
        _13220 = NOVALUE;
        _13221 = NOVALUE;
        goto LD; // [348] 388
    }
    DeRef(_13220);
    _13220 = NOVALUE;
    _13221 = NOVALUE;

    /** 						int_bits = {}*/
    RefDS(_5);
    DeRef(_int_bits_22640);
    _int_bits_22640 = _5;

    /** 						frac_bits = decimals_to_bits( repeat( 0, -exp-length(s) ) & s ) */
    if ((unsigned long)_exp_22639 == 0xC0000000)
    _13223 = (int)NewDouble((double)-0xC0000000);
    else
    _13223 = - _exp_22639;
    if (IS_SEQUENCE(_s_22636)){
            _13224 = SEQ_PTR(_s_22636)->length;
    }
    else {
        _13224 = 1;
    }
    if (IS_ATOM_INT(_13223)) {
        _13225 = _13223 - _13224;
    }
    else {
        _13225 = NewDouble(DBL_PTR(_13223)->dbl - (double)_13224);
    }
    DeRef(_13223);
    _13223 = NOVALUE;
    _13224 = NOVALUE;
    _13226 = Repeat(0, _13225);
    DeRef(_13225);
    _13225 = NOVALUE;
    Concat((object_ptr)&_13227, _13226, _s_22636);
    DeRefDS(_13226);
    _13226 = NOVALUE;
    DeRef(_13226);
    _13226 = NOVALUE;
    _0 = _frac_bits_22641;
    _frac_bits_22641 = _62decimals_to_bits(_13227);
    DeRef(_0);
    _13227 = NOVALUE;
    goto LE; // [385] 450
LD: 

    /** 						int_bits = trim_bits( bytes_to_bits( convert_radix( reverse( s[1..$+exp] ), 10, #100 ) ) )*/
    if (IS_SEQUENCE(_s_22636)){
            _13229 = SEQ_PTR(_s_22636)->length;
    }
    else {
        _13229 = 1;
    }
    _13230 = _13229 + _exp_22639;
    _13229 = NOVALUE;
    rhs_slice_target = (object_ptr)&_13231;
    RHS_Slice(_s_22636, 1, _13230);
    _13232 = _62reverse(_13231);
    _13231 = NOVALUE;
    _13233 = _62convert_radix(_13232, 10, 256);
    _13232 = NOVALUE;
    _13234 = _62bytes_to_bits(_13233);
    _13233 = NOVALUE;
    _0 = _int_bits_22640;
    _int_bits_22640 = _62trim_bits(_13234);
    DeRef(_0);
    _13234 = NOVALUE;

    /** 						frac_bits =  decimals_to_bits( s[$+exp+1..$] )*/
    if (IS_SEQUENCE(_s_22636)){
            _13236 = SEQ_PTR(_s_22636)->length;
    }
    else {
        _13236 = 1;
    }
    _13237 = _13236 + _exp_22639;
    if ((long)((unsigned long)_13237 + (unsigned long)HIGH_BITS) >= 0) 
    _13237 = NewDouble((double)_13237);
    _13236 = NOVALUE;
    if (IS_ATOM_INT(_13237)) {
        _13238 = _13237 + 1;
        if (_13238 > MAXINT){
            _13238 = NewDouble((double)_13238);
        }
    }
    else
    _13238 = binary_op(PLUS, 1, _13237);
    DeRef(_13237);
    _13237 = NOVALUE;
    if (IS_SEQUENCE(_s_22636)){
            _13239 = SEQ_PTR(_s_22636)->length;
    }
    else {
        _13239 = 1;
    }
    rhs_slice_target = (object_ptr)&_13240;
    RHS_Slice(_s_22636, _13238, _13239);
    _0 = _frac_bits_22641;
    _frac_bits_22641 = _62decimals_to_bits(_13240);
    DeRef(_0);
    _13240 = NOVALUE;
LE: 
LC: 

    /** 		if length(int_bits) >= 53 then*/
    if (IS_SEQUENCE(_int_bits_22640)){
            _13242 = SEQ_PTR(_int_bits_22640)->length;
    }
    else {
        _13242 = 1;
    }
    if (_13242 < 53)
    goto LF; // [458] 547

    /** 				mbits = int_bits[$-52..$-1]*/
    if (IS_SEQUENCE(_int_bits_22640)){
            _13244 = SEQ_PTR(_int_bits_22640)->length;
    }
    else {
        _13244 = 1;
    }
    _13245 = _13244 - 52;
    _13244 = NOVALUE;
    if (IS_SEQUENCE(_int_bits_22640)){
            _13246 = SEQ_PTR(_int_bits_22640)->length;
    }
    else {
        _13246 = 1;
    }
    _13247 = _13246 - 1;
    _13246 = NOVALUE;
    rhs_slice_target = (object_ptr)&_mbits_22642;
    RHS_Slice(_int_bits_22640, _13245, _13247);

    /** 				if length(int_bits) > 53 and int_bits[$-53] then*/
    if (IS_SEQUENCE(_int_bits_22640)){
            _13249 = SEQ_PTR(_int_bits_22640)->length;
    }
    else {
        _13249 = 1;
    }
    _13250 = (_13249 > 53);
    _13249 = NOVALUE;
    if (_13250 == 0) {
        goto L10; // [492] 535
    }
    if (IS_SEQUENCE(_int_bits_22640)){
            _13252 = SEQ_PTR(_int_bits_22640)->length;
    }
    else {
        _13252 = 1;
    }
    _13253 = _13252 - 53;
    _13252 = NOVALUE;
    _2 = (int)SEQ_PTR(_int_bits_22640);
    _13254 = (int)*(((s1_ptr)_2)->base + _13253);
    if (_13254 == 0) {
        _13254 = NOVALUE;
        goto L10; // [508] 535
    }
    else {
        if (!IS_ATOM_INT(_13254) && DBL_PTR(_13254)->dbl == 0.0){
            _13254 = NOVALUE;
            goto L10; // [508] 535
        }
        _13254 = NOVALUE;
    }
    _13254 = NOVALUE;

    /** 						mbits[1] += 1*/
    _2 = (int)SEQ_PTR(_mbits_22642);
    _13255 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_13255)) {
        _13256 = _13255 + 1;
        if (_13256 > MAXINT){
            _13256 = NewDouble((double)_13256);
        }
    }
    else
    _13256 = binary_op(PLUS, 1, _13255);
    _13255 = NOVALUE;
    _2 = (int)SEQ_PTR(_mbits_22642);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _mbits_22642 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _13256;
    if( _1 != _13256 ){
        DeRef(_1);
    }
    _13256 = NOVALUE;

    /** 						mbits = carry( mbits, 2 )*/
    RefDS(_mbits_22642);
    _0 = _mbits_22642;
    _mbits_22642 = _62carry(_mbits_22642, 2);
    DeRefDS(_0);
L10: 

    /** 				exp = length(int_bits)-1*/
    if (IS_SEQUENCE(_int_bits_22640)){
            _13258 = SEQ_PTR(_int_bits_22640)->length;
    }
    else {
        _13258 = 1;
    }
    _exp_22639 = _13258 - 1;
    _13258 = NOVALUE;
    goto L11; // [544] 783
LF: 

    /** 				if length(int_bits) then*/
    if (IS_SEQUENCE(_int_bits_22640)){
            _13260 = SEQ_PTR(_int_bits_22640)->length;
    }
    else {
        _13260 = 1;
    }
    if (_13260 == 0)
    {
        _13260 = NOVALUE;
        goto L12; // [552] 567
    }
    else{
        _13260 = NOVALUE;
    }

    /** 						exp = length(int_bits)-1*/
    if (IS_SEQUENCE(_int_bits_22640)){
            _13261 = SEQ_PTR(_int_bits_22640)->length;
    }
    else {
        _13261 = 1;
    }
    _exp_22639 = _13261 - 1;
    _13261 = NOVALUE;
    goto L13; // [564] 622
L12: 

    /** 						exp = - find( 1, reverse( frac_bits ) )*/
    RefDS(_frac_bits_22641);
    _13263 = _62reverse(_frac_bits_22641);
    _13264 = find_from(1, _13263, 1);
    DeRef(_13263);
    _13263 = NOVALUE;
    _exp_22639 = - _13264;

    /** 						if exp < -1023 then*/
    if (_exp_22639 >= -1023)
    goto L14; // [587] 597

    /** 								exp = -1023*/
    _exp_22639 = -1023;
L14: 

    /** 						if exp then*/
    if (_exp_22639 == 0)
    {
        goto L15; // [599] 621
    }
    else{
    }

    /** 								frac_bits = frac_bits[1..$+exp+1]*/
    if (IS_SEQUENCE(_frac_bits_22641)){
            _13269 = SEQ_PTR(_frac_bits_22641)->length;
    }
    else {
        _13269 = 1;
    }
    _13270 = _13269 + _exp_22639;
    if ((long)((unsigned long)_13270 + (unsigned long)HIGH_BITS) >= 0) 
    _13270 = NewDouble((double)_13270);
    _13269 = NOVALUE;
    if (IS_ATOM_INT(_13270)) {
        _13271 = _13270 + 1;
    }
    else
    _13271 = binary_op(PLUS, 1, _13270);
    DeRef(_13270);
    _13270 = NOVALUE;
    rhs_slice_target = (object_ptr)&_frac_bits_22641;
    RHS_Slice(_frac_bits_22641, 1, _13271);
L15: 
L13: 

    /** 				mbits = frac_bits & int_bits*/
    Concat((object_ptr)&_mbits_22642, _frac_bits_22641, _int_bits_22640);

    /** 				mbits = repeat( 0, 53 ) & mbits*/
    _13274 = Repeat(0, 53);
    Concat((object_ptr)&_mbits_22642, _13274, _mbits_22642);
    DeRefDS(_13274);
    _13274 = NOVALUE;
    DeRef(_13274);
    _13274 = NOVALUE;

    /** 				if exp > -1023 then*/
    if (_exp_22639 <= -1023)
    goto L16; // [642] 717

    /** 						if mbits[$-53] then*/
    if (IS_SEQUENCE(_mbits_22642)){
            _13277 = SEQ_PTR(_mbits_22642)->length;
    }
    else {
        _13277 = 1;
    }
    _13278 = _13277 - 53;
    _13277 = NOVALUE;
    _2 = (int)SEQ_PTR(_mbits_22642);
    _13279 = (int)*(((s1_ptr)_2)->base + _13278);
    if (_13279 == 0) {
        _13279 = NOVALUE;
        goto L17; // [659] 693
    }
    else {
        if (!IS_ATOM_INT(_13279) && DBL_PTR(_13279)->dbl == 0.0){
            _13279 = NOVALUE;
            goto L17; // [659] 693
        }
        _13279 = NOVALUE;
    }
    _13279 = NOVALUE;

    /** 								mbits[$-52] += 1*/
    if (IS_SEQUENCE(_mbits_22642)){
            _13280 = SEQ_PTR(_mbits_22642)->length;
    }
    else {
        _13280 = 1;
    }
    _13281 = _13280 - 52;
    _13280 = NOVALUE;
    _2 = (int)SEQ_PTR(_mbits_22642);
    _13282 = (int)*(((s1_ptr)_2)->base + _13281);
    if (IS_ATOM_INT(_13282)) {
        _13283 = _13282 + 1;
        if (_13283 > MAXINT){
            _13283 = NewDouble((double)_13283);
        }
    }
    else
    _13283 = binary_op(PLUS, 1, _13282);
    _13282 = NOVALUE;
    _2 = (int)SEQ_PTR(_mbits_22642);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _mbits_22642 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _13281);
    _1 = *(int *)_2;
    *(int *)_2 = _13283;
    if( _1 != _13283 ){
        DeRef(_1);
    }
    _13283 = NOVALUE;

    /** 								mbits = carry( mbits, 2 )*/
    RefDS(_mbits_22642);
    _0 = _mbits_22642;
    _mbits_22642 = _62carry(_mbits_22642, 2);
    DeRefDS(_0);
L17: 

    /** 						mbits = mbits[$-52..$-1]*/
    if (IS_SEQUENCE(_mbits_22642)){
            _13285 = SEQ_PTR(_mbits_22642)->length;
    }
    else {
        _13285 = 1;
    }
    _13286 = _13285 - 52;
    _13285 = NOVALUE;
    if (IS_SEQUENCE(_mbits_22642)){
            _13287 = SEQ_PTR(_mbits_22642)->length;
    }
    else {
        _13287 = 1;
    }
    _13288 = _13287 - 1;
    _13287 = NOVALUE;
    rhs_slice_target = (object_ptr)&_mbits_22642;
    RHS_Slice(_mbits_22642, _13286, _13288);
    goto L18; // [714] 782
L16: 

    /** 						if mbits[$-52] then*/
    if (IS_SEQUENCE(_mbits_22642)){
            _13290 = SEQ_PTR(_mbits_22642)->length;
    }
    else {
        _13290 = 1;
    }
    _13291 = _13290 - 52;
    _13290 = NOVALUE;
    _2 = (int)SEQ_PTR(_mbits_22642);
    _13292 = (int)*(((s1_ptr)_2)->base + _13291);
    if (_13292 == 0) {
        _13292 = NOVALUE;
        goto L19; // [730] 764
    }
    else {
        if (!IS_ATOM_INT(_13292) && DBL_PTR(_13292)->dbl == 0.0){
            _13292 = NOVALUE;
            goto L19; // [730] 764
        }
        _13292 = NOVALUE;
    }
    _13292 = NOVALUE;

    /** 								mbits[$-52] += 1*/
    if (IS_SEQUENCE(_mbits_22642)){
            _13293 = SEQ_PTR(_mbits_22642)->length;
    }
    else {
        _13293 = 1;
    }
    _13294 = _13293 - 52;
    _13293 = NOVALUE;
    _2 = (int)SEQ_PTR(_mbits_22642);
    _13295 = (int)*(((s1_ptr)_2)->base + _13294);
    if (IS_ATOM_INT(_13295)) {
        _13296 = _13295 + 1;
        if (_13296 > MAXINT){
            _13296 = NewDouble((double)_13296);
        }
    }
    else
    _13296 = binary_op(PLUS, 1, _13295);
    _13295 = NOVALUE;
    _2 = (int)SEQ_PTR(_mbits_22642);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _mbits_22642 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _13294);
    _1 = *(int *)_2;
    *(int *)_2 = _13296;
    if( _1 != _13296 ){
        DeRef(_1);
    }
    _13296 = NOVALUE;

    /** 								mbits = carry( mbits, 2 )*/
    RefDS(_mbits_22642);
    _0 = _mbits_22642;
    _mbits_22642 = _62carry(_mbits_22642, 2);
    DeRefDS(_0);
L19: 

    /** 						mbits = mbits[$-51..$]*/
    if (IS_SEQUENCE(_mbits_22642)){
            _13298 = SEQ_PTR(_mbits_22642)->length;
    }
    else {
        _13298 = 1;
    }
    _13299 = _13298 - 51;
    _13298 = NOVALUE;
    if (IS_SEQUENCE(_mbits_22642)){
            _13300 = SEQ_PTR(_mbits_22642)->length;
    }
    else {
        _13300 = 1;
    }
    rhs_slice_target = (object_ptr)&_mbits_22642;
    RHS_Slice(_mbits_22642, _13299, _13300);
L18: 
L11: 

    /** 		ebits = int_to_bits( exp + 1023, 11 )*/
    _13302 = _exp_22639 + 1023;
    if ((long)((unsigned long)_13302 + (unsigned long)HIGH_BITS) >= 0) 
    _13302 = NewDouble((double)_13302);
    _0 = _ebits_22643;
    _ebits_22643 = _15int_to_bits(_13302, 11);
    DeRef(_0);
    _13302 = NOVALUE;

    /** 		return bits_to_bytes( mbits & ebits & sbits )*/
    {
        int concat_list[3];

        concat_list[0] = _sbits_22644;
        concat_list[1] = _ebits_22643;
        concat_list[2] = _mbits_22642;
        Concat_N((object_ptr)&_13304, concat_list, 3);
    }
    _13305 = _62bits_to_bytes(_13304);
    _13304 = NOVALUE;
    DeRefDS(_s_22636);
    DeRef(_int_bits_22640);
    DeRef(_frac_bits_22641);
    DeRefDS(_mbits_22642);
    DeRefDS(_ebits_22643);
    DeRefDSi(_sbits_22644);
    DeRef(_13179);
    _13179 = NOVALUE;
    DeRef(_13247);
    _13247 = NOVALUE;
    DeRef(_13197);
    _13197 = NOVALUE;
    DeRef(_13271);
    _13271 = NOVALUE;
    DeRef(_13278);
    _13278 = NOVALUE;
    DeRef(_13299);
    _13299 = NOVALUE;
    DeRef(_13291);
    _13291 = NOVALUE;
    DeRef(_13206);
    _13206 = NOVALUE;
    DeRef(_13176);
    _13176 = NOVALUE;
    DeRef(_13230);
    _13230 = NOVALUE;
    DeRef(_13253);
    _13253 = NOVALUE;
    DeRef(_13281);
    _13281 = NOVALUE;
    DeRef(_13294);
    _13294 = NOVALUE;
    DeRef(_13288);
    _13288 = NOVALUE;
    DeRef(_13212);
    _13212 = NOVALUE;
    DeRef(_13238);
    _13238 = NOVALUE;
    DeRef(_13199);
    _13199 = NOVALUE;
    DeRef(_13286);
    _13286 = NOVALUE;
    DeRef(_13192);
    _13192 = NOVALUE;
    DeRef(_13184);
    _13184 = NOVALUE;
    DeRef(_13250);
    _13250 = NOVALUE;
    DeRef(_13245);
    _13245 = NOVALUE;
    DeRef(_13187);
    _13187 = NOVALUE;
    return _13305;
    ;
}


int _62scientific_to_atom(int _s_22817)
{
    int _13307 = NOVALUE;
    int _13306 = NOVALUE;
    int _0, _1, _2;
    

    /** 		return float64_to_atom( scientific_to_float64( s ) )*/
    RefDS(_s_22817);
    _13306 = _62scientific_to_float64(_s_22817);
    _13307 = _15float64_to_atom(_13306);
    _13306 = NOVALUE;
    DeRefDS(_s_22817);
    return _13307;
    ;
}



// 0x132B444A
