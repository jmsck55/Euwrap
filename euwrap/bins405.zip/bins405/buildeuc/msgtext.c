// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int _45GetMsgText(int _MsgNum_21167, int _WithNum_21168, int _Args_21169)
{
    int _idx_21170 = NOVALUE;
    int _msgtext_21171 = NOVALUE;
    int _12258 = NOVALUE;
    int _12257 = NOVALUE;
    int _12253 = NOVALUE;
    int _12252 = NOVALUE;
    int _12250 = NOVALUE;
    int _12248 = NOVALUE;
    int _12246 = NOVALUE;
    int _12245 = NOVALUE;
    int _12244 = NOVALUE;
    int _12243 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_MsgNum_21167)) {
        _1 = (long)(DBL_PTR(_MsgNum_21167)->dbl);
        DeRefDS(_MsgNum_21167);
        _MsgNum_21167 = _1;
    }

    /** 	integer idx = 1*/
    _idx_21170 = 1;

    /** 	msgtext = get_text( MsgNum, LocalizeQual, LocalDB )*/
    RefDS(_36LocalizeQual_15261);
    RefDS(_36LocalDB_15262);
    _0 = _msgtext_21171;
    _msgtext_21171 = _46get_text(_MsgNum_21167, _36LocalizeQual_15261, _36LocalDB_15262);
    DeRef(_0);

    /** 	if atom(msgtext) then*/
    _12243 = IS_ATOM(_msgtext_21171);
    if (_12243 == 0)
    {
        _12243 = NOVALUE;
        goto L1; // [27] 90
    }
    else{
        _12243 = NOVALUE;
    }

    /** 		for i = 1 to length(StdErrMsgs) do*/
    _12244 = 354;
    {
        int _i_21179;
        _i_21179 = 1;
L2: 
        if (_i_21179 > 354){
            goto L3; // [37] 77
        }

        /** 			if StdErrMsgs[i][1] = MsgNum then*/
        _2 = (int)SEQ_PTR(_45StdErrMsgs_20174);
        _12245 = (int)*(((s1_ptr)_2)->base + _i_21179);
        _2 = (int)SEQ_PTR(_12245);
        _12246 = (int)*(((s1_ptr)_2)->base + 1);
        _12245 = NOVALUE;
        if (binary_op_a(NOTEQ, _12246, _MsgNum_21167)){
            _12246 = NOVALUE;
            goto L4; // [56] 70
        }
        _12246 = NOVALUE;

        /** 				idx = i*/
        _idx_21170 = _i_21179;

        /** 				exit*/
        goto L3; // [67] 77
L4: 

        /** 		end for*/
        _i_21179 = _i_21179 + 1;
        goto L2; // [72] 44
L3: 
        ;
    }

    /** 		msgtext = StdErrMsgs[idx][2]*/
    _2 = (int)SEQ_PTR(_45StdErrMsgs_20174);
    _12248 = (int)*(((s1_ptr)_2)->base + _idx_21170);
    DeRef(_msgtext_21171);
    _2 = (int)SEQ_PTR(_12248);
    _msgtext_21171 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_msgtext_21171);
    _12248 = NOVALUE;
L1: 

    /** 	if atom(Args) or length(Args) != 0 then*/
    _12250 = IS_ATOM(_Args_21169);
    if (_12250 != 0) {
        goto L5; // [95] 111
    }
    if (IS_SEQUENCE(_Args_21169)){
            _12252 = SEQ_PTR(_Args_21169)->length;
    }
    else {
        _12252 = 1;
    }
    _12253 = (_12252 != 0);
    _12252 = NOVALUE;
    if (_12253 == 0)
    {
        DeRef(_12253);
        _12253 = NOVALUE;
        goto L6; // [107] 119
    }
    else{
        DeRef(_12253);
        _12253 = NOVALUE;
    }
L5: 

    /** 		msgtext = format(msgtext, Args)*/
    Ref(_msgtext_21171);
    Ref(_Args_21169);
    _0 = _msgtext_21171;
    _msgtext_21171 = _14format(_msgtext_21171, _Args_21169);
    DeRef(_0);
L6: 

    /** 	if WithNum != 0 then*/
    if (_WithNum_21168 == 0)
    goto L7; // [121] 142

    /** 		return sprintf("<%04d>:: %s", {MsgNum, msgtext})*/
    Ref(_msgtext_21171);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _MsgNum_21167;
    ((int *)_2)[2] = _msgtext_21171;
    _12257 = MAKE_SEQ(_1);
    _12258 = EPrintf(-9999999, _12256, _12257);
    DeRefDS(_12257);
    _12257 = NOVALUE;
    DeRef(_Args_21169);
    DeRef(_msgtext_21171);
    return _12258;
    goto L8; // [139] 149
L7: 

    /** 		return msgtext*/
    DeRef(_Args_21169);
    DeRef(_12258);
    _12258 = NOVALUE;
    return _msgtext_21171;
L8: 
    ;
}


void _45ShowMsg(int _Cons_21202, int _Msg_21203, int _Args_21204, int _NL_21205)
{
    int _12265 = NOVALUE;
    int _12264 = NOVALUE;
    int _12262 = NOVALUE;
    int _12260 = NOVALUE;
    int _12259 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(Msg) then*/
    _12259 = 1;
    if (_12259 == 0)
    {
        _12259 = NOVALUE;
        goto L1; // [10] 25
    }
    else{
        _12259 = NOVALUE;
    }

    /** 		Msg = GetMsgText(floor(Msg), 0)*/
    _12260 = e_floor(_Msg_21203);
    RefDS(_5);
    _Msg_21203 = _45GetMsgText(_12260, 0, _5);
    _12260 = NOVALUE;
L1: 

    /** 	if atom(Args) or length(Args) != 0 then*/
    _12262 = IS_ATOM(_Args_21204);
    if (_12262 != 0) {
        goto L2; // [30] 46
    }
    if (IS_SEQUENCE(_Args_21204)){
            _12264 = SEQ_PTR(_Args_21204)->length;
    }
    else {
        _12264 = 1;
    }
    _12265 = (_12264 != 0);
    _12264 = NOVALUE;
    if (_12265 == 0)
    {
        DeRef(_12265);
        _12265 = NOVALUE;
        goto L3; // [42] 54
    }
    else{
        DeRef(_12265);
        _12265 = NOVALUE;
    }
L2: 

    /** 		Msg = format(Msg, Args)*/
    Ref(_Msg_21203);
    Ref(_Args_21204);
    _0 = _Msg_21203;
    _Msg_21203 = _14format(_Msg_21203, _Args_21204);
    DeRef(_0);
L3: 

    /** 	puts(Cons, Msg)*/
    EPuts(_Cons_21202, _Msg_21203); // DJP 

    /** 	if NL then*/
    if (_NL_21205 == 0)
    {
        goto L4; // [61] 70
    }
    else{
    }

    /** 		puts(Cons, '\n')*/
    EPuts(_Cons_21202, 10); // DJP 
L4: 

    /** end procedure*/
    DeRef(_Msg_21203);
    DeRef(_Args_21204);
    return;
    ;
}



// 0xE8BDC20F
