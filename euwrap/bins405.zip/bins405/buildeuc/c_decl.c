// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int _57get_eucompiledir()
{
    int _x_41693 = NOVALUE;
    int _22348 = NOVALUE;
    int _22344 = NOVALUE;
    int _0, _1, _2;
    

    /** 	object x = getenv("EUCOMPILEDIR")*/
    DeRef(_x_41693);
    _x_41693 = EGetEnv(_22342);

    /** 	if is_eudir_from_cmdline() then*/
    _22344 = _36is_eudir_from_cmdline();
    if (_22344 == 0) {
        DeRef(_22344);
        _22344 = NOVALUE;
        goto L1; // [11] 20
    }
    else {
        if (!IS_ATOM_INT(_22344) && DBL_PTR(_22344)->dbl == 0.0){
            DeRef(_22344);
            _22344 = NOVALUE;
            goto L1; // [11] 20
        }
        DeRef(_22344);
        _22344 = NOVALUE;
    }
    DeRef(_22344);
    _22344 = NOVALUE;

    /** 		x = get_eudir()*/
    _0 = _x_41693;
    _x_41693 = _36get_eudir();
    DeRefi(_0);
L1: 

    /** 	ifdef UNIX then*/

    /** 	if equal(x, -1) then*/
    if (_x_41693 == -1)
    _22348 = 1;
    else if (IS_ATOM_INT(_x_41693) && IS_ATOM_INT(-1))
    _22348 = 0;
    else
    _22348 = (compare(_x_41693, -1) == 0);
    if (_22348 == 0)
    {
        _22348 = NOVALUE;
        goto L2; // [28] 37
    }
    else{
        _22348 = NOVALUE;
    }

    /** 		x = get_eudir()*/
    _0 = _x_41693;
    _x_41693 = _36get_eudir();
    DeRef(_0);
L2: 

    /** 	return x*/
    return _x_41693;
    ;
}


void _57NewBB(int _a_call_41709, int _mask_41710, int _sub_41712)
{
    int _s_41714 = NOVALUE;
    int _22381 = NOVALUE;
    int _22380 = NOVALUE;
    int _22378 = NOVALUE;
    int _22377 = NOVALUE;
    int _22375 = NOVALUE;
    int _22374 = NOVALUE;
    int _22373 = NOVALUE;
    int _22372 = NOVALUE;
    int _22371 = NOVALUE;
    int _22370 = NOVALUE;
    int _22369 = NOVALUE;
    int _22368 = NOVALUE;
    int _22367 = NOVALUE;
    int _22366 = NOVALUE;
    int _22365 = NOVALUE;
    int _22364 = NOVALUE;
    int _22363 = NOVALUE;
    int _22362 = NOVALUE;
    int _22361 = NOVALUE;
    int _22360 = NOVALUE;
    int _22359 = NOVALUE;
    int _22358 = NOVALUE;
    int _22357 = NOVALUE;
    int _22356 = NOVALUE;
    int _22355 = NOVALUE;
    int _22354 = NOVALUE;
    int _22353 = NOVALUE;
    int _22351 = NOVALUE;
    int _22350 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_a_call_41709)) {
        _1 = (long)(DBL_PTR(_a_call_41709)->dbl);
        DeRefDS(_a_call_41709);
        _a_call_41709 = _1;
    }
    if (!IS_ATOM_INT(_mask_41710)) {
        _1 = (long)(DBL_PTR(_mask_41710)->dbl);
        DeRefDS(_mask_41710);
        _mask_41710 = _1;
    }
    if (!IS_ATOM_INT(_sub_41712)) {
        _1 = (long)(DBL_PTR(_sub_41712)->dbl);
        DeRefDS(_sub_41712);
        _sub_41712 = _1;
    }

    /** 	if a_call then*/
    if (_a_call_41709 == 0)
    {
        goto L1; // [9] 252
    }
    else{
    }

    /** 		for i = 1 to length(BB_info) do*/
    if (IS_SEQUENCE(_57BB_info_41672)){
            _22350 = SEQ_PTR(_57BB_info_41672)->length;
    }
    else {
        _22350 = 1;
    }
    {
        int _i_41717;
        _i_41717 = 1;
L2: 
        if (_i_41717 > _22350){
            goto L3; // [19] 249
        }

        /** 			s = BB_info[i][BB_VAR]*/
        _2 = (int)SEQ_PTR(_57BB_info_41672);
        _22351 = (int)*(((s1_ptr)_2)->base + _i_41717);
        _2 = (int)SEQ_PTR(_22351);
        _s_41714 = (int)*(((s1_ptr)_2)->base + 1);
        if (!IS_ATOM_INT(_s_41714)){
            _s_41714 = (long)DBL_PTR(_s_41714)->dbl;
        }
        _22351 = NOVALUE;

        /** 			if SymTab[s][S_MODE] = M_NORMAL and*/
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _22353 = (int)*(((s1_ptr)_2)->base + _s_41714);
        _2 = (int)SEQ_PTR(_22353);
        _22354 = (int)*(((s1_ptr)_2)->base + 3);
        _22353 = NOVALUE;
        if (IS_ATOM_INT(_22354)) {
            _22355 = (_22354 == 1);
        }
        else {
            _22355 = binary_op(EQUALS, _22354, 1);
        }
        _22354 = NOVALUE;
        if (IS_ATOM_INT(_22355)) {
            if (_22355 == 0) {
                goto L4; // [60] 242
            }
        }
        else {
            if (DBL_PTR(_22355)->dbl == 0.0) {
                goto L4; // [60] 242
            }
        }
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _22357 = (int)*(((s1_ptr)_2)->base + _s_41714);
        _2 = (int)SEQ_PTR(_22357);
        _22358 = (int)*(((s1_ptr)_2)->base + 4);
        _22357 = NOVALUE;
        if (IS_ATOM_INT(_22358)) {
            _22359 = (_22358 == 6);
        }
        else {
            _22359 = binary_op(EQUALS, _22358, 6);
        }
        _22358 = NOVALUE;
        if (IS_ATOM_INT(_22359)) {
            if (_22359 != 0) {
                DeRef(_22360);
                _22360 = 1;
                goto L5; // [82] 108
            }
        }
        else {
            if (DBL_PTR(_22359)->dbl != 0.0) {
                DeRef(_22360);
                _22360 = 1;
                goto L5; // [82] 108
            }
        }
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _22361 = (int)*(((s1_ptr)_2)->base + _s_41714);
        _2 = (int)SEQ_PTR(_22361);
        _22362 = (int)*(((s1_ptr)_2)->base + 4);
        _22361 = NOVALUE;
        if (IS_ATOM_INT(_22362)) {
            _22363 = (_22362 == 5);
        }
        else {
            _22363 = binary_op(EQUALS, _22362, 5);
        }
        _22362 = NOVALUE;
        DeRef(_22360);
        if (IS_ATOM_INT(_22363))
        _22360 = (_22363 != 0);
        else
        _22360 = DBL_PTR(_22363)->dbl != 0.0;
L5: 
        if (_22360 != 0) {
            _22364 = 1;
            goto L6; // [108] 134
        }
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _22365 = (int)*(((s1_ptr)_2)->base + _s_41714);
        _2 = (int)SEQ_PTR(_22365);
        _22366 = (int)*(((s1_ptr)_2)->base + 4);
        _22365 = NOVALUE;
        if (IS_ATOM_INT(_22366)) {
            _22367 = (_22366 == 11);
        }
        else {
            _22367 = binary_op(EQUALS, _22366, 11);
        }
        _22366 = NOVALUE;
        if (IS_ATOM_INT(_22367))
        _22364 = (_22367 != 0);
        else
        _22364 = DBL_PTR(_22367)->dbl != 0.0;
L6: 
        if (_22364 != 0) {
            DeRef(_22368);
            _22368 = 1;
            goto L7; // [134] 160
        }
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _22369 = (int)*(((s1_ptr)_2)->base + _s_41714);
        _2 = (int)SEQ_PTR(_22369);
        _22370 = (int)*(((s1_ptr)_2)->base + 4);
        _22369 = NOVALUE;
        if (IS_ATOM_INT(_22370)) {
            _22371 = (_22370 == 13);
        }
        else {
            _22371 = binary_op(EQUALS, _22370, 13);
        }
        _22370 = NOVALUE;
        if (IS_ATOM_INT(_22371))
        _22368 = (_22371 != 0);
        else
        _22368 = DBL_PTR(_22371)->dbl != 0.0;
L7: 
        if (_22368 == 0)
        {
            _22368 = NOVALUE;
            goto L4; // [161] 242
        }
        else{
            _22368 = NOVALUE;
        }

        /** 				  if and_bits(mask, power(2, remainder(s, E_SIZE))) then*/
        _22372 = (_s_41714 % 29);
        _22373 = power(2, _22372);
        _22372 = NOVALUE;
        if (IS_ATOM_INT(_22373)) {
            {unsigned long tu;
                 tu = (unsigned long)_mask_41710 & (unsigned long)_22373;
                 _22374 = MAKE_UINT(tu);
            }
        }
        else {
            temp_d.dbl = (double)_mask_41710;
            _22374 = Dand_bits(&temp_d, DBL_PTR(_22373));
        }
        DeRef(_22373);
        _22373 = NOVALUE;
        if (_22374 == 0) {
            DeRef(_22374);
            _22374 = NOVALUE;
            goto L8; // [180] 241
        }
        else {
            if (!IS_ATOM_INT(_22374) && DBL_PTR(_22374)->dbl == 0.0){
                DeRef(_22374);
                _22374 = NOVALUE;
                goto L8; // [180] 241
            }
            DeRef(_22374);
            _22374 = NOVALUE;
        }
        DeRef(_22374);
        _22374 = NOVALUE;

        /** 					  if mask = E_ALL_EFFECT or s < sub then*/
        _22375 = (_mask_41710 == 1073741823);
        if (_22375 != 0) {
            goto L9; // [191] 204
        }
        _22377 = (_s_41714 < _sub_41712);
        if (_22377 == 0)
        {
            DeRef(_22377);
            _22377 = NOVALUE;
            goto LA; // [200] 240
        }
        else{
            DeRef(_22377);
            _22377 = NOVALUE;
        }
L9: 

        /** 						  BB_info[i][BB_TYPE..BB_OBJ] =*/
        _2 = (int)SEQ_PTR(_57BB_info_41672);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _57BB_info_41672 = MAKE_SEQ(_2);
        }
        _3 = (int)(_i_41717 + ((s1_ptr)_2)->base);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = -1073741824;
        ((int *)_2)[2] = 1073741823;
        _22380 = MAKE_SEQ(_1);
        _1 = NewS1(4);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = 0;
        *((int *)(_2+8)) = 0;
        Ref(_35NOVALUE_16099);
        *((int *)(_2+12)) = _35NOVALUE_16099;
        *((int *)(_2+16)) = _22380;
        _22381 = MAKE_SEQ(_1);
        _22380 = NOVALUE;
        assign_slice_seq = (s1_ptr *)_3;
        AssignSlice(2, 5, _22381);
        DeRefDS(_22381);
        _22381 = NOVALUE;
LA: 
L8: 
L4: 

        /** 		end for*/
        _i_41717 = _i_41717 + 1;
        goto L2; // [244] 26
L3: 
        ;
    }
    goto LB; // [249] 260
L1: 

    /** 		BB_info = {}*/
    RefDS(_22023);
    DeRef(_57BB_info_41672);
    _57BB_info_41672 = _22023;
LB: 

    /** end procedure*/
    DeRef(_22375);
    _22375 = NOVALUE;
    DeRef(_22355);
    _22355 = NOVALUE;
    DeRef(_22359);
    _22359 = NOVALUE;
    DeRef(_22363);
    _22363 = NOVALUE;
    DeRef(_22367);
    _22367 = NOVALUE;
    DeRef(_22371);
    _22371 = NOVALUE;
    DeRef(_22378);
    _22378 = NOVALUE;
    return;
    ;
}


int _57BB_var_obj(int _var_41782)
{
    int _bbi_41783 = NOVALUE;
    int _22392 = NOVALUE;
    int _22390 = NOVALUE;
    int _22388 = NOVALUE;
    int _22387 = NOVALUE;
    int _22385 = NOVALUE;
    int _22383 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_var_41782)) {
        _1 = (long)(DBL_PTR(_var_41782)->dbl);
        DeRefDS(_var_41782);
        _var_41782 = _1;
    }

    /** 	for i = length(BB_info) to 1 by -1 do*/
    if (IS_SEQUENCE(_57BB_info_41672)){
            _22383 = SEQ_PTR(_57BB_info_41672)->length;
    }
    else {
        _22383 = 1;
    }
    {
        int _i_41785;
        _i_41785 = _22383;
L1: 
        if (_i_41785 < 1){
            goto L2; // [10] 99
        }

        /** 		bbi = BB_info[i]*/
        DeRef(_bbi_41783);
        _2 = (int)SEQ_PTR(_57BB_info_41672);
        _bbi_41783 = (int)*(((s1_ptr)_2)->base + _i_41785);
        Ref(_bbi_41783);

        /** 		if bbi[BB_VAR] != var then*/
        _2 = (int)SEQ_PTR(_bbi_41783);
        _22385 = (int)*(((s1_ptr)_2)->base + 1);
        if (binary_op_a(EQUALS, _22385, _var_41782)){
            _22385 = NOVALUE;
            goto L3; // [31] 40
        }
        _22385 = NOVALUE;

        /** 			continue*/
        goto L4; // [37] 94
L3: 

        /** 		if SymTab[var][S_MODE] != M_NORMAL then*/
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _22387 = (int)*(((s1_ptr)_2)->base + _var_41782);
        _2 = (int)SEQ_PTR(_22387);
        _22388 = (int)*(((s1_ptr)_2)->base + 3);
        _22387 = NOVALUE;
        if (binary_op_a(EQUALS, _22388, 1)){
            _22388 = NOVALUE;
            goto L5; // [56] 65
        }
        _22388 = NOVALUE;

        /** 			continue*/
        goto L4; // [62] 94
L5: 

        /** 		if bbi[BB_TYPE] != TYPE_INTEGER then*/
        _2 = (int)SEQ_PTR(_bbi_41783);
        _22390 = (int)*(((s1_ptr)_2)->base + 2);
        if (binary_op_a(EQUALS, _22390, 1)){
            _22390 = NOVALUE;
            goto L6; // [73] 82
        }
        _22390 = NOVALUE;

        /** 			exit*/
        goto L2; // [79] 99
L6: 

        /** 		return bbi[BB_OBJ]*/
        _2 = (int)SEQ_PTR(_bbi_41783);
        _22392 = (int)*(((s1_ptr)_2)->base + 5);
        Ref(_22392);
        DeRef(_bbi_41783);
        return _22392;

        /** 	end for*/
L4: 
        _i_41785 = _i_41785 + -1;
        goto L1; // [94] 17
L2: 
        ;
    }

    /** 	return BB_def_values*/
    RefDS(_57BB_def_values_41776);
    DeRef(_bbi_41783);
    _22392 = NOVALUE;
    return _57BB_def_values_41776;
    ;
}


int _57BB_var_type(int _var_41805)
{
    int _22407 = NOVALUE;
    int _22406 = NOVALUE;
    int _22404 = NOVALUE;
    int _22403 = NOVALUE;
    int _22402 = NOVALUE;
    int _22401 = NOVALUE;
    int _22400 = NOVALUE;
    int _22399 = NOVALUE;
    int _22398 = NOVALUE;
    int _22397 = NOVALUE;
    int _22396 = NOVALUE;
    int _22395 = NOVALUE;
    int _22394 = NOVALUE;
    int _22393 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_var_41805)) {
        _1 = (long)(DBL_PTR(_var_41805)->dbl);
        DeRefDS(_var_41805);
        _var_41805 = _1;
    }

    /** 	for i = length(BB_info) to 1 by -1 do*/
    if (IS_SEQUENCE(_57BB_info_41672)){
            _22393 = SEQ_PTR(_57BB_info_41672)->length;
    }
    else {
        _22393 = 1;
    }
    {
        int _i_41807;
        _i_41807 = _22393;
L1: 
        if (_i_41807 < 1){
            goto L2; // [10] 125
        }

        /** 		if BB_info[i][BB_VAR] = var and*/
        _2 = (int)SEQ_PTR(_57BB_info_41672);
        _22394 = (int)*(((s1_ptr)_2)->base + _i_41807);
        _2 = (int)SEQ_PTR(_22394);
        _22395 = (int)*(((s1_ptr)_2)->base + 1);
        _22394 = NOVALUE;
        if (IS_ATOM_INT(_22395)) {
            _22396 = (_22395 == _var_41805);
        }
        else {
            _22396 = binary_op(EQUALS, _22395, _var_41805);
        }
        _22395 = NOVALUE;
        if (IS_ATOM_INT(_22396)) {
            if (_22396 == 0) {
                goto L3; // [33] 118
            }
        }
        else {
            if (DBL_PTR(_22396)->dbl == 0.0) {
                goto L3; // [33] 118
            }
        }
        _2 = (int)SEQ_PTR(_57BB_info_41672);
        _22398 = (int)*(((s1_ptr)_2)->base + _i_41807);
        _2 = (int)SEQ_PTR(_22398);
        _22399 = (int)*(((s1_ptr)_2)->base + 1);
        _22398 = NOVALUE;
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        if (!IS_ATOM_INT(_22399)){
            _22400 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_22399)->dbl));
        }
        else{
            _22400 = (int)*(((s1_ptr)_2)->base + _22399);
        }
        _2 = (int)SEQ_PTR(_22400);
        _22401 = (int)*(((s1_ptr)_2)->base + 3);
        _22400 = NOVALUE;
        if (IS_ATOM_INT(_22401)) {
            _22402 = (_22401 == 1);
        }
        else {
            _22402 = binary_op(EQUALS, _22401, 1);
        }
        _22401 = NOVALUE;
        if (_22402 == 0) {
            DeRef(_22402);
            _22402 = NOVALUE;
            goto L3; // [66] 118
        }
        else {
            if (!IS_ATOM_INT(_22402) && DBL_PTR(_22402)->dbl == 0.0){
                DeRef(_22402);
                _22402 = NOVALUE;
                goto L3; // [66] 118
            }
            DeRef(_22402);
            _22402 = NOVALUE;
        }
        DeRef(_22402);
        _22402 = NOVALUE;

        /** 			ifdef DEBUG then*/

        /** 			if BB_info[i][BB_TYPE] = TYPE_NULL then  -- var has only been read*/
        _2 = (int)SEQ_PTR(_57BB_info_41672);
        _22403 = (int)*(((s1_ptr)_2)->base + _i_41807);
        _2 = (int)SEQ_PTR(_22403);
        _22404 = (int)*(((s1_ptr)_2)->base + 2);
        _22403 = NOVALUE;
        if (binary_op_a(NOTEQ, _22404, 0)){
            _22404 = NOVALUE;
            goto L4; // [85] 100
        }
        _22404 = NOVALUE;

        /** 				return TYPE_OBJECT*/
        _22399 = NOVALUE;
        DeRef(_22396);
        _22396 = NOVALUE;
        return 16;
        goto L5; // [97] 117
L4: 

        /** 				return BB_info[i][BB_TYPE]*/
        _2 = (int)SEQ_PTR(_57BB_info_41672);
        _22406 = (int)*(((s1_ptr)_2)->base + _i_41807);
        _2 = (int)SEQ_PTR(_22406);
        _22407 = (int)*(((s1_ptr)_2)->base + 2);
        _22406 = NOVALUE;
        Ref(_22407);
        _22399 = NOVALUE;
        DeRef(_22396);
        _22396 = NOVALUE;
        return _22407;
L5: 
L3: 

        /** 	end for*/
        _i_41807 = _i_41807 + -1;
        goto L1; // [120] 17
L2: 
        ;
    }

    /** 	return TYPE_OBJECT*/
    _22399 = NOVALUE;
    DeRef(_22396);
    _22396 = NOVALUE;
    _22407 = NOVALUE;
    return 16;
    ;
}


int _57GType(int _s_41835)
{
    int _t_41836 = NOVALUE;
    int _local_t_41837 = NOVALUE;
    int _22411 = NOVALUE;
    int _22410 = NOVALUE;
    int _22408 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_s_41835)) {
        _1 = (long)(DBL_PTR(_s_41835)->dbl);
        DeRefDS(_s_41835);
        _s_41835 = _1;
    }

    /** 	t = SymTab[s][S_GTYPE]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _22408 = (int)*(((s1_ptr)_2)->base + _s_41835);
    _2 = (int)SEQ_PTR(_22408);
    _t_41836 = (int)*(((s1_ptr)_2)->base + 36);
    if (!IS_ATOM_INT(_t_41836)){
        _t_41836 = (long)DBL_PTR(_t_41836)->dbl;
    }
    _22408 = NOVALUE;

    /** 	ifdef DEBUG then*/

    /** 	if SymTab[s][S_MODE] != M_NORMAL then*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _22410 = (int)*(((s1_ptr)_2)->base + _s_41835);
    _2 = (int)SEQ_PTR(_22410);
    _22411 = (int)*(((s1_ptr)_2)->base + 3);
    _22410 = NOVALUE;
    if (binary_op_a(EQUALS, _22411, 1)){
        _22411 = NOVALUE;
        goto L1; // [37] 48
    }
    _22411 = NOVALUE;

    /** 		return t*/
    return _t_41836;
L1: 

    /** 	local_t = BB_var_type(s)*/
    _local_t_41837 = _57BB_var_type(_s_41835);
    if (!IS_ATOM_INT(_local_t_41837)) {
        _1 = (long)(DBL_PTR(_local_t_41837)->dbl);
        DeRefDS(_local_t_41837);
        _local_t_41837 = _1;
    }

    /** 	if local_t = TYPE_OBJECT then*/
    if (_local_t_41837 != 16)
    goto L2; // [60] 71

    /** 		return t*/
    return _t_41836;
L2: 

    /** 	if t = TYPE_INTEGER then*/
    if (_t_41836 != 1)
    goto L3; // [75] 88

    /** 		return TYPE_INTEGER*/
    return 1;
L3: 

    /** 	return local_t*/
    return _local_t_41837;
    ;
}


int _57GDelete()
{
    int _0, _1, _2;
    

    /** 	return g_has_delete*/
    return _57g_has_delete_41857;
    ;
}


int _57HasDelete(int _s_41864)
{
    int _22426 = NOVALUE;
    int _22425 = NOVALUE;
    int _22423 = NOVALUE;
    int _22422 = NOVALUE;
    int _22421 = NOVALUE;
    int _22420 = NOVALUE;
    int _22418 = NOVALUE;
    int _22417 = NOVALUE;
    int _22416 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_s_41864)) {
        _1 = (long)(DBL_PTR(_s_41864)->dbl);
        DeRefDS(_s_41864);
        _s_41864 = _1;
    }

    /** 	for i = length(BB_info) to 1 by -1 do*/
    if (IS_SEQUENCE(_57BB_info_41672)){
            _22416 = SEQ_PTR(_57BB_info_41672)->length;
    }
    else {
        _22416 = 1;
    }
    {
        int _i_41866;
        _i_41866 = _22416;
L1: 
        if (_i_41866 < 1){
            goto L2; // [10] 57
        }

        /** 		if BB_info[i][BB_VAR] = s then*/
        _2 = (int)SEQ_PTR(_57BB_info_41672);
        _22417 = (int)*(((s1_ptr)_2)->base + _i_41866);
        _2 = (int)SEQ_PTR(_22417);
        _22418 = (int)*(((s1_ptr)_2)->base + 1);
        _22417 = NOVALUE;
        if (binary_op_a(NOTEQ, _22418, _s_41864)){
            _22418 = NOVALUE;
            goto L3; // [29] 50
        }
        _22418 = NOVALUE;

        /** 			return BB_info[i][BB_DELETE]*/
        _2 = (int)SEQ_PTR(_57BB_info_41672);
        _22420 = (int)*(((s1_ptr)_2)->base + _i_41866);
        _2 = (int)SEQ_PTR(_22420);
        _22421 = (int)*(((s1_ptr)_2)->base + 6);
        _22420 = NOVALUE;
        Ref(_22421);
        return _22421;
L3: 

        /** 	end for*/
        _i_41866 = _i_41866 + -1;
        goto L1; // [52] 17
L2: 
        ;
    }

    /** 	if length(SymTab[s]) < S_HAS_DELETE then*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _22422 = (int)*(((s1_ptr)_2)->base + _s_41864);
    if (IS_SEQUENCE(_22422)){
            _22423 = SEQ_PTR(_22422)->length;
    }
    else {
        _22423 = 1;
    }
    _22422 = NOVALUE;
    if (_22423 >= 54)
    goto L4; // [70] 81

    /** 		return 0*/
    _22421 = NOVALUE;
    _22422 = NOVALUE;
    return 0;
L4: 

    /** 	return SymTab[s][S_HAS_DELETE]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _22425 = (int)*(((s1_ptr)_2)->base + _s_41864);
    _2 = (int)SEQ_PTR(_22425);
    _22426 = (int)*(((s1_ptr)_2)->base + 54);
    _22425 = NOVALUE;
    Ref(_22426);
    _22421 = NOVALUE;
    _22422 = NOVALUE;
    return _22426;
    ;
}


int _57ObjValue(int _s_41887)
{
    int _local_t_41888 = NOVALUE;
    int _st_41889 = NOVALUE;
    int _tmin_41890 = NOVALUE;
    int _tmax_41891 = NOVALUE;
    int _22439 = NOVALUE;
    int _22437 = NOVALUE;
    int _22436 = NOVALUE;
    int _22434 = NOVALUE;
    int _22431 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_s_41887)) {
        _1 = (long)(DBL_PTR(_s_41887)->dbl);
        DeRefDS(_s_41887);
        _s_41887 = _1;
    }

    /** 	st = SymTab[s]*/
    DeRef(_st_41889);
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _st_41889 = (int)*(((s1_ptr)_2)->base + _s_41887);
    Ref(_st_41889);

    /** 	tmin = st[S_OBJ_MIN]*/
    DeRef(_tmin_41890);
    _2 = (int)SEQ_PTR(_st_41889);
    _tmin_41890 = (int)*(((s1_ptr)_2)->base + 30);
    Ref(_tmin_41890);

    /** 	tmax = st[S_OBJ_MAX]*/
    DeRef(_tmax_41891);
    _2 = (int)SEQ_PTR(_st_41889);
    _tmax_41891 = (int)*(((s1_ptr)_2)->base + 31);
    Ref(_tmax_41891);

    /** 	if tmin != tmax then*/
    if (binary_op_a(EQUALS, _tmin_41890, _tmax_41891)){
        goto L1; // [29] 41
    }

    /** 		tmin = NOVALUE*/
    Ref(_35NOVALUE_16099);
    DeRef(_tmin_41890);
    _tmin_41890 = _35NOVALUE_16099;
L1: 

    /** 	if st[S_MODE] != M_NORMAL then*/
    _2 = (int)SEQ_PTR(_st_41889);
    _22431 = (int)*(((s1_ptr)_2)->base + 3);
    if (binary_op_a(EQUALS, _22431, 1)){
        _22431 = NOVALUE;
        goto L2; // [51] 62
    }
    _22431 = NOVALUE;

    /** 		return tmin*/
    DeRef(_local_t_41888);
    DeRef(_st_41889);
    DeRef(_tmax_41891);
    return _tmin_41890;
L2: 

    /** 	local_t = BB_var_obj(s)*/
    _0 = _local_t_41888;
    _local_t_41888 = _57BB_var_obj(_s_41887);
    DeRef(_0);

    /** 	if local_t[MIN] = NOVALUE then*/
    _2 = (int)SEQ_PTR(_local_t_41888);
    _22434 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _22434, _35NOVALUE_16099)){
        _22434 = NOVALUE;
        goto L3; // [80] 91
    }
    _22434 = NOVALUE;

    /** 		return tmin*/
    DeRefDS(_local_t_41888);
    DeRef(_st_41889);
    DeRef(_tmax_41891);
    return _tmin_41890;
L3: 

    /** 	if local_t[MIN] != local_t[MAX] then*/
    _2 = (int)SEQ_PTR(_local_t_41888);
    _22436 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_local_t_41888);
    _22437 = (int)*(((s1_ptr)_2)->base + 2);
    if (binary_op_a(EQUALS, _22436, _22437)){
        _22436 = NOVALUE;
        _22437 = NOVALUE;
        goto L4; // [105] 116
    }
    _22436 = NOVALUE;
    _22437 = NOVALUE;

    /** 		return tmin*/
    DeRefDS(_local_t_41888);
    DeRef(_st_41889);
    DeRef(_tmax_41891);
    return _tmin_41890;
L4: 

    /** 	return local_t[MIN]*/
    _2 = (int)SEQ_PTR(_local_t_41888);
    _22439 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_22439);
    DeRefDS(_local_t_41888);
    DeRef(_st_41889);
    DeRef(_tmin_41890);
    DeRef(_tmax_41891);
    return _22439;
    ;
}


int _57TypeIs(int _x_41922, int _typei_41923)
{
    int _22441 = NOVALUE;
    int _22440 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_x_41922)) {
        _1 = (long)(DBL_PTR(_x_41922)->dbl);
        DeRefDS(_x_41922);
        _x_41922 = _1;
    }
    if (!IS_ATOM_INT(_typei_41923)) {
        _1 = (long)(DBL_PTR(_typei_41923)->dbl);
        DeRefDS(_typei_41923);
        _typei_41923 = _1;
    }

    /** 	return GType(x) = typei*/
    _22440 = _57GType(_x_41922);
    if (IS_ATOM_INT(_22440)) {
        _22441 = (_22440 == _typei_41923);
    }
    else {
        _22441 = binary_op(EQUALS, _22440, _typei_41923);
    }
    DeRef(_22440);
    _22440 = NOVALUE;
    return _22441;
    ;
}


int _57TypeIsIn(int _x_41928, int _types_41929)
{
    int _22443 = NOVALUE;
    int _22442 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_x_41928)) {
        _1 = (long)(DBL_PTR(_x_41928)->dbl);
        DeRefDS(_x_41928);
        _x_41928 = _1;
    }

    /** 	return find(GType(x), types)*/
    _22442 = _57GType(_x_41928);
    _22443 = find_from(_22442, _types_41929, 1);
    DeRef(_22442);
    _22442 = NOVALUE;
    DeRefDS(_types_41929);
    return _22443;
    ;
}


int _57TypeIsNot(int _x_41934, int _typei_41935)
{
    int _22445 = NOVALUE;
    int _22444 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_x_41934)) {
        _1 = (long)(DBL_PTR(_x_41934)->dbl);
        DeRefDS(_x_41934);
        _x_41934 = _1;
    }
    if (!IS_ATOM_INT(_typei_41935)) {
        _1 = (long)(DBL_PTR(_typei_41935)->dbl);
        DeRefDS(_typei_41935);
        _typei_41935 = _1;
    }

    /** 	return GType(x) != typei*/
    _22444 = _57GType(_x_41934);
    if (IS_ATOM_INT(_22444)) {
        _22445 = (_22444 != _typei_41935);
    }
    else {
        _22445 = binary_op(NOTEQ, _22444, _typei_41935);
    }
    DeRef(_22444);
    _22444 = NOVALUE;
    return _22445;
    ;
}


int _57TypeIsNotIn(int _x_41940, int _types_41941)
{
    int _22448 = NOVALUE;
    int _22447 = NOVALUE;
    int _22446 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_x_41940)) {
        _1 = (long)(DBL_PTR(_x_41940)->dbl);
        DeRefDS(_x_41940);
        _x_41940 = _1;
    }

    /** 	return not find(GType(x), types)*/
    _22446 = _57GType(_x_41940);
    _22447 = find_from(_22446, _types_41941, 1);
    DeRef(_22446);
    _22446 = NOVALUE;
    _22448 = (_22447 == 0);
    _22447 = NOVALUE;
    DeRefDS(_types_41941);
    return _22448;
    ;
}


int _57or_type(int _t1_41947, int _t2_41948)
{
    int _22468 = NOVALUE;
    int _22467 = NOVALUE;
    int _22466 = NOVALUE;
    int _22465 = NOVALUE;
    int _22460 = NOVALUE;
    int _22458 = NOVALUE;
    int _22453 = NOVALUE;
    int _22451 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_t1_41947)) {
        _1 = (long)(DBL_PTR(_t1_41947)->dbl);
        DeRefDS(_t1_41947);
        _t1_41947 = _1;
    }
    if (!IS_ATOM_INT(_t2_41948)) {
        _1 = (long)(DBL_PTR(_t2_41948)->dbl);
        DeRefDS(_t2_41948);
        _t2_41948 = _1;
    }

    /** 	if t1 = TYPE_NULL then*/
    if (_t1_41947 != 0)
    goto L1; // [9] 22

    /** 		return t2*/
    return _t2_41948;
    goto L2; // [19] 307
L1: 

    /** 	elsif t2 = TYPE_NULL then*/
    if (_t2_41948 != 0)
    goto L3; // [26] 39

    /** 		return t1*/
    return _t1_41947;
    goto L2; // [36] 307
L3: 

    /** 	elsif t1 = TYPE_OBJECT or t2 = TYPE_OBJECT then*/
    _22451 = (_t1_41947 == 16);
    if (_22451 != 0) {
        goto L4; // [47] 62
    }
    _22453 = (_t2_41948 == 16);
    if (_22453 == 0)
    {
        DeRef(_22453);
        _22453 = NOVALUE;
        goto L5; // [58] 73
    }
    else{
        DeRef(_22453);
        _22453 = NOVALUE;
    }
L4: 

    /** 		return TYPE_OBJECT*/
    DeRef(_22451);
    _22451 = NOVALUE;
    return 16;
    goto L2; // [70] 307
L5: 

    /** 	elsif t1 = TYPE_SEQUENCE then*/
    if (_t1_41947 != 8)
    goto L6; // [77] 112

    /** 		if t2 = TYPE_SEQUENCE then*/
    if (_t2_41948 != 8)
    goto L7; // [85] 100

    /** 			return TYPE_SEQUENCE*/
    DeRef(_22451);
    _22451 = NOVALUE;
    return 8;
    goto L2; // [97] 307
L7: 

    /** 			return TYPE_OBJECT*/
    DeRef(_22451);
    _22451 = NOVALUE;
    return 16;
    goto L2; // [109] 307
L6: 

    /** 	elsif t2 = TYPE_SEQUENCE then*/
    if (_t2_41948 != 8)
    goto L8; // [116] 151

    /** 		if t1 = TYPE_SEQUENCE then*/
    if (_t1_41947 != 8)
    goto L9; // [124] 139

    /** 			return TYPE_SEQUENCE*/
    DeRef(_22451);
    _22451 = NOVALUE;
    return 8;
    goto L2; // [136] 307
L9: 

    /** 			return TYPE_OBJECT*/
    DeRef(_22451);
    _22451 = NOVALUE;
    return 16;
    goto L2; // [148] 307
L8: 

    /** 	elsif t1 = TYPE_ATOM or t2 = TYPE_ATOM then*/
    _22458 = (_t1_41947 == 4);
    if (_22458 != 0) {
        goto LA; // [159] 174
    }
    _22460 = (_t2_41948 == 4);
    if (_22460 == 0)
    {
        DeRef(_22460);
        _22460 = NOVALUE;
        goto LB; // [170] 185
    }
    else{
        DeRef(_22460);
        _22460 = NOVALUE;
    }
LA: 

    /** 		return TYPE_ATOM*/
    DeRef(_22451);
    _22451 = NOVALUE;
    DeRef(_22458);
    _22458 = NOVALUE;
    return 4;
    goto L2; // [182] 307
LB: 

    /** 	elsif t1 = TYPE_DOUBLE then*/
    if (_t1_41947 != 2)
    goto LC; // [189] 224

    /** 		if t2 = TYPE_INTEGER then*/
    if (_t2_41948 != 1)
    goto LD; // [197] 212

    /** 			return TYPE_ATOM*/
    DeRef(_22451);
    _22451 = NOVALUE;
    DeRef(_22458);
    _22458 = NOVALUE;
    return 4;
    goto L2; // [209] 307
LD: 

    /** 			return TYPE_DOUBLE*/
    DeRef(_22451);
    _22451 = NOVALUE;
    DeRef(_22458);
    _22458 = NOVALUE;
    return 2;
    goto L2; // [221] 307
LC: 

    /** 	elsif t2 = TYPE_DOUBLE then*/
    if (_t2_41948 != 2)
    goto LE; // [228] 263

    /** 		if t1 = TYPE_INTEGER then*/
    if (_t1_41947 != 1)
    goto LF; // [236] 251

    /** 			return TYPE_ATOM*/
    DeRef(_22451);
    _22451 = NOVALUE;
    DeRef(_22458);
    _22458 = NOVALUE;
    return 4;
    goto L2; // [248] 307
LF: 

    /** 			return TYPE_DOUBLE*/
    DeRef(_22451);
    _22451 = NOVALUE;
    DeRef(_22458);
    _22458 = NOVALUE;
    return 2;
    goto L2; // [260] 307
LE: 

    /** 	elsif t1 = TYPE_INTEGER and t2 = TYPE_INTEGER then*/
    _22465 = (_t1_41947 == 1);
    if (_22465 == 0) {
        goto L10; // [271] 296
    }
    _22467 = (_t2_41948 == 1);
    if (_22467 == 0)
    {
        DeRef(_22467);
        _22467 = NOVALUE;
        goto L10; // [282] 296
    }
    else{
        DeRef(_22467);
        _22467 = NOVALUE;
    }

    /** 		return TYPE_INTEGER*/
    DeRef(_22451);
    _22451 = NOVALUE;
    DeRef(_22458);
    _22458 = NOVALUE;
    DeRef(_22465);
    _22465 = NOVALUE;
    return 1;
    goto L2; // [293] 307
L10: 

    /** 		InternalErr(258, {t1, t2})*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _t1_41947;
    ((int *)_2)[2] = _t2_41948;
    _22468 = MAKE_SEQ(_1);
    _44InternalErr(258, _22468);
    _22468 = NOVALUE;
L2: 
    ;
}


void _57RemoveFromBB(int _s_42018)
{
    int _int_42019 = NOVALUE;
    int _22470 = NOVALUE;
    int _22469 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_s_42018)) {
        _1 = (long)(DBL_PTR(_s_42018)->dbl);
        DeRefDS(_s_42018);
        _s_42018 = _1;
    }

    /** 	for i = 1 to length(BB_info) do*/
    if (IS_SEQUENCE(_57BB_info_41672)){
            _22469 = SEQ_PTR(_57BB_info_41672)->length;
    }
    else {
        _22469 = 1;
    }
    {
        int _i_42021;
        _i_42021 = 1;
L1: 
        if (_i_42021 > _22469){
            goto L2; // [10] 59
        }

        /** 		int = BB_info[i][BB_VAR]*/
        _2 = (int)SEQ_PTR(_57BB_info_41672);
        _22470 = (int)*(((s1_ptr)_2)->base + _i_42021);
        _2 = (int)SEQ_PTR(_22470);
        _int_42019 = (int)*(((s1_ptr)_2)->base + 1);
        if (!IS_ATOM_INT(_int_42019)){
            _int_42019 = (long)DBL_PTR(_int_42019)->dbl;
        }
        _22470 = NOVALUE;

        /** 		if int = s then*/
        if (_int_42019 != _s_42018)
        goto L3; // [33] 52

        /** 			BB_info = remove( BB_info, int )*/
        {
            s1_ptr assign_space = SEQ_PTR(_57BB_info_41672);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_int_42019)) ? _int_42019 : (long)(DBL_PTR(_int_42019)->dbl);
            int stop = (IS_ATOM_INT(_int_42019)) ? _int_42019 : (long)(DBL_PTR(_int_42019)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<0) {
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_57BB_info_41672), start, &_57BB_info_41672 );
                }
                else Tail(SEQ_PTR(_57BB_info_41672), stop+1, &_57BB_info_41672);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_57BB_info_41672), start, &_57BB_info_41672);
            }
            else {
                assign_slice_seq = &assign_space;
                _57BB_info_41672 = Remove_elements(start, stop, (SEQ_PTR(_57BB_info_41672)->ref == 1));
            }
        }

        /** 			return*/
        return;
L3: 

        /** 	end for*/
        _i_42021 = _i_42021 + 1;
        goto L1; // [54] 17
L2: 
        ;
    }

    /** end procedure*/
    return;
    ;
}


void _57SetBBType(int _s_42039, int _t_42040, int _val_42041, int _etype_42042, int _has_delete_42043)
{
    int _found_42044 = NOVALUE;
    int _i_42045 = NOVALUE;
    int _tn_42046 = NOVALUE;
    int _int_42047 = NOVALUE;
    int _sym_42048 = NOVALUE;
    int _mode_42053 = NOVALUE;
    int _gtype_42068 = NOVALUE;
    int _new_type_42105 = NOVALUE;
    int _bbsym_42128 = NOVALUE;
    int _bbi_42264 = NOVALUE;
    int _22589 = NOVALUE;
    int _22588 = NOVALUE;
    int _22587 = NOVALUE;
    int _22585 = NOVALUE;
    int _22584 = NOVALUE;
    int _22583 = NOVALUE;
    int _22581 = NOVALUE;
    int _22580 = NOVALUE;
    int _22578 = NOVALUE;
    int _22576 = NOVALUE;
    int _22575 = NOVALUE;
    int _22573 = NOVALUE;
    int _22571 = NOVALUE;
    int _22570 = NOVALUE;
    int _22569 = NOVALUE;
    int _22568 = NOVALUE;
    int _22567 = NOVALUE;
    int _22566 = NOVALUE;
    int _22565 = NOVALUE;
    int _22564 = NOVALUE;
    int _22563 = NOVALUE;
    int _22560 = NOVALUE;
    int _22556 = NOVALUE;
    int _22551 = NOVALUE;
    int _22549 = NOVALUE;
    int _22548 = NOVALUE;
    int _22547 = NOVALUE;
    int _22545 = NOVALUE;
    int _22543 = NOVALUE;
    int _22542 = NOVALUE;
    int _22541 = NOVALUE;
    int _22539 = NOVALUE;
    int _22538 = NOVALUE;
    int _22536 = NOVALUE;
    int _22535 = NOVALUE;
    int _22534 = NOVALUE;
    int _22532 = NOVALUE;
    int _22531 = NOVALUE;
    int _22528 = NOVALUE;
    int _22527 = NOVALUE;
    int _22526 = NOVALUE;
    int _22524 = NOVALUE;
    int _22522 = NOVALUE;
    int _22521 = NOVALUE;
    int _22519 = NOVALUE;
    int _22518 = NOVALUE;
    int _22517 = NOVALUE;
    int _22515 = NOVALUE;
    int _22514 = NOVALUE;
    int _22503 = NOVALUE;
    int _22501 = NOVALUE;
    int _22498 = NOVALUE;
    int _22497 = NOVALUE;
    int _22494 = NOVALUE;
    int _22493 = NOVALUE;
    int _22492 = NOVALUE;
    int _22490 = NOVALUE;
    int _22489 = NOVALUE;
    int _22488 = NOVALUE;
    int _22486 = NOVALUE;
    int _22485 = NOVALUE;
    int _22483 = NOVALUE;
    int _22480 = NOVALUE;
    int _22478 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_s_42039)) {
        _1 = (long)(DBL_PTR(_s_42039)->dbl);
        DeRefDS(_s_42039);
        _s_42039 = _1;
    }
    if (!IS_ATOM_INT(_t_42040)) {
        _1 = (long)(DBL_PTR(_t_42040)->dbl);
        DeRefDS(_t_42040);
        _t_42040 = _1;
    }
    if (!IS_ATOM_INT(_etype_42042)) {
        _1 = (long)(DBL_PTR(_etype_42042)->dbl);
        DeRefDS(_etype_42042);
        _etype_42042 = _1;
    }
    if (!IS_ATOM_INT(_has_delete_42043)) {
        _1 = (long)(DBL_PTR(_has_delete_42043)->dbl);
        DeRefDS(_has_delete_42043);
        _has_delete_42043 = _1;
    }

    /** 	if has_delete then*/
    if (_has_delete_42043 == 0)
    {
        goto L1; // [13] 27
    }
    else{
    }

    /** 		p_has_delete = 1*/
    _57p_has_delete_41858 = 1;

    /** 		g_has_delete = 1*/
    _57g_has_delete_41857 = 1;
L1: 

    /** 	sym = SymTab[s]*/
    DeRef(_sym_42048);
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _sym_42048 = (int)*(((s1_ptr)_2)->base + _s_42039);
    Ref(_sym_42048);

    /** 	SymTab[s] = 0*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _s_42039);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 	integer mode = sym[S_MODE]*/
    _2 = (int)SEQ_PTR(_sym_42048);
    _mode_42053 = (int)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_mode_42053))
    _mode_42053 = (long)DBL_PTR(_mode_42053)->dbl;

    /** 	if mode = M_NORMAL or mode = M_TEMP  then*/
    _22478 = (_mode_42053 == 1);
    if (_22478 != 0) {
        goto L2; // [61] 76
    }
    _22480 = (_mode_42053 == 3);
    if (_22480 == 0)
    {
        DeRef(_22480);
        _22480 = NOVALUE;
        goto L3; // [72] 1167
    }
    else{
        DeRef(_22480);
        _22480 = NOVALUE;
    }
L2: 

    /** 		found = FALSE*/
    _found_42044 = _13FALSE_434;

    /** 		if mode = M_TEMP then*/
    if (_mode_42053 != 3)
    goto L4; // [89] 465

    /** 			sym[S_GTYPE] = t*/
    _2 = (int)SEQ_PTR(_sym_42048);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42048 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 36);
    _1 = *(int *)_2;
    *(int *)_2 = _t_42040;
    DeRef(_1);

    /** 			sym[S_SEQ_ELEM] = etype*/
    _2 = (int)SEQ_PTR(_sym_42048);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42048 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 33);
    _1 = *(int *)_2;
    *(int *)_2 = _etype_42042;
    DeRef(_1);

    /** 			integer gtype = sym[S_GTYPE]*/
    _2 = (int)SEQ_PTR(_sym_42048);
    _gtype_42068 = (int)*(((s1_ptr)_2)->base + 36);
    if (!IS_ATOM_INT(_gtype_42068))
    _gtype_42068 = (long)DBL_PTR(_gtype_42068)->dbl;

    /** 			if gtype = TYPE_OBJECT*/
    _22483 = (_gtype_42068 == 16);
    if (_22483 != 0) {
        goto L5; // [125] 140
    }
    _22485 = (_gtype_42068 == 8);
    if (_22485 == 0)
    {
        DeRef(_22485);
        _22485 = NOVALUE;
        goto L6; // [136] 213
    }
    else{
        DeRef(_22485);
        _22485 = NOVALUE;
    }
L5: 

    /** 				if val[MIN] < 0 then*/
    _2 = (int)SEQ_PTR(_val_42041);
    _22486 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(GREATEREQ, _22486, 0)){
        _22486 = NOVALUE;
        goto L7; // [148] 165
    }
    _22486 = NOVALUE;

    /** 					sym[S_SEQ_LEN] = NOVALUE*/
    Ref(_35NOVALUE_16099);
    _2 = (int)SEQ_PTR(_sym_42048);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42048 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 32);
    _1 = *(int *)_2;
    *(int *)_2 = _35NOVALUE_16099;
    DeRef(_1);
    goto L8; // [162] 180
L7: 

    /** 					sym[S_SEQ_LEN] = val[MIN]*/
    _2 = (int)SEQ_PTR(_val_42041);
    _22488 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_22488);
    _2 = (int)SEQ_PTR(_sym_42048);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42048 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 32);
    _1 = *(int *)_2;
    *(int *)_2 = _22488;
    if( _1 != _22488 ){
        DeRef(_1);
    }
    _22488 = NOVALUE;
L8: 

    /** 				sym[S_OBJ] = NOVALUE*/
    Ref(_35NOVALUE_16099);
    _2 = (int)SEQ_PTR(_sym_42048);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42048 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _35NOVALUE_16099;
    DeRef(_1);

    /** 				sym[S_OBJ_MIN] = NOVALUE*/
    Ref(_35NOVALUE_16099);
    _2 = (int)SEQ_PTR(_sym_42048);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42048 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 30);
    _1 = *(int *)_2;
    *(int *)_2 = _35NOVALUE_16099;
    DeRef(_1);

    /** 				sym[S_OBJ_MAX] = NOVALUE*/
    Ref(_35NOVALUE_16099);
    _2 = (int)SEQ_PTR(_sym_42048);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42048 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 31);
    _1 = *(int *)_2;
    *(int *)_2 = _35NOVALUE_16099;
    DeRef(_1);
    goto L9; // [210] 252
L6: 

    /** 				sym[S_OBJ_MIN] = val[MIN]*/
    _2 = (int)SEQ_PTR(_val_42041);
    _22489 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_22489);
    _2 = (int)SEQ_PTR(_sym_42048);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42048 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 30);
    _1 = *(int *)_2;
    *(int *)_2 = _22489;
    if( _1 != _22489 ){
        DeRef(_1);
    }
    _22489 = NOVALUE;

    /** 				sym[S_OBJ_MAX] = val[MAX]*/
    _2 = (int)SEQ_PTR(_val_42041);
    _22490 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_22490);
    _2 = (int)SEQ_PTR(_sym_42048);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42048 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 31);
    _1 = *(int *)_2;
    *(int *)_2 = _22490;
    if( _1 != _22490 ){
        DeRef(_1);
    }
    _22490 = NOVALUE;

    /** 				sym[S_SEQ_LEN] = NOVALUE*/
    Ref(_35NOVALUE_16099);
    _2 = (int)SEQ_PTR(_sym_42048);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42048 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 32);
    _1 = *(int *)_2;
    *(int *)_2 = _35NOVALUE_16099;
    DeRef(_1);
L9: 

    /** 			if not Initializing then*/
    if (_35Initializing_16324 != 0)
    goto LA; // [256] 326

    /** 				integer new_type = or_type(temp_name_type[sym[S_TEMP_NAME]][T_GTYPE_NEW], t)*/
    _2 = (int)SEQ_PTR(_sym_42048);
    _22492 = (int)*(((s1_ptr)_2)->base + 34);
    _2 = (int)SEQ_PTR(_35temp_name_type_16326);
    if (!IS_ATOM_INT(_22492)){
        _22493 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_22492)->dbl));
    }
    else{
        _22493 = (int)*(((s1_ptr)_2)->base + _22492);
    }
    _2 = (int)SEQ_PTR(_22493);
    _22494 = (int)*(((s1_ptr)_2)->base + 2);
    _22493 = NOVALUE;
    Ref(_22494);
    _new_type_42105 = _57or_type(_22494, _t_42040);
    _22494 = NOVALUE;
    if (!IS_ATOM_INT(_new_type_42105)) {
        _1 = (long)(DBL_PTR(_new_type_42105)->dbl);
        DeRefDS(_new_type_42105);
        _new_type_42105 = _1;
    }

    /** 				if new_type = TYPE_NULL then*/
    if (_new_type_42105 != 0)
    goto LB; // [290] 304

    /** 					new_type = TYPE_OBJECT*/
    _new_type_42105 = 16;
LB: 

    /** 				temp_name_type[sym[S_TEMP_NAME]][T_GTYPE_NEW] = new_type*/
    _2 = (int)SEQ_PTR(_sym_42048);
    _22497 = (int)*(((s1_ptr)_2)->base + 34);
    _2 = (int)SEQ_PTR(_35temp_name_type_16326);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _35temp_name_type_16326 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_22497))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_22497)->dbl));
    else
    _3 = (int)(_22497 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _new_type_42105;
    DeRef(_1);
    _22498 = NOVALUE;
LA: 

    /** 			tn = sym[S_TEMP_NAME]*/
    _2 = (int)SEQ_PTR(_sym_42048);
    _tn_42046 = (int)*(((s1_ptr)_2)->base + 34);
    if (!IS_ATOM_INT(_tn_42046))
    _tn_42046 = (long)DBL_PTR(_tn_42046)->dbl;

    /** 			i = 1*/
    _i_42045 = 1;

    /** 			while i <= length(BB_info) do*/
LC: 
    if (IS_SEQUENCE(_57BB_info_41672)){
            _22501 = SEQ_PTR(_57BB_info_41672)->length;
    }
    else {
        _22501 = 1;
    }
    if (_i_42045 > _22501)
    goto LD; // [351] 460

    /** 				sequence bbsym*/

    /** 				int = BB_info[i][BB_VAR]*/
    _2 = (int)SEQ_PTR(_57BB_info_41672);
    _22503 = (int)*(((s1_ptr)_2)->base + _i_42045);
    _2 = (int)SEQ_PTR(_22503);
    _int_42047 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_int_42047)){
        _int_42047 = (long)DBL_PTR(_int_42047)->dbl;
    }
    _22503 = NOVALUE;

    /** 				if int = s then*/
    if (_int_42047 != _s_42039)
    goto LE; // [373] 387

    /** 					bbsym = sym*/
    RefDS(_sym_42048);
    DeRef(_bbsym_42128);
    _bbsym_42128 = _sym_42048;
    goto LF; // [384] 398
LE: 

    /** 					bbsym = SymTab[int]*/
    DeRef(_bbsym_42128);
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _bbsym_42128 = (int)*(((s1_ptr)_2)->base + _int_42047);
    Ref(_bbsym_42128);
LF: 

    /** 				int = bbsym[S_MODE]*/
    _2 = (int)SEQ_PTR(_bbsym_42128);
    _int_42047 = (int)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_int_42047))
    _int_42047 = (long)DBL_PTR(_int_42047)->dbl;

    /** 				if int = M_TEMP then*/
    if (_int_42047 != 3)
    goto L10; // [412] 447

    /** 					int = bbsym[S_TEMP_NAME]*/
    _2 = (int)SEQ_PTR(_bbsym_42128);
    _int_42047 = (int)*(((s1_ptr)_2)->base + 34);
    if (!IS_ATOM_INT(_int_42047))
    _int_42047 = (long)DBL_PTR(_int_42047)->dbl;

    /** 					if int = tn then*/
    if (_int_42047 != _tn_42046)
    goto L11; // [426] 446

    /** 						found = TRUE*/
    _found_42044 = _13TRUE_436;

    /** 						exit*/
    DeRefDS(_bbsym_42128);
    _bbsym_42128 = NOVALUE;
    goto LD; // [443] 460
L11: 
L10: 

    /** 				i += 1*/
    _i_42045 = _i_42045 + 1;
    DeRef(_bbsym_42128);
    _bbsym_42128 = NOVALUE;

    /** 			end while*/
    goto LC; // [457] 346
LD: 
    goto L12; // [462] 889
L4: 

    /** 			if t != TYPE_NULL then*/
    if (_t_42040 == 0)
    goto L13; // [469] 824

    /** 				if not Initializing then*/
    if (_35Initializing_16324 != 0)
    goto L14; // [477] 500

    /** 					sym[S_GTYPE_NEW] = or_type(sym[S_GTYPE_NEW], t)*/
    _2 = (int)SEQ_PTR(_sym_42048);
    _22514 = (int)*(((s1_ptr)_2)->base + 38);
    Ref(_22514);
    _22515 = _57or_type(_22514, _t_42040);
    _22514 = NOVALUE;
    _2 = (int)SEQ_PTR(_sym_42048);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42048 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 38);
    _1 = *(int *)_2;
    *(int *)_2 = _22515;
    if( _1 != _22515 ){
        DeRef(_1);
    }
    _22515 = NOVALUE;
L14: 

    /** 				if t = TYPE_SEQUENCE then*/
    if (_t_42040 != 8)
    goto L15; // [504] 633

    /** 					sym[S_SEQ_ELEM_NEW] =*/
    _2 = (int)SEQ_PTR(_sym_42048);
    _22517 = (int)*(((s1_ptr)_2)->base + 40);
    Ref(_22517);
    _22518 = _57or_type(_22517, _etype_42042);
    _22517 = NOVALUE;
    _2 = (int)SEQ_PTR(_sym_42048);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42048 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 40);
    _1 = *(int *)_2;
    *(int *)_2 = _22518;
    if( _1 != _22518 ){
        DeRef(_1);
    }
    _22518 = NOVALUE;

    /** 					if val[MIN] != -1 then*/
    _2 = (int)SEQ_PTR(_val_42041);
    _22519 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _22519, -1)){
        _22519 = NOVALUE;
        goto L16; // [535] 823
    }
    _22519 = NOVALUE;

    /** 						if sym[S_SEQ_LEN_NEW] = -NOVALUE then*/
    _2 = (int)SEQ_PTR(_sym_42048);
    _22521 = (int)*(((s1_ptr)_2)->base + 39);
    if (IS_ATOM_INT(_35NOVALUE_16099)) {
        if ((unsigned long)_35NOVALUE_16099 == 0xC0000000)
        _22522 = (int)NewDouble((double)-0xC0000000);
        else
        _22522 = - _35NOVALUE_16099;
    }
    else {
        _22522 = unary_op(UMINUS, _35NOVALUE_16099);
    }
    if (binary_op_a(NOTEQ, _22521, _22522)){
        _22521 = NOVALUE;
        DeRef(_22522);
        _22522 = NOVALUE;
        goto L17; // [552] 599
    }
    _22521 = NOVALUE;
    DeRef(_22522);
    _22522 = NOVALUE;

    /** 							if val[MIN] < 0 then*/
    _2 = (int)SEQ_PTR(_val_42041);
    _22524 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(GREATEREQ, _22524, 0)){
        _22524 = NOVALUE;
        goto L18; // [564] 581
    }
    _22524 = NOVALUE;

    /** 								sym[S_SEQ_LEN_NEW] = NOVALUE*/
    Ref(_35NOVALUE_16099);
    _2 = (int)SEQ_PTR(_sym_42048);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42048 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 39);
    _1 = *(int *)_2;
    *(int *)_2 = _35NOVALUE_16099;
    DeRef(_1);
    goto L16; // [578] 823
L18: 

    /** 								sym[S_SEQ_LEN_NEW] = val[MIN]*/
    _2 = (int)SEQ_PTR(_val_42041);
    _22526 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_22526);
    _2 = (int)SEQ_PTR(_sym_42048);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42048 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 39);
    _1 = *(int *)_2;
    *(int *)_2 = _22526;
    if( _1 != _22526 ){
        DeRef(_1);
    }
    _22526 = NOVALUE;
    goto L16; // [596] 823
L17: 

    /** 						elsif val[MIN] != sym[S_SEQ_LEN_NEW] then*/
    _2 = (int)SEQ_PTR(_val_42041);
    _22527 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_sym_42048);
    _22528 = (int)*(((s1_ptr)_2)->base + 39);
    if (binary_op_a(EQUALS, _22527, _22528)){
        _22527 = NOVALUE;
        _22528 = NOVALUE;
        goto L16; // [613] 823
    }
    _22527 = NOVALUE;
    _22528 = NOVALUE;

    /** 							sym[S_SEQ_LEN_NEW] = NOVALUE*/
    Ref(_35NOVALUE_16099);
    _2 = (int)SEQ_PTR(_sym_42048);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42048 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 39);
    _1 = *(int *)_2;
    *(int *)_2 = _35NOVALUE_16099;
    DeRef(_1);
    goto L16; // [630] 823
L15: 

    /** 				elsif t = TYPE_INTEGER then*/
    if (_t_42040 != 1)
    goto L19; // [637] 774

    /** 					if sym[S_OBJ_MIN_NEW] = -NOVALUE then*/
    _2 = (int)SEQ_PTR(_sym_42048);
    _22531 = (int)*(((s1_ptr)_2)->base + 41);
    if (IS_ATOM_INT(_35NOVALUE_16099)) {
        if ((unsigned long)_35NOVALUE_16099 == 0xC0000000)
        _22532 = (int)NewDouble((double)-0xC0000000);
        else
        _22532 = - _35NOVALUE_16099;
    }
    else {
        _22532 = unary_op(UMINUS, _35NOVALUE_16099);
    }
    if (binary_op_a(NOTEQ, _22531, _22532)){
        _22531 = NOVALUE;
        DeRef(_22532);
        _22532 = NOVALUE;
        goto L1A; // [654] 689
    }
    _22531 = NOVALUE;
    DeRef(_22532);
    _22532 = NOVALUE;

    /** 						sym[S_OBJ_MIN_NEW] = val[MIN]*/
    _2 = (int)SEQ_PTR(_val_42041);
    _22534 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_22534);
    _2 = (int)SEQ_PTR(_sym_42048);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42048 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 41);
    _1 = *(int *)_2;
    *(int *)_2 = _22534;
    if( _1 != _22534 ){
        DeRef(_1);
    }
    _22534 = NOVALUE;

    /** 						sym[S_OBJ_MAX_NEW] = val[MAX]*/
    _2 = (int)SEQ_PTR(_val_42041);
    _22535 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_22535);
    _2 = (int)SEQ_PTR(_sym_42048);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42048 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 42);
    _1 = *(int *)_2;
    *(int *)_2 = _22535;
    if( _1 != _22535 ){
        DeRef(_1);
    }
    _22535 = NOVALUE;
    goto L16; // [686] 823
L1A: 

    /** 					elsif sym[S_OBJ_MIN_NEW] != NOVALUE then*/
    _2 = (int)SEQ_PTR(_sym_42048);
    _22536 = (int)*(((s1_ptr)_2)->base + 41);
    if (binary_op_a(EQUALS, _22536, _35NOVALUE_16099)){
        _22536 = NOVALUE;
        goto L16; // [699] 823
    }
    _22536 = NOVALUE;

    /** 						if val[MIN] < sym[S_OBJ_MIN_NEW] then*/
    _2 = (int)SEQ_PTR(_val_42041);
    _22538 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_sym_42048);
    _22539 = (int)*(((s1_ptr)_2)->base + 41);
    if (binary_op_a(GREATEREQ, _22538, _22539)){
        _22538 = NOVALUE;
        _22539 = NOVALUE;
        goto L1B; // [717] 736
    }
    _22538 = NOVALUE;
    _22539 = NOVALUE;

    /** 							sym[S_OBJ_MIN_NEW] = val[MIN]*/
    _2 = (int)SEQ_PTR(_val_42041);
    _22541 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_22541);
    _2 = (int)SEQ_PTR(_sym_42048);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42048 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 41);
    _1 = *(int *)_2;
    *(int *)_2 = _22541;
    if( _1 != _22541 ){
        DeRef(_1);
    }
    _22541 = NOVALUE;
L1B: 

    /** 						if val[MAX] > sym[S_OBJ_MAX_NEW] then*/
    _2 = (int)SEQ_PTR(_val_42041);
    _22542 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_sym_42048);
    _22543 = (int)*(((s1_ptr)_2)->base + 42);
    if (binary_op_a(LESSEQ, _22542, _22543)){
        _22542 = NOVALUE;
        _22543 = NOVALUE;
        goto L16; // [750] 823
    }
    _22542 = NOVALUE;
    _22543 = NOVALUE;

    /** 							sym[S_OBJ_MAX_NEW] = val[MAX]*/
    _2 = (int)SEQ_PTR(_val_42041);
    _22545 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_22545);
    _2 = (int)SEQ_PTR(_sym_42048);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42048 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 42);
    _1 = *(int *)_2;
    *(int *)_2 = _22545;
    if( _1 != _22545 ){
        DeRef(_1);
    }
    _22545 = NOVALUE;
    goto L16; // [771] 823
L19: 

    /** 					sym[S_OBJ_MIN_NEW] = NOVALUE*/
    Ref(_35NOVALUE_16099);
    _2 = (int)SEQ_PTR(_sym_42048);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42048 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 41);
    _1 = *(int *)_2;
    *(int *)_2 = _35NOVALUE_16099;
    DeRef(_1);

    /** 					if t = TYPE_OBJECT then*/
    if (_t_42040 != 16)
    goto L1C; // [788] 822

    /** 						sym[S_SEQ_ELEM_NEW] =*/
    _2 = (int)SEQ_PTR(_sym_42048);
    _22547 = (int)*(((s1_ptr)_2)->base + 40);
    Ref(_22547);
    _22548 = _57or_type(_22547, _etype_42042);
    _22547 = NOVALUE;
    _2 = (int)SEQ_PTR(_sym_42048);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42048 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 40);
    _1 = *(int *)_2;
    *(int *)_2 = _22548;
    if( _1 != _22548 ){
        DeRef(_1);
    }
    _22548 = NOVALUE;

    /** 						sym[S_SEQ_LEN_NEW] = NOVALUE*/
    Ref(_35NOVALUE_16099);
    _2 = (int)SEQ_PTR(_sym_42048);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42048 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 39);
    _1 = *(int *)_2;
    *(int *)_2 = _35NOVALUE_16099;
    DeRef(_1);
L1C: 
L16: 
L13: 

    /** 			i = 1*/
    _i_42045 = 1;

    /** 			while i <= length(BB_info) do*/
L1D: 
    if (IS_SEQUENCE(_57BB_info_41672)){
            _22549 = SEQ_PTR(_57BB_info_41672)->length;
    }
    else {
        _22549 = 1;
    }
    if (_i_42045 > _22549)
    goto L1E; // [839] 888

    /** 				int = BB_info[i][BB_VAR]*/
    _2 = (int)SEQ_PTR(_57BB_info_41672);
    _22551 = (int)*(((s1_ptr)_2)->base + _i_42045);
    _2 = (int)SEQ_PTR(_22551);
    _int_42047 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_int_42047)){
        _int_42047 = (long)DBL_PTR(_int_42047)->dbl;
    }
    _22551 = NOVALUE;

    /** 				if int = s then*/
    if (_int_42047 != _s_42039)
    goto L1F; // [859] 877

    /** 					found = TRUE*/
    _found_42044 = _13TRUE_436;

    /** 					exit*/
    goto L1E; // [874] 888
L1F: 

    /** 				i += 1*/
    _i_42045 = _i_42045 + 1;

    /** 			end while*/
    goto L1D; // [885] 834
L1E: 
L12: 

    /** 		if not found then*/
    if (_found_42044 != 0)
    goto L20; // [891] 907

    /** 			BB_info = append(BB_info, repeat(0, 6))*/
    _22556 = Repeat(0, 6);
    RefDS(_22556);
    Append(&_57BB_info_41672, _57BB_info_41672, _22556);
    DeRefDS(_22556);
    _22556 = NOVALUE;
L20: 

    /** 		if t = TYPE_NULL then*/
    if (_t_42040 != 0)
    goto L21; // [911] 949

    /** 			if not found then*/
    if (_found_42044 != 0)
    goto L22; // [917] 1308

    /** 				BB_info[i] = dummy_bb*/
    RefDS(_57dummy_bb_42028);
    _2 = (int)SEQ_PTR(_57BB_info_41672);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _57BB_info_41672 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _i_42045);
    _1 = *(int *)_2;
    *(int *)_2 = _57dummy_bb_42028;
    DeRef(_1);

    /** 				BB_info[i][BB_VAR] = s*/
    _2 = (int)SEQ_PTR(_57BB_info_41672);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _57BB_info_41672 = MAKE_SEQ(_2);
    }
    _3 = (int)(_i_42045 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _s_42039;
    DeRef(_1);
    _22560 = NOVALUE;
    goto L22; // [946] 1308
L21: 

    /** 			sequence bbi = BB_info[i]*/
    DeRef(_bbi_42264);
    _2 = (int)SEQ_PTR(_57BB_info_41672);
    _bbi_42264 = (int)*(((s1_ptr)_2)->base + _i_42045);
    Ref(_bbi_42264);

    /** 			BB_info[i] = 0*/
    _2 = (int)SEQ_PTR(_57BB_info_41672);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _57BB_info_41672 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _i_42045);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 			bbi[BB_VAR] = s*/
    _2 = (int)SEQ_PTR(_bbi_42264);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _bbi_42264 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _s_42039;
    DeRef(_1);

    /** 			bbi[BB_TYPE] = t*/
    _2 = (int)SEQ_PTR(_bbi_42264);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _bbi_42264 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _t_42040;
    DeRef(_1);

    /** 			bbi[BB_DELETE] = has_delete*/
    _2 = (int)SEQ_PTR(_bbi_42264);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _bbi_42264 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 6);
    _1 = *(int *)_2;
    *(int *)_2 = _has_delete_42043;
    DeRef(_1);

    /** 			if t = TYPE_SEQUENCE and val[MIN] = -1 then*/
    _22563 = (_t_42040 == 8);
    if (_22563 == 0) {
        goto L23; // [995] 1077
    }
    _2 = (int)SEQ_PTR(_val_42041);
    _22565 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_22565)) {
        _22566 = (_22565 == -1);
    }
    else {
        _22566 = binary_op(EQUALS, _22565, -1);
    }
    _22565 = NOVALUE;
    if (_22566 == 0) {
        DeRef(_22566);
        _22566 = NOVALUE;
        goto L23; // [1010] 1077
    }
    else {
        if (!IS_ATOM_INT(_22566) && DBL_PTR(_22566)->dbl == 0.0){
            DeRef(_22566);
            _22566 = NOVALUE;
            goto L23; // [1010] 1077
        }
        DeRef(_22566);
        _22566 = NOVALUE;
    }
    DeRef(_22566);
    _22566 = NOVALUE;

    /** 				if found and bbi[BB_ELEM] != TYPE_NULL then*/
    if (_found_42044 == 0) {
        goto L24; // [1015] 1051
    }
    _2 = (int)SEQ_PTR(_bbi_42264);
    _22568 = (int)*(((s1_ptr)_2)->base + 3);
    if (IS_ATOM_INT(_22568)) {
        _22569 = (_22568 != 0);
    }
    else {
        _22569 = binary_op(NOTEQ, _22568, 0);
    }
    _22568 = NOVALUE;
    if (_22569 == 0) {
        DeRef(_22569);
        _22569 = NOVALUE;
        goto L24; // [1030] 1051
    }
    else {
        if (!IS_ATOM_INT(_22569) && DBL_PTR(_22569)->dbl == 0.0){
            DeRef(_22569);
            _22569 = NOVALUE;
            goto L24; // [1030] 1051
        }
        DeRef(_22569);
        _22569 = NOVALUE;
    }
    DeRef(_22569);
    _22569 = NOVALUE;

    /** 					bbi[BB_ELEM] = or_type(bbi[BB_ELEM], etype)*/
    _2 = (int)SEQ_PTR(_bbi_42264);
    _22570 = (int)*(((s1_ptr)_2)->base + 3);
    Ref(_22570);
    _22571 = _57or_type(_22570, _etype_42042);
    _22570 = NOVALUE;
    _2 = (int)SEQ_PTR(_bbi_42264);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _bbi_42264 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = _22571;
    if( _1 != _22571 ){
        DeRef(_1);
    }
    _22571 = NOVALUE;
    goto L25; // [1048] 1060
L24: 

    /** 					bbi[BB_ELEM] = TYPE_NULL*/
    _2 = (int)SEQ_PTR(_bbi_42264);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _bbi_42264 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
L25: 

    /** 				if not found then*/
    if (_found_42044 != 0)
    goto L26; // [1062] 1153

    /** 					bbi[BB_SEQLEN] = NOVALUE*/
    Ref(_35NOVALUE_16099);
    _2 = (int)SEQ_PTR(_bbi_42264);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _bbi_42264 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = _35NOVALUE_16099;
    DeRef(_1);
    goto L26; // [1074] 1153
L23: 

    /** 				bbi[BB_ELEM] = etype*/
    _2 = (int)SEQ_PTR(_bbi_42264);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _bbi_42264 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = _etype_42042;
    DeRef(_1);

    /** 				if t = TYPE_SEQUENCE or t = TYPE_OBJECT then*/
    _22573 = (_t_42040 == 8);
    if (_22573 != 0) {
        goto L27; // [1091] 1106
    }
    _22575 = (_t_42040 == 16);
    if (_22575 == 0)
    {
        DeRef(_22575);
        _22575 = NOVALUE;
        goto L28; // [1102] 1145
    }
    else{
        DeRef(_22575);
        _22575 = NOVALUE;
    }
L27: 

    /** 					if val[MIN] < 0 then*/
    _2 = (int)SEQ_PTR(_val_42041);
    _22576 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(GREATEREQ, _22576, 0)){
        _22576 = NOVALUE;
        goto L29; // [1114] 1129
    }
    _22576 = NOVALUE;

    /** 						bbi[BB_SEQLEN] = NOVALUE*/
    Ref(_35NOVALUE_16099);
    _2 = (int)SEQ_PTR(_bbi_42264);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _bbi_42264 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = _35NOVALUE_16099;
    DeRef(_1);
    goto L2A; // [1126] 1152
L29: 

    /** 						bbi[BB_SEQLEN] = val[MIN]*/
    _2 = (int)SEQ_PTR(_val_42041);
    _22578 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_22578);
    _2 = (int)SEQ_PTR(_bbi_42264);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _bbi_42264 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = _22578;
    if( _1 != _22578 ){
        DeRef(_1);
    }
    _22578 = NOVALUE;
    goto L2A; // [1142] 1152
L28: 

    /** 					bbi[BB_OBJ] = val*/
    RefDS(_val_42041);
    _2 = (int)SEQ_PTR(_bbi_42264);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _bbi_42264 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = _val_42041;
    DeRef(_1);
L2A: 
L26: 

    /** 			BB_info[i] = bbi*/
    RefDS(_bbi_42264);
    _2 = (int)SEQ_PTR(_57BB_info_41672);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _57BB_info_41672 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _i_42045);
    _1 = *(int *)_2;
    *(int *)_2 = _bbi_42264;
    DeRef(_1);
    DeRefDS(_bbi_42264);
    _bbi_42264 = NOVALUE;
    goto L22; // [1164] 1308
L3: 

    /** 	elsif mode = M_CONSTANT then*/
    if (_mode_42053 != 2)
    goto L2B; // [1171] 1307

    /** 		sym[S_GTYPE] = t*/
    _2 = (int)SEQ_PTR(_sym_42048);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42048 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 36);
    _1 = *(int *)_2;
    *(int *)_2 = _t_42040;
    DeRef(_1);

    /** 		sym[S_SEQ_ELEM] = etype*/
    _2 = (int)SEQ_PTR(_sym_42048);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42048 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 33);
    _1 = *(int *)_2;
    *(int *)_2 = _etype_42042;
    DeRef(_1);

    /** 		if sym[S_GTYPE] = TYPE_SEQUENCE or*/
    _2 = (int)SEQ_PTR(_sym_42048);
    _22580 = (int)*(((s1_ptr)_2)->base + 36);
    if (IS_ATOM_INT(_22580)) {
        _22581 = (_22580 == 8);
    }
    else {
        _22581 = binary_op(EQUALS, _22580, 8);
    }
    _22580 = NOVALUE;
    if (IS_ATOM_INT(_22581)) {
        if (_22581 != 0) {
            goto L2C; // [1205] 1226
        }
    }
    else {
        if (DBL_PTR(_22581)->dbl != 0.0) {
            goto L2C; // [1205] 1226
        }
    }
    _2 = (int)SEQ_PTR(_sym_42048);
    _22583 = (int)*(((s1_ptr)_2)->base + 36);
    if (IS_ATOM_INT(_22583)) {
        _22584 = (_22583 == 16);
    }
    else {
        _22584 = binary_op(EQUALS, _22583, 16);
    }
    _22583 = NOVALUE;
    if (_22584 == 0) {
        DeRef(_22584);
        _22584 = NOVALUE;
        goto L2D; // [1222] 1269
    }
    else {
        if (!IS_ATOM_INT(_22584) && DBL_PTR(_22584)->dbl == 0.0){
            DeRef(_22584);
            _22584 = NOVALUE;
            goto L2D; // [1222] 1269
        }
        DeRef(_22584);
        _22584 = NOVALUE;
    }
    DeRef(_22584);
    _22584 = NOVALUE;
L2C: 

    /** 			if val[MIN] < 0 then*/
    _2 = (int)SEQ_PTR(_val_42041);
    _22585 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(GREATEREQ, _22585, 0)){
        _22585 = NOVALUE;
        goto L2E; // [1234] 1251
    }
    _22585 = NOVALUE;

    /** 				sym[S_SEQ_LEN] = NOVALUE*/
    Ref(_35NOVALUE_16099);
    _2 = (int)SEQ_PTR(_sym_42048);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42048 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 32);
    _1 = *(int *)_2;
    *(int *)_2 = _35NOVALUE_16099;
    DeRef(_1);
    goto L2F; // [1248] 1298
L2E: 

    /** 				sym[S_SEQ_LEN] = val[MIN]*/
    _2 = (int)SEQ_PTR(_val_42041);
    _22587 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_22587);
    _2 = (int)SEQ_PTR(_sym_42048);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42048 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 32);
    _1 = *(int *)_2;
    *(int *)_2 = _22587;
    if( _1 != _22587 ){
        DeRef(_1);
    }
    _22587 = NOVALUE;
    goto L2F; // [1266] 1298
L2D: 

    /** 			sym[S_OBJ_MIN] = val[MIN]*/
    _2 = (int)SEQ_PTR(_val_42041);
    _22588 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_22588);
    _2 = (int)SEQ_PTR(_sym_42048);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42048 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 30);
    _1 = *(int *)_2;
    *(int *)_2 = _22588;
    if( _1 != _22588 ){
        DeRef(_1);
    }
    _22588 = NOVALUE;

    /** 			sym[S_OBJ_MAX] = val[MAX]*/
    _2 = (int)SEQ_PTR(_val_42041);
    _22589 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_22589);
    _2 = (int)SEQ_PTR(_sym_42048);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42048 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 31);
    _1 = *(int *)_2;
    *(int *)_2 = _22589;
    if( _1 != _22589 ){
        DeRef(_1);
    }
    _22589 = NOVALUE;
L2F: 

    /** 		sym[S_HAS_DELETE] = has_delete*/
    _2 = (int)SEQ_PTR(_sym_42048);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42048 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 54);
    _1 = *(int *)_2;
    *(int *)_2 = _has_delete_42043;
    DeRef(_1);
L2B: 
L22: 

    /** 	SymTab[s] = sym*/
    RefDS(_sym_42048);
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _s_42039);
    _1 = *(int *)_2;
    *(int *)_2 = _sym_42048;
    DeRef(_1);

    /** end procedure*/
    DeRefDS(_val_42041);
    DeRefDS(_sym_42048);
    DeRef(_22478);
    _22478 = NOVALUE;
    DeRef(_22483);
    _22483 = NOVALUE;
    _22492 = NOVALUE;
    _22497 = NOVALUE;
    DeRef(_22563);
    _22563 = NOVALUE;
    DeRef(_22573);
    _22573 = NOVALUE;
    DeRef(_22581);
    _22581 = NOVALUE;
    return;
    ;
}


void _57CName(int _s_42338)
{
    int _v_42339 = NOVALUE;
    int _mode_42341 = NOVALUE;
    int _22650 = NOVALUE;
    int _22649 = NOVALUE;
    int _22648 = NOVALUE;
    int _22647 = NOVALUE;
    int _22646 = NOVALUE;
    int _22645 = NOVALUE;
    int _22644 = NOVALUE;
    int _22643 = NOVALUE;
    int _22642 = NOVALUE;
    int _22641 = NOVALUE;
    int _22639 = NOVALUE;
    int _22637 = NOVALUE;
    int _22636 = NOVALUE;
    int _22635 = NOVALUE;
    int _22634 = NOVALUE;
    int _22633 = NOVALUE;
    int _22632 = NOVALUE;
    int _22631 = NOVALUE;
    int _22630 = NOVALUE;
    int _22629 = NOVALUE;
    int _22628 = NOVALUE;
    int _22627 = NOVALUE;
    int _22625 = NOVALUE;
    int _22624 = NOVALUE;
    int _22623 = NOVALUE;
    int _22622 = NOVALUE;
    int _22621 = NOVALUE;
    int _22620 = NOVALUE;
    int _22618 = NOVALUE;
    int _22617 = NOVALUE;
    int _22615 = NOVALUE;
    int _22614 = NOVALUE;
    int _22613 = NOVALUE;
    int _22612 = NOVALUE;
    int _22611 = NOVALUE;
    int _22610 = NOVALUE;
    int _22609 = NOVALUE;
    int _22608 = NOVALUE;
    int _22607 = NOVALUE;
    int _22606 = NOVALUE;
    int _22605 = NOVALUE;
    int _22604 = NOVALUE;
    int _22602 = NOVALUE;
    int _22601 = NOVALUE;
    int _22599 = NOVALUE;
    int _22598 = NOVALUE;
    int _22597 = NOVALUE;
    int _22596 = NOVALUE;
    int _22595 = NOVALUE;
    int _22594 = NOVALUE;
    int _22591 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_s_42338)) {
        _1 = (long)(DBL_PTR(_s_42338)->dbl);
        DeRefDS(_s_42338);
        _s_42338 = _1;
    }

    /** 	v = ObjValue(s)*/
    _0 = _v_42339;
    _v_42339 = _57ObjValue(_s_42338);
    DeRef(_0);

    /** 	integer mode = SymTab[s][S_MODE]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _22591 = (int)*(((s1_ptr)_2)->base + _s_42338);
    _2 = (int)SEQ_PTR(_22591);
    _mode_42341 = (int)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_mode_42341)){
        _mode_42341 = (long)DBL_PTR(_mode_42341)->dbl;
    }
    _22591 = NOVALUE;

    /**  	if mode = M_NORMAL then*/
    if (_mode_42341 != 1)
    goto L1; // [29] 240

    /** 		if LeftSym = FALSE and GType(s) = TYPE_INTEGER and v != NOVALUE then*/
    _22594 = (_57LeftSym_41673 == _13FALSE_434);
    if (_22594 == 0) {
        _22595 = 0;
        goto L2; // [43] 61
    }
    _22596 = _57GType(_s_42338);
    if (IS_ATOM_INT(_22596)) {
        _22597 = (_22596 == 1);
    }
    else {
        _22597 = binary_op(EQUALS, _22596, 1);
    }
    DeRef(_22596);
    _22596 = NOVALUE;
    if (IS_ATOM_INT(_22597))
    _22595 = (_22597 != 0);
    else
    _22595 = DBL_PTR(_22597)->dbl != 0.0;
L2: 
    if (_22595 == 0) {
        goto L3; // [61] 84
    }
    if (IS_ATOM_INT(_v_42339) && IS_ATOM_INT(_35NOVALUE_16099)) {
        _22599 = (_v_42339 != _35NOVALUE_16099);
    }
    else {
        _22599 = binary_op(NOTEQ, _v_42339, _35NOVALUE_16099);
    }
    if (_22599 == 0) {
        DeRef(_22599);
        _22599 = NOVALUE;
        goto L3; // [72] 84
    }
    else {
        if (!IS_ATOM_INT(_22599) && DBL_PTR(_22599)->dbl == 0.0){
            DeRef(_22599);
            _22599 = NOVALUE;
            goto L3; // [72] 84
        }
        DeRef(_22599);
        _22599 = NOVALUE;
    }
    DeRef(_22599);
    _22599 = NOVALUE;

    /** 			c_printf("%d", v)*/
    RefDS(_22600);
    Ref(_v_42339);
    _54c_printf(_22600, _v_42339);
    goto L4; // [81] 166
L3: 

    /** 			if SymTab[s][S_SCOPE] > SC_PRIVATE then*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _22601 = (int)*(((s1_ptr)_2)->base + _s_42338);
    _2 = (int)SEQ_PTR(_22601);
    _22602 = (int)*(((s1_ptr)_2)->base + 4);
    _22601 = NOVALUE;
    if (binary_op_a(LESSEQ, _22602, 3)){
        _22602 = NOVALUE;
        goto L5; // [100] 142
    }
    _22602 = NOVALUE;

    /** 				c_printf("_%d", SymTab[s][S_FILE_NO])*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _22604 = (int)*(((s1_ptr)_2)->base + _s_42338);
    _2 = (int)SEQ_PTR(_22604);
    if (!IS_ATOM_INT(_35S_FILE_NO_15913)){
        _22605 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FILE_NO_15913)->dbl));
    }
    else{
        _22605 = (int)*(((s1_ptr)_2)->base + _35S_FILE_NO_15913);
    }
    _22604 = NOVALUE;
    RefDS(_22116);
    Ref(_22605);
    _54c_printf(_22116, _22605);
    _22605 = NOVALUE;

    /** 				c_puts(SymTab[s][S_NAME])*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _22606 = (int)*(((s1_ptr)_2)->base + _s_42338);
    _2 = (int)SEQ_PTR(_22606);
    if (!IS_ATOM_INT(_35S_NAME_15917)){
        _22607 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15917)->dbl));
    }
    else{
        _22607 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15917);
    }
    _22606 = NOVALUE;
    Ref(_22607);
    _54c_puts(_22607);
    _22607 = NOVALUE;
    goto L6; // [139] 165
L5: 

    /** 				c_puts("_")*/
    RefDS(_22095);
    _54c_puts(_22095);

    /** 				c_puts(SymTab[s][S_NAME])*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _22608 = (int)*(((s1_ptr)_2)->base + _s_42338);
    _2 = (int)SEQ_PTR(_22608);
    if (!IS_ATOM_INT(_35S_NAME_15917)){
        _22609 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15917)->dbl));
    }
    else{
        _22609 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15917);
    }
    _22608 = NOVALUE;
    Ref(_22609);
    _54c_puts(_22609);
    _22609 = NOVALUE;
L6: 
L4: 

    /** 		if s != CurrentSub and SymTab[s][S_NREFS] < 2 then*/
    _22610 = (_s_42338 != _35CurrentSub_16252);
    if (_22610 == 0) {
        goto L7; // [174] 222
    }
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _22612 = (int)*(((s1_ptr)_2)->base + _s_42338);
    _2 = (int)SEQ_PTR(_22612);
    _22613 = (int)*(((s1_ptr)_2)->base + 12);
    _22612 = NOVALUE;
    if (IS_ATOM_INT(_22613)) {
        _22614 = (_22613 < 2);
    }
    else {
        _22614 = binary_op(LESS, _22613, 2);
    }
    _22613 = NOVALUE;
    if (_22614 == 0) {
        DeRef(_22614);
        _22614 = NOVALUE;
        goto L7; // [195] 222
    }
    else {
        if (!IS_ATOM_INT(_22614) && DBL_PTR(_22614)->dbl == 0.0){
            DeRef(_22614);
            _22614 = NOVALUE;
            goto L7; // [195] 222
        }
        DeRef(_22614);
        _22614 = NOVALUE;
    }
    DeRef(_22614);
    _22614 = NOVALUE;

    /** 			SymTab[s][S_NREFS] += 1*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_s_42338 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    _22617 = (int)*(((s1_ptr)_2)->base + 12);
    _22615 = NOVALUE;
    if (IS_ATOM_INT(_22617)) {
        _22618 = _22617 + 1;
        if (_22618 > MAXINT){
            _22618 = NewDouble((double)_22618);
        }
    }
    else
    _22618 = binary_op(PLUS, 1, _22617);
    _22617 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 12);
    _1 = *(int *)_2;
    *(int *)_2 = _22618;
    if( _1 != _22618 ){
        DeRef(_1);
    }
    _22618 = NOVALUE;
    _22615 = NOVALUE;
L7: 

    /** 		SetBBType(s, TYPE_NULL, novalue, TYPE_OBJECT, 0) -- record that this var was referenced in this BB*/
    RefDS(_54novalue_45495);
    _57SetBBType(_s_42338, 0, _54novalue_45495, 16, 0);
    goto L8; // [237] 490
L1: 

    /**  	elsif mode = M_CONSTANT then*/
    if (_mode_42341 != 2)
    goto L9; // [244] 419

    /** 		if (integer( sym_obj( s ) ) and SymTab[s][S_GTYPE] != TYPE_DOUBLE ) or (LeftSym = FALSE and TypeIs(s, TYPE_INTEGER) and v != NOVALUE) then*/
    _22620 = _53sym_obj(_s_42338);
    if (IS_ATOM_INT(_22620))
    _22621 = 1;
    else if (IS_ATOM_DBL(_22620))
    _22621 = IS_ATOM_INT(DoubleToInt(_22620));
    else
    _22621 = 0;
    DeRef(_22620);
    _22620 = NOVALUE;
    if (_22621 == 0) {
        _22622 = 0;
        goto LA; // [257] 283
    }
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _22623 = (int)*(((s1_ptr)_2)->base + _s_42338);
    _2 = (int)SEQ_PTR(_22623);
    _22624 = (int)*(((s1_ptr)_2)->base + 36);
    _22623 = NOVALUE;
    if (IS_ATOM_INT(_22624)) {
        _22625 = (_22624 != 2);
    }
    else {
        _22625 = binary_op(NOTEQ, _22624, 2);
    }
    _22624 = NOVALUE;
    if (IS_ATOM_INT(_22625))
    _22622 = (_22625 != 0);
    else
    _22622 = DBL_PTR(_22625)->dbl != 0.0;
LA: 
    if (_22622 != 0) {
        goto LB; // [283] 329
    }
    _22627 = (_57LeftSym_41673 == _13FALSE_434);
    if (_22627 == 0) {
        _22628 = 0;
        goto LC; // [295] 310
    }
    _22629 = _57TypeIs(_s_42338, 1);
    if (IS_ATOM_INT(_22629))
    _22628 = (_22629 != 0);
    else
    _22628 = DBL_PTR(_22629)->dbl != 0.0;
LC: 
    if (_22628 == 0) {
        DeRef(_22630);
        _22630 = 0;
        goto LD; // [310] 324
    }
    if (IS_ATOM_INT(_v_42339) && IS_ATOM_INT(_35NOVALUE_16099)) {
        _22631 = (_v_42339 != _35NOVALUE_16099);
    }
    else {
        _22631 = binary_op(NOTEQ, _v_42339, _35NOVALUE_16099);
    }
    if (IS_ATOM_INT(_22631))
    _22630 = (_22631 != 0);
    else
    _22630 = DBL_PTR(_22631)->dbl != 0.0;
LD: 
    if (_22630 == 0)
    {
        _22630 = NOVALUE;
        goto LE; // [325] 338
    }
    else{
        _22630 = NOVALUE;
    }
LB: 

    /** 			c_printf("%d", v)*/
    RefDS(_22600);
    Ref(_v_42339);
    _54c_printf(_22600, _v_42339);
    goto L8; // [335] 490
LE: 

    /** 			c_printf("_%d", SymTab[s][S_FILE_NO])*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _22632 = (int)*(((s1_ptr)_2)->base + _s_42338);
    _2 = (int)SEQ_PTR(_22632);
    if (!IS_ATOM_INT(_35S_FILE_NO_15913)){
        _22633 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FILE_NO_15913)->dbl));
    }
    else{
        _22633 = (int)*(((s1_ptr)_2)->base + _35S_FILE_NO_15913);
    }
    _22632 = NOVALUE;
    RefDS(_22116);
    Ref(_22633);
    _54c_printf(_22116, _22633);
    _22633 = NOVALUE;

    /** 			c_puts(SymTab[s][S_NAME])*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _22634 = (int)*(((s1_ptr)_2)->base + _s_42338);
    _2 = (int)SEQ_PTR(_22634);
    if (!IS_ATOM_INT(_35S_NAME_15917)){
        _22635 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15917)->dbl));
    }
    else{
        _22635 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15917);
    }
    _22634 = NOVALUE;
    Ref(_22635);
    _54c_puts(_22635);
    _22635 = NOVALUE;

    /** 			if SymTab[s][S_NREFS] < 2 then*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _22636 = (int)*(((s1_ptr)_2)->base + _s_42338);
    _2 = (int)SEQ_PTR(_22636);
    _22637 = (int)*(((s1_ptr)_2)->base + 12);
    _22636 = NOVALUE;
    if (binary_op_a(GREATEREQ, _22637, 2)){
        _22637 = NOVALUE;
        goto L8; // [387] 490
    }
    _22637 = NOVALUE;

    /** 				SymTab[s][S_NREFS] += 1*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_s_42338 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    _22641 = (int)*(((s1_ptr)_2)->base + 12);
    _22639 = NOVALUE;
    if (IS_ATOM_INT(_22641)) {
        _22642 = _22641 + 1;
        if (_22642 > MAXINT){
            _22642 = NewDouble((double)_22642);
        }
    }
    else
    _22642 = binary_op(PLUS, 1, _22641);
    _22641 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 12);
    _1 = *(int *)_2;
    *(int *)_2 = _22642;
    if( _1 != _22642 ){
        DeRef(_1);
    }
    _22642 = NOVALUE;
    _22639 = NOVALUE;
    goto L8; // [416] 490
L9: 

    /** 		if LeftSym = FALSE and GType(s) = TYPE_INTEGER and v != NOVALUE then*/
    _22643 = (_57LeftSym_41673 == _13FALSE_434);
    if (_22643 == 0) {
        _22644 = 0;
        goto LF; // [429] 447
    }
    _22645 = _57GType(_s_42338);
    if (IS_ATOM_INT(_22645)) {
        _22646 = (_22645 == 1);
    }
    else {
        _22646 = binary_op(EQUALS, _22645, 1);
    }
    DeRef(_22645);
    _22645 = NOVALUE;
    if (IS_ATOM_INT(_22646))
    _22644 = (_22646 != 0);
    else
    _22644 = DBL_PTR(_22646)->dbl != 0.0;
LF: 
    if (_22644 == 0) {
        goto L10; // [447] 470
    }
    if (IS_ATOM_INT(_v_42339) && IS_ATOM_INT(_35NOVALUE_16099)) {
        _22648 = (_v_42339 != _35NOVALUE_16099);
    }
    else {
        _22648 = binary_op(NOTEQ, _v_42339, _35NOVALUE_16099);
    }
    if (_22648 == 0) {
        DeRef(_22648);
        _22648 = NOVALUE;
        goto L10; // [458] 470
    }
    else {
        if (!IS_ATOM_INT(_22648) && DBL_PTR(_22648)->dbl == 0.0){
            DeRef(_22648);
            _22648 = NOVALUE;
            goto L10; // [458] 470
        }
        DeRef(_22648);
        _22648 = NOVALUE;
    }
    DeRef(_22648);
    _22648 = NOVALUE;

    /** 			c_printf("%d", v)*/
    RefDS(_22600);
    Ref(_v_42339);
    _54c_printf(_22600, _v_42339);
    goto L11; // [467] 489
L10: 

    /** 			c_printf("_%d", SymTab[s][S_TEMP_NAME])*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _22649 = (int)*(((s1_ptr)_2)->base + _s_42338);
    _2 = (int)SEQ_PTR(_22649);
    _22650 = (int)*(((s1_ptr)_2)->base + 34);
    _22649 = NOVALUE;
    RefDS(_22116);
    Ref(_22650);
    _54c_printf(_22116, _22650);
    _22650 = NOVALUE;
L11: 
L8: 

    /** 	LeftSym = FALSE*/
    _57LeftSym_41673 = _13FALSE_434;

    /** end procedure*/
    DeRef(_v_42339);
    DeRef(_22594);
    _22594 = NOVALUE;
    DeRef(_22610);
    _22610 = NOVALUE;
    DeRef(_22597);
    _22597 = NOVALUE;
    DeRef(_22627);
    _22627 = NOVALUE;
    DeRef(_22625);
    _22625 = NOVALUE;
    DeRef(_22629);
    _22629 = NOVALUE;
    DeRef(_22631);
    _22631 = NOVALUE;
    DeRef(_22643);
    _22643 = NOVALUE;
    DeRef(_22646);
    _22646 = NOVALUE;
    return;
    ;
}


void _57c_stmt(int _stmt_42472, int _arg_42473, int _lhs_arg_42475)
{
    int _argcount_42476 = NOVALUE;
    int _i_42477 = NOVALUE;
    int _22705 = NOVALUE;
    int _22704 = NOVALUE;
    int _22703 = NOVALUE;
    int _22702 = NOVALUE;
    int _22701 = NOVALUE;
    int _22700 = NOVALUE;
    int _22699 = NOVALUE;
    int _22698 = NOVALUE;
    int _22697 = NOVALUE;
    int _22696 = NOVALUE;
    int _22695 = NOVALUE;
    int _22694 = NOVALUE;
    int _22693 = NOVALUE;
    int _22692 = NOVALUE;
    int _22691 = NOVALUE;
    int _22690 = NOVALUE;
    int _22689 = NOVALUE;
    int _22687 = NOVALUE;
    int _22685 = NOVALUE;
    int _22683 = NOVALUE;
    int _22682 = NOVALUE;
    int _22681 = NOVALUE;
    int _22680 = NOVALUE;
    int _22678 = NOVALUE;
    int _22677 = NOVALUE;
    int _22676 = NOVALUE;
    int _22675 = NOVALUE;
    int _22674 = NOVALUE;
    int _22673 = NOVALUE;
    int _22672 = NOVALUE;
    int _22671 = NOVALUE;
    int _22670 = NOVALUE;
    int _22669 = NOVALUE;
    int _22668 = NOVALUE;
    int _22667 = NOVALUE;
    int _22666 = NOVALUE;
    int _22665 = NOVALUE;
    int _22662 = NOVALUE;
    int _22661 = NOVALUE;
    int _22660 = NOVALUE;
    int _22659 = NOVALUE;
    int _22658 = NOVALUE;
    int _22657 = NOVALUE;
    int _22655 = NOVALUE;
    int _22653 = NOVALUE;
    int _22652 = NOVALUE;
    int _22651 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_lhs_arg_42475)) {
        _1 = (long)(DBL_PTR(_lhs_arg_42475)->dbl);
        DeRefDS(_lhs_arg_42475);
        _lhs_arg_42475 = _1;
    }

    /** 	if LAST_PASS = TRUE and Initializing = FALSE then*/
    _22651 = (_57LAST_PASS_41663 == _13TRUE_436);
    if (_22651 == 0) {
        goto L1; // [15] 47
    }
    _22653 = (_35Initializing_16324 == _13FALSE_434);
    if (_22653 == 0)
    {
        DeRef(_22653);
        _22653 = NOVALUE;
        goto L1; // [28] 47
    }
    else{
        DeRef(_22653);
        _22653 = NOVALUE;
    }

    /** 		cfile_size += 1*/
    _35cfile_size_16323 = _35cfile_size_16323 + 1;

    /** 		update_checksum( stmt )*/
    RefDS(_stmt_42472);
    _55update_checksum(_stmt_42472);
L1: 

    /** 	if emit_c_output then*/
    if (_54emit_c_output_45488 == 0)
    {
        goto L2; // [51] 60
    }
    else{
    }

    /** 		adjust_indent_before(stmt)*/
    RefDS(_stmt_42472);
    _54adjust_indent_before(_stmt_42472);
L2: 

    /** 	if atom(arg) then*/
    _22655 = IS_ATOM(_arg_42473);
    if (_22655 == 0)
    {
        _22655 = NOVALUE;
        goto L3; // [65] 75
    }
    else{
        _22655 = NOVALUE;
    }

    /** 		arg = {arg}*/
    _0 = _arg_42473;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_arg_42473);
    *((int *)(_2+4)) = _arg_42473;
    _arg_42473 = MAKE_SEQ(_1);
    DeRef(_0);
L3: 

    /** 	argcount = 1*/
    _argcount_42476 = 1;

    /** 	i = 1*/
    _i_42477 = 1;

    /** 	while i <= length(stmt) and length(stmt) > 0 do*/
L4: 
    if (IS_SEQUENCE(_stmt_42472)){
            _22657 = SEQ_PTR(_stmt_42472)->length;
    }
    else {
        _22657 = 1;
    }
    _22658 = (_i_42477 <= _22657);
    _22657 = NOVALUE;
    if (_22658 == 0) {
        goto L5; // [97] 435
    }
    if (IS_SEQUENCE(_stmt_42472)){
            _22660 = SEQ_PTR(_stmt_42472)->length;
    }
    else {
        _22660 = 1;
    }
    _22661 = (_22660 > 0);
    _22660 = NOVALUE;
    if (_22661 == 0)
    {
        DeRef(_22661);
        _22661 = NOVALUE;
        goto L5; // [109] 435
    }
    else{
        DeRef(_22661);
        _22661 = NOVALUE;
    }

    /** 		if stmt[i] = '@' then*/
    _2 = (int)SEQ_PTR(_stmt_42472);
    _22662 = (int)*(((s1_ptr)_2)->base + _i_42477);
    if (binary_op_a(NOTEQ, _22662, 64)){
        _22662 = NOVALUE;
        goto L6; // [118] 288
    }
    _22662 = NOVALUE;

    /** 			if i = 1 then*/
    if (_i_42477 != 1)
    goto L7; // [124] 138

    /** 				LeftSym = TRUE*/
    _57LeftSym_41673 = _13TRUE_436;
L7: 

    /** 			if i < length(stmt) and stmt[i+1] > '0' and stmt[i+1] <= '9' then*/
    if (IS_SEQUENCE(_stmt_42472)){
            _22665 = SEQ_PTR(_stmt_42472)->length;
    }
    else {
        _22665 = 1;
    }
    _22666 = (_i_42477 < _22665);
    _22665 = NOVALUE;
    if (_22666 == 0) {
        _22667 = 0;
        goto L8; // [147] 167
    }
    _22668 = _i_42477 + 1;
    _2 = (int)SEQ_PTR(_stmt_42472);
    _22669 = (int)*(((s1_ptr)_2)->base + _22668);
    if (IS_ATOM_INT(_22669)) {
        _22670 = (_22669 > 48);
    }
    else {
        _22670 = binary_op(GREATER, _22669, 48);
    }
    _22669 = NOVALUE;
    if (IS_ATOM_INT(_22670))
    _22667 = (_22670 != 0);
    else
    _22667 = DBL_PTR(_22670)->dbl != 0.0;
L8: 
    if (_22667 == 0) {
        goto L9; // [167] 249
    }
    _22672 = _i_42477 + 1;
    _2 = (int)SEQ_PTR(_stmt_42472);
    _22673 = (int)*(((s1_ptr)_2)->base + _22672);
    if (IS_ATOM_INT(_22673)) {
        _22674 = (_22673 <= 57);
    }
    else {
        _22674 = binary_op(LESSEQ, _22673, 57);
    }
    _22673 = NOVALUE;
    if (_22674 == 0) {
        DeRef(_22674);
        _22674 = NOVALUE;
        goto L9; // [184] 249
    }
    else {
        if (!IS_ATOM_INT(_22674) && DBL_PTR(_22674)->dbl == 0.0){
            DeRef(_22674);
            _22674 = NOVALUE;
            goto L9; // [184] 249
        }
        DeRef(_22674);
        _22674 = NOVALUE;
    }
    DeRef(_22674);
    _22674 = NOVALUE;

    /** 				if arg[stmt[i+1]-'0'] = lhs_arg then*/
    _22675 = _i_42477 + 1;
    _2 = (int)SEQ_PTR(_stmt_42472);
    _22676 = (int)*(((s1_ptr)_2)->base + _22675);
    if (IS_ATOM_INT(_22676)) {
        _22677 = _22676 - 48;
    }
    else {
        _22677 = binary_op(MINUS, _22676, 48);
    }
    _22676 = NOVALUE;
    _2 = (int)SEQ_PTR(_arg_42473);
    if (!IS_ATOM_INT(_22677)){
        _22678 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_22677)->dbl));
    }
    else{
        _22678 = (int)*(((s1_ptr)_2)->base + _22677);
    }
    if (binary_op_a(NOTEQ, _22678, _lhs_arg_42475)){
        _22678 = NOVALUE;
        goto LA; // [205] 219
    }
    _22678 = NOVALUE;

    /** 					LeftSym = TRUE*/
    _57LeftSym_41673 = _13TRUE_436;
LA: 

    /** 				CName(arg[stmt[i+1]-'0'])*/
    _22680 = _i_42477 + 1;
    _2 = (int)SEQ_PTR(_stmt_42472);
    _22681 = (int)*(((s1_ptr)_2)->base + _22680);
    if (IS_ATOM_INT(_22681)) {
        _22682 = _22681 - 48;
    }
    else {
        _22682 = binary_op(MINUS, _22681, 48);
    }
    _22681 = NOVALUE;
    _2 = (int)SEQ_PTR(_arg_42473);
    if (!IS_ATOM_INT(_22682)){
        _22683 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_22682)->dbl));
    }
    else{
        _22683 = (int)*(((s1_ptr)_2)->base + _22682);
    }
    Ref(_22683);
    _57CName(_22683);
    _22683 = NOVALUE;

    /** 				i += 1*/
    _i_42477 = _i_42477 + 1;
    goto LB; // [246] 279
L9: 

    /** 				if arg[argcount] = lhs_arg then*/
    _2 = (int)SEQ_PTR(_arg_42473);
    _22685 = (int)*(((s1_ptr)_2)->base + _argcount_42476);
    if (binary_op_a(NOTEQ, _22685, _lhs_arg_42475)){
        _22685 = NOVALUE;
        goto LC; // [255] 269
    }
    _22685 = NOVALUE;

    /** 					LeftSym = TRUE*/
    _57LeftSym_41673 = _13TRUE_436;
LC: 

    /** 				CName(arg[argcount])*/
    _2 = (int)SEQ_PTR(_arg_42473);
    _22687 = (int)*(((s1_ptr)_2)->base + _argcount_42476);
    Ref(_22687);
    _57CName(_22687);
    _22687 = NOVALUE;
LB: 

    /** 			argcount += 1*/
    _argcount_42476 = _argcount_42476 + 1;
    goto LD; // [285] 353
L6: 

    /** 			c_putc(stmt[i])*/
    _2 = (int)SEQ_PTR(_stmt_42472);
    _22689 = (int)*(((s1_ptr)_2)->base + _i_42477);
    Ref(_22689);
    _54c_putc(_22689);
    _22689 = NOVALUE;

    /** 			if stmt[i] = '&' and i < length(stmt) and stmt[i+1] = '@' then*/
    _2 = (int)SEQ_PTR(_stmt_42472);
    _22690 = (int)*(((s1_ptr)_2)->base + _i_42477);
    if (IS_ATOM_INT(_22690)) {
        _22691 = (_22690 == 38);
    }
    else {
        _22691 = binary_op(EQUALS, _22690, 38);
    }
    _22690 = NOVALUE;
    if (IS_ATOM_INT(_22691)) {
        if (_22691 == 0) {
            DeRef(_22692);
            _22692 = 0;
            goto LE; // [307] 322
        }
    }
    else {
        if (DBL_PTR(_22691)->dbl == 0.0) {
            DeRef(_22692);
            _22692 = 0;
            goto LE; // [307] 322
        }
    }
    if (IS_SEQUENCE(_stmt_42472)){
            _22693 = SEQ_PTR(_stmt_42472)->length;
    }
    else {
        _22693 = 1;
    }
    _22694 = (_i_42477 < _22693);
    _22693 = NOVALUE;
    DeRef(_22692);
    _22692 = (_22694 != 0);
LE: 
    if (_22692 == 0) {
        goto LF; // [322] 352
    }
    _22696 = _i_42477 + 1;
    _2 = (int)SEQ_PTR(_stmt_42472);
    _22697 = (int)*(((s1_ptr)_2)->base + _22696);
    if (IS_ATOM_INT(_22697)) {
        _22698 = (_22697 == 64);
    }
    else {
        _22698 = binary_op(EQUALS, _22697, 64);
    }
    _22697 = NOVALUE;
    if (_22698 == 0) {
        DeRef(_22698);
        _22698 = NOVALUE;
        goto LF; // [339] 352
    }
    else {
        if (!IS_ATOM_INT(_22698) && DBL_PTR(_22698)->dbl == 0.0){
            DeRef(_22698);
            _22698 = NOVALUE;
            goto LF; // [339] 352
        }
        DeRef(_22698);
        _22698 = NOVALUE;
    }
    DeRef(_22698);
    _22698 = NOVALUE;

    /** 				LeftSym = TRUE -- never say: x = x &y or andy - always leave space*/
    _57LeftSym_41673 = _13TRUE_436;
LF: 
LD: 

    /** 		if stmt[i] = '\n' and i < length(stmt) then*/
    _2 = (int)SEQ_PTR(_stmt_42472);
    _22699 = (int)*(((s1_ptr)_2)->base + _i_42477);
    if (IS_ATOM_INT(_22699)) {
        _22700 = (_22699 == 10);
    }
    else {
        _22700 = binary_op(EQUALS, _22699, 10);
    }
    _22699 = NOVALUE;
    if (IS_ATOM_INT(_22700)) {
        if (_22700 == 0) {
            goto L10; // [363] 424
        }
    }
    else {
        if (DBL_PTR(_22700)->dbl == 0.0) {
            goto L10; // [363] 424
        }
    }
    if (IS_SEQUENCE(_stmt_42472)){
            _22702 = SEQ_PTR(_stmt_42472)->length;
    }
    else {
        _22702 = 1;
    }
    _22703 = (_i_42477 < _22702);
    _22702 = NOVALUE;
    if (_22703 == 0)
    {
        DeRef(_22703);
        _22703 = NOVALUE;
        goto L10; // [375] 424
    }
    else{
        DeRef(_22703);
        _22703 = NOVALUE;
    }

    /** 			if emit_c_output then*/
    if (_54emit_c_output_45488 == 0)
    {
        goto L11; // [382] 391
    }
    else{
    }

    /** 				adjust_indent_after(stmt)*/
    RefDS(_stmt_42472);
    _54adjust_indent_after(_stmt_42472);
L11: 

    /** 			stmt = stmt[i+1..$]*/
    _22704 = _i_42477 + 1;
    if (_22704 > MAXINT){
        _22704 = NewDouble((double)_22704);
    }
    if (IS_SEQUENCE(_stmt_42472)){
            _22705 = SEQ_PTR(_stmt_42472)->length;
    }
    else {
        _22705 = 1;
    }
    rhs_slice_target = (object_ptr)&_stmt_42472;
    RHS_Slice(_stmt_42472, _22704, _22705);

    /** 			i = 0*/
    _i_42477 = 0;

    /** 			if emit_c_output then*/
    if (_54emit_c_output_45488 == 0)
    {
        goto L12; // [414] 423
    }
    else{
    }

    /** 				adjust_indent_before(stmt)*/
    RefDS(_stmt_42472);
    _54adjust_indent_before(_stmt_42472);
L12: 
L10: 

    /** 		i += 1*/
    _i_42477 = _i_42477 + 1;

    /** 	end while*/
    goto L4; // [432] 90
L5: 

    /** 	if emit_c_output then*/
    if (_54emit_c_output_45488 == 0)
    {
        goto L13; // [439] 448
    }
    else{
    }

    /** 		adjust_indent_after(stmt)*/
    RefDS(_stmt_42472);
    _54adjust_indent_after(_stmt_42472);
L13: 

    /** end procedure*/
    DeRefDS(_stmt_42472);
    DeRef(_arg_42473);
    DeRef(_22651);
    _22651 = NOVALUE;
    DeRef(_22658);
    _22658 = NOVALUE;
    DeRef(_22666);
    _22666 = NOVALUE;
    DeRef(_22668);
    _22668 = NOVALUE;
    DeRef(_22672);
    _22672 = NOVALUE;
    DeRef(_22670);
    _22670 = NOVALUE;
    DeRef(_22675);
    _22675 = NOVALUE;
    DeRef(_22680);
    _22680 = NOVALUE;
    DeRef(_22677);
    _22677 = NOVALUE;
    DeRef(_22694);
    _22694 = NOVALUE;
    DeRef(_22682);
    _22682 = NOVALUE;
    DeRef(_22691);
    _22691 = NOVALUE;
    DeRef(_22696);
    _22696 = NOVALUE;
    DeRef(_22704);
    _22704 = NOVALUE;
    DeRef(_22700);
    _22700 = NOVALUE;
    return;
    ;
}


void _57c_stmt0(int _stmt_42571)
{
    int _0, _1, _2;
    

    /** 	if emit_c_output then*/
    if (_54emit_c_output_45488 == 0)
    {
        goto L1; // [7] 18
    }
    else{
    }

    /** 		c_stmt(stmt, {})*/
    RefDS(_stmt_42571);
    RefDS(_22023);
    _57c_stmt(_stmt_42571, _22023, 0);
L1: 

    /** end procedure*/
    DeRefDS(_stmt_42571);
    return;
    ;
}


void _57DeclareFileVars()
{
    int _s_42577 = NOVALUE;
    int _eentry_42579 = NOVALUE;
    int _22747 = NOVALUE;
    int _22746 = NOVALUE;
    int _22745 = NOVALUE;
    int _22742 = NOVALUE;
    int _22740 = NOVALUE;
    int _22739 = NOVALUE;
    int _22738 = NOVALUE;
    int _22737 = NOVALUE;
    int _22733 = NOVALUE;
    int _22732 = NOVALUE;
    int _22731 = NOVALUE;
    int _22730 = NOVALUE;
    int _22729 = NOVALUE;
    int _22728 = NOVALUE;
    int _22727 = NOVALUE;
    int _22726 = NOVALUE;
    int _22725 = NOVALUE;
    int _22724 = NOVALUE;
    int _22723 = NOVALUE;
    int _22722 = NOVALUE;
    int _22721 = NOVALUE;
    int _22720 = NOVALUE;
    int _22719 = NOVALUE;
    int _22718 = NOVALUE;
    int _22717 = NOVALUE;
    int _22716 = NOVALUE;
    int _22715 = NOVALUE;
    int _22714 = NOVALUE;
    int _22713 = NOVALUE;
    int _22712 = NOVALUE;
    int _22709 = NOVALUE;
    int _0, _1, _2;
    

    /** 	c_puts("// Declaring file vars\n")*/
    RefDS(_22708);
    _54c_puts(_22708);

    /** 	s = SymTab[TopLevelSub][S_NEXT]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _22709 = (int)*(((s1_ptr)_2)->base + _35TopLevelSub_16251);
    _2 = (int)SEQ_PTR(_22709);
    _s_42577 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_42577)){
        _s_42577 = (long)DBL_PTR(_s_42577)->dbl;
    }
    _22709 = NOVALUE;

    /** 	while s do*/
L1: 
    if (_s_42577 == 0)
    {
        goto L2; // [29] 321
    }
    else{
    }

    /** 		eentry = SymTab[s]*/
    DeRef(_eentry_42579);
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _eentry_42579 = (int)*(((s1_ptr)_2)->base + _s_42577);
    Ref(_eentry_42579);

    /** 		if eentry[S_SCOPE] >= SC_LOCAL*/
    _2 = (int)SEQ_PTR(_eentry_42579);
    _22712 = (int)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_22712)) {
        _22713 = (_22712 >= 5);
    }
    else {
        _22713 = binary_op(GREATEREQ, _22712, 5);
    }
    _22712 = NOVALUE;
    if (IS_ATOM_INT(_22713)) {
        if (_22713 == 0) {
            DeRef(_22714);
            _22714 = 0;
            goto L3; // [56] 116
        }
    }
    else {
        if (DBL_PTR(_22713)->dbl == 0.0) {
            DeRef(_22714);
            _22714 = 0;
            goto L3; // [56] 116
        }
    }
    _2 = (int)SEQ_PTR(_eentry_42579);
    _22715 = (int)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_22715)) {
        _22716 = (_22715 <= 6);
    }
    else {
        _22716 = binary_op(LESSEQ, _22715, 6);
    }
    _22715 = NOVALUE;
    if (IS_ATOM_INT(_22716)) {
        if (_22716 != 0) {
            DeRef(_22717);
            _22717 = 1;
            goto L4; // [72] 92
        }
    }
    else {
        if (DBL_PTR(_22716)->dbl != 0.0) {
            DeRef(_22717);
            _22717 = 1;
            goto L4; // [72] 92
        }
    }
    _2 = (int)SEQ_PTR(_eentry_42579);
    _22718 = (int)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_22718)) {
        _22719 = (_22718 == 11);
    }
    else {
        _22719 = binary_op(EQUALS, _22718, 11);
    }
    _22718 = NOVALUE;
    DeRef(_22717);
    if (IS_ATOM_INT(_22719))
    _22717 = (_22719 != 0);
    else
    _22717 = DBL_PTR(_22719)->dbl != 0.0;
L4: 
    if (_22717 != 0) {
        _22720 = 1;
        goto L5; // [92] 112
    }
    _2 = (int)SEQ_PTR(_eentry_42579);
    _22721 = (int)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_22721)) {
        _22722 = (_22721 == 13);
    }
    else {
        _22722 = binary_op(EQUALS, _22721, 13);
    }
    _22721 = NOVALUE;
    if (IS_ATOM_INT(_22722))
    _22720 = (_22722 != 0);
    else
    _22720 = DBL_PTR(_22722)->dbl != 0.0;
L5: 
    DeRef(_22714);
    _22714 = (_22720 != 0);
L3: 
    if (_22714 == 0) {
        _22723 = 0;
        goto L6; // [116] 136
    }
    _2 = (int)SEQ_PTR(_eentry_42579);
    _22724 = (int)*(((s1_ptr)_2)->base + 5);
    if (IS_ATOM_INT(_22724)) {
        _22725 = (_22724 != 0);
    }
    else {
        _22725 = binary_op(NOTEQ, _22724, 0);
    }
    _22724 = NOVALUE;
    if (IS_ATOM_INT(_22725))
    _22723 = (_22725 != 0);
    else
    _22723 = DBL_PTR(_22725)->dbl != 0.0;
L6: 
    if (_22723 == 0) {
        _22726 = 0;
        goto L7; // [136] 156
    }
    _2 = (int)SEQ_PTR(_eentry_42579);
    _22727 = (int)*(((s1_ptr)_2)->base + 5);
    if (IS_ATOM_INT(_22727)) {
        _22728 = (_22727 != 99);
    }
    else {
        _22728 = binary_op(NOTEQ, _22727, 99);
    }
    _22727 = NOVALUE;
    if (IS_ATOM_INT(_22728))
    _22726 = (_22728 != 0);
    else
    _22726 = DBL_PTR(_22728)->dbl != 0.0;
L7: 
    if (_22726 == 0) {
        goto L8; // [156] 300
    }
    _2 = (int)SEQ_PTR(_eentry_42579);
    if (!IS_ATOM_INT(_35S_TOKEN_15922)){
        _22730 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TOKEN_15922)->dbl));
    }
    else{
        _22730 = (int)*(((s1_ptr)_2)->base + _35S_TOKEN_15922);
    }
    _22731 = find_from(_22730, _37RTN_TOKS_15870, 1);
    _22730 = NOVALUE;
    _22732 = (_22731 == 0);
    _22731 = NOVALUE;
    if (_22732 == 0)
    {
        DeRef(_22732);
        _22732 = NOVALUE;
        goto L8; // [177] 300
    }
    else{
        DeRef(_22732);
        _22732 = NOVALUE;
    }

    /** 			if eentry[S_TOKEN] = PROC then*/
    _2 = (int)SEQ_PTR(_eentry_42579);
    if (!IS_ATOM_INT(_35S_TOKEN_15922)){
        _22733 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TOKEN_15922)->dbl));
    }
    else{
        _22733 = (int)*(((s1_ptr)_2)->base + _35S_TOKEN_15922);
    }
    if (binary_op_a(NOTEQ, _22733, 27)){
        _22733 = NOVALUE;
        goto L9; // [190] 202
    }
    _22733 = NOVALUE;

    /** 				c_puts( "void ")*/
    RefDS(_22735);
    _54c_puts(_22735);
    goto LA; // [199] 208
L9: 

    /** 				c_puts("int ")*/
    RefDS(_22736);
    _54c_puts(_22736);
LA: 

    /** 			c_printf("_%d", eentry[S_FILE_NO])*/
    _2 = (int)SEQ_PTR(_eentry_42579);
    if (!IS_ATOM_INT(_35S_FILE_NO_15913)){
        _22737 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FILE_NO_15913)->dbl));
    }
    else{
        _22737 = (int)*(((s1_ptr)_2)->base + _35S_FILE_NO_15913);
    }
    RefDS(_22116);
    Ref(_22737);
    _54c_printf(_22116, _22737);
    _22737 = NOVALUE;

    /** 			c_puts(eentry[S_NAME])*/
    _2 = (int)SEQ_PTR(_eentry_42579);
    if (!IS_ATOM_INT(_35S_NAME_15917)){
        _22738 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15917)->dbl));
    }
    else{
        _22738 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15917);
    }
    Ref(_22738);
    _54c_puts(_22738);
    _22738 = NOVALUE;

    /** 			if integer( eentry[S_OBJ] ) then*/
    _2 = (int)SEQ_PTR(_eentry_42579);
    _22739 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_22739))
    _22740 = 1;
    else if (IS_ATOM_DBL(_22739))
    _22740 = IS_ATOM_INT(DoubleToInt(_22739));
    else
    _22740 = 0;
    _22739 = NOVALUE;
    if (_22740 == 0)
    {
        _22740 = NOVALUE;
        goto LB; // [242] 260
    }
    else{
        _22740 = NOVALUE;
    }

    /** 					c_printf(" = %d;\n", eentry[S_OBJ] )*/
    _2 = (int)SEQ_PTR(_eentry_42579);
    _22742 = (int)*(((s1_ptr)_2)->base + 1);
    RefDS(_22741);
    Ref(_22742);
    _54c_printf(_22741, _22742);
    _22742 = NOVALUE;
    goto LC; // [257] 266
LB: 

    /** 				c_puts(" = NOVALUE;\n")*/
    RefDS(_22743);
    _54c_puts(_22743);
LC: 

    /** 			c_hputs("extern int ")*/
    RefDS(_22744);
    _54c_hputs(_22744);

    /** 			c_hprintf("_%d", eentry[S_FILE_NO])*/
    _2 = (int)SEQ_PTR(_eentry_42579);
    if (!IS_ATOM_INT(_35S_FILE_NO_15913)){
        _22745 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FILE_NO_15913)->dbl));
    }
    else{
        _22745 = (int)*(((s1_ptr)_2)->base + _35S_FILE_NO_15913);
    }
    RefDS(_22116);
    Ref(_22745);
    _54c_hprintf(_22116, _22745);
    _22745 = NOVALUE;

    /** 			c_hputs(eentry[S_NAME])*/
    _2 = (int)SEQ_PTR(_eentry_42579);
    if (!IS_ATOM_INT(_35S_NAME_15917)){
        _22746 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15917)->dbl));
    }
    else{
        _22746 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15917);
    }
    Ref(_22746);
    _54c_hputs(_22746);
    _22746 = NOVALUE;

    /** 			c_hputs(";\n")*/
    RefDS(_22253);
    _54c_hputs(_22253);
L8: 

    /** 		s = SymTab[s][S_NEXT]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _22747 = (int)*(((s1_ptr)_2)->base + _s_42577);
    _2 = (int)SEQ_PTR(_22747);
    _s_42577 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_42577)){
        _s_42577 = (long)DBL_PTR(_s_42577)->dbl;
    }
    _22747 = NOVALUE;

    /** 	end while*/
    goto L1; // [318] 29
L2: 

    /** 	c_puts("\n")*/
    RefDS(_22175);
    _54c_puts(_22175);

    /** 	c_hputs("\n")*/
    RefDS(_22175);
    _54c_hputs(_22175);

    /** end procedure*/
    DeRef(_eentry_42579);
    DeRef(_22713);
    _22713 = NOVALUE;
    DeRef(_22716);
    _22716 = NOVALUE;
    DeRef(_22719);
    _22719 = NOVALUE;
    DeRef(_22722);
    _22722 = NOVALUE;
    DeRef(_22725);
    _22725 = NOVALUE;
    DeRef(_22728);
    _22728 = NOVALUE;
    return;
    ;
}


int _57PromoteTypeInfo()
{
    int _updsym_42671 = NOVALUE;
    int _s_42673 = NOVALUE;
    int _sym_42674 = NOVALUE;
    int _symo_42675 = NOVALUE;
    int _upd_42904 = NOVALUE;
    int _22847 = NOVALUE;
    int _22845 = NOVALUE;
    int _22844 = NOVALUE;
    int _22843 = NOVALUE;
    int _22842 = NOVALUE;
    int _22840 = NOVALUE;
    int _22838 = NOVALUE;
    int _22837 = NOVALUE;
    int _22836 = NOVALUE;
    int _22835 = NOVALUE;
    int _22834 = NOVALUE;
    int _22830 = NOVALUE;
    int _22827 = NOVALUE;
    int _22826 = NOVALUE;
    int _22825 = NOVALUE;
    int _22824 = NOVALUE;
    int _22823 = NOVALUE;
    int _22822 = NOVALUE;
    int _22821 = NOVALUE;
    int _22820 = NOVALUE;
    int _22819 = NOVALUE;
    int _22818 = NOVALUE;
    int _22817 = NOVALUE;
    int _22815 = NOVALUE;
    int _22814 = NOVALUE;
    int _22813 = NOVALUE;
    int _22812 = NOVALUE;
    int _22811 = NOVALUE;
    int _22810 = NOVALUE;
    int _22809 = NOVALUE;
    int _22808 = NOVALUE;
    int _22807 = NOVALUE;
    int _22806 = NOVALUE;
    int _22804 = NOVALUE;
    int _22803 = NOVALUE;
    int _22802 = NOVALUE;
    int _22800 = NOVALUE;
    int _22799 = NOVALUE;
    int _22798 = NOVALUE;
    int _22796 = NOVALUE;
    int _22795 = NOVALUE;
    int _22794 = NOVALUE;
    int _22793 = NOVALUE;
    int _22792 = NOVALUE;
    int _22791 = NOVALUE;
    int _22790 = NOVALUE;
    int _22788 = NOVALUE;
    int _22787 = NOVALUE;
    int _22786 = NOVALUE;
    int _22785 = NOVALUE;
    int _22783 = NOVALUE;
    int _22782 = NOVALUE;
    int _22780 = NOVALUE;
    int _22779 = NOVALUE;
    int _22778 = NOVALUE;
    int _22777 = NOVALUE;
    int _22776 = NOVALUE;
    int _22775 = NOVALUE;
    int _22774 = NOVALUE;
    int _22772 = NOVALUE;
    int _22771 = NOVALUE;
    int _22770 = NOVALUE;
    int _22769 = NOVALUE;
    int _22768 = NOVALUE;
    int _22767 = NOVALUE;
    int _22766 = NOVALUE;
    int _22765 = NOVALUE;
    int _22764 = NOVALUE;
    int _22763 = NOVALUE;
    int _22762 = NOVALUE;
    int _22761 = NOVALUE;
    int _22760 = NOVALUE;
    int _22759 = NOVALUE;
    int _22757 = NOVALUE;
    int _22756 = NOVALUE;
    int _22755 = NOVALUE;
    int _22753 = NOVALUE;
    int _22752 = NOVALUE;
    int _22749 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	sequence sym, symo*/

    /** 	updsym = 0*/
    _updsym_42671 = 0;

    /** 	g_has_delete = p_has_delete*/
    _57g_has_delete_41857 = _57p_has_delete_41858;

    /** 	s = SymTab[TopLevelSub][S_NEXT]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _22749 = (int)*(((s1_ptr)_2)->base + _35TopLevelSub_16251);
    _2 = (int)SEQ_PTR(_22749);
    _s_42673 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_42673)){
        _s_42673 = (long)DBL_PTR(_s_42673)->dbl;
    }
    _22749 = NOVALUE;

    /** 	while s do*/
L1: 
    if (_s_42673 == 0)
    {
        goto L2; // [38] 921
    }
    else{
    }

    /** 		sym = SymTab[s]*/
    DeRef(_sym_42674);
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _sym_42674 = (int)*(((s1_ptr)_2)->base + _s_42673);
    Ref(_sym_42674);

    /** 		symo = sym*/
    RefDS(_sym_42674);
    DeRef(_symo_42675);
    _symo_42675 = _sym_42674;

    /** 		if sym[S_TOKEN] = FUNC or sym[S_TOKEN] = TYPE then*/
    _2 = (int)SEQ_PTR(_sym_42674);
    if (!IS_ATOM_INT(_35S_TOKEN_15922)){
        _22752 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TOKEN_15922)->dbl));
    }
    else{
        _22752 = (int)*(((s1_ptr)_2)->base + _35S_TOKEN_15922);
    }
    if (IS_ATOM_INT(_22752)) {
        _22753 = (_22752 == 501);
    }
    else {
        _22753 = binary_op(EQUALS, _22752, 501);
    }
    _22752 = NOVALUE;
    if (IS_ATOM_INT(_22753)) {
        if (_22753 != 0) {
            goto L3; // [72] 93
        }
    }
    else {
        if (DBL_PTR(_22753)->dbl != 0.0) {
            goto L3; // [72] 93
        }
    }
    _2 = (int)SEQ_PTR(_sym_42674);
    if (!IS_ATOM_INT(_35S_TOKEN_15922)){
        _22755 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TOKEN_15922)->dbl));
    }
    else{
        _22755 = (int)*(((s1_ptr)_2)->base + _35S_TOKEN_15922);
    }
    if (IS_ATOM_INT(_22755)) {
        _22756 = (_22755 == 504);
    }
    else {
        _22756 = binary_op(EQUALS, _22755, 504);
    }
    _22755 = NOVALUE;
    if (_22756 == 0) {
        DeRef(_22756);
        _22756 = NOVALUE;
        goto L4; // [89] 138
    }
    else {
        if (!IS_ATOM_INT(_22756) && DBL_PTR(_22756)->dbl == 0.0){
            DeRef(_22756);
            _22756 = NOVALUE;
            goto L4; // [89] 138
        }
        DeRef(_22756);
        _22756 = NOVALUE;
    }
    DeRef(_22756);
    _22756 = NOVALUE;
L3: 

    /** 			if sym[S_GTYPE_NEW] = TYPE_NULL then*/
    _2 = (int)SEQ_PTR(_sym_42674);
    _22757 = (int)*(((s1_ptr)_2)->base + 38);
    if (binary_op_a(NOTEQ, _22757, 0)){
        _22757 = NOVALUE;
        goto L5; // [103] 120
    }
    _22757 = NOVALUE;

    /** 				sym[S_GTYPE] = TYPE_OBJECT*/
    _2 = (int)SEQ_PTR(_sym_42674);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42674 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 36);
    _1 = *(int *)_2;
    *(int *)_2 = 16;
    DeRef(_1);
    goto L6; // [117] 549
L5: 

    /** 				sym[S_GTYPE] = sym[S_GTYPE_NEW]*/
    _2 = (int)SEQ_PTR(_sym_42674);
    _22759 = (int)*(((s1_ptr)_2)->base + 38);
    Ref(_22759);
    _2 = (int)SEQ_PTR(_sym_42674);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42674 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 36);
    _1 = *(int *)_2;
    *(int *)_2 = _22759;
    if( _1 != _22759 ){
        DeRef(_1);
    }
    _22759 = NOVALUE;
    goto L6; // [135] 549
L4: 

    /** 			if sym[S_GTYPE] != TYPE_INTEGER and*/
    _2 = (int)SEQ_PTR(_sym_42674);
    _22760 = (int)*(((s1_ptr)_2)->base + 36);
    if (IS_ATOM_INT(_22760)) {
        _22761 = (_22760 != 1);
    }
    else {
        _22761 = binary_op(NOTEQ, _22760, 1);
    }
    _22760 = NOVALUE;
    if (IS_ATOM_INT(_22761)) {
        if (_22761 == 0) {
            DeRef(_22762);
            _22762 = 0;
            goto L7; // [152] 172
        }
    }
    else {
        if (DBL_PTR(_22761)->dbl == 0.0) {
            DeRef(_22762);
            _22762 = 0;
            goto L7; // [152] 172
        }
    }
    _2 = (int)SEQ_PTR(_sym_42674);
    _22763 = (int)*(((s1_ptr)_2)->base + 38);
    if (IS_ATOM_INT(_22763)) {
        _22764 = (_22763 != 16);
    }
    else {
        _22764 = binary_op(NOTEQ, _22763, 16);
    }
    _22763 = NOVALUE;
    DeRef(_22762);
    if (IS_ATOM_INT(_22764))
    _22762 = (_22764 != 0);
    else
    _22762 = DBL_PTR(_22764)->dbl != 0.0;
L7: 
    if (_22762 == 0) {
        goto L8; // [172] 283
    }
    _2 = (int)SEQ_PTR(_sym_42674);
    _22766 = (int)*(((s1_ptr)_2)->base + 38);
    if (IS_ATOM_INT(_22766)) {
        _22767 = (_22766 != 0);
    }
    else {
        _22767 = binary_op(NOTEQ, _22766, 0);
    }
    _22766 = NOVALUE;
    if (_22767 == 0) {
        DeRef(_22767);
        _22767 = NOVALUE;
        goto L8; // [189] 283
    }
    else {
        if (!IS_ATOM_INT(_22767) && DBL_PTR(_22767)->dbl == 0.0){
            DeRef(_22767);
            _22767 = NOVALUE;
            goto L8; // [189] 283
        }
        DeRef(_22767);
        _22767 = NOVALUE;
    }
    DeRef(_22767);
    _22767 = NOVALUE;

    /** 				if sym[S_GTYPE_NEW] = TYPE_INTEGER or*/
    _2 = (int)SEQ_PTR(_sym_42674);
    _22768 = (int)*(((s1_ptr)_2)->base + 38);
    if (IS_ATOM_INT(_22768)) {
        _22769 = (_22768 == 1);
    }
    else {
        _22769 = binary_op(EQUALS, _22768, 1);
    }
    _22768 = NOVALUE;
    if (IS_ATOM_INT(_22769)) {
        if (_22769 != 0) {
            DeRef(_22770);
            _22770 = 1;
            goto L9; // [206] 226
        }
    }
    else {
        if (DBL_PTR(_22769)->dbl != 0.0) {
            DeRef(_22770);
            _22770 = 1;
            goto L9; // [206] 226
        }
    }
    _2 = (int)SEQ_PTR(_sym_42674);
    _22771 = (int)*(((s1_ptr)_2)->base + 36);
    if (IS_ATOM_INT(_22771)) {
        _22772 = (_22771 == 16);
    }
    else {
        _22772 = binary_op(EQUALS, _22771, 16);
    }
    _22771 = NOVALUE;
    DeRef(_22770);
    if (IS_ATOM_INT(_22772))
    _22770 = (_22772 != 0);
    else
    _22770 = DBL_PTR(_22772)->dbl != 0.0;
L9: 
    if (_22770 != 0) {
        goto LA; // [226] 267
    }
    _2 = (int)SEQ_PTR(_sym_42674);
    _22774 = (int)*(((s1_ptr)_2)->base + 36);
    if (IS_ATOM_INT(_22774)) {
        _22775 = (_22774 == 4);
    }
    else {
        _22775 = binary_op(EQUALS, _22774, 4);
    }
    _22774 = NOVALUE;
    if (IS_ATOM_INT(_22775)) {
        if (_22775 == 0) {
            DeRef(_22776);
            _22776 = 0;
            goto LB; // [242] 262
        }
    }
    else {
        if (DBL_PTR(_22775)->dbl == 0.0) {
            DeRef(_22776);
            _22776 = 0;
            goto LB; // [242] 262
        }
    }
    _2 = (int)SEQ_PTR(_sym_42674);
    _22777 = (int)*(((s1_ptr)_2)->base + 38);
    if (IS_ATOM_INT(_22777)) {
        _22778 = (_22777 == 2);
    }
    else {
        _22778 = binary_op(EQUALS, _22777, 2);
    }
    _22777 = NOVALUE;
    DeRef(_22776);
    if (IS_ATOM_INT(_22778))
    _22776 = (_22778 != 0);
    else
    _22776 = DBL_PTR(_22778)->dbl != 0.0;
LB: 
    if (_22776 == 0)
    {
        _22776 = NOVALUE;
        goto LC; // [263] 282
    }
    else{
        _22776 = NOVALUE;
    }
LA: 

    /** 						sym[S_GTYPE] = sym[S_GTYPE_NEW]*/
    _2 = (int)SEQ_PTR(_sym_42674);
    _22779 = (int)*(((s1_ptr)_2)->base + 38);
    Ref(_22779);
    _2 = (int)SEQ_PTR(_sym_42674);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42674 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 36);
    _1 = *(int *)_2;
    *(int *)_2 = _22779;
    if( _1 != _22779 ){
        DeRef(_1);
    }
    _22779 = NOVALUE;
LC: 
L8: 

    /** 			if sym[S_ARG_TYPE_NEW] = TYPE_NULL then*/
    _2 = (int)SEQ_PTR(_sym_42674);
    _22780 = (int)*(((s1_ptr)_2)->base + 44);
    if (binary_op_a(NOTEQ, _22780, 0)){
        _22780 = NOVALUE;
        goto LD; // [293] 310
    }
    _22780 = NOVALUE;

    /** 				sym[S_ARG_TYPE] = TYPE_OBJECT*/
    _2 = (int)SEQ_PTR(_sym_42674);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42674 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 43);
    _1 = *(int *)_2;
    *(int *)_2 = 16;
    DeRef(_1);
    goto LE; // [307] 325
LD: 

    /** 				sym[S_ARG_TYPE] = sym[S_ARG_TYPE_NEW]*/
    _2 = (int)SEQ_PTR(_sym_42674);
    _22782 = (int)*(((s1_ptr)_2)->base + 44);
    Ref(_22782);
    _2 = (int)SEQ_PTR(_sym_42674);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42674 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 43);
    _1 = *(int *)_2;
    *(int *)_2 = _22782;
    if( _1 != _22782 ){
        DeRef(_1);
    }
    _22782 = NOVALUE;
LE: 

    /** 			sym[S_ARG_TYPE_NEW] = TYPE_NULL*/
    _2 = (int)SEQ_PTR(_sym_42674);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42674 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 44);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 			if sym[S_ARG_SEQ_ELEM_NEW] = TYPE_NULL then*/
    _2 = (int)SEQ_PTR(_sym_42674);
    _22783 = (int)*(((s1_ptr)_2)->base + 46);
    if (binary_op_a(NOTEQ, _22783, 0)){
        _22783 = NOVALUE;
        goto LF; // [345] 362
    }
    _22783 = NOVALUE;

    /** 				sym[S_ARG_SEQ_ELEM] = TYPE_OBJECT*/
    _2 = (int)SEQ_PTR(_sym_42674);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42674 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 45);
    _1 = *(int *)_2;
    *(int *)_2 = 16;
    DeRef(_1);
    goto L10; // [359] 377
LF: 

    /** 				sym[S_ARG_SEQ_ELEM] = sym[S_ARG_SEQ_ELEM_NEW]*/
    _2 = (int)SEQ_PTR(_sym_42674);
    _22785 = (int)*(((s1_ptr)_2)->base + 46);
    Ref(_22785);
    _2 = (int)SEQ_PTR(_sym_42674);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42674 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 45);
    _1 = *(int *)_2;
    *(int *)_2 = _22785;
    if( _1 != _22785 ){
        DeRef(_1);
    }
    _22785 = NOVALUE;
L10: 

    /** 			sym[S_ARG_SEQ_ELEM_NEW] = TYPE_NULL*/
    _2 = (int)SEQ_PTR(_sym_42674);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42674 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 46);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 			if sym[S_ARG_MIN_NEW] = -NOVALUE or*/
    _2 = (int)SEQ_PTR(_sym_42674);
    _22786 = (int)*(((s1_ptr)_2)->base + 49);
    if (IS_ATOM_INT(_35NOVALUE_16099)) {
        if ((unsigned long)_35NOVALUE_16099 == 0xC0000000)
        _22787 = (int)NewDouble((double)-0xC0000000);
        else
        _22787 = - _35NOVALUE_16099;
    }
    else {
        _22787 = unary_op(UMINUS, _35NOVALUE_16099);
    }
    if (IS_ATOM_INT(_22786) && IS_ATOM_INT(_22787)) {
        _22788 = (_22786 == _22787);
    }
    else {
        _22788 = binary_op(EQUALS, _22786, _22787);
    }
    _22786 = NOVALUE;
    DeRef(_22787);
    _22787 = NOVALUE;
    if (IS_ATOM_INT(_22788)) {
        if (_22788 != 0) {
            goto L11; // [404] 425
        }
    }
    else {
        if (DBL_PTR(_22788)->dbl != 0.0) {
            goto L11; // [404] 425
        }
    }
    _2 = (int)SEQ_PTR(_sym_42674);
    _22790 = (int)*(((s1_ptr)_2)->base + 49);
    if (IS_ATOM_INT(_22790) && IS_ATOM_INT(_35NOVALUE_16099)) {
        _22791 = (_22790 == _35NOVALUE_16099);
    }
    else {
        _22791 = binary_op(EQUALS, _22790, _35NOVALUE_16099);
    }
    _22790 = NOVALUE;
    if (_22791 == 0) {
        DeRef(_22791);
        _22791 = NOVALUE;
        goto L12; // [421] 448
    }
    else {
        if (!IS_ATOM_INT(_22791) && DBL_PTR(_22791)->dbl == 0.0){
            DeRef(_22791);
            _22791 = NOVALUE;
            goto L12; // [421] 448
        }
        DeRef(_22791);
        _22791 = NOVALUE;
    }
    DeRef(_22791);
    _22791 = NOVALUE;
L11: 

    /** 				sym[S_ARG_MIN] = MININT*/
    _2 = (int)SEQ_PTR(_sym_42674);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42674 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 47);
    _1 = *(int *)_2;
    *(int *)_2 = -1073741824;
    DeRef(_1);

    /** 				sym[S_ARG_MAX] = MAXINT*/
    _2 = (int)SEQ_PTR(_sym_42674);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42674 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 48);
    _1 = *(int *)_2;
    *(int *)_2 = 1073741823;
    DeRef(_1);
    goto L13; // [445] 477
L12: 

    /** 				sym[S_ARG_MIN] = sym[S_ARG_MIN_NEW]*/
    _2 = (int)SEQ_PTR(_sym_42674);
    _22792 = (int)*(((s1_ptr)_2)->base + 49);
    Ref(_22792);
    _2 = (int)SEQ_PTR(_sym_42674);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42674 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 47);
    _1 = *(int *)_2;
    *(int *)_2 = _22792;
    if( _1 != _22792 ){
        DeRef(_1);
    }
    _22792 = NOVALUE;

    /** 				sym[S_ARG_MAX] = sym[S_ARG_MAX_NEW]*/
    _2 = (int)SEQ_PTR(_sym_42674);
    _22793 = (int)*(((s1_ptr)_2)->base + 50);
    Ref(_22793);
    _2 = (int)SEQ_PTR(_sym_42674);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42674 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 48);
    _1 = *(int *)_2;
    *(int *)_2 = _22793;
    if( _1 != _22793 ){
        DeRef(_1);
    }
    _22793 = NOVALUE;
L13: 

    /** 			sym[S_ARG_MIN_NEW] = -NOVALUE*/
    if (IS_ATOM_INT(_35NOVALUE_16099)) {
        if ((unsigned long)_35NOVALUE_16099 == 0xC0000000)
        _22794 = (int)NewDouble((double)-0xC0000000);
        else
        _22794 = - _35NOVALUE_16099;
    }
    else {
        _22794 = unary_op(UMINUS, _35NOVALUE_16099);
    }
    _2 = (int)SEQ_PTR(_sym_42674);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42674 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 49);
    _1 = *(int *)_2;
    *(int *)_2 = _22794;
    if( _1 != _22794 ){
        DeRef(_1);
    }
    _22794 = NOVALUE;

    /** 			if sym[S_ARG_SEQ_LEN_NEW] = -NOVALUE then*/
    _2 = (int)SEQ_PTR(_sym_42674);
    _22795 = (int)*(((s1_ptr)_2)->base + 52);
    if (IS_ATOM_INT(_35NOVALUE_16099)) {
        if ((unsigned long)_35NOVALUE_16099 == 0xC0000000)
        _22796 = (int)NewDouble((double)-0xC0000000);
        else
        _22796 = - _35NOVALUE_16099;
    }
    else {
        _22796 = unary_op(UMINUS, _35NOVALUE_16099);
    }
    if (binary_op_a(NOTEQ, _22795, _22796)){
        _22795 = NOVALUE;
        DeRef(_22796);
        _22796 = NOVALUE;
        goto L14; // [503] 520
    }
    _22795 = NOVALUE;
    DeRef(_22796);
    _22796 = NOVALUE;

    /** 				sym[S_ARG_SEQ_LEN] = NOVALUE*/
    Ref(_35NOVALUE_16099);
    _2 = (int)SEQ_PTR(_sym_42674);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42674 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 51);
    _1 = *(int *)_2;
    *(int *)_2 = _35NOVALUE_16099;
    DeRef(_1);
    goto L15; // [517] 535
L14: 

    /** 				sym[S_ARG_SEQ_LEN] = sym[S_ARG_SEQ_LEN_NEW]*/
    _2 = (int)SEQ_PTR(_sym_42674);
    _22798 = (int)*(((s1_ptr)_2)->base + 52);
    Ref(_22798);
    _2 = (int)SEQ_PTR(_sym_42674);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42674 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 51);
    _1 = *(int *)_2;
    *(int *)_2 = _22798;
    if( _1 != _22798 ){
        DeRef(_1);
    }
    _22798 = NOVALUE;
L15: 

    /** 			sym[S_ARG_SEQ_LEN_NEW] = -NOVALUE*/
    if (IS_ATOM_INT(_35NOVALUE_16099)) {
        if ((unsigned long)_35NOVALUE_16099 == 0xC0000000)
        _22799 = (int)NewDouble((double)-0xC0000000);
        else
        _22799 = - _35NOVALUE_16099;
    }
    else {
        _22799 = unary_op(UMINUS, _35NOVALUE_16099);
    }
    _2 = (int)SEQ_PTR(_sym_42674);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42674 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 52);
    _1 = *(int *)_2;
    *(int *)_2 = _22799;
    if( _1 != _22799 ){
        DeRef(_1);
    }
    _22799 = NOVALUE;
L6: 

    /** 		sym[S_GTYPE_NEW] = TYPE_NULL*/
    _2 = (int)SEQ_PTR(_sym_42674);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42674 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 38);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 		if sym[S_SEQ_ELEM_NEW] = TYPE_NULL then*/
    _2 = (int)SEQ_PTR(_sym_42674);
    _22800 = (int)*(((s1_ptr)_2)->base + 40);
    if (binary_op_a(NOTEQ, _22800, 0)){
        _22800 = NOVALUE;
        goto L16; // [569] 586
    }
    _22800 = NOVALUE;

    /** 		   sym[S_SEQ_ELEM] = TYPE_OBJECT*/
    _2 = (int)SEQ_PTR(_sym_42674);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42674 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 33);
    _1 = *(int *)_2;
    *(int *)_2 = 16;
    DeRef(_1);
    goto L17; // [583] 601
L16: 

    /** 			sym[S_SEQ_ELEM] = sym[S_SEQ_ELEM_NEW]*/
    _2 = (int)SEQ_PTR(_sym_42674);
    _22802 = (int)*(((s1_ptr)_2)->base + 40);
    Ref(_22802);
    _2 = (int)SEQ_PTR(_sym_42674);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42674 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 33);
    _1 = *(int *)_2;
    *(int *)_2 = _22802;
    if( _1 != _22802 ){
        DeRef(_1);
    }
    _22802 = NOVALUE;
L17: 

    /** 		sym[S_SEQ_ELEM_NEW] = TYPE_NULL*/
    _2 = (int)SEQ_PTR(_sym_42674);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42674 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 40);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 		if sym[S_SEQ_LEN_NEW] = -NOVALUE then*/
    _2 = (int)SEQ_PTR(_sym_42674);
    _22803 = (int)*(((s1_ptr)_2)->base + 39);
    if (IS_ATOM_INT(_35NOVALUE_16099)) {
        if ((unsigned long)_35NOVALUE_16099 == 0xC0000000)
        _22804 = (int)NewDouble((double)-0xC0000000);
        else
        _22804 = - _35NOVALUE_16099;
    }
    else {
        _22804 = unary_op(UMINUS, _35NOVALUE_16099);
    }
    if (binary_op_a(NOTEQ, _22803, _22804)){
        _22803 = NOVALUE;
        DeRef(_22804);
        _22804 = NOVALUE;
        goto L18; // [624] 641
    }
    _22803 = NOVALUE;
    DeRef(_22804);
    _22804 = NOVALUE;

    /** 			sym[S_SEQ_LEN] = NOVALUE*/
    Ref(_35NOVALUE_16099);
    _2 = (int)SEQ_PTR(_sym_42674);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42674 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 32);
    _1 = *(int *)_2;
    *(int *)_2 = _35NOVALUE_16099;
    DeRef(_1);
    goto L19; // [638] 656
L18: 

    /** 			sym[S_SEQ_LEN] = sym[S_SEQ_LEN_NEW]*/
    _2 = (int)SEQ_PTR(_sym_42674);
    _22806 = (int)*(((s1_ptr)_2)->base + 39);
    Ref(_22806);
    _2 = (int)SEQ_PTR(_sym_42674);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42674 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 32);
    _1 = *(int *)_2;
    *(int *)_2 = _22806;
    if( _1 != _22806 ){
        DeRef(_1);
    }
    _22806 = NOVALUE;
L19: 

    /** 		sym[S_SEQ_LEN_NEW] = -NOVALUE*/
    if (IS_ATOM_INT(_35NOVALUE_16099)) {
        if ((unsigned long)_35NOVALUE_16099 == 0xC0000000)
        _22807 = (int)NewDouble((double)-0xC0000000);
        else
        _22807 = - _35NOVALUE_16099;
    }
    else {
        _22807 = unary_op(UMINUS, _35NOVALUE_16099);
    }
    _2 = (int)SEQ_PTR(_sym_42674);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42674 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 39);
    _1 = *(int *)_2;
    *(int *)_2 = _22807;
    if( _1 != _22807 ){
        DeRef(_1);
    }
    _22807 = NOVALUE;

    /** 		if sym[S_TOKEN] != NAMESPACE*/
    _2 = (int)SEQ_PTR(_sym_42674);
    if (!IS_ATOM_INT(_35S_TOKEN_15922)){
        _22808 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TOKEN_15922)->dbl));
    }
    else{
        _22808 = (int)*(((s1_ptr)_2)->base + _35S_TOKEN_15922);
    }
    if (IS_ATOM_INT(_22808)) {
        _22809 = (_22808 != 523);
    }
    else {
        _22809 = binary_op(NOTEQ, _22808, 523);
    }
    _22808 = NOVALUE;
    if (IS_ATOM_INT(_22809)) {
        if (_22809 == 0) {
            goto L1A; // [683] 794
        }
    }
    else {
        if (DBL_PTR(_22809)->dbl == 0.0) {
            goto L1A; // [683] 794
        }
    }
    _2 = (int)SEQ_PTR(_sym_42674);
    _22811 = (int)*(((s1_ptr)_2)->base + 3);
    if (IS_ATOM_INT(_22811)) {
        _22812 = (_22811 != 2);
    }
    else {
        _22812 = binary_op(NOTEQ, _22811, 2);
    }
    _22811 = NOVALUE;
    if (_22812 == 0) {
        DeRef(_22812);
        _22812 = NOVALUE;
        goto L1A; // [700] 794
    }
    else {
        if (!IS_ATOM_INT(_22812) && DBL_PTR(_22812)->dbl == 0.0){
            DeRef(_22812);
            _22812 = NOVALUE;
            goto L1A; // [700] 794
        }
        DeRef(_22812);
        _22812 = NOVALUE;
    }
    DeRef(_22812);
    _22812 = NOVALUE;

    /** 			if sym[S_OBJ_MIN_NEW] = -NOVALUE or*/
    _2 = (int)SEQ_PTR(_sym_42674);
    _22813 = (int)*(((s1_ptr)_2)->base + 41);
    if (IS_ATOM_INT(_35NOVALUE_16099)) {
        if ((unsigned long)_35NOVALUE_16099 == 0xC0000000)
        _22814 = (int)NewDouble((double)-0xC0000000);
        else
        _22814 = - _35NOVALUE_16099;
    }
    else {
        _22814 = unary_op(UMINUS, _35NOVALUE_16099);
    }
    if (IS_ATOM_INT(_22813) && IS_ATOM_INT(_22814)) {
        _22815 = (_22813 == _22814);
    }
    else {
        _22815 = binary_op(EQUALS, _22813, _22814);
    }
    _22813 = NOVALUE;
    DeRef(_22814);
    _22814 = NOVALUE;
    if (IS_ATOM_INT(_22815)) {
        if (_22815 != 0) {
            goto L1B; // [720] 741
        }
    }
    else {
        if (DBL_PTR(_22815)->dbl != 0.0) {
            goto L1B; // [720] 741
        }
    }
    _2 = (int)SEQ_PTR(_sym_42674);
    _22817 = (int)*(((s1_ptr)_2)->base + 41);
    if (IS_ATOM_INT(_22817) && IS_ATOM_INT(_35NOVALUE_16099)) {
        _22818 = (_22817 == _35NOVALUE_16099);
    }
    else {
        _22818 = binary_op(EQUALS, _22817, _35NOVALUE_16099);
    }
    _22817 = NOVALUE;
    if (_22818 == 0) {
        DeRef(_22818);
        _22818 = NOVALUE;
        goto L1C; // [737] 764
    }
    else {
        if (!IS_ATOM_INT(_22818) && DBL_PTR(_22818)->dbl == 0.0){
            DeRef(_22818);
            _22818 = NOVALUE;
            goto L1C; // [737] 764
        }
        DeRef(_22818);
        _22818 = NOVALUE;
    }
    DeRef(_22818);
    _22818 = NOVALUE;
L1B: 

    /** 				sym[S_OBJ_MIN] = MININT*/
    _2 = (int)SEQ_PTR(_sym_42674);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42674 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 30);
    _1 = *(int *)_2;
    *(int *)_2 = -1073741824;
    DeRef(_1);

    /** 				sym[S_OBJ_MAX] = MAXINT*/
    _2 = (int)SEQ_PTR(_sym_42674);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42674 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 31);
    _1 = *(int *)_2;
    *(int *)_2 = 1073741823;
    DeRef(_1);
    goto L1D; // [761] 793
L1C: 

    /** 				sym[S_OBJ_MIN] = sym[S_OBJ_MIN_NEW]*/
    _2 = (int)SEQ_PTR(_sym_42674);
    _22819 = (int)*(((s1_ptr)_2)->base + 41);
    Ref(_22819);
    _2 = (int)SEQ_PTR(_sym_42674);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42674 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 30);
    _1 = *(int *)_2;
    *(int *)_2 = _22819;
    if( _1 != _22819 ){
        DeRef(_1);
    }
    _22819 = NOVALUE;

    /** 				sym[S_OBJ_MAX] = sym[S_OBJ_MAX_NEW]*/
    _2 = (int)SEQ_PTR(_sym_42674);
    _22820 = (int)*(((s1_ptr)_2)->base + 42);
    Ref(_22820);
    _2 = (int)SEQ_PTR(_sym_42674);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42674 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 31);
    _1 = *(int *)_2;
    *(int *)_2 = _22820;
    if( _1 != _22820 ){
        DeRef(_1);
    }
    _22820 = NOVALUE;
L1D: 
L1A: 

    /** 		sym[S_OBJ_MIN_NEW] = -NOVALUE*/
    if (IS_ATOM_INT(_35NOVALUE_16099)) {
        if ((unsigned long)_35NOVALUE_16099 == 0xC0000000)
        _22821 = (int)NewDouble((double)-0xC0000000);
        else
        _22821 = - _35NOVALUE_16099;
    }
    else {
        _22821 = unary_op(UMINUS, _35NOVALUE_16099);
    }
    _2 = (int)SEQ_PTR(_sym_42674);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42674 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 41);
    _1 = *(int *)_2;
    *(int *)_2 = _22821;
    if( _1 != _22821 ){
        DeRef(_1);
    }
    _22821 = NOVALUE;

    /** 		if sym[S_NREFS] = 1 and*/
    _2 = (int)SEQ_PTR(_sym_42674);
    _22822 = (int)*(((s1_ptr)_2)->base + 12);
    if (IS_ATOM_INT(_22822)) {
        _22823 = (_22822 == 1);
    }
    else {
        _22823 = binary_op(EQUALS, _22822, 1);
    }
    _22822 = NOVALUE;
    if (IS_ATOM_INT(_22823)) {
        if (_22823 == 0) {
            goto L1E; // [819] 874
        }
    }
    else {
        if (DBL_PTR(_22823)->dbl == 0.0) {
            goto L1E; // [819] 874
        }
    }
    _2 = (int)SEQ_PTR(_sym_42674);
    if (!IS_ATOM_INT(_35S_TOKEN_15922)){
        _22825 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TOKEN_15922)->dbl));
    }
    else{
        _22825 = (int)*(((s1_ptr)_2)->base + _35S_TOKEN_15922);
    }
    _22826 = find_from(_22825, _37RTN_TOKS_15870, 1);
    _22825 = NOVALUE;
    if (_22826 == 0)
    {
        _22826 = NOVALUE;
        goto L1E; // [837] 874
    }
    else{
        _22826 = NOVALUE;
    }

    /** 			if sym[S_USAGE] != U_DELETED then*/
    _2 = (int)SEQ_PTR(_sym_42674);
    _22827 = (int)*(((s1_ptr)_2)->base + 5);
    if (binary_op_a(EQUALS, _22827, 99)){
        _22827 = NOVALUE;
        goto L1F; // [850] 873
    }
    _22827 = NOVALUE;

    /** 				sym[S_USAGE] = U_DELETED*/
    _2 = (int)SEQ_PTR(_sym_42674);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42674 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = 99;
    DeRef(_1);

    /** 				deleted_routines += 1*/
    _57deleted_routines_42668 = _57deleted_routines_42668 + 1;
L1F: 
L1E: 

    /** 		sym[S_NREFS] = 0*/
    _2 = (int)SEQ_PTR(_sym_42674);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42674 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 12);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 		if not equal(symo, sym) then*/
    if (_symo_42675 == _sym_42674)
    _22830 = 1;
    else if (IS_ATOM_INT(_symo_42675) && IS_ATOM_INT(_sym_42674))
    _22830 = 0;
    else
    _22830 = (compare(_symo_42675, _sym_42674) == 0);
    if (_22830 != 0)
    goto L20; // [888] 906
    _22830 = NOVALUE;

    /** 			SymTab[s] = sym*/
    RefDS(_sym_42674);
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _s_42673);
    _1 = *(int *)_2;
    *(int *)_2 = _sym_42674;
    DeRef(_1);

    /** 			updsym += 1*/
    _updsym_42671 = _updsym_42671 + 1;
L20: 

    /** 		s = sym[S_NEXT]*/
    _2 = (int)SEQ_PTR(_sym_42674);
    _s_42673 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_42673)){
        _s_42673 = (long)DBL_PTR(_s_42673)->dbl;
    }

    /** 	end while*/
    goto L1; // [918] 38
L2: 

    /** 	for i = 1 to length(temp_name_type) do*/
    if (IS_SEQUENCE(_35temp_name_type_16326)){
            _22834 = SEQ_PTR(_35temp_name_type_16326)->length;
    }
    else {
        _22834 = 1;
    }
    {
        int _i_42901;
        _i_42901 = 1;
L21: 
        if (_i_42901 > _22834){
            goto L22; // [928] 1061
        }

        /** 		integer upd = 0*/
        _upd_42904 = 0;

        /** 		if temp_name_type[i][T_GTYPE] != temp_name_type[i][T_GTYPE_NEW] then*/
        _2 = (int)SEQ_PTR(_35temp_name_type_16326);
        _22835 = (int)*(((s1_ptr)_2)->base + _i_42901);
        _2 = (int)SEQ_PTR(_22835);
        _22836 = (int)*(((s1_ptr)_2)->base + 1);
        _22835 = NOVALUE;
        _2 = (int)SEQ_PTR(_35temp_name_type_16326);
        _22837 = (int)*(((s1_ptr)_2)->base + _i_42901);
        _2 = (int)SEQ_PTR(_22837);
        _22838 = (int)*(((s1_ptr)_2)->base + 2);
        _22837 = NOVALUE;
        if (binary_op_a(EQUALS, _22836, _22838)){
            _22836 = NOVALUE;
            _22838 = NOVALUE;
            goto L23; // [966] 1003
        }
        _22836 = NOVALUE;
        _22838 = NOVALUE;

        /** 			temp_name_type[i][T_GTYPE] = temp_name_type[i][T_GTYPE_NEW]*/
        _2 = (int)SEQ_PTR(_35temp_name_type_16326);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _35temp_name_type_16326 = MAKE_SEQ(_2);
        }
        _3 = (int)(_i_42901 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(_35temp_name_type_16326);
        _22842 = (int)*(((s1_ptr)_2)->base + _i_42901);
        _2 = (int)SEQ_PTR(_22842);
        _22843 = (int)*(((s1_ptr)_2)->base + 2);
        _22842 = NOVALUE;
        Ref(_22843);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 1);
        _1 = *(int *)_2;
        *(int *)_2 = _22843;
        if( _1 != _22843 ){
            DeRef(_1);
        }
        _22843 = NOVALUE;
        _22840 = NOVALUE;

        /** 			upd = 1*/
        _upd_42904 = 1;
L23: 

        /** 		if temp_name_type[i][T_GTYPE_NEW] != TYPE_NULL then*/
        _2 = (int)SEQ_PTR(_35temp_name_type_16326);
        _22844 = (int)*(((s1_ptr)_2)->base + _i_42901);
        _2 = (int)SEQ_PTR(_22844);
        _22845 = (int)*(((s1_ptr)_2)->base + 2);
        _22844 = NOVALUE;
        if (binary_op_a(EQUALS, _22845, 0)){
            _22845 = NOVALUE;
            goto L24; // [1019] 1046
        }
        _22845 = NOVALUE;

        /** 			temp_name_type[i][T_GTYPE_NEW] = TYPE_NULL*/
        _2 = (int)SEQ_PTR(_35temp_name_type_16326);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _35temp_name_type_16326 = MAKE_SEQ(_2);
        }
        _3 = (int)(_i_42901 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 2);
        _1 = *(int *)_2;
        *(int *)_2 = 0;
        DeRef(_1);
        _22847 = NOVALUE;

        /** 			upd = 1*/
        _upd_42904 = 1;
L24: 

        /** 		updsym += upd*/
        _updsym_42671 = _updsym_42671 + _upd_42904;

        /** 	end for*/
        _i_42901 = _i_42901 + 1;
        goto L21; // [1056] 935
L22: 
        ;
    }

    /** 	return updsym*/
    DeRef(_sym_42674);
    DeRef(_symo_42675);
    DeRef(_22753);
    _22753 = NOVALUE;
    DeRef(_22761);
    _22761 = NOVALUE;
    DeRef(_22764);
    _22764 = NOVALUE;
    DeRef(_22769);
    _22769 = NOVALUE;
    DeRef(_22772);
    _22772 = NOVALUE;
    DeRef(_22775);
    _22775 = NOVALUE;
    DeRef(_22778);
    _22778 = NOVALUE;
    DeRef(_22809);
    _22809 = NOVALUE;
    DeRef(_22788);
    _22788 = NOVALUE;
    DeRef(_22823);
    _22823 = NOVALUE;
    DeRef(_22815);
    _22815 = NOVALUE;
    return _updsym_42671;
    ;
}


void _57declare_prototype(int _s_42939)
{
    int _ret_type_42940 = NOVALUE;
    int _scope_42951 = NOVALUE;
    int _22867 = NOVALUE;
    int _22866 = NOVALUE;
    int _22864 = NOVALUE;
    int _22863 = NOVALUE;
    int _22862 = NOVALUE;
    int _22861 = NOVALUE;
    int _22859 = NOVALUE;
    int _22858 = NOVALUE;
    int _22857 = NOVALUE;
    int _22856 = NOVALUE;
    int _22855 = NOVALUE;
    int _22853 = NOVALUE;
    int _22852 = NOVALUE;
    int _22850 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if sym_token( s ) = PROC then*/
    _22850 = _53sym_token(_s_42939);
    if (binary_op_a(NOTEQ, _22850, 27)){
        DeRef(_22850);
        _22850 = NOVALUE;
        goto L1; // [11] 25
    }
    DeRef(_22850);
    _22850 = NOVALUE;

    /** 		ret_type = "void "*/
    RefDS(_22735);
    DeRefi(_ret_type_42940);
    _ret_type_42940 = _22735;
    goto L2; // [22] 33
L1: 

    /** 		ret_type ="int "*/
    RefDS(_22736);
    DeRefi(_ret_type_42940);
    _ret_type_42940 = _22736;
L2: 

    /** 	c_hputs(ret_type)*/
    RefDS(_ret_type_42940);
    _54c_hputs(_ret_type_42940);

    /** 	if dll_option and TWINDOWS  then*/
    if (_57dll_option_41676 == 0) {
        goto L3; // [44] 116
    }
    if (_40TWINDOWS_16388 == 0)
    {
        goto L3; // [51] 116
    }
    else{
    }

    /** 		integer scope = SymTab[s][S_SCOPE]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _22853 = (int)*(((s1_ptr)_2)->base + _s_42939);
    _2 = (int)SEQ_PTR(_22853);
    _scope_42951 = (int)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_scope_42951)){
        _scope_42951 = (long)DBL_PTR(_scope_42951)->dbl;
    }
    _22853 = NOVALUE;

    /** 		if (scope = SC_PUBLIC*/
    _22855 = (_scope_42951 == 13);
    if (_22855 != 0) {
        _22856 = 1;
        goto L4; // [78] 92
    }
    _22857 = (_scope_42951 == 11);
    _22856 = (_22857 != 0);
L4: 
    if (_22856 != 0) {
        DeRef(_22858);
        _22858 = 1;
        goto L5; // [92] 106
    }
    _22859 = (_scope_42951 == 6);
    _22858 = (_22859 != 0);
L5: 
    if (_22858 == 0)
    {
        _22858 = NOVALUE;
        goto L6; // [106] 115
    }
    else{
        _22858 = NOVALUE;
    }

    /** 			c_hputs("__stdcall ")*/
    RefDS(_22860);
    _54c_hputs(_22860);
L6: 
L3: 

    /** 	c_hprintf("_%d", SymTab[s][S_FILE_NO])*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _22861 = (int)*(((s1_ptr)_2)->base + _s_42939);
    _2 = (int)SEQ_PTR(_22861);
    if (!IS_ATOM_INT(_35S_FILE_NO_15913)){
        _22862 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FILE_NO_15913)->dbl));
    }
    else{
        _22862 = (int)*(((s1_ptr)_2)->base + _35S_FILE_NO_15913);
    }
    _22861 = NOVALUE;
    RefDS(_22116);
    Ref(_22862);
    _54c_hprintf(_22116, _22862);
    _22862 = NOVALUE;

    /** 	c_hputs(SymTab[s][S_NAME])*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _22863 = (int)*(((s1_ptr)_2)->base + _s_42939);
    _2 = (int)SEQ_PTR(_22863);
    if (!IS_ATOM_INT(_35S_NAME_15917)){
        _22864 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15917)->dbl));
    }
    else{
        _22864 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15917);
    }
    _22863 = NOVALUE;
    Ref(_22864);
    _54c_hputs(_22864);
    _22864 = NOVALUE;

    /** 	c_hputs("(")*/
    RefDS(_22865);
    _54c_hputs(_22865);

    /** 	for i = 1 to SymTab[s][S_NUM_ARGS] do*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _22866 = (int)*(((s1_ptr)_2)->base + _s_42939);
    _2 = (int)SEQ_PTR(_22866);
    if (!IS_ATOM_INT(_35S_NUM_ARGS_15968)){
        _22867 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NUM_ARGS_15968)->dbl));
    }
    else{
        _22867 = (int)*(((s1_ptr)_2)->base + _35S_NUM_ARGS_15968);
    }
    _22866 = NOVALUE;
    {
        int _i_42980;
        _i_42980 = 1;
L7: 
        if (binary_op_a(GREATER, _i_42980, _22867)){
            goto L8; // [172] 206
        }

        /** 		if i = 1 then*/
        if (binary_op_a(NOTEQ, _i_42980, 1)){
            goto L9; // [181] 193
        }

        /** 			c_hputs("int")*/
        RefDS(_22869);
        _54c_hputs(_22869);
        goto LA; // [190] 199
L9: 

        /** 			c_hputs(", int")*/
        RefDS(_22870);
        _54c_hputs(_22870);
LA: 

        /** 	end for*/
        _0 = _i_42980;
        if (IS_ATOM_INT(_i_42980)) {
            _i_42980 = _i_42980 + 1;
            if ((long)((unsigned long)_i_42980 +(unsigned long) HIGH_BITS) >= 0){
                _i_42980 = NewDouble((double)_i_42980);
            }
        }
        else {
            _i_42980 = binary_op_a(PLUS, _i_42980, 1);
        }
        DeRef(_0);
        goto L7; // [201] 179
L8: 
        ;
        DeRef(_i_42980);
    }

    /** 	c_hputs(");\n")*/
    RefDS(_22285);
    _54c_hputs(_22285);

    /** end procedure*/
    DeRefi(_ret_type_42940);
    DeRef(_22855);
    _22855 = NOVALUE;
    DeRef(_22857);
    _22857 = NOVALUE;
    DeRef(_22859);
    _22859 = NOVALUE;
    _22867 = NOVALUE;
    return;
    ;
}


void _57add_to_routine_list(int _s_42996, int _seq_num_42997, int _first_42998)
{
    int _p_43073 = NOVALUE;
    int _22916 = NOVALUE;
    int _22914 = NOVALUE;
    int _22912 = NOVALUE;
    int _22910 = NOVALUE;
    int _22908 = NOVALUE;
    int _22907 = NOVALUE;
    int _22906 = NOVALUE;
    int _22904 = NOVALUE;
    int _22902 = NOVALUE;
    int _22900 = NOVALUE;
    int _22899 = NOVALUE;
    int _22897 = NOVALUE;
    int _22896 = NOVALUE;
    int _22892 = NOVALUE;
    int _22891 = NOVALUE;
    int _22890 = NOVALUE;
    int _22889 = NOVALUE;
    int _22888 = NOVALUE;
    int _22887 = NOVALUE;
    int _22886 = NOVALUE;
    int _22885 = NOVALUE;
    int _22884 = NOVALUE;
    int _22883 = NOVALUE;
    int _22881 = NOVALUE;
    int _22880 = NOVALUE;
    int _22879 = NOVALUE;
    int _22878 = NOVALUE;
    int _22875 = NOVALUE;
    int _22874 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	if not first then*/
    if (_first_42998 != 0)
    goto L1; // [9] 18

    /** 		c_puts(",\n")*/
    RefDS(_22872);
    _54c_puts(_22872);
L1: 

    /** 	c_puts("  {\"")*/
    RefDS(_22873);
    _54c_puts(_22873);

    /** 	c_puts(SymTab[s][S_NAME])*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _22874 = (int)*(((s1_ptr)_2)->base + _s_42996);
    _2 = (int)SEQ_PTR(_22874);
    if (!IS_ATOM_INT(_35S_NAME_15917)){
        _22875 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15917)->dbl));
    }
    else{
        _22875 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15917);
    }
    _22874 = NOVALUE;
    Ref(_22875);
    _54c_puts(_22875);
    _22875 = NOVALUE;

    /** 	c_puts("\", ")*/
    RefDS(_22876);
    _54c_puts(_22876);

    /** 	c_puts("(int (*)())")*/
    RefDS(_22877);
    _54c_puts(_22877);

    /** 	c_printf("_%d", SymTab[s][S_FILE_NO])*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _22878 = (int)*(((s1_ptr)_2)->base + _s_42996);
    _2 = (int)SEQ_PTR(_22878);
    if (!IS_ATOM_INT(_35S_FILE_NO_15913)){
        _22879 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FILE_NO_15913)->dbl));
    }
    else{
        _22879 = (int)*(((s1_ptr)_2)->base + _35S_FILE_NO_15913);
    }
    _22878 = NOVALUE;
    RefDS(_22116);
    Ref(_22879);
    _54c_printf(_22116, _22879);
    _22879 = NOVALUE;

    /** 	c_puts(SymTab[s][S_NAME])*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _22880 = (int)*(((s1_ptr)_2)->base + _s_42996);
    _2 = (int)SEQ_PTR(_22880);
    if (!IS_ATOM_INT(_35S_NAME_15917)){
        _22881 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15917)->dbl));
    }
    else{
        _22881 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15917);
    }
    _22880 = NOVALUE;
    Ref(_22881);
    _54c_puts(_22881);
    _22881 = NOVALUE;

    /** 	c_printf(", %d", seq_num)*/
    RefDS(_22882);
    _54c_printf(_22882, _seq_num_42997);

    /** 	c_printf(", %d", SymTab[s][S_FILE_NO])*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _22883 = (int)*(((s1_ptr)_2)->base + _s_42996);
    _2 = (int)SEQ_PTR(_22883);
    if (!IS_ATOM_INT(_35S_FILE_NO_15913)){
        _22884 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FILE_NO_15913)->dbl));
    }
    else{
        _22884 = (int)*(((s1_ptr)_2)->base + _35S_FILE_NO_15913);
    }
    _22883 = NOVALUE;
    RefDS(_22882);
    Ref(_22884);
    _54c_printf(_22882, _22884);
    _22884 = NOVALUE;

    /** 	c_printf(", %d", SymTab[s][S_NUM_ARGS])*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _22885 = (int)*(((s1_ptr)_2)->base + _s_42996);
    _2 = (int)SEQ_PTR(_22885);
    if (!IS_ATOM_INT(_35S_NUM_ARGS_15968)){
        _22886 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NUM_ARGS_15968)->dbl));
    }
    else{
        _22886 = (int)*(((s1_ptr)_2)->base + _35S_NUM_ARGS_15968);
    }
    _22885 = NOVALUE;
    RefDS(_22882);
    Ref(_22886);
    _54c_printf(_22882, _22886);
    _22886 = NOVALUE;

    /** 	if TWINDOWS and dll_option and find( SymTab[s][S_SCOPE], { SC_GLOBAL, SC_EXPORT, SC_PUBLIC} ) then*/
    if (_40TWINDOWS_16388 == 0) {
        _22887 = 0;
        goto L2; // [131] 141
    }
    _22887 = (_57dll_option_41676 != 0);
L2: 
    if (_22887 == 0) {
        goto L3; // [141] 186
    }
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _22889 = (int)*(((s1_ptr)_2)->base + _s_42996);
    _2 = (int)SEQ_PTR(_22889);
    _22890 = (int)*(((s1_ptr)_2)->base + 4);
    _22889 = NOVALUE;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 6;
    *((int *)(_2+8)) = 11;
    *((int *)(_2+12)) = 13;
    _22891 = MAKE_SEQ(_1);
    _22892 = find_from(_22890, _22891, 1);
    _22890 = NOVALUE;
    DeRefDS(_22891);
    _22891 = NOVALUE;
    if (_22892 == 0)
    {
        _22892 = NOVALUE;
        goto L3; // [175] 186
    }
    else{
        _22892 = NOVALUE;
    }

    /** 		c_puts(", 1")  -- must call with __stdcall convention*/
    RefDS(_22893);
    _54c_puts(_22893);
    goto L4; // [183] 192
L3: 

    /** 		c_puts(", 0")  -- default: call with normal or __cdecl convention*/
    RefDS(_22894);
    _54c_puts(_22894);
L4: 

    /** 	c_printf(", %d, 0", SymTab[s][S_SCOPE] )*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _22896 = (int)*(((s1_ptr)_2)->base + _s_42996);
    _2 = (int)SEQ_PTR(_22896);
    _22897 = (int)*(((s1_ptr)_2)->base + 4);
    _22896 = NOVALUE;
    RefDS(_22895);
    Ref(_22897);
    _54c_printf(_22895, _22897);
    _22897 = NOVALUE;

    /** 	c_puts("}")*/
    RefDS(_22898);
    _54c_puts(_22898);

    /** 	if SymTab[s][S_NREFS] < 2 then*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _22899 = (int)*(((s1_ptr)_2)->base + _s_42996);
    _2 = (int)SEQ_PTR(_22899);
    _22900 = (int)*(((s1_ptr)_2)->base + 12);
    _22899 = NOVALUE;
    if (binary_op_a(GREATEREQ, _22900, 2)){
        _22900 = NOVALUE;
        goto L5; // [229] 249
    }
    _22900 = NOVALUE;

    /** 		SymTab[s][S_NREFS] = 2 --s->nrefs++*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_15242 = MAKE_SEQ(_2);
    }
    _3 = (int)(_s_42996 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 12);
    _1 = *(int *)_2;
    *(int *)_2 = 2;
    DeRef(_1);
    _22902 = NOVALUE;
L5: 

    /** 	symtab_index p = SymTab[s][S_NEXT]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _22904 = (int)*(((s1_ptr)_2)->base + _s_42996);
    _2 = (int)SEQ_PTR(_22904);
    _p_43073 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_p_43073)){
        _p_43073 = (long)DBL_PTR(_p_43073)->dbl;
    }
    _22904 = NOVALUE;

    /** 	for i = 1 to SymTab[s][S_NUM_ARGS] do*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _22906 = (int)*(((s1_ptr)_2)->base + _s_42996);
    _2 = (int)SEQ_PTR(_22906);
    if (!IS_ATOM_INT(_35S_NUM_ARGS_15968)){
        _22907 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NUM_ARGS_15968)->dbl));
    }
    else{
        _22907 = (int)*(((s1_ptr)_2)->base + _35S_NUM_ARGS_15968);
    }
    _22906 = NOVALUE;
    {
        int _i_43079;
        _i_43079 = 1;
L6: 
        if (binary_op_a(GREATER, _i_43079, _22907)){
            goto L7; // [279] 377
        }

        /** 		SymTab[p][S_ARG_SEQ_ELEM_NEW] = TYPE_OBJECT*/
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _36SymTab_15242 = MAKE_SEQ(_2);
        }
        _3 = (int)(_p_43073 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 46);
        _1 = *(int *)_2;
        *(int *)_2 = 16;
        DeRef(_1);
        _22908 = NOVALUE;

        /** 		SymTab[p][S_ARG_TYPE_NEW] = TYPE_OBJECT*/
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _36SymTab_15242 = MAKE_SEQ(_2);
        }
        _3 = (int)(_p_43073 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 44);
        _1 = *(int *)_2;
        *(int *)_2 = 16;
        DeRef(_1);
        _22910 = NOVALUE;

        /** 		SymTab[p][S_ARG_MIN_NEW] = NOVALUE*/
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _36SymTab_15242 = MAKE_SEQ(_2);
        }
        _3 = (int)(_p_43073 + ((s1_ptr)_2)->base);
        Ref(_35NOVALUE_16099);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 49);
        _1 = *(int *)_2;
        *(int *)_2 = _35NOVALUE_16099;
        DeRef(_1);
        _22912 = NOVALUE;

        /** 		SymTab[p][S_ARG_SEQ_LEN_NEW] = NOVALUE*/
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _36SymTab_15242 = MAKE_SEQ(_2);
        }
        _3 = (int)(_p_43073 + ((s1_ptr)_2)->base);
        Ref(_35NOVALUE_16099);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 52);
        _1 = *(int *)_2;
        *(int *)_2 = _35NOVALUE_16099;
        DeRef(_1);
        _22914 = NOVALUE;

        /** 		p = SymTab[p][S_NEXT]*/
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _22916 = (int)*(((s1_ptr)_2)->base + _p_43073);
        _2 = (int)SEQ_PTR(_22916);
        _p_43073 = (int)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_p_43073)){
            _p_43073 = (long)DBL_PTR(_p_43073)->dbl;
        }
        _22916 = NOVALUE;

        /** 	end for*/
        _0 = _i_43079;
        if (IS_ATOM_INT(_i_43079)) {
            _i_43079 = _i_43079 + 1;
            if ((long)((unsigned long)_i_43079 +(unsigned long) HIGH_BITS) >= 0){
                _i_43079 = NewDouble((double)_i_43079);
            }
        }
        else {
            _i_43079 = binary_op_a(PLUS, _i_43079, 1);
        }
        DeRef(_0);
        goto L6; // [372] 286
L7: 
        ;
        DeRef(_i_43079);
    }

    /** end procedure*/
    _22907 = NOVALUE;
    return;
    ;
}


void _57DeclareRoutineList()
{
    int _s_43111 = NOVALUE;
    int _first_43112 = NOVALUE;
    int _seq_num_43113 = NOVALUE;
    int _these_routines_43121 = NOVALUE;
    int _these_routines_43143 = NOVALUE;
    int _22932 = NOVALUE;
    int _22931 = NOVALUE;
    int _22929 = NOVALUE;
    int _22927 = NOVALUE;
    int _22924 = NOVALUE;
    int _22923 = NOVALUE;
    int _22921 = NOVALUE;
    int _22919 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer first, seq_num*/

    /** 	c_hputs("extern struct routine_list _00[];\n")*/
    RefDS(_22918);
    _54c_hputs(_22918);

    /** 	check_file_routines()*/
    _57check_file_routines();

    /** 	for f = 1 to length( file_routines ) do*/
    if (IS_SEQUENCE(_57file_routines_43697)){
            _22919 = SEQ_PTR(_57file_routines_43697)->length;
    }
    else {
        _22919 = 1;
    }
    {
        int _f_43118;
        _f_43118 = 1;
L1: 
        if (_f_43118 > _22919){
            goto L2; // [19] 98
        }

        /** 		sequence these_routines = file_routines[f]*/
        DeRef(_these_routines_43121);
        _2 = (int)SEQ_PTR(_57file_routines_43697);
        _these_routines_43121 = (int)*(((s1_ptr)_2)->base + _f_43118);
        Ref(_these_routines_43121);

        /** 		for r = 1 to length( these_routines ) do*/
        if (IS_SEQUENCE(_these_routines_43121)){
                _22921 = SEQ_PTR(_these_routines_43121)->length;
        }
        else {
            _22921 = 1;
        }
        {
            int _r_43125;
            _r_43125 = 1;
L3: 
            if (_r_43125 > _22921){
                goto L4; // [41] 89
            }

            /** 			s = these_routines[r]*/
            _2 = (int)SEQ_PTR(_these_routines_43121);
            _s_43111 = (int)*(((s1_ptr)_2)->base + _r_43125);
            if (!IS_ATOM_INT(_s_43111)){
                _s_43111 = (long)DBL_PTR(_s_43111)->dbl;
            }

            /** 			if SymTab[s][S_USAGE] != U_DELETED then*/
            _2 = (int)SEQ_PTR(_36SymTab_15242);
            _22923 = (int)*(((s1_ptr)_2)->base + _s_43111);
            _2 = (int)SEQ_PTR(_22923);
            _22924 = (int)*(((s1_ptr)_2)->base + 5);
            _22923 = NOVALUE;
            if (binary_op_a(EQUALS, _22924, 99)){
                _22924 = NOVALUE;
                goto L5; // [72] 82
            }
            _22924 = NOVALUE;

            /** 				declare_prototype( s )*/
            _57declare_prototype(_s_43111);
L5: 

            /** 		end for*/
            _r_43125 = _r_43125 + 1;
            goto L3; // [84] 48
L4: 
            ;
        }
        DeRef(_these_routines_43121);
        _these_routines_43121 = NOVALUE;

        /** 	end for*/
        _f_43118 = _f_43118 + 1;
        goto L1; // [93] 26
L2: 
        ;
    }

    /** 	c_puts("\n")*/
    RefDS(_22175);
    _54c_puts(_22175);

    /** 	seq_num = 0*/
    _seq_num_43113 = 0;

    /** 	first = TRUE*/
    _first_43112 = _13TRUE_436;

    /** 	c_puts("struct routine_list _00[] = {\n")*/
    RefDS(_22926);
    _54c_puts(_22926);

    /** 	for f = 1 to length( file_routines ) do*/
    if (IS_SEQUENCE(_57file_routines_43697)){
            _22927 = SEQ_PTR(_57file_routines_43697)->length;
    }
    else {
        _22927 = 1;
    }
    {
        int _f_43140;
        _f_43140 = 1;
L6: 
        if (_f_43140 > _22927){
            goto L7; // [129] 222
        }

        /** 		sequence these_routines = file_routines[f]*/
        DeRef(_these_routines_43143);
        _2 = (int)SEQ_PTR(_57file_routines_43697);
        _these_routines_43143 = (int)*(((s1_ptr)_2)->base + _f_43140);
        Ref(_these_routines_43143);

        /** 		for r = 1 to length( these_routines ) do*/
        if (IS_SEQUENCE(_these_routines_43143)){
                _22929 = SEQ_PTR(_these_routines_43143)->length;
        }
        else {
            _22929 = 1;
        }
        {
            int _r_43147;
            _r_43147 = 1;
L8: 
            if (_r_43147 > _22929){
                goto L9; // [151] 213
            }

            /** 			s = these_routines[r]*/
            _2 = (int)SEQ_PTR(_these_routines_43143);
            _s_43111 = (int)*(((s1_ptr)_2)->base + _r_43147);
            if (!IS_ATOM_INT(_s_43111)){
                _s_43111 = (long)DBL_PTR(_s_43111)->dbl;
            }

            /** 			if SymTab[s][S_RI_TARGET] then*/
            _2 = (int)SEQ_PTR(_36SymTab_15242);
            _22931 = (int)*(((s1_ptr)_2)->base + _s_43111);
            _2 = (int)SEQ_PTR(_22931);
            _22932 = (int)*(((s1_ptr)_2)->base + 53);
            _22931 = NOVALUE;
            if (_22932 == 0) {
                _22932 = NOVALUE;
                goto LA; // [180] 200
            }
            else {
                if (!IS_ATOM_INT(_22932) && DBL_PTR(_22932)->dbl == 0.0){
                    _22932 = NOVALUE;
                    goto LA; // [180] 200
                }
                _22932 = NOVALUE;
            }
            _22932 = NOVALUE;

            /** 				add_to_routine_list( s, seq_num, first )*/
            _57add_to_routine_list(_s_43111, _seq_num_43113, _first_43112);

            /** 				first = FALSE*/
            _first_43112 = _13FALSE_434;
LA: 

            /** 			seq_num += 1*/
            _seq_num_43113 = _seq_num_43113 + 1;

            /** 		end for*/
            _r_43147 = _r_43147 + 1;
            goto L8; // [208] 158
L9: 
            ;
        }
        DeRef(_these_routines_43143);
        _these_routines_43143 = NOVALUE;

        /** 	end for*/
        _f_43140 = _f_43140 + 1;
        goto L6; // [217] 136
L7: 
        ;
    }

    /** 	if not first then*/
    if (_first_43112 != 0)
    goto LB; // [224] 233

    /** 		c_puts(",\n")*/
    RefDS(_22872);
    _54c_puts(_22872);
LB: 

    /** 	c_puts("  {\"\", 0, 999999999, 0, 0, 0, 0}\n};\n\n")  -- end marker*/
    RefDS(_22935);
    _54c_puts(_22935);

    /** 	c_hputs("extern unsigned char ** _02;\n")*/
    RefDS(_22936);
    _54c_hputs(_22936);

    /** 	c_puts("unsigned char ** _02;\n")*/
    RefDS(_22937);
    _54c_puts(_22937);

    /** 	c_hputs("extern object _0switches;\n")*/
    RefDS(_22938);
    _54c_hputs(_22938);

    /** 	c_puts("object _0switches;\n")*/
    RefDS(_22939);
    _54c_puts(_22939);

    /** end procedure*/
    return;
    ;
}


void _57DeclareNameSpaceList()
{
    int _s_43173 = NOVALUE;
    int _first_43174 = NOVALUE;
    int _seq_num_43175 = NOVALUE;
    int _22959 = NOVALUE;
    int _22957 = NOVALUE;
    int _22956 = NOVALUE;
    int _22955 = NOVALUE;
    int _22954 = NOVALUE;
    int _22952 = NOVALUE;
    int _22951 = NOVALUE;
    int _22948 = NOVALUE;
    int _22947 = NOVALUE;
    int _22946 = NOVALUE;
    int _22945 = NOVALUE;
    int _22944 = NOVALUE;
    int _22942 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer first, seq_num*/

    /** 	c_hputs("extern struct ns_list _01[];\n")*/
    RefDS(_22940);
    _54c_hputs(_22940);

    /** 	c_puts("struct ns_list _01[] = {\n")*/
    RefDS(_22941);
    _54c_puts(_22941);

    /** 	seq_num = 0*/
    _seq_num_43175 = 0;

    /** 	first = TRUE*/
    _first_43174 = _13TRUE_436;

    /** 	s = SymTab[TopLevelSub][S_NEXT]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _22942 = (int)*(((s1_ptr)_2)->base + _35TopLevelSub_16251);
    _2 = (int)SEQ_PTR(_22942);
    _s_43173 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_43173)){
        _s_43173 = (long)DBL_PTR(_s_43173)->dbl;
    }
    _22942 = NOVALUE;

    /** 	while s do*/
L1: 
    if (_s_43173 == 0)
    {
        goto L2; // [50] 215
    }
    else{
    }

    /** 		if find(SymTab[s][S_TOKEN], NAMED_TOKS) then*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _22944 = (int)*(((s1_ptr)_2)->base + _s_43173);
    _2 = (int)SEQ_PTR(_22944);
    if (!IS_ATOM_INT(_35S_TOKEN_15922)){
        _22945 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TOKEN_15922)->dbl));
    }
    else{
        _22945 = (int)*(((s1_ptr)_2)->base + _35S_TOKEN_15922);
    }
    _22944 = NOVALUE;
    _22946 = find_from(_22945, _37NAMED_TOKS_15872, 1);
    _22945 = NOVALUE;
    if (_22946 == 0)
    {
        _22946 = NOVALUE;
        goto L3; // [74] 194
    }
    else{
        _22946 = NOVALUE;
    }

    /** 			if SymTab[s][S_TOKEN] = NAMESPACE then*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _22947 = (int)*(((s1_ptr)_2)->base + _s_43173);
    _2 = (int)SEQ_PTR(_22947);
    if (!IS_ATOM_INT(_35S_TOKEN_15922)){
        _22948 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TOKEN_15922)->dbl));
    }
    else{
        _22948 = (int)*(((s1_ptr)_2)->base + _35S_TOKEN_15922);
    }
    _22947 = NOVALUE;
    if (binary_op_a(NOTEQ, _22948, 523)){
        _22948 = NOVALUE;
        goto L4; // [93] 187
    }
    _22948 = NOVALUE;

    /** 				if not first then*/
    if (_first_43174 != 0)
    goto L5; // [99] 108

    /** 					c_puts(",\n")*/
    RefDS(_22872);
    _54c_puts(_22872);
L5: 

    /** 				first = FALSE*/
    _first_43174 = _13FALSE_434;

    /** 				c_puts("  {\"")*/
    RefDS(_22873);
    _54c_puts(_22873);

    /** 				c_puts(SymTab[s][S_NAME])*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _22951 = (int)*(((s1_ptr)_2)->base + _s_43173);
    _2 = (int)SEQ_PTR(_22951);
    if (!IS_ATOM_INT(_35S_NAME_15917)){
        _22952 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15917)->dbl));
    }
    else{
        _22952 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15917);
    }
    _22951 = NOVALUE;
    Ref(_22952);
    _54c_puts(_22952);
    _22952 = NOVALUE;

    /** 				c_printf("\", %d", SymTab[s][S_OBJ])*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _22954 = (int)*(((s1_ptr)_2)->base + _s_43173);
    _2 = (int)SEQ_PTR(_22954);
    _22955 = (int)*(((s1_ptr)_2)->base + 1);
    _22954 = NOVALUE;
    RefDS(_22953);
    Ref(_22955);
    _54c_printf(_22953, _22955);
    _22955 = NOVALUE;

    /** 				c_printf(", %d", seq_num)*/
    RefDS(_22882);
    _54c_printf(_22882, _seq_num_43175);

    /** 				c_printf(", %d", SymTab[s][S_FILE_NO])*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _22956 = (int)*(((s1_ptr)_2)->base + _s_43173);
    _2 = (int)SEQ_PTR(_22956);
    if (!IS_ATOM_INT(_35S_FILE_NO_15913)){
        _22957 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FILE_NO_15913)->dbl));
    }
    else{
        _22957 = (int)*(((s1_ptr)_2)->base + _35S_FILE_NO_15913);
    }
    _22956 = NOVALUE;
    RefDS(_22882);
    Ref(_22957);
    _54c_printf(_22882, _22957);
    _22957 = NOVALUE;

    /** 				c_puts("}")*/
    RefDS(_22898);
    _54c_puts(_22898);
L4: 

    /** 			seq_num += 1*/
    _seq_num_43175 = _seq_num_43175 + 1;
L3: 

    /** 		s = SymTab[s][S_NEXT]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _22959 = (int)*(((s1_ptr)_2)->base + _s_43173);
    _2 = (int)SEQ_PTR(_22959);
    _s_43173 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_43173)){
        _s_43173 = (long)DBL_PTR(_s_43173)->dbl;
    }
    _22959 = NOVALUE;

    /** 	end while*/
    goto L1; // [212] 50
L2: 

    /** 	if not first then*/
    if (_first_43174 != 0)
    goto L6; // [217] 226

    /** 		c_puts(",\n")*/
    RefDS(_22872);
    _54c_puts(_22872);
L6: 

    /** 	c_puts("  {\"\", 0, 999999999, 0}\n};\n\n")  -- end marker*/
    RefDS(_22962);
    _54c_puts(_22962);

    /** end procedure*/
    return;
    ;
}


int _57is_exported(int _s_43237)
{
    int _eentry_43238 = NOVALUE;
    int _scope_43241 = NOVALUE;
    int _22977 = NOVALUE;
    int _22976 = NOVALUE;
    int _22975 = NOVALUE;
    int _22974 = NOVALUE;
    int _22973 = NOVALUE;
    int _22972 = NOVALUE;
    int _22971 = NOVALUE;
    int _22970 = NOVALUE;
    int _22969 = NOVALUE;
    int _22968 = NOVALUE;
    int _22967 = NOVALUE;
    int _22965 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_s_43237)) {
        _1 = (long)(DBL_PTR(_s_43237)->dbl);
        DeRefDS(_s_43237);
        _s_43237 = _1;
    }

    /** 	sequence eentry = SymTab[s]*/
    DeRef(_eentry_43238);
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _eentry_43238 = (int)*(((s1_ptr)_2)->base + _s_43237);
    Ref(_eentry_43238);

    /** 	integer scope = eentry[S_SCOPE]*/
    _2 = (int)SEQ_PTR(_eentry_43238);
    _scope_43241 = (int)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_scope_43241))
    _scope_43241 = (long)DBL_PTR(_scope_43241)->dbl;

    /** 	if eentry[S_MODE] = M_NORMAL then*/
    _2 = (int)SEQ_PTR(_eentry_43238);
    _22965 = (int)*(((s1_ptr)_2)->base + 3);
    if (binary_op_a(NOTEQ, _22965, 1)){
        _22965 = NOVALUE;
        goto L1; // [31] 125
    }
    _22965 = NOVALUE;

    /** 		if eentry[S_FILE_NO] = 1 and find(scope, { SC_EXPORT, SC_PUBLIC, SC_GLOBAL }) then*/
    _2 = (int)SEQ_PTR(_eentry_43238);
    if (!IS_ATOM_INT(_35S_FILE_NO_15913)){
        _22967 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FILE_NO_15913)->dbl));
    }
    else{
        _22967 = (int)*(((s1_ptr)_2)->base + _35S_FILE_NO_15913);
    }
    if (IS_ATOM_INT(_22967)) {
        _22968 = (_22967 == 1);
    }
    else {
        _22968 = binary_op(EQUALS, _22967, 1);
    }
    _22967 = NOVALUE;
    if (IS_ATOM_INT(_22968)) {
        if (_22968 == 0) {
            goto L2; // [47] 79
        }
    }
    else {
        if (DBL_PTR(_22968)->dbl == 0.0) {
            goto L2; // [47] 79
        }
    }
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 11;
    *((int *)(_2+8)) = 13;
    *((int *)(_2+12)) = 6;
    _22970 = MAKE_SEQ(_1);
    _22971 = find_from(_scope_43241, _22970, 1);
    DeRefDS(_22970);
    _22970 = NOVALUE;
    if (_22971 == 0)
    {
        _22971 = NOVALUE;
        goto L2; // [69] 79
    }
    else{
        _22971 = NOVALUE;
    }

    /** 			return 1*/
    DeRef(_eentry_43238);
    DeRef(_22968);
    _22968 = NOVALUE;
    return 1;
L2: 

    /** 		if scope = SC_PUBLIC and*/
    _22972 = (_scope_43241 == 13);
    if (_22972 == 0) {
        goto L3; // [87] 124
    }
    _2 = (int)SEQ_PTR(_36include_matrix_15249);
    _22974 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_eentry_43238);
    if (!IS_ATOM_INT(_35S_FILE_NO_15913)){
        _22975 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FILE_NO_15913)->dbl));
    }
    else{
        _22975 = (int)*(((s1_ptr)_2)->base + _35S_FILE_NO_15913);
    }
    _2 = (int)SEQ_PTR(_22974);
    if (!IS_ATOM_INT(_22975)){
        _22976 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_22975)->dbl));
    }
    else{
        _22976 = (int)*(((s1_ptr)_2)->base + _22975);
    }
    _22974 = NOVALUE;
    if (IS_ATOM_INT(_22976)) {
        {unsigned long tu;
             tu = (unsigned long)_22976 & (unsigned long)4;
             _22977 = MAKE_UINT(tu);
        }
    }
    else {
        _22977 = binary_op(AND_BITS, _22976, 4);
    }
    _22976 = NOVALUE;
    if (_22977 == 0) {
        DeRef(_22977);
        _22977 = NOVALUE;
        goto L3; // [114] 124
    }
    else {
        if (!IS_ATOM_INT(_22977) && DBL_PTR(_22977)->dbl == 0.0){
            DeRef(_22977);
            _22977 = NOVALUE;
            goto L3; // [114] 124
        }
        DeRef(_22977);
        _22977 = NOVALUE;
    }
    DeRef(_22977);
    _22977 = NOVALUE;

    /** 			return 1*/
    DeRef(_eentry_43238);
    DeRef(_22972);
    _22972 = NOVALUE;
    DeRef(_22968);
    _22968 = NOVALUE;
    _22975 = NOVALUE;
    return 1;
L3: 
L1: 

    /** 	return 0*/
    DeRef(_eentry_43238);
    DeRef(_22972);
    _22972 = NOVALUE;
    DeRef(_22968);
    _22968 = NOVALUE;
    _22975 = NOVALUE;
    return 0;
    ;
}


void _57version()
{
    int _23011 = NOVALUE;
    int _23010 = NOVALUE;
    int _0, _1, _2;
    

    /** 	c_puts("// Euphoria To C version " & version_string() & "\n")*/
    _23010 = _32version_string(0);
    {
        int concat_list[3];

        concat_list[0] = _22175;
        concat_list[1] = _23010;
        concat_list[2] = _23009;
        Concat_N((object_ptr)&_23011, concat_list, 3);
    }
    DeRef(_23010);
    _23010 = NOVALUE;
    _54c_puts(_23011);
    _23011 = NOVALUE;

    /** end procedure*/
    return;
    ;
}


void _57new_c_file(int _name_43345)
{
    int _23014 = NOVALUE;
    int _0, _1, _2;
    

    /** 	cfile_size = 0*/
    _35cfile_size_16323 = 0;

    /** 	if LAST_PASS = FALSE then*/
    if (_57LAST_PASS_41663 != _13FALSE_434)
    goto L1; // [16] 26

    /** 		return*/
    DeRefDS(_name_43345);
    return;
L1: 

    /** 	write_checksum( c_code )*/
    _55write_checksum(_54c_code_45491);

    /** 	close(c_code)*/
    EClose(_54c_code_45491);

    /** 	c_code = open(output_dir & name & ".c", "w")*/
    {
        int concat_list[3];

        concat_list[0] = _23013;
        concat_list[1] = _name_43345;
        concat_list[2] = _57output_dir_41689;
        Concat_N((object_ptr)&_23014, concat_list, 3);
    }
    _54c_code_45491 = EOpen(_23014, _22129, 0);
    DeRefDS(_23014);
    _23014 = NOVALUE;

    /** 	if c_code = -1 then*/
    if (_54c_code_45491 != -1)
    goto L2; // [60] 72

    /** 		CompileErr(57)*/
    RefDS(_22023);
    _44CompileErr(57, _22023, 0);
L2: 

    /** 	cfile_count += 1*/
    _35cfile_count_16322 = _35cfile_count_16322 + 1;

    /** 	version()*/
    _57version();

    /** 	c_puts("#include \"include/euphoria.h\"\n")*/
    RefDS(_22133);
    _54c_puts(_22133);

    /** 	c_puts("#include \"main-.h\"\n\n")*/
    RefDS(_22134);
    _54c_puts(_22134);

    /** 	if not TUNIX then*/
    if (_40TUNIX_16392 != 0)
    goto L3; // [100] 112

    /** 		name = lower(name)  -- for faster compare later*/
    RefDS(_name_43345);
    _0 = _name_43345;
    _name_43345 = _14lower(_name_43345);
    DeRefDS(_0);
L3: 

    /** end procedure*/
    DeRefDS(_name_43345);
    return;
    ;
}


int _57unique_c_name(int _name_43374)
{
    int _i_43375 = NOVALUE;
    int _compare_name_43376 = NOVALUE;
    int _next_fc_43377 = NOVALUE;
    int _23030 = NOVALUE;
    int _23028 = NOVALUE;
    int _23027 = NOVALUE;
    int _23026 = NOVALUE;
    int _23024 = NOVALUE;
    int _0, _1, _2;
    

    /** 	compare_name = name & ".c"*/
    Concat((object_ptr)&_compare_name_43376, _name_43374, _23013);

    /** 	if not TUNIX then*/
    if (_40TUNIX_16392 != 0)
    goto L1; // [13] 25

    /** 		compare_name = lower(compare_name)*/
    RefDS(_compare_name_43376);
    _0 = _compare_name_43376;
    _compare_name_43376 = _14lower(_compare_name_43376);
    DeRefDS(_0);
L1: 

    /** 	next_fc = 1*/
    _next_fc_43377 = 1;

    /** 	i = 1*/
    _i_43375 = 1;

    /** 	while i <= length(generated_files) do*/
L2: 
    if (IS_SEQUENCE(_57generated_files_41680)){
            _23024 = SEQ_PTR(_57generated_files_41680)->length;
    }
    else {
        _23024 = 1;
    }
    if (_i_43375 > _23024)
    goto L3; // [45] 139

    /** 		if equal(generated_files[i], compare_name) then*/
    _2 = (int)SEQ_PTR(_57generated_files_41680);
    _23026 = (int)*(((s1_ptr)_2)->base + _i_43375);
    if (_23026 == _compare_name_43376)
    _23027 = 1;
    else if (IS_ATOM_INT(_23026) && IS_ATOM_INT(_compare_name_43376))
    _23027 = 0;
    else
    _23027 = (compare(_23026, _compare_name_43376) == 0);
    _23026 = NOVALUE;
    if (_23027 == 0)
    {
        _23027 = NOVALUE;
        goto L4; // [61] 127
    }
    else{
        _23027 = NOVALUE;
    }

    /** 			if next_fc > length(file_chars) then*/
    if (IS_SEQUENCE(_57file_chars_43370)){
            _23028 = SEQ_PTR(_57file_chars_43370)->length;
    }
    else {
        _23028 = 1;
    }
    if (_next_fc_43377 <= _23028)
    goto L5; // [69] 81

    /** 				CompileErr(140)*/
    RefDS(_22023);
    _44CompileErr(140, _22023, 0);
L5: 

    /** 			name[1] = file_chars[next_fc]*/
    _2 = (int)SEQ_PTR(_57file_chars_43370);
    _23030 = (int)*(((s1_ptr)_2)->base + _next_fc_43377);
    Ref(_23030);
    _2 = (int)SEQ_PTR(_name_43374);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _name_43374 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _23030;
    if( _1 != _23030 ){
        DeRef(_1);
    }
    _23030 = NOVALUE;

    /** 			compare_name = name & ".c"*/
    Concat((object_ptr)&_compare_name_43376, _name_43374, _23013);

    /** 			if not TUNIX then*/
    if (_40TUNIX_16392 != 0)
    goto L6; // [101] 113

    /** 				compare_name = lower(compare_name)*/
    RefDS(_compare_name_43376);
    _0 = _compare_name_43376;
    _compare_name_43376 = _14lower(_compare_name_43376);
    DeRefDS(_0);
L6: 

    /** 			next_fc += 1*/
    _next_fc_43377 = _next_fc_43377 + 1;

    /** 			i = 1 -- start over and compare again*/
    _i_43375 = 1;
    goto L2; // [124] 40
L4: 

    /** 			i += 1*/
    _i_43375 = _i_43375 + 1;

    /** 	end while*/
    goto L2; // [136] 40
L3: 

    /** 	return name*/
    DeRef(_compare_name_43376);
    return _name_43374;
    ;
}


int _57is_file_newer(int _f1_43406, int _f2_43407)
{
    int _d1_43408 = NOVALUE;
    int _d2_43411 = NOVALUE;
    int _diff_2__tmp_at42_43422 = NOVALUE;
    int _diff_1__tmp_at42_43421 = NOVALUE;
    int _diff_inlined_diff_at_42_43420 = NOVALUE;
    int _23040 = NOVALUE;
    int _23038 = NOVALUE;
    int _0, _1, _2;
    

    /** 	object d1 = file_timestamp(f1)*/
    RefDS(_f1_43406);
    _0 = _d1_43408;
    _d1_43408 = _17file_timestamp(_f1_43406);
    DeRef(_0);

    /** 	object d2 = file_timestamp(f2)*/
    RefDS(_f2_43407);
    _0 = _d2_43411;
    _d2_43411 = _17file_timestamp(_f2_43407);
    DeRef(_0);

    /** 	if atom(d1) or atom(d2) then return 1 end if*/
    _23038 = IS_ATOM(_d1_43408);
    if (_23038 != 0) {
        goto L1; // [22] 34
    }
    _23040 = IS_ATOM(_d2_43411);
    if (_23040 == 0)
    {
        _23040 = NOVALUE;
        goto L2; // [30] 39
    }
    else{
        _23040 = NOVALUE;
    }
L1: 
    DeRefDS(_f1_43406);
    DeRefDS(_f2_43407);
    DeRef(_d1_43408);
    DeRef(_d2_43411);
    return 1;
L2: 

    /** 	if datetime:diff(d1, d2) < 0 then*/

    /** 	return datetimeToSeconds(dt2) - datetimeToSeconds(dt1)*/
    Ref(_d2_43411);
    _0 = _diff_1__tmp_at42_43421;
    _diff_1__tmp_at42_43421 = _18datetimeToSeconds(_d2_43411);
    DeRef(_0);
    Ref(_d1_43408);
    _0 = _diff_2__tmp_at42_43422;
    _diff_2__tmp_at42_43422 = _18datetimeToSeconds(_d1_43408);
    DeRef(_0);
    DeRef(_diff_inlined_diff_at_42_43420);
    if (IS_ATOM_INT(_diff_1__tmp_at42_43421) && IS_ATOM_INT(_diff_2__tmp_at42_43422)) {
        _diff_inlined_diff_at_42_43420 = _diff_1__tmp_at42_43421 - _diff_2__tmp_at42_43422;
        if ((long)((unsigned long)_diff_inlined_diff_at_42_43420 +(unsigned long) HIGH_BITS) >= 0){
            _diff_inlined_diff_at_42_43420 = NewDouble((double)_diff_inlined_diff_at_42_43420);
        }
    }
    else {
        _diff_inlined_diff_at_42_43420 = binary_op(MINUS, _diff_1__tmp_at42_43421, _diff_2__tmp_at42_43422);
    }
    DeRef(_diff_1__tmp_at42_43421);
    _diff_1__tmp_at42_43421 = NOVALUE;
    DeRef(_diff_2__tmp_at42_43422);
    _diff_2__tmp_at42_43422 = NOVALUE;
    if (binary_op_a(GREATEREQ, _diff_inlined_diff_at_42_43420, 0)){
        goto L3; // [58] 69
    }

    /** 		return 1*/
    DeRefDS(_f1_43406);
    DeRefDS(_f2_43407);
    DeRef(_d1_43408);
    DeRef(_d2_43411);
    return 1;
L3: 

    /** 	return 0*/
    DeRefDS(_f1_43406);
    DeRefDS(_f2_43407);
    DeRef(_d1_43408);
    DeRef(_d2_43411);
    return 0;
    ;
}


void _57add_file(int _filename_43426, int _eu_filename_43427)
{
    int _obj_fname_43447 = NOVALUE;
    int _src_fname_43448 = NOVALUE;
    int _23064 = NOVALUE;
    int _23063 = NOVALUE;
    int _23050 = NOVALUE;
    int _23049 = NOVALUE;
    int _23046 = NOVALUE;
    int _23045 = NOVALUE;
    int _23044 = NOVALUE;
    int _23043 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if equal("c", fileext(filename)) then*/
    RefDS(_filename_43426);
    _23043 = _17fileext(_filename_43426);
    if (_23042 == _23043)
    _23044 = 1;
    else if (IS_ATOM_INT(_23042) && IS_ATOM_INT(_23043))
    _23044 = 0;
    else
    _23044 = (compare(_23042, _23043) == 0);
    DeRef(_23043);
    _23043 = NOVALUE;
    if (_23044 == 0)
    {
        _23044 = NOVALUE;
        goto L1; // [15] 35
    }
    else{
        _23044 = NOVALUE;
    }

    /** 		filename = filename[1..$-2]*/
    if (IS_SEQUENCE(_filename_43426)){
            _23045 = SEQ_PTR(_filename_43426)->length;
    }
    else {
        _23045 = 1;
    }
    _23046 = _23045 - 2;
    _23045 = NOVALUE;
    rhs_slice_target = (object_ptr)&_filename_43426;
    RHS_Slice(_filename_43426, 1, _23046);
    goto L2; // [32] 82
L1: 

    /** 	elsif equal("h", fileext(filename)) then*/
    RefDS(_filename_43426);
    _23049 = _17fileext(_filename_43426);
    if (_23048 == _23049)
    _23050 = 1;
    else if (IS_ATOM_INT(_23048) && IS_ATOM_INT(_23049))
    _23050 = 0;
    else
    _23050 = (compare(_23048, _23049) == 0);
    DeRef(_23049);
    _23049 = NOVALUE;
    if (_23050 == 0)
    {
        _23050 = NOVALUE;
        goto L3; // [45] 81
    }
    else{
        _23050 = NOVALUE;
    }

    /** 		generated_files = append(generated_files, filename)*/
    RefDS(_filename_43426);
    Append(&_57generated_files_41680, _57generated_files_41680, _filename_43426);

    /** 		if build_system_type = BUILD_DIRECT then*/
    if (_55build_system_type_44318 != 3)
    goto L4; // [62] 75

    /** 			outdated_files  = append(outdated_files, 0)*/
    Append(&_57outdated_files_41681, _57outdated_files_41681, 0);
L4: 

    /** 		return*/
    DeRefDS(_filename_43426);
    DeRefDS(_eu_filename_43427);
    DeRef(_obj_fname_43447);
    DeRef(_src_fname_43448);
    DeRef(_23046);
    _23046 = NOVALUE;
    return;
L3: 
L2: 

    /** 	sequence obj_fname = filename, src_fname = filename & ".c"*/
    RefDS(_filename_43426);
    DeRef(_obj_fname_43447);
    _obj_fname_43447 = _filename_43426;
    Concat((object_ptr)&_src_fname_43448, _filename_43426, _23013);

    /** 	if compiler_type = COMPILER_WATCOM then*/
    if (_55compiler_type_44322 != 2)
    goto L5; // [99] 112

    /** 		obj_fname &= ".obj"*/
    Concat((object_ptr)&_obj_fname_43447, _obj_fname_43447, _23056);
    goto L6; // [109] 119
L5: 

    /** 		obj_fname &= ".o"*/
    Concat((object_ptr)&_obj_fname_43447, _obj_fname_43447, _23058);
L6: 

    /** 	generated_files = append(generated_files, src_fname)*/
    RefDS(_src_fname_43448);
    Append(&_57generated_files_41680, _57generated_files_41680, _src_fname_43448);

    /** 	generated_files = append(generated_files, obj_fname)*/
    RefDS(_obj_fname_43447);
    Append(&_57generated_files_41680, _57generated_files_41680, _obj_fname_43447);

    /** 	if build_system_type = BUILD_DIRECT then*/
    if (_55build_system_type_44318 != 3)
    goto L7; // [141] 173

    /** 		outdated_files  = append(outdated_files, is_file_newer(eu_filename, output_dir & src_fname))*/
    Concat((object_ptr)&_23063, _57output_dir_41689, _src_fname_43448);
    RefDS(_eu_filename_43427);
    _23064 = _57is_file_newer(_eu_filename_43427, _23063);
    _23063 = NOVALUE;
    Ref(_23064);
    Append(&_57outdated_files_41681, _57outdated_files_41681, _23064);
    DeRef(_23064);
    _23064 = NOVALUE;

    /** 		outdated_files  = append(outdated_files, 0)*/
    Append(&_57outdated_files_41681, _57outdated_files_41681, 0);
L7: 

    /** end procedure*/
    DeRefDS(_filename_43426);
    DeRefDS(_eu_filename_43427);
    DeRef(_obj_fname_43447);
    DeRef(_src_fname_43448);
    DeRef(_23046);
    _23046 = NOVALUE;
    return;
    ;
}


int _57any_code(int _file_no_43471)
{
    int _these_routines_43473 = NOVALUE;
    int _s_43480 = NOVALUE;
    int _23080 = NOVALUE;
    int _23079 = NOVALUE;
    int _23078 = NOVALUE;
    int _23077 = NOVALUE;
    int _23076 = NOVALUE;
    int _23075 = NOVALUE;
    int _23074 = NOVALUE;
    int _23073 = NOVALUE;
    int _23072 = NOVALUE;
    int _23071 = NOVALUE;
    int _23070 = NOVALUE;
    int _23068 = NOVALUE;
    int _0, _1, _2;
    

    /** 	check_file_routines()*/
    _57check_file_routines();

    /** 	sequence these_routines = file_routines[file_no]*/
    DeRef(_these_routines_43473);
    _2 = (int)SEQ_PTR(_57file_routines_43697);
    _these_routines_43473 = (int)*(((s1_ptr)_2)->base + _file_no_43471);
    Ref(_these_routines_43473);

    /** 	for i = 1 to length( these_routines ) do*/
    if (IS_SEQUENCE(_these_routines_43473)){
            _23068 = SEQ_PTR(_these_routines_43473)->length;
    }
    else {
        _23068 = 1;
    }
    {
        int _i_43477;
        _i_43477 = 1;
L1: 
        if (_i_43477 > _23068){
            goto L2; // [22] 126
        }

        /** 		symtab_index s = these_routines[i]*/
        _2 = (int)SEQ_PTR(_these_routines_43473);
        _s_43480 = (int)*(((s1_ptr)_2)->base + _i_43477);
        if (!IS_ATOM_INT(_s_43480)){
            _s_43480 = (long)DBL_PTR(_s_43480)->dbl;
        }

        /** 		if SymTab[s][S_FILE_NO] = file_no and*/
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _23070 = (int)*(((s1_ptr)_2)->base + _s_43480);
        _2 = (int)SEQ_PTR(_23070);
        if (!IS_ATOM_INT(_35S_FILE_NO_15913)){
            _23071 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FILE_NO_15913)->dbl));
        }
        else{
            _23071 = (int)*(((s1_ptr)_2)->base + _35S_FILE_NO_15913);
        }
        _23070 = NOVALUE;
        if (IS_ATOM_INT(_23071)) {
            _23072 = (_23071 == _file_no_43471);
        }
        else {
            _23072 = binary_op(EQUALS, _23071, _file_no_43471);
        }
        _23071 = NOVALUE;
        if (IS_ATOM_INT(_23072)) {
            if (_23072 == 0) {
                DeRef(_23073);
                _23073 = 0;
                goto L3; // [55] 81
            }
        }
        else {
            if (DBL_PTR(_23072)->dbl == 0.0) {
                DeRef(_23073);
                _23073 = 0;
                goto L3; // [55] 81
            }
        }
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _23074 = (int)*(((s1_ptr)_2)->base + _s_43480);
        _2 = (int)SEQ_PTR(_23074);
        _23075 = (int)*(((s1_ptr)_2)->base + 5);
        _23074 = NOVALUE;
        if (IS_ATOM_INT(_23075)) {
            _23076 = (_23075 != 99);
        }
        else {
            _23076 = binary_op(NOTEQ, _23075, 99);
        }
        _23075 = NOVALUE;
        DeRef(_23073);
        if (IS_ATOM_INT(_23076))
        _23073 = (_23076 != 0);
        else
        _23073 = DBL_PTR(_23076)->dbl != 0.0;
L3: 
        if (_23073 == 0) {
            goto L4; // [81] 117
        }
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _23078 = (int)*(((s1_ptr)_2)->base + _s_43480);
        _2 = (int)SEQ_PTR(_23078);
        if (!IS_ATOM_INT(_35S_TOKEN_15922)){
            _23079 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TOKEN_15922)->dbl));
        }
        else{
            _23079 = (int)*(((s1_ptr)_2)->base + _35S_TOKEN_15922);
        }
        _23078 = NOVALUE;
        _23080 = find_from(_23079, _37RTN_TOKS_15870, 1);
        _23079 = NOVALUE;
        if (_23080 == 0)
        {
            _23080 = NOVALUE;
            goto L4; // [105] 117
        }
        else{
            _23080 = NOVALUE;
        }

        /** 			return TRUE -- found a non-deleted routine in this file*/
        DeRef(_these_routines_43473);
        DeRef(_23072);
        _23072 = NOVALUE;
        DeRef(_23076);
        _23076 = NOVALUE;
        return _13TRUE_436;
L4: 

        /** 	end for*/
        _i_43477 = _i_43477 + 1;
        goto L1; // [121] 29
L2: 
        ;
    }

    /** 	return FALSE*/
    DeRef(_these_routines_43473);
    DeRef(_23072);
    _23072 = NOVALUE;
    DeRef(_23076);
    _23076 = NOVALUE;
    return _13FALSE_434;
    ;
}


int _57legaldos_filename_char(int _i_43507)
{
    int _23095 = NOVALUE;
    int _23094 = NOVALUE;
    int _23091 = NOVALUE;
    int _23090 = NOVALUE;
    int _23089 = NOVALUE;
    int _23088 = NOVALUE;
    int _23087 = NOVALUE;
    int _23086 = NOVALUE;
    int _23085 = NOVALUE;
    int _23084 = NOVALUE;
    int _23083 = NOVALUE;
    int _23082 = NOVALUE;
    int _23081 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_i_43507)) {
        _1 = (long)(DBL_PTR(_i_43507)->dbl);
        DeRefDS(_i_43507);
        _i_43507 = _1;
    }

    /** 	if ('A' <= i and i <= 'Z') or*/
    _23081 = (65 <= _i_43507);
    if (_23081 == 0) {
        _23082 = 0;
        goto L1; // [9] 21
    }
    _23083 = (_i_43507 <= 90);
    _23082 = (_23083 != 0);
L1: 
    if (_23082 != 0) {
        _23084 = 1;
        goto L2; // [21] 45
    }
    _23085 = (48 <= _i_43507);
    if (_23085 == 0) {
        _23086 = 0;
        goto L3; // [29] 41
    }
    _23087 = (_i_43507 <= 57);
    _23086 = (_23087 != 0);
L3: 
    _23084 = (_23086 != 0);
L2: 
    if (_23084 != 0) {
        _23088 = 1;
        goto L4; // [45] 69
    }
    _23089 = (128 <= _i_43507);
    if (_23089 == 0) {
        _23090 = 0;
        goto L5; // [53] 65
    }
    _23091 = (_i_43507 <= 255);
    _23090 = (_23091 != 0);
L5: 
    _23088 = (_23090 != 0);
L4: 
    if (_23088 != 0) {
        goto L6; // [69] 87
    }
    _23094 = find_from(_i_43507, _23093, 1);
    _23095 = (_23094 != 0);
    _23094 = NOVALUE;
    if (_23095 == 0)
    {
        DeRef(_23095);
        _23095 = NOVALUE;
        goto L7; // [83] 96
    }
    else{
        DeRef(_23095);
        _23095 = NOVALUE;
    }
L6: 

    /** 		return 1*/
    DeRef(_23081);
    _23081 = NOVALUE;
    DeRef(_23083);
    _23083 = NOVALUE;
    DeRef(_23085);
    _23085 = NOVALUE;
    DeRef(_23087);
    _23087 = NOVALUE;
    DeRef(_23089);
    _23089 = NOVALUE;
    DeRef(_23091);
    _23091 = NOVALUE;
    return 1;
    goto L8; // [93] 103
L7: 

    /** 		return 0*/
    DeRef(_23081);
    _23081 = NOVALUE;
    DeRef(_23083);
    _23083 = NOVALUE;
    DeRef(_23085);
    _23085 = NOVALUE;
    DeRef(_23087);
    _23087 = NOVALUE;
    DeRef(_23089);
    _23089 = NOVALUE;
    DeRef(_23091);
    _23091 = NOVALUE;
    return 0;
L8: 
    ;
}


int _57legaldos_filename(int _s_43527)
{
    int _dloc_43528 = NOVALUE;
    int _23122 = NOVALUE;
    int _23121 = NOVALUE;
    int _23119 = NOVALUE;
    int _23118 = NOVALUE;
    int _23117 = NOVALUE;
    int _23116 = NOVALUE;
    int _23114 = NOVALUE;
    int _23113 = NOVALUE;
    int _23112 = NOVALUE;
    int _23111 = NOVALUE;
    int _23110 = NOVALUE;
    int _23109 = NOVALUE;
    int _23107 = NOVALUE;
    int _23106 = NOVALUE;
    int _23105 = NOVALUE;
    int _23104 = NOVALUE;
    int _23103 = NOVALUE;
    int _23102 = NOVALUE;
    int _23101 = NOVALUE;
    int _23099 = NOVALUE;
    int _23098 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if find( s, { "..", "." } ) then*/
    RefDS(_23097);
    RefDS(_23096);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _23096;
    ((int *)_2)[2] = _23097;
    _23098 = MAKE_SEQ(_1);
    _23099 = find_from(_s_43527, _23098, 1);
    DeRefDS(_23098);
    _23098 = NOVALUE;
    if (_23099 == 0)
    {
        _23099 = NOVALUE;
        goto L1; // [14] 24
    }
    else{
        _23099 = NOVALUE;
    }

    /** 		return 1*/
    DeRefDS(_s_43527);
    return 1;
L1: 

    /** 	dloc = find('.',s)*/
    _dloc_43528 = find_from(46, _s_43527, 1);

    /** 	if dloc > 8 or ( dloc > 0 and dloc + 3 < length(s) ) or ( dloc = 0 and length(s) > 8 ) then*/
    _23101 = (_dloc_43528 > 8);
    if (_23101 != 0) {
        _23102 = 1;
        goto L2; // [37] 68
    }
    _23103 = (_dloc_43528 > 0);
    if (_23103 == 0) {
        _23104 = 0;
        goto L3; // [45] 64
    }
    _23105 = _dloc_43528 + 3;
    if (IS_SEQUENCE(_s_43527)){
            _23106 = SEQ_PTR(_s_43527)->length;
    }
    else {
        _23106 = 1;
    }
    _23107 = (_23105 < _23106);
    _23105 = NOVALUE;
    _23106 = NOVALUE;
    _23104 = (_23107 != 0);
L3: 
    _23102 = (_23104 != 0);
L2: 
    if (_23102 != 0) {
        goto L4; // [68] 96
    }
    _23109 = (_dloc_43528 == 0);
    if (_23109 == 0) {
        DeRef(_23110);
        _23110 = 0;
        goto L5; // [76] 91
    }
    if (IS_SEQUENCE(_s_43527)){
            _23111 = SEQ_PTR(_s_43527)->length;
    }
    else {
        _23111 = 1;
    }
    _23112 = (_23111 > 8);
    _23111 = NOVALUE;
    _23110 = (_23112 != 0);
L5: 
    if (_23110 == 0)
    {
        _23110 = NOVALUE;
        goto L6; // [92] 103
    }
    else{
        _23110 = NOVALUE;
    }
L4: 

    /** 		return 0*/
    DeRefDS(_s_43527);
    DeRef(_23101);
    _23101 = NOVALUE;
    DeRef(_23103);
    _23103 = NOVALUE;
    DeRef(_23109);
    _23109 = NOVALUE;
    DeRef(_23107);
    _23107 = NOVALUE;
    DeRef(_23112);
    _23112 = NOVALUE;
    return 0;
L6: 

    /** 	for i = 1 to length(s) do*/
    if (IS_SEQUENCE(_s_43527)){
            _23113 = SEQ_PTR(_s_43527)->length;
    }
    else {
        _23113 = 1;
    }
    {
        int _i_43549;
        _i_43549 = 1;
L7: 
        if (_i_43549 > _23113){
            goto L8; // [108] 200
        }

        /** 		if s[i] = '.' then*/
        _2 = (int)SEQ_PTR(_s_43527);
        _23114 = (int)*(((s1_ptr)_2)->base + _i_43549);
        if (binary_op_a(NOTEQ, _23114, 46)){
            _23114 = NOVALUE;
            goto L9; // [121] 173
        }
        _23114 = NOVALUE;

        /** 			for j = i+1 to length(s) do*/
        _23116 = _i_43549 + 1;
        if (IS_SEQUENCE(_s_43527)){
                _23117 = SEQ_PTR(_s_43527)->length;
        }
        else {
            _23117 = 1;
        }
        {
            int _j_43555;
            _j_43555 = _23116;
LA: 
            if (_j_43555 > _23117){
                goto LB; // [134] 168
            }

            /** 				if not legaldos_filename_char(s[j]) then*/
            _2 = (int)SEQ_PTR(_s_43527);
            _23118 = (int)*(((s1_ptr)_2)->base + _j_43555);
            Ref(_23118);
            _23119 = _57legaldos_filename_char(_23118);
            _23118 = NOVALUE;
            if (IS_ATOM_INT(_23119)) {
                if (_23119 != 0){
                    DeRef(_23119);
                    _23119 = NOVALUE;
                    goto LC; // [151] 161
                }
            }
            else {
                if (DBL_PTR(_23119)->dbl != 0.0){
                    DeRef(_23119);
                    _23119 = NOVALUE;
                    goto LC; // [151] 161
                }
            }
            DeRef(_23119);
            _23119 = NOVALUE;

            /** 					return 0*/
            DeRefDS(_s_43527);
            DeRef(_23101);
            _23101 = NOVALUE;
            DeRef(_23103);
            _23103 = NOVALUE;
            DeRef(_23109);
            _23109 = NOVALUE;
            DeRef(_23107);
            _23107 = NOVALUE;
            DeRef(_23112);
            _23112 = NOVALUE;
            DeRef(_23116);
            _23116 = NOVALUE;
            return 0;
LC: 

            /** 			end for*/
            _j_43555 = _j_43555 + 1;
            goto LA; // [163] 141
LB: 
            ;
        }

        /** 			exit*/
        goto L8; // [170] 200
L9: 

        /** 		if not legaldos_filename_char(s[i]) then*/
        _2 = (int)SEQ_PTR(_s_43527);
        _23121 = (int)*(((s1_ptr)_2)->base + _i_43549);
        Ref(_23121);
        _23122 = _57legaldos_filename_char(_23121);
        _23121 = NOVALUE;
        if (IS_ATOM_INT(_23122)) {
            if (_23122 != 0){
                DeRef(_23122);
                _23122 = NOVALUE;
                goto LD; // [183] 193
            }
        }
        else {
            if (DBL_PTR(_23122)->dbl != 0.0){
                DeRef(_23122);
                _23122 = NOVALUE;
                goto LD; // [183] 193
            }
        }
        DeRef(_23122);
        _23122 = NOVALUE;

        /** 			return 0*/
        DeRefDS(_s_43527);
        DeRef(_23101);
        _23101 = NOVALUE;
        DeRef(_23103);
        _23103 = NOVALUE;
        DeRef(_23109);
        _23109 = NOVALUE;
        DeRef(_23107);
        _23107 = NOVALUE;
        DeRef(_23112);
        _23112 = NOVALUE;
        DeRef(_23116);
        _23116 = NOVALUE;
        return 0;
LD: 

        /** 	end for*/
        _i_43549 = _i_43549 + 1;
        goto L7; // [195] 115
L8: 
        ;
    }

    /** 	return 1*/
    DeRefDS(_s_43527);
    DeRef(_23101);
    _23101 = NOVALUE;
    DeRef(_23103);
    _23103 = NOVALUE;
    DeRef(_23109);
    _23109 = NOVALUE;
    DeRef(_23107);
    _23107 = NOVALUE;
    DeRef(_23112);
    _23112 = NOVALUE;
    DeRef(_23116);
    _23116 = NOVALUE;
    return 1;
    ;
}


int _57shrink_to_83(int _s_43568)
{
    int _dl_43569 = NOVALUE;
    int _sl_43570 = NOVALUE;
    int _osl_43571 = NOVALUE;
    int _se_43572 = NOVALUE;
    int _23203 = NOVALUE;
    int _23202 = NOVALUE;
    int _23201 = NOVALUE;
    int _23200 = NOVALUE;
    int _23199 = NOVALUE;
    int _23198 = NOVALUE;
    int _23197 = NOVALUE;
    int _23196 = NOVALUE;
    int _23195 = NOVALUE;
    int _23194 = NOVALUE;
    int _23192 = NOVALUE;
    int _23191 = NOVALUE;
    int _23190 = NOVALUE;
    int _23189 = NOVALUE;
    int _23187 = NOVALUE;
    int _23186 = NOVALUE;
    int _23185 = NOVALUE;
    int _23184 = NOVALUE;
    int _23181 = NOVALUE;
    int _23180 = NOVALUE;
    int _23179 = NOVALUE;
    int _23176 = NOVALUE;
    int _23175 = NOVALUE;
    int _23174 = NOVALUE;
    int _23172 = NOVALUE;
    int _23171 = NOVALUE;
    int _23170 = NOVALUE;
    int _23169 = NOVALUE;
    int _23167 = NOVALUE;
    int _23166 = NOVALUE;
    int _23164 = NOVALUE;
    int _23163 = NOVALUE;
    int _23161 = NOVALUE;
    int _23160 = NOVALUE;
    int _23159 = NOVALUE;
    int _23158 = NOVALUE;
    int _23157 = NOVALUE;
    int _23156 = NOVALUE;
    int _23155 = NOVALUE;
    int _23154 = NOVALUE;
    int _23153 = NOVALUE;
    int _23152 = NOVALUE;
    int _23150 = NOVALUE;
    int _23149 = NOVALUE;
    int _23148 = NOVALUE;
    int _23145 = NOVALUE;
    int _23144 = NOVALUE;
    int _23143 = NOVALUE;
    int _23142 = NOVALUE;
    int _23139 = NOVALUE;
    int _23138 = NOVALUE;
    int _23137 = NOVALUE;
    int _23135 = NOVALUE;
    int _23134 = NOVALUE;
    int _23133 = NOVALUE;
    int _23132 = NOVALUE;
    int _23130 = NOVALUE;
    int _23128 = NOVALUE;
    int _23127 = NOVALUE;
    int _23126 = NOVALUE;
    int _23125 = NOVALUE;
    int _0, _1, _2;
    

    /** 	osl = find( ':', s )*/
    _osl_43571 = find_from(58, _s_43568, 1);

    /** 	sl = osl + find( '\\', s[osl+1..$] ) -- find_from osl*/
    _23125 = _osl_43571 + 1;
    if (IS_SEQUENCE(_s_43568)){
            _23126 = SEQ_PTR(_s_43568)->length;
    }
    else {
        _23126 = 1;
    }
    rhs_slice_target = (object_ptr)&_23127;
    RHS_Slice(_s_43568, _23125, _23126);
    _23128 = find_from(92, _23127, 1);
    DeRefDS(_23127);
    _23127 = NOVALUE;
    _sl_43570 = _osl_43571 + _23128;
    _23128 = NOVALUE;

    /** 	if sl=osl+1 then*/
    _23130 = _osl_43571 + 1;
    if (_sl_43570 != _23130)
    goto L1; // [39] 49

    /** 		osl = sl*/
    _osl_43571 = _sl_43570;
L1: 

    /** 	sl = osl + find( '\\', s[osl+1..$] )*/
    _23132 = _osl_43571 + 1;
    if (_23132 > MAXINT){
        _23132 = NewDouble((double)_23132);
    }
    if (IS_SEQUENCE(_s_43568)){
            _23133 = SEQ_PTR(_s_43568)->length;
    }
    else {
        _23133 = 1;
    }
    rhs_slice_target = (object_ptr)&_23134;
    RHS_Slice(_s_43568, _23132, _23133);
    _23135 = find_from(92, _23134, 1);
    DeRefDS(_23134);
    _23134 = NOVALUE;
    _sl_43570 = _osl_43571 + _23135;
    _23135 = NOVALUE;

    /** 	dl = osl + find( '.', s[osl+1..sl] )*/
    _23137 = _osl_43571 + 1;
    rhs_slice_target = (object_ptr)&_23138;
    RHS_Slice(_s_43568, _23137, _sl_43570);
    _23139 = find_from(46, _23138, 1);
    DeRefDS(_23138);
    _23138 = NOVALUE;
    _dl_43569 = _osl_43571 + _23139;
    _23139 = NOVALUE;

    /** 	if dl > osl then*/
    if (_dl_43569 <= _osl_43571)
    goto L2; // [94] 124

    /** 		se = s[dl..min({dl+3,sl-1})]*/
    _23142 = _dl_43569 + 3;
    if ((long)((unsigned long)_23142 + (unsigned long)HIGH_BITS) >= 0) 
    _23142 = NewDouble((double)_23142);
    _23143 = _sl_43570 - 1;
    if ((long)((unsigned long)_23143 +(unsigned long) HIGH_BITS) >= 0){
        _23143 = NewDouble((double)_23143);
    }
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _23142;
    ((int *)_2)[2] = _23143;
    _23144 = MAKE_SEQ(_1);
    _23143 = NOVALUE;
    _23142 = NOVALUE;
    _23145 = _20min(_23144);
    _23144 = NOVALUE;
    rhs_slice_target = (object_ptr)&_se_43572;
    RHS_Slice(_s_43568, _dl_43569, _23145);
    goto L3; // [121] 132
L2: 

    /** 		se = ""*/
    RefDS(_22023);
    DeRef(_se_43572);
    _se_43572 = _22023;
L3: 

    /** 	while sl != osl do*/
L4: 
    if (_sl_43570 == _osl_43571)
    goto L5; // [137] 333

    /** 		if find( ' ', s[osl+1..sl] ) or not legaldos_filename(upper(s[osl+1..sl-1])) then*/
    _23148 = _osl_43571 + 1;
    rhs_slice_target = (object_ptr)&_23149;
    RHS_Slice(_s_43568, _23148, _sl_43570);
    _23150 = find_from(32, _23149, 1);
    DeRefDS(_23149);
    _23149 = NOVALUE;
    if (_23150 != 0) {
        goto L6; // [157] 190
    }
    _23152 = _osl_43571 + 1;
    if (_23152 > MAXINT){
        _23152 = NewDouble((double)_23152);
    }
    _23153 = _sl_43570 - 1;
    rhs_slice_target = (object_ptr)&_23154;
    RHS_Slice(_s_43568, _23152, _23153);
    _23155 = _14upper(_23154);
    _23154 = NOVALUE;
    _23156 = _57legaldos_filename(_23155);
    _23155 = NOVALUE;
    if (IS_ATOM_INT(_23156)) {
        _23157 = (_23156 == 0);
    }
    else {
        _23157 = unary_op(NOT, _23156);
    }
    DeRef(_23156);
    _23156 = NOVALUE;
    if (_23157 == 0) {
        DeRef(_23157);
        _23157 = NOVALUE;
        goto L7; // [186] 244
    }
    else {
        if (!IS_ATOM_INT(_23157) && DBL_PTR(_23157)->dbl == 0.0){
            DeRef(_23157);
            _23157 = NOVALUE;
            goto L7; // [186] 244
        }
        DeRef(_23157);
        _23157 = NOVALUE;
    }
    DeRef(_23157);
    _23157 = NOVALUE;
L6: 

    /** 			s = s[1..osl] & s[osl+1..osl+6] & "~1" & se & s[sl..$]*/
    rhs_slice_target = (object_ptr)&_23158;
    RHS_Slice(_s_43568, 1, _osl_43571);
    _23159 = _osl_43571 + 1;
    if (_23159 > MAXINT){
        _23159 = NewDouble((double)_23159);
    }
    _23160 = _osl_43571 + 6;
    rhs_slice_target = (object_ptr)&_23161;
    RHS_Slice(_s_43568, _23159, _23160);
    if (IS_SEQUENCE(_s_43568)){
            _23163 = SEQ_PTR(_s_43568)->length;
    }
    else {
        _23163 = 1;
    }
    rhs_slice_target = (object_ptr)&_23164;
    RHS_Slice(_s_43568, _sl_43570, _23163);
    {
        int concat_list[5];

        concat_list[0] = _23164;
        concat_list[1] = _se_43572;
        concat_list[2] = _23162;
        concat_list[3] = _23161;
        concat_list[4] = _23158;
        Concat_N((object_ptr)&_s_43568, concat_list, 5);
    }
    DeRefDS(_23164);
    _23164 = NOVALUE;
    DeRefDS(_23161);
    _23161 = NOVALUE;
    DeRefDS(_23158);
    _23158 = NOVALUE;

    /** 			sl = osl+8+length(se)*/
    _23166 = _osl_43571 + 8;
    if ((long)((unsigned long)_23166 + (unsigned long)HIGH_BITS) >= 0) 
    _23166 = NewDouble((double)_23166);
    if (IS_SEQUENCE(_se_43572)){
            _23167 = SEQ_PTR(_se_43572)->length;
    }
    else {
        _23167 = 1;
    }
    if (IS_ATOM_INT(_23166)) {
        _sl_43570 = _23166 + _23167;
    }
    else {
        _sl_43570 = NewDouble(DBL_PTR(_23166)->dbl + (double)_23167);
    }
    DeRef(_23166);
    _23166 = NOVALUE;
    _23167 = NOVALUE;
    if (!IS_ATOM_INT(_sl_43570)) {
        _1 = (long)(DBL_PTR(_sl_43570)->dbl);
        DeRefDS(_sl_43570);
        _sl_43570 = _1;
    }
L7: 

    /** 		osl = sl*/
    _osl_43571 = _sl_43570;

    /** 		sl += find( '\\', s[sl+1..$] )*/
    _23169 = _sl_43570 + 1;
    if (_23169 > MAXINT){
        _23169 = NewDouble((double)_23169);
    }
    if (IS_SEQUENCE(_s_43568)){
            _23170 = SEQ_PTR(_s_43568)->length;
    }
    else {
        _23170 = 1;
    }
    rhs_slice_target = (object_ptr)&_23171;
    RHS_Slice(_s_43568, _23169, _23170);
    _23172 = find_from(92, _23171, 1);
    DeRefDS(_23171);
    _23171 = NOVALUE;
    _sl_43570 = _sl_43570 + _23172;
    _23172 = NOVALUE;

    /** 		dl = osl + find( '.', s[osl+1..sl] )*/
    _23174 = _osl_43571 + 1;
    rhs_slice_target = (object_ptr)&_23175;
    RHS_Slice(_s_43568, _23174, _sl_43570);
    _23176 = find_from(46, _23175, 1);
    DeRefDS(_23175);
    _23175 = NOVALUE;
    _dl_43569 = _osl_43571 + _23176;
    _23176 = NOVALUE;

    /** 		if dl > osl then*/
    if (_dl_43569 <= _osl_43571)
    goto L8; // [294] 320

    /** 			se = s[dl..min({dl+3,sl})]*/
    _23179 = _dl_43569 + 3;
    if ((long)((unsigned long)_23179 + (unsigned long)HIGH_BITS) >= 0) 
    _23179 = NewDouble((double)_23179);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _23179;
    ((int *)_2)[2] = _sl_43570;
    _23180 = MAKE_SEQ(_1);
    _23179 = NOVALUE;
    _23181 = _20min(_23180);
    _23180 = NOVALUE;
    rhs_slice_target = (object_ptr)&_se_43572;
    RHS_Slice(_s_43568, _dl_43569, _23181);
    goto L4; // [317] 137
L8: 

    /** 			se = ""*/
    RefDS(_22023);
    DeRef(_se_43572);
    _se_43572 = _22023;

    /** 	end while*/
    goto L4; // [330] 137
L5: 

    /** 	if dl > osl then*/
    if (_dl_43569 <= _osl_43571)
    goto L9; // [335] 362

    /** 		se = s[dl..min({dl+3,length(s)})]*/
    _23184 = _dl_43569 + 3;
    if ((long)((unsigned long)_23184 + (unsigned long)HIGH_BITS) >= 0) 
    _23184 = NewDouble((double)_23184);
    if (IS_SEQUENCE(_s_43568)){
            _23185 = SEQ_PTR(_s_43568)->length;
    }
    else {
        _23185 = 1;
    }
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _23184;
    ((int *)_2)[2] = _23185;
    _23186 = MAKE_SEQ(_1);
    _23185 = NOVALUE;
    _23184 = NOVALUE;
    _23187 = _20min(_23186);
    _23186 = NOVALUE;
    rhs_slice_target = (object_ptr)&_se_43572;
    RHS_Slice(_s_43568, _dl_43569, _23187);
L9: 

    /** 	if find( ' ', s[osl+1..$] ) or not legaldos_filename(upper(s[osl+1..$])) then*/
    _23189 = _osl_43571 + 1;
    if (_23189 > MAXINT){
        _23189 = NewDouble((double)_23189);
    }
    if (IS_SEQUENCE(_s_43568)){
            _23190 = SEQ_PTR(_s_43568)->length;
    }
    else {
        _23190 = 1;
    }
    rhs_slice_target = (object_ptr)&_23191;
    RHS_Slice(_s_43568, _23189, _23190);
    _23192 = find_from(32, _23191, 1);
    DeRefDS(_23191);
    _23191 = NOVALUE;
    if (_23192 != 0) {
        goto LA; // [381] 413
    }
    _23194 = _osl_43571 + 1;
    if (_23194 > MAXINT){
        _23194 = NewDouble((double)_23194);
    }
    if (IS_SEQUENCE(_s_43568)){
            _23195 = SEQ_PTR(_s_43568)->length;
    }
    else {
        _23195 = 1;
    }
    rhs_slice_target = (object_ptr)&_23196;
    RHS_Slice(_s_43568, _23194, _23195);
    _23197 = _14upper(_23196);
    _23196 = NOVALUE;
    _23198 = _57legaldos_filename(_23197);
    _23197 = NOVALUE;
    if (IS_ATOM_INT(_23198)) {
        _23199 = (_23198 == 0);
    }
    else {
        _23199 = unary_op(NOT, _23198);
    }
    DeRef(_23198);
    _23198 = NOVALUE;
    if (_23199 == 0) {
        DeRef(_23199);
        _23199 = NOVALUE;
        goto LB; // [409] 443
    }
    else {
        if (!IS_ATOM_INT(_23199) && DBL_PTR(_23199)->dbl == 0.0){
            DeRef(_23199);
            _23199 = NOVALUE;
            goto LB; // [409] 443
        }
        DeRef(_23199);
        _23199 = NOVALUE;
    }
    DeRef(_23199);
    _23199 = NOVALUE;
LA: 

    /** 		s = s[1..osl] & s[osl+1..osl+6] & "~1" & se*/
    rhs_slice_target = (object_ptr)&_23200;
    RHS_Slice(_s_43568, 1, _osl_43571);
    _23201 = _osl_43571 + 1;
    if (_23201 > MAXINT){
        _23201 = NewDouble((double)_23201);
    }
    _23202 = _osl_43571 + 6;
    rhs_slice_target = (object_ptr)&_23203;
    RHS_Slice(_s_43568, _23201, _23202);
    {
        int concat_list[4];

        concat_list[0] = _se_43572;
        concat_list[1] = _23162;
        concat_list[2] = _23203;
        concat_list[3] = _23200;
        Concat_N((object_ptr)&_s_43568, concat_list, 4);
    }
    DeRefDS(_23203);
    _23203 = NOVALUE;
    DeRefDS(_23200);
    _23200 = NOVALUE;
LB: 

    /** 	return s*/
    DeRef(_se_43572);
    DeRef(_23125);
    _23125 = NOVALUE;
    DeRef(_23130);
    _23130 = NOVALUE;
    DeRef(_23132);
    _23132 = NOVALUE;
    DeRef(_23137);
    _23137 = NOVALUE;
    DeRef(_23148);
    _23148 = NOVALUE;
    DeRef(_23145);
    _23145 = NOVALUE;
    DeRef(_23152);
    _23152 = NOVALUE;
    DeRef(_23153);
    _23153 = NOVALUE;
    DeRef(_23169);
    _23169 = NOVALUE;
    DeRef(_23159);
    _23159 = NOVALUE;
    DeRef(_23160);
    _23160 = NOVALUE;
    DeRef(_23174);
    _23174 = NOVALUE;
    DeRef(_23189);
    _23189 = NOVALUE;
    DeRef(_23181);
    _23181 = NOVALUE;
    DeRef(_23187);
    _23187 = NOVALUE;
    DeRef(_23194);
    _23194 = NOVALUE;
    DeRef(_23201);
    _23201 = NOVALUE;
    DeRef(_23202);
    _23202 = NOVALUE;
    return _s_43568;
    ;
}


int _57truncate_to_83(int _lfn_43670)
{
    int _dl_43671 = NOVALUE;
    int _23224 = NOVALUE;
    int _23223 = NOVALUE;
    int _23222 = NOVALUE;
    int _23221 = NOVALUE;
    int _23220 = NOVALUE;
    int _23219 = NOVALUE;
    int _23218 = NOVALUE;
    int _23217 = NOVALUE;
    int _23216 = NOVALUE;
    int _23215 = NOVALUE;
    int _23214 = NOVALUE;
    int _23213 = NOVALUE;
    int _23212 = NOVALUE;
    int _23211 = NOVALUE;
    int _23210 = NOVALUE;
    int _23209 = NOVALUE;
    int _23208 = NOVALUE;
    int _23207 = NOVALUE;
    int _23206 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer dl = find( '.', lfn )*/
    _dl_43671 = find_from(46, _lfn_43670, 1);

    /** 	if dl = 0 and length(lfn) > 8 then*/
    _23206 = (_dl_43671 == 0);
    if (_23206 == 0) {
        goto L1; // [16] 45
    }
    if (IS_SEQUENCE(_lfn_43670)){
            _23208 = SEQ_PTR(_lfn_43670)->length;
    }
    else {
        _23208 = 1;
    }
    _23209 = (_23208 > 8);
    _23208 = NOVALUE;
    if (_23209 == 0)
    {
        DeRef(_23209);
        _23209 = NOVALUE;
        goto L1; // [28] 45
    }
    else{
        DeRef(_23209);
        _23209 = NOVALUE;
    }

    /** 		return lfn[1..8]*/
    rhs_slice_target = (object_ptr)&_23210;
    RHS_Slice(_lfn_43670, 1, 8);
    DeRefDS(_lfn_43670);
    DeRef(_23206);
    _23206 = NOVALUE;
    return _23210;
    goto L2; // [42] 138
L1: 

    /** 	elsif dl = 0 and length(lfn) <= 8 then*/
    _23211 = (_dl_43671 == 0);
    if (_23211 == 0) {
        goto L3; // [51] 75
    }
    if (IS_SEQUENCE(_lfn_43670)){
            _23213 = SEQ_PTR(_lfn_43670)->length;
    }
    else {
        _23213 = 1;
    }
    _23214 = (_23213 <= 8);
    _23213 = NOVALUE;
    if (_23214 == 0)
    {
        DeRef(_23214);
        _23214 = NOVALUE;
        goto L3; // [63] 75
    }
    else{
        DeRef(_23214);
        _23214 = NOVALUE;
    }

    /** 		return lfn*/
    DeRef(_23206);
    _23206 = NOVALUE;
    DeRef(_23210);
    _23210 = NOVALUE;
    DeRef(_23211);
    _23211 = NOVALUE;
    return _lfn_43670;
    goto L2; // [72] 138
L3: 

    /** 	elsif dl > 9 and dl + 3 <= length(lfn) then*/
    _23215 = (_dl_43671 > 9);
    if (_23215 == 0) {
        goto L4; // [81] 126
    }
    _23217 = _dl_43671 + 3;
    if ((long)((unsigned long)_23217 + (unsigned long)HIGH_BITS) >= 0) 
    _23217 = NewDouble((double)_23217);
    if (IS_SEQUENCE(_lfn_43670)){
            _23218 = SEQ_PTR(_lfn_43670)->length;
    }
    else {
        _23218 = 1;
    }
    if (IS_ATOM_INT(_23217)) {
        _23219 = (_23217 <= _23218);
    }
    else {
        _23219 = (DBL_PTR(_23217)->dbl <= (double)_23218);
    }
    DeRef(_23217);
    _23217 = NOVALUE;
    _23218 = NOVALUE;
    if (_23219 == 0)
    {
        DeRef(_23219);
        _23219 = NOVALUE;
        goto L4; // [97] 126
    }
    else{
        DeRef(_23219);
        _23219 = NOVALUE;
    }

    /** 		return lfn[1..8] & lfn[dl..$]*/
    rhs_slice_target = (object_ptr)&_23220;
    RHS_Slice(_lfn_43670, 1, 8);
    if (IS_SEQUENCE(_lfn_43670)){
            _23221 = SEQ_PTR(_lfn_43670)->length;
    }
    else {
        _23221 = 1;
    }
    rhs_slice_target = (object_ptr)&_23222;
    RHS_Slice(_lfn_43670, _dl_43671, _23221);
    Concat((object_ptr)&_23223, _23220, _23222);
    DeRefDS(_23220);
    _23220 = NOVALUE;
    DeRef(_23220);
    _23220 = NOVALUE;
    DeRefDS(_23222);
    _23222 = NOVALUE;
    DeRefDS(_lfn_43670);
    DeRef(_23206);
    _23206 = NOVALUE;
    DeRef(_23210);
    _23210 = NOVALUE;
    DeRef(_23211);
    _23211 = NOVALUE;
    DeRef(_23215);
    _23215 = NOVALUE;
    return _23223;
    goto L2; // [123] 138
L4: 

    /** 		CompileErr( 48, {lfn})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_lfn_43670);
    *((int *)(_2+4)) = _lfn_43670;
    _23224 = MAKE_SEQ(_1);
    _44CompileErr(48, _23224, 0);
    _23224 = NOVALUE;
L2: 
    ;
}


void _57check_file_routines()
{
    int _s_43706 = NOVALUE;
    int _23242 = NOVALUE;
    int _23241 = NOVALUE;
    int _23240 = NOVALUE;
    int _23239 = NOVALUE;
    int _23238 = NOVALUE;
    int _23237 = NOVALUE;
    int _23236 = NOVALUE;
    int _23235 = NOVALUE;
    int _23234 = NOVALUE;
    int _23233 = NOVALUE;
    int _23232 = NOVALUE;
    int _23231 = NOVALUE;
    int _23229 = NOVALUE;
    int _23227 = NOVALUE;
    int _23225 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not length( file_routines ) then*/
    if (IS_SEQUENCE(_57file_routines_43697)){
            _23225 = SEQ_PTR(_57file_routines_43697)->length;
    }
    else {
        _23225 = 1;
    }
    if (_23225 != 0)
    goto L1; // [8] 146
    _23225 = NOVALUE;

    /** 		file_routines = repeat( {}, length( known_files ) )*/
    if (IS_SEQUENCE(_36known_files_15243)){
            _23227 = SEQ_PTR(_36known_files_15243)->length;
    }
    else {
        _23227 = 1;
    }
    DeRefDS(_57file_routines_43697);
    _57file_routines_43697 = Repeat(_22023, _23227);
    _23227 = NOVALUE;

    /** 		integer s = SymTab[TopLevelSub][S_NEXT]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _23229 = (int)*(((s1_ptr)_2)->base + _35TopLevelSub_16251);
    _2 = (int)SEQ_PTR(_23229);
    _s_43706 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_43706)){
        _s_43706 = (long)DBL_PTR(_s_43706)->dbl;
    }
    _23229 = NOVALUE;

    /** 		while s do*/
L2: 
    if (_s_43706 == 0)
    {
        goto L3; // [45] 145
    }
    else{
    }

    /** 			if SymTab[s][S_USAGE] != U_DELETED and*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _23231 = (int)*(((s1_ptr)_2)->base + _s_43706);
    _2 = (int)SEQ_PTR(_23231);
    _23232 = (int)*(((s1_ptr)_2)->base + 5);
    _23231 = NOVALUE;
    if (IS_ATOM_INT(_23232)) {
        _23233 = (_23232 != 99);
    }
    else {
        _23233 = binary_op(NOTEQ, _23232, 99);
    }
    _23232 = NOVALUE;
    if (IS_ATOM_INT(_23233)) {
        if (_23233 == 0) {
            goto L4; // [68] 124
        }
    }
    else {
        if (DBL_PTR(_23233)->dbl == 0.0) {
            goto L4; // [68] 124
        }
    }
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _23235 = (int)*(((s1_ptr)_2)->base + _s_43706);
    _2 = (int)SEQ_PTR(_23235);
    if (!IS_ATOM_INT(_35S_TOKEN_15922)){
        _23236 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TOKEN_15922)->dbl));
    }
    else{
        _23236 = (int)*(((s1_ptr)_2)->base + _35S_TOKEN_15922);
    }
    _23235 = NOVALUE;
    _23237 = find_from(_23236, _37RTN_TOKS_15870, 1);
    _23236 = NOVALUE;
    if (_23237 == 0)
    {
        _23237 = NOVALUE;
        goto L4; // [92] 124
    }
    else{
        _23237 = NOVALUE;
    }

    /** 				file_routines[SymTab[s][S_FILE_NO]] &= s*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _23238 = (int)*(((s1_ptr)_2)->base + _s_43706);
    _2 = (int)SEQ_PTR(_23238);
    if (!IS_ATOM_INT(_35S_FILE_NO_15913)){
        _23239 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FILE_NO_15913)->dbl));
    }
    else{
        _23239 = (int)*(((s1_ptr)_2)->base + _35S_FILE_NO_15913);
    }
    _23238 = NOVALUE;
    _2 = (int)SEQ_PTR(_57file_routines_43697);
    if (!IS_ATOM_INT(_23239)){
        _23240 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_23239)->dbl));
    }
    else{
        _23240 = (int)*(((s1_ptr)_2)->base + _23239);
    }
    if (IS_SEQUENCE(_23240) && IS_ATOM(_s_43706)) {
        Append(&_23241, _23240, _s_43706);
    }
    else if (IS_ATOM(_23240) && IS_SEQUENCE(_s_43706)) {
    }
    else {
        Concat((object_ptr)&_23241, _23240, _s_43706);
        _23240 = NOVALUE;
    }
    _23240 = NOVALUE;
    _2 = (int)SEQ_PTR(_57file_routines_43697);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _57file_routines_43697 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_23239))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_23239)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _23239);
    _1 = *(int *)_2;
    *(int *)_2 = _23241;
    if( _1 != _23241 ){
        DeRef(_1);
    }
    _23241 = NOVALUE;
L4: 

    /** 			s = SymTab[s][S_NEXT]*/
    _2 = (int)SEQ_PTR(_36SymTab_15242);
    _23242 = (int)*(((s1_ptr)_2)->base + _s_43706);
    _2 = (int)SEQ_PTR(_23242);
    _s_43706 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_43706)){
        _s_43706 = (long)DBL_PTR(_s_43706)->dbl;
    }
    _23242 = NOVALUE;

    /** 		end while*/
    goto L2; // [142] 45
L3: 
L1: 

    /** end procedure*/
    _23239 = NOVALUE;
    DeRef(_23233);
    _23233 = NOVALUE;
    return;
    ;
}


void _57GenerateUserRoutines()
{
    int _s_43740 = NOVALUE;
    int _sp_43741 = NOVALUE;
    int _next_c_char_43742 = NOVALUE;
    int _q_43743 = NOVALUE;
    int _temps_43744 = NOVALUE;
    int _buff_43745 = NOVALUE;
    int _base_name_43746 = NOVALUE;
    int _long_c_file_43747 = NOVALUE;
    int _c_file_43748 = NOVALUE;
    int _these_routines_43815 = NOVALUE;
    int _ret_type_43873 = NOVALUE;
    int _scope_43944 = NOVALUE;
    int _names_43978 = NOVALUE;
    int _name_43988 = NOVALUE;
    int _23455 = NOVALUE;
    int _23453 = NOVALUE;
    int _23452 = NOVALUE;
    int _23449 = NOVALUE;
    int _23447 = NOVALUE;
    int _23446 = NOVALUE;
    int _23445 = NOVALUE;
    int _23444 = NOVALUE;
    int _23443 = NOVALUE;
    int _23442 = NOVALUE;
    int _23440 = NOVALUE;
    int _23436 = NOVALUE;
    int _23434 = NOVALUE;
    int _23433 = NOVALUE;
    int _23432 = NOVALUE;
    int _23431 = NOVALUE;
    int _23430 = NOVALUE;
    int _23429 = NOVALUE;
    int _23427 = NOVALUE;
    int _23426 = NOVALUE;
    int _23424 = NOVALUE;
    int _23423 = NOVALUE;
    int _23422 = NOVALUE;
    int _23421 = NOVALUE;
    int _23420 = NOVALUE;
    int _23418 = NOVALUE;
    int _23416 = NOVALUE;
    int _23415 = NOVALUE;
    int _23414 = NOVALUE;
    int _23413 = NOVALUE;
    int _23412 = NOVALUE;
    int _23411 = NOVALUE;
    int _23410 = NOVALUE;
    int _23408 = NOVALUE;
    int _23407 = NOVALUE;
    int _23406 = NOVALUE;
    int _23405 = NOVALUE;
    int _23404 = NOVALUE;
    int _23403 = NOVALUE;
    int _23402 = NOVALUE;
    int _23401 = NOVALUE;
    int _23399 = NOVALUE;
    int _23398 = NOVALUE;
    int _23396 = NOVALUE;
    int _23395 = NOVALUE;
    int _23394 = NOVALUE;
    int _23393 = NOVALUE;
    int _23392 = NOVALUE;
    int _23391 = NOVALUE;
    int _23390 = NOVALUE;
    int _23389 = NOVALUE;
    int _23387 = NOVALUE;
    int _23386 = NOVALUE;
    int _23384 = NOVALUE;
    int _23383 = NOVALUE;
    int _23382 = NOVALUE;
    int _23380 = NOVALUE;
    int _23377 = NOVALUE;
    int _23376 = NOVALUE;
    int _23374 = NOVALUE;
    int _23372 = NOVALUE;
    int _23366 = NOVALUE;
    int _23365 = NOVALUE;
    int _23364 = NOVALUE;
    int _23363 = NOVALUE;
    int _23362 = NOVALUE;
    int _23361 = NOVALUE;
    int _23360 = NOVALUE;
    int _23359 = NOVALUE;
    int _23357 = NOVALUE;
    int _23356 = NOVALUE;
    int _23354 = NOVALUE;
    int _23353 = NOVALUE;
    int _23350 = NOVALUE;
    int _23348 = NOVALUE;
    int _23347 = NOVALUE;
    int _23346 = NOVALUE;
    int _23342 = NOVALUE;
    int _23339 = NOVALUE;
    int _23336 = NOVALUE;
    int _23335 = NOVALUE;
    int _23334 = NOVALUE;
    int _23333 = NOVALUE;
    int _23331 = NOVALUE;
    int _23330 = NOVALUE;
    int _23328 = NOVALUE;
    int _23327 = NOVALUE;
    int _23326 = NOVALUE;
    int _23324 = NOVALUE;
    int _23321 = NOVALUE;
    int _23320 = NOVALUE;
    int _23319 = NOVALUE;
    int _23318 = NOVALUE;
    int _23317 = NOVALUE;
    int _23316 = NOVALUE;
    int _23314 = NOVALUE;
    int _23313 = NOVALUE;
    int _23311 = NOVALUE;
    int _23308 = NOVALUE;
    int _23307 = NOVALUE;
    int _23303 = NOVALUE;
    int _23302 = NOVALUE;
    int _23300 = NOVALUE;
    int _23296 = NOVALUE;
    int _23295 = NOVALUE;
    int _23294 = NOVALUE;
    int _23293 = NOVALUE;
    int _23292 = NOVALUE;
    int _23291 = NOVALUE;
    int _23290 = NOVALUE;
    int _23289 = NOVALUE;
    int _23288 = NOVALUE;
    int _23287 = NOVALUE;
    int _23286 = NOVALUE;
    int _23285 = NOVALUE;
    int _23284 = NOVALUE;
    int _23283 = NOVALUE;
    int _23281 = NOVALUE;
    int _23280 = NOVALUE;
    int _23278 = NOVALUE;
    int _23275 = NOVALUE;
    int _23272 = NOVALUE;
    int _23269 = NOVALUE;
    int _23266 = NOVALUE;
    int _23265 = NOVALUE;
    int _23264 = NOVALUE;
    int _23261 = NOVALUE;
    int _23258 = NOVALUE;
    int _23256 = NOVALUE;
    int _23252 = NOVALUE;
    int _23251 = NOVALUE;
    int _23249 = NOVALUE;
    int _23248 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	integer next_c_char, q, temps*/

    /** 	sequence buff, base_name, long_c_file, c_file*/

    /** 	if not silent then*/
    if (_35silent_16359 != 0)
    goto L1; // [9] 62

    /** 		if Pass = 1 then*/
    if (_57Pass_41665 != 1)
    goto L2; // [16] 29

    /** 			ShowMsg(1, 239,,0)*/
    RefDS(_22023);
    _45ShowMsg(1, 239, _22023, 0);
L2: 

    /** 		if LAST_PASS = TRUE then*/
    if (_57LAST_PASS_41663 != _13TRUE_436)
    goto L3; // [35] 50

    /** 			ShowMsg(1, 240)*/
    RefDS(_22023);
    _45ShowMsg(1, 240, _22023, 1);
    goto L4; // [47] 61
L3: 

    /** 			ShowMsg(1, 241, Pass, 0)*/
    _45ShowMsg(1, 241, _57Pass_41665, 0);
L4: 
L1: 

    /** 	check_file_routines()*/
    _57check_file_routines();

    /** 	c_puts("// GenerateUserRoutines\n")*/
    RefDS(_23247);
    _54c_puts(_23247);

    /** 	for file_no = 1 to length(known_files) do*/
    if (IS_SEQUENCE(_36known_files_15243)){
            _23248 = SEQ_PTR(_36known_files_15243)->length;
    }
    else {
        _23248 = 1;
    }
    {
        int _file_no_43764;
        _file_no_43764 = 1;
L5: 
        if (_file_no_43764 > _23248){
            goto L6; // [78] 2060
        }

        /** 		if file_no = 1 or any_code(file_no) then*/
        _23249 = (_file_no_43764 == 1);
        if (_23249 != 0) {
            goto L7; // [91] 104
        }
        _23251 = _57any_code(_file_no_43764);
        if (_23251 == 0) {
            DeRef(_23251);
            _23251 = NOVALUE;
            goto L8; // [100] 2051
        }
        else {
            if (!IS_ATOM_INT(_23251) && DBL_PTR(_23251)->dbl == 0.0){
                DeRef(_23251);
                _23251 = NOVALUE;
                goto L8; // [100] 2051
            }
            DeRef(_23251);
            _23251 = NOVALUE;
        }
        DeRef(_23251);
        _23251 = NOVALUE;
L7: 

        /** 			next_c_char = 1*/
        _next_c_char_43742 = 1;

        /** 			base_name = name_ext(known_files[file_no])*/
        _2 = (int)SEQ_PTR(_36known_files_15243);
        _23252 = (int)*(((s1_ptr)_2)->base + _file_no_43764);
        Ref(_23252);
        _0 = _base_name_43746;
        _base_name_43746 = _53name_ext(_23252);
        DeRef(_0);
        _23252 = NOVALUE;

        /** 			c_file = base_name*/
        RefDS(_base_name_43746);
        DeRef(_c_file_43748);
        _c_file_43748 = _base_name_43746;

        /** 			q = length(c_file)*/
        if (IS_SEQUENCE(_c_file_43748)){
                _q_43743 = SEQ_PTR(_c_file_43748)->length;
        }
        else {
            _q_43743 = 1;
        }

        /** 			while q >= 1 do*/
L9: 
        if (_q_43743 < 1)
        goto LA; // [140] 181

        /** 				if c_file[q] = '.' then*/
        _2 = (int)SEQ_PTR(_c_file_43748);
        _23256 = (int)*(((s1_ptr)_2)->base + _q_43743);
        if (binary_op_a(NOTEQ, _23256, 46)){
            _23256 = NOVALUE;
            goto LB; // [150] 170
        }
        _23256 = NOVALUE;

        /** 					c_file = c_file[1..q-1]*/
        _23258 = _q_43743 - 1;
        rhs_slice_target = (object_ptr)&_c_file_43748;
        RHS_Slice(_c_file_43748, 1, _23258);

        /** 					exit*/
        goto LA; // [167] 181
LB: 

        /** 				q -= 1*/
        _q_43743 = _q_43743 - 1;

        /** 			end while*/
        goto L9; // [178] 140
LA: 

        /** 			if find(lower(c_file), {"main-", "init-"})  then*/
        RefDS(_c_file_43748);
        _23261 = _14lower(_c_file_43748);
        RefDS(_23263);
        RefDS(_23262);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _23262;
        ((int *)_2)[2] = _23263;
        _23264 = MAKE_SEQ(_1);
        _23265 = find_from(_23261, _23264, 1);
        DeRef(_23261);
        _23261 = NOVALUE;
        DeRefDS(_23264);
        _23264 = NOVALUE;
        if (_23265 == 0)
        {
            _23265 = NOVALUE;
            goto LC; // [196] 211
        }
        else{
            _23265 = NOVALUE;
        }

        /** 				CompileErr(12, {base_name})*/
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        RefDS(_base_name_43746);
        *((int *)(_2+4)) = _base_name_43746;
        _23266 = MAKE_SEQ(_1);
        _44CompileErr(12, _23266, 0);
        _23266 = NOVALUE;
LC: 

        /** 			long_c_file = c_file*/
        RefDS(_c_file_43748);
        DeRef(_long_c_file_43747);
        _long_c_file_43747 = _c_file_43748;

        /** 			if LAST_PASS = TRUE then*/
        if (_57LAST_PASS_41663 != _13TRUE_436)
        goto LD; // [224] 249

        /** 				c_file = unique_c_name(c_file)*/
        RefDS(_c_file_43748);
        _0 = _c_file_43748;
        _c_file_43748 = _57unique_c_name(_c_file_43748);
        DeRefDS(_0);

        /** 				add_file(c_file, known_files[file_no])*/
        _2 = (int)SEQ_PTR(_36known_files_15243);
        _23269 = (int)*(((s1_ptr)_2)->base + _file_no_43764);
        RefDS(_c_file_43748);
        Ref(_23269);
        _57add_file(_c_file_43748, _23269);
        _23269 = NOVALUE;
LD: 

        /** 			if file_no = 1 then*/
        if (_file_no_43764 != 1)
        goto LE; // [251] 314

        /** 				if LAST_PASS = TRUE then*/
        if (_57LAST_PASS_41663 != _13TRUE_436)
        goto LF; // [261] 306

        /** 					add_file("main-")*/
        RefDS(_23262);
        RefDS(_22023);
        _57add_file(_23262, _22023);

        /** 					for i = 0 to main_name_num-1 do*/
        _23272 = _54main_name_num_45493 - 1;
        if ((long)((unsigned long)_23272 +(unsigned long) HIGH_BITS) >= 0){
            _23272 = NewDouble((double)_23272);
        }
        {
            int _i_43805;
            _i_43805 = 0;
L10: 
            if (binary_op_a(GREATER, _i_43805, _23272)){
                goto L11; // [279] 305
            }

            /** 						buff = sprintf("main-%d", i)*/
            DeRefi(_buff_43745);
            _buff_43745 = EPrintf(-9999999, _23273, _i_43805);

            /** 						add_file(buff)*/
            RefDS(_buff_43745);
            RefDS(_22023);
            _57add_file(_buff_43745, _22023);

            /** 					end for*/
            _0 = _i_43805;
            if (IS_ATOM_INT(_i_43805)) {
                _i_43805 = _i_43805 + 1;
                if ((long)((unsigned long)_i_43805 +(unsigned long) HIGH_BITS) >= 0){
                    _i_43805 = NewDouble((double)_i_43805);
                }
            }
            else {
                _i_43805 = binary_op_a(PLUS, _i_43805, 1);
            }
            DeRef(_0);
            goto L10; // [300] 286
L11: 
            ;
            DeRef(_i_43805);
        }
LF: 

        /** 				file0 = long_c_file*/
        RefDS(_long_c_file_43747);
        DeRef(_57file0_43504);
        _57file0_43504 = _long_c_file_43747;
LE: 

        /** 			new_c_file(c_file)*/
        RefDS(_c_file_43748);
        _57new_c_file(_c_file_43748);

        /** 			s = SymTab[TopLevelSub][S_NEXT]*/
        _2 = (int)SEQ_PTR(_36SymTab_15242);
        _23275 = (int)*(((s1_ptr)_2)->base + _35TopLevelSub_16251);
        _2 = (int)SEQ_PTR(_23275);
        _s_43740 = (int)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_s_43740)){
            _s_43740 = (long)DBL_PTR(_s_43740)->dbl;
        }
        _23275 = NOVALUE;

        /** 			sequence these_routines = file_routines[file_no]*/
        DeRef(_these_routines_43815);
        _2 = (int)SEQ_PTR(_57file_routines_43697);
        _these_routines_43815 = (int)*(((s1_ptr)_2)->base + _file_no_43764);
        Ref(_these_routines_43815);

        /** 			for routine_no = 1 to length( these_routines ) do*/
        if (IS_SEQUENCE(_these_routines_43815)){
                _23278 = SEQ_PTR(_these_routines_43815)->length;
        }
        else {
            _23278 = 1;
        }
        {
            int _routine_no_43818;
            _routine_no_43818 = 1;
L12: 
            if (_routine_no_43818 > _23278){
                goto L13; // [352] 2050
            }

            /** 				s = these_routines[routine_no]*/
            _2 = (int)SEQ_PTR(_these_routines_43815);
            _s_43740 = (int)*(((s1_ptr)_2)->base + _routine_no_43818);
            if (!IS_ATOM_INT(_s_43740)){
                _s_43740 = (long)DBL_PTR(_s_43740)->dbl;
            }

            /** 				if SymTab[s][S_USAGE] != U_DELETED then*/
            _2 = (int)SEQ_PTR(_36SymTab_15242);
            _23280 = (int)*(((s1_ptr)_2)->base + _s_43740);
            _2 = (int)SEQ_PTR(_23280);
            _23281 = (int)*(((s1_ptr)_2)->base + 5);
            _23280 = NOVALUE;
            if (binary_op_a(EQUALS, _23281, 99)){
                _23281 = NOVALUE;
                goto L14; // [383] 2041
            }
            _23281 = NOVALUE;

            /** 					if LAST_PASS = TRUE and*/
            _23283 = (_57LAST_PASS_41663 == _13TRUE_436);
            if (_23283 == 0) {
                goto L15; // [397] 593
            }
            _23285 = (_35cfile_size_16323 > _55max_cfile_size_44337);
            if (_23285 != 0) {
                DeRef(_23286);
                _23286 = 1;
                goto L16; // [409] 472
            }
            _23287 = (_s_43740 != _35TopLevelSub_16251);
            if (_23287 == 0) {
                _23288 = 0;
                goto L17; // [419] 439
            }
            _23289 = (_55max_cfile_size_44337 % 4) ? NewDouble((double)_55max_cfile_size_44337 / 4) : (_55max_cfile_size_44337 / 4);
            if (IS_ATOM_INT(_23289)) {
                _23290 = (_35cfile_size_16323 > _23289);
            }
            else {
                _23290 = ((double)_35cfile_size_16323 > DBL_PTR(_23289)->dbl);
            }
            DeRef(_23289);
            _23289 = NOVALUE;
            _23288 = (_23290 != 0);
L17: 
            if (_23288 == 0) {
                _23291 = 0;
                goto L18; // [439] 468
            }
            _2 = (int)SEQ_PTR(_36SymTab_15242);
            _23292 = (int)*(((s1_ptr)_2)->base + _s_43740);
            _2 = (int)SEQ_PTR(_23292);
            if (!IS_ATOM_INT(_35S_CODE_15929)){
                _23293 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_CODE_15929)->dbl));
            }
            else{
                _23293 = (int)*(((s1_ptr)_2)->base + _35S_CODE_15929);
            }
            _23292 = NOVALUE;
            if (IS_SEQUENCE(_23293)){
                    _23294 = SEQ_PTR(_23293)->length;
            }
            else {
                _23294 = 1;
            }
            _23293 = NOVALUE;
            _23295 = (_23294 > _55max_cfile_size_44337);
            _23294 = NOVALUE;
            _23291 = (_23295 != 0);
L18: 
            DeRef(_23286);
            _23286 = (_23291 != 0);
L16: 
            if (_23286 == 0)
            {
                _23286 = NOVALUE;
                goto L15; // [473] 593
            }
            else{
                _23286 = NOVALUE;
            }

            /** 						if length(c_file) = 7 then*/
            if (IS_SEQUENCE(_c_file_43748)){
                    _23296 = SEQ_PTR(_c_file_43748)->length;
            }
            else {
                _23296 = 1;
            }
            if (_23296 != 7)
            goto L19; // [481] 492

            /** 							c_file &= " "*/
            Concat((object_ptr)&_c_file_43748, _c_file_43748, _23298);
L19: 

            /** 						if length(c_file) >= 8 then*/
            if (IS_SEQUENCE(_c_file_43748)){
                    _23300 = SEQ_PTR(_c_file_43748)->length;
            }
            else {
                _23300 = 1;
            }
            if (_23300 < 8)
            goto L1A; // [497] 520

            /** 							c_file[7] = '_'*/
            _2 = (int)SEQ_PTR(_c_file_43748);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _c_file_43748 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + 7);
            _1 = *(int *)_2;
            *(int *)_2 = 95;
            DeRef(_1);

            /** 							c_file[8] = file_chars[next_c_char]*/
            _2 = (int)SEQ_PTR(_57file_chars_43370);
            _23302 = (int)*(((s1_ptr)_2)->base + _next_c_char_43742);
            Ref(_23302);
            _2 = (int)SEQ_PTR(_c_file_43748);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _c_file_43748 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + 8);
            _1 = *(int *)_2;
            *(int *)_2 = _23302;
            if( _1 != _23302 ){
                DeRef(_1);
            }
            _23302 = NOVALUE;
            goto L1B; // [517] 552
L1A: 

            /** 							if find('_', c_file) = 0 then*/
            _23303 = find_from(95, _c_file_43748, 1);
            if (_23303 != 0)
            goto L1C; // [527] 538

            /** 								c_file &= "_ "*/
            Concat((object_ptr)&_c_file_43748, _c_file_43748, _23305);
L1C: 

            /** 							c_file[$] = file_chars[next_c_char]*/
            if (IS_SEQUENCE(_c_file_43748)){
                    _23307 = SEQ_PTR(_c_file_43748)->length;
            }
            else {
                _23307 = 1;
            }
            _2 = (int)SEQ_PTR(_57file_chars_43370);
            _23308 = (int)*(((s1_ptr)_2)->base + _next_c_char_43742);
            Ref(_23308);
            _2 = (int)SEQ_PTR(_c_file_43748);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _c_file_43748 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _23307);
            _1 = *(int *)_2;
            *(int *)_2 = _23308;
            if( _1 != _23308 ){
                DeRef(_1);
            }
            _23308 = NOVALUE;
L1B: 

            /** 						c_file = unique_c_name(c_file)*/
            RefDS(_c_file_43748);
            _0 = _c_file_43748;
            _c_file_43748 = _57unique_c_name(_c_file_43748);
            DeRefDS(_0);

            /** 						new_c_file(c_file)*/
            RefDS(_c_file_43748);
            _57new_c_file(_c_file_43748);

            /** 						next_c_char += 1*/
            _next_c_char_43742 = _next_c_char_43742 + 1;

            /** 						if next_c_char > length(file_chars) then*/
            if (IS_SEQUENCE(_57file_chars_43370)){
                    _23311 = SEQ_PTR(_57file_chars_43370)->length;
            }
            else {
                _23311 = 1;
            }
            if (_next_c_char_43742 <= _23311)
            goto L1D; // [576] 586

            /** 							next_c_char = 1  -- (unique_c_name will resolve)*/
            _next_c_char_43742 = 1;
L1D: 

            /** 						add_file(c_file)*/
            RefDS(_c_file_43748);
            RefDS(_22023);
            _57add_file(_c_file_43748, _22023);
L15: 

            /** 					sequence ret_type*/

            /** 					if SymTab[s][S_TOKEN] = PROC then*/
            _2 = (int)SEQ_PTR(_36SymTab_15242);
            _23313 = (int)*(((s1_ptr)_2)->base + _s_43740);
            _2 = (int)SEQ_PTR(_23313);
            if (!IS_ATOM_INT(_35S_TOKEN_15922)){
                _23314 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TOKEN_15922)->dbl));
            }
            else{
                _23314 = (int)*(((s1_ptr)_2)->base + _35S_TOKEN_15922);
            }
            _23313 = NOVALUE;
            if (binary_op_a(NOTEQ, _23314, 27)){
                _23314 = NOVALUE;
                goto L1E; // [611] 625
            }
            _23314 = NOVALUE;

            /** 						ret_type = "void "*/
            RefDS(_22735);
            DeRefi(_ret_type_43873);
            _ret_type_43873 = _22735;
            goto L1F; // [622] 633
L1E: 

            /** 						ret_type = "int "*/
            RefDS(_22736);
            DeRefi(_ret_type_43873);
            _ret_type_43873 = _22736;
L1F: 

            /** 					if find( SymTab[s][S_SCOPE], {SC_GLOBAL, SC_EXPORT, SC_PUBLIC} ) and dll_option then*/
            _2 = (int)SEQ_PTR(_36SymTab_15242);
            _23316 = (int)*(((s1_ptr)_2)->base + _s_43740);
            _2 = (int)SEQ_PTR(_23316);
            _23317 = (int)*(((s1_ptr)_2)->base + 4);
            _23316 = NOVALUE;
            _1 = NewS1(3);
            _2 = (int)((s1_ptr)_1)->base;
            *((int *)(_2+4)) = 6;
            *((int *)(_2+8)) = 11;
            *((int *)(_2+12)) = 13;
            _23318 = MAKE_SEQ(_1);
            _23319 = find_from(_23317, _23318, 1);
            _23317 = NOVALUE;
            DeRefDS(_23318);
            _23318 = NOVALUE;
            if (_23319 == 0) {
                goto L20; // [664] 740
            }
            if (_57dll_option_41676 == 0)
            {
                goto L20; // [671] 740
            }
            else{
            }

            /** 						SymTab[s][S_RI_TARGET] = TRUE*/
            _2 = (int)SEQ_PTR(_36SymTab_15242);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _36SymTab_15242 = MAKE_SEQ(_2);
            }
            _3 = (int)(_s_43740 + ((s1_ptr)_2)->base);
            _2 = (int)SEQ_PTR(*(int *)_3);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                *(int *)_3 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + 53);
            _1 = *(int *)_2;
            *(int *)_2 = _13TRUE_436;
            DeRef(_1);
            _23321 = NOVALUE;

            /** 						LeftSym = TRUE*/
            _57LeftSym_41673 = _13TRUE_436;

            /** 						if TWINDOWS then*/
            if (_40TWINDOWS_16388 == 0)
            {
                goto L21; // [704] 723
            }
            else{
            }

            /** 							c_stmt(ret_type & " __stdcall @(", s)*/
            Concat((object_ptr)&_23324, _ret_type_43873, _23323);
            _57c_stmt(_23324, _s_43740, 0);
            _23324 = NOVALUE;
            goto L22; // [720] 763
L21: 

            /** 							c_stmt(ret_type & "@(", s)*/
            Concat((object_ptr)&_23326, _ret_type_43873, _23325);
            _57c_stmt(_23326, _s_43740, 0);
            _23326 = NOVALUE;
            goto L22; // [737] 763
L20: 

            /** 						LeftSym = TRUE*/
            _57LeftSym_41673 = _13TRUE_436;

            /** 						c_stmt( ret_type & "@(", s)*/
            Concat((object_ptr)&_23327, _ret_type_43873, _23325);
            _57c_stmt(_23327, _s_43740, 0);
            _23327 = NOVALUE;
L22: 

            /** 					sp = SymTab[s][S_NEXT]*/
            _2 = (int)SEQ_PTR(_36SymTab_15242);
            _23328 = (int)*(((s1_ptr)_2)->base + _s_43740);
            _2 = (int)SEQ_PTR(_23328);
            _sp_43741 = (int)*(((s1_ptr)_2)->base + 2);
            if (!IS_ATOM_INT(_sp_43741)){
                _sp_43741 = (long)DBL_PTR(_sp_43741)->dbl;
            }
            _23328 = NOVALUE;

            /** 					for p = 1 to SymTab[s][S_NUM_ARGS] do*/
            _2 = (int)SEQ_PTR(_36SymTab_15242);
            _23330 = (int)*(((s1_ptr)_2)->base + _s_43740);
            _2 = (int)SEQ_PTR(_23330);
            if (!IS_ATOM_INT(_35S_NUM_ARGS_15968)){
                _23331 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NUM_ARGS_15968)->dbl));
            }
            else{
                _23331 = (int)*(((s1_ptr)_2)->base + _35S_NUM_ARGS_15968);
            }
            _23330 = NOVALUE;
            {
                int _p_43914;
                _p_43914 = 1;
L23: 
                if (binary_op_a(GREATER, _p_43914, _23331)){
                    goto L24; // [793] 869
                }

                /** 						c_puts("int _")*/
                RefDS(_23332);
                _54c_puts(_23332);

                /** 						c_puts(SymTab[sp][S_NAME])*/
                _2 = (int)SEQ_PTR(_36SymTab_15242);
                _23333 = (int)*(((s1_ptr)_2)->base + _sp_43741);
                _2 = (int)SEQ_PTR(_23333);
                if (!IS_ATOM_INT(_35S_NAME_15917)){
                    _23334 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15917)->dbl));
                }
                else{
                    _23334 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15917);
                }
                _23333 = NOVALUE;
                Ref(_23334);
                _54c_puts(_23334);
                _23334 = NOVALUE;

                /** 						if p != SymTab[s][S_NUM_ARGS] then*/
                _2 = (int)SEQ_PTR(_36SymTab_15242);
                _23335 = (int)*(((s1_ptr)_2)->base + _s_43740);
                _2 = (int)SEQ_PTR(_23335);
                if (!IS_ATOM_INT(_35S_NUM_ARGS_15968)){
                    _23336 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NUM_ARGS_15968)->dbl));
                }
                else{
                    _23336 = (int)*(((s1_ptr)_2)->base + _35S_NUM_ARGS_15968);
                }
                _23335 = NOVALUE;
                if (binary_op_a(EQUALS, _p_43914, _23336)){
                    _23336 = NOVALUE;
                    goto L25; // [836] 846
                }
                _23336 = NOVALUE;

                /** 							c_puts(", ")*/
                RefDS(_23338);
                _54c_puts(_23338);
L25: 

                /** 						sp = SymTab[sp][S_NEXT]*/
                _2 = (int)SEQ_PTR(_36SymTab_15242);
                _23339 = (int)*(((s1_ptr)_2)->base + _sp_43741);
                _2 = (int)SEQ_PTR(_23339);
                _sp_43741 = (int)*(((s1_ptr)_2)->base + 2);
                if (!IS_ATOM_INT(_sp_43741)){
                    _sp_43741 = (long)DBL_PTR(_sp_43741)->dbl;
                }
                _23339 = NOVALUE;

                /** 					end for*/
                _0 = _p_43914;
                if (IS_ATOM_INT(_p_43914)) {
                    _p_43914 = _p_43914 + 1;
                    if ((long)((unsigned long)_p_43914 +(unsigned long) HIGH_BITS) >= 0){
                        _p_43914 = NewDouble((double)_p_43914);
                    }
                }
                else {
                    _p_43914 = binary_op_a(PLUS, _p_43914, 1);
                }
                DeRef(_0);
                goto L23; // [864] 800
L24: 
                ;
                DeRef(_p_43914);
            }

            /** 					c_puts(")\n")*/
            RefDS(_23341);
            _54c_puts(_23341);

            /** 					c_stmt0("{\n")*/
            RefDS(_22180);
            _57c_stmt0(_22180);

            /** 					NewBB(0, E_ALL_EFFECT, 0)*/
            _57NewBB(0, 1073741823, 0);

            /** 					Initializing = TRUE*/
            _35Initializing_16324 = _13TRUE_436;

            /** 					while sp do*/
L26: 
            if (_sp_43741 == 0)
            {
                goto L27; // [902] 1041
            }
            else{
            }

            /** 						integer scope = SymTab[sp][S_SCOPE]*/
            _2 = (int)SEQ_PTR(_36SymTab_15242);
            _23342 = (int)*(((s1_ptr)_2)->base + _sp_43741);
            _2 = (int)SEQ_PTR(_23342);
            _scope_43944 = (int)*(((s1_ptr)_2)->base + 4);
            if (!IS_ATOM_INT(_scope_43944)){
                _scope_43944 = (long)DBL_PTR(_scope_43944)->dbl;
            }
            _23342 = NOVALUE;

            /** 						switch scope with fallthru do*/
            _0 = _scope_43944;
            switch ( _0 ){ 

                /** 							case SC_LOOP_VAR, SC_UNDEFINED then*/
                case 2:
                case 9:

                /** 								break*/
                goto L28; // [936] 1018

                /** 							case SC_PRIVATE then*/
                case 3:

                /** 								c_stmt0("int ")*/
                RefDS(_22736);
                _57c_stmt0(_22736);

                /** 								c_puts("_")*/
                RefDS(_22095);
                _54c_puts(_22095);

                /** 								c_puts(SymTab[sp][S_NAME])*/
                _2 = (int)SEQ_PTR(_36SymTab_15242);
                _23346 = (int)*(((s1_ptr)_2)->base + _sp_43741);
                _2 = (int)SEQ_PTR(_23346);
                if (!IS_ATOM_INT(_35S_NAME_15917)){
                    _23347 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15917)->dbl));
                }
                else{
                    _23347 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15917);
                }
                _23346 = NOVALUE;
                Ref(_23347);
                _54c_puts(_23347);
                _23347 = NOVALUE;

                /** 								c_puts(" = NOVALUE;\n")*/
                RefDS(_22743);
                _54c_puts(_22743);

                /** 								target[MIN] = NOVALUE*/
                Ref(_35NOVALUE_16099);
                _2 = (int)SEQ_PTR(_58target_27454);
                if (!UNIQUE(_2)) {
                    _2 = (int)SequenceCopy((s1_ptr)_2);
                    _58target_27454 = MAKE_SEQ(_2);
                }
                _2 = (int)(((s1_ptr)_2)->base + 1);
                _1 = *(int *)_2;
                *(int *)_2 = _35NOVALUE_16099;
                DeRef(_1);

                /** 								target[MAX] = NOVALUE*/
                Ref(_35NOVALUE_16099);
                _2 = (int)SEQ_PTR(_58target_27454);
                if (!UNIQUE(_2)) {
                    _2 = (int)SequenceCopy((s1_ptr)_2);
                    _58target_27454 = MAKE_SEQ(_2);
                }
                _2 = (int)(((s1_ptr)_2)->base + 2);
                _1 = *(int *)_2;
                *(int *)_2 = _35NOVALUE_16099;
                DeRef(_1);

                /** 								RemoveFromBB( sp )*/
                _57RemoveFromBB(_sp_43741);

                /** 								break*/
                goto L28; // [1005] 1018

                /** 							case else*/
                default:

                /** 								exit*/
                goto L27; // [1015] 1041
            ;}L28: 

            /** 						sp = SymTab[sp][S_NEXT]*/
            _2 = (int)SEQ_PTR(_36SymTab_15242);
            _23348 = (int)*(((s1_ptr)_2)->base + _sp_43741);
            _2 = (int)SEQ_PTR(_23348);
            _sp_43741 = (int)*(((s1_ptr)_2)->base + 2);
            if (!IS_ATOM_INT(_sp_43741)){
                _sp_43741 = (long)DBL_PTR(_sp_43741)->dbl;
            }
            _23348 = NOVALUE;

            /** 					end while*/
            goto L26; // [1038] 902
L27: 

            /** 					temps = SymTab[s][S_TEMPS]*/
            _2 = (int)SEQ_PTR(_36SymTab_15242);
            _23350 = (int)*(((s1_ptr)_2)->base + _s_43740);
            _2 = (int)SEQ_PTR(_23350);
            if (!IS_ATOM_INT(_35S_TEMPS_15962)){
                _temps_43744 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TEMPS_15962)->dbl));
            }
            else{
                _temps_43744 = (int)*(((s1_ptr)_2)->base + _35S_TEMPS_15962);
            }
            if (!IS_ATOM_INT(_temps_43744)){
                _temps_43744 = (long)DBL_PTR(_temps_43744)->dbl;
            }
            _23350 = NOVALUE;

            /** 					sequence names = {}*/
            RefDS(_22023);
            DeRef(_names_43978);
            _names_43978 = _22023;

            /** 					while temps != 0 do*/
L29: 
            if (_temps_43744 == 0)
            goto L2A; // [1069] 1261

            /** 						if SymTab[temps][S_SCOPE] != DELETED then*/
            _2 = (int)SEQ_PTR(_36SymTab_15242);
            _23353 = (int)*(((s1_ptr)_2)->base + _temps_43744);
            _2 = (int)SEQ_PTR(_23353);
            _23354 = (int)*(((s1_ptr)_2)->base + 4);
            _23353 = NOVALUE;
            if (binary_op_a(EQUALS, _23354, 2)){
                _23354 = NOVALUE;
                goto L2B; // [1089] 1221
            }
            _23354 = NOVALUE;

            /** 							sequence name = sprintf("_%d", SymTab[temps][S_TEMP_NAME] )*/
            _2 = (int)SEQ_PTR(_36SymTab_15242);
            _23356 = (int)*(((s1_ptr)_2)->base + _temps_43744);
            _2 = (int)SEQ_PTR(_23356);
            _23357 = (int)*(((s1_ptr)_2)->base + 34);
            _23356 = NOVALUE;
            DeRefi(_name_43988);
            _name_43988 = EPrintf(-9999999, _22116, _23357);
            _23357 = NOVALUE;

            /** 							if temp_name_type[SymTab[temps][S_TEMP_NAME]][T_GTYPE]*/
            _2 = (int)SEQ_PTR(_36SymTab_15242);
            _23359 = (int)*(((s1_ptr)_2)->base + _temps_43744);
            _2 = (int)SEQ_PTR(_23359);
            _23360 = (int)*(((s1_ptr)_2)->base + 34);
            _23359 = NOVALUE;
            _2 = (int)SEQ_PTR(_35temp_name_type_16326);
            if (!IS_ATOM_INT(_23360)){
                _23361 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_23360)->dbl));
            }
            else{
                _23361 = (int)*(((s1_ptr)_2)->base + _23360);
            }
            _2 = (int)SEQ_PTR(_23361);
            _23362 = (int)*(((s1_ptr)_2)->base + 1);
            _23361 = NOVALUE;
            if (IS_ATOM_INT(_23362)) {
                _23363 = (_23362 != 0);
            }
            else {
                _23363 = binary_op(NOTEQ, _23362, 0);
            }
            _23362 = NOVALUE;
            if (IS_ATOM_INT(_23363)) {
                if (_23363 == 0) {
                    goto L2C; // [1143] 1217
                }
            }
            else {
                if (DBL_PTR(_23363)->dbl == 0.0) {
                    goto L2C; // [1143] 1217
                }
            }
            _23365 = find_from(_name_43988, _names_43978, 1);
            _23366 = (_23365 == 0);
            _23365 = NOVALUE;
            if (_23366 == 0)
            {
                DeRef(_23366);
                _23366 = NOVALUE;
                goto L2C; // [1156] 1217
            }
            else{
                DeRef(_23366);
                _23366 = NOVALUE;
            }

            /** 								c_stmt0("int ")*/
            RefDS(_22736);
            _57c_stmt0(_22736);

            /** 								c_puts( name )*/
            RefDS(_name_43988);
            _54c_puts(_name_43988);

            /** 								c_puts(" = NOVALUE")*/
            RefDS(_23367);
            _54c_puts(_23367);

            /** 								target = {NOVALUE, NOVALUE}*/
            Ref(_35NOVALUE_16099);
            Ref(_35NOVALUE_16099);
            DeRef(_58target_27454);
            _1 = NewS1(2);
            _2 = (int)((s1_ptr)_1)->base;
            ((int *)_2)[1] = _35NOVALUE_16099;
            ((int *)_2)[2] = _35NOVALUE_16099;
            _58target_27454 = MAKE_SEQ(_1);

            /** 								SetBBType(temps, TYPE_INTEGER, target, TYPE_OBJECT, 0)*/
            RefDS(_58target_27454);
            _57SetBBType(_temps_43744, 1, _58target_27454, 16, 0);

            /** 								ifdef DEBUG then*/

            /** 									c_puts(";\n")*/
            RefDS(_22253);
            _54c_puts(_22253);

            /** 								names = prepend( names, name )*/
            RefDS(_name_43988);
            Prepend(&_names_43978, _names_43978, _name_43988);
            goto L2D; // [1214] 1220
L2C: 

            /** 								ifdef DEBUG then*/
L2D: 
L2B: 
            DeRefi(_name_43988);
            _name_43988 = NOVALUE;

            /** 						SymTab[temps][S_GTYPE] = TYPE_OBJECT*/
            _2 = (int)SEQ_PTR(_36SymTab_15242);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _36SymTab_15242 = MAKE_SEQ(_2);
            }
            _3 = (int)(_temps_43744 + ((s1_ptr)_2)->base);
            _2 = (int)SEQ_PTR(*(int *)_3);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                *(int *)_3 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + 36);
            _1 = *(int *)_2;
            *(int *)_2 = 16;
            DeRef(_1);
            _23372 = NOVALUE;

            /** 						temps = SymTab[temps][S_NEXT]*/
            _2 = (int)SEQ_PTR(_36SymTab_15242);
            _23374 = (int)*(((s1_ptr)_2)->base + _temps_43744);
            _2 = (int)SEQ_PTR(_23374);
            _temps_43744 = (int)*(((s1_ptr)_2)->base + 2);
            if (!IS_ATOM_INT(_temps_43744)){
                _temps_43744 = (long)DBL_PTR(_temps_43744)->dbl;
            }
            _23374 = NOVALUE;

            /** 					end while*/
            goto L29; // [1258] 1069
L2A: 

            /** 					Initializing = FALSE*/
            _35Initializing_16324 = _13FALSE_434;

            /** 					if SymTab[s][S_LHS_SUBS2] then*/
            _2 = (int)SEQ_PTR(_36SymTab_15242);
            _23376 = (int)*(((s1_ptr)_2)->base + _s_43740);
            _2 = (int)SEQ_PTR(_23376);
            _23377 = (int)*(((s1_ptr)_2)->base + 37);
            _23376 = NOVALUE;
            if (_23377 == 0) {
                _23377 = NOVALUE;
                goto L2E; // [1284] 1295
            }
            else {
                if (!IS_ATOM_INT(_23377) && DBL_PTR(_23377)->dbl == 0.0){
                    _23377 = NOVALUE;
                    goto L2E; // [1284] 1295
                }
                _23377 = NOVALUE;
            }
            _23377 = NOVALUE;

            /** 						c_stmt0("int _0, _1, _2, _3;\n\n")*/
            RefDS(_23378);
            _57c_stmt0(_23378);
            goto L2F; // [1292] 1301
L2E: 

            /** 						c_stmt0("int _0, _1, _2;\n\n")*/
            RefDS(_23379);
            _57c_stmt0(_23379);
L2F: 

            /** 					sp = SymTab[s][S_NEXT]*/
            _2 = (int)SEQ_PTR(_36SymTab_15242);
            _23380 = (int)*(((s1_ptr)_2)->base + _s_43740);
            _2 = (int)SEQ_PTR(_23380);
            _sp_43741 = (int)*(((s1_ptr)_2)->base + 2);
            if (!IS_ATOM_INT(_sp_43741)){
                _sp_43741 = (long)DBL_PTR(_sp_43741)->dbl;
            }
            _23380 = NOVALUE;

            /** 					for p = 1 to SymTab[s][S_NUM_ARGS] do*/
            _2 = (int)SEQ_PTR(_36SymTab_15242);
            _23382 = (int)*(((s1_ptr)_2)->base + _s_43740);
            _2 = (int)SEQ_PTR(_23382);
            if (!IS_ATOM_INT(_35S_NUM_ARGS_15968)){
                _23383 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NUM_ARGS_15968)->dbl));
            }
            else{
                _23383 = (int)*(((s1_ptr)_2)->base + _35S_NUM_ARGS_15968);
            }
            _23382 = NOVALUE;
            {
                int _p_44047;
                _p_44047 = 1;
L30: 
                if (binary_op_a(GREATER, _p_44047, _23383)){
                    goto L31; // [1331] 1682
                }

                /** 						SymTab[sp][S_ONE_REF] = FALSE*/
                _2 = (int)SEQ_PTR(_36SymTab_15242);
                if (!UNIQUE(_2)) {
                    _2 = (int)SequenceCopy((s1_ptr)_2);
                    _36SymTab_15242 = MAKE_SEQ(_2);
                }
                _3 = (int)(_sp_43741 + ((s1_ptr)_2)->base);
                _2 = (int)SEQ_PTR(*(int *)_3);
                if (!UNIQUE(_2)) {
                    _2 = (int)SequenceCopy((s1_ptr)_2);
                    *(int *)_3 = MAKE_SEQ(_2);
                }
                _2 = (int)(((s1_ptr)_2)->base + 35);
                _1 = *(int *)_2;
                *(int *)_2 = _13FALSE_434;
                DeRef(_1);
                _23384 = NOVALUE;

                /** 						if SymTab[sp][S_ARG_TYPE] = TYPE_SEQUENCE then*/
                _2 = (int)SEQ_PTR(_36SymTab_15242);
                _23386 = (int)*(((s1_ptr)_2)->base + _sp_43741);
                _2 = (int)SEQ_PTR(_23386);
                _23387 = (int)*(((s1_ptr)_2)->base + 43);
                _23386 = NOVALUE;
                if (binary_op_a(NOTEQ, _23387, 8)){
                    _23387 = NOVALUE;
                    goto L32; // [1371] 1435
                }
                _23387 = NOVALUE;

                /** 							target[MIN] = SymTab[sp][S_ARG_SEQ_LEN]*/
                _2 = (int)SEQ_PTR(_36SymTab_15242);
                _23389 = (int)*(((s1_ptr)_2)->base + _sp_43741);
                _2 = (int)SEQ_PTR(_23389);
                _23390 = (int)*(((s1_ptr)_2)->base + 51);
                _23389 = NOVALUE;
                Ref(_23390);
                _2 = (int)SEQ_PTR(_58target_27454);
                if (!UNIQUE(_2)) {
                    _2 = (int)SequenceCopy((s1_ptr)_2);
                    _58target_27454 = MAKE_SEQ(_2);
                }
                _2 = (int)(((s1_ptr)_2)->base + 1);
                _1 = *(int *)_2;
                *(int *)_2 = _23390;
                if( _1 != _23390 ){
                    DeRef(_1);
                }
                _23390 = NOVALUE;

                /** 							SetBBType(sp, SymTab[sp][S_ARG_TYPE], target,*/
                _2 = (int)SEQ_PTR(_36SymTab_15242);
                _23391 = (int)*(((s1_ptr)_2)->base + _sp_43741);
                _2 = (int)SEQ_PTR(_23391);
                _23392 = (int)*(((s1_ptr)_2)->base + 43);
                _23391 = NOVALUE;
                _2 = (int)SEQ_PTR(_36SymTab_15242);
                _23393 = (int)*(((s1_ptr)_2)->base + _sp_43741);
                _2 = (int)SEQ_PTR(_23393);
                _23394 = (int)*(((s1_ptr)_2)->base + 45);
                _23393 = NOVALUE;
                Ref(_23392);
                RefDS(_58target_27454);
                Ref(_23394);
                _57SetBBType(_sp_43741, _23392, _58target_27454, _23394, 0);
                _23392 = NOVALUE;
                _23394 = NOVALUE;
                goto L33; // [1432] 1659
L32: 

                /** 						elsif SymTab[sp][S_ARG_TYPE] = TYPE_INTEGER then*/
                _2 = (int)SEQ_PTR(_36SymTab_15242);
                _23395 = (int)*(((s1_ptr)_2)->base + _sp_43741);
                _2 = (int)SEQ_PTR(_23395);
                _23396 = (int)*(((s1_ptr)_2)->base + 43);
                _23395 = NOVALUE;
                if (binary_op_a(NOTEQ, _23396, 1)){
                    _23396 = NOVALUE;
                    goto L34; // [1451] 1575
                }
                _23396 = NOVALUE;

                /** 							if SymTab[sp][S_ARG_MIN] = NOVALUE then*/
                _2 = (int)SEQ_PTR(_36SymTab_15242);
                _23398 = (int)*(((s1_ptr)_2)->base + _sp_43741);
                _2 = (int)SEQ_PTR(_23398);
                _23399 = (int)*(((s1_ptr)_2)->base + 47);
                _23398 = NOVALUE;
                if (binary_op_a(NOTEQ, _23399, _35NOVALUE_16099)){
                    _23399 = NOVALUE;
                    goto L35; // [1471] 1502
                }
                _23399 = NOVALUE;

                /** 								target[MIN] = MININT*/
                _2 = (int)SEQ_PTR(_58target_27454);
                if (!UNIQUE(_2)) {
                    _2 = (int)SequenceCopy((s1_ptr)_2);
                    _58target_27454 = MAKE_SEQ(_2);
                }
                _2 = (int)(((s1_ptr)_2)->base + 1);
                _1 = *(int *)_2;
                *(int *)_2 = -1073741824;
                DeRef(_1);

                /** 								target[MAX] = MAXINT*/
                _2 = (int)SEQ_PTR(_58target_27454);
                if (!UNIQUE(_2)) {
                    _2 = (int)SequenceCopy((s1_ptr)_2);
                    _58target_27454 = MAKE_SEQ(_2);
                }
                _2 = (int)(((s1_ptr)_2)->base + 2);
                _1 = *(int *)_2;
                *(int *)_2 = 1073741823;
                DeRef(_1);
                goto L36; // [1499] 1547
L35: 

                /** 								target[MIN] = SymTab[sp][S_ARG_MIN]*/
                _2 = (int)SEQ_PTR(_36SymTab_15242);
                _23401 = (int)*(((s1_ptr)_2)->base + _sp_43741);
                _2 = (int)SEQ_PTR(_23401);
                _23402 = (int)*(((s1_ptr)_2)->base + 47);
                _23401 = NOVALUE;
                Ref(_23402);
                _2 = (int)SEQ_PTR(_58target_27454);
                if (!UNIQUE(_2)) {
                    _2 = (int)SequenceCopy((s1_ptr)_2);
                    _58target_27454 = MAKE_SEQ(_2);
                }
                _2 = (int)(((s1_ptr)_2)->base + 1);
                _1 = *(int *)_2;
                *(int *)_2 = _23402;
                if( _1 != _23402 ){
                    DeRef(_1);
                }
                _23402 = NOVALUE;

                /** 								target[MAX] = SymTab[sp][S_ARG_MAX]*/
                _2 = (int)SEQ_PTR(_36SymTab_15242);
                _23403 = (int)*(((s1_ptr)_2)->base + _sp_43741);
                _2 = (int)SEQ_PTR(_23403);
                _23404 = (int)*(((s1_ptr)_2)->base + 48);
                _23403 = NOVALUE;
                Ref(_23404);
                _2 = (int)SEQ_PTR(_58target_27454);
                if (!UNIQUE(_2)) {
                    _2 = (int)SequenceCopy((s1_ptr)_2);
                    _58target_27454 = MAKE_SEQ(_2);
                }
                _2 = (int)(((s1_ptr)_2)->base + 2);
                _1 = *(int *)_2;
                *(int *)_2 = _23404;
                if( _1 != _23404 ){
                    DeRef(_1);
                }
                _23404 = NOVALUE;
L36: 

                /** 							SetBBType(sp, SymTab[sp][S_ARG_TYPE], target, TYPE_OBJECT, 0)*/
                _2 = (int)SEQ_PTR(_36SymTab_15242);
                _23405 = (int)*(((s1_ptr)_2)->base + _sp_43741);
                _2 = (int)SEQ_PTR(_23405);
                _23406 = (int)*(((s1_ptr)_2)->base + 43);
                _23405 = NOVALUE;
                Ref(_23406);
                RefDS(_58target_27454);
                _57SetBBType(_sp_43741, _23406, _58target_27454, 16, 0);
                _23406 = NOVALUE;
                goto L33; // [1572] 1659
L34: 

                /** 						elsif SymTab[sp][S_ARG_TYPE] = TYPE_OBJECT then*/
                _2 = (int)SEQ_PTR(_36SymTab_15242);
                _23407 = (int)*(((s1_ptr)_2)->base + _sp_43741);
                _2 = (int)SEQ_PTR(_23407);
                _23408 = (int)*(((s1_ptr)_2)->base + 43);
                _23407 = NOVALUE;
                if (binary_op_a(NOTEQ, _23408, 16)){
                    _23408 = NOVALUE;
                    goto L37; // [1591] 1633
                }
                _23408 = NOVALUE;

                /** 							SetBBType(sp, SymTab[sp][S_ARG_TYPE], novalue,*/
                _2 = (int)SEQ_PTR(_36SymTab_15242);
                _23410 = (int)*(((s1_ptr)_2)->base + _sp_43741);
                _2 = (int)SEQ_PTR(_23410);
                _23411 = (int)*(((s1_ptr)_2)->base + 43);
                _23410 = NOVALUE;
                _2 = (int)SEQ_PTR(_36SymTab_15242);
                _23412 = (int)*(((s1_ptr)_2)->base + _sp_43741);
                _2 = (int)SEQ_PTR(_23412);
                _23413 = (int)*(((s1_ptr)_2)->base + 45);
                _23412 = NOVALUE;
                Ref(_23411);
                RefDS(_54novalue_45495);
                Ref(_23413);
                _57SetBBType(_sp_43741, _23411, _54novalue_45495, _23413, 0);
                _23411 = NOVALUE;
                _23413 = NOVALUE;
                goto L33; // [1630] 1659
L37: 

                /** 							SetBBType(sp, SymTab[sp][S_ARG_TYPE], novalue, TYPE_OBJECT, 0)*/
                _2 = (int)SEQ_PTR(_36SymTab_15242);
                _23414 = (int)*(((s1_ptr)_2)->base + _sp_43741);
                _2 = (int)SEQ_PTR(_23414);
                _23415 = (int)*(((s1_ptr)_2)->base + 43);
                _23414 = NOVALUE;
                Ref(_23415);
                RefDS(_54novalue_45495);
                _57SetBBType(_sp_43741, _23415, _54novalue_45495, 16, 0);
                _23415 = NOVALUE;
L33: 

                /** 						sp = SymTab[sp][S_NEXT]*/
                _2 = (int)SEQ_PTR(_36SymTab_15242);
                _23416 = (int)*(((s1_ptr)_2)->base + _sp_43741);
                _2 = (int)SEQ_PTR(_23416);
                _sp_43741 = (int)*(((s1_ptr)_2)->base + 2);
                if (!IS_ATOM_INT(_sp_43741)){
                    _sp_43741 = (long)DBL_PTR(_sp_43741)->dbl;
                }
                _23416 = NOVALUE;

                /** 					end for*/
                _0 = _p_44047;
                if (IS_ATOM_INT(_p_44047)) {
                    _p_44047 = _p_44047 + 1;
                    if ((long)((unsigned long)_p_44047 +(unsigned long) HIGH_BITS) >= 0){
                        _p_44047 = NewDouble((double)_p_44047);
                    }
                }
                else {
                    _p_44047 = binary_op_a(PLUS, _p_44047, 1);
                }
                DeRef(_0);
                goto L30; // [1677] 1338
L31: 
                ;
                DeRef(_p_44047);
            }

            /** 					call_proc(Execute_id, {s})*/
            _1 = NewS1(1);
            _2 = (int)((s1_ptr)_1)->base;
            *((int *)(_2+4)) = _s_43740;
            _23418 = MAKE_SEQ(_1);
            _1 = (int)SEQ_PTR(_23418);
            _2 = (int)((s1_ptr)_1)->base;
            _0 = (int)_00[_35Execute_id_16331].addr;
            Ref(*(int *)(_2+4));
            (*(int (*)())_0)(
                                *(int *)(_2+4)
                                 );
            DeRefDS(_23418);
            _23418 = NOVALUE;

            /** 					c_puts("    ;\n}\n")*/
            RefDS(_23419);
            _54c_puts(_23419);

            /** 					if TUNIX and dll_option and is_exported( s ) then*/
            if (_40TUNIX_16392 == 0) {
                _23420 = 0;
                goto L38; // [1702] 1712
            }
            _23420 = (_57dll_option_41676 != 0);
L38: 
            if (_23420 == 0) {
                goto L39; // [1712] 2035
            }
            _23422 = _57is_exported(_s_43740);
            if (_23422 == 0) {
                DeRef(_23422);
                _23422 = NOVALUE;
                goto L39; // [1721] 2035
            }
            else {
                if (!IS_ATOM_INT(_23422) && DBL_PTR(_23422)->dbl == 0.0){
                    DeRef(_23422);
                    _23422 = NOVALUE;
                    goto L39; // [1721] 2035
                }
                DeRef(_23422);
                _23422 = NOVALUE;
            }
            DeRef(_23422);
            _23422 = NOVALUE;

            /** 						LeftSym = TRUE*/
            _57LeftSym_41673 = _13TRUE_436;

            /** 						if TOSX then*/
            if (_40TOSX_16396 == 0)
            {
                goto L3A; // [1737] 1997
            }
            else{
            }

            /** 							c_stmt0( ret_type & SymTab[s][S_NAME] & " (" )*/
            _2 = (int)SEQ_PTR(_36SymTab_15242);
            _23423 = (int)*(((s1_ptr)_2)->base + _s_43740);
            _2 = (int)SEQ_PTR(_23423);
            if (!IS_ATOM_INT(_35S_NAME_15917)){
                _23424 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15917)->dbl));
            }
            else{
                _23424 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15917);
            }
            _23423 = NOVALUE;
            {
                int concat_list[3];

                concat_list[0] = _23425;
                concat_list[1] = _23424;
                concat_list[2] = _ret_type_43873;
                Concat_N((object_ptr)&_23426, concat_list, 3);
            }
            _23424 = NOVALUE;
            _57c_stmt0(_23426);
            _23426 = NOVALUE;

            /** 							sp = SymTab[s][S_NEXT]*/
            _2 = (int)SEQ_PTR(_36SymTab_15242);
            _23427 = (int)*(((s1_ptr)_2)->base + _s_43740);
            _2 = (int)SEQ_PTR(_23427);
            _sp_43741 = (int)*(((s1_ptr)_2)->base + 2);
            if (!IS_ATOM_INT(_sp_43741)){
                _sp_43741 = (long)DBL_PTR(_sp_43741)->dbl;
            }
            _23427 = NOVALUE;

            /** 							for p = 1 to SymTab[s][S_NUM_ARGS] do*/
            _2 = (int)SEQ_PTR(_36SymTab_15242);
            _23429 = (int)*(((s1_ptr)_2)->base + _s_43740);
            _2 = (int)SEQ_PTR(_23429);
            if (!IS_ATOM_INT(_35S_NUM_ARGS_15968)){
                _23430 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NUM_ARGS_15968)->dbl));
            }
            else{
                _23430 = (int)*(((s1_ptr)_2)->base + _35S_NUM_ARGS_15968);
            }
            _23429 = NOVALUE;
            {
                int _p_44168;
                _p_44168 = 1;
L3B: 
                if (binary_op_a(GREATER, _p_44168, _23430)){
                    goto L3C; // [1795] 1871
                }

                /** 								c_puts("int _")*/
                RefDS(_23332);
                _54c_puts(_23332);

                /** 								c_puts(SymTab[sp][S_NAME])*/
                _2 = (int)SEQ_PTR(_36SymTab_15242);
                _23431 = (int)*(((s1_ptr)_2)->base + _sp_43741);
                _2 = (int)SEQ_PTR(_23431);
                if (!IS_ATOM_INT(_35S_NAME_15917)){
                    _23432 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15917)->dbl));
                }
                else{
                    _23432 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15917);
                }
                _23431 = NOVALUE;
                Ref(_23432);
                _54c_puts(_23432);
                _23432 = NOVALUE;

                /** 								if p != SymTab[s][S_NUM_ARGS] then*/
                _2 = (int)SEQ_PTR(_36SymTab_15242);
                _23433 = (int)*(((s1_ptr)_2)->base + _s_43740);
                _2 = (int)SEQ_PTR(_23433);
                if (!IS_ATOM_INT(_35S_NUM_ARGS_15968)){
                    _23434 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NUM_ARGS_15968)->dbl));
                }
                else{
                    _23434 = (int)*(((s1_ptr)_2)->base + _35S_NUM_ARGS_15968);
                }
                _23433 = NOVALUE;
                if (binary_op_a(EQUALS, _p_44168, _23434)){
                    _23434 = NOVALUE;
                    goto L3D; // [1838] 1848
                }
                _23434 = NOVALUE;

                /** 									c_puts(", ")*/
                RefDS(_23338);
                _54c_puts(_23338);
L3D: 

                /** 								sp = SymTab[sp][S_NEXT]*/
                _2 = (int)SEQ_PTR(_36SymTab_15242);
                _23436 = (int)*(((s1_ptr)_2)->base + _sp_43741);
                _2 = (int)SEQ_PTR(_23436);
                _sp_43741 = (int)*(((s1_ptr)_2)->base + 2);
                if (!IS_ATOM_INT(_sp_43741)){
                    _sp_43741 = (long)DBL_PTR(_sp_43741)->dbl;
                }
                _23436 = NOVALUE;

                /** 							end for*/
                _0 = _p_44168;
                if (IS_ATOM_INT(_p_44168)) {
                    _p_44168 = _p_44168 + 1;
                    if ((long)((unsigned long)_p_44168 +(unsigned long) HIGH_BITS) >= 0){
                        _p_44168 = NewDouble((double)_p_44168);
                    }
                }
                else {
                    _p_44168 = binary_op_a(PLUS, _p_44168, 1);
                }
                DeRef(_0);
                goto L3B; // [1866] 1802
L3C: 
                ;
                DeRef(_p_44168);
            }

            /** 							c_puts( ") {\n")*/
            RefDS(_23438);
            _54c_puts(_23438);

            /** 							c_stmt("    return @(", s)*/
            RefDS(_23439);
            _57c_stmt(_23439, _s_43740, 0);

            /** 							sp = SymTab[s][S_NEXT]*/
            _2 = (int)SEQ_PTR(_36SymTab_15242);
            _23440 = (int)*(((s1_ptr)_2)->base + _s_43740);
            _2 = (int)SEQ_PTR(_23440);
            _sp_43741 = (int)*(((s1_ptr)_2)->base + 2);
            if (!IS_ATOM_INT(_sp_43741)){
                _sp_43741 = (long)DBL_PTR(_sp_43741)->dbl;
            }
            _23440 = NOVALUE;

            /** 							for p = 1 to SymTab[s][S_NUM_ARGS] do*/
            _2 = (int)SEQ_PTR(_36SymTab_15242);
            _23442 = (int)*(((s1_ptr)_2)->base + _s_43740);
            _2 = (int)SEQ_PTR(_23442);
            if (!IS_ATOM_INT(_35S_NUM_ARGS_15968)){
                _23443 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NUM_ARGS_15968)->dbl));
            }
            else{
                _23443 = (int)*(((s1_ptr)_2)->base + _35S_NUM_ARGS_15968);
            }
            _23442 = NOVALUE;
            {
                int _p_44198;
                _p_44198 = 1;
L3E: 
                if (binary_op_a(GREATER, _p_44198, _23443)){
                    goto L3F; // [1913] 1989
                }

                /** 								c_puts("_")*/
                RefDS(_22095);
                _54c_puts(_22095);

                /** 								c_puts(SymTab[sp][S_NAME])*/
                _2 = (int)SEQ_PTR(_36SymTab_15242);
                _23444 = (int)*(((s1_ptr)_2)->base + _sp_43741);
                _2 = (int)SEQ_PTR(_23444);
                if (!IS_ATOM_INT(_35S_NAME_15917)){
                    _23445 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15917)->dbl));
                }
                else{
                    _23445 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15917);
                }
                _23444 = NOVALUE;
                Ref(_23445);
                _54c_puts(_23445);
                _23445 = NOVALUE;

                /** 								if p != SymTab[s][S_NUM_ARGS] then*/
                _2 = (int)SEQ_PTR(_36SymTab_15242);
                _23446 = (int)*(((s1_ptr)_2)->base + _s_43740);
                _2 = (int)SEQ_PTR(_23446);
                if (!IS_ATOM_INT(_35S_NUM_ARGS_15968)){
                    _23447 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NUM_ARGS_15968)->dbl));
                }
                else{
                    _23447 = (int)*(((s1_ptr)_2)->base + _35S_NUM_ARGS_15968);
                }
                _23446 = NOVALUE;
                if (binary_op_a(EQUALS, _p_44198, _23447)){
                    _23447 = NOVALUE;
                    goto L40; // [1956] 1966
                }
                _23447 = NOVALUE;

                /** 									c_puts(", ")*/
                RefDS(_23338);
                _54c_puts(_23338);
L40: 

                /** 								sp = SymTab[sp][S_NEXT]*/
                _2 = (int)SEQ_PTR(_36SymTab_15242);
                _23449 = (int)*(((s1_ptr)_2)->base + _sp_43741);
                _2 = (int)SEQ_PTR(_23449);
                _sp_43741 = (int)*(((s1_ptr)_2)->base + 2);
                if (!IS_ATOM_INT(_sp_43741)){
                    _sp_43741 = (long)DBL_PTR(_sp_43741)->dbl;
                }
                _23449 = NOVALUE;

                /** 							end for*/
                _0 = _p_44198;
                if (IS_ATOM_INT(_p_44198)) {
                    _p_44198 = _p_44198 + 1;
                    if ((long)((unsigned long)_p_44198 +(unsigned long) HIGH_BITS) >= 0){
                        _p_44198 = NewDouble((double)_p_44198);
                    }
                }
                else {
                    _p_44198 = binary_op_a(PLUS, _p_44198, 1);
                }
                DeRef(_0);
                goto L3E; // [1984] 1920
L3F: 
                ;
                DeRef(_p_44198);
            }

            /** 							c_puts( ");\n}\n" )	*/
            RefDS(_23451);
            _54c_puts(_23451);
            goto L41; // [1994] 2025
L3A: 

            /** 							c_stmt( ret_type & SymTab[s][S_NAME] & "() __attribute__ ((alias (\"@\")));\n", s )*/
            _2 = (int)SEQ_PTR(_36SymTab_15242);
            _23452 = (int)*(((s1_ptr)_2)->base + _s_43740);
            _2 = (int)SEQ_PTR(_23452);
            if (!IS_ATOM_INT(_35S_NAME_15917)){
                _23453 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15917)->dbl));
            }
            else{
                _23453 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15917);
            }
            _23452 = NOVALUE;
            {
                int concat_list[3];

                concat_list[0] = _23454;
                concat_list[1] = _23453;
                concat_list[2] = _ret_type_43873;
                Concat_N((object_ptr)&_23455, concat_list, 3);
            }
            _23453 = NOVALUE;
            _57c_stmt(_23455, _s_43740, 0);
            _23455 = NOVALUE;
L41: 

            /** 						LeftSym = FALSE*/
            _57LeftSym_41673 = _13FALSE_434;
L39: 

            /** 					c_puts("\n\n" )*/
            RefDS(_22137);
            _54c_puts(_22137);
L14: 
            DeRefi(_ret_type_43873);
            _ret_type_43873 = NOVALUE;
            DeRef(_names_43978);
            _names_43978 = NOVALUE;

            /** 			end for*/
            _routine_no_43818 = _routine_no_43818 + 1;
            goto L12; // [2045] 359
L13: 
            ;
        }
L8: 
        DeRef(_these_routines_43815);
        _these_routines_43815 = NOVALUE;

        /** 	end for*/
        _file_no_43764 = _file_no_43764 + 1;
        goto L5; // [2055] 85
L6: 
        ;
    }

    /** end procedure*/
    DeRefi(_buff_43745);
    DeRef(_base_name_43746);
    DeRef(_long_c_file_43747);
    DeRef(_c_file_43748);
    DeRef(_23249);
    _23249 = NOVALUE;
    DeRef(_23258);
    _23258 = NOVALUE;
    DeRef(_23272);
    _23272 = NOVALUE;
    DeRef(_23283);
    _23283 = NOVALUE;
    DeRef(_23285);
    _23285 = NOVALUE;
    DeRef(_23287);
    _23287 = NOVALUE;
    _23293 = NOVALUE;
    DeRef(_23290);
    _23290 = NOVALUE;
    DeRef(_23295);
    _23295 = NOVALUE;
    _23331 = NOVALUE;
    _23360 = NOVALUE;
    _23383 = NOVALUE;
    DeRef(_23363);
    _23363 = NOVALUE;
    _23430 = NOVALUE;
    _23443 = NOVALUE;
    return;
    ;
}



// 0x1B790E30
