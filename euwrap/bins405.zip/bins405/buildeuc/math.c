// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int _20abs(int _a_3331)
{
    int _t_3332 = NOVALUE;
    int _1627 = NOVALUE;
    int _1626 = NOVALUE;
    int _1625 = NOVALUE;
    int _1623 = NOVALUE;
    int _1621 = NOVALUE;
    int _1620 = NOVALUE;
    int _1618 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(a) then*/
    _1618 = IS_ATOM(_a_3331);
    if (_1618 == 0)
    {
        _1618 = NOVALUE;
        goto L1; // [6] 35
    }
    else{
        _1618 = NOVALUE;
    }

    /** 		if a >= 0 then*/
    if (binary_op_a(LESS, _a_3331, 0)){
        goto L2; // [11] 24
    }

    /** 			return a*/
    DeRef(_t_3332);
    return _a_3331;
    goto L3; // [21] 34
L2: 

    /** 			return - a*/
    if (IS_ATOM_INT(_a_3331)) {
        if ((unsigned long)_a_3331 == 0xC0000000)
        _1620 = (int)NewDouble((double)-0xC0000000);
        else
        _1620 = - _a_3331;
    }
    else {
        _1620 = unary_op(UMINUS, _a_3331);
    }
    DeRef(_a_3331);
    DeRef(_t_3332);
    return _1620;
L3: 
L1: 

    /** 	for i = 1 to length(a) do*/
    if (IS_SEQUENCE(_a_3331)){
            _1621 = SEQ_PTR(_a_3331)->length;
    }
    else {
        _1621 = 1;
    }
    {
        int _i_3340;
        _i_3340 = 1;
L4: 
        if (_i_3340 > _1621){
            goto L5; // [40] 101
        }

        /** 		t = a[i]*/
        DeRef(_t_3332);
        _2 = (int)SEQ_PTR(_a_3331);
        _t_3332 = (int)*(((s1_ptr)_2)->base + _i_3340);
        Ref(_t_3332);

        /** 		if atom(t) then*/
        _1623 = IS_ATOM(_t_3332);
        if (_1623 == 0)
        {
            _1623 = NOVALUE;
            goto L6; // [58] 80
        }
        else{
            _1623 = NOVALUE;
        }

        /** 			if t < 0 then*/
        if (binary_op_a(GREATEREQ, _t_3332, 0)){
            goto L7; // [63] 94
        }

        /** 				a[i] = - t*/
        if (IS_ATOM_INT(_t_3332)) {
            if ((unsigned long)_t_3332 == 0xC0000000)
            _1625 = (int)NewDouble((double)-0xC0000000);
            else
            _1625 = - _t_3332;
        }
        else {
            _1625 = unary_op(UMINUS, _t_3332);
        }
        _2 = (int)SEQ_PTR(_a_3331);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _a_3331 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_3340);
        _1 = *(int *)_2;
        *(int *)_2 = _1625;
        if( _1 != _1625 ){
            DeRef(_1);
        }
        _1625 = NOVALUE;
        goto L7; // [77] 94
L6: 

        /** 			a[i] = abs(t)*/
        Ref(_t_3332);
        DeRef(_1626);
        _1626 = _t_3332;
        _1627 = _20abs(_1626);
        _1626 = NOVALUE;
        _2 = (int)SEQ_PTR(_a_3331);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _a_3331 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_3340);
        _1 = *(int *)_2;
        *(int *)_2 = _1627;
        if( _1 != _1627 ){
            DeRef(_1);
        }
        _1627 = NOVALUE;
L7: 

        /** 	end for*/
        _i_3340 = _i_3340 + 1;
        goto L4; // [96] 47
L5: 
        ;
    }

    /** 	return a*/
    DeRef(_t_3332);
    DeRef(_1620);
    _1620 = NOVALUE;
    return _a_3331;
    ;
}


int _20max(int _a_3375)
{
    int _b_3376 = NOVALUE;
    int _c_3377 = NOVALUE;
    int _1637 = NOVALUE;
    int _1636 = NOVALUE;
    int _1635 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(a) then*/
    _1635 = IS_ATOM(_a_3375);
    if (_1635 == 0)
    {
        _1635 = NOVALUE;
        goto L1; // [6] 16
    }
    else{
        _1635 = NOVALUE;
    }

    /** 		return a*/
    DeRef(_b_3376);
    DeRef(_c_3377);
    return _a_3375;
L1: 

    /** 	b = mathcons:MINF*/
    RefDS(_22MINF_3309);
    DeRef(_b_3376);
    _b_3376 = _22MINF_3309;

    /** 	for i = 1 to length(a) do*/
    if (IS_SEQUENCE(_a_3375)){
            _1636 = SEQ_PTR(_a_3375)->length;
    }
    else {
        _1636 = 1;
    }
    {
        int _i_3381;
        _i_3381 = 1;
L2: 
        if (_i_3381 > _1636){
            goto L3; // [28] 64
        }

        /** 		c = max(a[i])*/
        _2 = (int)SEQ_PTR(_a_3375);
        _1637 = (int)*(((s1_ptr)_2)->base + _i_3381);
        Ref(_1637);
        _0 = _c_3377;
        _c_3377 = _20max(_1637);
        DeRef(_0);
        _1637 = NOVALUE;

        /** 		if c > b then*/
        if (binary_op_a(LESSEQ, _c_3377, _b_3376)){
            goto L4; // [47] 57
        }

        /** 			b = c*/
        Ref(_c_3377);
        DeRef(_b_3376);
        _b_3376 = _c_3377;
L4: 

        /** 	end for*/
        _i_3381 = _i_3381 + 1;
        goto L2; // [59] 35
L3: 
        ;
    }

    /** 	return b*/
    DeRef(_a_3375);
    DeRef(_c_3377);
    return _b_3376;
    ;
}


int _20min(int _a_3389)
{
    int _b_3390 = NOVALUE;
    int _c_3391 = NOVALUE;
    int _1642 = NOVALUE;
    int _1641 = NOVALUE;
    int _1640 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(a) then*/
    _1640 = IS_ATOM(_a_3389);
    if (_1640 == 0)
    {
        _1640 = NOVALUE;
        goto L1; // [6] 16
    }
    else{
        _1640 = NOVALUE;
    }

    /** 			return a*/
    DeRef(_b_3390);
    DeRef(_c_3391);
    return _a_3389;
L1: 

    /** 	b = mathcons:PINF*/
    RefDS(_22PINF_3305);
    DeRef(_b_3390);
    _b_3390 = _22PINF_3305;

    /** 	for i = 1 to length(a) do*/
    if (IS_SEQUENCE(_a_3389)){
            _1641 = SEQ_PTR(_a_3389)->length;
    }
    else {
        _1641 = 1;
    }
    {
        int _i_3395;
        _i_3395 = 1;
L2: 
        if (_i_3395 > _1641){
            goto L3; // [28] 64
        }

        /** 		c = min(a[i])*/
        _2 = (int)SEQ_PTR(_a_3389);
        _1642 = (int)*(((s1_ptr)_2)->base + _i_3395);
        Ref(_1642);
        _0 = _c_3391;
        _c_3391 = _20min(_1642);
        DeRef(_0);
        _1642 = NOVALUE;

        /** 			if c < b then*/
        if (binary_op_a(GREATEREQ, _c_3391, _b_3390)){
            goto L4; // [47] 57
        }

        /** 				b = c*/
        Ref(_c_3391);
        DeRef(_b_3390);
        _b_3390 = _c_3391;
L4: 

        /** 	end for*/
        _i_3395 = _i_3395 + 1;
        goto L2; // [59] 35
L3: 
        ;
    }

    /** 	return b*/
    DeRef(_a_3389);
    DeRef(_c_3391);
    return _b_3390;
    ;
}


int _20or_all(int _a_3768)
{
    int _b_3769 = NOVALUE;
    int _1841 = NOVALUE;
    int _1840 = NOVALUE;
    int _1838 = NOVALUE;
    int _1837 = NOVALUE;
    int _1836 = NOVALUE;
    int _1835 = NOVALUE;
    int _1834 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(a) then*/
    _1834 = IS_ATOM(_a_3768);
    if (_1834 == 0)
    {
        _1834 = NOVALUE;
        goto L1; // [6] 16
    }
    else{
        _1834 = NOVALUE;
    }

    /** 		return a*/
    DeRef(_b_3769);
    return _a_3768;
L1: 

    /** 	b = 0*/
    DeRef(_b_3769);
    _b_3769 = 0;

    /** 	for i = 1 to length(a) do*/
    if (IS_SEQUENCE(_a_3768)){
            _1835 = SEQ_PTR(_a_3768)->length;
    }
    else {
        _1835 = 1;
    }
    {
        int _i_3773;
        _i_3773 = 1;
L2: 
        if (_i_3773 > _1835){
            goto L3; // [26] 80
        }

        /** 		if atom(a[i]) then*/
        _2 = (int)SEQ_PTR(_a_3768);
        _1836 = (int)*(((s1_ptr)_2)->base + _i_3773);
        _1837 = IS_ATOM(_1836);
        _1836 = NOVALUE;
        if (_1837 == 0)
        {
            _1837 = NOVALUE;
            goto L4; // [42] 58
        }
        else{
            _1837 = NOVALUE;
        }

        /** 			b = or_bits(b, a[i])*/
        _2 = (int)SEQ_PTR(_a_3768);
        _1838 = (int)*(((s1_ptr)_2)->base + _i_3773);
        _0 = _b_3769;
        if (IS_ATOM_INT(_b_3769) && IS_ATOM_INT(_1838)) {
            {unsigned long tu;
                 tu = (unsigned long)_b_3769 | (unsigned long)_1838;
                 _b_3769 = MAKE_UINT(tu);
            }
        }
        else {
            _b_3769 = binary_op(OR_BITS, _b_3769, _1838);
        }
        DeRef(_0);
        _1838 = NOVALUE;
        goto L5; // [55] 73
L4: 

        /** 			b = or_bits(b, or_all(a[i]))*/
        _2 = (int)SEQ_PTR(_a_3768);
        _1840 = (int)*(((s1_ptr)_2)->base + _i_3773);
        Ref(_1840);
        _1841 = _20or_all(_1840);
        _1840 = NOVALUE;
        _0 = _b_3769;
        if (IS_ATOM_INT(_b_3769) && IS_ATOM_INT(_1841)) {
            {unsigned long tu;
                 tu = (unsigned long)_b_3769 | (unsigned long)_1841;
                 _b_3769 = MAKE_UINT(tu);
            }
        }
        else {
            _b_3769 = binary_op(OR_BITS, _b_3769, _1841);
        }
        DeRef(_0);
        DeRef(_1841);
        _1841 = NOVALUE;
L5: 

        /** 	end for*/
        _i_3773 = _i_3773 + 1;
        goto L2; // [75] 33
L3: 
        ;
    }

    /** 	return b*/
    DeRef(_a_3768);
    return _b_3769;
    ;
}



// 0x318EB351
