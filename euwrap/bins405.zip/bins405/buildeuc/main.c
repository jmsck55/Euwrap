// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int _68GetSourceName()
{
    int _real_name_63861 = NOVALUE;
    int _fh_63862 = NOVALUE;
    int _has_extension_63864 = NOVALUE;
    int _31970 = NOVALUE;
    int _31968 = NOVALUE;
    int _31967 = NOVALUE;
    int _31964 = NOVALUE;
    int _31963 = NOVALUE;
    int _31962 = NOVALUE;
    int _31961 = NOVALUE;
    int _31960 = NOVALUE;
    int _31959 = NOVALUE;
    int _31956 = NOVALUE;
    int _31955 = NOVALUE;
    int _31953 = NOVALUE;
    int _31952 = NOVALUE;
    int _31951 = NOVALUE;
    int _31950 = NOVALUE;
    int _31949 = NOVALUE;
    int _31948 = NOVALUE;
    int _31945 = NOVALUE;
    int _31944 = NOVALUE;
    int _31942 = NOVALUE;
    int _31941 = NOVALUE;
    int _31938 = NOVALUE;
    int _0, _1, _2;
    

    /** 	boolean has_extension = FALSE*/
    _has_extension_63864 = _13FALSE_434;

    /** 	if length(src_name) = 0 then*/
    if (IS_SEQUENCE(_43src_name_48855)){
            _31938 = SEQ_PTR(_43src_name_48855)->length;
    }
    else {
        _31938 = 1;
    }
    if (_31938 != 0)
    goto L1; // [15] 30

    /** 		show_banner()*/
    _43show_banner();

    /** 		return -2 -- No source file*/
    DeRef(_real_name_63861);
    return -2;
L1: 

    /** 	ifdef WINDOWS then*/

    /** 		src_name = match_replace("/", src_name, "\\")*/
    RefDS(_23466);
    RefDS(_43src_name_48855);
    RefDS(_23578);
    _0 = _16match_replace(_23466, _43src_name_48855, _23578, 0);
    DeRefDS(_43src_name_48855);
    _43src_name_48855 = _0;

    /** 	for p = length(src_name) to 1 by -1 do*/
    if (IS_SEQUENCE(_43src_name_48855)){
            _31941 = SEQ_PTR(_43src_name_48855)->length;
    }
    else {
        _31941 = 1;
    }
    {
        int _p_63876;
        _p_63876 = _31941;
L2: 
        if (_p_63876 < 1){
            goto L3; // [52] 116
        }

        /** 		if src_name[p] = '.' then*/
        _2 = (int)SEQ_PTR(_43src_name_48855);
        _31942 = (int)*(((s1_ptr)_2)->base + _p_63876);
        if (binary_op_a(NOTEQ, _31942, 46)){
            _31942 = NOVALUE;
            goto L4; // [67] 85
        }
        _31942 = NOVALUE;

        /** 		   has_extension = TRUE*/
        _has_extension_63864 = _13TRUE_436;

        /** 		   exit*/
        goto L3; // [80] 116
        goto L5; // [82] 109
L4: 

        /** 		elsif find(src_name[p], SLASH_CHARS) then*/
        _2 = (int)SEQ_PTR(_43src_name_48855);
        _31944 = (int)*(((s1_ptr)_2)->base + _p_63876);
        _31945 = find_from(_31944, _40SLASH_CHARS_16402, 1);
        _31944 = NOVALUE;
        if (_31945 == 0)
        {
            _31945 = NOVALUE;
            goto L6; // [100] 108
        }
        else{
            _31945 = NOVALUE;
        }

        /** 		   exit*/
        goto L3; // [105] 116
L6: 
L5: 

        /** 	end for*/
        _p_63876 = _p_63876 + -1;
        goto L2; // [111] 59
L3: 
        ;
    }

    /** 	if not has_extension then*/
    if (_has_extension_63864 != 0)
    goto L7; // [118] 223

    /** 		known_files = append(known_files, "")*/
    RefDS(_22023);
    Append(&_36known_files_15243, _36known_files_15243, _22023);

    /** 		for i = 1 to length( DEFAULT_EXTS ) do*/
    _31948 = 4;
    {
        int _i_63895;
        _i_63895 = 1;
L8: 
        if (_i_63895 > 4){
            goto L9; // [138] 203
        }

        /** 			known_files[$] = src_name & DEFAULT_EXTS[i]*/
        if (IS_SEQUENCE(_36known_files_15243)){
                _31949 = SEQ_PTR(_36known_files_15243)->length;
        }
        else {
            _31949 = 1;
        }
        _2 = (int)SEQ_PTR(_40DEFAULT_EXTS_16383);
        _31950 = (int)*(((s1_ptr)_2)->base + _i_63895);
        Concat((object_ptr)&_31951, _43src_name_48855, _31950);
        _31950 = NOVALUE;
        _2 = (int)SEQ_PTR(_36known_files_15243);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _36known_files_15243 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _31949);
        _1 = *(int *)_2;
        *(int *)_2 = _31951;
        if( _1 != _31951 ){
            DeRef(_1);
        }
        _31951 = NOVALUE;

        /** 			real_name = e_path_find(known_files[$])*/
        if (IS_SEQUENCE(_36known_files_15243)){
                _31952 = SEQ_PTR(_36known_files_15243)->length;
        }
        else {
            _31952 = 1;
        }
        _2 = (int)SEQ_PTR(_36known_files_15243);
        _31953 = (int)*(((s1_ptr)_2)->base + _31952);
        Ref(_31953);
        _0 = _real_name_63861;
        _real_name_63861 = _42e_path_find(_31953);
        DeRef(_0);
        _31953 = NOVALUE;

        /** 			if sequence(real_name) then*/
        _31955 = IS_SEQUENCE(_real_name_63861);
        if (_31955 == 0)
        {
            _31955 = NOVALUE;
            goto LA; // [188] 196
        }
        else{
            _31955 = NOVALUE;
        }

        /** 				exit*/
        goto L9; // [193] 203
LA: 

        /** 		end for*/
        _i_63895 = _i_63895 + 1;
        goto L8; // [198] 145
L9: 
        ;
    }

    /** 		if atom(real_name) then*/
    _31956 = IS_ATOM(_real_name_63861);
    if (_31956 == 0)
    {
        _31956 = NOVALUE;
        goto LB; // [210] 259
    }
    else{
        _31956 = NOVALUE;
    }

    /** 			return -1*/
    DeRef(_real_name_63861);
    return -1;
    goto LB; // [220] 259
L7: 

    /** 		known_files = append(known_files, src_name)*/
    RefDS(_43src_name_48855);
    Append(&_36known_files_15243, _36known_files_15243, _43src_name_48855);

    /** 		real_name = e_path_find(src_name)*/
    RefDS(_43src_name_48855);
    _0 = _real_name_63861;
    _real_name_63861 = _42e_path_find(_43src_name_48855);
    DeRef(_0);

    /** 		if atom(real_name) then*/
    _31959 = IS_ATOM(_real_name_63861);
    if (_31959 == 0)
    {
        _31959 = NOVALUE;
        goto LC; // [248] 258
    }
    else{
        _31959 = NOVALUE;
    }

    /** 			return -1*/
    DeRef(_real_name_63861);
    return -1;
LC: 
LB: 

    /** 	known_files[$] = canonical_path(real_name,,CORRECT)*/
    if (IS_SEQUENCE(_36known_files_15243)){
            _31960 = SEQ_PTR(_36known_files_15243)->length;
    }
    else {
        _31960 = 1;
    }
    Ref(_real_name_63861);
    _31961 = _17canonical_path(_real_name_63861, 0, 2);
    _2 = (int)SEQ_PTR(_36known_files_15243);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36known_files_15243 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _31960);
    _1 = *(int *)_2;
    *(int *)_2 = _31961;
    if( _1 != _31961 ){
        DeRef(_1);
    }
    _31961 = NOVALUE;

    /** 	known_files_hash &= hash(known_files[$], stdhash:HSIEH32)*/
    if (IS_SEQUENCE(_36known_files_15243)){
            _31962 = SEQ_PTR(_36known_files_15243)->length;
    }
    else {
        _31962 = 1;
    }
    _2 = (int)SEQ_PTR(_36known_files_15243);
    _31963 = (int)*(((s1_ptr)_2)->base + _31962);
    _31964 = calc_hash(_31963, -5);
    _31963 = NOVALUE;
    Ref(_31964);
    Append(&_36known_files_hash_15244, _36known_files_hash_15244, _31964);
    DeRef(_31964);
    _31964 = NOVALUE;

    /** 	finished_files &= 0*/
    Append(&_36finished_files_15245, _36finished_files_15245, 0);

    /** 	file_include_depend = append( file_include_depend, { length( known_files ) } )*/
    if (IS_SEQUENCE(_36known_files_15243)){
            _31967 = SEQ_PTR(_36known_files_15243)->length;
    }
    else {
        _31967 = 1;
    }
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _31967;
    _31968 = MAKE_SEQ(_1);
    _31967 = NOVALUE;
    RefDS(_31968);
    Append(&_36file_include_depend_15246, _36file_include_depend_15246, _31968);
    DeRefDS(_31968);
    _31968 = NOVALUE;

    /** 	if file_exists(real_name) then*/
    Ref(_real_name_63861);
    _31970 = _17file_exists(_real_name_63861);
    if (_31970 == 0) {
        DeRef(_31970);
        _31970 = NOVALUE;
        goto LD; // [338] 362
    }
    else {
        if (!IS_ATOM_INT(_31970) && DBL_PTR(_31970)->dbl == 0.0){
            DeRef(_31970);
            _31970 = NOVALUE;
            goto LD; // [338] 362
        }
        DeRef(_31970);
        _31970 = NOVALUE;
    }
    DeRef(_31970);
    _31970 = NOVALUE;

    /** 		real_name = maybe_preprocess(real_name)*/
    Ref(_real_name_63861);
    _0 = _real_name_63861;
    _real_name_63861 = _64maybe_preprocess(_real_name_63861);
    DeRef(_0);

    /** 		fh = open_locked(real_name)*/
    Ref(_real_name_63861);
    _fh_63862 = _36open_locked(_real_name_63861);
    if (!IS_ATOM_INT(_fh_63862)) {
        _1 = (long)(DBL_PTR(_fh_63862)->dbl);
        DeRefDS(_fh_63862);
        _fh_63862 = _1;
    }

    /** 		return fh*/
    DeRef(_real_name_63861);
    return _fh_63862;
LD: 

    /** 	return -1*/
    DeRef(_real_name_63861);
    return -1;
    ;
}


void _68main()
{
    int _argc_63964 = NOVALUE;
    int _argv_63965 = NOVALUE;
    int _32010 = NOVALUE;
    int _32009 = NOVALUE;
    int _32008 = NOVALUE;
    int _32007 = NOVALUE;
    int _32006 = NOVALUE;
    int _32005 = NOVALUE;
    int _32004 = NOVALUE;
    int _32003 = NOVALUE;
    int _32002 = NOVALUE;
    int _32001 = NOVALUE;
    int _32000 = NOVALUE;
    int _31997 = NOVALUE;
    int _31995 = NOVALUE;
    int _31993 = NOVALUE;
    int _31992 = NOVALUE;
    int _31991 = NOVALUE;
    int _31990 = NOVALUE;
    int _31989 = NOVALUE;
    int _31988 = NOVALUE;
    int _31987 = NOVALUE;
    int _31986 = NOVALUE;
    int _31982 = NOVALUE;
    int _0, _1, _2;
    

    /** 	argv = command_line()*/
    DeRef(_argv_63965);
    _argv_63965 = Command_Line();

    /** 	if BIND then*/
    if (_35BIND_15890 == 0)
    {
        goto L1; // [9] 21
    }
    else{
    }

    /** 		argv = extract_options(argv)*/
    RefDS(_argv_63965);
    _0 = _argv_63965;
    _argv_63965 = _2extract_options(_argv_63965);
    DeRefDS(_0);
L1: 

    /** 	argc = length(argv)*/
    if (IS_SEQUENCE(_argv_63965)){
            _argc_63964 = SEQ_PTR(_argv_63965)->length;
    }
    else {
        _argc_63964 = 1;
    }

    /** 	Argv = argv*/
    RefDS(_argv_63965);
    DeRef(_35Argv_16255);
    _35Argv_16255 = _argv_63965;

    /** 	Argc = argc*/
    _35Argc_16254 = _argc_63964;

    /** 	TempErrName = "ex.err"*/
    RefDS(_31981);
    DeRefi(_44TempErrName_48516);
    _44TempErrName_48516 = _31981;

    /** 	TempWarningName = STDERR*/
    DeRef(_35TempWarningName_16258);
    _35TempWarningName_16258 = 2;

    /** 	display_warnings = 1*/
    _44display_warnings_48517 = 1;

    /** 	InitGlobals()*/
    _39InitGlobals();

    /** 	if TRANSLATE or BIND or INTERPRET then*/
    if (_35TRANSLATE_15887 != 0) {
        _31982 = 1;
        goto L2; // [69] 79
    }
    _31982 = (_35BIND_15890 != 0);
L2: 
    if (_31982 != 0) {
        goto L3; // [79] 90
    }
    if (_35INTERPRET_15884 == 0)
    {
        goto L4; // [86] 96
    }
    else{
    }
L3: 

    /** 		InitBackEnd(0)*/
    _2InitBackEnd(0);
L4: 

    /** 	src_file = GetSourceName()*/
    _0 = _68GetSourceName();
    _35src_file_16365 = _0;
    if (!IS_ATOM_INT(_35src_file_16365)) {
        _1 = (long)(DBL_PTR(_35src_file_16365)->dbl);
        DeRefDS(_35src_file_16365);
        _35src_file_16365 = _1;
    }

    /** 	if src_file = -1 then*/
    if (_35src_file_16365 != -1)
    goto L5; // [107] 181

    /** 		screen_output(STDERR, GetMsgText(51, 0, {known_files[$]}))*/
    if (IS_SEQUENCE(_36known_files_15243)){
            _31986 = SEQ_PTR(_36known_files_15243)->length;
    }
    else {
        _31986 = 1;
    }
    _2 = (int)SEQ_PTR(_36known_files_15243);
    _31987 = (int)*(((s1_ptr)_2)->base + _31986);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_31987);
    *((int *)(_2+4)) = _31987;
    _31988 = MAKE_SEQ(_1);
    _31987 = NOVALUE;
    _31989 = _45GetMsgText(51, 0, _31988);
    _31988 = NOVALUE;
    _44screen_output(2, _31989);
    _31989 = NOVALUE;

    /** 		if not batch_job and not test_only then*/
    _31990 = (_35batch_job_16257 == 0);
    if (_31990 == 0) {
        goto L6; // [145] 173
    }
    _31992 = (_35test_only_16256 == 0);
    if (_31992 == 0)
    {
        DeRef(_31992);
        _31992 = NOVALUE;
        goto L6; // [155] 173
    }
    else{
        DeRef(_31992);
        _31992 = NOVALUE;
    }

    /** 			maybe_any_key(GetMsgText(277,0), STDERR)*/
    RefDS(_22023);
    _31993 = _45GetMsgText(277, 0, _22023);
    _5maybe_any_key(_31993, 2);
    _31993 = NOVALUE;
L6: 

    /** 		Cleanup(1)*/
    _44Cleanup(1);
    goto L7; // [178] 226
L5: 

    /** 	elsif src_file >= 0 then*/
    if (_35src_file_16365 < 0)
    goto L8; // [185] 225

    /** 		main_path = known_files[$]*/
    if (IS_SEQUENCE(_36known_files_15243)){
            _31995 = SEQ_PTR(_36known_files_15243)->length;
    }
    else {
        _31995 = 1;
    }
    DeRef(_35main_path_16364);
    _2 = (int)SEQ_PTR(_36known_files_15243);
    _35main_path_16364 = (int)*(((s1_ptr)_2)->base + _31995);
    Ref(_35main_path_16364);

    /** 		if length(main_path) = 0 then*/
    if (IS_SEQUENCE(_35main_path_16364)){
            _31997 = SEQ_PTR(_35main_path_16364)->length;
    }
    else {
        _31997 = 1;
    }
    if (_31997 != 0)
    goto L9; // [209] 224

    /** 			main_path = '.' & SLASH*/
    Concat((object_ptr)&_35main_path_16364, 46, 92);
L9: 
L8: 
L7: 

    /** 	if TRANSLATE then*/
    if (_35TRANSLATE_15887 == 0)
    {
        goto LA; // [230] 239
    }
    else{
    }

    /** 		InitBackEnd(1)*/
    _2InitBackEnd(1);
LA: 

    /** 	CheckPlatform()*/
    _2CheckPlatform();

    /** 	InitSymTab()*/
    _53InitSymTab();

    /** 	InitEmit()*/
    _41InitEmit();

    /** 	InitLex()*/
    _61InitLex();

    /** 	InitParser()*/
    _39InitParser();

    /** 	eu_namespace()*/
    _61eu_namespace();

    /** 	ifdef TRANSLATOR then*/

    /** 		if keep and build_system_type = BUILD_DIRECT then*/
    if (_57keep_41683 == 0) {
        goto LB; // [269] 338
    }
    _32001 = (_55build_system_type_44318 == 3);
    if (_32001 == 0)
    {
        DeRef(_32001);
        _32001 = NOVALUE;
        goto LB; // [282] 338
    }
    else{
        DeRef(_32001);
        _32001 = NOVALUE;
    }

    /** 			if 0 and not quick_has_changed(known_files[$]) then*/
    if (0 == 0) {
        goto LC; // [287] 337
    }
    if (IS_SEQUENCE(_36known_files_15243)){
            _32003 = SEQ_PTR(_36known_files_15243)->length;
    }
    else {
        _32003 = 1;
    }
    _2 = (int)SEQ_PTR(_36known_files_15243);
    _32004 = (int)*(((s1_ptr)_2)->base + _32003);
    Ref(_32004);
    _32005 = _55quick_has_changed(_32004);
    _32004 = NOVALUE;
    if (IS_ATOM_INT(_32005)) {
        _32006 = (_32005 == 0);
    }
    else {
        _32006 = unary_op(NOT, _32005);
    }
    DeRef(_32005);
    _32005 = NOVALUE;
    if (_32006 == 0) {
        DeRef(_32006);
        _32006 = NOVALUE;
        goto LC; // [308] 337
    }
    else {
        if (!IS_ATOM_INT(_32006) && DBL_PTR(_32006)->dbl == 0.0){
            DeRef(_32006);
            _32006 = NOVALUE;
            goto LC; // [308] 337
        }
        DeRef(_32006);
        _32006 = NOVALUE;
    }
    DeRef(_32006);
    _32006 = NOVALUE;

    /** 				build_direct(1, known_files[$])*/
    if (IS_SEQUENCE(_36known_files_15243)){
            _32007 = SEQ_PTR(_36known_files_15243)->length;
    }
    else {
        _32007 = 1;
    }
    _2 = (int)SEQ_PTR(_36known_files_15243);
    _32008 = (int)*(((s1_ptr)_2)->base + _32007);
    Ref(_32008);
    _55build_direct(1, _32008);
    _32008 = NOVALUE;

    /** 				Cleanup(0)*/
    _44Cleanup(0);

    /** 				return*/
    DeRef(_argv_63965);
    DeRef(_31990);
    _31990 = NOVALUE;
    return;
LC: 
LB: 

    /** 	main_file()*/
    _61main_file();

    /** 	check_coverage()*/
    _50check_coverage();

    /** 	parser()*/
    _39parser();

    /** 	init_coverage()*/
    _50init_coverage();

    /** 	if TRANSLATE then*/
    if (_35TRANSLATE_15887 == 0)
    {
        goto LD; // [358] 369
    }
    else{
    }

    /** 		BackEnd(0) -- translate IL to C*/
    _2BackEnd(0);
    goto LE; // [366] 409
LD: 

    /** 	elsif BIND then*/
    if (_35BIND_15890 == 0)
    {
        goto LF; // [373] 383
    }
    else{
    }

    /** 		OutputIL()*/
    _2OutputIL();
    goto LE; // [380] 409
LF: 

    /** 	elsif INTERPRET and not test_only then*/
    if (_35INTERPRET_15884 == 0) {
        goto L10; // [387] 408
    }
    _32010 = (_35test_only_16256 == 0);
    if (_32010 == 0)
    {
        DeRef(_32010);
        _32010 = NOVALUE;
        goto L10; // [397] 408
    }
    else{
        DeRef(_32010);
        _32010 = NOVALUE;
    }

    /** 		ifdef not STDDEBUG then*/

    /** 			BackEnd(0) -- execute IL using Euphoria-coded back-end*/
    _2BackEnd(0);
L10: 
LE: 

    /** 	Cleanup(0) -- does warnings*/
    _44Cleanup(0);

    /** end procedure*/
    DeRef(_argv_63965);
    DeRef(_31990);
    _31990 = NOVALUE;
    return;
    ;
}



// 0xA077E359
