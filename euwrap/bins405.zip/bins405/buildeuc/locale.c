// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int _46get_text(int _MsgNum_20111, int _LocalQuals_20112, int _DBBase_20113)
{
    int _db_res_20115 = NOVALUE;
    int _lMsgText_20116 = NOVALUE;
    int _dbname_20117 = NOVALUE;
    int _11250 = NOVALUE;
    int _11248 = NOVALUE;
    int _11246 = NOVALUE;
    int _11245 = NOVALUE;
    int _11244 = NOVALUE;
    int _11242 = NOVALUE;
    int _11241 = NOVALUE;
    int _11240 = NOVALUE;
    int _11234 = NOVALUE;
    int _11233 = NOVALUE;
    int _11232 = NOVALUE;
    int _11225 = NOVALUE;
    int _11222 = NOVALUE;
    int _11220 = NOVALUE;
    int _11218 = NOVALUE;
    int _11217 = NOVALUE;
    int _11216 = NOVALUE;
    int _11215 = NOVALUE;
    int _0, _1, _2;
    

    /** 	db_res = -1*/
    _db_res_20115 = -1;

    /** 	lMsgText = 0*/
    DeRef(_lMsgText_20116);
    _lMsgText_20116 = 0;

    /** 	if string(LocalQuals) and length(LocalQuals) > 0 then*/
    RefDS(_LocalQuals_20112);
    _11215 = _13string(_LocalQuals_20112);
    if (IS_ATOM_INT(_11215)) {
        if (_11215 == 0) {
            goto L1; // [23] 45
        }
    }
    else {
        if (DBL_PTR(_11215)->dbl == 0.0) {
            goto L1; // [23] 45
        }
    }
    if (IS_SEQUENCE(_LocalQuals_20112)){
            _11217 = SEQ_PTR(_LocalQuals_20112)->length;
    }
    else {
        _11217 = 1;
    }
    _11218 = (_11217 > 0);
    _11217 = NOVALUE;
    if (_11218 == 0)
    {
        DeRef(_11218);
        _11218 = NOVALUE;
        goto L1; // [35] 45
    }
    else{
        DeRef(_11218);
        _11218 = NOVALUE;
    }

    /** 		LocalQuals = {LocalQuals}*/
    _0 = _LocalQuals_20112;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_LocalQuals_20112);
    *((int *)(_2+4)) = _LocalQuals_20112;
    _LocalQuals_20112 = MAKE_SEQ(_1);
    DeRefDS(_0);
L1: 

    /** 	for i = 1 to length(LocalQuals) do*/
    if (IS_SEQUENCE(_LocalQuals_20112)){
            _11220 = SEQ_PTR(_LocalQuals_20112)->length;
    }
    else {
        _11220 = 1;
    }
    {
        int _i_20126;
        _i_20126 = 1;
L2: 
        if (_i_20126 > _11220){
            goto L3; // [50] 136
        }

        /** 		dbname = DBBase & "_" & LocalQuals[i] & ".edb"*/
        _2 = (int)SEQ_PTR(_LocalQuals_20112);
        _11222 = (int)*(((s1_ptr)_2)->base + _i_20126);
        {
            int concat_list[4];

            concat_list[0] = _11223;
            concat_list[1] = _11222;
            concat_list[2] = _11221;
            concat_list[3] = _DBBase_20113;
            Concat_N((object_ptr)&_dbname_20117, concat_list, 4);
        }
        _11222 = NOVALUE;

        /** 		db_res = eds:db_select( filesys:locate_file( dbname ), eds:DB_LOCK_READ_ONLY)*/
        RefDS(_dbname_20117);
        RefDS(_5);
        RefDS(_5);
        _11225 = _17locate_file(_dbname_20117, _5, _5);
        _db_res_20115 = _49db_select(_11225, 3);
        _11225 = NOVALUE;
        if (!IS_ATOM_INT(_db_res_20115)) {
            _1 = (long)(DBL_PTR(_db_res_20115)->dbl);
            DeRefDS(_db_res_20115);
            _db_res_20115 = _1;
        }

        /** 		if db_res = eds:DB_OK then*/
        if (_db_res_20115 != 0)
        goto L4; // [87] 129

        /** 			db_res = eds:db_select_table("1")*/
        RefDS(_11228);
        _db_res_20115 = _49db_select_table(_11228);
        if (!IS_ATOM_INT(_db_res_20115)) {
            _1 = (long)(DBL_PTR(_db_res_20115)->dbl);
            DeRefDS(_db_res_20115);
            _db_res_20115 = _1;
        }

        /** 			if db_res = eds:DB_OK then*/
        if (_db_res_20115 != 0)
        goto L5; // [101] 128

        /** 				lMsgText = eds:db_fetch_record(MsgNum)*/
        RefDS(_49current_table_name_17374);
        _0 = _lMsgText_20116;
        _lMsgText_20116 = _49db_fetch_record(_MsgNum_20111, _49current_table_name_17374);
        DeRef(_0);

        /** 				if sequence(lMsgText) then*/
        _11232 = IS_SEQUENCE(_lMsgText_20116);
        if (_11232 == 0)
        {
            _11232 = NOVALUE;
            goto L6; // [119] 127
        }
        else{
            _11232 = NOVALUE;
        }

        /** 					exit*/
        goto L3; // [124] 136
L6: 
L5: 
L4: 

        /** 	end for*/
        _i_20126 = _i_20126 + 1;
        goto L2; // [131] 57
L3: 
        ;
    }

    /** 	if atom(lMsgText) then*/
    _11233 = IS_ATOM(_lMsgText_20116);
    if (_11233 == 0)
    {
        _11233 = NOVALUE;
        goto L7; // [141] 281
    }
    else{
        _11233 = NOVALUE;
    }

    /** 		dbname = filesys:locate_file( DBBase & ".edb" )*/
    Concat((object_ptr)&_11234, _DBBase_20113, _11223);
    RefDS(_5);
    RefDS(_5);
    _0 = _dbname_20117;
    _dbname_20117 = _17locate_file(_11234, _5, _5);
    DeRef(_0);
    _11234 = NOVALUE;

    /** 		db_res = eds:db_select(	dbname, DB_LOCK_READ_ONLY)*/
    RefDS(_dbname_20117);
    _db_res_20115 = _49db_select(_dbname_20117, 3);
    if (!IS_ATOM_INT(_db_res_20115)) {
        _1 = (long)(DBL_PTR(_db_res_20115)->dbl);
        DeRefDS(_db_res_20115);
        _db_res_20115 = _1;
    }

    /** 		if db_res = eds:DB_OK then*/
    if (_db_res_20115 != 0)
    goto L8; // [171] 280

    /** 			db_res = eds:db_select_table("1")*/
    RefDS(_11228);
    _db_res_20115 = _49db_select_table(_11228);
    if (!IS_ATOM_INT(_db_res_20115)) {
        _1 = (long)(DBL_PTR(_db_res_20115)->dbl);
        DeRefDS(_db_res_20115);
        _db_res_20115 = _1;
    }

    /** 			if db_res = eds:DB_OK then*/
    if (_db_res_20115 != 0)
    goto L9; // [185] 279

    /** 				for i = 1 to length(LocalQuals) do*/
    if (IS_SEQUENCE(_LocalQuals_20112)){
            _11240 = SEQ_PTR(_LocalQuals_20112)->length;
    }
    else {
        _11240 = 1;
    }
    {
        int _i_20155;
        _i_20155 = 1;
LA: 
        if (_i_20155 > _11240){
            goto LB; // [194] 238
        }

        /** 					lMsgText = eds:db_fetch_record({LocalQuals[i],MsgNum})*/
        _2 = (int)SEQ_PTR(_LocalQuals_20112);
        _11241 = (int)*(((s1_ptr)_2)->base + _i_20155);
        Ref(_11241);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _11241;
        ((int *)_2)[2] = _MsgNum_20111;
        _11242 = MAKE_SEQ(_1);
        _11241 = NOVALUE;
        RefDS(_49current_table_name_17374);
        _0 = _lMsgText_20116;
        _lMsgText_20116 = _49db_fetch_record(_11242, _49current_table_name_17374);
        DeRef(_0);
        _11242 = NOVALUE;

        /** 					if sequence(lMsgText) then*/
        _11244 = IS_SEQUENCE(_lMsgText_20116);
        if (_11244 == 0)
        {
            _11244 = NOVALUE;
            goto LC; // [223] 231
        }
        else{
            _11244 = NOVALUE;
        }

        /** 						exit*/
        goto LB; // [228] 238
LC: 

        /** 				end for*/
        _i_20155 = _i_20155 + 1;
        goto LA; // [233] 201
LB: 
        ;
    }

    /** 				if atom(lMsgText) then*/
    _11245 = IS_ATOM(_lMsgText_20116);
    if (_11245 == 0)
    {
        _11245 = NOVALUE;
        goto LD; // [243] 260
    }
    else{
        _11245 = NOVALUE;
    }

    /** 					lMsgText = eds:db_fetch_record({"",MsgNum})*/
    RefDS(_5);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _5;
    ((int *)_2)[2] = _MsgNum_20111;
    _11246 = MAKE_SEQ(_1);
    RefDS(_49current_table_name_17374);
    _0 = _lMsgText_20116;
    _lMsgText_20116 = _49db_fetch_record(_11246, _49current_table_name_17374);
    DeRef(_0);
    _11246 = NOVALUE;
LD: 

    /** 				if atom(lMsgText) then*/
    _11248 = IS_ATOM(_lMsgText_20116);
    if (_11248 == 0)
    {
        _11248 = NOVALUE;
        goto LE; // [265] 278
    }
    else{
        _11248 = NOVALUE;
    }

    /** 					lMsgText = eds:db_fetch_record(MsgNum)*/
    RefDS(_49current_table_name_17374);
    _0 = _lMsgText_20116;
    _lMsgText_20116 = _49db_fetch_record(_MsgNum_20111, _49current_table_name_17374);
    DeRef(_0);
LE: 
L9: 
L8: 
L7: 

    /** 	if atom(lMsgText) then*/
    _11250 = IS_ATOM(_lMsgText_20116);
    if (_11250 == 0)
    {
        _11250 = NOVALUE;
        goto LF; // [286] 298
    }
    else{
        _11250 = NOVALUE;
    }

    /** 		return 0*/
    DeRefDS(_LocalQuals_20112);
    DeRefDS(_DBBase_20113);
    DeRef(_lMsgText_20116);
    DeRef(_dbname_20117);
    DeRef(_11215);
    _11215 = NOVALUE;
    return 0;
    goto L10; // [295] 305
LF: 

    /** 		return lMsgText*/
    DeRefDS(_LocalQuals_20112);
    DeRefDS(_DBBase_20113);
    DeRef(_dbname_20117);
    DeRef(_11215);
    _11215 = NOVALUE;
    return _lMsgText_20116;
L10: 
    ;
}



// 0xA95F59DE
