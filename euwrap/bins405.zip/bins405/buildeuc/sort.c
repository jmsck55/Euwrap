// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int _24sort(int _x_3956, int _order_3957)
{
    int _gap_3958 = NOVALUE;
    int _j_3959 = NOVALUE;
    int _first_3960 = NOVALUE;
    int _last_3961 = NOVALUE;
    int _tempi_3962 = NOVALUE;
    int _tempj_3963 = NOVALUE;
    int _1949 = NOVALUE;
    int _1945 = NOVALUE;
    int _1942 = NOVALUE;
    int _1938 = NOVALUE;
    int _1935 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if order >= 0 then*/

    /** 		order = -1*/
    _order_3957 = -1;
    goto L1; // [16] 25

    /** 		order = 1*/
    _order_3957 = 1;
L1: 

    /** 	last = length(x)*/
    if (IS_SEQUENCE(_x_3956)){
            _last_3961 = SEQ_PTR(_x_3956)->length;
    }
    else {
        _last_3961 = 1;
    }

    /** 	gap = floor(last / 10) + 1*/
    if (10 > 0 && _last_3961 >= 0) {
        _1935 = _last_3961 / 10;
    }
    else {
        temp_dbl = floor((double)_last_3961 / (double)10);
        _1935 = (long)temp_dbl;
    }
    _gap_3958 = _1935 + 1;
    _1935 = NOVALUE;

    /** 	while 1 do*/
L2: 

    /** 		first = gap + 1*/
    _first_3960 = _gap_3958 + 1;

    /** 		for i = first to last do*/
    _1938 = _last_3961;
    {
        int _i_3973;
        _i_3973 = _first_3960;
L3: 
        if (_i_3973 > _1938){
            goto L4; // [56] 152
        }

        /** 			tempi = x[i]*/
        DeRef(_tempi_3962);
        _2 = (int)SEQ_PTR(_x_3956);
        _tempi_3962 = (int)*(((s1_ptr)_2)->base + _i_3973);
        Ref(_tempi_3962);

        /** 			j = i - gap*/
        _j_3959 = _i_3973 - _gap_3958;

        /** 			while 1 do*/
L5: 

        /** 				tempj = x[j]*/
        DeRef(_tempj_3963);
        _2 = (int)SEQ_PTR(_x_3956);
        _tempj_3963 = (int)*(((s1_ptr)_2)->base + _j_3959);
        Ref(_tempj_3963);

        /** 				if eu:compare(tempi, tempj) != order then*/
        if (IS_ATOM_INT(_tempi_3962) && IS_ATOM_INT(_tempj_3963)){
            _1942 = (_tempi_3962 < _tempj_3963) ? -1 : (_tempi_3962 > _tempj_3963);
        }
        else{
            _1942 = compare(_tempi_3962, _tempj_3963);
        }
        if (_1942 == _order_3957)
        goto L6; // [92] 107

        /** 					j += gap*/
        _j_3959 = _j_3959 + _gap_3958;

        /** 					exit*/
        goto L7; // [104] 139
L6: 

        /** 				x[j+gap] = tempj*/
        _1945 = _j_3959 + _gap_3958;
        Ref(_tempj_3963);
        _2 = (int)SEQ_PTR(_x_3956);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _x_3956 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _1945);
        _1 = *(int *)_2;
        *(int *)_2 = _tempj_3963;
        DeRef(_1);

        /** 				if j <= gap then*/
        if (_j_3959 > _gap_3958)
        goto L8; // [119] 128

        /** 					exit*/
        goto L7; // [125] 139
L8: 

        /** 				j -= gap*/
        _j_3959 = _j_3959 - _gap_3958;

        /** 			end while*/
        goto L5; // [136] 80
L7: 

        /** 			x[j] = tempi*/
        Ref(_tempi_3962);
        _2 = (int)SEQ_PTR(_x_3956);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _x_3956 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _j_3959);
        _1 = *(int *)_2;
        *(int *)_2 = _tempi_3962;
        DeRef(_1);

        /** 		end for*/
        _i_3973 = _i_3973 + 1;
        goto L3; // [147] 63
L4: 
        ;
    }

    /** 		if gap = 1 then*/
    if (_gap_3958 != 1)
    goto L9; // [154] 167

    /** 			return x*/
    DeRef(_tempi_3962);
    DeRef(_tempj_3963);
    DeRef(_1945);
    _1945 = NOVALUE;
    return _x_3956;
    goto L2; // [164] 45
L9: 

    /** 			gap = floor(gap / 7) + 1*/
    if (7 > 0 && _gap_3958 >= 0) {
        _1949 = _gap_3958 / 7;
    }
    else {
        temp_dbl = floor((double)_gap_3958 / (double)7);
        _1949 = (long)temp_dbl;
    }
    _gap_3958 = _1949 + 1;
    _1949 = NOVALUE;

    /** 	end while*/
    goto L2; // [180] 45
    ;
}


int _24custom_sort(int _custom_compare_3994, int _x_3995, int _data_3996, int _order_3997)
{
    int _gap_3998 = NOVALUE;
    int _j_3999 = NOVALUE;
    int _first_4000 = NOVALUE;
    int _last_4001 = NOVALUE;
    int _tempi_4002 = NOVALUE;
    int _tempj_4003 = NOVALUE;
    int _result_4004 = NOVALUE;
    int _args_4005 = NOVALUE;
    int _1977 = NOVALUE;
    int _1973 = NOVALUE;
    int _1970 = NOVALUE;
    int _1968 = NOVALUE;
    int _1967 = NOVALUE;
    int _1962 = NOVALUE;
    int _1959 = NOVALUE;
    int _1955 = NOVALUE;
    int _1953 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence args = {0, 0}*/
    DeRef(_args_4005);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = 0;
    _args_4005 = MAKE_SEQ(_1);

    /** 	if order >= 0 then*/

    /** 		order = -1*/
    _order_3997 = -1;
    goto L1; // [24] 33

    /** 		order = 1*/
    _order_3997 = 1;
L1: 

    /** 	if atom(data) then*/
    _1953 = IS_ATOM(_data_3996);
    if (_1953 == 0)
    {
        _1953 = NOVALUE;
        goto L2; // [38] 50
    }
    else{
        _1953 = NOVALUE;
    }

    /** 		args &= data*/
    if (IS_SEQUENCE(_args_4005) && IS_ATOM(_data_3996)) {
        Ref(_data_3996);
        Append(&_args_4005, _args_4005, _data_3996);
    }
    else if (IS_ATOM(_args_4005) && IS_SEQUENCE(_data_3996)) {
    }
    else {
        Concat((object_ptr)&_args_4005, _args_4005, _data_3996);
    }
    goto L3; // [47] 70
L2: 

    /** 	elsif length(data) then*/
    _1955 = 0;
L3: 

    /** 	last = length(x)*/
    if (IS_SEQUENCE(_x_3995)){
            _last_4001 = SEQ_PTR(_x_3995)->length;
    }
    else {
        _last_4001 = 1;
    }

    /** 	gap = floor(last / 10) + 1*/
    if (10 > 0 && _last_4001 >= 0) {
        _1959 = _last_4001 / 10;
    }
    else {
        temp_dbl = floor((double)_last_4001 / (double)10);
        _1959 = (long)temp_dbl;
    }
    _gap_3998 = _1959 + 1;
    _1959 = NOVALUE;

    /** 	while 1 do*/
L4: 

    /** 		first = gap + 1*/
    _first_4000 = _gap_3998 + 1;

    /** 		for i = first to last do*/
    _1962 = _last_4001;
    {
        int _i_4023;
        _i_4023 = _first_4000;
L5: 
        if (_i_4023 > _1962){
            goto L6; // [101] 240
        }

        /** 			tempi = x[i]*/
        DeRef(_tempi_4002);
        _2 = (int)SEQ_PTR(_x_3995);
        _tempi_4002 = (int)*(((s1_ptr)_2)->base + _i_4023);
        Ref(_tempi_4002);

        /** 			args[1] = tempi*/
        Ref(_tempi_4002);
        _2 = (int)SEQ_PTR(_args_4005);
        _2 = (int)(((s1_ptr)_2)->base + 1);
        _1 = *(int *)_2;
        *(int *)_2 = _tempi_4002;
        DeRef(_1);

        /** 			j = i - gap*/
        _j_3999 = _i_4023 - _gap_3998;

        /** 			while 1 do*/
L7: 

        /** 				tempj = x[j]*/
        DeRef(_tempj_4003);
        _2 = (int)SEQ_PTR(_x_3995);
        _tempj_4003 = (int)*(((s1_ptr)_2)->base + _j_3999);
        Ref(_tempj_4003);

        /** 				args[2] = tempj*/
        Ref(_tempj_4003);
        _2 = (int)SEQ_PTR(_args_4005);
        _2 = (int)(((s1_ptr)_2)->base + 2);
        _1 = *(int *)_2;
        *(int *)_2 = _tempj_4003;
        DeRef(_1);

        /** 				result = call_func(custom_compare, args)*/
        _1 = (int)SEQ_PTR(_args_4005);
        _2 = (int)((s1_ptr)_1)->base;
        _0 = (int)_00[_custom_compare_3994].addr;
        switch(((s1_ptr)_1)->length) {
            case 0:
                _1 = (*(int (*)())_0)(
                                     );
                break;
            case 1:
                Ref(*(int *)(_2+4));
                _1 = (*(int (*)())_0)(
                                    *(int *)(_2+4)
                                     );
                break;
            case 2:
                Ref(*(int *)(_2+4));
                Ref(*(int *)(_2+8));
                _1 = (*(int (*)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8)
                                     );
                break;
            case 3:
                Ref(*(int *)(_2+4));
                Ref(*(int *)(_2+8));
                Ref(*(int *)(_2+12));
                _1 = (*(int (*)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8), 
                                    *(int *)(_2+12)
                                     );
                break;
            case 4:
                Ref(*(int *)(_2+4));
                Ref(*(int *)(_2+8));
                Ref(*(int *)(_2+12));
                Ref(*(int *)(_2+16));
                _1 = (*(int (*)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8), 
                                    *(int *)(_2+12), 
                                    *(int *)(_2+16)
                                     );
                break;
            case 5:
                Ref(*(int *)(_2+4));
                Ref(*(int *)(_2+8));
                Ref(*(int *)(_2+12));
                Ref(*(int *)(_2+16));
                Ref(*(int *)(_2+20));
                _1 = (*(int (*)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8), 
                                    *(int *)(_2+12), 
                                    *(int *)(_2+16), 
                                    *(int *)(_2+20)
                                     );
                break;
            case 6:
                Ref(*(int *)(_2+4));
                Ref(*(int *)(_2+8));
                Ref(*(int *)(_2+12));
                Ref(*(int *)(_2+16));
                Ref(*(int *)(_2+20));
                Ref(*(int *)(_2+24));
                _1 = (*(int (*)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8), 
                                    *(int *)(_2+12), 
                                    *(int *)(_2+16), 
                                    *(int *)(_2+20), 
                                    *(int *)(_2+24)
                                     );
                break;
            case 7:
                Ref(*(int *)(_2+4));
                Ref(*(int *)(_2+8));
                Ref(*(int *)(_2+12));
                Ref(*(int *)(_2+16));
                Ref(*(int *)(_2+20));
                Ref(*(int *)(_2+24));
                Ref(*(int *)(_2+28));
                _1 = (*(int (*)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8), 
                                    *(int *)(_2+12), 
                                    *(int *)(_2+16), 
                                    *(int *)(_2+20), 
                                    *(int *)(_2+24), 
                                    *(int *)(_2+28)
                                     );
                break;
            case 8:
                Ref(*(int *)(_2+4));
                Ref(*(int *)(_2+8));
                Ref(*(int *)(_2+12));
                Ref(*(int *)(_2+16));
                Ref(*(int *)(_2+20));
                Ref(*(int *)(_2+24));
                Ref(*(int *)(_2+28));
                Ref(*(int *)(_2+32));
                _1 = (*(int (*)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8), 
                                    *(int *)(_2+12), 
                                    *(int *)(_2+16), 
                                    *(int *)(_2+20), 
                                    *(int *)(_2+24), 
                                    *(int *)(_2+28), 
                                    *(int *)(_2+32)
                                     );
                break;
            case 9:
                Ref(*(int *)(_2+4));
                Ref(*(int *)(_2+8));
                Ref(*(int *)(_2+12));
                Ref(*(int *)(_2+16));
                Ref(*(int *)(_2+20));
                Ref(*(int *)(_2+24));
                Ref(*(int *)(_2+28));
                Ref(*(int *)(_2+32));
                Ref(*(int *)(_2+36));
                _1 = (*(int (*)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8), 
                                    *(int *)(_2+12), 
                                    *(int *)(_2+16), 
                                    *(int *)(_2+20), 
                                    *(int *)(_2+24), 
                                    *(int *)(_2+28), 
                                    *(int *)(_2+32), 
                                    *(int *)(_2+36)
                                     );
                break;
        }
        DeRef(_result_4004);
        _result_4004 = _1;

        /** 				if sequence(result) then*/
        _1967 = IS_SEQUENCE(_result_4004);
        if (_1967 == 0)
        {
            _1967 = NOVALUE;
            goto L8; // [154] 174
        }
        else{
            _1967 = NOVALUE;
        }

        /** 					args[3] = result[2]*/
        _2 = (int)SEQ_PTR(_result_4004);
        _1968 = (int)*(((s1_ptr)_2)->base + 2);
        Ref(_1968);
        _2 = (int)SEQ_PTR(_args_4005);
        _2 = (int)(((s1_ptr)_2)->base + 3);
        _1 = *(int *)_2;
        *(int *)_2 = _1968;
        if( _1 != _1968 ){
            DeRef(_1);
        }
        _1968 = NOVALUE;

        /** 					result = result[1]*/
        _0 = _result_4004;
        _2 = (int)SEQ_PTR(_result_4004);
        _result_4004 = (int)*(((s1_ptr)_2)->base + 1);
        Ref(_result_4004);
        DeRef(_0);
L8: 

        /** 				if eu:compare(result, 0) != order then*/
        if (IS_ATOM_INT(_result_4004) && IS_ATOM_INT(0)){
            _1970 = (_result_4004 < 0) ? -1 : (_result_4004 > 0);
        }
        else{
            _1970 = compare(_result_4004, 0);
        }
        if (_1970 == _order_3997)
        goto L9; // [180] 195

        /** 					j += gap*/
        _j_3999 = _j_3999 + _gap_3998;

        /** 					exit*/
        goto LA; // [192] 227
L9: 

        /** 				x[j+gap] = tempj*/
        _1973 = _j_3999 + _gap_3998;
        Ref(_tempj_4003);
        _2 = (int)SEQ_PTR(_x_3995);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _x_3995 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _1973);
        _1 = *(int *)_2;
        *(int *)_2 = _tempj_4003;
        DeRef(_1);

        /** 				if j <= gap then*/
        if (_j_3999 > _gap_3998)
        goto LB; // [207] 216

        /** 					exit*/
        goto LA; // [213] 227
LB: 

        /** 				j -= gap*/
        _j_3999 = _j_3999 - _gap_3998;

        /** 			end while*/
        goto L7; // [224] 131
LA: 

        /** 			x[j] = tempi*/
        Ref(_tempi_4002);
        _2 = (int)SEQ_PTR(_x_3995);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _x_3995 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _j_3999);
        _1 = *(int *)_2;
        *(int *)_2 = _tempi_4002;
        DeRef(_1);

        /** 		end for*/
        _i_4023 = _i_4023 + 1;
        goto L5; // [235] 108
L6: 
        ;
    }

    /** 		if gap = 1 then*/
    if (_gap_3998 != 1)
    goto LC; // [242] 255

    /** 			return x*/
    DeRef(_data_3996);
    DeRef(_tempi_4002);
    DeRef(_tempj_4003);
    DeRef(_result_4004);
    DeRef(_args_4005);
    DeRef(_1973);
    _1973 = NOVALUE;
    return _x_3995;
    goto L4; // [252] 90
LC: 

    /** 			gap = floor(gap / 7) + 1*/
    if (7 > 0 && _gap_3998 >= 0) {
        _1977 = _gap_3998 / 7;
    }
    else {
        temp_dbl = floor((double)_gap_3998 / (double)7);
        _1977 = (long)temp_dbl;
    }
    _gap_3998 = _1977 + 1;
    _1977 = NOVALUE;

    /** 	end while*/
    goto L4; // [268] 90
    ;
}


int _24column_compare(int _a_4049, int _b_4050, int _cols_4051)
{
    int _sign_4052 = NOVALUE;
    int _column_4053 = NOVALUE;
    int _2000 = NOVALUE;
    int _1998 = NOVALUE;
    int _1997 = NOVALUE;
    int _1996 = NOVALUE;
    int _1995 = NOVALUE;
    int _1994 = NOVALUE;
    int _1993 = NOVALUE;
    int _1991 = NOVALUE;
    int _1990 = NOVALUE;
    int _1989 = NOVALUE;
    int _1987 = NOVALUE;
    int _1985 = NOVALUE;
    int _1982 = NOVALUE;
    int _1980 = NOVALUE;
    int _1979 = NOVALUE;
    int _0, _1, _2;
    

    /** 	for i = 1 to length(cols) do*/
    if (IS_SEQUENCE(_cols_4051)){
            _1979 = SEQ_PTR(_cols_4051)->length;
    }
    else {
        _1979 = 1;
    }
    {
        int _i_4055;
        _i_4055 = 1;
L1: 
        if (_i_4055 > _1979){
            goto L2; // [6] 176
        }

        /** 		if cols[i] < 0 then*/
        _2 = (int)SEQ_PTR(_cols_4051);
        _1980 = (int)*(((s1_ptr)_2)->base + _i_4055);
        if (binary_op_a(GREATEREQ, _1980, 0)){
            _1980 = NOVALUE;
            goto L3; // [19] 42
        }
        _1980 = NOVALUE;

        /** 			sign = -1*/
        _sign_4052 = -1;

        /** 			column = -cols[i]*/
        _2 = (int)SEQ_PTR(_cols_4051);
        _1982 = (int)*(((s1_ptr)_2)->base + _i_4055);
        if (IS_ATOM_INT(_1982)) {
            if ((unsigned long)_1982 == 0xC0000000)
            _column_4053 = (int)NewDouble((double)-0xC0000000);
            else
            _column_4053 = - _1982;
        }
        else {
            _column_4053 = unary_op(UMINUS, _1982);
        }
        _1982 = NOVALUE;
        if (!IS_ATOM_INT(_column_4053)) {
            _1 = (long)(DBL_PTR(_column_4053)->dbl);
            DeRefDS(_column_4053);
            _column_4053 = _1;
        }
        goto L4; // [39] 56
L3: 

        /** 			sign = 1*/
        _sign_4052 = 1;

        /** 			column = cols[i]*/
        _2 = (int)SEQ_PTR(_cols_4051);
        _column_4053 = (int)*(((s1_ptr)_2)->base + _i_4055);
        if (!IS_ATOM_INT(_column_4053)){
            _column_4053 = (long)DBL_PTR(_column_4053)->dbl;
        }
L4: 

        /** 		if column <= length(a) then*/
        if (IS_SEQUENCE(_a_4049)){
                _1985 = SEQ_PTR(_a_4049)->length;
        }
        else {
            _1985 = 1;
        }
        if (_column_4053 > _1985)
        goto L5; // [63] 137

        /** 			if column <= length(b) then*/
        if (IS_SEQUENCE(_b_4050)){
                _1987 = SEQ_PTR(_b_4050)->length;
        }
        else {
            _1987 = 1;
        }
        if (_column_4053 > _1987)
        goto L6; // [72] 121

        /** 				if not equal(a[column], b[column]) then*/
        _2 = (int)SEQ_PTR(_a_4049);
        _1989 = (int)*(((s1_ptr)_2)->base + _column_4053);
        _2 = (int)SEQ_PTR(_b_4050);
        _1990 = (int)*(((s1_ptr)_2)->base + _column_4053);
        if (_1989 == _1990)
        _1991 = 1;
        else if (IS_ATOM_INT(_1989) && IS_ATOM_INT(_1990))
        _1991 = 0;
        else
        _1991 = (compare(_1989, _1990) == 0);
        _1989 = NOVALUE;
        _1990 = NOVALUE;
        if (_1991 != 0)
        goto L7; // [90] 169
        _1991 = NOVALUE;

        /** 					return sign * eu:compare(a[column], b[column])*/
        _2 = (int)SEQ_PTR(_a_4049);
        _1993 = (int)*(((s1_ptr)_2)->base + _column_4053);
        _2 = (int)SEQ_PTR(_b_4050);
        _1994 = (int)*(((s1_ptr)_2)->base + _column_4053);
        if (IS_ATOM_INT(_1993) && IS_ATOM_INT(_1994)){
            _1995 = (_1993 < _1994) ? -1 : (_1993 > _1994);
        }
        else{
            _1995 = compare(_1993, _1994);
        }
        _1993 = NOVALUE;
        _1994 = NOVALUE;
        if (_sign_4052 == (short)_sign_4052)
        _1996 = _sign_4052 * _1995;
        else
        _1996 = NewDouble(_sign_4052 * (double)_1995);
        _1995 = NOVALUE;
        DeRef(_a_4049);
        DeRef(_b_4050);
        DeRef(_cols_4051);
        return _1996;
        goto L7; // [118] 169
L6: 

        /** 				return sign * -1*/
        if (_sign_4052 == (short)_sign_4052)
        _1997 = _sign_4052 * -1;
        else
        _1997 = NewDouble(_sign_4052 * (double)-1);
        DeRef(_a_4049);
        DeRef(_b_4050);
        DeRef(_cols_4051);
        DeRef(_1996);
        _1996 = NOVALUE;
        return _1997;
        goto L7; // [134] 169
L5: 

        /** 			if column <= length(b) then*/
        if (IS_SEQUENCE(_b_4050)){
                _1998 = SEQ_PTR(_b_4050)->length;
        }
        else {
            _1998 = 1;
        }
        if (_column_4053 > _1998)
        goto L8; // [142] 161

        /** 				return sign * 1*/
        _2000 = _sign_4052 * 1;
        DeRef(_a_4049);
        DeRef(_b_4050);
        DeRef(_cols_4051);
        DeRef(_1996);
        _1996 = NOVALUE;
        DeRef(_1997);
        _1997 = NOVALUE;
        return _2000;
        goto L9; // [158] 168
L8: 

        /** 				return 0*/
        DeRef(_a_4049);
        DeRef(_b_4050);
        DeRef(_cols_4051);
        DeRef(_1996);
        _1996 = NOVALUE;
        DeRef(_1997);
        _1997 = NOVALUE;
        DeRef(_2000);
        _2000 = NOVALUE;
        return 0;
L9: 
L7: 

        /** 	end for*/
        _i_4055 = _i_4055 + 1;
        goto L1; // [171] 13
L2: 
        ;
    }

    /** 	return 0*/
    DeRef(_a_4049);
    DeRef(_b_4050);
    DeRef(_cols_4051);
    DeRef(_1996);
    _1996 = NOVALUE;
    DeRef(_1997);
    _1997 = NOVALUE;
    DeRef(_2000);
    _2000 = NOVALUE;
    return 0;
    ;
}



// 0xC7493B00
