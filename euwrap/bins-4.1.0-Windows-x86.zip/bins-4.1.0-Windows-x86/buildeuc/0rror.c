// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _50screen_output(object _f_49605, object _msg_49606)
{
    object _0, _1, _2;
    

    /** error.e:44		puts(f, msg)*/
    EPuts(2, _msg_49606); // DJP 

    /** error.e:45	end procedure*/
    DeRefDS(_msg_49606);
    return;
    ;
}


void _50Warning(object _msg_49609, object _mask_49610, object _args_49611)
{
    object _orig_mask_49612 = NOVALUE;
    object _text_49613 = NOVALUE;
    object _w_name_49614 = NOVALUE;
    object _25508 = NOVALUE;
    object _25506 = NOVALUE;
    object _25504 = NOVALUE;
    object _25501 = NOVALUE;
    object _25496 = NOVALUE;
    object _25494 = NOVALUE;
    object _25493 = NOVALUE;
    object _25492 = NOVALUE;
    object _25491 = NOVALUE;
    object _25489 = NOVALUE;
    object _0, _1, _2;
    

    /** error.e:54		if display_warnings = 0 then*/

    /** error.e:58		if not Strict_is_on or Strict_Override then*/
    _25489 = (_36Strict_is_on_21836 == 0);
    if (_25489 != 0) {
        goto L1; // [26] 37
    }
    if (_36Strict_Override_21837 == 0)
    {
        goto L2; // [33] 56
    }
    else{
    }
L1: 

    /** error.e:59			if find(mask, strict_only_warnings) then*/
    _25491 = find_from(_mask_49610, _36strict_only_warnings_21834, 1);
    if (_25491 == 0)
    {
        _25491 = NOVALUE;
        goto L3; // [46] 55
    }
    else{
        _25491 = NOVALUE;
    }

    /** error.e:60				return*/
    DeRef(_msg_49609);
    DeRefDS(_args_49611);
    DeRef(_text_49613);
    DeRef(_w_name_49614);
    DeRef(_25489);
    _25489 = NOVALUE;
    return;
L3: 
L2: 

    /** error.e:64		orig_mask = mask -- =0 for non maskable warnings - none implemented so far*/
    _orig_mask_49612 = _mask_49610;

    /** error.e:65		if Strict_is_on and Strict_Override = 0 then*/
    if (_36Strict_is_on_21836 == 0) {
        goto L4; // [65] 85
    }
    _25493 = (_36Strict_Override_21837 == 0);
    if (_25493 == 0)
    {
        DeRef(_25493);
        _25493 = NOVALUE;
        goto L4; // [76] 85
    }
    else{
        DeRef(_25493);
        _25493 = NOVALUE;
    }

    /** error.e:66			mask = 0*/
    _mask_49610 = 0;
L4: 

    /** error.e:69		if mask = 0 or and_bits(OpWarning, mask) then*/
    _25494 = (_mask_49610 == 0);
    if (_25494 != 0) {
        goto L5; // [91] 106
    }
    {uintptr_t tu;
         tu = (uintptr_t)_36OpWarning_21838 & (uintptr_t)_mask_49610;
         _25496 = MAKE_UINT(tu);
    }
    if (_25496 == 0) {
        DeRef(_25496);
        _25496 = NOVALUE;
        goto L6; // [102] 215
    }
    else {
        if (!IS_ATOM_INT(_25496) && DBL_PTR(_25496)->dbl == 0.0){
            DeRef(_25496);
            _25496 = NOVALUE;
            goto L6; // [102] 215
        }
        DeRef(_25496);
        _25496 = NOVALUE;
    }
    DeRef(_25496);
    _25496 = NOVALUE;
L5: 

    /** error.e:70			if orig_mask != 0 then*/
    if (_orig_mask_49612 == 0)
    goto L7; // [108] 122

    /** error.e:71				orig_mask = find(orig_mask,warning_flags)*/
    _orig_mask_49612 = find_from(_orig_mask_49612, _36warning_flags_21813, 1);
L7: 

    /** error.e:74			if orig_mask != 0 then*/
    if (_orig_mask_49612 == 0)
    goto L8; // [124] 145

    /** error.e:75				w_name = "{ " & warning_names[orig_mask] & " }"*/
    _2 = (object)SEQ_PTR(_36warning_names_21815);
    _25501 = (object)*(((s1_ptr)_2)->base + _orig_mask_49612);
    {
        object concat_list[3];

        concat_list[0] = _25502;
        concat_list[1] = _25501;
        concat_list[2] = _25500;
        Concat_N((object_ptr)&_w_name_49614, concat_list, 3);
    }
    _25501 = NOVALUE;
    goto L9; // [142] 153
L8: 

    /** error.e:77				w_name = "" -- not maskable*/
    RefDS(_22190);
    DeRef(_w_name_49614);
    _w_name_49614 = _22190;
L9: 

    /** error.e:80			if atom(msg) then*/
    _25504 = IS_ATOM(_msg_49609);
    if (_25504 == 0)
    {
        _25504 = NOVALUE;
        goto LA; // [158] 170
    }
    else{
        _25504 = NOVALUE;
    }

    /** error.e:81				msg = GetMsgText(msg, 1, args)*/
    Ref(_msg_49609);
    RefDS(_args_49611);
    _0 = _msg_49609;
    _msg_49609 = _39GetMsgText(_msg_49609, 1, _args_49611);
    DeRef(_0);
LA: 

    /** error.e:84			text = GetMsgText(WARNING_1T2, 0, {w_name, msg})*/
    Ref(_msg_49609);
    RefDS(_w_name_49614);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _w_name_49614;
    ((intptr_t *)_2)[2] = _msg_49609;
    _25506 = MAKE_SEQ(_1);
    _0 = _text_49613;
    _text_49613 = _39GetMsgText(204, 0, _25506);
    DeRef(_0);
    _25506 = NOVALUE;

    /** error.e:85			if find(text, warning_list) then*/
    _25508 = find_from(_text_49613, _50warning_list_49602, 1);
    if (_25508 == 0)
    {
        _25508 = NOVALUE;
        goto LB; // [197] 206
    }
    else{
        _25508 = NOVALUE;
    }

    /** error.e:86				return -- duplicate*/
    DeRef(_msg_49609);
    DeRefDS(_args_49611);
    DeRefDS(_text_49613);
    DeRefDS(_w_name_49614);
    DeRef(_25489);
    _25489 = NOVALUE;
    DeRef(_25494);
    _25494 = NOVALUE;
    return;
LB: 

    /** error.e:89			warning_list = append(warning_list, text)*/
    RefDS(_text_49613);
    Append(&_50warning_list_49602, _50warning_list_49602, _text_49613);
L6: 

    /** error.e:91	end procedure*/
    DeRef(_msg_49609);
    DeRefDS(_args_49611);
    DeRef(_text_49613);
    DeRef(_w_name_49614);
    DeRef(_25489);
    _25489 = NOVALUE;
    DeRef(_25494);
    _25494 = NOVALUE;
    return;
    ;
}


object _50ShowWarnings()
{
    object _c_49679 = NOVALUE;
    object _errfile_49680 = NOVALUE;
    object _twf_49681 = NOVALUE;
    object _25547 = NOVALUE;
    object _25544 = NOVALUE;
    object _25543 = NOVALUE;
    object _25542 = NOVALUE;
    object _25541 = NOVALUE;
    object _25540 = NOVALUE;
    object _25539 = NOVALUE;
    object _25537 = NOVALUE;
    object _25536 = NOVALUE;
    object _25535 = NOVALUE;
    object _25533 = NOVALUE;
    object _25532 = NOVALUE;
    object _25531 = NOVALUE;
    object _25530 = NOVALUE;
    object _25528 = NOVALUE;
    object _25524 = NOVALUE;
    object _25522 = NOVALUE;
    object _25521 = NOVALUE;
    object _25520 = NOVALUE;
    object _25518 = NOVALUE;
    object _0, _1, _2;
    

    /** error.e:117		if display_warnings = 0 or length(warning_list) = 0 then*/
    _25518 = (1 == 0);
    if (_25518 != 0) {
        goto L1; // [9] 27
    }
    if (IS_SEQUENCE(_50warning_list_49602)){
            _25520 = SEQ_PTR(_50warning_list_49602)->length;
    }
    else {
        _25520 = 1;
    }
    _25521 = (_25520 == 0);
    _25520 = NOVALUE;
    if (_25521 == 0)
    {
        DeRef(_25521);
        _25521 = NOVALUE;
        goto L2; // [23] 39
    }
    else{
        DeRef(_25521);
        _25521 = NOVALUE;
    }
L1: 

    /** error.e:118			return length(warning_list)*/
    if (IS_SEQUENCE(_50warning_list_49602)){
            _25522 = SEQ_PTR(_50warning_list_49602)->length;
    }
    else {
        _25522 = 1;
    }
    DeRef(_25518);
    _25518 = NOVALUE;
    return _25522;
L2: 

    /** error.e:121		if TempErrFile > 0 then*/
    if (_50TempErrFile_49591 <= 0)
    goto L3; // [43] 57

    /** error.e:122			errfile = TempErrFile*/
    _errfile_49680 = _50TempErrFile_49591;
    goto L4; // [54] 67
L3: 

    /** error.e:124			errfile = STDERR*/
    _errfile_49680 = 2;
L4: 

    /** error.e:127		if not integer(TempWarningName) then*/
    if (IS_ATOM_INT(_36TempWarningName_21781))
    _25524 = 1;
    else if (IS_ATOM_DBL(_36TempWarningName_21781))
    _25524 = IS_ATOM_INT(DoubleToInt(_36TempWarningName_21781));
    else
    _25524 = 0;
    if (_25524 != 0)
    goto L5; // [74] 183
    _25524 = NOVALUE;

    /** error.e:128			twf = open(TempWarningName,"w")*/
    _twf_49681 = EOpen(_36TempWarningName_21781, _22326, 0);

    /** error.e:129			if twf = -1 then*/
    if (_twf_49681 != -1)
    goto L6; // [88] 140

    /** error.e:130				ShowMsg(errfile, UNABLE_TO_CREATE_WARNING_FILE_1, {TempWarningName})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_36TempWarningName_21781);
    ((intptr_t*)_2)[1] = _36TempWarningName_21781;
    _25528 = MAKE_SEQ(_1);
    _39ShowMsg(_errfile_49680, 205, _25528, 1);
    _25528 = NOVALUE;

    /** error.e:131				if errfile != STDERR then*/
    if (_errfile_49680 == 2)
    goto L7; // [114] 177

    /** error.e:132					ShowMsg(STDERR, UNABLE_TO_CREATE_WARNING_FILE_1, {TempWarningName})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_36TempWarningName_21781);
    ((intptr_t*)_2)[1] = _36TempWarningName_21781;
    _25530 = MAKE_SEQ(_1);
    _39ShowMsg(2, 205, _25530, 1);
    _25530 = NOVALUE;
    goto L7; // [137] 177
L6: 

    /** error.e:135				for i = 1 to length(warning_list) do*/
    if (IS_SEQUENCE(_50warning_list_49602)){
            _25531 = SEQ_PTR(_50warning_list_49602)->length;
    }
    else {
        _25531 = 1;
    }
    {
        object _i_49714;
        _i_49714 = 1;
L8: 
        if (_i_49714 > _25531){
            goto L9; // [147] 172
        }

        /** error.e:136					puts(twf, warning_list[i])*/
        _2 = (object)SEQ_PTR(_50warning_list_49602);
        _25532 = (object)*(((s1_ptr)_2)->base + _i_49714);
        EPuts(_twf_49681, _25532); // DJP 
        _25532 = NOVALUE;

        /** error.e:137				end for*/
        _i_49714 = _i_49714 + 1;
        goto L8; // [167] 154
L9: 
        ;
    }

    /** error.e:138			    close(twf)*/
    EClose(_twf_49681);
L7: 

    /** error.e:140			TempWarningName = 99 -- Flag that we have done this already.*/
    DeRef(_36TempWarningName_21781);
    _36TempWarningName_21781 = 99;
L5: 

    /** error.e:143		if batch_job = 0 or errfile != STDERR then*/
    _25533 = (_36batch_job_21780 == 0);
    if (_25533 != 0) {
        goto LA; // [191] 208
    }
    _25535 = (_errfile_49680 != 2);
    if (_25535 == 0)
    {
        DeRef(_25535);
        _25535 = NOVALUE;
        goto LB; // [204] 317
    }
    else{
        DeRef(_25535);
        _25535 = NOVALUE;
    }
LA: 

    /** error.e:144			for i = 1 to length(warning_list) do*/
    if (IS_SEQUENCE(_50warning_list_49602)){
            _25536 = SEQ_PTR(_50warning_list_49602)->length;
    }
    else {
        _25536 = 1;
    }
    {
        object _i_49725;
        _i_49725 = 1;
LC: 
        if (_i_49725 > _25536){
            goto LD; // [215] 316
        }

        /** error.e:145				puts(errfile, warning_list[i])*/
        _2 = (object)SEQ_PTR(_50warning_list_49602);
        _25537 = (object)*(((s1_ptr)_2)->base + _i_49725);
        EPuts(_errfile_49680, _25537); // DJP 
        _25537 = NOVALUE;

        /** error.e:146				if errfile = STDERR then*/
        if (_errfile_49680 != 2)
        goto LE; // [239] 309

        /** error.e:147					if remainder(i, 20) = 0 and batch_job = 0 and test_only = 0 then*/
        _25539 = (_i_49725 % 20);
        _25540 = (_25539 == 0);
        _25539 = NOVALUE;
        if (_25540 == 0) {
            _25541 = 0;
            goto LF; // [253] 267
        }
        _25542 = (_36batch_job_21780 == 0);
        _25541 = (_25542 != 0);
LF: 
        if (_25541 == 0) {
            goto L10; // [267] 308
        }
        _25544 = (_36test_only_21779 == 0);
        if (_25544 == 0)
        {
            DeRef(_25544);
            _25544 = NOVALUE;
            goto L10; // [278] 308
        }
        else{
            DeRef(_25544);
            _25544 = NOVALUE;
        }

        /** error.e:148						ShowMsg(errfile, PRESS_ENTER_TO_CONTINUE_Q_TO_QUIT)*/
        RefDS(_22190);
        _39ShowMsg(_errfile_49680, 206, _22190, 1);

        /** error.e:149						c = getc(0)*/
        if (0 != last_r_file_no) {
            last_r_file_ptr = which_file(0, EF_READ);
            last_r_file_no = 0;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _c_49679 = getKBchar();
            }
            else{
                _c_49679 = getc(last_r_file_ptr);
            }
        }
        else{
            _c_49679 = getc(last_r_file_ptr);
        }

        /** error.e:150						if c = 'q' then*/
        if (_c_49679 != 113)
        goto L11; // [298] 307

        /** error.e:151							exit*/
        goto LD; // [304] 316
L11: 
L10: 
LE: 

        /** error.e:155			end for*/
        _i_49725 = _i_49725 + 1;
        goto LC; // [311] 222
LD: 
        ;
    }
LB: 

    /** error.e:158		return length(warning_list)*/
    if (IS_SEQUENCE(_50warning_list_49602)){
            _25547 = SEQ_PTR(_50warning_list_49602)->length;
    }
    else {
        _25547 = 1;
    }
    DeRef(_25518);
    _25518 = NOVALUE;
    DeRef(_25542);
    _25542 = NOVALUE;
    DeRef(_25533);
    _25533 = NOVALUE;
    DeRef(_25540);
    _25540 = NOVALUE;
    return _25547;
    ;
}


void _50ShowDefines(object _errfile_49748)
{
    object _c_49749 = NOVALUE;
    object _25561 = NOVALUE;
    object _25560 = NOVALUE;
    object _25558 = NOVALUE;
    object _25557 = NOVALUE;
    object _25554 = NOVALUE;
    object _25553 = NOVALUE;
    object _25552 = NOVALUE;
    object _25551 = NOVALUE;
    object _25550 = NOVALUE;
    object _0, _1, _2;
    

    /** error.e:164		if errfile=0 then*/
    if (_errfile_49748 != 0)
    goto L1; // [5] 19

    /** error.e:165			errfile = STDERR*/
    _errfile_49748 = 2;
L1: 

    /** error.e:168		puts(errfile, format("\n--- [1] ---\n", {GetMsgText(DEFINED_WORDS,0)}))*/
    RefDS(_22190);
    _25550 = _39GetMsgText(207, 0, _22190);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _25550;
    _25551 = MAKE_SEQ(_1);
    _25550 = NOVALUE;
    RefDS(_25549);
    _25552 = _14format(_25549, _25551);
    _25551 = NOVALUE;
    EPuts(_errfile_49748, _25552); // DJP 
    DeRef(_25552);
    _25552 = NOVALUE;

    /** error.e:170		for i = 1 to length(OpDefines) do*/
    if (IS_SEQUENCE(_36OpDefines_21844)){
            _25553 = SEQ_PTR(_36OpDefines_21844)->length;
    }
    else {
        _25553 = 1;
    }
    {
        object _i_49761;
        _i_49761 = 1;
L2: 
        if (_i_49761 > _25553){
            goto L3; // [48] 100
        }

        /** error.e:171			if find(OpDefines[i], {"_PLAT_START", "_PLAT_STOP"}) = 0 then*/
        _2 = (object)SEQ_PTR(_36OpDefines_21844);
        _25554 = (object)*(((s1_ptr)_2)->base + _i_49761);
        RefDS(_25556);
        RefDS(_25555);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _25555;
        ((intptr_t *)_2)[2] = _25556;
        _25557 = MAKE_SEQ(_1);
        _25558 = find_from(_25554, _25557, 1);
        _25554 = NOVALUE;
        DeRefDS(_25557);
        _25557 = NOVALUE;
        if (_25558 != 0)
        goto L4; // [72] 93

        /** error.e:172				printf(errfile, "%s\n", {OpDefines[i]})*/
        _2 = (object)SEQ_PTR(_36OpDefines_21844);
        _25560 = (object)*(((s1_ptr)_2)->base + _i_49761);
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        Ref(_25560);
        ((intptr_t*)_2)[1] = _25560;
        _25561 = MAKE_SEQ(_1);
        _25560 = NOVALUE;
        EPrintf(_errfile_49748, _25442, _25561);
        DeRefDS(_25561);
        _25561 = NOVALUE;
L4: 

        /** error.e:174		end for*/
        _i_49761 = _i_49761 + 1;
        goto L2; // [95] 55
L3: 
        ;
    }

    /** error.e:175		puts(errfile, "-------------------\n")*/
    EPuts(_errfile_49748, _25562); // DJP 

    /** error.e:177	end procedure*/
    return;
    ;
}


void _50Cleanup(object _status_49778)
{
    object _w_49779 = NOVALUE;
    object _show_error_49780 = NOVALUE;
    object _25580 = NOVALUE;
    object _25579 = NOVALUE;
    object _25578 = NOVALUE;
    object _25577 = NOVALUE;
    object _25576 = NOVALUE;
    object _25575 = NOVALUE;
    object _25574 = NOVALUE;
    object _25573 = NOVALUE;
    object _25572 = NOVALUE;
    object _25571 = NOVALUE;
    object _25569 = NOVALUE;
    object _25568 = NOVALUE;
    object _25567 = NOVALUE;
    object _25566 = NOVALUE;
    object _25565 = NOVALUE;
    object _25563 = NOVALUE;
    object _0, _1, _2;
    

    /** error.e:182		integer w, show_error = 0*/
    _show_error_49780 = 0;

    /** error.e:184		ifdef EU_EX then*/

    /** error.e:190		show_error = 1*/
    _show_error_49780 = 1;

    /** error.e:196		if object(src_file) = 0 then*/
    if( NOVALUE == _36src_file_21892 ){
        _25563 = 0;
    }
    else{
        _25563 = 1;
    }
    if (_25563 != 0)
    goto L1; // [20] 34

    /** error.e:197			src_file = -1*/
    _36src_file_21892 = -1;
    goto L2; // [31] 86
L1: 

    /** error.e:198		elsif src_file >= 0 and (src_file != repl_file or not repl) then*/
    _25565 = (_36src_file_21892 >= 0);
    if (_25565 == 0) {
        goto L3; // [42] 85
    }
    _25567 = (_36src_file_21892 != 5555);
    if (_25567 != 0) {
        DeRef(_25568);
        _25568 = 1;
        goto L4; // [54] 67
    }
    _25569 = (0 == 0);
    _25568 = (_25569 != 0);
L4: 
    if (_25568 == 0)
    {
        _25568 = NOVALUE;
        goto L3; // [68] 85
    }
    else{
        _25568 = NOVALUE;
    }

    /** error.e:199			close(src_file)*/
    EClose(_36src_file_21892);

    /** error.e:200			src_file = -1*/
    _36src_file_21892 = -1;
L3: 
L2: 

    /** error.e:203		w = ShowWarnings()*/
    _w_49779 = _50ShowWarnings();
    if (!IS_ATOM_INT(_w_49779)) {
        _1 = (object)(DBL_PTR(_w_49779)->dbl);
        DeRefDS(_w_49779);
        _w_49779 = _1;
    }

    /** error.e:204		if not TRANSLATE and (BIND or show_error) and (w or Errors) then*/
    _25571 = (_36TRANSLATE_21369 == 0);
    if (_25571 == 0) {
        _25572 = 0;
        goto L5; // [100] 118
    }
    if (_36BIND_21372 != 0) {
        _25573 = 1;
        goto L6; // [106] 114
    }
    _25573 = (_show_error_49780 != 0);
L6: 
    _25572 = (_25573 != 0);
L5: 
    if (_25572 == 0) {
        goto L7; // [118] 179
    }
    if (_w_49779 != 0) {
        DeRef(_25575);
        _25575 = 1;
        goto L8; // [122] 132
    }
    _25575 = (_50Errors_49590 != 0);
L8: 
    if (_25575 == 0)
    {
        _25575 = NOVALUE;
        goto L7; // [133] 179
    }
    else{
        _25575 = NOVALUE;
    }

    /** error.e:205			if not batch_job and not test_only then*/
    _25576 = (_36batch_job_21780 == 0);
    if (_25576 == 0) {
        goto L9; // [143] 178
    }
    _25578 = (_36test_only_21779 == 0);
    if (_25578 == 0)
    {
        DeRef(_25578);
        _25578 = NOVALUE;
        goto L9; // [153] 178
    }
    else{
        DeRef(_25578);
        _25578 = NOVALUE;
    }

    /** error.e:206				screen_output(STDERR, GetMsgText(PRESS_ENTER,0))*/
    RefDS(_22190);
    _25579 = _39GetMsgText(208, 0, _22190);
    _50screen_output(2, _25579);
    _25579 = NOVALUE;

    /** error.e:207				getc(0) -- wait*/
    if (0 != last_r_file_no) {
        last_r_file_ptr = which_file(0, EF_READ);
        last_r_file_no = 0;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _25580 = getKBchar();
        }
        else{
            _25580 = getc(last_r_file_ptr);
        }
    }
    else{
        _25580 = getc(last_r_file_ptr);
    }
L9: 
L7: 

    /** error.e:212		cleanup_open_includes()*/
    _62cleanup_open_includes();

    /** error.e:213		abort(status)*/
    UserCleanup(_status_49778);

    /** error.e:214	end procedure*/
    DeRef(_25569);
    _25569 = NOVALUE;
    DeRef(_25571);
    _25571 = NOVALUE;
    DeRef(_25567);
    _25567 = NOVALUE;
    DeRef(_25565);
    _25565 = NOVALUE;
    DeRef(_25576);
    _25576 = NOVALUE;
    return;
    ;
}


void _50OpenErrFile()
{
    object _25587 = NOVALUE;
    object _25586 = NOVALUE;
    object _25584 = NOVALUE;
    object _0, _1, _2;
    

    /** error.e:219	    if TempErrFile != -1 then*/
    if (_50TempErrFile_49591 == -1)
    goto L1; // [5] 19

    /** error.e:220			TempErrFile = open(TempErrName, "w")*/
    _50TempErrFile_49591 = EOpen(_50TempErrName_49592, _22326, 0);
L1: 

    /** error.e:223		if TempErrFile = -1 then*/
    if (_50TempErrFile_49591 != -1)
    goto L2; // [23] 66

    /** error.e:224			if length(TempErrName) > 0 then*/
    _25584 = 6;

    /** error.e:225				screen_output(STDERR, GetMsgText(CANT_CREATE_ERROR_MESSAGE_FILE_1, 0, {TempErrName}))*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_50TempErrName_49592);
    ((intptr_t*)_2)[1] = _50TempErrName_49592;
    _25586 = MAKE_SEQ(_1);
    _25587 = _39GetMsgText(209, 0, _25586);
    _25586 = NOVALUE;
    _50screen_output(2, _25587);
    _25587 = NOVALUE;

    /** error.e:227			abort(1) -- with no clean up*/
    UserCleanup(1);
L2: 

    /** error.e:229	end procedure*/
    return;
    ;
}


void _50ShowErr(object _f_49836)
{
    object _msg_inlined_screen_output_at_43_49849 = NOVALUE;
    object _25594 = NOVALUE;
    object _25593 = NOVALUE;
    object _25592 = NOVALUE;
    object _25590 = NOVALUE;
    object _25588 = NOVALUE;
    object _0, _1, _2;
    

    /** error.e:234		if length(known_files) = 0 then*/
    if (IS_SEQUENCE(_37known_files_15638)){
            _25588 = SEQ_PTR(_37known_files_15638)->length;
    }
    else {
        _25588 = 1;
    }
    if (_25588 != 0)
    goto L1; // [10] 20

    /** error.e:235			return*/
    return;
L1: 

    /** error.e:238		if ThisLine[1] = END_OF_FILE_CHAR then*/
    _2 = (object)SEQ_PTR(_50ThisLine_49594);
    _25590 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _25590, 26)){
        _25590 = NOVALUE;
        goto L2; // [30] 64
    }
    _25590 = NOVALUE;

    /** error.e:239			screen_output(f, GetMsgText(MSG_ENDOFFILE,0))*/
    RefDS(_22190);
    _25592 = _39GetMsgText(210, 0, _22190);
    DeRef(_msg_inlined_screen_output_at_43_49849);
    _msg_inlined_screen_output_at_43_49849 = _25592;
    _25592 = NOVALUE;

    /** error.e:44		puts(f, msg)*/
    EPuts(_f_49836, _msg_inlined_screen_output_at_43_49849); // DJP 

    /** error.e:45	end procedure*/
    goto L3; // [56] 59
L3: 
    DeRef(_msg_inlined_screen_output_at_43_49849);
    _msg_inlined_screen_output_at_43_49849 = NOVALUE;
    goto L4; // [61] 81
L2: 

    /** error.e:241			screen_output(f, ThisLine)*/

    /** error.e:44		puts(f, msg)*/
    EPuts(_f_49836, _50ThisLine_49594); // DJP 

    /** error.e:45	end procedure*/
    goto L5; // [77] 80
L5: 
L4: 

    /** error.e:244		for i = 1 to bp-2 do -- bp-1 points to last character read*/
    _25593 = _50bp_49598 - 2;
    if ((object)((uintptr_t)_25593 +(uintptr_t) HIGH_BITS) >= 0){
        _25593 = NewDouble((eudouble)_25593);
    }
    {
        object _i_49853;
        _i_49853 = 1;
L6: 
        if (binary_op_a(GREATER, _i_49853, _25593)){
            goto L7; // [89] 143
        }

        /** error.e:245			if ThisLine[i] = '\t' then*/
        _2 = (object)SEQ_PTR(_50ThisLine_49594);
        if (!IS_ATOM_INT(_i_49853)){
            _25594 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_49853)->dbl));
        }
        else{
            _25594 = (object)*(((s1_ptr)_2)->base + _i_49853);
        }
        if (binary_op_a(NOTEQ, _25594, 9)){
            _25594 = NOVALUE;
            goto L8; // [104] 123
        }
        _25594 = NOVALUE;

        /** error.e:246				screen_output(f, "\t")*/

        /** error.e:44		puts(f, msg)*/
        EPuts(_f_49836, _24152); // DJP 

        /** error.e:45	end procedure*/
        goto L9; // [117] 136
        goto L9; // [120] 136
L8: 

        /** error.e:248				screen_output(f, " ")*/

        /** error.e:44		puts(f, msg)*/
        EPuts(_f_49836, _23576); // DJP 

        /** error.e:45	end procedure*/
        goto LA; // [132] 135
LA: 
L9: 

        /** error.e:250		end for*/
        _0 = _i_49853;
        if (IS_ATOM_INT(_i_49853)) {
            _i_49853 = _i_49853 + 1;
            if ((object)((uintptr_t)_i_49853 +(uintptr_t) HIGH_BITS) >= 0){
                _i_49853 = NewDouble((eudouble)_i_49853);
            }
        }
        else {
            _i_49853 = binary_op_a(PLUS, _i_49853, 1);
        }
        DeRef(_0);
        goto L6; // [138] 96
L7: 
        ;
        DeRef(_i_49853);
    }

    /** error.e:252		screen_output(f, "^\n\n")*/

    /** error.e:44		puts(f, msg)*/
    EPuts(_f_49836, _25596); // DJP 

    /** error.e:45	end procedure*/
    goto LB; // [152] 155
LB: 

    /** error.e:253	end procedure*/
    DeRef(_25593);
    _25593 = NOVALUE;
    return;
    ;
}


void _50CompileErr(object _msg_49865, object _args_49866, object _preproc_49867)
{
    object _errmsg_49868 = NOVALUE;
    object _25617 = NOVALUE;
    object _25613 = NOVALUE;
    object _25612 = NOVALUE;
    object _25611 = NOVALUE;
    object _25610 = NOVALUE;
    object _25609 = NOVALUE;
    object _25608 = NOVALUE;
    object _25606 = NOVALUE;
    object _25605 = NOVALUE;
    object _25603 = NOVALUE;
    object _25602 = NOVALUE;
    object _25601 = NOVALUE;
    object _25597 = NOVALUE;
    object _0, _1, _2;
    

    /** error.e:260		if integer(msg) then*/
    if (IS_ATOM_INT(_msg_49865))
    _25597 = 1;
    else if (IS_ATOM_DBL(_msg_49865))
    _25597 = IS_ATOM_INT(DoubleToInt(_msg_49865));
    else
    _25597 = 0;
    if (_25597 == 0)
    {
        _25597 = NOVALUE;
        goto L1; // [8] 20
    }
    else{
        _25597 = NOVALUE;
    }

    /** error.e:261			msg = GetMsgText(msg)*/
    Ref(_msg_49865);
    RefDS(_22190);
    _0 = _msg_49865;
    _msg_49865 = _39GetMsgText(_msg_49865, 1, _22190);
    DeRefi(_0);
L1: 

    /** error.e:264		msg = format(msg, args)*/
    Ref(_msg_49865);
    Ref(_args_49866);
    _0 = _msg_49865;
    _msg_49865 = _14format(_msg_49865, _args_49866);
    DeRef(_0);

    /** error.e:266		Errors += 1*/
    _50Errors_49590 = _50Errors_49590 + 1;

    /** error.e:267		if not preproc and length(known_files) then*/
    _25601 = (_preproc_49867 == 0);
    if (_25601 == 0) {
        goto L2; // [40] 78
    }
    if (IS_SEQUENCE(_37known_files_15638)){
            _25603 = SEQ_PTR(_37known_files_15638)->length;
    }
    else {
        _25603 = 1;
    }
    if (_25603 == 0)
    {
        _25603 = NOVALUE;
        goto L2; // [50] 78
    }
    else{
        _25603 = NOVALUE;
    }

    /** error.e:268			errmsg = sprintf("%s:%d\n%s\n", {known_files[current_file_no],*/
    _2 = (object)SEQ_PTR(_37known_files_15638);
    _25605 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21767);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_25605);
    ((intptr_t*)_2)[1] = _25605;
    ((intptr_t*)_2)[2] = _36line_number_21768;
    Ref(_msg_49865);
    ((intptr_t*)_2)[3] = _msg_49865;
    _25606 = MAKE_SEQ(_1);
    _25605 = NOVALUE;
    DeRef(_errmsg_49868);
    _errmsg_49868 = EPrintf(-9999999, _25604, _25606);
    DeRefDS(_25606);
    _25606 = NOVALUE;
    goto L3; // [75] 121
L2: 

    /** error.e:271			errmsg = msg*/
    Ref(_msg_49865);
    DeRef(_errmsg_49868);
    _errmsg_49868 = _msg_49865;

    /** error.e:272			if length(msg) > 0 and msg[$] != '\n' then*/
    if (IS_SEQUENCE(_msg_49865)){
            _25608 = SEQ_PTR(_msg_49865)->length;
    }
    else {
        _25608 = 1;
    }
    _25609 = (_25608 > 0);
    _25608 = NOVALUE;
    if (_25609 == 0) {
        goto L4; // [94] 120
    }
    if (IS_SEQUENCE(_msg_49865)){
            _25611 = SEQ_PTR(_msg_49865)->length;
    }
    else {
        _25611 = 1;
    }
    _2 = (object)SEQ_PTR(_msg_49865);
    _25612 = (object)*(((s1_ptr)_2)->base + _25611);
    if (IS_ATOM_INT(_25612)) {
        _25613 = (_25612 != 10);
    }
    else {
        _25613 = binary_op(NOTEQ, _25612, 10);
    }
    _25612 = NOVALUE;
    if (_25613 == 0) {
        DeRef(_25613);
        _25613 = NOVALUE;
        goto L4; // [110] 120
    }
    else {
        if (!IS_ATOM_INT(_25613) && DBL_PTR(_25613)->dbl == 0.0){
            DeRef(_25613);
            _25613 = NOVALUE;
            goto L4; // [110] 120
        }
        DeRef(_25613);
        _25613 = NOVALUE;
    }
    DeRef(_25613);
    _25613 = NOVALUE;

    /** error.e:273				errmsg &= '\n'*/
    Append(&_errmsg_49868, _errmsg_49868, 10);
L4: 
L3: 

    /** error.e:277		if not preproc then*/
    if (_preproc_49867 != 0)
    goto L5; // [123] 131

    /** error.e:279			OpenErrFile() -- exits if error filename is ""*/
    _50OpenErrFile();
L5: 

    /** error.e:281		screen_output(STDERR, errmsg)*/
    RefDS(_errmsg_49868);
    _50screen_output(2, _errmsg_49868);

    /** error.e:283		if not preproc then*/
    if (_preproc_49867 != 0)
    goto L6; // [143] 198

    /** error.e:284			ShowErr(STDERR)*/
    _50ShowErr(2);

    /** error.e:286			puts(TempErrFile, errmsg)*/
    EPuts(_50TempErrFile_49591, _errmsg_49868); // DJP 

    /** error.e:288			ShowErr(TempErrFile)*/
    _50ShowErr(_50TempErrFile_49591);

    /** error.e:290			ShowWarnings()*/
    _25617 = _50ShowWarnings();

    /** error.e:292			ShowDefines(TempErrFile)*/
    _50ShowDefines(_50TempErrFile_49591);

    /** error.e:294			close(TempErrFile)*/
    EClose(_50TempErrFile_49591);

    /** error.e:295			TempErrFile = -2*/
    _50TempErrFile_49591 = -2;

    /** error.e:296			ifdef CRASH_ON_ERROR then*/

    /** error.e:299			Cleanup(1)*/
    _50Cleanup(1);
L6: 

    /** error.e:302	end procedure*/
    DeRef(_msg_49865);
    DeRef(_args_49866);
    DeRef(_errmsg_49868);
    DeRef(_25609);
    _25609 = NOVALUE;
    DeRef(_25601);
    _25601 = NOVALUE;
    DeRef(_25617);
    _25617 = NOVALUE;
    return;
    ;
}


void _50InternalErr(object _msgno_49912, object _args_49913)
{
    object _msg_49914 = NOVALUE;
    object _25632 = NOVALUE;
    object _25631 = NOVALUE;
    object _25630 = NOVALUE;
    object _25629 = NOVALUE;
    object _25628 = NOVALUE;
    object _25627 = NOVALUE;
    object _25626 = NOVALUE;
    object _25625 = NOVALUE;
    object _25624 = NOVALUE;
    object _25623 = NOVALUE;
    object _25622 = NOVALUE;
    object _25619 = NOVALUE;
    object _0, _1, _2;
    

    /** error.e:316		if atom(args) then*/
    _25619 = 0;
    if (_25619 == 0)
    {
        _25619 = NOVALUE;
        goto L1; // [8] 18
    }
    else{
        _25619 = NOVALUE;
    }

    /** error.e:317			args = {args}*/
    _0 = _args_49913;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_args_49913);
    ((intptr_t*)_2)[1] = _args_49913;
    _args_49913 = MAKE_SEQ(_1);
    DeRefDS(_0);
L1: 

    /** error.e:320		msg = GetMsgText(msgno, 1, args)*/
    Ref(_args_49913);
    _0 = _msg_49914;
    _msg_49914 = _39GetMsgText(_msgno_49912, 1, _args_49913);
    DeRef(_0);

    /** error.e:321		if TRANSLATE then*/
    if (_36TRANSLATE_21369 == 0)
    {
        goto L2; // [32] 58
    }
    else{
    }

    /** error.e:322			screen_output(STDERR, GetMsgText(INTERNAL_ERRORT1, 1, {msg}))*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_msg_49914);
    ((intptr_t*)_2)[1] = _msg_49914;
    _25622 = MAKE_SEQ(_1);
    _25623 = _39GetMsgText(211, 1, _25622);
    _25622 = NOVALUE;
    _50screen_output(2, _25623);
    _25623 = NOVALUE;
    goto L3; // [55] 91
L2: 

    /** error.e:324			screen_output(STDERR, GetMsgText(INTERNAL_ERROR_AT_12T3, 1, {known_files[current_file_no], line_number, msg}))*/
    _2 = (object)SEQ_PTR(_37known_files_15638);
    _25624 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21767);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_25624);
    ((intptr_t*)_2)[1] = _25624;
    ((intptr_t*)_2)[2] = _36line_number_21768;
    RefDS(_msg_49914);
    ((intptr_t*)_2)[3] = _msg_49914;
    _25625 = MAKE_SEQ(_1);
    _25624 = NOVALUE;
    _25626 = _39GetMsgText(212, 1, _25625);
    _25625 = NOVALUE;
    _50screen_output(2, _25626);
    _25626 = NOVALUE;
L3: 

    /** error.e:327		if not batch_job and not test_only then*/
    _25627 = (_36batch_job_21780 == 0);
    if (_25627 == 0) {
        goto L4; // [98] 133
    }
    _25629 = (_36test_only_21779 == 0);
    if (_25629 == 0)
    {
        DeRef(_25629);
        _25629 = NOVALUE;
        goto L4; // [108] 133
    }
    else{
        DeRef(_25629);
        _25629 = NOVALUE;
    }

    /** error.e:328			screen_output(STDERR, GetMsgText(PRESS_ENTER, 0))*/
    RefDS(_22190);
    _25630 = _39GetMsgText(208, 0, _22190);
    _50screen_output(2, _25630);
    _25630 = NOVALUE;

    /** error.e:329			getc(0)*/
    if (0 != last_r_file_no) {
        last_r_file_ptr = which_file(0, EF_READ);
        last_r_file_no = 0;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _25631 = getKBchar();
        }
        else{
            _25631 = getc(last_r_file_ptr);
        }
    }
    else{
        _25631 = getc(last_r_file_ptr);
    }
L4: 

    /** error.e:333		machine_proc(67, GetMsgText(FAILED_DUE_TO_INTERNAL_ERROR))*/
    RefDS(_22190);
    _25632 = _39GetMsgText(213, 1, _22190);
    machine(67, _25632);
    DeRef(_25632);
    _25632 = NOVALUE;

    /** error.e:334	end procedure*/
    DeRef(_args_49913);
    DeRef(_msg_49914);
    DeRef(_25627);
    _25627 = NOVALUE;
    return;
    ;
}



// 0x8C82CB16
