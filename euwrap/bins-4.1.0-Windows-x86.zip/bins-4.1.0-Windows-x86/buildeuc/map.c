// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _29map(object _m_12256)
{
    object _6868 = NOVALUE;
    object _6867 = NOVALUE;
    object _6866 = NOVALUE;
    object _6864 = NOVALUE;
    object _6863 = NOVALUE;
    object _6862 = NOVALUE;
    object _6860 = NOVALUE;
    object _6859 = NOVALUE;
    object _6858 = NOVALUE;
    object _6856 = NOVALUE;
    object _6855 = NOVALUE;
    object _6852 = NOVALUE;
    object _6850 = NOVALUE;
    object _0, _1, _2;
    

    /** map.e:126		if not atom( m ) then*/
    _6850 = IS_ATOM(_m_12256);
    if (_6850 != 0)
    goto L1; // [6] 16
    _6850 = NOVALUE;

    /** map.e:127			return 0*/
    DeRef(_m_12256);
    return 0;
L1: 

    /** map.e:129		if length( eumem:ram_space ) < m then*/
    if (IS_SEQUENCE(_30ram_space_11346)){
            _6852 = SEQ_PTR(_30ram_space_11346)->length;
    }
    else {
        _6852 = 1;
    }
    if (binary_op_a(GREATEREQ, _6852, _m_12256)){
        _6852 = NOVALUE;
        goto L2; // [23] 34
    }
    _6852 = NOVALUE;

    /** map.e:130			return 0*/
    DeRef(_m_12256);
    return 0;
L2: 

    /** map.e:132		if m < 1 then*/
    if (binary_op_a(GREATEREQ, _m_12256, 1)){
        goto L3; // [36] 47
    }

    /** map.e:133			return 0*/
    DeRef(_m_12256);
    return 0;
L3: 

    /** map.e:135		if length( eumem:ram_space[m] ) != MAP_MAX then*/
    _2 = (object)SEQ_PTR(_30ram_space_11346);
    if (!IS_ATOM_INT(_m_12256)){
        _6855 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_m_12256)->dbl));
    }
    else{
        _6855 = (object)*(((s1_ptr)_2)->base + _m_12256);
    }
    if (IS_SEQUENCE(_6855)){
            _6856 = SEQ_PTR(_6855)->length;
    }
    else {
        _6856 = 1;
    }
    _6855 = NOVALUE;
    if (_6856 == 3)
    goto L4; // [58] 69

    /** map.e:136			return 0*/
    DeRef(_m_12256);
    _6855 = NOVALUE;
    return 0;
L4: 

    /** map.e:138		if not atom( eumem:ram_space[m][MAP_SIZE] ) then*/
    _2 = (object)SEQ_PTR(_30ram_space_11346);
    if (!IS_ATOM_INT(_m_12256)){
        _6858 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_m_12256)->dbl));
    }
    else{
        _6858 = (object)*(((s1_ptr)_2)->base + _m_12256);
    }
    _2 = (object)SEQ_PTR(_6858);
    _6859 = (object)*(((s1_ptr)_2)->base + 1);
    _6858 = NOVALUE;
    _6860 = IS_ATOM(_6859);
    _6859 = NOVALUE;
    if (_6860 != 0)
    goto L5; // [84] 94
    _6860 = NOVALUE;

    /** map.e:139			return 0*/
    DeRef(_m_12256);
    _6855 = NOVALUE;
    return 0;
L5: 

    /** map.e:141		if not sequence( eumem:ram_space[m][MAP_SLOTS] ) then*/
    _2 = (object)SEQ_PTR(_30ram_space_11346);
    if (!IS_ATOM_INT(_m_12256)){
        _6862 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_m_12256)->dbl));
    }
    else{
        _6862 = (object)*(((s1_ptr)_2)->base + _m_12256);
    }
    _2 = (object)SEQ_PTR(_6862);
    _6863 = (object)*(((s1_ptr)_2)->base + 2);
    _6862 = NOVALUE;
    _6864 = IS_SEQUENCE(_6863);
    _6863 = NOVALUE;
    if (_6864 != 0)
    goto L6; // [109] 119
    _6864 = NOVALUE;

    /** map.e:142			return 0*/
    DeRef(_m_12256);
    _6855 = NOVALUE;
    return 0;
L6: 

    /** map.e:144		if not atom( eumem:ram_space[m][MAP_MAX] ) then*/
    _2 = (object)SEQ_PTR(_30ram_space_11346);
    if (!IS_ATOM_INT(_m_12256)){
        _6866 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_m_12256)->dbl));
    }
    else{
        _6866 = (object)*(((s1_ptr)_2)->base + _m_12256);
    }
    _2 = (object)SEQ_PTR(_6866);
    _6867 = (object)*(((s1_ptr)_2)->base + 3);
    _6866 = NOVALUE;
    _6868 = IS_ATOM(_6867);
    _6867 = NOVALUE;
    if (_6868 != 0)
    goto L7; // [134] 144
    _6868 = NOVALUE;

    /** map.e:145			return 0*/
    DeRef(_m_12256);
    _6855 = NOVALUE;
    return 0;
L7: 

    /** map.e:147		return 1*/
    DeRef(_m_12256);
    _6855 = NOVALUE;
    return 1;
    ;
}


object _29new_map_seq(object _size_12287)
{
    object _slots_12288 = NOVALUE;
    object _6879 = NOVALUE;
    object _6878 = NOVALUE;
    object _6877 = NOVALUE;
    object _6876 = NOVALUE;
    object _6872 = NOVALUE;
    object _0, _1, _2;
    

    /** map.e:155		integer slots = DEFAULT_SIZE * 2*/
    _slots_12288 = 16;

    /** map.e:156		if size <= DEFAULT_SIZE then*/
    if (_size_12287 > 8)
    goto L1; // [11] 23

    /** map.e:157			size = DEFAULT_SIZE*/
    _size_12287 = 8;
    goto L2; // [20] 55
L1: 

    /** map.e:159			size = floor( size * 1.5 )*/
    _6872 = NewDouble((eudouble)_size_12287 * DBL_PTR(_3055)->dbl);
    _size_12287 = unary_op(FLOOR, _6872);
    DeRefDS(_6872);
    _6872 = NOVALUE;
    if (!IS_ATOM_INT(_size_12287)) {
        _1 = (object)(DBL_PTR(_size_12287)->dbl);
        DeRefDS(_size_12287);
        _size_12287 = _1;
    }

    /** map.e:160			while slots < size do*/
L3: 
    if (_slots_12288 >= _size_12287)
    goto L4; // [39] 54

    /** map.e:162				slots *= 2*/
    _slots_12288 = _slots_12288 + _slots_12288;

    /** map.e:163			end while*/
    goto L3; // [51] 39
L4: 
L2: 

    /** map.e:165		return { 0, repeat( EMPTY_SLOT, slots ), floor( size * 2/3 ) }*/
    _6876 = Repeat(_29EMPTY_SLOT_12244, _slots_12288);
    _6877 = _size_12287 + _size_12287;
    if ((object)((uintptr_t)_6877 + (uintptr_t)HIGH_BITS) >= 0){
        _6877 = NewDouble((eudouble)_6877);
    }
    if (IS_ATOM_INT(_6877)) {
        if (3 > 0 && _6877 >= 0) {
            _6878 = _6877 / 3;
        }
        else {
            temp_dbl = EUFLOOR((eudouble)_6877 / (eudouble)3);
            if (_6877 != MININT)
            _6878 = (object)temp_dbl;
            else
            _6878 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _6877, 3);
        _6878 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    DeRef(_6877);
    _6877 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 0;
    ((intptr_t*)_2)[2] = _6876;
    ((intptr_t*)_2)[3] = _6878;
    _6879 = MAKE_SEQ(_1);
    _6878 = NOVALUE;
    _6876 = NOVALUE;
    return _6879;
    ;
}


object _29lookup(object _key_12330, object _hashval_12331, object _slots_12333)
{
    object _mask_12334 = NOVALUE;
    object _index_12337 = NOVALUE;
    object _index_hash_12340 = NOVALUE;
    object _slot_12341 = NOVALUE;
    object _perturb_12342 = NOVALUE;
    object _this_hash_12343 = NOVALUE;
    object _this_key_12344 = NOVALUE;
    object _looks_12345 = NOVALUE;
    object _removed_slot_12346 = NOVALUE;
    object _6907 = NOVALUE;
    object _6895 = NOVALUE;
    object _6894 = NOVALUE;
    object _6893 = NOVALUE;
    object _6892 = NOVALUE;
    object _6890 = NOVALUE;
    object _6888 = NOVALUE;
    object _0, _1, _2;
    

    /** map.e:275		integer mask = length( slots ) - 1*/
    if (IS_SEQUENCE(_slots_12333)){
            _6888 = SEQ_PTR(_slots_12333)->length;
    }
    else {
        _6888 = 1;
    }
    _mask_12334 = _6888 - 1;
    _6888 = NOVALUE;

    /** map.e:276		integer index = and_bits( hashval, mask ) + 1*/
    {uintptr_t tu;
         tu = (uintptr_t)_hashval_12331 & (uintptr_t)_mask_12334;
         _6890 = MAKE_UINT(tu);
    }
    if (IS_ATOM_INT(_6890)) {
        _index_12337 = _6890 + 1;
    }
    else
    { // coercing _index_12337 to an integer 1
        _index_12337 = 1+(object)(DBL_PTR(_6890)->dbl);
        if( !IS_ATOM_INT(_index_12337) ){
            _index_12337 = (object)DBL_PTR(_index_12337)->dbl;
        }
    }
    DeRef(_6890);
    _6890 = NOVALUE;

    /** map.e:277		ifdef BITS64 then*/

    /** map.e:280			atom index_hash = index*/
    DeRef(_index_hash_12340);
    _index_hash_12340 = _index_12337;

    /** map.e:282		sequence slot*/

    /** map.e:284		integer perturb = hashval*/
    _perturb_12342 = _hashval_12331;

    /** map.e:285		integer this_hash*/

    /** map.e:286		object this_key*/

    /** map.e:287		integer looks = 0*/
    _looks_12345 = 0;

    /** map.e:288		integer removed_slot = 0*/
    _removed_slot_12346 = 0;

    /** map.e:289		while this_hash != hashval or not equal( this_key, key ) with entry do*/
    goto L1; // [54] 140
L2: 
    _6892 = (_this_hash_12343 != _hashval_12331);
    if (_6892 != 0) {
        DeRef(_6893);
        _6893 = 1;
        goto L3; // [63] 80
    }
    if (_this_key_12344 == _key_12330)
    _6894 = 1;
    else if (IS_ATOM_INT(_this_key_12344) && IS_ATOM_INT(_key_12330))
    _6894 = 0;
    else
    _6894 = (compare(_this_key_12344, _key_12330) == 0);
    _6895 = (_6894 == 0);
    _6894 = NOVALUE;
    _6893 = (_6895 != 0);
L3: 
    if (_6893 == 0)
    {
        _6893 = NOVALUE;
        goto L4; // [80] 217
    }
    else{
        _6893 = NOVALUE;
    }

    /** map.e:290			index_hash *= 4*/
    _0 = _index_hash_12340;
    if (IS_ATOM_INT(_index_hash_12340)) {
        if (_index_hash_12340 == (short)_index_hash_12340){
            _index_hash_12340 = _index_hash_12340 * 4;
        }
        else{
            _index_hash_12340 = NewDouble(_index_hash_12340 * (eudouble)4);
        }
    }
    else {
        _index_hash_12340 = NewDouble(DBL_PTR(_index_hash_12340)->dbl * (eudouble)4);
    }
    DeRef(_0);

    /** map.e:291			index_hash += index*/
    _0 = _index_hash_12340;
    if (IS_ATOM_INT(_index_hash_12340)) {
        _index_hash_12340 = _index_hash_12340 + _index_12337;
        if ((object)((uintptr_t)_index_hash_12340 + (uintptr_t)HIGH_BITS) >= 0){
            _index_hash_12340 = NewDouble((eudouble)_index_hash_12340);
        }
    }
    else {
        _index_hash_12340 = NewDouble(DBL_PTR(_index_hash_12340)->dbl + (eudouble)_index_12337);
    }
    DeRef(_0);

    /** map.e:292			index_hash += perturb*/
    _0 = _index_hash_12340;
    if (IS_ATOM_INT(_index_hash_12340)) {
        _index_hash_12340 = _index_hash_12340 + _perturb_12342;
        if ((object)((uintptr_t)_index_hash_12340 + (uintptr_t)HIGH_BITS) >= 0){
            _index_hash_12340 = NewDouble((eudouble)_index_hash_12340);
        }
    }
    else {
        _index_hash_12340 = NewDouble(DBL_PTR(_index_hash_12340)->dbl + (eudouble)_perturb_12342);
    }
    DeRef(_0);

    /** map.e:293			index_hash += 1*/
    _0 = _index_hash_12340;
    if (IS_ATOM_INT(_index_hash_12340)) {
        _index_hash_12340 = _index_hash_12340 + 1;
        if (_index_hash_12340 > MAXINT){
            _index_hash_12340 = NewDouble((eudouble)_index_hash_12340);
        }
    }
    else
    _index_hash_12340 = binary_op(PLUS, 1, _index_hash_12340);
    DeRef(_0);

    /** map.e:294			index_hash = and_bits( 0xffff_ffff, index_hash )*/
    _0 = _index_hash_12340;
    if (IS_ATOM_INT(_index_hash_12340)) {
        temp_d.dbl = (eudouble)_index_hash_12340;
        _index_hash_12340 = Dand_bits(DBL_PTR(_385), &temp_d);
    }
    else
    _index_hash_12340 = Dand_bits(DBL_PTR(_385), DBL_PTR(_index_hash_12340));
    DeRef(_0);

    /** map.e:295			index = and_bits( mask, index_hash )*/
    if (IS_ATOM_INT(_index_hash_12340)) {
        {uintptr_t tu;
             tu = (uintptr_t)_mask_12334 & (uintptr_t)_index_hash_12340;
             _index_12337 = MAKE_UINT(tu);
        }
    }
    else {
        temp_d.dbl = (eudouble)_mask_12334;
        _index_12337 = Dand_bits(&temp_d, DBL_PTR(_index_hash_12340));
    }
    if (!IS_ATOM_INT(_index_12337)) {
        _1 = (object)(DBL_PTR(_index_12337)->dbl);
        DeRefDS(_index_12337);
        _index_12337 = _1;
    }

    /** map.e:296			index += 1*/
    _index_12337 = _index_12337 + 1;

    /** map.e:297			perturb = floor( perturb / 32 )*/
    if (32 > 0 && _perturb_12342 >= 0) {
        _perturb_12342 = _perturb_12342 / 32;
    }
    else {
        temp_dbl = EUFLOOR((eudouble)_perturb_12342 / (eudouble)32);
        _perturb_12342 = (object)temp_dbl;
    }

    /** map.e:298		entry*/
L1: 

    /** map.e:299			slot = slots[index]*/
    DeRef(_slot_12341);
    _2 = (object)SEQ_PTR(_slots_12333);
    _slot_12341 = (object)*(((s1_ptr)_2)->base + _index_12337);
    Ref(_slot_12341);

    /** map.e:300			this_hash = slot[SLOT_HASH]*/
    _2 = (object)SEQ_PTR(_slot_12341);
    _this_hash_12343 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_this_hash_12343))
    _this_hash_12343 = (object)DBL_PTR(_this_hash_12343)->dbl;

    /** map.e:301			if this_hash = EMPTY then*/
    if (_this_hash_12343 != -2)
    goto L5; // [156] 169

    /** map.e:302				return index*/
    DeRef(_key_12330);
    DeRefDS(_slots_12333);
    DeRef(_index_hash_12340);
    DeRefDS(_slot_12341);
    DeRef(_this_key_12344);
    DeRef(_6892);
    _6892 = NOVALUE;
    DeRef(_6895);
    _6895 = NOVALUE;
    return _index_12337;
    goto L6; // [166] 200
L5: 

    /** map.e:303			elsif looks > length( slots ) then*/
    if (IS_SEQUENCE(_slots_12333)){
            _6907 = SEQ_PTR(_slots_12333)->length;
    }
    else {
        _6907 = 1;
    }
    if (_looks_12345 <= _6907)
    goto L7; // [174] 187

    /** map.e:304				return removed_slot*/
    DeRef(_key_12330);
    DeRefDS(_slots_12333);
    DeRef(_index_hash_12340);
    DeRef(_slot_12341);
    DeRef(_this_key_12344);
    DeRef(_6892);
    _6892 = NOVALUE;
    DeRef(_6895);
    _6895 = NOVALUE;
    return _removed_slot_12346;
    goto L6; // [184] 200
L7: 

    /** map.e:305			elsif this_hash = REMOVED then*/
    if (_this_hash_12343 != -1)
    goto L8; // [189] 199

    /** map.e:306				removed_slot = index*/
    _removed_slot_12346 = _index_12337;
L8: 
L6: 

    /** map.e:308			this_key = slot[SLOT_KEY]*/
    DeRef(_this_key_12344);
    _2 = (object)SEQ_PTR(_slot_12341);
    _this_key_12344 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_this_key_12344);

    /** map.e:309			looks += 1*/
    _looks_12345 = _looks_12345 + 1;

    /** map.e:310		end while*/
    goto L2; // [214] 57
L4: 

    /** map.e:311		return index*/
    DeRef(_key_12330);
    DeRefDS(_slots_12333);
    DeRef(_index_hash_12340);
    DeRef(_slot_12341);
    DeRef(_this_key_12344);
    DeRef(_6892);
    _6892 = NOVALUE;
    DeRef(_6895);
    _6895 = NOVALUE;
    return _index_12337;
    ;
}


object _29rehash_seq(object _old_map_12373, object _size_12374)
{
    object _old_size_12375 = NOVALUE;
    object _index_12377 = NOVALUE;
    object _new_map_12390 = NOVALUE;
    object _slots_12392 = NOVALUE;
    object _old_slots_12395 = NOVALUE;
    object _old_slot_12400 = NOVALUE;
    object _old_hash_12402 = NOVALUE;
    object _6928 = NOVALUE;
    object _6924 = NOVALUE;
    object _6922 = NOVALUE;
    object _0, _1, _2;
    

    /** map.e:316		integer old_size = old_map[MAP_SIZE]*/
    _2 = (object)SEQ_PTR(_old_map_12373);
    _old_size_12375 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_old_size_12375))
    _old_size_12375 = (object)DBL_PTR(_old_size_12375)->dbl;

    /** map.e:319		if size = 0 then*/

    /** map.e:320			if old_size > 50_000 then*/
    if (_old_size_12375 <= 50000)
    goto L1; // [19] 32

    /** map.e:321				size = old_size * 2*/
    _size_12374 = _old_size_12375 + _old_size_12375;
    goto L2; // [29] 69
L1: 

    /** map.e:323				size = old_size * 4*/
    _size_12374 = _old_size_12375 * 4;
    goto L2; // [41] 69

    /** map.e:325		elsif size < old_size then*/
    if (_size_12374 >= _old_size_12375)
    goto L3; // [46] 68

    /** map.e:326			size = old_size*/
    _size_12374 = _old_size_12375;

    /** map.e:327			if size < DEFAULT_SIZE then*/
    if (_size_12374 >= 8)
    goto L4; // [57] 67

    /** map.e:328				size = DEFAULT_SIZE*/
    _size_12374 = 8;
L4: 
L3: 
L2: 

    /** map.e:332		sequence new_map = new_map_seq( size )*/
    _0 = _new_map_12390;
    _new_map_12390 = _29new_map_seq(_size_12374);
    DeRef(_0);

    /** map.e:333		sequence slots = new_map[MAP_SLOTS]*/
    DeRef(_slots_12392);
    _2 = (object)SEQ_PTR(_new_map_12390);
    _slots_12392 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_slots_12392);

    /** map.e:334		new_map[MAP_SLOTS] = 0*/
    _2 = (object)SEQ_PTR(_new_map_12390);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_map_12390 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);

    /** map.e:335		new_map[MAP_SIZE] = old_map[MAP_SIZE]*/
    _2 = (object)SEQ_PTR(_old_map_12373);
    _6922 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_6922);
    _2 = (object)SEQ_PTR(_new_map_12390);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_map_12390 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _6922;
    if( _1 != _6922 ){
        DeRef(_1);
    }
    _6922 = NOVALUE;

    /** map.e:337		sequence old_slots = old_map[MAP_SLOTS]*/
    DeRef(_old_slots_12395);
    _2 = (object)SEQ_PTR(_old_map_12373);
    _old_slots_12395 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_old_slots_12395);

    /** map.e:338		for i = 1 to length( old_slots ) do*/
    if (IS_SEQUENCE(_old_slots_12395)){
            _6924 = SEQ_PTR(_old_slots_12395)->length;
    }
    else {
        _6924 = 1;
    }
    {
        object _i_12398;
        _i_12398 = 1;
L5: 
        if (_i_12398 > _6924){
            goto L6; // [114] 171
        }

        /** map.e:339			sequence old_slot = old_slots[i]*/
        DeRef(_old_slot_12400);
        _2 = (object)SEQ_PTR(_old_slots_12395);
        _old_slot_12400 = (object)*(((s1_ptr)_2)->base + _i_12398);
        Ref(_old_slot_12400);

        /** map.e:340			integer old_hash = old_slot[SLOT_HASH]*/
        _2 = (object)SEQ_PTR(_old_slot_12400);
        _old_hash_12402 = (object)*(((s1_ptr)_2)->base + 1);
        if (!IS_ATOM_INT(_old_hash_12402))
        _old_hash_12402 = (object)DBL_PTR(_old_hash_12402)->dbl;

        /** map.e:341			if old_hash != -1 then*/
        if (_old_hash_12402 == -1)
        goto L7; // [137] 162

        /** map.e:342				index = lookup( old_slot[SLOT_KEY], old_hash, slots )*/
        _2 = (object)SEQ_PTR(_old_slot_12400);
        _6928 = (object)*(((s1_ptr)_2)->base + 2);
        Ref(_6928);
        RefDS(_slots_12392);
        _index_12377 = _29lookup(_6928, _old_hash_12402, _slots_12392);
        _6928 = NOVALUE;
        if (!IS_ATOM_INT(_index_12377)) {
            _1 = (object)(DBL_PTR(_index_12377)->dbl);
            DeRefDS(_index_12377);
            _index_12377 = _1;
        }

        /** map.e:343				slots[index] = old_slot*/
        RefDS(_old_slot_12400);
        _2 = (object)SEQ_PTR(_slots_12392);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _slots_12392 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _index_12377);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _old_slot_12400;
        DeRef(_1);
L7: 
        DeRef(_old_slot_12400);
        _old_slot_12400 = NOVALUE;

        /** map.e:345		end for*/
        _i_12398 = _i_12398 + 1;
        goto L5; // [166] 121
L6: 
        ;
    }

    /** map.e:346		new_map[MAP_SLOTS] = slots*/
    RefDS(_slots_12392);
    _2 = (object)SEQ_PTR(_new_map_12390);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_map_12390 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _slots_12392;
    DeRef(_1);

    /** map.e:347		return new_map*/
    DeRefDS(_old_map_12373);
    DeRefDS(_slots_12392);
    DeRef(_old_slots_12395);
    return _new_map_12390;
    ;
}


object _29new_extra(object _the_map_p_12410, object _initial_size_p_12411)
{
    object _new_1__tmp_at22_12417 = NOVALUE;
    object _new_inlined_new_at_22_12416 = NOVALUE;
    object _6930 = NOVALUE;
    object _0, _1, _2;
    

    /** map.e:376		if map(the_map_p) then*/
    Ref(_the_map_p_12410);
    _6930 = _29map(_the_map_p_12410);
    if (_6930 == 0) {
        DeRef(_6930);
        _6930 = NOVALUE;
        goto L1; // [9] 21
    }
    else {
        if (!IS_ATOM_INT(_6930) && DBL_PTR(_6930)->dbl == 0.0){
            DeRef(_6930);
            _6930 = NOVALUE;
            goto L1; // [9] 21
        }
        DeRef(_6930);
        _6930 = NOVALUE;
    }
    DeRef(_6930);
    _6930 = NOVALUE;

    /** map.e:377			return the_map_p*/
    return _the_map_p_12410;
    goto L2; // [18] 42
L1: 

    /** map.e:379			return new(initial_size_p)*/

    /** map.e:271		return eumem:malloc( new_map_seq( initial_size_p ) )*/
    _0 = _new_1__tmp_at22_12417;
    _new_1__tmp_at22_12417 = _29new_map_seq(_initial_size_p_12411);
    DeRef(_0);
    Ref(_new_1__tmp_at22_12417);
    _0 = _new_inlined_new_at_22_12416;
    _new_inlined_new_at_22_12416 = _30malloc(_new_1__tmp_at22_12417, 1);
    DeRef(_0);
    DeRef(_new_1__tmp_at22_12417);
    _new_1__tmp_at22_12417 = NOVALUE;
    DeRef(_the_map_p_12410);
    return _new_inlined_new_at_22_12416;
L2: 
    ;
}


object _29has(object _the_map_p_12452, object _key_12453)
{
    object _hashval_12454 = NOVALUE;
    object _hash_inlined_hash_at_2_12456 = NOVALUE;
    object _slots_12457 = NOVALUE;
    object _index_12460 = NOVALUE;
    object _6950 = NOVALUE;
    object _6949 = NOVALUE;
    object _6948 = NOVALUE;
    object _6945 = NOVALUE;
    object _0, _1, _2;
    

    /** map.e:464		integer hashval = hash( key )*/

    /** map.e:107		return eu:hash( x, DEFAULT_HASH )*/
    _hashval_12454 = calc_hash(_key_12453, -6);

    /** map.e:465		sequence slots = eumem:ram_space[the_map_p][MAP_SLOTS]*/
    _2 = (object)SEQ_PTR(_30ram_space_11346);
    if (!IS_ATOM_INT(_the_map_p_12452)){
        _6945 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_the_map_p_12452)->dbl));
    }
    else{
        _6945 = (object)*(((s1_ptr)_2)->base + _the_map_p_12452);
    }
    DeRef(_slots_12457);
    _2 = (object)SEQ_PTR(_6945);
    _slots_12457 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_slots_12457);
    _6945 = NOVALUE;

    /** map.e:466		integer index = lookup( key, hashval, slots )*/
    Ref(_key_12453);
    RefDS(_slots_12457);
    _index_12460 = _29lookup(_key_12453, _hashval_12454, _slots_12457);
    if (!IS_ATOM_INT(_index_12460)) {
        _1 = (object)(DBL_PTR(_index_12460)->dbl);
        DeRefDS(_index_12460);
        _index_12460 = _1;
    }

    /** map.e:468		return hashval = slots[index][SLOT_HASH]*/
    _2 = (object)SEQ_PTR(_slots_12457);
    _6948 = (object)*(((s1_ptr)_2)->base + _index_12460);
    _2 = (object)SEQ_PTR(_6948);
    _6949 = (object)*(((s1_ptr)_2)->base + 1);
    _6948 = NOVALUE;
    if (IS_ATOM_INT(_6949)) {
        _6950 = (_hashval_12454 == _6949);
    }
    else {
        _6950 = binary_op(EQUALS, _hashval_12454, _6949);
    }
    _6949 = NOVALUE;
    DeRef(_the_map_p_12452);
    DeRef(_key_12453);
    DeRefDS(_slots_12457);
    return _6950;
    ;
}


object _29get(object _the_map_p_12467, object _key_12468, object _default_12469)
{
    object _hashval_12470 = NOVALUE;
    object _hash_inlined_hash_at_2_12472 = NOVALUE;
    object _slots_12473 = NOVALUE;
    object _index_12476 = NOVALUE;
    object _slot_12478 = NOVALUE;
    object _6957 = NOVALUE;
    object _6955 = NOVALUE;
    object _6951 = NOVALUE;
    object _0, _1, _2;
    

    /** map.e:505		integer hashval = hash( key )*/

    /** map.e:107		return eu:hash( x, DEFAULT_HASH )*/
    _hashval_12470 = calc_hash(_key_12468, -6);

    /** map.e:506		sequence slots = eumem:ram_space[the_map_p][MAP_SLOTS]*/
    _2 = (object)SEQ_PTR(_30ram_space_11346);
    if (!IS_ATOM_INT(_the_map_p_12467)){
        _6951 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_the_map_p_12467)->dbl));
    }
    else{
        _6951 = (object)*(((s1_ptr)_2)->base + _the_map_p_12467);
    }
    DeRef(_slots_12473);
    _2 = (object)SEQ_PTR(_6951);
    _slots_12473 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_slots_12473);
    _6951 = NOVALUE;

    /** map.e:507		integer index = lookup( key, hashval, slots )*/
    Ref(_key_12468);
    RefDS(_slots_12473);
    _index_12476 = _29lookup(_key_12468, _hashval_12470, _slots_12473);
    if (!IS_ATOM_INT(_index_12476)) {
        _1 = (object)(DBL_PTR(_index_12476)->dbl);
        DeRefDS(_index_12476);
        _index_12476 = _1;
    }

    /** map.e:508		sequence slot = slots[index]*/
    DeRef(_slot_12478);
    _2 = (object)SEQ_PTR(_slots_12473);
    _slot_12478 = (object)*(((s1_ptr)_2)->base + _index_12476);
    Ref(_slot_12478);

    /** map.e:509		if hashval = slot[SLOT_HASH] then*/
    _2 = (object)SEQ_PTR(_slot_12478);
    _6955 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _hashval_12470, _6955)){
        _6955 = NOVALUE;
        goto L1; // [50] 65
    }
    _6955 = NOVALUE;

    /** map.e:510			return slot[SLOT_VALUE]*/
    _2 = (object)SEQ_PTR(_slot_12478);
    _6957 = (object)*(((s1_ptr)_2)->base + 3);
    Ref(_6957);
    DeRef(_the_map_p_12467);
    DeRef(_key_12468);
    DeRef(_default_12469);
    DeRefDS(_slots_12473);
    DeRefDS(_slot_12478);
    return _6957;
L1: 

    /** map.e:512		return default*/
    DeRef(_the_map_p_12467);
    DeRef(_key_12468);
    DeRef(_slots_12473);
    DeRef(_slot_12478);
    _6957 = NOVALUE;
    return _default_12469;
    ;
}


void _29put(object _the_map_p_12506, object _key_12507, object _val_12508, object _op_12509, object _deprecated_12510)
{
    object _hashval_12511 = NOVALUE;
    object _hash_inlined_hash_at_2_12513 = NOVALUE;
    object _the_map_seq_12514 = NOVALUE;
    object _slots_12516 = NOVALUE;
    object _index_12518 = NOVALUE;
    object _old_hash_12520 = NOVALUE;
    object _msg_inlined_crash_at_288_12563 = NOVALUE;
    object _msg_inlined_crash_at_348_12573 = NOVALUE;
    object _msg_inlined_crash_at_535_12605 = NOVALUE;
    object _7024 = NOVALUE;
    object _7022 = NOVALUE;
    object _7021 = NOVALUE;
    object _7020 = NOVALUE;
    object _7019 = NOVALUE;
    object _7018 = NOVALUE;
    object _7016 = NOVALUE;
    object _7015 = NOVALUE;
    object _7014 = NOVALUE;
    object _7013 = NOVALUE;
    object _7012 = NOVALUE;
    object _7011 = NOVALUE;
    object _7009 = NOVALUE;
    object _7008 = NOVALUE;
    object _7007 = NOVALUE;
    object _7006 = NOVALUE;
    object _7004 = NOVALUE;
    object _7003 = NOVALUE;
    object _7002 = NOVALUE;
    object _7001 = NOVALUE;
    object _6998 = NOVALUE;
    object _6997 = NOVALUE;
    object _6996 = NOVALUE;
    object _6995 = NOVALUE;
    object _6994 = NOVALUE;
    object _6992 = NOVALUE;
    object _6991 = NOVALUE;
    object _6990 = NOVALUE;
    object _6989 = NOVALUE;
    object _6988 = NOVALUE;
    object _6986 = NOVALUE;
    object _6983 = NOVALUE;
    object _6982 = NOVALUE;
    object _6980 = NOVALUE;
    object _6975 = NOVALUE;
    object _6974 = NOVALUE;
    object _6971 = NOVALUE;
    object _0, _1, _2;
    

    /** map.e:579		integer hashval = hash( key )*/

    /** map.e:107		return eu:hash( x, DEFAULT_HASH )*/
    _hashval_12511 = calc_hash(_key_12507, -6);

    /** map.e:580		sequence the_map_seq = eumem:ram_space[the_map_p]*/
    DeRef(_the_map_seq_12514);
    _2 = (object)SEQ_PTR(_30ram_space_11346);
    if (!IS_ATOM_INT(_the_map_p_12506)){
        _the_map_seq_12514 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_the_map_p_12506)->dbl));
    }
    else{
        _the_map_seq_12514 = (object)*(((s1_ptr)_2)->base + _the_map_p_12506);
    }
    Ref(_the_map_seq_12514);

    /** map.e:581		eumem:ram_space[the_map_p] = 0*/
    _2 = (object)SEQ_PTR(_30ram_space_11346);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _30ram_space_11346 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_the_map_p_12506))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_the_map_p_12506)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _the_map_p_12506);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);

    /** map.e:582		sequence slots = the_map_seq[MAP_SLOTS]*/
    DeRef(_slots_12516);
    _2 = (object)SEQ_PTR(_the_map_seq_12514);
    _slots_12516 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_slots_12516);

    /** map.e:584		integer index = lookup( key, hashval, slots )*/
    Ref(_key_12507);
    RefDS(_slots_12516);
    _index_12518 = _29lookup(_key_12507, _hashval_12511, _slots_12516);
    if (!IS_ATOM_INT(_index_12518)) {
        _1 = (object)(DBL_PTR(_index_12518)->dbl);
        DeRefDS(_index_12518);
        _index_12518 = _1;
    }

    /** map.e:585		integer old_hash = slots[index][SLOT_HASH]*/
    _2 = (object)SEQ_PTR(_slots_12516);
    _6971 = (object)*(((s1_ptr)_2)->base + _index_12518);
    _2 = (object)SEQ_PTR(_6971);
    _old_hash_12520 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_old_hash_12520)){
        _old_hash_12520 = (object)DBL_PTR(_old_hash_12520)->dbl;
    }
    _6971 = NOVALUE;

    /** map.e:587		if old_hash < 0 then*/
    if (_old_hash_12520 >= 0)
    goto L1; // [62] 142

    /** map.e:589			if the_map_seq[MAP_SIZE] > the_map_seq[MAP_MAX] then*/
    _2 = (object)SEQ_PTR(_the_map_seq_12514);
    _6974 = (object)*(((s1_ptr)_2)->base + 1);
    _2 = (object)SEQ_PTR(_the_map_seq_12514);
    _6975 = (object)*(((s1_ptr)_2)->base + 3);
    if (binary_op_a(LESSEQ, _6974, _6975)){
        _6974 = NOVALUE;
        _6975 = NOVALUE;
        goto L2; // [76] 127
    }
    _6974 = NOVALUE;
    _6975 = NOVALUE;

    /** map.e:590				slots = {}*/
    RefDS(_5);
    DeRefDS(_slots_12516);
    _slots_12516 = _5;

    /** map.e:591				the_map_seq = rehash_seq( the_map_seq )*/
    RefDS(_the_map_seq_12514);
    _0 = _the_map_seq_12514;
    _the_map_seq_12514 = _29rehash_seq(_the_map_seq_12514, 0);
    DeRefDS(_0);

    /** map.e:592				slots = the_map_seq[MAP_SLOTS]*/
    DeRefDS(_slots_12516);
    _2 = (object)SEQ_PTR(_the_map_seq_12514);
    _slots_12516 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_slots_12516);

    /** map.e:593				index = lookup( key, hashval, slots )*/
    Ref(_key_12507);
    RefDS(_slots_12516);
    _index_12518 = _29lookup(_key_12507, _hashval_12511, _slots_12516);
    if (!IS_ATOM_INT(_index_12518)) {
        _1 = (object)(DBL_PTR(_index_12518)->dbl);
        DeRefDS(_index_12518);
        _index_12518 = _1;
    }

    /** map.e:594				old_hash = slots[index][SLOT_HASH]*/
    _2 = (object)SEQ_PTR(_slots_12516);
    _6980 = (object)*(((s1_ptr)_2)->base + _index_12518);
    _2 = (object)SEQ_PTR(_6980);
    _old_hash_12520 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_old_hash_12520)){
        _old_hash_12520 = (object)DBL_PTR(_old_hash_12520)->dbl;
    }
    _6980 = NOVALUE;
L2: 

    /** map.e:596			the_map_seq[MAP_SIZE] += 1*/
    _2 = (object)SEQ_PTR(_the_map_seq_12514);
    _6982 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_6982)) {
        _6983 = _6982 + 1;
        if (_6983 > MAXINT){
            _6983 = NewDouble((eudouble)_6983);
        }
    }
    else
    _6983 = binary_op(PLUS, 1, _6982);
    _6982 = NOVALUE;
    _2 = (object)SEQ_PTR(_the_map_seq_12514);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _the_map_seq_12514 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _6983;
    if( _1 != _6983 ){
        DeRef(_1);
    }
    _6983 = NOVALUE;
L1: 

    /** map.e:599		the_map_seq[MAP_SLOTS] = 0*/
    _2 = (object)SEQ_PTR(_the_map_seq_12514);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _the_map_seq_12514 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);

    /** map.e:601		switch op do*/
    _0 = _op_12509;
    switch ( _0 ){ 

        /** map.e:602			case PUT then*/
        case 1:

        /** map.e:603				slots[index] = { hashval, key, val }*/
        _1 = NewS1(3);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _hashval_12511;
        Ref(_key_12507);
        ((intptr_t*)_2)[2] = _key_12507;
        Ref(_val_12508);
        ((intptr_t*)_2)[3] = _val_12508;
        _6986 = MAKE_SEQ(_1);
        _2 = (object)SEQ_PTR(_slots_12516);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _slots_12516 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _index_12518);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _6986;
        if( _1 != _6986 ){
            DeRef(_1);
        }
        _6986 = NOVALUE;
        goto L3; // [171] 555

        /** map.e:604			case ADD then*/
        case 2:

        /** map.e:605				if old_hash < 0 then*/
        if (_old_hash_12520 >= 0)
        goto L4; // [179] 198

        /** map.e:606					slots[index] = { hashval, key, val }*/
        _1 = NewS1(3);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _hashval_12511;
        Ref(_key_12507);
        ((intptr_t*)_2)[2] = _key_12507;
        Ref(_val_12508);
        ((intptr_t*)_2)[3] = _val_12508;
        _6988 = MAKE_SEQ(_1);
        _2 = (object)SEQ_PTR(_slots_12516);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _slots_12516 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _index_12518);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _6988;
        if( _1 != _6988 ){
            DeRef(_1);
        }
        _6988 = NOVALUE;
        goto L3; // [195] 555
L4: 

        /** map.e:608					slots[index] = { hashval, key, val + slots[index][SLOT_VALUE] }*/
        _2 = (object)SEQ_PTR(_slots_12516);
        _6989 = (object)*(((s1_ptr)_2)->base + _index_12518);
        _2 = (object)SEQ_PTR(_6989);
        _6990 = (object)*(((s1_ptr)_2)->base + 3);
        _6989 = NOVALUE;
        if (IS_ATOM_INT(_val_12508) && IS_ATOM_INT(_6990)) {
            _6991 = _val_12508 + _6990;
            if ((object)((uintptr_t)_6991 + (uintptr_t)HIGH_BITS) >= 0){
                _6991 = NewDouble((eudouble)_6991);
            }
        }
        else {
            _6991 = binary_op(PLUS, _val_12508, _6990);
        }
        _6990 = NOVALUE;
        _1 = NewS1(3);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _hashval_12511;
        Ref(_key_12507);
        ((intptr_t*)_2)[2] = _key_12507;
        ((intptr_t*)_2)[3] = _6991;
        _6992 = MAKE_SEQ(_1);
        _6991 = NOVALUE;
        _2 = (object)SEQ_PTR(_slots_12516);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _slots_12516 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _index_12518);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _6992;
        if( _1 != _6992 ){
            DeRef(_1);
        }
        _6992 = NOVALUE;
        goto L3; // [223] 555

        /** map.e:610			case SUBTRACT then*/
        case 3:

        /** map.e:611				if old_hash < 0 then*/
        if (_old_hash_12520 >= 0)
        goto L5; // [231] 250

        /** map.e:612					slots[index] = { hashval, key, val }*/
        _1 = NewS1(3);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _hashval_12511;
        Ref(_key_12507);
        ((intptr_t*)_2)[2] = _key_12507;
        Ref(_val_12508);
        ((intptr_t*)_2)[3] = _val_12508;
        _6994 = MAKE_SEQ(_1);
        _2 = (object)SEQ_PTR(_slots_12516);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _slots_12516 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _index_12518);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _6994;
        if( _1 != _6994 ){
            DeRef(_1);
        }
        _6994 = NOVALUE;
        goto L3; // [247] 555
L5: 

        /** map.e:614					slots[index] = { hashval, key, slots[index][SLOT_VALUE] - val }*/
        _2 = (object)SEQ_PTR(_slots_12516);
        _6995 = (object)*(((s1_ptr)_2)->base + _index_12518);
        _2 = (object)SEQ_PTR(_6995);
        _6996 = (object)*(((s1_ptr)_2)->base + 3);
        _6995 = NOVALUE;
        if (IS_ATOM_INT(_6996) && IS_ATOM_INT(_val_12508)) {
            _6997 = _6996 - _val_12508;
            if ((object)((uintptr_t)_6997 +(uintptr_t) HIGH_BITS) >= 0){
                _6997 = NewDouble((eudouble)_6997);
            }
        }
        else {
            _6997 = binary_op(MINUS, _6996, _val_12508);
        }
        _6996 = NOVALUE;
        _1 = NewS1(3);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _hashval_12511;
        Ref(_key_12507);
        ((intptr_t*)_2)[2] = _key_12507;
        ((intptr_t*)_2)[3] = _6997;
        _6998 = MAKE_SEQ(_1);
        _6997 = NOVALUE;
        _2 = (object)SEQ_PTR(_slots_12516);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _slots_12516 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _index_12518);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _6998;
        if( _1 != _6998 ){
            DeRef(_1);
        }
        _6998 = NOVALUE;
        goto L3; // [275] 555

        /** map.e:617			case MULTIPLY then*/
        case 4:

        /** map.e:618				if old_hash < 0 then*/
        if (_old_hash_12520 >= 0)
        goto L6; // [283] 310

        /** map.e:619					error:crash("Inappropriate initial operation given to map.e:put()")*/

        /** error.e:51		msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_288_12563);
        _msg_inlined_crash_at_288_12563 = EPrintf(-9999999, _7000, _5);

        /** error.e:52		machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_288_12563);

        /** error.e:53	end procedure*/
        goto L7; // [302] 305
L7: 
        DeRefi(_msg_inlined_crash_at_288_12563);
        _msg_inlined_crash_at_288_12563 = NOVALUE;
        goto L3; // [307] 555
L6: 

        /** map.e:621					slots[index] = { hashval, key, val * slots[index][SLOT_VALUE] }*/
        _2 = (object)SEQ_PTR(_slots_12516);
        _7001 = (object)*(((s1_ptr)_2)->base + _index_12518);
        _2 = (object)SEQ_PTR(_7001);
        _7002 = (object)*(((s1_ptr)_2)->base + 3);
        _7001 = NOVALUE;
        if (IS_ATOM_INT(_val_12508) && IS_ATOM_INT(_7002)) {
            if (_val_12508 == (short)_val_12508 && _7002 <= INT15 && _7002 >= -INT15){
                _7003 = _val_12508 * _7002;
            }
            else{
                _7003 = NewDouble(_val_12508 * (eudouble)_7002);
            }
        }
        else {
            _7003 = binary_op(MULTIPLY, _val_12508, _7002);
        }
        _7002 = NOVALUE;
        _1 = NewS1(3);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _hashval_12511;
        Ref(_key_12507);
        ((intptr_t*)_2)[2] = _key_12507;
        ((intptr_t*)_2)[3] = _7003;
        _7004 = MAKE_SEQ(_1);
        _7003 = NOVALUE;
        _2 = (object)SEQ_PTR(_slots_12516);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _slots_12516 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _index_12518);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _7004;
        if( _1 != _7004 ){
            DeRef(_1);
        }
        _7004 = NOVALUE;
        goto L3; // [335] 555

        /** map.e:624			case DIVIDE then*/
        case 5:

        /** map.e:625				if old_hash < 0 then*/
        if (_old_hash_12520 >= 0)
        goto L8; // [343] 370

        /** map.e:626					error:crash("Inappropriate initial operation given to map.e:put()")*/

        /** error.e:51		msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_348_12573);
        _msg_inlined_crash_at_348_12573 = EPrintf(-9999999, _7000, _5);

        /** error.e:52		machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_348_12573);

        /** error.e:53	end procedure*/
        goto L9; // [362] 365
L9: 
        DeRefi(_msg_inlined_crash_at_348_12573);
        _msg_inlined_crash_at_348_12573 = NOVALUE;
        goto L3; // [367] 555
L8: 

        /** map.e:628					slots[index] = { hashval, key, slots[index][SLOT_VALUE] / val }*/
        _2 = (object)SEQ_PTR(_slots_12516);
        _7006 = (object)*(((s1_ptr)_2)->base + _index_12518);
        _2 = (object)SEQ_PTR(_7006);
        _7007 = (object)*(((s1_ptr)_2)->base + 3);
        _7006 = NOVALUE;
        if (IS_ATOM_INT(_7007) && IS_ATOM_INT(_val_12508)) {
            _7008 = (_7007 % _val_12508) ? NewDouble((eudouble)_7007 / _val_12508) : (_7007 / _val_12508);
        }
        else {
            _7008 = binary_op(DIVIDE, _7007, _val_12508);
        }
        _7007 = NOVALUE;
        _1 = NewS1(3);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _hashval_12511;
        Ref(_key_12507);
        ((intptr_t*)_2)[2] = _key_12507;
        ((intptr_t*)_2)[3] = _7008;
        _7009 = MAKE_SEQ(_1);
        _7008 = NOVALUE;
        _2 = (object)SEQ_PTR(_slots_12516);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _slots_12516 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _index_12518);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _7009;
        if( _1 != _7009 ){
            DeRef(_1);
        }
        _7009 = NOVALUE;
        goto L3; // [395] 555

        /** map.e:631			case APPEND then*/
        case 6:

        /** map.e:632				if old_hash < 0 then*/
        if (_old_hash_12520 >= 0)
        goto LA; // [403] 426

        /** map.e:633					slots[index] = { hashval, key, {val} }*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        Ref(_val_12508);
        ((intptr_t*)_2)[1] = _val_12508;
        _7011 = MAKE_SEQ(_1);
        _1 = NewS1(3);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _hashval_12511;
        Ref(_key_12507);
        ((intptr_t*)_2)[2] = _key_12507;
        ((intptr_t*)_2)[3] = _7011;
        _7012 = MAKE_SEQ(_1);
        _7011 = NOVALUE;
        _2 = (object)SEQ_PTR(_slots_12516);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _slots_12516 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _index_12518);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _7012;
        if( _1 != _7012 ){
            DeRef(_1);
        }
        _7012 = NOVALUE;
        goto L3; // [423] 555
LA: 

        /** map.e:635					slots[index] = { hashval, key, append( slots[index][SLOT_VALUE], val ) }*/
        _2 = (object)SEQ_PTR(_slots_12516);
        _7013 = (object)*(((s1_ptr)_2)->base + _index_12518);
        _2 = (object)SEQ_PTR(_7013);
        _7014 = (object)*(((s1_ptr)_2)->base + 3);
        _7013 = NOVALUE;
        Ref(_val_12508);
        Append(&_7015, _7014, _val_12508);
        _7014 = NOVALUE;
        _1 = NewS1(3);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _hashval_12511;
        Ref(_key_12507);
        ((intptr_t*)_2)[2] = _key_12507;
        ((intptr_t*)_2)[3] = _7015;
        _7016 = MAKE_SEQ(_1);
        _7015 = NOVALUE;
        _2 = (object)SEQ_PTR(_slots_12516);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _slots_12516 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _index_12518);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _7016;
        if( _1 != _7016 ){
            DeRef(_1);
        }
        _7016 = NOVALUE;
        goto L3; // [451] 555

        /** map.e:638			case CONCAT then*/
        case 7:

        /** map.e:639				if old_hash < 0 then*/
        if (_old_hash_12520 >= 0)
        goto LB; // [459] 478

        /** map.e:640					slots[index] = { hashval, key, val }*/
        _1 = NewS1(3);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _hashval_12511;
        Ref(_key_12507);
        ((intptr_t*)_2)[2] = _key_12507;
        Ref(_val_12508);
        ((intptr_t*)_2)[3] = _val_12508;
        _7018 = MAKE_SEQ(_1);
        _2 = (object)SEQ_PTR(_slots_12516);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _slots_12516 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _index_12518);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _7018;
        if( _1 != _7018 ){
            DeRef(_1);
        }
        _7018 = NOVALUE;
        goto L3; // [475] 555
LB: 

        /** map.e:642					slots[index] = { hashval, key, slots[index][SLOT_VALUE] & val }*/
        _2 = (object)SEQ_PTR(_slots_12516);
        _7019 = (object)*(((s1_ptr)_2)->base + _index_12518);
        _2 = (object)SEQ_PTR(_7019);
        _7020 = (object)*(((s1_ptr)_2)->base + 3);
        _7019 = NOVALUE;
        if (IS_SEQUENCE(_7020) && IS_ATOM(_val_12508)) {
            Ref(_val_12508);
            Append(&_7021, _7020, _val_12508);
        }
        else if (IS_ATOM(_7020) && IS_SEQUENCE(_val_12508)) {
            Ref(_7020);
            Prepend(&_7021, _val_12508, _7020);
        }
        else {
            Concat((object_ptr)&_7021, _7020, _val_12508);
            _7020 = NOVALUE;
        }
        _7020 = NOVALUE;
        _1 = NewS1(3);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _hashval_12511;
        Ref(_key_12507);
        ((intptr_t*)_2)[2] = _key_12507;
        ((intptr_t*)_2)[3] = _7021;
        _7022 = MAKE_SEQ(_1);
        _7021 = NOVALUE;
        _2 = (object)SEQ_PTR(_slots_12516);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _slots_12516 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _index_12518);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _7022;
        if( _1 != _7022 ){
            DeRef(_1);
        }
        _7022 = NOVALUE;
        goto L3; // [503] 555

        /** map.e:645			case LEAVE then*/
        case 8:

        /** map.e:646				if old_hash < 0 then*/
        if (_old_hash_12520 >= 0)
        goto L3; // [511] 555

        /** map.e:647					slots[index] = { hashval, key, val }*/
        _1 = NewS1(3);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _hashval_12511;
        Ref(_key_12507);
        ((intptr_t*)_2)[2] = _key_12507;
        Ref(_val_12508);
        ((intptr_t*)_2)[3] = _val_12508;
        _7024 = MAKE_SEQ(_1);
        _2 = (object)SEQ_PTR(_slots_12516);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _slots_12516 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _index_12518);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _7024;
        if( _1 != _7024 ){
            DeRef(_1);
        }
        _7024 = NOVALUE;
        goto L3; // [528] 555

        /** map.e:649			case else*/
        default:

        /** map.e:650				error:crash("Unknown operation given to map.e:put()")*/

        /** error.e:51		msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_535_12605);
        _msg_inlined_crash_at_535_12605 = EPrintf(-9999999, _7025, _5);

        /** error.e:52		machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_535_12605);

        /** error.e:53	end procedure*/
        goto LC; // [549] 552
LC: 
        DeRefi(_msg_inlined_crash_at_535_12605);
        _msg_inlined_crash_at_535_12605 = NOVALUE;
    ;}L3: 

    /** map.e:654		the_map_seq[MAP_SLOTS] = slots*/
    RefDS(_slots_12516);
    _2 = (object)SEQ_PTR(_the_map_seq_12514);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _the_map_seq_12514 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _slots_12516;
    DeRef(_1);

    /** map.e:655		eumem:ram_space[the_map_p] = the_map_seq*/
    RefDS(_the_map_seq_12514);
    _2 = (object)SEQ_PTR(_30ram_space_11346);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _30ram_space_11346 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_the_map_p_12506))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_the_map_p_12506)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _the_map_p_12506);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _the_map_seq_12514;
    DeRef(_1);

    /** map.e:656	end procedure*/
    DeRef(_the_map_p_12506);
    DeRef(_key_12507);
    DeRef(_val_12508);
    DeRefDS(_the_map_seq_12514);
    DeRefDS(_slots_12516);
    return;
    ;
}


void _29nested_put(object _the_map_p_12608, object _the_keys_p_12609, object _the_value_p_12610, object _operation_p_12611, object _deprecated_trigger_p_12612)
{
    object _temp_map__12613 = NOVALUE;
    object _7036 = NOVALUE;
    object _7035 = NOVALUE;
    object _7034 = NOVALUE;
    object _7033 = NOVALUE;
    object _7032 = NOVALUE;
    object _7030 = NOVALUE;
    object _7029 = NOVALUE;
    object _7028 = NOVALUE;
    object _7026 = NOVALUE;
    object _0, _1, _2;
    

    /** map.e:701		if length( the_keys_p ) = 1 then*/
    if (IS_SEQUENCE(_the_keys_p_12609)){
            _7026 = SEQ_PTR(_the_keys_p_12609)->length;
    }
    else {
        _7026 = 1;
    }
    if (_7026 != 1)
    goto L1; // [10] 30

    /** map.e:702			put( the_map_p, the_keys_p[1], the_value_p, operation_p )*/
    _2 = (object)SEQ_PTR(_the_keys_p_12609);
    _7028 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_the_map_p_12608);
    Ref(_7028);
    Ref(_the_value_p_12610);
    _29put(_the_map_p_12608, _7028, _the_value_p_12610, _operation_p_12611, 0);
    _7028 = NOVALUE;
    goto L2; // [27] 84
L1: 

    /** map.e:704			temp_map_ = new_extra( get( the_map_p, the_keys_p[1] ) )*/
    _2 = (object)SEQ_PTR(_the_keys_p_12609);
    _7029 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_the_map_p_12608);
    Ref(_7029);
    _7030 = _29get(_the_map_p_12608, _7029, 0);
    _7029 = NOVALUE;
    _0 = _temp_map__12613;
    _temp_map__12613 = _29new_extra(_7030, 8);
    DeRef(_0);
    _7030 = NOVALUE;

    /** map.e:705			nested_put( temp_map_, the_keys_p[2..$], the_value_p, operation_p )*/
    if (IS_SEQUENCE(_the_keys_p_12609)){
            _7032 = SEQ_PTR(_the_keys_p_12609)->length;
    }
    else {
        _7032 = 1;
    }
    rhs_slice_target = (object_ptr)&_7033;
    RHS_Slice(_the_keys_p_12609, 2, _7032);
    Ref(_the_value_p_12610);
    DeRef(_7034);
    _7034 = _the_value_p_12610;
    DeRef(_7035);
    _7035 = _operation_p_12611;
    Ref(_temp_map__12613);
    _29nested_put(_temp_map__12613, _7033, _7034, _7035, 0);
    _7033 = NOVALUE;
    _7034 = NOVALUE;
    _7035 = NOVALUE;

    /** map.e:706			put( the_map_p, the_keys_p[1], temp_map_, PUT )*/
    _2 = (object)SEQ_PTR(_the_keys_p_12609);
    _7036 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_the_map_p_12608);
    Ref(_7036);
    Ref(_temp_map__12613);
    _29put(_the_map_p_12608, _7036, _temp_map__12613, 1, 0);
    _7036 = NOVALUE;
L2: 

    /** map.e:708	end procedure*/
    DeRef(_the_map_p_12608);
    DeRefDS(_the_keys_p_12609);
    DeRef(_the_value_p_12610);
    DeRef(_temp_map__12613);
    return;
    ;
}


void _29remove(object _the_map_p_12629, object _key_12630)
{
    object _hashval_12631 = NOVALUE;
    object _hash_inlined_hash_at_2_12633 = NOVALUE;
    object _slots_12634 = NOVALUE;
    object _index_12637 = NOVALUE;
    object _7048 = NOVALUE;
    object _7047 = NOVALUE;
    object _7045 = NOVALUE;
    object _7043 = NOVALUE;
    object _7041 = NOVALUE;
    object _7040 = NOVALUE;
    object _7037 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** map.e:733		integer hashval = hash( key )*/

    /** map.e:107		return eu:hash( x, DEFAULT_HASH )*/
    _hashval_12631 = calc_hash(_key_12630, -6);

    /** map.e:734		sequence slots = eumem:ram_space[the_map_p][MAP_SLOTS]*/
    _2 = (object)SEQ_PTR(_30ram_space_11346);
    if (!IS_ATOM_INT(_the_map_p_12629)){
        _7037 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_the_map_p_12629)->dbl));
    }
    else{
        _7037 = (object)*(((s1_ptr)_2)->base + _the_map_p_12629);
    }
    DeRef(_slots_12634);
    _2 = (object)SEQ_PTR(_7037);
    _slots_12634 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_slots_12634);
    _7037 = NOVALUE;

    /** map.e:736		integer index = lookup( key, hashval, slots )*/
    Ref(_key_12630);
    RefDS(_slots_12634);
    _index_12637 = _29lookup(_key_12630, _hashval_12631, _slots_12634);
    if (!IS_ATOM_INT(_index_12637)) {
        _1 = (object)(DBL_PTR(_index_12637)->dbl);
        DeRefDS(_index_12637);
        _index_12637 = _1;
    }

    /** map.e:737		if hashval = slots[index][SLOT_HASH] then*/
    _2 = (object)SEQ_PTR(_slots_12634);
    _7040 = (object)*(((s1_ptr)_2)->base + _index_12637);
    _2 = (object)SEQ_PTR(_7040);
    _7041 = (object)*(((s1_ptr)_2)->base + 1);
    _7040 = NOVALUE;
    if (binary_op_a(NOTEQ, _hashval_12631, _7041)){
        _7041 = NOVALUE;
        goto L1; // [46] 99
    }
    _7041 = NOVALUE;

    /** map.e:738			slots = {}*/
    RefDS(_5);
    DeRefDS(_slots_12634);
    _slots_12634 = _5;

    /** map.e:739			eumem:ram_space[the_map_p][MAP_SLOTS][index] = REMOVED_SLOT*/
    _2 = (object)SEQ_PTR(_30ram_space_11346);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _30ram_space_11346 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_the_map_p_12629))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_the_map_p_12629)->dbl));
    else
    _3 = (object)(_the_map_p_12629 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(object_ptr)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(object_ptr)_3 = MAKE_SEQ(_2);
    }
    _3 = (object)(2 + ((s1_ptr)_2)->base);
    _7043 = NOVALUE;
    RefDS(_29REMOVED_SLOT_12246);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _index_12637);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29REMOVED_SLOT_12246;
    DeRef(_1);
    _7043 = NOVALUE;

    /** map.e:740			eumem:ram_space[the_map_p][MAP_SIZE] -= 1*/
    _2 = (object)SEQ_PTR(_30ram_space_11346);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _30ram_space_11346 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_the_map_p_12629))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_the_map_p_12629)->dbl));
    else
    _3 = (object)(_the_map_p_12629 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _7047 = (object)*(((s1_ptr)_2)->base + 1);
    _7045 = NOVALUE;
    if (IS_ATOM_INT(_7047)) {
        _7048 = _7047 - 1;
        if ((object)((uintptr_t)_7048 +(uintptr_t) HIGH_BITS) >= 0){
            _7048 = NewDouble((eudouble)_7048);
        }
    }
    else {
        _7048 = binary_op(MINUS, _7047, 1);
    }
    _7047 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _7048;
    if( _1 != _7048 ){
        DeRef(_1);
    }
    _7048 = NOVALUE;
    _7045 = NOVALUE;
L1: 

    /** map.e:742	end procedure*/
    DeRef(_the_map_p_12629);
    DeRef(_key_12630);
    DeRef(_slots_12634);
    return;
    ;
}


void _29clear(object _the_map_p_12651)
{
    object _7055 = NOVALUE;
    object _7054 = NOVALUE;
    object _7053 = NOVALUE;
    object _7052 = NOVALUE;
    object _7051 = NOVALUE;
    object _7049 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** map.e:771		eumem:ram_space[the_map_p][MAP_SLOTS] = repeat( EMPTY_SLOT, length( eumem:ram_space[the_map_p][MAP_SLOTS] ) )*/
    _2 = (object)SEQ_PTR(_30ram_space_11346);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _30ram_space_11346 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_the_map_p_12651))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_the_map_p_12651)->dbl));
    else
    _3 = (object)(_the_map_p_12651 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_30ram_space_11346);
    if (!IS_ATOM_INT(_the_map_p_12651)){
        _7051 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_the_map_p_12651)->dbl));
    }
    else{
        _7051 = (object)*(((s1_ptr)_2)->base + _the_map_p_12651);
    }
    _2 = (object)SEQ_PTR(_7051);
    _7052 = (object)*(((s1_ptr)_2)->base + 2);
    _7051 = NOVALUE;
    if (IS_SEQUENCE(_7052)){
            _7053 = SEQ_PTR(_7052)->length;
    }
    else {
        _7053 = 1;
    }
    _7052 = NOVALUE;
    _7054 = Repeat(_29EMPTY_SLOT_12244, _7053);
    _7053 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _7054;
    if( _1 != _7054 ){
        DeRef(_1);
    }
    _7054 = NOVALUE;
    _7049 = NOVALUE;

    /** map.e:772		eumem:ram_space[the_map_p][MAP_SIZE]  = 0*/
    _2 = (object)SEQ_PTR(_30ram_space_11346);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _30ram_space_11346 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_the_map_p_12651))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_the_map_p_12651)->dbl));
    else
    _3 = (object)(_the_map_p_12651 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);
    _7055 = NOVALUE;

    /** map.e:773	end procedure*/
    DeRef(_the_map_p_12651);
    _7052 = NOVALUE;
    return;
    ;
}


object _29keys(object _the_map_p_12706, object _sorted_result_12707)
{
    object _slots_12708 = NOVALUE;
    object _keys_12711 = NOVALUE;
    object _kx_12715 = NOVALUE;
    object _7086 = NOVALUE;
    object _7084 = NOVALUE;
    object _7083 = NOVALUE;
    object _7082 = NOVALUE;
    object _7079 = NOVALUE;
    object _7078 = NOVALUE;
    object _7077 = NOVALUE;
    object _7075 = NOVALUE;
    object _7074 = NOVALUE;
    object _7072 = NOVALUE;
    object _0, _1, _2;
    

    /** map.e:901		sequence slots = eumem:ram_space[the_map_p][MAP_SLOTS]*/
    _2 = (object)SEQ_PTR(_30ram_space_11346);
    if (!IS_ATOM_INT(_the_map_p_12706)){
        _7072 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_the_map_p_12706)->dbl));
    }
    else{
        _7072 = (object)*(((s1_ptr)_2)->base + _the_map_p_12706);
    }
    DeRef(_slots_12708);
    _2 = (object)SEQ_PTR(_7072);
    _slots_12708 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_slots_12708);
    _7072 = NOVALUE;

    /** map.e:902		sequence keys = repeat( 0, eumem:ram_space[the_map_p][MAP_SIZE] )*/
    _2 = (object)SEQ_PTR(_30ram_space_11346);
    if (!IS_ATOM_INT(_the_map_p_12706)){
        _7074 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_the_map_p_12706)->dbl));
    }
    else{
        _7074 = (object)*(((s1_ptr)_2)->base + _the_map_p_12706);
    }
    _2 = (object)SEQ_PTR(_7074);
    _7075 = (object)*(((s1_ptr)_2)->base + 1);
    _7074 = NOVALUE;
    DeRef(_keys_12711);
    _keys_12711 = Repeat(0, _7075);
    _7075 = NOVALUE;

    /** map.e:903		integer kx = 0*/
    _kx_12715 = 0;

    /** map.e:904		for i = 1 to length( slots ) do*/
    if (IS_SEQUENCE(_slots_12708)){
            _7077 = SEQ_PTR(_slots_12708)->length;
    }
    else {
        _7077 = 1;
    }
    {
        object _i_12717;
        _i_12717 = 1;
L1: 
        if (_i_12717 > _7077){
            goto L2; // [43] 106
        }

        /** map.e:905			if slots[i][SLOT_HASH] >= 0 then*/
        _2 = (object)SEQ_PTR(_slots_12708);
        _7078 = (object)*(((s1_ptr)_2)->base + _i_12717);
        _2 = (object)SEQ_PTR(_7078);
        _7079 = (object)*(((s1_ptr)_2)->base + 1);
        _7078 = NOVALUE;
        if (binary_op_a(LESS, _7079, 0)){
            _7079 = NOVALUE;
            goto L3; // [60] 99
        }
        _7079 = NOVALUE;

        /** map.e:906				kx += 1*/
        _kx_12715 = _kx_12715 + 1;

        /** map.e:907				keys[kx] = slots[i][SLOT_KEY]*/
        _2 = (object)SEQ_PTR(_slots_12708);
        _7082 = (object)*(((s1_ptr)_2)->base + _i_12717);
        _2 = (object)SEQ_PTR(_7082);
        _7083 = (object)*(((s1_ptr)_2)->base + 2);
        _7082 = NOVALUE;
        Ref(_7083);
        _2 = (object)SEQ_PTR(_keys_12711);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _keys_12711 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _kx_12715);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _7083;
        if( _1 != _7083 ){
            DeRef(_1);
        }
        _7083 = NOVALUE;

        /** map.e:908				if kx = length( keys ) then*/
        if (IS_SEQUENCE(_keys_12711)){
                _7084 = SEQ_PTR(_keys_12711)->length;
        }
        else {
            _7084 = 1;
        }
        if (_kx_12715 != _7084)
        goto L4; // [89] 98

        /** map.e:909					exit*/
        goto L2; // [95] 106
L4: 
L3: 

        /** map.e:912		end for*/
        _i_12717 = _i_12717 + 1;
        goto L1; // [101] 50
L2: 
        ;
    }

    /** map.e:913		if sorted_result then*/
    if (_sorted_result_12707 == 0)
    {
        goto L5; // [108] 123
    }
    else{
    }

    /** map.e:914			return stdsort:sort( keys )*/
    RefDS(_keys_12711);
    _7086 = _24sort(_keys_12711, 1);
    DeRef(_the_map_p_12706);
    DeRef(_slots_12708);
    DeRefDS(_keys_12711);
    return _7086;
L5: 

    /** map.e:916		return keys*/
    DeRef(_the_map_p_12706);
    DeRef(_slots_12708);
    DeRef(_7086);
    _7086 = NOVALUE;
    return _keys_12711;
    ;
}


object _29pairs(object _the_map_12782, object _sorted_result_12783)
{
    object _slots_12784 = NOVALUE;
    object _pairs_12787 = NOVALUE;
    object _px_12791 = NOVALUE;
    object _7136 = NOVALUE;
    object _7134 = NOVALUE;
    object _7133 = NOVALUE;
    object _7132 = NOVALUE;
    object _7131 = NOVALUE;
    object _7130 = NOVALUE;
    object _7129 = NOVALUE;
    object _7126 = NOVALUE;
    object _7125 = NOVALUE;
    object _7124 = NOVALUE;
    object _7122 = NOVALUE;
    object _7121 = NOVALUE;
    object _7119 = NOVALUE;
    object _0, _1, _2;
    

    /** map.e:1045		sequence slots = eumem:ram_space[the_map][MAP_SLOTS]*/
    _2 = (object)SEQ_PTR(_30ram_space_11346);
    if (!IS_ATOM_INT(_the_map_12782)){
        _7119 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_the_map_12782)->dbl));
    }
    else{
        _7119 = (object)*(((s1_ptr)_2)->base + _the_map_12782);
    }
    DeRef(_slots_12784);
    _2 = (object)SEQ_PTR(_7119);
    _slots_12784 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_slots_12784);
    _7119 = NOVALUE;

    /** map.e:1046		sequence pairs = repeat( 0, eumem:ram_space[the_map][MAP_SIZE] )*/
    _2 = (object)SEQ_PTR(_30ram_space_11346);
    if (!IS_ATOM_INT(_the_map_12782)){
        _7121 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_the_map_12782)->dbl));
    }
    else{
        _7121 = (object)*(((s1_ptr)_2)->base + _the_map_12782);
    }
    _2 = (object)SEQ_PTR(_7121);
    _7122 = (object)*(((s1_ptr)_2)->base + 1);
    _7121 = NOVALUE;
    DeRef(_pairs_12787);
    _pairs_12787 = Repeat(0, _7122);
    _7122 = NOVALUE;

    /** map.e:1047		integer px = 0*/
    _px_12791 = 0;

    /** map.e:1048		for i = 1 to length( slots ) do*/
    if (IS_SEQUENCE(_slots_12784)){
            _7124 = SEQ_PTR(_slots_12784)->length;
    }
    else {
        _7124 = 1;
    }
    {
        object _i_12793;
        _i_12793 = 1;
L1: 
        if (_i_12793 > _7124){
            goto L2; // [43] 118
        }

        /** map.e:1049			if slots[i][SLOT_HASH] >= 0 then*/
        _2 = (object)SEQ_PTR(_slots_12784);
        _7125 = (object)*(((s1_ptr)_2)->base + _i_12793);
        _2 = (object)SEQ_PTR(_7125);
        _7126 = (object)*(((s1_ptr)_2)->base + 1);
        _7125 = NOVALUE;
        if (binary_op_a(LESS, _7126, 0)){
            _7126 = NOVALUE;
            goto L3; // [60] 111
        }
        _7126 = NOVALUE;

        /** map.e:1050				px += 1*/
        _px_12791 = _px_12791 + 1;

        /** map.e:1051				pairs[px] = { slots[i][SLOT_KEY], slots[i][SLOT_VALUE] }*/
        _2 = (object)SEQ_PTR(_slots_12784);
        _7129 = (object)*(((s1_ptr)_2)->base + _i_12793);
        _2 = (object)SEQ_PTR(_7129);
        _7130 = (object)*(((s1_ptr)_2)->base + 2);
        _7129 = NOVALUE;
        _2 = (object)SEQ_PTR(_slots_12784);
        _7131 = (object)*(((s1_ptr)_2)->base + _i_12793);
        _2 = (object)SEQ_PTR(_7131);
        _7132 = (object)*(((s1_ptr)_2)->base + 3);
        _7131 = NOVALUE;
        Ref(_7132);
        Ref(_7130);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _7130;
        ((intptr_t *)_2)[2] = _7132;
        _7133 = MAKE_SEQ(_1);
        _7132 = NOVALUE;
        _7130 = NOVALUE;
        _2 = (object)SEQ_PTR(_pairs_12787);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _pairs_12787 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _px_12791);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _7133;
        if( _1 != _7133 ){
            DeRef(_1);
        }
        _7133 = NOVALUE;

        /** map.e:1052				if px = length( pairs ) then*/
        if (IS_SEQUENCE(_pairs_12787)){
                _7134 = SEQ_PTR(_pairs_12787)->length;
        }
        else {
            _7134 = 1;
        }
        if (_px_12791 != _7134)
        goto L4; // [101] 110

        /** map.e:1053					exit*/
        goto L2; // [107] 118
L4: 
L3: 

        /** map.e:1056		end for*/
        _i_12793 = _i_12793 + 1;
        goto L1; // [113] 50
L2: 
        ;
    }

    /** map.e:1057		if sorted_result then*/
    if (_sorted_result_12783 == 0)
    {
        goto L5; // [120] 135
    }
    else{
    }

    /** map.e:1058			return stdsort:sort( pairs )*/
    RefDS(_pairs_12787);
    _7136 = _24sort(_pairs_12787, 1);
    DeRef(_the_map_12782);
    DeRef(_slots_12784);
    DeRefDS(_pairs_12787);
    return _7136;
L5: 

    /** map.e:1060		return pairs*/
    DeRef(_the_map_12782);
    DeRef(_slots_12784);
    DeRef(_7136);
    _7136 = NOVALUE;
    return _pairs_12787;
    ;
}



// 0x30807326
