// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _70set_colors(object _pColorList_66962)
{
    object _lColorName_66963 = NOVALUE;
    object _33050 = NOVALUE;
    object _33047 = NOVALUE;
    object _33044 = NOVALUE;
    object _33041 = NOVALUE;
    object _33038 = NOVALUE;
    object _33035 = NOVALUE;
    object _33032 = NOVALUE;
    object _33027 = NOVALUE;
    object _33026 = NOVALUE;
    object _33025 = NOVALUE;
    object _0, _1, _2;
    

    /** syncolor.e:48		for i = 1 to length(pColorList) do*/
    _33025 = 6;
    {
        object _i_66965;
        _i_66965 = 1;
L1: 
        if (_i_66965 > 6){
            goto L2; // [8] 168
        }

        /** syncolor.e:49			lColorName = text:upper(pColorList[i][1])*/
        _2 = (object)SEQ_PTR(_pColorList_66962);
        _33026 = (object)*(((s1_ptr)_2)->base + _i_66965);
        _2 = (object)SEQ_PTR(_33026);
        _33027 = (object)*(((s1_ptr)_2)->base + 1);
        _33026 = NOVALUE;
        Ref(_33027);
        _0 = _lColorName_66963;
        _lColorName_66963 = _14upper(_33027);
        DeRef(_0);
        _33027 = NOVALUE;

        /** syncolor.e:50			switch lColorName do*/
        _1 = find(_lColorName_66963, _33029);
        switch ( _1 ){ 

            /** syncolor.e:51				case "NORMAL" then*/
            case 1:

            /** syncolor.e:52					NORMAL_COLOR  = pColorList[i][2]*/
            _2 = (object)SEQ_PTR(_pColorList_66962);
            _33032 = (object)*(((s1_ptr)_2)->base + _i_66965);
            _2 = (object)SEQ_PTR(_33032);
            _70NORMAL_COLOR_66951 = (object)*(((s1_ptr)_2)->base + 2);
            if (!IS_ATOM_INT(_70NORMAL_COLOR_66951)){
                _70NORMAL_COLOR_66951 = (object)DBL_PTR(_70NORMAL_COLOR_66951)->dbl;
            }
            _33032 = NOVALUE;
            goto L3; // [54] 161

            /** syncolor.e:53				case "COMMENT" then*/
            case 2:

            /** syncolor.e:54					COMMENT_COLOR  = pColorList[i][2]*/
            _2 = (object)SEQ_PTR(_pColorList_66962);
            _33035 = (object)*(((s1_ptr)_2)->base + _i_66965);
            _2 = (object)SEQ_PTR(_33035);
            _70COMMENT_COLOR_66952 = (object)*(((s1_ptr)_2)->base + 2);
            if (!IS_ATOM_INT(_70COMMENT_COLOR_66952)){
                _70COMMENT_COLOR_66952 = (object)DBL_PTR(_70COMMENT_COLOR_66952)->dbl;
            }
            _33035 = NOVALUE;
            goto L3; // [72] 161

            /** syncolor.e:55				case "KEYWORD" then*/
            case 3:

            /** syncolor.e:56					KEYWORD_COLOR  = pColorList[i][2]*/
            _2 = (object)SEQ_PTR(_pColorList_66962);
            _33038 = (object)*(((s1_ptr)_2)->base + _i_66965);
            _2 = (object)SEQ_PTR(_33038);
            _70KEYWORD_COLOR_66953 = (object)*(((s1_ptr)_2)->base + 2);
            if (!IS_ATOM_INT(_70KEYWORD_COLOR_66953)){
                _70KEYWORD_COLOR_66953 = (object)DBL_PTR(_70KEYWORD_COLOR_66953)->dbl;
            }
            _33038 = NOVALUE;
            goto L3; // [90] 161

            /** syncolor.e:57				case "BUILTIN" then*/
            case 4:

            /** syncolor.e:58					BUILTIN_COLOR  = pColorList[i][2]*/
            _2 = (object)SEQ_PTR(_pColorList_66962);
            _33041 = (object)*(((s1_ptr)_2)->base + _i_66965);
            _2 = (object)SEQ_PTR(_33041);
            _70BUILTIN_COLOR_66954 = (object)*(((s1_ptr)_2)->base + 2);
            if (!IS_ATOM_INT(_70BUILTIN_COLOR_66954)){
                _70BUILTIN_COLOR_66954 = (object)DBL_PTR(_70BUILTIN_COLOR_66954)->dbl;
            }
            _33041 = NOVALUE;
            goto L3; // [108] 161

            /** syncolor.e:59				case "STRING" then*/
            case 5:

            /** syncolor.e:60					STRING_COLOR  = pColorList[i][2]*/
            _2 = (object)SEQ_PTR(_pColorList_66962);
            _33044 = (object)*(((s1_ptr)_2)->base + _i_66965);
            _2 = (object)SEQ_PTR(_33044);
            _70STRING_COLOR_66955 = (object)*(((s1_ptr)_2)->base + 2);
            if (!IS_ATOM_INT(_70STRING_COLOR_66955)){
                _70STRING_COLOR_66955 = (object)DBL_PTR(_70STRING_COLOR_66955)->dbl;
            }
            _33044 = NOVALUE;
            goto L3; // [126] 161

            /** syncolor.e:61				case "BRACKET" then*/
            case 6:

            /** syncolor.e:62					BRACKET_COLOR  = pColorList[i][2]*/
            _2 = (object)SEQ_PTR(_pColorList_66962);
            _33047 = (object)*(((s1_ptr)_2)->base + _i_66965);
            DeRef(_70BRACKET_COLOR_66956);
            _2 = (object)SEQ_PTR(_33047);
            _70BRACKET_COLOR_66956 = (object)*(((s1_ptr)_2)->base + 2);
            Ref(_70BRACKET_COLOR_66956);
            _33047 = NOVALUE;
            goto L3; // [144] 161

            /** syncolor.e:63				case else*/
            case 0:

            /** syncolor.e:64					printf(2, "syncolor.e: Unknown color name '%s', ignored.\n", {lColorName})*/
            _1 = NewS1(1);
            _2 = (object)((s1_ptr)_1)->base;
            RefDS(_lColorName_66963);
            ((intptr_t*)_2)[1] = _lColorName_66963;
            _33050 = MAKE_SEQ(_1);
            EPrintf(2, _33049, _33050);
            DeRefDS(_33050);
            _33050 = NOVALUE;
        ;}L3: 

        /** syncolor.e:66		end for*/
        _i_66965 = _i_66965 + 1;
        goto L1; // [163] 15
L2: 
        ;
    }

    /** syncolor.e:67	end procedure*/
    DeRefDS(_pColorList_66962);
    DeRef(_lColorName_66963);
    return;
    ;
}


void _70init_class()
{
    object _0, _1, _2;
    

    /** syncolor.e:71		NORMAL_COLOR  = #330033*/
    _70NORMAL_COLOR_66951 = 3342387;

    /** syncolor.e:72		COMMENT_COLOR = #FF0055*/
    _70COMMENT_COLOR_66952 = 16711765;

    /** syncolor.e:73		KEYWORD_COLOR = #0000FF*/
    _70KEYWORD_COLOR_66953 = 255;

    /** syncolor.e:74		BUILTIN_COLOR = #FF00FF*/
    _70BUILTIN_COLOR_66954 = 16711935;

    /** syncolor.e:75		STRING_COLOR  = #00A033*/
    _70STRING_COLOR_66955 = 41011;

    /** syncolor.e:76		BRACKET_COLOR = {NORMAL_COLOR, #993333, #0000FF, #5500FF, #00FF00}*/
    _0 = _70BRACKET_COLOR_66956;
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 3342387;
    ((intptr_t*)_2)[2] = 10040115;
    ((intptr_t*)_2)[3] = 255;
    ((intptr_t*)_2)[4] = 5570815;
    ((intptr_t*)_2)[5] = 65280;
    _70BRACKET_COLOR_66956 = MAKE_SEQ(_1);
    DeRef(_0);

    /** syncolor.e:78	end procedure*/
    return;
    ;
}


object _70default_state(object _token_67029)
{
    object _33068 = NOVALUE;
    object _0, _1, _2;
    

    /** syncolor.e:103		if not token then*/
    if (IS_ATOM_INT(_token_67029)) {
        if (_token_67029 != 0){
            goto L1; // [3] 12
        }
    }
    else {
        if (DBL_PTR(_token_67029)->dbl != 0.0){
            goto L1; // [3] 12
        }
    }

    /** syncolor.e:104			token = tokenize:new()*/
    _0 = _token_67029;
    _token_67029 = _71new();
    DeRef(_0);
L1: 

    /** syncolor.e:106		return {*/
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_token_67029);
    ((intptr_t*)_2)[1] = _token_67029;
    ((intptr_t*)_2)[2] = 0;
    ((intptr_t*)_2)[3] = 0;
    _33068 = MAKE_SEQ(_1);
    DeRef(_token_67029);
    return _33068;
    ;
}


object _70new()
{
    object _state_67039 = NOVALUE;
    object _0, _1, _2;
    

    /** syncolor.e:124		atom state = eumem:malloc()*/
    _0 = _state_67039;
    _state_67039 = _30malloc(1, 1);
    DeRef(_0);

    /** syncolor.e:126		reset(state)*/
    Ref(_state_67039);
    _70reset(_state_67039);

    /** syncolor.e:128		return state*/
    return _state_67039;
    ;
}


void _70tokenize_reset(object _token_67044)
{
    object _reset_1__tmp_at7_67047 = NOVALUE;
    object _0, _1, _2;
    

    /** syncolor.e:138		if token then*/
    if (_token_67044 == 0) {
        goto L1; // [3] 27
    }
    else {
        if (!IS_ATOM_INT(_token_67044) && DBL_PTR(_token_67044)->dbl == 0.0){
            goto L1; // [3] 27
        }
    }

    /** syncolor.e:139			tokenize:reset(token)*/

    /** tokenize.e:215		eumem:ram_space[state] = default_state()*/
    _0 = _reset_1__tmp_at7_67047;
    _reset_1__tmp_at7_67047 = _71default_state();
    DeRef(_0);
    Ref(_reset_1__tmp_at7_67047);
    _2 = (object)SEQ_PTR(_30ram_space_11346);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _30ram_space_11346 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_token_67044))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_token_67044)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _token_67044);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _reset_1__tmp_at7_67047;
    DeRef(_1);

    /** tokenize.e:216	end procedure*/
    goto L2; // [21] 24
L2: 
    DeRef(_reset_1__tmp_at7_67047);
    _reset_1__tmp_at7_67047 = NOVALUE;
L1: 

    /** syncolor.e:141	end procedure*/
    DeRef(_token_67044);
    return;
    ;
}


void _70reset(object _state_67050)
{
    object _token_67051 = NOVALUE;
    object _33075 = NOVALUE;
    object _33074 = NOVALUE;
    object _33072 = NOVALUE;
    object _0, _1, _2;
    

    /** syncolor.e:144		atom token = eumem:ram_space[state][S_TOKENIZER]*/
    _2 = (object)SEQ_PTR(_30ram_space_11346);
    if (!IS_ATOM_INT(_state_67050)){
        _33072 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_state_67050)->dbl));
    }
    else{
        _33072 = (object)*(((s1_ptr)_2)->base + _state_67050);
    }
    DeRef(_token_67051);
    _2 = (object)SEQ_PTR(_33072);
    _token_67051 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_token_67051);
    _33072 = NOVALUE;

    /** syncolor.e:145		tokenize_reset(token)*/
    Ref(_token_67051);
    _70tokenize_reset(_token_67051);

    /** syncolor.e:146		eumem:ram_space[state] = default_state(token)*/
    Ref(_token_67051);
    _33074 = _70default_state(_token_67051);
    _2 = (object)SEQ_PTR(_30ram_space_11346);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _30ram_space_11346 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_state_67050))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_state_67050)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _state_67050);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33074;
    if( _1 != _33074 ){
        DeRef(_1);
    }
    _33074 = NOVALUE;

    /** syncolor.e:147		eumem:ram_space[state] = default_state()*/
    _33075 = _70default_state(0);
    _2 = (object)SEQ_PTR(_30ram_space_11346);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _30ram_space_11346 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_state_67050))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_state_67050)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _state_67050);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33075;
    if( _1 != _33075 ){
        DeRef(_1);
    }
    _33075 = NOVALUE;

    /** syncolor.e:148	end procedure*/
    DeRef(_state_67050);
    DeRef(_token_67051);
    return;
    ;
}



// 0x7D6D81B8
