// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _60compress(object _x_22883)
{
    object _x4_22884 = NOVALUE;
    object _s_22885 = NOVALUE;
    object _12944 = NOVALUE;
    object _12943 = NOVALUE;
    object _12942 = NOVALUE;
    object _12940 = NOVALUE;
    object _12939 = NOVALUE;
    object _12937 = NOVALUE;
    object _12935 = NOVALUE;
    object _12934 = NOVALUE;
    object _12933 = NOVALUE;
    object _12932 = NOVALUE;
    object _12930 = NOVALUE;
    object _12928 = NOVALUE;
    object _12926 = NOVALUE;
    object _12924 = NOVALUE;
    object _12923 = NOVALUE;
    object _12922 = NOVALUE;
    object _12920 = NOVALUE;
    object _12919 = NOVALUE;
    object _12918 = NOVALUE;
    object _12917 = NOVALUE;
    object _12916 = NOVALUE;
    object _12915 = NOVALUE;
    object _12914 = NOVALUE;
    object _12913 = NOVALUE;
    object _12912 = NOVALUE;
    object _12911 = NOVALUE;
    object _12909 = NOVALUE;
    object _12908 = NOVALUE;
    object _12907 = NOVALUE;
    object _12906 = NOVALUE;
    object _12905 = NOVALUE;
    object _12904 = NOVALUE;
    object _12902 = NOVALUE;
    object _12901 = NOVALUE;
    object _12900 = NOVALUE;
    object _12899 = NOVALUE;
    object _12898 = NOVALUE;
    object _12897 = NOVALUE;
    object _12896 = NOVALUE;
    object _12895 = NOVALUE;
    object _12894 = NOVALUE;
    object _0, _1, _2;
    

    /** compress.e:59		if integer(x) then*/
    if (IS_ATOM_INT(_x_22883))
    _12894 = 1;
    else if (IS_ATOM_DBL(_x_22883))
    _12894 = IS_ATOM_INT(DoubleToInt(_x_22883));
    else
    _12894 = 0;
    if (_12894 == 0)
    {
        _12894 = NOVALUE;
        goto L1; // [6] 220
    }
    else{
        _12894 = NOVALUE;
    }

    /** compress.e:60			if x >= MIN1B and x <= MAX1B then*/
    if (IS_ATOM_INT(_x_22883)) {
        _12895 = (_x_22883 >= -2);
    }
    else {
        _12895 = binary_op(GREATEREQ, _x_22883, -2);
    }
    if (IS_ATOM_INT(_12895)) {
        if (_12895 == 0) {
            goto L2; // [15] 44
        }
    }
    else {
        if (DBL_PTR(_12895)->dbl == 0.0) {
            goto L2; // [15] 44
        }
    }
    if (IS_ATOM_INT(_x_22883)) {
        _12897 = (_x_22883 <= 244);
    }
    else {
        _12897 = binary_op(LESSEQ, _x_22883, 244);
    }
    if (_12897 == 0) {
        DeRef(_12897);
        _12897 = NOVALUE;
        goto L2; // [24] 44
    }
    else {
        if (!IS_ATOM_INT(_12897) && DBL_PTR(_12897)->dbl == 0.0){
            DeRef(_12897);
            _12897 = NOVALUE;
            goto L2; // [24] 44
        }
        DeRef(_12897);
        _12897 = NOVALUE;
    }
    DeRef(_12897);
    _12897 = NOVALUE;

    /** compress.e:61				return {x - MIN1B}*/
    if (IS_ATOM_INT(_x_22883)) {
        _12898 = _x_22883 - -2;
        if ((object)((uintptr_t)_12898 +(uintptr_t) HIGH_BITS) >= 0){
            _12898 = NewDouble((eudouble)_12898);
        }
    }
    else {
        _12898 = binary_op(MINUS, _x_22883, -2);
    }
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _12898;
    _12899 = MAKE_SEQ(_1);
    _12898 = NOVALUE;
    DeRef(_x_22883);
    DeRef(_x4_22884);
    DeRef(_s_22885);
    DeRef(_12895);
    _12895 = NOVALUE;
    return _12899;
    goto L3; // [41] 389
L2: 

    /** compress.e:63			elsif x >= MIN2B and x <= MAX2B then*/
    if (IS_ATOM_INT(_x_22883)) {
        _12900 = (_x_22883 >= _60MIN2B_22857);
    }
    else {
        _12900 = binary_op(GREATEREQ, _x_22883, _60MIN2B_22857);
    }
    if (IS_ATOM_INT(_12900)) {
        if (_12900 == 0) {
            goto L4; // [52] 97
        }
    }
    else {
        if (DBL_PTR(_12900)->dbl == 0.0) {
            goto L4; // [52] 97
        }
    }
    if (IS_ATOM_INT(_x_22883)) {
        _12902 = (_x_22883 <= 32767);
    }
    else {
        _12902 = binary_op(LESSEQ, _x_22883, 32767);
    }
    if (_12902 == 0) {
        DeRef(_12902);
        _12902 = NOVALUE;
        goto L4; // [63] 97
    }
    else {
        if (!IS_ATOM_INT(_12902) && DBL_PTR(_12902)->dbl == 0.0){
            DeRef(_12902);
            _12902 = NOVALUE;
            goto L4; // [63] 97
        }
        DeRef(_12902);
        _12902 = NOVALUE;
    }
    DeRef(_12902);
    _12902 = NOVALUE;

    /** compress.e:64				x -= MIN2B*/
    _0 = _x_22883;
    if (IS_ATOM_INT(_x_22883)) {
        _x_22883 = _x_22883 - _60MIN2B_22857;
        if ((object)((uintptr_t)_x_22883 +(uintptr_t) HIGH_BITS) >= 0){
            _x_22883 = NewDouble((eudouble)_x_22883);
        }
    }
    else {
        _x_22883 = binary_op(MINUS, _x_22883, _60MIN2B_22857);
    }
    DeRef(_0);

    /** compress.e:65				return {I2B, and_bits(x, #FF), floor(x / #100)}*/
    if (IS_ATOM_INT(_x_22883)) {
        {uintptr_t tu;
             tu = (uintptr_t)_x_22883 & (uintptr_t)255;
             _12904 = MAKE_UINT(tu);
        }
    }
    else {
        _12904 = binary_op(AND_BITS, _x_22883, 255);
    }
    if (IS_ATOM_INT(_x_22883)) {
        if (256 > 0 && _x_22883 >= 0) {
            _12905 = _x_22883 / 256;
        }
        else {
            temp_dbl = EUFLOOR((eudouble)_x_22883 / (eudouble)256);
            if (_x_22883 != MININT)
            _12905 = (object)temp_dbl;
            else
            _12905 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x_22883, 256);
        _12905 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 247;
    ((intptr_t*)_2)[2] = _12904;
    ((intptr_t*)_2)[3] = _12905;
    _12906 = MAKE_SEQ(_1);
    _12905 = NOVALUE;
    _12904 = NOVALUE;
    DeRef(_x_22883);
    DeRef(_x4_22884);
    DeRef(_s_22885);
    DeRef(_12895);
    _12895 = NOVALUE;
    DeRef(_12899);
    _12899 = NOVALUE;
    DeRef(_12900);
    _12900 = NOVALUE;
    return _12906;
    goto L3; // [94] 389
L4: 

    /** compress.e:67			elsif x >= MIN3B and x <= MAX3B then*/
    if (IS_ATOM_INT(_x_22883)) {
        _12907 = (_x_22883 >= _60MIN3B_22863);
    }
    else {
        _12907 = binary_op(GREATEREQ, _x_22883, _60MIN3B_22863);
    }
    if (IS_ATOM_INT(_12907)) {
        if (_12907 == 0) {
            goto L5; // [105] 159
        }
    }
    else {
        if (DBL_PTR(_12907)->dbl == 0.0) {
            goto L5; // [105] 159
        }
    }
    if (IS_ATOM_INT(_x_22883)) {
        _12909 = (_x_22883 <= 8388607);
    }
    else {
        _12909 = binary_op(LESSEQ, _x_22883, 8388607);
    }
    if (_12909 == 0) {
        DeRef(_12909);
        _12909 = NOVALUE;
        goto L5; // [116] 159
    }
    else {
        if (!IS_ATOM_INT(_12909) && DBL_PTR(_12909)->dbl == 0.0){
            DeRef(_12909);
            _12909 = NOVALUE;
            goto L5; // [116] 159
        }
        DeRef(_12909);
        _12909 = NOVALUE;
    }
    DeRef(_12909);
    _12909 = NOVALUE;

    /** compress.e:68				x -= MIN3B*/
    _0 = _x_22883;
    if (IS_ATOM_INT(_x_22883)) {
        _x_22883 = _x_22883 - _60MIN3B_22863;
        if ((object)((uintptr_t)_x_22883 +(uintptr_t) HIGH_BITS) >= 0){
            _x_22883 = NewDouble((eudouble)_x_22883);
        }
    }
    else {
        _x_22883 = binary_op(MINUS, _x_22883, _60MIN3B_22863);
    }
    DeRef(_0);

    /** compress.e:69				return {I3B, and_bits(x, #FF), and_bits(floor(x / #100), #FF), floor(x / #10000)}*/
    if (IS_ATOM_INT(_x_22883)) {
        {uintptr_t tu;
             tu = (uintptr_t)_x_22883 & (uintptr_t)255;
             _12911 = MAKE_UINT(tu);
        }
    }
    else {
        _12911 = binary_op(AND_BITS, _x_22883, 255);
    }
    if (IS_ATOM_INT(_x_22883)) {
        if (256 > 0 && _x_22883 >= 0) {
            _12912 = _x_22883 / 256;
        }
        else {
            temp_dbl = EUFLOOR((eudouble)_x_22883 / (eudouble)256);
            if (_x_22883 != MININT)
            _12912 = (object)temp_dbl;
            else
            _12912 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x_22883, 256);
        _12912 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    if (IS_ATOM_INT(_12912)) {
        {uintptr_t tu;
             tu = (uintptr_t)_12912 & (uintptr_t)255;
             _12913 = MAKE_UINT(tu);
        }
    }
    else {
        _12913 = binary_op(AND_BITS, _12912, 255);
    }
    DeRef(_12912);
    _12912 = NOVALUE;
    if (IS_ATOM_INT(_x_22883)) {
        if (65536 > 0 && _x_22883 >= 0) {
            _12914 = _x_22883 / 65536;
        }
        else {
            temp_dbl = EUFLOOR((eudouble)_x_22883 / (eudouble)65536);
            if (_x_22883 != MININT)
            _12914 = (object)temp_dbl;
            else
            _12914 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x_22883, 65536);
        _12914 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 248;
    ((intptr_t*)_2)[2] = _12911;
    ((intptr_t*)_2)[3] = _12913;
    ((intptr_t*)_2)[4] = _12914;
    _12915 = MAKE_SEQ(_1);
    _12914 = NOVALUE;
    _12913 = NOVALUE;
    _12911 = NOVALUE;
    DeRef(_x_22883);
    DeRef(_x4_22884);
    DeRef(_s_22885);
    DeRef(_12895);
    _12895 = NOVALUE;
    DeRef(_12906);
    _12906 = NOVALUE;
    DeRef(_12899);
    _12899 = NOVALUE;
    DeRef(_12900);
    _12900 = NOVALUE;
    DeRef(_12907);
    _12907 = NOVALUE;
    return _12915;
    goto L3; // [156] 389
L5: 

    /** compress.e:71			elsif x >= MIN4B and x <= MAX4B then*/
    if (IS_ATOM_INT(_x_22883) && IS_ATOM_INT(_60MIN4B_22869)) {
        _12916 = (_x_22883 >= _60MIN4B_22869);
    }
    else {
        _12916 = binary_op(GREATEREQ, _x_22883, _60MIN4B_22869);
    }
    if (IS_ATOM_INT(_12916)) {
        if (_12916 == 0) {
            goto L6; // [167] 199
        }
    }
    else {
        if (DBL_PTR(_12916)->dbl == 0.0) {
            goto L6; // [167] 199
        }
    }
    if (IS_ATOM_INT(_x_22883) && IS_ATOM_INT(_60MAX4B_22872)) {
        _12918 = (_x_22883 <= _60MAX4B_22872);
    }
    else {
        _12918 = binary_op(LESSEQ, _x_22883, _60MAX4B_22872);
    }
    if (_12918 == 0) {
        DeRef(_12918);
        _12918 = NOVALUE;
        goto L6; // [178] 199
    }
    else {
        if (!IS_ATOM_INT(_12918) && DBL_PTR(_12918)->dbl == 0.0){
            DeRef(_12918);
            _12918 = NOVALUE;
            goto L6; // [178] 199
        }
        DeRef(_12918);
        _12918 = NOVALUE;
    }
    DeRef(_12918);
    _12918 = NOVALUE;

    /** compress.e:72				return I4B & int_to_bytes(x)*/
    Ref(_x_22883);
    _12919 = _15int_to_bytes(_x_22883, 4);
    if (IS_SEQUENCE(249) && IS_ATOM(_12919)) {
    }
    else if (IS_ATOM(249) && IS_SEQUENCE(_12919)) {
        Prepend(&_12920, _12919, 249);
    }
    else {
        Concat((object_ptr)&_12920, 249, _12919);
    }
    DeRef(_12919);
    _12919 = NOVALUE;
    DeRef(_x_22883);
    DeRef(_x4_22884);
    DeRef(_s_22885);
    DeRef(_12895);
    _12895 = NOVALUE;
    DeRef(_12906);
    _12906 = NOVALUE;
    DeRef(_12916);
    _12916 = NOVALUE;
    DeRef(_12915);
    _12915 = NOVALUE;
    DeRef(_12899);
    _12899 = NOVALUE;
    DeRef(_12900);
    _12900 = NOVALUE;
    DeRef(_12907);
    _12907 = NOVALUE;
    return _12920;
    goto L3; // [196] 389
L6: 

    /** compress.e:75				ifdef EU4_0 then*/

    /** compress.e:79					return I8B & int_to_bytes(x, 8)*/
    Ref(_x_22883);
    _12922 = _15int_to_bytes(_x_22883, 8);
    if (IS_SEQUENCE(250) && IS_ATOM(_12922)) {
    }
    else if (IS_ATOM(250) && IS_SEQUENCE(_12922)) {
        Prepend(&_12923, _12922, 250);
    }
    else {
        Concat((object_ptr)&_12923, 250, _12922);
    }
    DeRef(_12922);
    _12922 = NOVALUE;
    DeRef(_x_22883);
    DeRef(_x4_22884);
    DeRef(_s_22885);
    DeRef(_12895);
    _12895 = NOVALUE;
    DeRef(_12906);
    _12906 = NOVALUE;
    DeRef(_12916);
    _12916 = NOVALUE;
    DeRef(_12920);
    _12920 = NOVALUE;
    DeRef(_12915);
    _12915 = NOVALUE;
    DeRef(_12899);
    _12899 = NOVALUE;
    DeRef(_12900);
    _12900 = NOVALUE;
    DeRef(_12907);
    _12907 = NOVALUE;
    return _12923;
    goto L3; // [217] 389
L1: 

    /** compress.e:83		elsif atom(x) then*/
    _12924 = IS_ATOM(_x_22883);
    if (_12924 == 0)
    {
        _12924 = NOVALUE;
        goto L7; // [225] 309
    }
    else{
        _12924 = NOVALUE;
    }

    /** compress.e:85			x4 = atom_to_float32(x)*/
    Ref(_x_22883);
    _0 = _x4_22884;
    _x4_22884 = _15atom_to_float32(_x_22883);
    DeRef(_0);

    /** compress.e:86			if x = float32_to_atom(x4) then*/
    RefDS(_x4_22884);
    _12926 = _15float32_to_atom(_x4_22884);
    if (binary_op_a(NOTEQ, _x_22883, _12926)){
        DeRef(_12926);
        _12926 = NOVALUE;
        goto L8; // [242] 259
    }
    DeRef(_12926);
    _12926 = NOVALUE;

    /** compress.e:88				return F4B & x4*/
    Prepend(&_12928, _x4_22884, 251);
    DeRef(_x_22883);
    DeRefDS(_x4_22884);
    DeRef(_s_22885);
    DeRef(_12895);
    _12895 = NOVALUE;
    DeRef(_12906);
    _12906 = NOVALUE;
    DeRef(_12916);
    _12916 = NOVALUE;
    DeRef(_12920);
    _12920 = NOVALUE;
    DeRef(_12923);
    _12923 = NOVALUE;
    DeRef(_12915);
    _12915 = NOVALUE;
    DeRef(_12899);
    _12899 = NOVALUE;
    DeRef(_12900);
    _12900 = NOVALUE;
    DeRef(_12907);
    _12907 = NOVALUE;
    return _12928;
    goto L3; // [256] 389
L8: 

    /** compress.e:90				x4 = atom_to_float64( x )*/
    Ref(_x_22883);
    _0 = _x4_22884;
    _x4_22884 = _15atom_to_float64(_x_22883);
    DeRef(_0);

    /** compress.e:91				if x = float64_to_atom( x4 ) then*/
    RefDS(_x4_22884);
    _12930 = _15float64_to_atom(_x4_22884);
    if (binary_op_a(NOTEQ, _x_22883, _12930)){
        DeRef(_12930);
        _12930 = NOVALUE;
        goto L9; // [273] 290
    }
    DeRef(_12930);
    _12930 = NOVALUE;

    /** compress.e:92					return F8B & x4*/
    Prepend(&_12932, _x4_22884, 252);
    DeRef(_x_22883);
    DeRefDS(_x4_22884);
    DeRef(_s_22885);
    DeRef(_12895);
    _12895 = NOVALUE;
    DeRef(_12906);
    _12906 = NOVALUE;
    DeRef(_12916);
    _12916 = NOVALUE;
    DeRef(_12920);
    _12920 = NOVALUE;
    DeRef(_12923);
    _12923 = NOVALUE;
    DeRef(_12915);
    _12915 = NOVALUE;
    DeRef(_12928);
    _12928 = NOVALUE;
    DeRef(_12899);
    _12899 = NOVALUE;
    DeRef(_12900);
    _12900 = NOVALUE;
    DeRef(_12907);
    _12907 = NOVALUE;
    return _12932;
    goto L3; // [287] 389
L9: 

    /** compress.e:94					return F10B & atom_to_float80( x )*/
    Ref(_x_22883);
    _12933 = _15atom_to_float80(_x_22883);
    if (IS_SEQUENCE(253) && IS_ATOM(_12933)) {
    }
    else if (IS_ATOM(253) && IS_SEQUENCE(_12933)) {
        Prepend(&_12934, _12933, 253);
    }
    else {
        Concat((object_ptr)&_12934, 253, _12933);
    }
    DeRef(_12933);
    _12933 = NOVALUE;
    DeRef(_x_22883);
    DeRef(_x4_22884);
    DeRef(_s_22885);
    DeRef(_12895);
    _12895 = NOVALUE;
    DeRef(_12906);
    _12906 = NOVALUE;
    DeRef(_12916);
    _12916 = NOVALUE;
    DeRef(_12920);
    _12920 = NOVALUE;
    DeRef(_12923);
    _12923 = NOVALUE;
    DeRef(_12932);
    _12932 = NOVALUE;
    DeRef(_12915);
    _12915 = NOVALUE;
    DeRef(_12928);
    _12928 = NOVALUE;
    DeRef(_12899);
    _12899 = NOVALUE;
    DeRef(_12900);
    _12900 = NOVALUE;
    DeRef(_12907);
    _12907 = NOVALUE;
    return _12934;
    goto L3; // [306] 389
L7: 

    /** compress.e:100			if length(x) <= 255 then*/
    if (IS_SEQUENCE(_x_22883)){
            _12935 = SEQ_PTR(_x_22883)->length;
    }
    else {
        _12935 = 1;
    }
    if (_12935 > 255)
    goto LA; // [314] 330

    /** compress.e:101				s = {S1B, length(x)}*/
    if (IS_SEQUENCE(_x_22883)){
            _12937 = SEQ_PTR(_x_22883)->length;
    }
    else {
        _12937 = 1;
    }
    DeRef(_s_22885);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 254;
    ((intptr_t *)_2)[2] = _12937;
    _s_22885 = MAKE_SEQ(_1);
    _12937 = NOVALUE;
    goto LB; // [327] 345
LA: 

    /** compress.e:103				s = S4B & int_to_bytes(length(x))*/
    if (IS_SEQUENCE(_x_22883)){
            _12939 = SEQ_PTR(_x_22883)->length;
    }
    else {
        _12939 = 1;
    }
    _12940 = _15int_to_bytes(_12939, 4);
    _12939 = NOVALUE;
    if (IS_SEQUENCE(255) && IS_ATOM(_12940)) {
    }
    else if (IS_ATOM(255) && IS_SEQUENCE(_12940)) {
        Prepend(&_s_22885, _12940, 255);
    }
    else {
        Concat((object_ptr)&_s_22885, 255, _12940);
    }
    DeRef(_12940);
    _12940 = NOVALUE;
LB: 

    /** compress.e:105			for i = 1 to length(x) do*/
    if (IS_SEQUENCE(_x_22883)){
            _12942 = SEQ_PTR(_x_22883)->length;
    }
    else {
        _12942 = 1;
    }
    {
        object _i_22957;
        _i_22957 = 1;
LC: 
        if (_i_22957 > _12942){
            goto LD; // [350] 380
        }

        /** compress.e:106				s &= compress(x[i])*/
        _2 = (object)SEQ_PTR(_x_22883);
        _12943 = (object)*(((s1_ptr)_2)->base + _i_22957);
        Ref(_12943);
        _12944 = _60compress(_12943);
        _12943 = NOVALUE;
        if (IS_SEQUENCE(_s_22885) && IS_ATOM(_12944)) {
            Ref(_12944);
            Append(&_s_22885, _s_22885, _12944);
        }
        else if (IS_ATOM(_s_22885) && IS_SEQUENCE(_12944)) {
        }
        else {
            Concat((object_ptr)&_s_22885, _s_22885, _12944);
        }
        DeRef(_12944);
        _12944 = NOVALUE;

        /** compress.e:107			end for*/
        _i_22957 = _i_22957 + 1;
        goto LC; // [375] 357
LD: 
        ;
    }

    /** compress.e:108			return s*/
    DeRef(_x_22883);
    DeRef(_x4_22884);
    DeRef(_12895);
    _12895 = NOVALUE;
    DeRef(_12906);
    _12906 = NOVALUE;
    DeRef(_12916);
    _12916 = NOVALUE;
    DeRef(_12920);
    _12920 = NOVALUE;
    DeRef(_12923);
    _12923 = NOVALUE;
    DeRef(_12934);
    _12934 = NOVALUE;
    DeRef(_12932);
    _12932 = NOVALUE;
    DeRef(_12915);
    _12915 = NOVALUE;
    DeRef(_12928);
    _12928 = NOVALUE;
    DeRef(_12899);
    _12899 = NOVALUE;
    DeRef(_12900);
    _12900 = NOVALUE;
    DeRef(_12907);
    _12907 = NOVALUE;
    return _s_22885;
L3: 
    ;
}



// 0xA809F88E
