// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _45EndLineTable()
{
    object _0, _1, _2;
    

    /** parser.e:120		LineTable = append(LineTable, -2)*/
    Append(&_36LineTable_21860, _36LineTable_21860, -2);

    /** parser.e:121	end procedure*/
    return;
    ;
}


void _45CreateTopLevel()
{
    object _28064 = NOVALUE;
    object _28062 = NOVALUE;
    object _28060 = NOVALUE;
    object _28058 = NOVALUE;
    object _28056 = NOVALUE;
    object _28054 = NOVALUE;
    object _28052 = NOVALUE;
    object _28050 = NOVALUE;
    object _28048 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:125		SymTab[TopLevelSub][S_NUM_ARGS] = 0*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_36TopLevelSub_21774 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_NUM_ARGS_21455))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21455)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_NUM_ARGS_21455);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);
    _28048 = NOVALUE;

    /** parser.e:126		SymTab[TopLevelSub][S_TEMPS] = 0*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_36TopLevelSub_21774 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_TEMPS_21449))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TEMPS_21449)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_TEMPS_21449);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);
    _28050 = NOVALUE;

    /** parser.e:127		SymTab[TopLevelSub][S_CODE] = {}*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_36TopLevelSub_21774 + ((s1_ptr)_2)->base);
    RefDS(_22190);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_CODE_21416))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21416)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_CODE_21416);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22190;
    DeRef(_1);
    _28052 = NOVALUE;

    /** parser.e:128		SymTab[TopLevelSub][S_LINETAB] = {}*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_36TopLevelSub_21774 + ((s1_ptr)_2)->base);
    RefDS(_22190);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_LINETAB_21439))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_LINETAB_21439)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_LINETAB_21439);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22190;
    DeRef(_1);
    _28054 = NOVALUE;

    /** parser.e:129		SymTab[TopLevelSub][S_FIRSTLINE] = 1*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_36TopLevelSub_21774 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_FIRSTLINE_21444))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FIRSTLINE_21444)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_FIRSTLINE_21444);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1;
    DeRef(_1);
    _28056 = NOVALUE;

    /** parser.e:130		SymTab[TopLevelSub][S_REFLIST] = {}*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_36TopLevelSub_21774 + ((s1_ptr)_2)->base);
    RefDS(_22190);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 24);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22190;
    DeRef(_1);
    _28058 = NOVALUE;

    /** parser.e:131		SymTab[TopLevelSub][S_NREFS] = 1*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_36TopLevelSub_21774 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1;
    DeRef(_1);
    _28060 = NOVALUE;

    /** parser.e:132		SymTab[TopLevelSub][S_RESIDENT_TASK] = 1*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_36TopLevelSub_21774 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 25);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1;
    DeRef(_1);
    _28062 = NOVALUE;

    /** parser.e:133		SymTab[TopLevelSub][S_SAVED_PRIVATES] = {}*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_36TopLevelSub_21774 + ((s1_ptr)_2)->base);
    RefDS(_22190);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 26);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22190;
    DeRef(_1);
    _28064 = NOVALUE;

    /** parser.e:135		Start_block( PROC, TopLevelSub )*/
    _65Start_block(27, _36TopLevelSub_21774);

    /** parser.e:136	end procedure*/
    return;
    ;
}


void _45CheckForUndefinedGotoLabels()
{
    object _28078 = NOVALUE;
    object _28077 = NOVALUE;
    object _28074 = NOVALUE;
    object _28072 = NOVALUE;
    object _28070 = NOVALUE;
    object _28068 = NOVALUE;
    object _28067 = NOVALUE;
    object _28066 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:139		for i = 1 to length(goto_delay) do*/
    if (IS_SEQUENCE(_36goto_delay_21881)){
            _28066 = SEQ_PTR(_36goto_delay_21881)->length;
    }
    else {
        _28066 = 1;
    }
    {
        object _i_55460;
        _i_55460 = 1;
L1: 
        if (_i_55460 > _28066){
            goto L2; // [8] 106
        }

        /** parser.e:140			if not equal(goto_delay[i],"") then*/
        _2 = (object)SEQ_PTR(_36goto_delay_21881);
        _28067 = (object)*(((s1_ptr)_2)->base + _i_55460);
        if (_28067 == _22190)
        _28068 = 1;
        else if (IS_ATOM_INT(_28067) && IS_ATOM_INT(_22190))
        _28068 = 0;
        else
        _28068 = (compare(_28067, _22190) == 0);
        _28067 = NOVALUE;
        if (_28068 != 0)
        goto L3; // [27] 99
        _28068 = NOVALUE;

        /** parser.e:141				line_number = goto_line[i][1] -- tell compiler the correct line number*/
        _2 = (object)SEQ_PTR(_45goto_line_55366);
        _28070 = (object)*(((s1_ptr)_2)->base + _i_55460);
        _2 = (object)SEQ_PTR(_28070);
        _36line_number_21768 = (object)*(((s1_ptr)_2)->base + 1);
        if (!IS_ATOM_INT(_36line_number_21768)){
            _36line_number_21768 = (object)DBL_PTR(_36line_number_21768)->dbl;
        }
        _28070 = NOVALUE;

        /** parser.e:142				gline_number = goto_line[i][1] -- tell compiler the correct line number*/
        _2 = (object)SEQ_PTR(_45goto_line_55366);
        _28072 = (object)*(((s1_ptr)_2)->base + _i_55460);
        _2 = (object)SEQ_PTR(_28072);
        _36gline_number_21772 = (object)*(((s1_ptr)_2)->base + 1);
        if (!IS_ATOM_INT(_36gline_number_21772)){
            _36gline_number_21772 = (object)DBL_PTR(_36gline_number_21772)->dbl;
        }
        _28072 = NOVALUE;

        /** parser.e:143				ThisLine = goto_line[i][2] -- tell compiler the correct line number*/
        _2 = (object)SEQ_PTR(_45goto_line_55366);
        _28074 = (object)*(((s1_ptr)_2)->base + _i_55460);
        DeRef(_50ThisLine_49594);
        _2 = (object)SEQ_PTR(_28074);
        _50ThisLine_49594 = (object)*(((s1_ptr)_2)->base + 2);
        Ref(_50ThisLine_49594);
        _28074 = NOVALUE;

        /** parser.e:144				bp = length(ThisLine)*/
        if (IS_SEQUENCE(_50ThisLine_49594)){
                _50bp_49598 = SEQ_PTR(_50ThisLine_49594)->length;
        }
        else {
            _50bp_49598 = 1;
        }

        /** parser.e:145					CompileErr(UNKNOWN_LABEL_1, {goto_delay[i]})*/
        _2 = (object)SEQ_PTR(_36goto_delay_21881);
        _28077 = (object)*(((s1_ptr)_2)->base + _i_55460);
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        Ref(_28077);
        ((intptr_t*)_2)[1] = _28077;
        _28078 = MAKE_SEQ(_1);
        _28077 = NOVALUE;
        _50CompileErr(156, _28078, 0);
        _28078 = NOVALUE;
L3: 

        /** parser.e:147		end for*/
        _i_55460 = _i_55460 + 1;
        goto L1; // [101] 15
L2: 
        ;
    }

    /** parser.e:148	end procedure*/
    return;
    ;
}


void _45PushGoto()
{
    object _new_1__tmp_at88_55495 = NOVALUE;
    object _new_inlined_new_at_88_55494 = NOVALUE;
    object _28079 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:151		goto_stack = append(goto_stack, {goto_addr, goto_list, goto_labels, goto_delay, goto_line, goto_ref, label_block, goto_init })*/
    _1 = NewS1(8);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_45goto_addr_55368);
    ((intptr_t*)_2)[1] = _45goto_addr_55368;
    RefDS(_36goto_list_21882);
    ((intptr_t*)_2)[2] = _36goto_list_21882;
    RefDS(_45goto_labels_55367);
    ((intptr_t*)_2)[3] = _45goto_labels_55367;
    RefDS(_36goto_delay_21881);
    ((intptr_t*)_2)[4] = _36goto_delay_21881;
    RefDS(_45goto_line_55366);
    ((intptr_t*)_2)[5] = _45goto_line_55366;
    RefDS(_45goto_ref_55370);
    ((intptr_t*)_2)[6] = _45goto_ref_55370;
    RefDS(_45label_block_55371);
    ((intptr_t*)_2)[7] = _45label_block_55371;
    Ref(_45goto_init_55373);
    ((intptr_t*)_2)[8] = _45goto_init_55373;
    _28079 = MAKE_SEQ(_1);
    RefDS(_28079);
    Append(&_45goto_stack_55369, _45goto_stack_55369, _28079);
    DeRefDS(_28079);
    _28079 = NOVALUE;

    /** parser.e:152		goto_addr = {}*/
    RefDS(_22190);
    DeRefDS(_45goto_addr_55368);
    _45goto_addr_55368 = _22190;

    /** parser.e:153		goto_list = {}*/
    RefDS(_22190);
    DeRefDS(_36goto_list_21882);
    _36goto_list_21882 = _22190;

    /** parser.e:154		goto_labels = {}*/
    RefDS(_22190);
    DeRefDS(_45goto_labels_55367);
    _45goto_labels_55367 = _22190;

    /** parser.e:155		goto_delay = {}*/
    RefDS(_22190);
    DeRefDS(_36goto_delay_21881);
    _36goto_delay_21881 = _22190;

    /** parser.e:156		goto_line = {}*/
    RefDS(_22190);
    DeRefDS(_45goto_line_55366);
    _45goto_line_55366 = _22190;

    /** parser.e:157		goto_ref = {}*/
    RefDS(_22190);
    DeRefDS(_45goto_ref_55370);
    _45goto_ref_55370 = _22190;

    /** parser.e:158		label_block = {}*/
    RefDS(_22190);
    DeRefDS(_45label_block_55371);
    _45label_block_55371 = _22190;

    /** parser.e:159		goto_init = map:new()*/

    /** map.e:271		return eumem:malloc( new_map_seq( initial_size_p ) )*/
    _0 = _new_1__tmp_at88_55495;
    _new_1__tmp_at88_55495 = _29new_map_seq(8);
    DeRef(_0);
    Ref(_new_1__tmp_at88_55495);
    _0 = _30malloc(_new_1__tmp_at88_55495, 1);
    DeRef(_45goto_init_55373);
    _45goto_init_55373 = _0;
    DeRef(_new_1__tmp_at88_55495);
    _new_1__tmp_at88_55495 = NOVALUE;

    /** parser.e:160	end procedure*/
    return;
    ;
}


void _45PopGoto()
{
    object _28105 = NOVALUE;
    object _28103 = NOVALUE;
    object _28102 = NOVALUE;
    object _28100 = NOVALUE;
    object _28099 = NOVALUE;
    object _28097 = NOVALUE;
    object _28096 = NOVALUE;
    object _28094 = NOVALUE;
    object _28093 = NOVALUE;
    object _28091 = NOVALUE;
    object _28090 = NOVALUE;
    object _28088 = NOVALUE;
    object _28087 = NOVALUE;
    object _28085 = NOVALUE;
    object _28084 = NOVALUE;
    object _28082 = NOVALUE;
    object _28081 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:163		CheckForUndefinedGotoLabels()*/
    _45CheckForUndefinedGotoLabels();

    /** parser.e:164		goto_addr   = goto_stack[$][1]*/
    if (IS_SEQUENCE(_45goto_stack_55369)){
            _28081 = SEQ_PTR(_45goto_stack_55369)->length;
    }
    else {
        _28081 = 1;
    }
    _2 = (object)SEQ_PTR(_45goto_stack_55369);
    _28082 = (object)*(((s1_ptr)_2)->base + _28081);
    DeRef(_45goto_addr_55368);
    _2 = (object)SEQ_PTR(_28082);
    _45goto_addr_55368 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_45goto_addr_55368);
    _28082 = NOVALUE;

    /** parser.e:165		goto_list   = goto_stack[$][2]*/
    if (IS_SEQUENCE(_45goto_stack_55369)){
            _28084 = SEQ_PTR(_45goto_stack_55369)->length;
    }
    else {
        _28084 = 1;
    }
    _2 = (object)SEQ_PTR(_45goto_stack_55369);
    _28085 = (object)*(((s1_ptr)_2)->base + _28084);
    DeRef(_36goto_list_21882);
    _2 = (object)SEQ_PTR(_28085);
    _36goto_list_21882 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_36goto_list_21882);
    _28085 = NOVALUE;

    /** parser.e:166		goto_labels = goto_stack[$][3]*/
    if (IS_SEQUENCE(_45goto_stack_55369)){
            _28087 = SEQ_PTR(_45goto_stack_55369)->length;
    }
    else {
        _28087 = 1;
    }
    _2 = (object)SEQ_PTR(_45goto_stack_55369);
    _28088 = (object)*(((s1_ptr)_2)->base + _28087);
    DeRef(_45goto_labels_55367);
    _2 = (object)SEQ_PTR(_28088);
    _45goto_labels_55367 = (object)*(((s1_ptr)_2)->base + 3);
    Ref(_45goto_labels_55367);
    _28088 = NOVALUE;

    /** parser.e:167		goto_delay  = goto_stack[$][4]*/
    if (IS_SEQUENCE(_45goto_stack_55369)){
            _28090 = SEQ_PTR(_45goto_stack_55369)->length;
    }
    else {
        _28090 = 1;
    }
    _2 = (object)SEQ_PTR(_45goto_stack_55369);
    _28091 = (object)*(((s1_ptr)_2)->base + _28090);
    DeRef(_36goto_delay_21881);
    _2 = (object)SEQ_PTR(_28091);
    _36goto_delay_21881 = (object)*(((s1_ptr)_2)->base + 4);
    Ref(_36goto_delay_21881);
    _28091 = NOVALUE;

    /** parser.e:168		goto_line   = goto_stack[$][5]*/
    if (IS_SEQUENCE(_45goto_stack_55369)){
            _28093 = SEQ_PTR(_45goto_stack_55369)->length;
    }
    else {
        _28093 = 1;
    }
    _2 = (object)SEQ_PTR(_45goto_stack_55369);
    _28094 = (object)*(((s1_ptr)_2)->base + _28093);
    DeRef(_45goto_line_55366);
    _2 = (object)SEQ_PTR(_28094);
    _45goto_line_55366 = (object)*(((s1_ptr)_2)->base + 5);
    Ref(_45goto_line_55366);
    _28094 = NOVALUE;

    /** parser.e:169		goto_ref    = goto_stack[$][6]*/
    if (IS_SEQUENCE(_45goto_stack_55369)){
            _28096 = SEQ_PTR(_45goto_stack_55369)->length;
    }
    else {
        _28096 = 1;
    }
    _2 = (object)SEQ_PTR(_45goto_stack_55369);
    _28097 = (object)*(((s1_ptr)_2)->base + _28096);
    DeRef(_45goto_ref_55370);
    _2 = (object)SEQ_PTR(_28097);
    _45goto_ref_55370 = (object)*(((s1_ptr)_2)->base + 6);
    Ref(_45goto_ref_55370);
    _28097 = NOVALUE;

    /** parser.e:170		label_block = goto_stack[$][7]*/
    if (IS_SEQUENCE(_45goto_stack_55369)){
            _28099 = SEQ_PTR(_45goto_stack_55369)->length;
    }
    else {
        _28099 = 1;
    }
    _2 = (object)SEQ_PTR(_45goto_stack_55369);
    _28100 = (object)*(((s1_ptr)_2)->base + _28099);
    DeRef(_45label_block_55371);
    _2 = (object)SEQ_PTR(_28100);
    _45label_block_55371 = (object)*(((s1_ptr)_2)->base + 7);
    Ref(_45label_block_55371);
    _28100 = NOVALUE;

    /** parser.e:171		goto_init   = goto_stack[$][8]*/
    if (IS_SEQUENCE(_45goto_stack_55369)){
            _28102 = SEQ_PTR(_45goto_stack_55369)->length;
    }
    else {
        _28102 = 1;
    }
    _2 = (object)SEQ_PTR(_45goto_stack_55369);
    _28103 = (object)*(((s1_ptr)_2)->base + _28102);
    DeRef(_45goto_init_55373);
    _2 = (object)SEQ_PTR(_28103);
    _45goto_init_55373 = (object)*(((s1_ptr)_2)->base + 8);
    Ref(_45goto_init_55373);
    _28103 = NOVALUE;

    /** parser.e:173		goto_stack = remove( goto_stack, length( goto_stack ) )*/
    if (IS_SEQUENCE(_45goto_stack_55369)){
            _28105 = SEQ_PTR(_45goto_stack_55369)->length;
    }
    else {
        _28105 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_45goto_stack_55369);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_28105)) ? _28105 : (object)(DBL_PTR(_28105)->dbl);
        int stop = (IS_ATOM_INT(_28105)) ? _28105 : (object)(DBL_PTR(_28105)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_45goto_stack_55369), start, &_45goto_stack_55369 );
            }
            else Tail(SEQ_PTR(_45goto_stack_55369), stop+1, &_45goto_stack_55369);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_45goto_stack_55369), start, &_45goto_stack_55369);
        }
        else {
            assign_slice_seq = &assign_space;
            _45goto_stack_55369 = Remove_elements(start, stop, (SEQ_PTR(_45goto_stack_55369)->ref == 1));
        }
    }
    _28105 = NOVALUE;
    _28105 = NOVALUE;

    /** parser.e:175	end procedure*/
    return;
    ;
}


void _45EnterTopLevel(object _end_line_table_55528)
{
    object _28124 = NOVALUE;
    object _28123 = NOVALUE;
    object _28121 = NOVALUE;
    object _28120 = NOVALUE;
    object _28118 = NOVALUE;
    object _28116 = NOVALUE;
    object _28114 = NOVALUE;
    object _28112 = NOVALUE;
    object _28111 = NOVALUE;
    object _28109 = NOVALUE;
    object _28107 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:179		if CurrentSub then*/
    if (_36CurrentSub_21775 == 0)
    {
        goto L1; // [7] 59
    }
    else{
    }

    /** parser.e:180			if end_line_table then*/
    if (_end_line_table_55528 == 0)
    {
        goto L2; // [12] 58
    }
    else{
    }

    /** parser.e:181				EndLineTable()*/
    _45EndLineTable();

    /** parser.e:182				SymTab[CurrentSub][S_LINETAB] = LineTable*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_36CurrentSub_21775 + ((s1_ptr)_2)->base);
    RefDS(_36LineTable_21860);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_LINETAB_21439))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_LINETAB_21439)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_LINETAB_21439);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36LineTable_21860;
    DeRef(_1);
    _28107 = NOVALUE;

    /** parser.e:183				SymTab[CurrentSub][S_CODE] = Code*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_36CurrentSub_21775 + ((s1_ptr)_2)->base);
    RefDS(_36Code_21859);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_CODE_21416))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21416)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_CODE_21416);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36Code_21859;
    DeRef(_1);
    _28109 = NOVALUE;
L2: 
L1: 

    /** parser.e:186		if length(goto_stack) then*/
    if (IS_SEQUENCE(_45goto_stack_55369)){
            _28111 = SEQ_PTR(_45goto_stack_55369)->length;
    }
    else {
        _28111 = 1;
    }
    if (_28111 == 0)
    {
        _28111 = NOVALUE;
        goto L3; // [66] 74
    }
    else{
        _28111 = NOVALUE;
    }

    /** parser.e:187			PopGoto()*/
    _45PopGoto();
L3: 

    /** parser.e:189		LineTable = SymTab[TopLevelSub][S_LINETAB]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _28112 = (object)*(((s1_ptr)_2)->base + _36TopLevelSub_21774);
    DeRef(_36LineTable_21860);
    _2 = (object)SEQ_PTR(_28112);
    if (!IS_ATOM_INT(_36S_LINETAB_21439)){
        _36LineTable_21860 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_LINETAB_21439)->dbl));
    }
    else{
        _36LineTable_21860 = (object)*(((s1_ptr)_2)->base + _36S_LINETAB_21439);
    }
    Ref(_36LineTable_21860);
    _28112 = NOVALUE;

    /** parser.e:190		Code = SymTab[TopLevelSub][S_CODE]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _28114 = (object)*(((s1_ptr)_2)->base + _36TopLevelSub_21774);
    DeRef(_36Code_21859);
    _2 = (object)SEQ_PTR(_28114);
    if (!IS_ATOM_INT(_36S_CODE_21416)){
        _36Code_21859 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21416)->dbl));
    }
    else{
        _36Code_21859 = (object)*(((s1_ptr)_2)->base + _36S_CODE_21416);
    }
    Ref(_36Code_21859);
    _28114 = NOVALUE;

    /** parser.e:191		SymTab[TopLevelSub][S_LINETAB] = 0*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_36TopLevelSub_21774 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_LINETAB_21439))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_LINETAB_21439)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_LINETAB_21439);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);
    _28116 = NOVALUE;

    /** parser.e:192		SymTab[TopLevelSub][S_CODE] = 0*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_36TopLevelSub_21774 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_CODE_21416))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21416)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_CODE_21416);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);
    _28118 = NOVALUE;

    /** parser.e:193		previous_op = -1*/
    _36previous_op_21869 = -1;

    /** parser.e:194		CurrentSub = TopLevelSub*/
    _36CurrentSub_21775 = _36TopLevelSub_21774;

    /** parser.e:195		clear_last()*/
    _47clear_last();

    /** parser.e:196		if length( branch_stack ) then*/
    if (IS_SEQUENCE(_45branch_stack_55355)){
            _28120 = SEQ_PTR(_45branch_stack_55355)->length;
    }
    else {
        _28120 = 1;
    }
    if (_28120 == 0)
    {
        _28120 = NOVALUE;
        goto L4; // [171] 205
    }
    else{
        _28120 = NOVALUE;
    }

    /** parser.e:197			branch_list = branch_stack[$]*/
    if (IS_SEQUENCE(_45branch_stack_55355)){
            _28121 = SEQ_PTR(_45branch_stack_55355)->length;
    }
    else {
        _28121 = 1;
    }
    DeRef(_45branch_list_55354);
    _2 = (object)SEQ_PTR(_45branch_stack_55355);
    _45branch_list_55354 = (object)*(((s1_ptr)_2)->base + _28121);
    Ref(_45branch_list_55354);

    /** parser.e:198			branch_stack = tail( branch_stack )*/
    if (IS_SEQUENCE(_45branch_stack_55355)){
            _28123 = SEQ_PTR(_45branch_stack_55355)->length;
    }
    else {
        _28123 = 1;
    }
    _28124 = _28123 - 1;
    _28123 = NOVALUE;
    {
        int len = SEQ_PTR(_45branch_stack_55355)->length;
        int size = (IS_ATOM_INT(_28124)) ? _28124 : (object)(DBL_PTR(_28124)->dbl);
        if (size <= 0) {
            DeRef(_45branch_stack_55355);
            _45branch_stack_55355 = MAKE_SEQ(NewS1(0));
        }
        else if (len <= size) {
            RefDS(_45branch_stack_55355);
            DeRef(_45branch_stack_55355);
            _45branch_stack_55355 = _45branch_stack_55355;
        }
        else Tail(SEQ_PTR(_45branch_stack_55355), len-size+1, &_45branch_stack_55355);
    }
    _28124 = NOVALUE;
L4: 

    /** parser.e:200	end procedure*/
    return;
    ;
}


void _45LeaveTopLevel()
{
    object _28129 = NOVALUE;
    object _28127 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:204		branch_stack = append( branch_stack, branch_list )*/
    RefDS(_45branch_list_55354);
    Append(&_45branch_stack_55355, _45branch_stack_55355, _45branch_list_55354);

    /** parser.e:205		branch_list = {}*/
    RefDS(_22190);
    DeRefDS(_45branch_list_55354);
    _45branch_list_55354 = _22190;

    /** parser.e:206		PushGoto()*/
    _45PushGoto();

    /** parser.e:207		LastLineNumber = -1*/
    _62LastLineNumber_25877 = -1;

    /** parser.e:208		SymTab[TopLevelSub][S_LINETAB] = LineTable*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_36TopLevelSub_21774 + ((s1_ptr)_2)->base);
    RefDS(_36LineTable_21860);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_LINETAB_21439))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_LINETAB_21439)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_LINETAB_21439);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36LineTable_21860;
    DeRef(_1);
    _28127 = NOVALUE;

    /** parser.e:209		SymTab[TopLevelSub][S_CODE] = Code*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_36TopLevelSub_21774 + ((s1_ptr)_2)->base);
    RefDS(_36Code_21859);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_CODE_21416))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21416)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_CODE_21416);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36Code_21859;
    DeRef(_1);
    _28129 = NOVALUE;

    /** parser.e:210		LineTable = {}*/
    RefDS(_22190);
    DeRefDS(_36LineTable_21860);
    _36LineTable_21860 = _22190;

    /** parser.e:211		Code = {}*/
    RefDS(_22190);
    DeRefDS(_36Code_21859);
    _36Code_21859 = _22190;

    /** parser.e:212		previous_op = -1*/
    _36previous_op_21869 = -1;

    /** parser.e:213		clear_last()*/
    _47clear_last();

    /** parser.e:214	end procedure*/
    return;
    ;
}


void _45InitParser()
{
    object _new_1__tmp_at195_55604 = NOVALUE;
    object _new_inlined_new_at_195_55603 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:217		goto_stack = {}*/
    RefDS(_22190);
    DeRef(_45goto_stack_55369);
    _45goto_stack_55369 = _22190;

    /** parser.e:220		goto_labels = {}*/
    RefDS(_22190);
    DeRef(_45goto_labels_55367);
    _45goto_labels_55367 = _22190;

    /** parser.e:221		label_block = {}*/
    RefDS(_22190);
    DeRef(_45label_block_55371);
    _45label_block_55371 = _22190;

    /** parser.e:222		goto_ref = {}*/
    RefDS(_22190);
    DeRef(_45goto_ref_55370);
    _45goto_ref_55370 = _22190;

    /** parser.e:223		goto_addr = {}*/
    RefDS(_22190);
    DeRef(_45goto_addr_55368);
    _45goto_addr_55368 = _22190;

    /** parser.e:224		goto_line = {}*/
    RefDS(_22190);
    DeRef(_45goto_line_55366);
    _45goto_line_55366 = _22190;

    /** parser.e:225		break_list = {}*/
    RefDS(_22190);
    DeRefi(_45break_list_55374);
    _45break_list_55374 = _22190;

    /** parser.e:226		break_delay = {}*/
    RefDS(_22190);
    DeRef(_45break_delay_55375);
    _45break_delay_55375 = _22190;

    /** parser.e:227		exit_list = {}*/
    RefDS(_22190);
    DeRefi(_45exit_list_55376);
    _45exit_list_55376 = _22190;

    /** parser.e:228		exit_delay = {}*/
    RefDS(_22190);
    DeRef(_45exit_delay_55377);
    _45exit_delay_55377 = _22190;

    /** parser.e:229		continue_list = {}*/
    RefDS(_22190);
    DeRefi(_45continue_list_55378);
    _45continue_list_55378 = _22190;

    /** parser.e:230		continue_delay = {}*/
    RefDS(_22190);
    DeRef(_45continue_delay_55379);
    _45continue_delay_55379 = _22190;

    /** parser.e:231		init_stack = {}*/
    RefDS(_22190);
    DeRefi(_45init_stack_55389);
    _45init_stack_55389 = _22190;

    /** parser.e:232		CurrentSub = 0*/
    _36CurrentSub_21775 = 0;

    /** parser.e:233		CreateTopLevel()*/
    _45CreateTopLevel();

    /** parser.e:234		EnterTopLevel()*/
    _45EnterTopLevel(1);

    /** parser.e:235		backed_up_tok = {}*/
    RefDS(_22190);
    DeRef(_45backed_up_tok_55363);
    _45backed_up_tok_55363 = _22190;

    /** parser.e:236		loop_stack = {}*/
    RefDS(_22190);
    DeRefi(_45loop_stack_55390);
    _45loop_stack_55390 = _22190;

    /** parser.e:237		stmt_nest = 0*/
    _45stmt_nest_55388 = 0;

    /** parser.e:238		loop_labels = {}*/
    RefDS(_22190);
    DeRef(_45loop_labels_55384);
    _45loop_labels_55384 = _22190;

    /** parser.e:239		if_labels = {}*/
    RefDS(_22190);
    DeRef(_45if_labels_55385);
    _45if_labels_55385 = _22190;

    /** parser.e:240		if_stack = {}*/
    RefDS(_22190);
    DeRefi(_45if_stack_55391);
    _45if_stack_55391 = _22190;

    /** parser.e:241		continue_addr = {}*/
    RefDS(_22190);
    DeRefi(_45continue_addr_55381);
    _45continue_addr_55381 = _22190;

    /** parser.e:242		retry_addr = {}*/
    RefDS(_22190);
    DeRefi(_45retry_addr_55382);
    _45retry_addr_55382 = _22190;

    /** parser.e:243		entry_addr = {}*/
    RefDS(_22190);
    DeRefi(_45entry_addr_55380);
    _45entry_addr_55380 = _22190;

    /** parser.e:244		block_list = {}*/
    RefDS(_22190);
    DeRefi(_45block_list_55386);
    _45block_list_55386 = _22190;

    /** parser.e:245		block_index = 0*/
    _45block_index_55387 = 0;

    /** parser.e:246		param_num = -1*/
    _45param_num_55365 = -1;

    /** parser.e:247		entry_stack = {}*/
    RefDS(_22190);
    DeRef(_45entry_stack_55383);
    _45entry_stack_55383 = _22190;

    /** parser.e:248		goto_init = map:new()*/

    /** map.e:271		return eumem:malloc( new_map_seq( initial_size_p ) )*/
    _0 = _new_1__tmp_at195_55604;
    _new_1__tmp_at195_55604 = _29new_map_seq(8);
    DeRef(_0);
    Ref(_new_1__tmp_at195_55604);
    _0 = _30malloc(_new_1__tmp_at195_55604, 1);
    DeRef(_45goto_init_55373);
    _45goto_init_55373 = _0;
    DeRef(_new_1__tmp_at195_55604);
    _new_1__tmp_at195_55604 = NOVALUE;

    /** parser.e:249	end procedure*/
    return;
    ;
}


void _45NotReached(object _tok_55621, object _keyword_55622)
{
    object _28144 = NOVALUE;
    object _28143 = NOVALUE;
    object _28142 = NOVALUE;
    object _28141 = NOVALUE;
    object _28140 = NOVALUE;
    object _28139 = NOVALUE;
    object _28137 = NOVALUE;
    object _28136 = NOVALUE;
    object _28135 = NOVALUE;
    object _28134 = NOVALUE;
    object _28132 = NOVALUE;
    object _28131 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_tok_55621)) {
        _1 = (object)(DBL_PTR(_tok_55621)->dbl);
        DeRefDS(_tok_55621);
        _tok_55621 = _1;
    }

    /** parser.e:271		if not find(tok, {END, ELSE, ELSIF, END_OF_FILE, CASE, IFDEF, ELSIFDEF, ELSEDEF}) then*/
    _1 = NewS1(8);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 402;
    ((intptr_t*)_2)[2] = 23;
    ((intptr_t*)_2)[3] = 414;
    ((intptr_t*)_2)[4] = -21;
    ((intptr_t*)_2)[5] = 186;
    ((intptr_t*)_2)[6] = 407;
    ((intptr_t*)_2)[7] = 408;
    ((intptr_t*)_2)[8] = 409;
    _28131 = MAKE_SEQ(_1);
    _28132 = find_from(_tok_55621, _28131, 1);
    DeRefDS(_28131);
    _28131 = NOVALUE;
    if (_28132 != 0)
    goto L1; // [39] 135
    _28132 = NOVALUE;

    /** parser.e:272			if equal(keyword, "goto") and find(tok, {LOOP, LABEL, WHILE}) then*/
    if (_keyword_55622 == _26471)
    _28134 = 1;
    else if (IS_ATOM_INT(_keyword_55622) && IS_ATOM_INT(_26471))
    _28134 = 0;
    else
    _28134 = (compare(_keyword_55622, _26471) == 0);
    if (_28134 == 0) {
        goto L2; // [48] 79
    }
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 422;
    ((intptr_t*)_2)[2] = 419;
    ((intptr_t*)_2)[3] = 47;
    _28136 = MAKE_SEQ(_1);
    _28137 = find_from(_tok_55621, _28136, 1);
    DeRefDS(_28136);
    _28136 = NOVALUE;
    if (_28137 == 0)
    {
        _28137 = NOVALUE;
        goto L2; // [70] 79
    }
    else{
        _28137 = NOVALUE;
    }

    /** parser.e:273				return*/
    DeRefDSi(_keyword_55622);
    return;
L2: 

    /** parser.e:275			if equal(keyword, "abort()") and tok = LABEL then*/
    if (_keyword_55622 == _28138)
    _28139 = 1;
    else if (IS_ATOM_INT(_keyword_55622) && IS_ATOM_INT(_28138))
    _28139 = 0;
    else
    _28139 = (compare(_keyword_55622, _28138) == 0);
    if (_28139 == 0) {
        goto L3; // [85] 105
    }
    _28141 = (_tok_55621 == 419);
    if (_28141 == 0)
    {
        DeRef(_28141);
        _28141 = NOVALUE;
        goto L3; // [96] 105
    }
    else{
        DeRef(_28141);
        _28141 = NOVALUE;
    }

    /** parser.e:278				return*/
    DeRefDSi(_keyword_55622);
    return;
L3: 

    /** parser.e:280			Warning(218, not_reached_warning_flag,*/
    _2 = (object)SEQ_PTR(_37known_files_15638);
    _28142 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21767);
    Ref(_28142);
    _28143 = _54name_ext(_28142);
    _28142 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _28143;
    ((intptr_t*)_2)[2] = _36line_number_21768;
    RefDS(_keyword_55622);
    ((intptr_t*)_2)[3] = _keyword_55622;
    _28144 = MAKE_SEQ(_1);
    _28143 = NOVALUE;
    _50Warning(218, 512, _28144);
    _28144 = NOVALUE;
L1: 

    /** parser.e:285	end procedure*/
    DeRefDSi(_keyword_55622);
    return;
    ;
}


void _45Forward_InitCheck(object _tok_55661, object _ref_55662)
{
    object _sym_55664 = NOVALUE;
    object _28150 = NOVALUE;
    object _28149 = NOVALUE;
    object _28148 = NOVALUE;
    object _28146 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:289		if ref then*/
    if (_ref_55662 == 0)
    {
        goto L1; // [5] 83
    }
    else{
    }

    /** parser.e:290			integer sym = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_55661);
    _sym_55664 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_sym_55664)){
        _sym_55664 = (object)DBL_PTR(_sym_55664)->dbl;
    }

    /** parser.e:291			if tok[T_ID] = QUALIFIED_VARIABLE then*/
    _2 = (object)SEQ_PTR(_tok_55661);
    _28146 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28146, 512)){
        _28146 = NOVALUE;
        goto L2; // [28] 50
    }
    _28146 = NOVALUE;

    /** parser.e:292				set_qualified_fwd( SymTab[sym][S_FILE_NO] )*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _28148 = (object)*(((s1_ptr)_2)->base + _sym_55664);
    _2 = (object)SEQ_PTR(_28148);
    if (!IS_ATOM_INT(_36S_FILE_NO_21400)){
        _28149 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21400)->dbl));
    }
    else{
        _28149 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21400);
    }
    _28148 = NOVALUE;
    Ref(_28149);
    _62set_qualified_fwd(_28149);
    _28149 = NOVALUE;
L2: 

    /** parser.e:294			ref = new_forward_reference( GLOBAL_INIT_CHECK, tok[T_SYM], GLOBAL_INIT_CHECK )*/
    _2 = (object)SEQ_PTR(_tok_55661);
    _28150 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_28150);
    _ref_55662 = _44new_forward_reference(109, _28150, 109);
    _28150 = NOVALUE;
    if (!IS_ATOM_INT(_ref_55662)) {
        _1 = (object)(DBL_PTR(_ref_55662)->dbl);
        DeRefDS(_ref_55662);
        _ref_55662 = _1;
    }

    /** parser.e:296			emit_op( GLOBAL_INIT_CHECK )*/
    _47emit_op(109);

    /** parser.e:297			emit_addr( sym )*/
    _47emit_addr(_sym_55664);
L1: 

    /** parser.e:299	end procedure*/
    DeRef(_tok_55661);
    return;
    ;
}


void _45InitCheck(object _sym_55689, object _ref_55690)
{
    object _28227 = NOVALUE;
    object _28226 = NOVALUE;
    object _28225 = NOVALUE;
    object _28224 = NOVALUE;
    object _28223 = NOVALUE;
    object _28222 = NOVALUE;
    object _28221 = NOVALUE;
    object _28220 = NOVALUE;
    object _28218 = NOVALUE;
    object _28216 = NOVALUE;
    object _28215 = NOVALUE;
    object _28213 = NOVALUE;
    object _28212 = NOVALUE;
    object _28211 = NOVALUE;
    object _28210 = NOVALUE;
    object _28209 = NOVALUE;
    object _28208 = NOVALUE;
    object _28207 = NOVALUE;
    object _28206 = NOVALUE;
    object _28205 = NOVALUE;
    object _28204 = NOVALUE;
    object _28203 = NOVALUE;
    object _28202 = NOVALUE;
    object _28201 = NOVALUE;
    object _28200 = NOVALUE;
    object _28198 = NOVALUE;
    object _28197 = NOVALUE;
    object _28196 = NOVALUE;
    object _28195 = NOVALUE;
    object _28194 = NOVALUE;
    object _28193 = NOVALUE;
    object _28192 = NOVALUE;
    object _28191 = NOVALUE;
    object _28190 = NOVALUE;
    object _28188 = NOVALUE;
    object _28187 = NOVALUE;
    object _28186 = NOVALUE;
    object _28185 = NOVALUE;
    object _28184 = NOVALUE;
    object _28183 = NOVALUE;
    object _28182 = NOVALUE;
    object _28181 = NOVALUE;
    object _28180 = NOVALUE;
    object _28179 = NOVALUE;
    object _28178 = NOVALUE;
    object _28177 = NOVALUE;
    object _28176 = NOVALUE;
    object _28175 = NOVALUE;
    object _28174 = NOVALUE;
    object _28173 = NOVALUE;
    object _28172 = NOVALUE;
    object _28171 = NOVALUE;
    object _28170 = NOVALUE;
    object _28169 = NOVALUE;
    object _28168 = NOVALUE;
    object _28167 = NOVALUE;
    object _28165 = NOVALUE;
    object _28164 = NOVALUE;
    object _28163 = NOVALUE;
    object _28162 = NOVALUE;
    object _28161 = NOVALUE;
    object _28160 = NOVALUE;
    object _28159 = NOVALUE;
    object _28158 = NOVALUE;
    object _28157 = NOVALUE;
    object _28156 = NOVALUE;
    object _28155 = NOVALUE;
    object _28154 = NOVALUE;
    object _28152 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:306		if sym < 0 or (SymTab[sym][S_MODE] = M_NORMAL and*/
    _28152 = (_sym_55689 < 0);
    if (_28152 != 0) {
        goto L1; // [11] 90
    }
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _28154 = (object)*(((s1_ptr)_2)->base + _sym_55689);
    _2 = (object)SEQ_PTR(_28154);
    _28155 = (object)*(((s1_ptr)_2)->base + 3);
    _28154 = NOVALUE;
    if (IS_ATOM_INT(_28155)) {
        _28156 = (_28155 == 1);
    }
    else {
        _28156 = binary_op(EQUALS, _28155, 1);
    }
    _28155 = NOVALUE;
    if (IS_ATOM_INT(_28156)) {
        if (_28156 == 0) {
            _28157 = 0;
            goto L2; // [33] 59
        }
    }
    else {
        if (DBL_PTR(_28156)->dbl == 0.0) {
            _28157 = 0;
            goto L2; // [33] 59
        }
    }
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _28158 = (object)*(((s1_ptr)_2)->base + _sym_55689);
    _2 = (object)SEQ_PTR(_28158);
    _28159 = (object)*(((s1_ptr)_2)->base + 4);
    _28158 = NOVALUE;
    if (IS_ATOM_INT(_28159)) {
        _28160 = (_28159 != 2);
    }
    else {
        _28160 = binary_op(NOTEQ, _28159, 2);
    }
    _28159 = NOVALUE;
    DeRef(_28157);
    if (IS_ATOM_INT(_28160))
    _28157 = (_28160 != 0);
    else
    _28157 = DBL_PTR(_28160)->dbl != 0.0;
L2: 
    if (_28157 == 0) {
        DeRef(_28161);
        _28161 = 0;
        goto L3; // [59] 85
    }
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _28162 = (object)*(((s1_ptr)_2)->base + _sym_55689);
    _2 = (object)SEQ_PTR(_28162);
    _28163 = (object)*(((s1_ptr)_2)->base + 4);
    _28162 = NOVALUE;
    if (IS_ATOM_INT(_28163)) {
        _28164 = (_28163 != 4);
    }
    else {
        _28164 = binary_op(NOTEQ, _28163, 4);
    }
    _28163 = NOVALUE;
    if (IS_ATOM_INT(_28164))
    _28161 = (_28164 != 0);
    else
    _28161 = DBL_PTR(_28164)->dbl != 0.0;
L3: 
    if (_28161 == 0)
    {
        _28161 = NOVALUE;
        goto L4; // [86] 502
    }
    else{
        _28161 = NOVALUE;
    }
L1: 

    /** parser.e:309			if sym < 0 or ((SymTab[sym][S_SCOPE] != SC_PRIVATE and*/
    _28165 = (_sym_55689 < 0);
    if (_28165 != 0) {
        goto L5; // [96] 213
    }
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _28167 = (object)*(((s1_ptr)_2)->base + _sym_55689);
    _2 = (object)SEQ_PTR(_28167);
    _28168 = (object)*(((s1_ptr)_2)->base + 4);
    _28167 = NOVALUE;
    if (IS_ATOM_INT(_28168)) {
        _28169 = (_28168 != 3);
    }
    else {
        _28169 = binary_op(NOTEQ, _28168, 3);
    }
    _28168 = NOVALUE;
    if (IS_ATOM_INT(_28169)) {
        if (_28169 == 0) {
            DeRef(_28170);
            _28170 = 0;
            goto L6; // [118] 144
        }
    }
    else {
        if (DBL_PTR(_28169)->dbl == 0.0) {
            DeRef(_28170);
            _28170 = 0;
            goto L6; // [118] 144
        }
    }
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _28171 = (object)*(((s1_ptr)_2)->base + _sym_55689);
    _2 = (object)SEQ_PTR(_28171);
    _28172 = (object)*(((s1_ptr)_2)->base + 1);
    _28171 = NOVALUE;
    if (_28172 == _36NOVALUE_21621)
    _28173 = 1;
    else if (IS_ATOM_INT(_28172) && IS_ATOM_INT(_36NOVALUE_21621))
    _28173 = 0;
    else
    _28173 = (compare(_28172, _36NOVALUE_21621) == 0);
    _28172 = NOVALUE;
    DeRef(_28170);
    _28170 = (_28173 != 0);
L6: 
    if (_28170 != 0) {
        DeRef(_28174);
        _28174 = 1;
        goto L7; // [144] 208
    }
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _28175 = (object)*(((s1_ptr)_2)->base + _sym_55689);
    _2 = (object)SEQ_PTR(_28175);
    _28176 = (object)*(((s1_ptr)_2)->base + 4);
    _28175 = NOVALUE;
    if (IS_ATOM_INT(_28176)) {
        _28177 = (_28176 == 3);
    }
    else {
        _28177 = binary_op(EQUALS, _28176, 3);
    }
    _28176 = NOVALUE;
    if (IS_ATOM_INT(_28177)) {
        if (_28177 == 0) {
            DeRef(_28178);
            _28178 = 0;
            goto L8; // [166] 204
        }
    }
    else {
        if (DBL_PTR(_28177)->dbl == 0.0) {
            DeRef(_28178);
            _28178 = 0;
            goto L8; // [166] 204
        }
    }
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _28179 = (object)*(((s1_ptr)_2)->base + _sym_55689);
    _2 = (object)SEQ_PTR(_28179);
    _28180 = (object)*(((s1_ptr)_2)->base + 16);
    _28179 = NOVALUE;
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _28181 = (object)*(((s1_ptr)_2)->base + _36CurrentSub_21775);
    _2 = (object)SEQ_PTR(_28181);
    if (!IS_ATOM_INT(_36S_NUM_ARGS_21455)){
        _28182 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21455)->dbl));
    }
    else{
        _28182 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21455);
    }
    _28181 = NOVALUE;
    if (IS_ATOM_INT(_28180) && IS_ATOM_INT(_28182)) {
        _28183 = (_28180 >= _28182);
    }
    else {
        _28183 = binary_op(GREATEREQ, _28180, _28182);
    }
    _28180 = NOVALUE;
    _28182 = NOVALUE;
    DeRef(_28178);
    if (IS_ATOM_INT(_28183))
    _28178 = (_28183 != 0);
    else
    _28178 = DBL_PTR(_28183)->dbl != 0.0;
L8: 
    DeRef(_28174);
    _28174 = (_28178 != 0);
L7: 
    if (_28174 == 0)
    {
        _28174 = NOVALUE;
        goto L9; // [209] 566
    }
    else{
        _28174 = NOVALUE;
    }
L5: 

    /** parser.e:313				if sym < 0 or (SymTab[sym][S_INITLEVEL] = -1)*/
    _28184 = (_sym_55689 < 0);
    if (_28184 != 0) {
        _28185 = 1;
        goto LA; // [219] 243
    }
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _28186 = (object)*(((s1_ptr)_2)->base + _sym_55689);
    _2 = (object)SEQ_PTR(_28186);
    _28187 = (object)*(((s1_ptr)_2)->base + 14);
    _28186 = NOVALUE;
    if (IS_ATOM_INT(_28187)) {
        _28188 = (_28187 == -1);
    }
    else {
        _28188 = binary_op(EQUALS, _28187, -1);
    }
    _28187 = NOVALUE;
    if (IS_ATOM_INT(_28188))
    _28185 = (_28188 != 0);
    else
    _28185 = DBL_PTR(_28188)->dbl != 0.0;
LA: 
    if (_28185 != 0) {
        goto LB; // [243] 270
    }
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _28190 = (object)*(((s1_ptr)_2)->base + _sym_55689);
    _2 = (object)SEQ_PTR(_28190);
    _28191 = (object)*(((s1_ptr)_2)->base + 4);
    _28190 = NOVALUE;
    if (IS_ATOM_INT(_28191)) {
        _28192 = (_28191 != 3);
    }
    else {
        _28192 = binary_op(NOTEQ, _28191, 3);
    }
    _28191 = NOVALUE;
    if (_28192 == 0) {
        DeRef(_28192);
        _28192 = NOVALUE;
        goto L9; // [266] 566
    }
    else {
        if (!IS_ATOM_INT(_28192) && DBL_PTR(_28192)->dbl == 0.0){
            DeRef(_28192);
            _28192 = NOVALUE;
            goto L9; // [266] 566
        }
        DeRef(_28192);
        _28192 = NOVALUE;
    }
    DeRef(_28192);
    _28192 = NOVALUE;
LB: 

    /** parser.e:316					if ref then*/
    if (_ref_55690 == 0)
    {
        goto LC; // [272] 375
    }
    else{
    }

    /** parser.e:317						if sym > 0 and (SymTab[sym][S_SCOPE] = SC_UNDEFINED) then*/
    _28193 = (_sym_55689 > 0);
    if (_28193 == 0) {
        goto LD; // [281] 317
    }
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _28195 = (object)*(((s1_ptr)_2)->base + _sym_55689);
    _2 = (object)SEQ_PTR(_28195);
    _28196 = (object)*(((s1_ptr)_2)->base + 4);
    _28195 = NOVALUE;
    if (IS_ATOM_INT(_28196)) {
        _28197 = (_28196 == 9);
    }
    else {
        _28197 = binary_op(EQUALS, _28196, 9);
    }
    _28196 = NOVALUE;
    if (_28197 == 0) {
        DeRef(_28197);
        _28197 = NOVALUE;
        goto LD; // [304] 317
    }
    else {
        if (!IS_ATOM_INT(_28197) && DBL_PTR(_28197)->dbl == 0.0){
            DeRef(_28197);
            _28197 = NOVALUE;
            goto LD; // [304] 317
        }
        DeRef(_28197);
        _28197 = NOVALUE;
    }
    DeRef(_28197);
    _28197 = NOVALUE;

    /** parser.e:318							emit_op(PRIVATE_INIT_CHECK)*/
    _47emit_op(30);
    goto LE; // [314] 369
LD: 

    /** parser.e:319						elsif sym < 0 or find(SymTab[sym][S_SCOPE], SCOPE_TYPES) then*/
    _28198 = (_sym_55689 < 0);
    if (_28198 != 0) {
        goto LF; // [323] 351
    }
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _28200 = (object)*(((s1_ptr)_2)->base + _sym_55689);
    _2 = (object)SEQ_PTR(_28200);
    _28201 = (object)*(((s1_ptr)_2)->base + 4);
    _28200 = NOVALUE;
    _28202 = find_from(_28201, _45SCOPE_TYPES_55347, 1);
    _28201 = NOVALUE;
    if (_28202 == 0)
    {
        _28202 = NOVALUE;
        goto L10; // [347] 361
    }
    else{
        _28202 = NOVALUE;
    }
LF: 

    /** parser.e:320							emit_op(GLOBAL_INIT_CHECK) -- will become NOP2*/
    _47emit_op(109);
    goto LE; // [358] 369
L10: 

    /** parser.e:322							emit_op(PRIVATE_INIT_CHECK)*/
    _47emit_op(30);
LE: 

    /** parser.e:324						emit_addr(sym)*/
    _47emit_addr(_sym_55689);
LC: 

    /** parser.e:326					if sym > 0 */
    _28203 = (_sym_55689 > 0);
    if (_28203 == 0) {
        _28204 = 0;
        goto L11; // [381] 411
    }
    _28205 = (_45short_circuit_55356 <= 0);
    if (_28205 != 0) {
        _28206 = 1;
        goto L12; // [391] 407
    }
    _28207 = (_45short_circuit_B_55358 == _13FALSE_445);
    _28206 = (_28207 != 0);
L12: 
    _28204 = (_28206 != 0);
L11: 
    if (_28204 == 0) {
        goto L9; // [411] 566
    }
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _28209 = (object)*(((s1_ptr)_2)->base + _sym_55689);
    _2 = (object)SEQ_PTR(_28209);
    _28210 = (object)*(((s1_ptr)_2)->base + 4);
    _28209 = NOVALUE;
    if (IS_ATOM_INT(_28210)) {
        _28211 = (_28210 != 3);
    }
    else {
        _28211 = binary_op(NOTEQ, _28210, 3);
    }
    _28210 = NOVALUE;
    if (IS_ATOM_INT(_28211)) {
        _28212 = (_28211 == 0);
    }
    else {
        _28212 = unary_op(NOT, _28211);
    }
    DeRef(_28211);
    _28211 = NOVALUE;
    if (_28212 == 0) {
        DeRef(_28212);
        _28212 = NOVALUE;
        goto L9; // [437] 566
    }
    else {
        if (!IS_ATOM_INT(_28212) && DBL_PTR(_28212)->dbl == 0.0){
            DeRef(_28212);
            _28212 = NOVALUE;
            goto L9; // [437] 566
        }
        DeRef(_28212);
        _28212 = NOVALUE;
    }
    DeRef(_28212);
    _28212 = NOVALUE;

    /** parser.e:330						if CurrentSub != TopLevelSub */
    _28213 = (_36CurrentSub_21775 != _36TopLevelSub_21774);
    if (_28213 != 0) {
        goto L13; // [450] 470
    }
    if (IS_SEQUENCE(_37known_files_15638)){
            _28215 = SEQ_PTR(_37known_files_15638)->length;
    }
    else {
        _28215 = 1;
    }
    _28216 = (_36current_file_no_21767 == _28215);
    _28215 = NOVALUE;
    if (_28216 == 0)
    {
        DeRef(_28216);
        _28216 = NOVALUE;
        goto L9; // [466] 566
    }
    else{
        DeRef(_28216);
        _28216 = NOVALUE;
    }
L13: 

    /** parser.e:335							init_stack = append(init_stack, sym)*/
    Append(&_45init_stack_55389, _45init_stack_55389, _sym_55689);

    /** parser.e:336							SymTab[sym][S_INITLEVEL] = stmt_nest*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_55689 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 14);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _45stmt_nest_55388;
    DeRef(_1);
    _28218 = NOVALUE;
    goto L9; // [499] 566
L4: 

    /** parser.e:343		elsif ref and sym > 0 and sym_mode( sym ) = M_CONSTANT and equal( NOVALUE, sym_obj( sym ) ) then*/
    if (_ref_55690 == 0) {
        _28220 = 0;
        goto L14; // [504] 516
    }
    _28221 = (_sym_55689 > 0);
    _28220 = (_28221 != 0);
L14: 
    if (_28220 == 0) {
        _28222 = 0;
        goto L15; // [516] 534
    }
    _28223 = _54sym_mode(_sym_55689);
    if (IS_ATOM_INT(_28223)) {
        _28224 = (_28223 == 2);
    }
    else {
        _28224 = binary_op(EQUALS, _28223, 2);
    }
    DeRef(_28223);
    _28223 = NOVALUE;
    if (IS_ATOM_INT(_28224))
    _28222 = (_28224 != 0);
    else
    _28222 = DBL_PTR(_28224)->dbl != 0.0;
L15: 
    if (_28222 == 0) {
        goto L16; // [534] 565
    }
    _28226 = _54sym_obj(_sym_55689);
    if (_36NOVALUE_21621 == _28226)
    _28227 = 1;
    else if (IS_ATOM_INT(_36NOVALUE_21621) && IS_ATOM_INT(_28226))
    _28227 = 0;
    else
    _28227 = (compare(_36NOVALUE_21621, _28226) == 0);
    DeRef(_28226);
    _28226 = NOVALUE;
    if (_28227 == 0)
    {
        _28227 = NOVALUE;
        goto L16; // [549] 565
    }
    else{
        _28227 = NOVALUE;
    }

    /** parser.e:344			emit_op( GLOBAL_INIT_CHECK )*/
    _47emit_op(109);

    /** parser.e:345			emit_addr(sym)*/
    _47emit_addr(_sym_55689);
L16: 
L9: 

    /** parser.e:349	end procedure*/
    DeRef(_28160);
    _28160 = NOVALUE;
    DeRef(_28188);
    _28188 = NOVALUE;
    DeRef(_28221);
    _28221 = NOVALUE;
    DeRef(_28213);
    _28213 = NOVALUE;
    DeRef(_28224);
    _28224 = NOVALUE;
    DeRef(_28198);
    _28198 = NOVALUE;
    DeRef(_28169);
    _28169 = NOVALUE;
    DeRef(_28193);
    _28193 = NOVALUE;
    DeRef(_28177);
    _28177 = NOVALUE;
    DeRef(_28207);
    _28207 = NOVALUE;
    DeRef(_28183);
    _28183 = NOVALUE;
    DeRef(_28205);
    _28205 = NOVALUE;
    DeRef(_28165);
    _28165 = NOVALUE;
    DeRef(_28164);
    _28164 = NOVALUE;
    DeRef(_28203);
    _28203 = NOVALUE;
    DeRef(_28152);
    _28152 = NOVALUE;
    DeRef(_28156);
    _28156 = NOVALUE;
    DeRef(_28184);
    _28184 = NOVALUE;
    return;
    ;
}


void _45InitDelete()
{
    object _28240 = NOVALUE;
    object _28239 = NOVALUE;
    object _28237 = NOVALUE;
    object _28236 = NOVALUE;
    object _28235 = NOVALUE;
    object _28234 = NOVALUE;
    object _28233 = NOVALUE;
    object _28232 = NOVALUE;
    object _28231 = NOVALUE;
    object _28230 = NOVALUE;
    object _28229 = NOVALUE;
    object _28228 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:354		while length(init_stack) and*/
L1: 
    if (IS_SEQUENCE(_45init_stack_55389)){
            _28228 = SEQ_PTR(_45init_stack_55389)->length;
    }
    else {
        _28228 = 1;
    }
    if (_28228 == 0) {
        goto L2; // [11] 91
    }
    if (IS_SEQUENCE(_45init_stack_55389)){
            _28230 = SEQ_PTR(_45init_stack_55389)->length;
    }
    else {
        _28230 = 1;
    }
    _2 = (object)SEQ_PTR(_45init_stack_55389);
    _28231 = (object)*(((s1_ptr)_2)->base + _28230);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _28232 = (object)*(((s1_ptr)_2)->base + _28231);
    _2 = (object)SEQ_PTR(_28232);
    _28233 = (object)*(((s1_ptr)_2)->base + 14);
    _28232 = NOVALUE;
    if (IS_ATOM_INT(_28233)) {
        _28234 = (_28233 > _45stmt_nest_55388);
    }
    else {
        _28234 = binary_op(GREATER, _28233, _45stmt_nest_55388);
    }
    _28233 = NOVALUE;
    if (_28234 <= 0) {
        if (_28234 == 0) {
            DeRef(_28234);
            _28234 = NOVALUE;
            goto L2; // [43] 91
        }
        else {
            if (!IS_ATOM_INT(_28234) && DBL_PTR(_28234)->dbl == 0.0){
                DeRef(_28234);
                _28234 = NOVALUE;
                goto L2; // [43] 91
            }
            DeRef(_28234);
            _28234 = NOVALUE;
        }
    }
    DeRef(_28234);
    _28234 = NOVALUE;

    /** parser.e:356			SymTab[init_stack[$]][S_INITLEVEL] = -1*/
    if (IS_SEQUENCE(_45init_stack_55389)){
            _28235 = SEQ_PTR(_45init_stack_55389)->length;
    }
    else {
        _28235 = 1;
    }
    _2 = (object)SEQ_PTR(_45init_stack_55389);
    _28236 = (object)*(((s1_ptr)_2)->base + _28235);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_28236 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 14);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = -1;
    DeRef(_1);
    _28237 = NOVALUE;

    /** parser.e:357			init_stack = init_stack[1..$-1]*/
    if (IS_SEQUENCE(_45init_stack_55389)){
            _28239 = SEQ_PTR(_45init_stack_55389)->length;
    }
    else {
        _28239 = 1;
    }
    _28240 = _28239 - 1;
    _28239 = NOVALUE;
    rhs_slice_target = (object_ptr)&_45init_stack_55389;
    RHS_Slice(_45init_stack_55389, 1, _28240);

    /** parser.e:358		end while*/
    goto L1; // [88] 6
L2: 

    /** parser.e:359	end procedure*/
    _28231 = NOVALUE;
    DeRef(_28240);
    _28240 = NOVALUE;
    _28236 = NOVALUE;
    return;
    ;
}


void _45emit_forward_addr()
{
    object _28242 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:364		emit_addr(0)*/
    _47emit_addr(0);

    /** parser.e:365		branch_list = append(branch_list, length(Code))*/
    if (IS_SEQUENCE(_36Code_21859)){
            _28242 = SEQ_PTR(_36Code_21859)->length;
    }
    else {
        _28242 = 1;
    }
    Append(&_45branch_list_55354, _45branch_list_55354, _28242);
    _28242 = NOVALUE;

    /** parser.e:366	end procedure*/
    return;
    ;
}


void _45StraightenBranches()
{
    object _br_55863 = NOVALUE;
    object _target_55864 = NOVALUE;
    object _28263 = NOVALUE;
    object _28262 = NOVALUE;
    object _28261 = NOVALUE;
    object _28260 = NOVALUE;
    object _28258 = NOVALUE;
    object _28257 = NOVALUE;
    object _28256 = NOVALUE;
    object _28254 = NOVALUE;
    object _28253 = NOVALUE;
    object _28252 = NOVALUE;
    object _28251 = NOVALUE;
    object _28249 = NOVALUE;
    object _28246 = NOVALUE;
    object _28245 = NOVALUE;
    object _28244 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:373		if TRANSLATE then*/
    if (_36TRANSLATE_21369 == 0)
    {
        goto L1; // [5] 14
    }
    else{
    }

    /** parser.e:374			return -- do it in back-end*/
    return;
L1: 

    /** parser.e:376		for i = length(branch_list) to 1 by -1 do*/
    if (IS_SEQUENCE(_45branch_list_55354)){
            _28244 = SEQ_PTR(_45branch_list_55354)->length;
    }
    else {
        _28244 = 1;
    }
    {
        object _i_55868;
        _i_55868 = _28244;
L2: 
        if (_i_55868 < 1){
            goto L3; // [21] 170
        }

        /** parser.e:377			if branch_list[i] > length(Code) then*/
        _2 = (object)SEQ_PTR(_45branch_list_55354);
        _28245 = (object)*(((s1_ptr)_2)->base + _i_55868);
        if (IS_SEQUENCE(_36Code_21859)){
                _28246 = SEQ_PTR(_36Code_21859)->length;
        }
        else {
            _28246 = 1;
        }
        if (binary_op_a(LESSEQ, _28245, _28246)){
            _28245 = NOVALUE;
            _28246 = NOVALUE;
            goto L4; // [41] 53
        }
        _28245 = NOVALUE;
        _28246 = NOVALUE;

        /** parser.e:378				CompileErr("wtf")*/
        RefDS(_28248);
        RefDS(_22190);
        _50CompileErr(_28248, _22190, 0);
L4: 

        /** parser.e:380			target = Code[branch_list[i]]*/
        _2 = (object)SEQ_PTR(_45branch_list_55354);
        _28249 = (object)*(((s1_ptr)_2)->base + _i_55868);
        _2 = (object)SEQ_PTR(_36Code_21859);
        if (!IS_ATOM_INT(_28249)){
            _target_55864 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_28249)->dbl));
        }
        else{
            _target_55864 = (object)*(((s1_ptr)_2)->base + _28249);
        }
        if (!IS_ATOM_INT(_target_55864)){
            _target_55864 = (object)DBL_PTR(_target_55864)->dbl;
        }

        /** parser.e:381			if target <= length(Code) and target > 0 then*/
        if (IS_SEQUENCE(_36Code_21859)){
                _28251 = SEQ_PTR(_36Code_21859)->length;
        }
        else {
            _28251 = 1;
        }
        _28252 = (_target_55864 <= _28251);
        _28251 = NOVALUE;
        if (_28252 == 0) {
            goto L5; // [80] 163
        }
        _28254 = (_target_55864 > 0);
        if (_28254 == 0)
        {
            DeRef(_28254);
            _28254 = NOVALUE;
            goto L5; // [89] 163
        }
        else{
            DeRef(_28254);
            _28254 = NOVALUE;
        }

        /** parser.e:382				br = Code[target]*/
        _2 = (object)SEQ_PTR(_36Code_21859);
        _br_55863 = (object)*(((s1_ptr)_2)->base + _target_55864);
        if (!IS_ATOM_INT(_br_55863)){
            _br_55863 = (object)DBL_PTR(_br_55863)->dbl;
        }

        /** parser.e:383				if br = ELSE or br = ENDWHILE or br = EXIT then*/
        _28256 = (_br_55863 == 23);
        if (_28256 != 0) {
            _28257 = 1;
            goto L6; // [110] 124
        }
        _28258 = (_br_55863 == 22);
        _28257 = (_28258 != 0);
L6: 
        if (_28257 != 0) {
            goto L7; // [124] 139
        }
        _28260 = (_br_55863 == 61);
        if (_28260 == 0)
        {
            DeRef(_28260);
            _28260 = NOVALUE;
            goto L8; // [135] 162
        }
        else{
            DeRef(_28260);
            _28260 = NOVALUE;
        }
L7: 

        /** parser.e:384					backpatch(branch_list[i], Code[target+1])*/
        _2 = (object)SEQ_PTR(_45branch_list_55354);
        _28261 = (object)*(((s1_ptr)_2)->base + _i_55868);
        _28262 = _target_55864 + 1;
        _2 = (object)SEQ_PTR(_36Code_21859);
        _28263 = (object)*(((s1_ptr)_2)->base + _28262);
        Ref(_28261);
        Ref(_28263);
        _47backpatch(_28261, _28263);
        _28261 = NOVALUE;
        _28263 = NOVALUE;
L8: 
L5: 

        /** parser.e:387		end for*/
        _i_55868 = _i_55868 + -1;
        goto L2; // [165] 28
L3: 
        ;
    }

    /** parser.e:388		branch_list = {}*/
    RefDS(_22190);
    DeRef(_45branch_list_55354);
    _45branch_list_55354 = _22190;

    /** parser.e:389	end procedure*/
    DeRef(_28256);
    _28256 = NOVALUE;
    _28249 = NOVALUE;
    DeRef(_28262);
    _28262 = NOVALUE;
    DeRef(_28258);
    _28258 = NOVALUE;
    DeRef(_28252);
    _28252 = NOVALUE;
    return;
    ;
}


void _45PatchEList(object _base_55916)
{
    object _break_top_55917 = NOVALUE;
    object _n_55918 = NOVALUE;
    object _28280 = NOVALUE;
    object _28279 = NOVALUE;
    object _28278 = NOVALUE;
    object _28274 = NOVALUE;
    object _28273 = NOVALUE;
    object _28272 = NOVALUE;
    object _28270 = NOVALUE;
    object _28269 = NOVALUE;
    object _28267 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:410		if not length(break_list) then*/
    if (IS_SEQUENCE(_45break_list_55374)){
            _28267 = SEQ_PTR(_45break_list_55374)->length;
    }
    else {
        _28267 = 1;
    }
    if (_28267 != 0)
    goto L1; // [10] 19
    _28267 = NOVALUE;

    /** parser.e:411			return*/
    return;
L1: 

    /** parser.e:414		break_top = 0*/
    _break_top_55917 = 0;

    /** parser.e:415		for i=length(break_list) to base+1 by -1 do*/
    if (IS_SEQUENCE(_45break_list_55374)){
            _28269 = SEQ_PTR(_45break_list_55374)->length;
    }
    else {
        _28269 = 1;
    }
    _28270 = _base_55916 + 1;
    if (_28270 > MAXINT){
        _28270 = NewDouble((eudouble)_28270);
    }
    {
        object _i_55923;
        _i_55923 = _28269;
L2: 
        if (binary_op_a(LESS, _i_55923, _28270)){
            goto L3; // [35] 129
        }

        /** parser.e:416			n=break_delay[i]*/
        _2 = (object)SEQ_PTR(_45break_delay_55375);
        if (!IS_ATOM_INT(_i_55923)){
            _n_55918 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_55923)->dbl));
        }
        else{
            _n_55918 = (object)*(((s1_ptr)_2)->base + _i_55923);
        }
        if (!IS_ATOM_INT(_n_55918))
        _n_55918 = (object)DBL_PTR(_n_55918)->dbl;

        /** parser.e:417			break_delay[i] -= (n>0)*/
        _28272 = (_n_55918 > 0);
        _2 = (object)SEQ_PTR(_45break_delay_55375);
        if (!IS_ATOM_INT(_i_55923)){
            _28273 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_55923)->dbl));
        }
        else{
            _28273 = (object)*(((s1_ptr)_2)->base + _i_55923);
        }
        if (IS_ATOM_INT(_28273)) {
            _28274 = _28273 - _28272;
            if ((object)((uintptr_t)_28274 +(uintptr_t) HIGH_BITS) >= 0){
                _28274 = NewDouble((eudouble)_28274);
            }
        }
        else {
            _28274 = binary_op(MINUS, _28273, _28272);
        }
        _28273 = NOVALUE;
        _28272 = NOVALUE;
        _2 = (object)SEQ_PTR(_45break_delay_55375);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _45break_delay_55375 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_i_55923))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_55923)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _i_55923);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _28274;
        if( _1 != _28274 ){
            DeRef(_1);
        }
        _28274 = NOVALUE;

        /** parser.e:418			if n>1 then*/
        if (_n_55918 <= 1)
        goto L4; // [72] 93

        /** parser.e:419				if break_top = 0 then*/
        if (_break_top_55917 != 0)
        goto L5; // [78] 122

        /** parser.e:420					break_top = i*/
        Ref(_i_55923);
        _break_top_55917 = _i_55923;
        if (!IS_ATOM_INT(_break_top_55917)) {
            _1 = (object)(DBL_PTR(_break_top_55917)->dbl);
            DeRefDS(_break_top_55917);
            _break_top_55917 = _1;
        }
        goto L5; // [90] 122
L4: 

        /** parser.e:422			elsif n=1 then*/
        if (_n_55918 != 1)
        goto L6; // [95] 121

        /** parser.e:423				backpatch(break_list[i],length(Code)+1)*/
        _2 = (object)SEQ_PTR(_45break_list_55374);
        if (!IS_ATOM_INT(_i_55923)){
            _28278 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_55923)->dbl));
        }
        else{
            _28278 = (object)*(((s1_ptr)_2)->base + _i_55923);
        }
        if (IS_SEQUENCE(_36Code_21859)){
                _28279 = SEQ_PTR(_36Code_21859)->length;
        }
        else {
            _28279 = 1;
        }
        _28280 = _28279 + 1;
        _28279 = NOVALUE;
        _47backpatch(_28278, _28280);
        _28278 = NOVALUE;
        _28280 = NOVALUE;
L6: 
L5: 

        /** parser.e:425		end for*/
        _0 = _i_55923;
        if (IS_ATOM_INT(_i_55923)) {
            _i_55923 = _i_55923 + -1;
            if ((object)((uintptr_t)_i_55923 +(uintptr_t) HIGH_BITS) >= 0){
                _i_55923 = NewDouble((eudouble)_i_55923);
            }
        }
        else {
            _i_55923 = binary_op_a(PLUS, _i_55923, -1);
        }
        DeRef(_0);
        goto L2; // [124] 42
L3: 
        ;
        DeRef(_i_55923);
    }

    /** parser.e:427		if break_top=0 then*/
    if (_break_top_55917 != 0)
    goto L7; // [131] 141

    /** parser.e:428		    break_top=base*/
    _break_top_55917 = _base_55916;
L7: 

    /** parser.e:431		break_delay = break_delay[1..break_top]*/
    rhs_slice_target = (object_ptr)&_45break_delay_55375;
    RHS_Slice(_45break_delay_55375, 1, _break_top_55917);

    /** parser.e:432		break_list = break_list[1..break_top]*/
    rhs_slice_target = (object_ptr)&_45break_list_55374;
    RHS_Slice(_45break_list_55374, 1, _break_top_55917);

    /** parser.e:433	end procedure*/
    DeRef(_28270);
    _28270 = NOVALUE;
    return;
    ;
}


void _45PatchNList(object _base_55947)
{
    object _next_top_55948 = NOVALUE;
    object _n_55949 = NOVALUE;
    object _28297 = NOVALUE;
    object _28296 = NOVALUE;
    object _28295 = NOVALUE;
    object _28291 = NOVALUE;
    object _28290 = NOVALUE;
    object _28289 = NOVALUE;
    object _28287 = NOVALUE;
    object _28286 = NOVALUE;
    object _28284 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:439		if not length(continue_list) then*/
    if (IS_SEQUENCE(_45continue_list_55378)){
            _28284 = SEQ_PTR(_45continue_list_55378)->length;
    }
    else {
        _28284 = 1;
    }
    if (_28284 != 0)
    goto L1; // [10] 19
    _28284 = NOVALUE;

    /** parser.e:440			return*/
    return;
L1: 

    /** parser.e:443		next_top = 0*/
    _next_top_55948 = 0;

    /** parser.e:445		for i=length(continue_list) to base+1 by -1 do*/
    if (IS_SEQUENCE(_45continue_list_55378)){
            _28286 = SEQ_PTR(_45continue_list_55378)->length;
    }
    else {
        _28286 = 1;
    }
    _28287 = _base_55947 + 1;
    if (_28287 > MAXINT){
        _28287 = NewDouble((eudouble)_28287);
    }
    {
        object _i_55954;
        _i_55954 = _28286;
L2: 
        if (binary_op_a(LESS, _i_55954, _28287)){
            goto L3; // [35] 129
        }

        /** parser.e:446			n=continue_delay[i]*/
        _2 = (object)SEQ_PTR(_45continue_delay_55379);
        if (!IS_ATOM_INT(_i_55954)){
            _n_55949 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_55954)->dbl));
        }
        else{
            _n_55949 = (object)*(((s1_ptr)_2)->base + _i_55954);
        }
        if (!IS_ATOM_INT(_n_55949))
        _n_55949 = (object)DBL_PTR(_n_55949)->dbl;

        /** parser.e:447			continue_delay[i] -= (n>0)*/
        _28289 = (_n_55949 > 0);
        _2 = (object)SEQ_PTR(_45continue_delay_55379);
        if (!IS_ATOM_INT(_i_55954)){
            _28290 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_55954)->dbl));
        }
        else{
            _28290 = (object)*(((s1_ptr)_2)->base + _i_55954);
        }
        if (IS_ATOM_INT(_28290)) {
            _28291 = _28290 - _28289;
            if ((object)((uintptr_t)_28291 +(uintptr_t) HIGH_BITS) >= 0){
                _28291 = NewDouble((eudouble)_28291);
            }
        }
        else {
            _28291 = binary_op(MINUS, _28290, _28289);
        }
        _28290 = NOVALUE;
        _28289 = NOVALUE;
        _2 = (object)SEQ_PTR(_45continue_delay_55379);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _45continue_delay_55379 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_i_55954))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_55954)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _i_55954);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _28291;
        if( _1 != _28291 ){
            DeRef(_1);
        }
        _28291 = NOVALUE;

        /** parser.e:448			if n>1 then*/
        if (_n_55949 <= 1)
        goto L4; // [72] 93

        /** parser.e:449				if next_top = 0 then*/
        if (_next_top_55948 != 0)
        goto L5; // [78] 122

        /** parser.e:450					next_top = i*/
        Ref(_i_55954);
        _next_top_55948 = _i_55954;
        if (!IS_ATOM_INT(_next_top_55948)) {
            _1 = (object)(DBL_PTR(_next_top_55948)->dbl);
            DeRefDS(_next_top_55948);
            _next_top_55948 = _1;
        }
        goto L5; // [90] 122
L4: 

        /** parser.e:452			elsif n=1 then*/
        if (_n_55949 != 1)
        goto L6; // [95] 121

        /** parser.e:453				backpatch(continue_list[i],length(Code)+1)*/
        _2 = (object)SEQ_PTR(_45continue_list_55378);
        if (!IS_ATOM_INT(_i_55954)){
            _28295 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_55954)->dbl));
        }
        else{
            _28295 = (object)*(((s1_ptr)_2)->base + _i_55954);
        }
        if (IS_SEQUENCE(_36Code_21859)){
                _28296 = SEQ_PTR(_36Code_21859)->length;
        }
        else {
            _28296 = 1;
        }
        _28297 = _28296 + 1;
        _28296 = NOVALUE;
        _47backpatch(_28295, _28297);
        _28295 = NOVALUE;
        _28297 = NOVALUE;
L6: 
L5: 

        /** parser.e:455		end for*/
        _0 = _i_55954;
        if (IS_ATOM_INT(_i_55954)) {
            _i_55954 = _i_55954 + -1;
            if ((object)((uintptr_t)_i_55954 +(uintptr_t) HIGH_BITS) >= 0){
                _i_55954 = NewDouble((eudouble)_i_55954);
            }
        }
        else {
            _i_55954 = binary_op_a(PLUS, _i_55954, -1);
        }
        DeRef(_0);
        goto L2; // [124] 42
L3: 
        ;
        DeRef(_i_55954);
    }

    /** parser.e:457		if next_top=0 then*/
    if (_next_top_55948 != 0)
    goto L7; // [131] 141

    /** parser.e:458		    next_top=base*/
    _next_top_55948 = _base_55947;
L7: 

    /** parser.e:461		continue_delay =continue_delay[1..next_top]*/
    rhs_slice_target = (object_ptr)&_45continue_delay_55379;
    RHS_Slice(_45continue_delay_55379, 1, _next_top_55948);

    /** parser.e:462		continue_list = continue_list[1..next_top]*/
    rhs_slice_target = (object_ptr)&_45continue_list_55378;
    RHS_Slice(_45continue_list_55378, 1, _next_top_55948);

    /** parser.e:463	end procedure*/
    DeRef(_28287);
    _28287 = NOVALUE;
    return;
    ;
}


void _45PatchXList(object _base_55978)
{
    object _exit_top_55979 = NOVALUE;
    object _n_55980 = NOVALUE;
    object _28314 = NOVALUE;
    object _28313 = NOVALUE;
    object _28312 = NOVALUE;
    object _28308 = NOVALUE;
    object _28307 = NOVALUE;
    object _28306 = NOVALUE;
    object _28304 = NOVALUE;
    object _28303 = NOVALUE;
    object _28301 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:469		if not length(exit_list) then*/
    if (IS_SEQUENCE(_45exit_list_55376)){
            _28301 = SEQ_PTR(_45exit_list_55376)->length;
    }
    else {
        _28301 = 1;
    }
    if (_28301 != 0)
    goto L1; // [10] 19
    _28301 = NOVALUE;

    /** parser.e:470			return*/
    return;
L1: 

    /** parser.e:473		exit_top = 0*/
    _exit_top_55979 = 0;

    /** parser.e:475		for i=length(exit_list) to base+1 by -1 do*/
    if (IS_SEQUENCE(_45exit_list_55376)){
            _28303 = SEQ_PTR(_45exit_list_55376)->length;
    }
    else {
        _28303 = 1;
    }
    _28304 = _base_55978 + 1;
    if (_28304 > MAXINT){
        _28304 = NewDouble((eudouble)_28304);
    }
    {
        object _i_55985;
        _i_55985 = _28303;
L2: 
        if (binary_op_a(LESS, _i_55985, _28304)){
            goto L3; // [35] 129
        }

        /** parser.e:476			n=exit_delay[i]*/
        _2 = (object)SEQ_PTR(_45exit_delay_55377);
        if (!IS_ATOM_INT(_i_55985)){
            _n_55980 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_55985)->dbl));
        }
        else{
            _n_55980 = (object)*(((s1_ptr)_2)->base + _i_55985);
        }
        if (!IS_ATOM_INT(_n_55980))
        _n_55980 = (object)DBL_PTR(_n_55980)->dbl;

        /** parser.e:477			exit_delay[i] -= (n>0)*/
        _28306 = (_n_55980 > 0);
        _2 = (object)SEQ_PTR(_45exit_delay_55377);
        if (!IS_ATOM_INT(_i_55985)){
            _28307 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_55985)->dbl));
        }
        else{
            _28307 = (object)*(((s1_ptr)_2)->base + _i_55985);
        }
        if (IS_ATOM_INT(_28307)) {
            _28308 = _28307 - _28306;
            if ((object)((uintptr_t)_28308 +(uintptr_t) HIGH_BITS) >= 0){
                _28308 = NewDouble((eudouble)_28308);
            }
        }
        else {
            _28308 = binary_op(MINUS, _28307, _28306);
        }
        _28307 = NOVALUE;
        _28306 = NOVALUE;
        _2 = (object)SEQ_PTR(_45exit_delay_55377);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _45exit_delay_55377 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_i_55985))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_55985)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _i_55985);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _28308;
        if( _1 != _28308 ){
            DeRef(_1);
        }
        _28308 = NOVALUE;

        /** parser.e:478			if n>1 then*/
        if (_n_55980 <= 1)
        goto L4; // [72] 93

        /** parser.e:479				if exit_top = 0 then*/
        if (_exit_top_55979 != 0)
        goto L5; // [78] 122

        /** parser.e:480					exit_top = i*/
        Ref(_i_55985);
        _exit_top_55979 = _i_55985;
        if (!IS_ATOM_INT(_exit_top_55979)) {
            _1 = (object)(DBL_PTR(_exit_top_55979)->dbl);
            DeRefDS(_exit_top_55979);
            _exit_top_55979 = _1;
        }
        goto L5; // [90] 122
L4: 

        /** parser.e:482			elsif n=1 then*/
        if (_n_55980 != 1)
        goto L6; // [95] 121

        /** parser.e:483				backpatch(exit_list[i],length(Code)+1)*/
        _2 = (object)SEQ_PTR(_45exit_list_55376);
        if (!IS_ATOM_INT(_i_55985)){
            _28312 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_55985)->dbl));
        }
        else{
            _28312 = (object)*(((s1_ptr)_2)->base + _i_55985);
        }
        if (IS_SEQUENCE(_36Code_21859)){
                _28313 = SEQ_PTR(_36Code_21859)->length;
        }
        else {
            _28313 = 1;
        }
        _28314 = _28313 + 1;
        _28313 = NOVALUE;
        _47backpatch(_28312, _28314);
        _28312 = NOVALUE;
        _28314 = NOVALUE;
L6: 
L5: 

        /** parser.e:485		end for*/
        _0 = _i_55985;
        if (IS_ATOM_INT(_i_55985)) {
            _i_55985 = _i_55985 + -1;
            if ((object)((uintptr_t)_i_55985 +(uintptr_t) HIGH_BITS) >= 0){
                _i_55985 = NewDouble((eudouble)_i_55985);
            }
        }
        else {
            _i_55985 = binary_op_a(PLUS, _i_55985, -1);
        }
        DeRef(_0);
        goto L2; // [124] 42
L3: 
        ;
        DeRef(_i_55985);
    }

    /** parser.e:487		if exit_top=0 then*/
    if (_exit_top_55979 != 0)
    goto L7; // [131] 141

    /** parser.e:488		    exit_top=base*/
    _exit_top_55979 = _base_55978;
L7: 

    /** parser.e:491		exit_delay = exit_delay [1..exit_top]*/
    rhs_slice_target = (object_ptr)&_45exit_delay_55377;
    RHS_Slice(_45exit_delay_55377, 1, _exit_top_55979);

    /** parser.e:492		exit_list = exit_list [1..exit_top]*/
    rhs_slice_target = (object_ptr)&_45exit_list_55376;
    RHS_Slice(_45exit_list_55376, 1, _exit_top_55979);

    /** parser.e:493	end procedure*/
    DeRef(_28304);
    _28304 = NOVALUE;
    return;
    ;
}


void _45putback(object _t_56010)
{
    object _28319 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:497		backed_up_tok = append(backed_up_tok, t)*/
    Ref(_t_56010);
    Append(&_45backed_up_tok_55363, _45backed_up_tok_55363, _t_56010);

    /** parser.e:499		if t[T_SYM] then*/
    _2 = (object)SEQ_PTR(_t_56010);
    _28319 = (object)*(((s1_ptr)_2)->base + 2);
    if (_28319 == 0) {
        _28319 = NOVALUE;
        goto L1; // [17] 79
    }
    else {
        if (!IS_ATOM_INT(_28319) && DBL_PTR(_28319)->dbl == 0.0){
            _28319 = NOVALUE;
            goto L1; // [17] 79
        }
        _28319 = NOVALUE;
    }
    _28319 = NOVALUE;

    /** parser.e:500			putback_ForwardLine     = ForwardLine*/
    Ref(_50ForwardLine_49595);
    DeRef(_50putback_ForwardLine_49596);
    _50putback_ForwardLine_49596 = _50ForwardLine_49595;

    /** parser.e:501			putback_forward_bp      = forward_bp*/
    _50putback_forward_bp_49600 = _50forward_bp_49599;

    /** parser.e:502			putback_fwd_line_number = fwd_line_number*/
    _36putback_fwd_line_number_21770 = _36fwd_line_number_21769;

    /** parser.e:504			if last_fwd_line_number then*/
    if (_36last_fwd_line_number_21771 == 0)
    {
        goto L2; // [49] 78
    }
    else{
    }

    /** parser.e:505				ForwardLine     = last_ForwardLine*/
    Ref(_50last_ForwardLine_49597);
    DeRef(_50ForwardLine_49595);
    _50ForwardLine_49595 = _50last_ForwardLine_49597;

    /** parser.e:506				forward_bp      = last_forward_bp*/
    _50forward_bp_49599 = _50last_forward_bp_49601;

    /** parser.e:507				fwd_line_number = last_fwd_line_number*/
    _36fwd_line_number_21769 = _36last_fwd_line_number_21771;
L2: 
L1: 

    /** parser.e:510	end procedure*/
    DeRef(_t_56010);
    return;
    ;
}


void _45start_recording()
{
    object _0, _1, _2;
    

    /** parser.e:519		psm_stack &= Parser_mode*/
    Append(&_45psm_stack_56029, _45psm_stack_56029, _36Parser_mode_21876);

    /** parser.e:520		can_stack = append(can_stack,canned_tokens)*/
    Ref(_45canned_tokens_55400);
    Append(&_45can_stack_56030, _45can_stack_56030, _45canned_tokens_55400);

    /** parser.e:521		idx_stack &= canned_index*/
    Append(&_45idx_stack_56031, _45idx_stack_56031, _45canned_index_55401);

    /** parser.e:522		tok_stack = append(tok_stack,backed_up_tok)*/
    RefDS(_45backed_up_tok_55363);
    Append(&_45tok_stack_56032, _45tok_stack_56032, _45backed_up_tok_55363);

    /** parser.e:523		canned_tokens = {}*/
    RefDS(_22190);
    DeRef(_45canned_tokens_55400);
    _45canned_tokens_55400 = _22190;

    /** parser.e:524		Parser_mode = PAM_RECORD*/
    _36Parser_mode_21876 = 1;

    /** parser.e:525		clear_last()*/
    _47clear_last();

    /** parser.e:526	end procedure*/
    return;
    ;
}


object _45restore_parser()
{
    object _n_56045 = NOVALUE;
    object _tok_56046 = NOVALUE;
    object _x_56047 = NOVALUE;
    object _28350 = NOVALUE;
    object _28349 = NOVALUE;
    object _28348 = NOVALUE;
    object _28346 = NOVALUE;
    object _28342 = NOVALUE;
    object _28341 = NOVALUE;
    object _28339 = NOVALUE;
    object _28337 = NOVALUE;
    object _28336 = NOVALUE;
    object _28334 = NOVALUE;
    object _28332 = NOVALUE;
    object _28331 = NOVALUE;
    object _28329 = NOVALUE;
    object _28327 = NOVALUE;
    object _28326 = NOVALUE;
    object _28324 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:533		n=Parser_mode*/
    _n_56045 = _36Parser_mode_21876;

    /** parser.e:534		x = canned_tokens*/
    Ref(_45canned_tokens_55400);
    DeRef(_x_56047);
    _x_56047 = _45canned_tokens_55400;

    /** parser.e:535		canned_tokens = can_stack[$]*/
    if (IS_SEQUENCE(_45can_stack_56030)){
            _28324 = SEQ_PTR(_45can_stack_56030)->length;
    }
    else {
        _28324 = 1;
    }
    DeRef(_45canned_tokens_55400);
    _2 = (object)SEQ_PTR(_45can_stack_56030);
    _45canned_tokens_55400 = (object)*(((s1_ptr)_2)->base + _28324);
    Ref(_45canned_tokens_55400);

    /** parser.e:536		can_stack     = can_stack[1..$-1]*/
    if (IS_SEQUENCE(_45can_stack_56030)){
            _28326 = SEQ_PTR(_45can_stack_56030)->length;
    }
    else {
        _28326 = 1;
    }
    _28327 = _28326 - 1;
    _28326 = NOVALUE;
    rhs_slice_target = (object_ptr)&_45can_stack_56030;
    RHS_Slice(_45can_stack_56030, 1, _28327);

    /** parser.e:537		canned_index  = idx_stack[$]*/
    if (IS_SEQUENCE(_45idx_stack_56031)){
            _28329 = SEQ_PTR(_45idx_stack_56031)->length;
    }
    else {
        _28329 = 1;
    }
    _2 = (object)SEQ_PTR(_45idx_stack_56031);
    _45canned_index_55401 = (object)*(((s1_ptr)_2)->base + _28329);

    /** parser.e:538		idx_stack     = idx_stack[1..$-1]*/
    if (IS_SEQUENCE(_45idx_stack_56031)){
            _28331 = SEQ_PTR(_45idx_stack_56031)->length;
    }
    else {
        _28331 = 1;
    }
    _28332 = _28331 - 1;
    _28331 = NOVALUE;
    rhs_slice_target = (object_ptr)&_45idx_stack_56031;
    RHS_Slice(_45idx_stack_56031, 1, _28332);

    /** parser.e:539		Parser_mode   = psm_stack[$]*/
    if (IS_SEQUENCE(_45psm_stack_56029)){
            _28334 = SEQ_PTR(_45psm_stack_56029)->length;
    }
    else {
        _28334 = 1;
    }
    _2 = (object)SEQ_PTR(_45psm_stack_56029);
    _36Parser_mode_21876 = (object)*(((s1_ptr)_2)->base + _28334);

    /** parser.e:540		psm_stack     = psm_stack[1..$-1]*/
    if (IS_SEQUENCE(_45psm_stack_56029)){
            _28336 = SEQ_PTR(_45psm_stack_56029)->length;
    }
    else {
        _28336 = 1;
    }
    _28337 = _28336 - 1;
    _28336 = NOVALUE;
    rhs_slice_target = (object_ptr)&_45psm_stack_56029;
    RHS_Slice(_45psm_stack_56029, 1, _28337);

    /** parser.e:541		tok 		  = tok_stack[$]*/
    if (IS_SEQUENCE(_45tok_stack_56032)){
            _28339 = SEQ_PTR(_45tok_stack_56032)->length;
    }
    else {
        _28339 = 1;
    }
    DeRef(_tok_56046);
    _2 = (object)SEQ_PTR(_45tok_stack_56032);
    _tok_56046 = (object)*(((s1_ptr)_2)->base + _28339);
    RefDS(_tok_56046);

    /** parser.e:542		tok_stack 	  = tok_stack[1..$-1]*/
    if (IS_SEQUENCE(_45tok_stack_56032)){
            _28341 = SEQ_PTR(_45tok_stack_56032)->length;
    }
    else {
        _28341 = 1;
    }
    _28342 = _28341 - 1;
    _28341 = NOVALUE;
    rhs_slice_target = (object_ptr)&_45tok_stack_56032;
    RHS_Slice(_45tok_stack_56032, 1, _28342);

    /** parser.e:543		clear_last()*/
    _47clear_last();

    /** parser.e:544		if n=PAM_PLAYBACK then*/
    if (_n_56045 != -1)
    goto L1; // [137] 150

    /** parser.e:545			return {}*/
    RefDS(_22190);
    DeRefDS(_tok_56046);
    DeRefDS(_x_56047);
    _28332 = NOVALUE;
    _28327 = NOVALUE;
    _28337 = NOVALUE;
    _28342 = NOVALUE;
    return _22190;
    goto L2; // [147] 167
L1: 

    /** parser.e:547		elsif n = PAM_NORMAL then*/
    if (_n_56045 != 0)
    goto L3; // [154] 166

    /** parser.e:548			use_private_list = 0*/
    _36use_private_list_21884 = 0;
L3: 
L2: 

    /** parser.e:550		if length(backed_up_tok) > 0 then*/
    if (IS_SEQUENCE(_45backed_up_tok_55363)){
            _28346 = SEQ_PTR(_45backed_up_tok_55363)->length;
    }
    else {
        _28346 = 1;
    }
    if (_28346 <= 0)
    goto L4; // [174] 199

    /** parser.e:551			return x[1..$-1]*/
    if (IS_SEQUENCE(_x_56047)){
            _28348 = SEQ_PTR(_x_56047)->length;
    }
    else {
        _28348 = 1;
    }
    _28349 = _28348 - 1;
    _28348 = NOVALUE;
    rhs_slice_target = (object_ptr)&_28350;
    RHS_Slice(_x_56047, 1, _28349);
    DeRef(_tok_56046);
    DeRefDS(_x_56047);
    _28349 = NOVALUE;
    DeRef(_28332);
    _28332 = NOVALUE;
    DeRef(_28327);
    _28327 = NOVALUE;
    DeRef(_28337);
    _28337 = NOVALUE;
    DeRef(_28342);
    _28342 = NOVALUE;
    return _28350;
    goto L5; // [196] 206
L4: 

    /** parser.e:553			return x*/
    DeRef(_tok_56046);
    DeRef(_28349);
    _28349 = NOVALUE;
    DeRef(_28332);
    _28332 = NOVALUE;
    DeRef(_28350);
    _28350 = NOVALUE;
    DeRef(_28327);
    _28327 = NOVALUE;
    DeRef(_28337);
    _28337 = NOVALUE;
    DeRef(_28342);
    _28342 = NOVALUE;
    return _x_56047;
L5: 
    ;
}


void _45start_playback(object _s_56087)
{
    object _0, _1, _2;
    

    /** parser.e:558		psm_stack &= Parser_mode*/
    Append(&_45psm_stack_56029, _45psm_stack_56029, _36Parser_mode_21876);

    /** parser.e:559		can_stack = append(can_stack,canned_tokens)*/
    Ref(_45canned_tokens_55400);
    Append(&_45can_stack_56030, _45can_stack_56030, _45canned_tokens_55400);

    /** parser.e:560		idx_stack &= canned_index*/
    Append(&_45idx_stack_56031, _45idx_stack_56031, _45canned_index_55401);

    /** parser.e:561		tok_stack = append(tok_stack,backed_up_tok)*/
    RefDS(_45backed_up_tok_55363);
    Append(&_45tok_stack_56032, _45tok_stack_56032, _45backed_up_tok_55363);

    /** parser.e:562		canned_index = 1*/
    _45canned_index_55401 = 1;

    /** parser.e:563		canned_tokens = s*/
    RefDS(_s_56087);
    DeRef(_45canned_tokens_55400);
    _45canned_tokens_55400 = _s_56087;

    /** parser.e:564		backed_up_tok = {}*/
    RefDS(_22190);
    DeRefDS(_45backed_up_tok_55363);
    _45backed_up_tok_55363 = _22190;

    /** parser.e:565		Parser_mode = PAM_PLAYBACK*/
    _36Parser_mode_21876 = -1;

    /** parser.e:566	end procedure*/
    DeRefDS(_s_56087);
    return;
    ;
}


void _45restore_parseargs_states()
{
    object _s_56106 = NOVALUE;
    object _n_56107 = NOVALUE;
    object _28367 = NOVALUE;
    object _28366 = NOVALUE;
    object _28358 = NOVALUE;
    object _28357 = NOVALUE;
    object _28355 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:584		s = parseargs_states[$]*/
    if (IS_SEQUENCE(_45parseargs_states_56095)){
            _28355 = SEQ_PTR(_45parseargs_states_56095)->length;
    }
    else {
        _28355 = 1;
    }
    DeRef(_s_56106);
    _2 = (object)SEQ_PTR(_45parseargs_states_56095);
    _s_56106 = (object)*(((s1_ptr)_2)->base + _28355);
    RefDS(_s_56106);

    /** parser.e:585		parseargs_states = parseargs_states[1..$-1]*/
    if (IS_SEQUENCE(_45parseargs_states_56095)){
            _28357 = SEQ_PTR(_45parseargs_states_56095)->length;
    }
    else {
        _28357 = 1;
    }
    _28358 = _28357 - 1;
    _28357 = NOVALUE;
    rhs_slice_target = (object_ptr)&_45parseargs_states_56095;
    RHS_Slice(_45parseargs_states_56095, 1, _28358);

    /** parser.e:586		n=s[PS_POSITION]*/
    _2 = (object)SEQ_PTR(_s_56106);
    _n_56107 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_n_56107))
    _n_56107 = (object)DBL_PTR(_n_56107)->dbl;

    /** parser.e:587		private_list = private_list[1..n]*/
    rhs_slice_target = (object_ptr)&_45private_list_56100;
    RHS_Slice(_45private_list_56100, 1, _n_56107);

    /** parser.e:588		private_sym = private_sym[1..n]*/
    rhs_slice_target = (object_ptr)&_36private_sym_21883;
    RHS_Slice(_36private_sym_21883, 1, _n_56107);

    /** parser.e:589		lock_scanner = s[PS_SCAN_LOCK]*/
    _2 = (object)SEQ_PTR(_s_56106);
    _45lock_scanner_56101 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_45lock_scanner_56101))
    _45lock_scanner_56101 = (object)DBL_PTR(_45lock_scanner_56101)->dbl;

    /** parser.e:590		use_private_list = s[PS_USE_LIST]*/
    _2 = (object)SEQ_PTR(_s_56106);
    _36use_private_list_21884 = (object)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_36use_private_list_21884)){
        _36use_private_list_21884 = (object)DBL_PTR(_36use_private_list_21884)->dbl;
    }

    /** parser.e:591		on_arg = s[PS_ON_ARG]*/
    _2 = (object)SEQ_PTR(_s_56106);
    _45on_arg_56102 = (object)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_45on_arg_56102))
    _45on_arg_56102 = (object)DBL_PTR(_45on_arg_56102)->dbl;

    /** parser.e:592		nested_calls = nested_calls[1..$-1]*/
    if (IS_SEQUENCE(_45nested_calls_56103)){
            _28366 = SEQ_PTR(_45nested_calls_56103)->length;
    }
    else {
        _28366 = 1;
    }
    _28367 = _28366 - 1;
    _28366 = NOVALUE;
    rhs_slice_target = (object_ptr)&_45nested_calls_56103;
    RHS_Slice(_45nested_calls_56103, 1, _28367);

    /** parser.e:593	end procedure*/
    DeRefDS(_s_56106);
    _28358 = NOVALUE;
    _28367 = NOVALUE;
    return;
    ;
}


object _45read_recorded_token(object _n_56127)
{
    object _t_56129 = NOVALUE;
    object _p_56130 = NOVALUE;
    object _prev_Nne_56131 = NOVALUE;
    object _ts_56160 = NOVALUE;
    object _31969 = NOVALUE;
    object _31968 = NOVALUE;
    object _31967 = NOVALUE;
    object _31966 = NOVALUE;
    object _31965 = NOVALUE;
    object _31964 = NOVALUE;
    object _31963 = NOVALUE;
    object _31962 = NOVALUE;
    object _28439 = NOVALUE;
    object _28438 = NOVALUE;
    object _28437 = NOVALUE;
    object _28436 = NOVALUE;
    object _28432 = NOVALUE;
    object _28430 = NOVALUE;
    object _28429 = NOVALUE;
    object _28428 = NOVALUE;
    object _28427 = NOVALUE;
    object _28425 = NOVALUE;
    object _28424 = NOVALUE;
    object _28423 = NOVALUE;
    object _28422 = NOVALUE;
    object _28420 = NOVALUE;
    object _28417 = NOVALUE;
    object _28415 = NOVALUE;
    object _28413 = NOVALUE;
    object _28412 = NOVALUE;
    object _28411 = NOVALUE;
    object _28410 = NOVALUE;
    object _28408 = NOVALUE;
    object _28406 = NOVALUE;
    object _28402 = NOVALUE;
    object _28400 = NOVALUE;
    object _28398 = NOVALUE;
    object _28397 = NOVALUE;
    object _28396 = NOVALUE;
    object _28395 = NOVALUE;
    object _28394 = NOVALUE;
    object _28393 = NOVALUE;
    object _28392 = NOVALUE;
    object _28391 = NOVALUE;
    object _28390 = NOVALUE;
    object _28389 = NOVALUE;
    object _28388 = NOVALUE;
    object _28387 = NOVALUE;
    object _28385 = NOVALUE;
    object _28384 = NOVALUE;
    object _28382 = NOVALUE;
    object _28381 = NOVALUE;
    object _28380 = NOVALUE;
    object _28379 = NOVALUE;
    object _28378 = NOVALUE;
    object _28377 = NOVALUE;
    object _28376 = NOVALUE;
    object _28375 = NOVALUE;
    object _28372 = NOVALUE;
    object _28370 = NOVALUE;
    object _28369 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_n_56127)) {
        _1 = (object)(DBL_PTR(_n_56127)->dbl);
        DeRefDS(_n_56127);
        _n_56127 = _1;
    }

    /** parser.e:597		integer p, prev_Nne*/

    /** parser.e:598		if atom(Ns_recorded[n]) label "top if" then*/
    _2 = (object)SEQ_PTR(_36Ns_recorded_21878);
    _28369 = (object)*(((s1_ptr)_2)->base + _n_56127);
    _28370 = IS_ATOM(_28369);
    _28369 = NOVALUE;
    if (_28370 == 0)
    {
        _28370 = NOVALUE;
        goto L1; // [16] 405
    }
    else{
        _28370 = NOVALUE;
    }

    /** parser.e:599			if use_private_list then*/
    if (_36use_private_list_21884 == 0)
    {
        goto L2; // [23] 171
    }
    else{
    }

    /** parser.e:600				p = find( Recorded[n], private_list)*/
    _2 = (object)SEQ_PTR(_36Recorded_21877);
    _28372 = (object)*(((s1_ptr)_2)->base + _n_56127);
    _p_56130 = find_from(_28372, _45private_list_56100, 1);
    _28372 = NOVALUE;

    /** parser.e:601				if p > 0 then -- the value of this parameter is known, use it*/
    if (_p_56130 <= 0)
    goto L3; // [43] 170

    /** parser.e:603					if TRANSLATE*/
    if (_36TRANSLATE_21369 == 0) {
        goto L4; // [51] 150
    }
    _2 = (object)SEQ_PTR(_36private_sym_21883);
    _28376 = (object)*(((s1_ptr)_2)->base + _p_56130);
    if (IS_ATOM_INT(_28376)) {
        _28377 = (_28376 < 0);
    }
    else {
        _28377 = binary_op(LESS, _28376, 0);
    }
    _28376 = NOVALUE;
    if (IS_ATOM_INT(_28377)) {
        if (_28377 != 0) {
            _28378 = 1;
            goto L5; // [65] 97
        }
    }
    else {
        if (DBL_PTR(_28377)->dbl != 0.0) {
            _28378 = 1;
            goto L5; // [65] 97
        }
    }
    _2 = (object)SEQ_PTR(_36private_sym_21883);
    _28379 = (object)*(((s1_ptr)_2)->base + _p_56130);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!IS_ATOM_INT(_28379)){
        _28380 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_28379)->dbl));
    }
    else{
        _28380 = (object)*(((s1_ptr)_2)->base + _28379);
    }
    _2 = (object)SEQ_PTR(_28380);
    _28381 = (object)*(((s1_ptr)_2)->base + 3);
    _28380 = NOVALUE;
    if (IS_ATOM_INT(_28381)) {
        _28382 = (_28381 == 3);
    }
    else {
        _28382 = binary_op(EQUALS, _28381, 3);
    }
    _28381 = NOVALUE;
    DeRef(_28378);
    if (IS_ATOM_INT(_28382))
    _28378 = (_28382 != 0);
    else
    _28378 = DBL_PTR(_28382)->dbl != 0.0;
L5: 
    if (_28378 == 0)
    {
        _28378 = NOVALUE;
        goto L4; // [98] 150
    }
    else{
        _28378 = NOVALUE;
    }

    /** parser.e:610						symtab_index ts = NewTempSym()*/
    _ts_56160 = _54NewTempSym(0);
    if (!IS_ATOM_INT(_ts_56160)) {
        _1 = (object)(DBL_PTR(_ts_56160)->dbl);
        DeRefDS(_ts_56160);
        _ts_56160 = _1;
    }

    /** parser.e:611						Code &= { ASSIGN, private_sym[p], ts }*/
    _2 = (object)SEQ_PTR(_36private_sym_21883);
    _28384 = (object)*(((s1_ptr)_2)->base + _p_56130);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 18;
    Ref(_28384);
    ((intptr_t*)_2)[2] = _28384;
    ((intptr_t*)_2)[3] = _ts_56160;
    _28385 = MAKE_SEQ(_1);
    _28384 = NOVALUE;
    Concat((object_ptr)&_36Code_21859, _36Code_21859, _28385);
    DeRefDS(_28385);
    _28385 = NOVALUE;

    /** parser.e:612						return {VARIABLE, ts}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -100;
    ((intptr_t *)_2)[2] = _ts_56160;
    _28387 = MAKE_SEQ(_1);
    DeRef(_t_56129);
    DeRef(_28377);
    _28377 = NOVALUE;
    DeRef(_28382);
    _28382 = NOVALUE;
    _28379 = NOVALUE;
    return _28387;
    goto L6; // [147] 169
L4: 

    /** parser.e:614						return {VARIABLE, private_sym[p]}*/
    _2 = (object)SEQ_PTR(_36private_sym_21883);
    _28388 = (object)*(((s1_ptr)_2)->base + _p_56130);
    Ref(_28388);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -100;
    ((intptr_t *)_2)[2] = _28388;
    _28389 = MAKE_SEQ(_1);
    _28388 = NOVALUE;
    DeRef(_t_56129);
    DeRef(_28387);
    _28387 = NOVALUE;
    DeRef(_28377);
    _28377 = NOVALUE;
    DeRef(_28382);
    _28382 = NOVALUE;
    _28379 = NOVALUE;
    return _28389;
L6: 
L3: 
L2: 

    /** parser.e:620			prev_Nne = No_new_entry*/
    _prev_Nne_56131 = _54No_new_entry_48334;

    /** parser.e:621			No_new_entry = 1*/
    _54No_new_entry_48334 = 1;

    /** parser.e:623			if Recorded_sym[n] > 0 and  sym_scope( Recorded_sym[n] ) != SC_UNDEFINED then*/
    _2 = (object)SEQ_PTR(_36Recorded_sym_21879);
    _28390 = (object)*(((s1_ptr)_2)->base + _n_56127);
    if (IS_ATOM_INT(_28390)) {
        _28391 = (_28390 > 0);
    }
    else {
        _28391 = binary_op(GREATER, _28390, 0);
    }
    _28390 = NOVALUE;
    if (IS_ATOM_INT(_28391)) {
        if (_28391 == 0) {
            goto L7; // [199] 250
        }
    }
    else {
        if (DBL_PTR(_28391)->dbl == 0.0) {
            goto L7; // [199] 250
        }
    }
    _2 = (object)SEQ_PTR(_36Recorded_sym_21879);
    _28393 = (object)*(((s1_ptr)_2)->base + _n_56127);
    Ref(_28393);
    _28394 = _54sym_scope(_28393);
    _28393 = NOVALUE;
    if (IS_ATOM_INT(_28394)) {
        _28395 = (_28394 != 9);
    }
    else {
        _28395 = binary_op(NOTEQ, _28394, 9);
    }
    DeRef(_28394);
    _28394 = NOVALUE;
    if (_28395 == 0) {
        DeRef(_28395);
        _28395 = NOVALUE;
        goto L7; // [220] 250
    }
    else {
        if (!IS_ATOM_INT(_28395) && DBL_PTR(_28395)->dbl == 0.0){
            DeRef(_28395);
            _28395 = NOVALUE;
            goto L7; // [220] 250
        }
        DeRef(_28395);
        _28395 = NOVALUE;
    }
    DeRef(_28395);
    _28395 = NOVALUE;

    /** parser.e:624				t = { sym_token( Recorded_sym[n] ), Recorded_sym[n] }*/
    _2 = (object)SEQ_PTR(_36Recorded_sym_21879);
    _28396 = (object)*(((s1_ptr)_2)->base + _n_56127);
    Ref(_28396);
    _28397 = _54sym_token(_28396);
    _28396 = NOVALUE;
    _2 = (object)SEQ_PTR(_36Recorded_sym_21879);
    _28398 = (object)*(((s1_ptr)_2)->base + _n_56127);
    Ref(_28398);
    DeRef(_t_56129);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _28397;
    ((intptr_t *)_2)[2] = _28398;
    _t_56129 = MAKE_SEQ(_1);
    _28398 = NOVALUE;
    _28397 = NOVALUE;

    /** parser.e:625				break "top if"*/
    goto L8; // [247] 734
L7: 

    /** parser.e:628			t = keyfind(Recorded[n],-1)*/
    _2 = (object)SEQ_PTR(_36Recorded_21877);
    _28400 = (object)*(((s1_ptr)_2)->base + _n_56127);
    RefDS(_28400);
    DeRef(_31968);
    _31968 = _28400;
    _31969 = _54hashfn(_31968);
    _31968 = NOVALUE;
    RefDS(_28400);
    _0 = _t_56129;
    _t_56129 = _54keyfind(_28400, -1, _36current_file_no_21767, 0, _31969);
    DeRef(_0);
    _28400 = NOVALUE;
    _31969 = NOVALUE;

    /** parser.e:629			if t[T_ID] = IGNORED then*/
    _2 = (object)SEQ_PTR(_t_56129);
    _28402 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28402, 509)){
        _28402 = NOVALUE;
        goto L8; // [286] 734
    }
    _28402 = NOVALUE;

    /** parser.e:630		        p = Recorded_sym[n]*/
    _2 = (object)SEQ_PTR(_36Recorded_sym_21879);
    _p_56130 = (object)*(((s1_ptr)_2)->base + _n_56127);
    if (!IS_ATOM_INT(_p_56130)){
        _p_56130 = (object)DBL_PTR(_p_56130)->dbl;
    }

    /** parser.e:631		        if p = 0 then*/
    if (_p_56130 != 0)
    goto L9; // [302] 382

    /** parser.e:633					No_new_entry = 0*/
    _54No_new_entry_48334 = 0;

    /** parser.e:634					t = keyfind( Recorded[n], -1 )*/
    _2 = (object)SEQ_PTR(_36Recorded_21877);
    _28406 = (object)*(((s1_ptr)_2)->base + _n_56127);
    RefDS(_28406);
    DeRef(_31966);
    _31966 = _28406;
    _31967 = _54hashfn(_31966);
    _31966 = NOVALUE;
    RefDS(_28406);
    _0 = _t_56129;
    _t_56129 = _54keyfind(_28406, -1, _36current_file_no_21767, 0, _31967);
    DeRef(_0);
    _28406 = NOVALUE;
    _31967 = NOVALUE;

    /** parser.e:635					No_new_entry = 1*/
    _54No_new_entry_48334 = 1;

    /** parser.e:636					if t[T_ID] = IGNORED then*/
    _2 = (object)SEQ_PTR(_t_56129);
    _28408 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28408, 509)){
        _28408 = NOVALUE;
        goto L8; // [355] 734
    }
    _28408 = NOVALUE;

    /** parser.e:637						CompileErr(VARIABLE_1_HAS_NOT_BEEN_DECLARED,{Recorded[n]})*/
    _2 = (object)SEQ_PTR(_36Recorded_21877);
    _28410 = (object)*(((s1_ptr)_2)->base + _n_56127);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_28410);
    ((intptr_t*)_2)[1] = _28410;
    _28411 = MAKE_SEQ(_1);
    _28410 = NOVALUE;
    _50CompileErr(157, _28411, 0);
    _28411 = NOVALUE;
    goto L8; // [379] 734
L9: 

    /** parser.e:640					t = {SymTab[p][S_TOKEN], p}*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _28412 = (object)*(((s1_ptr)_2)->base + _p_56130);
    _2 = (object)SEQ_PTR(_28412);
    if (!IS_ATOM_INT(_36S_TOKEN_21409)){
        _28413 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21409)->dbl));
    }
    else{
        _28413 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21409);
    }
    _28412 = NOVALUE;
    Ref(_28413);
    DeRef(_t_56129);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _28413;
    ((intptr_t *)_2)[2] = _p_56130;
    _t_56129 = MAKE_SEQ(_1);
    _28413 = NOVALUE;
    goto L8; // [402] 734
L1: 

    /** parser.e:644			prev_Nne = No_new_entry*/
    _prev_Nne_56131 = _54No_new_entry_48334;

    /** parser.e:645			No_new_entry = 1*/
    _54No_new_entry_48334 = 1;

    /** parser.e:646			t = keyfind(Ns_recorded[n],-1, , 1)*/
    _2 = (object)SEQ_PTR(_36Ns_recorded_21878);
    _28415 = (object)*(((s1_ptr)_2)->base + _n_56127);
    Ref(_28415);
    DeRef(_31964);
    _31964 = _28415;
    _31965 = _54hashfn(_31964);
    _31964 = NOVALUE;
    Ref(_28415);
    _0 = _t_56129;
    _t_56129 = _54keyfind(_28415, -1, _36current_file_no_21767, 1, _31965);
    DeRef(_0);
    _28415 = NOVALUE;
    _31965 = NOVALUE;

    /** parser.e:647			if t[T_ID] != NAMESPACE then*/
    _2 = (object)SEQ_PTR(_t_56129);
    _28417 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _28417, 523)){
        _28417 = NOVALUE;
        goto LA; // [456] 524
    }
    _28417 = NOVALUE;

    /** parser.e:648				p = Ns_recorded_sym[n]*/
    _2 = (object)SEQ_PTR(_36Ns_recorded_sym_21880);
    _p_56130 = (object)*(((s1_ptr)_2)->base + _n_56127);
    if (!IS_ATOM_INT(_p_56130)){
        _p_56130 = (object)DBL_PTR(_p_56130)->dbl;
    }

    /** parser.e:649				if p = 0 or sym_token( p ) != NAMESPACE then*/
    _28420 = (_p_56130 == 0);
    if (_28420 != 0) {
        goto LB; // [476] 495
    }
    _28422 = _54sym_token(_p_56130);
    if (IS_ATOM_INT(_28422)) {
        _28423 = (_28422 != 523);
    }
    else {
        _28423 = binary_op(NOTEQ, _28422, 523);
    }
    DeRef(_28422);
    _28422 = NOVALUE;
    if (_28423 == 0) {
        DeRef(_28423);
        _28423 = NOVALUE;
        goto LC; // [491] 515
    }
    else {
        if (!IS_ATOM_INT(_28423) && DBL_PTR(_28423)->dbl == 0.0){
            DeRef(_28423);
            _28423 = NOVALUE;
            goto LC; // [491] 515
        }
        DeRef(_28423);
        _28423 = NOVALUE;
    }
    DeRef(_28423);
    _28423 = NOVALUE;
LB: 

    /** parser.e:650					CompileErr(UNKNOWN_NAMESPACE_1_IN_DEFAULT_ARGUMENT, {Ns_recorded[n]})*/
    _2 = (object)SEQ_PTR(_36Ns_recorded_21878);
    _28424 = (object)*(((s1_ptr)_2)->base + _n_56127);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_28424);
    ((intptr_t*)_2)[1] = _28424;
    _28425 = MAKE_SEQ(_1);
    _28424 = NOVALUE;
    _50CompileErr(153, _28425, 0);
    _28425 = NOVALUE;
LC: 

    /** parser.e:652				t = {NAMESPACE, p}*/
    DeRef(_t_56129);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 523;
    ((intptr_t *)_2)[2] = _p_56130;
    _t_56129 = MAKE_SEQ(_1);
LA: 

    /** parser.e:655			t = keyfind(Recorded[n],SymTab[t[T_SYM]][S_OBJ])*/
    _2 = (object)SEQ_PTR(_36Recorded_21877);
    _28427 = (object)*(((s1_ptr)_2)->base + _n_56127);
    _2 = (object)SEQ_PTR(_t_56129);
    _28428 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!IS_ATOM_INT(_28428)){
        _28429 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_28428)->dbl));
    }
    else{
        _28429 = (object)*(((s1_ptr)_2)->base + _28428);
    }
    _2 = (object)SEQ_PTR(_28429);
    _28430 = (object)*(((s1_ptr)_2)->base + 1);
    _28429 = NOVALUE;
    RefDS(_28427);
    DeRef(_31962);
    _31962 = _28427;
    _31963 = _54hashfn(_31962);
    _31962 = NOVALUE;
    RefDS(_28427);
    Ref(_28430);
    _0 = _t_56129;
    _t_56129 = _54keyfind(_28427, _28430, _36current_file_no_21767, 0, _31963);
    DeRef(_0);
    _28427 = NOVALUE;
    _28430 = NOVALUE;
    _31963 = NOVALUE;

    /** parser.e:656			if t[T_ID] = IGNORED then*/
    _2 = (object)SEQ_PTR(_t_56129);
    _28432 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28432, 509)){
        _28432 = NOVALUE;
        goto LD; // [577] 636
    }
    _28432 = NOVALUE;

    /** parser.e:657		        p = Recorded_sym[n]*/
    _2 = (object)SEQ_PTR(_36Recorded_sym_21879);
    _p_56130 = (object)*(((s1_ptr)_2)->base + _n_56127);
    if (!IS_ATOM_INT(_p_56130)){
        _p_56130 = (object)DBL_PTR(_p_56130)->dbl;
    }

    /** parser.e:658		        if p = 0 then*/
    if (_p_56130 != 0)
    goto LE; // [593] 617

    /** parser.e:659		        	CompileErr(VARIABLE_1_HAS_NOT_BEEN_DECLARED,{Recorded[n]})*/
    _2 = (object)SEQ_PTR(_36Recorded_21877);
    _28436 = (object)*(((s1_ptr)_2)->base + _n_56127);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_28436);
    ((intptr_t*)_2)[1] = _28436;
    _28437 = MAKE_SEQ(_1);
    _28436 = NOVALUE;
    _50CompileErr(157, _28437, 0);
    _28437 = NOVALUE;
LE: 

    /** parser.e:661			    t = {SymTab[p][S_TOKEN], p}*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _28438 = (object)*(((s1_ptr)_2)->base + _p_56130);
    _2 = (object)SEQ_PTR(_28438);
    if (!IS_ATOM_INT(_36S_TOKEN_21409)){
        _28439 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21409)->dbl));
    }
    else{
        _28439 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21409);
    }
    _28438 = NOVALUE;
    Ref(_28439);
    DeRef(_t_56129);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _28439;
    ((intptr_t *)_2)[2] = _p_56130;
    _t_56129 = MAKE_SEQ(_1);
    _28439 = NOVALUE;
LD: 

    /** parser.e:663			n = t[T_ID]*/
    _2 = (object)SEQ_PTR(_t_56129);
    _n_56127 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_n_56127)){
        _n_56127 = (object)DBL_PTR(_n_56127)->dbl;
    }

    /** parser.e:664			if n = VARIABLE then*/
    if (_n_56127 != -100)
    goto LF; // [650] 666

    /** parser.e:665				n = QUALIFIED_VARIABLE*/
    _n_56127 = 512;
    goto L10; // [663] 725
LF: 

    /** parser.e:666			elsif n = FUNC then*/
    if (_n_56127 != 501)
    goto L11; // [670] 686

    /** parser.e:667				n = QUALIFIED_FUNC*/
    _n_56127 = 520;
    goto L10; // [683] 725
L11: 

    /** parser.e:668			elsif n = PROC then*/
    if (_n_56127 != 27)
    goto L12; // [690] 706

    /** parser.e:669				n = QUALIFIED_PROC*/
    _n_56127 = 521;
    goto L10; // [703] 725
L12: 

    /** parser.e:670			elsif n = TYPE then*/
    if (_n_56127 != 504)
    goto L13; // [710] 724

    /** parser.e:671				n = QUALIFIED_TYPE*/
    _n_56127 = 522;
L13: 
L10: 

    /** parser.e:673			t[T_ID] = n*/
    _2 = (object)SEQ_PTR(_t_56129);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _t_56129 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _n_56127;
    DeRef(_1);
L8: 

    /** parser.e:675		No_new_entry = prev_Nne*/
    _54No_new_entry_48334 = _prev_Nne_56131;

    /** parser.e:676	  	return t*/
    DeRef(_28391);
    _28391 = NOVALUE;
    DeRef(_28387);
    _28387 = NOVALUE;
    DeRef(_28389);
    _28389 = NOVALUE;
    DeRef(_28377);
    _28377 = NOVALUE;
    DeRef(_28420);
    _28420 = NOVALUE;
    DeRef(_28382);
    _28382 = NOVALUE;
    _28428 = NOVALUE;
    _28379 = NOVALUE;
    return _t_56129;
    ;
}


object _45next_token()
{
    object _t_56311 = NOVALUE;
    object _s_56312 = NOVALUE;
    object _28478 = NOVALUE;
    object _28477 = NOVALUE;
    object _28476 = NOVALUE;
    object _28475 = NOVALUE;
    object _28474 = NOVALUE;
    object _28473 = NOVALUE;
    object _28472 = NOVALUE;
    object _28471 = NOVALUE;
    object _28469 = NOVALUE;
    object _28468 = NOVALUE;
    object _28467 = NOVALUE;
    object _28466 = NOVALUE;
    object _28464 = NOVALUE;
    object _28462 = NOVALUE;
    object _28460 = NOVALUE;
    object _28456 = NOVALUE;
    object _28453 = NOVALUE;
    object _28450 = NOVALUE;
    object _28448 = NOVALUE;
    object _28446 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:682		sequence s*/

    /** parser.e:684		if length(backed_up_tok) > 0 then*/
    if (IS_SEQUENCE(_45backed_up_tok_55363)){
            _28446 = SEQ_PTR(_45backed_up_tok_55363)->length;
    }
    else {
        _28446 = 1;
    }
    if (_28446 <= 0)
    goto L1; // [10] 82

    /** parser.e:685			t = backed_up_tok[$]*/
    if (IS_SEQUENCE(_45backed_up_tok_55363)){
            _28448 = SEQ_PTR(_45backed_up_tok_55363)->length;
    }
    else {
        _28448 = 1;
    }
    DeRef(_t_56311);
    _2 = (object)SEQ_PTR(_45backed_up_tok_55363);
    _t_56311 = (object)*(((s1_ptr)_2)->base + _28448);
    Ref(_t_56311);

    /** parser.e:686			backed_up_tok = remove( backed_up_tok, length( backed_up_tok ) )*/
    if (IS_SEQUENCE(_45backed_up_tok_55363)){
            _28450 = SEQ_PTR(_45backed_up_tok_55363)->length;
    }
    else {
        _28450 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_45backed_up_tok_55363);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_28450)) ? _28450 : (object)(DBL_PTR(_28450)->dbl);
        int stop = (IS_ATOM_INT(_28450)) ? _28450 : (object)(DBL_PTR(_28450)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_45backed_up_tok_55363), start, &_45backed_up_tok_55363 );
            }
            else Tail(SEQ_PTR(_45backed_up_tok_55363), stop+1, &_45backed_up_tok_55363);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_45backed_up_tok_55363), start, &_45backed_up_tok_55363);
        }
        else {
            assign_slice_seq = &assign_space;
            _45backed_up_tok_55363 = Remove_elements(start, stop, (SEQ_PTR(_45backed_up_tok_55363)->ref == 1));
        }
    }
    _28450 = NOVALUE;
    _28450 = NOVALUE;

    /** parser.e:687			if putback_fwd_line_number then*/
    if (_36putback_fwd_line_number_21770 == 0)
    {
        goto L2; // [43] 349
    }
    else{
    }

    /** parser.e:689				ForwardLine     = putback_ForwardLine*/
    Ref(_50putback_ForwardLine_49596);
    DeRef(_50ForwardLine_49595);
    _50ForwardLine_49595 = _50putback_ForwardLine_49596;

    /** parser.e:690				forward_bp      = putback_forward_bp*/
    _50forward_bp_49599 = _50putback_forward_bp_49600;

    /** parser.e:691				fwd_line_number = putback_fwd_line_number*/
    _36fwd_line_number_21769 = _36putback_fwd_line_number_21770;

    /** parser.e:693				putback_fwd_line_number = 0*/
    _36putback_fwd_line_number_21770 = 0;
    goto L2; // [79] 349
L1: 

    /** parser.e:696		elsif Parser_mode = PAM_PLAYBACK then*/
    if (_36Parser_mode_21876 != -1)
    goto L3; // [88] 302

    /** parser.e:697			if canned_index <= length(canned_tokens) then*/
    if (IS_SEQUENCE(_45canned_tokens_55400)){
            _28453 = SEQ_PTR(_45canned_tokens_55400)->length;
    }
    else {
        _28453 = 1;
    }
    if (_45canned_index_55401 > _28453)
    goto L4; // [101] 150

    /** parser.e:698				t = canned_tokens[canned_index]*/
    DeRef(_t_56311);
    _2 = (object)SEQ_PTR(_45canned_tokens_55400);
    _t_56311 = (object)*(((s1_ptr)_2)->base + _45canned_index_55401);
    Ref(_t_56311);

    /** parser.e:699				if canned_index < length(canned_tokens) then*/
    if (IS_SEQUENCE(_45canned_tokens_55400)){
            _28456 = SEQ_PTR(_45canned_tokens_55400)->length;
    }
    else {
        _28456 = 1;
    }
    if (_45canned_index_55401 >= _28456)
    goto L5; // [124] 139

    /** parser.e:700					canned_index += 1*/
    _45canned_index_55401 = _45canned_index_55401 + 1;
    goto L6; // [136] 157
L5: 

    /** parser.e:702		            s = restore_parser()*/
    _0 = _s_56312;
    _s_56312 = _45restore_parser();
    DeRef(_0);
    goto L6; // [147] 157
L4: 

    /** parser.e:705		    	InternalErr(266)*/
    RefDS(_22190);
    _50InternalErr(266, _22190);
L6: 

    /** parser.e:707			if t[T_ID] = RECORDED then*/
    _2 = (object)SEQ_PTR(_t_56311);
    _28460 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28460, 508)){
        _28460 = NOVALUE;
        goto L7; // [169] 188
    }
    _28460 = NOVALUE;

    /** parser.e:708				t=read_recorded_token(t[T_SYM])*/
    _2 = (object)SEQ_PTR(_t_56311);
    _28462 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_28462);
    _0 = _t_56311;
    _t_56311 = _45read_recorded_token(_28462);
    DeRef(_0);
    _28462 = NOVALUE;
    goto L2; // [185] 349
L7: 

    /** parser.e:709			elsif t[T_ID] = DEF_PARAM then*/
    _2 = (object)SEQ_PTR(_t_56311);
    _28464 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28464, 510)){
        _28464 = NOVALUE;
        goto L2; // [198] 349
    }
    _28464 = NOVALUE;

    /** parser.e:710	        	for i=length(nested_calls) to 1 by -1 do*/
    if (IS_SEQUENCE(_45nested_calls_56103)){
            _28466 = SEQ_PTR(_45nested_calls_56103)->length;
    }
    else {
        _28466 = 1;
    }
    {
        object _i_56359;
        _i_56359 = _28466;
L8: 
        if (_i_56359 < 1){
            goto L9; // [209] 288
        }

        /** parser.e:711	        	    if nested_calls[i] = t[T_SYM][2] then*/
        _2 = (object)SEQ_PTR(_45nested_calls_56103);
        _28467 = (object)*(((s1_ptr)_2)->base + _i_56359);
        _2 = (object)SEQ_PTR(_t_56311);
        _28468 = (object)*(((s1_ptr)_2)->base + 2);
        _2 = (object)SEQ_PTR(_28468);
        _28469 = (object)*(((s1_ptr)_2)->base + 2);
        _28468 = NOVALUE;
        if (binary_op_a(NOTEQ, _28467, _28469)){
            _28467 = NOVALUE;
            _28469 = NOVALUE;
            goto LA; // [234] 281
        }
        _28467 = NOVALUE;
        _28469 = NOVALUE;

        /** parser.e:712						return {VARIABLE, private_sym[parseargs_states[i][PS_POSITION]+t[T_SYM][1]]}*/
        _2 = (object)SEQ_PTR(_45parseargs_states_56095);
        _28471 = (object)*(((s1_ptr)_2)->base + _i_56359);
        _2 = (object)SEQ_PTR(_28471);
        _28472 = (object)*(((s1_ptr)_2)->base + 1);
        _28471 = NOVALUE;
        _2 = (object)SEQ_PTR(_t_56311);
        _28473 = (object)*(((s1_ptr)_2)->base + 2);
        _2 = (object)SEQ_PTR(_28473);
        _28474 = (object)*(((s1_ptr)_2)->base + 1);
        _28473 = NOVALUE;
        if (IS_ATOM_INT(_28472) && IS_ATOM_INT(_28474)) {
            _28475 = _28472 + _28474;
        }
        else {
            _28475 = binary_op(PLUS, _28472, _28474);
        }
        _28472 = NOVALUE;
        _28474 = NOVALUE;
        _2 = (object)SEQ_PTR(_36private_sym_21883);
        if (!IS_ATOM_INT(_28475)){
            _28476 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_28475)->dbl));
        }
        else{
            _28476 = (object)*(((s1_ptr)_2)->base + _28475);
        }
        Ref(_28476);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = -100;
        ((intptr_t *)_2)[2] = _28476;
        _28477 = MAKE_SEQ(_1);
        _28476 = NOVALUE;
        DeRef(_t_56311);
        DeRef(_s_56312);
        DeRef(_28475);
        _28475 = NOVALUE;
        return _28477;
LA: 

        /** parser.e:714				end for*/
        _i_56359 = _i_56359 + -1;
        goto L8; // [283] 216
L9: 
        ;
    }

    /** parser.e:715				CompileErr(INTERNAL_NESTED_CALL_PARSING_ERROR)*/
    RefDS(_22190);
    _50CompileErr(98, _22190, 0);
    goto L2; // [299] 349
L3: 

    /** parser.e:717		elsif lock_scanner then*/
    if (_45lock_scanner_56101 == 0)
    {
        goto LB; // [306] 324
    }
    else{
    }

    /** parser.e:718			return {PLAYBACK_ENDS,0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 505;
    ((intptr_t *)_2)[2] = 0;
    _28478 = MAKE_SEQ(_1);
    DeRef(_t_56311);
    DeRef(_s_56312);
    DeRef(_28475);
    _28475 = NOVALUE;
    DeRef(_28477);
    _28477 = NOVALUE;
    return _28478;
    goto L2; // [321] 349
LB: 

    /** parser.e:720		    t = Scanner()*/
    _0 = _t_56311;
    _t_56311 = _62Scanner();
    DeRef(_0);

    /** parser.e:721		    if Parser_mode = PAM_RECORD then*/
    if (_36Parser_mode_21876 != 1)
    goto LC; // [335] 348

    /** parser.e:722		        canned_tokens = append(canned_tokens,t)*/
    Ref(_t_56311);
    Append(&_45canned_tokens_55400, _45canned_tokens_55400, _t_56311);
LC: 
L2: 

    /** parser.e:725		putback_fwd_line_number = 0*/
    _36putback_fwd_line_number_21770 = 0;

    /** parser.e:726		return t*/
    DeRef(_s_56312);
    DeRef(_28475);
    _28475 = NOVALUE;
    DeRef(_28477);
    _28477 = NOVALUE;
    DeRef(_28478);
    _28478 = NOVALUE;
    return _t_56311;
    ;
}


object _45Expr_list()
{
    object _tok_56395 = NOVALUE;
    object _n_56396 = NOVALUE;
    object _28494 = NOVALUE;
    object _28491 = NOVALUE;
    object _28490 = NOVALUE;
    object _28488 = NOVALUE;
    object _28487 = NOVALUE;
    object _28483 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:734		integer n*/

    /** parser.e:736		tok = next_token()*/
    _0 = _tok_56395;
    _tok_56395 = _45next_token();
    DeRef(_0);

    /** parser.e:737		putback(tok)*/
    Ref(_tok_56395);
    _45putback(_tok_56395);

    /** parser.e:738		if tok[T_ID] = RIGHT_BRACE then*/
    _2 = (object)SEQ_PTR(_tok_56395);
    _28483 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28483, -25)){
        _28483 = NOVALUE;
        goto L1; // [23] 36
    }
    _28483 = NOVALUE;

    /** parser.e:739			return 0*/
    DeRef(_tok_56395);
    return 0;
    goto L2; // [33] 142
L1: 

    /** parser.e:741			n = 0*/
    _n_56396 = 0;

    /** parser.e:742			short_circuit -= 1*/
    _45short_circuit_55356 = _45short_circuit_55356 - 1;

    /** parser.e:743			while TRUE do*/
L3: 
    if (_13TRUE_447 == 0)
    {
        goto L4; // [56] 133
    }
    else{
    }

    /** parser.e:744				gListItem &= 1*/
    Append(&_45gListItem_55392, _45gListItem_55392, 1);

    /** parser.e:745				Expr()*/
    _45Expr();

    /** parser.e:746				n += gListItem[$]*/
    if (IS_SEQUENCE(_45gListItem_55392)){
            _28487 = SEQ_PTR(_45gListItem_55392)->length;
    }
    else {
        _28487 = 1;
    }
    _2 = (object)SEQ_PTR(_45gListItem_55392);
    _28488 = (object)*(((s1_ptr)_2)->base + _28487);
    _n_56396 = _n_56396 + _28488;
    _28488 = NOVALUE;

    /** parser.e:747				gListItem = gListItem[1 .. $-1]*/
    if (IS_SEQUENCE(_45gListItem_55392)){
            _28490 = SEQ_PTR(_45gListItem_55392)->length;
    }
    else {
        _28490 = 1;
    }
    _28491 = _28490 - 1;
    _28490 = NOVALUE;
    rhs_slice_target = (object_ptr)&_45gListItem_55392;
    RHS_Slice(_45gListItem_55392, 1, _28491);

    /** parser.e:748				tok = next_token()*/
    _0 = _tok_56395;
    _tok_56395 = _45next_token();
    DeRef(_0);

    /** parser.e:749				if tok[T_ID] != COMMA then*/
    _2 = (object)SEQ_PTR(_tok_56395);
    _28494 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _28494, -30)){
        _28494 = NOVALUE;
        goto L3; // [119] 54
    }
    _28494 = NOVALUE;

    /** parser.e:750					exit*/
    goto L4; // [125] 133

    /** parser.e:752			end while*/
    goto L3; // [130] 54
L4: 

    /** parser.e:753			short_circuit += 1*/
    _45short_circuit_55356 = _45short_circuit_55356 + 1;
L2: 

    /** parser.e:755		putback(tok)*/
    Ref(_tok_56395);
    _45putback(_tok_56395);

    /** parser.e:756		return n*/
    DeRef(_tok_56395);
    DeRef(_28491);
    _28491 = NOVALUE;
    return _n_56396;
    ;
}


void _45tok_match(object _tok_56424, object _prevtok_56425)
{
    object _t_56427 = NOVALUE;
    object _expected_56428 = NOVALUE;
    object _actual_56429 = NOVALUE;
    object _prevname_56430 = NOVALUE;
    object _28506 = NOVALUE;
    object _28504 = NOVALUE;
    object _28501 = NOVALUE;
    object _28498 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:762		sequence expected, actual, prevname*/

    /** parser.e:764		t = next_token()*/
    _0 = _t_56427;
    _t_56427 = _45next_token();
    DeRef(_0);

    /** parser.e:765		if t[T_ID] != tok then*/
    _2 = (object)SEQ_PTR(_t_56427);
    _28498 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _28498, _tok_56424)){
        _28498 = NOVALUE;
        goto L1; // [20] 96
    }
    _28498 = NOVALUE;

    /** parser.e:766			expected = LexName(tok)*/
    RefDS(_26602);
    _0 = _expected_56428;
    _expected_56428 = _47LexName(_tok_56424, _26602);
    DeRef(_0);

    /** parser.e:767			actual = LexName(t[T_ID])*/
    _2 = (object)SEQ_PTR(_t_56427);
    _28501 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_28501);
    RefDS(_26602);
    _0 = _actual_56429;
    _actual_56429 = _47LexName(_28501, _26602);
    DeRef(_0);
    _28501 = NOVALUE;

    /** parser.e:768			if prevtok = 0 then*/
    if (_prevtok_56425 != 0)
    goto L2; // [50] 70

    /** parser.e:769				CompileErr(SYNTAX_ERROR__EXPECTED_TO_SEE_POSSIBLY_1_NOT_2, {expected, actual})*/
    RefDS(_actual_56429);
    RefDS(_expected_56428);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _expected_56428;
    ((intptr_t *)_2)[2] = _actual_56429;
    _28504 = MAKE_SEQ(_1);
    _50CompileErr(132, _28504, 0);
    _28504 = NOVALUE;
    goto L3; // [67] 95
L2: 

    /** parser.e:771				prevname = LexName(prevtok)*/
    RefDS(_26602);
    _0 = _prevname_56430;
    _prevname_56430 = _47LexName(_prevtok_56425, _26602);
    DeRef(_0);

    /** parser.e:772				CompileErr(SYNTAX_ERROR__EXPECTED_TO_SEE_1_AFTER_2_NOT_3, {expected, prevname, actual})*/
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_expected_56428);
    ((intptr_t*)_2)[1] = _expected_56428;
    RefDS(_prevname_56430);
    ((intptr_t*)_2)[2] = _prevname_56430;
    RefDS(_actual_56429);
    ((intptr_t*)_2)[3] = _actual_56429;
    _28506 = MAKE_SEQ(_1);
    _50CompileErr(138, _28506, 0);
    _28506 = NOVALUE;
L3: 
L1: 

    /** parser.e:775	end procedure*/
    DeRef(_t_56427);
    DeRef(_expected_56428);
    DeRef(_actual_56429);
    DeRef(_prevname_56430);
    return;
    ;
}


void _45UndefinedVar(object _s_56466)
{
    object _dup_56468 = NOVALUE;
    object _errmsg_56469 = NOVALUE;
    object _rname_56470 = NOVALUE;
    object _fname_56471 = NOVALUE;
    object _28529 = NOVALUE;
    object _28528 = NOVALUE;
    object _28526 = NOVALUE;
    object _28524 = NOVALUE;
    object _28523 = NOVALUE;
    object _28521 = NOVALUE;
    object _28519 = NOVALUE;
    object _28517 = NOVALUE;
    object _28516 = NOVALUE;
    object _28515 = NOVALUE;
    object _28514 = NOVALUE;
    object _28513 = NOVALUE;
    object _28511 = NOVALUE;
    object _28510 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_s_56466)) {
        _1 = (object)(DBL_PTR(_s_56466)->dbl);
        DeRefDS(_s_56466);
        _s_56466 = _1;
    }

    /** parser.e:790		sequence errmsg*/

    /** parser.e:791		sequence rname*/

    /** parser.e:792		sequence fname*/

    /** parser.e:794		if SymTab[s][S_SCOPE] = SC_UNDEFINED then*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _28510 = (object)*(((s1_ptr)_2)->base + _s_56466);
    _2 = (object)SEQ_PTR(_28510);
    _28511 = (object)*(((s1_ptr)_2)->base + 4);
    _28510 = NOVALUE;
    if (binary_op_a(NOTEQ, _28511, 9)){
        _28511 = NOVALUE;
        goto L1; // [25] 57
    }
    _28511 = NOVALUE;

    /** parser.e:795			CompileErr(MSG_1_HAS_NOT_BEEN_DECLARED, {SymTab[s][S_NAME]})*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _28513 = (object)*(((s1_ptr)_2)->base + _s_56466);
    _2 = (object)SEQ_PTR(_28513);
    if (!IS_ATOM_INT(_36S_NAME_21404)){
        _28514 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21404)->dbl));
    }
    else{
        _28514 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21404);
    }
    _28513 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_28514);
    ((intptr_t*)_2)[1] = _28514;
    _28515 = MAKE_SEQ(_1);
    _28514 = NOVALUE;
    _50CompileErr(19, _28515, 0);
    _28515 = NOVALUE;
    goto L2; // [54] 206
L1: 

    /** parser.e:797		elsif SymTab[s][S_SCOPE] = SC_MULTIPLY_DEFINED then*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _28516 = (object)*(((s1_ptr)_2)->base + _s_56466);
    _2 = (object)SEQ_PTR(_28516);
    _28517 = (object)*(((s1_ptr)_2)->base + 4);
    _28516 = NOVALUE;
    if (binary_op_a(NOTEQ, _28517, 10)){
        _28517 = NOVALUE;
        goto L3; // [73] 183
    }
    _28517 = NOVALUE;

    /** parser.e:798			rname = SymTab[s][S_NAME]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _28519 = (object)*(((s1_ptr)_2)->base + _s_56466);
    DeRef(_rname_56470);
    _2 = (object)SEQ_PTR(_28519);
    if (!IS_ATOM_INT(_36S_NAME_21404)){
        _rname_56470 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21404)->dbl));
    }
    else{
        _rname_56470 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21404);
    }
    Ref(_rname_56470);
    _28519 = NOVALUE;

    /** parser.e:799			errmsg = ""*/
    RefDS(_22190);
    DeRef(_errmsg_56469);
    _errmsg_56469 = _22190;

    /** parser.e:801			for i = 1 to length(dup_globals) do*/
    if (IS_SEQUENCE(_54dup_globals_48323)){
            _28521 = SEQ_PTR(_54dup_globals_48323)->length;
    }
    else {
        _28521 = 1;
    }
    {
        object _i_56498;
        _i_56498 = 1;
L4: 
        if (_i_56498 > _28521){
            goto L5; // [107] 165
        }

        /** parser.e:802				dup = dup_globals[i]*/
        _2 = (object)SEQ_PTR(_54dup_globals_48323);
        _dup_56468 = (object)*(((s1_ptr)_2)->base + _i_56498);
        if (!IS_ATOM_INT(_dup_56468)){
            _dup_56468 = (object)DBL_PTR(_dup_56468)->dbl;
        }

        /** parser.e:803				fname = known_files[SymTab[dup][S_FILE_NO]]*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _28523 = (object)*(((s1_ptr)_2)->base + _dup_56468);
        _2 = (object)SEQ_PTR(_28523);
        if (!IS_ATOM_INT(_36S_FILE_NO_21400)){
            _28524 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21400)->dbl));
        }
        else{
            _28524 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21400);
        }
        _28523 = NOVALUE;
        DeRef(_fname_56471);
        _2 = (object)SEQ_PTR(_37known_files_15638);
        if (!IS_ATOM_INT(_28524)){
            _fname_56471 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_28524)->dbl));
        }
        else{
            _fname_56471 = (object)*(((s1_ptr)_2)->base + _28524);
        }
        Ref(_fname_56471);

        /** parser.e:804				errmsg &= "    " & fname & "\n"*/
        {
            object concat_list[3];

            concat_list[0] = _22385;
            concat_list[1] = _fname_56471;
            concat_list[2] = _25096;
            Concat_N((object_ptr)&_28526, concat_list, 3);
        }
        Concat((object_ptr)&_errmsg_56469, _errmsg_56469, _28526);
        DeRefDS(_28526);
        _28526 = NOVALUE;

        /** parser.e:806			end for*/
        _i_56498 = _i_56498 + 1;
        goto L4; // [160] 114
L5: 
        ;
    }

    /** parser.e:808			CompileErr(A_NAMESPACE_QUALIFIER_IS_NEEDED_TO_RESOLVE_1BECAUSE_2_IS_DECLARED_AS_A_GLOBALPUBLIC_SYMBOL_IN3, {rname, rname, errmsg})*/
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDSn(_rname_56470, 2);
    ((intptr_t*)_2)[1] = _rname_56470;
    ((intptr_t*)_2)[2] = _rname_56470;
    RefDS(_errmsg_56469);
    ((intptr_t*)_2)[3] = _errmsg_56469;
    _28528 = MAKE_SEQ(_1);
    _50CompileErr(23, _28528, 0);
    _28528 = NOVALUE;
    goto L2; // [180] 206
L3: 

    /** parser.e:810		elsif length(symbol_resolution_warning) then*/
    if (IS_SEQUENCE(_36symbol_resolution_warning_21872)){
            _28529 = SEQ_PTR(_36symbol_resolution_warning_21872)->length;
    }
    else {
        _28529 = 1;
    }
    if (_28529 == 0)
    {
        _28529 = NOVALUE;
        goto L6; // [190] 205
    }
    else{
        _28529 = NOVALUE;
    }

    /** parser.e:811			Warning( symbol_resolution_warning, resolution_warning_flag)*/
    RefDS(_36symbol_resolution_warning_21872);
    RefDS(_22190);
    _50Warning(_36symbol_resolution_warning_21872, 1, _22190);
L6: 
L2: 

    /** parser.e:813	end procedure*/
    DeRef(_errmsg_56469);
    DeRef(_rname_56470);
    DeRef(_fname_56471);
    _28524 = NOVALUE;
    return;
    ;
}


void _45WrongNumberArgs(object _subsym_56523, object _only_56524)
{
    object _msgno_56525 = NOVALUE;
    object _28541 = NOVALUE;
    object _28540 = NOVALUE;
    object _28539 = NOVALUE;
    object _28538 = NOVALUE;
    object _28537 = NOVALUE;
    object _28535 = NOVALUE;
    object _28533 = NOVALUE;
    object _28531 = NOVALUE;
    object _28530 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_subsym_56523)) {
        _1 = (object)(DBL_PTR(_subsym_56523)->dbl);
        DeRefDS(_subsym_56523);
        _subsym_56523 = _1;
    }

    /** parser.e:819		if SymTab[subsym][S_NUM_ARGS] = 1 then*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _28530 = (object)*(((s1_ptr)_2)->base + _subsym_56523);
    _2 = (object)SEQ_PTR(_28530);
    if (!IS_ATOM_INT(_36S_NUM_ARGS_21455)){
        _28531 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21455)->dbl));
    }
    else{
        _28531 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21455);
    }
    _28530 = NOVALUE;
    if (binary_op_a(NOTEQ, _28531, 1)){
        _28531 = NOVALUE;
        goto L1; // [19] 49
    }
    _28531 = NOVALUE;

    /** parser.e:820			if length(only) = 0 then*/
    if (IS_SEQUENCE(_only_56524)){
            _28533 = SEQ_PTR(_only_56524)->length;
    }
    else {
        _28533 = 1;
    }
    if (_28533 != 0)
    goto L2; // [28] 40

    /** parser.e:821				msgno = 20*/
    _msgno_56525 = 20;
    goto L3; // [37] 73
L2: 

    /** parser.e:823				msgno = 237*/
    _msgno_56525 = 237;
    goto L3; // [46] 73
L1: 

    /** parser.e:826			if length(only) = 0 then*/
    if (IS_SEQUENCE(_only_56524)){
            _28535 = SEQ_PTR(_only_56524)->length;
    }
    else {
        _28535 = 1;
    }
    if (_28535 != 0)
    goto L4; // [54] 66

    /** parser.e:827				msgno = 236*/
    _msgno_56525 = 236;
    goto L5; // [63] 72
L4: 

    /** parser.e:829				msgno = 238*/
    _msgno_56525 = 238;
L5: 
L3: 

    /** parser.e:833		CompileErr(msgno, {SymTab[subsym][S_NAME], SymTab[subsym][S_NUM_ARGS]})*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _28537 = (object)*(((s1_ptr)_2)->base + _subsym_56523);
    _2 = (object)SEQ_PTR(_28537);
    if (!IS_ATOM_INT(_36S_NAME_21404)){
        _28538 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21404)->dbl));
    }
    else{
        _28538 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21404);
    }
    _28537 = NOVALUE;
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _28539 = (object)*(((s1_ptr)_2)->base + _subsym_56523);
    _2 = (object)SEQ_PTR(_28539);
    if (!IS_ATOM_INT(_36S_NUM_ARGS_21455)){
        _28540 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21455)->dbl));
    }
    else{
        _28540 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21455);
    }
    _28539 = NOVALUE;
    Ref(_28540);
    Ref(_28538);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _28538;
    ((intptr_t *)_2)[2] = _28540;
    _28541 = MAKE_SEQ(_1);
    _28540 = NOVALUE;
    _28538 = NOVALUE;
    _50CompileErr(_msgno_56525, _28541, 0);
    _28541 = NOVALUE;

    /** parser.e:834	end procedure*/
    DeRefDSi(_only_56524);
    return;
    ;
}


void _45MissingArgs(object _subsym_56554)
{
    object _eentry_56555 = NOVALUE;
    object _28546 = NOVALUE;
    object _28545 = NOVALUE;
    object _28544 = NOVALUE;
    object _28543 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:837		sequence eentry = SymTab[subsym]*/
    DeRef(_eentry_56555);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _eentry_56555 = (object)*(((s1_ptr)_2)->base + _subsym_56554);
    Ref(_eentry_56555);

    /** parser.e:839		CompileErr(MSG_1_NEEDS_AT_LEAST_2_PARAMETERS_BUT_SOME_NONDEFAULTABLE_ARGUMENTS_ARE_MISSING, {eentry[S_NAME], eentry[S_DEF_ARGS][2]})*/
    _2 = (object)SEQ_PTR(_eentry_56555);
    if (!IS_ATOM_INT(_36S_NAME_21404)){
        _28543 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21404)->dbl));
    }
    else{
        _28543 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21404);
    }
    _2 = (object)SEQ_PTR(_eentry_56555);
    _28544 = (object)*(((s1_ptr)_2)->base + 28);
    _2 = (object)SEQ_PTR(_28544);
    _28545 = (object)*(((s1_ptr)_2)->base + 2);
    _28544 = NOVALUE;
    Ref(_28545);
    Ref(_28543);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _28543;
    ((intptr_t *)_2)[2] = _28545;
    _28546 = MAKE_SEQ(_1);
    _28545 = NOVALUE;
    _28543 = NOVALUE;
    _50CompileErr(235, _28546, 0);
    _28546 = NOVALUE;

    /** parser.e:840	end procedure*/
    DeRefDS(_eentry_56555);
    return;
    ;
}


void _45Parse_default_arg(object _subsym_56569, object _arg_56570, object _fwd_private_list_56571, object _fwd_private_sym_56572)
{
    object _param_56574 = NOVALUE;
    object _28566 = NOVALUE;
    object _28565 = NOVALUE;
    object _28564 = NOVALUE;
    object _28563 = NOVALUE;
    object _28562 = NOVALUE;
    object _28561 = NOVALUE;
    object _28560 = NOVALUE;
    object _28559 = NOVALUE;
    object _28558 = NOVALUE;
    object _28557 = NOVALUE;
    object _28556 = NOVALUE;
    object _28555 = NOVALUE;
    object _28554 = NOVALUE;
    object _28552 = NOVALUE;
    object _28551 = NOVALUE;
    object _28548 = NOVALUE;
    object _28547 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:843		symtab_index param = subsym*/
    _param_56574 = _subsym_56569;

    /** parser.e:844		on_arg = arg*/
    _45on_arg_56102 = _arg_56570;

    /** parser.e:845		parseargs_states = append(parseargs_states,*/
    if (IS_SEQUENCE(_45private_list_56100)){
            _28547 = SEQ_PTR(_45private_list_56100)->length;
    }
    else {
        _28547 = 1;
    }
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _28547;
    ((intptr_t*)_2)[2] = _45lock_scanner_56101;
    ((intptr_t*)_2)[3] = _36use_private_list_21884;
    ((intptr_t*)_2)[4] = _45on_arg_56102;
    _28548 = MAKE_SEQ(_1);
    _28547 = NOVALUE;
    RefDS(_28548);
    Append(&_45parseargs_states_56095, _45parseargs_states_56095, _28548);
    DeRefDS(_28548);
    _28548 = NOVALUE;

    /** parser.e:847		nested_calls &= subsym*/
    Append(&_45nested_calls_56103, _45nested_calls_56103, _subsym_56569);

    /** parser.e:849		for i = 1 to arg do*/
    _28551 = _arg_56570;
    {
        object _i_56581;
        _i_56581 = 1;
L1: 
        if (_i_56581 > _28551){
            goto L2; // [60] 90
        }

        /** parser.e:850			param = SymTab[param][S_NEXT]*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _28552 = (object)*(((s1_ptr)_2)->base + _param_56574);
        _2 = (object)SEQ_PTR(_28552);
        _param_56574 = (object)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_param_56574)){
            _param_56574 = (object)DBL_PTR(_param_56574)->dbl;
        }
        _28552 = NOVALUE;

        /** parser.e:851		end for*/
        _i_56581 = _i_56581 + 1;
        goto L1; // [85] 67
L2: 
        ;
    }

    /** parser.e:853		private_list = fwd_private_list*/
    RefDS(_fwd_private_list_56571);
    DeRef(_45private_list_56100);
    _45private_list_56100 = _fwd_private_list_56571;

    /** parser.e:854		private_sym  = fwd_private_sym*/
    RefDS(_fwd_private_sym_56572);
    DeRef(_36private_sym_21883);
    _36private_sym_21883 = _fwd_private_sym_56572;

    /** parser.e:856		if atom(SymTab[param][S_CODE]) then  -- but no default set*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _28554 = (object)*(((s1_ptr)_2)->base + _param_56574);
    _2 = (object)SEQ_PTR(_28554);
    if (!IS_ATOM_INT(_36S_CODE_21416)){
        _28555 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21416)->dbl));
    }
    else{
        _28555 = (object)*(((s1_ptr)_2)->base + _36S_CODE_21416);
    }
    _28554 = NOVALUE;
    _28556 = IS_ATOM(_28555);
    _28555 = NOVALUE;
    if (_28556 == 0)
    {
        _28556 = NOVALUE;
        goto L3; // [121] 164
    }
    else{
        _28556 = NOVALUE;
    }

    /** parser.e:857			CompileErr(ARGUMENT_1_OF_2_3_WAS_OMITTED_BUT_THERE_IS_NO_DEFAULT_VALUE_DEFINED, {arg, SymTab[subsym][S_NAME], SymTab[param][S_NAME]})*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _28557 = (object)*(((s1_ptr)_2)->base + _subsym_56569);
    _2 = (object)SEQ_PTR(_28557);
    if (!IS_ATOM_INT(_36S_NAME_21404)){
        _28558 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21404)->dbl));
    }
    else{
        _28558 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21404);
    }
    _28557 = NOVALUE;
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _28559 = (object)*(((s1_ptr)_2)->base + _param_56574);
    _2 = (object)SEQ_PTR(_28559);
    if (!IS_ATOM_INT(_36S_NAME_21404)){
        _28560 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21404)->dbl));
    }
    else{
        _28560 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21404);
    }
    _28559 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _arg_56570;
    Ref(_28558);
    ((intptr_t*)_2)[2] = _28558;
    Ref(_28560);
    ((intptr_t*)_2)[3] = _28560;
    _28561 = MAKE_SEQ(_1);
    _28560 = NOVALUE;
    _28558 = NOVALUE;
    _50CompileErr(26, _28561, 0);
    _28561 = NOVALUE;
L3: 

    /** parser.e:860		use_private_list = 1*/
    _36use_private_list_21884 = 1;

    /** parser.e:861		lock_scanner = 1*/
    _45lock_scanner_56101 = 1;

    /** parser.e:862		start_playback(SymTab[param][S_CODE] )*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _28562 = (object)*(((s1_ptr)_2)->base + _param_56574);
    _2 = (object)SEQ_PTR(_28562);
    if (!IS_ATOM_INT(_36S_CODE_21416)){
        _28563 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21416)->dbl));
    }
    else{
        _28563 = (object)*(((s1_ptr)_2)->base + _36S_CODE_21416);
    }
    _28562 = NOVALUE;
    Ref(_28563);
    _45start_playback(_28563);
    _28563 = NOVALUE;

    /** parser.e:863		call_proc(forward_expr, {})*/
    _0 = (object)_00[_45forward_expr_56391].addr;
    (*(intptr_t (*)())_0)(
                         );

    /** parser.e:865		add_private_symbol( Top(), SymTab[param][S_NAME] )*/
    _28564 = _47Top();
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _28565 = (object)*(((s1_ptr)_2)->base + _param_56574);
    _2 = (object)SEQ_PTR(_28565);
    if (!IS_ATOM_INT(_36S_NAME_21404)){
        _28566 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21404)->dbl));
    }
    else{
        _28566 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21404);
    }
    _28565 = NOVALUE;
    Ref(_28566);
    _44add_private_symbol(_28564, _28566);
    _28564 = NOVALUE;
    _28566 = NOVALUE;

    /** parser.e:866		lock_scanner = 0*/
    _45lock_scanner_56101 = 0;

    /** parser.e:867		restore_parseargs_states()*/
    _45restore_parseargs_states();

    /** parser.e:868	end procedure*/
    DeRefDS(_fwd_private_list_56571);
    DeRefDSi(_fwd_private_sym_56572);
    return;
    ;
}


void _45ParseArgs(object _subsym_56620)
{
    object _n_56621 = NOVALUE;
    object _fda_56622 = NOVALUE;
    object _lnda_56623 = NOVALUE;
    object _tok_56625 = NOVALUE;
    object _s_56627 = NOVALUE;
    object _var_code_56628 = NOVALUE;
    object _name_56629 = NOVALUE;
    object _28676 = NOVALUE;
    object _28674 = NOVALUE;
    object _28670 = NOVALUE;
    object _28669 = NOVALUE;
    object _28668 = NOVALUE;
    object _28665 = NOVALUE;
    object _28662 = NOVALUE;
    object _28660 = NOVALUE;
    object _28658 = NOVALUE;
    object _28656 = NOVALUE;
    object _28654 = NOVALUE;
    object _28653 = NOVALUE;
    object _28652 = NOVALUE;
    object _28651 = NOVALUE;
    object _28650 = NOVALUE;
    object _28649 = NOVALUE;
    object _28648 = NOVALUE;
    object _28642 = NOVALUE;
    object _28641 = NOVALUE;
    object _28640 = NOVALUE;
    object _28639 = NOVALUE;
    object _28638 = NOVALUE;
    object _28637 = NOVALUE;
    object _28634 = NOVALUE;
    object _28631 = NOVALUE;
    object _28626 = NOVALUE;
    object _28624 = NOVALUE;
    object _28623 = NOVALUE;
    object _28622 = NOVALUE;
    object _28620 = NOVALUE;
    object _28617 = NOVALUE;
    object _28614 = NOVALUE;
    object _28612 = NOVALUE;
    object _28610 = NOVALUE;
    object _28608 = NOVALUE;
    object _28606 = NOVALUE;
    object _28605 = NOVALUE;
    object _28604 = NOVALUE;
    object _28603 = NOVALUE;
    object _28602 = NOVALUE;
    object _28601 = NOVALUE;
    object _28600 = NOVALUE;
    object _28598 = NOVALUE;
    object _28597 = NOVALUE;
    object _28596 = NOVALUE;
    object _28595 = NOVALUE;
    object _28594 = NOVALUE;
    object _28593 = NOVALUE;
    object _28590 = NOVALUE;
    object _28589 = NOVALUE;
    object _28588 = NOVALUE;
    object _28586 = NOVALUE;
    object _28585 = NOVALUE;
    object _28583 = NOVALUE;
    object _28579 = NOVALUE;
    object _28578 = NOVALUE;
    object _28576 = NOVALUE;
    object _28575 = NOVALUE;
    object _28573 = NOVALUE;
    object _28572 = NOVALUE;
    object _28571 = NOVALUE;
    object _28570 = NOVALUE;
    object _28569 = NOVALUE;
    object _28567 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_subsym_56620)) {
        _1 = (object)(DBL_PTR(_subsym_56620)->dbl);
        DeRefDS(_subsym_56620);
        _subsym_56620 = _1;
    }

    /** parser.e:875		object var_code*/

    /** parser.e:876		sequence name*/

    /** parser.e:878		n = SymTab[subsym][S_NUM_ARGS]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _28567 = (object)*(((s1_ptr)_2)->base + _subsym_56620);
    _2 = (object)SEQ_PTR(_28567);
    if (!IS_ATOM_INT(_36S_NUM_ARGS_21455)){
        _n_56621 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21455)->dbl));
    }
    else{
        _n_56621 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21455);
    }
    if (!IS_ATOM_INT(_n_56621)){
        _n_56621 = (object)DBL_PTR(_n_56621)->dbl;
    }
    _28567 = NOVALUE;

    /** parser.e:879		if sequence(SymTab[subsym][S_DEF_ARGS]) then*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _28569 = (object)*(((s1_ptr)_2)->base + _subsym_56620);
    _2 = (object)SEQ_PTR(_28569);
    _28570 = (object)*(((s1_ptr)_2)->base + 28);
    _28569 = NOVALUE;
    _28571 = IS_SEQUENCE(_28570);
    _28570 = NOVALUE;
    if (_28571 == 0)
    {
        _28571 = NOVALUE;
        goto L1; // [40] 86
    }
    else{
        _28571 = NOVALUE;
    }

    /** parser.e:880			fda = SymTab[subsym][S_DEF_ARGS][1]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _28572 = (object)*(((s1_ptr)_2)->base + _subsym_56620);
    _2 = (object)SEQ_PTR(_28572);
    _28573 = (object)*(((s1_ptr)_2)->base + 28);
    _28572 = NOVALUE;
    _2 = (object)SEQ_PTR(_28573);
    _fda_56622 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_fda_56622)){
        _fda_56622 = (object)DBL_PTR(_fda_56622)->dbl;
    }
    _28573 = NOVALUE;

    /** parser.e:881			lnda = SymTab[subsym][S_DEF_ARGS][2]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _28575 = (object)*(((s1_ptr)_2)->base + _subsym_56620);
    _2 = (object)SEQ_PTR(_28575);
    _28576 = (object)*(((s1_ptr)_2)->base + 28);
    _28575 = NOVALUE;
    _2 = (object)SEQ_PTR(_28576);
    _lnda_56623 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_lnda_56623)){
        _lnda_56623 = (object)DBL_PTR(_lnda_56623)->dbl;
    }
    _28576 = NOVALUE;
    goto L2; // [83] 97
L1: 

    /** parser.e:883			fda = 0*/
    _fda_56622 = 0;

    /** parser.e:884			lnda = 0*/
    _lnda_56623 = 0;
L2: 

    /** parser.e:886		s = subsym*/
    _s_56627 = _subsym_56620;

    /** parser.e:888		parseargs_states = append(parseargs_states,*/
    if (IS_SEQUENCE(_45private_list_56100)){
            _28578 = SEQ_PTR(_45private_list_56100)->length;
    }
    else {
        _28578 = 1;
    }
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _28578;
    ((intptr_t*)_2)[2] = _45lock_scanner_56101;
    ((intptr_t*)_2)[3] = _36use_private_list_21884;
    ((intptr_t*)_2)[4] = _45on_arg_56102;
    _28579 = MAKE_SEQ(_1);
    _28578 = NOVALUE;
    RefDS(_28579);
    Append(&_45parseargs_states_56095, _45parseargs_states_56095, _28579);
    DeRefDS(_28579);
    _28579 = NOVALUE;

    /** parser.e:890		nested_calls &= subsym*/
    Append(&_45nested_calls_56103, _45nested_calls_56103, _subsym_56620);

    /** parser.e:891		lock_scanner = 0*/
    _45lock_scanner_56101 = 0;

    /** parser.e:892		on_arg = 0*/
    _45on_arg_56102 = 0;

    /** parser.e:894		short_circuit -= 1*/
    _45short_circuit_55356 = _45short_circuit_55356 - 1;

    /** parser.e:895		for i = 1 to n do*/
    _28583 = _n_56621;
    {
        object _i_56658;
        _i_56658 = 1;
L3: 
        if (_i_56658 > _28583){
            goto L4; // [161] 1050
        }

        /** parser.e:897		  	tok = next_token()*/
        _0 = _tok_56625;
        _tok_56625 = _45next_token();
        DeRef(_0);

        /** parser.e:899			if tok[T_ID] = QUESTION_MARK or tok[T_ID] = COMMA then*/
        _2 = (object)SEQ_PTR(_tok_56625);
        _28585 = (object)*(((s1_ptr)_2)->base + 1);
        if (IS_ATOM_INT(_28585)) {
            _28586 = (_28585 == -31);
        }
        else {
            _28586 = binary_op(EQUALS, _28585, -31);
        }
        _28585 = NOVALUE;
        if (IS_ATOM_INT(_28586)) {
            if (_28586 != 0) {
                goto L5; // [187] 208
            }
        }
        else {
            if (DBL_PTR(_28586)->dbl != 0.0) {
                goto L5; // [187] 208
            }
        }
        _2 = (object)SEQ_PTR(_tok_56625);
        _28588 = (object)*(((s1_ptr)_2)->base + 1);
        if (IS_ATOM_INT(_28588)) {
            _28589 = (_28588 == -30);
        }
        else {
            _28589 = binary_op(EQUALS, _28588, -30);
        }
        _28588 = NOVALUE;
        if (_28589 == 0) {
            DeRef(_28589);
            _28589 = NOVALUE;
            goto L6; // [204] 505
        }
        else {
            if (!IS_ATOM_INT(_28589) && DBL_PTR(_28589)->dbl == 0.0){
                DeRef(_28589);
                _28589 = NOVALUE;
                goto L6; // [204] 505
            }
            DeRef(_28589);
            _28589 = NOVALUE;
        }
        DeRef(_28589);
        _28589 = NOVALUE;
L5: 

        /** parser.e:902				if tok[T_ID] = QUESTION_MARK then*/
        _2 = (object)SEQ_PTR(_tok_56625);
        _28590 = (object)*(((s1_ptr)_2)->base + 1);
        if (binary_op_a(NOTEQ, _28590, -31)){
            _28590 = NOVALUE;
            goto L7; // [218] 297
        }
        _28590 = NOVALUE;

        /** parser.e:903					tok = next_token()*/
        _0 = _tok_56625;
        _tok_56625 = _45next_token();
        DeRef(_0);

        /** parser.e:904					if tok[T_ID] != RIGHT_ROUND and tok[T_ID] != COMMA then*/
        _2 = (object)SEQ_PTR(_tok_56625);
        _28593 = (object)*(((s1_ptr)_2)->base + 1);
        if (IS_ATOM_INT(_28593)) {
            _28594 = (_28593 != -27);
        }
        else {
            _28594 = binary_op(NOTEQ, _28593, -27);
        }
        _28593 = NOVALUE;
        if (IS_ATOM_INT(_28594)) {
            if (_28594 == 0) {
                goto L8; // [241] 273
            }
        }
        else {
            if (DBL_PTR(_28594)->dbl == 0.0) {
                goto L8; // [241] 273
            }
        }
        _2 = (object)SEQ_PTR(_tok_56625);
        _28596 = (object)*(((s1_ptr)_2)->base + 1);
        if (IS_ATOM_INT(_28596)) {
            _28597 = (_28596 != -30);
        }
        else {
            _28597 = binary_op(NOTEQ, _28596, -30);
        }
        _28596 = NOVALUE;
        if (_28597 == 0) {
            DeRef(_28597);
            _28597 = NOVALUE;
            goto L8; // [258] 273
        }
        else {
            if (!IS_ATOM_INT(_28597) && DBL_PTR(_28597)->dbl == 0.0){
                DeRef(_28597);
                _28597 = NOVALUE;
                goto L8; // [258] 273
            }
            DeRef(_28597);
            _28597 = NOVALUE;
        }
        DeRef(_28597);
        _28597 = NOVALUE;

        /** parser.e:905						CompileErr( BADLYFORMED_LIST_OF_PARAMETERS__EXPECTED__OR)*/
        RefDS(_22190);
        _50CompileErr(41, _22190, 0);
        goto L9; // [270] 298
L8: 

        /** parser.e:906					elsif tok[T_ID] = RIGHT_ROUND then*/
        _2 = (object)SEQ_PTR(_tok_56625);
        _28598 = (object)*(((s1_ptr)_2)->base + 1);
        if (binary_op_a(NOTEQ, _28598, -27)){
            _28598 = NOVALUE;
            goto L9; // [283] 298
        }
        _28598 = NOVALUE;

        /** parser.e:907						putback( tok )*/
        Ref(_tok_56625);
        _45putback(_tok_56625);
        goto L9; // [294] 298
L7: 
L9: 

        /** parser.e:912				if SymTab[subsym][S_OPCODE] then*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _28600 = (object)*(((s1_ptr)_2)->base + _subsym_56620);
        _2 = (object)SEQ_PTR(_28600);
        _28601 = (object)*(((s1_ptr)_2)->base + 21);
        _28600 = NOVALUE;
        if (_28601 == 0) {
            _28601 = NOVALUE;
            goto LA; // [312] 372
        }
        else {
            if (!IS_ATOM_INT(_28601) && DBL_PTR(_28601)->dbl == 0.0){
                _28601 = NOVALUE;
                goto LA; // [312] 372
            }
            _28601 = NOVALUE;
        }
        _28601 = NOVALUE;

        /** parser.e:913					if atom(SymTab[subsym][S_CODE]) then*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _28602 = (object)*(((s1_ptr)_2)->base + _subsym_56620);
        _2 = (object)SEQ_PTR(_28602);
        if (!IS_ATOM_INT(_36S_CODE_21416)){
            _28603 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21416)->dbl));
        }
        else{
            _28603 = (object)*(((s1_ptr)_2)->base + _36S_CODE_21416);
        }
        _28602 = NOVALUE;
        _28604 = IS_ATOM(_28603);
        _28603 = NOVALUE;
        if (_28604 == 0)
        {
            _28604 = NOVALUE;
            goto LB; // [332] 343
        }
        else{
            _28604 = NOVALUE;
        }

        /** parser.e:914						var_code = 0*/
        DeRef(_var_code_56628);
        _var_code_56628 = 0;
        goto LC; // [340] 362
LB: 

        /** parser.e:916						var_code = SymTab[subsym][S_CODE][i]*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _28605 = (object)*(((s1_ptr)_2)->base + _subsym_56620);
        _2 = (object)SEQ_PTR(_28605);
        if (!IS_ATOM_INT(_36S_CODE_21416)){
            _28606 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21416)->dbl));
        }
        else{
            _28606 = (object)*(((s1_ptr)_2)->base + _36S_CODE_21416);
        }
        _28605 = NOVALUE;
        DeRef(_var_code_56628);
        _2 = (object)SEQ_PTR(_28606);
        _var_code_56628 = (object)*(((s1_ptr)_2)->base + _i_56658);
        Ref(_var_code_56628);
        _28606 = NOVALUE;
LC: 

        /** parser.e:918					name = ""*/
        RefDS(_22190);
        DeRef(_name_56629);
        _name_56629 = _22190;
        goto LD; // [369] 419
LA: 

        /** parser.e:920					s = SymTab[s][S_NEXT]*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _28608 = (object)*(((s1_ptr)_2)->base + _s_56627);
        _2 = (object)SEQ_PTR(_28608);
        _s_56627 = (object)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_s_56627)){
            _s_56627 = (object)DBL_PTR(_s_56627)->dbl;
        }
        _28608 = NOVALUE;

        /** parser.e:921					var_code = SymTab[s][S_CODE]*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _28610 = (object)*(((s1_ptr)_2)->base + _s_56627);
        DeRef(_var_code_56628);
        _2 = (object)SEQ_PTR(_28610);
        if (!IS_ATOM_INT(_36S_CODE_21416)){
            _var_code_56628 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21416)->dbl));
        }
        else{
            _var_code_56628 = (object)*(((s1_ptr)_2)->base + _36S_CODE_21416);
        }
        Ref(_var_code_56628);
        _28610 = NOVALUE;

        /** parser.e:922					name = SymTab[s][S_NAME]*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _28612 = (object)*(((s1_ptr)_2)->base + _s_56627);
        DeRef(_name_56629);
        _2 = (object)SEQ_PTR(_28612);
        if (!IS_ATOM_INT(_36S_NAME_21404)){
            _name_56629 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21404)->dbl));
        }
        else{
            _name_56629 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21404);
        }
        Ref(_name_56629);
        _28612 = NOVALUE;
LD: 

        /** parser.e:925				if atom(var_code) then  -- but no default set*/
        _28614 = IS_ATOM(_var_code_56628);
        if (_28614 == 0)
        {
            _28614 = NOVALUE;
            goto LE; // [426] 439
        }
        else{
            _28614 = NOVALUE;
        }

        /** parser.e:926					CompileErr(ARGUMENT_1_WAS_OMITTED_BUT_THERE_IS_NO_DEFAULT_VALUE_DEFINED,i)*/
        _50CompileErr(29, _i_56658, 0);
LE: 

        /** parser.e:929				use_private_list = 1*/
        _36use_private_list_21884 = 1;

        /** parser.e:930				start_playback(var_code)*/
        Ref(_var_code_56628);
        _45start_playback(_var_code_56628);

        /** parser.e:931				lock_scanner=1*/
        _45lock_scanner_56101 = 1;

        /** parser.e:934				Expr()*/
        _45Expr();

        /** parser.e:935				lock_scanner=0*/
        _45lock_scanner_56101 = 0;

        /** parser.e:936				on_arg += 1*/
        _45on_arg_56102 = _45on_arg_56102 + 1;

        /** parser.e:937				private_list = append(private_list,name)*/
        RefDS(_name_56629);
        Append(&_45private_list_56100, _45private_list_56100, _name_56629);

        /** parser.e:938				private_sym &= Top()*/
        _28617 = _47Top();
        if (IS_SEQUENCE(_36private_sym_21883) && IS_ATOM(_28617)) {
            Ref(_28617);
            Append(&_36private_sym_21883, _36private_sym_21883, _28617);
        }
        else if (IS_ATOM(_36private_sym_21883) && IS_SEQUENCE(_28617)) {
        }
        else {
            Concat((object_ptr)&_36private_sym_21883, _36private_sym_21883, _28617);
        }
        DeRef(_28617);
        _28617 = NOVALUE;

        /** parser.e:939				backed_up_tok = {tok} -- ????*/
        _0 = _45backed_up_tok_55363;
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        Ref(_tok_56625);
        ((intptr_t*)_2)[1] = _tok_56625;
        _45backed_up_tok_55363 = MAKE_SEQ(_1);
        DeRef(_0);
        goto LF; // [502] 633
L6: 

        /** parser.e:942			elsif tok[T_ID] != RIGHT_ROUND then*/
        _2 = (object)SEQ_PTR(_tok_56625);
        _28620 = (object)*(((s1_ptr)_2)->base + 1);
        if (binary_op_a(EQUALS, _28620, -27)){
            _28620 = NOVALUE;
            goto L10; // [515] 632
        }
        _28620 = NOVALUE;

        /** parser.e:944				if SymTab[subsym][S_OPCODE] then*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _28622 = (object)*(((s1_ptr)_2)->base + _subsym_56620);
        _2 = (object)SEQ_PTR(_28622);
        _28623 = (object)*(((s1_ptr)_2)->base + 21);
        _28622 = NOVALUE;
        if (_28623 == 0) {
            _28623 = NOVALUE;
            goto L11; // [533] 546
        }
        else {
            if (!IS_ATOM_INT(_28623) && DBL_PTR(_28623)->dbl == 0.0){
                _28623 = NOVALUE;
                goto L11; // [533] 546
            }
            _28623 = NOVALUE;
        }
        _28623 = NOVALUE;

        /** parser.e:945					name = ""*/
        RefDS(_22190);
        DeRef(_name_56629);
        _name_56629 = _22190;
        goto L12; // [543] 579
L11: 

        /** parser.e:947					s = SymTab[s][S_NEXT]*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _28624 = (object)*(((s1_ptr)_2)->base + _s_56627);
        _2 = (object)SEQ_PTR(_28624);
        _s_56627 = (object)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_s_56627)){
            _s_56627 = (object)DBL_PTR(_s_56627)->dbl;
        }
        _28624 = NOVALUE;

        /** parser.e:948					name = SymTab[s][S_NAME]*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _28626 = (object)*(((s1_ptr)_2)->base + _s_56627);
        DeRef(_name_56629);
        _2 = (object)SEQ_PTR(_28626);
        if (!IS_ATOM_INT(_36S_NAME_21404)){
            _name_56629 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21404)->dbl));
        }
        else{
            _name_56629 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21404);
        }
        Ref(_name_56629);
        _28626 = NOVALUE;
L12: 

        /** parser.e:951				use_private_list = Parser_mode != PAM_NORMAL*/
        _36use_private_list_21884 = (_36Parser_mode_21876 != 0);

        /** parser.e:952				putback(tok)*/
        Ref(_tok_56625);
        _45putback(_tok_56625);

        /** parser.e:953				Expr()*/
        _45Expr();

        /** parser.e:954				on_arg += 1*/
        _45on_arg_56102 = _45on_arg_56102 + 1;

        /** parser.e:955				private_list = append(private_list,name)*/
        RefDS(_name_56629);
        Append(&_45private_list_56100, _45private_list_56100, _name_56629);

        /** parser.e:956				private_sym &= Top()*/
        _28631 = _47Top();
        if (IS_SEQUENCE(_36private_sym_21883) && IS_ATOM(_28631)) {
            Ref(_28631);
            Append(&_36private_sym_21883, _36private_sym_21883, _28631);
        }
        else if (IS_ATOM(_36private_sym_21883) && IS_SEQUENCE(_28631)) {
        }
        else {
            Concat((object_ptr)&_36private_sym_21883, _36private_sym_21883, _28631);
        }
        DeRef(_28631);
        _28631 = NOVALUE;
L10: 
LF: 

        /** parser.e:959			if on_arg != n then*/
        if (_45on_arg_56102 == _n_56621)
        goto L13; // [637] 1043

        /** parser.e:960				if tok[T_ID] = RIGHT_ROUND then*/
        _2 = (object)SEQ_PTR(_tok_56625);
        _28634 = (object)*(((s1_ptr)_2)->base + 1);
        if (binary_op_a(NOTEQ, _28634, -27)){
            _28634 = NOVALUE;
            goto L14; // [651] 661
        }
        _28634 = NOVALUE;

        /** parser.e:961					putback( tok )*/
        Ref(_tok_56625);
        _45putback(_tok_56625);
L14: 

        /** parser.e:963				tok = next_token()*/
        _0 = _tok_56625;
        _tok_56625 = _45next_token();
        DeRef(_0);

        /** parser.e:964				if tok[T_ID] != COMMA and tok[T_ID] != QUESTION_MARK then*/
        _2 = (object)SEQ_PTR(_tok_56625);
        _28637 = (object)*(((s1_ptr)_2)->base + 1);
        if (IS_ATOM_INT(_28637)) {
            _28638 = (_28637 != -30);
        }
        else {
            _28638 = binary_op(NOTEQ, _28637, -30);
        }
        _28637 = NOVALUE;
        if (IS_ATOM_INT(_28638)) {
            if (_28638 == 0) {
                goto L15; // [680] 1042
            }
        }
        else {
            if (DBL_PTR(_28638)->dbl == 0.0) {
                goto L15; // [680] 1042
            }
        }
        _2 = (object)SEQ_PTR(_tok_56625);
        _28640 = (object)*(((s1_ptr)_2)->base + 1);
        if (IS_ATOM_INT(_28640)) {
            _28641 = (_28640 != -31);
        }
        else {
            _28641 = binary_op(NOTEQ, _28640, -31);
        }
        _28640 = NOVALUE;
        if (_28641 == 0) {
            DeRef(_28641);
            _28641 = NOVALUE;
            goto L15; // [697] 1042
        }
        else {
            if (!IS_ATOM_INT(_28641) && DBL_PTR(_28641)->dbl == 0.0){
                DeRef(_28641);
                _28641 = NOVALUE;
                goto L15; // [697] 1042
            }
            DeRef(_28641);
            _28641 = NOVALUE;
        }
        DeRef(_28641);
        _28641 = NOVALUE;

        /** parser.e:966			  		if tok[T_ID] = RIGHT_ROUND then*/
        _2 = (object)SEQ_PTR(_tok_56625);
        _28642 = (object)*(((s1_ptr)_2)->base + 1);
        if (binary_op_a(NOTEQ, _28642, -27)){
            _28642 = NOVALUE;
            goto L16; // [710] 1027
        }
        _28642 = NOVALUE;

        /** parser.e:968						if fda=0 then*/
        if (_fda_56622 != 0)
        goto L17; // [718] 731

        /** parser.e:969							WrongNumberArgs(subsym, "")*/
        RefDS(_22190);
        _45WrongNumberArgs(_subsym_56620, _22190);
        goto L18; // [728] 746
L17: 

        /** parser.e:970						elsif i<lnda then*/
        if (_i_56658 >= _lnda_56623)
        goto L19; // [735] 745

        /** parser.e:971							MissingArgs(subsym)*/
        _45MissingArgs(_subsym_56620);
L19: 
L18: 

        /** parser.e:973						lock_scanner = 1*/
        _45lock_scanner_56101 = 1;

        /** parser.e:974						use_private_list = 1*/
        _36use_private_list_21884 = 1;

        /** parser.e:977						while on_arg < n do*/
L1A: 
        if (_45on_arg_56102 >= _n_56621)
        goto L1B; // [765] 976

        /** parser.e:978							on_arg += 1*/
        _45on_arg_56102 = _45on_arg_56102 + 1;

        /** parser.e:979							if SymTab[subsym][S_OPCODE] then*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _28648 = (object)*(((s1_ptr)_2)->base + _subsym_56620);
        _2 = (object)SEQ_PTR(_28648);
        _28649 = (object)*(((s1_ptr)_2)->base + 21);
        _28648 = NOVALUE;
        if (_28649 == 0) {
            _28649 = NOVALUE;
            goto L1C; // [791] 853
        }
        else {
            if (!IS_ATOM_INT(_28649) && DBL_PTR(_28649)->dbl == 0.0){
                _28649 = NOVALUE;
                goto L1C; // [791] 853
            }
            _28649 = NOVALUE;
        }
        _28649 = NOVALUE;

        /** parser.e:980								if atom(SymTab[subsym][S_CODE]) then*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _28650 = (object)*(((s1_ptr)_2)->base + _subsym_56620);
        _2 = (object)SEQ_PTR(_28650);
        if (!IS_ATOM_INT(_36S_CODE_21416)){
            _28651 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21416)->dbl));
        }
        else{
            _28651 = (object)*(((s1_ptr)_2)->base + _36S_CODE_21416);
        }
        _28650 = NOVALUE;
        _28652 = IS_ATOM(_28651);
        _28651 = NOVALUE;
        if (_28652 == 0)
        {
            _28652 = NOVALUE;
            goto L1D; // [811] 822
        }
        else{
            _28652 = NOVALUE;
        }

        /** parser.e:981									var_code = 0*/
        DeRef(_var_code_56628);
        _var_code_56628 = 0;
        goto L1E; // [819] 843
L1D: 

        /** parser.e:983									var_code = SymTab[subsym][S_CODE][on_arg]*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _28653 = (object)*(((s1_ptr)_2)->base + _subsym_56620);
        _2 = (object)SEQ_PTR(_28653);
        if (!IS_ATOM_INT(_36S_CODE_21416)){
            _28654 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21416)->dbl));
        }
        else{
            _28654 = (object)*(((s1_ptr)_2)->base + _36S_CODE_21416);
        }
        _28653 = NOVALUE;
        DeRef(_var_code_56628);
        _2 = (object)SEQ_PTR(_28654);
        _var_code_56628 = (object)*(((s1_ptr)_2)->base + _45on_arg_56102);
        Ref(_var_code_56628);
        _28654 = NOVALUE;
L1E: 

        /** parser.e:986								name = ""*/
        RefDS(_22190);
        DeRef(_name_56629);
        _name_56629 = _22190;
        goto L1F; // [850] 900
L1C: 

        /** parser.e:989								s = SymTab[s][S_NEXT]*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _28656 = (object)*(((s1_ptr)_2)->base + _s_56627);
        _2 = (object)SEQ_PTR(_28656);
        _s_56627 = (object)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_s_56627)){
            _s_56627 = (object)DBL_PTR(_s_56627)->dbl;
        }
        _28656 = NOVALUE;

        /** parser.e:990								var_code = SymTab[s][S_CODE]*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _28658 = (object)*(((s1_ptr)_2)->base + _s_56627);
        DeRef(_var_code_56628);
        _2 = (object)SEQ_PTR(_28658);
        if (!IS_ATOM_INT(_36S_CODE_21416)){
            _var_code_56628 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21416)->dbl));
        }
        else{
            _var_code_56628 = (object)*(((s1_ptr)_2)->base + _36S_CODE_21416);
        }
        Ref(_var_code_56628);
        _28658 = NOVALUE;

        /** parser.e:991								name = SymTab[s][S_NAME]*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _28660 = (object)*(((s1_ptr)_2)->base + _s_56627);
        DeRef(_name_56629);
        _2 = (object)SEQ_PTR(_28660);
        if (!IS_ATOM_INT(_36S_NAME_21404)){
            _name_56629 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21404)->dbl));
        }
        else{
            _name_56629 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21404);
        }
        Ref(_name_56629);
        _28660 = NOVALUE;
L1F: 

        /** parser.e:993							if sequence(var_code) then*/
        _28662 = IS_SEQUENCE(_var_code_56628);
        if (_28662 == 0)
        {
            _28662 = NOVALUE;
            goto L20; // [907] 959
        }
        else{
            _28662 = NOVALUE;
        }

        /** parser.e:995								putback( tok )*/
        Ref(_tok_56625);
        _45putback(_tok_56625);

        /** parser.e:996								start_playback(var_code)*/
        Ref(_var_code_56628);
        _45start_playback(_var_code_56628);

        /** parser.e:999								Expr()*/
        _45Expr();

        /** parser.e:1000								if on_arg < n then*/
        if (_45on_arg_56102 >= _n_56621)
        goto L1A; // [928] 763

        /** parser.e:1001									private_list = append(private_list,name)*/
        RefDS(_name_56629);
        Append(&_45private_list_56100, _45private_list_56100, _name_56629);

        /** parser.e:1002									private_sym &= Top()*/
        _28665 = _47Top();
        if (IS_SEQUENCE(_36private_sym_21883) && IS_ATOM(_28665)) {
            Ref(_28665);
            Append(&_36private_sym_21883, _36private_sym_21883, _28665);
        }
        else if (IS_ATOM(_36private_sym_21883) && IS_SEQUENCE(_28665)) {
        }
        else {
            Concat((object_ptr)&_36private_sym_21883, _36private_sym_21883, _28665);
        }
        DeRef(_28665);
        _28665 = NOVALUE;
        goto L1A; // [956] 763
L20: 

        /** parser.e:1005								CompileErr(ARGUMENT_1_WAS_OMITTED_BUT_THERE_IS_NO_DEFAULT_VALUE_DEFINED, on_arg)*/
        _50CompileErr(29, _45on_arg_56102, 0);

        /** parser.e:1007			  		    end while*/
        goto L1A; // [973] 763
L1B: 

        /** parser.e:1009						short_circuit += 1*/
        _45short_circuit_55356 = _45short_circuit_55356 + 1;

        /** parser.e:1010						if backed_up_tok[$][T_ID] = PLAYBACK_ENDS then*/
        if (IS_SEQUENCE(_45backed_up_tok_55363)){
                _28668 = SEQ_PTR(_45backed_up_tok_55363)->length;
        }
        else {
            _28668 = 1;
        }
        _2 = (object)SEQ_PTR(_45backed_up_tok_55363);
        _28669 = (object)*(((s1_ptr)_2)->base + _28668);
        _2 = (object)SEQ_PTR(_28669);
        _28670 = (object)*(((s1_ptr)_2)->base + 1);
        _28669 = NOVALUE;
        if (binary_op_a(NOTEQ, _28670, 505)){
            _28670 = NOVALUE;
            goto L21; // [1003] 1015
        }
        _28670 = NOVALUE;

        /** parser.e:1011							backed_up_tok = {}*/
        RefDS(_22190);
        DeRefDS(_45backed_up_tok_55363);
        _45backed_up_tok_55363 = _22190;
L21: 

        /** parser.e:1014						restore_parseargs_states()*/
        _45restore_parseargs_states();

        /** parser.e:1016						return*/
        DeRef(_tok_56625);
        DeRef(_var_code_56628);
        DeRef(_name_56629);
        DeRef(_28586);
        _28586 = NOVALUE;
        DeRef(_28638);
        _28638 = NOVALUE;
        DeRef(_28594);
        _28594 = NOVALUE;
        return;
        goto L22; // [1024] 1041
L16: 

        /** parser.e:1018						putback(tok)*/
        Ref(_tok_56625);
        _45putback(_tok_56625);

        /** parser.e:1019						tok_match(COMMA)*/
        _45tok_match(-30, 0);
L22: 
L15: 
L13: 

        /** parser.e:1024		end for*/
        _i_56658 = _i_56658 + 1;
        goto L3; // [1045] 168
L4: 
        ;
    }

    /** parser.e:1025		tok = next_token()*/
    _0 = _tok_56625;
    _tok_56625 = _45next_token();
    DeRef(_0);

    /** parser.e:1026		short_circuit += 1*/
    _45short_circuit_55356 = _45short_circuit_55356 + 1;

    /** parser.e:1027		if tok[T_ID] != RIGHT_ROUND then*/
    _2 = (object)SEQ_PTR(_tok_56625);
    _28674 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _28674, -27)){
        _28674 = NOVALUE;
        goto L23; // [1073] 1115
    }
    _28674 = NOVALUE;

    /** parser.e:1028			if tok[T_ID] = COMMA then*/
    _2 = (object)SEQ_PTR(_tok_56625);
    _28676 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28676, -30)){
        _28676 = NOVALUE;
        goto L24; // [1087] 1100
    }
    _28676 = NOVALUE;

    /** parser.e:1029				WrongNumberArgs(subsym, "only ")*/
    RefDS(_28678);
    _45WrongNumberArgs(_subsym_56620, _28678);
    goto L25; // [1097] 1114
L24: 

    /** parser.e:1031				putback(tok)*/
    Ref(_tok_56625);
    _45putback(_tok_56625);

    /** parser.e:1032				tok_match(RIGHT_ROUND)*/
    _45tok_match(-27, 0);
L25: 
L23: 

    /** parser.e:1036		restore_parseargs_states()*/
    _45restore_parseargs_states();

    /** parser.e:1037	end procedure*/
    DeRef(_tok_56625);
    DeRef(_var_code_56628);
    DeRef(_name_56629);
    DeRef(_28586);
    _28586 = NOVALUE;
    DeRef(_28638);
    _28638 = NOVALUE;
    DeRef(_28594);
    _28594 = NOVALUE;
    return;
    ;
}


void _45Forward_var(object _tok_56870, object _init_check_56871, object _op_56872)
{
    object _ref_56876 = NOVALUE;
    object _28682 = NOVALUE;
    object _28680 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_op_56872)) {
        _1 = (object)(DBL_PTR(_op_56872)->dbl);
        DeRefDS(_op_56872);
        _op_56872 = _1;
    }

    /** parser.e:1041		ref = new_forward_reference( VARIABLE, tok[T_SYM], op )*/
    _2 = (object)SEQ_PTR(_tok_56870);
    _28680 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_28680);
    _ref_56876 = _44new_forward_reference(-100, _28680, _op_56872);
    _28680 = NOVALUE;
    if (!IS_ATOM_INT(_ref_56876)) {
        _1 = (object)(DBL_PTR(_ref_56876)->dbl);
        DeRefDS(_ref_56876);
        _ref_56876 = _1;
    }

    /** parser.e:1042		emit_opnd( - ref )*/
    if ((uintptr_t)_ref_56876 == (uintptr_t)HIGH_BITS){
        _28682 = (object)NewDouble((eudouble) -HIGH_BITS);
    }
    else{
        _28682 = - _ref_56876;
    }
    _47emit_opnd(_28682);
    _28682 = NOVALUE;

    /** parser.e:1043		if init_check != -1 then*/
    if (_init_check_56871 == -1)
    goto L1; // [33] 44

    /** parser.e:1044			Forward_InitCheck( tok, init_check )*/
    Ref(_tok_56870);
    _45Forward_InitCheck(_tok_56870, _init_check_56871);
L1: 

    /** parser.e:1047	end procedure*/
    DeRef(_tok_56870);
    return;
    ;
}


void _45Forward_call(object _tok_56889, object _opcode_56890)
{
    object _args_56893 = NOVALUE;
    object _proc_56895 = NOVALUE;
    object _tok_id_56898 = NOVALUE;
    object _id_56905 = NOVALUE;
    object _fc_pc_56929 = NOVALUE;
    object _28701 = NOVALUE;
    object _28700 = NOVALUE;
    object _28697 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:1050		integer args = 0*/
    _args_56893 = 0;

    /** parser.e:1051		symtab_index proc = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_56889);
    _proc_56895 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_proc_56895)){
        _proc_56895 = (object)DBL_PTR(_proc_56895)->dbl;
    }

    /** parser.e:1052		integer tok_id = tok[T_ID]*/
    _2 = (object)SEQ_PTR(_tok_56889);
    _tok_id_56898 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_tok_id_56898)){
        _tok_id_56898 = (object)DBL_PTR(_tok_id_56898)->dbl;
    }

    /** parser.e:1053		remove_symbol( proc )*/
    _54remove_symbol(_proc_56895);

    /** parser.e:1054		short_circuit -= 1*/
    _45short_circuit_55356 = _45short_circuit_55356 - 1;

    /** parser.e:1055		while 1 do*/
L1: 

    /** parser.e:1056			tok = next_token()*/
    _0 = _tok_56889;
    _tok_56889 = _45next_token();
    DeRef(_0);

    /** parser.e:1057			integer id = tok[T_ID]*/
    _2 = (object)SEQ_PTR(_tok_56889);
    _id_56905 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_id_56905)){
        _id_56905 = (object)DBL_PTR(_id_56905)->dbl;
    }

    /** parser.e:1059			switch id do*/
    _0 = _id_56905;
    switch ( _0 ){ 

        /** parser.e:1060				case COMMA then*/
        case -30:

        /** parser.e:1061					emit_opnd( 0 ) -- clean this up later*/
        _47emit_opnd(0);

        /** parser.e:1062					args += 1*/
        _args_56893 = _args_56893 + 1;
        goto L2; // [83] 168

        /** parser.e:1064				case RIGHT_ROUND then*/
        case -27:

        /** parser.e:1065					exit*/
        goto L3; // [93] 175
        goto L2; // [95] 168

        /** parser.e:1067				case else*/
        default:

        /** parser.e:1068					putback( tok )*/
        Ref(_tok_56889);
        _45putback(_tok_56889);

        /** parser.e:1069					call_proc( forward_expr, {} )*/
        _0 = (object)_00[_45forward_expr_56391].addr;
        (*(intptr_t (*)())_0)(
                             );

        /** parser.e:1070					args += 1*/
        _args_56893 = _args_56893 + 1;

        /** parser.e:1072					tok = next_token()*/
        _0 = _tok_56889;
        _tok_56889 = _45next_token();
        DeRef(_0);

        /** parser.e:1073					id = tok[T_ID]*/
        _2 = (object)SEQ_PTR(_tok_56889);
        _id_56905 = (object)*(((s1_ptr)_2)->base + 1);
        if (!IS_ATOM_INT(_id_56905)){
            _id_56905 = (object)DBL_PTR(_id_56905)->dbl;
        }

        /** parser.e:1074					if id = RIGHT_ROUND then*/
        if (_id_56905 != -27)
        goto L4; // [138] 149

        /** parser.e:1075						exit*/
        goto L3; // [146] 175
L4: 

        /** parser.e:1078					if id != COMMA then*/
        if (_id_56905 == -30)
        goto L5; // [153] 167

        /** parser.e:1079							CompileErr(EXPECTED__OR)*/
        RefDS(_22190);
        _50CompileErr(69, _22190, 0);
L5: 
    ;}L2: 

    /** parser.e:1082		end while*/
    goto L1; // [172] 46
L3: 

    /** parser.e:1084		integer fc_pc = length( Code ) + 1*/
    if (IS_SEQUENCE(_36Code_21859)){
            _28697 = SEQ_PTR(_36Code_21859)->length;
    }
    else {
        _28697 = 1;
    }
    _fc_pc_56929 = _28697 + 1;
    _28697 = NOVALUE;

    /** parser.e:1085		emit_opnd( args )*/
    _47emit_opnd(_args_56893);

    /** parser.e:1087		op_info1 = proc*/
    _47op_info1_51364 = _proc_56895;

    /** parser.e:1088		if tok_id = QUALIFIED_VARIABLE then*/
    if (_tok_id_56898 != 512)
    goto L6; // [202] 226

    /** parser.e:1089			set_qualified_fwd( SymTab[proc][S_FILE_NO] )*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _28700 = (object)*(((s1_ptr)_2)->base + _proc_56895);
    _2 = (object)SEQ_PTR(_28700);
    if (!IS_ATOM_INT(_36S_FILE_NO_21400)){
        _28701 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21400)->dbl));
    }
    else{
        _28701 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21400);
    }
    _28700 = NOVALUE;
    Ref(_28701);
    _62set_qualified_fwd(_28701);
    _28701 = NOVALUE;
    goto L7; // [223] 232
L6: 

    /** parser.e:1091			set_qualified_fwd( -1 )*/
    _62set_qualified_fwd(-1);
L7: 

    /** parser.e:1093		emit_op( opcode )*/
    _47emit_op(_opcode_56890);

    /** parser.e:1094		if not TRANSLATE then*/
    if (_36TRANSLATE_21369 != 0)
    goto L8; // [241] 260

    /** parser.e:1095			if OpTrace then*/
    if (_36OpTrace_21840 == 0)
    {
        goto L9; // [248] 259
    }
    else{
    }

    /** parser.e:1096				emit_op(UPDATE_GLOBALS)*/
    _47emit_op(89);
L9: 
L8: 

    /** parser.e:1099		short_circuit += 1*/
    _45short_circuit_55356 = _45short_circuit_55356 + 1;

    /** parser.e:1100	end procedure*/
    DeRef(_tok_56889);
    return;
    ;
}


void _45Object_call(object _tok_56957)
{
    object _tok2_56959 = NOVALUE;
    object _tok3_56960 = NOVALUE;
    object _save_factors_56961 = NOVALUE;
    object _save_lhs_subs_level_56962 = NOVALUE;
    object _sym_56964 = NOVALUE;
    object _28759 = NOVALUE;
    object _28757 = NOVALUE;
    object _28754 = NOVALUE;
    object _28750 = NOVALUE;
    object _28744 = NOVALUE;
    object _28741 = NOVALUE;
    object _28740 = NOVALUE;
    object _28739 = NOVALUE;
    object _28737 = NOVALUE;
    object _28736 = NOVALUE;
    object _28734 = NOVALUE;
    object _28733 = NOVALUE;
    object _28730 = NOVALUE;
    object _28729 = NOVALUE;
    object _28728 = NOVALUE;
    object _28726 = NOVALUE;
    object _28725 = NOVALUE;
    object _28723 = NOVALUE;
    object _28722 = NOVALUE;
    object _28721 = NOVALUE;
    object _28720 = NOVALUE;
    object _28718 = NOVALUE;
    object _28717 = NOVALUE;
    object _28715 = NOVALUE;
    object _28714 = NOVALUE;
    object _28711 = NOVALUE;
    object _28709 = NOVALUE;
    object _28708 = NOVALUE;
    object _28706 = NOVALUE;
    object _28705 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:1104		integer save_factors, save_lhs_subs_level*/

    /** parser.e:1107		tok2 = next_token()*/
    _0 = _tok2_56959;
    _tok2_56959 = _45next_token();
    DeRef(_0);

    /** parser.e:1108		if tok2[T_ID] = VARIABLE or tok2[T_ID] = QUALIFIED_VARIABLE then*/
    _2 = (object)SEQ_PTR(_tok2_56959);
    _28705 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_28705)) {
        _28706 = (_28705 == -100);
    }
    else {
        _28706 = binary_op(EQUALS, _28705, -100);
    }
    _28705 = NOVALUE;
    if (IS_ATOM_INT(_28706)) {
        if (_28706 != 0) {
            goto L1; // [22] 43
        }
    }
    else {
        if (DBL_PTR(_28706)->dbl != 0.0) {
            goto L1; // [22] 43
        }
    }
    _2 = (object)SEQ_PTR(_tok2_56959);
    _28708 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_28708)) {
        _28709 = (_28708 == 512);
    }
    else {
        _28709 = binary_op(EQUALS, _28708, 512);
    }
    _28708 = NOVALUE;
    if (_28709 == 0) {
        DeRef(_28709);
        _28709 = NOVALUE;
        goto L2; // [39] 582
    }
    else {
        if (!IS_ATOM_INT(_28709) && DBL_PTR(_28709)->dbl == 0.0){
            DeRef(_28709);
            _28709 = NOVALUE;
            goto L2; // [39] 582
        }
        DeRef(_28709);
        _28709 = NOVALUE;
    }
    DeRef(_28709);
    _28709 = NOVALUE;
L1: 

    /** parser.e:1109			tok3 = next_token()*/
    _0 = _tok3_56960;
    _tok3_56960 = _45next_token();
    DeRef(_0);

    /** parser.e:1110			if tok3[T_ID] = RIGHT_ROUND then*/
    _2 = (object)SEQ_PTR(_tok3_56960);
    _28711 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28711, -27)){
        _28711 = NOVALUE;
        goto L3; // [58] 155
    }
    _28711 = NOVALUE;

    /** parser.e:1112				sym = tok2[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok2_56959);
    _sym_56964 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_sym_56964)){
        _sym_56964 = (object)DBL_PTR(_sym_56964)->dbl;
    }

    /** parser.e:1113				if SymTab[sym][S_SCOPE] = SC_UNDEFINED then*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _28714 = (object)*(((s1_ptr)_2)->base + _sym_56964);
    _2 = (object)SEQ_PTR(_28714);
    _28715 = (object)*(((s1_ptr)_2)->base + 4);
    _28714 = NOVALUE;
    if (binary_op_a(NOTEQ, _28715, 9)){
        _28715 = NOVALUE;
        goto L4; // [88] 108
    }
    _28715 = NOVALUE;

    /** parser.e:1114					Forward_var( tok2 )*/
    _2 = (object)SEQ_PTR(_tok2_56959);
    _28717 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_tok2_56959);
    Ref(_28717);
    _45Forward_var(_tok2_56959, -1, _28717);
    _28717 = NOVALUE;
    goto L5; // [105] 147
L4: 

    /** parser.e:1116					SymTab[sym][S_USAGE] = or_bits(SymTab[sym][S_USAGE], U_READ)*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_56964 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _28720 = (object)*(((s1_ptr)_2)->base + _sym_56964);
    _2 = (object)SEQ_PTR(_28720);
    _28721 = (object)*(((s1_ptr)_2)->base + 5);
    _28720 = NOVALUE;
    if (IS_ATOM_INT(_28721)) {
        {uintptr_t tu;
             tu = (uintptr_t)_28721 | (uintptr_t)1;
             _28722 = MAKE_UINT(tu);
        }
    }
    else {
        _28722 = binary_op(OR_BITS, _28721, 1);
    }
    _28721 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _28722;
    if( _1 != _28722 ){
        DeRef(_1);
    }
    _28722 = NOVALUE;
    _28718 = NOVALUE;

    /** parser.e:1118					emit_opnd(sym)*/
    _47emit_opnd(_sym_56964);
L5: 

    /** parser.e:1120				putback( tok3 )*/
    Ref(_tok3_56960);
    _45putback(_tok3_56960);
    goto L6; // [152] 571
L3: 

    /** parser.e:1122			elsif tok3[T_ID] = COMMA then*/
    _2 = (object)SEQ_PTR(_tok3_56960);
    _28723 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28723, -30)){
        _28723 = NOVALUE;
        goto L7; // [165] 184
    }
    _28723 = NOVALUE;

    /** parser.e:1124				WrongNumberArgs(tok[T_SYM], "")*/
    _2 = (object)SEQ_PTR(_tok_56957);
    _28725 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_28725);
    RefDS(_22190);
    _45WrongNumberArgs(_28725, _22190);
    _28725 = NOVALUE;
    goto L6; // [181] 571
L7: 

    /** parser.e:1126			elsif tok3[T_ID] = LEFT_ROUND then*/
    _2 = (object)SEQ_PTR(_tok3_56960);
    _28726 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28726, -26)){
        _28726 = NOVALUE;
        goto L8; // [194] 244
    }
    _28726 = NOVALUE;

    /** parser.e:1127				if SymTab[tok2[T_SYM]][S_SCOPE] = SC_UNDEFINED then*/
    _2 = (object)SEQ_PTR(_tok2_56959);
    _28728 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!IS_ATOM_INT(_28728)){
        _28729 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_28728)->dbl));
    }
    else{
        _28729 = (object)*(((s1_ptr)_2)->base + _28728);
    }
    _2 = (object)SEQ_PTR(_28729);
    _28730 = (object)*(((s1_ptr)_2)->base + 4);
    _28729 = NOVALUE;
    if (binary_op_a(NOTEQ, _28730, 9)){
        _28730 = NOVALUE;
        goto L9; // [220] 235
    }
    _28730 = NOVALUE;

    /** parser.e:1128					Forward_call( tok2, FUNC_FORWARD )*/
    Ref(_tok2_56959);
    _45Forward_call(_tok2_56959, 196);
    goto L6; // [232] 571
L9: 

    /** parser.e:1130					Function_call( tok2 )*/
    Ref(_tok2_56959);
    _45Function_call(_tok2_56959);
    goto L6; // [241] 571
L8: 

    /** parser.e:1139				sym = tok2[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok2_56959);
    _sym_56964 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_sym_56964)){
        _sym_56964 = (object)DBL_PTR(_sym_56964)->dbl;
    }

    /** parser.e:1140				if SymTab[sym][S_SCOPE] = SC_UNDEFINED then*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _28733 = (object)*(((s1_ptr)_2)->base + _sym_56964);
    _2 = (object)SEQ_PTR(_28733);
    _28734 = (object)*(((s1_ptr)_2)->base + 4);
    _28733 = NOVALUE;
    if (binary_op_a(NOTEQ, _28734, 9)){
        _28734 = NOVALUE;
        goto LA; // [270] 292
    }
    _28734 = NOVALUE;

    /** parser.e:1141					Forward_var( tok2, TRUE )*/
    _2 = (object)SEQ_PTR(_tok2_56959);
    _28736 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_tok2_56959);
    Ref(_28736);
    _45Forward_var(_tok2_56959, _13TRUE_447, _28736);
    _28736 = NOVALUE;
    goto LB; // [289] 339
LA: 

    /** parser.e:1143					SymTab[sym][S_USAGE] = or_bits(SymTab[sym][S_USAGE], U_READ)*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_56964 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _28739 = (object)*(((s1_ptr)_2)->base + _sym_56964);
    _2 = (object)SEQ_PTR(_28739);
    _28740 = (object)*(((s1_ptr)_2)->base + 5);
    _28739 = NOVALUE;
    if (IS_ATOM_INT(_28740)) {
        {uintptr_t tu;
             tu = (uintptr_t)_28740 | (uintptr_t)1;
             _28741 = MAKE_UINT(tu);
        }
    }
    else {
        _28741 = binary_op(OR_BITS, _28740, 1);
    }
    _28740 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _28741;
    if( _1 != _28741 ){
        DeRef(_1);
    }
    _28741 = NOVALUE;
    _28737 = NOVALUE;

    /** parser.e:1144					InitCheck(sym, TRUE)*/
    _45InitCheck(_sym_56964, _13TRUE_447);

    /** parser.e:1145					emit_opnd(sym)*/
    _47emit_opnd(_sym_56964);
LB: 

    /** parser.e:1149				if sym = left_sym then*/
    if (_sym_56964 != _45left_sym_55397)
    goto LC; // [343] 353

    /** parser.e:1150					lhs_subs_level = 0*/
    _45lhs_subs_level_55395 = 0;
LC: 

    /** parser.e:1155				tok2 = tok3*/
    Ref(_tok3_56960);
    DeRef(_tok2_56959);
    _tok2_56959 = _tok3_56960;

    /** parser.e:1156				current_sequence = append(current_sequence, sym)*/
    Append(&_47current_sequence_51372, _47current_sequence_51372, _sym_56964);

    /** parser.e:1157				while tok2[T_ID] = LEFT_SQUARE do*/
LD: 
    _2 = (object)SEQ_PTR(_tok2_56959);
    _28744 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28744, -28)){
        _28744 = NOVALUE;
        goto LE; // [381] 549
    }
    _28744 = NOVALUE;

    /** parser.e:1158					subs_depth += 1*/
    _45subs_depth_55398 = _45subs_depth_55398 + 1;

    /** parser.e:1159					if lhs_subs_level >= 0 then*/
    if (_45lhs_subs_level_55395 < 0)
    goto LF; // [397] 410

    /** parser.e:1160						lhs_subs_level += 1*/
    _45lhs_subs_level_55395 = _45lhs_subs_level_55395 + 1;
LF: 

    /** parser.e:1162					save_factors = factors*/
    _save_factors_56961 = _45factors_55394;

    /** parser.e:1163					save_lhs_subs_level = lhs_subs_level*/
    _save_lhs_subs_level_56962 = _45lhs_subs_level_55395;

    /** parser.e:1164					call_proc(forward_expr, {})*/
    _0 = (object)_00[_45forward_expr_56391].addr;
    (*(intptr_t (*)())_0)(
                         );

    /** parser.e:1165					tok2 = next_token()*/
    _0 = _tok2_56959;
    _tok2_56959 = _45next_token();
    DeRef(_0);

    /** parser.e:1166					if tok2[T_ID] = SLICE then*/
    _2 = (object)SEQ_PTR(_tok2_56959);
    _28750 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28750, 513)){
        _28750 = NOVALUE;
        goto L10; // [446] 484
    }
    _28750 = NOVALUE;

    /** parser.e:1167						call_proc(forward_expr, {})*/
    _0 = (object)_00[_45forward_expr_56391].addr;
    (*(intptr_t (*)())_0)(
                         );

    /** parser.e:1168						emit_op(RHS_SLICE)*/
    _47emit_op(46);

    /** parser.e:1169						tok_match(RIGHT_SQUARE)*/
    _45tok_match(-29, 0);

    /** parser.e:1170						tok2 = next_token()*/
    _0 = _tok2_56959;
    _tok2_56959 = _45next_token();
    DeRef(_0);

    /** parser.e:1171						exit*/
    goto LE; // [479] 549
    goto L11; // [481] 529
L10: 

    /** parser.e:1173						putback(tok2)*/
    Ref(_tok2_56959);
    _45putback(_tok2_56959);

    /** parser.e:1174						tok_match(RIGHT_SQUARE)*/
    _45tok_match(-29, 0);

    /** parser.e:1175						subs_depth -= 1*/
    _45subs_depth_55398 = _45subs_depth_55398 - 1;

    /** parser.e:1176						current_sequence = remove( current_sequence, length( current_sequence ) )*/
    if (IS_SEQUENCE(_47current_sequence_51372)){
            _28754 = SEQ_PTR(_47current_sequence_51372)->length;
    }
    else {
        _28754 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_47current_sequence_51372);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_28754)) ? _28754 : (object)(DBL_PTR(_28754)->dbl);
        int stop = (IS_ATOM_INT(_28754)) ? _28754 : (object)(DBL_PTR(_28754)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_47current_sequence_51372), start, &_47current_sequence_51372 );
            }
            else Tail(SEQ_PTR(_47current_sequence_51372), stop+1, &_47current_sequence_51372);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_47current_sequence_51372), start, &_47current_sequence_51372);
        }
        else {
            assign_slice_seq = &assign_space;
            _47current_sequence_51372 = Remove_elements(start, stop, (SEQ_PTR(_47current_sequence_51372)->ref == 1));
        }
    }
    _28754 = NOVALUE;
    _28754 = NOVALUE;

    /** parser.e:1177						emit_op(RHS_SUBS)*/
    _47emit_op(25);
L11: 

    /** parser.e:1180					factors = save_factors*/
    _45factors_55394 = _save_factors_56961;

    /** parser.e:1181					lhs_subs_level = save_lhs_subs_level*/
    _45lhs_subs_level_55395 = _save_lhs_subs_level_56962;

    /** parser.e:1182					tok2 = next_token()*/
    _0 = _tok2_56959;
    _tok2_56959 = _45next_token();
    DeRef(_0);

    /** parser.e:1183				end while*/
    goto LD; // [546] 373
LE: 

    /** parser.e:1184				current_sequence = remove( current_sequence, length( current_sequence ) )*/
    if (IS_SEQUENCE(_47current_sequence_51372)){
            _28757 = SEQ_PTR(_47current_sequence_51372)->length;
    }
    else {
        _28757 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_47current_sequence_51372);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_28757)) ? _28757 : (object)(DBL_PTR(_28757)->dbl);
        int stop = (IS_ATOM_INT(_28757)) ? _28757 : (object)(DBL_PTR(_28757)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_47current_sequence_51372), start, &_47current_sequence_51372 );
            }
            else Tail(SEQ_PTR(_47current_sequence_51372), stop+1, &_47current_sequence_51372);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_47current_sequence_51372), start, &_47current_sequence_51372);
        }
        else {
            assign_slice_seq = &assign_space;
            _47current_sequence_51372 = Remove_elements(start, stop, (SEQ_PTR(_47current_sequence_51372)->ref == 1));
        }
    }
    _28757 = NOVALUE;
    _28757 = NOVALUE;

    /** parser.e:1185				putback(tok2)*/
    Ref(_tok2_56959);
    _45putback(_tok2_56959);
L6: 

    /** parser.e:1189			tok_match( RIGHT_ROUND )*/
    _45tok_match(-27, 0);
    goto L12; // [579] 599
L2: 

    /** parser.e:1191			putback(tok2)*/
    Ref(_tok2_56959);
    _45putback(_tok2_56959);

    /** parser.e:1192			ParseArgs(tok[T_SYM])*/
    _2 = (object)SEQ_PTR(_tok_56957);
    _28759 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_28759);
    _45ParseArgs(_28759);
    _28759 = NOVALUE;
L12: 

    /** parser.e:1194	end procedure*/
    DeRef(_tok_56957);
    DeRef(_tok2_56959);
    DeRef(_tok3_56960);
    _28728 = NOVALUE;
    DeRef(_28706);
    _28706 = NOVALUE;
    return;
    ;
}


void _45Function_call(object _tok_57102)
{
    object _id_57103 = NOVALUE;
    object _scope_57104 = NOVALUE;
    object _opcode_57105 = NOVALUE;
    object _e_57106 = NOVALUE;
    object _28800 = NOVALUE;
    object _28799 = NOVALUE;
    object _28798 = NOVALUE;
    object _28797 = NOVALUE;
    object _28796 = NOVALUE;
    object _28795 = NOVALUE;
    object _28794 = NOVALUE;
    object _28792 = NOVALUE;
    object _28791 = NOVALUE;
    object _28789 = NOVALUE;
    object _28788 = NOVALUE;
    object _28787 = NOVALUE;
    object _28786 = NOVALUE;
    object _28785 = NOVALUE;
    object _28784 = NOVALUE;
    object _28783 = NOVALUE;
    object _28782 = NOVALUE;
    object _28781 = NOVALUE;
    object _28780 = NOVALUE;
    object _28779 = NOVALUE;
    object _28778 = NOVALUE;
    object _28777 = NOVALUE;
    object _28776 = NOVALUE;
    object _28775 = NOVALUE;
    object _28773 = NOVALUE;
    object _28771 = NOVALUE;
    object _28770 = NOVALUE;
    object _28768 = NOVALUE;
    object _28766 = NOVALUE;
    object _28765 = NOVALUE;
    object _28764 = NOVALUE;
    object _28763 = NOVALUE;
    object _28761 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:1200		id = tok[T_ID]*/
    _2 = (object)SEQ_PTR(_tok_57102);
    _id_57103 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_id_57103)){
        _id_57103 = (object)DBL_PTR(_id_57103)->dbl;
    }

    /** parser.e:1201		if id = FUNC or id = TYPE then*/
    _28761 = (_id_57103 == 501);
    if (_28761 != 0) {
        goto L1; // [19] 34
    }
    _28763 = (_id_57103 == 504);
    if (_28763 == 0)
    {
        DeRef(_28763);
        _28763 = NOVALUE;
        goto L2; // [30] 46
    }
    else{
        DeRef(_28763);
        _28763 = NOVALUE;
    }
L1: 

    /** parser.e:1203			UndefinedVar( tok[T_SYM] )*/
    _2 = (object)SEQ_PTR(_tok_57102);
    _28764 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_28764);
    _45UndefinedVar(_28764);
    _28764 = NOVALUE;
L2: 

    /** parser.e:1206		e = SymTab[tok[T_SYM]][S_EFFECT]*/
    _2 = (object)SEQ_PTR(_tok_57102);
    _28765 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!IS_ATOM_INT(_28765)){
        _28766 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_28765)->dbl));
    }
    else{
        _28766 = (object)*(((s1_ptr)_2)->base + _28765);
    }
    _2 = (object)SEQ_PTR(_28766);
    _e_57106 = (object)*(((s1_ptr)_2)->base + 23);
    if (!IS_ATOM_INT(_e_57106)){
        _e_57106 = (object)DBL_PTR(_e_57106)->dbl;
    }
    _28766 = NOVALUE;

    /** parser.e:1207		if e then*/
    if (_e_57106 == 0)
    {
        goto L3; // [70] 229
    }
    else{
    }

    /** parser.e:1209			if e = E_ALL_EFFECT or tok[T_SYM] > left_sym then*/
    _28768 = (_e_57106 == 1073741823);
    if (_28768 != 0) {
        goto L4; // [81] 102
    }
    _2 = (object)SEQ_PTR(_tok_57102);
    _28770 = (object)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_28770)) {
        _28771 = (_28770 > _45left_sym_55397);
    }
    else {
        _28771 = binary_op(GREATER, _28770, _45left_sym_55397);
    }
    _28770 = NOVALUE;
    if (_28771 == 0) {
        DeRef(_28771);
        _28771 = NOVALUE;
        goto L5; // [98] 111
    }
    else {
        if (!IS_ATOM_INT(_28771) && DBL_PTR(_28771)->dbl == 0.0){
            DeRef(_28771);
            _28771 = NOVALUE;
            goto L5; // [98] 111
        }
        DeRef(_28771);
        _28771 = NOVALUE;
    }
    DeRef(_28771);
    _28771 = NOVALUE;
L4: 

    /** parser.e:1211				side_effect_calls = or_bits(side_effect_calls, e)*/
    {uintptr_t tu;
         tu = (uintptr_t)_45side_effect_calls_55393 | (uintptr_t)_e_57106;
         _45side_effect_calls_55393 = MAKE_UINT(tu);
    }
L5: 

    /** parser.e:1214			SymTab[CurrentSub][S_EFFECT] = or_bits(SymTab[CurrentSub][S_EFFECT], e)*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_36CurrentSub_21775 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _28775 = (object)*(((s1_ptr)_2)->base + _36CurrentSub_21775);
    _2 = (object)SEQ_PTR(_28775);
    _28776 = (object)*(((s1_ptr)_2)->base + 23);
    _28775 = NOVALUE;
    if (IS_ATOM_INT(_28776)) {
        {uintptr_t tu;
             tu = (uintptr_t)_28776 | (uintptr_t)_e_57106;
             _28777 = MAKE_UINT(tu);
        }
    }
    else {
        _28777 = binary_op(OR_BITS, _28776, _e_57106);
    }
    _28776 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 23);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _28777;
    if( _1 != _28777 ){
        DeRef(_1);
    }
    _28777 = NOVALUE;
    _28773 = NOVALUE;

    /** parser.e:1216			if short_circuit > 0 and short_circuit_B and*/
    _28778 = (_45short_circuit_55356 > 0);
    if (_28778 == 0) {
        _28779 = 0;
        goto L6; // [154] 164
    }
    _28779 = (_45short_circuit_B_55358 != 0);
L6: 
    if (_28779 == 0) {
        goto L7; // [164] 228
    }
    _28781 = find_from(_id_57103, _38FUNC_TOKS_16303, 1);
    if (_28781 == 0)
    {
        _28781 = NOVALUE;
        goto L7; // [176] 228
    }
    else{
        _28781 = NOVALUE;
    }

    /** parser.e:1218				Warning(219, short_circuit_warning_flag,*/
    _2 = (object)SEQ_PTR(_37known_files_15638);
    _28782 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21767);
    Ref(_28782);
    RefDS(_22190);
    _28783 = _17abbreviate_path(_28782, _22190);
    _28782 = NOVALUE;
    _2 = (object)SEQ_PTR(_tok_57102);
    _28784 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!IS_ATOM_INT(_28784)){
        _28785 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_28784)->dbl));
    }
    else{
        _28785 = (object)*(((s1_ptr)_2)->base + _28784);
    }
    _2 = (object)SEQ_PTR(_28785);
    if (!IS_ATOM_INT(_36S_NAME_21404)){
        _28786 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21404)->dbl));
    }
    else{
        _28786 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21404);
    }
    _28785 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _28783;
    ((intptr_t*)_2)[2] = _36line_number_21768;
    Ref(_28786);
    ((intptr_t*)_2)[3] = _28786;
    _28787 = MAKE_SEQ(_1);
    _28786 = NOVALUE;
    _28783 = NOVALUE;
    _50Warning(219, 2, _28787);
    _28787 = NOVALUE;
L7: 
L3: 

    /** parser.e:1222		tok_match(LEFT_ROUND)*/
    _45tok_match(-26, 0);

    /** parser.e:1223		scope = SymTab[tok[T_SYM]][S_SCOPE]*/
    _2 = (object)SEQ_PTR(_tok_57102);
    _28788 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!IS_ATOM_INT(_28788)){
        _28789 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_28788)->dbl));
    }
    else{
        _28789 = (object)*(((s1_ptr)_2)->base + _28788);
    }
    _2 = (object)SEQ_PTR(_28789);
    _scope_57104 = (object)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_scope_57104)){
        _scope_57104 = (object)DBL_PTR(_scope_57104)->dbl;
    }
    _28789 = NOVALUE;

    /** parser.e:1224		opcode = SymTab[tok[T_SYM]][S_OPCODE]*/
    _2 = (object)SEQ_PTR(_tok_57102);
    _28791 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!IS_ATOM_INT(_28791)){
        _28792 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_28791)->dbl));
    }
    else{
        _28792 = (object)*(((s1_ptr)_2)->base + _28791);
    }
    _2 = (object)SEQ_PTR(_28792);
    _opcode_57105 = (object)*(((s1_ptr)_2)->base + 21);
    if (!IS_ATOM_INT(_opcode_57105)){
        _opcode_57105 = (object)DBL_PTR(_opcode_57105)->dbl;
    }
    _28792 = NOVALUE;

    /** parser.e:1225		if equal(SymTab[tok[T_SYM]][S_NAME],"object") and scope = SC_PREDEF then*/
    _2 = (object)SEQ_PTR(_tok_57102);
    _28794 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!IS_ATOM_INT(_28794)){
        _28795 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_28794)->dbl));
    }
    else{
        _28795 = (object)*(((s1_ptr)_2)->base + _28794);
    }
    _2 = (object)SEQ_PTR(_28795);
    if (!IS_ATOM_INT(_36S_NAME_21404)){
        _28796 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21404)->dbl));
    }
    else{
        _28796 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21404);
    }
    _28795 = NOVALUE;
    if (_28796 == _23147)
    _28797 = 1;
    else if (IS_ATOM_INT(_28796) && IS_ATOM_INT(_23147))
    _28797 = 0;
    else
    _28797 = (compare(_28796, _23147) == 0);
    _28796 = NOVALUE;
    if (_28797 == 0) {
        goto L8; // [305] 327
    }
    _28799 = (_scope_57104 == 7);
    if (_28799 == 0)
    {
        DeRef(_28799);
        _28799 = NOVALUE;
        goto L8; // [316] 327
    }
    else{
        DeRef(_28799);
        _28799 = NOVALUE;
    }

    /** parser.e:1227			Object_call( tok )*/
    Ref(_tok_57102);
    _45Object_call(_tok_57102);
    goto L9; // [324] 339
L8: 

    /** parser.e:1230			ParseArgs(tok[T_SYM])*/
    _2 = (object)SEQ_PTR(_tok_57102);
    _28800 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_28800);
    _45ParseArgs(_28800);
    _28800 = NOVALUE;
L9: 

    /** parser.e:1233		if scope = SC_PREDEF then*/
    if (_scope_57104 != 7)
    goto LA; // [343] 355

    /** parser.e:1234			emit_op(opcode)*/
    _47emit_op(_opcode_57105);
    goto LB; // [352] 393
LA: 

    /** parser.e:1236			op_info1 = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_57102);
    _47op_info1_51364 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_47op_info1_51364)){
        _47op_info1_51364 = (object)DBL_PTR(_47op_info1_51364)->dbl;
    }

    /** parser.e:1238			emit_or_inline()*/
    _67emit_or_inline();

    /** parser.e:1239			if not TRANSLATE then*/
    if (_36TRANSLATE_21369 != 0)
    goto LC; // [373] 392

    /** parser.e:1240				if OpTrace then*/
    if (_36OpTrace_21840 == 0)
    {
        goto LD; // [380] 391
    }
    else{
    }

    /** parser.e:1241					emit_op(UPDATE_GLOBALS)*/
    _47emit_op(89);
LD: 
LC: 
LB: 

    /** parser.e:1245	end procedure*/
    DeRef(_tok_57102);
    DeRef(_28778);
    _28778 = NOVALUE;
    _28784 = NOVALUE;
    _28794 = NOVALUE;
    _28765 = NOVALUE;
    DeRef(_28768);
    _28768 = NOVALUE;
    DeRef(_28761);
    _28761 = NOVALUE;
    _28788 = NOVALUE;
    _28791 = NOVALUE;
    return;
    ;
}


void _45Factor()
{
    object _tok_57210 = NOVALUE;
    object _id_57211 = NOVALUE;
    object _n_57212 = NOVALUE;
    object _save_factors_57213 = NOVALUE;
    object _save_lhs_subs_level_57214 = NOVALUE;
    object _sym_57216 = NOVALUE;
    object _forward_57247 = NOVALUE;
    object _28860 = NOVALUE;
    object _28859 = NOVALUE;
    object _28858 = NOVALUE;
    object _28856 = NOVALUE;
    object _28855 = NOVALUE;
    object _28854 = NOVALUE;
    object _28853 = NOVALUE;
    object _28852 = NOVALUE;
    object _28850 = NOVALUE;
    object _28846 = NOVALUE;
    object _28843 = NOVALUE;
    object _28839 = NOVALUE;
    object _28833 = NOVALUE;
    object _28828 = NOVALUE;
    object _28827 = NOVALUE;
    object _28826 = NOVALUE;
    object _28824 = NOVALUE;
    object _28823 = NOVALUE;
    object _28821 = NOVALUE;
    object _28819 = NOVALUE;
    object _28818 = NOVALUE;
    object _28817 = NOVALUE;
    object _28815 = NOVALUE;
    object _28808 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:1250		integer id, n*/

    /** parser.e:1251		integer save_factors, save_lhs_subs_level*/

    /** parser.e:1254		factors += 1*/
    _45factors_55394 = _45factors_55394 + 1;

    /** parser.e:1255		tok = next_token()*/
    _0 = _tok_57210;
    _tok_57210 = _45next_token();
    DeRef(_0);

    /** parser.e:1256		id = tok[T_ID]*/
    _2 = (object)SEQ_PTR(_tok_57210);
    _id_57211 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_id_57211)){
        _id_57211 = (object)DBL_PTR(_id_57211)->dbl;
    }

    /** parser.e:1257		if id = RECORDED then*/
    if (_id_57211 != 508)
    goto L1; // [32] 59

    /** parser.e:1258			tok = read_recorded_token(tok[T_SYM])*/
    _2 = (object)SEQ_PTR(_tok_57210);
    _28808 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_28808);
    _0 = _tok_57210;
    _tok_57210 = _45read_recorded_token(_28808);
    DeRef(_0);
    _28808 = NOVALUE;

    /** parser.e:1259			id = tok[T_ID]*/
    _2 = (object)SEQ_PTR(_tok_57210);
    _id_57211 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_id_57211)){
        _id_57211 = (object)DBL_PTR(_id_57211)->dbl;
    }
L1: 

    /** parser.e:1261		switch id label "factor" do*/
    _0 = _id_57211;
    switch ( _0 ){ 

        /** parser.e:1262			case VARIABLE, QUALIFIED_VARIABLE then*/
        case -100:
        case 512:

        /** parser.e:1263				sym = tok[T_SYM]*/
        _2 = (object)SEQ_PTR(_tok_57210);
        _sym_57216 = (object)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_sym_57216)){
            _sym_57216 = (object)DBL_PTR(_sym_57216)->dbl;
        }

        /** parser.e:1264				if sym < 0 or SymTab[sym][S_SCOPE] = SC_UNDEFINED then*/
        _28815 = (_sym_57216 < 0);
        if (_28815 != 0) {
            goto L2; // [88] 115
        }
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _28817 = (object)*(((s1_ptr)_2)->base + _sym_57216);
        _2 = (object)SEQ_PTR(_28817);
        _28818 = (object)*(((s1_ptr)_2)->base + 4);
        _28817 = NOVALUE;
        if (IS_ATOM_INT(_28818)) {
            _28819 = (_28818 == 9);
        }
        else {
            _28819 = binary_op(EQUALS, _28818, 9);
        }
        _28818 = NOVALUE;
        if (_28819 == 0) {
            DeRef(_28819);
            _28819 = NOVALUE;
            goto L3; // [111] 177
        }
        else {
            if (!IS_ATOM_INT(_28819) && DBL_PTR(_28819)->dbl == 0.0){
                DeRef(_28819);
                _28819 = NOVALUE;
                goto L3; // [111] 177
            }
            DeRef(_28819);
            _28819 = NOVALUE;
        }
        DeRef(_28819);
        _28819 = NOVALUE;
L2: 

        /** parser.e:1265					token forward = next_token()*/
        _0 = _forward_57247;
        _forward_57247 = _45next_token();
        DeRef(_0);

        /** parser.e:1266					if forward[T_ID] = LEFT_ROUND then*/
        _2 = (object)SEQ_PTR(_forward_57247);
        _28821 = (object)*(((s1_ptr)_2)->base + 1);
        if (binary_op_a(NOTEQ, _28821, -26)){
            _28821 = NOVALUE;
            goto L4; // [130] 151
        }
        _28821 = NOVALUE;

        /** parser.e:1267						Forward_call( tok, FUNC_FORWARD )*/
        Ref(_tok_57210);
        _45Forward_call(_tok_57210, 196);

        /** parser.e:1268						break "factor"*/
        DeRef(_forward_57247);
        _forward_57247 = NOVALUE;
        goto L5; // [146] 694
        goto L6; // [148] 172
L4: 

        /** parser.e:1270						putback( forward )*/
        Ref(_forward_57247);
        _45putback(_forward_57247);

        /** parser.e:1271						Forward_var( tok, TRUE )*/
        _2 = (object)SEQ_PTR(_tok_57210);
        _28823 = (object)*(((s1_ptr)_2)->base + 1);
        Ref(_tok_57210);
        Ref(_28823);
        _45Forward_var(_tok_57210, _13TRUE_447, _28823);
        _28823 = NOVALUE;
L6: 
        DeRef(_forward_57247);
        _forward_57247 = NOVALUE;
        goto L7; // [174] 229
L3: 

        /** parser.e:1275					UndefinedVar(sym)*/
        _45UndefinedVar(_sym_57216);

        /** parser.e:1276					SymTab[sym][S_USAGE] = or_bits(SymTab[sym][S_USAGE], U_READ)*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37SymTab_15637 = MAKE_SEQ(_2);
        }
        _3 = (object)(_sym_57216 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _28826 = (object)*(((s1_ptr)_2)->base + _sym_57216);
        _2 = (object)SEQ_PTR(_28826);
        _28827 = (object)*(((s1_ptr)_2)->base + 5);
        _28826 = NOVALUE;
        if (IS_ATOM_INT(_28827)) {
            {uintptr_t tu;
                 tu = (uintptr_t)_28827 | (uintptr_t)1;
                 _28828 = MAKE_UINT(tu);
            }
        }
        else {
            _28828 = binary_op(OR_BITS, _28827, 1);
        }
        _28827 = NOVALUE;
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 5);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _28828;
        if( _1 != _28828 ){
            DeRef(_1);
        }
        _28828 = NOVALUE;
        _28824 = NOVALUE;

        /** parser.e:1277					InitCheck(sym, TRUE)*/
        _45InitCheck(_sym_57216, _13TRUE_447);

        /** parser.e:1278					emit_opnd(sym)*/
        _47emit_opnd(_sym_57216);
L7: 

        /** parser.e:1281				if sym = left_sym then*/
        if (_sym_57216 != _45left_sym_55397)
        goto L8; // [233] 243

        /** parser.e:1282					lhs_subs_level = 0 -- start counting subscripts*/
        _45lhs_subs_level_55395 = 0;
L8: 

        /** parser.e:1285				short_circuit -= 1*/
        _45short_circuit_55356 = _45short_circuit_55356 - 1;

        /** parser.e:1286				tok = next_token()*/
        _0 = _tok_57210;
        _tok_57210 = _45next_token();
        DeRef(_0);

        /** parser.e:1287				current_sequence = append(current_sequence, sym)*/
        Append(&_47current_sequence_51372, _47current_sequence_51372, _sym_57216);

        /** parser.e:1288				while tok[T_ID] = LEFT_SQUARE do*/
L9: 
        _2 = (object)SEQ_PTR(_tok_57210);
        _28833 = (object)*(((s1_ptr)_2)->base + 1);
        if (binary_op_a(NOTEQ, _28833, -28)){
            _28833 = NOVALUE;
            goto LA; // [279] 447
        }
        _28833 = NOVALUE;

        /** parser.e:1289					subs_depth += 1*/
        _45subs_depth_55398 = _45subs_depth_55398 + 1;

        /** parser.e:1290					if lhs_subs_level >= 0 then*/
        if (_45lhs_subs_level_55395 < 0)
        goto LB; // [295] 308

        /** parser.e:1291						lhs_subs_level += 1*/
        _45lhs_subs_level_55395 = _45lhs_subs_level_55395 + 1;
LB: 

        /** parser.e:1293					save_factors = factors*/
        _save_factors_57213 = _45factors_55394;

        /** parser.e:1294					save_lhs_subs_level = lhs_subs_level*/
        _save_lhs_subs_level_57214 = _45lhs_subs_level_55395;

        /** parser.e:1295					call_proc(forward_expr, {})*/
        _0 = (object)_00[_45forward_expr_56391].addr;
        (*(intptr_t (*)())_0)(
                             );

        /** parser.e:1296					tok = next_token()*/
        _0 = _tok_57210;
        _tok_57210 = _45next_token();
        DeRef(_0);

        /** parser.e:1297					if tok[T_ID] = SLICE then*/
        _2 = (object)SEQ_PTR(_tok_57210);
        _28839 = (object)*(((s1_ptr)_2)->base + 1);
        if (binary_op_a(NOTEQ, _28839, 513)){
            _28839 = NOVALUE;
            goto LC; // [344] 382
        }
        _28839 = NOVALUE;

        /** parser.e:1298						call_proc(forward_expr, {})*/
        _0 = (object)_00[_45forward_expr_56391].addr;
        (*(intptr_t (*)())_0)(
                             );

        /** parser.e:1299						emit_op(RHS_SLICE)*/
        _47emit_op(46);

        /** parser.e:1300						tok_match(RIGHT_SQUARE)*/
        _45tok_match(-29, 0);

        /** parser.e:1301						tok = next_token()*/
        _0 = _tok_57210;
        _tok_57210 = _45next_token();
        DeRef(_0);

        /** parser.e:1302						exit*/
        goto LA; // [377] 447
        goto LD; // [379] 427
LC: 

        /** parser.e:1304						putback(tok)*/
        Ref(_tok_57210);
        _45putback(_tok_57210);

        /** parser.e:1305						tok_match(RIGHT_SQUARE)*/
        _45tok_match(-29, 0);

        /** parser.e:1306						subs_depth -= 1*/
        _45subs_depth_55398 = _45subs_depth_55398 - 1;

        /** parser.e:1307						current_sequence = remove( current_sequence, length( current_sequence ) )*/
        if (IS_SEQUENCE(_47current_sequence_51372)){
                _28843 = SEQ_PTR(_47current_sequence_51372)->length;
        }
        else {
            _28843 = 1;
        }
        {
            s1_ptr assign_space = SEQ_PTR(_47current_sequence_51372);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_28843)) ? _28843 : (object)(DBL_PTR(_28843)->dbl);
            int stop = (IS_ATOM_INT(_28843)) ? _28843 : (object)(DBL_PTR(_28843)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<1) {
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_47current_sequence_51372), start, &_47current_sequence_51372 );
                }
                else Tail(SEQ_PTR(_47current_sequence_51372), stop+1, &_47current_sequence_51372);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_47current_sequence_51372), start, &_47current_sequence_51372);
            }
            else {
                assign_slice_seq = &assign_space;
                _47current_sequence_51372 = Remove_elements(start, stop, (SEQ_PTR(_47current_sequence_51372)->ref == 1));
            }
        }
        _28843 = NOVALUE;
        _28843 = NOVALUE;

        /** parser.e:1308						emit_op(RHS_SUBS) -- current_sequence will be updated*/
        _47emit_op(25);
LD: 

        /** parser.e:1310					factors = save_factors*/
        _45factors_55394 = _save_factors_57213;

        /** parser.e:1311					lhs_subs_level = save_lhs_subs_level*/
        _45lhs_subs_level_55395 = _save_lhs_subs_level_57214;

        /** parser.e:1312					tok = next_token()*/
        _0 = _tok_57210;
        _tok_57210 = _45next_token();
        DeRef(_0);

        /** parser.e:1313				end while*/
        goto L9; // [444] 271
LA: 

        /** parser.e:1314				current_sequence = remove( current_sequence, length( current_sequence ) )*/
        if (IS_SEQUENCE(_47current_sequence_51372)){
                _28846 = SEQ_PTR(_47current_sequence_51372)->length;
        }
        else {
            _28846 = 1;
        }
        {
            s1_ptr assign_space = SEQ_PTR(_47current_sequence_51372);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_28846)) ? _28846 : (object)(DBL_PTR(_28846)->dbl);
            int stop = (IS_ATOM_INT(_28846)) ? _28846 : (object)(DBL_PTR(_28846)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<1) {
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_47current_sequence_51372), start, &_47current_sequence_51372 );
                }
                else Tail(SEQ_PTR(_47current_sequence_51372), stop+1, &_47current_sequence_51372);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_47current_sequence_51372), start, &_47current_sequence_51372);
            }
            else {
                assign_slice_seq = &assign_space;
                _47current_sequence_51372 = Remove_elements(start, stop, (SEQ_PTR(_47current_sequence_51372)->ref == 1));
            }
        }
        _28846 = NOVALUE;
        _28846 = NOVALUE;

        /** parser.e:1315				putback(tok)*/
        Ref(_tok_57210);
        _45putback(_tok_57210);

        /** parser.e:1316				short_circuit += 1*/
        _45short_circuit_55356 = _45short_circuit_55356 + 1;
        goto L5; // [476] 694

        /** parser.e:1318			case DOLLAR then*/
        case -22:

        /** parser.e:1319				tok = next_token()*/
        _0 = _tok_57210;
        _tok_57210 = _45next_token();
        DeRef(_0);

        /** parser.e:1320				putback(tok)*/
        Ref(_tok_57210);
        _45putback(_tok_57210);

        /** parser.e:1321				if tok[T_ID] = RIGHT_BRACE then*/
        _2 = (object)SEQ_PTR(_tok_57210);
        _28850 = (object)*(((s1_ptr)_2)->base + 1);
        if (binary_op_a(NOTEQ, _28850, -25)){
            _28850 = NOVALUE;
            goto LE; // [502] 520
        }
        _28850 = NOVALUE;

        /** parser.e:1322					gListItem[$] = 0*/
        if (IS_SEQUENCE(_45gListItem_55392)){
                _28852 = SEQ_PTR(_45gListItem_55392)->length;
        }
        else {
            _28852 = 1;
        }
        _2 = (object)SEQ_PTR(_45gListItem_55392);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _45gListItem_55392 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _28852);
        *(intptr_t *)_2 = 0;
        goto L5; // [517] 694
LE: 

        /** parser.e:1324					if subs_depth > 0 and length(current_sequence) then*/
        _28853 = (_45subs_depth_55398 > 0);
        if (_28853 == 0) {
            goto LF; // [528] 551
        }
        if (IS_SEQUENCE(_47current_sequence_51372)){
                _28855 = SEQ_PTR(_47current_sequence_51372)->length;
        }
        else {
            _28855 = 1;
        }
        if (_28855 == 0)
        {
            _28855 = NOVALUE;
            goto LF; // [538] 551
        }
        else{
            _28855 = NOVALUE;
        }

        /** parser.e:1325						emit_op(DOLLAR)*/
        _47emit_op(-22);
        goto L5; // [548] 694
LF: 

        /** parser.e:1327						CompileErr(MSG__MUST_ONLY_APPEAR_BETWEEN__AND__OR_AS_THE_LAST_ITEM_IN_A_SEQUENCE_LITERAL)*/
        RefDS(_22190);
        _50CompileErr(21, _22190, 0);
        goto L5; // [562] 694

        /** parser.e:1331			case ATOM then*/
        case 502:

        /** parser.e:1332				emit_opnd(tok[T_SYM])*/
        _2 = (object)SEQ_PTR(_tok_57210);
        _28856 = (object)*(((s1_ptr)_2)->base + 2);
        Ref(_28856);
        _47emit_opnd(_28856);
        _28856 = NOVALUE;
        goto L5; // [579] 694

        /** parser.e:1334			case LEFT_BRACE then*/
        case -24:

        /** parser.e:1335				n = Expr_list()*/
        _n_57212 = _45Expr_list();
        if (!IS_ATOM_INT(_n_57212)) {
            _1 = (object)(DBL_PTR(_n_57212)->dbl);
            DeRefDS(_n_57212);
            _n_57212 = _1;
        }

        /** parser.e:1336				tok_match(RIGHT_BRACE)*/
        _45tok_match(-25, 0);

        /** parser.e:1337				op_info1 = n*/
        _47op_info1_51364 = _n_57212;

        /** parser.e:1338				emit_op(RIGHT_BRACE_N)*/
        _47emit_op(31);
        goto L5; // [614] 694

        /** parser.e:1340			case STRING then*/
        case 503:

        /** parser.e:1341				emit_opnd(tok[T_SYM])*/
        _2 = (object)SEQ_PTR(_tok_57210);
        _28858 = (object)*(((s1_ptr)_2)->base + 2);
        Ref(_28858);
        _47emit_opnd(_28858);
        _28858 = NOVALUE;
        goto L5; // [631] 694

        /** parser.e:1343			case LEFT_ROUND then*/
        case -26:

        /** parser.e:1344				call_proc(forward_expr, {})*/
        _0 = (object)_00[_45forward_expr_56391].addr;
        (*(intptr_t (*)())_0)(
                             );

        /** parser.e:1345				tok_match(RIGHT_ROUND)*/
        _45tok_match(-27, 0);
        goto L5; // [652] 694

        /** parser.e:1347			case FUNC, TYPE, QUALIFIED_FUNC, QUALIFIED_TYPE then*/
        case 501:
        case 504:
        case 520:
        case 522:

        /** parser.e:1348				Function_call( tok )*/
        Ref(_tok_57210);
        _45Function_call(_tok_57210);
        goto L5; // [669] 694

        /** parser.e:1350			case else*/
        default:

        /** parser.e:1351				CompileErr(SYNTAX_ERROR__EXPECTED_TO_SEE_AN_EXPRESSION_NOT_1, {LexName(id)})*/
        RefDS(_26602);
        _28859 = _47LexName(_id_57211, _26602);
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _28859;
        _28860 = MAKE_SEQ(_1);
        _28859 = NOVALUE;
        _50CompileErr(135, _28860, 0);
        _28860 = NOVALUE;
    ;}L5: 

    /** parser.e:1353	end procedure*/
    DeRef(_tok_57210);
    DeRef(_28853);
    _28853 = NOVALUE;
    DeRef(_28815);
    _28815 = NOVALUE;
    return;
    ;
}


void _45UFactor()
{
    object _tok_57369 = NOVALUE;
    object _28866 = NOVALUE;
    object _28864 = NOVALUE;
    object _28862 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:1359		tok = next_token()*/
    _0 = _tok_57369;
    _tok_57369 = _45next_token();
    DeRef(_0);

    /** parser.e:1361		if tok[T_ID] = MINUS then*/
    _2 = (object)SEQ_PTR(_tok_57369);
    _28862 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28862, 10)){
        _28862 = NOVALUE;
        goto L1; // [16] 34
    }
    _28862 = NOVALUE;

    /** parser.e:1362			Factor()*/
    _45Factor();

    /** parser.e:1363			emit_op(UMINUS)*/
    _47emit_op(12);
    goto L2; // [31] 93
L1: 

    /** parser.e:1365		elsif tok[T_ID] = NOT then*/
    _2 = (object)SEQ_PTR(_tok_57369);
    _28864 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28864, 7)){
        _28864 = NOVALUE;
        goto L3; // [44] 62
    }
    _28864 = NOVALUE;

    /** parser.e:1366			Factor()*/
    _45Factor();

    /** parser.e:1367			emit_op(NOT)*/
    _47emit_op(7);
    goto L2; // [59] 93
L3: 

    /** parser.e:1369		elsif tok[T_ID] = PLUS then*/
    _2 = (object)SEQ_PTR(_tok_57369);
    _28866 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28866, 11)){
        _28866 = NOVALUE;
        goto L4; // [72] 83
    }
    _28866 = NOVALUE;

    /** parser.e:1370			Factor()*/
    _45Factor();
    goto L2; // [80] 93
L4: 

    /** parser.e:1373			putback(tok)*/
    Ref(_tok_57369);
    _45putback(_tok_57369);

    /** parser.e:1374			Factor()*/
    _45Factor();
L2: 

    /** parser.e:1377	end procedure*/
    DeRef(_tok_57369);
    return;
    ;
}


object _45Term()
{
    object _tok_57394 = NOVALUE;
    object _28874 = NOVALUE;
    object _28873 = NOVALUE;
    object _28872 = NOVALUE;
    object _28870 = NOVALUE;
    object _28869 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:1383		UFactor()*/
    _45UFactor();

    /** parser.e:1384		tok = next_token()*/
    _0 = _tok_57394;
    _tok_57394 = _45next_token();
    DeRef(_0);

    /** parser.e:1385		while tok[T_ID] = reserved:MULTIPLY or tok[T_ID] = reserved:DIVIDE do*/
L1: 
    _2 = (object)SEQ_PTR(_tok_57394);
    _28869 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_28869)) {
        _28870 = (_28869 == 13);
    }
    else {
        _28870 = binary_op(EQUALS, _28869, 13);
    }
    _28869 = NOVALUE;
    if (IS_ATOM_INT(_28870)) {
        if (_28870 != 0) {
            goto L2; // [25] 44
        }
    }
    else {
        if (DBL_PTR(_28870)->dbl != 0.0) {
            goto L2; // [25] 44
        }
    }
    _2 = (object)SEQ_PTR(_tok_57394);
    _28872 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_28872)) {
        _28873 = (_28872 == 14);
    }
    else {
        _28873 = binary_op(EQUALS, _28872, 14);
    }
    _28872 = NOVALUE;
    if (_28873 <= 0) {
        if (_28873 == 0) {
            DeRef(_28873);
            _28873 = NOVALUE;
            goto L3; // [40] 69
        }
        else {
            if (!IS_ATOM_INT(_28873) && DBL_PTR(_28873)->dbl == 0.0){
                DeRef(_28873);
                _28873 = NOVALUE;
                goto L3; // [40] 69
            }
            DeRef(_28873);
            _28873 = NOVALUE;
        }
    }
    DeRef(_28873);
    _28873 = NOVALUE;
L2: 

    /** parser.e:1386			UFactor()*/
    _45UFactor();

    /** parser.e:1387			emit_op(tok[T_ID])*/
    _2 = (object)SEQ_PTR(_tok_57394);
    _28874 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_28874);
    _47emit_op(_28874);
    _28874 = NOVALUE;

    /** parser.e:1388			tok = next_token()*/
    _0 = _tok_57394;
    _tok_57394 = _45next_token();
    DeRef(_0);

    /** parser.e:1389		end while*/
    goto L1; // [66] 15
L3: 

    /** parser.e:1390		return tok*/
    DeRef(_28870);
    _28870 = NOVALUE;
    return _tok_57394;
    ;
}


object _45aexpr()
{
    object _tok_57411 = NOVALUE;
    object _id_57412 = NOVALUE;
    object _28881 = NOVALUE;
    object _28880 = NOVALUE;
    object _28878 = NOVALUE;
    object _28877 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:1396		integer id*/

    /** parser.e:1398		tok = Term()*/
    _0 = _tok_57411;
    _tok_57411 = _45Term();
    DeRef(_0);

    /** parser.e:1399		while tok[T_ID] = PLUS or tok[T_ID] = MINUS do*/
L1: 
    _2 = (object)SEQ_PTR(_tok_57411);
    _28877 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_28877)) {
        _28878 = (_28877 == 11);
    }
    else {
        _28878 = binary_op(EQUALS, _28877, 11);
    }
    _28877 = NOVALUE;
    if (IS_ATOM_INT(_28878)) {
        if (_28878 != 0) {
            goto L2; // [25] 46
        }
    }
    else {
        if (DBL_PTR(_28878)->dbl != 0.0) {
            goto L2; // [25] 46
        }
    }
    _2 = (object)SEQ_PTR(_tok_57411);
    _28880 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_28880)) {
        _28881 = (_28880 == 10);
    }
    else {
        _28881 = binary_op(EQUALS, _28880, 10);
    }
    _28880 = NOVALUE;
    if (_28881 <= 0) {
        if (_28881 == 0) {
            DeRef(_28881);
            _28881 = NOVALUE;
            goto L3; // [42] 71
        }
        else {
            if (!IS_ATOM_INT(_28881) && DBL_PTR(_28881)->dbl == 0.0){
                DeRef(_28881);
                _28881 = NOVALUE;
                goto L3; // [42] 71
            }
            DeRef(_28881);
            _28881 = NOVALUE;
        }
    }
    DeRef(_28881);
    _28881 = NOVALUE;
L2: 

    /** parser.e:1400			id = tok[T_ID]*/
    _2 = (object)SEQ_PTR(_tok_57411);
    _id_57412 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_id_57412)){
        _id_57412 = (object)DBL_PTR(_id_57412)->dbl;
    }

    /** parser.e:1401			tok = Term()*/
    _0 = _tok_57411;
    _tok_57411 = _45Term();
    DeRef(_0);

    /** parser.e:1402			emit_op(id)*/
    _47emit_op(_id_57412);

    /** parser.e:1403		end while*/
    goto L1; // [68] 13
L3: 

    /** parser.e:1404		return tok*/
    DeRef(_28878);
    _28878 = NOVALUE;
    return _tok_57411;
    ;
}


object _45cexpr()
{
    object _tok_57431 = NOVALUE;
    object _concat_count_57432 = NOVALUE;
    object _28885 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:1410		integer concat_count*/

    /** parser.e:1412		tok = aexpr()*/
    _0 = _tok_57431;
    _tok_57431 = _45aexpr();
    DeRef(_0);

    /** parser.e:1413		concat_count = 0*/
    _concat_count_57432 = 0;

    /** parser.e:1414		while tok[T_ID] = reserved:CONCAT do*/
L1: 
    _2 = (object)SEQ_PTR(_tok_57431);
    _28885 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28885, 15)){
        _28885 = NOVALUE;
        goto L2; // [24] 44
    }
    _28885 = NOVALUE;

    /** parser.e:1415			tok = aexpr()*/
    _0 = _tok_57431;
    _tok_57431 = _45aexpr();
    DeRef(_0);

    /** parser.e:1416			concat_count += 1*/
    _concat_count_57432 = _concat_count_57432 + 1;

    /** parser.e:1417		end while*/
    goto L1; // [41] 18
L2: 

    /** parser.e:1419		if concat_count = 1 then*/
    if (_concat_count_57432 != 1)
    goto L3; // [46] 58

    /** parser.e:1420			emit_op( reserved:CONCAT )*/
    _47emit_op(15);
    goto L4; // [55] 81
L3: 

    /** parser.e:1422		elsif concat_count > 1 then*/
    if (_concat_count_57432 <= 1)
    goto L5; // [60] 80

    /** parser.e:1423			op_info1 = concat_count+1*/
    _47op_info1_51364 = _concat_count_57432 + 1;

    /** parser.e:1424			emit_op(CONCAT_N)*/
    _47emit_op(157);
L5: 
L4: 

    /** parser.e:1427		return tok*/
    return _tok_57431;
    ;
}


object _45rexpr()
{
    object _tok_57452 = NOVALUE;
    object _id_57453 = NOVALUE;
    object _28897 = NOVALUE;
    object _28896 = NOVALUE;
    object _28895 = NOVALUE;
    object _28894 = NOVALUE;
    object _28893 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:1433		integer id*/

    /** parser.e:1435		tok = cexpr()*/
    _0 = _tok_57452;
    _tok_57452 = _45cexpr();
    DeRef(_0);

    /** parser.e:1436		while tok[T_ID] <= GREATER and tok[T_ID] >= LESS do*/
L1: 
    _2 = (object)SEQ_PTR(_tok_57452);
    _28893 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_28893)) {
        _28894 = (_28893 <= 6);
    }
    else {
        _28894 = binary_op(LESSEQ, _28893, 6);
    }
    _28893 = NOVALUE;
    if (IS_ATOM_INT(_28894)) {
        if (_28894 == 0) {
            goto L2; // [25] 70
        }
    }
    else {
        if (DBL_PTR(_28894)->dbl == 0.0) {
            goto L2; // [25] 70
        }
    }
    _2 = (object)SEQ_PTR(_tok_57452);
    _28896 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_28896)) {
        _28897 = (_28896 >= 1);
    }
    else {
        _28897 = binary_op(GREATEREQ, _28896, 1);
    }
    _28896 = NOVALUE;
    if (_28897 <= 0) {
        if (_28897 == 0) {
            DeRef(_28897);
            _28897 = NOVALUE;
            goto L2; // [42] 70
        }
        else {
            if (!IS_ATOM_INT(_28897) && DBL_PTR(_28897)->dbl == 0.0){
                DeRef(_28897);
                _28897 = NOVALUE;
                goto L2; // [42] 70
            }
            DeRef(_28897);
            _28897 = NOVALUE;
        }
    }
    DeRef(_28897);
    _28897 = NOVALUE;

    /** parser.e:1437			id = tok[T_ID]*/
    _2 = (object)SEQ_PTR(_tok_57452);
    _id_57453 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_id_57453)){
        _id_57453 = (object)DBL_PTR(_id_57453)->dbl;
    }

    /** parser.e:1438			tok = cexpr()*/
    _0 = _tok_57452;
    _tok_57452 = _45cexpr();
    DeRef(_0);

    /** parser.e:1439			emit_op(id)*/
    _47emit_op(_id_57453);

    /** parser.e:1440		end while*/
    goto L1; // [67] 13
L2: 

    /** parser.e:1441		return tok*/
    DeRef(_28894);
    _28894 = NOVALUE;
    return _tok_57452;
    ;
}


void _45Expr()
{
    object _tok_57479 = NOVALUE;
    object _id_57480 = NOVALUE;
    object _patch_57481 = NOVALUE;
    object _28920 = NOVALUE;
    object _28918 = NOVALUE;
    object _28917 = NOVALUE;
    object _28915 = NOVALUE;
    object _28914 = NOVALUE;
    object _28913 = NOVALUE;
    object _28912 = NOVALUE;
    object _28911 = NOVALUE;
    object _28905 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:1451		integer id*/

    /** parser.e:1452		integer patch*/

    /** parser.e:1454		ExprLine = ThisLine*/
    Ref(_50ThisLine_49594);
    DeRef(_45ExprLine_57474);
    _45ExprLine_57474 = _50ThisLine_49594;

    /** parser.e:1455		expr_bp = bp*/
    _45expr_bp_57475 = _50bp_49598;

    /** parser.e:1456		id = -1*/
    _id_57480 = -1;

    /** parser.e:1457		patch = 0*/
    _patch_57481 = 0;

    /** parser.e:1458		while TRUE do*/
L1: 
    if (_13TRUE_447 == 0)
    {
        goto L2; // [40] 300
    }
    else{
    }

    /** parser.e:1459			if id != -1 then*/
    if (_id_57480 == -1)
    goto L3; // [45] 116

    /** parser.e:1460				if id != XOR then*/
    if (_id_57480 == 152)
    goto L4; // [53] 115

    /** parser.e:1461					if short_circuit > 0 then*/
    if (_45short_circuit_55356 <= 0)
    goto L5; // [61] 114

    /** parser.e:1462						if id = OR then*/
    if (_id_57480 != 9)
    goto L6; // [69] 83

    /** parser.e:1463							emit_op(SC1_OR)*/
    _47emit_op(143);
    goto L7; // [80] 91
L6: 

    /** parser.e:1465							emit_op(SC1_AND)*/
    _47emit_op(141);
L7: 

    /** parser.e:1467						patch = length(Code)+1*/
    if (IS_SEQUENCE(_36Code_21859)){
            _28905 = SEQ_PTR(_36Code_21859)->length;
    }
    else {
        _28905 = 1;
    }
    _patch_57481 = _28905 + 1;
    _28905 = NOVALUE;

    /** parser.e:1468						emit_forward_addr()*/
    _45emit_forward_addr();

    /** parser.e:1469						short_circuit_B = TRUE*/
    _45short_circuit_B_55358 = _13TRUE_447;
L5: 
L4: 
L3: 

    /** parser.e:1474			tok = rexpr()*/
    _0 = _tok_57479;
    _tok_57479 = _45rexpr();
    DeRef(_0);

    /** parser.e:1476			if id != -1 then*/
    if (_id_57480 == -1)
    goto L8; // [123] 268

    /** parser.e:1477				if id != XOR then*/
    if (_id_57480 == 152)
    goto L9; // [131] 261

    /** parser.e:1478					if short_circuit > 0 then*/
    if (_45short_circuit_55356 <= 0)
    goto LA; // [139] 252

    /** parser.e:1479						if tok[T_ID] != THEN and tok[T_ID] != DO then*/
    _2 = (object)SEQ_PTR(_tok_57479);
    _28911 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_28911)) {
        _28912 = (_28911 != 410);
    }
    else {
        _28912 = binary_op(NOTEQ, _28911, 410);
    }
    _28911 = NOVALUE;
    if (IS_ATOM_INT(_28912)) {
        if (_28912 == 0) {
            goto LB; // [157] 206
        }
    }
    else {
        if (DBL_PTR(_28912)->dbl == 0.0) {
            goto LB; // [157] 206
        }
    }
    _2 = (object)SEQ_PTR(_tok_57479);
    _28914 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_28914)) {
        _28915 = (_28914 != 411);
    }
    else {
        _28915 = binary_op(NOTEQ, _28914, 411);
    }
    _28914 = NOVALUE;
    if (_28915 == 0) {
        DeRef(_28915);
        _28915 = NOVALUE;
        goto LB; // [174] 206
    }
    else {
        if (!IS_ATOM_INT(_28915) && DBL_PTR(_28915)->dbl == 0.0){
            DeRef(_28915);
            _28915 = NOVALUE;
            goto LB; // [174] 206
        }
        DeRef(_28915);
        _28915 = NOVALUE;
    }
    DeRef(_28915);
    _28915 = NOVALUE;

    /** parser.e:1480							if id = OR then*/
    if (_id_57480 != 9)
    goto LC; // [181] 195

    /** parser.e:1481								emit_op(SC2_OR)*/
    _47emit_op(144);
    goto LD; // [192] 219
LC: 

    /** parser.e:1483								emit_op(SC2_AND)*/
    _47emit_op(142);
    goto LD; // [203] 219
LB: 

    /** parser.e:1486							SC1_type = id -- if/while/elsif must patch*/
    _45SC1_type_55361 = _id_57480;

    /** parser.e:1487							emit_op(SC2_NULL)*/
    _47emit_op(145);
LD: 

    /** parser.e:1489						if TRANSLATE then*/
    if (_36TRANSLATE_21369 == 0)
    {
        goto LE; // [223] 234
    }
    else{
    }

    /** parser.e:1490							emit_op(NOP1)   -- to get label here*/
    _47emit_op(159);
LE: 

    /** parser.e:1492						backpatch(patch, length(Code)+1)*/
    if (IS_SEQUENCE(_36Code_21859)){
            _28917 = SEQ_PTR(_36Code_21859)->length;
    }
    else {
        _28917 = 1;
    }
    _28918 = _28917 + 1;
    _28917 = NOVALUE;
    _47backpatch(_patch_57481, _28918);
    _28918 = NOVALUE;
    goto LF; // [249] 267
LA: 

    /** parser.e:1494						emit_op(id)*/
    _47emit_op(_id_57480);
    goto LF; // [258] 267
L9: 

    /** parser.e:1497					emit_op(id)*/
    _47emit_op(_id_57480);
LF: 
L8: 

    /** parser.e:1500			id = tok[T_ID]*/
    _2 = (object)SEQ_PTR(_tok_57479);
    _id_57480 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_id_57480)){
        _id_57480 = (object)DBL_PTR(_id_57480)->dbl;
    }

    /** parser.e:1501			if not find(id, boolOps) then*/
    _28920 = find_from(_id_57480, _45boolOps_57469, 1);
    if (_28920 != 0)
    goto L1; // [287] 38
    _28920 = NOVALUE;

    /** parser.e:1502				exit*/
    goto L2; // [292] 300

    /** parser.e:1504		end while*/
    goto L1; // [297] 38
L2: 

    /** parser.e:1505		putback(tok)*/
    Ref(_tok_57479);
    _45putback(_tok_57479);

    /** parser.e:1506		SC1_patch = patch -- extra line*/
    _45SC1_patch_55360 = _patch_57481;

    /** parser.e:1507	end procedure*/
    DeRef(_tok_57479);
    DeRef(_28912);
    _28912 = NOVALUE;
    return;
    ;
}


void _45TypeCheck(object _var_57556)
{
    object _which_type_57557 = NOVALUE;
    object _ref_57567 = NOVALUE;
    object _ref_57600 = NOVALUE;
    object _28976 = NOVALUE;
    object _28975 = NOVALUE;
    object _28974 = NOVALUE;
    object _28973 = NOVALUE;
    object _28972 = NOVALUE;
    object _28970 = NOVALUE;
    object _28969 = NOVALUE;
    object _28968 = NOVALUE;
    object _28967 = NOVALUE;
    object _28966 = NOVALUE;
    object _28965 = NOVALUE;
    object _28963 = NOVALUE;
    object _28962 = NOVALUE;
    object _28959 = NOVALUE;
    object _28958 = NOVALUE;
    object _28957 = NOVALUE;
    object _28956 = NOVALUE;
    object _28951 = NOVALUE;
    object _28950 = NOVALUE;
    object _28946 = NOVALUE;
    object _28944 = NOVALUE;
    object _28943 = NOVALUE;
    object _28942 = NOVALUE;
    object _28940 = NOVALUE;
    object _28939 = NOVALUE;
    object _28938 = NOVALUE;
    object _28937 = NOVALUE;
    object _28936 = NOVALUE;
    object _28935 = NOVALUE;
    object _28932 = NOVALUE;
    object _28930 = NOVALUE;
    object _28928 = NOVALUE;
    object _28927 = NOVALUE;
    object _28926 = NOVALUE;
    object _28924 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_var_57556)) {
        _1 = (object)(DBL_PTR(_var_57556)->dbl);
        DeRefDS(_var_57556);
        _var_57556 = _1;
    }

    /** parser.e:1515		if var < 0 or SymTab[var][S_SCOPE] = SC_UNDEFINED then*/
    _28924 = (_var_57556 < 0);
    if (_28924 != 0) {
        goto L1; // [9] 36
    }
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _28926 = (object)*(((s1_ptr)_2)->base + _var_57556);
    _2 = (object)SEQ_PTR(_28926);
    _28927 = (object)*(((s1_ptr)_2)->base + 4);
    _28926 = NOVALUE;
    if (IS_ATOM_INT(_28927)) {
        _28928 = (_28927 == 9);
    }
    else {
        _28928 = binary_op(EQUALS, _28927, 9);
    }
    _28927 = NOVALUE;
    if (_28928 == 0) {
        DeRef(_28928);
        _28928 = NOVALUE;
        goto L2; // [32] 76
    }
    else {
        if (!IS_ATOM_INT(_28928) && DBL_PTR(_28928)->dbl == 0.0){
            DeRef(_28928);
            _28928 = NOVALUE;
            goto L2; // [32] 76
        }
        DeRef(_28928);
        _28928 = NOVALUE;
    }
    DeRef(_28928);
    _28928 = NOVALUE;
L1: 

    /** parser.e:1517			integer ref = new_forward_reference( TYPE_CHECK, var, TYPE_CHECK_FORWARD )*/
    _ref_57567 = _44new_forward_reference(65, _var_57556, 197);
    if (!IS_ATOM_INT(_ref_57567)) {
        _1 = (object)(DBL_PTR(_ref_57567)->dbl);
        DeRefDS(_ref_57567);
        _ref_57567 = _1;
    }

    /** parser.e:1518			Code &= { TYPE_CHECK_FORWARD, var, OpTypeCheck }*/
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 197;
    ((intptr_t*)_2)[2] = _var_57556;
    ((intptr_t*)_2)[3] = _36OpTypeCheck_21841;
    _28930 = MAKE_SEQ(_1);
    Concat((object_ptr)&_36Code_21859, _36Code_21859, _28930);
    DeRefDS(_28930);
    _28930 = NOVALUE;

    /** parser.e:1519			return*/
    DeRef(_28924);
    _28924 = NOVALUE;
    return;
L2: 

    /** parser.e:1522		which_type = SymTab[var][S_VTYPE]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _28932 = (object)*(((s1_ptr)_2)->base + _var_57556);
    _2 = (object)SEQ_PTR(_28932);
    _which_type_57557 = (object)*(((s1_ptr)_2)->base + 15);
    if (!IS_ATOM_INT(_which_type_57557)){
        _which_type_57557 = (object)DBL_PTR(_which_type_57557)->dbl;
    }
    _28932 = NOVALUE;

    /** parser.e:1523		if which_type = 0 then*/
    if (_which_type_57557 != 0)
    goto L3; // [96] 106

    /** parser.e:1524			return	-- Not a typed identifier.*/
    DeRef(_28924);
    _28924 = NOVALUE;
    return;
L3: 

    /** parser.e:1526		if which_type > 0 and length(SymTab[which_type]) < S_TOKEN then*/
    _28935 = (_which_type_57557 > 0);
    if (_28935 == 0) {
        goto L4; // [112] 141
    }
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _28937 = (object)*(((s1_ptr)_2)->base + _which_type_57557);
    if (IS_SEQUENCE(_28937)){
            _28938 = SEQ_PTR(_28937)->length;
    }
    else {
        _28938 = 1;
    }
    _28937 = NOVALUE;
    if (IS_ATOM_INT(_36S_TOKEN_21409)) {
        _28939 = (_28938 < _36S_TOKEN_21409);
    }
    else {
        _28939 = binary_op(LESS, _28938, _36S_TOKEN_21409);
    }
    _28938 = NOVALUE;
    if (_28939 == 0) {
        DeRef(_28939);
        _28939 = NOVALUE;
        goto L4; // [132] 141
    }
    else {
        if (!IS_ATOM_INT(_28939) && DBL_PTR(_28939)->dbl == 0.0){
            DeRef(_28939);
            _28939 = NOVALUE;
            goto L4; // [132] 141
        }
        DeRef(_28939);
        _28939 = NOVALUE;
    }
    DeRef(_28939);
    _28939 = NOVALUE;

    /** parser.e:1527			return	-- Not a typed identifier.*/
    _28937 = NOVALUE;
    DeRef(_28935);
    _28935 = NOVALUE;
    DeRef(_28924);
    _28924 = NOVALUE;
    return;
L4: 

    /** parser.e:1530		if which_type < 0 or SymTab[which_type][S_TOKEN] = VARIABLE  then*/
    _28940 = (_which_type_57557 < 0);
    if (_28940 != 0) {
        goto L5; // [147] 174
    }
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _28942 = (object)*(((s1_ptr)_2)->base + _which_type_57557);
    _2 = (object)SEQ_PTR(_28942);
    if (!IS_ATOM_INT(_36S_TOKEN_21409)){
        _28943 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21409)->dbl));
    }
    else{
        _28943 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21409);
    }
    _28942 = NOVALUE;
    if (IS_ATOM_INT(_28943)) {
        _28944 = (_28943 == -100);
    }
    else {
        _28944 = binary_op(EQUALS, _28943, -100);
    }
    _28943 = NOVALUE;
    if (_28944 == 0) {
        DeRef(_28944);
        _28944 = NOVALUE;
        goto L6; // [170] 214
    }
    else {
        if (!IS_ATOM_INT(_28944) && DBL_PTR(_28944)->dbl == 0.0){
            DeRef(_28944);
            _28944 = NOVALUE;
            goto L6; // [170] 214
        }
        DeRef(_28944);
        _28944 = NOVALUE;
    }
    DeRef(_28944);
    _28944 = NOVALUE;
L5: 

    /** parser.e:1531			integer ref = new_forward_reference( TYPE_CHECK, which_type, TYPE )*/
    _ref_57600 = _44new_forward_reference(65, _which_type_57557, 504);
    if (!IS_ATOM_INT(_ref_57600)) {
        _1 = (object)(DBL_PTR(_ref_57600)->dbl);
        DeRefDS(_ref_57600);
        _ref_57600 = _1;
    }

    /** parser.e:1532			Code &= { TYPE_CHECK_FORWARD, var, OpTypeCheck }*/
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 197;
    ((intptr_t*)_2)[2] = _var_57556;
    ((intptr_t*)_2)[3] = _36OpTypeCheck_21841;
    _28946 = MAKE_SEQ(_1);
    Concat((object_ptr)&_36Code_21859, _36Code_21859, _28946);
    DeRefDS(_28946);
    _28946 = NOVALUE;

    /** parser.e:1534			return*/
    _28937 = NOVALUE;
    DeRef(_28940);
    _28940 = NOVALUE;
    DeRef(_28935);
    _28935 = NOVALUE;
    DeRef(_28924);
    _28924 = NOVALUE;
    return;
L6: 

    /** parser.e:1537		if TRANSLATE then*/
    if (_36TRANSLATE_21369 == 0)
    {
        goto L7; // [220] 317
    }
    else{
    }

    /** parser.e:1538			if OpTypeCheck then*/
    if (_36OpTypeCheck_21841 == 0)
    {
        goto L8; // [227] 481
    }
    else{
    }

    /** parser.e:1539				switch which_type do*/
    if( _45_57614_cases == 0 ){
        _45_57614_cases = 1;
        SEQ_PTR( _28948 )->base[1] = _54object_type_47136;
        SEQ_PTR( _28948 )->base[2] = _54sequence_type_47140;
        SEQ_PTR( _28948 )->base[3] = _54atom_type_47138;
        SEQ_PTR( _28948 )->base[4] = _54integer_type_47142;
    }
    _1 = find(_which_type_57557, _28948);
    switch ( _1 ){ 

        /** parser.e:1540					case object_type, sequence_type, atom_type then*/
        case 1:
        case 2:
        case 3:

        /** parser.e:1542					case integer_type then*/
        goto L8; // [247] 481
        case 4:

        /** parser.e:1544						op_info1 = var*/
        _47op_info1_51364 = _var_57556;

        /** parser.e:1545						emit_op(INTEGER_CHECK)*/
        _47emit_op(96);
        goto L8; // [265] 481

        /** parser.e:1546					case else*/
        case 0:

        /** parser.e:1547						if SymTab[which_type][S_EFFECT] then*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _28950 = (object)*(((s1_ptr)_2)->base + _which_type_57557);
        _2 = (object)SEQ_PTR(_28950);
        _28951 = (object)*(((s1_ptr)_2)->base + 23);
        _28950 = NOVALUE;
        if (_28951 == 0) {
            _28951 = NOVALUE;
            goto L9; // [285] 312
        }
        else {
            if (!IS_ATOM_INT(_28951) && DBL_PTR(_28951)->dbl == 0.0){
                _28951 = NOVALUE;
                goto L9; // [285] 312
            }
            _28951 = NOVALUE;
        }
        _28951 = NOVALUE;

        /** parser.e:1549							emit_opnd(var)*/
        _47emit_opnd(_var_57556);

        /** parser.e:1550							op_info1 = which_type*/
        _47op_info1_51364 = _which_type_57557;

        /** parser.e:1552							emit_or_inline()*/
        _67emit_or_inline();

        /** parser.e:1553							emit_op(TYPE_CHECK)*/
        _47emit_op(65);
L9: 
    ;}    goto L8; // [314] 481
L7: 

    /** parser.e:1559			if OpTypeCheck then*/
    if (_36OpTypeCheck_21841 == 0)
    {
        goto LA; // [321] 480
    }
    else{
    }

    /** parser.e:1560				if which_type != object_type then*/
    if (_which_type_57557 == _54object_type_47136)
    goto LB; // [328] 479

    /** parser.e:1561					if which_type = integer_type then*/
    if (_which_type_57557 != _54integer_type_47142)
    goto LC; // [336] 357

    /** parser.e:1562							op_info1 = var*/
    _47op_info1_51364 = _var_57556;

    /** parser.e:1563							emit_op(INTEGER_CHECK)*/
    _47emit_op(96);
    goto LD; // [354] 478
LC: 

    /** parser.e:1565					elsif which_type = sequence_type then*/
    if (_which_type_57557 != _54sequence_type_47140)
    goto LE; // [361] 382

    /** parser.e:1566							op_info1 = var*/
    _47op_info1_51364 = _var_57556;

    /** parser.e:1567							emit_op(SEQUENCE_CHECK)*/
    _47emit_op(97);
    goto LD; // [379] 478
LE: 

    /** parser.e:1569					elsif which_type = atom_type then*/
    if (_which_type_57557 != _54atom_type_47138)
    goto LF; // [386] 407

    /** parser.e:1570							op_info1 = var*/
    _47op_info1_51364 = _var_57556;

    /** parser.e:1571							emit_op(ATOM_CHECK)*/
    _47emit_op(101);
    goto LD; // [404] 478
LF: 

    /** parser.e:1575							if SymTab[SymTab[which_type][S_NEXT]][S_VTYPE] =*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _28956 = (object)*(((s1_ptr)_2)->base + _which_type_57557);
    _2 = (object)SEQ_PTR(_28956);
    _28957 = (object)*(((s1_ptr)_2)->base + 2);
    _28956 = NOVALUE;
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!IS_ATOM_INT(_28957)){
        _28958 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_28957)->dbl));
    }
    else{
        _28958 = (object)*(((s1_ptr)_2)->base + _28957);
    }
    _2 = (object)SEQ_PTR(_28958);
    _28959 = (object)*(((s1_ptr)_2)->base + 15);
    _28958 = NOVALUE;
    if (binary_op_a(NOTEQ, _28959, _54integer_type_47142)){
        _28959 = NOVALUE;
        goto L10; // [435] 454
    }
    _28959 = NOVALUE;

    /** parser.e:1577								op_info1 = var*/
    _47op_info1_51364 = _var_57556;

    /** parser.e:1578								emit_op(INTEGER_CHECK) -- need integer conversion*/
    _47emit_op(96);
L10: 

    /** parser.e:1580							emit_opnd(var)*/
    _47emit_opnd(_var_57556);

    /** parser.e:1581							op_info1 = which_type*/
    _47op_info1_51364 = _which_type_57557;

    /** parser.e:1582							emit_or_inline()*/
    _67emit_or_inline();

    /** parser.e:1584							emit_op(TYPE_CHECK)*/
    _47emit_op(65);
LD: 
LB: 
LA: 
L8: 

    /** parser.e:1590		if TRANSLATE or not OpTypeCheck then*/
    if (_36TRANSLATE_21369 != 0) {
        goto L11; // [485] 499
    }
    _28962 = (_36OpTypeCheck_21841 == 0);
    if (_28962 == 0)
    {
        DeRef(_28962);
        _28962 = NOVALUE;
        goto L12; // [495] 620
    }
    else{
        DeRef(_28962);
        _28962 = NOVALUE;
    }
L11: 

    /** parser.e:1591			op_info1 = var*/
    _47op_info1_51364 = _var_57556;

    /** parser.e:1592			if which_type = sequence_type or*/
    _28963 = (_which_type_57557 == _54sequence_type_47140);
    if (_28963 != 0) {
        goto L13; // [514] 553
    }
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _28965 = (object)*(((s1_ptr)_2)->base + _which_type_57557);
    _2 = (object)SEQ_PTR(_28965);
    _28966 = (object)*(((s1_ptr)_2)->base + 2);
    _28965 = NOVALUE;
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!IS_ATOM_INT(_28966)){
        _28967 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_28966)->dbl));
    }
    else{
        _28967 = (object)*(((s1_ptr)_2)->base + _28966);
    }
    _2 = (object)SEQ_PTR(_28967);
    _28968 = (object)*(((s1_ptr)_2)->base + 15);
    _28967 = NOVALUE;
    if (IS_ATOM_INT(_28968)) {
        _28969 = (_28968 == _54sequence_type_47140);
    }
    else {
        _28969 = binary_op(EQUALS, _28968, _54sequence_type_47140);
    }
    _28968 = NOVALUE;
    if (_28969 == 0) {
        DeRef(_28969);
        _28969 = NOVALUE;
        goto L14; // [549] 563
    }
    else {
        if (!IS_ATOM_INT(_28969) && DBL_PTR(_28969)->dbl == 0.0){
            DeRef(_28969);
            _28969 = NOVALUE;
            goto L14; // [549] 563
        }
        DeRef(_28969);
        _28969 = NOVALUE;
    }
    DeRef(_28969);
    _28969 = NOVALUE;
L13: 

    /** parser.e:1595				emit_op(SEQUENCE_CHECK)*/
    _47emit_op(97);
    goto L15; // [560] 619
L14: 

    /** parser.e:1597			elsif which_type = integer_type or*/
    _28970 = (_which_type_57557 == _54integer_type_47142);
    if (_28970 != 0) {
        goto L16; // [571] 610
    }
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _28972 = (object)*(((s1_ptr)_2)->base + _which_type_57557);
    _2 = (object)SEQ_PTR(_28972);
    _28973 = (object)*(((s1_ptr)_2)->base + 2);
    _28972 = NOVALUE;
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!IS_ATOM_INT(_28973)){
        _28974 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_28973)->dbl));
    }
    else{
        _28974 = (object)*(((s1_ptr)_2)->base + _28973);
    }
    _2 = (object)SEQ_PTR(_28974);
    _28975 = (object)*(((s1_ptr)_2)->base + 15);
    _28974 = NOVALUE;
    if (IS_ATOM_INT(_28975)) {
        _28976 = (_28975 == _54integer_type_47142);
    }
    else {
        _28976 = binary_op(EQUALS, _28975, _54integer_type_47142);
    }
    _28975 = NOVALUE;
    if (_28976 == 0) {
        DeRef(_28976);
        _28976 = NOVALUE;
        goto L17; // [606] 618
    }
    else {
        if (!IS_ATOM_INT(_28976) && DBL_PTR(_28976)->dbl == 0.0){
            DeRef(_28976);
            _28976 = NOVALUE;
            goto L17; // [606] 618
        }
        DeRef(_28976);
        _28976 = NOVALUE;
    }
    DeRef(_28976);
    _28976 = NOVALUE;
L16: 

    /** parser.e:1600				emit_op(INTEGER_CHECK)*/
    _47emit_op(96);
L17: 
L15: 
L12: 

    /** parser.e:1603	end procedure*/
    _28937 = NOVALUE;
    DeRef(_28940);
    _28940 = NOVALUE;
    _28973 = NOVALUE;
    _28957 = NOVALUE;
    DeRef(_28935);
    _28935 = NOVALUE;
    DeRef(_28970);
    _28970 = NOVALUE;
    _28966 = NOVALUE;
    DeRef(_28963);
    _28963 = NOVALUE;
    DeRef(_28924);
    _28924 = NOVALUE;
    return;
    ;
}


void _45Assignment(object _left_var_57721)
{
    object _tok_57723 = NOVALUE;
    object _subs_57724 = NOVALUE;
    object _slice_57725 = NOVALUE;
    object _assign_op_57726 = NOVALUE;
    object _subs1_patch_57727 = NOVALUE;
    object _dangerous_57729 = NOVALUE;
    object _lname_57854 = NOVALUE;
    object _temp_len_57873 = NOVALUE;
    object _29073 = NOVALUE;
    object _29072 = NOVALUE;
    object _29071 = NOVALUE;
    object _29070 = NOVALUE;
    object _29069 = NOVALUE;
    object _29068 = NOVALUE;
    object _29067 = NOVALUE;
    object _29058 = NOVALUE;
    object _29057 = NOVALUE;
    object _29056 = NOVALUE;
    object _29055 = NOVALUE;
    object _29054 = NOVALUE;
    object _29053 = NOVALUE;
    object _29052 = NOVALUE;
    object _29051 = NOVALUE;
    object _29050 = NOVALUE;
    object _29049 = NOVALUE;
    object _29048 = NOVALUE;
    object _29047 = NOVALUE;
    object _29046 = NOVALUE;
    object _29045 = NOVALUE;
    object _29044 = NOVALUE;
    object _29042 = NOVALUE;
    object _29041 = NOVALUE;
    object _29040 = NOVALUE;
    object _29038 = NOVALUE;
    object _29033 = NOVALUE;
    object _29032 = NOVALUE;
    object _29029 = NOVALUE;
    object _29028 = NOVALUE;
    object _29026 = NOVALUE;
    object _29020 = NOVALUE;
    object _29015 = NOVALUE;
    object _29012 = NOVALUE;
    object _29009 = NOVALUE;
    object _29006 = NOVALUE;
    object _29005 = NOVALUE;
    object _29004 = NOVALUE;
    object _29002 = NOVALUE;
    object _29001 = NOVALUE;
    object _29000 = NOVALUE;
    object _28999 = NOVALUE;
    object _28998 = NOVALUE;
    object _28997 = NOVALUE;
    object _28995 = NOVALUE;
    object _28994 = NOVALUE;
    object _28993 = NOVALUE;
    object _28992 = NOVALUE;
    object _28990 = NOVALUE;
    object _28989 = NOVALUE;
    object _28988 = NOVALUE;
    object _28987 = NOVALUE;
    object _28986 = NOVALUE;
    object _28984 = NOVALUE;
    object _28983 = NOVALUE;
    object _28982 = NOVALUE;
    object _28979 = NOVALUE;
    object _28978 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:1608		integer subs, slice, assign_op, subs1_patch*/

    /** parser.e:1611		left_sym = left_var[T_SYM]*/
    _2 = (object)SEQ_PTR(_left_var_57721);
    _45left_sym_55397 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_45left_sym_55397)){
        _45left_sym_55397 = (object)DBL_PTR(_45left_sym_55397)->dbl;
    }

    /** parser.e:1612		if SymTab[left_sym][S_SCOPE] = SC_UNDEFINED then*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _28978 = (object)*(((s1_ptr)_2)->base + _45left_sym_55397);
    _2 = (object)SEQ_PTR(_28978);
    _28979 = (object)*(((s1_ptr)_2)->base + 4);
    _28978 = NOVALUE;
    if (binary_op_a(NOTEQ, _28979, 9)){
        _28979 = NOVALUE;
        goto L1; // [31] 54
    }
    _28979 = NOVALUE;

    /** parser.e:1613			Forward_var( left_var, ,ASSIGN )*/
    Ref(_left_var_57721);
    _45Forward_var(_left_var_57721, -1, 18);

    /** parser.e:1614			left_sym = Pop() -- pops off what forward var emitted, because it gets emitted later*/
    _0 = _47Pop();
    _45left_sym_55397 = _0;
    if (!IS_ATOM_INT(_45left_sym_55397)) {
        _1 = (object)(DBL_PTR(_45left_sym_55397)->dbl);
        DeRefDS(_45left_sym_55397);
        _45left_sym_55397 = _1;
    }
    goto L2; // [51] 271
L1: 

    /** parser.e:1616			UndefinedVar(left_sym)*/
    _45UndefinedVar(_45left_sym_55397);

    /** parser.e:1617			if SymTab[left_sym][S_SCOPE] = SC_LOOP_VAR or*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _28982 = (object)*(((s1_ptr)_2)->base + _45left_sym_55397);
    _2 = (object)SEQ_PTR(_28982);
    _28983 = (object)*(((s1_ptr)_2)->base + 4);
    _28982 = NOVALUE;
    if (IS_ATOM_INT(_28983)) {
        _28984 = (_28983 == 2);
    }
    else {
        _28984 = binary_op(EQUALS, _28983, 2);
    }
    _28983 = NOVALUE;
    if (IS_ATOM_INT(_28984)) {
        if (_28984 != 0) {
            goto L3; // [83] 112
        }
    }
    else {
        if (DBL_PTR(_28984)->dbl != 0.0) {
            goto L3; // [83] 112
        }
    }
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _28986 = (object)*(((s1_ptr)_2)->base + _45left_sym_55397);
    _2 = (object)SEQ_PTR(_28986);
    _28987 = (object)*(((s1_ptr)_2)->base + 4);
    _28986 = NOVALUE;
    if (IS_ATOM_INT(_28987)) {
        _28988 = (_28987 == 4);
    }
    else {
        _28988 = binary_op(EQUALS, _28987, 4);
    }
    _28987 = NOVALUE;
    if (_28988 == 0) {
        DeRef(_28988);
        _28988 = NOVALUE;
        goto L4; // [108] 124
    }
    else {
        if (!IS_ATOM_INT(_28988) && DBL_PTR(_28988)->dbl == 0.0){
            DeRef(_28988);
            _28988 = NOVALUE;
            goto L4; // [108] 124
        }
        DeRef(_28988);
        _28988 = NOVALUE;
    }
    DeRef(_28988);
    _28988 = NOVALUE;
L3: 

    /** parser.e:1619				CompileErr(MAY_NOT_ASSIGN_TO_A_FORLOOP_VARIABLE)*/
    RefDS(_22190);
    _50CompileErr(109, _22190, 0);
    goto L5; // [121] 233
L4: 

    /** parser.e:1621			elsif SymTab[left_sym][S_MODE] = M_CONSTANT then*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _28989 = (object)*(((s1_ptr)_2)->base + _45left_sym_55397);
    _2 = (object)SEQ_PTR(_28989);
    _28990 = (object)*(((s1_ptr)_2)->base + 3);
    _28989 = NOVALUE;
    if (binary_op_a(NOTEQ, _28990, 2)){
        _28990 = NOVALUE;
        goto L6; // [142] 158
    }
    _28990 = NOVALUE;

    /** parser.e:1622				CompileErr(MAY_NOT_CHANGE_THE_VALUE_OF_A_CONSTANT)*/
    RefDS(_22190);
    _50CompileErr(110, _22190, 0);
    goto L5; // [155] 233
L6: 

    /** parser.e:1624			elsif find(SymTab[left_sym][S_SCOPE], SCOPE_TYPES) then*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _28992 = (object)*(((s1_ptr)_2)->base + _45left_sym_55397);
    _2 = (object)SEQ_PTR(_28992);
    _28993 = (object)*(((s1_ptr)_2)->base + 4);
    _28992 = NOVALUE;
    _28994 = find_from(_28993, _45SCOPE_TYPES_55347, 1);
    _28993 = NOVALUE;
    if (_28994 == 0)
    {
        _28994 = NOVALUE;
        goto L7; // [181] 232
    }
    else{
        _28994 = NOVALUE;
    }

    /** parser.e:1626				SymTab[CurrentSub][S_EFFECT] = or_bits(SymTab[CurrentSub][S_EFFECT],*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_36CurrentSub_21775 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _28997 = (object)*(((s1_ptr)_2)->base + _36CurrentSub_21775);
    _2 = (object)SEQ_PTR(_28997);
    _28998 = (object)*(((s1_ptr)_2)->base + 23);
    _28997 = NOVALUE;
    _28999 = (_45left_sym_55397 % 29);
    _29000 = power(2, _28999);
    _28999 = NOVALUE;
    if (IS_ATOM_INT(_28998) && IS_ATOM_INT(_29000)) {
        {uintptr_t tu;
             tu = (uintptr_t)_28998 | (uintptr_t)_29000;
             _29001 = MAKE_UINT(tu);
        }
    }
    else {
        _29001 = binary_op(OR_BITS, _28998, _29000);
    }
    _28998 = NOVALUE;
    DeRef(_29000);
    _29000 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 23);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29001;
    if( _1 != _29001 ){
        DeRef(_1);
    }
    _29001 = NOVALUE;
    _28995 = NOVALUE;
L7: 
L5: 

    /** parser.e:1630			SymTab[left_sym][S_USAGE] = or_bits(SymTab[left_sym][S_USAGE], U_WRITTEN)*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_45left_sym_55397 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _29004 = (object)*(((s1_ptr)_2)->base + _45left_sym_55397);
    _2 = (object)SEQ_PTR(_29004);
    _29005 = (object)*(((s1_ptr)_2)->base + 5);
    _29004 = NOVALUE;
    if (IS_ATOM_INT(_29005)) {
        {uintptr_t tu;
             tu = (uintptr_t)_29005 | (uintptr_t)2;
             _29006 = MAKE_UINT(tu);
        }
    }
    else {
        _29006 = binary_op(OR_BITS, _29005, 2);
    }
    _29005 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29006;
    if( _1 != _29006 ){
        DeRef(_1);
    }
    _29006 = NOVALUE;
    _29002 = NOVALUE;
L2: 

    /** parser.e:1635		tok = next_token()*/
    _0 = _tok_57723;
    _tok_57723 = _45next_token();
    DeRef(_0);

    /** parser.e:1636		subs = 0*/
    _subs_57724 = 0;

    /** parser.e:1637		slice = FALSE*/
    _slice_57725 = _13FALSE_445;

    /** parser.e:1639		dangerous = FALSE*/
    _dangerous_57729 = _13FALSE_445;

    /** parser.e:1640		side_effect_calls = 0*/
    _45side_effect_calls_55393 = 0;

    /** parser.e:1643		emit_opnd(left_sym)*/
    _47emit_opnd(_45left_sym_55397);

    /** parser.e:1644		current_sequence = append(current_sequence, left_sym)*/
    Append(&_47current_sequence_51372, _47current_sequence_51372, _45left_sym_55397);

    /** parser.e:1646		while tok[T_ID] = LEFT_SQUARE do*/
L8: 
    _2 = (object)SEQ_PTR(_tok_57723);
    _29009 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29009, -28)){
        _29009 = NOVALUE;
        goto L9; // [334] 523
    }
    _29009 = NOVALUE;

    /** parser.e:1647			subs_depth += 1*/
    _45subs_depth_55398 = _45subs_depth_55398 + 1;

    /** parser.e:1648			if lhs_ptr then*/
    if (_47lhs_ptr_51374 == 0)
    {
        goto LA; // [350] 405
    }
    else{
    }

    /** parser.e:1650				current_sequence = remove( current_sequence, length( current_sequence ) )*/
    if (IS_SEQUENCE(_47current_sequence_51372)){
            _29012 = SEQ_PTR(_47current_sequence_51372)->length;
    }
    else {
        _29012 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_47current_sequence_51372);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_29012)) ? _29012 : (object)(DBL_PTR(_29012)->dbl);
        int stop = (IS_ATOM_INT(_29012)) ? _29012 : (object)(DBL_PTR(_29012)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_47current_sequence_51372), start, &_47current_sequence_51372 );
            }
            else Tail(SEQ_PTR(_47current_sequence_51372), stop+1, &_47current_sequence_51372);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_47current_sequence_51372), start, &_47current_sequence_51372);
        }
        else {
            assign_slice_seq = &assign_space;
            _47current_sequence_51372 = Remove_elements(start, stop, (SEQ_PTR(_47current_sequence_51372)->ref == 1));
        }
    }
    _29012 = NOVALUE;
    _29012 = NOVALUE;

    /** parser.e:1651				if subs = 1 then*/
    if (_subs_57724 != 1)
    goto LB; // [371] 396

    /** parser.e:1653					subs1_patch = length(Code)+1*/
    if (IS_SEQUENCE(_36Code_21859)){
            _29015 = SEQ_PTR(_36Code_21859)->length;
    }
    else {
        _29015 = 1;
    }
    _subs1_patch_57727 = _29015 + 1;
    _29015 = NOVALUE;

    /** parser.e:1654					emit_op(LHS_SUBS1) -- creates new current_sequence*/
    _47emit_op(161);
    goto LC; // [393] 404
LB: 

    /** parser.e:1657					emit_op(LHS_SUBS) -- adds to current_sequence*/
    _47emit_op(95);
LC: 
LA: 

    /** parser.e:1660			subs += 1*/
    _subs_57724 = _subs_57724 + 1;

    /** parser.e:1661			if subs = 1 then*/
    if (_subs_57724 != 1)
    goto LD; // [413] 428

    /** parser.e:1662				InitCheck(left_sym, TRUE)*/
    _45InitCheck(_45left_sym_55397, _13TRUE_447);
LD: 

    /** parser.e:1664			Expr()*/
    _45Expr();

    /** parser.e:1665			tok = next_token()*/
    _0 = _tok_57723;
    _tok_57723 = _45next_token();
    DeRef(_0);

    /** parser.e:1666			if tok[T_ID] = SLICE then*/
    _2 = (object)SEQ_PTR(_tok_57723);
    _29020 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29020, 513)){
        _29020 = NOVALUE;
        goto LE; // [447] 484
    }
    _29020 = NOVALUE;

    /** parser.e:1667				Expr()*/
    _45Expr();

    /** parser.e:1668				slice = TRUE*/
    _slice_57725 = _13TRUE_447;

    /** parser.e:1669				tok_match(RIGHT_SQUARE)*/
    _45tok_match(-29, 0);

    /** parser.e:1670				tok = next_token()*/
    _0 = _tok_57723;
    _tok_57723 = _45next_token();
    DeRef(_0);

    /** parser.e:1671				exit  -- no further subs or slices allowed*/
    goto L9; // [479] 523
    goto LF; // [481] 506
LE: 

    /** parser.e:1673				putback(tok)*/
    Ref(_tok_57723);
    _45putback(_tok_57723);

    /** parser.e:1674				tok_match(RIGHT_SQUARE)*/
    _45tok_match(-29, 0);

    /** parser.e:1675				subs_depth -= 1*/
    _45subs_depth_55398 = _45subs_depth_55398 - 1;
LF: 

    /** parser.e:1677			tok = next_token()*/
    _0 = _tok_57723;
    _tok_57723 = _45next_token();
    DeRef(_0);

    /** parser.e:1678			lhs_ptr = TRUE*/
    _47lhs_ptr_51374 = _13TRUE_447;

    /** parser.e:1679		end while*/
    goto L8; // [520] 326
L9: 

    /** parser.e:1681		lhs_ptr = FALSE*/
    _47lhs_ptr_51374 = _13FALSE_445;

    /** parser.e:1683		assign_op = tok[T_ID]*/
    _2 = (object)SEQ_PTR(_tok_57723);
    _assign_op_57726 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_assign_op_57726)){
        _assign_op_57726 = (object)DBL_PTR(_assign_op_57726)->dbl;
    }

    /** parser.e:1684		if not find(assign_op, ASSIGN_OPS) then*/
    _29026 = find_from(_assign_op_57726, _45ASSIGN_OPS_55339, 1);
    if (_29026 != 0)
    goto L10; // [549] 613
    _29026 = NOVALUE;

    /** parser.e:1685			sequence lname = SymTab[left_var[T_SYM]][S_NAME]*/
    _2 = (object)SEQ_PTR(_left_var_57721);
    _29028 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!IS_ATOM_INT(_29028)){
        _29029 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_29028)->dbl));
    }
    else{
        _29029 = (object)*(((s1_ptr)_2)->base + _29028);
    }
    DeRef(_lname_57854);
    _2 = (object)SEQ_PTR(_29029);
    if (!IS_ATOM_INT(_36S_NAME_21404)){
        _lname_57854 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21404)->dbl));
    }
    else{
        _lname_57854 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21404);
    }
    Ref(_lname_57854);
    _29029 = NOVALUE;

    /** parser.e:1686			if assign_op = COLON then*/
    if (_assign_op_57726 != -23)
    goto L11; // [578] 598

    /** parser.e:1687				CompileErr(SYNTAX_ERROR__UNKNOWN_NAMESPACE_1_USED, {lname})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_lname_57854);
    ((intptr_t*)_2)[1] = _lname_57854;
    _29032 = MAKE_SEQ(_1);
    _50CompileErr(133, _29032, 0);
    _29032 = NOVALUE;
    goto L12; // [595] 612
L11: 

    /** parser.e:1689				CompileErr(EXPECTED_TO_SEE_AN_ASSIGNMENT_AFTER_1_SUCH_AS__OR, {lname})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_lname_57854);
    ((intptr_t*)_2)[1] = _lname_57854;
    _29033 = MAKE_SEQ(_1);
    _50CompileErr(76, _29033, 0);
    _29033 = NOVALUE;
L12: 
L10: 
    DeRef(_lname_57854);
    _lname_57854 = NOVALUE;

    /** parser.e:1693		if subs = 0 then*/
    if (_subs_57724 != 0)
    goto L13; // [617] 745

    /** parser.e:1695			integer temp_len = length(Code)*/
    if (IS_SEQUENCE(_36Code_21859)){
            _temp_len_57873 = SEQ_PTR(_36Code_21859)->length;
    }
    else {
        _temp_len_57873 = 1;
    }

    /** parser.e:1696			if assign_op = EQUALS then*/
    if (_assign_op_57726 != 3)
    goto L14; // [632] 653

    /** parser.e:1697				Expr() -- RHS expression*/
    _45Expr();

    /** parser.e:1698				InitCheck(left_sym, FALSE)*/
    _45InitCheck(_45left_sym_55397, _13FALSE_445);
    goto L15; // [650] 726
L14: 

    /** parser.e:1700				InitCheck(left_sym, TRUE)*/
    _45InitCheck(_45left_sym_55397, _13TRUE_447);

    /** parser.e:1701				if left_sym > 0 then*/
    if (_45left_sym_55397 <= 0)
    goto L16; // [667] 709

    /** parser.e:1702					SymTab[left_sym][S_USAGE] = or_bits(SymTab[left_sym][S_USAGE], U_READ)*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_45left_sym_55397 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _29040 = (object)*(((s1_ptr)_2)->base + _45left_sym_55397);
    _2 = (object)SEQ_PTR(_29040);
    _29041 = (object)*(((s1_ptr)_2)->base + 5);
    _29040 = NOVALUE;
    if (IS_ATOM_INT(_29041)) {
        {uintptr_t tu;
             tu = (uintptr_t)_29041 | (uintptr_t)1;
             _29042 = MAKE_UINT(tu);
        }
    }
    else {
        _29042 = binary_op(OR_BITS, _29041, 1);
    }
    _29041 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29042;
    if( _1 != _29042 ){
        DeRef(_1);
    }
    _29042 = NOVALUE;
    _29038 = NOVALUE;
L16: 

    /** parser.e:1704				emit_opnd(left_sym)*/
    _47emit_opnd(_45left_sym_55397);

    /** parser.e:1705				Expr() -- RHS expression*/
    _45Expr();

    /** parser.e:1706				emit_assign_op(assign_op)*/
    _47emit_assign_op(_assign_op_57726);
L15: 

    /** parser.e:1708			emit_op(ASSIGN)*/
    _47emit_op(18);

    /** parser.e:1709			TypeCheck(left_sym)*/
    _45TypeCheck(_45left_sym_55397);
    goto L17; // [742] 1169
L13: 

    /** parser.e:1712			factors = 0*/
    _45factors_55394 = 0;

    /** parser.e:1713			lhs_subs_level = -1*/
    _45lhs_subs_level_55395 = -1;

    /** parser.e:1714			Expr() -- RHS expression*/
    _45Expr();

    /** parser.e:1716			if subs > 1 then*/
    if (_subs_57724 <= 1)
    goto L18; // [761] 900

    /** parser.e:1717				if left_sym < 0 or SymTab[left_sym][S_SCOPE] != SC_PRIVATE and*/
    _29044 = (_45left_sym_55397 < 0);
    if (_29044 != 0) {
        _29045 = 1;
        goto L19; // [773] 801
    }
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _29046 = (object)*(((s1_ptr)_2)->base + _45left_sym_55397);
    _2 = (object)SEQ_PTR(_29046);
    _29047 = (object)*(((s1_ptr)_2)->base + 4);
    _29046 = NOVALUE;
    if (IS_ATOM_INT(_29047)) {
        _29048 = (_29047 != 3);
    }
    else {
        _29048 = binary_op(NOTEQ, _29047, 3);
    }
    _29047 = NOVALUE;
    if (IS_ATOM_INT(_29048))
    _29045 = (_29048 != 0);
    else
    _29045 = DBL_PTR(_29048)->dbl != 0.0;
L19: 
    if (_29045 == 0) {
        goto L1A; // [801] 835
    }
    _29050 = (_45left_sym_55397 % 29);
    _29051 = power(2, _29050);
    _29050 = NOVALUE;
    if (IS_ATOM_INT(_29051)) {
        {uintptr_t tu;
             tu = (uintptr_t)_45side_effect_calls_55393 & (uintptr_t)_29051;
             _29052 = MAKE_UINT(tu);
        }
    }
    else {
        temp_d.dbl = (eudouble)_45side_effect_calls_55393;
        _29052 = Dand_bits(&temp_d, DBL_PTR(_29051));
    }
    DeRef(_29051);
    _29051 = NOVALUE;
    if (_29052 == 0) {
        DeRef(_29052);
        _29052 = NOVALUE;
        goto L1A; // [824] 835
    }
    else {
        if (!IS_ATOM_INT(_29052) && DBL_PTR(_29052)->dbl == 0.0){
            DeRef(_29052);
            _29052 = NOVALUE;
            goto L1A; // [824] 835
        }
        DeRef(_29052);
        _29052 = NOVALUE;
    }
    DeRef(_29052);
    _29052 = NOVALUE;

    /** parser.e:1722					dangerous = TRUE*/
    _dangerous_57729 = _13TRUE_447;
L1A: 

    /** parser.e:1725				if factors = 1 and*/
    _29053 = (_45factors_55394 == 1);
    if (_29053 == 0) {
        _29054 = 0;
        goto L1B; // [843] 857
    }
    _29055 = (_45lhs_subs_level_55395 >= 0);
    _29054 = (_29055 != 0);
L1B: 
    if (_29054 == 0) {
        goto L1C; // [857] 883
    }
    _29057 = _subs_57724 + _slice_57725;
    if ((object)((uintptr_t)_29057 + (uintptr_t)HIGH_BITS) >= 0){
        _29057 = NewDouble((eudouble)_29057);
    }
    if (IS_ATOM_INT(_29057)) {
        _29058 = (_45lhs_subs_level_55395 < _29057);
    }
    else {
        _29058 = ((eudouble)_45lhs_subs_level_55395 < DBL_PTR(_29057)->dbl);
    }
    DeRef(_29057);
    _29057 = NOVALUE;
    if (_29058 == 0)
    {
        DeRef(_29058);
        _29058 = NOVALUE;
        goto L1C; // [872] 883
    }
    else{
        DeRef(_29058);
        _29058 = NOVALUE;
    }

    /** parser.e:1729					dangerous = TRUE*/
    _dangerous_57729 = _13TRUE_447;
L1C: 

    /** parser.e:1732				if dangerous then*/
    if (_dangerous_57729 == 0)
    {
        goto L1D; // [885] 899
    }
    else{
    }

    /** parser.e:1738					backpatch(subs1_patch, LHS_SUBS1_COPY)*/
    _47backpatch(_subs1_patch_57727, 166);
L1D: 
L18: 

    /** parser.e:1742			if slice then*/
    if (_slice_57725 == 0)
    {
        goto L1E; // [902] 970
    }
    else{
    }

    /** parser.e:1743				if assign_op != EQUALS then*/
    if (_assign_op_57726 == 3)
    goto L1F; // [909] 943

    /** parser.e:1744					if subs = 1 then*/
    if (_subs_57724 != 1)
    goto L20; // [915] 929

    /** parser.e:1745						emit_op(ASSIGN_OP_SLICE)*/
    _47emit_op(150);
    goto L21; // [926] 937
L20: 

    /** parser.e:1747						emit_op(PASSIGN_OP_SLICE)*/
    _47emit_op(165);
L21: 

    /** parser.e:1749					emit_assign_op(assign_op)*/
    _47emit_assign_op(_assign_op_57726);
L1F: 

    /** parser.e:1751				if subs = 1 then*/
    if (_subs_57724 != 1)
    goto L22; // [945] 959

    /** parser.e:1752					emit_op(ASSIGN_SLICE)*/
    _47emit_op(45);
    goto L23; // [956] 1060
L22: 

    /** parser.e:1754					emit_op(PASSIGN_SLICE)*/
    _47emit_op(163);
    goto L23; // [967] 1060
L1E: 

    /** parser.e:1757				if assign_op = EQUALS then*/
    if (_assign_op_57726 != 3)
    goto L24; // [974] 1005

    /** parser.e:1758					if subs = 1 then*/
    if (_subs_57724 != 1)
    goto L25; // [980] 994

    /** parser.e:1759						emit_op(ASSIGN_SUBS)*/
    _47emit_op(16);
    goto L26; // [991] 1059
L25: 

    /** parser.e:1761						emit_op(PASSIGN_SUBS)*/
    _47emit_op(162);
    goto L26; // [1002] 1059
L24: 

    /** parser.e:1764					if subs = 1 then*/
    if (_subs_57724 != 1)
    goto L27; // [1007] 1021

    /** parser.e:1765						emit_op(ASSIGN_OP_SUBS)*/
    _47emit_op(149);
    goto L28; // [1018] 1029
L27: 

    /** parser.e:1767						emit_op(PASSIGN_OP_SUBS)*/
    _47emit_op(164);
L28: 

    /** parser.e:1769					emit_assign_op(assign_op)*/
    _47emit_assign_op(_assign_op_57726);

    /** parser.e:1770					if subs = 1 then*/
    if (_subs_57724 != 1)
    goto L29; // [1036] 1050

    /** parser.e:1771						emit_op(ASSIGN_SUBS2)*/
    _47emit_op(148);
    goto L2A; // [1047] 1058
L29: 

    /** parser.e:1773						emit_op(PASSIGN_SUBS)*/
    _47emit_op(162);
L2A: 
L26: 
L23: 

    /** parser.e:1778			if subs > 1 then*/
    if (_subs_57724 <= 1)
    goto L2B; // [1062] 1114

    /** parser.e:1779				if dangerous then*/
    if (_dangerous_57729 == 0)
    {
        goto L2C; // [1068] 1105
    }
    else{
    }

    /** parser.e:1781					emit_opnd(left_sym)*/
    _47emit_opnd(_45left_sym_55397);

    /** parser.e:1782					emit_opnd(lhs_subs1_copy_temp) -- will be freed*/
    _47emit_opnd(_47lhs_subs1_copy_temp_51377);

    /** parser.e:1783					emit_temp( lhs_subs1_copy_temp, NEW_REFERENCE )*/
    _47emit_temp(_47lhs_subs1_copy_temp_51377, 1);

    /** parser.e:1784					emit_op(ASSIGN)*/
    _47emit_op(18);
    goto L2D; // [1102] 1113
L2C: 

    /** parser.e:1787					TempFree(lhs_subs1_copy_temp)*/
    _47TempFree(_47lhs_subs1_copy_temp_51377);
L2D: 
L2B: 

    /** parser.e:1791			if OpTypeCheck and (left_sym < 0 or SymTab[left_sym][S_VTYPE] != sequence_type) then*/
    if (_36OpTypeCheck_21841 == 0) {
        goto L2E; // [1118] 1168
    }
    _29068 = (_45left_sym_55397 < 0);
    if (_29068 != 0) {
        DeRef(_29069);
        _29069 = 1;
        goto L2F; // [1128] 1156
    }
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _29070 = (object)*(((s1_ptr)_2)->base + _45left_sym_55397);
    _2 = (object)SEQ_PTR(_29070);
    _29071 = (object)*(((s1_ptr)_2)->base + 15);
    _29070 = NOVALUE;
    if (IS_ATOM_INT(_29071)) {
        _29072 = (_29071 != _54sequence_type_47140);
    }
    else {
        _29072 = binary_op(NOTEQ, _29071, _54sequence_type_47140);
    }
    _29071 = NOVALUE;
    if (IS_ATOM_INT(_29072))
    _29069 = (_29072 != 0);
    else
    _29069 = DBL_PTR(_29072)->dbl != 0.0;
L2F: 
    if (_29069 == 0)
    {
        _29069 = NOVALUE;
        goto L2E; // [1157] 1168
    }
    else{
        _29069 = NOVALUE;
    }

    /** parser.e:1792				TypeCheck(left_sym)*/
    _45TypeCheck(_45left_sym_55397);
L2E: 
L17: 

    /** parser.e:1796		current_sequence = remove( current_sequence, length( current_sequence ) )*/
    if (IS_SEQUENCE(_47current_sequence_51372)){
            _29073 = SEQ_PTR(_47current_sequence_51372)->length;
    }
    else {
        _29073 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_47current_sequence_51372);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_29073)) ? _29073 : (object)(DBL_PTR(_29073)->dbl);
        int stop = (IS_ATOM_INT(_29073)) ? _29073 : (object)(DBL_PTR(_29073)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_47current_sequence_51372), start, &_47current_sequence_51372 );
            }
            else Tail(SEQ_PTR(_47current_sequence_51372), stop+1, &_47current_sequence_51372);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_47current_sequence_51372), start, &_47current_sequence_51372);
        }
        else {
            assign_slice_seq = &assign_space;
            _47current_sequence_51372 = Remove_elements(start, stop, (SEQ_PTR(_47current_sequence_51372)->ref == 1));
        }
    }
    _29073 = NOVALUE;
    _29073 = NOVALUE;

    /** parser.e:1798		if not TRANSLATE then*/
    if (_36TRANSLATE_21369 != 0)
    goto L30; // [1189] 1215

    /** parser.e:1799			if OpTrace then*/
    if (_36OpTrace_21840 == 0)
    {
        goto L31; // [1196] 1214
    }
    else{
    }

    /** parser.e:1800				emit_op(DISPLAY_VAR)*/
    _47emit_op(87);

    /** parser.e:1801				emit_addr(left_sym)*/
    _47emit_addr(_45left_sym_55397);
L31: 
L30: 

    /** parser.e:1804	end procedure*/
    DeRef(_left_var_57721);
    DeRef(_tok_57723);
    DeRef(_29068);
    _29068 = NOVALUE;
    DeRef(_28984);
    _28984 = NOVALUE;
    DeRef(_29048);
    _29048 = NOVALUE;
    DeRef(_29072);
    _29072 = NOVALUE;
    _29028 = NOVALUE;
    DeRef(_29055);
    _29055 = NOVALUE;
    DeRef(_29044);
    _29044 = NOVALUE;
    DeRef(_29053);
    _29053 = NOVALUE;
    return;
    ;
}


void _45Multi_assign()
{
    object _lhs_syms_58013 = NOVALUE;
    object _lhs_list_58014 = NOVALUE;
    object _tok_58016 = NOVALUE;
    object _need_comma_58017 = NOVALUE;
    object _temp_sym_58079 = NOVALUE;
    object _temps_58082 = NOVALUE;
    object _len_58130 = NOVALUE;
    object _29132 = NOVALUE;
    object _29130 = NOVALUE;
    object _29128 = NOVALUE;
    object _29126 = NOVALUE;
    object _29125 = NOVALUE;
    object _29124 = NOVALUE;
    object _29123 = NOVALUE;
    object _29122 = NOVALUE;
    object _29121 = NOVALUE;
    object _29119 = NOVALUE;
    object _29118 = NOVALUE;
    object _29117 = NOVALUE;
    object _29116 = NOVALUE;
    object _29115 = NOVALUE;
    object _29113 = NOVALUE;
    object _29112 = NOVALUE;
    object _29111 = NOVALUE;
    object _29110 = NOVALUE;
    object _29109 = NOVALUE;
    object _29105 = NOVALUE;
    object _29104 = NOVALUE;
    object _29103 = NOVALUE;
    object _29102 = NOVALUE;
    object _29099 = NOVALUE;
    object _29098 = NOVALUE;
    object _29096 = NOVALUE;
    object _29095 = NOVALUE;
    object _29094 = NOVALUE;
    object _29092 = NOVALUE;
    object _29091 = NOVALUE;
    object _29090 = NOVALUE;
    object _29089 = NOVALUE;
    object _29087 = NOVALUE;
    object _29086 = NOVALUE;
    object _29085 = NOVALUE;
    object _29083 = NOVALUE;
    object _29082 = NOVALUE;
    object _29079 = NOVALUE;
    object _29076 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:1811		sequence lhs_syms = {}*/
    RefDS(_22190);
    DeRef(_lhs_syms_58013);
    _lhs_syms_58013 = _22190;

    /** parser.e:1812		sequence lhs_list = {} -- make sure we don't repeat anything*/
    RefDS(_22190);
    DeRef(_lhs_list_58014);
    _lhs_list_58014 = _22190;

    /** parser.e:1814		integer need_comma = 0*/
    _need_comma_58017 = 0;

    /** parser.e:1815		while tok[T_ID] != RIGHT_BRACE with entry do*/
    goto L1; // [22] 215
L2: 
    _2 = (object)SEQ_PTR(_tok_58016);
    _29076 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _29076, -25)){
        _29076 = NOVALUE;
        goto L3; // [35] 225
    }
    _29076 = NOVALUE;

    /** parser.e:1817			if need_comma then*/
    if (_need_comma_58017 == 0)
    {
        goto L4; // [41] 63
    }
    else{
    }

    /** parser.e:1818				putback( tok )*/
    Ref(_tok_58016);
    _45putback(_tok_58016);

    /** parser.e:1819				tok_match( COMMA )*/
    _45tok_match(-30, 0);

    /** parser.e:1820				tok = next_token()*/
    _0 = _tok_58016;
    _tok_58016 = _45next_token();
    DeRef(_0);
L4: 

    /** parser.e:1823			if tok[T_ID] = QUESTION_MARK then*/
    _2 = (object)SEQ_PTR(_tok_58016);
    _29079 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29079, -31)){
        _29079 = NOVALUE;
        goto L5; // [73] 86
    }
    _29079 = NOVALUE;

    /** parser.e:1825				lhs_syms &= 0*/
    Append(&_lhs_syms_58013, _lhs_syms_58013, 0);
    goto L6; // [83] 207
L5: 

    /** parser.e:1826			elsif tok[T_ID] = VARIABLE or tok[T_ID] = QUALIFIED_VARIABLE then*/
    _2 = (object)SEQ_PTR(_tok_58016);
    _29082 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_29082)) {
        _29083 = (_29082 == -100);
    }
    else {
        _29083 = binary_op(EQUALS, _29082, -100);
    }
    _29082 = NOVALUE;
    if (IS_ATOM_INT(_29083)) {
        if (_29083 != 0) {
            goto L7; // [100] 121
        }
    }
    else {
        if (DBL_PTR(_29083)->dbl != 0.0) {
            goto L7; // [100] 121
        }
    }
    _2 = (object)SEQ_PTR(_tok_58016);
    _29085 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_29085)) {
        _29086 = (_29085 == 512);
    }
    else {
        _29086 = binary_op(EQUALS, _29085, 512);
    }
    _29085 = NOVALUE;
    if (_29086 == 0) {
        DeRef(_29086);
        _29086 = NOVALUE;
        goto L8; // [117] 197
    }
    else {
        if (!IS_ATOM_INT(_29086) && DBL_PTR(_29086)->dbl == 0.0){
            DeRef(_29086);
            _29086 = NOVALUE;
            goto L8; // [117] 197
        }
        DeRef(_29086);
        _29086 = NOVALUE;
    }
    DeRef(_29086);
    _29086 = NOVALUE;
L7: 

    /** parser.e:1827				lhs_syms &= tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_58016);
    _29087 = (object)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_lhs_syms_58013) && IS_ATOM(_29087)) {
        Ref(_29087);
        Append(&_lhs_syms_58013, _lhs_syms_58013, _29087);
    }
    else if (IS_ATOM(_lhs_syms_58013) && IS_SEQUENCE(_29087)) {
    }
    else {
        Concat((object_ptr)&_lhs_syms_58013, _lhs_syms_58013, _29087);
    }
    _29087 = NOVALUE;

    /** parser.e:1828				if SymTab[lhs_syms[$]][S_SCOPE] = SC_UNDEFINED then*/
    if (IS_SEQUENCE(_lhs_syms_58013)){
            _29089 = SEQ_PTR(_lhs_syms_58013)->length;
    }
    else {
        _29089 = 1;
    }
    _2 = (object)SEQ_PTR(_lhs_syms_58013);
    _29090 = (object)*(((s1_ptr)_2)->base + _29089);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!IS_ATOM_INT(_29090)){
        _29091 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_29090)->dbl));
    }
    else{
        _29091 = (object)*(((s1_ptr)_2)->base + _29090);
    }
    _2 = (object)SEQ_PTR(_29091);
    _29092 = (object)*(((s1_ptr)_2)->base + 4);
    _29091 = NOVALUE;
    if (binary_op_a(NOTEQ, _29092, 9)){
        _29092 = NOVALUE;
        goto L9; // [156] 180
    }
    _29092 = NOVALUE;

    /** parser.e:1829					lhs_list = append( lhs_list, sym_name( lhs_syms[$] ) )*/
    if (IS_SEQUENCE(_lhs_syms_58013)){
            _29094 = SEQ_PTR(_lhs_syms_58013)->length;
    }
    else {
        _29094 = 1;
    }
    _2 = (object)SEQ_PTR(_lhs_syms_58013);
    _29095 = (object)*(((s1_ptr)_2)->base + _29094);
    Ref(_29095);
    _29096 = _54sym_name(_29095);
    _29095 = NOVALUE;
    Ref(_29096);
    Append(&_lhs_list_58014, _lhs_list_58014, _29096);
    DeRef(_29096);
    _29096 = NOVALUE;
    goto L6; // [177] 207
L9: 

    /** parser.e:1831					lhs_list &= lhs_syms[$]*/
    if (IS_SEQUENCE(_lhs_syms_58013)){
            _29098 = SEQ_PTR(_lhs_syms_58013)->length;
    }
    else {
        _29098 = 1;
    }
    _2 = (object)SEQ_PTR(_lhs_syms_58013);
    _29099 = (object)*(((s1_ptr)_2)->base + _29098);
    if (IS_SEQUENCE(_lhs_list_58014) && IS_ATOM(_29099)) {
        Ref(_29099);
        Append(&_lhs_list_58014, _lhs_list_58014, _29099);
    }
    else if (IS_ATOM(_lhs_list_58014) && IS_SEQUENCE(_29099)) {
    }
    else {
        Concat((object_ptr)&_lhs_list_58014, _lhs_list_58014, _29099);
    }
    _29099 = NOVALUE;
    goto L6; // [194] 207
L8: 

    /** parser.e:1834				CompileErr( A_VARIABLE_NAME_IS_EXPECTED_HERE)*/
    RefDS(_22190);
    _50CompileErr(24, _22190, 0);
L6: 

    /** parser.e:1837			need_comma = 1*/
    _need_comma_58017 = 1;

    /** parser.e:1838		entry*/
L1: 

    /** parser.e:1839			tok = next_token()*/
    _0 = _tok_58016;
    _tok_58016 = _45next_token();
    DeRef(_0);

    /** parser.e:1840		end while*/
    goto L2; // [222] 25
L3: 

    /** parser.e:1843		if length( lhs_list ) != length( remove_dups( sort( lhs_list ) ) ) then*/
    if (IS_SEQUENCE(_lhs_list_58014)){
            _29102 = SEQ_PTR(_lhs_list_58014)->length;
    }
    else {
        _29102 = 1;
    }
    RefDS(_lhs_list_58014);
    _29103 = _24sort(_lhs_list_58014, 1);
    _29104 = _23remove_dups(_29103, 2);
    _29103 = NOVALUE;
    if (IS_SEQUENCE(_29104)){
            _29105 = SEQ_PTR(_29104)->length;
    }
    else {
        _29105 = 1;
    }
    DeRef(_29104);
    _29104 = NOVALUE;
    if (_29102 == _29105)
    goto LA; // [243] 257

    /** parser.e:1844			CompileErr( DUPLICATE_MULTI_ASSIGN )*/
    RefDS(_22190);
    _50CompileErr(602, _22190, 0);
LA: 

    /** parser.e:1846		tok_match( EQUALS )*/
    _45tok_match(3, 0);

    /** parser.e:1849		Expr()*/
    _45Expr();

    /** parser.e:1851		symtab_index temp_sym = Pop()*/
    _temp_sym_58079 = _47Pop();
    if (!IS_ATOM_INT(_temp_sym_58079)) {
        _1 = (object)(DBL_PTR(_temp_sym_58079)->dbl);
        DeRefDS(_temp_sym_58079);
        _temp_sym_58079 = _1;
    }

    /** parser.e:1852		sequence temps = pop_temps()*/
    _0 = _temps_58082;
    _temps_58082 = _47pop_temps();
    DeRef(_0);

    /** parser.e:1853		if TRANSLATE then*/
    if (_36TRANSLATE_21369 == 0)
    {
        goto LB; // [287] 303
    }
    else{
    }

    /** parser.e:1854			emit_opnd( temp_sym )*/
    _47emit_opnd(_temp_sym_58079);

    /** parser.e:1855			emit_op( REF_TEMP )*/
    _47emit_op(207);
LB: 

    /** parser.e:1858		for i = 1 to length( lhs_syms ) do*/
    if (IS_SEQUENCE(_lhs_syms_58013)){
            _29109 = SEQ_PTR(_lhs_syms_58013)->length;
    }
    else {
        _29109 = 1;
    }
    {
        object _i_58091;
        _i_58091 = 1;
LC: 
        if (_i_58091 > _29109){
            goto LD; // [308] 512
        }

        /** parser.e:1859			if lhs_syms[i] then*/
        _2 = (object)SEQ_PTR(_lhs_syms_58013);
        _29110 = (object)*(((s1_ptr)_2)->base + _i_58091);
        if (_29110 == 0) {
            _29110 = NOVALUE;
            goto LE; // [321] 503
        }
        else {
            if (!IS_ATOM_INT(_29110) && DBL_PTR(_29110)->dbl == 0.0){
                _29110 = NOVALUE;
                goto LE; // [321] 503
            }
            _29110 = NOVALUE;
        }
        _29110 = NOVALUE;

        /** parser.e:1860				if SymTab[lhs_syms[i]][S_SCOPE] = SC_UNDEFINED then*/
        _2 = (object)SEQ_PTR(_lhs_syms_58013);
        _29111 = (object)*(((s1_ptr)_2)->base + _i_58091);
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        if (!IS_ATOM_INT(_29111)){
            _29112 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_29111)->dbl));
        }
        else{
            _29112 = (object)*(((s1_ptr)_2)->base + _29111);
        }
        _2 = (object)SEQ_PTR(_29112);
        _29113 = (object)*(((s1_ptr)_2)->base + 4);
        _29112 = NOVALUE;
        if (binary_op_a(NOTEQ, _29113, 9)){
            _29113 = NOVALUE;
            goto LF; // [344] 379
        }
        _29113 = NOVALUE;

        /** parser.e:1861					Forward_var( { VARIABLE, lhs_syms[i]}, ,ASSIGN )*/
        _2 = (object)SEQ_PTR(_lhs_syms_58013);
        _29115 = (object)*(((s1_ptr)_2)->base + _i_58091);
        Ref(_29115);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = -100;
        ((intptr_t *)_2)[2] = _29115;
        _29116 = MAKE_SEQ(_1);
        _29115 = NOVALUE;
        _45Forward_var(_29116, -1, 18);
        _29116 = NOVALUE;

        /** parser.e:1862					lhs_syms[i] = Pop()*/
        _29117 = _47Pop();
        _2 = (object)SEQ_PTR(_lhs_syms_58013);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _lhs_syms_58013 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_58091);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _29117;
        if( _1 != _29117 ){
            DeRef(_1);
        }
        _29117 = NOVALUE;
        goto L10; // [376] 421
LF: 

        /** parser.e:1864					SymTab[lhs_syms[i]][S_USAGE] = or_bits(SymTab[lhs_syms[i]][S_USAGE], U_WRITTEN)*/
        _2 = (object)SEQ_PTR(_lhs_syms_58013);
        _29118 = (object)*(((s1_ptr)_2)->base + _i_58091);
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37SymTab_15637 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_29118))
        _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_29118)->dbl));
        else
        _3 = (object)(_29118 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_lhs_syms_58013);
        _29121 = (object)*(((s1_ptr)_2)->base + _i_58091);
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        if (!IS_ATOM_INT(_29121)){
            _29122 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_29121)->dbl));
        }
        else{
            _29122 = (object)*(((s1_ptr)_2)->base + _29121);
        }
        _2 = (object)SEQ_PTR(_29122);
        _29123 = (object)*(((s1_ptr)_2)->base + 5);
        _29122 = NOVALUE;
        if (IS_ATOM_INT(_29123)) {
            {uintptr_t tu;
                 tu = (uintptr_t)_29123 | (uintptr_t)2;
                 _29124 = MAKE_UINT(tu);
            }
        }
        else {
            _29124 = binary_op(OR_BITS, _29123, 2);
        }
        _29123 = NOVALUE;
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 5);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _29124;
        if( _1 != _29124 ){
            DeRef(_1);
        }
        _29124 = NOVALUE;
        _29119 = NOVALUE;
L10: 

        /** parser.e:1867				emit_opnd( lhs_syms[i] )*/
        _2 = (object)SEQ_PTR(_lhs_syms_58013);
        _29125 = (object)*(((s1_ptr)_2)->base + _i_58091);
        Ref(_29125);
        _47emit_opnd(_29125);
        _29125 = NOVALUE;

        /** parser.e:1869				emit_opnd( temp_sym )*/
        _47emit_opnd(_temp_sym_58079);

        /** parser.e:1870				emit_opnd( NewIntSym( i ) )*/
        _29126 = _54NewIntSym(_i_58091);
        _47emit_opnd(_29126);
        _29126 = NOVALUE;

        /** parser.e:1871				emit_op( RHS_SUBS )*/
        _47emit_op(25);

        /** parser.e:1872				integer len = length( Code )*/
        if (IS_SEQUENCE(_36Code_21859)){
                _len_58130 = SEQ_PTR(_36Code_21859)->length;
        }
        else {
            _len_58130 = 1;
        }

        /** parser.e:1873				if Code[len] = temp_sym then*/
        _2 = (object)SEQ_PTR(_36Code_21859);
        _29128 = (object)*(((s1_ptr)_2)->base + _len_58130);
        if (binary_op_a(NOTEQ, _29128, _temp_sym_58079)){
            _29128 = NOVALUE;
            goto L11; // [466] 486
        }
        _29128 = NOVALUE;

        /** parser.e:1875					Code = remove( Code, len - 1, len )*/
        _29130 = _len_58130 - 1;
        {
            s1_ptr assign_space = SEQ_PTR(_36Code_21859);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_29130)) ? _29130 : (object)(DBL_PTR(_29130)->dbl);
            int stop = (IS_ATOM_INT(_len_58130)) ? _len_58130 : (object)(DBL_PTR(_len_58130)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<1) {
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_36Code_21859), start, &_36Code_21859 );
                }
                else Tail(SEQ_PTR(_36Code_21859), stop+1, &_36Code_21859);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_36Code_21859), start, &_36Code_21859);
            }
            else {
                assign_slice_seq = &assign_space;
                _36Code_21859 = Remove_elements(start, stop, (SEQ_PTR(_36Code_21859)->ref == 1));
            }
        }
        _29130 = NOVALUE;
L11: 

        /** parser.e:1877				emit_op( ASSIGN )*/
        _47emit_op(18);

        /** parser.e:1879				TypeCheck( lhs_syms[i] )*/
        _2 = (object)SEQ_PTR(_lhs_syms_58013);
        _29132 = (object)*(((s1_ptr)_2)->base + _i_58091);
        Ref(_29132);
        _45TypeCheck(_29132);
        _29132 = NOVALUE;
LE: 

        /** parser.e:1882		end for*/
        _i_58091 = _i_58091 + 1;
        goto LC; // [507] 315
LD: 
        ;
    }

    /** parser.e:1884		push_temps( temps )*/
    RefDS(_temps_58082);
    _47push_temps(_temps_58082);

    /** parser.e:1885		flush_temps()*/
    RefDS(_22190);
    _47flush_temps(_22190);

    /** parser.e:1887		if TRANSLATE then*/
    if (_36TRANSLATE_21369 == 0)
    {
        goto L12; // [526] 542
    }
    else{
    }

    /** parser.e:1888			emit_opnd( temp_sym )*/
    _47emit_opnd(_temp_sym_58079);

    /** parser.e:1889			emit_op( DEREF_TEMP )*/
    _47emit_op(208);
L12: 

    /** parser.e:1891	end procedure*/
    DeRef(_lhs_syms_58013);
    DeRef(_lhs_list_58014);
    DeRef(_tok_58016);
    DeRef(_temps_58082);
    _29104 = NOVALUE;
    _29118 = NOVALUE;
    _29111 = NOVALUE;
    _29121 = NOVALUE;
    _29090 = NOVALUE;
    DeRef(_29083);
    _29083 = NOVALUE;
    return;
    ;
}


void _45Return_statement()
{
    object _tok_58154 = NOVALUE;
    object _pop_58155 = NOVALUE;
    object _last_op_58162 = NOVALUE;
    object _last_pc_58165 = NOVALUE;
    object _is_tail_58168 = NOVALUE;
    object _29164 = NOVALUE;
    object _29162 = NOVALUE;
    object _29161 = NOVALUE;
    object _29160 = NOVALUE;
    object _29159 = NOVALUE;
    object _29157 = NOVALUE;
    object _29156 = NOVALUE;
    object _29155 = NOVALUE;
    object _29154 = NOVALUE;
    object _29153 = NOVALUE;
    object _29152 = NOVALUE;
    object _29151 = NOVALUE;
    object _29150 = NOVALUE;
    object _29146 = NOVALUE;
    object _29145 = NOVALUE;
    object _29143 = NOVALUE;
    object _29142 = NOVALUE;
    object _29141 = NOVALUE;
    object _29140 = NOVALUE;
    object _29139 = NOVALUE;
    object _29138 = NOVALUE;
    object _29137 = NOVALUE;
    object _29136 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:1897		integer pop*/

    /** parser.e:1898		if CurrentSub = TopLevelSub then*/
    if (_36CurrentSub_21775 != _36TopLevelSub_21774)
    goto L1; // [9] 23

    /** parser.e:1899			CompileErr(RETURN_MUST_BE_INSIDE_A_PROCEDURE_OR_FUNCTION)*/
    RefDS(_22190);
    _50CompileErr(130, _22190, 0);
L1: 

    /** parser.e:1902		integer*/

    /** parser.e:1903			last_op = Last_op(),*/
    _last_op_58162 = _47Last_op();
    if (!IS_ATOM_INT(_last_op_58162)) {
        _1 = (object)(DBL_PTR(_last_op_58162)->dbl);
        DeRefDS(_last_op_58162);
        _last_op_58162 = _1;
    }

    /** parser.e:1904			last_pc = Last_pc(),*/
    _last_pc_58165 = _47Last_pc();
    if (!IS_ATOM_INT(_last_pc_58165)) {
        _1 = (object)(DBL_PTR(_last_pc_58165)->dbl);
        DeRefDS(_last_pc_58165);
        _last_pc_58165 = _1;
    }

    /** parser.e:1905			is_tail = 0*/
    _is_tail_58168 = 0;

    /** parser.e:1907		if last_op = PROC and length(Code) > last_pc and Code[last_pc+1] = CurrentSub then*/
    _29136 = (_last_op_58162 == 27);
    if (_29136 == 0) {
        _29137 = 0;
        goto L2; // [52] 69
    }
    if (IS_SEQUENCE(_36Code_21859)){
            _29138 = SEQ_PTR(_36Code_21859)->length;
    }
    else {
        _29138 = 1;
    }
    _29139 = (_29138 > _last_pc_58165);
    _29138 = NOVALUE;
    _29137 = (_29139 != 0);
L2: 
    if (_29137 == 0) {
        goto L3; // [69] 99
    }
    _29141 = _last_pc_58165 + 1;
    _2 = (object)SEQ_PTR(_36Code_21859);
    _29142 = (object)*(((s1_ptr)_2)->base + _29141);
    if (IS_ATOM_INT(_29142)) {
        _29143 = (_29142 == _36CurrentSub_21775);
    }
    else {
        _29143 = binary_op(EQUALS, _29142, _36CurrentSub_21775);
    }
    _29142 = NOVALUE;
    if (_29143 == 0) {
        DeRef(_29143);
        _29143 = NOVALUE;
        goto L3; // [90] 99
    }
    else {
        if (!IS_ATOM_INT(_29143) && DBL_PTR(_29143)->dbl == 0.0){
            DeRef(_29143);
            _29143 = NOVALUE;
            goto L3; // [90] 99
        }
        DeRef(_29143);
        _29143 = NOVALUE;
    }
    DeRef(_29143);
    _29143 = NOVALUE;

    /** parser.e:1908			is_tail = 1*/
    _is_tail_58168 = 1;
L3: 

    /** parser.e:1911		if not TRANSLATE then*/
    if (_36TRANSLATE_21369 != 0)
    goto L4; // [103] 129

    /** parser.e:1912			if OpTrace then*/
    if (_36OpTrace_21840 == 0)
    {
        goto L5; // [110] 128
    }
    else{
    }

    /** parser.e:1913				emit_op(ERASE_PRIVATE_NAMES)*/
    _47emit_op(88);

    /** parser.e:1914				emit_addr(CurrentSub)*/
    _47emit_addr(_36CurrentSub_21775);
L5: 
L4: 

    /** parser.e:1917		if SymTab[CurrentSub][S_TOKEN] != PROC then*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _29145 = (object)*(((s1_ptr)_2)->base + _36CurrentSub_21775);
    _2 = (object)SEQ_PTR(_29145);
    if (!IS_ATOM_INT(_36S_TOKEN_21409)){
        _29146 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21409)->dbl));
    }
    else{
        _29146 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21409);
    }
    _29145 = NOVALUE;
    if (binary_op_a(EQUALS, _29146, 27)){
        _29146 = NOVALUE;
        goto L6; // [147] 273
    }
    _29146 = NOVALUE;

    /** parser.e:1918			Expr()*/
    _45Expr();

    /** parser.e:1919			last_op = Last_op()*/
    _last_op_58162 = _47Last_op();
    if (!IS_ATOM_INT(_last_op_58162)) {
        _1 = (object)(DBL_PTR(_last_op_58162)->dbl);
        DeRefDS(_last_op_58162);
        _last_op_58162 = _1;
    }

    /** parser.e:1920			last_pc = Last_pc()*/
    _last_pc_58165 = _47Last_pc();
    if (!IS_ATOM_INT(_last_pc_58165)) {
        _1 = (object)(DBL_PTR(_last_pc_58165)->dbl);
        DeRefDS(_last_pc_58165);
        _last_pc_58165 = _1;
    }

    /** parser.e:1921			if last_op = PROC and length(Code) > last_pc and Code[last_pc+1] = CurrentSub then*/
    _29150 = (_last_op_58162 == 27);
    if (_29150 == 0) {
        _29151 = 0;
        goto L7; // [177] 194
    }
    if (IS_SEQUENCE(_36Code_21859)){
            _29152 = SEQ_PTR(_36Code_21859)->length;
    }
    else {
        _29152 = 1;
    }
    _29153 = (_29152 > _last_pc_58165);
    _29152 = NOVALUE;
    _29151 = (_29153 != 0);
L7: 
    if (_29151 == 0) {
        goto L8; // [194] 253
    }
    _29155 = _last_pc_58165 + 1;
    _2 = (object)SEQ_PTR(_36Code_21859);
    _29156 = (object)*(((s1_ptr)_2)->base + _29155);
    if (IS_ATOM_INT(_29156)) {
        _29157 = (_29156 == _36CurrentSub_21775);
    }
    else {
        _29157 = binary_op(EQUALS, _29156, _36CurrentSub_21775);
    }
    _29156 = NOVALUE;
    if (_29157 == 0) {
        DeRef(_29157);
        _29157 = NOVALUE;
        goto L8; // [215] 253
    }
    else {
        if (!IS_ATOM_INT(_29157) && DBL_PTR(_29157)->dbl == 0.0){
            DeRef(_29157);
            _29157 = NOVALUE;
            goto L8; // [215] 253
        }
        DeRef(_29157);
        _29157 = NOVALUE;
    }
    DeRef(_29157);
    _29157 = NOVALUE;

    /** parser.e:1922				pop = Pop() -- prevent cg_stack (code generation stack) leakage*/
    _pop_58155 = _47Pop();
    if (!IS_ATOM_INT(_pop_58155)) {
        _1 = (object)(DBL_PTR(_pop_58155)->dbl);
        DeRefDS(_pop_58155);
        _pop_58155 = _1;
    }

    /** parser.e:1923				Code[Last_pc()] = PROC_TAIL*/
    _29159 = _47Last_pc();
    _2 = (object)SEQ_PTR(_36Code_21859);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _36Code_21859 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_29159))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_29159)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _29159);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 203;
    DeRef(_1);

    /** parser.e:1924				if object(pop_temps()) then end if*/
    _29160 = _47pop_temps();
    if( NOVALUE == _29160 ){
        _29161 = 0;
    }
    else{
        if (IS_ATOM_INT(_29160))
        _29161 = 1;
        else if (IS_ATOM_DBL(_29160)) {
             if (IS_ATOM_INT(DoubleToInt(_29160))) {
                 _29161 = 1;
                 } else {
                     _29161 = 2;
                } } else if (IS_SEQUENCE(_29160))
                _29161 = 3;
                else
                _29161 = 0;
            }
            DeRef(_29160);
            _29160 = NOVALUE;
            if (_29161 == 0)
            {
                _29161 = NOVALUE;
                goto L9; // [246] 300
            }
            else{
                _29161 = NOVALUE;
            }
            goto L9; // [250] 300
L8: 

            /** parser.e:1926				FuncReturn = TRUE*/
            _45FuncReturn_55364 = _13TRUE_447;

            /** parser.e:1927				emit_op(RETURNF)*/
            _47emit_op(28);
            goto L9; // [270] 300
L6: 

            /** parser.e:1930			if is_tail then*/
            if (_is_tail_58168 == 0)
            {
                goto LA; // [275] 292
            }
            else{
            }

            /** parser.e:1931				Code[Last_pc()] = PROC_TAIL*/
            _29162 = _47Last_pc();
            _2 = (object)SEQ_PTR(_36Code_21859);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _36Code_21859 = MAKE_SEQ(_2);
            }
            if (!IS_ATOM_INT(_29162))
            _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_29162)->dbl));
            else
            _2 = (object)(((s1_ptr)_2)->base + _29162);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = 203;
            DeRef(_1);
LA: 

            /** parser.e:1933			emit_op(RETURNP)*/
            _47emit_op(29);
L9: 

            /** parser.e:1936		tok = next_token()*/
            _0 = _tok_58154;
            _tok_58154 = _45next_token();
            DeRef(_0);

            /** parser.e:1937		putback(tok)*/
            Ref(_tok_58154);
            _45putback(_tok_58154);

            /** parser.e:1938		NotReached(tok[T_ID], "return")*/
            _2 = (object)SEQ_PTR(_tok_58154);
            _29164 = (object)*(((s1_ptr)_2)->base + 1);
            Ref(_29164);
            RefDS(_26529);
            _45NotReached(_29164, _26529);
            _29164 = NOVALUE;

            /** parser.e:1939	end procedure*/
            DeRef(_tok_58154);
            DeRef(_29159);
            _29159 = NOVALUE;
            DeRef(_29139);
            _29139 = NOVALUE;
            DeRef(_29141);
            _29141 = NOVALUE;
            DeRef(_29162);
            _29162 = NOVALUE;
            DeRef(_29155);
            _29155 = NOVALUE;
            DeRef(_29153);
            _29153 = NOVALUE;
            DeRef(_29136);
            _29136 = NOVALUE;
            DeRef(_29150);
            _29150 = NOVALUE;
            return;
    ;
}


object _45exit_level(object _tok_58244, object _flag_58245)
{
    object _arg_58246 = NOVALUE;
    object _n_58247 = NOVALUE;
    object _num_labels_58248 = NOVALUE;
    object _negative_58249 = NOVALUE;
    object _labels_58250 = NOVALUE;
    object _29193 = NOVALUE;
    object _29192 = NOVALUE;
    object _29191 = NOVALUE;
    object _29190 = NOVALUE;
    object _29189 = NOVALUE;
    object _29186 = NOVALUE;
    object _29185 = NOVALUE;
    object _29184 = NOVALUE;
    object _29182 = NOVALUE;
    object _29181 = NOVALUE;
    object _29180 = NOVALUE;
    object _29179 = NOVALUE;
    object _29177 = NOVALUE;
    object _29172 = NOVALUE;
    object _29171 = NOVALUE;
    object _29169 = NOVALUE;
    object _29166 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:1946		integer negative = 0*/
    _negative_58249 = 0;

    /** parser.e:1949		if flag then*/
    if (_flag_58245 == 0)
    {
        goto L1; // [10] 25
    }
    else{
    }

    /** parser.e:1950			labels = if_labels*/
    RefDS(_45if_labels_55385);
    DeRef(_labels_58250);
    _labels_58250 = _45if_labels_55385;
    goto L2; // [22] 35
L1: 

    /** parser.e:1952			labels = loop_labels*/
    RefDS(_45loop_labels_55384);
    DeRef(_labels_58250);
    _labels_58250 = _45loop_labels_55384;
L2: 

    /** parser.e:1954		num_labels = length(labels)*/
    if (IS_SEQUENCE(_labels_58250)){
            _num_labels_58248 = SEQ_PTR(_labels_58250)->length;
    }
    else {
        _num_labels_58248 = 1;
    }

    /** parser.e:1956		if tok[T_ID] = MINUS then*/
    _2 = (object)SEQ_PTR(_tok_58244);
    _29166 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29166, 10)){
        _29166 = NOVALUE;
        goto L3; // [52] 67
    }
    _29166 = NOVALUE;

    /** parser.e:1957			tok = next_token()*/
    _0 = _tok_58244;
    _tok_58244 = _45next_token();
    DeRef(_0);

    /** parser.e:1958			negative = 1*/
    _negative_58249 = 1;
L3: 

    /** parser.e:1961		if tok[T_ID]=ATOM then*/
    _2 = (object)SEQ_PTR(_tok_58244);
    _29169 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29169, 502)){
        _29169 = NOVALUE;
        goto L4; // [77] 180
    }
    _29169 = NOVALUE;

    /** parser.e:1962			arg = SymTab[tok[T_SYM]][S_OBJ]*/
    _2 = (object)SEQ_PTR(_tok_58244);
    _29171 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!IS_ATOM_INT(_29171)){
        _29172 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_29171)->dbl));
    }
    else{
        _29172 = (object)*(((s1_ptr)_2)->base + _29171);
    }
    DeRef(_arg_58246);
    _2 = (object)SEQ_PTR(_29172);
    _arg_58246 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_arg_58246);
    _29172 = NOVALUE;

    /** parser.e:1963			n = floor(arg)*/
    if (IS_ATOM_INT(_arg_58246))
    _n_58247 = e_floor(_arg_58246);
    else
    _n_58247 = unary_op(FLOOR, _arg_58246);
    if (!IS_ATOM_INT(_n_58247)) {
        _1 = (object)(DBL_PTR(_n_58247)->dbl);
        DeRefDS(_n_58247);
        _n_58247 = _1;
    }

    /** parser.e:1964			if negative then*/
    if (_negative_58249 == 0)
    {
        goto L5; // [110] 122
    }
    else{
    }

    /** parser.e:1965				n = num_labels - n*/
    _n_58247 = _num_labels_58248 - _n_58247;
    goto L6; // [119] 135
L5: 

    /** parser.e:1966			elsif n = 0 then*/
    if (_n_58247 != 0)
    goto L7; // [124] 134

    /** parser.e:1967				n = num_labels*/
    _n_58247 = _num_labels_58248;
L7: 
L6: 

    /** parser.e:1969			if n<=0 or n>num_labels then*/
    _29177 = (_n_58247 <= 0);
    if (_29177 != 0) {
        goto L8; // [141] 154
    }
    _29179 = (_n_58247 > _num_labels_58248);
    if (_29179 == 0)
    {
        DeRef(_29179);
        _29179 = NOVALUE;
        goto L9; // [150] 164
    }
    else{
        DeRef(_29179);
        _29179 = NOVALUE;
    }
L8: 

    /** parser.e:1970				CompileErr(EXITBREAK_ARGUMENT_OUT_OF_RANGE)*/
    RefDS(_22190);
    _50CompileErr(87, _22190, 0);
L9: 

    /** parser.e:1972			return {n, next_token()}*/
    _29180 = _45next_token();
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _n_58247;
    ((intptr_t *)_2)[2] = _29180;
    _29181 = MAKE_SEQ(_1);
    _29180 = NOVALUE;
    DeRef(_tok_58244);
    DeRef(_arg_58246);
    DeRef(_labels_58250);
    _29171 = NOVALUE;
    DeRef(_29177);
    _29177 = NOVALUE;
    return _29181;
    goto LA; // [177] 270
L4: 

    /** parser.e:1973		elsif tok[T_ID]=STRING then*/
    _2 = (object)SEQ_PTR(_tok_58244);
    _29182 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29182, 503)){
        _29182 = NOVALUE;
        goto LB; // [190] 259
    }
    _29182 = NOVALUE;

    /** parser.e:1974			n = find(SymTab[tok[T_SYM]][S_OBJ],labels)*/
    _2 = (object)SEQ_PTR(_tok_58244);
    _29184 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!IS_ATOM_INT(_29184)){
        _29185 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_29184)->dbl));
    }
    else{
        _29185 = (object)*(((s1_ptr)_2)->base + _29184);
    }
    _2 = (object)SEQ_PTR(_29185);
    _29186 = (object)*(((s1_ptr)_2)->base + 1);
    _29185 = NOVALUE;
    _n_58247 = find_from(_29186, _labels_58250, 1);
    _29186 = NOVALUE;

    /** parser.e:1975			if n = 0 then*/
    if (_n_58247 != 0)
    goto LC; // [221] 235

    /** parser.e:1976				CompileErr(UNKNOWN_BLOCK_LABEL)*/
    RefDS(_22190);
    _50CompileErr(152, _22190, 0);
LC: 

    /** parser.e:1978			return {num_labels + 1 - n, next_token()}*/
    _29189 = _num_labels_58248 + 1;
    if (_29189 > MAXINT){
        _29189 = NewDouble((eudouble)_29189);
    }
    if (IS_ATOM_INT(_29189)) {
        _29190 = _29189 - _n_58247;
        if ((object)((uintptr_t)_29190 +(uintptr_t) HIGH_BITS) >= 0){
            _29190 = NewDouble((eudouble)_29190);
        }
    }
    else {
        _29190 = NewDouble(DBL_PTR(_29189)->dbl - (eudouble)_n_58247);
    }
    DeRef(_29189);
    _29189 = NOVALUE;
    _29191 = _45next_token();
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _29190;
    ((intptr_t *)_2)[2] = _29191;
    _29192 = MAKE_SEQ(_1);
    _29191 = NOVALUE;
    _29190 = NOVALUE;
    DeRef(_tok_58244);
    DeRef(_arg_58246);
    DeRef(_labels_58250);
    DeRef(_29181);
    _29181 = NOVALUE;
    _29171 = NOVALUE;
    _29184 = NOVALUE;
    DeRef(_29177);
    _29177 = NOVALUE;
    return _29192;
    goto LA; // [256] 270
LB: 

    /** parser.e:1980			return {1, tok} -- no parameters*/
    Ref(_tok_58244);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 1;
    ((intptr_t *)_2)[2] = _tok_58244;
    _29193 = MAKE_SEQ(_1);
    DeRef(_tok_58244);
    DeRef(_arg_58246);
    DeRef(_labels_58250);
    DeRef(_29181);
    _29181 = NOVALUE;
    DeRef(_29192);
    _29192 = NOVALUE;
    _29171 = NOVALUE;
    _29184 = NOVALUE;
    DeRef(_29177);
    _29177 = NOVALUE;
    return _29193;
LA: 
    ;
}


void _45GLabel_statement()
{
    object _tok_58309 = NOVALUE;
    object _labbel_58310 = NOVALUE;
    object _laddr_58311 = NOVALUE;
    object _n_58312 = NOVALUE;
    object _29212 = NOVALUE;
    object _29210 = NOVALUE;
    object _29209 = NOVALUE;
    object _29208 = NOVALUE;
    object _29207 = NOVALUE;
    object _29205 = NOVALUE;
    object _29202 = NOVALUE;
    object _29200 = NOVALUE;
    object _29198 = NOVALUE;
    object _29197 = NOVALUE;
    object _29195 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:1986		object labbel*/

    /** parser.e:1987		object laddr*/

    /** parser.e:1988		integer n*/

    /** parser.e:1990		tok = next_token()*/
    _0 = _tok_58309;
    _tok_58309 = _45next_token();
    DeRef(_0);

    /** parser.e:1992		if tok[T_ID] != STRING then*/
    _2 = (object)SEQ_PTR(_tok_58309);
    _29195 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _29195, 503)){
        _29195 = NOVALUE;
        goto L1; // [22] 36
    }
    _29195 = NOVALUE;

    /** parser.e:1993			CompileErr(A_LABEL_CLAUSE_MUST_BE_FOLLOWED_BY_A_CONSTANT_STRING)*/
    RefDS(_22190);
    _50CompileErr(35, _22190, 0);
L1: 

    /** parser.e:1996		labbel = SymTab[tok[T_SYM]][S_OBJ]*/
    _2 = (object)SEQ_PTR(_tok_58309);
    _29197 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!IS_ATOM_INT(_29197)){
        _29198 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_29197)->dbl));
    }
    else{
        _29198 = (object)*(((s1_ptr)_2)->base + _29197);
    }
    DeRef(_labbel_58310);
    _2 = (object)SEQ_PTR(_29198);
    _labbel_58310 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_labbel_58310);
    _29198 = NOVALUE;

    /** parser.e:1997		laddr = length(Code) + 1*/
    if (IS_SEQUENCE(_36Code_21859)){
            _29200 = SEQ_PTR(_36Code_21859)->length;
    }
    else {
        _29200 = 1;
    }
    _laddr_58311 = _29200 + 1;
    _29200 = NOVALUE;

    /** parser.e:1999		if find(labbel, goto_labels) then*/
    _29202 = find_from(_labbel_58310, _45goto_labels_55367, 1);
    if (_29202 == 0)
    {
        _29202 = NOVALUE;
        goto L2; // [76] 89
    }
    else{
        _29202 = NOVALUE;
    }

    /** parser.e:2000			CompileErr(DUPLICATE_LABEL_NAME)*/
    RefDS(_22190);
    _50CompileErr(59, _22190, 0);
L2: 

    /** parser.e:2003		goto_labels = append(goto_labels, labbel)*/
    Ref(_labbel_58310);
    Append(&_45goto_labels_55367, _45goto_labels_55367, _labbel_58310);

    /** parser.e:2004		goto_addr = append(goto_addr, laddr)*/
    Append(&_45goto_addr_55368, _45goto_addr_55368, _laddr_58311);

    /** parser.e:2005		label_block = append( label_block, top_block() )*/
    _29205 = _65top_block(0);
    Ref(_29205);
    Append(&_45label_block_55371, _45label_block_55371, _29205);
    DeRef(_29205);
    _29205 = NOVALUE;

    /** parser.e:2007		while n with entry do*/
    goto L3; // [119] 178
L4: 
    if (_n_58312 == 0)
    {
        goto L5; // [124] 192
    }
    else{
    }

    /** parser.e:2008			backpatch(goto_list[n], laddr)*/
    _2 = (object)SEQ_PTR(_36goto_list_21882);
    _29207 = (object)*(((s1_ptr)_2)->base + _n_58312);
    Ref(_29207);
    _47backpatch(_29207, _laddr_58311);
    _29207 = NOVALUE;

    /** parser.e:2009			set_glabel_block( goto_ref[n], top_block() )*/
    _2 = (object)SEQ_PTR(_45goto_ref_55370);
    _29208 = (object)*(((s1_ptr)_2)->base + _n_58312);
    _29209 = _65top_block(0);
    Ref(_29208);
    _44set_glabel_block(_29208, _29209);
    _29208 = NOVALUE;
    _29209 = NOVALUE;

    /** parser.e:2010			goto_delay[n] = "" --clear it*/
    RefDS(_22190);
    _2 = (object)SEQ_PTR(_36goto_delay_21881);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _36goto_delay_21881 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _n_58312);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22190;
    DeRef(_1);

    /** parser.e:2011			goto_line[n] = {-1,""} --clear it*/
    RefDS(_22190);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -1;
    ((intptr_t *)_2)[2] = _22190;
    _29210 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_45goto_line_55366);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _45goto_line_55366 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _n_58312);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29210;
    if( _1 != _29210 ){
        DeRef(_1);
    }
    _29210 = NOVALUE;

    /** parser.e:2013		entry*/
L3: 

    /** parser.e:2014			n = find(labbel, goto_delay)*/
    _n_58312 = find_from(_labbel_58310, _36goto_delay_21881, 1);

    /** parser.e:2015		end while*/
    goto L4; // [189] 122
L5: 

    /** parser.e:2017		force_uninitialize( map:get( goto_init, labbel, {} ) )*/
    Ref(_45goto_init_55373);
    Ref(_labbel_58310);
    RefDS(_22190);
    _29212 = _29get(_45goto_init_55373, _labbel_58310, _22190);
    _45force_uninitialize(_29212);
    _29212 = NOVALUE;

    /** parser.e:2019		if TRANSLATE then*/
    if (_36TRANSLATE_21369 == 0)
    {
        goto L6; // [209] 225
    }
    else{
    }

    /** parser.e:2020			emit_op(GLABEL)*/
    _47emit_op(189);

    /** parser.e:2021			emit_addr(laddr)*/
    _47emit_addr(_laddr_58311);
L6: 

    /** parser.e:2023	end procedure*/
    DeRef(_tok_58309);
    DeRef(_labbel_58310);
    _29197 = NOVALUE;
    return;
    ;
}


void _45Goto_statement()
{
    object _tok_58361 = NOVALUE;
    object _n_58362 = NOVALUE;
    object _num_labels_58363 = NOVALUE;
    object _31961 = NOVALUE;
    object _29251 = NOVALUE;
    object _29250 = NOVALUE;
    object _29247 = NOVALUE;
    object _29246 = NOVALUE;
    object _29245 = NOVALUE;
    object _29244 = NOVALUE;
    object _29243 = NOVALUE;
    object _29242 = NOVALUE;
    object _29241 = NOVALUE;
    object _29240 = NOVALUE;
    object _29239 = NOVALUE;
    object _29238 = NOVALUE;
    object _29237 = NOVALUE;
    object _29236 = NOVALUE;
    object _29234 = NOVALUE;
    object _29233 = NOVALUE;
    object _29231 = NOVALUE;
    object _29230 = NOVALUE;
    object _29228 = NOVALUE;
    object _29227 = NOVALUE;
    object _29225 = NOVALUE;
    object _29224 = NOVALUE;
    object _29223 = NOVALUE;
    object _29222 = NOVALUE;
    object _29219 = NOVALUE;
    object _29218 = NOVALUE;
    object _29217 = NOVALUE;
    object _29215 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:2028		integer n*/

    /** parser.e:2029		integer num_labels*/

    /** parser.e:2031		tok = next_token()*/
    _0 = _tok_58361;
    _tok_58361 = _45next_token();
    DeRef(_0);

    /** parser.e:2032		num_labels = length(goto_labels)*/
    if (IS_SEQUENCE(_45goto_labels_55367)){
            _num_labels_58363 = SEQ_PTR(_45goto_labels_55367)->length;
    }
    else {
        _num_labels_58363 = 1;
    }

    /** parser.e:2034		if tok[T_ID]=STRING then*/
    _2 = (object)SEQ_PTR(_tok_58361);
    _29215 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29215, 503)){
        _29215 = NOVALUE;
        goto L1; // [27] 267
    }
    _29215 = NOVALUE;

    /** parser.e:2035			n = find(SymTab[tok[T_SYM]][S_OBJ],goto_labels)*/
    _2 = (object)SEQ_PTR(_tok_58361);
    _29217 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!IS_ATOM_INT(_29217)){
        _29218 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_29217)->dbl));
    }
    else{
        _29218 = (object)*(((s1_ptr)_2)->base + _29217);
    }
    _2 = (object)SEQ_PTR(_29218);
    _29219 = (object)*(((s1_ptr)_2)->base + 1);
    _29218 = NOVALUE;
    _n_58362 = find_from(_29219, _45goto_labels_55367, 1);
    _29219 = NOVALUE;

    /** parser.e:2036			if n = 0 then*/
    if (_n_58362 != 0)
    goto L2; // [60] 241

    /** parser.e:2037				goto_delay &= {SymTab[tok[T_SYM]][S_OBJ]}*/
    _2 = (object)SEQ_PTR(_tok_58361);
    _29222 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!IS_ATOM_INT(_29222)){
        _29223 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_29222)->dbl));
    }
    else{
        _29223 = (object)*(((s1_ptr)_2)->base + _29222);
    }
    _2 = (object)SEQ_PTR(_29223);
    _29224 = (object)*(((s1_ptr)_2)->base + 1);
    _29223 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_29224);
    ((intptr_t*)_2)[1] = _29224;
    _29225 = MAKE_SEQ(_1);
    _29224 = NOVALUE;
    Concat((object_ptr)&_36goto_delay_21881, _36goto_delay_21881, _29225);
    DeRefDS(_29225);
    _29225 = NOVALUE;

    /** parser.e:2038				goto_list &= length(Code)+2 --not 1???*/
    if (IS_SEQUENCE(_36Code_21859)){
            _29227 = SEQ_PTR(_36Code_21859)->length;
    }
    else {
        _29227 = 1;
    }
    _29228 = _29227 + 2;
    _29227 = NOVALUE;
    Append(&_36goto_list_21882, _36goto_list_21882, _29228);
    _29228 = NOVALUE;

    /** parser.e:2039				goto_line &= {{line_number,ThisLine}}*/
    Ref(_50ThisLine_49594);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _36line_number_21768;
    ((intptr_t *)_2)[2] = _50ThisLine_49594;
    _29230 = MAKE_SEQ(_1);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _29230;
    _29231 = MAKE_SEQ(_1);
    _29230 = NOVALUE;
    Concat((object_ptr)&_45goto_line_55366, _45goto_line_55366, _29231);
    DeRefDS(_29231);
    _29231 = NOVALUE;

    /** parser.e:2040				goto_ref &= new_forward_reference( GOTO, top_block() )*/
    _29233 = _65top_block(0);
    _31961 = 188;
    _29234 = _44new_forward_reference(188, _29233, 188);
    _29233 = NOVALUE;
    _31961 = NOVALUE;
    if (IS_SEQUENCE(_45goto_ref_55370) && IS_ATOM(_29234)) {
        Ref(_29234);
        Append(&_45goto_ref_55370, _45goto_ref_55370, _29234);
    }
    else if (IS_ATOM(_45goto_ref_55370) && IS_SEQUENCE(_29234)) {
    }
    else {
        Concat((object_ptr)&_45goto_ref_55370, _45goto_ref_55370, _29234);
    }
    DeRef(_29234);
    _29234 = NOVALUE;

    /** parser.e:2041				map:put( goto_init, SymTab[tok[T_SYM]][S_OBJ], get_private_uninitialized() )*/
    _2 = (object)SEQ_PTR(_tok_58361);
    _29236 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!IS_ATOM_INT(_29236)){
        _29237 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_29236)->dbl));
    }
    else{
        _29237 = (object)*(((s1_ptr)_2)->base + _29236);
    }
    _2 = (object)SEQ_PTR(_29237);
    _29238 = (object)*(((s1_ptr)_2)->base + 1);
    _29237 = NOVALUE;
    _29239 = _45get_private_uninitialized();
    Ref(_45goto_init_55373);
    Ref(_29238);
    _29put(_45goto_init_55373, _29238, _29239, 1, 0);
    _29238 = NOVALUE;
    _29239 = NOVALUE;

    /** parser.e:2042				add_data( goto_ref[$], sym_obj( tok[T_SYM] ) )*/
    if (IS_SEQUENCE(_45goto_ref_55370)){
            _29240 = SEQ_PTR(_45goto_ref_55370)->length;
    }
    else {
        _29240 = 1;
    }
    _2 = (object)SEQ_PTR(_45goto_ref_55370);
    _29241 = (object)*(((s1_ptr)_2)->base + _29240);
    _2 = (object)SEQ_PTR(_tok_58361);
    _29242 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_29242);
    _29243 = _54sym_obj(_29242);
    _29242 = NOVALUE;
    Ref(_29241);
    _44add_data(_29241, _29243);
    _29241 = NOVALUE;
    _29243 = NOVALUE;

    /** parser.e:2043				set_line( goto_ref[$], line_number, ThisLine, bp )*/
    if (IS_SEQUENCE(_45goto_ref_55370)){
            _29244 = SEQ_PTR(_45goto_ref_55370)->length;
    }
    else {
        _29244 = 1;
    }
    _2 = (object)SEQ_PTR(_45goto_ref_55370);
    _29245 = (object)*(((s1_ptr)_2)->base + _29244);
    Ref(_29245);
    Ref(_50ThisLine_49594);
    _44set_line(_29245, _36line_number_21768, _50ThisLine_49594, _50bp_49598);
    _29245 = NOVALUE;
    goto L3; // [238] 259
L2: 

    /** parser.e:2045				Goto_block( top_block(), label_block[n] )*/
    _29246 = _65top_block(0);
    _2 = (object)SEQ_PTR(_45label_block_55371);
    _29247 = (object)*(((s1_ptr)_2)->base + _n_58362);
    Ref(_29247);
    _65Goto_block(_29246, _29247, 0);
    _29246 = NOVALUE;
    _29247 = NOVALUE;
L3: 

    /** parser.e:2047			tok = next_token()*/
    _0 = _tok_58361;
    _tok_58361 = _45next_token();
    DeRef(_0);
    goto L4; // [264] 277
L1: 

    /** parser.e:2049			CompileErr(GOTO_STATEMENT_WITHOUT_A_STRING_LABEL)*/
    RefDS(_22190);
    _50CompileErr(96, _22190, 0);
L4: 

    /** parser.e:2052		emit_op(GOTO)*/
    _47emit_op(188);

    /** parser.e:2053		if n = 0 then*/
    if (_n_58362 != 0)
    goto L5; // [288] 300

    /** parser.e:2054			emit_addr(0) -- to be back-patched*/
    _47emit_addr(0);
    goto L6; // [297] 312
L5: 

    /** parser.e:2056			emit_addr(goto_addr[n])*/
    _2 = (object)SEQ_PTR(_45goto_addr_55368);
    _29250 = (object)*(((s1_ptr)_2)->base + _n_58362);
    Ref(_29250);
    _47emit_addr(_29250);
    _29250 = NOVALUE;
L6: 

    /** parser.e:2059		putback(tok)*/
    Ref(_tok_58361);
    _45putback(_tok_58361);

    /** parser.e:2060		NotReached(tok[T_ID], "goto")*/
    _2 = (object)SEQ_PTR(_tok_58361);
    _29251 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_29251);
    RefDS(_26471);
    _45NotReached(_29251, _26471);
    _29251 = NOVALUE;

    /** parser.e:2061	end procedure*/
    DeRef(_tok_58361);
    _29236 = NOVALUE;
    _29222 = NOVALUE;
    _29217 = NOVALUE;
    return;
    ;
}


void _45Exit_statement()
{
    object _addr_inlined_AppendXList_at_65_58466 = NOVALUE;
    object _tok_58448 = NOVALUE;
    object _by_ref_58449 = NOVALUE;
    object _29259 = NOVALUE;
    object _29258 = NOVALUE;
    object _29257 = NOVALUE;
    object _29256 = NOVALUE;
    object _29254 = NOVALUE;
    object _29252 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:2066		sequence by_ref*/

    /** parser.e:2068		if not length(loop_stack) then*/
    if (IS_SEQUENCE(_45loop_stack_55390)){
            _29252 = SEQ_PTR(_45loop_stack_55390)->length;
    }
    else {
        _29252 = 1;
    }
    if (_29252 != 0)
    goto L1; // [10] 23
    _29252 = NOVALUE;

    /** parser.e:2069			CompileErr(EXIT_STATEMENT_MUST_BE_INSIDE_A_LOOP)*/
    RefDS(_22190);
    _50CompileErr(88, _22190, 0);
L1: 

    /** parser.e:2072		by_ref = exit_level(next_token(),0) -- can't pass tok by reference*/
    _29254 = _45next_token();
    _0 = _by_ref_58449;
    _by_ref_58449 = _45exit_level(_29254, 0);
    DeRef(_0);
    _29254 = NOVALUE;

    /** parser.e:2073		Leave_blocks( by_ref[1], LOOP_BLOCK )*/
    _2 = (object)SEQ_PTR(_by_ref_58449);
    _29256 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_29256);
    _65Leave_blocks(_29256, 1);
    _29256 = NOVALUE;

    /** parser.e:2074		emit_op(EXIT)*/
    _47emit_op(61);

    /** parser.e:2075		AppendXList(length(Code)+1)*/
    if (IS_SEQUENCE(_36Code_21859)){
            _29257 = SEQ_PTR(_36Code_21859)->length;
    }
    else {
        _29257 = 1;
    }
    _29258 = _29257 + 1;
    _29257 = NOVALUE;
    _addr_inlined_AppendXList_at_65_58466 = _29258;
    _29258 = NOVALUE;

    /** parser.e:398		exit_list = append(exit_list, addr)*/
    Append(&_45exit_list_55376, _45exit_list_55376, _addr_inlined_AppendXList_at_65_58466);

    /** parser.e:399	end procedure*/
    goto L2; // [80] 83
L2: 

    /** parser.e:2076		exit_delay &= by_ref[1]*/
    _2 = (object)SEQ_PTR(_by_ref_58449);
    _29259 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_45exit_delay_55377) && IS_ATOM(_29259)) {
        Ref(_29259);
        Append(&_45exit_delay_55377, _45exit_delay_55377, _29259);
    }
    else if (IS_ATOM(_45exit_delay_55377) && IS_SEQUENCE(_29259)) {
    }
    else {
        Concat((object_ptr)&_45exit_delay_55377, _45exit_delay_55377, _29259);
    }
    _29259 = NOVALUE;

    /** parser.e:2077		emit_forward_addr()    -- to be back-patched*/
    _45emit_forward_addr();

    /** parser.e:2078		tok = by_ref[2]*/
    DeRef(_tok_58448);
    _2 = (object)SEQ_PTR(_by_ref_58449);
    _tok_58448 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_tok_58448);

    /** parser.e:2079		putback(tok)*/
    Ref(_tok_58448);
    _45putback(_tok_58448);

    /** parser.e:2080	end procedure*/
    DeRef(_tok_58448);
    DeRefDS(_by_ref_58449);
    return;
    ;
}


void _45Continue_statement()
{
    object _addr_inlined_AppendNList_at_153_58512 = NOVALUE;
    object _tok_58473 = NOVALUE;
    object _by_ref_58474 = NOVALUE;
    object _loop_level_58475 = NOVALUE;
    object _29285 = NOVALUE;
    object _29282 = NOVALUE;
    object _29281 = NOVALUE;
    object _29280 = NOVALUE;
    object _29279 = NOVALUE;
    object _29278 = NOVALUE;
    object _29277 = NOVALUE;
    object _29275 = NOVALUE;
    object _29274 = NOVALUE;
    object _29273 = NOVALUE;
    object _29272 = NOVALUE;
    object _29271 = NOVALUE;
    object _29270 = NOVALUE;
    object _29269 = NOVALUE;
    object _29268 = NOVALUE;
    object _29266 = NOVALUE;
    object _29264 = NOVALUE;
    object _29262 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:2085		sequence by_ref*/

    /** parser.e:2086		integer loop_level*/

    /** parser.e:2088		if not length(loop_stack) then*/
    if (IS_SEQUENCE(_45loop_stack_55390)){
            _29262 = SEQ_PTR(_45loop_stack_55390)->length;
    }
    else {
        _29262 = 1;
    }
    if (_29262 != 0)
    goto L1; // [12] 25
    _29262 = NOVALUE;

    /** parser.e:2089			CompileErr(CONTINUE_STATEMENT_MUST_BE_INSIDE_A_LOOP)*/
    RefDS(_22190);
    _50CompileErr(49, _22190, 0);
L1: 

    /** parser.e:2092		by_ref = exit_level(next_token(),0) -- can't pass tok by reference*/
    _29264 = _45next_token();
    _0 = _by_ref_58474;
    _by_ref_58474 = _45exit_level(_29264, 0);
    DeRef(_0);
    _29264 = NOVALUE;

    /** parser.e:2093		Leave_blocks( by_ref[1], LOOP_BLOCK )*/
    _2 = (object)SEQ_PTR(_by_ref_58474);
    _29266 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_29266);
    _65Leave_blocks(_29266, 1);
    _29266 = NOVALUE;

    /** parser.e:2094		emit_op(ELSE)*/
    _47emit_op(23);

    /** parser.e:2095		loop_level = by_ref[1]*/
    _2 = (object)SEQ_PTR(_by_ref_58474);
    _loop_level_58475 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_loop_level_58475))
    _loop_level_58475 = (object)DBL_PTR(_loop_level_58475)->dbl;

    /** parser.e:2098		if continue_addr[$+1-loop_level] then -- address is known for while loops*/
    if (IS_SEQUENCE(_45continue_addr_55381)){
            _29268 = SEQ_PTR(_45continue_addr_55381)->length;
    }
    else {
        _29268 = 1;
    }
    _29269 = _29268 + 1;
    _29268 = NOVALUE;
    _29270 = _29269 - _loop_level_58475;
    _29269 = NOVALUE;
    _2 = (object)SEQ_PTR(_45continue_addr_55381);
    _29271 = (object)*(((s1_ptr)_2)->base + _29270);
    if (_29271 == 0)
    {
        _29271 = NOVALUE;
        goto L2; // [81] 142
    }
    else{
        _29271 = NOVALUE;
    }

    /** parser.e:2099			if continue_addr[$+1-loop_level] < 0 then*/
    if (IS_SEQUENCE(_45continue_addr_55381)){
            _29272 = SEQ_PTR(_45continue_addr_55381)->length;
    }
    else {
        _29272 = 1;
    }
    _29273 = _29272 + 1;
    _29272 = NOVALUE;
    _29274 = _29273 - _loop_level_58475;
    _29273 = NOVALUE;
    _2 = (object)SEQ_PTR(_45continue_addr_55381);
    _29275 = (object)*(((s1_ptr)_2)->base + _29274);
    if (_29275 >= 0)
    goto L3; // [103] 117

    /** parser.e:2101				CompileErr(CONTINUE_STATEMENT_MUST_BE_INSIDE_A_LOOP)*/
    RefDS(_22190);
    _50CompileErr(49, _22190, 0);
L3: 

    /** parser.e:2103			emit_addr(continue_addr[$+1-loop_level])*/
    if (IS_SEQUENCE(_45continue_addr_55381)){
            _29277 = SEQ_PTR(_45continue_addr_55381)->length;
    }
    else {
        _29277 = 1;
    }
    _29278 = _29277 + 1;
    _29277 = NOVALUE;
    _29279 = _29278 - _loop_level_58475;
    _29278 = NOVALUE;
    _2 = (object)SEQ_PTR(_45continue_addr_55381);
    _29280 = (object)*(((s1_ptr)_2)->base + _29279);
    _47emit_addr(_29280);
    _29280 = NOVALUE;
    goto L4; // [139] 186
L2: 

    /** parser.e:2105			AppendNList(length(Code)+1)*/
    if (IS_SEQUENCE(_36Code_21859)){
            _29281 = SEQ_PTR(_36Code_21859)->length;
    }
    else {
        _29281 = 1;
    }
    _29282 = _29281 + 1;
    _29281 = NOVALUE;
    _addr_inlined_AppendNList_at_153_58512 = _29282;
    _29282 = NOVALUE;

    /** parser.e:403		continue_list = append(continue_list, addr)*/
    Append(&_45continue_list_55378, _45continue_list_55378, _addr_inlined_AppendNList_at_153_58512);

    /** parser.e:404	end procedure*/
    goto L5; // [168] 171
L5: 

    /** parser.e:2106			continue_delay &= loop_level*/
    Append(&_45continue_delay_55379, _45continue_delay_55379, _loop_level_58475);

    /** parser.e:2107			emit_forward_addr()    -- to be back-patched*/
    _45emit_forward_addr();
L4: 

    /** parser.e:2110		tok = by_ref[2]*/
    DeRef(_tok_58473);
    _2 = (object)SEQ_PTR(_by_ref_58474);
    _tok_58473 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_tok_58473);

    /** parser.e:2111		putback(tok)*/
    Ref(_tok_58473);
    _45putback(_tok_58473);

    /** parser.e:2113		NotReached(tok[T_ID], "continue")*/
    _2 = (object)SEQ_PTR(_tok_58473);
    _29285 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_29285);
    RefDS(_26433);
    _45NotReached(_29285, _26433);
    _29285 = NOVALUE;

    /** parser.e:2114	end procedure*/
    DeRef(_tok_58473);
    DeRefDS(_by_ref_58474);
    DeRef(_29274);
    _29274 = NOVALUE;
    _29275 = NOVALUE;
    DeRef(_29270);
    _29270 = NOVALUE;
    DeRef(_29279);
    _29279 = NOVALUE;
    return;
    ;
}


void _45Retry_statement()
{
    object _by_ref_58519 = NOVALUE;
    object _tok_58521 = NOVALUE;
    object _29309 = NOVALUE;
    object _29307 = NOVALUE;
    object _29306 = NOVALUE;
    object _29305 = NOVALUE;
    object _29304 = NOVALUE;
    object _29303 = NOVALUE;
    object _29301 = NOVALUE;
    object _29300 = NOVALUE;
    object _29299 = NOVALUE;
    object _29298 = NOVALUE;
    object _29297 = NOVALUE;
    object _29295 = NOVALUE;
    object _29294 = NOVALUE;
    object _29293 = NOVALUE;
    object _29292 = NOVALUE;
    object _29291 = NOVALUE;
    object _29290 = NOVALUE;
    object _29288 = NOVALUE;
    object _29286 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:2122		if not length(loop_stack) then*/
    if (IS_SEQUENCE(_45loop_stack_55390)){
            _29286 = SEQ_PTR(_45loop_stack_55390)->length;
    }
    else {
        _29286 = 1;
    }
    if (_29286 != 0)
    goto L1; // [8] 21
    _29286 = NOVALUE;

    /** parser.e:2123			CompileErr(RETRY_STATEMENT_MUST_BE_INSIDE_A_LOOP)*/
    RefDS(_22190);
    _50CompileErr(131, _22190, 0);
L1: 

    /** parser.e:2126		by_ref = exit_level(next_token(),0) -- can't pass tok by reference*/
    _29288 = _45next_token();
    _0 = _by_ref_58519;
    _by_ref_58519 = _45exit_level(_29288, 0);
    DeRef(_0);
    _29288 = NOVALUE;

    /** parser.e:2127		Leave_blocks( by_ref[1], LOOP_BLOCK )*/
    _2 = (object)SEQ_PTR(_by_ref_58519);
    _29290 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_29290);
    _65Leave_blocks(_29290, 1);
    _29290 = NOVALUE;

    /** parser.e:2128		if loop_stack[$+1-by_ref[1]]=FOR then*/
    if (IS_SEQUENCE(_45loop_stack_55390)){
            _29291 = SEQ_PTR(_45loop_stack_55390)->length;
    }
    else {
        _29291 = 1;
    }
    _29292 = _29291 + 1;
    _29291 = NOVALUE;
    _2 = (object)SEQ_PTR(_by_ref_58519);
    _29293 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_29293)) {
        _29294 = _29292 - _29293;
    }
    else {
        _29294 = binary_op(MINUS, _29292, _29293);
    }
    _29292 = NOVALUE;
    _29293 = NOVALUE;
    _2 = (object)SEQ_PTR(_45loop_stack_55390);
    if (!IS_ATOM_INT(_29294)){
        _29295 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_29294)->dbl));
    }
    else{
        _29295 = (object)*(((s1_ptr)_2)->base + _29294);
    }
    if (_29295 != 21)
    goto L2; // [70] 84

    /** parser.e:2129			emit_op(RETRY) -- for Translator to emit a label at the right place*/
    _47emit_op(184);
    goto L3; // [81] 129
L2: 

    /** parser.e:2131			if retry_addr[$+1-by_ref[1]] < 0 then*/
    if (IS_SEQUENCE(_45retry_addr_55382)){
            _29297 = SEQ_PTR(_45retry_addr_55382)->length;
    }
    else {
        _29297 = 1;
    }
    _29298 = _29297 + 1;
    _29297 = NOVALUE;
    _2 = (object)SEQ_PTR(_by_ref_58519);
    _29299 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_29299)) {
        _29300 = _29298 - _29299;
    }
    else {
        _29300 = binary_op(MINUS, _29298, _29299);
    }
    _29298 = NOVALUE;
    _29299 = NOVALUE;
    _2 = (object)SEQ_PTR(_45retry_addr_55382);
    if (!IS_ATOM_INT(_29300)){
        _29301 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_29300)->dbl));
    }
    else{
        _29301 = (object)*(((s1_ptr)_2)->base + _29300);
    }
    if (_29301 >= 0)
    goto L4; // [107] 121

    /** parser.e:2133				CompileErr(RETRY_STATEMENT_MUST_BE_INSIDE_A_LOOP)*/
    RefDS(_22190);
    _50CompileErr(131, _22190, 0);
L4: 

    /** parser.e:2135			emit_op(ELSE)*/
    _47emit_op(23);
L3: 

    /** parser.e:2138		emit_addr(retry_addr[$+1-by_ref[1]])*/
    if (IS_SEQUENCE(_45retry_addr_55382)){
            _29303 = SEQ_PTR(_45retry_addr_55382)->length;
    }
    else {
        _29303 = 1;
    }
    _29304 = _29303 + 1;
    _29303 = NOVALUE;
    _2 = (object)SEQ_PTR(_by_ref_58519);
    _29305 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_29305)) {
        _29306 = _29304 - _29305;
    }
    else {
        _29306 = binary_op(MINUS, _29304, _29305);
    }
    _29304 = NOVALUE;
    _29305 = NOVALUE;
    _2 = (object)SEQ_PTR(_45retry_addr_55382);
    if (!IS_ATOM_INT(_29306)){
        _29307 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_29306)->dbl));
    }
    else{
        _29307 = (object)*(((s1_ptr)_2)->base + _29306);
    }
    _47emit_addr(_29307);
    _29307 = NOVALUE;

    /** parser.e:2139		tok = by_ref[2]*/
    DeRef(_tok_58521);
    _2 = (object)SEQ_PTR(_by_ref_58519);
    _tok_58521 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_tok_58521);

    /** parser.e:2140		putback(tok)*/
    Ref(_tok_58521);
    _45putback(_tok_58521);

    /** parser.e:2141		NotReached(tok[T_ID], "retry")*/
    _2 = (object)SEQ_PTR(_tok_58521);
    _29309 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_29309);
    RefDS(_26527);
    _45NotReached(_29309, _26527);
    _29309 = NOVALUE;

    /** parser.e:2142	end procedure*/
    DeRefDS(_by_ref_58519);
    DeRef(_tok_58521);
    DeRef(_29300);
    _29300 = NOVALUE;
    DeRef(_29306);
    _29306 = NOVALUE;
    _29301 = NOVALUE;
    _29295 = NOVALUE;
    DeRef(_29294);
    _29294 = NOVALUE;
    return;
    ;
}


object _45in_switch()
{
    object _29314 = NOVALUE;
    object _29313 = NOVALUE;
    object _29312 = NOVALUE;
    object _29311 = NOVALUE;
    object _29310 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:2145		if length( if_stack ) and if_stack[$] = SWITCH then*/
    if (IS_SEQUENCE(_45if_stack_55391)){
            _29310 = SEQ_PTR(_45if_stack_55391)->length;
    }
    else {
        _29310 = 1;
    }
    if (_29310 == 0) {
        goto L1; // [8] 40
    }
    if (IS_SEQUENCE(_45if_stack_55391)){
            _29312 = SEQ_PTR(_45if_stack_55391)->length;
    }
    else {
        _29312 = 1;
    }
    _2 = (object)SEQ_PTR(_45if_stack_55391);
    _29313 = (object)*(((s1_ptr)_2)->base + _29312);
    _29314 = (_29313 == 185);
    _29313 = NOVALUE;
    if (_29314 == 0)
    {
        DeRef(_29314);
        _29314 = NOVALUE;
        goto L1; // [28] 40
    }
    else{
        DeRef(_29314);
        _29314 = NOVALUE;
    }

    /** parser.e:2146			return 1*/
    return 1;
    goto L2; // [37] 47
L1: 

    /** parser.e:2148			return 0*/
    return 0;
L2: 
    ;
}


void _45Break_statement()
{
    object _addr_inlined_AppendEList_at_65_58594 = NOVALUE;
    object _tok_58576 = NOVALUE;
    object _by_ref_58577 = NOVALUE;
    object _29325 = NOVALUE;
    object _29322 = NOVALUE;
    object _29321 = NOVALUE;
    object _29320 = NOVALUE;
    object _29319 = NOVALUE;
    object _29317 = NOVALUE;
    object _29315 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:2154		sequence by_ref*/

    /** parser.e:2156		if not length(if_labels) then*/
    if (IS_SEQUENCE(_45if_labels_55385)){
            _29315 = SEQ_PTR(_45if_labels_55385)->length;
    }
    else {
        _29315 = 1;
    }
    if (_29315 != 0)
    goto L1; // [10] 23
    _29315 = NOVALUE;

    /** parser.e:2157			CompileErr(BREAK_STATEMENT_MUST_BE_INSIDE_A_IF_OR_A_SWITCH_BLOCK)*/
    RefDS(_22190);
    _50CompileErr(40, _22190, 0);
L1: 

    /** parser.e:2160		by_ref = exit_level(next_token(),1)*/
    _29317 = _45next_token();
    _0 = _by_ref_58577;
    _by_ref_58577 = _45exit_level(_29317, 1);
    DeRef(_0);
    _29317 = NOVALUE;

    /** parser.e:2161		Leave_blocks( by_ref[1], CONDITIONAL_BLOCK )*/
    _2 = (object)SEQ_PTR(_by_ref_58577);
    _29319 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_29319);
    _65Leave_blocks(_29319, 2);
    _29319 = NOVALUE;

    /** parser.e:2162		emit_op(ELSE)*/
    _47emit_op(23);

    /** parser.e:2163		AppendEList(length(Code)+1)*/
    if (IS_SEQUENCE(_36Code_21859)){
            _29320 = SEQ_PTR(_36Code_21859)->length;
    }
    else {
        _29320 = 1;
    }
    _29321 = _29320 + 1;
    _29320 = NOVALUE;
    _addr_inlined_AppendEList_at_65_58594 = _29321;
    _29321 = NOVALUE;

    /** parser.e:393		break_list = append(break_list, addr)*/
    Append(&_45break_list_55374, _45break_list_55374, _addr_inlined_AppendEList_at_65_58594);

    /** parser.e:394	end procedure*/
    goto L2; // [80] 83
L2: 

    /** parser.e:2165		break_delay &= by_ref[1]*/
    _2 = (object)SEQ_PTR(_by_ref_58577);
    _29322 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_45break_delay_55375) && IS_ATOM(_29322)) {
        Ref(_29322);
        Append(&_45break_delay_55375, _45break_delay_55375, _29322);
    }
    else if (IS_ATOM(_45break_delay_55375) && IS_SEQUENCE(_29322)) {
    }
    else {
        Concat((object_ptr)&_45break_delay_55375, _45break_delay_55375, _29322);
    }
    _29322 = NOVALUE;

    /** parser.e:2166		emit_forward_addr()    -- to be back-patched*/
    _45emit_forward_addr();

    /** parser.e:2167		tok = by_ref[2]*/
    DeRef(_tok_58576);
    _2 = (object)SEQ_PTR(_by_ref_58577);
    _tok_58576 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_tok_58576);

    /** parser.e:2168		putback(tok)*/
    Ref(_tok_58576);
    _45putback(_tok_58576);

    /** parser.e:2169		NotReached(tok[T_ID], "break")*/
    _2 = (object)SEQ_PTR(_tok_58576);
    _29325 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_29325);
    RefDS(_26417);
    _45NotReached(_29325, _26417);
    _29325 = NOVALUE;

    /** parser.e:2170	end procedure*/
    DeRef(_tok_58576);
    DeRefDS(_by_ref_58577);
    return;
    ;
}


object _45finish_block_header(object _opcode_58603)
{
    object _tok_58605 = NOVALUE;
    object _labbel_58606 = NOVALUE;
    object _has_entry_58607 = NOVALUE;
    object _29379 = NOVALUE;
    object _29378 = NOVALUE;
    object _29377 = NOVALUE;
    object _29376 = NOVALUE;
    object _29373 = NOVALUE;
    object _29368 = NOVALUE;
    object _29365 = NOVALUE;
    object _29363 = NOVALUE;
    object _29360 = NOVALUE;
    object _29359 = NOVALUE;
    object _29357 = NOVALUE;
    object _29354 = NOVALUE;
    object _29351 = NOVALUE;
    object _29350 = NOVALUE;
    object _29348 = NOVALUE;
    object _29346 = NOVALUE;
    object _29343 = NOVALUE;
    object _29340 = NOVALUE;
    object _29339 = NOVALUE;
    object _29337 = NOVALUE;
    object _29335 = NOVALUE;
    object _29334 = NOVALUE;
    object _29333 = NOVALUE;
    object _29330 = NOVALUE;
    object _29327 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:2176		object labbel*/

    /** parser.e:2177		integer has_entry*/

    /** parser.e:2179		tok = next_token()*/
    _0 = _tok_58605;
    _tok_58605 = _45next_token();
    DeRef(_0);

    /** parser.e:2180		has_entry=0*/
    _has_entry_58607 = 0;

    /** parser.e:2182		if tok[T_ID] = WITH then*/
    _2 = (object)SEQ_PTR(_tok_58605);
    _29327 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29327, 420)){
        _29327 = NOVALUE;
        goto L1; // [27] 160
    }
    _29327 = NOVALUE;

    /** parser.e:2183			tok = next_token()*/
    _0 = _tok_58605;
    _tok_58605 = _45next_token();
    DeRef(_0);

    /** parser.e:2184			switch tok[T_ID] do*/
    _2 = (object)SEQ_PTR(_tok_58605);
    _29330 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_29330) ){
        goto L2; // [44] 140
    }
    if(!IS_ATOM_INT(_29330)){
        if( (DBL_PTR(_29330)->dbl != (eudouble) ((object) DBL_PTR(_29330)->dbl) ) ){
            goto L2; // [44] 140
        }
        _0 = (object) DBL_PTR(_29330)->dbl;
    }
    else {
        _0 = _29330;
    };
    _29330 = NOVALUE;
    switch ( _0 ){ 

        /** parser.e:2185			    case ENTRY then*/
        case 424:

        /** parser.e:2186					if not (opcode = WHILE or opcode = LOOP) then*/
        _29333 = (_opcode_58603 == 47);
        if (_29333 != 0) {
            DeRef(_29334);
            _29334 = 1;
            goto L3; // [61] 75
        }
        _29335 = (_opcode_58603 == 422);
        _29334 = (_29335 != 0);
L3: 
        if (_29334 != 0)
        goto L4; // [75] 88
        _29334 = NOVALUE;

        /** parser.e:2187						CompileErr(MSG_WITH_ENTRY_IS_ONLY_VALID_ON_A_WHILE_OR_LOOP_STATEMENT)*/
        RefDS(_22190);
        _50CompileErr(14, _22190, 0);
L4: 

        /** parser.e:2190				    has_entry = 1*/
        _has_entry_58607 = 1;
        goto L5; // [93] 152

        /** parser.e:2192				case FALLTHRU then*/
        case 431:

        /** parser.e:2193					if not opcode = SWITCH then*/
        _29337 = (_opcode_58603 == 0);
        if (_29337 != 185)
        goto L6; // [106] 120

        /** parser.e:2194						CompileErr(MSG_WITH_FALLTHRU_IS_ONLY_VALID_IN_A_SWITCH_STATEMENT)*/
        RefDS(_22190);
        _50CompileErr(13, _22190, 0);
L6: 

        /** parser.e:2197					switch_stack[$][SWITCH_FALLTHRU] = 1*/
        if (IS_SEQUENCE(_45switch_stack_55605)){
                _29339 = SEQ_PTR(_45switch_stack_55605)->length;
        }
        else {
            _29339 = 1;
        }
        _2 = (object)SEQ_PTR(_45switch_stack_55605);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _45switch_stack_55605 = MAKE_SEQ(_2);
        }
        _3 = (object)(_29339 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 5);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = 1;
        DeRef(_1);
        _29340 = NOVALUE;
        goto L5; // [136] 152

        /** parser.e:2199				case else*/
        default:
L2: 

        /** parser.e:2200				    CompileErr(AN_UNKNOWN_WITHWITHOUT_OPTION_HAS_BEEN_SPECIFIED)*/
        RefDS(_22190);
        _50CompileErr(27, _22190, 0);
    ;}L5: 

    /** parser.e:2203	        tok = next_token()*/
    _0 = _tok_58605;
    _tok_58605 = _45next_token();
    DeRef(_0);
    goto L7; // [157] 250
L1: 

    /** parser.e:2204		elsif tok[T_ID] = WITHOUT then*/
    _2 = (object)SEQ_PTR(_tok_58605);
    _29343 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29343, 421)){
        _29343 = NOVALUE;
        goto L8; // [170] 249
    }
    _29343 = NOVALUE;

    /** parser.e:2205			tok = next_token()*/
    _0 = _tok_58605;
    _tok_58605 = _45next_token();
    DeRef(_0);

    /** parser.e:2206			if tok[T_ID] = FALLTHRU then*/
    _2 = (object)SEQ_PTR(_tok_58605);
    _29346 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29346, 431)){
        _29346 = NOVALUE;
        goto L9; // [189] 233
    }
    _29346 = NOVALUE;

    /** parser.e:2207				if not opcode = SWITCH then*/
    _29348 = (_opcode_58603 == 0);
    if (_29348 != 185)
    goto LA; // [200] 214

    /** parser.e:2208					CompileErr(MSG_WITHOUT_FALLTHRU_IS_ONLY_VALID_IN_A_SWITCH_STATEMENT)*/
    RefDS(_22190);
    _50CompileErr(15, _22190, 0);
LA: 

    /** parser.e:2211				switch_stack[$][SWITCH_FALLTHRU] = 0*/
    if (IS_SEQUENCE(_45switch_stack_55605)){
            _29350 = SEQ_PTR(_45switch_stack_55605)->length;
    }
    else {
        _29350 = 1;
    }
    _2 = (object)SEQ_PTR(_45switch_stack_55605);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _45switch_stack_55605 = MAKE_SEQ(_2);
    }
    _3 = (object)(_29350 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);
    _29351 = NOVALUE;
    goto LB; // [230] 243
L9: 

    /** parser.e:2214				CompileErr(AN_UNKNOWN_WITHWITHOUT_OPTION_HAS_BEEN_SPECIFIED)*/
    RefDS(_22190);
    _50CompileErr(27, _22190, 0);
LB: 

    /** parser.e:2216	        tok = next_token()*/
    _0 = _tok_58605;
    _tok_58605 = _45next_token();
    DeRef(_0);
L8: 
L7: 

    /** parser.e:2219		labbel=0*/
    DeRef(_labbel_58606);
    _labbel_58606 = 0;

    /** parser.e:2220		if tok[T_ID]=LABEL then*/
    _2 = (object)SEQ_PTR(_tok_58605);
    _29354 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29354, 419)){
        _29354 = NOVALUE;
        goto LC; // [265] 329
    }
    _29354 = NOVALUE;

    /** parser.e:2221			tok = next_token()*/
    _0 = _tok_58605;
    _tok_58605 = _45next_token();
    DeRef(_0);

    /** parser.e:2222			if tok[T_ID] != STRING then*/
    _2 = (object)SEQ_PTR(_tok_58605);
    _29357 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _29357, 503)){
        _29357 = NOVALUE;
        goto LD; // [284] 298
    }
    _29357 = NOVALUE;

    /** parser.e:2223				CompileErr(A_LABEL_CLAUSE_MUST_BE_FOLLOWED_BY_A_LITERAL_STRING)*/
    RefDS(_22190);
    _50CompileErr(38, _22190, 0);
LD: 

    /** parser.e:2225			labbel = SymTab[tok[T_SYM]][S_OBJ]*/
    _2 = (object)SEQ_PTR(_tok_58605);
    _29359 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!IS_ATOM_INT(_29359)){
        _29360 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_29359)->dbl));
    }
    else{
        _29360 = (object)*(((s1_ptr)_2)->base + _29359);
    }
    DeRef(_labbel_58606);
    _2 = (object)SEQ_PTR(_29360);
    _labbel_58606 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_labbel_58606);
    _29360 = NOVALUE;

    /** parser.e:2226			block_label( labbel )*/
    Ref(_labbel_58606);
    _65block_label(_labbel_58606);

    /** parser.e:2227			tok = next_token()*/
    _0 = _tok_58605;
    _tok_58605 = _45next_token();
    DeRef(_0);
LC: 

    /** parser.e:2229		if opcode = IF or opcode = SWITCH then*/
    _29363 = (_opcode_58603 == 20);
    if (_29363 != 0) {
        goto LE; // [337] 352
    }
    _29365 = (_opcode_58603 == 185);
    if (_29365 == 0)
    {
        DeRef(_29365);
        _29365 = NOVALUE;
        goto LF; // [348] 363
    }
    else{
        DeRef(_29365);
        _29365 = NOVALUE;
    }
LE: 

    /** parser.e:2230			if_labels = append(if_labels,labbel)*/
    Ref(_labbel_58606);
    Append(&_45if_labels_55385, _45if_labels_55385, _labbel_58606);
    goto L10; // [360] 372
LF: 

    /** parser.e:2232			loop_labels = append(loop_labels,labbel)*/
    Ref(_labbel_58606);
    Append(&_45loop_labels_55384, _45loop_labels_55384, _labbel_58606);
L10: 

    /** parser.e:2234		if block_index=length(block_list) then*/
    if (IS_SEQUENCE(_45block_list_55386)){
            _29368 = SEQ_PTR(_45block_list_55386)->length;
    }
    else {
        _29368 = 1;
    }
    if (_45block_index_55387 != _29368)
    goto L11; // [381] 404

    /** parser.e:2235		    block_list &= opcode*/
    Append(&_45block_list_55386, _45block_list_55386, _opcode_58603);

    /** parser.e:2236		    block_index += 1*/
    _45block_index_55387 = _45block_index_55387 + 1;
    goto L12; // [401] 423
L11: 

    /** parser.e:2238		    block_index += 1*/
    _45block_index_55387 = _45block_index_55387 + 1;

    /** parser.e:2239		    block_list[block_index] = opcode*/
    _2 = (object)SEQ_PTR(_45block_list_55386);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _45block_list_55386 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _45block_index_55387);
    *(intptr_t *)_2 = _opcode_58603;
L12: 

    /** parser.e:2241		if tok[T_ID]=ENTRY then*/
    _2 = (object)SEQ_PTR(_tok_58605);
    _29373 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29373, 424)){
        _29373 = NOVALUE;
        goto L13; // [433] 463
    }
    _29373 = NOVALUE;

    /** parser.e:2242		    if has_entry then*/
    if (_has_entry_58607 == 0)
    {
        goto L14; // [439] 452
    }
    else{
    }

    /** parser.e:2243		        CompileErr(DUPLICATE_ENTRY_CLAUSE_IN_A_LOOP_HEADER)*/
    RefDS(_22190);
    _50CompileErr(64, _22190, 0);
L14: 

    /** parser.e:2245		    has_entry=1*/
    _has_entry_58607 = 1;

    /** parser.e:2246		    tok=next_token()*/
    _0 = _tok_58605;
    _tok_58605 = _45next_token();
    DeRef(_0);
L13: 

    /** parser.e:2248		if has_entry and (opcode = IF or opcode = SWITCH) then*/
    if (_has_entry_58607 == 0) {
        goto L15; // [465] 503
    }
    _29377 = (_opcode_58603 == 20);
    if (_29377 != 0) {
        DeRef(_29378);
        _29378 = 1;
        goto L16; // [475] 489
    }
    _29379 = (_opcode_58603 == 185);
    _29378 = (_29379 != 0);
L16: 
    if (_29378 == 0)
    {
        _29378 = NOVALUE;
        goto L15; // [490] 503
    }
    else{
        _29378 = NOVALUE;
    }

    /** parser.e:2249			CompileErr(ENTRY_KEYWORD_IS_NOT_SUPPORTED_INSIDE_AN_IF_OR_SWITCH_BLOCK_HEADER)*/
    RefDS(_22190);
    _50CompileErr(80, _22190, 0);
L15: 

    /** parser.e:2251		if opcode = IF then*/
    if (_opcode_58603 != 20)
    goto L17; // [507] 523

    /** parser.e:2252			opcode = THEN*/
    _opcode_58603 = 410;
    goto L18; // [520] 533
L17: 

    /** parser.e:2254			opcode = DO*/
    _opcode_58603 = 411;
L18: 

    /** parser.e:2256		putback(tok)*/
    Ref(_tok_58605);
    _45putback(_tok_58605);

    /** parser.e:2257		tok_match(opcode)*/
    _45tok_match(_opcode_58603, 0);

    /** parser.e:2258		return has_entry*/
    DeRef(_tok_58605);
    DeRef(_labbel_58606);
    DeRef(_29333);
    _29333 = NOVALUE;
    _29359 = NOVALUE;
    DeRef(_29348);
    _29348 = NOVALUE;
    DeRef(_29379);
    _29379 = NOVALUE;
    DeRef(_29377);
    _29377 = NOVALUE;
    DeRef(_29363);
    _29363 = NOVALUE;
    DeRef(_29335);
    _29335 = NOVALUE;
    DeRef(_29337);
    _29337 = NOVALUE;
    return _has_entry_58607;
    ;
}


void _45If_statement()
{
    object _addr_inlined_AppendEList_at_624_58861 = NOVALUE;
    object _addr_inlined_AppendEList_at_260_58790 = NOVALUE;
    object _tok_58733 = NOVALUE;
    object _prev_false_58734 = NOVALUE;
    object _prev_false2_58735 = NOVALUE;
    object _elist_base_58736 = NOVALUE;
    object _temps_58744 = NOVALUE;
    object _31960 = NOVALUE;
    object _29445 = NOVALUE;
    object _29444 = NOVALUE;
    object _29441 = NOVALUE;
    object _29440 = NOVALUE;
    object _29438 = NOVALUE;
    object _29437 = NOVALUE;
    object _29436 = NOVALUE;
    object _29434 = NOVALUE;
    object _29433 = NOVALUE;
    object _29431 = NOVALUE;
    object _29430 = NOVALUE;
    object _29429 = NOVALUE;
    object _29427 = NOVALUE;
    object _29426 = NOVALUE;
    object _29424 = NOVALUE;
    object _29423 = NOVALUE;
    object _29422 = NOVALUE;
    object _29421 = NOVALUE;
    object _29419 = NOVALUE;
    object _29418 = NOVALUE;
    object _29415 = NOVALUE;
    object _29413 = NOVALUE;
    object _29412 = NOVALUE;
    object _29411 = NOVALUE;
    object _29408 = NOVALUE;
    object _29405 = NOVALUE;
    object _29404 = NOVALUE;
    object _29402 = NOVALUE;
    object _29401 = NOVALUE;
    object _29399 = NOVALUE;
    object _29398 = NOVALUE;
    object _29396 = NOVALUE;
    object _29393 = NOVALUE;
    object _29391 = NOVALUE;
    object _29390 = NOVALUE;
    object _29389 = NOVALUE;
    object _29385 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:2265		integer prev_false*/

    /** parser.e:2266		integer prev_false2*/

    /** parser.e:2267		integer elist_base*/

    /** parser.e:2269		if_stack &= IF*/
    Append(&_45if_stack_55391, _45if_stack_55391, 20);

    /** parser.e:2271		Start_block( IF )*/
    _65Start_block(20, 0);

    /** parser.e:2273		elist_base = length(break_list)*/
    if (IS_SEQUENCE(_45break_list_55374)){
            _elist_base_58736 = SEQ_PTR(_45break_list_55374)->length;
    }
    else {
        _elist_base_58736 = 1;
    }

    /** parser.e:2274		short_circuit += 1*/
    _45short_circuit_55356 = _45short_circuit_55356 + 1;

    /** parser.e:2275		short_circuit_B = FALSE*/
    _45short_circuit_B_55358 = _13FALSE_445;

    /** parser.e:2276		SC1_type = 0*/
    _45SC1_type_55361 = 0;

    /** parser.e:2277		Expr()*/
    _45Expr();

    /** parser.e:2279		sequence temps = get_temps()*/
    _31960 = Repeat(_22190, 2);
    _0 = _temps_58744;
    _temps_58744 = _47get_temps(_31960);
    DeRef(_0);
    _31960 = NOVALUE;

    /** parser.e:2281		emit_op(IF)*/
    _47emit_op(20);

    /** parser.e:2282		prev_false = length(Code)+1*/
    if (IS_SEQUENCE(_36Code_21859)){
            _29385 = SEQ_PTR(_36Code_21859)->length;
    }
    else {
        _29385 = 1;
    }
    _prev_false_58734 = _29385 + 1;
    _29385 = NOVALUE;

    /** parser.e:2283		emit_forward_addr() -- to be patched*/
    _45emit_forward_addr();

    /** parser.e:2284		prev_false2=finish_block_header(IF)  -- 0*/
    _prev_false2_58735 = _45finish_block_header(20);
    if (!IS_ATOM_INT(_prev_false2_58735)) {
        _1 = (object)(DBL_PTR(_prev_false2_58735)->dbl);
        DeRefDS(_prev_false2_58735);
        _prev_false2_58735 = _1;
    }

    /** parser.e:2285		if SC1_type = OR then*/
    if (_45SC1_type_55361 != 9)
    goto L1; // [106] 159

    /** parser.e:2286			backpatch(SC1_patch-3, SC1_OR_IF)*/
    _29389 = _45SC1_patch_55360 - 3;
    if ((object)((uintptr_t)_29389 +(uintptr_t) HIGH_BITS) >= 0){
        _29389 = NewDouble((eudouble)_29389);
    }
    _47backpatch(_29389, 147);
    _29389 = NOVALUE;

    /** parser.e:2287			if TRANSLATE then*/
    if (_36TRANSLATE_21369 == 0)
    {
        goto L2; // [128] 139
    }
    else{
    }

    /** parser.e:2288				emit_op(NOP1)  -- to get label here*/
    _47emit_op(159);
L2: 

    /** parser.e:2290			backpatch(SC1_patch, length(Code)+1)*/
    if (IS_SEQUENCE(_36Code_21859)){
            _29390 = SEQ_PTR(_36Code_21859)->length;
    }
    else {
        _29390 = 1;
    }
    _29391 = _29390 + 1;
    _29390 = NOVALUE;
    _47backpatch(_45SC1_patch_55360, _29391);
    _29391 = NOVALUE;
    goto L3; // [156] 192
L1: 

    /** parser.e:2291		elsif SC1_type = AND then*/
    if (_45SC1_type_55361 != 8)
    goto L4; // [165] 191

    /** parser.e:2292			backpatch(SC1_patch-3, SC1_AND_IF)*/
    _29393 = _45SC1_patch_55360 - 3;
    if ((object)((uintptr_t)_29393 +(uintptr_t) HIGH_BITS) >= 0){
        _29393 = NewDouble((eudouble)_29393);
    }
    _47backpatch(_29393, 146);
    _29393 = NOVALUE;

    /** parser.e:2293			prev_false2 = SC1_patch*/
    _prev_false2_58735 = _45SC1_patch_55360;
L4: 
L3: 

    /** parser.e:2295		short_circuit -= 1*/
    _45short_circuit_55356 = _45short_circuit_55356 - 1;

    /** parser.e:2298		Statement_list()*/
    _45Statement_list();

    /** parser.e:2299		tok = next_token()*/
    _0 = _tok_58733;
    _tok_58733 = _45next_token();
    DeRef(_0);

    /** parser.e:2301		while tok[T_ID] = ELSIF do*/
L5: 
    _2 = (object)SEQ_PTR(_tok_58733);
    _29396 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29396, 414)){
        _29396 = NOVALUE;
        goto L6; // [222] 530
    }
    _29396 = NOVALUE;

    /** parser.e:2302			Sibling_block( IF )*/
    _65Sibling_block(20);

    /** parser.e:2305			emit_op(ELSE)*/
    _47emit_op(23);

    /** parser.e:2306			AppendEList(length(Code)+1)*/
    if (IS_SEQUENCE(_36Code_21859)){
            _29398 = SEQ_PTR(_36Code_21859)->length;
    }
    else {
        _29398 = 1;
    }
    _29399 = _29398 + 1;
    _29398 = NOVALUE;
    _addr_inlined_AppendEList_at_260_58790 = _29399;
    _29399 = NOVALUE;

    /** parser.e:393		break_list = append(break_list, addr)*/
    Append(&_45break_list_55374, _45break_list_55374, _addr_inlined_AppendEList_at_260_58790);

    /** parser.e:394	end procedure*/
    goto L7; // [266] 269
L7: 

    /** parser.e:2307			break_delay &= 1*/
    Append(&_45break_delay_55375, _45break_delay_55375, 1);

    /** parser.e:2308			emit_forward_addr()  -- to be patched*/
    _45emit_forward_addr();

    /** parser.e:2309			if TRANSLATE then*/
    if (_36TRANSLATE_21369 == 0)
    {
        goto L8; // [287] 298
    }
    else{
    }

    /** parser.e:2310				emit_op(NOP1)*/
    _47emit_op(159);
L8: 

    /** parser.e:2312			backpatch(prev_false, length(Code)+1)*/
    if (IS_SEQUENCE(_36Code_21859)){
            _29401 = SEQ_PTR(_36Code_21859)->length;
    }
    else {
        _29401 = 1;
    }
    _29402 = _29401 + 1;
    _29401 = NOVALUE;
    _47backpatch(_prev_false_58734, _29402);
    _29402 = NOVALUE;

    /** parser.e:2313			if prev_false2 != 0 then*/
    if (_prev_false2_58735 == 0)
    goto L9; // [315] 335

    /** parser.e:2314				backpatch(prev_false2, length(Code)+1)*/
    if (IS_SEQUENCE(_36Code_21859)){
            _29404 = SEQ_PTR(_36Code_21859)->length;
    }
    else {
        _29404 = 1;
    }
    _29405 = _29404 + 1;
    _29404 = NOVALUE;
    _47backpatch(_prev_false2_58735, _29405);
    _29405 = NOVALUE;
L9: 

    /** parser.e:2317			StartSourceLine(TRUE)*/
    _47StartSourceLine(_13TRUE_447, 0, 2);

    /** parser.e:2318			short_circuit += 1*/
    _45short_circuit_55356 = _45short_circuit_55356 + 1;

    /** parser.e:2319			short_circuit_B = FALSE*/
    _45short_circuit_B_55358 = _13FALSE_445;

    /** parser.e:2320			SC1_type = 0*/
    _45SC1_type_55361 = 0;

    /** parser.e:2322			push_temps( temps )*/
    RefDS(_temps_58744);
    _47push_temps(_temps_58744);

    /** parser.e:2323			Expr()*/
    _45Expr();

    /** parser.e:2325			temps = get_temps( temps )*/
    RefDS(_temps_58744);
    _0 = _temps_58744;
    _temps_58744 = _47get_temps(_temps_58744);
    DeRefDS(_0);

    /** parser.e:2327			emit_op(IF)*/
    _47emit_op(20);

    /** parser.e:2328			prev_false = length(Code)+1*/
    if (IS_SEQUENCE(_36Code_21859)){
            _29408 = SEQ_PTR(_36Code_21859)->length;
    }
    else {
        _29408 = 1;
    }
    _prev_false_58734 = _29408 + 1;
    _29408 = NOVALUE;

    /** parser.e:2329			prev_false2 = 0*/
    _prev_false2_58735 = 0;

    /** parser.e:2330			emit_forward_addr() -- to be patched*/
    _45emit_forward_addr();

    /** parser.e:2331			if SC1_type = OR then*/
    if (_45SC1_type_55361 != 9)
    goto LA; // [414] 467

    /** parser.e:2332				backpatch(SC1_patch-3, SC1_OR_IF)*/
    _29411 = _45SC1_patch_55360 - 3;
    if ((object)((uintptr_t)_29411 +(uintptr_t) HIGH_BITS) >= 0){
        _29411 = NewDouble((eudouble)_29411);
    }
    _47backpatch(_29411, 147);
    _29411 = NOVALUE;

    /** parser.e:2333				if TRANSLATE then*/
    if (_36TRANSLATE_21369 == 0)
    {
        goto LB; // [436] 447
    }
    else{
    }

    /** parser.e:2334					emit_op(NOP1)*/
    _47emit_op(159);
LB: 

    /** parser.e:2336				backpatch(SC1_patch, length(Code)+1)*/
    if (IS_SEQUENCE(_36Code_21859)){
            _29412 = SEQ_PTR(_36Code_21859)->length;
    }
    else {
        _29412 = 1;
    }
    _29413 = _29412 + 1;
    _29412 = NOVALUE;
    _47backpatch(_45SC1_patch_55360, _29413);
    _29413 = NOVALUE;
    goto LC; // [464] 500
LA: 

    /** parser.e:2337			elsif SC1_type = AND then*/
    if (_45SC1_type_55361 != 8)
    goto LD; // [473] 499

    /** parser.e:2338				backpatch(SC1_patch-3, SC1_AND_IF)*/
    _29415 = _45SC1_patch_55360 - 3;
    if ((object)((uintptr_t)_29415 +(uintptr_t) HIGH_BITS) >= 0){
        _29415 = NewDouble((eudouble)_29415);
    }
    _47backpatch(_29415, 146);
    _29415 = NOVALUE;

    /** parser.e:2339				prev_false2 = SC1_patch*/
    _prev_false2_58735 = _45SC1_patch_55360;
LD: 
LC: 

    /** parser.e:2341			short_circuit -= 1*/
    _45short_circuit_55356 = _45short_circuit_55356 - 1;

    /** parser.e:2342			tok_match(THEN)*/
    _45tok_match(410, 0);

    /** parser.e:2345			Statement_list()*/
    _45Statement_list();

    /** parser.e:2346			tok = next_token()*/
    _0 = _tok_58733;
    _tok_58733 = _45next_token();
    DeRef(_0);

    /** parser.e:2347		end while*/
    goto L5; // [527] 214
L6: 

    /** parser.e:2349		if tok[T_ID] = ELSE or length(temps[1]) then*/
    _2 = (object)SEQ_PTR(_tok_58733);
    _29418 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_29418)) {
        _29419 = (_29418 == 23);
    }
    else {
        _29419 = binary_op(EQUALS, _29418, 23);
    }
    _29418 = NOVALUE;
    if (IS_ATOM_INT(_29419)) {
        if (_29419 != 0) {
            goto LE; // [544] 560
        }
    }
    else {
        if (DBL_PTR(_29419)->dbl != 0.0) {
            goto LE; // [544] 560
        }
    }
    _2 = (object)SEQ_PTR(_temps_58744);
    _29421 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_29421)){
            _29422 = SEQ_PTR(_29421)->length;
    }
    else {
        _29422 = 1;
    }
    _29421 = NOVALUE;
    if (_29422 == 0)
    {
        _29422 = NOVALUE;
        goto LF; // [556] 715
    }
    else{
        _29422 = NOVALUE;
    }
LE: 

    /** parser.e:2354			Sibling_block( IF )*/
    _65Sibling_block(20);

    /** parser.e:2356			StartSourceLine(FALSE, , COVERAGE_SUPPRESS )*/
    _47StartSourceLine(_13FALSE_445, 0, 1);

    /** parser.e:2357			emit_op(ELSE)*/
    _47emit_op(23);

    /** parser.e:2358			AppendEList(length(Code)+1)*/
    if (IS_SEQUENCE(_36Code_21859)){
            _29423 = SEQ_PTR(_36Code_21859)->length;
    }
    else {
        _29423 = 1;
    }
    _29424 = _29423 + 1;
    _29423 = NOVALUE;
    _addr_inlined_AppendEList_at_624_58861 = _29424;
    _29424 = NOVALUE;

    /** parser.e:393		break_list = append(break_list, addr)*/
    Append(&_45break_list_55374, _45break_list_55374, _addr_inlined_AppendEList_at_624_58861);

    /** parser.e:394	end procedure*/
    goto L10; // [611] 614
L10: 

    /** parser.e:2359			break_delay &= 1*/
    Append(&_45break_delay_55375, _45break_delay_55375, 1);

    /** parser.e:2360			emit_forward_addr() -- to be patched*/
    _45emit_forward_addr();

    /** parser.e:2361			if TRANSLATE then*/
    if (_36TRANSLATE_21369 == 0)
    {
        goto L11; // [632] 643
    }
    else{
    }

    /** parser.e:2362				emit_op(NOP1)*/
    _47emit_op(159);
L11: 

    /** parser.e:2364			backpatch(prev_false, length(Code)+1)*/
    if (IS_SEQUENCE(_36Code_21859)){
            _29426 = SEQ_PTR(_36Code_21859)->length;
    }
    else {
        _29426 = 1;
    }
    _29427 = _29426 + 1;
    _29426 = NOVALUE;
    _47backpatch(_prev_false_58734, _29427);
    _29427 = NOVALUE;

    /** parser.e:2365			if prev_false2 != 0 then*/
    if (_prev_false2_58735 == 0)
    goto L12; // [660] 680

    /** parser.e:2366				backpatch(prev_false2, length(Code)+1)*/
    if (IS_SEQUENCE(_36Code_21859)){
            _29429 = SEQ_PTR(_36Code_21859)->length;
    }
    else {
        _29429 = 1;
    }
    _29430 = _29429 + 1;
    _29429 = NOVALUE;
    _47backpatch(_prev_false2_58735, _29430);
    _29430 = NOVALUE;
L12: 

    /** parser.e:2369			push_temps( temps )*/
    RefDS(_temps_58744);
    _47push_temps(_temps_58744);

    /** parser.e:2371			if tok[T_ID] = ELSE then*/
    _2 = (object)SEQ_PTR(_tok_58733);
    _29431 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29431, 23)){
        _29431 = NOVALUE;
        goto L13; // [695] 706
    }
    _29431 = NOVALUE;

    /** parser.e:2372				Statement_list()*/
    _45Statement_list();
    goto L14; // [703] 773
L13: 

    /** parser.e:2374				putback(tok)*/
    Ref(_tok_58733);
    _45putback(_tok_58733);
    goto L14; // [712] 773
LF: 

    /** parser.e:2377			putback(tok)*/
    Ref(_tok_58733);
    _45putback(_tok_58733);

    /** parser.e:2378			if TRANSLATE then*/
    if (_36TRANSLATE_21369 == 0)
    {
        goto L15; // [724] 735
    }
    else{
    }

    /** parser.e:2379				emit_op(NOP1)*/
    _47emit_op(159);
L15: 

    /** parser.e:2381			backpatch(prev_false, length(Code)+1)*/
    if (IS_SEQUENCE(_36Code_21859)){
            _29433 = SEQ_PTR(_36Code_21859)->length;
    }
    else {
        _29433 = 1;
    }
    _29434 = _29433 + 1;
    _29433 = NOVALUE;
    _47backpatch(_prev_false_58734, _29434);
    _29434 = NOVALUE;

    /** parser.e:2382			if prev_false2 != 0 then*/
    if (_prev_false2_58735 == 0)
    goto L16; // [752] 772

    /** parser.e:2383				backpatch(prev_false2, length(Code)+1)*/
    if (IS_SEQUENCE(_36Code_21859)){
            _29436 = SEQ_PTR(_36Code_21859)->length;
    }
    else {
        _29436 = 1;
    }
    _29437 = _29436 + 1;
    _29436 = NOVALUE;
    _47backpatch(_prev_false2_58735, _29437);
    _29437 = NOVALUE;
L16: 
L14: 

    /** parser.e:2387		tok_match(END)*/
    _45tok_match(402, 0);

    /** parser.e:2388		tok_match(IF, END)*/
    _45tok_match(20, 402);

    /** parser.e:2390		End_block( IF )*/
    _65End_block(20);

    /** parser.e:2392		if TRANSLATE then*/
    if (_36TRANSLATE_21369 == 0)
    {
        goto L17; // [802] 825
    }
    else{
    }

    /** parser.e:2393			if length(break_list) > elist_base then*/
    if (IS_SEQUENCE(_45break_list_55374)){
            _29438 = SEQ_PTR(_45break_list_55374)->length;
    }
    else {
        _29438 = 1;
    }
    if (_29438 <= _elist_base_58736)
    goto L18; // [812] 824

    /** parser.e:2394				emit_op(NOP1)  -- to emit label here*/
    _47emit_op(159);
L18: 
L17: 

    /** parser.e:2397		PatchEList(elist_base)*/
    _45PatchEList(_elist_base_58736);

    /** parser.e:2398		if_labels = if_labels[1..$-1]*/
    if (IS_SEQUENCE(_45if_labels_55385)){
            _29440 = SEQ_PTR(_45if_labels_55385)->length;
    }
    else {
        _29440 = 1;
    }
    _29441 = _29440 - 1;
    _29440 = NOVALUE;
    rhs_slice_target = (object_ptr)&_45if_labels_55385;
    RHS_Slice(_45if_labels_55385, 1, _29441);

    /** parser.e:2399		block_index -= 1*/
    _45block_index_55387 = _45block_index_55387 - 1;

    /** parser.e:2400		if_stack = if_stack[1..$-1]*/
    if (IS_SEQUENCE(_45if_stack_55391)){
            _29444 = SEQ_PTR(_45if_stack_55391)->length;
    }
    else {
        _29444 = 1;
    }
    _29445 = _29444 - 1;
    _29444 = NOVALUE;
    rhs_slice_target = (object_ptr)&_45if_stack_55391;
    RHS_Slice(_45if_stack_55391, 1, _29445);

    /** parser.e:2402	end procedure*/
    DeRef(_tok_58733);
    DeRef(_temps_58744);
    _29421 = NOVALUE;
    _29441 = NOVALUE;
    DeRef(_29419);
    _29419 = NOVALUE;
    _29445 = NOVALUE;
    return;
    ;
}


void _45exit_loop(object _exit_base_58921)
{
    object _29460 = NOVALUE;
    object _29459 = NOVALUE;
    object _29457 = NOVALUE;
    object _29456 = NOVALUE;
    object _29454 = NOVALUE;
    object _29453 = NOVALUE;
    object _29451 = NOVALUE;
    object _29450 = NOVALUE;
    object _29448 = NOVALUE;
    object _29447 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:2405		PatchXList(exit_base)*/
    _45PatchXList(_exit_base_58921);

    /** parser.e:2406		loop_labels = loop_labels[1..$-1]*/
    if (IS_SEQUENCE(_45loop_labels_55384)){
            _29447 = SEQ_PTR(_45loop_labels_55384)->length;
    }
    else {
        _29447 = 1;
    }
    _29448 = _29447 - 1;
    _29447 = NOVALUE;
    rhs_slice_target = (object_ptr)&_45loop_labels_55384;
    RHS_Slice(_45loop_labels_55384, 1, _29448);

    /** parser.e:2407		loop_stack = loop_stack[1..$-1]*/
    if (IS_SEQUENCE(_45loop_stack_55390)){
            _29450 = SEQ_PTR(_45loop_stack_55390)->length;
    }
    else {
        _29450 = 1;
    }
    _29451 = _29450 - 1;
    _29450 = NOVALUE;
    rhs_slice_target = (object_ptr)&_45loop_stack_55390;
    RHS_Slice(_45loop_stack_55390, 1, _29451);

    /** parser.e:2408		continue_addr = continue_addr[1..$-1]*/
    if (IS_SEQUENCE(_45continue_addr_55381)){
            _29453 = SEQ_PTR(_45continue_addr_55381)->length;
    }
    else {
        _29453 = 1;
    }
    _29454 = _29453 - 1;
    _29453 = NOVALUE;
    rhs_slice_target = (object_ptr)&_45continue_addr_55381;
    RHS_Slice(_45continue_addr_55381, 1, _29454);

    /** parser.e:2409		retry_addr = retry_addr[1..$-1]*/
    if (IS_SEQUENCE(_45retry_addr_55382)){
            _29456 = SEQ_PTR(_45retry_addr_55382)->length;
    }
    else {
        _29456 = 1;
    }
    _29457 = _29456 - 1;
    _29456 = NOVALUE;
    rhs_slice_target = (object_ptr)&_45retry_addr_55382;
    RHS_Slice(_45retry_addr_55382, 1, _29457);

    /** parser.e:2410		entry_addr = entry_addr[1..$-1]*/
    if (IS_SEQUENCE(_45entry_addr_55380)){
            _29459 = SEQ_PTR(_45entry_addr_55380)->length;
    }
    else {
        _29459 = 1;
    }
    _29460 = _29459 - 1;
    _29459 = NOVALUE;
    rhs_slice_target = (object_ptr)&_45entry_addr_55380;
    RHS_Slice(_45entry_addr_55380, 1, _29460);

    /** parser.e:2411		block_index -= 1*/
    _45block_index_55387 = _45block_index_55387 - 1;

    /** parser.e:2412	end procedure*/
    _29454 = NOVALUE;
    _29451 = NOVALUE;
    _29457 = NOVALUE;
    _29460 = NOVALUE;
    _29448 = NOVALUE;
    return;
    ;
}


void _45push_switch()
{
    object _new_1__tmp_at14_58944 = NOVALUE;
    object _new_inlined_new_at_14_58943 = NOVALUE;
    object _29464 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:2415		if_stack &= SWITCH*/
    Append(&_45if_stack_55391, _45if_stack_55391, 185);

    /** parser.e:2416		switch_stack = append( switch_stack,*/

    /** map.e:271		return eumem:malloc( new_map_seq( initial_size_p ) )*/
    _0 = _new_1__tmp_at14_58944;
    _new_1__tmp_at14_58944 = _29new_map_seq(8);
    DeRef(_0);
    Ref(_new_1__tmp_at14_58944);
    _0 = _new_inlined_new_at_14_58943;
    _new_inlined_new_at_14_58943 = _30malloc(_new_1__tmp_at14_58944, 1);
    DeRef(_0);
    DeRef(_new_1__tmp_at14_58944);
    _new_1__tmp_at14_58944 = NOVALUE;
    _1 = NewS1(13);
    _2 = (object)((s1_ptr)_1)->base;
    RefDSn(_22190, 2);
    ((intptr_t*)_2)[1] = _22190;
    ((intptr_t*)_2)[2] = _22190;
    ((intptr_t*)_2)[3] = 0;
    ((intptr_t*)_2)[4] = 0;
    ((intptr_t*)_2)[5] = 0;
    ((intptr_t*)_2)[6] = 0;
    Ref(_new_inlined_new_at_14_58943);
    ((intptr_t*)_2)[7] = _new_inlined_new_at_14_58943;
    RefDS(_22190);
    ((intptr_t*)_2)[8] = _22190;
    ((intptr_t*)_2)[9] = 0;
    RefDSn(_22190, 4);
    ((intptr_t*)_2)[10] = _22190;
    ((intptr_t*)_2)[11] = _22190;
    ((intptr_t*)_2)[12] = _22190;
    ((intptr_t*)_2)[13] = _22190;
    _29464 = MAKE_SEQ(_1);
    RefDS(_29464);
    Append(&_45switch_stack_55605, _45switch_stack_55605, _29464);
    DeRefDS(_29464);
    _29464 = NOVALUE;

    /** parser.e:2433	end procedure*/
    return;
    ;
}


void _45pop_switch(object _break_base_58949)
{
    object _29479 = NOVALUE;
    object _29478 = NOVALUE;
    object _29476 = NOVALUE;
    object _29475 = NOVALUE;
    object _29473 = NOVALUE;
    object _29472 = NOVALUE;
    object _29470 = NOVALUE;
    object _29469 = NOVALUE;
    object _29468 = NOVALUE;
    object _29467 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:2438		PatchEList( break_base )*/
    _45PatchEList(_break_base_58949);

    /** parser.e:2439		block_index -= 1*/
    _45block_index_55387 = _45block_index_55387 - 1;

    /** parser.e:2440		if length(switch_stack[$][SWITCH_CASES]) > 0 then*/
    if (IS_SEQUENCE(_45switch_stack_55605)){
            _29467 = SEQ_PTR(_45switch_stack_55605)->length;
    }
    else {
        _29467 = 1;
    }
    _2 = (object)SEQ_PTR(_45switch_stack_55605);
    _29468 = (object)*(((s1_ptr)_2)->base + _29467);
    _2 = (object)SEQ_PTR(_29468);
    _29469 = (object)*(((s1_ptr)_2)->base + 1);
    _29468 = NOVALUE;
    if (IS_SEQUENCE(_29469)){
            _29470 = SEQ_PTR(_29469)->length;
    }
    else {
        _29470 = 1;
    }
    _29469 = NOVALUE;
    if (_29470 <= 0)
    goto L1; // [34] 46

    /** parser.e:2441			End_block( CASE )*/
    _65End_block(186);
L1: 

    /** parser.e:2443		if_labels = if_labels[1..$-1]*/
    if (IS_SEQUENCE(_45if_labels_55385)){
            _29472 = SEQ_PTR(_45if_labels_55385)->length;
    }
    else {
        _29472 = 1;
    }
    _29473 = _29472 - 1;
    _29472 = NOVALUE;
    rhs_slice_target = (object_ptr)&_45if_labels_55385;
    RHS_Slice(_45if_labels_55385, 1, _29473);

    /** parser.e:2444		if_stack  = if_stack[1..$-1]*/
    if (IS_SEQUENCE(_45if_stack_55391)){
            _29475 = SEQ_PTR(_45if_stack_55391)->length;
    }
    else {
        _29475 = 1;
    }
    _29476 = _29475 - 1;
    _29475 = NOVALUE;
    rhs_slice_target = (object_ptr)&_45if_stack_55391;
    RHS_Slice(_45if_stack_55391, 1, _29476);

    /** parser.e:2445		switch_stack  = switch_stack[1..$-1]*/
    if (IS_SEQUENCE(_45switch_stack_55605)){
            _29478 = SEQ_PTR(_45switch_stack_55605)->length;
    }
    else {
        _29478 = 1;
    }
    _29479 = _29478 - 1;
    _29478 = NOVALUE;
    rhs_slice_target = (object_ptr)&_45switch_stack_55605;
    RHS_Slice(_45switch_stack_55605, 1, _29479);

    /** parser.e:2446	end procedure*/
    _29476 = NOVALUE;
    _29473 = NOVALUE;
    _29479 = NOVALUE;
    _29469 = NOVALUE;
    return;
    ;
}


void _45add_case(object _sym_58970, object _sign_58971)
{
    object _29526 = NOVALUE;
    object _29525 = NOVALUE;
    object _29524 = NOVALUE;
    object _29523 = NOVALUE;
    object _29522 = NOVALUE;
    object _29521 = NOVALUE;
    object _29519 = NOVALUE;
    object _29518 = NOVALUE;
    object _29517 = NOVALUE;
    object _29516 = NOVALUE;
    object _29514 = NOVALUE;
    object _29513 = NOVALUE;
    object _29512 = NOVALUE;
    object _29511 = NOVALUE;
    object _29509 = NOVALUE;
    object _29508 = NOVALUE;
    object _29507 = NOVALUE;
    object _29506 = NOVALUE;
    object _29505 = NOVALUE;
    object _29503 = NOVALUE;
    object _29502 = NOVALUE;
    object _29501 = NOVALUE;
    object _29500 = NOVALUE;
    object _29499 = NOVALUE;
    object _29498 = NOVALUE;
    object _29496 = NOVALUE;
    object _29495 = NOVALUE;
    object _29494 = NOVALUE;
    object _29493 = NOVALUE;
    object _29492 = NOVALUE;
    object _29491 = NOVALUE;
    object _29489 = NOVALUE;
    object _29488 = NOVALUE;
    object _29486 = NOVALUE;
    object _29485 = NOVALUE;
    object _29484 = NOVALUE;
    object _29483 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:2450		if sign < 0 then*/
    if (_sign_58971 >= 0)
    goto L1; // [5] 15

    /** parser.e:2451			sym = -sym*/
    _0 = _sym_58970;
    if (IS_ATOM_INT(_sym_58970)) {
        if ((uintptr_t)_sym_58970 == (uintptr_t)HIGH_BITS){
            _sym_58970 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _sym_58970 = - _sym_58970;
        }
    }
    else {
        _sym_58970 = unary_op(UMINUS, _sym_58970);
    }
    DeRefi(_0);
L1: 

    /** parser.e:2454		if find(sym, switch_stack[$][SWITCH_CASES] ) = 0 then*/
    if (IS_SEQUENCE(_45switch_stack_55605)){
            _29483 = SEQ_PTR(_45switch_stack_55605)->length;
    }
    else {
        _29483 = 1;
    }
    _2 = (object)SEQ_PTR(_45switch_stack_55605);
    _29484 = (object)*(((s1_ptr)_2)->base + _29483);
    _2 = (object)SEQ_PTR(_29484);
    _29485 = (object)*(((s1_ptr)_2)->base + 1);
    _29484 = NOVALUE;
    _29486 = find_from(_sym_58970, _29485, 1);
    _29485 = NOVALUE;
    if (_29486 != 0)
    goto L2; // [35] 252

    /** parser.e:2455			switch_stack[$][SWITCH_CASES]            = append( switch_stack[$][SWITCH_CASES], sym )*/
    if (IS_SEQUENCE(_45switch_stack_55605)){
            _29488 = SEQ_PTR(_45switch_stack_55605)->length;
    }
    else {
        _29488 = 1;
    }
    _2 = (object)SEQ_PTR(_45switch_stack_55605);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _45switch_stack_55605 = MAKE_SEQ(_2);
    }
    _3 = (object)(_29488 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_45switch_stack_55605)){
            _29491 = SEQ_PTR(_45switch_stack_55605)->length;
    }
    else {
        _29491 = 1;
    }
    _2 = (object)SEQ_PTR(_45switch_stack_55605);
    _29492 = (object)*(((s1_ptr)_2)->base + _29491);
    _2 = (object)SEQ_PTR(_29492);
    _29493 = (object)*(((s1_ptr)_2)->base + 1);
    _29492 = NOVALUE;
    Ref(_sym_58970);
    Append(&_29494, _29493, _sym_58970);
    _29493 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29494;
    if( _1 != _29494 ){
        DeRef(_1);
    }
    _29494 = NOVALUE;
    _29489 = NOVALUE;

    /** parser.e:2456			switch_stack[$][SWITCH_JUMP_TABLE]      &= length(Code) + 1*/
    if (IS_SEQUENCE(_45switch_stack_55605)){
            _29495 = SEQ_PTR(_45switch_stack_55605)->length;
    }
    else {
        _29495 = 1;
    }
    _2 = (object)SEQ_PTR(_45switch_stack_55605);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _45switch_stack_55605 = MAKE_SEQ(_2);
    }
    _3 = (object)(_29495 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_36Code_21859)){
            _29498 = SEQ_PTR(_36Code_21859)->length;
    }
    else {
        _29498 = 1;
    }
    _29499 = _29498 + 1;
    _29498 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _29500 = (object)*(((s1_ptr)_2)->base + 2);
    _29496 = NOVALUE;
    if (IS_SEQUENCE(_29500) && IS_ATOM(_29499)) {
        Append(&_29501, _29500, _29499);
    }
    else if (IS_ATOM(_29500) && IS_SEQUENCE(_29499)) {
    }
    else {
        Concat((object_ptr)&_29501, _29500, _29499);
        _29500 = NOVALUE;
    }
    _29500 = NOVALUE;
    _29499 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29501;
    if( _1 != _29501 ){
        DeRef(_1);
    }
    _29501 = NOVALUE;
    _29496 = NOVALUE;

    /** parser.e:2457			switch_stack[$][SWITCH_THISLINE]        &= {ThisLine}*/
    if (IS_SEQUENCE(_45switch_stack_55605)){
            _29502 = SEQ_PTR(_45switch_stack_55605)->length;
    }
    else {
        _29502 = 1;
    }
    _2 = (object)SEQ_PTR(_45switch_stack_55605);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _45switch_stack_55605 = MAKE_SEQ(_2);
    }
    _3 = (object)(_29502 + ((s1_ptr)_2)->base);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_50ThisLine_49594);
    ((intptr_t*)_2)[1] = _50ThisLine_49594;
    _29505 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _29506 = (object)*(((s1_ptr)_2)->base + 10);
    _29503 = NOVALUE;
    if (IS_SEQUENCE(_29506) && IS_ATOM(_29505)) {
    }
    else if (IS_ATOM(_29506) && IS_SEQUENCE(_29505)) {
        Ref(_29506);
        Prepend(&_29507, _29505, _29506);
    }
    else {
        Concat((object_ptr)&_29507, _29506, _29505);
        _29506 = NOVALUE;
    }
    _29506 = NOVALUE;
    DeRefDS(_29505);
    _29505 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 10);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29507;
    if( _1 != _29507 ){
        DeRef(_1);
    }
    _29507 = NOVALUE;
    _29503 = NOVALUE;

    /** parser.e:2458			switch_stack[$][SWITCH_BP]              &= bp*/
    if (IS_SEQUENCE(_45switch_stack_55605)){
            _29508 = SEQ_PTR(_45switch_stack_55605)->length;
    }
    else {
        _29508 = 1;
    }
    _2 = (object)SEQ_PTR(_45switch_stack_55605);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _45switch_stack_55605 = MAKE_SEQ(_2);
    }
    _3 = (object)(_29508 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _29511 = (object)*(((s1_ptr)_2)->base + 11);
    _29509 = NOVALUE;
    if (IS_SEQUENCE(_29511) && IS_ATOM(_50bp_49598)) {
        Append(&_29512, _29511, _50bp_49598);
    }
    else if (IS_ATOM(_29511) && IS_SEQUENCE(_50bp_49598)) {
    }
    else {
        Concat((object_ptr)&_29512, _29511, _50bp_49598);
        _29511 = NOVALUE;
    }
    _29511 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 11);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29512;
    if( _1 != _29512 ){
        DeRef(_1);
    }
    _29512 = NOVALUE;
    _29509 = NOVALUE;

    /** parser.e:2459			switch_stack[$][SWITCH_LINE_NUMBER]     &= line_number*/
    if (IS_SEQUENCE(_45switch_stack_55605)){
            _29513 = SEQ_PTR(_45switch_stack_55605)->length;
    }
    else {
        _29513 = 1;
    }
    _2 = (object)SEQ_PTR(_45switch_stack_55605);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _45switch_stack_55605 = MAKE_SEQ(_2);
    }
    _3 = (object)(_29513 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _29516 = (object)*(((s1_ptr)_2)->base + 12);
    _29514 = NOVALUE;
    if (IS_SEQUENCE(_29516) && IS_ATOM(_36line_number_21768)) {
        Append(&_29517, _29516, _36line_number_21768);
    }
    else if (IS_ATOM(_29516) && IS_SEQUENCE(_36line_number_21768)) {
    }
    else {
        Concat((object_ptr)&_29517, _29516, _36line_number_21768);
        _29516 = NOVALUE;
    }
    _29516 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29517;
    if( _1 != _29517 ){
        DeRef(_1);
    }
    _29517 = NOVALUE;
    _29514 = NOVALUE;

    /** parser.e:2460			switch_stack[$][SWITCH_CURRENT_FILE_NO] &= current_file_no*/
    if (IS_SEQUENCE(_45switch_stack_55605)){
            _29518 = SEQ_PTR(_45switch_stack_55605)->length;
    }
    else {
        _29518 = 1;
    }
    _2 = (object)SEQ_PTR(_45switch_stack_55605);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _45switch_stack_55605 = MAKE_SEQ(_2);
    }
    _3 = (object)(_29518 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _29521 = (object)*(((s1_ptr)_2)->base + 13);
    _29519 = NOVALUE;
    if (IS_SEQUENCE(_29521) && IS_ATOM(_36current_file_no_21767)) {
        Append(&_29522, _29521, _36current_file_no_21767);
    }
    else if (IS_ATOM(_29521) && IS_SEQUENCE(_36current_file_no_21767)) {
    }
    else {
        Concat((object_ptr)&_29522, _29521, _36current_file_no_21767);
        _29521 = NOVALUE;
    }
    _29521 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 13);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29522;
    if( _1 != _29522 ){
        DeRef(_1);
    }
    _29522 = NOVALUE;
    _29519 = NOVALUE;

    /** parser.e:2462			if TRANSLATE then*/
    if (_36TRANSLATE_21369 == 0)
    {
        goto L3; // [217] 262
    }
    else{
    }

    /** parser.e:2463				emit_addr( CASE )*/
    _47emit_addr(186);

    /** parser.e:2464				emit_addr( length( switch_stack[$][SWITCH_CASES] ) )*/
    if (IS_SEQUENCE(_45switch_stack_55605)){
            _29523 = SEQ_PTR(_45switch_stack_55605)->length;
    }
    else {
        _29523 = 1;
    }
    _2 = (object)SEQ_PTR(_45switch_stack_55605);
    _29524 = (object)*(((s1_ptr)_2)->base + _29523);
    _2 = (object)SEQ_PTR(_29524);
    _29525 = (object)*(((s1_ptr)_2)->base + 1);
    _29524 = NOVALUE;
    if (IS_SEQUENCE(_29525)){
            _29526 = SEQ_PTR(_29525)->length;
    }
    else {
        _29526 = 1;
    }
    _29525 = NOVALUE;
    _47emit_addr(_29526);
    _29526 = NOVALUE;
    goto L3; // [249] 262
L2: 

    /** parser.e:2467			CompileErr( DUPLICATE_CASE_VALUE_USED)*/
    RefDS(_22190);
    _50CompileErr(63, _22190, 0);
L3: 

    /** parser.e:2469	end procedure*/
    DeRef(_sym_58970);
    _29525 = NOVALUE;
    return;
    ;
}


void _45case_else()
{
    object _29534 = NOVALUE;
    object _29533 = NOVALUE;
    object _29531 = NOVALUE;
    object _29530 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:2476		switch_stack[$][SWITCH_ELSE] = length(Code) + 1*/
    if (IS_SEQUENCE(_45switch_stack_55605)){
            _29530 = SEQ_PTR(_45switch_stack_55605)->length;
    }
    else {
        _29530 = 1;
    }
    _2 = (object)SEQ_PTR(_45switch_stack_55605);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _45switch_stack_55605 = MAKE_SEQ(_2);
    }
    _3 = (object)(_29530 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_36Code_21859)){
            _29533 = SEQ_PTR(_36Code_21859)->length;
    }
    else {
        _29533 = 1;
    }
    _29534 = _29533 + 1;
    _29533 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29534;
    if( _1 != _29534 ){
        DeRef(_1);
    }
    _29534 = NOVALUE;
    _29531 = NOVALUE;

    /** parser.e:2477		if TRANSLATE then*/
    if (_36TRANSLATE_21369 == 0)
    {
        goto L1; // [30] 46
    }
    else{
    }

    /** parser.e:2478			emit_addr( CASE )*/
    _47emit_addr(186);

    /** parser.e:2479			emit_addr( 0 )*/
    _47emit_addr(0);
L1: 

    /** parser.e:2482	end procedure*/
    return;
    ;
}


void _45Case_statement()
{
    object _else_case_2__tmp_at147_59094 = NOVALUE;
    object _else_case_1__tmp_at147_59093 = NOVALUE;
    object _else_case_inlined_else_case_at_147_59092 = NOVALUE;
    object _tok_59055 = NOVALUE;
    object _condition_59057 = NOVALUE;
    object _start_line_59087 = NOVALUE;
    object _sign_59099 = NOVALUE;
    object _fwd_59112 = NOVALUE;
    object _symi_59122 = NOVALUE;
    object _fwdref_59194 = NOVALUE;
    object _31959 = NOVALUE;
    object _29616 = NOVALUE;
    object _29615 = NOVALUE;
    object _29614 = NOVALUE;
    object _29613 = NOVALUE;
    object _29612 = NOVALUE;
    object _29611 = NOVALUE;
    object _29609 = NOVALUE;
    object _29608 = NOVALUE;
    object _29607 = NOVALUE;
    object _29606 = NOVALUE;
    object _29605 = NOVALUE;
    object _29604 = NOVALUE;
    object _29602 = NOVALUE;
    object _29599 = NOVALUE;
    object _29596 = NOVALUE;
    object _29595 = NOVALUE;
    object _29594 = NOVALUE;
    object _29593 = NOVALUE;
    object _29590 = NOVALUE;
    object _29589 = NOVALUE;
    object _29588 = NOVALUE;
    object _29587 = NOVALUE;
    object _29584 = NOVALUE;
    object _29583 = NOVALUE;
    object _29582 = NOVALUE;
    object _29581 = NOVALUE;
    object _29579 = NOVALUE;
    object _29578 = NOVALUE;
    object _29577 = NOVALUE;
    object _29575 = NOVALUE;
    object _29574 = NOVALUE;
    object _29573 = NOVALUE;
    object _29572 = NOVALUE;
    object _29571 = NOVALUE;
    object _29569 = NOVALUE;
    object _29568 = NOVALUE;
    object _29566 = NOVALUE;
    object _29565 = NOVALUE;
    object _29564 = NOVALUE;
    object _29563 = NOVALUE;
    object _29559 = NOVALUE;
    object _29558 = NOVALUE;
    object _29557 = NOVALUE;
    object _29554 = NOVALUE;
    object _29551 = NOVALUE;
    object _29548 = NOVALUE;
    object _29547 = NOVALUE;
    object _29546 = NOVALUE;
    object _29545 = NOVALUE;
    object _29544 = NOVALUE;
    object _29543 = NOVALUE;
    object _29542 = NOVALUE;
    object _29540 = NOVALUE;
    object _29539 = NOVALUE;
    object _29538 = NOVALUE;
    object _29537 = NOVALUE;
    object _29535 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:2489		if not in_switch() then*/
    _29535 = _45in_switch();
    if (IS_ATOM_INT(_29535)) {
        if (_29535 != 0){
            DeRef(_29535);
            _29535 = NOVALUE;
            goto L1; // [6] 19
        }
    }
    else {
        if (DBL_PTR(_29535)->dbl != 0.0){
            DeRef(_29535);
            _29535 = NOVALUE;
            goto L1; // [6] 19
        }
    }
    DeRef(_29535);
    _29535 = NOVALUE;

    /** parser.e:2490			CompileErr( A_CASE_MUST_BE_INSIDE_A_SWITCH)*/
    RefDS(_22190);
    _50CompileErr(34, _22190, 0);
L1: 

    /** parser.e:2493		if length(switch_stack[$][SWITCH_CASES]) > 0 then*/
    if (IS_SEQUENCE(_45switch_stack_55605)){
            _29537 = SEQ_PTR(_45switch_stack_55605)->length;
    }
    else {
        _29537 = 1;
    }
    _2 = (object)SEQ_PTR(_45switch_stack_55605);
    _29538 = (object)*(((s1_ptr)_2)->base + _29537);
    _2 = (object)SEQ_PTR(_29538);
    _29539 = (object)*(((s1_ptr)_2)->base + 1);
    _29538 = NOVALUE;
    if (IS_SEQUENCE(_29539)){
            _29540 = SEQ_PTR(_29539)->length;
    }
    else {
        _29540 = 1;
    }
    _29539 = NOVALUE;
    if (_29540 <= 0)
    goto L2; // [37] 103

    /** parser.e:2495			Sibling_block( CASE )*/
    _65Sibling_block(186);

    /** parser.e:2497			if not switch_stack[$][SWITCH_FALLTHRU] and*/
    if (IS_SEQUENCE(_45switch_stack_55605)){
            _29542 = SEQ_PTR(_45switch_stack_55605)->length;
    }
    else {
        _29542 = 1;
    }
    _2 = (object)SEQ_PTR(_45switch_stack_55605);
    _29543 = (object)*(((s1_ptr)_2)->base + _29542);
    _2 = (object)SEQ_PTR(_29543);
    _29544 = (object)*(((s1_ptr)_2)->base + 5);
    _29543 = NOVALUE;
    if (IS_ATOM_INT(_29544)) {
        _29545 = (_29544 == 0);
    }
    else {
        _29545 = unary_op(NOT, _29544);
    }
    _29544 = NOVALUE;
    if (IS_ATOM_INT(_29545)) {
        if (_29545 == 0) {
            goto L3; // [66] 112
        }
    }
    else {
        if (DBL_PTR(_29545)->dbl == 0.0) {
            goto L3; // [66] 112
        }
    }
    _29547 = (_45fallthru_case_59051 == 0);
    if (_29547 == 0)
    {
        DeRef(_29547);
        _29547 = NOVALUE;
        goto L3; // [76] 112
    }
    else{
        DeRef(_29547);
        _29547 = NOVALUE;
    }

    /** parser.e:2501				putback( {CASE, 0} )*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 186;
    ((intptr_t *)_2)[2] = 0;
    _29548 = MAKE_SEQ(_1);
    _45putback(_29548);
    _29548 = NOVALUE;

    /** parser.e:2502				Break_statement()*/
    _45Break_statement();

    /** parser.e:2503				tok = next_token()*/
    _0 = _tok_59055;
    _tok_59055 = _45next_token();
    DeRef(_0);
    goto L3; // [100] 112
L2: 

    /** parser.e:2506			Start_block( CASE )*/
    _65Start_block(186, 0);
L3: 

    /** parser.e:2509		StartSourceLine(TRUE, , COVERAGE_SUPPRESS)*/
    _47StartSourceLine(_13TRUE_447, 0, 1);

    /** parser.e:2511		fallthru_case = 0*/
    _45fallthru_case_59051 = 0;

    /** parser.e:2512		integer start_line = line_number*/
    _start_line_59087 = _36line_number_21768;

    /** parser.e:2513		while 1 do*/
L4: 

    /** parser.e:2515			if else_case() then*/

    /** parser.e:2472		return switch_stack[$][SWITCH_ELSE]*/
    if (IS_SEQUENCE(_45switch_stack_55605)){
            _else_case_1__tmp_at147_59093 = SEQ_PTR(_45switch_stack_55605)->length;
    }
    else {
        _else_case_1__tmp_at147_59093 = 1;
    }
    DeRef(_else_case_2__tmp_at147_59094);
    _2 = (object)SEQ_PTR(_45switch_stack_55605);
    _else_case_2__tmp_at147_59094 = (object)*(((s1_ptr)_2)->base + _else_case_1__tmp_at147_59093);
    RefDS(_else_case_2__tmp_at147_59094);
    DeRef(_else_case_inlined_else_case_at_147_59092);
    _2 = (object)SEQ_PTR(_else_case_2__tmp_at147_59094);
    _else_case_inlined_else_case_at_147_59092 = (object)*(((s1_ptr)_2)->base + 3);
    Ref(_else_case_inlined_else_case_at_147_59092);
    DeRef(_else_case_2__tmp_at147_59094);
    _else_case_2__tmp_at147_59094 = NOVALUE;
    if (_else_case_inlined_else_case_at_147_59092 == 0) {
        goto L5; // [162] 175
    }
    else {
        if (!IS_ATOM_INT(_else_case_inlined_else_case_at_147_59092) && DBL_PTR(_else_case_inlined_else_case_at_147_59092)->dbl == 0.0){
            goto L5; // [162] 175
        }
    }

    /** parser.e:2516				CompileErr( A_CASE_BLOCK_CANNOT_FOLLOW_A_CASE_ELSE_BLOCK)*/
    RefDS(_22190);
    _50CompileErr(33, _22190, 0);
L5: 

    /** parser.e:2518			maybe_namespace()*/
    _62maybe_namespace();

    /** parser.e:2519			tok = next_token()*/
    _0 = _tok_59055;
    _tok_59055 = _45next_token();
    DeRef(_0);

    /** parser.e:2520			integer sign = 1*/
    _sign_59099 = 1;

    /** parser.e:2521			if tok[T_ID] = MINUS then*/
    _2 = (object)SEQ_PTR(_tok_59055);
    _29551 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29551, 10)){
        _29551 = NOVALUE;
        goto L6; // [199] 216
    }
    _29551 = NOVALUE;

    /** parser.e:2522				sign = -1*/
    _sign_59099 = -1;

    /** parser.e:2523				tok = next_token()*/
    _0 = _tok_59055;
    _tok_59055 = _45next_token();
    DeRef(_0);
    goto L7; // [213] 237
L6: 

    /** parser.e:2524			elsif tok[T_ID] = PLUS then*/
    _2 = (object)SEQ_PTR(_tok_59055);
    _29554 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29554, 11)){
        _29554 = NOVALUE;
        goto L8; // [226] 236
    }
    _29554 = NOVALUE;

    /** parser.e:2525				tok = next_token()*/
    _0 = _tok_59055;
    _tok_59055 = _45next_token();
    DeRef(_0);
L8: 
L7: 

    /** parser.e:2528			integer fwd*/

    /** parser.e:2529			if not find( tok[T_ID], {ATOM, STRING, ELSE} ) then*/
    _2 = (object)SEQ_PTR(_tok_59055);
    _29557 = (object)*(((s1_ptr)_2)->base + 1);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 502;
    ((intptr_t*)_2)[2] = 503;
    ((intptr_t*)_2)[3] = 23;
    _29558 = MAKE_SEQ(_1);
    _29559 = find_from(_29557, _29558, 1);
    _29557 = NOVALUE;
    DeRefDS(_29558);
    _29558 = NOVALUE;
    if (_29559 != 0)
    goto L9; // [264] 439
    _29559 = NOVALUE;

    /** parser.e:2531				integer symi = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_59055);
    _symi_59122 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_symi_59122)){
        _symi_59122 = (object)DBL_PTR(_symi_59122)->dbl;
    }

    /** parser.e:2532				fwd = -1*/
    _fwd_59112 = -1;

    /** parser.e:2533				if symi > 0 then*/
    if (_symi_59122 <= 0)
    goto LA; // [284] 434

    /** parser.e:2534					if find(tok[T_ID] , VAR_TOKS) then*/
    _2 = (object)SEQ_PTR(_tok_59055);
    _29563 = (object)*(((s1_ptr)_2)->base + 1);
    _29564 = find_from(_29563, _38VAR_TOKS_16301, 1);
    _29563 = NOVALUE;
    if (_29564 == 0)
    {
        _29564 = NOVALUE;
        goto LB; // [303] 433
    }
    else{
        _29564 = NOVALUE;
    }

    /** parser.e:2535						if SymTab[symi][S_SCOPE] = SC_UNDEFINED then*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _29565 = (object)*(((s1_ptr)_2)->base + _symi_59122);
    _2 = (object)SEQ_PTR(_29565);
    _29566 = (object)*(((s1_ptr)_2)->base + 4);
    _29565 = NOVALUE;
    if (binary_op_a(NOTEQ, _29566, 9)){
        _29566 = NOVALUE;
        goto LC; // [322] 334
    }
    _29566 = NOVALUE;

    /** parser.e:2537							fwd = symi*/
    _fwd_59112 = _symi_59122;
    goto LD; // [331] 432
LC: 

    /** parser.e:2538						elsif SymTab[symi][S_MODE] = M_CONSTANT then*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _29568 = (object)*(((s1_ptr)_2)->base + _symi_59122);
    _2 = (object)SEQ_PTR(_29568);
    _29569 = (object)*(((s1_ptr)_2)->base + 3);
    _29568 = NOVALUE;
    if (binary_op_a(NOTEQ, _29569, 2)){
        _29569 = NOVALUE;
        goto LE; // [350] 431
    }
    _29569 = NOVALUE;

    /** parser.e:2539							fwd = 0*/
    _fwd_59112 = 0;

    /** parser.e:2540							if SymTab[symi][S_CODE] then*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _29571 = (object)*(((s1_ptr)_2)->base + _symi_59122);
    _2 = (object)SEQ_PTR(_29571);
    if (!IS_ATOM_INT(_36S_CODE_21416)){
        _29572 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21416)->dbl));
    }
    else{
        _29572 = (object)*(((s1_ptr)_2)->base + _36S_CODE_21416);
    }
    _29571 = NOVALUE;
    if (_29572 == 0) {
        _29572 = NOVALUE;
        goto LF; // [373] 397
    }
    else {
        if (!IS_ATOM_INT(_29572) && DBL_PTR(_29572)->dbl == 0.0){
            _29572 = NOVALUE;
            goto LF; // [373] 397
        }
        _29572 = NOVALUE;
    }
    _29572 = NOVALUE;

    /** parser.e:2541								tok[T_SYM] = SymTab[symi][S_CODE]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _29573 = (object)*(((s1_ptr)_2)->base + _symi_59122);
    _2 = (object)SEQ_PTR(_29573);
    if (!IS_ATOM_INT(_36S_CODE_21416)){
        _29574 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21416)->dbl));
    }
    else{
        _29574 = (object)*(((s1_ptr)_2)->base + _36S_CODE_21416);
    }
    _29573 = NOVALUE;
    Ref(_29574);
    _2 = (object)SEQ_PTR(_tok_59055);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _tok_59055 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29574;
    if( _1 != _29574 ){
        DeRef(_1);
    }
    _29574 = NOVALUE;
LF: 

    /** parser.e:2543							SymTab[symi][S_USAGE] = or_bits( SymTab[symi][S_USAGE], U_READ )*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_symi_59122 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _29577 = (object)*(((s1_ptr)_2)->base + _symi_59122);
    _2 = (object)SEQ_PTR(_29577);
    _29578 = (object)*(((s1_ptr)_2)->base + 5);
    _29577 = NOVALUE;
    if (IS_ATOM_INT(_29578)) {
        {uintptr_t tu;
             tu = (uintptr_t)_29578 | (uintptr_t)1;
             _29579 = MAKE_UINT(tu);
        }
    }
    else {
        _29579 = binary_op(OR_BITS, _29578, 1);
    }
    _29578 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29579;
    if( _1 != _29579 ){
        DeRef(_1);
    }
    _29579 = NOVALUE;
    _29575 = NOVALUE;
LE: 
LD: 
LB: 
LA: 
    goto L10; // [436] 445
L9: 

    /** parser.e:2548				fwd = 0*/
    _fwd_59112 = 0;
L10: 

    /** parser.e:2551			if fwd < 0 then*/
    if (_fwd_59112 >= 0)
    goto L11; // [449] 477

    /** parser.e:2552				CompileErr( FOUND_1_BUT_EXPECTED_ELSE_AN_ATOM_STRING_CONSTANT_OR_ENUM, {find_category(tok[T_ID])})*/
    _2 = (object)SEQ_PTR(_tok_59055);
    _29581 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_29581);
    _29582 = _63find_category(_29581);
    _29581 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _29582;
    _29583 = MAKE_SEQ(_1);
    _29582 = NOVALUE;
    _50CompileErr(91, _29583, 0);
    _29583 = NOVALUE;
L11: 

    /** parser.e:2555			if tok[T_ID] = ELSE then*/
    _2 = (object)SEQ_PTR(_tok_59055);
    _29584 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29584, 23)){
        _29584 = NOVALUE;
        goto L12; // [487] 552
    }
    _29584 = NOVALUE;

    /** parser.e:2556				if sign = -1 then*/
    if (_sign_59099 != -1)
    goto L13; // [493] 507

    /** parser.e:2557					CompileErr( EXPECTED_AN_ATOM_STRING_OR_A_CONSTANT_ASSIGNED_AN_ATOM_OR_A_STRING)*/
    RefDS(_22190);
    _50CompileErr(71, _22190, 0);
L13: 

    /** parser.e:2559				if length(switch_stack[$][SWITCH_CASES]) = 0 then*/
    if (IS_SEQUENCE(_45switch_stack_55605)){
            _29587 = SEQ_PTR(_45switch_stack_55605)->length;
    }
    else {
        _29587 = 1;
    }
    _2 = (object)SEQ_PTR(_45switch_stack_55605);
    _29588 = (object)*(((s1_ptr)_2)->base + _29587);
    _2 = (object)SEQ_PTR(_29588);
    _29589 = (object)*(((s1_ptr)_2)->base + 1);
    _29588 = NOVALUE;
    if (IS_SEQUENCE(_29589)){
            _29590 = SEQ_PTR(_29589)->length;
    }
    else {
        _29590 = 1;
    }
    _29589 = NOVALUE;
    if (_29590 != 0)
    goto L14; // [525] 539

    /** parser.e:2560					CompileErr( CASE_ELSE_CANNOT_BE_FIRST_CASE_IN_SWITCH)*/
    RefDS(_22190);
    _50CompileErr(44, _22190, 0);
L14: 

    /** parser.e:2562				case_else()*/
    _45case_else();

    /** parser.e:2563				exit*/
    goto L15; // [547] 789
    goto L16; // [549] 623
L12: 

    /** parser.e:2565			elsif fwd then*/
    if (_fwd_59112 == 0)
    {
        goto L17; // [554] 606
    }
    else{
    }

    /** parser.e:2566				integer fwdref = new_forward_reference( CASE, fwd )*/
    DeRef(_31959);
    _31959 = 186;
    _fwdref_59194 = _44new_forward_reference(186, _fwd_59112, 186);
    _31959 = NOVALUE;
    if (!IS_ATOM_INT(_fwdref_59194)) {
        _1 = (object)(DBL_PTR(_fwdref_59194)->dbl);
        DeRefDS(_fwdref_59194);
        _fwdref_59194 = _1;
    }

    /** parser.e:2567				add_case( {fwdref}, sign )*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _fwdref_59194;
    _29593 = MAKE_SEQ(_1);
    _45add_case(_29593, _sign_59099);
    _29593 = NOVALUE;

    /** parser.e:2568				fwd:set_data( fwdref, switch_stack[$][SWITCH_PC] )*/
    if (IS_SEQUENCE(_45switch_stack_55605)){
            _29594 = SEQ_PTR(_45switch_stack_55605)->length;
    }
    else {
        _29594 = 1;
    }
    _2 = (object)SEQ_PTR(_45switch_stack_55605);
    _29595 = (object)*(((s1_ptr)_2)->base + _29594);
    _2 = (object)SEQ_PTR(_29595);
    _29596 = (object)*(((s1_ptr)_2)->base + 4);
    _29595 = NOVALUE;
    Ref(_29596);
    _44set_data(_fwdref_59194, _29596);
    _29596 = NOVALUE;
    goto L16; // [603] 623
L17: 

    /** parser.e:2571				condition = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_59055);
    _condition_59057 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_condition_59057)){
        _condition_59057 = (object)DBL_PTR(_condition_59057)->dbl;
    }

    /** parser.e:2572				add_case( condition, sign )*/
    _45add_case(_condition_59057, _sign_59099);
L16: 

    /** parser.e:2575			tok = next_token()*/
    _0 = _tok_59055;
    _tok_59055 = _45next_token();
    DeRef(_0);

    /** parser.e:2576			if tok[T_ID] = THEN then*/
    _2 = (object)SEQ_PTR(_tok_59055);
    _29599 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29599, 410)){
        _29599 = NOVALUE;
        goto L18; // [638] 742
    }
    _29599 = NOVALUE;

    /** parser.e:2577				tok = next_token()*/
    _0 = _tok_59055;
    _tok_59055 = _45next_token();
    DeRef(_0);

    /** parser.e:2579				if tok[T_ID] = CASE then*/
    _2 = (object)SEQ_PTR(_tok_59055);
    _29602 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29602, 186)){
        _29602 = NOVALUE;
        goto L19; // [657] 727
    }
    _29602 = NOVALUE;

    /** parser.e:2580					if switch_stack[$][SWITCH_FALLTHRU] then*/
    if (IS_SEQUENCE(_45switch_stack_55605)){
            _29604 = SEQ_PTR(_45switch_stack_55605)->length;
    }
    else {
        _29604 = 1;
    }
    _2 = (object)SEQ_PTR(_45switch_stack_55605);
    _29605 = (object)*(((s1_ptr)_2)->base + _29604);
    _2 = (object)SEQ_PTR(_29605);
    _29606 = (object)*(((s1_ptr)_2)->base + 5);
    _29605 = NOVALUE;
    if (_29606 == 0) {
        _29606 = NOVALUE;
        goto L1A; // [676] 691
    }
    else {
        if (!IS_ATOM_INT(_29606) && DBL_PTR(_29606)->dbl == 0.0){
            _29606 = NOVALUE;
            goto L1A; // [676] 691
        }
        _29606 = NOVALUE;
    }
    _29606 = NOVALUE;

    /** parser.e:2581						start_line = line_number*/
    _start_line_59087 = _36line_number_21768;
    goto L1B; // [688] 782
L1A: 

    /** parser.e:2583						putback( tok )*/
    Ref(_tok_59055);
    _45putback(_tok_59055);

    /** parser.e:2584						Warning(220, empty_case_warning_flag,*/
    _2 = (object)SEQ_PTR(_37known_files_15638);
    _29607 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21767);
    Ref(_29607);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _29607;
    ((intptr_t *)_2)[2] = _start_line_59087;
    _29608 = MAKE_SEQ(_1);
    _29607 = NOVALUE;
    _50Warning(220, 2048, _29608);
    _29608 = NOVALUE;

    /** parser.e:2586						exit*/
    goto L15; // [721] 789
    goto L1B; // [724] 782
L19: 

    /** parser.e:2589					putback( tok )*/
    Ref(_tok_59055);
    _45putback(_tok_59055);

    /** parser.e:2590					exit*/
    goto L15; // [736] 789
    goto L1B; // [739] 782
L18: 

    /** parser.e:2593			elsif tok[T_ID] != COMMA then*/
    _2 = (object)SEQ_PTR(_tok_59055);
    _29609 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _29609, -30)){
        _29609 = NOVALUE;
        goto L1C; // [752] 781
    }
    _29609 = NOVALUE;

    /** parser.e:2594				CompileErr(EXPECTED_THEN_OR__NOT_1,{LexName(tok[T_ID])})*/
    _2 = (object)SEQ_PTR(_tok_59055);
    _29611 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_29611);
    RefDS(_26602);
    _29612 = _47LexName(_29611, _26602);
    _29611 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _29612;
    _29613 = MAKE_SEQ(_1);
    _29612 = NOVALUE;
    _50CompileErr(66, _29613, 0);
    _29613 = NOVALUE;
L1C: 
L1B: 

    /** parser.e:2597		end while*/
    goto L4; // [786] 142
L15: 

    /** parser.e:2598		StartSourceLine( TRUE )*/
    _47StartSourceLine(_13TRUE_447, 0, 2);

    /** parser.e:2599		emit_temp( switch_stack[$][SWITCH_VALUE], NEW_REFERENCE )*/
    if (IS_SEQUENCE(_45switch_stack_55605)){
            _29614 = SEQ_PTR(_45switch_stack_55605)->length;
    }
    else {
        _29614 = 1;
    }
    _2 = (object)SEQ_PTR(_45switch_stack_55605);
    _29615 = (object)*(((s1_ptr)_2)->base + _29614);
    _2 = (object)SEQ_PTR(_29615);
    _29616 = (object)*(((s1_ptr)_2)->base + 6);
    _29615 = NOVALUE;
    Ref(_29616);
    _47emit_temp(_29616, 1);
    _29616 = NOVALUE;

    /** parser.e:2600		flush_temps()*/
    RefDS(_22190);
    _47flush_temps(_22190);

    /** parser.e:2601	end procedure*/
    DeRef(_tok_59055);
    DeRef(_29545);
    _29545 = NOVALUE;
    _29589 = NOVALUE;
    _29539 = NOVALUE;
    return;
    ;
}


void _45Fallthru_statement()
{
    object _29617 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:2604		if not in_switch() then*/
    _29617 = _45in_switch();
    if (IS_ATOM_INT(_29617)) {
        if (_29617 != 0){
            DeRef(_29617);
            _29617 = NOVALUE;
            goto L1; // [6] 19
        }
    }
    else {
        if (DBL_PTR(_29617)->dbl != 0.0){
            DeRef(_29617);
            _29617 = NOVALUE;
            goto L1; // [6] 19
        }
    }
    DeRef(_29617);
    _29617 = NOVALUE;

    /** parser.e:2605			CompileErr( A_FALLTHRU_MUST_BE_INSIDE_A_SWITCH)*/
    RefDS(_22190);
    _50CompileErr(22, _22190, 0);
L1: 

    /** parser.e:2607		tok_match( CASE )*/
    _45tok_match(186, 0);

    /** parser.e:2608		fallthru_case = 1*/
    _45fallthru_case_59051 = 1;

    /** parser.e:2609		Case_statement()*/
    _45Case_statement();

    /** parser.e:2610	end procedure*/
    return;
    ;
}


void _45update_translator_info(object _sym_59262, object _all_ints_59263, object _has_integer_59264, object _has_atom_59265, object _has_sequence_59266)
{
    object _29642 = NOVALUE;
    object _29640 = NOVALUE;
    object _29638 = NOVALUE;
    object _29636 = NOVALUE;
    object _29634 = NOVALUE;
    object _29633 = NOVALUE;
    object _29631 = NOVALUE;
    object _29629 = NOVALUE;
    object _29628 = NOVALUE;
    object _29627 = NOVALUE;
    object _29626 = NOVALUE;
    object _29625 = NOVALUE;
    object _29623 = NOVALUE;
    object _29621 = NOVALUE;
    object _29619 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:2615		SymTab[sym][S_MODE] = M_TEMP    -- override CONSTANT for compile*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_59262 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 3;
    DeRef(_1);
    _29619 = NOVALUE;

    /** parser.e:2616		SymTab[sym][S_GTYPE] = TYPE_SEQUENCE*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_59262 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 8;
    DeRef(_1);
    _29621 = NOVALUE;

    /** parser.e:2617		SymTab[sym][S_SEQ_LEN] = length( SymTab[sym][S_OBJ] )*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_59262 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _29625 = (object)*(((s1_ptr)_2)->base + _sym_59262);
    _2 = (object)SEQ_PTR(_29625);
    _29626 = (object)*(((s1_ptr)_2)->base + 1);
    _29625 = NOVALUE;
    if (IS_SEQUENCE(_29626)){
            _29627 = SEQ_PTR(_29626)->length;
    }
    else {
        _29627 = 1;
    }
    _29626 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 32);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29627;
    if( _1 != _29627 ){
        DeRef(_1);
    }
    _29627 = NOVALUE;
    _29623 = NOVALUE;

    /** parser.e:2619		if SymTab[sym][S_SEQ_LEN] > 0 then*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _29628 = (object)*(((s1_ptr)_2)->base + _sym_59262);
    _2 = (object)SEQ_PTR(_29628);
    _29629 = (object)*(((s1_ptr)_2)->base + 32);
    _29628 = NOVALUE;
    if (binary_op_a(LESSEQ, _29629, 0)){
        _29629 = NOVALUE;
        goto L1; // [89] 198
    }
    _29629 = NOVALUE;

    /** parser.e:2620			if all_ints then*/
    if (_all_ints_59263 == 0)
    {
        goto L2; // [95] 118
    }
    else{
    }

    /** parser.e:2621				SymTab[sym][S_SEQ_ELEM] = TYPE_INTEGER*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_59262 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1;
    DeRef(_1);
    _29631 = NOVALUE;
    goto L3; // [115] 216
L2: 

    /** parser.e:2623			elsif has_atom + has_sequence + has_integer > 1 then*/
    _29633 = _has_atom_59265 + _has_sequence_59266;
    if ((object)((uintptr_t)_29633 + (uintptr_t)HIGH_BITS) >= 0){
        _29633 = NewDouble((eudouble)_29633);
    }
    if (IS_ATOM_INT(_29633)) {
        _29634 = _29633 + _has_integer_59264;
        if ((object)((uintptr_t)_29634 + (uintptr_t)HIGH_BITS) >= 0){
            _29634 = NewDouble((eudouble)_29634);
        }
    }
    else {
        _29634 = NewDouble(DBL_PTR(_29633)->dbl + (eudouble)_has_integer_59264);
    }
    DeRef(_29633);
    _29633 = NOVALUE;
    if (binary_op_a(LESSEQ, _29634, 1)){
        DeRef(_29634);
        _29634 = NOVALUE;
        goto L4; // [128] 152
    }
    DeRef(_29634);
    _29634 = NOVALUE;

    /** parser.e:2624				SymTab[sym][S_SEQ_ELEM] = TYPE_OBJECT*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_59262 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 16;
    DeRef(_1);
    _29636 = NOVALUE;
    goto L3; // [149] 216
L4: 

    /** parser.e:2626			elsif has_atom then*/
    if (_has_atom_59265 == 0)
    {
        goto L5; // [154] 177
    }
    else{
    }

    /** parser.e:2627				SymTab[sym][S_SEQ_ELEM] = TYPE_ATOM*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_59262 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 4;
    DeRef(_1);
    _29638 = NOVALUE;
    goto L3; // [174] 216
L5: 

    /** parser.e:2630				SymTab[sym][S_SEQ_ELEM] = TYPE_SEQUENCE*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_59262 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 8;
    DeRef(_1);
    _29640 = NOVALUE;
    goto L3; // [195] 216
L1: 

    /** parser.e:2634			SymTab[sym][S_SEQ_ELEM] = TYPE_NULL*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_59262 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);
    _29642 = NOVALUE;
L3: 

    /** parser.e:2636	end procedure*/
    _29626 = NOVALUE;
    return;
    ;
}


void _45optimize_switch(object _switch_pc_59327, object _else_bp_59328, object _cases_59329, object _jump_table_59330)
{
    object _values_59331 = NOVALUE;
    object _min_59335 = NOVALUE;
    object _max_59337 = NOVALUE;
    object _all_ints_59339 = NOVALUE;
    object _has_integer_59340 = NOVALUE;
    object _has_atom_59341 = NOVALUE;
    object _has_sequence_59342 = NOVALUE;
    object _has_unassigned_59343 = NOVALUE;
    object _has_fwdref_59344 = NOVALUE;
    object _unique_values_59345 = NOVALUE;
    object _unique_jumps_59347 = NOVALUE;
    object _new_1__tmp_at74_59350 = NOVALUE;
    object _new_inlined_new_at_74_59349 = NOVALUE;
    object _jump_59351 = NOVALUE;
    object _jump_offset_59355 = NOVALUE;
    object _sym_59362 = NOVALUE;
    object _sign_59364 = NOVALUE;
    object _value_i_59377 = NOVALUE;
    object _v_59401 = NOVALUE;
    object _else_target_59487 = NOVALUE;
    object _opcode_59490 = NOVALUE;
    object _delta_59496 = NOVALUE;
    object _switch_table_59506 = NOVALUE;
    object _offset_59509 = NOVALUE;
    object _29756 = NOVALUE;
    object _29755 = NOVALUE;
    object _29754 = NOVALUE;
    object _29753 = NOVALUE;
    object _29751 = NOVALUE;
    object _29749 = NOVALUE;
    object _29746 = NOVALUE;
    object _29745 = NOVALUE;
    object _29744 = NOVALUE;
    object _29743 = NOVALUE;
    object _29742 = NOVALUE;
    object _29741 = NOVALUE;
    object _29740 = NOVALUE;
    object _29737 = NOVALUE;
    object _29736 = NOVALUE;
    object _29735 = NOVALUE;
    object _29734 = NOVALUE;
    object _29733 = NOVALUE;
    object _29732 = NOVALUE;
    object _29728 = NOVALUE;
    object _29727 = NOVALUE;
    object _29725 = NOVALUE;
    object _29724 = NOVALUE;
    object _29723 = NOVALUE;
    object _29722 = NOVALUE;
    object _29721 = NOVALUE;
    object _29720 = NOVALUE;
    object _29719 = NOVALUE;
    object _29718 = NOVALUE;
    object _29717 = NOVALUE;
    object _29716 = NOVALUE;
    object _29714 = NOVALUE;
    object _29713 = NOVALUE;
    object _29709 = NOVALUE;
    object _29707 = NOVALUE;
    object _29706 = NOVALUE;
    object _29705 = NOVALUE;
    object _29703 = NOVALUE;
    object _29700 = NOVALUE;
    object _29699 = NOVALUE;
    object _29698 = NOVALUE;
    object _29696 = NOVALUE;
    object _29695 = NOVALUE;
    object _29694 = NOVALUE;
    object _29692 = NOVALUE;
    object _29691 = NOVALUE;
    object _29690 = NOVALUE;
    object _29688 = NOVALUE;
    object _29687 = NOVALUE;
    object _29686 = NOVALUE;
    object _29684 = NOVALUE;
    object _29681 = NOVALUE;
    object _29680 = NOVALUE;
    object _29679 = NOVALUE;
    object _29678 = NOVALUE;
    object _29677 = NOVALUE;
    object _29676 = NOVALUE;
    object _29675 = NOVALUE;
    object _29674 = NOVALUE;
    object _29673 = NOVALUE;
    object _29672 = NOVALUE;
    object _29671 = NOVALUE;
    object _29670 = NOVALUE;
    object _29667 = NOVALUE;
    object _29666 = NOVALUE;
    object _29665 = NOVALUE;
    object _29663 = NOVALUE;
    object _29662 = NOVALUE;
    object _29660 = NOVALUE;
    object _29659 = NOVALUE;
    object _29658 = NOVALUE;
    object _29654 = NOVALUE;
    object _29653 = NOVALUE;
    object _29652 = NOVALUE;
    object _29650 = NOVALUE;
    object _29649 = NOVALUE;
    object _29645 = NOVALUE;
    object _29644 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:2641		sequence values = switch_stack[$][SWITCH_CASES]*/
    if (IS_SEQUENCE(_45switch_stack_55605)){
            _29644 = SEQ_PTR(_45switch_stack_55605)->length;
    }
    else {
        _29644 = 1;
    }
    _2 = (object)SEQ_PTR(_45switch_stack_55605);
    _29645 = (object)*(((s1_ptr)_2)->base + _29644);
    DeRef(_values_59331);
    _2 = (object)SEQ_PTR(_29645);
    _values_59331 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_values_59331);
    _29645 = NOVALUE;

    /** parser.e:2642		atom min =  1e+300*/
    RefDS(_29647);
    DeRef(_min_59335);
    _min_59335 = _29647;

    /** parser.e:2643		atom max = -1e+300*/
    RefDS(_29648);
    DeRef(_max_59337);
    _max_59337 = _29648;

    /** parser.e:2644		integer all_ints = 1*/
    _all_ints_59339 = 1;

    /** parser.e:2645		integer has_integer    = 0*/
    _has_integer_59340 = 0;

    /** parser.e:2646		integer has_atom       = 0*/
    _has_atom_59341 = 0;

    /** parser.e:2647		integer has_sequence   = 0*/
    _has_sequence_59342 = 0;

    /** parser.e:2648		integer has_unassigned = 0*/
    _has_unassigned_59343 = 0;

    /** parser.e:2649		integer has_fwdref     = 0*/
    _has_fwdref_59344 = 0;

    /** parser.e:2650		sequence unique_values = {}*/
    RefDS(_22190);
    DeRef(_unique_values_59345);
    _unique_values_59345 = _22190;

    /** parser.e:2651		map unique_jumps = map:new()*/

    /** map.e:271		return eumem:malloc( new_map_seq( initial_size_p ) )*/
    _0 = _new_1__tmp_at74_59350;
    _new_1__tmp_at74_59350 = _29new_map_seq(8);
    DeRef(_0);
    Ref(_new_1__tmp_at74_59350);
    _0 = _unique_jumps_59347;
    _unique_jumps_59347 = _30malloc(_new_1__tmp_at74_59350, 1);
    DeRef(_0);
    DeRef(_new_1__tmp_at74_59350);
    _new_1__tmp_at74_59350 = NOVALUE;

    /** parser.e:2653		sequence jump = switch_stack[$][SWITCH_JUMP_TABLE]*/
    if (IS_SEQUENCE(_45switch_stack_55605)){
            _29649 = SEQ_PTR(_45switch_stack_55605)->length;
    }
    else {
        _29649 = 1;
    }
    _2 = (object)SEQ_PTR(_45switch_stack_55605);
    _29650 = (object)*(((s1_ptr)_2)->base + _29649);
    DeRef(_jump_59351);
    _2 = (object)SEQ_PTR(_29650);
    _jump_59351 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_jump_59351);
    _29650 = NOVALUE;

    /** parser.e:2654		integer jump_offset = 0*/
    _jump_offset_59355 = 0;

    /** parser.e:2655		for i = 1 to length( values ) do*/
    if (IS_SEQUENCE(_values_59331)){
            _29652 = SEQ_PTR(_values_59331)->length;
    }
    else {
        _29652 = 1;
    }
    {
        object _i_59357;
        _i_59357 = 1;
L1: 
        if (_i_59357 > _29652){
            goto L2; // [116] 586
        }

        /** parser.e:2656			if sequence( values[i] ) then*/
        _2 = (object)SEQ_PTR(_values_59331);
        _29653 = (object)*(((s1_ptr)_2)->base + _i_59357);
        _29654 = IS_SEQUENCE(_29653);
        _29653 = NOVALUE;
        if (_29654 == 0)
        {
            _29654 = NOVALUE;
            goto L3; // [132] 145
        }
        else{
            _29654 = NOVALUE;
        }

        /** parser.e:2657				has_fwdref = 1*/
        _has_fwdref_59344 = 1;

        /** parser.e:2658				exit*/
        goto L2; // [142] 586
L3: 

        /** parser.e:2660			integer sym = values[i]*/
        _2 = (object)SEQ_PTR(_values_59331);
        _sym_59362 = (object)*(((s1_ptr)_2)->base + _i_59357);
        if (!IS_ATOM_INT(_sym_59362))
        _sym_59362 = (object)DBL_PTR(_sym_59362)->dbl;

        /** parser.e:2661			integer sign*/

        /** parser.e:2663			if sym < 0 then*/
        if (_sym_59362 >= 0)
        goto L4; // [155] 174

        /** parser.e:2664				sign = -1*/
        _sign_59364 = -1;

        /** parser.e:2665				sym = -sym*/
        _sym_59362 = - _sym_59362;
        goto L5; // [171] 180
L4: 

        /** parser.e:2667				sign = 1*/
        _sign_59364 = 1;
L5: 

        /** parser.e:2669			if not equal(SymTab[sym][S_OBJ], NOVALUE) then*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _29658 = (object)*(((s1_ptr)_2)->base + _sym_59362);
        _2 = (object)SEQ_PTR(_29658);
        _29659 = (object)*(((s1_ptr)_2)->base + 1);
        _29658 = NOVALUE;
        if (_29659 == _36NOVALUE_21621)
        _29660 = 1;
        else if (IS_ATOM_INT(_29659) && IS_ATOM_INT(_36NOVALUE_21621))
        _29660 = 0;
        else
        _29660 = (compare(_29659, _36NOVALUE_21621) == 0);
        _29659 = NOVALUE;
        if (_29660 != 0)
        goto L6; // [200] 565
        _29660 = NOVALUE;

        /** parser.e:2670				object value_i = sign * SymTab[sym][S_OBJ]*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _29662 = (object)*(((s1_ptr)_2)->base + _sym_59362);
        _2 = (object)SEQ_PTR(_29662);
        _29663 = (object)*(((s1_ptr)_2)->base + 1);
        _29662 = NOVALUE;
        DeRef(_value_i_59377);
        if (IS_ATOM_INT(_29663)) {
            if (_sign_59364 == (short)_sign_59364 && _29663 <= INT15 && _29663 >= -INT15){
                _value_i_59377 = _sign_59364 * _29663;
            }
            else{
                _value_i_59377 = NewDouble(_sign_59364 * (eudouble)_29663);
            }
        }
        else {
            _value_i_59377 = binary_op(MULTIPLY, _sign_59364, _29663);
        }
        _29663 = NOVALUE;

        /** parser.e:2671				values[i] = value_i*/
        Ref(_value_i_59377);
        _2 = (object)SEQ_PTR(_values_59331);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _values_59331 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_59357);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _value_i_59377;
        DeRef(_1);

        /** parser.e:2672				if TRANSLATE then*/
        if (_36TRANSLATE_21369 == 0)
        {
            goto L7; // [233] 274
        }
        else{
        }

        /** parser.e:2673					if Code[jump[i]-2] = CASE then*/
        _2 = (object)SEQ_PTR(_jump_59351);
        _29665 = (object)*(((s1_ptr)_2)->base + _i_59357);
        if (IS_ATOM_INT(_29665)) {
            _29666 = _29665 - 2;
        }
        else {
            _29666 = binary_op(MINUS, _29665, 2);
        }
        _29665 = NOVALUE;
        _2 = (object)SEQ_PTR(_36Code_21859);
        if (!IS_ATOM_INT(_29666)){
            _29667 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_29666)->dbl));
        }
        else{
            _29667 = (object)*(((s1_ptr)_2)->base + _29666);
        }
        if (binary_op_a(NOTEQ, _29667, 186)){
            _29667 = NOVALUE;
            goto L8; // [254] 267
        }
        _29667 = NOVALUE;

        /** parser.e:2674						jump_offset -=2*/
        _jump_offset_59355 = _jump_offset_59355 - 2;
        goto L9; // [264] 273
L8: 

        /** parser.e:2676						jump_offset = 0*/
        _jump_offset_59355 = 0;
L9: 
L7: 

        /** parser.e:2680				if find( value_i, map:get( unique_jumps, jump[i] + jump_offset, {}) ) then*/
        _2 = (object)SEQ_PTR(_jump_59351);
        _29670 = (object)*(((s1_ptr)_2)->base + _i_59357);
        if (IS_ATOM_INT(_29670)) {
            _29671 = _29670 + _jump_offset_59355;
            if ((object)((uintptr_t)_29671 + (uintptr_t)HIGH_BITS) >= 0){
                _29671 = NewDouble((eudouble)_29671);
            }
        }
        else {
            _29671 = binary_op(PLUS, _29670, _jump_offset_59355);
        }
        _29670 = NOVALUE;
        Ref(_unique_jumps_59347);
        RefDS(_22190);
        _29672 = _29get(_unique_jumps_59347, _29671, _22190);
        _29671 = NOVALUE;
        _29673 = find_from(_value_i_59377, _29672, 1);
        DeRef(_29672);
        _29672 = NOVALUE;
        if (_29673 == 0)
        {
            _29673 = NOVALUE;
            goto LA; // [295] 301
        }
        else{
            _29673 = NOVALUE;
        }
        goto LB; // [298] 560
LA: 

        /** parser.e:2683				elsif find( value_i, unique_values ) then*/
        _29674 = find_from(_value_i_59377, _unique_values_59345, 1);
        if (_29674 == 0)
        {
            _29674 = NOVALUE;
            goto LC; // [308] 467
        }
        else{
            _29674 = NOVALUE;
        }

        /** parser.e:2686					object v = ""*/
        RefDS(_22190);
        DeRef(_v_59401);
        _v_59401 = _22190;

        /** parser.e:2687					if length( SymTab[sym] ) > S_NAME and sequence( sym_name( sym ) ) then*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _29675 = (object)*(((s1_ptr)_2)->base + _sym_59362);
        if (IS_SEQUENCE(_29675)){
                _29676 = SEQ_PTR(_29675)->length;
        }
        else {
            _29676 = 1;
        }
        _29675 = NOVALUE;
        if (IS_ATOM_INT(_36S_NAME_21404)) {
            _29677 = (_29676 > _36S_NAME_21404);
        }
        else {
            _29677 = binary_op(GREATER, _29676, _36S_NAME_21404);
        }
        _29676 = NOVALUE;
        if (IS_ATOM_INT(_29677)) {
            if (_29677 == 0) {
                goto LD; // [333] 359
            }
        }
        else {
            if (DBL_PTR(_29677)->dbl == 0.0) {
                goto LD; // [333] 359
            }
        }
        _29679 = _54sym_name(_sym_59362);
        _29680 = IS_SEQUENCE(_29679);
        DeRef(_29679);
        _29679 = NOVALUE;
        if (_29680 == 0)
        {
            _29680 = NOVALUE;
            goto LD; // [345] 359
        }
        else{
            _29680 = NOVALUE;
        }

        /** parser.e:2688						v = sym_name( sym ) & " = " */
        _29681 = _54sym_name(_sym_59362);
        if (IS_SEQUENCE(_29681) && IS_ATOM(_29682)) {
        }
        else if (IS_ATOM(_29681) && IS_SEQUENCE(_29682)) {
            Ref(_29681);
            Prepend(&_v_59401, _29682, _29681);
        }
        else {
            Concat((object_ptr)&_v_59401, _29681, _29682);
            DeRef(_29681);
            _29681 = NOVALUE;
        }
        DeRef(_29681);
        _29681 = NOVALUE;
LD: 

        /** parser.e:2691					v &= sprint( value_i )*/
        Ref(_value_i_59377);
        _29684 = _14sprint(_value_i_59377);
        if (IS_SEQUENCE(_v_59401) && IS_ATOM(_29684)) {
            Ref(_29684);
            Append(&_v_59401, _v_59401, _29684);
        }
        else if (IS_ATOM(_v_59401) && IS_SEQUENCE(_29684)) {
            Ref(_v_59401);
            Prepend(&_v_59401, _29684, _v_59401);
        }
        else {
            Concat((object_ptr)&_v_59401, _v_59401, _29684);
        }
        DeRef(_29684);
        _29684 = NOVALUE;

        /** parser.e:2692					ThisLine        = switch_stack[$][SWITCH_THISLINE][i]*/
        if (IS_SEQUENCE(_45switch_stack_55605)){
                _29686 = SEQ_PTR(_45switch_stack_55605)->length;
        }
        else {
            _29686 = 1;
        }
        _2 = (object)SEQ_PTR(_45switch_stack_55605);
        _29687 = (object)*(((s1_ptr)_2)->base + _29686);
        _2 = (object)SEQ_PTR(_29687);
        _29688 = (object)*(((s1_ptr)_2)->base + 10);
        _29687 = NOVALUE;
        DeRef(_50ThisLine_49594);
        _2 = (object)SEQ_PTR(_29688);
        _50ThisLine_49594 = (object)*(((s1_ptr)_2)->base + _i_59357);
        Ref(_50ThisLine_49594);
        _29688 = NOVALUE;

        /** parser.e:2693					bp              = switch_stack[$][SWITCH_BP][i]*/
        if (IS_SEQUENCE(_45switch_stack_55605)){
                _29690 = SEQ_PTR(_45switch_stack_55605)->length;
        }
        else {
            _29690 = 1;
        }
        _2 = (object)SEQ_PTR(_45switch_stack_55605);
        _29691 = (object)*(((s1_ptr)_2)->base + _29690);
        _2 = (object)SEQ_PTR(_29691);
        _29692 = (object)*(((s1_ptr)_2)->base + 11);
        _29691 = NOVALUE;
        _2 = (object)SEQ_PTR(_29692);
        _50bp_49598 = (object)*(((s1_ptr)_2)->base + _i_59357);
        if (!IS_ATOM_INT(_50bp_49598)){
            _50bp_49598 = (object)DBL_PTR(_50bp_49598)->dbl;
        }
        _29692 = NOVALUE;

        /** parser.e:2694					line_number     = switch_stack[$][SWITCH_LINE_NUMBER][i]*/
        if (IS_SEQUENCE(_45switch_stack_55605)){
                _29694 = SEQ_PTR(_45switch_stack_55605)->length;
        }
        else {
            _29694 = 1;
        }
        _2 = (object)SEQ_PTR(_45switch_stack_55605);
        _29695 = (object)*(((s1_ptr)_2)->base + _29694);
        _2 = (object)SEQ_PTR(_29695);
        _29696 = (object)*(((s1_ptr)_2)->base + 12);
        _29695 = NOVALUE;
        _2 = (object)SEQ_PTR(_29696);
        _36line_number_21768 = (object)*(((s1_ptr)_2)->base + _i_59357);
        if (!IS_ATOM_INT(_36line_number_21768)){
            _36line_number_21768 = (object)DBL_PTR(_36line_number_21768)->dbl;
        }
        _29696 = NOVALUE;

        /** parser.e:2695					current_file_no = switch_stack[$][SWITCH_CURRENT_FILE_NO][i]*/
        if (IS_SEQUENCE(_45switch_stack_55605)){
                _29698 = SEQ_PTR(_45switch_stack_55605)->length;
        }
        else {
            _29698 = 1;
        }
        _2 = (object)SEQ_PTR(_45switch_stack_55605);
        _29699 = (object)*(((s1_ptr)_2)->base + _29698);
        _2 = (object)SEQ_PTR(_29699);
        _29700 = (object)*(((s1_ptr)_2)->base + 13);
        _29699 = NOVALUE;
        _2 = (object)SEQ_PTR(_29700);
        _36current_file_no_21767 = (object)*(((s1_ptr)_2)->base + _i_59357);
        if (!IS_ATOM_INT(_36current_file_no_21767)){
            _36current_file_no_21767 = (object)DBL_PTR(_36current_file_no_21767)->dbl;
        }
        _29700 = NOVALUE;

        /** parser.e:2697					CompileErr("duplicate case value used in switch: [1]", {v})*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_v_59401);
        ((intptr_t*)_2)[1] = _v_59401;
        _29703 = MAKE_SEQ(_1);
        RefDS(_29702);
        _50CompileErr(_29702, _29703, 0);
        _29703 = NOVALUE;
        DeRefDS(_v_59401);
        _v_59401 = NOVALUE;
        goto LB; // [464] 560
LC: 

        /** parser.e:2700					unique_values   &= value_i*/
        if (IS_SEQUENCE(_unique_values_59345) && IS_ATOM(_value_i_59377)) {
            Ref(_value_i_59377);
            Append(&_unique_values_59345, _unique_values_59345, _value_i_59377);
        }
        else if (IS_ATOM(_unique_values_59345) && IS_SEQUENCE(_value_i_59377)) {
        }
        else {
            Concat((object_ptr)&_unique_values_59345, _unique_values_59345, _value_i_59377);
        }

        /** parser.e:2701					map:put( unique_jumps, jump[i] + jump_offset, value_i, map:APPEND )*/
        _2 = (object)SEQ_PTR(_jump_59351);
        _29705 = (object)*(((s1_ptr)_2)->base + _i_59357);
        if (IS_ATOM_INT(_29705)) {
            _29706 = _29705 + _jump_offset_59355;
            if ((object)((uintptr_t)_29706 + (uintptr_t)HIGH_BITS) >= 0){
                _29706 = NewDouble((eudouble)_29706);
            }
        }
        else {
            _29706 = binary_op(PLUS, _29705, _jump_offset_59355);
        }
        _29705 = NOVALUE;
        Ref(_unique_jumps_59347);
        Ref(_value_i_59377);
        _29put(_unique_jumps_59347, _29706, _value_i_59377, 6, 0);
        _29706 = NOVALUE;

        /** parser.e:2703					if not is_integer( value_i ) then*/
        Ref(_value_i_59377);
        _29707 = _36is_integer(_value_i_59377);
        if (IS_ATOM_INT(_29707)) {
            if (_29707 != 0){
                DeRef(_29707);
                _29707 = NOVALUE;
                goto LE; // [496] 529
            }
        }
        else {
            if (DBL_PTR(_29707)->dbl != 0.0){
                DeRef(_29707);
                _29707 = NOVALUE;
                goto LE; // [496] 529
            }
        }
        DeRef(_29707);
        _29707 = NOVALUE;

        /** parser.e:2704						all_ints = 0*/
        _all_ints_59339 = 0;

        /** parser.e:2705						if atom( value_i ) then*/
        _29709 = IS_ATOM(_value_i_59377);
        if (_29709 == 0)
        {
            _29709 = NOVALUE;
            goto LF; // [509] 520
        }
        else{
            _29709 = NOVALUE;
        }

        /** parser.e:2706							has_atom = 1*/
        _has_atom_59341 = 1;
        goto L10; // [517] 559
LF: 

        /** parser.e:2708							has_sequence = 1*/
        _has_sequence_59342 = 1;
        goto L10; // [526] 559
LE: 

        /** parser.e:2711						has_integer = 1*/
        _has_integer_59340 = 1;

        /** parser.e:2713						if value_i < min then*/
        if (binary_op_a(GREATEREQ, _value_i_59377, _min_59335)){
            goto L11; // [536] 546
        }

        /** parser.e:2714							min = value_i*/
        Ref(_value_i_59377);
        DeRef(_min_59335);
        _min_59335 = _value_i_59377;
L11: 

        /** parser.e:2717						if value_i > max then*/
        if (binary_op_a(LESSEQ, _value_i_59377, _max_59337)){
            goto L12; // [548] 558
        }

        /** parser.e:2718							max = value_i*/
        Ref(_value_i_59377);
        DeRef(_max_59337);
        _max_59337 = _value_i_59377;
L12: 
L10: 
LB: 
        DeRef(_value_i_59377);
        _value_i_59377 = NOVALUE;
        goto L13; // [562] 577
L6: 

        /** parser.e:2723				has_unassigned = 1*/
        _has_unassigned_59343 = 1;

        /** parser.e:2724				exit*/
        goto L2; // [574] 586
L13: 

        /** parser.e:2726		end for*/
        _i_59357 = _i_59357 + 1;
        goto L1; // [581] 123
L2: 
        ;
    }

    /** parser.e:2728		if has_unassigned or has_fwdref then*/
    if (_has_unassigned_59343 != 0) {
        goto L14; // [588] 597
    }
    if (_has_fwdref_59344 == 0)
    {
        goto L15; // [593] 615
    }
    else{
    }
L14: 

    /** parser.e:2729			values = switch_stack[$][SWITCH_CASES]*/
    if (IS_SEQUENCE(_45switch_stack_55605)){
            _29713 = SEQ_PTR(_45switch_stack_55605)->length;
    }
    else {
        _29713 = 1;
    }
    _2 = (object)SEQ_PTR(_45switch_stack_55605);
    _29714 = (object)*(((s1_ptr)_2)->base + _29713);
    DeRef(_values_59331);
    _2 = (object)SEQ_PTR(_29714);
    _values_59331 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_values_59331);
    _29714 = NOVALUE;
L15: 

    /** parser.e:2732		if switch_stack[$][SWITCH_ELSE] then*/
    if (IS_SEQUENCE(_45switch_stack_55605)){
            _29716 = SEQ_PTR(_45switch_stack_55605)->length;
    }
    else {
        _29716 = 1;
    }
    _2 = (object)SEQ_PTR(_45switch_stack_55605);
    _29717 = (object)*(((s1_ptr)_2)->base + _29716);
    _2 = (object)SEQ_PTR(_29717);
    _29718 = (object)*(((s1_ptr)_2)->base + 3);
    _29717 = NOVALUE;
    if (_29718 == 0) {
        _29718 = NOVALUE;
        goto L16; // [630] 657
    }
    else {
        if (!IS_ATOM_INT(_29718) && DBL_PTR(_29718)->dbl == 0.0){
            _29718 = NOVALUE;
            goto L16; // [630] 657
        }
        _29718 = NOVALUE;
    }
    _29718 = NOVALUE;

    /** parser.e:2733				Code[else_bp] = switch_stack[$][SWITCH_ELSE]*/
    if (IS_SEQUENCE(_45switch_stack_55605)){
            _29719 = SEQ_PTR(_45switch_stack_55605)->length;
    }
    else {
        _29719 = 1;
    }
    _2 = (object)SEQ_PTR(_45switch_stack_55605);
    _29720 = (object)*(((s1_ptr)_2)->base + _29719);
    _2 = (object)SEQ_PTR(_29720);
    _29721 = (object)*(((s1_ptr)_2)->base + 3);
    _29720 = NOVALUE;
    Ref(_29721);
    _2 = (object)SEQ_PTR(_36Code_21859);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _36Code_21859 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _else_bp_59328);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29721;
    if( _1 != _29721 ){
        DeRef(_1);
    }
    _29721 = NOVALUE;
    goto L17; // [654] 681
L16: 

    /** parser.e:2736			Code[else_bp] = length(Code) + 1 + TRANSLATE*/
    if (IS_SEQUENCE(_36Code_21859)){
            _29722 = SEQ_PTR(_36Code_21859)->length;
    }
    else {
        _29722 = 1;
    }
    _29723 = _29722 + 1;
    _29722 = NOVALUE;
    _29724 = _29723 + _36TRANSLATE_21369;
    _29723 = NOVALUE;
    _2 = (object)SEQ_PTR(_36Code_21859);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _36Code_21859 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _else_bp_59328);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29724;
    if( _1 != _29724 ){
        DeRef(_1);
    }
    _29724 = NOVALUE;
L17: 

    /** parser.e:2739		if TRANSLATE then*/
    if (_36TRANSLATE_21369 == 0)
    {
        goto L18; // [685] 712
    }
    else{
    }

    /** parser.e:2744			SymTab[cases][S_OBJ] &= 0*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_cases_59329 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _29727 = (object)*(((s1_ptr)_2)->base + 1);
    _29725 = NOVALUE;
    if (IS_SEQUENCE(_29727) && IS_ATOM(0)) {
        Append(&_29728, _29727, 0);
    }
    else if (IS_ATOM(_29727) && IS_SEQUENCE(0)) {
    }
    else {
        Concat((object_ptr)&_29728, _29727, 0);
        _29727 = NOVALUE;
    }
    _29727 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29728;
    if( _1 != _29728 ){
        DeRef(_1);
    }
    _29728 = NOVALUE;
    _29725 = NOVALUE;
L18: 

    /** parser.e:2748		integer else_target = Code[else_bp]*/
    _2 = (object)SEQ_PTR(_36Code_21859);
    _else_target_59487 = (object)*(((s1_ptr)_2)->base + _else_bp_59328);
    if (!IS_ATOM_INT(_else_target_59487)){
        _else_target_59487 = (object)DBL_PTR(_else_target_59487)->dbl;
    }

    /** parser.e:2749		integer opcode = SWITCH*/
    _opcode_59490 = 185;

    /** parser.e:2750		if has_unassigned or has_fwdref then*/
    if (_has_unassigned_59343 != 0) {
        goto L19; // [733] 742
    }
    if (_has_fwdref_59344 == 0)
    {
        goto L1A; // [738] 754
    }
    else{
    }
L19: 

    /** parser.e:2751			opcode = SWITCH_RT*/
    _opcode_59490 = 202;
    goto L1B; // [751] 907
L1A: 

    /** parser.e:2753		elsif all_ints then*/
    if (_all_ints_59339 == 0)
    {
        goto L1C; // [756] 904
    }
    else{
    }

    /** parser.e:2754			atom delta = max - min*/
    DeRef(_delta_59496);
    if (IS_ATOM_INT(_max_59337) && IS_ATOM_INT(_min_59335)) {
        _delta_59496 = _max_59337 - _min_59335;
        if ((object)((uintptr_t)_delta_59496 +(uintptr_t) HIGH_BITS) >= 0){
            _delta_59496 = NewDouble((eudouble)_delta_59496);
        }
    }
    else {
        if (IS_ATOM_INT(_max_59337)) {
            _delta_59496 = NewDouble((eudouble)_max_59337 - DBL_PTR(_min_59335)->dbl);
        }
        else {
            if (IS_ATOM_INT(_min_59335)) {
                _delta_59496 = NewDouble(DBL_PTR(_max_59337)->dbl - (eudouble)_min_59335);
            }
            else
            _delta_59496 = NewDouble(DBL_PTR(_max_59337)->dbl - DBL_PTR(_min_59335)->dbl);
        }
    }

    /** parser.e:2755			if not TRANSLATE and  delta < 1024 and delta >= 0 then*/
    _29732 = (_36TRANSLATE_21369 == 0);
    if (_29732 == 0) {
        _29733 = 0;
        goto L1D; // [772] 784
    }
    if (IS_ATOM_INT(_delta_59496)) {
        _29734 = (_delta_59496 < 1024);
    }
    else {
        _29734 = (DBL_PTR(_delta_59496)->dbl < (eudouble)1024);
    }
    _29733 = (_29734 != 0);
L1D: 
    if (_29733 == 0) {
        goto L1E; // [784] 893
    }
    if (IS_ATOM_INT(_delta_59496)) {
        _29736 = (_delta_59496 >= 0);
    }
    else {
        _29736 = (DBL_PTR(_delta_59496)->dbl >= (eudouble)0);
    }
    if (_29736 == 0)
    {
        DeRef(_29736);
        _29736 = NOVALUE;
        goto L1E; // [793] 893
    }
    else{
        DeRef(_29736);
        _29736 = NOVALUE;
    }

    /** parser.e:2756				opcode = SWITCH_SPI*/
    _opcode_59490 = 192;

    /** parser.e:2758				sequence switch_table = repeat( else_target, delta + 1 )*/
    if (IS_ATOM_INT(_delta_59496)) {
        _29737 = _delta_59496 + 1;
    }
    else
    _29737 = binary_op(PLUS, 1, _delta_59496);
    DeRef(_switch_table_59506);
    _switch_table_59506 = Repeat(_else_target_59487, _29737);
    DeRef(_29737);
    _29737 = NOVALUE;

    /** parser.e:2759				integer offset = min - 1*/
    if (IS_ATOM_INT(_min_59335)) {
        _offset_59509 = _min_59335 - 1;
    }
    else {
        _offset_59509 = NewDouble(DBL_PTR(_min_59335)->dbl - (eudouble)1);
    }
    if (!IS_ATOM_INT(_offset_59509)) {
        _1 = (object)(DBL_PTR(_offset_59509)->dbl);
        DeRefDS(_offset_59509);
        _offset_59509 = _1;
    }

    /** parser.e:2760				for i = 1 to length( values ) do*/
    if (IS_SEQUENCE(_values_59331)){
            _29740 = SEQ_PTR(_values_59331)->length;
    }
    else {
        _29740 = 1;
    }
    {
        object _i_59512;
        _i_59512 = 1;
L1F: 
        if (_i_59512 > _29740){
            goto L20; // [828] 860
        }

        /** parser.e:2761					switch_table[values[i] - offset] = jump[i]*/
        _2 = (object)SEQ_PTR(_values_59331);
        _29741 = (object)*(((s1_ptr)_2)->base + _i_59512);
        if (IS_ATOM_INT(_29741)) {
            _29742 = _29741 - _offset_59509;
            if ((object)((uintptr_t)_29742 +(uintptr_t) HIGH_BITS) >= 0){
                _29742 = NewDouble((eudouble)_29742);
            }
        }
        else {
            _29742 = binary_op(MINUS, _29741, _offset_59509);
        }
        _29741 = NOVALUE;
        _2 = (object)SEQ_PTR(_jump_59351);
        _29743 = (object)*(((s1_ptr)_2)->base + _i_59512);
        Ref(_29743);
        _2 = (object)SEQ_PTR(_switch_table_59506);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _switch_table_59506 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_29742))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_29742)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _29742);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _29743;
        if( _1 != _29743 ){
            DeRef(_1);
        }
        _29743 = NOVALUE;

        /** parser.e:2762				end for*/
        _i_59512 = _i_59512 + 1;
        goto L1F; // [855] 835
L20: 
        ;
    }

    /** parser.e:2763				Code[switch_pc + 2] = offset*/
    _29744 = _switch_pc_59327 + 2;
    _2 = (object)SEQ_PTR(_36Code_21859);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _36Code_21859 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _29744);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _offset_59509;
    DeRef(_1);

    /** parser.e:2764				switch_stack[$][SWITCH_JUMP_TABLE] = switch_table*/
    if (IS_SEQUENCE(_45switch_stack_55605)){
            _29745 = SEQ_PTR(_45switch_stack_55605)->length;
    }
    else {
        _29745 = 1;
    }
    _2 = (object)SEQ_PTR(_45switch_stack_55605);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _45switch_stack_55605 = MAKE_SEQ(_2);
    }
    _3 = (object)(_29745 + ((s1_ptr)_2)->base);
    RefDS(_switch_table_59506);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _switch_table_59506;
    DeRef(_1);
    _29746 = NOVALUE;
    DeRefDS(_switch_table_59506);
    _switch_table_59506 = NOVALUE;
    goto L21; // [890] 903
L1E: 

    /** parser.e:2766				opcode = SWITCH_I*/
    _opcode_59490 = 193;
L21: 
L1C: 
    DeRef(_delta_59496);
    _delta_59496 = NOVALUE;
L1B: 

    /** parser.e:2770		Code[switch_pc] = opcode*/
    _2 = (object)SEQ_PTR(_36Code_21859);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _36Code_21859 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _switch_pc_59327);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _opcode_59490;
    DeRef(_1);

    /** parser.e:2771		if opcode != SWITCH_SPI then*/
    if (_opcode_59490 == 192)
    goto L22; // [919] 956

    /** parser.e:2772			SymTab[cases][S_OBJ] = values*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_cases_59329 + ((s1_ptr)_2)->base);
    RefDS(_values_59331);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _values_59331;
    DeRef(_1);
    _29749 = NOVALUE;

    /** parser.e:2773			if TRANSLATE then*/
    if (_36TRANSLATE_21369 == 0)
    {
        goto L23; // [942] 955
    }
    else{
    }

    /** parser.e:2774				update_translator_info( cases, all_ints, has_integer, has_atom, has_sequence )*/
    _45update_translator_info(_cases_59329, _all_ints_59339, _has_integer_59340, _has_atom_59341, _has_sequence_59342);
L23: 
L22: 

    /** parser.e:2779		SymTab[jump_table][S_OBJ] = switch_stack[$][SWITCH_JUMP_TABLE] - switch_pc*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_jump_table_59330 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_45switch_stack_55605)){
            _29753 = SEQ_PTR(_45switch_stack_55605)->length;
    }
    else {
        _29753 = 1;
    }
    _2 = (object)SEQ_PTR(_45switch_stack_55605);
    _29754 = (object)*(((s1_ptr)_2)->base + _29753);
    _2 = (object)SEQ_PTR(_29754);
    _29755 = (object)*(((s1_ptr)_2)->base + 2);
    _29754 = NOVALUE;
    if (IS_ATOM_INT(_29755)) {
        _29756 = _29755 - _switch_pc_59327;
        if ((object)((uintptr_t)_29756 +(uintptr_t) HIGH_BITS) >= 0){
            _29756 = NewDouble((eudouble)_29756);
        }
    }
    else {
        _29756 = binary_op(MINUS, _29755, _switch_pc_59327);
    }
    _29755 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29756;
    if( _1 != _29756 ){
        DeRef(_1);
    }
    _29756 = NOVALUE;
    _29751 = NOVALUE;

    /** parser.e:2781	end procedure*/
    DeRef(_values_59331);
    DeRef(_min_59335);
    DeRef(_max_59337);
    DeRef(_unique_values_59345);
    DeRef(_unique_jumps_59347);
    DeRef(_jump_59351);
    DeRef(_29666);
    _29666 = NOVALUE;
    DeRef(_29734);
    _29734 = NOVALUE;
    DeRef(_29742);
    _29742 = NOVALUE;
    DeRef(_29744);
    _29744 = NOVALUE;
    DeRef(_29732);
    _29732 = NOVALUE;
    DeRef(_29677);
    _29677 = NOVALUE;
    _29675 = NOVALUE;
    return;
    ;
}


void _45Switch_statement()
{
    object _else_case_2__tmp_at250_59606 = NOVALUE;
    object _else_case_1__tmp_at250_59605 = NOVALUE;
    object _else_case_inlined_else_case_at_250_59604 = NOVALUE;
    object _break_base_59544 = NOVALUE;
    object _cases_59546 = NOVALUE;
    object _jump_table_59547 = NOVALUE;
    object _else_bp_59548 = NOVALUE;
    object _switch_pc_59549 = NOVALUE;
    object _t_59586 = NOVALUE;
    object _29787 = NOVALUE;
    object _29786 = NOVALUE;
    object _29785 = NOVALUE;
    object _29784 = NOVALUE;
    object _29783 = NOVALUE;
    object _29779 = NOVALUE;
    object _29775 = NOVALUE;
    object _29774 = NOVALUE;
    object _29772 = NOVALUE;
    object _29771 = NOVALUE;
    object _29769 = NOVALUE;
    object _29768 = NOVALUE;
    object _29766 = NOVALUE;
    object _29765 = NOVALUE;
    object _29764 = NOVALUE;
    object _29763 = NOVALUE;
    object _29762 = NOVALUE;
    object _29761 = NOVALUE;
    object _29759 = NOVALUE;
    object _29758 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:2786		integer else_bp*/

    /** parser.e:2787		integer switch_pc*/

    /** parser.e:2789		push_switch()*/
    _45push_switch();

    /** parser.e:2790		break_base = length(break_list)*/
    if (IS_SEQUENCE(_45break_list_55374)){
            _break_base_59544 = SEQ_PTR(_45break_list_55374)->length;
    }
    else {
        _break_base_59544 = 1;
    }

    /** parser.e:2792		Expr()*/
    _45Expr();

    /** parser.e:2793		switch_stack[$][SWITCH_VALUE] = Top()*/
    if (IS_SEQUENCE(_45switch_stack_55605)){
            _29758 = SEQ_PTR(_45switch_stack_55605)->length;
    }
    else {
        _29758 = 1;
    }
    _2 = (object)SEQ_PTR(_45switch_stack_55605);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _45switch_stack_55605 = MAKE_SEQ(_2);
    }
    _3 = (object)(_29758 + ((s1_ptr)_2)->base);
    _29761 = _47Top();
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 6);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29761;
    if( _1 != _29761 ){
        DeRef(_1);
    }
    _29761 = NOVALUE;
    _29759 = NOVALUE;

    /** parser.e:2794		clear_temp( switch_stack[$][SWITCH_VALUE] )*/
    if (IS_SEQUENCE(_45switch_stack_55605)){
            _29762 = SEQ_PTR(_45switch_stack_55605)->length;
    }
    else {
        _29762 = 1;
    }
    _2 = (object)SEQ_PTR(_45switch_stack_55605);
    _29763 = (object)*(((s1_ptr)_2)->base + _29762);
    _2 = (object)SEQ_PTR(_29763);
    _29764 = (object)*(((s1_ptr)_2)->base + 6);
    _29763 = NOVALUE;
    Ref(_29764);
    _47clear_temp(_29764);
    _29764 = NOVALUE;

    /** parser.e:2796		cases = NewStringSym( {-1, length(SymTab) } )*/
    if (IS_SEQUENCE(_37SymTab_15637)){
            _29765 = SEQ_PTR(_37SymTab_15637)->length;
    }
    else {
        _29765 = 1;
    }
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -1;
    ((intptr_t *)_2)[2] = _29765;
    _29766 = MAKE_SEQ(_1);
    _29765 = NOVALUE;
    _cases_59546 = _54NewStringSym(_29766);
    _29766 = NOVALUE;
    if (!IS_ATOM_INT(_cases_59546)) {
        _1 = (object)(DBL_PTR(_cases_59546)->dbl);
        DeRefDS(_cases_59546);
        _cases_59546 = _1;
    }

    /** parser.e:2798		emit_opnd( cases )*/
    _47emit_opnd(_cases_59546);

    /** parser.e:2800		jump_table = NewStringSym( {-2, length(SymTab) } )*/
    if (IS_SEQUENCE(_37SymTab_15637)){
            _29768 = SEQ_PTR(_37SymTab_15637)->length;
    }
    else {
        _29768 = 1;
    }
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -2;
    ((intptr_t *)_2)[2] = _29768;
    _29769 = MAKE_SEQ(_1);
    _29768 = NOVALUE;
    _jump_table_59547 = _54NewStringSym(_29769);
    _29769 = NOVALUE;
    if (!IS_ATOM_INT(_jump_table_59547)) {
        _1 = (object)(DBL_PTR(_jump_table_59547)->dbl);
        DeRefDS(_jump_table_59547);
        _jump_table_59547 = _1;
    }

    /** parser.e:2801		emit_opnd( jump_table )*/
    _47emit_opnd(_jump_table_59547);

    /** parser.e:2803		if finish_block_header(SWITCH) then end if*/
    _29771 = _45finish_block_header(185);
    if (_29771 == 0) {
        DeRef(_29771);
        _29771 = NOVALUE;
        goto L1; // [109] 113
    }
    else {
        if (!IS_ATOM_INT(_29771) && DBL_PTR(_29771)->dbl == 0.0){
            DeRef(_29771);
            _29771 = NOVALUE;
            goto L1; // [109] 113
        }
        DeRef(_29771);
        _29771 = NOVALUE;
    }
    DeRef(_29771);
    _29771 = NOVALUE;
L1: 

    /** parser.e:2805		switch_pc = length(Code) + 1*/
    if (IS_SEQUENCE(_36Code_21859)){
            _29772 = SEQ_PTR(_36Code_21859)->length;
    }
    else {
        _29772 = 1;
    }
    _switch_pc_59549 = _29772 + 1;
    _29772 = NOVALUE;

    /** parser.e:2806		switch_stack[$][SWITCH_PC] = switch_pc*/
    if (IS_SEQUENCE(_45switch_stack_55605)){
            _29774 = SEQ_PTR(_45switch_stack_55605)->length;
    }
    else {
        _29774 = 1;
    }
    _2 = (object)SEQ_PTR(_45switch_stack_55605);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _45switch_stack_55605 = MAKE_SEQ(_2);
    }
    _3 = (object)(_29774 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _switch_pc_59549;
    DeRef(_1);
    _29775 = NOVALUE;

    /** parser.e:2808		emit_op(SWITCH)*/
    _47emit_op(185);

    /** parser.e:2809		emit_forward_addr()  -- the else*/
    _45emit_forward_addr();

    /** parser.e:2810		else_bp = length( Code )*/
    if (IS_SEQUENCE(_36Code_21859)){
            _else_bp_59548 = SEQ_PTR(_36Code_21859)->length;
    }
    else {
        _else_bp_59548 = 1;
    }

    /** parser.e:2813		t = next_token()*/
    _0 = _t_59586;
    _t_59586 = _45next_token();
    DeRef(_0);

    /** parser.e:2814		if t[T_ID] = CASE then*/
    _2 = (object)SEQ_PTR(_t_59586);
    _29779 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29779, 186)){
        _29779 = NOVALUE;
        goto L2; // [173] 188
    }
    _29779 = NOVALUE;

    /** parser.e:2816			Case_statement()*/
    _45Case_statement();

    /** parser.e:2818			Statement_list()*/
    _45Statement_list();
    goto L3; // [185] 194
L2: 

    /** parser.e:2821			putback(t)*/
    Ref(_t_59586);
    _45putback(_t_59586);
L3: 

    /** parser.e:2824		optimize_switch( switch_pc, else_bp, cases, jump_table )*/
    _45optimize_switch(_switch_pc_59549, _else_bp_59548, _cases_59546, _jump_table_59547);

    /** parser.e:2825		tok_match(END)*/
    _45tok_match(402, 0);

    /** parser.e:2826		tok_match(SWITCH, END)*/
    _45tok_match(185, 402);

    /** parser.e:2827		if TRANSLATE then*/
    if (_36TRANSLATE_21369 == 0)
    {
        goto L4; // [224] 235
    }
    else{
    }

    /** parser.e:2828			emit_op(NOPSWITCH)*/
    _47emit_op(187);
L4: 

    /** parser.e:2831		if not else_case() then*/

    /** parser.e:2472		return switch_stack[$][SWITCH_ELSE]*/
    if (IS_SEQUENCE(_45switch_stack_55605)){
            _else_case_1__tmp_at250_59605 = SEQ_PTR(_45switch_stack_55605)->length;
    }
    else {
        _else_case_1__tmp_at250_59605 = 1;
    }
    DeRef(_else_case_2__tmp_at250_59606);
    _2 = (object)SEQ_PTR(_45switch_stack_55605);
    _else_case_2__tmp_at250_59606 = (object)*(((s1_ptr)_2)->base + _else_case_1__tmp_at250_59605);
    RefDS(_else_case_2__tmp_at250_59606);
    DeRef(_else_case_inlined_else_case_at_250_59604);
    _2 = (object)SEQ_PTR(_else_case_2__tmp_at250_59606);
    _else_case_inlined_else_case_at_250_59604 = (object)*(((s1_ptr)_2)->base + 3);
    Ref(_else_case_inlined_else_case_at_250_59604);
    DeRef(_else_case_2__tmp_at250_59606);
    _else_case_2__tmp_at250_59606 = NOVALUE;
    if (IS_ATOM_INT(_else_case_inlined_else_case_at_250_59604)) {
        if (_else_case_inlined_else_case_at_250_59604 != 0){
            goto L5; // [255] 327
        }
    }
    else {
        if (DBL_PTR(_else_case_inlined_else_case_at_250_59604)->dbl != 0.0){
            goto L5; // [255] 327
        }
    }

    /** parser.e:2832			if not TRANSLATE then*/
    if (_36TRANSLATE_21369 != 0)
    goto L6; // [262] 303

    /** parser.e:2833				StartSourceLine( TRUE, , COVERAGE_SUPPRESS )*/
    _47StartSourceLine(_13TRUE_447, 0, 1);

    /** parser.e:2834				emit_temp( switch_stack[$][SWITCH_VALUE], NEW_REFERENCE )*/
    if (IS_SEQUENCE(_45switch_stack_55605)){
            _29783 = SEQ_PTR(_45switch_stack_55605)->length;
    }
    else {
        _29783 = 1;
    }
    _2 = (object)SEQ_PTR(_45switch_stack_55605);
    _29784 = (object)*(((s1_ptr)_2)->base + _29783);
    _2 = (object)SEQ_PTR(_29784);
    _29785 = (object)*(((s1_ptr)_2)->base + 6);
    _29784 = NOVALUE;
    Ref(_29785);
    _47emit_temp(_29785, 1);
    _29785 = NOVALUE;

    /** parser.e:2835				flush_temps()*/
    RefDS(_22190);
    _47flush_temps(_22190);
L6: 

    /** parser.e:2838			Warning(221, no_case_else_warning_flag,*/
    _2 = (object)SEQ_PTR(_37known_files_15638);
    _29786 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21767);
    Ref(_29786);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _29786;
    ((intptr_t *)_2)[2] = _36line_number_21768;
    _29787 = MAKE_SEQ(_1);
    _29786 = NOVALUE;
    _50Warning(221, 4096, _29787);
    _29787 = NOVALUE;
L5: 

    /** parser.e:2841		pop_switch( break_base )*/
    _45pop_switch(_break_base_59544);

    /** parser.e:2842	end procedure*/
    DeRef(_t_59586);
    return;
    ;
}


object _45get_private_uninitialized()
{
    object _uninitialized_59629 = NOVALUE;
    object _s_59635 = NOVALUE;
    object _pu_59641 = NOVALUE;
    object _29804 = NOVALUE;
    object _29802 = NOVALUE;
    object _29801 = NOVALUE;
    object _29800 = NOVALUE;
    object _29799 = NOVALUE;
    object _29798 = NOVALUE;
    object _29797 = NOVALUE;
    object _29796 = NOVALUE;
    object _29795 = NOVALUE;
    object _29794 = NOVALUE;
    object _29793 = NOVALUE;
    object _29792 = NOVALUE;
    object _29789 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:2845		sequence uninitialized = {}*/
    RefDS(_22190);
    DeRefi(_uninitialized_59629);
    _uninitialized_59629 = _22190;

    /** parser.e:2846		if CurrentSub != TopLevelSub then*/
    if (_36CurrentSub_21775 == _36TopLevelSub_21774)
    goto L1; // [14] 149

    /** parser.e:2847			symtab_pointer s = SymTab[CurrentSub][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _29789 = (object)*(((s1_ptr)_2)->base + _36CurrentSub_21775);
    _2 = (object)SEQ_PTR(_29789);
    _s_59635 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_59635)){
        _s_59635 = (object)DBL_PTR(_s_59635)->dbl;
    }
    _29789 = NOVALUE;

    /** parser.e:2848			sequence pu = { SC_PRIVATE, SC_UNDEFINED }*/
    DeRefi(_pu_59641);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 3;
    ((intptr_t *)_2)[2] = 9;
    _pu_59641 = MAKE_SEQ(_1);

    /** parser.e:2849			while s and find( SymTab[s][S_SCOPE], pu ) do*/
L2: 
    if (_s_59635 == 0) {
        goto L3; // [51] 148
    }
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _29793 = (object)*(((s1_ptr)_2)->base + _s_59635);
    _2 = (object)SEQ_PTR(_29793);
    _29794 = (object)*(((s1_ptr)_2)->base + 4);
    _29793 = NOVALUE;
    _29795 = find_from(_29794, _pu_59641, 1);
    _29794 = NOVALUE;
    if (_29795 == 0)
    {
        _29795 = NOVALUE;
        goto L3; // [73] 148
    }
    else{
        _29795 = NOVALUE;
    }

    /** parser.e:2850				if SymTab[s][S_SCOPE] = SC_PRIVATE and SymTab[s][S_INITLEVEL] = -1 then*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _29796 = (object)*(((s1_ptr)_2)->base + _s_59635);
    _2 = (object)SEQ_PTR(_29796);
    _29797 = (object)*(((s1_ptr)_2)->base + 4);
    _29796 = NOVALUE;
    if (IS_ATOM_INT(_29797)) {
        _29798 = (_29797 == 3);
    }
    else {
        _29798 = binary_op(EQUALS, _29797, 3);
    }
    _29797 = NOVALUE;
    if (IS_ATOM_INT(_29798)) {
        if (_29798 == 0) {
            goto L4; // [96] 127
        }
    }
    else {
        if (DBL_PTR(_29798)->dbl == 0.0) {
            goto L4; // [96] 127
        }
    }
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _29800 = (object)*(((s1_ptr)_2)->base + _s_59635);
    _2 = (object)SEQ_PTR(_29800);
    _29801 = (object)*(((s1_ptr)_2)->base + 14);
    _29800 = NOVALUE;
    if (IS_ATOM_INT(_29801)) {
        _29802 = (_29801 == -1);
    }
    else {
        _29802 = binary_op(EQUALS, _29801, -1);
    }
    _29801 = NOVALUE;
    if (_29802 == 0) {
        DeRef(_29802);
        _29802 = NOVALUE;
        goto L4; // [117] 127
    }
    else {
        if (!IS_ATOM_INT(_29802) && DBL_PTR(_29802)->dbl == 0.0){
            DeRef(_29802);
            _29802 = NOVALUE;
            goto L4; // [117] 127
        }
        DeRef(_29802);
        _29802 = NOVALUE;
    }
    DeRef(_29802);
    _29802 = NOVALUE;

    /** parser.e:2851					uninitialized &= s*/
    Append(&_uninitialized_59629, _uninitialized_59629, _s_59635);
L4: 

    /** parser.e:2853				s = SymTab[s][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _29804 = (object)*(((s1_ptr)_2)->base + _s_59635);
    _2 = (object)SEQ_PTR(_29804);
    _s_59635 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_59635)){
        _s_59635 = (object)DBL_PTR(_s_59635)->dbl;
    }
    _29804 = NOVALUE;

    /** parser.e:2854			end while*/
    goto L2; // [145] 51
L3: 
L1: 
    DeRefi(_pu_59641);
    _pu_59641 = NOVALUE;

    /** parser.e:2856		return uninitialized*/
    DeRef(_29798);
    _29798 = NOVALUE;
    return _uninitialized_59629;
    ;
}


void _45While_statement()
{
    object _bp1_59672 = NOVALUE;
    object _bp2_59673 = NOVALUE;
    object _exit_base_59674 = NOVALUE;
    object _next_base_59675 = NOVALUE;
    object _uninitialized_59676 = NOVALUE;
    object _temps_59746 = NOVALUE;
    object _29840 = NOVALUE;
    object _29839 = NOVALUE;
    object _29838 = NOVALUE;
    object _29834 = NOVALUE;
    object _29833 = NOVALUE;
    object _29831 = NOVALUE;
    object _29829 = NOVALUE;
    object _29828 = NOVALUE;
    object _29827 = NOVALUE;
    object _29823 = NOVALUE;
    object _29821 = NOVALUE;
    object _29819 = NOVALUE;
    object _29813 = NOVALUE;
    object _29811 = NOVALUE;
    object _29810 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:2865		sequence uninitialized = get_private_uninitialized()*/
    _0 = _uninitialized_59676;
    _uninitialized_59676 = _45get_private_uninitialized();
    DeRef(_0);

    /** parser.e:2867		entry_stack = append( entry_stack, uninitialized )*/
    RefDS(_uninitialized_59676);
    Append(&_45entry_stack_55383, _45entry_stack_55383, _uninitialized_59676);

    /** parser.e:2869		Start_block( WHILE )*/
    _65Start_block(47, 0);

    /** parser.e:2871		exit_base = length(exit_list)*/
    if (IS_SEQUENCE(_45exit_list_55376)){
            _exit_base_59674 = SEQ_PTR(_45exit_list_55376)->length;
    }
    else {
        _exit_base_59674 = 1;
    }

    /** parser.e:2872		next_base = length(continue_list)*/
    if (IS_SEQUENCE(_45continue_list_55378)){
            _next_base_59675 = SEQ_PTR(_45continue_list_55378)->length;
    }
    else {
        _next_base_59675 = 1;
    }

    /** parser.e:2873		entry_addr &= length(Code)+1*/
    if (IS_SEQUENCE(_36Code_21859)){
            _29810 = SEQ_PTR(_36Code_21859)->length;
    }
    else {
        _29810 = 1;
    }
    _29811 = _29810 + 1;
    _29810 = NOVALUE;
    Append(&_45entry_addr_55380, _45entry_addr_55380, _29811);
    _29811 = NOVALUE;

    /** parser.e:2874		emit_op(NOP2) -- Entry_statement may patch this later*/
    _47emit_op(110);

    /** parser.e:2875		emit_addr(0)*/
    _47emit_addr(0);

    /** parser.e:2876		if TRANSLATE then*/
    if (_36TRANSLATE_21369 == 0)
    {
        goto L1; // [71] 82
    }
    else{
    }

    /** parser.e:2877			emit_op(NOPWHILE)*/
    _47emit_op(158);
L1: 

    /** parser.e:2879		bp1 = length(Code)+1*/
    if (IS_SEQUENCE(_36Code_21859)){
            _29813 = SEQ_PTR(_36Code_21859)->length;
    }
    else {
        _29813 = 1;
    }
    _bp1_59672 = _29813 + 1;
    _29813 = NOVALUE;

    /** parser.e:2880		continue_addr &= bp1*/
    Append(&_45continue_addr_55381, _45continue_addr_55381, _bp1_59672);

    /** parser.e:2881		short_circuit += 1*/
    _45short_circuit_55356 = _45short_circuit_55356 + 1;

    /** parser.e:2882		short_circuit_B = FALSE*/
    _45short_circuit_B_55358 = _13FALSE_445;

    /** parser.e:2883		SC1_type = 0*/
    _45SC1_type_55361 = 0;

    /** parser.e:2884		Expr()*/
    _45Expr();

    /** parser.e:2885		optimized_while = FALSE*/
    _47optimized_while_51366 = _13FALSE_445;

    /** parser.e:2886		emit_op(WHILE)*/
    _47emit_op(47);

    /** parser.e:2887		short_circuit -= 1*/
    _45short_circuit_55356 = _45short_circuit_55356 - 1;

    /** parser.e:2888		if not optimized_while then*/
    if (_47optimized_while_51366 != 0)
    goto L2; // [153] 174

    /** parser.e:2890			bp2 = length(Code)+1*/
    if (IS_SEQUENCE(_36Code_21859)){
            _29819 = SEQ_PTR(_36Code_21859)->length;
    }
    else {
        _29819 = 1;
    }
    _bp2_59673 = _29819 + 1;
    _29819 = NOVALUE;

    /** parser.e:2891			emit_forward_addr() -- will be patched*/
    _45emit_forward_addr();
    goto L3; // [171] 180
L2: 

    /** parser.e:2893			bp2 = 0*/
    _bp2_59673 = 0;
L3: 

    /** parser.e:2895		if finish_block_header(WHILE)=0 then*/
    _29821 = _45finish_block_header(47);
    if (binary_op_a(NOTEQ, _29821, 0)){
        DeRef(_29821);
        _29821 = NOVALUE;
        goto L4; // [188] 204
    }
    DeRef(_29821);
    _29821 = NOVALUE;

    /** parser.e:2896			entry_addr[$]=-1*/
    if (IS_SEQUENCE(_45entry_addr_55380)){
            _29823 = SEQ_PTR(_45entry_addr_55380)->length;
    }
    else {
        _29823 = 1;
    }
    _2 = (object)SEQ_PTR(_45entry_addr_55380);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _45entry_addr_55380 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _29823);
    *(intptr_t *)_2 = -1;
L4: 

    /** parser.e:2899		loop_stack &= WHILE*/
    Append(&_45loop_stack_55390, _45loop_stack_55390, 47);

    /** parser.e:2901		exit_base = length(exit_list)*/
    if (IS_SEQUENCE(_45exit_list_55376)){
            _exit_base_59674 = SEQ_PTR(_45exit_list_55376)->length;
    }
    else {
        _exit_base_59674 = 1;
    }

    /** parser.e:2902		if SC1_type = OR then*/
    if (_45SC1_type_55361 != 9)
    goto L5; // [227] 280

    /** parser.e:2903			backpatch(SC1_patch-3, SC1_OR_IF)*/
    _29827 = _45SC1_patch_55360 - 3;
    if ((object)((uintptr_t)_29827 +(uintptr_t) HIGH_BITS) >= 0){
        _29827 = NewDouble((eudouble)_29827);
    }
    _47backpatch(_29827, 147);
    _29827 = NOVALUE;

    /** parser.e:2904			if TRANSLATE then*/
    if (_36TRANSLATE_21369 == 0)
    {
        goto L6; // [249] 260
    }
    else{
    }

    /** parser.e:2905				emit_op(NOP1)*/
    _47emit_op(159);
L6: 

    /** parser.e:2907			backpatch(SC1_patch, length(Code)+1)*/
    if (IS_SEQUENCE(_36Code_21859)){
            _29828 = SEQ_PTR(_36Code_21859)->length;
    }
    else {
        _29828 = 1;
    }
    _29829 = _29828 + 1;
    _29828 = NOVALUE;
    _47backpatch(_45SC1_patch_55360, _29829);
    _29829 = NOVALUE;
    goto L7; // [277] 331
L5: 

    /** parser.e:2908		elsif SC1_type = AND then*/
    if (_45SC1_type_55361 != 8)
    goto L8; // [286] 330

    /** parser.e:2909			backpatch(SC1_patch-3, SC1_AND_IF)*/
    _29831 = _45SC1_patch_55360 - 3;
    if ((object)((uintptr_t)_29831 +(uintptr_t) HIGH_BITS) >= 0){
        _29831 = NewDouble((eudouble)_29831);
    }
    _47backpatch(_29831, 146);
    _29831 = NOVALUE;

    /** parser.e:2910			AppendXList(SC1_patch)*/

    /** parser.e:398		exit_list = append(exit_list, addr)*/
    Append(&_45exit_list_55376, _45exit_list_55376, _45SC1_patch_55360);

    /** parser.e:399	end procedure*/
    goto L9; // [318] 321
L9: 

    /** parser.e:2911			exit_delay &= 1*/
    Append(&_45exit_delay_55377, _45exit_delay_55377, 1);
L8: 
L7: 

    /** parser.e:2913		retry_addr &= length(Code)+1*/
    if (IS_SEQUENCE(_36Code_21859)){
            _29833 = SEQ_PTR(_36Code_21859)->length;
    }
    else {
        _29833 = 1;
    }
    _29834 = _29833 + 1;
    _29833 = NOVALUE;
    Append(&_45retry_addr_55382, _45retry_addr_55382, _29834);
    _29834 = NOVALUE;

    /** parser.e:2915		sequence temps = pop_temps()*/
    _0 = _temps_59746;
    _temps_59746 = _47pop_temps();
    DeRef(_0);

    /** parser.e:2917		push_temps( temps )*/
    RefDS(_temps_59746);
    _47push_temps(_temps_59746);

    /** parser.e:2919		Statement_list()*/
    _45Statement_list();

    /** parser.e:2920		PatchNList(next_base)*/
    _45PatchNList(_next_base_59675);

    /** parser.e:2921		tok_match(END)*/
    _45tok_match(402, 0);

    /** parser.e:2922		tok_match(WHILE, END)*/
    _45tok_match(47, 402);

    /** parser.e:2924		End_block( WHILE )*/
    _65End_block(47);

    /** parser.e:2926		StartSourceLine(TRUE)*/
    _47StartSourceLine(_13TRUE_447, 0, 2);

    /** parser.e:2927		emit_op(ENDWHILE)*/
    _47emit_op(22);

    /** parser.e:2928		emit_addr(bp1)*/
    _47emit_addr(_bp1_59672);

    /** parser.e:2929		if TRANSLATE then*/
    if (_36TRANSLATE_21369 == 0)
    {
        goto LA; // [419] 430
    }
    else{
    }

    /** parser.e:2930			emit_op(NOP1)*/
    _47emit_op(159);
LA: 

    /** parser.e:2932		if bp2 != 0 then*/
    if (_bp2_59673 == 0)
    goto LB; // [434] 454

    /** parser.e:2933			backpatch(bp2, length(Code)+1)*/
    if (IS_SEQUENCE(_36Code_21859)){
            _29838 = SEQ_PTR(_36Code_21859)->length;
    }
    else {
        _29838 = 1;
    }
    _29839 = _29838 + 1;
    _29838 = NOVALUE;
    _47backpatch(_bp2_59673, _29839);
    _29839 = NOVALUE;
LB: 

    /** parser.e:2935		exit_loop(exit_base)*/
    _45exit_loop(_exit_base_59674);

    /** parser.e:2936		entry_stack = remove( entry_stack, length( entry_stack ) )*/
    if (IS_SEQUENCE(_45entry_stack_55383)){
            _29840 = SEQ_PTR(_45entry_stack_55383)->length;
    }
    else {
        _29840 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_45entry_stack_55383);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_29840)) ? _29840 : (object)(DBL_PTR(_29840)->dbl);
        int stop = (IS_ATOM_INT(_29840)) ? _29840 : (object)(DBL_PTR(_29840)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_45entry_stack_55383), start, &_45entry_stack_55383 );
            }
            else Tail(SEQ_PTR(_45entry_stack_55383), stop+1, &_45entry_stack_55383);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_45entry_stack_55383), start, &_45entry_stack_55383);
        }
        else {
            assign_slice_seq = &assign_space;
            _45entry_stack_55383 = Remove_elements(start, stop, (SEQ_PTR(_45entry_stack_55383)->ref == 1));
        }
    }
    _29840 = NOVALUE;
    _29840 = NOVALUE;

    /** parser.e:2937		push_temps( temps )*/
    RefDS(_temps_59746);
    _47push_temps(_temps_59746);

    /** parser.e:2938	end procedure*/
    DeRef(_uninitialized_59676);
    DeRefDS(_temps_59746);
    return;
    ;
}


void _45Loop_statement()
{
    object _bp1_59776 = NOVALUE;
    object _exit_base_59777 = NOVALUE;
    object _next_base_59778 = NOVALUE;
    object _t_59780 = NOVALUE;
    object _uninitialized_59783 = NOVALUE;
    object _29864 = NOVALUE;
    object _29862 = NOVALUE;
    object _29861 = NOVALUE;
    object _29860 = NOVALUE;
    object _29854 = NOVALUE;
    object _29853 = NOVALUE;
    object _29851 = NOVALUE;
    object _29848 = NOVALUE;
    object _29847 = NOVALUE;
    object _29846 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:2946		Start_block( LOOP )*/
    _65Start_block(422, 0);

    /** parser.e:2948		sequence uninitialized = get_private_uninitialized()*/
    _0 = _uninitialized_59783;
    _uninitialized_59783 = _45get_private_uninitialized();
    DeRef(_0);

    /** parser.e:2949		entry_stack = append( entry_stack, uninitialized )*/
    RefDS(_uninitialized_59783);
    Append(&_45entry_stack_55383, _45entry_stack_55383, _uninitialized_59783);

    /** parser.e:2951		exit_base = length(exit_list)*/
    if (IS_SEQUENCE(_45exit_list_55376)){
            _exit_base_59777 = SEQ_PTR(_45exit_list_55376)->length;
    }
    else {
        _exit_base_59777 = 1;
    }

    /** parser.e:2952		next_base = length(continue_list)*/
    if (IS_SEQUENCE(_45continue_list_55378)){
            _next_base_59778 = SEQ_PTR(_45continue_list_55378)->length;
    }
    else {
        _next_base_59778 = 1;
    }

    /** parser.e:2953		emit_op(NOP2) -- Entry_statement() may patch this*/
    _47emit_op(110);

    /** parser.e:2954		emit_addr(0)*/
    _47emit_addr(0);

    /** parser.e:2955		if finish_block_header(LOOP) then*/
    _29846 = _45finish_block_header(422);
    if (_29846 == 0) {
        DeRef(_29846);
        _29846 = NOVALUE;
        goto L1; // [58] 81
    }
    else {
        if (!IS_ATOM_INT(_29846) && DBL_PTR(_29846)->dbl == 0.0){
            DeRef(_29846);
            _29846 = NOVALUE;
            goto L1; // [58] 81
        }
        DeRef(_29846);
        _29846 = NOVALUE;
    }
    DeRef(_29846);
    _29846 = NOVALUE;

    /** parser.e:2956		    entry_addr &= length(Code)-1*/
    if (IS_SEQUENCE(_36Code_21859)){
            _29847 = SEQ_PTR(_36Code_21859)->length;
    }
    else {
        _29847 = 1;
    }
    _29848 = _29847 - 1;
    _29847 = NOVALUE;
    Append(&_45entry_addr_55380, _45entry_addr_55380, _29848);
    _29848 = NOVALUE;
    goto L2; // [78] 90
L1: 

    /** parser.e:2958			entry_addr &= -1*/
    Append(&_45entry_addr_55380, _45entry_addr_55380, -1);
L2: 

    /** parser.e:2962		if TRANSLATE then*/
    if (_36TRANSLATE_21369 == 0)
    {
        goto L3; // [94] 105
    }
    else{
    }

    /** parser.e:2963			emit_op(NOP1)*/
    _47emit_op(159);
L3: 

    /** parser.e:2965		bp1 = length(Code)+1*/
    if (IS_SEQUENCE(_36Code_21859)){
            _29851 = SEQ_PTR(_36Code_21859)->length;
    }
    else {
        _29851 = 1;
    }
    _bp1_59776 = _29851 + 1;
    _29851 = NOVALUE;

    /** parser.e:2966		retry_addr &= length(Code)+1*/
    if (IS_SEQUENCE(_36Code_21859)){
            _29853 = SEQ_PTR(_36Code_21859)->length;
    }
    else {
        _29853 = 1;
    }
    _29854 = _29853 + 1;
    _29853 = NOVALUE;
    Append(&_45retry_addr_55382, _45retry_addr_55382, _29854);
    _29854 = NOVALUE;

    /** parser.e:2967		continue_addr &= 0*/
    Append(&_45continue_addr_55381, _45continue_addr_55381, 0);

    /** parser.e:2968		loop_stack &= LOOP*/
    Append(&_45loop_stack_55390, _45loop_stack_55390, 422);

    /** parser.e:2970		Statement_list()*/
    _45Statement_list();

    /** parser.e:2972		End_block( LOOP )*/
    _65End_block(422);

    /** parser.e:2974		tok_match(UNTIL)*/
    _45tok_match(423, 0);

    /** parser.e:2975		if TRANSLATE then*/
    if (_36TRANSLATE_21369 == 0)
    {
        goto L4; // [174] 185
    }
    else{
    }

    /** parser.e:2976			emit_op(NOP1)*/
    _47emit_op(159);
L4: 

    /** parser.e:2978		PatchNList(next_base)*/
    _45PatchNList(_next_base_59778);

    /** parser.e:2979		StartSourceLine(TRUE)*/
    _47StartSourceLine(_13TRUE_447, 0, 2);

    /** parser.e:2980		short_circuit += 1*/
    _45short_circuit_55356 = _45short_circuit_55356 + 1;

    /** parser.e:2981		short_circuit_B = FALSE*/
    _45short_circuit_B_55358 = _13FALSE_445;

    /** parser.e:2982		SC1_type = 0*/
    _45SC1_type_55361 = 0;

    /** parser.e:2983		Expr()*/
    _45Expr();

    /** parser.e:2984		if SC1_type = OR then*/
    if (_45SC1_type_55361 != 9)
    goto L5; // [229] 282

    /** parser.e:2985			backpatch(SC1_patch-3, SC1_OR_IF)*/
    _29860 = _45SC1_patch_55360 - 3;
    if ((object)((uintptr_t)_29860 +(uintptr_t) HIGH_BITS) >= 0){
        _29860 = NewDouble((eudouble)_29860);
    }
    _47backpatch(_29860, 147);
    _29860 = NOVALUE;

    /** parser.e:2986			if TRANSLATE then*/
    if (_36TRANSLATE_21369 == 0)
    {
        goto L6; // [251] 262
    }
    else{
    }

    /** parser.e:2987			    emit_op(NOP1)  -- to get label here*/
    _47emit_op(159);
L6: 

    /** parser.e:2989			backpatch(SC1_patch, length(Code)+1)*/
    if (IS_SEQUENCE(_36Code_21859)){
            _29861 = SEQ_PTR(_36Code_21859)->length;
    }
    else {
        _29861 = 1;
    }
    _29862 = _29861 + 1;
    _29861 = NOVALUE;
    _47backpatch(_45SC1_patch_55360, _29862);
    _29862 = NOVALUE;
    goto L7; // [279] 308
L5: 

    /** parser.e:2990		elsif SC1_type = AND then*/
    if (_45SC1_type_55361 != 8)
    goto L8; // [288] 307

    /** parser.e:2991			backpatch(SC1_patch-3, SC1_AND_IF)*/
    _29864 = _45SC1_patch_55360 - 3;
    if ((object)((uintptr_t)_29864 +(uintptr_t) HIGH_BITS) >= 0){
        _29864 = NewDouble((eudouble)_29864);
    }
    _47backpatch(_29864, 146);
    _29864 = NOVALUE;
L8: 
L7: 

    /** parser.e:2993		short_circuit -= 1*/
    _45short_circuit_55356 = _45short_circuit_55356 - 1;

    /** parser.e:2994		emit_op(IF)*/
    _47emit_op(20);

    /** parser.e:2995		emit_addr(bp1)*/
    _47emit_addr(_bp1_59776);

    /** parser.e:2996		if TRANSLATE then*/
    if (_36TRANSLATE_21369 == 0)
    {
        goto L9; // [332] 343
    }
    else{
    }

    /** parser.e:2997			emit_op(NOP1)*/
    _47emit_op(159);
L9: 

    /** parser.e:2999		exit_loop(exit_base)*/
    _45exit_loop(_exit_base_59777);

    /** parser.e:3001		tok_match(END)*/
    _45tok_match(402, 0);

    /** parser.e:3002		tok_match(LOOP, END)*/
    _45tok_match(422, 402);

    /** parser.e:3004	end procedure*/
    DeRef(_uninitialized_59783);
    return;
    ;
}


void _45Ifdef_statement()
{
    object _option_59862 = NOVALUE;
    object _matched_59863 = NOVALUE;
    object _has_matched_59864 = NOVALUE;
    object _in_matched_59865 = NOVALUE;
    object _dead_ifdef_59866 = NOVALUE;
    object _in_elsedef_59867 = NOVALUE;
    object _tok_59869 = NOVALUE;
    object _keyw_59870 = NOVALUE;
    object _parser_id_59874 = NOVALUE;
    object _negate_59890 = NOVALUE;
    object _conjunction_59891 = NOVALUE;
    object _at_start_59892 = NOVALUE;
    object _prev_conj_59893 = NOVALUE;
    object _this_matched_59978 = NOVALUE;
    object _gotword_59994 = NOVALUE;
    object _gotthen_59995 = NOVALUE;
    object _if_lvl_59996 = NOVALUE;
    object _29981 = NOVALUE;
    object _29980 = NOVALUE;
    object _29976 = NOVALUE;
    object _29974 = NOVALUE;
    object _29971 = NOVALUE;
    object _29969 = NOVALUE;
    object _29968 = NOVALUE;
    object _29964 = NOVALUE;
    object _29961 = NOVALUE;
    object _29958 = NOVALUE;
    object _29954 = NOVALUE;
    object _29952 = NOVALUE;
    object _29951 = NOVALUE;
    object _29950 = NOVALUE;
    object _29949 = NOVALUE;
    object _29948 = NOVALUE;
    object _29947 = NOVALUE;
    object _29946 = NOVALUE;
    object _29942 = NOVALUE;
    object _29939 = NOVALUE;
    object _29938 = NOVALUE;
    object _29937 = NOVALUE;
    object _29933 = NOVALUE;
    object _29932 = NOVALUE;
    object _29931 = NOVALUE;
    object _29928 = NOVALUE;
    object _29925 = NOVALUE;
    object _29924 = NOVALUE;
    object _29923 = NOVALUE;
    object _29921 = NOVALUE;
    object _29910 = NOVALUE;
    object _29908 = NOVALUE;
    object _29907 = NOVALUE;
    object _29906 = NOVALUE;
    object _29905 = NOVALUE;
    object _29904 = NOVALUE;
    object _29903 = NOVALUE;
    object _29902 = NOVALUE;
    object _29899 = NOVALUE;
    object _29898 = NOVALUE;
    object _29896 = NOVALUE;
    object _29894 = NOVALUE;
    object _29893 = NOVALUE;
    object _29891 = NOVALUE;
    object _29889 = NOVALUE;
    object _29888 = NOVALUE;
    object _29886 = NOVALUE;
    object _29885 = NOVALUE;
    object _29884 = NOVALUE;
    object _29881 = NOVALUE;
    object _29879 = NOVALUE;
    object _29876 = NOVALUE;
    object _29875 = NOVALUE;
    object _29874 = NOVALUE;
    object _29872 = NOVALUE;
    object _29870 = NOVALUE;
    object _29869 = NOVALUE;
    object _29868 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:3012		integer matched = 0, has_matched = 0,  in_matched = 0, dead_ifdef = 0, in_elsedef = 0*/
    _matched_59863 = 0;
    _has_matched_59864 = 0;
    _in_matched_59865 = 0;
    _dead_ifdef_59866 = 0;
    _in_elsedef_59867 = 0;

    /** parser.e:3014		sequence keyw ="ifdef"*/
    RefDS(_26479);
    DeRefi(_keyw_59870);
    _keyw_59870 = _26479;

    /** parser.e:3016		live_ifdef += 1*/
    _45live_ifdef_59858 = _45live_ifdef_59858 + 1;

    /** parser.e:3017		ifdef_lineno &= line_number*/
    Append(&_45ifdef_lineno_59859, _45ifdef_lineno_59859, _36line_number_21768);

    /** parser.e:3019		integer parser_id*/

    /** parser.e:3020		if CurrentSub != TopLevelSub or length(if_labels) or length(loop_labels) then*/
    _29868 = (_36CurrentSub_21775 != _36TopLevelSub_21774);
    if (_29868 != 0) {
        _29869 = 1;
        goto L1; // [55] 68
    }
    if (IS_SEQUENCE(_45if_labels_55385)){
            _29870 = SEQ_PTR(_45if_labels_55385)->length;
    }
    else {
        _29870 = 1;
    }
    _29869 = (_29870 != 0);
L1: 
    if (_29869 != 0) {
        goto L2; // [68] 82
    }
    if (IS_SEQUENCE(_45loop_labels_55384)){
            _29872 = SEQ_PTR(_45loop_labels_55384)->length;
    }
    else {
        _29872 = 1;
    }
    if (_29872 == 0)
    {
        _29872 = NOVALUE;
        goto L3; // [78] 92
    }
    else{
        _29872 = NOVALUE;
    }
L2: 

    /** parser.e:3021			parser_id = forward_Statement_list*/
    _parser_id_59874 = _45forward_Statement_list_58600;
    goto L4; // [89] 100
L3: 

    /** parser.e:3023			parser_id = top_level_parser*/
    _parser_id_59874 = _45top_level_parser_59857;
L4: 

    /** parser.e:3026		while 1 label "top" do*/
L5: 

    /** parser.e:3027			if matched = 0 and in_elsedef = 0 then*/
    _29874 = (_matched_59863 == 0);
    if (_29874 == 0) {
        goto L6; // [111] 656
    }
    _29876 = (_in_elsedef_59867 == 0);
    if (_29876 == 0)
    {
        DeRef(_29876);
        _29876 = NOVALUE;
        goto L6; // [120] 656
    }
    else{
        DeRef(_29876);
        _29876 = NOVALUE;
    }

    /** parser.e:3028				integer negate = 0, conjunction = 0*/
    _negate_59890 = 0;
    _conjunction_59891 = 0;

    /** parser.e:3029				integer at_start = 1*/
    _at_start_59892 = 1;

    /** parser.e:3030				sequence prev_conj = ""*/
    RefDS(_22190);
    DeRef(_prev_conj_59893);
    _prev_conj_59893 = _22190;

    /** parser.e:3032				while 1 label "deflist" do*/
L7: 

    /** parser.e:3033					option = StringToken()*/
    RefDS(_5);
    _0 = _option_59862;
    _option_59862 = _62StringToken(_5);
    DeRef(_0);

    /** parser.e:3034					if equal(option, "then") then*/
    if (_option_59862 == _26546)
    _29879 = 1;
    else if (IS_ATOM_INT(_option_59862) && IS_ATOM_INT(_26546))
    _29879 = 0;
    else
    _29879 = (compare(_option_59862, _26546) == 0);
    if (_29879 == 0)
    {
        _29879 = NOVALUE;
        goto L8; // [162] 240
    }
    else{
        _29879 = NOVALUE;
    }

    /** parser.e:3035						if at_start = 1 then*/
    if (_at_start_59892 != 1)
    goto L9; // [167] 187

    /** parser.e:3036							CompileErr(MSG_1_IS_MISSING_DEFINED_WORD_BEFORE_THEN, {keyw})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_keyw_59870);
    ((intptr_t*)_2)[1] = _keyw_59870;
    _29881 = MAKE_SEQ(_1);
    _50CompileErr(6, _29881, 0);
    _29881 = NOVALUE;
    goto LA; // [184] 542
L9: 

    /** parser.e:3037						elsif conjunction = 0 then*/
    if (_conjunction_59891 != 0)
    goto LB; // [189] 223

    /** parser.e:3038							if negate = 0 then*/
    if (_negate_59890 != 0)
    goto LC; // [195] 206

    /** parser.e:3039								exit "deflist"*/
    goto LD; // [201] 630
    goto LA; // [203] 542
LC: 

    /** parser.e:3041								CompileErr(MSG_1_THEN_FOLLOWS_NOT, {keyw})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_keyw_59870);
    ((intptr_t*)_2)[1] = _keyw_59870;
    _29884 = MAKE_SEQ(_1);
    _50CompileErr(11, _29884, 0);
    _29884 = NOVALUE;
    goto LA; // [220] 542
LB: 

    /** parser.e:3044							CompileErr(MSG_1_THEN_FOLLOWS_2, {keyw, prev_conj})*/
    RefDS(_prev_conj_59893);
    RefDS(_keyw_59870);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _keyw_59870;
    ((intptr_t *)_2)[2] = _prev_conj_59893;
    _29885 = MAKE_SEQ(_1);
    _50CompileErr(8, _29885, 0);
    _29885 = NOVALUE;
    goto LA; // [237] 542
L8: 

    /** parser.e:3046					elsif equal(option, "not") then*/
    if (_option_59862 == _26507)
    _29886 = 1;
    else if (IS_ATOM_INT(_option_59862) && IS_ATOM_INT(_26507))
    _29886 = 0;
    else
    _29886 = (compare(_option_59862, _26507) == 0);
    if (_29886 == 0)
    {
        _29886 = NOVALUE;
        goto LE; // [246] 284
    }
    else{
        _29886 = NOVALUE;
    }

    /** parser.e:3047						if negate = 0 then*/
    if (_negate_59890 != 0)
    goto LF; // [251] 267

    /** parser.e:3048							negate = 1*/
    _negate_59890 = 1;

    /** parser.e:3049							continue "deflist"*/
    goto L7; // [262] 148
    goto LA; // [264] 542
LF: 

    /** parser.e:3051							CompileErr(MSG_1_DUPLICATE_NOT, {keyw})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_keyw_59870);
    ((intptr_t*)_2)[1] = _keyw_59870;
    _29888 = MAKE_SEQ(_1);
    _50CompileErr(7, _29888, 0);
    _29888 = NOVALUE;
    goto LA; // [281] 542
LE: 

    /** parser.e:3053					elsif equal(option, "and") then*/
    if (_option_59862 == _26411)
    _29889 = 1;
    else if (IS_ATOM_INT(_option_59862) && IS_ATOM_INT(_26411))
    _29889 = 0;
    else
    _29889 = (compare(_option_59862, _26411) == 0);
    if (_29889 == 0)
    {
        _29889 = NOVALUE;
        goto L10; // [290] 357
    }
    else{
        _29889 = NOVALUE;
    }

    /** parser.e:3054						if at_start = 1 then*/
    if (_at_start_59892 != 1)
    goto L11; // [295] 315

    /** parser.e:3055							CompileErr(MSG_1_IS_MISSING_DEFINED_WORD_BEFORE_AND, {keyw})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_keyw_59870);
    ((intptr_t*)_2)[1] = _keyw_59870;
    _29891 = MAKE_SEQ(_1);
    _50CompileErr(2, _29891, 0);
    _29891 = NOVALUE;
    goto LA; // [312] 542
L11: 

    /** parser.e:3056						elsif conjunction = 0 then*/
    if (_conjunction_59891 != 0)
    goto L12; // [317] 340

    /** parser.e:3057							conjunction = 1*/
    _conjunction_59891 = 1;

    /** parser.e:3058							prev_conj = option*/
    RefDS(_option_59862);
    DeRef(_prev_conj_59893);
    _prev_conj_59893 = _option_59862;

    /** parser.e:3059							continue "deflist"*/
    goto L7; // [335] 148
    goto LA; // [337] 542
L12: 

    /** parser.e:3061							CompileErr(MSG_1_AND_FOLLOWS_2,{keyw,prev_conj})*/
    RefDS(_prev_conj_59893);
    RefDS(_keyw_59870);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _keyw_59870;
    ((intptr_t *)_2)[2] = _prev_conj_59893;
    _29893 = MAKE_SEQ(_1);
    _50CompileErr(10, _29893, 0);
    _29893 = NOVALUE;
    goto LA; // [354] 542
L10: 

    /** parser.e:3063					elsif equal(option, "or") then*/
    if (_option_59862 == _26511)
    _29894 = 1;
    else if (IS_ATOM_INT(_option_59862) && IS_ATOM_INT(_26511))
    _29894 = 0;
    else
    _29894 = (compare(_option_59862, _26511) == 0);
    if (_29894 == 0)
    {
        _29894 = NOVALUE;
        goto L13; // [363] 430
    }
    else{
        _29894 = NOVALUE;
    }

    /** parser.e:3064						if at_start = 1 then*/
    if (_at_start_59892 != 1)
    goto L14; // [368] 388

    /** parser.e:3065							CompileErr(MSG_1_IS_MISSING_DEFINED_WORD_BEFORE_THEN, {keyw})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_keyw_59870);
    ((intptr_t*)_2)[1] = _keyw_59870;
    _29896 = MAKE_SEQ(_1);
    _50CompileErr(6, _29896, 0);
    _29896 = NOVALUE;
    goto LA; // [385] 542
L14: 

    /** parser.e:3066						elsif conjunction = 0 then*/
    if (_conjunction_59891 != 0)
    goto L15; // [390] 413

    /** parser.e:3067							conjunction = 2*/
    _conjunction_59891 = 2;

    /** parser.e:3068							prev_conj = option*/
    RefDS(_option_59862);
    DeRef(_prev_conj_59893);
    _prev_conj_59893 = _option_59862;

    /** parser.e:3069							continue "deflist"*/
    goto L7; // [408] 148
    goto LA; // [410] 542
L15: 

    /** parser.e:3071							CompileErr(MSG_1_OR_FOLLOWS_2, {keyw, prev_conj})*/
    RefDS(_prev_conj_59893);
    RefDS(_keyw_59870);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _keyw_59870;
    ((intptr_t *)_2)[2] = _prev_conj_59893;
    _29898 = MAKE_SEQ(_1);
    _50CompileErr(9, _29898, 0);
    _29898 = NOVALUE;
    goto LA; // [427] 542
L13: 

    /** parser.e:3073					elsif length(option) = 0 then*/
    if (IS_SEQUENCE(_option_59862)){
            _29899 = SEQ_PTR(_option_59862)->length;
    }
    else {
        _29899 = 1;
    }
    if (_29899 != 0)
    goto L16; // [435] 474

    /** parser.e:3074						if at_start = 1 then*/
    if (_at_start_59892 != 1)
    goto L17; // [441] 461

    /** parser.e:3075							CompileErr(NO_WORD_WAS_FOUND_FOLLOWING_1, {keyw})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_keyw_59870);
    ((intptr_t*)_2)[1] = _keyw_59870;
    _29902 = MAKE_SEQ(_1);
    _50CompileErr(122, _29902, 0);
    _29902 = NOVALUE;
    goto LA; // [458] 542
L17: 

    /** parser.e:3077							CompileErr(EXPECTING_POSSIBLY_THEN_NOT_END_OF_LINE)*/
    RefDS(_22190);
    _50CompileErr(82, _22190, 0);
    goto LA; // [471] 542
L16: 

    /** parser.e:3079					elsif not at_start and length(prev_conj) = 0 then*/
    _29903 = (_at_start_59892 == 0);
    if (_29903 == 0) {
        goto L18; // [479] 510
    }
    if (IS_SEQUENCE(_prev_conj_59893)){
            _29905 = SEQ_PTR(_prev_conj_59893)->length;
    }
    else {
        _29905 = 1;
    }
    _29906 = (_29905 == 0);
    _29905 = NOVALUE;
    if (_29906 == 0)
    {
        DeRef(_29906);
        _29906 = NOVALUE;
        goto L18; // [491] 510
    }
    else{
        DeRef(_29906);
        _29906 = NOVALUE;
    }

    /** parser.e:3080						CompileErr(MSG_1_NOT_UNDERSTOOD, {keyw})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_keyw_59870);
    ((intptr_t*)_2)[1] = _keyw_59870;
    _29907 = MAKE_SEQ(_1);
    _50CompileErr(4, _29907, 0);
    _29907 = NOVALUE;
    goto LA; // [507] 542
L18: 

    /** parser.e:3081					elsif t_identifier(option) = 0 then*/
    RefDS(_option_59862);
    _29908 = _13t_identifier(_option_59862);
    if (binary_op_a(NOTEQ, _29908, 0)){
        DeRef(_29908);
        _29908 = NOVALUE;
        goto L19; // [516] 536
    }
    DeRef(_29908);
    _29908 = NOVALUE;

    /** parser.e:3082						CompileErr(MSG_1_WORD_MUST_BE_AN_IDENTIFIER, {keyw})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_keyw_59870);
    ((intptr_t*)_2)[1] = _keyw_59870;
    _29910 = MAKE_SEQ(_1);
    _50CompileErr(3, _29910, 0);
    _29910 = NOVALUE;
    goto LA; // [533] 542
L19: 

    /** parser.e:3084						at_start = 0*/
    _at_start_59892 = 0;
LA: 

    /** parser.e:3087					integer this_matched = find(option, OpDefines)*/
    _this_matched_59978 = find_from(_option_59862, _36OpDefines_21844, 1);

    /** parser.e:3088					if negate then*/
    if (_negate_59890 == 0)
    {
        goto L1A; // [553] 567
    }
    else{
    }

    /** parser.e:3089						this_matched = not this_matched*/
    _this_matched_59978 = (_this_matched_59978 == 0);

    /** parser.e:3090						negate = 0*/
    _negate_59890 = 0;
L1A: 

    /** parser.e:3093					if conjunction = 0 then*/
    if (_conjunction_59891 != 0)
    goto L1B; // [569] 581

    /** parser.e:3094						matched = this_matched*/
    _matched_59863 = _this_matched_59978;
    goto L1C; // [578] 623
L1B: 

    /** parser.e:3096						if conjunction = 1 then*/
    if (_conjunction_59891 != 1)
    goto L1D; // [583] 596

    /** parser.e:3097							matched = matched and this_matched*/
    _matched_59863 = (_matched_59863 != 0 && _this_matched_59978 != 0);
    goto L1E; // [593] 610
L1D: 

    /** parser.e:3098						elsif conjunction = 2 then*/
    if (_conjunction_59891 != 2)
    goto L1F; // [598] 609

    /** parser.e:3099							matched = matched or this_matched*/
    _matched_59863 = (_matched_59863 != 0 || _this_matched_59978 != 0);
L1F: 
L1E: 

    /** parser.e:3101						conjunction = 0*/
    _conjunction_59891 = 0;

    /** parser.e:3102						prev_conj = ""*/
    RefDS(_22190);
    DeRef(_prev_conj_59893);
    _prev_conj_59893 = _22190;
L1C: 

    /** parser.e:3104				end while*/
    goto L7; // [627] 148
LD: 

    /** parser.e:3106				in_matched = matched*/
    _in_matched_59865 = _matched_59863;

    /** parser.e:3107				if matched then*/
    if (_matched_59863 == 0)
    {
        goto L20; // [637] 655
    }
    else{
    }

    /** parser.e:3108					No_new_entry = 0*/
    _54No_new_entry_48334 = 0;

    /** parser.e:3109					call_proc(parser_id, {})*/
    _0 = (object)_00[_parser_id_59874].addr;
    (*(intptr_t (*)())_0)(
                         );
L20: 
L6: 
    DeRef(_prev_conj_59893);
    _prev_conj_59893 = NOVALUE;

    /** parser.e:3115			integer gotword = 0*/
    _gotword_59994 = 0;

    /** parser.e:3116			integer gotthen = 0*/
    _gotthen_59995 = 0;

    /** parser.e:3117			integer if_lvl  = 0*/
    _if_lvl_59996 = 0;

    /** parser.e:3118			No_new_entry = not matched*/
    _54No_new_entry_48334 = (_matched_59863 == 0);

    /** parser.e:3119			has_matched = has_matched or matched*/
    _has_matched_59864 = (_has_matched_59864 != 0 || _matched_59863 != 0);

    /** parser.e:3120			keyw = "elsifdef"*/
    RefDS(_26447);
    DeRefi(_keyw_59870);
    _keyw_59870 = _26447;

    /** parser.e:3121			while 1 do*/
L21: 

    /** parser.e:3122				tok = next_token()*/
    _0 = _tok_59869;
    _tok_59869 = _45next_token();
    DeRef(_0);

    /** parser.e:3123				if tok[T_ID] = END_OF_FILE then*/
    _2 = (object)SEQ_PTR(_tok_59869);
    _29921 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29921, -21)){
        _29921 = NOVALUE;
        goto L22; // [713] 738
    }
    _29921 = NOVALUE;

    /** parser.e:3124					CompileErr(END_OF_FILE_REACHED_WHILE_SEARCHING_FOR_END_IFDEF_TO_MATCH_IFDEF_ON_LINE_1, ifdef_lineno[$])*/
    if (IS_SEQUENCE(_45ifdef_lineno_59859)){
            _29923 = SEQ_PTR(_45ifdef_lineno_59859)->length;
    }
    else {
        _29923 = 1;
    }
    _2 = (object)SEQ_PTR(_45ifdef_lineno_59859);
    _29924 = (object)*(((s1_ptr)_2)->base + _29923);
    _50CompileErr(65, _29924, 0);
    _29924 = NOVALUE;
    goto L21; // [735] 698
L22: 

    /** parser.e:3125				elsif tok[T_ID] = END then*/
    _2 = (object)SEQ_PTR(_tok_59869);
    _29925 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29925, 402)){
        _29925 = NOVALUE;
        goto L23; // [748] 874
    }
    _29925 = NOVALUE;

    /** parser.e:3126					tok = next_token()*/
    _0 = _tok_59869;
    _tok_59869 = _45next_token();
    DeRef(_0);

    /** parser.e:3127					if tok[T_ID] = IFDEF then*/
    _2 = (object)SEQ_PTR(_tok_59869);
    _29928 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29928, 407)){
        _29928 = NOVALUE;
        goto L24; // [767] 795
    }
    _29928 = NOVALUE;

    /** parser.e:3128						if dead_ifdef then*/
    if (_dead_ifdef_59866 == 0)
    {
        goto L25; // [773] 785
    }
    else{
    }

    /** parser.e:3129							dead_ifdef -= 1*/
    _dead_ifdef_59866 = _dead_ifdef_59866 - 1;
    goto L21; // [782] 698
L25: 

    /** parser.e:3131							exit "top"*/
    goto L26; // [789] 1350
    goto L21; // [792] 698
L24: 

    /** parser.e:3133					elsif in_matched then*/
    if (_in_matched_59865 == 0)
    {
        goto L27; // [797] 821
    }
    else{
    }

    /** parser.e:3135						CompileErr(EXPECTING_END_IFDEF_TO_MATCH_IFDEF_ON_LINE_1, ifdef_lineno[$])*/
    if (IS_SEQUENCE(_45ifdef_lineno_59859)){
            _29931 = SEQ_PTR(_45ifdef_lineno_59859)->length;
    }
    else {
        _29931 = 1;
    }
    _2 = (object)SEQ_PTR(_45ifdef_lineno_59859);
    _29932 = (object)*(((s1_ptr)_2)->base + _29931);
    _50CompileErr(75, _29932, 0);
    _29932 = NOVALUE;
    goto L21; // [818] 698
L27: 

    /** parser.e:3137						if tok[T_ID] = IF then*/
    _2 = (object)SEQ_PTR(_tok_59869);
    _29933 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29933, 20)){
        _29933 = NOVALUE;
        goto L21; // [831] 698
    }
    _29933 = NOVALUE;

    /** parser.e:3138							if if_lvl > 0 then*/
    if (_if_lvl_59996 <= 0)
    goto L28; // [837] 850

    /** parser.e:3139								if_lvl -= 1*/
    _if_lvl_59996 = _if_lvl_59996 - 1;
    goto L21; // [847] 698
L28: 

    /** parser.e:3141								CompileErr(MISMATCHED_END_IF_SHOULD_THIS_BE_AN_END_IFDEF_TO_MATCH_IFDEF_ON_LINE_1, ifdef_lineno[$])*/
    if (IS_SEQUENCE(_45ifdef_lineno_59859)){
            _29937 = SEQ_PTR(_45ifdef_lineno_59859)->length;
    }
    else {
        _29937 = 1;
    }
    _2 = (object)SEQ_PTR(_45ifdef_lineno_59859);
    _29938 = (object)*(((s1_ptr)_2)->base + _29937);
    _50CompileErr(111, _29938, 0);
    _29938 = NOVALUE;
    goto L21; // [871] 698
L23: 

    /** parser.e:3145				elsif tok[T_ID] = IF then*/
    _2 = (object)SEQ_PTR(_tok_59869);
    _29939 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29939, 20)){
        _29939 = NOVALUE;
        goto L29; // [884] 897
    }
    _29939 = NOVALUE;

    /** parser.e:3146					if_lvl += 1*/
    _if_lvl_59996 = _if_lvl_59996 + 1;
    goto L21; // [894] 698
L29: 

    /** parser.e:3147				elsif tok[T_ID] = ELSE then*/
    _2 = (object)SEQ_PTR(_tok_59869);
    _29942 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29942, 23)){
        _29942 = NOVALUE;
        goto L2A; // [907] 945
    }
    _29942 = NOVALUE;

    /** parser.e:3148					if not in_matched then*/
    if (_in_matched_59865 != 0)
    goto L21; // [913] 698

    /** parser.e:3149						if if_lvl = 0 then*/
    if (_if_lvl_59996 != 0)
    goto L21; // [918] 698

    /** parser.e:3150							CompileErr(MISMATCHED_ELSE_SHOULD_THIS_BE_AN_ELSEDEF_TO_MATCH_IFDEF_ON_LINE_1, ifdef_lineno[$])*/
    if (IS_SEQUENCE(_45ifdef_lineno_59859)){
            _29946 = SEQ_PTR(_45ifdef_lineno_59859)->length;
    }
    else {
        _29946 = 1;
    }
    _2 = (object)SEQ_PTR(_45ifdef_lineno_59859);
    _29947 = (object)*(((s1_ptr)_2)->base + _29946);
    _50CompileErr(108, _29947, 0);
    _29947 = NOVALUE;
    goto L21; // [942] 698
L2A: 

    /** parser.e:3153				elsif tok[T_ID] = ELSIFDEF and not dead_ifdef then*/
    _2 = (object)SEQ_PTR(_tok_59869);
    _29948 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_29948)) {
        _29949 = (_29948 == 408);
    }
    else {
        _29949 = binary_op(EQUALS, _29948, 408);
    }
    _29948 = NOVALUE;
    if (IS_ATOM_INT(_29949)) {
        if (_29949 == 0) {
            goto L2B; // [959] 1101
        }
    }
    else {
        if (DBL_PTR(_29949)->dbl == 0.0) {
            goto L2B; // [959] 1101
        }
    }
    _29951 = (_dead_ifdef_59866 == 0);
    if (_29951 == 0)
    {
        DeRef(_29951);
        _29951 = NOVALUE;
        goto L2B; // [967] 1101
    }
    else{
        DeRef(_29951);
        _29951 = NOVALUE;
    }

    /** parser.e:3154					if has_matched then*/
    if (_has_matched_59864 == 0)
    {
        goto L2C; // [972] 1343
    }
    else{
    }

    /** parser.e:3155						in_matched = 0*/
    _in_matched_59865 = 0;

    /** parser.e:3156						No_new_entry = 1*/
    _54No_new_entry_48334 = 1;

    /** parser.e:3157						gotword = 0*/
    _gotword_59994 = 0;

    /** parser.e:3158						gotthen = 0*/
    _gotthen_59995 = 0;

    /** parser.e:3159						while length(option) > 0 with entry do*/
    goto L2D; // [999] 1041
L2E: 
    if (IS_SEQUENCE(_option_59862)){
            _29952 = SEQ_PTR(_option_59862)->length;
    }
    else {
        _29952 = 1;
    }
    if (_29952 <= 0)
    goto L2F; // [1007] 1054

    /** parser.e:3160							if equal(option, "then") then*/
    if (_option_59862 == _26546)
    _29954 = 1;
    else if (IS_ATOM_INT(_option_59862) && IS_ATOM_INT(_26546))
    _29954 = 0;
    else
    _29954 = (compare(_option_59862, _26546) == 0);
    if (_29954 == 0)
    {
        _29954 = NOVALUE;
        goto L30; // [1017] 1032
    }
    else{
        _29954 = NOVALUE;
    }

    /** parser.e:3161								gotthen = 1*/
    _gotthen_59995 = 1;

    /** parser.e:3162								exit*/
    goto L2F; // [1027] 1054
    goto L31; // [1029] 1038
L30: 

    /** parser.e:3164								gotword = 1*/
    _gotword_59994 = 1;
L31: 

    /** parser.e:3166						entry*/
L2D: 

    /** parser.e:3167							option = StringToken()*/
    RefDS(_5);
    _0 = _option_59862;
    _option_59862 = _62StringToken(_5);
    DeRef(_0);

    /** parser.e:3168						end while*/
    goto L2E; // [1051] 1002
L2F: 

    /** parser.e:3169						if gotword = 0 then*/
    if (_gotword_59994 != 0)
    goto L32; // [1056] 1070

    /** parser.e:3170							CompileErr(EXPECTING_A_WORD_TO_FOLLOW_ELSIFDEF)*/
    RefDS(_22190);
    _50CompileErr(78, _22190, 0);
L32: 

    /** parser.e:3172						if gotthen = 0 then*/
    if (_gotthen_59995 != 0)
    goto L33; // [1072] 1086

    /** parser.e:3173							CompileErr(EXPECTING_THEN_ON_ELSIFDEF_LINE)*/
    RefDS(_22190);
    _50CompileErr(77, _22190, 0);
L33: 

    /** parser.e:3175						read_line()*/
    _62read_line();
    goto L21; // [1090] 698

    /** parser.e:3177						exit*/
    goto L2C; // [1095] 1343
    goto L21; // [1098] 698
L2B: 

    /** parser.e:3179				elsif tok[T_ID] = ELSEDEF then*/
    _2 = (object)SEQ_PTR(_tok_59869);
    _29958 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29958, 409)){
        _29958 = NOVALUE;
        goto L34; // [1111] 1273
    }
    _29958 = NOVALUE;

    /** parser.e:3180					gotword = line_number*/
    _gotword_59994 = _36line_number_21768;

    /** parser.e:3181					option = StringToken()*/
    RefDS(_5);
    _0 = _option_59862;
    _option_59862 = _62StringToken(_5);
    DeRef(_0);

    /** parser.e:3182					if length(option) > 0 then*/
    if (IS_SEQUENCE(_option_59862)){
            _29961 = SEQ_PTR(_option_59862)->length;
    }
    else {
        _29961 = 1;
    }
    if (_29961 <= 0)
    goto L35; // [1137] 1173

    /** parser.e:3183						if line_number = gotword then*/
    if (_36line_number_21768 != _gotword_59994)
    goto L36; // [1145] 1159

    /** parser.e:3184							CompileErr(NOT_EXPECTING_ANYTHING_ON_SAME_LINE_AS_ELSDEF)*/
    RefDS(_22190);
    _50CompileErr(116, _22190, 0);
L36: 

    /** parser.e:3186						bp -= length(option)*/
    if (IS_SEQUENCE(_option_59862)){
            _29964 = SEQ_PTR(_option_59862)->length;
    }
    else {
        _29964 = 1;
    }
    _50bp_49598 = _50bp_49598 - _29964;
    _29964 = NOVALUE;
L35: 

    /** parser.e:3188					if not dead_ifdef then*/
    if (_dead_ifdef_59866 != 0)
    goto L21; // [1175] 698

    /** parser.e:3189						if has_matched then*/
    if (_has_matched_59864 == 0)
    {
        goto L37; // [1180] 1202
    }
    else{
    }

    /** parser.e:3190							in_matched = 0*/
    _in_matched_59865 = 0;

    /** parser.e:3191							No_new_entry = 1*/
    _54No_new_entry_48334 = 1;

    /** parser.e:3192							read_line()*/
    _62read_line();
    goto L21; // [1199] 698
L37: 

    /** parser.e:3194							No_new_entry = 0*/
    _54No_new_entry_48334 = 0;

    /** parser.e:3195							in_elsedef = 1*/
    _in_elsedef_59867 = 1;

    /** parser.e:3196							call_proc(parser_id, {})*/
    _0 = (object)_00[_parser_id_59874].addr;
    (*(intptr_t (*)())_0)(
                         );

    /** parser.e:3197							tok_match(END)*/
    _45tok_match(402, 0);

    /** parser.e:3198							tok_match(IFDEF, END)*/
    _45tok_match(407, 402);

    /** parser.e:3199							live_ifdef -= 1*/
    _45live_ifdef_59858 = _45live_ifdef_59858 - 1;

    /** parser.e:3200							ifdef_lineno = ifdef_lineno[1..$-1]*/
    if (IS_SEQUENCE(_45ifdef_lineno_59859)){
            _29968 = SEQ_PTR(_45ifdef_lineno_59859)->length;
    }
    else {
        _29968 = 1;
    }
    _29969 = _29968 - 1;
    _29968 = NOVALUE;
    rhs_slice_target = (object_ptr)&_45ifdef_lineno_59859;
    RHS_Slice(_45ifdef_lineno_59859, 1, _29969);

    /** parser.e:3201							return*/
    DeRef(_option_59862);
    DeRef(_tok_59869);
    DeRefi(_keyw_59870);
    _29969 = NOVALUE;
    DeRef(_29903);
    _29903 = NOVALUE;
    DeRef(_29874);
    _29874 = NOVALUE;
    DeRef(_29868);
    _29868 = NOVALUE;
    DeRef(_29949);
    _29949 = NOVALUE;
    return;
    goto L21; // [1270] 698
L34: 

    /** parser.e:3204				elsif tok[T_ID] = IFDEF then*/
    _2 = (object)SEQ_PTR(_tok_59869);
    _29971 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29971, 407)){
        _29971 = NOVALUE;
        goto L38; // [1283] 1296
    }
    _29971 = NOVALUE;

    /** parser.e:3205					dead_ifdef += 1*/
    _dead_ifdef_59866 = _dead_ifdef_59866 + 1;
    goto L21; // [1293] 698
L38: 

    /** parser.e:3207				elsif tok[T_ID] = INCLUDE then*/
    _2 = (object)SEQ_PTR(_tok_59869);
    _29974 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29974, 418)){
        _29974 = NOVALUE;
        goto L39; // [1306] 1317
    }
    _29974 = NOVALUE;

    /** parser.e:3209					read_line()*/
    _62read_line();
    goto L21; // [1314] 698
L39: 

    /** parser.e:3211				elsif tok[T_ID] = CASE then*/
    _2 = (object)SEQ_PTR(_tok_59869);
    _29976 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29976, 186)){
        _29976 = NOVALUE;
        goto L21; // [1327] 698
    }
    _29976 = NOVALUE;

    /** parser.e:3213					tok = next_token()*/
    _0 = _tok_59869;
    _tok_59869 = _45next_token();
    DeRef(_0);

    /** parser.e:3216			end while*/
    goto L21; // [1340] 698
L2C: 

    /** parser.e:3217		end while*/
    goto L5; // [1347] 105
L26: 

    /** parser.e:3219		live_ifdef -= 1*/
    _45live_ifdef_59858 = _45live_ifdef_59858 - 1;

    /** parser.e:3220		ifdef_lineno = ifdef_lineno[1..$-1]*/
    if (IS_SEQUENCE(_45ifdef_lineno_59859)){
            _29980 = SEQ_PTR(_45ifdef_lineno_59859)->length;
    }
    else {
        _29980 = 1;
    }
    _29981 = _29980 - 1;
    _29980 = NOVALUE;
    rhs_slice_target = (object_ptr)&_45ifdef_lineno_59859;
    RHS_Slice(_45ifdef_lineno_59859, 1, _29981);

    /** parser.e:3221		No_new_entry = 0*/
    _54No_new_entry_48334 = 0;

    /** parser.e:3222	end procedure*/
    DeRef(_option_59862);
    DeRef(_tok_59869);
    DeRefi(_keyw_59870);
    DeRef(_29969);
    _29969 = NOVALUE;
    DeRef(_29903);
    _29903 = NOVALUE;
    DeRef(_29874);
    _29874 = NOVALUE;
    _29981 = NOVALUE;
    DeRef(_29868);
    _29868 = NOVALUE;
    DeRef(_29949);
    _29949 = NOVALUE;
    return;
    ;
}


object _45SetPrivateScope(object _s_60149, object _type_sym_60151, object _n_60152)
{
    object _hashval_60153 = NOVALUE;
    object _scope_60154 = NOVALUE;
    object _t_60156 = NOVALUE;
    object _30002 = NOVALUE;
    object _30001 = NOVALUE;
    object _30000 = NOVALUE;
    object _29999 = NOVALUE;
    object _29998 = NOVALUE;
    object _29997 = NOVALUE;
    object _29994 = NOVALUE;
    object _29991 = NOVALUE;
    object _29989 = NOVALUE;
    object _29987 = NOVALUE;
    object _29983 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_s_60149)) {
        _1 = (object)(DBL_PTR(_s_60149)->dbl);
        DeRefDS(_s_60149);
        _s_60149 = _1;
    }

    /** parser.e:3230		scope = SymTab[s][S_SCOPE]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _29983 = (object)*(((s1_ptr)_2)->base + _s_60149);
    _2 = (object)SEQ_PTR(_29983);
    _scope_60154 = (object)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_scope_60154)){
        _scope_60154 = (object)DBL_PTR(_scope_60154)->dbl;
    }
    _29983 = NOVALUE;

    /** parser.e:3231		switch scope do*/
    _0 = _scope_60154;
    switch ( _0 ){ 

        /** parser.e:3232			case SC_PRIVATE then*/
        case 3:

        /** parser.e:3233				DefinedYet(s)*/
        _54DefinedYet(_s_60149);

        /** parser.e:3234				Block_var( s )*/
        _65Block_var(_s_60149);

        /** parser.e:3235				return s*/
        return _s_60149;
        goto L1; // [50] 260

        /** parser.e:3237			case SC_LOOP_VAR then*/
        case 2:

        /** parser.e:3238				DefinedYet(s)*/
        _54DefinedYet(_s_60149);

        /** parser.e:3239				return s*/
        return _s_60149;
        goto L1; // [67] 260

        /** parser.e:3241			case SC_UNDEFINED, SC_MULTIPLY_DEFINED then*/
        case 9:
        case 10:

        /** parser.e:3242				SymTab[s][S_SCOPE] = SC_PRIVATE*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37SymTab_15637 = MAKE_SEQ(_2);
        }
        _3 = (object)(_s_60149 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 4);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = 3;
        DeRef(_1);
        _29987 = NOVALUE;

        /** parser.e:3243				SymTab[s][S_VARNUM] = n*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37SymTab_15637 = MAKE_SEQ(_2);
        }
        _3 = (object)(_s_60149 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 16);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _n_60152;
        DeRef(_1);
        _29989 = NOVALUE;

        /** parser.e:3244				SymTab[s][S_VTYPE] = type_sym*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37SymTab_15637 = MAKE_SEQ(_2);
        }
        _3 = (object)(_s_60149 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 15);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _type_sym_60151;
        DeRef(_1);
        _29991 = NOVALUE;

        /** parser.e:3245				if type_sym < 0 then*/
        if (_type_sym_60151 >= 0)
        goto L2; // [124] 135

        /** parser.e:3246					register_forward_type( s, type_sym )*/
        _44register_forward_type(_s_60149, _type_sym_60151);
L2: 

        /** parser.e:3248				Block_var( s )*/
        _65Block_var(_s_60149);

        /** parser.e:3249				return s*/
        return _s_60149;
        goto L1; // [146] 260

        /** parser.e:3251			case SC_LOCAL, SC_GLOBAL, SC_PREDEF, SC_PUBLIC, SC_EXPORT then*/
        case 5:
        case 6:
        case 7:
        case 13:
        case 11:

        /** parser.e:3252				hashval = SymTab[s][S_HASHVAL]*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _29994 = (object)*(((s1_ptr)_2)->base + _s_60149);
        _2 = (object)SEQ_PTR(_29994);
        _hashval_60153 = (object)*(((s1_ptr)_2)->base + 11);
        if (!IS_ATOM_INT(_hashval_60153)){
            _hashval_60153 = (object)DBL_PTR(_hashval_60153)->dbl;
        }
        _29994 = NOVALUE;

        /** parser.e:3253				t = buckets[hashval]*/
        _2 = (object)SEQ_PTR(_54buckets_47132);
        _t_60156 = (object)*(((s1_ptr)_2)->base + _hashval_60153);
        if (!IS_ATOM_INT(_t_60156)){
            _t_60156 = (object)DBL_PTR(_t_60156)->dbl;
        }

        /** parser.e:3254				buckets[hashval] = NewEntry(SymTab[s][S_NAME], n, SC_PRIVATE,*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _29997 = (object)*(((s1_ptr)_2)->base + _s_60149);
        _2 = (object)SEQ_PTR(_29997);
        if (!IS_ATOM_INT(_36S_NAME_21404)){
            _29998 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21404)->dbl));
        }
        else{
            _29998 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21404);
        }
        _29997 = NOVALUE;
        Ref(_29998);
        _29999 = _54NewEntry(_29998, _n_60152, 3, -100, _hashval_60153, _t_60156, _type_sym_60151);
        _29998 = NOVALUE;
        _2 = (object)SEQ_PTR(_54buckets_47132);
        _2 = (object)(((s1_ptr)_2)->base + _hashval_60153);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _29999;
        if( _1 != _29999 ){
            DeRef(_1);
        }
        _29999 = NOVALUE;

        /** parser.e:3256				Block_var( buckets[hashval] )*/
        _2 = (object)SEQ_PTR(_54buckets_47132);
        _30000 = (object)*(((s1_ptr)_2)->base + _hashval_60153);
        Ref(_30000);
        _65Block_var(_30000);
        _30000 = NOVALUE;

        /** parser.e:3257				return buckets[hashval]*/
        _2 = (object)SEQ_PTR(_54buckets_47132);
        _30001 = (object)*(((s1_ptr)_2)->base + _hashval_60153);
        Ref(_30001);
        return _30001;
        goto L1; // [243] 260

        /** parser.e:3259			case else*/
        default:

        /** parser.e:3260				InternalErr(267, {scope})*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _scope_60154;
        _30002 = MAKE_SEQ(_1);
        _50InternalErr(267, _30002);
        _30002 = NOVALUE;
    ;}L1: 

    /** parser.e:3264		return 0*/
    _30001 = NOVALUE;
    return 0;
    ;
}


void _45For_statement()
{
    object _bp1_60221 = NOVALUE;
    object _bp2_60222 = NOVALUE;
    object _exit_base_60223 = NOVALUE;
    object _next_base_60224 = NOVALUE;
    object _end_op_60225 = NOVALUE;
    object _tok_60227 = NOVALUE;
    object _loop_var_60228 = NOVALUE;
    object _loop_var_sym_60230 = NOVALUE;
    object _save_syms_60231 = NOVALUE;
    object _30049 = NOVALUE;
    object _30047 = NOVALUE;
    object _30046 = NOVALUE;
    object _30040 = NOVALUE;
    object _30038 = NOVALUE;
    object _30036 = NOVALUE;
    object _30035 = NOVALUE;
    object _30034 = NOVALUE;
    object _30033 = NOVALUE;
    object _30031 = NOVALUE;
    object _30029 = NOVALUE;
    object _30028 = NOVALUE;
    object _30027 = NOVALUE;
    object _30026 = NOVALUE;
    object _30024 = NOVALUE;
    object _30022 = NOVALUE;
    object _30018 = NOVALUE;
    object _30016 = NOVALUE;
    object _30013 = NOVALUE;
    object _30011 = NOVALUE;
    object _30005 = NOVALUE;
    object _30004 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:3273		sequence save_syms*/

    /** parser.e:3275		Start_block( FOR )*/
    _65Start_block(21, 0);

    /** parser.e:3276		loop_var = next_token()*/
    _0 = _loop_var_60228;
    _loop_var_60228 = _45next_token();
    DeRef(_0);

    /** parser.e:3277		if not find(loop_var[T_ID], ADDR_TOKS) then*/
    _2 = (object)SEQ_PTR(_loop_var_60228);
    _30004 = (object)*(((s1_ptr)_2)->base + 1);
    _30005 = find_from(_30004, _38ADDR_TOKS_16295, 1);
    _30004 = NOVALUE;
    if (_30005 != 0)
    goto L1; // [31] 44
    _30005 = NOVALUE;

    /** parser.e:3278			CompileErr(A_LOOP_VARIABLE_NAME_IS_EXPECTED_HERE)*/
    RefDS(_22190);
    _50CompileErr(28, _22190, 0);
L1: 

    /** parser.e:3281		if BIND then*/
    if (_36BIND_21372 == 0)
    {
        goto L2; // [48] 57
    }
    else{
    }

    /** parser.e:3282			add_ref(loop_var)*/
    Ref(_loop_var_60228);
    _54add_ref(_loop_var_60228);
L2: 

    /** parser.e:3285		tok_match(EQUALS)*/
    _45tok_match(3, 0);

    /** parser.e:3286		exit_base = length(exit_list)*/
    if (IS_SEQUENCE(_45exit_list_55376)){
            _exit_base_60223 = SEQ_PTR(_45exit_list_55376)->length;
    }
    else {
        _exit_base_60223 = 1;
    }

    /** parser.e:3287		next_base = length(continue_list)*/
    if (IS_SEQUENCE(_45continue_list_55378)){
            _next_base_60224 = SEQ_PTR(_45continue_list_55378)->length;
    }
    else {
        _next_base_60224 = 1;
    }

    /** parser.e:3288		Expr()*/
    _45Expr();

    /** parser.e:3289		tok_match(TO)*/
    _45tok_match(403, 0);

    /** parser.e:3290		exit_base = length(exit_list)*/
    if (IS_SEQUENCE(_45exit_list_55376)){
            _exit_base_60223 = SEQ_PTR(_45exit_list_55376)->length;
    }
    else {
        _exit_base_60223 = 1;
    }

    /** parser.e:3291		Expr()*/
    _45Expr();

    /** parser.e:3292		tok = next_token()*/
    _0 = _tok_60227;
    _tok_60227 = _45next_token();
    DeRef(_0);

    /** parser.e:3293		if tok[T_ID] = BY then*/
    _2 = (object)SEQ_PTR(_tok_60227);
    _30011 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30011, 404)){
        _30011 = NOVALUE;
        goto L3; // [117] 137
    }
    _30011 = NOVALUE;

    /** parser.e:3294			Expr()*/
    _45Expr();

    /** parser.e:3295			end_op = ENDFOR_GENERAL -- will be set at runtime by FOR op*/
    _end_op_60225 = 39;
    goto L4; // [134] 161
L3: 

    /** parser.e:3298			emit_opnd(NewIntSym(1))*/
    _30013 = _54NewIntSym(1);
    _47emit_opnd(_30013);
    _30013 = NOVALUE;

    /** parser.e:3299			putback(tok)*/
    Ref(_tok_60227);
    _45putback(_tok_60227);

    /** parser.e:3300			end_op = ENDFOR_INT_UP1*/
    _end_op_60225 = 54;
L4: 

    /** parser.e:3303		loop_var_sym = loop_var[T_SYM]*/
    _2 = (object)SEQ_PTR(_loop_var_60228);
    _loop_var_sym_60230 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_loop_var_sym_60230)){
        _loop_var_sym_60230 = (object)DBL_PTR(_loop_var_sym_60230)->dbl;
    }

    /** parser.e:3304		if CurrentSub = TopLevelSub then*/
    if (_36CurrentSub_21775 != _36TopLevelSub_21774)
    goto L5; // [177] 223

    /** parser.e:3305			DefinedYet(loop_var_sym)*/
    _54DefinedYet(_loop_var_sym_60230);

    /** parser.e:3306			SymTab[loop_var_sym][S_SCOPE] = SC_GLOOP_VAR*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_loop_var_sym_60230 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 4;
    DeRef(_1);
    _30016 = NOVALUE;

    /** parser.e:3307			SymTab[loop_var_sym][S_VTYPE] = object_type*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_loop_var_sym_60230 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 15);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _54object_type_47136;
    DeRef(_1);
    _30018 = NOVALUE;
    goto L6; // [220] 267
L5: 

    /** parser.e:3309			loop_var_sym = SetPrivateScope(loop_var_sym, object_type, param_num)*/
    _loop_var_sym_60230 = _45SetPrivateScope(_loop_var_sym_60230, _54object_type_47136, _45param_num_55365);
    if (!IS_ATOM_INT(_loop_var_sym_60230)) {
        _1 = (object)(DBL_PTR(_loop_var_sym_60230)->dbl);
        DeRefDS(_loop_var_sym_60230);
        _loop_var_sym_60230 = _1;
    }

    /** parser.e:3310			param_num += 1*/
    _45param_num_55365 = _45param_num_55365 + 1;

    /** parser.e:3311			SymTab[loop_var_sym][S_SCOPE] = SC_LOOP_VAR*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_loop_var_sym_60230 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2;
    DeRef(_1);
    _30022 = NOVALUE;

    /** parser.e:3312			Pop_block_var()*/
    _65Pop_block_var();
L6: 

    /** parser.e:3314		SymTab[loop_var_sym][S_USAGE] = or_bits(SymTab[loop_var_sym][S_USAGE], U_USED)*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_loop_var_sym_60230 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _30026 = (object)*(((s1_ptr)_2)->base + _loop_var_sym_60230);
    _2 = (object)SEQ_PTR(_30026);
    _30027 = (object)*(((s1_ptr)_2)->base + 5);
    _30026 = NOVALUE;
    if (IS_ATOM_INT(_30027)) {
        {uintptr_t tu;
             tu = (uintptr_t)_30027 | (uintptr_t)3;
             _30028 = MAKE_UINT(tu);
        }
    }
    else {
        _30028 = binary_op(OR_BITS, _30027, 3);
    }
    _30027 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30028;
    if( _1 != _30028 ){
        DeRef(_1);
    }
    _30028 = NOVALUE;
    _30024 = NOVALUE;

    /** parser.e:3316		op_info1 = loop_var_sym*/
    _47op_info1_51364 = _loop_var_sym_60230;

    /** parser.e:3317		emit_op(FOR)*/
    _47emit_op(21);

    /** parser.e:3318		emit_addr(loop_var_sym)*/
    _47emit_addr(_loop_var_sym_60230);

    /** parser.e:3319		if finish_block_header(FOR) then*/
    _30029 = _45finish_block_header(21);
    if (_30029 == 0) {
        DeRef(_30029);
        _30029 = NOVALUE;
        goto L7; // [327] 340
    }
    else {
        if (!IS_ATOM_INT(_30029) && DBL_PTR(_30029)->dbl == 0.0){
            DeRef(_30029);
            _30029 = NOVALUE;
            goto L7; // [327] 340
        }
        DeRef(_30029);
        _30029 = NOVALUE;
    }
    DeRef(_30029);
    _30029 = NOVALUE;

    /** parser.e:3320			CompileErr(ENTRY_IS_NOT_SUPPORTED_IN_FOR_LOOPS)*/
    RefDS(_22190);
    _50CompileErr(83, _22190, 0);
L7: 

    /** parser.e:3322		entry_addr &= 0*/
    Append(&_45entry_addr_55380, _45entry_addr_55380, 0);

    /** parser.e:3323		bp1 = length(Code)+1*/
    if (IS_SEQUENCE(_36Code_21859)){
            _30031 = SEQ_PTR(_36Code_21859)->length;
    }
    else {
        _30031 = 1;
    }
    _bp1_60221 = _30031 + 1;
    _30031 = NOVALUE;

    /** parser.e:3324		emit_addr(0) -- will be patched - don't straighten*/
    _47emit_addr(0);

    /** parser.e:3326		save_syms = Code[$-5..$-3] -- could be temps, but can't get rid of them yet*/
    if (IS_SEQUENCE(_36Code_21859)){
            _30033 = SEQ_PTR(_36Code_21859)->length;
    }
    else {
        _30033 = 1;
    }
    _30034 = _30033 - 5;
    _30033 = NOVALUE;
    if (IS_SEQUENCE(_36Code_21859)){
            _30035 = SEQ_PTR(_36Code_21859)->length;
    }
    else {
        _30035 = 1;
    }
    _30036 = _30035 - 3;
    _30035 = NOVALUE;
    rhs_slice_target = (object_ptr)&_save_syms_60231;
    RHS_Slice(_36Code_21859, _30034, _30036);

    /** parser.e:3327		for i = 1 to 3 do*/
    {
        object _i_60321;
        _i_60321 = 1;
L8: 
        if (_i_60321 > 3){
            goto L9; // [389] 412
        }

        /** parser.e:3328			clear_temp( save_syms[i] )*/
        _2 = (object)SEQ_PTR(_save_syms_60231);
        _30038 = (object)*(((s1_ptr)_2)->base + _i_60321);
        Ref(_30038);
        _47clear_temp(_30038);
        _30038 = NOVALUE;

        /** parser.e:3329		end for*/
        _i_60321 = _i_60321 + 1;
        goto L8; // [407] 396
L9: 
        ;
    }

    /** parser.e:3330		flush_temps()*/
    RefDS(_22190);
    _47flush_temps(_22190);

    /** parser.e:3332		bp2 = length(Code)*/
    if (IS_SEQUENCE(_36Code_21859)){
            _bp2_60222 = SEQ_PTR(_36Code_21859)->length;
    }
    else {
        _bp2_60222 = 1;
    }

    /** parser.e:3333		retry_addr &= bp2 + 1*/
    _30040 = _bp2_60222 + 1;
    Append(&_45retry_addr_55382, _45retry_addr_55382, _30040);
    _30040 = NOVALUE;

    /** parser.e:3334		continue_addr &= 0*/
    Append(&_45continue_addr_55381, _45continue_addr_55381, 0);

    /** parser.e:3336		loop_stack &= FOR*/
    Append(&_45loop_stack_55390, _45loop_stack_55390, 21);

    /** parser.e:3338		if not TRANSLATE then*/
    if (_36TRANSLATE_21369 != 0)
    goto LA; // [458] 482

    /** parser.e:3339			if OpTrace then*/
    if (_36OpTrace_21840 == 0)
    {
        goto LB; // [465] 481
    }
    else{
    }

    /** parser.e:3340				emit_op(DISPLAY_VAR)*/
    _47emit_op(87);

    /** parser.e:3341				emit_addr(loop_var_sym)*/
    _47emit_addr(_loop_var_sym_60230);
LB: 
LA: 

    /** parser.e:3345		Statement_list()*/
    _45Statement_list();

    /** parser.e:3346		tok_match(END)*/
    _45tok_match(402, 0);

    /** parser.e:3347		tok_match(FOR, END)*/
    _45tok_match(21, 402);

    /** parser.e:3349		End_block( FOR )*/
    _65End_block(21);

    /** parser.e:3351		StartSourceLine(TRUE, TRANSLATE)*/
    _47StartSourceLine(_13TRUE_447, _36TRANSLATE_21369, 2);

    /** parser.e:3352		op_info1 = loop_var_sym*/
    _47op_info1_51364 = _loop_var_sym_60230;

    /** parser.e:3353		op_info2 = bp2 + 1*/
    _47op_info2_51365 = _bp2_60222 + 1;

    /** parser.e:3354		PatchNList(next_base)*/
    _45PatchNList(_next_base_60224);

    /** parser.e:3355		emit_op(end_op)*/
    _47emit_op(_end_op_60225);

    /** parser.e:3356		backpatch(bp1, length(Code)+1)*/
    if (IS_SEQUENCE(_36Code_21859)){
            _30046 = SEQ_PTR(_36Code_21859)->length;
    }
    else {
        _30046 = 1;
    }
    _30047 = _30046 + 1;
    _30046 = NOVALUE;
    _47backpatch(_bp1_60221, _30047);
    _30047 = NOVALUE;

    /** parser.e:3357		if not TRANSLATE then*/
    if (_36TRANSLATE_21369 != 0)
    goto LC; // [568] 592

    /** parser.e:3358			if OpTrace then*/
    if (_36OpTrace_21840 == 0)
    {
        goto LD; // [575] 591
    }
    else{
    }

    /** parser.e:3359				emit_op(ERASE_SYMBOL)*/
    _47emit_op(90);

    /** parser.e:3360				emit_addr(loop_var_sym)*/
    _47emit_addr(_loop_var_sym_60230);
LD: 
LC: 

    /** parser.e:3364		Hide(loop_var_sym)*/
    _54Hide(_loop_var_sym_60230);

    /** parser.e:3365		exit_loop(exit_base)*/
    _45exit_loop(_exit_base_60223);

    /** parser.e:3366		for i = 1 to 3 do*/
    {
        object _i_60367;
        _i_60367 = 1;
LE: 
        if (_i_60367 > 3){
            goto LF; // [604] 630
        }

        /** parser.e:3367			emit_temp( save_syms[i], NEW_REFERENCE )*/
        _2 = (object)SEQ_PTR(_save_syms_60231);
        _30049 = (object)*(((s1_ptr)_2)->base + _i_60367);
        Ref(_30049);
        _47emit_temp(_30049, 1);
        _30049 = NOVALUE;

        /** parser.e:3368		end for*/
        _i_60367 = _i_60367 + 1;
        goto LE; // [625] 611
LF: 
        ;
    }

    /** parser.e:3369		flush_temps()*/
    RefDS(_22190);
    _47flush_temps(_22190);

    /** parser.e:3370	end procedure*/
    DeRef(_tok_60227);
    DeRef(_loop_var_60228);
    DeRef(_save_syms_60231);
    DeRef(_30034);
    _30034 = NOVALUE;
    DeRef(_30036);
    _30036 = NOVALUE;
    return;
    ;
}


object _45CompileType(object _type_ptr_60375)
{
    object _t_60376 = NOVALUE;
    object _30060 = NOVALUE;
    object _30059 = NOVALUE;
    object _30058 = NOVALUE;
    object _30052 = NOVALUE;
    object _30051 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_type_ptr_60375)) {
        _1 = (object)(DBL_PTR(_type_ptr_60375)->dbl);
        DeRefDS(_type_ptr_60375);
        _type_ptr_60375 = _1;
    }

    /** parser.e:3376		if type_ptr < 0 then*/
    if (_type_ptr_60375 >= 0)
    goto L1; // [5] 16

    /** parser.e:3378			return type_ptr*/
    return _type_ptr_60375;
L1: 

    /** parser.e:3381		if SymTab[type_ptr][S_TOKEN] = OBJECT then*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _30051 = (object)*(((s1_ptr)_2)->base + _type_ptr_60375);
    _2 = (object)SEQ_PTR(_30051);
    if (!IS_ATOM_INT(_36S_TOKEN_21409)){
        _30052 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21409)->dbl));
    }
    else{
        _30052 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21409);
    }
    _30051 = NOVALUE;
    if (binary_op_a(NOTEQ, _30052, 415)){
        _30052 = NOVALUE;
        goto L2; // [32] 47
    }
    _30052 = NOVALUE;

    /** parser.e:3382			return TYPE_OBJECT*/
    return 16;
    goto L3; // [44] 218
L2: 

    /** parser.e:3384		elsif type_ptr = integer_type then*/
    if (_type_ptr_60375 != _54integer_type_47142)
    goto L4; // [51] 66

    /** parser.e:3385			return TYPE_INTEGER*/
    return 1;
    goto L3; // [63] 218
L4: 

    /** parser.e:3387		elsif type_ptr = atom_type then*/
    if (_type_ptr_60375 != _54atom_type_47138)
    goto L5; // [70] 85

    /** parser.e:3388			return TYPE_ATOM*/
    return 4;
    goto L3; // [82] 218
L5: 

    /** parser.e:3390		elsif type_ptr = sequence_type then*/
    if (_type_ptr_60375 != _54sequence_type_47140)
    goto L6; // [89] 104

    /** parser.e:3391			return TYPE_SEQUENCE*/
    return 8;
    goto L3; // [101] 218
L6: 

    /** parser.e:3393		elsif type_ptr = object_type then*/
    if (_type_ptr_60375 != _54object_type_47136)
    goto L7; // [108] 123

    /** parser.e:3394			return TYPE_OBJECT*/
    return 16;
    goto L3; // [120] 218
L7: 

    /** parser.e:3398			t = SymTab[SymTab[type_ptr][S_NEXT]][S_VTYPE]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _30058 = (object)*(((s1_ptr)_2)->base + _type_ptr_60375);
    _2 = (object)SEQ_PTR(_30058);
    _30059 = (object)*(((s1_ptr)_2)->base + 2);
    _30058 = NOVALUE;
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!IS_ATOM_INT(_30059)){
        _30060 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_30059)->dbl));
    }
    else{
        _30060 = (object)*(((s1_ptr)_2)->base + _30059);
    }
    _2 = (object)SEQ_PTR(_30060);
    _t_60376 = (object)*(((s1_ptr)_2)->base + 15);
    if (!IS_ATOM_INT(_t_60376)){
        _t_60376 = (object)DBL_PTR(_t_60376)->dbl;
    }
    _30060 = NOVALUE;

    /** parser.e:3399			if t = integer_type then*/
    if (_t_60376 != _54integer_type_47142)
    goto L8; // [155] 170

    /** parser.e:3400				return TYPE_INTEGER*/
    _30059 = NOVALUE;
    return 1;
    goto L9; // [167] 217
L8: 

    /** parser.e:3401			elsif t = atom_type then*/
    if (_t_60376 != _54atom_type_47138)
    goto LA; // [174] 189

    /** parser.e:3402				return TYPE_ATOM*/
    _30059 = NOVALUE;
    return 4;
    goto L9; // [186] 217
LA: 

    /** parser.e:3403			elsif t = sequence_type then*/
    if (_t_60376 != _54sequence_type_47140)
    goto LB; // [193] 208

    /** parser.e:3404				return TYPE_SEQUENCE*/
    _30059 = NOVALUE;
    return 8;
    goto L9; // [205] 217
LB: 

    /** parser.e:3406				return TYPE_OBJECT*/
    _30059 = NOVALUE;
    return 16;
L9: 
L3: 
    ;
}


object _45get_assigned_sym()
{
    object _30073 = NOVALUE;
    object _30072 = NOVALUE;
    object _30071 = NOVALUE;
    object _30069 = NOVALUE;
    object _30068 = NOVALUE;
    object _30067 = NOVALUE;
    object _30066 = NOVALUE;
    object _30065 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:3416		if not find( Code[$-2], {ASSIGN, ASSIGN_I}) then*/
    if (IS_SEQUENCE(_36Code_21859)){
            _30065 = SEQ_PTR(_36Code_21859)->length;
    }
    else {
        _30065 = 1;
    }
    _30066 = _30065 - 2;
    _30065 = NOVALUE;
    _2 = (object)SEQ_PTR(_36Code_21859);
    _30067 = (object)*(((s1_ptr)_2)->base + _30066);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 18;
    ((intptr_t *)_2)[2] = 113;
    _30068 = MAKE_SEQ(_1);
    _30069 = find_from(_30067, _30068, 1);
    _30067 = NOVALUE;
    DeRefDS(_30068);
    _30068 = NOVALUE;
    if (_30069 != 0)
    goto L1; // [29] 39
    _30069 = NOVALUE;

    /** parser.e:3417			return 0*/
    _30066 = NOVALUE;
    return 0;
L1: 

    /** parser.e:3419		return Code[$-1]*/
    if (IS_SEQUENCE(_36Code_21859)){
            _30071 = SEQ_PTR(_36Code_21859)->length;
    }
    else {
        _30071 = 1;
    }
    _30072 = _30071 - 1;
    _30071 = NOVALUE;
    _2 = (object)SEQ_PTR(_36Code_21859);
    _30073 = (object)*(((s1_ptr)_2)->base + _30072);
    Ref(_30073);
    _30072 = NOVALUE;
    DeRef(_30066);
    _30066 = NOVALUE;
    return _30073;
    ;
}


void _45Assign_Constant(object _sym_60445)
{
    object _valsym_60447 = NOVALUE;
    object _val_60450 = NOVALUE;
    object _30100 = NOVALUE;
    object _30099 = NOVALUE;
    object _30097 = NOVALUE;
    object _30096 = NOVALUE;
    object _30095 = NOVALUE;
    object _30093 = NOVALUE;
    object _30092 = NOVALUE;
    object _30091 = NOVALUE;
    object _30089 = NOVALUE;
    object _30088 = NOVALUE;
    object _30087 = NOVALUE;
    object _30085 = NOVALUE;
    object _30084 = NOVALUE;
    object _30083 = NOVALUE;
    object _30081 = NOVALUE;
    object _30079 = NOVALUE;
    object _30077 = NOVALUE;
    object _30075 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:3423		symtab_index valsym = Pop() -- pop the sym for the constant, too*/
    _valsym_60447 = _47Pop();
    if (!IS_ATOM_INT(_valsym_60447)) {
        _1 = (object)(DBL_PTR(_valsym_60447)->dbl);
        DeRefDS(_valsym_60447);
        _valsym_60447 = _1;
    }

    /** parser.e:3424		object val = SymTab[valsym][S_OBJ]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _30075 = (object)*(((s1_ptr)_2)->base + _valsym_60447);
    DeRef(_val_60450);
    _2 = (object)SEQ_PTR(_30075);
    _val_60450 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_val_60450);
    _30075 = NOVALUE;

    /** parser.e:3426		SymTab[sym][S_OBJ] = val*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60445 + ((s1_ptr)_2)->base);
    Ref(_val_60450);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _val_60450;
    DeRef(_1);
    _30077 = NOVALUE;

    /** parser.e:3427		SymTab[sym][S_INITLEVEL] = 0*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60445 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 14);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);
    _30079 = NOVALUE;

    /** parser.e:3429		if TRANSLATE then*/
    if (_36TRANSLATE_21369 == 0)
    {
        goto L1; // [58] 197
    }
    else{
    }

    /** parser.e:3431			SymTab[sym][S_GTYPE] = SymTab[valsym][S_GTYPE]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60445 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _30083 = (object)*(((s1_ptr)_2)->base + _valsym_60447);
    _2 = (object)SEQ_PTR(_30083);
    _30084 = (object)*(((s1_ptr)_2)->base + 36);
    _30083 = NOVALUE;
    Ref(_30084);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30084;
    if( _1 != _30084 ){
        DeRef(_1);
    }
    _30084 = NOVALUE;
    _30081 = NOVALUE;

    /** parser.e:3432			SymTab[sym][S_SEQ_ELEM] = SymTab[valsym][S_SEQ_ELEM]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60445 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _30087 = (object)*(((s1_ptr)_2)->base + _valsym_60447);
    _2 = (object)SEQ_PTR(_30087);
    _30088 = (object)*(((s1_ptr)_2)->base + 33);
    _30087 = NOVALUE;
    Ref(_30088);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30088;
    if( _1 != _30088 ){
        DeRef(_1);
    }
    _30088 = NOVALUE;
    _30085 = NOVALUE;

    /** parser.e:3433			SymTab[sym][S_OBJ_MIN] = SymTab[valsym][S_OBJ_MIN]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60445 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _30091 = (object)*(((s1_ptr)_2)->base + _valsym_60447);
    _2 = (object)SEQ_PTR(_30091);
    _30092 = (object)*(((s1_ptr)_2)->base + 30);
    _30091 = NOVALUE;
    Ref(_30092);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 30);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30092;
    if( _1 != _30092 ){
        DeRef(_1);
    }
    _30092 = NOVALUE;
    _30089 = NOVALUE;

    /** parser.e:3434			SymTab[sym][S_OBJ_MAX] = SymTab[valsym][S_OBJ_MAX]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60445 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _30095 = (object)*(((s1_ptr)_2)->base + _valsym_60447);
    _2 = (object)SEQ_PTR(_30095);
    _30096 = (object)*(((s1_ptr)_2)->base + 31);
    _30095 = NOVALUE;
    Ref(_30096);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 31);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30096;
    if( _1 != _30096 ){
        DeRef(_1);
    }
    _30096 = NOVALUE;
    _30093 = NOVALUE;

    /** parser.e:3435			SymTab[sym][S_SEQ_LEN] = SymTab[valsym][S_SEQ_LEN]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60445 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _30099 = (object)*(((s1_ptr)_2)->base + _valsym_60447);
    _2 = (object)SEQ_PTR(_30099);
    _30100 = (object)*(((s1_ptr)_2)->base + 32);
    _30099 = NOVALUE;
    Ref(_30100);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 32);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30100;
    if( _1 != _30100 ){
        DeRef(_1);
    }
    _30100 = NOVALUE;
    _30097 = NOVALUE;
L1: 

    /** parser.e:3437	end procedure*/
    DeRef(_val_60450);
    return;
    ;
}


object _45Global_declaration(object _type_ptr_60507, object _scope_60508)
{
    object _new_symbols_60509 = NOVALUE;
    object _tok_60511 = NOVALUE;
    object _tsym_60512 = NOVALUE;
    object _prevtok_60513 = NOVALUE;
    object _sym_60515 = NOVALUE;
    object _valsym_60516 = NOVALUE;
    object _h_60517 = NOVALUE;
    object _count_60518 = NOVALUE;
    object _val_60519 = NOVALUE;
    object _usedval_60520 = NOVALUE;
    object _deltafunc_60521 = NOVALUE;
    object _delta_60522 = NOVALUE;
    object _is_fwd_ref_60523 = NOVALUE;
    object _ptok_60540 = NOVALUE;
    object _negate_60556 = NOVALUE;
    object _negate_60805 = NOVALUE;
    object _31958 = NOVALUE;
    object _31957 = NOVALUE;
    object _31956 = NOVALUE;
    object _30340 = NOVALUE;
    object _30338 = NOVALUE;
    object _30336 = NOVALUE;
    object _30334 = NOVALUE;
    object _30332 = NOVALUE;
    object _30329 = NOVALUE;
    object _30327 = NOVALUE;
    object _30326 = NOVALUE;
    object _30325 = NOVALUE;
    object _30324 = NOVALUE;
    object _30323 = NOVALUE;
    object _30322 = NOVALUE;
    object _30320 = NOVALUE;
    object _30316 = NOVALUE;
    object _30314 = NOVALUE;
    object _30312 = NOVALUE;
    object _30310 = NOVALUE;
    object _30308 = NOVALUE;
    object _30306 = NOVALUE;
    object _30305 = NOVALUE;
    object _30303 = NOVALUE;
    object _30302 = NOVALUE;
    object _30301 = NOVALUE;
    object _30299 = NOVALUE;
    object _30297 = NOVALUE;
    object _30295 = NOVALUE;
    object _30294 = NOVALUE;
    object _30293 = NOVALUE;
    object _30291 = NOVALUE;
    object _30290 = NOVALUE;
    object _30289 = NOVALUE;
    object _30287 = NOVALUE;
    object _30285 = NOVALUE;
    object _30283 = NOVALUE;
    object _30282 = NOVALUE;
    object _30281 = NOVALUE;
    object _30280 = NOVALUE;
    object _30279 = NOVALUE;
    object _30276 = NOVALUE;
    object _30274 = NOVALUE;
    object _30272 = NOVALUE;
    object _30271 = NOVALUE;
    object _30270 = NOVALUE;
    object _30266 = NOVALUE;
    object _30265 = NOVALUE;
    object _30264 = NOVALUE;
    object _30260 = NOVALUE;
    object _30259 = NOVALUE;
    object _30258 = NOVALUE;
    object _30256 = NOVALUE;
    object _30255 = NOVALUE;
    object _30254 = NOVALUE;
    object _30253 = NOVALUE;
    object _30252 = NOVALUE;
    object _30251 = NOVALUE;
    object _30250 = NOVALUE;
    object _30249 = NOVALUE;
    object _30248 = NOVALUE;
    object _30245 = NOVALUE;
    object _30243 = NOVALUE;
    object _30242 = NOVALUE;
    object _30240 = NOVALUE;
    object _30239 = NOVALUE;
    object _30237 = NOVALUE;
    object _30236 = NOVALUE;
    object _30235 = NOVALUE;
    object _30234 = NOVALUE;
    object _30232 = NOVALUE;
    object _30230 = NOVALUE;
    object _30228 = NOVALUE;
    object _30225 = NOVALUE;
    object _30222 = NOVALUE;
    object _30219 = NOVALUE;
    object _30217 = NOVALUE;
    object _30216 = NOVALUE;
    object _30215 = NOVALUE;
    object _30214 = NOVALUE;
    object _30212 = NOVALUE;
    object _30211 = NOVALUE;
    object _30210 = NOVALUE;
    object _30209 = NOVALUE;
    object _30205 = NOVALUE;
    object _30204 = NOVALUE;
    object _30203 = NOVALUE;
    object _30202 = NOVALUE;
    object _30201 = NOVALUE;
    object _30200 = NOVALUE;
    object _30197 = NOVALUE;
    object _30195 = NOVALUE;
    object _30194 = NOVALUE;
    object _30193 = NOVALUE;
    object _30192 = NOVALUE;
    object _30191 = NOVALUE;
    object _30188 = NOVALUE;
    object _30186 = NOVALUE;
    object _30184 = NOVALUE;
    object _30183 = NOVALUE;
    object _30182 = NOVALUE;
    object _30181 = NOVALUE;
    object _30180 = NOVALUE;
    object _30179 = NOVALUE;
    object _30178 = NOVALUE;
    object _30176 = NOVALUE;
    object _30173 = NOVALUE;
    object _30171 = NOVALUE;
    object _30170 = NOVALUE;
    object _30169 = NOVALUE;
    object _30168 = NOVALUE;
    object _30167 = NOVALUE;
    object _30166 = NOVALUE;
    object _30165 = NOVALUE;
    object _30164 = NOVALUE;
    object _30161 = NOVALUE;
    object _30160 = NOVALUE;
    object _30159 = NOVALUE;
    object _30157 = NOVALUE;
    object _30156 = NOVALUE;
    object _30155 = NOVALUE;
    object _30154 = NOVALUE;
    object _30153 = NOVALUE;
    object _30151 = NOVALUE;
    object _30150 = NOVALUE;
    object _30149 = NOVALUE;
    object _30147 = NOVALUE;
    object _30146 = NOVALUE;
    object _30144 = NOVALUE;
    object _30141 = NOVALUE;
    object _30139 = NOVALUE;
    object _30137 = NOVALUE;
    object _30129 = NOVALUE;
    object _30128 = NOVALUE;
    object _30126 = NOVALUE;
    object _30123 = NOVALUE;
    object _30116 = NOVALUE;
    object _30113 = NOVALUE;
    object _30112 = NOVALUE;
    object _30110 = NOVALUE;
    object _30106 = NOVALUE;
    object _30105 = NOVALUE;
    object _30104 = NOVALUE;
    object _30103 = NOVALUE;
    object _30102 = NOVALUE;
    object _30101 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_type_ptr_60507)) {
        _1 = (object)(DBL_PTR(_type_ptr_60507)->dbl);
        DeRefDS(_type_ptr_60507);
        _type_ptr_60507 = _1;
    }

    /** parser.e:3447		object tsym*/

    /** parser.e:3448		object prevtok = 0*/
    DeRef(_prevtok_60513);
    _prevtok_60513 = 0;

    /** parser.e:3450		integer h, count = 0*/
    _count_60518 = 0;

    /** parser.e:3451		atom val = 1, usedval*/
    DeRef(_val_60519);
    _val_60519 = 1;

    /** parser.e:3452		integer deltafunc = '+'*/
    _deltafunc_60521 = 43;

    /** parser.e:3453		atom delta = 1*/
    DeRef(_delta_60522);
    _delta_60522 = 1;

    /** parser.e:3455		new_symbols = {}*/
    RefDS(_22190);
    DeRefi(_new_symbols_60509);
    _new_symbols_60509 = _22190;

    /** parser.e:3456		integer is_fwd_ref = 0*/
    _is_fwd_ref_60523 = 0;

    /** parser.e:3457		if type_ptr > 0 and SymTab[type_ptr][S_SCOPE] = SC_UNDEFINED then*/
    _30101 = (_type_ptr_60507 > 0);
    if (_30101 == 0) {
        goto L1; // [50] 105
    }
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _30103 = (object)*(((s1_ptr)_2)->base + _type_ptr_60507);
    _2 = (object)SEQ_PTR(_30103);
    _30104 = (object)*(((s1_ptr)_2)->base + 4);
    _30103 = NOVALUE;
    if (IS_ATOM_INT(_30104)) {
        _30105 = (_30104 == 9);
    }
    else {
        _30105 = binary_op(EQUALS, _30104, 9);
    }
    _30104 = NOVALUE;
    if (_30105 == 0) {
        DeRef(_30105);
        _30105 = NOVALUE;
        goto L1; // [73] 105
    }
    else {
        if (!IS_ATOM_INT(_30105) && DBL_PTR(_30105)->dbl == 0.0){
            DeRef(_30105);
            _30105 = NOVALUE;
            goto L1; // [73] 105
        }
        DeRef(_30105);
        _30105 = NOVALUE;
    }
    DeRef(_30105);
    _30105 = NOVALUE;

    /** parser.e:3458			is_fwd_ref = 1*/
    _is_fwd_ref_60523 = 1;

    /** parser.e:3459			Hide(type_ptr)*/
    _54Hide(_type_ptr_60507);

    /** parser.e:3460			type_ptr = -new_forward_reference( TYPE, type_ptr )*/
    DeRef(_31958);
    _31958 = 504;
    _30106 = _44new_forward_reference(504, _type_ptr_60507, 504);
    _31958 = NOVALUE;
    if (IS_ATOM_INT(_30106)) {
        if ((uintptr_t)_30106 == (uintptr_t)HIGH_BITS){
            _type_ptr_60507 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _type_ptr_60507 = - _30106;
        }
    }
    else {
        _type_ptr_60507 = unary_op(UMINUS, _30106);
    }
    DeRef(_30106);
    _30106 = NOVALUE;
    if (!IS_ATOM_INT(_type_ptr_60507)) {
        _1 = (object)(DBL_PTR(_type_ptr_60507)->dbl);
        DeRefDS(_type_ptr_60507);
        _type_ptr_60507 = _1;
    }
L1: 

    /** parser.e:3463		if type_ptr = -1 then*/
    if (_type_ptr_60507 != -1)
    goto L2; // [107] 426

    /** parser.e:3465			sequence ptok = next_token()*/
    _0 = _ptok_60540;
    _ptok_60540 = _45next_token();
    DeRef(_0);

    /** parser.e:3466			if ptok[T_ID] = TYPE_DECL then*/
    _2 = (object)SEQ_PTR(_ptok_60540);
    _30110 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30110, 416)){
        _30110 = NOVALUE;
        goto L3; // [128] 172
    }
    _30110 = NOVALUE;

    /** parser.e:3469				putback(keyfind("enum",-1))*/
    RefDS(_26455);
    DeRef(_31956);
    _31956 = _26455;
    _31957 = _54hashfn(_31956);
    _31956 = NOVALUE;
    RefDS(_26455);
    _30112 = _54keyfind(_26455, -1, _36current_file_no_21767, 0, _31957);
    _31957 = NOVALUE;
    _45putback(_30112);
    _30112 = NOVALUE;

    /** parser.e:3470				SubProg(TYPE_DECL, scope, 0)*/
    _45SubProg(416, _scope_60508, 0);

    /** parser.e:3471				return {}*/
    RefDS(_22190);
    DeRefDS(_ptok_60540);
    DeRefi(_new_symbols_60509);
    DeRef(_tok_60511);
    DeRef(_tsym_60512);
    DeRef(_prevtok_60513);
    DeRef(_val_60519);
    DeRef(_usedval_60520);
    DeRef(_delta_60522);
    DeRef(_30101);
    _30101 = NOVALUE;
    return _22190;
    goto L4; // [169] 425
L3: 

    /** parser.e:3472			elsif ptok[T_ID] = BY then*/
    _2 = (object)SEQ_PTR(_ptok_60540);
    _30113 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30113, 404)){
        _30113 = NOVALUE;
        goto L5; // [182] 419
    }
    _30113 = NOVALUE;

    /** parser.e:3474				integer negate = 0*/
    _negate_60556 = 0;

    /** parser.e:3475				ptok = next_token()*/
    _0 = _ptok_60540;
    _ptok_60540 = _45next_token();
    DeRefDS(_0);

    /** parser.e:3476				switch ptok[T_ID] do*/
    _2 = (object)SEQ_PTR(_ptok_60540);
    _30116 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_30116) ){
        goto L6; // [206] 285
    }
    if(!IS_ATOM_INT(_30116)){
        if( (DBL_PTR(_30116)->dbl != (eudouble) ((object) DBL_PTR(_30116)->dbl) ) ){
            goto L6; // [206] 285
        }
        _0 = (object) DBL_PTR(_30116)->dbl;
    }
    else {
        _0 = _30116;
    };
    _30116 = NOVALUE;
    switch ( _0 ){ 

        /** parser.e:3477					case reserved:MULTIPLY then*/
        case 13:

        /** parser.e:3478						deltafunc = '*'*/
        _deltafunc_60521 = 42;

        /** parser.e:3479						ptok = next_token()*/
        _0 = _ptok_60540;
        _ptok_60540 = _45next_token();
        DeRef(_0);
        goto L7; // [227] 293

        /** parser.e:3481					case reserved:DIVIDE then*/
        case 14:

        /** parser.e:3482						deltafunc = '/'*/
        _deltafunc_60521 = 47;

        /** parser.e:3483						ptok = next_token()*/
        _0 = _ptok_60540;
        _ptok_60540 = _45next_token();
        DeRef(_0);
        goto L7; // [245] 293

        /** parser.e:3485					case MINUS then*/
        case 10:

        /** parser.e:3486						deltafunc = '-'*/
        _deltafunc_60521 = 45;

        /** parser.e:3487						ptok = next_token()*/
        _0 = _ptok_60540;
        _ptok_60540 = _45next_token();
        DeRef(_0);
        goto L7; // [263] 293

        /** parser.e:3489					case PLUS then*/
        case 11:

        /** parser.e:3490						deltafunc = '+'*/
        _deltafunc_60521 = 43;

        /** parser.e:3491						ptok = next_token()*/
        _0 = _ptok_60540;
        _ptok_60540 = _45next_token();
        DeRef(_0);
        goto L7; // [281] 293

        /** parser.e:3493					case else*/
        default:
L6: 

        /** parser.e:3494						deltafunc = '+'*/
        _deltafunc_60521 = 43;
    ;}L7: 

    /** parser.e:3498				if ptok[T_ID] = MINUS then*/
    _2 = (object)SEQ_PTR(_ptok_60540);
    _30123 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30123, 10)){
        _30123 = NOVALUE;
        goto L8; // [303] 320
    }
    _30123 = NOVALUE;

    /** parser.e:3499					negate = 1*/
    _negate_60556 = 1;

    /** parser.e:3500					ptok = next_token()*/
    _0 = _ptok_60540;
    _ptok_60540 = _45next_token();
    DeRefDS(_0);
L8: 

    /** parser.e:3502				if ptok[T_ID] != ATOM then*/
    _2 = (object)SEQ_PTR(_ptok_60540);
    _30126 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _30126, 502)){
        _30126 = NOVALUE;
        goto L9; // [330] 344
    }
    _30126 = NOVALUE;

    /** parser.e:3503					CompileErr( A_NUMERIC_LITERAL_WAS_EXPECTED)*/
    RefDS(_22190);
    _50CompileErr(344, _22190, 0);
L9: 

    /** parser.e:3506				delta = SymTab[ptok[T_SYM]][S_OBJ]*/
    _2 = (object)SEQ_PTR(_ptok_60540);
    _30128 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!IS_ATOM_INT(_30128)){
        _30129 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_30128)->dbl));
    }
    else{
        _30129 = (object)*(((s1_ptr)_2)->base + _30128);
    }
    DeRef(_delta_60522);
    _2 = (object)SEQ_PTR(_30129);
    _delta_60522 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_delta_60522);
    _30129 = NOVALUE;

    /** parser.e:3507				if negate then*/
    if (_negate_60556 == 0)
    {
        goto LA; // [366] 375
    }
    else{
    }

    /** parser.e:3508					delta = -delta*/
    _0 = _delta_60522;
    if (IS_ATOM_INT(_delta_60522)) {
        if ((uintptr_t)_delta_60522 == (uintptr_t)HIGH_BITS){
            _delta_60522 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _delta_60522 = - _delta_60522;
        }
    }
    else {
        _delta_60522 = unary_op(UMINUS, _delta_60522);
    }
    DeRef(_0);
LA: 

    /** parser.e:3511				switch deltafunc do*/
    _0 = _deltafunc_60521;
    switch ( _0 ){ 

        /** parser.e:3512					case '/' then*/
        case 47:

        /** parser.e:3513						delta = 1 / delta*/
        _0 = _delta_60522;
        if (IS_ATOM_INT(_delta_60522)) {
            _delta_60522 = (1 % _delta_60522) ? NewDouble((eudouble)1 / _delta_60522) : (1 / _delta_60522);
        }
        else {
            _delta_60522 = NewDouble((eudouble)1 / DBL_PTR(_delta_60522)->dbl);
        }
        DeRef(_0);

        /** parser.e:3514						deltafunc = '*'*/
        _deltafunc_60521 = 42;
        goto LB; // [397] 414

        /** parser.e:3516					case '-' then*/
        case 45:

        /** parser.e:3517						delta = -delta*/
        _0 = _delta_60522;
        if (IS_ATOM_INT(_delta_60522)) {
            if ((uintptr_t)_delta_60522 == (uintptr_t)HIGH_BITS){
                _delta_60522 = (object)NewDouble((eudouble) -HIGH_BITS);
            }
            else{
                _delta_60522 = - _delta_60522;
            }
        }
        else {
            _delta_60522 = unary_op(UMINUS, _delta_60522);
        }
        DeRef(_0);

        /** parser.e:3518						deltafunc = '+'*/
        _deltafunc_60521 = 43;
    ;}LB: 
    goto L4; // [416] 425
L5: 

    /** parser.e:3523				putback(ptok)*/
    RefDS(_ptok_60540);
    _45putback(_ptok_60540);
L4: 
L2: 
    DeRef(_ptok_60540);
    _ptok_60540 = NOVALUE;

    /** parser.e:3527		valsym = 0*/
    _valsym_60516 = 0;

    /** parser.e:3528		while TRUE do*/
LC: 
    if (_13TRUE_447 == 0)
    {
        goto LD; // [442] 2303
    }
    else{
    }

    /** parser.e:3529			tok = next_token()*/
    _0 = _tok_60511;
    _tok_60511 = _45next_token();
    DeRef(_0);

    /** parser.e:3530			if tok[T_ID] = DOLLAR then*/
    _2 = (object)SEQ_PTR(_tok_60511);
    _30137 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30137, -22)){
        _30137 = NOVALUE;
        goto LE; // [460] 499
    }
    _30137 = NOVALUE;

    /** parser.e:3531				if not equal(prevtok, 0) then*/
    if (_prevtok_60513 == 0)
    _30139 = 1;
    else if (IS_ATOM_INT(_prevtok_60513) && IS_ATOM_INT(0))
    _30139 = 0;
    else
    _30139 = (compare(_prevtok_60513, 0) == 0);
    if (_30139 != 0)
    goto LF; // [470] 498
    _30139 = NOVALUE;

    /** parser.e:3532					if prevtok[T_ID] = COMMA then*/
    _2 = (object)SEQ_PTR(_prevtok_60513);
    _30141 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30141, -30)){
        _30141 = NOVALUE;
        goto L10; // [483] 497
    }
    _30141 = NOVALUE;

    /** parser.e:3534						tok = next_token()*/
    _0 = _tok_60511;
    _tok_60511 = _45next_token();
    DeRef(_0);

    /** parser.e:3535						exit*/
    goto LD; // [494] 2303
L10: 
LF: 
LE: 

    /** parser.e:3539			if tok[T_ID] = END_OF_FILE then*/
    _2 = (object)SEQ_PTR(_tok_60511);
    _30144 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30144, -21)){
        _30144 = NOVALUE;
        goto L11; // [509] 523
    }
    _30144 = NOVALUE;

    /** parser.e:3540				CompileErr( AN_IDENTIFIER_IS_EXPECTED_HERE)*/
    RefDS(_22190);
    _50CompileErr(32, _22190, 0);
L11: 

    /** parser.e:3543			if not find(tok[T_ID], ADDR_TOKS) then*/
    _2 = (object)SEQ_PTR(_tok_60511);
    _30146 = (object)*(((s1_ptr)_2)->base + 1);
    _30147 = find_from(_30146, _38ADDR_TOKS_16295, 1);
    _30146 = NOVALUE;
    if (_30147 != 0)
    goto L12; // [538] 565
    _30147 = NOVALUE;

    /** parser.e:3544				CompileErr(FOUND__1__BUT_WAS_EXPECTING_AN_IDENTIFIER_NAME, {find_category(tok[T_ID])} )*/
    _2 = (object)SEQ_PTR(_tok_60511);
    _30149 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_30149);
    _30150 = _63find_category(_30149);
    _30149 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _30150;
    _30151 = MAKE_SEQ(_1);
    _30150 = NOVALUE;
    _50CompileErr(25, _30151, 0);
    _30151 = NOVALUE;
L12: 

    /** parser.e:3546			sym = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_60511);
    _sym_60515 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_sym_60515)){
        _sym_60515 = (object)DBL_PTR(_sym_60515)->dbl;
    }

    /** parser.e:3547			DefinedYet(sym)*/
    _54DefinedYet(_sym_60515);

    /** parser.e:3548			if find(SymTab[sym][S_SCOPE], {SC_GLOBAL, SC_PREDEF, SC_PUBLIC, SC_EXPORT}) then*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _30153 = (object)*(((s1_ptr)_2)->base + _sym_60515);
    _2 = (object)SEQ_PTR(_30153);
    _30154 = (object)*(((s1_ptr)_2)->base + 4);
    _30153 = NOVALUE;
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 6;
    ((intptr_t*)_2)[2] = 7;
    ((intptr_t*)_2)[3] = 13;
    ((intptr_t*)_2)[4] = 11;
    _30155 = MAKE_SEQ(_1);
    _30156 = find_from(_30154, _30155, 1);
    _30154 = NOVALUE;
    DeRefDS(_30155);
    _30155 = NOVALUE;
    if (_30156 == 0)
    {
        _30156 = NOVALUE;
        goto L13; // [614] 676
    }
    else{
        _30156 = NOVALUE;
    }

    /** parser.e:3549				h = SymTab[sym][S_HASHVAL]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _30157 = (object)*(((s1_ptr)_2)->base + _sym_60515);
    _2 = (object)SEQ_PTR(_30157);
    _h_60517 = (object)*(((s1_ptr)_2)->base + 11);
    if (!IS_ATOM_INT(_h_60517)){
        _h_60517 = (object)DBL_PTR(_h_60517)->dbl;
    }
    _30157 = NOVALUE;

    /** parser.e:3551				sym = NewEntry(SymTab[sym][S_NAME], 0, 0, VARIABLE, h, buckets[h], 0)*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _30159 = (object)*(((s1_ptr)_2)->base + _sym_60515);
    _2 = (object)SEQ_PTR(_30159);
    if (!IS_ATOM_INT(_36S_NAME_21404)){
        _30160 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21404)->dbl));
    }
    else{
        _30160 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21404);
    }
    _30159 = NOVALUE;
    _2 = (object)SEQ_PTR(_54buckets_47132);
    _30161 = (object)*(((s1_ptr)_2)->base + _h_60517);
    Ref(_30160);
    Ref(_30161);
    _sym_60515 = _54NewEntry(_30160, 0, 0, -100, _h_60517, _30161, 0);
    _30160 = NOVALUE;
    _30161 = NOVALUE;
    if (!IS_ATOM_INT(_sym_60515)) {
        _1 = (object)(DBL_PTR(_sym_60515)->dbl);
        DeRefDS(_sym_60515);
        _sym_60515 = _1;
    }

    /** parser.e:3552				buckets[h] = sym*/
    _2 = (object)SEQ_PTR(_54buckets_47132);
    _2 = (object)(((s1_ptr)_2)->base + _h_60517);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _sym_60515;
    DeRef(_1);
L13: 

    /** parser.e:3555			new_symbols = append(new_symbols, sym)*/
    Append(&_new_symbols_60509, _new_symbols_60509, _sym_60515);

    /** parser.e:3556			Block_var( sym )*/
    _65Block_var(_sym_60515);

    /** parser.e:3557			if SymTab[sym][S_SCOPE] = SC_UNDEFINED and SymTab[sym][S_FILE_NO] != current_file_no then*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _30164 = (object)*(((s1_ptr)_2)->base + _sym_60515);
    _2 = (object)SEQ_PTR(_30164);
    _30165 = (object)*(((s1_ptr)_2)->base + 4);
    _30164 = NOVALUE;
    if (IS_ATOM_INT(_30165)) {
        _30166 = (_30165 == 9);
    }
    else {
        _30166 = binary_op(EQUALS, _30165, 9);
    }
    _30165 = NOVALUE;
    if (IS_ATOM_INT(_30166)) {
        if (_30166 == 0) {
            goto L14; // [707] 751
        }
    }
    else {
        if (DBL_PTR(_30166)->dbl == 0.0) {
            goto L14; // [707] 751
        }
    }
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _30168 = (object)*(((s1_ptr)_2)->base + _sym_60515);
    _2 = (object)SEQ_PTR(_30168);
    if (!IS_ATOM_INT(_36S_FILE_NO_21400)){
        _30169 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21400)->dbl));
    }
    else{
        _30169 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21400);
    }
    _30168 = NOVALUE;
    if (IS_ATOM_INT(_30169)) {
        _30170 = (_30169 != _36current_file_no_21767);
    }
    else {
        _30170 = binary_op(NOTEQ, _30169, _36current_file_no_21767);
    }
    _30169 = NOVALUE;
    if (_30170 == 0) {
        DeRef(_30170);
        _30170 = NOVALUE;
        goto L14; // [730] 751
    }
    else {
        if (!IS_ATOM_INT(_30170) && DBL_PTR(_30170)->dbl == 0.0){
            DeRef(_30170);
            _30170 = NOVALUE;
            goto L14; // [730] 751
        }
        DeRef(_30170);
        _30170 = NOVALUE;
    }
    DeRef(_30170);
    _30170 = NOVALUE;

    /** parser.e:3558				SymTab[sym][S_FILE_NO] = current_file_no*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60515 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_FILE_NO_21400))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21400)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_FILE_NO_21400);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36current_file_no_21767;
    DeRef(_1);
    _30171 = NOVALUE;
L14: 

    /** parser.e:3560			SymTab[sym][S_SCOPE] = scope*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60515 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _scope_60508;
    DeRef(_1);
    _30173 = NOVALUE;

    /** parser.e:3562			if type_ptr = 0 then*/
    if (_type_ptr_60507 != 0)
    goto L15; // [768] 1103

    /** parser.e:3564				SymTab[sym][S_MODE] = M_CONSTANT*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60515 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2;
    DeRef(_1);
    _30176 = NOVALUE;

    /** parser.e:3566				buckets[SymTab[sym][S_HASHVAL]] = SymTab[sym][S_SAMEHASH]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _30178 = (object)*(((s1_ptr)_2)->base + _sym_60515);
    _2 = (object)SEQ_PTR(_30178);
    _30179 = (object)*(((s1_ptr)_2)->base + 11);
    _30178 = NOVALUE;
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _30180 = (object)*(((s1_ptr)_2)->base + _sym_60515);
    _2 = (object)SEQ_PTR(_30180);
    _30181 = (object)*(((s1_ptr)_2)->base + 9);
    _30180 = NOVALUE;
    Ref(_30181);
    _2 = (object)SEQ_PTR(_54buckets_47132);
    if (!IS_ATOM_INT(_30179))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_30179)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _30179);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30181;
    if( _1 != _30181 ){
        DeRef(_1);
    }
    _30181 = NOVALUE;

    /** parser.e:3567				tok_match(EQUALS)*/
    _45tok_match(3, 0);

    /** parser.e:3568				StartSourceLine(FALSE, , COVERAGE_OVERRIDE)*/
    _47StartSourceLine(_13FALSE_445, 0, 3);

    /** parser.e:3569				emit_opnd(sym)*/
    _47emit_opnd(_sym_60515);

    /** parser.e:3570				Expr()  -- no new symbols can be defined in here*/
    _45Expr();

    /** parser.e:3571				buckets[SymTab[sym][S_HASHVAL]] = sym*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _30182 = (object)*(((s1_ptr)_2)->base + _sym_60515);
    _2 = (object)SEQ_PTR(_30182);
    _30183 = (object)*(((s1_ptr)_2)->base + 11);
    _30182 = NOVALUE;
    _2 = (object)SEQ_PTR(_54buckets_47132);
    if (!IS_ATOM_INT(_30183))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_30183)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _30183);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _sym_60515;
    DeRef(_1);

    /** parser.e:3572				SymTab[sym][S_USAGE] = U_WRITTEN*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60515 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2;
    DeRef(_1);
    _30184 = NOVALUE;

    /** parser.e:3573				if TRANSLATE then*/
    if (_36TRANSLATE_21369 == 0)
    {
        goto L16; // [890] 928
    }
    else{
    }

    /** parser.e:3574					SymTab[sym][S_GTYPE] = TYPE_OBJECT*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60515 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 16;
    DeRef(_1);
    _30186 = NOVALUE;

    /** parser.e:3575					SymTab[sym][S_OBJ] = NOVALUE     -- distinguish from literals*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60515 + ((s1_ptr)_2)->base);
    Ref(_36NOVALUE_21621);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36NOVALUE_21621;
    DeRef(_1);
    _30188 = NOVALUE;
L16: 

    /** parser.e:3577				valsym = Top()*/
    _valsym_60516 = _47Top();
    if (!IS_ATOM_INT(_valsym_60516)) {
        _1 = (object)(DBL_PTR(_valsym_60516)->dbl);
        DeRefDS(_valsym_60516);
        _valsym_60516 = _1;
    }

    /** parser.e:3579				if valsym > 0 and compare( SymTab[valsym][S_OBJ], NOVALUE ) then*/
    _30191 = (_valsym_60516 > 0);
    if (_30191 == 0) {
        goto L17; // [941] 982
    }
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _30193 = (object)*(((s1_ptr)_2)->base + _valsym_60516);
    _2 = (object)SEQ_PTR(_30193);
    _30194 = (object)*(((s1_ptr)_2)->base + 1);
    _30193 = NOVALUE;
    if (IS_ATOM_INT(_30194) && IS_ATOM_INT(_36NOVALUE_21621)){
        _30195 = (_30194 < _36NOVALUE_21621) ? -1 : (_30194 > _36NOVALUE_21621);
    }
    else{
        _30195 = compare(_30194, _36NOVALUE_21621);
    }
    _30194 = NOVALUE;
    if (_30195 == 0)
    {
        _30195 = NOVALUE;
        goto L17; // [964] 982
    }
    else{
        _30195 = NOVALUE;
    }

    /** parser.e:3580					Assign_Constant( sym )*/
    _45Assign_Constant(_sym_60515);

    /** parser.e:3581					sym = Pop()*/
    _sym_60515 = _47Pop();
    if (!IS_ATOM_INT(_sym_60515)) {
        _1 = (object)(DBL_PTR(_sym_60515)->dbl);
        DeRefDS(_sym_60515);
        _sym_60515 = _1;
    }
    goto L18; // [979] 2269
L17: 

    /** parser.e:3584					emit_op(ASSIGN)*/
    _47emit_op(18);

    /** parser.e:3585					if Last_op() = ASSIGN then*/
    _30197 = _47Last_op();
    if (binary_op_a(NOTEQ, _30197, 18)){
        DeRef(_30197);
        _30197 = NOVALUE;
        goto L19; // [996] 1010
    }
    DeRef(_30197);
    _30197 = NOVALUE;

    /** parser.e:3586						valsym = get_assigned_sym()*/
    _valsym_60516 = _45get_assigned_sym();
    if (!IS_ATOM_INT(_valsym_60516)) {
        _1 = (object)(DBL_PTR(_valsym_60516)->dbl);
        DeRefDS(_valsym_60516);
        _valsym_60516 = _1;
    }
    goto L1A; // [1007] 1018
L19: 

    /** parser.e:3589						valsym = -1*/
    _valsym_60516 = -1;
L1A: 

    /** parser.e:3591					if valsym > 0 and compare( SymTab[valsym][S_OBJ], NOVALUE ) then*/
    _30200 = (_valsym_60516 > 0);
    if (_30200 == 0) {
        goto L1B; // [1024] 1066
    }
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _30202 = (object)*(((s1_ptr)_2)->base + _valsym_60516);
    _2 = (object)SEQ_PTR(_30202);
    _30203 = (object)*(((s1_ptr)_2)->base + 1);
    _30202 = NOVALUE;
    if (IS_ATOM_INT(_30203) && IS_ATOM_INT(_36NOVALUE_21621)){
        _30204 = (_30203 < _36NOVALUE_21621) ? -1 : (_30203 > _36NOVALUE_21621);
    }
    else{
        _30204 = compare(_30203, _36NOVALUE_21621);
    }
    _30203 = NOVALUE;
    if (_30204 == 0)
    {
        _30204 = NOVALUE;
        goto L1B; // [1047] 1066
    }
    else{
        _30204 = NOVALUE;
    }

    /** parser.e:3593						SymTab[sym][S_CODE] = valsym*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60515 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_CODE_21416))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21416)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_CODE_21416);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _valsym_60516;
    DeRef(_1);
    _30205 = NOVALUE;
L1B: 

    /** parser.e:3596					if TRANSLATE then*/
    if (_36TRANSLATE_21369 == 0)
    {
        goto L18; // [1070] 2269
    }
    else{
    }

    /** parser.e:3597						count += 1*/
    _count_60518 = _count_60518 + 1;

    /** parser.e:3598						if count = 10 then*/
    if (_count_60518 != 10)
    goto L18; // [1081] 2269

    /** parser.e:3599							count = 0*/
    _count_60518 = 0;

    /** parser.e:3601							emit_op( RETURNT )*/
    _47emit_op(34);
    goto L18; // [1100] 2269
L15: 

    /** parser.e:3606			elsif type_ptr = -1 and not is_fwd_ref then*/
    _30209 = (_type_ptr_60507 == -1);
    if (_30209 == 0) {
        goto L1C; // [1109] 2096
    }
    _30211 = (_is_fwd_ref_60523 == 0);
    if (_30211 == 0)
    {
        DeRef(_30211);
        _30211 = NOVALUE;
        goto L1C; // [1117] 2096
    }
    else{
        DeRef(_30211);
        _30211 = NOVALUE;
    }

    /** parser.e:3608				StartSourceLine(FALSE, , COVERAGE_OVERRIDE )*/
    _47StartSourceLine(_13FALSE_445, 0, 3);

    /** parser.e:3609				SymTab[sym][S_MODE] = M_CONSTANT*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60515 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2;
    DeRef(_1);
    _30212 = NOVALUE;

    /** parser.e:3611				buckets[SymTab[sym][S_HASHVAL]] = SymTab[sym][S_SAMEHASH]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _30214 = (object)*(((s1_ptr)_2)->base + _sym_60515);
    _2 = (object)SEQ_PTR(_30214);
    _30215 = (object)*(((s1_ptr)_2)->base + 11);
    _30214 = NOVALUE;
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _30216 = (object)*(((s1_ptr)_2)->base + _sym_60515);
    _2 = (object)SEQ_PTR(_30216);
    _30217 = (object)*(((s1_ptr)_2)->base + 9);
    _30216 = NOVALUE;
    Ref(_30217);
    _2 = (object)SEQ_PTR(_54buckets_47132);
    if (!IS_ATOM_INT(_30215))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_30215)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _30215);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30217;
    if( _1 != _30217 ){
        DeRef(_1);
    }
    _30217 = NOVALUE;

    /** parser.e:3612				tok = next_token()*/
    _0 = _tok_60511;
    _tok_60511 = _45next_token();
    DeRef(_0);

    /** parser.e:3615				emit_opnd(sym)*/
    _47emit_opnd(_sym_60515);

    /** parser.e:3617				if tok[T_ID] = EQUALS then*/
    _2 = (object)SEQ_PTR(_tok_60511);
    _30219 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30219, 3)){
        _30219 = NOVALUE;
        goto L1D; // [1200] 1607
    }
    _30219 = NOVALUE;

    /** parser.e:3618					integer negate = 1*/
    _negate_60805 = 1;

    /** parser.e:3620					tok = next_token()*/
    _0 = _tok_60511;
    _tok_60511 = _45next_token();
    DeRef(_0);

    /** parser.e:3621					if tok[T_ID] = MINUS then*/
    _2 = (object)SEQ_PTR(_tok_60511);
    _30222 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30222, 10)){
        _30222 = NOVALUE;
        goto L1E; // [1224] 1239
    }
    _30222 = NOVALUE;

    /** parser.e:3622						negate = -1*/
    _negate_60805 = -1;

    /** parser.e:3623						tok = next_token()*/
    _0 = _tok_60511;
    _tok_60511 = _45next_token();
    DeRef(_0);
L1E: 

    /** parser.e:3626					if tok[T_ID] = ATOM then*/
    _2 = (object)SEQ_PTR(_tok_60511);
    _30225 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30225, 502)){
        _30225 = NOVALUE;
        goto L1F; // [1249] 1266
    }
    _30225 = NOVALUE;

    /** parser.e:3627						valsym = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_60511);
    _valsym_60516 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_valsym_60516)){
        _valsym_60516 = (object)DBL_PTR(_valsym_60516)->dbl;
    }
    goto L20; // [1263] 1464
L1F: 

    /** parser.e:3628					elsif tok[T_SYM] > 0 then*/
    _2 = (object)SEQ_PTR(_tok_60511);
    _30228 = (object)*(((s1_ptr)_2)->base + 2);
    if (binary_op_a(LESSEQ, _30228, 0)){
        _30228 = NOVALUE;
        goto L21; // [1274] 1454
    }
    _30228 = NOVALUE;

    /** parser.e:3629						tsym = SymTab[tok[T_SYM]]*/
    _2 = (object)SEQ_PTR(_tok_60511);
    _30230 = (object)*(((s1_ptr)_2)->base + 2);
    DeRef(_tsym_60512);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!IS_ATOM_INT(_30230)){
        _tsym_60512 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_30230)->dbl));
    }
    else{
        _tsym_60512 = (object)*(((s1_ptr)_2)->base + _30230);
    }
    Ref(_tsym_60512);

    /** parser.e:3630						if tsym[S_MODE] = M_CONSTANT then*/
    _2 = (object)SEQ_PTR(_tsym_60512);
    _30232 = (object)*(((s1_ptr)_2)->base + 3);
    if (binary_op_a(NOTEQ, _30232, 2)){
        _30232 = NOVALUE;
        goto L22; // [1302] 1415
    }
    _30232 = NOVALUE;

    /** parser.e:3631							if length(tsym) >= S_CODE and tsym[S_CODE] then*/
    if (IS_SEQUENCE(_tsym_60512)){
            _30234 = SEQ_PTR(_tsym_60512)->length;
    }
    else {
        _30234 = 1;
    }
    if (IS_ATOM_INT(_36S_CODE_21416)) {
        _30235 = (_30234 >= _36S_CODE_21416);
    }
    else {
        _30235 = binary_op(GREATEREQ, _30234, _36S_CODE_21416);
    }
    _30234 = NOVALUE;
    if (IS_ATOM_INT(_30235)) {
        if (_30235 == 0) {
            goto L23; // [1317] 1344
        }
    }
    else {
        if (DBL_PTR(_30235)->dbl == 0.0) {
            goto L23; // [1317] 1344
        }
    }
    _2 = (object)SEQ_PTR(_tsym_60512);
    if (!IS_ATOM_INT(_36S_CODE_21416)){
        _30237 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21416)->dbl));
    }
    else{
        _30237 = (object)*(((s1_ptr)_2)->base + _36S_CODE_21416);
    }
    if (_30237 == 0) {
        _30237 = NOVALUE;
        goto L23; // [1328] 1344
    }
    else {
        if (!IS_ATOM_INT(_30237) && DBL_PTR(_30237)->dbl == 0.0){
            _30237 = NOVALUE;
            goto L23; // [1328] 1344
        }
        _30237 = NOVALUE;
    }
    _30237 = NOVALUE;

    /** parser.e:3632								valsym = tsym[S_CODE]*/
    _2 = (object)SEQ_PTR(_tsym_60512);
    if (!IS_ATOM_INT(_36S_CODE_21416)){
        _valsym_60516 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21416)->dbl));
    }
    else{
        _valsym_60516 = (object)*(((s1_ptr)_2)->base + _36S_CODE_21416);
    }
    if (!IS_ATOM_INT(_valsym_60516)){
        _valsym_60516 = (object)DBL_PTR(_valsym_60516)->dbl;
    }
    goto L20; // [1341] 1464
L23: 

    /** parser.e:3634							elsif not equal( tsym[S_OBJ], NOVALUE ) then*/
    _2 = (object)SEQ_PTR(_tsym_60512);
    _30239 = (object)*(((s1_ptr)_2)->base + 1);
    if (_30239 == _36NOVALUE_21621)
    _30240 = 1;
    else if (IS_ATOM_INT(_30239) && IS_ATOM_INT(_36NOVALUE_21621))
    _30240 = 0;
    else
    _30240 = (compare(_30239, _36NOVALUE_21621) == 0);
    _30239 = NOVALUE;
    if (_30240 != 0)
    goto L24; // [1358] 1402
    _30240 = NOVALUE;

    /** parser.e:3635								if is_integer(tsym[S_OBJ]) then*/
    _2 = (object)SEQ_PTR(_tsym_60512);
    _30242 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_30242);
    _30243 = _36is_integer(_30242);
    _30242 = NOVALUE;
    if (_30243 == 0) {
        DeRef(_30243);
        _30243 = NOVALUE;
        goto L25; // [1373] 1389
    }
    else {
        if (!IS_ATOM_INT(_30243) && DBL_PTR(_30243)->dbl == 0.0){
            DeRef(_30243);
            _30243 = NOVALUE;
            goto L25; // [1373] 1389
        }
        DeRef(_30243);
        _30243 = NOVALUE;
    }
    DeRef(_30243);
    _30243 = NOVALUE;

    /** parser.e:3636									valsym = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_60511);
    _valsym_60516 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_valsym_60516)){
        _valsym_60516 = (object)DBL_PTR(_valsym_60516)->dbl;
    }
    goto L20; // [1386] 1464
L25: 

    /** parser.e:3638									CompileErr(AN_ENUM_CONSTANT_MUST_BE_AN_INTEGER)*/
    RefDS(_22190);
    _50CompileErr(30, _22190, 0);
    goto L20; // [1399] 1464
L24: 

    /** parser.e:3641								CompileErr(ENUM_CONSTANTS_MUST_BE_ASSIGNED_AN_INTEGER)*/
    RefDS(_22190);
    _50CompileErr(70, _22190, 0);
    goto L20; // [1412] 1464
L22: 

    /** parser.e:3643						elsif tsym[S_OBJ] = NOVALUE then*/
    _2 = (object)SEQ_PTR(_tsym_60512);
    _30245 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30245, _36NOVALUE_21621)){
        _30245 = NOVALUE;
        goto L26; // [1425] 1441
    }
    _30245 = NOVALUE;

    /** parser.e:3645							CompileErr(ENUM_FWD_REFERENCES_NOT_SUPPORTED)*/
    RefDS(_22190);
    _50CompileErr(331, _22190, 0);
    goto L20; // [1438] 1464
L26: 

    /** parser.e:3647							CompileErr(INTEGER_OR_CONSTANT_EXPECTED)*/
    RefDS(_22190);
    _50CompileErr(99, _22190, 0);
    goto L20; // [1451] 1464
L21: 

    /** parser.e:3651							CompileErr(INTEGER_OR_CONSTANT_EXPECTED)*/
    RefDS(_22190);
    _50CompileErr(99, _22190, 0);
L20: 

    /** parser.e:3653					valsym = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_60511);
    _valsym_60516 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_valsym_60516)){
        _valsym_60516 = (object)DBL_PTR(_valsym_60516)->dbl;
    }

    /** parser.e:3654					if not atom( SymTab[valsym][S_OBJ] ) and tsym[S_SCOPE] != SC_UNDEFINED then*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _30248 = (object)*(((s1_ptr)_2)->base + _valsym_60516);
    _2 = (object)SEQ_PTR(_30248);
    _30249 = (object)*(((s1_ptr)_2)->base + 1);
    _30248 = NOVALUE;
    _30250 = IS_ATOM(_30249);
    _30249 = NOVALUE;
    _30251 = (_30250 == 0);
    _30250 = NOVALUE;
    if (_30251 == 0) {
        goto L27; // [1494] 1526
    }
    _2 = (object)SEQ_PTR(_tsym_60512);
    _30253 = (object)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_30253)) {
        _30254 = (_30253 != 9);
    }
    else {
        _30254 = binary_op(NOTEQ, _30253, 9);
    }
    _30253 = NOVALUE;
    if (_30254 == 0) {
        DeRef(_30254);
        _30254 = NOVALUE;
        goto L27; // [1513] 1526
    }
    else {
        if (!IS_ATOM_INT(_30254) && DBL_PTR(_30254)->dbl == 0.0){
            DeRef(_30254);
            _30254 = NOVALUE;
            goto L27; // [1513] 1526
        }
        DeRef(_30254);
        _30254 = NOVALUE;
    }
    DeRef(_30254);
    _30254 = NOVALUE;

    /** parser.e:3655						CompileErr(ENUM_CONSTANTS_MUST_BE_INTEGERS)*/
    RefDS(_22190);
    _50CompileErr(84, _22190, 0);
L27: 

    /** parser.e:3657					val = SymTab[valsym][S_OBJ] * negate*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _30255 = (object)*(((s1_ptr)_2)->base + _valsym_60516);
    _2 = (object)SEQ_PTR(_30255);
    _30256 = (object)*(((s1_ptr)_2)->base + 1);
    _30255 = NOVALUE;
    DeRef(_val_60519);
    if (IS_ATOM_INT(_30256)) {
        if (_30256 == (short)_30256 && _negate_60805 <= INT15 && _negate_60805 >= -INT15){
            _val_60519 = _30256 * _negate_60805;
        }
        else{
            _val_60519 = NewDouble(_30256 * (eudouble)_negate_60805);
        }
    }
    else {
        _val_60519 = binary_op(MULTIPLY, _30256, _negate_60805);
    }
    _30256 = NOVALUE;

    /** parser.e:3658					if is_integer(val) then*/
    Ref(_val_60519);
    _30258 = _36is_integer(_val_60519);
    if (_30258 == 0) {
        DeRef(_30258);
        _30258 = NOVALUE;
        goto L28; // [1550] 1565
    }
    else {
        if (!IS_ATOM_INT(_30258) && DBL_PTR(_30258)->dbl == 0.0){
            DeRef(_30258);
            _30258 = NOVALUE;
            goto L28; // [1550] 1565
        }
        DeRef(_30258);
        _30258 = NOVALUE;
    }
    DeRef(_30258);
    _30258 = NOVALUE;

    /** parser.e:3659						Push(NewIntSym(val))*/
    Ref(_val_60519);
    _30259 = _54NewIntSym(_val_60519);
    _47Push(_30259);
    _30259 = NOVALUE;
    goto L29; // [1562] 1575
L28: 

    /** parser.e:3661						Push(NewDoubleSym(val))*/
    Ref(_val_60519);
    _30260 = _54NewDoubleSym(_val_60519);
    _47Push(_30260);
    _30260 = NOVALUE;
L29: 

    /** parser.e:3663					usedval = val*/
    Ref(_val_60519);
    DeRef(_usedval_60520);
    _usedval_60520 = _val_60519;

    /** parser.e:3664					if deltafunc = '+' then*/
    if (_deltafunc_60521 != 43)
    goto L2A; // [1582] 1595

    /** parser.e:3665						val += delta*/
    _0 = _val_60519;
    if (IS_ATOM_INT(_val_60519) && IS_ATOM_INT(_delta_60522)) {
        _val_60519 = _val_60519 + _delta_60522;
        if ((object)((uintptr_t)_val_60519 + (uintptr_t)HIGH_BITS) >= 0){
            _val_60519 = NewDouble((eudouble)_val_60519);
        }
    }
    else {
        if (IS_ATOM_INT(_val_60519)) {
            _val_60519 = NewDouble((eudouble)_val_60519 + DBL_PTR(_delta_60522)->dbl);
        }
        else {
            if (IS_ATOM_INT(_delta_60522)) {
                _val_60519 = NewDouble(DBL_PTR(_val_60519)->dbl + (eudouble)_delta_60522);
            }
            else
            _val_60519 = NewDouble(DBL_PTR(_val_60519)->dbl + DBL_PTR(_delta_60522)->dbl);
        }
    }
    DeRef(_0);
    goto L2B; // [1592] 1602
L2A: 

    /** parser.e:3667						val *= delta*/
    _0 = _val_60519;
    if (IS_ATOM_INT(_val_60519) && IS_ATOM_INT(_delta_60522)) {
        if (_val_60519 == (short)_val_60519 && _delta_60522 <= INT15 && _delta_60522 >= -INT15){
            _val_60519 = _val_60519 * _delta_60522;
        }
        else{
            _val_60519 = NewDouble(_val_60519 * (eudouble)_delta_60522);
        }
    }
    else {
        if (IS_ATOM_INT(_val_60519)) {
            _val_60519 = NewDouble((eudouble)_val_60519 * DBL_PTR(_delta_60522)->dbl);
        }
        else {
            if (IS_ATOM_INT(_delta_60522)) {
                _val_60519 = NewDouble(DBL_PTR(_val_60519)->dbl * (eudouble)_delta_60522);
            }
            else
            _val_60519 = NewDouble(DBL_PTR(_val_60519)->dbl * DBL_PTR(_delta_60522)->dbl);
        }
    }
    DeRef(_0);
L2B: 
    goto L2C; // [1604] 1678
L1D: 

    /** parser.e:3670					putback(tok)*/
    Ref(_tok_60511);
    _45putback(_tok_60511);

    /** parser.e:3671					if is_integer(val) then*/
    Ref(_val_60519);
    _30264 = _36is_integer(_val_60519);
    if (_30264 == 0) {
        DeRef(_30264);
        _30264 = NOVALUE;
        goto L2D; // [1618] 1633
    }
    else {
        if (!IS_ATOM_INT(_30264) && DBL_PTR(_30264)->dbl == 0.0){
            DeRef(_30264);
            _30264 = NOVALUE;
            goto L2D; // [1618] 1633
        }
        DeRef(_30264);
        _30264 = NOVALUE;
    }
    DeRef(_30264);
    _30264 = NOVALUE;

    /** parser.e:3672						Push(NewIntSym(val))*/
    Ref(_val_60519);
    _30265 = _54NewIntSym(_val_60519);
    _47Push(_30265);
    _30265 = NOVALUE;
    goto L2E; // [1630] 1643
L2D: 

    /** parser.e:3674						Push(NewDoubleSym(val))*/
    Ref(_val_60519);
    _30266 = _54NewDoubleSym(_val_60519);
    _47Push(_30266);
    _30266 = NOVALUE;
L2E: 

    /** parser.e:3676					usedval = val*/
    Ref(_val_60519);
    DeRef(_usedval_60520);
    _usedval_60520 = _val_60519;

    /** parser.e:3677					if deltafunc = '+' then*/
    if (_deltafunc_60521 != 43)
    goto L2F; // [1650] 1663

    /** parser.e:3678						val += delta*/
    _0 = _val_60519;
    if (IS_ATOM_INT(_val_60519) && IS_ATOM_INT(_delta_60522)) {
        _val_60519 = _val_60519 + _delta_60522;
        if ((object)((uintptr_t)_val_60519 + (uintptr_t)HIGH_BITS) >= 0){
            _val_60519 = NewDouble((eudouble)_val_60519);
        }
    }
    else {
        if (IS_ATOM_INT(_val_60519)) {
            _val_60519 = NewDouble((eudouble)_val_60519 + DBL_PTR(_delta_60522)->dbl);
        }
        else {
            if (IS_ATOM_INT(_delta_60522)) {
                _val_60519 = NewDouble(DBL_PTR(_val_60519)->dbl + (eudouble)_delta_60522);
            }
            else
            _val_60519 = NewDouble(DBL_PTR(_val_60519)->dbl + DBL_PTR(_delta_60522)->dbl);
        }
    }
    DeRef(_0);
    goto L30; // [1660] 1670
L2F: 

    /** parser.e:3680						val *= delta*/
    _0 = _val_60519;
    if (IS_ATOM_INT(_val_60519) && IS_ATOM_INT(_delta_60522)) {
        if (_val_60519 == (short)_val_60519 && _delta_60522 <= INT15 && _delta_60522 >= -INT15){
            _val_60519 = _val_60519 * _delta_60522;
        }
        else{
            _val_60519 = NewDouble(_val_60519 * (eudouble)_delta_60522);
        }
    }
    else {
        if (IS_ATOM_INT(_val_60519)) {
            _val_60519 = NewDouble((eudouble)_val_60519 * DBL_PTR(_delta_60522)->dbl);
        }
        else {
            if (IS_ATOM_INT(_delta_60522)) {
                _val_60519 = NewDouble(DBL_PTR(_val_60519)->dbl * (eudouble)_delta_60522);
            }
            else
            _val_60519 = NewDouble(DBL_PTR(_val_60519)->dbl * DBL_PTR(_delta_60522)->dbl);
        }
    }
    DeRef(_0);
L30: 

    /** parser.e:3682					valsym = 0*/
    _valsym_60516 = 0;
L2C: 

    /** parser.e:3684				buckets[SymTab[sym][S_HASHVAL]] = sym*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _30270 = (object)*(((s1_ptr)_2)->base + _sym_60515);
    _2 = (object)SEQ_PTR(_30270);
    _30271 = (object)*(((s1_ptr)_2)->base + 11);
    _30270 = NOVALUE;
    _2 = (object)SEQ_PTR(_54buckets_47132);
    if (!IS_ATOM_INT(_30271))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_30271)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _30271);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _sym_60515;
    DeRef(_1);

    /** parser.e:3685				SymTab[sym][S_USAGE] = U_WRITTEN*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60515 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2;
    DeRef(_1);
    _30272 = NOVALUE;

    /** parser.e:3687				if TRANSLATE then*/
    if (_36TRANSLATE_21369 == 0)
    {
        goto L31; // [1719] 1757
    }
    else{
    }

    /** parser.e:3688					SymTab[sym][S_GTYPE] = TYPE_OBJECT*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60515 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 16;
    DeRef(_1);
    _30274 = NOVALUE;

    /** parser.e:3689					SymTab[sym][S_OBJ] = NOVALUE     -- distinguish from literals*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60515 + ((s1_ptr)_2)->base);
    Ref(_36NOVALUE_21621);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36NOVALUE_21621;
    DeRef(_1);
    _30276 = NOVALUE;
L31: 

    /** parser.e:3692				if valsym < 0 then*/
    if (_valsym_60516 >= 0)
    goto L32; // [1759] 1764
L32: 

    /** parser.e:3697				if valsym and compare( SymTab[valsym][S_OBJ], NOVALUE ) then*/
    if (_valsym_60516 == 0) {
        goto L33; // [1766] 1946
    }
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _30280 = (object)*(((s1_ptr)_2)->base + _valsym_60516);
    _2 = (object)SEQ_PTR(_30280);
    _30281 = (object)*(((s1_ptr)_2)->base + 1);
    _30280 = NOVALUE;
    if (IS_ATOM_INT(_30281) && IS_ATOM_INT(_36NOVALUE_21621)){
        _30282 = (_30281 < _36NOVALUE_21621) ? -1 : (_30281 > _36NOVALUE_21621);
    }
    else{
        _30282 = compare(_30281, _36NOVALUE_21621);
    }
    _30281 = NOVALUE;
    if (_30282 == 0)
    {
        _30282 = NOVALUE;
        goto L33; // [1789] 1946
    }
    else{
        _30282 = NOVALUE;
    }

    /** parser.e:3699					SymTab[sym][S_CODE] = valsym*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60515 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_CODE_21416))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21416)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_CODE_21416);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _valsym_60516;
    DeRef(_1);
    _30283 = NOVALUE;

    /** parser.e:3700					SymTab[sym][S_OBJ]  = usedval*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60515 + ((s1_ptr)_2)->base);
    Ref(_usedval_60520);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _usedval_60520;
    DeRef(_1);
    _30285 = NOVALUE;

    /** parser.e:3702					if TRANSLATE then*/
    if (_36TRANSLATE_21369 == 0)
    {
        goto L34; // [1828] 2079
    }
    else{
    }

    /** parser.e:3704						SymTab[sym][S_GTYPE] = SymTab[valsym][S_GTYPE]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60515 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _30289 = (object)*(((s1_ptr)_2)->base + _valsym_60516);
    _2 = (object)SEQ_PTR(_30289);
    _30290 = (object)*(((s1_ptr)_2)->base + 36);
    _30289 = NOVALUE;
    Ref(_30290);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30290;
    if( _1 != _30290 ){
        DeRef(_1);
    }
    _30290 = NOVALUE;
    _30287 = NOVALUE;

    /** parser.e:3705						SymTab[sym][S_SEQ_ELEM] = SymTab[valsym][S_SEQ_ELEM]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60515 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _30293 = (object)*(((s1_ptr)_2)->base + _valsym_60516);
    _2 = (object)SEQ_PTR(_30293);
    _30294 = (object)*(((s1_ptr)_2)->base + 33);
    _30293 = NOVALUE;
    Ref(_30294);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30294;
    if( _1 != _30294 ){
        DeRef(_1);
    }
    _30294 = NOVALUE;
    _30291 = NOVALUE;

    /** parser.e:3706						SymTab[sym][S_OBJ_MIN] = usedval*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60515 + ((s1_ptr)_2)->base);
    Ref(_usedval_60520);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 30);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _usedval_60520;
    DeRef(_1);
    _30295 = NOVALUE;

    /** parser.e:3707						SymTab[sym][S_OBJ_MAX] = usedval*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60515 + ((s1_ptr)_2)->base);
    Ref(_usedval_60520);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 31);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _usedval_60520;
    DeRef(_1);
    _30297 = NOVALUE;

    /** parser.e:3708						SymTab[sym][S_SEQ_LEN] = SymTab[valsym][S_SEQ_LEN]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60515 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _30301 = (object)*(((s1_ptr)_2)->base + _valsym_60516);
    _2 = (object)SEQ_PTR(_30301);
    _30302 = (object)*(((s1_ptr)_2)->base + 32);
    _30301 = NOVALUE;
    Ref(_30302);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 32);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30302;
    if( _1 != _30302 ){
        DeRef(_1);
    }
    _30302 = NOVALUE;
    _30299 = NOVALUE;
    goto L34; // [1943] 2079
L33: 

    /** parser.e:3711					SymTab[sym][S_OBJ] = usedval*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60515 + ((s1_ptr)_2)->base);
    Ref(_usedval_60520);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _usedval_60520;
    DeRef(_1);
    _30303 = NOVALUE;

    /** parser.e:3712					if TRANSLATE then*/
    if (_36TRANSLATE_21369 == 0)
    {
        goto L35; // [1967] 2078
    }
    else{
    }

    /** parser.e:3714						if is_integer( usedval ) then*/
    Ref(_usedval_60520);
    _30305 = _36is_integer(_usedval_60520);
    if (_30305 == 0) {
        DeRef(_30305);
        _30305 = NOVALUE;
        goto L36; // [1976] 1999
    }
    else {
        if (!IS_ATOM_INT(_30305) && DBL_PTR(_30305)->dbl == 0.0){
            DeRef(_30305);
            _30305 = NOVALUE;
            goto L36; // [1976] 1999
        }
        DeRef(_30305);
        _30305 = NOVALUE;
    }
    DeRef(_30305);
    _30305 = NOVALUE;

    /** parser.e:3715							SymTab[sym][S_GTYPE] = TYPE_INTEGER*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60515 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1;
    DeRef(_1);
    _30306 = NOVALUE;
    goto L37; // [1996] 2017
L36: 

    /** parser.e:3717							SymTab[sym][S_GTYPE] = TYPE_DOUBLE*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60515 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2;
    DeRef(_1);
    _30308 = NOVALUE;
L37: 

    /** parser.e:3719						SymTab[sym][S_SEQ_ELEM] = 0*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60515 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);
    _30310 = NOVALUE;

    /** parser.e:3720						SymTab[sym][S_OBJ_MIN] = usedval*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60515 + ((s1_ptr)_2)->base);
    Ref(_usedval_60520);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 30);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _usedval_60520;
    DeRef(_1);
    _30312 = NOVALUE;

    /** parser.e:3721						SymTab[sym][S_OBJ_MAX] = usedval*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60515 + ((s1_ptr)_2)->base);
    Ref(_usedval_60520);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 31);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _usedval_60520;
    DeRef(_1);
    _30314 = NOVALUE;

    /** parser.e:3722						SymTab[sym][S_SEQ_LEN] = 0 --SymTab[valsym][S_SEQ_LEN]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60515 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 32);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);
    _30316 = NOVALUE;
L35: 
L34: 

    /** parser.e:3725				valsym = Pop()*/
    _valsym_60516 = _47Pop();
    if (!IS_ATOM_INT(_valsym_60516)) {
        _1 = (object)(DBL_PTR(_valsym_60516)->dbl);
        DeRefDS(_valsym_60516);
        _valsym_60516 = _1;
    }

    /** parser.e:3726				valsym = Pop()*/
    _valsym_60516 = _47Pop();
    if (!IS_ATOM_INT(_valsym_60516)) {
        _1 = (object)(DBL_PTR(_valsym_60516)->dbl);
        DeRefDS(_valsym_60516);
        _valsym_60516 = _1;
    }
    goto L18; // [2093] 2269
L1C: 

    /** parser.e:3729				SymTab[sym][S_MODE] = M_NORMAL*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60515 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1;
    DeRef(_1);
    _30320 = NOVALUE;

    /** parser.e:3730				if type_ptr > 0 and SymTab[type_ptr][S_TOKEN] = OBJECT then*/
    _30322 = (_type_ptr_60507 > 0);
    if (_30322 == 0) {
        goto L38; // [2119] 2165
    }
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _30324 = (object)*(((s1_ptr)_2)->base + _type_ptr_60507);
    _2 = (object)SEQ_PTR(_30324);
    if (!IS_ATOM_INT(_36S_TOKEN_21409)){
        _30325 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21409)->dbl));
    }
    else{
        _30325 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21409);
    }
    _30324 = NOVALUE;
    if (IS_ATOM_INT(_30325)) {
        _30326 = (_30325 == 415);
    }
    else {
        _30326 = binary_op(EQUALS, _30325, 415);
    }
    _30325 = NOVALUE;
    if (_30326 == 0) {
        DeRef(_30326);
        _30326 = NOVALUE;
        goto L38; // [2142] 2165
    }
    else {
        if (!IS_ATOM_INT(_30326) && DBL_PTR(_30326)->dbl == 0.0){
            DeRef(_30326);
            _30326 = NOVALUE;
            goto L38; // [2142] 2165
        }
        DeRef(_30326);
        _30326 = NOVALUE;
    }
    DeRef(_30326);
    _30326 = NOVALUE;

    /** parser.e:3731					SymTab[sym][S_VTYPE] = object_type*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60515 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 15);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _54object_type_47136;
    DeRef(_1);
    _30327 = NOVALUE;
    goto L39; // [2162] 2194
L38: 

    /** parser.e:3733					SymTab[sym][S_VTYPE] = type_ptr*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60515 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 15);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _type_ptr_60507;
    DeRef(_1);
    _30329 = NOVALUE;

    /** parser.e:3734					if type_ptr < 0 then*/
    if (_type_ptr_60507 >= 0)
    goto L3A; // [2182] 2193

    /** parser.e:3735						register_forward_type( sym, type_ptr )*/
    _44register_forward_type(_sym_60515, _type_ptr_60507);
L3A: 
L39: 

    /** parser.e:3739				if TRANSLATE then*/
    if (_36TRANSLATE_21369 == 0)
    {
        goto L3B; // [2198] 2221
    }
    else{
    }

    /** parser.e:3740					SymTab[sym][S_GTYPE] = CompileType(type_ptr)*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60515 + ((s1_ptr)_2)->base);
    _30334 = _45CompileType(_type_ptr_60507);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30334;
    if( _1 != _30334 ){
        DeRef(_1);
    }
    _30334 = NOVALUE;
    _30332 = NOVALUE;
L3B: 

    /** parser.e:3743		   		tok = next_token()*/
    _0 = _tok_60511;
    _tok_60511 = _45next_token();
    DeRef(_0);

    /** parser.e:3744	   			putback(tok)*/
    Ref(_tok_60511);
    _45putback(_tok_60511);

    /** parser.e:3745		   		if tok[T_ID] = EQUALS then -- assign on declare*/
    _2 = (object)SEQ_PTR(_tok_60511);
    _30336 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30336, 3)){
        _30336 = NOVALUE;
        goto L3C; // [2241] 2268
    }
    _30336 = NOVALUE;

    /** parser.e:3746		   			StartSourceLine( FALSE, , COVERAGE_OVERRIDE )*/
    _47StartSourceLine(_13FALSE_445, 0, 3);

    /** parser.e:3747		   			Assignment({VARIABLE,sym})*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -100;
    ((intptr_t *)_2)[2] = _sym_60515;
    _30338 = MAKE_SEQ(_1);
    _45Assignment(_30338);
    _30338 = NOVALUE;
L3C: 
L18: 

    /** parser.e:3750			tok = next_token()*/
    _0 = _tok_60511;
    _tok_60511 = _45next_token();
    DeRef(_0);

    /** parser.e:3751			if tok[T_ID] != COMMA then*/
    _2 = (object)SEQ_PTR(_tok_60511);
    _30340 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _30340, -30)){
        _30340 = NOVALUE;
        goto L3D; // [2284] 2293
    }
    _30340 = NOVALUE;

    /** parser.e:3752				exit*/
    goto LD; // [2290] 2303
L3D: 

    /** parser.e:3754			prevtok = tok*/
    Ref(_tok_60511);
    DeRef(_prevtok_60513);
    _prevtok_60513 = _tok_60511;

    /** parser.e:3755		end while*/
    goto LC; // [2300] 440
LD: 

    /** parser.e:3756		putback(tok)*/
    Ref(_tok_60511);
    _45putback(_tok_60511);

    /** parser.e:3757		return new_symbols*/
    DeRef(_tok_60511);
    DeRef(_tsym_60512);
    DeRef(_prevtok_60513);
    DeRef(_val_60519);
    DeRef(_usedval_60520);
    DeRef(_delta_60522);
    DeRef(_30251);
    _30251 = NOVALUE;
    DeRef(_30191);
    _30191 = NOVALUE;
    DeRef(_30166);
    _30166 = NOVALUE;
    DeRef(_30101);
    _30101 = NOVALUE;
    _30179 = NOVALUE;
    _30271 = NOVALUE;
    _30183 = NOVALUE;
    DeRef(_30235);
    _30235 = NOVALUE;
    _30215 = NOVALUE;
    DeRef(_30209);
    _30209 = NOVALUE;
    _30128 = NOVALUE;
    DeRef(_30200);
    _30200 = NOVALUE;
    _30230 = NOVALUE;
    DeRef(_30322);
    _30322 = NOVALUE;
    return _new_symbols_60509;
    ;
}


void _45Private_declaration(object _type_sym_61096)
{
    object _tok_61098 = NOVALUE;
    object _sym_61100 = NOVALUE;
    object _31955 = NOVALUE;
    object _31954 = NOVALUE;
    object _31953 = NOVALUE;
    object _30366 = NOVALUE;
    object _30364 = NOVALUE;
    object _30362 = NOVALUE;
    object _30360 = NOVALUE;
    object _30358 = NOVALUE;
    object _30356 = NOVALUE;
    object _30354 = NOVALUE;
    object _30351 = NOVALUE;
    object _30349 = NOVALUE;
    object _30348 = NOVALUE;
    object _30345 = NOVALUE;
    object _30343 = NOVALUE;
    object _30342 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_type_sym_61096)) {
        _1 = (object)(DBL_PTR(_type_sym_61096)->dbl);
        DeRefDS(_type_sym_61096);
        _type_sym_61096 = _1;
    }

    /** parser.e:3765		if SymTab[type_sym][S_SCOPE] = SC_UNDEFINED then*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _30342 = (object)*(((s1_ptr)_2)->base + _type_sym_61096);
    _2 = (object)SEQ_PTR(_30342);
    _30343 = (object)*(((s1_ptr)_2)->base + 4);
    _30342 = NOVALUE;
    if (binary_op_a(NOTEQ, _30343, 9)){
        _30343 = NOVALUE;
        goto L1; // [19] 47
    }
    _30343 = NOVALUE;

    /** parser.e:3766			Hide( type_sym )*/
    _54Hide(_type_sym_61096);

    /** parser.e:3767			type_sym = -new_forward_reference( TYPE, type_sym )*/
    _31955 = 504;
    _30345 = _44new_forward_reference(504, _type_sym_61096, 504);
    _31955 = NOVALUE;
    if (IS_ATOM_INT(_30345)) {
        if ((uintptr_t)_30345 == (uintptr_t)HIGH_BITS){
            _type_sym_61096 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _type_sym_61096 = - _30345;
        }
    }
    else {
        _type_sym_61096 = unary_op(UMINUS, _30345);
    }
    DeRef(_30345);
    _30345 = NOVALUE;
    if (!IS_ATOM_INT(_type_sym_61096)) {
        _1 = (object)(DBL_PTR(_type_sym_61096)->dbl);
        DeRefDS(_type_sym_61096);
        _type_sym_61096 = _1;
    }
L1: 

    /** parser.e:3770		while TRUE do*/
L2: 
    if (_13TRUE_447 == 0)
    {
        goto L3; // [54] 257
    }
    else{
    }

    /** parser.e:3771			tok = next_token()*/
    _0 = _tok_61098;
    _tok_61098 = _45next_token();
    DeRef(_0);

    /** parser.e:3772			if not find(tok[T_ID], ID_TOKS) then*/
    _2 = (object)SEQ_PTR(_tok_61098);
    _30348 = (object)*(((s1_ptr)_2)->base + 1);
    _30349 = find_from(_30348, _38ID_TOKS_16297, 1);
    _30348 = NOVALUE;
    if (_30349 != 0)
    goto L4; // [77] 90
    _30349 = NOVALUE;

    /** parser.e:3773				CompileErr(A_VARIABLE_NAME_IS_EXPECTED_HERE)*/
    RefDS(_22190);
    _50CompileErr(24, _22190, 0);
L4: 

    /** parser.e:3775			sym = SetPrivateScope(tok[T_SYM], type_sym, param_num)*/
    _2 = (object)SEQ_PTR(_tok_61098);
    _30351 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_30351);
    _sym_61100 = _45SetPrivateScope(_30351, _type_sym_61096, _45param_num_55365);
    _30351 = NOVALUE;
    if (!IS_ATOM_INT(_sym_61100)) {
        _1 = (object)(DBL_PTR(_sym_61100)->dbl);
        DeRefDS(_sym_61100);
        _sym_61100 = _1;
    }

    /** parser.e:3776			param_num += 1*/
    _45param_num_55365 = _45param_num_55365 + 1;

    /** parser.e:3778			if TRANSLATE then*/
    if (_36TRANSLATE_21369 == 0)
    {
        goto L5; // [120] 143
    }
    else{
    }

    /** parser.e:3779				SymTab[sym][S_GTYPE] = CompileType(type_sym)*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_61100 + ((s1_ptr)_2)->base);
    _30356 = _45CompileType(_type_sym_61096);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30356;
    if( _1 != _30356 ){
        DeRef(_1);
    }
    _30356 = NOVALUE;
    _30354 = NOVALUE;
L5: 

    /** parser.e:3782	   		tok = next_token()*/
    _0 = _tok_61098;
    _tok_61098 = _45next_token();
    DeRef(_0);

    /** parser.e:3783	   		if tok[T_ID] = EQUALS then -- assign on declare*/
    _2 = (object)SEQ_PTR(_tok_61098);
    _30358 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30358, 3)){
        _30358 = NOVALUE;
        goto L6; // [158] 233
    }
    _30358 = NOVALUE;

    /** parser.e:3784			    putback(tok)*/
    Ref(_tok_61098);
    _45putback(_tok_61098);

    /** parser.e:3785			    StartSourceLine( TRUE )*/
    _47StartSourceLine(_13TRUE_447, 0, 2);

    /** parser.e:3797			    Assignment({VARIABLE,sym})*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -100;
    ((intptr_t *)_2)[2] = _sym_61100;
    _30360 = MAKE_SEQ(_1);
    _45Assignment(_30360);
    _30360 = NOVALUE;

    /** parser.e:3800				tok = next_token()*/
    _0 = _tok_61098;
    _tok_61098 = _45next_token();
    DeRef(_0);

    /** parser.e:3801				if tok[T_ID]=IGNORED then*/
    _2 = (object)SEQ_PTR(_tok_61098);
    _30362 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30362, 509)){
        _30362 = NOVALUE;
        goto L7; // [202] 232
    }
    _30362 = NOVALUE;

    /** parser.e:3802					tok = keyfind(tok[T_SYM],-1)*/
    _2 = (object)SEQ_PTR(_tok_61098);
    _30364 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_30364);
    DeRef(_31953);
    _31953 = _30364;
    _31954 = _54hashfn(_31953);
    _31953 = NOVALUE;
    Ref(_30364);
    _0 = _tok_61098;
    _tok_61098 = _54keyfind(_30364, -1, _36current_file_no_21767, 0, _31954);
    DeRef(_0);
    _30364 = NOVALUE;
    _31954 = NOVALUE;
L7: 
L6: 

    /** parser.e:3806			if tok[T_ID] != COMMA then*/
    _2 = (object)SEQ_PTR(_tok_61098);
    _30366 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _30366, -30)){
        _30366 = NOVALUE;
        goto L2; // [243] 52
    }
    _30366 = NOVALUE;

    /** parser.e:3807				exit*/
    goto L3; // [249] 257

    /** parser.e:3809		end while*/
    goto L2; // [254] 52
L3: 

    /** parser.e:3810		putback(tok)*/
    Ref(_tok_61098);
    _45putback(_tok_61098);

    /** parser.e:3811	end procedure*/
    DeRef(_tok_61098);
    return;
    ;
}


void _45Procedure_call(object _tok_61163)
{
    object _n_61164 = NOVALUE;
    object _scope_61165 = NOVALUE;
    object _opcode_61166 = NOVALUE;
    object _temp_tok_61168 = NOVALUE;
    object _s_61170 = NOVALUE;
    object _sub_61171 = NOVALUE;
    object _30402 = NOVALUE;
    object _30397 = NOVALUE;
    object _30396 = NOVALUE;
    object _30395 = NOVALUE;
    object _30394 = NOVALUE;
    object _30393 = NOVALUE;
    object _30392 = NOVALUE;
    object _30391 = NOVALUE;
    object _30390 = NOVALUE;
    object _30389 = NOVALUE;
    object _30388 = NOVALUE;
    object _30387 = NOVALUE;
    object _30385 = NOVALUE;
    object _30384 = NOVALUE;
    object _30383 = NOVALUE;
    object _30382 = NOVALUE;
    object _30381 = NOVALUE;
    object _30380 = NOVALUE;
    object _30379 = NOVALUE;
    object _30377 = NOVALUE;
    object _30376 = NOVALUE;
    object _30375 = NOVALUE;
    object _30373 = NOVALUE;
    object _30371 = NOVALUE;
    object _30369 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:3820		tok_match(LEFT_ROUND)*/
    _45tok_match(-26, 0);

    /** parser.e:3821		s = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_61163);
    _s_61170 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_61170)){
        _s_61170 = (object)DBL_PTR(_s_61170)->dbl;
    }

    /** parser.e:3822		sub=s*/
    _sub_61171 = _s_61170;

    /** parser.e:3823		n = SymTab[s][S_NUM_ARGS]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _30369 = (object)*(((s1_ptr)_2)->base + _s_61170);
    _2 = (object)SEQ_PTR(_30369);
    if (!IS_ATOM_INT(_36S_NUM_ARGS_21455)){
        _n_61164 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21455)->dbl));
    }
    else{
        _n_61164 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21455);
    }
    if (!IS_ATOM_INT(_n_61164)){
        _n_61164 = (object)DBL_PTR(_n_61164)->dbl;
    }
    _30369 = NOVALUE;

    /** parser.e:3824		scope = SymTab[s][S_SCOPE]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _30371 = (object)*(((s1_ptr)_2)->base + _s_61170);
    _2 = (object)SEQ_PTR(_30371);
    _scope_61165 = (object)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_scope_61165)){
        _scope_61165 = (object)DBL_PTR(_scope_61165)->dbl;
    }
    _30371 = NOVALUE;

    /** parser.e:3825		opcode = SymTab[s][S_OPCODE]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _30373 = (object)*(((s1_ptr)_2)->base + _s_61170);
    _2 = (object)SEQ_PTR(_30373);
    _opcode_61166 = (object)*(((s1_ptr)_2)->base + 21);
    if (!IS_ATOM_INT(_opcode_61166)){
        _opcode_61166 = (object)DBL_PTR(_opcode_61166)->dbl;
    }
    _30373 = NOVALUE;

    /** parser.e:3826		if SymTab[s][S_EFFECT] then*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _30375 = (object)*(((s1_ptr)_2)->base + _s_61170);
    _2 = (object)SEQ_PTR(_30375);
    _30376 = (object)*(((s1_ptr)_2)->base + 23);
    _30375 = NOVALUE;
    if (_30376 == 0) {
        _30376 = NOVALUE;
        goto L1; // [88] 139
    }
    else {
        if (!IS_ATOM_INT(_30376) && DBL_PTR(_30376)->dbl == 0.0){
            _30376 = NOVALUE;
            goto L1; // [88] 139
        }
        _30376 = NOVALUE;
    }
    _30376 = NOVALUE;

    /** parser.e:3827			SymTab[CurrentSub][S_EFFECT] = or_bits(SymTab[CurrentSub][S_EFFECT],*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_36CurrentSub_21775 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _30379 = (object)*(((s1_ptr)_2)->base + _36CurrentSub_21775);
    _2 = (object)SEQ_PTR(_30379);
    _30380 = (object)*(((s1_ptr)_2)->base + 23);
    _30379 = NOVALUE;
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _30381 = (object)*(((s1_ptr)_2)->base + _s_61170);
    _2 = (object)SEQ_PTR(_30381);
    _30382 = (object)*(((s1_ptr)_2)->base + 23);
    _30381 = NOVALUE;
    if (IS_ATOM_INT(_30380) && IS_ATOM_INT(_30382)) {
        {uintptr_t tu;
             tu = (uintptr_t)_30380 | (uintptr_t)_30382;
             _30383 = MAKE_UINT(tu);
        }
    }
    else {
        _30383 = binary_op(OR_BITS, _30380, _30382);
    }
    _30380 = NOVALUE;
    _30382 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 23);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30383;
    if( _1 != _30383 ){
        DeRef(_1);
    }
    _30383 = NOVALUE;
    _30377 = NOVALUE;
L1: 

    /** parser.e:3830		ParseArgs(s)*/
    _45ParseArgs(_s_61170);

    /** parser.e:3833		for i=1 to n+1 do*/
    _30384 = _n_61164 + 1;
    if (_30384 > MAXINT){
        _30384 = NewDouble((eudouble)_30384);
    }
    {
        object _i_61208;
        _i_61208 = 1;
L2: 
        if (binary_op_a(GREATER, _i_61208, _30384)){
            goto L3; // [150] 180
        }

        /** parser.e:3834			s = SymTab[s][S_NEXT]*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _30385 = (object)*(((s1_ptr)_2)->base + _s_61170);
        _2 = (object)SEQ_PTR(_30385);
        _s_61170 = (object)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_s_61170)){
            _s_61170 = (object)DBL_PTR(_s_61170)->dbl;
        }
        _30385 = NOVALUE;

        /** parser.e:3835		end for*/
        _0 = _i_61208;
        if (IS_ATOM_INT(_i_61208)) {
            _i_61208 = _i_61208 + 1;
            if ((object)((uintptr_t)_i_61208 +(uintptr_t) HIGH_BITS) >= 0){
                _i_61208 = NewDouble((eudouble)_i_61208);
            }
        }
        else {
            _i_61208 = binary_op_a(PLUS, _i_61208, 1);
        }
        DeRef(_0);
        goto L2; // [175] 157
L3: 
        ;
        DeRef(_i_61208);
    }

    /** parser.e:3836		while s and SymTab[s][S_SCOPE]=SC_PRIVATE do*/
L4: 
    if (_s_61170 == 0) {
        goto L5; // [185] 281
    }
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _30388 = (object)*(((s1_ptr)_2)->base + _s_61170);
    _2 = (object)SEQ_PTR(_30388);
    _30389 = (object)*(((s1_ptr)_2)->base + 4);
    _30388 = NOVALUE;
    if (IS_ATOM_INT(_30389)) {
        _30390 = (_30389 == 3);
    }
    else {
        _30390 = binary_op(EQUALS, _30389, 3);
    }
    _30389 = NOVALUE;
    if (_30390 <= 0) {
        if (_30390 == 0) {
            DeRef(_30390);
            _30390 = NOVALUE;
            goto L5; // [208] 281
        }
        else {
            if (!IS_ATOM_INT(_30390) && DBL_PTR(_30390)->dbl == 0.0){
                DeRef(_30390);
                _30390 = NOVALUE;
                goto L5; // [208] 281
            }
            DeRef(_30390);
            _30390 = NOVALUE;
        }
    }
    DeRef(_30390);
    _30390 = NOVALUE;

    /** parser.e:3837			if sequence(SymTab[s][S_CODE]) then*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _30391 = (object)*(((s1_ptr)_2)->base + _s_61170);
    _2 = (object)SEQ_PTR(_30391);
    if (!IS_ATOM_INT(_36S_CODE_21416)){
        _30392 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21416)->dbl));
    }
    else{
        _30392 = (object)*(((s1_ptr)_2)->base + _36S_CODE_21416);
    }
    _30391 = NOVALUE;
    _30393 = IS_SEQUENCE(_30392);
    _30392 = NOVALUE;
    if (_30393 == 0)
    {
        _30393 = NOVALUE;
        goto L6; // [228] 260
    }
    else{
        _30393 = NOVALUE;
    }

    /** parser.e:3838				start_playback(SymTab[s][S_CODE])*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _30394 = (object)*(((s1_ptr)_2)->base + _s_61170);
    _2 = (object)SEQ_PTR(_30394);
    if (!IS_ATOM_INT(_36S_CODE_21416)){
        _30395 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21416)->dbl));
    }
    else{
        _30395 = (object)*(((s1_ptr)_2)->base + _36S_CODE_21416);
    }
    _30394 = NOVALUE;
    Ref(_30395);
    _45start_playback(_30395);
    _30395 = NOVALUE;

    /** parser.e:3839				Assignment({VARIABLE,s})*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -100;
    ((intptr_t *)_2)[2] = _s_61170;
    _30396 = MAKE_SEQ(_1);
    _45Assignment(_30396);
    _30396 = NOVALUE;
L6: 

    /** parser.e:3841			s = SymTab[s][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _30397 = (object)*(((s1_ptr)_2)->base + _s_61170);
    _2 = (object)SEQ_PTR(_30397);
    _s_61170 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_61170)){
        _s_61170 = (object)DBL_PTR(_s_61170)->dbl;
    }
    _30397 = NOVALUE;

    /** parser.e:3842		end while*/
    goto L4; // [278] 185
L5: 

    /** parser.e:3844		s = sub*/
    _s_61170 = _sub_61171;

    /** parser.e:3845		if scope = SC_PREDEF then*/
    if (_scope_61165 != 7)
    goto L7; // [292] 335

    /** parser.e:3846			emit_op(opcode)*/
    _47emit_op(_opcode_61166);

    /** parser.e:3847			if opcode = ABORT then*/
    if (_opcode_61166 != 126)
    goto L8; // [305] 370

    /** parser.e:3848				temp_tok = next_token()*/
    _0 = _temp_tok_61168;
    _temp_tok_61168 = _45next_token();
    DeRef(_0);

    /** parser.e:3849				putback(temp_tok)*/
    Ref(_temp_tok_61168);
    _45putback(_temp_tok_61168);

    /** parser.e:3850				NotReached(temp_tok[T_ID], "abort()")*/
    _2 = (object)SEQ_PTR(_temp_tok_61168);
    _30402 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_30402);
    RefDS(_28138);
    _45NotReached(_30402, _28138);
    _30402 = NOVALUE;
    goto L8; // [332] 370
L7: 

    /** parser.e:3853			op_info1 = s*/
    _47op_info1_51364 = _s_61170;

    /** parser.e:3855			emit_or_inline()*/
    _67emit_or_inline();

    /** parser.e:3856			if not TRANSLATE then*/
    if (_36TRANSLATE_21369 != 0)
    goto L9; // [350] 369

    /** parser.e:3857				if OpTrace then*/
    if (_36OpTrace_21840 == 0)
    {
        goto LA; // [357] 368
    }
    else{
    }

    /** parser.e:3858					emit_op(UPDATE_GLOBALS)*/
    _47emit_op(89);
LA: 
L9: 
L8: 

    /** parser.e:3862	end procedure*/
    DeRef(_tok_61163);
    DeRef(_temp_tok_61168);
    DeRef(_30384);
    _30384 = NOVALUE;
    return;
    ;
}


void _45Print_statement()
{
    object _30409 = NOVALUE;
    object _30408 = NOVALUE;
    object _30407 = NOVALUE;
    object _30405 = NOVALUE;
    object _30404 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:3866		emit_opnd(NewIntSym(1)) -- stdout*/
    _30404 = _54NewIntSym(1);
    _47emit_opnd(_30404);
    _30404 = NOVALUE;

    /** parser.e:3867		Expr()*/
    _45Expr();

    /** parser.e:3868		emit_op(QPRINT)*/
    _47emit_op(36);

    /** parser.e:3869		SymTab[CurrentSub][S_EFFECT] = or_bits(SymTab[CurrentSub][S_EFFECT],*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_36CurrentSub_21775 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _30407 = (object)*(((s1_ptr)_2)->base + _36CurrentSub_21775);
    _2 = (object)SEQ_PTR(_30407);
    _30408 = (object)*(((s1_ptr)_2)->base + 23);
    _30407 = NOVALUE;
    if (IS_ATOM_INT(_30408)) {
        {uintptr_t tu;
             tu = (uintptr_t)_30408 | (uintptr_t)536870912;
             _30409 = MAKE_UINT(tu);
        }
    }
    else {
        _30409 = binary_op(OR_BITS, _30408, 536870912);
    }
    _30408 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 23);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30409;
    if( _1 != _30409 ){
        DeRef(_1);
    }
    _30409 = NOVALUE;
    _30405 = NOVALUE;

    /** parser.e:3871	end procedure*/
    return;
    ;
}


void _45Entry_statement()
{
    object _addr_61279 = NOVALUE;
    object _30433 = NOVALUE;
    object _30432 = NOVALUE;
    object _30431 = NOVALUE;
    object _30430 = NOVALUE;
    object _30429 = NOVALUE;
    object _30428 = NOVALUE;
    object _30427 = NOVALUE;
    object _30426 = NOVALUE;
    object _30422 = NOVALUE;
    object _30420 = NOVALUE;
    object _30419 = NOVALUE;
    object _30418 = NOVALUE;
    object _30417 = NOVALUE;
    object _30415 = NOVALUE;
    object _30414 = NOVALUE;
    object _30413 = NOVALUE;
    object _30411 = NOVALUE;
    object _30410 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:3878		if not length(loop_stack) or block_index=0 then*/
    if (IS_SEQUENCE(_45loop_stack_55390)){
            _30410 = SEQ_PTR(_45loop_stack_55390)->length;
    }
    else {
        _30410 = 1;
    }
    _30411 = (_30410 == 0);
    _30410 = NOVALUE;
    if (_30411 != 0) {
        goto L1; // [11] 26
    }
    _30413 = (_45block_index_55387 == 0);
    if (_30413 == 0)
    {
        DeRef(_30413);
        _30413 = NOVALUE;
        goto L2; // [22] 36
    }
    else{
        DeRef(_30413);
        _30413 = NOVALUE;
    }
L1: 

    /** parser.e:3879			CompileErr(THE_ENTRY_STATEMENT_MUST_APPEAR_INSIDE_A_LOOP)*/
    RefDS(_22190);
    _50CompileErr(144, _22190, 0);
L2: 

    /** parser.e:3881		if block_list[block_index]=IF or block_list[block_index]=SWITCH then*/
    _2 = (object)SEQ_PTR(_45block_list_55386);
    _30414 = (object)*(((s1_ptr)_2)->base + _45block_index_55387);
    _30415 = (_30414 == 20);
    _30414 = NOVALUE;
    if (_30415 != 0) {
        goto L3; // [52] 75
    }
    _2 = (object)SEQ_PTR(_45block_list_55386);
    _30417 = (object)*(((s1_ptr)_2)->base + _45block_index_55387);
    _30418 = (_30417 == 185);
    _30417 = NOVALUE;
    if (_30418 == 0)
    {
        DeRef(_30418);
        _30418 = NOVALUE;
        goto L4; // [71] 87
    }
    else{
        DeRef(_30418);
        _30418 = NOVALUE;
    }
L3: 

    /** parser.e:3882			CompileErr(THE_INNERMOST_BLOCK_CONTAINING_AN_ENTRY_STATEMENT_MUST_BE_THE_LOOP_IT_DEFINES_AN_ENTRY_IN)*/
    RefDS(_22190);
    _50CompileErr(143, _22190, 0);
    goto L5; // [84] 115
L4: 

    /** parser.e:3883		elsif loop_stack[$] = FOR then  -- not allowed in an innermost for loop*/
    if (IS_SEQUENCE(_45loop_stack_55390)){
            _30419 = SEQ_PTR(_45loop_stack_55390)->length;
    }
    else {
        _30419 = 1;
    }
    _2 = (object)SEQ_PTR(_45loop_stack_55390);
    _30420 = (object)*(((s1_ptr)_2)->base + _30419);
    if (_30420 != 21)
    goto L6; // [100] 114

    /** parser.e:3884			CompileErr(THE_ENTRY_STATEMENT_CAN_NOT_BE_USED_IN_A_FOR_BLOCK)*/
    RefDS(_22190);
    _50CompileErr(142, _22190, 0);
L6: 
L5: 

    /** parser.e:3886		addr = entry_addr[$]*/
    if (IS_SEQUENCE(_45entry_addr_55380)){
            _30422 = SEQ_PTR(_45entry_addr_55380)->length;
    }
    else {
        _30422 = 1;
    }
    _2 = (object)SEQ_PTR(_45entry_addr_55380);
    _addr_61279 = (object)*(((s1_ptr)_2)->base + _30422);

    /** parser.e:3887		if addr=0  then*/
    if (_addr_61279 != 0)
    goto L7; // [128] 144

    /** parser.e:3888			CompileErr(THE_ENTRY_STATEMENT_MUST_APPEAR_AT_MOST_ONCE_INSIDE_A_LOOP)*/
    RefDS(_22190);
    _50CompileErr(141, _22190, 0);
    goto L8; // [141] 161
L7: 

    /** parser.e:3889		elsif addr<0 then*/
    if (_addr_61279 >= 0)
    goto L9; // [146] 160

    /** parser.e:3890			CompileErr(ENTRY_STATEMENT_IS_BEING_USED_WITHOUT_A_CORRESPONDING_ENTRY_CLAUSE_IN_THE_LOOP_HEADER)*/
    RefDS(_22190);
    _50CompileErr(73, _22190, 0);
L9: 
L8: 

    /** parser.e:3892		backpatch(addr,ELSE)*/
    _47backpatch(_addr_61279, 23);

    /** parser.e:3893		backpatch(addr+1,length(Code)+1+(TRANSLATE>0))*/
    _30426 = _addr_61279 + 1;
    if (_30426 > MAXINT){
        _30426 = NewDouble((eudouble)_30426);
    }
    if (IS_SEQUENCE(_36Code_21859)){
            _30427 = SEQ_PTR(_36Code_21859)->length;
    }
    else {
        _30427 = 1;
    }
    _30428 = _30427 + 1;
    _30427 = NOVALUE;
    _30429 = (_36TRANSLATE_21369 > 0);
    _30430 = _30428 + _30429;
    _30428 = NOVALUE;
    _30429 = NOVALUE;
    _47backpatch(_30426, _30430);
    _30426 = NOVALUE;
    _30430 = NOVALUE;

    /** parser.e:3894		entry_addr[$] = 0*/
    if (IS_SEQUENCE(_45entry_addr_55380)){
            _30431 = SEQ_PTR(_45entry_addr_55380)->length;
    }
    else {
        _30431 = 1;
    }
    _2 = (object)SEQ_PTR(_45entry_addr_55380);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _45entry_addr_55380 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _30431);
    *(intptr_t *)_2 = 0;

    /** parser.e:3895		if TRANSLATE then*/
    if (_36TRANSLATE_21369 == 0)
    {
        goto LA; // [213] 224
    }
    else{
    }

    /** parser.e:3896		    emit_op(NOP1)*/
    _47emit_op(159);
LA: 

    /** parser.e:3899		force_uninitialize( entry_stack[$] )*/
    if (IS_SEQUENCE(_45entry_stack_55383)){
            _30432 = SEQ_PTR(_45entry_stack_55383)->length;
    }
    else {
        _30432 = 1;
    }
    _2 = (object)SEQ_PTR(_45entry_stack_55383);
    _30433 = (object)*(((s1_ptr)_2)->base + _30432);
    Ref(_30433);
    _45force_uninitialize(_30433);
    _30433 = NOVALUE;

    /** parser.e:3901	end procedure*/
    _30420 = NOVALUE;
    DeRef(_30415);
    _30415 = NOVALUE;
    DeRef(_30411);
    _30411 = NOVALUE;
    return;
    ;
}


void _45force_uninitialize(object _uninitialized_61334)
{
    object _30436 = NOVALUE;
    object _30435 = NOVALUE;
    object _30434 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:3907		for i = 1 to length( uninitialized ) do*/
    if (IS_SEQUENCE(_uninitialized_61334)){
            _30434 = SEQ_PTR(_uninitialized_61334)->length;
    }
    else {
        _30434 = 1;
    }
    {
        object _i_61336;
        _i_61336 = 1;
L1: 
        if (_i_61336 > _30434){
            goto L2; // [8] 41
        }

        /** parser.e:3908			SymTab[uninitialized[i]][S_INITLEVEL] = -1*/
        _2 = (object)SEQ_PTR(_uninitialized_61334);
        _30435 = (object)*(((s1_ptr)_2)->base + _i_61336);
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37SymTab_15637 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_30435))
        _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_30435)->dbl));
        else
        _3 = (object)(_30435 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 14);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = -1;
        DeRef(_1);
        _30436 = NOVALUE;

        /** parser.e:3909		end for*/
        _i_61336 = _i_61336 + 1;
        goto L1; // [36] 15
L2: 
        ;
    }

    /** parser.e:3910	end procedure*/
    DeRefDS(_uninitialized_61334);
    _30435 = NOVALUE;
    return;
    ;
}


void _45Statement_list()
{
    object _tok_61346 = NOVALUE;
    object _id_61347 = NOVALUE;
    object _forward_61370 = NOVALUE;
    object _test_61519 = NOVALUE;
    object _30509 = NOVALUE;
    object _30508 = NOVALUE;
    object _30505 = NOVALUE;
    object _30503 = NOVALUE;
    object _30502 = NOVALUE;
    object _30499 = NOVALUE;
    object _30496 = NOVALUE;
    object _30495 = NOVALUE;
    object _30494 = NOVALUE;
    object _30491 = NOVALUE;
    object _30489 = NOVALUE;
    object _30487 = NOVALUE;
    object _30485 = NOVALUE;
    object _30467 = NOVALUE;
    object _30466 = NOVALUE;
    object _30464 = NOVALUE;
    object _30462 = NOVALUE;
    object _30461 = NOVALUE;
    object _30459 = NOVALUE;
    object _30457 = NOVALUE;
    object _30456 = NOVALUE;
    object _30455 = NOVALUE;
    object _30454 = NOVALUE;
    object _30449 = NOVALUE;
    object _30446 = NOVALUE;
    object _30445 = NOVALUE;
    object _30444 = NOVALUE;
    object _30443 = NOVALUE;
    object _30441 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:3915		integer id*/

    /** parser.e:3917		stmt_nest += 1*/
    _45stmt_nest_55388 = _45stmt_nest_55388 + 1;

    /** parser.e:3918		while TRUE do*/
L1: 
    if (_13TRUE_447 == 0)
    {
        goto L2; // [18] 1125
    }
    else{
    }

    /** parser.e:3919			tok = next_token()*/
    _0 = _tok_61346;
    _tok_61346 = _45next_token();
    DeRef(_0);

    /** parser.e:3920			id = tok[T_ID]*/
    _2 = (object)SEQ_PTR(_tok_61346);
    _id_61347 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_id_61347)){
        _id_61347 = (object)DBL_PTR(_id_61347)->dbl;
    }

    /** parser.e:3921			if id = VARIABLE or id = QUALIFIED_VARIABLE then*/
    _30441 = (_id_61347 == -100);
    if (_30441 != 0) {
        goto L3; // [44] 59
    }
    _30443 = (_id_61347 == 512);
    if (_30443 == 0)
    {
        DeRef(_30443);
        _30443 = NOVALUE;
        goto L4; // [55] 229
    }
    else{
        DeRef(_30443);
        _30443 = NOVALUE;
    }
L3: 

    /** parser.e:3922				if SymTab[tok[T_SYM]][S_SCOPE] = SC_UNDEFINED then*/
    _2 = (object)SEQ_PTR(_tok_61346);
    _30444 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!IS_ATOM_INT(_30444)){
        _30445 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_30444)->dbl));
    }
    else{
        _30445 = (object)*(((s1_ptr)_2)->base + _30444);
    }
    _2 = (object)SEQ_PTR(_30445);
    _30446 = (object)*(((s1_ptr)_2)->base + 4);
    _30445 = NOVALUE;
    if (binary_op_a(NOTEQ, _30446, 9)){
        _30446 = NOVALUE;
        goto L5; // [81] 210
    }
    _30446 = NOVALUE;

    /** parser.e:3923					token forward = next_token()*/
    _0 = _forward_61370;
    _forward_61370 = _45next_token();
    DeRef(_0);

    /** parser.e:3924					switch forward[T_ID] do*/
    _2 = (object)SEQ_PTR(_forward_61370);
    _30449 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_30449) ){
        goto L6; // [98] 204
    }
    if(!IS_ATOM_INT(_30449)){
        if( (DBL_PTR(_30449)->dbl != (eudouble) ((object) DBL_PTR(_30449)->dbl) ) ){
            goto L6; // [98] 204
        }
        _0 = (object) DBL_PTR(_30449)->dbl;
    }
    else {
        _0 = _30449;
    };
    _30449 = NOVALUE;
    switch ( _0 ){ 

        /** parser.e:3925						case LEFT_ROUND then*/
        case -26:

        /** parser.e:3926							StartSourceLine( TRUE )*/
        _47StartSourceLine(_13TRUE_447, 0, 2);

        /** parser.e:3928							Forward_call( tok )*/
        Ref(_tok_61346);
        _45Forward_call(_tok_61346, 195);

        /** parser.e:3929							flush_temps()*/
        RefDS(_22190);
        _47flush_temps(_22190);

        /** parser.e:3930							continue*/
        DeRef(_forward_61370);
        _forward_61370 = NOVALUE;
        goto L1; // [133] 16
        goto L6; // [135] 204

        /** parser.e:3932						case VARIABLE then*/
        case -100:

        /** parser.e:3933							putback( forward )*/
        Ref(_forward_61370);
        _45putback(_forward_61370);

        /** parser.e:3934							if param_num != -1 then*/
        if (_45param_num_55365 == -1)
        goto L7; // [150] 176

        /** parser.e:3936								param_num += 1*/
        _45param_num_55365 = _45param_num_55365 + 1;

        /** parser.e:3937								Private_declaration( tok[T_SYM] )*/
        _2 = (object)SEQ_PTR(_tok_61346);
        _30454 = (object)*(((s1_ptr)_2)->base + 2);
        Ref(_30454);
        _45Private_declaration(_30454);
        _30454 = NOVALUE;
        goto L8; // [173] 192
L7: 

        /** parser.e:3939								Global_declaration( tok[T_SYM], SC_LOCAL )*/
        _2 = (object)SEQ_PTR(_tok_61346);
        _30455 = (object)*(((s1_ptr)_2)->base + 2);
        Ref(_30455);
        _30456 = _45Global_declaration(_30455, 5);
        _30455 = NOVALUE;
L8: 

        /** parser.e:3941							flush_temps()*/
        RefDS(_22190);
        _47flush_temps(_22190);

        /** parser.e:3942							continue*/
        DeRef(_forward_61370);
        _forward_61370 = NOVALUE;
        goto L1; // [201] 16
    ;}L6: 

    /** parser.e:3945					putback( forward )*/
    Ref(_forward_61370);
    _45putback(_forward_61370);
L5: 
    DeRef(_forward_61370);
    _forward_61370 = NOVALUE;

    /** parser.e:3947				StartSourceLine(TRUE)*/
    _47StartSourceLine(_13TRUE_447, 0, 2);

    /** parser.e:3948				Assignment(tok)*/
    Ref(_tok_61346);
    _45Assignment(_tok_61346);
    goto L9; // [226] 1115
L4: 

    /** parser.e:3950			elsif id = PROC or id = QUALIFIED_PROC then*/
    _30457 = (_id_61347 == 27);
    if (_30457 != 0) {
        goto LA; // [237] 252
    }
    _30459 = (_id_61347 == 521);
    if (_30459 == 0)
    {
        DeRef(_30459);
        _30459 = NOVALUE;
        goto LB; // [248] 289
    }
    else{
        DeRef(_30459);
        _30459 = NOVALUE;
    }
LA: 

    /** parser.e:3951				if id = PROC then*/
    if (_id_61347 != 27)
    goto LC; // [256] 272

    /** parser.e:3953					UndefinedVar( tok[T_SYM] )*/
    _2 = (object)SEQ_PTR(_tok_61346);
    _30461 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_30461);
    _45UndefinedVar(_30461);
    _30461 = NOVALUE;
LC: 

    /** parser.e:3955				StartSourceLine(TRUE)*/
    _47StartSourceLine(_13TRUE_447, 0, 2);

    /** parser.e:3956				Procedure_call(tok)*/
    Ref(_tok_61346);
    _45Procedure_call(_tok_61346);
    goto L9; // [286] 1115
LB: 

    /** parser.e:3958			elsif id = FUNC or id = QUALIFIED_FUNC then*/
    _30462 = (_id_61347 == 501);
    if (_30462 != 0) {
        goto LD; // [297] 312
    }
    _30464 = (_id_61347 == 520);
    if (_30464 == 0)
    {
        DeRef(_30464);
        _30464 = NOVALUE;
        goto LE; // [308] 362
    }
    else{
        DeRef(_30464);
        _30464 = NOVALUE;
    }
LD: 

    /** parser.e:3959				if id = FUNC then*/
    if (_id_61347 != 501)
    goto LF; // [316] 332

    /** parser.e:3961					UndefinedVar( tok[T_SYM] )*/
    _2 = (object)SEQ_PTR(_tok_61346);
    _30466 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_30466);
    _45UndefinedVar(_30466);
    _30466 = NOVALUE;
LF: 

    /** parser.e:3963				StartSourceLine(TRUE)*/
    _47StartSourceLine(_13TRUE_447, 0, 2);

    /** parser.e:3964				Procedure_call(tok)*/
    Ref(_tok_61346);
    _45Procedure_call(_tok_61346);

    /** parser.e:3965				clear_op()*/
    _47clear_op();

    /** parser.e:3966				if Pop() then end if*/
    _30467 = _47Pop();
    if (_30467 == 0) {
        DeRef(_30467);
        _30467 = NOVALUE;
        goto L9; // [355] 1115
    }
    else {
        if (!IS_ATOM_INT(_30467) && DBL_PTR(_30467)->dbl == 0.0){
            DeRef(_30467);
            _30467 = NOVALUE;
            goto L9; // [355] 1115
        }
        DeRef(_30467);
        _30467 = NOVALUE;
    }
    DeRef(_30467);
    _30467 = NOVALUE;
    goto L9; // [359] 1115
LE: 

    /** parser.e:3968			elsif id = IF then*/
    if (_id_61347 != 20)
    goto L10; // [366] 386

    /** parser.e:3969				StartSourceLine(TRUE)*/
    _47StartSourceLine(_13TRUE_447, 0, 2);

    /** parser.e:3970				If_statement()*/
    _45If_statement();
    goto L9; // [383] 1115
L10: 

    /** parser.e:3972			elsif id = FOR then*/
    if (_id_61347 != 21)
    goto L11; // [390] 410

    /** parser.e:3973				StartSourceLine(TRUE)*/
    _47StartSourceLine(_13TRUE_447, 0, 2);

    /** parser.e:3974				For_statement()*/
    _45For_statement();
    goto L9; // [407] 1115
L11: 

    /** parser.e:3976			elsif id = RETURN then*/
    if (_id_61347 != 413)
    goto L12; // [414] 434

    /** parser.e:3977				StartSourceLine(TRUE)*/
    _47StartSourceLine(_13TRUE_447, 0, 2);

    /** parser.e:3978				Return_statement()*/
    _45Return_statement();
    goto L9; // [431] 1115
L12: 

    /** parser.e:3980			elsif id = LABEL then*/
    if (_id_61347 != 419)
    goto L13; // [438] 460

    /** parser.e:3981				StartSourceLine(TRUE, , COVERAGE_SUPPRESS )*/
    _47StartSourceLine(_13TRUE_447, 0, 1);

    /** parser.e:3982				GLabel_statement()*/
    _45GLabel_statement();
    goto L9; // [457] 1115
L13: 

    /** parser.e:3984			elsif id = GOTO then*/
    if (_id_61347 != 188)
    goto L14; // [464] 484

    /** parser.e:3985				StartSourceLine(TRUE)*/
    _47StartSourceLine(_13TRUE_447, 0, 2);

    /** parser.e:3986				Goto_statement()*/
    _45Goto_statement();
    goto L9; // [481] 1115
L14: 

    /** parser.e:3988			elsif id = EXIT then*/
    if (_id_61347 != 61)
    goto L15; // [488] 508

    /** parser.e:3989				StartSourceLine(TRUE)*/
    _47StartSourceLine(_13TRUE_447, 0, 2);

    /** parser.e:3990				Exit_statement()*/
    _45Exit_statement();
    goto L9; // [505] 1115
L15: 

    /** parser.e:3992			elsif id = BREAK then*/
    if (_id_61347 != 425)
    goto L16; // [512] 532

    /** parser.e:3993				StartSourceLine(TRUE)*/
    _47StartSourceLine(_13TRUE_447, 0, 2);

    /** parser.e:3994				Break_statement()*/
    _45Break_statement();
    goto L9; // [529] 1115
L16: 

    /** parser.e:3996			elsif id = WHILE then*/
    if (_id_61347 != 47)
    goto L17; // [536] 556

    /** parser.e:3997				StartSourceLine(TRUE)*/
    _47StartSourceLine(_13TRUE_447, 0, 2);

    /** parser.e:3998				While_statement()*/
    _45While_statement();
    goto L9; // [553] 1115
L17: 

    /** parser.e:4000			elsif id = LOOP then*/
    if (_id_61347 != 422)
    goto L18; // [560] 580

    /** parser.e:4001			    StartSourceLine(TRUE)*/
    _47StartSourceLine(_13TRUE_447, 0, 2);

    /** parser.e:4002		        Loop_statement()*/
    _45Loop_statement();
    goto L9; // [577] 1115
L18: 

    /** parser.e:4004			elsif id = ENTRY then*/
    if (_id_61347 != 424)
    goto L19; // [584] 606

    /** parser.e:4005			    StartSourceLine(TRUE, , COVERAGE_SUPPRESS )*/
    _47StartSourceLine(_13TRUE_447, 0, 1);

    /** parser.e:4006			    Entry_statement()*/
    _45Entry_statement();
    goto L9; // [603] 1115
L19: 

    /** parser.e:4008			elsif id = QUESTION_MARK then*/
    if (_id_61347 != -31)
    goto L1A; // [610] 630

    /** parser.e:4009				StartSourceLine(TRUE)*/
    _47StartSourceLine(_13TRUE_447, 0, 2);

    /** parser.e:4010				Print_statement()*/
    _45Print_statement();
    goto L9; // [627] 1115
L1A: 

    /** parser.e:4012			elsif id = CONTINUE then*/
    if (_id_61347 != 426)
    goto L1B; // [634] 654

    /** parser.e:4013				StartSourceLine(TRUE)*/
    _47StartSourceLine(_13TRUE_447, 0, 2);

    /** parser.e:4014				Continue_statement()*/
    _45Continue_statement();
    goto L9; // [651] 1115
L1B: 

    /** parser.e:4016			elsif id = RETRY then*/
    if (_id_61347 != 184)
    goto L1C; // [658] 678

    /** parser.e:4017				StartSourceLine(TRUE)*/
    _47StartSourceLine(_13TRUE_447, 0, 2);

    /** parser.e:4018				Retry_statement()*/
    _45Retry_statement();
    goto L9; // [675] 1115
L1C: 

    /** parser.e:4020			elsif id = IFDEF then*/
    if (_id_61347 != 407)
    goto L1D; // [682] 702

    /** parser.e:4021				StartSourceLine(TRUE)*/
    _47StartSourceLine(_13TRUE_447, 0, 2);

    /** parser.e:4022				Ifdef_statement()*/
    _45Ifdef_statement();
    goto L9; // [699] 1115
L1D: 

    /** parser.e:4024			elsif id = CASE then*/
    if (_id_61347 != 186)
    goto L1E; // [706] 717

    /** parser.e:4025				Case_statement()*/
    _45Case_statement();
    goto L9; // [714] 1115
L1E: 

    /** parser.e:4027			elsif id = SWITCH then*/
    if (_id_61347 != 185)
    goto L1F; // [721] 741

    /** parser.e:4028				StartSourceLine(TRUE)*/
    _47StartSourceLine(_13TRUE_447, 0, 2);

    /** parser.e:4029				Switch_statement()*/
    _45Switch_statement();
    goto L9; // [738] 1115
L1F: 

    /** parser.e:4031			elsif id = FALLTHRU then*/
    if (_id_61347 != 431)
    goto L20; // [745] 756

    /** parser.e:4032				Fallthru_statement()*/
    _45Fallthru_statement();
    goto L9; // [753] 1115
L20: 

    /** parser.e:4034			elsif id = TYPE or id = QUALIFIED_TYPE then*/
    _30485 = (_id_61347 == 504);
    if (_30485 != 0) {
        goto L21; // [764] 779
    }
    _30487 = (_id_61347 == 522);
    if (_30487 == 0)
    {
        DeRef(_30487);
        _30487 = NOVALUE;
        goto L22; // [775] 904
    }
    else{
        DeRef(_30487);
        _30487 = NOVALUE;
    }
L21: 

    /** parser.e:4035				StartSourceLine(TRUE)*/
    _47StartSourceLine(_13TRUE_447, 0, 2);

    /** parser.e:4036				token test = next_token()*/
    _0 = _test_61519;
    _test_61519 = _45next_token();
    DeRef(_0);

    /** parser.e:4037				putback( test )*/
    Ref(_test_61519);
    _45putback(_test_61519);

    /** parser.e:4038				if test[T_ID] = LEFT_ROUND then*/
    _2 = (object)SEQ_PTR(_test_61519);
    _30489 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30489, -26)){
        _30489 = NOVALUE;
        goto L23; // [808] 852
    }
    _30489 = NOVALUE;

    /** parser.e:4039					StartSourceLine( TRUE )*/
    _47StartSourceLine(_13TRUE_447, 0, 2);

    /** parser.e:4040					Procedure_call(tok)*/
    Ref(_tok_61346);
    _45Procedure_call(_tok_61346);

    /** parser.e:4041					clear_op()*/
    _47clear_op();

    /** parser.e:4042					if Pop() then end if*/
    _30491 = _47Pop();
    if (_30491 == 0) {
        DeRef(_30491);
        _30491 = NOVALUE;
        goto L24; // [835] 839
    }
    else {
        if (!IS_ATOM_INT(_30491) && DBL_PTR(_30491)->dbl == 0.0){
            DeRef(_30491);
            _30491 = NOVALUE;
            goto L24; // [835] 839
        }
        DeRef(_30491);
        _30491 = NOVALUE;
    }
    DeRef(_30491);
    _30491 = NOVALUE;
L24: 

    /** parser.e:4043					ExecCommand()*/
    _45ExecCommand();

    /** parser.e:4044					continue*/
    DeRef(_test_61519);
    _test_61519 = NOVALUE;
    goto L1; // [847] 16
    goto L25; // [849] 899
L23: 

    /** parser.e:4047					if param_num != -1 then*/
    if (_45param_num_55365 == -1)
    goto L26; // [856] 882

    /** parser.e:4049						param_num += 1*/
    _45param_num_55365 = _45param_num_55365 + 1;

    /** parser.e:4050						Private_declaration( tok[T_SYM] )*/
    _2 = (object)SEQ_PTR(_tok_61346);
    _30494 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_30494);
    _45Private_declaration(_30494);
    _30494 = NOVALUE;
    goto L27; // [879] 898
L26: 

    /** parser.e:4052						Global_declaration( tok[T_SYM], SC_LOCAL )*/
    _2 = (object)SEQ_PTR(_tok_61346);
    _30495 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_30495);
    _30496 = _45Global_declaration(_30495, 5);
    _30495 = NOVALUE;
L27: 
L25: 
    DeRef(_test_61519);
    _test_61519 = NOVALUE;
    goto L9; // [901] 1115
L22: 

    /** parser.e:4055			elsif id = LEFT_BRACE then*/
    if (_id_61347 != -24)
    goto L28; // [908] 928

    /** parser.e:4056				StartSourceLine( TRUE )*/
    _47StartSourceLine(_13TRUE_447, 0, 2);

    /** parser.e:4057				Multi_assign()*/
    _45Multi_assign();
    goto L9; // [925] 1115
L28: 

    /** parser.e:4060				if id = ELSE then*/
    if (_id_61347 != 23)
    goto L29; // [932] 990

    /** parser.e:4061					if length(if_stack) = 0 then*/
    if (IS_SEQUENCE(_45if_stack_55391)){
            _30499 = SEQ_PTR(_45if_stack_55391)->length;
    }
    else {
        _30499 = 1;
    }
    if (_30499 != 0)
    goto L2A; // [943] 1051

    /** parser.e:4062						if live_ifdef > 0 then*/
    if (_45live_ifdef_59858 <= 0)
    goto L2B; // [951] 976

    /** parser.e:4063							CompileErr(SHOULD_THIS_BE_ELSEDEF_FOR_THE_IFDEF_ON_LINE_1, ifdef_lineno[$])*/
    if (IS_SEQUENCE(_45ifdef_lineno_59859)){
            _30502 = SEQ_PTR(_45ifdef_lineno_59859)->length;
    }
    else {
        _30502 = 1;
    }
    _2 = (object)SEQ_PTR(_45ifdef_lineno_59859);
    _30503 = (object)*(((s1_ptr)_2)->base + _30502);
    _50CompileErr(134, _30503, 0);
    _30503 = NOVALUE;
    goto L2A; // [973] 1051
L2B: 

    /** parser.e:4065							CompileErr(NOT_EXPECTING_ELSE)*/
    RefDS(_22190);
    _50CompileErr(118, _22190, 0);
    goto L2A; // [987] 1051
L29: 

    /** parser.e:4068				elsif id = ELSIF then*/
    if (_id_61347 != 414)
    goto L2C; // [994] 1050

    /** parser.e:4069					if length(if_stack) = 0 then*/
    if (IS_SEQUENCE(_45if_stack_55391)){
            _30505 = SEQ_PTR(_45if_stack_55391)->length;
    }
    else {
        _30505 = 1;
    }
    if (_30505 != 0)
    goto L2D; // [1005] 1049

    /** parser.e:4070						if live_ifdef > 0 then*/
    if (_45live_ifdef_59858 <= 0)
    goto L2E; // [1013] 1038

    /** parser.e:4071							CompileErr(SHOULD_THIS_BE_ELSIFDEF_FOR_THE_IFDEF_ON_LINE_1, ifdef_lineno[$])*/
    if (IS_SEQUENCE(_45ifdef_lineno_59859)){
            _30508 = SEQ_PTR(_45ifdef_lineno_59859)->length;
    }
    else {
        _30508 = 1;
    }
    _2 = (object)SEQ_PTR(_45ifdef_lineno_59859);
    _30509 = (object)*(((s1_ptr)_2)->base + _30508);
    _50CompileErr(139, _30509, 0);
    _30509 = NOVALUE;
    goto L2F; // [1035] 1048
L2E: 

    /** parser.e:4073							CompileErr(NOT_EXPECTING_ELSIF)*/
    RefDS(_22190);
    _50CompileErr(119, _22190, 0);
L2F: 
L2D: 
L2C: 
L2A: 

    /** parser.e:4078				putback( tok )*/
    Ref(_tok_61346);
    _45putback(_tok_61346);

    /** parser.e:4080				switch id do*/
    _0 = _id_61347;
    switch ( _0 ){ 

        /** parser.e:4081					case END, ELSEDEF, ELSIFDEF, ELSIF, ELSE, UNTIL then*/
        case 402:
        case 409:
        case 408:
        case 414:
        case 23:
        case 423:

        /** parser.e:4083						stmt_nest -= 1*/
        _45stmt_nest_55388 = _45stmt_nest_55388 - 1;

        /** parser.e:4084						InitDelete()*/
        _45InitDelete();

        /** parser.e:4085						flush_temps()*/
        RefDS(_22190);
        _47flush_temps(_22190);

        /** parser.e:4086						return*/
        DeRef(_tok_61346);
        DeRef(_30456);
        _30456 = NOVALUE;
        _30444 = NOVALUE;
        DeRef(_30485);
        _30485 = NOVALUE;
        DeRef(_30496);
        _30496 = NOVALUE;
        DeRef(_30457);
        _30457 = NOVALUE;
        DeRef(_30462);
        _30462 = NOVALUE;
        DeRef(_30441);
        _30441 = NOVALUE;
        return;
        goto L30; // [1099] 1114

        /** parser.e:4088					case else*/
        default:

        /** parser.e:4089						tok_match( END )*/
        _45tok_match(402, 0);
    ;}L30: 
L9: 

    /** parser.e:4094			flush_temps()*/
    RefDS(_22190);
    _47flush_temps(_22190);

    /** parser.e:4095		end while*/
    goto L1; // [1122] 16
L2: 

    /** parser.e:4096	end procedure*/
    DeRef(_tok_61346);
    DeRef(_30456);
    _30456 = NOVALUE;
    _30444 = NOVALUE;
    DeRef(_30485);
    _30485 = NOVALUE;
    DeRef(_30496);
    _30496 = NOVALUE;
    DeRef(_30457);
    _30457 = NOVALUE;
    DeRef(_30462);
    _30462 = NOVALUE;
    DeRef(_30441);
    _30441 = NOVALUE;
    return;
    ;
}


void _45SubProg(object _prog_type_61598, object _scope_61599, object _deprecated_61600)
{
    object _h_61601 = NOVALUE;
    object _pt_61602 = NOVALUE;
    object _p_61604 = NOVALUE;
    object _type_sym_61605 = NOVALUE;
    object _sym_61606 = NOVALUE;
    object _tok_61608 = NOVALUE;
    object _prog_name_61609 = NOVALUE;
    object _first_def_arg_61610 = NOVALUE;
    object _again_61611 = NOVALUE;
    object _type_enum_61612 = NOVALUE;
    object _seq_sym_61613 = NOVALUE;
    object _i1_sym_61614 = NOVALUE;
    object _enum_syms_61615 = NOVALUE;
    object _type_enum_gline_61616 = NOVALUE;
    object _real_gline_61617 = NOVALUE;
    object _tsym_61629 = NOVALUE;
    object _seq_symbol_61640 = NOVALUE;
    object _middle_def_args_61845 = NOVALUE;
    object _last_nda_61846 = NOVALUE;
    object _start_def_61847 = NOVALUE;
    object _last_link_61849 = NOVALUE;
    object _temptok_61876 = NOVALUE;
    object _undef_type_61878 = NOVALUE;
    object _tokcat_61930 = NOVALUE;
    object _31952 = NOVALUE;
    object _31951 = NOVALUE;
    object _31950 = NOVALUE;
    object _31949 = NOVALUE;
    object _31948 = NOVALUE;
    object _31947 = NOVALUE;
    object _31946 = NOVALUE;
    object _31945 = NOVALUE;
    object _31944 = NOVALUE;
    object _30775 = NOVALUE;
    object _30773 = NOVALUE;
    object _30772 = NOVALUE;
    object _30770 = NOVALUE;
    object _30769 = NOVALUE;
    object _30768 = NOVALUE;
    object _30767 = NOVALUE;
    object _30766 = NOVALUE;
    object _30764 = NOVALUE;
    object _30763 = NOVALUE;
    object _30760 = NOVALUE;
    object _30759 = NOVALUE;
    object _30758 = NOVALUE;
    object _30757 = NOVALUE;
    object _30755 = NOVALUE;
    object _30746 = NOVALUE;
    object _30744 = NOVALUE;
    object _30743 = NOVALUE;
    object _30742 = NOVALUE;
    object _30741 = NOVALUE;
    object _30738 = NOVALUE;
    object _30737 = NOVALUE;
    object _30736 = NOVALUE;
    object _30734 = NOVALUE;
    object _30731 = NOVALUE;
    object _30730 = NOVALUE;
    object _30729 = NOVALUE;
    object _30727 = NOVALUE;
    object _30726 = NOVALUE;
    object _30723 = NOVALUE;
    object _30721 = NOVALUE;
    object _30719 = NOVALUE;
    object _30718 = NOVALUE;
    object _30717 = NOVALUE;
    object _30716 = NOVALUE;
    object _30714 = NOVALUE;
    object _30713 = NOVALUE;
    object _30712 = NOVALUE;
    object _30711 = NOVALUE;
    object _30710 = NOVALUE;
    object _30709 = NOVALUE;
    object _30706 = NOVALUE;
    object _30704 = NOVALUE;
    object _30702 = NOVALUE;
    object _30700 = NOVALUE;
    object _30698 = NOVALUE;
    object _30695 = NOVALUE;
    object _30693 = NOVALUE;
    object _30692 = NOVALUE;
    object _30689 = NOVALUE;
    object _30685 = NOVALUE;
    object _30684 = NOVALUE;
    object _30682 = NOVALUE;
    object _30680 = NOVALUE;
    object _30678 = NOVALUE;
    object _30676 = NOVALUE;
    object _30674 = NOVALUE;
    object _30672 = NOVALUE;
    object _30671 = NOVALUE;
    object _30670 = NOVALUE;
    object _30669 = NOVALUE;
    object _30668 = NOVALUE;
    object _30667 = NOVALUE;
    object _30666 = NOVALUE;
    object _30665 = NOVALUE;
    object _30664 = NOVALUE;
    object _30663 = NOVALUE;
    object _30662 = NOVALUE;
    object _30661 = NOVALUE;
    object _30658 = NOVALUE;
    object _30657 = NOVALUE;
    object _30656 = NOVALUE;
    object _30655 = NOVALUE;
    object _30654 = NOVALUE;
    object _30653 = NOVALUE;
    object _30652 = NOVALUE;
    object _30651 = NOVALUE;
    object _30650 = NOVALUE;
    object _30649 = NOVALUE;
    object _30648 = NOVALUE;
    object _30647 = NOVALUE;
    object _30646 = NOVALUE;
    object _30645 = NOVALUE;
    object _30644 = NOVALUE;
    object _30642 = NOVALUE;
    object _30640 = NOVALUE;
    object _30639 = NOVALUE;
    object _30634 = NOVALUE;
    object _30633 = NOVALUE;
    object _30631 = NOVALUE;
    object _30630 = NOVALUE;
    object _30629 = NOVALUE;
    object _30628 = NOVALUE;
    object _30627 = NOVALUE;
    object _30626 = NOVALUE;
    object _30625 = NOVALUE;
    object _30624 = NOVALUE;
    object _30623 = NOVALUE;
    object _30622 = NOVALUE;
    object _30620 = NOVALUE;
    object _30619 = NOVALUE;
    object _30617 = NOVALUE;
    object _30616 = NOVALUE;
    object _30615 = NOVALUE;
    object _30614 = NOVALUE;
    object _30613 = NOVALUE;
    object _30612 = NOVALUE;
    object _30611 = NOVALUE;
    object _30609 = NOVALUE;
    object _30606 = NOVALUE;
    object _30604 = NOVALUE;
    object _30602 = NOVALUE;
    object _30600 = NOVALUE;
    object _30598 = NOVALUE;
    object _30596 = NOVALUE;
    object _30594 = NOVALUE;
    object _30592 = NOVALUE;
    object _30590 = NOVALUE;
    object _30588 = NOVALUE;
    object _30587 = NOVALUE;
    object _30586 = NOVALUE;
    object _30585 = NOVALUE;
    object _30584 = NOVALUE;
    object _30583 = NOVALUE;
    object _30582 = NOVALUE;
    object _30580 = NOVALUE;
    object _30579 = NOVALUE;
    object _30577 = NOVALUE;
    object _30575 = NOVALUE;
    object _30573 = NOVALUE;
    object _30572 = NOVALUE;
    object _30569 = NOVALUE;
    object _30568 = NOVALUE;
    object _30567 = NOVALUE;
    object _30566 = NOVALUE;
    object _30565 = NOVALUE;
    object _30563 = NOVALUE;
    object _30562 = NOVALUE;
    object _30561 = NOVALUE;
    object _30560 = NOVALUE;
    object _30559 = NOVALUE;
    object _30557 = NOVALUE;
    object _30556 = NOVALUE;
    object _30555 = NOVALUE;
    object _30553 = NOVALUE;
    object _30552 = NOVALUE;
    object _30551 = NOVALUE;
    object _30550 = NOVALUE;
    object _30546 = NOVALUE;
    object _30545 = NOVALUE;
    object _30544 = NOVALUE;
    object _30542 = NOVALUE;
    object _30541 = NOVALUE;
    object _30540 = NOVALUE;
    object _30539 = NOVALUE;
    object _30538 = NOVALUE;
    object _30537 = NOVALUE;
    object _30533 = NOVALUE;
    object _30532 = NOVALUE;
    object _30531 = NOVALUE;
    object _30529 = NOVALUE;
    object _30528 = NOVALUE;
    object _30527 = NOVALUE;
    object _30525 = NOVALUE;
    object _30524 = NOVALUE;
    object _30522 = NOVALUE;
    object _30521 = NOVALUE;
    object _30520 = NOVALUE;
    object _30516 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_prog_type_61598)) {
        _1 = (object)(DBL_PTR(_prog_type_61598)->dbl);
        DeRefDS(_prog_type_61598);
        _prog_type_61598 = _1;
    }

    /** parser.e:4105		integer first_def_arg*/

    /** parser.e:4106		integer again*/

    /** parser.e:4107		integer type_enum*/

    /** parser.e:4108		object seq_sym*/

    /** parser.e:4109		object i1_sym*/

    /** parser.e:4110		sequence enum_syms = {}*/
    RefDS(_22190);
    DeRef(_enum_syms_61615);
    _enum_syms_61615 = _22190;

    /** parser.e:4111		integer type_enum_gline, real_gline*/

    /** parser.e:4113		LeaveTopLevel()*/
    _45LeaveTopLevel();

    /** parser.e:4114		prog_name = next_token()*/
    _0 = _prog_name_61609;
    _prog_name_61609 = _45next_token();
    DeRef(_0);

    /** parser.e:4115		if prog_name[T_ID] = END_OF_FILE then*/
    _2 = (object)SEQ_PTR(_prog_name_61609);
    _30516 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30516, -21)){
        _30516 = NOVALUE;
        goto L1; // [45] 59
    }
    _30516 = NOVALUE;

    /** parser.e:4116			CompileErr( AN_IDENTIFIER_IS_EXPECTED_HERE)*/
    RefDS(_22190);
    _50CompileErr(32, _22190, 0);
L1: 

    /** parser.e:4118		type_enum =  0*/
    _type_enum_61612 = 0;

    /** parser.e:4119		if prog_type = TYPE_DECL then*/
    if (_prog_type_61598 != 416)
    goto L2; // [68] 322

    /** parser.e:4120			object tsym = prog_name[T_SYM]*/
    DeRef(_tsym_61629);
    _2 = (object)SEQ_PTR(_prog_name_61609);
    _tsym_61629 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_tsym_61629);

    /** parser.e:4121			if equal(sym_name(prog_name[T_SYM]),"enum") then*/
    _2 = (object)SEQ_PTR(_prog_name_61609);
    _30520 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_30520);
    _30521 = _54sym_name(_30520);
    _30520 = NOVALUE;
    if (_30521 == _26455)
    _30522 = 1;
    else if (IS_ATOM_INT(_30521) && IS_ATOM_INT(_26455))
    _30522 = 0;
    else
    _30522 = (compare(_30521, _26455) == 0);
    DeRef(_30521);
    _30521 = NOVALUE;
    if (_30522 == 0)
    {
        _30522 = NOVALUE;
        goto L3; // [96] 319
    }
    else{
        _30522 = NOVALUE;
    }

    /** parser.e:4125				EnterTopLevel( FALSE )*/
    _45EnterTopLevel(_13FALSE_445);

    /** parser.e:4126				type_enum_gline = gline_number*/
    _type_enum_gline_61616 = _36gline_number_21772;

    /** parser.e:4127				type_enum = 1*/
    _type_enum_61612 = 1;

    /** parser.e:4128				sequence seq_symbol*/

    /** parser.e:4129				prog_name = next_token()*/
    _0 = _prog_name_61609;
    _prog_name_61609 = _45next_token();
    DeRef(_0);

    /** parser.e:4130				if not find(prog_name[T_ID], ADDR_TOKS) then*/
    _2 = (object)SEQ_PTR(_prog_name_61609);
    _30524 = (object)*(((s1_ptr)_2)->base + 1);
    _30525 = find_from(_30524, _38ADDR_TOKS_16295, 1);
    _30524 = NOVALUE;
    if (_30525 != 0)
    goto L4; // [142] 169
    _30525 = NOVALUE;

    /** parser.e:4131					CompileErr(FOUND__1__BUT_WAS_EXPECTING_AN_IDENTIFIER_NAME, {find_category(prog_name[T_ID])} )*/
    _2 = (object)SEQ_PTR(_prog_name_61609);
    _30527 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_30527);
    _30528 = _63find_category(_30527);
    _30527 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _30528;
    _30529 = MAKE_SEQ(_1);
    _30528 = NOVALUE;
    _50CompileErr(25, _30529, 0);
    _30529 = NOVALUE;
L4: 

    /** parser.e:4133				enum_syms = Global_declaration(-1, scope)*/
    _0 = _enum_syms_61615;
    _enum_syms_61615 = _45Global_declaration(-1, _scope_61599);
    DeRef(_0);

    /** parser.e:4134				seq_symbol = enum_syms*/
    RefDS(_enum_syms_61615);
    DeRef(_seq_symbol_61640);
    _seq_symbol_61640 = _enum_syms_61615;

    /** parser.e:4135				for i = 1 to length( enum_syms ) do*/
    if (IS_SEQUENCE(_enum_syms_61615)){
            _30531 = SEQ_PTR(_enum_syms_61615)->length;
    }
    else {
        _30531 = 1;
    }
    {
        object _i_61657;
        _i_61657 = 1;
L5: 
        if (_i_61657 > _30531){
            goto L6; // [190] 218
        }

        /** parser.e:4136					seq_symbol[i] = sym_obj(enum_syms[i])*/
        _2 = (object)SEQ_PTR(_enum_syms_61615);
        _30532 = (object)*(((s1_ptr)_2)->base + _i_61657);
        Ref(_30532);
        _30533 = _54sym_obj(_30532);
        _30532 = NOVALUE;
        _2 = (object)SEQ_PTR(_seq_symbol_61640);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _seq_symbol_61640 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_61657);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _30533;
        if( _1 != _30533 ){
            DeRef(_1);
        }
        _30533 = NOVALUE;

        /** parser.e:4137				end for*/
        _i_61657 = _i_61657 + 1;
        goto L5; // [213] 197
L6: 
        ;
    }

    /** parser.e:4142				i1_sym = keyfind("i1",-1)*/
    RefDS(_30534);
    DeRef(_31951);
    _31951 = _30534;
    _31952 = _54hashfn(_31951);
    _31951 = NOVALUE;
    RefDS(_30534);
    _0 = _i1_sym_61614;
    _i1_sym_61614 = _54keyfind(_30534, -1, _36current_file_no_21767, 0, _31952);
    DeRef(_0);
    _31952 = NOVALUE;

    /** parser.e:4143				seq_sym = NewStringSym(seq_symbol)*/
    RefDS(_seq_symbol_61640);
    _0 = _seq_sym_61613;
    _seq_sym_61613 = _54NewStringSym(_seq_symbol_61640);
    DeRef(_0);

    /** parser.e:4144				putback(keyfind("return",-1))*/
    RefDS(_26529);
    DeRef(_31949);
    _31949 = _26529;
    _31950 = _54hashfn(_31949);
    _31949 = NOVALUE;
    RefDS(_26529);
    _30537 = _54keyfind(_26529, -1, _36current_file_no_21767, 0, _31950);
    _31950 = NOVALUE;
    _45putback(_30537);
    _30537 = NOVALUE;

    /** parser.e:4145				putback({RIGHT_ROUND,0})*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -27;
    ((intptr_t *)_2)[2] = 0;
    _30538 = MAKE_SEQ(_1);
    _45putback(_30538);
    _30538 = NOVALUE;

    /** parser.e:4146				putback(i1_sym)*/
    Ref(_i1_sym_61614);
    _45putback(_i1_sym_61614);

    /** parser.e:4147				putback(keyfind("object",-1))*/
    RefDS(_23147);
    DeRef(_31947);
    _31947 = _23147;
    _31948 = _54hashfn(_31947);
    _31947 = NOVALUE;
    RefDS(_23147);
    _30539 = _54keyfind(_23147, -1, _36current_file_no_21767, 0, _31948);
    _31948 = NOVALUE;
    _45putback(_30539);
    _30539 = NOVALUE;

    /** parser.e:4148				putback({LEFT_ROUND,0})*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -26;
    ((intptr_t *)_2)[2] = 0;
    _30540 = MAKE_SEQ(_1);
    _45putback(_30540);
    _30540 = NOVALUE;

    /** parser.e:4150				LeaveTopLevel()*/
    _45LeaveTopLevel();
L3: 
    DeRef(_seq_symbol_61640);
    _seq_symbol_61640 = NOVALUE;
L2: 
    DeRef(_tsym_61629);
    _tsym_61629 = NOVALUE;

    /** parser.e:4153		if not find(prog_name[T_ID], ADDR_TOKS) then*/
    _2 = (object)SEQ_PTR(_prog_name_61609);
    _30541 = (object)*(((s1_ptr)_2)->base + 1);
    _30542 = find_from(_30541, _38ADDR_TOKS_16295, 1);
    _30541 = NOVALUE;
    if (_30542 != 0)
    goto L7; // [339] 366
    _30542 = NOVALUE;

    /** parser.e:4154			CompileErr(FOUND__1__BUT_WAS_EXPECTING_AN_IDENTIFIER_NAME, {find_category(prog_name[T_ID])} )*/
    _2 = (object)SEQ_PTR(_prog_name_61609);
    _30544 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_30544);
    _30545 = _63find_category(_30544);
    _30544 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _30545;
    _30546 = MAKE_SEQ(_1);
    _30545 = NOVALUE;
    _50CompileErr(25, _30546, 0);
    _30546 = NOVALUE;
L7: 

    /** parser.e:4156		p = prog_name[T_SYM]*/
    _2 = (object)SEQ_PTR(_prog_name_61609);
    _p_61604 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_p_61604)){
        _p_61604 = (object)DBL_PTR(_p_61604)->dbl;
    }

    /** parser.e:4157		DefinedYet(p)*/
    _54DefinedYet(_p_61604);

    /** parser.e:4158		if prog_type = PROCEDURE then*/
    if (_prog_type_61598 != 405)
    goto L8; // [385] 401

    /** parser.e:4159			pt = PROC*/
    _pt_61602 = 27;
    goto L9; // [398] 431
L8: 

    /** parser.e:4160		elsif prog_type = FUNCTION then*/
    if (_prog_type_61598 != 406)
    goto LA; // [405] 421

    /** parser.e:4161			pt = FUNC*/
    _pt_61602 = 501;
    goto L9; // [418] 431
LA: 

    /** parser.e:4163			pt = TYPE*/
    _pt_61602 = 504;
L9: 

    /** parser.e:4166		clear_fwd_refs()*/
    _44clear_fwd_refs();

    /** parser.e:4167		if find(SymTab[p][S_SCOPE], {SC_PREDEF, SC_GLOBAL, SC_PUBLIC, SC_EXPORT, SC_OVERRIDE}) then*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _30550 = (object)*(((s1_ptr)_2)->base + _p_61604);
    _2 = (object)SEQ_PTR(_30550);
    _30551 = (object)*(((s1_ptr)_2)->base + 4);
    _30550 = NOVALUE;
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 7;
    ((intptr_t*)_2)[2] = 6;
    ((intptr_t*)_2)[3] = 13;
    ((intptr_t*)_2)[4] = 11;
    ((intptr_t*)_2)[5] = 12;
    _30552 = MAKE_SEQ(_1);
    _30553 = find_from(_30551, _30552, 1);
    _30551 = NOVALUE;
    DeRefDS(_30552);
    _30552 = NOVALUE;
    if (_30553 == 0)
    {
        _30553 = NOVALUE;
        goto LB; // [472] 668
    }
    else{
        _30553 = NOVALUE;
    }

    /** parser.e:4169			if scope = SC_OVERRIDE then*/
    if (_scope_61599 != 12)
    goto LC; // [479] 605

    /** parser.e:4170				if SymTab[p][S_SCOPE] = SC_PREDEF or SymTab[p][S_SCOPE] = SC_OVERRIDE then*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _30555 = (object)*(((s1_ptr)_2)->base + _p_61604);
    _2 = (object)SEQ_PTR(_30555);
    _30556 = (object)*(((s1_ptr)_2)->base + 4);
    _30555 = NOVALUE;
    if (IS_ATOM_INT(_30556)) {
        _30557 = (_30556 == 7);
    }
    else {
        _30557 = binary_op(EQUALS, _30556, 7);
    }
    _30556 = NOVALUE;
    if (IS_ATOM_INT(_30557)) {
        if (_30557 != 0) {
            goto LD; // [503] 530
        }
    }
    else {
        if (DBL_PTR(_30557)->dbl != 0.0) {
            goto LD; // [503] 530
        }
    }
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _30559 = (object)*(((s1_ptr)_2)->base + _p_61604);
    _2 = (object)SEQ_PTR(_30559);
    _30560 = (object)*(((s1_ptr)_2)->base + 4);
    _30559 = NOVALUE;
    if (IS_ATOM_INT(_30560)) {
        _30561 = (_30560 == 12);
    }
    else {
        _30561 = binary_op(EQUALS, _30560, 12);
    }
    _30560 = NOVALUE;
    if (_30561 == 0) {
        DeRef(_30561);
        _30561 = NOVALUE;
        goto LE; // [526] 604
    }
    else {
        if (!IS_ATOM_INT(_30561) && DBL_PTR(_30561)->dbl == 0.0){
            DeRef(_30561);
            _30561 = NOVALUE;
            goto LE; // [526] 604
        }
        DeRef(_30561);
        _30561 = NOVALUE;
    }
    DeRef(_30561);
    _30561 = NOVALUE;
LD: 

    /** parser.e:4171						if SymTab[p][S_SCOPE] = SC_OVERRIDE then*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _30562 = (object)*(((s1_ptr)_2)->base + _p_61604);
    _2 = (object)SEQ_PTR(_30562);
    _30563 = (object)*(((s1_ptr)_2)->base + 4);
    _30562 = NOVALUE;
    if (binary_op_a(NOTEQ, _30563, 12)){
        _30563 = NOVALUE;
        goto LF; // [546] 558
    }
    _30563 = NOVALUE;

    /** parser.e:4172							again = 223*/
    _again_61611 = 223;
    goto L10; // [555] 564
LF: 

    /** parser.e:4174							again = 222*/
    _again_61611 = 222;
L10: 

    /** parser.e:4176						Warning(again, override_warning_flag,*/
    _2 = (object)SEQ_PTR(_37known_files_15638);
    _30565 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21767);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _30566 = (object)*(((s1_ptr)_2)->base + _p_61604);
    _2 = (object)SEQ_PTR(_30566);
    if (!IS_ATOM_INT(_36S_NAME_21404)){
        _30567 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21404)->dbl));
    }
    else{
        _30567 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21404);
    }
    _30566 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_30565);
    ((intptr_t*)_2)[1] = _30565;
    ((intptr_t*)_2)[2] = _36line_number_21768;
    Ref(_30567);
    ((intptr_t*)_2)[3] = _30567;
    _30568 = MAKE_SEQ(_1);
    _30567 = NOVALUE;
    _30565 = NOVALUE;
    _50Warning(_again_61611, 4, _30568);
    _30568 = NOVALUE;
LE: 
LC: 

    /** parser.e:4181			h = SymTab[p][S_HASHVAL]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _30569 = (object)*(((s1_ptr)_2)->base + _p_61604);
    _2 = (object)SEQ_PTR(_30569);
    _h_61601 = (object)*(((s1_ptr)_2)->base + 11);
    if (!IS_ATOM_INT(_h_61601)){
        _h_61601 = (object)DBL_PTR(_h_61601)->dbl;
    }
    _30569 = NOVALUE;

    /** parser.e:4182			sym = buckets[h]*/
    _2 = (object)SEQ_PTR(_54buckets_47132);
    _sym_61606 = (object)*(((s1_ptr)_2)->base + _h_61601);
    if (!IS_ATOM_INT(_sym_61606)){
        _sym_61606 = (object)DBL_PTR(_sym_61606)->dbl;
    }

    /** parser.e:4183			p = NewEntry(SymTab[p][S_NAME], 0, 0, pt, h, sym, 0)*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _30572 = (object)*(((s1_ptr)_2)->base + _p_61604);
    _2 = (object)SEQ_PTR(_30572);
    if (!IS_ATOM_INT(_36S_NAME_21404)){
        _30573 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21404)->dbl));
    }
    else{
        _30573 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21404);
    }
    _30572 = NOVALUE;
    Ref(_30573);
    _p_61604 = _54NewEntry(_30573, 0, 0, _pt_61602, _h_61601, _sym_61606, 0);
    _30573 = NOVALUE;
    if (!IS_ATOM_INT(_p_61604)) {
        _1 = (object)(DBL_PTR(_p_61604)->dbl);
        DeRefDS(_p_61604);
        _p_61604 = _1;
    }

    /** parser.e:4184			buckets[h] = p*/
    _2 = (object)SEQ_PTR(_54buckets_47132);
    _2 = (object)(((s1_ptr)_2)->base + _h_61601);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _p_61604;
    DeRef(_1);
LB: 

    /** parser.e:4187		Start_block( pt, p )*/
    _65Start_block(_pt_61602, _p_61604);

    /** parser.e:4189		CurrentSub = p*/
    _36CurrentSub_21775 = _p_61604;

    /** parser.e:4190		first_def_arg = 0*/
    _first_def_arg_61610 = 0;

    /** parser.e:4191		temps_allocated = 0*/
    _54temps_allocated_47667 = 0;

    /** parser.e:4193		SymTab[p][S_SCOPE] = scope*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_61604 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _scope_61599;
    DeRef(_1);
    _30575 = NOVALUE;

    /** parser.e:4195		SymTab[p][S_TOKEN] = pt*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_61604 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_TOKEN_21409))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21409)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_TOKEN_21409);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _pt_61602;
    DeRef(_1);
    _30577 = NOVALUE;

    /** parser.e:4197		if length(SymTab[p]) < SIZEOF_ROUTINE_ENTRY then*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _30579 = (object)*(((s1_ptr)_2)->base + _p_61604);
    if (IS_SEQUENCE(_30579)){
            _30580 = SEQ_PTR(_30579)->length;
    }
    else {
        _30580 = 1;
    }
    _30579 = NOVALUE;
    if (_30580 >= _36SIZEOF_ROUTINE_ENTRY_21530)
    goto L11; // [738] 780

    /** parser.e:4199			SymTab[p] = SymTab[p] & repeat(0, SIZEOF_ROUTINE_ENTRY -*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _30582 = (object)*(((s1_ptr)_2)->base + _p_61604);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _30583 = (object)*(((s1_ptr)_2)->base + _p_61604);
    if (IS_SEQUENCE(_30583)){
            _30584 = SEQ_PTR(_30583)->length;
    }
    else {
        _30584 = 1;
    }
    _30583 = NOVALUE;
    _30585 = _36SIZEOF_ROUTINE_ENTRY_21530 - _30584;
    _30584 = NOVALUE;
    _30586 = Repeat(0, _30585);
    _30585 = NOVALUE;
    if (IS_SEQUENCE(_30582) && IS_ATOM(_30586)) {
    }
    else if (IS_ATOM(_30582) && IS_SEQUENCE(_30586)) {
        Ref(_30582);
        Prepend(&_30587, _30586, _30582);
    }
    else {
        Concat((object_ptr)&_30587, _30582, _30586);
        _30582 = NOVALUE;
    }
    _30582 = NOVALUE;
    DeRefDS(_30586);
    _30586 = NOVALUE;
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _p_61604);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30587;
    if( _1 != _30587 ){
        DeRef(_1);
    }
    _30587 = NOVALUE;
L11: 

    /** parser.e:4203		SymTab[p][S_CODE] = 0*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_61604 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_CODE_21416))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21416)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_CODE_21416);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);
    _30588 = NOVALUE;

    /** parser.e:4204		SymTab[p][S_LINETAB] = 0*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_61604 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_LINETAB_21439))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_LINETAB_21439)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_LINETAB_21439);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);
    _30590 = NOVALUE;

    /** parser.e:4205		SymTab[p][S_EFFECT] = E_PURE*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_61604 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 23);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);
    _30592 = NOVALUE;

    /** parser.e:4206		SymTab[p][S_REFLIST] = {}*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_61604 + ((s1_ptr)_2)->base);
    RefDS(_22190);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 24);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22190;
    DeRef(_1);
    _30594 = NOVALUE;

    /** parser.e:4207		SymTab[p][S_FIRSTLINE] = gline_number*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_61604 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_FIRSTLINE_21444))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FIRSTLINE_21444)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_FIRSTLINE_21444);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36gline_number_21772;
    DeRef(_1);
    _30596 = NOVALUE;

    /** parser.e:4208		SymTab[p][S_TEMPS] = 0*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_61604 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_TEMPS_21449))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TEMPS_21449)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_TEMPS_21449);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);
    _30598 = NOVALUE;

    /** parser.e:4209		SymTab[p][S_RESIDENT_TASK] = 0*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_61604 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 25);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);
    _30600 = NOVALUE;

    /** parser.e:4210		SymTab[p][S_SAVED_PRIVATES] = {}*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_61604 + ((s1_ptr)_2)->base);
    RefDS(_22190);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 26);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22190;
    DeRef(_1);
    _30602 = NOVALUE;

    /** parser.e:4211		SymTab[p][S_DEPRECATED] = deprecated*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_61604 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 30);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _deprecated_61600;
    DeRef(_1);
    _30604 = NOVALUE;

    /** parser.e:4213		if type_enum then*/
    if (_type_enum_61612 == 0)
    {
        goto L12; // [921] 978
    }
    else{
    }

    /** parser.e:4214			SymTab[p][S_FIRSTLINE] = type_enum_gline*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_61604 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_FIRSTLINE_21444))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FIRSTLINE_21444)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_FIRSTLINE_21444);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _type_enum_gline_61616;
    DeRef(_1);
    _30606 = NOVALUE;

    /** parser.e:4215			real_gline = gline_number*/
    _real_gline_61617 = _36gline_number_21772;

    /** parser.e:4216			gline_number = type_enum_gline*/
    _36gline_number_21772 = _type_enum_gline_61616;

    /** parser.e:4217			StartSourceLine( FALSE, , COVERAGE_OVERRIDE )*/
    _47StartSourceLine(_13FALSE_445, 0, 3);

    /** parser.e:4218			gline_number = real_gline*/
    _36gline_number_21772 = _real_gline_61617;
    goto L13; // [975] 990
L12: 

    /** parser.e:4220			StartSourceLine(FALSE, , COVERAGE_OVERRIDE)*/
    _47StartSourceLine(_13FALSE_445, 0, 3);
L13: 

    /** parser.e:4223		tok_match(LEFT_ROUND)*/
    _45tok_match(-26, 0);

    /** parser.e:4224		tok = next_token()*/
    _0 = _tok_61608;
    _tok_61608 = _45next_token();
    DeRef(_0);

    /** parser.e:4225		param_num = 0*/
    _45param_num_55365 = 0;

    /** parser.e:4228		sequence middle_def_args = {}*/
    RefDS(_22190);
    DeRef(_middle_def_args_61845);
    _middle_def_args_61845 = _22190;

    /** parser.e:4229		integer last_nda = 0, start_def = 0*/
    _last_nda_61846 = 0;
    _start_def_61847 = 0;

    /** parser.e:4230		symtab_index last_link = p*/
    _last_link_61849 = _p_61604;

    /** parser.e:4231		while tok[T_ID] != RIGHT_ROUND do*/
L14: 
    _2 = (object)SEQ_PTR(_tok_61608);
    _30609 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _30609, -27)){
        _30609 = NOVALUE;
        goto L15; // [1043] 1830
    }
    _30609 = NOVALUE;

    /** parser.e:4234			if tok[T_ID] != TYPE and tok[T_ID] != QUALIFIED_TYPE then*/
    _2 = (object)SEQ_PTR(_tok_61608);
    _30611 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_30611)) {
        _30612 = (_30611 != 504);
    }
    else {
        _30612 = binary_op(NOTEQ, _30611, 504);
    }
    _30611 = NOVALUE;
    if (IS_ATOM_INT(_30612)) {
        if (_30612 == 0) {
            goto L16; // [1061] 1291
        }
    }
    else {
        if (DBL_PTR(_30612)->dbl == 0.0) {
            goto L16; // [1061] 1291
        }
    }
    _2 = (object)SEQ_PTR(_tok_61608);
    _30614 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_30614)) {
        _30615 = (_30614 != 522);
    }
    else {
        _30615 = binary_op(NOTEQ, _30614, 522);
    }
    _30614 = NOVALUE;
    if (_30615 == 0) {
        DeRef(_30615);
        _30615 = NOVALUE;
        goto L16; // [1078] 1291
    }
    else {
        if (!IS_ATOM_INT(_30615) && DBL_PTR(_30615)->dbl == 0.0){
            DeRef(_30615);
            _30615 = NOVALUE;
            goto L16; // [1078] 1291
        }
        DeRef(_30615);
        _30615 = NOVALUE;
    }
    DeRef(_30615);
    _30615 = NOVALUE;

    /** parser.e:4235				if tok[T_ID] = VARIABLE or tok[T_ID] = QUALIFIED_VARIABLE then*/
    _2 = (object)SEQ_PTR(_tok_61608);
    _30616 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_30616)) {
        _30617 = (_30616 == -100);
    }
    else {
        _30617 = binary_op(EQUALS, _30616, -100);
    }
    _30616 = NOVALUE;
    if (IS_ATOM_INT(_30617)) {
        if (_30617 != 0) {
            goto L17; // [1095] 1116
        }
    }
    else {
        if (DBL_PTR(_30617)->dbl != 0.0) {
            goto L17; // [1095] 1116
        }
    }
    _2 = (object)SEQ_PTR(_tok_61608);
    _30619 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_30619)) {
        _30620 = (_30619 == 512);
    }
    else {
        _30620 = binary_op(EQUALS, _30619, 512);
    }
    _30619 = NOVALUE;
    if (_30620 == 0) {
        DeRef(_30620);
        _30620 = NOVALUE;
        goto L18; // [1112] 1280
    }
    else {
        if (!IS_ATOM_INT(_30620) && DBL_PTR(_30620)->dbl == 0.0){
            DeRef(_30620);
            _30620 = NOVALUE;
            goto L18; // [1112] 1280
        }
        DeRef(_30620);
        _30620 = NOVALUE;
    }
    DeRef(_30620);
    _30620 = NOVALUE;
L17: 

    /** parser.e:4237					token temptok = next_token()*/
    _0 = _temptok_61876;
    _temptok_61876 = _45next_token();
    DeRef(_0);

    /** parser.e:4238					integer undef_type = 0*/
    _undef_type_61878 = 0;

    /** parser.e:4239					if temptok[T_ID] != TYPE and temptok[T_ID] != QUALIFIED_TYPE then*/
    _2 = (object)SEQ_PTR(_temptok_61876);
    _30622 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_30622)) {
        _30623 = (_30622 != 504);
    }
    else {
        _30623 = binary_op(NOTEQ, _30622, 504);
    }
    _30622 = NOVALUE;
    if (IS_ATOM_INT(_30623)) {
        if (_30623 == 0) {
            goto L19; // [1140] 1243
        }
    }
    else {
        if (DBL_PTR(_30623)->dbl == 0.0) {
            goto L19; // [1140] 1243
        }
    }
    _2 = (object)SEQ_PTR(_temptok_61876);
    _30625 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_30625)) {
        _30626 = (_30625 != 522);
    }
    else {
        _30626 = binary_op(NOTEQ, _30625, 522);
    }
    _30625 = NOVALUE;
    if (_30626 == 0) {
        DeRef(_30626);
        _30626 = NOVALUE;
        goto L19; // [1157] 1243
    }
    else {
        if (!IS_ATOM_INT(_30626) && DBL_PTR(_30626)->dbl == 0.0){
            DeRef(_30626);
            _30626 = NOVALUE;
            goto L19; // [1157] 1243
        }
        DeRef(_30626);
        _30626 = NOVALUE;
    }
    DeRef(_30626);
    _30626 = NOVALUE;

    /** parser.e:4240						if find( temptok[T_ID], FULL_ID_TOKS) then*/
    _2 = (object)SEQ_PTR(_temptok_61876);
    _30627 = (object)*(((s1_ptr)_2)->base + 1);
    _30628 = find_from(_30627, _38FULL_ID_TOKS_16299, 1);
    _30627 = NOVALUE;
    if (_30628 == 0)
    {
        _30628 = NOVALUE;
        goto L1A; // [1175] 1242
    }
    else{
        _30628 = NOVALUE;
    }

    /** parser.e:4242							if SymTab[tok[T_SYM]][S_SCOPE] = SC_UNDEFINED then*/
    _2 = (object)SEQ_PTR(_tok_61608);
    _30629 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!IS_ATOM_INT(_30629)){
        _30630 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_30629)->dbl));
    }
    else{
        _30630 = (object)*(((s1_ptr)_2)->base + _30629);
    }
    _2 = (object)SEQ_PTR(_30630);
    _30631 = (object)*(((s1_ptr)_2)->base + 4);
    _30630 = NOVALUE;
    if (binary_op_a(NOTEQ, _30631, 9)){
        _30631 = NOVALUE;
        goto L1B; // [1200] 1231
    }
    _30631 = NOVALUE;

    /** parser.e:4245								undef_type = - new_forward_reference( TYPE, tok[T_SYM] )*/
    _2 = (object)SEQ_PTR(_tok_61608);
    _30633 = (object)*(((s1_ptr)_2)->base + 2);
    DeRef(_31946);
    _31946 = 504;
    Ref(_30633);
    _30634 = _44new_forward_reference(504, _30633, 504);
    _30633 = NOVALUE;
    _31946 = NOVALUE;
    if (IS_ATOM_INT(_30634)) {
        if ((uintptr_t)_30634 == (uintptr_t)HIGH_BITS){
            _undef_type_61878 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _undef_type_61878 = - _30634;
        }
    }
    else {
        _undef_type_61878 = unary_op(UMINUS, _30634);
    }
    DeRef(_30634);
    _30634 = NOVALUE;
    if (!IS_ATOM_INT(_undef_type_61878)) {
        _1 = (object)(DBL_PTR(_undef_type_61878)->dbl);
        DeRefDS(_undef_type_61878);
        _undef_type_61878 = _1;
    }
    goto L1C; // [1228] 1241
L1B: 

    /** parser.e:4247								CompileErr(A_TYPE_IS_EXPECTED_HERE)*/
    RefDS(_22190);
    _50CompileErr(37, _22190, 0);
L1C: 
L1A: 
L19: 

    /** parser.e:4251					putback(temptok) -- Return whatever came after the name back onto the token stream.*/
    Ref(_temptok_61876);
    _45putback(_temptok_61876);

    /** parser.e:4252					if undef_type != 0 then*/
    if (_undef_type_61878 == 0)
    goto L1D; // [1250] 1265

    /** parser.e:4254						tok[T_SYM] = undef_type*/
    _2 = (object)SEQ_PTR(_tok_61608);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _tok_61608 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _undef_type_61878;
    DeRef(_1);
    goto L1E; // [1262] 1275
L1D: 

    /** parser.e:4256						CompileErr(A_TYPE_IS_EXPECTED_HERE)*/
    RefDS(_22190);
    _50CompileErr(37, _22190, 0);
L1E: 
    DeRef(_temptok_61876);
    _temptok_61876 = NOVALUE;
    goto L1F; // [1277] 1290
L18: 

    /** parser.e:4259					CompileErr(A_TYPE_IS_EXPECTED_HERE)*/
    RefDS(_22190);
    _50CompileErr(37, _22190, 0);
L1F: 
L16: 

    /** parser.e:4262			type_sym = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_61608);
    _type_sym_61605 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_type_sym_61605)){
        _type_sym_61605 = (object)DBL_PTR(_type_sym_61605)->dbl;
    }

    /** parser.e:4263			tok = next_token()*/
    _0 = _tok_61608;
    _tok_61608 = _45next_token();
    DeRef(_0);

    /** parser.e:4264			if not find(tok[T_ID], ID_TOKS) then*/
    _2 = (object)SEQ_PTR(_tok_61608);
    _30639 = (object)*(((s1_ptr)_2)->base + 1);
    _30640 = find_from(_30639, _38ID_TOKS_16297, 1);
    _30639 = NOVALUE;
    if (_30640 != 0)
    goto L20; // [1321] 1439
    _30640 = NOVALUE;

    /** parser.e:4265				sequence tokcat = find_category(tok[T_ID])*/
    _2 = (object)SEQ_PTR(_tok_61608);
    _30642 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_30642);
    _0 = _tokcat_61930;
    _tokcat_61930 = _63find_category(_30642);
    DeRef(_0);
    _30642 = NOVALUE;

    /** parser.e:4266				if tok[T_SYM] != 0 and length(SymTab[tok[T_SYM]]) >= S_NAME then*/
    _2 = (object)SEQ_PTR(_tok_61608);
    _30644 = (object)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_30644)) {
        _30645 = (_30644 != 0);
    }
    else {
        _30645 = binary_op(NOTEQ, _30644, 0);
    }
    _30644 = NOVALUE;
    if (IS_ATOM_INT(_30645)) {
        if (_30645 == 0) {
            goto L21; // [1350] 1413
        }
    }
    else {
        if (DBL_PTR(_30645)->dbl == 0.0) {
            goto L21; // [1350] 1413
        }
    }
    _2 = (object)SEQ_PTR(_tok_61608);
    _30647 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!IS_ATOM_INT(_30647)){
        _30648 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_30647)->dbl));
    }
    else{
        _30648 = (object)*(((s1_ptr)_2)->base + _30647);
    }
    if (IS_SEQUENCE(_30648)){
            _30649 = SEQ_PTR(_30648)->length;
    }
    else {
        _30649 = 1;
    }
    _30648 = NOVALUE;
    if (IS_ATOM_INT(_36S_NAME_21404)) {
        _30650 = (_30649 >= _36S_NAME_21404);
    }
    else {
        _30650 = binary_op(GREATEREQ, _30649, _36S_NAME_21404);
    }
    _30649 = NOVALUE;
    if (_30650 == 0) {
        DeRef(_30650);
        _30650 = NOVALUE;
        goto L21; // [1376] 1413
    }
    else {
        if (!IS_ATOM_INT(_30650) && DBL_PTR(_30650)->dbl == 0.0){
            DeRef(_30650);
            _30650 = NOVALUE;
            goto L21; // [1376] 1413
        }
        DeRef(_30650);
        _30650 = NOVALUE;
    }
    DeRef(_30650);
    _30650 = NOVALUE;

    /** parser.e:4267					CompileErr(FOUND_1_2_BUT_WAS_EXPECTING_A_PARAMETER_NAME_INSTEAD, {tokcat, SymTab[tok[T_SYM]][S_NAME]})*/
    _2 = (object)SEQ_PTR(_tok_61608);
    _30651 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!IS_ATOM_INT(_30651)){
        _30652 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_30651)->dbl));
    }
    else{
        _30652 = (object)*(((s1_ptr)_2)->base + _30651);
    }
    _2 = (object)SEQ_PTR(_30652);
    if (!IS_ATOM_INT(_36S_NAME_21404)){
        _30653 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21404)->dbl));
    }
    else{
        _30653 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21404);
    }
    _30652 = NOVALUE;
    Ref(_30653);
    RefDS(_tokcat_61930);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _tokcat_61930;
    ((intptr_t *)_2)[2] = _30653;
    _30654 = MAKE_SEQ(_1);
    _30653 = NOVALUE;
    _50CompileErr(90, _30654, 0);
    _30654 = NOVALUE;
    goto L22; // [1410] 1438
L21: 

    /** parser.e:4269					CompileErr(FOUND_1_BUT_WAS_EXPECTING_A_PARAMETER_NAME_INSTEAD, {LexName(tok[T_ID])})*/
    _2 = (object)SEQ_PTR(_tok_61608);
    _30655 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_30655);
    RefDS(_26602);
    _30656 = _47LexName(_30655, _26602);
    _30655 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _30656;
    _30657 = MAKE_SEQ(_1);
    _30656 = NOVALUE;
    _50CompileErr(92, _30657, 0);
    _30657 = NOVALUE;
L22: 
L20: 
    DeRef(_tokcat_61930);
    _tokcat_61930 = NOVALUE;

    /** parser.e:4272			sym = SetPrivateScope(tok[T_SYM], type_sym, param_num)*/
    _2 = (object)SEQ_PTR(_tok_61608);
    _30658 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_30658);
    _sym_61606 = _45SetPrivateScope(_30658, _type_sym_61605, _45param_num_55365);
    _30658 = NOVALUE;
    if (!IS_ATOM_INT(_sym_61606)) {
        _1 = (object)(DBL_PTR(_sym_61606)->dbl);
        DeRefDS(_sym_61606);
        _sym_61606 = _1;
    }

    /** parser.e:4273			param_num += 1*/
    _45param_num_55365 = _45param_num_55365 + 1;

    /** parser.e:4275			if SymTab[last_link][S_NEXT] != sym*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _30661 = (object)*(((s1_ptr)_2)->base + _last_link_61849);
    _2 = (object)SEQ_PTR(_30661);
    _30662 = (object)*(((s1_ptr)_2)->base + 2);
    _30661 = NOVALUE;
    if (IS_ATOM_INT(_30662)) {
        _30663 = (_30662 != _sym_61606);
    }
    else {
        _30663 = binary_op(NOTEQ, _30662, _sym_61606);
    }
    _30662 = NOVALUE;
    if (IS_ATOM_INT(_30663)) {
        if (_30663 == 0) {
            goto L23; // [1485] 1566
        }
    }
    else {
        if (DBL_PTR(_30663)->dbl == 0.0) {
            goto L23; // [1485] 1566
        }
    }
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _30665 = (object)*(((s1_ptr)_2)->base + _last_link_61849);
    _2 = (object)SEQ_PTR(_30665);
    _30666 = (object)*(((s1_ptr)_2)->base + 2);
    _30665 = NOVALUE;
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!IS_ATOM_INT(_30666)){
        _30667 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_30666)->dbl));
    }
    else{
        _30667 = (object)*(((s1_ptr)_2)->base + _30666);
    }
    _2 = (object)SEQ_PTR(_30667);
    _30668 = (object)*(((s1_ptr)_2)->base + 4);
    _30667 = NOVALUE;
    if (IS_ATOM_INT(_30668)) {
        _30669 = (_30668 == 9);
    }
    else {
        _30669 = binary_op(EQUALS, _30668, 9);
    }
    _30668 = NOVALUE;
    if (_30669 == 0) {
        DeRef(_30669);
        _30669 = NOVALUE;
        goto L23; // [1520] 1566
    }
    else {
        if (!IS_ATOM_INT(_30669) && DBL_PTR(_30669)->dbl == 0.0){
            DeRef(_30669);
            _30669 = NOVALUE;
            goto L23; // [1520] 1566
        }
        DeRef(_30669);
        _30669 = NOVALUE;
    }
    DeRef(_30669);
    _30669 = NOVALUE;

    /** parser.e:4278				SymTab[SymTab[last_link][S_NEXT]][S_NEXT] = 0*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _30670 = (object)*(((s1_ptr)_2)->base + _last_link_61849);
    _2 = (object)SEQ_PTR(_30670);
    _30671 = (object)*(((s1_ptr)_2)->base + 2);
    _30670 = NOVALUE;
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_30671))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_30671)->dbl));
    else
    _3 = (object)(_30671 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);
    _30672 = NOVALUE;

    /** parser.e:4279				SymTab[last_link][S_NEXT] = sym*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_last_link_61849 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _sym_61606;
    DeRef(_1);
    _30674 = NOVALUE;
L23: 

    /** parser.e:4282			last_link = sym*/
    _last_link_61849 = _sym_61606;

    /** parser.e:4284			if TRANSLATE then*/
    if (_36TRANSLATE_21369 == 0)
    {
        goto L24; // [1577] 1600
    }
    else{
    }

    /** parser.e:4285				SymTab[sym][S_GTYPE] = CompileType(type_sym)*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_61606 + ((s1_ptr)_2)->base);
    _30678 = _45CompileType(_type_sym_61605);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30678;
    if( _1 != _30678 ){
        DeRef(_1);
    }
    _30678 = NOVALUE;
    _30676 = NOVALUE;
L24: 

    /** parser.e:4289			tok = next_token()*/
    _0 = _tok_61608;
    _tok_61608 = _45next_token();
    DeRef(_0);

    /** parser.e:4290			if tok[T_ID] = EQUALS then -- defaulted parameter*/
    _2 = (object)SEQ_PTR(_tok_61608);
    _30680 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30680, 3)){
        _30680 = NOVALUE;
        goto L25; // [1615] 1697
    }
    _30680 = NOVALUE;

    /** parser.e:4291				start_recording()*/
    _45start_recording();

    /** parser.e:4292				Expr()*/
    _45Expr();

    /** parser.e:4293				SymTab[sym][S_CODE] = restore_parser()*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_61606 + ((s1_ptr)_2)->base);
    _30684 = _45restore_parser();
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_CODE_21416))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21416)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_CODE_21416);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30684;
    if( _1 != _30684 ){
        DeRef(_1);
    }
    _30684 = NOVALUE;
    _30682 = NOVALUE;

    /** parser.e:4294				if Pop() then end if -- don't leak the default argument*/
    _30685 = _47Pop();
    if (_30685 == 0) {
        DeRef(_30685);
        _30685 = NOVALUE;
        goto L26; // [1650] 1654
    }
    else {
        if (!IS_ATOM_INT(_30685) && DBL_PTR(_30685)->dbl == 0.0){
            DeRef(_30685);
            _30685 = NOVALUE;
            goto L26; // [1650] 1654
        }
        DeRef(_30685);
        _30685 = NOVALUE;
    }
    DeRef(_30685);
    _30685 = NOVALUE;
L26: 

    /** parser.e:4295				tok = next_token()*/
    _0 = _tok_61608;
    _tok_61608 = _45next_token();
    DeRef(_0);

    /** parser.e:4296				if first_def_arg = 0 then*/
    if (_first_def_arg_61610 != 0)
    goto L27; // [1661] 1673

    /** parser.e:4297					first_def_arg = param_num*/
    _first_def_arg_61610 = _45param_num_55365;
L27: 

    /** parser.e:4299				previous_op = -1 -- no interferences betwen defparms, or them and subsequent code*/
    _36previous_op_21869 = -1;

    /** parser.e:4300				if start_def = 0 then*/
    if (_start_def_61847 != 0)
    goto L28; // [1682] 1754

    /** parser.e:4301					start_def = param_num*/
    _start_def_61847 = _45param_num_55365;
    goto L28; // [1694] 1754
L25: 

    /** parser.e:4304				last_nda = param_num*/
    _last_nda_61846 = _45param_num_55365;

    /** parser.e:4305				if start_def then*/
    if (_start_def_61847 == 0)
    {
        goto L29; // [1706] 1753
    }
    else{
    }

    /** parser.e:4306					if start_def = param_num-1 then*/
    _30689 = _45param_num_55365 - 1;
    if ((object)((uintptr_t)_30689 +(uintptr_t) HIGH_BITS) >= 0){
        _30689 = NewDouble((eudouble)_30689);
    }
    if (binary_op_a(NOTEQ, _start_def_61847, _30689)){
        DeRef(_30689);
        _30689 = NOVALUE;
        goto L2A; // [1717] 1730
    }
    DeRef(_30689);
    _30689 = NOVALUE;

    /** parser.e:4307						middle_def_args &= start_def*/
    Append(&_middle_def_args_61845, _middle_def_args_61845, _start_def_61847);
    goto L2B; // [1727] 1747
L2A: 

    /** parser.e:4309						middle_def_args = append(middle_def_args, {start_def, param_num-1})*/
    _30692 = _45param_num_55365 - 1;
    if ((object)((uintptr_t)_30692 +(uintptr_t) HIGH_BITS) >= 0){
        _30692 = NewDouble((eudouble)_30692);
    }
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _start_def_61847;
    ((intptr_t *)_2)[2] = _30692;
    _30693 = MAKE_SEQ(_1);
    _30692 = NOVALUE;
    RefDS(_30693);
    Append(&_middle_def_args_61845, _middle_def_args_61845, _30693);
    DeRefDS(_30693);
    _30693 = NOVALUE;
L2B: 

    /** parser.e:4311					start_def = 0*/
    _start_def_61847 = 0;
L29: 
L28: 

    /** parser.e:4314			if tok[T_ID] = COMMA then*/
    _2 = (object)SEQ_PTR(_tok_61608);
    _30695 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30695, -30)){
        _30695 = NOVALUE;
        goto L2C; // [1764] 1800
    }
    _30695 = NOVALUE;

    /** parser.e:4315				tok = next_token()*/
    _0 = _tok_61608;
    _tok_61608 = _45next_token();
    DeRef(_0);

    /** parser.e:4316				if tok[T_ID] = RIGHT_ROUND then*/
    _2 = (object)SEQ_PTR(_tok_61608);
    _30698 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30698, -27)){
        _30698 = NOVALUE;
        goto L14; // [1783] 1035
    }
    _30698 = NOVALUE;

    /** parser.e:4317					CompileErr(EXPECTED_TO_SEE_A_PARAMETER_DECLARATION_NOT)*/
    RefDS(_22190);
    _50CompileErr(85, _22190, 0);
    goto L14; // [1797] 1035
L2C: 

    /** parser.e:4319			elsif tok[T_ID] != RIGHT_ROUND then*/
    _2 = (object)SEQ_PTR(_tok_61608);
    _30700 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _30700, -27)){
        _30700 = NOVALUE;
        goto L14; // [1810] 1035
    }
    _30700 = NOVALUE;

    /** parser.e:4320				CompileErr(BADLYFORMED_LIST_OF_PARAMETERS__EXPECTED__OR)*/
    RefDS(_22190);
    _50CompileErr(41, _22190, 0);

    /** parser.e:4322		end while*/
    goto L14; // [1827] 1035
L15: 

    /** parser.e:4323		Code = {} -- removes any spurious code emitted while recording parameters*/
    RefDS(_22190);
    DeRef(_36Code_21859);
    _36Code_21859 = _22190;

    /** parser.e:4325		SymTab[p][S_NUM_ARGS] = param_num*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_61604 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_NUM_ARGS_21455))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21455)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_NUM_ARGS_21455);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _45param_num_55365;
    DeRef(_1);
    _30702 = NOVALUE;

    /** parser.e:4326		SymTab[p][S_DEF_ARGS] = {first_def_arg, last_nda, middle_def_args}*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_61604 + ((s1_ptr)_2)->base);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _first_def_arg_61610;
    ((intptr_t*)_2)[2] = _last_nda_61846;
    RefDS(_middle_def_args_61845);
    ((intptr_t*)_2)[3] = _middle_def_args_61845;
    _30706 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 28);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30706;
    if( _1 != _30706 ){
        DeRef(_1);
    }
    _30706 = NOVALUE;
    _30704 = NOVALUE;

    /** parser.e:4327		if TRANSLATE then*/
    if (_36TRANSLATE_21369 == 0)
    {
        goto L2D; // [1879] 1913
    }
    else{
    }

    /** parser.e:4328			if param_num > max_params then*/
    if (_45param_num_55365 <= _47max_params_51370)
    goto L2E; // [1888] 1902

    /** parser.e:4329				max_params = param_num*/
    _47max_params_51370 = _45param_num_55365;
L2E: 

    /** parser.e:4331			num_routines += 1*/
    _36num_routines_21776 = _36num_routines_21776 + 1;
L2D: 

    /** parser.e:4333		if SymTab[p][S_TOKEN] = TYPE and param_num != 1 then*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _30709 = (object)*(((s1_ptr)_2)->base + _p_61604);
    _2 = (object)SEQ_PTR(_30709);
    if (!IS_ATOM_INT(_36S_TOKEN_21409)){
        _30710 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21409)->dbl));
    }
    else{
        _30710 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21409);
    }
    _30709 = NOVALUE;
    if (IS_ATOM_INT(_30710)) {
        _30711 = (_30710 == 504);
    }
    else {
        _30711 = binary_op(EQUALS, _30710, 504);
    }
    _30710 = NOVALUE;
    if (IS_ATOM_INT(_30711)) {
        if (_30711 == 0) {
            goto L2F; // [1933] 1957
        }
    }
    else {
        if (DBL_PTR(_30711)->dbl == 0.0) {
            goto L2F; // [1933] 1957
        }
    }
    _30713 = (_45param_num_55365 != 1);
    if (_30713 == 0)
    {
        DeRef(_30713);
        _30713 = NOVALUE;
        goto L2F; // [1944] 1957
    }
    else{
        DeRef(_30713);
        _30713 = NOVALUE;
    }

    /** parser.e:4334			CompileErr(TYPES_MUST_HAVE_EXACTLY_ONE_PARAMETER)*/
    RefDS(_22190);
    _50CompileErr(148, _22190, 0);
L2F: 

    /** parser.e:4337		include_routine()*/
    _51include_routine();

    /** parser.e:4340		sym = SymTab[p][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _30714 = (object)*(((s1_ptr)_2)->base + _p_61604);
    _2 = (object)SEQ_PTR(_30714);
    _sym_61606 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_sym_61606)){
        _sym_61606 = (object)DBL_PTR(_sym_61606)->dbl;
    }
    _30714 = NOVALUE;

    /** parser.e:4341		for i = 1 to SymTab[p][S_NUM_ARGS] do*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _30716 = (object)*(((s1_ptr)_2)->base + _p_61604);
    _2 = (object)SEQ_PTR(_30716);
    if (!IS_ATOM_INT(_36S_NUM_ARGS_21455)){
        _30717 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21455)->dbl));
    }
    else{
        _30717 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21455);
    }
    _30716 = NOVALUE;
    {
        object _i_62089;
        _i_62089 = 1;
L30: 
        if (binary_op_a(GREATER, _i_62089, _30717)){
            goto L31; // [1991] 2070
        }

        /** parser.e:4342			while SymTab[sym][S_SCOPE] != SC_PRIVATE do*/
L32: 
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _30718 = (object)*(((s1_ptr)_2)->base + _sym_61606);
        _2 = (object)SEQ_PTR(_30718);
        _30719 = (object)*(((s1_ptr)_2)->base + 4);
        _30718 = NOVALUE;
        if (binary_op_a(EQUALS, _30719, 3)){
            _30719 = NOVALUE;
            goto L33; // [2017] 2042
        }
        _30719 = NOVALUE;

        /** parser.e:4343				sym = SymTab[sym][S_NEXT]*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _30721 = (object)*(((s1_ptr)_2)->base + _sym_61606);
        _2 = (object)SEQ_PTR(_30721);
        _sym_61606 = (object)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_sym_61606)){
            _sym_61606 = (object)DBL_PTR(_sym_61606)->dbl;
        }
        _30721 = NOVALUE;

        /** parser.e:4344			end while*/
        goto L32; // [2039] 2003
L33: 

        /** parser.e:4345			TypeCheck(sym)*/
        _45TypeCheck(_sym_61606);

        /** parser.e:4346			sym = SymTab[sym][S_NEXT]*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _30723 = (object)*(((s1_ptr)_2)->base + _sym_61606);
        _2 = (object)SEQ_PTR(_30723);
        _sym_61606 = (object)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_sym_61606)){
            _sym_61606 = (object)DBL_PTR(_sym_61606)->dbl;
        }
        _30723 = NOVALUE;

        /** parser.e:4347		end for*/
        _0 = _i_62089;
        if (IS_ATOM_INT(_i_62089)) {
            _i_62089 = _i_62089 + 1;
            if ((object)((uintptr_t)_i_62089 +(uintptr_t) HIGH_BITS) >= 0){
                _i_62089 = NewDouble((eudouble)_i_62089);
            }
        }
        else {
            _i_62089 = binary_op_a(PLUS, _i_62089, 1);
        }
        DeRef(_0);
        goto L30; // [2065] 1998
L31: 
        ;
        DeRef(_i_62089);
    }

    /** parser.e:4352		tok = next_token()*/
    _0 = _tok_61608;
    _tok_61608 = _45next_token();
    DeRef(_0);

    /** parser.e:4353		while tok[T_ID] = TYPE or tok[T_ID] = QUALIFIED_TYPE do*/
L34: 
    _2 = (object)SEQ_PTR(_tok_61608);
    _30726 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_30726)) {
        _30727 = (_30726 == 504);
    }
    else {
        _30727 = binary_op(EQUALS, _30726, 504);
    }
    _30726 = NOVALUE;
    if (IS_ATOM_INT(_30727)) {
        if (_30727 != 0) {
            goto L35; // [2092] 2113
        }
    }
    else {
        if (DBL_PTR(_30727)->dbl != 0.0) {
            goto L35; // [2092] 2113
        }
    }
    _2 = (object)SEQ_PTR(_tok_61608);
    _30729 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_30729)) {
        _30730 = (_30729 == 522);
    }
    else {
        _30730 = binary_op(EQUALS, _30729, 522);
    }
    _30729 = NOVALUE;
    if (_30730 <= 0) {
        if (_30730 == 0) {
            DeRef(_30730);
            _30730 = NOVALUE;
            goto L36; // [2109] 2134
        }
        else {
            if (!IS_ATOM_INT(_30730) && DBL_PTR(_30730)->dbl == 0.0){
                DeRef(_30730);
                _30730 = NOVALUE;
                goto L36; // [2109] 2134
            }
            DeRef(_30730);
            _30730 = NOVALUE;
        }
    }
    DeRef(_30730);
    _30730 = NOVALUE;
L35: 

    /** parser.e:4354			Private_declaration(tok[T_SYM])*/
    _2 = (object)SEQ_PTR(_tok_61608);
    _30731 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_30731);
    _45Private_declaration(_30731);
    _30731 = NOVALUE;

    /** parser.e:4355			tok = next_token()*/
    _0 = _tok_61608;
    _tok_61608 = _45next_token();
    DeRef(_0);

    /** parser.e:4356		end while*/
    goto L34; // [2131] 2080
L36: 

    /** parser.e:4358		if not TRANSLATE then*/
    if (_36TRANSLATE_21369 != 0)
    goto L37; // [2138] 2241

    /** parser.e:4359			if OpTrace then*/
    if (_36OpTrace_21840 == 0)
    {
        goto L38; // [2145] 2240
    }
    else{
    }

    /** parser.e:4361				emit_op(ERASE_PRIVATE_NAMES)*/
    _47emit_op(88);

    /** parser.e:4362				emit_addr(p)*/
    _47emit_addr(_p_61604);

    /** parser.e:4364				sym = SymTab[p][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _30734 = (object)*(((s1_ptr)_2)->base + _p_61604);
    _2 = (object)SEQ_PTR(_30734);
    _sym_61606 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_sym_61606)){
        _sym_61606 = (object)DBL_PTR(_sym_61606)->dbl;
    }
    _30734 = NOVALUE;

    /** parser.e:4365				for i = 1 to SymTab[p][S_NUM_ARGS] do*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _30736 = (object)*(((s1_ptr)_2)->base + _p_61604);
    _2 = (object)SEQ_PTR(_30736);
    if (!IS_ATOM_INT(_36S_NUM_ARGS_21455)){
        _30737 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21455)->dbl));
    }
    else{
        _30737 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21455);
    }
    _30736 = NOVALUE;
    {
        object _i_62136;
        _i_62136 = 1;
L39: 
        if (binary_op_a(GREATER, _i_62136, _30737)){
            goto L3A; // [2190] 2232
        }

        /** parser.e:4366					emit_op(DISPLAY_VAR)*/
        _47emit_op(87);

        /** parser.e:4367					emit_addr(sym)*/
        _47emit_addr(_sym_61606);

        /** parser.e:4368					sym = SymTab[sym][S_NEXT]*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _30738 = (object)*(((s1_ptr)_2)->base + _sym_61606);
        _2 = (object)SEQ_PTR(_30738);
        _sym_61606 = (object)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_sym_61606)){
            _sym_61606 = (object)DBL_PTR(_sym_61606)->dbl;
        }
        _30738 = NOVALUE;

        /** parser.e:4369				end for*/
        _0 = _i_62136;
        if (IS_ATOM_INT(_i_62136)) {
            _i_62136 = _i_62136 + 1;
            if ((object)((uintptr_t)_i_62136 +(uintptr_t) HIGH_BITS) >= 0){
                _i_62136 = NewDouble((eudouble)_i_62136);
            }
        }
        else {
            _i_62136 = binary_op_a(PLUS, _i_62136, 1);
        }
        DeRef(_0);
        goto L39; // [2227] 2197
L3A: 
        ;
        DeRef(_i_62136);
    }

    /** parser.e:4371				emit_op(UPDATE_GLOBALS)*/
    _47emit_op(89);
L38: 
L37: 

    /** parser.e:4374		putback(tok)*/
    Ref(_tok_61608);
    _45putback(_tok_61608);

    /** parser.e:4377		FuncReturn = FALSE*/
    _45FuncReturn_55364 = _13FALSE_445;

    /** parser.e:4378		if type_enum then*/
    if (_type_enum_61612 == 0)
    {
        goto L3B; // [2257] 2426
    }
    else{
    }

    /** parser.e:4380			stmt_nest += 1*/
    _45stmt_nest_55388 = _45stmt_nest_55388 + 1;

    /** parser.e:4381			tok_match(RETURN)*/
    _45tok_match(413, 0);

    /** parser.e:4382			putback({RIGHT_ROUND,0})*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -27;
    ((intptr_t *)_2)[2] = 0;
    _30741 = MAKE_SEQ(_1);
    _45putback(_30741);
    _30741 = NOVALUE;

    /** parser.e:4383			putback({VARIABLE,seq_sym})*/
    Ref(_seq_sym_61613);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -100;
    ((intptr_t *)_2)[2] = _seq_sym_61613;
    _30742 = MAKE_SEQ(_1);
    _45putback(_30742);
    _30742 = NOVALUE;

    /** parser.e:4384			putback({COMMA,0})*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -30;
    ((intptr_t *)_2)[2] = 0;
    _30743 = MAKE_SEQ(_1);
    _45putback(_30743);
    _30743 = NOVALUE;

    /** parser.e:4385			putback(i1_sym)*/
    Ref(_i1_sym_61614);
    _45putback(_i1_sym_61614);

    /** parser.e:4386			putback({LEFT_ROUND,0})*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -26;
    ((intptr_t *)_2)[2] = 0;
    _30744 = MAKE_SEQ(_1);
    _45putback(_30744);
    _30744 = NOVALUE;

    /** parser.e:4387			putback(keyfind("find",-1))*/
    RefDS(_30745);
    DeRef(_31944);
    _31944 = _30745;
    _31945 = _54hashfn(_31944);
    _31944 = NOVALUE;
    RefDS(_30745);
    _30746 = _54keyfind(_30745, -1, _36current_file_no_21767, 0, _31945);
    _31945 = NOVALUE;
    _45putback(_30746);
    _30746 = NOVALUE;

    /** parser.e:4388			if not TRANSLATE then*/
    if (_36TRANSLATE_21369 != 0)
    goto L3C; // [2355] 2381

    /** parser.e:4389				if OpTrace then*/
    if (_36OpTrace_21840 == 0)
    {
        goto L3D; // [2362] 2380
    }
    else{
    }

    /** parser.e:4390					emit_op(ERASE_PRIVATE_NAMES)*/
    _47emit_op(88);

    /** parser.e:4391					emit_addr(CurrentSub)*/
    _47emit_addr(_36CurrentSub_21775);
L3D: 
L3C: 

    /** parser.e:4394			Expr()*/
    _45Expr();

    /** parser.e:4395			FuncReturn = TRUE*/
    _45FuncReturn_55364 = _13TRUE_447;

    /** parser.e:4396			emit_op(RETURNF)*/
    _47emit_op(28);

    /** parser.e:4397			flush_temps()*/
    RefDS(_22190);
    _47flush_temps(_22190);

    /** parser.e:4398			stmt_nest -= 1*/
    _45stmt_nest_55388 = _45stmt_nest_55388 - 1;

    /** parser.e:4399			InitDelete()*/
    _45InitDelete();

    /** parser.e:4400			flush_temps()*/
    RefDS(_22190);
    _47flush_temps(_22190);
    goto L3E; // [2423] 2439
L3B: 

    /** parser.e:4402			Statement_list()*/
    _45Statement_list();

    /** parser.e:4404			tok_match(END)*/
    _45tok_match(402, 0);
L3E: 

    /** parser.e:4408		tok_match(prog_type, END)*/
    _45tok_match(_prog_type_61598, 402);

    /** parser.e:4410		if prog_type != PROCEDURE then*/
    if (_prog_type_61598 == 405)
    goto L3F; // [2451] 2503

    /** parser.e:4411			if not FuncReturn then*/
    if (_45FuncReturn_55364 != 0)
    goto L40; // [2459] 2493

    /** parser.e:4412				if prog_type = FUNCTION then*/
    if (_prog_type_61598 != 406)
    goto L41; // [2466] 2482

    /** parser.e:4413					CompileErr(NO_VALUE_RETURNED_FROM_FUNCTION)*/
    RefDS(_22190);
    _50CompileErr(120, _22190, 0);
    goto L42; // [2479] 2492
L41: 

    /** parser.e:4415					CompileErr(TYPE_MUST_RETURN_TRUE__FALSE_VALUE)*/
    RefDS(_22190);
    _50CompileErr(149, _22190, 0);
L42: 
L40: 

    /** parser.e:4418			emit_op(BADRETURNF) -- function/type shouldn't reach here*/
    _47emit_op(43);
    goto L43; // [2500] 2563
L3F: 

    /** parser.e:4421			StartSourceLine(TRUE)*/
    _47StartSourceLine(_13TRUE_447, 0, 2);

    /** parser.e:4422			if not TRANSLATE then*/
    if (_36TRANSLATE_21369 != 0)
    goto L44; // [2516] 2540

    /** parser.e:4423				if OpTrace then*/
    if (_36OpTrace_21840 == 0)
    {
        goto L45; // [2523] 2539
    }
    else{
    }

    /** parser.e:4424					emit_op(ERASE_PRIVATE_NAMES)*/
    _47emit_op(88);

    /** parser.e:4425					emit_addr(p)*/
    _47emit_addr(_p_61604);
L45: 
L44: 

    /** parser.e:4428			emit_op(RETURNP)*/
    _47emit_op(29);

    /** parser.e:4429			if TRANSLATE then*/
    if (_36TRANSLATE_21369 == 0)
    {
        goto L46; // [2551] 2562
    }
    else{
    }

    /** parser.e:4430				emit_op(BADRETURNF) -- just to mark end of procedure*/
    _47emit_op(43);
L46: 
L43: 

    /** parser.e:4433		Drop_block( pt )*/
    _65Drop_block(_pt_61602);

    /** parser.e:4435		if Strict_Override > 0 then*/
    if (_36Strict_Override_21837 <= 0)
    goto L47; // [2572] 2587

    /** parser.e:4436			Strict_Override -= 1	-- Reset at the end of each routine.*/
    _36Strict_Override_21837 = _36Strict_Override_21837 - 1;
L47: 

    /** parser.e:4439		SymTab[p][S_STACK_SPACE] += temps_allocated + param_num*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_61604 + ((s1_ptr)_2)->base);
    _30757 = _54temps_allocated_47667 + _45param_num_55365;
    if ((object)((uintptr_t)_30757 + (uintptr_t)HIGH_BITS) >= 0){
        _30757 = NewDouble((eudouble)_30757);
    }
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!IS_ATOM_INT(_36S_STACK_SPACE_21464)){
        _30758 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_STACK_SPACE_21464)->dbl));
    }
    else{
        _30758 = (object)*(((s1_ptr)_2)->base + _36S_STACK_SPACE_21464);
    }
    _30755 = NOVALUE;
    if (IS_ATOM_INT(_30758) && IS_ATOM_INT(_30757)) {
        _30759 = _30758 + _30757;
        if ((object)((uintptr_t)_30759 + (uintptr_t)HIGH_BITS) >= 0){
            _30759 = NewDouble((eudouble)_30759);
        }
    }
    else {
        _30759 = binary_op(PLUS, _30758, _30757);
    }
    _30758 = NOVALUE;
    DeRef(_30757);
    _30757 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_STACK_SPACE_21464))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_STACK_SPACE_21464)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_STACK_SPACE_21464);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30759;
    if( _1 != _30759 ){
        DeRef(_1);
    }
    _30759 = NOVALUE;
    _30755 = NOVALUE;

    /** parser.e:4440		if temps_allocated + param_num > max_stack_per_call then*/
    _30760 = _54temps_allocated_47667 + _45param_num_55365;
    if ((object)((uintptr_t)_30760 + (uintptr_t)HIGH_BITS) >= 0){
        _30760 = NewDouble((eudouble)_30760);
    }
    if (binary_op_a(LESSEQ, _30760, _36max_stack_per_call_21870)){
        DeRef(_30760);
        _30760 = NOVALUE;
        goto L48; // [2630] 2647
    }
    DeRef(_30760);
    _30760 = NOVALUE;

    /** parser.e:4441			max_stack_per_call = temps_allocated + param_num*/
    _36max_stack_per_call_21870 = _54temps_allocated_47667 + _45param_num_55365;
L48: 

    /** parser.e:4443		param_num = -1*/
    _45param_num_55365 = -1;

    /** parser.e:4445		StraightenBranches()*/
    _45StraightenBranches();

    /** parser.e:4446		check_inline( p )*/
    _67check_inline(_p_61604);

    /** parser.e:4447		param_num = -1*/
    _45param_num_55365 = -1;

    /** parser.e:4448		EnterTopLevel()*/
    _45EnterTopLevel(1);

    /** parser.e:4451		if length( enum_syms ) then*/
    if (IS_SEQUENCE(_enum_syms_61615)){
            _30763 = SEQ_PTR(_enum_syms_61615)->length;
    }
    else {
        _30763 = 1;
    }
    if (_30763 == 0)
    {
        _30763 = NOVALUE;
        goto L49; // [2676] 2763
    }
    else{
        _30763 = NOVALUE;
    }

    /** parser.e:4452			SymTab[p][S_NEXT] = SymTab[enum_syms[$]][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_61604 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_enum_syms_61615)){
            _30766 = SEQ_PTR(_enum_syms_61615)->length;
    }
    else {
        _30766 = 1;
    }
    _2 = (object)SEQ_PTR(_enum_syms_61615);
    _30767 = (object)*(((s1_ptr)_2)->base + _30766);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!IS_ATOM_INT(_30767)){
        _30768 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_30767)->dbl));
    }
    else{
        _30768 = (object)*(((s1_ptr)_2)->base + _30767);
    }
    _2 = (object)SEQ_PTR(_30768);
    _30769 = (object)*(((s1_ptr)_2)->base + 2);
    _30768 = NOVALUE;
    Ref(_30769);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30769;
    if( _1 != _30769 ){
        DeRef(_1);
    }
    _30769 = NOVALUE;
    _30764 = NOVALUE;

    /** parser.e:4453			SymTab[last_sym][S_NEXT] = enum_syms[1]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_54last_sym_47145 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_enum_syms_61615);
    _30772 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_30772);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30772;
    if( _1 != _30772 ){
        DeRef(_1);
    }
    _30772 = NOVALUE;
    _30770 = NOVALUE;

    /** parser.e:4454			last_sym = enum_syms[$]*/
    if (IS_SEQUENCE(_enum_syms_61615)){
            _30773 = SEQ_PTR(_enum_syms_61615)->length;
    }
    else {
        _30773 = 1;
    }
    _2 = (object)SEQ_PTR(_enum_syms_61615);
    _54last_sym_47145 = (object)*(((s1_ptr)_2)->base + _30773);
    if (!IS_ATOM_INT(_54last_sym_47145)){
        _54last_sym_47145 = (object)DBL_PTR(_54last_sym_47145)->dbl;
    }

    /** parser.e:4455			SymTab[last_sym][S_NEXT] = 0*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_54last_sym_47145 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);
    _30775 = NOVALUE;
L49: 

    /** parser.e:4457	end procedure*/
    DeRef(_tok_61608);
    DeRef(_prog_name_61609);
    DeRef(_seq_sym_61613);
    DeRef(_i1_sym_61614);
    DeRef(_enum_syms_61615);
    DeRef(_middle_def_args_61845);
    DeRef(_30612);
    _30612 = NOVALUE;
    _30717 = NOVALUE;
    _30629 = NOVALUE;
    DeRef(_30663);
    _30663 = NOVALUE;
    DeRef(_30617);
    _30617 = NOVALUE;
    _30583 = NOVALUE;
    _30666 = NOVALUE;
    _30737 = NOVALUE;
    _30579 = NOVALUE;
    _30767 = NOVALUE;
    _30648 = NOVALUE;
    DeRef(_30645);
    _30645 = NOVALUE;
    DeRef(_30557);
    _30557 = NOVALUE;
    _30651 = NOVALUE;
    _30671 = NOVALUE;
    DeRef(_30727);
    _30727 = NOVALUE;
    DeRef(_30711);
    _30711 = NOVALUE;
    DeRef(_30623);
    _30623 = NOVALUE;
    _30647 = NOVALUE;
    return;
    ;
}


void _45InitGlobals()
{
    object _30794 = NOVALUE;
    object _30792 = NOVALUE;
    object _30791 = NOVALUE;
    object _30790 = NOVALUE;
    object _30789 = NOVALUE;
    object _30788 = NOVALUE;
    object _30787 = NOVALUE;
    object _30785 = NOVALUE;
    object _30784 = NOVALUE;
    object _30783 = NOVALUE;
    object _30782 = NOVALUE;
    object _30780 = NOVALUE;
    object _30779 = NOVALUE;
    object _30778 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:4461		ResetTP()*/
    _62ResetTP();

    /** parser.e:4462		OpTypeCheck = TRUE*/
    _36OpTypeCheck_21841 = _13TRUE_447;

    /** parser.e:4464		OpDefines &= {*/
    _30778 = _33version_major();
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _30778;
    _30779 = MAKE_SEQ(_1);
    _30778 = NOVALUE;
    _30780 = EPrintf(-9999999, _30777, _30779);
    DeRefDS(_30779);
    _30779 = NOVALUE;
    _30782 = _33version_major();
    _30783 = _33version_minor();
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _30782;
    ((intptr_t *)_2)[2] = _30783;
    _30784 = MAKE_SEQ(_1);
    _30783 = NOVALUE;
    _30782 = NOVALUE;
    _30785 = EPrintf(-9999999, _30781, _30784);
    DeRefDS(_30784);
    _30784 = NOVALUE;
    _30787 = _33version_major();
    _30788 = _33version_minor();
    _30789 = _33version_patch();
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _30787;
    ((intptr_t*)_2)[2] = _30788;
    ((intptr_t*)_2)[3] = _30789;
    _30790 = MAKE_SEQ(_1);
    _30789 = NOVALUE;
    _30788 = NOVALUE;
    _30787 = NOVALUE;
    _30791 = EPrintf(-9999999, _30786, _30790);
    DeRefDS(_30790);
    _30790 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _30780;
    ((intptr_t*)_2)[2] = _30785;
    ((intptr_t*)_2)[3] = _30791;
    _30792 = MAKE_SEQ(_1);
    _30791 = NOVALUE;
    _30785 = NOVALUE;
    _30780 = NOVALUE;
    Concat((object_ptr)&_36OpDefines_21844, _36OpDefines_21844, _30792);
    DeRefDS(_30792);
    _30792 = NOVALUE;

    /** parser.e:4470		OpDefines &= GetPlatformDefines()*/
    _30794 = _46GetPlatformDefines(0);
    if (IS_SEQUENCE(_36OpDefines_21844) && IS_ATOM(_30794)) {
        Ref(_30794);
        Append(&_36OpDefines_21844, _36OpDefines_21844, _30794);
    }
    else if (IS_ATOM(_36OpDefines_21844) && IS_SEQUENCE(_30794)) {
    }
    else {
        Concat((object_ptr)&_36OpDefines_21844, _36OpDefines_21844, _30794);
    }
    DeRef(_30794);
    _30794 = NOVALUE;

    /** parser.e:4472		if repl then*/

    /** parser.e:4476			OpInline = DEFAULT_INLINE*/
    _36OpInline_21845 = 30;

    /** parser.e:4478		OpIndirectInclude = 1*/
    _36OpIndirectInclude_21846 = 1;

    /** parser.e:4479	end procedure*/
    return;
    ;
}


void _45not_supported_compile(object _feature_62306)
{
    object _30796 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:4483		CompileErr(MSG_1_IS_NOT_SUPPORTED_IN_EUPHORIA_FOR_2, {feature, version_name})*/
    RefDS(_36version_name_21383);
    RefDS(_feature_62306);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _feature_62306;
    ((intptr_t *)_2)[2] = _36version_name_21383;
    _30796 = MAKE_SEQ(_1);
    _50CompileErr(5, _30796, 0);
    _30796 = NOVALUE;

    /** parser.e:4484	end procedure*/
    DeRefDSi(_feature_62306);
    return;
    ;
}


void _45SetWith(object _on_off_62313)
{
    object _option_62314 = NOVALUE;
    object _idx_62315 = NOVALUE;
    object _reset_flags_62316 = NOVALUE;
    object _tok_62368 = NOVALUE;
    object _good_sofar_62418 = NOVALUE;
    object _tok_62421 = NOVALUE;
    object _warning_extra_62423 = NOVALUE;
    object _endlist_62516 = NOVALUE;
    object _tok_62665 = NOVALUE;
    object _30943 = NOVALUE;
    object _30942 = NOVALUE;
    object _30941 = NOVALUE;
    object _30940 = NOVALUE;
    object _30939 = NOVALUE;
    object _30936 = NOVALUE;
    object _30935 = NOVALUE;
    object _30934 = NOVALUE;
    object _30932 = NOVALUE;
    object _30930 = NOVALUE;
    object _30929 = NOVALUE;
    object _30928 = NOVALUE;
    object _30925 = NOVALUE;
    object _30923 = NOVALUE;
    object _30922 = NOVALUE;
    object _30921 = NOVALUE;
    object _30920 = NOVALUE;
    object _30919 = NOVALUE;
    object _30915 = NOVALUE;
    object _30913 = NOVALUE;
    object _30911 = NOVALUE;
    object _30907 = NOVALUE;
    object _30902 = NOVALUE;
    object _30901 = NOVALUE;
    object _30896 = NOVALUE;
    object _30895 = NOVALUE;
    object _30894 = NOVALUE;
    object _30893 = NOVALUE;
    object _30892 = NOVALUE;
    object _30891 = NOVALUE;
    object _30890 = NOVALUE;
    object _30889 = NOVALUE;
    object _30888 = NOVALUE;
    object _30887 = NOVALUE;
    object _30885 = NOVALUE;
    object _30884 = NOVALUE;
    object _30882 = NOVALUE;
    object _30881 = NOVALUE;
    object _30880 = NOVALUE;
    object _30878 = NOVALUE;
    object _30877 = NOVALUE;
    object _30875 = NOVALUE;
    object _30872 = NOVALUE;
    object _30870 = NOVALUE;
    object _30867 = NOVALUE;
    object _30866 = NOVALUE;
    object _30865 = NOVALUE;
    object _30864 = NOVALUE;
    object _30857 = NOVALUE;
    object _30856 = NOVALUE;
    object _30854 = NOVALUE;
    object _30851 = NOVALUE;
    object _30850 = NOVALUE;
    object _30848 = NOVALUE;
    object _30847 = NOVALUE;
    object _30846 = NOVALUE;
    object _30845 = NOVALUE;
    object _30844 = NOVALUE;
    object _30843 = NOVALUE;
    object _30840 = NOVALUE;
    object _30839 = NOVALUE;
    object _30838 = NOVALUE;
    object _30837 = NOVALUE;
    object _30836 = NOVALUE;
    object _30835 = NOVALUE;
    object _30832 = NOVALUE;
    object _30831 = NOVALUE;
    object _30830 = NOVALUE;
    object _30828 = NOVALUE;
    object _30825 = NOVALUE;
    object _30823 = NOVALUE;
    object _30822 = NOVALUE;
    object _30820 = NOVALUE;
    object _30819 = NOVALUE;
    object _30818 = NOVALUE;
    object _30817 = NOVALUE;
    object _30816 = NOVALUE;
    object _30815 = NOVALUE;
    object _30813 = NOVALUE;
    object _30810 = NOVALUE;
    object _30809 = NOVALUE;
    object _30808 = NOVALUE;
    object _30807 = NOVALUE;
    object _30805 = NOVALUE;
    object _30804 = NOVALUE;
    object _30803 = NOVALUE;
    object _30802 = NOVALUE;
    object _30800 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:4490		integer reset_flags = 1*/
    _reset_flags_62316 = 1;

    /** parser.e:4493		option = StringToken("&+=")*/
    RefDS(_30797);
    _0 = _option_62314;
    _option_62314 = _62StringToken(_30797);
    DeRef(_0);

    /** parser.e:4495		if equal(option, "type_check") then*/
    if (_option_62314 == _30799)
    _30800 = 1;
    else if (IS_ATOM_INT(_option_62314) && IS_ATOM_INT(_30799))
    _30800 = 0;
    else
    _30800 = (compare(_option_62314, _30799) == 0);
    if (_30800 == 0)
    {
        _30800 = NOVALUE;
        goto L1; // [22] 35
    }
    else{
        _30800 = NOVALUE;
    }

    /** parser.e:4496			OpTypeCheck = on_off*/
    _36OpTypeCheck_21841 = _on_off_62313;
    goto L2; // [32] 1546
L1: 

    /** parser.e:4498		elsif equal(option, "profile") then*/
    if (_option_62314 == _30801)
    _30802 = 1;
    else if (IS_ATOM_INT(_option_62314) && IS_ATOM_INT(_30801))
    _30802 = 0;
    else
    _30802 = (compare(_option_62314, _30801) == 0);
    if (_30802 == 0)
    {
        _30802 = NOVALUE;
        goto L3; // [41] 121
    }
    else{
        _30802 = NOVALUE;
    }

    /** parser.e:4499			if not TRANSLATE and not BIND then*/
    _30803 = (_36TRANSLATE_21369 == 0);
    if (_30803 == 0) {
        goto L2; // [51] 1546
    }
    _30805 = (_36BIND_21372 == 0);
    if (_30805 == 0)
    {
        DeRef(_30805);
        _30805 = NOVALUE;
        goto L2; // [61] 1546
    }
    else{
        DeRef(_30805);
        _30805 = NOVALUE;
    }

    /** parser.e:4500				OpProfileStatement = on_off*/
    _36OpProfileStatement_21842 = _on_off_62313;

    /** parser.e:4501				if OpProfileStatement then*/
    if (_36OpProfileStatement_21842 == 0)
    {
        goto L2; // [75] 1546
    }
    else{
    }

    /** parser.e:4502					if AnyTimeProfile then*/
    if (_37AnyTimeProfile_15659 == 0)
    {
        goto L4; // [82] 106
    }
    else{
    }

    /** parser.e:4503						Warning(224, mixed_profile_warning_flag)*/
    RefDS(_22190);
    _50Warning(224, 1024, _22190);

    /** parser.e:4504						OpProfileStatement = FALSE*/
    _36OpProfileStatement_21842 = _13FALSE_445;
    goto L2; // [103] 1546
L4: 

    /** parser.e:4506						AnyStatementProfile = TRUE*/
    _37AnyStatementProfile_15660 = _13TRUE_447;
    goto L2; // [118] 1546
L3: 

    /** parser.e:4511		elsif equal(option, "profile_time") then*/
    if (_option_62314 == _30806)
    _30807 = 1;
    else if (IS_ATOM_INT(_option_62314) && IS_ATOM_INT(_30806))
    _30807 = 0;
    else
    _30807 = (compare(_option_62314, _30806) == 0);
    if (_30807 == 0)
    {
        _30807 = NOVALUE;
        goto L5; // [127] 364
    }
    else{
        _30807 = NOVALUE;
    }

    /** parser.e:4512			if not TRANSLATE and not BIND then*/
    _30808 = (_36TRANSLATE_21369 == 0);
    if (_30808 == 0) {
        goto L2; // [137] 1546
    }
    _30810 = (_36BIND_21372 == 0);
    if (_30810 == 0)
    {
        DeRef(_30810);
        _30810 = NOVALUE;
        goto L2; // [147] 1546
    }
    else{
        DeRef(_30810);
        _30810 = NOVALUE;
    }

    /** parser.e:4513				if not IWINDOWS then*/
    if (_46IWINDOWS_21913 != 0)
    goto L6; // [154] 169

    /** parser.e:4514					if on_off then*/
    if (_on_off_62313 == 0)
    {
        goto L7; // [159] 168
    }
    else{
    }

    /** parser.e:4515						not_supported_compile("profile_time")*/
    RefDS(_30806);
    _45not_supported_compile(_30806);
L7: 
L6: 

    /** parser.e:4518				OpProfileTime = on_off*/
    _36OpProfileTime_21843 = _on_off_62313;

    /** parser.e:4519				if OpProfileTime then*/
    if (_36OpProfileTime_21843 == 0)
    {
        goto L8; // [180] 358
    }
    else{
    }

    /** parser.e:4520					if AnyStatementProfile then*/
    if (_37AnyStatementProfile_15660 == 0)
    {
        goto L9; // [187] 209
    }
    else{
    }

    /** parser.e:4521						Warning(224,mixed_profile_warning_flag)*/
    RefDS(_22190);
    _50Warning(224, 1024, _22190);

    /** parser.e:4522						OpProfileTime = FALSE*/
    _36OpProfileTime_21843 = _13FALSE_445;
L9: 

    /** parser.e:4524					token tok = next_token()*/
    _0 = _tok_62368;
    _tok_62368 = _45next_token();
    DeRef(_0);

    /** parser.e:4525					if tok[T_ID] = ATOM then*/
    _2 = (object)SEQ_PTR(_tok_62368);
    _30813 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30813, 502)){
        _30813 = NOVALUE;
        goto LA; // [224] 319
    }
    _30813 = NOVALUE;

    /** parser.e:4526						if is_integer(SymTab[tok[T_SYM]][S_OBJ]) then*/
    _2 = (object)SEQ_PTR(_tok_62368);
    _30815 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!IS_ATOM_INT(_30815)){
        _30816 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_30815)->dbl));
    }
    else{
        _30816 = (object)*(((s1_ptr)_2)->base + _30815);
    }
    _2 = (object)SEQ_PTR(_30816);
    _30817 = (object)*(((s1_ptr)_2)->base + 1);
    _30816 = NOVALUE;
    Ref(_30817);
    _30818 = _36is_integer(_30817);
    _30817 = NOVALUE;
    if (_30818 == 0) {
        DeRef(_30818);
        _30818 = NOVALUE;
        goto LB; // [252] 280
    }
    else {
        if (!IS_ATOM_INT(_30818) && DBL_PTR(_30818)->dbl == 0.0){
            DeRef(_30818);
            _30818 = NOVALUE;
            goto LB; // [252] 280
        }
        DeRef(_30818);
        _30818 = NOVALUE;
    }
    DeRef(_30818);
    _30818 = NOVALUE;

    /** parser.e:4527							sample_size = SymTab[tok[T_SYM]][S_OBJ]*/
    _2 = (object)SEQ_PTR(_tok_62368);
    _30819 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!IS_ATOM_INT(_30819)){
        _30820 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_30819)->dbl));
    }
    else{
        _30820 = (object)*(((s1_ptr)_2)->base + _30819);
    }
    _2 = (object)SEQ_PTR(_30820);
    _36sample_size_21871 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_36sample_size_21871)){
        _36sample_size_21871 = (object)DBL_PTR(_36sample_size_21871)->dbl;
    }
    _30820 = NOVALUE;
    goto LC; // [277] 288
LB: 

    /** parser.e:4529							sample_size = -1*/
    _36sample_size_21871 = -1;
LC: 

    /** parser.e:4531						if sample_size < 1 and OpProfileTime then*/
    _30822 = (_36sample_size_21871 < 1);
    if (_30822 == 0) {
        goto LD; // [296] 332
    }
    if (_36OpProfileTime_21843 == 0)
    {
        goto LD; // [303] 332
    }
    else{
    }

    /** parser.e:4532							CompileErr(SAMPLE_SIZE_MUST_BE_A_POSITIVE_INTEGER)*/
    RefDS(_22190);
    _50CompileErr(136, _22190, 0);
    goto LD; // [316] 332
LA: 

    /** parser.e:4535						putback(tok)*/
    Ref(_tok_62368);
    _45putback(_tok_62368);

    /** parser.e:4536						sample_size = DEFAULT_SAMPLE_SIZE*/
    _36sample_size_21871 = 25000;
LD: 

    /** parser.e:4538					if OpProfileTime then*/
    if (_36OpProfileTime_21843 == 0)
    {
        goto LE; // [336] 357
    }
    else{
    }

    /** parser.e:4539						if IWINDOWS then*/
    if (_46IWINDOWS_21913 == 0)
    {
        goto LF; // [343] 356
    }
    else{
    }

    /** parser.e:4540							AnyTimeProfile = TRUE*/
    _37AnyTimeProfile_15659 = _13TRUE_447;
LF: 
LE: 
L8: 
    DeRef(_tok_62368);
    _tok_62368 = NOVALUE;
    goto L2; // [361] 1546
L5: 

    /** parser.e:4546		elsif equal(option, "trace") then*/
    if (_option_62314 == _30824)
    _30825 = 1;
    else if (IS_ATOM_INT(_option_62314) && IS_ATOM_INT(_30824))
    _30825 = 0;
    else
    _30825 = (compare(_option_62314, _30824) == 0);
    if (_30825 == 0)
    {
        _30825 = NOVALUE;
        goto L10; // [370] 391
    }
    else{
        _30825 = NOVALUE;
    }

    /** parser.e:4547			if not BIND then*/
    if (_36BIND_21372 != 0)
    goto L2; // [377] 1546

    /** parser.e:4548				OpTrace = on_off*/
    _36OpTrace_21840 = _on_off_62313;
    goto L2; // [388] 1546
L10: 

    /** parser.e:4551		elsif equal(option, "warning") then*/
    if (_option_62314 == _30827)
    _30828 = 1;
    else if (IS_ATOM_INT(_option_62314) && IS_ATOM_INT(_30827))
    _30828 = 0;
    else
    _30828 = (compare(_option_62314, _30827) == 0);
    if (_30828 == 0)
    {
        _30828 = NOVALUE;
        goto L11; // [397] 1243
    }
    else{
        _30828 = NOVALUE;
    }

    /** parser.e:4552			integer good_sofar = line_number*/
    _good_sofar_62418 = _36line_number_21768;

    /** parser.e:4553			reset_flags = 1*/
    _reset_flags_62316 = 1;

    /** parser.e:4554			token tok = next_token()*/
    _0 = _tok_62421;
    _tok_62421 = _45next_token();
    DeRef(_0);

    /** parser.e:4555			integer warning_extra = 1*/
    _warning_extra_62423 = 1;

    /** parser.e:4556			if find(tok[T_ID], {CONCAT_EQUALS, PLUS_EQUALS}) != 0 then*/
    _2 = (object)SEQ_PTR(_tok_62421);
    _30830 = (object)*(((s1_ptr)_2)->base + 1);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 519;
    ((intptr_t *)_2)[2] = 515;
    _30831 = MAKE_SEQ(_1);
    _30832 = find_from(_30830, _30831, 1);
    _30830 = NOVALUE;
    DeRefDS(_30831);
    _30831 = NOVALUE;
    if (_30832 == 0)
    goto L12; // [445] 506

    /** parser.e:4557				tok = next_token()*/
    _0 = _tok_62421;
    _tok_62421 = _45next_token();
    DeRef(_0);

    /** parser.e:4558				if tok[T_ID] != LEFT_BRACE and tok[T_ID] != LEFT_ROUND then*/
    _2 = (object)SEQ_PTR(_tok_62421);
    _30835 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_30835)) {
        _30836 = (_30835 != -24);
    }
    else {
        _30836 = binary_op(NOTEQ, _30835, -24);
    }
    _30835 = NOVALUE;
    if (IS_ATOM_INT(_30836)) {
        if (_30836 == 0) {
            goto L13; // [468] 498
        }
    }
    else {
        if (DBL_PTR(_30836)->dbl == 0.0) {
            goto L13; // [468] 498
        }
    }
    _2 = (object)SEQ_PTR(_tok_62421);
    _30838 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_30838)) {
        _30839 = (_30838 != -26);
    }
    else {
        _30839 = binary_op(NOTEQ, _30838, -26);
    }
    _30838 = NOVALUE;
    if (_30839 == 0) {
        DeRef(_30839);
        _30839 = NOVALUE;
        goto L13; // [485] 498
    }
    else {
        if (!IS_ATOM_INT(_30839) && DBL_PTR(_30839)->dbl == 0.0){
            DeRef(_30839);
            _30839 = NOVALUE;
            goto L13; // [485] 498
        }
        DeRef(_30839);
        _30839 = NOVALUE;
    }
    DeRef(_30839);
    _30839 = NOVALUE;

    /** parser.e:4559					CompileErr(WARNING_NAMES_MUST_BE_ENCLOSED_IN)*/
    RefDS(_22190);
    _50CompileErr(160, _22190, 0);
L13: 

    /** parser.e:4561				reset_flags = 0*/
    _reset_flags_62316 = 0;
    goto L14; // [503] 734
L12: 

    /** parser.e:4562			elsif tok[T_ID] = EQUALS then*/
    _2 = (object)SEQ_PTR(_tok_62421);
    _30840 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30840, 3)){
        _30840 = NOVALUE;
        goto L15; // [516] 577
    }
    _30840 = NOVALUE;

    /** parser.e:4563				tok = next_token()*/
    _0 = _tok_62421;
    _tok_62421 = _45next_token();
    DeRef(_0);

    /** parser.e:4564				if tok[T_ID] != LEFT_BRACE and tok[T_ID] != LEFT_ROUND then*/
    _2 = (object)SEQ_PTR(_tok_62421);
    _30843 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_30843)) {
        _30844 = (_30843 != -24);
    }
    else {
        _30844 = binary_op(NOTEQ, _30843, -24);
    }
    _30843 = NOVALUE;
    if (IS_ATOM_INT(_30844)) {
        if (_30844 == 0) {
            goto L16; // [539] 569
        }
    }
    else {
        if (DBL_PTR(_30844)->dbl == 0.0) {
            goto L16; // [539] 569
        }
    }
    _2 = (object)SEQ_PTR(_tok_62421);
    _30846 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_30846)) {
        _30847 = (_30846 != -26);
    }
    else {
        _30847 = binary_op(NOTEQ, _30846, -26);
    }
    _30846 = NOVALUE;
    if (_30847 == 0) {
        DeRef(_30847);
        _30847 = NOVALUE;
        goto L16; // [556] 569
    }
    else {
        if (!IS_ATOM_INT(_30847) && DBL_PTR(_30847)->dbl == 0.0){
            DeRef(_30847);
            _30847 = NOVALUE;
            goto L16; // [556] 569
        }
        DeRef(_30847);
        _30847 = NOVALUE;
    }
    DeRef(_30847);
    _30847 = NOVALUE;

    /** parser.e:4565					CompileErr(WARNING_NAMES_MUST_BE_ENCLOSED_IN)*/
    RefDS(_22190);
    _50CompileErr(160, _22190, 0);
L16: 

    /** parser.e:4567				reset_flags = 1*/
    _reset_flags_62316 = 1;
    goto L14; // [574] 734
L15: 

    /** parser.e:4568			elsif tok[T_ID] = VARIABLE then*/
    _2 = (object)SEQ_PTR(_tok_62421);
    _30848 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30848, -100)){
        _30848 = NOVALUE;
        goto L17; // [587] 733
    }
    _30848 = NOVALUE;

    /** parser.e:4569				option = SymTab[tok[T_SYM]][S_NAME]*/
    _2 = (object)SEQ_PTR(_tok_62421);
    _30850 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!IS_ATOM_INT(_30850)){
        _30851 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_30850)->dbl));
    }
    else{
        _30851 = (object)*(((s1_ptr)_2)->base + _30850);
    }
    DeRef(_option_62314);
    _2 = (object)SEQ_PTR(_30851);
    if (!IS_ATOM_INT(_36S_NAME_21404)){
        _option_62314 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21404)->dbl));
    }
    else{
        _option_62314 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21404);
    }
    Ref(_option_62314);
    _30851 = NOVALUE;

    /** parser.e:4570				if equal(option, "save") then*/
    if (_option_62314 == _30853)
    _30854 = 1;
    else if (IS_ATOM_INT(_option_62314) && IS_ATOM_INT(_30853))
    _30854 = 0;
    else
    _30854 = (compare(_option_62314, _30853) == 0);
    if (_30854 == 0)
    {
        _30854 = NOVALUE;
        goto L18; // [619] 643
    }
    else{
        _30854 = NOVALUE;
    }

    /** parser.e:4571					prev_OpWarning = OpWarning*/
    _36prev_OpWarning_21839 = _36OpWarning_21838;

    /** parser.e:4572					warning_extra = FALSE*/
    _warning_extra_62423 = _13FALSE_445;
    goto L19; // [640] 732
L18: 

    /** parser.e:4574				elsif equal(option, "restore") then*/
    if (_option_62314 == _30855)
    _30856 = 1;
    else if (IS_ATOM_INT(_option_62314) && IS_ATOM_INT(_30855))
    _30856 = 0;
    else
    _30856 = (compare(_option_62314, _30855) == 0);
    if (_30856 == 0)
    {
        _30856 = NOVALUE;
        goto L1A; // [649] 673
    }
    else{
        _30856 = NOVALUE;
    }

    /** parser.e:4575					OpWarning = prev_OpWarning*/
    _36OpWarning_21838 = _36prev_OpWarning_21839;

    /** parser.e:4576					warning_extra = FALSE*/
    _warning_extra_62423 = _13FALSE_445;
    goto L19; // [670] 732
L1A: 

    /** parser.e:4578				elsif equal(option, "strict") then*/
    if (_option_62314 == _25684)
    _30857 = 1;
    else if (IS_ATOM_INT(_option_62314) && IS_ATOM_INT(_25684))
    _30857 = 0;
    else
    _30857 = (compare(_option_62314, _25684) == 0);
    if (_30857 == 0)
    {
        _30857 = NOVALUE;
        goto L1B; // [679] 731
    }
    else{
        _30857 = NOVALUE;
    }

    /** parser.e:4579					if on_off = 0 then*/
    if (_on_off_62313 != 0)
    goto L1C; // [684] 701

    /** parser.e:4580						Strict_Override += 1*/
    _36Strict_Override_21837 = _36Strict_Override_21837 + 1;
    goto L1D; // [698] 721
L1C: 

    /** parser.e:4581					elsif Strict_Override > 0 then*/
    if (_36Strict_Override_21837 <= 0)
    goto L1E; // [705] 720

    /** parser.e:4582						Strict_Override -= 1*/
    _36Strict_Override_21837 = _36Strict_Override_21837 - 1;
L1E: 
L1D: 

    /** parser.e:4584					warning_extra = FALSE*/
    _warning_extra_62423 = _13FALSE_445;
L1B: 
L19: 
L17: 
L14: 

    /** parser.e:4588			if warning_extra = TRUE then*/
    if (_warning_extra_62423 != _13TRUE_447)
    goto L1F; // [738] 1238

    /** parser.e:4589				if reset_flags then*/
    if (_reset_flags_62316 == 0)
    {
        goto L20; // [744] 776
    }
    else{
    }

    /** parser.e:4590					if on_off = 0 then*/
    if (_on_off_62313 != 0)
    goto L21; // [749] 765

    /** parser.e:4591						OpWarning = no_warning_flag*/
    _36OpWarning_21838 = 0;
    goto L22; // [762] 775
L21: 

    /** parser.e:4593						OpWarning = all_warning_flag*/
    _36OpWarning_21838 = 32767;
L22: 
L20: 

    /** parser.e:4597				if find(tok[T_ID], {LEFT_BRACE, LEFT_ROUND}) then*/
    _2 = (object)SEQ_PTR(_tok_62421);
    _30864 = (object)*(((s1_ptr)_2)->base + 1);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -24;
    ((intptr_t *)_2)[2] = -26;
    _30865 = MAKE_SEQ(_1);
    _30866 = find_from(_30864, _30865, 1);
    _30864 = NOVALUE;
    DeRefDS(_30865);
    _30865 = NOVALUE;
    if (_30866 == 0)
    {
        _30866 = NOVALUE;
        goto L23; // [797] 1231
    }
    else{
        _30866 = NOVALUE;
    }

    /** parser.e:4598					integer endlist*/

    /** parser.e:4599					if tok[T_ID] = LEFT_BRACE then*/
    _2 = (object)SEQ_PTR(_tok_62421);
    _30867 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30867, -24)){
        _30867 = NOVALUE;
        goto L24; // [812] 828
    }
    _30867 = NOVALUE;

    /** parser.e:4600						endlist = RIGHT_BRACE*/
    _endlist_62516 = -25;
    goto L25; // [825] 838
L24: 

    /** parser.e:4602						endlist = RIGHT_ROUND*/
    _endlist_62516 = -27;
L25: 

    /** parser.e:4604					tok = next_token()*/
    _0 = _tok_62421;
    _tok_62421 = _45next_token();
    DeRef(_0);

    /** parser.e:4605					while tok[T_ID] != endlist do*/
L26: 
    _2 = (object)SEQ_PTR(_tok_62421);
    _30870 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _30870, _endlist_62516)){
        _30870 = NOVALUE;
        goto L27; // [856] 1226
    }
    _30870 = NOVALUE;

    /** parser.e:4606						if tok[T_ID] = COMMA then*/
    _2 = (object)SEQ_PTR(_tok_62421);
    _30872 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30872, -30)){
        _30872 = NOVALUE;
        goto L28; // [870] 884
    }
    _30872 = NOVALUE;

    /** parser.e:4607							tok = next_token()*/
    _0 = _tok_62421;
    _tok_62421 = _45next_token();
    DeRef(_0);

    /** parser.e:4608							continue*/
    goto L26; // [881] 848
L28: 

    /** parser.e:4611						if tok[T_ID] = STRING then*/
    _2 = (object)SEQ_PTR(_tok_62421);
    _30875 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30875, 503)){
        _30875 = NOVALUE;
        goto L29; // [894] 923
    }
    _30875 = NOVALUE;

    /** parser.e:4612							option = SymTab[tok[T_SYM]][S_OBJ]*/
    _2 = (object)SEQ_PTR(_tok_62421);
    _30877 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!IS_ATOM_INT(_30877)){
        _30878 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_30877)->dbl));
    }
    else{
        _30878 = (object)*(((s1_ptr)_2)->base + _30877);
    }
    DeRef(_option_62314);
    _2 = (object)SEQ_PTR(_30878);
    _option_62314 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_option_62314);
    _30878 = NOVALUE;
    goto L2A; // [920] 1071
L29: 

    /** parser.e:4613						elsif length(SymTab[tok[T_SYM]]) >= S_NAME then*/
    _2 = (object)SEQ_PTR(_tok_62421);
    _30880 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!IS_ATOM_INT(_30880)){
        _30881 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_30880)->dbl));
    }
    else{
        _30881 = (object)*(((s1_ptr)_2)->base + _30880);
    }
    if (IS_SEQUENCE(_30881)){
            _30882 = SEQ_PTR(_30881)->length;
    }
    else {
        _30882 = 1;
    }
    _30881 = NOVALUE;
    if (binary_op_a(LESS, _30882, _36S_NAME_21404)){
        _30882 = NOVALUE;
        goto L2B; // [942] 971
    }
    _30882 = NOVALUE;

    /** parser.e:4614							option = SymTab[tok[T_SYM]][S_NAME]*/
    _2 = (object)SEQ_PTR(_tok_62421);
    _30884 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!IS_ATOM_INT(_30884)){
        _30885 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_30884)->dbl));
    }
    else{
        _30885 = (object)*(((s1_ptr)_2)->base + _30884);
    }
    DeRef(_option_62314);
    _2 = (object)SEQ_PTR(_30885);
    if (!IS_ATOM_INT(_36S_NAME_21404)){
        _option_62314 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21404)->dbl));
    }
    else{
        _option_62314 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21404);
    }
    Ref(_option_62314);
    _30885 = NOVALUE;
    goto L2A; // [968] 1071
L2B: 

    /** parser.e:4616							option = ""*/
    RefDS(_22190);
    DeRef(_option_62314);
    _option_62314 = _22190;

    /** parser.e:4617							for k = 1 to length(keylist) do*/
    if (IS_SEQUENCE(_63keylist_23441)){
            _30887 = SEQ_PTR(_63keylist_23441)->length;
    }
    else {
        _30887 = 1;
    }
    {
        object _k_62563;
        _k_62563 = 1;
L2C: 
        if (_k_62563 > _30887){
            goto L2D; // [985] 1070
        }

        /** parser.e:4618								if keylist[k][S_SCOPE] = SC_KEYWORD and*/
        _2 = (object)SEQ_PTR(_63keylist_23441);
        _30888 = (object)*(((s1_ptr)_2)->base + _k_62563);
        _2 = (object)SEQ_PTR(_30888);
        _30889 = (object)*(((s1_ptr)_2)->base + 4);
        _30888 = NOVALUE;
        if (IS_ATOM_INT(_30889)) {
            _30890 = (_30889 == 8);
        }
        else {
            _30890 = binary_op(EQUALS, _30889, 8);
        }
        _30889 = NOVALUE;
        if (IS_ATOM_INT(_30890)) {
            if (_30890 == 0) {
                goto L2E; // [1012] 1063
            }
        }
        else {
            if (DBL_PTR(_30890)->dbl == 0.0) {
                goto L2E; // [1012] 1063
            }
        }
        _2 = (object)SEQ_PTR(_63keylist_23441);
        _30892 = (object)*(((s1_ptr)_2)->base + _k_62563);
        _2 = (object)SEQ_PTR(_30892);
        if (!IS_ATOM_INT(_36S_TOKEN_21409)){
            _30893 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21409)->dbl));
        }
        else{
            _30893 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21409);
        }
        _30892 = NOVALUE;
        _2 = (object)SEQ_PTR(_tok_62421);
        _30894 = (object)*(((s1_ptr)_2)->base + 1);
        if (IS_ATOM_INT(_30893) && IS_ATOM_INT(_30894)) {
            _30895 = (_30893 == _30894);
        }
        else {
            _30895 = binary_op(EQUALS, _30893, _30894);
        }
        _30893 = NOVALUE;
        _30894 = NOVALUE;
        if (_30895 == 0) {
            DeRef(_30895);
            _30895 = NOVALUE;
            goto L2E; // [1039] 1063
        }
        else {
            if (!IS_ATOM_INT(_30895) && DBL_PTR(_30895)->dbl == 0.0){
                DeRef(_30895);
                _30895 = NOVALUE;
                goto L2E; // [1039] 1063
            }
            DeRef(_30895);
            _30895 = NOVALUE;
        }
        DeRef(_30895);
        _30895 = NOVALUE;

        /** parser.e:4621										option = keylist[k][S_NAME]*/
        _2 = (object)SEQ_PTR(_63keylist_23441);
        _30896 = (object)*(((s1_ptr)_2)->base + _k_62563);
        DeRef(_option_62314);
        _2 = (object)SEQ_PTR(_30896);
        if (!IS_ATOM_INT(_36S_NAME_21404)){
            _option_62314 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21404)->dbl));
        }
        else{
            _option_62314 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21404);
        }
        Ref(_option_62314);
        _30896 = NOVALUE;

        /** parser.e:4622										exit*/
        goto L2D; // [1060] 1070
L2E: 

        /** parser.e:4624							end for*/
        _k_62563 = _k_62563 + 1;
        goto L2C; // [1065] 992
L2D: 
        ;
    }
L2A: 

    /** parser.e:4628						idx = find(option, warning_names)*/
    _idx_62315 = find_from(_option_62314, _36warning_names_21815, 1);

    /** parser.e:4629						if idx = 0 then*/
    if (_idx_62315 != 0)
    goto L2F; // [1082] 1137

    /** parser.e:4630		 					if good_sofar != line_number then*/
    if (_good_sofar_62418 == _36line_number_21768)
    goto L30; // [1090] 1104

    /** parser.e:4631	 							CompileErr(TOO_MANY_WARNING_ERRORS)*/
    RefDS(_22190);
    _50CompileErr(147, _22190, 0);
L30: 

    /** parser.e:4633							Warning(225, 0,*/
    _2 = (object)SEQ_PTR(_37known_files_15638);
    _30901 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21767);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_30901);
    ((intptr_t*)_2)[1] = _30901;
    ((intptr_t*)_2)[2] = _36line_number_21768;
    RefDS(_option_62314);
    ((intptr_t*)_2)[3] = _option_62314;
    _30902 = MAKE_SEQ(_1);
    _30901 = NOVALUE;
    _50Warning(225, 0, _30902);
    _30902 = NOVALUE;

    /** parser.e:4635							tok = next_token()*/
    _0 = _tok_62421;
    _tok_62421 = _45next_token();
    DeRef(_0);

    /** parser.e:4636							continue*/
    goto L26; // [1134] 848
L2F: 

    /** parser.e:4639						idx = warning_flags[idx]*/
    _2 = (object)SEQ_PTR(_36warning_flags_21813);
    _idx_62315 = (object)*(((s1_ptr)_2)->base + _idx_62315);

    /** parser.e:4640						if idx = 0 then*/
    if (_idx_62315 != 0)
    goto L31; // [1149] 1183

    /** parser.e:4641							if on_off then*/
    if (_on_off_62313 == 0)
    {
        goto L32; // [1155] 1170
    }
    else{
    }

    /** parser.e:4642								OpWarning = no_warning_flag*/
    _36OpWarning_21838 = 0;
    goto L33; // [1167] 1216
L32: 

    /** parser.e:4644							    OpWarning = all_warning_flag*/
    _36OpWarning_21838 = 32767;
    goto L33; // [1180] 1216
L31: 

    /** parser.e:4647							if on_off then*/
    if (_on_off_62313 == 0)
    {
        goto L34; // [1185] 1201
    }
    else{
    }

    /** parser.e:4648								OpWarning = or_bits(OpWarning, idx)*/
    {uintptr_t tu;
         tu = (uintptr_t)_36OpWarning_21838 | (uintptr_t)_idx_62315;
         _36OpWarning_21838 = MAKE_UINT(tu);
    }
    if (!IS_ATOM_INT(_36OpWarning_21838)) {
        _1 = (object)(DBL_PTR(_36OpWarning_21838)->dbl);
        DeRefDS(_36OpWarning_21838);
        _36OpWarning_21838 = _1;
    }
    goto L35; // [1198] 1215
L34: 

    /** parser.e:4650							    OpWarning = and_bits(OpWarning, not_bits(idx))*/
    _30907 = not_bits(_idx_62315);
    if (IS_ATOM_INT(_30907)) {
        {uintptr_t tu;
             tu = (uintptr_t)_36OpWarning_21838 & (uintptr_t)_30907;
             _36OpWarning_21838 = MAKE_UINT(tu);
        }
    }
    else {
        temp_d.dbl = (eudouble)_36OpWarning_21838;
        _36OpWarning_21838 = Dand_bits(&temp_d, DBL_PTR(_30907));
    }
    DeRef(_30907);
    _30907 = NOVALUE;
    if (!IS_ATOM_INT(_36OpWarning_21838)) {
        _1 = (object)(DBL_PTR(_36OpWarning_21838)->dbl);
        DeRefDS(_36OpWarning_21838);
        _36OpWarning_21838 = _1;
    }
L35: 
L33: 

    /** parser.e:4653						tok = next_token()*/
    _0 = _tok_62421;
    _tok_62421 = _45next_token();
    DeRef(_0);

    /** parser.e:4654					end while*/
    goto L26; // [1223] 848
L27: 
    goto L36; // [1228] 1237
L23: 

    /** parser.e:4656					putback(tok)*/
    Ref(_tok_62421);
    _45putback(_tok_62421);
L36: 
L1F: 
    DeRef(_tok_62421);
    _tok_62421 = NOVALUE;
    goto L2; // [1240] 1546
L11: 

    /** parser.e:4659		elsif equal(option, "define") then*/
    if (_option_62314 == _30910)
    _30911 = 1;
    else if (IS_ATOM_INT(_option_62314) && IS_ATOM_INT(_30910))
    _30911 = 0;
    else
    _30911 = (compare(_option_62314, _30910) == 0);
    if (_30911 == 0)
    {
        _30911 = NOVALUE;
        goto L37; // [1249] 1376
    }
    else{
        _30911 = NOVALUE;
    }

    /** parser.e:4660			option = StringToken()*/
    RefDS(_5);
    _0 = _option_62314;
    _option_62314 = _62StringToken(_5);
    DeRefDS(_0);

    /** parser.e:4661			if length(option) = 0 then*/
    if (IS_SEQUENCE(_option_62314)){
            _30913 = SEQ_PTR(_option_62314)->length;
    }
    else {
        _30913 = 1;
    }
    if (_30913 != 0)
    goto L38; // [1265] 1281

    /** parser.e:4662				CompileErr(EXPECTING_TO_FIND_A_WORD_TO_DEFINE_BUT_REACHED_END_OF_LINE_FIRST)*/
    RefDS(_22190);
    _50CompileErr(81, _22190, 0);
    goto L39; // [1278] 1301
L38: 

    /** parser.e:4664			elsif not t_identifier(option) then*/
    RefDS(_option_62314);
    _30915 = _13t_identifier(_option_62314);
    if (IS_ATOM_INT(_30915)) {
        if (_30915 != 0){
            DeRef(_30915);
            _30915 = NOVALUE;
            goto L3A; // [1287] 1300
        }
    }
    else {
        if (DBL_PTR(_30915)->dbl != 0.0){
            DeRef(_30915);
            _30915 = NOVALUE;
            goto L3A; // [1287] 1300
        }
    }
    DeRef(_30915);
    _30915 = NOVALUE;

    /** parser.e:4665				CompileErr(DEFINED_WORD_MUST_ONLY_HAVE_ALPHANUMERICS_AND_UNDERSCORE)*/
    RefDS(_22190);
    _50CompileErr(61, _22190, 0);
L3A: 
L39: 

    /** parser.e:4668			if on_off = 0 then*/
    if (_on_off_62313 != 0)
    goto L3B; // [1303] 1358

    /** parser.e:4669				idx = find(option, OpDefines)*/
    _idx_62315 = find_from(_option_62314, _36OpDefines_21844, 1);

    /** parser.e:4670				if idx then*/
    if (_idx_62315 == 0)
    {
        goto L2; // [1318] 1546
    }
    else{
    }

    /** parser.e:4671					OpDefines = OpDefines[1..idx-1]&OpDefines[idx+1..$]*/
    _30919 = _idx_62315 - 1;
    rhs_slice_target = (object_ptr)&_30920;
    RHS_Slice(_36OpDefines_21844, 1, _30919);
    _30921 = _idx_62315 + 1;
    if (IS_SEQUENCE(_36OpDefines_21844)){
            _30922 = SEQ_PTR(_36OpDefines_21844)->length;
    }
    else {
        _30922 = 1;
    }
    rhs_slice_target = (object_ptr)&_30923;
    RHS_Slice(_36OpDefines_21844, _30921, _30922);
    Concat((object_ptr)&_36OpDefines_21844, _30920, _30923);
    DeRefDS(_30920);
    _30920 = NOVALUE;
    DeRef(_30920);
    _30920 = NOVALUE;
    DeRefDS(_30923);
    _30923 = NOVALUE;
    goto L2; // [1355] 1546
L3B: 

    /** parser.e:4674				OpDefines &= {option}*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_option_62314);
    ((intptr_t*)_2)[1] = _option_62314;
    _30925 = MAKE_SEQ(_1);
    Concat((object_ptr)&_36OpDefines_21844, _36OpDefines_21844, _30925);
    DeRefDS(_30925);
    _30925 = NOVALUE;
    goto L2; // [1373] 1546
L37: 

    /** parser.e:4677		elsif equal(option, "inline") then*/
    if (_option_62314 == _30927)
    _30928 = 1;
    else if (IS_ATOM_INT(_option_62314) && IS_ATOM_INT(_30927))
    _30928 = 0;
    else
    _30928 = (compare(_option_62314, _30927) == 0);
    if (_30928 == 0)
    {
        _30928 = NOVALUE;
        goto L3C; // [1382] 1478
    }
    else{
        _30928 = NOVALUE;
    }

    /** parser.e:4679			if on_off and not repl then*/
    if (_on_off_62313 == 0) {
        goto L3D; // [1387] 1467
    }
    _30930 = (0 == 0);
    if (_30930 == 0)
    {
        DeRef(_30930);
        _30930 = NOVALUE;
        goto L3D; // [1397] 1467
    }
    else{
        DeRef(_30930);
        _30930 = NOVALUE;
    }

    /** parser.e:4680				token tok = next_token()*/
    _0 = _tok_62665;
    _tok_62665 = _45next_token();
    DeRef(_0);

    /** parser.e:4681				if tok[T_ID] = ATOM then*/
    _2 = (object)SEQ_PTR(_tok_62665);
    _30932 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30932, 502)){
        _30932 = NOVALUE;
        goto L3E; // [1415] 1447
    }
    _30932 = NOVALUE;

    /** parser.e:4682					OpInline = floor( SymTab[tok[T_SYM]][S_OBJ] )*/
    _2 = (object)SEQ_PTR(_tok_62665);
    _30934 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!IS_ATOM_INT(_30934)){
        _30935 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_30934)->dbl));
    }
    else{
        _30935 = (object)*(((s1_ptr)_2)->base + _30934);
    }
    _2 = (object)SEQ_PTR(_30935);
    _30936 = (object)*(((s1_ptr)_2)->base + 1);
    _30935 = NOVALUE;
    if (IS_ATOM_INT(_30936))
    _36OpInline_21845 = e_floor(_30936);
    else
    _36OpInline_21845 = unary_op(FLOOR, _30936);
    _30936 = NOVALUE;
    if (!IS_ATOM_INT(_36OpInline_21845)) {
        _1 = (object)(DBL_PTR(_36OpInline_21845)->dbl);
        DeRefDS(_36OpInline_21845);
        _36OpInline_21845 = _1;
    }
    goto L3F; // [1444] 1462
L3E: 

    /** parser.e:4684					putback(tok)*/
    Ref(_tok_62665);
    _45putback(_tok_62665);

    /** parser.e:4685					OpInline = DEFAULT_INLINE*/
    _36OpInline_21845 = 30;
L3F: 
    DeRef(_tok_62665);
    _tok_62665 = NOVALUE;
    goto L2; // [1464] 1546
L3D: 

    /** parser.e:4688				OpInline = 0*/
    _36OpInline_21845 = 0;
    goto L2; // [1475] 1546
L3C: 

    /** parser.e:4692		elsif equal( option, "indirect_includes" ) then*/
    if (_option_62314 == _30938)
    _30939 = 1;
    else if (IS_ATOM_INT(_option_62314) && IS_ATOM_INT(_30938))
    _30939 = 0;
    else
    _30939 = (compare(_option_62314, _30938) == 0);
    if (_30939 == 0)
    {
        _30939 = NOVALUE;
        goto L40; // [1484] 1497
    }
    else{
        _30939 = NOVALUE;
    }

    /** parser.e:4693			OpIndirectInclude = on_off*/
    _36OpIndirectInclude_21846 = _on_off_62313;
    goto L2; // [1494] 1546
L40: 

    /** parser.e:4695		elsif equal(option, "batch") then*/
    if (_option_62314 == _25681)
    _30940 = 1;
    else if (IS_ATOM_INT(_option_62314) && IS_ATOM_INT(_25681))
    _30940 = 0;
    else
    _30940 = (compare(_option_62314, _25681) == 0);
    if (_30940 == 0)
    {
        _30940 = NOVALUE;
        goto L41; // [1503] 1516
    }
    else{
        _30940 = NOVALUE;
    }

    /** parser.e:4696			batch_job = on_off*/
    _36batch_job_21780 = _on_off_62313;
    goto L2; // [1513] 1546
L41: 

    /** parser.e:4698		elsif integer(to_number(option, -1)) then*/
    RefDS(_option_62314);
    _30941 = _15to_number(_option_62314, -1);
    if (IS_ATOM_INT(_30941))
    _30942 = 1;
    else if (IS_ATOM_DBL(_30941))
    _30942 = IS_ATOM_INT(DoubleToInt(_30941));
    else
    _30942 = 0;
    DeRef(_30941);
    _30941 = NOVALUE;
    if (_30942 == 0)
    {
        _30942 = NOVALUE;
        goto L42; // [1526] 1532
    }
    else{
        _30942 = NOVALUE;
    }
    goto L2; // [1529] 1546
L42: 

    /** parser.e:4702			CompileErr(UNKNOWN_WITHWITHOUT_OPTION_1, {option})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_option_62314);
    ((intptr_t*)_2)[1] = _option_62314;
    _30943 = MAKE_SEQ(_1);
    _50CompileErr(154, _30943, 0);
    _30943 = NOVALUE;
L2: 

    /** parser.e:4705	end procedure*/
    DeRef(_option_62314);
    DeRef(_30844);
    _30844 = NOVALUE;
    DeRef(_30808);
    _30808 = NOVALUE;
    DeRef(_30836);
    _30836 = NOVALUE;
    _30815 = NOVALUE;
    DeRef(_30890);
    _30890 = NOVALUE;
    _30884 = NOVALUE;
    DeRef(_30803);
    _30803 = NOVALUE;
    DeRef(_30919);
    _30919 = NOVALUE;
    DeRef(_30921);
    _30921 = NOVALUE;
    _30934 = NOVALUE;
    _30880 = NOVALUE;
    _30850 = NOVALUE;
    _30819 = NOVALUE;
    _30881 = NOVALUE;
    _30877 = NOVALUE;
    DeRef(_30822);
    _30822 = NOVALUE;
    return;
    ;
}


void _45ExecCommand()
{
    object _0, _1, _2;
    

    /** parser.e:4709		if TRANSLATE then*/
    if (_36TRANSLATE_21369 == 0)
    {
        goto L1; // [5] 16
    }
    else{
    }

    /** parser.e:4710			emit_op(RETURNT)*/
    _47emit_op(34);
L1: 

    /** parser.e:4712		StraightenBranches()  -- straighten top-level*/
    _45StraightenBranches();

    /** parser.e:4713	end procedure*/
    return;
    ;
}


object _45undefined_var(object _tok_62709, object _scope_62710)
{
    object _forward_62712 = NOVALUE;
    object _30949 = NOVALUE;
    object _30948 = NOVALUE;
    object _30945 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:4716		token forward = next_token()*/
    _0 = _forward_62712;
    _forward_62712 = _45next_token();
    DeRef(_0);

    /** parser.e:4717			switch forward[T_ID] do*/
    _2 = (object)SEQ_PTR(_forward_62712);
    _30945 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_30945) ){
        goto L1; // [16] 82
    }
    if(!IS_ATOM_INT(_30945)){
        if( (DBL_PTR(_30945)->dbl != (eudouble) ((object) DBL_PTR(_30945)->dbl) ) ){
            goto L1; // [16] 82
        }
        _0 = (object) DBL_PTR(_30945)->dbl;
    }
    else {
        _0 = _30945;
    };
    _30945 = NOVALUE;
    switch ( _0 ){ 

        /** parser.e:4718				case LEFT_ROUND then*/
        case -26:

        /** parser.e:4719					StartSourceLine( TRUE )*/
        _47StartSourceLine(_13TRUE_447, 0, 2);

        /** parser.e:4720					Forward_call( tok )*/
        Ref(_tok_62709);
        _45Forward_call(_tok_62709, 195);

        /** parser.e:4721					return 1*/
        DeRef(_tok_62709);
        DeRef(_forward_62712);
        return 1;
        goto L2; // [48] 96

        /** parser.e:4723				case VARIABLE then*/
        case -100:

        /** parser.e:4724					putback( forward )*/
        Ref(_forward_62712);
        _45putback(_forward_62712);

        /** parser.e:4725					Global_declaration( tok[T_SYM], scope )*/
        _2 = (object)SEQ_PTR(_tok_62709);
        _30948 = (object)*(((s1_ptr)_2)->base + 2);
        Ref(_30948);
        _30949 = _45Global_declaration(_30948, _scope_62710);
        _30948 = NOVALUE;

        /** parser.e:4726					return 1*/
        DeRef(_tok_62709);
        DeRef(_forward_62712);
        DeRef(_30949);
        _30949 = NOVALUE;
        return 1;
        goto L2; // [78] 96

        /** parser.e:4728				case else*/
        default:
L1: 

        /** parser.e:4729					putback( forward )*/
        Ref(_forward_62712);
        _45putback(_forward_62712);

        /** parser.e:4730					return 0*/
        DeRef(_tok_62709);
        DeRef(_forward_62712);
        DeRef(_30949);
        _30949 = NOVALUE;
        return 0;
    ;}L2: 
    ;
}


void _45real_parser(object _nested_62731)
{
    object _tok_62733 = NOVALUE;
    object _id_62734 = NOVALUE;
    object _scope_62735 = NOVALUE;
    object _deprecated_62797 = NOVALUE;
    object _test_62892 = NOVALUE;
    object _31089 = NOVALUE;
    object _31087 = NOVALUE;
    object _31086 = NOVALUE;
    object _31085 = NOVALUE;
    object _31084 = NOVALUE;
    object _31083 = NOVALUE;
    object _31082 = NOVALUE;
    object _31081 = NOVALUE;
    object _31076 = NOVALUE;
    object _31075 = NOVALUE;
    object _31072 = NOVALUE;
    object _31070 = NOVALUE;
    object _31069 = NOVALUE;
    object _31066 = NOVALUE;
    object _31052 = NOVALUE;
    object _31045 = NOVALUE;
    object _31044 = NOVALUE;
    object _31042 = NOVALUE;
    object _31040 = NOVALUE;
    object _31039 = NOVALUE;
    object _31037 = NOVALUE;
    object _31035 = NOVALUE;
    object _31030 = NOVALUE;
    object _31028 = NOVALUE;
    object _31026 = NOVALUE;
    object _31025 = NOVALUE;
    object _31024 = NOVALUE;
    object _31022 = NOVALUE;
    object _31020 = NOVALUE;
    object _31018 = NOVALUE;
    object _31016 = NOVALUE;
    object _31015 = NOVALUE;
    object _31014 = NOVALUE;
    object _31013 = NOVALUE;
    object _31012 = NOVALUE;
    object _31011 = NOVALUE;
    object _31010 = NOVALUE;
    object _31009 = NOVALUE;
    object _31008 = NOVALUE;
    object _31007 = NOVALUE;
    object _31006 = NOVALUE;
    object _31005 = NOVALUE;
    object _31004 = NOVALUE;
    object _31003 = NOVALUE;
    object _31001 = NOVALUE;
    object _31000 = NOVALUE;
    object _30999 = NOVALUE;
    object _30998 = NOVALUE;
    object _30996 = NOVALUE;
    object _30994 = NOVALUE;
    object _30993 = NOVALUE;
    object _30992 = NOVALUE;
    object _30990 = NOVALUE;
    object _30979 = NOVALUE;
    object _30977 = NOVALUE;
    object _30976 = NOVALUE;
    object _30975 = NOVALUE;
    object _30974 = NOVALUE;
    object _30973 = NOVALUE;
    object _30972 = NOVALUE;
    object _30971 = NOVALUE;
    object _30970 = NOVALUE;
    object _30969 = NOVALUE;
    object _30967 = NOVALUE;
    object _30966 = NOVALUE;
    object _30965 = NOVALUE;
    object _30964 = NOVALUE;
    object _30963 = NOVALUE;
    object _30962 = NOVALUE;
    object _30961 = NOVALUE;
    object _30960 = NOVALUE;
    object _30959 = NOVALUE;
    object _30958 = NOVALUE;
    object _30956 = NOVALUE;
    object _30952 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:4737		integer id*/

    /** parser.e:4738		integer scope*/

    /** parser.e:4740		while TRUE do  -- infinite loop until scanner aborts*/
L1: 
    if (_13TRUE_447 == 0)
    {
        goto L2; // [14] 1925
    }
    else{
    }

    /** parser.e:4741			if OpInline = 25000 then*/
    if (_36OpInline_21845 != 25000)
    goto L3; // [21] 35

    /** parser.e:4742				CompileErr("OpInline went nuts: [1]", OpInline )*/
    RefDS(_30951);
    _50CompileErr(_30951, _36OpInline_21845, 0);
L3: 

    /** parser.e:4744			start_index = length(Code)+1*/
    if (IS_SEQUENCE(_36Code_21859)){
            _30952 = SEQ_PTR(_36Code_21859)->length;
    }
    else {
        _30952 = 1;
    }
    _45start_index_55362 = _30952 + 1;
    _30952 = NOVALUE;

    /** parser.e:4745			tok = next_token()*/
    _0 = _tok_62733;
    _tok_62733 = _45next_token();
    DeRef(_0);

    /** parser.e:4746			id = tok[T_ID]*/
    _2 = (object)SEQ_PTR(_tok_62733);
    _id_62734 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_id_62734)){
        _id_62734 = (object)DBL_PTR(_id_62734)->dbl;
    }

    /** parser.e:4747			if id = VARIABLE or id = QUALIFIED_VARIABLE then*/
    _30956 = (_id_62734 == -100);
    if (_30956 != 0) {
        goto L4; // [69] 84
    }
    _30958 = (_id_62734 == 512);
    if (_30958 == 0)
    {
        DeRef(_30958);
        _30958 = NOVALUE;
        goto L5; // [80] 151
    }
    else{
        DeRef(_30958);
        _30958 = NOVALUE;
    }
L4: 

    /** parser.e:4748				if SymTab[tok[T_SYM]][S_SCOPE] = SC_UNDEFINED*/
    _2 = (object)SEQ_PTR(_tok_62733);
    _30959 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!IS_ATOM_INT(_30959)){
        _30960 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_30959)->dbl));
    }
    else{
        _30960 = (object)*(((s1_ptr)_2)->base + _30959);
    }
    _2 = (object)SEQ_PTR(_30960);
    _30961 = (object)*(((s1_ptr)_2)->base + 4);
    _30960 = NOVALUE;
    if (IS_ATOM_INT(_30961)) {
        _30962 = (_30961 == 9);
    }
    else {
        _30962 = binary_op(EQUALS, _30961, 9);
    }
    _30961 = NOVALUE;
    if (IS_ATOM_INT(_30962)) {
        if (_30962 == 0) {
            goto L6; // [110] 130
        }
    }
    else {
        if (DBL_PTR(_30962)->dbl == 0.0) {
            goto L6; // [110] 130
        }
    }
    Ref(_tok_62733);
    _30964 = _45undefined_var(_tok_62733, 5);
    if (_30964 == 0) {
        DeRef(_30964);
        _30964 = NOVALUE;
        goto L6; // [122] 130
    }
    else {
        if (!IS_ATOM_INT(_30964) && DBL_PTR(_30964)->dbl == 0.0){
            DeRef(_30964);
            _30964 = NOVALUE;
            goto L6; // [122] 130
        }
        DeRef(_30964);
        _30964 = NOVALUE;
    }
    DeRef(_30964);
    _30964 = NOVALUE;

    /** parser.e:4750					continue*/
    goto L1; // [127] 12
L6: 

    /** parser.e:4752				StartSourceLine(TRUE)*/
    _47StartSourceLine(_13TRUE_447, 0, 2);

    /** parser.e:4753				Assignment(tok)*/
    Ref(_tok_62733);
    _45Assignment(_tok_62733);

    /** parser.e:4754				ExecCommand()*/
    _45ExecCommand();
    goto L7; // [148] 1915
L5: 

    /** parser.e:4756			elsif id = PROCEDURE or id = FUNCTION or id = TYPE_DECL then*/
    _30965 = (_id_62734 == 405);
    if (_30965 != 0) {
        _30966 = 1;
        goto L8; // [159] 173
    }
    _30967 = (_id_62734 == 406);
    _30966 = (_30967 != 0);
L8: 
    if (_30966 != 0) {
        goto L9; // [173] 188
    }
    _30969 = (_id_62734 == 416);
    if (_30969 == 0)
    {
        DeRef(_30969);
        _30969 = NOVALUE;
        goto LA; // [184] 206
    }
    else{
        DeRef(_30969);
        _30969 = NOVALUE;
    }
L9: 

    /** parser.e:4757				SubProg(tok[T_ID], SC_LOCAL, 0)*/
    _2 = (object)SEQ_PTR(_tok_62733);
    _30970 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_30970);
    _45SubProg(_30970, 5, 0);
    _30970 = NOVALUE;
    goto L7; // [203] 1915
LA: 

    /** parser.e:4759			elsif id = GLOBAL or id = EXPORT or id = OVERRIDE or id = PUBLIC or id = DEPRECATE then*/
    _30971 = (_id_62734 == 412);
    if (_30971 != 0) {
        _30972 = 1;
        goto LB; // [214] 228
    }
    _30973 = (_id_62734 == 428);
    _30972 = (_30973 != 0);
LB: 
    if (_30972 != 0) {
        _30974 = 1;
        goto LC; // [228] 242
    }
    _30975 = (_id_62734 == 429);
    _30974 = (_30975 != 0);
LC: 
    if (_30974 != 0) {
        _30976 = 1;
        goto LD; // [242] 256
    }
    _30977 = (_id_62734 == 430);
    _30976 = (_30977 != 0);
LD: 
    if (_30976 != 0) {
        goto LE; // [256] 271
    }
    _30979 = (_id_62734 == 433);
    if (_30979 == 0)
    {
        DeRef(_30979);
        _30979 = NOVALUE;
        goto LF; // [267] 692
    }
    else{
        DeRef(_30979);
        _30979 = NOVALUE;
    }
LE: 

    /** parser.e:4760				integer deprecated = 0*/
    _deprecated_62797 = 0;

    /** parser.e:4762				if id = DEPRECATE then*/
    if (_id_62734 != 433)
    goto L10; // [280] 305

    /** parser.e:4763					deprecated = 1*/
    _deprecated_62797 = 1;

    /** parser.e:4765					tok = next_token()*/
    _0 = _tok_62733;
    _tok_62733 = _45next_token();
    DeRef(_0);

    /** parser.e:4766					id = tok[T_ID]*/
    _2 = (object)SEQ_PTR(_tok_62733);
    _id_62734 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_id_62734)){
        _id_62734 = (object)DBL_PTR(_id_62734)->dbl;
    }
L10: 

    /** parser.e:4769				scope = SC_LOCAL*/
    _scope_62735 = 5;

    /** parser.e:4770				if id = GLOBAL then*/
    if (_id_62734 != 412)
    goto L11; // [318] 334

    /** parser.e:4771				    scope = SC_GLOBAL*/
    _scope_62735 = 6;
    goto L12; // [331] 393
L11: 

    /** parser.e:4772				elsif id = EXPORT then*/
    if (_id_62734 != 428)
    goto L13; // [338] 354

    /** parser.e:4773					scope = SC_EXPORT*/
    _scope_62735 = 11;
    goto L12; // [351] 393
L13: 

    /** parser.e:4774				elsif id = OVERRIDE then*/
    if (_id_62734 != 429)
    goto L14; // [358] 374

    /** parser.e:4775					scope = SC_OVERRIDE*/
    _scope_62735 = 12;
    goto L12; // [371] 393
L14: 

    /** parser.e:4776				elsif id = PUBLIC then*/
    if (_id_62734 != 430)
    goto L15; // [378] 392

    /** parser.e:4777					scope = SC_PUBLIC*/
    _scope_62735 = 13;
L15: 
L12: 

    /** parser.e:4781				if scope != SC_LOCAL then*/
    if (_scope_62735 == 5)
    goto L16; // [397] 417

    /** parser.e:4782					tok = next_token()*/
    _0 = _tok_62733;
    _tok_62733 = _45next_token();
    DeRef(_0);

    /** parser.e:4783					id = tok[T_ID]*/
    _2 = (object)SEQ_PTR(_tok_62733);
    _id_62734 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_id_62734)){
        _id_62734 = (object)DBL_PTR(_id_62734)->dbl;
    }
L16: 

    /** parser.e:4786				if id = TYPE or id = QUALIFIED_TYPE then*/
    _30990 = (_id_62734 == 504);
    if (_30990 != 0) {
        goto L17; // [425] 440
    }
    _30992 = (_id_62734 == 522);
    if (_30992 == 0)
    {
        DeRef(_30992);
        _30992 = NOVALUE;
        goto L18; // [436] 456
    }
    else{
        DeRef(_30992);
        _30992 = NOVALUE;
    }
L17: 

    /** parser.e:4787					Global_declaration(tok[T_SYM], scope )*/
    _2 = (object)SEQ_PTR(_tok_62733);
    _30993 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_30993);
    _30994 = _45Global_declaration(_30993, _scope_62735);
    _30993 = NOVALUE;
    goto L19; // [453] 687
L18: 

    /** parser.e:4789				elsif id = CONSTANT then*/
    if (_id_62734 != 417)
    goto L1A; // [460] 478

    /** parser.e:4790					Global_declaration(0, scope )*/
    _30996 = _45Global_declaration(0, _scope_62735);

    /** parser.e:4791					ExecCommand()*/
    _45ExecCommand();
    goto L19; // [475] 687
L1A: 

    /** parser.e:4793				elsif id = ENUM then*/
    if (_id_62734 != 427)
    goto L1B; // [482] 500

    /** parser.e:4794					Global_declaration(-1, scope )*/
    _30998 = _45Global_declaration(-1, _scope_62735);

    /** parser.e:4795					ExecCommand()*/
    _45ExecCommand();
    goto L19; // [497] 687
L1B: 

    /** parser.e:4797				elsif id = PROCEDURE or id = FUNCTION or id = TYPE_DECL then*/
    _30999 = (_id_62734 == 405);
    if (_30999 != 0) {
        _31000 = 1;
        goto L1C; // [508] 522
    }
    _31001 = (_id_62734 == 406);
    _31000 = (_31001 != 0);
L1C: 
    if (_31000 != 0) {
        goto L1D; // [522] 537
    }
    _31003 = (_id_62734 == 416);
    if (_31003 == 0)
    {
        DeRef(_31003);
        _31003 = NOVALUE;
        goto L1E; // [533] 547
    }
    else{
        DeRef(_31003);
        _31003 = NOVALUE;
    }
L1D: 

    /** parser.e:4798					SubProg(id, scope, deprecated)*/
    _45SubProg(_id_62734, _scope_62735, _deprecated_62797);
    goto L19; // [544] 687
L1E: 

    /** parser.e:4800				elsif (scope = SC_PUBLIC) and id = INCLUDE then*/
    _31004 = (_scope_62735 == 13);
    if (_31004 == 0) {
        goto L1F; // [555] 581
    }
    _31006 = (_id_62734 == 418);
    if (_31006 == 0)
    {
        DeRef(_31006);
        _31006 = NOVALUE;
        goto L1F; // [566] 581
    }
    else{
        DeRef(_31006);
        _31006 = NOVALUE;
    }

    /** parser.e:4801					IncludeScan( 1 )*/
    _62IncludeScan(1);

    /** parser.e:4802					PushGoto()*/
    _45PushGoto();
    goto L19; // [578] 687
L1F: 

    /** parser.e:4803				elsif (id = VARIABLE or id = QUALIFIED_VARIABLE)*/
    _31007 = (_id_62734 == -100);
    if (_31007 != 0) {
        _31008 = 1;
        goto L20; // [589] 603
    }
    _31009 = (_id_62734 == 512);
    _31008 = (_31009 != 0);
L20: 
    if (_31008 == 0) {
        _31010 = 0;
        goto L21; // [603] 635
    }
    _2 = (object)SEQ_PTR(_tok_62733);
    _31011 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!IS_ATOM_INT(_31011)){
        _31012 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31011)->dbl));
    }
    else{
        _31012 = (object)*(((s1_ptr)_2)->base + _31011);
    }
    _2 = (object)SEQ_PTR(_31012);
    _31013 = (object)*(((s1_ptr)_2)->base + 4);
    _31012 = NOVALUE;
    if (IS_ATOM_INT(_31013)) {
        _31014 = (_31013 == 9);
    }
    else {
        _31014 = binary_op(EQUALS, _31013, 9);
    }
    _31013 = NOVALUE;
    if (IS_ATOM_INT(_31014))
    _31010 = (_31014 != 0);
    else
    _31010 = DBL_PTR(_31014)->dbl != 0.0;
L21: 
    if (_31010 == 0) {
        goto L22; // [635] 657
    }
    Ref(_tok_62733);
    _31016 = _45undefined_var(_tok_62733, _scope_62735);
    if (_31016 == 0) {
        DeRef(_31016);
        _31016 = NOVALUE;
        goto L22; // [645] 657
    }
    else {
        if (!IS_ATOM_INT(_31016) && DBL_PTR(_31016)->dbl == 0.0){
            DeRef(_31016);
            _31016 = NOVALUE;
            goto L22; // [645] 657
        }
        DeRef(_31016);
        _31016 = NOVALUE;
    }
    DeRef(_31016);
    _31016 = NOVALUE;

    /** parser.e:4807					continue*/
    goto L1; // [652] 12
    goto L19; // [654] 687
L22: 

    /** parser.e:4809				elsif scope = SC_GLOBAL then*/
    if (_scope_62735 != 6)
    goto L23; // [661] 677

    /** parser.e:4810					CompileErr( MSG_GLOBAL_MUST_BE_FOLLOWED_BYA_TYPE_CONSTANT_ENUM_PROCEDURE_TYPE_OR_FUNCTION)*/
    RefDS(_22190);
    _50CompileErr(18, _22190, 0);
    goto L19; // [674] 687
L23: 

    /** parser.e:4812					CompileErr( MSG_PUBLIC_OR_EXPORT_MUST_BE_FOLLOWED_BYA_TYPE_CONSTANT_ENUM_PROCEDURE_TYPE_OR_FUNCTION)*/
    RefDS(_22190);
    _50CompileErr(16, _22190, 0);
L19: 
    goto L7; // [689] 1915
LF: 

    /** parser.e:4815			elsif id = TYPE or id = QUALIFIED_TYPE then*/
    _31018 = (_id_62734 == 504);
    if (_31018 != 0) {
        goto L24; // [700] 715
    }
    _31020 = (_id_62734 == 522);
    if (_31020 == 0)
    {
        DeRef(_31020);
        _31020 = NOVALUE;
        goto L25; // [711] 800
    }
    else{
        DeRef(_31020);
        _31020 = NOVALUE;
    }
L24: 

    /** parser.e:4816				token test = next_token()*/
    _0 = _test_62892;
    _test_62892 = _45next_token();
    DeRef(_0);

    /** parser.e:4817				putback( test )*/
    Ref(_test_62892);
    _45putback(_test_62892);

    /** parser.e:4818				if test[T_ID] = LEFT_ROUND then*/
    _2 = (object)SEQ_PTR(_test_62892);
    _31022 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _31022, -26)){
        _31022 = NOVALUE;
        goto L26; // [735] 773
    }
    _31022 = NOVALUE;

    /** parser.e:4819						StartSourceLine( TRUE )*/
    _47StartSourceLine(_13TRUE_447, 0, 2);

    /** parser.e:4820						Procedure_call(tok)*/
    Ref(_tok_62733);
    _45Procedure_call(_tok_62733);

    /** parser.e:4821						clear_op()*/
    _47clear_op();

    /** parser.e:4822						if Pop() then end if*/
    _31024 = _47Pop();
    if (_31024 == 0) {
        DeRef(_31024);
        _31024 = NOVALUE;
        goto L27; // [762] 766
    }
    else {
        if (!IS_ATOM_INT(_31024) && DBL_PTR(_31024)->dbl == 0.0){
            DeRef(_31024);
            _31024 = NOVALUE;
            goto L27; // [762] 766
        }
        DeRef(_31024);
        _31024 = NOVALUE;
    }
    DeRef(_31024);
    _31024 = NOVALUE;
L27: 

    /** parser.e:4823						ExecCommand()*/
    _45ExecCommand();
    goto L28; // [770] 789
L26: 

    /** parser.e:4826					Global_declaration( tok[T_SYM], SC_LOCAL )*/
    _2 = (object)SEQ_PTR(_tok_62733);
    _31025 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_31025);
    _31026 = _45Global_declaration(_31025, 5);
    _31025 = NOVALUE;
L28: 

    /** parser.e:4829				continue*/
    DeRef(_test_62892);
    _test_62892 = NOVALUE;
    goto L1; // [793] 12
    goto L7; // [797] 1915
L25: 

    /** parser.e:4831			elsif id = CONSTANT then*/
    if (_id_62734 != 417)
    goto L29; // [804] 824

    /** parser.e:4832				Global_declaration(0, SC_LOCAL)*/
    _31028 = _45Global_declaration(0, 5);

    /** parser.e:4833				ExecCommand()*/
    _45ExecCommand();
    goto L7; // [821] 1915
L29: 

    /** parser.e:4835			elsif id = ENUM then*/
    if (_id_62734 != 427)
    goto L2A; // [828] 848

    /** parser.e:4836				Global_declaration(-1, SC_LOCAL)*/
    _31030 = _45Global_declaration(-1, 5);

    /** parser.e:4837				ExecCommand()*/
    _45ExecCommand();
    goto L7; // [845] 1915
L2A: 

    /** parser.e:4839			elsif id = IF then*/
    if (_id_62734 != 20)
    goto L2B; // [852] 876

    /** parser.e:4840				StartSourceLine(TRUE)*/
    _47StartSourceLine(_13TRUE_447, 0, 2);

    /** parser.e:4841				If_statement()*/
    _45If_statement();

    /** parser.e:4842				ExecCommand()*/
    _45ExecCommand();
    goto L7; // [873] 1915
L2B: 

    /** parser.e:4844			elsif id = FOR then*/
    if (_id_62734 != 21)
    goto L2C; // [880] 904

    /** parser.e:4845				StartSourceLine(TRUE)*/
    _47StartSourceLine(_13TRUE_447, 0, 2);

    /** parser.e:4846				For_statement()*/
    _45For_statement();

    /** parser.e:4847				ExecCommand()*/
    _45ExecCommand();
    goto L7; // [901] 1915
L2C: 

    /** parser.e:4849			elsif id = WHILE then*/
    if (_id_62734 != 47)
    goto L2D; // [908] 932

    /** parser.e:4850				StartSourceLine(TRUE)*/
    _47StartSourceLine(_13TRUE_447, 0, 2);

    /** parser.e:4851				While_statement()*/
    _45While_statement();

    /** parser.e:4852				ExecCommand()*/
    _45ExecCommand();
    goto L7; // [929] 1915
L2D: 

    /** parser.e:4854			elsif id = LOOP then*/
    if (_id_62734 != 422)
    goto L2E; // [936] 960

    /** parser.e:4855			    StartSourceLine(TRUE)*/
    _47StartSourceLine(_13TRUE_447, 0, 2);

    /** parser.e:4856			    Loop_statement()*/
    _45Loop_statement();

    /** parser.e:4857			    ExecCommand()*/
    _45ExecCommand();
    goto L7; // [957] 1915
L2E: 

    /** parser.e:4859			elsif id = PROC or id = QUALIFIED_PROC then*/
    _31035 = (_id_62734 == 27);
    if (_31035 != 0) {
        goto L2F; // [968] 983
    }
    _31037 = (_id_62734 == 521);
    if (_31037 == 0)
    {
        DeRef(_31037);
        _31037 = NOVALUE;
        goto L30; // [979] 1024
    }
    else{
        DeRef(_31037);
        _31037 = NOVALUE;
    }
L2F: 

    /** parser.e:4860				StartSourceLine(TRUE)*/
    _47StartSourceLine(_13TRUE_447, 0, 2);

    /** parser.e:4861				if id = PROC then*/
    if (_id_62734 != 27)
    goto L31; // [996] 1012

    /** parser.e:4863					UndefinedVar( tok[T_SYM] )*/
    _2 = (object)SEQ_PTR(_tok_62733);
    _31039 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_31039);
    _45UndefinedVar(_31039);
    _31039 = NOVALUE;
L31: 

    /** parser.e:4866				Procedure_call(tok)*/
    Ref(_tok_62733);
    _45Procedure_call(_tok_62733);

    /** parser.e:4867				ExecCommand()*/
    _45ExecCommand();
    goto L7; // [1021] 1915
L30: 

    /** parser.e:4869			elsif id = FUNC or id = QUALIFIED_FUNC then*/
    _31040 = (_id_62734 == 501);
    if (_31040 != 0) {
        goto L32; // [1032] 1047
    }
    _31042 = (_id_62734 == 520);
    if (_31042 == 0)
    {
        DeRef(_31042);
        _31042 = NOVALUE;
        goto L33; // [1043] 1101
    }
    else{
        DeRef(_31042);
        _31042 = NOVALUE;
    }
L32: 

    /** parser.e:4870				StartSourceLine(TRUE)*/
    _47StartSourceLine(_13TRUE_447, 0, 2);

    /** parser.e:4871				if id = FUNC then*/
    if (_id_62734 != 501)
    goto L34; // [1060] 1076

    /** parser.e:4873					UndefinedVar( tok[T_SYM] )*/
    _2 = (object)SEQ_PTR(_tok_62733);
    _31044 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_31044);
    _45UndefinedVar(_31044);
    _31044 = NOVALUE;
L34: 

    /** parser.e:4876				Procedure_call(tok)*/
    Ref(_tok_62733);
    _45Procedure_call(_tok_62733);

    /** parser.e:4877				clear_op()*/
    _47clear_op();

    /** parser.e:4878				if Pop() then end if*/
    _31045 = _47Pop();
    if (_31045 == 0) {
        DeRef(_31045);
        _31045 = NOVALUE;
        goto L35; // [1090] 1094
    }
    else {
        if (!IS_ATOM_INT(_31045) && DBL_PTR(_31045)->dbl == 0.0){
            DeRef(_31045);
            _31045 = NOVALUE;
            goto L35; // [1090] 1094
        }
        DeRef(_31045);
        _31045 = NOVALUE;
    }
    DeRef(_31045);
    _31045 = NOVALUE;
L35: 

    /** parser.e:4879				ExecCommand()*/
    _45ExecCommand();
    goto L7; // [1098] 1915
L33: 

    /** parser.e:4881			elsif id = RETURN then*/
    if (_id_62734 != 413)
    goto L36; // [1105] 1116

    /** parser.e:4882				Return_statement() -- will fail - not allowed at top level*/
    _45Return_statement();
    goto L7; // [1113] 1915
L36: 

    /** parser.e:4884			elsif id = EXIT then*/
    if (_id_62734 != 61)
    goto L37; // [1120] 1158

    /** parser.e:4885				if nested then*/
    if (_nested_62731 == 0)
    {
        goto L38; // [1126] 1145
    }
    else{
    }

    /** parser.e:4886				StartSourceLine(TRUE)*/
    _47StartSourceLine(_13TRUE_447, 0, 2);

    /** parser.e:4887				Exit_statement()*/
    _45Exit_statement();
    goto L7; // [1142] 1915
L38: 

    /** parser.e:4889				CompileErr(EXIT_MUST_BE_INSIDE_A_LOOP)*/
    RefDS(_22190);
    _50CompileErr(89, _22190, 0);
    goto L7; // [1155] 1915
L37: 

    /** parser.e:4892			elsif id = INCLUDE then*/
    if (_id_62734 != 418)
    goto L39; // [1162] 1178

    /** parser.e:4893				IncludeScan( 0 )*/
    _62IncludeScan(0);

    /** parser.e:4894				PushGoto()*/
    _45PushGoto();
    goto L7; // [1175] 1915
L39: 

    /** parser.e:4896			elsif id = WITH then*/
    if (_id_62734 != 420)
    goto L3A; // [1182] 1196

    /** parser.e:4897				SetWith(TRUE)*/
    _45SetWith(_13TRUE_447);
    goto L7; // [1193] 1915
L3A: 

    /** parser.e:4899			elsif id = WITHOUT then*/
    if (_id_62734 != 421)
    goto L3B; // [1200] 1214

    /** parser.e:4900				SetWith(FALSE)*/
    _45SetWith(_13FALSE_445);
    goto L7; // [1211] 1915
L3B: 

    /** parser.e:4902			elsif id = END_OF_FILE then*/
    if (_id_62734 != -21)
    goto L3C; // [1218] 1335

    /** parser.e:4903				if IncludePop() then*/
    _31052 = _62IncludePop();
    if (_31052 == 0) {
        DeRef(_31052);
        _31052 = NOVALUE;
        goto L3D; // [1227] 1323
    }
    else {
        if (!IS_ATOM_INT(_31052) && DBL_PTR(_31052)->dbl == 0.0){
            DeRef(_31052);
            _31052 = NOVALUE;
            goto L3D; // [1227] 1323
        }
        DeRef(_31052);
        _31052 = NOVALUE;
    }
    DeRef(_31052);
    _31052 = NOVALUE;

    /** parser.e:4904					backed_up_tok = {}*/
    RefDS(_22190);
    DeRef(_45backed_up_tok_55363);
    _45backed_up_tok_55363 = _22190;

    /** parser.e:4905					PopGoto()*/
    _45PopGoto();

    /** parser.e:4906					read_line()*/
    _62read_line();

    /** parser.e:4908					last_ForwardLine     = ThisLine*/
    Ref(_50ThisLine_49594);
    DeRef(_50last_ForwardLine_49597);
    _50last_ForwardLine_49597 = _50ThisLine_49594;

    /** parser.e:4909					last_fwd_line_number = line_number*/
    _36last_fwd_line_number_21771 = _36line_number_21768;

    /** parser.e:4910					last_forward_bp      = bp*/
    _50last_forward_bp_49601 = _50bp_49598;

    /** parser.e:4912					putback_ForwardLine     = ThisLine*/
    Ref(_50ThisLine_49594);
    DeRef(_50putback_ForwardLine_49596);
    _50putback_ForwardLine_49596 = _50ThisLine_49594;

    /** parser.e:4913					putback_fwd_line_number = line_number*/
    _36putback_fwd_line_number_21770 = _36line_number_21768;

    /** parser.e:4914					putback_forward_bp      = bp*/
    _50putback_forward_bp_49600 = _50bp_49598;

    /** parser.e:4916					ForwardLine     = ThisLine*/
    Ref(_50ThisLine_49594);
    DeRef(_50ForwardLine_49595);
    _50ForwardLine_49595 = _50ThisLine_49594;

    /** parser.e:4917					fwd_line_number = line_number*/
    _36fwd_line_number_21769 = _36line_number_21768;

    /** parser.e:4918					forward_bp      = bp*/
    _50forward_bp_49599 = _50bp_49598;
    goto L7; // [1320] 1915
L3D: 

    /** parser.e:4921					CheckForUndefinedGotoLabels()*/
    _45CheckForUndefinedGotoLabels();

    /** parser.e:4922					exit -- all finished*/
    goto L2; // [1329] 1925
    goto L7; // [1332] 1915
L3C: 

    /** parser.e:4925			elsif id = QUESTION_MARK then*/
    if (_id_62734 != -31)
    goto L3E; // [1339] 1363

    /** parser.e:4926				StartSourceLine(TRUE)*/
    _47StartSourceLine(_13TRUE_447, 0, 2);

    /** parser.e:4927				Print_statement()*/
    _45Print_statement();

    /** parser.e:4928				ExecCommand()*/
    _45ExecCommand();
    goto L7; // [1360] 1915
L3E: 

    /** parser.e:4930			elsif id = LABEL then*/
    if (_id_62734 != 419)
    goto L3F; // [1367] 1389

    /** parser.e:4931				StartSourceLine(TRUE, , COVERAGE_SUPPRESS)*/
    _47StartSourceLine(_13TRUE_447, 0, 1);

    /** parser.e:4932				GLabel_statement()*/
    _45GLabel_statement();
    goto L7; // [1386] 1915
L3F: 

    /** parser.e:4934			elsif id = GOTO then*/
    if (_id_62734 != 188)
    goto L40; // [1393] 1413

    /** parser.e:4935				StartSourceLine(TRUE)*/
    _47StartSourceLine(_13TRUE_447, 0, 2);

    /** parser.e:4936				Goto_statement()*/
    _45Goto_statement();
    goto L7; // [1410] 1915
L40: 

    /** parser.e:4938			elsif id = CONTINUE then*/
    if (_id_62734 != 426)
    goto L41; // [1417] 1455

    /** parser.e:4939				if nested then*/
    if (_nested_62731 == 0)
    {
        goto L42; // [1423] 1442
    }
    else{
    }

    /** parser.e:4940					StartSourceLine(TRUE)*/
    _47StartSourceLine(_13TRUE_447, 0, 2);

    /** parser.e:4941					Continue_statement()*/
    _45Continue_statement();
    goto L7; // [1439] 1915
L42: 

    /** parser.e:4943					CompileErr(CONTINUE_MUST_BE_INSIDE_A_LOOP)*/
    RefDS(_22190);
    _50CompileErr(50, _22190, 0);
    goto L7; // [1452] 1915
L41: 

    /** parser.e:4946			elsif id = RETRY then*/
    if (_id_62734 != 184)
    goto L43; // [1459] 1497

    /** parser.e:4947				if nested then*/
    if (_nested_62731 == 0)
    {
        goto L44; // [1465] 1484
    }
    else{
    }

    /** parser.e:4948					StartSourceLine(TRUE)*/
    _47StartSourceLine(_13TRUE_447, 0, 2);

    /** parser.e:4949					Retry_statement()*/
    _45Retry_statement();
    goto L7; // [1481] 1915
L44: 

    /** parser.e:4951					CompileErr(RETRY_MUST_BE_INSIDE_A_LOOP)*/
    RefDS(_22190);
    _50CompileErr(128, _22190, 0);
    goto L7; // [1494] 1915
L43: 

    /** parser.e:4954			elsif id = BREAK then*/
    if (_id_62734 != 425)
    goto L45; // [1501] 1539

    /** parser.e:4955				if nested then*/
    if (_nested_62731 == 0)
    {
        goto L46; // [1507] 1526
    }
    else{
    }

    /** parser.e:4956					StartSourceLine(TRUE)*/
    _47StartSourceLine(_13TRUE_447, 0, 2);

    /** parser.e:4957					Break_statement()*/
    _45Break_statement();
    goto L7; // [1523] 1915
L46: 

    /** parser.e:4959					CompileErr(BREAK_MUST_BE_INSIDE_AN_IF_BLOCK)*/
    RefDS(_22190);
    _50CompileErr(39, _22190, 0);
    goto L7; // [1536] 1915
L45: 

    /** parser.e:4962			elsif id = ENTRY then*/
    if (_id_62734 != 424)
    goto L47; // [1543] 1583

    /** parser.e:4963				if nested then*/
    if (_nested_62731 == 0)
    {
        goto L48; // [1549] 1570
    }
    else{
    }

    /** parser.e:4964				    StartSourceLine(TRUE, , COVERAGE_SUPPRESS)*/
    _47StartSourceLine(_13TRUE_447, 0, 1);

    /** parser.e:4965				    Entry_statement()*/
    _45Entry_statement();
    goto L7; // [1567] 1915
L48: 

    /** parser.e:4967					CompileErr(ENTRY_MUST_BE_INSIDE_A_LOOP)*/
    RefDS(_22190);
    _50CompileErr(72, _22190, 0);
    goto L7; // [1580] 1915
L47: 

    /** parser.e:4970			elsif id = IFDEF then*/
    if (_id_62734 != 407)
    goto L49; // [1587] 1607

    /** parser.e:4971				StartSourceLine(TRUE)*/
    _47StartSourceLine(_13TRUE_447, 0, 2);

    /** parser.e:4972				Ifdef_statement()*/
    _45Ifdef_statement();
    goto L7; // [1604] 1915
L49: 

    /** parser.e:4974			elsif id = CASE then*/
    if (_id_62734 != 186)
    goto L4A; // [1611] 1622

    /** parser.e:4975				Case_statement()*/
    _45Case_statement();
    goto L7; // [1619] 1915
L4A: 

    /** parser.e:4977			elsif id = SWITCH then*/
    if (_id_62734 != 185)
    goto L4B; // [1626] 1646

    /** parser.e:4978				StartSourceLine(TRUE)*/
    _47StartSourceLine(_13TRUE_447, 0, 2);

    /** parser.e:4979				Switch_statement()*/
    _45Switch_statement();
    goto L7; // [1643] 1915
L4B: 

    /** parser.e:4981			elsif id = LEFT_BRACE then*/
    if (_id_62734 != -24)
    goto L4C; // [1650] 1670

    /** parser.e:4982				StartSourceLine( TRUE )*/
    _47StartSourceLine(_13TRUE_447, 0, 2);

    /** parser.e:4983				Multi_assign()*/
    _45Multi_assign();
    goto L7; // [1667] 1915
L4C: 

    /** parser.e:4985			elsif id = ILLEGAL_CHAR then*/
    if (_id_62734 != -20)
    goto L4D; // [1674] 1690

    /** parser.e:4986				CompileErr(ILLEGAL_CHARACTER)*/
    RefDS(_22190);
    _50CompileErr(102, _22190, 0);
    goto L7; // [1687] 1915
L4D: 

    /** parser.e:4989				if nested then*/
    if (_nested_62731 == 0)
    {
        goto L4E; // [1692] 1852
    }
    else{
    }

    /** parser.e:4990					if id = ELSE then*/
    if (_id_62734 != 23)
    goto L4F; // [1699] 1757

    /** parser.e:4991						if length(if_stack) = 0 then*/
    if (IS_SEQUENCE(_45if_stack_55391)){
            _31066 = SEQ_PTR(_45if_stack_55391)->length;
    }
    else {
        _31066 = 1;
    }
    if (_31066 != 0)
    goto L50; // [1710] 1818

    /** parser.e:4992							if live_ifdef > 0 then*/
    if (_45live_ifdef_59858 <= 0)
    goto L51; // [1718] 1743

    /** parser.e:4993								CompileErr(SHOULD_THIS_BE_ELSEDEF_FOR_THE_IFDEF_ON_LINE_1, ifdef_lineno[$])*/
    if (IS_SEQUENCE(_45ifdef_lineno_59859)){
            _31069 = SEQ_PTR(_45ifdef_lineno_59859)->length;
    }
    else {
        _31069 = 1;
    }
    _2 = (object)SEQ_PTR(_45ifdef_lineno_59859);
    _31070 = (object)*(((s1_ptr)_2)->base + _31069);
    _50CompileErr(134, _31070, 0);
    _31070 = NOVALUE;
    goto L50; // [1740] 1818
L51: 

    /** parser.e:4995								CompileErr(NOT_EXPECTING_ELSE)*/
    RefDS(_22190);
    _50CompileErr(118, _22190, 0);
    goto L50; // [1754] 1818
L4F: 

    /** parser.e:4998					elsif id = ELSIF then*/
    if (_id_62734 != 414)
    goto L52; // [1761] 1817

    /** parser.e:4999						if length(if_stack) = 0 then*/
    if (IS_SEQUENCE(_45if_stack_55391)){
            _31072 = SEQ_PTR(_45if_stack_55391)->length;
    }
    else {
        _31072 = 1;
    }
    if (_31072 != 0)
    goto L53; // [1772] 1816

    /** parser.e:5000							if live_ifdef > 0 then*/
    if (_45live_ifdef_59858 <= 0)
    goto L54; // [1780] 1805

    /** parser.e:5001								CompileErr(SHOULD_THIS_BE_ELSIFDEF_FOR_THE_IFDEF_ON_LINE_1, ifdef_lineno[$])*/
    if (IS_SEQUENCE(_45ifdef_lineno_59859)){
            _31075 = SEQ_PTR(_45ifdef_lineno_59859)->length;
    }
    else {
        _31075 = 1;
    }
    _2 = (object)SEQ_PTR(_45ifdef_lineno_59859);
    _31076 = (object)*(((s1_ptr)_2)->base + _31075);
    _50CompileErr(139, _31076, 0);
    _31076 = NOVALUE;
    goto L55; // [1802] 1815
L54: 

    /** parser.e:5003								CompileErr(NOT_EXPECTING_ELSIF)*/
    RefDS(_22190);
    _50CompileErr(119, _22190, 0);
L55: 
L53: 
L52: 
L50: 

    /** parser.e:5007					putback(tok)*/
    Ref(_tok_62733);
    _45putback(_tok_62733);

    /** parser.e:5008					if stmt_nest > 0 then*/
    if (_45stmt_nest_55388 <= 0)
    goto L56; // [1827] 1844

    /** parser.e:5009						stmt_nest -= 1*/
    _45stmt_nest_55388 = _45stmt_nest_55388 - 1;

    /** parser.e:5010						InitDelete()*/
    _45InitDelete();
L56: 

    /** parser.e:5012					return*/
    DeRef(_tok_62733);
    DeRef(_31001);
    _31001 = NOVALUE;
    _31011 = NOVALUE;
    DeRef(_30999);
    _30999 = NOVALUE;
    DeRef(_31035);
    _31035 = NOVALUE;
    DeRef(_30967);
    _30967 = NOVALUE;
    DeRef(_30973);
    _30973 = NOVALUE;
    DeRef(_31018);
    _31018 = NOVALUE;
    DeRef(_31014);
    _31014 = NOVALUE;
    DeRef(_30990);
    _30990 = NOVALUE;
    DeRef(_31028);
    _31028 = NOVALUE;
    DeRef(_30977);
    _30977 = NOVALUE;
    DeRef(_30956);
    _30956 = NOVALUE;
    DeRef(_30996);
    _30996 = NOVALUE;
    DeRef(_30975);
    _30975 = NOVALUE;
    DeRef(_31009);
    _31009 = NOVALUE;
    DeRef(_31007);
    _31007 = NOVALUE;
    _30959 = NOVALUE;
    DeRef(_31040);
    _31040 = NOVALUE;
    DeRef(_31026);
    _31026 = NOVALUE;
    DeRef(_30998);
    _30998 = NOVALUE;
    DeRef(_30965);
    _30965 = NOVALUE;
    DeRef(_31030);
    _31030 = NOVALUE;
    DeRef(_31004);
    _31004 = NOVALUE;
    DeRef(_30994);
    _30994 = NOVALUE;
    DeRef(_30971);
    _30971 = NOVALUE;
    DeRef(_30962);
    _30962 = NOVALUE;
    return;
    goto L57; // [1849] 1914
L4E: 

    /** parser.e:5014					if id = END then*/
    if (_id_62734 != 402)
    goto L58; // [1856] 1889

    /** parser.e:5015						tok = next_token()*/
    _0 = _tok_62733;
    _tok_62733 = _45next_token();
    DeRef(_0);

    /** parser.e:5016						CompileErr(MSG_END_HAS_NO_MATCHING_1, {find_token_text(tok[T_ID])})*/
    _2 = (object)SEQ_PTR(_tok_62733);
    _31081 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_31081);
    _31082 = _63find_token_text(_31081);
    _31081 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _31082;
    _31083 = MAKE_SEQ(_1);
    _31082 = NOVALUE;
    _50CompileErr(17, _31083, 0);
    _31083 = NOVALUE;
L58: 

    /** parser.e:5019					CompileErr(NOT_EXPECTING_TO_SEE_1_HERE, { match_replace(",", find_token_text(id), "") })*/
    _31084 = _63find_token_text(_id_62734);
    RefDS(_26425);
    RefDS(_22190);
    _31085 = _16match_replace(_26425, _31084, _22190, 0);
    _31084 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _31085;
    _31086 = MAKE_SEQ(_1);
    _31085 = NOVALUE;
    _50CompileErr(117, _31086, 0);
    _31086 = NOVALUE;
L57: 
L7: 

    /** parser.e:5024			flush_temps()*/
    RefDS(_22190);
    _47flush_temps(_22190);

    /** parser.e:5025		end while*/
    goto L1; // [1922] 12
L2: 

    /** parser.e:5026		emit_op(RETURNT)*/
    _47emit_op(34);

    /** parser.e:5027		clear_last()*/
    _47clear_last();

    /** parser.e:5028		StraightenBranches()*/
    _45StraightenBranches();

    /** parser.e:5029		SymTab[TopLevelSub][S_CODE] = Code*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_36TopLevelSub_21774 + ((s1_ptr)_2)->base);
    RefDS(_36Code_21859);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_CODE_21416))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21416)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_CODE_21416);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36Code_21859;
    DeRef(_1);
    _31087 = NOVALUE;

    /** parser.e:5030		EndLineTable()*/
    _45EndLineTable();

    /** parser.e:5031		SymTab[TopLevelSub][S_LINETAB] = LineTable*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_36TopLevelSub_21774 + ((s1_ptr)_2)->base);
    RefDS(_36LineTable_21860);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_LINETAB_21439))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_LINETAB_21439)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_LINETAB_21439);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36LineTable_21860;
    DeRef(_1);
    _31089 = NOVALUE;

    /** parser.e:5032	end procedure*/
    DeRef(_tok_62733);
    DeRef(_31001);
    _31001 = NOVALUE;
    _31011 = NOVALUE;
    DeRef(_30999);
    _30999 = NOVALUE;
    DeRef(_31035);
    _31035 = NOVALUE;
    DeRef(_30967);
    _30967 = NOVALUE;
    DeRef(_30973);
    _30973 = NOVALUE;
    DeRef(_31018);
    _31018 = NOVALUE;
    DeRef(_31014);
    _31014 = NOVALUE;
    DeRef(_30990);
    _30990 = NOVALUE;
    DeRef(_31028);
    _31028 = NOVALUE;
    DeRef(_30977);
    _30977 = NOVALUE;
    DeRef(_30956);
    _30956 = NOVALUE;
    DeRef(_30996);
    _30996 = NOVALUE;
    DeRef(_30975);
    _30975 = NOVALUE;
    DeRef(_31009);
    _31009 = NOVALUE;
    DeRef(_31007);
    _31007 = NOVALUE;
    _30959 = NOVALUE;
    DeRef(_31040);
    _31040 = NOVALUE;
    DeRef(_31026);
    _31026 = NOVALUE;
    DeRef(_30998);
    _30998 = NOVALUE;
    DeRef(_30965);
    _30965 = NOVALUE;
    DeRef(_31030);
    _31030 = NOVALUE;
    DeRef(_31004);
    _31004 = NOVALUE;
    DeRef(_30994);
    _30994 = NOVALUE;
    DeRef(_30971);
    _30971 = NOVALUE;
    DeRef(_30962);
    _30962 = NOVALUE;
    return;
    ;
}


void _45parser()
{
    object _31093 = NOVALUE;
    object _31091 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:5035		real_parser(0)*/
    _45real_parser(0);

    /** parser.e:5036		mark_final_targets()*/
    _54mark_final_targets();

    /** parser.e:5037		resolve_unincluded_globals( 1 )*/
    _54resolve_unincluded_globals(1);

    /** parser.e:5038		Resolve_forward_references( 1 )*/
    _44Resolve_forward_references(1);

    /** parser.e:5039		SymTab[TopLevelSub][S_CODE] = Code*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_36TopLevelSub_21774 + ((s1_ptr)_2)->base);
    RefDS(_36Code_21859);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_CODE_21416))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21416)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_CODE_21416);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36Code_21859;
    DeRef(_1);
    _31091 = NOVALUE;

    /** parser.e:5040		SymTab[TopLevelSub][S_LINETAB] = LineTable*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_36TopLevelSub_21774 + ((s1_ptr)_2)->base);
    RefDS(_36LineTable_21860);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_LINETAB_21439))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_LINETAB_21439)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_LINETAB_21439);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36LineTable_21860;
    DeRef(_1);
    _31093 = NOVALUE;

    /** parser.e:5041		Code = {}*/
    RefDS(_22190);
    DeRefDS(_36Code_21859);
    _36Code_21859 = _22190;

    /** parser.e:5042		LineTable = {}*/
    RefDS(_22190);
    DeRefDS(_36LineTable_21860);
    _36LineTable_21860 = _22190;

    /** parser.e:5043		inline_deferred_calls()*/
    _67inline_deferred_calls();

    /** parser.e:5044		if not repl then*/

    /** parser.e:5045		End_block( PROC )*/
    _65End_block(27);

    /** parser.e:5046		Code = {}*/
    RefDS(_22190);
    DeRefDS(_36Code_21859);
    _36Code_21859 = _22190;

    /** parser.e:5047		LineTable = {}*/
    RefDS(_22190);
    DeRefDS(_36LineTable_21860);
    _36LineTable_21860 = _22190;

    /** parser.e:5049	end procedure*/
    return;
    ;
}


void _45nested_parser()
{
    object _0, _1, _2;
    

    /** parser.e:5052		real_parser(1)*/
    _45real_parser(1);

    /** parser.e:5053	end procedure*/
    return;
    ;
}



// 0xAE453CA4
