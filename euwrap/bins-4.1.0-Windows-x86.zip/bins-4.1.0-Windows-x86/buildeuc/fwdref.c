// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _44clear_fwd_refs()
{
    object _0, _1, _2;
    

    /** fwdref.e:70		fwdref_count = 0*/
    _44fwdref_count_63217 = 0;

    /** fwdref.e:71	end procedure*/
    return;
    ;
}


object _44get_fwdref_count()
{
    object _0, _1, _2;
    

    /** fwdref.e:74		return fwdref_count*/
    return _44fwdref_count_63217;
    ;
}


void _44set_glabel_block(object _ref_63224, object _block_63226)
{
    object _31101 = NOVALUE;
    object _31100 = NOVALUE;
    object _31098 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_ref_63224)) {
        _1 = (object)(DBL_PTR(_ref_63224)->dbl);
        DeRefDS(_ref_63224);
        _ref_63224 = _1;
    }
    if (!IS_ATOM_INT(_block_63226)) {
        _1 = (object)(DBL_PTR(_block_63226)->dbl);
        DeRefDS(_block_63226);
        _block_63226 = _1;
    }

    /** fwdref.e:78		forward_references[ref][FR_DATA] &= block*/
    _2 = (object)SEQ_PTR(_44forward_references_63197);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44forward_references_63197 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_63224 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _31100 = (object)*(((s1_ptr)_2)->base + 12);
    _31098 = NOVALUE;
    if (IS_SEQUENCE(_31100) && IS_ATOM(_block_63226)) {
        Append(&_31101, _31100, _block_63226);
    }
    else if (IS_ATOM(_31100) && IS_SEQUENCE(_block_63226)) {
    }
    else {
        Concat((object_ptr)&_31101, _31100, _block_63226);
        _31100 = NOVALUE;
    }
    _31100 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31101;
    if( _1 != _31101 ){
        DeRef(_1);
    }
    _31101 = NOVALUE;
    _31098 = NOVALUE;

    /** fwdref.e:79	end procedure*/
    return;
    ;
}


void _44replace_code(object _code_63238, object _start_63239, object _finish_63240, object _subprog_63241)
{
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_finish_63240)) {
        _1 = (object)(DBL_PTR(_finish_63240)->dbl);
        DeRefDS(_finish_63240);
        _finish_63240 = _1;
    }
    if (!IS_ATOM_INT(_subprog_63241)) {
        _1 = (object)(DBL_PTR(_subprog_63241)->dbl);
        DeRefDS(_subprog_63241);
        _subprog_63241 = _1;
    }

    /** fwdref.e:88		shifting_sub = subprog*/
    _44shifting_sub_63216 = _subprog_63241;

    /** fwdref.e:89		shift:replace_code( code, start, finish )*/
    RefDS(_code_63238);
    _66replace_code(_code_63238, _start_63239, _finish_63240);

    /** fwdref.e:90		shifting_sub = 0*/
    _44shifting_sub_63216 = 0;

    /** fwdref.e:91	end procedure*/
    DeRefDS(_code_63238);
    return;
    ;
}


void _44resolved_reference(object _ref_63244)
{
    object _file_63245 = NOVALUE;
    object _subprog_63248 = NOVALUE;
    object _tx_63251 = NOVALUE;
    object _ax_63252 = NOVALUE;
    object _sp_63253 = NOVALUE;
    object _r_63268 = NOVALUE;
    object _r_63286 = NOVALUE;
    object _31125 = NOVALUE;
    object _31124 = NOVALUE;
    object _31123 = NOVALUE;
    object _31121 = NOVALUE;
    object _31118 = NOVALUE;
    object _31116 = NOVALUE;
    object _31114 = NOVALUE;
    object _31113 = NOVALUE;
    object _31111 = NOVALUE;
    object _31109 = NOVALUE;
    object _31107 = NOVALUE;
    object _31106 = NOVALUE;
    object _31104 = NOVALUE;
    object _31102 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** fwdref.e:95			file    = forward_references[ref][FR_FILE],*/
    _2 = (object)SEQ_PTR(_44forward_references_63197);
    _31102 = (object)*(((s1_ptr)_2)->base + _ref_63244);
    _2 = (object)SEQ_PTR(_31102);
    _file_63245 = (object)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_file_63245)){
        _file_63245 = (object)DBL_PTR(_file_63245)->dbl;
    }
    _31102 = NOVALUE;

    /** fwdref.e:96			subprog = forward_references[ref][FR_SUBPROG]*/
    _2 = (object)SEQ_PTR(_44forward_references_63197);
    _31104 = (object)*(((s1_ptr)_2)->base + _ref_63244);
    _2 = (object)SEQ_PTR(_31104);
    _subprog_63248 = (object)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_subprog_63248)){
        _subprog_63248 = (object)DBL_PTR(_subprog_63248)->dbl;
    }
    _31104 = NOVALUE;

    /** fwdref.e:99			tx = 0,*/
    _tx_63251 = 0;

    /** fwdref.e:100			ax = 0,*/
    _ax_63252 = 0;

    /** fwdref.e:101			sp = 0*/
    _sp_63253 = 0;

    /** fwdref.e:103		if forward_references[ref][FR_SUBPROG] = TopLevelSub then*/
    _2 = (object)SEQ_PTR(_44forward_references_63197);
    _31106 = (object)*(((s1_ptr)_2)->base + _ref_63244);
    _2 = (object)SEQ_PTR(_31106);
    _31107 = (object)*(((s1_ptr)_2)->base + 4);
    _31106 = NOVALUE;
    if (binary_op_a(NOTEQ, _31107, _36TopLevelSub_21774)){
        _31107 = NOVALUE;
        goto L1; // [60] 80
    }
    _31107 = NOVALUE;

    /** fwdref.e:104			tx = find( ref, toplevel_references[file] )*/
    _2 = (object)SEQ_PTR(_44toplevel_references_63200);
    _31109 = (object)*(((s1_ptr)_2)->base + _file_63245);
    _tx_63251 = find_from(_ref_63244, _31109, 1);
    _31109 = NOVALUE;
    goto L2; // [77] 111
L1: 

    /** fwdref.e:106			sp = find( subprog, active_subprogs[file] )*/
    _2 = (object)SEQ_PTR(_44active_subprogs_63198);
    _31111 = (object)*(((s1_ptr)_2)->base + _file_63245);
    _sp_63253 = find_from(_subprog_63248, _31111, 1);
    _31111 = NOVALUE;

    /** fwdref.e:107			ax = find( ref, active_references[file][sp] )*/
    _2 = (object)SEQ_PTR(_44active_references_63199);
    _31113 = (object)*(((s1_ptr)_2)->base + _file_63245);
    _2 = (object)SEQ_PTR(_31113);
    _31114 = (object)*(((s1_ptr)_2)->base + _sp_63253);
    _31113 = NOVALUE;
    _ax_63252 = find_from(_ref_63244, _31114, 1);
    _31114 = NOVALUE;
L2: 

    /** fwdref.e:110		if ax then*/
    if (_ax_63252 == 0)
    {
        goto L3; // [113] 253
    }
    else{
    }

    /** fwdref.e:111			sequence r = active_references[file][sp] */
    _2 = (object)SEQ_PTR(_44active_references_63199);
    _31116 = (object)*(((s1_ptr)_2)->base + _file_63245);
    DeRef(_r_63268);
    _2 = (object)SEQ_PTR(_31116);
    _r_63268 = (object)*(((s1_ptr)_2)->base + _sp_63253);
    Ref(_r_63268);
    _31116 = NOVALUE;

    /** fwdref.e:112			active_references[file][sp] = 0*/
    _2 = (object)SEQ_PTR(_44active_references_63199);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44active_references_63199 = MAKE_SEQ(_2);
    }
    _3 = (object)(_file_63245 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _sp_63253);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);
    _31118 = NOVALUE;

    /** fwdref.e:113			r = remove( r, ax )*/
    {
        s1_ptr assign_space = SEQ_PTR(_r_63268);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_ax_63252)) ? _ax_63252 : (object)(DBL_PTR(_ax_63252)->dbl);
        int stop = (IS_ATOM_INT(_ax_63252)) ? _ax_63252 : (object)(DBL_PTR(_ax_63252)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_r_63268), start, &_r_63268 );
            }
            else Tail(SEQ_PTR(_r_63268), stop+1, &_r_63268);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_r_63268), start, &_r_63268);
        }
        else {
            assign_slice_seq = &assign_space;
            _r_63268 = Remove_elements(start, stop, (SEQ_PTR(_r_63268)->ref == 1));
        }
    }

    /** fwdref.e:114			active_references[file][sp] = r*/
    _2 = (object)SEQ_PTR(_44active_references_63199);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44active_references_63199 = MAKE_SEQ(_2);
    }
    _3 = (object)(_file_63245 + ((s1_ptr)_2)->base);
    RefDS(_r_63268);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _sp_63253);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _r_63268;
    DeRef(_1);
    _31121 = NOVALUE;

    /** fwdref.e:116			if not length( active_references[file][sp] ) then*/
    _2 = (object)SEQ_PTR(_44active_references_63199);
    _31123 = (object)*(((s1_ptr)_2)->base + _file_63245);
    _2 = (object)SEQ_PTR(_31123);
    _31124 = (object)*(((s1_ptr)_2)->base + _sp_63253);
    _31123 = NOVALUE;
    if (IS_SEQUENCE(_31124)){
            _31125 = SEQ_PTR(_31124)->length;
    }
    else {
        _31125 = 1;
    }
    _31124 = NOVALUE;
    if (_31125 != 0)
    goto L4; // [178] 248
    _31125 = NOVALUE;

    /** fwdref.e:117				r = active_references[file]*/
    DeRefDS(_r_63268);
    _2 = (object)SEQ_PTR(_44active_references_63199);
    _r_63268 = (object)*(((s1_ptr)_2)->base + _file_63245);
    Ref(_r_63268);

    /** fwdref.e:118				active_references[file] = 0*/
    _2 = (object)SEQ_PTR(_44active_references_63199);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44active_references_63199 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _file_63245);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);

    /** fwdref.e:119				r = remove( r, sp )*/
    {
        s1_ptr assign_space = SEQ_PTR(_r_63268);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_sp_63253)) ? _sp_63253 : (object)(DBL_PTR(_sp_63253)->dbl);
        int stop = (IS_ATOM_INT(_sp_63253)) ? _sp_63253 : (object)(DBL_PTR(_sp_63253)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_r_63268), start, &_r_63268 );
            }
            else Tail(SEQ_PTR(_r_63268), stop+1, &_r_63268);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_r_63268), start, &_r_63268);
        }
        else {
            assign_slice_seq = &assign_space;
            _r_63268 = Remove_elements(start, stop, (SEQ_PTR(_r_63268)->ref == 1));
        }
    }

    /** fwdref.e:120				active_references[file] = r*/
    RefDS(_r_63268);
    _2 = (object)SEQ_PTR(_44active_references_63199);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44active_references_63199 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _file_63245);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _r_63268;
    DeRef(_1);

    /** fwdref.e:122				r = active_subprogs[file]*/
    DeRefDS(_r_63268);
    _2 = (object)SEQ_PTR(_44active_subprogs_63198);
    _r_63268 = (object)*(((s1_ptr)_2)->base + _file_63245);
    Ref(_r_63268);

    /** fwdref.e:123				active_subprogs[file] = 0*/
    _2 = (object)SEQ_PTR(_44active_subprogs_63198);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44active_subprogs_63198 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _file_63245);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);

    /** fwdref.e:124				r = remove( r,   sp )*/
    {
        s1_ptr assign_space = SEQ_PTR(_r_63268);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_sp_63253)) ? _sp_63253 : (object)(DBL_PTR(_sp_63253)->dbl);
        int stop = (IS_ATOM_INT(_sp_63253)) ? _sp_63253 : (object)(DBL_PTR(_sp_63253)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_r_63268), start, &_r_63268 );
            }
            else Tail(SEQ_PTR(_r_63268), stop+1, &_r_63268);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_r_63268), start, &_r_63268);
        }
        else {
            assign_slice_seq = &assign_space;
            _r_63268 = Remove_elements(start, stop, (SEQ_PTR(_r_63268)->ref == 1));
        }
    }

    /** fwdref.e:125				active_subprogs[file] = r*/
    RefDS(_r_63268);
    _2 = (object)SEQ_PTR(_44active_subprogs_63198);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44active_subprogs_63198 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _file_63245);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _r_63268;
    DeRef(_1);
L4: 
    DeRef(_r_63268);
    _r_63268 = NOVALUE;
    goto L5; // [250] 303
L3: 

    /** fwdref.e:127		elsif tx then*/
    if (_tx_63251 == 0)
    {
        goto L6; // [255] 296
    }
    else{
    }

    /** fwdref.e:128			sequence r = toplevel_references[file]*/
    DeRef(_r_63286);
    _2 = (object)SEQ_PTR(_44toplevel_references_63200);
    _r_63286 = (object)*(((s1_ptr)_2)->base + _file_63245);
    Ref(_r_63286);

    /** fwdref.e:129			toplevel_references[file] = 0*/
    _2 = (object)SEQ_PTR(_44toplevel_references_63200);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44toplevel_references_63200 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _file_63245);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);

    /** fwdref.e:130			r = remove( r, tx )*/
    {
        s1_ptr assign_space = SEQ_PTR(_r_63286);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_tx_63251)) ? _tx_63251 : (object)(DBL_PTR(_tx_63251)->dbl);
        int stop = (IS_ATOM_INT(_tx_63251)) ? _tx_63251 : (object)(DBL_PTR(_tx_63251)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_r_63286), start, &_r_63286 );
            }
            else Tail(SEQ_PTR(_r_63286), stop+1, &_r_63286);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_r_63286), start, &_r_63286);
        }
        else {
            assign_slice_seq = &assign_space;
            _r_63286 = Remove_elements(start, stop, (SEQ_PTR(_r_63286)->ref == 1));
        }
    }

    /** fwdref.e:131			toplevel_references[file] = r*/
    RefDS(_r_63286);
    _2 = (object)SEQ_PTR(_44toplevel_references_63200);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44toplevel_references_63200 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _file_63245);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _r_63286;
    DeRef(_1);
    DeRefDS(_r_63286);
    _r_63286 = NOVALUE;
    goto L5; // [293] 303
L6: 

    /** fwdref.e:134			InternalErr( 260 )*/
    RefDS(_22190);
    _50InternalErr(260, _22190);
L5: 

    /** fwdref.e:136		inactive_references &= ref*/
    Append(&_44inactive_references_63201, _44inactive_references_63201, _ref_63244);

    /** fwdref.e:137		forward_references[ref] = 0*/
    _2 = (object)SEQ_PTR(_44forward_references_63197);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44forward_references_63197 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _ref_63244);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);

    /** fwdref.e:138	end procedure*/
    _31124 = NOVALUE;
    return;
    ;
}


void _44set_code(object _ref_63300)
{
    object _31150 = NOVALUE;
    object _31148 = NOVALUE;
    object _31147 = NOVALUE;
    object _31146 = NOVALUE;
    object _31145 = NOVALUE;
    object _31143 = NOVALUE;
    object _31141 = NOVALUE;
    object _31139 = NOVALUE;
    object _31137 = NOVALUE;
    object _31134 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** fwdref.e:146		patch_code_sub = forward_references[ref][FR_SUBPROG]*/
    _2 = (object)SEQ_PTR(_44forward_references_63197);
    _31134 = (object)*(((s1_ptr)_2)->base + _ref_63300);
    _2 = (object)SEQ_PTR(_31134);
    _44patch_code_sub_63295 = (object)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_44patch_code_sub_63295)){
        _44patch_code_sub_63295 = (object)DBL_PTR(_44patch_code_sub_63295)->dbl;
    }
    _31134 = NOVALUE;

    /** fwdref.e:147		if patch_code_sub != CurrentSub then*/
    if (_44patch_code_sub_63295 == _36CurrentSub_21775)
    goto L1; // [23] 136

    /** fwdref.e:149			patch_code_temp = Code*/
    RefDS(_36Code_21859);
    DeRef(_44patch_code_temp_63292);
    _44patch_code_temp_63292 = _36Code_21859;

    /** fwdref.e:150			patch_linetab_temp = LineTable*/
    RefDS(_36LineTable_21860);
    DeRef(_44patch_linetab_temp_63293);
    _44patch_linetab_temp_63293 = _36LineTable_21860;

    /** fwdref.e:152			Code = SymTab[patch_code_sub][S_CODE]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _31137 = (object)*(((s1_ptr)_2)->base + _44patch_code_sub_63295);
    DeRefDS(_36Code_21859);
    _2 = (object)SEQ_PTR(_31137);
    if (!IS_ATOM_INT(_36S_CODE_21416)){
        _36Code_21859 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21416)->dbl));
    }
    else{
        _36Code_21859 = (object)*(((s1_ptr)_2)->base + _36S_CODE_21416);
    }
    Ref(_36Code_21859);
    _31137 = NOVALUE;

    /** fwdref.e:153			SymTab[patch_code_sub][S_CODE] = 0*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_44patch_code_sub_63295 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_CODE_21416))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21416)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_CODE_21416);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);
    _31139 = NOVALUE;

    /** fwdref.e:154			LineTable = SymTab[patch_code_sub][S_LINETAB]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _31141 = (object)*(((s1_ptr)_2)->base + _44patch_code_sub_63295);
    DeRefDS(_36LineTable_21860);
    _2 = (object)SEQ_PTR(_31141);
    if (!IS_ATOM_INT(_36S_LINETAB_21439)){
        _36LineTable_21860 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_LINETAB_21439)->dbl));
    }
    else{
        _36LineTable_21860 = (object)*(((s1_ptr)_2)->base + _36S_LINETAB_21439);
    }
    Ref(_36LineTable_21860);
    _31141 = NOVALUE;

    /** fwdref.e:155			SymTab[patch_code_sub][S_LINETAB] = 0*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_44patch_code_sub_63295 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_LINETAB_21439))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_LINETAB_21439)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_LINETAB_21439);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);
    _31143 = NOVALUE;

    /** fwdref.e:157			patch_current_sub = CurrentSub*/
    _44patch_current_sub_63297 = _36CurrentSub_21775;

    /** fwdref.e:158			CurrentSub = patch_code_sub*/
    _36CurrentSub_21775 = _44patch_code_sub_63295;
    goto L2; // [133] 203
L1: 

    /** fwdref.e:160			patch_current_sub = patch_code_sub*/
    _44patch_current_sub_63297 = _44patch_code_sub_63295;

    /** fwdref.e:161			if sequence( SymTab[patch_current_sub][S_CODE] ) then*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _31145 = (object)*(((s1_ptr)_2)->base + _44patch_current_sub_63297);
    _2 = (object)SEQ_PTR(_31145);
    if (!IS_ATOM_INT(_36S_CODE_21416)){
        _31146 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21416)->dbl));
    }
    else{
        _31146 = (object)*(((s1_ptr)_2)->base + _36S_CODE_21416);
    }
    _31145 = NOVALUE;
    _31147 = IS_SEQUENCE(_31146);
    _31146 = NOVALUE;
    if (_31147 == 0)
    {
        _31147 = NOVALUE;
        goto L3; // [164] 202
    }
    else{
        _31147 = NOVALUE;
    }

    /** fwdref.e:162				SymTab[patch_code_sub][S_CODE] = 0*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_44patch_code_sub_63295 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_CODE_21416))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21416)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_CODE_21416);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);
    _31148 = NOVALUE;

    /** fwdref.e:163				SymTab[patch_code_sub][S_LINETAB] = 0*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_44patch_code_sub_63295 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_LINETAB_21439))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_LINETAB_21439)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_LINETAB_21439);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);
    _31150 = NOVALUE;
L3: 
L2: 

    /** fwdref.e:166	end procedure*/
    return;
    ;
}


void _44reset_code()
{
    object _31155 = NOVALUE;
    object _31153 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** fwdref.e:169		if patch_code_sub != patch_current_sub then*/
    if (_44patch_code_sub_63295 == _44patch_current_sub_63297)
    goto L1; // [7] 77

    /** fwdref.e:171			SymTab[patch_code_sub][S_CODE] = Code*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_44patch_code_sub_63295 + ((s1_ptr)_2)->base);
    RefDS(_36Code_21859);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_CODE_21416))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21416)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_CODE_21416);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36Code_21859;
    DeRef(_1);
    _31153 = NOVALUE;

    /** fwdref.e:172			SymTab[patch_code_sub][S_LINETAB] = LineTable*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_44patch_code_sub_63295 + ((s1_ptr)_2)->base);
    RefDS(_36LineTable_21860);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_LINETAB_21439))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_LINETAB_21439)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_LINETAB_21439);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36LineTable_21860;
    DeRef(_1);
    _31155 = NOVALUE;

    /** fwdref.e:175			CurrentSub = patch_current_sub*/
    _36CurrentSub_21775 = _44patch_current_sub_63297;

    /** fwdref.e:176			Code = patch_code_temp*/
    RefDS(_44patch_code_temp_63292);
    DeRefDS(_36Code_21859);
    _36Code_21859 = _44patch_code_temp_63292;

    /** fwdref.e:177			LineTable = patch_linetab_temp*/
    RefDS(_44patch_linetab_temp_63293);
    DeRefDS(_36LineTable_21860);
    _36LineTable_21860 = _44patch_linetab_temp_63293;
L1: 

    /** fwdref.e:181		patch_code_temp = {}*/
    RefDS(_22190);
    DeRef(_44patch_code_temp_63292);
    _44patch_code_temp_63292 = _22190;

    /** fwdref.e:182		patch_linetab_temp = {}*/
    RefDS(_22190);
    DeRef(_44patch_linetab_temp_63293);
    _44patch_linetab_temp_63293 = _22190;

    /** fwdref.e:183	end procedure*/
    return;
    ;
}


void _44set_data(object _ref_63362, object _data_63363)
{
    object _31157 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** fwdref.e:186		forward_references[ref][FR_DATA] = data*/
    _2 = (object)SEQ_PTR(_44forward_references_63197);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44forward_references_63197 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_63362 + ((s1_ptr)_2)->base);
    Ref(_data_63363);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _data_63363;
    DeRef(_1);
    _31157 = NOVALUE;

    /** fwdref.e:187	end procedure*/
    DeRef(_data_63363);
    return;
    ;
}


void _44add_data(object _ref_63368, object _data_63369)
{
    object _31163 = NOVALUE;
    object _31162 = NOVALUE;
    object _31161 = NOVALUE;
    object _31159 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_ref_63368)) {
        _1 = (object)(DBL_PTR(_ref_63368)->dbl);
        DeRefDS(_ref_63368);
        _ref_63368 = _1;
    }

    /** fwdref.e:190		forward_references[ref][FR_DATA] = append( forward_references[ref][FR_DATA], data )*/
    _2 = (object)SEQ_PTR(_44forward_references_63197);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44forward_references_63197 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_63368 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_44forward_references_63197);
    _31161 = (object)*(((s1_ptr)_2)->base + _ref_63368);
    _2 = (object)SEQ_PTR(_31161);
    _31162 = (object)*(((s1_ptr)_2)->base + 12);
    _31161 = NOVALUE;
    Ref(_data_63369);
    Append(&_31163, _31162, _data_63369);
    _31162 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31163;
    if( _1 != _31163 ){
        DeRef(_1);
    }
    _31163 = NOVALUE;
    _31159 = NOVALUE;

    /** fwdref.e:191	end procedure*/
    DeRef(_data_63369);
    return;
    ;
}


void _44set_line(object _ref_63377, object _line_no_63378, object _this_line_63379, object _bp_63380)
{
    object _31168 = NOVALUE;
    object _31166 = NOVALUE;
    object _31164 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_ref_63377)) {
        _1 = (object)(DBL_PTR(_ref_63377)->dbl);
        DeRefDS(_ref_63377);
        _ref_63377 = _1;
    }

    /** fwdref.e:194		forward_references[ref][FR_LINE] = line_no*/
    _2 = (object)SEQ_PTR(_44forward_references_63197);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44forward_references_63197 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_63377 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 6);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _line_no_63378;
    DeRef(_1);
    _31164 = NOVALUE;

    /** fwdref.e:195		forward_references[ref][FR_THISLINE] = this_line*/
    _2 = (object)SEQ_PTR(_44forward_references_63197);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44forward_references_63197 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_63377 + ((s1_ptr)_2)->base);
    RefDS(_this_line_63379);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 7);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _this_line_63379;
    DeRef(_1);
    _31166 = NOVALUE;

    /** fwdref.e:196		forward_references[ref][FR_BP] = bp*/
    _2 = (object)SEQ_PTR(_44forward_references_63197);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44forward_references_63197 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_63377 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 8);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _bp_63380;
    DeRef(_1);
    _31168 = NOVALUE;

    /** fwdref.e:198	end procedure*/
    DeRefDS(_this_line_63379);
    return;
    ;
}


void _44add_private_symbol(object _sym_63392, object _name_63393)
{
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_sym_63392)) {
        _1 = (object)(DBL_PTR(_sym_63392)->dbl);
        DeRefDS(_sym_63392);
        _sym_63392 = _1;
    }

    /** fwdref.e:206		fwd_private_sym &= sym*/
    Append(&_44fwd_private_sym_63387, _44fwd_private_sym_63387, _sym_63392);

    /** fwdref.e:207		fwd_private_name = append( fwd_private_name, name )*/
    RefDS(_name_63393);
    Append(&_44fwd_private_name_63388, _44fwd_private_name_63388, _name_63393);

    /** fwdref.e:209	end procedure*/
    DeRefDS(_name_63393);
    return;
    ;
}


void _44patch_forward_goto(object _tok_63401, object _ref_63402)
{
    object _fr_63403 = NOVALUE;
    object _31184 = NOVALUE;
    object _31183 = NOVALUE;
    object _31182 = NOVALUE;
    object _31181 = NOVALUE;
    object _31180 = NOVALUE;
    object _31179 = NOVALUE;
    object _31178 = NOVALUE;
    object _31177 = NOVALUE;
    object _31175 = NOVALUE;
    object _31174 = NOVALUE;
    object _0, _1, _2;
    

    /** fwdref.e:217		sequence fr = forward_references[ref]*/
    DeRef(_fr_63403);
    _2 = (object)SEQ_PTR(_44forward_references_63197);
    _fr_63403 = (object)*(((s1_ptr)_2)->base + _ref_63402);
    Ref(_fr_63403);

    /** fwdref.e:218		set_code( ref )*/
    _44set_code(_ref_63402);

    /** fwdref.e:220		shifting_sub = fr[FR_SUBPROG]*/
    _2 = (object)SEQ_PTR(_fr_63403);
    _44shifting_sub_63216 = (object)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_44shifting_sub_63216))
    _44shifting_sub_63216 = (object)DBL_PTR(_44shifting_sub_63216)->dbl;

    /** fwdref.e:222		if length( fr[FR_DATA] ) = 2 then*/
    _2 = (object)SEQ_PTR(_fr_63403);
    _31174 = (object)*(((s1_ptr)_2)->base + 12);
    if (IS_SEQUENCE(_31174)){
            _31175 = SEQ_PTR(_31174)->length;
    }
    else {
        _31175 = 1;
    }
    _31174 = NOVALUE;
    if (_31175 != 2)
    goto L1; // [33] 64

    /** fwdref.e:223			prep_forward_error( ref )*/
    _44prep_forward_error(_ref_63402);

    /** fwdref.e:224			CompileErr( UNKNOWN_LABEL_1, { fr[FR_DATA][2] })*/
    _2 = (object)SEQ_PTR(_fr_63403);
    _31177 = (object)*(((s1_ptr)_2)->base + 12);
    _2 = (object)SEQ_PTR(_31177);
    _31178 = (object)*(((s1_ptr)_2)->base + 2);
    _31177 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_31178);
    ((intptr_t*)_2)[1] = _31178;
    _31179 = MAKE_SEQ(_1);
    _31178 = NOVALUE;
    _50CompileErr(156, _31179, 0);
    _31179 = NOVALUE;
L1: 

    /** fwdref.e:227		Goto_block(  fr[FR_DATA][1], fr[FR_DATA][3], fr[FR_PC] )*/
    _2 = (object)SEQ_PTR(_fr_63403);
    _31180 = (object)*(((s1_ptr)_2)->base + 12);
    _2 = (object)SEQ_PTR(_31180);
    _31181 = (object)*(((s1_ptr)_2)->base + 1);
    _31180 = NOVALUE;
    _2 = (object)SEQ_PTR(_fr_63403);
    _31182 = (object)*(((s1_ptr)_2)->base + 12);
    _2 = (object)SEQ_PTR(_31182);
    _31183 = (object)*(((s1_ptr)_2)->base + 3);
    _31182 = NOVALUE;
    _2 = (object)SEQ_PTR(_fr_63403);
    _31184 = (object)*(((s1_ptr)_2)->base + 5);
    Ref(_31181);
    Ref(_31183);
    Ref(_31184);
    _65Goto_block(_31181, _31183, _31184);
    _31181 = NOVALUE;
    _31183 = NOVALUE;
    _31184 = NOVALUE;

    /** fwdref.e:229		shifting_sub = 0*/
    _44shifting_sub_63216 = 0;

    /** fwdref.e:231		reset_code()*/
    _44reset_code();

    /** fwdref.e:232		resolved_reference( ref )*/
    _44resolved_reference(_ref_63402);

    /** fwdref.e:233	end procedure*/
    DeRefDS(_fr_63403);
    _31174 = NOVALUE;
    return;
    ;
}


void _44patch_forward_call(object _tok_63425, object _ref_63426)
{
    object _fr_63427 = NOVALUE;
    object _sub_63430 = NOVALUE;
    object _defarg_63436 = NOVALUE;
    object _paramsym_63440 = NOVALUE;
    object _old_63443 = NOVALUE;
    object _tx_63447 = NOVALUE;
    object _code_sub_63457 = NOVALUE;
    object _args_63459 = NOVALUE;
    object _is_func_63464 = NOVALUE;
    object _real_file_63478 = NOVALUE;
    object _code_63482 = NOVALUE;
    object _temp_sub_63484 = NOVALUE;
    object _pc_63486 = NOVALUE;
    object _next_pc_63488 = NOVALUE;
    object _supplied_args_63489 = NOVALUE;
    object _name_63492 = NOVALUE;
    object _old_temps_allocated_63528 = NOVALUE;
    object _temp_target_63537 = NOVALUE;
    object _converted_code_63540 = NOVALUE;
    object _target_63556 = NOVALUE;
    object _has_defaults_63562 = NOVALUE;
    object _goto_target_63563 = NOVALUE;
    object _defarg_63566 = NOVALUE;
    object _code_len_63567 = NOVALUE;
    object _extra_default_args_63569 = NOVALUE;
    object _param_sym_63572 = NOVALUE;
    object _params_63573 = NOVALUE;
    object _orig_code_63575 = NOVALUE;
    object _orig_linetable_63576 = NOVALUE;
    object _ar_sp_63580 = NOVALUE;
    object _pre_refs_63584 = NOVALUE;
    object _old_fwd_params_63599 = NOVALUE;
    object _temp_shifting_sub_63640 = NOVALUE;
    object _new_code_63644 = NOVALUE;
    object _routine_type_63653 = NOVALUE;
    object _31943 = NOVALUE;
    object _31325 = NOVALUE;
    object _31324 = NOVALUE;
    object _31323 = NOVALUE;
    object _31321 = NOVALUE;
    object _31320 = NOVALUE;
    object _31319 = NOVALUE;
    object _31318 = NOVALUE;
    object _31317 = NOVALUE;
    object _31316 = NOVALUE;
    object _31315 = NOVALUE;
    object _31314 = NOVALUE;
    object _31313 = NOVALUE;
    object _31312 = NOVALUE;
    object _31311 = NOVALUE;
    object _31310 = NOVALUE;
    object _31309 = NOVALUE;
    object _31307 = NOVALUE;
    object _31306 = NOVALUE;
    object _31305 = NOVALUE;
    object _31304 = NOVALUE;
    object _31303 = NOVALUE;
    object _31302 = NOVALUE;
    object _31301 = NOVALUE;
    object _31300 = NOVALUE;
    object _31298 = NOVALUE;
    object _31295 = NOVALUE;
    object _31294 = NOVALUE;
    object _31293 = NOVALUE;
    object _31292 = NOVALUE;
    object _31288 = NOVALUE;
    object _31287 = NOVALUE;
    object _31286 = NOVALUE;
    object _31285 = NOVALUE;
    object _31284 = NOVALUE;
    object _31282 = NOVALUE;
    object _31281 = NOVALUE;
    object _31280 = NOVALUE;
    object _31279 = NOVALUE;
    object _31278 = NOVALUE;
    object _31277 = NOVALUE;
    object _31275 = NOVALUE;
    object _31274 = NOVALUE;
    object _31272 = NOVALUE;
    object _31271 = NOVALUE;
    object _31270 = NOVALUE;
    object _31269 = NOVALUE;
    object _31267 = NOVALUE;
    object _31265 = NOVALUE;
    object _31264 = NOVALUE;
    object _31263 = NOVALUE;
    object _31261 = NOVALUE;
    object _31260 = NOVALUE;
    object _31258 = NOVALUE;
    object _31256 = NOVALUE;
    object _31253 = NOVALUE;
    object _31249 = NOVALUE;
    object _31247 = NOVALUE;
    object _31246 = NOVALUE;
    object _31244 = NOVALUE;
    object _31243 = NOVALUE;
    object _31242 = NOVALUE;
    object _31241 = NOVALUE;
    object _31239 = NOVALUE;
    object _31238 = NOVALUE;
    object _31237 = NOVALUE;
    object _31236 = NOVALUE;
    object _31235 = NOVALUE;
    object _31233 = NOVALUE;
    object _31232 = NOVALUE;
    object _31231 = NOVALUE;
    object _31230 = NOVALUE;
    object _31229 = NOVALUE;
    object _31228 = NOVALUE;
    object _31227 = NOVALUE;
    object _31226 = NOVALUE;
    object _31225 = NOVALUE;
    object _31224 = NOVALUE;
    object _31223 = NOVALUE;
    object _31222 = NOVALUE;
    object _31221 = NOVALUE;
    object _31220 = NOVALUE;
    object _31218 = NOVALUE;
    object _31217 = NOVALUE;
    object _31216 = NOVALUE;
    object _31215 = NOVALUE;
    object _31214 = NOVALUE;
    object _31211 = NOVALUE;
    object _31207 = NOVALUE;
    object _31206 = NOVALUE;
    object _31205 = NOVALUE;
    object _31204 = NOVALUE;
    object _31203 = NOVALUE;
    object _31202 = NOVALUE;
    object _31200 = NOVALUE;
    object _31197 = NOVALUE;
    object _31195 = NOVALUE;
    object _31194 = NOVALUE;
    object _31192 = NOVALUE;
    object _31189 = NOVALUE;
    object _31188 = NOVALUE;
    object _31187 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** fwdref.e:242		sequence fr = forward_references[ref]*/
    DeRef(_fr_63427);
    _2 = (object)SEQ_PTR(_44forward_references_63197);
    _fr_63427 = (object)*(((s1_ptr)_2)->base + _ref_63426);
    Ref(_fr_63427);

    /** fwdref.e:243		symtab_index sub = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_63425);
    _sub_63430 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_sub_63430)){
        _sub_63430 = (object)DBL_PTR(_sub_63430)->dbl;
    }

    /** fwdref.e:245		if sequence( fr[FR_DATA] ) then*/
    _2 = (object)SEQ_PTR(_fr_63427);
    _31187 = (object)*(((s1_ptr)_2)->base + 12);
    _31188 = IS_SEQUENCE(_31187);
    _31187 = NOVALUE;
    if (_31188 == 0)
    {
        _31188 = NOVALUE;
        goto L1; // [32] 117
    }
    else{
        _31188 = NOVALUE;
    }

    /** fwdref.e:246			sequence defarg = fr[FR_DATA][1]*/
    _2 = (object)SEQ_PTR(_fr_63427);
    _31189 = (object)*(((s1_ptr)_2)->base + 12);
    DeRef(_defarg_63436);
    _2 = (object)SEQ_PTR(_31189);
    _defarg_63436 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_defarg_63436);
    _31189 = NOVALUE;

    /** fwdref.e:247			symtab_index paramsym = defarg[2]*/
    _2 = (object)SEQ_PTR(_defarg_63436);
    _paramsym_63440 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_paramsym_63440)){
        _paramsym_63440 = (object)DBL_PTR(_paramsym_63440)->dbl;
    }

    /** fwdref.e:248			token old = { RECORDED, defarg[3] }*/
    _2 = (object)SEQ_PTR(_defarg_63436);
    _31192 = (object)*(((s1_ptr)_2)->base + 3);
    Ref(_31192);
    DeRef(_old_63443);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 508;
    ((intptr_t *)_2)[2] = _31192;
    _old_63443 = MAKE_SEQ(_1);
    _31192 = NOVALUE;

    /** fwdref.e:249			integer tx = find( old, SymTab[paramsym][S_CODE] )*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _31194 = (object)*(((s1_ptr)_2)->base + _paramsym_63440);
    _2 = (object)SEQ_PTR(_31194);
    if (!IS_ATOM_INT(_36S_CODE_21416)){
        _31195 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21416)->dbl));
    }
    else{
        _31195 = (object)*(((s1_ptr)_2)->base + _36S_CODE_21416);
    }
    _31194 = NOVALUE;
    _tx_63447 = find_from(_old_63443, _31195, 1);
    _31195 = NOVALUE;

    /** fwdref.e:250			SymTab[paramsym][S_CODE][tx] = tok*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_paramsym_63440 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(object_ptr)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(object_ptr)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_CODE_21416))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21416)->dbl));
    else
    _3 = (object)(_36S_CODE_21416 + ((s1_ptr)_2)->base);
    _31197 = NOVALUE;
    Ref(_tok_63425);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _tx_63447);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _tok_63425;
    DeRef(_1);
    _31197 = NOVALUE;

    /** fwdref.e:251			resolved_reference( ref )*/
    _44resolved_reference(_ref_63426);

    /** fwdref.e:252			return*/
    DeRefDS(_defarg_63436);
    DeRefDS(_old_63443);
    DeRef(_tok_63425);
    DeRefDS(_fr_63427);
    DeRef(_code_63482);
    DeRef(_name_63492);
    DeRef(_params_63573);
    DeRef(_orig_code_63575);
    DeRef(_orig_linetable_63576);
    DeRef(_old_fwd_params_63599);
    DeRef(_new_code_63644);
    return;
L1: 
    DeRef(_defarg_63436);
    _defarg_63436 = NOVALUE;
    DeRef(_old_63443);
    _old_63443 = NOVALUE;

    /** fwdref.e:255		integer code_sub = fr[FR_SUBPROG]*/
    _2 = (object)SEQ_PTR(_fr_63427);
    _code_sub_63457 = (object)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_code_sub_63457))
    _code_sub_63457 = (object)DBL_PTR(_code_sub_63457)->dbl;

    /** fwdref.e:257		integer args = SymTab[sub][S_NUM_ARGS]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _31200 = (object)*(((s1_ptr)_2)->base + _sub_63430);
    _2 = (object)SEQ_PTR(_31200);
    if (!IS_ATOM_INT(_36S_NUM_ARGS_21455)){
        _args_63459 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21455)->dbl));
    }
    else{
        _args_63459 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21455);
    }
    if (!IS_ATOM_INT(_args_63459)){
        _args_63459 = (object)DBL_PTR(_args_63459)->dbl;
    }
    _31200 = NOVALUE;

    /** fwdref.e:258		integer is_func = (SymTab[sub][S_TOKEN] = FUNC) or (SymTab[sub][S_TOKEN] = TYPE)*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _31202 = (object)*(((s1_ptr)_2)->base + _sub_63430);
    _2 = (object)SEQ_PTR(_31202);
    if (!IS_ATOM_INT(_36S_TOKEN_21409)){
        _31203 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21409)->dbl));
    }
    else{
        _31203 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21409);
    }
    _31202 = NOVALUE;
    if (IS_ATOM_INT(_31203)) {
        _31204 = (_31203 == 501);
    }
    else {
        _31204 = binary_op(EQUALS, _31203, 501);
    }
    _31203 = NOVALUE;
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _31205 = (object)*(((s1_ptr)_2)->base + _sub_63430);
    _2 = (object)SEQ_PTR(_31205);
    if (!IS_ATOM_INT(_36S_TOKEN_21409)){
        _31206 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21409)->dbl));
    }
    else{
        _31206 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21409);
    }
    _31205 = NOVALUE;
    if (IS_ATOM_INT(_31206)) {
        _31207 = (_31206 == 504);
    }
    else {
        _31207 = binary_op(EQUALS, _31206, 504);
    }
    _31206 = NOVALUE;
    if (IS_ATOM_INT(_31204) && IS_ATOM_INT(_31207)) {
        _is_func_63464 = (_31204 != 0 || _31207 != 0);
    }
    else {
        _is_func_63464 = binary_op(OR, _31204, _31207);
    }
    DeRef(_31204);
    _31204 = NOVALUE;
    DeRef(_31207);
    _31207 = NOVALUE;
    if (!IS_ATOM_INT(_is_func_63464)) {
        _1 = (object)(DBL_PTR(_is_func_63464)->dbl);
        DeRefDS(_is_func_63464);
        _is_func_63464 = _1;
    }

    /** fwdref.e:260		integer real_file = current_file_no*/
    _real_file_63478 = _36current_file_no_21767;

    /** fwdref.e:261		current_file_no = fr[FR_FILE]*/
    _2 = (object)SEQ_PTR(_fr_63427);
    _36current_file_no_21767 = (object)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_36current_file_no_21767)){
        _36current_file_no_21767 = (object)DBL_PTR(_36current_file_no_21767)->dbl;
    }

    /** fwdref.e:263		set_code( ref )*/
    _44set_code(_ref_63426);

    /** fwdref.e:264		sequence code = Code*/
    RefDS(_36Code_21859);
    DeRef(_code_63482);
    _code_63482 = _36Code_21859;

    /** fwdref.e:265		integer temp_sub = CurrentSub*/
    _temp_sub_63484 = _36CurrentSub_21775;

    /** fwdref.e:267		integer pc = fr[FR_PC]*/
    _2 = (object)SEQ_PTR(_fr_63427);
    _pc_63486 = (object)*(((s1_ptr)_2)->base + 5);
    if (!IS_ATOM_INT(_pc_63486))
    _pc_63486 = (object)DBL_PTR(_pc_63486)->dbl;

    /** fwdref.e:268		integer next_pc = pc*/
    _next_pc_63488 = _pc_63486;

    /** fwdref.e:269		integer supplied_args = code[pc+2]*/
    _31211 = _pc_63486 + 2;
    _2 = (object)SEQ_PTR(_code_63482);
    _supplied_args_63489 = (object)*(((s1_ptr)_2)->base + _31211);
    if (!IS_ATOM_INT(_supplied_args_63489))
    _supplied_args_63489 = (object)DBL_PTR(_supplied_args_63489)->dbl;

    /** fwdref.e:270		sequence name = fr[FR_NAME]*/
    DeRef(_name_63492);
    _2 = (object)SEQ_PTR(_fr_63427);
    _name_63492 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_name_63492);

    /** fwdref.e:272		if Code[pc] != FUNC_FORWARD and Code[pc] != PROC_FORWARD then*/
    _2 = (object)SEQ_PTR(_36Code_21859);
    _31214 = (object)*(((s1_ptr)_2)->base + _pc_63486);
    if (IS_ATOM_INT(_31214)) {
        _31215 = (_31214 != 196);
    }
    else {
        _31215 = binary_op(NOTEQ, _31214, 196);
    }
    _31214 = NOVALUE;
    if (IS_ATOM_INT(_31215)) {
        if (_31215 == 0) {
            goto L2; // [268] 332
        }
    }
    else {
        if (DBL_PTR(_31215)->dbl == 0.0) {
            goto L2; // [268] 332
        }
    }
    _2 = (object)SEQ_PTR(_36Code_21859);
    _31217 = (object)*(((s1_ptr)_2)->base + _pc_63486);
    if (IS_ATOM_INT(_31217)) {
        _31218 = (_31217 != 195);
    }
    else {
        _31218 = binary_op(NOTEQ, _31217, 195);
    }
    _31217 = NOVALUE;
    if (_31218 == 0) {
        DeRef(_31218);
        _31218 = NOVALUE;
        goto L2; // [285] 332
    }
    else {
        if (!IS_ATOM_INT(_31218) && DBL_PTR(_31218)->dbl == 0.0){
            DeRef(_31218);
            _31218 = NOVALUE;
            goto L2; // [285] 332
        }
        DeRef(_31218);
        _31218 = NOVALUE;
    }
    DeRef(_31218);
    _31218 = NOVALUE;

    /** fwdref.e:273			prep_forward_error( ref )*/
    _44prep_forward_error(_ref_63426);

    /** fwdref.e:274			CompileErr( "The forward call to [4] wasn't where we thought it would be: [1]:[2]:[3]",*/
    _2 = (object)SEQ_PTR(_37known_files_15638);
    _31220 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21767);
    _2 = (object)SEQ_PTR(_fr_63427);
    _31221 = (object)*(((s1_ptr)_2)->base + 4);
    Ref(_31221);
    _31222 = _54sym_name(_31221);
    _31221 = NOVALUE;
    _2 = (object)SEQ_PTR(_fr_63427);
    _31223 = (object)*(((s1_ptr)_2)->base + 6);
    _2 = (object)SEQ_PTR(_fr_63427);
    _31224 = (object)*(((s1_ptr)_2)->base + 2);
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_31220);
    ((intptr_t*)_2)[1] = _31220;
    ((intptr_t*)_2)[2] = _31222;
    Ref(_31223);
    ((intptr_t*)_2)[3] = _31223;
    Ref(_31224);
    ((intptr_t*)_2)[4] = _31224;
    _31225 = MAKE_SEQ(_1);
    _31224 = NOVALUE;
    _31223 = NOVALUE;
    _31222 = NOVALUE;
    _31220 = NOVALUE;
    RefDS(_31219);
    _50CompileErr(_31219, _31225, 0);
    _31225 = NOVALUE;
L2: 

    /** fwdref.e:278		if SymTab[sub][S_DEPRECATED] then*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _31226 = (object)*(((s1_ptr)_2)->base + _sub_63430);
    _2 = (object)SEQ_PTR(_31226);
    _31227 = (object)*(((s1_ptr)_2)->base + 30);
    _31226 = NOVALUE;
    if (_31227 == 0) {
        _31227 = NOVALUE;
        goto L3; // [346] 375
    }
    else {
        if (!IS_ATOM_INT(_31227) && DBL_PTR(_31227)->dbl == 0.0){
            _31227 = NOVALUE;
            goto L3; // [346] 375
        }
        _31227 = NOVALUE;
    }
    _31227 = NOVALUE;

    /** fwdref.e:279			Warning(327, deprecated_warning_flag, { SymTab[sub][S_NAME] })*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _31228 = (object)*(((s1_ptr)_2)->base + _sub_63430);
    _2 = (object)SEQ_PTR(_31228);
    if (!IS_ATOM_INT(_36S_NAME_21404)){
        _31229 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21404)->dbl));
    }
    else{
        _31229 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21404);
    }
    _31228 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_31229);
    ((intptr_t*)_2)[1] = _31229;
    _31230 = MAKE_SEQ(_1);
    _31229 = NOVALUE;
    _50Warning(327, 16384, _31230);
    _31230 = NOVALUE;
L3: 

    /** fwdref.e:282		integer old_temps_allocated = temps_allocated*/
    _old_temps_allocated_63528 = _54temps_allocated_47667;

    /** fwdref.e:283		temps_allocated = 0*/
    _54temps_allocated_47667 = 0;

    /** fwdref.e:285		if is_func and fr[FR_OP] = PROC then*/
    if (_is_func_63464 == 0) {
        goto L4; // [393] 481
    }
    _2 = (object)SEQ_PTR(_fr_63427);
    _31232 = (object)*(((s1_ptr)_2)->base + 10);
    if (IS_ATOM_INT(_31232)) {
        _31233 = (_31232 == 27);
    }
    else {
        _31233 = binary_op(EQUALS, _31232, 27);
    }
    _31232 = NOVALUE;
    if (_31233 == 0) {
        DeRef(_31233);
        _31233 = NOVALUE;
        goto L4; // [408] 481
    }
    else {
        if (!IS_ATOM_INT(_31233) && DBL_PTR(_31233)->dbl == 0.0){
            DeRef(_31233);
            _31233 = NOVALUE;
            goto L4; // [408] 481
        }
        DeRef(_31233);
        _31233 = NOVALUE;
    }
    DeRef(_31233);
    _31233 = NOVALUE;

    /** fwdref.e:288			symtab_index temp_target = NewTempSym()*/
    _temp_target_63537 = _54NewTempSym(0);
    if (!IS_ATOM_INT(_temp_target_63537)) {
        _1 = (object)(DBL_PTR(_temp_target_63537)->dbl);
        DeRefDS(_temp_target_63537);
        _temp_target_63537 = _1;
    }

    /** fwdref.e:289			sequence converted_code = */
    _31235 = _pc_63486 + 1;
    if (_31235 > MAXINT){
        _31235 = NewDouble((eudouble)_31235);
    }
    _31236 = _pc_63486 + 2;
    if ((object)((uintptr_t)_31236 + (uintptr_t)HIGH_BITS) >= 0){
        _31236 = NewDouble((eudouble)_31236);
    }
    if (IS_ATOM_INT(_31236)) {
        _31237 = _31236 + _supplied_args_63489;
    }
    else {
        _31237 = NewDouble(DBL_PTR(_31236)->dbl + (eudouble)_supplied_args_63489);
    }
    DeRef(_31236);
    _31236 = NOVALUE;
    rhs_slice_target = (object_ptr)&_31238;
    RHS_Slice(_36Code_21859, _31235, _31237);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 208;
    ((intptr_t *)_2)[2] = _temp_target_63537;
    _31239 = MAKE_SEQ(_1);
    {
        object concat_list[4];

        concat_list[0] = _31239;
        concat_list[1] = _temp_target_63537;
        concat_list[2] = _31238;
        concat_list[3] = 196;
        Concat_N((object_ptr)&_converted_code_63540, concat_list, 4);
    }
    DeRefDS(_31239);
    _31239 = NOVALUE;
    DeRefDS(_31238);
    _31238 = NOVALUE;

    /** fwdref.e:295			replace_code( converted_code, pc, pc + 2 + supplied_args, code_sub )*/
    _31241 = _pc_63486 + 2;
    if ((object)((uintptr_t)_31241 + (uintptr_t)HIGH_BITS) >= 0){
        _31241 = NewDouble((eudouble)_31241);
    }
    if (IS_ATOM_INT(_31241)) {
        _31242 = _31241 + _supplied_args_63489;
        if ((object)((uintptr_t)_31242 + (uintptr_t)HIGH_BITS) >= 0){
            _31242 = NewDouble((eudouble)_31242);
        }
    }
    else {
        _31242 = NewDouble(DBL_PTR(_31241)->dbl + (eudouble)_supplied_args_63489);
    }
    DeRef(_31241);
    _31241 = NOVALUE;
    RefDS(_converted_code_63540);
    _44replace_code(_converted_code_63540, _pc_63486, _31242, _code_sub_63457);
    _31242 = NOVALUE;

    /** fwdref.e:297			code = Code*/
    RefDS(_36Code_21859);
    DeRef(_code_63482);
    _code_63482 = _36Code_21859;
L4: 
    DeRef(_converted_code_63540);
    _converted_code_63540 = NOVALUE;

    /** fwdref.e:299		next_pc +=*/
    _31243 = 3 + _supplied_args_63489;
    if ((object)((uintptr_t)_31243 + (uintptr_t)HIGH_BITS) >= 0){
        _31243 = NewDouble((eudouble)_31243);
    }
    if (IS_ATOM_INT(_31243)) {
        _31244 = _31243 + _is_func_63464;
        if ((object)((uintptr_t)_31244 + (uintptr_t)HIGH_BITS) >= 0){
            _31244 = NewDouble((eudouble)_31244);
        }
    }
    else {
        _31244 = NewDouble(DBL_PTR(_31243)->dbl + (eudouble)_is_func_63464);
    }
    DeRef(_31243);
    _31243 = NOVALUE;
    if (IS_ATOM_INT(_31244)) {
        _next_pc_63488 = _next_pc_63488 + _31244;
    }
    else {
        _next_pc_63488 = NewDouble((eudouble)_next_pc_63488 + DBL_PTR(_31244)->dbl);
    }
    DeRef(_31244);
    _31244 = NOVALUE;
    if (!IS_ATOM_INT(_next_pc_63488)) {
        _1 = (object)(DBL_PTR(_next_pc_63488)->dbl);
        DeRefDS(_next_pc_63488);
        _next_pc_63488 = _1;
    }

    /** fwdref.e:303		integer target*/

    /** fwdref.e:304		if is_func then*/
    if (_is_func_63464 == 0)
    {
        goto L5; // [503] 525
    }
    else{
    }

    /** fwdref.e:305			target = Code[pc + 3 + supplied_args]*/
    _31246 = _pc_63486 + 3;
    if ((object)((uintptr_t)_31246 + (uintptr_t)HIGH_BITS) >= 0){
        _31246 = NewDouble((eudouble)_31246);
    }
    if (IS_ATOM_INT(_31246)) {
        _31247 = _31246 + _supplied_args_63489;
    }
    else {
        _31247 = NewDouble(DBL_PTR(_31246)->dbl + (eudouble)_supplied_args_63489);
    }
    DeRef(_31246);
    _31246 = NOVALUE;
    _2 = (object)SEQ_PTR(_36Code_21859);
    if (!IS_ATOM_INT(_31247)){
        _target_63556 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31247)->dbl));
    }
    else{
        _target_63556 = (object)*(((s1_ptr)_2)->base + _31247);
    }
    if (!IS_ATOM_INT(_target_63556)){
        _target_63556 = (object)DBL_PTR(_target_63556)->dbl;
    }
L5: 

    /** fwdref.e:307		integer has_defaults = 0*/
    _has_defaults_63562 = 0;

    /** fwdref.e:308		integer goto_target = length( code ) + 1*/
    if (IS_SEQUENCE(_code_63482)){
            _31249 = SEQ_PTR(_code_63482)->length;
    }
    else {
        _31249 = 1;
    }
    _goto_target_63563 = _31249 + 1;
    _31249 = NOVALUE;

    /** fwdref.e:309		integer defarg = 0*/
    _defarg_63566 = 0;

    /** fwdref.e:310		integer code_len = length(code)*/
    if (IS_SEQUENCE(_code_63482)){
            _code_len_63567 = SEQ_PTR(_code_63482)->length;
    }
    else {
        _code_len_63567 = 1;
    }

    /** fwdref.e:312		integer extra_default_args = 0*/
    _extra_default_args_63569 = 0;

    /** fwdref.e:313		set_dont_read( 1 )*/
    _62set_dont_read(1);

    /** fwdref.e:314		reset_private_lists()*/

    /** fwdref.e:212		fwd_private_sym  = {}*/
    RefDS(_22190);
    DeRefi(_44fwd_private_sym_63387);
    _44fwd_private_sym_63387 = _22190;

    /** fwdref.e:213		fwd_private_name = {}*/
    RefDS(_22190);
    DeRef(_44fwd_private_name_63388);
    _44fwd_private_name_63388 = _22190;

    /** fwdref.e:214	end procedure*/
    goto L6; // [577] 580
L6: 

    /** fwdref.e:315		integer param_sym = sub*/
    _param_sym_63572 = _sub_63430;

    /** fwdref.e:316		sequence params = repeat( 0, args )*/
    DeRef(_params_63573);
    _params_63573 = Repeat(0, _args_63459);

    /** fwdref.e:317		sequence orig_code = code*/
    RefDS(_code_63482);
    DeRef(_orig_code_63575);
    _orig_code_63575 = _code_63482;

    /** fwdref.e:318		sequence orig_linetable = LineTable*/
    RefDS(_36LineTable_21860);
    DeRef(_orig_linetable_63576);
    _orig_linetable_63576 = _36LineTable_21860;

    /** fwdref.e:319		LineTable = {}*/
    RefDS(_22190);
    DeRefDS(_36LineTable_21860);
    _36LineTable_21860 = _22190;

    /** fwdref.e:320		Code = {}*/
    RefDS(_22190);
    DeRef(_36Code_21859);
    _36Code_21859 = _22190;

    /** fwdref.e:323		integer ar_sp = find( code_sub, active_subprogs[current_file_no] )*/
    _2 = (object)SEQ_PTR(_44active_subprogs_63198);
    _31253 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21767);
    _ar_sp_63580 = find_from(_code_sub_63457, _31253, 1);
    _31253 = NOVALUE;

    /** fwdref.e:324		integer pre_refs*/

    /** fwdref.e:326		if code_sub = TopLevelSub then*/
    if (_code_sub_63457 != _36TopLevelSub_21774)
    goto L7; // [644] 664

    /** fwdref.e:327			pre_refs = length( toplevel_references[current_file_no] )*/
    _2 = (object)SEQ_PTR(_44toplevel_references_63200);
    _31256 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21767);
    if (IS_SEQUENCE(_31256)){
            _pre_refs_63584 = SEQ_PTR(_31256)->length;
    }
    else {
        _pre_refs_63584 = 1;
    }
    _31256 = NOVALUE;
    goto L8; // [661] 697
L7: 

    /** fwdref.e:329			ar_sp = find( code_sub, active_subprogs[current_file_no] )*/
    _2 = (object)SEQ_PTR(_44active_subprogs_63198);
    _31258 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21767);
    _ar_sp_63580 = find_from(_code_sub_63457, _31258, 1);
    _31258 = NOVALUE;

    /** fwdref.e:330			pre_refs = length( active_references[current_file_no][ar_sp] )*/
    _2 = (object)SEQ_PTR(_44active_references_63199);
    _31260 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21767);
    _2 = (object)SEQ_PTR(_31260);
    _31261 = (object)*(((s1_ptr)_2)->base + _ar_sp_63580);
    _31260 = NOVALUE;
    if (IS_SEQUENCE(_31261)){
            _pre_refs_63584 = SEQ_PTR(_31261)->length;
    }
    else {
        _pre_refs_63584 = 1;
    }
    _31261 = NOVALUE;
L8: 

    /** fwdref.e:333		sequence old_fwd_params = {}*/
    RefDS(_22190);
    DeRef(_old_fwd_params_63599);
    _old_fwd_params_63599 = _22190;

    /** fwdref.e:334		for i = pc + 3 to pc + args + 2 do*/
    _31263 = _pc_63486 + 3;
    if ((object)((uintptr_t)_31263 + (uintptr_t)HIGH_BITS) >= 0){
        _31263 = NewDouble((eudouble)_31263);
    }
    _31264 = _pc_63486 + _args_63459;
    if ((object)((uintptr_t)_31264 + (uintptr_t)HIGH_BITS) >= 0){
        _31264 = NewDouble((eudouble)_31264);
    }
    if (IS_ATOM_INT(_31264)) {
        _31265 = _31264 + 2;
        if ((object)((uintptr_t)_31265 + (uintptr_t)HIGH_BITS) >= 0){
            _31265 = NewDouble((eudouble)_31265);
        }
    }
    else {
        _31265 = NewDouble(DBL_PTR(_31264)->dbl + (eudouble)2);
    }
    DeRef(_31264);
    _31264 = NOVALUE;
    {
        object _i_63601;
        Ref(_31263);
        _i_63601 = _31263;
L9: 
        if (binary_op_a(GREATER, _i_63601, _31265)){
            goto LA; // [718] 879
        }

        /** fwdref.e:335			defarg += 1*/
        _defarg_63566 = _defarg_63566 + 1;

        /** fwdref.e:336			param_sym = SymTab[param_sym][S_NEXT]*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _31267 = (object)*(((s1_ptr)_2)->base + _param_sym_63572);
        _2 = (object)SEQ_PTR(_31267);
        _param_sym_63572 = (object)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_param_sym_63572)){
            _param_sym_63572 = (object)DBL_PTR(_param_sym_63572)->dbl;
        }
        _31267 = NOVALUE;

        /** fwdref.e:337			if defarg > supplied_args or i > length( code ) or not code[i] then*/
        _31269 = (_defarg_63566 > _supplied_args_63489);
        if (_31269 != 0) {
            _31270 = 1;
            goto LB; // [753] 768
        }
        if (IS_SEQUENCE(_code_63482)){
                _31271 = SEQ_PTR(_code_63482)->length;
        }
        else {
            _31271 = 1;
        }
        if (IS_ATOM_INT(_i_63601)) {
            _31272 = (_i_63601 > _31271);
        }
        else {
            _31272 = (DBL_PTR(_i_63601)->dbl > (eudouble)_31271);
        }
        _31271 = NOVALUE;
        _31270 = (_31272 != 0);
LB: 
        if (_31270 != 0) {
            goto LC; // [768] 784
        }
        _2 = (object)SEQ_PTR(_code_63482);
        if (!IS_ATOM_INT(_i_63601)){
            _31274 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_63601)->dbl));
        }
        else{
            _31274 = (object)*(((s1_ptr)_2)->base + _i_63601);
        }
        if (IS_ATOM_INT(_31274)) {
            _31275 = (_31274 == 0);
        }
        else {
            _31275 = unary_op(NOT, _31274);
        }
        _31274 = NOVALUE;
        if (_31275 == 0) {
            DeRef(_31275);
            _31275 = NOVALUE;
            goto LD; // [780] 834
        }
        else {
            if (!IS_ATOM_INT(_31275) && DBL_PTR(_31275)->dbl == 0.0){
                DeRef(_31275);
                _31275 = NOVALUE;
                goto LD; // [780] 834
            }
            DeRef(_31275);
            _31275 = NOVALUE;
        }
        DeRef(_31275);
        _31275 = NOVALUE;
LC: 

        /** fwdref.e:339				has_defaults = 1*/
        _has_defaults_63562 = 1;

        /** fwdref.e:340				extra_default_args += 1*/
        _extra_default_args_63569 = _extra_default_args_63569 + 1;

        /** fwdref.e:345				show_params( sub )*/
        _54show_params(_sub_63430);

        /** fwdref.e:346				set_error_info( ref )*/
        _44set_error_info(_ref_63426);

        /** fwdref.e:347				Parse_default_arg(sub, defarg, fwd_private_name, fwd_private_sym) --call_proc( parse_arg_rid, { sub, defarg, fwd_private_name, fwd_private_sym } )*/
        RefDS(_44fwd_private_name_63388);
        RefDS(_44fwd_private_sym_63387);
        _45Parse_default_arg(_sub_63430, _defarg_63566, _44fwd_private_name_63388, _44fwd_private_sym_63387);

        /** fwdref.e:348				hide_params( sub )*/
        _54hide_params(_sub_63430);

        /** fwdref.e:349				params[defarg] = Pop()*/
        _31277 = _47Pop();
        _2 = (object)SEQ_PTR(_params_63573);
        _2 = (object)(((s1_ptr)_2)->base + _defarg_63566);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _31277;
        if( _1 != _31277 ){
            DeRef(_1);
        }
        _31277 = NOVALUE;
        goto LE; // [831] 872
LD: 

        /** fwdref.e:351				extra_default_args = 0*/
        _extra_default_args_63569 = 0;

        /** fwdref.e:352				add_private_symbol( code[i], SymTab[param_sym][S_NAME] )*/
        _2 = (object)SEQ_PTR(_code_63482);
        if (!IS_ATOM_INT(_i_63601)){
            _31278 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_63601)->dbl));
        }
        else{
            _31278 = (object)*(((s1_ptr)_2)->base + _i_63601);
        }
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _31279 = (object)*(((s1_ptr)_2)->base + _param_sym_63572);
        _2 = (object)SEQ_PTR(_31279);
        if (!IS_ATOM_INT(_36S_NAME_21404)){
            _31280 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21404)->dbl));
        }
        else{
            _31280 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21404);
        }
        _31279 = NOVALUE;
        Ref(_31278);
        Ref(_31280);
        _44add_private_symbol(_31278, _31280);
        _31278 = NOVALUE;
        _31280 = NOVALUE;

        /** fwdref.e:353				params[defarg] = code[i]*/
        _2 = (object)SEQ_PTR(_code_63482);
        if (!IS_ATOM_INT(_i_63601)){
            _31281 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_63601)->dbl));
        }
        else{
            _31281 = (object)*(((s1_ptr)_2)->base + _i_63601);
        }
        Ref(_31281);
        _2 = (object)SEQ_PTR(_params_63573);
        _2 = (object)(((s1_ptr)_2)->base + _defarg_63566);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _31281;
        if( _1 != _31281 ){
            DeRef(_1);
        }
        _31281 = NOVALUE;
LE: 

        /** fwdref.e:355		end for*/
        _0 = _i_63601;
        if (IS_ATOM_INT(_i_63601)) {
            _i_63601 = _i_63601 + 1;
            if ((object)((uintptr_t)_i_63601 +(uintptr_t) HIGH_BITS) >= 0){
                _i_63601 = NewDouble((eudouble)_i_63601);
            }
        }
        else {
            _i_63601 = binary_op_a(PLUS, _i_63601, 1);
        }
        DeRef(_0);
        goto L9; // [874] 725
LA: 
        ;
        DeRef(_i_63601);
    }

    /** fwdref.e:357		SymTab[code_sub][S_STACK_SPACE] += temps_allocated*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_code_sub_63457 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!IS_ATOM_INT(_36S_STACK_SPACE_21464)){
        _31284 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_STACK_SPACE_21464)->dbl));
    }
    else{
        _31284 = (object)*(((s1_ptr)_2)->base + _36S_STACK_SPACE_21464);
    }
    _31282 = NOVALUE;
    if (IS_ATOM_INT(_31284)) {
        _31285 = _31284 + _54temps_allocated_47667;
        if ((object)((uintptr_t)_31285 + (uintptr_t)HIGH_BITS) >= 0){
            _31285 = NewDouble((eudouble)_31285);
        }
    }
    else {
        _31285 = binary_op(PLUS, _31284, _54temps_allocated_47667);
    }
    _31284 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_STACK_SPACE_21464))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_STACK_SPACE_21464)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_STACK_SPACE_21464);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31285;
    if( _1 != _31285 ){
        DeRef(_1);
    }
    _31285 = NOVALUE;
    _31282 = NOVALUE;

    /** fwdref.e:358		temps_allocated = old_temps_allocated*/
    _54temps_allocated_47667 = _old_temps_allocated_63528;

    /** fwdref.e:363		integer temp_shifting_sub = shifting_sub*/
    _temp_shifting_sub_63640 = _44shifting_sub_63216;

    /** fwdref.e:364		shift( -pc, pc-1 )*/
    if ((uintptr_t)_pc_63486 == (uintptr_t)HIGH_BITS){
        _31286 = (object)NewDouble((eudouble) -HIGH_BITS);
    }
    else{
        _31286 = - _pc_63486;
    }
    _31287 = _pc_63486 - 1;
    if ((object)((uintptr_t)_31287 +(uintptr_t) HIGH_BITS) >= 0){
        _31287 = NewDouble((eudouble)_31287);
    }
    Ref(_31286);
    DeRef(_31943);
    _31943 = _31286;
    _66shift(_31286, _31287, _31943);
    _31286 = NOVALUE;
    _31287 = NOVALUE;
    _31943 = NOVALUE;

    /** fwdref.e:366		sequence new_code = Code*/
    RefDS(_36Code_21859);
    DeRef(_new_code_63644);
    _new_code_63644 = _36Code_21859;

    /** fwdref.e:367		Code = orig_code*/
    RefDS(_orig_code_63575);
    DeRefDS(_36Code_21859);
    _36Code_21859 = _orig_code_63575;

    /** fwdref.e:368		orig_code = {}*/
    RefDS(_22190);
    DeRefDS(_orig_code_63575);
    _orig_code_63575 = _22190;

    /** fwdref.e:369		LineTable = orig_linetable*/
    RefDS(_orig_linetable_63576);
    DeRef(_36LineTable_21860);
    _36LineTable_21860 = _orig_linetable_63576;

    /** fwdref.e:370		orig_linetable = {}*/
    RefDS(_22190);
    DeRefDS(_orig_linetable_63576);
    _orig_linetable_63576 = _22190;

    /** fwdref.e:371		set_dont_read( 0 )*/
    _62set_dont_read(0);

    /** fwdref.e:372		current_file_no = real_file*/
    _36current_file_no_21767 = _real_file_63478;

    /** fwdref.e:374		if args != ( supplied_args + extra_default_args ) then*/
    _31288 = _supplied_args_63489 + _extra_default_args_63569;
    if ((object)((uintptr_t)_31288 + (uintptr_t)HIGH_BITS) >= 0){
        _31288 = NewDouble((eudouble)_31288);
    }
    if (binary_op_a(EQUALS, _args_63459, _31288)){
        DeRef(_31288);
        _31288 = NOVALUE;
        goto LF; // [990] 1070
    }
    DeRef(_31288);
    _31288 = NOVALUE;

    /** fwdref.e:375			sequence routine_type*/

    /** fwdref.e:377			if is_func then */
    if (_is_func_63464 == 0)
    {
        goto L10; // [998] 1011
    }
    else{
    }

    /** fwdref.e:378				routine_type = "function"*/
    RefDS(_26465);
    DeRefi(_routine_type_63653);
    _routine_type_63653 = _26465;
    goto L11; // [1008] 1019
L10: 

    /** fwdref.e:380				routine_type = "procedure"*/
    RefDS(_26519);
    DeRefi(_routine_type_63653);
    _routine_type_63653 = _26519;
L11: 

    /** fwdref.e:382			current_file_no = fr[FR_FILE]*/
    _2 = (object)SEQ_PTR(_fr_63427);
    _36current_file_no_21767 = (object)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_36current_file_no_21767)){
        _36current_file_no_21767 = (object)DBL_PTR(_36current_file_no_21767)->dbl;
    }

    /** fwdref.e:383			line_number = fr[FR_LINE]*/
    _2 = (object)SEQ_PTR(_fr_63427);
    _36line_number_21768 = (object)*(((s1_ptr)_2)->base + 6);
    if (!IS_ATOM_INT(_36line_number_21768)){
        _36line_number_21768 = (object)DBL_PTR(_36line_number_21768)->dbl;
    }

    /** fwdref.e:384			CompileErr( WRONG_NUMBER_OF_ARGUMENTS_SUPPLIED_FOR_FORWARD_REFERENCET1_2_3_4__EXPECTED_5_BUT_FOUND_6,*/
    _2 = (object)SEQ_PTR(_37known_files_15638);
    _31292 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21767);
    _31293 = _supplied_args_63489 + _extra_default_args_63569;
    if ((object)((uintptr_t)_31293 + (uintptr_t)HIGH_BITS) >= 0){
        _31293 = NewDouble((eudouble)_31293);
    }
    _1 = NewS1(6);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_31292);
    ((intptr_t*)_2)[1] = _31292;
    ((intptr_t*)_2)[2] = _36line_number_21768;
    RefDS(_routine_type_63653);
    ((intptr_t*)_2)[3] = _routine_type_63653;
    RefDS(_name_63492);
    ((intptr_t*)_2)[4] = _name_63492;
    ((intptr_t*)_2)[5] = _args_63459;
    ((intptr_t*)_2)[6] = _31293;
    _31294 = MAKE_SEQ(_1);
    _31293 = NOVALUE;
    _31292 = NOVALUE;
    _50CompileErr(158, _31294, 0);
    _31294 = NOVALUE;
LF: 
    DeRefi(_routine_type_63653);
    _routine_type_63653 = NOVALUE;

    /** fwdref.e:388		new_code &= PROC & sub & params*/
    {
        object concat_list[3];

        concat_list[0] = _params_63573;
        concat_list[1] = _sub_63430;
        concat_list[2] = 27;
        Concat_N((object_ptr)&_31295, concat_list, 3);
    }
    Concat((object_ptr)&_new_code_63644, _new_code_63644, _31295);
    DeRefDS(_31295);
    _31295 = NOVALUE;

    /** fwdref.e:389		if is_func then*/
    if (_is_func_63464 == 0)
    {
        goto L12; // [1088] 1100
    }
    else{
    }

    /** fwdref.e:390			new_code &= target*/
    Append(&_new_code_63644, _new_code_63644, _target_63556);
L12: 

    /** fwdref.e:393		replace_code( new_code, pc, next_pc - 1, code_sub )*/
    _31298 = _next_pc_63488 - 1;
    if ((object)((uintptr_t)_31298 +(uintptr_t) HIGH_BITS) >= 0){
        _31298 = NewDouble((eudouble)_31298);
    }
    RefDS(_new_code_63644);
    _44replace_code(_new_code_63644, _pc_63486, _31298, _code_sub_63457);
    _31298 = NOVALUE;

    /** fwdref.e:395		if code_sub = TopLevelSub then*/
    if (_code_sub_63457 != _36TopLevelSub_21774)
    goto L13; // [1116] 1197

    /** fwdref.e:396			for i = pre_refs + 1 to length( toplevel_references[fr[FR_FILE]] ) do*/
    _31300 = _pre_refs_63584 + 1;
    if (_31300 > MAXINT){
        _31300 = NewDouble((eudouble)_31300);
    }
    _2 = (object)SEQ_PTR(_fr_63427);
    _31301 = (object)*(((s1_ptr)_2)->base + 3);
    _2 = (object)SEQ_PTR(_44toplevel_references_63200);
    if (!IS_ATOM_INT(_31301)){
        _31302 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31301)->dbl));
    }
    else{
        _31302 = (object)*(((s1_ptr)_2)->base + _31301);
    }
    if (IS_SEQUENCE(_31302)){
            _31303 = SEQ_PTR(_31302)->length;
    }
    else {
        _31303 = 1;
    }
    _31302 = NOVALUE;
    {
        object _i_63678;
        Ref(_31300);
        _i_63678 = _31300;
L14: 
        if (binary_op_a(GREATER, _i_63678, _31303)){
            goto L15; // [1141] 1194
        }

        /** fwdref.e:397				forward_references[toplevel_references[fr[FR_FILE]][i]][FR_PC] += pc - 1*/
        _2 = (object)SEQ_PTR(_fr_63427);
        _31304 = (object)*(((s1_ptr)_2)->base + 3);
        _2 = (object)SEQ_PTR(_44toplevel_references_63200);
        if (!IS_ATOM_INT(_31304)){
            _31305 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31304)->dbl));
        }
        else{
            _31305 = (object)*(((s1_ptr)_2)->base + _31304);
        }
        _2 = (object)SEQ_PTR(_31305);
        if (!IS_ATOM_INT(_i_63678)){
            _31306 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_63678)->dbl));
        }
        else{
            _31306 = (object)*(((s1_ptr)_2)->base + _i_63678);
        }
        _31305 = NOVALUE;
        _2 = (object)SEQ_PTR(_44forward_references_63197);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _44forward_references_63197 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_31306))
        _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_31306)->dbl));
        else
        _3 = (object)(_31306 + ((s1_ptr)_2)->base);
        _31309 = _pc_63486 - 1;
        if ((object)((uintptr_t)_31309 +(uintptr_t) HIGH_BITS) >= 0){
            _31309 = NewDouble((eudouble)_31309);
        }
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        _31310 = (object)*(((s1_ptr)_2)->base + 5);
        _31307 = NOVALUE;
        if (IS_ATOM_INT(_31310) && IS_ATOM_INT(_31309)) {
            _31311 = _31310 + _31309;
            if ((object)((uintptr_t)_31311 + (uintptr_t)HIGH_BITS) >= 0){
                _31311 = NewDouble((eudouble)_31311);
            }
        }
        else {
            _31311 = binary_op(PLUS, _31310, _31309);
        }
        _31310 = NOVALUE;
        DeRef(_31309);
        _31309 = NOVALUE;
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 5);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _31311;
        if( _1 != _31311 ){
            DeRef(_1);
        }
        _31311 = NOVALUE;
        _31307 = NOVALUE;

        /** fwdref.e:398			end for*/
        _0 = _i_63678;
        if (IS_ATOM_INT(_i_63678)) {
            _i_63678 = _i_63678 + 1;
            if ((object)((uintptr_t)_i_63678 +(uintptr_t) HIGH_BITS) >= 0){
                _i_63678 = NewDouble((eudouble)_i_63678);
            }
        }
        else {
            _i_63678 = binary_op_a(PLUS, _i_63678, 1);
        }
        DeRef(_0);
        goto L14; // [1189] 1148
L15: 
        ;
        DeRef(_i_63678);
    }
    goto L16; // [1194] 1280
L13: 

    /** fwdref.e:400			for i = pre_refs + 1 to length( active_references[fr[FR_FILE]][ar_sp] ) do*/
    _31312 = _pre_refs_63584 + 1;
    if (_31312 > MAXINT){
        _31312 = NewDouble((eudouble)_31312);
    }
    _2 = (object)SEQ_PTR(_fr_63427);
    _31313 = (object)*(((s1_ptr)_2)->base + 3);
    _2 = (object)SEQ_PTR(_44active_references_63199);
    if (!IS_ATOM_INT(_31313)){
        _31314 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31313)->dbl));
    }
    else{
        _31314 = (object)*(((s1_ptr)_2)->base + _31313);
    }
    _2 = (object)SEQ_PTR(_31314);
    _31315 = (object)*(((s1_ptr)_2)->base + _ar_sp_63580);
    _31314 = NOVALUE;
    if (IS_SEQUENCE(_31315)){
            _31316 = SEQ_PTR(_31315)->length;
    }
    else {
        _31316 = 1;
    }
    _31315 = NOVALUE;
    {
        object _i_63693;
        Ref(_31312);
        _i_63693 = _31312;
L17: 
        if (binary_op_a(GREATER, _i_63693, _31316)){
            goto L18; // [1222] 1279
        }

        /** fwdref.e:401				forward_references[active_references[fr[FR_FILE]][ar_sp][i]][FR_PC] += pc - 1*/
        _2 = (object)SEQ_PTR(_fr_63427);
        _31317 = (object)*(((s1_ptr)_2)->base + 3);
        _2 = (object)SEQ_PTR(_44active_references_63199);
        if (!IS_ATOM_INT(_31317)){
            _31318 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31317)->dbl));
        }
        else{
            _31318 = (object)*(((s1_ptr)_2)->base + _31317);
        }
        _2 = (object)SEQ_PTR(_31318);
        _31319 = (object)*(((s1_ptr)_2)->base + _ar_sp_63580);
        _31318 = NOVALUE;
        _2 = (object)SEQ_PTR(_31319);
        if (!IS_ATOM_INT(_i_63693)){
            _31320 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_63693)->dbl));
        }
        else{
            _31320 = (object)*(((s1_ptr)_2)->base + _i_63693);
        }
        _31319 = NOVALUE;
        _2 = (object)SEQ_PTR(_44forward_references_63197);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _44forward_references_63197 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_31320))
        _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_31320)->dbl));
        else
        _3 = (object)(_31320 + ((s1_ptr)_2)->base);
        _31323 = _pc_63486 - 1;
        if ((object)((uintptr_t)_31323 +(uintptr_t) HIGH_BITS) >= 0){
            _31323 = NewDouble((eudouble)_31323);
        }
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        _31324 = (object)*(((s1_ptr)_2)->base + 5);
        _31321 = NOVALUE;
        if (IS_ATOM_INT(_31324) && IS_ATOM_INT(_31323)) {
            _31325 = _31324 + _31323;
            if ((object)((uintptr_t)_31325 + (uintptr_t)HIGH_BITS) >= 0){
                _31325 = NewDouble((eudouble)_31325);
            }
        }
        else {
            _31325 = binary_op(PLUS, _31324, _31323);
        }
        _31324 = NOVALUE;
        DeRef(_31323);
        _31323 = NOVALUE;
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 5);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _31325;
        if( _1 != _31325 ){
            DeRef(_1);
        }
        _31325 = NOVALUE;
        _31321 = NOVALUE;

        /** fwdref.e:402			end for*/
        _0 = _i_63693;
        if (IS_ATOM_INT(_i_63693)) {
            _i_63693 = _i_63693 + 1;
            if ((object)((uintptr_t)_i_63693 +(uintptr_t) HIGH_BITS) >= 0){
                _i_63693 = NewDouble((eudouble)_i_63693);
            }
        }
        else {
            _i_63693 = binary_op_a(PLUS, _i_63693, 1);
        }
        DeRef(_0);
        goto L17; // [1274] 1229
L18: 
        ;
        DeRef(_i_63693);
    }
L16: 

    /** fwdref.e:405		reset_code()*/
    _44reset_code();

    /** fwdref.e:408		resolved_reference( ref )*/
    _44resolved_reference(_ref_63426);

    /** fwdref.e:409	end procedure*/
    DeRef(_tok_63425);
    DeRef(_fr_63427);
    DeRef(_code_63482);
    DeRef(_name_63492);
    DeRef(_params_63573);
    DeRef(_orig_code_63575);
    DeRef(_orig_linetable_63576);
    DeRef(_old_fwd_params_63599);
    DeRef(_new_code_63644);
    _31261 = NOVALUE;
    _31317 = NOVALUE;
    _31301 = NOVALUE;
    DeRef(_31235);
    _31235 = NOVALUE;
    _31315 = NOVALUE;
    DeRef(_31237);
    _31237 = NOVALUE;
    DeRef(_31263);
    _31263 = NOVALUE;
    DeRef(_31215);
    _31215 = NOVALUE;
    DeRef(_31269);
    _31269 = NOVALUE;
    _31320 = NOVALUE;
    DeRef(_31247);
    _31247 = NOVALUE;
    _31304 = NOVALUE;
    DeRef(_31265);
    _31265 = NOVALUE;
    _31302 = NOVALUE;
    _31256 = NOVALUE;
    _31313 = NOVALUE;
    DeRef(_31211);
    _31211 = NOVALUE;
    DeRef(_31312);
    _31312 = NOVALUE;
    DeRef(_31272);
    _31272 = NOVALUE;
    DeRef(_31300);
    _31300 = NOVALUE;
    _31306 = NOVALUE;
    return;
    ;
}


void _44set_error_info(object _ref_63710)
{
    object _fr_63711 = NOVALUE;
    object _0, _1, _2;
    

    /** fwdref.e:412		sequence fr = forward_references[ref]*/
    DeRef(_fr_63711);
    _2 = (object)SEQ_PTR(_44forward_references_63197);
    _fr_63711 = (object)*(((s1_ptr)_2)->base + _ref_63710);
    Ref(_fr_63711);

    /** fwdref.e:413		ThisLine        = fr[FR_THISLINE]*/
    DeRef(_50ThisLine_49594);
    _2 = (object)SEQ_PTR(_fr_63711);
    _50ThisLine_49594 = (object)*(((s1_ptr)_2)->base + 7);
    Ref(_50ThisLine_49594);

    /** fwdref.e:414		bp              = fr[FR_BP]*/
    _2 = (object)SEQ_PTR(_fr_63711);
    _50bp_49598 = (object)*(((s1_ptr)_2)->base + 8);
    if (!IS_ATOM_INT(_50bp_49598)){
        _50bp_49598 = (object)DBL_PTR(_50bp_49598)->dbl;
    }

    /** fwdref.e:415		line_number     = fr[FR_LINE]*/
    _2 = (object)SEQ_PTR(_fr_63711);
    _36line_number_21768 = (object)*(((s1_ptr)_2)->base + 6);
    if (!IS_ATOM_INT(_36line_number_21768)){
        _36line_number_21768 = (object)DBL_PTR(_36line_number_21768)->dbl;
    }

    /** fwdref.e:416		current_file_no = fr[FR_FILE]*/
    _2 = (object)SEQ_PTR(_fr_63711);
    _36current_file_no_21767 = (object)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_36current_file_no_21767)){
        _36current_file_no_21767 = (object)DBL_PTR(_36current_file_no_21767)->dbl;
    }

    /** fwdref.e:417	end procedure*/
    DeRefDS(_fr_63711);
    return;
    ;
}


void _44patch_forward_variable(object _tok_63724, object _ref_63725)
{
    object _fr_63726 = NOVALUE;
    object _sym_63729 = NOVALUE;
    object _pc_63782 = NOVALUE;
    object _vx_63786 = NOVALUE;
    object _d_63803 = NOVALUE;
    object _param_63813 = NOVALUE;
    object _old_63816 = NOVALUE;
    object _new_63821 = NOVALUE;
    object _31382 = NOVALUE;
    object _31381 = NOVALUE;
    object _31380 = NOVALUE;
    object _31378 = NOVALUE;
    object _31375 = NOVALUE;
    object _31373 = NOVALUE;
    object _31372 = NOVALUE;
    object _31371 = NOVALUE;
    object _31370 = NOVALUE;
    object _31368 = NOVALUE;
    object _31367 = NOVALUE;
    object _31366 = NOVALUE;
    object _31365 = NOVALUE;
    object _31364 = NOVALUE;
    object _31362 = NOVALUE;
    object _31360 = NOVALUE;
    object _31357 = NOVALUE;
    object _31356 = NOVALUE;
    object _31355 = NOVALUE;
    object _31353 = NOVALUE;
    object _31352 = NOVALUE;
    object _31351 = NOVALUE;
    object _31350 = NOVALUE;
    object _31348 = NOVALUE;
    object _31346 = NOVALUE;
    object _31345 = NOVALUE;
    object _31344 = NOVALUE;
    object _31343 = NOVALUE;
    object _31342 = NOVALUE;
    object _31341 = NOVALUE;
    object _31340 = NOVALUE;
    object _31339 = NOVALUE;
    object _31338 = NOVALUE;
    object _31337 = NOVALUE;
    object _31336 = NOVALUE;
    object _31335 = NOVALUE;
    object _31334 = NOVALUE;
    object _31333 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** fwdref.e:421		sequence fr = forward_references[ref]*/
    DeRef(_fr_63726);
    _2 = (object)SEQ_PTR(_44forward_references_63197);
    _fr_63726 = (object)*(((s1_ptr)_2)->base + _ref_63725);
    Ref(_fr_63726);

    /** fwdref.e:422		symtab_index sym = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_63724);
    _sym_63729 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_sym_63729)){
        _sym_63729 = (object)DBL_PTR(_sym_63729)->dbl;
    }

    /** fwdref.e:424		if SymTab[sym][S_FILE_NO] = fr[FR_FILE] */
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _31333 = (object)*(((s1_ptr)_2)->base + _sym_63729);
    _2 = (object)SEQ_PTR(_31333);
    if (!IS_ATOM_INT(_36S_FILE_NO_21400)){
        _31334 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21400)->dbl));
    }
    else{
        _31334 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21400);
    }
    _31333 = NOVALUE;
    _2 = (object)SEQ_PTR(_fr_63726);
    _31335 = (object)*(((s1_ptr)_2)->base + 3);
    if (IS_ATOM_INT(_31334) && IS_ATOM_INT(_31335)) {
        _31336 = (_31334 == _31335);
    }
    else {
        _31336 = binary_op(EQUALS, _31334, _31335);
    }
    _31334 = NOVALUE;
    _31335 = NOVALUE;
    if (IS_ATOM_INT(_31336)) {
        if (_31336 == 0) {
            goto L1; // [45] 69
        }
    }
    else {
        if (DBL_PTR(_31336)->dbl == 0.0) {
            goto L1; // [45] 69
        }
    }
    _2 = (object)SEQ_PTR(_fr_63726);
    _31338 = (object)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_31338)) {
        _31339 = (_31338 == _36TopLevelSub_21774);
    }
    else {
        _31339 = binary_op(EQUALS, _31338, _36TopLevelSub_21774);
    }
    _31338 = NOVALUE;
    if (_31339 == 0) {
        DeRef(_31339);
        _31339 = NOVALUE;
        goto L1; // [60] 69
    }
    else {
        if (!IS_ATOM_INT(_31339) && DBL_PTR(_31339)->dbl == 0.0){
            DeRef(_31339);
            _31339 = NOVALUE;
            goto L1; // [60] 69
        }
        DeRef(_31339);
        _31339 = NOVALUE;
    }
    DeRef(_31339);
    _31339 = NOVALUE;

    /** fwdref.e:426			return*/
    DeRef(_tok_63724);
    DeRef(_fr_63726);
    DeRef(_31336);
    _31336 = NOVALUE;
    return;
L1: 

    /** fwdref.e:429		if fr[FR_OP] = ASSIGN and SymTab[sym][S_MODE] = M_CONSTANT then*/
    _2 = (object)SEQ_PTR(_fr_63726);
    _31340 = (object)*(((s1_ptr)_2)->base + 10);
    if (IS_ATOM_INT(_31340)) {
        _31341 = (_31340 == 18);
    }
    else {
        _31341 = binary_op(EQUALS, _31340, 18);
    }
    _31340 = NOVALUE;
    if (IS_ATOM_INT(_31341)) {
        if (_31341 == 0) {
            goto L2; // [81] 122
        }
    }
    else {
        if (DBL_PTR(_31341)->dbl == 0.0) {
            goto L2; // [81] 122
        }
    }
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _31343 = (object)*(((s1_ptr)_2)->base + _sym_63729);
    _2 = (object)SEQ_PTR(_31343);
    _31344 = (object)*(((s1_ptr)_2)->base + 3);
    _31343 = NOVALUE;
    if (IS_ATOM_INT(_31344)) {
        _31345 = (_31344 == 2);
    }
    else {
        _31345 = binary_op(EQUALS, _31344, 2);
    }
    _31344 = NOVALUE;
    if (_31345 == 0) {
        DeRef(_31345);
        _31345 = NOVALUE;
        goto L2; // [104] 122
    }
    else {
        if (!IS_ATOM_INT(_31345) && DBL_PTR(_31345)->dbl == 0.0){
            DeRef(_31345);
            _31345 = NOVALUE;
            goto L2; // [104] 122
        }
        DeRef(_31345);
        _31345 = NOVALUE;
    }
    DeRef(_31345);
    _31345 = NOVALUE;

    /** fwdref.e:430			prep_forward_error( ref )*/
    _44prep_forward_error(_ref_63725);

    /** fwdref.e:431			CompileErr( MAY_NOT_CHANGE_THE_VALUE_OF_A_CONSTANT)*/
    RefDS(_22190);
    _50CompileErr(110, _22190, 0);
L2: 

    /** fwdref.e:434		if fr[FR_OP] = ASSIGN then*/
    _2 = (object)SEQ_PTR(_fr_63726);
    _31346 = (object)*(((s1_ptr)_2)->base + 10);
    if (binary_op_a(NOTEQ, _31346, 18)){
        _31346 = NOVALUE;
        goto L3; // [130] 170
    }
    _31346 = NOVALUE;

    /** fwdref.e:435			SymTab[sym][S_USAGE] = or_bits( U_WRITTEN, SymTab[sym][S_USAGE] )*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_63729 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _31350 = (object)*(((s1_ptr)_2)->base + _sym_63729);
    _2 = (object)SEQ_PTR(_31350);
    _31351 = (object)*(((s1_ptr)_2)->base + 5);
    _31350 = NOVALUE;
    if (IS_ATOM_INT(_31351)) {
        {uintptr_t tu;
             tu = (uintptr_t)2 | (uintptr_t)_31351;
             _31352 = MAKE_UINT(tu);
        }
    }
    else {
        _31352 = binary_op(OR_BITS, 2, _31351);
    }
    _31351 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31352;
    if( _1 != _31352 ){
        DeRef(_1);
    }
    _31352 = NOVALUE;
    _31348 = NOVALUE;
    goto L4; // [167] 204
L3: 

    /** fwdref.e:437			SymTab[sym][S_USAGE] = or_bits( U_READ, SymTab[sym][S_USAGE] )*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_63729 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _31355 = (object)*(((s1_ptr)_2)->base + _sym_63729);
    _2 = (object)SEQ_PTR(_31355);
    _31356 = (object)*(((s1_ptr)_2)->base + 5);
    _31355 = NOVALUE;
    if (IS_ATOM_INT(_31356)) {
        {uintptr_t tu;
             tu = (uintptr_t)1 | (uintptr_t)_31356;
             _31357 = MAKE_UINT(tu);
        }
    }
    else {
        _31357 = binary_op(OR_BITS, 1, _31356);
    }
    _31356 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31357;
    if( _1 != _31357 ){
        DeRef(_1);
    }
    _31357 = NOVALUE;
    _31353 = NOVALUE;
L4: 

    /** fwdref.e:440		set_code( ref )*/
    _44set_code(_ref_63725);

    /** fwdref.e:441		integer pc = fr[FR_PC]*/
    _2 = (object)SEQ_PTR(_fr_63726);
    _pc_63782 = (object)*(((s1_ptr)_2)->base + 5);
    if (!IS_ATOM_INT(_pc_63782))
    _pc_63782 = (object)DBL_PTR(_pc_63782)->dbl;

    /** fwdref.e:442		if pc < 1 then*/
    if (_pc_63782 >= 1)
    goto L5; // [217] 227

    /** fwdref.e:443			pc = 1*/
    _pc_63782 = 1;
L5: 

    /** fwdref.e:445		integer vx = find( -ref, Code, pc )*/
    if ((uintptr_t)_ref_63725 == (uintptr_t)HIGH_BITS){
        _31360 = (object)NewDouble((eudouble) -HIGH_BITS);
    }
    else{
        _31360 = - _ref_63725;
    }
    _vx_63786 = find_from(_31360, _36Code_21859, _pc_63782);
    DeRef(_31360);
    _31360 = NOVALUE;

    /** fwdref.e:446		if vx then*/
    if (_vx_63786 == 0)
    {
        goto L6; // [241] 283
    }
    else{
    }

    /** fwdref.e:447			while vx do*/
L7: 
    if (_vx_63786 == 0)
    {
        goto L8; // [249] 277
    }
    else{
    }

    /** fwdref.e:450				Code[vx] = sym*/
    _2 = (object)SEQ_PTR(_36Code_21859);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _36Code_21859 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _vx_63786);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _sym_63729;
    DeRef(_1);

    /** fwdref.e:451				vx = find( -ref, Code, vx )*/
    if ((uintptr_t)_ref_63725 == (uintptr_t)HIGH_BITS){
        _31362 = (object)NewDouble((eudouble) -HIGH_BITS);
    }
    else{
        _31362 = - _ref_63725;
    }
    _vx_63786 = find_from(_31362, _36Code_21859, _vx_63786);
    DeRef(_31362);
    _31362 = NOVALUE;

    /** fwdref.e:452			end while*/
    goto L7; // [274] 249
L8: 

    /** fwdref.e:453			resolved_reference( ref )*/
    _44resolved_reference(_ref_63725);
L6: 

    /** fwdref.e:456		if sequence( fr[FR_DATA] ) then*/
    _2 = (object)SEQ_PTR(_fr_63726);
    _31364 = (object)*(((s1_ptr)_2)->base + 12);
    _31365 = IS_SEQUENCE(_31364);
    _31364 = NOVALUE;
    if (_31365 == 0)
    {
        _31365 = NOVALUE;
        goto L9; // [292] 424
    }
    else{
        _31365 = NOVALUE;
    }

    /** fwdref.e:457			for i = 1 to length( fr[FR_DATA] ) do*/
    _2 = (object)SEQ_PTR(_fr_63726);
    _31366 = (object)*(((s1_ptr)_2)->base + 12);
    if (IS_SEQUENCE(_31366)){
            _31367 = SEQ_PTR(_31366)->length;
    }
    else {
        _31367 = 1;
    }
    _31366 = NOVALUE;
    {
        object _i_63800;
        _i_63800 = 1;
LA: 
        if (_i_63800 > _31367){
            goto LB; // [304] 418
        }

        /** fwdref.e:458				object d = fr[FR_DATA][i]*/
        _2 = (object)SEQ_PTR(_fr_63726);
        _31368 = (object)*(((s1_ptr)_2)->base + 12);
        DeRef(_d_63803);
        _2 = (object)SEQ_PTR(_31368);
        _d_63803 = (object)*(((s1_ptr)_2)->base + _i_63800);
        Ref(_d_63803);
        _31368 = NOVALUE;

        /** fwdref.e:459				if sequence( d ) and d[1] = PAM_RECORD then*/
        _31370 = IS_SEQUENCE(_d_63803);
        if (_31370 == 0) {
            goto LC; // [326] 407
        }
        _2 = (object)SEQ_PTR(_d_63803);
        _31372 = (object)*(((s1_ptr)_2)->base + 1);
        if (IS_ATOM_INT(_31372)) {
            _31373 = (_31372 == 1);
        }
        else {
            _31373 = binary_op(EQUALS, _31372, 1);
        }
        _31372 = NOVALUE;
        if (_31373 == 0) {
            DeRef(_31373);
            _31373 = NOVALUE;
            goto LC; // [341] 407
        }
        else {
            if (!IS_ATOM_INT(_31373) && DBL_PTR(_31373)->dbl == 0.0){
                DeRef(_31373);
                _31373 = NOVALUE;
                goto LC; // [341] 407
            }
            DeRef(_31373);
            _31373 = NOVALUE;
        }
        DeRef(_31373);
        _31373 = NOVALUE;

        /** fwdref.e:461					symtab_index param = d[2]*/
        _2 = (object)SEQ_PTR(_d_63803);
        _param_63813 = (object)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_param_63813)){
            _param_63813 = (object)DBL_PTR(_param_63813)->dbl;
        }

        /** fwdref.e:462					token old = {RECORDED, d[3]}*/
        _2 = (object)SEQ_PTR(_d_63803);
        _31375 = (object)*(((s1_ptr)_2)->base + 3);
        Ref(_31375);
        DeRef(_old_63816);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = 508;
        ((intptr_t *)_2)[2] = _31375;
        _old_63816 = MAKE_SEQ(_1);
        _31375 = NOVALUE;

        /** fwdref.e:463					token new = {VARIABLE, sym}*/
        DeRefi(_new_63821);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = -100;
        ((intptr_t *)_2)[2] = _sym_63729;
        _new_63821 = MAKE_SEQ(_1);

        /** fwdref.e:464					SymTab[param][S_CODE] = find_replace( old, SymTab[param][S_CODE], new )*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37SymTab_15637 = MAKE_SEQ(_2);
        }
        _3 = (object)(_param_63813 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _31380 = (object)*(((s1_ptr)_2)->base + _param_63813);
        _2 = (object)SEQ_PTR(_31380);
        if (!IS_ATOM_INT(_36S_CODE_21416)){
            _31381 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21416)->dbl));
        }
        else{
            _31381 = (object)*(((s1_ptr)_2)->base + _36S_CODE_21416);
        }
        _31380 = NOVALUE;
        RefDS(_old_63816);
        Ref(_31381);
        RefDS(_new_63821);
        _31382 = _16find_replace(_old_63816, _31381, _new_63821, 0);
        _31381 = NOVALUE;
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_36S_CODE_21416))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21416)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _36S_CODE_21416);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _31382;
        if( _1 != _31382 ){
            DeRef(_1);
        }
        _31382 = NOVALUE;
        _31378 = NOVALUE;
LC: 
        DeRef(_old_63816);
        _old_63816 = NOVALUE;
        DeRefi(_new_63821);
        _new_63821 = NOVALUE;
        DeRef(_d_63803);
        _d_63803 = NOVALUE;

        /** fwdref.e:466			end for*/
        _i_63800 = _i_63800 + 1;
        goto LA; // [413] 311
LB: 
        ;
    }

    /** fwdref.e:467			resolved_reference( ref )*/
    _44resolved_reference(_ref_63725);
L9: 

    /** fwdref.e:469		reset_code()*/
    _44reset_code();

    /** fwdref.e:470	end procedure*/
    DeRef(_tok_63724);
    DeRef(_fr_63726);
    _31366 = NOVALUE;
    DeRef(_31341);
    _31341 = NOVALUE;
    DeRef(_31336);
    _31336 = NOVALUE;
    return;
    ;
}


void _44patch_forward_init_check(object _tok_63837, object _ref_63838)
{
    object _fr_63839 = NOVALUE;
    object _31390 = NOVALUE;
    object _31389 = NOVALUE;
    object _31388 = NOVALUE;
    object _31386 = NOVALUE;
    object _31385 = NOVALUE;
    object _31384 = NOVALUE;
    object _0, _1, _2;
    

    /** fwdref.e:474		sequence fr = forward_references[ref]*/
    DeRef(_fr_63839);
    _2 = (object)SEQ_PTR(_44forward_references_63197);
    _fr_63839 = (object)*(((s1_ptr)_2)->base + _ref_63838);
    Ref(_fr_63839);

    /** fwdref.e:475		set_code( ref )*/
    _44set_code(_ref_63838);

    /** fwdref.e:476		if sequence( fr[FR_DATA] ) then*/
    _2 = (object)SEQ_PTR(_fr_63839);
    _31384 = (object)*(((s1_ptr)_2)->base + 12);
    _31385 = IS_SEQUENCE(_31384);
    _31384 = NOVALUE;
    if (_31385 == 0)
    {
        _31385 = NOVALUE;
        goto L1; // [27] 38
    }
    else{
        _31385 = NOVALUE;
    }

    /** fwdref.e:478			resolved_reference( ref )*/
    _44resolved_reference(_ref_63838);
    goto L2; // [35] 85
L1: 

    /** fwdref.e:479		elsif fr[FR_PC] > 0 then*/
    _2 = (object)SEQ_PTR(_fr_63839);
    _31386 = (object)*(((s1_ptr)_2)->base + 5);
    if (binary_op_a(LESSEQ, _31386, 0)){
        _31386 = NOVALUE;
        goto L3; // [44] 78
    }
    _31386 = NOVALUE;

    /** fwdref.e:480			Code[fr[FR_PC]+1] = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_fr_63839);
    _31388 = (object)*(((s1_ptr)_2)->base + 5);
    if (IS_ATOM_INT(_31388)) {
        _31389 = _31388 + 1;
        if (_31389 > MAXINT){
            _31389 = NewDouble((eudouble)_31389);
        }
    }
    else
    _31389 = binary_op(PLUS, 1, _31388);
    _31388 = NOVALUE;
    _2 = (object)SEQ_PTR(_tok_63837);
    _31390 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_31390);
    _2 = (object)SEQ_PTR(_36Code_21859);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _36Code_21859 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_31389))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_31389)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _31389);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31390;
    if( _1 != _31390 ){
        DeRef(_1);
    }
    _31390 = NOVALUE;

    /** fwdref.e:481			resolved_reference( ref )*/
    _44resolved_reference(_ref_63838);
    goto L2; // [75] 85
L3: 

    /** fwdref.e:483			forward_error( tok, ref )*/
    Ref(_tok_63837);
    _44forward_error(_tok_63837, _ref_63838);
L2: 

    /** fwdref.e:485		reset_code()*/
    _44reset_code();

    /** fwdref.e:486	end procedure*/
    DeRef(_tok_63837);
    DeRef(_fr_63839);
    DeRef(_31389);
    _31389 = NOVALUE;
    return;
    ;
}


object _44expected_name(object _id_63856)
{
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_id_63856)) {
        _1 = (object)(DBL_PTR(_id_63856)->dbl);
        DeRefDS(_id_63856);
        _id_63856 = _1;
    }

    /** fwdref.e:491		switch id with fallthru do*/
    _0 = _id_63856;
    switch ( _0 ){ 

        /** fwdref.e:492			case PROC then*/
        case 27:
        case 195:

        /** fwdref.e:494				return "a procedure"*/
        RefDS(_26517);
        return _26517;

        /** fwdref.e:496			case FUNC then*/
        case 501:
        case 196:

        /** fwdref.e:498				return "a function"*/
        RefDS(_26463);
        return _26463;

        /** fwdref.e:500			case VARIABLE then*/
        case -100:

        /** fwdref.e:501				return "a variable, constant or enum"*/
        RefDS(_31393);
        return _31393;

        /** fwdref.e:502			case else*/
        default:

        /** fwdref.e:503				return "something"*/
        RefDS(_31394);
        return _31394;
    ;}    ;
}


void _44patch_forward_type(object _tok_63873, object _ref_63874)
{
    object _fr_63875 = NOVALUE;
    object _syms_63877 = NOVALUE;
    object _31406 = NOVALUE;
    object _31405 = NOVALUE;
    object _31403 = NOVALUE;
    object _31402 = NOVALUE;
    object _31401 = NOVALUE;
    object _31399 = NOVALUE;
    object _31398 = NOVALUE;
    object _31397 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** fwdref.e:510		sequence fr = forward_references[ref]*/
    DeRef(_fr_63875);
    _2 = (object)SEQ_PTR(_44forward_references_63197);
    _fr_63875 = (object)*(((s1_ptr)_2)->base + _ref_63874);
    Ref(_fr_63875);

    /** fwdref.e:511		sequence syms = fr[FR_DATA]*/
    DeRef(_syms_63877);
    _2 = (object)SEQ_PTR(_fr_63875);
    _syms_63877 = (object)*(((s1_ptr)_2)->base + 12);
    Ref(_syms_63877);

    /** fwdref.e:512		for i = 2 to length( syms ) do*/
    if (IS_SEQUENCE(_syms_63877)){
            _31397 = SEQ_PTR(_syms_63877)->length;
    }
    else {
        _31397 = 1;
    }
    {
        object _i_63880;
        _i_63880 = 2;
L1: 
        if (_i_63880 > _31397){
            goto L2; // [26] 102
        }

        /** fwdref.e:513			SymTab[syms[i]][S_VTYPE] = tok[T_SYM]*/
        _2 = (object)SEQ_PTR(_syms_63877);
        _31398 = (object)*(((s1_ptr)_2)->base + _i_63880);
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37SymTab_15637 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_31398))
        _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_31398)->dbl));
        else
        _3 = (object)(_31398 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_tok_63873);
        _31401 = (object)*(((s1_ptr)_2)->base + 2);
        Ref(_31401);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 15);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _31401;
        if( _1 != _31401 ){
            DeRef(_1);
        }
        _31401 = NOVALUE;
        _31399 = NOVALUE;

        /** fwdref.e:514			if TRANSLATE then*/
        if (_36TRANSLATE_21369 == 0)
        {
            goto L3; // [62] 95
        }
        else{
        }

        /** fwdref.e:515				SymTab[syms[i]][S_GTYPE] = CompileType(tok[T_SYM])*/
        _2 = (object)SEQ_PTR(_syms_63877);
        _31402 = (object)*(((s1_ptr)_2)->base + _i_63880);
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37SymTab_15637 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_31402))
        _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_31402)->dbl));
        else
        _3 = (object)(_31402 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_tok_63873);
        _31405 = (object)*(((s1_ptr)_2)->base + 2);
        Ref(_31405);
        _31406 = _45CompileType(_31405);
        _31405 = NOVALUE;
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 36);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _31406;
        if( _1 != _31406 ){
            DeRef(_1);
        }
        _31406 = NOVALUE;
        _31403 = NOVALUE;
L3: 

        /** fwdref.e:517		end for*/
        _i_63880 = _i_63880 + 1;
        goto L1; // [97] 33
L2: 
        ;
    }

    /** fwdref.e:518		resolved_reference( ref )*/
    _44resolved_reference(_ref_63874);

    /** fwdref.e:519	end procedure*/
    DeRef(_tok_63873);
    DeRef(_fr_63875);
    DeRef(_syms_63877);
    _31398 = NOVALUE;
    _31402 = NOVALUE;
    return;
    ;
}


void _44patch_forward_case(object _tok_63903, object _ref_63904)
{
    object _fr_63905 = NOVALUE;
    object _switch_pc_63907 = NOVALUE;
    object _case_sym_63910 = NOVALUE;
    object _case_values_63939 = NOVALUE;
    object _cx_63944 = NOVALUE;
    object _negative_63952 = NOVALUE;
    object _31444 = NOVALUE;
    object _31443 = NOVALUE;
    object _31442 = NOVALUE;
    object _31441 = NOVALUE;
    object _31440 = NOVALUE;
    object _31439 = NOVALUE;
    object _31437 = NOVALUE;
    object _31435 = NOVALUE;
    object _31434 = NOVALUE;
    object _31432 = NOVALUE;
    object _31431 = NOVALUE;
    object _31428 = NOVALUE;
    object _31426 = NOVALUE;
    object _31425 = NOVALUE;
    object _31424 = NOVALUE;
    object _31423 = NOVALUE;
    object _31422 = NOVALUE;
    object _31421 = NOVALUE;
    object _31420 = NOVALUE;
    object _31419 = NOVALUE;
    object _31418 = NOVALUE;
    object _31416 = NOVALUE;
    object _31415 = NOVALUE;
    object _31414 = NOVALUE;
    object _31413 = NOVALUE;
    object _31411 = NOVALUE;
    object _31409 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** fwdref.e:522		sequence fr = forward_references[ref]*/
    DeRef(_fr_63905);
    _2 = (object)SEQ_PTR(_44forward_references_63197);
    _fr_63905 = (object)*(((s1_ptr)_2)->base + _ref_63904);
    Ref(_fr_63905);

    /** fwdref.e:524		integer switch_pc = fr[FR_DATA]*/
    _2 = (object)SEQ_PTR(_fr_63905);
    _switch_pc_63907 = (object)*(((s1_ptr)_2)->base + 12);
    if (!IS_ATOM_INT(_switch_pc_63907))
    _switch_pc_63907 = (object)DBL_PTR(_switch_pc_63907)->dbl;

    /** fwdref.e:527		if fr[FR_SUBPROG] = TopLevelSub then*/
    _2 = (object)SEQ_PTR(_fr_63905);
    _31409 = (object)*(((s1_ptr)_2)->base + 4);
    if (binary_op_a(NOTEQ, _31409, _36TopLevelSub_21774)){
        _31409 = NOVALUE;
        goto L1; // [27] 48
    }
    _31409 = NOVALUE;

    /** fwdref.e:528			case_sym = Code[switch_pc + 2]*/
    _31411 = _switch_pc_63907 + 2;
    _2 = (object)SEQ_PTR(_36Code_21859);
    _case_sym_63910 = (object)*(((s1_ptr)_2)->base + _31411);
    if (!IS_ATOM_INT(_case_sym_63910)){
        _case_sym_63910 = (object)DBL_PTR(_case_sym_63910)->dbl;
    }
    goto L2; // [45] 77
L1: 

    /** fwdref.e:530			case_sym = SymTab[fr[FR_SUBPROG]][S_CODE][switch_pc + 2]*/
    _2 = (object)SEQ_PTR(_fr_63905);
    _31413 = (object)*(((s1_ptr)_2)->base + 4);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!IS_ATOM_INT(_31413)){
        _31414 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31413)->dbl));
    }
    else{
        _31414 = (object)*(((s1_ptr)_2)->base + _31413);
    }
    _2 = (object)SEQ_PTR(_31414);
    if (!IS_ATOM_INT(_36S_CODE_21416)){
        _31415 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21416)->dbl));
    }
    else{
        _31415 = (object)*(((s1_ptr)_2)->base + _36S_CODE_21416);
    }
    _31414 = NOVALUE;
    _31416 = _switch_pc_63907 + 2;
    _2 = (object)SEQ_PTR(_31415);
    _case_sym_63910 = (object)*(((s1_ptr)_2)->base + _31416);
    if (!IS_ATOM_INT(_case_sym_63910)){
        _case_sym_63910 = (object)DBL_PTR(_case_sym_63910)->dbl;
    }
    _31415 = NOVALUE;
L2: 

    /** fwdref.e:533		if SymTab[tok[T_SYM]][S_FILE_NO] = fr[FR_FILE] and fr[FR_SUBPROG] = TopLevelSub then*/
    _2 = (object)SEQ_PTR(_tok_63903);
    _31418 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!IS_ATOM_INT(_31418)){
        _31419 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31418)->dbl));
    }
    else{
        _31419 = (object)*(((s1_ptr)_2)->base + _31418);
    }
    _2 = (object)SEQ_PTR(_31419);
    if (!IS_ATOM_INT(_36S_FILE_NO_21400)){
        _31420 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21400)->dbl));
    }
    else{
        _31420 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21400);
    }
    _31419 = NOVALUE;
    _2 = (object)SEQ_PTR(_fr_63905);
    _31421 = (object)*(((s1_ptr)_2)->base + 3);
    if (IS_ATOM_INT(_31420) && IS_ATOM_INT(_31421)) {
        _31422 = (_31420 == _31421);
    }
    else {
        _31422 = binary_op(EQUALS, _31420, _31421);
    }
    _31420 = NOVALUE;
    _31421 = NOVALUE;
    if (IS_ATOM_INT(_31422)) {
        if (_31422 == 0) {
            goto L3; // [105] 129
        }
    }
    else {
        if (DBL_PTR(_31422)->dbl == 0.0) {
            goto L3; // [105] 129
        }
    }
    _2 = (object)SEQ_PTR(_fr_63905);
    _31424 = (object)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_31424)) {
        _31425 = (_31424 == _36TopLevelSub_21774);
    }
    else {
        _31425 = binary_op(EQUALS, _31424, _36TopLevelSub_21774);
    }
    _31424 = NOVALUE;
    if (_31425 == 0) {
        DeRef(_31425);
        _31425 = NOVALUE;
        goto L3; // [120] 129
    }
    else {
        if (!IS_ATOM_INT(_31425) && DBL_PTR(_31425)->dbl == 0.0){
            DeRef(_31425);
            _31425 = NOVALUE;
            goto L3; // [120] 129
        }
        DeRef(_31425);
        _31425 = NOVALUE;
    }
    DeRef(_31425);
    _31425 = NOVALUE;

    /** fwdref.e:534			return*/
    DeRef(_tok_63903);
    DeRef(_fr_63905);
    DeRef(_case_values_63939);
    DeRef(_31422);
    _31422 = NOVALUE;
    _31418 = NOVALUE;
    _31413 = NOVALUE;
    DeRef(_31411);
    _31411 = NOVALUE;
    DeRef(_31416);
    _31416 = NOVALUE;
    return;
L3: 

    /** fwdref.e:537		sequence case_values = SymTab[case_sym][S_OBJ]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _31426 = (object)*(((s1_ptr)_2)->base + _case_sym_63910);
    DeRef(_case_values_63939);
    _2 = (object)SEQ_PTR(_31426);
    _case_values_63939 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_case_values_63939);
    _31426 = NOVALUE;

    /** fwdref.e:539		integer cx = find( { ref }, case_values )*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _ref_63904;
    _31428 = MAKE_SEQ(_1);
    _cx_63944 = find_from(_31428, _case_values_63939, 1);
    DeRefDS(_31428);
    _31428 = NOVALUE;

    /** fwdref.e:540		if not cx then*/
    if (_cx_63944 != 0)
    goto L4; // [160] 178

    /** fwdref.e:541			cx = find( { -ref }, case_values )*/
    if ((uintptr_t)_ref_63904 == (uintptr_t)HIGH_BITS){
        _31431 = (object)NewDouble((eudouble) -HIGH_BITS);
    }
    else{
        _31431 = - _ref_63904;
    }
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _31431;
    _31432 = MAKE_SEQ(_1);
    _31431 = NOVALUE;
    _cx_63944 = find_from(_31432, _case_values_63939, 1);
    DeRefDS(_31432);
    _31432 = NOVALUE;
L4: 

    /** fwdref.e:544	 	ifdef DEBUG then	*/

    /** fwdref.e:551		integer negative = 0*/
    _negative_63952 = 0;

    /** fwdref.e:552		if case_values[cx][1] < 0 then*/
    _2 = (object)SEQ_PTR(_case_values_63939);
    _31434 = (object)*(((s1_ptr)_2)->base + _cx_63944);
    _2 = (object)SEQ_PTR(_31434);
    _31435 = (object)*(((s1_ptr)_2)->base + 1);
    _31434 = NOVALUE;
    if (binary_op_a(GREATEREQ, _31435, 0)){
        _31435 = NOVALUE;
        goto L5; // [195] 224
    }
    _31435 = NOVALUE;

    /** fwdref.e:553			negative = 1*/
    _negative_63952 = 1;

    /** fwdref.e:554			case_values[cx][1] *= -1*/
    _2 = (object)SEQ_PTR(_case_values_63939);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _case_values_63939 = MAKE_SEQ(_2);
    }
    _3 = (object)(_cx_63944 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _31439 = (object)*(((s1_ptr)_2)->base + 1);
    _31437 = NOVALUE;
    if (IS_ATOM_INT(_31439)) {
        if (_31439 == (short)_31439){
            _31440 = _31439 * -1;
        }
        else{
            _31440 = NewDouble(_31439 * (eudouble)-1);
        }
    }
    else {
        _31440 = binary_op(MULTIPLY, _31439, -1);
    }
    _31439 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31440;
    if( _1 != _31440 ){
        DeRef(_1);
    }
    _31440 = NOVALUE;
    _31437 = NOVALUE;
L5: 

    /** fwdref.e:557		if negative then*/
    if (_negative_63952 == 0)
    {
        goto L6; // [226] 247
    }
    else{
    }

    /** fwdref.e:558			case_values[cx] = - tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_63903);
    _31441 = (object)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_31441)) {
        if ((uintptr_t)_31441 == (uintptr_t)HIGH_BITS){
            _31442 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _31442 = - _31441;
        }
    }
    else {
        _31442 = unary_op(UMINUS, _31441);
    }
    _31441 = NOVALUE;
    _2 = (object)SEQ_PTR(_case_values_63939);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _case_values_63939 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _cx_63944);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31442;
    if( _1 != _31442 ){
        DeRef(_1);
    }
    _31442 = NOVALUE;
    goto L7; // [244] 260
L6: 

    /** fwdref.e:560			case_values[cx] = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_63903);
    _31443 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_31443);
    _2 = (object)SEQ_PTR(_case_values_63939);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _case_values_63939 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _cx_63944);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31443;
    if( _1 != _31443 ){
        DeRef(_1);
    }
    _31443 = NOVALUE;
L7: 

    /** fwdref.e:562		SymTab[case_sym][S_OBJ] = case_values*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_case_sym_63910 + ((s1_ptr)_2)->base);
    RefDS(_case_values_63939);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _case_values_63939;
    DeRef(_1);
    _31444 = NOVALUE;

    /** fwdref.e:563		resolved_reference( ref )*/
    _44resolved_reference(_ref_63904);

    /** fwdref.e:564	end procedure*/
    DeRef(_tok_63903);
    DeRef(_fr_63905);
    DeRefDS(_case_values_63939);
    DeRef(_31422);
    _31422 = NOVALUE;
    _31418 = NOVALUE;
    _31413 = NOVALUE;
    DeRef(_31411);
    _31411 = NOVALUE;
    DeRef(_31416);
    _31416 = NOVALUE;
    return;
    ;
}


void _44patch_forward_type_check(object _tok_63975, object _ref_63976)
{
    object _fr_63977 = NOVALUE;
    object _which_type_63980 = NOVALUE;
    object _var_63982 = NOVALUE;
    object _pc_64015 = NOVALUE;
    object _with_type_check_64017 = NOVALUE;
    object _c_64047 = NOVALUE;
    object _subprog_inlined_insert_code_at_332_64056 = NOVALUE;
    object _code_inlined_insert_code_at_329_64055 = NOVALUE;
    object _subprog_inlined_insert_code_at_415_64072 = NOVALUE;
    object _code_inlined_insert_code_at_412_64071 = NOVALUE;
    object _subprog_inlined_insert_code_at_477_64082 = NOVALUE;
    object _code_inlined_insert_code_at_474_64081 = NOVALUE;
    object _subprog_inlined_insert_code_at_539_64092 = NOVALUE;
    object _code_inlined_insert_code_at_536_64091 = NOVALUE;
    object _start_pc_64099 = NOVALUE;
    object _subprog_inlined_insert_code_at_647_64116 = NOVALUE;
    object _code_inlined_insert_code_at_644_64115 = NOVALUE;
    object _c_64119 = NOVALUE;
    object _subprog_inlined_insert_code_at_741_64135 = NOVALUE;
    object _code_inlined_insert_code_at_738_64134 = NOVALUE;
    object _start_pc_64146 = NOVALUE;
    object _subprog_inlined_insert_code_at_886_64166 = NOVALUE;
    object _code_inlined_insert_code_at_883_64165 = NOVALUE;
    object _subprog_inlined_insert_code_at_987_64187 = NOVALUE;
    object _code_inlined_insert_code_at_984_64186 = NOVALUE;
    object _31534 = NOVALUE;
    object _31533 = NOVALUE;
    object _31532 = NOVALUE;
    object _31531 = NOVALUE;
    object _31530 = NOVALUE;
    object _31529 = NOVALUE;
    object _31528 = NOVALUE;
    object _31526 = NOVALUE;
    object _31524 = NOVALUE;
    object _31523 = NOVALUE;
    object _31522 = NOVALUE;
    object _31521 = NOVALUE;
    object _31520 = NOVALUE;
    object _31519 = NOVALUE;
    object _31518 = NOVALUE;
    object _31516 = NOVALUE;
    object _31515 = NOVALUE;
    object _31514 = NOVALUE;
    object _31513 = NOVALUE;
    object _31512 = NOVALUE;
    object _31511 = NOVALUE;
    object _31509 = NOVALUE;
    object _31508 = NOVALUE;
    object _31507 = NOVALUE;
    object _31506 = NOVALUE;
    object _31504 = NOVALUE;
    object _31503 = NOVALUE;
    object _31500 = NOVALUE;
    object _31499 = NOVALUE;
    object _31497 = NOVALUE;
    object _31496 = NOVALUE;
    object _31495 = NOVALUE;
    object _31494 = NOVALUE;
    object _31493 = NOVALUE;
    object _31492 = NOVALUE;
    object _31490 = NOVALUE;
    object _31489 = NOVALUE;
    object _31486 = NOVALUE;
    object _31485 = NOVALUE;
    object _31482 = NOVALUE;
    object _31481 = NOVALUE;
    object _31477 = NOVALUE;
    object _31476 = NOVALUE;
    object _31474 = NOVALUE;
    object _31473 = NOVALUE;
    object _31471 = NOVALUE;
    object _31470 = NOVALUE;
    object _31467 = NOVALUE;
    object _31464 = NOVALUE;
    object _31462 = NOVALUE;
    object _31459 = NOVALUE;
    object _31458 = NOVALUE;
    object _31455 = NOVALUE;
    object _31450 = NOVALUE;
    object _31449 = NOVALUE;
    object _31447 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** fwdref.e:568		sequence fr = forward_references[ref]*/
    DeRef(_fr_63977);
    _2 = (object)SEQ_PTR(_44forward_references_63197);
    _fr_63977 = (object)*(((s1_ptr)_2)->base + _ref_63976);
    Ref(_fr_63977);

    /** fwdref.e:572		if fr[FR_OP] = TYPE_CHECK_FORWARD then*/
    _2 = (object)SEQ_PTR(_fr_63977);
    _31447 = (object)*(((s1_ptr)_2)->base + 10);
    if (binary_op_a(NOTEQ, _31447, 197)){
        _31447 = NOVALUE;
        goto L1; // [21] 86
    }
    _31447 = NOVALUE;

    /** fwdref.e:573			which_type = SymTab[tok[T_SYM]][S_VTYPE]*/
    _2 = (object)SEQ_PTR(_tok_63975);
    _31449 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!IS_ATOM_INT(_31449)){
        _31450 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31449)->dbl));
    }
    else{
        _31450 = (object)*(((s1_ptr)_2)->base + _31449);
    }
    _2 = (object)SEQ_PTR(_31450);
    _which_type_63980 = (object)*(((s1_ptr)_2)->base + 15);
    if (!IS_ATOM_INT(_which_type_63980)){
        _which_type_63980 = (object)DBL_PTR(_which_type_63980)->dbl;
    }
    _31450 = NOVALUE;

    /** fwdref.e:574			if not which_type then*/
    if (_which_type_63980 != 0)
    goto L2; // [49] 72

    /** fwdref.e:575				which_type = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_63975);
    _which_type_63980 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_which_type_63980)){
        _which_type_63980 = (object)DBL_PTR(_which_type_63980)->dbl;
    }

    /** fwdref.e:576				var = 0*/
    _var_63982 = 0;
    goto L3; // [69] 144
L2: 

    /** fwdref.e:578				var = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_63975);
    _var_63982 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_var_63982)){
        _var_63982 = (object)DBL_PTR(_var_63982)->dbl;
    }
    goto L3; // [83] 144
L1: 

    /** fwdref.e:582		elsif fr[FR_OP] = TYPE then*/
    _2 = (object)SEQ_PTR(_fr_63977);
    _31455 = (object)*(((s1_ptr)_2)->base + 10);
    if (binary_op_a(NOTEQ, _31455, 504)){
        _31455 = NOVALUE;
        goto L4; // [94] 118
    }
    _31455 = NOVALUE;

    /** fwdref.e:583			which_type = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_63975);
    _which_type_63980 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_which_type_63980)){
        _which_type_63980 = (object)DBL_PTR(_which_type_63980)->dbl;
    }

    /** fwdref.e:584			var = 0*/
    _var_63982 = 0;
    goto L3; // [115] 144
L4: 

    /** fwdref.e:587			prep_forward_error( ref )*/
    _44prep_forward_error(_ref_63976);

    /** fwdref.e:588			InternalErr( 262, { TYPE_CHECK, TYPE_CHECK_FORWARD, fr[FR_OP] })*/
    _2 = (object)SEQ_PTR(_fr_63977);
    _31458 = (object)*(((s1_ptr)_2)->base + 10);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 65;
    ((intptr_t*)_2)[2] = 197;
    Ref(_31458);
    ((intptr_t*)_2)[3] = _31458;
    _31459 = MAKE_SEQ(_1);
    _31458 = NOVALUE;
    _50InternalErr(262, _31459);
    _31459 = NOVALUE;
L3: 

    /** fwdref.e:591		if which_type < 0 then*/
    if (_which_type_63980 >= 0)
    goto L5; // [148] 158

    /** fwdref.e:593			return*/
    DeRef(_tok_63975);
    DeRef(_fr_63977);
    _31449 = NOVALUE;
    return;
L5: 

    /** fwdref.e:596		set_code( ref )*/
    _44set_code(_ref_63976);

    /** fwdref.e:598		integer pc = fr[FR_PC]*/
    _2 = (object)SEQ_PTR(_fr_63977);
    _pc_64015 = (object)*(((s1_ptr)_2)->base + 5);
    if (!IS_ATOM_INT(_pc_64015))
    _pc_64015 = (object)DBL_PTR(_pc_64015)->dbl;

    /** fwdref.e:599		integer with_type_check = Code[pc + 2]*/
    _31462 = _pc_64015 + 2;
    _2 = (object)SEQ_PTR(_36Code_21859);
    _with_type_check_64017 = (object)*(((s1_ptr)_2)->base + _31462);
    if (!IS_ATOM_INT(_with_type_check_64017)){
        _with_type_check_64017 = (object)DBL_PTR(_with_type_check_64017)->dbl;
    }

    /** fwdref.e:601		if Code[pc] != TYPE_CHECK_FORWARD then*/
    _2 = (object)SEQ_PTR(_36Code_21859);
    _31464 = (object)*(((s1_ptr)_2)->base + _pc_64015);
    if (binary_op_a(EQUALS, _31464, 197)){
        _31464 = NOVALUE;
        goto L6; // [193] 204
    }
    _31464 = NOVALUE;

    /** fwdref.e:602			forward_error( tok, ref )*/
    Ref(_tok_63975);
    _44forward_error(_tok_63975, _ref_63976);
L6: 

    /** fwdref.e:604		if not var then*/
    if (_var_63982 != 0)
    goto L7; // [208] 226

    /** fwdref.e:606			var = Code[pc+1]*/
    _31467 = _pc_64015 + 1;
    _2 = (object)SEQ_PTR(_36Code_21859);
    _var_63982 = (object)*(((s1_ptr)_2)->base + _31467);
    if (!IS_ATOM_INT(_var_63982)){
        _var_63982 = (object)DBL_PTR(_var_63982)->dbl;
    }
L7: 

    /** fwdref.e:609		if var < 0 then*/
    if (_var_63982 >= 0)
    goto L8; // [228] 238

    /** fwdref.e:611			return*/
    DeRef(_tok_63975);
    DeRef(_fr_63977);
    DeRef(_31467);
    _31467 = NOVALUE;
    DeRef(_31462);
    _31462 = NOVALUE;
    _31449 = NOVALUE;
    return;
L8: 

    /** fwdref.e:615		replace_code( {}, pc, pc + 2, fr[FR_SUBPROG])*/
    _31470 = _pc_64015 + 2;
    if ((object)((uintptr_t)_31470 + (uintptr_t)HIGH_BITS) >= 0){
        _31470 = NewDouble((eudouble)_31470);
    }
    _2 = (object)SEQ_PTR(_fr_63977);
    _31471 = (object)*(((s1_ptr)_2)->base + 4);
    RefDS(_22190);
    Ref(_31471);
    _44replace_code(_22190, _pc_64015, _31470, _31471);
    _31470 = NOVALUE;
    _31471 = NOVALUE;

    /** fwdref.e:617		if TRANSLATE then*/
    if (_36TRANSLATE_21369 == 0)
    {
        goto L9; // [258] 364
    }
    else{
    }

    /** fwdref.e:618			if with_type_check then*/
    if (_with_type_check_64017 == 0)
    {
        goto LA; // [263] 771
    }
    else{
    }

    /** fwdref.e:619				if which_type != object_type then*/
    if (_which_type_63980 == _54object_type_47136)
    goto LA; // [270] 771

    /** fwdref.e:620					if SymTab[which_type][S_EFFECT] then*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _31473 = (object)*(((s1_ptr)_2)->base + _which_type_63980);
    _2 = (object)SEQ_PTR(_31473);
    _31474 = (object)*(((s1_ptr)_2)->base + 23);
    _31473 = NOVALUE;
    if (_31474 == 0) {
        _31474 = NOVALUE;
        goto LB; // [288] 357
    }
    else {
        if (!IS_ATOM_INT(_31474) && DBL_PTR(_31474)->dbl == 0.0){
            _31474 = NOVALUE;
            goto LB; // [288] 357
        }
        _31474 = NOVALUE;
    }
    _31474 = NOVALUE;

    /** fwdref.e:622						integer c = NewTempSym()*/
    _c_64047 = _54NewTempSym(0);
    if (!IS_ATOM_INT(_c_64047)) {
        _1 = (object)(DBL_PTR(_c_64047)->dbl);
        DeRefDS(_c_64047);
        _c_64047 = _1;
    }

    /** fwdref.e:623						insert_code( { PROC, which_type, var, c, TYPE_CHECK }, pc, fr[FR_SUBPROG] )*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 27;
    ((intptr_t*)_2)[2] = _which_type_63980;
    ((intptr_t*)_2)[3] = _var_63982;
    ((intptr_t*)_2)[4] = _c_64047;
    ((intptr_t*)_2)[5] = 65;
    _31476 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_fr_63977);
    _31477 = (object)*(((s1_ptr)_2)->base + 4);
    DeRefi(_code_inlined_insert_code_at_329_64055);
    _code_inlined_insert_code_at_329_64055 = _31476;
    _31476 = NOVALUE;
    Ref(_31477);
    DeRef(_subprog_inlined_insert_code_at_332_64056);
    _subprog_inlined_insert_code_at_332_64056 = _31477;
    _31477 = NOVALUE;
    if (!IS_ATOM_INT(_subprog_inlined_insert_code_at_332_64056)) {
        _1 = (object)(DBL_PTR(_subprog_inlined_insert_code_at_332_64056)->dbl);
        DeRefDS(_subprog_inlined_insert_code_at_332_64056);
        _subprog_inlined_insert_code_at_332_64056 = _1;
    }

    /** fwdref.e:82		shifting_sub = subprog*/
    _44shifting_sub_63216 = _subprog_inlined_insert_code_at_332_64056;

    /** fwdref.e:83		shift:insert_code( code, index )*/
    RefDS(_code_inlined_insert_code_at_329_64055);
    _66insert_code(_code_inlined_insert_code_at_329_64055, _pc_64015);

    /** fwdref.e:84		shifting_sub = 0*/
    _44shifting_sub_63216 = 0;

    /** fwdref.e:85	end procedure*/
    goto LC; // [345] 348
LC: 
    DeRefi(_code_inlined_insert_code_at_329_64055);
    _code_inlined_insert_code_at_329_64055 = NOVALUE;
    DeRef(_subprog_inlined_insert_code_at_332_64056);
    _subprog_inlined_insert_code_at_332_64056 = NOVALUE;

    /** fwdref.e:624						pc += 5*/
    _pc_64015 = _pc_64015 + 5;
LB: 
    goto LA; // [361] 771
L9: 

    /** fwdref.e:630			if with_type_check then*/
    if (_with_type_check_64017 == 0)
    {
        goto LD; // [366] 770
    }
    else{
    }

    /** fwdref.e:632				if which_type = object_type then*/
    if (_which_type_63980 != _54object_type_47136)
    goto LE; // [373] 380
    goto LF; // [377] 769
LE: 

    /** fwdref.e:636					if which_type = integer_type then*/
    if (_which_type_63980 != _54integer_type_47142)
    goto L10; // [384] 442

    /** fwdref.e:637						insert_code( { INTEGER_CHECK, var }, pc, fr[FR_SUBPROG] )*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 96;
    ((intptr_t *)_2)[2] = _var_63982;
    _31481 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_fr_63977);
    _31482 = (object)*(((s1_ptr)_2)->base + 4);
    DeRefi(_code_inlined_insert_code_at_412_64071);
    _code_inlined_insert_code_at_412_64071 = _31481;
    _31481 = NOVALUE;
    Ref(_31482);
    DeRef(_subprog_inlined_insert_code_at_415_64072);
    _subprog_inlined_insert_code_at_415_64072 = _31482;
    _31482 = NOVALUE;
    if (!IS_ATOM_INT(_subprog_inlined_insert_code_at_415_64072)) {
        _1 = (object)(DBL_PTR(_subprog_inlined_insert_code_at_415_64072)->dbl);
        DeRefDS(_subprog_inlined_insert_code_at_415_64072);
        _subprog_inlined_insert_code_at_415_64072 = _1;
    }

    /** fwdref.e:82		shifting_sub = subprog*/
    _44shifting_sub_63216 = _subprog_inlined_insert_code_at_415_64072;

    /** fwdref.e:83		shift:insert_code( code, index )*/
    RefDS(_code_inlined_insert_code_at_412_64071);
    _66insert_code(_code_inlined_insert_code_at_412_64071, _pc_64015);

    /** fwdref.e:84		shifting_sub = 0*/
    _44shifting_sub_63216 = 0;

    /** fwdref.e:85	end procedure*/
    goto L11; // [428] 431
L11: 
    DeRefi(_code_inlined_insert_code_at_412_64071);
    _code_inlined_insert_code_at_412_64071 = NOVALUE;
    DeRef(_subprog_inlined_insert_code_at_415_64072);
    _subprog_inlined_insert_code_at_415_64072 = NOVALUE;

    /** fwdref.e:638						pc += 2*/
    _pc_64015 = _pc_64015 + 2;
    goto L12; // [439] 768
L10: 

    /** fwdref.e:640					elsif which_type = sequence_type then*/
    if (_which_type_63980 != _54sequence_type_47140)
    goto L13; // [446] 504

    /** fwdref.e:641						insert_code( { SEQUENCE_CHECK, var }, pc, fr[FR_SUBPROG])*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 97;
    ((intptr_t *)_2)[2] = _var_63982;
    _31485 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_fr_63977);
    _31486 = (object)*(((s1_ptr)_2)->base + 4);
    DeRefi(_code_inlined_insert_code_at_474_64081);
    _code_inlined_insert_code_at_474_64081 = _31485;
    _31485 = NOVALUE;
    Ref(_31486);
    DeRef(_subprog_inlined_insert_code_at_477_64082);
    _subprog_inlined_insert_code_at_477_64082 = _31486;
    _31486 = NOVALUE;
    if (!IS_ATOM_INT(_subprog_inlined_insert_code_at_477_64082)) {
        _1 = (object)(DBL_PTR(_subprog_inlined_insert_code_at_477_64082)->dbl);
        DeRefDS(_subprog_inlined_insert_code_at_477_64082);
        _subprog_inlined_insert_code_at_477_64082 = _1;
    }

    /** fwdref.e:82		shifting_sub = subprog*/
    _44shifting_sub_63216 = _subprog_inlined_insert_code_at_477_64082;

    /** fwdref.e:83		shift:insert_code( code, index )*/
    RefDS(_code_inlined_insert_code_at_474_64081);
    _66insert_code(_code_inlined_insert_code_at_474_64081, _pc_64015);

    /** fwdref.e:84		shifting_sub = 0*/
    _44shifting_sub_63216 = 0;

    /** fwdref.e:85	end procedure*/
    goto L14; // [490] 493
L14: 
    DeRefi(_code_inlined_insert_code_at_474_64081);
    _code_inlined_insert_code_at_474_64081 = NOVALUE;
    DeRef(_subprog_inlined_insert_code_at_477_64082);
    _subprog_inlined_insert_code_at_477_64082 = NOVALUE;

    /** fwdref.e:642						pc += 2*/
    _pc_64015 = _pc_64015 + 2;
    goto L12; // [501] 768
L13: 

    /** fwdref.e:644					elsif which_type = atom_type then*/
    if (_which_type_63980 != _54atom_type_47138)
    goto L15; // [508] 566

    /** fwdref.e:645						insert_code( { ATOM_CHECK, var }, pc, fr[FR_SUBPROG] )*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 101;
    ((intptr_t *)_2)[2] = _var_63982;
    _31489 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_fr_63977);
    _31490 = (object)*(((s1_ptr)_2)->base + 4);
    DeRefi(_code_inlined_insert_code_at_536_64091);
    _code_inlined_insert_code_at_536_64091 = _31489;
    _31489 = NOVALUE;
    Ref(_31490);
    DeRef(_subprog_inlined_insert_code_at_539_64092);
    _subprog_inlined_insert_code_at_539_64092 = _31490;
    _31490 = NOVALUE;
    if (!IS_ATOM_INT(_subprog_inlined_insert_code_at_539_64092)) {
        _1 = (object)(DBL_PTR(_subprog_inlined_insert_code_at_539_64092)->dbl);
        DeRefDS(_subprog_inlined_insert_code_at_539_64092);
        _subprog_inlined_insert_code_at_539_64092 = _1;
    }

    /** fwdref.e:82		shifting_sub = subprog*/
    _44shifting_sub_63216 = _subprog_inlined_insert_code_at_539_64092;

    /** fwdref.e:83		shift:insert_code( code, index )*/
    RefDS(_code_inlined_insert_code_at_536_64091);
    _66insert_code(_code_inlined_insert_code_at_536_64091, _pc_64015);

    /** fwdref.e:84		shifting_sub = 0*/
    _44shifting_sub_63216 = 0;

    /** fwdref.e:85	end procedure*/
    goto L16; // [552] 555
L16: 
    DeRefi(_code_inlined_insert_code_at_536_64091);
    _code_inlined_insert_code_at_536_64091 = NOVALUE;
    DeRef(_subprog_inlined_insert_code_at_539_64092);
    _subprog_inlined_insert_code_at_539_64092 = NOVALUE;

    /** fwdref.e:646						pc += 2*/
    _pc_64015 = _pc_64015 + 2;
    goto L12; // [563] 768
L15: 

    /** fwdref.e:648					elsif SymTab[which_type][S_NEXT] then*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _31492 = (object)*(((s1_ptr)_2)->base + _which_type_63980);
    _2 = (object)SEQ_PTR(_31492);
    _31493 = (object)*(((s1_ptr)_2)->base + 2);
    _31492 = NOVALUE;
    if (_31493 == 0) {
        _31493 = NOVALUE;
        goto L17; // [580] 765
    }
    else {
        if (!IS_ATOM_INT(_31493) && DBL_PTR(_31493)->dbl == 0.0){
            _31493 = NOVALUE;
            goto L17; // [580] 765
        }
        _31493 = NOVALUE;
    }
    _31493 = NOVALUE;

    /** fwdref.e:649						integer start_pc = pc*/
    _start_pc_64099 = _pc_64015;

    /** fwdref.e:652						if SymTab[SymTab[which_type][S_NEXT]][S_VTYPE] = integer_type then*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _31494 = (object)*(((s1_ptr)_2)->base + _which_type_63980);
    _2 = (object)SEQ_PTR(_31494);
    _31495 = (object)*(((s1_ptr)_2)->base + 2);
    _31494 = NOVALUE;
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!IS_ATOM_INT(_31495)){
        _31496 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31495)->dbl));
    }
    else{
        _31496 = (object)*(((s1_ptr)_2)->base + _31495);
    }
    _2 = (object)SEQ_PTR(_31496);
    _31497 = (object)*(((s1_ptr)_2)->base + 15);
    _31496 = NOVALUE;
    if (binary_op_a(NOTEQ, _31497, _54integer_type_47142)){
        _31497 = NOVALUE;
        goto L18; // [616] 672
    }
    _31497 = NOVALUE;

    /** fwdref.e:654							insert_code( { INTEGER_CHECK, var }, pc, fr[FR_SUBPROG] )*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 96;
    ((intptr_t *)_2)[2] = _var_63982;
    _31499 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_fr_63977);
    _31500 = (object)*(((s1_ptr)_2)->base + 4);
    DeRefi(_code_inlined_insert_code_at_644_64115);
    _code_inlined_insert_code_at_644_64115 = _31499;
    _31499 = NOVALUE;
    Ref(_31500);
    DeRef(_subprog_inlined_insert_code_at_647_64116);
    _subprog_inlined_insert_code_at_647_64116 = _31500;
    _31500 = NOVALUE;
    if (!IS_ATOM_INT(_subprog_inlined_insert_code_at_647_64116)) {
        _1 = (object)(DBL_PTR(_subprog_inlined_insert_code_at_647_64116)->dbl);
        DeRefDS(_subprog_inlined_insert_code_at_647_64116);
        _subprog_inlined_insert_code_at_647_64116 = _1;
    }

    /** fwdref.e:82		shifting_sub = subprog*/
    _44shifting_sub_63216 = _subprog_inlined_insert_code_at_647_64116;

    /** fwdref.e:83		shift:insert_code( code, index )*/
    RefDS(_code_inlined_insert_code_at_644_64115);
    _66insert_code(_code_inlined_insert_code_at_644_64115, _pc_64015);

    /** fwdref.e:84		shifting_sub = 0*/
    _44shifting_sub_63216 = 0;

    /** fwdref.e:85	end procedure*/
    goto L19; // [660] 663
L19: 
    DeRefi(_code_inlined_insert_code_at_644_64115);
    _code_inlined_insert_code_at_644_64115 = NOVALUE;
    DeRef(_subprog_inlined_insert_code_at_647_64116);
    _subprog_inlined_insert_code_at_647_64116 = NOVALUE;

    /** fwdref.e:656							pc += 2*/
    _pc_64015 = _pc_64015 + 2;
L18: 

    /** fwdref.e:658						symtab_index c = NewTempSym()*/
    _c_64119 = _54NewTempSym(0);
    if (!IS_ATOM_INT(_c_64119)) {
        _1 = (object)(DBL_PTR(_c_64119)->dbl);
        DeRefDS(_c_64119);
        _c_64119 = _1;
    }

    /** fwdref.e:659						SymTab[fr[FR_SUBPROG]][S_STACK_SPACE] += 1*/
    _2 = (object)SEQ_PTR(_fr_63977);
    _31503 = (object)*(((s1_ptr)_2)->base + 4);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_31503))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_31503)->dbl));
    else
    _3 = (object)(_31503 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!IS_ATOM_INT(_36S_STACK_SPACE_21464)){
        _31506 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_STACK_SPACE_21464)->dbl));
    }
    else{
        _31506 = (object)*(((s1_ptr)_2)->base + _36S_STACK_SPACE_21464);
    }
    _31504 = NOVALUE;
    if (IS_ATOM_INT(_31506)) {
        _31507 = _31506 + 1;
        if (_31507 > MAXINT){
            _31507 = NewDouble((eudouble)_31507);
        }
    }
    else
    _31507 = binary_op(PLUS, 1, _31506);
    _31506 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_STACK_SPACE_21464))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_STACK_SPACE_21464)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_STACK_SPACE_21464);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31507;
    if( _1 != _31507 ){
        DeRef(_1);
    }
    _31507 = NOVALUE;
    _31504 = NOVALUE;

    /** fwdref.e:660						insert_code( { PROC, which_type, var, c, TYPE_CHECK }, pc, fr[FR_SUBPROG] )*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 27;
    ((intptr_t*)_2)[2] = _which_type_63980;
    ((intptr_t*)_2)[3] = _var_63982;
    ((intptr_t*)_2)[4] = _c_64119;
    ((intptr_t*)_2)[5] = 65;
    _31508 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_fr_63977);
    _31509 = (object)*(((s1_ptr)_2)->base + 4);
    DeRefi(_code_inlined_insert_code_at_738_64134);
    _code_inlined_insert_code_at_738_64134 = _31508;
    _31508 = NOVALUE;
    Ref(_31509);
    DeRef(_subprog_inlined_insert_code_at_741_64135);
    _subprog_inlined_insert_code_at_741_64135 = _31509;
    _31509 = NOVALUE;
    if (!IS_ATOM_INT(_subprog_inlined_insert_code_at_741_64135)) {
        _1 = (object)(DBL_PTR(_subprog_inlined_insert_code_at_741_64135)->dbl);
        DeRefDS(_subprog_inlined_insert_code_at_741_64135);
        _subprog_inlined_insert_code_at_741_64135 = _1;
    }

    /** fwdref.e:82		shifting_sub = subprog*/
    _44shifting_sub_63216 = _subprog_inlined_insert_code_at_741_64135;

    /** fwdref.e:83		shift:insert_code( code, index )*/
    RefDS(_code_inlined_insert_code_at_738_64134);
    _66insert_code(_code_inlined_insert_code_at_738_64134, _pc_64015);

    /** fwdref.e:84		shifting_sub = 0*/
    _44shifting_sub_63216 = 0;

    /** fwdref.e:85	end procedure*/
    goto L1A; // [753] 756
L1A: 
    DeRefi(_code_inlined_insert_code_at_738_64134);
    _code_inlined_insert_code_at_738_64134 = NOVALUE;
    DeRef(_subprog_inlined_insert_code_at_741_64135);
    _subprog_inlined_insert_code_at_741_64135 = NOVALUE;

    /** fwdref.e:661						pc += 4*/
    _pc_64015 = _pc_64015 + 4;
L17: 
L12: 
LF: 
LD: 
LA: 

    /** fwdref.e:668		if (TRANSLATE or not with_type_check) and SymTab[which_type][S_NEXT] then*/
    if (_36TRANSLATE_21369 != 0) {
        _31511 = 1;
        goto L1B; // [775] 786
    }
    _31512 = (_with_type_check_64017 == 0);
    _31511 = (_31512 != 0);
L1B: 
    if (_31511 == 0) {
        goto L1C; // [786] 1013
    }
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _31514 = (object)*(((s1_ptr)_2)->base + _which_type_63980);
    _2 = (object)SEQ_PTR(_31514);
    _31515 = (object)*(((s1_ptr)_2)->base + 2);
    _31514 = NOVALUE;
    if (_31515 == 0) {
        _31515 = NOVALUE;
        goto L1C; // [803] 1013
    }
    else {
        if (!IS_ATOM_INT(_31515) && DBL_PTR(_31515)->dbl == 0.0){
            _31515 = NOVALUE;
            goto L1C; // [803] 1013
        }
        _31515 = NOVALUE;
    }
    _31515 = NOVALUE;

    /** fwdref.e:669			integer start_pc = pc*/
    _start_pc_64146 = _pc_64015;

    /** fwdref.e:671			if which_type = sequence_type or*/
    _31516 = (_which_type_63980 == _54sequence_type_47140);
    if (_31516 != 0) {
        goto L1D; // [819] 858
    }
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _31518 = (object)*(((s1_ptr)_2)->base + _which_type_63980);
    _2 = (object)SEQ_PTR(_31518);
    _31519 = (object)*(((s1_ptr)_2)->base + 2);
    _31518 = NOVALUE;
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!IS_ATOM_INT(_31519)){
        _31520 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31519)->dbl));
    }
    else{
        _31520 = (object)*(((s1_ptr)_2)->base + _31519);
    }
    _2 = (object)SEQ_PTR(_31520);
    _31521 = (object)*(((s1_ptr)_2)->base + 15);
    _31520 = NOVALUE;
    if (IS_ATOM_INT(_31521)) {
        _31522 = (_31521 == _54sequence_type_47140);
    }
    else {
        _31522 = binary_op(EQUALS, _31521, _54sequence_type_47140);
    }
    _31521 = NOVALUE;
    if (_31522 == 0) {
        DeRef(_31522);
        _31522 = NOVALUE;
        goto L1E; // [854] 912
    }
    else {
        if (!IS_ATOM_INT(_31522) && DBL_PTR(_31522)->dbl == 0.0){
            DeRef(_31522);
            _31522 = NOVALUE;
            goto L1E; // [854] 912
        }
        DeRef(_31522);
        _31522 = NOVALUE;
    }
    DeRef(_31522);
    _31522 = NOVALUE;
L1D: 

    /** fwdref.e:674				insert_code( { SEQUENCE_CHECK, var }, pc, fr[FR_SUBPROG] )*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 97;
    ((intptr_t *)_2)[2] = _var_63982;
    _31523 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_fr_63977);
    _31524 = (object)*(((s1_ptr)_2)->base + 4);
    DeRefi(_code_inlined_insert_code_at_883_64165);
    _code_inlined_insert_code_at_883_64165 = _31523;
    _31523 = NOVALUE;
    Ref(_31524);
    DeRef(_subprog_inlined_insert_code_at_886_64166);
    _subprog_inlined_insert_code_at_886_64166 = _31524;
    _31524 = NOVALUE;
    if (!IS_ATOM_INT(_subprog_inlined_insert_code_at_886_64166)) {
        _1 = (object)(DBL_PTR(_subprog_inlined_insert_code_at_886_64166)->dbl);
        DeRefDS(_subprog_inlined_insert_code_at_886_64166);
        _subprog_inlined_insert_code_at_886_64166 = _1;
    }

    /** fwdref.e:82		shifting_sub = subprog*/
    _44shifting_sub_63216 = _subprog_inlined_insert_code_at_886_64166;

    /** fwdref.e:83		shift:insert_code( code, index )*/
    RefDS(_code_inlined_insert_code_at_883_64165);
    _66insert_code(_code_inlined_insert_code_at_883_64165, _pc_64015);

    /** fwdref.e:84		shifting_sub = 0*/
    _44shifting_sub_63216 = 0;

    /** fwdref.e:85	end procedure*/
    goto L1F; // [898] 901
L1F: 
    DeRefi(_code_inlined_insert_code_at_883_64165);
    _code_inlined_insert_code_at_883_64165 = NOVALUE;
    DeRef(_subprog_inlined_insert_code_at_886_64166);
    _subprog_inlined_insert_code_at_886_64166 = NOVALUE;

    /** fwdref.e:675				pc += 2*/
    _pc_64015 = _pc_64015 + 2;
    goto L20; // [909] 1012
L1E: 

    /** fwdref.e:677			elsif which_type = integer_type or*/
    _31526 = (_which_type_63980 == _54integer_type_47142);
    if (_31526 != 0) {
        goto L21; // [920] 959
    }
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _31528 = (object)*(((s1_ptr)_2)->base + _which_type_63980);
    _2 = (object)SEQ_PTR(_31528);
    _31529 = (object)*(((s1_ptr)_2)->base + 2);
    _31528 = NOVALUE;
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!IS_ATOM_INT(_31529)){
        _31530 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31529)->dbl));
    }
    else{
        _31530 = (object)*(((s1_ptr)_2)->base + _31529);
    }
    _2 = (object)SEQ_PTR(_31530);
    _31531 = (object)*(((s1_ptr)_2)->base + 15);
    _31530 = NOVALUE;
    if (IS_ATOM_INT(_31531)) {
        _31532 = (_31531 == _54integer_type_47142);
    }
    else {
        _31532 = binary_op(EQUALS, _31531, _54integer_type_47142);
    }
    _31531 = NOVALUE;
    if (_31532 == 0) {
        DeRef(_31532);
        _31532 = NOVALUE;
        goto L22; // [955] 1011
    }
    else {
        if (!IS_ATOM_INT(_31532) && DBL_PTR(_31532)->dbl == 0.0){
            DeRef(_31532);
            _31532 = NOVALUE;
            goto L22; // [955] 1011
        }
        DeRef(_31532);
        _31532 = NOVALUE;
    }
    DeRef(_31532);
    _31532 = NOVALUE;
L21: 

    /** fwdref.e:680				insert_code( { INTEGER_CHECK, var }, pc, fr[FR_SUBPROG] )*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 96;
    ((intptr_t *)_2)[2] = _var_63982;
    _31533 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_fr_63977);
    _31534 = (object)*(((s1_ptr)_2)->base + 4);
    DeRefi(_code_inlined_insert_code_at_984_64186);
    _code_inlined_insert_code_at_984_64186 = _31533;
    _31533 = NOVALUE;
    Ref(_31534);
    DeRef(_subprog_inlined_insert_code_at_987_64187);
    _subprog_inlined_insert_code_at_987_64187 = _31534;
    _31534 = NOVALUE;
    if (!IS_ATOM_INT(_subprog_inlined_insert_code_at_987_64187)) {
        _1 = (object)(DBL_PTR(_subprog_inlined_insert_code_at_987_64187)->dbl);
        DeRefDS(_subprog_inlined_insert_code_at_987_64187);
        _subprog_inlined_insert_code_at_987_64187 = _1;
    }

    /** fwdref.e:82		shifting_sub = subprog*/
    _44shifting_sub_63216 = _subprog_inlined_insert_code_at_987_64187;

    /** fwdref.e:83		shift:insert_code( code, index )*/
    RefDS(_code_inlined_insert_code_at_984_64186);
    _66insert_code(_code_inlined_insert_code_at_984_64186, _pc_64015);

    /** fwdref.e:84		shifting_sub = 0*/
    _44shifting_sub_63216 = 0;

    /** fwdref.e:85	end procedure*/
    goto L23; // [999] 1002
L23: 
    DeRefi(_code_inlined_insert_code_at_984_64186);
    _code_inlined_insert_code_at_984_64186 = NOVALUE;
    DeRef(_subprog_inlined_insert_code_at_987_64187);
    _subprog_inlined_insert_code_at_987_64187 = NOVALUE;

    /** fwdref.e:681				pc += 4*/
    _pc_64015 = _pc_64015 + 4;
L22: 
L20: 
L1C: 

    /** fwdref.e:686		resolved_reference( ref )*/
    _44resolved_reference(_ref_63976);

    /** fwdref.e:687		reset_code()*/
    _44reset_code();

    /** fwdref.e:688	end procedure*/
    DeRef(_tok_63975);
    DeRef(_fr_63977);
    _31503 = NOVALUE;
    _31529 = NOVALUE;
    DeRef(_31516);
    _31516 = NOVALUE;
    DeRef(_31467);
    _31467 = NOVALUE;
    DeRef(_31462);
    _31462 = NOVALUE;
    DeRef(_31512);
    _31512 = NOVALUE;
    DeRef(_31526);
    _31526 = NOVALUE;
    _31495 = NOVALUE;
    _31449 = NOVALUE;
    _31519 = NOVALUE;
    return;
    ;
}


void _44prep_forward_error(object _ref_64191)
{
    object _31542 = NOVALUE;
    object _31540 = NOVALUE;
    object _31538 = NOVALUE;
    object _31536 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_ref_64191)) {
        _1 = (object)(DBL_PTR(_ref_64191)->dbl);
        DeRefDS(_ref_64191);
        _ref_64191 = _1;
    }

    /** fwdref.e:691		ThisLine = forward_references[ref][FR_THISLINE]*/
    _2 = (object)SEQ_PTR(_44forward_references_63197);
    _31536 = (object)*(((s1_ptr)_2)->base + _ref_64191);
    DeRef(_50ThisLine_49594);
    _2 = (object)SEQ_PTR(_31536);
    _50ThisLine_49594 = (object)*(((s1_ptr)_2)->base + 7);
    Ref(_50ThisLine_49594);
    _31536 = NOVALUE;

    /** fwdref.e:692		bp = forward_references[ref][FR_BP]*/
    _2 = (object)SEQ_PTR(_44forward_references_63197);
    _31538 = (object)*(((s1_ptr)_2)->base + _ref_64191);
    _2 = (object)SEQ_PTR(_31538);
    _50bp_49598 = (object)*(((s1_ptr)_2)->base + 8);
    if (!IS_ATOM_INT(_50bp_49598)){
        _50bp_49598 = (object)DBL_PTR(_50bp_49598)->dbl;
    }
    _31538 = NOVALUE;

    /** fwdref.e:693		line_number = forward_references[ref][FR_LINE]*/
    _2 = (object)SEQ_PTR(_44forward_references_63197);
    _31540 = (object)*(((s1_ptr)_2)->base + _ref_64191);
    _2 = (object)SEQ_PTR(_31540);
    _36line_number_21768 = (object)*(((s1_ptr)_2)->base + 6);
    if (!IS_ATOM_INT(_36line_number_21768)){
        _36line_number_21768 = (object)DBL_PTR(_36line_number_21768)->dbl;
    }
    _31540 = NOVALUE;

    /** fwdref.e:694		current_file_no = forward_references[ref][FR_FILE]*/
    _2 = (object)SEQ_PTR(_44forward_references_63197);
    _31542 = (object)*(((s1_ptr)_2)->base + _ref_64191);
    _2 = (object)SEQ_PTR(_31542);
    _36current_file_no_21767 = (object)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_36current_file_no_21767)){
        _36current_file_no_21767 = (object)DBL_PTR(_36current_file_no_21767)->dbl;
    }
    _31542 = NOVALUE;

    /** fwdref.e:695	end procedure*/
    return;
    ;
}


void _44forward_error(object _tok_64207, object _ref_64208)
{
    object _31549 = NOVALUE;
    object _31548 = NOVALUE;
    object _31547 = NOVALUE;
    object _31546 = NOVALUE;
    object _31545 = NOVALUE;
    object _31544 = NOVALUE;
    object _0, _1, _2;
    

    /** fwdref.e:698		prep_forward_error( ref )*/
    _44prep_forward_error(_ref_64208);

    /** fwdref.e:699		CompileErr(EXPECTED_1_NOT_2, { expected_name( forward_references[ref][FR_TYPE] ),*/
    _2 = (object)SEQ_PTR(_44forward_references_63197);
    _31544 = (object)*(((s1_ptr)_2)->base + _ref_64208);
    _2 = (object)SEQ_PTR(_31544);
    _31545 = (object)*(((s1_ptr)_2)->base + 1);
    _31544 = NOVALUE;
    Ref(_31545);
    _31546 = _44expected_name(_31545);
    _31545 = NOVALUE;
    _2 = (object)SEQ_PTR(_tok_64207);
    _31547 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_31547);
    _31548 = _44expected_name(_31547);
    _31547 = NOVALUE;
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _31546;
    ((intptr_t *)_2)[2] = _31548;
    _31549 = MAKE_SEQ(_1);
    _31548 = NOVALUE;
    _31546 = NOVALUE;
    _50CompileErr(68, _31549, 0);
    _31549 = NOVALUE;

    /** fwdref.e:701	end procedure*/
    DeRef(_tok_64207);
    return;
    ;
}


object _44find_reference(object _fr_64220)
{
    object _name_64221 = NOVALUE;
    object _file_64223 = NOVALUE;
    object _ns_file_64225 = NOVALUE;
    object _ix_64226 = NOVALUE;
    object _ns_64229 = NOVALUE;
    object _ns_tok_64233 = NOVALUE;
    object _tok_64245 = NOVALUE;
    object _31560 = NOVALUE;
    object _31557 = NOVALUE;
    object _31555 = NOVALUE;
    object _31553 = NOVALUE;
    object _0, _1, _2;
    

    /** fwdref.e:706		sequence name = fr[FR_NAME]*/
    DeRef(_name_64221);
    _2 = (object)SEQ_PTR(_fr_64220);
    _name_64221 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_name_64221);

    /** fwdref.e:707		integer file  = fr[FR_FILE]*/
    _2 = (object)SEQ_PTR(_fr_64220);
    _file_64223 = (object)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_file_64223))
    _file_64223 = (object)DBL_PTR(_file_64223)->dbl;

    /** fwdref.e:709		integer ns_file = -1*/
    _ns_file_64225 = -1;

    /** fwdref.e:710		integer ix = find( ':', name )*/
    _ix_64226 = find_from(58, _name_64221, 1);

    /** fwdref.e:711		if ix then*/
    if (_ix_64226 == 0)
    {
        goto L1; // [31] 85
    }
    else{
    }

    /** fwdref.e:712			sequence ns = name[1..ix-1]*/
    _31553 = _ix_64226 - 1;
    rhs_slice_target = (object_ptr)&_ns_64229;
    RHS_Slice(_name_64221, 1, _31553);

    /** fwdref.e:713			token ns_tok = keyfind( ns, ns_file, file, 1, fr[FR_HASHVAL] )*/
    _2 = (object)SEQ_PTR(_fr_64220);
    _31555 = (object)*(((s1_ptr)_2)->base + 11);
    RefDS(_ns_64229);
    Ref(_31555);
    _0 = _ns_tok_64233;
    _ns_tok_64233 = _54keyfind(_ns_64229, -1, _file_64223, 1, _31555);
    DeRef(_0);
    _31555 = NOVALUE;

    /** fwdref.e:714			if ns_tok[T_ID] != NAMESPACE then*/
    _2 = (object)SEQ_PTR(_ns_tok_64233);
    _31557 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _31557, 523)){
        _31557 = NOVALUE;
        goto L2; // [69] 80
    }
    _31557 = NOVALUE;

    /** fwdref.e:715				return ns_tok*/
    DeRefDS(_ns_64229);
    DeRefDS(_fr_64220);
    DeRefDS(_name_64221);
    DeRef(_tok_64245);
    _31553 = NOVALUE;
    return _ns_tok_64233;
L2: 
    DeRef(_ns_64229);
    _ns_64229 = NOVALUE;
    DeRef(_ns_tok_64233);
    _ns_tok_64233 = NOVALUE;
    goto L3; // [82] 92
L1: 

    /** fwdref.e:718			ns_file = fr[FR_QUALIFIED]*/
    _2 = (object)SEQ_PTR(_fr_64220);
    _ns_file_64225 = (object)*(((s1_ptr)_2)->base + 9);
    if (!IS_ATOM_INT(_ns_file_64225))
    _ns_file_64225 = (object)DBL_PTR(_ns_file_64225)->dbl;
L3: 

    /** fwdref.e:721		No_new_entry = 1*/
    _54No_new_entry_48334 = 1;

    /** fwdref.e:722		object tok = keyfind( name, ns_file, file, , fr[FR_HASHVAL] )*/
    _2 = (object)SEQ_PTR(_fr_64220);
    _31560 = (object)*(((s1_ptr)_2)->base + 11);
    RefDS(_name_64221);
    Ref(_31560);
    _0 = _tok_64245;
    _tok_64245 = _54keyfind(_name_64221, _ns_file_64225, _file_64223, 0, _31560);
    DeRef(_0);
    _31560 = NOVALUE;

    /** fwdref.e:723		No_new_entry = 0*/
    _54No_new_entry_48334 = 0;

    /** fwdref.e:724		return tok*/
    DeRefDS(_fr_64220);
    DeRefDS(_name_64221);
    DeRef(_31553);
    _31553 = NOVALUE;
    return _tok_64245;
    ;
}


void _44register_forward_type(object _sym_64253, object _ref_64254)
{
    object _31567 = NOVALUE;
    object _31566 = NOVALUE;
    object _31564 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** fwdref.e:729		if ref < 0 then*/
    if (_ref_64254 >= 0)
    goto L1; // [7] 19

    /** fwdref.e:730			ref = -ref*/
    _ref_64254 = - _ref_64254;
L1: 

    /** fwdref.e:732		forward_references[ref][FR_DATA] &= sym*/
    _2 = (object)SEQ_PTR(_44forward_references_63197);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44forward_references_63197 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_64254 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _31566 = (object)*(((s1_ptr)_2)->base + 12);
    _31564 = NOVALUE;
    if (IS_SEQUENCE(_31566) && IS_ATOM(_sym_64253)) {
        Append(&_31567, _31566, _sym_64253);
    }
    else if (IS_ATOM(_31566) && IS_SEQUENCE(_sym_64253)) {
    }
    else {
        Concat((object_ptr)&_31567, _31566, _sym_64253);
        _31566 = NOVALUE;
    }
    _31566 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31567;
    if( _1 != _31567 ){
        DeRef(_1);
    }
    _31567 = NOVALUE;
    _31564 = NOVALUE;

    /** fwdref.e:733	end procedure*/
    return;
    ;
}


object _44new_forward_reference(object _fwd_op_64284, object _sym_64286, object _op_64287)
{
    object _ref_64288 = NOVALUE;
    object _len_64289 = NOVALUE;
    object _hashval_64319 = NOVALUE;
    object _default_sym_64394 = NOVALUE;
    object _param_64397 = NOVALUE;
    object _set_data_2__tmp_at578_64414 = NOVALUE;
    object _set_data_1__tmp_at578_64413 = NOVALUE;
    object _data_inlined_set_data_at_575_64412 = NOVALUE;
    object _31653 = NOVALUE;
    object _31652 = NOVALUE;
    object _31651 = NOVALUE;
    object _31648 = NOVALUE;
    object _31646 = NOVALUE;
    object _31645 = NOVALUE;
    object _31643 = NOVALUE;
    object _31642 = NOVALUE;
    object _31641 = NOVALUE;
    object _31639 = NOVALUE;
    object _31637 = NOVALUE;
    object _31635 = NOVALUE;
    object _31632 = NOVALUE;
    object _31631 = NOVALUE;
    object _31629 = NOVALUE;
    object _31627 = NOVALUE;
    object _31625 = NOVALUE;
    object _31623 = NOVALUE;
    object _31622 = NOVALUE;
    object _31621 = NOVALUE;
    object _31619 = NOVALUE;
    object _31616 = NOVALUE;
    object _31614 = NOVALUE;
    object _31612 = NOVALUE;
    object _31611 = NOVALUE;
    object _31610 = NOVALUE;
    object _31609 = NOVALUE;
    object _31607 = NOVALUE;
    object _31604 = NOVALUE;
    object _31603 = NOVALUE;
    object _31602 = NOVALUE;
    object _31600 = NOVALUE;
    object _31599 = NOVALUE;
    object _31598 = NOVALUE;
    object _31597 = NOVALUE;
    object _31595 = NOVALUE;
    object _31594 = NOVALUE;
    object _31593 = NOVALUE;
    object _31592 = NOVALUE;
    object _31590 = NOVALUE;
    object _31587 = NOVALUE;
    object _31586 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_sym_64286)) {
        _1 = (object)(DBL_PTR(_sym_64286)->dbl);
        DeRefDS(_sym_64286);
        _sym_64286 = _1;
    }

    /** fwdref.e:754			len = length( inactive_references )*/
    if (IS_SEQUENCE(_44inactive_references_63201)){
            _len_64289 = SEQ_PTR(_44inactive_references_63201)->length;
    }
    else {
        _len_64289 = 1;
    }

    /** fwdref.e:757		if len then*/
    if (_len_64289 == 0)
    {
        goto L1; // [16] 39
    }
    else{
    }

    /** fwdref.e:758			ref = inactive_references[len]*/
    _2 = (object)SEQ_PTR(_44inactive_references_63201);
    _ref_64288 = (object)*(((s1_ptr)_2)->base + _len_64289);
    if (!IS_ATOM_INT(_ref_64288))
    _ref_64288 = (object)DBL_PTR(_ref_64288)->dbl;

    /** fwdref.e:759			inactive_references = remove( inactive_references, len, len )*/
    {
        s1_ptr assign_space = SEQ_PTR(_44inactive_references_63201);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_len_64289)) ? _len_64289 : (object)(DBL_PTR(_len_64289)->dbl);
        int stop = (IS_ATOM_INT(_len_64289)) ? _len_64289 : (object)(DBL_PTR(_len_64289)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_44inactive_references_63201), start, &_44inactive_references_63201 );
            }
            else Tail(SEQ_PTR(_44inactive_references_63201), stop+1, &_44inactive_references_63201);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_44inactive_references_63201), start, &_44inactive_references_63201);
        }
        else {
            assign_slice_seq = &assign_space;
            _44inactive_references_63201 = Remove_elements(start, stop, (SEQ_PTR(_44inactive_references_63201)->ref == 1));
        }
    }
    goto L2; // [36] 55
L1: 

    /** fwdref.e:761			forward_references &= 0*/
    Append(&_44forward_references_63197, _44forward_references_63197, 0);

    /** fwdref.e:762			ref = length( forward_references )*/
    if (IS_SEQUENCE(_44forward_references_63197)){
            _ref_64288 = SEQ_PTR(_44forward_references_63197)->length;
    }
    else {
        _ref_64288 = 1;
    }
L2: 

    /** fwdref.e:764		forward_references[ref] = repeat( 0, FR_SIZE )*/
    _31586 = Repeat(0, 12);
    _2 = (object)SEQ_PTR(_44forward_references_63197);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44forward_references_63197 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _ref_64288);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31586;
    if( _1 != _31586 ){
        DeRef(_1);
    }
    _31586 = NOVALUE;

    /** fwdref.e:766		forward_references[ref][FR_TYPE]      = fwd_op*/
    _2 = (object)SEQ_PTR(_44forward_references_63197);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44forward_references_63197 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_64288 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _fwd_op_64284;
    DeRef(_1);
    _31587 = NOVALUE;

    /** fwdref.e:767		if sym < 0 then*/
    if (_sym_64286 >= 0)
    goto L3; // [84] 143

    /** fwdref.e:768			forward_references[ref][FR_NAME] = forward_references[-sym][FR_NAME]*/
    _2 = (object)SEQ_PTR(_44forward_references_63197);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44forward_references_63197 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_64288 + ((s1_ptr)_2)->base);
    if ((uintptr_t)_sym_64286 == (uintptr_t)HIGH_BITS){
        _31592 = (object)NewDouble((eudouble) -HIGH_BITS);
    }
    else{
        _31592 = - _sym_64286;
    }
    _2 = (object)SEQ_PTR(_44forward_references_63197);
    if (!IS_ATOM_INT(_31592)){
        _31593 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31592)->dbl));
    }
    else{
        _31593 = (object)*(((s1_ptr)_2)->base + _31592);
    }
    _2 = (object)SEQ_PTR(_31593);
    _31594 = (object)*(((s1_ptr)_2)->base + 2);
    _31593 = NOVALUE;
    Ref(_31594);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31594;
    if( _1 != _31594 ){
        DeRef(_1);
    }
    _31594 = NOVALUE;
    _31590 = NOVALUE;

    /** fwdref.e:769			forward_references[ref][FR_HASHVAL] = forward_references[-sym][FR_HASHVAL]*/
    _2 = (object)SEQ_PTR(_44forward_references_63197);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44forward_references_63197 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_64288 + ((s1_ptr)_2)->base);
    if ((uintptr_t)_sym_64286 == (uintptr_t)HIGH_BITS){
        _31597 = (object)NewDouble((eudouble) -HIGH_BITS);
    }
    else{
        _31597 = - _sym_64286;
    }
    _2 = (object)SEQ_PTR(_44forward_references_63197);
    if (!IS_ATOM_INT(_31597)){
        _31598 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31597)->dbl));
    }
    else{
        _31598 = (object)*(((s1_ptr)_2)->base + _31597);
    }
    _2 = (object)SEQ_PTR(_31598);
    _31599 = (object)*(((s1_ptr)_2)->base + 11);
    _31598 = NOVALUE;
    Ref(_31599);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 11);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31599;
    if( _1 != _31599 ){
        DeRef(_1);
    }
    _31599 = NOVALUE;
    _31595 = NOVALUE;
    goto L4; // [140] 242
L3: 

    /** fwdref.e:771			forward_references[ref][FR_NAME] = SymTab[sym][S_NAME]*/
    _2 = (object)SEQ_PTR(_44forward_references_63197);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44forward_references_63197 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_64288 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _31602 = (object)*(((s1_ptr)_2)->base + _sym_64286);
    _2 = (object)SEQ_PTR(_31602);
    if (!IS_ATOM_INT(_36S_NAME_21404)){
        _31603 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21404)->dbl));
    }
    else{
        _31603 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21404);
    }
    _31602 = NOVALUE;
    Ref(_31603);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31603;
    if( _1 != _31603 ){
        DeRef(_1);
    }
    _31603 = NOVALUE;
    _31600 = NOVALUE;

    /** fwdref.e:772			integer hashval = SymTab[sym][S_HASHVAL]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _31604 = (object)*(((s1_ptr)_2)->base + _sym_64286);
    _2 = (object)SEQ_PTR(_31604);
    _hashval_64319 = (object)*(((s1_ptr)_2)->base + 11);
    if (!IS_ATOM_INT(_hashval_64319)){
        _hashval_64319 = (object)DBL_PTR(_hashval_64319)->dbl;
    }
    _31604 = NOVALUE;

    /** fwdref.e:773			if 0 = hashval then*/
    if (0 != _hashval_64319)
    goto L5; // [186] 220

    /** fwdref.e:774				forward_references[ref][FR_HASHVAL] = hashfn( forward_references[ref][FR_NAME] )*/
    _2 = (object)SEQ_PTR(_44forward_references_63197);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44forward_references_63197 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_64288 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_44forward_references_63197);
    _31609 = (object)*(((s1_ptr)_2)->base + _ref_64288);
    _2 = (object)SEQ_PTR(_31609);
    _31610 = (object)*(((s1_ptr)_2)->base + 2);
    _31609 = NOVALUE;
    Ref(_31610);
    _31611 = _54hashfn(_31610);
    _31610 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 11);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31611;
    if( _1 != _31611 ){
        DeRef(_1);
    }
    _31611 = NOVALUE;
    _31607 = NOVALUE;
    goto L6; // [217] 239
L5: 

    /** fwdref.e:776				forward_references[ref][FR_HASHVAL] = hashval*/
    _2 = (object)SEQ_PTR(_44forward_references_63197);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44forward_references_63197 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_64288 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 11);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _hashval_64319;
    DeRef(_1);
    _31612 = NOVALUE;

    /** fwdref.e:777				remove_symbol( sym )*/
    _54remove_symbol(_sym_64286);
L6: 
L4: 

    /** fwdref.e:782		forward_references[ref][FR_FILE]      = current_file_no*/
    _2 = (object)SEQ_PTR(_44forward_references_63197);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44forward_references_63197 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_64288 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36current_file_no_21767;
    DeRef(_1);
    _31614 = NOVALUE;

    /** fwdref.e:783		forward_references[ref][FR_SUBPROG]   = CurrentSub*/
    _2 = (object)SEQ_PTR(_44forward_references_63197);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44forward_references_63197 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_64288 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36CurrentSub_21775;
    DeRef(_1);
    _31616 = NOVALUE;

    /** fwdref.e:785		if fwd_op != TYPE then*/
    if (_fwd_op_64284 == 504)
    goto L7; // [276] 303

    /** fwdref.e:786			forward_references[ref][FR_PC]        = length( Code ) + 1*/
    _2 = (object)SEQ_PTR(_44forward_references_63197);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44forward_references_63197 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_64288 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_36Code_21859)){
            _31621 = SEQ_PTR(_36Code_21859)->length;
    }
    else {
        _31621 = 1;
    }
    _31622 = _31621 + 1;
    _31621 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31622;
    if( _1 != _31622 ){
        DeRef(_1);
    }
    _31622 = NOVALUE;
    _31619 = NOVALUE;
L7: 

    /** fwdref.e:789		forward_references[ref][FR_LINE]      = fwd_line_number*/
    _2 = (object)SEQ_PTR(_44forward_references_63197);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44forward_references_63197 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_64288 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 6);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36fwd_line_number_21769;
    DeRef(_1);
    _31623 = NOVALUE;

    /** fwdref.e:790		forward_references[ref][FR_THISLINE]  = ForwardLine*/
    _2 = (object)SEQ_PTR(_44forward_references_63197);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44forward_references_63197 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_64288 + ((s1_ptr)_2)->base);
    Ref(_50ForwardLine_49595);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 7);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _50ForwardLine_49595;
    DeRef(_1);
    _31625 = NOVALUE;

    /** fwdref.e:791		forward_references[ref][FR_BP]        = forward_bp*/
    _2 = (object)SEQ_PTR(_44forward_references_63197);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44forward_references_63197 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_64288 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 8);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _50forward_bp_49599;
    DeRef(_1);
    _31627 = NOVALUE;

    /** fwdref.e:792		forward_references[ref][FR_QUALIFIED] = get_qualified_fwd()*/
    _2 = (object)SEQ_PTR(_44forward_references_63197);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44forward_references_63197 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_64288 + ((s1_ptr)_2)->base);
    _31631 = _62get_qualified_fwd();
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 9);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31631;
    if( _1 != _31631 ){
        DeRef(_1);
    }
    _31631 = NOVALUE;
    _31629 = NOVALUE;

    /** fwdref.e:793		forward_references[ref][FR_OP]        = op*/
    _2 = (object)SEQ_PTR(_44forward_references_63197);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44forward_references_63197 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_64288 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 10);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _op_64287;
    DeRef(_1);
    _31632 = NOVALUE;

    /** fwdref.e:795		if op = GOTO then*/
    if (_op_64287 != 188)
    goto L8; // [381] 403

    /** fwdref.e:796			forward_references[ref][FR_DATA] = { sym }*/
    _2 = (object)SEQ_PTR(_44forward_references_63197);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44forward_references_63197 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_64288 + ((s1_ptr)_2)->base);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _sym_64286;
    _31637 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31637;
    if( _1 != _31637 ){
        DeRef(_1);
    }
    _31637 = NOVALUE;
    _31635 = NOVALUE;
L8: 

    /** fwdref.e:803		if CurrentSub = TopLevelSub then*/
    if (_36CurrentSub_21775 != _36TopLevelSub_21774)
    goto L9; // [409] 471

    /** fwdref.e:804			if length( toplevel_references ) < current_file_no then*/
    if (IS_SEQUENCE(_44toplevel_references_63200)){
            _31639 = SEQ_PTR(_44toplevel_references_63200)->length;
    }
    else {
        _31639 = 1;
    }
    if (_31639 >= _36current_file_no_21767)
    goto LA; // [422] 450

    /** fwdref.e:805				toplevel_references &= repeat( {}, current_file_no - length( toplevel_references ) )*/
    if (IS_SEQUENCE(_44toplevel_references_63200)){
            _31641 = SEQ_PTR(_44toplevel_references_63200)->length;
    }
    else {
        _31641 = 1;
    }
    _31642 = _36current_file_no_21767 - _31641;
    _31641 = NOVALUE;
    _31643 = Repeat(_22190, _31642);
    _31642 = NOVALUE;
    Concat((object_ptr)&_44toplevel_references_63200, _44toplevel_references_63200, _31643);
    DeRefDS(_31643);
    _31643 = NOVALUE;
LA: 

    /** fwdref.e:807			toplevel_references[current_file_no] &= ref*/
    _2 = (object)SEQ_PTR(_44toplevel_references_63200);
    _31645 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21767);
    if (IS_SEQUENCE(_31645) && IS_ATOM(_ref_64288)) {
        Append(&_31646, _31645, _ref_64288);
    }
    else if (IS_ATOM(_31645) && IS_SEQUENCE(_ref_64288)) {
    }
    else {
        Concat((object_ptr)&_31646, _31645, _ref_64288);
        _31645 = NOVALUE;
    }
    _31645 = NOVALUE;
    _2 = (object)SEQ_PTR(_44toplevel_references_63200);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44toplevel_references_63200 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _36current_file_no_21767);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31646;
    if( _1 != _31646 ){
        DeRef(_1);
    }
    _31646 = NOVALUE;
    goto LB; // [468] 595
L9: 

    /** fwdref.e:809			add_active_reference( ref )*/
    _44add_active_reference(_ref_64288, _36current_file_no_21767);

    /** fwdref.e:811			if Parser_mode = PAM_RECORD then*/
    if (_36Parser_mode_21876 != 1)
    goto LC; // [485] 592

    /** fwdref.e:812				symtab_pointer default_sym = CurrentSub*/
    _default_sym_64394 = _36CurrentSub_21775;

    /** fwdref.e:813				symtab_pointer param = 0*/
    _param_64397 = 0;

    /** fwdref.e:814				while default_sym with entry do*/
    goto LD; // [507] 536
LE: 
    if (_default_sym_64394 == 0)
    {
        goto LF; // [510] 549
    }
    else{
    }

    /** fwdref.e:815					if sym_scope( default_sym ) = SC_PRIVATE then*/
    _31648 = _54sym_scope(_default_sym_64394);
    if (binary_op_a(NOTEQ, _31648, 3)){
        DeRef(_31648);
        _31648 = NOVALUE;
        goto L10; // [521] 533
    }
    DeRef(_31648);
    _31648 = NOVALUE;

    /** fwdref.e:816						param = default_sym*/
    _param_64397 = _default_sym_64394;
L10: 

    /** fwdref.e:818				entry*/
LD: 

    /** fwdref.e:819					default_sym = sym_next( default_sym )*/
    _default_sym_64394 = _54sym_next(_default_sym_64394);
    if (!IS_ATOM_INT(_default_sym_64394)) {
        _1 = (object)(DBL_PTR(_default_sym_64394)->dbl);
        DeRefDS(_default_sym_64394);
        _default_sym_64394 = _1;
    }

    /** fwdref.e:820				end while*/
    goto LE; // [546] 510
LF: 

    /** fwdref.e:821				set_data( ref, {{ PAM_RECORD, param, length( Recorded_sym ) }} )*/
    if (IS_SEQUENCE(_36Recorded_sym_21879)){
            _31651 = SEQ_PTR(_36Recorded_sym_21879)->length;
    }
    else {
        _31651 = 1;
    }
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = _param_64397;
    ((intptr_t*)_2)[3] = _31651;
    _31652 = MAKE_SEQ(_1);
    _31651 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _31652;
    _31653 = MAKE_SEQ(_1);
    _31652 = NOVALUE;
    DeRef(_data_inlined_set_data_at_575_64412);
    _data_inlined_set_data_at_575_64412 = _31653;
    _31653 = NOVALUE;

    /** fwdref.e:186		forward_references[ref][FR_DATA] = data*/
    _2 = (object)SEQ_PTR(_44forward_references_63197);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44forward_references_63197 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_64288 + ((s1_ptr)_2)->base);
    RefDS(_data_inlined_set_data_at_575_64412);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _data_inlined_set_data_at_575_64412;
    DeRef(_1);

    /** fwdref.e:187	end procedure*/
    goto L11; // [586] 589
L11: 
    DeRef(_data_inlined_set_data_at_575_64412);
    _data_inlined_set_data_at_575_64412 = NOVALUE;
LC: 
LB: 

    /** fwdref.e:824		fwdref_count += 1*/
    _44fwdref_count_63217 = _44fwdref_count_63217 + 1;

    /** fwdref.e:826		ifdef EUDIS then*/

    /** fwdref.e:839		return ref*/
    DeRef(_31592);
    _31592 = NOVALUE;
    DeRef(_31597);
    _31597 = NOVALUE;
    return _ref_64288;
    ;
}


void _44add_active_reference(object _ref_64418, object _file_no_64419)
{
    object _sp_64433 = NOVALUE;
    object _31677 = NOVALUE;
    object _31676 = NOVALUE;
    object _31674 = NOVALUE;
    object _31673 = NOVALUE;
    object _31672 = NOVALUE;
    object _31670 = NOVALUE;
    object _31669 = NOVALUE;
    object _31668 = NOVALUE;
    object _31665 = NOVALUE;
    object _31663 = NOVALUE;
    object _31662 = NOVALUE;
    object _31661 = NOVALUE;
    object _31659 = NOVALUE;
    object _31658 = NOVALUE;
    object _31657 = NOVALUE;
    object _31655 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** fwdref.e:843		if length( active_references ) < file_no then*/
    if (IS_SEQUENCE(_44active_references_63199)){
            _31655 = SEQ_PTR(_44active_references_63199)->length;
    }
    else {
        _31655 = 1;
    }
    if (_31655 >= _file_no_64419)
    goto L1; // [12] 59

    /** fwdref.e:844			active_references &= repeat( {}, file_no - length( active_references ) )*/
    if (IS_SEQUENCE(_44active_references_63199)){
            _31657 = SEQ_PTR(_44active_references_63199)->length;
    }
    else {
        _31657 = 1;
    }
    _31658 = _file_no_64419 - _31657;
    _31657 = NOVALUE;
    _31659 = Repeat(_22190, _31658);
    _31658 = NOVALUE;
    Concat((object_ptr)&_44active_references_63199, _44active_references_63199, _31659);
    DeRefDS(_31659);
    _31659 = NOVALUE;

    /** fwdref.e:845			active_subprogs   &= repeat( {}, file_no - length( active_subprogs ) )*/
    if (IS_SEQUENCE(_44active_subprogs_63198)){
            _31661 = SEQ_PTR(_44active_subprogs_63198)->length;
    }
    else {
        _31661 = 1;
    }
    _31662 = _file_no_64419 - _31661;
    _31661 = NOVALUE;
    _31663 = Repeat(_22190, _31662);
    _31662 = NOVALUE;
    Concat((object_ptr)&_44active_subprogs_63198, _44active_subprogs_63198, _31663);
    DeRefDS(_31663);
    _31663 = NOVALUE;
L1: 

    /** fwdref.e:847		integer sp = find( CurrentSub, active_subprogs[file_no] )*/
    _2 = (object)SEQ_PTR(_44active_subprogs_63198);
    _31665 = (object)*(((s1_ptr)_2)->base + _file_no_64419);
    _sp_64433 = find_from(_36CurrentSub_21775, _31665, 1);
    _31665 = NOVALUE;

    /** fwdref.e:848		if not sp then*/
    if (_sp_64433 != 0)
    goto L2; // [76] 127

    /** fwdref.e:849			active_subprogs[file_no] &= CurrentSub*/
    _2 = (object)SEQ_PTR(_44active_subprogs_63198);
    _31668 = (object)*(((s1_ptr)_2)->base + _file_no_64419);
    if (IS_SEQUENCE(_31668) && IS_ATOM(_36CurrentSub_21775)) {
        Append(&_31669, _31668, _36CurrentSub_21775);
    }
    else if (IS_ATOM(_31668) && IS_SEQUENCE(_36CurrentSub_21775)) {
    }
    else {
        Concat((object_ptr)&_31669, _31668, _36CurrentSub_21775);
        _31668 = NOVALUE;
    }
    _31668 = NOVALUE;
    _2 = (object)SEQ_PTR(_44active_subprogs_63198);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44active_subprogs_63198 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _file_no_64419);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31669;
    if( _1 != _31669 ){
        DeRef(_1);
    }
    _31669 = NOVALUE;

    /** fwdref.e:850			sp = length( active_subprogs[file_no] )*/
    _2 = (object)SEQ_PTR(_44active_subprogs_63198);
    _31670 = (object)*(((s1_ptr)_2)->base + _file_no_64419);
    if (IS_SEQUENCE(_31670)){
            _sp_64433 = SEQ_PTR(_31670)->length;
    }
    else {
        _sp_64433 = 1;
    }
    _31670 = NOVALUE;

    /** fwdref.e:852			active_references[file_no] = append( active_references[file_no], {} )*/
    _2 = (object)SEQ_PTR(_44active_references_63199);
    _31672 = (object)*(((s1_ptr)_2)->base + _file_no_64419);
    RefDS(_22190);
    Append(&_31673, _31672, _22190);
    _31672 = NOVALUE;
    _2 = (object)SEQ_PTR(_44active_references_63199);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44active_references_63199 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _file_no_64419);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31673;
    if( _1 != _31673 ){
        DeRef(_1);
    }
    _31673 = NOVALUE;
L2: 

    /** fwdref.e:854		active_references[file_no][sp] &= ref*/
    _2 = (object)SEQ_PTR(_44active_references_63199);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44active_references_63199 = MAKE_SEQ(_2);
    }
    _3 = (object)(_file_no_64419 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _31676 = (object)*(((s1_ptr)_2)->base + _sp_64433);
    _31674 = NOVALUE;
    if (IS_SEQUENCE(_31676) && IS_ATOM(_ref_64418)) {
        Append(&_31677, _31676, _ref_64418);
    }
    else if (IS_ATOM(_31676) && IS_SEQUENCE(_ref_64418)) {
    }
    else {
        Concat((object_ptr)&_31677, _31676, _ref_64418);
        _31676 = NOVALUE;
    }
    _31676 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _sp_64433);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31677;
    if( _1 != _31677 ){
        DeRef(_1);
    }
    _31677 = NOVALUE;
    _31674 = NOVALUE;

    /** fwdref.e:855	end procedure*/
    _31670 = NOVALUE;
    return;
    ;
}


object _44resolve_file(object _refs_64470, object _report_errors_64471, object _unincluded_ok_64472)
{
    object _errors_64473 = NOVALUE;
    object _ref_64477 = NOVALUE;
    object _fr_64479 = NOVALUE;
    object _tok_64492 = NOVALUE;
    object _code_sub_64500 = NOVALUE;
    object _fr_type_64502 = NOVALUE;
    object _sym_tok_64504 = NOVALUE;
    object _31731 = NOVALUE;
    object _31730 = NOVALUE;
    object _31729 = NOVALUE;
    object _31728 = NOVALUE;
    object _31727 = NOVALUE;
    object _31726 = NOVALUE;
    object _31721 = NOVALUE;
    object _31720 = NOVALUE;
    object _31719 = NOVALUE;
    object _31717 = NOVALUE;
    object _31716 = NOVALUE;
    object _31713 = NOVALUE;
    object _31712 = NOVALUE;
    object _31711 = NOVALUE;
    object _31707 = NOVALUE;
    object _31706 = NOVALUE;
    object _31698 = NOVALUE;
    object _31696 = NOVALUE;
    object _31695 = NOVALUE;
    object _31694 = NOVALUE;
    object _31693 = NOVALUE;
    object _31692 = NOVALUE;
    object _31691 = NOVALUE;
    object _31688 = NOVALUE;
    object _0, _1, _2;
    

    /** fwdref.e:864		sequence errors = {}*/
    RefDS(_22190);
    DeRefi(_errors_64473);
    _errors_64473 = _22190;

    /** fwdref.e:865		for ar = length( refs ) to 1 by -1 do*/
    if (IS_SEQUENCE(_refs_64470)){
            _31688 = SEQ_PTR(_refs_64470)->length;
    }
    else {
        _31688 = 1;
    }
    {
        object _ar_64475;
        _ar_64475 = _31688;
L1: 
        if (_ar_64475 < 1){
            goto L2; // [19] 481
        }

        /** fwdref.e:866			integer ref = refs[ar]*/
        _2 = (object)SEQ_PTR(_refs_64470);
        _ref_64477 = (object)*(((s1_ptr)_2)->base + _ar_64475);
        if (!IS_ATOM_INT(_ref_64477))
        _ref_64477 = (object)DBL_PTR(_ref_64477)->dbl;

        /** fwdref.e:868			sequence fr = forward_references[ref]*/
        DeRef(_fr_64479);
        _2 = (object)SEQ_PTR(_44forward_references_63197);
        _fr_64479 = (object)*(((s1_ptr)_2)->base + _ref_64477);
        Ref(_fr_64479);

        /** fwdref.e:869			if include_matrix[fr[FR_FILE]][current_file_no] = NOT_INCLUDED and not unincluded_ok then*/
        _2 = (object)SEQ_PTR(_fr_64479);
        _31691 = (object)*(((s1_ptr)_2)->base + 3);
        _2 = (object)SEQ_PTR(_37include_matrix_15644);
        if (!IS_ATOM_INT(_31691)){
            _31692 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31691)->dbl));
        }
        else{
            _31692 = (object)*(((s1_ptr)_2)->base + _31691);
        }
        _2 = (object)SEQ_PTR(_31692);
        _31693 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21767);
        _31692 = NOVALUE;
        if (IS_ATOM_INT(_31693)) {
            _31694 = (_31693 == 0);
        }
        else {
            _31694 = binary_op(EQUALS, _31693, 0);
        }
        _31693 = NOVALUE;
        if (IS_ATOM_INT(_31694)) {
            if (_31694 == 0) {
                goto L3; // [66] 84
            }
        }
        else {
            if (DBL_PTR(_31694)->dbl == 0.0) {
                goto L3; // [66] 84
            }
        }
        _31696 = (_unincluded_ok_64472 == 0);
        if (_31696 == 0)
        {
            DeRef(_31696);
            _31696 = NOVALUE;
            goto L3; // [74] 84
        }
        else{
            DeRef(_31696);
            _31696 = NOVALUE;
        }

        /** fwdref.e:870				continue*/
        DeRef(_fr_64479);
        _fr_64479 = NOVALUE;
        DeRef(_tok_64492);
        _tok_64492 = NOVALUE;
        goto L4; // [81] 476
L3: 

        /** fwdref.e:873			token tok = find_reference( fr )*/
        RefDS(_fr_64479);
        _0 = _tok_64492;
        _tok_64492 = _44find_reference(_fr_64479);
        DeRef(_0);

        /** fwdref.e:874			if tok[T_ID] = IGNORED then*/
        _2 = (object)SEQ_PTR(_tok_64492);
        _31698 = (object)*(((s1_ptr)_2)->base + 1);
        if (binary_op_a(NOTEQ, _31698, 509)){
            _31698 = NOVALUE;
            goto L5; // [100] 117
        }
        _31698 = NOVALUE;

        /** fwdref.e:875				errors &= ref*/
        Append(&_errors_64473, _errors_64473, _ref_64477);

        /** fwdref.e:876				continue*/
        DeRefDS(_fr_64479);
        _fr_64479 = NOVALUE;
        DeRef(_tok_64492);
        _tok_64492 = NOVALUE;
        goto L4; // [114] 476
L5: 

        /** fwdref.e:880			integer code_sub = fr[FR_SUBPROG]*/
        _2 = (object)SEQ_PTR(_fr_64479);
        _code_sub_64500 = (object)*(((s1_ptr)_2)->base + 4);
        if (!IS_ATOM_INT(_code_sub_64500))
        _code_sub_64500 = (object)DBL_PTR(_code_sub_64500)->dbl;

        /** fwdref.e:881			integer fr_type  = fr[FR_TYPE]*/
        _2 = (object)SEQ_PTR(_fr_64479);
        _fr_type_64502 = (object)*(((s1_ptr)_2)->base + 1);
        if (!IS_ATOM_INT(_fr_type_64502))
        _fr_type_64502 = (object)DBL_PTR(_fr_type_64502)->dbl;

        /** fwdref.e:882			integer sym_tok*/

        /** fwdref.e:884			switch fr_type label "fr_type" do*/
        _0 = _fr_type_64502;
        switch ( _0 ){ 

            /** fwdref.e:885				case PROC, FUNC then*/
            case 27:
            case 501:

            /** fwdref.e:887					sym_tok = SymTab[tok[T_SYM]][S_TOKEN]*/
            _2 = (object)SEQ_PTR(_tok_64492);
            _31706 = (object)*(((s1_ptr)_2)->base + 2);
            _2 = (object)SEQ_PTR(_37SymTab_15637);
            if (!IS_ATOM_INT(_31706)){
                _31707 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31706)->dbl));
            }
            else{
                _31707 = (object)*(((s1_ptr)_2)->base + _31706);
            }
            _2 = (object)SEQ_PTR(_31707);
            if (!IS_ATOM_INT(_36S_TOKEN_21409)){
                _sym_tok_64504 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21409)->dbl));
            }
            else{
                _sym_tok_64504 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21409);
            }
            if (!IS_ATOM_INT(_sym_tok_64504)){
                _sym_tok_64504 = (object)DBL_PTR(_sym_tok_64504)->dbl;
            }
            _31707 = NOVALUE;

            /** fwdref.e:888					if sym_tok = TYPE then*/
            if (_sym_tok_64504 != 504)
            goto L6; // [170] 184

            /** fwdref.e:889						sym_tok = FUNC*/
            _sym_tok_64504 = 501;
L6: 

            /** fwdref.e:891					if sym_tok != fr_type then*/
            if (_sym_tok_64504 == _fr_type_64502)
            goto L7; // [186] 220

            /** fwdref.e:892						if sym_tok != FUNC and fr_type != PROC then*/
            _31711 = (_sym_tok_64504 != 501);
            if (_31711 == 0) {
                goto L8; // [198] 219
            }
            _31713 = (_fr_type_64502 != 27);
            if (_31713 == 0)
            {
                DeRef(_31713);
                _31713 = NOVALUE;
                goto L8; // [209] 219
            }
            else{
                DeRef(_31713);
                _31713 = NOVALUE;
            }

            /** fwdref.e:893							forward_error( tok, ref )*/
            Ref(_tok_64492);
            _44forward_error(_tok_64492, _ref_64477);
L8: 
L7: 

            /** fwdref.e:896					switch sym_tok do*/
            _0 = _sym_tok_64504;
            switch ( _0 ){ 

                /** fwdref.e:897						case PROC, FUNC then*/
                case 27:
                case 501:

                /** fwdref.e:898							patch_forward_call( tok, ref )*/
                Ref(_tok_64492);
                _44patch_forward_call(_tok_64492, _ref_64477);

                /** fwdref.e:899							break "fr_type"*/
                goto L9; // [241] 446
                goto L9; // [243] 446

                /** fwdref.e:901						case else*/
                default:

                /** fwdref.e:902							forward_error( tok, ref )*/
                Ref(_tok_64492);
                _44forward_error(_tok_64492, _ref_64477);
            ;}            goto L9; // [256] 446

            /** fwdref.e:906				case VARIABLE then*/
            case -100:

            /** fwdref.e:907					sym_tok = SymTab[tok[T_SYM]][S_TOKEN]*/
            _2 = (object)SEQ_PTR(_tok_64492);
            _31716 = (object)*(((s1_ptr)_2)->base + 2);
            _2 = (object)SEQ_PTR(_37SymTab_15637);
            if (!IS_ATOM_INT(_31716)){
                _31717 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31716)->dbl));
            }
            else{
                _31717 = (object)*(((s1_ptr)_2)->base + _31716);
            }
            _2 = (object)SEQ_PTR(_31717);
            if (!IS_ATOM_INT(_36S_TOKEN_21409)){
                _sym_tok_64504 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21409)->dbl));
            }
            else{
                _sym_tok_64504 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21409);
            }
            if (!IS_ATOM_INT(_sym_tok_64504)){
                _sym_tok_64504 = (object)DBL_PTR(_sym_tok_64504)->dbl;
            }
            _31717 = NOVALUE;

            /** fwdref.e:908					if SymTab[tok[T_SYM]][S_SCOPE] = SC_UNDEFINED then*/
            _2 = (object)SEQ_PTR(_tok_64492);
            _31719 = (object)*(((s1_ptr)_2)->base + 2);
            _2 = (object)SEQ_PTR(_37SymTab_15637);
            if (!IS_ATOM_INT(_31719)){
                _31720 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31719)->dbl));
            }
            else{
                _31720 = (object)*(((s1_ptr)_2)->base + _31719);
            }
            _2 = (object)SEQ_PTR(_31720);
            _31721 = (object)*(((s1_ptr)_2)->base + 4);
            _31720 = NOVALUE;
            if (binary_op_a(NOTEQ, _31721, 9)){
                _31721 = NOVALUE;
                goto LA; // [306] 323
            }
            _31721 = NOVALUE;

            /** fwdref.e:909						errors &= ref*/
            Append(&_errors_64473, _errors_64473, _ref_64477);

            /** fwdref.e:910						continue*/
            DeRef(_fr_64479);
            _fr_64479 = NOVALUE;
            DeRef(_tok_64492);
            _tok_64492 = NOVALUE;
            goto L4; // [320] 476
LA: 

            /** fwdref.e:913					switch sym_tok do*/
            _0 = _sym_tok_64504;
            switch ( _0 ){ 

                /** fwdref.e:914						case CONSTANT, ENUM, VARIABLE then*/
                case 417:
                case 427:
                case -100:

                /** fwdref.e:915							patch_forward_variable( tok, ref )*/
                Ref(_tok_64492);
                _44patch_forward_variable(_tok_64492, _ref_64477);

                /** fwdref.e:916							break "fr_type"*/
                goto L9; // [346] 446
                goto L9; // [348] 446

                /** fwdref.e:917						case else*/
                default:

                /** fwdref.e:918							forward_error( tok, ref )*/
                Ref(_tok_64492);
                _44forward_error(_tok_64492, _ref_64477);
            ;}            goto L9; // [361] 446

            /** fwdref.e:921				case TYPE_CHECK then*/
            case 65:

            /** fwdref.e:922					patch_forward_type_check( tok, ref )*/
            Ref(_tok_64492);
            _44patch_forward_type_check(_tok_64492, _ref_64477);
            goto L9; // [373] 446

            /** fwdref.e:924				case GLOBAL_INIT_CHECK then*/
            case 109:

            /** fwdref.e:925					patch_forward_init_check( tok, ref )*/
            Ref(_tok_64492);
            _44patch_forward_init_check(_tok_64492, _ref_64477);
            goto L9; // [385] 446

            /** fwdref.e:927				case CASE then*/
            case 186:

            /** fwdref.e:928					patch_forward_case( tok, ref )*/
            Ref(_tok_64492);
            _44patch_forward_case(_tok_64492, _ref_64477);
            goto L9; // [397] 446

            /** fwdref.e:930				case TYPE then*/
            case 504:

            /** fwdref.e:931					patch_forward_type( tok, ref )*/
            Ref(_tok_64492);
            _44patch_forward_type(_tok_64492, _ref_64477);
            goto L9; // [409] 446

            /** fwdref.e:933				case GOTO then*/
            case 188:

            /** fwdref.e:934					patch_forward_goto( tok, ref )*/
            Ref(_tok_64492);
            _44patch_forward_goto(_tok_64492, _ref_64477);
            goto L9; // [421] 446

            /** fwdref.e:936				case else*/
            default:

            /** fwdref.e:938					InternalErr( 263, {fr[FR_TYPE], fr[FR_NAME]})*/
            _2 = (object)SEQ_PTR(_fr_64479);
            _31726 = (object)*(((s1_ptr)_2)->base + 1);
            _2 = (object)SEQ_PTR(_fr_64479);
            _31727 = (object)*(((s1_ptr)_2)->base + 2);
            Ref(_31727);
            Ref(_31726);
            _1 = NewS1(2);
            _2 = (object)((s1_ptr)_1)->base;
            ((intptr_t *)_2)[1] = _31726;
            ((intptr_t *)_2)[2] = _31727;
            _31728 = MAKE_SEQ(_1);
            _31727 = NOVALUE;
            _31726 = NOVALUE;
            _50InternalErr(263, _31728);
            _31728 = NOVALUE;
        ;}L9: 

        /** fwdref.e:940			if report_errors and sequence( forward_references[ref] ) then*/
        if (_report_errors_64471 == 0) {
            goto LB; // [448] 472
        }
        _2 = (object)SEQ_PTR(_44forward_references_63197);
        _31730 = (object)*(((s1_ptr)_2)->base + _ref_64477);
        _31731 = IS_SEQUENCE(_31730);
        _31730 = NOVALUE;
        if (_31731 == 0)
        {
            _31731 = NOVALUE;
            goto LB; // [462] 472
        }
        else{
            _31731 = NOVALUE;
        }

        /** fwdref.e:941				errors &= ref*/
        Append(&_errors_64473, _errors_64473, _ref_64477);
LB: 
        DeRef(_fr_64479);
        _fr_64479 = NOVALUE;
        DeRef(_tok_64492);
        _tok_64492 = NOVALUE;

        /** fwdref.e:944		end for*/
L4: 
        _ar_64475 = _ar_64475 + -1;
        goto L1; // [476] 26
L2: 
        ;
    }

    /** fwdref.e:945		return errors*/
    DeRefDS(_refs_64470);
    _31706 = NOVALUE;
    DeRef(_31694);
    _31694 = NOVALUE;
    _31691 = NOVALUE;
    DeRef(_31711);
    _31711 = NOVALUE;
    _31719 = NOVALUE;
    _31716 = NOVALUE;
    return _errors_64473;
    ;
}


object _44file_name_based_symindex_compare(object _si1_64582, object _si2_64583)
{
    object _fn1_64604 = NOVALUE;
    object _fn2_64609 = NOVALUE;
    object _31760 = NOVALUE;
    object _31759 = NOVALUE;
    object _31758 = NOVALUE;
    object _31757 = NOVALUE;
    object _31756 = NOVALUE;
    object _31755 = NOVALUE;
    object _31754 = NOVALUE;
    object _31753 = NOVALUE;
    object _31752 = NOVALUE;
    object _31751 = NOVALUE;
    object _31750 = NOVALUE;
    object _31749 = NOVALUE;
    object _31747 = NOVALUE;
    object _31745 = NOVALUE;
    object _31744 = NOVALUE;
    object _31743 = NOVALUE;
    object _31742 = NOVALUE;
    object _31741 = NOVALUE;
    object _31740 = NOVALUE;
    object _31739 = NOVALUE;
    object _31738 = NOVALUE;
    object _31737 = NOVALUE;
    object _31736 = NOVALUE;
    object _31734 = NOVALUE;
    object _31733 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_si1_64582)) {
        _1 = (object)(DBL_PTR(_si1_64582)->dbl);
        DeRefDS(_si1_64582);
        _si1_64582 = _1;
    }
    if (!IS_ATOM_INT(_si2_64583)) {
        _1 = (object)(DBL_PTR(_si2_64583)->dbl);
        DeRefDS(_si2_64583);
        _si2_64583 = _1;
    }

    /** fwdref.e:949		if not symtab_index(si1) or not symtab_index(si2) then*/
    _31733 = _36symtab_index(_si1_64582);
    if (IS_ATOM_INT(_31733)) {
        _31734 = (_31733 == 0);
    }
    else {
        _31734 = unary_op(NOT, _31733);
    }
    DeRef(_31733);
    _31733 = NOVALUE;
    if (IS_ATOM_INT(_31734)) {
        if (_31734 != 0) {
            goto L1; // [14] 30
        }
    }
    else {
        if (DBL_PTR(_31734)->dbl != 0.0) {
            goto L1; // [14] 30
        }
    }
    _31736 = _36symtab_index(_si2_64583);
    if (IS_ATOM_INT(_31736)) {
        _31737 = (_31736 == 0);
    }
    else {
        _31737 = unary_op(NOT, _31736);
    }
    DeRef(_31736);
    _31736 = NOVALUE;
    if (_31737 == 0) {
        DeRef(_31737);
        _31737 = NOVALUE;
        goto L2; // [26] 37
    }
    else {
        if (!IS_ATOM_INT(_31737) && DBL_PTR(_31737)->dbl == 0.0){
            DeRef(_31737);
            _31737 = NOVALUE;
            goto L2; // [26] 37
        }
        DeRef(_31737);
        _31737 = NOVALUE;
    }
    DeRef(_31737);
    _31737 = NOVALUE;
L1: 

    /** fwdref.e:950			return 1 -- put non symbols last*/
    DeRef(_31734);
    _31734 = NOVALUE;
    return 1;
L2: 

    /** fwdref.e:952		if S_FILE_NO <= length(SymTab[si1]) and S_FILE_NO <= length(SymTab[si2]) then*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _31738 = (object)*(((s1_ptr)_2)->base + _si1_64582);
    if (IS_SEQUENCE(_31738)){
            _31739 = SEQ_PTR(_31738)->length;
    }
    else {
        _31739 = 1;
    }
    _31738 = NOVALUE;
    if (IS_ATOM_INT(_36S_FILE_NO_21400)) {
        _31740 = (_36S_FILE_NO_21400 <= _31739);
    }
    else {
        _31740 = binary_op(LESSEQ, _36S_FILE_NO_21400, _31739);
    }
    _31739 = NOVALUE;
    if (IS_ATOM_INT(_31740)) {
        if (_31740 == 0) {
            goto L3; // [54] 186
        }
    }
    else {
        if (DBL_PTR(_31740)->dbl == 0.0) {
            goto L3; // [54] 186
        }
    }
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _31742 = (object)*(((s1_ptr)_2)->base + _si2_64583);
    if (IS_SEQUENCE(_31742)){
            _31743 = SEQ_PTR(_31742)->length;
    }
    else {
        _31743 = 1;
    }
    _31742 = NOVALUE;
    if (IS_ATOM_INT(_36S_FILE_NO_21400)) {
        _31744 = (_36S_FILE_NO_21400 <= _31743);
    }
    else {
        _31744 = binary_op(LESSEQ, _36S_FILE_NO_21400, _31743);
    }
    _31743 = NOVALUE;
    if (_31744 == 0) {
        DeRef(_31744);
        _31744 = NOVALUE;
        goto L3; // [74] 186
    }
    else {
        if (!IS_ATOM_INT(_31744) && DBL_PTR(_31744)->dbl == 0.0){
            DeRef(_31744);
            _31744 = NOVALUE;
            goto L3; // [74] 186
        }
        DeRef(_31744);
        _31744 = NOVALUE;
    }
    DeRef(_31744);
    _31744 = NOVALUE;

    /** fwdref.e:953			integer fn1 = SymTab[si1][S_FILE_NO], fn2 = SymTab[si2][S_FILE_NO]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _31745 = (object)*(((s1_ptr)_2)->base + _si1_64582);
    _2 = (object)SEQ_PTR(_31745);
    if (!IS_ATOM_INT(_36S_FILE_NO_21400)){
        _fn1_64604 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21400)->dbl));
    }
    else{
        _fn1_64604 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21400);
    }
    if (!IS_ATOM_INT(_fn1_64604)){
        _fn1_64604 = (object)DBL_PTR(_fn1_64604)->dbl;
    }
    _31745 = NOVALUE;
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _31747 = (object)*(((s1_ptr)_2)->base + _si2_64583);
    _2 = (object)SEQ_PTR(_31747);
    if (!IS_ATOM_INT(_36S_FILE_NO_21400)){
        _fn2_64609 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21400)->dbl));
    }
    else{
        _fn2_64609 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21400);
    }
    if (!IS_ATOM_INT(_fn2_64609)){
        _fn2_64609 = (object)DBL_PTR(_fn2_64609)->dbl;
    }
    _31747 = NOVALUE;

    /** fwdref.e:954			if find(1,{fn1,fn2} > length(known_files) or {fn1,fn2} <= 0) then*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _fn1_64604;
    ((intptr_t *)_2)[2] = _fn2_64609;
    _31749 = MAKE_SEQ(_1);
    if (IS_SEQUENCE(_37known_files_15638)){
            _31750 = SEQ_PTR(_37known_files_15638)->length;
    }
    else {
        _31750 = 1;
    }
    _31751 = binary_op(GREATER, _31749, _31750);
    DeRefDS(_31749);
    _31749 = NOVALUE;
    _31750 = NOVALUE;
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _fn1_64604;
    ((intptr_t *)_2)[2] = _fn2_64609;
    _31752 = MAKE_SEQ(_1);
    _31753 = binary_op(LESSEQ, _31752, 0);
    DeRefDS(_31752);
    _31752 = NOVALUE;
    _31754 = binary_op(OR, _31751, _31753);
    DeRefDS(_31751);
    _31751 = NOVALUE;
    DeRefDS(_31753);
    _31753 = NOVALUE;
    _31755 = find_from(1, _31754, 1);
    DeRefDS(_31754);
    _31754 = NOVALUE;
    if (_31755 == 0)
    {
        _31755 = NOVALUE;
        goto L4; // [139] 149
    }
    else{
        _31755 = NOVALUE;
    }

    /** fwdref.e:956				return 1*/
    _31742 = NOVALUE;
    DeRef(_31740);
    _31740 = NOVALUE;
    DeRef(_31734);
    _31734 = NOVALUE;
    _31738 = NOVALUE;
    return 1;
L4: 

    /** fwdref.e:958			return compare(abbreviate_path(known_files[fn1]),*/
    _2 = (object)SEQ_PTR(_37known_files_15638);
    _31756 = (object)*(((s1_ptr)_2)->base + _fn1_64604);
    Ref(_31756);
    RefDS(_22190);
    _31757 = _17abbreviate_path(_31756, _22190);
    _31756 = NOVALUE;
    _2 = (object)SEQ_PTR(_37known_files_15638);
    _31758 = (object)*(((s1_ptr)_2)->base + _fn2_64609);
    Ref(_31758);
    RefDS(_22190);
    _31759 = _17abbreviate_path(_31758, _22190);
    _31758 = NOVALUE;
    if (IS_ATOM_INT(_31757) && IS_ATOM_INT(_31759)){
        _31760 = (_31757 < _31759) ? -1 : (_31757 > _31759);
    }
    else{
        _31760 = compare(_31757, _31759);
    }
    DeRef(_31757);
    _31757 = NOVALUE;
    DeRef(_31759);
    _31759 = NOVALUE;
    _31742 = NOVALUE;
    DeRef(_31740);
    _31740 = NOVALUE;
    DeRef(_31734);
    _31734 = NOVALUE;
    _31738 = NOVALUE;
    return _31760;
    goto L5; // [183] 193
L3: 

    /** fwdref.e:961			return 1 -- put non-names last*/
    _31742 = NOVALUE;
    DeRef(_31740);
    _31740 = NOVALUE;
    DeRef(_31734);
    _31734 = NOVALUE;
    _31738 = NOVALUE;
    return 1;
L5: 
    ;
}


void _44Resolve_forward_references(object _report_errors_64635)
{
    object _errors_64636 = NOVALUE;
    object _unincluded_ok_64637 = NOVALUE;
    object _msg_64698 = NOVALUE;
    object _errloc_64699 = NOVALUE;
    object _ref_64704 = NOVALUE;
    object _tok_64720 = NOVALUE;
    object _THIS_SCOPE_64722 = NOVALUE;
    object _THESE_GLOBALS_64723 = NOVALUE;
    object _syms_64781 = NOVALUE;
    object _s_64802 = NOVALUE;
    object _31893 = NOVALUE;
    object _31892 = NOVALUE;
    object _31891 = NOVALUE;
    object _31889 = NOVALUE;
    object _31884 = NOVALUE;
    object _31881 = NOVALUE;
    object _31879 = NOVALUE;
    object _31878 = NOVALUE;
    object _31877 = NOVALUE;
    object _31876 = NOVALUE;
    object _31875 = NOVALUE;
    object _31874 = NOVALUE;
    object _31873 = NOVALUE;
    object _31871 = NOVALUE;
    object _31870 = NOVALUE;
    object _31869 = NOVALUE;
    object _31867 = NOVALUE;
    object _31865 = NOVALUE;
    object _31864 = NOVALUE;
    object _31863 = NOVALUE;
    object _31862 = NOVALUE;
    object _31861 = NOVALUE;
    object _31860 = NOVALUE;
    object _31857 = NOVALUE;
    object _31853 = NOVALUE;
    object _31852 = NOVALUE;
    object _31851 = NOVALUE;
    object _31850 = NOVALUE;
    object _31849 = NOVALUE;
    object _31848 = NOVALUE;
    object _31845 = NOVALUE;
    object _31844 = NOVALUE;
    object _31843 = NOVALUE;
    object _31842 = NOVALUE;
    object _31841 = NOVALUE;
    object _31840 = NOVALUE;
    object _31837 = NOVALUE;
    object _31836 = NOVALUE;
    object _31835 = NOVALUE;
    object _31834 = NOVALUE;
    object _31833 = NOVALUE;
    object _31832 = NOVALUE;
    object _31831 = NOVALUE;
    object _31830 = NOVALUE;
    object _31829 = NOVALUE;
    object _31828 = NOVALUE;
    object _31825 = NOVALUE;
    object _31823 = NOVALUE;
    object _31820 = NOVALUE;
    object _31818 = NOVALUE;
    object _31816 = NOVALUE;
    object _31815 = NOVALUE;
    object _31813 = NOVALUE;
    object _31812 = NOVALUE;
    object _31811 = NOVALUE;
    object _31810 = NOVALUE;
    object _31809 = NOVALUE;
    object _31807 = NOVALUE;
    object _31806 = NOVALUE;
    object _31804 = NOVALUE;
    object _31803 = NOVALUE;
    object _31801 = NOVALUE;
    object _31800 = NOVALUE;
    object _31798 = NOVALUE;
    object _31797 = NOVALUE;
    object _31796 = NOVALUE;
    object _31795 = NOVALUE;
    object _31794 = NOVALUE;
    object _31793 = NOVALUE;
    object _31792 = NOVALUE;
    object _31791 = NOVALUE;
    object _31790 = NOVALUE;
    object _31789 = NOVALUE;
    object _31788 = NOVALUE;
    object _31787 = NOVALUE;
    object _31786 = NOVALUE;
    object _31785 = NOVALUE;
    object _31784 = NOVALUE;
    object _31783 = NOVALUE;
    object _31781 = NOVALUE;
    object _31780 = NOVALUE;
    object _31779 = NOVALUE;
    object _31778 = NOVALUE;
    object _31776 = NOVALUE;
    object _31775 = NOVALUE;
    object _31773 = NOVALUE;
    object _31772 = NOVALUE;
    object _31771 = NOVALUE;
    object _31770 = NOVALUE;
    object _31768 = NOVALUE;
    object _31767 = NOVALUE;
    object _31766 = NOVALUE;
    object _31765 = NOVALUE;
    object _31763 = NOVALUE;
    object _31762 = NOVALUE;
    object _0, _1, _2;
    

    /** fwdref.e:966		sequence errors = {}*/
    RefDS(_22190);
    DeRef(_errors_64636);
    _errors_64636 = _22190;

    /** fwdref.e:967		integer unincluded_ok = get_resolve_unincluded_globals()*/
    _unincluded_ok_64637 = _54get_resolve_unincluded_globals();
    if (!IS_ATOM_INT(_unincluded_ok_64637)) {
        _1 = (object)(DBL_PTR(_unincluded_ok_64637)->dbl);
        DeRefDS(_unincluded_ok_64637);
        _unincluded_ok_64637 = _1;
    }

    /** fwdref.e:969		if length( active_references ) < length( known_files ) then*/
    if (IS_SEQUENCE(_44active_references_63199)){
            _31762 = SEQ_PTR(_44active_references_63199)->length;
    }
    else {
        _31762 = 1;
    }
    if (IS_SEQUENCE(_37known_files_15638)){
            _31763 = SEQ_PTR(_37known_files_15638)->length;
    }
    else {
        _31763 = 1;
    }
    if (_31762 >= _31763)
    goto L1; // [29] 86

    /** fwdref.e:970			active_references &= repeat( {}, length( known_files ) - length( active_references ) )*/
    if (IS_SEQUENCE(_37known_files_15638)){
            _31765 = SEQ_PTR(_37known_files_15638)->length;
    }
    else {
        _31765 = 1;
    }
    if (IS_SEQUENCE(_44active_references_63199)){
            _31766 = SEQ_PTR(_44active_references_63199)->length;
    }
    else {
        _31766 = 1;
    }
    _31767 = _31765 - _31766;
    _31765 = NOVALUE;
    _31766 = NOVALUE;
    _31768 = Repeat(_22190, _31767);
    _31767 = NOVALUE;
    Concat((object_ptr)&_44active_references_63199, _44active_references_63199, _31768);
    DeRefDS(_31768);
    _31768 = NOVALUE;

    /** fwdref.e:971			active_subprogs   &= repeat( {}, length( known_files ) - length( active_subprogs ) )*/
    if (IS_SEQUENCE(_37known_files_15638)){
            _31770 = SEQ_PTR(_37known_files_15638)->length;
    }
    else {
        _31770 = 1;
    }
    if (IS_SEQUENCE(_44active_subprogs_63198)){
            _31771 = SEQ_PTR(_44active_subprogs_63198)->length;
    }
    else {
        _31771 = 1;
    }
    _31772 = _31770 - _31771;
    _31770 = NOVALUE;
    _31771 = NOVALUE;
    _31773 = Repeat(_22190, _31772);
    _31772 = NOVALUE;
    Concat((object_ptr)&_44active_subprogs_63198, _44active_subprogs_63198, _31773);
    DeRefDS(_31773);
    _31773 = NOVALUE;
L1: 

    /** fwdref.e:974		if length( toplevel_references ) < length( known_files ) then*/
    if (IS_SEQUENCE(_44toplevel_references_63200)){
            _31775 = SEQ_PTR(_44toplevel_references_63200)->length;
    }
    else {
        _31775 = 1;
    }
    if (IS_SEQUENCE(_37known_files_15638)){
            _31776 = SEQ_PTR(_37known_files_15638)->length;
    }
    else {
        _31776 = 1;
    }
    if (_31775 >= _31776)
    goto L2; // [98] 129

    /** fwdref.e:975			toplevel_references &= repeat( {}, length( known_files ) - length( toplevel_references ) )*/
    if (IS_SEQUENCE(_37known_files_15638)){
            _31778 = SEQ_PTR(_37known_files_15638)->length;
    }
    else {
        _31778 = 1;
    }
    if (IS_SEQUENCE(_44toplevel_references_63200)){
            _31779 = SEQ_PTR(_44toplevel_references_63200)->length;
    }
    else {
        _31779 = 1;
    }
    _31780 = _31778 - _31779;
    _31778 = NOVALUE;
    _31779 = NOVALUE;
    _31781 = Repeat(_22190, _31780);
    _31780 = NOVALUE;
    Concat((object_ptr)&_44toplevel_references_63200, _44toplevel_references_63200, _31781);
    DeRefDS(_31781);
    _31781 = NOVALUE;
L2: 

    /** fwdref.e:978		for i = 1 to length( active_subprogs ) do*/
    if (IS_SEQUENCE(_44active_subprogs_63198)){
            _31783 = SEQ_PTR(_44active_subprogs_63198)->length;
    }
    else {
        _31783 = 1;
    }
    {
        object _i_64669;
        _i_64669 = 1;
L3: 
        if (_i_64669 > _31783){
            goto L4; // [136] 280
        }

        /** fwdref.e:979			if (length( active_subprogs[i] ) or length(toplevel_references[i])) */
        _2 = (object)SEQ_PTR(_44active_subprogs_63198);
        _31784 = (object)*(((s1_ptr)_2)->base + _i_64669);
        if (IS_SEQUENCE(_31784)){
                _31785 = SEQ_PTR(_31784)->length;
        }
        else {
            _31785 = 1;
        }
        _31784 = NOVALUE;
        if (_31785 != 0) {
            _31786 = 1;
            goto L5; // [154] 171
        }
        _2 = (object)SEQ_PTR(_44toplevel_references_63200);
        _31787 = (object)*(((s1_ptr)_2)->base + _i_64669);
        if (IS_SEQUENCE(_31787)){
                _31788 = SEQ_PTR(_31787)->length;
        }
        else {
            _31788 = 1;
        }
        _31787 = NOVALUE;
        _31786 = (_31788 != 0);
L5: 
        if (_31786 == 0) {
            goto L6; // [171] 273
        }
        _31790 = (_i_64669 == _36current_file_no_21767);
        if (_31790 != 0) {
            _31791 = 1;
            goto L7; // [181] 195
        }
        _2 = (object)SEQ_PTR(_37finished_files_15640);
        _31792 = (object)*(((s1_ptr)_2)->base + _i_64669);
        _31791 = (_31792 != 0);
L7: 
        if (_31791 != 0) {
            DeRef(_31793);
            _31793 = 1;
            goto L8; // [195] 203
        }
        _31793 = (_unincluded_ok_64637 != 0);
L8: 
        if (_31793 == 0)
        {
            _31793 = NOVALUE;
            goto L6; // [204] 273
        }
        else{
            _31793 = NOVALUE;
        }

        /** fwdref.e:982				for j = length( active_references[i] ) to 1 by -1 do*/
        _2 = (object)SEQ_PTR(_44active_references_63199);
        _31794 = (object)*(((s1_ptr)_2)->base + _i_64669);
        if (IS_SEQUENCE(_31794)){
                _31795 = SEQ_PTR(_31794)->length;
        }
        else {
            _31795 = 1;
        }
        _31794 = NOVALUE;
        {
            object _j_64685;
            _j_64685 = _31795;
L9: 
            if (_j_64685 < 1){
                goto LA; // [218] 254
            }

            /** fwdref.e:983					errors &= resolve_file( active_references[i][j], report_errors, unincluded_ok )*/
            _2 = (object)SEQ_PTR(_44active_references_63199);
            _31796 = (object)*(((s1_ptr)_2)->base + _i_64669);
            _2 = (object)SEQ_PTR(_31796);
            _31797 = (object)*(((s1_ptr)_2)->base + _j_64685);
            _31796 = NOVALUE;
            Ref(_31797);
            _31798 = _44resolve_file(_31797, _report_errors_64635, _unincluded_ok_64637);
            _31797 = NOVALUE;
            if (IS_SEQUENCE(_errors_64636) && IS_ATOM(_31798)) {
                Ref(_31798);
                Append(&_errors_64636, _errors_64636, _31798);
            }
            else if (IS_ATOM(_errors_64636) && IS_SEQUENCE(_31798)) {
            }
            else {
                Concat((object_ptr)&_errors_64636, _errors_64636, _31798);
            }
            DeRef(_31798);
            _31798 = NOVALUE;

            /** fwdref.e:984				end for*/
            _j_64685 = _j_64685 + -1;
            goto L9; // [249] 225
LA: 
            ;
        }

        /** fwdref.e:985				errors &= resolve_file( toplevel_references[i], report_errors, unincluded_ok )*/
        _2 = (object)SEQ_PTR(_44toplevel_references_63200);
        _31800 = (object)*(((s1_ptr)_2)->base + _i_64669);
        Ref(_31800);
        _31801 = _44resolve_file(_31800, _report_errors_64635, _unincluded_ok_64637);
        _31800 = NOVALUE;
        if (IS_SEQUENCE(_errors_64636) && IS_ATOM(_31801)) {
            Ref(_31801);
            Append(&_errors_64636, _errors_64636, _31801);
        }
        else if (IS_ATOM(_errors_64636) && IS_SEQUENCE(_31801)) {
        }
        else {
            Concat((object_ptr)&_errors_64636, _errors_64636, _31801);
        }
        DeRef(_31801);
        _31801 = NOVALUE;
L6: 

        /** fwdref.e:987		end for*/
        _i_64669 = _i_64669 + 1;
        goto L3; // [275] 143
L4: 
        ;
    }

    /** fwdref.e:989		if report_errors and length( errors ) then*/
    if (_report_errors_64635 == 0) {
        goto LB; // [282] 856
    }
    if (IS_SEQUENCE(_errors_64636)){
            _31804 = SEQ_PTR(_errors_64636)->length;
    }
    else {
        _31804 = 1;
    }
    if (_31804 == 0)
    {
        _31804 = NOVALUE;
        goto LB; // [290] 856
    }
    else{
        _31804 = NOVALUE;
    }

    /** fwdref.e:990			sequence msg = ""*/
    RefDS(_22190);
    DeRefi(_msg_64698);
    _msg_64698 = _22190;

    /** fwdref.e:991			sequence errloc = "Internal Error - Unknown Error Message"*/
    RefDS(_31805);
    DeRefi(_errloc_64699);
    _errloc_64699 = _31805;

    /** fwdref.e:993			for e = length(errors) to 1 by -1 do*/
    if (IS_SEQUENCE(_errors_64636)){
            _31806 = SEQ_PTR(_errors_64636)->length;
    }
    else {
        _31806 = 1;
    }
    {
        object _e_64702;
        _e_64702 = _31806;
LC: 
        if (_e_64702 < 1){
            goto LD; // [312] 828
        }

        /** fwdref.e:994				sequence ref = forward_references[errors[e]]*/
        _2 = (object)SEQ_PTR(_errors_64636);
        _31807 = (object)*(((s1_ptr)_2)->base + _e_64702);
        DeRef(_ref_64704);
        _2 = (object)SEQ_PTR(_44forward_references_63197);
        if (!IS_ATOM_INT(_31807)){
            _ref_64704 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31807)->dbl));
        }
        else{
            _ref_64704 = (object)*(((s1_ptr)_2)->base + _31807);
        }
        Ref(_ref_64704);

        /** fwdref.e:995				if (ref[FR_TYPE] = TYPE_CHECK and ref[FR_OP] = TYPE_CHECK) or ref[FR_TYPE] = GLOBAL_INIT_CHECK then*/
        _2 = (object)SEQ_PTR(_ref_64704);
        _31809 = (object)*(((s1_ptr)_2)->base + 1);
        if (IS_ATOM_INT(_31809)) {
            _31810 = (_31809 == 65);
        }
        else {
            _31810 = binary_op(EQUALS, _31809, 65);
        }
        _31809 = NOVALUE;
        if (IS_ATOM_INT(_31810)) {
            if (_31810 == 0) {
                DeRef(_31811);
                _31811 = 0;
                goto LE; // [345] 363
            }
        }
        else {
            if (DBL_PTR(_31810)->dbl == 0.0) {
                DeRef(_31811);
                _31811 = 0;
                goto LE; // [345] 363
            }
        }
        _2 = (object)SEQ_PTR(_ref_64704);
        _31812 = (object)*(((s1_ptr)_2)->base + 10);
        if (IS_ATOM_INT(_31812)) {
            _31813 = (_31812 == 65);
        }
        else {
            _31813 = binary_op(EQUALS, _31812, 65);
        }
        _31812 = NOVALUE;
        DeRef(_31811);
        if (IS_ATOM_INT(_31813))
        _31811 = (_31813 != 0);
        else
        _31811 = DBL_PTR(_31813)->dbl != 0.0;
LE: 
        if (_31811 != 0) {
            goto LF; // [363] 382
        }
        _2 = (object)SEQ_PTR(_ref_64704);
        _31815 = (object)*(((s1_ptr)_2)->base + 1);
        if (IS_ATOM_INT(_31815)) {
            _31816 = (_31815 == 109);
        }
        else {
            _31816 = binary_op(EQUALS, _31815, 109);
        }
        _31815 = NOVALUE;
        if (_31816 == 0) {
            DeRef(_31816);
            _31816 = NOVALUE;
            goto L10; // [378] 391
        }
        else {
            if (!IS_ATOM_INT(_31816) && DBL_PTR(_31816)->dbl == 0.0){
                DeRef(_31816);
                _31816 = NOVALUE;
                goto L10; // [378] 391
            }
            DeRef(_31816);
            _31816 = NOVALUE;
        }
        DeRef(_31816);
        _31816 = NOVALUE;
LF: 

        /** fwdref.e:997					continue*/
        DeRef(_ref_64704);
        _ref_64704 = NOVALUE;
        goto L11; // [386] 823
        goto L12; // [388] 789
L10: 

        /** fwdref.e:1001					object tok = find_reference(ref)*/
        RefDS(_ref_64704);
        _0 = _tok_64720;
        _tok_64720 = _44find_reference(_ref_64704);
        DeRef(_0);

        /** fwdref.e:1002					integer THIS_SCOPE = 3*/
        _THIS_SCOPE_64722 = 3;

        /** fwdref.e:1003					integer THESE_GLOBALS = 4*/
        _THESE_GLOBALS_64723 = 4;

        /** fwdref.e:1004					if tok[T_ID] = IGNORED then*/
        _2 = (object)SEQ_PTR(_tok_64720);
        _31818 = (object)*(((s1_ptr)_2)->base + 1);
        if (binary_op_a(NOTEQ, _31818, 509)){
            _31818 = NOVALUE;
            goto L13; // [417] 760
        }
        _31818 = NOVALUE;

        /** fwdref.e:1006						switch tok[THIS_SCOPE] do*/
        _2 = (object)SEQ_PTR(_tok_64720);
        _31820 = (object)*(((s1_ptr)_2)->base + 3);
        if (IS_SEQUENCE(_31820) ){
            goto L14; // [427] 756
        }
        if(!IS_ATOM_INT(_31820)){
            if( (DBL_PTR(_31820)->dbl != (eudouble) ((object) DBL_PTR(_31820)->dbl) ) ){
                goto L14; // [427] 756
            }
            _0 = (object) DBL_PTR(_31820)->dbl;
        }
        else {
            _0 = _31820;
        };
        _31820 = NOVALUE;
        switch ( _0 ){ 

            /** fwdref.e:1007							case SC_UNDEFINED then*/
            case 9:

            /** fwdref.e:1008								if ref[FR_QUALIFIED] != -1 then*/
            _2 = (object)SEQ_PTR(_ref_64704);
            _31823 = (object)*(((s1_ptr)_2)->base + 9);
            if (binary_op_a(EQUALS, _31823, -1)){
                _31823 = NOVALUE;
                goto L15; // [442] 556
            }
            _31823 = NOVALUE;

            /** fwdref.e:1009									if ref[FR_QUALIFIED] > 0 then*/
            _2 = (object)SEQ_PTR(_ref_64704);
            _31825 = (object)*(((s1_ptr)_2)->base + 9);
            if (binary_op_a(LESSEQ, _31825, 0)){
                _31825 = NOVALUE;
                goto L16; // [452] 517
            }
            _31825 = NOVALUE;

            /** fwdref.e:1011										errloc = sprintf("\t\'%s\' (%s:%d) was not declared in \'%s\'.\n", */
            _2 = (object)SEQ_PTR(_ref_64704);
            _31828 = (object)*(((s1_ptr)_2)->base + 2);
            _2 = (object)SEQ_PTR(_ref_64704);
            _31829 = (object)*(((s1_ptr)_2)->base + 3);
            _2 = (object)SEQ_PTR(_37known_files_15638);
            if (!IS_ATOM_INT(_31829)){
                _31830 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31829)->dbl));
            }
            else{
                _31830 = (object)*(((s1_ptr)_2)->base + _31829);
            }
            Ref(_31830);
            RefDS(_22190);
            _31831 = _17abbreviate_path(_31830, _22190);
            _31830 = NOVALUE;
            _2 = (object)SEQ_PTR(_ref_64704);
            _31832 = (object)*(((s1_ptr)_2)->base + 6);
            _2 = (object)SEQ_PTR(_ref_64704);
            _31833 = (object)*(((s1_ptr)_2)->base + 9);
            _2 = (object)SEQ_PTR(_37known_files_15638);
            if (!IS_ATOM_INT(_31833)){
                _31834 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31833)->dbl));
            }
            else{
                _31834 = (object)*(((s1_ptr)_2)->base + _31833);
            }
            Ref(_31834);
            RefDS(_22190);
            _31835 = _17abbreviate_path(_31834, _22190);
            _31834 = NOVALUE;
            _31836 = _16find_replace(92, _31835, 47, 0);
            _31835 = NOVALUE;
            _1 = NewS1(4);
            _2 = (object)((s1_ptr)_1)->base;
            Ref(_31828);
            ((intptr_t*)_2)[1] = _31828;
            ((intptr_t*)_2)[2] = _31831;
            Ref(_31832);
            ((intptr_t*)_2)[3] = _31832;
            ((intptr_t*)_2)[4] = _31836;
            _31837 = MAKE_SEQ(_1);
            _31836 = NOVALUE;
            _31832 = NOVALUE;
            _31831 = NOVALUE;
            _31828 = NOVALUE;
            DeRefi(_errloc_64699);
            _errloc_64699 = EPrintf(-9999999, _31827, _31837);
            DeRefDS(_31837);
            _31837 = NOVALUE;
            goto L17; // [514] 759
L16: 

            /** fwdref.e:1016										errloc = sprintf("\t\'%s\' (%s:%d) is not a builtin.\n", */
            _2 = (object)SEQ_PTR(_ref_64704);
            _31840 = (object)*(((s1_ptr)_2)->base + 2);
            _2 = (object)SEQ_PTR(_ref_64704);
            _31841 = (object)*(((s1_ptr)_2)->base + 3);
            _2 = (object)SEQ_PTR(_37known_files_15638);
            if (!IS_ATOM_INT(_31841)){
                _31842 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31841)->dbl));
            }
            else{
                _31842 = (object)*(((s1_ptr)_2)->base + _31841);
            }
            Ref(_31842);
            RefDS(_22190);
            _31843 = _17abbreviate_path(_31842, _22190);
            _31842 = NOVALUE;
            _2 = (object)SEQ_PTR(_ref_64704);
            _31844 = (object)*(((s1_ptr)_2)->base + 6);
            _1 = NewS1(3);
            _2 = (object)((s1_ptr)_1)->base;
            Ref(_31840);
            ((intptr_t*)_2)[1] = _31840;
            ((intptr_t*)_2)[2] = _31843;
            Ref(_31844);
            ((intptr_t*)_2)[3] = _31844;
            _31845 = MAKE_SEQ(_1);
            _31844 = NOVALUE;
            _31843 = NOVALUE;
            _31840 = NOVALUE;
            DeRefi(_errloc_64699);
            _errloc_64699 = EPrintf(-9999999, _31839, _31845);
            DeRefDS(_31845);
            _31845 = NOVALUE;
            goto L17; // [553] 759
L15: 

            /** fwdref.e:1021									errloc = sprintf("\t\'%s\' (%s:%d) has not been declared.\n", */
            _2 = (object)SEQ_PTR(_ref_64704);
            _31848 = (object)*(((s1_ptr)_2)->base + 2);
            _2 = (object)SEQ_PTR(_ref_64704);
            _31849 = (object)*(((s1_ptr)_2)->base + 3);
            _2 = (object)SEQ_PTR(_37known_files_15638);
            if (!IS_ATOM_INT(_31849)){
                _31850 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31849)->dbl));
            }
            else{
                _31850 = (object)*(((s1_ptr)_2)->base + _31849);
            }
            Ref(_31850);
            RefDS(_22190);
            _31851 = _17abbreviate_path(_31850, _22190);
            _31850 = NOVALUE;
            _2 = (object)SEQ_PTR(_ref_64704);
            _31852 = (object)*(((s1_ptr)_2)->base + 6);
            _1 = NewS1(3);
            _2 = (object)((s1_ptr)_1)->base;
            Ref(_31848);
            ((intptr_t*)_2)[1] = _31848;
            ((intptr_t*)_2)[2] = _31851;
            Ref(_31852);
            ((intptr_t*)_2)[3] = _31852;
            _31853 = MAKE_SEQ(_1);
            _31852 = NOVALUE;
            _31851 = NOVALUE;
            _31848 = NOVALUE;
            DeRefi(_errloc_64699);
            _errloc_64699 = EPrintf(-9999999, _31847, _31853);
            DeRefDS(_31853);
            _31853 = NOVALUE;
            goto L17; // [592] 759

            /** fwdref.e:1024							case SC_MULTIPLY_DEFINED then*/
            case 10:

            /** fwdref.e:1025								sequence syms = tok[THESE_GLOBALS] -- there should be no forward references in here.*/
            DeRef(_syms_64781);
            _2 = (object)SEQ_PTR(_tok_64720);
            _syms_64781 = (object)*(((s1_ptr)_2)->base + _THESE_GLOBALS_64723);
            Ref(_syms_64781);

            /** fwdref.e:1026								syms = custom_sort(routine_id("file_name_based_symindex_compare"), syms,, ASCENDING)*/
            _31857 = CRoutineId(1385, 44, _31856);
            RefDS(_syms_64781);
            RefDS(_22190);
            _0 = _syms_64781;
            _syms_64781 = _24custom_sort(_31857, _syms_64781, _22190, 1);
            DeRefDS(_0);
            _31857 = NOVALUE;

            /** fwdref.e:1027								errloc = sprintf("\t\'%s\' (%s:%d) has been declared more than once.\n", */
            _2 = (object)SEQ_PTR(_ref_64704);
            _31860 = (object)*(((s1_ptr)_2)->base + 2);
            _2 = (object)SEQ_PTR(_ref_64704);
            _31861 = (object)*(((s1_ptr)_2)->base + 3);
            _2 = (object)SEQ_PTR(_37known_files_15638);
            if (!IS_ATOM_INT(_31861)){
                _31862 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31861)->dbl));
            }
            else{
                _31862 = (object)*(((s1_ptr)_2)->base + _31861);
            }
            Ref(_31862);
            RefDS(_22190);
            _31863 = _17abbreviate_path(_31862, _22190);
            _31862 = NOVALUE;
            _2 = (object)SEQ_PTR(_ref_64704);
            _31864 = (object)*(((s1_ptr)_2)->base + 6);
            _1 = NewS1(3);
            _2 = (object)((s1_ptr)_1)->base;
            Ref(_31860);
            ((intptr_t*)_2)[1] = _31860;
            ((intptr_t*)_2)[2] = _31863;
            Ref(_31864);
            ((intptr_t*)_2)[3] = _31864;
            _31865 = MAKE_SEQ(_1);
            _31864 = NOVALUE;
            _31863 = NOVALUE;
            _31860 = NOVALUE;
            DeRefi(_errloc_64699);
            _errloc_64699 = EPrintf(-9999999, _31859, _31865);
            DeRefDS(_31865);
            _31865 = NOVALUE;

            /** fwdref.e:1029								for si = 1 to length(syms) do*/
            if (IS_SEQUENCE(_syms_64781)){
                    _31867 = SEQ_PTR(_syms_64781)->length;
            }
            else {
                _31867 = 1;
            }
            {
                object _si_64799;
                _si_64799 = 1;
L18: 
                if (_si_64799 > _31867){
                    goto L19; // [664] 750
                }

                /** fwdref.e:1030									symtab_index s = syms[si] */
                _2 = (object)SEQ_PTR(_syms_64781);
                _s_64802 = (object)*(((s1_ptr)_2)->base + _si_64799);
                if (!IS_ATOM_INT(_s_64802)){
                    _s_64802 = (object)DBL_PTR(_s_64802)->dbl;
                }

                /** fwdref.e:1031									if equal(ref[FR_NAME], sym_name(s)) then*/
                _2 = (object)SEQ_PTR(_ref_64704);
                _31869 = (object)*(((s1_ptr)_2)->base + 2);
                _31870 = _54sym_name(_s_64802);
                if (_31869 == _31870)
                _31871 = 1;
                else if (IS_ATOM_INT(_31869) && IS_ATOM_INT(_31870))
                _31871 = 0;
                else
                _31871 = (compare(_31869, _31870) == 0);
                _31869 = NOVALUE;
                DeRef(_31870);
                _31870 = NOVALUE;
                if (_31871 == 0)
                {
                    _31871 = NOVALUE;
                    goto L1A; // [693] 741
                }
                else{
                    _31871 = NOVALUE;
                }

                /** fwdref.e:1032										errloc &= sprintf("\t\tin %s\n", */
                _2 = (object)SEQ_PTR(_37SymTab_15637);
                _31873 = (object)*(((s1_ptr)_2)->base + _s_64802);
                _2 = (object)SEQ_PTR(_31873);
                if (!IS_ATOM_INT(_36S_FILE_NO_21400)){
                    _31874 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21400)->dbl));
                }
                else{
                    _31874 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21400);
                }
                _31873 = NOVALUE;
                _2 = (object)SEQ_PTR(_37known_files_15638);
                if (!IS_ATOM_INT(_31874)){
                    _31875 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31874)->dbl));
                }
                else{
                    _31875 = (object)*(((s1_ptr)_2)->base + _31874);
                }
                Ref(_31875);
                RefDS(_22190);
                _31876 = _17abbreviate_path(_31875, _22190);
                _31875 = NOVALUE;
                _31877 = _16find_replace(92, _31876, 47, 0);
                _31876 = NOVALUE;
                _1 = NewS1(1);
                _2 = (object)((s1_ptr)_1)->base;
                ((intptr_t*)_2)[1] = _31877;
                _31878 = MAKE_SEQ(_1);
                _31877 = NOVALUE;
                _31879 = EPrintf(-9999999, _31872, _31878);
                DeRefDS(_31878);
                _31878 = NOVALUE;
                Concat((object_ptr)&_errloc_64699, _errloc_64699, _31879);
                DeRefDS(_31879);
                _31879 = NOVALUE;
L1A: 

                /** fwdref.e:1035								end for*/
                _si_64799 = _si_64799 + 1;
                goto L18; // [745] 671
L19: 
                ;
            }
            DeRef(_syms_64781);
            _syms_64781 = NOVALUE;
            goto L17; // [752] 759

            /** fwdref.e:1036							case else */
            default:
L14: 
        ;}L17: 
L13: 

        /** fwdref.e:1040					if not match(errloc, msg) then*/
        _31881 = e_match_from(_errloc_64699, _msg_64698, 1);
        if (_31881 != 0)
        goto L1B; // [767] 786
        _31881 = NOVALUE;

        /** fwdref.e:1041						msg &= errloc*/
        Concat((object_ptr)&_msg_64698, _msg_64698, _errloc_64699);

        /** fwdref.e:1042						prep_forward_error( errors[e] )*/
        _2 = (object)SEQ_PTR(_errors_64636);
        _31884 = (object)*(((s1_ptr)_2)->base + _e_64702);
        Ref(_31884);
        _44prep_forward_error(_31884);
        _31884 = NOVALUE;
L1B: 
        DeRef(_tok_64720);
        _tok_64720 = NOVALUE;
L12: 

        /** fwdref.e:1045				ThisLine    = ref[FR_THISLINE]*/
        DeRef(_50ThisLine_49594);
        _2 = (object)SEQ_PTR(_ref_64704);
        _50ThisLine_49594 = (object)*(((s1_ptr)_2)->base + 7);
        Ref(_50ThisLine_49594);

        /** fwdref.e:1046				bp          = ref[FR_BP]*/
        _2 = (object)SEQ_PTR(_ref_64704);
        _50bp_49598 = (object)*(((s1_ptr)_2)->base + 8);
        if (!IS_ATOM_INT(_50bp_49598)){
            _50bp_49598 = (object)DBL_PTR(_50bp_49598)->dbl;
        }

        /** fwdref.e:1047				CurrentSub  = ref[FR_SUBPROG]*/
        _2 = (object)SEQ_PTR(_ref_64704);
        _36CurrentSub_21775 = (object)*(((s1_ptr)_2)->base + 4);
        if (!IS_ATOM_INT(_36CurrentSub_21775)){
            _36CurrentSub_21775 = (object)DBL_PTR(_36CurrentSub_21775)->dbl;
        }

        /** fwdref.e:1048				line_number = ref[FR_LINE]*/
        _2 = (object)SEQ_PTR(_ref_64704);
        _36line_number_21768 = (object)*(((s1_ptr)_2)->base + 6);
        if (!IS_ATOM_INT(_36line_number_21768)){
            _36line_number_21768 = (object)DBL_PTR(_36line_number_21768)->dbl;
        }
        DeRefDS(_ref_64704);
        _ref_64704 = NOVALUE;

        /** fwdref.e:1049			end for*/
L11: 
        _e_64702 = _e_64702 + -1;
        goto LC; // [823] 319
LD: 
        ;
    }

    /** fwdref.e:1050			if length(msg) > 0 then*/
    if (IS_SEQUENCE(_msg_64698)){
            _31889 = SEQ_PTR(_msg_64698)->length;
    }
    else {
        _31889 = 1;
    }
    if (_31889 <= 0)
    goto L1C; // [833] 851

    /** fwdref.e:1051				CompileErr( ERRORS_RESOLVING_THE_FOLLOWING_REFERENCES1, {msg} )*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_msg_64698);
    ((intptr_t*)_2)[1] = _msg_64698;
    _31891 = MAKE_SEQ(_1);
    _50CompileErr(74, _31891, 0);
    _31891 = NOVALUE;
L1C: 
    DeRefi(_msg_64698);
    _msg_64698 = NOVALUE;
    DeRefi(_errloc_64699);
    _errloc_64699 = NOVALUE;
    goto L1D; // [853] 901
LB: 

    /** fwdref.e:1053		elsif report_errors and not repl then*/
    if (_report_errors_64635 == 0) {
        goto L1E; // [858] 900
    }
    _31893 = (0 == 0);
    if (_31893 == 0)
    {
        DeRef(_31893);
        _31893 = NOVALUE;
        goto L1E; // [868] 900
    }
    else{
        DeRef(_31893);
        _31893 = NOVALUE;
    }

    /** fwdref.e:1055			forward_references  = {}*/
    RefDS(_22190);
    DeRef(_44forward_references_63197);
    _44forward_references_63197 = _22190;

    /** fwdref.e:1056			active_references   = {}*/
    RefDS(_22190);
    DeRef(_44active_references_63199);
    _44active_references_63199 = _22190;

    /** fwdref.e:1057			toplevel_references = {}*/
    RefDS(_22190);
    DeRef(_44toplevel_references_63200);
    _44toplevel_references_63200 = _22190;

    /** fwdref.e:1058			inactive_references = {}*/
    RefDS(_22190);
    DeRef(_44inactive_references_63201);
    _44inactive_references_63201 = _22190;
L1E: 
L1D: 

    /** fwdref.e:1060		clear_last()*/
    _47clear_last();

    /** fwdref.e:1061	end procedure*/
    DeRef(_errors_64636);
    DeRef(_31813);
    _31813 = NOVALUE;
    _31874 = NOVALUE;
    DeRef(_31790);
    _31790 = NOVALUE;
    _31829 = NOVALUE;
    _31784 = NOVALUE;
    DeRef(_31810);
    _31810 = NOVALUE;
    _31787 = NOVALUE;
    _31794 = NOVALUE;
    _31861 = NOVALUE;
    _31792 = NOVALUE;
    _31833 = NOVALUE;
    _31841 = NOVALUE;
    _31807 = NOVALUE;
    _31849 = NOVALUE;
    return;
    ;
}


void _44shift_these(object _refs_64850, object _pc_64851, object _amount_64852)
{
    object _fr_64856 = NOVALUE;
    object _31911 = NOVALUE;
    object _31910 = NOVALUE;
    object _31909 = NOVALUE;
    object _31908 = NOVALUE;
    object _31907 = NOVALUE;
    object _31906 = NOVALUE;
    object _31905 = NOVALUE;
    object _31904 = NOVALUE;
    object _31903 = NOVALUE;
    object _31902 = NOVALUE;
    object _31900 = NOVALUE;
    object _31898 = NOVALUE;
    object _31897 = NOVALUE;
    object _31895 = NOVALUE;
    object _31894 = NOVALUE;
    object _0, _1, _2;
    

    /** fwdref.e:1064		for i = length( refs ) to 1 by -1 do*/
    if (IS_SEQUENCE(_refs_64850)){
            _31894 = SEQ_PTR(_refs_64850)->length;
    }
    else {
        _31894 = 1;
    }
    {
        object _i_64854;
        _i_64854 = _31894;
L1: 
        if (_i_64854 < 1){
            goto L2; // [12] 147
        }

        /** fwdref.e:1065			sequence fr = forward_references[refs[i]]*/
        _2 = (object)SEQ_PTR(_refs_64850);
        _31895 = (object)*(((s1_ptr)_2)->base + _i_64854);
        DeRef(_fr_64856);
        _2 = (object)SEQ_PTR(_44forward_references_63197);
        if (!IS_ATOM_INT(_31895)){
            _fr_64856 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31895)->dbl));
        }
        else{
            _fr_64856 = (object)*(((s1_ptr)_2)->base + _31895);
        }
        Ref(_fr_64856);

        /** fwdref.e:1066			forward_references[refs[i]] = 0*/
        _2 = (object)SEQ_PTR(_refs_64850);
        _31897 = (object)*(((s1_ptr)_2)->base + _i_64854);
        _2 = (object)SEQ_PTR(_44forward_references_63197);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _44forward_references_63197 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_31897))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_31897)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _31897);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = 0;
        DeRef(_1);

        /** fwdref.e:1067			if fr[FR_SUBPROG] = shifting_sub then*/
        _2 = (object)SEQ_PTR(_fr_64856);
        _31898 = (object)*(((s1_ptr)_2)->base + 4);
        if (binary_op_a(NOTEQ, _31898, _44shifting_sub_63216)){
            _31898 = NOVALUE;
            goto L3; // [53] 126
        }
        _31898 = NOVALUE;

        /** fwdref.e:1068				if fr[FR_PC] >= pc then*/
        _2 = (object)SEQ_PTR(_fr_64856);
        _31900 = (object)*(((s1_ptr)_2)->base + 5);
        if (binary_op_a(LESS, _31900, _pc_64851)){
            _31900 = NOVALUE;
            goto L4; // [63] 125
        }
        _31900 = NOVALUE;

        /** fwdref.e:1069					fr[FR_PC] += amount*/
        _2 = (object)SEQ_PTR(_fr_64856);
        _31902 = (object)*(((s1_ptr)_2)->base + 5);
        if (IS_ATOM_INT(_31902)) {
            _31903 = _31902 + _amount_64852;
            if ((object)((uintptr_t)_31903 + (uintptr_t)HIGH_BITS) >= 0){
                _31903 = NewDouble((eudouble)_31903);
            }
        }
        else {
            _31903 = binary_op(PLUS, _31902, _amount_64852);
        }
        _31902 = NOVALUE;
        _2 = (object)SEQ_PTR(_fr_64856);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _fr_64856 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 5);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _31903;
        if( _1 != _31903 ){
            DeRef(_1);
        }
        _31903 = NOVALUE;

        /** fwdref.e:1070					if fr[FR_TYPE] = CASE*/
        _2 = (object)SEQ_PTR(_fr_64856);
        _31904 = (object)*(((s1_ptr)_2)->base + 1);
        if (IS_ATOM_INT(_31904)) {
            _31905 = (_31904 == 186);
        }
        else {
            _31905 = binary_op(EQUALS, _31904, 186);
        }
        _31904 = NOVALUE;
        if (IS_ATOM_INT(_31905)) {
            if (_31905 == 0) {
                goto L5; // [93] 124
            }
        }
        else {
            if (DBL_PTR(_31905)->dbl == 0.0) {
                goto L5; // [93] 124
            }
        }
        _2 = (object)SEQ_PTR(_fr_64856);
        _31907 = (object)*(((s1_ptr)_2)->base + 12);
        if (IS_ATOM_INT(_31907)) {
            _31908 = (_31907 >= _pc_64851);
        }
        else {
            _31908 = binary_op(GREATEREQ, _31907, _pc_64851);
        }
        _31907 = NOVALUE;
        if (_31908 == 0) {
            DeRef(_31908);
            _31908 = NOVALUE;
            goto L5; // [106] 124
        }
        else {
            if (!IS_ATOM_INT(_31908) && DBL_PTR(_31908)->dbl == 0.0){
                DeRef(_31908);
                _31908 = NOVALUE;
                goto L5; // [106] 124
            }
            DeRef(_31908);
            _31908 = NOVALUE;
        }
        DeRef(_31908);
        _31908 = NOVALUE;

        /** fwdref.e:1073						fr[FR_DATA] += amount*/
        _2 = (object)SEQ_PTR(_fr_64856);
        _31909 = (object)*(((s1_ptr)_2)->base + 12);
        if (IS_ATOM_INT(_31909)) {
            _31910 = _31909 + _amount_64852;
            if ((object)((uintptr_t)_31910 + (uintptr_t)HIGH_BITS) >= 0){
                _31910 = NewDouble((eudouble)_31910);
            }
        }
        else {
            _31910 = binary_op(PLUS, _31909, _amount_64852);
        }
        _31909 = NOVALUE;
        _2 = (object)SEQ_PTR(_fr_64856);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _fr_64856 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 12);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _31910;
        if( _1 != _31910 ){
            DeRef(_1);
        }
        _31910 = NOVALUE;
L5: 
L4: 
L3: 

        /** fwdref.e:1077			forward_references[refs[i]] = fr*/
        _2 = (object)SEQ_PTR(_refs_64850);
        _31911 = (object)*(((s1_ptr)_2)->base + _i_64854);
        RefDS(_fr_64856);
        _2 = (object)SEQ_PTR(_44forward_references_63197);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _44forward_references_63197 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_31911))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_31911)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _31911);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _fr_64856;
        DeRef(_1);
        DeRefDS(_fr_64856);
        _fr_64856 = NOVALUE;

        /** fwdref.e:1078		end for*/
        _i_64854 = _i_64854 + -1;
        goto L1; // [142] 19
L2: 
        ;
    }

    /** fwdref.e:1079	end procedure*/
    DeRefDS(_refs_64850);
    DeRef(_31905);
    _31905 = NOVALUE;
    _31897 = NOVALUE;
    _31895 = NOVALUE;
    _31911 = NOVALUE;
    return;
    ;
}


void _44shift_top(object _refs_64880, object _pc_64881, object _amount_64882)
{
    object _fr_64886 = NOVALUE;
    object _31927 = NOVALUE;
    object _31926 = NOVALUE;
    object _31925 = NOVALUE;
    object _31924 = NOVALUE;
    object _31923 = NOVALUE;
    object _31922 = NOVALUE;
    object _31921 = NOVALUE;
    object _31920 = NOVALUE;
    object _31919 = NOVALUE;
    object _31918 = NOVALUE;
    object _31916 = NOVALUE;
    object _31915 = NOVALUE;
    object _31913 = NOVALUE;
    object _31912 = NOVALUE;
    object _0, _1, _2;
    

    /** fwdref.e:1083		for i = length( refs ) to 1 by -1 do*/
    if (IS_SEQUENCE(_refs_64880)){
            _31912 = SEQ_PTR(_refs_64880)->length;
    }
    else {
        _31912 = 1;
    }
    {
        object _i_64884;
        _i_64884 = _31912;
L1: 
        if (_i_64884 < 1){
            goto L2; // [12] 134
        }

        /** fwdref.e:1084			sequence fr = forward_references[refs[i]]*/
        _2 = (object)SEQ_PTR(_refs_64880);
        _31913 = (object)*(((s1_ptr)_2)->base + _i_64884);
        DeRef(_fr_64886);
        _2 = (object)SEQ_PTR(_44forward_references_63197);
        if (!IS_ATOM_INT(_31913)){
            _fr_64886 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31913)->dbl));
        }
        else{
            _fr_64886 = (object)*(((s1_ptr)_2)->base + _31913);
        }
        Ref(_fr_64886);

        /** fwdref.e:1085			forward_references[refs[i]] = 0*/
        _2 = (object)SEQ_PTR(_refs_64880);
        _31915 = (object)*(((s1_ptr)_2)->base + _i_64884);
        _2 = (object)SEQ_PTR(_44forward_references_63197);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _44forward_references_63197 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_31915))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_31915)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _31915);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = 0;
        DeRef(_1);

        /** fwdref.e:1086			if fr[FR_PC] >= pc then*/
        _2 = (object)SEQ_PTR(_fr_64886);
        _31916 = (object)*(((s1_ptr)_2)->base + 5);
        if (binary_op_a(LESS, _31916, _pc_64881)){
            _31916 = NOVALUE;
            goto L3; // [51] 113
        }
        _31916 = NOVALUE;

        /** fwdref.e:1087				fr[FR_PC] += amount*/
        _2 = (object)SEQ_PTR(_fr_64886);
        _31918 = (object)*(((s1_ptr)_2)->base + 5);
        if (IS_ATOM_INT(_31918)) {
            _31919 = _31918 + _amount_64882;
            if ((object)((uintptr_t)_31919 + (uintptr_t)HIGH_BITS) >= 0){
                _31919 = NewDouble((eudouble)_31919);
            }
        }
        else {
            _31919 = binary_op(PLUS, _31918, _amount_64882);
        }
        _31918 = NOVALUE;
        _2 = (object)SEQ_PTR(_fr_64886);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _fr_64886 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 5);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _31919;
        if( _1 != _31919 ){
            DeRef(_1);
        }
        _31919 = NOVALUE;

        /** fwdref.e:1088				if fr[FR_TYPE] = CASE*/
        _2 = (object)SEQ_PTR(_fr_64886);
        _31920 = (object)*(((s1_ptr)_2)->base + 1);
        if (IS_ATOM_INT(_31920)) {
            _31921 = (_31920 == 186);
        }
        else {
            _31921 = binary_op(EQUALS, _31920, 186);
        }
        _31920 = NOVALUE;
        if (IS_ATOM_INT(_31921)) {
            if (_31921 == 0) {
                goto L4; // [81] 112
            }
        }
        else {
            if (DBL_PTR(_31921)->dbl == 0.0) {
                goto L4; // [81] 112
            }
        }
        _2 = (object)SEQ_PTR(_fr_64886);
        _31923 = (object)*(((s1_ptr)_2)->base + 12);
        if (IS_ATOM_INT(_31923)) {
            _31924 = (_31923 >= _pc_64881);
        }
        else {
            _31924 = binary_op(GREATEREQ, _31923, _pc_64881);
        }
        _31923 = NOVALUE;
        if (_31924 == 0) {
            DeRef(_31924);
            _31924 = NOVALUE;
            goto L4; // [94] 112
        }
        else {
            if (!IS_ATOM_INT(_31924) && DBL_PTR(_31924)->dbl == 0.0){
                DeRef(_31924);
                _31924 = NOVALUE;
                goto L4; // [94] 112
            }
            DeRef(_31924);
            _31924 = NOVALUE;
        }
        DeRef(_31924);
        _31924 = NOVALUE;

        /** fwdref.e:1091					fr[FR_DATA] += amount*/
        _2 = (object)SEQ_PTR(_fr_64886);
        _31925 = (object)*(((s1_ptr)_2)->base + 12);
        if (IS_ATOM_INT(_31925)) {
            _31926 = _31925 + _amount_64882;
            if ((object)((uintptr_t)_31926 + (uintptr_t)HIGH_BITS) >= 0){
                _31926 = NewDouble((eudouble)_31926);
            }
        }
        else {
            _31926 = binary_op(PLUS, _31925, _amount_64882);
        }
        _31925 = NOVALUE;
        _2 = (object)SEQ_PTR(_fr_64886);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _fr_64886 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 12);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _31926;
        if( _1 != _31926 ){
            DeRef(_1);
        }
        _31926 = NOVALUE;
L4: 
L3: 

        /** fwdref.e:1094			forward_references[refs[i]] = fr*/
        _2 = (object)SEQ_PTR(_refs_64880);
        _31927 = (object)*(((s1_ptr)_2)->base + _i_64884);
        RefDS(_fr_64886);
        _2 = (object)SEQ_PTR(_44forward_references_63197);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _44forward_references_63197 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_31927))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_31927)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _31927);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _fr_64886;
        DeRef(_1);
        DeRefDS(_fr_64886);
        _fr_64886 = NOVALUE;

        /** fwdref.e:1095		end for*/
        _i_64884 = _i_64884 + -1;
        goto L1; // [129] 19
L2: 
        ;
    }

    /** fwdref.e:1096	end procedure*/
    DeRefDS(_refs_64880);
    _31927 = NOVALUE;
    _31913 = NOVALUE;
    DeRef(_31921);
    _31921 = NOVALUE;
    _31915 = NOVALUE;
    return;
    ;
}


void _44shift_fwd_refs(object _pc_64907, object _amount_64908)
{
    object _file_64919 = NOVALUE;
    object _sp_64924 = NOVALUE;
    object _31937 = NOVALUE;
    object _31936 = NOVALUE;
    object _31934 = NOVALUE;
    object _31932 = NOVALUE;
    object _31931 = NOVALUE;
    object _31930 = NOVALUE;
    object _0, _1, _2;
    

    /** fwdref.e:1099		if not shifting_sub then*/
    if (_44shifting_sub_63216 != 0)
    goto L1; // [9] 18

    /** fwdref.e:1100			return*/
    return;
L1: 

    /** fwdref.e:1103		if shifting_sub = TopLevelSub then*/
    if (_44shifting_sub_63216 != _36TopLevelSub_21774)
    goto L2; // [24] 65

    /** fwdref.e:1104			for file = 1 to length( toplevel_references ) do*/
    if (IS_SEQUENCE(_44toplevel_references_63200)){
            _31930 = SEQ_PTR(_44toplevel_references_63200)->length;
    }
    else {
        _31930 = 1;
    }
    {
        object _file_64915;
        _file_64915 = 1;
L3: 
        if (_file_64915 > _31930){
            goto L4; // [35] 62
        }

        /** fwdref.e:1105				shift_top( toplevel_references[file], pc, amount )*/
        _2 = (object)SEQ_PTR(_44toplevel_references_63200);
        _31931 = (object)*(((s1_ptr)_2)->base + _file_64915);
        Ref(_31931);
        _44shift_top(_31931, _pc_64907, _amount_64908);
        _31931 = NOVALUE;

        /** fwdref.e:1106			end for*/
        _file_64915 = _file_64915 + 1;
        goto L3; // [57] 42
L4: 
        ;
    }
    goto L5; // [62] 118
L2: 

    /** fwdref.e:1108			integer file = SymTab[shifting_sub][S_FILE_NO]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _31932 = (object)*(((s1_ptr)_2)->base + _44shifting_sub_63216);
    _2 = (object)SEQ_PTR(_31932);
    if (!IS_ATOM_INT(_36S_FILE_NO_21400)){
        _file_64919 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21400)->dbl));
    }
    else{
        _file_64919 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21400);
    }
    if (!IS_ATOM_INT(_file_64919)){
        _file_64919 = (object)DBL_PTR(_file_64919)->dbl;
    }
    _31932 = NOVALUE;

    /** fwdref.e:1109			integer sp   = find( shifting_sub, active_subprogs[file] )*/
    _2 = (object)SEQ_PTR(_44active_subprogs_63198);
    _31934 = (object)*(((s1_ptr)_2)->base + _file_64919);
    _sp_64924 = find_from(_44shifting_sub_63216, _31934, 1);
    _31934 = NOVALUE;

    /** fwdref.e:1110			shift_these( active_references[file][sp], pc, amount )*/
    _2 = (object)SEQ_PTR(_44active_references_63199);
    _31936 = (object)*(((s1_ptr)_2)->base + _file_64919);
    _2 = (object)SEQ_PTR(_31936);
    _31937 = (object)*(((s1_ptr)_2)->base + _sp_64924);
    _31936 = NOVALUE;
    Ref(_31937);
    _44shift_these(_31937, _pc_64907, _amount_64908);
    _31937 = NOVALUE;
L5: 

    /** fwdref.e:1112	end procedure*/
    return;
    ;
}



// 0x30A12BDD
