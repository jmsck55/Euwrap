// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _64is_file_newer(object _f1_24362, object _f2_24363)
{
    object _d1_24364 = NOVALUE;
    object _d2_24367 = NOVALUE;
    object _diff_2__tmp_at33_24376 = NOVALUE;
    object _diff_1__tmp_at33_24375 = NOVALUE;
    object _diff_inlined_diff_at_33_24374 = NOVALUE;
    object _13713 = NOVALUE;
    object _0, _1, _2;
    

    /** preproc.e:22		object d1 = file_timestamp(f1)*/
    RefDS(_f1_24362);
    _0 = _d1_24364;
    _d1_24364 = _17file_timestamp(_f1_24362);
    DeRef(_0);

    /** preproc.e:23		object d2 = file_timestamp(f2)*/
    RefDS(_f2_24363);
    _0 = _d2_24367;
    _d2_24367 = _17file_timestamp(_f2_24363);
    DeRef(_0);

    /** preproc.e:25		if atom(d2) then return 1 end if*/
    _13713 = IS_ATOM(_d2_24367);
    if (_13713 == 0)
    {
        _13713 = NOVALUE;
        goto L1; // [22] 30
    }
    else{
        _13713 = NOVALUE;
    }
    DeRefDS(_f1_24362);
    DeRefDS(_f2_24363);
    DeRef(_d1_24364);
    DeRef(_d2_24367);
    return 1;
L1: 

    /** preproc.e:27		if dt:diff(d1, d2) < 0 then*/

    /** datetime.e:1253		return datetimeToSeconds(dt2) - datetimeToSeconds(dt1)*/
    Ref(_d2_24367);
    _0 = _diff_1__tmp_at33_24375;
    _diff_1__tmp_at33_24375 = _18datetimeToSeconds(_d2_24367);
    DeRef(_0);
    Ref(_d1_24364);
    _0 = _diff_2__tmp_at33_24376;
    _diff_2__tmp_at33_24376 = _18datetimeToSeconds(_d1_24364);
    DeRef(_0);
    DeRef(_diff_inlined_diff_at_33_24374);
    if (IS_ATOM_INT(_diff_1__tmp_at33_24375) && IS_ATOM_INT(_diff_2__tmp_at33_24376)) {
        _diff_inlined_diff_at_33_24374 = _diff_1__tmp_at33_24375 - _diff_2__tmp_at33_24376;
        if ((object)((uintptr_t)_diff_inlined_diff_at_33_24374 +(uintptr_t) HIGH_BITS) >= 0){
            _diff_inlined_diff_at_33_24374 = NewDouble((eudouble)_diff_inlined_diff_at_33_24374);
        }
    }
    else {
        _diff_inlined_diff_at_33_24374 = binary_op(MINUS, _diff_1__tmp_at33_24375, _diff_2__tmp_at33_24376);
    }
    DeRef(_diff_1__tmp_at33_24375);
    _diff_1__tmp_at33_24375 = NOVALUE;
    DeRef(_diff_2__tmp_at33_24376);
    _diff_2__tmp_at33_24376 = NOVALUE;
    if (binary_op_a(GREATEREQ, _diff_inlined_diff_at_33_24374, 0)){
        goto L2; // [49] 60
    }

    /** preproc.e:28			return 1*/
    DeRefDS(_f1_24362);
    DeRefDS(_f2_24363);
    DeRef(_d1_24364);
    DeRef(_d2_24367);
    return 1;
L2: 

    /** preproc.e:31		return 0*/
    DeRefDS(_f1_24362);
    DeRefDS(_f2_24363);
    DeRef(_d1_24364);
    DeRef(_d2_24367);
    return 0;
    ;
}


void _64add_preprocessor(object _file_ext_24380, object _command_24381, object _params_24382)
{
    object _tmp_24385 = NOVALUE;
    object _file_exts_24395 = NOVALUE;
    object _exts_24401 = NOVALUE;
    object _13730 = NOVALUE;
    object _13729 = NOVALUE;
    object _13728 = NOVALUE;
    object _13727 = NOVALUE;
    object _13725 = NOVALUE;
    object _13720 = NOVALUE;
    object _13715 = NOVALUE;
    object _0, _1, _2;
    

    /** preproc.e:46		if atom(command) then*/
    _13715 = 1;
    if (_13715 == 0)
    {
        _13715 = NOVALUE;
        goto L1; // [8] 53
    }
    else{
        _13715 = NOVALUE;
    }

    /** preproc.e:47			sequence tmp = split( file_ext, ":")*/
    RefDS(_file_ext_24380);
    RefDS(_13716);
    _0 = _tmp_24385;
    _tmp_24385 = _23split(_file_ext_24380, _13716, 0, 0);
    DeRef(_0);

    /** preproc.e:48			file_ext = tmp[1]*/
    DeRefDS(_file_ext_24380);
    _2 = (object)SEQ_PTR(_tmp_24385);
    _file_ext_24380 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_file_ext_24380);

    /** preproc.e:49			command = tmp[2]*/
    _2 = (object)SEQ_PTR(_tmp_24385);
    _command_24381 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_command_24381);

    /** preproc.e:50			if length(tmp) >= 3 then*/
    if (IS_SEQUENCE(_tmp_24385)){
            _13720 = SEQ_PTR(_tmp_24385)->length;
    }
    else {
        _13720 = 1;
    }
    if (_13720 < 3)
    goto L2; // [41] 52

    /** preproc.e:51				params = tmp[3]*/
    _2 = (object)SEQ_PTR(_tmp_24385);
    _params_24382 = (object)*(((s1_ptr)_2)->base + 3);
    Ref(_params_24382);
L2: 
L1: 
    DeRef(_tmp_24385);
    _tmp_24385 = NOVALUE;

    /** preproc.e:55		sequence file_exts = split( file_ext, "," )*/
    RefDS(_file_ext_24380);
    RefDS(_13723);
    _0 = _file_exts_24395;
    _file_exts_24395 = _23split(_file_ext_24380, _13723, 0, 0);
    DeRef(_0);

    /** preproc.e:57		if atom(params) then*/
    _13725 = IS_ATOM(_params_24382);
    if (_13725 == 0)
    {
        _13725 = NOVALUE;
        goto L3; // [71] 80
    }
    else{
        _13725 = NOVALUE;
    }

    /** preproc.e:58			params = ""*/
    RefDS(_5);
    DeRef(_params_24382);
    _params_24382 = _5;
L3: 

    /** preproc.e:61		sequence exts = split(file_ext, ",")*/
    RefDS(_file_ext_24380);
    RefDS(_13723);
    _0 = _exts_24401;
    _exts_24401 = _23split(_file_ext_24380, _13723, 0, 0);
    DeRef(_0);

    /** preproc.e:62		for i = 1 to length(exts) do*/
    if (IS_SEQUENCE(_exts_24401)){
            _13727 = SEQ_PTR(_exts_24401)->length;
    }
    else {
        _13727 = 1;
    }
    {
        object _i_24405;
        _i_24405 = 1;
L4: 
        if (_i_24405 > _13727){
            goto L5; // [96] 135
        }

        /** preproc.e:63			preprocessors &= { { exts[i], command, params, -1 } }*/
        _2 = (object)SEQ_PTR(_exts_24401);
        _13728 = (object)*(((s1_ptr)_2)->base + _i_24405);
        _1 = NewS1(4);
        _2 = (object)((s1_ptr)_1)->base;
        Ref(_13728);
        ((intptr_t*)_2)[1] = _13728;
        Ref(_command_24381);
        ((intptr_t*)_2)[2] = _command_24381;
        Ref(_params_24382);
        ((intptr_t*)_2)[3] = _params_24382;
        ((intptr_t*)_2)[4] = -1;
        _13729 = MAKE_SEQ(_1);
        _13728 = NOVALUE;
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _13729;
        _13730 = MAKE_SEQ(_1);
        _13729 = NOVALUE;
        Concat((object_ptr)&_37preprocessors_15654, _37preprocessors_15654, _13730);
        DeRefDS(_13730);
        _13730 = NOVALUE;

        /** preproc.e:64		end for*/
        _i_24405 = _i_24405 + 1;
        goto L4; // [130] 103
L5: 
        ;
    }

    /** preproc.e:65	end procedure */
    DeRefDS(_file_ext_24380);
    DeRef(_command_24381);
    DeRef(_params_24382);
    DeRef(_file_exts_24395);
    DeRef(_exts_24401);
    return;
    ;
}


object _64maybe_preprocess(object _fname_24414)
{
    object _pp_24415 = NOVALUE;
    object _pp_id_24416 = NOVALUE;
    object _fext_24420 = NOVALUE;
    object _post_fname_24437 = NOVALUE;
    object _rid_24465 = NOVALUE;
    object _dll_id_24469 = NOVALUE;
    object _public_cmd_args_24505 = NOVALUE;
    object _cmd_args_24508 = NOVALUE;
    object _cmd_24537 = NOVALUE;
    object _pcmd_24542 = NOVALUE;
    object _result_24547 = NOVALUE;
    object _13809 = NOVALUE;
    object _13808 = NOVALUE;
    object _13803 = NOVALUE;
    object _13802 = NOVALUE;
    object _13800 = NOVALUE;
    object _13799 = NOVALUE;
    object _13797 = NOVALUE;
    object _13795 = NOVALUE;
    object _13794 = NOVALUE;
    object _13792 = NOVALUE;
    object _13789 = NOVALUE;
    object _13787 = NOVALUE;
    object _13785 = NOVALUE;
    object _13783 = NOVALUE;
    object _13782 = NOVALUE;
    object _13780 = NOVALUE;
    object _13779 = NOVALUE;
    object _13777 = NOVALUE;
    object _13774 = NOVALUE;
    object _13773 = NOVALUE;
    object _13772 = NOVALUE;
    object _13770 = NOVALUE;
    object _13766 = NOVALUE;
    object _13764 = NOVALUE;
    object _13763 = NOVALUE;
    object _13762 = NOVALUE;
    object _13758 = NOVALUE;
    object _13755 = NOVALUE;
    object _13754 = NOVALUE;
    object _13753 = NOVALUE;
    object _13751 = NOVALUE;
    object _13748 = NOVALUE;
    object _13746 = NOVALUE;
    object _13745 = NOVALUE;
    object _13743 = NOVALUE;
    object _13741 = NOVALUE;
    object _13739 = NOVALUE;
    object _13737 = NOVALUE;
    object _13736 = NOVALUE;
    object _13735 = NOVALUE;
    object _13734 = NOVALUE;
    object _13732 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** preproc.e:81		sequence pp = {}*/
    RefDS(_5);
    DeRef(_pp_24415);
    _pp_24415 = _5;

    /** preproc.e:84		if length(preprocessors) then*/
    if (IS_SEQUENCE(_37preprocessors_15654)){
            _13732 = SEQ_PTR(_37preprocessors_15654)->length;
    }
    else {
        _13732 = 1;
    }
    if (_13732 == 0)
    {
        _13732 = NOVALUE;
        goto L1; // [17] 89
    }
    else{
        _13732 = NOVALUE;
    }

    /** preproc.e:85			sequence fext = fileext(fname)*/
    RefDS(_fname_24414);
    _0 = _fext_24420;
    _fext_24420 = _17fileext(_fname_24414);
    DeRef(_0);

    /** preproc.e:87			for i = 1 to length(preprocessors) do*/
    if (IS_SEQUENCE(_37preprocessors_15654)){
            _13734 = SEQ_PTR(_37preprocessors_15654)->length;
    }
    else {
        _13734 = 1;
    }
    {
        object _i_24424;
        _i_24424 = 1;
L2: 
        if (_i_24424 > _13734){
            goto L3; // [35] 88
        }

        /** preproc.e:88				if equal(fext, preprocessors[i][1]) then*/
        _2 = (object)SEQ_PTR(_37preprocessors_15654);
        _13735 = (object)*(((s1_ptr)_2)->base + _i_24424);
        _2 = (object)SEQ_PTR(_13735);
        _13736 = (object)*(((s1_ptr)_2)->base + 1);
        _13735 = NOVALUE;
        if (_fext_24420 == _13736)
        _13737 = 1;
        else if (IS_ATOM_INT(_fext_24420) && IS_ATOM_INT(_13736))
        _13737 = 0;
        else
        _13737 = (compare(_fext_24420, _13736) == 0);
        _13736 = NOVALUE;
        if (_13737 == 0)
        {
            _13737 = NOVALUE;
            goto L4; // [58] 81
        }
        else{
            _13737 = NOVALUE;
        }

        /** preproc.e:89					pp_id = i*/
        _pp_id_24416 = _i_24424;

        /** preproc.e:90					pp = preprocessors[pp_id]*/
        DeRef(_pp_24415);
        _2 = (object)SEQ_PTR(_37preprocessors_15654);
        _pp_24415 = (object)*(((s1_ptr)_2)->base + _pp_id_24416);
        RefDS(_pp_24415);

        /** preproc.e:91					exit*/
        goto L3; // [78] 88
L4: 

        /** preproc.e:93			end for*/
        _i_24424 = _i_24424 + 1;
        goto L2; // [83] 42
L3: 
        ;
    }
L1: 
    DeRef(_fext_24420);
    _fext_24420 = NOVALUE;

    /** preproc.e:96		if length(pp) = 0 then */
    if (IS_SEQUENCE(_pp_24415)){
            _13739 = SEQ_PTR(_pp_24415)->length;
    }
    else {
        _13739 = 1;
    }
    if (_13739 != 0)
    goto L5; // [96] 107

    /** preproc.e:97			return fname*/
    DeRefDS(_pp_24415);
    DeRef(_post_fname_24437);
    return _fname_24414;
L5: 

    /** preproc.e:100		sequence post_fname = filebase(fname) & ".pp." & fileext(fname)*/
    RefDS(_fname_24414);
    _13741 = _17filebase(_fname_24414);
    RefDS(_fname_24414);
    _13743 = _17fileext(_fname_24414);
    {
        object concat_list[3];

        concat_list[0] = _13743;
        concat_list[1] = _13742;
        concat_list[2] = _13741;
        Concat_N((object_ptr)&_post_fname_24437, concat_list, 3);
    }
    DeRef(_13743);
    _13743 = NOVALUE;
    DeRef(_13741);
    _13741 = NOVALUE;

    /** preproc.e:101		if length(dirname(fname)) > 0 then*/
    RefDS(_fname_24414);
    _13745 = _17dirname(_fname_24414, 0);
    if (IS_SEQUENCE(_13745)){
            _13746 = SEQ_PTR(_13745)->length;
    }
    else {
        _13746 = 1;
    }
    DeRef(_13745);
    _13745 = NOVALUE;
    if (_13746 <= 0)
    goto L6; // [133] 153

    /** preproc.e:102			post_fname = dirname(fname) & SLASH & post_fname*/
    RefDS(_fname_24414);
    _13748 = _17dirname(_fname_24414, 0);
    {
        object concat_list[3];

        concat_list[0] = _post_fname_24437;
        concat_list[1] = 92;
        concat_list[2] = _13748;
        Concat_N((object_ptr)&_post_fname_24437, concat_list, 3);
    }
    DeRef(_13748);
    _13748 = NOVALUE;
L6: 

    /** preproc.e:105		if not force_preprocessor then*/
    if (_37force_preprocessor_15655 != 0)
    goto L7; // [157] 178

    /** preproc.e:106			if not is_file_newer(fname, post_fname) then*/
    RefDS(_fname_24414);
    RefDS(_post_fname_24437);
    _13751 = _64is_file_newer(_fname_24414, _post_fname_24437);
    if (IS_ATOM_INT(_13751)) {
        if (_13751 != 0){
            DeRef(_13751);
            _13751 = NOVALUE;
            goto L8; // [167] 177
        }
    }
    else {
        if (DBL_PTR(_13751)->dbl != 0.0){
            DeRef(_13751);
            _13751 = NOVALUE;
            goto L8; // [167] 177
        }
    }
    DeRef(_13751);
    _13751 = NOVALUE;

    /** preproc.e:107				return post_fname*/
    DeRefDS(_fname_24414);
    DeRef(_pp_24415);
    _13745 = NOVALUE;
    return _post_fname_24437;
L8: 
L7: 

    /** preproc.e:112		if equal(fileext(pp[PP_COMMAND]), SHARED_LIB_EXT) then*/
    _2 = (object)SEQ_PTR(_pp_24415);
    _13753 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_13753);
    _13754 = _17fileext(_13753);
    _13753 = NOVALUE;
    if (_13754 == _17SHARED_LIB_EXT_6042)
    _13755 = 1;
    else if (IS_ATOM_INT(_13754) && IS_ATOM_INT(_17SHARED_LIB_EXT_6042))
    _13755 = 0;
    else
    _13755 = (compare(_13754, _17SHARED_LIB_EXT_6042) == 0);
    DeRef(_13754);
    _13754 = NOVALUE;
    if (_13755 == 0)
    {
        _13755 = NOVALUE;
        goto L9; // [194] 348
    }
    else{
        _13755 = NOVALUE;
    }

    /** preproc.e:113			integer rid = pp[PP_RID]*/
    _2 = (object)SEQ_PTR(_pp_24415);
    _rid_24465 = (object)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_rid_24465))
    _rid_24465 = (object)DBL_PTR(_rid_24465)->dbl;

    /** preproc.e:114			if rid = -1 then*/
    if (_rid_24465 != -1)
    goto LA; // [205] 307

    /** preproc.e:115				integer dll_id = open_dll(pp[PP_COMMAND])*/
    _2 = (object)SEQ_PTR(_pp_24415);
    _13758 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_13758);
    _dll_id_24469 = _12open_dll(_13758);
    _13758 = NOVALUE;
    if (!IS_ATOM_INT(_dll_id_24469)) {
        _1 = (object)(DBL_PTR(_dll_id_24469)->dbl);
        DeRefDS(_dll_id_24469);
        _dll_id_24469 = _1;
    }

    /** preproc.e:116				if dll_id = -1 then*/
    if (_dll_id_24469 != -1)
    goto LB; // [223] 247

    /** preproc.e:117					CompileErr(sprintf("Preprocessor shared library '%s' could not be loaded\n",*/
    _2 = (object)SEQ_PTR(_pp_24415);
    _13762 = (object)*(((s1_ptr)_2)->base + 2);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_13762);
    ((intptr_t*)_2)[1] = _13762;
    _13763 = MAKE_SEQ(_1);
    _13762 = NOVALUE;
    _13764 = EPrintf(-9999999, _13761, _13763);
    DeRefDS(_13763);
    _13763 = NOVALUE;
    RefDS(_22190);
    _50CompileErr(_13764, _22190, 1);
    _13764 = NOVALUE;
LB: 

    /** preproc.e:121				rid = define_c_func(dll_id, "preprocess", { E_SEQUENCE, E_SEQUENCE, E_SEQUENCE }, */
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 134217732;
    ((intptr_t*)_2)[2] = 134217732;
    ((intptr_t*)_2)[3] = 134217732;
    _13766 = MAKE_SEQ(_1);
    RefDS(_13765);
    _rid_24465 = _12define_c_func(_dll_id_24469, _13765, _13766, 100663300);
    _13766 = NOVALUE;
    if (!IS_ATOM_INT(_rid_24465)) {
        _1 = (object)(DBL_PTR(_rid_24465)->dbl);
        DeRefDS(_rid_24465);
        _rid_24465 = _1;
    }

    /** preproc.e:123				if rid = -1 then*/
    if (_rid_24465 != -1)
    goto LC; // [274] 291

    /** preproc.e:124					CompileErr("Preprocessor entry point cound not be found\n",,1)*/
    RefDS(_13769);
    RefDS(_22190);
    _50CompileErr(_13769, _22190, 1);

    /** preproc.e:126					Cleanup(1)*/
    _50Cleanup(1);
LC: 

    /** preproc.e:129				preprocessors[pp_id][PP_RID] = rid*/
    _2 = (object)SEQ_PTR(_37preprocessors_15654);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37preprocessors_15654 = MAKE_SEQ(_2);
    }
    _3 = (object)(_pp_id_24416 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _rid_24465;
    DeRef(_1);
    _13770 = NOVALUE;
LA: 

    /** preproc.e:132			if c_func(rid, { fname, post_fname, pp[PP_PARAMS] }) != 0 then*/
    _2 = (object)SEQ_PTR(_pp_24415);
    _13772 = (object)*(((s1_ptr)_2)->base + 3);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_fname_24414);
    ((intptr_t*)_2)[1] = _fname_24414;
    RefDS(_post_fname_24437);
    ((intptr_t*)_2)[2] = _post_fname_24437;
    Ref(_13772);
    ((intptr_t*)_2)[3] = _13772;
    _13773 = MAKE_SEQ(_1);
    _13772 = NOVALUE;
    _13774 = call_c(1, _rid_24465, _13773);
    DeRefDS(_13773);
    _13773 = NOVALUE;
    if (binary_op_a(EQUALS, _13774, 0)){
        DeRef(_13774);
        _13774 = NOVALUE;
        goto LD; // [326] 343
    }
    DeRef(_13774);
    _13774 = NOVALUE;

    /** preproc.e:133				CompileErr("Preprocessor call failed\n",,1)*/
    RefDS(_13776);
    RefDS(_22190);
    _50CompileErr(_13776, _22190, 1);

    /** preproc.e:135				Cleanup(1)*/
    _50Cleanup(1);
LD: 
    goto LE; // [345] 520
L9: 

    /** preproc.e:138			sequence public_cmd_args = {pp[PP_COMMAND]}*/
    _2 = (object)SEQ_PTR(_pp_24415);
    _13777 = (object)*(((s1_ptr)_2)->base + 2);
    _0 = _public_cmd_args_24505;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_13777);
    ((intptr_t*)_2)[1] = _13777;
    _public_cmd_args_24505 = MAKE_SEQ(_1);
    DeRef(_0);
    _13777 = NOVALUE;

    /** preproc.e:139			sequence cmd_args = {canonical_path(pp[PP_COMMAND],,TO_SHORT)}*/
    _2 = (object)SEQ_PTR(_pp_24415);
    _13779 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_13779);
    _13780 = _17canonical_path(_13779, 0, 4);
    _13779 = NOVALUE;
    _0 = _cmd_args_24508;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _13780;
    _cmd_args_24508 = MAKE_SEQ(_1);
    DeRef(_0);
    _13780 = NOVALUE;

    /** preproc.e:141			if equal(fileext(pp[PP_COMMAND]), "ex") then*/
    _2 = (object)SEQ_PTR(_pp_24415);
    _13782 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_13782);
    _13783 = _17fileext(_13782);
    _13782 = NOVALUE;
    if (_13783 == _13784)
    _13785 = 1;
    else if (IS_ATOM_INT(_13783) && IS_ATOM_INT(_13784))
    _13785 = 0;
    else
    _13785 = (compare(_13783, _13784) == 0);
    DeRef(_13783);
    _13783 = NOVALUE;
    if (_13785 == 0)
    {
        _13785 = NOVALUE;
        goto LF; // [390] 414
    }
    else{
        _13785 = NOVALUE;
    }

    /** preproc.e:142				public_cmd_args = { "eui" } & public_cmd_args*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_13786);
    ((intptr_t*)_2)[1] = _13786;
    _13787 = MAKE_SEQ(_1);
    Concat((object_ptr)&_public_cmd_args_24505, _13787, _public_cmd_args_24505);
    DeRefDS(_13787);
    _13787 = NOVALUE;
    DeRef(_13787);
    _13787 = NOVALUE;

    /** preproc.e:143				cmd_args = { "eui" } & cmd_args*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_13786);
    ((intptr_t*)_2)[1] = _13786;
    _13789 = MAKE_SEQ(_1);
    Concat((object_ptr)&_cmd_args_24508, _13789, _cmd_args_24508);
    DeRefDS(_13789);
    _13789 = NOVALUE;
    DeRef(_13789);
    _13789 = NOVALUE;
LF: 

    /** preproc.e:146			cmd_args &= { "-i", canonical_path(fname,,TO_SHORT), "-o", canonical_path(post_fname,,TO_SHORT) }*/
    RefDS(_fname_24414);
    _13792 = _17canonical_path(_fname_24414, 0, 4);
    RefDS(_post_fname_24437);
    _13794 = _17canonical_path(_post_fname_24437, 0, 4);
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_13791);
    ((intptr_t*)_2)[1] = _13791;
    ((intptr_t*)_2)[2] = _13792;
    RefDS(_13793);
    ((intptr_t*)_2)[3] = _13793;
    ((intptr_t*)_2)[4] = _13794;
    _13795 = MAKE_SEQ(_1);
    _13794 = NOVALUE;
    _13792 = NOVALUE;
    Concat((object_ptr)&_cmd_args_24508, _cmd_args_24508, _13795);
    DeRefDS(_13795);
    _13795 = NOVALUE;

    /** preproc.e:147			public_cmd_args &= { "-i", fname, "-o", post_fname }*/
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_13791);
    ((intptr_t*)_2)[1] = _13791;
    RefDS(_fname_24414);
    ((intptr_t*)_2)[2] = _fname_24414;
    RefDS(_13793);
    ((intptr_t*)_2)[3] = _13793;
    RefDS(_post_fname_24437);
    ((intptr_t*)_2)[4] = _post_fname_24437;
    _13797 = MAKE_SEQ(_1);
    Concat((object_ptr)&_public_cmd_args_24505, _public_cmd_args_24505, _13797);
    DeRefDS(_13797);
    _13797 = NOVALUE;

    /** preproc.e:148			sequence cmd = build_commandline( cmd_args ) & pp[PP_PARAMS]*/
    RefDS(_cmd_args_24508);
    _13799 = _4build_commandline(_cmd_args_24508);
    _2 = (object)SEQ_PTR(_pp_24415);
    _13800 = (object)*(((s1_ptr)_2)->base + 3);
    if (IS_SEQUENCE(_13799) && IS_ATOM(_13800)) {
        Ref(_13800);
        Append(&_cmd_24537, _13799, _13800);
    }
    else if (IS_ATOM(_13799) && IS_SEQUENCE(_13800)) {
        Ref(_13799);
        Prepend(&_cmd_24537, _13800, _13799);
    }
    else {
        Concat((object_ptr)&_cmd_24537, _13799, _13800);
        DeRef(_13799);
        _13799 = NOVALUE;
    }
    DeRef(_13799);
    _13799 = NOVALUE;
    _13800 = NOVALUE;

    /** preproc.e:149			sequence pcmd = build_commandline(public_cmd_args) & pp[PP_PARAMS]*/
    RefDS(_public_cmd_args_24505);
    _13802 = _4build_commandline(_public_cmd_args_24505);
    _2 = (object)SEQ_PTR(_pp_24415);
    _13803 = (object)*(((s1_ptr)_2)->base + 3);
    if (IS_SEQUENCE(_13802) && IS_ATOM(_13803)) {
        Ref(_13803);
        Append(&_pcmd_24542, _13802, _13803);
    }
    else if (IS_ATOM(_13802) && IS_SEQUENCE(_13803)) {
        Ref(_13802);
        Prepend(&_pcmd_24542, _13803, _13802);
    }
    else {
        Concat((object_ptr)&_pcmd_24542, _13802, _13803);
        DeRef(_13802);
        _13802 = NOVALUE;
    }
    DeRef(_13802);
    _13802 = NOVALUE;
    _13803 = NOVALUE;

    /** preproc.e:150			integer result = system_exec(cmd, 2)*/
    _result_24547 = system_exec_call(_cmd_24537, 2);

    /** preproc.e:151			if result != 0 then*/
    if (_result_24547 == 0)
    goto L10; // [492] 517

    /** preproc.e:152				CompileErr(sprintf("Preprocessor command failed (%d): %s\n", { result, pcmd } ),,1)*/
    RefDS(_pcmd_24542);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _result_24547;
    ((intptr_t *)_2)[2] = _pcmd_24542;
    _13808 = MAKE_SEQ(_1);
    _13809 = EPrintf(-9999999, _13807, _13808);
    DeRefDS(_13808);
    _13808 = NOVALUE;
    RefDS(_22190);
    _50CompileErr(_13809, _22190, 1);
    _13809 = NOVALUE;

    /** preproc.e:154				Cleanup(1)*/
    _50Cleanup(1);
L10: 
    DeRef(_public_cmd_args_24505);
    _public_cmd_args_24505 = NOVALUE;
    DeRef(_cmd_args_24508);
    _cmd_args_24508 = NOVALUE;
    DeRef(_cmd_24537);
    _cmd_24537 = NOVALUE;
    DeRef(_pcmd_24542);
    _pcmd_24542 = NOVALUE;
LE: 

    /** preproc.e:158		return post_fname*/
    DeRefDS(_fname_24414);
    DeRef(_pp_24415);
    _13745 = NOVALUE;
    return _post_fname_24437;
    ;
}



// 0xC1B8F485
