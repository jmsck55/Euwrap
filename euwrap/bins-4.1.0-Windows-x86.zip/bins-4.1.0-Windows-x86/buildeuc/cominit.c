// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _49add_options(object _new_options_50083)
{
    object _0, _1, _2;
    

    /** cominit.e:65		options = splice(options, new_options, COMMON_OPTIONS_SPLICE_IDX)*/
    {
        s1_ptr assign_space;
        insert_pos = 16;
        if (insert_pos <= 0) {
            Concat(&_49options_50079,_new_options_50083,_49options_50079);
        }
        else if (insert_pos > SEQ_PTR(_49options_50079)->length){
            Concat(&_49options_50079,_49options_50079,_new_options_50083);
        }
        else if (IS_SEQUENCE(_new_options_50083)) {
            if( _49options_50079 != _49options_50079 || SEQ_PTR( _49options_50079 )->ref != 1 ){
                DeRef( _49options_50079 );
                RefDS( _49options_50079 );
            }
            assign_space = Add_internal_space( _49options_50079, insert_pos,((s1_ptr)SEQ_PTR(_new_options_50083))->length);
            assign_slice_seq = &assign_space;
            assign_space = Copy_elements( insert_pos, SEQ_PTR(_new_options_50083), _49options_50079 == _49options_50079 );
            _49options_50079 = MAKE_SEQ( assign_space );
        }
        else {
            if( _49options_50079 == _49options_50079 && SEQ_PTR( _49options_50079 )->ref == 1 ){
                _49options_50079 = Insert( _49options_50079, _new_options_50083, insert_pos);
            }
            else {
                DeRef( _49options_50079 );
                RefDS( _49options_50079 );
                _49options_50079 = Insert( _49options_50079, _new_options_50083, insert_pos);
            }
        }
    }

    /** cominit.e:67	end procedure*/
    DeRefDS(_new_options_50083);
    return;
    ;
}


object _49get_options()
{
    object _0, _1, _2;
    

    /** cominit.e:73		return options*/
    RefDS(_49options_50079);
    return _49options_50079;
    ;
}


object _49get_switches()
{
    object _0, _1, _2;
    

    /** cominit.e:87		return switches*/
    RefDS(_49switches_49952);
    return _49switches_49952;
    ;
}


void _49show_copyrights()
{
    object _notices_50093 = NOVALUE;
    object _25715 = NOVALUE;
    object _25714 = NOVALUE;
    object _25712 = NOVALUE;
    object _25711 = NOVALUE;
    object _25710 = NOVALUE;
    object _25709 = NOVALUE;
    object _25707 = NOVALUE;
    object _0, _1, _2;
    

    /** cominit.e:94		sequence notices = all_copyrights()*/
    _0 = _notices_50093;
    _notices_50093 = _33all_copyrights();
    DeRef(_0);

    /** cominit.e:95		for i = 1 to length(notices) do*/
    if (IS_SEQUENCE(_notices_50093)){
            _25707 = SEQ_PTR(_notices_50093)->length;
    }
    else {
        _25707 = 1;
    }
    {
        object _i_50097;
        _i_50097 = 1;
L1: 
        if (_i_50097 > _25707){
            goto L2; // [13] 60
        }

        /** cominit.e:96			printf(2, "%s\n  %s\n\n", { notices[i][1], match_replace("\n", notices[i][2], "\n  ") })*/
        _2 = (object)SEQ_PTR(_notices_50093);
        _25709 = (object)*(((s1_ptr)_2)->base + _i_50097);
        _2 = (object)SEQ_PTR(_25709);
        _25710 = (object)*(((s1_ptr)_2)->base + 1);
        _25709 = NOVALUE;
        _2 = (object)SEQ_PTR(_notices_50093);
        _25711 = (object)*(((s1_ptr)_2)->base + _i_50097);
        _2 = (object)SEQ_PTR(_25711);
        _25712 = (object)*(((s1_ptr)_2)->base + 2);
        _25711 = NOVALUE;
        RefDS(_22385);
        Ref(_25712);
        RefDS(_25713);
        _25714 = _16match_replace(_22385, _25712, _25713, 0);
        _25712 = NOVALUE;
        Ref(_25710);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _25710;
        ((intptr_t *)_2)[2] = _25714;
        _25715 = MAKE_SEQ(_1);
        _25714 = NOVALUE;
        _25710 = NOVALUE;
        EPrintf(2, _25708, _25715);
        DeRefDS(_25715);
        _25715 = NOVALUE;

        /** cominit.e:97		end for*/
        _i_50097 = _i_50097 + 1;
        goto L1; // [55] 20
L2: 
        ;
    }

    /** cominit.e:98	end procedure*/
    DeRef(_notices_50093);
    return;
    ;
}


void _49show_banner()
{
    object _version_type_inlined_version_type_at_220_50166 = NOVALUE;
    object _version_string_short_1__tmp_at204_50164 = NOVALUE;
    object _version_string_short_inlined_version_string_short_at_204_50163 = NOVALUE;
    object _version_revision_inlined_version_revision_at_133_50144 = NOVALUE;
    object _platform_name_inlined_platform_name_at_94_50136 = NOVALUE;
    object _prod_name_50110 = NOVALUE;
    object _memory_type_50111 = NOVALUE;
    object _misc_info_50133 = NOVALUE;
    object _EuConsole_50148 = NOVALUE;
    object _25740 = NOVALUE;
    object _25739 = NOVALUE;
    object _25738 = NOVALUE;
    object _25735 = NOVALUE;
    object _25734 = NOVALUE;
    object _25730 = NOVALUE;
    object _25729 = NOVALUE;
    object _25728 = NOVALUE;
    object _25726 = NOVALUE;
    object _25724 = NOVALUE;
    object _25723 = NOVALUE;
    object _25722 = NOVALUE;
    object _25717 = NOVALUE;
    object _25716 = NOVALUE;
    object _0, _1, _2;
    

    /** cominit.e:109		if INTERPRET and not BIND then*/
    if (_36INTERPRET_21366 == 0) {
        goto L1; // [5] 33
    }
    _25717 = (_36BIND_21372 == 0);
    if (_25717 == 0)
    {
        DeRef(_25717);
        _25717 = NOVALUE;
        goto L1; // [15] 33
    }
    else{
        DeRef(_25717);
        _25717 = NOVALUE;
    }

    /** cominit.e:110			prod_name = GetMsgText(EUPHORIA_INTERPRETER,0)*/
    RefDS(_22190);
    _0 = _prod_name_50110;
    _prod_name_50110 = _39GetMsgText(270, 0, _22190);
    DeRef(_0);
    goto L2; // [30] 76
L1: 

    /** cominit.e:112		elsif TRANSLATE then*/
    if (_36TRANSLATE_21369 == 0)
    {
        goto L3; // [37] 55
    }
    else{
    }

    /** cominit.e:113			prod_name = GetMsgText(EUPHORIA_TO_C_TRANSLATOR,0)*/
    RefDS(_22190);
    _0 = _prod_name_50110;
    _prod_name_50110 = _39GetMsgText(271, 0, _22190);
    DeRef(_0);
    goto L2; // [52] 76
L3: 

    /** cominit.e:115		elsif BIND then*/
    if (_36BIND_21372 == 0)
    {
        goto L4; // [59] 75
    }
    else{
    }

    /** cominit.e:116			prod_name = GetMsgText(EUPHORIA_BINDER,0)*/
    RefDS(_22190);
    _0 = _prod_name_50110;
    _prod_name_50110 = _39GetMsgText(272, 0, _22190);
    DeRef(_0);
L4: 
L2: 

    /** cominit.e:119		ifdef EU_MANAGED_MEM then*/

    /** cominit.e:122			memory_type = GetMsgText(USING_SYSTEM_MEMORY,0)*/
    RefDS(_22190);
    _0 = _memory_type_50111;
    _memory_type_50111 = _39GetMsgText(274, 0, _22190);
    DeRef(_0);

    /** cominit.e:125		sequence misc_info = {*/
    _25722 = _33arch_bits();

    /** info.e:48		ifdef WINDOWS then*/

    /** info.e:49			return "Windows"*/
    RefDS(_6769);
    DeRefi(_platform_name_inlined_platform_name_at_94_50136);
    _platform_name_inlined_platform_name_at_94_50136 = _6769;
    _25723 = _33version_date(0);
    _25724 = _33version_node(0);
    _0 = _misc_info_50133;
    _1 = NewS1(6);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _25722;
    RefDS(_platform_name_inlined_platform_name_at_94_50136);
    ((intptr_t*)_2)[2] = _platform_name_inlined_platform_name_at_94_50136;
    RefDS(_memory_type_50111);
    ((intptr_t*)_2)[3] = _memory_type_50111;
    RefDS(_22190);
    ((intptr_t*)_2)[4] = _22190;
    ((intptr_t*)_2)[5] = _25723;
    ((intptr_t*)_2)[6] = _25724;
    _misc_info_50133 = MAKE_SEQ(_1);
    DeRef(_0);
    _25724 = NOVALUE;
    _25723 = NOVALUE;
    _25722 = NOVALUE;

    /** cominit.e:134		if info:is_developmental then*/
    if (_33is_developmental_12087 == 0)
    {
        goto L5; // [126] 160
    }
    else{
    }

    /** cominit.e:135			misc_info[$] = sprintf("%d:%s", { info:version_revision(), info:version_node() })*/
    _25726 = 6;

    /** info.e:157		return version_info[REVISION]*/
    DeRef(_version_revision_inlined_version_revision_at_133_50144);
    _2 = (object)SEQ_PTR(_33version_info_12085);
    _version_revision_inlined_version_revision_at_133_50144 = (object)*(((s1_ptr)_2)->base + 6);
    Ref(_version_revision_inlined_version_revision_at_133_50144);
    _25728 = _33version_node(0);
    Ref(_version_revision_inlined_version_revision_at_133_50144);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _version_revision_inlined_version_revision_at_133_50144;
    ((intptr_t *)_2)[2] = _25728;
    _25729 = MAKE_SEQ(_1);
    _25728 = NOVALUE;
    _25730 = EPrintf(-9999999, _25727, _25729);
    DeRefDS(_25729);
    _25729 = NOVALUE;
    _2 = (object)SEQ_PTR(_misc_info_50133);
    _2 = (object)(((s1_ptr)_2)->base + 6);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _25730;
    if( _1 != _25730 ){
        DeRef(_1);
    }
    _25730 = NOVALUE;
L5: 

    /** cominit.e:138		object EuConsole = getenv("EUCONS")*/
    DeRefi(_EuConsole_50148);
    _EuConsole_50148 = EGetEnv(_25731);

    /** cominit.e:139		if equal(EuConsole, "1") then*/
    if (_EuConsole_50148 == _25733)
    _25734 = 1;
    else if (IS_ATOM_INT(_EuConsole_50148) && IS_ATOM_INT(_25733))
    _25734 = 0;
    else
    _25734 = (compare(_EuConsole_50148, _25733) == 0);
    if (_25734 == 0)
    {
        _25734 = NOVALUE;
        goto L6; // [171] 191
    }
    else{
        _25734 = NOVALUE;
    }

    /** cominit.e:140			misc_info[4] = GetMsgText(EUCONSOLE,0)*/
    RefDS(_22190);
    _25735 = _39GetMsgText(275, 0, _22190);
    _2 = (object)SEQ_PTR(_misc_info_50133);
    _2 = (object)(((s1_ptr)_2)->base + 4);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _25735;
    if( _1 != _25735 ){
        DeRef(_1);
    }
    _25735 = NOVALUE;
    goto L7; // [188] 199
L6: 

    /** cominit.e:142			misc_info = remove(misc_info, 4)*/
    {
        s1_ptr assign_space = SEQ_PTR(_misc_info_50133);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(4)) ? 4 : (object)(DBL_PTR(4)->dbl);
        int stop = (IS_ATOM_INT(4)) ? 4 : (object)(DBL_PTR(4)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_misc_info_50133), start, &_misc_info_50133 );
            }
            else Tail(SEQ_PTR(_misc_info_50133), stop+1, &_misc_info_50133);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_misc_info_50133), start, &_misc_info_50133);
        }
        else {
            assign_slice_seq = &assign_space;
            _misc_info_50133 = Remove_elements(start, stop, (SEQ_PTR(_misc_info_50133)->ref == 1));
        }
    }
L7: 

    /** cominit.e:145		screen_output(STDERR, sprintf("%s v%s %s\n   %s %s, %s\n   Revision Date: %s, Id: %s\n", {*/

    /** info.e:261		return sprintf("%d.%d.%d", version_info[MAJ_VER..PAT_VER])*/
    rhs_slice_target = (object_ptr)&_version_string_short_1__tmp_at204_50164;
    RHS_Slice(_33version_info_12085, 1, 3);
    DeRefi(_version_string_short_inlined_version_string_short_at_204_50163);
    _version_string_short_inlined_version_string_short_at_204_50163 = EPrintf(-9999999, _6827, _version_string_short_1__tmp_at204_50164);
    DeRef(_version_string_short_1__tmp_at204_50164);
    _version_string_short_1__tmp_at204_50164 = NOVALUE;

    /** info.e:202		return version_info[VER_TYPE]*/
    DeRef(_version_type_inlined_version_type_at_220_50166);
    _2 = (object)SEQ_PTR(_33version_info_12085);
    _version_type_inlined_version_type_at_220_50166 = (object)*(((s1_ptr)_2)->base + 4);
    Ref(_version_type_inlined_version_type_at_220_50166);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_prod_name_50110);
    ((intptr_t*)_2)[1] = _prod_name_50110;
    RefDS(_version_string_short_inlined_version_string_short_at_204_50163);
    ((intptr_t*)_2)[2] = _version_string_short_inlined_version_string_short_at_204_50163;
    Ref(_version_type_inlined_version_type_at_220_50166);
    ((intptr_t*)_2)[3] = _version_type_inlined_version_type_at_220_50166;
    _25738 = MAKE_SEQ(_1);
    Concat((object_ptr)&_25739, _25738, _misc_info_50133);
    DeRefDS(_25738);
    _25738 = NOVALUE;
    DeRef(_25738);
    _25738 = NOVALUE;
    _25740 = EPrintf(-9999999, _25737, _25739);
    DeRefDS(_25739);
    _25739 = NOVALUE;
    _50screen_output(2, _25740);
    _25740 = NOVALUE;

    /** cominit.e:147	end procedure*/
    DeRefDS(_prod_name_50110);
    DeRef(_memory_type_50111);
    DeRefDS(_misc_info_50133);
    DeRefi(_EuConsole_50148);
    return;
    ;
}


object _49find_opt(object _name_type_50178, object _opt_50179, object _opts_50180)
{
    object _o_50184 = NOVALUE;
    object _has_case_50186 = NOVALUE;
    object _25753 = NOVALUE;
    object _25752 = NOVALUE;
    object _25751 = NOVALUE;
    object _25750 = NOVALUE;
    object _25749 = NOVALUE;
    object _25748 = NOVALUE;
    object _25747 = NOVALUE;
    object _25746 = NOVALUE;
    object _25745 = NOVALUE;
    object _25743 = NOVALUE;
    object _25741 = NOVALUE;
    object _0, _1, _2;
    

    /** cominit.e:172		for i = 1 to length(opts) do*/
    if (IS_SEQUENCE(_opts_50180)){
            _25741 = SEQ_PTR(_opts_50180)->length;
    }
    else {
        _25741 = 1;
    }
    {
        object _i_50182;
        _i_50182 = 1;
L1: 
        if (_i_50182 > _25741){
            goto L2; // [12] 113
        }

        /** cominit.e:173			sequence o = opts[i]		*/
        DeRef(_o_50184);
        _2 = (object)SEQ_PTR(_opts_50180);
        _o_50184 = (object)*(((s1_ptr)_2)->base + _i_50182);
        Ref(_o_50184);

        /** cominit.e:174			integer has_case = find(HAS_CASE, o[OPTIONS])*/
        _2 = (object)SEQ_PTR(_o_50184);
        _25743 = (object)*(((s1_ptr)_2)->base + 4);
        _has_case_50186 = find_from(99, _25743, 1);
        _25743 = NOVALUE;

        /** cominit.e:176			if has_case and equal(o[name_type], opt) then*/
        if (_has_case_50186 == 0) {
            goto L3; // [42] 67
        }
        _2 = (object)SEQ_PTR(_o_50184);
        _25746 = (object)*(((s1_ptr)_2)->base + _name_type_50178);
        if (_25746 == _opt_50179)
        _25747 = 1;
        else if (IS_ATOM_INT(_25746) && IS_ATOM_INT(_opt_50179))
        _25747 = 0;
        else
        _25747 = (compare(_25746, _opt_50179) == 0);
        _25746 = NOVALUE;
        if (_25747 == 0)
        {
            _25747 = NOVALUE;
            goto L3; // [55] 67
        }
        else{
            _25747 = NOVALUE;
        }

        /** cominit.e:177				return o*/
        DeRefDS(_opt_50179);
        DeRefDS(_opts_50180);
        return _o_50184;
        goto L4; // [64] 104
L3: 

        /** cominit.e:178			elsif not has_case and equal(text:lower(o[name_type]), text:lower(opt)) then*/
        _25748 = (_has_case_50186 == 0);
        if (_25748 == 0) {
            goto L5; // [72] 103
        }
        _2 = (object)SEQ_PTR(_o_50184);
        _25750 = (object)*(((s1_ptr)_2)->base + _name_type_50178);
        Ref(_25750);
        _25751 = _14lower(_25750);
        _25750 = NOVALUE;
        RefDS(_opt_50179);
        _25752 = _14lower(_opt_50179);
        if (_25751 == _25752)
        _25753 = 1;
        else if (IS_ATOM_INT(_25751) && IS_ATOM_INT(_25752))
        _25753 = 0;
        else
        _25753 = (compare(_25751, _25752) == 0);
        DeRef(_25751);
        _25751 = NOVALUE;
        DeRef(_25752);
        _25752 = NOVALUE;
        if (_25753 == 0)
        {
            _25753 = NOVALUE;
            goto L5; // [93] 103
        }
        else{
            _25753 = NOVALUE;
        }

        /** cominit.e:179				return o*/
        DeRefDS(_opt_50179);
        DeRefDS(_opts_50180);
        DeRef(_25748);
        _25748 = NOVALUE;
        return _o_50184;
L5: 
L4: 
        DeRef(_o_50184);
        _o_50184 = NOVALUE;

        /** cominit.e:181		end for*/
        _i_50182 = _i_50182 + 1;
        goto L1; // [108] 19
L2: 
        ;
    }

    /** cominit.e:183		return {}*/
    RefDS(_22190);
    DeRefDS(_opt_50179);
    DeRefDS(_opts_50180);
    DeRef(_25748);
    _25748 = NOVALUE;
    return _22190;
    ;
}


object _49merge_parameters(object _a_50203, object _b_50204, object _opts_50205, object _dedupe_50206)
{
    object _i_50207 = NOVALUE;
    object _opt_50211 = NOVALUE;
    object _this_opt_50217 = NOVALUE;
    object _bi_50218 = NOVALUE;
    object _beginLen_50278 = NOVALUE;
    object _first_extra_50300 = NOVALUE;
    object _opt_50304 = NOVALUE;
    object _this_opt_50309 = NOVALUE;
    object _25847 = NOVALUE;
    object _25846 = NOVALUE;
    object _25843 = NOVALUE;
    object _25842 = NOVALUE;
    object _25841 = NOVALUE;
    object _25839 = NOVALUE;
    object _25838 = NOVALUE;
    object _25837 = NOVALUE;
    object _25836 = NOVALUE;
    object _25834 = NOVALUE;
    object _25833 = NOVALUE;
    object _25831 = NOVALUE;
    object _25830 = NOVALUE;
    object _25829 = NOVALUE;
    object _25828 = NOVALUE;
    object _25827 = NOVALUE;
    object _25826 = NOVALUE;
    object _25825 = NOVALUE;
    object _25823 = NOVALUE;
    object _25820 = NOVALUE;
    object _25819 = NOVALUE;
    object _25814 = NOVALUE;
    object _25812 = NOVALUE;
    object _25811 = NOVALUE;
    object _25810 = NOVALUE;
    object _25809 = NOVALUE;
    object _25808 = NOVALUE;
    object _25807 = NOVALUE;
    object _25806 = NOVALUE;
    object _25805 = NOVALUE;
    object _25801 = NOVALUE;
    object _25800 = NOVALUE;
    object _25799 = NOVALUE;
    object _25798 = NOVALUE;
    object _25797 = NOVALUE;
    object _25796 = NOVALUE;
    object _25795 = NOVALUE;
    object _25794 = NOVALUE;
    object _25793 = NOVALUE;
    object _25792 = NOVALUE;
    object _25791 = NOVALUE;
    object _25790 = NOVALUE;
    object _25789 = NOVALUE;
    object _25788 = NOVALUE;
    object _25787 = NOVALUE;
    object _25785 = NOVALUE;
    object _25784 = NOVALUE;
    object _25783 = NOVALUE;
    object _25782 = NOVALUE;
    object _25781 = NOVALUE;
    object _25780 = NOVALUE;
    object _25779 = NOVALUE;
    object _25778 = NOVALUE;
    object _25776 = NOVALUE;
    object _25775 = NOVALUE;
    object _25774 = NOVALUE;
    object _25773 = NOVALUE;
    object _25771 = NOVALUE;
    object _25770 = NOVALUE;
    object _25769 = NOVALUE;
    object _25768 = NOVALUE;
    object _25767 = NOVALUE;
    object _25766 = NOVALUE;
    object _25765 = NOVALUE;
    object _25763 = NOVALUE;
    object _25762 = NOVALUE;
    object _25760 = NOVALUE;
    object _25757 = NOVALUE;
    object _25754 = NOVALUE;
    object _0, _1, _2;
    

    /** cominit.e:199		integer i = 1*/
    _i_50207 = 1;

    /** cominit.e:201		while i <= length(a) do*/
L1: 
    if (IS_SEQUENCE(_a_50203)){
            _25754 = SEQ_PTR(_a_50203)->length;
    }
    else {
        _25754 = 1;
    }
    if (_i_50207 > _25754)
    goto L2; // [22] 465

    /** cominit.e:202			sequence opt = a[i]*/
    DeRef(_opt_50211);
    _2 = (object)SEQ_PTR(_a_50203);
    _opt_50211 = (object)*(((s1_ptr)_2)->base + _i_50207);
    Ref(_opt_50211);

    /** cominit.e:203			if length(opt) < 2 then*/
    if (IS_SEQUENCE(_opt_50211)){
            _25757 = SEQ_PTR(_opt_50211)->length;
    }
    else {
        _25757 = 1;
    }
    if (_25757 >= 2)
    goto L3; // [39] 56

    /** cominit.e:204				i += 1*/
    _i_50207 = _i_50207 + 1;

    /** cominit.e:205				continue*/
    DeRefDS(_opt_50211);
    _opt_50211 = NOVALUE;
    DeRef(_this_opt_50217);
    _this_opt_50217 = NOVALUE;
    goto L1; // [53] 19
L3: 

    /** cominit.e:208			sequence this_opt = {}*/
    RefDS(_22190);
    DeRef(_this_opt_50217);
    _this_opt_50217 = _22190;

    /** cominit.e:209			integer bi = 0*/
    _bi_50218 = 0;

    /** cominit.e:211			if opt[2] = '-' then*/
    _2 = (object)SEQ_PTR(_opt_50211);
    _25760 = (object)*(((s1_ptr)_2)->base + 2);
    if (binary_op_a(NOTEQ, _25760, 45)){
        _25760 = NOVALUE;
        goto L4; // [74] 149
    }
    _25760 = NOVALUE;

    /** cominit.e:214				this_opt = find_opt(LONGNAME, opt[3..$], opts)*/
    if (IS_SEQUENCE(_opt_50211)){
            _25762 = SEQ_PTR(_opt_50211)->length;
    }
    else {
        _25762 = 1;
    }
    rhs_slice_target = (object_ptr)&_25763;
    RHS_Slice(_opt_50211, 3, _25762);
    RefDS(_opts_50205);
    _0 = _this_opt_50217;
    _this_opt_50217 = _49find_opt(2, _25763, _opts_50205);
    DeRefDS(_0);
    _25763 = NOVALUE;

    /** cominit.e:216				for j = 1 to length(b) do*/
    if (IS_SEQUENCE(_b_50204)){
            _25765 = SEQ_PTR(_b_50204)->length;
    }
    else {
        _25765 = 1;
    }
    {
        object _j_50226;
        _j_50226 = 1;
L5: 
        if (_j_50226 > _25765){
            goto L6; // [101] 146
        }

        /** cominit.e:217					if equal(text:lower(b[j]), text:lower(opt)) then*/
        _2 = (object)SEQ_PTR(_b_50204);
        _25766 = (object)*(((s1_ptr)_2)->base + _j_50226);
        Ref(_25766);
        _25767 = _14lower(_25766);
        _25766 = NOVALUE;
        RefDS(_opt_50211);
        _25768 = _14lower(_opt_50211);
        if (_25767 == _25768)
        _25769 = 1;
        else if (IS_ATOM_INT(_25767) && IS_ATOM_INT(_25768))
        _25769 = 0;
        else
        _25769 = (compare(_25767, _25768) == 0);
        DeRef(_25767);
        _25767 = NOVALUE;
        DeRef(_25768);
        _25768 = NOVALUE;
        if (_25769 == 0)
        {
            _25769 = NOVALUE;
            goto L7; // [126] 139
        }
        else{
            _25769 = NOVALUE;
        }

        /** cominit.e:218						bi = j*/
        _bi_50218 = _j_50226;

        /** cominit.e:219						exit*/
        goto L6; // [136] 146
L7: 

        /** cominit.e:221				end for*/
        _j_50226 = _j_50226 + 1;
        goto L5; // [141] 108
L6: 
        ;
    }
    goto L8; // [146] 292
L4: 

    /** cominit.e:223			elsif opt[1] = '-' or opt[1] = '/' then*/
    _2 = (object)SEQ_PTR(_opt_50211);
    _25770 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_25770)) {
        _25771 = (_25770 == 45);
    }
    else {
        _25771 = binary_op(EQUALS, _25770, 45);
    }
    _25770 = NOVALUE;
    if (IS_ATOM_INT(_25771)) {
        if (_25771 != 0) {
            goto L9; // [159] 176
        }
    }
    else {
        if (DBL_PTR(_25771)->dbl != 0.0) {
            goto L9; // [159] 176
        }
    }
    _2 = (object)SEQ_PTR(_opt_50211);
    _25773 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_25773)) {
        _25774 = (_25773 == 47);
    }
    else {
        _25774 = binary_op(EQUALS, _25773, 47);
    }
    _25773 = NOVALUE;
    if (_25774 == 0) {
        DeRef(_25774);
        _25774 = NOVALUE;
        goto LA; // [172] 291
    }
    else {
        if (!IS_ATOM_INT(_25774) && DBL_PTR(_25774)->dbl == 0.0){
            DeRef(_25774);
            _25774 = NOVALUE;
            goto LA; // [172] 291
        }
        DeRef(_25774);
        _25774 = NOVALUE;
    }
    DeRef(_25774);
    _25774 = NOVALUE;
L9: 

    /** cominit.e:226				this_opt = find_opt(SHORTNAME, opt[2..$], opts)*/
    if (IS_SEQUENCE(_opt_50211)){
            _25775 = SEQ_PTR(_opt_50211)->length;
    }
    else {
        _25775 = 1;
    }
    rhs_slice_target = (object_ptr)&_25776;
    RHS_Slice(_opt_50211, 2, _25775);
    RefDS(_opts_50205);
    _0 = _this_opt_50217;
    _this_opt_50217 = _49find_opt(1, _25776, _opts_50205);
    DeRef(_0);
    _25776 = NOVALUE;

    /** cominit.e:228				for j = 1 to length(b) do*/
    if (IS_SEQUENCE(_b_50204)){
            _25778 = SEQ_PTR(_b_50204)->length;
    }
    else {
        _25778 = 1;
    }
    {
        object _j_50243;
        _j_50243 = 1;
LB: 
        if (_j_50243 > _25778){
            goto LC; // [199] 290
        }

        /** cominit.e:229					if equal(text:lower(b[j]), '-' & text:lower(opt[2..$])) or */
        _2 = (object)SEQ_PTR(_b_50204);
        _25779 = (object)*(((s1_ptr)_2)->base + _j_50243);
        Ref(_25779);
        _25780 = _14lower(_25779);
        _25779 = NOVALUE;
        if (IS_SEQUENCE(_opt_50211)){
                _25781 = SEQ_PTR(_opt_50211)->length;
        }
        else {
            _25781 = 1;
        }
        rhs_slice_target = (object_ptr)&_25782;
        RHS_Slice(_opt_50211, 2, _25781);
        _25783 = _14lower(_25782);
        _25782 = NOVALUE;
        if (IS_SEQUENCE(45) && IS_ATOM(_25783)) {
        }
        else if (IS_ATOM(45) && IS_SEQUENCE(_25783)) {
            Prepend(&_25784, _25783, 45);
        }
        else {
            Concat((object_ptr)&_25784, 45, _25783);
        }
        DeRef(_25783);
        _25783 = NOVALUE;
        if (_25780 == _25784)
        _25785 = 1;
        else if (IS_ATOM_INT(_25780) && IS_ATOM_INT(_25784))
        _25785 = 0;
        else
        _25785 = (compare(_25780, _25784) == 0);
        DeRef(_25780);
        _25780 = NOVALUE;
        DeRefDS(_25784);
        _25784 = NOVALUE;
        if (_25785 != 0) {
            goto LD; // [236] 273
        }
        _2 = (object)SEQ_PTR(_b_50204);
        _25787 = (object)*(((s1_ptr)_2)->base + _j_50243);
        Ref(_25787);
        _25788 = _14lower(_25787);
        _25787 = NOVALUE;
        if (IS_SEQUENCE(_opt_50211)){
                _25789 = SEQ_PTR(_opt_50211)->length;
        }
        else {
            _25789 = 1;
        }
        rhs_slice_target = (object_ptr)&_25790;
        RHS_Slice(_opt_50211, 2, _25789);
        _25791 = _14lower(_25790);
        _25790 = NOVALUE;
        if (IS_SEQUENCE(47) && IS_ATOM(_25791)) {
        }
        else if (IS_ATOM(47) && IS_SEQUENCE(_25791)) {
            Prepend(&_25792, _25791, 47);
        }
        else {
            Concat((object_ptr)&_25792, 47, _25791);
        }
        DeRef(_25791);
        _25791 = NOVALUE;
        if (_25788 == _25792)
        _25793 = 1;
        else if (IS_ATOM_INT(_25788) && IS_ATOM_INT(_25792))
        _25793 = 0;
        else
        _25793 = (compare(_25788, _25792) == 0);
        DeRef(_25788);
        _25788 = NOVALUE;
        DeRefDS(_25792);
        _25792 = NOVALUE;
        if (_25793 == 0)
        {
            _25793 = NOVALUE;
            goto LE; // [269] 283
        }
        else{
            _25793 = NOVALUE;
        }
LD: 

        /** cominit.e:232						bi = j*/
        _bi_50218 = _j_50243;

        /** cominit.e:233						exit*/
        goto LC; // [280] 290
LE: 

        /** cominit.e:235				end for*/
        _j_50243 = _j_50243 + 1;
        goto LB; // [285] 206
LC: 
        ;
    }
LA: 
L8: 

    /** cominit.e:243			if length(this_opt) and not find(MULTIPLE, this_opt[OPTIONS]) then*/
    if (IS_SEQUENCE(_this_opt_50217)){
            _25794 = SEQ_PTR(_this_opt_50217)->length;
    }
    else {
        _25794 = 1;
    }
    if (_25794 == 0) {
        goto LF; // [297] 451
    }
    _2 = (object)SEQ_PTR(_this_opt_50217);
    _25796 = (object)*(((s1_ptr)_2)->base + 4);
    _25797 = find_from(42, _25796, 1);
    _25796 = NOVALUE;
    _25798 = (_25797 == 0);
    _25797 = NOVALUE;
    if (_25798 == 0)
    {
        DeRef(_25798);
        _25798 = NOVALUE;
        goto LF; // [316] 451
    }
    else{
        DeRef(_25798);
        _25798 = NOVALUE;
    }

    /** cominit.e:244				if bi then*/
    if (_bi_50218 == 0)
    {
        goto L10; // [321] 365
    }
    else{
    }

    /** cominit.e:245					if find(HAS_PARAMETER, this_opt[OPTIONS]) then*/
    _2 = (object)SEQ_PTR(_this_opt_50217);
    _25799 = (object)*(((s1_ptr)_2)->base + 4);
    _25800 = find_from(112, _25799, 1);
    _25799 = NOVALUE;
    if (_25800 == 0)
    {
        _25800 = NOVALUE;
        goto L11; // [337] 354
    }
    else{
        _25800 = NOVALUE;
    }

    /** cominit.e:247						a = remove(a, i, i + 1)*/
    _25801 = _i_50207 + 1;
    if (_25801 > MAXINT){
        _25801 = NewDouble((eudouble)_25801);
    }
    {
        s1_ptr assign_space = SEQ_PTR(_a_50203);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_i_50207)) ? _i_50207 : (object)(DBL_PTR(_i_50207)->dbl);
        int stop = (IS_ATOM_INT(_25801)) ? _25801 : (object)(DBL_PTR(_25801)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_a_50203), start, &_a_50203 );
            }
            else Tail(SEQ_PTR(_a_50203), stop+1, &_a_50203);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_a_50203), start, &_a_50203);
        }
        else {
            assign_slice_seq = &assign_space;
            _a_50203 = Remove_elements(start, stop, (SEQ_PTR(_a_50203)->ref == 1));
        }
    }
    DeRef(_25801);
    _25801 = NOVALUE;
    goto L12; // [351] 458
L11: 

    /** cominit.e:250						a = remove(a, i)*/
    {
        s1_ptr assign_space = SEQ_PTR(_a_50203);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_i_50207)) ? _i_50207 : (object)(DBL_PTR(_i_50207)->dbl);
        int stop = (IS_ATOM_INT(_i_50207)) ? _i_50207 : (object)(DBL_PTR(_i_50207)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_a_50203), start, &_a_50203 );
            }
            else Tail(SEQ_PTR(_a_50203), stop+1, &_a_50203);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_a_50203), start, &_a_50203);
        }
        else {
            assign_slice_seq = &assign_space;
            _a_50203 = Remove_elements(start, stop, (SEQ_PTR(_a_50203)->ref == 1));
        }
    }
    goto L12; // [362] 458
L10: 

    /** cominit.e:265					integer beginLen = length(a)*/
    if (IS_SEQUENCE(_a_50203)){
            _beginLen_50278 = SEQ_PTR(_a_50203)->length;
    }
    else {
        _beginLen_50278 = 1;
    }

    /** cominit.e:267					if dedupe = 0 and i < beginLen then*/
    _25805 = (_dedupe_50206 == 0);
    if (_25805 == 0) {
        goto L13; // [376] 438
    }
    _25807 = (_i_50207 < _beginLen_50278);
    if (_25807 == 0)
    {
        DeRef(_25807);
        _25807 = NOVALUE;
        goto L13; // [385] 438
    }
    else{
        DeRef(_25807);
        _25807 = NOVALUE;
    }

    /** cominit.e:268						a = merge_parameters( a[i + 1..$], a[1..i], opts, 1)*/
    _25808 = _i_50207 + 1;
    if (_25808 > MAXINT){
        _25808 = NewDouble((eudouble)_25808);
    }
    if (IS_SEQUENCE(_a_50203)){
            _25809 = SEQ_PTR(_a_50203)->length;
    }
    else {
        _25809 = 1;
    }
    rhs_slice_target = (object_ptr)&_25810;
    RHS_Slice(_a_50203, _25808, _25809);
    rhs_slice_target = (object_ptr)&_25811;
    RHS_Slice(_a_50203, 1, _i_50207);
    RefDS(_opts_50205);
    DeRef(_25812);
    _25812 = _opts_50205;
    _0 = _a_50203;
    _a_50203 = _49merge_parameters(_25810, _25811, _25812, 1);
    DeRefDS(_0);
    _25810 = NOVALUE;
    _25811 = NOVALUE;
    _25812 = NOVALUE;

    /** cominit.e:270						if beginLen = length(a) then*/
    if (IS_SEQUENCE(_a_50203)){
            _25814 = SEQ_PTR(_a_50203)->length;
    }
    else {
        _25814 = 1;
    }
    if (_beginLen_50278 != _25814)
    goto L14; // [424] 445

    /** cominit.e:272							i += 1*/
    _i_50207 = _i_50207 + 1;
    goto L14; // [435] 445
L13: 

    /** cominit.e:276						i += 1*/
    _i_50207 = _i_50207 + 1;
L14: 
    goto L12; // [448] 458
LF: 

    /** cominit.e:282				i += 1*/
    _i_50207 = _i_50207 + 1;
L12: 
    DeRef(_opt_50211);
    _opt_50211 = NOVALUE;
    DeRef(_this_opt_50217);
    _this_opt_50217 = NOVALUE;

    /** cominit.e:284		end while*/
    goto L1; // [462] 19
L2: 

    /** cominit.e:286		if dedupe then*/
    if (_dedupe_50206 == 0)
    {
        goto L15; // [467] 481
    }
    else{
    }

    /** cominit.e:287			return b & a*/
    Concat((object_ptr)&_25819, _b_50204, _a_50203);
    DeRefDS(_a_50203);
    DeRefDS(_b_50204);
    DeRefDS(_opts_50205);
    DeRef(_25805);
    _25805 = NOVALUE;
    DeRef(_25808);
    _25808 = NOVALUE;
    DeRef(_25771);
    _25771 = NOVALUE;
    return _25819;
L15: 

    /** cominit.e:290		integer first_extra = 0*/
    _first_extra_50300 = 0;

    /** cominit.e:292		i = 1*/
    _i_50207 = 1;

    /** cominit.e:295		while i <= length(b) do*/
L16: 
    if (IS_SEQUENCE(_b_50204)){
            _25820 = SEQ_PTR(_b_50204)->length;
    }
    else {
        _25820 = 1;
    }
    if (_i_50207 > _25820)
    goto L17; // [499] 692

    /** cominit.e:296			sequence opt = b[i]*/
    DeRef(_opt_50304);
    _2 = (object)SEQ_PTR(_b_50204);
    _opt_50304 = (object)*(((s1_ptr)_2)->base + _i_50207);
    Ref(_opt_50304);

    /** cominit.e:299			if length(opt) <= 1 then*/
    if (IS_SEQUENCE(_opt_50304)){
            _25823 = SEQ_PTR(_opt_50304)->length;
    }
    else {
        _25823 = 1;
    }
    if (_25823 > 1)
    goto L18; // [516] 532

    /** cominit.e:300				first_extra = i*/
    _first_extra_50300 = _i_50207;

    /** cominit.e:301				exit*/
    DeRefDS(_opt_50304);
    _opt_50304 = NOVALUE;
    DeRef(_this_opt_50309);
    _this_opt_50309 = NOVALUE;
    goto L17; // [529] 692
L18: 

    /** cominit.e:304			sequence this_opt = {}*/
    RefDS(_22190);
    DeRef(_this_opt_50309);
    _this_opt_50309 = _22190;

    /** cominit.e:305			if opt[2] = '-' and opt[1] = '-' then*/
    _2 = (object)SEQ_PTR(_opt_50304);
    _25825 = (object)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_25825)) {
        _25826 = (_25825 == 45);
    }
    else {
        _25826 = binary_op(EQUALS, _25825, 45);
    }
    _25825 = NOVALUE;
    if (IS_ATOM_INT(_25826)) {
        if (_25826 == 0) {
            goto L19; // [549] 586
        }
    }
    else {
        if (DBL_PTR(_25826)->dbl == 0.0) {
            goto L19; // [549] 586
        }
    }
    _2 = (object)SEQ_PTR(_opt_50304);
    _25828 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_25828)) {
        _25829 = (_25828 == 45);
    }
    else {
        _25829 = binary_op(EQUALS, _25828, 45);
    }
    _25828 = NOVALUE;
    if (_25829 == 0) {
        DeRef(_25829);
        _25829 = NOVALUE;
        goto L19; // [562] 586
    }
    else {
        if (!IS_ATOM_INT(_25829) && DBL_PTR(_25829)->dbl == 0.0){
            DeRef(_25829);
            _25829 = NOVALUE;
            goto L19; // [562] 586
        }
        DeRef(_25829);
        _25829 = NOVALUE;
    }
    DeRef(_25829);
    _25829 = NOVALUE;

    /** cominit.e:306				this_opt = find_opt(LONGNAME, opt[3..$], opts)*/
    if (IS_SEQUENCE(_opt_50304)){
            _25830 = SEQ_PTR(_opt_50304)->length;
    }
    else {
        _25830 = 1;
    }
    rhs_slice_target = (object_ptr)&_25831;
    RHS_Slice(_opt_50304, 3, _25830);
    RefDS(_opts_50205);
    _0 = _this_opt_50309;
    _this_opt_50309 = _49find_opt(2, _25831, _opts_50205);
    DeRef(_0);
    _25831 = NOVALUE;
    goto L1A; // [583] 633
L19: 

    /** cominit.e:307			elsif opt[1] = '-' or opt[1] = '/' then*/
    _2 = (object)SEQ_PTR(_opt_50304);
    _25833 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_25833)) {
        _25834 = (_25833 == 45);
    }
    else {
        _25834 = binary_op(EQUALS, _25833, 45);
    }
    _25833 = NOVALUE;
    if (IS_ATOM_INT(_25834)) {
        if (_25834 != 0) {
            goto L1B; // [596] 613
        }
    }
    else {
        if (DBL_PTR(_25834)->dbl != 0.0) {
            goto L1B; // [596] 613
        }
    }
    _2 = (object)SEQ_PTR(_opt_50304);
    _25836 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_25836)) {
        _25837 = (_25836 == 47);
    }
    else {
        _25837 = binary_op(EQUALS, _25836, 47);
    }
    _25836 = NOVALUE;
    if (_25837 == 0) {
        DeRef(_25837);
        _25837 = NOVALUE;
        goto L1C; // [609] 632
    }
    else {
        if (!IS_ATOM_INT(_25837) && DBL_PTR(_25837)->dbl == 0.0){
            DeRef(_25837);
            _25837 = NOVALUE;
            goto L1C; // [609] 632
        }
        DeRef(_25837);
        _25837 = NOVALUE;
    }
    DeRef(_25837);
    _25837 = NOVALUE;
L1B: 

    /** cominit.e:308				this_opt = find_opt(SHORTNAME, opt[2..$], opts)*/
    if (IS_SEQUENCE(_opt_50304)){
            _25838 = SEQ_PTR(_opt_50304)->length;
    }
    else {
        _25838 = 1;
    }
    rhs_slice_target = (object_ptr)&_25839;
    RHS_Slice(_opt_50304, 2, _25838);
    RefDS(_opts_50205);
    _0 = _this_opt_50309;
    _this_opt_50309 = _49find_opt(1, _25839, _opts_50205);
    DeRef(_0);
    _25839 = NOVALUE;
L1C: 
L1A: 

    /** cominit.e:311			if length(this_opt) then*/
    if (IS_SEQUENCE(_this_opt_50309)){
            _25841 = SEQ_PTR(_this_opt_50309)->length;
    }
    else {
        _25841 = 1;
    }
    if (_25841 == 0)
    {
        _25841 = NOVALUE;
        goto L1D; // [638] 667
    }
    else{
        _25841 = NOVALUE;
    }

    /** cominit.e:312				if find(HAS_PARAMETER, this_opt[OPTIONS]) then*/
    _2 = (object)SEQ_PTR(_this_opt_50309);
    _25842 = (object)*(((s1_ptr)_2)->base + 4);
    _25843 = find_from(112, _25842, 1);
    _25842 = NOVALUE;
    if (_25843 == 0)
    {
        _25843 = NOVALUE;
        goto L1E; // [654] 679
    }
    else{
        _25843 = NOVALUE;
    }

    /** cominit.e:313					i += 1*/
    _i_50207 = _i_50207 + 1;
    goto L1E; // [664] 679
L1D: 

    /** cominit.e:316				first_extra = i*/
    _first_extra_50300 = _i_50207;

    /** cominit.e:317				exit*/
    DeRef(_opt_50304);
    _opt_50304 = NOVALUE;
    DeRef(_this_opt_50309);
    _this_opt_50309 = NOVALUE;
    goto L17; // [676] 692
L1E: 

    /** cominit.e:320			i += 1*/
    _i_50207 = _i_50207 + 1;
    DeRef(_opt_50304);
    _opt_50304 = NOVALUE;
    DeRef(_this_opt_50309);
    _this_opt_50309 = NOVALUE;

    /** cominit.e:321		end while*/
    goto L16; // [689] 496
L17: 

    /** cominit.e:323		if first_extra then*/
    if (_first_extra_50300 == 0)
    {
        goto L1F; // [694] 709
    }
    else{
    }

    /** cominit.e:324			return splice(b, a, first_extra)*/
    {
        s1_ptr assign_space;
        insert_pos = _first_extra_50300;
        if (insert_pos <= 0) {
            Concat(&_25846,_a_50203,_b_50204);
        }
        else if (insert_pos > SEQ_PTR(_b_50204)->length){
            Concat(&_25846,_b_50204,_a_50203);
        }
        else if (IS_SEQUENCE(_a_50203)) {
            if( _25846 != _b_50204 || SEQ_PTR( _b_50204 )->ref != 1 ){
                DeRef( _25846 );
                RefDS( _b_50204 );
            }
            assign_space = Add_internal_space( _b_50204, insert_pos,((s1_ptr)SEQ_PTR(_a_50203))->length);
            assign_slice_seq = &assign_space;
            assign_space = Copy_elements( insert_pos, SEQ_PTR(_a_50203), _b_50204 == _25846 );
            _25846 = MAKE_SEQ( assign_space );
        }
        else {
            if( _25846 == _b_50204 && SEQ_PTR( _b_50204 )->ref == 1 ){
                _25846 = Insert( _b_50204, _a_50203, insert_pos);
            }
            else {
                DeRef( _25846 );
                RefDS( _b_50204 );
                _25846 = Insert( _b_50204, _a_50203, insert_pos);
            }
        }
    }
    DeRefDS(_a_50203);
    DeRefDS(_b_50204);
    DeRefDS(_opts_50205);
    DeRef(_25805);
    _25805 = NOVALUE;
    DeRef(_25826);
    _25826 = NOVALUE;
    DeRef(_25819);
    _25819 = NOVALUE;
    DeRef(_25834);
    _25834 = NOVALUE;
    DeRef(_25808);
    _25808 = NOVALUE;
    DeRef(_25771);
    _25771 = NOVALUE;
    return _25846;
L1F: 

    /** cominit.e:328		return b & a*/
    Concat((object_ptr)&_25847, _b_50204, _a_50203);
    DeRefDS(_a_50203);
    DeRefDS(_b_50204);
    DeRefDS(_opts_50205);
    DeRef(_25805);
    _25805 = NOVALUE;
    DeRef(_25826);
    _25826 = NOVALUE;
    DeRef(_25819);
    _25819 = NOVALUE;
    DeRef(_25846);
    _25846 = NOVALUE;
    DeRef(_25834);
    _25834 = NOVALUE;
    DeRef(_25808);
    _25808 = NOVALUE;
    DeRef(_25771);
    _25771 = NOVALUE;
    return _25847;
    ;
}


object _49validate_opt(object _opt_type_50342, object _arg_50343, object _args_50344, object _ix_50345)
{
    object _opt_50346 = NOVALUE;
    object _this_opt_50354 = NOVALUE;
    object _25866 = NOVALUE;
    object _25865 = NOVALUE;
    object _25864 = NOVALUE;
    object _25863 = NOVALUE;
    object _25862 = NOVALUE;
    object _25860 = NOVALUE;
    object _25859 = NOVALUE;
    object _25858 = NOVALUE;
    object _25857 = NOVALUE;
    object _25856 = NOVALUE;
    object _25854 = NOVALUE;
    object _25851 = NOVALUE;
    object _25849 = NOVALUE;
    object _0, _1, _2;
    

    /** cominit.e:336		if opt_type = SHORTNAME then*/
    if (_opt_type_50342 != 1)
    goto L1; // [11] 28

    /** cominit.e:337			opt = arg[2..$]*/
    if (IS_SEQUENCE(_arg_50343)){
            _25849 = SEQ_PTR(_arg_50343)->length;
    }
    else {
        _25849 = 1;
    }
    rhs_slice_target = (object_ptr)&_opt_50346;
    RHS_Slice(_arg_50343, 2, _25849);
    goto L2; // [25] 39
L1: 

    /** cominit.e:339			opt = arg[3..$]*/
    if (IS_SEQUENCE(_arg_50343)){
            _25851 = SEQ_PTR(_arg_50343)->length;
    }
    else {
        _25851 = 1;
    }
    rhs_slice_target = (object_ptr)&_opt_50346;
    RHS_Slice(_arg_50343, 3, _25851);
L2: 

    /** cominit.e:342		sequence this_opt = find_opt( opt_type, opt, options )*/
    RefDS(_opt_50346);
    RefDS(_49options_50079);
    _0 = _this_opt_50354;
    _this_opt_50354 = _49find_opt(_opt_type_50342, _opt_50346, _49options_50079);
    DeRef(_0);

    /** cominit.e:343		if not length( this_opt ) then*/
    if (IS_SEQUENCE(_this_opt_50354)){
            _25854 = SEQ_PTR(_this_opt_50354)->length;
    }
    else {
        _25854 = 1;
    }
    if (_25854 != 0)
    goto L3; // [58] 72
    _25854 = NOVALUE;

    /** cominit.e:345			return { 0, 0 }*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 0;
    ((intptr_t *)_2)[2] = 0;
    _25856 = MAKE_SEQ(_1);
    DeRefDS(_arg_50343);
    DeRefDS(_args_50344);
    DeRefDS(_opt_50346);
    DeRefDS(_this_opt_50354);
    return _25856;
L3: 

    /** cominit.e:348		if find( HAS_PARAMETER, this_opt[OPTIONS] ) then*/
    _2 = (object)SEQ_PTR(_this_opt_50354);
    _25857 = (object)*(((s1_ptr)_2)->base + 4);
    _25858 = find_from(112, _25857, 1);
    _25857 = NOVALUE;
    if (_25858 == 0)
    {
        _25858 = NOVALUE;
        goto L4; // [85] 135
    }
    else{
        _25858 = NOVALUE;
    }

    /** cominit.e:349			if ix = length( args ) - 1 then*/
    if (IS_SEQUENCE(_args_50344)){
            _25859 = SEQ_PTR(_args_50344)->length;
    }
    else {
        _25859 = 1;
    }
    _25860 = _25859 - 1;
    _25859 = NOVALUE;
    if (_ix_50345 != _25860)
    goto L5; // [97] 117

    /** cominit.e:351				CompileErr( MISSING_CMD_PARAMETER, { arg } )*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_arg_50343);
    ((intptr_t*)_2)[1] = _arg_50343;
    _25862 = MAKE_SEQ(_1);
    _50CompileErr(353, _25862, 0);
    _25862 = NOVALUE;
    goto L6; // [114] 150
L5: 

    /** cominit.e:353				return { ix, ix + 2 }*/
    _25863 = _ix_50345 + 2;
    if ((object)((uintptr_t)_25863 + (uintptr_t)HIGH_BITS) >= 0){
        _25863 = NewDouble((eudouble)_25863);
    }
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _ix_50345;
    ((intptr_t *)_2)[2] = _25863;
    _25864 = MAKE_SEQ(_1);
    _25863 = NOVALUE;
    DeRefDS(_arg_50343);
    DeRefDS(_args_50344);
    DeRef(_opt_50346);
    DeRef(_this_opt_50354);
    DeRef(_25860);
    _25860 = NOVALUE;
    DeRef(_25856);
    _25856 = NOVALUE;
    return _25864;
    goto L6; // [132] 150
L4: 

    /** cominit.e:356			return { ix, ix + 1 }*/
    _25865 = _ix_50345 + 1;
    if (_25865 > MAXINT){
        _25865 = NewDouble((eudouble)_25865);
    }
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _ix_50345;
    ((intptr_t *)_2)[2] = _25865;
    _25866 = MAKE_SEQ(_1);
    _25865 = NOVALUE;
    DeRefDS(_arg_50343);
    DeRefDS(_args_50344);
    DeRef(_opt_50346);
    DeRef(_this_opt_50354);
    DeRef(_25864);
    _25864 = NOVALUE;
    DeRef(_25860);
    _25860 = NOVALUE;
    DeRef(_25856);
    _25856 = NOVALUE;
    return _25866;
L6: 
    ;
}


object _49find_next_opt(object _ix_50379, object _args_50380)
{
    object _arg_50384 = NOVALUE;
    object _25888 = NOVALUE;
    object _25887 = NOVALUE;
    object _25885 = NOVALUE;
    object _25884 = NOVALUE;
    object _25883 = NOVALUE;
    object _25882 = NOVALUE;
    object _25881 = NOVALUE;
    object _25880 = NOVALUE;
    object _25879 = NOVALUE;
    object _25878 = NOVALUE;
    object _25876 = NOVALUE;
    object _25874 = NOVALUE;
    object _25872 = NOVALUE;
    object _25870 = NOVALUE;
    object _25867 = NOVALUE;
    object _0, _1, _2;
    

    /** cominit.e:374		while ix < length( args ) do*/
L1: 
    if (IS_SEQUENCE(_args_50380)){
            _25867 = SEQ_PTR(_args_50380)->length;
    }
    else {
        _25867 = 1;
    }
    if (_ix_50379 >= _25867)
    goto L2; // [13] 157

    /** cominit.e:375			sequence arg = args[ix]*/
    DeRef(_arg_50384);
    _2 = (object)SEQ_PTR(_args_50380);
    _arg_50384 = (object)*(((s1_ptr)_2)->base + _ix_50379);
    Ref(_arg_50384);

    /** cominit.e:376			if length( arg ) > 1 then*/
    if (IS_SEQUENCE(_arg_50384)){
            _25870 = SEQ_PTR(_arg_50384)->length;
    }
    else {
        _25870 = 1;
    }
    if (_25870 <= 1)
    goto L3; // [30] 129

    /** cominit.e:377				if arg[1] = '-' then*/
    _2 = (object)SEQ_PTR(_arg_50384);
    _25872 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _25872, 45)){
        _25872 = NOVALUE;
        goto L4; // [40] 111
    }
    _25872 = NOVALUE;

    /** cominit.e:378					if arg[2] = '-' then*/
    _2 = (object)SEQ_PTR(_arg_50384);
    _25874 = (object)*(((s1_ptr)_2)->base + 2);
    if (binary_op_a(NOTEQ, _25874, 45)){
        _25874 = NOVALUE;
        goto L5; // [50] 94
    }
    _25874 = NOVALUE;

    /** cominit.e:380						if length( arg ) = 2 then*/
    if (IS_SEQUENCE(_arg_50384)){
            _25876 = SEQ_PTR(_arg_50384)->length;
    }
    else {
        _25876 = 1;
    }
    if (_25876 != 2)
    goto L6; // [59] 78

    /** cominit.e:382							return { 0, ix - 1 }*/
    _25878 = _ix_50379 - 1;
    if ((object)((uintptr_t)_25878 +(uintptr_t) HIGH_BITS) >= 0){
        _25878 = NewDouble((eudouble)_25878);
    }
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 0;
    ((intptr_t *)_2)[2] = _25878;
    _25879 = MAKE_SEQ(_1);
    _25878 = NOVALUE;
    DeRefDS(_arg_50384);
    DeRefDS(_args_50380);
    return _25879;
L6: 

    /** cominit.e:385						return validate_opt( LONGNAME, arg, args, ix )*/
    RefDS(_arg_50384);
    RefDS(_args_50380);
    _25880 = _49validate_opt(2, _arg_50384, _args_50380, _ix_50379);
    DeRefDS(_arg_50384);
    DeRefDS(_args_50380);
    DeRef(_25879);
    _25879 = NOVALUE;
    return _25880;
    goto L7; // [91] 144
L5: 

    /** cominit.e:389						return validate_opt( SHORTNAME, arg, args, ix )*/
    RefDS(_arg_50384);
    RefDS(_args_50380);
    _25881 = _49validate_opt(1, _arg_50384, _args_50380, _ix_50379);
    DeRefDS(_arg_50384);
    DeRefDS(_args_50380);
    DeRef(_25880);
    _25880 = NOVALUE;
    DeRef(_25879);
    _25879 = NOVALUE;
    return _25881;
    goto L7; // [108] 144
L4: 

    /** cominit.e:393					return {0, ix-1}*/
    _25882 = _ix_50379 - 1;
    if ((object)((uintptr_t)_25882 +(uintptr_t) HIGH_BITS) >= 0){
        _25882 = NewDouble((eudouble)_25882);
    }
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 0;
    ((intptr_t *)_2)[2] = _25882;
    _25883 = MAKE_SEQ(_1);
    _25882 = NOVALUE;
    DeRef(_arg_50384);
    DeRefDS(_args_50380);
    DeRef(_25880);
    _25880 = NOVALUE;
    DeRef(_25879);
    _25879 = NOVALUE;
    DeRef(_25881);
    _25881 = NOVALUE;
    return _25883;
    goto L7; // [126] 144
L3: 

    /** cominit.e:397				return { 0, ix-1 }*/
    _25884 = _ix_50379 - 1;
    if ((object)((uintptr_t)_25884 +(uintptr_t) HIGH_BITS) >= 0){
        _25884 = NewDouble((eudouble)_25884);
    }
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 0;
    ((intptr_t *)_2)[2] = _25884;
    _25885 = MAKE_SEQ(_1);
    _25884 = NOVALUE;
    DeRef(_arg_50384);
    DeRefDS(_args_50380);
    DeRef(_25883);
    _25883 = NOVALUE;
    DeRef(_25880);
    _25880 = NOVALUE;
    DeRef(_25879);
    _25879 = NOVALUE;
    DeRef(_25881);
    _25881 = NOVALUE;
    return _25885;
L7: 

    /** cominit.e:400			ix += 1*/
    _ix_50379 = _ix_50379 + 1;
    DeRef(_arg_50384);
    _arg_50384 = NOVALUE;

    /** cominit.e:401		end while*/
    goto L1; // [154] 10
L2: 

    /** cominit.e:402		return {0, ix-1}*/
    _25887 = _ix_50379 - 1;
    if ((object)((uintptr_t)_25887 +(uintptr_t) HIGH_BITS) >= 0){
        _25887 = NewDouble((eudouble)_25887);
    }
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 0;
    ((intptr_t *)_2)[2] = _25887;
    _25888 = MAKE_SEQ(_1);
    _25887 = NOVALUE;
    DeRefDS(_args_50380);
    DeRef(_25883);
    _25883 = NOVALUE;
    DeRef(_25885);
    _25885 = NOVALUE;
    DeRef(_25880);
    _25880 = NOVALUE;
    DeRef(_25879);
    _25879 = NOVALUE;
    DeRef(_25881);
    _25881 = NOVALUE;
    return _25888;
    ;
}


object _49expand_config_options(object _args_50414)
{
    object _idx_50415 = NOVALUE;
    object _next_idx_50416 = NOVALUE;
    object _files_50417 = NOVALUE;
    object _cmd_1_2_50418 = NOVALUE;
    object _25911 = NOVALUE;
    object _25910 = NOVALUE;
    object _25909 = NOVALUE;
    object _25908 = NOVALUE;
    object _25907 = NOVALUE;
    object _25906 = NOVALUE;
    object _25905 = NOVALUE;
    object _25904 = NOVALUE;
    object _25903 = NOVALUE;
    object _25898 = NOVALUE;
    object _25896 = NOVALUE;
    object _25895 = NOVALUE;
    object _25894 = NOVALUE;
    object _25892 = NOVALUE;
    object _25891 = NOVALUE;
    object _0, _1, _2;
    

    /** cominit.e:410		integer idx = 1*/
    _idx_50415 = 1;

    /** cominit.e:412		sequence files = {}*/
    RefDS(_22190);
    DeRef(_files_50417);
    _files_50417 = _22190;

    /** cominit.e:413		sequence cmd_1_2 = args[1..2]*/
    rhs_slice_target = (object_ptr)&_cmd_1_2_50418;
    RHS_Slice(_args_50414, 1, 2);

    /** cominit.e:414		args = remove( args, 1, 2 )*/
    {
        s1_ptr assign_space = SEQ_PTR(_args_50414);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(1)) ? 1 : (object)(DBL_PTR(1)->dbl);
        int stop = (IS_ATOM_INT(2)) ? 2 : (object)(DBL_PTR(2)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_args_50414), start, &_args_50414 );
            }
            else Tail(SEQ_PTR(_args_50414), stop+1, &_args_50414);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_args_50414), start, &_args_50414);
        }
        else {
            assign_slice_seq = &assign_space;
            _args_50414 = Remove_elements(start, stop, (SEQ_PTR(_args_50414)->ref == 1));
        }
    }

    /** cominit.e:416		while idx with entry do*/
    goto L1; // [31] 94
L2: 
    if (_idx_50415 == 0)
    {
        goto L3; // [34] 114
    }
    else{
    }

    /** cominit.e:417			if equal(upper(args[idx]), "-C") then*/
    _2 = (object)SEQ_PTR(_args_50414);
    _25891 = (object)*(((s1_ptr)_2)->base + _idx_50415);
    Ref(_25891);
    _25892 = _14upper(_25891);
    _25891 = NOVALUE;
    if (_25892 == _25893)
    _25894 = 1;
    else if (IS_ATOM_INT(_25892) && IS_ATOM_INT(_25893))
    _25894 = 0;
    else
    _25894 = (compare(_25892, _25893) == 0);
    DeRef(_25892);
    _25892 = NOVALUE;
    if (_25894 == 0)
    {
        _25894 = NOVALUE;
        goto L4; // [51] 82
    }
    else{
        _25894 = NOVALUE;
    }

    /** cominit.e:418				files = append( files, args[idx+1] )*/
    _25895 = _idx_50415 + 1;
    _2 = (object)SEQ_PTR(_args_50414);
    _25896 = (object)*(((s1_ptr)_2)->base + _25895);
    Ref(_25896);
    Append(&_files_50417, _files_50417, _25896);
    _25896 = NOVALUE;

    /** cominit.e:419				args = remove( args, idx, idx + 1 )*/
    _25898 = _idx_50415 + 1;
    if (_25898 > MAXINT){
        _25898 = NewDouble((eudouble)_25898);
    }
    {
        s1_ptr assign_space = SEQ_PTR(_args_50414);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_idx_50415)) ? _idx_50415 : (object)(DBL_PTR(_idx_50415)->dbl);
        int stop = (IS_ATOM_INT(_25898)) ? _25898 : (object)(DBL_PTR(_25898)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_args_50414), start, &_args_50414 );
            }
            else Tail(SEQ_PTR(_args_50414), stop+1, &_args_50414);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_args_50414), start, &_args_50414);
        }
        else {
            assign_slice_seq = &assign_space;
            _args_50414 = Remove_elements(start, stop, (SEQ_PTR(_args_50414)->ref == 1));
        }
    }
    DeRef(_25898);
    _25898 = NOVALUE;
    goto L5; // [79] 91
L4: 

    /** cominit.e:422				idx = next_idx[2]*/
    _2 = (object)SEQ_PTR(_next_idx_50416);
    _idx_50415 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_idx_50415))
    _idx_50415 = (object)DBL_PTR(_idx_50415)->dbl;
L5: 

    /** cominit.e:424		entry*/
L1: 

    /** cominit.e:425			next_idx = find_next_opt( idx, args )*/
    RefDS(_args_50414);
    _0 = _next_idx_50416;
    _next_idx_50416 = _49find_next_opt(_idx_50415, _args_50414);
    DeRef(_0);

    /** cominit.e:426			idx = next_idx[1]*/
    _2 = (object)SEQ_PTR(_next_idx_50416);
    _idx_50415 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_idx_50415))
    _idx_50415 = (object)DBL_PTR(_idx_50415)->dbl;

    /** cominit.e:427		end while*/
    goto L2; // [111] 34
L3: 

    /** cominit.e:428		return cmd_1_2 & merge_parameters( GetDefaultArgs( files ), args[1..next_idx[2]], options, 1 ) & args[next_idx[2]+1..$]*/
    RefDS(_files_50417);
    _25903 = _48GetDefaultArgs(_files_50417);
    _2 = (object)SEQ_PTR(_next_idx_50416);
    _25904 = (object)*(((s1_ptr)_2)->base + 2);
    rhs_slice_target = (object_ptr)&_25905;
    RHS_Slice(_args_50414, 1, _25904);
    RefDS(_49options_50079);
    _25906 = _49merge_parameters(_25903, _25905, _49options_50079, 1);
    _25903 = NOVALUE;
    _25905 = NOVALUE;
    _2 = (object)SEQ_PTR(_next_idx_50416);
    _25907 = (object)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_25907)) {
        _25908 = _25907 + 1;
        if (_25908 > MAXINT){
            _25908 = NewDouble((eudouble)_25908);
        }
    }
    else
    _25908 = binary_op(PLUS, 1, _25907);
    _25907 = NOVALUE;
    if (IS_SEQUENCE(_args_50414)){
            _25909 = SEQ_PTR(_args_50414)->length;
    }
    else {
        _25909 = 1;
    }
    rhs_slice_target = (object_ptr)&_25910;
    RHS_Slice(_args_50414, _25908, _25909);
    {
        object concat_list[3];

        concat_list[0] = _25910;
        concat_list[1] = _25906;
        concat_list[2] = _cmd_1_2_50418;
        Concat_N((object_ptr)&_25911, concat_list, 3);
    }
    DeRefDS(_25910);
    _25910 = NOVALUE;
    DeRef(_25906);
    _25906 = NOVALUE;
    DeRefDS(_args_50414);
    DeRefDS(_next_idx_50416);
    DeRefDS(_files_50417);
    DeRefDS(_cmd_1_2_50418);
    DeRef(_25895);
    _25895 = NOVALUE;
    DeRef(_25908);
    _25908 = NOVALUE;
    _25904 = NOVALUE;
    return _25911;
    ;
}


void _49handle_common_options(object _opts_50449)
{
    object _opt_keys_50450 = NOVALUE;
    object _option_w_50452 = NOVALUE;
    object _key_50456 = NOVALUE;
    object _val_50458 = NOVALUE;
    object _this_warn_50504 = NOVALUE;
    object _auto_add_warn_50506 = NOVALUE;
    object _n_50512 = NOVALUE;
    object _this_warn_50535 = NOVALUE;
    object _auto_add_warn_50537 = NOVALUE;
    object _n_50543 = NOVALUE;
    object _has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_620_50580 = NOVALUE;
    object _prompt_inlined_maybe_any_key_at_617_50579 = NOVALUE;
    object _has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_696_50593 = NOVALUE;
    object _prompt_inlined_maybe_any_key_at_693_50592 = NOVALUE;
    object _25970 = NOVALUE;
    object _25969 = NOVALUE;
    object _25967 = NOVALUE;
    object _25965 = NOVALUE;
    object _25963 = NOVALUE;
    object _25962 = NOVALUE;
    object _25961 = NOVALUE;
    object _25960 = NOVALUE;
    object _25959 = NOVALUE;
    object _25958 = NOVALUE;
    object _25957 = NOVALUE;
    object _25956 = NOVALUE;
    object _25954 = NOVALUE;
    object _25952 = NOVALUE;
    object _25951 = NOVALUE;
    object _25950 = NOVALUE;
    object _25945 = NOVALUE;
    object _25943 = NOVALUE;
    object _25941 = NOVALUE;
    object _25938 = NOVALUE;
    object _25937 = NOVALUE;
    object _25932 = NOVALUE;
    object _25930 = NOVALUE;
    object _25928 = NOVALUE;
    object _25926 = NOVALUE;
    object _25925 = NOVALUE;
    object _25924 = NOVALUE;
    object _25923 = NOVALUE;
    object _25922 = NOVALUE;
    object _25921 = NOVALUE;
    object _25919 = NOVALUE;
    object _25918 = NOVALUE;
    object _25913 = NOVALUE;
    object _0, _1, _2;
    

    /** cominit.e:435		sequence opt_keys = m:keys(opts)*/
    Ref(_opts_50449);
    _0 = _opt_keys_50450;
    _opt_keys_50450 = _29keys(_opts_50449, 0);
    DeRef(_0);

    /** cominit.e:436		integer option_w = 0*/
    _option_w_50452 = 0;

    /** cominit.e:438		for idx = 1 to length(opt_keys) do*/
    if (IS_SEQUENCE(_opt_keys_50450)){
            _25913 = SEQ_PTR(_opt_keys_50450)->length;
    }
    else {
        _25913 = 1;
    }
    {
        object _idx_50454;
        _idx_50454 = 1;
L1: 
        if (_idx_50454 > _25913){
            goto L2; // [20] 795
        }

        /** cominit.e:439			sequence key = opt_keys[idx]*/
        DeRef(_key_50456);
        _2 = (object)SEQ_PTR(_opt_keys_50450);
        _key_50456 = (object)*(((s1_ptr)_2)->base + _idx_50454);
        Ref(_key_50456);

        /** cominit.e:440			object val = m:get(opts, key)*/
        Ref(_opts_50449);
        RefDS(_key_50456);
        _0 = _val_50458;
        _val_50458 = _29get(_opts_50449, _key_50456, 0);
        DeRef(_0);

        /** cominit.e:442			switch key do*/
        _1 = find(_key_50456, _25916);
        switch ( _1 ){ 

            /** cominit.e:443				case "i" then*/
            case 1:

            /** cominit.e:444					for i = 1 to length(val) do*/
            if (IS_SEQUENCE(_val_50458)){
                    _25918 = SEQ_PTR(_val_50458)->length;
            }
            else {
                _25918 = 1;
            }
            {
                object _i_50464;
                _i_50464 = 1;
L3: 
                if (_i_50464 > _25918){
                    goto L4; // [59] 82
                }

                /** cominit.e:445						add_include_directory(val[i])*/
                _2 = (object)SEQ_PTR(_val_50458);
                _25919 = (object)*(((s1_ptr)_2)->base + _i_50464);
                Ref(_25919);
                _48add_include_directory(_25919);
                _25919 = NOVALUE;

                /** cominit.e:446					end for*/
                _i_50464 = _i_50464 + 1;
                goto L3; // [77] 66
L4: 
                ;
            }
            goto L5; // [82] 786

            /** cominit.e:448				case "d" then*/
            case 2:

            /** cominit.e:449					OpDefines &= val*/
            if (IS_SEQUENCE(_36OpDefines_21844) && IS_ATOM(_val_50458)) {
                Ref(_val_50458);
                Append(&_36OpDefines_21844, _36OpDefines_21844, _val_50458);
            }
            else if (IS_ATOM(_36OpDefines_21844) && IS_SEQUENCE(_val_50458)) {
            }
            else {
                Concat((object_ptr)&_36OpDefines_21844, _36OpDefines_21844, _val_50458);
            }
            goto L5; // [98] 786

            /** cominit.e:451				case "batch" then*/
            case 3:

            /** cominit.e:452					batch_job = 1*/
            _36batch_job_21780 = 1;
            goto L5; // [111] 786

            /** cominit.e:454				case "test" then*/
            case 4:

            /** cominit.e:455					test_only = 1*/
            _36test_only_21779 = 1;
            goto L5; // [124] 786

            /** cominit.e:457				case "strict" then*/
            case 5:

            /** cominit.e:458					Strict_is_on = 1*/
            _36Strict_is_on_21836 = 1;
            goto L5; // [137] 786

            /** cominit.e:460				case "p" then*/
            case 6:

            /** cominit.e:461					for i = 1 to length(val) do*/
            if (IS_SEQUENCE(_val_50458)){
                    _25921 = SEQ_PTR(_val_50458)->length;
            }
            else {
                _25921 = 1;
            }
            {
                object _i_50479;
                _i_50479 = 1;
L6: 
                if (_i_50479 > _25921){
                    goto L7; // [148] 173
                }

                /** cominit.e:462						add_preprocessor(val[i])*/
                _2 = (object)SEQ_PTR(_val_50458);
                _25922 = (object)*(((s1_ptr)_2)->base + _i_50479);
                Ref(_25922);
                _64add_preprocessor(_25922, 0, 0);
                _25922 = NOVALUE;

                /** cominit.e:463					end for*/
                _i_50479 = _i_50479 + 1;
                goto L6; // [168] 155
L7: 
                ;
            }
            goto L5; // [173] 786

            /** cominit.e:465				case "pf" then*/
            case 7:

            /** cominit.e:466					force_preprocessor = 1*/
            _37force_preprocessor_15655 = 1;
            goto L5; // [186] 786

            /** cominit.e:468				case "l" then*/
            case 8:

            /** cominit.e:469					for i = 1 to length(val) do*/
            if (IS_SEQUENCE(_val_50458)){
                    _25923 = SEQ_PTR(_val_50458)->length;
            }
            else {
                _25923 = 1;
            }
            {
                object _i_50487;
                _i_50487 = 1;
L8: 
                if (_i_50487 > _25923){
                    goto L9; // [197] 238
                }

                /** cominit.e:470						LocalizeQual = append(LocalizeQual, (filter(lower(val[i]), STDFLTR_ALPHA)))*/
                _2 = (object)SEQ_PTR(_val_50458);
                _25924 = (object)*(((s1_ptr)_2)->base + _i_50487);
                Ref(_25924);
                _25925 = _14lower(_25924);
                _25924 = NOVALUE;
                RefDS(_22190);
                RefDS(_5);
                _25926 = _23filter(_25925, _23STDFLTR_ALPHA_5152, _22190, _5);
                _25925 = NOVALUE;
                Ref(_25926);
                Append(&_37LocalizeQual_15656, _37LocalizeQual_15656, _25926);
                DeRef(_25926);
                _25926 = NOVALUE;

                /** cominit.e:471					end for*/
                _i_50487 = _i_50487 + 1;
                goto L8; // [233] 204
L9: 
                ;
            }
            goto L5; // [238] 786

            /** cominit.e:473				case "ldb" then*/
            case 9:

            /** cominit.e:474					LocalDB = val*/
            Ref(_val_50458);
            DeRef(_37LocalDB_15657);
            _37LocalDB_15657 = _val_50458;
            goto L5; // [251] 786

            /** cominit.e:476				case "w" then*/
            case 10:

            /** cominit.e:477					for i = 1 to length(val) do*/
            if (IS_SEQUENCE(_val_50458)){
                    _25928 = SEQ_PTR(_val_50458)->length;
            }
            else {
                _25928 = 1;
            }
            {
                object _i_50502;
                _i_50502 = 1;
LA: 
                if (_i_50502 > _25928){
                    goto LB; // [262] 392
                }

                /** cominit.e:478						sequence this_warn = val[i]*/
                DeRef(_this_warn_50504);
                _2 = (object)SEQ_PTR(_val_50458);
                _this_warn_50504 = (object)*(((s1_ptr)_2)->base + _i_50502);
                Ref(_this_warn_50504);

                /** cominit.e:479						integer auto_add_warn = 0*/
                _auto_add_warn_50506 = 0;

                /** cominit.e:480						if this_warn[1] = '+' then*/
                _2 = (object)SEQ_PTR(_this_warn_50504);
                _25930 = (object)*(((s1_ptr)_2)->base + 1);
                if (binary_op_a(NOTEQ, _25930, 43)){
                    _25930 = NOVALUE;
                    goto LC; // [288] 308
                }
                _25930 = NOVALUE;

                /** cominit.e:481							auto_add_warn = 1*/
                _auto_add_warn_50506 = 1;

                /** cominit.e:482							this_warn = this_warn[2 .. $]*/
                if (IS_SEQUENCE(_this_warn_50504)){
                        _25932 = SEQ_PTR(_this_warn_50504)->length;
                }
                else {
                    _25932 = 1;
                }
                rhs_slice_target = (object_ptr)&_this_warn_50504;
                RHS_Slice(_this_warn_50504, 2, _25932);
LC: 

                /** cominit.e:484						integer n = find(this_warn, warning_names)*/
                _n_50512 = find_from(_this_warn_50504, _36warning_names_21815, 1);

                /** cominit.e:485						if n != 0 then*/
                if (_n_50512 == 0)
                goto LD; // [319] 383

                /** cominit.e:486							if auto_add_warn or option_w = 1 then*/
                if (_auto_add_warn_50506 != 0) {
                    goto LE; // [325] 338
                }
                _25937 = (_option_w_50452 == 1);
                if (_25937 == 0)
                {
                    DeRef(_25937);
                    _25937 = NOVALUE;
                    goto LF; // [334] 357
                }
                else{
                    DeRef(_25937);
                    _25937 = NOVALUE;
                }
LE: 

                /** cominit.e:487								OpWarning = or_bits(OpWarning, warning_flags[n])*/
                _2 = (object)SEQ_PTR(_36warning_flags_21813);
                _25938 = (object)*(((s1_ptr)_2)->base + _n_50512);
                {uintptr_t tu;
                     tu = (uintptr_t)_36OpWarning_21838 | (uintptr_t)_25938;
                     _36OpWarning_21838 = MAKE_UINT(tu);
                }
                _25938 = NOVALUE;
                if (!IS_ATOM_INT(_36OpWarning_21838)) {
                    _1 = (object)(DBL_PTR(_36OpWarning_21838)->dbl);
                    DeRefDS(_36OpWarning_21838);
                    _36OpWarning_21838 = _1;
                }
                goto L10; // [354] 373
LF: 

                /** cominit.e:489								option_w = 1*/
                _option_w_50452 = 1;

                /** cominit.e:490								OpWarning = warning_flags[n]*/
                _2 = (object)SEQ_PTR(_36warning_flags_21813);
                _36OpWarning_21838 = (object)*(((s1_ptr)_2)->base + _n_50512);
L10: 

                /** cominit.e:493							prev_OpWarning = OpWarning*/
                _36prev_OpWarning_21839 = _36OpWarning_21838;
LD: 
                DeRef(_this_warn_50504);
                _this_warn_50504 = NOVALUE;

                /** cominit.e:495					end for*/
                _i_50502 = _i_50502 + 1;
                goto LA; // [387] 269
LB: 
                ;
            }
            goto L5; // [392] 786

            /** cominit.e:497				case "x" then*/
            case 11:

            /** cominit.e:498					for i = 1 to length(val) do*/
            if (IS_SEQUENCE(_val_50458)){
                    _25941 = SEQ_PTR(_val_50458)->length;
            }
            else {
                _25941 = 1;
            }
            {
                object _i_50533;
                _i_50533 = 1;
L11: 
                if (_i_50533 > _25941){
                    goto L12; // [403] 542
                }

                /** cominit.e:499						sequence this_warn = val[i]*/
                DeRef(_this_warn_50535);
                _2 = (object)SEQ_PTR(_val_50458);
                _this_warn_50535 = (object)*(((s1_ptr)_2)->base + _i_50533);
                Ref(_this_warn_50535);

                /** cominit.e:500						integer auto_add_warn = 0*/
                _auto_add_warn_50537 = 0;

                /** cominit.e:501						if this_warn[1] = '+' then*/
                _2 = (object)SEQ_PTR(_this_warn_50535);
                _25943 = (object)*(((s1_ptr)_2)->base + 1);
                if (binary_op_a(NOTEQ, _25943, 43)){
                    _25943 = NOVALUE;
                    goto L13; // [429] 449
                }
                _25943 = NOVALUE;

                /** cominit.e:502							auto_add_warn = 1*/
                _auto_add_warn_50537 = 1;

                /** cominit.e:503							this_warn = this_warn[2 .. $]*/
                if (IS_SEQUENCE(_this_warn_50535)){
                        _25945 = SEQ_PTR(_this_warn_50535)->length;
                }
                else {
                    _25945 = 1;
                }
                rhs_slice_target = (object_ptr)&_this_warn_50535;
                RHS_Slice(_this_warn_50535, 2, _25945);
L13: 

                /** cominit.e:505						integer n = find(this_warn, warning_names)*/
                _n_50543 = find_from(_this_warn_50535, _36warning_names_21815, 1);

                /** cominit.e:506						if n != 0 then*/
                if (_n_50543 == 0)
                goto L14; // [460] 533

                /** cominit.e:507							if auto_add_warn or option_w = -1 then*/
                if (_auto_add_warn_50537 != 0) {
                    goto L15; // [466] 479
                }
                _25950 = (_option_w_50452 == -1);
                if (_25950 == 0)
                {
                    DeRef(_25950);
                    _25950 = NOVALUE;
                    goto L16; // [475] 501
                }
                else{
                    DeRef(_25950);
                    _25950 = NOVALUE;
                }
L15: 

                /** cominit.e:508								OpWarning = and_bits(OpWarning, not_bits(warning_flags[n]))*/
                _2 = (object)SEQ_PTR(_36warning_flags_21813);
                _25951 = (object)*(((s1_ptr)_2)->base + _n_50543);
                _25952 = not_bits(_25951);
                _25951 = NOVALUE;
                if (IS_ATOM_INT(_25952)) {
                    {uintptr_t tu;
                         tu = (uintptr_t)_36OpWarning_21838 & (uintptr_t)_25952;
                         _36OpWarning_21838 = MAKE_UINT(tu);
                    }
                }
                else {
                    temp_d.dbl = (eudouble)_36OpWarning_21838;
                    _36OpWarning_21838 = Dand_bits(&temp_d, DBL_PTR(_25952));
                }
                DeRef(_25952);
                _25952 = NOVALUE;
                if (!IS_ATOM_INT(_36OpWarning_21838)) {
                    _1 = (object)(DBL_PTR(_36OpWarning_21838)->dbl);
                    DeRefDS(_36OpWarning_21838);
                    _36OpWarning_21838 = _1;
                }
                goto L17; // [498] 523
L16: 

                /** cominit.e:510								option_w = -1*/
                _option_w_50452 = -1;

                /** cominit.e:511								OpWarning = all_warning_flag - warning_flags[n]*/
                _2 = (object)SEQ_PTR(_36warning_flags_21813);
                _25954 = (object)*(((s1_ptr)_2)->base + _n_50543);
                _36OpWarning_21838 = 32767 - _25954;
                _25954 = NOVALUE;
L17: 

                /** cominit.e:514							prev_OpWarning = OpWarning*/
                _36prev_OpWarning_21839 = _36OpWarning_21838;
L14: 
                DeRef(_this_warn_50535);
                _this_warn_50535 = NOVALUE;

                /** cominit.e:516					end for*/
                _i_50533 = _i_50533 + 1;
                goto L11; // [537] 410
L12: 
                ;
            }
            goto L5; // [542] 786

            /** cominit.e:518				case "wf" then*/
            case 12:

            /** cominit.e:519					TempWarningName = val*/
            Ref(_val_50458);
            DeRef(_36TempWarningName_21781);
            _36TempWarningName_21781 = _val_50458;

            /** cominit.e:520				  	error:warning_file(TempWarningName)*/
            Ref(_36TempWarningName_21781);
            _7warning_file(_36TempWarningName_21781);
            goto L5; // [560] 786

            /** cominit.e:522				case "v", "version" then*/
            case 13:
            case 14:

            /** cominit.e:523					show_banner()*/
            _49show_banner();

            /** cominit.e:524					if not batch_job and not test_only then*/
            _25956 = (_36batch_job_21780 == 0);
            if (_25956 == 0) {
                goto L18; // [579] 634
            }
            _25958 = (_36test_only_21779 == 0);
            if (_25958 == 0)
            {
                DeRef(_25958);
                _25958 = NOVALUE;
                goto L18; // [589] 634
            }
            else{
                DeRef(_25958);
                _25958 = NOVALUE;
            }

            /** cominit.e:525						console:maybe_any_key(GetMsgText(MSG_PRESS_ANY_KEY_AND_WINDOW_WILL_CLOSE,0), 2)*/
            RefDS(_22190);
            _25959 = _39GetMsgText(278, 0, _22190);
            DeRef(_prompt_inlined_maybe_any_key_at_617_50579);
            _prompt_inlined_maybe_any_key_at_617_50579 = _25959;
            _25959 = NOVALUE;

            /** console.e:923		if not has_console() then*/

            /** console.e:59		return machine_func(M_HAS_CONSOLE, 0)*/
            DeRef(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_620_50580);
            _has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_620_50580 = machine(99, 0);
            if (IS_ATOM_INT(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_620_50580)) {
                if (_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_620_50580 != 0){
                    goto L19; // [616] 631
                }
            }
            else {
                if (DBL_PTR(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_620_50580)->dbl != 0.0){
                    goto L19; // [616] 631
                }
            }

            /** console.e:924			any_key(prompt, con)*/
            Ref(_prompt_inlined_maybe_any_key_at_617_50579);
            _5any_key(_prompt_inlined_maybe_any_key_at_617_50579, 2);

            /** console.e:926	end procedure*/
            goto L19; // [628] 631
L19: 
            DeRef(_prompt_inlined_maybe_any_key_at_617_50579);
            _prompt_inlined_maybe_any_key_at_617_50579 = NOVALUE;
            DeRef(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_620_50580);
            _has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_620_50580 = NOVALUE;
L18: 

            /** cominit.e:528					abort(0)*/
            UserCleanup(0);
            goto L5; // [638] 786

            /** cominit.e:530				case "copyright" then*/
            case 15:

            /** cominit.e:531					show_copyrights()*/
            _49show_copyrights();

            /** cominit.e:532					if not batch_job and not test_only then*/
            _25960 = (_36batch_job_21780 == 0);
            if (_25960 == 0) {
                goto L1A; // [655] 710
            }
            _25962 = (_36test_only_21779 == 0);
            if (_25962 == 0)
            {
                DeRef(_25962);
                _25962 = NOVALUE;
                goto L1A; // [665] 710
            }
            else{
                DeRef(_25962);
                _25962 = NOVALUE;
            }

            /** cominit.e:533						console:maybe_any_key(GetMsgText(MSG_PRESS_ANY_KEY_AND_WINDOW_WILL_CLOSE,0), 2)*/
            RefDS(_22190);
            _25963 = _39GetMsgText(278, 0, _22190);
            DeRef(_prompt_inlined_maybe_any_key_at_693_50592);
            _prompt_inlined_maybe_any_key_at_693_50592 = _25963;
            _25963 = NOVALUE;

            /** console.e:923		if not has_console() then*/

            /** console.e:59		return machine_func(M_HAS_CONSOLE, 0)*/
            DeRef(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_696_50593);
            _has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_696_50593 = machine(99, 0);
            if (IS_ATOM_INT(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_696_50593)) {
                if (_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_696_50593 != 0){
                    goto L1B; // [692] 707
                }
            }
            else {
                if (DBL_PTR(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_696_50593)->dbl != 0.0){
                    goto L1B; // [692] 707
                }
            }

            /** console.e:924			any_key(prompt, con)*/
            Ref(_prompt_inlined_maybe_any_key_at_693_50592);
            _5any_key(_prompt_inlined_maybe_any_key_at_693_50592, 2);

            /** console.e:926	end procedure*/
            goto L1B; // [704] 707
L1B: 
            DeRef(_prompt_inlined_maybe_any_key_at_693_50592);
            _prompt_inlined_maybe_any_key_at_693_50592 = NOVALUE;
            DeRef(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_696_50593);
            _has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_696_50593 = NOVALUE;
L1A: 

            /** cominit.e:535					abort(0)*/
            UserCleanup(0);
            goto L5; // [714] 786

            /** cominit.e:537				case "eudir" then*/
            case 16:

            /** cominit.e:538					set_eudir( val )*/
            Ref(_val_50458);
            _37set_eudir(_val_50458);
            goto L5; // [725] 786

            /** cominit.e:540				case "trace-lines" then*/
            case 17:

            /** cominit.e:541					val = value( val )*/
            Ref(_val_50458);
            _0 = _val_50458;
            _val_50458 = _6value(_val_50458, 1, _6GET_SHORT_ANSWER_11277);
            DeRef(_0);

            /** cominit.e:542					if val[1] = GET_SUCCESS then*/
            _2 = (object)SEQ_PTR(_val_50458);
            _25965 = (object)*(((s1_ptr)_2)->base + 1);
            if (binary_op_a(NOTEQ, _25965, 0)){
                _25965 = NOVALUE;
                goto L1C; // [749] 767
            }
            _25965 = NOVALUE;

            /** cominit.e:543						trace_lines = floor( val[2] )*/
            _2 = (object)SEQ_PTR(_val_50458);
            _25967 = (object)*(((s1_ptr)_2)->base + 2);
            if (IS_ATOM_INT(_25967))
            _36trace_lines_64939 = e_floor(_25967);
            else
            _36trace_lines_64939 = unary_op(FLOOR, _25967);
            _25967 = NOVALUE;
            if (!IS_ATOM_INT(_36trace_lines_64939)) {
                _1 = (object)(DBL_PTR(_36trace_lines_64939)->dbl);
                DeRefDS(_36trace_lines_64939);
                _36trace_lines_64939 = _1;
            }
            goto L1D; // [764] 785
L1C: 

            /** cominit.e:545						puts(2, GetMsgText( BAD_TRACE_LINES ) )*/
            RefDS(_22190);
            _25969 = _39GetMsgText(604, 1, _22190);
            EPuts(2, _25969); // DJP 
            DeRef(_25969);
            _25969 = NOVALUE;

            /** cominit.e:546						abort( 1 )*/
            UserCleanup(1);
L1D: 
        ;}L5: 
        DeRef(_key_50456);
        _key_50456 = NOVALUE;
        DeRef(_val_50458);
        _val_50458 = NOVALUE;

        /** cominit.e:549		end for*/
        _idx_50454 = _idx_50454 + 1;
        goto L1; // [790] 27
L2: 
        ;
    }

    /** cominit.e:551		if length(LocalizeQual) = 0 then*/
    if (IS_SEQUENCE(_37LocalizeQual_15656)){
            _25970 = SEQ_PTR(_37LocalizeQual_15656)->length;
    }
    else {
        _25970 = 1;
    }
    if (_25970 != 0)
    goto L1E; // [802] 815

    /** cominit.e:552			LocalizeQual = {"en"}*/
    _0 = _37LocalizeQual_15656;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_25972);
    ((intptr_t*)_2)[1] = _25972;
    _37LocalizeQual_15656 = MAKE_SEQ(_1);
    DeRefDS(_0);
L1E: 

    /** cominit.e:554	end procedure*/
    DeRef(_opts_50449);
    DeRef(_opt_keys_50450);
    DeRef(_25956);
    _25956 = NOVALUE;
    DeRef(_25960);
    _25960 = NOVALUE;
    return;
    ;
}


void _49finalize_command_line(object _opts_50619)
{
    object _extras_50626 = NOVALUE;
    object _pairs_50631 = NOVALUE;
    object _pair_50636 = NOVALUE;
    object _26002 = NOVALUE;
    object _26000 = NOVALUE;
    object _25997 = NOVALUE;
    object _25996 = NOVALUE;
    object _25995 = NOVALUE;
    object _25994 = NOVALUE;
    object _25993 = NOVALUE;
    object _25992 = NOVALUE;
    object _25991 = NOVALUE;
    object _25990 = NOVALUE;
    object _25989 = NOVALUE;
    object _25988 = NOVALUE;
    object _25987 = NOVALUE;
    object _25986 = NOVALUE;
    object _25985 = NOVALUE;
    object _25984 = NOVALUE;
    object _25983 = NOVALUE;
    object _25982 = NOVALUE;
    object _25981 = NOVALUE;
    object _25980 = NOVALUE;
    object _25978 = NOVALUE;
    object _25975 = NOVALUE;
    object _0, _1, _2;
    

    /** cominit.e:562		if Strict_is_on then -- overrides any -W/-X switches*/
    if (_36Strict_is_on_21836 == 0)
    {
        goto L1; // [5] 27
    }
    else{
    }

    /** cominit.e:563			OpWarning = all_warning_flag*/
    _36OpWarning_21838 = 32767;

    /** cominit.e:564			prev_OpWarning = OpWarning*/
    _36prev_OpWarning_21839 = 32767;
L1: 

    /** cominit.e:569		sequence extras = m:get(opts, cmdline:EXTRAS)*/
    Ref(_opts_50619);
    RefDS(_4EXTRAS_14407);
    _0 = _extras_50626;
    _extras_50626 = _29get(_opts_50619, _4EXTRAS_14407, 0);
    DeRef(_0);

    /** cominit.e:570		if length(extras) > 0 then*/
    if (IS_SEQUENCE(_extras_50626)){
            _25975 = SEQ_PTR(_extras_50626)->length;
    }
    else {
        _25975 = 1;
    }
    if (_25975 <= 0)
    goto L2; // [44] 270

    /** cominit.e:571			sequence pairs = m:pairs( opts )*/
    Ref(_opts_50619);
    _0 = _pairs_50631;
    _pairs_50631 = _29pairs(_opts_50619, 0);
    DeRef(_0);

    /** cominit.e:573			for i = 1 to length( pairs ) do*/
    if (IS_SEQUENCE(_pairs_50631)){
            _25978 = SEQ_PTR(_pairs_50631)->length;
    }
    else {
        _25978 = 1;
    }
    {
        object _i_50634;
        _i_50634 = 1;
L3: 
        if (_i_50634 > _25978){
            goto L4; // [62] 237
        }

        /** cominit.e:574				sequence pair = pairs[i]*/
        DeRef(_pair_50636);
        _2 = (object)SEQ_PTR(_pairs_50631);
        _pair_50636 = (object)*(((s1_ptr)_2)->base + _i_50634);
        Ref(_pair_50636);

        /** cominit.e:575				if equal( pair[1], cmdline:EXTRAS ) then*/
        _2 = (object)SEQ_PTR(_pair_50636);
        _25980 = (object)*(((s1_ptr)_2)->base + 1);
        if (_25980 == _4EXTRAS_14407)
        _25981 = 1;
        else if (IS_ATOM_INT(_25980) && IS_ATOM_INT(_4EXTRAS_14407))
        _25981 = 0;
        else
        _25981 = (compare(_25980, _4EXTRAS_14407) == 0);
        _25980 = NOVALUE;
        if (_25981 == 0)
        {
            _25981 = NOVALUE;
            goto L5; // [89] 99
        }
        else{
            _25981 = NOVALUE;
        }

        /** cominit.e:576					continue*/
        DeRefDS(_pair_50636);
        _pair_50636 = NOVALUE;
        goto L6; // [96] 232
L5: 

        /** cominit.e:578				pair[1] = prepend( pair[1], '-' )*/
        _2 = (object)SEQ_PTR(_pair_50636);
        _25982 = (object)*(((s1_ptr)_2)->base + 1);
        Prepend(&_25983, _25982, 45);
        _25982 = NOVALUE;
        _2 = (object)SEQ_PTR(_pair_50636);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _pair_50636 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 1);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _25983;
        if( _1 != _25983 ){
            DeRef(_1);
        }
        _25983 = NOVALUE;

        /** cominit.e:579				if sequence( pair[2] ) then*/
        _2 = (object)SEQ_PTR(_pair_50636);
        _25984 = (object)*(((s1_ptr)_2)->base + 2);
        _25985 = IS_SEQUENCE(_25984);
        _25984 = NOVALUE;
        if (_25985 == 0)
        {
            _25985 = NOVALUE;
            goto L7; // [122] 215
        }
        else{
            _25985 = NOVALUE;
        }

        /** cominit.e:580					if length( pair[2] ) and sequence( pair[2][1] ) then*/
        _2 = (object)SEQ_PTR(_pair_50636);
        _25986 = (object)*(((s1_ptr)_2)->base + 2);
        if (IS_SEQUENCE(_25986)){
                _25987 = SEQ_PTR(_25986)->length;
        }
        else {
            _25987 = 1;
        }
        _25986 = NOVALUE;
        if (_25987 == 0) {
            goto L8; // [134] 203
        }
        _2 = (object)SEQ_PTR(_pair_50636);
        _25989 = (object)*(((s1_ptr)_2)->base + 2);
        _2 = (object)SEQ_PTR(_25989);
        _25990 = (object)*(((s1_ptr)_2)->base + 1);
        _25989 = NOVALUE;
        _25991 = IS_SEQUENCE(_25990);
        _25990 = NOVALUE;
        if (_25991 == 0)
        {
            _25991 = NOVALUE;
            goto L8; // [150] 203
        }
        else{
            _25991 = NOVALUE;
        }

        /** cominit.e:581						for j = 1 to length( pair[2] ) do*/
        _2 = (object)SEQ_PTR(_pair_50636);
        _25992 = (object)*(((s1_ptr)_2)->base + 2);
        if (IS_SEQUENCE(_25992)){
                _25993 = SEQ_PTR(_25992)->length;
        }
        else {
            _25993 = 1;
        }
        _25992 = NOVALUE;
        {
            object _j_50654;
            _j_50654 = 1;
L9: 
            if (_j_50654 > _25993){
                goto LA; // [162] 200
            }

            /** cominit.e:582							switches &= { pair[1], pair[2][j] }*/
            _2 = (object)SEQ_PTR(_pair_50636);
            _25994 = (object)*(((s1_ptr)_2)->base + 1);
            _2 = (object)SEQ_PTR(_pair_50636);
            _25995 = (object)*(((s1_ptr)_2)->base + 2);
            _2 = (object)SEQ_PTR(_25995);
            _25996 = (object)*(((s1_ptr)_2)->base + _j_50654);
            _25995 = NOVALUE;
            Ref(_25996);
            Ref(_25994);
            _1 = NewS1(2);
            _2 = (object)((s1_ptr)_1)->base;
            ((intptr_t *)_2)[1] = _25994;
            ((intptr_t *)_2)[2] = _25996;
            _25997 = MAKE_SEQ(_1);
            _25996 = NOVALUE;
            _25994 = NOVALUE;
            Concat((object_ptr)&_49switches_49952, _49switches_49952, _25997);
            DeRefDS(_25997);
            _25997 = NOVALUE;

            /** cominit.e:583						end for*/
            _j_50654 = _j_50654 + 1;
            goto L9; // [195] 169
LA: 
            ;
        }
        goto LB; // [200] 228
L8: 

        /** cominit.e:585						switches &= pair*/
        Concat((object_ptr)&_49switches_49952, _49switches_49952, _pair_50636);
        goto LB; // [212] 228
L7: 

        /** cominit.e:588					switches = append( switches, pair[1] )*/
        _2 = (object)SEQ_PTR(_pair_50636);
        _26000 = (object)*(((s1_ptr)_2)->base + 1);
        Ref(_26000);
        Append(&_49switches_49952, _49switches_49952, _26000);
        _26000 = NOVALUE;
LB: 
        DeRef(_pair_50636);
        _pair_50636 = NOVALUE;

        /** cominit.e:590			end for*/
L6: 
        _i_50634 = _i_50634 + 1;
        goto L3; // [232] 69
L4: 
        ;
    }

    /** cominit.e:592			Argv = Argv[2..3] & extras*/
    rhs_slice_target = (object_ptr)&_26002;
    RHS_Slice(_36Argv_21778, 2, 3);
    Concat((object_ptr)&_36Argv_21778, _26002, _extras_50626);
    DeRefDS(_26002);
    _26002 = NOVALUE;
    DeRef(_26002);
    _26002 = NOVALUE;

    /** cominit.e:593			Argc = length(Argv)*/
    if (IS_SEQUENCE(_36Argv_21778)){
            _36Argc_21777 = SEQ_PTR(_36Argv_21778)->length;
    }
    else {
        _36Argc_21777 = 1;
    }

    /** cominit.e:595			src_name = extras[1]*/
    DeRef(_49src_name_49951);
    _2 = (object)SEQ_PTR(_extras_50626);
    _49src_name_49951 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_49src_name_49951);
L2: 
    DeRef(_pairs_50631);
    _pairs_50631 = NOVALUE;

    /** cominit.e:597	end procedure*/
    DeRef(_opts_50619);
    DeRef(_extras_50626);
    _25992 = NOVALUE;
    _25986 = NOVALUE;
    return;
    ;
}



// 0xD1A42A95
