// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _52new(object _pattern_22489, object _options_22490)
{
    object _12712 = NOVALUE;
    object _12711 = NOVALUE;
    object _12709 = NOVALUE;
    object _0, _1, _2;
    

    /** regex.e:723		if sequence(options) then */
    _12709 = 0;
    if (_12709 == 0)
    {
        _12709 = NOVALUE;
        goto L1; // [6] 16
    }
    else{
        _12709 = NOVALUE;
    }

    /** regex.e:724			options = math:or_all(options) */
    _options_22490 = _20or_all(_options_22490);
L1: 

    /** regex.e:730		return machine_func(M_PCRE_COMPILE, { pattern, options })*/
    Ref(_options_22490);
    Ref(_pattern_22489);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _pattern_22489;
    ((intptr_t *)_2)[2] = _options_22490;
    _12711 = MAKE_SEQ(_1);
    _12712 = machine(68, _12711);
    DeRefDS(_12711);
    _12711 = NOVALUE;
    DeRefi(_pattern_22489);
    DeRef(_options_22490);
    return _12712;
    ;
}


object _52get_ovector_size(object _ex_22509, object _maxsize_22510)
{
    object _m_22511 = NOVALUE;
    object _12720 = NOVALUE;
    object _12717 = NOVALUE;
    object _0, _1, _2;
    

    /** regex.e:804		integer m = machine_func(M_PCRE_GET_OVECTOR_SIZE, {ex})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_ex_22509);
    ((intptr_t*)_2)[1] = _ex_22509;
    _12717 = MAKE_SEQ(_1);
    _m_22511 = machine(97, _12717);
    DeRefDS(_12717);
    _12717 = NOVALUE;
    if (!IS_ATOM_INT(_m_22511)) {
        _1 = (object)(DBL_PTR(_m_22511)->dbl);
        DeRefDS(_m_22511);
        _m_22511 = _1;
    }

    /** regex.e:805		if (m > maxsize) then*/
    if (_m_22511 <= 30)
    goto L1; // [17] 28

    /** regex.e:806			return maxsize*/
    DeRef(_ex_22509);
    return 30;
L1: 

    /** regex.e:809		return m+1*/
    _12720 = _m_22511 + 1;
    if (_12720 > MAXINT){
        _12720 = NewDouble((eudouble)_12720);
    }
    DeRef(_ex_22509);
    return _12720;
    ;
}


object _52find(object _re_22519, object _haystack_22521, object _from_22522, object _options_22523, object _size_22524)
{
    object _12727 = NOVALUE;
    object _12726 = NOVALUE;
    object _12725 = NOVALUE;
    object _12722 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_size_22524)) {
        _1 = (object)(DBL_PTR(_size_22524)->dbl);
        DeRefDS(_size_22524);
        _size_22524 = _1;
    }

    /** regex.e:872		if sequence(options) then */
    _12722 = IS_SEQUENCE(_options_22523);
    if (_12722 == 0)
    {
        _12722 = NOVALUE;
        goto L1; // [10] 20
    }
    else{
        _12722 = NOVALUE;
    }

    /** regex.e:873			options = math:or_all(options) */
    Ref(_options_22523);
    _0 = _options_22523;
    _options_22523 = _20or_all(_options_22523);
    DeRef(_0);
L1: 

    /** regex.e:876		if size < 0 then*/
    if (_size_22524 >= 0)
    goto L2; // [22] 32

    /** regex.e:877			size = 0*/
    _size_22524 = 0;
L2: 

    /** regex.e:880		return machine_func(M_PCRE_EXEC, { re, haystack, length(haystack), options, from, size })*/
    if (IS_SEQUENCE(_haystack_22521)){
            _12725 = SEQ_PTR(_haystack_22521)->length;
    }
    else {
        _12725 = 1;
    }
    _1 = NewS1(6);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_re_22519);
    ((intptr_t*)_2)[1] = _re_22519;
    Ref(_haystack_22521);
    ((intptr_t*)_2)[2] = _haystack_22521;
    ((intptr_t*)_2)[3] = _12725;
    Ref(_options_22523);
    ((intptr_t*)_2)[4] = _options_22523;
    ((intptr_t*)_2)[5] = _from_22522;
    ((intptr_t*)_2)[6] = _size_22524;
    _12726 = MAKE_SEQ(_1);
    _12725 = NOVALUE;
    _12727 = machine(70, _12726);
    DeRefDS(_12726);
    _12726 = NOVALUE;
    DeRef(_re_22519);
    DeRef(_haystack_22521);
    DeRef(_options_22523);
    return _12727;
    ;
}


object _52find_all(object _re_22536, object _haystack_22538, object _from_22539, object _options_22540, object _size_22541)
{
    object _result_22548 = NOVALUE;
    object _results_22549 = NOVALUE;
    object _pHaystack_22550 = NOVALUE;
    object _12740 = NOVALUE;
    object _12739 = NOVALUE;
    object _12737 = NOVALUE;
    object _12735 = NOVALUE;
    object _12733 = NOVALUE;
    object _12729 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_size_22541)) {
        _1 = (object)(DBL_PTR(_size_22541)->dbl);
        DeRefDS(_size_22541);
        _size_22541 = _1;
    }

    /** regex.e:917		if sequence(options) then */
    _12729 = IS_SEQUENCE(_options_22540);
    if (_12729 == 0)
    {
        _12729 = NOVALUE;
        goto L1; // [10] 20
    }
    else{
        _12729 = NOVALUE;
    }

    /** regex.e:918			options = math:or_all(options) */
    Ref(_options_22540);
    _0 = _options_22540;
    _options_22540 = _20or_all(_options_22540);
    DeRef(_0);
L1: 

    /** regex.e:921		if size < 0 then*/
    if (_size_22541 >= 0)
    goto L2; // [22] 32

    /** regex.e:922			size = 0*/
    _size_22541 = 0;
L2: 

    /** regex.e:925		object result*/

    /** regex.e:926		sequence results = {}*/
    RefDS(_5);
    DeRef(_results_22549);
    _results_22549 = _5;

    /** regex.e:927		atom pHaystack = machine:allocate_string(haystack)*/
    Ref(_haystack_22538);
    _0 = _pHaystack_22550;
    _pHaystack_22550 = _9allocate_string(_haystack_22538, 0);
    DeRef(_0);

    /** regex.e:928		while sequence(result) with entry do*/
    goto L3; // [50] 94
L4: 
    _12733 = IS_SEQUENCE(_result_22548);
    if (_12733 == 0)
    {
        _12733 = NOVALUE;
        goto L5; // [58] 117
    }
    else{
        _12733 = NOVALUE;
    }

    /** regex.e:929			results = append(results, result)*/
    Ref(_result_22548);
    Append(&_results_22549, _results_22549, _result_22548);

    /** regex.e:930			from = math:max(result) + 1*/
    Ref(_result_22548);
    _12735 = _20max(_result_22548);
    if (IS_ATOM_INT(_12735)) {
        _from_22539 = _12735 + 1;
    }
    else
    { // coercing _from_22539 to an integer 1
        _from_22539 = 1+(object)(DBL_PTR(_12735)->dbl);
        if( !IS_ATOM_INT(_from_22539) ){
            _from_22539 = (object)DBL_PTR(_from_22539)->dbl;
        }
    }
    DeRef(_12735);
    _12735 = NOVALUE;

    /** regex.e:932			if from > length(haystack) then*/
    if (IS_SEQUENCE(_haystack_22538)){
            _12737 = SEQ_PTR(_haystack_22538)->length;
    }
    else {
        _12737 = 1;
    }
    if (_from_22539 <= _12737)
    goto L6; // [82] 91

    /** regex.e:933				exit*/
    goto L5; // [88] 117
L6: 

    /** regex.e:935		entry*/
L3: 

    /** regex.e:936			result = machine_func(M_PCRE_EXEC, { re, pHaystack, length(haystack), options, from, size })*/
    if (IS_SEQUENCE(_haystack_22538)){
            _12739 = SEQ_PTR(_haystack_22538)->length;
    }
    else {
        _12739 = 1;
    }
    _1 = NewS1(6);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_re_22536);
    ((intptr_t*)_2)[1] = _re_22536;
    Ref(_pHaystack_22550);
    ((intptr_t*)_2)[2] = _pHaystack_22550;
    ((intptr_t*)_2)[3] = _12739;
    Ref(_options_22540);
    ((intptr_t*)_2)[4] = _options_22540;
    ((intptr_t*)_2)[5] = _from_22539;
    ((intptr_t*)_2)[6] = _size_22541;
    _12740 = MAKE_SEQ(_1);
    _12739 = NOVALUE;
    DeRef(_result_22548);
    _result_22548 = machine(70, _12740);
    DeRefDS(_12740);
    _12740 = NOVALUE;

    /** regex.e:937		end while*/
    goto L4; // [114] 53
L5: 

    /** regex.e:939		machine:free(pHaystack)*/
    Ref(_pHaystack_22550);
    _9free(_pHaystack_22550);

    /** regex.e:941		return results*/
    DeRef(_re_22536);
    DeRef(_haystack_22538);
    DeRef(_options_22540);
    DeRef(_result_22548);
    DeRef(_pHaystack_22550);
    return _results_22549;
    ;
}


object _52matches(object _re_22599, object _haystack_22601, object _from_22602, object _options_22603)
{
    object _str_offsets_22607 = NOVALUE;
    object _match_data_22609 = NOVALUE;
    object _tmp_22619 = NOVALUE;
    object _12781 = NOVALUE;
    object _12780 = NOVALUE;
    object _12779 = NOVALUE;
    object _12778 = NOVALUE;
    object _12777 = NOVALUE;
    object _12775 = NOVALUE;
    object _12774 = NOVALUE;
    object _12773 = NOVALUE;
    object _12772 = NOVALUE;
    object _12770 = NOVALUE;
    object _12769 = NOVALUE;
    object _12768 = NOVALUE;
    object _12767 = NOVALUE;
    object _12765 = NOVALUE;
    object _12764 = NOVALUE;
    object _12763 = NOVALUE;
    object _12760 = NOVALUE;
    object _0, _1, _2;
    

    /** regex.e:1038		if sequence(options) then */
    _12760 = 0;
    if (_12760 == 0)
    {
        _12760 = NOVALUE;
        goto L1; // [8] 18
    }
    else{
        _12760 = NOVALUE;
    }

    /** regex.e:1039			options = math:or_all(options) */
    _options_22603 = _20or_all(0);
L1: 

    /** regex.e:1041		integer str_offsets = and_bits(STRING_OFFSETS, options)*/
    if (IS_ATOM_INT(_options_22603)) {
        {uintptr_t tu;
             tu = (uintptr_t)201326592 & (uintptr_t)_options_22603;
             _str_offsets_22607 = MAKE_UINT(tu);
        }
    }
    else {
        _str_offsets_22607 = binary_op(AND_BITS, 201326592, _options_22603);
    }
    if (!IS_ATOM_INT(_str_offsets_22607)) {
        _1 = (object)(DBL_PTR(_str_offsets_22607)->dbl);
        DeRefDS(_str_offsets_22607);
        _str_offsets_22607 = _1;
    }

    /** regex.e:1042		object match_data = find(re, haystack, from, and_bits(options, not_bits(STRING_OFFSETS)))*/
    _12763 = not_bits(201326592);
    if (IS_ATOM_INT(_options_22603) && IS_ATOM_INT(_12763)) {
        {uintptr_t tu;
             tu = (uintptr_t)_options_22603 & (uintptr_t)_12763;
             _12764 = MAKE_UINT(tu);
        }
    }
    else {
        _12764 = binary_op(AND_BITS, _options_22603, _12763);
    }
    DeRef(_12763);
    _12763 = NOVALUE;
    Ref(_re_22599);
    _12765 = _52get_ovector_size(_re_22599, 30);
    Ref(_re_22599);
    Ref(_haystack_22601);
    _0 = _match_data_22609;
    _match_data_22609 = _52find(_re_22599, _haystack_22601, _from_22602, _12764, _12765);
    DeRef(_0);
    _12764 = NOVALUE;
    _12765 = NOVALUE;

    /** regex.e:1044		if atom(match_data) then */
    _12767 = IS_ATOM(_match_data_22609);
    if (_12767 == 0)
    {
        _12767 = NOVALUE;
        goto L2; // [53] 63
    }
    else{
        _12767 = NOVALUE;
    }

    /** regex.e:1045			return ERROR_NOMATCH */
    DeRef(_re_22599);
    DeRef(_haystack_22601);
    DeRef(_options_22603);
    DeRef(_match_data_22609);
    return -1;
L2: 

    /** regex.e:1048		for i = 1 to length(match_data) do*/
    if (IS_SEQUENCE(_match_data_22609)){
            _12768 = SEQ_PTR(_match_data_22609)->length;
    }
    else {
        _12768 = 1;
    }
    {
        object _i_22617;
        _i_22617 = 1;
L3: 
        if (_i_22617 > _12768){
            goto L4; // [68] 181
        }

        /** regex.e:1049			sequence tmp*/

        /** regex.e:1050			if match_data[i][1] = 0 then*/
        _2 = (object)SEQ_PTR(_match_data_22609);
        _12769 = (object)*(((s1_ptr)_2)->base + _i_22617);
        _2 = (object)SEQ_PTR(_12769);
        _12770 = (object)*(((s1_ptr)_2)->base + 1);
        _12769 = NOVALUE;
        if (binary_op_a(NOTEQ, _12770, 0)){
            _12770 = NOVALUE;
            goto L5; // [87] 101
        }
        _12770 = NOVALUE;

        /** regex.e:1051				tmp = ""*/
        RefDS(_5);
        DeRef(_tmp_22619);
        _tmp_22619 = _5;
        goto L6; // [98] 125
L5: 

        /** regex.e:1053				tmp = haystack[match_data[i][1]..match_data[i][2]]*/
        _2 = (object)SEQ_PTR(_match_data_22609);
        _12772 = (object)*(((s1_ptr)_2)->base + _i_22617);
        _2 = (object)SEQ_PTR(_12772);
        _12773 = (object)*(((s1_ptr)_2)->base + 1);
        _12772 = NOVALUE;
        _2 = (object)SEQ_PTR(_match_data_22609);
        _12774 = (object)*(((s1_ptr)_2)->base + _i_22617);
        _2 = (object)SEQ_PTR(_12774);
        _12775 = (object)*(((s1_ptr)_2)->base + 2);
        _12774 = NOVALUE;
        rhs_slice_target = (object_ptr)&_tmp_22619;
        RHS_Slice(_haystack_22601, _12773, _12775);
L6: 

        /** regex.e:1055			if str_offsets then*/
        if (_str_offsets_22607 == 0)
        {
            goto L7; // [127] 163
        }
        else{
        }

        /** regex.e:1056				match_data[i] = { tmp, match_data[i][1], match_data[i][2] }*/
        _2 = (object)SEQ_PTR(_match_data_22609);
        _12777 = (object)*(((s1_ptr)_2)->base + _i_22617);
        _2 = (object)SEQ_PTR(_12777);
        _12778 = (object)*(((s1_ptr)_2)->base + 1);
        _12777 = NOVALUE;
        _2 = (object)SEQ_PTR(_match_data_22609);
        _12779 = (object)*(((s1_ptr)_2)->base + _i_22617);
        _2 = (object)SEQ_PTR(_12779);
        _12780 = (object)*(((s1_ptr)_2)->base + 2);
        _12779 = NOVALUE;
        _1 = NewS1(3);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_tmp_22619);
        ((intptr_t*)_2)[1] = _tmp_22619;
        Ref(_12778);
        ((intptr_t*)_2)[2] = _12778;
        Ref(_12780);
        ((intptr_t*)_2)[3] = _12780;
        _12781 = MAKE_SEQ(_1);
        _12780 = NOVALUE;
        _12778 = NOVALUE;
        _2 = (object)SEQ_PTR(_match_data_22609);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _match_data_22609 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_22617);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _12781;
        if( _1 != _12781 ){
            DeRef(_1);
        }
        _12781 = NOVALUE;
        goto L8; // [160] 172
L7: 

        /** regex.e:1058				match_data[i] = tmp*/
        RefDS(_tmp_22619);
        _2 = (object)SEQ_PTR(_match_data_22609);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _match_data_22609 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_22617);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _tmp_22619;
        DeRef(_1);
L8: 
        DeRef(_tmp_22619);
        _tmp_22619 = NOVALUE;

        /** regex.e:1060		end for*/
        _i_22617 = _i_22617 + 1;
        goto L3; // [176] 75
L4: 
        ;
    }

    /** regex.e:1062		return match_data*/
    DeRef(_re_22599);
    DeRef(_haystack_22601);
    DeRef(_options_22603);
    _12775 = NOVALUE;
    _12773 = NOVALUE;
    return _match_data_22609;
    ;
}


object _52split(object _re_22686, object _text_22688, object _from_22689, object _options_22690)
{
    object _12807 = NOVALUE;
    object _0, _1, _2;
    

    /** regex.e:1198		return split_limit(re, text, 0, from, options)*/
    Ref(_re_22686);
    RefDS(_text_22688);
    _12807 = _52split_limit(_re_22686, _text_22688, 0, 1, 0);
    DeRef(_re_22686);
    DeRefDS(_text_22688);
    return _12807;
    ;
}


object _52split_limit(object _re_22695, object _text_22697, object _limit_22698, object _from_22699, object _options_22700)
{
    object _match_data_22704 = NOVALUE;
    object _result_22707 = NOVALUE;
    object _last_22708 = NOVALUE;
    object _a_22719 = NOVALUE;
    object _12833 = NOVALUE;
    object _12832 = NOVALUE;
    object _12831 = NOVALUE;
    object _12829 = NOVALUE;
    object _12827 = NOVALUE;
    object _12826 = NOVALUE;
    object _12825 = NOVALUE;
    object _12824 = NOVALUE;
    object _12823 = NOVALUE;
    object _12820 = NOVALUE;
    object _12819 = NOVALUE;
    object _12818 = NOVALUE;
    object _12815 = NOVALUE;
    object _12814 = NOVALUE;
    object _12812 = NOVALUE;
    object _12810 = NOVALUE;
    object _12808 = NOVALUE;
    object _0, _1, _2;
    

    /** regex.e:1202		if sequence(options) then */
    _12808 = 0;
    if (_12808 == 0)
    {
        _12808 = NOVALUE;
        goto L1; // [10] 20
    }
    else{
        _12808 = NOVALUE;
    }

    /** regex.e:1203			options = math:or_all(options) */
    _options_22700 = _20or_all(0);
L1: 

    /** regex.e:1205		sequence match_data = find_all(re, text, from, options), result*/
    Ref(_re_22695);
    _12810 = _52get_ovector_size(_re_22695, 30);
    Ref(_re_22695);
    Ref(_text_22697);
    Ref(_options_22700);
    _0 = _match_data_22704;
    _match_data_22704 = _52find_all(_re_22695, _text_22697, _from_22699, _options_22700, _12810);
    DeRef(_0);
    _12810 = NOVALUE;

    /** regex.e:1206		integer last = 1*/
    _last_22708 = 1;

    /** regex.e:1208		if limit = 0 or limit > length(match_data) then*/
    _12812 = (_limit_22698 == 0);
    if (_12812 != 0) {
        goto L2; // [48] 64
    }
    if (IS_SEQUENCE(_match_data_22704)){
            _12814 = SEQ_PTR(_match_data_22704)->length;
    }
    else {
        _12814 = 1;
    }
    _12815 = (_limit_22698 > _12814);
    _12814 = NOVALUE;
    if (_12815 == 0)
    {
        DeRef(_12815);
        _12815 = NOVALUE;
        goto L3; // [60] 70
    }
    else{
        DeRef(_12815);
        _12815 = NOVALUE;
    }
L2: 

    /** regex.e:1209			limit = length(match_data)*/
    if (IS_SEQUENCE(_match_data_22704)){
            _limit_22698 = SEQ_PTR(_match_data_22704)->length;
    }
    else {
        _limit_22698 = 1;
    }
L3: 

    /** regex.e:1212		result = repeat(0, limit)*/
    DeRef(_result_22707);
    _result_22707 = Repeat(0, _limit_22698);

    /** regex.e:1214		for i = 1 to limit do*/
    _12818 = _limit_22698;
    {
        object _i_22717;
        _i_22717 = 1;
L4: 
        if (_i_22717 > _12818){
            goto L5; // [81] 164
        }

        /** regex.e:1215			integer a*/

        /** regex.e:1216			a = match_data[i][1][1]*/
        _2 = (object)SEQ_PTR(_match_data_22704);
        _12819 = (object)*(((s1_ptr)_2)->base + _i_22717);
        _2 = (object)SEQ_PTR(_12819);
        _12820 = (object)*(((s1_ptr)_2)->base + 1);
        _12819 = NOVALUE;
        _2 = (object)SEQ_PTR(_12820);
        _a_22719 = (object)*(((s1_ptr)_2)->base + 1);
        if (!IS_ATOM_INT(_a_22719)){
            _a_22719 = (object)DBL_PTR(_a_22719)->dbl;
        }
        _12820 = NOVALUE;

        /** regex.e:1217			if a = 0 then*/
        if (_a_22719 != 0)
        goto L6; // [108] 121

        /** regex.e:1218				result[i] = ""*/
        RefDS(_5);
        _2 = (object)SEQ_PTR(_result_22707);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _result_22707 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_22717);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _5;
        DeRef(_1);
        goto L7; // [118] 155
L6: 

        /** regex.e:1220				result[i] = text[last..a - 1]*/
        _12823 = _a_22719 - 1;
        rhs_slice_target = (object_ptr)&_12824;
        RHS_Slice(_text_22697, _last_22708, _12823);
        _2 = (object)SEQ_PTR(_result_22707);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _result_22707 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_22717);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _12824;
        if( _1 != _12824 ){
            DeRef(_1);
        }
        _12824 = NOVALUE;

        /** regex.e:1221				last = match_data[i][1][2] + 1*/
        _2 = (object)SEQ_PTR(_match_data_22704);
        _12825 = (object)*(((s1_ptr)_2)->base + _i_22717);
        _2 = (object)SEQ_PTR(_12825);
        _12826 = (object)*(((s1_ptr)_2)->base + 1);
        _12825 = NOVALUE;
        _2 = (object)SEQ_PTR(_12826);
        _12827 = (object)*(((s1_ptr)_2)->base + 2);
        _12826 = NOVALUE;
        if (IS_ATOM_INT(_12827)) {
            _last_22708 = _12827 + 1;
        }
        else
        { // coercing _last_22708 to an integer 1
            _last_22708 = 1+(object)(DBL_PTR(_12827)->dbl);
            if( !IS_ATOM_INT(_last_22708) ){
                _last_22708 = (object)DBL_PTR(_last_22708)->dbl;
            }
        }
        _12827 = NOVALUE;
L7: 

        /** regex.e:1223		end for*/
        _i_22717 = _i_22717 + 1;
        goto L4; // [159] 88
L5: 
        ;
    }

    /** regex.e:1225		if last < length(text) then*/
    if (IS_SEQUENCE(_text_22697)){
            _12829 = SEQ_PTR(_text_22697)->length;
    }
    else {
        _12829 = 1;
    }
    if (_last_22708 >= _12829)
    goto L8; // [169] 192

    /** regex.e:1226			result &= { text[last..$] }*/
    if (IS_SEQUENCE(_text_22697)){
            _12831 = SEQ_PTR(_text_22697)->length;
    }
    else {
        _12831 = 1;
    }
    rhs_slice_target = (object_ptr)&_12832;
    RHS_Slice(_text_22697, _last_22708, _12831);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _12832;
    _12833 = MAKE_SEQ(_1);
    _12832 = NOVALUE;
    Concat((object_ptr)&_result_22707, _result_22707, _12833);
    DeRefDS(_12833);
    _12833 = NOVALUE;
L8: 

    /** regex.e:1229		return result*/
    DeRef(_re_22695);
    DeRef(_text_22697);
    DeRef(_options_22700);
    DeRef(_match_data_22704);
    DeRef(_12812);
    _12812 = NOVALUE;
    DeRef(_12823);
    _12823 = NOVALUE;
    return _result_22707;
    ;
}


object _52find_replace(object _ex_22741, object _text_22743, object _replacement_22744, object _from_22745, object _options_22746)
{
    object _12835 = NOVALUE;
    object _0, _1, _2;
    

    /** regex.e:1280		return find_replace_limit(ex, text, replacement, -1, from, options)*/
    Ref(_ex_22741);
    RefDS(_text_22743);
    RefDS(_replacement_22744);
    _12835 = _52find_replace_limit(_ex_22741, _text_22743, _replacement_22744, -1, 1, 0);
    DeRef(_ex_22741);
    DeRefDS(_text_22743);
    DeRefDS(_replacement_22744);
    return _12835;
    ;
}


object _52find_replace_limit(object _ex_22751, object _text_22753, object _replacement_22754, object _limit_22755, object _from_22756, object _options_22757)
{
    object _12839 = NOVALUE;
    object _12838 = NOVALUE;
    object _12836 = NOVALUE;
    object _0, _1, _2;
    

    /** regex.e:1312		if sequence(options) then */
    _12836 = 0;
    if (_12836 == 0)
    {
        _12836 = NOVALUE;
        goto L1; // [12] 22
    }
    else{
        _12836 = NOVALUE;
    }

    /** regex.e:1313			options = math:or_all(options) */
    _options_22757 = _20or_all(0);
L1: 

    /** regex.e:1316	    return machine_func(M_PCRE_REPLACE, { ex, text, replacement, options, */
    _1 = NewS1(6);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_ex_22751);
    ((intptr_t*)_2)[1] = _ex_22751;
    Ref(_text_22753);
    ((intptr_t*)_2)[2] = _text_22753;
    RefDS(_replacement_22754);
    ((intptr_t*)_2)[3] = _replacement_22754;
    Ref(_options_22757);
    ((intptr_t*)_2)[4] = _options_22757;
    ((intptr_t*)_2)[5] = _from_22756;
    ((intptr_t*)_2)[6] = _limit_22755;
    _12838 = MAKE_SEQ(_1);
    _12839 = machine(71, _12838);
    DeRefDS(_12838);
    _12838 = NOVALUE;
    DeRef(_ex_22751);
    DeRef(_text_22753);
    DeRefDS(_replacement_22754);
    DeRef(_options_22757);
    return _12839;
    ;
}



// 0xEF7AF571
