// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _5any_key(object _prompt_13907, object _con_13909)
{
    object _wait_key_inlined_wait_key_at_27_13914 = NOVALUE;
    object _7712 = NOVALUE;
    object _0, _1, _2;
    

    /** console.e:883		if not find(con, {1,2}) then*/
    _7712 = find_from(_con_13909, _7247, 1);
    if (_7712 != 0)
    goto L1; // [12] 21
    _7712 = NOVALUE;

    /** console.e:884			con = 1*/
    _con_13909 = 1;
L1: 

    /** console.e:886		puts(con, prompt)*/
    EPuts(_con_13909, _prompt_13907); // DJP 

    /** console.e:887		wait_key()*/

    /** console.e:854		return machine_func(M_WAIT_KEY, 0)*/
    _wait_key_inlined_wait_key_at_27_13914 = machine(26, 0);

    /** console.e:888		puts(con, "\n")*/
    EPuts(_con_13909, _3153); // DJP 

    /** console.e:889	end procedure*/
    DeRefDS(_prompt_13907);
    return;
    ;
}


void _5maybe_any_key(object _prompt_13917, object _con_13918)
{
    object _has_console_inlined_has_console_at_6_13921 = NOVALUE;
    object _0, _1, _2;
    

    /** console.e:923		if not has_console() then*/

    /** console.e:59		return machine_func(M_HAS_CONSOLE, 0)*/
    DeRef(_has_console_inlined_has_console_at_6_13921);
    _has_console_inlined_has_console_at_6_13921 = machine(99, 0);
    if (IS_ATOM_INT(_has_console_inlined_has_console_at_6_13921)) {
        if (_has_console_inlined_has_console_at_6_13921 != 0){
            goto L1; // [14] 24
        }
    }
    else {
        if (DBL_PTR(_has_console_inlined_has_console_at_6_13921)->dbl != 0.0){
            goto L1; // [14] 24
        }
    }

    /** console.e:924			any_key(prompt, con)*/
    RefDS(_prompt_13917);
    _5any_key(_prompt_13917, _con_13918);
L1: 

    /** console.e:926	end procedure*/
    DeRefDS(_prompt_13917);
    return;
    ;
}



// 0x05F96648
