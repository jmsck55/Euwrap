// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _55c_putc(object _c_46986)
{
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_c_46986)) {
        _1 = (object)(DBL_PTR(_c_46986)->dbl);
        DeRefDS(_c_46986);
        _c_46986 = _1;
    }

    /** c_out.e:62		if emit_c_output then*/
    if (_55emit_c_output_46973 == 0)
    {
        goto L1; // [7] 23
    }
    else{
    }

    /** c_out.e:63			puts(c_code, c)*/
    EPuts(_55c_code_46976, _c_46986); // DJP 

    /** c_out.e:64			update_checksum( c )*/
    _56update_checksum(_c_46986);
L1: 

    /** c_out.e:66	end procedure*/
    return;
    ;
}


void _55c_hputs(object _c_source_46991)
{
    object _0, _1, _2;
    

    /** c_out.e:71		if emit_c_output then*/
    if (_55emit_c_output_46973 == 0)
    {
        goto L1; // [7] 18
    }
    else{
    }

    /** c_out.e:72			puts(c_h, c_source)    */
    EPuts(_55c_h_46977, _c_source_46991); // DJP 
L1: 

    /** c_out.e:74	end procedure*/
    DeRefDS(_c_source_46991);
    return;
    ;
}


void _55c_puts(object _c_source_46995)
{
    object _0, _1, _2;
    

    /** c_out.e:79		if emit_c_output then*/
    if (_55emit_c_output_46973 == 0)
    {
        goto L1; // [7] 23
    }
    else{
    }

    /** c_out.e:80			puts(c_code, c_source)*/
    EPuts(_55c_code_46976, _c_source_46995); // DJP 

    /** c_out.e:81			update_checksum( c_source )*/
    RefDS(_c_source_46995);
    _56update_checksum(_c_source_46995);
L1: 

    /** c_out.e:83	end procedure*/
    DeRefDS(_c_source_46995);
    return;
    ;
}


void _55c_hprintf(object _format_47000, object _value_47001)
{
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_value_47001)) {
        _1 = (object)(DBL_PTR(_value_47001)->dbl);
        DeRefDS(_value_47001);
        _value_47001 = _1;
    }

    /** c_out.e:88		if emit_c_output then*/
    if (_55emit_c_output_46973 == 0)
    {
        goto L1; // [9] 21
    }
    else{
    }

    /** c_out.e:89			printf(c_h, format, value)*/
    EPrintf(_55c_h_46977, _format_47000, _value_47001);
L1: 

    /** c_out.e:91	end procedure*/
    DeRefDSi(_format_47000);
    return;
    ;
}


void _55c_printf(object _format_47005, object _value_47006)
{
    object _text_47008 = NOVALUE;
    object _0, _1, _2;
    

    /** c_out.e:96		if emit_c_output then*/
    if (_55emit_c_output_46973 == 0)
    {
        goto L1; // [7] 29
    }
    else{
    }

    /** c_out.e:97			sequence text = sprintf( format, value )*/
    DeRefi(_text_47008);
    _text_47008 = EPrintf(-9999999, _format_47005, _value_47006);

    /** c_out.e:98			puts(c_code, text)*/
    EPuts(_55c_code_46976, _text_47008); // DJP 

    /** c_out.e:99			update_checksum( text )*/
    RefDS(_text_47008);
    _56update_checksum(_text_47008);
L1: 
    DeRefi(_text_47008);
    _text_47008 = NOVALUE;

    /** c_out.e:101	end procedure*/
    DeRefDSi(_format_47005);
    DeRef(_value_47006);
    return;
    ;
}


void _55c_printf8(object _value_47019)
{
    object _buff_47020 = NOVALUE;
    object _neg_47021 = NOVALUE;
    object _p_47022 = NOVALUE;
    object _24448 = NOVALUE;
    object _24447 = NOVALUE;
    object _24446 = NOVALUE;
    object _24444 = NOVALUE;
    object _24443 = NOVALUE;
    object _24441 = NOVALUE;
    object _24440 = NOVALUE;
    object _24438 = NOVALUE;
    object _24437 = NOVALUE;
    object _24435 = NOVALUE;
    object _24433 = NOVALUE;
    object _24431 = NOVALUE;
    object _0, _1, _2;
    

    /** c_out.e:115		if emit_c_output then*/
    if (_55emit_c_output_46973 == 0)
    {
        goto L1; // [5] 217
    }
    else{
    }

    /** c_out.e:116			neg = 0*/
    _neg_47021 = 0;

    /** c_out.e:117			buff = sprintf("%.20eL", value)*/
    DeRef(_buff_47020);
    _buff_47020 = EPrintf(-9999999, _24429, _value_47019);

    /** c_out.e:118			if length(buff) < 10 then*/
    if (IS_SEQUENCE(_buff_47020)){
            _24431 = SEQ_PTR(_buff_47020)->length;
    }
    else {
        _24431 = 1;
    }
    if (_24431 >= 10)
    goto L2; // [24] 209

    /** c_out.e:120				p = 1*/
    _p_47022 = 1;

    /** c_out.e:121				while p <= length(buff) do*/
L3: 
    if (IS_SEQUENCE(_buff_47020)){
            _24433 = SEQ_PTR(_buff_47020)->length;
    }
    else {
        _24433 = 1;
    }
    if (_p_47022 > _24433)
    goto L4; // [41] 208

    /** c_out.e:122					if buff[p] = '-' then*/
    _2 = (object)SEQ_PTR(_buff_47020);
    _24435 = (object)*(((s1_ptr)_2)->base + _p_47022);
    if (binary_op_a(NOTEQ, _24435, 45)){
        _24435 = NOVALUE;
        goto L5; // [51] 63
    }
    _24435 = NOVALUE;

    /** c_out.e:123						neg = 1*/
    _neg_47021 = 1;
    goto L6; // [60] 197
L5: 

    /** c_out.e:125					elsif buff[p] = 'i' or buff[p] = 'I' then*/
    _2 = (object)SEQ_PTR(_buff_47020);
    _24437 = (object)*(((s1_ptr)_2)->base + _p_47022);
    if (IS_ATOM_INT(_24437)) {
        _24438 = (_24437 == 105);
    }
    else {
        _24438 = binary_op(EQUALS, _24437, 105);
    }
    _24437 = NOVALUE;
    if (IS_ATOM_INT(_24438)) {
        if (_24438 != 0) {
            goto L7; // [73] 90
        }
    }
    else {
        if (DBL_PTR(_24438)->dbl != 0.0) {
            goto L7; // [73] 90
        }
    }
    _2 = (object)SEQ_PTR(_buff_47020);
    _24440 = (object)*(((s1_ptr)_2)->base + _p_47022);
    if (IS_ATOM_INT(_24440)) {
        _24441 = (_24440 == 73);
    }
    else {
        _24441 = binary_op(EQUALS, _24440, 73);
    }
    _24440 = NOVALUE;
    if (_24441 == 0) {
        DeRef(_24441);
        _24441 = NOVALUE;
        goto L8; // [86] 114
    }
    else {
        if (!IS_ATOM_INT(_24441) && DBL_PTR(_24441)->dbl == 0.0){
            DeRef(_24441);
            _24441 = NOVALUE;
            goto L8; // [86] 114
        }
        DeRef(_24441);
        _24441 = NOVALUE;
    }
    DeRef(_24441);
    _24441 = NOVALUE;
L7: 

    /** c_out.e:127						buff = CREATE_INF*/
    RefDS(_55CREATE_INF_47011);
    DeRef(_buff_47020);
    _buff_47020 = _55CREATE_INF_47011;

    /** c_out.e:128						if neg then*/
    if (_neg_47021 == 0)
    {
        goto L4; // [97] 208
    }
    else{
    }

    /** c_out.e:129							buff = prepend(buff, '-')*/
    Prepend(&_buff_47020, _buff_47020, 45);

    /** c_out.e:131						exit*/
    goto L4; // [109] 208
    goto L6; // [111] 197
L8: 

    /** c_out.e:133					elsif buff[p] = 'n' or buff[p] = 'N' then*/
    _2 = (object)SEQ_PTR(_buff_47020);
    _24443 = (object)*(((s1_ptr)_2)->base + _p_47022);
    if (IS_ATOM_INT(_24443)) {
        _24444 = (_24443 == 110);
    }
    else {
        _24444 = binary_op(EQUALS, _24443, 110);
    }
    _24443 = NOVALUE;
    if (IS_ATOM_INT(_24444)) {
        if (_24444 != 0) {
            goto L9; // [124] 141
        }
    }
    else {
        if (DBL_PTR(_24444)->dbl != 0.0) {
            goto L9; // [124] 141
        }
    }
    _2 = (object)SEQ_PTR(_buff_47020);
    _24446 = (object)*(((s1_ptr)_2)->base + _p_47022);
    if (IS_ATOM_INT(_24446)) {
        _24447 = (_24446 == 78);
    }
    else {
        _24447 = binary_op(EQUALS, _24446, 78);
    }
    _24446 = NOVALUE;
    if (_24447 == 0) {
        DeRef(_24447);
        _24447 = NOVALUE;
        goto LA; // [137] 196
    }
    else {
        if (!IS_ATOM_INT(_24447) && DBL_PTR(_24447)->dbl == 0.0){
            DeRef(_24447);
            _24447 = NOVALUE;
            goto LA; // [137] 196
        }
        DeRef(_24447);
        _24447 = NOVALUE;
    }
    DeRef(_24447);
    _24447 = NOVALUE;
L9: 

    /** c_out.e:135						ifdef UNIX then*/

    /** c_out.e:141							if sequence(wat_path) then*/
    _24448 = IS_SEQUENCE(_36wat_path_21848);
    if (_24448 == 0)
    {
        _24448 = NOVALUE;
        goto LB; // [150] 173
    }
    else{
        _24448 = NOVALUE;
    }

    /** c_out.e:142								buff = CREATE_NAN2*/
    RefDS(_55CREATE_NAN2_47015);
    DeRef(_buff_47020);
    _buff_47020 = _55CREATE_NAN2_47015;

    /** c_out.e:143								if not neg then*/
    if (_neg_47021 != 0)
    goto L4; // [160] 208

    /** c_out.e:144									buff = prepend(buff, '-')*/
    Prepend(&_buff_47020, _buff_47020, 45);
    goto L4; // [170] 208
LB: 

    /** c_out.e:148								buff = CREATE_NAN1*/
    RefDS(_55CREATE_NAN1_47013);
    DeRef(_buff_47020);
    _buff_47020 = _55CREATE_NAN1_47013;

    /** c_out.e:149								if neg then*/
    if (_neg_47021 == 0)
    {
        goto L4; // [180] 208
    }
    else{
    }

    /** c_out.e:150									buff = prepend(buff, '-')*/
    Prepend(&_buff_47020, _buff_47020, 45);

    /** c_out.e:153							exit*/
    goto L4; // [193] 208
LA: 
L6: 

    /** c_out.e:156					p += 1*/
    _p_47022 = _p_47022 + 1;

    /** c_out.e:157				end while*/
    goto L3; // [205] 38
L4: 
L2: 

    /** c_out.e:159			puts(c_code, buff)*/
    EPuts(_55c_code_46976, _buff_47020); // DJP 
L1: 

    /** c_out.e:161	end procedure*/
    DeRef(_value_47019);
    DeRef(_buff_47020);
    DeRef(_24438);
    _24438 = NOVALUE;
    DeRef(_24444);
    _24444 = NOVALUE;
    return;
    ;
}


void _55adjust_indent_before(object _stmt_47065)
{
    object _i_47066 = NOVALUE;
    object _lb_47068 = NOVALUE;
    object _rb_47069 = NOVALUE;
    object _24465 = NOVALUE;
    object _24463 = NOVALUE;
    object _24461 = NOVALUE;
    object _24455 = NOVALUE;
    object _24454 = NOVALUE;
    object _0, _1, _2;
    

    /** c_out.e:177		lb = FALSE*/
    _lb_47068 = _13FALSE_445;

    /** c_out.e:178		rb = FALSE*/
    _rb_47069 = _13FALSE_445;

    /** c_out.e:180		for p = 1 to length(stmt) do*/
    if (IS_SEQUENCE(_stmt_47065)){
            _24454 = SEQ_PTR(_stmt_47065)->length;
    }
    else {
        _24454 = 1;
    }
    {
        object _p_47073;
        _p_47073 = 1;
L1: 
        if (_p_47073 > _24454){
            goto L2; // [22] 102
        }

        /** c_out.e:181			switch stmt[p] do*/
        _2 = (object)SEQ_PTR(_stmt_47065);
        _24455 = (object)*(((s1_ptr)_2)->base + _p_47073);
        if (IS_SEQUENCE(_24455) ){
            goto L3; // [35] 95
        }
        if(!IS_ATOM_INT(_24455)){
            if( (DBL_PTR(_24455)->dbl != (eudouble) ((object) DBL_PTR(_24455)->dbl) ) ){
                goto L3; // [35] 95
            }
            _0 = (object) DBL_PTR(_24455)->dbl;
        }
        else {
            _0 = _24455;
        };
        _24455 = NOVALUE;
        switch ( _0 ){ 

            /** c_out.e:182				case '\n' then*/
            case 10:

            /** c_out.e:183					exit*/
            goto L2; // [46] 102
            goto L3; // [48] 95

            /** c_out.e:185				case  '}' then*/
            case 125:

            /** c_out.e:186					rb = TRUE*/
            _rb_47069 = _13TRUE_447;

            /** c_out.e:187					if lb then*/
            if (_lb_47068 == 0)
            {
                goto L3; // [63] 95
            }
            else{
            }

            /** c_out.e:188						exit*/
            goto L2; // [68] 102
            goto L3; // [71] 95

            /** c_out.e:191				case '{' then*/
            case 123:

            /** c_out.e:192					lb = TRUE*/
            _lb_47068 = _13TRUE_447;

            /** c_out.e:193					if rb then */
            if (_rb_47069 == 0)
            {
                goto L4; // [86] 94
            }
            else{
            }

            /** c_out.e:194						exit*/
            goto L2; // [91] 102
L4: 
        ;}L3: 

        /** c_out.e:198		end for*/
        _p_47073 = _p_47073 + 1;
        goto L1; // [97] 29
L2: 
        ;
    }

    /** c_out.e:200		if rb then*/
    if (_rb_47069 == 0)
    {
        goto L5; // [104] 122
    }
    else{
    }

    /** c_out.e:201			if not lb then*/
    if (_lb_47068 != 0)
    goto L6; // [109] 121

    /** c_out.e:202				indent -= 4*/
    _55indent_47059 = _55indent_47059 - 4;
L6: 
L5: 

    /** c_out.e:206		i = indent + temp_indent*/
    _i_47066 = _55indent_47059 + _55temp_indent_47060;

    /** c_out.e:207		while i >= length(big_blanks) do*/
L7: 
    if (IS_SEQUENCE(_55big_blanks_47061)){
            _24461 = SEQ_PTR(_55big_blanks_47061)->length;
    }
    else {
        _24461 = 1;
    }
    if (_i_47066 < _24461)
    goto L8; // [140] 163

    /** c_out.e:208			c_puts(big_blanks)*/
    RefDS(_55big_blanks_47061);
    _55c_puts(_55big_blanks_47061);

    /** c_out.e:209			i -= length(big_blanks)*/
    if (IS_SEQUENCE(_55big_blanks_47061)){
            _24463 = SEQ_PTR(_55big_blanks_47061)->length;
    }
    else {
        _24463 = 1;
    }
    _i_47066 = _i_47066 - _24463;
    _24463 = NOVALUE;

    /** c_out.e:210		end while*/
    goto L7; // [160] 137
L8: 

    /** c_out.e:212		c_puts(big_blanks[1..i])*/
    rhs_slice_target = (object_ptr)&_24465;
    RHS_Slice(_55big_blanks_47061, 1, _i_47066);
    _55c_puts(_24465);
    _24465 = NOVALUE;

    /** c_out.e:214		temp_indent = 0    */
    _55temp_indent_47060 = 0;

    /** c_out.e:215	end procedure*/
    DeRefDS(_stmt_47065);
    return;
    ;
}


void _55adjust_indent_after(object _stmt_47098)
{
    object _24486 = NOVALUE;
    object _24485 = NOVALUE;
    object _24483 = NOVALUE;
    object _24481 = NOVALUE;
    object _24480 = NOVALUE;
    object _24477 = NOVALUE;
    object _24475 = NOVALUE;
    object _24474 = NOVALUE;
    object _24471 = NOVALUE;
    object _24467 = NOVALUE;
    object _24466 = NOVALUE;
    object _0, _1, _2;
    

    /** c_out.e:221		for p = 1 to length(stmt) do*/
    if (IS_SEQUENCE(_stmt_47098)){
            _24466 = SEQ_PTR(_stmt_47098)->length;
    }
    else {
        _24466 = 1;
    }
    {
        object _p_47100;
        _p_47100 = 1;
L1: 
        if (_p_47100 > _24466){
            goto L2; // [8] 61
        }

        /** c_out.e:222			switch stmt[p] do*/
        _2 = (object)SEQ_PTR(_stmt_47098);
        _24467 = (object)*(((s1_ptr)_2)->base + _p_47100);
        if (IS_SEQUENCE(_24467) ){
            goto L3; // [21] 54
        }
        if(!IS_ATOM_INT(_24467)){
            if( (DBL_PTR(_24467)->dbl != (eudouble) ((object) DBL_PTR(_24467)->dbl) ) ){
                goto L3; // [21] 54
            }
            _0 = (object) DBL_PTR(_24467)->dbl;
        }
        else {
            _0 = _24467;
        };
        _24467 = NOVALUE;
        switch ( _0 ){ 

            /** c_out.e:223				case '\n' then*/
            case 10:

            /** c_out.e:224					exit*/
            goto L2; // [32] 61
            goto L3; // [34] 54

            /** c_out.e:226				case '{' then*/
            case 123:

            /** c_out.e:227					indent += 4*/
            _55indent_47059 = _55indent_47059 + 4;

            /** c_out.e:228					return*/
            DeRefDS(_stmt_47098);
            return;
        ;}L3: 

        /** c_out.e:230		end for*/
        _p_47100 = _p_47100 + 1;
        goto L1; // [56] 15
L2: 
        ;
    }

    /** c_out.e:232		if length(stmt) < 3 then*/
    if (IS_SEQUENCE(_stmt_47098)){
            _24471 = SEQ_PTR(_stmt_47098)->length;
    }
    else {
        _24471 = 1;
    }
    if (_24471 >= 3)
    goto L4; // [66] 76

    /** c_out.e:233			return*/
    DeRefDS(_stmt_47098);
    return;
L4: 

    /** c_out.e:236		if not equal("if ", stmt[1..3]) then*/
    rhs_slice_target = (object_ptr)&_24474;
    RHS_Slice(_stmt_47098, 1, 3);
    if (_24473 == _24474)
    _24475 = 1;
    else if (IS_ATOM_INT(_24473) && IS_ATOM_INT(_24474))
    _24475 = 0;
    else
    _24475 = (compare(_24473, _24474) == 0);
    DeRefDS(_24474);
    _24474 = NOVALUE;
    if (_24475 != 0)
    goto L5; // [87] 96
    _24475 = NOVALUE;

    /** c_out.e:237			return*/
    DeRefDS(_stmt_47098);
    return;
L5: 

    /** c_out.e:240		if length(stmt) < 5 then*/
    if (IS_SEQUENCE(_stmt_47098)){
            _24477 = SEQ_PTR(_stmt_47098)->length;
    }
    else {
        _24477 = 1;
    }
    if (_24477 >= 5)
    goto L6; // [101] 111

    /** c_out.e:241			return*/
    DeRefDS(_stmt_47098);
    return;
L6: 

    /** c_out.e:244		if not equal("else", stmt[1..4]) then*/
    rhs_slice_target = (object_ptr)&_24480;
    RHS_Slice(_stmt_47098, 1, 4);
    if (_24479 == _24480)
    _24481 = 1;
    else if (IS_ATOM_INT(_24479) && IS_ATOM_INT(_24480))
    _24481 = 0;
    else
    _24481 = (compare(_24479, _24480) == 0);
    DeRefDS(_24480);
    _24480 = NOVALUE;
    if (_24481 != 0)
    goto L7; // [122] 131
    _24481 = NOVALUE;

    /** c_out.e:245			return*/
    DeRefDS(_stmt_47098);
    return;
L7: 

    /** c_out.e:248		if not find(stmt[5], {" \n"}) then*/
    _2 = (object)SEQ_PTR(_stmt_47098);
    _24483 = (object)*(((s1_ptr)_2)->base + 5);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_24484);
    ((intptr_t*)_2)[1] = _24484;
    _24485 = MAKE_SEQ(_1);
    _24486 = find_from(_24483, _24485, 1);
    _24483 = NOVALUE;
    DeRefDS(_24485);
    _24485 = NOVALUE;
    if (_24486 != 0)
    goto L8; // [146] 155
    _24486 = NOVALUE;

    /** c_out.e:249			return*/
    DeRefDS(_stmt_47098);
    return;
L8: 

    /** c_out.e:252		temp_indent = 4*/
    _55temp_indent_47060 = 4;

    /** c_out.e:254	end procedure*/
    DeRefDS(_stmt_47098);
    return;
    ;
}



// 0x3C928FF6
