// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _56find_file(object _fname_45631)
{
    object _23770 = NOVALUE;
    object _23769 = NOVALUE;
    object _23768 = NOVALUE;
    object _23767 = NOVALUE;
    object _23765 = NOVALUE;
    object _23764 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:30		for i = 1 to length(inc_dirs) do*/
    _23764 = 3;
    {
        object _i_45633;
        _i_45633 = 1;
L1: 
        if (_i_45633 > 3){
            goto L2; // [10] 64
        }

        /** buildsys.e:31			if file_exists(inc_dirs[i] & "/" & fname) then*/
        _2 = (object)SEQ_PTR(_56inc_dirs_45623);
        _23765 = (object)*(((s1_ptr)_2)->base + _i_45633);
        {
            object concat_list[3];

            concat_list[0] = _fname_45631;
            concat_list[1] = _23766;
            concat_list[2] = _23765;
            Concat_N((object_ptr)&_23767, concat_list, 3);
        }
        _23765 = NOVALUE;
        _23768 = _17file_exists(_23767);
        _23767 = NOVALUE;
        if (_23768 == 0) {
            DeRef(_23768);
            _23768 = NOVALUE;
            goto L3; // [35] 57
        }
        else {
            if (!IS_ATOM_INT(_23768) && DBL_PTR(_23768)->dbl == 0.0){
                DeRef(_23768);
                _23768 = NOVALUE;
                goto L3; // [35] 57
            }
            DeRef(_23768);
            _23768 = NOVALUE;
        }
        DeRef(_23768);
        _23768 = NOVALUE;

        /** buildsys.e:32				return inc_dirs[i] & "/" & fname*/
        _2 = (object)SEQ_PTR(_56inc_dirs_45623);
        _23769 = (object)*(((s1_ptr)_2)->base + _i_45633);
        {
            object concat_list[3];

            concat_list[0] = _fname_45631;
            concat_list[1] = _23766;
            concat_list[2] = _23769;
            Concat_N((object_ptr)&_23770, concat_list, 3);
        }
        _23769 = NOVALUE;
        DeRefDS(_fname_45631);
        return _23770;
L3: 

        /** buildsys.e:34		end for*/
        _i_45633 = _i_45633 + 1;
        goto L1; // [59] 17
L2: 
        ;
    }

    /** buildsys.e:36		return 0*/
    DeRefDS(_fname_45631);
    DeRef(_23770);
    _23770 = NOVALUE;
    return 0;
    ;
}


object _56find_all_includes(object _fname_45645, object _includes_45646)
{
    object _lines_45647 = NOVALUE;
    object _m_45653 = NOVALUE;
    object _full_fname_45658 = NOVALUE;
    object _23783 = NOVALUE;
    object _23781 = NOVALUE;
    object _23779 = NOVALUE;
    object _23778 = NOVALUE;
    object _23776 = NOVALUE;
    object _23775 = NOVALUE;
    object _23773 = NOVALUE;
    object _23772 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:40		sequence lines = read_lines(fname)*/
    RefDS(_fname_45645);
    _0 = _lines_45647;
    _lines_45647 = _8read_lines(_fname_45645);
    DeRef(_0);

    /** buildsys.e:42		for i = 1 to length(lines) do*/
    if (IS_SEQUENCE(_lines_45647)){
            _23772 = SEQ_PTR(_lines_45647)->length;
    }
    else {
        _23772 = 1;
    }
    {
        object _i_45651;
        _i_45651 = 1;
L1: 
        if (_i_45651 > _23772){
            goto L2; // [18] 113
        }

        /** buildsys.e:43			object m = regex:matches(re_include, lines[i])*/
        _2 = (object)SEQ_PTR(_lines_45647);
        _23773 = (object)*(((s1_ptr)_2)->base + _i_45651);
        Ref(_56re_include_45620);
        Ref(_23773);
        _0 = _m_45653;
        _m_45653 = _52matches(_56re_include_45620, _23773, 1, 0);
        DeRef(_0);
        _23773 = NOVALUE;

        /** buildsys.e:44			if sequence(m) then*/
        _23775 = IS_SEQUENCE(_m_45653);
        if (_23775 == 0)
        {
            _23775 = NOVALUE;
            goto L3; // [45] 102
        }
        else{
            _23775 = NOVALUE;
        }

        /** buildsys.e:45				object full_fname = find_file(m[3])*/
        _2 = (object)SEQ_PTR(_m_45653);
        _23776 = (object)*(((s1_ptr)_2)->base + 3);
        Ref(_23776);
        _0 = _full_fname_45658;
        _full_fname_45658 = _56find_file(_23776);
        DeRef(_0);
        _23776 = NOVALUE;

        /** buildsys.e:46				if sequence(full_fname) then*/
        _23778 = IS_SEQUENCE(_full_fname_45658);
        if (_23778 == 0)
        {
            _23778 = NOVALUE;
            goto L4; // [63] 101
        }
        else{
            _23778 = NOVALUE;
        }

        /** buildsys.e:47					if eu:find(full_fname, includes) = 0 then*/
        _23779 = find_from(_full_fname_45658, _includes_45646, 1);
        if (_23779 != 0)
        goto L5; // [73] 100

        /** buildsys.e:48						includes &= { full_fname }*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        Ref(_full_fname_45658);
        ((intptr_t*)_2)[1] = _full_fname_45658;
        _23781 = MAKE_SEQ(_1);
        Concat((object_ptr)&_includes_45646, _includes_45646, _23781);
        DeRefDS(_23781);
        _23781 = NOVALUE;

        /** buildsys.e:49						includes = find_all_includes(full_fname, includes)*/
        RefDS(_includes_45646);
        DeRef(_23783);
        _23783 = _includes_45646;
        Ref(_full_fname_45658);
        _0 = _includes_45646;
        _includes_45646 = _56find_all_includes(_full_fname_45658, _23783);
        DeRefDS(_0);
        _23783 = NOVALUE;
L5: 
L4: 
L3: 
        DeRef(_full_fname_45658);
        _full_fname_45658 = NOVALUE;
        DeRef(_m_45653);
        _m_45653 = NOVALUE;

        /** buildsys.e:53		end for*/
        _i_45651 = _i_45651 + 1;
        goto L1; // [108] 25
L2: 
        ;
    }

    /** buildsys.e:55		return includes*/
    DeRefDS(_fname_45645);
    DeRef(_lines_45647);
    return _includes_45646;
    ;
}


object _56quick_has_changed(object _fname_45672)
{
    object _d1_45673 = NOVALUE;
    object _all_files_45683 = NOVALUE;
    object _d2_45689 = NOVALUE;
    object _diff_2__tmp_at88_45699 = NOVALUE;
    object _diff_1__tmp_at88_45698 = NOVALUE;
    object _diff_inlined_diff_at_88_45697 = NOVALUE;
    object _23795 = NOVALUE;
    object _23793 = NOVALUE;
    object _23792 = NOVALUE;
    object _23790 = NOVALUE;
    object _23789 = NOVALUE;
    object _23787 = NOVALUE;
    object _23785 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:59		object d1 = file_timestamp(output_dir & filebase(fname) & ".bld")*/
    RefDS(_fname_45672);
    _23785 = _17filebase(_fname_45672);
    {
        object concat_list[3];

        concat_list[0] = _23786;
        concat_list[1] = _23785;
        concat_list[2] = _58output_dir_42907;
        Concat_N((object_ptr)&_23787, concat_list, 3);
    }
    DeRef(_23785);
    _23785 = NOVALUE;
    _0 = _d1_45673;
    _d1_45673 = _17file_timestamp(_23787);
    DeRef(_0);
    _23787 = NOVALUE;

    /** buildsys.e:61		if atom(d1) then*/
    _23789 = IS_ATOM(_d1_45673);
    if (_23789 == 0)
    {
        _23789 = NOVALUE;
        goto L1; // [26] 36
    }
    else{
        _23789 = NOVALUE;
    }

    /** buildsys.e:62			return 1*/
    DeRefDS(_fname_45672);
    DeRef(_d1_45673);
    DeRef(_all_files_45683);
    return 1;
L1: 

    /** buildsys.e:65		sequence all_files = append(find_all_includes(fname), fname)*/
    RefDS(_fname_45672);
    RefDS(_22190);
    _23790 = _56find_all_includes(_fname_45672, _22190);
    RefDS(_fname_45672);
    Append(&_all_files_45683, _23790, _fname_45672);
    DeRef(_23790);
    _23790 = NOVALUE;

    /** buildsys.e:66		for i = 1 to length(all_files) do*/
    if (IS_SEQUENCE(_all_files_45683)){
            _23792 = SEQ_PTR(_all_files_45683)->length;
    }
    else {
        _23792 = 1;
    }
    {
        object _i_45687;
        _i_45687 = 1;
L2: 
        if (_i_45687 > _23792){
            goto L3; // [52] 123
        }

        /** buildsys.e:67			object d2 = file_timestamp(all_files[i])*/
        _2 = (object)SEQ_PTR(_all_files_45683);
        _23793 = (object)*(((s1_ptr)_2)->base + _i_45687);
        Ref(_23793);
        _0 = _d2_45689;
        _d2_45689 = _17file_timestamp(_23793);
        DeRef(_0);
        _23793 = NOVALUE;

        /** buildsys.e:68			if atom(d2) then*/
        _23795 = IS_ATOM(_d2_45689);
        if (_23795 == 0)
        {
            _23795 = NOVALUE;
            goto L4; // [74] 84
        }
        else{
            _23795 = NOVALUE;
        }

        /** buildsys.e:69				return 1*/
        DeRef(_d2_45689);
        DeRefDS(_fname_45672);
        DeRef(_d1_45673);
        DeRefDS(_all_files_45683);
        return 1;
L4: 

        /** buildsys.e:71			if datetime:diff(d1, d2) > 0 then*/

        /** datetime.e:1253		return datetimeToSeconds(dt2) - datetimeToSeconds(dt1)*/
        Ref(_d2_45689);
        _0 = _diff_1__tmp_at88_45698;
        _diff_1__tmp_at88_45698 = _18datetimeToSeconds(_d2_45689);
        DeRef(_0);
        Ref(_d1_45673);
        _0 = _diff_2__tmp_at88_45699;
        _diff_2__tmp_at88_45699 = _18datetimeToSeconds(_d1_45673);
        DeRef(_0);
        DeRef(_diff_inlined_diff_at_88_45697);
        if (IS_ATOM_INT(_diff_1__tmp_at88_45698) && IS_ATOM_INT(_diff_2__tmp_at88_45699)) {
            _diff_inlined_diff_at_88_45697 = _diff_1__tmp_at88_45698 - _diff_2__tmp_at88_45699;
            if ((object)((uintptr_t)_diff_inlined_diff_at_88_45697 +(uintptr_t) HIGH_BITS) >= 0){
                _diff_inlined_diff_at_88_45697 = NewDouble((eudouble)_diff_inlined_diff_at_88_45697);
            }
        }
        else {
            _diff_inlined_diff_at_88_45697 = binary_op(MINUS, _diff_1__tmp_at88_45698, _diff_2__tmp_at88_45699);
        }
        DeRef(_diff_1__tmp_at88_45698);
        _diff_1__tmp_at88_45698 = NOVALUE;
        DeRef(_diff_2__tmp_at88_45699);
        _diff_2__tmp_at88_45699 = NOVALUE;
        if (binary_op_a(LESSEQ, _diff_inlined_diff_at_88_45697, 0)){
            goto L5; // [103] 114
        }

        /** buildsys.e:72				return 1*/
        DeRef(_d2_45689);
        DeRefDS(_fname_45672);
        DeRef(_d1_45673);
        DeRef(_all_files_45683);
        return 1;
L5: 
        DeRef(_d2_45689);
        _d2_45689 = NOVALUE;

        /** buildsys.e:74		end for*/
        _i_45687 = _i_45687 + 1;
        goto L2; // [118] 59
L3: 
        ;
    }

    /** buildsys.e:76		return 0*/
    DeRefDS(_fname_45672);
    DeRef(_d1_45673);
    DeRef(_all_files_45683);
    return 0;
    ;
}


void _56update_checksum(object _raw_data_45745)
{
    object _23803 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:213		cfile_check = xor_bits(cfile_check, hash( raw_data, stdhash:HSIEH32))*/
    _23803 = calc_hash(_raw_data_45745, -5);
    _0 = _56cfile_check_45726;
    if (IS_ATOM_INT(_56cfile_check_45726) && IS_ATOM_INT(_23803)) {
        {uintptr_t tu;
             tu = (uintptr_t)_56cfile_check_45726 ^ (uintptr_t)_23803;
             _56cfile_check_45726 = MAKE_UINT(tu);
        }
    }
    else {
        if (IS_ATOM_INT(_56cfile_check_45726)) {
            temp_d.dbl = (eudouble)_56cfile_check_45726;
            _56cfile_check_45726 = Dxor_bits(&temp_d, DBL_PTR(_23803));
        }
        else {
            if (IS_ATOM_INT(_23803)) {
                temp_d.dbl = (eudouble)_23803;
                _56cfile_check_45726 = Dxor_bits(DBL_PTR(_56cfile_check_45726), &temp_d);
            }
            else
            _56cfile_check_45726 = Dxor_bits(DBL_PTR(_56cfile_check_45726), DBL_PTR(_23803));
        }
    }
    DeRef(_0);
    DeRef(_23803);
    _23803 = NOVALUE;

    /** buildsys.e:214	end procedure*/
    DeRef(_raw_data_45745);
    return;
    ;
}


void _56write_checksum(object _file_45750)
{
    object _0, _1, _2;
    

    /** buildsys.e:219		printf( file, "\n// 0x%08x\n", cfile_check )*/
    EPrintf(_file_45750, _23805, _56cfile_check_45726);

    /** buildsys.e:220		cfile_check = 0*/
    DeRef(_56cfile_check_45726);
    _56cfile_check_45726 = 0;

    /** buildsys.e:221	end procedure*/
    return;
    ;
}


object _56find_file_element(object _needle_45754, object _files_45755)
{
    object _23821 = NOVALUE;
    object _23820 = NOVALUE;
    object _23819 = NOVALUE;
    object _23818 = NOVALUE;
    object _23817 = NOVALUE;
    object _23816 = NOVALUE;
    object _23815 = NOVALUE;
    object _23814 = NOVALUE;
    object _23813 = NOVALUE;
    object _23812 = NOVALUE;
    object _23811 = NOVALUE;
    object _23810 = NOVALUE;
    object _23809 = NOVALUE;
    object _23808 = NOVALUE;
    object _23807 = NOVALUE;
    object _23806 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:228		for j = 1 to length(files) do*/
    if (IS_SEQUENCE(_files_45755)){
            _23806 = SEQ_PTR(_files_45755)->length;
    }
    else {
        _23806 = 1;
    }
    {
        object _j_45757;
        _j_45757 = 1;
L1: 
        if (_j_45757 > _23806){
            goto L2; // [10] 50
        }

        /** buildsys.e:229			if equal(files[j][D_NAME],needle) then*/
        _2 = (object)SEQ_PTR(_files_45755);
        _23807 = (object)*(((s1_ptr)_2)->base + _j_45757);
        _2 = (object)SEQ_PTR(_23807);
        _23808 = (object)*(((s1_ptr)_2)->base + 1);
        _23807 = NOVALUE;
        if (_23808 == _needle_45754)
        _23809 = 1;
        else if (IS_ATOM_INT(_23808) && IS_ATOM_INT(_needle_45754))
        _23809 = 0;
        else
        _23809 = (compare(_23808, _needle_45754) == 0);
        _23808 = NOVALUE;
        if (_23809 == 0)
        {
            _23809 = NOVALUE;
            goto L3; // [33] 43
        }
        else{
            _23809 = NOVALUE;
        }

        /** buildsys.e:230				return j*/
        DeRefDS(_needle_45754);
        DeRefDS(_files_45755);
        return _j_45757;
L3: 

        /** buildsys.e:232		end for*/
        _j_45757 = _j_45757 + 1;
        goto L1; // [45] 17
L2: 
        ;
    }

    /** buildsys.e:233		for j = 1 to length(files) do*/
    if (IS_SEQUENCE(_files_45755)){
            _23810 = SEQ_PTR(_files_45755)->length;
    }
    else {
        _23810 = 1;
    }
    {
        object _j_45765;
        _j_45765 = 1;
L4: 
        if (_j_45765 > _23810){
            goto L5; // [55] 103
        }

        /** buildsys.e:234			if equal(lower(files[j][D_NAME]),lower(needle)) then*/
        _2 = (object)SEQ_PTR(_files_45755);
        _23811 = (object)*(((s1_ptr)_2)->base + _j_45765);
        _2 = (object)SEQ_PTR(_23811);
        _23812 = (object)*(((s1_ptr)_2)->base + 1);
        _23811 = NOVALUE;
        Ref(_23812);
        _23813 = _14lower(_23812);
        _23812 = NOVALUE;
        RefDS(_needle_45754);
        _23814 = _14lower(_needle_45754);
        if (_23813 == _23814)
        _23815 = 1;
        else if (IS_ATOM_INT(_23813) && IS_ATOM_INT(_23814))
        _23815 = 0;
        else
        _23815 = (compare(_23813, _23814) == 0);
        DeRef(_23813);
        _23813 = NOVALUE;
        DeRef(_23814);
        _23814 = NOVALUE;
        if (_23815 == 0)
        {
            _23815 = NOVALUE;
            goto L6; // [86] 96
        }
        else{
            _23815 = NOVALUE;
        }

        /** buildsys.e:235				return j*/
        DeRefDS(_needle_45754);
        DeRefDS(_files_45755);
        return _j_45765;
L6: 

        /** buildsys.e:237		end for*/
        _j_45765 = _j_45765 + 1;
        goto L4; // [98] 62
L5: 
        ;
    }

    /** buildsys.e:239		for j = 1 to length(files) do*/
    if (IS_SEQUENCE(_files_45755)){
            _23816 = SEQ_PTR(_files_45755)->length;
    }
    else {
        _23816 = 1;
    }
    {
        object _j_45777;
        _j_45777 = 1;
L7: 
        if (_j_45777 > _23816){
            goto L8; // [108] 156
        }

        /** buildsys.e:240			if equal(lower(files[j][D_ALTNAME]),lower(needle)) then*/
        _2 = (object)SEQ_PTR(_files_45755);
        _23817 = (object)*(((s1_ptr)_2)->base + _j_45777);
        _2 = (object)SEQ_PTR(_23817);
        _23818 = (object)*(((s1_ptr)_2)->base + 11);
        _23817 = NOVALUE;
        Ref(_23818);
        _23819 = _14lower(_23818);
        _23818 = NOVALUE;
        RefDS(_needle_45754);
        _23820 = _14lower(_needle_45754);
        if (_23819 == _23820)
        _23821 = 1;
        else if (IS_ATOM_INT(_23819) && IS_ATOM_INT(_23820))
        _23821 = 0;
        else
        _23821 = (compare(_23819, _23820) == 0);
        DeRef(_23819);
        _23819 = NOVALUE;
        DeRef(_23820);
        _23820 = NOVALUE;
        if (_23821 == 0)
        {
            _23821 = NOVALUE;
            goto L9; // [139] 149
        }
        else{
            _23821 = NOVALUE;
        }

        /** buildsys.e:241				return j*/
        DeRefDS(_needle_45754);
        DeRefDS(_files_45755);
        return _j_45777;
L9: 

        /** buildsys.e:243		end for*/
        _j_45777 = _j_45777 + 1;
        goto L7; // [151] 115
L8: 
        ;
    }

    /** buildsys.e:244		return 0*/
    DeRefDS(_needle_45754);
    DeRefDS(_files_45755);
    return 0;
    ;
}


object _56adjust_for_command_line_passing(object _long_path_45798)
{
    object _slash_45799 = NOVALUE;
    object _longs_45807 = NOVALUE;
    object _short_path_45813 = NOVALUE;
    object _files_45819 = NOVALUE;
    object _file_location_45822 = NOVALUE;
    object _23860 = NOVALUE;
    object _23859 = NOVALUE;
    object _23857 = NOVALUE;
    object _23856 = NOVALUE;
    object _23854 = NOVALUE;
    object _23853 = NOVALUE;
    object _23851 = NOVALUE;
    object _23850 = NOVALUE;
    object _23847 = NOVALUE;
    object _23846 = NOVALUE;
    object _23844 = NOVALUE;
    object _23843 = NOVALUE;
    object _23842 = NOVALUE;
    object _23841 = NOVALUE;
    object _23840 = NOVALUE;
    object _23838 = NOVALUE;
    object _23837 = NOVALUE;
    object _23835 = NOVALUE;
    object _23833 = NOVALUE;
    object _23831 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:310		if compiler_type = COMPILER_GCC then*/
    if (_56compiler_type_45709 != 1)
    goto L1; // [7] 19

    /** buildsys.e:311			slash = '/'*/
    _slash_45799 = 47;
    goto L2; // [16] 45
L1: 

    /** buildsys.e:312		elsif compiler_type = COMPILER_WATCOM then*/
    if (_56compiler_type_45709 != 2)
    goto L3; // [23] 35

    /** buildsys.e:313			slash = '\\'*/
    _slash_45799 = 92;
    goto L2; // [32] 45
L3: 

    /** buildsys.e:315			slash = SLASH*/
    _slash_45799 = 92;
L2: 

    /** buildsys.e:317		ifdef UNIX then*/

    /** buildsys.e:320			long_path = regex:find_replace(quote_pattern, long_path, "")*/
    Ref(_56quote_pattern_45791);
    RefDS(_long_path_45798);
    RefDS(_22190);
    _0 = _long_path_45798;
    _long_path_45798 = _52find_replace(_56quote_pattern_45791, _long_path_45798, _22190, 1, 0);
    DeRefDS(_0);

    /** buildsys.e:321			sequence longs = split( slash_pattern, long_path )*/
    Ref(_56slash_pattern_45788);
    RefDS(_long_path_45798);
    _0 = _longs_45807;
    _longs_45807 = _52split(_56slash_pattern_45788, _long_path_45798, 1, 0);
    DeRef(_0);

    /** buildsys.e:322			if length(longs)=0 then*/
    if (IS_SEQUENCE(_longs_45807)){
            _23831 = SEQ_PTR(_longs_45807)->length;
    }
    else {
        _23831 = 1;
    }
    if (_23831 != 0)
    goto L4; // [79] 90

    /** buildsys.e:323				return long_path*/
    DeRefDS(_longs_45807);
    DeRef(_short_path_45813);
    return _long_path_45798;
L4: 

    /** buildsys.e:325			sequence short_path = longs[1] & slash*/
    _2 = (object)SEQ_PTR(_longs_45807);
    _23833 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_23833) && IS_ATOM(_slash_45799)) {
        Append(&_short_path_45813, _23833, _slash_45799);
    }
    else if (IS_ATOM(_23833) && IS_SEQUENCE(_slash_45799)) {
    }
    else {
        Concat((object_ptr)&_short_path_45813, _23833, _slash_45799);
        _23833 = NOVALUE;
    }
    _23833 = NOVALUE;

    /** buildsys.e:326			for i = 2 to length(longs) do*/
    if (IS_SEQUENCE(_longs_45807)){
            _23835 = SEQ_PTR(_longs_45807)->length;
    }
    else {
        _23835 = 1;
    }
    {
        object _i_45817;
        _i_45817 = 2;
L5: 
        if (_i_45817 > _23835){
            goto L6; // [107] 266
        }

        /** buildsys.e:327				object files = dir(short_path)*/
        RefDS(_short_path_45813);
        _0 = _files_45819;
        _files_45819 = _17dir(_short_path_45813);
        DeRef(_0);

        /** buildsys.e:328				integer file_location = 0*/
        _file_location_45822 = 0;

        /** buildsys.e:329				if sequence(files) then*/
        _23837 = IS_SEQUENCE(_files_45819);
        if (_23837 == 0)
        {
            _23837 = NOVALUE;
            goto L7; // [130] 147
        }
        else{
            _23837 = NOVALUE;
        }

        /** buildsys.e:330					file_location = find_file_element(longs[i], files)*/
        _2 = (object)SEQ_PTR(_longs_45807);
        _23838 = (object)*(((s1_ptr)_2)->base + _i_45817);
        Ref(_23838);
        Ref(_files_45819);
        _file_location_45822 = _56find_file_element(_23838, _files_45819);
        _23838 = NOVALUE;
        if (!IS_ATOM_INT(_file_location_45822)) {
            _1 = (object)(DBL_PTR(_file_location_45822)->dbl);
            DeRefDS(_file_location_45822);
            _file_location_45822 = _1;
        }
L7: 

        /** buildsys.e:332				if file_location then*/
        if (_file_location_45822 == 0)
        {
            goto L8; // [149] 215
        }
        else{
        }

        /** buildsys.e:333					if sequence(files[file_location][D_ALTNAME]) then*/
        _2 = (object)SEQ_PTR(_files_45819);
        _23840 = (object)*(((s1_ptr)_2)->base + _file_location_45822);
        _2 = (object)SEQ_PTR(_23840);
        _23841 = (object)*(((s1_ptr)_2)->base + 11);
        _23840 = NOVALUE;
        _23842 = IS_SEQUENCE(_23841);
        _23841 = NOVALUE;
        if (_23842 == 0)
        {
            _23842 = NOVALUE;
            goto L9; // [167] 189
        }
        else{
            _23842 = NOVALUE;
        }

        /** buildsys.e:334						short_path &= files[file_location][D_ALTNAME]*/
        _2 = (object)SEQ_PTR(_files_45819);
        _23843 = (object)*(((s1_ptr)_2)->base + _file_location_45822);
        _2 = (object)SEQ_PTR(_23843);
        _23844 = (object)*(((s1_ptr)_2)->base + 11);
        _23843 = NOVALUE;
        if (IS_SEQUENCE(_short_path_45813) && IS_ATOM(_23844)) {
            Ref(_23844);
            Append(&_short_path_45813, _short_path_45813, _23844);
        }
        else if (IS_ATOM(_short_path_45813) && IS_SEQUENCE(_23844)) {
        }
        else {
            Concat((object_ptr)&_short_path_45813, _short_path_45813, _23844);
        }
        _23844 = NOVALUE;
        goto LA; // [186] 206
L9: 

        /** buildsys.e:336						short_path &= files[file_location][D_NAME]*/
        _2 = (object)SEQ_PTR(_files_45819);
        _23846 = (object)*(((s1_ptr)_2)->base + _file_location_45822);
        _2 = (object)SEQ_PTR(_23846);
        _23847 = (object)*(((s1_ptr)_2)->base + 1);
        _23846 = NOVALUE;
        if (IS_SEQUENCE(_short_path_45813) && IS_ATOM(_23847)) {
            Ref(_23847);
            Append(&_short_path_45813, _short_path_45813, _23847);
        }
        else if (IS_ATOM(_short_path_45813) && IS_SEQUENCE(_23847)) {
        }
        else {
            Concat((object_ptr)&_short_path_45813, _short_path_45813, _23847);
        }
        _23847 = NOVALUE;
LA: 

        /** buildsys.e:338					short_path &= slash*/
        Append(&_short_path_45813, _short_path_45813, _slash_45799);
        goto LB; // [212] 257
L8: 

        /** buildsys.e:340					if not find(' ',longs[i]) then*/
        _2 = (object)SEQ_PTR(_longs_45807);
        _23850 = (object)*(((s1_ptr)_2)->base + _i_45817);
        _23851 = find_from(32, _23850, 1);
        _23850 = NOVALUE;
        if (_23851 != 0)
        goto LC; // [226] 250
        _23851 = NOVALUE;

        /** buildsys.e:341						short_path &= longs[i] & slash*/
        _2 = (object)SEQ_PTR(_longs_45807);
        _23853 = (object)*(((s1_ptr)_2)->base + _i_45817);
        if (IS_SEQUENCE(_23853) && IS_ATOM(_slash_45799)) {
            Append(&_23854, _23853, _slash_45799);
        }
        else if (IS_ATOM(_23853) && IS_SEQUENCE(_slash_45799)) {
        }
        else {
            Concat((object_ptr)&_23854, _23853, _slash_45799);
            _23853 = NOVALUE;
        }
        _23853 = NOVALUE;
        Concat((object_ptr)&_short_path_45813, _short_path_45813, _23854);
        DeRefDS(_23854);
        _23854 = NOVALUE;

        /** buildsys.e:342						continue*/
        DeRef(_files_45819);
        _files_45819 = NOVALUE;
        goto LD; // [247] 261
LC: 

        /** buildsys.e:344					return 0*/
        DeRef(_files_45819);
        DeRefDS(_long_path_45798);
        DeRef(_longs_45807);
        DeRef(_short_path_45813);
        return 0;
LB: 
        DeRef(_files_45819);
        _files_45819 = NOVALUE;

        /** buildsys.e:346			end for -- i*/
LD: 
        _i_45817 = _i_45817 + 1;
        goto L5; // [261] 114
L6: 
        ;
    }

    /** buildsys.e:347			if short_path[$] = slash then*/
    if (IS_SEQUENCE(_short_path_45813)){
            _23856 = SEQ_PTR(_short_path_45813)->length;
    }
    else {
        _23856 = 1;
    }
    _2 = (object)SEQ_PTR(_short_path_45813);
    _23857 = (object)*(((s1_ptr)_2)->base + _23856);
    if (binary_op_a(NOTEQ, _23857, _slash_45799)){
        _23857 = NOVALUE;
        goto LE; // [275] 294
    }
    _23857 = NOVALUE;

    /** buildsys.e:348				short_path = short_path[1..$-1]*/
    if (IS_SEQUENCE(_short_path_45813)){
            _23859 = SEQ_PTR(_short_path_45813)->length;
    }
    else {
        _23859 = 1;
    }
    _23860 = _23859 - 1;
    _23859 = NOVALUE;
    rhs_slice_target = (object_ptr)&_short_path_45813;
    RHS_Slice(_short_path_45813, 1, _23860);
LE: 

    /** buildsys.e:350			return short_path*/
    DeRefDS(_long_path_45798);
    DeRef(_longs_45807);
    DeRef(_23860);
    _23860 = NOVALUE;
    return _short_path_45813;
    ;
}


object _56adjust_for_build_file(object _long_path_45860)
{
    object _short_path_45861 = NOVALUE;
    object _23868 = NOVALUE;
    object _23867 = NOVALUE;
    object _23866 = NOVALUE;
    object _23865 = NOVALUE;
    object _23864 = NOVALUE;
    object _23863 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:355	    object short_path = adjust_for_command_line_passing(long_path)*/
    RefDS(_long_path_45860);
    _0 = _short_path_45861;
    _short_path_45861 = _56adjust_for_command_line_passing(_long_path_45860);
    DeRef(_0);

    /** buildsys.e:356	    if atom(short_path) then*/
    _23863 = IS_ATOM(_short_path_45861);
    if (_23863 == 0)
    {
        _23863 = NOVALUE;
        goto L1; // [14] 24
    }
    else{
        _23863 = NOVALUE;
    }

    /** buildsys.e:357	    	return short_path*/
    DeRefDS(_long_path_45860);
    return _short_path_45861;
L1: 

    /** buildsys.e:359		if compiler_type = COMPILER_GCC and build_system_type != BUILD_DIRECT and TWINDOWS then*/
    _23864 = (_56compiler_type_45709 == 1);
    if (_23864 == 0) {
        _23865 = 0;
        goto L2; // [32] 46
    }
    _23866 = (_56build_system_type_45705 != 3);
    _23865 = (_23866 != 0);
L2: 
    if (_23865 == 0) {
        goto L3; // [46] 69
    }
    if (_46TWINDOWS_21914 == 0)
    {
        goto L3; // [53] 69
    }
    else{
    }

    /** buildsys.e:360			return windows_to_mingw_path(short_path)*/
    Ref(_short_path_45861);
    _23868 = _56windows_to_mingw_path(_short_path_45861);
    DeRefDS(_long_path_45860);
    DeRef(_short_path_45861);
    DeRef(_23864);
    _23864 = NOVALUE;
    DeRef(_23866);
    _23866 = NOVALUE;
    return _23868;
    goto L4; // [66] 76
L3: 

    /** buildsys.e:362			return short_path*/
    DeRefDS(_long_path_45860);
    DeRef(_23864);
    _23864 = NOVALUE;
    DeRef(_23866);
    _23866 = NOVALUE;
    DeRef(_23868);
    _23868 = NOVALUE;
    return _short_path_45861;
L4: 
    ;
}


object _56setup_build()
{
    object _c_exe_45876 = NOVALUE;
    object _c_flags_45877 = NOVALUE;
    object _l_exe_45878 = NOVALUE;
    object _l_flags_45879 = NOVALUE;
    object _obj_ext_45880 = NOVALUE;
    object _exe_ext_45881 = NOVALUE;
    object _l_flags_begin_45882 = NOVALUE;
    object _rc_comp_45883 = NOVALUE;
    object _l_names_45884 = NOVALUE;
    object _l_ext_45885 = NOVALUE;
    object _t_slash_45886 = NOVALUE;
    object _eudir_45928 = NOVALUE;
    object _compile_dir_45986 = NOVALUE;
    object _bits_45997 = NOVALUE;
    object _m_flag_46007 = NOVALUE;
    object _24025 = NOVALUE;
    object _24023 = NOVALUE;
    object _24022 = NOVALUE;
    object _24021 = NOVALUE;
    object _24019 = NOVALUE;
    object _24018 = NOVALUE;
    object _24017 = NOVALUE;
    object _24014 = NOVALUE;
    object _24013 = NOVALUE;
    object _24010 = NOVALUE;
    object _24009 = NOVALUE;
    object _24002 = NOVALUE;
    object _24001 = NOVALUE;
    object _23996 = NOVALUE;
    object _23995 = NOVALUE;
    object _23990 = NOVALUE;
    object _23989 = NOVALUE;
    object _23986 = NOVALUE;
    object _23985 = NOVALUE;
    object _23973 = NOVALUE;
    object _23972 = NOVALUE;
    object _23957 = NOVALUE;
    object _23956 = NOVALUE;
    object _23953 = NOVALUE;
    object _23948 = NOVALUE;
    object _23946 = NOVALUE;
    object _23945 = NOVALUE;
    object _23944 = NOVALUE;
    object _23943 = NOVALUE;
    object _23939 = NOVALUE;
    object _23938 = NOVALUE;
    object _23924 = NOVALUE;
    object _23923 = NOVALUE;
    object _23920 = NOVALUE;
    object _23908 = NOVALUE;
    object _23904 = NOVALUE;
    object _23901 = NOVALUE;
    object _23900 = NOVALUE;
    object _23899 = NOVALUE;
    object _23896 = NOVALUE;
    object _23895 = NOVALUE;
    object _23894 = NOVALUE;
    object _23891 = NOVALUE;
    object _23887 = NOVALUE;
    object _23886 = NOVALUE;
    object _23884 = NOVALUE;
    object _23883 = NOVALUE;
    object _23882 = NOVALUE;
    object _23881 = NOVALUE;
    object _23874 = NOVALUE;
    object _23873 = NOVALUE;
    object _23872 = NOVALUE;
    object _23871 = NOVALUE;
    object _23870 = NOVALUE;
    object _23869 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:373			c_exe   = "",*/
    RefDS(_22190);
    DeRef(_c_exe_45876);
    _c_exe_45876 = _22190;

    /** buildsys.e:374			c_flags = "",*/
    RefDS(_22190);
    DeRef(_c_flags_45877);
    _c_flags_45877 = _22190;

    /** buildsys.e:375			l_exe   = "",*/
    RefDS(_22190);
    DeRef(_l_exe_45878);
    _l_exe_45878 = _22190;

    /** buildsys.e:376			l_flags = "",*/
    RefDS(_22190);
    DeRef(_l_flags_45879);
    _l_flags_45879 = _22190;

    /** buildsys.e:377			obj_ext = "",*/
    RefDS(_22190);
    DeRefi(_obj_ext_45880);
    _obj_ext_45880 = _22190;

    /** buildsys.e:378			exe_ext = "",*/
    RefDS(_22190);
    DeRefi(_exe_ext_45881);
    _exe_ext_45881 = _22190;

    /** buildsys.e:379			l_flags_begin = "",*/
    RefDS(_22190);
    DeRefi(_l_flags_begin_45882);
    _l_flags_begin_45882 = _22190;

    /** buildsys.e:380			rc_comp = "",*/
    RefDS(_22190);
    DeRef(_rc_comp_45883);
    _rc_comp_45883 = _22190;

    /** buildsys.e:385		if dll_option*/
    if (_58dll_option_42893 == 0) {
        _23869 = 0;
        goto L1; // [61] 78
    }
    if (IS_SEQUENCE(_58user_pic_library_42906)){
            _23870 = SEQ_PTR(_58user_pic_library_42906)->length;
    }
    else {
        _23870 = 1;
    }
    _23871 = (_23870 > 0);
    _23870 = NOVALUE;
    _23869 = (_23871 != 0);
L1: 
    if (_23869 == 0) {
        goto L2; // [78] 101
    }
    _23873 = (_46TWINDOWS_21914 == 0);
    if (_23873 == 0)
    {
        DeRef(_23873);
        _23873 = NOVALUE;
        goto L2; // [88] 101
    }
    else{
        DeRef(_23873);
        _23873 = NOVALUE;
    }

    /** buildsys.e:388			user_library = user_pic_library*/
    RefDS(_58user_pic_library_42906);
    DeRef(_58user_library_42905);
    _58user_library_42905 = _58user_pic_library_42906;
L2: 

    /** buildsys.e:391		if length(user_library) = 0 then*/
    if (IS_SEQUENCE(_58user_library_42905)){
            _23874 = SEQ_PTR(_58user_library_42905)->length;
    }
    else {
        _23874 = 1;
    }
    if (_23874 != 0)
    goto L3; // [108] 366

    /** buildsys.e:392			if debug_option then*/
    if (_58debug_option_42903 == 0)
    {
        goto L4; // [116] 128
    }
    else{
    }

    /** buildsys.e:393				l_names = { "eudbg", "eu" }*/
    RefDS(_23877);
    RefDS(_23876);
    DeRef(_l_names_45884);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _23876;
    ((intptr_t *)_2)[2] = _23877;
    _l_names_45884 = MAKE_SEQ(_1);
    goto L5; // [125] 135
L4: 

    /** buildsys.e:395				l_names = { "eu", "eudbg" }*/
    RefDS(_23876);
    RefDS(_23877);
    DeRef(_l_names_45884);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _23877;
    ((intptr_t *)_2)[2] = _23876;
    _l_names_45884 = MAKE_SEQ(_1);
L5: 

    /** buildsys.e:400			if TUNIX or compiler_type = COMPILER_GCC then*/
    if (_46TUNIX_21918 != 0) {
        goto L6; // [139] 154
    }
    _23881 = (_56compiler_type_45709 == 1);
    if (_23881 == 0)
    {
        DeRef(_23881);
        _23881 = NOVALUE;
        goto L7; // [150] 224
    }
    else{
        DeRef(_23881);
        _23881 = NOVALUE;
    }
L6: 

    /** buildsys.e:401				l_ext = "a"*/
    RefDS(_22471);
    DeRefi(_l_ext_45885);
    _l_ext_45885 = _22471;

    /** buildsys.e:402				t_slash = "/"*/
    RefDS(_23766);
    DeRefi(_t_slash_45886);
    _t_slash_45886 = _23766;

    /** buildsys.e:403				if dll_option and not TWINDOWS then*/
    if (_58dll_option_42893 == 0) {
        goto L8; // [172] 247
    }
    _23883 = (_46TWINDOWS_21914 == 0);
    if (_23883 == 0)
    {
        DeRef(_23883);
        _23883 = NOVALUE;
        goto L8; // [182] 247
    }
    else{
        DeRef(_23883);
        _23883 = NOVALUE;
    }

    /** buildsys.e:404					for i = 1 to length( l_names ) do*/
    if (IS_SEQUENCE(_l_names_45884)){
            _23884 = SEQ_PTR(_l_names_45884)->length;
    }
    else {
        _23884 = 1;
    }
    {
        object _i_45919;
        _i_45919 = 1;
L9: 
        if (_i_45919 > _23884){
            goto LA; // [192] 220
        }

        /** buildsys.e:406						l_names[i] &= "so"*/
        _2 = (object)SEQ_PTR(_l_names_45884);
        _23886 = (object)*(((s1_ptr)_2)->base + _i_45919);
        if (IS_SEQUENCE(_23886) && IS_ATOM(_23885)) {
        }
        else if (IS_ATOM(_23886) && IS_SEQUENCE(_23885)) {
            Ref(_23886);
            Prepend(&_23887, _23885, _23886);
        }
        else {
            Concat((object_ptr)&_23887, _23886, _23885);
            _23886 = NOVALUE;
        }
        _23886 = NOVALUE;
        _2 = (object)SEQ_PTR(_l_names_45884);
        _2 = (object)(((s1_ptr)_2)->base + _i_45919);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _23887;
        if( _1 != _23887 ){
            DeRef(_1);
        }
        _23887 = NOVALUE;

        /** buildsys.e:407					end for*/
        _i_45919 = _i_45919 + 1;
        goto L9; // [215] 199
LA: 
        ;
    }
    goto L8; // [221] 247
L7: 

    /** buildsys.e:409			elsif TWINDOWS then*/
    if (_46TWINDOWS_21914 == 0)
    {
        goto LB; // [228] 246
    }
    else{
    }

    /** buildsys.e:410				l_ext = "lib"*/
    RefDS(_23888);
    DeRefi(_l_ext_45885);
    _l_ext_45885 = _23888;

    /** buildsys.e:411				t_slash = "\\"*/
    RefDS(_23889);
    DeRefi(_t_slash_45886);
    _t_slash_45886 = _23889;
LB: 
L8: 

    /** buildsys.e:414			object eudir = get_eucompiledir()*/
    _0 = _eudir_45928;
    _eudir_45928 = _58get_eucompiledir();
    DeRef(_0);

    /** buildsys.e:415			if not file_exists(eudir) then*/
    Ref(_eudir_45928);
    _23891 = _17file_exists(_eudir_45928);
    if (IS_ATOM_INT(_23891)) {
        if (_23891 != 0){
            DeRef(_23891);
            _23891 = NOVALUE;
            goto LC; // [258] 279
        }
    }
    else {
        if (DBL_PTR(_23891)->dbl != 0.0){
            DeRef(_23891);
            _23891 = NOVALUE;
            goto LC; // [258] 279
        }
    }
    DeRef(_23891);
    _23891 = NOVALUE;

    /** buildsys.e:416				printf(2,"Supplied directory \'%s\' is not a valid EUDIR\n",{get_eucompiledir()})*/
    _23894 = _58get_eucompiledir();
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _23894;
    _23895 = MAKE_SEQ(_1);
    _23894 = NOVALUE;
    EPrintf(2, _23893, _23895);
    DeRefDS(_23895);
    _23895 = NOVALUE;

    /** buildsys.e:417				abort(1)*/
    UserCleanup(1);
LC: 

    /** buildsys.e:419			for tk = 1 to length(l_names) label "translation kind" do*/
    if (IS_SEQUENCE(_l_names_45884)){
            _23896 = SEQ_PTR(_l_names_45884)->length;
    }
    else {
        _23896 = 1;
    }
    {
        object _tk_45940;
        _tk_45940 = 1;
LD: 
        if (_tk_45940 > _23896){
            goto LE; // [286] 365
        }

        /** buildsys.e:420				user_library = eudir & sprintf("%sbin%s%s.%s",{t_slash, t_slash, l_names[tk],l_ext})*/
        _2 = (object)SEQ_PTR(_l_names_45884);
        _23899 = (object)*(((s1_ptr)_2)->base + _tk_45940);
        _1 = NewS1(4);
        _2 = (object)((s1_ptr)_1)->base;
        RefDSn(_t_slash_45886, 2);
        ((intptr_t*)_2)[1] = _t_slash_45886;
        ((intptr_t*)_2)[2] = _t_slash_45886;
        Ref(_23899);
        ((intptr_t*)_2)[3] = _23899;
        RefDS(_l_ext_45885);
        ((intptr_t*)_2)[4] = _l_ext_45885;
        _23900 = MAKE_SEQ(_1);
        _23899 = NOVALUE;
        _23901 = EPrintf(-9999999, _23898, _23900);
        DeRefDS(_23900);
        _23900 = NOVALUE;
        if (IS_SEQUENCE(_eudir_45928) && IS_ATOM(_23901)) {
        }
        else if (IS_ATOM(_eudir_45928) && IS_SEQUENCE(_23901)) {
            Ref(_eudir_45928);
            Prepend(&_58user_library_42905, _23901, _eudir_45928);
        }
        else {
            Concat((object_ptr)&_58user_library_42905, _eudir_45928, _23901);
        }
        DeRefDS(_23901);
        _23901 = NOVALUE;

        /** buildsys.e:421				if TUNIX or compiler_type = COMPILER_GCC then*/
        if (_46TUNIX_21918 != 0) {
            goto LF; // [324] 339
        }
        _23904 = (_56compiler_type_45709 == 1);
        if (_23904 == 0)
        {
            DeRef(_23904);
            _23904 = NOVALUE;
            goto L10; // [335] 342
        }
        else{
            DeRef(_23904);
            _23904 = NOVALUE;
        }
LF: 

        /** buildsys.e:422					ifdef UNIX then*/
L10: 

        /** buildsys.e:436				if file_exists(user_library) then*/
        RefDS(_58user_library_42905);
        _23908 = _17file_exists(_58user_library_42905);
        if (_23908 == 0) {
            DeRef(_23908);
            _23908 = NOVALUE;
            goto L11; // [350] 358
        }
        else {
            if (!IS_ATOM_INT(_23908) && DBL_PTR(_23908)->dbl == 0.0){
                DeRef(_23908);
                _23908 = NOVALUE;
                goto L11; // [350] 358
            }
            DeRef(_23908);
            _23908 = NOVALUE;
        }
        DeRef(_23908);
        _23908 = NOVALUE;

        /** buildsys.e:437					exit "translation kind"*/
        goto LE; // [355] 365
L11: 

        /** buildsys.e:439			end for -- tk*/
        _tk_45940 = _tk_45940 + 1;
        goto LD; // [360] 293
LE: 
        ;
    }
L3: 
    DeRef(_eudir_45928);
    _eudir_45928 = NOVALUE;

    /** buildsys.e:441		user_library = adjust_for_build_file(user_library)*/
    RefDS(_58user_library_42905);
    _0 = _56adjust_for_build_file(_58user_library_42905);
    DeRefDS(_58user_library_42905);
    _58user_library_42905 = _0;

    /** buildsys.e:443		if TWINDOWS then*/
    if (_46TWINDOWS_21914 == 0)
    {
        goto L12; // [382] 437
    }
    else{
    }

    /** buildsys.e:444			if compiler_type = COMPILER_WATCOM then*/
    if (_56compiler_type_45709 != 2)
    goto L13; // [389] 402

    /** buildsys.e:445				c_flags &= " /dEWINDOWS"*/
    Concat((object_ptr)&_c_flags_45877, _c_flags_45877, _23911);
    goto L14; // [399] 409
L13: 

    /** buildsys.e:447				c_flags &= " -DEWINDOWS"*/
    Concat((object_ptr)&_c_flags_45877, _c_flags_45877, _23913);
L14: 

    /** buildsys.e:450			if dll_option then*/
    if (_58dll_option_42893 == 0)
    {
        goto L15; // [413] 426
    }
    else{
    }

    /** buildsys.e:451				exe_ext = ".dll"*/
    RefDS(_23915);
    DeRefi(_exe_ext_45881);
    _exe_ext_45881 = _23915;
    goto L16; // [423] 478
L15: 

    /** buildsys.e:453				exe_ext = ".exe"*/
    RefDS(_23916);
    DeRefi(_exe_ext_45881);
    _exe_ext_45881 = _23916;
    goto L16; // [434] 478
L12: 

    /** buildsys.e:455		elsif TOSX then*/
    if (_46TOSX_21922 == 0)
    {
        goto L17; // [441] 462
    }
    else{
    }

    /** buildsys.e:456			if dll_option then*/
    if (_58dll_option_42893 == 0)
    {
        goto L16; // [448] 478
    }
    else{
    }

    /** buildsys.e:457				exe_ext = ".dylib"*/
    RefDS(_23917);
    DeRefi(_exe_ext_45881);
    _exe_ext_45881 = _23917;
    goto L16; // [459] 478
L17: 

    /** buildsys.e:460			if dll_option then*/
    if (_58dll_option_42893 == 0)
    {
        goto L18; // [466] 477
    }
    else{
    }

    /** buildsys.e:461				exe_ext = ".so"*/
    RefDS(_23918);
    DeRefi(_exe_ext_45881);
    _exe_ext_45881 = _23918;
L18: 
L16: 

    /** buildsys.e:465		object compile_dir = get_eucompiledir()*/
    _0 = _compile_dir_45986;
    _compile_dir_45986 = _58get_eucompiledir();
    DeRef(_0);

    /** buildsys.e:466		if not file_exists(compile_dir) then*/
    Ref(_compile_dir_45986);
    _23920 = _17file_exists(_compile_dir_45986);
    if (IS_ATOM_INT(_23920)) {
        if (_23920 != 0){
            DeRef(_23920);
            _23920 = NOVALUE;
            goto L19; // [489] 510
        }
    }
    else {
        if (DBL_PTR(_23920)->dbl != 0.0){
            DeRef(_23920);
            _23920 = NOVALUE;
            goto L19; // [489] 510
        }
    }
    DeRef(_23920);
    _23920 = NOVALUE;

    /** buildsys.e:467			printf(2,"Couldn't get include directory '%s'",{get_eucompiledir()})*/
    _23923 = _58get_eucompiledir();
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _23923;
    _23924 = MAKE_SEQ(_1);
    _23923 = NOVALUE;
    EPrintf(2, _23922, _23924);
    DeRefDS(_23924);
    _23924 = NOVALUE;

    /** buildsys.e:468			abort(1)*/
    UserCleanup(1);
L19: 

    /** buildsys.e:471		integer bits = 32*/
    _bits_45997 = 32;

    /** buildsys.e:472		if TX86_64 then*/
    if (_46TX86_64_21930 == 0)
    {
        goto L1A; // [519] 528
    }
    else{
    }

    /** buildsys.e:473			bits = 64*/
    _bits_45997 = 64;
L1A: 

    /** buildsys.e:476		switch compiler_type do*/
    _0 = _56compiler_type_45709;
    switch ( _0 ){ 

        /** buildsys.e:477			case COMPILER_GCC then*/
        case 1:

        /** buildsys.e:478				c_exe = compiler_prefix & "gcc"*/
        Concat((object_ptr)&_c_exe_45876, _56compiler_prefix_45710, _23927);

        /** buildsys.e:479				l_exe = compiler_prefix & "gcc"*/
        Concat((object_ptr)&_l_exe_45878, _56compiler_prefix_45710, _23927);

        /** buildsys.e:480				obj_ext = "o"*/
        RefDS(_23930);
        DeRefi(_obj_ext_45880);
        _obj_ext_45880 = _23930;

        /** buildsys.e:482				sequence m_flag = ""*/
        RefDS(_22190);
        DeRefi(_m_flag_46007);
        _m_flag_46007 = _22190;

        /** buildsys.e:483				if not TARM then*/
        if (_46TARM_21932 != 0)
        goto L1B; // [575] 585

        /** buildsys.e:485					m_flag = sprintf( "-m%d", bits )*/
        DeRefDSi(_m_flag_46007);
        _m_flag_46007 = EPrintf(-9999999, _23932, _bits_45997);
L1B: 

        /** buildsys.e:488				if debug_option then*/
        if (_58debug_option_42903 == 0)
        {
            goto L1C; // [589] 601
        }
        else{
        }

        /** buildsys.e:489					c_flags &= " -g3"*/
        Concat((object_ptr)&_c_flags_45877, _c_flags_45877, _23934);
        goto L1D; // [598] 608
L1C: 

        /** buildsys.e:491					c_flags &= " -fomit-frame-pointer"*/
        Concat((object_ptr)&_c_flags_45877, _c_flags_45877, _23936);
L1D: 

        /** buildsys.e:494				if dll_option and not TWINDOWS then*/
        if (_58dll_option_42893 == 0) {
            goto L1E; // [612] 632
        }
        _23939 = (_46TWINDOWS_21914 == 0);
        if (_23939 == 0)
        {
            DeRef(_23939);
            _23939 = NOVALUE;
            goto L1E; // [622] 632
        }
        else{
            DeRef(_23939);
            _23939 = NOVALUE;
        }

        /** buildsys.e:495					c_flags &= " -fPIC"*/
        Concat((object_ptr)&_c_flags_45877, _c_flags_45877, _23940);
L1E: 

        /** buildsys.e:498				c_flags &= sprintf(" -c -w -fsigned-char -O2 %s -I%s -ffast-math",*/
        _23943 = _58get_eucompiledir();
        _23944 = _56adjust_for_build_file(_23943);
        _23943 = NOVALUE;
        RefDS(_m_flag_46007);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _m_flag_46007;
        ((intptr_t *)_2)[2] = _23944;
        _23945 = MAKE_SEQ(_1);
        _23944 = NOVALUE;
        _23946 = EPrintf(-9999999, _23942, _23945);
        DeRefDS(_23945);
        _23945 = NOVALUE;
        Concat((object_ptr)&_c_flags_45877, _c_flags_45877, _23946);
        DeRefDS(_23946);
        _23946 = NOVALUE;

        /** buildsys.e:501				if TWINDOWS and mno_cygwin then*/
        if (_46TWINDOWS_21914 == 0) {
            goto L1F; // [657] 674
        }
        if (_56mno_cygwin_45733 == 0)
        {
            goto L1F; // [664] 674
        }
        else{
        }

        /** buildsys.e:504					c_flags &= " -mno-cygwin"*/
        Concat((object_ptr)&_c_flags_45877, _c_flags_45877, _23949);
L1F: 

        /** buildsys.e:507				if build_system_type != BUILD_DIRECT then*/
        if (_56build_system_type_45705 == 3)
        goto L20; // [678] 695

        /** buildsys.e:508					l_flags = sprintf( " $(RUNTIME_LIBRARY) %s", { m_flag })*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_m_flag_46007);
        ((intptr_t*)_2)[1] = _m_flag_46007;
        _23953 = MAKE_SEQ(_1);
        DeRef(_l_flags_45879);
        _l_flags_45879 = EPrintf(-9999999, _23952, _23953);
        DeRefDS(_23953);
        _23953 = NOVALUE;
        goto L21; // [692] 712
L20: 

        /** buildsys.e:510					l_flags = sprintf( " %s %s",*/
        RefDS(_58user_library_42905);
        _23956 = _56adjust_for_command_line_passing(_58user_library_42905);
        RefDS(_m_flag_46007);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _23956;
        ((intptr_t *)_2)[2] = _m_flag_46007;
        _23957 = MAKE_SEQ(_1);
        _23956 = NOVALUE;
        DeRef(_l_flags_45879);
        _l_flags_45879 = EPrintf(-9999999, _23955, _23957);
        DeRefDS(_23957);
        _23957 = NOVALUE;
L21: 

        /** buildsys.e:514				if dll_option then*/
        if (_58dll_option_42893 == 0)
        {
            goto L22; // [716] 726
        }
        else{
        }

        /** buildsys.e:515					l_flags &= " -shared "*/
        Concat((object_ptr)&_l_flags_45879, _l_flags_45879, _23959);
L22: 

        /** buildsys.e:518				if TLINUX then*/
        if (_46TLINUX_21916 == 0)
        {
            goto L23; // [730] 742
        }
        else{
        }

        /** buildsys.e:519					l_flags &= " -ldl -lm -lpthread"*/
        Concat((object_ptr)&_l_flags_45879, _l_flags_45879, _23961);
        goto L24; // [739] 811
L23: 

        /** buildsys.e:520				elsif TBSD then*/
        if (_46TBSD_21920 == 0)
        {
            goto L25; // [746] 758
        }
        else{
        }

        /** buildsys.e:521					l_flags &= " -lm -lpthread"*/
        Concat((object_ptr)&_l_flags_45879, _l_flags_45879, _23963);
        goto L24; // [755] 811
L25: 

        /** buildsys.e:522				elsif TOSX then*/
        if (_46TOSX_21922 == 0)
        {
            goto L26; // [762] 774
        }
        else{
        }

        /** buildsys.e:523					l_flags &= " -lresolv"*/
        Concat((object_ptr)&_l_flags_45879, _l_flags_45879, _23965);
        goto L24; // [771] 811
L26: 

        /** buildsys.e:524				elsif TWINDOWS then*/
        if (_46TWINDOWS_21914 == 0)
        {
            goto L27; // [778] 810
        }
        else{
        }

        /** buildsys.e:525					if mno_cygwin then*/
        if (_56mno_cygwin_45733 == 0)
        {
            goto L28; // [785] 795
        }
        else{
        }

        /** buildsys.e:527						l_flags &= " -mno-cygwin"*/
        Concat((object_ptr)&_l_flags_45879, _l_flags_45879, _23949);
L28: 

        /** buildsys.e:529					if not con_option then*/
        if (_58con_option_42895 != 0)
        goto L29; // [799] 809

        /** buildsys.e:532						l_flags &= " -mwindows"*/
        Concat((object_ptr)&_l_flags_45879, _l_flags_45879, _23969);
L29: 
L27: 
L24: 

        /** buildsys.e:537				rc_comp = compiler_prefix & "windres -DSRCDIR=\"" & adjust_for_build_file(current_dir()) & "\" [1] -O coff -o [2]"*/
        _23972 = _17current_dir();
        _23973 = _56adjust_for_build_file(_23972);
        _23972 = NOVALUE;
        {
            object concat_list[4];

            concat_list[0] = _23974;
            concat_list[1] = _23973;
            concat_list[2] = _23971;
            concat_list[3] = _56compiler_prefix_45710;
            Concat_N((object_ptr)&_rc_comp_45883, concat_list, 4);
        }
        DeRef(_23973);
        _23973 = NOVALUE;
        DeRefi(_m_flag_46007);
        _m_flag_46007 = NOVALUE;
        goto L2A; // [831] 1037

        /** buildsys.e:539			case COMPILER_WATCOM then*/
        case 2:

        /** buildsys.e:540				c_exe = compiler_prefix & "wcc386"*/
        Concat((object_ptr)&_c_exe_45876, _56compiler_prefix_45710, _23976);

        /** buildsys.e:541				l_exe = compiler_prefix & "wlink"*/
        Concat((object_ptr)&_l_exe_45878, _56compiler_prefix_45710, _23978);

        /** buildsys.e:542				obj_ext = "obj"*/
        RefDS(_23980);
        DeRefi(_obj_ext_45880);
        _obj_ext_45880 = _23980;

        /** buildsys.e:544				if debug_option then*/
        if (_58debug_option_42903 == 0)
        {
            goto L2B; // [864] 881
        }
        else{
        }

        /** buildsys.e:545					c_flags = " /d3"*/
        RefDS(_23981);
        DeRef(_c_flags_45877);
        _c_flags_45877 = _23981;

        /** buildsys.e:546					l_flags_begin &= " DEBUG ALL "*/
        Concat((object_ptr)&_l_flags_begin_45882, _l_flags_begin_45882, _23982);
L2B: 

        /** buildsys.e:549				l_flags &= sprintf(" OPTION STACK=%d ", { total_stack_size })*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _58total_stack_size_42908;
        _23985 = MAKE_SEQ(_1);
        _23986 = EPrintf(-9999999, _23984, _23985);
        DeRefDS(_23985);
        _23985 = NOVALUE;
        Concat((object_ptr)&_l_flags_45879, _l_flags_45879, _23986);
        DeRefDS(_23986);
        _23986 = NOVALUE;

        /** buildsys.e:550				l_flags &= sprintf(" COMMIT STACK=%d ", { total_stack_size })*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _58total_stack_size_42908;
        _23989 = MAKE_SEQ(_1);
        _23990 = EPrintf(-9999999, _23988, _23989);
        DeRefDS(_23989);
        _23989 = NOVALUE;
        Concat((object_ptr)&_l_flags_45879, _l_flags_45879, _23990);
        DeRefDS(_23990);
        _23990 = NOVALUE;

        /** buildsys.e:551				l_flags &= " OPTION QUIET OPTION ELIMINATE OPTION CASEEXACT"*/
        Concat((object_ptr)&_l_flags_45879, _l_flags_45879, _23992);

        /** buildsys.e:553				if dll_option then*/
        if (_58dll_option_42893 == 0)
        {
            goto L2C; // [923] 949
        }
        else{
        }

        /** buildsys.e:554					c_flags &= " /bd /bt=nt /mf /w0 /zq /j /zp4 /fp5 /fpi87 /5r /otimra /s /I" & adjust_for_build_file(compile_dir) */
        Ref(_compile_dir_45986);
        _23995 = _56adjust_for_build_file(_compile_dir_45986);
        if (IS_SEQUENCE(_23994) && IS_ATOM(_23995)) {
            Ref(_23995);
            Append(&_23996, _23994, _23995);
        }
        else if (IS_ATOM(_23994) && IS_SEQUENCE(_23995)) {
        }
        else {
            Concat((object_ptr)&_23996, _23994, _23995);
        }
        DeRef(_23995);
        _23995 = NOVALUE;
        Concat((object_ptr)&_c_flags_45877, _c_flags_45877, _23996);
        DeRefDS(_23996);
        _23996 = NOVALUE;

        /** buildsys.e:555					l_flags &= " SYSTEM NT_DLL initinstance terminstance"*/
        Concat((object_ptr)&_l_flags_45879, _l_flags_45879, _23998);
        goto L2D; // [946] 987
L2C: 

        /** buildsys.e:557					c_flags &= " /bt=nt /mf /w0 /zq /j /zp4 /fp5 /fpi87 /5r /otimra /s /I" & adjust_for_build_file(compile_dir)*/
        Ref(_compile_dir_45986);
        _24001 = _56adjust_for_build_file(_compile_dir_45986);
        if (IS_SEQUENCE(_24000) && IS_ATOM(_24001)) {
            Ref(_24001);
            Append(&_24002, _24000, _24001);
        }
        else if (IS_ATOM(_24000) && IS_SEQUENCE(_24001)) {
        }
        else {
            Concat((object_ptr)&_24002, _24000, _24001);
        }
        DeRef(_24001);
        _24001 = NOVALUE;
        Concat((object_ptr)&_c_flags_45877, _c_flags_45877, _24002);
        DeRefDS(_24002);
        _24002 = NOVALUE;

        /** buildsys.e:558					if con_option then*/
        if (_58con_option_42895 == 0)
        {
            goto L2E; // [967] 979
        }
        else{
        }

        /** buildsys.e:560						l_flags = " SYSTEM NT" & l_flags*/
        Concat((object_ptr)&_l_flags_45879, _24004, _l_flags_45879);
        goto L2F; // [976] 986
L2E: 

        /** buildsys.e:562						l_flags = " SYSTEM NT_WIN RUNTIME WINDOWS=4.0" & l_flags*/
        Concat((object_ptr)&_l_flags_45879, _24006, _l_flags_45879);
L2F: 
L2D: 

        /** buildsys.e:566				l_flags &= sprintf(" FILE %s", { (user_library) })*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_58user_library_42905);
        ((intptr_t*)_2)[1] = _58user_library_42905;
        _24009 = MAKE_SEQ(_1);
        _24010 = EPrintf(-9999999, _24008, _24009);
        DeRefDS(_24009);
        _24009 = NOVALUE;
        Concat((object_ptr)&_l_flags_45879, _l_flags_45879, _24010);
        DeRefDS(_24010);
        _24010 = NOVALUE;

        /** buildsys.e:570				rc_comp = compiler_prefix &"wrc -DSRCDIR=\"" & adjust_for_build_file(current_dir()) & "\" -q -fo=[2] -ad [1] [3]"*/
        _24013 = _17current_dir();
        _24014 = _56adjust_for_build_file(_24013);
        _24013 = NOVALUE;
        {
            object concat_list[4];

            concat_list[0] = _24015;
            concat_list[1] = _24014;
            concat_list[2] = _24012;
            concat_list[3] = _56compiler_prefix_45710;
            Concat_N((object_ptr)&_rc_comp_45883, concat_list, 4);
        }
        DeRef(_24014);
        _24014 = NOVALUE;
        goto L2A; // [1021] 1037

        /** buildsys.e:571			case else*/
        default:

        /** buildsys.e:572				CompileErr(COMPILER_IS_UNKNOWN)*/
        RefDS(_22190);
        _50CompileErr(43, _22190, 0);
    ;}L2A: 

    /** buildsys.e:575		if length(cflags) then*/
    if (IS_SEQUENCE(_56cflags_45727)){
            _24017 = SEQ_PTR(_56cflags_45727)->length;
    }
    else {
        _24017 = 1;
    }
    if (_24017 == 0)
    {
        _24017 = NOVALUE;
        goto L30; // [1044] 1057
    }
    else{
        _24017 = NOVALUE;
    }

    /** buildsys.e:577			c_flags = cflags*/
    RefDS(_56cflags_45727);
    DeRef(_c_flags_45877);
    _c_flags_45877 = _56cflags_45727;
L30: 

    /** buildsys.e:580		if length(extra_cflags) then*/
    if (IS_SEQUENCE(_56extra_cflags_45728)){
            _24018 = SEQ_PTR(_56extra_cflags_45728)->length;
    }
    else {
        _24018 = 1;
    }
    if (_24018 == 0)
    {
        _24018 = NOVALUE;
        goto L31; // [1064] 1080
    }
    else{
        _24018 = NOVALUE;
    }

    /** buildsys.e:581			c_flags &= " " & extra_cflags*/
    Concat((object_ptr)&_24019, _23576, _56extra_cflags_45728);
    Concat((object_ptr)&_c_flags_45877, _c_flags_45877, _24019);
    DeRefDS(_24019);
    _24019 = NOVALUE;
L31: 

    /** buildsys.e:584		if length(lflags) then*/
    if (IS_SEQUENCE(_56lflags_45729)){
            _24021 = SEQ_PTR(_56lflags_45729)->length;
    }
    else {
        _24021 = 1;
    }
    if (_24021 == 0)
    {
        _24021 = NOVALUE;
        goto L32; // [1087] 1107
    }
    else{
        _24021 = NOVALUE;
    }

    /** buildsys.e:585			l_flags = lflags*/
    RefDS(_56lflags_45729);
    DeRef(_l_flags_45879);
    _l_flags_45879 = _56lflags_45729;

    /** buildsys.e:586			l_flags_begin = ""*/
    RefDS(_22190);
    DeRefi(_l_flags_begin_45882);
    _l_flags_begin_45882 = _22190;
L32: 

    /** buildsys.e:589		if length(extra_lflags) then*/
    if (IS_SEQUENCE(_56extra_lflags_45730)){
            _24022 = SEQ_PTR(_56extra_lflags_45730)->length;
    }
    else {
        _24022 = 1;
    }
    if (_24022 == 0)
    {
        _24022 = NOVALUE;
        goto L33; // [1114] 1130
    }
    else{
        _24022 = NOVALUE;
    }

    /** buildsys.e:590			l_flags &= " " & extra_lflags*/
    Concat((object_ptr)&_24023, _23576, _56extra_lflags_45730);
    Concat((object_ptr)&_l_flags_45879, _l_flags_45879, _24023);
    DeRefDS(_24023);
    _24023 = NOVALUE;
L33: 

    /** buildsys.e:593		return { */
    _1 = NewS1(9);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_c_exe_45876);
    ((intptr_t*)_2)[1] = _c_exe_45876;
    RefDS(_c_flags_45877);
    ((intptr_t*)_2)[2] = _c_flags_45877;
    RefDS(_l_exe_45878);
    ((intptr_t*)_2)[3] = _l_exe_45878;
    RefDS(_l_flags_45879);
    ((intptr_t*)_2)[4] = _l_flags_45879;
    RefDS(_obj_ext_45880);
    ((intptr_t*)_2)[5] = _obj_ext_45880;
    RefDS(_exe_ext_45881);
    ((intptr_t*)_2)[6] = _exe_ext_45881;
    RefDS(_l_flags_begin_45882);
    ((intptr_t*)_2)[7] = _l_flags_begin_45882;
    RefDS(_rc_comp_45883);
    ((intptr_t*)_2)[8] = _rc_comp_45883;
    RefDS(_58user_library_42905);
    ((intptr_t*)_2)[9] = _58user_library_42905;
    _24025 = MAKE_SEQ(_1);
    DeRefDS(_c_exe_45876);
    DeRefDS(_c_flags_45877);
    DeRefDS(_l_exe_45878);
    DeRefDS(_l_flags_45879);
    DeRefDSi(_obj_ext_45880);
    DeRefDSi(_exe_ext_45881);
    DeRefDSi(_l_flags_begin_45882);
    DeRefDS(_rc_comp_45883);
    DeRef(_l_names_45884);
    DeRefi(_l_ext_45885);
    DeRefi(_t_slash_45886);
    DeRef(_compile_dir_45986);
    DeRef(_23871);
    _23871 = NOVALUE;
    return _24025;
    ;
}


void _56ensure_exename(object _ext_46154)
{
    object _24032 = NOVALUE;
    object _24031 = NOVALUE;
    object _24030 = NOVALUE;
    object _24029 = NOVALUE;
    object _24027 = NOVALUE;
    object _24026 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:602		if length(exe_name[D_ALTNAME]) = 0 then*/
    _2 = (object)SEQ_PTR(_56exe_name_45712);
    _24026 = (object)*(((s1_ptr)_2)->base + 11);
    if (IS_SEQUENCE(_24026)){
            _24027 = SEQ_PTR(_24026)->length;
    }
    else {
        _24027 = 1;
    }
    _24026 = NOVALUE;
    if (_24027 != 0)
    goto L1; // [16] 67

    /** buildsys.e:603			exe_name[D_NAME] = current_dir() & SLASH & file0 & ext*/
    _24029 = _17current_dir();
    {
        object concat_list[4];

        concat_list[0] = _ext_46154;
        concat_list[1] = _58file0_44851;
        concat_list[2] = 92;
        concat_list[3] = _24029;
        Concat_N((object_ptr)&_24030, concat_list, 4);
    }
    DeRef(_24029);
    _24029 = NOVALUE;
    _2 = (object)SEQ_PTR(_56exe_name_45712);
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24030;
    if( _1 != _24030 ){
        DeRef(_1);
    }
    _24030 = NOVALUE;

    /** buildsys.e:604			exe_name[D_ALTNAME] = adjust_for_command_line_passing(exe_name[D_NAME])*/
    _2 = (object)SEQ_PTR(_56exe_name_45712);
    _24031 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_24031);
    _24032 = _56adjust_for_command_line_passing(_24031);
    _24031 = NOVALUE;
    _2 = (object)SEQ_PTR(_56exe_name_45712);
    _2 = (object)(((s1_ptr)_2)->base + 11);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24032;
    if( _1 != _24032 ){
        DeRef(_1);
    }
    _24032 = NOVALUE;
L1: 

    /** buildsys.e:606	end procedure*/
    DeRefDS(_ext_46154);
    _24026 = NOVALUE;
    return;
    ;
}


void _56write_objlink_file()
{
    object _settings_46172 = NOVALUE;
    object _fh_46174 = NOVALUE;
    object _s_46222 = NOVALUE;
    object _24081 = NOVALUE;
    object _24079 = NOVALUE;
    object _24078 = NOVALUE;
    object _24077 = NOVALUE;
    object _24076 = NOVALUE;
    object _24075 = NOVALUE;
    object _24074 = NOVALUE;
    object _24073 = NOVALUE;
    object _24072 = NOVALUE;
    object _24071 = NOVALUE;
    object _24070 = NOVALUE;
    object _24069 = NOVALUE;
    object _24068 = NOVALUE;
    object _24066 = NOVALUE;
    object _24065 = NOVALUE;
    object _24064 = NOVALUE;
    object _24063 = NOVALUE;
    object _24061 = NOVALUE;
    object _24060 = NOVALUE;
    object _24059 = NOVALUE;
    object _24058 = NOVALUE;
    object _24057 = NOVALUE;
    object _24056 = NOVALUE;
    object _24055 = NOVALUE;
    object _24054 = NOVALUE;
    object _24053 = NOVALUE;
    object _24050 = NOVALUE;
    object _24049 = NOVALUE;
    object _24046 = NOVALUE;
    object _24045 = NOVALUE;
    object _24044 = NOVALUE;
    object _24043 = NOVALUE;
    object _24042 = NOVALUE;
    object _24040 = NOVALUE;
    object _24039 = NOVALUE;
    object _24038 = NOVALUE;
    object _24035 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:612		sequence settings = setup_build()*/
    _0 = _settings_46172;
    _settings_46172 = _56setup_build();
    DeRef(_0);

    /** buildsys.e:613		integer fh = open(output_dir & file0 & ".lnk", "wb")*/
    {
        object concat_list[3];

        concat_list[0] = _24034;
        concat_list[1] = _58file0_44851;
        concat_list[2] = _58output_dir_42907;
        Concat_N((object_ptr)&_24035, concat_list, 3);
    }
    _fh_46174 = EOpen(_24035, _24036, 0);
    DeRefDS(_24035);
    _24035 = NOVALUE;

    /** buildsys.e:615		ensure_exename(settings[SETUP_EXE_EXT])*/
    _2 = (object)SEQ_PTR(_settings_46172);
    _24038 = (object)*(((s1_ptr)_2)->base + 6);
    Ref(_24038);
    _56ensure_exename(_24038);
    _24038 = NOVALUE;

    /** buildsys.e:617		if length(settings[SETUP_LFLAGS_BEGIN]) > 0 then*/
    _2 = (object)SEQ_PTR(_settings_46172);
    _24039 = (object)*(((s1_ptr)_2)->base + 7);
    if (IS_SEQUENCE(_24039)){
            _24040 = SEQ_PTR(_24039)->length;
    }
    else {
        _24040 = 1;
    }
    _24039 = NOVALUE;
    if (_24040 <= 0)
    goto L1; // [43] 63

    /** buildsys.e:618			puts(fh, settings[SETUP_LFLAGS_BEGIN] & HOSTNL)*/
    _2 = (object)SEQ_PTR(_settings_46172);
    _24042 = (object)*(((s1_ptr)_2)->base + 7);
    if (IS_SEQUENCE(_24042) && IS_ATOM(_46HOSTNL_21937)) {
    }
    else if (IS_ATOM(_24042) && IS_SEQUENCE(_46HOSTNL_21937)) {
        Ref(_24042);
        Prepend(&_24043, _46HOSTNL_21937, _24042);
    }
    else {
        Concat((object_ptr)&_24043, _24042, _46HOSTNL_21937);
        _24042 = NOVALUE;
    }
    _24042 = NOVALUE;
    EPuts(_fh_46174, _24043); // DJP 
    DeRefDS(_24043);
    _24043 = NOVALUE;
L1: 

    /** buildsys.e:621		for i = 1 to length(generated_files) do*/
    if (IS_SEQUENCE(_58generated_files_42897)){
            _24044 = SEQ_PTR(_58generated_files_42897)->length;
    }
    else {
        _24044 = 1;
    }
    {
        object _i_46190;
        _i_46190 = 1;
L2: 
        if (_i_46190 > _24044){
            goto L3; // [70] 132
        }

        /** buildsys.e:622			if match(".o", generated_files[i]) then*/
        _2 = (object)SEQ_PTR(_58generated_files_42897);
        _24045 = (object)*(((s1_ptr)_2)->base + _i_46190);
        _24046 = e_match_from(_23336, _24045, 1);
        _24045 = NOVALUE;
        if (_24046 == 0)
        {
            _24046 = NOVALUE;
            goto L4; // [90] 125
        }
        else{
            _24046 = NOVALUE;
        }

        /** buildsys.e:623				if compiler_type = COMPILER_WATCOM then*/
        if (_56compiler_type_45709 != 2)
        goto L5; // [97] 107

        /** buildsys.e:624					puts(fh, "FILE ")*/
        EPuts(_fh_46174, _24048); // DJP 
L5: 

        /** buildsys.e:627				puts(fh, generated_files[i] & HOSTNL)*/
        _2 = (object)SEQ_PTR(_58generated_files_42897);
        _24049 = (object)*(((s1_ptr)_2)->base + _i_46190);
        Concat((object_ptr)&_24050, _24049, _46HOSTNL_21937);
        _24049 = NOVALUE;
        _24049 = NOVALUE;
        EPuts(_fh_46174, _24050); // DJP 
        DeRefDS(_24050);
        _24050 = NOVALUE;
L4: 

        /** buildsys.e:629		end for*/
        _i_46190 = _i_46190 + 1;
        goto L2; // [127] 77
L3: 
        ;
    }

    /** buildsys.e:631		if compiler_type = COMPILER_WATCOM then*/
    if (_56compiler_type_45709 != 2)
    goto L6; // [136] 165

    /** buildsys.e:632			printf(fh, "NAME '%s'" & HOSTNL, { exe_name[D_ALTNAME] })*/
    Concat((object_ptr)&_24053, _24052, _46HOSTNL_21937);
    _2 = (object)SEQ_PTR(_56exe_name_45712);
    _24054 = (object)*(((s1_ptr)_2)->base + 11);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_24054);
    ((intptr_t*)_2)[1] = _24054;
    _24055 = MAKE_SEQ(_1);
    _24054 = NOVALUE;
    EPrintf(_fh_46174, _24053, _24055);
    DeRefDS(_24053);
    _24053 = NOVALUE;
    DeRefDS(_24055);
    _24055 = NOVALUE;
L6: 

    /** buildsys.e:635		puts(fh, trim(settings[SETUP_LFLAGS] & HOSTNL))*/
    _2 = (object)SEQ_PTR(_settings_46172);
    _24056 = (object)*(((s1_ptr)_2)->base + 4);
    if (IS_SEQUENCE(_24056) && IS_ATOM(_46HOSTNL_21937)) {
    }
    else if (IS_ATOM(_24056) && IS_SEQUENCE(_46HOSTNL_21937)) {
        Ref(_24056);
        Prepend(&_24057, _46HOSTNL_21937, _24056);
    }
    else {
        Concat((object_ptr)&_24057, _24056, _46HOSTNL_21937);
        _24056 = NOVALUE;
    }
    _24056 = NOVALUE;
    RefDS(_3922);
    _24058 = _14trim(_24057, _3922, 0);
    _24057 = NOVALUE;
    EPuts(_fh_46174, _24058); // DJP 
    DeRef(_24058);
    _24058 = NOVALUE;

    /** buildsys.e:637		if compiler_type = COMPILER_WATCOM and dll_option then*/
    _24059 = (_56compiler_type_45709 == 2);
    if (_24059 == 0) {
        goto L7; // [194] 361
    }
    if (_58dll_option_42893 == 0)
    {
        goto L7; // [201] 361
    }
    else{
    }

    /** buildsys.e:638			puts(fh, HOSTNL)*/
    EPuts(_fh_46174, _46HOSTNL_21937); // DJP 

    /** buildsys.e:640			object s = SymTab[TopLevelSub][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _24061 = (object)*(((s1_ptr)_2)->base + _36TopLevelSub_21774);
    DeRef(_s_46222);
    _2 = (object)SEQ_PTR(_24061);
    _s_46222 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_s_46222);
    _24061 = NOVALUE;

    /** buildsys.e:641			while s do*/
L8: 
    if (_s_46222 <= 0) {
        if (_s_46222 == 0) {
            goto L9; // [232] 360
        }
        else {
            if (!IS_ATOM_INT(_s_46222) && DBL_PTR(_s_46222)->dbl == 0.0){
                goto L9; // [232] 360
            }
        }
    }

    /** buildsys.e:642				if eu:find(SymTab[s][S_TOKEN], RTN_TOKS) then*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!IS_ATOM_INT(_s_46222)){
        _24063 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_s_46222)->dbl));
    }
    else{
        _24063 = (object)*(((s1_ptr)_2)->base + _s_46222);
    }
    _2 = (object)SEQ_PTR(_24063);
    if (!IS_ATOM_INT(_36S_TOKEN_21409)){
        _24064 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21409)->dbl));
    }
    else{
        _24064 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21409);
    }
    _24063 = NOVALUE;
    _24065 = find_from(_24064, _38RTN_TOKS_16291, 1);
    _24064 = NOVALUE;
    if (_24065 == 0)
    {
        _24065 = NOVALUE;
        goto LA; // [256] 341
    }
    else{
        _24065 = NOVALUE;
    }

    /** buildsys.e:643					if is_exported( s ) then*/
    Ref(_s_46222);
    _24066 = _58is_exported(_s_46222);
    if (_24066 == 0) {
        DeRef(_24066);
        _24066 = NOVALUE;
        goto LB; // [265] 340
    }
    else {
        if (!IS_ATOM_INT(_24066) && DBL_PTR(_24066)->dbl == 0.0){
            DeRef(_24066);
            _24066 = NOVALUE;
            goto LB; // [265] 340
        }
        DeRef(_24066);
        _24066 = NOVALUE;
    }
    DeRef(_24066);
    _24066 = NOVALUE;

    /** buildsys.e:644						printf(fh, "EXPORT %s='__%d%s@%d'" & HOSTNL,*/
    Concat((object_ptr)&_24068, _24067, _46HOSTNL_21937);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!IS_ATOM_INT(_s_46222)){
        _24069 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_s_46222)->dbl));
    }
    else{
        _24069 = (object)*(((s1_ptr)_2)->base + _s_46222);
    }
    _2 = (object)SEQ_PTR(_24069);
    if (!IS_ATOM_INT(_36S_NAME_21404)){
        _24070 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21404)->dbl));
    }
    else{
        _24070 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21404);
    }
    _24069 = NOVALUE;
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!IS_ATOM_INT(_s_46222)){
        _24071 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_s_46222)->dbl));
    }
    else{
        _24071 = (object)*(((s1_ptr)_2)->base + _s_46222);
    }
    _2 = (object)SEQ_PTR(_24071);
    if (!IS_ATOM_INT(_36S_FILE_NO_21400)){
        _24072 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21400)->dbl));
    }
    else{
        _24072 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21400);
    }
    _24071 = NOVALUE;
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!IS_ATOM_INT(_s_46222)){
        _24073 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_s_46222)->dbl));
    }
    else{
        _24073 = (object)*(((s1_ptr)_2)->base + _s_46222);
    }
    _2 = (object)SEQ_PTR(_24073);
    if (!IS_ATOM_INT(_36S_NAME_21404)){
        _24074 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21404)->dbl));
    }
    else{
        _24074 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21404);
    }
    _24073 = NOVALUE;
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!IS_ATOM_INT(_s_46222)){
        _24075 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_s_46222)->dbl));
    }
    else{
        _24075 = (object)*(((s1_ptr)_2)->base + _s_46222);
    }
    _2 = (object)SEQ_PTR(_24075);
    if (!IS_ATOM_INT(_36S_NUM_ARGS_21455)){
        _24076 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21455)->dbl));
    }
    else{
        _24076 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21455);
    }
    _24075 = NOVALUE;
    if (IS_ATOM_INT(_24076)) {
        if (_24076 == (short)_24076){
            _24077 = _24076 * 4;
        }
        else{
            _24077 = NewDouble(_24076 * (eudouble)4);
        }
    }
    else {
        _24077 = binary_op(MULTIPLY, _24076, 4);
    }
    _24076 = NOVALUE;
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_24070);
    ((intptr_t*)_2)[1] = _24070;
    Ref(_24072);
    ((intptr_t*)_2)[2] = _24072;
    Ref(_24074);
    ((intptr_t*)_2)[3] = _24074;
    ((intptr_t*)_2)[4] = _24077;
    _24078 = MAKE_SEQ(_1);
    _24077 = NOVALUE;
    _24074 = NOVALUE;
    _24072 = NOVALUE;
    _24070 = NOVALUE;
    EPrintf(_fh_46174, _24068, _24078);
    DeRefDS(_24068);
    _24068 = NOVALUE;
    DeRefDS(_24078);
    _24078 = NOVALUE;
LB: 
LA: 

    /** buildsys.e:649				s = SymTab[s][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!IS_ATOM_INT(_s_46222)){
        _24079 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_s_46222)->dbl));
    }
    else{
        _24079 = (object)*(((s1_ptr)_2)->base + _s_46222);
    }
    DeRef(_s_46222);
    _2 = (object)SEQ_PTR(_24079);
    _s_46222 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_s_46222);
    _24079 = NOVALUE;

    /** buildsys.e:650			end while*/
    goto L8; // [357] 232
L9: 
L7: 
    DeRef(_s_46222);
    _s_46222 = NOVALUE;

    /** buildsys.e:653		close(fh)*/
    EClose(_fh_46174);

    /** buildsys.e:655		generated_files = append(generated_files, file0 & ".lnk")*/
    Concat((object_ptr)&_24081, _58file0_44851, _24034);
    RefDS(_24081);
    Append(&_58generated_files_42897, _58generated_files_42897, _24081);
    DeRefDS(_24081);
    _24081 = NOVALUE;

    /** buildsys.e:656	end procedure*/
    DeRef(_settings_46172);
    DeRef(_24059);
    _24059 = NOVALUE;
    _24039 = NOVALUE;
    return;
    ;
}


void _56write_makefile_srcobj_list(object _fh_46271)
{
    object _file_count_46301 = NOVALUE;
    object _24113 = NOVALUE;
    object _24112 = NOVALUE;
    object _24111 = NOVALUE;
    object _24109 = NOVALUE;
    object _24108 = NOVALUE;
    object _24107 = NOVALUE;
    object _24105 = NOVALUE;
    object _24104 = NOVALUE;
    object _24102 = NOVALUE;
    object _24101 = NOVALUE;
    object _24100 = NOVALUE;
    object _24099 = NOVALUE;
    object _24098 = NOVALUE;
    object _24097 = NOVALUE;
    object _24095 = NOVALUE;
    object _24094 = NOVALUE;
    object _24093 = NOVALUE;
    object _24089 = NOVALUE;
    object _24088 = NOVALUE;
    object _24087 = NOVALUE;
    object _24086 = NOVALUE;
    object _24085 = NOVALUE;
    object _24084 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:660		printf(fh, "%s_SOURCES =", { upper(file0) })*/
    RefDS(_58file0_44851);
    _24084 = _14upper(_58file0_44851);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _24084;
    _24085 = MAKE_SEQ(_1);
    _24084 = NOVALUE;
    EPrintf(_fh_46271, _24083, _24085);
    DeRefDS(_24085);
    _24085 = NOVALUE;

    /** buildsys.e:661		for i = 1 to length(generated_files) do*/
    if (IS_SEQUENCE(_58generated_files_42897)){
            _24086 = SEQ_PTR(_58generated_files_42897)->length;
    }
    else {
        _24086 = 1;
    }
    {
        object _i_46278;
        _i_46278 = 1;
L1: 
        if (_i_46278 > _24086){
            goto L2; // [26] 94
        }

        /** buildsys.e:662			if generated_files[i][$] = 'c' then*/
        _2 = (object)SEQ_PTR(_58generated_files_42897);
        _24087 = (object)*(((s1_ptr)_2)->base + _i_46278);
        if (IS_SEQUENCE(_24087)){
                _24088 = SEQ_PTR(_24087)->length;
        }
        else {
            _24088 = 1;
        }
        _2 = (object)SEQ_PTR(_24087);
        _24089 = (object)*(((s1_ptr)_2)->base + _24088);
        _24087 = NOVALUE;
        if (binary_op_a(NOTEQ, _24089, 99)){
            _24089 = NOVALUE;
            goto L3; // [48] 87
        }
        _24089 = NOVALUE;

        /** buildsys.e:663				if i > 1 then*/
        if (_i_46278 <= 1)
        goto L4; // [54] 71

        /** buildsys.e:664					printf(fh, " \\%s\t", { HOSTNL }  )*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_46HOSTNL_21937);
        ((intptr_t*)_2)[1] = _46HOSTNL_21937;
        _24093 = MAKE_SEQ(_1);
        EPrintf(_fh_46271, _24092, _24093);
        DeRefDS(_24093);
        _24093 = NOVALUE;
L4: 

        /** buildsys.e:666				puts(fh, " " & generated_files[i])*/
        _2 = (object)SEQ_PTR(_58generated_files_42897);
        _24094 = (object)*(((s1_ptr)_2)->base + _i_46278);
        Concat((object_ptr)&_24095, _23576, _24094);
        _24094 = NOVALUE;
        EPuts(_fh_46271, _24095); // DJP 
        DeRefDS(_24095);
        _24095 = NOVALUE;
L3: 

        /** buildsys.e:668		end for*/
        _i_46278 = _i_46278 + 1;
        goto L1; // [89] 33
L2: 
        ;
    }

    /** buildsys.e:669		puts(fh, HOSTNL)*/
    EPuts(_fh_46271, _46HOSTNL_21937); // DJP 

    /** buildsys.e:671		printf(fh, "%s_OBJECTS =", { upper(file0) })*/
    RefDS(_58file0_44851);
    _24097 = _14upper(_58file0_44851);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _24097;
    _24098 = MAKE_SEQ(_1);
    _24097 = NOVALUE;
    EPrintf(_fh_46271, _24096, _24098);
    DeRefDS(_24098);
    _24098 = NOVALUE;

    /** buildsys.e:672		integer file_count = 0*/
    _file_count_46301 = 0;

    /** buildsys.e:673		for i = 1 to length(generated_files) do*/
    if (IS_SEQUENCE(_58generated_files_42897)){
            _24099 = SEQ_PTR(_58generated_files_42897)->length;
    }
    else {
        _24099 = 1;
    }
    {
        object _i_46303;
        _i_46303 = 1;
L5: 
        if (_i_46303 > _24099){
            goto L6; // [129] 199
        }

        /** buildsys.e:674			if match(".o", generated_files[i]) then*/
        _2 = (object)SEQ_PTR(_58generated_files_42897);
        _24100 = (object)*(((s1_ptr)_2)->base + _i_46303);
        _24101 = e_match_from(_23336, _24100, 1);
        _24100 = NOVALUE;
        if (_24101 == 0)
        {
            _24101 = NOVALUE;
            goto L7; // [149] 192
        }
        else{
            _24101 = NOVALUE;
        }

        /** buildsys.e:675				if file_count then*/
        if (_file_count_46301 == 0)
        {
            goto L8; // [154] 170
        }
        else{
        }

        /** buildsys.e:676					printf(fh, " \\%s\t", { HOSTNL }  )*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_46HOSTNL_21937);
        ((intptr_t*)_2)[1] = _46HOSTNL_21937;
        _24102 = MAKE_SEQ(_1);
        EPrintf(_fh_46271, _24092, _24102);
        DeRefDS(_24102);
        _24102 = NOVALUE;
L8: 

        /** buildsys.e:678				file_count += 1*/
        _file_count_46301 = _file_count_46301 + 1;

        /** buildsys.e:679				puts(fh, " " & generated_files[i])*/
        _2 = (object)SEQ_PTR(_58generated_files_42897);
        _24104 = (object)*(((s1_ptr)_2)->base + _i_46303);
        Concat((object_ptr)&_24105, _23576, _24104);
        _24104 = NOVALUE;
        EPuts(_fh_46271, _24105); // DJP 
        DeRefDS(_24105);
        _24105 = NOVALUE;
L7: 

        /** buildsys.e:681		end for*/
        _i_46303 = _i_46303 + 1;
        goto L5; // [194] 136
L6: 
        ;
    }

    /** buildsys.e:682		puts(fh, HOSTNL)*/
    EPuts(_fh_46271, _46HOSTNL_21937); // DJP 

    /** buildsys.e:684		printf(fh, "%s_GENERATED_FILES = ", { upper(file0) })*/
    RefDS(_58file0_44851);
    _24107 = _14upper(_58file0_44851);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _24107;
    _24108 = MAKE_SEQ(_1);
    _24107 = NOVALUE;
    EPrintf(_fh_46271, _24106, _24108);
    DeRefDS(_24108);
    _24108 = NOVALUE;

    /** buildsys.e:685		for i = 1 to length(generated_files) do*/
    if (IS_SEQUENCE(_58generated_files_42897)){
            _24109 = SEQ_PTR(_58generated_files_42897)->length;
    }
    else {
        _24109 = 1;
    }
    {
        object _i_46324;
        _i_46324 = 1;
L9: 
        if (_i_46324 > _24109){
            goto LA; // [229] 277
        }

        /** buildsys.e:686			if i > 1 then*/
        if (_i_46324 <= 1)
        goto LB; // [238] 255

        /** buildsys.e:687				printf(fh, " \\%s\t", { HOSTNL }  )*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_46HOSTNL_21937);
        ((intptr_t*)_2)[1] = _46HOSTNL_21937;
        _24111 = MAKE_SEQ(_1);
        EPrintf(_fh_46271, _24092, _24111);
        DeRefDS(_24111);
        _24111 = NOVALUE;
LB: 

        /** buildsys.e:689			puts(fh, " " & generated_files[i])*/
        _2 = (object)SEQ_PTR(_58generated_files_42897);
        _24112 = (object)*(((s1_ptr)_2)->base + _i_46324);
        Concat((object_ptr)&_24113, _23576, _24112);
        _24112 = NOVALUE;
        EPuts(_fh_46271, _24113); // DJP 
        DeRefDS(_24113);
        _24113 = NOVALUE;

        /** buildsys.e:690		end for*/
        _i_46324 = _i_46324 + 1;
        goto L9; // [272] 236
LA: 
        ;
    }

    /** buildsys.e:691		puts(fh, HOSTNL)*/
    EPuts(_fh_46271, _46HOSTNL_21937); // DJP 

    /** buildsys.e:692	end procedure*/
    return;
    ;
}


object _56windows_to_mingw_path(object _s_46337)
{
    object _24115 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:701		ifdef TEST_FOR_WIN9X_ON_MING then*/

    /** buildsys.e:711		return search:find_replace('\\',s,'/')*/
    RefDS(_s_46337);
    _24115 = _16find_replace(92, _s_46337, 47, 0);
    DeRefDS(_s_46337);
    return _24115;
    ;
}


void _56write_makefile_full()
{
    object _settings_46342 = NOVALUE;
    object _fh_46345 = NOVALUE;
    object _24242 = NOVALUE;
    object _24240 = NOVALUE;
    object _24238 = NOVALUE;
    object _24237 = NOVALUE;
    object _24236 = NOVALUE;
    object _24235 = NOVALUE;
    object _24234 = NOVALUE;
    object _24232 = NOVALUE;
    object _24231 = NOVALUE;
    object _24229 = NOVALUE;
    object _24228 = NOVALUE;
    object _24227 = NOVALUE;
    object _24226 = NOVALUE;
    object _24224 = NOVALUE;
    object _24223 = NOVALUE;
    object _24221 = NOVALUE;
    object _24220 = NOVALUE;
    object _24218 = NOVALUE;
    object _24217 = NOVALUE;
    object _24216 = NOVALUE;
    object _24215 = NOVALUE;
    object _24214 = NOVALUE;
    object _24213 = NOVALUE;
    object _24212 = NOVALUE;
    object _24211 = NOVALUE;
    object _24209 = NOVALUE;
    object _24208 = NOVALUE;
    object _24207 = NOVALUE;
    object _24206 = NOVALUE;
    object _24205 = NOVALUE;
    object _24204 = NOVALUE;
    object _24203 = NOVALUE;
    object _24202 = NOVALUE;
    object _24201 = NOVALUE;
    object _24200 = NOVALUE;
    object _24199 = NOVALUE;
    object _24198 = NOVALUE;
    object _24197 = NOVALUE;
    object _24195 = NOVALUE;
    object _24194 = NOVALUE;
    object _24192 = NOVALUE;
    object _24190 = NOVALUE;
    object _24188 = NOVALUE;
    object _24187 = NOVALUE;
    object _24186 = NOVALUE;
    object _24185 = NOVALUE;
    object _24184 = NOVALUE;
    object _24183 = NOVALUE;
    object _24182 = NOVALUE;
    object _24181 = NOVALUE;
    object _24180 = NOVALUE;
    object _24179 = NOVALUE;
    object _24178 = NOVALUE;
    object _24177 = NOVALUE;
    object _24176 = NOVALUE;
    object _24175 = NOVALUE;
    object _24173 = NOVALUE;
    object _24172 = NOVALUE;
    object _24171 = NOVALUE;
    object _24170 = NOVALUE;
    object _24169 = NOVALUE;
    object _24168 = NOVALUE;
    object _24167 = NOVALUE;
    object _24166 = NOVALUE;
    object _24165 = NOVALUE;
    object _24163 = NOVALUE;
    object _24162 = NOVALUE;
    object _24161 = NOVALUE;
    object _24160 = NOVALUE;
    object _24158 = NOVALUE;
    object _24157 = NOVALUE;
    object _24156 = NOVALUE;
    object _24155 = NOVALUE;
    object _24154 = NOVALUE;
    object _24153 = NOVALUE;
    object _24151 = NOVALUE;
    object _24150 = NOVALUE;
    object _24149 = NOVALUE;
    object _24148 = NOVALUE;
    object _24147 = NOVALUE;
    object _24146 = NOVALUE;
    object _24145 = NOVALUE;
    object _24143 = NOVALUE;
    object _24142 = NOVALUE;
    object _24141 = NOVALUE;
    object _24140 = NOVALUE;
    object _24137 = NOVALUE;
    object _24136 = NOVALUE;
    object _24135 = NOVALUE;
    object _24132 = NOVALUE;
    object _24131 = NOVALUE;
    object _24130 = NOVALUE;
    object _24128 = NOVALUE;
    object _24127 = NOVALUE;
    object _24126 = NOVALUE;
    object _24124 = NOVALUE;
    object _24123 = NOVALUE;
    object _24122 = NOVALUE;
    object _24119 = NOVALUE;
    object _24117 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:718		sequence settings = setup_build()*/
    _0 = _settings_46342;
    _settings_46342 = _56setup_build();
    DeRef(_0);

    /** buildsys.e:720		ensure_exename(settings[SETUP_EXE_EXT])*/
    _2 = (object)SEQ_PTR(_settings_46342);
    _24117 = (object)*(((s1_ptr)_2)->base + 6);
    Ref(_24117);
    _56ensure_exename(_24117);
    _24117 = NOVALUE;

    /** buildsys.e:722		integer fh = open(output_dir & file0 & ".mak", "wb")*/
    {
        object concat_list[3];

        concat_list[0] = _24118;
        concat_list[1] = _58file0_44851;
        concat_list[2] = _58output_dir_42907;
        Concat_N((object_ptr)&_24119, concat_list, 3);
    }
    _fh_46345 = EOpen(_24119, _24036, 0);
    DeRefDS(_24119);
    _24119 = NOVALUE;

    /** buildsys.e:724		printf(fh, "CC     = %s" & HOSTNL, { settings[SETUP_CEXE] })*/
    Concat((object_ptr)&_24122, _24121, _46HOSTNL_21937);
    _2 = (object)SEQ_PTR(_settings_46342);
    _24123 = (object)*(((s1_ptr)_2)->base + 1);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_24123);
    ((intptr_t*)_2)[1] = _24123;
    _24124 = MAKE_SEQ(_1);
    _24123 = NOVALUE;
    EPrintf(_fh_46345, _24122, _24124);
    DeRefDS(_24122);
    _24122 = NOVALUE;
    DeRefDS(_24124);
    _24124 = NOVALUE;

    /** buildsys.e:725		printf(fh, "CFLAGS = %s" & HOSTNL, { settings[SETUP_CFLAGS] })*/
    Concat((object_ptr)&_24126, _24125, _46HOSTNL_21937);
    _2 = (object)SEQ_PTR(_settings_46342);
    _24127 = (object)*(((s1_ptr)_2)->base + 2);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_24127);
    ((intptr_t*)_2)[1] = _24127;
    _24128 = MAKE_SEQ(_1);
    _24127 = NOVALUE;
    EPrintf(_fh_46345, _24126, _24128);
    DeRefDS(_24126);
    _24126 = NOVALUE;
    DeRefDS(_24128);
    _24128 = NOVALUE;

    /** buildsys.e:726		printf(fh, "LINKER = %s" & HOSTNL, { settings[SETUP_LEXE] })*/
    Concat((object_ptr)&_24130, _24129, _46HOSTNL_21937);
    _2 = (object)SEQ_PTR(_settings_46342);
    _24131 = (object)*(((s1_ptr)_2)->base + 3);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_24131);
    ((intptr_t*)_2)[1] = _24131;
    _24132 = MAKE_SEQ(_1);
    _24131 = NOVALUE;
    EPrintf(_fh_46345, _24130, _24132);
    DeRefDS(_24130);
    _24130 = NOVALUE;
    DeRefDS(_24132);
    _24132 = NOVALUE;

    /** buildsys.e:728		if compiler_type = COMPILER_GCC then*/
    if (_56compiler_type_45709 != 1)
    goto L1; // [98] 125

    /** buildsys.e:729			printf(fh, "LFLAGS = %s" & HOSTNL, { settings[SETUP_LFLAGS] })*/
    Concat((object_ptr)&_24135, _24134, _46HOSTNL_21937);
    _2 = (object)SEQ_PTR(_settings_46342);
    _24136 = (object)*(((s1_ptr)_2)->base + 4);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_24136);
    ((intptr_t*)_2)[1] = _24136;
    _24137 = MAKE_SEQ(_1);
    _24136 = NOVALUE;
    EPrintf(_fh_46345, _24135, _24137);
    DeRefDS(_24135);
    _24135 = NOVALUE;
    DeRefDS(_24137);
    _24137 = NOVALUE;
    goto L2; // [122] 130
L1: 

    /** buildsys.e:731			write_objlink_file()*/
    _56write_objlink_file();
L2: 

    /** buildsys.e:734		write_makefile_srcobj_list(fh)*/
    _56write_makefile_srcobj_list(_fh_46345);

    /** buildsys.e:735		puts(fh, HOSTNL)*/
    EPuts(_fh_46345, _46HOSTNL_21937); // DJP 

    /** buildsys.e:737		if compiler_type = COMPILER_WATCOM then*/
    if (_56compiler_type_45709 != 2)
    goto L3; // [146] 575

    /** buildsys.e:738			printf(fh, "\"%s\" : $(%s_OBJECTS) %s" & HOSTNL, { */
    Concat((object_ptr)&_24140, _24139, _46HOSTNL_21937);
    _2 = (object)SEQ_PTR(_56exe_name_45712);
    _24141 = (object)*(((s1_ptr)_2)->base + 11);
    RefDS(_58file0_44851);
    _24142 = _14upper(_58file0_44851);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_24141);
    ((intptr_t*)_2)[1] = _24141;
    ((intptr_t*)_2)[2] = _24142;
    RefDS(_58user_library_42905);
    ((intptr_t*)_2)[3] = _58user_library_42905;
    _24143 = MAKE_SEQ(_1);
    _24142 = NOVALUE;
    _24141 = NOVALUE;
    EPrintf(_fh_46345, _24140, _24143);
    DeRefDS(_24140);
    _24140 = NOVALUE;
    DeRefDS(_24143);
    _24143 = NOVALUE;

    /** buildsys.e:741			printf(fh, "\t$(LINKER) @%s.lnk" & HOSTNL, { file0 })*/
    Concat((object_ptr)&_24145, _24144, _46HOSTNL_21937);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_58file0_44851);
    ((intptr_t*)_2)[1] = _58file0_44851;
    _24146 = MAKE_SEQ(_1);
    EPrintf(_fh_46345, _24145, _24146);
    DeRefDS(_24145);
    _24145 = NOVALUE;
    DeRefDS(_24146);
    _24146 = NOVALUE;

    /** buildsys.e:742			if length(rc_file[D_ALTNAME]) and length(settings[SETUP_RC_COMPILER]) then*/
    _2 = (object)SEQ_PTR(_56rc_file_45718);
    _24147 = (object)*(((s1_ptr)_2)->base + 11);
    if (IS_SEQUENCE(_24147)){
            _24148 = SEQ_PTR(_24147)->length;
    }
    else {
        _24148 = 1;
    }
    _24147 = NOVALUE;
    if (_24148 == 0) {
        goto L4; // [215] 277
    }
    _2 = (object)SEQ_PTR(_settings_46342);
    _24150 = (object)*(((s1_ptr)_2)->base + 8);
    if (IS_SEQUENCE(_24150)){
            _24151 = SEQ_PTR(_24150)->length;
    }
    else {
        _24151 = 1;
    }
    _24150 = NOVALUE;
    if (_24151 == 0)
    {
        _24151 = NOVALUE;
        goto L4; // [227] 277
    }
    else{
        _24151 = NOVALUE;
    }

    /** buildsys.e:743				writef(fh, "\t" & settings[SETUP_RC_COMPILER], { rc_file[D_ALTNAME], res_file[D_ALTNAME], exe_name[D_ALTNAME] })*/
    _2 = (object)SEQ_PTR(_settings_46342);
    _24153 = (object)*(((s1_ptr)_2)->base + 8);
    if (IS_SEQUENCE(_24152) && IS_ATOM(_24153)) {
        Ref(_24153);
        Append(&_24154, _24152, _24153);
    }
    else if (IS_ATOM(_24152) && IS_SEQUENCE(_24153)) {
    }
    else {
        Concat((object_ptr)&_24154, _24152, _24153);
    }
    _24153 = NOVALUE;
    _2 = (object)SEQ_PTR(_56rc_file_45718);
    _24155 = (object)*(((s1_ptr)_2)->base + 11);
    _2 = (object)SEQ_PTR(_56res_file_45724);
    _24156 = (object)*(((s1_ptr)_2)->base + 11);
    _2 = (object)SEQ_PTR(_56exe_name_45712);
    _24157 = (object)*(((s1_ptr)_2)->base + 11);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_24155);
    ((intptr_t*)_2)[1] = _24155;
    Ref(_24156);
    ((intptr_t*)_2)[2] = _24156;
    Ref(_24157);
    ((intptr_t*)_2)[3] = _24157;
    _24158 = MAKE_SEQ(_1);
    _24157 = NOVALUE;
    _24156 = NOVALUE;
    _24155 = NOVALUE;
    _8writef(_fh_46345, _24154, _24158, 0);
    _24154 = NOVALUE;
    _24158 = NOVALUE;
L4: 

    /** buildsys.e:745			puts(fh, HOSTNL)*/
    EPuts(_fh_46345, _46HOSTNL_21937); // DJP 

    /** buildsys.e:746			printf(fh, "%s-clean : .SYMBOLIC" & HOSTNL, { file0 })*/
    Concat((object_ptr)&_24160, _24159, _46HOSTNL_21937);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_58file0_44851);
    ((intptr_t*)_2)[1] = _58file0_44851;
    _24161 = MAKE_SEQ(_1);
    EPrintf(_fh_46345, _24160, _24161);
    DeRefDS(_24160);
    _24160 = NOVALUE;
    DeRefDS(_24161);
    _24161 = NOVALUE;

    /** buildsys.e:747			if length(res_file[D_ALTNAME]) then*/
    _2 = (object)SEQ_PTR(_56res_file_45724);
    _24162 = (object)*(((s1_ptr)_2)->base + 11);
    if (IS_SEQUENCE(_24162)){
            _24163 = SEQ_PTR(_24162)->length;
    }
    else {
        _24163 = 1;
    }
    _24162 = NOVALUE;
    if (_24163 == 0)
    {
        _24163 = NOVALUE;
        goto L5; // [315] 343
    }
    else{
        _24163 = NOVALUE;
    }

    /** buildsys.e:748				printf(fh, "\tdel \"%s\"" & HOSTNL, { res_file[D_ALTNAME] })*/
    Concat((object_ptr)&_24165, _24164, _46HOSTNL_21937);
    _2 = (object)SEQ_PTR(_56res_file_45724);
    _24166 = (object)*(((s1_ptr)_2)->base + 11);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_24166);
    ((intptr_t*)_2)[1] = _24166;
    _24167 = MAKE_SEQ(_1);
    _24166 = NOVALUE;
    EPrintf(_fh_46345, _24165, _24167);
    DeRefDS(_24165);
    _24165 = NOVALUE;
    DeRefDS(_24167);
    _24167 = NOVALUE;
L5: 

    /** buildsys.e:750			for i = 1 to length(generated_files) do*/
    if (IS_SEQUENCE(_58generated_files_42897)){
            _24168 = SEQ_PTR(_58generated_files_42897)->length;
    }
    else {
        _24168 = 1;
    }
    {
        object _i_46427;
        _i_46427 = 1;
L6: 
        if (_i_46427 > _24168){
            goto L7; // [350] 403
        }

        /** buildsys.e:751				if match(".o", generated_files[i]) then*/
        _2 = (object)SEQ_PTR(_58generated_files_42897);
        _24169 = (object)*(((s1_ptr)_2)->base + _i_46427);
        _24170 = e_match_from(_23336, _24169, 1);
        _24169 = NOVALUE;
        if (_24170 == 0)
        {
            _24170 = NOVALUE;
            goto L8; // [370] 396
        }
        else{
            _24170 = NOVALUE;
        }

        /** buildsys.e:752					printf(fh, "\tdel \"%s\"" & HOSTNL, { generated_files[i] })*/
        Concat((object_ptr)&_24171, _24164, _46HOSTNL_21937);
        _2 = (object)SEQ_PTR(_58generated_files_42897);
        _24172 = (object)*(((s1_ptr)_2)->base + _i_46427);
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_24172);
        ((intptr_t*)_2)[1] = _24172;
        _24173 = MAKE_SEQ(_1);
        _24172 = NOVALUE;
        EPrintf(_fh_46345, _24171, _24173);
        DeRefDS(_24171);
        _24171 = NOVALUE;
        DeRefDS(_24173);
        _24173 = NOVALUE;
L8: 

        /** buildsys.e:754			end for*/
        _i_46427 = _i_46427 + 1;
        goto L6; // [398] 357
L7: 
        ;
    }

    /** buildsys.e:755			puts(fh, HOSTNL)*/
    EPuts(_fh_46345, _46HOSTNL_21937); // DJP 

    /** buildsys.e:756			printf(fh, "%s-clean-all : .SYMBOLIC" & HOSTNL, { file0 })*/
    Concat((object_ptr)&_24175, _24174, _46HOSTNL_21937);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_58file0_44851);
    ((intptr_t*)_2)[1] = _58file0_44851;
    _24176 = MAKE_SEQ(_1);
    EPrintf(_fh_46345, _24175, _24176);
    DeRefDS(_24175);
    _24175 = NOVALUE;
    DeRefDS(_24176);
    _24176 = NOVALUE;

    /** buildsys.e:757			printf(fh, "\tdel \"%s\"" & HOSTNL, { exe_name[D_ALTNAME] })*/
    Concat((object_ptr)&_24177, _24164, _46HOSTNL_21937);
    _2 = (object)SEQ_PTR(_56exe_name_45712);
    _24178 = (object)*(((s1_ptr)_2)->base + 11);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_24178);
    ((intptr_t*)_2)[1] = _24178;
    _24179 = MAKE_SEQ(_1);
    _24178 = NOVALUE;
    EPrintf(_fh_46345, _24177, _24179);
    DeRefDS(_24177);
    _24177 = NOVALUE;
    DeRefDS(_24179);
    _24179 = NOVALUE;

    /** buildsys.e:758			if length(res_file[D_ALTNAME]) then*/
    _2 = (object)SEQ_PTR(_56res_file_45724);
    _24180 = (object)*(((s1_ptr)_2)->base + 11);
    if (IS_SEQUENCE(_24180)){
            _24181 = SEQ_PTR(_24180)->length;
    }
    else {
        _24181 = 1;
    }
    _24180 = NOVALUE;
    if (_24181 == 0)
    {
        _24181 = NOVALUE;
        goto L9; // [465] 493
    }
    else{
        _24181 = NOVALUE;
    }

    /** buildsys.e:759				printf(fh, "\tdel \"%s\"" & HOSTNL, { res_file[D_ALTNAME] })*/
    Concat((object_ptr)&_24182, _24164, _46HOSTNL_21937);
    _2 = (object)SEQ_PTR(_56res_file_45724);
    _24183 = (object)*(((s1_ptr)_2)->base + 11);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_24183);
    ((intptr_t*)_2)[1] = _24183;
    _24184 = MAKE_SEQ(_1);
    _24183 = NOVALUE;
    EPrintf(_fh_46345, _24182, _24184);
    DeRefDS(_24182);
    _24182 = NOVALUE;
    DeRefDS(_24184);
    _24184 = NOVALUE;
L9: 

    /** buildsys.e:761			for i = 1 to length(generated_files) do*/
    if (IS_SEQUENCE(_58generated_files_42897)){
            _24185 = SEQ_PTR(_58generated_files_42897)->length;
    }
    else {
        _24185 = 1;
    }
    {
        object _i_46460;
        _i_46460 = 1;
LA: 
        if (_i_46460 > _24185){
            goto LB; // [500] 536
        }

        /** buildsys.e:762				printf(fh, "\tdel \"%s\"" & HOSTNL, { generated_files[i] })*/
        Concat((object_ptr)&_24186, _24164, _46HOSTNL_21937);
        _2 = (object)SEQ_PTR(_58generated_files_42897);
        _24187 = (object)*(((s1_ptr)_2)->base + _i_46460);
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_24187);
        ((intptr_t*)_2)[1] = _24187;
        _24188 = MAKE_SEQ(_1);
        _24187 = NOVALUE;
        EPrintf(_fh_46345, _24186, _24188);
        DeRefDS(_24186);
        _24186 = NOVALUE;
        DeRefDS(_24188);
        _24188 = NOVALUE;

        /** buildsys.e:763			end for*/
        _i_46460 = _i_46460 + 1;
        goto LA; // [531] 507
LB: 
        ;
    }

    /** buildsys.e:764			puts(fh, HOSTNL)*/
    EPuts(_fh_46345, _46HOSTNL_21937); // DJP 

    /** buildsys.e:765			puts(fh, ".c.obj : .autodepend" & HOSTNL)*/
    Concat((object_ptr)&_24190, _24189, _46HOSTNL_21937);
    EPuts(_fh_46345, _24190); // DJP 
    DeRefDS(_24190);
    _24190 = NOVALUE;

    /** buildsys.e:766			puts(fh, "\t$(CC) $(CFLAGS) $<" & HOSTNL)*/
    Concat((object_ptr)&_24192, _24191, _46HOSTNL_21937);
    EPuts(_fh_46345, _24192); // DJP 
    DeRefDS(_24192);
    _24192 = NOVALUE;

    /** buildsys.e:767			puts(fh, HOSTNL)*/
    EPuts(_fh_46345, _46HOSTNL_21937); // DJP 
    goto LC; // [572] 933
L3: 

    /** buildsys.e:770			printf(fh, "RUNTIME_LIBRARY=%s\n", { settings[SETUP_RUNTIME_LIBRARY] } )*/
    _2 = (object)SEQ_PTR(_settings_46342);
    _24194 = (object)*(((s1_ptr)_2)->base + 9);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_24194);
    ((intptr_t*)_2)[1] = _24194;
    _24195 = MAKE_SEQ(_1);
    _24194 = NOVALUE;
    EPrintf(_fh_46345, _24193, _24195);
    DeRefDS(_24195);
    _24195 = NOVALUE;

    /** buildsys.e:771			printf(fh, "%s: $(%s_OBJECTS) $(RUNTIME_LIBRARY) %s " & HOSTNL, { adjust_for_build_file(exe_name[D_ALTNAME]), upper(file0), rc_file[D_ALTNAME] })*/
    Concat((object_ptr)&_24197, _24196, _46HOSTNL_21937);
    _2 = (object)SEQ_PTR(_56exe_name_45712);
    _24198 = (object)*(((s1_ptr)_2)->base + 11);
    Ref(_24198);
    _24199 = _56adjust_for_build_file(_24198);
    _24198 = NOVALUE;
    RefDS(_58file0_44851);
    _24200 = _14upper(_58file0_44851);
    _2 = (object)SEQ_PTR(_56rc_file_45718);
    _24201 = (object)*(((s1_ptr)_2)->base + 11);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _24199;
    ((intptr_t*)_2)[2] = _24200;
    Ref(_24201);
    ((intptr_t*)_2)[3] = _24201;
    _24202 = MAKE_SEQ(_1);
    _24201 = NOVALUE;
    _24200 = NOVALUE;
    _24199 = NOVALUE;
    EPrintf(_fh_46345, _24197, _24202);
    DeRefDS(_24197);
    _24197 = NOVALUE;
    DeRefDS(_24202);
    _24202 = NOVALUE;

    /** buildsys.e:772			if length(rc_file[D_ALTNAME]) then*/
    _2 = (object)SEQ_PTR(_56rc_file_45718);
    _24203 = (object)*(((s1_ptr)_2)->base + 11);
    if (IS_SEQUENCE(_24203)){
            _24204 = SEQ_PTR(_24203)->length;
    }
    else {
        _24204 = 1;
    }
    _24203 = NOVALUE;
    if (_24204 == 0)
    {
        _24204 = NOVALUE;
        goto LD; // [646] 690
    }
    else{
        _24204 = NOVALUE;
    }

    /** buildsys.e:773				writef(fh, "\t" & settings[SETUP_RC_COMPILER] & HOSTNL, { rc_file[D_ALTNAME], res_file[D_ALTNAME] })*/
    _2 = (object)SEQ_PTR(_settings_46342);
    _24205 = (object)*(((s1_ptr)_2)->base + 8);
    {
        object concat_list[3];

        concat_list[0] = _46HOSTNL_21937;
        concat_list[1] = _24205;
        concat_list[2] = _24152;
        Concat_N((object_ptr)&_24206, concat_list, 3);
    }
    _24205 = NOVALUE;
    _2 = (object)SEQ_PTR(_56rc_file_45718);
    _24207 = (object)*(((s1_ptr)_2)->base + 11);
    _2 = (object)SEQ_PTR(_56res_file_45724);
    _24208 = (object)*(((s1_ptr)_2)->base + 11);
    Ref(_24208);
    Ref(_24207);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _24207;
    ((intptr_t *)_2)[2] = _24208;
    _24209 = MAKE_SEQ(_1);
    _24208 = NOVALUE;
    _24207 = NOVALUE;
    _8writef(_fh_46345, _24206, _24209, 0);
    _24206 = NOVALUE;
    _24209 = NOVALUE;
LD: 

    /** buildsys.e:775			printf(fh, "\t$(LINKER) -o %s $(%s_OBJECTS) %s $(LFLAGS)" & HOSTNL, {*/
    Concat((object_ptr)&_24211, _24210, _46HOSTNL_21937);
    _2 = (object)SEQ_PTR(_56exe_name_45712);
    _24212 = (object)*(((s1_ptr)_2)->base + 11);
    RefDS(_58file0_44851);
    _24213 = _14upper(_58file0_44851);
    _2 = (object)SEQ_PTR(_56res_file_45724);
    _24214 = (object)*(((s1_ptr)_2)->base + 11);
    if (IS_SEQUENCE(_24214)){
            _24215 = SEQ_PTR(_24214)->length;
    }
    else {
        _24215 = 1;
    }
    _24214 = NOVALUE;
    _2 = (object)SEQ_PTR(_56res_file_45724);
    _24216 = (object)*(((s1_ptr)_2)->base + 11);
    Ref(_24216);
    RefDS(_22190);
    _24217 = _57iif(_24215, _24216, _22190);
    _24215 = NOVALUE;
    _24216 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_24212);
    ((intptr_t*)_2)[1] = _24212;
    ((intptr_t*)_2)[2] = _24213;
    ((intptr_t*)_2)[3] = _24217;
    _24218 = MAKE_SEQ(_1);
    _24217 = NOVALUE;
    _24213 = NOVALUE;
    _24212 = NOVALUE;
    EPrintf(_fh_46345, _24211, _24218);
    DeRefDS(_24211);
    _24211 = NOVALUE;
    DeRefDS(_24218);
    _24218 = NOVALUE;

    /** buildsys.e:777			puts(fh, HOSTNL)*/
    EPuts(_fh_46345, _46HOSTNL_21937); // DJP 

    /** buildsys.e:778			printf(fh, ".PHONY: %s-clean %s-clean-all" & HOSTNL, { file0, file0 })*/
    Concat((object_ptr)&_24220, _24219, _46HOSTNL_21937);
    RefDS(_58file0_44851);
    RefDS(_58file0_44851);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _58file0_44851;
    ((intptr_t *)_2)[2] = _58file0_44851;
    _24221 = MAKE_SEQ(_1);
    EPrintf(_fh_46345, _24220, _24221);
    DeRefDS(_24220);
    _24220 = NOVALUE;
    DeRefDS(_24221);
    _24221 = NOVALUE;

    /** buildsys.e:779			puts(fh, HOSTNL)*/
    EPuts(_fh_46345, _46HOSTNL_21937); // DJP 

    /** buildsys.e:780			printf(fh, "%s-clean:" & HOSTNL, { file0 })*/
    Concat((object_ptr)&_24223, _24222, _46HOSTNL_21937);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_58file0_44851);
    ((intptr_t*)_2)[1] = _58file0_44851;
    _24224 = MAKE_SEQ(_1);
    EPrintf(_fh_46345, _24223, _24224);
    DeRefDS(_24223);
    _24223 = NOVALUE;
    DeRefDS(_24224);
    _24224 = NOVALUE;

    /** buildsys.e:781			printf(fh, "\trm -rf $(%s_OBJECTS) %s" & HOSTNL, { upper(file0), res_file[D_ALTNAME] })*/
    Concat((object_ptr)&_24226, _24225, _46HOSTNL_21937);
    RefDS(_58file0_44851);
    _24227 = _14upper(_58file0_44851);
    _2 = (object)SEQ_PTR(_56res_file_45724);
    _24228 = (object)*(((s1_ptr)_2)->base + 11);
    Ref(_24228);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _24227;
    ((intptr_t *)_2)[2] = _24228;
    _24229 = MAKE_SEQ(_1);
    _24228 = NOVALUE;
    _24227 = NOVALUE;
    EPrintf(_fh_46345, _24226, _24229);
    DeRefDS(_24226);
    _24226 = NOVALUE;
    DeRefDS(_24229);
    _24229 = NOVALUE;

    /** buildsys.e:782			puts(fh, HOSTNL)*/
    EPuts(_fh_46345, _46HOSTNL_21937); // DJP 

    /** buildsys.e:783			printf(fh, "%s-clean-all: %s-clean" & HOSTNL, { file0, file0 })*/
    Concat((object_ptr)&_24231, _24230, _46HOSTNL_21937);
    RefDS(_58file0_44851);
    RefDS(_58file0_44851);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _58file0_44851;
    ((intptr_t *)_2)[2] = _58file0_44851;
    _24232 = MAKE_SEQ(_1);
    EPrintf(_fh_46345, _24231, _24232);
    DeRefDS(_24231);
    _24231 = NOVALUE;
    DeRefDS(_24232);
    _24232 = NOVALUE;

    /** buildsys.e:784			printf(fh, "\trm -rf $(%s_SOURCES) %s %s" & HOSTNL, { upper(file0), res_file[D_ALTNAME], exe_name[D_ALTNAME] })*/
    Concat((object_ptr)&_24234, _24233, _46HOSTNL_21937);
    RefDS(_58file0_44851);
    _24235 = _14upper(_58file0_44851);
    _2 = (object)SEQ_PTR(_56res_file_45724);
    _24236 = (object)*(((s1_ptr)_2)->base + 11);
    _2 = (object)SEQ_PTR(_56exe_name_45712);
    _24237 = (object)*(((s1_ptr)_2)->base + 11);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _24235;
    Ref(_24236);
    ((intptr_t*)_2)[2] = _24236;
    Ref(_24237);
    ((intptr_t*)_2)[3] = _24237;
    _24238 = MAKE_SEQ(_1);
    _24237 = NOVALUE;
    _24236 = NOVALUE;
    _24235 = NOVALUE;
    EPrintf(_fh_46345, _24234, _24238);
    DeRefDS(_24234);
    _24234 = NOVALUE;
    DeRefDS(_24238);
    _24238 = NOVALUE;

    /** buildsys.e:785			puts(fh, HOSTNL)*/
    EPuts(_fh_46345, _46HOSTNL_21937); // DJP 

    /** buildsys.e:786			puts(fh, "%.o: %.c" & HOSTNL)*/
    Concat((object_ptr)&_24240, _24239, _46HOSTNL_21937);
    EPuts(_fh_46345, _24240); // DJP 
    DeRefDS(_24240);
    _24240 = NOVALUE;

    /** buildsys.e:787			puts(fh, "\t$(CC) $(CFLAGS) $*.c -o $*.o" & HOSTNL)*/
    Concat((object_ptr)&_24242, _24241, _46HOSTNL_21937);
    EPuts(_fh_46345, _24242); // DJP 
    DeRefDS(_24242);
    _24242 = NOVALUE;

    /** buildsys.e:788			puts(fh, HOSTNL)*/
    EPuts(_fh_46345, _46HOSTNL_21937); // DJP 
LC: 

    /** buildsys.e:791		close(fh)*/
    EClose(_fh_46345);

    /** buildsys.e:792	end procedure*/
    DeRef(_settings_46342);
    _24180 = NOVALUE;
    _24150 = NOVALUE;
    _24214 = NOVALUE;
    _24147 = NOVALUE;
    _24203 = NOVALUE;
    _24162 = NOVALUE;
    return;
    ;
}


void _56write_makefile_partial()
{
    object _settings_46571 = NOVALUE;
    object _fh_46573 = NOVALUE;
    object _24244 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:798		sequence settings = setup_build()*/
    _0 = _settings_46571;
    _settings_46571 = _56setup_build();
    DeRef(_0);

    /** buildsys.e:799		integer fh = open(output_dir & file0 & ".mak", "wb")*/
    {
        object concat_list[3];

        concat_list[0] = _24118;
        concat_list[1] = _58file0_44851;
        concat_list[2] = _58output_dir_42907;
        Concat_N((object_ptr)&_24244, concat_list, 3);
    }
    _fh_46573 = EOpen(_24244, _24036, 0);
    DeRefDS(_24244);
    _24244 = NOVALUE;

    /** buildsys.e:801		write_makefile_srcobj_list(fh)*/
    _56write_makefile_srcobj_list(_fh_46573);

    /** buildsys.e:803		close(fh)*/
    EClose(_fh_46573);

    /** buildsys.e:804	end procedure*/
    DeRefDS(_settings_46571);
    return;
    ;
}


void _56build_direct(object _link_only_46580, object _the_file0_46581)
{
    object _cmd_46587 = NOVALUE;
    object _objs_46588 = NOVALUE;
    object _settings_46589 = NOVALUE;
    object _cwd_46591 = NOVALUE;
    object _status_46594 = NOVALUE;
    object _link_files_46625 = NOVALUE;
    object _pdone_46651 = NOVALUE;
    object _files_46702 = NOVALUE;
    object _31980 = NOVALUE;
    object _31979 = NOVALUE;
    object _31978 = NOVALUE;
    object _31977 = NOVALUE;
    object _31976 = NOVALUE;
    object _31975 = NOVALUE;
    object _31974 = NOVALUE;
    object _24392 = NOVALUE;
    object _24391 = NOVALUE;
    object _24389 = NOVALUE;
    object _24388 = NOVALUE;
    object _24387 = NOVALUE;
    object _24386 = NOVALUE;
    object _24385 = NOVALUE;
    object _24384 = NOVALUE;
    object _24383 = NOVALUE;
    object _24382 = NOVALUE;
    object _24380 = NOVALUE;
    object _24379 = NOVALUE;
    object _24378 = NOVALUE;
    object _24377 = NOVALUE;
    object _24373 = NOVALUE;
    object _24372 = NOVALUE;
    object _24371 = NOVALUE;
    object _24370 = NOVALUE;
    object _24369 = NOVALUE;
    object _24368 = NOVALUE;
    object _24367 = NOVALUE;
    object _24366 = NOVALUE;
    object _24365 = NOVALUE;
    object _24364 = NOVALUE;
    object _24363 = NOVALUE;
    object _24362 = NOVALUE;
    object _24361 = NOVALUE;
    object _24360 = NOVALUE;
    object _24359 = NOVALUE;
    object _24356 = NOVALUE;
    object _24355 = NOVALUE;
    object _24354 = NOVALUE;
    object _24353 = NOVALUE;
    object _24350 = NOVALUE;
    object _24348 = NOVALUE;
    object _24347 = NOVALUE;
    object _24346 = NOVALUE;
    object _24345 = NOVALUE;
    object _24344 = NOVALUE;
    object _24343 = NOVALUE;
    object _24340 = NOVALUE;
    object _24339 = NOVALUE;
    object _24335 = NOVALUE;
    object _24334 = NOVALUE;
    object _24333 = NOVALUE;
    object _24329 = NOVALUE;
    object _24328 = NOVALUE;
    object _24327 = NOVALUE;
    object _24326 = NOVALUE;
    object _24325 = NOVALUE;
    object _24324 = NOVALUE;
    object _24323 = NOVALUE;
    object _24322 = NOVALUE;
    object _24321 = NOVALUE;
    object _24320 = NOVALUE;
    object _24319 = NOVALUE;
    object _24318 = NOVALUE;
    object _24316 = NOVALUE;
    object _24315 = NOVALUE;
    object _24314 = NOVALUE;
    object _24313 = NOVALUE;
    object _24312 = NOVALUE;
    object _24310 = NOVALUE;
    object _24309 = NOVALUE;
    object _24308 = NOVALUE;
    object _24307 = NOVALUE;
    object _24306 = NOVALUE;
    object _24304 = NOVALUE;
    object _24302 = NOVALUE;
    object _24301 = NOVALUE;
    object _24300 = NOVALUE;
    object _24299 = NOVALUE;
    object _24297 = NOVALUE;
    object _24296 = NOVALUE;
    object _24295 = NOVALUE;
    object _24292 = NOVALUE;
    object _24291 = NOVALUE;
    object _24290 = NOVALUE;
    object _24289 = NOVALUE;
    object _24288 = NOVALUE;
    object _24287 = NOVALUE;
    object _24286 = NOVALUE;
    object _24285 = NOVALUE;
    object _24284 = NOVALUE;
    object _24283 = NOVALUE;
    object _24280 = NOVALUE;
    object _24279 = NOVALUE;
    object _24276 = NOVALUE;
    object _24274 = NOVALUE;
    object _24273 = NOVALUE;
    object _24272 = NOVALUE;
    object _24271 = NOVALUE;
    object _24268 = NOVALUE;
    object _24267 = NOVALUE;
    object _24266 = NOVALUE;
    object _24265 = NOVALUE;
    object _24263 = NOVALUE;
    object _24262 = NOVALUE;
    object _24261 = NOVALUE;
    object _24260 = NOVALUE;
    object _24259 = NOVALUE;
    object _24256 = NOVALUE;
    object _24250 = NOVALUE;
    object _24246 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:810		if length(the_file0) then*/
    if (IS_SEQUENCE(_the_file0_46581)){
            _24246 = SEQ_PTR(_the_file0_46581)->length;
    }
    else {
        _24246 = 1;
    }
    if (_24246 == 0)
    {
        _24246 = NOVALUE;
        goto L1; // [10] 22
    }
    else{
        _24246 = NOVALUE;
    }

    /** buildsys.e:811			file0 = filebase(the_file0)*/
    RefDS(_the_file0_46581);
    _0 = _17filebase(_the_file0_46581);
    DeRef(_58file0_44851);
    _58file0_44851 = _0;
L1: 

    /** buildsys.e:813		sequence cmd, objs = "", settings = setup_build(), cwd = current_dir()*/
    RefDS(_22190);
    DeRef(_objs_46588);
    _objs_46588 = _22190;
    _0 = _settings_46589;
    _settings_46589 = _56setup_build();
    DeRef(_0);
    _0 = _cwd_46591;
    _cwd_46591 = _17current_dir();
    DeRef(_0);

    /** buildsys.e:814		integer status*/

    /** buildsys.e:816		ensure_exename(settings[SETUP_EXE_EXT])*/
    _2 = (object)SEQ_PTR(_settings_46589);
    _24250 = (object)*(((s1_ptr)_2)->base + 6);
    Ref(_24250);
    _56ensure_exename(_24250);
    _24250 = NOVALUE;

    /** buildsys.e:818		if not link_only then*/
    if (_link_only_46580 != 0)
    goto L2; // [52] 124

    /** buildsys.e:819			switch compiler_type do*/
    _0 = _56compiler_type_45709;
    switch ( _0 ){ 

        /** buildsys.e:820				case COMPILER_GCC then*/
        case 1:

        /** buildsys.e:821					if not silent then*/
        if (_36silent_21886 != 0)
        goto L3; // [72] 123

        /** buildsys.e:822						ShowMsg(1, COMPILING_WITH_1, {"GCC"})*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_24255);
        ((intptr_t*)_2)[1] = _24255;
        _24256 = MAKE_SEQ(_1);
        _39ShowMsg(1, 176, _24256, 1);
        _24256 = NOVALUE;
        goto L3; // [90] 123

        /** buildsys.e:825				case COMPILER_WATCOM then*/
        case 2:

        /** buildsys.e:826					write_objlink_file()*/
        _56write_objlink_file();

        /** buildsys.e:828					if not silent then*/
        if (_36silent_21886 != 0)
        goto L4; // [104] 122

        /** buildsys.e:829						ShowMsg(1, COMPILING_WITH_1, {"Watcom"})*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_24258);
        ((intptr_t*)_2)[1] = _24258;
        _24259 = MAKE_SEQ(_1);
        _39ShowMsg(1, 176, _24259, 1);
        _24259 = NOVALUE;
L4: 
    ;}L3: 
L2: 

    /** buildsys.e:834		if sequence(output_dir) and length(output_dir) > 0 then*/
    _24260 = 1;
    if (_24260 == 0) {
        goto L5; // [131] 159
    }
    if (IS_SEQUENCE(_58output_dir_42907)){
            _24262 = SEQ_PTR(_58output_dir_42907)->length;
    }
    else {
        _24262 = 1;
    }
    _24263 = (_24262 > 0);
    _24262 = NOVALUE;
    if (_24263 == 0)
    {
        DeRef(_24263);
        _24263 = NOVALUE;
        goto L5; // [145] 159
    }
    else{
        DeRef(_24263);
        _24263 = NOVALUE;
    }

    /** buildsys.e:835			chdir(output_dir)*/
    RefDS(_58output_dir_42907);
    _31980 = _17chdir(_58output_dir_42907);
    DeRef(_31980);
    _31980 = NOVALUE;
L5: 

    /** buildsys.e:838		sequence link_files = {}*/
    RefDS(_22190);
    DeRef(_link_files_46625);
    _link_files_46625 = _22190;

    /** buildsys.e:840		if not link_only then*/
    if (_link_only_46580 != 0)
    goto L6; // [168] 482

    /** buildsys.e:841			for i = 1 to length(generated_files) do*/
    if (IS_SEQUENCE(_58generated_files_42897)){
            _24265 = SEQ_PTR(_58generated_files_42897)->length;
    }
    else {
        _24265 = 1;
    }
    {
        object _i_46629;
        _i_46629 = 1;
L7: 
        if (_i_46629 > _24265){
            goto L8; // [178] 479
        }

        /** buildsys.e:842				if generated_files[i][$] = 'c' then*/
        _2 = (object)SEQ_PTR(_58generated_files_42897);
        _24266 = (object)*(((s1_ptr)_2)->base + _i_46629);
        if (IS_SEQUENCE(_24266)){
                _24267 = SEQ_PTR(_24266)->length;
        }
        else {
            _24267 = 1;
        }
        _2 = (object)SEQ_PTR(_24266);
        _24268 = (object)*(((s1_ptr)_2)->base + _24267);
        _24266 = NOVALUE;
        if (binary_op_a(NOTEQ, _24268, 99)){
            _24268 = NOVALUE;
            goto L9; // [200] 438
        }
        _24268 = NOVALUE;

        /** buildsys.e:843					cmd = sprintf("%s %s %s", { settings[SETUP_CEXE], settings[SETUP_CFLAGS],*/
        _2 = (object)SEQ_PTR(_settings_46589);
        _24271 = (object)*(((s1_ptr)_2)->base + 1);
        _2 = (object)SEQ_PTR(_settings_46589);
        _24272 = (object)*(((s1_ptr)_2)->base + 2);
        _2 = (object)SEQ_PTR(_58generated_files_42897);
        _24273 = (object)*(((s1_ptr)_2)->base + _i_46629);
        _1 = NewS1(3);
        _2 = (object)((s1_ptr)_1)->base;
        Ref(_24271);
        ((intptr_t*)_2)[1] = _24271;
        Ref(_24272);
        ((intptr_t*)_2)[2] = _24272;
        RefDS(_24273);
        ((intptr_t*)_2)[3] = _24273;
        _24274 = MAKE_SEQ(_1);
        _24273 = NOVALUE;
        _24272 = NOVALUE;
        _24271 = NOVALUE;
        DeRef(_cmd_46587);
        _cmd_46587 = EPrintf(-9999999, _24270, _24274);
        DeRefDS(_24274);
        _24274 = NOVALUE;

        /** buildsys.e:846					link_files = append(link_files, generated_files[i])*/
        _2 = (object)SEQ_PTR(_58generated_files_42897);
        _24276 = (object)*(((s1_ptr)_2)->base + _i_46629);
        RefDS(_24276);
        Append(&_link_files_46625, _link_files_46625, _24276);
        _24276 = NOVALUE;

        /** buildsys.e:848					if not silent then*/
        if (_36silent_21886 != 0)
        goto LA; // [246] 374

        /** buildsys.e:849						atom pdone = 100 * (i / length(generated_files))*/
        if (IS_SEQUENCE(_58generated_files_42897)){
                _24279 = SEQ_PTR(_58generated_files_42897)->length;
        }
        else {
            _24279 = 1;
        }
        _24280 = (_i_46629 % _24279) ? NewDouble((eudouble)_i_46629 / _24279) : (_i_46629 / _24279);
        _24279 = NOVALUE;
        DeRef(_pdone_46651);
        if (IS_ATOM_INT(_24280)) {
            if (_24280 <= INT15 && _24280 >= -INT15){
                _pdone_46651 = 100 * _24280;
            }
            else{
                _pdone_46651 = NewDouble(100 * (eudouble)_24280);
            }
        }
        else {
            _pdone_46651 = NewDouble((eudouble)100 * DBL_PTR(_24280)->dbl);
        }
        DeRef(_24280);
        _24280 = NOVALUE;

        /** buildsys.e:850						if not verbose then*/
        if (_36verbose_21889 != 0)
        goto LB; // [268] 358

        /** buildsys.e:853							if 0 and outdated_files[i] = 0 and force_build = 0 then*/
        if (0 == 0) {
            _24283 = 0;
            goto LC; // [273] 291
        }
        _2 = (object)SEQ_PTR(_58outdated_files_42898);
        _24284 = (object)*(((s1_ptr)_2)->base + _i_46629);
        if (IS_ATOM_INT(_24284)) {
            _24285 = (_24284 == 0);
        }
        else {
            _24285 = binary_op(EQUALS, _24284, 0);
        }
        _24284 = NOVALUE;
        if (IS_ATOM_INT(_24285))
        _24283 = (_24285 != 0);
        else
        _24283 = DBL_PTR(_24285)->dbl != 0.0;
LC: 
        if (_24283 == 0) {
            goto LD; // [291] 334
        }
        _24287 = (_56force_build_45731 == 0);
        if (_24287 == 0)
        {
            DeRef(_24287);
            _24287 = NOVALUE;
            goto LD; // [302] 334
        }
        else{
            DeRef(_24287);
            _24287 = NOVALUE;
        }

        /** buildsys.e:854								ShowMsg(1, SKIPPING__130_2_UPTODATE, { pdone, generated_files[i] })*/
        _2 = (object)SEQ_PTR(_58generated_files_42897);
        _24288 = (object)*(((s1_ptr)_2)->base + _i_46629);
        RefDS(_24288);
        Ref(_pdone_46651);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _pdone_46651;
        ((intptr_t *)_2)[2] = _24288;
        _24289 = MAKE_SEQ(_1);
        _24288 = NOVALUE;
        _39ShowMsg(1, 325, _24289, 1);
        _24289 = NOVALUE;

        /** buildsys.e:855								continue*/
        DeRef(_pdone_46651);
        _pdone_46651 = NOVALUE;
        goto LE; // [329] 474
        goto LF; // [331] 373
LD: 

        /** buildsys.e:857								ShowMsg(1, COMPILING_130_2, { pdone, generated_files[i] })*/
        _2 = (object)SEQ_PTR(_58generated_files_42897);
        _24290 = (object)*(((s1_ptr)_2)->base + _i_46629);
        RefDS(_24290);
        Ref(_pdone_46651);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _pdone_46651;
        ((intptr_t *)_2)[2] = _24290;
        _24291 = MAKE_SEQ(_1);
        _24290 = NOVALUE;
        _39ShowMsg(1, 163, _24291, 1);
        _24291 = NOVALUE;
        goto LF; // [355] 373
LB: 

        /** buildsys.e:860							ShowMsg(1, COMPILING_130_2, { pdone, cmd })*/
        RefDS(_cmd_46587);
        Ref(_pdone_46651);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _pdone_46651;
        ((intptr_t *)_2)[2] = _cmd_46587;
        _24292 = MAKE_SEQ(_1);
        _39ShowMsg(1, 163, _24292, 1);
        _24292 = NOVALUE;
LF: 
LA: 
        DeRef(_pdone_46651);
        _pdone_46651 = NOVALUE;

        /** buildsys.e:865					status = system_exec(cmd, 0)*/
        _status_46594 = system_exec_call(_cmd_46587, 0);

        /** buildsys.e:866					if status != 0 then*/
        if (_status_46594 == 0)
        goto L10; // [384] 472

        /** buildsys.e:867						ShowMsg(2, COULDNT_COMPILE_FILE_1, { generated_files[i] })*/
        _2 = (object)SEQ_PTR(_58generated_files_42897);
        _24295 = (object)*(((s1_ptr)_2)->base + _i_46629);
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_24295);
        ((intptr_t*)_2)[1] = _24295;
        _24296 = MAKE_SEQ(_1);
        _24295 = NOVALUE;
        _39ShowMsg(2, 164, _24296, 1);
        _24296 = NOVALUE;

        /** buildsys.e:868						ShowMsg(2, STATUS_1_COMMAND_2, { status, cmd })*/
        RefDS(_cmd_46587);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _status_46594;
        ((intptr_t *)_2)[2] = _cmd_46587;
        _24297 = MAKE_SEQ(_1);
        _39ShowMsg(2, 165, _24297, 1);
        _24297 = NOVALUE;

        /** buildsys.e:869						goto "build_direct_cleanup"*/
        goto G11;
        goto L10; // [435] 472
L9: 

        /** buildsys.e:871				elsif match(".o", generated_files[i]) then*/
        _2 = (object)SEQ_PTR(_58generated_files_42897);
        _24299 = (object)*(((s1_ptr)_2)->base + _i_46629);
        _24300 = e_match_from(_23336, _24299, 1);
        _24299 = NOVALUE;
        if (_24300 == 0)
        {
            _24300 = NOVALUE;
            goto L12; // [451] 471
        }
        else{
            _24300 = NOVALUE;
        }

        /** buildsys.e:872					objs &= " " & generated_files[i]*/
        _2 = (object)SEQ_PTR(_58generated_files_42897);
        _24301 = (object)*(((s1_ptr)_2)->base + _i_46629);
        Concat((object_ptr)&_24302, _23576, _24301);
        _24301 = NOVALUE;
        Concat((object_ptr)&_objs_46588, _objs_46588, _24302);
        DeRefDS(_24302);
        _24302 = NOVALUE;
L12: 
L10: 

        /** buildsys.e:874			end for*/
LE: 
        _i_46629 = _i_46629 + 1;
        goto L7; // [474] 185
L8: 
        ;
    }
    goto L13; // [479] 541
L6: 

    /** buildsys.e:876			object files = read_lines(file0 & ".bld")*/
    Concat((object_ptr)&_24304, _58file0_44851, _23786);
    _0 = _files_46702;
    _files_46702 = _8read_lines(_24304);
    DeRef(_0);
    _24304 = NOVALUE;

    /** buildsys.e:877			for i = 1 to length(files) do*/
    if (IS_SEQUENCE(_files_46702)){
            _24306 = SEQ_PTR(_files_46702)->length;
    }
    else {
        _24306 = 1;
    }
    {
        object _i_46708;
        _i_46708 = 1;
L14: 
        if (_i_46708 > _24306){
            goto L15; // [499] 538
        }

        /** buildsys.e:878				objs &= " " & filebase(files[i]) & "." & settings[SETUP_OBJ_EXT]*/
        _2 = (object)SEQ_PTR(_files_46702);
        _24307 = (object)*(((s1_ptr)_2)->base + _i_46708);
        Ref(_24307);
        _24308 = _17filebase(_24307);
        _24307 = NOVALUE;
        _2 = (object)SEQ_PTR(_settings_46589);
        _24309 = (object)*(((s1_ptr)_2)->base + 5);
        {
            object concat_list[4];

            concat_list[0] = _24309;
            concat_list[1] = _23375;
            concat_list[2] = _24308;
            concat_list[3] = _23576;
            Concat_N((object_ptr)&_24310, concat_list, 4);
        }
        _24309 = NOVALUE;
        DeRef(_24308);
        _24308 = NOVALUE;
        Concat((object_ptr)&_objs_46588, _objs_46588, _24310);
        DeRefDS(_24310);
        _24310 = NOVALUE;

        /** buildsys.e:879			end for*/
        _i_46708 = _i_46708 + 1;
        goto L14; // [533] 506
L15: 
        ;
    }
    DeRef(_files_46702);
    _files_46702 = NOVALUE;
L13: 

    /** buildsys.e:882		if keep and not link_only and length(link_files) then*/
    if (_58keep_42900 == 0) {
        _24312 = 0;
        goto L16; // [545] 556
    }
    _24313 = (_link_only_46580 == 0);
    _24312 = (_24313 != 0);
L16: 
    if (_24312 == 0) {
        goto L17; // [556] 585
    }
    if (IS_SEQUENCE(_link_files_46625)){
            _24315 = SEQ_PTR(_link_files_46625)->length;
    }
    else {
        _24315 = 1;
    }
    if (_24315 == 0)
    {
        _24315 = NOVALUE;
        goto L17; // [564] 585
    }
    else{
        _24315 = NOVALUE;
    }

    /** buildsys.e:883			write_lines(file0 & ".bld", link_files)*/
    Concat((object_ptr)&_24316, _58file0_44851, _23786);
    RefDS(_link_files_46625);
    _31979 = _8write_lines(_24316, _link_files_46625);
    _24316 = NOVALUE;
    DeRef(_31979);
    _31979 = NOVALUE;
    goto L18; // [582] 609
L17: 

    /** buildsys.e:884		elsif keep = 0 then*/
    if (_58keep_42900 != 0)
    goto L19; // [589] 608

    /** buildsys.e:886			delete_file(file0 & ".bld")*/
    Concat((object_ptr)&_24318, _58file0_44851, _23786);
    _31978 = _17delete_file(_24318);
    _24318 = NOVALUE;
    DeRef(_31978);
    _31978 = NOVALUE;
L19: 
L18: 

    /** buildsys.e:890		if length(rc_file[D_ALTNAME]) and length(settings[SETUP_RC_COMPILER]) and compiler_type = COMPILER_GCC then*/
    _2 = (object)SEQ_PTR(_56rc_file_45718);
    _24319 = (object)*(((s1_ptr)_2)->base + 11);
    if (IS_SEQUENCE(_24319)){
            _24320 = SEQ_PTR(_24319)->length;
    }
    else {
        _24320 = 1;
    }
    _24319 = NOVALUE;
    if (_24320 == 0) {
        _24321 = 0;
        goto L1A; // [622] 637
    }
    _2 = (object)SEQ_PTR(_settings_46589);
    _24322 = (object)*(((s1_ptr)_2)->base + 8);
    if (IS_SEQUENCE(_24322)){
            _24323 = SEQ_PTR(_24322)->length;
    }
    else {
        _24323 = 1;
    }
    _24322 = NOVALUE;
    _24321 = (_24323 != 0);
L1A: 
    if (_24321 == 0) {
        goto L1B; // [637] 742
    }
    _24325 = (_56compiler_type_45709 == 1);
    if (_24325 == 0)
    {
        DeRef(_24325);
        _24325 = NOVALUE;
        goto L1B; // [648] 742
    }
    else{
        DeRef(_24325);
        _24325 = NOVALUE;
    }

    /** buildsys.e:891			cmd = text:format(settings[SETUP_RC_COMPILER], { rc_file[D_ALTNAME], res_file[D_ALTNAME] })*/
    _2 = (object)SEQ_PTR(_settings_46589);
    _24326 = (object)*(((s1_ptr)_2)->base + 8);
    _2 = (object)SEQ_PTR(_56rc_file_45718);
    _24327 = (object)*(((s1_ptr)_2)->base + 11);
    _2 = (object)SEQ_PTR(_56res_file_45724);
    _24328 = (object)*(((s1_ptr)_2)->base + 11);
    Ref(_24328);
    Ref(_24327);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _24327;
    ((intptr_t *)_2)[2] = _24328;
    _24329 = MAKE_SEQ(_1);
    _24328 = NOVALUE;
    _24327 = NOVALUE;
    Ref(_24326);
    _0 = _cmd_46587;
    _cmd_46587 = _14format(_24326, _24329);
    DeRef(_0);
    _24326 = NOVALUE;
    _24329 = NOVALUE;

    /** buildsys.e:892			status = system_exec(cmd, 0)*/
    _status_46594 = system_exec_call(_cmd_46587, 0);

    /** buildsys.e:893			if status != 0 then*/
    if (_status_46594 == 0)
    goto L1C; // [692] 741

    /** buildsys.e:894				ShowMsg(2, UNABLE_TO_COMPILE_RESOURCE_FILE_1, { rc_file[D_NAME] })*/
    _2 = (object)SEQ_PTR(_56rc_file_45718);
    _24333 = (object)*(((s1_ptr)_2)->base + 1);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_24333);
    ((intptr_t*)_2)[1] = _24333;
    _24334 = MAKE_SEQ(_1);
    _24333 = NOVALUE;
    _39ShowMsg(2, 350, _24334, 1);
    _24334 = NOVALUE;

    /** buildsys.e:895				ShowMsg(2, STATUS_1_COMMAND_2_A, { status, cmd })*/
    RefDS(_cmd_46587);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _status_46594;
    ((intptr_t *)_2)[2] = _cmd_46587;
    _24335 = MAKE_SEQ(_1);
    _39ShowMsg(2, 169, _24335, 1);
    _24335 = NOVALUE;

    /** buildsys.e:897				goto "build_direct_cleanup"*/
    goto G11;
L1C: 
L1B: 

    /** buildsys.e:901		switch compiler_type do*/
    _0 = _56compiler_type_45709;
    switch ( _0 ){ 

        /** buildsys.e:902			case COMPILER_WATCOM then*/
        case 2:

        /** buildsys.e:903				cmd = sprintf("%s @%s.lnk", { settings[SETUP_LEXE], file0 })*/
        _2 = (object)SEQ_PTR(_settings_46589);
        _24339 = (object)*(((s1_ptr)_2)->base + 3);
        RefDS(_58file0_44851);
        Ref(_24339);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _24339;
        ((intptr_t *)_2)[2] = _58file0_44851;
        _24340 = MAKE_SEQ(_1);
        _24339 = NOVALUE;
        DeRef(_cmd_46587);
        _cmd_46587 = EPrintf(-9999999, _24338, _24340);
        DeRefDS(_24340);
        _24340 = NOVALUE;
        goto L1D; // [771] 848

        /** buildsys.e:905			case COMPILER_GCC then*/
        case 1:

        /** buildsys.e:906				cmd = sprintf("%s -o %s %s %s %s", { */
        _2 = (object)SEQ_PTR(_settings_46589);
        _24343 = (object)*(((s1_ptr)_2)->base + 3);
        _2 = (object)SEQ_PTR(_56exe_name_45712);
        _24344 = (object)*(((s1_ptr)_2)->base + 11);
        Ref(_24344);
        _24345 = _56adjust_for_build_file(_24344);
        _24344 = NOVALUE;
        _2 = (object)SEQ_PTR(_56res_file_45724);
        _24346 = (object)*(((s1_ptr)_2)->base + 11);
        _2 = (object)SEQ_PTR(_settings_46589);
        _24347 = (object)*(((s1_ptr)_2)->base + 4);
        _1 = NewS1(5);
        _2 = (object)((s1_ptr)_1)->base;
        Ref(_24343);
        ((intptr_t*)_2)[1] = _24343;
        ((intptr_t*)_2)[2] = _24345;
        RefDS(_objs_46588);
        ((intptr_t*)_2)[3] = _objs_46588;
        Ref(_24346);
        ((intptr_t*)_2)[4] = _24346;
        Ref(_24347);
        ((intptr_t*)_2)[5] = _24347;
        _24348 = MAKE_SEQ(_1);
        _24347 = NOVALUE;
        _24346 = NOVALUE;
        _24345 = NOVALUE;
        _24343 = NOVALUE;
        DeRef(_cmd_46587);
        _cmd_46587 = EPrintf(-9999999, _24342, _24348);
        DeRefDS(_24348);
        _24348 = NOVALUE;
        goto L1D; // [819] 848

        /** buildsys.e:915			case else*/
        default:

        /** buildsys.e:916				ShowMsg(2, UNKNOWN_COMPILER_TYPE_1, { compiler_type })*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _56compiler_type_45709;
        _24350 = MAKE_SEQ(_1);
        _39ShowMsg(2, 167, _24350, 1);
        _24350 = NOVALUE;

        /** buildsys.e:918				goto "build_direct_cleanup"*/
        goto G11;
    ;}L1D: 

    /** buildsys.e:921		if not silent then*/
    if (_36silent_21886 != 0)
    goto L1E; // [852] 910

    /** buildsys.e:922			if not verbose then*/
    if (_36verbose_21889 != 0)
    goto L1F; // [859] 892

    /** buildsys.e:923				ShowMsg(1, LINKING_100_1, { abbreviate_path(exe_name[D_NAME]) })*/
    _2 = (object)SEQ_PTR(_56exe_name_45712);
    _24353 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_24353);
    RefDS(_22190);
    _24354 = _17abbreviate_path(_24353, _22190);
    _24353 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _24354;
    _24355 = MAKE_SEQ(_1);
    _24354 = NOVALUE;
    _39ShowMsg(1, 166, _24355, 1);
    _24355 = NOVALUE;
    goto L20; // [889] 909
L1F: 

    /** buildsys.e:925				ShowMsg(1, LINKING_100_1, { cmd })*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_cmd_46587);
    ((intptr_t*)_2)[1] = _cmd_46587;
    _24356 = MAKE_SEQ(_1);
    _39ShowMsg(1, 166, _24356, 1);
    _24356 = NOVALUE;
L20: 
L1E: 

    /** buildsys.e:929		status = system_exec(cmd, 0)*/
    _status_46594 = system_exec_call(_cmd_46587, 0);

    /** buildsys.e:930		if status != 0 then*/
    if (_status_46594 == 0)
    goto L21; // [920] 967

    /** buildsys.e:931			ShowMsg(2, UNABLE_TO_LINK_1, { exe_name[D_NAME] })*/
    _2 = (object)SEQ_PTR(_56exe_name_45712);
    _24359 = (object)*(((s1_ptr)_2)->base + 1);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_24359);
    ((intptr_t*)_2)[1] = _24359;
    _24360 = MAKE_SEQ(_1);
    _24359 = NOVALUE;
    _39ShowMsg(2, 168, _24360, 1);
    _24360 = NOVALUE;

    /** buildsys.e:932			ShowMsg(2, STATUS_1_COMMAND_2_A, { status, cmd })*/
    RefDS(_cmd_46587);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _status_46594;
    ((intptr_t *)_2)[2] = _cmd_46587;
    _24361 = MAKE_SEQ(_1);
    _39ShowMsg(2, 169, _24361, 1);
    _24361 = NOVALUE;

    /** buildsys.e:934			goto "build_direct_cleanup"*/
    goto G11;
L21: 

    /** buildsys.e:938		if length(rc_file[D_ALTNAME]) and length(settings[SETUP_RC_COMPILER]) and compiler_type = COMPILER_WATCOM then*/
    _2 = (object)SEQ_PTR(_56rc_file_45718);
    _24362 = (object)*(((s1_ptr)_2)->base + 11);
    if (IS_SEQUENCE(_24362)){
            _24363 = SEQ_PTR(_24362)->length;
    }
    else {
        _24363 = 1;
    }
    _24362 = NOVALUE;
    if (_24363 == 0) {
        _24364 = 0;
        goto L22; // [980] 995
    }
    _2 = (object)SEQ_PTR(_settings_46589);
    _24365 = (object)*(((s1_ptr)_2)->base + 8);
    if (IS_SEQUENCE(_24365)){
            _24366 = SEQ_PTR(_24365)->length;
    }
    else {
        _24366 = 1;
    }
    _24365 = NOVALUE;
    _24364 = (_24366 != 0);
L22: 
    if (_24364 == 0) {
        goto L23; // [995] 1118
    }
    _24368 = (_56compiler_type_45709 == 2);
    if (_24368 == 0)
    {
        DeRef(_24368);
        _24368 = NOVALUE;
        goto L23; // [1006] 1118
    }
    else{
        DeRef(_24368);
        _24368 = NOVALUE;
    }

    /** buildsys.e:939			cmd = text:format(settings[SETUP_RC_COMPILER], { rc_file[D_ALTNAME], res_file[D_ALTNAME], exe_name[D_ALTNAME] })*/
    _2 = (object)SEQ_PTR(_settings_46589);
    _24369 = (object)*(((s1_ptr)_2)->base + 8);
    _2 = (object)SEQ_PTR(_56rc_file_45718);
    _24370 = (object)*(((s1_ptr)_2)->base + 11);
    _2 = (object)SEQ_PTR(_56res_file_45724);
    _24371 = (object)*(((s1_ptr)_2)->base + 11);
    _2 = (object)SEQ_PTR(_56exe_name_45712);
    _24372 = (object)*(((s1_ptr)_2)->base + 11);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_24370);
    ((intptr_t*)_2)[1] = _24370;
    Ref(_24371);
    ((intptr_t*)_2)[2] = _24371;
    Ref(_24372);
    ((intptr_t*)_2)[3] = _24372;
    _24373 = MAKE_SEQ(_1);
    _24372 = NOVALUE;
    _24371 = NOVALUE;
    _24370 = NOVALUE;
    Ref(_24369);
    _0 = _cmd_46587;
    _cmd_46587 = _14format(_24369, _24373);
    DeRef(_0);
    _24369 = NOVALUE;
    _24373 = NOVALUE;

    /** buildsys.e:940			status = system_exec(cmd, 0)*/
    _status_46594 = system_exec_call(_cmd_46587, 0);

    /** buildsys.e:941			if status != 0 then*/
    if (_status_46594 == 0)
    goto L24; // [1060] 1117

    /** buildsys.e:942				ShowMsg(2, UNABLE_TO_LINK_RESOURCE_FILE_1_INTO_EXECUTABLE_2, { rc_file[D_NAME], exe_name[D_NAME] })*/
    _2 = (object)SEQ_PTR(_56rc_file_45718);
    _24377 = (object)*(((s1_ptr)_2)->base + 1);
    _2 = (object)SEQ_PTR(_56exe_name_45712);
    _24378 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_24378);
    Ref(_24377);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _24377;
    ((intptr_t *)_2)[2] = _24378;
    _24379 = MAKE_SEQ(_1);
    _24378 = NOVALUE;
    _24377 = NOVALUE;
    _39ShowMsg(2, 187, _24379, 1);
    _24379 = NOVALUE;

    /** buildsys.e:943				ShowMsg(2, STATUS_1_COMMAND_2_A, { status, cmd })*/
    RefDS(_cmd_46587);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _status_46594;
    ((intptr_t *)_2)[2] = _cmd_46587;
    _24380 = MAKE_SEQ(_1);
    _39ShowMsg(2, 169, _24380, 1);
    _24380 = NOVALUE;

    /** buildsys.e:945				goto "build_direct_cleanup"*/
    goto G11;
L24: 
L23: 

    /** buildsys.e:949	label "build_direct_cleanup"*/
G11:

    /** buildsys.e:950		if keep = 0 then*/
    if (_58keep_42900 != 0)
    goto L25; // [1126] 1277

    /** buildsys.e:951			for i = 1 to length(generated_files) do*/
    if (IS_SEQUENCE(_58generated_files_42897)){
            _24382 = SEQ_PTR(_58generated_files_42897)->length;
    }
    else {
        _24382 = 1;
    }
    {
        object _i_46844;
        _i_46844 = 1;
L26: 
        if (_i_46844 > _24382){
            goto L27; // [1137] 1193
        }

        /** buildsys.e:952				if verbose then*/
        if (_36verbose_21889 == 0)
        {
            goto L28; // [1148] 1172
        }
        else{
        }

        /** buildsys.e:953					ShowMsg(1, DELETING_1, { generated_files[i] })*/
        _2 = (object)SEQ_PTR(_58generated_files_42897);
        _24383 = (object)*(((s1_ptr)_2)->base + _i_46844);
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_24383);
        ((intptr_t*)_2)[1] = _24383;
        _24384 = MAKE_SEQ(_1);
        _24383 = NOVALUE;
        _39ShowMsg(1, 347, _24384, 1);
        _24384 = NOVALUE;
L28: 

        /** buildsys.e:955				delete_file(generated_files[i])*/
        _2 = (object)SEQ_PTR(_58generated_files_42897);
        _24385 = (object)*(((s1_ptr)_2)->base + _i_46844);
        RefDS(_24385);
        _31977 = _17delete_file(_24385);
        _24385 = NOVALUE;
        DeRef(_31977);
        _31977 = NOVALUE;

        /** buildsys.e:956			end for*/
        _i_46844 = _i_46844 + 1;
        goto L26; // [1188] 1144
L27: 
        ;
    }

    /** buildsys.e:958			if length(res_file[D_ALTNAME]) then*/
    _2 = (object)SEQ_PTR(_56res_file_45724);
    _24386 = (object)*(((s1_ptr)_2)->base + 11);
    if (IS_SEQUENCE(_24386)){
            _24387 = SEQ_PTR(_24386)->length;
    }
    else {
        _24387 = 1;
    }
    _24386 = NOVALUE;
    if (_24387 == 0)
    {
        _24387 = NOVALUE;
        goto L29; // [1206] 1226
    }
    else{
        _24387 = NOVALUE;
    }

    /** buildsys.e:959				delete_file(res_file[D_ALTNAME])*/
    _2 = (object)SEQ_PTR(_56res_file_45724);
    _24388 = (object)*(((s1_ptr)_2)->base + 11);
    Ref(_24388);
    _31976 = _17delete_file(_24388);
    _24388 = NOVALUE;
    DeRef(_31976);
    _31976 = NOVALUE;
L29: 

    /** buildsys.e:962			if remove_output_dir then*/
    if (_56remove_output_dir_45732 == 0)
    {
        goto L2A; // [1230] 1276
    }
    else{
    }

    /** buildsys.e:963				chdir(cwd)*/
    RefDS(_cwd_46591);
    _31975 = _17chdir(_cwd_46591);
    DeRef(_31975);
    _31975 = NOVALUE;

    /** buildsys.e:966				if not remove_directory(output_dir) then*/
    RefDS(_58output_dir_42907);
    _24389 = _17remove_directory(_58output_dir_42907, 0);
    if (IS_ATOM_INT(_24389)) {
        if (_24389 != 0){
            DeRef(_24389);
            _24389 = NOVALUE;
            goto L2B; // [1250] 1275
        }
    }
    else {
        if (DBL_PTR(_24389)->dbl != 0.0){
            DeRef(_24389);
            _24389 = NOVALUE;
            goto L2B; // [1250] 1275
        }
    }
    DeRef(_24389);
    _24389 = NOVALUE;

    /** buildsys.e:967					ShowMsg(2, COULD_NOT_REMOVE_DIRECTORY_1, { abbreviate_path(output_dir) })*/
    RefDS(_58output_dir_42907);
    RefDS(_22190);
    _24391 = _17abbreviate_path(_58output_dir_42907, _22190);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _24391;
    _24392 = MAKE_SEQ(_1);
    _24391 = NOVALUE;
    _39ShowMsg(2, 194, _24392, 1);
    _24392 = NOVALUE;
L2B: 
L2A: 
L25: 

    /** buildsys.e:972		chdir(cwd)*/
    RefDS(_cwd_46591);
    _31974 = _17chdir(_cwd_46591);
    DeRef(_31974);
    _31974 = NOVALUE;

    /** buildsys.e:973	end procedure*/
    DeRefDS(_the_file0_46581);
    DeRef(_cmd_46587);
    DeRef(_objs_46588);
    DeRef(_settings_46589);
    DeRefDS(_cwd_46591);
    DeRef(_link_files_46625);
    _24319 = NOVALUE;
    _24386 = NOVALUE;
    DeRef(_24285);
    _24285 = NOVALUE;
    _24362 = NOVALUE;
    _24322 = NOVALUE;
    _24365 = NOVALUE;
    DeRef(_24313);
    _24313 = NOVALUE;
    return;
    ;
}


void _56write_buildfile()
{
    object _make_command_46886 = NOVALUE;
    object _settings_46931 = NOVALUE;
    object _24415 = NOVALUE;
    object _24414 = NOVALUE;
    object _24410 = NOVALUE;
    object _24409 = NOVALUE;
    object _24408 = NOVALUE;
    object _24406 = NOVALUE;
    object _24405 = NOVALUE;
    object _24404 = NOVALUE;
    object _24403 = NOVALUE;
    object _24402 = NOVALUE;
    object _24401 = NOVALUE;
    object _24400 = NOVALUE;
    object _24399 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:982		switch build_system_type do*/
    _0 = _56build_system_type_45705;
    switch ( _0 ){ 

        /** buildsys.e:983			case BUILD_MAKEFILE_FULL then*/
        case 2:

        /** buildsys.e:984				write_makefile_full()*/
        _56write_makefile_full();

        /** buildsys.e:986				if not silent then*/
        if (_36silent_21886 != 0)
        goto L1; // [22] 142

        /** buildsys.e:987					sequence make_command*/

        /** buildsys.e:988					if compiler_type = COMPILER_WATCOM then*/
        if (_56compiler_type_45709 != 2)
        goto L2; // [31] 45

        /** buildsys.e:989						make_command = "wmake /f "*/
        RefDS(_24397);
        DeRefi(_make_command_46886);
        _make_command_46886 = _24397;
        goto L3; // [42] 53
L2: 

        /** buildsys.e:991						make_command = "make -f "*/
        RefDS(_24398);
        DeRefi(_make_command_46886);
        _make_command_46886 = _24398;
L3: 

        /** buildsys.e:994					ShowMsg(1, MSG_1C_FILES_WERE_CREATED, { cfile_count + 2 })*/
        _24399 = _36cfile_count_21849 + 2;
        if ((object)((uintptr_t)_24399 + (uintptr_t)HIGH_BITS) >= 0){
            _24399 = NewDouble((eudouble)_24399);
        }
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _24399;
        _24400 = MAKE_SEQ(_1);
        _24399 = NOVALUE;
        _39ShowMsg(1, 170, _24400, 1);
        _24400 = NOVALUE;

        /** buildsys.e:996					if sequence(output_dir) and length(output_dir) > 0 then*/
        _24401 = 1;
        if (_24401 == 0) {
            goto L4; // [80] 122
        }
        if (IS_SEQUENCE(_58output_dir_42907)){
                _24403 = SEQ_PTR(_58output_dir_42907)->length;
        }
        else {
            _24403 = 1;
        }
        _24404 = (_24403 > 0);
        _24403 = NOVALUE;
        if (_24404 == 0)
        {
            DeRef(_24404);
            _24404 = NOVALUE;
            goto L4; // [94] 122
        }
        else{
            DeRef(_24404);
            _24404 = NOVALUE;
        }

        /** buildsys.e:997						ShowMsg(1, TO_BUILD_YOUR_PROJECT_CHANGE_DIRECTORY_TO_1_AND_TYPE_23MAK, { output_dir, make_command, file0 })*/
        _1 = NewS1(3);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_58output_dir_42907);
        ((intptr_t*)_2)[1] = _58output_dir_42907;
        RefDS(_make_command_46886);
        ((intptr_t*)_2)[2] = _make_command_46886;
        RefDS(_58file0_44851);
        ((intptr_t*)_2)[3] = _58file0_44851;
        _24405 = MAKE_SEQ(_1);
        _39ShowMsg(1, 174, _24405, 1);
        _24405 = NOVALUE;
        goto L5; // [119] 141
L4: 

        /** buildsys.e:999						ShowMsg(1, TO_BUILD_YOUR_PROJECT_TYPE_12MAK, { make_command, file0 })*/
        RefDS(_58file0_44851);
        RefDS(_make_command_46886);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _make_command_46886;
        ((intptr_t *)_2)[2] = _58file0_44851;
        _24406 = MAKE_SEQ(_1);
        _39ShowMsg(1, 172, _24406, 1);
        _24406 = NOVALUE;
L5: 
L1: 
        DeRefi(_make_command_46886);
        _make_command_46886 = NOVALUE;
        goto L6; // [144] 277

        /** buildsys.e:1003			case BUILD_MAKEFILE_PARTIAL then*/
        case 1:

        /** buildsys.e:1004				write_makefile_partial()*/
        _56write_makefile_partial();

        /** buildsys.e:1006				if not silent then*/
        if (_36silent_21886 != 0)
        goto L6; // [158] 277

        /** buildsys.e:1007					ShowMsg(1, MSG_1C_FILES_WERE_CREATED, { cfile_count + 2 })*/
        _24408 = _36cfile_count_21849 + 2;
        if ((object)((uintptr_t)_24408 + (uintptr_t)HIGH_BITS) >= 0){
            _24408 = NewDouble((eudouble)_24408);
        }
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _24408;
        _24409 = MAKE_SEQ(_1);
        _24408 = NOVALUE;
        _39ShowMsg(1, 170, _24409, 1);
        _24409 = NOVALUE;

        /** buildsys.e:1008					ShowMsg(1, TO_BUILD_YOUR_PROJECT_INCLUDE_1MAK_INTO_A_LARGER_MAKEFILE_PROJECT, { file0 })*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_58file0_44851);
        ((intptr_t*)_2)[1] = _58file0_44851;
        _24410 = MAKE_SEQ(_1);
        _39ShowMsg(1, 173, _24410, 1);
        _24410 = NOVALUE;
        goto L6; // [198] 277

        /** buildsys.e:1011			case BUILD_DIRECT then*/
        case 3:

        /** buildsys.e:1012				build_direct()*/
        RefDS(_22190);
        _56build_direct(0, _22190);

        /** buildsys.e:1014				if not silent then*/
        if (_36silent_21886 != 0)
        goto L7; // [214] 225

        /** buildsys.e:1015					sequence settings = setup_build()*/
        _0 = _settings_46931;
        _settings_46931 = _56setup_build();
        DeRef(_0);
L7: 
        DeRef(_settings_46931);
        _settings_46931 = NOVALUE;
        goto L6; // [227] 277

        /** buildsys.e:1019			case BUILD_NONE then*/
        case 0:

        /** buildsys.e:1020				if not silent then*/
        if (_36silent_21886 != 0)
        goto L6; // [237] 277

        /** buildsys.e:1021					ShowMsg(1, MSG_1C_FILES_WERE_CREATED, { cfile_count + 2 })*/
        _24414 = _36cfile_count_21849 + 2;
        if ((object)((uintptr_t)_24414 + (uintptr_t)HIGH_BITS) >= 0){
            _24414 = NewDouble((eudouble)_24414);
        }
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _24414;
        _24415 = MAKE_SEQ(_1);
        _24414 = NOVALUE;
        _39ShowMsg(1, 170, _24415, 1);
        _24415 = NOVALUE;
        goto L6; // [261] 277

        /** buildsys.e:1026			case else*/
        default:

        /** buildsys.e:1027				CompileErr(UNKNOWN_BUILD_FILE_TYPE)*/
        RefDS(_22190);
        _50CompileErr(151, _22190, 0);
    ;}L6: 

    /** buildsys.e:1029	end procedure*/
    return;
    ;
}



// 0x89D06C95
