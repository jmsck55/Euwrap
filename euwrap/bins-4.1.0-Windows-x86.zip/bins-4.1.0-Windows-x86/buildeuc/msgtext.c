// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _39GetMsgText(object _MsgNum_21313, object _WithNum_21314, object _Args_21315)
{
    object _idx_21316 = NOVALUE;
    object _msgtext_21317 = NOVALUE;
    object _12156 = NOVALUE;
    object _12155 = NOVALUE;
    object _12151 = NOVALUE;
    object _12150 = NOVALUE;
    object _12148 = NOVALUE;
    object _12145 = NOVALUE;
    object _12143 = NOVALUE;
    object _12142 = NOVALUE;
    object _12141 = NOVALUE;
    object _12140 = NOVALUE;
    object _0, _1, _2;
    

    /** msgtext.e:757		integer idx = 1*/
    _idx_21316 = 1;

    /** msgtext.e:761		msgtext = get_text( MsgNum, LocalizeQual, LocalDB )*/
    Ref(_MsgNum_21313);
    RefDS(_37LocalizeQual_15656);
    RefDS(_37LocalDB_15657);
    _0 = _msgtext_21317;
    _msgtext_21317 = _40get_text(_MsgNum_21313, _37LocalizeQual_15656, _37LocalDB_15657);
    DeRef(_0);

    /** msgtext.e:764		if atom(msgtext) then*/
    _12140 = IS_ATOM(_msgtext_21317);
    if (_12140 == 0)
    {
        _12140 = NOVALUE;
        goto L1; // [25] 100
    }
    else{
        _12140 = NOVALUE;
    }

    /** msgtext.e:765			for i = 1 to length(StdErrMsgs) do*/
    _12141 = 365;
    {
        object _i_21325;
        _i_21325 = 1;
L2: 
        if (_i_21325 > 365){
            goto L3; // [35] 75
        }

        /** msgtext.e:766				if StdErrMsgs[i][1] = MsgNum then*/
        _2 = (object)SEQ_PTR(_39StdErrMsgs_20584);
        _12142 = (object)*(((s1_ptr)_2)->base + _i_21325);
        _2 = (object)SEQ_PTR(_12142);
        _12143 = (object)*(((s1_ptr)_2)->base + 1);
        _12142 = NOVALUE;
        if (binary_op_a(NOTEQ, _12143, _MsgNum_21313)){
            _12143 = NOVALUE;
            goto L4; // [54] 68
        }
        _12143 = NOVALUE;

        /** msgtext.e:767					idx = i*/
        _idx_21316 = _i_21325;

        /** msgtext.e:768					exit*/
        goto L3; // [65] 75
L4: 

        /** msgtext.e:770			end for*/
        _i_21325 = _i_21325 + 1;
        goto L2; // [70] 42
L3: 
        ;
    }

    /** msgtext.e:771			msgtext = StdErrMsgs[idx][2]*/
    _2 = (object)SEQ_PTR(_39StdErrMsgs_20584);
    _12145 = (object)*(((s1_ptr)_2)->base + _idx_21316);
    DeRef(_msgtext_21317);
    _2 = (object)SEQ_PTR(_12145);
    _msgtext_21317 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_msgtext_21317);
    _12145 = NOVALUE;

    /** msgtext.e:772			if idx = 1 then*/
    if (_idx_21316 != 1)
    goto L5; // [89] 99

    /** msgtext.e:773				Args = MsgNum*/
    Ref(_MsgNum_21313);
    DeRef(_Args_21315);
    _Args_21315 = _MsgNum_21313;
L5: 
L1: 

    /** msgtext.e:777		if atom(Args) or length(Args) != 0 then*/
    _12148 = IS_ATOM(_Args_21315);
    if (_12148 != 0) {
        goto L6; // [105] 121
    }
    if (IS_SEQUENCE(_Args_21315)){
            _12150 = SEQ_PTR(_Args_21315)->length;
    }
    else {
        _12150 = 1;
    }
    _12151 = (_12150 != 0);
    _12150 = NOVALUE;
    if (_12151 == 0)
    {
        DeRef(_12151);
        _12151 = NOVALUE;
        goto L7; // [117] 129
    }
    else{
        DeRef(_12151);
        _12151 = NOVALUE;
    }
L6: 

    /** msgtext.e:778			msgtext = format(msgtext, Args)*/
    Ref(_msgtext_21317);
    Ref(_Args_21315);
    _0 = _msgtext_21317;
    _msgtext_21317 = _14format(_msgtext_21317, _Args_21315);
    DeRef(_0);
L7: 

    /** msgtext.e:781		if WithNum != 0 then*/
    if (_WithNum_21314 == 0)
    goto L8; // [131] 152

    /** msgtext.e:782			return sprintf("<%04d>:: %s", {MsgNum, msgtext})*/
    Ref(_msgtext_21317);
    Ref(_MsgNum_21313);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _MsgNum_21313;
    ((intptr_t *)_2)[2] = _msgtext_21317;
    _12155 = MAKE_SEQ(_1);
    _12156 = EPrintf(-9999999, _12154, _12155);
    DeRefDS(_12155);
    _12155 = NOVALUE;
    DeRef(_MsgNum_21313);
    DeRef(_Args_21315);
    DeRef(_msgtext_21317);
    return _12156;
    goto L9; // [149] 159
L8: 

    /** msgtext.e:784			return msgtext*/
    DeRef(_MsgNum_21313);
    DeRef(_Args_21315);
    DeRef(_12156);
    _12156 = NOVALUE;
    return _msgtext_21317;
L9: 
    ;
}


void _39ShowMsg(object _Cons_21350, object _Msg_21351, object _Args_21352, object _NL_21353)
{
    object _12163 = NOVALUE;
    object _12162 = NOVALUE;
    object _12160 = NOVALUE;
    object _12158 = NOVALUE;
    object _12157 = NOVALUE;
    object _0, _1, _2;
    

    /** msgtext.e:790		if atom(Msg) then*/
    _12157 = 1;
    if (_12157 == 0)
    {
        _12157 = NOVALUE;
        goto L1; // [10] 25
    }
    else{
        _12157 = NOVALUE;
    }

    /** msgtext.e:791			Msg = GetMsgText(floor(Msg), 0)*/
    _12158 = e_floor(_Msg_21351);
    RefDS(_5);
    _Msg_21351 = _39GetMsgText(_12158, 0, _5);
    _12158 = NOVALUE;
L1: 

    /** msgtext.e:794		if atom(Args) or length(Args) != 0 then*/
    _12160 = IS_ATOM(_Args_21352);
    if (_12160 != 0) {
        goto L2; // [30] 46
    }
    if (IS_SEQUENCE(_Args_21352)){
            _12162 = SEQ_PTR(_Args_21352)->length;
    }
    else {
        _12162 = 1;
    }
    _12163 = (_12162 != 0);
    _12162 = NOVALUE;
    if (_12163 == 0)
    {
        DeRef(_12163);
        _12163 = NOVALUE;
        goto L3; // [42] 54
    }
    else{
        DeRef(_12163);
        _12163 = NOVALUE;
    }
L2: 

    /** msgtext.e:795			Msg = format(Msg, Args)*/
    Ref(_Msg_21351);
    Ref(_Args_21352);
    _0 = _Msg_21351;
    _Msg_21351 = _14format(_Msg_21351, _Args_21352);
    DeRef(_0);
L3: 

    /** msgtext.e:798		puts(Cons, Msg)*/
    EPuts(_Cons_21350, _Msg_21351); // DJP 

    /** msgtext.e:800		if NL then*/
    if (_NL_21353 == 0)
    {
        goto L4; // [61] 70
    }
    else{
    }

    /** msgtext.e:801			puts(Cons, '\n')*/
    EPuts(_Cons_21350, 10); // DJP 
L4: 

    /** msgtext.e:804	end procedure*/
    DeRef(_Msg_21351);
    DeRef(_Args_21352);
    return;
    ;
}



// 0x61ECF7BF
