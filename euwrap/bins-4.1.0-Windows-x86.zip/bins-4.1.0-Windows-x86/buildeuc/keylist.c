// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _63find_category(object _tokid_24322)
{
    object _catname_24323 = NOVALUE;
    object _13701 = NOVALUE;
    object _13700 = NOVALUE;
    object _13698 = NOVALUE;
    object _13697 = NOVALUE;
    object _13696 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_tokid_24322)) {
        _1 = (object)(DBL_PTR(_tokid_24322)->dbl);
        DeRefDS(_tokid_24322);
        _tokid_24322 = _1;
    }

    /** keylist.e:194		sequence catname = "reserved word"*/
    RefDS(_13695);
    DeRef(_catname_24323);
    _catname_24323 = _13695;

    /** keylist.e:195		for i = 1 to length(token_category) do*/
    _13696 = 73;
    {
        object _i_24326;
        _i_24326 = 1;
L1: 
        if (_i_24326 > 73){
            goto L2; // [17] 72
        }

        /** keylist.e:196			if token_category[i][1] = tokid then*/
        _2 = (object)SEQ_PTR(_38token_category_16218);
        _13697 = (object)*(((s1_ptr)_2)->base + _i_24326);
        _2 = (object)SEQ_PTR(_13697);
        _13698 = (object)*(((s1_ptr)_2)->base + 1);
        _13697 = NOVALUE;
        if (binary_op_a(NOTEQ, _13698, _tokid_24322)){
            _13698 = NOVALUE;
            goto L3; // [36] 65
        }
        _13698 = NOVALUE;

        /** keylist.e:197				catname = token_catname[token_category[i][2]]*/
        _2 = (object)SEQ_PTR(_38token_category_16218);
        _13700 = (object)*(((s1_ptr)_2)->base + _i_24326);
        _2 = (object)SEQ_PTR(_13700);
        _13701 = (object)*(((s1_ptr)_2)->base + 2);
        _13700 = NOVALUE;
        DeRef(_catname_24323);
        _2 = (object)SEQ_PTR(_38token_catname_16205);
        if (!IS_ATOM_INT(_13701)){
            _catname_24323 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_13701)->dbl));
        }
        else{
            _catname_24323 = (object)*(((s1_ptr)_2)->base + _13701);
        }
        RefDS(_catname_24323);

        /** keylist.e:198				exit*/
        goto L2; // [62] 72
L3: 

        /** keylist.e:200		end for*/
        _i_24326 = _i_24326 + 1;
        goto L1; // [67] 24
L2: 
        ;
    }

    /** keylist.e:201		return catname*/
    _13701 = NOVALUE;
    return _catname_24323;
    ;
}


object _63find_token_text(object _tokid_24341)
{
    object _13710 = NOVALUE;
    object _13708 = NOVALUE;
    object _13707 = NOVALUE;
    object _13705 = NOVALUE;
    object _13704 = NOVALUE;
    object _13703 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_tokid_24341)) {
        _1 = (object)(DBL_PTR(_tokid_24341)->dbl);
        DeRefDS(_tokid_24341);
        _tokid_24341 = _1;
    }

    /** keylist.e:205		for i = 1 to length(keylist) do*/
    if (IS_SEQUENCE(_63keylist_23441)){
            _13703 = SEQ_PTR(_63keylist_23441)->length;
    }
    else {
        _13703 = 1;
    }
    {
        object _i_24343;
        _i_24343 = 1;
L1: 
        if (_i_24343 > _13703){
            goto L2; // [10] 57
        }

        /** keylist.e:206			if keylist[i][3] = tokid then*/
        _2 = (object)SEQ_PTR(_63keylist_23441);
        _13704 = (object)*(((s1_ptr)_2)->base + _i_24343);
        _2 = (object)SEQ_PTR(_13704);
        _13705 = (object)*(((s1_ptr)_2)->base + 3);
        _13704 = NOVALUE;
        if (binary_op_a(NOTEQ, _13705, _tokid_24341)){
            _13705 = NOVALUE;
            goto L3; // [29] 50
        }
        _13705 = NOVALUE;

        /** keylist.e:207				return keylist[i][1]*/
        _2 = (object)SEQ_PTR(_63keylist_23441);
        _13707 = (object)*(((s1_ptr)_2)->base + _i_24343);
        _2 = (object)SEQ_PTR(_13707);
        _13708 = (object)*(((s1_ptr)_2)->base + 1);
        _13707 = NOVALUE;
        Ref(_13708);
        return _13708;
L3: 

        /** keylist.e:209		end for*/
        _i_24343 = _i_24343 + 1;
        goto L1; // [52] 17
L2: 
        ;
    }

    /** keylist.e:210		return LexName(tokid, "unknown word")*/
    RefDS(_13709);
    _13710 = _47LexName(_tokid_24341, _13709);
    _13708 = NOVALUE;
    return _13710;
    ;
}



// 0xF6595436
