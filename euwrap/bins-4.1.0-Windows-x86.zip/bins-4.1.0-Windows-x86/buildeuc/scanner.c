// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _62set_qualified_fwd(object _fwd_25908)
{
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_fwd_25908)) {
        _1 = (object)(DBL_PTR(_fwd_25908)->dbl);
        DeRefDS(_fwd_25908);
        _fwd_25908 = _1;
    }

    /** scanner.e:104		qualified_fwd = fwd*/
    _62qualified_fwd_25905 = _fwd_25908;

    /** scanner.e:105	end procedure*/
    return;
    ;
}


object _62get_qualified_fwd()
{
    object _fwd_25911 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:108		integer fwd = qualified_fwd*/
    _fwd_25911 = _62qualified_fwd_25905;

    /** scanner.e:109		set_qualified_fwd( -1 )*/

    /** scanner.e:104		qualified_fwd = fwd*/
    _62qualified_fwd_25905 = -1;

    /** scanner.e:105	end procedure*/
    goto L1; // [17] 20
L1: 

    /** scanner.e:110		return fwd*/
    return _fwd_25911;
    ;
}


void _62InitLex()
{
    object _14445 = NOVALUE;
    object _14444 = NOVALUE;
    object _14443 = NOVALUE;
    object _14441 = NOVALUE;
    object _14440 = NOVALUE;
    object _14439 = NOVALUE;
    object _14438 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:117		gline_number = 0*/
    _36gline_number_21772 = 0;

    /** scanner.e:118		line_number = 0*/
    _36line_number_21768 = 0;

    /** scanner.e:119		IncludeStk = {}*/
    RefDS(_5);
    DeRef(_62IncludeStk_25882);
    _62IncludeStk_25882 = _5;

    /** scanner.e:120		char_class = repeat(ILLEGAL_CHAR, 255)  -- we screen out the 0 character*/
    DeRefi(_62char_class_25880);
    _62char_class_25880 = Repeat(-20, 255);

    /** scanner.e:122		char_class['0'..'9'] = DIGIT*/
    assign_slice_seq = (s1_ptr *)&_62char_class_25880;
    AssignSlice(48, 57, -7);

    /** scanner.e:123		char_class['_']      = DIGIT*/
    _2 = (object)SEQ_PTR(_62char_class_25880);
    _2 = (object)(((s1_ptr)_2)->base + 95);
    *(intptr_t *)_2 = -7;

    /** scanner.e:124		char_class['a'..'z'] = LETTER*/
    assign_slice_seq = (s1_ptr *)&_62char_class_25880;
    AssignSlice(97, 122, -2);

    /** scanner.e:125		char_class['A'..'Z'] = LETTER*/
    assign_slice_seq = (s1_ptr *)&_62char_class_25880;
    AssignSlice(65, 90, -2);

    /** scanner.e:126		char_class[KEYWORD_BASE+1..KEYWORD_BASE+NUM_KEYWORDS] = KEYWORD*/
    _14438 = 129;
    _14439 = 152;
    assign_slice_seq = (s1_ptr *)&_62char_class_25880;
    AssignSlice(129, 152, -10);
    _14438 = NOVALUE;
    _14439 = NOVALUE;

    /** scanner.e:127		char_class[BUILTIN_BASE+1..BUILTIN_BASE+NUM_BUILTINS] = BUILTIN*/
    _14440 = 171;
    _14441 = 234;
    assign_slice_seq = (s1_ptr *)&_62char_class_25880;
    AssignSlice(171, 234, -9);
    _14440 = NOVALUE;
    _14441 = NOVALUE;

    /** scanner.e:129		char_class[' '] = BLANK*/
    _2 = (object)SEQ_PTR(_62char_class_25880);
    _2 = (object)(((s1_ptr)_2)->base + 32);
    *(intptr_t *)_2 = -8;

    /** scanner.e:130		char_class['\t'] = BLANK*/
    _2 = (object)SEQ_PTR(_62char_class_25880);
    _2 = (object)(((s1_ptr)_2)->base + 9);
    *(intptr_t *)_2 = -8;

    /** scanner.e:131		char_class['+'] = PLUS*/
    _2 = (object)SEQ_PTR(_62char_class_25880);
    _2 = (object)(((s1_ptr)_2)->base + 43);
    *(intptr_t *)_2 = 11;

    /** scanner.e:132		char_class['-'] = MINUS*/
    _2 = (object)SEQ_PTR(_62char_class_25880);
    _2 = (object)(((s1_ptr)_2)->base + 45);
    *(intptr_t *)_2 = 10;

    /** scanner.e:133		char_class['*'] = res:MULTIPLY*/
    _2 = (object)SEQ_PTR(_62char_class_25880);
    _2 = (object)(((s1_ptr)_2)->base + 42);
    *(intptr_t *)_2 = 13;

    /** scanner.e:134		char_class['/'] = res:DIVIDE*/
    _2 = (object)SEQ_PTR(_62char_class_25880);
    _2 = (object)(((s1_ptr)_2)->base + 47);
    *(intptr_t *)_2 = 14;

    /** scanner.e:135		char_class['='] = EQUALS*/
    _2 = (object)SEQ_PTR(_62char_class_25880);
    _2 = (object)(((s1_ptr)_2)->base + 61);
    *(intptr_t *)_2 = 3;

    /** scanner.e:136		char_class['<'] = LESS*/
    _2 = (object)SEQ_PTR(_62char_class_25880);
    _2 = (object)(((s1_ptr)_2)->base + 60);
    *(intptr_t *)_2 = 1;

    /** scanner.e:137		char_class['>'] = GREATER*/
    _2 = (object)SEQ_PTR(_62char_class_25880);
    _2 = (object)(((s1_ptr)_2)->base + 62);
    *(intptr_t *)_2 = 6;

    /** scanner.e:138		char_class['\''] = SINGLE_QUOTE*/
    _2 = (object)SEQ_PTR(_62char_class_25880);
    _2 = (object)(((s1_ptr)_2)->base + 39);
    *(intptr_t *)_2 = -5;

    /** scanner.e:139		char_class['"'] = DOUBLE_QUOTE*/
    _2 = (object)SEQ_PTR(_62char_class_25880);
    _2 = (object)(((s1_ptr)_2)->base + 34);
    *(intptr_t *)_2 = -4;

    /** scanner.e:140		char_class['`'] = BACK_QUOTE*/
    _2 = (object)SEQ_PTR(_62char_class_25880);
    _2 = (object)(((s1_ptr)_2)->base + 96);
    *(intptr_t *)_2 = -12;

    /** scanner.e:141		char_class['.'] = DOT*/
    _2 = (object)SEQ_PTR(_62char_class_25880);
    _2 = (object)(((s1_ptr)_2)->base + 46);
    *(intptr_t *)_2 = -3;

    /** scanner.e:142		char_class[':'] = COLON*/
    _2 = (object)SEQ_PTR(_62char_class_25880);
    _2 = (object)(((s1_ptr)_2)->base + 58);
    *(intptr_t *)_2 = -23;

    /** scanner.e:143		char_class['\r'] = NEWLINE*/
    _2 = (object)SEQ_PTR(_62char_class_25880);
    _2 = (object)(((s1_ptr)_2)->base + 13);
    *(intptr_t *)_2 = -6;

    /** scanner.e:144		char_class['\n'] = NEWLINE*/
    _2 = (object)SEQ_PTR(_62char_class_25880);
    _2 = (object)(((s1_ptr)_2)->base + 10);
    *(intptr_t *)_2 = -6;

    /** scanner.e:145		char_class['!'] = BANG*/
    _2 = (object)SEQ_PTR(_62char_class_25880);
    _2 = (object)(((s1_ptr)_2)->base + 33);
    *(intptr_t *)_2 = -1;

    /** scanner.e:146		char_class['{'] = LEFT_BRACE*/
    _2 = (object)SEQ_PTR(_62char_class_25880);
    _2 = (object)(((s1_ptr)_2)->base + 123);
    *(intptr_t *)_2 = -24;

    /** scanner.e:147		char_class['}'] = RIGHT_BRACE*/
    _2 = (object)SEQ_PTR(_62char_class_25880);
    _2 = (object)(((s1_ptr)_2)->base + 125);
    *(intptr_t *)_2 = -25;

    /** scanner.e:148		char_class['('] = LEFT_ROUND*/
    _2 = (object)SEQ_PTR(_62char_class_25880);
    _2 = (object)(((s1_ptr)_2)->base + 40);
    *(intptr_t *)_2 = -26;

    /** scanner.e:149		char_class[')'] = RIGHT_ROUND*/
    _2 = (object)SEQ_PTR(_62char_class_25880);
    _2 = (object)(((s1_ptr)_2)->base + 41);
    *(intptr_t *)_2 = -27;

    /** scanner.e:150		char_class['['] = LEFT_SQUARE*/
    _2 = (object)SEQ_PTR(_62char_class_25880);
    _2 = (object)(((s1_ptr)_2)->base + 91);
    *(intptr_t *)_2 = -28;

    /** scanner.e:151		char_class[']'] = RIGHT_SQUARE*/
    _2 = (object)SEQ_PTR(_62char_class_25880);
    _2 = (object)(((s1_ptr)_2)->base + 93);
    *(intptr_t *)_2 = -29;

    /** scanner.e:152		char_class['$'] = DOLLAR*/
    _2 = (object)SEQ_PTR(_62char_class_25880);
    _2 = (object)(((s1_ptr)_2)->base + 36);
    *(intptr_t *)_2 = -22;

    /** scanner.e:153		char_class[','] = COMMA*/
    _2 = (object)SEQ_PTR(_62char_class_25880);
    _2 = (object)(((s1_ptr)_2)->base + 44);
    *(intptr_t *)_2 = -30;

    /** scanner.e:154		char_class['&'] = res:CONCAT*/
    _2 = (object)SEQ_PTR(_62char_class_25880);
    _2 = (object)(((s1_ptr)_2)->base + 38);
    *(intptr_t *)_2 = 15;

    /** scanner.e:155		char_class['?'] = QUESTION_MARK*/
    _2 = (object)SEQ_PTR(_62char_class_25880);
    _2 = (object)(((s1_ptr)_2)->base + 63);
    *(intptr_t *)_2 = -31;

    /** scanner.e:156		char_class['#'] = NUMBER_SIGN*/
    _2 = (object)SEQ_PTR(_62char_class_25880);
    _2 = (object)(((s1_ptr)_2)->base + 35);
    *(intptr_t *)_2 = -11;

    /** scanner.e:159		char_class[END_OF_FILE_CHAR] = END_OF_FILE*/
    _2 = (object)SEQ_PTR(_62char_class_25880);
    _2 = (object)(((s1_ptr)_2)->base + 26);
    *(intptr_t *)_2 = -21;

    /** scanner.e:162		id_char = repeat(FALSE, 255)*/
    DeRefi(_62id_char_25881);
    _62id_char_25881 = Repeat(_13FALSE_445, 255);

    /** scanner.e:163		for i = 1 to 255 do*/
    {
        object _i_25959;
        _i_25959 = 1;
L1: 
        if (_i_25959 > 255){
            goto L2; // [407] 456
        }

        /** scanner.e:164			if find(char_class[i], {LETTER, DIGIT}) then*/
        _2 = (object)SEQ_PTR(_62char_class_25880);
        _14443 = (object)*(((s1_ptr)_2)->base + _i_25959);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = -2;
        ((intptr_t *)_2)[2] = -7;
        _14444 = MAKE_SEQ(_1);
        _14445 = find_from(_14443, _14444, 1);
        _14443 = NOVALUE;
        DeRefDS(_14444);
        _14444 = NOVALUE;
        if (_14445 == 0)
        {
            _14445 = NOVALUE;
            goto L3; // [435] 449
        }
        else{
            _14445 = NOVALUE;
        }

        /** scanner.e:165				id_char[i] = TRUE*/
        _2 = (object)SEQ_PTR(_62id_char_25881);
        _2 = (object)(((s1_ptr)_2)->base + _i_25959);
        *(intptr_t *)_2 = _13TRUE_447;
L3: 

        /** scanner.e:167		end for*/
        _i_25959 = _i_25959 + 1;
        goto L1; // [451] 414
L2: 
        ;
    }

    /** scanner.e:169		default_namespaces = {0}*/
    _0 = _62default_namespaces_25879;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 0;
    _62default_namespaces_25879 = MAKE_SEQ(_1);
    DeRef(_0);

    /** scanner.e:170	end procedure*/
    return;
    ;
}


void _62ResetTP()
{
    object _0, _1, _2;
    

    /** scanner.e:174		OpTrace = FALSE*/
    _36OpTrace_21840 = _13FALSE_445;

    /** scanner.e:175		OpProfileStatement = FALSE*/
    _36OpProfileStatement_21842 = _13FALSE_445;

    /** scanner.e:176		OpProfileTime = FALSE*/
    _36OpProfileTime_21843 = _13FALSE_445;

    /** scanner.e:177		AnyStatementProfile = FALSE*/
    _37AnyStatementProfile_15660 = _13FALSE_445;

    /** scanner.e:178		AnyTimeProfile = FALSE*/
    _37AnyTimeProfile_15659 = _13FALSE_445;

    /** scanner.e:179	end procedure*/
    return;
    ;
}


object _62pack_source(object _src_25989)
{
    object _start_25990 = NOVALUE;
    object _14469 = NOVALUE;
    object _14468 = NOVALUE;
    object _14467 = NOVALUE;
    object _14466 = NOVALUE;
    object _14464 = NOVALUE;
    object _14462 = NOVALUE;
    object _14461 = NOVALUE;
    object _14460 = NOVALUE;
    object _14456 = NOVALUE;
    object _14454 = NOVALUE;
    object _14453 = NOVALUE;
    object _14450 = NOVALUE;
    object _14449 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:197		if equal(src, 0) then*/
    if (_src_25989 == 0)
    _14449 = 1;
    else if (IS_ATOM_INT(_src_25989) && IS_ATOM_INT(0))
    _14449 = 0;
    else
    _14449 = (compare(_src_25989, 0) == 0);
    if (_14449 == 0)
    {
        _14449 = NOVALUE;
        goto L1; // [7] 17
    }
    else{
        _14449 = NOVALUE;
    }

    /** scanner.e:198			return 0*/
    DeRef(_src_25989);
    return 0;
L1: 

    /** scanner.e:201		if length(src) >= SOURCE_CHUNK then*/
    if (IS_SEQUENCE(_src_25989)){
            _14450 = SEQ_PTR(_src_25989)->length;
    }
    else {
        _14450 = 1;
    }
    if (_14450 < 10000)
    goto L2; // [22] 34

    /** scanner.e:202			src = src[1..100] -- enough for trace or profile display*/
    rhs_slice_target = (object_ptr)&_src_25989;
    RHS_Slice(_src_25989, 1, 100);
L2: 

    /** scanner.e:205		if current_source_next + length(src) >= SOURCE_CHUNK then*/
    if (IS_SEQUENCE(_src_25989)){
            _14453 = SEQ_PTR(_src_25989)->length;
    }
    else {
        _14453 = 1;
    }
    _14454 = _62current_source_next_25985 + _14453;
    if ((object)((uintptr_t)_14454 + (uintptr_t)HIGH_BITS) >= 0){
        _14454 = NewDouble((eudouble)_14454);
    }
    _14453 = NOVALUE;
    if (binary_op_a(LESS, _14454, 10000)){
        DeRef(_14454);
        _14454 = NOVALUE;
        goto L3; // [45] 96
    }
    DeRef(_14454);
    _14454 = NOVALUE;

    /** scanner.e:207			current_source = allocate(SOURCE_CHUNK + LINE_BUFLEN)*/
    _14456 = 10400;
    _0 = _9allocate(10400, 0);
    DeRef(_62current_source_25984);
    _62current_source_25984 = _0;
    _14456 = NOVALUE;

    /** scanner.e:208			if current_source = 0 then*/
    if (binary_op_a(NOTEQ, _62current_source_25984, 0)){
        goto L4; // [64] 78
    }

    /** scanner.e:209				CompileErr(OUT_OF_MEMORY__TURN_OFF_TRACE_AND_PROFILE)*/
    RefDS(_22190);
    _50CompileErr(123, _22190, 0);
L4: 

    /** scanner.e:211			all_source = append(all_source, current_source)*/
    Ref(_62current_source_25984);
    Append(&_37all_source_15661, _37all_source_15661, _62current_source_25984);

    /** scanner.e:213			current_source_next = 1*/
    _62current_source_next_25985 = 1;
L3: 

    /** scanner.e:216		start = current_source_next*/
    _start_25990 = _62current_source_next_25985;

    /** scanner.e:217		poke(current_source+current_source_next, src)*/
    if (IS_ATOM_INT(_62current_source_25984)) {
        _14460 = _62current_source_25984 + _62current_source_next_25985;
        if ((object)((uintptr_t)_14460 + (uintptr_t)HIGH_BITS) >= 0){
            _14460 = NewDouble((eudouble)_14460);
        }
    }
    else {
        _14460 = NewDouble(DBL_PTR(_62current_source_25984)->dbl + (eudouble)_62current_source_next_25985);
    }
    if (IS_ATOM_INT(_14460)){
        poke_addr = (uint8_t *)_14460;
    }
    else {
        poke_addr = (uint8_t *)(uintptr_t)(DBL_PTR(_14460)->dbl);
    }
    if (IS_ATOM_INT(_src_25989)) {
        *poke_addr = (uint8_t)_src_25989;
    }
    else if (IS_ATOM(_src_25989)) {
        *poke_addr = (uint8_t)DBL_PTR(_src_25989)->dbl;
    }
    else {
        _1 = (object)SEQ_PTR(_src_25989);
        _1 = (object)((s1_ptr)_1)->base;
        while (1) {
            _1 += sizeof(object);
            _2 = *((object *)_1);
            if (IS_ATOM_INT(_2)) {
                *poke_addr++ = (uint8_t)_2;
            }
            else if (_2 == NOVALUE) {
                break;
            }
            else {
                *poke_addr++ = (uint8_t)DBL_PTR(_2)->dbl;
            }
        }
    }
    DeRef(_14460);
    _14460 = NOVALUE;

    /** scanner.e:218		current_source_next += length(src)-1*/
    if (IS_SEQUENCE(_src_25989)){
            _14461 = SEQ_PTR(_src_25989)->length;
    }
    else {
        _14461 = 1;
    }
    _14462 = _14461 - 1;
    _14461 = NOVALUE;
    _62current_source_next_25985 = _62current_source_next_25985 + _14462;
    _14462 = NOVALUE;

    /** scanner.e:219		poke(current_source+current_source_next, 0) -- overwrite \n*/
    if (IS_ATOM_INT(_62current_source_25984)) {
        _14464 = _62current_source_25984 + _62current_source_next_25985;
        if ((object)((uintptr_t)_14464 + (uintptr_t)HIGH_BITS) >= 0){
            _14464 = NewDouble((eudouble)_14464);
        }
    }
    else {
        _14464 = NewDouble(DBL_PTR(_62current_source_25984)->dbl + (eudouble)_62current_source_next_25985);
    }
    if (IS_ATOM_INT(_14464)){
        poke_addr = (uint8_t *)_14464;
    }
    else {
        poke_addr = (uint8_t *)(uintptr_t)(DBL_PTR(_14464)->dbl);
    }
    *poke_addr = (uint8_t)0;
    DeRef(_14464);
    _14464 = NOVALUE;

    /** scanner.e:220		current_source_next += 1*/
    _62current_source_next_25985 = _62current_source_next_25985 + 1;

    /** scanner.e:221		return start + SOURCE_CHUNK * (length(all_source)-1)*/
    if (IS_SEQUENCE(_37all_source_15661)){
            _14466 = SEQ_PTR(_37all_source_15661)->length;
    }
    else {
        _14466 = 1;
    }
    _14467 = _14466 - 1;
    _14466 = NOVALUE;
    if (_14467 <= INT15){
        _14468 = 10000 * _14467;
    }
    else{
        _14468 = NewDouble(10000 * (eudouble)_14467);
    }
    _14467 = NOVALUE;
    if (IS_ATOM_INT(_14468)) {
        _14469 = _start_25990 + _14468;
        if ((object)((uintptr_t)_14469 + (uintptr_t)HIGH_BITS) >= 0){
            _14469 = NewDouble((eudouble)_14469);
        }
    }
    else {
        _14469 = NewDouble((eudouble)_start_25990 + DBL_PTR(_14468)->dbl);
    }
    DeRef(_14468);
    _14468 = NOVALUE;
    DeRef(_src_25989);
    return _14469;
    ;
}


object _62fetch_line(object _start_26024)
{
    object _line_26025 = NOVALUE;
    object _memdata_26026 = NOVALUE;
    object _c_26027 = NOVALUE;
    object _chunk_26028 = NOVALUE;
    object _p_26029 = NOVALUE;
    object _n_26030 = NOVALUE;
    object _m_26031 = NOVALUE;
    object _14494 = NOVALUE;
    object _14493 = NOVALUE;
    object _14491 = NOVALUE;
    object _14489 = NOVALUE;
    object _14483 = NOVALUE;
    object _14481 = NOVALUE;
    object _14477 = NOVALUE;
    object _14475 = NOVALUE;
    object _14472 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:234		if start = 0 then*/
    if (_start_26024 != 0)
    goto L1; // [5] 16

    /** scanner.e:235			return ""*/
    RefDS(_5);
    DeRef(_line_26025);
    DeRefi(_memdata_26026);
    DeRef(_p_26029);
    return _5;
L1: 

    /** scanner.e:237		line = repeat(0, LINE_BUFLEN)*/
    DeRef(_line_26025);
    _line_26025 = Repeat(0, 400);

    /** scanner.e:238		n = 0*/
    _n_26030 = 0;

    /** scanner.e:239		chunk = 1+floor(start / SOURCE_CHUNK)*/
    if (10000 > 0 && _start_26024 >= 0) {
        _14472 = _start_26024 / 10000;
    }
    else {
        temp_dbl = EUFLOOR((eudouble)_start_26024 / (eudouble)10000);
        _14472 = (object)temp_dbl;
    }
    _chunk_26028 = _14472 + 1;
    _14472 = NOVALUE;

    /** scanner.e:240		start = remainder(start, SOURCE_CHUNK)*/
    _start_26024 = (_start_26024 % 10000);

    /** scanner.e:241		p = all_source[chunk] + start*/
    _2 = (object)SEQ_PTR(_37all_source_15661);
    _14475 = (object)*(((s1_ptr)_2)->base + _chunk_26028);
    DeRef(_p_26029);
    if (IS_ATOM_INT(_14475)) {
        _p_26029 = _14475 + _start_26024;
        if ((object)((uintptr_t)_p_26029 + (uintptr_t)HIGH_BITS) >= 0){
            _p_26029 = NewDouble((eudouble)_p_26029);
        }
    }
    else {
        _p_26029 = NewDouble(DBL_PTR(_14475)->dbl + (eudouble)_start_26024);
    }
    _14475 = NOVALUE;

    /** scanner.e:242		memdata = peek({p, LINE_BUFLEN})*/
    Ref(_p_26029);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _p_26029;
    ((intptr_t *)_2)[2] = 400;
    _14477 = MAKE_SEQ(_1);
    DeRefi(_memdata_26026);
    _1 = (object)SEQ_PTR(_14477);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _memdata_26026 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    DeRefDS(_14477);
    _14477 = NOVALUE;

    /** scanner.e:243		p += LINE_BUFLEN*/
    _0 = _p_26029;
    if (IS_ATOM_INT(_p_26029)) {
        _p_26029 = _p_26029 + 400;
        if ((object)((uintptr_t)_p_26029 + (uintptr_t)HIGH_BITS) >= 0){
            _p_26029 = NewDouble((eudouble)_p_26029);
        }
    }
    else {
        _p_26029 = NewDouble(DBL_PTR(_p_26029)->dbl + (eudouble)400);
    }
    DeRef(_0);

    /** scanner.e:244		m = 0*/
    _m_26031 = 0;

    /** scanner.e:245		while TRUE do*/
L2: 
    if (_13TRUE_447 == 0)
    {
        goto L3; // [84] 179
    }
    else{
    }

    /** scanner.e:246			m += 1*/
    _m_26031 = _m_26031 + 1;

    /** scanner.e:247			if m > length(memdata) then*/
    if (IS_SEQUENCE(_memdata_26026)){
            _14481 = SEQ_PTR(_memdata_26026)->length;
    }
    else {
        _14481 = 1;
    }
    if (_m_26031 <= _14481)
    goto L4; // [98] 125

    /** scanner.e:248				memdata = peek({p, LINE_BUFLEN})*/
    Ref(_p_26029);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _p_26029;
    ((intptr_t *)_2)[2] = 400;
    _14483 = MAKE_SEQ(_1);
    DeRefDSi(_memdata_26026);
    _1 = (object)SEQ_PTR(_14483);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _memdata_26026 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    DeRefDS(_14483);
    _14483 = NOVALUE;

    /** scanner.e:249				p += LINE_BUFLEN*/
    _0 = _p_26029;
    if (IS_ATOM_INT(_p_26029)) {
        _p_26029 = _p_26029 + 400;
        if ((object)((uintptr_t)_p_26029 + (uintptr_t)HIGH_BITS) >= 0){
            _p_26029 = NewDouble((eudouble)_p_26029);
        }
    }
    else {
        _p_26029 = NewDouble(DBL_PTR(_p_26029)->dbl + (eudouble)400);
    }
    DeRef(_0);

    /** scanner.e:250				m = 1*/
    _m_26031 = 1;
L4: 

    /** scanner.e:252			c = memdata[m]*/
    _2 = (object)SEQ_PTR(_memdata_26026);
    _c_26027 = (object)*(((s1_ptr)_2)->base + _m_26031);

    /** scanner.e:253			if c = 0 then*/
    if (_c_26027 != 0)
    goto L5; // [133] 142

    /** scanner.e:254				exit*/
    goto L3; // [139] 179
L5: 

    /** scanner.e:256			n += 1*/
    _n_26030 = _n_26030 + 1;

    /** scanner.e:257			if n > length(line) then*/
    if (IS_SEQUENCE(_line_26025)){
            _14489 = SEQ_PTR(_line_26025)->length;
    }
    else {
        _14489 = 1;
    }
    if (_n_26030 <= _14489)
    goto L6; // [153] 168

    /** scanner.e:258				line &= repeat(0, LINE_BUFLEN)*/
    _14491 = Repeat(0, 400);
    Concat((object_ptr)&_line_26025, _line_26025, _14491);
    DeRefDS(_14491);
    _14491 = NOVALUE;
L6: 

    /** scanner.e:260			line[n] = c*/
    _2 = (object)SEQ_PTR(_line_26025);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _line_26025 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _n_26030);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _c_26027;
    DeRef(_1);

    /** scanner.e:261		end while*/
    goto L2; // [176] 82
L3: 

    /** scanner.e:262		line = remove( line, n+1, length( line ) )*/
    _14493 = _n_26030 + 1;
    if (_14493 > MAXINT){
        _14493 = NewDouble((eudouble)_14493);
    }
    if (IS_SEQUENCE(_line_26025)){
            _14494 = SEQ_PTR(_line_26025)->length;
    }
    else {
        _14494 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_line_26025);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_14493)) ? _14493 : (object)(DBL_PTR(_14493)->dbl);
        int stop = (IS_ATOM_INT(_14494)) ? _14494 : (object)(DBL_PTR(_14494)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_line_26025), start, &_line_26025 );
            }
            else Tail(SEQ_PTR(_line_26025), stop+1, &_line_26025);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_line_26025), start, &_line_26025);
        }
        else {
            assign_slice_seq = &assign_space;
            _line_26025 = Remove_elements(start, stop, (SEQ_PTR(_line_26025)->ref == 1));
        }
    }
    DeRef(_14493);
    _14493 = NOVALUE;
    _14494 = NOVALUE;

    /** scanner.e:263		return line*/
    DeRefi(_memdata_26026);
    DeRef(_p_26029);
    return _line_26025;
    ;
}


void _62AppendSourceLine()
{
    object _new_26067 = NOVALUE;
    object _old_26068 = NOVALUE;
    object _options_26069 = NOVALUE;
    object _src_26070 = NOVALUE;
    object _14535 = NOVALUE;
    object _14531 = NOVALUE;
    object _14529 = NOVALUE;
    object _14528 = NOVALUE;
    object _14525 = NOVALUE;
    object _14524 = NOVALUE;
    object _14523 = NOVALUE;
    object _14522 = NOVALUE;
    object _14521 = NOVALUE;
    object _14520 = NOVALUE;
    object _14519 = NOVALUE;
    object _14518 = NOVALUE;
    object _14517 = NOVALUE;
    object _14516 = NOVALUE;
    object _14515 = NOVALUE;
    object _14514 = NOVALUE;
    object _14513 = NOVALUE;
    object _14512 = NOVALUE;
    object _14511 = NOVALUE;
    object _14510 = NOVALUE;
    object _14509 = NOVALUE;
    object _14508 = NOVALUE;
    object _14506 = NOVALUE;
    object _14505 = NOVALUE;
    object _14504 = NOVALUE;
    object _14502 = NOVALUE;
    object _14497 = NOVALUE;
    object _14496 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:272		src = 0*/
    DeRef(_src_26070);
    _src_26070 = 0;

    /** scanner.e:273		options = 0*/
    _options_26069 = 0;

    /** scanner.e:275		if TRANSLATE or OpTrace or OpProfileStatement or OpProfileTime then*/
    if (_36TRANSLATE_21369 != 0) {
        _14496 = 1;
        goto L1; // [15] 25
    }
    _14496 = (_36OpTrace_21840 != 0);
L1: 
    if (_14496 != 0) {
        _14497 = 1;
        goto L2; // [25] 35
    }
    _14497 = (_36OpProfileStatement_21842 != 0);
L2: 
    if (_14497 != 0) {
        goto L3; // [35] 46
    }
    if (_36OpProfileTime_21843 == 0)
    {
        goto L4; // [42] 136
    }
    else{
    }
L3: 

    /** scanner.e:277			src = ThisLine*/
    Ref(_50ThisLine_49594);
    DeRef(_src_26070);
    _src_26070 = _50ThisLine_49594;

    /** scanner.e:279			if OpTrace then*/
    if (_36OpTrace_21840 == 0)
    {
        goto L5; // [57] 70
    }
    else{
    }

    /** scanner.e:280				options = SOP_TRACE*/
    _options_26069 = 1;
L5: 

    /** scanner.e:282			if OpProfileTime then*/
    if (_36OpProfileTime_21843 == 0)
    {
        goto L6; // [74] 88
    }
    else{
    }

    /** scanner.e:283				options = or_bits(options, SOP_PROFILE_TIME)*/
    {uintptr_t tu;
         tu = (uintptr_t)_options_26069 | (uintptr_t)2;
         _options_26069 = MAKE_UINT(tu);
    }
    if (!IS_ATOM_INT(_options_26069)) {
        _1 = (object)(DBL_PTR(_options_26069)->dbl);
        DeRefDS(_options_26069);
        _options_26069 = _1;
    }
L6: 

    /** scanner.e:285			if OpProfileStatement then*/
    if (_36OpProfileStatement_21842 == 0)
    {
        goto L7; // [92] 106
    }
    else{
    }

    /** scanner.e:286				options = or_bits(options, SOP_PROFILE_STATEMENT)*/
    {uintptr_t tu;
         tu = (uintptr_t)_options_26069 | (uintptr_t)4;
         _options_26069 = MAKE_UINT(tu);
    }
    if (!IS_ATOM_INT(_options_26069)) {
        _1 = (object)(DBL_PTR(_options_26069)->dbl);
        DeRefDS(_options_26069);
        _options_26069 = _1;
    }
L7: 

    /** scanner.e:288			if OpProfileStatement or OpProfileTime then*/
    if (_36OpProfileStatement_21842 != 0) {
        goto L8; // [110] 121
    }
    if (_36OpProfileTime_21843 == 0)
    {
        goto L9; // [117] 135
    }
    else{
    }
L8: 

    /** scanner.e:289				src = {0,0,0,0} & src*/
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 0;
    ((intptr_t*)_2)[2] = 0;
    ((intptr_t*)_2)[3] = 0;
    ((intptr_t*)_2)[4] = 0;
    _14502 = MAKE_SEQ(_1);
    if (IS_SEQUENCE(_14502) && IS_ATOM(_src_26070)) {
        Ref(_src_26070);
        Append(&_src_26070, _14502, _src_26070);
    }
    else if (IS_ATOM(_14502) && IS_SEQUENCE(_src_26070)) {
    }
    else {
        Concat((object_ptr)&_src_26070, _14502, _src_26070);
        DeRefDS(_14502);
        _14502 = NOVALUE;
    }
    DeRef(_14502);
    _14502 = NOVALUE;
L9: 
L4: 

    /** scanner.e:293		if length(slist) then*/
    if (IS_SEQUENCE(_36slist_21861)){
            _14504 = SEQ_PTR(_36slist_21861)->length;
    }
    else {
        _14504 = 1;
    }
    if (_14504 == 0)
    {
        _14504 = NOVALUE;
        goto LA; // [143] 345
    }
    else{
        _14504 = NOVALUE;
    }

    /** scanner.e:294			old = slist[$-1]*/
    if (IS_SEQUENCE(_36slist_21861)){
            _14505 = SEQ_PTR(_36slist_21861)->length;
    }
    else {
        _14505 = 1;
    }
    _14506 = _14505 - 1;
    _14505 = NOVALUE;
    DeRef(_old_26068);
    _2 = (object)SEQ_PTR(_36slist_21861);
    _old_26068 = (object)*(((s1_ptr)_2)->base + _14506);
    Ref(_old_26068);

    /** scanner.e:296			if equal(src, old[SRC]) and*/
    _2 = (object)SEQ_PTR(_old_26068);
    _14508 = (object)*(((s1_ptr)_2)->base + 1);
    if (_src_26070 == _14508)
    _14509 = 1;
    else if (IS_ATOM_INT(_src_26070) && IS_ATOM_INT(_14508))
    _14509 = 0;
    else
    _14509 = (compare(_src_26070, _14508) == 0);
    _14508 = NOVALUE;
    if (_14509 == 0) {
        _14510 = 0;
        goto LB; // [175] 195
    }
    _2 = (object)SEQ_PTR(_old_26068);
    _14511 = (object)*(((s1_ptr)_2)->base + 3);
    if (IS_ATOM_INT(_14511)) {
        _14512 = (_36current_file_no_21767 == _14511);
    }
    else {
        _14512 = binary_op(EQUALS, _36current_file_no_21767, _14511);
    }
    _14511 = NOVALUE;
    if (IS_ATOM_INT(_14512))
    _14510 = (_14512 != 0);
    else
    _14510 = DBL_PTR(_14512)->dbl != 0.0;
LB: 
    if (_14510 == 0) {
        _14513 = 0;
        goto LC; // [195] 232
    }
    _2 = (object)SEQ_PTR(_old_26068);
    _14514 = (object)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_14514)) {
        _14515 = _14514 + 1;
        if (_14515 > MAXINT){
            _14515 = NewDouble((eudouble)_14515);
        }
    }
    else
    _14515 = binary_op(PLUS, 1, _14514);
    _14514 = NOVALUE;
    if (IS_SEQUENCE(_36slist_21861)){
            _14516 = SEQ_PTR(_36slist_21861)->length;
    }
    else {
        _14516 = 1;
    }
    _2 = (object)SEQ_PTR(_36slist_21861);
    _14517 = (object)*(((s1_ptr)_2)->base + _14516);
    if (IS_ATOM_INT(_14515) && IS_ATOM_INT(_14517)) {
        _14518 = _14515 + _14517;
        if ((object)((uintptr_t)_14518 + (uintptr_t)HIGH_BITS) >= 0){
            _14518 = NewDouble((eudouble)_14518);
        }
    }
    else {
        _14518 = binary_op(PLUS, _14515, _14517);
    }
    DeRef(_14515);
    _14515 = NOVALUE;
    _14517 = NOVALUE;
    if (IS_ATOM_INT(_14518)) {
        _14519 = (_36line_number_21768 == _14518);
    }
    else {
        _14519 = binary_op(EQUALS, _36line_number_21768, _14518);
    }
    DeRef(_14518);
    _14518 = NOVALUE;
    if (IS_ATOM_INT(_14519))
    _14513 = (_14519 != 0);
    else
    _14513 = DBL_PTR(_14519)->dbl != 0.0;
LC: 
    if (_14513 == 0) {
        goto LD; // [232] 272
    }
    _2 = (object)SEQ_PTR(_old_26068);
    _14521 = (object)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_14521)) {
        _14522 = (_options_26069 == _14521);
    }
    else {
        _14522 = binary_op(EQUALS, _options_26069, _14521);
    }
    _14521 = NOVALUE;
    if (_14522 == 0) {
        DeRef(_14522);
        _14522 = NOVALUE;
        goto LD; // [247] 272
    }
    else {
        if (!IS_ATOM_INT(_14522) && DBL_PTR(_14522)->dbl == 0.0){
            DeRef(_14522);
            _14522 = NOVALUE;
            goto LD; // [247] 272
        }
        DeRef(_14522);
        _14522 = NOVALUE;
    }
    DeRef(_14522);
    _14522 = NOVALUE;

    /** scanner.e:302				slist[$] += 1*/
    if (IS_SEQUENCE(_36slist_21861)){
            _14523 = SEQ_PTR(_36slist_21861)->length;
    }
    else {
        _14523 = 1;
    }
    _2 = (object)SEQ_PTR(_36slist_21861);
    _14524 = (object)*(((s1_ptr)_2)->base + _14523);
    if (IS_ATOM_INT(_14524)) {
        _14525 = _14524 + 1;
        if (_14525 > MAXINT){
            _14525 = NewDouble((eudouble)_14525);
        }
    }
    else
    _14525 = binary_op(PLUS, 1, _14524);
    _14524 = NOVALUE;
    _2 = (object)SEQ_PTR(_36slist_21861);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _36slist_21861 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _14523);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14525;
    if( _1 != _14525 ){
        DeRef(_1);
    }
    _14525 = NOVALUE;
    goto LE; // [269] 371
LD: 

    /** scanner.e:304				src = pack_source(src)*/
    Ref(_src_26070);
    _0 = _src_26070;
    _src_26070 = _62pack_source(_src_26070);
    DeRef(_0);

    /** scanner.e:305				new = {src, line_number, current_file_no, options}*/
    _0 = _new_26067;
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_src_26070);
    ((intptr_t*)_2)[1] = _src_26070;
    ((intptr_t*)_2)[2] = _36line_number_21768;
    ((intptr_t*)_2)[3] = _36current_file_no_21767;
    ((intptr_t*)_2)[4] = _options_26069;
    _new_26067 = MAKE_SEQ(_1);
    DeRef(_0);

    /** scanner.e:306				if slist[$] = 0 then*/
    if (IS_SEQUENCE(_36slist_21861)){
            _14528 = SEQ_PTR(_36slist_21861)->length;
    }
    else {
        _14528 = 1;
    }
    _2 = (object)SEQ_PTR(_36slist_21861);
    _14529 = (object)*(((s1_ptr)_2)->base + _14528);
    if (binary_op_a(NOTEQ, _14529, 0)){
        _14529 = NOVALUE;
        goto LF; // [302] 320
    }
    _14529 = NOVALUE;

    /** scanner.e:307					slist[$] = new*/
    if (IS_SEQUENCE(_36slist_21861)){
            _14531 = SEQ_PTR(_36slist_21861)->length;
    }
    else {
        _14531 = 1;
    }
    RefDS(_new_26067);
    _2 = (object)SEQ_PTR(_36slist_21861);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _36slist_21861 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _14531);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _new_26067;
    DeRef(_1);
    goto L10; // [317] 331
LF: 

    /** scanner.e:309					slist = append(slist, new)*/
    RefDS(_new_26067);
    Append(&_36slist_21861, _36slist_21861, _new_26067);
L10: 

    /** scanner.e:311				slist = append(slist, 0)*/
    Append(&_36slist_21861, _36slist_21861, 0);
    goto LE; // [342] 371
LA: 

    /** scanner.e:314			src = pack_source(src)*/
    Ref(_src_26070);
    _0 = _src_26070;
    _src_26070 = _62pack_source(_src_26070);
    DeRef(_0);

    /** scanner.e:315			slist = {{src, line_number, current_file_no, options}, 0}*/
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_src_26070);
    ((intptr_t*)_2)[1] = _src_26070;
    ((intptr_t*)_2)[2] = _36line_number_21768;
    ((intptr_t*)_2)[3] = _36current_file_no_21767;
    ((intptr_t*)_2)[4] = _options_26069;
    _14535 = MAKE_SEQ(_1);
    DeRef(_36slist_21861);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _14535;
    ((intptr_t *)_2)[2] = 0;
    _36slist_21861 = MAKE_SEQ(_1);
    _14535 = NOVALUE;
LE: 

    /** scanner.e:317	end procedure*/
    DeRef(_new_26067);
    DeRef(_old_26068);
    DeRef(_src_26070);
    DeRef(_14512);
    _14512 = NOVALUE;
    DeRef(_14519);
    _14519 = NOVALUE;
    DeRef(_14506);
    _14506 = NOVALUE;
    return;
    ;
}


object _62s_expand(object _slist_26159)
{
    object _new_slist_26160 = NOVALUE;
    object _14549 = NOVALUE;
    object _14548 = NOVALUE;
    object _14547 = NOVALUE;
    object _14546 = NOVALUE;
    object _14544 = NOVALUE;
    object _14543 = NOVALUE;
    object _14542 = NOVALUE;
    object _14540 = NOVALUE;
    object _14539 = NOVALUE;
    object _14538 = NOVALUE;
    object _14537 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** scanner.e:323		new_slist = {}*/
    RefDS(_5);
    DeRef(_new_slist_26160);
    _new_slist_26160 = _5;

    /** scanner.e:325		for i = 1 to length(slist) do*/
    if (IS_SEQUENCE(_slist_26159)){
            _14537 = SEQ_PTR(_slist_26159)->length;
    }
    else {
        _14537 = 1;
    }
    {
        object _i_26162;
        _i_26162 = 1;
L1: 
        if (_i_26162 > _14537){
            goto L2; // [15] 114
        }

        /** scanner.e:326			if sequence(slist[i]) then*/
        _2 = (object)SEQ_PTR(_slist_26159);
        _14538 = (object)*(((s1_ptr)_2)->base + _i_26162);
        _14539 = IS_SEQUENCE(_14538);
        _14538 = NOVALUE;
        if (_14539 == 0)
        {
            _14539 = NOVALUE;
            goto L3; // [31] 47
        }
        else{
            _14539 = NOVALUE;
        }

        /** scanner.e:327				new_slist = append(new_slist, slist[i])*/
        _2 = (object)SEQ_PTR(_slist_26159);
        _14540 = (object)*(((s1_ptr)_2)->base + _i_26162);
        Ref(_14540);
        Append(&_new_slist_26160, _new_slist_26160, _14540);
        _14540 = NOVALUE;
        goto L4; // [44] 107
L3: 

        /** scanner.e:329				for j = 1 to slist[i] do*/
        _2 = (object)SEQ_PTR(_slist_26159);
        _14542 = (object)*(((s1_ptr)_2)->base + _i_26162);
        {
            object _j_26171;
            _j_26171 = 1;
L5: 
            if (binary_op_a(GREATER, _j_26171, _14542)){
                goto L6; // [53] 106
            }

            /** scanner.e:330					slist[i-1][LINE] += 1*/
            _14543 = _i_26162 - 1;
            _2 = (object)SEQ_PTR(_slist_26159);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _slist_26159 = MAKE_SEQ(_2);
            }
            _3 = (object)(_14543 + ((s1_ptr)_2)->base);
            _2 = (object)SEQ_PTR(*(intptr_t *)_3);
            _14546 = (object)*(((s1_ptr)_2)->base + 2);
            _14544 = NOVALUE;
            if (IS_ATOM_INT(_14546)) {
                _14547 = _14546 + 1;
                if (_14547 > MAXINT){
                    _14547 = NewDouble((eudouble)_14547);
                }
            }
            else
            _14547 = binary_op(PLUS, 1, _14546);
            _14546 = NOVALUE;
            _2 = (object)SEQ_PTR(*(intptr_t *)_3);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                *(intptr_t *)_3 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + 2);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _14547;
            if( _1 != _14547 ){
                DeRef(_1);
            }
            _14547 = NOVALUE;
            _14544 = NOVALUE;

            /** scanner.e:331					new_slist = append(new_slist, slist[i-1])*/
            _14548 = _i_26162 - 1;
            _2 = (object)SEQ_PTR(_slist_26159);
            _14549 = (object)*(((s1_ptr)_2)->base + _14548);
            Ref(_14549);
            Append(&_new_slist_26160, _new_slist_26160, _14549);
            _14549 = NOVALUE;

            /** scanner.e:332				end for*/
            _0 = _j_26171;
            if (IS_ATOM_INT(_j_26171)) {
                _j_26171 = _j_26171 + 1;
                if ((object)((uintptr_t)_j_26171 +(uintptr_t) HIGH_BITS) >= 0){
                    _j_26171 = NewDouble((eudouble)_j_26171);
                }
            }
            else {
                _j_26171 = binary_op_a(PLUS, _j_26171, 1);
            }
            DeRef(_0);
            goto L5; // [101] 60
L6: 
            ;
            DeRef(_j_26171);
        }
L4: 

        /** scanner.e:334		end for*/
        _i_26162 = _i_26162 + 1;
        goto L1; // [109] 22
L2: 
        ;
    }

    /** scanner.e:335		return new_slist*/
    DeRefDS(_slist_26159);
    DeRef(_14543);
    _14543 = NOVALUE;
    DeRef(_14548);
    _14548 = NOVALUE;
    _14542 = NOVALUE;
    return _new_slist_26160;
    ;
}


void _62set_dont_read(object _read_26186)
{
    object _0, _1, _2;
    

    /** scanner.e:357		dont_read = read*/
    _62dont_read_26183 = _read_26186;

    /** scanner.e:358	end procedure*/
    return;
    ;
}


void _62read_line()
{
    object _n_26192 = NOVALUE;
    object _14579 = NOVALUE;
    object _14578 = NOVALUE;
    object _14577 = NOVALUE;
    object _14576 = NOVALUE;
    object _14575 = NOVALUE;
    object _14573 = NOVALUE;
    object _14572 = NOVALUE;
    object _14570 = NOVALUE;
    object _14569 = NOVALUE;
    object _14568 = NOVALUE;
    object _14567 = NOVALUE;
    object _14559 = NOVALUE;
    object _14557 = NOVALUE;
    object _14556 = NOVALUE;
    object _14555 = NOVALUE;
    object _14554 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:367		line_number += 1*/
    _36line_number_21768 = _36line_number_21768 + 1;

    /** scanner.e:368		gline_number += 1*/
    _36gline_number_21772 = _36gline_number_21772 + 1;

    /** scanner.e:370		if dont_read then*/
    if (_62dont_read_26183 == 0)
    {
        goto L1; // [25] 36
    }
    else{
    }

    /** scanner.e:371			ThisLine = -1*/
    DeRef(_50ThisLine_49594);
    _50ThisLine_49594 = -1;
    goto L2; // [33] 216
L1: 

    /** scanner.e:372		elsif repl and src_file = repl_file then*/
    if (0 == 0) {
        goto L3; // [40] 144
    }
    _14555 = (_36src_file_21892 == 5555);
    if (_14555 == 0)
    {
        DeRef(_14555);
        _14555 = NOVALUE;
        goto L3; // [53] 144
    }
    else{
        DeRef(_14555);
        _14555 = NOVALUE;
    }

    /** scanner.e:373			if repl_line_was_read and current_block = top_level_block then*/
    if (_62repl_line_was_read_26187 == 0) {
        goto L4; // [60] 118
    }
    _14557 = (_65current_block_25440 == _65top_level_block_25441);
    if (_14557 == 0)
    {
        DeRef(_14557);
        _14557 = NOVALUE;
        goto L4; // [73] 118
    }
    else{
        DeRef(_14557);
        _14557 = NOVALUE;
    }

    /** scanner.e:374				if repl_line_was_read > 1 then*/
    if (_62repl_line_was_read_26187 <= 1)
    goto L5; // [80] 110

    /** scanner.e:375					if not match("end", ThisLine) then*/
    _14559 = e_match_from(_13333, _50ThisLine_49594, 1);
    if (_14559 != 0)
    goto L6; // [93] 109
    _14559 = NOVALUE;

    /** scanner.e:376						goto "lol"*/
    goto G7;
L6: 
L5: 

    /** scanner.e:379				ThisLine = -1*/
    DeRef(_50ThisLine_49594);
    _50ThisLine_49594 = -1;
    goto L2; // [115] 216
L4: 

    /** scanner.e:381				label "lol"*/
G7:

    /** scanner.e:382				puts(1, "Enter line:\n")*/
    EPuts(1, _14562); // DJP 

    /** scanner.e:383				repl_line_was_read += 1*/
    _62repl_line_was_read_26187 = _62repl_line_was_read_26187 + 1;

    /** scanner.e:384				ThisLine = gets(0)*/
    DeRef(_50ThisLine_49594);
    _50ThisLine_49594 = EGets(0);
    goto L2; // [141] 216
L3: 

    /** scanner.e:386		elsif src_file < 0 then*/
    if (_36src_file_21892 >= 0)
    goto L8; // [148] 160

    /** scanner.e:387			ThisLine = -1*/
    DeRef(_50ThisLine_49594);
    _50ThisLine_49594 = -1;
    goto L2; // [157] 216
L8: 

    /** scanner.e:389			ThisLine = gets(src_file)*/
    DeRef(_50ThisLine_49594);
    _50ThisLine_49594 = EGets(_36src_file_21892);

    /** scanner.e:390			if sequence(ThisLine) and ends( {13,10}, ThisLine ) then*/
    _14567 = IS_SEQUENCE(_50ThisLine_49594);
    if (_14567 == 0) {
        goto L9; // [174] 215
    }
    RefDS(_12363);
    Ref(_50ThisLine_49594);
    _14569 = _16ends(_12363, _50ThisLine_49594);
    if (_14569 == 0) {
        DeRef(_14569);
        _14569 = NOVALUE;
        goto L9; // [186] 215
    }
    else {
        if (!IS_ATOM_INT(_14569) && DBL_PTR(_14569)->dbl == 0.0){
            DeRef(_14569);
            _14569 = NOVALUE;
            goto L9; // [186] 215
        }
        DeRef(_14569);
        _14569 = NOVALUE;
    }
    DeRef(_14569);
    _14569 = NOVALUE;

    /** scanner.e:391				ThisLine = remove(ThisLine, length(ThisLine))*/
    if (IS_SEQUENCE(_50ThisLine_49594)){
            _14570 = SEQ_PTR(_50ThisLine_49594)->length;
    }
    else {
        _14570 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_50ThisLine_49594);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_14570)) ? _14570 : (object)(DBL_PTR(_14570)->dbl);
        int stop = (IS_ATOM_INT(_14570)) ? _14570 : (object)(DBL_PTR(_14570)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_50ThisLine_49594), start, &_50ThisLine_49594 );
            }
            else Tail(SEQ_PTR(_50ThisLine_49594), stop+1, &_50ThisLine_49594);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_50ThisLine_49594), start, &_50ThisLine_49594);
        }
        else {
            assign_slice_seq = &assign_space;
            _50ThisLine_49594 = Remove_elements(start, stop, (SEQ_PTR(_50ThisLine_49594)->ref == 1));
        }
    }
    _14570 = NOVALUE;
    _14570 = NOVALUE;

    /** scanner.e:392				ThisLine[$] = 10*/
    if (IS_SEQUENCE(_50ThisLine_49594)){
            _14572 = SEQ_PTR(_50ThisLine_49594)->length;
    }
    else {
        _14572 = 1;
    }
    _2 = (object)SEQ_PTR(_50ThisLine_49594);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _50ThisLine_49594 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _14572);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 10;
    DeRef(_1);
L9: 
L2: 

    /** scanner.e:395		if atom(ThisLine) then*/
    _14573 = IS_ATOM(_50ThisLine_49594);
    if (_14573 == 0)
    {
        _14573 = NOVALUE;
        goto LA; // [223] 286
    }
    else{
        _14573 = NOVALUE;
    }

    /** scanner.e:396			ThisLine = {END_OF_FILE_CHAR}*/
    _0 = _50ThisLine_49594;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 26;
    _50ThisLine_49594 = MAKE_SEQ(_1);
    DeRef(_0);

    /** scanner.e:397			if src_file >= 0 and (src_file != repl_file or not repl) then*/
    _14575 = (_36src_file_21892 >= 0);
    if (_14575 == 0) {
        goto LB; // [242] 278
    }
    _14577 = (_36src_file_21892 != 5555);
    if (_14577 != 0) {
        DeRef(_14578);
        _14578 = 1;
        goto LC; // [254] 267
    }
    _14579 = (0 == 0);
    _14578 = (_14579 != 0);
LC: 
    if (_14578 == 0)
    {
        _14578 = NOVALUE;
        goto LB; // [268] 278
    }
    else{
        _14578 = NOVALUE;
    }

    /** scanner.e:398				close(src_file)*/
    EClose(_36src_file_21892);
LB: 

    /** scanner.e:400			src_file = -1*/
    _36src_file_21892 = -1;
LA: 

    /** scanner.e:403		bp = 1*/
    _50bp_49598 = 1;

    /** scanner.e:411		AppendSourceLine()*/
    _62AppendSourceLine();

    /** scanner.e:412	end procedure*/
    DeRef(_14575);
    _14575 = NOVALUE;
    DeRef(_14579);
    _14579 = NOVALUE;
    DeRef(_14577);
    _14577 = NOVALUE;
    return;
    ;
}


object _62getch()
{
    object _c_26266 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:417		c = ThisLine[bp]*/
    _2 = (object)SEQ_PTR(_50ThisLine_49594);
    _c_26266 = (object)*(((s1_ptr)_2)->base + _50bp_49598);
    if (!IS_ATOM_INT(_c_26266)){
        _c_26266 = (object)DBL_PTR(_c_26266)->dbl;
    }

    /** scanner.e:418		bp += 1*/
    _50bp_49598 = _50bp_49598 + 1;

    /** scanner.e:419		return c*/
    return _c_26266;
    ;
}


void _62ungetch()
{
    object _0, _1, _2;
    

    /** scanner.e:424		bp -= 1*/
    _50bp_49598 = _50bp_49598 - 1;

    /** scanner.e:425	end procedure*/
    return;
    ;
}


object _62get_file_path(object _s_26278)
{
    object _14588 = NOVALUE;
    object _14586 = NOVALUE;
    object _14585 = NOVALUE;
    object _14584 = NOVALUE;
    object _14583 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:429			for t=length(s) to 1 by -1 do*/
    if (IS_SEQUENCE(_s_26278)){
            _14583 = SEQ_PTR(_s_26278)->length;
    }
    else {
        _14583 = 1;
    }
    {
        object _t_26280;
        _t_26280 = _14583;
L1: 
        if (_t_26280 < 1){
            goto L2; // [8] 50
        }

        /** scanner.e:430					if find(s[t],SLASH_CHARS) then*/
        _2 = (object)SEQ_PTR(_s_26278);
        _14584 = (object)*(((s1_ptr)_2)->base + _t_26280);
        _14585 = find_from(_14584, _46SLASH_CHARS_21935, 1);
        _14584 = NOVALUE;
        if (_14585 == 0)
        {
            _14585 = NOVALUE;
            goto L3; // [28] 43
        }
        else{
            _14585 = NOVALUE;
        }

        /** scanner.e:431							return s[1..t]*/
        rhs_slice_target = (object_ptr)&_14586;
        RHS_Slice(_s_26278, 1, _t_26280);
        DeRefDS(_s_26278);
        return _14586;
L3: 

        /** scanner.e:433			end for*/
        _t_26280 = _t_26280 + -1;
        goto L1; // [45] 15
L2: 
        ;
    }

    /** scanner.e:435			return "." & SLASH*/
    Append(&_14588, _14587, 92);
    DeRefDS(_s_26278);
    DeRef(_14586);
    _14586 = NOVALUE;
    return _14588;
    ;
}


object _62find_file(object _fname_26292)
{
    object _try_26293 = NOVALUE;
    object _full_path_26294 = NOVALUE;
    object _errbuff_26295 = NOVALUE;
    object _currdir_26296 = NOVALUE;
    object _conf_path_26297 = NOVALUE;
    object _scan_result_26298 = NOVALUE;
    object _inc_path_26299 = NOVALUE;
    object _mainpath_26319 = NOVALUE;
    object _31992 = NOVALUE;
    object _31991 = NOVALUE;
    object _14685 = NOVALUE;
    object _14683 = NOVALUE;
    object _14682 = NOVALUE;
    object _14681 = NOVALUE;
    object _14679 = NOVALUE;
    object _14677 = NOVALUE;
    object _14675 = NOVALUE;
    object _14674 = NOVALUE;
    object _14672 = NOVALUE;
    object _14671 = NOVALUE;
    object _14668 = NOVALUE;
    object _14665 = NOVALUE;
    object _14664 = NOVALUE;
    object _14663 = NOVALUE;
    object _14662 = NOVALUE;
    object _14661 = NOVALUE;
    object _14660 = NOVALUE;
    object _14659 = NOVALUE;
    object _14658 = NOVALUE;
    object _14655 = NOVALUE;
    object _14654 = NOVALUE;
    object _14650 = NOVALUE;
    object _14647 = NOVALUE;
    object _14646 = NOVALUE;
    object _14645 = NOVALUE;
    object _14644 = NOVALUE;
    object _14643 = NOVALUE;
    object _14642 = NOVALUE;
    object _14641 = NOVALUE;
    object _14640 = NOVALUE;
    object _14637 = NOVALUE;
    object _14633 = NOVALUE;
    object _14631 = NOVALUE;
    object _14630 = NOVALUE;
    object _14629 = NOVALUE;
    object _14628 = NOVALUE;
    object _14627 = NOVALUE;
    object _14624 = NOVALUE;
    object _14623 = NOVALUE;
    object _14622 = NOVALUE;
    object _14621 = NOVALUE;
    object _14620 = NOVALUE;
    object _14619 = NOVALUE;
    object _14617 = NOVALUE;
    object _14616 = NOVALUE;
    object _14615 = NOVALUE;
    object _14614 = NOVALUE;
    object _14613 = NOVALUE;
    object _14611 = NOVALUE;
    object _14610 = NOVALUE;
    object _14607 = NOVALUE;
    object _14604 = NOVALUE;
    object _14602 = NOVALUE;
    object _14599 = NOVALUE;
    object _14597 = NOVALUE;
    object _14596 = NOVALUE;
    object _14593 = NOVALUE;
    object _14592 = NOVALUE;
    object _14590 = NOVALUE;
    object _14589 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:449		if absolute_path(fname) then*/
    RefDS(_fname_26292);
    _14589 = _17absolute_path(_fname_26292);
    if (_14589 == 0) {
        DeRef(_14589);
        _14589 = NOVALUE;
        goto L1; // [9] 44
    }
    else {
        if (!IS_ATOM_INT(_14589) && DBL_PTR(_14589)->dbl == 0.0){
            DeRef(_14589);
            _14589 = NOVALUE;
            goto L1; // [9] 44
        }
        DeRef(_14589);
        _14589 = NOVALUE;
    }
    DeRef(_14589);
    _14589 = NOVALUE;

    /** scanner.e:451			if not file_exists(fname) then*/
    RefDS(_fname_26292);
    _14590 = _17file_exists(_fname_26292);
    if (IS_ATOM_INT(_14590)) {
        if (_14590 != 0){
            DeRef(_14590);
            _14590 = NOVALUE;
            goto L2; // [18] 37
        }
    }
    else {
        if (DBL_PTR(_14590)->dbl != 0.0){
            DeRef(_14590);
            _14590 = NOVALUE;
            goto L2; // [18] 37
        }
    }
    DeRef(_14590);
    _14590 = NOVALUE;

    /** scanner.e:452				CompileErr(CANT_OPEN_1, {new_include_name})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_36new_include_name_21893);
    ((intptr_t*)_2)[1] = _36new_include_name_21893;
    _14592 = MAKE_SEQ(_1);
    _50CompileErr(51, _14592, 0);
    _14592 = NOVALUE;
L2: 

    /** scanner.e:455			return fname*/
    DeRef(_full_path_26294);
    DeRef(_errbuff_26295);
    DeRef(_currdir_26296);
    DeRef(_conf_path_26297);
    DeRef(_scan_result_26298);
    DeRef(_inc_path_26299);
    DeRef(_mainpath_26319);
    return _fname_26292;
L1: 

    /** scanner.e:460		currdir = get_file_path( known_files[current_file_no] )*/
    _2 = (object)SEQ_PTR(_37known_files_15638);
    _14593 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21767);
    Ref(_14593);
    _0 = _currdir_26296;
    _currdir_26296 = _62get_file_path(_14593);
    DeRef(_0);
    _14593 = NOVALUE;

    /** scanner.e:461		full_path = currdir & fname*/
    Concat((object_ptr)&_full_path_26294, _currdir_26296, _fname_26292);

    /** scanner.e:462		if file_exists(full_path) then*/
    RefDS(_full_path_26294);
    _14596 = _17file_exists(_full_path_26294);
    if (_14596 == 0) {
        DeRef(_14596);
        _14596 = NOVALUE;
        goto L3; // [72] 82
    }
    else {
        if (!IS_ATOM_INT(_14596) && DBL_PTR(_14596)->dbl == 0.0){
            DeRef(_14596);
            _14596 = NOVALUE;
            goto L3; // [72] 82
        }
        DeRef(_14596);
        _14596 = NOVALUE;
    }
    DeRef(_14596);
    _14596 = NOVALUE;

    /** scanner.e:463			return full_path*/
    DeRefDS(_fname_26292);
    DeRef(_errbuff_26295);
    DeRefDS(_currdir_26296);
    DeRef(_conf_path_26297);
    DeRef(_scan_result_26298);
    DeRef(_inc_path_26299);
    DeRef(_mainpath_26319);
    return _full_path_26294;
L3: 

    /** scanner.e:467		sequence mainpath = main_path[1..rfind(SLASH, main_path)]*/
    RefDS(_36main_path_21891);
    DeRef(_31991);
    _31991 = _36main_path_21891;
    if (IS_SEQUENCE(_31991)){
            _31992 = SEQ_PTR(_31991)->length;
    }
    else {
        _31992 = 1;
    }
    _31991 = NOVALUE;
    RefDS(_36main_path_21891);
    _14597 = _16rfind(92, _36main_path_21891, _31992);
    _31992 = NOVALUE;
    rhs_slice_target = (object_ptr)&_mainpath_26319;
    RHS_Slice(_36main_path_21891, 1, _14597);

    /** scanner.e:468		if not equal(mainpath, currdir) then*/
    if (_mainpath_26319 == _currdir_26296)
    _14599 = 1;
    else if (IS_ATOM_INT(_mainpath_26319) && IS_ATOM_INT(_currdir_26296))
    _14599 = 0;
    else
    _14599 = (compare(_mainpath_26319, _currdir_26296) == 0);
    if (_14599 != 0)
    goto L4; // [113] 141
    _14599 = NOVALUE;

    /** scanner.e:469			full_path = mainpath & new_include_name*/
    Concat((object_ptr)&_full_path_26294, _mainpath_26319, _36new_include_name_21893);

    /** scanner.e:470			if file_exists(full_path) then*/
    RefDS(_full_path_26294);
    _14602 = _17file_exists(_full_path_26294);
    if (_14602 == 0) {
        DeRef(_14602);
        _14602 = NOVALUE;
        goto L5; // [130] 140
    }
    else {
        if (!IS_ATOM_INT(_14602) && DBL_PTR(_14602)->dbl == 0.0){
            DeRef(_14602);
            _14602 = NOVALUE;
            goto L5; // [130] 140
        }
        DeRef(_14602);
        _14602 = NOVALUE;
    }
    DeRef(_14602);
    _14602 = NOVALUE;

    /** scanner.e:471				return full_path*/
    DeRefDS(_fname_26292);
    DeRef(_errbuff_26295);
    DeRefDS(_currdir_26296);
    DeRef(_conf_path_26297);
    DeRef(_scan_result_26298);
    DeRef(_inc_path_26299);
    DeRefDS(_mainpath_26319);
    DeRef(_14597);
    _14597 = NOVALUE;
    _31991 = NOVALUE;
    return _full_path_26294;
L5: 
L4: 

    /** scanner.e:475		scan_result = ConfPath(new_include_name)*/
    RefDS(_36new_include_name_21893);
    _0 = _scan_result_26298;
    _scan_result_26298 = _48ConfPath(_36new_include_name_21893);
    DeRef(_0);

    /** scanner.e:477		if atom(scan_result) then*/
    _14604 = IS_ATOM(_scan_result_26298);
    if (_14604 == 0)
    {
        _14604 = NOVALUE;
        goto L6; // [154] 166
    }
    else{
        _14604 = NOVALUE;
    }

    /** scanner.e:478			scan_result = ScanPath(fname,"EUINC",0)*/
    RefDS(_fname_26292);
    RefDS(_14605);
    _0 = _scan_result_26298;
    _scan_result_26298 = _48ScanPath(_fname_26292, _14605, 0);
    DeRef(_0);
L6: 

    /** scanner.e:481		if atom(scan_result) then*/
    _14607 = IS_ATOM(_scan_result_26298);
    if (_14607 == 0)
    {
        _14607 = NOVALUE;
        goto L7; // [171] 183
    }
    else{
        _14607 = NOVALUE;
    }

    /** scanner.e:482			scan_result = ScanPath(fname, "EUDIR",1)*/
    RefDS(_fname_26292);
    RefDS(_14608);
    _0 = _scan_result_26298;
    _scan_result_26298 = _48ScanPath(_fname_26292, _14608, 1);
    DeRef(_0);
L7: 

    /** scanner.e:485		if atom(scan_result) then*/
    _14610 = IS_ATOM(_scan_result_26298);
    if (_14610 == 0)
    {
        _14610 = NOVALUE;
        goto L8; // [188] 225
    }
    else{
        _14610 = NOVALUE;
    }

    /** scanner.e:487			full_path = get_eudir() & SLASH & "include" & SLASH & fname*/
    _14611 = _37get_eudir();
    {
        object concat_list[5];

        concat_list[0] = _fname_26292;
        concat_list[1] = 92;
        concat_list[2] = _13371;
        concat_list[3] = 92;
        concat_list[4] = _14611;
        Concat_N((object_ptr)&_full_path_26294, concat_list, 5);
    }
    DeRef(_14611);
    _14611 = NOVALUE;

    /** scanner.e:488			if file_exists(full_path) then*/
    RefDS(_full_path_26294);
    _14613 = _17file_exists(_full_path_26294);
    if (_14613 == 0) {
        DeRef(_14613);
        _14613 = NOVALUE;
        goto L9; // [214] 224
    }
    else {
        if (!IS_ATOM_INT(_14613) && DBL_PTR(_14613)->dbl == 0.0){
            DeRef(_14613);
            _14613 = NOVALUE;
            goto L9; // [214] 224
        }
        DeRef(_14613);
        _14613 = NOVALUE;
    }
    DeRef(_14613);
    _14613 = NOVALUE;

    /** scanner.e:489				return full_path*/
    DeRefDS(_fname_26292);
    DeRef(_errbuff_26295);
    DeRef(_currdir_26296);
    DeRef(_conf_path_26297);
    DeRef(_scan_result_26298);
    DeRef(_inc_path_26299);
    DeRef(_mainpath_26319);
    DeRef(_14597);
    _14597 = NOVALUE;
    _31991 = NOVALUE;
    return _full_path_26294;
L9: 
L8: 

    /** scanner.e:493		if sequence(scan_result) then*/
    _14614 = IS_SEQUENCE(_scan_result_26298);
    if (_14614 == 0)
    {
        _14614 = NOVALUE;
        goto LA; // [230] 252
    }
    else{
        _14614 = NOVALUE;
    }

    /** scanner.e:495			close(scan_result[2])*/
    _2 = (object)SEQ_PTR(_scan_result_26298);
    _14615 = (object)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_14615))
    EClose(_14615);
    else
    EClose((object)DBL_PTR(_14615)->dbl);
    _14615 = NOVALUE;

    /** scanner.e:496			return scan_result[1]*/
    _2 = (object)SEQ_PTR(_scan_result_26298);
    _14616 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_14616);
    DeRefDS(_fname_26292);
    DeRef(_full_path_26294);
    DeRef(_errbuff_26295);
    DeRef(_currdir_26296);
    DeRef(_conf_path_26297);
    DeRef(_scan_result_26298);
    DeRef(_inc_path_26299);
    DeRef(_mainpath_26319);
    DeRef(_14597);
    _14597 = NOVALUE;
    _31991 = NOVALUE;
    return _14616;
LA: 

    /** scanner.e:500		errbuff = ""*/
    RefDS(_5);
    DeRef(_errbuff_26295);
    _errbuff_26295 = _5;

    /** scanner.e:501		full_path = {}*/
    RefDS(_5);
    DeRef(_full_path_26294);
    _full_path_26294 = _5;

    /** scanner.e:502		if length(currdir) > 0 then*/
    if (IS_SEQUENCE(_currdir_26296)){
            _14617 = SEQ_PTR(_currdir_26296)->length;
    }
    else {
        _14617 = 1;
    }
    if (_14617 <= 0)
    goto LB; // [271] 323

    /** scanner.e:503			if find(currdir[$], SLASH_CHARS) then*/
    if (IS_SEQUENCE(_currdir_26296)){
            _14619 = SEQ_PTR(_currdir_26296)->length;
    }
    else {
        _14619 = 1;
    }
    _2 = (object)SEQ_PTR(_currdir_26296);
    _14620 = (object)*(((s1_ptr)_2)->base + _14619);
    _14621 = find_from(_14620, _46SLASH_CHARS_21935, 1);
    _14620 = NOVALUE;
    if (_14621 == 0)
    {
        _14621 = NOVALUE;
        goto LC; // [291] 315
    }
    else{
        _14621 = NOVALUE;
    }

    /** scanner.e:504				full_path = append(full_path, currdir[1..$-1])*/
    if (IS_SEQUENCE(_currdir_26296)){
            _14622 = SEQ_PTR(_currdir_26296)->length;
    }
    else {
        _14622 = 1;
    }
    _14623 = _14622 - 1;
    _14622 = NOVALUE;
    rhs_slice_target = (object_ptr)&_14624;
    RHS_Slice(_currdir_26296, 1, _14623);
    RefDS(_14624);
    Append(&_full_path_26294, _full_path_26294, _14624);
    DeRefDS(_14624);
    _14624 = NOVALUE;
    goto LD; // [312] 322
LC: 

    /** scanner.e:506				full_path = append(full_path, currdir)*/
    RefDS(_currdir_26296);
    Append(&_full_path_26294, _full_path_26294, _currdir_26296);
LD: 
LB: 

    /** scanner.e:511		if find(main_path[$], SLASH_CHARS) then*/
    if (IS_SEQUENCE(_36main_path_21891)){
            _14627 = SEQ_PTR(_36main_path_21891)->length;
    }
    else {
        _14627 = 1;
    }
    _2 = (object)SEQ_PTR(_36main_path_21891);
    _14628 = (object)*(((s1_ptr)_2)->base + _14627);
    _14629 = find_from(_14628, _46SLASH_CHARS_21935, 1);
    _14628 = NOVALUE;
    if (_14629 == 0)
    {
        _14629 = NOVALUE;
        goto LE; // [341] 363
    }
    else{
        _14629 = NOVALUE;
    }

    /** scanner.e:512			errbuff = main_path[1..$-1]  -- looks better*/
    if (IS_SEQUENCE(_36main_path_21891)){
            _14630 = SEQ_PTR(_36main_path_21891)->length;
    }
    else {
        _14630 = 1;
    }
    _14631 = _14630 - 1;
    _14630 = NOVALUE;
    rhs_slice_target = (object_ptr)&_errbuff_26295;
    RHS_Slice(_36main_path_21891, 1, _14631);
    goto LF; // [360] 373
LE: 

    /** scanner.e:514			errbuff = main_path*/
    RefDS(_36main_path_21891);
    DeRef(_errbuff_26295);
    _errbuff_26295 = _36main_path_21891;
LF: 

    /** scanner.e:516		if not find(errbuff, full_path) then*/
    _14633 = find_from(_errbuff_26295, _full_path_26294, 1);
    if (_14633 != 0)
    goto L10; // [380] 390
    _14633 = NOVALUE;

    /** scanner.e:517			full_path = append(full_path, errbuff)*/
    RefDS(_errbuff_26295);
    Append(&_full_path_26294, _full_path_26294, _errbuff_26295);
L10: 

    /** scanner.e:520		conf_path = get_conf_dirs()*/
    _0 = _conf_path_26297;
    _conf_path_26297 = _48get_conf_dirs();
    DeRef(_0);

    /** scanner.e:521		if length(conf_path) > 0 then*/
    if (IS_SEQUENCE(_conf_path_26297)){
            _14637 = SEQ_PTR(_conf_path_26297)->length;
    }
    else {
        _14637 = 1;
    }
    if (_14637 <= 0)
    goto L11; // [402] 509

    /** scanner.e:522			conf_path = split(conf_path, PATHSEP)*/
    RefDS(_conf_path_26297);
    _0 = _conf_path_26297;
    _conf_path_26297 = _23split(_conf_path_26297, 59, 0, 0);
    DeRefDS(_0);

    /** scanner.e:523			for i = 1 to length(conf_path) do*/
    if (IS_SEQUENCE(_conf_path_26297)){
            _14640 = SEQ_PTR(_conf_path_26297)->length;
    }
    else {
        _14640 = 1;
    }
    {
        object _i_26400;
        _i_26400 = 1;
L12: 
        if (_i_26400 > _14640){
            goto L13; // [424] 508
        }

        /** scanner.e:524				if find(conf_path[i][$], SLASH_CHARS) then*/
        _2 = (object)SEQ_PTR(_conf_path_26297);
        _14641 = (object)*(((s1_ptr)_2)->base + _i_26400);
        if (IS_SEQUENCE(_14641)){
                _14642 = SEQ_PTR(_14641)->length;
        }
        else {
            _14642 = 1;
        }
        _2 = (object)SEQ_PTR(_14641);
        _14643 = (object)*(((s1_ptr)_2)->base + _14642);
        _14641 = NOVALUE;
        _14644 = find_from(_14643, _46SLASH_CHARS_21935, 1);
        _14643 = NOVALUE;
        if (_14644 == 0)
        {
            _14644 = NOVALUE;
            goto L14; // [451] 475
        }
        else{
            _14644 = NOVALUE;
        }

        /** scanner.e:525					errbuff = conf_path[i][1..$-1]  -- looks better*/
        _2 = (object)SEQ_PTR(_conf_path_26297);
        _14645 = (object)*(((s1_ptr)_2)->base + _i_26400);
        if (IS_SEQUENCE(_14645)){
                _14646 = SEQ_PTR(_14645)->length;
        }
        else {
            _14646 = 1;
        }
        _14647 = _14646 - 1;
        _14646 = NOVALUE;
        rhs_slice_target = (object_ptr)&_errbuff_26295;
        RHS_Slice(_14645, 1, _14647);
        _14645 = NOVALUE;
        goto L15; // [472] 484
L14: 

        /** scanner.e:527					errbuff = conf_path[i]*/
        DeRef(_errbuff_26295);
        _2 = (object)SEQ_PTR(_conf_path_26297);
        _errbuff_26295 = (object)*(((s1_ptr)_2)->base + _i_26400);
        Ref(_errbuff_26295);
L15: 

        /** scanner.e:529				if not find(errbuff, full_path) then*/
        _14650 = find_from(_errbuff_26295, _full_path_26294, 1);
        if (_14650 != 0)
        goto L16; // [491] 501
        _14650 = NOVALUE;

        /** scanner.e:530					full_path = append(full_path, errbuff)*/
        RefDS(_errbuff_26295);
        Append(&_full_path_26294, _full_path_26294, _errbuff_26295);
L16: 

        /** scanner.e:532			end for*/
        _i_26400 = _i_26400 + 1;
        goto L12; // [503] 431
L13: 
        ;
    }
L11: 

    /** scanner.e:535		inc_path = getenv("EUINC")*/
    DeRef(_inc_path_26299);
    _inc_path_26299 = EGetEnv(_14605);

    /** scanner.e:536		if sequence(inc_path) then*/
    _14654 = IS_SEQUENCE(_inc_path_26299);
    if (_14654 == 0)
    {
        _14654 = NOVALUE;
        goto L17; // [519] 633
    }
    else{
        _14654 = NOVALUE;
    }

    /** scanner.e:537			if length(inc_path) > 0 then*/
    if (IS_SEQUENCE(_inc_path_26299)){
            _14655 = SEQ_PTR(_inc_path_26299)->length;
    }
    else {
        _14655 = 1;
    }
    if (_14655 <= 0)
    goto L18; // [527] 632

    /** scanner.e:538				inc_path = split(inc_path, PATHSEP)*/
    Ref(_inc_path_26299);
    _0 = _inc_path_26299;
    _inc_path_26299 = _23split(_inc_path_26299, 59, 0, 0);
    DeRefi(_0);

    /** scanner.e:539				for i = 1 to length(inc_path) do*/
    if (IS_SEQUENCE(_inc_path_26299)){
            _14658 = SEQ_PTR(_inc_path_26299)->length;
    }
    else {
        _14658 = 1;
    }
    {
        object _i_26428;
        _i_26428 = 1;
L19: 
        if (_i_26428 > _14658){
            goto L1A; // [547] 631
        }

        /** scanner.e:540					if find(inc_path[i][$], SLASH_CHARS) then*/
        _2 = (object)SEQ_PTR(_inc_path_26299);
        _14659 = (object)*(((s1_ptr)_2)->base + _i_26428);
        if (IS_SEQUENCE(_14659)){
                _14660 = SEQ_PTR(_14659)->length;
        }
        else {
            _14660 = 1;
        }
        _2 = (object)SEQ_PTR(_14659);
        _14661 = (object)*(((s1_ptr)_2)->base + _14660);
        _14659 = NOVALUE;
        _14662 = find_from(_14661, _46SLASH_CHARS_21935, 1);
        _14661 = NOVALUE;
        if (_14662 == 0)
        {
            _14662 = NOVALUE;
            goto L1B; // [574] 598
        }
        else{
            _14662 = NOVALUE;
        }

        /** scanner.e:541						errbuff = inc_path[i][1..$-1]  -- looks better*/
        _2 = (object)SEQ_PTR(_inc_path_26299);
        _14663 = (object)*(((s1_ptr)_2)->base + _i_26428);
        if (IS_SEQUENCE(_14663)){
                _14664 = SEQ_PTR(_14663)->length;
        }
        else {
            _14664 = 1;
        }
        _14665 = _14664 - 1;
        _14664 = NOVALUE;
        rhs_slice_target = (object_ptr)&_errbuff_26295;
        RHS_Slice(_14663, 1, _14665);
        _14663 = NOVALUE;
        goto L1C; // [595] 607
L1B: 

        /** scanner.e:543						errbuff = inc_path[i]*/
        DeRef(_errbuff_26295);
        _2 = (object)SEQ_PTR(_inc_path_26299);
        _errbuff_26295 = (object)*(((s1_ptr)_2)->base + _i_26428);
        Ref(_errbuff_26295);
L1C: 

        /** scanner.e:545					if not find(errbuff, full_path) then*/
        _14668 = find_from(_errbuff_26295, _full_path_26294, 1);
        if (_14668 != 0)
        goto L1D; // [614] 624
        _14668 = NOVALUE;

        /** scanner.e:546						full_path = append(full_path, errbuff)*/
        RefDS(_errbuff_26295);
        Append(&_full_path_26294, _full_path_26294, _errbuff_26295);
L1D: 

        /** scanner.e:548				end for*/
        _i_26428 = _i_26428 + 1;
        goto L19; // [626] 554
L1A: 
        ;
    }
L18: 
L17: 

    /** scanner.e:552		if length(get_eudir()) > 0 then*/
    _14671 = _37get_eudir();
    if (IS_SEQUENCE(_14671)){
            _14672 = SEQ_PTR(_14671)->length;
    }
    else {
        _14672 = 1;
    }
    DeRef(_14671);
    _14671 = NOVALUE;
    if (_14672 <= 0)
    goto L1E; // [641] 669

    /** scanner.e:553			if not find(get_eudir(), full_path) then*/
    _14674 = _37get_eudir();
    _14675 = find_from(_14674, _full_path_26294, 1);
    DeRef(_14674);
    _14674 = NOVALUE;
    if (_14675 != 0)
    goto L1F; // [655] 668
    _14675 = NOVALUE;

    /** scanner.e:554				full_path = append(full_path, get_eudir())*/
    _14677 = _37get_eudir();
    Ref(_14677);
    Append(&_full_path_26294, _full_path_26294, _14677);
    DeRef(_14677);
    _14677 = NOVALUE;
L1F: 
L1E: 

    /** scanner.e:558		errbuff = ""*/
    RefDS(_5);
    DeRef(_errbuff_26295);
    _errbuff_26295 = _5;

    /** scanner.e:559		for i = 1 to length(full_path) do*/
    if (IS_SEQUENCE(_full_path_26294)){
            _14679 = SEQ_PTR(_full_path_26294)->length;
    }
    else {
        _14679 = 1;
    }
    {
        object _i_26460;
        _i_26460 = 1;
L20: 
        if (_i_26460 > _14679){
            goto L21; // [681] 713
        }

        /** scanner.e:560			errbuff &= sprintf("\t%s\n", {full_path[i]})*/
        _2 = (object)SEQ_PTR(_full_path_26294);
        _14681 = (object)*(((s1_ptr)_2)->base + _i_26460);
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        Ref(_14681);
        ((intptr_t*)_2)[1] = _14681;
        _14682 = MAKE_SEQ(_1);
        _14681 = NOVALUE;
        _14683 = EPrintf(-9999999, _14680, _14682);
        DeRefDS(_14682);
        _14682 = NOVALUE;
        Concat((object_ptr)&_errbuff_26295, _errbuff_26295, _14683);
        DeRefDS(_14683);
        _14683 = NOVALUE;

        /** scanner.e:561		end for*/
        _i_26460 = _i_26460 + 1;
        goto L20; // [708] 688
L21: 
        ;
    }

    /** scanner.e:563		CompileErr(CANT_FIND_1_IN_ANY_OF_2, {new_include_name, errbuff})*/
    RefDS(_errbuff_26295);
    RefDS(_36new_include_name_21893);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _36new_include_name_21893;
    ((intptr_t *)_2)[2] = _errbuff_26295;
    _14685 = MAKE_SEQ(_1);
    _50CompileErr(52, _14685, 0);
    _14685 = NOVALUE;
    ;
}


object _62path_open()
{
    object _fh_26473 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:569		new_include_name = find_file(new_include_name)*/
    RefDS(_36new_include_name_21893);
    _0 = _62find_file(_36new_include_name_21893);
    DeRefDS(_36new_include_name_21893);
    _36new_include_name_21893 = _0;

    /** scanner.e:570		new_include_name = maybe_preprocess(new_include_name)*/
    RefDS(_36new_include_name_21893);
    _0 = _64maybe_preprocess(_36new_include_name_21893);
    DeRefDS(_36new_include_name_21893);
    _36new_include_name_21893 = _0;

    /** scanner.e:572		fh = open_locked(new_include_name)*/
    RefDS(_36new_include_name_21893);
    _fh_26473 = _37open_locked(_36new_include_name_21893);
    if (!IS_ATOM_INT(_fh_26473)) {
        _1 = (object)(DBL_PTR(_fh_26473)->dbl);
        DeRefDS(_fh_26473);
        _fh_26473 = _1;
    }

    /** scanner.e:573		return fh*/
    return _fh_26473;
    ;
}


object _62NameSpace_declaration(object _sym_26501)
{
    object _h_26502 = NOVALUE;
    object _14709 = NOVALUE;
    object _14707 = NOVALUE;
    object _14705 = NOVALUE;
    object _14703 = NOVALUE;
    object _14702 = NOVALUE;
    object _14701 = NOVALUE;
    object _14699 = NOVALUE;
    object _14698 = NOVALUE;
    object _14697 = NOVALUE;
    object _14696 = NOVALUE;
    object _14695 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_sym_26501)) {
        _1 = (object)(DBL_PTR(_sym_26501)->dbl);
        DeRefDS(_sym_26501);
        _sym_26501 = _1;
    }

    /** scanner.e:594		DefinedYet(sym)*/
    _54DefinedYet(_sym_26501);

    /** scanner.e:595		if find(SymTab[sym][S_SCOPE], {SC_GLOBAL, SC_PUBLIC, SC_EXPORT, SC_PREDEF}) then*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _14695 = (object)*(((s1_ptr)_2)->base + _sym_26501);
    _2 = (object)SEQ_PTR(_14695);
    _14696 = (object)*(((s1_ptr)_2)->base + 4);
    _14695 = NOVALUE;
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 6;
    ((intptr_t*)_2)[2] = 13;
    ((intptr_t*)_2)[3] = 11;
    ((intptr_t*)_2)[4] = 7;
    _14697 = MAKE_SEQ(_1);
    _14698 = find_from(_14696, _14697, 1);
    _14696 = NOVALUE;
    DeRefDS(_14697);
    _14697 = NOVALUE;
    if (_14698 == 0)
    {
        _14698 = NOVALUE;
        goto L1; // [42] 104
    }
    else{
        _14698 = NOVALUE;
    }

    /** scanner.e:597			h = SymTab[sym][S_HASHVAL]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _14699 = (object)*(((s1_ptr)_2)->base + _sym_26501);
    _2 = (object)SEQ_PTR(_14699);
    _h_26502 = (object)*(((s1_ptr)_2)->base + 11);
    if (!IS_ATOM_INT(_h_26502)){
        _h_26502 = (object)DBL_PTR(_h_26502)->dbl;
    }
    _14699 = NOVALUE;

    /** scanner.e:599			sym = NewEntry(SymTab[sym][S_NAME], 0, 0, VARIABLE, h, buckets[h], 0)*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _14701 = (object)*(((s1_ptr)_2)->base + _sym_26501);
    _2 = (object)SEQ_PTR(_14701);
    if (!IS_ATOM_INT(_36S_NAME_21404)){
        _14702 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21404)->dbl));
    }
    else{
        _14702 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21404);
    }
    _14701 = NOVALUE;
    _2 = (object)SEQ_PTR(_54buckets_47132);
    _14703 = (object)*(((s1_ptr)_2)->base + _h_26502);
    Ref(_14702);
    Ref(_14703);
    _sym_26501 = _54NewEntry(_14702, 0, 0, -100, _h_26502, _14703, 0);
    _14702 = NOVALUE;
    _14703 = NOVALUE;
    if (!IS_ATOM_INT(_sym_26501)) {
        _1 = (object)(DBL_PTR(_sym_26501)->dbl);
        DeRefDS(_sym_26501);
        _sym_26501 = _1;
    }

    /** scanner.e:600			buckets[h] = sym*/
    _2 = (object)SEQ_PTR(_54buckets_47132);
    _2 = (object)(((s1_ptr)_2)->base + _h_26502);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _sym_26501;
    DeRef(_1);
L1: 

    /** scanner.e:602		SymTab[sym][S_SCOPE] = SC_LOCAL*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_26501 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 5;
    DeRef(_1);
    _14705 = NOVALUE;

    /** scanner.e:603		SymTab[sym][S_MODE] = M_CONSTANT*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_26501 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2;
    DeRef(_1);
    _14707 = NOVALUE;

    /** scanner.e:604		SymTab[sym][S_TOKEN] = NAMESPACE -- [S_OBJ] will get the file number referred-to*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_26501 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_TOKEN_21409))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21409)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_TOKEN_21409);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 523;
    DeRef(_1);
    _14709 = NOVALUE;

    /** scanner.e:605		if TRANSLATE then*/
    if (_36TRANSLATE_21369 == 0)
    {
        goto L2; // [159] 173
    }
    else{
    }

    /** scanner.e:606			num_routines += 1 -- order of ns declaration relative to routines*/
    _36num_routines_21776 = _36num_routines_21776 + 1;
L2: 

    /** scanner.e:609		return sym*/
    return _sym_26501;
    ;
}


void _62default_namespace()
{
    object _tok_26552 = NOVALUE;
    object _sym_26554 = NOVALUE;
    object _14733 = NOVALUE;
    object _14732 = NOVALUE;
    object _14730 = NOVALUE;
    object _14728 = NOVALUE;
    object _14725 = NOVALUE;
    object _14722 = NOVALUE;
    object _14720 = NOVALUE;
    object _14718 = NOVALUE;
    object _14717 = NOVALUE;
    object _14716 = NOVALUE;
    object _14715 = NOVALUE;
    object _14714 = NOVALUE;
    object _14713 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** scanner.e:618		tok = call_func( scanner_rid, {} )*/
    _0 = (object)_00[_62scanner_rid_26548].addr;
    _1 = (*(intptr_t (*)())_0)(
                         );
    DeRef(_tok_26552);
    _tok_26552 = _1;

    /** scanner.e:619		if tok[T_ID] = VARIABLE and equal( SymTab[tok[T_SYM]][S_NAME], "namespace" ) then*/
    _2 = (object)SEQ_PTR(_tok_26552);
    _14713 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_14713)) {
        _14714 = (_14713 == -100);
    }
    else {
        _14714 = binary_op(EQUALS, _14713, -100);
    }
    _14713 = NOVALUE;
    if (IS_ATOM_INT(_14714)) {
        if (_14714 == 0) {
            goto L1; // [23] 179
        }
    }
    else {
        if (DBL_PTR(_14714)->dbl == 0.0) {
            goto L1; // [23] 179
        }
    }
    _2 = (object)SEQ_PTR(_tok_26552);
    _14716 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!IS_ATOM_INT(_14716)){
        _14717 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_14716)->dbl));
    }
    else{
        _14717 = (object)*(((s1_ptr)_2)->base + _14716);
    }
    _2 = (object)SEQ_PTR(_14717);
    if (!IS_ATOM_INT(_36S_NAME_21404)){
        _14718 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21404)->dbl));
    }
    else{
        _14718 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21404);
    }
    _14717 = NOVALUE;
    if (_14718 == _14719)
    _14720 = 1;
    else if (IS_ATOM_INT(_14718) && IS_ATOM_INT(_14719))
    _14720 = 0;
    else
    _14720 = (compare(_14718, _14719) == 0);
    _14718 = NOVALUE;
    if (_14720 == 0)
    {
        _14720 = NOVALUE;
        goto L1; // [50] 179
    }
    else{
        _14720 = NOVALUE;
    }

    /** scanner.e:621			tok = call_func( scanner_rid, {} )*/
    _0 = (object)_00[_62scanner_rid_26548].addr;
    _1 = (*(intptr_t (*)())_0)(
                         );
    DeRef(_tok_26552);
    _tok_26552 = _1;

    /** scanner.e:622			if tok[T_ID] != VARIABLE then*/
    _2 = (object)SEQ_PTR(_tok_26552);
    _14722 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _14722, -100)){
        _14722 = NOVALUE;
        goto L2; // [71] 85
    }
    _14722 = NOVALUE;

    /** scanner.e:623				CompileErr(MISSING_DEFAULT_NAMESPACE_QUALIFIER)*/
    RefDS(_22190);
    _50CompileErr(114, _22190, 0);
L2: 

    /** scanner.e:626			sym = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_26552);
    _sym_26554 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_sym_26554)){
        _sym_26554 = (object)DBL_PTR(_sym_26554)->dbl;
    }

    /** scanner.e:628			SymTab[sym][S_FILE_NO] = current_file_no*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_26554 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_FILE_NO_21400))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21400)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_FILE_NO_21400);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36current_file_no_21767;
    DeRef(_1);
    _14725 = NOVALUE;

    /** scanner.e:629			sym  = NameSpace_declaration( sym )*/
    _sym_26554 = _62NameSpace_declaration(_sym_26554);
    if (!IS_ATOM_INT(_sym_26554)) {
        _1 = (object)(DBL_PTR(_sym_26554)->dbl);
        DeRefDS(_sym_26554);
        _sym_26554 = _1;
    }

    /** scanner.e:630			SymTab[sym][S_OBJ] = current_file_no*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_26554 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36current_file_no_21767;
    DeRef(_1);
    _14728 = NOVALUE;

    /** scanner.e:631			SymTab[sym][S_SCOPE] = SC_PUBLIC*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_26554 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 13;
    DeRef(_1);
    _14730 = NOVALUE;

    /** scanner.e:633			default_namespaces[current_file_no] = SymTab[sym][S_NAME]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _14732 = (object)*(((s1_ptr)_2)->base + _sym_26554);
    _2 = (object)SEQ_PTR(_14732);
    if (!IS_ATOM_INT(_36S_NAME_21404)){
        _14733 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21404)->dbl));
    }
    else{
        _14733 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21404);
    }
    _14732 = NOVALUE;
    Ref(_14733);
    _2 = (object)SEQ_PTR(_62default_namespaces_25879);
    _2 = (object)(((s1_ptr)_2)->base + _36current_file_no_21767);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14733;
    if( _1 != _14733 ){
        DeRef(_1);
    }
    _14733 = NOVALUE;
    goto L3; // [176] 187
L1: 

    /** scanner.e:637			bp = 1*/
    _50bp_49598 = 1;
L3: 

    /** scanner.e:640	end procedure*/
    DeRef(_tok_26552);
    DeRef(_14714);
    _14714 = NOVALUE;
    _14716 = NOVALUE;
    return;
    ;
}


void _62add_exports(object _from_file_26605, object _to_file_26606)
{
    object _exports_26607 = NOVALUE;
    object _direct_26608 = NOVALUE;
    object _14753 = NOVALUE;
    object _14752 = NOVALUE;
    object _14751 = NOVALUE;
    object _14750 = NOVALUE;
    object _14749 = NOVALUE;
    object _14747 = NOVALUE;
    object _14745 = NOVALUE;
    object _14744 = NOVALUE;
    object _14742 = NOVALUE;
    object _14741 = NOVALUE;
    object _14740 = NOVALUE;
    object _14738 = NOVALUE;
    object _14737 = NOVALUE;
    object _14736 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** scanner.e:645		direct = file_include[to_file]*/
    DeRef(_direct_26608);
    _2 = (object)SEQ_PTR(_37file_include_15642);
    _direct_26608 = (object)*(((s1_ptr)_2)->base + _to_file_26606);
    Ref(_direct_26608);

    /** scanner.e:646		exports = file_public[from_file]*/
    DeRef(_exports_26607);
    _2 = (object)SEQ_PTR(_37file_public_15648);
    _exports_26607 = (object)*(((s1_ptr)_2)->base + _from_file_26605);
    Ref(_exports_26607);

    /** scanner.e:647		for i = 1 to length(exports) do*/
    if (IS_SEQUENCE(_exports_26607)){
            _14736 = SEQ_PTR(_exports_26607)->length;
    }
    else {
        _14736 = 1;
    }
    {
        object _i_26614;
        _i_26614 = 1;
L1: 
        if (_i_26614 > _14736){
            goto L2; // [30] 127
        }

        /** scanner.e:648			if not find( exports[i], direct ) then*/
        _2 = (object)SEQ_PTR(_exports_26607);
        _14737 = (object)*(((s1_ptr)_2)->base + _i_26614);
        _14738 = find_from(_14737, _direct_26608, 1);
        _14737 = NOVALUE;
        if (_14738 != 0)
        goto L3; // [48] 120
        _14738 = NOVALUE;

        /** scanner.e:649				if not find( -exports[i], direct ) then*/
        _2 = (object)SEQ_PTR(_exports_26607);
        _14740 = (object)*(((s1_ptr)_2)->base + _i_26614);
        if (IS_ATOM_INT(_14740)) {
            if ((uintptr_t)_14740 == (uintptr_t)HIGH_BITS){
                _14741 = (object)NewDouble((eudouble) -HIGH_BITS);
            }
            else{
                _14741 = - _14740;
            }
        }
        else {
            _14741 = unary_op(UMINUS, _14740);
        }
        _14740 = NOVALUE;
        _14742 = find_from(_14741, _direct_26608, 1);
        DeRef(_14741);
        _14741 = NOVALUE;
        if (_14742 != 0)
        goto L4; // [65] 82
        _14742 = NOVALUE;

        /** scanner.e:650					direct &= -exports[i]*/
        _2 = (object)SEQ_PTR(_exports_26607);
        _14744 = (object)*(((s1_ptr)_2)->base + _i_26614);
        if (IS_ATOM_INT(_14744)) {
            if ((uintptr_t)_14744 == (uintptr_t)HIGH_BITS){
                _14745 = (object)NewDouble((eudouble) -HIGH_BITS);
            }
            else{
                _14745 = - _14744;
            }
        }
        else {
            _14745 = unary_op(UMINUS, _14744);
        }
        _14744 = NOVALUE;
        if (IS_SEQUENCE(_direct_26608) && IS_ATOM(_14745)) {
            Ref(_14745);
            Append(&_direct_26608, _direct_26608, _14745);
        }
        else if (IS_ATOM(_direct_26608) && IS_SEQUENCE(_14745)) {
        }
        else {
            Concat((object_ptr)&_direct_26608, _direct_26608, _14745);
        }
        DeRef(_14745);
        _14745 = NOVALUE;
L4: 

        /** scanner.e:654				include_matrix[to_file][exports[i]] = or_bits( PUBLIC_INCLUDE, include_matrix[to_file][exports[i]] )*/
        _2 = (object)SEQ_PTR(_37include_matrix_15644);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37include_matrix_15644 = MAKE_SEQ(_2);
        }
        _3 = (object)(_to_file_26606 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_exports_26607);
        _14749 = (object)*(((s1_ptr)_2)->base + _i_26614);
        _2 = (object)SEQ_PTR(_37include_matrix_15644);
        _14750 = (object)*(((s1_ptr)_2)->base + _to_file_26606);
        _2 = (object)SEQ_PTR(_exports_26607);
        _14751 = (object)*(((s1_ptr)_2)->base + _i_26614);
        _2 = (object)SEQ_PTR(_14750);
        if (!IS_ATOM_INT(_14751)){
            _14752 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_14751)->dbl));
        }
        else{
            _14752 = (object)*(((s1_ptr)_2)->base + _14751);
        }
        _14750 = NOVALUE;
        if (IS_ATOM_INT(_14752)) {
            {uintptr_t tu;
                 tu = (uintptr_t)4 | (uintptr_t)_14752;
                 _14753 = MAKE_UINT(tu);
            }
        }
        else {
            _14753 = binary_op(OR_BITS, 4, _14752);
        }
        _14752 = NOVALUE;
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_14749))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_14749)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _14749);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _14753;
        if( _1 != _14753 ){
            DeRef(_1);
        }
        _14753 = NOVALUE;
        _14747 = NOVALUE;
L3: 

        /** scanner.e:656		end for*/
        _i_26614 = _i_26614 + 1;
        goto L1; // [122] 37
L2: 
        ;
    }

    /** scanner.e:657		file_include[to_file] = direct*/
    RefDS(_direct_26608);
    _2 = (object)SEQ_PTR(_37file_include_15642);
    _2 = (object)(((s1_ptr)_2)->base + _to_file_26606);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _direct_26608;
    DeRef(_1);

    /** scanner.e:658	end procedure*/
    DeRef(_exports_26607);
    DeRefDS(_direct_26608);
    _14749 = NOVALUE;
    _14751 = NOVALUE;
    return;
    ;
}


void _62patch_exports(object _for_file_26641)
{
    object _export_len_26642 = NOVALUE;
    object _14764 = NOVALUE;
    object _14763 = NOVALUE;
    object _14761 = NOVALUE;
    object _14760 = NOVALUE;
    object _14759 = NOVALUE;
    object _14758 = NOVALUE;
    object _14756 = NOVALUE;
    object _14755 = NOVALUE;
    object _14754 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:663		for i = 1 to length(file_include) do*/
    if (IS_SEQUENCE(_37file_include_15642)){
            _14754 = SEQ_PTR(_37file_include_15642)->length;
    }
    else {
        _14754 = 1;
    }
    {
        object _i_26644;
        _i_26644 = 1;
L1: 
        if (_i_26644 > _14754){
            goto L2; // [10] 99
        }

        /** scanner.e:664			if find( for_file, file_include[i] ) or find( -for_file, file_include[i] ) then*/
        _2 = (object)SEQ_PTR(_37file_include_15642);
        _14755 = (object)*(((s1_ptr)_2)->base + _i_26644);
        _14756 = find_from(_for_file_26641, _14755, 1);
        _14755 = NOVALUE;
        if (_14756 != 0) {
            goto L3; // [30] 53
        }
        if ((uintptr_t)_for_file_26641 == (uintptr_t)HIGH_BITS){
            _14758 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _14758 = - _for_file_26641;
        }
        _2 = (object)SEQ_PTR(_37file_include_15642);
        _14759 = (object)*(((s1_ptr)_2)->base + _i_26644);
        _14760 = find_from(_14758, _14759, 1);
        DeRef(_14758);
        _14758 = NOVALUE;
        _14759 = NOVALUE;
        if (_14760 == 0)
        {
            _14760 = NOVALUE;
            goto L4; // [49] 92
        }
        else{
            _14760 = NOVALUE;
        }
L3: 

        /** scanner.e:665				export_len = length( file_include[i] )*/
        _2 = (object)SEQ_PTR(_37file_include_15642);
        _14761 = (object)*(((s1_ptr)_2)->base + _i_26644);
        if (IS_SEQUENCE(_14761)){
                _export_len_26642 = SEQ_PTR(_14761)->length;
        }
        else {
            _export_len_26642 = 1;
        }
        _14761 = NOVALUE;

        /** scanner.e:666				add_exports( for_file, i )*/
        _62add_exports(_for_file_26641, _i_26644);

        /** scanner.e:667				if length( file_include[i] ) != export_len then*/
        _2 = (object)SEQ_PTR(_37file_include_15642);
        _14763 = (object)*(((s1_ptr)_2)->base + _i_26644);
        if (IS_SEQUENCE(_14763)){
                _14764 = SEQ_PTR(_14763)->length;
        }
        else {
            _14764 = 1;
        }
        _14763 = NOVALUE;
        if (_14764 == _export_len_26642)
        goto L5; // [81] 91

        /** scanner.e:669					patch_exports( i )*/
        _62patch_exports(_i_26644);
L5: 
L4: 

        /** scanner.e:672		end for*/
        _i_26644 = _i_26644 + 1;
        goto L1; // [94] 17
L2: 
        ;
    }

    /** scanner.e:673	end procedure*/
    _14761 = NOVALUE;
    _14763 = NOVALUE;
    return;
    ;
}


void _62update_include_matrix(object _included_file_26666, object _from_file_26667)
{
    object _add_public_26677 = NOVALUE;
    object _px_26695 = NOVALUE;
    object _indirect_26754 = NOVALUE;
    object _mask_26757 = NOVALUE;
    object _ix_26768 = NOVALUE;
    object _indirect_file_26772 = NOVALUE;
    object _14840 = NOVALUE;
    object _14839 = NOVALUE;
    object _14837 = NOVALUE;
    object _14836 = NOVALUE;
    object _14835 = NOVALUE;
    object _14834 = NOVALUE;
    object _14833 = NOVALUE;
    object _14832 = NOVALUE;
    object _14831 = NOVALUE;
    object _14830 = NOVALUE;
    object _14829 = NOVALUE;
    object _14826 = NOVALUE;
    object _14824 = NOVALUE;
    object _14823 = NOVALUE;
    object _14822 = NOVALUE;
    object _14820 = NOVALUE;
    object _14818 = NOVALUE;
    object _14817 = NOVALUE;
    object _14815 = NOVALUE;
    object _14814 = NOVALUE;
    object _14813 = NOVALUE;
    object _14812 = NOVALUE;
    object _14811 = NOVALUE;
    object _14809 = NOVALUE;
    object _14808 = NOVALUE;
    object _14807 = NOVALUE;
    object _14806 = NOVALUE;
    object _14805 = NOVALUE;
    object _14804 = NOVALUE;
    object _14802 = NOVALUE;
    object _14801 = NOVALUE;
    object _14800 = NOVALUE;
    object _14798 = NOVALUE;
    object _14797 = NOVALUE;
    object _14796 = NOVALUE;
    object _14795 = NOVALUE;
    object _14794 = NOVALUE;
    object _14793 = NOVALUE;
    object _14792 = NOVALUE;
    object _14791 = NOVALUE;
    object _14790 = NOVALUE;
    object _14789 = NOVALUE;
    object _14788 = NOVALUE;
    object _14786 = NOVALUE;
    object _14785 = NOVALUE;
    object _14783 = NOVALUE;
    object _14781 = NOVALUE;
    object _14779 = NOVALUE;
    object _14778 = NOVALUE;
    object _14777 = NOVALUE;
    object _14776 = NOVALUE;
    object _14774 = NOVALUE;
    object _14773 = NOVALUE;
    object _14772 = NOVALUE;
    object _14770 = NOVALUE;
    object _14769 = NOVALUE;
    object _14768 = NOVALUE;
    object _14766 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** scanner.e:684		include_matrix[from_file][included_file] = or_bits( DIRECT_INCLUDE, include_matrix[from_file][included_file] )*/
    _2 = (object)SEQ_PTR(_37include_matrix_15644);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37include_matrix_15644 = MAKE_SEQ(_2);
    }
    _3 = (object)(_from_file_26667 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_37include_matrix_15644);
    _14768 = (object)*(((s1_ptr)_2)->base + _from_file_26667);
    _2 = (object)SEQ_PTR(_14768);
    _14769 = (object)*(((s1_ptr)_2)->base + _included_file_26666);
    _14768 = NOVALUE;
    if (IS_ATOM_INT(_14769)) {
        {uintptr_t tu;
             tu = (uintptr_t)2 | (uintptr_t)_14769;
             _14770 = MAKE_UINT(tu);
        }
    }
    else {
        _14770 = binary_op(OR_BITS, 2, _14769);
    }
    _14769 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _included_file_26666);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14770;
    if( _1 != _14770 ){
        DeRef(_1);
    }
    _14770 = NOVALUE;
    _14766 = NOVALUE;

    /** scanner.e:686		if public_include then*/
    if (_62public_include_25876 == 0)
    {
        goto L1; // [38] 339
    }
    else{
    }

    /** scanner.e:689			sequence add_public = file_include_by[from_file]*/
    DeRef(_add_public_26677);
    _2 = (object)SEQ_PTR(_37file_include_by_15650);
    _add_public_26677 = (object)*(((s1_ptr)_2)->base + _from_file_26667);
    Ref(_add_public_26677);

    /** scanner.e:690			for i = 1 to length( add_public ) do*/
    if (IS_SEQUENCE(_add_public_26677)){
            _14772 = SEQ_PTR(_add_public_26677)->length;
    }
    else {
        _14772 = 1;
    }
    {
        object _i_26681;
        _i_26681 = 1;
L2: 
        if (_i_26681 > _14772){
            goto L3; // [56] 107
        }

        /** scanner.e:692				include_matrix[add_public[i]][included_file] =*/
        _2 = (object)SEQ_PTR(_add_public_26677);
        _14773 = (object)*(((s1_ptr)_2)->base + _i_26681);
        _2 = (object)SEQ_PTR(_37include_matrix_15644);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37include_matrix_15644 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_14773))
        _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_14773)->dbl));
        else
        _3 = (object)(_14773 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_add_public_26677);
        _14776 = (object)*(((s1_ptr)_2)->base + _i_26681);
        _2 = (object)SEQ_PTR(_37include_matrix_15644);
        if (!IS_ATOM_INT(_14776)){
            _14777 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_14776)->dbl));
        }
        else{
            _14777 = (object)*(((s1_ptr)_2)->base + _14776);
        }
        _2 = (object)SEQ_PTR(_14777);
        _14778 = (object)*(((s1_ptr)_2)->base + _included_file_26666);
        _14777 = NOVALUE;
        if (IS_ATOM_INT(_14778)) {
            {uintptr_t tu;
                 tu = (uintptr_t)4 | (uintptr_t)_14778;
                 _14779 = MAKE_UINT(tu);
            }
        }
        else {
            _14779 = binary_op(OR_BITS, 4, _14778);
        }
        _14778 = NOVALUE;
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _included_file_26666);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _14779;
        if( _1 != _14779 ){
            DeRef(_1);
        }
        _14779 = NOVALUE;
        _14774 = NOVALUE;

        /** scanner.e:695			end for*/
        _i_26681 = _i_26681 + 1;
        goto L2; // [102] 63
L3: 
        ;
    }

    /** scanner.e:698			add_public = file_public_by[from_file]*/
    DeRef(_add_public_26677);
    _2 = (object)SEQ_PTR(_37file_public_by_15652);
    _add_public_26677 = (object)*(((s1_ptr)_2)->base + _from_file_26667);
    Ref(_add_public_26677);

    /** scanner.e:699			integer px = length( add_public ) + 1*/
    if (IS_SEQUENCE(_add_public_26677)){
            _14781 = SEQ_PTR(_add_public_26677)->length;
    }
    else {
        _14781 = 1;
    }
    _px_26695 = _14781 + 1;
    _14781 = NOVALUE;

    /** scanner.e:700			while px <= length( add_public ) do*/
L4: 
    if (IS_SEQUENCE(_add_public_26677)){
            _14783 = SEQ_PTR(_add_public_26677)->length;
    }
    else {
        _14783 = 1;
    }
    if (_px_26695 > _14783)
    goto L5; // [134] 338

    /** scanner.e:701				include_matrix[add_public[px]][included_file] =*/
    _2 = (object)SEQ_PTR(_add_public_26677);
    _14785 = (object)*(((s1_ptr)_2)->base + _px_26695);
    _2 = (object)SEQ_PTR(_37include_matrix_15644);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37include_matrix_15644 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_14785))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_14785)->dbl));
    else
    _3 = (object)(_14785 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_add_public_26677);
    _14788 = (object)*(((s1_ptr)_2)->base + _px_26695);
    _2 = (object)SEQ_PTR(_37include_matrix_15644);
    if (!IS_ATOM_INT(_14788)){
        _14789 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_14788)->dbl));
    }
    else{
        _14789 = (object)*(((s1_ptr)_2)->base + _14788);
    }
    _2 = (object)SEQ_PTR(_14789);
    _14790 = (object)*(((s1_ptr)_2)->base + _included_file_26666);
    _14789 = NOVALUE;
    if (IS_ATOM_INT(_14790)) {
        {uintptr_t tu;
             tu = (uintptr_t)4 | (uintptr_t)_14790;
             _14791 = MAKE_UINT(tu);
        }
    }
    else {
        _14791 = binary_op(OR_BITS, 4, _14790);
    }
    _14790 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _included_file_26666);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14791;
    if( _1 != _14791 ){
        DeRef(_1);
    }
    _14791 = NOVALUE;
    _14786 = NOVALUE;

    /** scanner.e:704				for i = 1 to length( file_public_by[add_public[px]] ) do*/
    _2 = (object)SEQ_PTR(_add_public_26677);
    _14792 = (object)*(((s1_ptr)_2)->base + _px_26695);
    _2 = (object)SEQ_PTR(_37file_public_by_15652);
    if (!IS_ATOM_INT(_14792)){
        _14793 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_14792)->dbl));
    }
    else{
        _14793 = (object)*(((s1_ptr)_2)->base + _14792);
    }
    if (IS_SEQUENCE(_14793)){
            _14794 = SEQ_PTR(_14793)->length;
    }
    else {
        _14794 = 1;
    }
    _14793 = NOVALUE;
    {
        object _i_26712;
        _i_26712 = 1;
L6: 
        if (_i_26712 > _14794){
            goto L7; // [190] 249
        }

        /** scanner.e:705					if not find( file_public[add_public[px]][i], add_public ) then*/
        _2 = (object)SEQ_PTR(_add_public_26677);
        _14795 = (object)*(((s1_ptr)_2)->base + _px_26695);
        _2 = (object)SEQ_PTR(_37file_public_15648);
        if (!IS_ATOM_INT(_14795)){
            _14796 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_14795)->dbl));
        }
        else{
            _14796 = (object)*(((s1_ptr)_2)->base + _14795);
        }
        _2 = (object)SEQ_PTR(_14796);
        _14797 = (object)*(((s1_ptr)_2)->base + _i_26712);
        _14796 = NOVALUE;
        _14798 = find_from(_14797, _add_public_26677, 1);
        _14797 = NOVALUE;
        if (_14798 != 0)
        goto L8; // [218] 242
        _14798 = NOVALUE;

        /** scanner.e:706						add_public &= file_public[add_public[px]][i]*/
        _2 = (object)SEQ_PTR(_add_public_26677);
        _14800 = (object)*(((s1_ptr)_2)->base + _px_26695);
        _2 = (object)SEQ_PTR(_37file_public_15648);
        if (!IS_ATOM_INT(_14800)){
            _14801 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_14800)->dbl));
        }
        else{
            _14801 = (object)*(((s1_ptr)_2)->base + _14800);
        }
        _2 = (object)SEQ_PTR(_14801);
        _14802 = (object)*(((s1_ptr)_2)->base + _i_26712);
        _14801 = NOVALUE;
        if (IS_SEQUENCE(_add_public_26677) && IS_ATOM(_14802)) {
            Ref(_14802);
            Append(&_add_public_26677, _add_public_26677, _14802);
        }
        else if (IS_ATOM(_add_public_26677) && IS_SEQUENCE(_14802)) {
        }
        else {
            Concat((object_ptr)&_add_public_26677, _add_public_26677, _14802);
        }
        _14802 = NOVALUE;
L8: 

        /** scanner.e:708				end for*/
        _i_26712 = _i_26712 + 1;
        goto L6; // [244] 197
L7: 
        ;
    }

    /** scanner.e:710				for i = 1 to length( file_include_by[add_public[px]] ) do*/
    _2 = (object)SEQ_PTR(_add_public_26677);
    _14804 = (object)*(((s1_ptr)_2)->base + _px_26695);
    _2 = (object)SEQ_PTR(_37file_include_by_15650);
    if (!IS_ATOM_INT(_14804)){
        _14805 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_14804)->dbl));
    }
    else{
        _14805 = (object)*(((s1_ptr)_2)->base + _14804);
    }
    if (IS_SEQUENCE(_14805)){
            _14806 = SEQ_PTR(_14805)->length;
    }
    else {
        _14806 = 1;
    }
    _14805 = NOVALUE;
    {
        object _i_26730;
        _i_26730 = 1;
L9: 
        if (_i_26730 > _14806){
            goto LA; // [264] 327
        }

        /** scanner.e:711					include_matrix[file_include_by[add_public[px]]][included_file] =*/
        _2 = (object)SEQ_PTR(_add_public_26677);
        _14807 = (object)*(((s1_ptr)_2)->base + _px_26695);
        _2 = (object)SEQ_PTR(_37file_include_by_15650);
        if (!IS_ATOM_INT(_14807)){
            _14808 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_14807)->dbl));
        }
        else{
            _14808 = (object)*(((s1_ptr)_2)->base + _14807);
        }
        _2 = (object)SEQ_PTR(_37include_matrix_15644);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37include_matrix_15644 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_14808))
        _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_14808)->dbl));
        else
        _3 = (object)(_14808 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_add_public_26677);
        _14811 = (object)*(((s1_ptr)_2)->base + _px_26695);
        _2 = (object)SEQ_PTR(_37file_include_by_15650);
        if (!IS_ATOM_INT(_14811)){
            _14812 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_14811)->dbl));
        }
        else{
            _14812 = (object)*(((s1_ptr)_2)->base + _14811);
        }
        _2 = (object)SEQ_PTR(_37include_matrix_15644);
        if (!IS_ATOM_INT(_14812)){
            _14813 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_14812)->dbl));
        }
        else{
            _14813 = (object)*(((s1_ptr)_2)->base + _14812);
        }
        _2 = (object)SEQ_PTR(_14813);
        _14814 = (object)*(((s1_ptr)_2)->base + _included_file_26666);
        _14813 = NOVALUE;
        if (IS_ATOM_INT(_14814)) {
            {uintptr_t tu;
                 tu = (uintptr_t)4 | (uintptr_t)_14814;
                 _14815 = MAKE_UINT(tu);
            }
        }
        else {
            _14815 = binary_op(OR_BITS, 4, _14814);
        }
        _14814 = NOVALUE;
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _included_file_26666);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _14815;
        if( _1 != _14815 ){
            DeRef(_1);
        }
        _14815 = NOVALUE;
        _14809 = NOVALUE;

        /** scanner.e:713				end for*/
        _i_26730 = _i_26730 + 1;
        goto L9; // [322] 271
LA: 
        ;
    }

    /** scanner.e:715				px += 1*/
    _px_26695 = _px_26695 + 1;

    /** scanner.e:716			end while*/
    goto L4; // [335] 131
L5: 
L1: 
    DeRef(_add_public_26677);
    _add_public_26677 = NOVALUE;

    /** scanner.e:721		if indirect_include[from_file][included_file] then*/
    _2 = (object)SEQ_PTR(_37indirect_include_15646);
    _14817 = (object)*(((s1_ptr)_2)->base + _from_file_26667);
    _2 = (object)SEQ_PTR(_14817);
    _14818 = (object)*(((s1_ptr)_2)->base + _included_file_26666);
    _14817 = NOVALUE;
    if (_14818 == 0) {
        _14818 = NOVALUE;
        goto LB; // [353] 545
    }
    else {
        if (!IS_ATOM_INT(_14818) && DBL_PTR(_14818)->dbl == 0.0){
            _14818 = NOVALUE;
            goto LB; // [353] 545
        }
        _14818 = NOVALUE;
    }
    _14818 = NOVALUE;

    /** scanner.e:723			sequence indirect = file_include_by[from_file]*/
    DeRef(_indirect_26754);
    _2 = (object)SEQ_PTR(_37file_include_by_15650);
    _indirect_26754 = (object)*(((s1_ptr)_2)->base + _from_file_26667);
    Ref(_indirect_26754);

    /** scanner.e:725			sequence mask = include_matrix[included_file] != 0*/
    _2 = (object)SEQ_PTR(_37include_matrix_15644);
    _14820 = (object)*(((s1_ptr)_2)->base + _included_file_26666);
    DeRef(_mask_26757);
    if (IS_ATOM_INT(_14820)) {
        _mask_26757 = (_14820 != 0);
    }
    else {
        _mask_26757 = binary_op(NOTEQ, _14820, 0);
    }
    _14820 = NOVALUE;

    /** scanner.e:726			include_matrix[from_file] = or_bits( include_matrix[from_file], mask )*/
    _2 = (object)SEQ_PTR(_37include_matrix_15644);
    _14822 = (object)*(((s1_ptr)_2)->base + _from_file_26667);
    _14823 = binary_op(OR_BITS, _14822, _mask_26757);
    _14822 = NOVALUE;
    _2 = (object)SEQ_PTR(_37include_matrix_15644);
    _2 = (object)(((s1_ptr)_2)->base + _from_file_26667);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14823;
    if( _1 != _14823 ){
        DeRef(_1);
    }
    _14823 = NOVALUE;

    /** scanner.e:727			mask = include_matrix[from_file] != 0*/
    _2 = (object)SEQ_PTR(_37include_matrix_15644);
    _14824 = (object)*(((s1_ptr)_2)->base + _from_file_26667);
    DeRefDS(_mask_26757);
    if (IS_ATOM_INT(_14824)) {
        _mask_26757 = (_14824 != 0);
    }
    else {
        _mask_26757 = binary_op(NOTEQ, _14824, 0);
    }
    _14824 = NOVALUE;

    /** scanner.e:728			integer ix = 1*/
    _ix_26768 = 1;

    /** scanner.e:729			while ix <= length(indirect) do*/
LC: 
    if (IS_SEQUENCE(_indirect_26754)){
            _14826 = SEQ_PTR(_indirect_26754)->length;
    }
    else {
        _14826 = 1;
    }
    if (_ix_26768 > _14826)
    goto LD; // [425] 544

    /** scanner.e:730				integer indirect_file = indirect[ix]*/
    _2 = (object)SEQ_PTR(_indirect_26754);
    _indirect_file_26772 = (object)*(((s1_ptr)_2)->base + _ix_26768);
    if (!IS_ATOM_INT(_indirect_file_26772))
    _indirect_file_26772 = (object)DBL_PTR(_indirect_file_26772)->dbl;

    /** scanner.e:731				if indirect_include[indirect_file][included_file] then*/
    _2 = (object)SEQ_PTR(_37indirect_include_15646);
    _14829 = (object)*(((s1_ptr)_2)->base + _indirect_file_26772);
    _2 = (object)SEQ_PTR(_14829);
    _14830 = (object)*(((s1_ptr)_2)->base + _included_file_26666);
    _14829 = NOVALUE;
    if (_14830 == 0) {
        _14830 = NOVALUE;
        goto LE; // [447] 531
    }
    else {
        if (!IS_ATOM_INT(_14830) && DBL_PTR(_14830)->dbl == 0.0){
            _14830 = NOVALUE;
            goto LE; // [447] 531
        }
        _14830 = NOVALUE;
    }
    _14830 = NOVALUE;

    /** scanner.e:732					include_matrix[indirect_file] =*/
    _2 = (object)SEQ_PTR(_37include_matrix_15644);
    _14831 = (object)*(((s1_ptr)_2)->base + _indirect_file_26772);
    _14832 = binary_op(OR_BITS, _mask_26757, _14831);
    _14831 = NOVALUE;
    _2 = (object)SEQ_PTR(_37include_matrix_15644);
    _2 = (object)(((s1_ptr)_2)->base + _indirect_file_26772);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14832;
    if( _1 != _14832 ){
        DeRef(_1);
    }
    _14832 = NOVALUE;

    /** scanner.e:734					for i = 1 to length( file_include_by[indirect_file] ) do*/
    _2 = (object)SEQ_PTR(_37file_include_by_15650);
    _14833 = (object)*(((s1_ptr)_2)->base + _indirect_file_26772);
    if (IS_SEQUENCE(_14833)){
            _14834 = SEQ_PTR(_14833)->length;
    }
    else {
        _14834 = 1;
    }
    _14833 = NOVALUE;
    {
        object _i_26783;
        _i_26783 = 1;
LF: 
        if (_i_26783 > _14834){
            goto L10; // [479] 530
        }

        /** scanner.e:736						if not find( file_include_by[indirect_file][i], indirect ) then*/
        _2 = (object)SEQ_PTR(_37file_include_by_15650);
        _14835 = (object)*(((s1_ptr)_2)->base + _indirect_file_26772);
        _2 = (object)SEQ_PTR(_14835);
        _14836 = (object)*(((s1_ptr)_2)->base + _i_26783);
        _14835 = NOVALUE;
        _14837 = find_from(_14836, _indirect_26754, 1);
        _14836 = NOVALUE;
        if (_14837 != 0)
        goto L11; // [503] 523
        _14837 = NOVALUE;

        /** scanner.e:737							indirect &= file_include_by[indirect_file][i]*/
        _2 = (object)SEQ_PTR(_37file_include_by_15650);
        _14839 = (object)*(((s1_ptr)_2)->base + _indirect_file_26772);
        _2 = (object)SEQ_PTR(_14839);
        _14840 = (object)*(((s1_ptr)_2)->base + _i_26783);
        _14839 = NOVALUE;
        if (IS_SEQUENCE(_indirect_26754) && IS_ATOM(_14840)) {
            Ref(_14840);
            Append(&_indirect_26754, _indirect_26754, _14840);
        }
        else if (IS_ATOM(_indirect_26754) && IS_SEQUENCE(_14840)) {
        }
        else {
            Concat((object_ptr)&_indirect_26754, _indirect_26754, _14840);
        }
        _14840 = NOVALUE;
L11: 

        /** scanner.e:740					end for*/
        _i_26783 = _i_26783 + 1;
        goto LF; // [525] 486
L10: 
        ;
    }
LE: 

    /** scanner.e:742				ix += 1*/
    _ix_26768 = _ix_26768 + 1;

    /** scanner.e:743			end while*/
    goto LC; // [541] 422
LD: 
LB: 
    DeRef(_indirect_26754);
    _indirect_26754 = NOVALUE;
    DeRef(_mask_26757);
    _mask_26757 = NOVALUE;

    /** scanner.e:746		public_include = FALSE*/
    _62public_include_25876 = _13FALSE_445;

    /** scanner.e:747	end procedure*/
    _14800 = NOVALUE;
    _14795 = NOVALUE;
    _14833 = NOVALUE;
    _14811 = NOVALUE;
    _14788 = NOVALUE;
    _14793 = NOVALUE;
    _14804 = NOVALUE;
    _14773 = NOVALUE;
    _14805 = NOVALUE;
    _14812 = NOVALUE;
    _14785 = NOVALUE;
    _14776 = NOVALUE;
    _14807 = NOVALUE;
    _14792 = NOVALUE;
    _14808 = NOVALUE;
    return;
    ;
}


void _62add_include_by(object _by_file_26801, object _included_file_26802, object _is_public_26803)
{
    object _14887 = NOVALUE;
    object _14886 = NOVALUE;
    object _14885 = NOVALUE;
    object _14883 = NOVALUE;
    object _14882 = NOVALUE;
    object _14881 = NOVALUE;
    object _14880 = NOVALUE;
    object _14878 = NOVALUE;
    object _14877 = NOVALUE;
    object _14876 = NOVALUE;
    object _14875 = NOVALUE;
    object _14874 = NOVALUE;
    object _14873 = NOVALUE;
    object _14872 = NOVALUE;
    object _14871 = NOVALUE;
    object _14869 = NOVALUE;
    object _14868 = NOVALUE;
    object _14867 = NOVALUE;
    object _14866 = NOVALUE;
    object _14864 = NOVALUE;
    object _14863 = NOVALUE;
    object _14862 = NOVALUE;
    object _14861 = NOVALUE;
    object _14859 = NOVALUE;
    object _14858 = NOVALUE;
    object _14857 = NOVALUE;
    object _14856 = NOVALUE;
    object _14854 = NOVALUE;
    object _14853 = NOVALUE;
    object _14852 = NOVALUE;
    object _14851 = NOVALUE;
    object _14850 = NOVALUE;
    object _14848 = NOVALUE;
    object _14847 = NOVALUE;
    object _14846 = NOVALUE;
    object _14845 = NOVALUE;
    object _14843 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** scanner.e:750		include_matrix[by_file][included_file] = or_bits( DIRECT_INCLUDE, include_matrix[by_file][included_file] )*/
    _2 = (object)SEQ_PTR(_37include_matrix_15644);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37include_matrix_15644 = MAKE_SEQ(_2);
    }
    _3 = (object)(_by_file_26801 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_37include_matrix_15644);
    _14845 = (object)*(((s1_ptr)_2)->base + _by_file_26801);
    _2 = (object)SEQ_PTR(_14845);
    _14846 = (object)*(((s1_ptr)_2)->base + _included_file_26802);
    _14845 = NOVALUE;
    if (IS_ATOM_INT(_14846)) {
        {uintptr_t tu;
             tu = (uintptr_t)2 | (uintptr_t)_14846;
             _14847 = MAKE_UINT(tu);
        }
    }
    else {
        _14847 = binary_op(OR_BITS, 2, _14846);
    }
    _14846 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _included_file_26802);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14847;
    if( _1 != _14847 ){
        DeRef(_1);
    }
    _14847 = NOVALUE;
    _14843 = NOVALUE;

    /** scanner.e:751		if is_public then*/
    if (_is_public_26803 == 0)
    {
        goto L1; // [38] 71
    }
    else{
    }

    /** scanner.e:752			include_matrix[by_file][included_file] = or_bits( PUBLIC_INCLUDE, include_matrix[by_file][included_file] )*/
    _2 = (object)SEQ_PTR(_37include_matrix_15644);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37include_matrix_15644 = MAKE_SEQ(_2);
    }
    _3 = (object)(_by_file_26801 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_37include_matrix_15644);
    _14850 = (object)*(((s1_ptr)_2)->base + _by_file_26801);
    _2 = (object)SEQ_PTR(_14850);
    _14851 = (object)*(((s1_ptr)_2)->base + _included_file_26802);
    _14850 = NOVALUE;
    if (IS_ATOM_INT(_14851)) {
        {uintptr_t tu;
             tu = (uintptr_t)4 | (uintptr_t)_14851;
             _14852 = MAKE_UINT(tu);
        }
    }
    else {
        _14852 = binary_op(OR_BITS, 4, _14851);
    }
    _14851 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _included_file_26802);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14852;
    if( _1 != _14852 ){
        DeRef(_1);
    }
    _14852 = NOVALUE;
    _14848 = NOVALUE;
L1: 

    /** scanner.e:754		if not find( by_file, file_include_by[included_file] ) then*/
    _2 = (object)SEQ_PTR(_37file_include_by_15650);
    _14853 = (object)*(((s1_ptr)_2)->base + _included_file_26802);
    _14854 = find_from(_by_file_26801, _14853, 1);
    _14853 = NOVALUE;
    if (_14854 != 0)
    goto L2; // [84] 104
    _14854 = NOVALUE;

    /** scanner.e:755			file_include_by[included_file] &= by_file*/
    _2 = (object)SEQ_PTR(_37file_include_by_15650);
    _14856 = (object)*(((s1_ptr)_2)->base + _included_file_26802);
    if (IS_SEQUENCE(_14856) && IS_ATOM(_by_file_26801)) {
        Append(&_14857, _14856, _by_file_26801);
    }
    else if (IS_ATOM(_14856) && IS_SEQUENCE(_by_file_26801)) {
    }
    else {
        Concat((object_ptr)&_14857, _14856, _by_file_26801);
        _14856 = NOVALUE;
    }
    _14856 = NOVALUE;
    _2 = (object)SEQ_PTR(_37file_include_by_15650);
    _2 = (object)(((s1_ptr)_2)->base + _included_file_26802);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14857;
    if( _1 != _14857 ){
        DeRef(_1);
    }
    _14857 = NOVALUE;
L2: 

    /** scanner.e:758		if not find( included_file, file_include[by_file] ) then*/
    _2 = (object)SEQ_PTR(_37file_include_15642);
    _14858 = (object)*(((s1_ptr)_2)->base + _by_file_26801);
    _14859 = find_from(_included_file_26802, _14858, 1);
    _14858 = NOVALUE;
    if (_14859 != 0)
    goto L3; // [117] 137
    _14859 = NOVALUE;

    /** scanner.e:759			file_include[by_file] &= included_file*/
    _2 = (object)SEQ_PTR(_37file_include_15642);
    _14861 = (object)*(((s1_ptr)_2)->base + _by_file_26801);
    if (IS_SEQUENCE(_14861) && IS_ATOM(_included_file_26802)) {
        Append(&_14862, _14861, _included_file_26802);
    }
    else if (IS_ATOM(_14861) && IS_SEQUENCE(_included_file_26802)) {
    }
    else {
        Concat((object_ptr)&_14862, _14861, _included_file_26802);
        _14861 = NOVALUE;
    }
    _14861 = NOVALUE;
    _2 = (object)SEQ_PTR(_37file_include_15642);
    _2 = (object)(((s1_ptr)_2)->base + _by_file_26801);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14862;
    if( _1 != _14862 ){
        DeRef(_1);
    }
    _14862 = NOVALUE;
L3: 

    /** scanner.e:762		if is_public then*/
    if (_is_public_26803 == 0)
    {
        goto L4; // [139] 209
    }
    else{
    }

    /** scanner.e:763			if not find( by_file, file_public_by[included_file] ) then*/
    _2 = (object)SEQ_PTR(_37file_public_by_15652);
    _14863 = (object)*(((s1_ptr)_2)->base + _included_file_26802);
    _14864 = find_from(_by_file_26801, _14863, 1);
    _14863 = NOVALUE;
    if (_14864 != 0)
    goto L5; // [155] 175
    _14864 = NOVALUE;

    /** scanner.e:764				file_public_by[included_file] &= by_file*/
    _2 = (object)SEQ_PTR(_37file_public_by_15652);
    _14866 = (object)*(((s1_ptr)_2)->base + _included_file_26802);
    if (IS_SEQUENCE(_14866) && IS_ATOM(_by_file_26801)) {
        Append(&_14867, _14866, _by_file_26801);
    }
    else if (IS_ATOM(_14866) && IS_SEQUENCE(_by_file_26801)) {
    }
    else {
        Concat((object_ptr)&_14867, _14866, _by_file_26801);
        _14866 = NOVALUE;
    }
    _14866 = NOVALUE;
    _2 = (object)SEQ_PTR(_37file_public_by_15652);
    _2 = (object)(((s1_ptr)_2)->base + _included_file_26802);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14867;
    if( _1 != _14867 ){
        DeRef(_1);
    }
    _14867 = NOVALUE;
L5: 

    /** scanner.e:767			if not find( included_file, file_public[by_file] ) then*/
    _2 = (object)SEQ_PTR(_37file_public_15648);
    _14868 = (object)*(((s1_ptr)_2)->base + _by_file_26801);
    _14869 = find_from(_included_file_26802, _14868, 1);
    _14868 = NOVALUE;
    if (_14869 != 0)
    goto L6; // [188] 208
    _14869 = NOVALUE;

    /** scanner.e:768				file_public[by_file] &= included_file*/
    _2 = (object)SEQ_PTR(_37file_public_15648);
    _14871 = (object)*(((s1_ptr)_2)->base + _by_file_26801);
    if (IS_SEQUENCE(_14871) && IS_ATOM(_included_file_26802)) {
        Append(&_14872, _14871, _included_file_26802);
    }
    else if (IS_ATOM(_14871) && IS_SEQUENCE(_included_file_26802)) {
    }
    else {
        Concat((object_ptr)&_14872, _14871, _included_file_26802);
        _14871 = NOVALUE;
    }
    _14871 = NOVALUE;
    _2 = (object)SEQ_PTR(_37file_public_15648);
    _2 = (object)(((s1_ptr)_2)->base + _by_file_26801);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14872;
    if( _1 != _14872 ){
        DeRef(_1);
    }
    _14872 = NOVALUE;
L6: 
L4: 

    /** scanner.e:772		for propagate = 1 to length( include_matrix[included_file] ) do*/
    _2 = (object)SEQ_PTR(_37include_matrix_15644);
    _14873 = (object)*(((s1_ptr)_2)->base + _included_file_26802);
    if (IS_SEQUENCE(_14873)){
            _14874 = SEQ_PTR(_14873)->length;
    }
    else {
        _14874 = 1;
    }
    _14873 = NOVALUE;
    {
        object _propagate_26855;
        _propagate_26855 = 1;
L7: 
        if (_propagate_26855 > _14874){
            goto L8; // [220] 320
        }

        /** scanner.e:773			if and_bits( PUBLIC_INCLUDE, include_matrix[included_file][propagate] ) then*/
        _2 = (object)SEQ_PTR(_37include_matrix_15644);
        _14875 = (object)*(((s1_ptr)_2)->base + _included_file_26802);
        _2 = (object)SEQ_PTR(_14875);
        _14876 = (object)*(((s1_ptr)_2)->base + _propagate_26855);
        _14875 = NOVALUE;
        if (IS_ATOM_INT(_14876)) {
            {uintptr_t tu;
                 tu = (uintptr_t)4 & (uintptr_t)_14876;
                 _14877 = MAKE_UINT(tu);
            }
        }
        else {
            _14877 = binary_op(AND_BITS, 4, _14876);
        }
        _14876 = NOVALUE;
        if (_14877 == 0) {
            DeRef(_14877);
            _14877 = NOVALUE;
            goto L9; // [245] 313
        }
        else {
            if (!IS_ATOM_INT(_14877) && DBL_PTR(_14877)->dbl == 0.0){
                DeRef(_14877);
                _14877 = NOVALUE;
                goto L9; // [245] 313
            }
            DeRef(_14877);
            _14877 = NOVALUE;
        }
        DeRef(_14877);
        _14877 = NOVALUE;

        /** scanner.e:774				include_matrix[by_file][propagate] = or_bits( DIRECT_INCLUDE, include_matrix[by_file][propagate] )*/
        _2 = (object)SEQ_PTR(_37include_matrix_15644);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37include_matrix_15644 = MAKE_SEQ(_2);
        }
        _3 = (object)(_by_file_26801 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_37include_matrix_15644);
        _14880 = (object)*(((s1_ptr)_2)->base + _by_file_26801);
        _2 = (object)SEQ_PTR(_14880);
        _14881 = (object)*(((s1_ptr)_2)->base + _propagate_26855);
        _14880 = NOVALUE;
        if (IS_ATOM_INT(_14881)) {
            {uintptr_t tu;
                 tu = (uintptr_t)2 | (uintptr_t)_14881;
                 _14882 = MAKE_UINT(tu);
            }
        }
        else {
            _14882 = binary_op(OR_BITS, 2, _14881);
        }
        _14881 = NOVALUE;
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _propagate_26855);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _14882;
        if( _1 != _14882 ){
            DeRef(_1);
        }
        _14882 = NOVALUE;
        _14878 = NOVALUE;

        /** scanner.e:775				if is_public then*/
        if (_is_public_26803 == 0)
        {
            goto LA; // [279] 312
        }
        else{
        }

        /** scanner.e:776					include_matrix[by_file][propagate] = or_bits( PUBLIC_INCLUDE, include_matrix[by_file][propagate] )*/
        _2 = (object)SEQ_PTR(_37include_matrix_15644);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37include_matrix_15644 = MAKE_SEQ(_2);
        }
        _3 = (object)(_by_file_26801 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_37include_matrix_15644);
        _14885 = (object)*(((s1_ptr)_2)->base + _by_file_26801);
        _2 = (object)SEQ_PTR(_14885);
        _14886 = (object)*(((s1_ptr)_2)->base + _propagate_26855);
        _14885 = NOVALUE;
        if (IS_ATOM_INT(_14886)) {
            {uintptr_t tu;
                 tu = (uintptr_t)4 | (uintptr_t)_14886;
                 _14887 = MAKE_UINT(tu);
            }
        }
        else {
            _14887 = binary_op(OR_BITS, 4, _14886);
        }
        _14886 = NOVALUE;
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _propagate_26855);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _14887;
        if( _1 != _14887 ){
            DeRef(_1);
        }
        _14887 = NOVALUE;
        _14883 = NOVALUE;
LA: 
L9: 

        /** scanner.e:779		end for*/
        _propagate_26855 = _propagate_26855 + 1;
        goto L7; // [315] 227
L8: 
        ;
    }

    /** scanner.e:780	end procedure*/
    _14873 = NOVALUE;
    return;
    ;
}


void _62IncludePush()
{
    object _new_file_handle_26884 = NOVALUE;
    object _old_file_no_26885 = NOVALUE;
    object _new_hash_26886 = NOVALUE;
    object _idx_26887 = NOVALUE;
    object _14974 = NOVALUE;
    object _14971 = NOVALUE;
    object _14969 = NOVALUE;
    object _14968 = NOVALUE;
    object _14967 = NOVALUE;
    object _14965 = NOVALUE;
    object _14964 = NOVALUE;
    object _14958 = NOVALUE;
    object _14957 = NOVALUE;
    object _14956 = NOVALUE;
    object _14955 = NOVALUE;
    object _14954 = NOVALUE;
    object _14953 = NOVALUE;
    object _14952 = NOVALUE;
    object _14949 = NOVALUE;
    object _14947 = NOVALUE;
    object _14945 = NOVALUE;
    object _14944 = NOVALUE;
    object _14943 = NOVALUE;
    object _14941 = NOVALUE;
    object _14940 = NOVALUE;
    object _14938 = NOVALUE;
    object _14937 = NOVALUE;
    object _14935 = NOVALUE;
    object _14934 = NOVALUE;
    object _14933 = NOVALUE;
    object _14932 = NOVALUE;
    object _14931 = NOVALUE;
    object _14930 = NOVALUE;
    object _14929 = NOVALUE;
    object _14925 = NOVALUE;
    object _14923 = NOVALUE;
    object _14922 = NOVALUE;
    object _14921 = NOVALUE;
    object _14920 = NOVALUE;
    object _14919 = NOVALUE;
    object _14918 = NOVALUE;
    object _14917 = NOVALUE;
    object _14916 = NOVALUE;
    object _14915 = NOVALUE;
    object _14913 = NOVALUE;
    object _14912 = NOVALUE;
    object _14911 = NOVALUE;
    object _14909 = NOVALUE;
    object _14908 = NOVALUE;
    object _14907 = NOVALUE;
    object _14906 = NOVALUE;
    object _14904 = NOVALUE;
    object _14903 = NOVALUE;
    object _14902 = NOVALUE;
    object _14901 = NOVALUE;
    object _14900 = NOVALUE;
    object _14898 = NOVALUE;
    object _14897 = NOVALUE;
    object _14896 = NOVALUE;
    object _14895 = NOVALUE;
    object _14893 = NOVALUE;
    object _14889 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** scanner.e:788		start_include = FALSE*/
    _62start_include_25873 = _13FALSE_445;

    /** scanner.e:790		new_file_handle = path_open() -- sets new_include_name to full path*/
    _new_file_handle_26884 = _62path_open();
    if (!IS_ATOM_INT(_new_file_handle_26884)) {
        _1 = (object)(DBL_PTR(_new_file_handle_26884)->dbl);
        DeRefDS(_new_file_handle_26884);
        _new_file_handle_26884 = _1;
    }

    /** scanner.e:792		new_hash = hash(canonical_path(new_include_name,,CORRECT), stdhash:HSIEH32)*/
    RefDS(_36new_include_name_21893);
    _14889 = _17canonical_path(_36new_include_name_21893, 0, 2);
    DeRef(_new_hash_26886);
    _new_hash_26886 = calc_hash(_14889, -5);
    DeRef(_14889);
    _14889 = NOVALUE;

    /** scanner.e:794		idx = find(new_hash, known_files_hash)*/
    _idx_26887 = find_from(_new_hash_26886, _37known_files_hash_15639, 1);

    /** scanner.e:795		if idx then*/
    if (_idx_26887 == 0)
    {
        goto L1; // [42] 335
    }
    else{
    }

    /** scanner.e:797			if new_include_space != 0 then*/
    if (_62new_include_space_25871 == 0)
    goto L2; // [49] 71

    /** scanner.e:798				SymTab[new_include_space][S_OBJ] = idx -- but note any namespace*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_62new_include_space_25871 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _idx_26887;
    DeRef(_1);
    _14893 = NOVALUE;
L2: 

    /** scanner.e:801			close(new_file_handle)*/
    EClose(_new_file_handle_26884);

    /** scanner.e:803			if find( -idx, file_include[current_file_no] ) then*/
    if ((uintptr_t)_idx_26887 == (uintptr_t)HIGH_BITS){
        _14895 = (object)NewDouble((eudouble) -HIGH_BITS);
    }
    else{
        _14895 = - _idx_26887;
    }
    _2 = (object)SEQ_PTR(_37file_include_15642);
    _14896 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21767);
    _14897 = find_from(_14895, _14896, 1);
    DeRef(_14895);
    _14895 = NOVALUE;
    _14896 = NOVALUE;
    if (_14897 == 0)
    {
        _14897 = NOVALUE;
        goto L3; // [93] 130
    }
    else{
        _14897 = NOVALUE;
    }

    /** scanner.e:805				file_include[current_file_no][ find( -idx, file_include[current_file_no] ) ] = idx*/
    _2 = (object)SEQ_PTR(_37file_include_15642);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37file_include_15642 = MAKE_SEQ(_2);
    }
    _3 = (object)(_36current_file_no_21767 + ((s1_ptr)_2)->base);
    if ((uintptr_t)_idx_26887 == (uintptr_t)HIGH_BITS){
        _14900 = (object)NewDouble((eudouble) -HIGH_BITS);
    }
    else{
        _14900 = - _idx_26887;
    }
    _2 = (object)SEQ_PTR(_37file_include_15642);
    _14901 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21767);
    _14902 = find_from(_14900, _14901, 1);
    DeRef(_14900);
    _14900 = NOVALUE;
    _14901 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _14902);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _idx_26887;
    DeRef(_1);
    _14898 = NOVALUE;
    goto L4; // [127] 228
L3: 

    /** scanner.e:809			elsif not find( idx, file_include[current_file_no] ) then*/
    _2 = (object)SEQ_PTR(_37file_include_15642);
    _14903 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21767);
    _14904 = find_from(_idx_26887, _14903, 1);
    _14903 = NOVALUE;
    if (_14904 != 0)
    goto L5; // [145] 227
    _14904 = NOVALUE;

    /** scanner.e:811				file_include[current_file_no] &= idx*/
    _2 = (object)SEQ_PTR(_37file_include_15642);
    _14906 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21767);
    if (IS_SEQUENCE(_14906) && IS_ATOM(_idx_26887)) {
        Append(&_14907, _14906, _idx_26887);
    }
    else if (IS_ATOM(_14906) && IS_SEQUENCE(_idx_26887)) {
    }
    else {
        Concat((object_ptr)&_14907, _14906, _idx_26887);
        _14906 = NOVALUE;
    }
    _14906 = NOVALUE;
    _2 = (object)SEQ_PTR(_37file_include_15642);
    _2 = (object)(((s1_ptr)_2)->base + _36current_file_no_21767);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14907;
    if( _1 != _14907 ){
        DeRef(_1);
    }
    _14907 = NOVALUE;

    /** scanner.e:814				add_exports( idx, current_file_no )*/
    _62add_exports(_idx_26887, _36current_file_no_21767);

    /** scanner.e:816				if public_include then*/
    if (_62public_include_25876 == 0)
    {
        goto L6; // [178] 226
    }
    else{
    }

    /** scanner.e:818					if not find( idx, file_public[current_file_no] ) then*/
    _2 = (object)SEQ_PTR(_37file_public_15648);
    _14908 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21767);
    _14909 = find_from(_idx_26887, _14908, 1);
    _14908 = NOVALUE;
    if (_14909 != 0)
    goto L7; // [196] 225
    _14909 = NOVALUE;

    /** scanner.e:819						file_public[current_file_no] &= idx*/
    _2 = (object)SEQ_PTR(_37file_public_15648);
    _14911 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21767);
    if (IS_SEQUENCE(_14911) && IS_ATOM(_idx_26887)) {
        Append(&_14912, _14911, _idx_26887);
    }
    else if (IS_ATOM(_14911) && IS_SEQUENCE(_idx_26887)) {
    }
    else {
        Concat((object_ptr)&_14912, _14911, _idx_26887);
        _14911 = NOVALUE;
    }
    _14911 = NOVALUE;
    _2 = (object)SEQ_PTR(_37file_public_15648);
    _2 = (object)(((s1_ptr)_2)->base + _36current_file_no_21767);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14912;
    if( _1 != _14912 ){
        DeRef(_1);
    }
    _14912 = NOVALUE;

    /** scanner.e:820						patch_exports( current_file_no )*/
    _62patch_exports(_36current_file_no_21767);
L7: 
L6: 
L5: 
L4: 

    /** scanner.e:825			indirect_include[current_file_no][idx] = OpIndirectInclude*/
    _2 = (object)SEQ_PTR(_37indirect_include_15646);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37indirect_include_15646 = MAKE_SEQ(_2);
    }
    _3 = (object)(_36current_file_no_21767 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _idx_26887);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36OpIndirectInclude_21846;
    DeRef(_1);
    _14913 = NOVALUE;

    /** scanner.e:826			add_include_by( current_file_no, idx, public_include )*/
    _62add_include_by(_36current_file_no_21767, _idx_26887, _62public_include_25876);

    /** scanner.e:827			update_include_matrix( idx, current_file_no )*/
    _62update_include_matrix(_idx_26887, _36current_file_no_21767);

    /** scanner.e:828			public_include = FALSE*/
    _62public_include_25876 = _13FALSE_445;

    /** scanner.e:829			read_line() -- we can't return without reading a line first*/
    _62read_line();

    /** scanner.e:830			if not find( idx, file_include_depend[current_file_no] ) and not finished_files[idx] then*/
    _2 = (object)SEQ_PTR(_37file_include_depend_15641);
    _14915 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21767);
    _14916 = find_from(_idx_26887, _14915, 1);
    _14915 = NOVALUE;
    _14917 = (_14916 == 0);
    _14916 = NOVALUE;
    if (_14917 == 0) {
        goto L8; // [293] 329
    }
    _2 = (object)SEQ_PTR(_37finished_files_15640);
    _14919 = (object)*(((s1_ptr)_2)->base + _idx_26887);
    _14920 = (_14919 == 0);
    _14919 = NOVALUE;
    if (_14920 == 0)
    {
        DeRef(_14920);
        _14920 = NOVALUE;
        goto L8; // [307] 329
    }
    else{
        DeRef(_14920);
        _14920 = NOVALUE;
    }

    /** scanner.e:831				file_include_depend[current_file_no] &= idx*/
    _2 = (object)SEQ_PTR(_37file_include_depend_15641);
    _14921 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21767);
    if (IS_SEQUENCE(_14921) && IS_ATOM(_idx_26887)) {
        Append(&_14922, _14921, _idx_26887);
    }
    else if (IS_ATOM(_14921) && IS_SEQUENCE(_idx_26887)) {
    }
    else {
        Concat((object_ptr)&_14922, _14921, _idx_26887);
        _14921 = NOVALUE;
    }
    _14921 = NOVALUE;
    _2 = (object)SEQ_PTR(_37file_include_depend_15641);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37file_include_depend_15641 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _36current_file_no_21767);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14922;
    if( _1 != _14922 ){
        DeRef(_1);
    }
    _14922 = NOVALUE;
L8: 

    /** scanner.e:833			return -- ignore it*/
    DeRef(_new_hash_26886);
    DeRef(_14917);
    _14917 = NOVALUE;
    return;
L1: 

    /** scanner.e:836		if length(IncludeStk) >= INCLUDE_LIMIT then*/
    if (IS_SEQUENCE(_62IncludeStk_25882)){
            _14923 = SEQ_PTR(_62IncludeStk_25882)->length;
    }
    else {
        _14923 = 1;
    }
    if (_14923 < 30)
    goto L9; // [342] 356

    /** scanner.e:837			CompileErr(INCLUDES_ARE_NESTED_TOO_DEEPLY)*/
    RefDS(_22190);
    _50CompileErr(104, _22190, 0);
L9: 

    /** scanner.e:840		IncludeStk = append(IncludeStk,*/
    _1 = NewS1(22);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _36current_file_no_21767;
    ((intptr_t*)_2)[2] = _36line_number_21768;
    ((intptr_t*)_2)[3] = _36src_file_21892;
    ((intptr_t*)_2)[4] = _36file_start_sym_21773;
    ((intptr_t*)_2)[5] = _36OpWarning_21838;
    ((intptr_t*)_2)[6] = _36OpTrace_21840;
    ((intptr_t*)_2)[7] = _36OpTypeCheck_21841;
    ((intptr_t*)_2)[8] = _36OpProfileTime_21843;
    ((intptr_t*)_2)[9] = _36OpProfileStatement_21842;
    RefDS(_36OpDefines_21844);
    ((intptr_t*)_2)[10] = _36OpDefines_21844;
    ((intptr_t*)_2)[11] = _36prev_OpWarning_21839;
    ((intptr_t*)_2)[12] = _36OpInline_21845;
    ((intptr_t*)_2)[13] = _36OpIndirectInclude_21846;
    ((intptr_t*)_2)[14] = _36putback_fwd_line_number_21770;
    Ref(_50putback_ForwardLine_49596);
    ((intptr_t*)_2)[15] = _50putback_ForwardLine_49596;
    ((intptr_t*)_2)[16] = _50putback_forward_bp_49600;
    ((intptr_t*)_2)[17] = _36last_fwd_line_number_21771;
    Ref(_50last_ForwardLine_49597);
    ((intptr_t*)_2)[18] = _50last_ForwardLine_49597;
    ((intptr_t*)_2)[19] = _50last_forward_bp_49601;
    Ref(_50ThisLine_49594);
    ((intptr_t*)_2)[20] = _50ThisLine_49594;
    ((intptr_t*)_2)[21] = _36fwd_line_number_21769;
    ((intptr_t*)_2)[22] = _50forward_bp_49599;
    _14925 = MAKE_SEQ(_1);
    RefDS(_14925);
    Append(&_62IncludeStk_25882, _62IncludeStk_25882, _14925);
    DeRefDS(_14925);
    _14925 = NOVALUE;

    /** scanner.e:864		file_include = append( file_include, {} )*/
    RefDS(_5);
    Append(&_37file_include_15642, _37file_include_15642, _5);

    /** scanner.e:865		file_include_by = append( file_include_by, {} )*/
    RefDS(_5);
    Append(&_37file_include_by_15650, _37file_include_by_15650, _5);

    /** scanner.e:866		for i = 1 to length( include_matrix) do*/
    if (IS_SEQUENCE(_37include_matrix_15644)){
            _14929 = SEQ_PTR(_37include_matrix_15644)->length;
    }
    else {
        _14929 = 1;
    }
    {
        object _i_27000;
        _i_27000 = 1;
LA: 
        if (_i_27000 > _14929){
            goto LB; // [460] 506
        }

        /** scanner.e:867			include_matrix[i]   &= 0*/
        _2 = (object)SEQ_PTR(_37include_matrix_15644);
        _14930 = (object)*(((s1_ptr)_2)->base + _i_27000);
        if (IS_SEQUENCE(_14930) && IS_ATOM(0)) {
            Append(&_14931, _14930, 0);
        }
        else if (IS_ATOM(_14930) && IS_SEQUENCE(0)) {
        }
        else {
            Concat((object_ptr)&_14931, _14930, 0);
            _14930 = NOVALUE;
        }
        _14930 = NOVALUE;
        _2 = (object)SEQ_PTR(_37include_matrix_15644);
        _2 = (object)(((s1_ptr)_2)->base + _i_27000);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _14931;
        if( _1 != _14931 ){
            DeRef(_1);
        }
        _14931 = NOVALUE;

        /** scanner.e:868			indirect_include[i] &= 0*/
        _2 = (object)SEQ_PTR(_37indirect_include_15646);
        _14932 = (object)*(((s1_ptr)_2)->base + _i_27000);
        if (IS_SEQUENCE(_14932) && IS_ATOM(0)) {
            Append(&_14933, _14932, 0);
        }
        else if (IS_ATOM(_14932) && IS_SEQUENCE(0)) {
        }
        else {
            Concat((object_ptr)&_14933, _14932, 0);
            _14932 = NOVALUE;
        }
        _14932 = NOVALUE;
        _2 = (object)SEQ_PTR(_37indirect_include_15646);
        _2 = (object)(((s1_ptr)_2)->base + _i_27000);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _14933;
        if( _1 != _14933 ){
            DeRef(_1);
        }
        _14933 = NOVALUE;

        /** scanner.e:869		end for*/
        _i_27000 = _i_27000 + 1;
        goto LA; // [501] 467
LB: 
        ;
    }

    /** scanner.e:870		include_matrix = append( include_matrix, repeat( 0, length( file_include ) ) )*/
    if (IS_SEQUENCE(_37file_include_15642)){
            _14934 = SEQ_PTR(_37file_include_15642)->length;
    }
    else {
        _14934 = 1;
    }
    _14935 = Repeat(0, _14934);
    _14934 = NOVALUE;
    RefDS(_14935);
    Append(&_37include_matrix_15644, _37include_matrix_15644, _14935);
    DeRefDS(_14935);
    _14935 = NOVALUE;

    /** scanner.e:871		include_matrix[$][$] = DIRECT_INCLUDE*/
    if (IS_SEQUENCE(_37include_matrix_15644)){
            _14937 = SEQ_PTR(_37include_matrix_15644)->length;
    }
    else {
        _14937 = 1;
    }
    _2 = (object)SEQ_PTR(_37include_matrix_15644);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37include_matrix_15644 = MAKE_SEQ(_2);
    }
    _3 = (object)(_14937 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(*(object_ptr)_3)){
            _14940 = SEQ_PTR(*(object_ptr)_3)->length;
    }
    else {
        _14940 = 1;
    }
    _14938 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _14940);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2;
    DeRef(_1);
    _14938 = NOVALUE;

    /** scanner.e:872		include_matrix[current_file_no][$] = DIRECT_INCLUDE*/
    _2 = (object)SEQ_PTR(_37include_matrix_15644);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37include_matrix_15644 = MAKE_SEQ(_2);
    }
    _3 = (object)(_36current_file_no_21767 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(*(object_ptr)_3)){
            _14943 = SEQ_PTR(*(object_ptr)_3)->length;
    }
    else {
        _14943 = 1;
    }
    _14941 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _14943);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2;
    DeRef(_1);
    _14941 = NOVALUE;

    /** scanner.e:874		indirect_include = append( indirect_include, repeat( 0, length( file_include ) ) )*/
    if (IS_SEQUENCE(_37file_include_15642)){
            _14944 = SEQ_PTR(_37file_include_15642)->length;
    }
    else {
        _14944 = 1;
    }
    _14945 = Repeat(0, _14944);
    _14944 = NOVALUE;
    RefDS(_14945);
    Append(&_37indirect_include_15646, _37indirect_include_15646, _14945);
    DeRefDS(_14945);
    _14945 = NOVALUE;

    /** scanner.e:875		indirect_include[current_file_no][$] = OpIndirectInclude*/
    _2 = (object)SEQ_PTR(_37indirect_include_15646);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37indirect_include_15646 = MAKE_SEQ(_2);
    }
    _3 = (object)(_36current_file_no_21767 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(*(object_ptr)_3)){
            _14949 = SEQ_PTR(*(object_ptr)_3)->length;
    }
    else {
        _14949 = 1;
    }
    _14947 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _14949);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36OpIndirectInclude_21846;
    DeRef(_1);
    _14947 = NOVALUE;

    /** scanner.e:876		OpIndirectInclude = 1*/
    _36OpIndirectInclude_21846 = 1;

    /** scanner.e:878		file_public  = append( file_public, {} )*/
    RefDS(_5);
    Append(&_37file_public_15648, _37file_public_15648, _5);

    /** scanner.e:879		file_public_by = append( file_public_by, {} )*/
    RefDS(_5);
    Append(&_37file_public_by_15652, _37file_public_by_15652, _5);

    /** scanner.e:880		file_include[current_file_no] &= length( file_include )*/
    if (IS_SEQUENCE(_37file_include_15642)){
            _14952 = SEQ_PTR(_37file_include_15642)->length;
    }
    else {
        _14952 = 1;
    }
    _2 = (object)SEQ_PTR(_37file_include_15642);
    _14953 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21767);
    if (IS_SEQUENCE(_14953) && IS_ATOM(_14952)) {
        Append(&_14954, _14953, _14952);
    }
    else if (IS_ATOM(_14953) && IS_SEQUENCE(_14952)) {
    }
    else {
        Concat((object_ptr)&_14954, _14953, _14952);
        _14953 = NOVALUE;
    }
    _14953 = NOVALUE;
    _14952 = NOVALUE;
    _2 = (object)SEQ_PTR(_37file_include_15642);
    _2 = (object)(((s1_ptr)_2)->base + _36current_file_no_21767);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14954;
    if( _1 != _14954 ){
        DeRef(_1);
    }
    _14954 = NOVALUE;

    /** scanner.e:881		add_include_by( current_file_no, length(file_include), public_include )*/
    if (IS_SEQUENCE(_37file_include_15642)){
            _14955 = SEQ_PTR(_37file_include_15642)->length;
    }
    else {
        _14955 = 1;
    }
    _62add_include_by(_36current_file_no_21767, _14955, _62public_include_25876);
    _14955 = NOVALUE;

    /** scanner.e:882		if public_include then*/
    if (_62public_include_25876 == 0)
    {
        goto LC; // [675] 709
    }
    else{
    }

    /** scanner.e:883			file_public[current_file_no] &= length( file_public )*/
    if (IS_SEQUENCE(_37file_public_15648)){
            _14956 = SEQ_PTR(_37file_public_15648)->length;
    }
    else {
        _14956 = 1;
    }
    _2 = (object)SEQ_PTR(_37file_public_15648);
    _14957 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21767);
    if (IS_SEQUENCE(_14957) && IS_ATOM(_14956)) {
        Append(&_14958, _14957, _14956);
    }
    else if (IS_ATOM(_14957) && IS_SEQUENCE(_14956)) {
    }
    else {
        Concat((object_ptr)&_14958, _14957, _14956);
        _14957 = NOVALUE;
    }
    _14957 = NOVALUE;
    _14956 = NOVALUE;
    _2 = (object)SEQ_PTR(_37file_public_15648);
    _2 = (object)(((s1_ptr)_2)->base + _36current_file_no_21767);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14958;
    if( _1 != _14958 ){
        DeRef(_1);
    }
    _14958 = NOVALUE;

    /** scanner.e:884			patch_exports( current_file_no )*/
    _62patch_exports(_36current_file_no_21767);
LC: 

    /** scanner.e:887	ifdef STDDEBUG then*/

    /** scanner.e:893		src_file = new_file_handle*/
    _36src_file_21892 = _new_file_handle_26884;

    /** scanner.e:894		file_start_sym = last_sym*/
    _36file_start_sym_21773 = _54last_sym_47145;

    /** scanner.e:895		if current_file_no >= MAX_FILE then*/
    if (_36current_file_no_21767 < 256)
    goto LD; // [731] 745

    /** scanner.e:896			CompileErr(PROGRAM_INCLUDES_TOO_MANY_FILES)*/
    RefDS(_22190);
    _50CompileErr(126, _22190, 0);
LD: 

    /** scanner.e:898		known_files = append(known_files, new_include_name)*/
    RefDS(_36new_include_name_21893);
    Append(&_37known_files_15638, _37known_files_15638, _36new_include_name_21893);

    /** scanner.e:899		known_files_hash &= new_hash*/
    Ref(_new_hash_26886);
    Append(&_37known_files_hash_15639, _37known_files_hash_15639, _new_hash_26886);

    /** scanner.e:900		finished_files &= 0*/
    Append(&_37finished_files_15640, _37finished_files_15640, 0);

    /** scanner.e:901		file_include_depend = append( file_include_depend, { length( known_files ) } )*/
    if (IS_SEQUENCE(_37known_files_15638)){
            _14964 = SEQ_PTR(_37known_files_15638)->length;
    }
    else {
        _14964 = 1;
    }
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _14964;
    _14965 = MAKE_SEQ(_1);
    _14964 = NOVALUE;
    RefDS(_14965);
    Append(&_37file_include_depend_15641, _37file_include_depend_15641, _14965);
    DeRefDS(_14965);
    _14965 = NOVALUE;

    /** scanner.e:902		file_include_depend[current_file_no] &= length( known_files )*/
    if (IS_SEQUENCE(_37known_files_15638)){
            _14967 = SEQ_PTR(_37known_files_15638)->length;
    }
    else {
        _14967 = 1;
    }
    _2 = (object)SEQ_PTR(_37file_include_depend_15641);
    _14968 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21767);
    if (IS_SEQUENCE(_14968) && IS_ATOM(_14967)) {
        Append(&_14969, _14968, _14967);
    }
    else if (IS_ATOM(_14968) && IS_SEQUENCE(_14967)) {
    }
    else {
        Concat((object_ptr)&_14969, _14968, _14967);
        _14968 = NOVALUE;
    }
    _14968 = NOVALUE;
    _14967 = NOVALUE;
    _2 = (object)SEQ_PTR(_37file_include_depend_15641);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37file_include_depend_15641 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _36current_file_no_21767);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14969;
    if( _1 != _14969 ){
        DeRef(_1);
    }
    _14969 = NOVALUE;

    /** scanner.e:903		check_coverage()*/
    _51check_coverage();

    /** scanner.e:904		default_namespaces &= 0*/
    Append(&_62default_namespaces_25879, _62default_namespaces_25879, 0);

    /** scanner.e:906		update_include_matrix( length( file_include ), current_file_no )*/
    if (IS_SEQUENCE(_37file_include_15642)){
            _14971 = SEQ_PTR(_37file_include_15642)->length;
    }
    else {
        _14971 = 1;
    }
    _62update_include_matrix(_14971, _36current_file_no_21767);
    _14971 = NOVALUE;

    /** scanner.e:907		old_file_no = current_file_no*/
    _old_file_no_26885 = _36current_file_no_21767;

    /** scanner.e:908		current_file_no = length(known_files)*/
    if (IS_SEQUENCE(_37known_files_15638)){
            _36current_file_no_21767 = SEQ_PTR(_37known_files_15638)->length;
    }
    else {
        _36current_file_no_21767 = 1;
    }

    /** scanner.e:909		line_number = 0*/
    _36line_number_21768 = 0;

    /** scanner.e:910		read_line()*/
    _62read_line();

    /** scanner.e:912		if new_include_space != 0 then*/
    if (_62new_include_space_25871 == 0)
    goto LE; // [877] 901

    /** scanner.e:913			SymTab[new_include_space][S_OBJ] = current_file_no*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_62new_include_space_25871 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36current_file_no_21767;
    DeRef(_1);
    _14974 = NOVALUE;
LE: 

    /** scanner.e:915		default_namespace( )*/
    _62default_namespace();

    /** scanner.e:916	end procedure*/
    DeRef(_new_hash_26886);
    DeRef(_14917);
    _14917 = NOVALUE;
    return;
    ;
}


void _62update_include_completion(object _file_no_27111)
{
    object _fx_27120 = NOVALUE;
    object _14984 = NOVALUE;
    object _14983 = NOVALUE;
    object _14982 = NOVALUE;
    object _14981 = NOVALUE;
    object _14979 = NOVALUE;
    object _14978 = NOVALUE;
    object _14977 = NOVALUE;
    object _14976 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:919		for i = 1 to length( file_include_depend ) do*/
    if (IS_SEQUENCE(_37file_include_depend_15641)){
            _14976 = SEQ_PTR(_37file_include_depend_15641)->length;
    }
    else {
        _14976 = 1;
    }
    {
        object _i_27113;
        _i_27113 = 1;
L1: 
        if (_i_27113 > _14976){
            goto L2; // [10] 114
        }

        /** scanner.e:920			if length( file_include_depend[i] ) then*/
        _2 = (object)SEQ_PTR(_37file_include_depend_15641);
        _14977 = (object)*(((s1_ptr)_2)->base + _i_27113);
        if (IS_SEQUENCE(_14977)){
                _14978 = SEQ_PTR(_14977)->length;
        }
        else {
            _14978 = 1;
        }
        _14977 = NOVALUE;
        if (_14978 == 0)
        {
            _14978 = NOVALUE;
            goto L3; // [28] 105
        }
        else{
            _14978 = NOVALUE;
        }

        /** scanner.e:921				integer fx = find( file_no, file_include_depend[i] )*/
        _2 = (object)SEQ_PTR(_37file_include_depend_15641);
        _14979 = (object)*(((s1_ptr)_2)->base + _i_27113);
        _fx_27120 = find_from(_file_no_27111, _14979, 1);
        _14979 = NOVALUE;

        /** scanner.e:922				if fx then*/
        if (_fx_27120 == 0)
        {
            goto L4; // [46] 104
        }
        else{
        }

        /** scanner.e:923					file_include_depend[i] = remove( file_include_depend[i], fx )*/
        _2 = (object)SEQ_PTR(_37file_include_depend_15641);
        _14981 = (object)*(((s1_ptr)_2)->base + _i_27113);
        {
            s1_ptr assign_space = SEQ_PTR(_14981);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_fx_27120)) ? _fx_27120 : (object)(DBL_PTR(_fx_27120)->dbl);
            int stop = (IS_ATOM_INT(_fx_27120)) ? _fx_27120 : (object)(DBL_PTR(_fx_27120)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<1) {
                RefDS(_14981);
                DeRef(_14982);
                _14982 = _14981;
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_14981), start, &_14982 );
                }
                else Tail(SEQ_PTR(_14981), stop+1, &_14982);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_14981), start, &_14982);
            }
            else {
                assign_slice_seq = &assign_space;
                _1 = Remove_elements(start, stop, 0);
                DeRef(_14982);
                _14982 = _1;
            }
        }
        _14981 = NOVALUE;
        _2 = (object)SEQ_PTR(_37file_include_depend_15641);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37file_include_depend_15641 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_27113);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _14982;
        if( _1 != _14982 ){
            DeRef(_1);
        }
        _14982 = NOVALUE;

        /** scanner.e:924					if not length( file_include_depend[i] ) then*/
        _2 = (object)SEQ_PTR(_37file_include_depend_15641);
        _14983 = (object)*(((s1_ptr)_2)->base + _i_27113);
        if (IS_SEQUENCE(_14983)){
                _14984 = SEQ_PTR(_14983)->length;
        }
        else {
            _14984 = 1;
        }
        _14983 = NOVALUE;
        if (_14984 != 0)
        goto L5; // [79] 103
        _14984 = NOVALUE;

        /** scanner.e:925						finished_files[i] = 1*/
        _2 = (object)SEQ_PTR(_37finished_files_15640);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37finished_files_15640 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_27113);
        *(intptr_t *)_2 = 1;

        /** scanner.e:926						if i != file_no then*/
        if (_i_27113 == _file_no_27111)
        goto L6; // [92] 102

        /** scanner.e:927							update_include_completion( i )*/
        _62update_include_completion(_i_27113);
L6: 
L5: 
L4: 
L3: 

        /** scanner.e:932		end for*/
        _i_27113 = _i_27113 + 1;
        goto L1; // [109] 17
L2: 
        ;
    }

    /** scanner.e:933	end procedure*/
    _14983 = NOVALUE;
    _14977 = NOVALUE;
    return;
    ;
}


object _62IncludePop()
{
    object _top_27151 = NOVALUE;
    object _15015 = NOVALUE;
    object _15013 = NOVALUE;
    object _15012 = NOVALUE;
    object _14990 = NOVALUE;
    object _14988 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** scanner.e:940		update_include_completion( current_file_no )*/
    _62update_include_completion(_36current_file_no_21767);

    /** scanner.e:941		Resolve_forward_references()*/
    _44Resolve_forward_references(0);

    /** scanner.e:942		HideLocals()*/
    _54HideLocals();

    /** scanner.e:944		if src_file >= 0 then*/
    if (_36src_file_21892 < 0)
    goto L1; // [21] 39

    /** scanner.e:945			close(src_file)*/
    EClose(_36src_file_21892);

    /** scanner.e:946			src_file = -1*/
    _36src_file_21892 = -1;
L1: 

    /** scanner.e:949		if length(IncludeStk) = 0 then*/
    if (IS_SEQUENCE(_62IncludeStk_25882)){
            _14988 = SEQ_PTR(_62IncludeStk_25882)->length;
    }
    else {
        _14988 = 1;
    }
    if (_14988 != 0)
    goto L2; // [46] 59

    /** scanner.e:950			return FALSE  -- the end*/
    DeRef(_top_27151);
    return _13FALSE_445;
L2: 

    /** scanner.e:953		sequence top = IncludeStk[$]*/
    if (IS_SEQUENCE(_62IncludeStk_25882)){
            _14990 = SEQ_PTR(_62IncludeStk_25882)->length;
    }
    else {
        _14990 = 1;
    }
    DeRef(_top_27151);
    _2 = (object)SEQ_PTR(_62IncludeStk_25882);
    _top_27151 = (object)*(((s1_ptr)_2)->base + _14990);
    RefDS(_top_27151);

    /** scanner.e:955		current_file_no    = top[FILE_NO]*/
    _2 = (object)SEQ_PTR(_top_27151);
    _36current_file_no_21767 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_36current_file_no_21767)){
        _36current_file_no_21767 = (object)DBL_PTR(_36current_file_no_21767)->dbl;
    }

    /** scanner.e:956		line_number        = top[LINE_NO]*/
    _2 = (object)SEQ_PTR(_top_27151);
    _36line_number_21768 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_36line_number_21768)){
        _36line_number_21768 = (object)DBL_PTR(_36line_number_21768)->dbl;
    }

    /** scanner.e:957		src_file           = top[FILE_PTR]*/
    _2 = (object)SEQ_PTR(_top_27151);
    _36src_file_21892 = (object)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_36src_file_21892)){
        _36src_file_21892 = (object)DBL_PTR(_36src_file_21892)->dbl;
    }

    /** scanner.e:958		file_start_sym     = top[FILE_START_SYM]*/
    _2 = (object)SEQ_PTR(_top_27151);
    _36file_start_sym_21773 = (object)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_36file_start_sym_21773)){
        _36file_start_sym_21773 = (object)DBL_PTR(_36file_start_sym_21773)->dbl;
    }

    /** scanner.e:959		OpWarning          = top[OP_WARNING]*/
    _2 = (object)SEQ_PTR(_top_27151);
    _36OpWarning_21838 = (object)*(((s1_ptr)_2)->base + 5);
    if (!IS_ATOM_INT(_36OpWarning_21838)){
        _36OpWarning_21838 = (object)DBL_PTR(_36OpWarning_21838)->dbl;
    }

    /** scanner.e:960		OpTrace            = top[OP_TRACE]*/
    _2 = (object)SEQ_PTR(_top_27151);
    _36OpTrace_21840 = (object)*(((s1_ptr)_2)->base + 6);
    if (!IS_ATOM_INT(_36OpTrace_21840)){
        _36OpTrace_21840 = (object)DBL_PTR(_36OpTrace_21840)->dbl;
    }

    /** scanner.e:961		OpTypeCheck        = top[OP_TYPE_CHECK]*/
    _2 = (object)SEQ_PTR(_top_27151);
    _36OpTypeCheck_21841 = (object)*(((s1_ptr)_2)->base + 7);
    if (!IS_ATOM_INT(_36OpTypeCheck_21841)){
        _36OpTypeCheck_21841 = (object)DBL_PTR(_36OpTypeCheck_21841)->dbl;
    }

    /** scanner.e:962		OpProfileTime      = top[OP_PROFILE_TIME]*/
    _2 = (object)SEQ_PTR(_top_27151);
    _36OpProfileTime_21843 = (object)*(((s1_ptr)_2)->base + 8);
    if (!IS_ATOM_INT(_36OpProfileTime_21843)){
        _36OpProfileTime_21843 = (object)DBL_PTR(_36OpProfileTime_21843)->dbl;
    }

    /** scanner.e:963		OpProfileStatement = top[OP_PROFILE_STATEMENT]*/
    _2 = (object)SEQ_PTR(_top_27151);
    _36OpProfileStatement_21842 = (object)*(((s1_ptr)_2)->base + 9);
    if (!IS_ATOM_INT(_36OpProfileStatement_21842)){
        _36OpProfileStatement_21842 = (object)DBL_PTR(_36OpProfileStatement_21842)->dbl;
    }

    /** scanner.e:964		OpDefines          = top[OP_DEFINES]*/
    DeRef(_36OpDefines_21844);
    _2 = (object)SEQ_PTR(_top_27151);
    _36OpDefines_21844 = (object)*(((s1_ptr)_2)->base + 10);
    Ref(_36OpDefines_21844);

    /** scanner.e:965		prev_OpWarning     = top[PREV_OP_WARNING]*/
    _2 = (object)SEQ_PTR(_top_27151);
    _36prev_OpWarning_21839 = (object)*(((s1_ptr)_2)->base + 11);
    if (!IS_ATOM_INT(_36prev_OpWarning_21839)){
        _36prev_OpWarning_21839 = (object)DBL_PTR(_36prev_OpWarning_21839)->dbl;
    }

    /** scanner.e:966		OpInline           = top[OP_INLINE]*/
    _2 = (object)SEQ_PTR(_top_27151);
    _36OpInline_21845 = (object)*(((s1_ptr)_2)->base + 12);
    if (!IS_ATOM_INT(_36OpInline_21845)){
        _36OpInline_21845 = (object)DBL_PTR(_36OpInline_21845)->dbl;
    }

    /** scanner.e:967		OpIndirectInclude  = top[OP_INDIRECT_INCLUDE]*/
    _2 = (object)SEQ_PTR(_top_27151);
    _36OpIndirectInclude_21846 = (object)*(((s1_ptr)_2)->base + 13);
    if (!IS_ATOM_INT(_36OpIndirectInclude_21846)){
        _36OpIndirectInclude_21846 = (object)DBL_PTR(_36OpIndirectInclude_21846)->dbl;
    }

    /** scanner.e:968		putback_fwd_line_number = line_number -- top[PUTBACK_FWD_LINE_NUMBER]*/
    _36putback_fwd_line_number_21770 = _36line_number_21768;

    /** scanner.e:969		putback_ForwardLine = top[PUTBACK_FORWARDLINE]*/
    DeRef(_50putback_ForwardLine_49596);
    _2 = (object)SEQ_PTR(_top_27151);
    _50putback_ForwardLine_49596 = (object)*(((s1_ptr)_2)->base + 15);
    Ref(_50putback_ForwardLine_49596);

    /** scanner.e:970		putback_forward_bp = top[PUTBACK_FORWARD_BP]*/
    _2 = (object)SEQ_PTR(_top_27151);
    _50putback_forward_bp_49600 = (object)*(((s1_ptr)_2)->base + 16);
    if (!IS_ATOM_INT(_50putback_forward_bp_49600)){
        _50putback_forward_bp_49600 = (object)DBL_PTR(_50putback_forward_bp_49600)->dbl;
    }

    /** scanner.e:971		last_fwd_line_number = top[LAST_FWD_LINE_NUMBER]*/
    _2 = (object)SEQ_PTR(_top_27151);
    _36last_fwd_line_number_21771 = (object)*(((s1_ptr)_2)->base + 17);
    if (!IS_ATOM_INT(_36last_fwd_line_number_21771)){
        _36last_fwd_line_number_21771 = (object)DBL_PTR(_36last_fwd_line_number_21771)->dbl;
    }

    /** scanner.e:972		last_ForwardLine = top[LAST_FORWARDLINE]*/
    DeRef(_50last_ForwardLine_49597);
    _2 = (object)SEQ_PTR(_top_27151);
    _50last_ForwardLine_49597 = (object)*(((s1_ptr)_2)->base + 18);
    Ref(_50last_ForwardLine_49597);

    /** scanner.e:973		last_forward_bp = top[LAST_FORWARD_BP]*/
    _2 = (object)SEQ_PTR(_top_27151);
    _50last_forward_bp_49601 = (object)*(((s1_ptr)_2)->base + 19);
    if (!IS_ATOM_INT(_50last_forward_bp_49601)){
        _50last_forward_bp_49601 = (object)DBL_PTR(_50last_forward_bp_49601)->dbl;
    }

    /** scanner.e:974		ThisLine = top[THISLINE]*/
    DeRef(_50ThisLine_49594);
    _2 = (object)SEQ_PTR(_top_27151);
    _50ThisLine_49594 = (object)*(((s1_ptr)_2)->base + 20);
    Ref(_50ThisLine_49594);

    /** scanner.e:976		fwd_line_number = line_number --top[FWD_LINE_NUMBER]*/
    _36fwd_line_number_21769 = _36line_number_21768;

    /** scanner.e:977		forward_bp = top[FORWARD_BP]*/
    _2 = (object)SEQ_PTR(_top_27151);
    _50forward_bp_49599 = (object)*(((s1_ptr)_2)->base + 22);
    if (!IS_ATOM_INT(_50forward_bp_49599)){
        _50forward_bp_49599 = (object)DBL_PTR(_50forward_bp_49599)->dbl;
    }

    /** scanner.e:978		ForwardLine = ThisLine*/
    Ref(_50ThisLine_49594);
    DeRef(_50ForwardLine_49595);
    _50ForwardLine_49595 = _50ThisLine_49594;

    /** scanner.e:980		putback_ForwardLine = ThisLine*/
    Ref(_50ThisLine_49594);
    DeRef(_50putback_ForwardLine_49596);
    _50putback_ForwardLine_49596 = _50ThisLine_49594;

    /** scanner.e:981		last_ForwardLine = ThisLine*/
    Ref(_50ThisLine_49594);
    DeRef(_50last_ForwardLine_49597);
    _50last_ForwardLine_49597 = _50ThisLine_49594;

    /** scanner.e:983		IncludeStk = IncludeStk[1..$-1]*/
    if (IS_SEQUENCE(_62IncludeStk_25882)){
            _15012 = SEQ_PTR(_62IncludeStk_25882)->length;
    }
    else {
        _15012 = 1;
    }
    _15013 = _15012 - 1;
    _15012 = NOVALUE;
    rhs_slice_target = (object_ptr)&_62IncludeStk_25882;
    RHS_Slice(_62IncludeStk_25882, 1, _15013);

    /** scanner.e:984		SymTab[TopLevelSub][S_CODE] = Code*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_36TopLevelSub_21774 + ((s1_ptr)_2)->base);
    RefDS(_36Code_21859);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_CODE_21416))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21416)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_CODE_21416);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36Code_21859;
    DeRef(_1);
    _15015 = NOVALUE;

    /** scanner.e:987		return TRUE*/
    DeRefDS(_top_27151);
    _15013 = NOVALUE;
    return _13TRUE_447;
    ;
}


object _62MakeInt(object _text_27252, object _nBase_27253)
{
    object _num_27254 = NOVALUE;
    object _maxchk_27255 = NOVALUE;
    object _fnum_27256 = NOVALUE;
    object _digit_27257 = NOVALUE;
    object _15065 = NOVALUE;
    object _15063 = NOVALUE;
    object _15061 = NOVALUE;
    object _15058 = NOVALUE;
    object _15057 = NOVALUE;
    object _15056 = NOVALUE;
    object _15054 = NOVALUE;
    object _15052 = NOVALUE;
    object _15051 = NOVALUE;
    object _15050 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_nBase_27253)) {
        _1 = (object)(DBL_PTR(_nBase_27253)->dbl);
        DeRefDS(_nBase_27253);
        _nBase_27253 = _1;
    }

    /** scanner.e:1012		ifdef BITS32 then*/

    /** scanner.e:1013			atom num, maxchk*/

    /** scanner.e:1017		atom fnum*/

    /** scanner.e:1018		integer digit*/

    /** scanner.e:1021		switch nBase do*/
    _0 = _nBase_27253;
    switch ( _0 ){ 

        /** scanner.e:1022			case 2 then*/
        case 2:

        /** scanner.e:1023				maxchk = MAXCHK2*/
        _maxchk_27255 = 536870911;
        goto L1; // [29] 90

        /** scanner.e:1025			case 8 then*/
        case 8:

        /** scanner.e:1026				maxchk = MAXCHK8*/
        _maxchk_27255 = 134217727;
        goto L1; // [40] 90

        /** scanner.e:1028			case 10 then*/
        case 10:

        /** scanner.e:1030				num = find(text, common_int_text)*/
        DeRef(_num_27254);
        _num_27254 = find_from(_text_27252, _62common_int_text_27227, 1);

        /** scanner.e:1031				if num then*/
        if (_num_27254 == 0)
        {
            goto L2; // [57] 73
        }
        else{
        }

        /** scanner.e:1032					return common_ints[num]*/
        _2 = (object)SEQ_PTR(_62common_ints_27247);
        _15050 = (object)*(((s1_ptr)_2)->base + _num_27254);
        DeRefDS(_text_27252);
        DeRef(_fnum_27256);
        return _15050;
L2: 

        /** scanner.e:1035				maxchk = MAXCHK10*/
        _maxchk_27255 = 107374181;
        goto L1; // [78] 90

        /** scanner.e:1037			case 16 then*/
        case 16:

        /** scanner.e:1038				maxchk = MAXCHK16*/
        _maxchk_27255 = 67108863;
    ;}L1: 

    /** scanner.e:1042		num = 0*/
    DeRef(_num_27254);
    _num_27254 = 0;

    /** scanner.e:1043		fnum = 0*/
    DeRef(_fnum_27256);
    _fnum_27256 = 0;

    /** scanner.e:1044		for i = 1 to length(text) do*/
    if (IS_SEQUENCE(_text_27252)){
            _15051 = SEQ_PTR(_text_27252)->length;
    }
    else {
        _15051 = 1;
    }
    {
        object _i_27268;
        _i_27268 = 1;
L3: 
        if (_i_27268 > _15051){
            goto L4; // [105] 220
        }

        /** scanner.e:1045			digit = (text[i] - '0')*/
        _2 = (object)SEQ_PTR(_text_27252);
        _15052 = (object)*(((s1_ptr)_2)->base + _i_27268);
        if (IS_ATOM_INT(_15052)) {
            _digit_27257 = _15052 - 48;
        }
        else {
            _digit_27257 = binary_op(MINUS, _15052, 48);
        }
        _15052 = NOVALUE;
        if (!IS_ATOM_INT(_digit_27257)) {
            _1 = (object)(DBL_PTR(_digit_27257)->dbl);
            DeRefDS(_digit_27257);
            _digit_27257 = _1;
        }

        /** scanner.e:1046			if digit >= nBase or digit < 0 then*/
        _15054 = (_digit_27257 >= _nBase_27253);
        if (_15054 != 0) {
            goto L5; // [130] 143
        }
        _15056 = (_digit_27257 < 0);
        if (_15056 == 0)
        {
            DeRef(_15056);
            _15056 = NOVALUE;
            goto L6; // [139] 161
        }
        else{
            DeRef(_15056);
            _15056 = NOVALUE;
        }
L5: 

        /** scanner.e:1047				CompileErr(DIGIT_1_AT_POSITION_2_IS_OUTSIDE_OF_NUMBER_BASE, {text[i],i})*/
        _2 = (object)SEQ_PTR(_text_27252);
        _15057 = (object)*(((s1_ptr)_2)->base + _i_27268);
        Ref(_15057);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _15057;
        ((intptr_t *)_2)[2] = _i_27268;
        _15058 = MAKE_SEQ(_1);
        _15057 = NOVALUE;
        _50CompileErr(62, _15058, 0);
        _15058 = NOVALUE;
L6: 

        /** scanner.e:1049			if fnum = 0 then*/
        if (binary_op_a(NOTEQ, _fnum_27256, 0)){
            goto L7; // [163] 202
        }

        /** scanner.e:1050				if num <= maxchk then*/
        if (binary_op_a(GREATER, _num_27254, _maxchk_27255)){
            goto L8; // [171] 188
        }

        /** scanner.e:1051					num = num * nBase + digit*/
        if (IS_ATOM_INT(_num_27254)) {
            if (_num_27254 == (short)_num_27254 && _nBase_27253 <= INT15 && _nBase_27253 >= -INT15){
                _15061 = _num_27254 * _nBase_27253;
            }
            else{
                _15061 = NewDouble(_num_27254 * (eudouble)_nBase_27253);
            }
        }
        else {
            _15061 = NewDouble(DBL_PTR(_num_27254)->dbl * (eudouble)_nBase_27253);
        }
        DeRef(_num_27254);
        if (IS_ATOM_INT(_15061)) {
            _num_27254 = _15061 + _digit_27257;
            if ((object)((uintptr_t)_num_27254 + (uintptr_t)HIGH_BITS) >= 0){
                _num_27254 = NewDouble((eudouble)_num_27254);
            }
        }
        else {
            _num_27254 = NewDouble(DBL_PTR(_15061)->dbl + (eudouble)_digit_27257);
        }
        DeRef(_15061);
        _15061 = NOVALUE;
        goto L9; // [185] 213
L8: 

        /** scanner.e:1053					fnum = num * nBase + digit*/
        if (IS_ATOM_INT(_num_27254)) {
            if (_num_27254 == (short)_num_27254 && _nBase_27253 <= INT15 && _nBase_27253 >= -INT15){
                _15063 = _num_27254 * _nBase_27253;
            }
            else{
                _15063 = NewDouble(_num_27254 * (eudouble)_nBase_27253);
            }
        }
        else {
            _15063 = NewDouble(DBL_PTR(_num_27254)->dbl * (eudouble)_nBase_27253);
        }
        DeRef(_fnum_27256);
        if (IS_ATOM_INT(_15063)) {
            _fnum_27256 = _15063 + _digit_27257;
            if ((object)((uintptr_t)_fnum_27256 + (uintptr_t)HIGH_BITS) >= 0){
                _fnum_27256 = NewDouble((eudouble)_fnum_27256);
            }
        }
        else {
            _fnum_27256 = NewDouble(DBL_PTR(_15063)->dbl + (eudouble)_digit_27257);
        }
        DeRef(_15063);
        _15063 = NOVALUE;
        goto L9; // [199] 213
L7: 

        /** scanner.e:1056				fnum = fnum * nBase + digit*/
        if (IS_ATOM_INT(_fnum_27256)) {
            if (_fnum_27256 == (short)_fnum_27256 && _nBase_27253 <= INT15 && _nBase_27253 >= -INT15){
                _15065 = _fnum_27256 * _nBase_27253;
            }
            else{
                _15065 = NewDouble(_fnum_27256 * (eudouble)_nBase_27253);
            }
        }
        else {
            _15065 = NewDouble(DBL_PTR(_fnum_27256)->dbl * (eudouble)_nBase_27253);
        }
        DeRef(_fnum_27256);
        if (IS_ATOM_INT(_15065)) {
            _fnum_27256 = _15065 + _digit_27257;
            if ((object)((uintptr_t)_fnum_27256 + (uintptr_t)HIGH_BITS) >= 0){
                _fnum_27256 = NewDouble((eudouble)_fnum_27256);
            }
        }
        else {
            _fnum_27256 = NewDouble(DBL_PTR(_15065)->dbl + (eudouble)_digit_27257);
        }
        DeRef(_15065);
        _15065 = NOVALUE;
L9: 

        /** scanner.e:1058		end for*/
        _i_27268 = _i_27268 + 1;
        goto L3; // [215] 112
L4: 
        ;
    }

    /** scanner.e:1060		if fnum = 0 then*/
    if (binary_op_a(NOTEQ, _fnum_27256, 0)){
        goto LA; // [222] 235
    }

    /** scanner.e:1061			return num*/
    DeRefDS(_text_27252);
    DeRef(_fnum_27256);
    DeRef(_15054);
    _15054 = NOVALUE;
    _15050 = NOVALUE;
    return _num_27254;
    goto LB; // [232] 242
LA: 

    /** scanner.e:1063			return fnum*/
    DeRefDS(_text_27252);
    DeRef(_num_27254);
    DeRef(_15054);
    _15054 = NOVALUE;
    _15050 = NOVALUE;
    return _fnum_27256;
LB: 
    ;
}


object _62GetHexChar(object _cnt_27297, object _errno_27298)
{
    object _val_27299 = NOVALUE;
    object _d_27300 = NOVALUE;
    object _15075 = NOVALUE;
    object _15074 = NOVALUE;
    object _15069 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:1070		val = 0*/
    DeRef(_val_27299);
    _val_27299 = 0;

    /** scanner.e:1072		while cnt > 0 do*/
L1: 
    if (_cnt_27297 <= 0)
    goto L2; // [15] 88

    /** scanner.e:1073			d = find(getch(), "0123456789ABCDEFabcdef_")*/
    _15069 = _62getch();
    _d_27300 = find_from(_15069, _15070, 1);
    DeRef(_15069);
    _15069 = NOVALUE;

    /** scanner.e:1074			if d = 0 then*/
    if (_d_27300 != 0)
    goto L3; // [31] 43

    /** scanner.e:1075				CompileErr( errno )*/
    RefDS(_22190);
    _50CompileErr(_errno_27298, _22190, 0);
L3: 

    /** scanner.e:1077			if d != 23 then*/
    if (_d_27300 == 23)
    goto L1; // [45] 15

    /** scanner.e:1078				val = val * 16 + d - 1*/
    if (IS_ATOM_INT(_val_27299)) {
        if (_val_27299 == (short)_val_27299){
            _15074 = _val_27299 * 16;
        }
        else{
            _15074 = NewDouble(_val_27299 * (eudouble)16);
        }
    }
    else {
        _15074 = NewDouble(DBL_PTR(_val_27299)->dbl * (eudouble)16);
    }
    if (IS_ATOM_INT(_15074)) {
        _15075 = _15074 + _d_27300;
        if ((object)((uintptr_t)_15075 + (uintptr_t)HIGH_BITS) >= 0){
            _15075 = NewDouble((eudouble)_15075);
        }
    }
    else {
        _15075 = NewDouble(DBL_PTR(_15074)->dbl + (eudouble)_d_27300);
    }
    DeRef(_15074);
    _15074 = NOVALUE;
    DeRef(_val_27299);
    if (IS_ATOM_INT(_15075)) {
        _val_27299 = _15075 - 1;
        if ((object)((uintptr_t)_val_27299 +(uintptr_t) HIGH_BITS) >= 0){
            _val_27299 = NewDouble((eudouble)_val_27299);
        }
    }
    else {
        _val_27299 = NewDouble(DBL_PTR(_15075)->dbl - (eudouble)1);
    }
    DeRef(_15075);
    _15075 = NOVALUE;

    /** scanner.e:1079				if d > 16 then*/
    if (_d_27300 <= 16)
    goto L4; // [65] 76

    /** scanner.e:1080					val -= 6*/
    _0 = _val_27299;
    if (IS_ATOM_INT(_val_27299)) {
        _val_27299 = _val_27299 - 6;
        if ((object)((uintptr_t)_val_27299 +(uintptr_t) HIGH_BITS) >= 0){
            _val_27299 = NewDouble((eudouble)_val_27299);
        }
    }
    else {
        _val_27299 = NewDouble(DBL_PTR(_val_27299)->dbl - (eudouble)6);
    }
    DeRef(_0);
L4: 

    /** scanner.e:1082				cnt -= 1*/
    _cnt_27297 = _cnt_27297 - 1;

    /** scanner.e:1084		end while*/
    goto L1; // [85] 15
L2: 

    /** scanner.e:1086		return val*/
    return _val_27299;
    ;
}


object _62GetBinaryChar(object _delim_27320)
{
    object _val_27321 = NOVALUE;
    object _d_27322 = NOVALUE;
    object _vchars_27323 = NOVALUE;
    object _cnt_27326 = NOVALUE;
    object _15089 = NOVALUE;
    object _15088 = NOVALUE;
    object _15082 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:1092		sequence vchars = "01_ " & delim*/
    Append(&_vchars_27323, _15080, _delim_27320);

    /** scanner.e:1093		integer cnt = 0*/
    _cnt_27326 = 0;

    /** scanner.e:1094		val = 0*/
    DeRef(_val_27321);
    _val_27321 = 0;

    /** scanner.e:1095		while 1 do*/
L1: 

    /** scanner.e:1096			d = find(getch(), vchars)*/
    _15082 = _62getch();
    _d_27322 = find_from(_15082, _vchars_27323, 1);
    DeRef(_15082);
    _15082 = NOVALUE;

    /** scanner.e:1097			if d = 0 then*/
    if (_d_27322 != 0)
    goto L2; // [36] 50

    /** scanner.e:1098				CompileErr( EXPECTING_ONLY_0_1_OR_SPACE_TO_FOLLOW_THE_B)*/
    RefDS(_22190);
    _50CompileErr(343, _22190, 0);
L2: 

    /** scanner.e:1100			if d = 5 then*/
    if (_d_27322 != 5)
    goto L3; // [52] 65

    /** scanner.e:1101				ungetch()*/
    _62ungetch();

    /** scanner.e:1102				exit*/
    goto L4; // [62] 108
L3: 

    /** scanner.e:1104			if d = 4 then*/
    if (_d_27322 != 4)
    goto L5; // [67] 76

    /** scanner.e:1105				exit*/
    goto L4; // [73] 108
L5: 

    /** scanner.e:1107			if d != 3 then*/
    if (_d_27322 == 3)
    goto L1; // [78] 24

    /** scanner.e:1108				val = val * 2 + d - 1*/
    if (IS_ATOM_INT(_val_27321) && IS_ATOM_INT(_val_27321)) {
        _15088 = _val_27321 + _val_27321;
        if ((object)((uintptr_t)_15088 + (uintptr_t)HIGH_BITS) >= 0){
            _15088 = NewDouble((eudouble)_15088);
        }
    }
    else {
        if (IS_ATOM_INT(_val_27321)) {
            _15088 = NewDouble((eudouble)_val_27321 + DBL_PTR(_val_27321)->dbl);
        }
        else {
            if (IS_ATOM_INT(_val_27321)) {
                _15088 = NewDouble(DBL_PTR(_val_27321)->dbl + (eudouble)_val_27321);
            }
            else
            _15088 = NewDouble(DBL_PTR(_val_27321)->dbl + DBL_PTR(_val_27321)->dbl);
        }
    }
    if (IS_ATOM_INT(_15088)) {
        _15089 = _15088 + _d_27322;
        if ((object)((uintptr_t)_15089 + (uintptr_t)HIGH_BITS) >= 0){
            _15089 = NewDouble((eudouble)_15089);
        }
    }
    else {
        _15089 = NewDouble(DBL_PTR(_15088)->dbl + (eudouble)_d_27322);
    }
    DeRef(_15088);
    _15088 = NOVALUE;
    DeRef(_val_27321);
    if (IS_ATOM_INT(_15089)) {
        _val_27321 = _15089 - 1;
        if ((object)((uintptr_t)_val_27321 +(uintptr_t) HIGH_BITS) >= 0){
            _val_27321 = NewDouble((eudouble)_val_27321);
        }
    }
    else {
        _val_27321 = NewDouble(DBL_PTR(_15089)->dbl - (eudouble)1);
    }
    DeRef(_15089);
    _15089 = NOVALUE;

    /** scanner.e:1109				cnt += 1*/
    _cnt_27326 = _cnt_27326 + 1;

    /** scanner.e:1111		end while*/
    goto L1; // [105] 24
L4: 

    /** scanner.e:1113		if cnt = 0 then*/
    if (_cnt_27326 != 0)
    goto L6; // [110] 124

    /** scanner.e:1114			CompileErr(EXPECTING_ONLY_0_1_OR_SPACE_TO_FOLLOW_THE_B)*/
    RefDS(_22190);
    _50CompileErr(343, _22190, 0);
L6: 

    /** scanner.e:1116		return val*/
    DeRefi(_vchars_27323);
    return _val_27321;
    ;
}


object _62EscapeChar(object _delim_27350)
{
    object _c_27351 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:1124		c = getch()*/
    _0 = _c_27351;
    _c_27351 = _62getch();
    DeRef(_0);

    /** scanner.e:1125		switch c do*/
    if (IS_SEQUENCE(_c_27351) ){
        goto L1; // [10] 135
    }
    if(!IS_ATOM_INT(_c_27351)){
        if( (DBL_PTR(_c_27351)->dbl != (eudouble) ((object) DBL_PTR(_c_27351)->dbl) ) ){
            goto L1; // [10] 135
        }
        _0 = (object) DBL_PTR(_c_27351)->dbl;
    }
    else {
        _0 = _c_27351;
    };
    switch ( _0 ){ 

        /** scanner.e:1126			case 'n' then*/
        case 110:

        /** scanner.e:1127				c = 10 -- Newline*/
        DeRef(_c_27351);
        _c_27351 = 10;
        goto L2; // [24] 147

        /** scanner.e:1129			case 't' then*/
        case 116:

        /** scanner.e:1130				c = 9 -- Tabulator*/
        DeRef(_c_27351);
        _c_27351 = 9;
        goto L2; // [35] 147

        /** scanner.e:1132			case '"', '\\', '\'' then*/
        case 34:
        case 92:
        case 39:

        /** scanner.e:1137			case 'r' then*/
        goto L2; // [47] 147
        case 114:

        /** scanner.e:1138				c = 13 -- Carriage Return*/
        DeRef(_c_27351);
        _c_27351 = 13;
        goto L2; // [56] 147

        /** scanner.e:1140			case '0' then*/
        case 48:

        /** scanner.e:1141				c = 0 -- Null*/
        DeRef(_c_27351);
        _c_27351 = 0;
        goto L2; // [67] 147

        /** scanner.e:1143			case 'e', 'E' then*/
        case 101:
        case 69:

        /** scanner.e:1144				c = 27 -- escape char.*/
        DeRef(_c_27351);
        _c_27351 = 27;
        goto L2; // [80] 147

        /** scanner.e:1146			case 'x' then*/
        case 120:

        /** scanner.e:1148				c = GetHexChar(2, 340)*/
        _0 = _c_27351;
        _c_27351 = _62GetHexChar(2, 340);
        DeRef(_0);
        goto L2; // [93] 147

        /** scanner.e:1150			case 'u' then*/
        case 117:

        /** scanner.e:1152				c = GetHexChar(4, 341)*/
        _0 = _c_27351;
        _c_27351 = _62GetHexChar(4, 341);
        DeRef(_0);
        goto L2; // [106] 147

        /** scanner.e:1154			case 'U' then*/
        case 85:

        /** scanner.e:1156				c = GetHexChar(8, 342)*/
        _0 = _c_27351;
        _c_27351 = _62GetHexChar(8, 342);
        DeRef(_0);
        goto L2; // [119] 147

        /** scanner.e:1158			case 'b' then*/
        case 98:

        /** scanner.e:1160				c = GetBinaryChar(delim)*/
        _0 = _c_27351;
        _c_27351 = _62GetBinaryChar(_delim_27350);
        DeRef(_0);
        goto L2; // [131] 147

        /** scanner.e:1162			case else*/
        default:
L1: 

        /** scanner.e:1163				CompileErr(UNKNOWN_ESCAPE_CHARACTER)*/
        RefDS(_22190);
        _50CompileErr(155, _22190, 0);
    ;}L2: 

    /** scanner.e:1166		return c*/
    return _c_27351;
    ;
}


object _62my_sscanf(object _yytext_27374)
{
    object _e_sign_27375 = NOVALUE;
    object _ndigits_27376 = NOVALUE;
    object _e_mag_27377 = NOVALUE;
    object _mantissa_27378 = NOVALUE;
    object _c_27379 = NOVALUE;
    object _i_27380 = NOVALUE;
    object _dec_27381 = NOVALUE;
    object _frac_27414 = NOVALUE;
    object _15134 = NOVALUE;
    object _15129 = NOVALUE;
    object _15128 = NOVALUE;
    object _15126 = NOVALUE;
    object _15125 = NOVALUE;
    object _15124 = NOVALUE;
    object _15116 = NOVALUE;
    object _15115 = NOVALUE;
    object _15112 = NOVALUE;
    object _15111 = NOVALUE;
    object _15110 = NOVALUE;
    object _15105 = NOVALUE;
    object _15104 = NOVALUE;
    object _15102 = NOVALUE;
    object _15100 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:1179		if length(yytext) < 2 then*/
    if (IS_SEQUENCE(_yytext_27374)){
            _15100 = SEQ_PTR(_yytext_27374)->length;
    }
    else {
        _15100 = 1;
    }
    if (_15100 >= 2)
    goto L1; // [8] 22

    /** scanner.e:1180			CompileErr(NUMBER_NOT_FORMED_CORRECTLY)*/
    RefDS(_22190);
    _50CompileErr(121, _22190, 0);
L1: 

    /** scanner.e:1184		if find( 'e', yytext ) or find( 'E', yytext ) then*/
    _15102 = find_from(101, _yytext_27374, 1);
    if (_15102 != 0) {
        goto L2; // [29] 43
    }
    _15104 = find_from(69, _yytext_27374, 1);
    if (_15104 == 0)
    {
        _15104 = NOVALUE;
        goto L3; // [39] 59
    }
    else{
        _15104 = NOVALUE;
    }
L2: 

    /** scanner.e:1185			ifdef BITS32 then*/

    /** scanner.e:1186				return scientific_to_atom( yytext, DOUBLE )*/
    RefDS(_yytext_27374);
    _15105 = _28scientific_to_atom(_yytext_27374, 2);
    DeRefDS(_yytext_27374);
    DeRef(_mantissa_27378);
    DeRef(_dec_27381);
    return _15105;
L3: 

    /** scanner.e:1193		mantissa = 0.0*/
    RefDS(_15107);
    DeRef(_mantissa_27378);
    _mantissa_27378 = _15107;

    /** scanner.e:1194		ndigits = 0*/
    _ndigits_27376 = 0;

    /** scanner.e:1198		yytext &= 0 -- end marker*/
    Append(&_yytext_27374, _yytext_27374, 0);

    /** scanner.e:1199		c = yytext[1]*/
    _2 = (object)SEQ_PTR(_yytext_27374);
    _c_27379 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_c_27379))
    _c_27379 = (object)DBL_PTR(_c_27379)->dbl;

    /** scanner.e:1200		i = 2*/
    _i_27380 = 2;

    /** scanner.e:1201		while c >= '0' and c <= '9' do*/
L4: 
    _15110 = (_c_27379 >= 48);
    if (_15110 == 0) {
        goto L5; // [95] 144
    }
    _15112 = (_c_27379 <= 57);
    if (_15112 == 0)
    {
        DeRef(_15112);
        _15112 = NOVALUE;
        goto L5; // [104] 144
    }
    else{
        DeRef(_15112);
        _15112 = NOVALUE;
    }

    /** scanner.e:1202			ndigits += 1*/
    _ndigits_27376 = _ndigits_27376 + 1;

    /** scanner.e:1203			mantissa = mantissa * 10.0 + (c - '0')*/
    if (IS_ATOM_INT(_mantissa_27378)) {
        _15115 = NewDouble((eudouble)_mantissa_27378 * DBL_PTR(_15114)->dbl);
    }
    else {
        _15115 = NewDouble(DBL_PTR(_mantissa_27378)->dbl * DBL_PTR(_15114)->dbl);
    }
    _15116 = _c_27379 - 48;
    if ((object)((uintptr_t)_15116 +(uintptr_t) HIGH_BITS) >= 0){
        _15116 = NewDouble((eudouble)_15116);
    }
    DeRef(_mantissa_27378);
    if (IS_ATOM_INT(_15116)) {
        _mantissa_27378 = NewDouble(DBL_PTR(_15115)->dbl + (eudouble)_15116);
    }
    else
    _mantissa_27378 = NewDouble(DBL_PTR(_15115)->dbl + DBL_PTR(_15116)->dbl);
    DeRefDS(_15115);
    _15115 = NOVALUE;
    DeRef(_15116);
    _15116 = NOVALUE;

    /** scanner.e:1204			c = yytext[i]*/
    _2 = (object)SEQ_PTR(_yytext_27374);
    _c_27379 = (object)*(((s1_ptr)_2)->base + _i_27380);
    if (!IS_ATOM_INT(_c_27379))
    _c_27379 = (object)DBL_PTR(_c_27379)->dbl;

    /** scanner.e:1205			i += 1*/
    _i_27380 = _i_27380 + 1;

    /** scanner.e:1206		end while*/
    goto L4; // [141] 91
L5: 

    /** scanner.e:1208		if c = '.' then*/
    if (_c_27379 != 46)
    goto L6; // [146] 247

    /** scanner.e:1210			c = yytext[i]*/
    _2 = (object)SEQ_PTR(_yytext_27374);
    _c_27379 = (object)*(((s1_ptr)_2)->base + _i_27380);
    if (!IS_ATOM_INT(_c_27379))
    _c_27379 = (object)DBL_PTR(_c_27379)->dbl;

    /** scanner.e:1211			i += 1*/
    _i_27380 = _i_27380 + 1;

    /** scanner.e:1212			dec = 1.0*/
    RefDS(_15123);
    DeRef(_dec_27381);
    _dec_27381 = _15123;

    /** scanner.e:1213			atom frac = 0*/
    DeRef(_frac_27414);
    _frac_27414 = 0;

    /** scanner.e:1214			while c >= '0' and c <= '9' do*/
L7: 
    _15124 = (_c_27379 >= 48);
    if (_15124 == 0) {
        goto L8; // [181] 236
    }
    _15126 = (_c_27379 <= 57);
    if (_15126 == 0)
    {
        DeRef(_15126);
        _15126 = NOVALUE;
        goto L8; // [190] 236
    }
    else{
        DeRef(_15126);
        _15126 = NOVALUE;
    }

    /** scanner.e:1215				ndigits += 1*/
    _ndigits_27376 = _ndigits_27376 + 1;

    /** scanner.e:1216				frac = frac * 10 + (c - '0')*/
    if (IS_ATOM_INT(_frac_27414)) {
        if (_frac_27414 == (short)_frac_27414){
            _15128 = _frac_27414 * 10;
        }
        else{
            _15128 = NewDouble(_frac_27414 * (eudouble)10);
        }
    }
    else {
        _15128 = NewDouble(DBL_PTR(_frac_27414)->dbl * (eudouble)10);
    }
    _15129 = _c_27379 - 48;
    if ((object)((uintptr_t)_15129 +(uintptr_t) HIGH_BITS) >= 0){
        _15129 = NewDouble((eudouble)_15129);
    }
    DeRef(_frac_27414);
    if (IS_ATOM_INT(_15128) && IS_ATOM_INT(_15129)) {
        _frac_27414 = _15128 + _15129;
        if ((object)((uintptr_t)_frac_27414 + (uintptr_t)HIGH_BITS) >= 0){
            _frac_27414 = NewDouble((eudouble)_frac_27414);
        }
    }
    else {
        if (IS_ATOM_INT(_15128)) {
            _frac_27414 = NewDouble((eudouble)_15128 + DBL_PTR(_15129)->dbl);
        }
        else {
            if (IS_ATOM_INT(_15129)) {
                _frac_27414 = NewDouble(DBL_PTR(_15128)->dbl + (eudouble)_15129);
            }
            else
            _frac_27414 = NewDouble(DBL_PTR(_15128)->dbl + DBL_PTR(_15129)->dbl);
        }
    }
    DeRef(_15128);
    _15128 = NOVALUE;
    DeRef(_15129);
    _15129 = NOVALUE;

    /** scanner.e:1217				dec *= 10.0*/
    _0 = _dec_27381;
    if (IS_ATOM_INT(_dec_27381)) {
        _dec_27381 = NewDouble((eudouble)_dec_27381 * DBL_PTR(_15114)->dbl);
    }
    else {
        _dec_27381 = NewDouble(DBL_PTR(_dec_27381)->dbl * DBL_PTR(_15114)->dbl);
    }
    DeRef(_0);

    /** scanner.e:1218				c = yytext[i]*/
    _2 = (object)SEQ_PTR(_yytext_27374);
    _c_27379 = (object)*(((s1_ptr)_2)->base + _i_27380);
    if (!IS_ATOM_INT(_c_27379))
    _c_27379 = (object)DBL_PTR(_c_27379)->dbl;

    /** scanner.e:1219				i += 1*/
    _i_27380 = _i_27380 + 1;

    /** scanner.e:1220			end while*/
    goto L7; // [233] 177
L8: 

    /** scanner.e:1221			mantissa += frac / dec*/
    if (IS_ATOM_INT(_frac_27414) && IS_ATOM_INT(_dec_27381)) {
        _15134 = (_frac_27414 % _dec_27381) ? NewDouble((eudouble)_frac_27414 / _dec_27381) : (_frac_27414 / _dec_27381);
    }
    else {
        if (IS_ATOM_INT(_frac_27414)) {
            _15134 = NewDouble((eudouble)_frac_27414 / DBL_PTR(_dec_27381)->dbl);
        }
        else {
            if (IS_ATOM_INT(_dec_27381)) {
                _15134 = NewDouble(DBL_PTR(_frac_27414)->dbl / (eudouble)_dec_27381);
            }
            else
            _15134 = NewDouble(DBL_PTR(_frac_27414)->dbl / DBL_PTR(_dec_27381)->dbl);
        }
    }
    _0 = _mantissa_27378;
    if (IS_ATOM_INT(_mantissa_27378) && IS_ATOM_INT(_15134)) {
        _mantissa_27378 = _mantissa_27378 + _15134;
        if ((object)((uintptr_t)_mantissa_27378 + (uintptr_t)HIGH_BITS) >= 0){
            _mantissa_27378 = NewDouble((eudouble)_mantissa_27378);
        }
    }
    else {
        if (IS_ATOM_INT(_mantissa_27378)) {
            _mantissa_27378 = NewDouble((eudouble)_mantissa_27378 + DBL_PTR(_15134)->dbl);
        }
        else {
            if (IS_ATOM_INT(_15134)) {
                _mantissa_27378 = NewDouble(DBL_PTR(_mantissa_27378)->dbl + (eudouble)_15134);
            }
            else
            _mantissa_27378 = NewDouble(DBL_PTR(_mantissa_27378)->dbl + DBL_PTR(_15134)->dbl);
        }
    }
    DeRef(_0);
    DeRef(_15134);
    _15134 = NOVALUE;
L6: 
    DeRef(_frac_27414);
    _frac_27414 = NOVALUE;

    /** scanner.e:1224		if ndigits = 0 then*/
    if (_ndigits_27376 != 0)
    goto L9; // [251] 265

    /** scanner.e:1225			CompileErr(NUMBER_NOT_FORMED_CORRECTLY)  -- no digits*/
    RefDS(_22190);
    _50CompileErr(121, _22190, 0);
L9: 

    /** scanner.e:1271		return mantissa*/
    DeRefDS(_yytext_27374);
    DeRef(_dec_27381);
    DeRef(_15110);
    _15110 = NOVALUE;
    DeRef(_15105);
    _15105 = NOVALUE;
    DeRef(_15124);
    _15124 = NOVALUE;
    return _mantissa_27378;
    ;
}


void _62maybe_namespace()
{
    object _0, _1, _2;
    

    /** scanner.e:1276		might_be_namespace = 1*/
    _62might_be_namespace_27432 = 1;

    /** scanner.e:1277	end procedure*/
    return;
    ;
}


object _62ExtendedString(object _ech_27442)
{
    object _ch_27443 = NOVALUE;
    object _fch_27444 = NOVALUE;
    object _cline_27445 = NOVALUE;
    object _string_text_27446 = NOVALUE;
    object _trimming_27447 = NOVALUE;
    object _15187 = NOVALUE;
    object _15186 = NOVALUE;
    object _15184 = NOVALUE;
    object _15183 = NOVALUE;
    object _15182 = NOVALUE;
    object _15181 = NOVALUE;
    object _15180 = NOVALUE;
    object _15179 = NOVALUE;
    object _15178 = NOVALUE;
    object _15177 = NOVALUE;
    object _15175 = NOVALUE;
    object _15174 = NOVALUE;
    object _15173 = NOVALUE;
    object _15172 = NOVALUE;
    object _15171 = NOVALUE;
    object _15170 = NOVALUE;
    object _15167 = NOVALUE;
    object _15166 = NOVALUE;
    object _15165 = NOVALUE;
    object _15163 = NOVALUE;
    object _15162 = NOVALUE;
    object _15161 = NOVALUE;
    object _15160 = NOVALUE;
    object _15157 = NOVALUE;
    object _15142 = NOVALUE;
    object _15140 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:1290		cline = line_number*/
    _cline_27445 = _36line_number_21768;

    /** scanner.e:1291		string_text = ""*/
    RefDS(_5);
    DeRefi(_string_text_27446);
    _string_text_27446 = _5;

    /** scanner.e:1292		trimming = 0*/
    _trimming_27447 = 0;

    /** scanner.e:1293		ch = getch()*/
    _ch_27443 = _62getch();
    if (!IS_ATOM_INT(_ch_27443)) {
        _1 = (object)(DBL_PTR(_ch_27443)->dbl);
        DeRefDS(_ch_27443);
        _ch_27443 = _1;
    }

    /** scanner.e:1294		if bp > length(ThisLine) then*/
    if (IS_SEQUENCE(_50ThisLine_49594)){
            _15140 = SEQ_PTR(_50ThisLine_49594)->length;
    }
    else {
        _15140 = 1;
    }
    if (_50bp_49598 <= _15140)
    goto L1; // [40] 101

    /** scanner.e:1296			read_line()*/
    _62read_line();

    /** scanner.e:1297			while ThisLine[bp] = '_' do*/
L2: 
    _2 = (object)SEQ_PTR(_50ThisLine_49594);
    _15142 = (object)*(((s1_ptr)_2)->base + _50bp_49598);
    if (binary_op_a(NOTEQ, _15142, 95)){
        _15142 = NOVALUE;
        goto L3; // [61] 86
    }
    _15142 = NOVALUE;

    /** scanner.e:1298				trimming += 1*/
    _trimming_27447 = _trimming_27447 + 1;

    /** scanner.e:1299				bp += 1*/
    _50bp_49598 = _50bp_49598 + 1;

    /** scanner.e:1300			end while*/
    goto L2; // [83] 53
L3: 

    /** scanner.e:1301			if trimming > 0 then*/
    if (_trimming_27447 <= 0)
    goto L4; // [88] 100

    /** scanner.e:1302				ch = getch()*/
    _ch_27443 = _62getch();
    if (!IS_ATOM_INT(_ch_27443)) {
        _1 = (object)(DBL_PTR(_ch_27443)->dbl);
        DeRefDS(_ch_27443);
        _ch_27443 = _1;
    }
L4: 
L1: 

    /** scanner.e:1306		while 1 do*/
L5: 

    /** scanner.e:1307			if ch = END_OF_FILE_CHAR then*/
    if (_ch_27443 != 26)
    goto L6; // [110] 124

    /** scanner.e:1308				CompileErr(RAW_STRING_LITERAL_FROM_LINE_1_NOT_TERMINATED, cline)*/
    _50CompileErr(129, _cline_27445, 0);
L6: 

    /** scanner.e:1311			if ch = ech then*/
    if (_ch_27443 != _ech_27442)
    goto L7; // [126] 182

    /** scanner.e:1312				if ech != '"' then*/
    if (_ech_27442 == 34)
    goto L8; // [132] 141

    /** scanner.e:1313					exit*/
    goto L9; // [138] 312
L8: 

    /** scanner.e:1315				fch = getch()*/
    _fch_27444 = _62getch();
    if (!IS_ATOM_INT(_fch_27444)) {
        _1 = (object)(DBL_PTR(_fch_27444)->dbl);
        DeRefDS(_fch_27444);
        _fch_27444 = _1;
    }

    /** scanner.e:1316				if fch = '"' then*/
    if (_fch_27444 != 34)
    goto LA; // [150] 177

    /** scanner.e:1317					fch = getch()*/
    _fch_27444 = _62getch();
    if (!IS_ATOM_INT(_fch_27444)) {
        _1 = (object)(DBL_PTR(_fch_27444)->dbl);
        DeRefDS(_fch_27444);
        _fch_27444 = _1;
    }

    /** scanner.e:1318					if fch = '"' then*/
    if (_fch_27444 != 34)
    goto LB; // [163] 172

    /** scanner.e:1319						exit*/
    goto L9; // [169] 312
LB: 

    /** scanner.e:1321					ungetch()*/
    _62ungetch();
LA: 

    /** scanner.e:1323				ungetch()*/
    _62ungetch();
L7: 

    /** scanner.e:1326			if ch != '\r' then*/
    if (_ch_27443 == 13)
    goto LC; // [184] 195

    /** scanner.e:1329				string_text &= ch*/
    Append(&_string_text_27446, _string_text_27446, _ch_27443);
LC: 

    /** scanner.e:1332			if bp > length(ThisLine) then*/
    if (IS_SEQUENCE(_50ThisLine_49594)){
            _15157 = SEQ_PTR(_50ThisLine_49594)->length;
    }
    else {
        _15157 = 1;
    }
    if (_50bp_49598 <= _15157)
    goto LD; // [204] 300

    /** scanner.e:1333				read_line() -- sets bp to 1, btw.*/
    _62read_line();

    /** scanner.e:1334				if trimming > 0 then*/
    if (_trimming_27447 <= 0)
    goto LE; // [214] 299

    /** scanner.e:1335					while bp <= trimming and bp <= length(ThisLine) do*/
LF: 
    _15160 = (_50bp_49598 <= _trimming_27447);
    if (_15160 == 0) {
        goto L10; // [229] 298
    }
    if (IS_SEQUENCE(_50ThisLine_49594)){
            _15162 = SEQ_PTR(_50ThisLine_49594)->length;
    }
    else {
        _15162 = 1;
    }
    _15163 = (_50bp_49598 <= _15162);
    _15162 = NOVALUE;
    if (_15163 == 0)
    {
        DeRef(_15163);
        _15163 = NOVALUE;
        goto L10; // [245] 298
    }
    else{
        DeRef(_15163);
        _15163 = NOVALUE;
    }

    /** scanner.e:1336						ch = ThisLine[bp]*/
    _2 = (object)SEQ_PTR(_50ThisLine_49594);
    _ch_27443 = (object)*(((s1_ptr)_2)->base + _50bp_49598);
    if (!IS_ATOM_INT(_ch_27443)){
        _ch_27443 = (object)DBL_PTR(_ch_27443)->dbl;
    }

    /** scanner.e:1337						if ch != ' ' and ch != '\t' then*/
    _15165 = (_ch_27443 != 32);
    if (_15165 == 0) {
        goto L11; // [266] 283
    }
    _15167 = (_ch_27443 != 9);
    if (_15167 == 0)
    {
        DeRef(_15167);
        _15167 = NOVALUE;
        goto L11; // [275] 283
    }
    else{
        DeRef(_15167);
        _15167 = NOVALUE;
    }

    /** scanner.e:1338							exit*/
    goto L10; // [280] 298
L11: 

    /** scanner.e:1340						bp += 1*/
    _50bp_49598 = _50bp_49598 + 1;

    /** scanner.e:1341					end while*/
    goto LF; // [295] 223
L10: 
LE: 
LD: 

    /** scanner.e:1344			ch = getch()*/
    _ch_27443 = _62getch();
    if (!IS_ATOM_INT(_ch_27443)) {
        _1 = (object)(DBL_PTR(_ch_27443)->dbl);
        DeRefDS(_ch_27443);
        _ch_27443 = _1;
    }

    /** scanner.e:1345		end while*/
    goto L5; // [309] 106
L9: 

    /** scanner.e:1346		if length(string_text) > 0 and string_text[1] = '\n' then*/
    if (IS_SEQUENCE(_string_text_27446)){
            _15170 = SEQ_PTR(_string_text_27446)->length;
    }
    else {
        _15170 = 1;
    }
    _15171 = (_15170 > 0);
    _15170 = NOVALUE;
    if (_15171 == 0) {
        goto L12; // [321] 391
    }
    _2 = (object)SEQ_PTR(_string_text_27446);
    _15173 = (object)*(((s1_ptr)_2)->base + 1);
    _15174 = (_15173 == 10);
    _15173 = NOVALUE;
    if (_15174 == 0)
    {
        DeRef(_15174);
        _15174 = NOVALUE;
        goto L12; // [334] 391
    }
    else{
        DeRef(_15174);
        _15174 = NOVALUE;
    }

    /** scanner.e:1347			string_text = string_text[2 .. $]*/
    if (IS_SEQUENCE(_string_text_27446)){
            _15175 = SEQ_PTR(_string_text_27446)->length;
    }
    else {
        _15175 = 1;
    }
    rhs_slice_target = (object_ptr)&_string_text_27446;
    RHS_Slice(_string_text_27446, 2, _15175);

    /** scanner.e:1348			if length(string_text) > 0 and string_text[$] = '\n' then*/
    if (IS_SEQUENCE(_string_text_27446)){
            _15177 = SEQ_PTR(_string_text_27446)->length;
    }
    else {
        _15177 = 1;
    }
    _15178 = (_15177 > 0);
    _15177 = NOVALUE;
    if (_15178 == 0) {
        goto L13; // [356] 390
    }
    if (IS_SEQUENCE(_string_text_27446)){
            _15180 = SEQ_PTR(_string_text_27446)->length;
    }
    else {
        _15180 = 1;
    }
    _2 = (object)SEQ_PTR(_string_text_27446);
    _15181 = (object)*(((s1_ptr)_2)->base + _15180);
    _15182 = (_15181 == 10);
    _15181 = NOVALUE;
    if (_15182 == 0)
    {
        DeRef(_15182);
        _15182 = NOVALUE;
        goto L13; // [372] 390
    }
    else{
        DeRef(_15182);
        _15182 = NOVALUE;
    }

    /** scanner.e:1349				string_text = string_text[1 .. $-1]*/
    if (IS_SEQUENCE(_string_text_27446)){
            _15183 = SEQ_PTR(_string_text_27446)->length;
    }
    else {
        _15183 = 1;
    }
    _15184 = _15183 - 1;
    _15183 = NOVALUE;
    rhs_slice_target = (object_ptr)&_string_text_27446;
    RHS_Slice(_string_text_27446, 1, _15184);
L13: 
L12: 

    /** scanner.e:1352		return {STRING, NewStringSym(string_text)}*/
    RefDS(_string_text_27446);
    _15186 = _54NewStringSym(_string_text_27446);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 503;
    ((intptr_t *)_2)[2] = _15186;
    _15187 = MAKE_SEQ(_1);
    _15186 = NOVALUE;
    DeRefDSi(_string_text_27446);
    DeRef(_15178);
    _15178 = NOVALUE;
    DeRef(_15171);
    _15171 = NOVALUE;
    DeRef(_15165);
    _15165 = NOVALUE;
    DeRef(_15160);
    _15160 = NOVALUE;
    DeRef(_15184);
    _15184 = NOVALUE;
    return _15187;
    ;
}


object _62GetHexString(object _maxnibbles_27534)
{
    object _ch_27535 = NOVALUE;
    object _digit_27536 = NOVALUE;
    object _val_27537 = NOVALUE;
    object _cline_27538 = NOVALUE;
    object _nibble_27539 = NOVALUE;
    object _string_text_27540 = NOVALUE;
    object _15201 = NOVALUE;
    object _15200 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:1363		cline = line_number*/
    _cline_27538 = _36line_number_21768;

    /** scanner.e:1364		string_text = ""*/
    RefDS(_5);
    DeRef(_string_text_27540);
    _string_text_27540 = _5;

    /** scanner.e:1365		nibble = 1*/
    _nibble_27539 = 1;

    /** scanner.e:1366		val = -1*/
    DeRef(_val_27537);
    _val_27537 = -1;

    /** scanner.e:1367		ch = getch()*/
    _ch_27535 = _62getch();
    if (!IS_ATOM_INT(_ch_27535)) {
        _1 = (object)(DBL_PTR(_ch_27535)->dbl);
        DeRefDS(_ch_27535);
        _ch_27535 = _1;
    }

    /** scanner.e:1368		while 1 do*/
L1: 

    /** scanner.e:1369			if ch = END_OF_FILE_CHAR then*/
    if (_ch_27535 != 26)
    goto L2; // [45] 59

    /** scanner.e:1370				CompileErr(RAW_STRING_LITERAL_FROM_LINE_1_NOT_TERMINATED, cline)*/
    _50CompileErr(129, _cline_27538, 0);
L2: 

    /** scanner.e:1373			if ch = '"' then*/
    if (_ch_27535 != 34)
    goto L3; // [61] 70

    /** scanner.e:1374				exit*/
    goto L4; // [67] 228
L3: 

    /** scanner.e:1377			digit = find(ch, "0123456789ABCDEFabcdef_ \t\n\r")*/
    _digit_27536 = find_from(_ch_27535, _15191, 1);

    /** scanner.e:1378			if digit = 0 then*/
    if (_digit_27536 != 0)
    goto L5; // [79] 93

    /** scanner.e:1379				CompileErr(INVALID_CHARACTER_IN_HEX_STRING)*/
    RefDS(_22190);
    _50CompileErr(329, _22190, 0);
L5: 

    /** scanner.e:1381			if digit <= 23 then*/
    if (_digit_27536 > 23)
    goto L6; // [95] 181

    /** scanner.e:1382				if digit != 23 then*/
    if (_digit_27536 == 23)
    goto L7; // [101] 216

    /** scanner.e:1383					if digit > 16 then*/
    if (_digit_27536 <= 16)
    goto L8; // [107] 118

    /** scanner.e:1384						digit -= 6*/
    _digit_27536 = _digit_27536 - 6;
L8: 

    /** scanner.e:1386					if nibble = 1 then*/
    if (_nibble_27539 != 1)
    goto L9; // [120] 133

    /** scanner.e:1387						val = digit - 1*/
    DeRef(_val_27537);
    _val_27537 = _digit_27536 - 1;
    if ((object)((uintptr_t)_val_27537 +(uintptr_t) HIGH_BITS) >= 0){
        _val_27537 = NewDouble((eudouble)_val_27537);
    }
    goto LA; // [130] 171
L9: 

    /** scanner.e:1389						val = val * 16 + digit - 1*/
    if (IS_ATOM_INT(_val_27537)) {
        if (_val_27537 == (short)_val_27537){
            _15200 = _val_27537 * 16;
        }
        else{
            _15200 = NewDouble(_val_27537 * (eudouble)16);
        }
    }
    else {
        _15200 = NewDouble(DBL_PTR(_val_27537)->dbl * (eudouble)16);
    }
    if (IS_ATOM_INT(_15200)) {
        _15201 = _15200 + _digit_27536;
        if ((object)((uintptr_t)_15201 + (uintptr_t)HIGH_BITS) >= 0){
            _15201 = NewDouble((eudouble)_15201);
        }
    }
    else {
        _15201 = NewDouble(DBL_PTR(_15200)->dbl + (eudouble)_digit_27536);
    }
    DeRef(_15200);
    _15200 = NOVALUE;
    DeRef(_val_27537);
    if (IS_ATOM_INT(_15201)) {
        _val_27537 = _15201 - 1;
        if ((object)((uintptr_t)_val_27537 +(uintptr_t) HIGH_BITS) >= 0){
            _val_27537 = NewDouble((eudouble)_val_27537);
        }
    }
    else {
        _val_27537 = NewDouble(DBL_PTR(_15201)->dbl - (eudouble)1);
    }
    DeRef(_15201);
    _15201 = NOVALUE;

    /** scanner.e:1390						if nibble = maxnibbles then*/
    if (_nibble_27539 != _maxnibbles_27534)
    goto LB; // [149] 170

    /** scanner.e:1391							string_text &= val*/
    Ref(_val_27537);
    Append(&_string_text_27540, _string_text_27540, _val_27537);

    /** scanner.e:1392							val = -1*/
    DeRef(_val_27537);
    _val_27537 = -1;

    /** scanner.e:1393							nibble = 0*/
    _nibble_27539 = 0;
LB: 
LA: 

    /** scanner.e:1396					nibble += 1*/
    _nibble_27539 = _nibble_27539 + 1;
    goto L7; // [178] 216
L6: 

    /** scanner.e:1399				if val >= 0 then*/
    if (binary_op_a(LESS, _val_27537, 0)){
        goto LC; // [183] 199
    }

    /** scanner.e:1401					string_text &= val*/
    Ref(_val_27537);
    Append(&_string_text_27540, _string_text_27540, _val_27537);

    /** scanner.e:1402					val = -1*/
    DeRef(_val_27537);
    _val_27537 = -1;
LC: 

    /** scanner.e:1404				nibble = 1*/
    _nibble_27539 = 1;

    /** scanner.e:1405				if ch = '\n' then*/
    if (_ch_27535 != 10)
    goto LD; // [206] 215

    /** scanner.e:1406					read_line()*/
    _62read_line();
LD: 
L7: 

    /** scanner.e:1409			ch = getch()*/
    _ch_27535 = _62getch();
    if (!IS_ATOM_INT(_ch_27535)) {
        _1 = (object)(DBL_PTR(_ch_27535)->dbl);
        DeRefDS(_ch_27535);
        _ch_27535 = _1;
    }

    /** scanner.e:1410		end while*/
    goto L1; // [225] 41
L4: 

    /** scanner.e:1412		if val >= 0 then	*/
    if (binary_op_a(LESS, _val_27537, 0)){
        goto LE; // [230] 241
    }

    /** scanner.e:1414			string_text &= val*/
    Ref(_val_27537);
    Append(&_string_text_27540, _string_text_27540, _val_27537);
LE: 

    /** scanner.e:1417		return string_text*/
    DeRef(_val_27537);
    return _string_text_27540;
    ;
}


object _62GetBitString()
{
    object _ch_27587 = NOVALUE;
    object _digit_27588 = NOVALUE;
    object _val_27589 = NOVALUE;
    object _cline_27590 = NOVALUE;
    object _bitcnt_27591 = NOVALUE;
    object _string_text_27592 = NOVALUE;
    object _15223 = NOVALUE;
    object _15222 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:1428		cline = line_number*/
    _cline_27590 = _36line_number_21768;

    /** scanner.e:1429		string_text = ""*/
    RefDS(_5);
    DeRef(_string_text_27592);
    _string_text_27592 = _5;

    /** scanner.e:1430		bitcnt = 1*/
    _bitcnt_27591 = 1;

    /** scanner.e:1431		val = -1*/
    DeRef(_val_27589);
    _val_27589 = -1;

    /** scanner.e:1432		ch = getch()*/
    _ch_27587 = _62getch();
    if (!IS_ATOM_INT(_ch_27587)) {
        _1 = (object)(DBL_PTR(_ch_27587)->dbl);
        DeRefDS(_ch_27587);
        _ch_27587 = _1;
    }

    /** scanner.e:1433		while 1 do*/
L1: 

    /** scanner.e:1434			if ch = END_OF_FILE_CHAR then*/
    if (_ch_27587 != 26)
    goto L2; // [43] 57

    /** scanner.e:1435				CompileErr(RAW_STRING_LITERAL_FROM_LINE_1_NOT_TERMINATED, cline)*/
    _50CompileErr(129, _cline_27590, 0);
L2: 

    /** scanner.e:1438			if ch = '"' then*/
    if (_ch_27587 != 34)
    goto L3; // [59] 68

    /** scanner.e:1439				exit*/
    goto L4; // [65] 190
L3: 

    /** scanner.e:1442			digit = find(ch, "01_ \t\n\r")*/
    _digit_27588 = find_from(_ch_27587, _15215, 1);

    /** scanner.e:1443			if digit = 0 then*/
    if (_digit_27588 != 0)
    goto L5; // [77] 91

    /** scanner.e:1444				CompileErr(INVALID_CHARACTER_IN_HEX_STRING)*/
    RefDS(_22190);
    _50CompileErr(329, _22190, 0);
L5: 

    /** scanner.e:1446			if digit <= 3 then*/
    if (_digit_27588 > 3)
    goto L6; // [93] 143

    /** scanner.e:1447				if digit != 3 then*/
    if (_digit_27588 == 3)
    goto L7; // [99] 178

    /** scanner.e:1448					if bitcnt = 1 then*/
    if (_bitcnt_27591 != 1)
    goto L8; // [105] 118

    /** scanner.e:1449						val = digit - 1*/
    DeRef(_val_27589);
    _val_27589 = _digit_27588 - 1;
    if ((object)((uintptr_t)_val_27589 +(uintptr_t) HIGH_BITS) >= 0){
        _val_27589 = NewDouble((eudouble)_val_27589);
    }
    goto L9; // [115] 133
L8: 

    /** scanner.e:1451						val = val * 2 + digit - 1*/
    if (IS_ATOM_INT(_val_27589) && IS_ATOM_INT(_val_27589)) {
        _15222 = _val_27589 + _val_27589;
        if ((object)((uintptr_t)_15222 + (uintptr_t)HIGH_BITS) >= 0){
            _15222 = NewDouble((eudouble)_15222);
        }
    }
    else {
        if (IS_ATOM_INT(_val_27589)) {
            _15222 = NewDouble((eudouble)_val_27589 + DBL_PTR(_val_27589)->dbl);
        }
        else {
            if (IS_ATOM_INT(_val_27589)) {
                _15222 = NewDouble(DBL_PTR(_val_27589)->dbl + (eudouble)_val_27589);
            }
            else
            _15222 = NewDouble(DBL_PTR(_val_27589)->dbl + DBL_PTR(_val_27589)->dbl);
        }
    }
    if (IS_ATOM_INT(_15222)) {
        _15223 = _15222 + _digit_27588;
        if ((object)((uintptr_t)_15223 + (uintptr_t)HIGH_BITS) >= 0){
            _15223 = NewDouble((eudouble)_15223);
        }
    }
    else {
        _15223 = NewDouble(DBL_PTR(_15222)->dbl + (eudouble)_digit_27588);
    }
    DeRef(_15222);
    _15222 = NOVALUE;
    DeRef(_val_27589);
    if (IS_ATOM_INT(_15223)) {
        _val_27589 = _15223 - 1;
        if ((object)((uintptr_t)_val_27589 +(uintptr_t) HIGH_BITS) >= 0){
            _val_27589 = NewDouble((eudouble)_val_27589);
        }
    }
    else {
        _val_27589 = NewDouble(DBL_PTR(_15223)->dbl - (eudouble)1);
    }
    DeRef(_15223);
    _15223 = NOVALUE;
L9: 

    /** scanner.e:1453					bitcnt += 1*/
    _bitcnt_27591 = _bitcnt_27591 + 1;
    goto L7; // [140] 178
L6: 

    /** scanner.e:1456				if val >= 0 then*/
    if (binary_op_a(LESS, _val_27589, 0)){
        goto LA; // [145] 161
    }

    /** scanner.e:1458					string_text &= val*/
    Ref(_val_27589);
    Append(&_string_text_27592, _string_text_27592, _val_27589);

    /** scanner.e:1459					val = -1*/
    DeRef(_val_27589);
    _val_27589 = -1;
LA: 

    /** scanner.e:1461				bitcnt = 1*/
    _bitcnt_27591 = 1;

    /** scanner.e:1462				if ch = '\n' then*/
    if (_ch_27587 != 10)
    goto LB; // [168] 177

    /** scanner.e:1463					read_line()*/
    _62read_line();
LB: 
L7: 

    /** scanner.e:1466			ch = getch()*/
    _ch_27587 = _62getch();
    if (!IS_ATOM_INT(_ch_27587)) {
        _1 = (object)(DBL_PTR(_ch_27587)->dbl);
        DeRefDS(_ch_27587);
        _ch_27587 = _1;
    }

    /** scanner.e:1467		end while*/
    goto L1; // [187] 39
L4: 

    /** scanner.e:1469		if val >= 0 then	*/
    if (binary_op_a(LESS, _val_27589, 0)){
        goto LC; // [192] 203
    }

    /** scanner.e:1471			string_text &= val*/
    Ref(_val_27589);
    Append(&_string_text_27592, _string_text_27592, _val_27589);
LC: 

    /** scanner.e:1474		return string_text*/
    DeRef(_val_27589);
    return _string_text_27592;
    ;
}


object _62Scanner()
{
    object _fwd_inlined_set_qualified_fwd_at_441_27732 = NOVALUE;
    object _ch_27633 = NOVALUE;
    object _sp_27634 = NOVALUE;
    object _prev_Nne_27635 = NOVALUE;
    object _i_27636 = NOVALUE;
    object _pch_27637 = NOVALUE;
    object _cline_27638 = NOVALUE;
    object _yytext_27639 = NOVALUE;
    object _namespaces_27640 = NOVALUE;
    object _d_27641 = NOVALUE;
    object _tok_27643 = NOVALUE;
    object _is_int_27644 = NOVALUE;
    object _class_27645 = NOVALUE;
    object _name_27646 = NOVALUE;
    object _is_namespace_27705 = NOVALUE;
    object _basetype_27941 = NOVALUE;
    object _hdigit_27982 = NOVALUE;
    object _fch_28122 = NOVALUE;
    object _cnest_28306 = NOVALUE;
    object _ach_28336 = NOVALUE;
    object _31990 = NOVALUE;
    object _31989 = NOVALUE;
    object _31988 = NOVALUE;
    object _31987 = NOVALUE;
    object _31986 = NOVALUE;
    object _31985 = NOVALUE;
    object _31984 = NOVALUE;
    object _15616 = NOVALUE;
    object _15615 = NOVALUE;
    object _15613 = NOVALUE;
    object _15611 = NOVALUE;
    object _15610 = NOVALUE;
    object _15609 = NOVALUE;
    object _15607 = NOVALUE;
    object _15606 = NOVALUE;
    object _15605 = NOVALUE;
    object _15604 = NOVALUE;
    object _15602 = NOVALUE;
    object _15601 = NOVALUE;
    object _15599 = NOVALUE;
    object _15597 = NOVALUE;
    object _15596 = NOVALUE;
    object _15594 = NOVALUE;
    object _15592 = NOVALUE;
    object _15591 = NOVALUE;
    object _15589 = NOVALUE;
    object _15587 = NOVALUE;
    object _15586 = NOVALUE;
    object _15585 = NOVALUE;
    object _15584 = NOVALUE;
    object _15583 = NOVALUE;
    object _15581 = NOVALUE;
    object _15580 = NOVALUE;
    object _15570 = NOVALUE;
    object _15557 = NOVALUE;
    object _15553 = NOVALUE;
    object _15552 = NOVALUE;
    object _15548 = NOVALUE;
    object _15547 = NOVALUE;
    object _15546 = NOVALUE;
    object _15545 = NOVALUE;
    object _15543 = NOVALUE;
    object _15542 = NOVALUE;
    object _15541 = NOVALUE;
    object _15540 = NOVALUE;
    object _15537 = NOVALUE;
    object _15536 = NOVALUE;
    object _15535 = NOVALUE;
    object _15534 = NOVALUE;
    object _15533 = NOVALUE;
    object _15532 = NOVALUE;
    object _15530 = NOVALUE;
    object _15529 = NOVALUE;
    object _15528 = NOVALUE;
    object _15527 = NOVALUE;
    object _15526 = NOVALUE;
    object _15525 = NOVALUE;
    object _15523 = NOVALUE;
    object _15522 = NOVALUE;
    object _15519 = NOVALUE;
    object _15516 = NOVALUE;
    object _15511 = NOVALUE;
    object _15510 = NOVALUE;
    object _15509 = NOVALUE;
    object _15508 = NOVALUE;
    object _15507 = NOVALUE;
    object _15506 = NOVALUE;
    object _15504 = NOVALUE;
    object _15503 = NOVALUE;
    object _15502 = NOVALUE;
    object _15501 = NOVALUE;
    object _15500 = NOVALUE;
    object _15499 = NOVALUE;
    object _15497 = NOVALUE;
    object _15496 = NOVALUE;
    object _15493 = NOVALUE;
    object _15490 = NOVALUE;
    object _15488 = NOVALUE;
    object _15487 = NOVALUE;
    object _15483 = NOVALUE;
    object _15482 = NOVALUE;
    object _15478 = NOVALUE;
    object _15477 = NOVALUE;
    object _15476 = NOVALUE;
    object _15474 = NOVALUE;
    object _15469 = NOVALUE;
    object _15466 = NOVALUE;
    object _15465 = NOVALUE;
    object _15464 = NOVALUE;
    object _15463 = NOVALUE;
    object _15457 = NOVALUE;
    object _15455 = NOVALUE;
    object _15450 = NOVALUE;
    object _15449 = NOVALUE;
    object _15448 = NOVALUE;
    object _15447 = NOVALUE;
    object _15446 = NOVALUE;
    object _15445 = NOVALUE;
    object _15444 = NOVALUE;
    object _15442 = NOVALUE;
    object _15440 = NOVALUE;
    object _15439 = NOVALUE;
    object _15438 = NOVALUE;
    object _15437 = NOVALUE;
    object _15436 = NOVALUE;
    object _15434 = NOVALUE;
    object _15429 = NOVALUE;
    object _15428 = NOVALUE;
    object _15426 = NOVALUE;
    object _15422 = NOVALUE;
    object _15419 = NOVALUE;
    object _15418 = NOVALUE;
    object _15416 = NOVALUE;
    object _15415 = NOVALUE;
    object _15414 = NOVALUE;
    object _15411 = NOVALUE;
    object _15409 = NOVALUE;
    object _15408 = NOVALUE;
    object _15404 = NOVALUE;
    object _15400 = NOVALUE;
    object _15397 = NOVALUE;
    object _15391 = NOVALUE;
    object _15383 = NOVALUE;
    object _15382 = NOVALUE;
    object _15381 = NOVALUE;
    object _15379 = NOVALUE;
    object _15376 = NOVALUE;
    object _15374 = NOVALUE;
    object _15372 = NOVALUE;
    object _15369 = NOVALUE;
    object _15366 = NOVALUE;
    object _15364 = NOVALUE;
    object _15362 = NOVALUE;
    object _15360 = NOVALUE;
    object _15359 = NOVALUE;
    object _15355 = NOVALUE;
    object _15352 = NOVALUE;
    object _15350 = NOVALUE;
    object _15347 = NOVALUE;
    object _15340 = NOVALUE;
    object _15338 = NOVALUE;
    object _15335 = NOVALUE;
    object _15329 = NOVALUE;
    object _15328 = NOVALUE;
    object _15327 = NOVALUE;
    object _15326 = NOVALUE;
    object _15325 = NOVALUE;
    object _15324 = NOVALUE;
    object _15323 = NOVALUE;
    object _15321 = NOVALUE;
    object _15319 = NOVALUE;
    object _15317 = NOVALUE;
    object _15315 = NOVALUE;
    object _15313 = NOVALUE;
    object _15312 = NOVALUE;
    object _15311 = NOVALUE;
    object _15310 = NOVALUE;
    object _15309 = NOVALUE;
    object _15307 = NOVALUE;
    object _15304 = NOVALUE;
    object _15302 = NOVALUE;
    object _15301 = NOVALUE;
    object _15300 = NOVALUE;
    object _15298 = NOVALUE;
    object _15293 = NOVALUE;
    object _15289 = NOVALUE;
    object _15286 = NOVALUE;
    object _15284 = NOVALUE;
    object _15283 = NOVALUE;
    object _15281 = NOVALUE;
    object _15279 = NOVALUE;
    object _15277 = NOVALUE;
    object _15276 = NOVALUE;
    object _15275 = NOVALUE;
    object _15273 = NOVALUE;
    object _15268 = NOVALUE;
    object _15265 = NOVALUE;
    object _15263 = NOVALUE;
    object _15260 = NOVALUE;
    object _15259 = NOVALUE;
    object _15257 = NOVALUE;
    object _15256 = NOVALUE;
    object _15255 = NOVALUE;
    object _15254 = NOVALUE;
    object _15253 = NOVALUE;
    object _15252 = NOVALUE;
    object _15251 = NOVALUE;
    object _15250 = NOVALUE;
    object _15249 = NOVALUE;
    object _15248 = NOVALUE;
    object _15247 = NOVALUE;
    object _15246 = NOVALUE;
    object _15245 = NOVALUE;
    object _15240 = NOVALUE;
    object _15238 = NOVALUE;
    object _15235 = NOVALUE;
    object _15233 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:1486		integer is_int, class*/

    /** scanner.e:1487		sequence name*/

    /** scanner.e:1489		while TRUE do*/
L1: 
    if (_13TRUE_447 == 0)
    {
        goto L2; // [12] 3821
    }
    else{
    }

    /** scanner.e:1490			ch = getch()*/
    _ch_27633 = _62getch();
    if (!IS_ATOM_INT(_ch_27633)) {
        _1 = (object)(DBL_PTR(_ch_27633)->dbl);
        DeRefDS(_ch_27633);
        _ch_27633 = _1;
    }

    /** scanner.e:1491			while ch = ' ' or ch = '\t' do*/
L3: 
    _15233 = (_ch_27633 == 32);
    if (_15233 != 0) {
        goto L4; // [31] 44
    }
    _15235 = (_ch_27633 == 9);
    if (_15235 == 0)
    {
        DeRef(_15235);
        _15235 = NOVALUE;
        goto L5; // [40] 56
    }
    else{
        DeRef(_15235);
        _15235 = NOVALUE;
    }
L4: 

    /** scanner.e:1492				ch = getch()*/
    _ch_27633 = _62getch();
    if (!IS_ATOM_INT(_ch_27633)) {
        _1 = (object)(DBL_PTR(_ch_27633)->dbl);
        DeRefDS(_ch_27633);
        _ch_27633 = _1;
    }

    /** scanner.e:1493			end while*/
    goto L3; // [53] 27
L5: 

    /** scanner.e:1495			class = char_class[ch]*/
    _2 = (object)SEQ_PTR(_62char_class_25880);
    _class_27645 = (object)*(((s1_ptr)_2)->base + _ch_27633);

    /** scanner.e:1498			if class = LETTER or ch = '_' then*/
    _15238 = (_class_27645 == -2);
    if (_15238 != 0) {
        goto L6; // [72] 85
    }
    _15240 = (_ch_27633 == 95);
    if (_15240 == 0)
    {
        DeRef(_15240);
        _15240 = NOVALUE;
        goto L7; // [81] 1284
    }
    else{
        DeRef(_15240);
        _15240 = NOVALUE;
    }
L6: 

    /** scanner.e:1499				sp = bp*/
    _sp_27634 = _50bp_49598;

    /** scanner.e:1500				pch = ch*/
    _pch_27637 = _ch_27633;

    /** scanner.e:1501				ch = getch()*/
    _ch_27633 = _62getch();
    if (!IS_ATOM_INT(_ch_27633)) {
        _1 = (object)(DBL_PTR(_ch_27633)->dbl);
        DeRefDS(_ch_27633);
        _ch_27633 = _1;
    }

    /** scanner.e:1502				if ch = '"' then*/
    if (_ch_27633 != 34)
    goto L8; // [108] 222

    /** scanner.e:1503					switch pch do*/
    _0 = _pch_27637;
    switch ( _0 ){ 

        /** scanner.e:1504						case 'x' then*/
        case 120:

        /** scanner.e:1505							return {STRING, NewStringSym(GetHexString(2))}*/
        _15245 = _62GetHexString(2);
        _15246 = _54NewStringSym(_15245);
        _15245 = NOVALUE;
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = 503;
        ((intptr_t *)_2)[2] = _15246;
        _15247 = MAKE_SEQ(_1);
        _15246 = NOVALUE;
        DeRef(_i_27636);
        DeRef(_yytext_27639);
        DeRef(_namespaces_27640);
        DeRef(_d_27641);
        DeRef(_tok_27643);
        DeRef(_name_27646);
        DeRef(_15238);
        _15238 = NOVALUE;
        DeRef(_15233);
        _15233 = NOVALUE;
        return _15247;
        goto L9; // [143] 221

        /** scanner.e:1507						case 'u' then*/
        case 117:

        /** scanner.e:1508							return {STRING, NewStringSym(GetHexString(4))}*/
        _15248 = _62GetHexString(4);
        _15249 = _54NewStringSym(_15248);
        _15248 = NOVALUE;
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = 503;
        ((intptr_t *)_2)[2] = _15249;
        _15250 = MAKE_SEQ(_1);
        _15249 = NOVALUE;
        DeRef(_i_27636);
        DeRef(_yytext_27639);
        DeRef(_namespaces_27640);
        DeRef(_d_27641);
        DeRef(_tok_27643);
        DeRef(_name_27646);
        DeRef(_15238);
        _15238 = NOVALUE;
        DeRef(_15247);
        _15247 = NOVALUE;
        DeRef(_15233);
        _15233 = NOVALUE;
        return _15250;
        goto L9; // [169] 221

        /** scanner.e:1510						case 'U' then*/
        case 85:

        /** scanner.e:1511							return {STRING, NewStringSym(GetHexString(8))}*/
        _15251 = _62GetHexString(8);
        _15252 = _54NewStringSym(_15251);
        _15251 = NOVALUE;
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = 503;
        ((intptr_t *)_2)[2] = _15252;
        _15253 = MAKE_SEQ(_1);
        _15252 = NOVALUE;
        DeRef(_i_27636);
        DeRef(_yytext_27639);
        DeRef(_namespaces_27640);
        DeRef(_d_27641);
        DeRef(_tok_27643);
        DeRef(_name_27646);
        DeRef(_15238);
        _15238 = NOVALUE;
        DeRef(_15247);
        _15247 = NOVALUE;
        DeRef(_15250);
        _15250 = NOVALUE;
        DeRef(_15233);
        _15233 = NOVALUE;
        return _15253;
        goto L9; // [195] 221

        /** scanner.e:1513						case 'b' then*/
        case 98:

        /** scanner.e:1514							return {STRING, NewStringSym(GetBitString())}*/
        _15254 = _62GetBitString();
        _15255 = _54NewStringSym(_15254);
        _15254 = NOVALUE;
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = 503;
        ((intptr_t *)_2)[2] = _15255;
        _15256 = MAKE_SEQ(_1);
        _15255 = NOVALUE;
        DeRef(_i_27636);
        DeRef(_yytext_27639);
        DeRef(_namespaces_27640);
        DeRef(_d_27641);
        DeRef(_tok_27643);
        DeRef(_name_27646);
        DeRef(_15253);
        _15253 = NOVALUE;
        DeRef(_15238);
        _15238 = NOVALUE;
        DeRef(_15247);
        _15247 = NOVALUE;
        DeRef(_15250);
        _15250 = NOVALUE;
        DeRef(_15233);
        _15233 = NOVALUE;
        return _15256;
    ;}L9: 
L8: 

    /** scanner.e:1519				while id_char[ch] do*/
LA: 
    _2 = (object)SEQ_PTR(_62id_char_25881);
    _15257 = (object)*(((s1_ptr)_2)->base + _ch_27633);
    if (_15257 == 0)
    {
        _15257 = NOVALUE;
        goto LB; // [233] 248
    }
    else{
        _15257 = NOVALUE;
    }

    /** scanner.e:1520					ch = getch()*/
    _ch_27633 = _62getch();
    if (!IS_ATOM_INT(_ch_27633)) {
        _1 = (object)(DBL_PTR(_ch_27633)->dbl);
        DeRefDS(_ch_27633);
        _ch_27633 = _1;
    }

    /** scanner.e:1521				end while*/
    goto LA; // [245] 227
LB: 

    /** scanner.e:1522				yytext = ThisLine[sp-1..bp-2]*/
    _15259 = _sp_27634 - 1;
    if ((object)((uintptr_t)_15259 +(uintptr_t) HIGH_BITS) >= 0){
        _15259 = NewDouble((eudouble)_15259);
    }
    _15260 = _50bp_49598 - 2;
    rhs_slice_target = (object_ptr)&_yytext_27639;
    RHS_Slice(_50ThisLine_49594, _15259, _15260);

    /** scanner.e:1523				ungetch()*/
    _62ungetch();

    /** scanner.e:1525				ch = getch()*/
    _ch_27633 = _62getch();
    if (!IS_ATOM_INT(_ch_27633)) {
        _1 = (object)(DBL_PTR(_ch_27633)->dbl);
        DeRefDS(_ch_27633);
        _ch_27633 = _1;
    }

    /** scanner.e:1526				while ch = ' ' or ch = '\t' do*/
LC: 
    _15263 = (_ch_27633 == 32);
    if (_15263 != 0) {
        goto LD; // [287] 300
    }
    _15265 = (_ch_27633 == 9);
    if (_15265 == 0)
    {
        DeRef(_15265);
        _15265 = NOVALUE;
        goto LE; // [296] 312
    }
    else{
        DeRef(_15265);
        _15265 = NOVALUE;
    }
LD: 

    /** scanner.e:1527					ch = getch()*/
    _ch_27633 = _62getch();
    if (!IS_ATOM_INT(_ch_27633)) {
        _1 = (object)(DBL_PTR(_ch_27633)->dbl);
        DeRefDS(_ch_27633);
        _ch_27633 = _1;
    }

    /** scanner.e:1528				end while*/
    goto LC; // [309] 283
LE: 

    /** scanner.e:1529				integer is_namespace*/

    /** scanner.e:1531				if might_be_namespace then*/
    if (_62might_be_namespace_27432 == 0)
    {
        goto LF; // [318] 361
    }
    else{
    }

    /** scanner.e:1532					tok = keyfind(yytext, -1, , -1 )*/
    RefDS(_yytext_27639);
    _31990 = _54hashfn(_yytext_27639);
    RefDS(_yytext_27639);
    _0 = _tok_27643;
    _tok_27643 = _54keyfind(_yytext_27639, -1, _36current_file_no_21767, -1, _31990);
    DeRef(_0);
    _31990 = NOVALUE;

    /** scanner.e:1533					is_namespace = tok[T_ID] = NAMESPACE*/
    _2 = (object)SEQ_PTR(_tok_27643);
    _15268 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_15268)) {
        _is_namespace_27705 = (_15268 == 523);
    }
    else {
        _is_namespace_27705 = binary_op(EQUALS, _15268, 523);
    }
    _15268 = NOVALUE;
    if (!IS_ATOM_INT(_is_namespace_27705)) {
        _1 = (object)(DBL_PTR(_is_namespace_27705)->dbl);
        DeRefDS(_is_namespace_27705);
        _is_namespace_27705 = _1;
    }

    /** scanner.e:1534					might_be_namespace = 0*/
    _62might_be_namespace_27432 = 0;
    goto L10; // [358] 384
LF: 

    /** scanner.e:1536					is_namespace = ch = ':'*/
    _is_namespace_27705 = (_ch_27633 == 58);

    /** scanner.e:1537					tok = keyfind(yytext, -1, , is_namespace )*/
    RefDS(_yytext_27639);
    _31989 = _54hashfn(_yytext_27639);
    RefDS(_yytext_27639);
    _0 = _tok_27643;
    _tok_27643 = _54keyfind(_yytext_27639, -1, _36current_file_no_21767, _is_namespace_27705, _31989);
    DeRef(_0);
    _31989 = NOVALUE;
L10: 

    /** scanner.e:1541				if not is_namespace then*/
    if (_is_namespace_27705 != 0)
    goto L11; // [388] 396

    /** scanner.e:1542					ungetch()*/
    _62ungetch();
L11: 

    /** scanner.e:1545				if is_namespace then*/
    if (_is_namespace_27705 == 0)
    {
        goto L12; // [398] 1121
    }
    else{
    }

    /** scanner.e:1547					namespaces = yytext*/
    RefDS(_yytext_27639);
    DeRef(_namespaces_27640);
    _namespaces_27640 = _yytext_27639;

    /** scanner.e:1550					if tok[T_ID] = NAMESPACE then -- known namespace*/
    _2 = (object)SEQ_PTR(_tok_27643);
    _15273 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _15273, 523)){
        _15273 = NOVALUE;
        goto L13; // [420] 976
    }
    _15273 = NOVALUE;

    /** scanner.e:1551						set_qualified_fwd( SymTab[tok[T_SYM]][S_OBJ] )*/
    _2 = (object)SEQ_PTR(_tok_27643);
    _15275 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!IS_ATOM_INT(_15275)){
        _15276 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_15275)->dbl));
    }
    else{
        _15276 = (object)*(((s1_ptr)_2)->base + _15275);
    }
    _2 = (object)SEQ_PTR(_15276);
    _15277 = (object)*(((s1_ptr)_2)->base + 1);
    _15276 = NOVALUE;
    Ref(_15277);
    DeRef(_fwd_inlined_set_qualified_fwd_at_441_27732);
    _fwd_inlined_set_qualified_fwd_at_441_27732 = _15277;
    _15277 = NOVALUE;
    if (!IS_ATOM_INT(_fwd_inlined_set_qualified_fwd_at_441_27732)) {
        _1 = (object)(DBL_PTR(_fwd_inlined_set_qualified_fwd_at_441_27732)->dbl);
        DeRefDS(_fwd_inlined_set_qualified_fwd_at_441_27732);
        _fwd_inlined_set_qualified_fwd_at_441_27732 = _1;
    }

    /** scanner.e:104		qualified_fwd = fwd*/
    _62qualified_fwd_25905 = _fwd_inlined_set_qualified_fwd_at_441_27732;

    /** scanner.e:105	end procedure*/
    goto L14; // [456] 459
L14: 
    DeRef(_fwd_inlined_set_qualified_fwd_at_441_27732);
    _fwd_inlined_set_qualified_fwd_at_441_27732 = NOVALUE;

    /** scanner.e:1554						ch = getch()*/
    _ch_27633 = _62getch();
    if (!IS_ATOM_INT(_ch_27633)) {
        _1 = (object)(DBL_PTR(_ch_27633)->dbl);
        DeRefDS(_ch_27633);
        _ch_27633 = _1;
    }

    /** scanner.e:1555						while ch = ' ' or ch = '\t' do*/
L15: 
    _15279 = (_ch_27633 == 32);
    if (_15279 != 0) {
        goto L16; // [477] 490
    }
    _15281 = (_ch_27633 == 9);
    if (_15281 == 0)
    {
        DeRef(_15281);
        _15281 = NOVALUE;
        goto L17; // [486] 502
    }
    else{
        DeRef(_15281);
        _15281 = NOVALUE;
    }
L16: 

    /** scanner.e:1556							ch = getch()*/
    _ch_27633 = _62getch();
    if (!IS_ATOM_INT(_ch_27633)) {
        _1 = (object)(DBL_PTR(_ch_27633)->dbl);
        DeRefDS(_ch_27633);
        _ch_27633 = _1;
    }

    /** scanner.e:1557						end while*/
    goto L15; // [499] 473
L17: 

    /** scanner.e:1558						yytext = ""*/
    RefDS(_5);
    DeRef(_yytext_27639);
    _yytext_27639 = _5;

    /** scanner.e:1559						if char_class[ch] = LETTER or ch = '_' then*/
    _2 = (object)SEQ_PTR(_62char_class_25880);
    _15283 = (object)*(((s1_ptr)_2)->base + _ch_27633);
    _15284 = (_15283 == -2);
    _15283 = NOVALUE;
    if (_15284 != 0) {
        goto L18; // [523] 536
    }
    _15286 = (_ch_27633 == 95);
    if (_15286 == 0)
    {
        DeRef(_15286);
        _15286 = NOVALUE;
        goto L19; // [532] 589
    }
    else{
        DeRef(_15286);
        _15286 = NOVALUE;
    }
L18: 

    /** scanner.e:1560							yytext &= ch*/
    Append(&_yytext_27639, _yytext_27639, _ch_27633);

    /** scanner.e:1561							ch = getch()*/
    _ch_27633 = _62getch();
    if (!IS_ATOM_INT(_ch_27633)) {
        _1 = (object)(DBL_PTR(_ch_27633)->dbl);
        DeRefDS(_ch_27633);
        _ch_27633 = _1;
    }

    /** scanner.e:1562							while id_char[ch] = TRUE do*/
L1A: 
    _2 = (object)SEQ_PTR(_62id_char_25881);
    _15289 = (object)*(((s1_ptr)_2)->base + _ch_27633);
    if (_15289 != _13TRUE_447)
    goto L1B; // [562] 584

    /** scanner.e:1563								yytext &= ch*/
    Append(&_yytext_27639, _yytext_27639, _ch_27633);

    /** scanner.e:1564								ch = getch()*/
    _ch_27633 = _62getch();
    if (!IS_ATOM_INT(_ch_27633)) {
        _1 = (object)(DBL_PTR(_ch_27633)->dbl);
        DeRefDS(_ch_27633);
        _ch_27633 = _1;
    }

    /** scanner.e:1565							end while*/
    goto L1A; // [581] 554
L1B: 

    /** scanner.e:1566							ungetch()*/
    _62ungetch();
L19: 

    /** scanner.e:1569						if length(yytext) = 0 then*/
    if (IS_SEQUENCE(_yytext_27639)){
            _15293 = SEQ_PTR(_yytext_27639)->length;
    }
    else {
        _15293 = 1;
    }
    if (_15293 != 0)
    goto L1C; // [594] 608

    /** scanner.e:1570							CompileErr(AN_IDENTIFIER_IS_EXPECTED_HERE)*/
    RefDS(_22190);
    _50CompileErr(32, _22190, 0);
L1C: 

    /** scanner.e:1576					    if Parser_mode = PAM_RECORD then*/
    if (_36Parser_mode_21876 != 1)
    goto L1D; // [614] 775

    /** scanner.e:1577			                Recorded = append(Recorded,yytext)*/
    RefDS(_yytext_27639);
    Append(&_36Recorded_21877, _36Recorded_21877, _yytext_27639);

    /** scanner.e:1578			                Ns_recorded = append(Ns_recorded,namespaces)*/
    RefDS(_namespaces_27640);
    Append(&_36Ns_recorded_21878, _36Ns_recorded_21878, _namespaces_27640);

    /** scanner.e:1579			                Ns_recorded_sym &= tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_27643);
    _15298 = (object)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_36Ns_recorded_sym_21880) && IS_ATOM(_15298)) {
        Ref(_15298);
        Append(&_36Ns_recorded_sym_21880, _36Ns_recorded_sym_21880, _15298);
    }
    else if (IS_ATOM(_36Ns_recorded_sym_21880) && IS_SEQUENCE(_15298)) {
    }
    else {
        Concat((object_ptr)&_36Ns_recorded_sym_21880, _36Ns_recorded_sym_21880, _15298);
    }
    _15298 = NOVALUE;

    /** scanner.e:1580			                prev_Nne = No_new_entry*/
    _prev_Nne_27635 = _54No_new_entry_48334;

    /** scanner.e:1581							No_new_entry = 1*/
    _54No_new_entry_48334 = 1;

    /** scanner.e:1582							tok = keyfind(yytext, SymTab[tok[T_SYM]][S_OBJ])*/
    _2 = (object)SEQ_PTR(_tok_27643);
    _15300 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!IS_ATOM_INT(_15300)){
        _15301 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_15300)->dbl));
    }
    else{
        _15301 = (object)*(((s1_ptr)_2)->base + _15300);
    }
    _2 = (object)SEQ_PTR(_15301);
    _15302 = (object)*(((s1_ptr)_2)->base + 1);
    _15301 = NOVALUE;
    RefDS(_yytext_27639);
    _31988 = _54hashfn(_yytext_27639);
    RefDS(_yytext_27639);
    Ref(_15302);
    _0 = _tok_27643;
    _tok_27643 = _54keyfind(_yytext_27639, _15302, _36current_file_no_21767, 0, _31988);
    DeRef(_0);
    _15302 = NOVALUE;
    _31988 = NOVALUE;

    /** scanner.e:1583							if tok[T_ID] = IGNORED then*/
    _2 = (object)SEQ_PTR(_tok_27643);
    _15304 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _15304, 509)){
        _15304 = NOVALUE;
        goto L1E; // [714] 731
    }
    _15304 = NOVALUE;

    /** scanner.e:1584								Recorded_sym &= 0 -- must resolve on call site*/
    Append(&_36Recorded_sym_21879, _36Recorded_sym_21879, 0);
    goto L1F; // [728] 748
L1E: 

    /** scanner.e:1586								Recorded_sym &= tok[T_SYM] -- fallback when symbol is undefined on call site*/
    _2 = (object)SEQ_PTR(_tok_27643);
    _15307 = (object)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_36Recorded_sym_21879) && IS_ATOM(_15307)) {
        Ref(_15307);
        Append(&_36Recorded_sym_21879, _36Recorded_sym_21879, _15307);
    }
    else if (IS_ATOM(_36Recorded_sym_21879) && IS_SEQUENCE(_15307)) {
    }
    else {
        Concat((object_ptr)&_36Recorded_sym_21879, _36Recorded_sym_21879, _15307);
    }
    _15307 = NOVALUE;
L1F: 

    /** scanner.e:1588			                No_new_entry = prev_Nne*/
    _54No_new_entry_48334 = _prev_Nne_27635;

    /** scanner.e:1589			                return {RECORDED,length(Recorded)}*/
    if (IS_SEQUENCE(_36Recorded_21877)){
            _15309 = SEQ_PTR(_36Recorded_21877)->length;
    }
    else {
        _15309 = 1;
    }
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 508;
    ((intptr_t *)_2)[2] = _15309;
    _15310 = MAKE_SEQ(_1);
    _15309 = NOVALUE;
    DeRef(_i_27636);
    DeRef(_yytext_27639);
    DeRef(_namespaces_27640);
    DeRef(_d_27641);
    DeRef(_tok_27643);
    DeRef(_name_27646);
    DeRef(_15284);
    _15284 = NOVALUE;
    DeRef(_15253);
    _15253 = NOVALUE;
    DeRef(_15238);
    _15238 = NOVALUE;
    DeRef(_15260);
    _15260 = NOVALUE;
    _15275 = NOVALUE;
    DeRef(_15256);
    _15256 = NOVALUE;
    DeRef(_15247);
    _15247 = NOVALUE;
    DeRef(_15250);
    _15250 = NOVALUE;
    DeRef(_15279);
    _15279 = NOVALUE;
    DeRef(_15259);
    _15259 = NOVALUE;
    DeRef(_15263);
    _15263 = NOVALUE;
    _15300 = NOVALUE;
    _15289 = NOVALUE;
    DeRef(_15233);
    _15233 = NOVALUE;
    return _15310;
    goto L20; // [772] 917
L1D: 

    /** scanner.e:1591							tok = keyfind(yytext, SymTab[tok[T_SYM]][S_OBJ])*/
    _2 = (object)SEQ_PTR(_tok_27643);
    _15311 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!IS_ATOM_INT(_15311)){
        _15312 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_15311)->dbl));
    }
    else{
        _15312 = (object)*(((s1_ptr)_2)->base + _15311);
    }
    _2 = (object)SEQ_PTR(_15312);
    _15313 = (object)*(((s1_ptr)_2)->base + 1);
    _15312 = NOVALUE;
    RefDS(_yytext_27639);
    _31987 = _54hashfn(_yytext_27639);
    RefDS(_yytext_27639);
    Ref(_15313);
    _0 = _tok_27643;
    _tok_27643 = _54keyfind(_yytext_27639, _15313, _36current_file_no_21767, 0, _31987);
    DeRef(_0);
    _15313 = NOVALUE;
    _31987 = NOVALUE;

    /** scanner.e:1593							if tok[T_ID] = VARIABLE then*/
    _2 = (object)SEQ_PTR(_tok_27643);
    _15315 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _15315, -100)){
        _15315 = NOVALUE;
        goto L21; // [819] 836
    }
    _15315 = NOVALUE;

    /** scanner.e:1594								tok[T_ID] = QUALIFIED_VARIABLE*/
    _2 = (object)SEQ_PTR(_tok_27643);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _tok_27643 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 512;
    DeRef(_1);
    goto L22; // [833] 916
L21: 

    /** scanner.e:1595							elsif tok[T_ID] = FUNC then*/
    _2 = (object)SEQ_PTR(_tok_27643);
    _15317 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _15317, 501)){
        _15317 = NOVALUE;
        goto L23; // [846] 863
    }
    _15317 = NOVALUE;

    /** scanner.e:1596								tok[T_ID] = QUALIFIED_FUNC*/
    _2 = (object)SEQ_PTR(_tok_27643);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _tok_27643 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 520;
    DeRef(_1);
    goto L22; // [860] 916
L23: 

    /** scanner.e:1597							elsif tok[T_ID] = PROC then*/
    _2 = (object)SEQ_PTR(_tok_27643);
    _15319 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _15319, 27)){
        _15319 = NOVALUE;
        goto L24; // [873] 890
    }
    _15319 = NOVALUE;

    /** scanner.e:1598								tok[T_ID] = QUALIFIED_PROC*/
    _2 = (object)SEQ_PTR(_tok_27643);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _tok_27643 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 521;
    DeRef(_1);
    goto L22; // [887] 916
L24: 

    /** scanner.e:1599							elsif tok[T_ID] = TYPE then*/
    _2 = (object)SEQ_PTR(_tok_27643);
    _15321 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _15321, 504)){
        _15321 = NOVALUE;
        goto L25; // [900] 915
    }
    _15321 = NOVALUE;

    /** scanner.e:1600								tok[T_ID] = QUALIFIED_TYPE*/
    _2 = (object)SEQ_PTR(_tok_27643);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _tok_27643 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 522;
    DeRef(_1);
L25: 
L22: 
L20: 

    /** scanner.e:1605						if atom( tok[T_SYM] ) and  SymTab[tok[T_SYM]][S_SCOPE] != SC_UNDEFINED then*/
    _2 = (object)SEQ_PTR(_tok_27643);
    _15323 = (object)*(((s1_ptr)_2)->base + 2);
    _15324 = IS_ATOM(_15323);
    _15323 = NOVALUE;
    if (_15324 == 0) {
        goto L26; // [928] 1271
    }
    _2 = (object)SEQ_PTR(_tok_27643);
    _15326 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!IS_ATOM_INT(_15326)){
        _15327 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_15326)->dbl));
    }
    else{
        _15327 = (object)*(((s1_ptr)_2)->base + _15326);
    }
    _2 = (object)SEQ_PTR(_15327);
    _15328 = (object)*(((s1_ptr)_2)->base + 4);
    _15327 = NOVALUE;
    if (IS_ATOM_INT(_15328)) {
        _15329 = (_15328 != 9);
    }
    else {
        _15329 = binary_op(NOTEQ, _15328, 9);
    }
    _15328 = NOVALUE;
    if (_15329 == 0) {
        DeRef(_15329);
        _15329 = NOVALUE;
        goto L26; // [957] 1271
    }
    else {
        if (!IS_ATOM_INT(_15329) && DBL_PTR(_15329)->dbl == 0.0){
            DeRef(_15329);
            _15329 = NOVALUE;
            goto L26; // [957] 1271
        }
        DeRef(_15329);
        _15329 = NOVALUE;
    }
    DeRef(_15329);
    _15329 = NOVALUE;

    /** scanner.e:1606							set_qualified_fwd( -1 )*/

    /** scanner.e:104		qualified_fwd = fwd*/
    _62qualified_fwd_25905 = -1;

    /** scanner.e:105	end procedure*/
    goto L26; // [969] 1271
    goto L26; // [973] 1271
L13: 

    /** scanner.e:1610						ungetch()*/
    _62ungetch();

    /** scanner.e:1611					    if Parser_mode = PAM_RECORD then*/
    if (_36Parser_mode_21876 != 1)
    goto L26; // [986] 1271

    /** scanner.e:1612			                Ns_recorded &= 0*/
    Append(&_36Ns_recorded_21878, _36Ns_recorded_21878, 0);

    /** scanner.e:1613			                Ns_recorded_sym &= 0*/
    Append(&_36Ns_recorded_sym_21880, _36Ns_recorded_sym_21880, 0);

    /** scanner.e:1614			                Recorded = append(Recorded,yytext)*/
    RefDS(_yytext_27639);
    Append(&_36Recorded_21877, _36Recorded_21877, _yytext_27639);

    /** scanner.e:1615			                prev_Nne = No_new_entry*/
    _prev_Nne_27635 = _54No_new_entry_48334;

    /** scanner.e:1616							No_new_entry = 1*/
    _54No_new_entry_48334 = 1;

    /** scanner.e:1617							tok = keyfind(yytext, -1)*/
    RefDS(_yytext_27639);
    _31986 = _54hashfn(_yytext_27639);
    RefDS(_yytext_27639);
    _0 = _tok_27643;
    _tok_27643 = _54keyfind(_yytext_27639, -1, _36current_file_no_21767, 0, _31986);
    DeRef(_0);
    _31986 = NOVALUE;

    /** scanner.e:1618							if tok[T_ID] = IGNORED then*/
    _2 = (object)SEQ_PTR(_tok_27643);
    _15335 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _15335, 509)){
        _15335 = NOVALUE;
        goto L27; // [1062] 1079
    }
    _15335 = NOVALUE;

    /** scanner.e:1619								Recorded_sym &= 0 -- must resolve on call site*/
    Append(&_36Recorded_sym_21879, _36Recorded_sym_21879, 0);
    goto L28; // [1076] 1096
L27: 

    /** scanner.e:1621								Recorded_sym &= tok[T_SYM] -- fallback when symbol is undefined on call site*/
    _2 = (object)SEQ_PTR(_tok_27643);
    _15338 = (object)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_36Recorded_sym_21879) && IS_ATOM(_15338)) {
        Ref(_15338);
        Append(&_36Recorded_sym_21879, _36Recorded_sym_21879, _15338);
    }
    else if (IS_ATOM(_36Recorded_sym_21879) && IS_SEQUENCE(_15338)) {
    }
    else {
        Concat((object_ptr)&_36Recorded_sym_21879, _36Recorded_sym_21879, _15338);
    }
    _15338 = NOVALUE;
L28: 

    /** scanner.e:1623			                No_new_entry = prev_Nne*/
    _54No_new_entry_48334 = _prev_Nne_27635;

    /** scanner.e:1624			                tok = {RECORDED,length(Recorded)}*/
    if (IS_SEQUENCE(_36Recorded_21877)){
            _15340 = SEQ_PTR(_36Recorded_21877)->length;
    }
    else {
        _15340 = 1;
    }
    DeRef(_tok_27643);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 508;
    ((intptr_t *)_2)[2] = _15340;
    _tok_27643 = MAKE_SEQ(_1);
    _15340 = NOVALUE;
    goto L26; // [1118] 1271
L12: 

    /** scanner.e:1628					set_qualified_fwd( -1 )*/

    /** scanner.e:104		qualified_fwd = fwd*/
    _62qualified_fwd_25905 = -1;

    /** scanner.e:105	end procedure*/
    goto L29; // [1130] 1133
L29: 

    /** scanner.e:1629				    if Parser_mode = PAM_RECORD then*/
    if (_36Parser_mode_21876 != 1)
    goto L2A; // [1139] 1270

    /** scanner.e:1630		                Ns_recorded_sym &= 0*/
    Append(&_36Ns_recorded_sym_21880, _36Ns_recorded_sym_21880, 0);

    /** scanner.e:1631							Recorded = append(Recorded, yytext)*/
    RefDS(_yytext_27639);
    Append(&_36Recorded_21877, _36Recorded_21877, _yytext_27639);

    /** scanner.e:1632			                Ns_recorded &= 0*/
    Append(&_36Ns_recorded_21878, _36Ns_recorded_21878, 0);

    /** scanner.e:1633			                prev_Nne = No_new_entry*/
    _prev_Nne_27635 = _54No_new_entry_48334;

    /** scanner.e:1634							No_new_entry = 1*/
    _54No_new_entry_48334 = 1;

    /** scanner.e:1635							tok = keyfind(yytext, -1)*/
    RefDS(_yytext_27639);
    _31985 = _54hashfn(_yytext_27639);
    RefDS(_yytext_27639);
    _0 = _tok_27643;
    _tok_27643 = _54keyfind(_yytext_27639, -1, _36current_file_no_21767, 0, _31985);
    DeRef(_0);
    _31985 = NOVALUE;

    /** scanner.e:1636							if tok[T_ID] = IGNORED then*/
    _2 = (object)SEQ_PTR(_tok_27643);
    _15347 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _15347, 509)){
        _15347 = NOVALUE;
        goto L2B; // [1215] 1232
    }
    _15347 = NOVALUE;

    /** scanner.e:1637								Recorded_sym &= 0 -- must resolve on call site*/
    Append(&_36Recorded_sym_21879, _36Recorded_sym_21879, 0);
    goto L2C; // [1229] 1249
L2B: 

    /** scanner.e:1639								Recorded_sym &= tok[T_SYM] -- fallback when symbol is undefined on call site*/
    _2 = (object)SEQ_PTR(_tok_27643);
    _15350 = (object)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_36Recorded_sym_21879) && IS_ATOM(_15350)) {
        Ref(_15350);
        Append(&_36Recorded_sym_21879, _36Recorded_sym_21879, _15350);
    }
    else if (IS_ATOM(_36Recorded_sym_21879) && IS_SEQUENCE(_15350)) {
    }
    else {
        Concat((object_ptr)&_36Recorded_sym_21879, _36Recorded_sym_21879, _15350);
    }
    _15350 = NOVALUE;
L2C: 

    /** scanner.e:1641			                No_new_entry = prev_Nne*/
    _54No_new_entry_48334 = _prev_Nne_27635;

    /** scanner.e:1642		                tok = {RECORDED, length(Recorded)}*/
    if (IS_SEQUENCE(_36Recorded_21877)){
            _15352 = SEQ_PTR(_36Recorded_21877)->length;
    }
    else {
        _15352 = 1;
    }
    DeRef(_tok_27643);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 508;
    ((intptr_t *)_2)[2] = _15352;
    _tok_27643 = MAKE_SEQ(_1);
    _15352 = NOVALUE;
L2A: 
L26: 

    /** scanner.e:1646				return tok*/
    DeRef(_i_27636);
    DeRef(_yytext_27639);
    DeRef(_namespaces_27640);
    DeRef(_d_27641);
    DeRef(_name_27646);
    DeRef(_15284);
    _15284 = NOVALUE;
    DeRef(_15310);
    _15310 = NOVALUE;
    DeRef(_15253);
    _15253 = NOVALUE;
    DeRef(_15238);
    _15238 = NOVALUE;
    DeRef(_15260);
    _15260 = NOVALUE;
    _15275 = NOVALUE;
    DeRef(_15256);
    _15256 = NOVALUE;
    DeRef(_15247);
    _15247 = NOVALUE;
    DeRef(_15250);
    _15250 = NOVALUE;
    DeRef(_15279);
    _15279 = NOVALUE;
    DeRef(_15259);
    _15259 = NOVALUE;
    DeRef(_15263);
    _15263 = NOVALUE;
    _15300 = NOVALUE;
    _15326 = NOVALUE;
    _15289 = NOVALUE;
    _15311 = NOVALUE;
    DeRef(_15233);
    _15233 = NOVALUE;
    return _tok_27643;
    goto L1; // [1281] 10
L7: 

    /** scanner.e:1648			elsif class < ILLEGAL_CHAR then*/
    if (_class_27645 >= -20)
    goto L2D; // [1288] 1305

    /** scanner.e:1649				return {class, 0}  -- brackets, punctuation, eof, illegal char etc.*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _class_27645;
    ((intptr_t *)_2)[2] = 0;
    _15355 = MAKE_SEQ(_1);
    DeRef(_i_27636);
    DeRef(_yytext_27639);
    DeRef(_namespaces_27640);
    DeRef(_d_27641);
    DeRef(_tok_27643);
    DeRef(_name_27646);
    DeRef(_15284);
    _15284 = NOVALUE;
    DeRef(_15310);
    _15310 = NOVALUE;
    DeRef(_15253);
    _15253 = NOVALUE;
    DeRef(_15238);
    _15238 = NOVALUE;
    DeRef(_15260);
    _15260 = NOVALUE;
    _15275 = NOVALUE;
    DeRef(_15256);
    _15256 = NOVALUE;
    DeRef(_15247);
    _15247 = NOVALUE;
    DeRef(_15250);
    _15250 = NOVALUE;
    DeRef(_15279);
    _15279 = NOVALUE;
    DeRef(_15259);
    _15259 = NOVALUE;
    DeRef(_15263);
    _15263 = NOVALUE;
    _15300 = NOVALUE;
    _15326 = NOVALUE;
    _15289 = NOVALUE;
    _15311 = NOVALUE;
    DeRef(_15233);
    _15233 = NOVALUE;
    return _15355;
    goto L1; // [1302] 10
L2D: 

    /** scanner.e:1651			elsif class = ILLEGAL_CHAR then*/
    if (_class_27645 != -20)
    goto L2E; // [1309] 1325

    /** scanner.e:1652				CompileErr(ILLEGAL_CHARACTER_IN_SOURCE)*/
    RefDS(_22190);
    _50CompileErr(101, _22190, 0);
    goto L1; // [1322] 10
L2E: 

    /** scanner.e:1654			elsif class = NEWLINE then*/
    if (_class_27645 != -6)
    goto L2F; // [1329] 1355

    /** scanner.e:1655				if start_include then*/
    if (_62start_include_25873 == 0)
    {
        goto L30; // [1337] 1347
    }
    else{
    }

    /** scanner.e:1656					IncludePush()*/
    _62IncludePush();
    goto L1; // [1344] 10
L30: 

    /** scanner.e:1658					read_line()*/
    _62read_line();
    goto L1; // [1352] 10
L2F: 

    /** scanner.e:1662			elsif class = EQUALS then*/
    if (_class_27645 != 3)
    goto L31; // [1359] 1376

    /** scanner.e:1663				return {class, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _class_27645;
    ((intptr_t *)_2)[2] = 0;
    _15359 = MAKE_SEQ(_1);
    DeRef(_i_27636);
    DeRef(_yytext_27639);
    DeRef(_namespaces_27640);
    DeRef(_d_27641);
    DeRef(_tok_27643);
    DeRef(_name_27646);
    DeRef(_15284);
    _15284 = NOVALUE;
    DeRef(_15310);
    _15310 = NOVALUE;
    DeRef(_15253);
    _15253 = NOVALUE;
    DeRef(_15238);
    _15238 = NOVALUE;
    DeRef(_15260);
    _15260 = NOVALUE;
    _15275 = NOVALUE;
    DeRef(_15256);
    _15256 = NOVALUE;
    DeRef(_15247);
    _15247 = NOVALUE;
    DeRef(_15250);
    _15250 = NOVALUE;
    DeRef(_15279);
    _15279 = NOVALUE;
    DeRef(_15259);
    _15259 = NOVALUE;
    DeRef(_15263);
    _15263 = NOVALUE;
    _15300 = NOVALUE;
    _15326 = NOVALUE;
    DeRef(_15355);
    _15355 = NOVALUE;
    _15289 = NOVALUE;
    _15311 = NOVALUE;
    DeRef(_15233);
    _15233 = NOVALUE;
    return _15359;
    goto L1; // [1373] 10
L31: 

    /** scanner.e:1665			elsif class = DOT or class = DIGIT then*/
    _15360 = (_class_27645 == -3);
    if (_15360 != 0) {
        goto L32; // [1384] 1399
    }
    _15362 = (_class_27645 == -7);
    if (_15362 == 0)
    {
        DeRef(_15362);
        _15362 = NOVALUE;
        goto L33; // [1395] 2195
    }
    else{
        DeRef(_15362);
        _15362 = NOVALUE;
    }
L32: 

    /** scanner.e:1666				integer basetype*/

    /** scanner.e:1667				if class = DOT then*/
    if (_class_27645 != -3)
    goto L34; // [1405] 1439

    /** scanner.e:1668					if getch() = '.' then*/
    _15364 = _62getch();
    if (binary_op_a(NOTEQ, _15364, 46)){
        DeRef(_15364);
        _15364 = NOVALUE;
        goto L35; // [1414] 1433
    }
    DeRef(_15364);
    _15364 = NOVALUE;

    /** scanner.e:1669						return {SLICE, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 513;
    ((intptr_t *)_2)[2] = 0;
    _15366 = MAKE_SEQ(_1);
    DeRef(_i_27636);
    DeRef(_yytext_27639);
    DeRef(_namespaces_27640);
    DeRef(_d_27641);
    DeRef(_tok_27643);
    DeRef(_name_27646);
    DeRef(_15284);
    _15284 = NOVALUE;
    DeRef(_15310);
    _15310 = NOVALUE;
    DeRef(_15253);
    _15253 = NOVALUE;
    DeRef(_15238);
    _15238 = NOVALUE;
    DeRef(_15260);
    _15260 = NOVALUE;
    _15275 = NOVALUE;
    DeRef(_15256);
    _15256 = NOVALUE;
    DeRef(_15247);
    _15247 = NOVALUE;
    DeRef(_15250);
    _15250 = NOVALUE;
    DeRef(_15279);
    _15279 = NOVALUE;
    DeRef(_15259);
    _15259 = NOVALUE;
    DeRef(_15359);
    _15359 = NOVALUE;
    DeRef(_15263);
    _15263 = NOVALUE;
    _15300 = NOVALUE;
    _15326 = NOVALUE;
    DeRef(_15355);
    _15355 = NOVALUE;
    DeRef(_15360);
    _15360 = NOVALUE;
    _15289 = NOVALUE;
    _15311 = NOVALUE;
    DeRef(_15233);
    _15233 = NOVALUE;
    return _15366;
    goto L36; // [1430] 1438
L35: 

    /** scanner.e:1671						ungetch()*/
    _62ungetch();
L36: 
L34: 

    /** scanner.e:1675				yytext = {ch}*/
    _0 = _yytext_27639;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _ch_27633;
    _yytext_27639 = MAKE_SEQ(_1);
    DeRef(_0);

    /** scanner.e:1676				is_int = (ch != '.')*/
    _is_int_27644 = (_ch_27633 != 46);

    /** scanner.e:1677				basetype = -1 -- default is decimal*/
    _basetype_27941 = -1;

    /** scanner.e:1678				while 1 with entry do*/
    goto L37; // [1458] 1651
L38: 

    /** scanner.e:1679					if char_class[ch] = DIGIT then*/
    _2 = (object)SEQ_PTR(_62char_class_25880);
    _15369 = (object)*(((s1_ptr)_2)->base + _ch_27633);
    if (_15369 != -7)
    goto L39; // [1471] 1484

    /** scanner.e:1680						yytext &= ch*/
    Append(&_yytext_27639, _yytext_27639, _ch_27633);
    goto L3A; // [1481] 1648
L39: 

    /** scanner.e:1682					elsif equal(yytext, "0") then*/
    if (_yytext_27639 == _15026)
    _15372 = 1;
    else if (IS_ATOM_INT(_yytext_27639) && IS_ATOM_INT(_15026))
    _15372 = 0;
    else
    _15372 = (compare(_yytext_27639, _15026) == 0);
    if (_15372 == 0)
    {
        _15372 = NOVALUE;
        goto L3B; // [1490] 1587
    }
    else{
        _15372 = NOVALUE;
    }

    /** scanner.e:1683						basetype = find(ch, nbasecode)*/
    _basetype_27941 = find_from(_ch_27633, _62nbasecode_27436, 1);

    /** scanner.e:1684						if basetype > length(nbase) then*/
    if (IS_SEQUENCE(_62nbase_27435)){
            _15374 = SEQ_PTR(_62nbase_27435)->length;
    }
    else {
        _15374 = 1;
    }
    if (_basetype_27941 <= _15374)
    goto L3C; // [1505] 1519

    /** scanner.e:1685							basetype -= length(nbase)*/
    if (IS_SEQUENCE(_62nbase_27435)){
            _15376 = SEQ_PTR(_62nbase_27435)->length;
    }
    else {
        _15376 = 1;
    }
    _basetype_27941 = _basetype_27941 - _15376;
    _15376 = NOVALUE;
L3C: 

    /** scanner.e:1688						if basetype = 0 then*/
    if (_basetype_27941 != 0)
    goto L3D; // [1521] 1578

    /** scanner.e:1689							if char_class[ch] = LETTER then*/
    _2 = (object)SEQ_PTR(_62char_class_25880);
    _15379 = (object)*(((s1_ptr)_2)->base + _ch_27633);
    if (_15379 != -2)
    goto L3E; // [1535] 1568

    /** scanner.e:1690								if ch != 'e' and ch != 'E' then*/
    _15381 = (_ch_27633 != 101);
    if (_15381 == 0) {
        goto L3F; // [1545] 1567
    }
    _15383 = (_ch_27633 != 69);
    if (_15383 == 0)
    {
        DeRef(_15383);
        _15383 = NOVALUE;
        goto L3F; // [1554] 1567
    }
    else{
        DeRef(_15383);
        _15383 = NOVALUE;
    }

    /** scanner.e:1691									CompileErr(INVALID_NUMBER_BASE_SPECIFIER_1, ch)*/
    _50CompileErr(105, _ch_27633, 0);
L3F: 
L3E: 

    /** scanner.e:1695							basetype = -1 -- decimal*/
    _basetype_27941 = -1;

    /** scanner.e:1696							exit*/
    goto L40; // [1575] 1663
L3D: 

    /** scanner.e:1698						yytext &= '0'*/
    Append(&_yytext_27639, _yytext_27639, 48);
    goto L3A; // [1584] 1648
L3B: 

    /** scanner.e:1700					elsif basetype = 4 then -- hexadecimal*/
    if (_basetype_27941 != 4)
    goto L40; // [1589] 1663

    /** scanner.e:1701						integer hdigit*/

    /** scanner.e:1702						hdigit = find(ch, "ABCDEFabcdef")*/
    _hdigit_27982 = find_from(_ch_27633, _15386, 1);

    /** scanner.e:1703						if hdigit = 0 then*/
    if (_hdigit_27982 != 0)
    goto L41; // [1604] 1615

    /** scanner.e:1704							exit*/
    goto L40; // [1612] 1663
L41: 

    /** scanner.e:1706						if hdigit > 6 then*/
    if (_hdigit_27982 <= 6)
    goto L42; // [1617] 1628

    /** scanner.e:1707							hdigit -= 6*/
    _hdigit_27982 = _hdigit_27982 - 6;
L42: 

    /** scanner.e:1709						yytext &= hexasc[hdigit]*/
    _2 = (object)SEQ_PTR(_62hexasc_27438);
    _15391 = (object)*(((s1_ptr)_2)->base + _hdigit_27982);
    if (IS_SEQUENCE(_yytext_27639) && IS_ATOM(_15391)) {
        Ref(_15391);
        Append(&_yytext_27639, _yytext_27639, _15391);
    }
    else if (IS_ATOM(_yytext_27639) && IS_SEQUENCE(_15391)) {
    }
    else {
        Concat((object_ptr)&_yytext_27639, _yytext_27639, _15391);
    }
    _15391 = NOVALUE;
    goto L3A; // [1640] 1648

    /** scanner.e:1712						exit*/
    goto L40; // [1645] 1663
L3A: 

    /** scanner.e:1714				entry*/
L37: 

    /** scanner.e:1715					ch = getch()*/
    _ch_27633 = _62getch();
    if (!IS_ATOM_INT(_ch_27633)) {
        _1 = (object)(DBL_PTR(_ch_27633)->dbl);
        DeRefDS(_ch_27633);
        _ch_27633 = _1;
    }

    /** scanner.e:1716				end while*/
    goto L38; // [1660] 1461
L40: 

    /** scanner.e:1718				if ch = '.' then*/
    if (_ch_27633 != 46)
    goto L43; // [1665] 1804

    /** scanner.e:1719					ch = getch()*/
    _ch_27633 = _62getch();
    if (!IS_ATOM_INT(_ch_27633)) {
        _1 = (object)(DBL_PTR(_ch_27633)->dbl);
        DeRefDS(_ch_27633);
        _ch_27633 = _1;
    }

    /** scanner.e:1720					if ch = '.' then*/
    if (_ch_27633 != 46)
    goto L44; // [1678] 1689

    /** scanner.e:1722						ungetch()*/
    _62ungetch();
    goto L45; // [1686] 1803
L44: 

    /** scanner.e:1724						is_int = FALSE*/
    _is_int_27644 = _13FALSE_445;

    /** scanner.e:1725						if yytext[1] = '.' then*/
    _2 = (object)SEQ_PTR(_yytext_27639);
    _15397 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _15397, 46)){
        _15397 = NOVALUE;
        goto L46; // [1704] 1720
    }
    _15397 = NOVALUE;

    /** scanner.e:1726							CompileErr(ONLY_ONE_DECIMAL_POINT_ALLOWED)*/
    RefDS(_22190);
    _50CompileErr(124, _22190, 0);
    goto L47; // [1717] 1727
L46: 

    /** scanner.e:1728							yytext &= '.'*/
    Append(&_yytext_27639, _yytext_27639, 46);
L47: 

    /** scanner.e:1730						if char_class[ch] = DIGIT then*/
    _2 = (object)SEQ_PTR(_62char_class_25880);
    _15400 = (object)*(((s1_ptr)_2)->base + _ch_27633);
    if (_15400 != -7)
    goto L48; // [1737] 1792

    /** scanner.e:1731							yytext &= ch*/
    Append(&_yytext_27639, _yytext_27639, _ch_27633);

    /** scanner.e:1732							ch = getch()*/
    _ch_27633 = _62getch();
    if (!IS_ATOM_INT(_ch_27633)) {
        _1 = (object)(DBL_PTR(_ch_27633)->dbl);
        DeRefDS(_ch_27633);
        _ch_27633 = _1;
    }

    /** scanner.e:1733							while char_class[ch] = DIGIT do*/
L49: 
    _2 = (object)SEQ_PTR(_62char_class_25880);
    _15404 = (object)*(((s1_ptr)_2)->base + _ch_27633);
    if (_15404 != -7)
    goto L4A; // [1767] 1802

    /** scanner.e:1734								yytext &= ch*/
    Append(&_yytext_27639, _yytext_27639, _ch_27633);

    /** scanner.e:1735								ch = getch()*/
    _ch_27633 = _62getch();
    if (!IS_ATOM_INT(_ch_27633)) {
        _1 = (object)(DBL_PTR(_ch_27633)->dbl);
        DeRefDS(_ch_27633);
        _ch_27633 = _1;
    }

    /** scanner.e:1736							end while*/
    goto L49; // [1786] 1759
    goto L4A; // [1789] 1802
L48: 

    /** scanner.e:1738							CompileErr(FRACTIONAL_PART_OF_NUMBER_IS_MISSING)*/
    RefDS(_22190);
    _50CompileErr(94, _22190, 0);
L4A: 
L45: 
L43: 

    /** scanner.e:1743				if basetype = -1 and find(ch, "eE") then*/
    _15408 = (_basetype_27941 == -1);
    if (_15408 == 0) {
        goto L4B; // [1810] 1948
    }
    _15411 = find_from(_ch_27633, _15410, 1);
    if (_15411 == 0)
    {
        _15411 = NOVALUE;
        goto L4B; // [1820] 1948
    }
    else{
        _15411 = NOVALUE;
    }

    /** scanner.e:1744					is_int = FALSE*/
    _is_int_27644 = _13FALSE_445;

    /** scanner.e:1745					yytext &= ch*/
    Append(&_yytext_27639, _yytext_27639, _ch_27633);

    /** scanner.e:1746					ch = getch()*/
    _ch_27633 = _62getch();
    if (!IS_ATOM_INT(_ch_27633)) {
        _1 = (object)(DBL_PTR(_ch_27633)->dbl);
        DeRefDS(_ch_27633);
        _ch_27633 = _1;
    }

    /** scanner.e:1747					if ch = '-' or ch = '+' or char_class[ch] = DIGIT then*/
    _15414 = (_ch_27633 == 45);
    if (_15414 != 0) {
        _15415 = 1;
        goto L4C; // [1851] 1863
    }
    _15416 = (_ch_27633 == 43);
    _15415 = (_15416 != 0);
L4C: 
    if (_15415 != 0) {
        goto L4D; // [1863] 1884
    }
    _2 = (object)SEQ_PTR(_62char_class_25880);
    _15418 = (object)*(((s1_ptr)_2)->base + _ch_27633);
    _15419 = (_15418 == -7);
    _15418 = NOVALUE;
    if (_15419 == 0)
    {
        DeRef(_15419);
        _15419 = NOVALUE;
        goto L4E; // [1880] 1893
    }
    else{
        DeRef(_15419);
        _15419 = NOVALUE;
    }
L4D: 

    /** scanner.e:1748						yytext &= ch*/
    Append(&_yytext_27639, _yytext_27639, _ch_27633);
    goto L4F; // [1890] 1903
L4E: 

    /** scanner.e:1750						CompileErr(EXPONENT_NOT_FORMED_CORRECTLY)*/
    RefDS(_22190);
    _50CompileErr(86, _22190, 0);
L4F: 

    /** scanner.e:1752					ch = getch()*/
    _ch_27633 = _62getch();
    if (!IS_ATOM_INT(_ch_27633)) {
        _1 = (object)(DBL_PTR(_ch_27633)->dbl);
        DeRefDS(_ch_27633);
        _ch_27633 = _1;
    }

    /** scanner.e:1753					while char_class[ch] = DIGIT do*/
L50: 
    _2 = (object)SEQ_PTR(_62char_class_25880);
    _15422 = (object)*(((s1_ptr)_2)->base + _ch_27633);
    if (_15422 != -7)
    goto L51; // [1923] 1981

    /** scanner.e:1754						yytext &= ch*/
    Append(&_yytext_27639, _yytext_27639, _ch_27633);

    /** scanner.e:1755						ch = getch()*/
    _ch_27633 = _62getch();
    if (!IS_ATOM_INT(_ch_27633)) {
        _1 = (object)(DBL_PTR(_ch_27633)->dbl);
        DeRefDS(_ch_27633);
        _ch_27633 = _1;
    }

    /** scanner.e:1756					end while*/
    goto L50; // [1942] 1915
    goto L51; // [1945] 1981
L4B: 

    /** scanner.e:1757				elsif char_class[ch] = LETTER then*/
    _2 = (object)SEQ_PTR(_62char_class_25880);
    _15426 = (object)*(((s1_ptr)_2)->base + _ch_27633);
    if (_15426 != -2)
    goto L52; // [1958] 1980

    /** scanner.e:1758					CompileErr(PUNCTUATION_MISSING_IN_BETWEEN_NUMBER_AND_1, {{ch}})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _ch_27633;
    _15428 = MAKE_SEQ(_1);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _15428;
    _15429 = MAKE_SEQ(_1);
    _15428 = NOVALUE;
    _50CompileErr(127, _15429, 0);
    _15429 = NOVALUE;
L52: 
L51: 

    /** scanner.e:1761				ungetch()*/
    _62ungetch();

    /** scanner.e:1763				while i != 0 with entry do*/
    goto L53; // [1987] 2006
L54: 
    if (binary_op_a(EQUALS, _i_27636, 0)){
        goto L55; // [1992] 2018
    }

    /** scanner.e:1764					yytext = remove( yytext, i )*/
    {
        s1_ptr assign_space = SEQ_PTR(_yytext_27639);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_i_27636)) ? _i_27636 : (object)(DBL_PTR(_i_27636)->dbl);
        int stop = (IS_ATOM_INT(_i_27636)) ? _i_27636 : (object)(DBL_PTR(_i_27636)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_yytext_27639), start, &_yytext_27639 );
            }
            else Tail(SEQ_PTR(_yytext_27639), stop+1, &_yytext_27639);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_yytext_27639), start, &_yytext_27639);
        }
        else {
            assign_slice_seq = &assign_space;
            _yytext_27639 = Remove_elements(start, stop, (SEQ_PTR(_yytext_27639)->ref == 1));
        }
    }

    /** scanner.e:1765				  entry*/
L53: 

    /** scanner.e:1766				    i = find('_', yytext)*/
    DeRef(_i_27636);
    _i_27636 = find_from(95, _yytext_27639, 1);

    /** scanner.e:1767				end while*/
    goto L54; // [2015] 1990
L55: 

    /** scanner.e:1769				if is_int then*/
    if (_is_int_27644 == 0)
    {
        goto L56; // [2020] 2092
    }
    else{
    }

    /** scanner.e:1770					if basetype = -1 then*/
    if (_basetype_27941 != -1)
    goto L57; // [2025] 2035

    /** scanner.e:1771						basetype = 3 -- decimal*/
    _basetype_27941 = 3;
L57: 

    /** scanner.e:1773					d = MakeInt(yytext, nbase[basetype])*/
    _2 = (object)SEQ_PTR(_62nbase_27435);
    _15434 = (object)*(((s1_ptr)_2)->base + _basetype_27941);
    RefDS(_yytext_27639);
    Ref(_15434);
    _0 = _d_27641;
    _d_27641 = _62MakeInt(_yytext_27639, _15434);
    DeRef(_0);
    _15434 = NOVALUE;

    /** scanner.e:1774					if is_integer(d) then*/
    Ref(_d_27641);
    _15436 = _36is_integer(_d_27641);
    if (_15436 == 0) {
        DeRef(_15436);
        _15436 = NOVALUE;
        goto L58; // [2052] 2074
    }
    else {
        if (!IS_ATOM_INT(_15436) && DBL_PTR(_15436)->dbl == 0.0){
            DeRef(_15436);
            _15436 = NOVALUE;
            goto L58; // [2052] 2074
        }
        DeRef(_15436);
        _15436 = NOVALUE;
    }
    DeRef(_15436);
    _15436 = NOVALUE;

    /** scanner.e:1775						return {ATOM, NewIntSym(d)}*/
    Ref(_d_27641);
    _15437 = _54NewIntSym(_d_27641);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 502;
    ((intptr_t *)_2)[2] = _15437;
    _15438 = MAKE_SEQ(_1);
    _15437 = NOVALUE;
    DeRef(_i_27636);
    DeRefDS(_yytext_27639);
    DeRef(_namespaces_27640);
    DeRef(_d_27641);
    DeRef(_tok_27643);
    DeRef(_name_27646);
    DeRef(_15284);
    _15284 = NOVALUE;
    DeRef(_15310);
    _15310 = NOVALUE;
    DeRef(_15253);
    _15253 = NOVALUE;
    DeRef(_15414);
    _15414 = NOVALUE;
    DeRef(_15238);
    _15238 = NOVALUE;
    _15426 = NOVALUE;
    DeRef(_15260);
    _15260 = NOVALUE;
    _15275 = NOVALUE;
    _15422 = NOVALUE;
    DeRef(_15256);
    _15256 = NOVALUE;
    _15379 = NOVALUE;
    DeRef(_15381);
    _15381 = NOVALUE;
    _15404 = NOVALUE;
    DeRef(_15247);
    _15247 = NOVALUE;
    DeRef(_15416);
    _15416 = NOVALUE;
    DeRef(_15250);
    _15250 = NOVALUE;
    DeRef(_15279);
    _15279 = NOVALUE;
    DeRef(_15259);
    _15259 = NOVALUE;
    DeRef(_15359);
    _15359 = NOVALUE;
    DeRef(_15263);
    _15263 = NOVALUE;
    _15300 = NOVALUE;
    _15326 = NOVALUE;
    DeRef(_15366);
    _15366 = NOVALUE;
    DeRef(_15355);
    _15355 = NOVALUE;
    DeRef(_15408);
    _15408 = NOVALUE;
    DeRef(_15360);
    _15360 = NOVALUE;
    _15400 = NOVALUE;
    _15369 = NOVALUE;
    _15289 = NOVALUE;
    _15311 = NOVALUE;
    DeRef(_15233);
    _15233 = NOVALUE;
    return _15438;
    goto L59; // [2071] 2091
L58: 

    /** scanner.e:1777						return {ATOM, NewDoubleSym(d)}*/
    Ref(_d_27641);
    _15439 = _54NewDoubleSym(_d_27641);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 502;
    ((intptr_t *)_2)[2] = _15439;
    _15440 = MAKE_SEQ(_1);
    _15439 = NOVALUE;
    DeRef(_i_27636);
    DeRef(_yytext_27639);
    DeRef(_namespaces_27640);
    DeRef(_d_27641);
    DeRef(_tok_27643);
    DeRef(_name_27646);
    DeRef(_15284);
    _15284 = NOVALUE;
    DeRef(_15310);
    _15310 = NOVALUE;
    DeRef(_15253);
    _15253 = NOVALUE;
    DeRef(_15414);
    _15414 = NOVALUE;
    DeRef(_15238);
    _15238 = NOVALUE;
    _15426 = NOVALUE;
    DeRef(_15260);
    _15260 = NOVALUE;
    _15275 = NOVALUE;
    _15422 = NOVALUE;
    DeRef(_15256);
    _15256 = NOVALUE;
    _15379 = NOVALUE;
    DeRef(_15381);
    _15381 = NOVALUE;
    _15404 = NOVALUE;
    DeRef(_15247);
    _15247 = NOVALUE;
    DeRef(_15416);
    _15416 = NOVALUE;
    DeRef(_15250);
    _15250 = NOVALUE;
    DeRef(_15279);
    _15279 = NOVALUE;
    DeRef(_15259);
    _15259 = NOVALUE;
    DeRef(_15359);
    _15359 = NOVALUE;
    DeRef(_15263);
    _15263 = NOVALUE;
    _15300 = NOVALUE;
    _15326 = NOVALUE;
    DeRef(_15366);
    _15366 = NOVALUE;
    DeRef(_15355);
    _15355 = NOVALUE;
    DeRef(_15408);
    _15408 = NOVALUE;
    DeRef(_15360);
    _15360 = NOVALUE;
    DeRef(_15438);
    _15438 = NOVALUE;
    _15400 = NOVALUE;
    _15369 = NOVALUE;
    _15289 = NOVALUE;
    _15311 = NOVALUE;
    DeRef(_15233);
    _15233 = NOVALUE;
    return _15440;
L59: 
L56: 

    /** scanner.e:1782				if basetype != -1 then*/
    if (_basetype_27941 == -1)
    goto L5A; // [2094] 2112

    /** scanner.e:1783					CompileErr(ONLY_INTEGER_LITERALS_CAN_USE_THE_01_FORMAT, nbasecode[basetype])*/
    _2 = (object)SEQ_PTR(_62nbasecode_27436);
    _15442 = (object)*(((s1_ptr)_2)->base + _basetype_27941);
    Ref(_15442);
    _50CompileErr(125, _15442, 0);
    _15442 = NOVALUE;
L5A: 

    /** scanner.e:1787				d = my_sscanf(yytext)*/
    RefDS(_yytext_27639);
    _0 = _d_27641;
    _d_27641 = _62my_sscanf(_yytext_27639);
    DeRef(_0);

    /** scanner.e:1788				if sequence(d) then*/
    _15444 = IS_SEQUENCE(_d_27641);
    if (_15444 == 0)
    {
        _15444 = NOVALUE;
        goto L5B; // [2123] 2138
    }
    else{
        _15444 = NOVALUE;
    }

    /** scanner.e:1789					CompileErr(NUMBER_NOT_FORMED_CORRECTLY)*/
    RefDS(_22190);
    _50CompileErr(121, _22190, 0);
    goto L5C; // [2135] 2190
L5B: 

    /** scanner.e:1790				elsif is_int and d <= TMAXINT_DBL then*/
    if (_is_int_27644 == 0) {
        goto L5D; // [2140] 2173
    }
    if (IS_ATOM_INT(_d_27641) && IS_ATOM_INT(_36TMAXINT_DBL_21599)) {
        _15446 = (_d_27641 <= _36TMAXINT_DBL_21599);
    }
    else {
        _15446 = binary_op(LESSEQ, _d_27641, _36TMAXINT_DBL_21599);
    }
    if (_15446 == 0) {
        DeRef(_15446);
        _15446 = NOVALUE;
        goto L5D; // [2151] 2173
    }
    else {
        if (!IS_ATOM_INT(_15446) && DBL_PTR(_15446)->dbl == 0.0){
            DeRef(_15446);
            _15446 = NOVALUE;
            goto L5D; // [2151] 2173
        }
        DeRef(_15446);
        _15446 = NOVALUE;
    }
    DeRef(_15446);
    _15446 = NOVALUE;

    /** scanner.e:1791					return {ATOM, NewIntSym(d)}  -- 1 to 1.07 billion*/
    Ref(_d_27641);
    _15447 = _54NewIntSym(_d_27641);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 502;
    ((intptr_t *)_2)[2] = _15447;
    _15448 = MAKE_SEQ(_1);
    _15447 = NOVALUE;
    DeRef(_i_27636);
    DeRef(_yytext_27639);
    DeRef(_namespaces_27640);
    DeRef(_d_27641);
    DeRef(_tok_27643);
    DeRef(_name_27646);
    DeRef(_15284);
    _15284 = NOVALUE;
    DeRef(_15310);
    _15310 = NOVALUE;
    DeRef(_15253);
    _15253 = NOVALUE;
    DeRef(_15414);
    _15414 = NOVALUE;
    DeRef(_15238);
    _15238 = NOVALUE;
    _15426 = NOVALUE;
    DeRef(_15260);
    _15260 = NOVALUE;
    _15275 = NOVALUE;
    _15422 = NOVALUE;
    DeRef(_15256);
    _15256 = NOVALUE;
    _15379 = NOVALUE;
    DeRef(_15381);
    _15381 = NOVALUE;
    _15404 = NOVALUE;
    DeRef(_15247);
    _15247 = NOVALUE;
    DeRef(_15416);
    _15416 = NOVALUE;
    DeRef(_15250);
    _15250 = NOVALUE;
    DeRef(_15279);
    _15279 = NOVALUE;
    DeRef(_15440);
    _15440 = NOVALUE;
    DeRef(_15259);
    _15259 = NOVALUE;
    DeRef(_15359);
    _15359 = NOVALUE;
    DeRef(_15263);
    _15263 = NOVALUE;
    _15300 = NOVALUE;
    _15326 = NOVALUE;
    DeRef(_15366);
    _15366 = NOVALUE;
    DeRef(_15355);
    _15355 = NOVALUE;
    DeRef(_15408);
    _15408 = NOVALUE;
    DeRef(_15360);
    _15360 = NOVALUE;
    DeRef(_15438);
    _15438 = NOVALUE;
    _15400 = NOVALUE;
    _15369 = NOVALUE;
    _15289 = NOVALUE;
    _15311 = NOVALUE;
    DeRef(_15233);
    _15233 = NOVALUE;
    return _15448;
    goto L5C; // [2170] 2190
L5D: 

    /** scanner.e:1793					return {ATOM, NewDoubleSym(d)}*/
    Ref(_d_27641);
    _15449 = _54NewDoubleSym(_d_27641);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 502;
    ((intptr_t *)_2)[2] = _15449;
    _15450 = MAKE_SEQ(_1);
    _15449 = NOVALUE;
    DeRef(_i_27636);
    DeRef(_yytext_27639);
    DeRef(_namespaces_27640);
    DeRef(_d_27641);
    DeRef(_tok_27643);
    DeRef(_name_27646);
    DeRef(_15284);
    _15284 = NOVALUE;
    DeRef(_15310);
    _15310 = NOVALUE;
    DeRef(_15253);
    _15253 = NOVALUE;
    DeRef(_15414);
    _15414 = NOVALUE;
    DeRef(_15238);
    _15238 = NOVALUE;
    _15426 = NOVALUE;
    DeRef(_15260);
    _15260 = NOVALUE;
    _15275 = NOVALUE;
    _15422 = NOVALUE;
    DeRef(_15256);
    _15256 = NOVALUE;
    _15379 = NOVALUE;
    DeRef(_15381);
    _15381 = NOVALUE;
    _15404 = NOVALUE;
    DeRef(_15247);
    _15247 = NOVALUE;
    DeRef(_15448);
    _15448 = NOVALUE;
    DeRef(_15416);
    _15416 = NOVALUE;
    DeRef(_15250);
    _15250 = NOVALUE;
    DeRef(_15279);
    _15279 = NOVALUE;
    DeRef(_15440);
    _15440 = NOVALUE;
    DeRef(_15259);
    _15259 = NOVALUE;
    DeRef(_15359);
    _15359 = NOVALUE;
    DeRef(_15263);
    _15263 = NOVALUE;
    _15300 = NOVALUE;
    _15326 = NOVALUE;
    DeRef(_15366);
    _15366 = NOVALUE;
    DeRef(_15355);
    _15355 = NOVALUE;
    DeRef(_15408);
    _15408 = NOVALUE;
    DeRef(_15360);
    _15360 = NOVALUE;
    DeRef(_15438);
    _15438 = NOVALUE;
    _15400 = NOVALUE;
    _15369 = NOVALUE;
    _15289 = NOVALUE;
    _15311 = NOVALUE;
    DeRef(_15233);
    _15233 = NOVALUE;
    return _15450;
L5C: 
    goto L1; // [2192] 10
L33: 

    /** scanner.e:1797			elsif class = MINUS then*/
    if (_class_27645 != 10)
    goto L5E; // [2199] 2285

    /** scanner.e:1798				ch = getch()*/
    _ch_27633 = _62getch();
    if (!IS_ATOM_INT(_ch_27633)) {
        _1 = (object)(DBL_PTR(_ch_27633)->dbl);
        DeRefDS(_ch_27633);
        _ch_27633 = _1;
    }

    /** scanner.e:1799				if ch = '-' then*/
    if (_ch_27633 != 45)
    goto L5F; // [2212] 2238

    /** scanner.e:1801					if start_include then*/
    if (_62start_include_25873 == 0)
    {
        goto L60; // [2220] 2230
    }
    else{
    }

    /** scanner.e:1802						IncludePush()*/
    _62IncludePush();
    goto L1; // [2227] 10
L60: 

    /** scanner.e:1804						read_line()*/
    _62read_line();
    goto L1; // [2235] 10
L5F: 

    /** scanner.e:1806				elsif ch = '=' then*/
    if (_ch_27633 != 61)
    goto L61; // [2240] 2259

    /** scanner.e:1807					return {MINUS_EQUALS, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 516;
    ((intptr_t *)_2)[2] = 0;
    _15455 = MAKE_SEQ(_1);
    DeRef(_i_27636);
    DeRef(_yytext_27639);
    DeRef(_namespaces_27640);
    DeRef(_d_27641);
    DeRef(_tok_27643);
    DeRef(_name_27646);
    DeRef(_15284);
    _15284 = NOVALUE;
    DeRef(_15310);
    _15310 = NOVALUE;
    DeRef(_15253);
    _15253 = NOVALUE;
    DeRef(_15414);
    _15414 = NOVALUE;
    DeRef(_15238);
    _15238 = NOVALUE;
    _15426 = NOVALUE;
    DeRef(_15260);
    _15260 = NOVALUE;
    _15275 = NOVALUE;
    _15422 = NOVALUE;
    DeRef(_15256);
    _15256 = NOVALUE;
    _15379 = NOVALUE;
    DeRef(_15381);
    _15381 = NOVALUE;
    _15404 = NOVALUE;
    DeRef(_15247);
    _15247 = NOVALUE;
    DeRef(_15448);
    _15448 = NOVALUE;
    DeRef(_15450);
    _15450 = NOVALUE;
    DeRef(_15416);
    _15416 = NOVALUE;
    DeRef(_15250);
    _15250 = NOVALUE;
    DeRef(_15279);
    _15279 = NOVALUE;
    DeRef(_15440);
    _15440 = NOVALUE;
    DeRef(_15259);
    _15259 = NOVALUE;
    DeRef(_15359);
    _15359 = NOVALUE;
    DeRef(_15263);
    _15263 = NOVALUE;
    _15300 = NOVALUE;
    _15326 = NOVALUE;
    DeRef(_15366);
    _15366 = NOVALUE;
    DeRef(_15355);
    _15355 = NOVALUE;
    DeRef(_15408);
    _15408 = NOVALUE;
    DeRef(_15360);
    _15360 = NOVALUE;
    DeRef(_15438);
    _15438 = NOVALUE;
    _15400 = NOVALUE;
    _15369 = NOVALUE;
    _15289 = NOVALUE;
    _15311 = NOVALUE;
    DeRef(_15233);
    _15233 = NOVALUE;
    return _15455;
    goto L1; // [2256] 10
L61: 

    /** scanner.e:1809					bp -= 1*/
    _50bp_49598 = _50bp_49598 - 1;

    /** scanner.e:1810					return {MINUS, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 10;
    ((intptr_t *)_2)[2] = 0;
    _15457 = MAKE_SEQ(_1);
    DeRef(_i_27636);
    DeRef(_yytext_27639);
    DeRef(_namespaces_27640);
    DeRef(_d_27641);
    DeRef(_tok_27643);
    DeRef(_name_27646);
    DeRef(_15284);
    _15284 = NOVALUE;
    DeRef(_15455);
    _15455 = NOVALUE;
    DeRef(_15310);
    _15310 = NOVALUE;
    DeRef(_15253);
    _15253 = NOVALUE;
    DeRef(_15414);
    _15414 = NOVALUE;
    DeRef(_15238);
    _15238 = NOVALUE;
    _15426 = NOVALUE;
    DeRef(_15260);
    _15260 = NOVALUE;
    _15275 = NOVALUE;
    _15422 = NOVALUE;
    DeRef(_15256);
    _15256 = NOVALUE;
    _15379 = NOVALUE;
    DeRef(_15381);
    _15381 = NOVALUE;
    _15404 = NOVALUE;
    DeRef(_15247);
    _15247 = NOVALUE;
    DeRef(_15448);
    _15448 = NOVALUE;
    DeRef(_15450);
    _15450 = NOVALUE;
    DeRef(_15416);
    _15416 = NOVALUE;
    DeRef(_15250);
    _15250 = NOVALUE;
    DeRef(_15279);
    _15279 = NOVALUE;
    DeRef(_15440);
    _15440 = NOVALUE;
    DeRef(_15259);
    _15259 = NOVALUE;
    DeRef(_15359);
    _15359 = NOVALUE;
    DeRef(_15263);
    _15263 = NOVALUE;
    _15300 = NOVALUE;
    _15326 = NOVALUE;
    DeRef(_15366);
    _15366 = NOVALUE;
    DeRef(_15355);
    _15355 = NOVALUE;
    DeRef(_15408);
    _15408 = NOVALUE;
    DeRef(_15360);
    _15360 = NOVALUE;
    DeRef(_15438);
    _15438 = NOVALUE;
    _15400 = NOVALUE;
    _15369 = NOVALUE;
    _15289 = NOVALUE;
    _15311 = NOVALUE;
    DeRef(_15233);
    _15233 = NOVALUE;
    return _15457;
    goto L1; // [2282] 10
L5E: 

    /** scanner.e:1812			elsif class = DOUBLE_QUOTE then*/
    if (_class_27645 != -4)
    goto L62; // [2289] 2487

    /** scanner.e:1813				integer fch*/

    /** scanner.e:1814				ch = getch()*/
    _ch_27633 = _62getch();
    if (!IS_ATOM_INT(_ch_27633)) {
        _1 = (object)(DBL_PTR(_ch_27633)->dbl);
        DeRefDS(_ch_27633);
        _ch_27633 = _1;
    }

    /** scanner.e:1815				if ch = '"' then*/
    if (_ch_27633 != 34)
    goto L63; // [2304] 2340

    /** scanner.e:1816					fch = getch()*/
    _fch_28122 = _62getch();
    if (!IS_ATOM_INT(_fch_28122)) {
        _1 = (object)(DBL_PTR(_fch_28122)->dbl);
        DeRefDS(_fch_28122);
        _fch_28122 = _1;
    }

    /** scanner.e:1817					if fch = '"' then*/
    if (_fch_28122 != 34)
    goto L64; // [2317] 2334

    /** scanner.e:1819						return ExtendedString( fch )*/
    _15463 = _62ExtendedString(_fch_28122);
    DeRef(_i_27636);
    DeRef(_yytext_27639);
    DeRef(_namespaces_27640);
    DeRef(_d_27641);
    DeRef(_tok_27643);
    DeRef(_name_27646);
    DeRef(_15284);
    _15284 = NOVALUE;
    DeRef(_15455);
    _15455 = NOVALUE;
    DeRef(_15310);
    _15310 = NOVALUE;
    DeRef(_15253);
    _15253 = NOVALUE;
    DeRef(_15414);
    _15414 = NOVALUE;
    DeRef(_15238);
    _15238 = NOVALUE;
    _15426 = NOVALUE;
    DeRef(_15260);
    _15260 = NOVALUE;
    _15275 = NOVALUE;
    _15422 = NOVALUE;
    DeRef(_15256);
    _15256 = NOVALUE;
    _15379 = NOVALUE;
    DeRef(_15381);
    _15381 = NOVALUE;
    _15404 = NOVALUE;
    DeRef(_15247);
    _15247 = NOVALUE;
    DeRef(_15448);
    _15448 = NOVALUE;
    DeRef(_15450);
    _15450 = NOVALUE;
    DeRef(_15416);
    _15416 = NOVALUE;
    DeRef(_15250);
    _15250 = NOVALUE;
    DeRef(_15279);
    _15279 = NOVALUE;
    DeRef(_15440);
    _15440 = NOVALUE;
    DeRef(_15259);
    _15259 = NOVALUE;
    DeRef(_15359);
    _15359 = NOVALUE;
    DeRef(_15263);
    _15263 = NOVALUE;
    DeRef(_15457);
    _15457 = NOVALUE;
    _15300 = NOVALUE;
    _15326 = NOVALUE;
    DeRef(_15366);
    _15366 = NOVALUE;
    DeRef(_15355);
    _15355 = NOVALUE;
    DeRef(_15408);
    _15408 = NOVALUE;
    DeRef(_15360);
    _15360 = NOVALUE;
    DeRef(_15438);
    _15438 = NOVALUE;
    _15400 = NOVALUE;
    _15369 = NOVALUE;
    _15289 = NOVALUE;
    _15311 = NOVALUE;
    DeRef(_15233);
    _15233 = NOVALUE;
    return _15463;
    goto L65; // [2331] 2339
L64: 

    /** scanner.e:1821						ungetch()*/
    _62ungetch();
L65: 
L63: 

    /** scanner.e:1824				yytext = ""*/
    RefDS(_5);
    DeRef(_yytext_27639);
    _yytext_27639 = _5;

    /** scanner.e:1825				while ch != '\n' and ch != '\r' do -- can't be EOF*/
L66: 
    _15464 = (_ch_27633 != 10);
    if (_15464 == 0) {
        goto L67; // [2356] 2437
    }
    _15466 = (_ch_27633 != 13);
    if (_15466 == 0)
    {
        DeRef(_15466);
        _15466 = NOVALUE;
        goto L67; // [2365] 2437
    }
    else{
        DeRef(_15466);
        _15466 = NOVALUE;
    }

    /** scanner.e:1826					if ch = '"' then*/
    if (_ch_27633 != 34)
    goto L68; // [2370] 2381

    /** scanner.e:1827						exit*/
    goto L67; // [2376] 2437
    goto L69; // [2378] 2425
L68: 

    /** scanner.e:1828					elsif ch = '\\' then*/
    if (_ch_27633 != 92)
    goto L6A; // [2383] 2400

    /** scanner.e:1829						yytext &= EscapeChar('"')*/
    _15469 = _62EscapeChar(34);
    if (IS_SEQUENCE(_yytext_27639) && IS_ATOM(_15469)) {
        Ref(_15469);
        Append(&_yytext_27639, _yytext_27639, _15469);
    }
    else if (IS_ATOM(_yytext_27639) && IS_SEQUENCE(_15469)) {
    }
    else {
        Concat((object_ptr)&_yytext_27639, _yytext_27639, _15469);
    }
    DeRef(_15469);
    _15469 = NOVALUE;
    goto L69; // [2397] 2425
L6A: 

    /** scanner.e:1830					elsif ch = '\t' then*/
    if (_ch_27633 != 9)
    goto L6B; // [2402] 2418

    /** scanner.e:1831						CompileErr(MSG_TAB_CHARACTER_FOUND_IN_STRING__USE_T_INSTEAD)*/
    RefDS(_22190);
    _50CompileErr(145, _22190, 0);
    goto L69; // [2415] 2425
L6B: 

    /** scanner.e:1833						yytext &= ch*/
    Append(&_yytext_27639, _yytext_27639, _ch_27633);
L69: 

    /** scanner.e:1835					ch = getch()*/
    _ch_27633 = _62getch();
    if (!IS_ATOM_INT(_ch_27633)) {
        _1 = (object)(DBL_PTR(_ch_27633)->dbl);
        DeRefDS(_ch_27633);
        _ch_27633 = _1;
    }

    /** scanner.e:1836				end while*/
    goto L66; // [2434] 2352
L67: 

    /** scanner.e:1837				if ch = '\n' or ch = '\r' then*/
    _15474 = (_ch_27633 == 10);
    if (_15474 != 0) {
        goto L6C; // [2443] 2456
    }
    _15476 = (_ch_27633 == 13);
    if (_15476 == 0)
    {
        DeRef(_15476);
        _15476 = NOVALUE;
        goto L6D; // [2452] 2466
    }
    else{
        DeRef(_15476);
        _15476 = NOVALUE;
    }
L6C: 

    /** scanner.e:1838					CompileErr(END_OF_LINE_REACHED_WITH_NO_CLOSING)*/
    RefDS(_22190);
    _50CompileErr(67, _22190, 0);
L6D: 

    /** scanner.e:1840				return {STRING, NewStringSym(yytext)}*/
    RefDS(_yytext_27639);
    _15477 = _54NewStringSym(_yytext_27639);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 503;
    ((intptr_t *)_2)[2] = _15477;
    _15478 = MAKE_SEQ(_1);
    _15477 = NOVALUE;
    DeRef(_i_27636);
    DeRefDS(_yytext_27639);
    DeRef(_namespaces_27640);
    DeRef(_d_27641);
    DeRef(_tok_27643);
    DeRef(_name_27646);
    DeRef(_15284);
    _15284 = NOVALUE;
    DeRef(_15455);
    _15455 = NOVALUE;
    DeRef(_15310);
    _15310 = NOVALUE;
    DeRef(_15253);
    _15253 = NOVALUE;
    DeRef(_15414);
    _15414 = NOVALUE;
    DeRef(_15238);
    _15238 = NOVALUE;
    _15426 = NOVALUE;
    DeRef(_15260);
    _15260 = NOVALUE;
    _15275 = NOVALUE;
    _15422 = NOVALUE;
    DeRef(_15256);
    _15256 = NOVALUE;
    _15379 = NOVALUE;
    DeRef(_15381);
    _15381 = NOVALUE;
    _15404 = NOVALUE;
    DeRef(_15247);
    _15247 = NOVALUE;
    DeRef(_15448);
    _15448 = NOVALUE;
    DeRef(_15464);
    _15464 = NOVALUE;
    DeRef(_15450);
    _15450 = NOVALUE;
    DeRef(_15416);
    _15416 = NOVALUE;
    DeRef(_15250);
    _15250 = NOVALUE;
    DeRef(_15279);
    _15279 = NOVALUE;
    DeRef(_15474);
    _15474 = NOVALUE;
    DeRef(_15440);
    _15440 = NOVALUE;
    DeRef(_15259);
    _15259 = NOVALUE;
    DeRef(_15359);
    _15359 = NOVALUE;
    DeRef(_15263);
    _15263 = NOVALUE;
    DeRef(_15457);
    _15457 = NOVALUE;
    _15300 = NOVALUE;
    _15326 = NOVALUE;
    DeRef(_15366);
    _15366 = NOVALUE;
    DeRef(_15355);
    _15355 = NOVALUE;
    DeRef(_15463);
    _15463 = NOVALUE;
    DeRef(_15408);
    _15408 = NOVALUE;
    DeRef(_15360);
    _15360 = NOVALUE;
    DeRef(_15438);
    _15438 = NOVALUE;
    _15400 = NOVALUE;
    _15369 = NOVALUE;
    _15289 = NOVALUE;
    _15311 = NOVALUE;
    DeRef(_15233);
    _15233 = NOVALUE;
    return _15478;
    goto L1; // [2484] 10
L62: 

    /** scanner.e:1842			elsif class = PLUS then*/
    if (_class_27645 != 11)
    goto L6E; // [2491] 2543

    /** scanner.e:1843				ch = getch()*/
    _ch_27633 = _62getch();
    if (!IS_ATOM_INT(_ch_27633)) {
        _1 = (object)(DBL_PTR(_ch_27633)->dbl);
        DeRefDS(_ch_27633);
        _ch_27633 = _1;
    }

    /** scanner.e:1844				if ch = '=' then*/
    if (_ch_27633 != 61)
    goto L6F; // [2504] 2523

    /** scanner.e:1845					return {PLUS_EQUALS, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 515;
    ((intptr_t *)_2)[2] = 0;
    _15482 = MAKE_SEQ(_1);
    DeRef(_i_27636);
    DeRef(_yytext_27639);
    DeRef(_namespaces_27640);
    DeRef(_d_27641);
    DeRef(_tok_27643);
    DeRef(_name_27646);
    DeRef(_15284);
    _15284 = NOVALUE;
    DeRef(_15455);
    _15455 = NOVALUE;
    DeRef(_15310);
    _15310 = NOVALUE;
    DeRef(_15253);
    _15253 = NOVALUE;
    DeRef(_15414);
    _15414 = NOVALUE;
    DeRef(_15238);
    _15238 = NOVALUE;
    _15426 = NOVALUE;
    DeRef(_15260);
    _15260 = NOVALUE;
    _15275 = NOVALUE;
    _15422 = NOVALUE;
    DeRef(_15256);
    _15256 = NOVALUE;
    _15379 = NOVALUE;
    DeRef(_15381);
    _15381 = NOVALUE;
    _15404 = NOVALUE;
    DeRef(_15478);
    _15478 = NOVALUE;
    DeRef(_15247);
    _15247 = NOVALUE;
    DeRef(_15448);
    _15448 = NOVALUE;
    DeRef(_15464);
    _15464 = NOVALUE;
    DeRef(_15450);
    _15450 = NOVALUE;
    DeRef(_15416);
    _15416 = NOVALUE;
    DeRef(_15250);
    _15250 = NOVALUE;
    DeRef(_15279);
    _15279 = NOVALUE;
    DeRef(_15474);
    _15474 = NOVALUE;
    DeRef(_15440);
    _15440 = NOVALUE;
    DeRef(_15259);
    _15259 = NOVALUE;
    DeRef(_15359);
    _15359 = NOVALUE;
    DeRef(_15263);
    _15263 = NOVALUE;
    DeRef(_15457);
    _15457 = NOVALUE;
    _15300 = NOVALUE;
    _15326 = NOVALUE;
    DeRef(_15366);
    _15366 = NOVALUE;
    DeRef(_15355);
    _15355 = NOVALUE;
    DeRef(_15463);
    _15463 = NOVALUE;
    DeRef(_15408);
    _15408 = NOVALUE;
    DeRef(_15360);
    _15360 = NOVALUE;
    DeRef(_15438);
    _15438 = NOVALUE;
    _15400 = NOVALUE;
    _15369 = NOVALUE;
    _15289 = NOVALUE;
    _15311 = NOVALUE;
    DeRef(_15233);
    _15233 = NOVALUE;
    return _15482;
    goto L1; // [2520] 10
L6F: 

    /** scanner.e:1847					ungetch()*/
    _62ungetch();

    /** scanner.e:1848					return {PLUS, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 11;
    ((intptr_t *)_2)[2] = 0;
    _15483 = MAKE_SEQ(_1);
    DeRef(_i_27636);
    DeRef(_yytext_27639);
    DeRef(_namespaces_27640);
    DeRef(_d_27641);
    DeRef(_tok_27643);
    DeRef(_name_27646);
    DeRef(_15284);
    _15284 = NOVALUE;
    DeRef(_15455);
    _15455 = NOVALUE;
    DeRef(_15310);
    _15310 = NOVALUE;
    DeRef(_15253);
    _15253 = NOVALUE;
    DeRef(_15414);
    _15414 = NOVALUE;
    DeRef(_15238);
    _15238 = NOVALUE;
    _15426 = NOVALUE;
    DeRef(_15260);
    _15260 = NOVALUE;
    _15275 = NOVALUE;
    _15422 = NOVALUE;
    DeRef(_15256);
    _15256 = NOVALUE;
    _15379 = NOVALUE;
    DeRef(_15381);
    _15381 = NOVALUE;
    _15404 = NOVALUE;
    DeRef(_15478);
    _15478 = NOVALUE;
    DeRef(_15247);
    _15247 = NOVALUE;
    DeRef(_15448);
    _15448 = NOVALUE;
    DeRef(_15464);
    _15464 = NOVALUE;
    DeRef(_15450);
    _15450 = NOVALUE;
    DeRef(_15416);
    _15416 = NOVALUE;
    DeRef(_15250);
    _15250 = NOVALUE;
    DeRef(_15279);
    _15279 = NOVALUE;
    DeRef(_15474);
    _15474 = NOVALUE;
    DeRef(_15440);
    _15440 = NOVALUE;
    DeRef(_15259);
    _15259 = NOVALUE;
    DeRef(_15359);
    _15359 = NOVALUE;
    DeRef(_15263);
    _15263 = NOVALUE;
    DeRef(_15457);
    _15457 = NOVALUE;
    _15300 = NOVALUE;
    _15326 = NOVALUE;
    DeRef(_15366);
    _15366 = NOVALUE;
    DeRef(_15355);
    _15355 = NOVALUE;
    DeRef(_15463);
    _15463 = NOVALUE;
    DeRef(_15408);
    _15408 = NOVALUE;
    DeRef(_15360);
    _15360 = NOVALUE;
    DeRef(_15438);
    _15438 = NOVALUE;
    _15400 = NOVALUE;
    _15369 = NOVALUE;
    _15289 = NOVALUE;
    DeRef(_15482);
    _15482 = NOVALUE;
    _15311 = NOVALUE;
    DeRef(_15233);
    _15233 = NOVALUE;
    return _15483;
    goto L1; // [2540] 10
L6E: 

    /** scanner.e:1851			elsif class = res:CONCAT then*/
    if (_class_27645 != 15)
    goto L70; // [2545] 2595

    /** scanner.e:1852				ch = getch()*/
    _ch_27633 = _62getch();
    if (!IS_ATOM_INT(_ch_27633)) {
        _1 = (object)(DBL_PTR(_ch_27633)->dbl);
        DeRefDS(_ch_27633);
        _ch_27633 = _1;
    }

    /** scanner.e:1853				if ch = '=' then*/
    if (_ch_27633 != 61)
    goto L71; // [2558] 2577

    /** scanner.e:1854					return {CONCAT_EQUALS, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 519;
    ((intptr_t *)_2)[2] = 0;
    _15487 = MAKE_SEQ(_1);
    DeRef(_i_27636);
    DeRef(_yytext_27639);
    DeRef(_namespaces_27640);
    DeRef(_d_27641);
    DeRef(_tok_27643);
    DeRef(_name_27646);
    DeRef(_15284);
    _15284 = NOVALUE;
    DeRef(_15455);
    _15455 = NOVALUE;
    DeRef(_15310);
    _15310 = NOVALUE;
    DeRef(_15253);
    _15253 = NOVALUE;
    DeRef(_15414);
    _15414 = NOVALUE;
    DeRef(_15238);
    _15238 = NOVALUE;
    _15426 = NOVALUE;
    DeRef(_15260);
    _15260 = NOVALUE;
    _15275 = NOVALUE;
    _15422 = NOVALUE;
    DeRef(_15256);
    _15256 = NOVALUE;
    _15379 = NOVALUE;
    DeRef(_15381);
    _15381 = NOVALUE;
    DeRef(_15483);
    _15483 = NOVALUE;
    _15404 = NOVALUE;
    DeRef(_15478);
    _15478 = NOVALUE;
    DeRef(_15247);
    _15247 = NOVALUE;
    DeRef(_15448);
    _15448 = NOVALUE;
    DeRef(_15464);
    _15464 = NOVALUE;
    DeRef(_15450);
    _15450 = NOVALUE;
    DeRef(_15416);
    _15416 = NOVALUE;
    DeRef(_15250);
    _15250 = NOVALUE;
    DeRef(_15279);
    _15279 = NOVALUE;
    DeRef(_15474);
    _15474 = NOVALUE;
    DeRef(_15440);
    _15440 = NOVALUE;
    DeRef(_15259);
    _15259 = NOVALUE;
    DeRef(_15359);
    _15359 = NOVALUE;
    DeRef(_15263);
    _15263 = NOVALUE;
    DeRef(_15457);
    _15457 = NOVALUE;
    _15300 = NOVALUE;
    _15326 = NOVALUE;
    DeRef(_15366);
    _15366 = NOVALUE;
    DeRef(_15355);
    _15355 = NOVALUE;
    DeRef(_15463);
    _15463 = NOVALUE;
    DeRef(_15408);
    _15408 = NOVALUE;
    DeRef(_15360);
    _15360 = NOVALUE;
    DeRef(_15438);
    _15438 = NOVALUE;
    _15400 = NOVALUE;
    _15369 = NOVALUE;
    _15289 = NOVALUE;
    DeRef(_15482);
    _15482 = NOVALUE;
    _15311 = NOVALUE;
    DeRef(_15233);
    _15233 = NOVALUE;
    return _15487;
    goto L1; // [2574] 10
L71: 

    /** scanner.e:1856					ungetch()*/
    _62ungetch();

    /** scanner.e:1857					return {res:CONCAT, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 15;
    ((intptr_t *)_2)[2] = 0;
    _15488 = MAKE_SEQ(_1);
    DeRef(_i_27636);
    DeRef(_yytext_27639);
    DeRef(_namespaces_27640);
    DeRef(_d_27641);
    DeRef(_tok_27643);
    DeRef(_name_27646);
    DeRef(_15284);
    _15284 = NOVALUE;
    DeRef(_15455);
    _15455 = NOVALUE;
    DeRef(_15310);
    _15310 = NOVALUE;
    DeRef(_15253);
    _15253 = NOVALUE;
    DeRef(_15414);
    _15414 = NOVALUE;
    DeRef(_15238);
    _15238 = NOVALUE;
    _15426 = NOVALUE;
    DeRef(_15260);
    _15260 = NOVALUE;
    _15275 = NOVALUE;
    _15422 = NOVALUE;
    DeRef(_15256);
    _15256 = NOVALUE;
    _15379 = NOVALUE;
    DeRef(_15381);
    _15381 = NOVALUE;
    DeRef(_15483);
    _15483 = NOVALUE;
    _15404 = NOVALUE;
    DeRef(_15478);
    _15478 = NOVALUE;
    DeRef(_15247);
    _15247 = NOVALUE;
    DeRef(_15448);
    _15448 = NOVALUE;
    DeRef(_15464);
    _15464 = NOVALUE;
    DeRef(_15450);
    _15450 = NOVALUE;
    DeRef(_15416);
    _15416 = NOVALUE;
    DeRef(_15250);
    _15250 = NOVALUE;
    DeRef(_15279);
    _15279 = NOVALUE;
    DeRef(_15474);
    _15474 = NOVALUE;
    DeRef(_15487);
    _15487 = NOVALUE;
    DeRef(_15440);
    _15440 = NOVALUE;
    DeRef(_15259);
    _15259 = NOVALUE;
    DeRef(_15359);
    _15359 = NOVALUE;
    DeRef(_15263);
    _15263 = NOVALUE;
    DeRef(_15457);
    _15457 = NOVALUE;
    _15300 = NOVALUE;
    _15326 = NOVALUE;
    DeRef(_15366);
    _15366 = NOVALUE;
    DeRef(_15355);
    _15355 = NOVALUE;
    DeRef(_15463);
    _15463 = NOVALUE;
    DeRef(_15408);
    _15408 = NOVALUE;
    DeRef(_15360);
    _15360 = NOVALUE;
    DeRef(_15438);
    _15438 = NOVALUE;
    _15400 = NOVALUE;
    _15369 = NOVALUE;
    _15289 = NOVALUE;
    DeRef(_15482);
    _15482 = NOVALUE;
    _15311 = NOVALUE;
    DeRef(_15233);
    _15233 = NOVALUE;
    return _15488;
    goto L1; // [2592] 10
L70: 

    /** scanner.e:1860			elsif class = NUMBER_SIGN then*/
    if (_class_27645 != -11)
    goto L72; // [2599] 3122

    /** scanner.e:1861				i = 0*/
    DeRef(_i_27636);
    _i_27636 = 0;

    /** scanner.e:1862				is_int = -1*/
    _is_int_27644 = -1;

    /** scanner.e:1863				while i < TMAXINT/32 do*/
L73: 
    if (IS_ATOM_INT(_36TMAXINT_21596)) {
        _15490 = (_36TMAXINT_21596 % 32) ? NewDouble((eudouble)_36TMAXINT_21596 / 32) : (_36TMAXINT_21596 / 32);
    }
    else {
        _15490 = NewDouble(DBL_PTR(_36TMAXINT_21596)->dbl / (eudouble)32);
    }
    if (binary_op_a(GREATEREQ, _i_27636, _15490)){
        DeRef(_15490);
        _15490 = NOVALUE;
        goto L74; // [2624] 2788
    }
    DeRef(_15490);
    _15490 = NOVALUE;

    /** scanner.e:1864					ch = getch()*/
    _ch_27633 = _62getch();
    if (!IS_ATOM_INT(_ch_27633)) {
        _1 = (object)(DBL_PTR(_ch_27633)->dbl);
        DeRefDS(_ch_27633);
        _ch_27633 = _1;
    }

    /** scanner.e:1865					if char_class[ch] = DIGIT then*/
    _2 = (object)SEQ_PTR(_62char_class_25880);
    _15493 = (object)*(((s1_ptr)_2)->base + _ch_27633);
    if (_15493 != -7)
    goto L75; // [2645] 2682

    /** scanner.e:1866						if ch != '_' then*/
    if (_ch_27633 == 95)
    goto L73; // [2651] 2618

    /** scanner.e:1867							i = i * 16 + ch - '0'*/
    if (IS_ATOM_INT(_i_27636)) {
        if (_i_27636 == (short)_i_27636){
            _15496 = _i_27636 * 16;
        }
        else{
            _15496 = NewDouble(_i_27636 * (eudouble)16);
        }
    }
    else {
        _15496 = NewDouble(DBL_PTR(_i_27636)->dbl * (eudouble)16);
    }
    if (IS_ATOM_INT(_15496)) {
        _15497 = _15496 + _ch_27633;
        if ((object)((uintptr_t)_15497 + (uintptr_t)HIGH_BITS) >= 0){
            _15497 = NewDouble((eudouble)_15497);
        }
    }
    else {
        _15497 = NewDouble(DBL_PTR(_15496)->dbl + (eudouble)_ch_27633);
    }
    DeRef(_15496);
    _15496 = NOVALUE;
    DeRef(_i_27636);
    if (IS_ATOM_INT(_15497)) {
        _i_27636 = _15497 - 48;
        if ((object)((uintptr_t)_i_27636 +(uintptr_t) HIGH_BITS) >= 0){
            _i_27636 = NewDouble((eudouble)_i_27636);
        }
    }
    else {
        _i_27636 = NewDouble(DBL_PTR(_15497)->dbl - (eudouble)48);
    }
    DeRef(_15497);
    _15497 = NOVALUE;

    /** scanner.e:1868							is_int = TRUE*/
    _is_int_27644 = _13TRUE_447;
    goto L73; // [2679] 2618
L75: 

    /** scanner.e:1870					elsif ch >= 'A' and ch <= 'F' then*/
    _15499 = (_ch_27633 >= 65);
    if (_15499 == 0) {
        goto L76; // [2688] 2730
    }
    _15501 = (_ch_27633 <= 70);
    if (_15501 == 0)
    {
        DeRef(_15501);
        _15501 = NOVALUE;
        goto L76; // [2697] 2730
    }
    else{
        DeRef(_15501);
        _15501 = NOVALUE;
    }

    /** scanner.e:1871						i = (i * 16) + ch - ('A'-10)*/
    if (IS_ATOM_INT(_i_27636)) {
        if (_i_27636 == (short)_i_27636){
            _15502 = _i_27636 * 16;
        }
        else{
            _15502 = NewDouble(_i_27636 * (eudouble)16);
        }
    }
    else {
        _15502 = NewDouble(DBL_PTR(_i_27636)->dbl * (eudouble)16);
    }
    if (IS_ATOM_INT(_15502)) {
        _15503 = _15502 + _ch_27633;
        if ((object)((uintptr_t)_15503 + (uintptr_t)HIGH_BITS) >= 0){
            _15503 = NewDouble((eudouble)_15503);
        }
    }
    else {
        _15503 = NewDouble(DBL_PTR(_15502)->dbl + (eudouble)_ch_27633);
    }
    DeRef(_15502);
    _15502 = NOVALUE;
    _15504 = 55;
    DeRef(_i_27636);
    if (IS_ATOM_INT(_15503)) {
        _i_27636 = _15503 - 55;
        if ((object)((uintptr_t)_i_27636 +(uintptr_t) HIGH_BITS) >= 0){
            _i_27636 = NewDouble((eudouble)_i_27636);
        }
    }
    else {
        _i_27636 = NewDouble(DBL_PTR(_15503)->dbl - (eudouble)55);
    }
    DeRef(_15503);
    _15503 = NOVALUE;
    _15504 = NOVALUE;

    /** scanner.e:1872						is_int = TRUE*/
    _is_int_27644 = _13TRUE_447;
    goto L73; // [2727] 2618
L76: 

    /** scanner.e:1873					elsif ch >= 'a' and ch <= 'f' then*/
    _15506 = (_ch_27633 >= 97);
    if (_15506 == 0) {
        goto L74; // [2736] 2788
    }
    _15508 = (_ch_27633 <= 102);
    if (_15508 == 0)
    {
        DeRef(_15508);
        _15508 = NOVALUE;
        goto L74; // [2745] 2788
    }
    else{
        DeRef(_15508);
        _15508 = NOVALUE;
    }

    /** scanner.e:1874						i = (i * 16) + ch - ('a'-10)*/
    if (IS_ATOM_INT(_i_27636)) {
        if (_i_27636 == (short)_i_27636){
            _15509 = _i_27636 * 16;
        }
        else{
            _15509 = NewDouble(_i_27636 * (eudouble)16);
        }
    }
    else {
        _15509 = NewDouble(DBL_PTR(_i_27636)->dbl * (eudouble)16);
    }
    if (IS_ATOM_INT(_15509)) {
        _15510 = _15509 + _ch_27633;
        if ((object)((uintptr_t)_15510 + (uintptr_t)HIGH_BITS) >= 0){
            _15510 = NewDouble((eudouble)_15510);
        }
    }
    else {
        _15510 = NewDouble(DBL_PTR(_15509)->dbl + (eudouble)_ch_27633);
    }
    DeRef(_15509);
    _15509 = NOVALUE;
    _15511 = 87;
    DeRef(_i_27636);
    if (IS_ATOM_INT(_15510)) {
        _i_27636 = _15510 - 87;
        if ((object)((uintptr_t)_i_27636 +(uintptr_t) HIGH_BITS) >= 0){
            _i_27636 = NewDouble((eudouble)_i_27636);
        }
    }
    else {
        _i_27636 = NewDouble(DBL_PTR(_15510)->dbl - (eudouble)87);
    }
    DeRef(_15510);
    _15510 = NOVALUE;
    _15511 = NOVALUE;

    /** scanner.e:1875						is_int = TRUE*/
    _is_int_27644 = _13TRUE_447;
    goto L73; // [2775] 2618

    /** scanner.e:1877						exit*/
    goto L74; // [2780] 2788

    /** scanner.e:1879				end while*/
    goto L73; // [2785] 2618
L74: 

    /** scanner.e:1881				if is_int = -1 then*/
    if (_is_int_27644 != -1)
    goto L77; // [2790] 2857

    /** scanner.e:1882					if ch = '!' then*/
    if (_ch_27633 != 33)
    goto L78; // [2796] 2844

    /** scanner.e:1883						if line_number > 1 then*/
    if (_36line_number_21768 <= 1)
    goto L79; // [2804] 2818

    /** scanner.e:1884							CompileErr(MSG__MAY_ONLY_BE_ON_THE_FIRST_LINE_OF_A_PROGRAM)*/
    RefDS(_22190);
    _50CompileErr(161, _22190, 0);
L79: 

    /** scanner.e:1887						shebang = ThisLine*/
    Ref(_50ThisLine_49594);
    DeRef(_62shebang_25878);
    _62shebang_25878 = _50ThisLine_49594;

    /** scanner.e:1888						if start_include then*/
    if (_62start_include_25873 == 0)
    {
        goto L7A; // [2829] 2837
    }
    else{
    }

    /** scanner.e:1889							IncludePush()*/
    _62IncludePush();
L7A: 

    /** scanner.e:1891						read_line()*/
    _62read_line();
    goto L1; // [2841] 10
L78: 

    /** scanner.e:1893						CompileErr(HEX_NUMBER_NOT_FORMED_CORRECTLY)*/
    RefDS(_22190);
    _50CompileErr(97, _22190, 0);
    goto L1; // [2854] 10
L77: 

    /** scanner.e:1896					d = i*/
    Ref(_i_27636);
    DeRef(_d_27641);
    _d_27641 = _i_27636;

    /** scanner.e:1897					if i >= TMAXINT/32 then*/
    if (IS_ATOM_INT(_36TMAXINT_21596)) {
        _15516 = (_36TMAXINT_21596 % 32) ? NewDouble((eudouble)_36TMAXINT_21596 / 32) : (_36TMAXINT_21596 / 32);
    }
    else {
        _15516 = NewDouble(DBL_PTR(_36TMAXINT_21596)->dbl / (eudouble)32);
    }
    if (binary_op_a(LESS, _i_27636, _15516)){
        DeRef(_15516);
        _15516 = NOVALUE;
        goto L7B; // [2870] 3036
    }
    DeRef(_15516);
    _15516 = NOVALUE;

    /** scanner.e:1898						is_int = FALSE*/
    _is_int_27644 = _13FALSE_445;

    /** scanner.e:1899						while TRUE do*/
L7C: 
    if (_13TRUE_447 == 0)
    {
        goto L7D; // [2890] 3035
    }
    else{
    }

    /** scanner.e:1900							ch = getch()  -- eventually END_OF_FILE_CHAR or new-line*/
    _ch_27633 = _62getch();
    if (!IS_ATOM_INT(_ch_27633)) {
        _1 = (object)(DBL_PTR(_ch_27633)->dbl);
        DeRefDS(_ch_27633);
        _ch_27633 = _1;
    }

    /** scanner.e:1901							if char_class[ch] = DIGIT then*/
    _2 = (object)SEQ_PTR(_62char_class_25880);
    _15519 = (object)*(((s1_ptr)_2)->base + _ch_27633);
    if (_15519 != -7)
    goto L7E; // [2910] 2938

    /** scanner.e:1902								if ch != '_' then*/
    if (_ch_27633 == 95)
    goto L7C; // [2916] 2888

    /** scanner.e:1903									d = (d * 16) + ch - '0'*/
    if (IS_ATOM_INT(_d_27641)) {
        if (_d_27641 == (short)_d_27641){
            _15522 = _d_27641 * 16;
        }
        else{
            _15522 = NewDouble(_d_27641 * (eudouble)16);
        }
    }
    else {
        _15522 = binary_op(MULTIPLY, _d_27641, 16);
    }
    if (IS_ATOM_INT(_15522)) {
        _15523 = _15522 + _ch_27633;
        if ((object)((uintptr_t)_15523 + (uintptr_t)HIGH_BITS) >= 0){
            _15523 = NewDouble((eudouble)_15523);
        }
    }
    else {
        _15523 = binary_op(PLUS, _15522, _ch_27633);
    }
    DeRef(_15522);
    _15522 = NOVALUE;
    DeRef(_d_27641);
    if (IS_ATOM_INT(_15523)) {
        _d_27641 = _15523 - 48;
        if ((object)((uintptr_t)_d_27641 +(uintptr_t) HIGH_BITS) >= 0){
            _d_27641 = NewDouble((eudouble)_d_27641);
        }
    }
    else {
        _d_27641 = binary_op(MINUS, _15523, 48);
    }
    DeRef(_15523);
    _15523 = NOVALUE;
    goto L7C; // [2935] 2888
L7E: 

    /** scanner.e:1905							elsif ch >= 'A' and ch <= 'F' then*/
    _15525 = (_ch_27633 >= 65);
    if (_15525 == 0) {
        goto L7F; // [2944] 2977
    }
    _15527 = (_ch_27633 <= 70);
    if (_15527 == 0)
    {
        DeRef(_15527);
        _15527 = NOVALUE;
        goto L7F; // [2953] 2977
    }
    else{
        DeRef(_15527);
        _15527 = NOVALUE;
    }

    /** scanner.e:1906								d = (d * 16) + ch - ('A'- 10)*/
    if (IS_ATOM_INT(_d_27641)) {
        if (_d_27641 == (short)_d_27641){
            _15528 = _d_27641 * 16;
        }
        else{
            _15528 = NewDouble(_d_27641 * (eudouble)16);
        }
    }
    else {
        _15528 = binary_op(MULTIPLY, _d_27641, 16);
    }
    if (IS_ATOM_INT(_15528)) {
        _15529 = _15528 + _ch_27633;
        if ((object)((uintptr_t)_15529 + (uintptr_t)HIGH_BITS) >= 0){
            _15529 = NewDouble((eudouble)_15529);
        }
    }
    else {
        _15529 = binary_op(PLUS, _15528, _ch_27633);
    }
    DeRef(_15528);
    _15528 = NOVALUE;
    _15530 = 55;
    DeRef(_d_27641);
    if (IS_ATOM_INT(_15529)) {
        _d_27641 = _15529 - 55;
        if ((object)((uintptr_t)_d_27641 +(uintptr_t) HIGH_BITS) >= 0){
            _d_27641 = NewDouble((eudouble)_d_27641);
        }
    }
    else {
        _d_27641 = binary_op(MINUS, _15529, 55);
    }
    DeRef(_15529);
    _15529 = NOVALUE;
    _15530 = NOVALUE;
    goto L7C; // [2974] 2888
L7F: 

    /** scanner.e:1907							elsif ch >= 'a' and ch <= 'f' then*/
    _15532 = (_ch_27633 >= 97);
    if (_15532 == 0) {
        goto L80; // [2983] 3016
    }
    _15534 = (_ch_27633 <= 102);
    if (_15534 == 0)
    {
        DeRef(_15534);
        _15534 = NOVALUE;
        goto L80; // [2992] 3016
    }
    else{
        DeRef(_15534);
        _15534 = NOVALUE;
    }

    /** scanner.e:1908								d = (d * 16) + ch - ('a'-10)*/
    if (IS_ATOM_INT(_d_27641)) {
        if (_d_27641 == (short)_d_27641){
            _15535 = _d_27641 * 16;
        }
        else{
            _15535 = NewDouble(_d_27641 * (eudouble)16);
        }
    }
    else {
        _15535 = binary_op(MULTIPLY, _d_27641, 16);
    }
    if (IS_ATOM_INT(_15535)) {
        _15536 = _15535 + _ch_27633;
        if ((object)((uintptr_t)_15536 + (uintptr_t)HIGH_BITS) >= 0){
            _15536 = NewDouble((eudouble)_15536);
        }
    }
    else {
        _15536 = binary_op(PLUS, _15535, _ch_27633);
    }
    DeRef(_15535);
    _15535 = NOVALUE;
    _15537 = 87;
    DeRef(_d_27641);
    if (IS_ATOM_INT(_15536)) {
        _d_27641 = _15536 - 87;
        if ((object)((uintptr_t)_d_27641 +(uintptr_t) HIGH_BITS) >= 0){
            _d_27641 = NewDouble((eudouble)_d_27641);
        }
    }
    else {
        _d_27641 = binary_op(MINUS, _15536, 87);
    }
    DeRef(_15536);
    _15536 = NOVALUE;
    _15537 = NOVALUE;
    goto L7C; // [3013] 2888
L80: 

    /** scanner.e:1909							elsif ch = '_' then*/
    if (_ch_27633 != 95)
    goto L7D; // [3018] 3035
    goto L7C; // [3022] 2888

    /** scanner.e:1912								exit*/
    goto L7D; // [3027] 3035

    /** scanner.e:1914						end while*/
    goto L7C; // [3032] 2888
L7D: 
L7B: 

    /** scanner.e:1917					ungetch()*/
    _62ungetch();

    /** scanner.e:1918					if is_int and is_integer(i) then*/
    if (_is_int_27644 == 0) {
        goto L81; // [3042] 3073
    }
    Ref(_i_27636);
    _15541 = _36is_integer(_i_27636);
    if (_15541 == 0) {
        DeRef(_15541);
        _15541 = NOVALUE;
        goto L81; // [3051] 3073
    }
    else {
        if (!IS_ATOM_INT(_15541) && DBL_PTR(_15541)->dbl == 0.0){
            DeRef(_15541);
            _15541 = NOVALUE;
            goto L81; // [3051] 3073
        }
        DeRef(_15541);
        _15541 = NOVALUE;
    }
    DeRef(_15541);
    _15541 = NOVALUE;

    /** scanner.e:1919						return {ATOM, NewIntSym(i)}*/
    Ref(_i_27636);
    _15542 = _54NewIntSym(_i_27636);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 502;
    ((intptr_t *)_2)[2] = _15542;
    _15543 = MAKE_SEQ(_1);
    _15542 = NOVALUE;
    DeRef(_i_27636);
    DeRef(_yytext_27639);
    DeRef(_namespaces_27640);
    DeRef(_d_27641);
    DeRef(_tok_27643);
    DeRef(_name_27646);
    DeRef(_15284);
    _15284 = NOVALUE;
    DeRef(_15455);
    _15455 = NOVALUE;
    DeRef(_15310);
    _15310 = NOVALUE;
    DeRef(_15253);
    _15253 = NOVALUE;
    DeRef(_15414);
    _15414 = NOVALUE;
    DeRef(_15238);
    _15238 = NOVALUE;
    _15426 = NOVALUE;
    DeRef(_15260);
    _15260 = NOVALUE;
    _15275 = NOVALUE;
    _15422 = NOVALUE;
    DeRef(_15256);
    _15256 = NOVALUE;
    _15379 = NOVALUE;
    DeRef(_15381);
    _15381 = NOVALUE;
    DeRef(_15483);
    _15483 = NOVALUE;
    _15404 = NOVALUE;
    DeRef(_15506);
    _15506 = NOVALUE;
    DeRef(_15478);
    _15478 = NOVALUE;
    DeRef(_15247);
    _15247 = NOVALUE;
    DeRef(_15448);
    _15448 = NOVALUE;
    _15519 = NOVALUE;
    DeRef(_15464);
    _15464 = NOVALUE;
    DeRef(_15450);
    _15450 = NOVALUE;
    DeRef(_15416);
    _15416 = NOVALUE;
    DeRef(_15250);
    _15250 = NOVALUE;
    DeRef(_15279);
    _15279 = NOVALUE;
    DeRef(_15474);
    _15474 = NOVALUE;
    DeRef(_15487);
    _15487 = NOVALUE;
    DeRef(_15532);
    _15532 = NOVALUE;
    DeRef(_15440);
    _15440 = NOVALUE;
    DeRef(_15259);
    _15259 = NOVALUE;
    DeRef(_15488);
    _15488 = NOVALUE;
    DeRef(_15359);
    _15359 = NOVALUE;
    DeRef(_15263);
    _15263 = NOVALUE;
    DeRef(_15457);
    _15457 = NOVALUE;
    _15300 = NOVALUE;
    _15326 = NOVALUE;
    DeRef(_15366);
    _15366 = NOVALUE;
    DeRef(_15355);
    _15355 = NOVALUE;
    DeRef(_15525);
    _15525 = NOVALUE;
    DeRef(_15463);
    _15463 = NOVALUE;
    DeRef(_15408);
    _15408 = NOVALUE;
    DeRef(_15360);
    _15360 = NOVALUE;
    DeRef(_15438);
    _15438 = NOVALUE;
    DeRef(_15499);
    _15499 = NOVALUE;
    _15400 = NOVALUE;
    _15369 = NOVALUE;
    _15289 = NOVALUE;
    DeRef(_15482);
    _15482 = NOVALUE;
    _15311 = NOVALUE;
    _15493 = NOVALUE;
    DeRef(_15233);
    _15233 = NOVALUE;
    return _15543;
    goto L1; // [3070] 10
L81: 

    /** scanner.e:1921						if d <= TMAXINT_DBL then            -- d is always >= 0*/
    if (binary_op_a(GREATER, _d_27641, _36TMAXINT_DBL_21599)){
        goto L82; // [3077] 3100
    }

    /** scanner.e:1922							return {ATOM, NewIntSym(d)}*/
    Ref(_d_27641);
    _15545 = _54NewIntSym(_d_27641);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 502;
    ((intptr_t *)_2)[2] = _15545;
    _15546 = MAKE_SEQ(_1);
    _15545 = NOVALUE;
    DeRef(_i_27636);
    DeRef(_yytext_27639);
    DeRef(_namespaces_27640);
    DeRef(_d_27641);
    DeRef(_tok_27643);
    DeRef(_name_27646);
    DeRef(_15284);
    _15284 = NOVALUE;
    DeRef(_15455);
    _15455 = NOVALUE;
    DeRef(_15310);
    _15310 = NOVALUE;
    DeRef(_15253);
    _15253 = NOVALUE;
    DeRef(_15414);
    _15414 = NOVALUE;
    DeRef(_15238);
    _15238 = NOVALUE;
    _15426 = NOVALUE;
    DeRef(_15260);
    _15260 = NOVALUE;
    _15275 = NOVALUE;
    _15422 = NOVALUE;
    DeRef(_15256);
    _15256 = NOVALUE;
    _15379 = NOVALUE;
    DeRef(_15381);
    _15381 = NOVALUE;
    DeRef(_15483);
    _15483 = NOVALUE;
    _15404 = NOVALUE;
    DeRef(_15506);
    _15506 = NOVALUE;
    DeRef(_15478);
    _15478 = NOVALUE;
    DeRef(_15247);
    _15247 = NOVALUE;
    DeRef(_15448);
    _15448 = NOVALUE;
    _15519 = NOVALUE;
    DeRef(_15464);
    _15464 = NOVALUE;
    DeRef(_15450);
    _15450 = NOVALUE;
    DeRef(_15416);
    _15416 = NOVALUE;
    DeRef(_15250);
    _15250 = NOVALUE;
    DeRef(_15279);
    _15279 = NOVALUE;
    DeRef(_15474);
    _15474 = NOVALUE;
    DeRef(_15487);
    _15487 = NOVALUE;
    DeRef(_15532);
    _15532 = NOVALUE;
    DeRef(_15440);
    _15440 = NOVALUE;
    DeRef(_15543);
    _15543 = NOVALUE;
    DeRef(_15259);
    _15259 = NOVALUE;
    DeRef(_15488);
    _15488 = NOVALUE;
    DeRef(_15359);
    _15359 = NOVALUE;
    DeRef(_15263);
    _15263 = NOVALUE;
    DeRef(_15457);
    _15457 = NOVALUE;
    _15300 = NOVALUE;
    _15326 = NOVALUE;
    DeRef(_15366);
    _15366 = NOVALUE;
    DeRef(_15355);
    _15355 = NOVALUE;
    DeRef(_15525);
    _15525 = NOVALUE;
    DeRef(_15463);
    _15463 = NOVALUE;
    DeRef(_15408);
    _15408 = NOVALUE;
    DeRef(_15360);
    _15360 = NOVALUE;
    DeRef(_15438);
    _15438 = NOVALUE;
    DeRef(_15499);
    _15499 = NOVALUE;
    _15400 = NOVALUE;
    _15369 = NOVALUE;
    _15289 = NOVALUE;
    DeRef(_15482);
    _15482 = NOVALUE;
    _15311 = NOVALUE;
    _15493 = NOVALUE;
    DeRef(_15233);
    _15233 = NOVALUE;
    return _15546;
    goto L1; // [3097] 10
L82: 

    /** scanner.e:1924							return {ATOM, NewDoubleSym(d)}*/
    Ref(_d_27641);
    _15547 = _54NewDoubleSym(_d_27641);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 502;
    ((intptr_t *)_2)[2] = _15547;
    _15548 = MAKE_SEQ(_1);
    _15547 = NOVALUE;
    DeRef(_i_27636);
    DeRef(_yytext_27639);
    DeRef(_namespaces_27640);
    DeRef(_d_27641);
    DeRef(_tok_27643);
    DeRef(_name_27646);
    DeRef(_15284);
    _15284 = NOVALUE;
    DeRef(_15455);
    _15455 = NOVALUE;
    DeRef(_15310);
    _15310 = NOVALUE;
    DeRef(_15253);
    _15253 = NOVALUE;
    DeRef(_15414);
    _15414 = NOVALUE;
    DeRef(_15238);
    _15238 = NOVALUE;
    _15426 = NOVALUE;
    DeRef(_15260);
    _15260 = NOVALUE;
    _15275 = NOVALUE;
    _15422 = NOVALUE;
    DeRef(_15256);
    _15256 = NOVALUE;
    _15379 = NOVALUE;
    DeRef(_15381);
    _15381 = NOVALUE;
    DeRef(_15483);
    _15483 = NOVALUE;
    _15404 = NOVALUE;
    DeRef(_15506);
    _15506 = NOVALUE;
    DeRef(_15478);
    _15478 = NOVALUE;
    DeRef(_15247);
    _15247 = NOVALUE;
    DeRef(_15448);
    _15448 = NOVALUE;
    _15519 = NOVALUE;
    DeRef(_15464);
    _15464 = NOVALUE;
    DeRef(_15450);
    _15450 = NOVALUE;
    DeRef(_15416);
    _15416 = NOVALUE;
    DeRef(_15250);
    _15250 = NOVALUE;
    DeRef(_15279);
    _15279 = NOVALUE;
    DeRef(_15474);
    _15474 = NOVALUE;
    DeRef(_15546);
    _15546 = NOVALUE;
    DeRef(_15487);
    _15487 = NOVALUE;
    DeRef(_15532);
    _15532 = NOVALUE;
    DeRef(_15440);
    _15440 = NOVALUE;
    DeRef(_15543);
    _15543 = NOVALUE;
    DeRef(_15259);
    _15259 = NOVALUE;
    DeRef(_15488);
    _15488 = NOVALUE;
    DeRef(_15359);
    _15359 = NOVALUE;
    DeRef(_15263);
    _15263 = NOVALUE;
    DeRef(_15457);
    _15457 = NOVALUE;
    _15300 = NOVALUE;
    _15326 = NOVALUE;
    DeRef(_15366);
    _15366 = NOVALUE;
    DeRef(_15355);
    _15355 = NOVALUE;
    DeRef(_15525);
    _15525 = NOVALUE;
    DeRef(_15463);
    _15463 = NOVALUE;
    DeRef(_15408);
    _15408 = NOVALUE;
    DeRef(_15360);
    _15360 = NOVALUE;
    DeRef(_15438);
    _15438 = NOVALUE;
    DeRef(_15499);
    _15499 = NOVALUE;
    _15400 = NOVALUE;
    _15369 = NOVALUE;
    _15289 = NOVALUE;
    DeRef(_15482);
    _15482 = NOVALUE;
    _15311 = NOVALUE;
    _15493 = NOVALUE;
    DeRef(_15233);
    _15233 = NOVALUE;
    return _15548;
    goto L1; // [3119] 10
L72: 

    /** scanner.e:1929			elsif class = res:MULTIPLY then*/
    if (_class_27645 != 13)
    goto L83; // [3124] 3174

    /** scanner.e:1930				ch = getch()*/
    _ch_27633 = _62getch();
    if (!IS_ATOM_INT(_ch_27633)) {
        _1 = (object)(DBL_PTR(_ch_27633)->dbl);
        DeRefDS(_ch_27633);
        _ch_27633 = _1;
    }

    /** scanner.e:1931				if ch = '=' then*/
    if (_ch_27633 != 61)
    goto L84; // [3137] 3156

    /** scanner.e:1932					return {MULTIPLY_EQUALS, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 517;
    ((intptr_t *)_2)[2] = 0;
    _15552 = MAKE_SEQ(_1);
    DeRef(_i_27636);
    DeRef(_yytext_27639);
    DeRef(_namespaces_27640);
    DeRef(_d_27641);
    DeRef(_tok_27643);
    DeRef(_name_27646);
    DeRef(_15284);
    _15284 = NOVALUE;
    DeRef(_15455);
    _15455 = NOVALUE;
    DeRef(_15310);
    _15310 = NOVALUE;
    DeRef(_15253);
    _15253 = NOVALUE;
    DeRef(_15414);
    _15414 = NOVALUE;
    DeRef(_15238);
    _15238 = NOVALUE;
    _15426 = NOVALUE;
    DeRef(_15260);
    _15260 = NOVALUE;
    _15275 = NOVALUE;
    _15422 = NOVALUE;
    DeRef(_15256);
    _15256 = NOVALUE;
    _15379 = NOVALUE;
    DeRef(_15381);
    _15381 = NOVALUE;
    DeRef(_15483);
    _15483 = NOVALUE;
    _15404 = NOVALUE;
    DeRef(_15506);
    _15506 = NOVALUE;
    DeRef(_15478);
    _15478 = NOVALUE;
    DeRef(_15247);
    _15247 = NOVALUE;
    DeRef(_15448);
    _15448 = NOVALUE;
    _15519 = NOVALUE;
    DeRef(_15464);
    _15464 = NOVALUE;
    DeRef(_15450);
    _15450 = NOVALUE;
    DeRef(_15548);
    _15548 = NOVALUE;
    DeRef(_15416);
    _15416 = NOVALUE;
    DeRef(_15250);
    _15250 = NOVALUE;
    DeRef(_15279);
    _15279 = NOVALUE;
    DeRef(_15474);
    _15474 = NOVALUE;
    DeRef(_15546);
    _15546 = NOVALUE;
    DeRef(_15487);
    _15487 = NOVALUE;
    DeRef(_15532);
    _15532 = NOVALUE;
    DeRef(_15440);
    _15440 = NOVALUE;
    DeRef(_15543);
    _15543 = NOVALUE;
    DeRef(_15259);
    _15259 = NOVALUE;
    DeRef(_15488);
    _15488 = NOVALUE;
    DeRef(_15359);
    _15359 = NOVALUE;
    DeRef(_15263);
    _15263 = NOVALUE;
    DeRef(_15457);
    _15457 = NOVALUE;
    _15300 = NOVALUE;
    _15326 = NOVALUE;
    DeRef(_15366);
    _15366 = NOVALUE;
    DeRef(_15355);
    _15355 = NOVALUE;
    DeRef(_15525);
    _15525 = NOVALUE;
    DeRef(_15463);
    _15463 = NOVALUE;
    DeRef(_15408);
    _15408 = NOVALUE;
    DeRef(_15360);
    _15360 = NOVALUE;
    DeRef(_15438);
    _15438 = NOVALUE;
    DeRef(_15499);
    _15499 = NOVALUE;
    _15400 = NOVALUE;
    _15369 = NOVALUE;
    _15289 = NOVALUE;
    DeRef(_15482);
    _15482 = NOVALUE;
    _15311 = NOVALUE;
    _15493 = NOVALUE;
    DeRef(_15233);
    _15233 = NOVALUE;
    return _15552;
    goto L1; // [3153] 10
L84: 

    /** scanner.e:1934					ungetch()*/
    _62ungetch();

    /** scanner.e:1935					return {res:MULTIPLY, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 13;
    ((intptr_t *)_2)[2] = 0;
    _15553 = MAKE_SEQ(_1);
    DeRef(_i_27636);
    DeRef(_yytext_27639);
    DeRef(_namespaces_27640);
    DeRef(_d_27641);
    DeRef(_tok_27643);
    DeRef(_name_27646);
    DeRef(_15284);
    _15284 = NOVALUE;
    DeRef(_15455);
    _15455 = NOVALUE;
    DeRef(_15310);
    _15310 = NOVALUE;
    DeRef(_15253);
    _15253 = NOVALUE;
    DeRef(_15414);
    _15414 = NOVALUE;
    DeRef(_15238);
    _15238 = NOVALUE;
    _15426 = NOVALUE;
    DeRef(_15260);
    _15260 = NOVALUE;
    _15275 = NOVALUE;
    _15422 = NOVALUE;
    DeRef(_15256);
    _15256 = NOVALUE;
    _15379 = NOVALUE;
    DeRef(_15381);
    _15381 = NOVALUE;
    DeRef(_15483);
    _15483 = NOVALUE;
    _15404 = NOVALUE;
    DeRef(_15506);
    _15506 = NOVALUE;
    DeRef(_15552);
    _15552 = NOVALUE;
    DeRef(_15478);
    _15478 = NOVALUE;
    DeRef(_15247);
    _15247 = NOVALUE;
    DeRef(_15448);
    _15448 = NOVALUE;
    _15519 = NOVALUE;
    DeRef(_15464);
    _15464 = NOVALUE;
    DeRef(_15450);
    _15450 = NOVALUE;
    DeRef(_15548);
    _15548 = NOVALUE;
    DeRef(_15416);
    _15416 = NOVALUE;
    DeRef(_15250);
    _15250 = NOVALUE;
    DeRef(_15279);
    _15279 = NOVALUE;
    DeRef(_15474);
    _15474 = NOVALUE;
    DeRef(_15546);
    _15546 = NOVALUE;
    DeRef(_15487);
    _15487 = NOVALUE;
    DeRef(_15532);
    _15532 = NOVALUE;
    DeRef(_15440);
    _15440 = NOVALUE;
    DeRef(_15543);
    _15543 = NOVALUE;
    DeRef(_15259);
    _15259 = NOVALUE;
    DeRef(_15488);
    _15488 = NOVALUE;
    DeRef(_15359);
    _15359 = NOVALUE;
    DeRef(_15263);
    _15263 = NOVALUE;
    DeRef(_15457);
    _15457 = NOVALUE;
    _15300 = NOVALUE;
    _15326 = NOVALUE;
    DeRef(_15366);
    _15366 = NOVALUE;
    DeRef(_15355);
    _15355 = NOVALUE;
    DeRef(_15525);
    _15525 = NOVALUE;
    DeRef(_15463);
    _15463 = NOVALUE;
    DeRef(_15408);
    _15408 = NOVALUE;
    DeRef(_15360);
    _15360 = NOVALUE;
    DeRef(_15438);
    _15438 = NOVALUE;
    DeRef(_15499);
    _15499 = NOVALUE;
    _15400 = NOVALUE;
    _15369 = NOVALUE;
    _15289 = NOVALUE;
    DeRef(_15482);
    _15482 = NOVALUE;
    _15311 = NOVALUE;
    _15493 = NOVALUE;
    DeRef(_15233);
    _15233 = NOVALUE;
    return _15553;
    goto L1; // [3171] 10
L83: 

    /** scanner.e:1938			elsif class = res:DIVIDE then*/
    if (_class_27645 != 14)
    goto L85; // [3176] 3380

    /** scanner.e:1939				ch = getch()*/
    _ch_27633 = _62getch();
    if (!IS_ATOM_INT(_ch_27633)) {
        _1 = (object)(DBL_PTR(_ch_27633)->dbl);
        DeRefDS(_ch_27633);
        _ch_27633 = _1;
    }

    /** scanner.e:1940				if ch = '=' then*/
    if (_ch_27633 != 61)
    goto L86; // [3189] 3208

    /** scanner.e:1941					return {DIVIDE_EQUALS, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 518;
    ((intptr_t *)_2)[2] = 0;
    _15557 = MAKE_SEQ(_1);
    DeRef(_i_27636);
    DeRef(_yytext_27639);
    DeRef(_namespaces_27640);
    DeRef(_d_27641);
    DeRef(_tok_27643);
    DeRef(_name_27646);
    DeRef(_15284);
    _15284 = NOVALUE;
    DeRef(_15455);
    _15455 = NOVALUE;
    DeRef(_15310);
    _15310 = NOVALUE;
    DeRef(_15253);
    _15253 = NOVALUE;
    DeRef(_15414);
    _15414 = NOVALUE;
    DeRef(_15238);
    _15238 = NOVALUE;
    _15426 = NOVALUE;
    DeRef(_15260);
    _15260 = NOVALUE;
    _15275 = NOVALUE;
    _15422 = NOVALUE;
    DeRef(_15256);
    _15256 = NOVALUE;
    _15379 = NOVALUE;
    DeRef(_15381);
    _15381 = NOVALUE;
    DeRef(_15483);
    _15483 = NOVALUE;
    _15404 = NOVALUE;
    DeRef(_15506);
    _15506 = NOVALUE;
    DeRef(_15552);
    _15552 = NOVALUE;
    DeRef(_15478);
    _15478 = NOVALUE;
    DeRef(_15247);
    _15247 = NOVALUE;
    DeRef(_15448);
    _15448 = NOVALUE;
    _15519 = NOVALUE;
    DeRef(_15464);
    _15464 = NOVALUE;
    DeRef(_15450);
    _15450 = NOVALUE;
    DeRef(_15548);
    _15548 = NOVALUE;
    DeRef(_15416);
    _15416 = NOVALUE;
    DeRef(_15250);
    _15250 = NOVALUE;
    DeRef(_15279);
    _15279 = NOVALUE;
    DeRef(_15553);
    _15553 = NOVALUE;
    DeRef(_15474);
    _15474 = NOVALUE;
    DeRef(_15546);
    _15546 = NOVALUE;
    DeRef(_15487);
    _15487 = NOVALUE;
    DeRef(_15532);
    _15532 = NOVALUE;
    DeRef(_15440);
    _15440 = NOVALUE;
    DeRef(_15543);
    _15543 = NOVALUE;
    DeRef(_15259);
    _15259 = NOVALUE;
    DeRef(_15488);
    _15488 = NOVALUE;
    DeRef(_15359);
    _15359 = NOVALUE;
    DeRef(_15263);
    _15263 = NOVALUE;
    DeRef(_15457);
    _15457 = NOVALUE;
    _15300 = NOVALUE;
    _15326 = NOVALUE;
    DeRef(_15366);
    _15366 = NOVALUE;
    DeRef(_15355);
    _15355 = NOVALUE;
    DeRef(_15525);
    _15525 = NOVALUE;
    DeRef(_15463);
    _15463 = NOVALUE;
    DeRef(_15408);
    _15408 = NOVALUE;
    DeRef(_15360);
    _15360 = NOVALUE;
    DeRef(_15438);
    _15438 = NOVALUE;
    DeRef(_15499);
    _15499 = NOVALUE;
    _15400 = NOVALUE;
    _15369 = NOVALUE;
    _15289 = NOVALUE;
    DeRef(_15482);
    _15482 = NOVALUE;
    _15311 = NOVALUE;
    _15493 = NOVALUE;
    DeRef(_15233);
    _15233 = NOVALUE;
    return _15557;
    goto L1; // [3205] 10
L86: 

    /** scanner.e:1942				elsif ch = '*' then*/
    if (_ch_27633 != 42)
    goto L87; // [3210] 3362

    /** scanner.e:1944					cline = line_number*/
    _cline_27638 = _36line_number_21768;

    /** scanner.e:1945					integer cnest = 1*/
    _cnest_28306 = 1;

    /** scanner.e:1946					while cnest > 0 do*/
L88: 
    if (_cnest_28306 <= 0)
    goto L89; // [3233] 3341

    /** scanner.e:1947						ch = getch()*/
    _ch_27633 = _62getch();
    if (!IS_ATOM_INT(_ch_27633)) {
        _1 = (object)(DBL_PTR(_ch_27633)->dbl);
        DeRefDS(_ch_27633);
        _ch_27633 = _1;
    }

    /** scanner.e:1948						switch ch do*/
    _0 = _ch_27633;
    switch ( _0 ){ 

        /** scanner.e:1949							case  END_OF_FILE_CHAR then*/
        case 26:

        /** scanner.e:1950								exit*/
        goto L89; // [3257] 3341
        goto L88; // [3259] 3233

        /** scanner.e:1952							case '\n' then*/
        case 10:

        /** scanner.e:1953								read_line()*/
        _62read_line();
        goto L88; // [3269] 3233

        /** scanner.e:1955							case '*' then*/
        case 42:

        /** scanner.e:1956								ch = getch()*/
        _ch_27633 = _62getch();
        if (!IS_ATOM_INT(_ch_27633)) {
            _1 = (object)(DBL_PTR(_ch_27633)->dbl);
            DeRefDS(_ch_27633);
            _ch_27633 = _1;
        }

        /** scanner.e:1957								if ch = '/' then*/
        if (_ch_27633 != 47)
        goto L8A; // [3284] 3297

        /** scanner.e:1958									cnest -= 1*/
        _cnest_28306 = _cnest_28306 - 1;
        goto L88; // [3294] 3233
L8A: 

        /** scanner.e:1960									ungetch()*/
        _62ungetch();
        goto L88; // [3302] 3233

        /** scanner.e:1963							case '/' then*/
        case 47:

        /** scanner.e:1964								ch = getch()*/
        _ch_27633 = _62getch();
        if (!IS_ATOM_INT(_ch_27633)) {
            _1 = (object)(DBL_PTR(_ch_27633)->dbl);
            DeRefDS(_ch_27633);
            _ch_27633 = _1;
        }

        /** scanner.e:1965								if ch = '*' then*/
        if (_ch_27633 != 42)
        goto L8B; // [3317] 3330

        /** scanner.e:1966									cnest += 1*/
        _cnest_28306 = _cnest_28306 + 1;
        goto L8C; // [3327] 3335
L8B: 

        /** scanner.e:1968									ungetch()*/
        _62ungetch();
L8C: 
    ;}
    /** scanner.e:1972					end while*/
    goto L88; // [3338] 3233
L89: 

    /** scanner.e:1974					if cnest > 0 then*/
    if (_cnest_28306 <= 0)
    goto L8D; // [3343] 3357

    /** scanner.e:1975						CompileErr(BLOCK_COMMENT_FROM_LINE_1_NOT_TERMINATED, cline)*/
    _50CompileErr(42, _cline_27638, 0);
L8D: 
    goto L1; // [3359] 10
L87: 

    /** scanner.e:1978					ungetch()*/
    _62ungetch();

    /** scanner.e:1979					return {res:DIVIDE, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 14;
    ((intptr_t *)_2)[2] = 0;
    _15570 = MAKE_SEQ(_1);
    DeRef(_i_27636);
    DeRef(_yytext_27639);
    DeRef(_namespaces_27640);
    DeRef(_d_27641);
    DeRef(_tok_27643);
    DeRef(_name_27646);
    DeRef(_15284);
    _15284 = NOVALUE;
    DeRef(_15455);
    _15455 = NOVALUE;
    DeRef(_15310);
    _15310 = NOVALUE;
    DeRef(_15253);
    _15253 = NOVALUE;
    DeRef(_15414);
    _15414 = NOVALUE;
    DeRef(_15238);
    _15238 = NOVALUE;
    _15426 = NOVALUE;
    DeRef(_15260);
    _15260 = NOVALUE;
    _15275 = NOVALUE;
    _15422 = NOVALUE;
    DeRef(_15256);
    _15256 = NOVALUE;
    _15379 = NOVALUE;
    DeRef(_15381);
    _15381 = NOVALUE;
    DeRef(_15483);
    _15483 = NOVALUE;
    _15404 = NOVALUE;
    DeRef(_15506);
    _15506 = NOVALUE;
    DeRef(_15552);
    _15552 = NOVALUE;
    DeRef(_15478);
    _15478 = NOVALUE;
    DeRef(_15247);
    _15247 = NOVALUE;
    DeRef(_15448);
    _15448 = NOVALUE;
    _15519 = NOVALUE;
    DeRef(_15464);
    _15464 = NOVALUE;
    DeRef(_15450);
    _15450 = NOVALUE;
    DeRef(_15557);
    _15557 = NOVALUE;
    DeRef(_15548);
    _15548 = NOVALUE;
    DeRef(_15416);
    _15416 = NOVALUE;
    DeRef(_15250);
    _15250 = NOVALUE;
    DeRef(_15279);
    _15279 = NOVALUE;
    DeRef(_15553);
    _15553 = NOVALUE;
    DeRef(_15474);
    _15474 = NOVALUE;
    DeRef(_15546);
    _15546 = NOVALUE;
    DeRef(_15487);
    _15487 = NOVALUE;
    DeRef(_15532);
    _15532 = NOVALUE;
    DeRef(_15440);
    _15440 = NOVALUE;
    DeRef(_15543);
    _15543 = NOVALUE;
    DeRef(_15259);
    _15259 = NOVALUE;
    DeRef(_15488);
    _15488 = NOVALUE;
    DeRef(_15359);
    _15359 = NOVALUE;
    DeRef(_15263);
    _15263 = NOVALUE;
    DeRef(_15457);
    _15457 = NOVALUE;
    _15300 = NOVALUE;
    _15326 = NOVALUE;
    DeRef(_15366);
    _15366 = NOVALUE;
    DeRef(_15355);
    _15355 = NOVALUE;
    DeRef(_15525);
    _15525 = NOVALUE;
    DeRef(_15463);
    _15463 = NOVALUE;
    DeRef(_15408);
    _15408 = NOVALUE;
    DeRef(_15360);
    _15360 = NOVALUE;
    DeRef(_15438);
    _15438 = NOVALUE;
    DeRef(_15499);
    _15499 = NOVALUE;
    _15400 = NOVALUE;
    _15369 = NOVALUE;
    _15289 = NOVALUE;
    DeRef(_15482);
    _15482 = NOVALUE;
    _15311 = NOVALUE;
    _15493 = NOVALUE;
    DeRef(_15233);
    _15233 = NOVALUE;
    return _15570;
    goto L1; // [3377] 10
L85: 

    /** scanner.e:1981			elsif class = SINGLE_QUOTE then*/
    if (_class_27645 != -5)
    goto L8E; // [3384] 3534

    /** scanner.e:1982				atom ach = getch()*/
    _0 = _ach_28336;
    _ach_28336 = _62getch();
    DeRef(_0);

    /** scanner.e:1983				if ach = '\\' then*/
    if (binary_op_a(NOTEQ, _ach_28336, 92)){
        goto L8F; // [3395] 3408
    }

    /** scanner.e:1984					ach = EscapeChar('\'')*/
    _0 = _ach_28336;
    _ach_28336 = _62EscapeChar(39);
    DeRef(_0);
    goto L90; // [3405] 3465
L8F: 

    /** scanner.e:1985				elsif ach = '\t' then*/
    if (binary_op_a(NOTEQ, _ach_28336, 9)){
        goto L91; // [3410] 3426
    }

    /** scanner.e:1986					CompileErr(MSG_TAB_CHARACTER_FOUND_IN_STRING__USE_T_INSTEAD)*/
    RefDS(_22190);
    _50CompileErr(145, _22190, 0);
    goto L90; // [3423] 3465
L91: 

    /** scanner.e:1987				elsif ach = '\'' then*/
    if (binary_op_a(NOTEQ, _ach_28336, 39)){
        goto L92; // [3428] 3444
    }

    /** scanner.e:1988					CompileErr(SINGLEQUOTE_CHARACTER_IS_EMPTY)*/
    RefDS(_22190);
    _50CompileErr(137, _22190, 0);
    goto L90; // [3441] 3465
L92: 

    /** scanner.e:1989				elsif ach = '\n' then*/
    if (binary_op_a(NOTEQ, _ach_28336, 10)){
        goto L93; // [3446] 3464
    }

    /** scanner.e:1990					CompileErr(EXPECTED_1_NOT_2, {"character", "end of line"})*/
    RefDS(_15579);
    RefDS(_15578);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _15578;
    ((intptr_t *)_2)[2] = _15579;
    _15580 = MAKE_SEQ(_1);
    _50CompileErr(68, _15580, 0);
    _15580 = NOVALUE;
L93: 
L90: 

    /** scanner.e:1992				if getch() != '\'' then*/
    _15581 = _62getch();
    if (binary_op_a(EQUALS, _15581, 39)){
        DeRef(_15581);
        _15581 = NOVALUE;
        goto L94; // [3470] 3484
    }
    DeRef(_15581);
    _15581 = NOVALUE;

    /** scanner.e:1993					CompileErr(CHARACTER_CONSTANT_IS_MISSING_A_CLOSING)*/
    RefDS(_22190);
    _50CompileErr(56, _22190, 0);
L94: 

    /** scanner.e:1995				if is_integer(ach) then*/
    Ref(_ach_28336);
    _15583 = _36is_integer(_ach_28336);
    if (_15583 == 0) {
        DeRef(_15583);
        _15583 = NOVALUE;
        goto L95; // [3490] 3512
    }
    else {
        if (!IS_ATOM_INT(_15583) && DBL_PTR(_15583)->dbl == 0.0){
            DeRef(_15583);
            _15583 = NOVALUE;
            goto L95; // [3490] 3512
        }
        DeRef(_15583);
        _15583 = NOVALUE;
    }
    DeRef(_15583);
    _15583 = NOVALUE;

    /** scanner.e:1996					return {ATOM, NewIntSym(ach)}*/
    Ref(_ach_28336);
    _15584 = _54NewIntSym(_ach_28336);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 502;
    ((intptr_t *)_2)[2] = _15584;
    _15585 = MAKE_SEQ(_1);
    _15584 = NOVALUE;
    DeRef(_ach_28336);
    DeRef(_i_27636);
    DeRef(_yytext_27639);
    DeRef(_namespaces_27640);
    DeRef(_d_27641);
    DeRef(_tok_27643);
    DeRef(_name_27646);
    DeRef(_15284);
    _15284 = NOVALUE;
    DeRef(_15455);
    _15455 = NOVALUE;
    DeRef(_15310);
    _15310 = NOVALUE;
    DeRef(_15253);
    _15253 = NOVALUE;
    DeRef(_15414);
    _15414 = NOVALUE;
    DeRef(_15238);
    _15238 = NOVALUE;
    _15426 = NOVALUE;
    DeRef(_15260);
    _15260 = NOVALUE;
    _15275 = NOVALUE;
    _15422 = NOVALUE;
    DeRef(_15256);
    _15256 = NOVALUE;
    _15379 = NOVALUE;
    DeRef(_15381);
    _15381 = NOVALUE;
    DeRef(_15483);
    _15483 = NOVALUE;
    _15404 = NOVALUE;
    DeRef(_15506);
    _15506 = NOVALUE;
    DeRef(_15552);
    _15552 = NOVALUE;
    DeRef(_15478);
    _15478 = NOVALUE;
    DeRef(_15247);
    _15247 = NOVALUE;
    DeRef(_15448);
    _15448 = NOVALUE;
    _15519 = NOVALUE;
    DeRef(_15464);
    _15464 = NOVALUE;
    DeRef(_15450);
    _15450 = NOVALUE;
    DeRef(_15557);
    _15557 = NOVALUE;
    DeRef(_15548);
    _15548 = NOVALUE;
    DeRef(_15416);
    _15416 = NOVALUE;
    DeRef(_15250);
    _15250 = NOVALUE;
    DeRef(_15279);
    _15279 = NOVALUE;
    DeRef(_15553);
    _15553 = NOVALUE;
    DeRef(_15474);
    _15474 = NOVALUE;
    DeRef(_15546);
    _15546 = NOVALUE;
    DeRef(_15487);
    _15487 = NOVALUE;
    DeRef(_15532);
    _15532 = NOVALUE;
    DeRef(_15440);
    _15440 = NOVALUE;
    DeRef(_15543);
    _15543 = NOVALUE;
    DeRef(_15259);
    _15259 = NOVALUE;
    DeRef(_15488);
    _15488 = NOVALUE;
    DeRef(_15359);
    _15359 = NOVALUE;
    DeRef(_15570);
    _15570 = NOVALUE;
    DeRef(_15263);
    _15263 = NOVALUE;
    DeRef(_15457);
    _15457 = NOVALUE;
    _15300 = NOVALUE;
    _15326 = NOVALUE;
    DeRef(_15366);
    _15366 = NOVALUE;
    DeRef(_15355);
    _15355 = NOVALUE;
    DeRef(_15525);
    _15525 = NOVALUE;
    DeRef(_15463);
    _15463 = NOVALUE;
    DeRef(_15408);
    _15408 = NOVALUE;
    DeRef(_15360);
    _15360 = NOVALUE;
    DeRef(_15438);
    _15438 = NOVALUE;
    DeRef(_15499);
    _15499 = NOVALUE;
    _15400 = NOVALUE;
    _15369 = NOVALUE;
    _15289 = NOVALUE;
    DeRef(_15482);
    _15482 = NOVALUE;
    _15311 = NOVALUE;
    _15493 = NOVALUE;
    DeRef(_15233);
    _15233 = NOVALUE;
    return _15585;
    goto L96; // [3509] 3529
L95: 

    /** scanner.e:1998					return {ATOM, NewDoubleSym(ach)}*/
    Ref(_ach_28336);
    _15586 = _54NewDoubleSym(_ach_28336);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 502;
    ((intptr_t *)_2)[2] = _15586;
    _15587 = MAKE_SEQ(_1);
    _15586 = NOVALUE;
    DeRef(_ach_28336);
    DeRef(_i_27636);
    DeRef(_yytext_27639);
    DeRef(_namespaces_27640);
    DeRef(_d_27641);
    DeRef(_tok_27643);
    DeRef(_name_27646);
    DeRef(_15284);
    _15284 = NOVALUE;
    DeRef(_15455);
    _15455 = NOVALUE;
    DeRef(_15310);
    _15310 = NOVALUE;
    DeRef(_15253);
    _15253 = NOVALUE;
    DeRef(_15414);
    _15414 = NOVALUE;
    DeRef(_15238);
    _15238 = NOVALUE;
    _15426 = NOVALUE;
    DeRef(_15260);
    _15260 = NOVALUE;
    _15275 = NOVALUE;
    _15422 = NOVALUE;
    DeRef(_15256);
    _15256 = NOVALUE;
    _15379 = NOVALUE;
    DeRef(_15381);
    _15381 = NOVALUE;
    DeRef(_15483);
    _15483 = NOVALUE;
    _15404 = NOVALUE;
    DeRef(_15506);
    _15506 = NOVALUE;
    DeRef(_15552);
    _15552 = NOVALUE;
    DeRef(_15478);
    _15478 = NOVALUE;
    DeRef(_15247);
    _15247 = NOVALUE;
    DeRef(_15448);
    _15448 = NOVALUE;
    _15519 = NOVALUE;
    DeRef(_15464);
    _15464 = NOVALUE;
    DeRef(_15450);
    _15450 = NOVALUE;
    DeRef(_15557);
    _15557 = NOVALUE;
    DeRef(_15548);
    _15548 = NOVALUE;
    DeRef(_15416);
    _15416 = NOVALUE;
    DeRef(_15250);
    _15250 = NOVALUE;
    DeRef(_15279);
    _15279 = NOVALUE;
    DeRef(_15553);
    _15553 = NOVALUE;
    DeRef(_15474);
    _15474 = NOVALUE;
    DeRef(_15546);
    _15546 = NOVALUE;
    DeRef(_15487);
    _15487 = NOVALUE;
    DeRef(_15532);
    _15532 = NOVALUE;
    DeRef(_15440);
    _15440 = NOVALUE;
    DeRef(_15543);
    _15543 = NOVALUE;
    DeRef(_15259);
    _15259 = NOVALUE;
    DeRef(_15488);
    _15488 = NOVALUE;
    DeRef(_15359);
    _15359 = NOVALUE;
    DeRef(_15585);
    _15585 = NOVALUE;
    DeRef(_15570);
    _15570 = NOVALUE;
    DeRef(_15263);
    _15263 = NOVALUE;
    DeRef(_15457);
    _15457 = NOVALUE;
    _15300 = NOVALUE;
    _15326 = NOVALUE;
    DeRef(_15366);
    _15366 = NOVALUE;
    DeRef(_15355);
    _15355 = NOVALUE;
    DeRef(_15525);
    _15525 = NOVALUE;
    DeRef(_15463);
    _15463 = NOVALUE;
    DeRef(_15408);
    _15408 = NOVALUE;
    DeRef(_15360);
    _15360 = NOVALUE;
    DeRef(_15438);
    _15438 = NOVALUE;
    DeRef(_15499);
    _15499 = NOVALUE;
    _15400 = NOVALUE;
    _15369 = NOVALUE;
    _15289 = NOVALUE;
    DeRef(_15482);
    _15482 = NOVALUE;
    _15311 = NOVALUE;
    _15493 = NOVALUE;
    DeRef(_15233);
    _15233 = NOVALUE;
    return _15587;
L96: 
    DeRef(_ach_28336);
    _ach_28336 = NOVALUE;
    goto L1; // [3531] 10
L8E: 

    /** scanner.e:2001			elsif class = LESS then*/
    if (_class_27645 != 1)
    goto L97; // [3538] 3586

    /** scanner.e:2002				if getch() = '=' then*/
    _15589 = _62getch();
    if (binary_op_a(NOTEQ, _15589, 61)){
        DeRef(_15589);
        _15589 = NOVALUE;
        goto L98; // [3547] 3566
    }
    DeRef(_15589);
    _15589 = NOVALUE;

    /** scanner.e:2003					return {LESSEQ, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 5;
    ((intptr_t *)_2)[2] = 0;
    _15591 = MAKE_SEQ(_1);
    DeRef(_i_27636);
    DeRef(_yytext_27639);
    DeRef(_namespaces_27640);
    DeRef(_d_27641);
    DeRef(_tok_27643);
    DeRef(_name_27646);
    DeRef(_15284);
    _15284 = NOVALUE;
    DeRef(_15455);
    _15455 = NOVALUE;
    DeRef(_15310);
    _15310 = NOVALUE;
    DeRef(_15253);
    _15253 = NOVALUE;
    DeRef(_15414);
    _15414 = NOVALUE;
    DeRef(_15238);
    _15238 = NOVALUE;
    _15426 = NOVALUE;
    DeRef(_15260);
    _15260 = NOVALUE;
    _15275 = NOVALUE;
    _15422 = NOVALUE;
    DeRef(_15256);
    _15256 = NOVALUE;
    _15379 = NOVALUE;
    DeRef(_15587);
    _15587 = NOVALUE;
    DeRef(_15381);
    _15381 = NOVALUE;
    DeRef(_15483);
    _15483 = NOVALUE;
    _15404 = NOVALUE;
    DeRef(_15506);
    _15506 = NOVALUE;
    DeRef(_15552);
    _15552 = NOVALUE;
    DeRef(_15478);
    _15478 = NOVALUE;
    DeRef(_15247);
    _15247 = NOVALUE;
    DeRef(_15448);
    _15448 = NOVALUE;
    _15519 = NOVALUE;
    DeRef(_15464);
    _15464 = NOVALUE;
    DeRef(_15450);
    _15450 = NOVALUE;
    DeRef(_15557);
    _15557 = NOVALUE;
    DeRef(_15548);
    _15548 = NOVALUE;
    DeRef(_15416);
    _15416 = NOVALUE;
    DeRef(_15250);
    _15250 = NOVALUE;
    DeRef(_15279);
    _15279 = NOVALUE;
    DeRef(_15553);
    _15553 = NOVALUE;
    DeRef(_15474);
    _15474 = NOVALUE;
    DeRef(_15546);
    _15546 = NOVALUE;
    DeRef(_15487);
    _15487 = NOVALUE;
    DeRef(_15532);
    _15532 = NOVALUE;
    DeRef(_15440);
    _15440 = NOVALUE;
    DeRef(_15543);
    _15543 = NOVALUE;
    DeRef(_15259);
    _15259 = NOVALUE;
    DeRef(_15488);
    _15488 = NOVALUE;
    DeRef(_15359);
    _15359 = NOVALUE;
    DeRef(_15585);
    _15585 = NOVALUE;
    DeRef(_15570);
    _15570 = NOVALUE;
    DeRef(_15263);
    _15263 = NOVALUE;
    DeRef(_15457);
    _15457 = NOVALUE;
    _15300 = NOVALUE;
    _15326 = NOVALUE;
    DeRef(_15366);
    _15366 = NOVALUE;
    DeRef(_15355);
    _15355 = NOVALUE;
    DeRef(_15525);
    _15525 = NOVALUE;
    DeRef(_15463);
    _15463 = NOVALUE;
    DeRef(_15408);
    _15408 = NOVALUE;
    DeRef(_15360);
    _15360 = NOVALUE;
    DeRef(_15438);
    _15438 = NOVALUE;
    DeRef(_15499);
    _15499 = NOVALUE;
    _15400 = NOVALUE;
    _15369 = NOVALUE;
    _15289 = NOVALUE;
    DeRef(_15482);
    _15482 = NOVALUE;
    _15311 = NOVALUE;
    _15493 = NOVALUE;
    DeRef(_15233);
    _15233 = NOVALUE;
    return _15591;
    goto L1; // [3563] 10
L98: 

    /** scanner.e:2005					ungetch()*/
    _62ungetch();

    /** scanner.e:2006					return {LESS, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 1;
    ((intptr_t *)_2)[2] = 0;
    _15592 = MAKE_SEQ(_1);
    DeRef(_i_27636);
    DeRef(_yytext_27639);
    DeRef(_namespaces_27640);
    DeRef(_d_27641);
    DeRef(_tok_27643);
    DeRef(_name_27646);
    DeRef(_15284);
    _15284 = NOVALUE;
    DeRef(_15455);
    _15455 = NOVALUE;
    DeRef(_15310);
    _15310 = NOVALUE;
    DeRef(_15253);
    _15253 = NOVALUE;
    DeRef(_15414);
    _15414 = NOVALUE;
    DeRef(_15238);
    _15238 = NOVALUE;
    _15426 = NOVALUE;
    DeRef(_15260);
    _15260 = NOVALUE;
    _15275 = NOVALUE;
    _15422 = NOVALUE;
    DeRef(_15256);
    _15256 = NOVALUE;
    _15379 = NOVALUE;
    DeRef(_15587);
    _15587 = NOVALUE;
    DeRef(_15381);
    _15381 = NOVALUE;
    DeRef(_15483);
    _15483 = NOVALUE;
    _15404 = NOVALUE;
    DeRef(_15506);
    _15506 = NOVALUE;
    DeRef(_15552);
    _15552 = NOVALUE;
    DeRef(_15478);
    _15478 = NOVALUE;
    DeRef(_15247);
    _15247 = NOVALUE;
    DeRef(_15448);
    _15448 = NOVALUE;
    _15519 = NOVALUE;
    DeRef(_15464);
    _15464 = NOVALUE;
    DeRef(_15450);
    _15450 = NOVALUE;
    DeRef(_15557);
    _15557 = NOVALUE;
    DeRef(_15548);
    _15548 = NOVALUE;
    DeRef(_15416);
    _15416 = NOVALUE;
    DeRef(_15250);
    _15250 = NOVALUE;
    DeRef(_15279);
    _15279 = NOVALUE;
    DeRef(_15553);
    _15553 = NOVALUE;
    DeRef(_15474);
    _15474 = NOVALUE;
    DeRef(_15591);
    _15591 = NOVALUE;
    DeRef(_15546);
    _15546 = NOVALUE;
    DeRef(_15487);
    _15487 = NOVALUE;
    DeRef(_15532);
    _15532 = NOVALUE;
    DeRef(_15440);
    _15440 = NOVALUE;
    DeRef(_15543);
    _15543 = NOVALUE;
    DeRef(_15259);
    _15259 = NOVALUE;
    DeRef(_15488);
    _15488 = NOVALUE;
    DeRef(_15359);
    _15359 = NOVALUE;
    DeRef(_15585);
    _15585 = NOVALUE;
    DeRef(_15570);
    _15570 = NOVALUE;
    DeRef(_15263);
    _15263 = NOVALUE;
    DeRef(_15457);
    _15457 = NOVALUE;
    _15300 = NOVALUE;
    _15326 = NOVALUE;
    DeRef(_15366);
    _15366 = NOVALUE;
    DeRef(_15355);
    _15355 = NOVALUE;
    DeRef(_15525);
    _15525 = NOVALUE;
    DeRef(_15463);
    _15463 = NOVALUE;
    DeRef(_15408);
    _15408 = NOVALUE;
    DeRef(_15360);
    _15360 = NOVALUE;
    DeRef(_15438);
    _15438 = NOVALUE;
    DeRef(_15499);
    _15499 = NOVALUE;
    _15400 = NOVALUE;
    _15369 = NOVALUE;
    _15289 = NOVALUE;
    DeRef(_15482);
    _15482 = NOVALUE;
    _15311 = NOVALUE;
    _15493 = NOVALUE;
    DeRef(_15233);
    _15233 = NOVALUE;
    return _15592;
    goto L1; // [3583] 10
L97: 

    /** scanner.e:2009			elsif class = GREATER then*/
    if (_class_27645 != 6)
    goto L99; // [3590] 3638

    /** scanner.e:2010				if getch() = '=' then*/
    _15594 = _62getch();
    if (binary_op_a(NOTEQ, _15594, 61)){
        DeRef(_15594);
        _15594 = NOVALUE;
        goto L9A; // [3599] 3618
    }
    DeRef(_15594);
    _15594 = NOVALUE;

    /** scanner.e:2011					return {GREATEREQ, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 2;
    ((intptr_t *)_2)[2] = 0;
    _15596 = MAKE_SEQ(_1);
    DeRef(_i_27636);
    DeRef(_yytext_27639);
    DeRef(_namespaces_27640);
    DeRef(_d_27641);
    DeRef(_tok_27643);
    DeRef(_name_27646);
    DeRef(_15284);
    _15284 = NOVALUE;
    DeRef(_15455);
    _15455 = NOVALUE;
    DeRef(_15310);
    _15310 = NOVALUE;
    DeRef(_15253);
    _15253 = NOVALUE;
    DeRef(_15414);
    _15414 = NOVALUE;
    DeRef(_15238);
    _15238 = NOVALUE;
    _15426 = NOVALUE;
    DeRef(_15260);
    _15260 = NOVALUE;
    _15275 = NOVALUE;
    _15422 = NOVALUE;
    DeRef(_15256);
    _15256 = NOVALUE;
    _15379 = NOVALUE;
    DeRef(_15587);
    _15587 = NOVALUE;
    DeRef(_15381);
    _15381 = NOVALUE;
    DeRef(_15483);
    _15483 = NOVALUE;
    _15404 = NOVALUE;
    DeRef(_15506);
    _15506 = NOVALUE;
    DeRef(_15552);
    _15552 = NOVALUE;
    DeRef(_15478);
    _15478 = NOVALUE;
    DeRef(_15247);
    _15247 = NOVALUE;
    DeRef(_15448);
    _15448 = NOVALUE;
    _15519 = NOVALUE;
    DeRef(_15464);
    _15464 = NOVALUE;
    DeRef(_15450);
    _15450 = NOVALUE;
    DeRef(_15557);
    _15557 = NOVALUE;
    DeRef(_15548);
    _15548 = NOVALUE;
    DeRef(_15416);
    _15416 = NOVALUE;
    DeRef(_15250);
    _15250 = NOVALUE;
    DeRef(_15279);
    _15279 = NOVALUE;
    DeRef(_15553);
    _15553 = NOVALUE;
    DeRef(_15474);
    _15474 = NOVALUE;
    DeRef(_15591);
    _15591 = NOVALUE;
    DeRef(_15546);
    _15546 = NOVALUE;
    DeRef(_15487);
    _15487 = NOVALUE;
    DeRef(_15532);
    _15532 = NOVALUE;
    DeRef(_15440);
    _15440 = NOVALUE;
    DeRef(_15543);
    _15543 = NOVALUE;
    DeRef(_15259);
    _15259 = NOVALUE;
    DeRef(_15488);
    _15488 = NOVALUE;
    DeRef(_15359);
    _15359 = NOVALUE;
    DeRef(_15585);
    _15585 = NOVALUE;
    DeRef(_15570);
    _15570 = NOVALUE;
    DeRef(_15263);
    _15263 = NOVALUE;
    DeRef(_15457);
    _15457 = NOVALUE;
    _15300 = NOVALUE;
    _15326 = NOVALUE;
    DeRef(_15366);
    _15366 = NOVALUE;
    DeRef(_15355);
    _15355 = NOVALUE;
    DeRef(_15525);
    _15525 = NOVALUE;
    DeRef(_15463);
    _15463 = NOVALUE;
    DeRef(_15408);
    _15408 = NOVALUE;
    DeRef(_15360);
    _15360 = NOVALUE;
    DeRef(_15438);
    _15438 = NOVALUE;
    DeRef(_15499);
    _15499 = NOVALUE;
    _15400 = NOVALUE;
    _15369 = NOVALUE;
    _15289 = NOVALUE;
    DeRef(_15482);
    _15482 = NOVALUE;
    _15311 = NOVALUE;
    DeRef(_15592);
    _15592 = NOVALUE;
    _15493 = NOVALUE;
    DeRef(_15233);
    _15233 = NOVALUE;
    return _15596;
    goto L1; // [3615] 10
L9A: 

    /** scanner.e:2013					ungetch()*/
    _62ungetch();

    /** scanner.e:2014					return {GREATER, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 6;
    ((intptr_t *)_2)[2] = 0;
    _15597 = MAKE_SEQ(_1);
    DeRef(_i_27636);
    DeRef(_yytext_27639);
    DeRef(_namespaces_27640);
    DeRef(_d_27641);
    DeRef(_tok_27643);
    DeRef(_name_27646);
    DeRef(_15284);
    _15284 = NOVALUE;
    DeRef(_15455);
    _15455 = NOVALUE;
    DeRef(_15310);
    _15310 = NOVALUE;
    DeRef(_15253);
    _15253 = NOVALUE;
    DeRef(_15414);
    _15414 = NOVALUE;
    DeRef(_15238);
    _15238 = NOVALUE;
    _15426 = NOVALUE;
    DeRef(_15260);
    _15260 = NOVALUE;
    _15275 = NOVALUE;
    _15422 = NOVALUE;
    DeRef(_15256);
    _15256 = NOVALUE;
    _15379 = NOVALUE;
    DeRef(_15587);
    _15587 = NOVALUE;
    DeRef(_15381);
    _15381 = NOVALUE;
    DeRef(_15483);
    _15483 = NOVALUE;
    _15404 = NOVALUE;
    DeRef(_15506);
    _15506 = NOVALUE;
    DeRef(_15552);
    _15552 = NOVALUE;
    DeRef(_15478);
    _15478 = NOVALUE;
    DeRef(_15247);
    _15247 = NOVALUE;
    DeRef(_15448);
    _15448 = NOVALUE;
    _15519 = NOVALUE;
    DeRef(_15464);
    _15464 = NOVALUE;
    DeRef(_15450);
    _15450 = NOVALUE;
    DeRef(_15557);
    _15557 = NOVALUE;
    DeRef(_15548);
    _15548 = NOVALUE;
    DeRef(_15416);
    _15416 = NOVALUE;
    DeRef(_15250);
    _15250 = NOVALUE;
    DeRef(_15279);
    _15279 = NOVALUE;
    DeRef(_15553);
    _15553 = NOVALUE;
    DeRef(_15474);
    _15474 = NOVALUE;
    DeRef(_15591);
    _15591 = NOVALUE;
    DeRef(_15546);
    _15546 = NOVALUE;
    DeRef(_15487);
    _15487 = NOVALUE;
    DeRef(_15532);
    _15532 = NOVALUE;
    DeRef(_15440);
    _15440 = NOVALUE;
    DeRef(_15543);
    _15543 = NOVALUE;
    DeRef(_15259);
    _15259 = NOVALUE;
    DeRef(_15488);
    _15488 = NOVALUE;
    DeRef(_15359);
    _15359 = NOVALUE;
    DeRef(_15585);
    _15585 = NOVALUE;
    DeRef(_15570);
    _15570 = NOVALUE;
    DeRef(_15263);
    _15263 = NOVALUE;
    DeRef(_15457);
    _15457 = NOVALUE;
    _15300 = NOVALUE;
    _15326 = NOVALUE;
    DeRef(_15366);
    _15366 = NOVALUE;
    DeRef(_15355);
    _15355 = NOVALUE;
    DeRef(_15525);
    _15525 = NOVALUE;
    DeRef(_15463);
    _15463 = NOVALUE;
    DeRef(_15408);
    _15408 = NOVALUE;
    DeRef(_15360);
    _15360 = NOVALUE;
    DeRef(_15438);
    _15438 = NOVALUE;
    DeRef(_15499);
    _15499 = NOVALUE;
    _15400 = NOVALUE;
    _15369 = NOVALUE;
    _15289 = NOVALUE;
    DeRef(_15482);
    _15482 = NOVALUE;
    _15311 = NOVALUE;
    DeRef(_15592);
    _15592 = NOVALUE;
    DeRef(_15596);
    _15596 = NOVALUE;
    _15493 = NOVALUE;
    DeRef(_15233);
    _15233 = NOVALUE;
    return _15597;
    goto L1; // [3635] 10
L99: 

    /** scanner.e:2017			elsif class = BANG then*/
    if (_class_27645 != -1)
    goto L9B; // [3642] 3690

    /** scanner.e:2018				if getch() = '=' then*/
    _15599 = _62getch();
    if (binary_op_a(NOTEQ, _15599, 61)){
        DeRef(_15599);
        _15599 = NOVALUE;
        goto L9C; // [3651] 3670
    }
    DeRef(_15599);
    _15599 = NOVALUE;

    /** scanner.e:2019					return {NOTEQ, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 4;
    ((intptr_t *)_2)[2] = 0;
    _15601 = MAKE_SEQ(_1);
    DeRef(_i_27636);
    DeRef(_yytext_27639);
    DeRef(_namespaces_27640);
    DeRef(_d_27641);
    DeRef(_tok_27643);
    DeRef(_name_27646);
    DeRef(_15284);
    _15284 = NOVALUE;
    DeRef(_15455);
    _15455 = NOVALUE;
    DeRef(_15310);
    _15310 = NOVALUE;
    DeRef(_15253);
    _15253 = NOVALUE;
    DeRef(_15414);
    _15414 = NOVALUE;
    DeRef(_15238);
    _15238 = NOVALUE;
    _15426 = NOVALUE;
    DeRef(_15260);
    _15260 = NOVALUE;
    _15275 = NOVALUE;
    _15422 = NOVALUE;
    DeRef(_15256);
    _15256 = NOVALUE;
    _15379 = NOVALUE;
    DeRef(_15587);
    _15587 = NOVALUE;
    DeRef(_15381);
    _15381 = NOVALUE;
    DeRef(_15483);
    _15483 = NOVALUE;
    _15404 = NOVALUE;
    DeRef(_15506);
    _15506 = NOVALUE;
    DeRef(_15552);
    _15552 = NOVALUE;
    DeRef(_15478);
    _15478 = NOVALUE;
    DeRef(_15247);
    _15247 = NOVALUE;
    DeRef(_15448);
    _15448 = NOVALUE;
    DeRef(_15597);
    _15597 = NOVALUE;
    _15519 = NOVALUE;
    DeRef(_15464);
    _15464 = NOVALUE;
    DeRef(_15450);
    _15450 = NOVALUE;
    DeRef(_15557);
    _15557 = NOVALUE;
    DeRef(_15548);
    _15548 = NOVALUE;
    DeRef(_15416);
    _15416 = NOVALUE;
    DeRef(_15250);
    _15250 = NOVALUE;
    DeRef(_15279);
    _15279 = NOVALUE;
    DeRef(_15553);
    _15553 = NOVALUE;
    DeRef(_15474);
    _15474 = NOVALUE;
    DeRef(_15591);
    _15591 = NOVALUE;
    DeRef(_15546);
    _15546 = NOVALUE;
    DeRef(_15487);
    _15487 = NOVALUE;
    DeRef(_15532);
    _15532 = NOVALUE;
    DeRef(_15440);
    _15440 = NOVALUE;
    DeRef(_15543);
    _15543 = NOVALUE;
    DeRef(_15259);
    _15259 = NOVALUE;
    DeRef(_15488);
    _15488 = NOVALUE;
    DeRef(_15359);
    _15359 = NOVALUE;
    DeRef(_15585);
    _15585 = NOVALUE;
    DeRef(_15570);
    _15570 = NOVALUE;
    DeRef(_15263);
    _15263 = NOVALUE;
    DeRef(_15457);
    _15457 = NOVALUE;
    _15300 = NOVALUE;
    _15326 = NOVALUE;
    DeRef(_15366);
    _15366 = NOVALUE;
    DeRef(_15355);
    _15355 = NOVALUE;
    DeRef(_15525);
    _15525 = NOVALUE;
    DeRef(_15463);
    _15463 = NOVALUE;
    DeRef(_15408);
    _15408 = NOVALUE;
    DeRef(_15360);
    _15360 = NOVALUE;
    DeRef(_15438);
    _15438 = NOVALUE;
    DeRef(_15499);
    _15499 = NOVALUE;
    _15400 = NOVALUE;
    _15369 = NOVALUE;
    _15289 = NOVALUE;
    DeRef(_15482);
    _15482 = NOVALUE;
    _15311 = NOVALUE;
    DeRef(_15592);
    _15592 = NOVALUE;
    DeRef(_15596);
    _15596 = NOVALUE;
    _15493 = NOVALUE;
    DeRef(_15233);
    _15233 = NOVALUE;
    return _15601;
    goto L1; // [3667] 10
L9C: 

    /** scanner.e:2021					ungetch()*/
    _62ungetch();

    /** scanner.e:2022					return {BANG, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -1;
    ((intptr_t *)_2)[2] = 0;
    _15602 = MAKE_SEQ(_1);
    DeRef(_i_27636);
    DeRef(_yytext_27639);
    DeRef(_namespaces_27640);
    DeRef(_d_27641);
    DeRef(_tok_27643);
    DeRef(_name_27646);
    DeRef(_15284);
    _15284 = NOVALUE;
    DeRef(_15455);
    _15455 = NOVALUE;
    DeRef(_15310);
    _15310 = NOVALUE;
    DeRef(_15253);
    _15253 = NOVALUE;
    DeRef(_15414);
    _15414 = NOVALUE;
    DeRef(_15238);
    _15238 = NOVALUE;
    _15426 = NOVALUE;
    DeRef(_15260);
    _15260 = NOVALUE;
    _15275 = NOVALUE;
    _15422 = NOVALUE;
    DeRef(_15256);
    _15256 = NOVALUE;
    _15379 = NOVALUE;
    DeRef(_15587);
    _15587 = NOVALUE;
    DeRef(_15381);
    _15381 = NOVALUE;
    DeRef(_15483);
    _15483 = NOVALUE;
    _15404 = NOVALUE;
    DeRef(_15506);
    _15506 = NOVALUE;
    DeRef(_15601);
    _15601 = NOVALUE;
    DeRef(_15552);
    _15552 = NOVALUE;
    DeRef(_15478);
    _15478 = NOVALUE;
    DeRef(_15247);
    _15247 = NOVALUE;
    DeRef(_15448);
    _15448 = NOVALUE;
    DeRef(_15597);
    _15597 = NOVALUE;
    _15519 = NOVALUE;
    DeRef(_15464);
    _15464 = NOVALUE;
    DeRef(_15450);
    _15450 = NOVALUE;
    DeRef(_15557);
    _15557 = NOVALUE;
    DeRef(_15548);
    _15548 = NOVALUE;
    DeRef(_15416);
    _15416 = NOVALUE;
    DeRef(_15250);
    _15250 = NOVALUE;
    DeRef(_15279);
    _15279 = NOVALUE;
    DeRef(_15553);
    _15553 = NOVALUE;
    DeRef(_15474);
    _15474 = NOVALUE;
    DeRef(_15591);
    _15591 = NOVALUE;
    DeRef(_15546);
    _15546 = NOVALUE;
    DeRef(_15487);
    _15487 = NOVALUE;
    DeRef(_15532);
    _15532 = NOVALUE;
    DeRef(_15440);
    _15440 = NOVALUE;
    DeRef(_15543);
    _15543 = NOVALUE;
    DeRef(_15259);
    _15259 = NOVALUE;
    DeRef(_15488);
    _15488 = NOVALUE;
    DeRef(_15359);
    _15359 = NOVALUE;
    DeRef(_15585);
    _15585 = NOVALUE;
    DeRef(_15570);
    _15570 = NOVALUE;
    DeRef(_15263);
    _15263 = NOVALUE;
    DeRef(_15457);
    _15457 = NOVALUE;
    _15300 = NOVALUE;
    _15326 = NOVALUE;
    DeRef(_15366);
    _15366 = NOVALUE;
    DeRef(_15355);
    _15355 = NOVALUE;
    DeRef(_15525);
    _15525 = NOVALUE;
    DeRef(_15463);
    _15463 = NOVALUE;
    DeRef(_15408);
    _15408 = NOVALUE;
    DeRef(_15360);
    _15360 = NOVALUE;
    DeRef(_15438);
    _15438 = NOVALUE;
    DeRef(_15499);
    _15499 = NOVALUE;
    _15400 = NOVALUE;
    _15369 = NOVALUE;
    _15289 = NOVALUE;
    DeRef(_15482);
    _15482 = NOVALUE;
    _15311 = NOVALUE;
    DeRef(_15592);
    _15592 = NOVALUE;
    DeRef(_15596);
    _15596 = NOVALUE;
    _15493 = NOVALUE;
    DeRef(_15233);
    _15233 = NOVALUE;
    return _15602;
    goto L1; // [3687] 10
L9B: 

    /** scanner.e:2025			elsif class = KEYWORD then*/
    if (_class_27645 != -10)
    goto L9D; // [3694] 3727

    /** scanner.e:2026				return {keylist[ch - KEYWORD_BASE][K_TOKEN], 0}*/
    _15604 = _ch_27633 - 128;
    _2 = (object)SEQ_PTR(_63keylist_23441);
    _15605 = (object)*(((s1_ptr)_2)->base + _15604);
    _2 = (object)SEQ_PTR(_15605);
    _15606 = (object)*(((s1_ptr)_2)->base + 3);
    _15605 = NOVALUE;
    Ref(_15606);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _15606;
    ((intptr_t *)_2)[2] = 0;
    _15607 = MAKE_SEQ(_1);
    _15606 = NOVALUE;
    DeRef(_i_27636);
    DeRef(_yytext_27639);
    DeRef(_namespaces_27640);
    DeRef(_d_27641);
    DeRef(_tok_27643);
    DeRef(_name_27646);
    DeRef(_15284);
    _15284 = NOVALUE;
    DeRef(_15455);
    _15455 = NOVALUE;
    DeRef(_15310);
    _15310 = NOVALUE;
    DeRef(_15253);
    _15253 = NOVALUE;
    DeRef(_15414);
    _15414 = NOVALUE;
    DeRef(_15238);
    _15238 = NOVALUE;
    _15426 = NOVALUE;
    DeRef(_15260);
    _15260 = NOVALUE;
    _15275 = NOVALUE;
    _15422 = NOVALUE;
    DeRef(_15256);
    _15256 = NOVALUE;
    _15379 = NOVALUE;
    DeRef(_15587);
    _15587 = NOVALUE;
    DeRef(_15381);
    _15381 = NOVALUE;
    DeRef(_15483);
    _15483 = NOVALUE;
    _15404 = NOVALUE;
    DeRef(_15506);
    _15506 = NOVALUE;
    DeRef(_15601);
    _15601 = NOVALUE;
    DeRef(_15552);
    _15552 = NOVALUE;
    DeRef(_15478);
    _15478 = NOVALUE;
    DeRef(_15247);
    _15247 = NOVALUE;
    DeRef(_15448);
    _15448 = NOVALUE;
    DeRef(_15597);
    _15597 = NOVALUE;
    _15519 = NOVALUE;
    DeRef(_15464);
    _15464 = NOVALUE;
    DeRef(_15450);
    _15450 = NOVALUE;
    DeRef(_15557);
    _15557 = NOVALUE;
    DeRef(_15548);
    _15548 = NOVALUE;
    DeRef(_15416);
    _15416 = NOVALUE;
    DeRef(_15250);
    _15250 = NOVALUE;
    DeRef(_15279);
    _15279 = NOVALUE;
    DeRef(_15553);
    _15553 = NOVALUE;
    DeRef(_15474);
    _15474 = NOVALUE;
    DeRef(_15591);
    _15591 = NOVALUE;
    DeRef(_15546);
    _15546 = NOVALUE;
    _15604 = NOVALUE;
    DeRef(_15487);
    _15487 = NOVALUE;
    DeRef(_15532);
    _15532 = NOVALUE;
    DeRef(_15440);
    _15440 = NOVALUE;
    DeRef(_15543);
    _15543 = NOVALUE;
    DeRef(_15259);
    _15259 = NOVALUE;
    DeRef(_15488);
    _15488 = NOVALUE;
    DeRef(_15359);
    _15359 = NOVALUE;
    DeRef(_15585);
    _15585 = NOVALUE;
    DeRef(_15570);
    _15570 = NOVALUE;
    DeRef(_15263);
    _15263 = NOVALUE;
    DeRef(_15457);
    _15457 = NOVALUE;
    _15300 = NOVALUE;
    _15326 = NOVALUE;
    DeRef(_15366);
    _15366 = NOVALUE;
    DeRef(_15355);
    _15355 = NOVALUE;
    DeRef(_15525);
    _15525 = NOVALUE;
    DeRef(_15463);
    _15463 = NOVALUE;
    DeRef(_15408);
    _15408 = NOVALUE;
    DeRef(_15360);
    _15360 = NOVALUE;
    DeRef(_15438);
    _15438 = NOVALUE;
    DeRef(_15499);
    _15499 = NOVALUE;
    _15400 = NOVALUE;
    DeRef(_15602);
    _15602 = NOVALUE;
    _15369 = NOVALUE;
    _15289 = NOVALUE;
    DeRef(_15482);
    _15482 = NOVALUE;
    _15311 = NOVALUE;
    DeRef(_15592);
    _15592 = NOVALUE;
    DeRef(_15596);
    _15596 = NOVALUE;
    _15493 = NOVALUE;
    DeRef(_15233);
    _15233 = NOVALUE;
    return _15607;
    goto L1; // [3724] 10
L9D: 

    /** scanner.e:2028			elsif class = BUILTIN then*/
    if (_class_27645 != -9)
    goto L9E; // [3731] 3784

    /** scanner.e:2029				name = keylist[ch - BUILTIN_BASE + NUM_KEYWORDS][K_NAME]*/
    _15609 = _ch_27633 - 170;
    if ((object)((uintptr_t)_15609 +(uintptr_t) HIGH_BITS) >= 0){
        _15609 = NewDouble((eudouble)_15609);
    }
    if (IS_ATOM_INT(_15609)) {
        _15610 = _15609 + 24;
    }
    else {
        _15610 = NewDouble(DBL_PTR(_15609)->dbl + (eudouble)24);
    }
    DeRef(_15609);
    _15609 = NOVALUE;
    _2 = (object)SEQ_PTR(_63keylist_23441);
    if (!IS_ATOM_INT(_15610)){
        _15611 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_15610)->dbl));
    }
    else{
        _15611 = (object)*(((s1_ptr)_2)->base + _15610);
    }
    DeRef(_name_27646);
    _2 = (object)SEQ_PTR(_15611);
    _name_27646 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_name_27646);
    _15611 = NOVALUE;

    /** scanner.e:2030				return keyfind(name, -1)*/
    RefDS(_name_27646);
    _31984 = _54hashfn(_name_27646);
    RefDS(_name_27646);
    _15613 = _54keyfind(_name_27646, -1, _36current_file_no_21767, 0, _31984);
    _31984 = NOVALUE;
    DeRef(_i_27636);
    DeRef(_yytext_27639);
    DeRef(_namespaces_27640);
    DeRef(_d_27641);
    DeRef(_tok_27643);
    DeRefDS(_name_27646);
    DeRef(_15284);
    _15284 = NOVALUE;
    DeRef(_15610);
    _15610 = NOVALUE;
    DeRef(_15455);
    _15455 = NOVALUE;
    DeRef(_15310);
    _15310 = NOVALUE;
    DeRef(_15253);
    _15253 = NOVALUE;
    DeRef(_15414);
    _15414 = NOVALUE;
    DeRef(_15238);
    _15238 = NOVALUE;
    _15426 = NOVALUE;
    DeRef(_15260);
    _15260 = NOVALUE;
    _15275 = NOVALUE;
    _15422 = NOVALUE;
    DeRef(_15256);
    _15256 = NOVALUE;
    _15379 = NOVALUE;
    DeRef(_15587);
    _15587 = NOVALUE;
    DeRef(_15381);
    _15381 = NOVALUE;
    DeRef(_15483);
    _15483 = NOVALUE;
    _15404 = NOVALUE;
    DeRef(_15506);
    _15506 = NOVALUE;
    DeRef(_15601);
    _15601 = NOVALUE;
    DeRef(_15552);
    _15552 = NOVALUE;
    DeRef(_15478);
    _15478 = NOVALUE;
    DeRef(_15247);
    _15247 = NOVALUE;
    DeRef(_15448);
    _15448 = NOVALUE;
    DeRef(_15597);
    _15597 = NOVALUE;
    _15519 = NOVALUE;
    DeRef(_15464);
    _15464 = NOVALUE;
    DeRef(_15450);
    _15450 = NOVALUE;
    DeRef(_15557);
    _15557 = NOVALUE;
    DeRef(_15548);
    _15548 = NOVALUE;
    DeRef(_15416);
    _15416 = NOVALUE;
    DeRef(_15250);
    _15250 = NOVALUE;
    DeRef(_15279);
    _15279 = NOVALUE;
    DeRef(_15553);
    _15553 = NOVALUE;
    DeRef(_15474);
    _15474 = NOVALUE;
    DeRef(_15591);
    _15591 = NOVALUE;
    DeRef(_15546);
    _15546 = NOVALUE;
    DeRef(_15604);
    _15604 = NOVALUE;
    DeRef(_15487);
    _15487 = NOVALUE;
    DeRef(_15532);
    _15532 = NOVALUE;
    DeRef(_15440);
    _15440 = NOVALUE;
    DeRef(_15543);
    _15543 = NOVALUE;
    DeRef(_15607);
    _15607 = NOVALUE;
    DeRef(_15259);
    _15259 = NOVALUE;
    DeRef(_15488);
    _15488 = NOVALUE;
    DeRef(_15359);
    _15359 = NOVALUE;
    DeRef(_15585);
    _15585 = NOVALUE;
    DeRef(_15570);
    _15570 = NOVALUE;
    DeRef(_15263);
    _15263 = NOVALUE;
    DeRef(_15457);
    _15457 = NOVALUE;
    _15300 = NOVALUE;
    _15326 = NOVALUE;
    DeRef(_15366);
    _15366 = NOVALUE;
    DeRef(_15355);
    _15355 = NOVALUE;
    DeRef(_15525);
    _15525 = NOVALUE;
    DeRef(_15463);
    _15463 = NOVALUE;
    DeRef(_15408);
    _15408 = NOVALUE;
    DeRef(_15360);
    _15360 = NOVALUE;
    DeRef(_15438);
    _15438 = NOVALUE;
    DeRef(_15499);
    _15499 = NOVALUE;
    _15400 = NOVALUE;
    DeRef(_15602);
    _15602 = NOVALUE;
    _15369 = NOVALUE;
    _15289 = NOVALUE;
    DeRef(_15482);
    _15482 = NOVALUE;
    _15311 = NOVALUE;
    DeRef(_15592);
    _15592 = NOVALUE;
    DeRef(_15596);
    _15596 = NOVALUE;
    _15493 = NOVALUE;
    DeRef(_15233);
    _15233 = NOVALUE;
    return _15613;
    goto L1; // [3781] 10
L9E: 

    /** scanner.e:2032			elsif class = BACK_QUOTE then*/
    if (_class_27645 != -12)
    goto L9F; // [3788] 3805

    /** scanner.e:2033				return ExtendedString( '`' )*/
    _15615 = _62ExtendedString(96);
    DeRef(_i_27636);
    DeRef(_yytext_27639);
    DeRef(_namespaces_27640);
    DeRef(_d_27641);
    DeRef(_tok_27643);
    DeRef(_name_27646);
    DeRef(_15284);
    _15284 = NOVALUE;
    DeRef(_15610);
    _15610 = NOVALUE;
    DeRef(_15455);
    _15455 = NOVALUE;
    DeRef(_15310);
    _15310 = NOVALUE;
    DeRef(_15253);
    _15253 = NOVALUE;
    DeRef(_15414);
    _15414 = NOVALUE;
    DeRef(_15238);
    _15238 = NOVALUE;
    _15426 = NOVALUE;
    DeRef(_15260);
    _15260 = NOVALUE;
    _15275 = NOVALUE;
    _15422 = NOVALUE;
    DeRef(_15256);
    _15256 = NOVALUE;
    _15379 = NOVALUE;
    DeRef(_15587);
    _15587 = NOVALUE;
    DeRef(_15381);
    _15381 = NOVALUE;
    DeRef(_15483);
    _15483 = NOVALUE;
    _15404 = NOVALUE;
    DeRef(_15506);
    _15506 = NOVALUE;
    DeRef(_15601);
    _15601 = NOVALUE;
    DeRef(_15552);
    _15552 = NOVALUE;
    DeRef(_15478);
    _15478 = NOVALUE;
    DeRef(_15247);
    _15247 = NOVALUE;
    DeRef(_15448);
    _15448 = NOVALUE;
    DeRef(_15597);
    _15597 = NOVALUE;
    _15519 = NOVALUE;
    DeRef(_15464);
    _15464 = NOVALUE;
    DeRef(_15450);
    _15450 = NOVALUE;
    DeRef(_15557);
    _15557 = NOVALUE;
    DeRef(_15548);
    _15548 = NOVALUE;
    DeRef(_15416);
    _15416 = NOVALUE;
    DeRef(_15250);
    _15250 = NOVALUE;
    DeRef(_15279);
    _15279 = NOVALUE;
    DeRef(_15553);
    _15553 = NOVALUE;
    DeRef(_15474);
    _15474 = NOVALUE;
    DeRef(_15591);
    _15591 = NOVALUE;
    DeRef(_15546);
    _15546 = NOVALUE;
    DeRef(_15604);
    _15604 = NOVALUE;
    DeRef(_15487);
    _15487 = NOVALUE;
    DeRef(_15532);
    _15532 = NOVALUE;
    DeRef(_15440);
    _15440 = NOVALUE;
    DeRef(_15543);
    _15543 = NOVALUE;
    DeRef(_15613);
    _15613 = NOVALUE;
    DeRef(_15607);
    _15607 = NOVALUE;
    DeRef(_15259);
    _15259 = NOVALUE;
    DeRef(_15488);
    _15488 = NOVALUE;
    DeRef(_15359);
    _15359 = NOVALUE;
    DeRef(_15585);
    _15585 = NOVALUE;
    DeRef(_15570);
    _15570 = NOVALUE;
    DeRef(_15263);
    _15263 = NOVALUE;
    DeRef(_15457);
    _15457 = NOVALUE;
    _15300 = NOVALUE;
    _15326 = NOVALUE;
    DeRef(_15366);
    _15366 = NOVALUE;
    DeRef(_15355);
    _15355 = NOVALUE;
    DeRef(_15525);
    _15525 = NOVALUE;
    DeRef(_15463);
    _15463 = NOVALUE;
    DeRef(_15408);
    _15408 = NOVALUE;
    DeRef(_15360);
    _15360 = NOVALUE;
    DeRef(_15438);
    _15438 = NOVALUE;
    DeRef(_15499);
    _15499 = NOVALUE;
    _15400 = NOVALUE;
    DeRef(_15602);
    _15602 = NOVALUE;
    _15369 = NOVALUE;
    _15289 = NOVALUE;
    DeRef(_15482);
    _15482 = NOVALUE;
    _15311 = NOVALUE;
    DeRef(_15592);
    _15592 = NOVALUE;
    DeRef(_15596);
    _15596 = NOVALUE;
    _15493 = NOVALUE;
    DeRef(_15233);
    _15233 = NOVALUE;
    return _15615;
    goto L1; // [3802] 10
L9F: 

    /** scanner.e:2036				InternalErr(268, {class})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _class_27645;
    _15616 = MAKE_SEQ(_1);
    _50InternalErr(268, _15616);
    _15616 = NOVALUE;

    /** scanner.e:2039	   end while*/
    goto L1; // [3818] 10
L2: 
    ;
}


void _62eu_namespace()
{
    object _eu_tok_28438 = NOVALUE;
    object _eu_ns_28440 = NOVALUE;
    object _31983 = NOVALUE;
    object _31982 = NOVALUE;
    object _15625 = NOVALUE;
    object _15623 = NOVALUE;
    object _15621 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** scanner.e:2047		eu_tok = keyfind("eu", -1, , 1)*/
    RefDS(_15619);
    _31982 = _15619;
    _31983 = _54hashfn(_31982);
    _31982 = NOVALUE;
    RefDS(_15619);
    _0 = _eu_tok_28438;
    _eu_tok_28438 = _54keyfind(_15619, -1, _36current_file_no_21767, 1, _31983);
    DeRef(_0);
    _31983 = NOVALUE;

    /** scanner.e:2050		eu_ns  = NameSpace_declaration(eu_tok[T_SYM])*/
    _2 = (object)SEQ_PTR(_eu_tok_28438);
    _15621 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_15621);
    _eu_ns_28440 = _62NameSpace_declaration(_15621);
    _15621 = NOVALUE;
    if (!IS_ATOM_INT(_eu_ns_28440)) {
        _1 = (object)(DBL_PTR(_eu_ns_28440)->dbl);
        DeRefDS(_eu_ns_28440);
        _eu_ns_28440 = _1;
    }

    /** scanner.e:2051		SymTab[eu_ns][S_OBJ] = 0*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_eu_ns_28440 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);
    _15623 = NOVALUE;

    /** scanner.e:2052		SymTab[eu_ns][S_SCOPE] = SC_GLOBAL*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_eu_ns_28440 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 6;
    DeRef(_1);
    _15625 = NOVALUE;

    /** scanner.e:2053	end procedure*/
    DeRef(_eu_tok_28438);
    return;
    ;
}


object _62StringToken(object _pDelims_28458)
{
    object _ch_28459 = NOVALUE;
    object _m_28460 = NOVALUE;
    object _gtext_28461 = NOVALUE;
    object _level_28492 = NOVALUE;
    object _15664 = NOVALUE;
    object _15662 = NOVALUE;
    object _15660 = NOVALUE;
    object _15641 = NOVALUE;
    object _15640 = NOVALUE;
    object _15634 = NOVALUE;
    object _15632 = NOVALUE;
    object _15630 = NOVALUE;
    object _15628 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:2064		ch = getch()*/
    _ch_28459 = _62getch();
    if (!IS_ATOM_INT(_ch_28459)) {
        _1 = (object)(DBL_PTR(_ch_28459)->dbl);
        DeRefDS(_ch_28459);
        _ch_28459 = _1;
    }

    /** scanner.e:2065		while ch = ' ' or ch = '\t' do*/
L1: 
    _15628 = (_ch_28459 == 32);
    if (_15628 != 0) {
        goto L2; // [19] 32
    }
    _15630 = (_ch_28459 == 9);
    if (_15630 == 0)
    {
        DeRef(_15630);
        _15630 = NOVALUE;
        goto L3; // [28] 44
    }
    else{
        DeRef(_15630);
        _15630 = NOVALUE;
    }
L2: 

    /** scanner.e:2066			ch = getch()*/
    _ch_28459 = _62getch();
    if (!IS_ATOM_INT(_ch_28459)) {
        _1 = (object)(DBL_PTR(_ch_28459)->dbl);
        DeRefDS(_ch_28459);
        _ch_28459 = _1;
    }

    /** scanner.e:2067		end while*/
    goto L1; // [41] 15
L3: 

    /** scanner.e:2069		pDelims &= {' ', '\t', '\n', '\r', END_OF_FILE_CHAR}*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 32;
    ((intptr_t*)_2)[2] = 9;
    ((intptr_t*)_2)[3] = 10;
    ((intptr_t*)_2)[4] = 13;
    ((intptr_t*)_2)[5] = 26;
    _15632 = MAKE_SEQ(_1);
    Concat((object_ptr)&_pDelims_28458, _pDelims_28458, _15632);
    DeRefDS(_15632);
    _15632 = NOVALUE;

    /** scanner.e:2070		gtext = ""*/
    RefDS(_5);
    DeRefi(_gtext_28461);
    _gtext_28461 = _5;

    /** scanner.e:2071		while not find(ch,  pDelims) label "top" do*/
L4: 
    _15634 = find_from(_ch_28459, _pDelims_28458, 1);
    if (_15634 != 0)
    goto L5; // [77] 391
    _15634 = NOVALUE;

    /** scanner.e:2072			if ch = '-' then*/
    if (_ch_28459 != 45)
    goto L6; // [82] 145

    /** scanner.e:2073				ch = getch()*/
    _ch_28459 = _62getch();
    if (!IS_ATOM_INT(_ch_28459)) {
        _1 = (object)(DBL_PTR(_ch_28459)->dbl);
        DeRefDS(_ch_28459);
        _ch_28459 = _1;
    }

    /** scanner.e:2074				if ch = '-' then*/
    if (_ch_28459 != 45)
    goto L7; // [95] 137

    /** scanner.e:2075					while not find(ch, {'\n', END_OF_FILE_CHAR}) do*/
L8: 
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 10;
    ((intptr_t *)_2)[2] = 26;
    _15640 = MAKE_SEQ(_1);
    _15641 = find_from(_ch_28459, _15640, 1);
    DeRefDS(_15640);
    _15640 = NOVALUE;
    if (_15641 != 0)
    goto L5; // [115] 391
    _15641 = NOVALUE;

    /** scanner.e:2076						ch = getch()*/
    _ch_28459 = _62getch();
    if (!IS_ATOM_INT(_ch_28459)) {
        _1 = (object)(DBL_PTR(_ch_28459)->dbl);
        DeRefDS(_ch_28459);
        _ch_28459 = _1;
    }

    /** scanner.e:2077					end while*/
    goto L8; // [127] 104

    /** scanner.e:2078					exit*/
    goto L5; // [132] 391
    goto L9; // [134] 373
L7: 

    /** scanner.e:2080					ungetch()*/
    _62ungetch();
    goto L9; // [142] 373
L6: 

    /** scanner.e:2082			elsif ch = '/' then*/
    if (_ch_28459 != 47)
    goto LA; // [147] 372

    /** scanner.e:2083				ch = getch()*/
    _ch_28459 = _62getch();
    if (!IS_ATOM_INT(_ch_28459)) {
        _1 = (object)(DBL_PTR(_ch_28459)->dbl);
        DeRefDS(_ch_28459);
        _ch_28459 = _1;
    }

    /** scanner.e:2084				if ch = '*' then*/
    if (_ch_28459 != 42)
    goto LB; // [160] 361

    /** scanner.e:2085					integer level = 1*/
    _level_28492 = 1;

    /** scanner.e:2086					while level > 0 do*/
LC: 
    if (_level_28492 <= 0)
    goto LD; // [174] 293

    /** scanner.e:2087						ch = getch()*/
    _ch_28459 = _62getch();
    if (!IS_ATOM_INT(_ch_28459)) {
        _1 = (object)(DBL_PTR(_ch_28459)->dbl);
        DeRefDS(_ch_28459);
        _ch_28459 = _1;
    }

    /** scanner.e:2088						if ch = '/' then*/
    if (_ch_28459 != 47)
    goto LE; // [187] 221

    /** scanner.e:2089							ch = getch()*/
    _ch_28459 = _62getch();
    if (!IS_ATOM_INT(_ch_28459)) {
        _1 = (object)(DBL_PTR(_ch_28459)->dbl);
        DeRefDS(_ch_28459);
        _ch_28459 = _1;
    }

    /** scanner.e:2090							if ch = '*' then*/
    if (_ch_28459 != 42)
    goto LF; // [200] 213

    /** scanner.e:2091								level += 1*/
    _level_28492 = _level_28492 + 1;
    goto LC; // [210] 174
LF: 

    /** scanner.e:2093								ungetch()*/
    _62ungetch();
    goto LC; // [218] 174
LE: 

    /** scanner.e:2095						elsif ch = '*' then*/
    if (_ch_28459 != 42)
    goto L10; // [223] 257

    /** scanner.e:2096							ch = getch()*/
    _ch_28459 = _62getch();
    if (!IS_ATOM_INT(_ch_28459)) {
        _1 = (object)(DBL_PTR(_ch_28459)->dbl);
        DeRefDS(_ch_28459);
        _ch_28459 = _1;
    }

    /** scanner.e:2097							if ch = '/' then*/
    if (_ch_28459 != 47)
    goto L11; // [236] 249

    /** scanner.e:2098								level -= 1*/
    _level_28492 = _level_28492 - 1;
    goto LC; // [246] 174
L11: 

    /** scanner.e:2100								ungetch()*/
    _62ungetch();
    goto LC; // [254] 174
L10: 

    /** scanner.e:2102						elsif ch = '\n' then*/
    if (_ch_28459 != 10)
    goto L12; // [259] 270

    /** scanner.e:2103							read_line()*/
    _62read_line();
    goto LC; // [267] 174
L12: 

    /** scanner.e:2104						elsif ch = END_OF_FILE_CHAR then*/
    if (_ch_28459 != 26)
    goto LC; // [274] 174

    /** scanner.e:2105							ungetch()*/
    _62ungetch();

    /** scanner.e:2106							exit*/
    goto LD; // [284] 293

    /** scanner.e:2108					end while*/
    goto LC; // [290] 174
LD: 

    /** scanner.e:2109					ch = getch()*/
    _ch_28459 = _62getch();
    if (!IS_ATOM_INT(_ch_28459)) {
        _1 = (object)(DBL_PTR(_ch_28459)->dbl);
        DeRefDS(_ch_28459);
        _ch_28459 = _1;
    }

    /** scanner.e:2110					if length(gtext) = 0 then*/
    if (IS_SEQUENCE(_gtext_28461)){
            _15660 = SEQ_PTR(_gtext_28461)->length;
    }
    else {
        _15660 = 1;
    }
    if (_15660 != 0)
    goto L13; // [305] 350

    /** scanner.e:2111						while ch = ' ' or ch = '\t' do*/
L14: 
    _15662 = (_ch_28459 == 32);
    if (_15662 != 0) {
        goto L15; // [318] 331
    }
    _15664 = (_ch_28459 == 9);
    if (_15664 == 0)
    {
        DeRef(_15664);
        _15664 = NOVALUE;
        goto L16; // [327] 343
    }
    else{
        DeRef(_15664);
        _15664 = NOVALUE;
    }
L15: 

    /** scanner.e:2112							ch = getch()*/
    _ch_28459 = _62getch();
    if (!IS_ATOM_INT(_ch_28459)) {
        _1 = (object)(DBL_PTR(_ch_28459)->dbl);
        DeRefDS(_ch_28459);
        _ch_28459 = _1;
    }

    /** scanner.e:2113						end while*/
    goto L14; // [340] 314
L16: 

    /** scanner.e:2114						continue "top"*/
    goto L4; // [347] 72
L13: 

    /** scanner.e:2116					exit*/
    goto L5; // [354] 391
    goto L17; // [358] 371
LB: 

    /** scanner.e:2119					ungetch()*/
    _62ungetch();

    /** scanner.e:2120					ch = '/'*/
    _ch_28459 = 47;
L17: 
LA: 
L9: 

    /** scanner.e:2123			gtext &= ch*/
    Append(&_gtext_28461, _gtext_28461, _ch_28459);

    /** scanner.e:2124			ch = getch()*/
    _ch_28459 = _62getch();
    if (!IS_ATOM_INT(_ch_28459)) {
        _1 = (object)(DBL_PTR(_ch_28459)->dbl);
        DeRefDS(_ch_28459);
        _ch_28459 = _1;
    }

    /** scanner.e:2125		end while*/
    goto L4; // [388] 72
L5: 

    /** scanner.e:2127		ungetch() -- put back end-word token.*/
    _62ungetch();

    /** scanner.e:2129		return gtext*/
    DeRefDSi(_pDelims_28458);
    DeRef(_15628);
    _15628 = NOVALUE;
    DeRef(_15662);
    _15662 = NOVALUE;
    return _gtext_28461;
    ;
}


void _62IncludeScan(object _is_public_28529)
{
    object _ch_28530 = NOVALUE;
    object _gtext_28531 = NOVALUE;
    object _s_28533 = NOVALUE;
    object _31981 = NOVALUE;
    object _15728 = NOVALUE;
    object _15727 = NOVALUE;
    object _15725 = NOVALUE;
    object _15723 = NOVALUE;
    object _15722 = NOVALUE;
    object _15717 = NOVALUE;
    object _15714 = NOVALUE;
    object _15712 = NOVALUE;
    object _15711 = NOVALUE;
    object _15709 = NOVALUE;
    object _15707 = NOVALUE;
    object _15705 = NOVALUE;
    object _15703 = NOVALUE;
    object _15697 = NOVALUE;
    object _15695 = NOVALUE;
    object _15689 = NOVALUE;
    object _15685 = NOVALUE;
    object _15684 = NOVALUE;
    object _15679 = NOVALUE;
    object _15676 = NOVALUE;
    object _15675 = NOVALUE;
    object _15671 = NOVALUE;
    object _15669 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:2149		ch = getch()*/
    _ch_28530 = _62getch();
    if (!IS_ATOM_INT(_ch_28530)) {
        _1 = (object)(DBL_PTR(_ch_28530)->dbl);
        DeRefDS(_ch_28530);
        _ch_28530 = _1;
    }

    /** scanner.e:2150		while ch = ' ' or ch = '\t' do*/
L1: 
    _15669 = (_ch_28530 == 32);
    if (_15669 != 0) {
        goto L2; // [19] 32
    }
    _15671 = (_ch_28530 == 9);
    if (_15671 == 0)
    {
        DeRef(_15671);
        _15671 = NOVALUE;
        goto L3; // [28] 44
    }
    else{
        DeRef(_15671);
        _15671 = NOVALUE;
    }
L2: 

    /** scanner.e:2151			ch = getch()*/
    _ch_28530 = _62getch();
    if (!IS_ATOM_INT(_ch_28530)) {
        _1 = (object)(DBL_PTR(_ch_28530)->dbl);
        DeRefDS(_ch_28530);
        _ch_28530 = _1;
    }

    /** scanner.e:2152		end while*/
    goto L1; // [41] 15
L3: 

    /** scanner.e:2155		gtext = ""*/
    RefDS(_5);
    DeRef(_gtext_28531);
    _gtext_28531 = _5;

    /** scanner.e:2157		if ch = '"' then*/
    if (_ch_28530 != 34)
    goto L4; // [53] 143

    /** scanner.e:2159			ch = getch()*/
    _ch_28530 = _62getch();
    if (!IS_ATOM_INT(_ch_28530)) {
        _1 = (object)(DBL_PTR(_ch_28530)->dbl);
        DeRefDS(_ch_28530);
        _ch_28530 = _1;
    }

    /** scanner.e:2160			while not find(ch, {'\n', '\r', '"', END_OF_FILE_CHAR}) do*/
L5: 
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 10;
    ((intptr_t*)_2)[2] = 13;
    ((intptr_t*)_2)[3] = 34;
    ((intptr_t*)_2)[4] = 26;
    _15675 = MAKE_SEQ(_1);
    _15676 = find_from(_ch_28530, _15675, 1);
    DeRefDS(_15675);
    _15675 = NOVALUE;
    if (_15676 != 0)
    goto L6; // [83] 124
    _15676 = NOVALUE;

    /** scanner.e:2161				if ch = '\\' then*/
    if (_ch_28530 != 92)
    goto L7; // [88] 105

    /** scanner.e:2162					gtext &= EscapeChar('"')*/
    _15679 = _62EscapeChar(34);
    if (IS_SEQUENCE(_gtext_28531) && IS_ATOM(_15679)) {
        Ref(_15679);
        Append(&_gtext_28531, _gtext_28531, _15679);
    }
    else if (IS_ATOM(_gtext_28531) && IS_SEQUENCE(_15679)) {
    }
    else {
        Concat((object_ptr)&_gtext_28531, _gtext_28531, _15679);
    }
    DeRef(_15679);
    _15679 = NOVALUE;
    goto L8; // [102] 112
L7: 

    /** scanner.e:2164					gtext &= ch*/
    Append(&_gtext_28531, _gtext_28531, _ch_28530);
L8: 

    /** scanner.e:2166				ch = getch()*/
    _ch_28530 = _62getch();
    if (!IS_ATOM_INT(_ch_28530)) {
        _1 = (object)(DBL_PTR(_ch_28530)->dbl);
        DeRefDS(_ch_28530);
        _ch_28530 = _1;
    }

    /** scanner.e:2167			end while*/
    goto L5; // [121] 69
L6: 

    /** scanner.e:2168			if ch != '"' then*/
    if (_ch_28530 == 34)
    goto L9; // [126] 189

    /** scanner.e:2169				CompileErr(MISSING_CLOSING_QUOTE_ON_FILE_NAME)*/
    RefDS(_22190);
    _50CompileErr(115, _22190, 0);
    goto L9; // [140] 189
L4: 

    /** scanner.e:2173			while not find(ch, {' ', '\t', '\n', '\r', END_OF_FILE_CHAR}) do*/
LA: 
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 32;
    ((intptr_t*)_2)[2] = 9;
    ((intptr_t*)_2)[3] = 10;
    ((intptr_t*)_2)[4] = 13;
    ((intptr_t*)_2)[5] = 26;
    _15684 = MAKE_SEQ(_1);
    _15685 = find_from(_ch_28530, _15684, 1);
    DeRefDS(_15684);
    _15684 = NOVALUE;
    if (_15685 != 0)
    goto LB; // [163] 184
    _15685 = NOVALUE;

    /** scanner.e:2174				gtext &= ch*/
    Append(&_gtext_28531, _gtext_28531, _ch_28530);

    /** scanner.e:2175				ch = getch()*/
    _ch_28530 = _62getch();
    if (!IS_ATOM_INT(_ch_28530)) {
        _1 = (object)(DBL_PTR(_ch_28530)->dbl);
        DeRefDS(_ch_28530);
        _ch_28530 = _1;
    }

    /** scanner.e:2176			end while*/
    goto LA; // [181] 148
LB: 

    /** scanner.e:2177			ungetch()*/
    _62ungetch();
L9: 

    /** scanner.e:2180		if length(gtext) = 0 then*/
    if (IS_SEQUENCE(_gtext_28531)){
            _15689 = SEQ_PTR(_gtext_28531)->length;
    }
    else {
        _15689 = 1;
    }
    if (_15689 != 0)
    goto LC; // [194] 208

    /** scanner.e:2181			CompileErr(FILE_NAME_IS_MISSING)*/
    RefDS(_22190);
    _50CompileErr(95, _22190, 0);
LC: 

    /** scanner.e:2185		ifdef WINDOWS then*/

    /** scanner.e:2186			new_include_name = match_replace(`/`, gtext, `\`)*/
    RefDS(_15691);
    RefDS(_gtext_28531);
    RefDS(_15692);
    _0 = _16match_replace(_15691, _gtext_28531, _15692, 0);
    DeRef(_36new_include_name_21893);
    _36new_include_name_21893 = _0;

    /** scanner.e:2192		ch = getch()*/
    _ch_28530 = _62getch();
    if (!IS_ATOM_INT(_ch_28530)) {
        _1 = (object)(DBL_PTR(_ch_28530)->dbl);
        DeRefDS(_ch_28530);
        _ch_28530 = _1;
    }

    /** scanner.e:2193		while ch = ' ' or ch = '\t' do*/
LD: 
    _15695 = (_ch_28530 == 32);
    if (_15695 != 0) {
        goto LE; // [237] 250
    }
    _15697 = (_ch_28530 == 9);
    if (_15697 == 0)
    {
        DeRef(_15697);
        _15697 = NOVALUE;
        goto LF; // [246] 262
    }
    else{
        DeRef(_15697);
        _15697 = NOVALUE;
    }
LE: 

    /** scanner.e:2194			ch = getch()*/
    _ch_28530 = _62getch();
    if (!IS_ATOM_INT(_ch_28530)) {
        _1 = (object)(DBL_PTR(_ch_28530)->dbl);
        DeRefDS(_ch_28530);
        _ch_28530 = _1;
    }

    /** scanner.e:2195		end while*/
    goto LD; // [259] 233
LF: 

    /** scanner.e:2197		new_include_space = 0*/
    _62new_include_space_25871 = 0;

    /** scanner.e:2199		if ch = 'a' then*/
    if (_ch_28530 != 97)
    goto L10; // [271] 536

    /** scanner.e:2201			ch = getch()*/
    _ch_28530 = _62getch();
    if (!IS_ATOM_INT(_ch_28530)) {
        _1 = (object)(DBL_PTR(_ch_28530)->dbl);
        DeRefDS(_ch_28530);
        _ch_28530 = _1;
    }

    /** scanner.e:2202			if ch = 's' then*/
    if (_ch_28530 != 115)
    goto L11; // [284] 523

    /** scanner.e:2203				ch = getch()*/
    _ch_28530 = _62getch();
    if (!IS_ATOM_INT(_ch_28530)) {
        _1 = (object)(DBL_PTR(_ch_28530)->dbl);
        DeRefDS(_ch_28530);
        _ch_28530 = _1;
    }

    /** scanner.e:2204				if ch = ' ' or ch = '\t' then*/
    _15703 = (_ch_28530 == 32);
    if (_15703 != 0) {
        goto L12; // [301] 314
    }
    _15705 = (_ch_28530 == 9);
    if (_15705 == 0)
    {
        DeRef(_15705);
        _15705 = NOVALUE;
        goto L13; // [310] 510
    }
    else{
        DeRef(_15705);
        _15705 = NOVALUE;
    }
L12: 

    /** scanner.e:2207					ch = getch()*/
    _ch_28530 = _62getch();
    if (!IS_ATOM_INT(_ch_28530)) {
        _1 = (object)(DBL_PTR(_ch_28530)->dbl);
        DeRefDS(_ch_28530);
        _ch_28530 = _1;
    }

    /** scanner.e:2208					while ch = ' ' or ch = '\t' do*/
L14: 
    _15707 = (_ch_28530 == 32);
    if (_15707 != 0) {
        goto L15; // [330] 343
    }
    _15709 = (_ch_28530 == 9);
    if (_15709 == 0)
    {
        DeRef(_15709);
        _15709 = NOVALUE;
        goto L16; // [339] 355
    }
    else{
        DeRef(_15709);
        _15709 = NOVALUE;
    }
L15: 

    /** scanner.e:2209						ch = getch()*/
    _ch_28530 = _62getch();
    if (!IS_ATOM_INT(_ch_28530)) {
        _1 = (object)(DBL_PTR(_ch_28530)->dbl);
        DeRefDS(_ch_28530);
        _ch_28530 = _1;
    }

    /** scanner.e:2210					end while*/
    goto L14; // [352] 326
L16: 

    /** scanner.e:2213					if char_class[ch] = LETTER or ch = '_' then*/
    _2 = (object)SEQ_PTR(_62char_class_25880);
    _15711 = (object)*(((s1_ptr)_2)->base + _ch_28530);
    _15712 = (_15711 == -2);
    _15711 = NOVALUE;
    if (_15712 != 0) {
        goto L17; // [369] 382
    }
    _15714 = (_ch_28530 == 95);
    if (_15714 == 0)
    {
        DeRef(_15714);
        _15714 = NOVALUE;
        goto L18; // [378] 497
    }
    else{
        DeRef(_15714);
        _15714 = NOVALUE;
    }
L17: 

    /** scanner.e:2214						gtext = {ch}*/
    _0 = _gtext_28531;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _ch_28530;
    _gtext_28531 = MAKE_SEQ(_1);
    DeRef(_0);

    /** scanner.e:2215						ch = getch()*/
    _ch_28530 = _62getch();
    if (!IS_ATOM_INT(_ch_28530)) {
        _1 = (object)(DBL_PTR(_ch_28530)->dbl);
        DeRefDS(_ch_28530);
        _ch_28530 = _1;
    }

    /** scanner.e:2216						while id_char[ch] = TRUE do*/
L19: 
    _2 = (object)SEQ_PTR(_62id_char_25881);
    _15717 = (object)*(((s1_ptr)_2)->base + _ch_28530);
    if (_15717 != _13TRUE_447)
    goto L1A; // [408] 430

    /** scanner.e:2217							gtext &= ch*/
    Append(&_gtext_28531, _gtext_28531, _ch_28530);

    /** scanner.e:2218							ch = getch()*/
    _ch_28530 = _62getch();
    if (!IS_ATOM_INT(_ch_28530)) {
        _1 = (object)(DBL_PTR(_ch_28530)->dbl);
        DeRefDS(_ch_28530);
        _ch_28530 = _1;
    }

    /** scanner.e:2219						end while*/
    goto L19; // [427] 400
L1A: 

    /** scanner.e:2221						ungetch()*/
    _62ungetch();

    /** scanner.e:2222						s = keyfind(gtext, -1, , 1)*/
    RefDS(_gtext_28531);
    _31981 = _54hashfn(_gtext_28531);
    RefDS(_gtext_28531);
    _0 = _s_28533;
    _s_28533 = _54keyfind(_gtext_28531, -1, _36current_file_no_21767, 1, _31981);
    DeRef(_0);
    _31981 = NOVALUE;

    /** scanner.e:2223						if not find(s[T_ID], ID_TOKS) then*/
    _2 = (object)SEQ_PTR(_s_28533);
    _15722 = (object)*(((s1_ptr)_2)->base + 1);
    _15723 = find_from(_15722, _38ID_TOKS_16297, 1);
    _15722 = NOVALUE;
    if (_15723 != 0)
    goto L1B; // [467] 480
    _15723 = NOVALUE;

    /** scanner.e:2224							CompileErr(A_NEW_NAMESPACE_IDENTIFIER_IS_EXPECTED_HERE)*/
    RefDS(_22190);
    _50CompileErr(36, _22190, 0);
L1B: 

    /** scanner.e:2226						new_include_space = NameSpace_declaration(s[T_SYM])*/
    _2 = (object)SEQ_PTR(_s_28533);
    _15725 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_15725);
    _0 = _62NameSpace_declaration(_15725);
    _62new_include_space_25871 = _0;
    _15725 = NOVALUE;
    if (!IS_ATOM_INT(_62new_include_space_25871)) {
        _1 = (object)(DBL_PTR(_62new_include_space_25871)->dbl);
        DeRefDS(_62new_include_space_25871);
        _62new_include_space_25871 = _1;
    }
    goto L1C; // [494] 651
L18: 

    /** scanner.e:2228						CompileErr(MISSING_NAMESPACE_QUALIFIER)*/
    RefDS(_22190);
    _50CompileErr(113, _22190, 0);
    goto L1C; // [507] 651
L13: 

    /** scanner.e:2231					CompileErr(EXPECTING_AS_OR_ENDOF_LINE_UNEXPECTED_TEXT_ON_INCLUDE_DIRECTIVE)*/
    RefDS(_22190);
    _50CompileErr(100, _22190, 0);
    goto L1C; // [520] 651
L11: 

    /** scanner.e:2234				CompileErr(EXPECTING_AS_OR_ENDOF_LINE_UNEXPECTED_TEXT_ON_INCLUDE_DIRECTIVE)*/
    RefDS(_22190);
    _50CompileErr(100, _22190, 0);
    goto L1C; // [533] 651
L10: 

    /** scanner.e:2237		elsif find(ch, {'\n', '\r', END_OF_FILE_CHAR}) then*/
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 10;
    ((intptr_t*)_2)[2] = 13;
    ((intptr_t*)_2)[3] = 26;
    _15727 = MAKE_SEQ(_1);
    _15728 = find_from(_ch_28530, _15727, 1);
    DeRefDS(_15727);
    _15727 = NOVALUE;
    if (_15728 == 0)
    {
        _15728 = NOVALUE;
        goto L1D; // [551] 561
    }
    else{
        _15728 = NOVALUE;
    }

    /** scanner.e:2238			ungetch()*/
    _62ungetch();
    goto L1C; // [558] 651
L1D: 

    /** scanner.e:2240		elsif ch = '-' then*/
    if (_ch_28530 != 45)
    goto L1E; // [563] 601

    /** scanner.e:2241			ch = getch()*/
    _ch_28530 = _62getch();
    if (!IS_ATOM_INT(_ch_28530)) {
        _1 = (object)(DBL_PTR(_ch_28530)->dbl);
        DeRefDS(_ch_28530);
        _ch_28530 = _1;
    }

    /** scanner.e:2242			if ch != '-' then*/
    if (_ch_28530 == 45)
    goto L1F; // [576] 590

    /** scanner.e:2243				CompileErr(EXPECTING_AS_OR_ENDOF_LINE_UNEXPECTED_TEXT_ON_INCLUDE_DIRECTIVE)*/
    RefDS(_22190);
    _50CompileErr(100, _22190, 0);
L1F: 

    /** scanner.e:2245			ungetch()*/
    _62ungetch();

    /** scanner.e:2246			ungetch()*/
    _62ungetch();
    goto L1C; // [598] 651
L1E: 

    /** scanner.e:2248		elsif ch = '/' then*/
    if (_ch_28530 != 47)
    goto L20; // [603] 641

    /** scanner.e:2249			ch = getch()*/
    _ch_28530 = _62getch();
    if (!IS_ATOM_INT(_ch_28530)) {
        _1 = (object)(DBL_PTR(_ch_28530)->dbl);
        DeRefDS(_ch_28530);
        _ch_28530 = _1;
    }

    /** scanner.e:2250			if ch != '*' then*/
    if (_ch_28530 == 42)
    goto L21; // [616] 630

    /** scanner.e:2251				CompileErr(EXPECTING_AS_OR_ENDOF_LINE_UNEXPECTED_TEXT_ON_INCLUDE_DIRECTIVE)*/
    RefDS(_22190);
    _50CompileErr(100, _22190, 0);
L21: 

    /** scanner.e:2253			ungetch()*/
    _62ungetch();

    /** scanner.e:2254			ungetch()*/
    _62ungetch();
    goto L1C; // [638] 651
L20: 

    /** scanner.e:2257			CompileErr(EXPECTING_AS_OR_ENDOF_LINE_UNEXPECTED_TEXT_ON_INCLUDE_DIRECTIVE)*/
    RefDS(_22190);
    _50CompileErr(100, _22190, 0);
L1C: 

    /** scanner.e:2260		start_include = TRUE -- let scanner know*/
    _62start_include_25873 = _13TRUE_447;

    /** scanner.e:2261		public_include = is_public*/
    _62public_include_25876 = _is_public_28529;

    /** scanner.e:2262	end procedure*/
    DeRef(_gtext_28531);
    DeRef(_s_28533);
    DeRef(_15695);
    _15695 = NOVALUE;
    DeRef(_15712);
    _15712 = NOVALUE;
    _15717 = NOVALUE;
    DeRef(_15703);
    _15703 = NOVALUE;
    DeRef(_15669);
    _15669 = NOVALUE;
    DeRef(_15707);
    _15707 = NOVALUE;
    return;
    ;
}


void _62main_file()
{
    object _15737 = NOVALUE;
    object _15736 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:2275		if repl and top_level_block = -1 then*/
    if (0 == 0) {
        goto L1; // [5] 29
    }
    _15737 = (_65top_level_block_25441 == -1);
    if (_15737 == 0)
    {
        DeRef(_15737);
        _15737 = NOVALUE;
        goto L1; // [16] 29
    }
    else{
        DeRef(_15737);
        _15737 = NOVALUE;
    }

    /** scanner.e:2276			top_level_block = current_block*/
    _65top_level_block_25441 = _65current_block_25440;
L1: 

    /** scanner.e:2278		ifdef STDDEBUG then*/

    /** scanner.e:2283			read_line()*/
    _62read_line();

    /** scanner.e:2284			default_namespace( )*/
    _62default_namespace();

    /** scanner.e:2286	end procedure*/
    return;
    ;
}


void _62cleanup_open_includes()
{
    object _15740 = NOVALUE;
    object _15739 = NOVALUE;
    object _15738 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:2289		for i = 1 to length( IncludeStk ) do*/
    if (IS_SEQUENCE(_62IncludeStk_25882)){
            _15738 = SEQ_PTR(_62IncludeStk_25882)->length;
    }
    else {
        _15738 = 1;
    }
    {
        object _i_28670;
        _i_28670 = 1;
L1: 
        if (_i_28670 > _15738){
            goto L2; // [8] 36
        }

        /** scanner.e:2290			close( IncludeStk[i][FILE_PTR] )*/
        _2 = (object)SEQ_PTR(_62IncludeStk_25882);
        _15739 = (object)*(((s1_ptr)_2)->base + _i_28670);
        _2 = (object)SEQ_PTR(_15739);
        _15740 = (object)*(((s1_ptr)_2)->base + 3);
        _15739 = NOVALUE;
        if (IS_ATOM_INT(_15740))
        EClose(_15740);
        else
        EClose((object)DBL_PTR(_15740)->dbl);
        _15740 = NOVALUE;

        /** scanner.e:2291		end for*/
        _i_28670 = _i_28670 + 1;
        goto L1; // [31] 15
L2: 
        ;
    }

    /** scanner.e:2292	end procedure*/
    return;
    ;
}



// 0x8502B8BA
