// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _40get_text(object _MsgNum_19860, object _LocalQuals_19861, object _DBBase_19862)
{
    object _db_res_19864 = NOVALUE;
    object _lMsgText_19865 = NOVALUE;
    object _dbname_19866 = NOVALUE;
    object _11117 = NOVALUE;
    object _11115 = NOVALUE;
    object _11113 = NOVALUE;
    object _11112 = NOVALUE;
    object _11111 = NOVALUE;
    object _11109 = NOVALUE;
    object _11108 = NOVALUE;
    object _11107 = NOVALUE;
    object _11101 = NOVALUE;
    object _11100 = NOVALUE;
    object _11099 = NOVALUE;
    object _11092 = NOVALUE;
    object _11089 = NOVALUE;
    object _11087 = NOVALUE;
    object _11085 = NOVALUE;
    object _11084 = NOVALUE;
    object _11083 = NOVALUE;
    object _11082 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_MsgNum_19860)) {
        _1 = (object)(DBL_PTR(_MsgNum_19860)->dbl);
        DeRefDS(_MsgNum_19860);
        _MsgNum_19860 = _1;
    }

    /** locale.e:798		db_res = -1*/
    _db_res_19864 = -1;

    /** locale.e:799		lMsgText = 0*/
    DeRef(_lMsgText_19865);
    _lMsgText_19865 = 0;

    /** locale.e:801		if string(LocalQuals) and length(LocalQuals) > 0 then*/
    RefDS(_LocalQuals_19861);
    _11082 = _13string(_LocalQuals_19861);
    if (IS_ATOM_INT(_11082)) {
        if (_11082 == 0) {
            goto L1; // [23] 45
        }
    }
    else {
        if (DBL_PTR(_11082)->dbl == 0.0) {
            goto L1; // [23] 45
        }
    }
    if (IS_SEQUENCE(_LocalQuals_19861)){
            _11084 = SEQ_PTR(_LocalQuals_19861)->length;
    }
    else {
        _11084 = 1;
    }
    _11085 = (_11084 > 0);
    _11084 = NOVALUE;
    if (_11085 == 0)
    {
        DeRef(_11085);
        _11085 = NOVALUE;
        goto L1; // [35] 45
    }
    else{
        DeRef(_11085);
        _11085 = NOVALUE;
    }

    /** locale.e:802			LocalQuals = {LocalQuals}*/
    _0 = _LocalQuals_19861;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_LocalQuals_19861);
    ((intptr_t*)_2)[1] = _LocalQuals_19861;
    _LocalQuals_19861 = MAKE_SEQ(_1);
    DeRefDS(_0);
L1: 

    /** locale.e:804		for i = 1 to length(LocalQuals) do*/
    if (IS_SEQUENCE(_LocalQuals_19861)){
            _11087 = SEQ_PTR(_LocalQuals_19861)->length;
    }
    else {
        _11087 = 1;
    }
    {
        object _i_19875;
        _i_19875 = 1;
L2: 
        if (_i_19875 > _11087){
            goto L3; // [50] 136
        }

        /** locale.e:805			dbname = DBBase & "_" & LocalQuals[i] & ".edb"*/
        _2 = (object)SEQ_PTR(_LocalQuals_19861);
        _11089 = (object)*(((s1_ptr)_2)->base + _i_19875);
        {
            object concat_list[4];

            concat_list[0] = _11090;
            concat_list[1] = _11089;
            concat_list[2] = _11088;
            concat_list[3] = _DBBase_19862;
            Concat_N((object_ptr)&_dbname_19866, concat_list, 4);
        }
        _11089 = NOVALUE;

        /** locale.e:806			db_res = eds:db_select( filesys:locate_file( dbname ), eds:DB_LOCK_READ_ONLY)*/
        RefDS(_dbname_19866);
        RefDS(_5);
        RefDS(_5);
        _11092 = _17locate_file(_dbname_19866, _5, _5);
        _db_res_19864 = _43db_select(_11092, 3);
        _11092 = NOVALUE;
        if (!IS_ATOM_INT(_db_res_19864)) {
            _1 = (object)(DBL_PTR(_db_res_19864)->dbl);
            DeRefDS(_db_res_19864);
            _db_res_19864 = _1;
        }

        /** locale.e:807			if db_res = eds:DB_OK then*/
        if (_db_res_19864 != 0)
        goto L4; // [87] 129

        /** locale.e:808				db_res = eds:db_select_table("1")*/
        RefDS(_11095);
        _db_res_19864 = _43db_select_table(_11095);
        if (!IS_ATOM_INT(_db_res_19864)) {
            _1 = (object)(DBL_PTR(_db_res_19864)->dbl);
            DeRefDS(_db_res_19864);
            _db_res_19864 = _1;
        }

        /** locale.e:809				if db_res = eds:DB_OK then*/
        if (_db_res_19864 != 0)
        goto L5; // [101] 128

        /** locale.e:810					lMsgText = eds:db_fetch_record(MsgNum)*/
        RefDS(_43current_table_name_17117);
        _0 = _lMsgText_19865;
        _lMsgText_19865 = _43db_fetch_record(_MsgNum_19860, _43current_table_name_17117);
        DeRef(_0);

        /** locale.e:811					if sequence(lMsgText) then*/
        _11099 = IS_SEQUENCE(_lMsgText_19865);
        if (_11099 == 0)
        {
            _11099 = NOVALUE;
            goto L6; // [119] 127
        }
        else{
            _11099 = NOVALUE;
        }

        /** locale.e:812						exit*/
        goto L3; // [124] 136
L6: 
L5: 
L4: 

        /** locale.e:816		end for*/
        _i_19875 = _i_19875 + 1;
        goto L2; // [131] 57
L3: 
        ;
    }

    /** locale.e:819		if atom(lMsgText) then*/
    _11100 = IS_ATOM(_lMsgText_19865);
    if (_11100 == 0)
    {
        _11100 = NOVALUE;
        goto L7; // [141] 281
    }
    else{
        _11100 = NOVALUE;
    }

    /** locale.e:820			dbname = filesys:locate_file( DBBase & ".edb" )*/
    Concat((object_ptr)&_11101, _DBBase_19862, _11090);
    RefDS(_5);
    RefDS(_5);
    _0 = _dbname_19866;
    _dbname_19866 = _17locate_file(_11101, _5, _5);
    DeRef(_0);
    _11101 = NOVALUE;

    /** locale.e:821			db_res = eds:db_select(	dbname, DB_LOCK_READ_ONLY)*/
    RefDS(_dbname_19866);
    _db_res_19864 = _43db_select(_dbname_19866, 3);
    if (!IS_ATOM_INT(_db_res_19864)) {
        _1 = (object)(DBL_PTR(_db_res_19864)->dbl);
        DeRefDS(_db_res_19864);
        _db_res_19864 = _1;
    }

    /** locale.e:822			if db_res = eds:DB_OK then*/
    if (_db_res_19864 != 0)
    goto L8; // [171] 280

    /** locale.e:823				db_res = eds:db_select_table("1")*/
    RefDS(_11095);
    _db_res_19864 = _43db_select_table(_11095);
    if (!IS_ATOM_INT(_db_res_19864)) {
        _1 = (object)(DBL_PTR(_db_res_19864)->dbl);
        DeRefDS(_db_res_19864);
        _db_res_19864 = _1;
    }

    /** locale.e:824				if db_res = eds:DB_OK then*/
    if (_db_res_19864 != 0)
    goto L9; // [185] 279

    /** locale.e:825					for i = 1 to length(LocalQuals) do*/
    if (IS_SEQUENCE(_LocalQuals_19861)){
            _11107 = SEQ_PTR(_LocalQuals_19861)->length;
    }
    else {
        _11107 = 1;
    }
    {
        object _i_19904;
        _i_19904 = 1;
LA: 
        if (_i_19904 > _11107){
            goto LB; // [194] 238
        }

        /** locale.e:826						lMsgText = eds:db_fetch_record({LocalQuals[i],MsgNum})*/
        _2 = (object)SEQ_PTR(_LocalQuals_19861);
        _11108 = (object)*(((s1_ptr)_2)->base + _i_19904);
        Ref(_11108);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _11108;
        ((intptr_t *)_2)[2] = _MsgNum_19860;
        _11109 = MAKE_SEQ(_1);
        _11108 = NOVALUE;
        RefDS(_43current_table_name_17117);
        _0 = _lMsgText_19865;
        _lMsgText_19865 = _43db_fetch_record(_11109, _43current_table_name_17117);
        DeRef(_0);
        _11109 = NOVALUE;

        /** locale.e:827						if sequence(lMsgText) then*/
        _11111 = IS_SEQUENCE(_lMsgText_19865);
        if (_11111 == 0)
        {
            _11111 = NOVALUE;
            goto LC; // [223] 231
        }
        else{
            _11111 = NOVALUE;
        }

        /** locale.e:828							exit*/
        goto LB; // [228] 238
LC: 

        /** locale.e:830					end for*/
        _i_19904 = _i_19904 + 1;
        goto LA; // [233] 201
LB: 
        ;
    }

    /** locale.e:831					if atom(lMsgText) then*/
    _11112 = IS_ATOM(_lMsgText_19865);
    if (_11112 == 0)
    {
        _11112 = NOVALUE;
        goto LD; // [243] 260
    }
    else{
        _11112 = NOVALUE;
    }

    /** locale.e:832						lMsgText = eds:db_fetch_record({"",MsgNum})*/
    RefDS(_5);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _5;
    ((intptr_t *)_2)[2] = _MsgNum_19860;
    _11113 = MAKE_SEQ(_1);
    RefDS(_43current_table_name_17117);
    _0 = _lMsgText_19865;
    _lMsgText_19865 = _43db_fetch_record(_11113, _43current_table_name_17117);
    DeRef(_0);
    _11113 = NOVALUE;
LD: 

    /** locale.e:834					if atom(lMsgText) then*/
    _11115 = IS_ATOM(_lMsgText_19865);
    if (_11115 == 0)
    {
        _11115 = NOVALUE;
        goto LE; // [265] 278
    }
    else{
        _11115 = NOVALUE;
    }

    /** locale.e:835						lMsgText = eds:db_fetch_record(MsgNum)*/
    RefDS(_43current_table_name_17117);
    _0 = _lMsgText_19865;
    _lMsgText_19865 = _43db_fetch_record(_MsgNum_19860, _43current_table_name_17117);
    DeRef(_0);
LE: 
L9: 
L8: 
L7: 

    /** locale.e:840		if atom(lMsgText) then*/
    _11117 = IS_ATOM(_lMsgText_19865);
    if (_11117 == 0)
    {
        _11117 = NOVALUE;
        goto LF; // [286] 298
    }
    else{
        _11117 = NOVALUE;
    }

    /** locale.e:841			return 0*/
    DeRefDS(_LocalQuals_19861);
    DeRefDS(_DBBase_19862);
    DeRef(_lMsgText_19865);
    DeRef(_dbname_19866);
    DeRef(_11082);
    _11082 = NOVALUE;
    return 0;
    goto L10; // [295] 305
LF: 

    /** locale.e:843			return lMsgText*/
    DeRefDS(_LocalQuals_19861);
    DeRefDS(_DBBase_19862);
    DeRef(_dbname_19866);
    DeRef(_11082);
    _11082 = NOVALUE;
    return _lMsgText_19865;
L10: 
    ;
}



// 0xF24A68D3
