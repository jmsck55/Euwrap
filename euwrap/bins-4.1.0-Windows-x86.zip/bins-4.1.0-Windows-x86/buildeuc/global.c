// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _36set_target_integer_size(object _sizeof_pointer_21602)
{
    object _12241 = NOVALUE;
    object _0, _1, _2;
    

    /** global.e:297		if sizeof_pointer = 4 then*/
    if (_sizeof_pointer_21602 != 4)
    goto L1; // [5] 17

    /** global.e:298			TMAXINT = max_int32*/
    DeRef(_36TMAXINT_21596);
    _36TMAXINT_21596 = 1073741823;
    goto L2; // [14] 25
L1: 

    /** global.e:300			TMAXINT = max_int64*/
    Ref(_36max_int64_21585);
    DeRef(_36TMAXINT_21596);
    _36TMAXINT_21596 = _36max_int64_21585;
L2: 

    /** global.e:303		TMININT = -TMAXINT - 1*/
    if (IS_ATOM_INT(_36TMAXINT_21596)) {
        if ((uintptr_t)_36TMAXINT_21596 == (uintptr_t)HIGH_BITS){
            _12241 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _12241 = - _36TMAXINT_21596;
        }
    }
    else {
        _12241 = unary_op(UMINUS, _36TMAXINT_21596);
    }
    DeRef(_36TMININT_21597);
    if (IS_ATOM_INT(_12241)) {
        _36TMININT_21597 = _12241 - 1;
        if ((object)((uintptr_t)_36TMININT_21597 +(uintptr_t) HIGH_BITS) >= 0){
            _36TMININT_21597 = NewDouble((eudouble)_36TMININT_21597);
        }
    }
    else {
        _36TMININT_21597 = NewDouble(DBL_PTR(_12241)->dbl - (eudouble)1);
    }
    DeRef(_12241);
    _12241 = NOVALUE;

    /** global.e:304		TMAXINT_DBL = TMAXINT*/
    Ref(_36TMAXINT_21596);
    DeRef(_36TMAXINT_DBL_21599);
    _36TMAXINT_DBL_21599 = _36TMAXINT_21596;

    /** global.e:305		TMININT_DBL = TMININT*/
    Ref(_36TMININT_21597);
    DeRef(_36TMININT_DBL_21598);
    _36TMININT_DBL_21598 = _36TMININT_21597;

    /** global.e:306	end procedure*/
    return;
    ;
}


object _36is_integer(object _o_21610)
{
    object _12249 = NOVALUE;
    object _12248 = NOVALUE;
    object _12247 = NOVALUE;
    object _12245 = NOVALUE;
    object _12243 = NOVALUE;
    object _0, _1, _2;
    

    /** global.e:310		if not atom( o ) then*/
    _12243 = IS_ATOM(_o_21610);
    if (_12243 != 0)
    goto L1; // [6] 16
    _12243 = NOVALUE;

    /** global.e:311			return 0*/
    DeRef(_o_21610);
    return 0;
L1: 

    /** global.e:314		if o = floor( o ) then*/
    if (IS_ATOM_INT(_o_21610))
    _12245 = e_floor(_o_21610);
    else
    _12245 = unary_op(FLOOR, _o_21610);
    if (binary_op_a(NOTEQ, _o_21610, _12245)){
        DeRef(_12245);
        _12245 = NOVALUE;
        goto L2; // [21] 55
    }
    DeRef(_12245);
    _12245 = NOVALUE;

    /** global.e:315			if o <= TMAXINT and o >= TMININT then*/
    if (IS_ATOM_INT(_o_21610) && IS_ATOM_INT(_36TMAXINT_21596)) {
        _12247 = (_o_21610 <= _36TMAXINT_21596);
    }
    else {
        _12247 = binary_op(LESSEQ, _o_21610, _36TMAXINT_21596);
    }
    if (IS_ATOM_INT(_12247)) {
        if (_12247 == 0) {
            goto L3; // [33] 54
        }
    }
    else {
        if (DBL_PTR(_12247)->dbl == 0.0) {
            goto L3; // [33] 54
        }
    }
    if (IS_ATOM_INT(_o_21610) && IS_ATOM_INT(_36TMININT_21597)) {
        _12249 = (_o_21610 >= _36TMININT_21597);
    }
    else {
        _12249 = binary_op(GREATEREQ, _o_21610, _36TMININT_21597);
    }
    if (_12249 == 0) {
        DeRef(_12249);
        _12249 = NOVALUE;
        goto L3; // [44] 54
    }
    else {
        if (!IS_ATOM_INT(_12249) && DBL_PTR(_12249)->dbl == 0.0){
            DeRef(_12249);
            _12249 = NOVALUE;
            goto L3; // [44] 54
        }
        DeRef(_12249);
        _12249 = NOVALUE;
    }
    DeRef(_12249);
    _12249 = NOVALUE;

    /** global.e:316				return 1*/
    DeRef(_o_21610);
    DeRef(_12247);
    _12247 = NOVALUE;
    return 1;
L3: 
L2: 

    /** global.e:319		return 0*/
    DeRef(_o_21610);
    DeRef(_12247);
    _12247 = NOVALUE;
    return 0;
    ;
}


object _36symtab_index(object _x_21634)
{
    object _12265 = NOVALUE;
    object _12264 = NOVALUE;
    object _12263 = NOVALUE;
    object _12262 = NOVALUE;
    object _12261 = NOVALUE;
    object _12260 = NOVALUE;
    object _12258 = NOVALUE;
    object _0, _1, _2;
    

    /** global.e:337		if x = 0 then*/
    if (_x_21634 != 0)
    goto L1; // [5] 18

    /** global.e:338			return TRUE -- NULL value*/
    return _13TRUE_447;
L1: 

    /** global.e:340		if x < 0 or x > length(SymTab) then*/
    _12258 = (_x_21634 < 0);
    if (_12258 != 0) {
        goto L2; // [24] 42
    }
    if (IS_SEQUENCE(_37SymTab_15637)){
            _12260 = SEQ_PTR(_37SymTab_15637)->length;
    }
    else {
        _12260 = 1;
    }
    _12261 = (_x_21634 > _12260);
    _12260 = NOVALUE;
    if (_12261 == 0)
    {
        DeRef(_12261);
        _12261 = NOVALUE;
        goto L3; // [38] 51
    }
    else{
        DeRef(_12261);
        _12261 = NOVALUE;
    }
L2: 

    /** global.e:341			return FALSE*/
    DeRef(_12258);
    _12258 = NOVALUE;
    return _13FALSE_445;
L3: 

    /** global.e:343		return find(length(SymTab[x]), {SIZEOF_VAR_ENTRY, SIZEOF_ROUTINE_ENTRY,*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _12262 = (object)*(((s1_ptr)_2)->base + _x_21634);
    if (IS_SEQUENCE(_12262)){
            _12263 = SEQ_PTR(_12262)->length;
    }
    else {
        _12263 = 1;
    }
    _12262 = NOVALUE;
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _36SIZEOF_VAR_ENTRY_21533;
    ((intptr_t*)_2)[2] = _36SIZEOF_ROUTINE_ENTRY_21530;
    ((intptr_t*)_2)[3] = _36SIZEOF_TEMP_ENTRY_21539;
    ((intptr_t*)_2)[4] = _36SIZEOF_BLOCK_ENTRY_21536;
    _12264 = MAKE_SEQ(_1);
    _12265 = find_from(_12263, _12264, 1);
    _12263 = NOVALUE;
    DeRefDS(_12264);
    _12264 = NOVALUE;
    DeRef(_12258);
    _12258 = NOVALUE;
    _12262 = NOVALUE;
    return _12265;
    ;
}



// 0x1BB4F24A
