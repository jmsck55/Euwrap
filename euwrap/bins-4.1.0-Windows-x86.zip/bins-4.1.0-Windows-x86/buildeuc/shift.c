// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _66init_op_info()
{
    object _SHORT_CIRCUIT_24988 = NOVALUE;
    object _info_25033 = NOVALUE;
    object _14045 = NOVALUE;
    object _14044 = NOVALUE;
    object _14043 = NOVALUE;
    object _14042 = NOVALUE;
    object _14041 = NOVALUE;
    object _14040 = NOVALUE;
    object _14038 = NOVALUE;
    object _14037 = NOVALUE;
    object _14036 = NOVALUE;
    object _14035 = NOVALUE;
    object _14034 = NOVALUE;
    object _14033 = NOVALUE;
    object _14032 = NOVALUE;
    object _14031 = NOVALUE;
    object _14030 = NOVALUE;
    object _14029 = NOVALUE;
    object _14028 = NOVALUE;
    object _14027 = NOVALUE;
    object _14026 = NOVALUE;
    object _14025 = NOVALUE;
    object _14024 = NOVALUE;
    object _14023 = NOVALUE;
    object _14022 = NOVALUE;
    object _14021 = NOVALUE;
    object _14019 = NOVALUE;
    object _14018 = NOVALUE;
    object _14017 = NOVALUE;
    object _14016 = NOVALUE;
    object _14015 = NOVALUE;
    object _14014 = NOVALUE;
    object _14013 = NOVALUE;
    object _14012 = NOVALUE;
    object _14011 = NOVALUE;
    object _14010 = NOVALUE;
    object _14009 = NOVALUE;
    object _14008 = NOVALUE;
    object _14007 = NOVALUE;
    object _14006 = NOVALUE;
    object _14005 = NOVALUE;
    object _14004 = NOVALUE;
    object _14003 = NOVALUE;
    object _14002 = NOVALUE;
    object _14001 = NOVALUE;
    object _14000 = NOVALUE;
    object _13999 = NOVALUE;
    object _13998 = NOVALUE;
    object _13997 = NOVALUE;
    object _13996 = NOVALUE;
    object _13995 = NOVALUE;
    object _13994 = NOVALUE;
    object _13993 = NOVALUE;
    object _13992 = NOVALUE;
    object _13991 = NOVALUE;
    object _13990 = NOVALUE;
    object _13989 = NOVALUE;
    object _13988 = NOVALUE;
    object _13987 = NOVALUE;
    object _13986 = NOVALUE;
    object _13985 = NOVALUE;
    object _13984 = NOVALUE;
    object _13983 = NOVALUE;
    object _13982 = NOVALUE;
    object _13981 = NOVALUE;
    object _13980 = NOVALUE;
    object _13979 = NOVALUE;
    object _13978 = NOVALUE;
    object _13977 = NOVALUE;
    object _13976 = NOVALUE;
    object _13975 = NOVALUE;
    object _13974 = NOVALUE;
    object _13973 = NOVALUE;
    object _13972 = NOVALUE;
    object _13970 = NOVALUE;
    object _13969 = NOVALUE;
    object _13968 = NOVALUE;
    object _13967 = NOVALUE;
    object _13966 = NOVALUE;
    object _13965 = NOVALUE;
    object _13964 = NOVALUE;
    object _13963 = NOVALUE;
    object _13962 = NOVALUE;
    object _13961 = NOVALUE;
    object _13960 = NOVALUE;
    object _13959 = NOVALUE;
    object _13958 = NOVALUE;
    object _13957 = NOVALUE;
    object _13956 = NOVALUE;
    object _13955 = NOVALUE;
    object _13954 = NOVALUE;
    object _13953 = NOVALUE;
    object _13952 = NOVALUE;
    object _13951 = NOVALUE;
    object _13950 = NOVALUE;
    object _13949 = NOVALUE;
    object _13948 = NOVALUE;
    object _13947 = NOVALUE;
    object _13946 = NOVALUE;
    object _13945 = NOVALUE;
    object _13944 = NOVALUE;
    object _13943 = NOVALUE;
    object _13942 = NOVALUE;
    object _13941 = NOVALUE;
    object _13940 = NOVALUE;
    object _13939 = NOVALUE;
    object _13938 = NOVALUE;
    object _13937 = NOVALUE;
    object _13936 = NOVALUE;
    object _13935 = NOVALUE;
    object _13934 = NOVALUE;
    object _13933 = NOVALUE;
    object _13932 = NOVALUE;
    object _13931 = NOVALUE;
    object _13930 = NOVALUE;
    object _13929 = NOVALUE;
    object _13928 = NOVALUE;
    object _13927 = NOVALUE;
    object _13926 = NOVALUE;
    object _13925 = NOVALUE;
    object _13924 = NOVALUE;
    object _13923 = NOVALUE;
    object _13922 = NOVALUE;
    object _13921 = NOVALUE;
    object _13920 = NOVALUE;
    object _13919 = NOVALUE;
    object _13918 = NOVALUE;
    object _13917 = NOVALUE;
    object _13916 = NOVALUE;
    object _13915 = NOVALUE;
    object _13914 = NOVALUE;
    object _13913 = NOVALUE;
    object _13912 = NOVALUE;
    object _13911 = NOVALUE;
    object _13910 = NOVALUE;
    object _13909 = NOVALUE;
    object _13908 = NOVALUE;
    object _13907 = NOVALUE;
    object _13906 = NOVALUE;
    object _13905 = NOVALUE;
    object _13904 = NOVALUE;
    object _13903 = NOVALUE;
    object _13902 = NOVALUE;
    object _13901 = NOVALUE;
    object _13899 = NOVALUE;
    object _13898 = NOVALUE;
    object _13897 = NOVALUE;
    object _13896 = NOVALUE;
    object _13895 = NOVALUE;
    object _13894 = NOVALUE;
    object _13893 = NOVALUE;
    object _13892 = NOVALUE;
    object _13891 = NOVALUE;
    object _13890 = NOVALUE;
    object _13889 = NOVALUE;
    object _13888 = NOVALUE;
    object _13887 = NOVALUE;
    object _13886 = NOVALUE;
    object _13885 = NOVALUE;
    object _13884 = NOVALUE;
    object _13883 = NOVALUE;
    object _13882 = NOVALUE;
    object _13881 = NOVALUE;
    object _13880 = NOVALUE;
    object _13879 = NOVALUE;
    object _13878 = NOVALUE;
    object _13877 = NOVALUE;
    object _13876 = NOVALUE;
    object _13875 = NOVALUE;
    object _13874 = NOVALUE;
    object _13873 = NOVALUE;
    object _13871 = NOVALUE;
    object _13870 = NOVALUE;
    object _13869 = NOVALUE;
    object _13868 = NOVALUE;
    object _13867 = NOVALUE;
    object _13866 = NOVALUE;
    object _13865 = NOVALUE;
    object _13864 = NOVALUE;
    object _13863 = NOVALUE;
    object _13862 = NOVALUE;
    object _13861 = NOVALUE;
    object _13860 = NOVALUE;
    object _13859 = NOVALUE;
    object _13858 = NOVALUE;
    object _13857 = NOVALUE;
    object _13856 = NOVALUE;
    object _13855 = NOVALUE;
    object _13854 = NOVALUE;
    object _13853 = NOVALUE;
    object _13852 = NOVALUE;
    object _13851 = NOVALUE;
    object _13850 = NOVALUE;
    object _13849 = NOVALUE;
    object _13848 = NOVALUE;
    object _13847 = NOVALUE;
    object _13846 = NOVALUE;
    object _13845 = NOVALUE;
    object _13844 = NOVALUE;
    object _13843 = NOVALUE;
    object _13842 = NOVALUE;
    object _13841 = NOVALUE;
    object _13840 = NOVALUE;
    object _13839 = NOVALUE;
    object _13838 = NOVALUE;
    object _13837 = NOVALUE;
    object _13836 = NOVALUE;
    object _13835 = NOVALUE;
    object _13834 = NOVALUE;
    object _13833 = NOVALUE;
    object _13832 = NOVALUE;
    object _13831 = NOVALUE;
    object _13830 = NOVALUE;
    object _13829 = NOVALUE;
    object _13828 = NOVALUE;
    object _13827 = NOVALUE;
    object _13826 = NOVALUE;
    object _13824 = NOVALUE;
    object _13823 = NOVALUE;
    object _13822 = NOVALUE;
    object _13821 = NOVALUE;
    object _13820 = NOVALUE;
    object _13819 = NOVALUE;
    object _13818 = NOVALUE;
    object _13817 = NOVALUE;
    object _13816 = NOVALUE;
    object _0, _1, _2;
    

    /** shift.e:44		op_info = repeat( 0, MAX_OPCODE )*/
    DeRef(_66op_info_24561);
    _66op_info_24561 = Repeat(0, 218);

    /** shift.e:45		op_info_size_type = repeat( 0, MAX_OPCODE )*/
    DeRef(_66op_info_size_type_24567);
    _66op_info_size_type_24567 = Repeat(0, 218);

    /** shift.e:46		op_info_size = repeat( 0, MAX_OPCODE )*/
    DeRef(_66op_info_size_24568);
    _66op_info_size_24568 = Repeat(0, 218);

    /** shift.e:47		op_info_addr = repeat( 0, MAX_OPCODE )*/
    DeRef(_66op_info_addr_24569);
    _66op_info_addr_24569 = Repeat(0, 218);

    /** shift.e:48		op_info_target = repeat( 0, MAX_OPCODE )*/
    DeRef(_66op_info_target_24570);
    _66op_info_target_24570 = Repeat(0, 218);

    /** shift.e:49		op_info_sub = repeat( 0, MAX_OPCODE )*/
    DeRef(_66op_info_sub_24571);
    _66op_info_sub_24571 = Repeat(0, 218);

    /** shift.e:51		op_info[ABORT               ] = { FIXED_SIZE, 2, {}, {}, {} }   -- ary: pun*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 2;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13816 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 126);
    *(intptr_t *)_2 = _13816;
    if( _1 != _13816 ){
    }
    _13816 = NOVALUE;

    /** shift.e:52		op_info[AND                 ] = { FIXED_SIZE, 4, {}, {}, {} }   -- ary: bin*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13817 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 8);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13817;
    if( _1 != _13817 ){
        DeRef(_1);
    }
    _13817 = NOVALUE;

    /** shift.e:53		op_info[AND_BITS            ] = { FIXED_SIZE, 4, {}, {3}, {} }   -- ary: bin*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13436);
    ((intptr_t*)_2)[4] = _13436;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13818 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 56);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13818;
    if( _1 != _13818 ){
        DeRef(_1);
    }
    _13818 = NOVALUE;

    /** shift.e:54		op_info[APPEND              ] = { FIXED_SIZE, 4, {}, {3}, {} }   -- ary: bin*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13436);
    ((intptr_t*)_2)[4] = _13436;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13819 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 35);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13819;
    if( _1 != _13819 ){
        DeRef(_1);
    }
    _13819 = NOVALUE;

    /** shift.e:55		op_info[ARCTAN              ] = { FIXED_SIZE, 3, {}, {2}, {} }   -- ary: un*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13499);
    ((intptr_t*)_2)[4] = _13499;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13820 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 73);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13820;
    if( _1 != _13820 ){
        DeRef(_1);
    }
    _13820 = NOVALUE;

    /** shift.e:56		op_info[ASSIGN              ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13499);
    ((intptr_t*)_2)[4] = _13499;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13821 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 18);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13821;
    if( _1 != _13821 ){
        DeRef(_1);
    }
    _13821 = NOVALUE;

    /** shift.e:57		op_info[ASSIGN_I            ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13499);
    ((intptr_t*)_2)[4] = _13499;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13822 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 113);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13822;
    if( _1 != _13822 ){
        DeRef(_1);
    }
    _13822 = NOVALUE;

    /** shift.e:58		op_info[ASSIGN_OP_SLICE     ] = { FIXED_SIZE, 5, {}, {4}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 5;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13659);
    ((intptr_t*)_2)[4] = _13659;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13823 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 150);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13823;
    if( _1 != _13823 ){
        DeRef(_1);
    }
    _13823 = NOVALUE;

    /** shift.e:59		op_info[ASSIGN_OP_SUBS      ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13436);
    ((intptr_t*)_2)[4] = _13436;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13824 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 149);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13824;
    if( _1 != _13824 ){
        DeRef(_1);
    }
    _13824 = NOVALUE;

    /** shift.e:60		op_info[ASSIGN_SLICE        ] = { FIXED_SIZE, 5, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 5;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13825);
    ((intptr_t*)_2)[4] = _13825;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13826 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 45);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13826;
    if( _1 != _13826 ){
        DeRef(_1);
    }
    _13826 = NOVALUE;

    /** shift.e:61		op_info[ASSIGN_SUBS         ] = { FIXED_SIZE, 4, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13825);
    ((intptr_t*)_2)[4] = _13825;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13827 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 16);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13827;
    if( _1 != _13827 ){
        DeRef(_1);
    }
    _13827 = NOVALUE;

    /** shift.e:62		op_info[ASSIGN_SUBS_CHECK   ] = { FIXED_SIZE, 4, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13825);
    ((intptr_t*)_2)[4] = _13825;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13828 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 84);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13828;
    if( _1 != _13828 ){
        DeRef(_1);
    }
    _13828 = NOVALUE;

    /** shift.e:63		op_info[ASSIGN_SUBS_I       ] = { FIXED_SIZE, 4, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13825);
    ((intptr_t*)_2)[4] = _13825;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13829 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 118);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13829;
    if( _1 != _13829 ){
        DeRef(_1);
    }
    _13829 = NOVALUE;

    /** shift.e:64		op_info[BADRETURNF          ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 1;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13830 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 43);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13830;
    if( _1 != _13830 ){
        DeRef(_1);
    }
    _13830 = NOVALUE;

    /** shift.e:65		op_info[CALL                ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 2;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13831 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 129);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13831;
    if( _1 != _13831 ){
        DeRef(_1);
    }
    _13831 = NOVALUE;

    /** shift.e:66		op_info[CALL_PROC           ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13832 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 136);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13832;
    if( _1 != _13832 ){
        DeRef(_1);
    }
    _13832 = NOVALUE;

    /** shift.e:67		op_info[CALL_FUNC           ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13436);
    ((intptr_t*)_2)[4] = _13436;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13833 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 137);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13833;
    if( _1 != _13833 ){
        DeRef(_1);
    }
    _13833 = NOVALUE;

    /** shift.e:68		op_info[CASE                ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 2;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13834 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 186);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13834;
    if( _1 != _13834 ){
        DeRef(_1);
    }
    _13834 = NOVALUE;

    /** shift.e:69		op_info[CLEAR_SCREEN        ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 1;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13835 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 59);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13835;
    if( _1 != _13835 ){
        DeRef(_1);
    }
    _13835 = NOVALUE;

    /** shift.e:70		op_info[CLOSE               ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 2;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13836 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 86);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13836;
    if( _1 != _13836 ){
        DeRef(_1);
    }
    _13836 = NOVALUE;

    /** shift.e:71		op_info[COMMAND_LINE        ] = { FIXED_SIZE, 2, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 2;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13825);
    ((intptr_t*)_2)[4] = _13825;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13837 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 100);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13837;
    if( _1 != _13837 ){
        DeRef(_1);
    }
    _13837 = NOVALUE;

    /** shift.e:72		op_info[COMPARE             ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13436);
    ((intptr_t*)_2)[4] = _13436;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13838 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 76);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13838;
    if( _1 != _13838 ){
        DeRef(_1);
    }
    _13838 = NOVALUE;

    /** shift.e:73		op_info[CONCAT              ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13436);
    ((intptr_t*)_2)[4] = _13436;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13839 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 15);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13839;
    if( _1 != _13839 ){
        DeRef(_1);
    }
    _13839 = NOVALUE;

    /** shift.e:74		op_info[COS                 ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13499);
    ((intptr_t*)_2)[4] = _13499;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13840 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 81);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13840;
    if( _1 != _13840 ){
        DeRef(_1);
    }
    _13840 = NOVALUE;

    /** shift.e:75		op_info[COVERAGE_LINE       ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 2;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13841 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 210);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13841;
    if( _1 != _13841 ){
        DeRef(_1);
    }
    _13841 = NOVALUE;

    /** shift.e:76		op_info[COVERAGE_ROUTINE    ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 2;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13842 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 211);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13842;
    if( _1 != _13842 ){
        DeRef(_1);
    }
    _13842 = NOVALUE;

    /** shift.e:77		op_info[C_FUNC              ] = { FIXED_SIZE, 5, {}, {4}, {3} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 5;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13659);
    ((intptr_t*)_2)[4] = _13659;
    RefDS(_13436);
    ((intptr_t*)_2)[5] = _13436;
    _13843 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 133);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13843;
    if( _1 != _13843 ){
        DeRef(_1);
    }
    _13843 = NOVALUE;

    /** shift.e:78		op_info[C_PROC              ] = { FIXED_SIZE, 4, {}, {}, {3} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    RefDS(_13436);
    ((intptr_t*)_2)[5] = _13436;
    _13844 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 132);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13844;
    if( _1 != _13844 ){
        DeRef(_1);
    }
    _13844 = NOVALUE;

    /** shift.e:79		op_info[DATE                ] = { FIXED_SIZE, 2, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 2;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13825);
    ((intptr_t*)_2)[4] = _13825;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13845 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 69);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13845;
    if( _1 != _13845 ){
        DeRef(_1);
    }
    _13845 = NOVALUE;

    /** shift.e:80		op_info[DELETE_ROUTINE      ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13436);
    ((intptr_t*)_2)[4] = _13436;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13846 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 204);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13846;
    if( _1 != _13846 ){
        DeRef(_1);
    }
    _13846 = NOVALUE;

    /** shift.e:81		op_info[DELETE_OBJECT       ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 2;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13847 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 205);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13847;
    if( _1 != _13847 ){
        DeRef(_1);
    }
    _13847 = NOVALUE;

    /** shift.e:82		op_info[DIV2                ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13436);
    ((intptr_t*)_2)[4] = _13436;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13848 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 98);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13848;
    if( _1 != _13848 ){
        DeRef(_1);
    }
    _13848 = NOVALUE;

    /** shift.e:83		op_info[DIVIDE              ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13436);
    ((intptr_t*)_2)[4] = _13436;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13849 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 14);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13849;
    if( _1 != _13849 ){
        DeRef(_1);
    }
    _13849 = NOVALUE;

    /** shift.e:84		op_info[ELSE                ] = { FIXED_SIZE, 2, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 2;
    RefDS(_13825);
    ((intptr_t*)_2)[3] = _13825;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13850 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 23);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13850;
    if( _1 != _13850 ){
        DeRef(_1);
    }
    _13850 = NOVALUE;

    /** shift.e:85		op_info[EXIT                ] = { FIXED_SIZE, 2, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 2;
    RefDS(_13825);
    ((intptr_t*)_2)[3] = _13825;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13851 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 61);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13851;
    if( _1 != _13851 ){
        DeRef(_1);
    }
    _13851 = NOVALUE;

    /** shift.e:86		op_info[EXIT_BLOCK          ] = { FIXED_SIZE, 2, {},  {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 2;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13852 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 206);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13852;
    if( _1 != _13852 ){
        DeRef(_1);
    }
    _13852 = NOVALUE;

    /** shift.e:87		op_info[ENDWHILE            ] = { FIXED_SIZE, 2, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 2;
    RefDS(_13825);
    ((intptr_t*)_2)[3] = _13825;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13853 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 22);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13853;
    if( _1 != _13853 ){
        DeRef(_1);
    }
    _13853 = NOVALUE;

    /** shift.e:88		op_info[RETRY               ] = { FIXED_SIZE, 2, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 2;
    RefDS(_13825);
    ((intptr_t*)_2)[3] = _13825;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13854 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 184);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13854;
    if( _1 != _13854 ){
        DeRef(_1);
    }
    _13854 = NOVALUE;

    /** shift.e:89		op_info[GOTO                ] = { FIXED_SIZE, 2, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 2;
    RefDS(_13825);
    ((intptr_t*)_2)[3] = _13825;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13855 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 188);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13855;
    if( _1 != _13855 ){
        DeRef(_1);
    }
    _13855 = NOVALUE;

    /** shift.e:90		op_info[ENDFOR_GENERAL      ] = { FIXED_SIZE, 5, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 5;
    RefDS(_13825);
    ((intptr_t*)_2)[3] = _13825;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13856 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 39);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13856;
    if( _1 != _13856 ){
        DeRef(_1);
    }
    _13856 = NOVALUE;

    /** shift.e:91		op_info[ENDFOR_UP           ] = { FIXED_SIZE, 4, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_13825);
    ((intptr_t*)_2)[3] = _13825;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13857 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 49);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13857;
    if( _1 != _13857 ){
        DeRef(_1);
    }
    _13857 = NOVALUE;

    /** shift.e:92		op_info[ENDFOR_DOWN         ] = { FIXED_SIZE, 4, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_13825);
    ((intptr_t*)_2)[3] = _13825;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13858 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 50);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13858;
    if( _1 != _13858 ){
        DeRef(_1);
    }
    _13858 = NOVALUE;

    /** shift.e:93		op_info[ENDFOR_INT_UP       ] = { FIXED_SIZE, 4, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_13825);
    ((intptr_t*)_2)[3] = _13825;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13859 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 48);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13859;
    if( _1 != _13859 ){
        DeRef(_1);
    }
    _13859 = NOVALUE;

    /** shift.e:94		op_info[ENDFOR_INT_DOWN     ] = { FIXED_SIZE, 4, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_13825);
    ((intptr_t*)_2)[3] = _13825;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13860 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 52);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13860;
    if( _1 != _13860 ){
        DeRef(_1);
    }
    _13860 = NOVALUE;

    /** shift.e:95		op_info[ENDFOR_INT_DOWN1    ] = { FIXED_SIZE, 4, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_13825);
    ((intptr_t*)_2)[3] = _13825;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13861 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 55);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13861;
    if( _1 != _13861 ){
        DeRef(_1);
    }
    _13861 = NOVALUE;

    /** shift.e:96		op_info[ENDFOR_INT_UP1      ] = { FIXED_SIZE, 5, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 5;
    RefDS(_13825);
    ((intptr_t*)_2)[3] = _13825;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13862 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 54);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13862;
    if( _1 != _13862 ){
        DeRef(_1);
    }
    _13862 = NOVALUE;

    /** shift.e:97		op_info[EQUAL               ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13436);
    ((intptr_t*)_2)[4] = _13436;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13863 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 153);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13863;
    if( _1 != _13863 ){
        DeRef(_1);
    }
    _13863 = NOVALUE;

    /** shift.e:98		op_info[EQUALS              ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13436);
    ((intptr_t*)_2)[4] = _13436;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13864 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13864;
    if( _1 != _13864 ){
        DeRef(_1);
    }
    _13864 = NOVALUE;

    /** shift.e:99		op_info[EQUALS_IFW          ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_13436);
    ((intptr_t*)_2)[3] = _13436;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13865 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 104);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13865;
    if( _1 != _13865 ){
        DeRef(_1);
    }
    _13865 = NOVALUE;

    /** shift.e:100		op_info[EQUALS_IFW_I        ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_13436);
    ((intptr_t*)_2)[3] = _13436;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13866 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 121);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13866;
    if( _1 != _13866 ){
        DeRef(_1);
    }
    _13866 = NOVALUE;

    /** shift.e:101		op_info[FIND                ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13436);
    ((intptr_t*)_2)[4] = _13436;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13867 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 77);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13867;
    if( _1 != _13867 ){
        DeRef(_1);
    }
    _13867 = NOVALUE;

    /** shift.e:102		op_info[FIND_FROM           ] = { FIXED_SIZE, 5, {}, {4}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 5;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13659);
    ((intptr_t*)_2)[4] = _13659;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13868 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 176);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13868;
    if( _1 != _13868 ){
        DeRef(_1);
    }
    _13868 = NOVALUE;

    /** shift.e:103		op_info[FLOOR               ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13499);
    ((intptr_t*)_2)[4] = _13499;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13869 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 83);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13869;
    if( _1 != _13869 ){
        DeRef(_1);
    }
    _13869 = NOVALUE;

    /** shift.e:104		op_info[FLOOR_DIV           ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13436);
    ((intptr_t*)_2)[4] = _13436;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13870 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 63);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13870;
    if( _1 != _13870 ){
        DeRef(_1);
    }
    _13870 = NOVALUE;

    /** shift.e:105		op_info[FLOOR_DIV2          ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13436);
    ((intptr_t*)_2)[4] = _13436;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13871 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 66);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13871;
    if( _1 != _13871 ){
        DeRef(_1);
    }
    _13871 = NOVALUE;

    /** shift.e:106		op_info[FOR                 ] = { FIXED_SIZE, 7, {6}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 7;
    RefDS(_13872);
    ((intptr_t*)_2)[3] = _13872;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13873 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 21);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13873;
    if( _1 != _13873 ){
        DeRef(_1);
    }
    _13873 = NOVALUE;

    /** shift.e:107		op_info[FOR_I               ] = { FIXED_SIZE, 7, {6}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 7;
    RefDS(_13872);
    ((intptr_t*)_2)[3] = _13872;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13874 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 125);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13874;
    if( _1 != _13874 ){
        DeRef(_1);
    }
    _13874 = NOVALUE;

    /** shift.e:108		op_info[GETC                ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13499);
    ((intptr_t*)_2)[4] = _13499;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13875 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13875;
    if( _1 != _13875 ){
        DeRef(_1);
    }
    _13875 = NOVALUE;

    /** shift.e:109		op_info[GETENV              ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13499);
    ((intptr_t*)_2)[4] = _13499;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13876 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 91);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13876;
    if( _1 != _13876 ){
        DeRef(_1);
    }
    _13876 = NOVALUE;

    /** shift.e:110		op_info[GETS                ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13499);
    ((intptr_t*)_2)[4] = _13499;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13877 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 17);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13877;
    if( _1 != _13877 ){
        DeRef(_1);
    }
    _13877 = NOVALUE;

    /** shift.e:111		op_info[GET_KEY             ] = { FIXED_SIZE, 2, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 2;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13825);
    ((intptr_t*)_2)[4] = _13825;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13878 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 79);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13878;
    if( _1 != _13878 ){
        DeRef(_1);
    }
    _13878 = NOVALUE;

    /** shift.e:112		op_info[GLABEL              ] = { FIXED_SIZE, 2, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 2;
    RefDS(_13825);
    ((intptr_t*)_2)[3] = _13825;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13879 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 189);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13879;
    if( _1 != _13879 ){
        DeRef(_1);
    }
    _13879 = NOVALUE;

    /** shift.e:113		op_info[GLOBAL_INIT_CHECK   ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 2;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13880 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 109);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13880;
    if( _1 != _13880 ){
        DeRef(_1);
    }
    _13880 = NOVALUE;

    /** shift.e:114		op_info[PRIVATE_INIT_CHECK  ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 2;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13881 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 30);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13881;
    if( _1 != _13881 ){
        DeRef(_1);
    }
    _13881 = NOVALUE;

    /** shift.e:115		op_info[GREATER             ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13436);
    ((intptr_t*)_2)[4] = _13436;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13882 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 6);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13882;
    if( _1 != _13882 ){
        DeRef(_1);
    }
    _13882 = NOVALUE;

    /** shift.e:116		op_info[GREATEREQ           ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13436);
    ((intptr_t*)_2)[4] = _13436;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13883 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13883;
    if( _1 != _13883 ){
        DeRef(_1);
    }
    _13883 = NOVALUE;

    /** shift.e:117		op_info[GREATEREQ_IFW       ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_13436);
    ((intptr_t*)_2)[3] = _13436;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13884 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 103);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13884;
    if( _1 != _13884 ){
        DeRef(_1);
    }
    _13884 = NOVALUE;

    /** shift.e:118		op_info[GREATEREQ_IFW_I     ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_13436);
    ((intptr_t*)_2)[3] = _13436;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13885 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 120);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13885;
    if( _1 != _13885 ){
        DeRef(_1);
    }
    _13885 = NOVALUE;

    /** shift.e:119		op_info[GREATER_IFW         ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_13436);
    ((intptr_t*)_2)[3] = _13436;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13886 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 107);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13886;
    if( _1 != _13886 ){
        DeRef(_1);
    }
    _13886 = NOVALUE;

    /** shift.e:120		op_info[GREATER_IFW_I       ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_13436);
    ((intptr_t*)_2)[3] = _13436;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13887 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 124);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13887;
    if( _1 != _13887 ){
        DeRef(_1);
    }
    _13887 = NOVALUE;

    /** shift.e:121		op_info[HASH                ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13436);
    ((intptr_t*)_2)[4] = _13436;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13888 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 194);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13888;
    if( _1 != _13888 ){
        DeRef(_1);
    }
    _13888 = NOVALUE;

    /** shift.e:122		op_info[HEAD                ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13436);
    ((intptr_t*)_2)[4] = _13436;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13889 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 198);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13889;
    if( _1 != _13889 ){
        DeRef(_1);
    }
    _13889 = NOVALUE;

    /** shift.e:123		op_info[IF                  ] = { FIXED_SIZE, 3, {2}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDS(_13499);
    ((intptr_t*)_2)[3] = _13499;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13890 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 20);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13890;
    if( _1 != _13890 ){
        DeRef(_1);
    }
    _13890 = NOVALUE;

    /** shift.e:124		op_info[INSERT              ] = { FIXED_SIZE, 5, {}, {4}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 5;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13659);
    ((intptr_t*)_2)[4] = _13659;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13891 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 191);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13891;
    if( _1 != _13891 ){
        DeRef(_1);
    }
    _13891 = NOVALUE;

    /** shift.e:125		op_info[LENGTH              ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13499);
    ((intptr_t*)_2)[4] = _13499;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13892 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 42);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13892;
    if( _1 != _13892 ){
        DeRef(_1);
    }
    _13892 = NOVALUE;

    /** shift.e:126		op_info[LESS                ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13436);
    ((intptr_t*)_2)[4] = _13436;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13893 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13893;
    if( _1 != _13893 ){
        DeRef(_1);
    }
    _13893 = NOVALUE;

    /** shift.e:127		op_info[LESSEQ              ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13436);
    ((intptr_t*)_2)[4] = _13436;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13894 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13894;
    if( _1 != _13894 ){
        DeRef(_1);
    }
    _13894 = NOVALUE;

    /** shift.e:128		op_info[LESSEQ_IFW          ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_13436);
    ((intptr_t*)_2)[3] = _13436;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13895 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 106);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13895;
    if( _1 != _13895 ){
        DeRef(_1);
    }
    _13895 = NOVALUE;

    /** shift.e:129		op_info[LESSEQ_IFW_I        ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_13436);
    ((intptr_t*)_2)[3] = _13436;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13896 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 123);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13896;
    if( _1 != _13896 ){
        DeRef(_1);
    }
    _13896 = NOVALUE;

    /** shift.e:130		op_info[LESS_IFW            ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_13436);
    ((intptr_t*)_2)[3] = _13436;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13897 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 102);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13897;
    if( _1 != _13897 ){
        DeRef(_1);
    }
    _13897 = NOVALUE;

    /** shift.e:131		op_info[LESS_IFW_I          ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_13436);
    ((intptr_t*)_2)[3] = _13436;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13898 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 119);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13898;
    if( _1 != _13898 ){
        DeRef(_1);
    }
    _13898 = NOVALUE;

    /** shift.e:132		op_info[LHS_SUBS            ] = { FIXED_SIZE, 5, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 5;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13436);
    ((intptr_t*)_2)[4] = _13436;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13899 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 95);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13899;
    if( _1 != _13899 ){
        DeRef(_1);
    }
    _13899 = NOVALUE;

    /** shift.e:133		op_info[LHS_SUBS1           ] = { FIXED_SIZE, 5, {}, {3,4}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 5;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13900);
    ((intptr_t*)_2)[4] = _13900;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13901 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 161);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13901;
    if( _1 != _13901 ){
        DeRef(_1);
    }
    _13901 = NOVALUE;

    /** shift.e:134		op_info[LHS_SUBS1_COPY      ] = { FIXED_SIZE, 5, {}, {3,4}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 5;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13900);
    ((intptr_t*)_2)[4] = _13900;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13902 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 166);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13902;
    if( _1 != _13902 ){
        DeRef(_1);
    }
    _13902 = NOVALUE;

    /** shift.e:135		op_info[LOG                 ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13499);
    ((intptr_t*)_2)[4] = _13499;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13903 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 74);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13903;
    if( _1 != _13903 ){
        DeRef(_1);
    }
    _13903 = NOVALUE;

    /** shift.e:136		op_info[MACHINE_FUNC        ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13436);
    ((intptr_t*)_2)[4] = _13436;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13904 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 111);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13904;
    if( _1 != _13904 ){
        DeRef(_1);
    }
    _13904 = NOVALUE;

    /** shift.e:137		op_info[MACHINE_PROC        ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13905 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 112);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13905;
    if( _1 != _13905 ){
        DeRef(_1);
    }
    _13905 = NOVALUE;

    /** shift.e:138		op_info[MATCH               ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13436);
    ((intptr_t*)_2)[4] = _13436;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13906 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 78);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13906;
    if( _1 != _13906 ){
        DeRef(_1);
    }
    _13906 = NOVALUE;

    /** shift.e:139		op_info[MATCH_FROM          ] = { FIXED_SIZE, 5, {}, {4}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 5;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13659);
    ((intptr_t*)_2)[4] = _13659;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13907 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 177);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13907;
    if( _1 != _13907 ){
        DeRef(_1);
    }
    _13907 = NOVALUE;

    /** shift.e:140		op_info[MEM_COPY            ] = { FIXED_SIZE, 4, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13908 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 130);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13908;
    if( _1 != _13908 ){
        DeRef(_1);
    }
    _13908 = NOVALUE;

    /** shift.e:141		op_info[MEM_SET             ] = { FIXED_SIZE, 4, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13909 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 131);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13909;
    if( _1 != _13909 ){
        DeRef(_1);
    }
    _13909 = NOVALUE;

    /** shift.e:142		op_info[MINUS               ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13436);
    ((intptr_t*)_2)[4] = _13436;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13910 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 10);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13910;
    if( _1 != _13910 ){
        DeRef(_1);
    }
    _13910 = NOVALUE;

    /** shift.e:143		op_info[MINUS_I             ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13436);
    ((intptr_t*)_2)[4] = _13436;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13911 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 116);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13911;
    if( _1 != _13911 ){
        DeRef(_1);
    }
    _13911 = NOVALUE;

    /** shift.e:144		op_info[MULTIPLY            ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13436);
    ((intptr_t*)_2)[4] = _13436;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13912 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 13);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13912;
    if( _1 != _13912 ){
        DeRef(_1);
    }
    _13912 = NOVALUE;

    /** shift.e:145		op_info[NOP1                ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 1;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13913 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 159);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13913;
    if( _1 != _13913 ){
        DeRef(_1);
    }
    _13913 = NOVALUE;

    /** shift.e:146		op_info[NOPWHILE            ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 1;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13914 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 158);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13914;
    if( _1 != _13914 ){
        DeRef(_1);
    }
    _13914 = NOVALUE;

    /** shift.e:147		op_info[NOP2                ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 2;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13915 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 110);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13915;
    if( _1 != _13915 ){
        DeRef(_1);
    }
    _13915 = NOVALUE;

    /** shift.e:148		op_info[SC2_NULL            ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 2;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13916 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 145);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13916;
    if( _1 != _13916 ){
        DeRef(_1);
    }
    _13916 = NOVALUE;

    /** shift.e:149		op_info[ASSIGN_SUBS2        ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 2;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13917 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 148);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13917;
    if( _1 != _13917 ){
        DeRef(_1);
    }
    _13917 = NOVALUE;

    /** shift.e:150		op_info[PLATFORM            ] = { FIXED_SIZE, 2, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 2;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13825);
    ((intptr_t*)_2)[4] = _13825;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13918 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 155);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13918;
    if( _1 != _13918 ){
        DeRef(_1);
    }
    _13918 = NOVALUE;

    /** shift.e:151		op_info[END_PARAM_CHECK     ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 2;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13919 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 156);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13919;
    if( _1 != _13919 ){
        DeRef(_1);
    }
    _13919 = NOVALUE;

    /** shift.e:153		op_info[NOPSWITCH           ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 1;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13920 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 187);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13920;
    if( _1 != _13920 ){
        DeRef(_1);
    }
    _13920 = NOVALUE;

    /** shift.e:154		op_info[NOT                 ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13499);
    ((intptr_t*)_2)[4] = _13499;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13921 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 7);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13921;
    if( _1 != _13921 ){
        DeRef(_1);
    }
    _13921 = NOVALUE;

    /** shift.e:155		op_info[NOTEQ               ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13436);
    ((intptr_t*)_2)[4] = _13436;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13922 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13922;
    if( _1 != _13922 ){
        DeRef(_1);
    }
    _13922 = NOVALUE;

    /** shift.e:156		op_info[NOTEQ_IFW           ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_13436);
    ((intptr_t*)_2)[3] = _13436;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13923 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 105);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13923;
    if( _1 != _13923 ){
        DeRef(_1);
    }
    _13923 = NOVALUE;

    /** shift.e:157		op_info[NOTEQ_IFW_I         ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_13436);
    ((intptr_t*)_2)[3] = _13436;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13924 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 122);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13924;
    if( _1 != _13924 ){
        DeRef(_1);
    }
    _13924 = NOVALUE;

    /** shift.e:158		op_info[NOT_BITS            ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13499);
    ((intptr_t*)_2)[4] = _13499;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13925 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 51);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13925;
    if( _1 != _13925 ){
        DeRef(_1);
    }
    _13925 = NOVALUE;

    /** shift.e:159		op_info[NOT_IFW             ] = { FIXED_SIZE, 3, {2}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDS(_13499);
    ((intptr_t*)_2)[3] = _13499;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13926 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 108);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13926;
    if( _1 != _13926 ){
        DeRef(_1);
    }
    _13926 = NOVALUE;

    /** shift.e:160		op_info[OPEN                ] = { FIXED_SIZE, 5, {}, {4}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 5;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13659);
    ((intptr_t*)_2)[4] = _13659;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13927 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 37);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13927;
    if( _1 != _13927 ){
        DeRef(_1);
    }
    _13927 = NOVALUE;

    /** shift.e:161		op_info[OPTION_SWITCHES     ] = { FIXED_SIZE, 2, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 2;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13825);
    ((intptr_t*)_2)[4] = _13825;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13928 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 183);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13928;
    if( _1 != _13928 ){
        DeRef(_1);
    }
    _13928 = NOVALUE;

    /** shift.e:162		op_info[OR                  ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13436);
    ((intptr_t*)_2)[4] = _13436;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13929 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 9);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13929;
    if( _1 != _13929 ){
        DeRef(_1);
    }
    _13929 = NOVALUE;

    /** shift.e:163		op_info[OR_BITS             ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13436);
    ((intptr_t*)_2)[4] = _13436;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13930 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 24);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13930;
    if( _1 != _13930 ){
        DeRef(_1);
    }
    _13930 = NOVALUE;

    /** shift.e:164		op_info[PASSIGN_OP_SLICE    ] = { FIXED_SIZE, 5, {}, {4}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 5;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13659);
    ((intptr_t*)_2)[4] = _13659;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13931 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 165);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13931;
    if( _1 != _13931 ){
        DeRef(_1);
    }
    _13931 = NOVALUE;

    /** shift.e:165		op_info[PASSIGN_OP_SUBS     ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13436);
    ((intptr_t*)_2)[4] = _13436;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13932 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 164);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13932;
    if( _1 != _13932 ){
        DeRef(_1);
    }
    _13932 = NOVALUE;

    /** shift.e:166		op_info[PASSIGN_SLICE       ] = { FIXED_SIZE, 5, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 5;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13825);
    ((intptr_t*)_2)[4] = _13825;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13933 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 163);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13933;
    if( _1 != _13933 ){
        DeRef(_1);
    }
    _13933 = NOVALUE;

    /** shift.e:167		op_info[PASSIGN_SUBS        ] = { FIXED_SIZE, 4, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13825);
    ((intptr_t*)_2)[4] = _13825;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13934 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 162);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13934;
    if( _1 != _13934 ){
        DeRef(_1);
    }
    _13934 = NOVALUE;

    /** shift.e:168		op_info[PEEK_STRING         ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13499);
    ((intptr_t*)_2)[4] = _13499;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13935 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 182);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13935;
    if( _1 != _13935 ){
        DeRef(_1);
    }
    _13935 = NOVALUE;

    /** shift.e:169		op_info[PEEK8U              ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13499);
    ((intptr_t*)_2)[4] = _13499;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13936 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 214);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13936;
    if( _1 != _13936 ){
        DeRef(_1);
    }
    _13936 = NOVALUE;

    /** shift.e:170		op_info[PEEK8S              ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13499);
    ((intptr_t*)_2)[4] = _13499;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13937 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 213);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13937;
    if( _1 != _13937 ){
        DeRef(_1);
    }
    _13937 = NOVALUE;

    /** shift.e:171		op_info[PEEK2U              ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13499);
    ((intptr_t*)_2)[4] = _13499;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13938 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 180);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13938;
    if( _1 != _13938 ){
        DeRef(_1);
    }
    _13938 = NOVALUE;

    /** shift.e:172		op_info[PEEK2S              ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13499);
    ((intptr_t*)_2)[4] = _13499;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13939 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 179);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13939;
    if( _1 != _13939 ){
        DeRef(_1);
    }
    _13939 = NOVALUE;

    /** shift.e:173		op_info[PEEK4U              ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13499);
    ((intptr_t*)_2)[4] = _13499;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13940 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 140);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13940;
    if( _1 != _13940 ){
        DeRef(_1);
    }
    _13940 = NOVALUE;

    /** shift.e:174		op_info[PEEK4S              ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13499);
    ((intptr_t*)_2)[4] = _13499;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13941 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 139);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13941;
    if( _1 != _13941 ){
        DeRef(_1);
    }
    _13941 = NOVALUE;

    /** shift.e:175		op_info[PEEKS               ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13499);
    ((intptr_t*)_2)[4] = _13499;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13942 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 181);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13942;
    if( _1 != _13942 ){
        DeRef(_1);
    }
    _13942 = NOVALUE;

    /** shift.e:176		op_info[PEEK                ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13499);
    ((intptr_t*)_2)[4] = _13499;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13943 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 127);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13943;
    if( _1 != _13943 ){
        DeRef(_1);
    }
    _13943 = NOVALUE;

    /** shift.e:177		op_info[SIZEOF              ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13499);
    ((intptr_t*)_2)[4] = _13499;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13944 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 217);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13944;
    if( _1 != _13944 ){
        DeRef(_1);
    }
    _13944 = NOVALUE;

    /** shift.e:178		op_info[PEEK_POINTER        ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13499);
    ((intptr_t*)_2)[4] = _13499;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13945 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 216);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13945;
    if( _1 != _13945 ){
        DeRef(_1);
    }
    _13945 = NOVALUE;

    /** shift.e:179		op_info[PLENGTH             ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13499);
    ((intptr_t*)_2)[4] = _13499;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13946 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 160);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13946;
    if( _1 != _13946 ){
        DeRef(_1);
    }
    _13946 = NOVALUE;

    /** shift.e:180		op_info[PLUS                ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13436);
    ((intptr_t*)_2)[4] = _13436;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13947 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 11);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13947;
    if( _1 != _13947 ){
        DeRef(_1);
    }
    _13947 = NOVALUE;

    /** shift.e:181		op_info[PLUS_I              ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13436);
    ((intptr_t*)_2)[4] = _13436;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13948 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 115);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13948;
    if( _1 != _13948 ){
        DeRef(_1);
    }
    _13948 = NOVALUE;

    /** shift.e:182		op_info[PLUS1               ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13436);
    ((intptr_t*)_2)[4] = _13436;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13949 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 93);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13949;
    if( _1 != _13949 ){
        DeRef(_1);
    }
    _13949 = NOVALUE;

    /** shift.e:183		op_info[PLUS1_I             ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13436);
    ((intptr_t*)_2)[4] = _13436;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13950 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 117);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13950;
    if( _1 != _13950 ){
        DeRef(_1);
    }
    _13950 = NOVALUE;

    /** shift.e:184		op_info[POKE                ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13951 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 128);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13951;
    if( _1 != _13951 ){
        DeRef(_1);
    }
    _13951 = NOVALUE;

    /** shift.e:185		op_info[POKE2               ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13952 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 178);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13952;
    if( _1 != _13952 ){
        DeRef(_1);
    }
    _13952 = NOVALUE;

    /** shift.e:186		op_info[POKE4               ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13953 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 138);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13953;
    if( _1 != _13953 ){
        DeRef(_1);
    }
    _13953 = NOVALUE;

    /** shift.e:187		op_info[POKE8               ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13954 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 212);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13954;
    if( _1 != _13954 ){
        DeRef(_1);
    }
    _13954 = NOVALUE;

    /** shift.e:188		op_info[POKE_POINTER        ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13955 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 215);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13955;
    if( _1 != _13955 ){
        DeRef(_1);
    }
    _13955 = NOVALUE;

    /** shift.e:189		op_info[POSITION            ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13956 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 60);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13956;
    if( _1 != _13956 ){
        DeRef(_1);
    }
    _13956 = NOVALUE;

    /** shift.e:190		op_info[POWER               ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13436);
    ((intptr_t*)_2)[4] = _13436;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13957 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 72);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13957;
    if( _1 != _13957 ){
        DeRef(_1);
    }
    _13957 = NOVALUE;

    /** shift.e:191		op_info[PREPEND             ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13436);
    ((intptr_t*)_2)[4] = _13436;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13958 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 57);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13958;
    if( _1 != _13958 ){
        DeRef(_1);
    }
    _13958 = NOVALUE;

    /** shift.e:192		op_info[PRINT               ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13959 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 19);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13959;
    if( _1 != _13959 ){
        DeRef(_1);
    }
    _13959 = NOVALUE;

    /** shift.e:193		op_info[PRINTF              ] = { FIXED_SIZE, 4, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13960 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 38);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13960;
    if( _1 != _13960 ){
        DeRef(_1);
    }
    _13960 = NOVALUE;

    /** shift.e:194		op_info[PROFILE             ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 2;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13961 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 151);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13961;
    if( _1 != _13961 ){
        DeRef(_1);
    }
    _13961 = NOVALUE;

    /** shift.e:195		op_info[DISPLAY_VAR         ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 2;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13962 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 87);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13962;
    if( _1 != _13962 ){
        DeRef(_1);
    }
    _13962 = NOVALUE;

    /** shift.e:196		op_info[ERASE_PRIVATE_NAMES ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 2;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13963 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 88);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13963;
    if( _1 != _13963 ){
        DeRef(_1);
    }
    _13963 = NOVALUE;

    /** shift.e:197		op_info[ERASE_SYMBOL        ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 2;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13964 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 90);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13964;
    if( _1 != _13964 ){
        DeRef(_1);
    }
    _13964 = NOVALUE;

    /** shift.e:198		op_info[PUTS                ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13965 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 44);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13965;
    if( _1 != _13965 ){
        DeRef(_1);
    }
    _13965 = NOVALUE;

    /** shift.e:199		op_info[QPRINT              ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13966 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13966;
    if( _1 != _13966 ){
        DeRef(_1);
    }
    _13966 = NOVALUE;

    /** shift.e:200		op_info[RAND                ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13499);
    ((intptr_t*)_2)[4] = _13499;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13967 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 62);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13967;
    if( _1 != _13967 ){
        DeRef(_1);
    }
    _13967 = NOVALUE;

    /** shift.e:201		op_info[REMAINDER           ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13436);
    ((intptr_t*)_2)[4] = _13436;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13968 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 71);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13968;
    if( _1 != _13968 ){
        DeRef(_1);
    }
    _13968 = NOVALUE;

    /** shift.e:202		op_info[REMOVE              ] = { FIXED_SIZE, 5, {}, {4}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 5;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13659);
    ((intptr_t*)_2)[4] = _13659;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13969 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 200);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13969;
    if( _1 != _13969 ){
        DeRef(_1);
    }
    _13969 = NOVALUE;

    /** shift.e:203		op_info[REPEAT              ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13436);
    ((intptr_t*)_2)[4] = _13436;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13970 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 32);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13970;
    if( _1 != _13970 ){
        DeRef(_1);
    }
    _13970 = NOVALUE;

    /** shift.e:204		op_info[REPLACE             ] = { FIXED_SIZE, 6, {}, {5}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 6;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13971);
    ((intptr_t*)_2)[4] = _13971;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13972 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 201);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13972;
    if( _1 != _13972 ){
        DeRef(_1);
    }
    _13972 = NOVALUE;

    /** shift.e:205		op_info[RETURNF             ] = { FIXED_SIZE, 4, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13973 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 28);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13973;
    if( _1 != _13973 ){
        DeRef(_1);
    }
    _13973 = NOVALUE;

    /** shift.e:206		op_info[RETURNP             ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13974 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 29);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13974;
    if( _1 != _13974 ){
        DeRef(_1);
    }
    _13974 = NOVALUE;

    /** shift.e:207		op_info[RETURNT             ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 1;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13975 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 34);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13975;
    if( _1 != _13975 ){
        DeRef(_1);
    }
    _13975 = NOVALUE;

    /** shift.e:208		op_info[RHS_SLICE           ] = { FIXED_SIZE, 5, {}, {4}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 5;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13659);
    ((intptr_t*)_2)[4] = _13659;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13976 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 46);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13976;
    if( _1 != _13976 ){
        DeRef(_1);
    }
    _13976 = NOVALUE;

    /** shift.e:209		op_info[RHS_SUBS            ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13436);
    ((intptr_t*)_2)[4] = _13436;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13977 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 25);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13977;
    if( _1 != _13977 ){
        DeRef(_1);
    }
    _13977 = NOVALUE;

    /** shift.e:210		op_info[RHS_SUBS_I          ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13436);
    ((intptr_t*)_2)[4] = _13436;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13978 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 114);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13978;
    if( _1 != _13978 ){
        DeRef(_1);
    }
    _13978 = NOVALUE;

    /** shift.e:211		op_info[RHS_SUBS_CHECK      ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13436);
    ((intptr_t*)_2)[4] = _13436;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13979 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 92);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13979;
    if( _1 != _13979 ){
        DeRef(_1);
    }
    _13979 = NOVALUE;

    /** shift.e:212		op_info[RIGHT_BRACE_2       ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13436);
    ((intptr_t*)_2)[4] = _13436;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13980 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 85);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13980;
    if( _1 != _13980 ){
        DeRef(_1);
    }
    _13980 = NOVALUE;

    /** shift.e:214		op_info[ROUTINE_ID          ] = { FIXED_SIZE, 6 - TRANSLATE, {}, { 4 + not TRANSLATE }, {} }*/
    _13981 = 6 - _36TRANSLATE_21369;
    _13982 = (_36TRANSLATE_21369 == 0);
    _13983 = 4 + _13982;
    if ((object)((uintptr_t)_13983 + (uintptr_t)HIGH_BITS) >= 0){
        _13983 = NewDouble((eudouble)_13983);
    }
    _13982 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _13983;
    _13984 = MAKE_SEQ(_1);
    _13983 = NOVALUE;
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = _13981;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _13984;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13985 = MAKE_SEQ(_1);
    _13984 = NOVALUE;
    _13981 = NOVALUE;
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 134);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13985;
    if( _1 != _13985 ){
        DeRef(_1);
    }
    _13985 = NOVALUE;

    /** shift.e:215		op_info[SC2_OR              ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13986 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 144);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13986;
    if( _1 != _13986 ){
        DeRef(_1);
    }
    _13986 = NOVALUE;

    /** shift.e:216		op_info[SC2_AND             ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13987 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 142);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13987;
    if( _1 != _13987 ){
        DeRef(_1);
    }
    _13987 = NOVALUE;

    /** shift.e:217		op_info[SIN                 ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13499);
    ((intptr_t*)_2)[4] = _13499;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13988 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 80);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13988;
    if( _1 != _13988 ){
        DeRef(_1);
    }
    _13988 = NOVALUE;

    /** shift.e:218		op_info[SPACE_USED          ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 2;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13989 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 75);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13989;
    if( _1 != _13989 ){
        DeRef(_1);
    }
    _13989 = NOVALUE;

    /** shift.e:219		op_info[SPLICE              ] = { FIXED_SIZE, 5, {}, {4}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 5;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13659);
    ((intptr_t*)_2)[4] = _13659;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13990 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 190);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13990;
    if( _1 != _13990 ){
        DeRef(_1);
    }
    _13990 = NOVALUE;

    /** shift.e:220		op_info[SPRINTF             ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13436);
    ((intptr_t*)_2)[4] = _13436;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13991 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 53);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13991;
    if( _1 != _13991 ){
        DeRef(_1);
    }
    _13991 = NOVALUE;

    /** shift.e:221		op_info[SQRT                ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13499);
    ((intptr_t*)_2)[4] = _13499;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13992 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 41);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13992;
    if( _1 != _13992 ){
        DeRef(_1);
    }
    _13992 = NOVALUE;

    /** shift.e:222		op_info[STARTLINE           ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 2;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13993 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 58);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13993;
    if( _1 != _13993 ){
        DeRef(_1);
    }
    _13993 = NOVALUE;

    /** shift.e:223		op_info[SWITCH              ] = { FIXED_SIZE, 5, {4}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 5;
    RefDS(_13659);
    ((intptr_t*)_2)[3] = _13659;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13994 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 185);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13994;
    if( _1 != _13994 ){
        DeRef(_1);
    }
    _13994 = NOVALUE;

    /** shift.e:224		op_info[SWITCH_I            ] = { FIXED_SIZE, 5, {4}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 5;
    RefDS(_13659);
    ((intptr_t*)_2)[3] = _13659;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13995 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 193);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13995;
    if( _1 != _13995 ){
        DeRef(_1);
    }
    _13995 = NOVALUE;

    /** shift.e:225		op_info[SWITCH_SPI          ] = { FIXED_SIZE, 5, {4}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 5;
    RefDS(_13659);
    ((intptr_t*)_2)[3] = _13659;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13996 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 192);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13996;
    if( _1 != _13996 ){
        DeRef(_1);
    }
    _13996 = NOVALUE;

    /** shift.e:226		op_info[SWITCH_RT           ] = { FIXED_SIZE, 5, {4}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 5;
    RefDS(_13659);
    ((intptr_t*)_2)[3] = _13659;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13997 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 202);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13997;
    if( _1 != _13997 ){
        DeRef(_1);
    }
    _13997 = NOVALUE;

    /** shift.e:227		op_info[SYSTEM              ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13998 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 99);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13998;
    if( _1 != _13998 ){
        DeRef(_1);
    }
    _13998 = NOVALUE;

    /** shift.e:228		op_info[SYSTEM_EXEC         ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13436);
    ((intptr_t*)_2)[4] = _13436;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13999 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 154);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13999;
    if( _1 != _13999 ){
        DeRef(_1);
    }
    _13999 = NOVALUE;

    /** shift.e:229		op_info[TAIL                ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13436);
    ((intptr_t*)_2)[4] = _13436;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _14000 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 199);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14000;
    if( _1 != _14000 ){
        DeRef(_1);
    }
    _14000 = NOVALUE;

    /** shift.e:230		op_info[TAN                 ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13499);
    ((intptr_t*)_2)[4] = _13499;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _14001 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 82);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14001;
    if( _1 != _14001 ){
        DeRef(_1);
    }
    _14001 = NOVALUE;

    /** shift.e:231		op_info[TASK_CLOCK_START    ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 1;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _14002 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 175);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14002;
    if( _1 != _14002 ){
        DeRef(_1);
    }
    _14002 = NOVALUE;

    /** shift.e:232		op_info[TASK_CLOCK_STOP     ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 1;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _14003 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 174);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14003;
    if( _1 != _14003 ){
        DeRef(_1);
    }
    _14003 = NOVALUE;

    /** shift.e:233		op_info[TASK_CREATE         ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13436);
    ((intptr_t*)_2)[4] = _13436;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _14004 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 167);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14004;
    if( _1 != _14004 ){
        DeRef(_1);
    }
    _14004 = NOVALUE;

    /** shift.e:234		op_info[TASK_LIST           ] = { FIXED_SIZE, 2, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 2;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13825);
    ((intptr_t*)_2)[4] = _13825;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _14005 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 172);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14005;
    if( _1 != _14005 ){
        DeRef(_1);
    }
    _14005 = NOVALUE;

    /** shift.e:235		op_info[TASK_SCHEDULE       ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _14006 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 168);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14006;
    if( _1 != _14006 ){
        DeRef(_1);
    }
    _14006 = NOVALUE;

    /** shift.e:236		op_info[TASK_SELF           ] = { FIXED_SIZE, 2, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 2;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13825);
    ((intptr_t*)_2)[4] = _13825;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _14007 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 170);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14007;
    if( _1 != _14007 ){
        DeRef(_1);
    }
    _14007 = NOVALUE;

    /** shift.e:237		op_info[TASK_STATUS         ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13499);
    ((intptr_t*)_2)[4] = _13499;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _14008 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 173);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14008;
    if( _1 != _14008 ){
        DeRef(_1);
    }
    _14008 = NOVALUE;

    /** shift.e:238		op_info[TASK_SUSPEND        ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 2;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _14009 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 171);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14009;
    if( _1 != _14009 ){
        DeRef(_1);
    }
    _14009 = NOVALUE;

    /** shift.e:239		op_info[TASK_YIELD          ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 1;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _14010 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 169);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14010;
    if( _1 != _14010 ){
        DeRef(_1);
    }
    _14010 = NOVALUE;

    /** shift.e:240		op_info[TIME                ] = { FIXED_SIZE, 2, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 2;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13825);
    ((intptr_t*)_2)[4] = _13825;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _14011 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 70);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14011;
    if( _1 != _14011 ){
        DeRef(_1);
    }
    _14011 = NOVALUE;

    /** shift.e:241		op_info[TRACE               ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 2;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _14012 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 64);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14012;
    if( _1 != _14012 ){
        DeRef(_1);
    }
    _14012 = NOVALUE;

    /** shift.e:242		op_info[TYPE_CHECK          ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 1;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _14013 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 65);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14013;
    if( _1 != _14013 ){
        DeRef(_1);
    }
    _14013 = NOVALUE;

    /** shift.e:243		op_info[UMINUS              ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13499);
    ((intptr_t*)_2)[4] = _13499;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _14014 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14014;
    if( _1 != _14014 ){
        DeRef(_1);
    }
    _14014 = NOVALUE;

    /** shift.e:244		op_info[UPDATE_GLOBALS      ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 1;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _14015 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 89);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14015;
    if( _1 != _14015 ){
        DeRef(_1);
    }
    _14015 = NOVALUE;

    /** shift.e:245		op_info[WHILE               ] = { FIXED_SIZE, 3, {2}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDS(_13499);
    ((intptr_t*)_2)[3] = _13499;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _14016 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 47);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14016;
    if( _1 != _14016 ){
        DeRef(_1);
    }
    _14016 = NOVALUE;

    /** shift.e:246		op_info[XOR                 ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13436);
    ((intptr_t*)_2)[4] = _13436;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _14017 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 152);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14017;
    if( _1 != _14017 ){
        DeRef(_1);
    }
    _14017 = NOVALUE;

    /** shift.e:247		op_info[XOR_BITS            ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13436);
    ((intptr_t*)_2)[4] = _13436;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _14018 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 26);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14018;
    if( _1 != _14018 ){
        DeRef(_1);
    }
    _14018 = NOVALUE;

    /** shift.e:249		op_info[TYPE_CHECK_FORWARD  ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _14019 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 197);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14019;
    if( _1 != _14019 ){
        DeRef(_1);
    }
    _14019 = NOVALUE;

    /** shift.e:251		sequence SHORT_CIRCUIT = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _0 = _SHORT_CIRCUIT_24988;
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_13436);
    ((intptr_t*)_2)[3] = _13436;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _SHORT_CIRCUIT_24988 = MAKE_SEQ(_1);
    DeRef(_0);

    /** shift.e:252		op_info[SC1_AND_IF          ] = SHORT_CIRCUIT*/
    RefDS(_SHORT_CIRCUIT_24988);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 146);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _SHORT_CIRCUIT_24988;
    DeRef(_1);

    /** shift.e:253		op_info[SC1_OR_IF           ] = SHORT_CIRCUIT*/
    RefDS(_SHORT_CIRCUIT_24988);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 147);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _SHORT_CIRCUIT_24988;
    DeRef(_1);

    /** shift.e:254		op_info[SC1_AND             ] = SHORT_CIRCUIT*/
    RefDS(_SHORT_CIRCUIT_24988);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 141);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _SHORT_CIRCUIT_24988;
    DeRef(_1);

    /** shift.e:255		op_info[SC1_OR              ] = SHORT_CIRCUIT*/
    RefDS(_SHORT_CIRCUIT_24988);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 143);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _SHORT_CIRCUIT_24988;
    DeRef(_1);

    /** shift.e:257		op_info[ATOM_CHECK          ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 2;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _14021 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 101);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14021;
    if( _1 != _14021 ){
        DeRef(_1);
    }
    _14021 = NOVALUE;

    /** shift.e:258		op_info[INTEGER_CHECK       ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 2;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _14022 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 96);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14022;
    if( _1 != _14022 ){
        DeRef(_1);
    }
    _14022 = NOVALUE;

    /** shift.e:259		op_info[SEQUENCE_CHECK      ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 2;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _14023 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 97);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14023;
    if( _1 != _14023 ){
        DeRef(_1);
    }
    _14023 = NOVALUE;

    /** shift.e:261		op_info[IS_AN_INTEGER       ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13499);
    ((intptr_t*)_2)[4] = _13499;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _14024 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 94);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14024;
    if( _1 != _14024 ){
        DeRef(_1);
    }
    _14024 = NOVALUE;

    /** shift.e:262		op_info[IS_AN_ATOM          ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13499);
    ((intptr_t*)_2)[4] = _13499;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _14025 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 67);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14025;
    if( _1 != _14025 ){
        DeRef(_1);
    }
    _14025 = NOVALUE;

    /** shift.e:263		op_info[IS_A_SEQUENCE       ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13499);
    ((intptr_t*)_2)[4] = _13499;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _14026 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 68);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14026;
    if( _1 != _14026 ){
        DeRef(_1);
    }
    _14026 = NOVALUE;

    /** shift.e:264		op_info[IS_AN_OBJECT        ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13499);
    ((intptr_t*)_2)[4] = _13499;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _14027 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 40);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14027;
    if( _1 != _14027 ){
        DeRef(_1);
    }
    _14027 = NOVALUE;

    /** shift.e:266		op_info[CALL_BACK_RETURN    ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 1;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _14028 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 135);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14028;
    if( _1 != _14028 ){
        DeRef(_1);
    }
    _14028 = NOVALUE;

    /** shift.e:268		op_info[REF_TEMP            ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 2;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _14029 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 207);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14029;
    if( _1 != _14029 ){
        DeRef(_1);
    }
    _14029 = NOVALUE;

    /** shift.e:269		op_info[DEREF_TEMP          ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 2;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _14030 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 208);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14030;
    if( _1 != _14030 ){
        DeRef(_1);
    }
    _14030 = NOVALUE;

    /** shift.e:270		op_info[NOVALUE_TEMP        ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 2;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _14031 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 209);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14031;
    if( _1 != _14031 ){
        DeRef(_1);
    }
    _14031 = NOVALUE;

    /** shift.e:272		op_info[PROC_FORWARD        ] = { VARIABLE_SIZE, 0, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 2;
    ((intptr_t*)_2)[2] = 0;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _14032 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 195);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14032;
    if( _1 != _14032 ){
        DeRef(_1);
    }
    _14032 = NOVALUE;

    /** shift.e:273		op_info[FUNC_FORWARD        ] = { VARIABLE_SIZE, 0, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 2;
    ((intptr_t*)_2)[2] = 0;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _14033 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 196);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14033;
    if( _1 != _14033 ){
        DeRef(_1);
    }
    _14033 = NOVALUE;

    /** shift.e:275		op_info[RIGHT_BRACE_N       ] = { VARIABLE_SIZE, 3, {}, {}, {} } -- target: [pc+1] + 2*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 2;
    ((intptr_t*)_2)[2] = 3;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _14034 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 31);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14034;
    if( _1 != _14034 ){
        DeRef(_1);
    }
    _14034 = NOVALUE;

    /** shift.e:276		op_info[CONCAT_N            ] = { VARIABLE_SIZE, 0, {}, {}, {} } -- target: [pc+1] + 2*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 2;
    ((intptr_t*)_2)[2] = 0;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _14035 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 157);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14035;
    if( _1 != _14035 ){
        DeRef(_1);
    }
    _14035 = NOVALUE;

    /** shift.e:277		op_info[PROC                ] = { VARIABLE_SIZE, 0, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 2;
    ((intptr_t*)_2)[2] = 0;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _14036 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 27);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14036;
    if( _1 != _14036 ){
        DeRef(_1);
    }
    _14036 = NOVALUE;

    /** shift.e:278		op_info[PROC_TAIL           ] = op_info[PROC]*/
    _2 = (object)SEQ_PTR(_66op_info_24561);
    _14037 = (object)*(((s1_ptr)_2)->base + 27);
    Ref(_14037);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24561 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 203);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14037;
    if( _1 != _14037 ){
        DeRef(_1);
    }
    _14037 = NOVALUE;

    /** shift.e:281		for i = 1 to MAX_OPCODE do*/
    _14038 = 218;
    {
        object _i_25030;
        _i_25030 = 1;
L1: 
        if (_i_25030 > 218){
            goto L2; // [3959] 4052
        }

        /** shift.e:282			object info = op_info[i]*/
        DeRef(_info_25033);
        _2 = (object)SEQ_PTR(_66op_info_24561);
        _info_25033 = (object)*(((s1_ptr)_2)->base + _i_25030);
        Ref(_info_25033);

        /** shift.e:283			if sequence( info ) then*/
        _14040 = IS_SEQUENCE(_info_25033);
        if (_14040 == 0)
        {
            _14040 = NOVALUE;
            goto L3; // [3979] 4043
        }
        else{
            _14040 = NOVALUE;
        }

        /** shift.e:284				op_info_size_type[i] = info[OP_SIZE_TYPE]*/
        _2 = (object)SEQ_PTR(_info_25033);
        _14041 = (object)*(((s1_ptr)_2)->base + 1);
        Ref(_14041);
        _2 = (object)SEQ_PTR(_66op_info_size_type_24567);
        _2 = (object)(((s1_ptr)_2)->base + _i_25030);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _14041;
        if( _1 != _14041 ){
            DeRef(_1);
        }
        _14041 = NOVALUE;

        /** shift.e:285				op_info_size[i] = info[OP_SIZE]*/
        _2 = (object)SEQ_PTR(_info_25033);
        _14042 = (object)*(((s1_ptr)_2)->base + 2);
        Ref(_14042);
        _2 = (object)SEQ_PTR(_66op_info_size_24568);
        _2 = (object)(((s1_ptr)_2)->base + _i_25030);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _14042;
        if( _1 != _14042 ){
            DeRef(_1);
        }
        _14042 = NOVALUE;

        /** shift.e:286				op_info_addr[i] = info[OP_ADDR]*/
        _2 = (object)SEQ_PTR(_info_25033);
        _14043 = (object)*(((s1_ptr)_2)->base + 3);
        Ref(_14043);
        _2 = (object)SEQ_PTR(_66op_info_addr_24569);
        _2 = (object)(((s1_ptr)_2)->base + _i_25030);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _14043;
        if( _1 != _14043 ){
            DeRef(_1);
        }
        _14043 = NOVALUE;

        /** shift.e:287				op_info_target[i] = info[OP_TARGET]*/
        _2 = (object)SEQ_PTR(_info_25033);
        _14044 = (object)*(((s1_ptr)_2)->base + 4);
        Ref(_14044);
        _2 = (object)SEQ_PTR(_66op_info_target_24570);
        _2 = (object)(((s1_ptr)_2)->base + _i_25030);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _14044;
        if( _1 != _14044 ){
            DeRef(_1);
        }
        _14044 = NOVALUE;

        /** shift.e:288				op_info_sub[i] = info[OP_SUB]*/
        _2 = (object)SEQ_PTR(_info_25033);
        _14045 = (object)*(((s1_ptr)_2)->base + 5);
        Ref(_14045);
        _2 = (object)SEQ_PTR(_66op_info_sub_24571);
        _2 = (object)(((s1_ptr)_2)->base + _i_25030);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _14045;
        if( _1 != _14045 ){
            DeRef(_1);
        }
        _14045 = NOVALUE;
L3: 
        DeRef(_info_25033);
        _info_25033 = NOVALUE;

        /** shift.e:290		end for*/
        _i_25030 = _i_25030 + 1;
        goto L1; // [4047] 3966
L2: 
        ;
    }

    /** shift.e:291	end procedure*/
    DeRef(_SHORT_CIRCUIT_24988);
    return;
    ;
}


object _66variable_op_size(object _pc_25044, object _op_25045, object _code_25046)
{
    object _int_25049 = NOVALUE;
    object _info_25055 = NOVALUE;
    object _14065 = NOVALUE;
    object _14062 = NOVALUE;
    object _14059 = NOVALUE;
    object _14056 = NOVALUE;
    object _14055 = NOVALUE;
    object _14054 = NOVALUE;
    object _14053 = NOVALUE;
    object _14052 = NOVALUE;
    object _14051 = NOVALUE;
    object _14049 = NOVALUE;
    object _14048 = NOVALUE;
    object _0, _1, _2;
    

    /** shift.e:297		switch op do*/
    _0 = _op_25045;
    switch ( _0 ){ 

        /** shift.e:298			case PROC, PROC_TAIL then*/
        case 27:
        case 203:

        /** shift.e:299				sequence info = SymTab[code[pc+1]]*/
        _14048 = _pc_25044 + 1;
        _2 = (object)SEQ_PTR(_code_25046);
        _14049 = (object)*(((s1_ptr)_2)->base + _14048);
        DeRef(_info_25055);
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        if (!IS_ATOM_INT(_14049)){
            _info_25055 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_14049)->dbl));
        }
        else{
            _info_25055 = (object)*(((s1_ptr)_2)->base + _14049);
        }
        Ref(_info_25055);

        /** shift.e:300				return info[S_NUM_ARGS] + 2 + (info[S_TOKEN] != PROC)*/
        _2 = (object)SEQ_PTR(_info_25055);
        if (!IS_ATOM_INT(_36S_NUM_ARGS_21455)){
            _14051 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21455)->dbl));
        }
        else{
            _14051 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21455);
        }
        if (IS_ATOM_INT(_14051)) {
            _14052 = _14051 + 2;
            if ((object)((uintptr_t)_14052 + (uintptr_t)HIGH_BITS) >= 0){
                _14052 = NewDouble((eudouble)_14052);
            }
        }
        else {
            _14052 = binary_op(PLUS, _14051, 2);
        }
        _14051 = NOVALUE;
        _2 = (object)SEQ_PTR(_info_25055);
        if (!IS_ATOM_INT(_36S_TOKEN_21409)){
            _14053 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21409)->dbl));
        }
        else{
            _14053 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21409);
        }
        if (IS_ATOM_INT(_14053)) {
            _14054 = (_14053 != 27);
        }
        else {
            _14054 = binary_op(NOTEQ, _14053, 27);
        }
        _14053 = NOVALUE;
        if (IS_ATOM_INT(_14052) && IS_ATOM_INT(_14054)) {
            _14055 = _14052 + _14054;
            if ((object)((uintptr_t)_14055 + (uintptr_t)HIGH_BITS) >= 0){
                _14055 = NewDouble((eudouble)_14055);
            }
        }
        else {
            _14055 = binary_op(PLUS, _14052, _14054);
        }
        DeRef(_14052);
        _14052 = NOVALUE;
        DeRef(_14054);
        _14054 = NOVALUE;
        DeRefDS(_info_25055);
        DeRefDS(_code_25046);
        _14049 = NOVALUE;
        _14048 = NOVALUE;
        return _14055;
        goto L1; // [72] 157

        /** shift.e:302			case PROC_FORWARD then*/
        case 195:

        /** shift.e:303				int = code[pc+2]*/
        _14056 = _pc_25044 + 2;
        _2 = (object)SEQ_PTR(_code_25046);
        _int_25049 = (object)*(((s1_ptr)_2)->base + _14056);
        if (!IS_ATOM_INT(_int_25049))
        _int_25049 = (object)DBL_PTR(_int_25049)->dbl;

        /** shift.e:304				int += 3*/
        _int_25049 = _int_25049 + 3;
        goto L1; // [94] 157

        /** shift.e:305			case FUNC_FORWARD then*/
        case 196:

        /** shift.e:306				int = code[pc+2]*/
        _14059 = _pc_25044 + 2;
        _2 = (object)SEQ_PTR(_code_25046);
        _int_25049 = (object)*(((s1_ptr)_2)->base + _14059);
        if (!IS_ATOM_INT(_int_25049))
        _int_25049 = (object)DBL_PTR(_int_25049)->dbl;

        /** shift.e:307				int += 4*/
        _int_25049 = _int_25049 + 4;
        goto L1; // [116] 157

        /** shift.e:308			case RIGHT_BRACE_N, CONCAT_N then*/
        case 31:
        case 157:

        /** shift.e:309				int = code[pc+1]*/
        _14062 = _pc_25044 + 1;
        _2 = (object)SEQ_PTR(_code_25046);
        _int_25049 = (object)*(((s1_ptr)_2)->base + _14062);
        if (!IS_ATOM_INT(_int_25049))
        _int_25049 = (object)DBL_PTR(_int_25049)->dbl;

        /** shift.e:310				int += 3*/
        _int_25049 = _int_25049 + 3;
        goto L1; // [140] 157

        /** shift.e:311			case else*/
        default:

        /** shift.e:312				InternalErr( 269, {op} )*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _op_25045;
        _14065 = MAKE_SEQ(_1);
        _50InternalErr(269, _14065);
        _14065 = NOVALUE;
    ;}L1: 

    /** shift.e:314		return int*/
    DeRefDS(_code_25046);
    DeRef(_14059);
    _14059 = NOVALUE;
    DeRef(_14055);
    _14055 = NOVALUE;
    _14049 = NOVALUE;
    DeRef(_14048);
    _14048 = NOVALUE;
    DeRef(_14056);
    _14056 = NOVALUE;
    DeRef(_14062);
    _14062 = NOVALUE;
    return _int_25049;
    ;
}


object _66op_size(object _pc_25089, object _code_25090)
{
    object _op_25093 = NOVALUE;
    object _int_25095 = NOVALUE;
    object _14070 = NOVALUE;
    object _14069 = NOVALUE;
    object _0, _1, _2;
    

    /** shift.e:318		integer op = code[pc]*/
    _2 = (object)SEQ_PTR(_code_25090);
    _op_25093 = (object)*(((s1_ptr)_2)->base + _pc_25089);
    if (!IS_ATOM_INT(_op_25093))
    _op_25093 = (object)DBL_PTR(_op_25093)->dbl;

    /** shift.e:319		integer int = op_info_size_type[op]*/
    _2 = (object)SEQ_PTR(_66op_info_size_type_24567);
    _int_25095 = (object)*(((s1_ptr)_2)->base + _op_25093);
    if (!IS_ATOM_INT(_int_25095))
    _int_25095 = (object)DBL_PTR(_int_25095)->dbl;

    /** shift.e:321		if int = FIXED_SIZE then*/
    if (_int_25095 != 1)
    goto L1; // [21] 40

    /** shift.e:322			return op_info_size[op]*/
    _2 = (object)SEQ_PTR(_66op_info_size_24568);
    _14069 = (object)*(((s1_ptr)_2)->base + _op_25093);
    Ref(_14069);
    DeRefDS(_code_25090);
    return _14069;
    goto L2; // [37] 53
L1: 

    /** shift.e:324			return variable_op_size( pc, op, code )*/
    RefDS(_code_25090);
    _14070 = _66variable_op_size(_pc_25089, _op_25093, _code_25090);
    DeRefDS(_code_25090);
    _14069 = NOVALUE;
    return _14070;
L2: 
    ;
}


object _66advance(object _pc_25104, object _code_25105)
{
    object _size_25108 = NOVALUE;
    object _14072 = NOVALUE;
    object _0, _1, _2;
    

    /** shift.e:329		integer size = op_size( pc, code )*/
    RefDS(_code_25105);
    _size_25108 = _66op_size(_pc_25104, _code_25105);
    if (!IS_ATOM_INT(_size_25108)) {
        _1 = (object)(DBL_PTR(_size_25108)->dbl);
        DeRefDS(_size_25108);
        _size_25108 = _1;
    }

    /** shift.e:330		return pc + size*/
    _14072 = _pc_25104 + _size_25108;
    if ((object)((uintptr_t)_14072 + (uintptr_t)HIGH_BITS) >= 0){
        _14072 = NewDouble((eudouble)_14072);
    }
    DeRefDS(_code_25105);
    return _14072;
    ;
}


void _66shift_switch(object _pc_25113, object _start_25114, object _amount_25115)
{
    object _addr_25116 = NOVALUE;
    object _jump_25148 = NOVALUE;
    object _14107 = NOVALUE;
    object _14106 = NOVALUE;
    object _14105 = NOVALUE;
    object _14104 = NOVALUE;
    object _14103 = NOVALUE;
    object _14102 = NOVALUE;
    object _14101 = NOVALUE;
    object _14100 = NOVALUE;
    object _14099 = NOVALUE;
    object _14098 = NOVALUE;
    object _14097 = NOVALUE;
    object _14095 = NOVALUE;
    object _14094 = NOVALUE;
    object _14093 = NOVALUE;
    object _14092 = NOVALUE;
    object _14091 = NOVALUE;
    object _14090 = NOVALUE;
    object _14089 = NOVALUE;
    object _14088 = NOVALUE;
    object _14086 = NOVALUE;
    object _14085 = NOVALUE;
    object _14084 = NOVALUE;
    object _14083 = NOVALUE;
    object _14082 = NOVALUE;
    object _14079 = NOVALUE;
    object _14077 = NOVALUE;
    object _14076 = NOVALUE;
    object _14075 = NOVALUE;
    object _14074 = NOVALUE;
    object _14073 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** shift.e:336		if sequence( Code[pc+4] ) then*/
    _14073 = _pc_25113 + 4;
    _2 = (object)SEQ_PTR(_36Code_21859);
    _14074 = (object)*(((s1_ptr)_2)->base + _14073);
    _14075 = IS_SEQUENCE(_14074);
    _14074 = NOVALUE;
    if (_14075 == 0)
    {
        _14075 = NOVALUE;
        goto L1; // [22] 46
    }
    else{
        _14075 = NOVALUE;
    }

    /** shift.e:337			addr = Code[pc+4][2]*/
    _14076 = _pc_25113 + 4;
    _2 = (object)SEQ_PTR(_36Code_21859);
    _14077 = (object)*(((s1_ptr)_2)->base + _14076);
    _2 = (object)SEQ_PTR(_14077);
    _addr_25116 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_addr_25116)){
        _addr_25116 = (object)DBL_PTR(_addr_25116)->dbl;
    }
    _14077 = NOVALUE;
    goto L2; // [43] 61
L1: 

    /** shift.e:339			addr = Code[pc+4]*/
    _14079 = _pc_25113 + 4;
    _2 = (object)SEQ_PTR(_36Code_21859);
    _addr_25116 = (object)*(((s1_ptr)_2)->base + _14079);
    if (!IS_ATOM_INT(_addr_25116)){
        _addr_25116 = (object)DBL_PTR(_addr_25116)->dbl;
    }
L2: 

    /** shift.e:343		if start < addr then*/
    if (_start_25114 >= _addr_25116)
    goto L3; // [65] 137

    /** shift.e:344			if sequence( Code[pc+4] ) then*/
    _14082 = _pc_25113 + 4;
    _2 = (object)SEQ_PTR(_36Code_21859);
    _14083 = (object)*(((s1_ptr)_2)->base + _14082);
    _14084 = IS_SEQUENCE(_14083);
    _14083 = NOVALUE;
    if (_14084 == 0)
    {
        _14084 = NOVALUE;
        goto L4; // [84] 115
    }
    else{
        _14084 = NOVALUE;
    }

    /** shift.e:345				Code[pc+4][2] += amount*/
    _14085 = _pc_25113 + 4;
    _2 = (object)SEQ_PTR(_36Code_21859);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _36Code_21859 = MAKE_SEQ(_2);
    }
    _3 = (object)(_14085 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _14088 = (object)*(((s1_ptr)_2)->base + 2);
    _14086 = NOVALUE;
    if (IS_ATOM_INT(_14088)) {
        _14089 = _14088 + _amount_25115;
        if ((object)((uintptr_t)_14089 + (uintptr_t)HIGH_BITS) >= 0){
            _14089 = NewDouble((eudouble)_14089);
        }
    }
    else {
        _14089 = binary_op(PLUS, _14088, _amount_25115);
    }
    _14088 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14089;
    if( _1 != _14089 ){
        DeRef(_1);
    }
    _14089 = NOVALUE;
    _14086 = NOVALUE;
    goto L5; // [112] 136
L4: 

    /** shift.e:347				Code[pc+4] += amount*/
    _14090 = _pc_25113 + 4;
    _2 = (object)SEQ_PTR(_36Code_21859);
    _14091 = (object)*(((s1_ptr)_2)->base + _14090);
    if (IS_ATOM_INT(_14091)) {
        _14092 = _14091 + _amount_25115;
        if ((object)((uintptr_t)_14092 + (uintptr_t)HIGH_BITS) >= 0){
            _14092 = NewDouble((eudouble)_14092);
        }
    }
    else {
        _14092 = binary_op(PLUS, _14091, _amount_25115);
    }
    _14091 = NOVALUE;
    _2 = (object)SEQ_PTR(_36Code_21859);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _36Code_21859 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _14090);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14092;
    if( _1 != _14092 ){
        DeRef(_1);
    }
    _14092 = NOVALUE;
L5: 
L3: 

    /** shift.e:351		sequence jump = SymTab[Code[pc+3]][S_OBJ]*/
    _14093 = _pc_25113 + 3;
    _2 = (object)SEQ_PTR(_36Code_21859);
    _14094 = (object)*(((s1_ptr)_2)->base + _14093);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!IS_ATOM_INT(_14094)){
        _14095 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_14094)->dbl));
    }
    else{
        _14095 = (object)*(((s1_ptr)_2)->base + _14094);
    }
    DeRef(_jump_25148);
    _2 = (object)SEQ_PTR(_14095);
    _jump_25148 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_jump_25148);
    _14095 = NOVALUE;

    /** shift.e:352		for i = 1 to length(jump) do*/
    if (IS_SEQUENCE(_jump_25148)){
            _14097 = SEQ_PTR(_jump_25148)->length;
    }
    else {
        _14097 = 1;
    }
    {
        object _i_25157;
        _i_25157 = 1;
L6: 
        if (_i_25157 > _14097){
            goto L7; // [168] 223
        }

        /** shift.e:353			if start > pc and start < pc + jump[i] then*/
        _14098 = (_start_25114 > _pc_25113);
        if (_14098 == 0) {
            goto L8; // [181] 216
        }
        _2 = (object)SEQ_PTR(_jump_25148);
        _14100 = (object)*(((s1_ptr)_2)->base + _i_25157);
        if (IS_ATOM_INT(_14100)) {
            _14101 = _pc_25113 + _14100;
            if ((object)((uintptr_t)_14101 + (uintptr_t)HIGH_BITS) >= 0){
                _14101 = NewDouble((eudouble)_14101);
            }
        }
        else {
            _14101 = binary_op(PLUS, _pc_25113, _14100);
        }
        _14100 = NOVALUE;
        if (IS_ATOM_INT(_14101)) {
            _14102 = (_start_25114 < _14101);
        }
        else {
            _14102 = binary_op(LESS, _start_25114, _14101);
        }
        DeRef(_14101);
        _14101 = NOVALUE;
        if (_14102 == 0) {
            DeRef(_14102);
            _14102 = NOVALUE;
            goto L8; // [198] 216
        }
        else {
            if (!IS_ATOM_INT(_14102) && DBL_PTR(_14102)->dbl == 0.0){
                DeRef(_14102);
                _14102 = NOVALUE;
                goto L8; // [198] 216
            }
            DeRef(_14102);
            _14102 = NOVALUE;
        }
        DeRef(_14102);
        _14102 = NOVALUE;

        /** shift.e:354				jump[i] += amount*/
        _2 = (object)SEQ_PTR(_jump_25148);
        _14103 = (object)*(((s1_ptr)_2)->base + _i_25157);
        if (IS_ATOM_INT(_14103)) {
            _14104 = _14103 + _amount_25115;
            if ((object)((uintptr_t)_14104 + (uintptr_t)HIGH_BITS) >= 0){
                _14104 = NewDouble((eudouble)_14104);
            }
        }
        else {
            _14104 = binary_op(PLUS, _14103, _amount_25115);
        }
        _14103 = NOVALUE;
        _2 = (object)SEQ_PTR(_jump_25148);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _jump_25148 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_25157);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _14104;
        if( _1 != _14104 ){
            DeRef(_1);
        }
        _14104 = NOVALUE;
L8: 

        /** shift.e:356		end for*/
        _i_25157 = _i_25157 + 1;
        goto L6; // [218] 175
L7: 
        ;
    }

    /** shift.e:357		SymTab[Code[pc+3]][S_OBJ] = jump*/
    _14105 = _pc_25113 + 3;
    _2 = (object)SEQ_PTR(_36Code_21859);
    _14106 = (object)*(((s1_ptr)_2)->base + _14105);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_14106))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_14106)->dbl));
    else
    _3 = (object)(_14106 + ((s1_ptr)_2)->base);
    RefDS(_jump_25148);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _jump_25148;
    DeRef(_1);
    _14107 = NOVALUE;

    /** shift.e:358	end procedure*/
    DeRefDS(_jump_25148);
    _14106 = NOVALUE;
    DeRef(_14085);
    _14085 = NOVALUE;
    DeRef(_14076);
    _14076 = NOVALUE;
    _14094 = NOVALUE;
    DeRef(_14079);
    _14079 = NOVALUE;
    _14105 = NOVALUE;
    DeRef(_14098);
    _14098 = NOVALUE;
    DeRef(_14093);
    _14093 = NOVALUE;
    DeRef(_14090);
    _14090 = NOVALUE;
    DeRef(_14073);
    _14073 = NOVALUE;
    DeRef(_14082);
    _14082 = NOVALUE;
    return;
    ;
}


void _66shift_addr(object _pc_25176, object _amount_25177, object _start_25178, object _bound_25179)
{
    object _int_25180 = NOVALUE;
    object _14122 = NOVALUE;
    object _14119 = NOVALUE;
    object _14115 = NOVALUE;
    object _14110 = NOVALUE;
    object _14109 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_pc_25176)) {
        _1 = (object)(DBL_PTR(_pc_25176)->dbl);
        DeRefDS(_pc_25176);
        _pc_25176 = _1;
    }

    /** shift.e:362		if atom( Code[pc] ) then*/
    _2 = (object)SEQ_PTR(_36Code_21859);
    _14109 = (object)*(((s1_ptr)_2)->base + _pc_25176);
    _14110 = IS_ATOM(_14109);
    _14109 = NOVALUE;
    if (_14110 == 0)
    {
        _14110 = NOVALUE;
        goto L1; // [20] 75
    }
    else{
        _14110 = NOVALUE;
    }

    /** shift.e:363			int = Code[pc]*/
    _2 = (object)SEQ_PTR(_36Code_21859);
    _int_25180 = (object)*(((s1_ptr)_2)->base + _pc_25176);
    if (!IS_ATOM_INT(_int_25180)){
        _int_25180 = (object)DBL_PTR(_int_25180)->dbl;
    }

    /** shift.e:364			if int >= start then*/
    if (_int_25180 < _start_25178)
    goto L2; // [35] 139

    /** shift.e:365				if int < bound then*/
    if (_int_25180 >= _bound_25179)
    goto L3; // [41] 56

    /** shift.e:366					Code[pc] = start*/
    _2 = (object)SEQ_PTR(_36Code_21859);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _36Code_21859 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _pc_25176);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _start_25178;
    DeRef(_1);
    goto L2; // [53] 139
L3: 

    /** shift.e:368					int += amount*/
    _int_25180 = _int_25180 + _amount_25177;

    /** shift.e:369					Code[pc] = int*/
    _2 = (object)SEQ_PTR(_36Code_21859);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _36Code_21859 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _pc_25176);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _int_25180;
    DeRef(_1);
    goto L2; // [72] 139
L1: 

    /** shift.e:373			int = Code[pc][2]*/
    _2 = (object)SEQ_PTR(_36Code_21859);
    _14115 = (object)*(((s1_ptr)_2)->base + _pc_25176);
    _2 = (object)SEQ_PTR(_14115);
    _int_25180 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_int_25180)){
        _int_25180 = (object)DBL_PTR(_int_25180)->dbl;
    }
    _14115 = NOVALUE;

    /** shift.e:374			if int >= start then*/
    if (_int_25180 < _start_25178)
    goto L4; // [91] 138

    /** shift.e:375				if int < bound then*/
    if (_int_25180 >= _bound_25179)
    goto L5; // [97] 117

    /** shift.e:376					Code[pc][2] = start*/
    _2 = (object)SEQ_PTR(_36Code_21859);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _36Code_21859 = MAKE_SEQ(_2);
    }
    _3 = (object)(_pc_25176 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _start_25178;
    DeRef(_1);
    _14119 = NOVALUE;
    goto L6; // [114] 137
L5: 

    /** shift.e:378					int += amount*/
    _int_25180 = _int_25180 + _amount_25177;

    /** shift.e:379					Code[pc][2] = int*/
    _2 = (object)SEQ_PTR(_36Code_21859);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _36Code_21859 = MAKE_SEQ(_2);
    }
    _3 = (object)(_pc_25176 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _int_25180;
    DeRef(_1);
    _14122 = NOVALUE;
L6: 
L4: 
L2: 

    /** shift.e:383	end procedure*/
    return;
    ;
}


void _66shift(object _start_25213, object _amount_25214, object _bound_25215)
{
    object _int_25218 = NOVALUE;
    object _pc_25231 = NOVALUE;
    object _op_25232 = NOVALUE;
    object _finish_25233 = NOVALUE;
    object _len_25236 = NOVALUE;
    object _size_type_25261 = NOVALUE;
    object _14149 = NOVALUE;
    object _14147 = NOVALUE;
    object _14144 = NOVALUE;
    object _14142 = NOVALUE;
    object _14139 = NOVALUE;
    object _14138 = NOVALUE;
    object _14137 = NOVALUE;
    object _14135 = NOVALUE;
    object _14130 = NOVALUE;
    object _14125 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_start_25213)) {
        _1 = (object)(DBL_PTR(_start_25213)->dbl);
        DeRefDS(_start_25213);
        _start_25213 = _1;
    }
    if (!IS_ATOM_INT(_amount_25214)) {
        _1 = (object)(DBL_PTR(_amount_25214)->dbl);
        DeRefDS(_amount_25214);
        _amount_25214 = _1;
    }
    if (!IS_ATOM_INT(_bound_25215)) {
        _1 = (object)(DBL_PTR(_bound_25215)->dbl);
        DeRefDS(_bound_25215);
        _bound_25215 = _1;
    }

    /** shift.e:388		if amount = 0 then*/
    if (_amount_25214 != 0)
    goto L1; // [9] 19

    /** shift.e:389			return*/
    return;
L1: 

    /** shift.e:392		integer int*/

    /** shift.e:393		for i = length( LineTable ) to 1 by -1 do*/
    if (IS_SEQUENCE(_36LineTable_21860)){
            _14125 = SEQ_PTR(_36LineTable_21860)->length;
    }
    else {
        _14125 = 1;
    }
    {
        object _i_25220;
        _i_25220 = _14125;
L2: 
        if (_i_25220 < 1){
            goto L3; // [28] 84
        }

        /** shift.e:394			int = LineTable[i]*/
        _2 = (object)SEQ_PTR(_36LineTable_21860);
        _int_25218 = (object)*(((s1_ptr)_2)->base + _i_25220);
        if (!IS_ATOM_INT(_int_25218)){
            _int_25218 = (object)DBL_PTR(_int_25218)->dbl;
        }

        /** shift.e:395			if int > 0 then*/
        if (_int_25218 <= 0)
        goto L4; // [47] 77

        /** shift.e:396				if int < start then*/
        if (_int_25218 >= _start_25213)
        goto L5; // [53] 62

        /** shift.e:397					exit*/
        goto L3; // [59] 84
L5: 

        /** shift.e:399				int += amount*/
        _int_25218 = _int_25218 + _amount_25214;

        /** shift.e:400				LineTable[i] = int*/
        _2 = (object)SEQ_PTR(_36LineTable_21860);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _36LineTable_21860 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_25220);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _int_25218;
        DeRef(_1);
L4: 

        /** shift.e:402		end for*/
        _i_25220 = _i_25220 + -1;
        goto L2; // [79] 35
L3: 
        ;
    }

    /** shift.e:404		integer pc = 1*/
    _pc_25231 = 1;

    /** shift.e:405		integer op*/

    /** shift.e:406		integer finish = start + amount - 1*/
    _14130 = _start_25213 + _amount_25214;
    if ((object)((uintptr_t)_14130 + (uintptr_t)HIGH_BITS) >= 0){
        _14130 = NewDouble((eudouble)_14130);
    }
    if (IS_ATOM_INT(_14130)) {
        _finish_25233 = _14130 - 1;
    }
    else {
        _finish_25233 = NewDouble(DBL_PTR(_14130)->dbl - (eudouble)1);
    }
    DeRef(_14130);
    _14130 = NOVALUE;
    if (!IS_ATOM_INT(_finish_25233)) {
        _1 = (object)(DBL_PTR(_finish_25233)->dbl);
        DeRefDS(_finish_25233);
        _finish_25233 = _1;
    }

    /** shift.e:407		integer len = length( Code )*/
    if (IS_SEQUENCE(_36Code_21859)){
            _len_25236 = SEQ_PTR(_36Code_21859)->length;
    }
    else {
        _len_25236 = 1;
    }

    /** shift.e:408		while pc <= len do*/
L6: 
    if (_pc_25231 > _len_25236)
    goto L7; // [115] 278

    /** shift.e:409			op = Code[pc]*/
    _2 = (object)SEQ_PTR(_36Code_21859);
    _op_25232 = (object)*(((s1_ptr)_2)->base + _pc_25231);
    if (!IS_ATOM_INT(_op_25232)){
        _op_25232 = (object)DBL_PTR(_op_25232)->dbl;
    }

    /** shift.e:410			if pc < start or pc > finish then*/
    _14135 = (_pc_25231 < _start_25213);
    if (_14135 != 0) {
        goto L8; // [135] 148
    }
    _14137 = (_pc_25231 > _finish_25233);
    if (_14137 == 0)
    {
        DeRef(_14137);
        _14137 = NOVALUE;
        goto L9; // [144] 223
    }
    else{
        DeRef(_14137);
        _14137 = NOVALUE;
    }
L8: 

    /** shift.e:412				if length( op_info_addr[op] ) then*/
    _2 = (object)SEQ_PTR(_66op_info_addr_24569);
    _14138 = (object)*(((s1_ptr)_2)->base + _op_25232);
    if (IS_SEQUENCE(_14138)){
            _14139 = SEQ_PTR(_14138)->length;
    }
    else {
        _14139 = 1;
    }
    _14138 = NOVALUE;
    if (_14139 == 0)
    {
        _14139 = NOVALUE;
        goto LA; // [159] 222
    }
    else{
        _14139 = NOVALUE;
    }

    /** shift.e:414					switch op with fallthru do*/
    _0 = _op_25232;
    switch ( _0 ){ 

        /** shift.e:415						case SWITCH then*/
        case 185:
        case 193:
        case 192:
        case 202:

        /** shift.e:420							shift_switch( pc, start, amount )*/
        _66shift_switch(_pc_25231, _start_25213, _amount_25214);

        /** shift.e:421							break*/
        goto LB; // [188] 221

        /** shift.e:423						case else*/
        default:

        /** shift.e:424							int = op_info_addr[op][1]*/
        _2 = (object)SEQ_PTR(_66op_info_addr_24569);
        _14142 = (object)*(((s1_ptr)_2)->base + _op_25232);
        _2 = (object)SEQ_PTR(_14142);
        _int_25218 = (object)*(((s1_ptr)_2)->base + 1);
        if (!IS_ATOM_INT(_int_25218)){
            _int_25218 = (object)DBL_PTR(_int_25218)->dbl;
        }
        _14142 = NOVALUE;

        /** shift.e:425							shift_addr( pc + int, amount, start, bound )*/
        _14144 = _pc_25231 + _int_25218;
        if ((object)((uintptr_t)_14144 + (uintptr_t)HIGH_BITS) >= 0){
            _14144 = NewDouble((eudouble)_14144);
        }
        _66shift_addr(_14144, _amount_25214, _start_25213, _bound_25215);
        _14144 = NOVALUE;
    ;}LB: 
LA: 
L9: 

    /** shift.e:430			integer size_type = op_info_size_type[op]*/
    _2 = (object)SEQ_PTR(_66op_info_size_type_24567);
    _size_type_25261 = (object)*(((s1_ptr)_2)->base + _op_25232);
    if (!IS_ATOM_INT(_size_type_25261))
    _size_type_25261 = (object)DBL_PTR(_size_type_25261)->dbl;

    /** shift.e:431			if size_type = FIXED_SIZE then*/
    if (_size_type_25261 != 1)
    goto LC; // [233] 254

    /** shift.e:433				pc += op_info_size[op]*/
    _2 = (object)SEQ_PTR(_66op_info_size_24568);
    _14147 = (object)*(((s1_ptr)_2)->base + _op_25232);
    if (IS_ATOM_INT(_14147)) {
        _pc_25231 = _pc_25231 + _14147;
    }
    else {
        _pc_25231 = binary_op(PLUS, _pc_25231, _14147);
    }
    _14147 = NOVALUE;
    if (!IS_ATOM_INT(_pc_25231)) {
        _1 = (object)(DBL_PTR(_pc_25231)->dbl);
        DeRefDS(_pc_25231);
        _pc_25231 = _1;
    }
    goto LD; // [251] 271
LC: 

    /** shift.e:435				pc += variable_op_size( pc, op )*/
    RefDS(_36Code_21859);
    _14149 = _66variable_op_size(_pc_25231, _op_25232, _36Code_21859);
    if (IS_ATOM_INT(_14149)) {
        _pc_25231 = _pc_25231 + _14149;
    }
    else {
        _pc_25231 = binary_op(PLUS, _pc_25231, _14149);
    }
    DeRef(_14149);
    _14149 = NOVALUE;
    if (!IS_ATOM_INT(_pc_25231)) {
        _1 = (object)(DBL_PTR(_pc_25231)->dbl);
        DeRefDS(_pc_25231);
        _pc_25231 = _1;
    }
LD: 

    /** shift.e:437		end while*/
    goto L6; // [275] 115
L7: 

    /** shift.e:438		shift_fwd_refs( start, amount )*/
    _44shift_fwd_refs(_start_25213, _amount_25214);

    /** shift.e:439		move_last_pc( amount )*/
    _47move_last_pc(_amount_25214);

    /** shift.e:440	end procedure*/
    _14138 = NOVALUE;
    DeRef(_14135);
    _14135 = NOVALUE;
    return;
    ;
}


void _66insert_code(object _code_25275, object _index_25276)
{
    object _14152 = NOVALUE;
    object _0, _1, _2;
    

    /** shift.e:443		Code = splice( Code, code, index )*/
    {
        s1_ptr assign_space;
        insert_pos = _index_25276;
        if (insert_pos <= 0) {
            Concat(&_36Code_21859,_code_25275,_36Code_21859);
        }
        else if (insert_pos > SEQ_PTR(_36Code_21859)->length){
            Concat(&_36Code_21859,_36Code_21859,_code_25275);
        }
        else if (IS_SEQUENCE(_code_25275)) {
            if( _36Code_21859 != _36Code_21859 || SEQ_PTR( _36Code_21859 )->ref != 1 ){
                DeRef( _36Code_21859 );
                RefDS( _36Code_21859 );
            }
            assign_space = Add_internal_space( _36Code_21859, insert_pos,((s1_ptr)SEQ_PTR(_code_25275))->length);
            assign_slice_seq = &assign_space;
            assign_space = Copy_elements( insert_pos, SEQ_PTR(_code_25275), _36Code_21859 == _36Code_21859 );
            _36Code_21859 = MAKE_SEQ( assign_space );
        }
        else {
            if( _36Code_21859 == _36Code_21859 && SEQ_PTR( _36Code_21859 )->ref == 1 ){
                _36Code_21859 = Insert( _36Code_21859, _code_25275, insert_pos);
            }
            else {
                DeRef( _36Code_21859 );
                RefDS( _36Code_21859 );
                _36Code_21859 = Insert( _36Code_21859, _code_25275, insert_pos);
            }
        }
    }

    /** shift.e:444		shift( index, length( code ) )*/
    if (IS_SEQUENCE(_code_25275)){
            _14152 = SEQ_PTR(_code_25275)->length;
    }
    else {
        _14152 = 1;
    }
    _66shift(_index_25276, _14152, _index_25276);
    _14152 = NOVALUE;

    /** shift.e:445	end procedure*/
    DeRefDSi(_code_25275);
    return;
    ;
}


void _66replace_code(object _code_25283, object _start_25284, object _finish_25285)
{
    object _14157 = NOVALUE;
    object _14156 = NOVALUE;
    object _14155 = NOVALUE;
    object _14154 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_start_25284)) {
        _1 = (object)(DBL_PTR(_start_25284)->dbl);
        DeRefDS(_start_25284);
        _start_25284 = _1;
    }
    if (!IS_ATOM_INT(_finish_25285)) {
        _1 = (object)(DBL_PTR(_finish_25285)->dbl);
        DeRefDS(_finish_25285);
        _finish_25285 = _1;
    }

    /** shift.e:448		Code = replace( Code, code, start, finish )*/
    {
        intptr_t p1 = _36Code_21859;
        intptr_t p2 = _code_25283;
        intptr_t p3 = _start_25284;
        intptr_t p4 = _finish_25285;
        struct replace_block replace_params;
        replace_params.copy_to   = &p1;
        replace_params.copy_from = &p2;
        replace_params.start     = &p3;
        replace_params.stop      = &p4;
        replace_params.target    = &_36Code_21859;
        Replace( &replace_params );
    }

    /** shift.e:449		shift( start, length( code ) - (finish - start + 1), finish )*/
    if (IS_SEQUENCE(_code_25283)){
            _14154 = SEQ_PTR(_code_25283)->length;
    }
    else {
        _14154 = 1;
    }
    _14155 = _finish_25285 - _start_25284;
    if ((object)((uintptr_t)_14155 +(uintptr_t) HIGH_BITS) >= 0){
        _14155 = NewDouble((eudouble)_14155);
    }
    if (IS_ATOM_INT(_14155)) {
        _14156 = _14155 + 1;
        if (_14156 > MAXINT){
            _14156 = NewDouble((eudouble)_14156);
        }
    }
    else
    _14156 = binary_op(PLUS, 1, _14155);
    DeRef(_14155);
    _14155 = NOVALUE;
    if (IS_ATOM_INT(_14156)) {
        _14157 = _14154 - _14156;
        if ((object)((uintptr_t)_14157 +(uintptr_t) HIGH_BITS) >= 0){
            _14157 = NewDouble((eudouble)_14157);
        }
    }
    else {
        _14157 = NewDouble((eudouble)_14154 - DBL_PTR(_14156)->dbl);
    }
    _14154 = NOVALUE;
    DeRef(_14156);
    _14156 = NOVALUE;
    _66shift(_start_25284, _14157, _finish_25285);
    _14157 = NOVALUE;

    /** shift.e:450	end procedure*/
    DeRefDS(_code_25283);
    return;
    ;
}


object _66current_op(object _pc_25295, object _code_25296)
{
    object _14165 = NOVALUE;
    object _14164 = NOVALUE;
    object _14163 = NOVALUE;
    object _14162 = NOVALUE;
    object _14161 = NOVALUE;
    object _14159 = NOVALUE;
    object _14158 = NOVALUE;
    object _0, _1, _2;
    

    /** shift.e:456		if pc > length(code) or pc < 1 then*/
    if (IS_SEQUENCE(_code_25296)){
            _14158 = SEQ_PTR(_code_25296)->length;
    }
    else {
        _14158 = 1;
    }
    _14159 = (_pc_25295 > _14158);
    _14158 = NOVALUE;
    if (_14159 != 0) {
        goto L1; // [14] 27
    }
    _14161 = (_pc_25295 < 1);
    if (_14161 == 0)
    {
        DeRef(_14161);
        _14161 = NOVALUE;
        goto L2; // [23] 34
    }
    else{
        DeRef(_14161);
        _14161 = NOVALUE;
    }
L1: 

    /** shift.e:457			return {}*/
    RefDS(_5);
    DeRefDS(_code_25296);
    DeRef(_14159);
    _14159 = NOVALUE;
    return _5;
L2: 

    /** shift.e:459		return code[pc..pc-1+op_size( pc, code )]*/
    _14162 = _pc_25295 - 1;
    if ((object)((uintptr_t)_14162 +(uintptr_t) HIGH_BITS) >= 0){
        _14162 = NewDouble((eudouble)_14162);
    }
    RefDS(_code_25296);
    _14163 = _66op_size(_pc_25295, _code_25296);
    if (IS_ATOM_INT(_14162) && IS_ATOM_INT(_14163)) {
        _14164 = _14162 + _14163;
    }
    else {
        _14164 = binary_op(PLUS, _14162, _14163);
    }
    DeRef(_14162);
    _14162 = NOVALUE;
    DeRef(_14163);
    _14163 = NOVALUE;
    rhs_slice_target = (object_ptr)&_14165;
    RHS_Slice(_code_25296, _pc_25295, _14164);
    DeRefDS(_code_25296);
    DeRef(_14164);
    _14164 = NOVALUE;
    DeRef(_14159);
    _14159 = NOVALUE;
    return _14165;
    ;
}


object _66get_ops(object _pc_25310, object _offset_25311, object _num_ops_25312, object _code_25313)
{
    object _sign_25316 = NOVALUE;
    object _ops_25325 = NOVALUE;
    object _opx_25327 = NOVALUE;
    object _14182 = NOVALUE;
    object _14181 = NOVALUE;
    object _14177 = NOVALUE;
    object _14176 = NOVALUE;
    object _14175 = NOVALUE;
    object _14174 = NOVALUE;
    object _14173 = NOVALUE;
    object _14172 = NOVALUE;
    object _0, _1, _2;
    

    /** shift.e:466		integer sign = offset >= 0*/
    _sign_25316 = (_offset_25311 >= 0);

    /** shift.e:467		if not sign then*/
    if (_sign_25316 != 0)
    goto L1; // [17] 33

    /** shift.e:468			offset = -offset*/
    _offset_25311 = - _offset_25311;

    /** shift.e:469			sign = -1*/
    _sign_25316 = -1;
L1: 

    /** shift.e:472		while offset do*/
L2: 
    if (_offset_25311 == 0)
    {
        goto L3; // [38] 63
    }
    else{
    }

    /** shift.e:473			pc = advance( pc )*/
    RefDS(_36Code_21859);
    _pc_25310 = _66advance(_pc_25310, _36Code_21859);
    if (!IS_ATOM_INT(_pc_25310)) {
        _1 = (object)(DBL_PTR(_pc_25310)->dbl);
        DeRefDS(_pc_25310);
        _pc_25310 = _1;
    }

    /** shift.e:474			offset -= sign*/
    _offset_25311 = _offset_25311 - _sign_25316;

    /** shift.e:475		end while*/
    goto L2; // [60] 38
L3: 

    /** shift.e:477		sequence ops = repeat( 0, num_ops )*/
    DeRef(_ops_25325);
    _ops_25325 = Repeat(0, _num_ops_25312);

    /** shift.e:478		integer opx = 1*/
    _opx_25327 = 1;

    /** shift.e:479		while num_ops and pc <= length(code) do*/
L4: 
    if (_num_ops_25312 == 0) {
        goto L5; // [79] 137
    }
    if (IS_SEQUENCE(_code_25313)){
            _14173 = SEQ_PTR(_code_25313)->length;
    }
    else {
        _14173 = 1;
    }
    _14174 = (_pc_25310 <= _14173);
    _14173 = NOVALUE;
    if (_14174 == 0)
    {
        DeRef(_14174);
        _14174 = NOVALUE;
        goto L5; // [91] 137
    }
    else{
        DeRef(_14174);
        _14174 = NOVALUE;
    }

    /** shift.e:480			ops[opx] = current_op( pc )*/
    RefDS(_36Code_21859);
    _14175 = _66current_op(_pc_25310, _36Code_21859);
    _2 = (object)SEQ_PTR(_ops_25325);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _ops_25325 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _opx_25327);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14175;
    if( _1 != _14175 ){
        DeRef(_1);
    }
    _14175 = NOVALUE;

    /** shift.e:481			pc += length( ops[opx] )*/
    _2 = (object)SEQ_PTR(_ops_25325);
    _14176 = (object)*(((s1_ptr)_2)->base + _opx_25327);
    if (IS_SEQUENCE(_14176)){
            _14177 = SEQ_PTR(_14176)->length;
    }
    else {
        _14177 = 1;
    }
    _14176 = NOVALUE;
    _pc_25310 = _pc_25310 + _14177;
    _14177 = NOVALUE;

    /** shift.e:482			opx += 1*/
    _opx_25327 = _opx_25327 + 1;

    /** shift.e:483			num_ops -= 1*/
    _num_ops_25312 = _num_ops_25312 - 1;

    /** shift.e:484		end while*/
    goto L4; // [134] 79
L5: 

    /** shift.e:485		if num_ops then*/
    if (_num_ops_25312 == 0)
    {
        goto L6; // [139] 156
    }
    else{
    }

    /** shift.e:486			ops = head( ops, length( ops ) - num_ops )*/
    if (IS_SEQUENCE(_ops_25325)){
            _14181 = SEQ_PTR(_ops_25325)->length;
    }
    else {
        _14181 = 1;
    }
    _14182 = _14181 - _num_ops_25312;
    if ((object)((uintptr_t)_14182 +(uintptr_t) HIGH_BITS) >= 0){
        _14182 = NewDouble((eudouble)_14182);
    }
    _14181 = NOVALUE;
    {
        int len = SEQ_PTR(_ops_25325)->length;
        int size = (IS_ATOM_INT(_14182)) ? _14182 : (object)(DBL_PTR(_14182)->dbl);
        if (size <= 0){
            DeRef( _ops_25325 );
            _ops_25325 = MAKE_SEQ(NewS1(0));
        }
        else if (len <= size) {
            RefDS(_ops_25325);
            DeRef(_ops_25325);
            _ops_25325 = _ops_25325;
        }
        else{
            Head(SEQ_PTR(_ops_25325),size+1,&_ops_25325);
        }
    }
    DeRef(_14182);
    _14182 = NOVALUE;
L6: 

    /** shift.e:488		return ops*/
    DeRefDS(_code_25313);
    _14176 = NOVALUE;
    return _ops_25325;
    ;
}


object _66find_ops(object _pc_25345, object _op_25346, object _code_25347)
{
    object _ops_25350 = NOVALUE;
    object _found_op_25354 = NOVALUE;
    object _14191 = NOVALUE;
    object _14189 = NOVALUE;
    object _14187 = NOVALUE;
    object _14184 = NOVALUE;
    object _0, _1, _2;
    

    /** shift.e:492		sequence ops = {}*/
    RefDS(_5);
    DeRef(_ops_25350);
    _ops_25350 = _5;

    /** shift.e:493		while pc <= length(code) do*/
L1: 
    if (IS_SEQUENCE(_code_25347)){
            _14184 = SEQ_PTR(_code_25347)->length;
    }
    else {
        _14184 = 1;
    }
    if (_pc_25345 > _14184)
    goto L2; // [22] 74

    /** shift.e:494			sequence found_op = current_op( pc )*/
    RefDS(_36Code_21859);
    _0 = _found_op_25354;
    _found_op_25354 = _66current_op(_pc_25345, _36Code_21859);
    DeRef(_0);

    /** shift.e:495			if found_op[1] = op then*/
    _2 = (object)SEQ_PTR(_found_op_25354);
    _14187 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _14187, _op_25346)){
        _14187 = NOVALUE;
        goto L3; // [43] 58
    }
    _14187 = NOVALUE;

    /** shift.e:496				ops = append( ops, { pc, found_op } )*/
    RefDS(_found_op_25354);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _pc_25345;
    ((intptr_t *)_2)[2] = _found_op_25354;
    _14189 = MAKE_SEQ(_1);
    RefDS(_14189);
    Append(&_ops_25350, _ops_25350, _14189);
    DeRefDS(_14189);
    _14189 = NOVALUE;
L3: 

    /** shift.e:498			pc += length( found_op )*/
    if (IS_SEQUENCE(_found_op_25354)){
            _14191 = SEQ_PTR(_found_op_25354)->length;
    }
    else {
        _14191 = 1;
    }
    _pc_25345 = _pc_25345 + _14191;
    _14191 = NOVALUE;
    DeRefDS(_found_op_25354);
    _found_op_25354 = NOVALUE;

    /** shift.e:499		end while*/
    goto L1; // [71] 19
L2: 

    /** shift.e:500		return ops*/
    DeRefDS(_code_25347);
    return _ops_25350;
    ;
}


object _66get_target_sym(object _opseq_25366)
{
    object _op_25370 = NOVALUE;
    object _info_25372 = NOVALUE;
    object _targets_25388 = NOVALUE;
    object _sub_25403 = NOVALUE;
    object _14223 = NOVALUE;
    object _14222 = NOVALUE;
    object _14221 = NOVALUE;
    object _14220 = NOVALUE;
    object _14219 = NOVALUE;
    object _14218 = NOVALUE;
    object _14217 = NOVALUE;
    object _14215 = NOVALUE;
    object _14211 = NOVALUE;
    object _14210 = NOVALUE;
    object _14209 = NOVALUE;
    object _14208 = NOVALUE;
    object _14206 = NOVALUE;
    object _14205 = NOVALUE;
    object _14204 = NOVALUE;
    object _14203 = NOVALUE;
    object _14200 = NOVALUE;
    object _14199 = NOVALUE;
    object _14197 = NOVALUE;
    object _14193 = NOVALUE;
    object _0, _1, _2;
    

    /** shift.e:509		if not length( opseq ) then*/
    if (IS_SEQUENCE(_opseq_25366)){
            _14193 = SEQ_PTR(_opseq_25366)->length;
    }
    else {
        _14193 = 1;
    }
    if (_14193 != 0)
    goto L1; // [8] 18
    _14193 = NOVALUE;

    /** shift.e:510			return 0*/
    DeRefDS(_opseq_25366);
    DeRef(_info_25372);
    return 0;
L1: 

    /** shift.e:512		integer op = opseq[1]*/
    _2 = (object)SEQ_PTR(_opseq_25366);
    _op_25370 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_op_25370))
    _op_25370 = (object)DBL_PTR(_op_25370)->dbl;

    /** shift.e:513		sequence info = op_info[op]*/
    DeRef(_info_25372);
    _2 = (object)SEQ_PTR(_66op_info_24561);
    _info_25372 = (object)*(((s1_ptr)_2)->base + _op_25370);
    Ref(_info_25372);

    /** shift.e:515		if info[OP_SIZE_TYPE] = FIXED_SIZE then*/
    _2 = (object)SEQ_PTR(_info_25372);
    _14197 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _14197, 1)){
        _14197 = NOVALUE;
        goto L2; // [40] 157
    }
    _14197 = NOVALUE;

    /** shift.e:516			switch length( info[OP_TARGET] ) do*/
    _2 = (object)SEQ_PTR(_info_25372);
    _14199 = (object)*(((s1_ptr)_2)->base + 4);
    if (IS_SEQUENCE(_14199)){
            _14200 = SEQ_PTR(_14199)->length;
    }
    else {
        _14200 = 1;
    }
    _14199 = NOVALUE;
    _0 = _14200;
    _14200 = NOVALUE;
    switch ( _0 ){ 

        /** shift.e:517				case 0 then*/
        case 0:

        /** shift.e:518					break*/
        goto L3; // [64] 152
        goto L3; // [66] 152

        /** shift.e:520				case 1 then*/
        case 1:

        /** shift.e:521					return opseq[info[OP_TARGET][1]+1]*/
        _2 = (object)SEQ_PTR(_info_25372);
        _14203 = (object)*(((s1_ptr)_2)->base + 4);
        _2 = (object)SEQ_PTR(_14203);
        _14204 = (object)*(((s1_ptr)_2)->base + 1);
        _14203 = NOVALUE;
        if (IS_ATOM_INT(_14204)) {
            _14205 = _14204 + 1;
        }
        else
        _14205 = binary_op(PLUS, 1, _14204);
        _14204 = NOVALUE;
        _2 = (object)SEQ_PTR(_opseq_25366);
        if (!IS_ATOM_INT(_14205)){
            _14206 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_14205)->dbl));
        }
        else{
            _14206 = (object)*(((s1_ptr)_2)->base + _14205);
        }
        Ref(_14206);
        DeRefDS(_opseq_25366);
        DeRefDS(_info_25372);
        _14199 = NOVALUE;
        DeRef(_14205);
        _14205 = NOVALUE;
        return _14206;
        goto L3; // [94] 152

        /** shift.e:523				case else*/
        default:

        /** shift.e:524					sequence targets = info[OP_TARGET]*/
        DeRef(_targets_25388);
        _2 = (object)SEQ_PTR(_info_25372);
        _targets_25388 = (object)*(((s1_ptr)_2)->base + 4);
        Ref(_targets_25388);

        /** shift.e:525					for i = 1 to length( targets ) do*/
        if (IS_SEQUENCE(_targets_25388)){
                _14208 = SEQ_PTR(_targets_25388)->length;
        }
        else {
            _14208 = 1;
        }
        {
            object _i_25391;
            _i_25391 = 1;
L4: 
            if (_i_25391 > _14208){
                goto L5; // [113] 145
            }

            /** shift.e:526						targets[i] = opseq[targets[i] + 1]*/
            _2 = (object)SEQ_PTR(_targets_25388);
            _14209 = (object)*(((s1_ptr)_2)->base + _i_25391);
            if (IS_ATOM_INT(_14209)) {
                _14210 = _14209 + 1;
            }
            else
            _14210 = binary_op(PLUS, 1, _14209);
            _14209 = NOVALUE;
            _2 = (object)SEQ_PTR(_opseq_25366);
            if (!IS_ATOM_INT(_14210)){
                _14211 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_14210)->dbl));
            }
            else{
                _14211 = (object)*(((s1_ptr)_2)->base + _14210);
            }
            Ref(_14211);
            _2 = (object)SEQ_PTR(_targets_25388);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _targets_25388 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + _i_25391);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _14211;
            if( _1 != _14211 ){
                DeRef(_1);
            }
            _14211 = NOVALUE;

            /** shift.e:527					end for*/
            _i_25391 = _i_25391 + 1;
            goto L4; // [140] 120
L5: 
            ;
        }

        /** shift.e:529					return targets*/
        DeRefDS(_opseq_25366);
        DeRef(_info_25372);
        _14206 = NOVALUE;
        DeRef(_14210);
        _14210 = NOVALUE;
        _14199 = NOVALUE;
        DeRef(_14205);
        _14205 = NOVALUE;
        return _targets_25388;
    ;}L3: 
    DeRef(_targets_25388);
    _targets_25388 = NOVALUE;
    goto L6; // [154] 253
L2: 

    /** shift.e:535			switch op do*/
    _0 = _op_25370;
    switch ( _0 ){ 

        /** shift.e:536				case PROC, PROC_TAIL then*/
        case 27:
        case 203:

        /** shift.e:537					symtab_index sub = opseq[2]*/
        _2 = (object)SEQ_PTR(_opseq_25366);
        _sub_25403 = (object)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_sub_25403)){
            _sub_25403 = (object)DBL_PTR(_sub_25403)->dbl;
        }

        /** shift.e:538					if sym_token( sub ) = FUNC then*/
        _14215 = _54sym_token(_sub_25403);
        if (binary_op_a(NOTEQ, _14215, 501)){
            DeRef(_14215);
            _14215 = NOVALUE;
            goto L7; // [186] 204
        }
        DeRef(_14215);
        _14215 = NOVALUE;

        /** shift.e:539						return opseq[$]*/
        if (IS_SEQUENCE(_opseq_25366)){
                _14217 = SEQ_PTR(_opseq_25366)->length;
        }
        else {
            _14217 = 1;
        }
        _2 = (object)SEQ_PTR(_opseq_25366);
        _14218 = (object)*(((s1_ptr)_2)->base + _14217);
        Ref(_14218);
        DeRefDS(_opseq_25366);
        DeRef(_info_25372);
        _14206 = NOVALUE;
        DeRef(_14210);
        _14210 = NOVALUE;
        _14199 = NOVALUE;
        DeRef(_14205);
        _14205 = NOVALUE;
        return _14218;
L7: 
        goto L8; // [206] 252

        /** shift.e:542				case FUNC_FORWARD then*/
        case 196:

        /** shift.e:543					return opseq[$]*/
        if (IS_SEQUENCE(_opseq_25366)){
                _14219 = SEQ_PTR(_opseq_25366)->length;
        }
        else {
            _14219 = 1;
        }
        _2 = (object)SEQ_PTR(_opseq_25366);
        _14220 = (object)*(((s1_ptr)_2)->base + _14219);
        Ref(_14220);
        DeRefDS(_opseq_25366);
        DeRef(_info_25372);
        _14218 = NOVALUE;
        _14206 = NOVALUE;
        DeRef(_14210);
        _14210 = NOVALUE;
        _14199 = NOVALUE;
        DeRef(_14205);
        _14205 = NOVALUE;
        return _14220;
        goto L8; // [225] 252

        /** shift.e:545				case RIGHT_BRACE_N, CONCAT_N then*/
        case 31:
        case 157:

        /** shift.e:546					return opseq[opseq[2]+2]*/
        _2 = (object)SEQ_PTR(_opseq_25366);
        _14221 = (object)*(((s1_ptr)_2)->base + 2);
        if (IS_ATOM_INT(_14221)) {
            _14222 = _14221 + 2;
        }
        else {
            _14222 = binary_op(PLUS, _14221, 2);
        }
        _14221 = NOVALUE;
        _2 = (object)SEQ_PTR(_opseq_25366);
        if (!IS_ATOM_INT(_14222)){
            _14223 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_14222)->dbl));
        }
        else{
            _14223 = (object)*(((s1_ptr)_2)->base + _14222);
        }
        Ref(_14223);
        DeRefDS(_opseq_25366);
        DeRef(_info_25372);
        _14218 = NOVALUE;
        _14206 = NOVALUE;
        DeRef(_14222);
        _14222 = NOVALUE;
        _14220 = NOVALUE;
        DeRef(_14210);
        _14210 = NOVALUE;
        _14199 = NOVALUE;
        DeRef(_14205);
        _14205 = NOVALUE;
        return _14223;
    ;}L8: 
L6: 

    /** shift.e:551		return 0*/
    DeRefDS(_opseq_25366);
    DeRef(_info_25372);
    _14218 = NOVALUE;
    _14206 = NOVALUE;
    _14223 = NOVALUE;
    DeRef(_14222);
    _14222 = NOVALUE;
    _14220 = NOVALUE;
    DeRef(_14210);
    _14210 = NOVALUE;
    _14199 = NOVALUE;
    DeRef(_14205);
    _14205 = NOVALUE;
    return 0;
    ;
}



// 0xDD109F1E
