// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _65block_type_name(object _opcode_25444)
{
    object _14233 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_opcode_25444)) {
        _1 = (object)(DBL_PTR(_opcode_25444)->dbl);
        DeRefDS(_opcode_25444);
        _opcode_25444 = _1;
    }

    /** block.e:51		switch opcode do*/
    _0 = _opcode_25444;
    switch ( _0 ){ 

        /** block.e:52			case LOOP then*/
        case 422:

        /** block.e:53				return "LOOP"*/
        RefDS(_14231);
        return _14231;
        goto L1; // [20] 63

        /** block.e:54			case PROC then*/
        case 27:

        /** block.e:55				return "PROC"*/
        RefDS(_13138);
        return _13138;
        goto L1; // [32] 63

        /** block.e:56			case FUNC then*/
        case 501:

        /** block.e:57				return "FUNC"*/
        RefDS(_14232);
        return _14232;
        goto L1; // [44] 63

        /** block.e:58			case else*/
        default:

        /** block.e:59				return opnames[opcode]*/
        _2 = (object)SEQ_PTR(_61opnames_23211);
        _14233 = (object)*(((s1_ptr)_2)->base + _opcode_25444);
        RefDS(_14233);
        return _14233;
    ;}L1: 
    ;
}


void _65check_block(object _got_25460)
{
    object _expected_25461 = NOVALUE;
    object _14241 = NOVALUE;
    object _14240 = NOVALUE;
    object _14239 = NOVALUE;
    object _14235 = NOVALUE;
    object _14234 = NOVALUE;
    object _0, _1, _2;
    

    /** block.e:64		integer expected = block_stack[$][BLOCK_OPCODE]*/
    if (IS_SEQUENCE(_65block_stack_25433)){
            _14234 = SEQ_PTR(_65block_stack_25433)->length;
    }
    else {
        _14234 = 1;
    }
    _2 = (object)SEQ_PTR(_65block_stack_25433);
    _14235 = (object)*(((s1_ptr)_2)->base + _14234);
    _2 = (object)SEQ_PTR(_14235);
    _expected_25461 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_expected_25461)){
        _expected_25461 = (object)DBL_PTR(_expected_25461)->dbl;
    }
    _14235 = NOVALUE;

    /** block.e:65		if got = FUNC then*/
    if (_got_25460 != 501)
    goto L1; // [24] 38

    /** block.e:66			got = PROC*/
    _got_25460 = 27;
L1: 

    /** block.e:68		if got != expected then*/
    if (_got_25460 == _expected_25461)
    goto L2; // [40] 66

    /** block.e:69			CompileErr( EXPECTED_END_OF_1_BLOCK_NOT_2, {block_type_name( expected ), block_type_name( got)} )*/
    _14239 = _65block_type_name(_expected_25461);
    _14240 = _65block_type_name(_got_25460);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _14239;
    ((intptr_t *)_2)[2] = _14240;
    _14241 = MAKE_SEQ(_1);
    _14240 = NOVALUE;
    _14239 = NOVALUE;
    _50CompileErr(79, _14241, 0);
    _14241 = NOVALUE;
L2: 

    /** block.e:71	end procedure*/
    return;
    ;
}


void _65Block_var(object _sym_25479)
{
    object _block_25480 = NOVALUE;
    object _14262 = NOVALUE;
    object _14261 = NOVALUE;
    object _14260 = NOVALUE;
    object _14258 = NOVALUE;
    object _14257 = NOVALUE;
    object _14255 = NOVALUE;
    object _14254 = NOVALUE;
    object _14253 = NOVALUE;
    object _14252 = NOVALUE;
    object _14251 = NOVALUE;
    object _14250 = NOVALUE;
    object _14249 = NOVALUE;
    object _14247 = NOVALUE;
    object _14245 = NOVALUE;
    object _14244 = NOVALUE;
    object _14242 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_sym_25479)) {
        _1 = (object)(DBL_PTR(_sym_25479)->dbl);
        DeRefDS(_sym_25479);
        _sym_25479 = _1;
    }

    /** block.e:75		sequence block = block_stack[$]*/
    if (IS_SEQUENCE(_65block_stack_25433)){
            _14242 = SEQ_PTR(_65block_stack_25433)->length;
    }
    else {
        _14242 = 1;
    }
    DeRef(_block_25480);
    _2 = (object)SEQ_PTR(_65block_stack_25433);
    _block_25480 = (object)*(((s1_ptr)_2)->base + _14242);
    Ref(_block_25480);

    /** block.e:76		block_stack[$] = 0*/
    if (IS_SEQUENCE(_65block_stack_25433)){
            _14244 = SEQ_PTR(_65block_stack_25433)->length;
    }
    else {
        _14244 = 1;
    }
    _2 = (object)SEQ_PTR(_65block_stack_25433);
    _2 = (object)(((s1_ptr)_2)->base + _14244);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);

    /** block.e:77		if length(block_stack) > 1 then*/
    if (IS_SEQUENCE(_65block_stack_25433)){
            _14245 = SEQ_PTR(_65block_stack_25433)->length;
    }
    else {
        _14245 = 1;
    }
    if (_14245 <= 1)
    goto L1; // [34] 58

    /** block.e:79			SymTab[sym][S_BLOCK] = block[BLOCK_SYM]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_25479 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_block_25480);
    _14249 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_14249);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_BLOCK_21424))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_BLOCK_21424)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_BLOCK_21424);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14249;
    if( _1 != _14249 ){
        DeRef(_1);
    }
    _14249 = NOVALUE;
    _14247 = NOVALUE;
L1: 

    /** block.e:82		if length(block[BLOCK_VARS]) then*/
    _2 = (object)SEQ_PTR(_block_25480);
    _14250 = (object)*(((s1_ptr)_2)->base + 6);
    if (IS_SEQUENCE(_14250)){
            _14251 = SEQ_PTR(_14250)->length;
    }
    else {
        _14251 = 1;
    }
    _14250 = NOVALUE;
    if (_14251 == 0)
    {
        _14251 = NOVALUE;
        goto L2; // [67] 99
    }
    else{
        _14251 = NOVALUE;
    }

    /** block.e:83			SymTab[block[BLOCK_VARS][$]][S_NEXT_IN_BLOCK] = sym*/
    _2 = (object)SEQ_PTR(_block_25480);
    _14252 = (object)*(((s1_ptr)_2)->base + 6);
    if (IS_SEQUENCE(_14252)){
            _14253 = SEQ_PTR(_14252)->length;
    }
    else {
        _14253 = 1;
    }
    _2 = (object)SEQ_PTR(_14252);
    _14254 = (object)*(((s1_ptr)_2)->base + _14253);
    _14252 = NOVALUE;
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_14254))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_14254)->dbl));
    else
    _3 = (object)(_14254 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_NEXT_IN_BLOCK_21396))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NEXT_IN_BLOCK_21396)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_NEXT_IN_BLOCK_21396);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _sym_25479;
    DeRef(_1);
    _14255 = NOVALUE;
    goto L3; // [96] 119
L2: 

    /** block.e:85			SymTab[block[BLOCK_SYM]][S_NEXT_IN_BLOCK] = sym*/
    _2 = (object)SEQ_PTR(_block_25480);
    _14257 = (object)*(((s1_ptr)_2)->base + 1);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_14257))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_14257)->dbl));
    else
    _3 = (object)(_14257 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_NEXT_IN_BLOCK_21396))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NEXT_IN_BLOCK_21396)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_NEXT_IN_BLOCK_21396);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _sym_25479;
    DeRef(_1);
    _14258 = NOVALUE;
L3: 

    /** block.e:88		block[BLOCK_VARS] &= sym*/
    _2 = (object)SEQ_PTR(_block_25480);
    _14260 = (object)*(((s1_ptr)_2)->base + 6);
    if (IS_SEQUENCE(_14260) && IS_ATOM(_sym_25479)) {
        Append(&_14261, _14260, _sym_25479);
    }
    else if (IS_ATOM(_14260) && IS_SEQUENCE(_sym_25479)) {
    }
    else {
        Concat((object_ptr)&_14261, _14260, _sym_25479);
        _14260 = NOVALUE;
    }
    _14260 = NOVALUE;
    _2 = (object)SEQ_PTR(_block_25480);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _block_25480 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 6);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14261;
    if( _1 != _14261 ){
        DeRef(_1);
    }
    _14261 = NOVALUE;

    /** block.e:90		block_stack[$] = block*/
    if (IS_SEQUENCE(_65block_stack_25433)){
            _14262 = SEQ_PTR(_65block_stack_25433)->length;
    }
    else {
        _14262 = 1;
    }
    RefDS(_block_25480);
    _2 = (object)SEQ_PTR(_65block_stack_25433);
    _2 = (object)(((s1_ptr)_2)->base + _14262);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _block_25480;
    DeRef(_1);

    /** block.e:91		ifdef BDEBUG then*/

    /** block.e:96	end procedure*/
    DeRefDS(_block_25480);
    _14250 = NOVALUE;
    _14254 = NOVALUE;
    _14257 = NOVALUE;
    return;
    ;
}


void _65NewBlock(object _opcode_25514, object _block_label_25515)
{
    object _block_25533 = NOVALUE;
    object _14276 = NOVALUE;
    object _14275 = NOVALUE;
    object _14274 = NOVALUE;
    object _14272 = NOVALUE;
    object _14270 = NOVALUE;
    object _14269 = NOVALUE;
    object _14267 = NOVALUE;
    object _14266 = NOVALUE;
    object _14264 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** block.e:101		SymTab = append( SymTab, repeat( 0, SIZEOF_BLOCK_ENTRY ) )*/
    _14264 = Repeat(0, _36SIZEOF_BLOCK_ENTRY_21536);
    RefDS(_14264);
    Append(&_37SymTab_15637, _37SymTab_15637, _14264);
    DeRefDS(_14264);
    _14264 = NOVALUE;

    /** block.e:102		SymTab[$][S_MODE] = M_BLOCK*/
    if (IS_SEQUENCE(_37SymTab_15637)){
            _14266 = SEQ_PTR(_37SymTab_15637)->length;
    }
    else {
        _14266 = 1;
    }
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_14266 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 4;
    DeRef(_1);
    _14267 = NOVALUE;

    /** block.e:103		SymTab[$][S_FIRST_LINE] = gline_number*/
    if (IS_SEQUENCE(_37SymTab_15637)){
            _14269 = SEQ_PTR(_37SymTab_15637)->length;
    }
    else {
        _14269 = 1;
    }
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_14269 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_FIRST_LINE_21429))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FIRST_LINE_21429)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_FIRST_LINE_21429);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36gline_number_21772;
    DeRef(_1);
    _14270 = NOVALUE;

    /** block.e:105		sequence block = repeat( 0, BLOCK_SIZE-1 )*/
    _14272 = 6;
    DeRef(_block_25533);
    _block_25533 = Repeat(0, 6);
    _14272 = NOVALUE;

    /** block.e:106		block[BLOCK_SYM]    = length(SymTab)*/
    if (IS_SEQUENCE(_37SymTab_15637)){
            _14274 = SEQ_PTR(_37SymTab_15637)->length;
    }
    else {
        _14274 = 1;
    }
    _2 = (object)SEQ_PTR(_block_25533);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _block_25533 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    *(intptr_t *)_2 = _14274;
    if( _1 != _14274 ){
    }
    _14274 = NOVALUE;

    /** block.e:107		block[BLOCK_OPCODE] = opcode*/
    _2 = (object)SEQ_PTR(_block_25533);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _block_25533 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    *(intptr_t *)_2 = _opcode_25514;

    /** block.e:108		block[BLOCK_LABEL]  = block_label*/
    Ref(_block_label_25515);
    _2 = (object)SEQ_PTR(_block_25533);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _block_25533 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3);
    *(intptr_t *)_2 = _block_label_25515;

    /** block.e:109		block[BLOCK_START]  = length(Code) + 1*/
    if (IS_SEQUENCE(_36Code_21859)){
            _14275 = SEQ_PTR(_36Code_21859)->length;
    }
    else {
        _14275 = 1;
    }
    _14276 = _14275 + 1;
    _14275 = NOVALUE;
    _2 = (object)SEQ_PTR(_block_25533);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _block_25533 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14276;
    if( _1 != _14276 ){
        DeRef(_1);
    }
    _14276 = NOVALUE;

    /** block.e:110		block[BLOCK_VARS]   = {}*/
    RefDS(_5);
    _2 = (object)SEQ_PTR(_block_25533);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _block_25533 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 6);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _5;
    DeRef(_1);

    /** block.e:112		block_stack = append( block_stack, block )*/
    RefDS(_block_25533);
    Append(&_65block_stack_25433, _65block_stack_25433, _block_25533);

    /** block.e:113		current_block = length(SymTab)*/
    if (IS_SEQUENCE(_37SymTab_15637)){
            _65current_block_25440 = SEQ_PTR(_37SymTab_15637)->length;
    }
    else {
        _65current_block_25440 = 1;
    }

    /** block.e:114	end procedure*/
    DeRefi(_block_label_25515);
    DeRefDS(_block_25533);
    return;
    ;
}


void _65Start_block(object _opcode_25546, object _block_label_25547)
{
    object _last_block_25549 = NOVALUE;
    object _label_name_25577 = NOVALUE;
    object _14298 = NOVALUE;
    object _14297 = NOVALUE;
    object _14296 = NOVALUE;
    object _14293 = NOVALUE;
    object _14292 = NOVALUE;
    object _14290 = NOVALUE;
    object _14289 = NOVALUE;
    object _14288 = NOVALUE;
    object _14287 = NOVALUE;
    object _14286 = NOVALUE;
    object _14283 = NOVALUE;
    object _14281 = NOVALUE;
    object _14280 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** block.e:120		symtab_index last_block = current_block*/
    _last_block_25549 = _65current_block_25440;

    /** block.e:121		if opcode = FUNC then*/
    if (_opcode_25546 != 501)
    goto L1; // [16] 30

    /** block.e:122			opcode = PROC*/
    _opcode_25546 = 27;
L1: 

    /** block.e:124		NewBlock( opcode, block_label )*/
    Ref(_block_label_25547);
    _65NewBlock(_opcode_25546, _block_label_25547);

    /** block.e:126		if find(opcode, RTN_TOKS) then*/
    _14280 = find_from(_opcode_25546, _38RTN_TOKS_16291, 1);
    if (_14280 == 0)
    {
        _14280 = NOVALUE;
        goto L2; // [45] 105
    }
    else{
        _14280 = NOVALUE;
    }

    /** block.e:127			SymTab[block_label][S_BLOCK] = current_block*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_block_label_25547))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_block_label_25547)->dbl));
    else
    _3 = (object)(_block_label_25547 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_BLOCK_21424))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_BLOCK_21424)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_BLOCK_21424);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _65current_block_25440;
    DeRef(_1);
    _14281 = NOVALUE;

    /** block.e:128			SymTab[current_block][S_NAME] = sprintf("BLOCK: %s", {SymTab[block_label][S_NAME]})*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_65current_block_25440 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!IS_ATOM_INT(_block_label_25547)){
        _14286 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_block_label_25547)->dbl));
    }
    else{
        _14286 = (object)*(((s1_ptr)_2)->base + _block_label_25547);
    }
    _2 = (object)SEQ_PTR(_14286);
    if (!IS_ATOM_INT(_36S_NAME_21404)){
        _14287 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21404)->dbl));
    }
    else{
        _14287 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21404);
    }
    _14286 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_14287);
    ((intptr_t*)_2)[1] = _14287;
    _14288 = MAKE_SEQ(_1);
    _14287 = NOVALUE;
    _14289 = EPrintf(-9999999, _14285, _14288);
    DeRefDS(_14288);
    _14288 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_NAME_21404))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21404)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_NAME_21404);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14289;
    if( _1 != _14289 ){
        DeRef(_1);
    }
    _14289 = NOVALUE;
    _14283 = NOVALUE;
    goto L3; // [102] 185
L2: 

    /** block.e:129		elsif current_block then*/
    if (_65current_block_25440 == 0)
    {
        goto L4; // [109] 182
    }
    else{
    }

    /** block.e:135			SymTab[current_block][S_BLOCK] = last_block*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_65current_block_25440 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_BLOCK_21424))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_BLOCK_21424)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_BLOCK_21424);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _last_block_25549;
    DeRef(_1);
    _14290 = NOVALUE;

    /** block.e:136			sequence label_name = ""*/
    RefDS(_5);
    DeRefi(_label_name_25577);
    _label_name_25577 = _5;

    /** block.e:137			if sequence(block_label) then*/
    _14292 = IS_SEQUENCE(_block_label_25547);
    if (_14292 == 0)
    {
        _14292 = NOVALUE;
        goto L5; // [141] 152
    }
    else{
        _14292 = NOVALUE;
    }

    /** block.e:138				label_name = block_label*/
    Ref(_block_label_25547);
    DeRefDSi(_label_name_25577);
    _label_name_25577 = _block_label_25547;
L5: 

    /** block.e:141			SymTab[current_block][S_NAME] = sprintf( "BLOCK: %s-%s", {block_type_name(opcode), label_name})*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_65current_block_25440 + ((s1_ptr)_2)->base);
    _14296 = _65block_type_name(_opcode_25546);
    RefDS(_label_name_25577);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _14296;
    ((intptr_t *)_2)[2] = _label_name_25577;
    _14297 = MAKE_SEQ(_1);
    _14296 = NOVALUE;
    _14298 = EPrintf(-9999999, _14295, _14297);
    DeRefDS(_14297);
    _14297 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_NAME_21404))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21404)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_NAME_21404);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14298;
    if( _1 != _14298 ){
        DeRef(_1);
    }
    _14298 = NOVALUE;
    _14293 = NOVALUE;
L4: 
    DeRefi(_label_name_25577);
    _label_name_25577 = NOVALUE;
L3: 

    /** block.e:144		ifdef BDEBUG then*/

    /** block.e:153	end procedure*/
    DeRefi(_block_label_25547);
    return;
    ;
}


void _65block_label(object _label_name_25593)
{
    object _14312 = NOVALUE;
    object _14311 = NOVALUE;
    object _14310 = NOVALUE;
    object _14309 = NOVALUE;
    object _14308 = NOVALUE;
    object _14307 = NOVALUE;
    object _14305 = NOVALUE;
    object _14303 = NOVALUE;
    object _14302 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** block.e:157		block_stack[$][BLOCK_LABEL] = label_name*/
    if (IS_SEQUENCE(_65block_stack_25433)){
            _14302 = SEQ_PTR(_65block_stack_25433)->length;
    }
    else {
        _14302 = 1;
    }
    _2 = (object)SEQ_PTR(_65block_stack_25433);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65block_stack_25433 = MAKE_SEQ(_2);
    }
    _3 = (object)(_14302 + ((s1_ptr)_2)->base);
    RefDS(_label_name_25593);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _label_name_25593;
    DeRef(_1);
    _14303 = NOVALUE;

    /** block.e:158		SymTab[current_block][S_NAME] = sprintf( "BLOCK: %s-%s", */
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_65current_block_25440 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_65block_stack_25433)){
            _14307 = SEQ_PTR(_65block_stack_25433)->length;
    }
    else {
        _14307 = 1;
    }
    _2 = (object)SEQ_PTR(_65block_stack_25433);
    _14308 = (object)*(((s1_ptr)_2)->base + _14307);
    _2 = (object)SEQ_PTR(_14308);
    _14309 = (object)*(((s1_ptr)_2)->base + 2);
    _14308 = NOVALUE;
    Ref(_14309);
    _14310 = _65block_type_name(_14309);
    _14309 = NOVALUE;
    RefDS(_label_name_25593);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _14310;
    ((intptr_t *)_2)[2] = _label_name_25593;
    _14311 = MAKE_SEQ(_1);
    _14310 = NOVALUE;
    _14312 = EPrintf(-9999999, _14295, _14311);
    DeRefDS(_14311);
    _14311 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_NAME_21404))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21404)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_NAME_21404);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14312;
    if( _1 != _14312 ){
        DeRef(_1);
    }
    _14312 = NOVALUE;
    _14305 = NOVALUE;

    /** block.e:160	end procedure*/
    DeRefDS(_label_name_25593);
    return;
    ;
}


object _65pop_block()
{
    object _block_25612 = NOVALUE;
    object _block_vars_25625 = NOVALUE;
    object _14341 = NOVALUE;
    object _14339 = NOVALUE;
    object _14338 = NOVALUE;
    object _14337 = NOVALUE;
    object _14336 = NOVALUE;
    object _14334 = NOVALUE;
    object _14333 = NOVALUE;
    object _14332 = NOVALUE;
    object _14331 = NOVALUE;
    object _14330 = NOVALUE;
    object _14329 = NOVALUE;
    object _14328 = NOVALUE;
    object _14327 = NOVALUE;
    object _14326 = NOVALUE;
    object _14325 = NOVALUE;
    object _14321 = NOVALUE;
    object _14320 = NOVALUE;
    object _14318 = NOVALUE;
    object _14317 = NOVALUE;
    object _14315 = NOVALUE;
    object _14313 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** block.e:164		if not length(block_stack) then*/
    if (IS_SEQUENCE(_65block_stack_25433)){
            _14313 = SEQ_PTR(_65block_stack_25433)->length;
    }
    else {
        _14313 = 1;
    }
    if (_14313 != 0)
    goto L1; // [8] 18
    _14313 = NOVALUE;

    /** block.e:165			return 0*/
    DeRef(_block_25612);
    DeRef(_block_vars_25625);
    return 0;
L1: 

    /** block.e:168		sequence  block = block_stack[$]*/
    if (IS_SEQUENCE(_65block_stack_25433)){
            _14315 = SEQ_PTR(_65block_stack_25433)->length;
    }
    else {
        _14315 = 1;
    }
    DeRef(_block_25612);
    _2 = (object)SEQ_PTR(_65block_stack_25433);
    _block_25612 = (object)*(((s1_ptr)_2)->base + _14315);
    Ref(_block_25612);

    /** block.e:169		block_stack = block_stack[1..$-1]*/
    if (IS_SEQUENCE(_65block_stack_25433)){
            _14317 = SEQ_PTR(_65block_stack_25433)->length;
    }
    else {
        _14317 = 1;
    }
    _14318 = _14317 - 1;
    _14317 = NOVALUE;
    rhs_slice_target = (object_ptr)&_65block_stack_25433;
    RHS_Slice(_65block_stack_25433, 1, _14318);

    /** block.e:170		SymTab[block[BLOCK_SYM]][S_LAST_LINE] = gline_number*/
    _2 = (object)SEQ_PTR(_block_25612);
    _14320 = (object)*(((s1_ptr)_2)->base + 1);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_14320))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_14320)->dbl));
    else
    _3 = (object)(_14320 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_LAST_LINE_21434))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_LAST_LINE_21434)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_LAST_LINE_21434);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36gline_number_21772;
    DeRef(_1);
    _14321 = NOVALUE;

    /** block.e:172		ifdef BDEBUG then*/

    /** block.e:177		sequence block_vars = block[BLOCK_VARS]*/
    DeRef(_block_vars_25625);
    _2 = (object)SEQ_PTR(_block_25612);
    _block_vars_25625 = (object)*(((s1_ptr)_2)->base + 6);
    Ref(_block_vars_25625);

    /** block.e:178		for sx = 1 to length( block_vars ) do*/
    if (IS_SEQUENCE(_block_vars_25625)){
            _14325 = SEQ_PTR(_block_vars_25625)->length;
    }
    else {
        _14325 = 1;
    }
    {
        object _sx_25628;
        _sx_25628 = 1;
L2: 
        if (_sx_25628 > _14325){
            goto L3; // [83] 172
        }

        /** block.e:180			if SymTab[block_vars[sx]][S_MODE] = M_NORMAL */
        _2 = (object)SEQ_PTR(_block_vars_25625);
        _14326 = (object)*(((s1_ptr)_2)->base + _sx_25628);
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        if (!IS_ATOM_INT(_14326)){
            _14327 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_14326)->dbl));
        }
        else{
            _14327 = (object)*(((s1_ptr)_2)->base + _14326);
        }
        _2 = (object)SEQ_PTR(_14327);
        _14328 = (object)*(((s1_ptr)_2)->base + 3);
        _14327 = NOVALUE;
        if (IS_ATOM_INT(_14328)) {
            _14329 = (_14328 == 1);
        }
        else {
            _14329 = binary_op(EQUALS, _14328, 1);
        }
        _14328 = NOVALUE;
        if (IS_ATOM_INT(_14329)) {
            if (_14329 == 0) {
                goto L4; // [114] 165
            }
        }
        else {
            if (DBL_PTR(_14329)->dbl == 0.0) {
                goto L4; // [114] 165
            }
        }
        _2 = (object)SEQ_PTR(_block_vars_25625);
        _14331 = (object)*(((s1_ptr)_2)->base + _sx_25628);
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        if (!IS_ATOM_INT(_14331)){
            _14332 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_14331)->dbl));
        }
        else{
            _14332 = (object)*(((s1_ptr)_2)->base + _14331);
        }
        _2 = (object)SEQ_PTR(_14332);
        _14333 = (object)*(((s1_ptr)_2)->base + 4);
        _14332 = NOVALUE;
        if (IS_ATOM_INT(_14333)) {
            _14334 = (_14333 <= 5);
        }
        else {
            _14334 = binary_op(LESSEQ, _14333, 5);
        }
        _14333 = NOVALUE;
        if (_14334 == 0) {
            DeRef(_14334);
            _14334 = NOVALUE;
            goto L4; // [141] 165
        }
        else {
            if (!IS_ATOM_INT(_14334) && DBL_PTR(_14334)->dbl == 0.0){
                DeRef(_14334);
                _14334 = NOVALUE;
                goto L4; // [141] 165
            }
            DeRef(_14334);
            _14334 = NOVALUE;
        }
        DeRef(_14334);
        _14334 = NOVALUE;

        /** block.e:182				ifdef BDEBUG then*/

        /** block.e:187				Hide( block_vars[sx] )*/
        _2 = (object)SEQ_PTR(_block_vars_25625);
        _14336 = (object)*(((s1_ptr)_2)->base + _sx_25628);
        Ref(_14336);
        _54Hide(_14336);
        _14336 = NOVALUE;

        /** block.e:188				LintCheck( block_vars[sx] )*/
        _2 = (object)SEQ_PTR(_block_vars_25625);
        _14337 = (object)*(((s1_ptr)_2)->base + _sx_25628);
        Ref(_14337);
        _54LintCheck(_14337);
        _14337 = NOVALUE;
L4: 

        /** block.e:191		end for*/
        _sx_25628 = _sx_25628 + 1;
        goto L2; // [167] 90
L3: 
        ;
    }

    /** block.e:213		current_block = block_stack[$][BLOCK_SYM]*/
    if (IS_SEQUENCE(_65block_stack_25433)){
            _14338 = SEQ_PTR(_65block_stack_25433)->length;
    }
    else {
        _14338 = 1;
    }
    _2 = (object)SEQ_PTR(_65block_stack_25433);
    _14339 = (object)*(((s1_ptr)_2)->base + _14338);
    _2 = (object)SEQ_PTR(_14339);
    _65current_block_25440 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_65current_block_25440)){
        _65current_block_25440 = (object)DBL_PTR(_65current_block_25440)->dbl;
    }
    _14339 = NOVALUE;

    /** block.e:214		return block[BLOCK_SYM]*/
    _2 = (object)SEQ_PTR(_block_25612);
    _14341 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_14341);
    DeRefDS(_block_25612);
    DeRef(_block_vars_25625);
    DeRef(_14329);
    _14329 = NOVALUE;
    _14320 = NOVALUE;
    DeRef(_14318);
    _14318 = NOVALUE;
    _14326 = NOVALUE;
    _14331 = NOVALUE;
    return _14341;
    ;
}


object _65top_block(object _offset_25657)
{
    object _14349 = NOVALUE;
    object _14348 = NOVALUE;
    object _14347 = NOVALUE;
    object _14346 = NOVALUE;
    object _14345 = NOVALUE;
    object _14344 = NOVALUE;
    object _14342 = NOVALUE;
    object _0, _1, _2;
    

    /** block.e:219		if offset >= length(block_stack) then*/
    if (IS_SEQUENCE(_65block_stack_25433)){
            _14342 = SEQ_PTR(_65block_stack_25433)->length;
    }
    else {
        _14342 = 1;
    }
    if (_offset_25657 < _14342)
    goto L1; // [10] 35

    /** block.e:220			CompileErr(LEAVING_TOO_MANY_BLOCKS_1__2, {offset,length(block_stack)})*/
    if (IS_SEQUENCE(_65block_stack_25433)){
            _14344 = SEQ_PTR(_65block_stack_25433)->length;
    }
    else {
        _14344 = 1;
    }
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _offset_25657;
    ((intptr_t *)_2)[2] = _14344;
    _14345 = MAKE_SEQ(_1);
    _14344 = NOVALUE;
    _50CompileErr(107, _14345, 0);
    _14345 = NOVALUE;
    goto L2; // [32] 59
L1: 

    /** block.e:222			return block_stack[$-offset][BLOCK_SYM]*/
    if (IS_SEQUENCE(_65block_stack_25433)){
            _14346 = SEQ_PTR(_65block_stack_25433)->length;
    }
    else {
        _14346 = 1;
    }
    _14347 = _14346 - _offset_25657;
    _14346 = NOVALUE;
    _2 = (object)SEQ_PTR(_65block_stack_25433);
    _14348 = (object)*(((s1_ptr)_2)->base + _14347);
    _2 = (object)SEQ_PTR(_14348);
    _14349 = (object)*(((s1_ptr)_2)->base + 1);
    _14348 = NOVALUE;
    Ref(_14349);
    _14347 = NOVALUE;
    return _14349;
L2: 
    ;
}


void _65End_block(object _opcode_25672)
{
    object _ix_25683 = NOVALUE;
    object _14357 = NOVALUE;
    object _14354 = NOVALUE;
    object _14353 = NOVALUE;
    object _14352 = NOVALUE;
    object _14351 = NOVALUE;
    object _0, _1, _2;
    

    /** block.e:229		if opcode = FUNC then*/

    /** block.e:232		check_block( opcode )*/
    _65check_block(_opcode_25672);

    /** block.e:233		if not length(block_stack[$][BLOCK_VARS]) then*/
    if (IS_SEQUENCE(_65block_stack_25433)){
            _14351 = SEQ_PTR(_65block_stack_25433)->length;
    }
    else {
        _14351 = 1;
    }
    _2 = (object)SEQ_PTR(_65block_stack_25433);
    _14352 = (object)*(((s1_ptr)_2)->base + _14351);
    _2 = (object)SEQ_PTR(_14352);
    _14353 = (object)*(((s1_ptr)_2)->base + 6);
    _14352 = NOVALUE;
    if (IS_SEQUENCE(_14353)){
            _14354 = SEQ_PTR(_14353)->length;
    }
    else {
        _14354 = 1;
    }
    _14353 = NOVALUE;
    if (_14354 != 0)
    goto L1; // [44] 64
    _14354 = NOVALUE;

    /** block.e:234			integer ix = 1*/
    _ix_25683 = 1;

    /** block.e:235			ix = pop_block()*/
    _ix_25683 = _65pop_block();
    if (!IS_ATOM_INT(_ix_25683)) {
        _1 = (object)(DBL_PTR(_ix_25683)->dbl);
        DeRefDS(_ix_25683);
        _ix_25683 = _1;
    }
    goto L2; // [61] 80
L1: 

    /** block.e:237			Push( pop_block() )*/
    _14357 = _65pop_block();
    _47Push(_14357);
    _14357 = NOVALUE;

    /** block.e:238			emit_op( EXIT_BLOCK )*/
    _47emit_op(206);
L2: 

    /** block.e:241	end procedure*/
    _14353 = NOVALUE;
    return;
    ;
}


object _65End_inline_block(object _opcode_25692)
{
    object _14364 = NOVALUE;
    object _14363 = NOVALUE;
    object _14362 = NOVALUE;
    object _14361 = NOVALUE;
    object _14360 = NOVALUE;
    object _14359 = NOVALUE;
    object _0, _1, _2;
    

    /** block.e:246		if opcode = FUNC then*/

    /** block.e:249		if length(block_stack[$][BLOCK_VARS]) then*/
    if (IS_SEQUENCE(_65block_stack_25433)){
            _14359 = SEQ_PTR(_65block_stack_25433)->length;
    }
    else {
        _14359 = 1;
    }
    _2 = (object)SEQ_PTR(_65block_stack_25433);
    _14360 = (object)*(((s1_ptr)_2)->base + _14359);
    _2 = (object)SEQ_PTR(_14360);
    _14361 = (object)*(((s1_ptr)_2)->base + 6);
    _14360 = NOVALUE;
    if (IS_SEQUENCE(_14361)){
            _14362 = SEQ_PTR(_14361)->length;
    }
    else {
        _14362 = 1;
    }
    _14361 = NOVALUE;
    if (_14362 == 0)
    {
        _14362 = NOVALUE;
        goto L1; // [39] 60
    }
    else{
        _14362 = NOVALUE;
    }

    /** block.e:250			return { EXIT_BLOCK, pop_block() }*/
    _14363 = _65pop_block();
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 206;
    ((intptr_t *)_2)[2] = _14363;
    _14364 = MAKE_SEQ(_1);
    _14363 = NOVALUE;
    _14361 = NOVALUE;
    return _14364;
    goto L2; // [57] 72
L1: 

    /** block.e:252			Drop_block( opcode )*/
    _65Drop_block(_opcode_25692);

    /** block.e:253			return {}*/
    RefDS(_5);
    _14361 = NOVALUE;
    DeRef(_14364);
    _14364 = NOVALUE;
    return _5;
L2: 
    ;
}


void _65Sibling_block(object _opcode_25709)
{
    object _0, _1, _2;
    

    /** block.e:261		End_block( opcode )*/
    _65End_block(_opcode_25709);

    /** block.e:262		Start_block( opcode )*/
    _65Start_block(_opcode_25709, 0);

    /** block.e:263	end procedure*/
    return;
    ;
}


void _65Leave_block(object _offset_25712)
{
    object _14370 = NOVALUE;
    object _14369 = NOVALUE;
    object _14368 = NOVALUE;
    object _14367 = NOVALUE;
    object _14366 = NOVALUE;
    object _14365 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_offset_25712)) {
        _1 = (object)(DBL_PTR(_offset_25712)->dbl);
        DeRefDS(_offset_25712);
        _offset_25712 = _1;
    }

    /** block.e:268		if length( block_stack[$-offset][BLOCK_VARS]) then*/
    if (IS_SEQUENCE(_65block_stack_25433)){
            _14365 = SEQ_PTR(_65block_stack_25433)->length;
    }
    else {
        _14365 = 1;
    }
    _14366 = _14365 - _offset_25712;
    _14365 = NOVALUE;
    _2 = (object)SEQ_PTR(_65block_stack_25433);
    _14367 = (object)*(((s1_ptr)_2)->base + _14366);
    _2 = (object)SEQ_PTR(_14367);
    _14368 = (object)*(((s1_ptr)_2)->base + 6);
    _14367 = NOVALUE;
    if (IS_SEQUENCE(_14368)){
            _14369 = SEQ_PTR(_14368)->length;
    }
    else {
        _14369 = 1;
    }
    _14368 = NOVALUE;
    if (_14369 == 0)
    {
        _14369 = NOVALUE;
        goto L1; // [25] 45
    }
    else{
        _14369 = NOVALUE;
    }

    /** block.e:269			Push( top_block( offset ) )*/
    _14370 = _65top_block(_offset_25712);
    _47Push(_14370);
    _14370 = NOVALUE;

    /** block.e:270			emit_op( EXIT_BLOCK )*/
    _47emit_op(206);
L1: 

    /** block.e:272	end procedure*/
    _14368 = NOVALUE;
    DeRef(_14366);
    _14366 = NOVALUE;
    return;
    ;
}


void _65Leave_blocks(object _blocks_25732, object _block_type_25733)
{
    object _bx_25734 = NOVALUE;
    object _Block_opcode_3__tmp_at29_25741 = NOVALUE;
    object _Block_opcode_2__tmp_at29_25740 = NOVALUE;
    object _Block_opcode_1__tmp_at29_25739 = NOVALUE;
    object _Block_opcode_inlined_Block_opcode_at_29_25738 = NOVALUE;
    object _14383 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_blocks_25732)) {
        _1 = (object)(DBL_PTR(_blocks_25732)->dbl);
        DeRefDS(_blocks_25732);
        _blocks_25732 = _1;
    }

    /** block.e:284		integer bx = 0*/
    _bx_25734 = 0;

    /** block.e:285		while blocks do*/
L1: 
    if (_blocks_25732 == 0)
    {
        goto L2; // [15] 119
    }
    else{
    }

    /** block.e:286			Leave_block( bx )*/
    _65Leave_block(_bx_25734);

    /** block.e:288			if block_type then*/
    if (_block_type_25733 == 0)
    {
        goto L3; // [25] 101
    }
    else{
    }

    /** block.e:289				switch Block_opcode( bx ) do*/

    /** block.e:276		return block_stack[$-bx][BLOCK_OPCODE]*/
    if (IS_SEQUENCE(_65block_stack_25433)){
            _Block_opcode_1__tmp_at29_25739 = SEQ_PTR(_65block_stack_25433)->length;
    }
    else {
        _Block_opcode_1__tmp_at29_25739 = 1;
    }
    _Block_opcode_2__tmp_at29_25740 = _Block_opcode_1__tmp_at29_25739 - _bx_25734;
    DeRef(_Block_opcode_3__tmp_at29_25741);
    _2 = (object)SEQ_PTR(_65block_stack_25433);
    _Block_opcode_3__tmp_at29_25741 = (object)*(((s1_ptr)_2)->base + _Block_opcode_2__tmp_at29_25740);
    Ref(_Block_opcode_3__tmp_at29_25741);
    DeRef(_Block_opcode_inlined_Block_opcode_at_29_25738);
    _2 = (object)SEQ_PTR(_Block_opcode_3__tmp_at29_25741);
    _Block_opcode_inlined_Block_opcode_at_29_25738 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_Block_opcode_inlined_Block_opcode_at_29_25738);
    DeRef(_Block_opcode_3__tmp_at29_25741);
    _Block_opcode_3__tmp_at29_25741 = NOVALUE;
    if (IS_SEQUENCE(_Block_opcode_inlined_Block_opcode_at_29_25738) ){
        goto L4; // [52] 82
    }
    if(!IS_ATOM_INT(_Block_opcode_inlined_Block_opcode_at_29_25738)){
        if( (DBL_PTR(_Block_opcode_inlined_Block_opcode_at_29_25738)->dbl != (eudouble) ((object) DBL_PTR(_Block_opcode_inlined_Block_opcode_at_29_25738)->dbl) ) ){
            goto L4; // [52] 82
        }
        _0 = (object) DBL_PTR(_Block_opcode_inlined_Block_opcode_at_29_25738)->dbl;
    }
    else {
        _0 = _Block_opcode_inlined_Block_opcode_at_29_25738;
    };
    switch ( _0 ){ 

        /** block.e:290					case FOR, WHILE, LOOP then*/
        case 21:
        case 47:
        case 422:

        /** block.e:291						if block_type = LOOP_BLOCK then*/
        if (_block_type_25733 != 1)
        goto L5; // [67] 108

        /** block.e:292							blocks -= 1*/
        _blocks_25732 = _blocks_25732 - 1;
        goto L5; // [78] 108

        /** block.e:294					case else*/
        default:
L4: 

        /** block.e:295						if block_type = CONDITIONAL_BLOCK then*/
        if (_block_type_25733 != 2)
        goto L6; // [86] 97

        /** block.e:296							blocks -= 1*/
        _blocks_25732 = _blocks_25732 - 1;
L6: 
    ;}    goto L5; // [98] 108
L3: 

    /** block.e:300				blocks -= 1*/
    _blocks_25732 = _blocks_25732 - 1;
L5: 

    /** block.e:302			bx += 1*/
    _bx_25734 = _bx_25734 + 1;

    /** block.e:303		end while*/
    goto L1; // [116] 15
L2: 

    /** block.e:304		for i = 0 to blocks - 1 do*/
    _14383 = _blocks_25732 - 1;
    if ((object)((uintptr_t)_14383 +(uintptr_t) HIGH_BITS) >= 0){
        _14383 = NewDouble((eudouble)_14383);
    }
    {
        object _i_25759;
        _i_25759 = 0;
L7: 
        if (binary_op_a(GREATER, _i_25759, _14383)){
            goto L8; // [125] 144
        }

        /** block.e:305			Leave_block( i )*/
        Ref(_i_25759);
        _65Leave_block(_i_25759);

        /** block.e:306		end for*/
        _0 = _i_25759;
        if (IS_ATOM_INT(_i_25759)) {
            _i_25759 = _i_25759 + 1;
            if ((object)((uintptr_t)_i_25759 +(uintptr_t) HIGH_BITS) >= 0){
                _i_25759 = NewDouble((eudouble)_i_25759);
            }
        }
        else {
            _i_25759 = binary_op_a(PLUS, _i_25759, 1);
        }
        DeRef(_0);
        goto L7; // [139] 132
L8: 
        ;
        DeRef(_i_25759);
    }

    /** block.e:307	end procedure*/
    DeRef(_14383);
    _14383 = NOVALUE;
    return;
    ;
}


void _65Drop_block(object _opcode_25763)
{
    object _x_25765 = NOVALUE;
    object _0, _1, _2;
    

    /** block.e:311		check_block( opcode )*/
    _65check_block(_opcode_25763);

    /** block.e:312		symtab_index x = pop_block()*/
    _x_25765 = _65pop_block();
    if (!IS_ATOM_INT(_x_25765)) {
        _1 = (object)(DBL_PTR(_x_25765)->dbl);
        DeRefDS(_x_25765);
        _x_25765 = _1;
    }

    /** block.e:313	end procedure*/
    return;
    ;
}


void _65Pop_block_var()
{
    object _sym_25770 = NOVALUE;
    object _block_sym_25777 = NOVALUE;
    object _14411 = NOVALUE;
    object _14410 = NOVALUE;
    object _14409 = NOVALUE;
    object _14408 = NOVALUE;
    object _14407 = NOVALUE;
    object _14406 = NOVALUE;
    object _14405 = NOVALUE;
    object _14404 = NOVALUE;
    object _14402 = NOVALUE;
    object _14401 = NOVALUE;
    object _14399 = NOVALUE;
    object _14398 = NOVALUE;
    object _14396 = NOVALUE;
    object _14393 = NOVALUE;
    object _14391 = NOVALUE;
    object _14390 = NOVALUE;
    object _14388 = NOVALUE;
    object _14387 = NOVALUE;
    object _14386 = NOVALUE;
    object _14385 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** block.e:316		symtab_index sym = block_stack[$][BLOCK_VARS][$]*/
    if (IS_SEQUENCE(_65block_stack_25433)){
            _14385 = SEQ_PTR(_65block_stack_25433)->length;
    }
    else {
        _14385 = 1;
    }
    _2 = (object)SEQ_PTR(_65block_stack_25433);
    _14386 = (object)*(((s1_ptr)_2)->base + _14385);
    _2 = (object)SEQ_PTR(_14386);
    _14387 = (object)*(((s1_ptr)_2)->base + 6);
    _14386 = NOVALUE;
    if (IS_SEQUENCE(_14387)){
            _14388 = SEQ_PTR(_14387)->length;
    }
    else {
        _14388 = 1;
    }
    _2 = (object)SEQ_PTR(_14387);
    _sym_25770 = (object)*(((s1_ptr)_2)->base + _14388);
    if (!IS_ATOM_INT(_sym_25770)){
        _sym_25770 = (object)DBL_PTR(_sym_25770)->dbl;
    }
    _14387 = NOVALUE;

    /** block.e:317		symtab_index block_sym = block_stack[$][BLOCK_SYM]*/
    if (IS_SEQUENCE(_65block_stack_25433)){
            _14390 = SEQ_PTR(_65block_stack_25433)->length;
    }
    else {
        _14390 = 1;
    }
    _2 = (object)SEQ_PTR(_65block_stack_25433);
    _14391 = (object)*(((s1_ptr)_2)->base + _14390);
    _2 = (object)SEQ_PTR(_14391);
    _block_sym_25777 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_block_sym_25777)){
        _block_sym_25777 = (object)DBL_PTR(_block_sym_25777)->dbl;
    }
    _14391 = NOVALUE;

    /** block.e:318		while sym_next_in_block( block_sym ) != sym do*/
L1: 
    _14393 = _54sym_next_in_block(_block_sym_25777);
    if (binary_op_a(EQUALS, _14393, _sym_25770)){
        DeRef(_14393);
        _14393 = NOVALUE;
        goto L2; // [51] 68
    }
    DeRef(_14393);
    _14393 = NOVALUE;

    /** block.e:319			block_sym = sym_next_in_block( block_sym )*/
    _block_sym_25777 = _54sym_next_in_block(_block_sym_25777);
    if (!IS_ATOM_INT(_block_sym_25777)) {
        _1 = (object)(DBL_PTR(_block_sym_25777)->dbl);
        DeRefDS(_block_sym_25777);
        _block_sym_25777 = _1;
    }

    /** block.e:320		end while*/
    goto L1; // [65] 47
L2: 

    /** block.e:322		SymTab[block_sym][S_NEXT_IN_BLOCK] = sym_next_in_block( sym )*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_block_sym_25777 + ((s1_ptr)_2)->base);
    _14398 = _54sym_next_in_block(_sym_25770);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_NEXT_IN_BLOCK_21396))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NEXT_IN_BLOCK_21396)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_NEXT_IN_BLOCK_21396);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14398;
    if( _1 != _14398 ){
        DeRef(_1);
    }
    _14398 = NOVALUE;
    _14396 = NOVALUE;

    /** block.e:323		SymTab[sym][S_NEXT_IN_BLOCK] = 0*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_25770 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_NEXT_IN_BLOCK_21396))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NEXT_IN_BLOCK_21396)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_NEXT_IN_BLOCK_21396);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);
    _14399 = NOVALUE;

    /** block.e:325		block_stack[$][BLOCK_VARS] = eu:remove( block_stack[$][BLOCK_VARS], */
    if (IS_SEQUENCE(_65block_stack_25433)){
            _14401 = SEQ_PTR(_65block_stack_25433)->length;
    }
    else {
        _14401 = 1;
    }
    _2 = (object)SEQ_PTR(_65block_stack_25433);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65block_stack_25433 = MAKE_SEQ(_2);
    }
    _3 = (object)(_14401 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_65block_stack_25433)){
            _14404 = SEQ_PTR(_65block_stack_25433)->length;
    }
    else {
        _14404 = 1;
    }
    _2 = (object)SEQ_PTR(_65block_stack_25433);
    _14405 = (object)*(((s1_ptr)_2)->base + _14404);
    _2 = (object)SEQ_PTR(_14405);
    _14406 = (object)*(((s1_ptr)_2)->base + 6);
    _14405 = NOVALUE;
    if (IS_SEQUENCE(_65block_stack_25433)){
            _14407 = SEQ_PTR(_65block_stack_25433)->length;
    }
    else {
        _14407 = 1;
    }
    _2 = (object)SEQ_PTR(_65block_stack_25433);
    _14408 = (object)*(((s1_ptr)_2)->base + _14407);
    _2 = (object)SEQ_PTR(_14408);
    _14409 = (object)*(((s1_ptr)_2)->base + 6);
    _14408 = NOVALUE;
    if (IS_SEQUENCE(_14409)){
            _14410 = SEQ_PTR(_14409)->length;
    }
    else {
        _14410 = 1;
    }
    _14409 = NOVALUE;
    {
        s1_ptr assign_space = SEQ_PTR(_14406);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_14410)) ? _14410 : (object)(DBL_PTR(_14410)->dbl);
        int stop = (IS_ATOM_INT(_14410)) ? _14410 : (object)(DBL_PTR(_14410)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
            RefDS(_14406);
            DeRef(_14411);
            _14411 = _14406;
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_14406), start, &_14411 );
            }
            else Tail(SEQ_PTR(_14406), stop+1, &_14411);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_14406), start, &_14411);
        }
        else {
            assign_slice_seq = &assign_space;
            _1 = Remove_elements(start, stop, 0);
            DeRef(_14411);
            _14411 = _1;
        }
    }
    _14406 = NOVALUE;
    _14410 = NOVALUE;
    _14410 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 6);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14411;
    if( _1 != _14411 ){
        DeRef(_1);
    }
    _14411 = NOVALUE;
    _14402 = NOVALUE;

    /** block.e:327	end procedure*/
    _14409 = NOVALUE;
    return;
    ;
}


void _65Goto_block(object _from_block_25811, object _to_block_25813, object _pc_25814)
{
    object _code_25815 = NOVALUE;
    object _next_block_25817 = NOVALUE;
    object _14422 = NOVALUE;
    object _14419 = NOVALUE;
    object _14418 = NOVALUE;
    object _14417 = NOVALUE;
    object _14416 = NOVALUE;
    object _14415 = NOVALUE;
    object _14414 = NOVALUE;
    object _14413 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_from_block_25811)) {
        _1 = (object)(DBL_PTR(_from_block_25811)->dbl);
        DeRefDS(_from_block_25811);
        _from_block_25811 = _1;
    }
    if (!IS_ATOM_INT(_to_block_25813)) {
        _1 = (object)(DBL_PTR(_to_block_25813)->dbl);
        DeRefDS(_to_block_25813);
        _to_block_25813 = _1;
    }
    if (!IS_ATOM_INT(_pc_25814)) {
        _1 = (object)(DBL_PTR(_pc_25814)->dbl);
        DeRefDS(_pc_25814);
        _pc_25814 = _1;
    }

    /** block.e:330		sequence code = {}*/
    RefDS(_5);
    DeRefi(_code_25815);
    _code_25815 = _5;

    /** block.e:331		symtab_index next_block = sym_block( from_block )*/
    _next_block_25817 = _54sym_block(_from_block_25811);
    if (!IS_ATOM_INT(_next_block_25817)) {
        _1 = (object)(DBL_PTR(_next_block_25817)->dbl);
        DeRefDS(_next_block_25817);
        _next_block_25817 = _1;
    }

    /** block.e:332		while next_block */
L1: 
    if (_next_block_25817 == 0) {
        _14413 = 0;
        goto L2; // [27] 39
    }
    _14414 = (_from_block_25811 != _to_block_25813);
    _14413 = (_14414 != 0);
L2: 
    if (_14413 == 0) {
        goto L3; // [39] 93
    }
    _14416 = _54sym_token(_next_block_25817);
    _14417 = find_from(_14416, _38RTN_TOKS_16291, 1);
    DeRef(_14416);
    _14416 = NOVALUE;
    _14418 = (_14417 == 0);
    _14417 = NOVALUE;
    if (_14418 == 0)
    {
        DeRef(_14418);
        _14418 = NOVALUE;
        goto L3; // [58] 93
    }
    else{
        DeRef(_14418);
        _14418 = NOVALUE;
    }

    /** block.e:335			code &= { EXIT_BLOCK, from_block }*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 206;
    ((intptr_t *)_2)[2] = _from_block_25811;
    _14419 = MAKE_SEQ(_1);
    Concat((object_ptr)&_code_25815, _code_25815, _14419);
    DeRefDS(_14419);
    _14419 = NOVALUE;

    /** block.e:336			from_block = next_block*/
    _from_block_25811 = _next_block_25817;

    /** block.e:337			next_block = sym_block( next_block )*/
    _next_block_25817 = _54sym_block(_next_block_25817);
    if (!IS_ATOM_INT(_next_block_25817)) {
        _1 = (object)(DBL_PTR(_next_block_25817)->dbl);
        DeRefDS(_next_block_25817);
        _next_block_25817 = _1;
    }

    /** block.e:338		end while*/
    goto L1; // [90] 27
L3: 

    /** block.e:340		if length(code) then*/
    if (IS_SEQUENCE(_code_25815)){
            _14422 = SEQ_PTR(_code_25815)->length;
    }
    else {
        _14422 = 1;
    }
    if (_14422 == 0)
    {
        _14422 = NOVALUE;
        goto L4; // [98] 127
    }
    else{
        _14422 = NOVALUE;
    }

    /** block.e:341			if pc then*/
    if (_pc_25814 == 0)
    {
        goto L5; // [103] 115
    }
    else{
    }

    /** block.e:342				insert_code( code, pc )*/
    RefDS(_code_25815);
    _66insert_code(_code_25815, _pc_25814);
    goto L6; // [112] 126
L5: 

    /** block.e:344				Code &= code*/
    Concat((object_ptr)&_36Code_21859, _36Code_21859, _code_25815);
L6: 
L4: 

    /** block.e:348	end procedure*/
    DeRefi(_code_25815);
    DeRef(_14414);
    _14414 = NOVALUE;
    return;
    ;
}


object _65Least_block()
{
    object _ix_25845 = NOVALUE;
    object _sub_block_25848 = NOVALUE;
    object _14436 = NOVALUE;
    object _14435 = NOVALUE;
    object _14433 = NOVALUE;
    object _14432 = NOVALUE;
    object _14431 = NOVALUE;
    object _14430 = NOVALUE;
    object _14429 = NOVALUE;
    object _14428 = NOVALUE;
    object _14427 = NOVALUE;
    object _14426 = NOVALUE;
    object _0, _1, _2;
    

    /** block.e:358		integer ix = length( block_stack )*/
    if (IS_SEQUENCE(_65block_stack_25433)){
            _ix_25845 = SEQ_PTR(_65block_stack_25433)->length;
    }
    else {
        _ix_25845 = 1;
    }

    /** block.e:359		symtab_index sub_block = sym_block( CurrentSub )*/
    _sub_block_25848 = _54sym_block(_36CurrentSub_21775);
    if (!IS_ATOM_INT(_sub_block_25848)) {
        _1 = (object)(DBL_PTR(_sub_block_25848)->dbl);
        DeRefDS(_sub_block_25848);
        _sub_block_25848 = _1;
    }

    /** block.e:360		while not length( block_stack[ix][BLOCK_VARS] ) */
L1: 
    _2 = (object)SEQ_PTR(_65block_stack_25433);
    _14426 = (object)*(((s1_ptr)_2)->base + _ix_25845);
    _2 = (object)SEQ_PTR(_14426);
    _14427 = (object)*(((s1_ptr)_2)->base + 6);
    _14426 = NOVALUE;
    if (IS_SEQUENCE(_14427)){
            _14428 = SEQ_PTR(_14427)->length;
    }
    else {
        _14428 = 1;
    }
    _14427 = NOVALUE;
    _14429 = (_14428 == 0);
    _14428 = NOVALUE;
    if (_14429 == 0) {
        goto L2; // [39] 72
    }
    _2 = (object)SEQ_PTR(_65block_stack_25433);
    _14431 = (object)*(((s1_ptr)_2)->base + _ix_25845);
    _2 = (object)SEQ_PTR(_14431);
    _14432 = (object)*(((s1_ptr)_2)->base + 1);
    _14431 = NOVALUE;
    if (IS_ATOM_INT(_14432)) {
        _14433 = (_14432 != _sub_block_25848);
    }
    else {
        _14433 = binary_op(NOTEQ, _14432, _sub_block_25848);
    }
    _14432 = NOVALUE;
    if (_14433 <= 0) {
        if (_14433 == 0) {
            DeRef(_14433);
            _14433 = NOVALUE;
            goto L2; // [58] 72
        }
        else {
            if (!IS_ATOM_INT(_14433) && DBL_PTR(_14433)->dbl == 0.0){
                DeRef(_14433);
                _14433 = NOVALUE;
                goto L2; // [58] 72
            }
            DeRef(_14433);
            _14433 = NOVALUE;
        }
    }
    DeRef(_14433);
    _14433 = NOVALUE;

    /** block.e:362			ix -= 1	*/
    _ix_25845 = _ix_25845 - 1;

    /** block.e:363		end while*/
    goto L1; // [69] 23
L2: 

    /** block.e:364		return block_stack[ix][BLOCK_SYM]*/
    _2 = (object)SEQ_PTR(_65block_stack_25433);
    _14435 = (object)*(((s1_ptr)_2)->base + _ix_25845);
    _2 = (object)SEQ_PTR(_14435);
    _14436 = (object)*(((s1_ptr)_2)->base + 1);
    _14435 = NOVALUE;
    Ref(_14436);
    _14427 = NOVALUE;
    DeRef(_14429);
    _14429 = NOVALUE;
    return _14436;
    ;
}



// 0x867F3509
