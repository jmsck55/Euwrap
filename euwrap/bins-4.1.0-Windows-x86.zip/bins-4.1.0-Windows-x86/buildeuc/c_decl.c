// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _58get_eucompiledir()
{
    object _x_42911 = NOVALUE;
    object _22557 = NOVALUE;
    object _22553 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:133		object x = getenv("EUCOMPILEDIR")*/
    DeRef(_x_42911);
    _x_42911 = EGetEnv(_22551);

    /** c_decl.e:134		if is_eudir_from_cmdline() then*/
    _22553 = _37is_eudir_from_cmdline();
    if (_22553 == 0) {
        DeRef(_22553);
        _22553 = NOVALUE;
        goto L1; // [11] 20
    }
    else {
        if (!IS_ATOM_INT(_22553) && DBL_PTR(_22553)->dbl == 0.0){
            DeRef(_22553);
            _22553 = NOVALUE;
            goto L1; // [11] 20
        }
        DeRef(_22553);
        _22553 = NOVALUE;
    }
    DeRef(_22553);
    _22553 = NOVALUE;

    /** c_decl.e:135			x = get_eudir()*/
    _0 = _x_42911;
    _x_42911 = _37get_eudir();
    DeRefi(_0);
L1: 

    /** c_decl.e:138		ifdef UNIX then*/

    /** c_decl.e:152		if equal(x, -1) then*/
    if (_x_42911 == -1)
    _22557 = 1;
    else if (IS_ATOM_INT(_x_42911) && IS_ATOM_INT(-1))
    _22557 = 0;
    else
    _22557 = (compare(_x_42911, -1) == 0);
    if (_22557 == 0)
    {
        _22557 = NOVALUE;
        goto L2; // [28] 37
    }
    else{
        _22557 = NOVALUE;
    }

    /** c_decl.e:153			x = get_eudir()*/
    _0 = _x_42911;
    _x_42911 = _37get_eudir();
    DeRef(_0);
L2: 

    /** c_decl.e:156		return x*/
    return _x_42911;
    ;
}


void _58NewBB(object _a_call_42927, object _mask_42928, object _sub_42930)
{
    object _s_42932 = NOVALUE;
    object _22590 = NOVALUE;
    object _22589 = NOVALUE;
    object _22587 = NOVALUE;
    object _22586 = NOVALUE;
    object _22584 = NOVALUE;
    object _22583 = NOVALUE;
    object _22582 = NOVALUE;
    object _22581 = NOVALUE;
    object _22580 = NOVALUE;
    object _22579 = NOVALUE;
    object _22578 = NOVALUE;
    object _22577 = NOVALUE;
    object _22576 = NOVALUE;
    object _22575 = NOVALUE;
    object _22574 = NOVALUE;
    object _22573 = NOVALUE;
    object _22572 = NOVALUE;
    object _22571 = NOVALUE;
    object _22570 = NOVALUE;
    object _22569 = NOVALUE;
    object _22568 = NOVALUE;
    object _22567 = NOVALUE;
    object _22566 = NOVALUE;
    object _22565 = NOVALUE;
    object _22564 = NOVALUE;
    object _22563 = NOVALUE;
    object _22562 = NOVALUE;
    object _22560 = NOVALUE;
    object _22559 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_mask_42928)) {
        _1 = (object)(DBL_PTR(_mask_42928)->dbl);
        DeRefDS(_mask_42928);
        _mask_42928 = _1;
    }

    /** c_decl.e:166		if a_call then*/
    if (_a_call_42927 == 0)
    {
        goto L1; // [9] 252
    }
    else{
    }

    /** c_decl.e:169			for i = 1 to length(BB_info) do*/
    if (IS_SEQUENCE(_58BB_info_42889)){
            _22559 = SEQ_PTR(_58BB_info_42889)->length;
    }
    else {
        _22559 = 1;
    }
    {
        object _i_42935;
        _i_42935 = 1;
L2: 
        if (_i_42935 > _22559){
            goto L3; // [19] 249
        }

        /** c_decl.e:170				s = BB_info[i][BB_VAR]*/
        _2 = (object)SEQ_PTR(_58BB_info_42889);
        _22560 = (object)*(((s1_ptr)_2)->base + _i_42935);
        _2 = (object)SEQ_PTR(_22560);
        _s_42932 = (object)*(((s1_ptr)_2)->base + 1);
        if (!IS_ATOM_INT(_s_42932)){
            _s_42932 = (object)DBL_PTR(_s_42932)->dbl;
        }
        _22560 = NOVALUE;

        /** c_decl.e:171				if SymTab[s][S_MODE] = M_NORMAL and*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _22562 = (object)*(((s1_ptr)_2)->base + _s_42932);
        _2 = (object)SEQ_PTR(_22562);
        _22563 = (object)*(((s1_ptr)_2)->base + 3);
        _22562 = NOVALUE;
        if (IS_ATOM_INT(_22563)) {
            _22564 = (_22563 == 1);
        }
        else {
            _22564 = binary_op(EQUALS, _22563, 1);
        }
        _22563 = NOVALUE;
        if (IS_ATOM_INT(_22564)) {
            if (_22564 == 0) {
                goto L4; // [60] 242
            }
        }
        else {
            if (DBL_PTR(_22564)->dbl == 0.0) {
                goto L4; // [60] 242
            }
        }
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _22566 = (object)*(((s1_ptr)_2)->base + _s_42932);
        _2 = (object)SEQ_PTR(_22566);
        _22567 = (object)*(((s1_ptr)_2)->base + 4);
        _22566 = NOVALUE;
        if (IS_ATOM_INT(_22567)) {
            _22568 = (_22567 == 6);
        }
        else {
            _22568 = binary_op(EQUALS, _22567, 6);
        }
        _22567 = NOVALUE;
        if (IS_ATOM_INT(_22568)) {
            if (_22568 != 0) {
                DeRef(_22569);
                _22569 = 1;
                goto L5; // [82] 108
            }
        }
        else {
            if (DBL_PTR(_22568)->dbl != 0.0) {
                DeRef(_22569);
                _22569 = 1;
                goto L5; // [82] 108
            }
        }
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _22570 = (object)*(((s1_ptr)_2)->base + _s_42932);
        _2 = (object)SEQ_PTR(_22570);
        _22571 = (object)*(((s1_ptr)_2)->base + 4);
        _22570 = NOVALUE;
        if (IS_ATOM_INT(_22571)) {
            _22572 = (_22571 == 5);
        }
        else {
            _22572 = binary_op(EQUALS, _22571, 5);
        }
        _22571 = NOVALUE;
        DeRef(_22569);
        if (IS_ATOM_INT(_22572))
        _22569 = (_22572 != 0);
        else
        _22569 = DBL_PTR(_22572)->dbl != 0.0;
L5: 
        if (_22569 != 0) {
            _22573 = 1;
            goto L6; // [108] 134
        }
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _22574 = (object)*(((s1_ptr)_2)->base + _s_42932);
        _2 = (object)SEQ_PTR(_22574);
        _22575 = (object)*(((s1_ptr)_2)->base + 4);
        _22574 = NOVALUE;
        if (IS_ATOM_INT(_22575)) {
            _22576 = (_22575 == 11);
        }
        else {
            _22576 = binary_op(EQUALS, _22575, 11);
        }
        _22575 = NOVALUE;
        if (IS_ATOM_INT(_22576))
        _22573 = (_22576 != 0);
        else
        _22573 = DBL_PTR(_22576)->dbl != 0.0;
L6: 
        if (_22573 != 0) {
            DeRef(_22577);
            _22577 = 1;
            goto L7; // [134] 160
        }
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _22578 = (object)*(((s1_ptr)_2)->base + _s_42932);
        _2 = (object)SEQ_PTR(_22578);
        _22579 = (object)*(((s1_ptr)_2)->base + 4);
        _22578 = NOVALUE;
        if (IS_ATOM_INT(_22579)) {
            _22580 = (_22579 == 13);
        }
        else {
            _22580 = binary_op(EQUALS, _22579, 13);
        }
        _22579 = NOVALUE;
        if (IS_ATOM_INT(_22580))
        _22577 = (_22580 != 0);
        else
        _22577 = DBL_PTR(_22580)->dbl != 0.0;
L7: 
        if (_22577 == 0)
        {
            _22577 = NOVALUE;
            goto L4; // [161] 242
        }
        else{
            _22577 = NOVALUE;
        }

        /** c_decl.e:176					  if and_bits(mask, power(2, remainder(s, E_SIZE))) then*/
        _22581 = (_s_42932 % 29);
        _22582 = power(2, _22581);
        _22581 = NOVALUE;
        if (IS_ATOM_INT(_22582)) {
            {uintptr_t tu;
                 tu = (uintptr_t)_mask_42928 & (uintptr_t)_22582;
                 _22583 = MAKE_UINT(tu);
            }
        }
        else {
            temp_d.dbl = (eudouble)_mask_42928;
            _22583 = Dand_bits(&temp_d, DBL_PTR(_22582));
        }
        DeRef(_22582);
        _22582 = NOVALUE;
        if (_22583 == 0) {
            DeRef(_22583);
            _22583 = NOVALUE;
            goto L8; // [180] 241
        }
        else {
            if (!IS_ATOM_INT(_22583) && DBL_PTR(_22583)->dbl == 0.0){
                DeRef(_22583);
                _22583 = NOVALUE;
                goto L8; // [180] 241
            }
            DeRef(_22583);
            _22583 = NOVALUE;
        }
        DeRef(_22583);
        _22583 = NOVALUE;

        /** c_decl.e:177						  if mask = E_ALL_EFFECT or s < sub then*/
        _22584 = (_mask_42928 == 1073741823);
        if (_22584 != 0) {
            goto L9; // [191] 204
        }
        _22586 = (_s_42932 < _sub_42930);
        if (_22586 == 0)
        {
            DeRef(_22586);
            _22586 = NOVALUE;
            goto LA; // [200] 240
        }
        else{
            DeRef(_22586);
            _22586 = NOVALUE;
        }
L9: 

        /** c_decl.e:178							  BB_info[i][BB_TYPE..BB_OBJ] =*/
        _2 = (object)SEQ_PTR(_58BB_info_42889);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _58BB_info_42889 = MAKE_SEQ(_2);
        }
        _3 = (object)(_i_42935 + ((s1_ptr)_2)->base);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = -1073741824;
        ((intptr_t *)_2)[2] = 1073741823;
        _22589 = MAKE_SEQ(_1);
        _1 = NewS1(4);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = 0;
        ((intptr_t*)_2)[2] = 0;
        Ref(_36NOVALUE_21621);
        ((intptr_t*)_2)[3] = _36NOVALUE_21621;
        ((intptr_t*)_2)[4] = _22589;
        _22590 = MAKE_SEQ(_1);
        _22589 = NOVALUE;
        assign_slice_seq = (s1_ptr *)_3;
        AssignSlice(2, 5, _22590);
        DeRefDS(_22590);
        _22590 = NOVALUE;
LA: 
L8: 
L4: 

        /** c_decl.e:183			end for*/
        _i_42935 = _i_42935 + 1;
        goto L2; // [244] 26
L3: 
        ;
    }
    goto LB; // [249] 260
L1: 

    /** c_decl.e:186			BB_info = {}*/
    RefDS(_22190);
    DeRef(_58BB_info_42889);
    _58BB_info_42889 = _22190;
LB: 

    /** c_decl.e:188	end procedure*/
    DeRef(_22587);
    _22587 = NOVALUE;
    DeRef(_22580);
    _22580 = NOVALUE;
    DeRef(_22564);
    _22564 = NOVALUE;
    DeRef(_22576);
    _22576 = NOVALUE;
    DeRef(_22568);
    _22568 = NOVALUE;
    DeRef(_22584);
    _22584 = NOVALUE;
    DeRef(_22572);
    _22572 = NOVALUE;
    return;
    ;
}


object _58BB_var_obj(object _var_43000)
{
    object _bbi_43001 = NOVALUE;
    object _22601 = NOVALUE;
    object _22599 = NOVALUE;
    object _22597 = NOVALUE;
    object _22596 = NOVALUE;
    object _22594 = NOVALUE;
    object _22592 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:196		for i = length(BB_info) to 1 by -1 do*/
    if (IS_SEQUENCE(_58BB_info_42889)){
            _22592 = SEQ_PTR(_58BB_info_42889)->length;
    }
    else {
        _22592 = 1;
    }
    {
        object _i_43003;
        _i_43003 = _22592;
L1: 
        if (_i_43003 < 1){
            goto L2; // [10] 99
        }

        /** c_decl.e:197			bbi = BB_info[i]*/
        DeRef(_bbi_43001);
        _2 = (object)SEQ_PTR(_58BB_info_42889);
        _bbi_43001 = (object)*(((s1_ptr)_2)->base + _i_43003);
        Ref(_bbi_43001);

        /** c_decl.e:198			if bbi[BB_VAR] != var then*/
        _2 = (object)SEQ_PTR(_bbi_43001);
        _22594 = (object)*(((s1_ptr)_2)->base + 1);
        if (binary_op_a(EQUALS, _22594, _var_43000)){
            _22594 = NOVALUE;
            goto L3; // [31] 40
        }
        _22594 = NOVALUE;

        /** c_decl.e:199				continue*/
        goto L4; // [37] 94
L3: 

        /** c_decl.e:202			if SymTab[var][S_MODE] != M_NORMAL then*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _22596 = (object)*(((s1_ptr)_2)->base + _var_43000);
        _2 = (object)SEQ_PTR(_22596);
        _22597 = (object)*(((s1_ptr)_2)->base + 3);
        _22596 = NOVALUE;
        if (binary_op_a(EQUALS, _22597, 1)){
            _22597 = NOVALUE;
            goto L5; // [56] 65
        }
        _22597 = NOVALUE;

        /** c_decl.e:203				continue*/
        goto L4; // [62] 94
L5: 

        /** c_decl.e:206			if bbi[BB_TYPE] != TYPE_INTEGER then*/
        _2 = (object)SEQ_PTR(_bbi_43001);
        _22599 = (object)*(((s1_ptr)_2)->base + 2);
        if (binary_op_a(EQUALS, _22599, 1)){
            _22599 = NOVALUE;
            goto L6; // [73] 82
        }
        _22599 = NOVALUE;

        /** c_decl.e:207				exit*/
        goto L2; // [79] 99
L6: 

        /** c_decl.e:210			return bbi[BB_OBJ]*/
        _2 = (object)SEQ_PTR(_bbi_43001);
        _22601 = (object)*(((s1_ptr)_2)->base + 5);
        Ref(_22601);
        DeRef(_bbi_43001);
        return _22601;

        /** c_decl.e:211		end for*/
L4: 
        _i_43003 = _i_43003 + -1;
        goto L1; // [94] 17
L2: 
        ;
    }

    /** c_decl.e:212		return BB_def_values*/
    RefDS(_58BB_def_values_42994);
    DeRef(_bbi_43001);
    _22601 = NOVALUE;
    return _58BB_def_values_42994;
    ;
}


object _58BB_var_type(object _var_43023)
{
    object _22616 = NOVALUE;
    object _22615 = NOVALUE;
    object _22613 = NOVALUE;
    object _22612 = NOVALUE;
    object _22611 = NOVALUE;
    object _22610 = NOVALUE;
    object _22609 = NOVALUE;
    object _22608 = NOVALUE;
    object _22607 = NOVALUE;
    object _22606 = NOVALUE;
    object _22605 = NOVALUE;
    object _22604 = NOVALUE;
    object _22603 = NOVALUE;
    object _22602 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:218		for i = length(BB_info) to 1 by -1 do*/
    if (IS_SEQUENCE(_58BB_info_42889)){
            _22602 = SEQ_PTR(_58BB_info_42889)->length;
    }
    else {
        _22602 = 1;
    }
    {
        object _i_43025;
        _i_43025 = _22602;
L1: 
        if (_i_43025 < 1){
            goto L2; // [10] 125
        }

        /** c_decl.e:219			if BB_info[i][BB_VAR] = var and*/
        _2 = (object)SEQ_PTR(_58BB_info_42889);
        _22603 = (object)*(((s1_ptr)_2)->base + _i_43025);
        _2 = (object)SEQ_PTR(_22603);
        _22604 = (object)*(((s1_ptr)_2)->base + 1);
        _22603 = NOVALUE;
        if (IS_ATOM_INT(_22604)) {
            _22605 = (_22604 == _var_43023);
        }
        else {
            _22605 = binary_op(EQUALS, _22604, _var_43023);
        }
        _22604 = NOVALUE;
        if (IS_ATOM_INT(_22605)) {
            if (_22605 == 0) {
                goto L3; // [33] 118
            }
        }
        else {
            if (DBL_PTR(_22605)->dbl == 0.0) {
                goto L3; // [33] 118
            }
        }
        _2 = (object)SEQ_PTR(_58BB_info_42889);
        _22607 = (object)*(((s1_ptr)_2)->base + _i_43025);
        _2 = (object)SEQ_PTR(_22607);
        _22608 = (object)*(((s1_ptr)_2)->base + 1);
        _22607 = NOVALUE;
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        if (!IS_ATOM_INT(_22608)){
            _22609 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_22608)->dbl));
        }
        else{
            _22609 = (object)*(((s1_ptr)_2)->base + _22608);
        }
        _2 = (object)SEQ_PTR(_22609);
        _22610 = (object)*(((s1_ptr)_2)->base + 3);
        _22609 = NOVALUE;
        if (IS_ATOM_INT(_22610)) {
            _22611 = (_22610 == 1);
        }
        else {
            _22611 = binary_op(EQUALS, _22610, 1);
        }
        _22610 = NOVALUE;
        if (_22611 == 0) {
            DeRef(_22611);
            _22611 = NOVALUE;
            goto L3; // [66] 118
        }
        else {
            if (!IS_ATOM_INT(_22611) && DBL_PTR(_22611)->dbl == 0.0){
                DeRef(_22611);
                _22611 = NOVALUE;
                goto L3; // [66] 118
            }
            DeRef(_22611);
            _22611 = NOVALUE;
        }
        DeRef(_22611);
        _22611 = NOVALUE;

        /** c_decl.e:221				ifdef DEBUG then*/

        /** c_decl.e:228				if BB_info[i][BB_TYPE] = TYPE_NULL then  -- var has only been read*/
        _2 = (object)SEQ_PTR(_58BB_info_42889);
        _22612 = (object)*(((s1_ptr)_2)->base + _i_43025);
        _2 = (object)SEQ_PTR(_22612);
        _22613 = (object)*(((s1_ptr)_2)->base + 2);
        _22612 = NOVALUE;
        if (binary_op_a(NOTEQ, _22613, 0)){
            _22613 = NOVALUE;
            goto L4; // [85] 100
        }
        _22613 = NOVALUE;

        /** c_decl.e:229					return TYPE_OBJECT*/
        _22608 = NOVALUE;
        DeRef(_22605);
        _22605 = NOVALUE;
        return 16;
        goto L5; // [97] 117
L4: 

        /** c_decl.e:231					return BB_info[i][BB_TYPE]*/
        _2 = (object)SEQ_PTR(_58BB_info_42889);
        _22615 = (object)*(((s1_ptr)_2)->base + _i_43025);
        _2 = (object)SEQ_PTR(_22615);
        _22616 = (object)*(((s1_ptr)_2)->base + 2);
        _22615 = NOVALUE;
        Ref(_22616);
        _22608 = NOVALUE;
        DeRef(_22605);
        _22605 = NOVALUE;
        return _22616;
L5: 
L3: 

        /** c_decl.e:234		end for*/
        _i_43025 = _i_43025 + -1;
        goto L1; // [120] 17
L2: 
        ;
    }

    /** c_decl.e:235		return TYPE_OBJECT*/
    _22608 = NOVALUE;
    _22616 = NOVALUE;
    DeRef(_22605);
    _22605 = NOVALUE;
    return 16;
    ;
}


object _58GType(object _s_43053)
{
    object _t_43054 = NOVALUE;
    object _local_t_43055 = NOVALUE;
    object _22620 = NOVALUE;
    object _22619 = NOVALUE;
    object _22617 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_s_43053)) {
        _1 = (object)(DBL_PTR(_s_43053)->dbl);
        DeRefDS(_s_43053);
        _s_43053 = _1;
    }

    /** c_decl.e:243		t = SymTab[s][S_GTYPE]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _22617 = (object)*(((s1_ptr)_2)->base + _s_43053);
    _2 = (object)SEQ_PTR(_22617);
    _t_43054 = (object)*(((s1_ptr)_2)->base + 36);
    if (!IS_ATOM_INT(_t_43054)){
        _t_43054 = (object)DBL_PTR(_t_43054)->dbl;
    }
    _22617 = NOVALUE;

    /** c_decl.e:244		ifdef DEBUG then*/

    /** c_decl.e:250		if SymTab[s][S_MODE] != M_NORMAL then*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _22619 = (object)*(((s1_ptr)_2)->base + _s_43053);
    _2 = (object)SEQ_PTR(_22619);
    _22620 = (object)*(((s1_ptr)_2)->base + 3);
    _22619 = NOVALUE;
    if (binary_op_a(EQUALS, _22620, 1)){
        _22620 = NOVALUE;
        goto L1; // [37] 48
    }
    _22620 = NOVALUE;

    /** c_decl.e:251			return t*/
    return _t_43054;
L1: 

    /** c_decl.e:254		local_t = BB_var_type(s)*/
    _local_t_43055 = _58BB_var_type(_s_43053);
    if (!IS_ATOM_INT(_local_t_43055)) {
        _1 = (object)(DBL_PTR(_local_t_43055)->dbl);
        DeRefDS(_local_t_43055);
        _local_t_43055 = _1;
    }

    /** c_decl.e:255		if local_t = TYPE_OBJECT then*/
    if (_local_t_43055 != 16)
    goto L2; // [60] 71

    /** c_decl.e:256			return t*/
    return _t_43054;
L2: 

    /** c_decl.e:258		if t = TYPE_INTEGER then*/
    if (_t_43054 != 1)
    goto L3; // [75] 88

    /** c_decl.e:259			return TYPE_INTEGER*/
    return 1;
L3: 

    /** c_decl.e:261		return local_t*/
    return _local_t_43055;
    ;
}


object _58GDelete()
{
    object _0, _1, _2;
    

    /** c_decl.e:269		return g_has_delete*/
    return _58g_has_delete_43075;
    ;
}


object _58HasDelete(object _s_43082)
{
    object _22635 = NOVALUE;
    object _22634 = NOVALUE;
    object _22632 = NOVALUE;
    object _22631 = NOVALUE;
    object _22630 = NOVALUE;
    object _22629 = NOVALUE;
    object _22627 = NOVALUE;
    object _22626 = NOVALUE;
    object _22625 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_s_43082)) {
        _1 = (object)(DBL_PTR(_s_43082)->dbl);
        DeRefDS(_s_43082);
        _s_43082 = _1;
    }

    /** c_decl.e:274		for i = length(BB_info) to 1 by -1 do*/
    if (IS_SEQUENCE(_58BB_info_42889)){
            _22625 = SEQ_PTR(_58BB_info_42889)->length;
    }
    else {
        _22625 = 1;
    }
    {
        object _i_43084;
        _i_43084 = _22625;
L1: 
        if (_i_43084 < 1){
            goto L2; // [10] 57
        }

        /** c_decl.e:275			if BB_info[i][BB_VAR] = s then*/
        _2 = (object)SEQ_PTR(_58BB_info_42889);
        _22626 = (object)*(((s1_ptr)_2)->base + _i_43084);
        _2 = (object)SEQ_PTR(_22626);
        _22627 = (object)*(((s1_ptr)_2)->base + 1);
        _22626 = NOVALUE;
        if (binary_op_a(NOTEQ, _22627, _s_43082)){
            _22627 = NOVALUE;
            goto L3; // [29] 50
        }
        _22627 = NOVALUE;

        /** c_decl.e:276				return BB_info[i][BB_DELETE]*/
        _2 = (object)SEQ_PTR(_58BB_info_42889);
        _22629 = (object)*(((s1_ptr)_2)->base + _i_43084);
        _2 = (object)SEQ_PTR(_22629);
        _22630 = (object)*(((s1_ptr)_2)->base + 6);
        _22629 = NOVALUE;
        Ref(_22630);
        return _22630;
L3: 

        /** c_decl.e:278		end for*/
        _i_43084 = _i_43084 + -1;
        goto L1; // [52] 17
L2: 
        ;
    }

    /** c_decl.e:279		if length(SymTab[s]) < S_HAS_DELETE then*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _22631 = (object)*(((s1_ptr)_2)->base + _s_43082);
    if (IS_SEQUENCE(_22631)){
            _22632 = SEQ_PTR(_22631)->length;
    }
    else {
        _22632 = 1;
    }
    _22631 = NOVALUE;
    if (_22632 >= 54)
    goto L4; // [70] 81

    /** c_decl.e:280			return 0*/
    _22630 = NOVALUE;
    _22631 = NOVALUE;
    return 0;
L4: 

    /** c_decl.e:282		return SymTab[s][S_HAS_DELETE]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _22634 = (object)*(((s1_ptr)_2)->base + _s_43082);
    _2 = (object)SEQ_PTR(_22634);
    _22635 = (object)*(((s1_ptr)_2)->base + 54);
    _22634 = NOVALUE;
    Ref(_22635);
    _22630 = NOVALUE;
    _22631 = NOVALUE;
    return _22635;
    ;
}


object _58ObjValue(object _s_43105)
{
    object _local_t_43106 = NOVALUE;
    object _st_43107 = NOVALUE;
    object _tmin_43108 = NOVALUE;
    object _tmax_43109 = NOVALUE;
    object _22648 = NOVALUE;
    object _22646 = NOVALUE;
    object _22645 = NOVALUE;
    object _22643 = NOVALUE;
    object _22640 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_s_43105)) {
        _1 = (object)(DBL_PTR(_s_43105)->dbl);
        DeRefDS(_s_43105);
        _s_43105 = _1;
    }

    /** c_decl.e:293		st = SymTab[s]*/
    DeRef(_st_43107);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _st_43107 = (object)*(((s1_ptr)_2)->base + _s_43105);
    Ref(_st_43107);

    /** c_decl.e:294		tmin = st[S_OBJ_MIN]*/
    DeRef(_tmin_43108);
    _2 = (object)SEQ_PTR(_st_43107);
    _tmin_43108 = (object)*(((s1_ptr)_2)->base + 30);
    Ref(_tmin_43108);

    /** c_decl.e:295		tmax = st[S_OBJ_MAX]*/
    DeRef(_tmax_43109);
    _2 = (object)SEQ_PTR(_st_43107);
    _tmax_43109 = (object)*(((s1_ptr)_2)->base + 31);
    Ref(_tmax_43109);

    /** c_decl.e:297		if tmin != tmax then*/
    if (binary_op_a(EQUALS, _tmin_43108, _tmax_43109)){
        goto L1; // [29] 41
    }

    /** c_decl.e:298			tmin = NOVALUE*/
    Ref(_36NOVALUE_21621);
    DeRef(_tmin_43108);
    _tmin_43108 = _36NOVALUE_21621;
L1: 

    /** c_decl.e:300		if st[S_MODE] != M_NORMAL then*/
    _2 = (object)SEQ_PTR(_st_43107);
    _22640 = (object)*(((s1_ptr)_2)->base + 3);
    if (binary_op_a(EQUALS, _22640, 1)){
        _22640 = NOVALUE;
        goto L2; // [51] 62
    }
    _22640 = NOVALUE;

    /** c_decl.e:301			return tmin*/
    DeRef(_local_t_43106);
    DeRef(_st_43107);
    DeRef(_tmax_43109);
    return _tmin_43108;
L2: 

    /** c_decl.e:305		local_t = BB_var_obj(s)*/
    _0 = _local_t_43106;
    _local_t_43106 = _58BB_var_obj(_s_43105);
    DeRef(_0);

    /** c_decl.e:306		if local_t[MIN] = NOVALUE then*/
    _2 = (object)SEQ_PTR(_local_t_43106);
    _22643 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _22643, _36NOVALUE_21621)){
        _22643 = NOVALUE;
        goto L3; // [80] 91
    }
    _22643 = NOVALUE;

    /** c_decl.e:307			return tmin*/
    DeRefDS(_local_t_43106);
    DeRef(_st_43107);
    DeRef(_tmax_43109);
    return _tmin_43108;
L3: 

    /** c_decl.e:310		if local_t[MIN] != local_t[MAX] then*/
    _2 = (object)SEQ_PTR(_local_t_43106);
    _22645 = (object)*(((s1_ptr)_2)->base + 1);
    _2 = (object)SEQ_PTR(_local_t_43106);
    _22646 = (object)*(((s1_ptr)_2)->base + 2);
    if (binary_op_a(EQUALS, _22645, _22646)){
        _22645 = NOVALUE;
        _22646 = NOVALUE;
        goto L4; // [105] 116
    }
    _22645 = NOVALUE;
    _22646 = NOVALUE;

    /** c_decl.e:311			return tmin*/
    DeRefDS(_local_t_43106);
    DeRef(_st_43107);
    DeRef(_tmax_43109);
    return _tmin_43108;
L4: 

    /** c_decl.e:314		return local_t[MIN]*/
    _2 = (object)SEQ_PTR(_local_t_43106);
    _22648 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_22648);
    DeRefDS(_local_t_43106);
    DeRef(_st_43107);
    DeRef(_tmin_43108);
    DeRef(_tmax_43109);
    return _22648;
    ;
}


object _58TypeIs(object _x_43140, object _typei_43141)
{
    object _22650 = NOVALUE;
    object _22649 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_x_43140)) {
        _1 = (object)(DBL_PTR(_x_43140)->dbl);
        DeRefDS(_x_43140);
        _x_43140 = _1;
    }

    /** c_decl.e:319		return GType(x) = typei*/
    _22649 = _58GType(_x_43140);
    if (IS_ATOM_INT(_22649)) {
        _22650 = (_22649 == _typei_43141);
    }
    else {
        _22650 = binary_op(EQUALS, _22649, _typei_43141);
    }
    DeRef(_22649);
    _22649 = NOVALUE;
    return _22650;
    ;
}


object _58TypeIsIn(object _x_43146, object _types_43147)
{
    object _22652 = NOVALUE;
    object _22651 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_x_43146)) {
        _1 = (object)(DBL_PTR(_x_43146)->dbl);
        DeRefDS(_x_43146);
        _x_43146 = _1;
    }

    /** c_decl.e:323		return find(GType(x), types)*/
    _22651 = _58GType(_x_43146);
    _22652 = find_from(_22651, _types_43147, 1);
    DeRef(_22651);
    _22651 = NOVALUE;
    DeRefDS(_types_43147);
    return _22652;
    ;
}


object _58TypeIsNot(object _x_43152, object _typei_43153)
{
    object _22654 = NOVALUE;
    object _22653 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_x_43152)) {
        _1 = (object)(DBL_PTR(_x_43152)->dbl);
        DeRefDS(_x_43152);
        _x_43152 = _1;
    }

    /** c_decl.e:327		return GType(x) != typei*/
    _22653 = _58GType(_x_43152);
    if (IS_ATOM_INT(_22653)) {
        _22654 = (_22653 != _typei_43153);
    }
    else {
        _22654 = binary_op(NOTEQ, _22653, _typei_43153);
    }
    DeRef(_22653);
    _22653 = NOVALUE;
    return _22654;
    ;
}


object _58TypeIsNotIn(object _x_43158, object _types_43159)
{
    object _22657 = NOVALUE;
    object _22656 = NOVALUE;
    object _22655 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_x_43158)) {
        _1 = (object)(DBL_PTR(_x_43158)->dbl);
        DeRefDS(_x_43158);
        _x_43158 = _1;
    }

    /** c_decl.e:331		return not find(GType(x), types)*/
    _22655 = _58GType(_x_43158);
    _22656 = find_from(_22655, _types_43159, 1);
    DeRef(_22655);
    _22655 = NOVALUE;
    _22657 = (_22656 == 0);
    _22656 = NOVALUE;
    DeRefDS(_types_43159);
    return _22657;
    ;
}


object _58or_type(object _t1_43165, object _t2_43166)
{
    object _22677 = NOVALUE;
    object _22676 = NOVALUE;
    object _22675 = NOVALUE;
    object _22674 = NOVALUE;
    object _22669 = NOVALUE;
    object _22667 = NOVALUE;
    object _22662 = NOVALUE;
    object _22660 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_t1_43165)) {
        _1 = (object)(DBL_PTR(_t1_43165)->dbl);
        DeRefDS(_t1_43165);
        _t1_43165 = _1;
    }
    if (!IS_ATOM_INT(_t2_43166)) {
        _1 = (object)(DBL_PTR(_t2_43166)->dbl);
        DeRefDS(_t2_43166);
        _t2_43166 = _1;
    }

    /** c_decl.e:337		if t1 = TYPE_NULL then*/
    if (_t1_43165 != 0)
    goto L1; // [9] 22

    /** c_decl.e:338			return t2*/
    return _t2_43166;
    goto L2; // [19] 307
L1: 

    /** c_decl.e:340		elsif t2 = TYPE_NULL then*/
    if (_t2_43166 != 0)
    goto L3; // [26] 39

    /** c_decl.e:341			return t1*/
    return _t1_43165;
    goto L2; // [36] 307
L3: 

    /** c_decl.e:343		elsif t1 = TYPE_OBJECT or t2 = TYPE_OBJECT then*/
    _22660 = (_t1_43165 == 16);
    if (_22660 != 0) {
        goto L4; // [47] 62
    }
    _22662 = (_t2_43166 == 16);
    if (_22662 == 0)
    {
        DeRef(_22662);
        _22662 = NOVALUE;
        goto L5; // [58] 73
    }
    else{
        DeRef(_22662);
        _22662 = NOVALUE;
    }
L4: 

    /** c_decl.e:344			return TYPE_OBJECT*/
    DeRef(_22660);
    _22660 = NOVALUE;
    return 16;
    goto L2; // [70] 307
L5: 

    /** c_decl.e:346		elsif t1 = TYPE_SEQUENCE then*/
    if (_t1_43165 != 8)
    goto L6; // [77] 112

    /** c_decl.e:347			if t2 = TYPE_SEQUENCE then*/
    if (_t2_43166 != 8)
    goto L7; // [85] 100

    /** c_decl.e:348				return TYPE_SEQUENCE*/
    DeRef(_22660);
    _22660 = NOVALUE;
    return 8;
    goto L2; // [97] 307
L7: 

    /** c_decl.e:350				return TYPE_OBJECT*/
    DeRef(_22660);
    _22660 = NOVALUE;
    return 16;
    goto L2; // [109] 307
L6: 

    /** c_decl.e:353		elsif t2 = TYPE_SEQUENCE then*/
    if (_t2_43166 != 8)
    goto L8; // [116] 151

    /** c_decl.e:354			if t1 = TYPE_SEQUENCE then*/
    if (_t1_43165 != 8)
    goto L9; // [124] 139

    /** c_decl.e:355				return TYPE_SEQUENCE*/
    DeRef(_22660);
    _22660 = NOVALUE;
    return 8;
    goto L2; // [136] 307
L9: 

    /** c_decl.e:357				return TYPE_OBJECT*/
    DeRef(_22660);
    _22660 = NOVALUE;
    return 16;
    goto L2; // [148] 307
L8: 

    /** c_decl.e:360		elsif t1 = TYPE_ATOM or t2 = TYPE_ATOM then*/
    _22667 = (_t1_43165 == 4);
    if (_22667 != 0) {
        goto LA; // [159] 174
    }
    _22669 = (_t2_43166 == 4);
    if (_22669 == 0)
    {
        DeRef(_22669);
        _22669 = NOVALUE;
        goto LB; // [170] 185
    }
    else{
        DeRef(_22669);
        _22669 = NOVALUE;
    }
LA: 

    /** c_decl.e:361			return TYPE_ATOM*/
    DeRef(_22667);
    _22667 = NOVALUE;
    DeRef(_22660);
    _22660 = NOVALUE;
    return 4;
    goto L2; // [182] 307
LB: 

    /** c_decl.e:363		elsif t1 = TYPE_DOUBLE then*/
    if (_t1_43165 != 2)
    goto LC; // [189] 224

    /** c_decl.e:364			if t2 = TYPE_INTEGER then*/
    if (_t2_43166 != 1)
    goto LD; // [197] 212

    /** c_decl.e:365				return TYPE_ATOM*/
    DeRef(_22667);
    _22667 = NOVALUE;
    DeRef(_22660);
    _22660 = NOVALUE;
    return 4;
    goto L2; // [209] 307
LD: 

    /** c_decl.e:367				return TYPE_DOUBLE*/
    DeRef(_22667);
    _22667 = NOVALUE;
    DeRef(_22660);
    _22660 = NOVALUE;
    return 2;
    goto L2; // [221] 307
LC: 

    /** c_decl.e:370		elsif t2 = TYPE_DOUBLE then*/
    if (_t2_43166 != 2)
    goto LE; // [228] 263

    /** c_decl.e:371			if t1 = TYPE_INTEGER then*/
    if (_t1_43165 != 1)
    goto LF; // [236] 251

    /** c_decl.e:372				return TYPE_ATOM*/
    DeRef(_22667);
    _22667 = NOVALUE;
    DeRef(_22660);
    _22660 = NOVALUE;
    return 4;
    goto L2; // [248] 307
LF: 

    /** c_decl.e:374				return TYPE_DOUBLE*/
    DeRef(_22667);
    _22667 = NOVALUE;
    DeRef(_22660);
    _22660 = NOVALUE;
    return 2;
    goto L2; // [260] 307
LE: 

    /** c_decl.e:377		elsif t1 = TYPE_INTEGER and t2 = TYPE_INTEGER then*/
    _22674 = (_t1_43165 == 1);
    if (_22674 == 0) {
        goto L10; // [271] 296
    }
    _22676 = (_t2_43166 == 1);
    if (_22676 == 0)
    {
        DeRef(_22676);
        _22676 = NOVALUE;
        goto L10; // [282] 296
    }
    else{
        DeRef(_22676);
        _22676 = NOVALUE;
    }

    /** c_decl.e:378			return TYPE_INTEGER*/
    DeRef(_22667);
    _22667 = NOVALUE;
    DeRef(_22674);
    _22674 = NOVALUE;
    DeRef(_22660);
    _22660 = NOVALUE;
    return 1;
    goto L2; // [293] 307
L10: 

    /** c_decl.e:381			InternalErr(258, {t1, t2})*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _t1_43165;
    ((intptr_t *)_2)[2] = _t2_43166;
    _22677 = MAKE_SEQ(_1);
    _50InternalErr(258, _22677);
    _22677 = NOVALUE;
L2: 
    ;
}


void _58RemoveFromBB(object _s_43236)
{
    object _int_43237 = NOVALUE;
    object _22679 = NOVALUE;
    object _22678 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:388		for i = 1 to length(BB_info) do*/
    if (IS_SEQUENCE(_58BB_info_42889)){
            _22678 = SEQ_PTR(_58BB_info_42889)->length;
    }
    else {
        _22678 = 1;
    }
    {
        object _i_43239;
        _i_43239 = 1;
L1: 
        if (_i_43239 > _22678){
            goto L2; // [10] 59
        }

        /** c_decl.e:389			int = BB_info[i][BB_VAR]*/
        _2 = (object)SEQ_PTR(_58BB_info_42889);
        _22679 = (object)*(((s1_ptr)_2)->base + _i_43239);
        _2 = (object)SEQ_PTR(_22679);
        _int_43237 = (object)*(((s1_ptr)_2)->base + 1);
        if (!IS_ATOM_INT(_int_43237)){
            _int_43237 = (object)DBL_PTR(_int_43237)->dbl;
        }
        _22679 = NOVALUE;

        /** c_decl.e:390			if int = s then*/
        if (_int_43237 != _s_43236)
        goto L3; // [33] 52

        /** c_decl.e:391				BB_info = remove( BB_info, int )*/
        {
            s1_ptr assign_space = SEQ_PTR(_58BB_info_42889);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_int_43237)) ? _int_43237 : (object)(DBL_PTR(_int_43237)->dbl);
            int stop = (IS_ATOM_INT(_int_43237)) ? _int_43237 : (object)(DBL_PTR(_int_43237)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<1) {
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_58BB_info_42889), start, &_58BB_info_42889 );
                }
                else Tail(SEQ_PTR(_58BB_info_42889), stop+1, &_58BB_info_42889);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_58BB_info_42889), start, &_58BB_info_42889);
            }
            else {
                assign_slice_seq = &assign_space;
                _58BB_info_42889 = Remove_elements(start, stop, (SEQ_PTR(_58BB_info_42889)->ref == 1));
            }
        }

        /** c_decl.e:392				return*/
        return;
L3: 

        /** c_decl.e:394		end for*/
        _i_43239 = _i_43239 + 1;
        goto L1; // [54] 17
L2: 
        ;
    }

    /** c_decl.e:395	end procedure*/
    return;
    ;
}


void _58SetBBType(object _s_43257, object _t_43258, object _val_43259, object _etype_43260, object _has_delete_43261)
{
    object _found_43262 = NOVALUE;
    object _i_43263 = NOVALUE;
    object _tn_43264 = NOVALUE;
    object _int_43265 = NOVALUE;
    object _sym_43266 = NOVALUE;
    object _mode_43271 = NOVALUE;
    object _gtype_43286 = NOVALUE;
    object _new_type_43323 = NOVALUE;
    object _bbsym_43346 = NOVALUE;
    object _bbi_43482 = NOVALUE;
    object _22798 = NOVALUE;
    object _22797 = NOVALUE;
    object _22796 = NOVALUE;
    object _22794 = NOVALUE;
    object _22793 = NOVALUE;
    object _22792 = NOVALUE;
    object _22790 = NOVALUE;
    object _22789 = NOVALUE;
    object _22787 = NOVALUE;
    object _22785 = NOVALUE;
    object _22784 = NOVALUE;
    object _22782 = NOVALUE;
    object _22780 = NOVALUE;
    object _22779 = NOVALUE;
    object _22778 = NOVALUE;
    object _22777 = NOVALUE;
    object _22776 = NOVALUE;
    object _22775 = NOVALUE;
    object _22774 = NOVALUE;
    object _22773 = NOVALUE;
    object _22772 = NOVALUE;
    object _22769 = NOVALUE;
    object _22765 = NOVALUE;
    object _22760 = NOVALUE;
    object _22758 = NOVALUE;
    object _22757 = NOVALUE;
    object _22756 = NOVALUE;
    object _22754 = NOVALUE;
    object _22752 = NOVALUE;
    object _22751 = NOVALUE;
    object _22750 = NOVALUE;
    object _22748 = NOVALUE;
    object _22747 = NOVALUE;
    object _22745 = NOVALUE;
    object _22744 = NOVALUE;
    object _22743 = NOVALUE;
    object _22741 = NOVALUE;
    object _22740 = NOVALUE;
    object _22737 = NOVALUE;
    object _22736 = NOVALUE;
    object _22735 = NOVALUE;
    object _22733 = NOVALUE;
    object _22731 = NOVALUE;
    object _22730 = NOVALUE;
    object _22728 = NOVALUE;
    object _22727 = NOVALUE;
    object _22726 = NOVALUE;
    object _22724 = NOVALUE;
    object _22723 = NOVALUE;
    object _22712 = NOVALUE;
    object _22710 = NOVALUE;
    object _22707 = NOVALUE;
    object _22706 = NOVALUE;
    object _22703 = NOVALUE;
    object _22702 = NOVALUE;
    object _22701 = NOVALUE;
    object _22699 = NOVALUE;
    object _22698 = NOVALUE;
    object _22697 = NOVALUE;
    object _22695 = NOVALUE;
    object _22694 = NOVALUE;
    object _22692 = NOVALUE;
    object _22689 = NOVALUE;
    object _22687 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_s_43257)) {
        _1 = (object)(DBL_PTR(_s_43257)->dbl);
        DeRefDS(_s_43257);
        _s_43257 = _1;
    }
    if (!IS_ATOM_INT(_t_43258)) {
        _1 = (object)(DBL_PTR(_t_43258)->dbl);
        DeRefDS(_t_43258);
        _t_43258 = _1;
    }
    if (!IS_ATOM_INT(_etype_43260)) {
        _1 = (object)(DBL_PTR(_etype_43260)->dbl);
        DeRefDS(_etype_43260);
        _etype_43260 = _1;
    }
    if (!IS_ATOM_INT(_has_delete_43261)) {
        _1 = (object)(DBL_PTR(_has_delete_43261)->dbl);
        DeRefDS(_has_delete_43261);
        _has_delete_43261 = _1;
    }

    /** c_decl.e:416		if has_delete then*/
    if (_has_delete_43261 == 0)
    {
        goto L1; // [13] 27
    }
    else{
    }

    /** c_decl.e:417			p_has_delete = 1*/
    _58p_has_delete_43076 = 1;

    /** c_decl.e:418			g_has_delete = 1*/
    _58g_has_delete_43075 = 1;
L1: 

    /** c_decl.e:421		sym = SymTab[s]*/
    DeRef(_sym_43266);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _sym_43266 = (object)*(((s1_ptr)_2)->base + _s_43257);
    Ref(_sym_43266);

    /** c_decl.e:422		SymTab[s] = 0*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _s_43257);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);

    /** c_decl.e:424		integer mode = sym[S_MODE]*/
    _2 = (object)SEQ_PTR(_sym_43266);
    _mode_43271 = (object)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_mode_43271))
    _mode_43271 = (object)DBL_PTR(_mode_43271)->dbl;

    /** c_decl.e:425		if mode = M_NORMAL or mode = M_TEMP  then*/
    _22687 = (_mode_43271 == 1);
    if (_22687 != 0) {
        goto L2; // [61] 76
    }
    _22689 = (_mode_43271 == 3);
    if (_22689 == 0)
    {
        DeRef(_22689);
        _22689 = NOVALUE;
        goto L3; // [72] 1167
    }
    else{
        DeRef(_22689);
        _22689 = NOVALUE;
    }
L2: 

    /** c_decl.e:427			found = FALSE*/
    _found_43262 = _13FALSE_445;

    /** c_decl.e:428			if mode = M_TEMP then*/
    if (_mode_43271 != 3)
    goto L4; // [89] 465

    /** c_decl.e:429				sym[S_GTYPE] = t*/
    _2 = (object)SEQ_PTR(_sym_43266);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43266 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _t_43258;
    DeRef(_1);

    /** c_decl.e:430				sym[S_SEQ_ELEM] = etype*/
    _2 = (object)SEQ_PTR(_sym_43266);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43266 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _etype_43260;
    DeRef(_1);

    /** c_decl.e:431				integer gtype = sym[S_GTYPE]*/
    _2 = (object)SEQ_PTR(_sym_43266);
    _gtype_43286 = (object)*(((s1_ptr)_2)->base + 36);
    if (!IS_ATOM_INT(_gtype_43286))
    _gtype_43286 = (object)DBL_PTR(_gtype_43286)->dbl;

    /** c_decl.e:432				if gtype = TYPE_OBJECT*/
    _22692 = (_gtype_43286 == 16);
    if (_22692 != 0) {
        goto L5; // [125] 140
    }
    _22694 = (_gtype_43286 == 8);
    if (_22694 == 0)
    {
        DeRef(_22694);
        _22694 = NOVALUE;
        goto L6; // [136] 213
    }
    else{
        DeRef(_22694);
        _22694 = NOVALUE;
    }
L5: 

    /** c_decl.e:435					if val[MIN] < 0 then*/
    _2 = (object)SEQ_PTR(_val_43259);
    _22695 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(GREATEREQ, _22695, 0)){
        _22695 = NOVALUE;
        goto L7; // [148] 165
    }
    _22695 = NOVALUE;

    /** c_decl.e:436						sym[S_SEQ_LEN] = NOVALUE*/
    Ref(_36NOVALUE_21621);
    _2 = (object)SEQ_PTR(_sym_43266);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43266 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 32);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36NOVALUE_21621;
    DeRef(_1);
    goto L8; // [162] 180
L7: 

    /** c_decl.e:438						sym[S_SEQ_LEN] = val[MIN]*/
    _2 = (object)SEQ_PTR(_val_43259);
    _22697 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_22697);
    _2 = (object)SEQ_PTR(_sym_43266);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43266 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 32);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22697;
    if( _1 != _22697 ){
        DeRef(_1);
    }
    _22697 = NOVALUE;
L8: 

    /** c_decl.e:440					sym[S_OBJ] = NOVALUE*/
    Ref(_36NOVALUE_21621);
    _2 = (object)SEQ_PTR(_sym_43266);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43266 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36NOVALUE_21621;
    DeRef(_1);

    /** c_decl.e:442					sym[S_OBJ_MIN] = NOVALUE*/
    Ref(_36NOVALUE_21621);
    _2 = (object)SEQ_PTR(_sym_43266);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43266 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 30);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36NOVALUE_21621;
    DeRef(_1);

    /** c_decl.e:443					sym[S_OBJ_MAX] = NOVALUE*/
    Ref(_36NOVALUE_21621);
    _2 = (object)SEQ_PTR(_sym_43266);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43266 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 31);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36NOVALUE_21621;
    DeRef(_1);
    goto L9; // [210] 252
L6: 

    /** c_decl.e:445					sym[S_OBJ_MIN] = val[MIN]*/
    _2 = (object)SEQ_PTR(_val_43259);
    _22698 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_22698);
    _2 = (object)SEQ_PTR(_sym_43266);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43266 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 30);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22698;
    if( _1 != _22698 ){
        DeRef(_1);
    }
    _22698 = NOVALUE;

    /** c_decl.e:446					sym[S_OBJ_MAX] = val[MAX]*/
    _2 = (object)SEQ_PTR(_val_43259);
    _22699 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_22699);
    _2 = (object)SEQ_PTR(_sym_43266);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43266 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 31);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22699;
    if( _1 != _22699 ){
        DeRef(_1);
    }
    _22699 = NOVALUE;

    /** c_decl.e:447					sym[S_SEQ_LEN] = NOVALUE*/
    Ref(_36NOVALUE_21621);
    _2 = (object)SEQ_PTR(_sym_43266);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43266 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 32);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36NOVALUE_21621;
    DeRef(_1);
L9: 

    /** c_decl.e:449				if not Initializing then*/
    if (_36Initializing_21851 != 0)
    goto LA; // [256] 326

    /** c_decl.e:450					integer new_type = or_type(temp_name_type[sym[S_TEMP_NAME]][T_GTYPE_NEW], t)*/
    _2 = (object)SEQ_PTR(_sym_43266);
    _22701 = (object)*(((s1_ptr)_2)->base + 34);
    _2 = (object)SEQ_PTR(_36temp_name_type_21853);
    if (!IS_ATOM_INT(_22701)){
        _22702 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_22701)->dbl));
    }
    else{
        _22702 = (object)*(((s1_ptr)_2)->base + _22701);
    }
    _2 = (object)SEQ_PTR(_22702);
    _22703 = (object)*(((s1_ptr)_2)->base + 2);
    _22702 = NOVALUE;
    Ref(_22703);
    _new_type_43323 = _58or_type(_22703, _t_43258);
    _22703 = NOVALUE;
    if (!IS_ATOM_INT(_new_type_43323)) {
        _1 = (object)(DBL_PTR(_new_type_43323)->dbl);
        DeRefDS(_new_type_43323);
        _new_type_43323 = _1;
    }

    /** c_decl.e:451					if new_type = TYPE_NULL then*/
    if (_new_type_43323 != 0)
    goto LB; // [290] 304

    /** c_decl.e:452						new_type = TYPE_OBJECT*/
    _new_type_43323 = 16;
LB: 

    /** c_decl.e:454					temp_name_type[sym[S_TEMP_NAME]][T_GTYPE_NEW] = new_type*/
    _2 = (object)SEQ_PTR(_sym_43266);
    _22706 = (object)*(((s1_ptr)_2)->base + 34);
    _2 = (object)SEQ_PTR(_36temp_name_type_21853);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _36temp_name_type_21853 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_22706))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_22706)->dbl));
    else
    _3 = (object)(_22706 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _new_type_43323;
    DeRef(_1);
    _22707 = NOVALUE;
LA: 

    /** c_decl.e:458				tn = sym[S_TEMP_NAME]*/
    _2 = (object)SEQ_PTR(_sym_43266);
    _tn_43264 = (object)*(((s1_ptr)_2)->base + 34);
    if (!IS_ATOM_INT(_tn_43264))
    _tn_43264 = (object)DBL_PTR(_tn_43264)->dbl;

    /** c_decl.e:459				i = 1*/
    _i_43263 = 1;

    /** c_decl.e:460				while i <= length(BB_info) do*/
LC: 
    if (IS_SEQUENCE(_58BB_info_42889)){
            _22710 = SEQ_PTR(_58BB_info_42889)->length;
    }
    else {
        _22710 = 1;
    }
    if (_i_43263 > _22710)
    goto LD; // [351] 460

    /** c_decl.e:461					sequence bbsym*/

    /** c_decl.e:462					int = BB_info[i][BB_VAR]*/
    _2 = (object)SEQ_PTR(_58BB_info_42889);
    _22712 = (object)*(((s1_ptr)_2)->base + _i_43263);
    _2 = (object)SEQ_PTR(_22712);
    _int_43265 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_int_43265)){
        _int_43265 = (object)DBL_PTR(_int_43265)->dbl;
    }
    _22712 = NOVALUE;

    /** c_decl.e:463					if int = s then*/
    if (_int_43265 != _s_43257)
    goto LE; // [373] 387

    /** c_decl.e:464						bbsym = sym*/
    RefDS(_sym_43266);
    DeRef(_bbsym_43346);
    _bbsym_43346 = _sym_43266;
    goto LF; // [384] 398
LE: 

    /** c_decl.e:466						bbsym = SymTab[int]*/
    DeRef(_bbsym_43346);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _bbsym_43346 = (object)*(((s1_ptr)_2)->base + _int_43265);
    Ref(_bbsym_43346);
LF: 

    /** c_decl.e:468					int = bbsym[S_MODE]*/
    _2 = (object)SEQ_PTR(_bbsym_43346);
    _int_43265 = (object)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_int_43265))
    _int_43265 = (object)DBL_PTR(_int_43265)->dbl;

    /** c_decl.e:469					if int = M_TEMP then*/
    if (_int_43265 != 3)
    goto L10; // [412] 447

    /** c_decl.e:470						int = bbsym[S_TEMP_NAME]*/
    _2 = (object)SEQ_PTR(_bbsym_43346);
    _int_43265 = (object)*(((s1_ptr)_2)->base + 34);
    if (!IS_ATOM_INT(_int_43265))
    _int_43265 = (object)DBL_PTR(_int_43265)->dbl;

    /** c_decl.e:471						if int = tn then*/
    if (_int_43265 != _tn_43264)
    goto L11; // [426] 446

    /** c_decl.e:472							found = TRUE*/
    _found_43262 = _13TRUE_447;

    /** c_decl.e:473							exit*/
    DeRefDS(_bbsym_43346);
    _bbsym_43346 = NOVALUE;
    goto LD; // [443] 460
L11: 
L10: 

    /** c_decl.e:476					i += 1*/
    _i_43263 = _i_43263 + 1;
    DeRef(_bbsym_43346);
    _bbsym_43346 = NOVALUE;

    /** c_decl.e:477				end while*/
    goto LC; // [457] 346
LD: 
    goto L12; // [462] 889
L4: 

    /** c_decl.e:479				if t != TYPE_NULL then*/
    if (_t_43258 == 0)
    goto L13; // [469] 824

    /** c_decl.e:480					if not Initializing then*/
    if (_36Initializing_21851 != 0)
    goto L14; // [477] 500

    /** c_decl.e:481						sym[S_GTYPE_NEW] = or_type(sym[S_GTYPE_NEW], t)*/
    _2 = (object)SEQ_PTR(_sym_43266);
    _22723 = (object)*(((s1_ptr)_2)->base + 38);
    Ref(_22723);
    _22724 = _58or_type(_22723, _t_43258);
    _22723 = NOVALUE;
    _2 = (object)SEQ_PTR(_sym_43266);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43266 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 38);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22724;
    if( _1 != _22724 ){
        DeRef(_1);
    }
    _22724 = NOVALUE;
L14: 

    /** c_decl.e:484					if t = TYPE_SEQUENCE then*/
    if (_t_43258 != 8)
    goto L15; // [504] 633

    /** c_decl.e:485						sym[S_SEQ_ELEM_NEW] =*/
    _2 = (object)SEQ_PTR(_sym_43266);
    _22726 = (object)*(((s1_ptr)_2)->base + 40);
    Ref(_22726);
    _22727 = _58or_type(_22726, _etype_43260);
    _22726 = NOVALUE;
    _2 = (object)SEQ_PTR(_sym_43266);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43266 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 40);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22727;
    if( _1 != _22727 ){
        DeRef(_1);
    }
    _22727 = NOVALUE;

    /** c_decl.e:488						if val[MIN] != -1 then*/
    _2 = (object)SEQ_PTR(_val_43259);
    _22728 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _22728, -1)){
        _22728 = NOVALUE;
        goto L16; // [535] 823
    }
    _22728 = NOVALUE;

    /** c_decl.e:489							if sym[S_SEQ_LEN_NEW] = -NOVALUE then*/
    _2 = (object)SEQ_PTR(_sym_43266);
    _22730 = (object)*(((s1_ptr)_2)->base + 39);
    if (IS_ATOM_INT(_36NOVALUE_21621)) {
        if ((uintptr_t)_36NOVALUE_21621 == (uintptr_t)HIGH_BITS){
            _22731 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _22731 = - _36NOVALUE_21621;
        }
    }
    else {
        _22731 = unary_op(UMINUS, _36NOVALUE_21621);
    }
    if (binary_op_a(NOTEQ, _22730, _22731)){
        _22730 = NOVALUE;
        DeRef(_22731);
        _22731 = NOVALUE;
        goto L17; // [552] 599
    }
    _22730 = NOVALUE;
    DeRef(_22731);
    _22731 = NOVALUE;

    /** c_decl.e:490								if val[MIN] < 0 then*/
    _2 = (object)SEQ_PTR(_val_43259);
    _22733 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(GREATEREQ, _22733, 0)){
        _22733 = NOVALUE;
        goto L18; // [564] 581
    }
    _22733 = NOVALUE;

    /** c_decl.e:491									sym[S_SEQ_LEN_NEW] = NOVALUE*/
    Ref(_36NOVALUE_21621);
    _2 = (object)SEQ_PTR(_sym_43266);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43266 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 39);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36NOVALUE_21621;
    DeRef(_1);
    goto L16; // [578] 823
L18: 

    /** c_decl.e:493									sym[S_SEQ_LEN_NEW] = val[MIN]*/
    _2 = (object)SEQ_PTR(_val_43259);
    _22735 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_22735);
    _2 = (object)SEQ_PTR(_sym_43266);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43266 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 39);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22735;
    if( _1 != _22735 ){
        DeRef(_1);
    }
    _22735 = NOVALUE;
    goto L16; // [596] 823
L17: 

    /** c_decl.e:495							elsif val[MIN] != sym[S_SEQ_LEN_NEW] then*/
    _2 = (object)SEQ_PTR(_val_43259);
    _22736 = (object)*(((s1_ptr)_2)->base + 1);
    _2 = (object)SEQ_PTR(_sym_43266);
    _22737 = (object)*(((s1_ptr)_2)->base + 39);
    if (binary_op_a(EQUALS, _22736, _22737)){
        _22736 = NOVALUE;
        _22737 = NOVALUE;
        goto L16; // [613] 823
    }
    _22736 = NOVALUE;
    _22737 = NOVALUE;

    /** c_decl.e:496								sym[S_SEQ_LEN_NEW] = NOVALUE*/
    Ref(_36NOVALUE_21621);
    _2 = (object)SEQ_PTR(_sym_43266);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43266 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 39);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36NOVALUE_21621;
    DeRef(_1);
    goto L16; // [630] 823
L15: 

    /** c_decl.e:500					elsif t = TYPE_INTEGER then*/
    if (_t_43258 != 1)
    goto L19; // [637] 774

    /** c_decl.e:502						if sym[S_OBJ_MIN_NEW] = -NOVALUE then*/
    _2 = (object)SEQ_PTR(_sym_43266);
    _22740 = (object)*(((s1_ptr)_2)->base + 41);
    if (IS_ATOM_INT(_36NOVALUE_21621)) {
        if ((uintptr_t)_36NOVALUE_21621 == (uintptr_t)HIGH_BITS){
            _22741 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _22741 = - _36NOVALUE_21621;
        }
    }
    else {
        _22741 = unary_op(UMINUS, _36NOVALUE_21621);
    }
    if (binary_op_a(NOTEQ, _22740, _22741)){
        _22740 = NOVALUE;
        DeRef(_22741);
        _22741 = NOVALUE;
        goto L1A; // [654] 689
    }
    _22740 = NOVALUE;
    DeRef(_22741);
    _22741 = NOVALUE;

    /** c_decl.e:504							sym[S_OBJ_MIN_NEW] = val[MIN]*/
    _2 = (object)SEQ_PTR(_val_43259);
    _22743 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_22743);
    _2 = (object)SEQ_PTR(_sym_43266);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43266 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 41);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22743;
    if( _1 != _22743 ){
        DeRef(_1);
    }
    _22743 = NOVALUE;

    /** c_decl.e:505							sym[S_OBJ_MAX_NEW] = val[MAX]*/
    _2 = (object)SEQ_PTR(_val_43259);
    _22744 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_22744);
    _2 = (object)SEQ_PTR(_sym_43266);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43266 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 42);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22744;
    if( _1 != _22744 ){
        DeRef(_1);
    }
    _22744 = NOVALUE;
    goto L16; // [686] 823
L1A: 

    /** c_decl.e:507						elsif sym[S_OBJ_MIN_NEW] != NOVALUE then*/
    _2 = (object)SEQ_PTR(_sym_43266);
    _22745 = (object)*(((s1_ptr)_2)->base + 41);
    if (binary_op_a(EQUALS, _22745, _36NOVALUE_21621)){
        _22745 = NOVALUE;
        goto L16; // [699] 823
    }
    _22745 = NOVALUE;

    /** c_decl.e:509							if val[MIN] < sym[S_OBJ_MIN_NEW] then*/
    _2 = (object)SEQ_PTR(_val_43259);
    _22747 = (object)*(((s1_ptr)_2)->base + 1);
    _2 = (object)SEQ_PTR(_sym_43266);
    _22748 = (object)*(((s1_ptr)_2)->base + 41);
    if (binary_op_a(GREATEREQ, _22747, _22748)){
        _22747 = NOVALUE;
        _22748 = NOVALUE;
        goto L1B; // [717] 736
    }
    _22747 = NOVALUE;
    _22748 = NOVALUE;

    /** c_decl.e:510								sym[S_OBJ_MIN_NEW] = val[MIN]*/
    _2 = (object)SEQ_PTR(_val_43259);
    _22750 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_22750);
    _2 = (object)SEQ_PTR(_sym_43266);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43266 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 41);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22750;
    if( _1 != _22750 ){
        DeRef(_1);
    }
    _22750 = NOVALUE;
L1B: 

    /** c_decl.e:512							if val[MAX] > sym[S_OBJ_MAX_NEW] then*/
    _2 = (object)SEQ_PTR(_val_43259);
    _22751 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_sym_43266);
    _22752 = (object)*(((s1_ptr)_2)->base + 42);
    if (binary_op_a(LESSEQ, _22751, _22752)){
        _22751 = NOVALUE;
        _22752 = NOVALUE;
        goto L16; // [750] 823
    }
    _22751 = NOVALUE;
    _22752 = NOVALUE;

    /** c_decl.e:513								sym[S_OBJ_MAX_NEW] = val[MAX]*/
    _2 = (object)SEQ_PTR(_val_43259);
    _22754 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_22754);
    _2 = (object)SEQ_PTR(_sym_43266);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43266 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 42);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22754;
    if( _1 != _22754 ){
        DeRef(_1);
    }
    _22754 = NOVALUE;
    goto L16; // [771] 823
L19: 

    /** c_decl.e:518						sym[S_OBJ_MIN_NEW] = NOVALUE*/
    Ref(_36NOVALUE_21621);
    _2 = (object)SEQ_PTR(_sym_43266);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43266 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 41);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36NOVALUE_21621;
    DeRef(_1);

    /** c_decl.e:519						if t = TYPE_OBJECT then*/
    if (_t_43258 != 16)
    goto L1C; // [788] 822

    /** c_decl.e:522							sym[S_SEQ_ELEM_NEW] =*/
    _2 = (object)SEQ_PTR(_sym_43266);
    _22756 = (object)*(((s1_ptr)_2)->base + 40);
    Ref(_22756);
    _22757 = _58or_type(_22756, _etype_43260);
    _22756 = NOVALUE;
    _2 = (object)SEQ_PTR(_sym_43266);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43266 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 40);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22757;
    if( _1 != _22757 ){
        DeRef(_1);
    }
    _22757 = NOVALUE;

    /** c_decl.e:524							sym[S_SEQ_LEN_NEW] = NOVALUE*/
    Ref(_36NOVALUE_21621);
    _2 = (object)SEQ_PTR(_sym_43266);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43266 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 39);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36NOVALUE_21621;
    DeRef(_1);
L1C: 
L16: 
L13: 

    /** c_decl.e:529				i = 1*/
    _i_43263 = 1;

    /** c_decl.e:530				while i <= length(BB_info) do*/
L1D: 
    if (IS_SEQUENCE(_58BB_info_42889)){
            _22758 = SEQ_PTR(_58BB_info_42889)->length;
    }
    else {
        _22758 = 1;
    }
    if (_i_43263 > _22758)
    goto L1E; // [839] 888

    /** c_decl.e:531					int = BB_info[i][BB_VAR]*/
    _2 = (object)SEQ_PTR(_58BB_info_42889);
    _22760 = (object)*(((s1_ptr)_2)->base + _i_43263);
    _2 = (object)SEQ_PTR(_22760);
    _int_43265 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_int_43265)){
        _int_43265 = (object)DBL_PTR(_int_43265)->dbl;
    }
    _22760 = NOVALUE;

    /** c_decl.e:532					if int = s then*/
    if (_int_43265 != _s_43257)
    goto L1F; // [859] 877

    /** c_decl.e:533						found = TRUE*/
    _found_43262 = _13TRUE_447;

    /** c_decl.e:534						exit*/
    goto L1E; // [874] 888
L1F: 

    /** c_decl.e:536					i += 1*/
    _i_43263 = _i_43263 + 1;

    /** c_decl.e:537				end while*/
    goto L1D; // [885] 834
L1E: 
L12: 

    /** c_decl.e:541			if not found then*/
    if (_found_43262 != 0)
    goto L20; // [891] 907

    /** c_decl.e:543				BB_info = append(BB_info, repeat(0, 6))*/
    _22765 = Repeat(0, 6);
    RefDS(_22765);
    Append(&_58BB_info_42889, _58BB_info_42889, _22765);
    DeRefDS(_22765);
    _22765 = NOVALUE;
L20: 

    /** c_decl.e:546			if t = TYPE_NULL then*/
    if (_t_43258 != 0)
    goto L21; // [911] 949

    /** c_decl.e:547				if not found then*/
    if (_found_43262 != 0)
    goto L22; // [917] 1308

    /** c_decl.e:549					BB_info[i] = dummy_bb*/
    RefDS(_58dummy_bb_43246);
    _2 = (object)SEQ_PTR(_58BB_info_42889);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _58BB_info_42889 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _i_43263);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _58dummy_bb_43246;
    DeRef(_1);

    /** c_decl.e:550					BB_info[i][BB_VAR] = s*/
    _2 = (object)SEQ_PTR(_58BB_info_42889);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _58BB_info_42889 = MAKE_SEQ(_2);
    }
    _3 = (object)(_i_43263 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _s_43257;
    DeRef(_1);
    _22769 = NOVALUE;
    goto L22; // [946] 1308
L21: 

    /** c_decl.e:554				sequence bbi = BB_info[i]*/
    DeRef(_bbi_43482);
    _2 = (object)SEQ_PTR(_58BB_info_42889);
    _bbi_43482 = (object)*(((s1_ptr)_2)->base + _i_43263);
    Ref(_bbi_43482);

    /** c_decl.e:555				BB_info[i] = 0*/
    _2 = (object)SEQ_PTR(_58BB_info_42889);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _58BB_info_42889 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _i_43263);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);

    /** c_decl.e:556				bbi[BB_VAR] = s*/
    _2 = (object)SEQ_PTR(_bbi_43482);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _bbi_43482 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _s_43257;
    DeRef(_1);

    /** c_decl.e:557				bbi[BB_TYPE] = t*/
    _2 = (object)SEQ_PTR(_bbi_43482);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _bbi_43482 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _t_43258;
    DeRef(_1);

    /** c_decl.e:558				bbi[BB_DELETE] = has_delete*/
    _2 = (object)SEQ_PTR(_bbi_43482);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _bbi_43482 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 6);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _has_delete_43261;
    DeRef(_1);

    /** c_decl.e:560				if t = TYPE_SEQUENCE and val[MIN] = -1 then*/
    _22772 = (_t_43258 == 8);
    if (_22772 == 0) {
        goto L23; // [995] 1077
    }
    _2 = (object)SEQ_PTR(_val_43259);
    _22774 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_22774)) {
        _22775 = (_22774 == -1);
    }
    else {
        _22775 = binary_op(EQUALS, _22774, -1);
    }
    _22774 = NOVALUE;
    if (_22775 == 0) {
        DeRef(_22775);
        _22775 = NOVALUE;
        goto L23; // [1010] 1077
    }
    else {
        if (!IS_ATOM_INT(_22775) && DBL_PTR(_22775)->dbl == 0.0){
            DeRef(_22775);
            _22775 = NOVALUE;
            goto L23; // [1010] 1077
        }
        DeRef(_22775);
        _22775 = NOVALUE;
    }
    DeRef(_22775);
    _22775 = NOVALUE;

    /** c_decl.e:562					if found and bbi[BB_ELEM] != TYPE_NULL then*/
    if (_found_43262 == 0) {
        goto L24; // [1015] 1051
    }
    _2 = (object)SEQ_PTR(_bbi_43482);
    _22777 = (object)*(((s1_ptr)_2)->base + 3);
    if (IS_ATOM_INT(_22777)) {
        _22778 = (_22777 != 0);
    }
    else {
        _22778 = binary_op(NOTEQ, _22777, 0);
    }
    _22777 = NOVALUE;
    if (_22778 == 0) {
        DeRef(_22778);
        _22778 = NOVALUE;
        goto L24; // [1030] 1051
    }
    else {
        if (!IS_ATOM_INT(_22778) && DBL_PTR(_22778)->dbl == 0.0){
            DeRef(_22778);
            _22778 = NOVALUE;
            goto L24; // [1030] 1051
        }
        DeRef(_22778);
        _22778 = NOVALUE;
    }
    DeRef(_22778);
    _22778 = NOVALUE;

    /** c_decl.e:564						bbi[BB_ELEM] = or_type(bbi[BB_ELEM], etype)*/
    _2 = (object)SEQ_PTR(_bbi_43482);
    _22779 = (object)*(((s1_ptr)_2)->base + 3);
    Ref(_22779);
    _22780 = _58or_type(_22779, _etype_43260);
    _22779 = NOVALUE;
    _2 = (object)SEQ_PTR(_bbi_43482);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _bbi_43482 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22780;
    if( _1 != _22780 ){
        DeRef(_1);
    }
    _22780 = NOVALUE;
    goto L25; // [1048] 1060
L24: 

    /** c_decl.e:566						bbi[BB_ELEM] = TYPE_NULL*/
    _2 = (object)SEQ_PTR(_bbi_43482);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _bbi_43482 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);
L25: 

    /** c_decl.e:568					if not found then*/
    if (_found_43262 != 0)
    goto L26; // [1062] 1153

    /** c_decl.e:569						bbi[BB_SEQLEN] = NOVALUE*/
    Ref(_36NOVALUE_21621);
    _2 = (object)SEQ_PTR(_bbi_43482);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _bbi_43482 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36NOVALUE_21621;
    DeRef(_1);
    goto L26; // [1074] 1153
L23: 

    /** c_decl.e:572					bbi[BB_ELEM] = etype*/
    _2 = (object)SEQ_PTR(_bbi_43482);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _bbi_43482 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _etype_43260;
    DeRef(_1);

    /** c_decl.e:573					if t = TYPE_SEQUENCE or t = TYPE_OBJECT then*/
    _22782 = (_t_43258 == 8);
    if (_22782 != 0) {
        goto L27; // [1091] 1106
    }
    _22784 = (_t_43258 == 16);
    if (_22784 == 0)
    {
        DeRef(_22784);
        _22784 = NOVALUE;
        goto L28; // [1102] 1145
    }
    else{
        DeRef(_22784);
        _22784 = NOVALUE;
    }
L27: 

    /** c_decl.e:574						if val[MIN] < 0 then*/
    _2 = (object)SEQ_PTR(_val_43259);
    _22785 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(GREATEREQ, _22785, 0)){
        _22785 = NOVALUE;
        goto L29; // [1114] 1129
    }
    _22785 = NOVALUE;

    /** c_decl.e:575							bbi[BB_SEQLEN] = NOVALUE*/
    Ref(_36NOVALUE_21621);
    _2 = (object)SEQ_PTR(_bbi_43482);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _bbi_43482 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36NOVALUE_21621;
    DeRef(_1);
    goto L2A; // [1126] 1152
L29: 

    /** c_decl.e:577							bbi[BB_SEQLEN] = val[MIN]*/
    _2 = (object)SEQ_PTR(_val_43259);
    _22787 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_22787);
    _2 = (object)SEQ_PTR(_bbi_43482);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _bbi_43482 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22787;
    if( _1 != _22787 ){
        DeRef(_1);
    }
    _22787 = NOVALUE;
    goto L2A; // [1142] 1152
L28: 

    /** c_decl.e:580						bbi[BB_OBJ] = val*/
    RefDS(_val_43259);
    _2 = (object)SEQ_PTR(_bbi_43482);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _bbi_43482 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _val_43259;
    DeRef(_1);
L2A: 
L26: 

    /** c_decl.e:583				BB_info[i] = bbi*/
    RefDS(_bbi_43482);
    _2 = (object)SEQ_PTR(_58BB_info_42889);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _58BB_info_42889 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _i_43263);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _bbi_43482;
    DeRef(_1);
    DeRefDS(_bbi_43482);
    _bbi_43482 = NOVALUE;
    goto L22; // [1164] 1308
L3: 

    /** c_decl.e:586		elsif mode = M_CONSTANT then*/
    if (_mode_43271 != 2)
    goto L2B; // [1171] 1307

    /** c_decl.e:587			sym[S_GTYPE] = t*/
    _2 = (object)SEQ_PTR(_sym_43266);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43266 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _t_43258;
    DeRef(_1);

    /** c_decl.e:588			sym[S_SEQ_ELEM] = etype*/
    _2 = (object)SEQ_PTR(_sym_43266);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43266 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _etype_43260;
    DeRef(_1);

    /** c_decl.e:589			if sym[S_GTYPE] = TYPE_SEQUENCE or*/
    _2 = (object)SEQ_PTR(_sym_43266);
    _22789 = (object)*(((s1_ptr)_2)->base + 36);
    if (IS_ATOM_INT(_22789)) {
        _22790 = (_22789 == 8);
    }
    else {
        _22790 = binary_op(EQUALS, _22789, 8);
    }
    _22789 = NOVALUE;
    if (IS_ATOM_INT(_22790)) {
        if (_22790 != 0) {
            goto L2C; // [1205] 1226
        }
    }
    else {
        if (DBL_PTR(_22790)->dbl != 0.0) {
            goto L2C; // [1205] 1226
        }
    }
    _2 = (object)SEQ_PTR(_sym_43266);
    _22792 = (object)*(((s1_ptr)_2)->base + 36);
    if (IS_ATOM_INT(_22792)) {
        _22793 = (_22792 == 16);
    }
    else {
        _22793 = binary_op(EQUALS, _22792, 16);
    }
    _22792 = NOVALUE;
    if (_22793 == 0) {
        DeRef(_22793);
        _22793 = NOVALUE;
        goto L2D; // [1222] 1269
    }
    else {
        if (!IS_ATOM_INT(_22793) && DBL_PTR(_22793)->dbl == 0.0){
            DeRef(_22793);
            _22793 = NOVALUE;
            goto L2D; // [1222] 1269
        }
        DeRef(_22793);
        _22793 = NOVALUE;
    }
    DeRef(_22793);
    _22793 = NOVALUE;
L2C: 

    /** c_decl.e:591				if val[MIN] < 0 then*/
    _2 = (object)SEQ_PTR(_val_43259);
    _22794 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(GREATEREQ, _22794, 0)){
        _22794 = NOVALUE;
        goto L2E; // [1234] 1251
    }
    _22794 = NOVALUE;

    /** c_decl.e:592					sym[S_SEQ_LEN] = NOVALUE*/
    Ref(_36NOVALUE_21621);
    _2 = (object)SEQ_PTR(_sym_43266);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43266 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 32);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36NOVALUE_21621;
    DeRef(_1);
    goto L2F; // [1248] 1298
L2E: 

    /** c_decl.e:594					sym[S_SEQ_LEN] = val[MIN]*/
    _2 = (object)SEQ_PTR(_val_43259);
    _22796 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_22796);
    _2 = (object)SEQ_PTR(_sym_43266);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43266 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 32);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22796;
    if( _1 != _22796 ){
        DeRef(_1);
    }
    _22796 = NOVALUE;
    goto L2F; // [1266] 1298
L2D: 

    /** c_decl.e:597				sym[S_OBJ_MIN] = val[MIN]*/
    _2 = (object)SEQ_PTR(_val_43259);
    _22797 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_22797);
    _2 = (object)SEQ_PTR(_sym_43266);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43266 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 30);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22797;
    if( _1 != _22797 ){
        DeRef(_1);
    }
    _22797 = NOVALUE;

    /** c_decl.e:598				sym[S_OBJ_MAX] = val[MAX]*/
    _2 = (object)SEQ_PTR(_val_43259);
    _22798 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_22798);
    _2 = (object)SEQ_PTR(_sym_43266);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43266 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 31);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22798;
    if( _1 != _22798 ){
        DeRef(_1);
    }
    _22798 = NOVALUE;
L2F: 

    /** c_decl.e:600			sym[S_HAS_DELETE] = has_delete*/
    _2 = (object)SEQ_PTR(_sym_43266);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43266 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 54);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _has_delete_43261;
    DeRef(_1);
L2B: 
L22: 

    /** c_decl.e:603		SymTab[s] = sym*/
    RefDS(_sym_43266);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _s_43257);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _sym_43266;
    DeRef(_1);

    /** c_decl.e:605	end procedure*/
    DeRefDS(_val_43259);
    DeRefDS(_sym_43266);
    DeRef(_22692);
    _22692 = NOVALUE;
    DeRef(_22687);
    _22687 = NOVALUE;
    DeRef(_22772);
    _22772 = NOVALUE;
    DeRef(_22782);
    _22782 = NOVALUE;
    _22706 = NOVALUE;
    _22701 = NOVALUE;
    DeRef(_22790);
    _22790 = NOVALUE;
    return;
    ;
}


void _58CName(object _s_43556)
{
    object _v_43557 = NOVALUE;
    object _mode_43559 = NOVALUE;
    object _22863 = NOVALUE;
    object _22862 = NOVALUE;
    object _22860 = NOVALUE;
    object _22859 = NOVALUE;
    object _22858 = NOVALUE;
    object _22857 = NOVALUE;
    object _22856 = NOVALUE;
    object _22855 = NOVALUE;
    object _22854 = NOVALUE;
    object _22853 = NOVALUE;
    object _22851 = NOVALUE;
    object _22849 = NOVALUE;
    object _22848 = NOVALUE;
    object _22847 = NOVALUE;
    object _22846 = NOVALUE;
    object _22845 = NOVALUE;
    object _22844 = NOVALUE;
    object _22842 = NOVALUE;
    object _22841 = NOVALUE;
    object _22840 = NOVALUE;
    object _22839 = NOVALUE;
    object _22838 = NOVALUE;
    object _22836 = NOVALUE;
    object _22835 = NOVALUE;
    object _22834 = NOVALUE;
    object _22833 = NOVALUE;
    object _22832 = NOVALUE;
    object _22831 = NOVALUE;
    object _22829 = NOVALUE;
    object _22828 = NOVALUE;
    object _22826 = NOVALUE;
    object _22825 = NOVALUE;
    object _22824 = NOVALUE;
    object _22823 = NOVALUE;
    object _22822 = NOVALUE;
    object _22821 = NOVALUE;
    object _22820 = NOVALUE;
    object _22819 = NOVALUE;
    object _22818 = NOVALUE;
    object _22817 = NOVALUE;
    object _22816 = NOVALUE;
    object _22815 = NOVALUE;
    object _22813 = NOVALUE;
    object _22812 = NOVALUE;
    object _22808 = NOVALUE;
    object _22807 = NOVALUE;
    object _22806 = NOVALUE;
    object _22805 = NOVALUE;
    object _22804 = NOVALUE;
    object _22803 = NOVALUE;
    object _22800 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_s_43556)) {
        _1 = (object)(DBL_PTR(_s_43556)->dbl);
        DeRefDS(_s_43556);
        _s_43556 = _1;
    }

    /** c_decl.e:612		v = ObjValue(s)*/
    _0 = _v_43557;
    _v_43557 = _58ObjValue(_s_43556);
    DeRef(_0);

    /** c_decl.e:613		integer mode = SymTab[s][S_MODE]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _22800 = (object)*(((s1_ptr)_2)->base + _s_43556);
    _2 = (object)SEQ_PTR(_22800);
    _mode_43559 = (object)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_mode_43559)){
        _mode_43559 = (object)DBL_PTR(_mode_43559)->dbl;
    }
    _22800 = NOVALUE;

    /** c_decl.e:614	 	if mode = M_NORMAL then*/
    if (_mode_43559 != 1)
    goto L1; // [29] 254

    /** c_decl.e:617			if LeftSym = FALSE and GType(s) = TYPE_INTEGER and v != NOVALUE then*/
    _22803 = (_58LeftSym_42890 == _13FALSE_445);
    if (_22803 == 0) {
        _22804 = 0;
        goto L2; // [43] 61
    }
    _22805 = _58GType(_s_43556);
    if (IS_ATOM_INT(_22805)) {
        _22806 = (_22805 == 1);
    }
    else {
        _22806 = binary_op(EQUALS, _22805, 1);
    }
    DeRef(_22805);
    _22805 = NOVALUE;
    if (IS_ATOM_INT(_22806))
    _22804 = (_22806 != 0);
    else
    _22804 = DBL_PTR(_22806)->dbl != 0.0;
L2: 
    if (_22804 == 0) {
        goto L3; // [61] 98
    }
    if (IS_ATOM_INT(_v_43557) && IS_ATOM_INT(_36NOVALUE_21621)) {
        _22808 = (_v_43557 != _36NOVALUE_21621);
    }
    else {
        _22808 = binary_op(NOTEQ, _v_43557, _36NOVALUE_21621);
    }
    if (_22808 == 0) {
        DeRef(_22808);
        _22808 = NOVALUE;
        goto L3; // [72] 98
    }
    else {
        if (!IS_ATOM_INT(_22808) && DBL_PTR(_22808)->dbl == 0.0){
            DeRef(_22808);
            _22808 = NOVALUE;
            goto L3; // [72] 98
        }
        DeRef(_22808);
        _22808 = NOVALUE;
    }
    DeRef(_22808);
    _22808 = NOVALUE;

    /** c_decl.e:618				c_printf("%d", v)*/
    RefDS(_22809);
    Ref(_v_43557);
    _55c_printf(_22809, _v_43557);

    /** c_decl.e:619				if TARGET_SIZEOF_POINTER = 8 then*/
    if (_36TARGET_SIZEOF_POINTER_21589 != 8)
    goto L4; // [85] 180

    /** c_decl.e:620					c_puts( "LL" )*/
    RefDS(_22811);
    _55c_puts(_22811);
    goto L4; // [95] 180
L3: 

    /** c_decl.e:623				if SymTab[s][S_SCOPE] > SC_PRIVATE then*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _22812 = (object)*(((s1_ptr)_2)->base + _s_43556);
    _2 = (object)SEQ_PTR(_22812);
    _22813 = (object)*(((s1_ptr)_2)->base + 4);
    _22812 = NOVALUE;
    if (binary_op_a(LESSEQ, _22813, 3)){
        _22813 = NOVALUE;
        goto L5; // [114] 156
    }
    _22813 = NOVALUE;

    /** c_decl.e:624					c_printf("_%d", SymTab[s][S_FILE_NO])*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _22815 = (object)*(((s1_ptr)_2)->base + _s_43556);
    _2 = (object)SEQ_PTR(_22815);
    if (!IS_ATOM_INT(_36S_FILE_NO_21400)){
        _22816 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21400)->dbl));
    }
    else{
        _22816 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21400);
    }
    _22815 = NOVALUE;
    RefDS(_22313);
    Ref(_22816);
    _55c_printf(_22313, _22816);
    _22816 = NOVALUE;

    /** c_decl.e:625					c_puts(SymTab[s][S_NAME])*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _22817 = (object)*(((s1_ptr)_2)->base + _s_43556);
    _2 = (object)SEQ_PTR(_22817);
    if (!IS_ATOM_INT(_36S_NAME_21404)){
        _22818 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21404)->dbl));
    }
    else{
        _22818 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21404);
    }
    _22817 = NOVALUE;
    Ref(_22818);
    _55c_puts(_22818);
    _22818 = NOVALUE;
    goto L6; // [153] 179
L5: 

    /** c_decl.e:627					c_puts("_")*/
    RefDS(_22262);
    _55c_puts(_22262);

    /** c_decl.e:628					c_puts(SymTab[s][S_NAME])*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _22819 = (object)*(((s1_ptr)_2)->base + _s_43556);
    _2 = (object)SEQ_PTR(_22819);
    if (!IS_ATOM_INT(_36S_NAME_21404)){
        _22820 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21404)->dbl));
    }
    else{
        _22820 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21404);
    }
    _22819 = NOVALUE;
    Ref(_22820);
    _55c_puts(_22820);
    _22820 = NOVALUE;
L6: 
L4: 

    /** c_decl.e:631			if s != CurrentSub and SymTab[s][S_NREFS] < 2 then*/
    _22821 = (_s_43556 != _36CurrentSub_21775);
    if (_22821 == 0) {
        goto L7; // [188] 236
    }
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _22823 = (object)*(((s1_ptr)_2)->base + _s_43556);
    _2 = (object)SEQ_PTR(_22823);
    _22824 = (object)*(((s1_ptr)_2)->base + 12);
    _22823 = NOVALUE;
    if (IS_ATOM_INT(_22824)) {
        _22825 = (_22824 < 2);
    }
    else {
        _22825 = binary_op(LESS, _22824, 2);
    }
    _22824 = NOVALUE;
    if (_22825 == 0) {
        DeRef(_22825);
        _22825 = NOVALUE;
        goto L7; // [209] 236
    }
    else {
        if (!IS_ATOM_INT(_22825) && DBL_PTR(_22825)->dbl == 0.0){
            DeRef(_22825);
            _22825 = NOVALUE;
            goto L7; // [209] 236
        }
        DeRef(_22825);
        _22825 = NOVALUE;
    }
    DeRef(_22825);
    _22825 = NOVALUE;

    /** c_decl.e:632				SymTab[s][S_NREFS] += 1*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_s_43556 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _22828 = (object)*(((s1_ptr)_2)->base + 12);
    _22826 = NOVALUE;
    if (IS_ATOM_INT(_22828)) {
        _22829 = _22828 + 1;
        if (_22829 > MAXINT){
            _22829 = NewDouble((eudouble)_22829);
        }
    }
    else
    _22829 = binary_op(PLUS, 1, _22828);
    _22828 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22829;
    if( _1 != _22829 ){
        DeRef(_1);
    }
    _22829 = NOVALUE;
    _22826 = NOVALUE;
L7: 

    /** c_decl.e:634			SetBBType(s, TYPE_NULL, novalue, TYPE_OBJECT, 0) -- record that this var was referenced in this BB*/
    RefDS(_55novalue_46980);
    _58SetBBType(_s_43556, 0, _55novalue_46980, 16, 0);
    goto L8; // [251] 533
L1: 

    /** c_decl.e:636	 	elsif mode = M_CONSTANT then*/
    if (_mode_43559 != 2)
    goto L9; // [258] 448

    /** c_decl.e:638			if (is_integer( sym_obj( s ) ) and SymTab[s][S_GTYPE] != TYPE_DOUBLE ) or (LeftSym = FALSE and TypeIs(s, TYPE_INTEGER) and v != NOVALUE) then*/
    _22831 = _54sym_obj(_s_43556);
    _22832 = _36is_integer(_22831);
    _22831 = NOVALUE;
    if (IS_ATOM_INT(_22832)) {
        if (_22832 == 0) {
            DeRef(_22833);
            _22833 = 0;
            goto LA; // [272] 298
        }
    }
    else {
        if (DBL_PTR(_22832)->dbl == 0.0) {
            DeRef(_22833);
            _22833 = 0;
            goto LA; // [272] 298
        }
    }
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _22834 = (object)*(((s1_ptr)_2)->base + _s_43556);
    _2 = (object)SEQ_PTR(_22834);
    _22835 = (object)*(((s1_ptr)_2)->base + 36);
    _22834 = NOVALUE;
    if (IS_ATOM_INT(_22835)) {
        _22836 = (_22835 != 2);
    }
    else {
        _22836 = binary_op(NOTEQ, _22835, 2);
    }
    _22835 = NOVALUE;
    DeRef(_22833);
    if (IS_ATOM_INT(_22836))
    _22833 = (_22836 != 0);
    else
    _22833 = DBL_PTR(_22836)->dbl != 0.0;
LA: 
    if (_22833 != 0) {
        goto LB; // [298] 344
    }
    _22838 = (_58LeftSym_42890 == _13FALSE_445);
    if (_22838 == 0) {
        _22839 = 0;
        goto LC; // [310] 325
    }
    _22840 = _58TypeIs(_s_43556, 1);
    if (IS_ATOM_INT(_22840))
    _22839 = (_22840 != 0);
    else
    _22839 = DBL_PTR(_22840)->dbl != 0.0;
LC: 
    if (_22839 == 0) {
        DeRef(_22841);
        _22841 = 0;
        goto LD; // [325] 339
    }
    if (IS_ATOM_INT(_v_43557) && IS_ATOM_INT(_36NOVALUE_21621)) {
        _22842 = (_v_43557 != _36NOVALUE_21621);
    }
    else {
        _22842 = binary_op(NOTEQ, _v_43557, _36NOVALUE_21621);
    }
    if (IS_ATOM_INT(_22842))
    _22841 = (_22842 != 0);
    else
    _22841 = DBL_PTR(_22842)->dbl != 0.0;
LD: 
    if (_22841 == 0)
    {
        _22841 = NOVALUE;
        goto LE; // [340] 367
    }
    else{
        _22841 = NOVALUE;
    }
LB: 

    /** c_decl.e:641				c_printf("%d", v)*/
    RefDS(_22809);
    Ref(_v_43557);
    _55c_printf(_22809, _v_43557);

    /** c_decl.e:642				if TARGET_SIZEOF_POINTER = 8 then*/
    if (_36TARGET_SIZEOF_POINTER_21589 != 8)
    goto L8; // [354] 533

    /** c_decl.e:643					c_puts( "LL" )*/
    RefDS(_22811);
    _55c_puts(_22811);
    goto L8; // [364] 533
LE: 

    /** c_decl.e:647				c_printf("_%d", SymTab[s][S_FILE_NO])*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _22844 = (object)*(((s1_ptr)_2)->base + _s_43556);
    _2 = (object)SEQ_PTR(_22844);
    if (!IS_ATOM_INT(_36S_FILE_NO_21400)){
        _22845 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21400)->dbl));
    }
    else{
        _22845 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21400);
    }
    _22844 = NOVALUE;
    RefDS(_22313);
    Ref(_22845);
    _55c_printf(_22313, _22845);
    _22845 = NOVALUE;

    /** c_decl.e:648				c_puts(SymTab[s][S_NAME])*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _22846 = (object)*(((s1_ptr)_2)->base + _s_43556);
    _2 = (object)SEQ_PTR(_22846);
    if (!IS_ATOM_INT(_36S_NAME_21404)){
        _22847 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21404)->dbl));
    }
    else{
        _22847 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21404);
    }
    _22846 = NOVALUE;
    Ref(_22847);
    _55c_puts(_22847);
    _22847 = NOVALUE;

    /** c_decl.e:649				if SymTab[s][S_NREFS] < 2 then*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _22848 = (object)*(((s1_ptr)_2)->base + _s_43556);
    _2 = (object)SEQ_PTR(_22848);
    _22849 = (object)*(((s1_ptr)_2)->base + 12);
    _22848 = NOVALUE;
    if (binary_op_a(GREATEREQ, _22849, 2)){
        _22849 = NOVALUE;
        goto L8; // [416] 533
    }
    _22849 = NOVALUE;

    /** c_decl.e:650					SymTab[s][S_NREFS] += 1*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_s_43556 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _22853 = (object)*(((s1_ptr)_2)->base + 12);
    _22851 = NOVALUE;
    if (IS_ATOM_INT(_22853)) {
        _22854 = _22853 + 1;
        if (_22854 > MAXINT){
            _22854 = NewDouble((eudouble)_22854);
        }
    }
    else
    _22854 = binary_op(PLUS, 1, _22853);
    _22853 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22854;
    if( _1 != _22854 ){
        DeRef(_1);
    }
    _22854 = NOVALUE;
    _22851 = NOVALUE;
    goto L8; // [445] 533
L9: 

    /** c_decl.e:656			if LeftSym = FALSE and GType(s) = TYPE_INTEGER and v != NOVALUE then*/
    _22855 = (_58LeftSym_42890 == _13FALSE_445);
    if (_22855 == 0) {
        _22856 = 0;
        goto LF; // [458] 476
    }
    _22857 = _58GType(_s_43556);
    if (IS_ATOM_INT(_22857)) {
        _22858 = (_22857 == 1);
    }
    else {
        _22858 = binary_op(EQUALS, _22857, 1);
    }
    DeRef(_22857);
    _22857 = NOVALUE;
    if (IS_ATOM_INT(_22858))
    _22856 = (_22858 != 0);
    else
    _22856 = DBL_PTR(_22858)->dbl != 0.0;
LF: 
    if (_22856 == 0) {
        goto L10; // [476] 513
    }
    if (IS_ATOM_INT(_v_43557) && IS_ATOM_INT(_36NOVALUE_21621)) {
        _22860 = (_v_43557 != _36NOVALUE_21621);
    }
    else {
        _22860 = binary_op(NOTEQ, _v_43557, _36NOVALUE_21621);
    }
    if (_22860 == 0) {
        DeRef(_22860);
        _22860 = NOVALUE;
        goto L10; // [487] 513
    }
    else {
        if (!IS_ATOM_INT(_22860) && DBL_PTR(_22860)->dbl == 0.0){
            DeRef(_22860);
            _22860 = NOVALUE;
            goto L10; // [487] 513
        }
        DeRef(_22860);
        _22860 = NOVALUE;
    }
    DeRef(_22860);
    _22860 = NOVALUE;

    /** c_decl.e:657				c_printf("%d", v)*/
    RefDS(_22809);
    Ref(_v_43557);
    _55c_printf(_22809, _v_43557);

    /** c_decl.e:658				if TARGET_SIZEOF_POINTER = 8 then*/
    if (_36TARGET_SIZEOF_POINTER_21589 != 8)
    goto L11; // [500] 532

    /** c_decl.e:659					c_puts( "LL" )*/
    RefDS(_22811);
    _55c_puts(_22811);
    goto L11; // [510] 532
L10: 

    /** c_decl.e:662				c_printf("_%d", SymTab[s][S_TEMP_NAME])*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _22862 = (object)*(((s1_ptr)_2)->base + _s_43556);
    _2 = (object)SEQ_PTR(_22862);
    _22863 = (object)*(((s1_ptr)_2)->base + 34);
    _22862 = NOVALUE;
    RefDS(_22313);
    Ref(_22863);
    _55c_printf(_22313, _22863);
    _22863 = NOVALUE;
L11: 
L8: 

    /** c_decl.e:666		LeftSym = FALSE*/
    _58LeftSym_42890 = _13FALSE_445;

    /** c_decl.e:667	end procedure*/
    DeRef(_v_43557);
    DeRef(_22832);
    _22832 = NOVALUE;
    DeRef(_22821);
    _22821 = NOVALUE;
    DeRef(_22838);
    _22838 = NOVALUE;
    DeRef(_22806);
    _22806 = NOVALUE;
    DeRef(_22836);
    _22836 = NOVALUE;
    DeRef(_22840);
    _22840 = NOVALUE;
    DeRef(_22858);
    _22858 = NOVALUE;
    DeRef(_22855);
    _22855 = NOVALUE;
    DeRef(_22803);
    _22803 = NOVALUE;
    DeRef(_22842);
    _22842 = NOVALUE;
    return;
    ;
}


void _58c_stmt(object _stmt_43704, object _arg_43705, object _lhs_arg_43707)
{
    object _argcount_43708 = NOVALUE;
    object _i_43709 = NOVALUE;
    object _22918 = NOVALUE;
    object _22917 = NOVALUE;
    object _22916 = NOVALUE;
    object _22915 = NOVALUE;
    object _22914 = NOVALUE;
    object _22913 = NOVALUE;
    object _22912 = NOVALUE;
    object _22911 = NOVALUE;
    object _22910 = NOVALUE;
    object _22909 = NOVALUE;
    object _22908 = NOVALUE;
    object _22907 = NOVALUE;
    object _22906 = NOVALUE;
    object _22905 = NOVALUE;
    object _22904 = NOVALUE;
    object _22903 = NOVALUE;
    object _22902 = NOVALUE;
    object _22900 = NOVALUE;
    object _22898 = NOVALUE;
    object _22896 = NOVALUE;
    object _22895 = NOVALUE;
    object _22894 = NOVALUE;
    object _22893 = NOVALUE;
    object _22891 = NOVALUE;
    object _22890 = NOVALUE;
    object _22889 = NOVALUE;
    object _22888 = NOVALUE;
    object _22887 = NOVALUE;
    object _22886 = NOVALUE;
    object _22885 = NOVALUE;
    object _22884 = NOVALUE;
    object _22883 = NOVALUE;
    object _22882 = NOVALUE;
    object _22881 = NOVALUE;
    object _22880 = NOVALUE;
    object _22879 = NOVALUE;
    object _22878 = NOVALUE;
    object _22875 = NOVALUE;
    object _22874 = NOVALUE;
    object _22873 = NOVALUE;
    object _22872 = NOVALUE;
    object _22871 = NOVALUE;
    object _22870 = NOVALUE;
    object _22868 = NOVALUE;
    object _22866 = NOVALUE;
    object _22865 = NOVALUE;
    object _22864 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_lhs_arg_43707)) {
        _1 = (object)(DBL_PTR(_lhs_arg_43707)->dbl);
        DeRefDS(_lhs_arg_43707);
        _lhs_arg_43707 = _1;
    }

    /** c_decl.e:675		if LAST_PASS = TRUE and Initializing = FALSE then*/
    _22864 = (_58LAST_PASS_42880 == _13TRUE_447);
    if (_22864 == 0) {
        goto L1; // [15] 47
    }
    _22866 = (_36Initializing_21851 == _13FALSE_445);
    if (_22866 == 0)
    {
        DeRef(_22866);
        _22866 = NOVALUE;
        goto L1; // [28] 47
    }
    else{
        DeRef(_22866);
        _22866 = NOVALUE;
    }

    /** c_decl.e:676			cfile_size += 1*/
    _36cfile_size_21850 = _36cfile_size_21850 + 1;

    /** c_decl.e:677			update_checksum( stmt )*/
    RefDS(_stmt_43704);
    _56update_checksum(_stmt_43704);
L1: 

    /** c_decl.e:681		if emit_c_output then*/
    if (_55emit_c_output_46973 == 0)
    {
        goto L2; // [51] 60
    }
    else{
    }

    /** c_decl.e:682			adjust_indent_before(stmt)*/
    RefDS(_stmt_43704);
    _55adjust_indent_before(_stmt_43704);
L2: 

    /** c_decl.e:685		if atom(arg) then*/
    _22868 = IS_ATOM(_arg_43705);
    if (_22868 == 0)
    {
        _22868 = NOVALUE;
        goto L3; // [65] 75
    }
    else{
        _22868 = NOVALUE;
    }

    /** c_decl.e:686			arg = {arg}*/
    _0 = _arg_43705;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_arg_43705);
    ((intptr_t*)_2)[1] = _arg_43705;
    _arg_43705 = MAKE_SEQ(_1);
    DeRef(_0);
L3: 

    /** c_decl.e:689		argcount = 1*/
    _argcount_43708 = 1;

    /** c_decl.e:690		i = 1*/
    _i_43709 = 1;

    /** c_decl.e:691		while i <= length(stmt) and length(stmt) > 0 do*/
L4: 
    if (IS_SEQUENCE(_stmt_43704)){
            _22870 = SEQ_PTR(_stmt_43704)->length;
    }
    else {
        _22870 = 1;
    }
    _22871 = (_i_43709 <= _22870);
    _22870 = NOVALUE;
    if (_22871 == 0) {
        goto L5; // [97] 435
    }
    if (IS_SEQUENCE(_stmt_43704)){
            _22873 = SEQ_PTR(_stmt_43704)->length;
    }
    else {
        _22873 = 1;
    }
    _22874 = (_22873 > 0);
    _22873 = NOVALUE;
    if (_22874 == 0)
    {
        DeRef(_22874);
        _22874 = NOVALUE;
        goto L5; // [109] 435
    }
    else{
        DeRef(_22874);
        _22874 = NOVALUE;
    }

    /** c_decl.e:692			if stmt[i] = '@' then*/
    _2 = (object)SEQ_PTR(_stmt_43704);
    _22875 = (object)*(((s1_ptr)_2)->base + _i_43709);
    if (binary_op_a(NOTEQ, _22875, 64)){
        _22875 = NOVALUE;
        goto L6; // [118] 288
    }
    _22875 = NOVALUE;

    /** c_decl.e:694				if i = 1 then*/
    if (_i_43709 != 1)
    goto L7; // [124] 138

    /** c_decl.e:695					LeftSym = TRUE*/
    _58LeftSym_42890 = _13TRUE_447;
L7: 

    /** c_decl.e:698				if i < length(stmt) and stmt[i+1] > '0' and stmt[i+1] <= '9' then*/
    if (IS_SEQUENCE(_stmt_43704)){
            _22878 = SEQ_PTR(_stmt_43704)->length;
    }
    else {
        _22878 = 1;
    }
    _22879 = (_i_43709 < _22878);
    _22878 = NOVALUE;
    if (_22879 == 0) {
        _22880 = 0;
        goto L8; // [147] 167
    }
    _22881 = _i_43709 + 1;
    _2 = (object)SEQ_PTR(_stmt_43704);
    _22882 = (object)*(((s1_ptr)_2)->base + _22881);
    if (IS_ATOM_INT(_22882)) {
        _22883 = (_22882 > 48);
    }
    else {
        _22883 = binary_op(GREATER, _22882, 48);
    }
    _22882 = NOVALUE;
    if (IS_ATOM_INT(_22883))
    _22880 = (_22883 != 0);
    else
    _22880 = DBL_PTR(_22883)->dbl != 0.0;
L8: 
    if (_22880 == 0) {
        goto L9; // [167] 249
    }
    _22885 = _i_43709 + 1;
    _2 = (object)SEQ_PTR(_stmt_43704);
    _22886 = (object)*(((s1_ptr)_2)->base + _22885);
    if (IS_ATOM_INT(_22886)) {
        _22887 = (_22886 <= 57);
    }
    else {
        _22887 = binary_op(LESSEQ, _22886, 57);
    }
    _22886 = NOVALUE;
    if (_22887 == 0) {
        DeRef(_22887);
        _22887 = NOVALUE;
        goto L9; // [184] 249
    }
    else {
        if (!IS_ATOM_INT(_22887) && DBL_PTR(_22887)->dbl == 0.0){
            DeRef(_22887);
            _22887 = NOVALUE;
            goto L9; // [184] 249
        }
        DeRef(_22887);
        _22887 = NOVALUE;
    }
    DeRef(_22887);
    _22887 = NOVALUE;

    /** c_decl.e:700					if arg[stmt[i+1]-'0'] = lhs_arg then*/
    _22888 = _i_43709 + 1;
    _2 = (object)SEQ_PTR(_stmt_43704);
    _22889 = (object)*(((s1_ptr)_2)->base + _22888);
    if (IS_ATOM_INT(_22889)) {
        _22890 = _22889 - 48;
    }
    else {
        _22890 = binary_op(MINUS, _22889, 48);
    }
    _22889 = NOVALUE;
    _2 = (object)SEQ_PTR(_arg_43705);
    if (!IS_ATOM_INT(_22890)){
        _22891 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_22890)->dbl));
    }
    else{
        _22891 = (object)*(((s1_ptr)_2)->base + _22890);
    }
    if (binary_op_a(NOTEQ, _22891, _lhs_arg_43707)){
        _22891 = NOVALUE;
        goto LA; // [205] 219
    }
    _22891 = NOVALUE;

    /** c_decl.e:701						LeftSym = TRUE*/
    _58LeftSym_42890 = _13TRUE_447;
LA: 

    /** c_decl.e:703					CName(arg[stmt[i+1]-'0'])*/
    _22893 = _i_43709 + 1;
    _2 = (object)SEQ_PTR(_stmt_43704);
    _22894 = (object)*(((s1_ptr)_2)->base + _22893);
    if (IS_ATOM_INT(_22894)) {
        _22895 = _22894 - 48;
    }
    else {
        _22895 = binary_op(MINUS, _22894, 48);
    }
    _22894 = NOVALUE;
    _2 = (object)SEQ_PTR(_arg_43705);
    if (!IS_ATOM_INT(_22895)){
        _22896 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_22895)->dbl));
    }
    else{
        _22896 = (object)*(((s1_ptr)_2)->base + _22895);
    }
    Ref(_22896);
    _58CName(_22896);
    _22896 = NOVALUE;

    /** c_decl.e:704					i += 1*/
    _i_43709 = _i_43709 + 1;
    goto LB; // [246] 279
L9: 

    /** c_decl.e:708					if arg[argcount] = lhs_arg then*/
    _2 = (object)SEQ_PTR(_arg_43705);
    _22898 = (object)*(((s1_ptr)_2)->base + _argcount_43708);
    if (binary_op_a(NOTEQ, _22898, _lhs_arg_43707)){
        _22898 = NOVALUE;
        goto LC; // [255] 269
    }
    _22898 = NOVALUE;

    /** c_decl.e:709						LeftSym = TRUE*/
    _58LeftSym_42890 = _13TRUE_447;
LC: 

    /** c_decl.e:711					CName(arg[argcount])*/
    _2 = (object)SEQ_PTR(_arg_43705);
    _22900 = (object)*(((s1_ptr)_2)->base + _argcount_43708);
    Ref(_22900);
    _58CName(_22900);
    _22900 = NOVALUE;
LB: 

    /** c_decl.e:714				argcount += 1*/
    _argcount_43708 = _argcount_43708 + 1;
    goto LD; // [285] 353
L6: 

    /** c_decl.e:717				c_putc(stmt[i])*/
    _2 = (object)SEQ_PTR(_stmt_43704);
    _22902 = (object)*(((s1_ptr)_2)->base + _i_43709);
    Ref(_22902);
    _55c_putc(_22902);
    _22902 = NOVALUE;

    /** c_decl.e:718				if stmt[i] = '&' and i < length(stmt) and stmt[i+1] = '@' then*/
    _2 = (object)SEQ_PTR(_stmt_43704);
    _22903 = (object)*(((s1_ptr)_2)->base + _i_43709);
    if (IS_ATOM_INT(_22903)) {
        _22904 = (_22903 == 38);
    }
    else {
        _22904 = binary_op(EQUALS, _22903, 38);
    }
    _22903 = NOVALUE;
    if (IS_ATOM_INT(_22904)) {
        if (_22904 == 0) {
            DeRef(_22905);
            _22905 = 0;
            goto LE; // [307] 322
        }
    }
    else {
        if (DBL_PTR(_22904)->dbl == 0.0) {
            DeRef(_22905);
            _22905 = 0;
            goto LE; // [307] 322
        }
    }
    if (IS_SEQUENCE(_stmt_43704)){
            _22906 = SEQ_PTR(_stmt_43704)->length;
    }
    else {
        _22906 = 1;
    }
    _22907 = (_i_43709 < _22906);
    _22906 = NOVALUE;
    DeRef(_22905);
    _22905 = (_22907 != 0);
LE: 
    if (_22905 == 0) {
        goto LF; // [322] 352
    }
    _22909 = _i_43709 + 1;
    _2 = (object)SEQ_PTR(_stmt_43704);
    _22910 = (object)*(((s1_ptr)_2)->base + _22909);
    if (IS_ATOM_INT(_22910)) {
        _22911 = (_22910 == 64);
    }
    else {
        _22911 = binary_op(EQUALS, _22910, 64);
    }
    _22910 = NOVALUE;
    if (_22911 == 0) {
        DeRef(_22911);
        _22911 = NOVALUE;
        goto LF; // [339] 352
    }
    else {
        if (!IS_ATOM_INT(_22911) && DBL_PTR(_22911)->dbl == 0.0){
            DeRef(_22911);
            _22911 = NOVALUE;
            goto LF; // [339] 352
        }
        DeRef(_22911);
        _22911 = NOVALUE;
    }
    DeRef(_22911);
    _22911 = NOVALUE;

    /** c_decl.e:719					LeftSym = TRUE -- never say: x = x &y or andy - always leave space*/
    _58LeftSym_42890 = _13TRUE_447;
LF: 
LD: 

    /** c_decl.e:723			if stmt[i] = '\n' and i < length(stmt) then*/
    _2 = (object)SEQ_PTR(_stmt_43704);
    _22912 = (object)*(((s1_ptr)_2)->base + _i_43709);
    if (IS_ATOM_INT(_22912)) {
        _22913 = (_22912 == 10);
    }
    else {
        _22913 = binary_op(EQUALS, _22912, 10);
    }
    _22912 = NOVALUE;
    if (IS_ATOM_INT(_22913)) {
        if (_22913 == 0) {
            goto L10; // [363] 424
        }
    }
    else {
        if (DBL_PTR(_22913)->dbl == 0.0) {
            goto L10; // [363] 424
        }
    }
    if (IS_SEQUENCE(_stmt_43704)){
            _22915 = SEQ_PTR(_stmt_43704)->length;
    }
    else {
        _22915 = 1;
    }
    _22916 = (_i_43709 < _22915);
    _22915 = NOVALUE;
    if (_22916 == 0)
    {
        DeRef(_22916);
        _22916 = NOVALUE;
        goto L10; // [375] 424
    }
    else{
        DeRef(_22916);
        _22916 = NOVALUE;
    }

    /** c_decl.e:724				if emit_c_output then*/
    if (_55emit_c_output_46973 == 0)
    {
        goto L11; // [382] 391
    }
    else{
    }

    /** c_decl.e:725					adjust_indent_after(stmt)*/
    RefDS(_stmt_43704);
    _55adjust_indent_after(_stmt_43704);
L11: 

    /** c_decl.e:727				stmt = stmt[i+1..$]*/
    _22917 = _i_43709 + 1;
    if (_22917 > MAXINT){
        _22917 = NewDouble((eudouble)_22917);
    }
    if (IS_SEQUENCE(_stmt_43704)){
            _22918 = SEQ_PTR(_stmt_43704)->length;
    }
    else {
        _22918 = 1;
    }
    rhs_slice_target = (object_ptr)&_stmt_43704;
    RHS_Slice(_stmt_43704, _22917, _22918);

    /** c_decl.e:728				i = 0*/
    _i_43709 = 0;

    /** c_decl.e:729				if emit_c_output then*/
    if (_55emit_c_output_46973 == 0)
    {
        goto L12; // [414] 423
    }
    else{
    }

    /** c_decl.e:730					adjust_indent_before(stmt)*/
    RefDS(_stmt_43704);
    _55adjust_indent_before(_stmt_43704);
L12: 
L10: 

    /** c_decl.e:734			i += 1*/
    _i_43709 = _i_43709 + 1;

    /** c_decl.e:735		end while*/
    goto L4; // [432] 90
L5: 

    /** c_decl.e:737		if emit_c_output then*/
    if (_55emit_c_output_46973 == 0)
    {
        goto L13; // [439] 448
    }
    else{
    }

    /** c_decl.e:738			adjust_indent_after(stmt)*/
    RefDS(_stmt_43704);
    _55adjust_indent_after(_stmt_43704);
L13: 

    /** c_decl.e:740	end procedure*/
    DeRefDS(_stmt_43704);
    DeRef(_arg_43705);
    DeRef(_22895);
    _22895 = NOVALUE;
    DeRef(_22888);
    _22888 = NOVALUE;
    DeRef(_22917);
    _22917 = NOVALUE;
    DeRef(_22883);
    _22883 = NOVALUE;
    DeRef(_22890);
    _22890 = NOVALUE;
    DeRef(_22893);
    _22893 = NOVALUE;
    DeRef(_22885);
    _22885 = NOVALUE;
    DeRef(_22864);
    _22864 = NOVALUE;
    DeRef(_22913);
    _22913 = NOVALUE;
    DeRef(_22907);
    _22907 = NOVALUE;
    DeRef(_22909);
    _22909 = NOVALUE;
    DeRef(_22904);
    _22904 = NOVALUE;
    DeRef(_22871);
    _22871 = NOVALUE;
    DeRef(_22879);
    _22879 = NOVALUE;
    DeRef(_22881);
    _22881 = NOVALUE;
    return;
    ;
}


void _58c_stmt0(object _stmt_43803)
{
    object _0, _1, _2;
    

    /** c_decl.e:745		if emit_c_output then*/
    if (_55emit_c_output_46973 == 0)
    {
        goto L1; // [7] 18
    }
    else{
    }

    /** c_decl.e:746			c_stmt(stmt, {})*/
    RefDS(_stmt_43803);
    RefDS(_22190);
    _58c_stmt(_stmt_43803, _22190, 0);
L1: 

    /** c_decl.e:748	end procedure*/
    DeRefDS(_stmt_43803);
    return;
    ;
}


object _58needs_uninit(object _eentry_43808)
{
    object _22941 = NOVALUE;
    object _22940 = NOVALUE;
    object _22939 = NOVALUE;
    object _22938 = NOVALUE;
    object _22937 = NOVALUE;
    object _22936 = NOVALUE;
    object _22935 = NOVALUE;
    object _22934 = NOVALUE;
    object _22933 = NOVALUE;
    object _22932 = NOVALUE;
    object _22931 = NOVALUE;
    object _22930 = NOVALUE;
    object _22929 = NOVALUE;
    object _22928 = NOVALUE;
    object _22927 = NOVALUE;
    object _22926 = NOVALUE;
    object _22925 = NOVALUE;
    object _22924 = NOVALUE;
    object _22923 = NOVALUE;
    object _22922 = NOVALUE;
    object _22921 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:751		if eentry[S_SCOPE] >= SC_LOCAL*/
    _2 = (object)SEQ_PTR(_eentry_43808);
    _22921 = (object)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_22921)) {
        _22922 = (_22921 >= 5);
    }
    else {
        _22922 = binary_op(GREATEREQ, _22921, 5);
    }
    _22921 = NOVALUE;
    if (IS_ATOM_INT(_22922)) {
        if (_22922 == 0) {
            _22923 = 0;
            goto L1; // [17] 77
        }
    }
    else {
        if (DBL_PTR(_22922)->dbl == 0.0) {
            _22923 = 0;
            goto L1; // [17] 77
        }
    }
    _2 = (object)SEQ_PTR(_eentry_43808);
    _22924 = (object)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_22924)) {
        _22925 = (_22924 <= 6);
    }
    else {
        _22925 = binary_op(LESSEQ, _22924, 6);
    }
    _22924 = NOVALUE;
    if (IS_ATOM_INT(_22925)) {
        if (_22925 != 0) {
            _22926 = 1;
            goto L2; // [33] 53
        }
    }
    else {
        if (DBL_PTR(_22925)->dbl != 0.0) {
            _22926 = 1;
            goto L2; // [33] 53
        }
    }
    _2 = (object)SEQ_PTR(_eentry_43808);
    _22927 = (object)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_22927)) {
        _22928 = (_22927 == 11);
    }
    else {
        _22928 = binary_op(EQUALS, _22927, 11);
    }
    _22927 = NOVALUE;
    DeRef(_22926);
    if (IS_ATOM_INT(_22928))
    _22926 = (_22928 != 0);
    else
    _22926 = DBL_PTR(_22928)->dbl != 0.0;
L2: 
    if (_22926 != 0) {
        _22929 = 1;
        goto L3; // [53] 73
    }
    _2 = (object)SEQ_PTR(_eentry_43808);
    _22930 = (object)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_22930)) {
        _22931 = (_22930 == 13);
    }
    else {
        _22931 = binary_op(EQUALS, _22930, 13);
    }
    _22930 = NOVALUE;
    if (IS_ATOM_INT(_22931))
    _22929 = (_22931 != 0);
    else
    _22929 = DBL_PTR(_22931)->dbl != 0.0;
L3: 
    DeRef(_22923);
    _22923 = (_22929 != 0);
L1: 
    if (_22923 == 0) {
        _22932 = 0;
        goto L4; // [77] 97
    }
    _2 = (object)SEQ_PTR(_eentry_43808);
    _22933 = (object)*(((s1_ptr)_2)->base + 5);
    if (IS_ATOM_INT(_22933)) {
        _22934 = (_22933 != 0);
    }
    else {
        _22934 = binary_op(NOTEQ, _22933, 0);
    }
    _22933 = NOVALUE;
    if (IS_ATOM_INT(_22934))
    _22932 = (_22934 != 0);
    else
    _22932 = DBL_PTR(_22934)->dbl != 0.0;
L4: 
    if (_22932 == 0) {
        _22935 = 0;
        goto L5; // [97] 117
    }
    _2 = (object)SEQ_PTR(_eentry_43808);
    _22936 = (object)*(((s1_ptr)_2)->base + 5);
    if (IS_ATOM_INT(_22936)) {
        _22937 = (_22936 != 99);
    }
    else {
        _22937 = binary_op(NOTEQ, _22936, 99);
    }
    _22936 = NOVALUE;
    if (IS_ATOM_INT(_22937))
    _22935 = (_22937 != 0);
    else
    _22935 = DBL_PTR(_22937)->dbl != 0.0;
L5: 
    if (_22935 == 0) {
        goto L6; // [117] 150
    }
    _2 = (object)SEQ_PTR(_eentry_43808);
    if (!IS_ATOM_INT(_36S_TOKEN_21409)){
        _22939 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21409)->dbl));
    }
    else{
        _22939 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21409);
    }
    _22940 = find_from(_22939, _38RTN_TOKS_16291, 1);
    _22939 = NOVALUE;
    _22941 = (_22940 == 0);
    _22940 = NOVALUE;
    if (_22941 == 0)
    {
        DeRef(_22941);
        _22941 = NOVALUE;
        goto L6; // [138] 150
    }
    else{
        DeRef(_22941);
        _22941 = NOVALUE;
    }

    /** c_decl.e:757			return 1*/
    DeRefDS(_eentry_43808);
    DeRef(_22931);
    _22931 = NOVALUE;
    DeRef(_22937);
    _22937 = NOVALUE;
    DeRef(_22925);
    _22925 = NOVALUE;
    DeRef(_22922);
    _22922 = NOVALUE;
    DeRef(_22928);
    _22928 = NOVALUE;
    DeRef(_22934);
    _22934 = NOVALUE;
    return 1;
    goto L7; // [147] 157
L6: 

    /** c_decl.e:759			return 0*/
    DeRefDS(_eentry_43808);
    DeRef(_22931);
    _22931 = NOVALUE;
    DeRef(_22937);
    _22937 = NOVALUE;
    DeRef(_22925);
    _22925 = NOVALUE;
    DeRef(_22922);
    _22922 = NOVALUE;
    DeRef(_22928);
    _22928 = NOVALUE;
    DeRef(_22934);
    _22934 = NOVALUE;
    return 0;
L7: 
    ;
}


void _58DeclareFileVars()
{
    object _s_43849 = NOVALUE;
    object _eentry_43851 = NOVALUE;
    object _cleanup_vars_43945 = NOVALUE;
    object _23024 = NOVALUE;
    object _23017 = NOVALUE;
    object _23012 = NOVALUE;
    object _23009 = NOVALUE;
    object _23008 = NOVALUE;
    object _23007 = NOVALUE;
    object _23005 = NOVALUE;
    object _23001 = NOVALUE;
    object _22997 = NOVALUE;
    object _22994 = NOVALUE;
    object _22993 = NOVALUE;
    object _22992 = NOVALUE;
    object _22990 = NOVALUE;
    object _22986 = NOVALUE;
    object _22982 = NOVALUE;
    object _22981 = NOVALUE;
    object _22980 = NOVALUE;
    object _22977 = NOVALUE;
    object _22976 = NOVALUE;
    object _22974 = NOVALUE;
    object _22973 = NOVALUE;
    object _22972 = NOVALUE;
    object _22971 = NOVALUE;
    object _22967 = NOVALUE;
    object _22966 = NOVALUE;
    object _22965 = NOVALUE;
    object _22964 = NOVALUE;
    object _22963 = NOVALUE;
    object _22962 = NOVALUE;
    object _22961 = NOVALUE;
    object _22960 = NOVALUE;
    object _22959 = NOVALUE;
    object _22958 = NOVALUE;
    object _22957 = NOVALUE;
    object _22956 = NOVALUE;
    object _22955 = NOVALUE;
    object _22954 = NOVALUE;
    object _22953 = NOVALUE;
    object _22952 = NOVALUE;
    object _22951 = NOVALUE;
    object _22950 = NOVALUE;
    object _22949 = NOVALUE;
    object _22948 = NOVALUE;
    object _22947 = NOVALUE;
    object _22946 = NOVALUE;
    object _22943 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:769		c_puts("// Declaring file vars\n")*/
    RefDS(_22942);
    _55c_puts(_22942);

    /** c_decl.e:770		s = SymTab[TopLevelSub][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _22943 = (object)*(((s1_ptr)_2)->base + _36TopLevelSub_21774);
    _2 = (object)SEQ_PTR(_22943);
    _s_43849 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_43849)){
        _s_43849 = (object)DBL_PTR(_s_43849)->dbl;
    }
    _22943 = NOVALUE;

    /** c_decl.e:772		while s do*/
L1: 
    if (_s_43849 == 0)
    {
        goto L2; // [29] 328
    }
    else{
    }

    /** c_decl.e:773			eentry = SymTab[s]*/
    DeRef(_eentry_43851);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _eentry_43851 = (object)*(((s1_ptr)_2)->base + _s_43849);
    Ref(_eentry_43851);

    /** c_decl.e:774			if eentry[S_SCOPE] >= SC_LOCAL*/
    _2 = (object)SEQ_PTR(_eentry_43851);
    _22946 = (object)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_22946)) {
        _22947 = (_22946 >= 5);
    }
    else {
        _22947 = binary_op(GREATEREQ, _22946, 5);
    }
    _22946 = NOVALUE;
    if (IS_ATOM_INT(_22947)) {
        if (_22947 == 0) {
            DeRef(_22948);
            _22948 = 0;
            goto L3; // [56] 116
        }
    }
    else {
        if (DBL_PTR(_22947)->dbl == 0.0) {
            DeRef(_22948);
            _22948 = 0;
            goto L3; // [56] 116
        }
    }
    _2 = (object)SEQ_PTR(_eentry_43851);
    _22949 = (object)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_22949)) {
        _22950 = (_22949 <= 6);
    }
    else {
        _22950 = binary_op(LESSEQ, _22949, 6);
    }
    _22949 = NOVALUE;
    if (IS_ATOM_INT(_22950)) {
        if (_22950 != 0) {
            DeRef(_22951);
            _22951 = 1;
            goto L4; // [72] 92
        }
    }
    else {
        if (DBL_PTR(_22950)->dbl != 0.0) {
            DeRef(_22951);
            _22951 = 1;
            goto L4; // [72] 92
        }
    }
    _2 = (object)SEQ_PTR(_eentry_43851);
    _22952 = (object)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_22952)) {
        _22953 = (_22952 == 11);
    }
    else {
        _22953 = binary_op(EQUALS, _22952, 11);
    }
    _22952 = NOVALUE;
    DeRef(_22951);
    if (IS_ATOM_INT(_22953))
    _22951 = (_22953 != 0);
    else
    _22951 = DBL_PTR(_22953)->dbl != 0.0;
L4: 
    if (_22951 != 0) {
        _22954 = 1;
        goto L5; // [92] 112
    }
    _2 = (object)SEQ_PTR(_eentry_43851);
    _22955 = (object)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_22955)) {
        _22956 = (_22955 == 13);
    }
    else {
        _22956 = binary_op(EQUALS, _22955, 13);
    }
    _22955 = NOVALUE;
    if (IS_ATOM_INT(_22956))
    _22954 = (_22956 != 0);
    else
    _22954 = DBL_PTR(_22956)->dbl != 0.0;
L5: 
    DeRef(_22948);
    _22948 = (_22954 != 0);
L3: 
    if (_22948 == 0) {
        _22957 = 0;
        goto L6; // [116] 136
    }
    _2 = (object)SEQ_PTR(_eentry_43851);
    _22958 = (object)*(((s1_ptr)_2)->base + 5);
    if (IS_ATOM_INT(_22958)) {
        _22959 = (_22958 != 0);
    }
    else {
        _22959 = binary_op(NOTEQ, _22958, 0);
    }
    _22958 = NOVALUE;
    if (IS_ATOM_INT(_22959))
    _22957 = (_22959 != 0);
    else
    _22957 = DBL_PTR(_22959)->dbl != 0.0;
L6: 
    if (_22957 == 0) {
        _22960 = 0;
        goto L7; // [136] 156
    }
    _2 = (object)SEQ_PTR(_eentry_43851);
    _22961 = (object)*(((s1_ptr)_2)->base + 5);
    if (IS_ATOM_INT(_22961)) {
        _22962 = (_22961 != 99);
    }
    else {
        _22962 = binary_op(NOTEQ, _22961, 99);
    }
    _22961 = NOVALUE;
    if (IS_ATOM_INT(_22962))
    _22960 = (_22962 != 0);
    else
    _22960 = DBL_PTR(_22962)->dbl != 0.0;
L7: 
    if (_22960 == 0) {
        goto L8; // [156] 307
    }
    _2 = (object)SEQ_PTR(_eentry_43851);
    if (!IS_ATOM_INT(_36S_TOKEN_21409)){
        _22964 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21409)->dbl));
    }
    else{
        _22964 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21409);
    }
    _22965 = find_from(_22964, _38RTN_TOKS_16291, 1);
    _22964 = NOVALUE;
    _22966 = (_22965 == 0);
    _22965 = NOVALUE;
    if (_22966 == 0)
    {
        DeRef(_22966);
        _22966 = NOVALUE;
        goto L8; // [177] 307
    }
    else{
        DeRef(_22966);
        _22966 = NOVALUE;
    }

    /** c_decl.e:780				if eentry[S_TOKEN] = PROC then*/
    _2 = (object)SEQ_PTR(_eentry_43851);
    if (!IS_ATOM_INT(_36S_TOKEN_21409)){
        _22967 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21409)->dbl));
    }
    else{
        _22967 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21409);
    }
    if (binary_op_a(NOTEQ, _22967, 27)){
        _22967 = NOVALUE;
        goto L9; // [190] 202
    }
    _22967 = NOVALUE;

    /** c_decl.e:781					c_puts( "void ")*/
    RefDS(_22969);
    _55c_puts(_22969);
    goto LA; // [199] 208
L9: 

    /** c_decl.e:783					c_puts("object ")*/
    RefDS(_22970);
    _55c_puts(_22970);
LA: 

    /** c_decl.e:785				c_printf("_%d", eentry[S_FILE_NO])*/
    _2 = (object)SEQ_PTR(_eentry_43851);
    if (!IS_ATOM_INT(_36S_FILE_NO_21400)){
        _22971 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21400)->dbl));
    }
    else{
        _22971 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21400);
    }
    RefDS(_22313);
    Ref(_22971);
    _55c_printf(_22313, _22971);
    _22971 = NOVALUE;

    /** c_decl.e:786				c_puts(eentry[S_NAME])*/
    _2 = (object)SEQ_PTR(_eentry_43851);
    if (!IS_ATOM_INT(_36S_NAME_21404)){
        _22972 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21404)->dbl));
    }
    else{
        _22972 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21404);
    }
    Ref(_22972);
    _55c_puts(_22972);
    _22972 = NOVALUE;

    /** c_decl.e:787				if is_integer( eentry[S_OBJ] ) then*/
    _2 = (object)SEQ_PTR(_eentry_43851);
    _22973 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_22973);
    _22974 = _36is_integer(_22973);
    _22973 = NOVALUE;
    if (_22974 == 0) {
        DeRef(_22974);
        _22974 = NOVALUE;
        goto LB; // [243] 267
    }
    else {
        if (!IS_ATOM_INT(_22974) && DBL_PTR(_22974)->dbl == 0.0){
            DeRef(_22974);
            _22974 = NOVALUE;
            goto LB; // [243] 267
        }
        DeRef(_22974);
        _22974 = NOVALUE;
    }
    DeRef(_22974);
    _22974 = NOVALUE;

    /** c_decl.e:788						c_printf(" = %d%s;\n", { eentry[S_OBJ], LL_suffix} )*/
    _2 = (object)SEQ_PTR(_eentry_43851);
    _22976 = (object)*(((s1_ptr)_2)->base + 1);
    RefDS(_59LL_suffix_30335);
    Ref(_22976);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _22976;
    ((intptr_t *)_2)[2] = _59LL_suffix_30335;
    _22977 = MAKE_SEQ(_1);
    _22976 = NOVALUE;
    RefDS(_22975);
    _55c_printf(_22975, _22977);
    _22977 = NOVALUE;
    goto LC; // [264] 273
LB: 

    /** c_decl.e:790					c_puts(" = NOVALUE;\n")*/
    RefDS(_22978);
    _55c_puts(_22978);
LC: 

    /** c_decl.e:793				c_hputs("extern object ")*/
    RefDS(_22979);
    _55c_hputs(_22979);

    /** c_decl.e:794				c_hprintf("_%d", eentry[S_FILE_NO])*/
    _2 = (object)SEQ_PTR(_eentry_43851);
    if (!IS_ATOM_INT(_36S_FILE_NO_21400)){
        _22980 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21400)->dbl));
    }
    else{
        _22980 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21400);
    }
    RefDS(_22313);
    Ref(_22980);
    _55c_hprintf(_22313, _22980);
    _22980 = NOVALUE;

    /** c_decl.e:795				c_hputs(eentry[S_NAME])*/
    _2 = (object)SEQ_PTR(_eentry_43851);
    if (!IS_ATOM_INT(_36S_NAME_21404)){
        _22981 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21404)->dbl));
    }
    else{
        _22981 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21404);
    }
    Ref(_22981);
    _55c_hputs(_22981);
    _22981 = NOVALUE;

    /** c_decl.e:797				c_hputs(";\n")*/
    RefDS(_22466);
    _55c_hputs(_22466);
L8: 

    /** c_decl.e:799			s = SymTab[s][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _22982 = (object)*(((s1_ptr)_2)->base + _s_43849);
    _2 = (object)SEQ_PTR(_22982);
    _s_43849 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_43849)){
        _s_43849 = (object)DBL_PTR(_s_43849)->dbl;
    }
    _22982 = NOVALUE;

    /** c_decl.e:800		end while*/
    goto L1; // [325] 29
L2: 

    /** c_decl.e:801		c_puts("\n")*/
    RefDS(_22385);
    _55c_puts(_22385);

    /** c_decl.e:802		c_hputs("\n")*/
    RefDS(_22385);
    _55c_hputs(_22385);

    /** c_decl.e:803		if dll_option or debug_option then*/
    if (_58dll_option_42893 != 0) {
        goto LD; // [342] 353
    }
    if (_58debug_option_42903 == 0)
    {
        goto LE; // [349] 707
    }
    else{
    }
LD: 

    /** c_decl.e:804			integer cleanup_vars = 0*/
    _cleanup_vars_43945 = 0;

    /** c_decl.e:805			c_puts("// Declaring var array for cleanup\n")*/
    RefDS(_22985);
    _55c_puts(_22985);

    /** c_decl.e:806			s = SymTab[TopLevelSub][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _22986 = (object)*(((s1_ptr)_2)->base + _36TopLevelSub_21774);
    _2 = (object)SEQ_PTR(_22986);
    _s_43849 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_43849)){
        _s_43849 = (object)DBL_PTR(_s_43849)->dbl;
    }
    _22986 = NOVALUE;

    /** c_decl.e:807			c_stmt0( "object_ptr _0var_cleanup[] = {\n" )*/
    RefDS(_22988);
    _58c_stmt0(_22988);

    /** c_decl.e:808			while s do*/
LF: 
    if (_s_43849 == 0)
    {
        goto L10; // [391] 473
    }
    else{
    }

    /** c_decl.e:809				eentry = SymTab[s]*/
    DeRef(_eentry_43851);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _eentry_43851 = (object)*(((s1_ptr)_2)->base + _s_43849);
    Ref(_eentry_43851);

    /** c_decl.e:810				if needs_uninit( eentry ) then*/
    RefDS(_eentry_43851);
    _22990 = _58needs_uninit(_eentry_43851);
    if (_22990 == 0) {
        DeRef(_22990);
        _22990 = NOVALUE;
        goto L11; // [410] 452
    }
    else {
        if (!IS_ATOM_INT(_22990) && DBL_PTR(_22990)->dbl == 0.0){
            DeRef(_22990);
            _22990 = NOVALUE;
            goto L11; // [410] 452
        }
        DeRef(_22990);
        _22990 = NOVALUE;
    }
    DeRef(_22990);
    _22990 = NOVALUE;

    /** c_decl.e:812					c_stmt0( sprintf("&_%d", eentry[S_FILE_NO]))*/
    _2 = (object)SEQ_PTR(_eentry_43851);
    if (!IS_ATOM_INT(_36S_FILE_NO_21400)){
        _22992 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21400)->dbl));
    }
    else{
        _22992 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21400);
    }
    _22993 = EPrintf(-9999999, _22991, _22992);
    _22992 = NOVALUE;
    _58c_stmt0(_22993);
    _22993 = NOVALUE;

    /** c_decl.e:813					c_puts(eentry[S_NAME] )*/
    _2 = (object)SEQ_PTR(_eentry_43851);
    if (!IS_ATOM_INT(_36S_NAME_21404)){
        _22994 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21404)->dbl));
    }
    else{
        _22994 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21404);
    }
    Ref(_22994);
    _55c_puts(_22994);
    _22994 = NOVALUE;

    /** c_decl.e:814					c_printf(", // %d\n", cleanup_vars )*/
    RefDS(_22995);
    _55c_printf(_22995, _cleanup_vars_43945);

    /** c_decl.e:815					cleanup_vars += 1*/
    _cleanup_vars_43945 = _cleanup_vars_43945 + 1;
L11: 

    /** c_decl.e:818				s = SymTab[s][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _22997 = (object)*(((s1_ptr)_2)->base + _s_43849);
    _2 = (object)SEQ_PTR(_22997);
    _s_43849 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_43849)){
        _s_43849 = (object)DBL_PTR(_s_43849)->dbl;
    }
    _22997 = NOVALUE;

    /** c_decl.e:819			end while*/
    goto LF; // [470] 391
L10: 

    /** c_decl.e:820			c_stmt0( "0\n" )*/
    RefDS(_22999);
    _58c_stmt0(_22999);

    /** c_decl.e:821			c_stmt0( "};\n" )*/
    RefDS(_23000);
    _58c_stmt0(_23000);

    /** c_decl.e:822			s = SymTab[TopLevelSub][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _23001 = (object)*(((s1_ptr)_2)->base + _36TopLevelSub_21774);
    _2 = (object)SEQ_PTR(_23001);
    _s_43849 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_43849)){
        _s_43849 = (object)DBL_PTR(_s_43849)->dbl;
    }
    _23001 = NOVALUE;

    /** c_decl.e:823			c_stmt0( "char *_0var_cleanup_name[] = {\n" )*/
    RefDS(_23003);
    _58c_stmt0(_23003);

    /** c_decl.e:824			cleanup_vars = 0*/
    _cleanup_vars_43945 = 0;

    /** c_decl.e:825			while s do*/
L12: 
    if (_s_43849 == 0)
    {
        goto L13; // [516] 598
    }
    else{
    }

    /** c_decl.e:826				eentry = SymTab[s]*/
    DeRef(_eentry_43851);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _eentry_43851 = (object)*(((s1_ptr)_2)->base + _s_43849);
    Ref(_eentry_43851);

    /** c_decl.e:827				if needs_uninit( eentry ) then*/
    RefDS(_eentry_43851);
    _23005 = _58needs_uninit(_eentry_43851);
    if (_23005 == 0) {
        DeRef(_23005);
        _23005 = NOVALUE;
        goto L14; // [535] 577
    }
    else {
        if (!IS_ATOM_INT(_23005) && DBL_PTR(_23005)->dbl == 0.0){
            DeRef(_23005);
            _23005 = NOVALUE;
            goto L14; // [535] 577
        }
        DeRef(_23005);
        _23005 = NOVALUE;
    }
    DeRef(_23005);
    _23005 = NOVALUE;

    /** c_decl.e:828					c_stmt0( sprintf("\"_%d", eentry[S_FILE_NO]))*/
    _2 = (object)SEQ_PTR(_eentry_43851);
    if (!IS_ATOM_INT(_36S_FILE_NO_21400)){
        _23007 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21400)->dbl));
    }
    else{
        _23007 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21400);
    }
    _23008 = EPrintf(-9999999, _23006, _23007);
    _23007 = NOVALUE;
    _58c_stmt0(_23008);
    _23008 = NOVALUE;

    /** c_decl.e:829					c_puts(eentry[S_NAME] )*/
    _2 = (object)SEQ_PTR(_eentry_43851);
    if (!IS_ATOM_INT(_36S_NAME_21404)){
        _23009 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21404)->dbl));
    }
    else{
        _23009 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21404);
    }
    Ref(_23009);
    _55c_puts(_23009);
    _23009 = NOVALUE;

    /** c_decl.e:830					c_printf("\", // %d\n", cleanup_vars )*/
    RefDS(_23010);
    _55c_printf(_23010, _cleanup_vars_43945);

    /** c_decl.e:831					cleanup_vars += 1*/
    _cleanup_vars_43945 = _cleanup_vars_43945 + 1;
L14: 

    /** c_decl.e:834				s = SymTab[s][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _23012 = (object)*(((s1_ptr)_2)->base + _s_43849);
    _2 = (object)SEQ_PTR(_23012);
    _s_43849 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_43849)){
        _s_43849 = (object)DBL_PTR(_s_43849)->dbl;
    }
    _23012 = NOVALUE;

    /** c_decl.e:835			end while*/
    goto L12; // [595] 516
L13: 

    /** c_decl.e:836			c_stmt0( "0\n" )*/
    RefDS(_22999);
    _58c_stmt0(_22999);

    /** c_decl.e:837			c_stmt0( "};\n" )*/
    RefDS(_23000);
    _58c_stmt0(_23000);

    /** c_decl.e:838			c_stmt0( "void _0cleanup_vars(){\n" )*/
    RefDS(_23014);
    _58c_stmt0(_23014);

    /** c_decl.e:839				c_stmt0( "int i;\n" )*/
    RefDS(_22274);
    _58c_stmt0(_22274);

    /** c_decl.e:840				c_stmt0( "object x;\n" )*/
    RefDS(_23015);
    _58c_stmt0(_23015);

    /** c_decl.e:841				c_stmt0( sprintf( "for( i = 0; i < %d; ++i ){\n", cleanup_vars ) )*/
    _23017 = EPrintf(-9999999, _23016, _cleanup_vars_43945);
    _58c_stmt0(_23017);
    _23017 = NOVALUE;

    /** c_decl.e:842					c_stmt0( "x = *_0var_cleanup[i];\n" )*/
    RefDS(_23018);
    _58c_stmt0(_23018);

    //c_decl.e:843					c_stmt0( "if( x >= NOVALUE ) /* do nothing */;\n" )
    RefDS(_23019);
    _58c_stmt0(_23019);

    /** c_decl.e:844					c_stmt0( "else if ( IS_ATOM_DBL( x ) && DBL_PTR( x )->cleanup != 0) {\n")*/
    RefDS(_23020);
    _58c_stmt0(_23020);

    /** c_decl.e:845						c_stmt0( "cleanup_double( DBL_PTR( x ) );\n")*/
    RefDS(_23021);
    _58c_stmt0(_23021);

    /** c_decl.e:846					c_stmt0( "}\n" )*/
    RefDS(_16169);
    _58c_stmt0(_16169);

    /** c_decl.e:847						c_stmt0( "else if (IS_SEQUENCE( x ) && SEQ_PTR( x )->cleanup != 0 ) {\n")*/
    RefDS(_23022);
    _58c_stmt0(_23022);

    /** c_decl.e:848						c_stmt0( "cleanup_sequence( SEQ_PTR( x ) );\n")*/
    RefDS(_23023);
    _58c_stmt0(_23023);

    /** c_decl.e:849					c_stmt0( "}\n" )*/
    RefDS(_16169);
    _58c_stmt0(_16169);

    /** c_decl.e:850				c_stmt0( "}\n" )*/
    RefDS(_16169);
    _58c_stmt0(_16169);

    /** c_decl.e:851				c_stmt0( sprintf( "for( i = 0; i < %d; ++i ){\n", cleanup_vars ) )*/
    _23024 = EPrintf(-9999999, _23016, _cleanup_vars_43945);
    _58c_stmt0(_23024);
    _23024 = NOVALUE;

    /** c_decl.e:852					c_stmt0( "DeRef( *_0var_cleanup[i] );\n" )*/
    RefDS(_23025);
    _58c_stmt0(_23025);

    /** c_decl.e:853					c_stmt0( "*_0var_cleanup[i] = NOVALUE;\n" )*/
    RefDS(_23026);
    _58c_stmt0(_23026);

    /** c_decl.e:854				c_stmt0( "}\n" )*/
    RefDS(_16169);
    _58c_stmt0(_16169);

    /** c_decl.e:855			c_stmt0( "}\n" )*/
    RefDS(_16169);
    _58c_stmt0(_16169);
LE: 

    /** c_decl.e:857	end procedure*/
    DeRef(_eentry_43851);
    DeRef(_22959);
    _22959 = NOVALUE;
    DeRef(_22947);
    _22947 = NOVALUE;
    DeRef(_22953);
    _22953 = NOVALUE;
    DeRef(_22962);
    _22962 = NOVALUE;
    DeRef(_22950);
    _22950 = NOVALUE;
    DeRef(_22956);
    _22956 = NOVALUE;
    return;
    ;
}


object _58PromoteTypeInfo()
{
    object _updsym_44016 = NOVALUE;
    object _s_44018 = NOVALUE;
    object _sym_44019 = NOVALUE;
    object _symo_44020 = NOVALUE;
    object _upd_44249 = NOVALUE;
    object _23125 = NOVALUE;
    object _23123 = NOVALUE;
    object _23122 = NOVALUE;
    object _23121 = NOVALUE;
    object _23120 = NOVALUE;
    object _23118 = NOVALUE;
    object _23116 = NOVALUE;
    object _23115 = NOVALUE;
    object _23114 = NOVALUE;
    object _23113 = NOVALUE;
    object _23112 = NOVALUE;
    object _23108 = NOVALUE;
    object _23105 = NOVALUE;
    object _23104 = NOVALUE;
    object _23103 = NOVALUE;
    object _23102 = NOVALUE;
    object _23101 = NOVALUE;
    object _23100 = NOVALUE;
    object _23099 = NOVALUE;
    object _23098 = NOVALUE;
    object _23097 = NOVALUE;
    object _23096 = NOVALUE;
    object _23095 = NOVALUE;
    object _23093 = NOVALUE;
    object _23092 = NOVALUE;
    object _23091 = NOVALUE;
    object _23090 = NOVALUE;
    object _23089 = NOVALUE;
    object _23088 = NOVALUE;
    object _23087 = NOVALUE;
    object _23086 = NOVALUE;
    object _23085 = NOVALUE;
    object _23084 = NOVALUE;
    object _23082 = NOVALUE;
    object _23081 = NOVALUE;
    object _23080 = NOVALUE;
    object _23078 = NOVALUE;
    object _23077 = NOVALUE;
    object _23076 = NOVALUE;
    object _23074 = NOVALUE;
    object _23073 = NOVALUE;
    object _23072 = NOVALUE;
    object _23071 = NOVALUE;
    object _23070 = NOVALUE;
    object _23069 = NOVALUE;
    object _23068 = NOVALUE;
    object _23066 = NOVALUE;
    object _23065 = NOVALUE;
    object _23064 = NOVALUE;
    object _23063 = NOVALUE;
    object _23061 = NOVALUE;
    object _23060 = NOVALUE;
    object _23058 = NOVALUE;
    object _23057 = NOVALUE;
    object _23056 = NOVALUE;
    object _23055 = NOVALUE;
    object _23054 = NOVALUE;
    object _23053 = NOVALUE;
    object _23052 = NOVALUE;
    object _23050 = NOVALUE;
    object _23049 = NOVALUE;
    object _23048 = NOVALUE;
    object _23047 = NOVALUE;
    object _23046 = NOVALUE;
    object _23045 = NOVALUE;
    object _23044 = NOVALUE;
    object _23043 = NOVALUE;
    object _23042 = NOVALUE;
    object _23041 = NOVALUE;
    object _23040 = NOVALUE;
    object _23039 = NOVALUE;
    object _23038 = NOVALUE;
    object _23037 = NOVALUE;
    object _23035 = NOVALUE;
    object _23034 = NOVALUE;
    object _23033 = NOVALUE;
    object _23031 = NOVALUE;
    object _23030 = NOVALUE;
    object _23027 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** c_decl.e:866		sequence sym, symo*/

    /** c_decl.e:868		updsym = 0*/
    _updsym_44016 = 0;

    /** c_decl.e:869		g_has_delete = p_has_delete*/
    _58g_has_delete_43075 = _58p_has_delete_43076;

    /** c_decl.e:870		s = SymTab[TopLevelSub][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _23027 = (object)*(((s1_ptr)_2)->base + _36TopLevelSub_21774);
    _2 = (object)SEQ_PTR(_23027);
    _s_44018 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_44018)){
        _s_44018 = (object)DBL_PTR(_s_44018)->dbl;
    }
    _23027 = NOVALUE;

    /** c_decl.e:871		while s do*/
L1: 
    if (_s_44018 == 0)
    {
        goto L2; // [38] 921
    }
    else{
    }

    /** c_decl.e:872			sym = SymTab[s]*/
    DeRef(_sym_44019);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _sym_44019 = (object)*(((s1_ptr)_2)->base + _s_44018);
    Ref(_sym_44019);

    /** c_decl.e:873			symo = sym*/
    RefDS(_sym_44019);
    DeRef(_symo_44020);
    _symo_44020 = _sym_44019;

    /** c_decl.e:874			if sym[S_TOKEN] = FUNC or sym[S_TOKEN] = TYPE then*/
    _2 = (object)SEQ_PTR(_sym_44019);
    if (!IS_ATOM_INT(_36S_TOKEN_21409)){
        _23030 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21409)->dbl));
    }
    else{
        _23030 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21409);
    }
    if (IS_ATOM_INT(_23030)) {
        _23031 = (_23030 == 501);
    }
    else {
        _23031 = binary_op(EQUALS, _23030, 501);
    }
    _23030 = NOVALUE;
    if (IS_ATOM_INT(_23031)) {
        if (_23031 != 0) {
            goto L3; // [72] 93
        }
    }
    else {
        if (DBL_PTR(_23031)->dbl != 0.0) {
            goto L3; // [72] 93
        }
    }
    _2 = (object)SEQ_PTR(_sym_44019);
    if (!IS_ATOM_INT(_36S_TOKEN_21409)){
        _23033 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21409)->dbl));
    }
    else{
        _23033 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21409);
    }
    if (IS_ATOM_INT(_23033)) {
        _23034 = (_23033 == 504);
    }
    else {
        _23034 = binary_op(EQUALS, _23033, 504);
    }
    _23033 = NOVALUE;
    if (_23034 == 0) {
        DeRef(_23034);
        _23034 = NOVALUE;
        goto L4; // [89] 138
    }
    else {
        if (!IS_ATOM_INT(_23034) && DBL_PTR(_23034)->dbl == 0.0){
            DeRef(_23034);
            _23034 = NOVALUE;
            goto L4; // [89] 138
        }
        DeRef(_23034);
        _23034 = NOVALUE;
    }
    DeRef(_23034);
    _23034 = NOVALUE;
L3: 

    /** c_decl.e:875				if sym[S_GTYPE_NEW] = TYPE_NULL then*/
    _2 = (object)SEQ_PTR(_sym_44019);
    _23035 = (object)*(((s1_ptr)_2)->base + 38);
    if (binary_op_a(NOTEQ, _23035, 0)){
        _23035 = NOVALUE;
        goto L5; // [103] 120
    }
    _23035 = NOVALUE;

    /** c_decl.e:876					sym[S_GTYPE] = TYPE_OBJECT*/
    _2 = (object)SEQ_PTR(_sym_44019);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44019 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 16;
    DeRef(_1);
    goto L6; // [117] 549
L5: 

    /** c_decl.e:878					sym[S_GTYPE] = sym[S_GTYPE_NEW]*/
    _2 = (object)SEQ_PTR(_sym_44019);
    _23037 = (object)*(((s1_ptr)_2)->base + 38);
    Ref(_23037);
    _2 = (object)SEQ_PTR(_sym_44019);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44019 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _23037;
    if( _1 != _23037 ){
        DeRef(_1);
    }
    _23037 = NOVALUE;
    goto L6; // [135] 549
L4: 

    /** c_decl.e:883				if sym[S_GTYPE] != TYPE_INTEGER and*/
    _2 = (object)SEQ_PTR(_sym_44019);
    _23038 = (object)*(((s1_ptr)_2)->base + 36);
    if (IS_ATOM_INT(_23038)) {
        _23039 = (_23038 != 1);
    }
    else {
        _23039 = binary_op(NOTEQ, _23038, 1);
    }
    _23038 = NOVALUE;
    if (IS_ATOM_INT(_23039)) {
        if (_23039 == 0) {
            DeRef(_23040);
            _23040 = 0;
            goto L7; // [152] 172
        }
    }
    else {
        if (DBL_PTR(_23039)->dbl == 0.0) {
            DeRef(_23040);
            _23040 = 0;
            goto L7; // [152] 172
        }
    }
    _2 = (object)SEQ_PTR(_sym_44019);
    _23041 = (object)*(((s1_ptr)_2)->base + 38);
    if (IS_ATOM_INT(_23041)) {
        _23042 = (_23041 != 16);
    }
    else {
        _23042 = binary_op(NOTEQ, _23041, 16);
    }
    _23041 = NOVALUE;
    DeRef(_23040);
    if (IS_ATOM_INT(_23042))
    _23040 = (_23042 != 0);
    else
    _23040 = DBL_PTR(_23042)->dbl != 0.0;
L7: 
    if (_23040 == 0) {
        goto L8; // [172] 283
    }
    _2 = (object)SEQ_PTR(_sym_44019);
    _23044 = (object)*(((s1_ptr)_2)->base + 38);
    if (IS_ATOM_INT(_23044)) {
        _23045 = (_23044 != 0);
    }
    else {
        _23045 = binary_op(NOTEQ, _23044, 0);
    }
    _23044 = NOVALUE;
    if (_23045 == 0) {
        DeRef(_23045);
        _23045 = NOVALUE;
        goto L8; // [189] 283
    }
    else {
        if (!IS_ATOM_INT(_23045) && DBL_PTR(_23045)->dbl == 0.0){
            DeRef(_23045);
            _23045 = NOVALUE;
            goto L8; // [189] 283
        }
        DeRef(_23045);
        _23045 = NOVALUE;
    }
    DeRef(_23045);
    _23045 = NOVALUE;

    /** c_decl.e:886					if sym[S_GTYPE_NEW] = TYPE_INTEGER or*/
    _2 = (object)SEQ_PTR(_sym_44019);
    _23046 = (object)*(((s1_ptr)_2)->base + 38);
    if (IS_ATOM_INT(_23046)) {
        _23047 = (_23046 == 1);
    }
    else {
        _23047 = binary_op(EQUALS, _23046, 1);
    }
    _23046 = NOVALUE;
    if (IS_ATOM_INT(_23047)) {
        if (_23047 != 0) {
            DeRef(_23048);
            _23048 = 1;
            goto L9; // [206] 226
        }
    }
    else {
        if (DBL_PTR(_23047)->dbl != 0.0) {
            DeRef(_23048);
            _23048 = 1;
            goto L9; // [206] 226
        }
    }
    _2 = (object)SEQ_PTR(_sym_44019);
    _23049 = (object)*(((s1_ptr)_2)->base + 36);
    if (IS_ATOM_INT(_23049)) {
        _23050 = (_23049 == 16);
    }
    else {
        _23050 = binary_op(EQUALS, _23049, 16);
    }
    _23049 = NOVALUE;
    DeRef(_23048);
    if (IS_ATOM_INT(_23050))
    _23048 = (_23050 != 0);
    else
    _23048 = DBL_PTR(_23050)->dbl != 0.0;
L9: 
    if (_23048 != 0) {
        goto LA; // [226] 267
    }
    _2 = (object)SEQ_PTR(_sym_44019);
    _23052 = (object)*(((s1_ptr)_2)->base + 36);
    if (IS_ATOM_INT(_23052)) {
        _23053 = (_23052 == 4);
    }
    else {
        _23053 = binary_op(EQUALS, _23052, 4);
    }
    _23052 = NOVALUE;
    if (IS_ATOM_INT(_23053)) {
        if (_23053 == 0) {
            DeRef(_23054);
            _23054 = 0;
            goto LB; // [242] 262
        }
    }
    else {
        if (DBL_PTR(_23053)->dbl == 0.0) {
            DeRef(_23054);
            _23054 = 0;
            goto LB; // [242] 262
        }
    }
    _2 = (object)SEQ_PTR(_sym_44019);
    _23055 = (object)*(((s1_ptr)_2)->base + 38);
    if (IS_ATOM_INT(_23055)) {
        _23056 = (_23055 == 2);
    }
    else {
        _23056 = binary_op(EQUALS, _23055, 2);
    }
    _23055 = NOVALUE;
    DeRef(_23054);
    if (IS_ATOM_INT(_23056))
    _23054 = (_23056 != 0);
    else
    _23054 = DBL_PTR(_23056)->dbl != 0.0;
LB: 
    if (_23054 == 0)
    {
        _23054 = NOVALUE;
        goto LC; // [263] 282
    }
    else{
        _23054 = NOVALUE;
    }
LA: 

    /** c_decl.e:890							sym[S_GTYPE] = sym[S_GTYPE_NEW]*/
    _2 = (object)SEQ_PTR(_sym_44019);
    _23057 = (object)*(((s1_ptr)_2)->base + 38);
    Ref(_23057);
    _2 = (object)SEQ_PTR(_sym_44019);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44019 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _23057;
    if( _1 != _23057 ){
        DeRef(_1);
    }
    _23057 = NOVALUE;
LC: 
L8: 

    /** c_decl.e:893				if sym[S_ARG_TYPE_NEW] = TYPE_NULL then*/
    _2 = (object)SEQ_PTR(_sym_44019);
    _23058 = (object)*(((s1_ptr)_2)->base + 44);
    if (binary_op_a(NOTEQ, _23058, 0)){
        _23058 = NOVALUE;
        goto LD; // [293] 310
    }
    _23058 = NOVALUE;

    /** c_decl.e:894					sym[S_ARG_TYPE] = TYPE_OBJECT*/
    _2 = (object)SEQ_PTR(_sym_44019);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44019 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 43);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 16;
    DeRef(_1);
    goto LE; // [307] 325
LD: 

    /** c_decl.e:896					sym[S_ARG_TYPE] = sym[S_ARG_TYPE_NEW]*/
    _2 = (object)SEQ_PTR(_sym_44019);
    _23060 = (object)*(((s1_ptr)_2)->base + 44);
    Ref(_23060);
    _2 = (object)SEQ_PTR(_sym_44019);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44019 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 43);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _23060;
    if( _1 != _23060 ){
        DeRef(_1);
    }
    _23060 = NOVALUE;
LE: 

    /** c_decl.e:898				sym[S_ARG_TYPE_NEW] = TYPE_NULL*/
    _2 = (object)SEQ_PTR(_sym_44019);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44019 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 44);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);

    /** c_decl.e:900				if sym[S_ARG_SEQ_ELEM_NEW] = TYPE_NULL then*/
    _2 = (object)SEQ_PTR(_sym_44019);
    _23061 = (object)*(((s1_ptr)_2)->base + 46);
    if (binary_op_a(NOTEQ, _23061, 0)){
        _23061 = NOVALUE;
        goto LF; // [345] 362
    }
    _23061 = NOVALUE;

    /** c_decl.e:901					sym[S_ARG_SEQ_ELEM] = TYPE_OBJECT*/
    _2 = (object)SEQ_PTR(_sym_44019);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44019 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 45);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 16;
    DeRef(_1);
    goto L10; // [359] 377
LF: 

    /** c_decl.e:903					sym[S_ARG_SEQ_ELEM] = sym[S_ARG_SEQ_ELEM_NEW]*/
    _2 = (object)SEQ_PTR(_sym_44019);
    _23063 = (object)*(((s1_ptr)_2)->base + 46);
    Ref(_23063);
    _2 = (object)SEQ_PTR(_sym_44019);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44019 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 45);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _23063;
    if( _1 != _23063 ){
        DeRef(_1);
    }
    _23063 = NOVALUE;
L10: 

    /** c_decl.e:905				sym[S_ARG_SEQ_ELEM_NEW] = TYPE_NULL*/
    _2 = (object)SEQ_PTR(_sym_44019);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44019 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 46);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);

    /** c_decl.e:907				if sym[S_ARG_MIN_NEW] = -NOVALUE or*/
    _2 = (object)SEQ_PTR(_sym_44019);
    _23064 = (object)*(((s1_ptr)_2)->base + 49);
    if (IS_ATOM_INT(_36NOVALUE_21621)) {
        if ((uintptr_t)_36NOVALUE_21621 == (uintptr_t)HIGH_BITS){
            _23065 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _23065 = - _36NOVALUE_21621;
        }
    }
    else {
        _23065 = unary_op(UMINUS, _36NOVALUE_21621);
    }
    if (IS_ATOM_INT(_23064) && IS_ATOM_INT(_23065)) {
        _23066 = (_23064 == _23065);
    }
    else {
        _23066 = binary_op(EQUALS, _23064, _23065);
    }
    _23064 = NOVALUE;
    DeRef(_23065);
    _23065 = NOVALUE;
    if (IS_ATOM_INT(_23066)) {
        if (_23066 != 0) {
            goto L11; // [404] 425
        }
    }
    else {
        if (DBL_PTR(_23066)->dbl != 0.0) {
            goto L11; // [404] 425
        }
    }
    _2 = (object)SEQ_PTR(_sym_44019);
    _23068 = (object)*(((s1_ptr)_2)->base + 49);
    if (IS_ATOM_INT(_23068) && IS_ATOM_INT(_36NOVALUE_21621)) {
        _23069 = (_23068 == _36NOVALUE_21621);
    }
    else {
        _23069 = binary_op(EQUALS, _23068, _36NOVALUE_21621);
    }
    _23068 = NOVALUE;
    if (_23069 == 0) {
        DeRef(_23069);
        _23069 = NOVALUE;
        goto L12; // [421] 448
    }
    else {
        if (!IS_ATOM_INT(_23069) && DBL_PTR(_23069)->dbl == 0.0){
            DeRef(_23069);
            _23069 = NOVALUE;
            goto L12; // [421] 448
        }
        DeRef(_23069);
        _23069 = NOVALUE;
    }
    DeRef(_23069);
    _23069 = NOVALUE;
L11: 

    /** c_decl.e:909					sym[S_ARG_MIN] = MININT*/
    _2 = (object)SEQ_PTR(_sym_44019);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44019 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 47);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = -1073741824;
    DeRef(_1);

    /** c_decl.e:910					sym[S_ARG_MAX] = MAXINT*/
    _2 = (object)SEQ_PTR(_sym_44019);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44019 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 48);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1073741823;
    DeRef(_1);
    goto L13; // [445] 477
L12: 

    /** c_decl.e:912					sym[S_ARG_MIN] = sym[S_ARG_MIN_NEW]*/
    _2 = (object)SEQ_PTR(_sym_44019);
    _23070 = (object)*(((s1_ptr)_2)->base + 49);
    Ref(_23070);
    _2 = (object)SEQ_PTR(_sym_44019);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44019 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 47);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _23070;
    if( _1 != _23070 ){
        DeRef(_1);
    }
    _23070 = NOVALUE;

    /** c_decl.e:913					sym[S_ARG_MAX] = sym[S_ARG_MAX_NEW]*/
    _2 = (object)SEQ_PTR(_sym_44019);
    _23071 = (object)*(((s1_ptr)_2)->base + 50);
    Ref(_23071);
    _2 = (object)SEQ_PTR(_sym_44019);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44019 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 48);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _23071;
    if( _1 != _23071 ){
        DeRef(_1);
    }
    _23071 = NOVALUE;
L13: 

    /** c_decl.e:915				sym[S_ARG_MIN_NEW] = -NOVALUE*/
    if (IS_ATOM_INT(_36NOVALUE_21621)) {
        if ((uintptr_t)_36NOVALUE_21621 == (uintptr_t)HIGH_BITS){
            _23072 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _23072 = - _36NOVALUE_21621;
        }
    }
    else {
        _23072 = unary_op(UMINUS, _36NOVALUE_21621);
    }
    _2 = (object)SEQ_PTR(_sym_44019);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44019 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 49);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _23072;
    if( _1 != _23072 ){
        DeRef(_1);
    }
    _23072 = NOVALUE;

    /** c_decl.e:917				if sym[S_ARG_SEQ_LEN_NEW] = -NOVALUE then*/
    _2 = (object)SEQ_PTR(_sym_44019);
    _23073 = (object)*(((s1_ptr)_2)->base + 52);
    if (IS_ATOM_INT(_36NOVALUE_21621)) {
        if ((uintptr_t)_36NOVALUE_21621 == (uintptr_t)HIGH_BITS){
            _23074 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _23074 = - _36NOVALUE_21621;
        }
    }
    else {
        _23074 = unary_op(UMINUS, _36NOVALUE_21621);
    }
    if (binary_op_a(NOTEQ, _23073, _23074)){
        _23073 = NOVALUE;
        DeRef(_23074);
        _23074 = NOVALUE;
        goto L14; // [503] 520
    }
    _23073 = NOVALUE;
    DeRef(_23074);
    _23074 = NOVALUE;

    /** c_decl.e:918					sym[S_ARG_SEQ_LEN] = NOVALUE*/
    Ref(_36NOVALUE_21621);
    _2 = (object)SEQ_PTR(_sym_44019);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44019 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 51);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36NOVALUE_21621;
    DeRef(_1);
    goto L15; // [517] 535
L14: 

    /** c_decl.e:920					sym[S_ARG_SEQ_LEN] = sym[S_ARG_SEQ_LEN_NEW]*/
    _2 = (object)SEQ_PTR(_sym_44019);
    _23076 = (object)*(((s1_ptr)_2)->base + 52);
    Ref(_23076);
    _2 = (object)SEQ_PTR(_sym_44019);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44019 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 51);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _23076;
    if( _1 != _23076 ){
        DeRef(_1);
    }
    _23076 = NOVALUE;
L15: 

    /** c_decl.e:922				sym[S_ARG_SEQ_LEN_NEW] = -NOVALUE*/
    if (IS_ATOM_INT(_36NOVALUE_21621)) {
        if ((uintptr_t)_36NOVALUE_21621 == (uintptr_t)HIGH_BITS){
            _23077 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _23077 = - _36NOVALUE_21621;
        }
    }
    else {
        _23077 = unary_op(UMINUS, _36NOVALUE_21621);
    }
    _2 = (object)SEQ_PTR(_sym_44019);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44019 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 52);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _23077;
    if( _1 != _23077 ){
        DeRef(_1);
    }
    _23077 = NOVALUE;
L6: 

    /** c_decl.e:925			sym[S_GTYPE_NEW] = TYPE_NULL*/
    _2 = (object)SEQ_PTR(_sym_44019);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44019 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 38);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);

    /** c_decl.e:927			if sym[S_SEQ_ELEM_NEW] = TYPE_NULL then*/
    _2 = (object)SEQ_PTR(_sym_44019);
    _23078 = (object)*(((s1_ptr)_2)->base + 40);
    if (binary_op_a(NOTEQ, _23078, 0)){
        _23078 = NOVALUE;
        goto L16; // [569] 586
    }
    _23078 = NOVALUE;

    /** c_decl.e:928			   sym[S_SEQ_ELEM] = TYPE_OBJECT*/
    _2 = (object)SEQ_PTR(_sym_44019);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44019 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 16;
    DeRef(_1);
    goto L17; // [583] 601
L16: 

    /** c_decl.e:930				sym[S_SEQ_ELEM] = sym[S_SEQ_ELEM_NEW]*/
    _2 = (object)SEQ_PTR(_sym_44019);
    _23080 = (object)*(((s1_ptr)_2)->base + 40);
    Ref(_23080);
    _2 = (object)SEQ_PTR(_sym_44019);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44019 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _23080;
    if( _1 != _23080 ){
        DeRef(_1);
    }
    _23080 = NOVALUE;
L17: 

    /** c_decl.e:932			sym[S_SEQ_ELEM_NEW] = TYPE_NULL*/
    _2 = (object)SEQ_PTR(_sym_44019);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44019 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 40);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);

    /** c_decl.e:934			if sym[S_SEQ_LEN_NEW] = -NOVALUE then*/
    _2 = (object)SEQ_PTR(_sym_44019);
    _23081 = (object)*(((s1_ptr)_2)->base + 39);
    if (IS_ATOM_INT(_36NOVALUE_21621)) {
        if ((uintptr_t)_36NOVALUE_21621 == (uintptr_t)HIGH_BITS){
            _23082 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _23082 = - _36NOVALUE_21621;
        }
    }
    else {
        _23082 = unary_op(UMINUS, _36NOVALUE_21621);
    }
    if (binary_op_a(NOTEQ, _23081, _23082)){
        _23081 = NOVALUE;
        DeRef(_23082);
        _23082 = NOVALUE;
        goto L18; // [624] 641
    }
    _23081 = NOVALUE;
    DeRef(_23082);
    _23082 = NOVALUE;

    /** c_decl.e:935				sym[S_SEQ_LEN] = NOVALUE*/
    Ref(_36NOVALUE_21621);
    _2 = (object)SEQ_PTR(_sym_44019);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44019 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 32);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36NOVALUE_21621;
    DeRef(_1);
    goto L19; // [638] 656
L18: 

    /** c_decl.e:937				sym[S_SEQ_LEN] = sym[S_SEQ_LEN_NEW]*/
    _2 = (object)SEQ_PTR(_sym_44019);
    _23084 = (object)*(((s1_ptr)_2)->base + 39);
    Ref(_23084);
    _2 = (object)SEQ_PTR(_sym_44019);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44019 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 32);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _23084;
    if( _1 != _23084 ){
        DeRef(_1);
    }
    _23084 = NOVALUE;
L19: 

    /** c_decl.e:939			sym[S_SEQ_LEN_NEW] = -NOVALUE*/
    if (IS_ATOM_INT(_36NOVALUE_21621)) {
        if ((uintptr_t)_36NOVALUE_21621 == (uintptr_t)HIGH_BITS){
            _23085 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _23085 = - _36NOVALUE_21621;
        }
    }
    else {
        _23085 = unary_op(UMINUS, _36NOVALUE_21621);
    }
    _2 = (object)SEQ_PTR(_sym_44019);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44019 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 39);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _23085;
    if( _1 != _23085 ){
        DeRef(_1);
    }
    _23085 = NOVALUE;

    /** c_decl.e:941			if sym[S_TOKEN] != NAMESPACE*/
    _2 = (object)SEQ_PTR(_sym_44019);
    if (!IS_ATOM_INT(_36S_TOKEN_21409)){
        _23086 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21409)->dbl));
    }
    else{
        _23086 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21409);
    }
    if (IS_ATOM_INT(_23086)) {
        _23087 = (_23086 != 523);
    }
    else {
        _23087 = binary_op(NOTEQ, _23086, 523);
    }
    _23086 = NOVALUE;
    if (IS_ATOM_INT(_23087)) {
        if (_23087 == 0) {
            goto L1A; // [683] 794
        }
    }
    else {
        if (DBL_PTR(_23087)->dbl == 0.0) {
            goto L1A; // [683] 794
        }
    }
    _2 = (object)SEQ_PTR(_sym_44019);
    _23089 = (object)*(((s1_ptr)_2)->base + 3);
    if (IS_ATOM_INT(_23089)) {
        _23090 = (_23089 != 2);
    }
    else {
        _23090 = binary_op(NOTEQ, _23089, 2);
    }
    _23089 = NOVALUE;
    if (_23090 == 0) {
        DeRef(_23090);
        _23090 = NOVALUE;
        goto L1A; // [700] 794
    }
    else {
        if (!IS_ATOM_INT(_23090) && DBL_PTR(_23090)->dbl == 0.0){
            DeRef(_23090);
            _23090 = NOVALUE;
            goto L1A; // [700] 794
        }
        DeRef(_23090);
        _23090 = NOVALUE;
    }
    DeRef(_23090);
    _23090 = NOVALUE;

    /** c_decl.e:944				if sym[S_OBJ_MIN_NEW] = -NOVALUE or*/
    _2 = (object)SEQ_PTR(_sym_44019);
    _23091 = (object)*(((s1_ptr)_2)->base + 41);
    if (IS_ATOM_INT(_36NOVALUE_21621)) {
        if ((uintptr_t)_36NOVALUE_21621 == (uintptr_t)HIGH_BITS){
            _23092 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _23092 = - _36NOVALUE_21621;
        }
    }
    else {
        _23092 = unary_op(UMINUS, _36NOVALUE_21621);
    }
    if (IS_ATOM_INT(_23091) && IS_ATOM_INT(_23092)) {
        _23093 = (_23091 == _23092);
    }
    else {
        _23093 = binary_op(EQUALS, _23091, _23092);
    }
    _23091 = NOVALUE;
    DeRef(_23092);
    _23092 = NOVALUE;
    if (IS_ATOM_INT(_23093)) {
        if (_23093 != 0) {
            goto L1B; // [720] 741
        }
    }
    else {
        if (DBL_PTR(_23093)->dbl != 0.0) {
            goto L1B; // [720] 741
        }
    }
    _2 = (object)SEQ_PTR(_sym_44019);
    _23095 = (object)*(((s1_ptr)_2)->base + 41);
    if (IS_ATOM_INT(_23095) && IS_ATOM_INT(_36NOVALUE_21621)) {
        _23096 = (_23095 == _36NOVALUE_21621);
    }
    else {
        _23096 = binary_op(EQUALS, _23095, _36NOVALUE_21621);
    }
    _23095 = NOVALUE;
    if (_23096 == 0) {
        DeRef(_23096);
        _23096 = NOVALUE;
        goto L1C; // [737] 764
    }
    else {
        if (!IS_ATOM_INT(_23096) && DBL_PTR(_23096)->dbl == 0.0){
            DeRef(_23096);
            _23096 = NOVALUE;
            goto L1C; // [737] 764
        }
        DeRef(_23096);
        _23096 = NOVALUE;
    }
    DeRef(_23096);
    _23096 = NOVALUE;
L1B: 

    /** c_decl.e:946					sym[S_OBJ_MIN] = MININT*/
    _2 = (object)SEQ_PTR(_sym_44019);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44019 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 30);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = -1073741824;
    DeRef(_1);

    /** c_decl.e:947					sym[S_OBJ_MAX] = MAXINT*/
    _2 = (object)SEQ_PTR(_sym_44019);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44019 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 31);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1073741823;
    DeRef(_1);
    goto L1D; // [761] 793
L1C: 

    /** c_decl.e:949					sym[S_OBJ_MIN] = sym[S_OBJ_MIN_NEW]*/
    _2 = (object)SEQ_PTR(_sym_44019);
    _23097 = (object)*(((s1_ptr)_2)->base + 41);
    Ref(_23097);
    _2 = (object)SEQ_PTR(_sym_44019);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44019 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 30);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _23097;
    if( _1 != _23097 ){
        DeRef(_1);
    }
    _23097 = NOVALUE;

    /** c_decl.e:950					sym[S_OBJ_MAX] = sym[S_OBJ_MAX_NEW]*/
    _2 = (object)SEQ_PTR(_sym_44019);
    _23098 = (object)*(((s1_ptr)_2)->base + 42);
    Ref(_23098);
    _2 = (object)SEQ_PTR(_sym_44019);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44019 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 31);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _23098;
    if( _1 != _23098 ){
        DeRef(_1);
    }
    _23098 = NOVALUE;
L1D: 
L1A: 

    /** c_decl.e:953			sym[S_OBJ_MIN_NEW] = -NOVALUE*/
    if (IS_ATOM_INT(_36NOVALUE_21621)) {
        if ((uintptr_t)_36NOVALUE_21621 == (uintptr_t)HIGH_BITS){
            _23099 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _23099 = - _36NOVALUE_21621;
        }
    }
    else {
        _23099 = unary_op(UMINUS, _36NOVALUE_21621);
    }
    _2 = (object)SEQ_PTR(_sym_44019);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44019 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 41);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _23099;
    if( _1 != _23099 ){
        DeRef(_1);
    }
    _23099 = NOVALUE;

    /** c_decl.e:955			if sym[S_NREFS] = 1 and*/
    _2 = (object)SEQ_PTR(_sym_44019);
    _23100 = (object)*(((s1_ptr)_2)->base + 12);
    if (IS_ATOM_INT(_23100)) {
        _23101 = (_23100 == 1);
    }
    else {
        _23101 = binary_op(EQUALS, _23100, 1);
    }
    _23100 = NOVALUE;
    if (IS_ATOM_INT(_23101)) {
        if (_23101 == 0) {
            goto L1E; // [819] 874
        }
    }
    else {
        if (DBL_PTR(_23101)->dbl == 0.0) {
            goto L1E; // [819] 874
        }
    }
    _2 = (object)SEQ_PTR(_sym_44019);
    if (!IS_ATOM_INT(_36S_TOKEN_21409)){
        _23103 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21409)->dbl));
    }
    else{
        _23103 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21409);
    }
    _23104 = find_from(_23103, _38RTN_TOKS_16291, 1);
    _23103 = NOVALUE;
    if (_23104 == 0)
    {
        _23104 = NOVALUE;
        goto L1E; // [837] 874
    }
    else{
        _23104 = NOVALUE;
    }

    /** c_decl.e:957				if sym[S_USAGE] != U_DELETED then*/
    _2 = (object)SEQ_PTR(_sym_44019);
    _23105 = (object)*(((s1_ptr)_2)->base + 5);
    if (binary_op_a(EQUALS, _23105, 99)){
        _23105 = NOVALUE;
        goto L1F; // [850] 873
    }
    _23105 = NOVALUE;

    /** c_decl.e:958					sym[S_USAGE] = U_DELETED*/
    _2 = (object)SEQ_PTR(_sym_44019);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44019 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 99;
    DeRef(_1);

    /** c_decl.e:959					deleted_routines += 1*/
    _58deleted_routines_44013 = _58deleted_routines_44013 + 1;
L1F: 
L1E: 

    /** c_decl.e:962			sym[S_NREFS] = 0*/
    _2 = (object)SEQ_PTR(_sym_44019);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44019 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);

    /** c_decl.e:963			if not equal(symo, sym) then*/
    if (_symo_44020 == _sym_44019)
    _23108 = 1;
    else if (IS_ATOM_INT(_symo_44020) && IS_ATOM_INT(_sym_44019))
    _23108 = 0;
    else
    _23108 = (compare(_symo_44020, _sym_44019) == 0);
    if (_23108 != 0)
    goto L20; // [888] 906
    _23108 = NOVALUE;

    /** c_decl.e:964				SymTab[s] = sym*/
    RefDS(_sym_44019);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _s_44018);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _sym_44019;
    DeRef(_1);

    /** c_decl.e:965				updsym += 1*/
    _updsym_44016 = _updsym_44016 + 1;
L20: 

    /** c_decl.e:967			s = sym[S_NEXT]*/
    _2 = (object)SEQ_PTR(_sym_44019);
    _s_44018 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_44018)){
        _s_44018 = (object)DBL_PTR(_s_44018)->dbl;
    }

    /** c_decl.e:968		end while*/
    goto L1; // [918] 38
L2: 

    /** c_decl.e:971		for i = 1 to length(temp_name_type) do*/
    if (IS_SEQUENCE(_36temp_name_type_21853)){
            _23112 = SEQ_PTR(_36temp_name_type_21853)->length;
    }
    else {
        _23112 = 1;
    }
    {
        object _i_44246;
        _i_44246 = 1;
L21: 
        if (_i_44246 > _23112){
            goto L22; // [928] 1061
        }

        /** c_decl.e:972			integer upd = 0*/
        _upd_44249 = 0;

        /** c_decl.e:974			if temp_name_type[i][T_GTYPE] != temp_name_type[i][T_GTYPE_NEW] then*/
        _2 = (object)SEQ_PTR(_36temp_name_type_21853);
        _23113 = (object)*(((s1_ptr)_2)->base + _i_44246);
        _2 = (object)SEQ_PTR(_23113);
        _23114 = (object)*(((s1_ptr)_2)->base + 1);
        _23113 = NOVALUE;
        _2 = (object)SEQ_PTR(_36temp_name_type_21853);
        _23115 = (object)*(((s1_ptr)_2)->base + _i_44246);
        _2 = (object)SEQ_PTR(_23115);
        _23116 = (object)*(((s1_ptr)_2)->base + 2);
        _23115 = NOVALUE;
        if (binary_op_a(EQUALS, _23114, _23116)){
            _23114 = NOVALUE;
            _23116 = NOVALUE;
            goto L23; // [966] 1003
        }
        _23114 = NOVALUE;
        _23116 = NOVALUE;

        /** c_decl.e:975				temp_name_type[i][T_GTYPE] = temp_name_type[i][T_GTYPE_NEW]*/
        _2 = (object)SEQ_PTR(_36temp_name_type_21853);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _36temp_name_type_21853 = MAKE_SEQ(_2);
        }
        _3 = (object)(_i_44246 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_36temp_name_type_21853);
        _23120 = (object)*(((s1_ptr)_2)->base + _i_44246);
        _2 = (object)SEQ_PTR(_23120);
        _23121 = (object)*(((s1_ptr)_2)->base + 2);
        _23120 = NOVALUE;
        Ref(_23121);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 1);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _23121;
        if( _1 != _23121 ){
            DeRef(_1);
        }
        _23121 = NOVALUE;
        _23118 = NOVALUE;

        /** c_decl.e:976				upd = 1*/
        _upd_44249 = 1;
L23: 

        /** c_decl.e:978			if temp_name_type[i][T_GTYPE_NEW] != TYPE_NULL then*/
        _2 = (object)SEQ_PTR(_36temp_name_type_21853);
        _23122 = (object)*(((s1_ptr)_2)->base + _i_44246);
        _2 = (object)SEQ_PTR(_23122);
        _23123 = (object)*(((s1_ptr)_2)->base + 2);
        _23122 = NOVALUE;
        if (binary_op_a(EQUALS, _23123, 0)){
            _23123 = NOVALUE;
            goto L24; // [1019] 1046
        }
        _23123 = NOVALUE;

        /** c_decl.e:979				temp_name_type[i][T_GTYPE_NEW] = TYPE_NULL*/
        _2 = (object)SEQ_PTR(_36temp_name_type_21853);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _36temp_name_type_21853 = MAKE_SEQ(_2);
        }
        _3 = (object)(_i_44246 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 2);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = 0;
        DeRef(_1);
        _23125 = NOVALUE;

        /** c_decl.e:980				upd = 1*/
        _upd_44249 = 1;
L24: 

        /** c_decl.e:982			updsym += upd*/
        _updsym_44016 = _updsym_44016 + _upd_44249;

        /** c_decl.e:983		end for*/
        _i_44246 = _i_44246 + 1;
        goto L21; // [1056] 935
L22: 
        ;
    }

    /** c_decl.e:985		return updsym*/
    DeRef(_sym_44019);
    DeRef(_symo_44020);
    DeRef(_23031);
    _23031 = NOVALUE;
    DeRef(_23066);
    _23066 = NOVALUE;
    DeRef(_23050);
    _23050 = NOVALUE;
    DeRef(_23087);
    _23087 = NOVALUE;
    DeRef(_23047);
    _23047 = NOVALUE;
    DeRef(_23101);
    _23101 = NOVALUE;
    DeRef(_23053);
    _23053 = NOVALUE;
    DeRef(_23039);
    _23039 = NOVALUE;
    DeRef(_23093);
    _23093 = NOVALUE;
    DeRef(_23056);
    _23056 = NOVALUE;
    DeRef(_23042);
    _23042 = NOVALUE;
    return _updsym_44016;
    ;
}


void _58declare_prototype(object _s_44284)
{
    object _ret_type_44285 = NOVALUE;
    object _scope_44296 = NOVALUE;
    object _23145 = NOVALUE;
    object _23144 = NOVALUE;
    object _23142 = NOVALUE;
    object _23141 = NOVALUE;
    object _23140 = NOVALUE;
    object _23139 = NOVALUE;
    object _23137 = NOVALUE;
    object _23136 = NOVALUE;
    object _23135 = NOVALUE;
    object _23134 = NOVALUE;
    object _23133 = NOVALUE;
    object _23131 = NOVALUE;
    object _23130 = NOVALUE;
    object _23128 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:990		if sym_token( s ) = PROC then*/
    _23128 = _54sym_token(_s_44284);
    if (binary_op_a(NOTEQ, _23128, 27)){
        DeRef(_23128);
        _23128 = NOVALUE;
        goto L1; // [11] 25
    }
    DeRef(_23128);
    _23128 = NOVALUE;

    /** c_decl.e:991			ret_type = "void "*/
    RefDS(_22969);
    DeRefi(_ret_type_44285);
    _ret_type_44285 = _22969;
    goto L2; // [22] 33
L1: 

    /** c_decl.e:993			ret_type ="object "*/
    RefDS(_22970);
    DeRefi(_ret_type_44285);
    _ret_type_44285 = _22970;
L2: 

    /** c_decl.e:996		c_hputs(ret_type)*/
    RefDS(_ret_type_44285);
    _55c_hputs(_ret_type_44285);

    /** c_decl.e:999		if dll_option and TWINDOWS  then*/
    if (_58dll_option_42893 == 0) {
        goto L3; // [44] 116
    }
    if (_46TWINDOWS_21914 == 0)
    {
        goto L3; // [51] 116
    }
    else{
    }

    /** c_decl.e:1000			integer scope = SymTab[s][S_SCOPE]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _23131 = (object)*(((s1_ptr)_2)->base + _s_44284);
    _2 = (object)SEQ_PTR(_23131);
    _scope_44296 = (object)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_scope_44296)){
        _scope_44296 = (object)DBL_PTR(_scope_44296)->dbl;
    }
    _23131 = NOVALUE;

    /** c_decl.e:1001			if (scope = SC_PUBLIC*/
    _23133 = (_scope_44296 == 13);
    if (_23133 != 0) {
        _23134 = 1;
        goto L4; // [78] 92
    }
    _23135 = (_scope_44296 == 11);
    _23134 = (_23135 != 0);
L4: 
    if (_23134 != 0) {
        DeRef(_23136);
        _23136 = 1;
        goto L5; // [92] 106
    }
    _23137 = (_scope_44296 == 6);
    _23136 = (_23137 != 0);
L5: 
    if (_23136 == 0)
    {
        _23136 = NOVALUE;
        goto L6; // [106] 115
    }
    else{
        _23136 = NOVALUE;
    }

    /** c_decl.e:1006				c_hputs("__stdcall ")*/
    RefDS(_23138);
    _55c_hputs(_23138);
L6: 
L3: 

    /** c_decl.e:1010		c_hprintf("_%d", SymTab[s][S_FILE_NO])*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _23139 = (object)*(((s1_ptr)_2)->base + _s_44284);
    _2 = (object)SEQ_PTR(_23139);
    if (!IS_ATOM_INT(_36S_FILE_NO_21400)){
        _23140 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21400)->dbl));
    }
    else{
        _23140 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21400);
    }
    _23139 = NOVALUE;
    RefDS(_22313);
    Ref(_23140);
    _55c_hprintf(_22313, _23140);
    _23140 = NOVALUE;

    /** c_decl.e:1011		c_hputs(SymTab[s][S_NAME])*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _23141 = (object)*(((s1_ptr)_2)->base + _s_44284);
    _2 = (object)SEQ_PTR(_23141);
    if (!IS_ATOM_INT(_36S_NAME_21404)){
        _23142 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21404)->dbl));
    }
    else{
        _23142 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21404);
    }
    _23141 = NOVALUE;
    Ref(_23142);
    _55c_hputs(_23142);
    _23142 = NOVALUE;

    /** c_decl.e:1012		c_hputs("(")*/
    RefDS(_23143);
    _55c_hputs(_23143);

    /** c_decl.e:1014		for i = 1 to SymTab[s][S_NUM_ARGS] do*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _23144 = (object)*(((s1_ptr)_2)->base + _s_44284);
    _2 = (object)SEQ_PTR(_23144);
    if (!IS_ATOM_INT(_36S_NUM_ARGS_21455)){
        _23145 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21455)->dbl));
    }
    else{
        _23145 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21455);
    }
    _23144 = NOVALUE;
    {
        object _i_44325;
        _i_44325 = 1;
L7: 
        if (binary_op_a(GREATER, _i_44325, _23145)){
            goto L8; // [172] 206
        }

        /** c_decl.e:1015			if i = 1 then*/
        if (binary_op_a(NOTEQ, _i_44325, 1)){
            goto L9; // [181] 193
        }

        /** c_decl.e:1016				c_hputs("object")*/
        RefDS(_23147);
        _55c_hputs(_23147);
        goto LA; // [190] 199
L9: 

        /** c_decl.e:1018				c_hputs(", object")*/
        RefDS(_23148);
        _55c_hputs(_23148);
LA: 

        /** c_decl.e:1020		end for*/
        _0 = _i_44325;
        if (IS_ATOM_INT(_i_44325)) {
            _i_44325 = _i_44325 + 1;
            if ((object)((uintptr_t)_i_44325 +(uintptr_t) HIGH_BITS) >= 0){
                _i_44325 = NewDouble((eudouble)_i_44325);
            }
        }
        else {
            _i_44325 = binary_op_a(PLUS, _i_44325, 1);
        }
        DeRef(_0);
        goto L7; // [201] 179
L8: 
        ;
        DeRef(_i_44325);
    }

    /** c_decl.e:1021		c_hputs(");\n")*/
    RefDS(_22494);
    _55c_hputs(_22494);

    /** c_decl.e:1022	end procedure*/
    DeRefi(_ret_type_44285);
    DeRef(_23135);
    _23135 = NOVALUE;
    DeRef(_23133);
    _23133 = NOVALUE;
    _23145 = NOVALUE;
    DeRef(_23137);
    _23137 = NOVALUE;
    return;
    ;
}


void _58add_to_routine_list(object _s_44341, object _seq_num_44342, object _first_44343)
{
    object _p_44418 = NOVALUE;
    object _23194 = NOVALUE;
    object _23192 = NOVALUE;
    object _23190 = NOVALUE;
    object _23188 = NOVALUE;
    object _23186 = NOVALUE;
    object _23185 = NOVALUE;
    object _23184 = NOVALUE;
    object _23182 = NOVALUE;
    object _23180 = NOVALUE;
    object _23178 = NOVALUE;
    object _23177 = NOVALUE;
    object _23175 = NOVALUE;
    object _23174 = NOVALUE;
    object _23170 = NOVALUE;
    object _23169 = NOVALUE;
    object _23168 = NOVALUE;
    object _23167 = NOVALUE;
    object _23166 = NOVALUE;
    object _23165 = NOVALUE;
    object _23164 = NOVALUE;
    object _23163 = NOVALUE;
    object _23162 = NOVALUE;
    object _23161 = NOVALUE;
    object _23159 = NOVALUE;
    object _23158 = NOVALUE;
    object _23157 = NOVALUE;
    object _23156 = NOVALUE;
    object _23153 = NOVALUE;
    object _23152 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** c_decl.e:1025		if not first then*/
    if (_first_44343 != 0)
    goto L1; // [9] 18

    /** c_decl.e:1026			c_puts(",\n")*/
    RefDS(_23150);
    _55c_puts(_23150);
L1: 

    /** c_decl.e:1029		c_puts("  {\"")*/
    RefDS(_23151);
    _55c_puts(_23151);

    /** c_decl.e:1031		c_puts(SymTab[s][S_NAME])*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _23152 = (object)*(((s1_ptr)_2)->base + _s_44341);
    _2 = (object)SEQ_PTR(_23152);
    if (!IS_ATOM_INT(_36S_NAME_21404)){
        _23153 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21404)->dbl));
    }
    else{
        _23153 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21404);
    }
    _23152 = NOVALUE;
    Ref(_23153);
    _55c_puts(_23153);
    _23153 = NOVALUE;

    /** c_decl.e:1032		c_puts("\", ")*/
    RefDS(_23154);
    _55c_puts(_23154);

    /** c_decl.e:1033		c_puts("(object (*)())")*/
    RefDS(_23155);
    _55c_puts(_23155);

    /** c_decl.e:1034		c_printf("_%d", SymTab[s][S_FILE_NO])*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _23156 = (object)*(((s1_ptr)_2)->base + _s_44341);
    _2 = (object)SEQ_PTR(_23156);
    if (!IS_ATOM_INT(_36S_FILE_NO_21400)){
        _23157 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21400)->dbl));
    }
    else{
        _23157 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21400);
    }
    _23156 = NOVALUE;
    RefDS(_22313);
    Ref(_23157);
    _55c_printf(_22313, _23157);
    _23157 = NOVALUE;

    /** c_decl.e:1035		c_puts(SymTab[s][S_NAME])*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _23158 = (object)*(((s1_ptr)_2)->base + _s_44341);
    _2 = (object)SEQ_PTR(_23158);
    if (!IS_ATOM_INT(_36S_NAME_21404)){
        _23159 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21404)->dbl));
    }
    else{
        _23159 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21404);
    }
    _23158 = NOVALUE;
    Ref(_23159);
    _55c_puts(_23159);
    _23159 = NOVALUE;

    /** c_decl.e:1036		c_printf(", %d", seq_num)*/
    RefDS(_23160);
    _55c_printf(_23160, _seq_num_44342);

    /** c_decl.e:1037		c_printf(", %d", SymTab[s][S_FILE_NO])*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _23161 = (object)*(((s1_ptr)_2)->base + _s_44341);
    _2 = (object)SEQ_PTR(_23161);
    if (!IS_ATOM_INT(_36S_FILE_NO_21400)){
        _23162 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21400)->dbl));
    }
    else{
        _23162 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21400);
    }
    _23161 = NOVALUE;
    RefDS(_23160);
    Ref(_23162);
    _55c_printf(_23160, _23162);
    _23162 = NOVALUE;

    /** c_decl.e:1038		c_printf(", %d", SymTab[s][S_NUM_ARGS])*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _23163 = (object)*(((s1_ptr)_2)->base + _s_44341);
    _2 = (object)SEQ_PTR(_23163);
    if (!IS_ATOM_INT(_36S_NUM_ARGS_21455)){
        _23164 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21455)->dbl));
    }
    else{
        _23164 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21455);
    }
    _23163 = NOVALUE;
    RefDS(_23160);
    Ref(_23164);
    _55c_printf(_23160, _23164);
    _23164 = NOVALUE;

    /** c_decl.e:1040		if TWINDOWS and dll_option and find( SymTab[s][S_SCOPE], { SC_GLOBAL, SC_EXPORT, SC_PUBLIC} ) then*/
    if (_46TWINDOWS_21914 == 0) {
        _23165 = 0;
        goto L2; // [131] 141
    }
    _23165 = (_58dll_option_42893 != 0);
L2: 
    if (_23165 == 0) {
        goto L3; // [141] 186
    }
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _23167 = (object)*(((s1_ptr)_2)->base + _s_44341);
    _2 = (object)SEQ_PTR(_23167);
    _23168 = (object)*(((s1_ptr)_2)->base + 4);
    _23167 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 6;
    ((intptr_t*)_2)[2] = 11;
    ((intptr_t*)_2)[3] = 13;
    _23169 = MAKE_SEQ(_1);
    _23170 = find_from(_23168, _23169, 1);
    _23168 = NOVALUE;
    DeRefDS(_23169);
    _23169 = NOVALUE;
    if (_23170 == 0)
    {
        _23170 = NOVALUE;
        goto L3; // [175] 186
    }
    else{
        _23170 = NOVALUE;
    }

    /** c_decl.e:1041			c_puts(", 1")  -- must call with __stdcall convention*/
    RefDS(_23171);
    _55c_puts(_23171);
    goto L4; // [183] 192
L3: 

    /** c_decl.e:1043			c_puts(", 0")  -- default: call with normal or __cdecl convention*/
    RefDS(_23172);
    _55c_puts(_23172);
L4: 

    /** c_decl.e:1046		c_printf(", %d, 0", SymTab[s][S_SCOPE] )*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _23174 = (object)*(((s1_ptr)_2)->base + _s_44341);
    _2 = (object)SEQ_PTR(_23174);
    _23175 = (object)*(((s1_ptr)_2)->base + 4);
    _23174 = NOVALUE;
    RefDS(_23173);
    Ref(_23175);
    _55c_printf(_23173, _23175);
    _23175 = NOVALUE;

    /** c_decl.e:1047		c_puts("}")*/
    RefDS(_23176);
    _55c_puts(_23176);

    /** c_decl.e:1049		if SymTab[s][S_NREFS] < 2 then*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _23177 = (object)*(((s1_ptr)_2)->base + _s_44341);
    _2 = (object)SEQ_PTR(_23177);
    _23178 = (object)*(((s1_ptr)_2)->base + 12);
    _23177 = NOVALUE;
    if (binary_op_a(GREATEREQ, _23178, 2)){
        _23178 = NOVALUE;
        goto L5; // [229] 249
    }
    _23178 = NOVALUE;

    /** c_decl.e:1050			SymTab[s][S_NREFS] = 2 --s->nrefs++*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_s_44341 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2;
    DeRef(_1);
    _23180 = NOVALUE;
L5: 

    /** c_decl.e:1055		symtab_index p = SymTab[s][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _23182 = (object)*(((s1_ptr)_2)->base + _s_44341);
    _2 = (object)SEQ_PTR(_23182);
    _p_44418 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_p_44418)){
        _p_44418 = (object)DBL_PTR(_p_44418)->dbl;
    }
    _23182 = NOVALUE;

    /** c_decl.e:1056		for i = 1 to SymTab[s][S_NUM_ARGS] do*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _23184 = (object)*(((s1_ptr)_2)->base + _s_44341);
    _2 = (object)SEQ_PTR(_23184);
    if (!IS_ATOM_INT(_36S_NUM_ARGS_21455)){
        _23185 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21455)->dbl));
    }
    else{
        _23185 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21455);
    }
    _23184 = NOVALUE;
    {
        object _i_44424;
        _i_44424 = 1;
L6: 
        if (binary_op_a(GREATER, _i_44424, _23185)){
            goto L7; // [279] 377
        }

        /** c_decl.e:1057			SymTab[p][S_ARG_SEQ_ELEM_NEW] = TYPE_OBJECT*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37SymTab_15637 = MAKE_SEQ(_2);
        }
        _3 = (object)(_p_44418 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 46);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = 16;
        DeRef(_1);
        _23186 = NOVALUE;

        /** c_decl.e:1058			SymTab[p][S_ARG_TYPE_NEW] = TYPE_OBJECT*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37SymTab_15637 = MAKE_SEQ(_2);
        }
        _3 = (object)(_p_44418 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 44);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = 16;
        DeRef(_1);
        _23188 = NOVALUE;

        /** c_decl.e:1059			SymTab[p][S_ARG_MIN_NEW] = NOVALUE*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37SymTab_15637 = MAKE_SEQ(_2);
        }
        _3 = (object)(_p_44418 + ((s1_ptr)_2)->base);
        Ref(_36NOVALUE_21621);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 49);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _36NOVALUE_21621;
        DeRef(_1);
        _23190 = NOVALUE;

        /** c_decl.e:1060			SymTab[p][S_ARG_SEQ_LEN_NEW] = NOVALUE*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37SymTab_15637 = MAKE_SEQ(_2);
        }
        _3 = (object)(_p_44418 + ((s1_ptr)_2)->base);
        Ref(_36NOVALUE_21621);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 52);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _36NOVALUE_21621;
        DeRef(_1);
        _23192 = NOVALUE;

        /** c_decl.e:1061			p = SymTab[p][S_NEXT]*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _23194 = (object)*(((s1_ptr)_2)->base + _p_44418);
        _2 = (object)SEQ_PTR(_23194);
        _p_44418 = (object)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_p_44418)){
            _p_44418 = (object)DBL_PTR(_p_44418)->dbl;
        }
        _23194 = NOVALUE;

        /** c_decl.e:1062		end for*/
        _0 = _i_44424;
        if (IS_ATOM_INT(_i_44424)) {
            _i_44424 = _i_44424 + 1;
            if ((object)((uintptr_t)_i_44424 +(uintptr_t) HIGH_BITS) >= 0){
                _i_44424 = NewDouble((eudouble)_i_44424);
            }
        }
        else {
            _i_44424 = binary_op_a(PLUS, _i_44424, 1);
        }
        DeRef(_0);
        goto L6; // [372] 286
L7: 
        ;
        DeRef(_i_44424);
    }

    /** c_decl.e:1063	end procedure*/
    _23185 = NOVALUE;
    return;
    ;
}


void _58DeclareRoutineList()
{
    object _s_44456 = NOVALUE;
    object _first_44457 = NOVALUE;
    object _seq_num_44458 = NOVALUE;
    object _these_routines_44466 = NOVALUE;
    object _these_routines_44488 = NOVALUE;
    object _23210 = NOVALUE;
    object _23209 = NOVALUE;
    object _23207 = NOVALUE;
    object _23205 = NOVALUE;
    object _23202 = NOVALUE;
    object _23201 = NOVALUE;
    object _23199 = NOVALUE;
    object _23197 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:1069		integer first, seq_num*/

    /** c_decl.e:1071		c_hputs("extern struct routine_list _00[];\n")*/
    RefDS(_23196);
    _55c_hputs(_23196);

    /** c_decl.e:1073		check_file_routines()*/
    _58check_file_routines();

    /** c_decl.e:1074		for f = 1 to length( file_routines ) do*/
    if (IS_SEQUENCE(_58file_routines_45045)){
            _23197 = SEQ_PTR(_58file_routines_45045)->length;
    }
    else {
        _23197 = 1;
    }
    {
        object _f_44463;
        _f_44463 = 1;
L1: 
        if (_f_44463 > _23197){
            goto L2; // [19] 98
        }

        /** c_decl.e:1075			sequence these_routines = file_routines[f]*/
        DeRef(_these_routines_44466);
        _2 = (object)SEQ_PTR(_58file_routines_45045);
        _these_routines_44466 = (object)*(((s1_ptr)_2)->base + _f_44463);
        Ref(_these_routines_44466);

        /** c_decl.e:1076			for r = 1 to length( these_routines ) do*/
        if (IS_SEQUENCE(_these_routines_44466)){
                _23199 = SEQ_PTR(_these_routines_44466)->length;
        }
        else {
            _23199 = 1;
        }
        {
            object _r_44470;
            _r_44470 = 1;
L3: 
            if (_r_44470 > _23199){
                goto L4; // [41] 89
            }

            /** c_decl.e:1077				s = these_routines[r]*/
            _2 = (object)SEQ_PTR(_these_routines_44466);
            _s_44456 = (object)*(((s1_ptr)_2)->base + _r_44470);
            if (!IS_ATOM_INT(_s_44456)){
                _s_44456 = (object)DBL_PTR(_s_44456)->dbl;
            }

            /** c_decl.e:1078				if SymTab[s][S_USAGE] != U_DELETED then*/
            _2 = (object)SEQ_PTR(_37SymTab_15637);
            _23201 = (object)*(((s1_ptr)_2)->base + _s_44456);
            _2 = (object)SEQ_PTR(_23201);
            _23202 = (object)*(((s1_ptr)_2)->base + 5);
            _23201 = NOVALUE;
            if (binary_op_a(EQUALS, _23202, 99)){
                _23202 = NOVALUE;
                goto L5; // [72] 82
            }
            _23202 = NOVALUE;

            /** c_decl.e:1080					declare_prototype( s )*/
            _58declare_prototype(_s_44456);
L5: 

            /** c_decl.e:1083			end for*/
            _r_44470 = _r_44470 + 1;
            goto L3; // [84] 48
L4: 
            ;
        }
        DeRef(_these_routines_44466);
        _these_routines_44466 = NOVALUE;

        /** c_decl.e:1084		end for*/
        _f_44463 = _f_44463 + 1;
        goto L1; // [93] 26
L2: 
        ;
    }

    /** c_decl.e:1085		c_puts("\n")*/
    RefDS(_22385);
    _55c_puts(_22385);

    /** c_decl.e:1088		seq_num = 0*/
    _seq_num_44458 = 0;

    /** c_decl.e:1089		first = TRUE*/
    _first_44457 = _13TRUE_447;

    /** c_decl.e:1090		c_puts("struct routine_list _00[] = {\n")*/
    RefDS(_23204);
    _55c_puts(_23204);

    /** c_decl.e:1092		for f = 1 to length( file_routines ) do*/
    if (IS_SEQUENCE(_58file_routines_45045)){
            _23205 = SEQ_PTR(_58file_routines_45045)->length;
    }
    else {
        _23205 = 1;
    }
    {
        object _f_44485;
        _f_44485 = 1;
L6: 
        if (_f_44485 > _23205){
            goto L7; // [129] 222
        }

        /** c_decl.e:1093			sequence these_routines = file_routines[f]*/
        DeRef(_these_routines_44488);
        _2 = (object)SEQ_PTR(_58file_routines_45045);
        _these_routines_44488 = (object)*(((s1_ptr)_2)->base + _f_44485);
        Ref(_these_routines_44488);

        /** c_decl.e:1094			for r = 1 to length( these_routines ) do*/
        if (IS_SEQUENCE(_these_routines_44488)){
                _23207 = SEQ_PTR(_these_routines_44488)->length;
        }
        else {
            _23207 = 1;
        }
        {
            object _r_44492;
            _r_44492 = 1;
L8: 
            if (_r_44492 > _23207){
                goto L9; // [151] 213
            }

            /** c_decl.e:1095				s = these_routines[r]*/
            _2 = (object)SEQ_PTR(_these_routines_44488);
            _s_44456 = (object)*(((s1_ptr)_2)->base + _r_44492);
            if (!IS_ATOM_INT(_s_44456)){
                _s_44456 = (object)DBL_PTR(_s_44456)->dbl;
            }

            /** c_decl.e:1096				if SymTab[s][S_RI_TARGET] then*/
            _2 = (object)SEQ_PTR(_37SymTab_15637);
            _23209 = (object)*(((s1_ptr)_2)->base + _s_44456);
            _2 = (object)SEQ_PTR(_23209);
            _23210 = (object)*(((s1_ptr)_2)->base + 53);
            _23209 = NOVALUE;
            if (_23210 == 0) {
                _23210 = NOVALUE;
                goto LA; // [180] 200
            }
            else {
                if (!IS_ATOM_INT(_23210) && DBL_PTR(_23210)->dbl == 0.0){
                    _23210 = NOVALUE;
                    goto LA; // [180] 200
                }
                _23210 = NOVALUE;
            }
            _23210 = NOVALUE;

            /** c_decl.e:1098					add_to_routine_list( s, seq_num, first )*/
            _58add_to_routine_list(_s_44456, _seq_num_44458, _first_44457);

            /** c_decl.e:1099					first = FALSE*/
            _first_44457 = _13FALSE_445;
LA: 

            /** c_decl.e:1102				seq_num += 1*/
            _seq_num_44458 = _seq_num_44458 + 1;

            /** c_decl.e:1103			end for*/
            _r_44492 = _r_44492 + 1;
            goto L8; // [208] 158
L9: 
            ;
        }
        DeRef(_these_routines_44488);
        _these_routines_44488 = NOVALUE;

        /** c_decl.e:1104		end for*/
        _f_44485 = _f_44485 + 1;
        goto L6; // [217] 136
L7: 
        ;
    }

    /** c_decl.e:1105		if not first then*/
    if (_first_44457 != 0)
    goto LB; // [224] 233

    /** c_decl.e:1106			c_puts(",\n")*/
    RefDS(_23150);
    _55c_puts(_23150);
LB: 

    /** c_decl.e:1108		c_puts("  {\"\", 0, 999999999, 0, 0, 0, 0}\n};\n\n")  -- end marker*/
    RefDS(_23213);
    _55c_puts(_23213);

    /** c_decl.e:1110		c_hputs("extern char ** _02;\n")*/
    RefDS(_23214);
    _55c_hputs(_23214);

    /** c_decl.e:1111		c_puts("char ** _02;\n")*/
    RefDS(_23215);
    _55c_puts(_23215);

    /** c_decl.e:1113		c_hputs("extern object _0switches;\n")*/
    RefDS(_23216);
    _55c_hputs(_23216);

    /** c_decl.e:1114		c_puts("object _0switches;\n")*/
    RefDS(_23217);
    _55c_puts(_23217);

    /** c_decl.e:1115	end procedure*/
    return;
    ;
}


void _58DeclareNameSpaceList()
{
    object _s_44518 = NOVALUE;
    object _first_44519 = NOVALUE;
    object _seq_num_44520 = NOVALUE;
    object _23237 = NOVALUE;
    object _23235 = NOVALUE;
    object _23234 = NOVALUE;
    object _23233 = NOVALUE;
    object _23232 = NOVALUE;
    object _23230 = NOVALUE;
    object _23229 = NOVALUE;
    object _23226 = NOVALUE;
    object _23225 = NOVALUE;
    object _23224 = NOVALUE;
    object _23223 = NOVALUE;
    object _23222 = NOVALUE;
    object _23220 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:1121		integer first, seq_num*/

    /** c_decl.e:1123		c_hputs("extern struct ns_list _01[];\n")*/
    RefDS(_23218);
    _55c_hputs(_23218);

    /** c_decl.e:1124		c_puts("struct ns_list _01[] = {\n")*/
    RefDS(_23219);
    _55c_puts(_23219);

    /** c_decl.e:1126		seq_num = 0*/
    _seq_num_44520 = 0;

    /** c_decl.e:1127		first = TRUE*/
    _first_44519 = _13TRUE_447;

    /** c_decl.e:1129		s = SymTab[TopLevelSub][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _23220 = (object)*(((s1_ptr)_2)->base + _36TopLevelSub_21774);
    _2 = (object)SEQ_PTR(_23220);
    _s_44518 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_44518)){
        _s_44518 = (object)DBL_PTR(_s_44518)->dbl;
    }
    _23220 = NOVALUE;

    /** c_decl.e:1130		while s do*/
L1: 
    if (_s_44518 == 0)
    {
        goto L2; // [50] 215
    }
    else{
    }

    /** c_decl.e:1131			if find(SymTab[s][S_TOKEN], NAMED_TOKS) then*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _23222 = (object)*(((s1_ptr)_2)->base + _s_44518);
    _2 = (object)SEQ_PTR(_23222);
    if (!IS_ATOM_INT(_36S_TOKEN_21409)){
        _23223 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21409)->dbl));
    }
    else{
        _23223 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21409);
    }
    _23222 = NOVALUE;
    _23224 = find_from(_23223, _38NAMED_TOKS_16293, 1);
    _23223 = NOVALUE;
    if (_23224 == 0)
    {
        _23224 = NOVALUE;
        goto L3; // [74] 194
    }
    else{
        _23224 = NOVALUE;
    }

    /** c_decl.e:1132				if SymTab[s][S_TOKEN] = NAMESPACE then*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _23225 = (object)*(((s1_ptr)_2)->base + _s_44518);
    _2 = (object)SEQ_PTR(_23225);
    if (!IS_ATOM_INT(_36S_TOKEN_21409)){
        _23226 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21409)->dbl));
    }
    else{
        _23226 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21409);
    }
    _23225 = NOVALUE;
    if (binary_op_a(NOTEQ, _23226, 523)){
        _23226 = NOVALUE;
        goto L4; // [93] 187
    }
    _23226 = NOVALUE;

    /** c_decl.e:1133					if not first then*/
    if (_first_44519 != 0)
    goto L5; // [99] 108

    /** c_decl.e:1134						c_puts(",\n")*/
    RefDS(_23150);
    _55c_puts(_23150);
L5: 

    /** c_decl.e:1136					first = FALSE*/
    _first_44519 = _13FALSE_445;

    /** c_decl.e:1138					c_puts("  {\"")*/
    RefDS(_23151);
    _55c_puts(_23151);

    /** c_decl.e:1139					c_puts(SymTab[s][S_NAME])*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _23229 = (object)*(((s1_ptr)_2)->base + _s_44518);
    _2 = (object)SEQ_PTR(_23229);
    if (!IS_ATOM_INT(_36S_NAME_21404)){
        _23230 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21404)->dbl));
    }
    else{
        _23230 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21404);
    }
    _23229 = NOVALUE;
    Ref(_23230);
    _55c_puts(_23230);
    _23230 = NOVALUE;

    /** c_decl.e:1140					c_printf("\", %d", SymTab[s][S_OBJ])*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _23232 = (object)*(((s1_ptr)_2)->base + _s_44518);
    _2 = (object)SEQ_PTR(_23232);
    _23233 = (object)*(((s1_ptr)_2)->base + 1);
    _23232 = NOVALUE;
    RefDS(_23231);
    Ref(_23233);
    _55c_printf(_23231, _23233);
    _23233 = NOVALUE;

    /** c_decl.e:1141					c_printf(", %d", seq_num)*/
    RefDS(_23160);
    _55c_printf(_23160, _seq_num_44520);

    /** c_decl.e:1142					c_printf(", %d", SymTab[s][S_FILE_NO])*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _23234 = (object)*(((s1_ptr)_2)->base + _s_44518);
    _2 = (object)SEQ_PTR(_23234);
    if (!IS_ATOM_INT(_36S_FILE_NO_21400)){
        _23235 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21400)->dbl));
    }
    else{
        _23235 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21400);
    }
    _23234 = NOVALUE;
    RefDS(_23160);
    Ref(_23235);
    _55c_printf(_23160, _23235);
    _23235 = NOVALUE;

    /** c_decl.e:1144					c_puts("}")*/
    RefDS(_23176);
    _55c_puts(_23176);
L4: 

    /** c_decl.e:1146				seq_num += 1*/
    _seq_num_44520 = _seq_num_44520 + 1;
L3: 

    /** c_decl.e:1148			s = SymTab[s][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _23237 = (object)*(((s1_ptr)_2)->base + _s_44518);
    _2 = (object)SEQ_PTR(_23237);
    _s_44518 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_44518)){
        _s_44518 = (object)DBL_PTR(_s_44518)->dbl;
    }
    _23237 = NOVALUE;

    /** c_decl.e:1149		end while*/
    goto L1; // [212] 50
L2: 

    /** c_decl.e:1150		if not first then*/
    if (_first_44519 != 0)
    goto L6; // [217] 226

    /** c_decl.e:1151			c_puts(",\n")*/
    RefDS(_23150);
    _55c_puts(_23150);
L6: 

    /** c_decl.e:1153		c_puts("  {\"\", 0, 999999999, 0}\n};\n\n")  -- end marker*/
    RefDS(_23240);
    _55c_puts(_23240);

    /** c_decl.e:1154	end procedure*/
    return;
    ;
}


object _58is_exported(object _s_44582)
{
    object _eentry_44583 = NOVALUE;
    object _scope_44586 = NOVALUE;
    object _23255 = NOVALUE;
    object _23254 = NOVALUE;
    object _23253 = NOVALUE;
    object _23252 = NOVALUE;
    object _23251 = NOVALUE;
    object _23250 = NOVALUE;
    object _23249 = NOVALUE;
    object _23248 = NOVALUE;
    object _23247 = NOVALUE;
    object _23246 = NOVALUE;
    object _23245 = NOVALUE;
    object _23243 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_s_44582)) {
        _1 = (object)(DBL_PTR(_s_44582)->dbl);
        DeRefDS(_s_44582);
        _s_44582 = _1;
    }

    /** c_decl.e:1159		sequence eentry = SymTab[s]*/
    DeRef(_eentry_44583);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _eentry_44583 = (object)*(((s1_ptr)_2)->base + _s_44582);
    Ref(_eentry_44583);

    /** c_decl.e:1160		integer scope = eentry[S_SCOPE]*/
    _2 = (object)SEQ_PTR(_eentry_44583);
    _scope_44586 = (object)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_scope_44586))
    _scope_44586 = (object)DBL_PTR(_scope_44586)->dbl;

    /** c_decl.e:1162		if eentry[S_MODE] = M_NORMAL then*/
    _2 = (object)SEQ_PTR(_eentry_44583);
    _23243 = (object)*(((s1_ptr)_2)->base + 3);
    if (binary_op_a(NOTEQ, _23243, 1)){
        _23243 = NOVALUE;
        goto L1; // [31] 125
    }
    _23243 = NOVALUE;

    /** c_decl.e:1163			if eentry[S_FILE_NO] = 1 and find(scope, { SC_EXPORT, SC_PUBLIC, SC_GLOBAL }) then*/
    _2 = (object)SEQ_PTR(_eentry_44583);
    if (!IS_ATOM_INT(_36S_FILE_NO_21400)){
        _23245 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21400)->dbl));
    }
    else{
        _23245 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21400);
    }
    if (IS_ATOM_INT(_23245)) {
        _23246 = (_23245 == 1);
    }
    else {
        _23246 = binary_op(EQUALS, _23245, 1);
    }
    _23245 = NOVALUE;
    if (IS_ATOM_INT(_23246)) {
        if (_23246 == 0) {
            goto L2; // [47] 79
        }
    }
    else {
        if (DBL_PTR(_23246)->dbl == 0.0) {
            goto L2; // [47] 79
        }
    }
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 11;
    ((intptr_t*)_2)[2] = 13;
    ((intptr_t*)_2)[3] = 6;
    _23248 = MAKE_SEQ(_1);
    _23249 = find_from(_scope_44586, _23248, 1);
    DeRefDS(_23248);
    _23248 = NOVALUE;
    if (_23249 == 0)
    {
        _23249 = NOVALUE;
        goto L2; // [69] 79
    }
    else{
        _23249 = NOVALUE;
    }

    /** c_decl.e:1164				return 1*/
    DeRef(_eentry_44583);
    DeRef(_23246);
    _23246 = NOVALUE;
    return 1;
L2: 

    /** c_decl.e:1167			if scope = SC_PUBLIC and*/
    _23250 = (_scope_44586 == 13);
    if (_23250 == 0) {
        goto L3; // [87] 124
    }
    _2 = (object)SEQ_PTR(_37include_matrix_15644);
    _23252 = (object)*(((s1_ptr)_2)->base + 1);
    _2 = (object)SEQ_PTR(_eentry_44583);
    if (!IS_ATOM_INT(_36S_FILE_NO_21400)){
        _23253 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21400)->dbl));
    }
    else{
        _23253 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21400);
    }
    _2 = (object)SEQ_PTR(_23252);
    if (!IS_ATOM_INT(_23253)){
        _23254 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_23253)->dbl));
    }
    else{
        _23254 = (object)*(((s1_ptr)_2)->base + _23253);
    }
    _23252 = NOVALUE;
    if (IS_ATOM_INT(_23254)) {
        {uintptr_t tu;
             tu = (uintptr_t)_23254 & (uintptr_t)4;
             _23255 = MAKE_UINT(tu);
        }
    }
    else {
        _23255 = binary_op(AND_BITS, _23254, 4);
    }
    _23254 = NOVALUE;
    if (_23255 == 0) {
        DeRef(_23255);
        _23255 = NOVALUE;
        goto L3; // [114] 124
    }
    else {
        if (!IS_ATOM_INT(_23255) && DBL_PTR(_23255)->dbl == 0.0){
            DeRef(_23255);
            _23255 = NOVALUE;
            goto L3; // [114] 124
        }
        DeRef(_23255);
        _23255 = NOVALUE;
    }
    DeRef(_23255);
    _23255 = NOVALUE;

    /** c_decl.e:1170				return 1*/
    DeRef(_eentry_44583);
    _23253 = NOVALUE;
    DeRef(_23246);
    _23246 = NOVALUE;
    DeRef(_23250);
    _23250 = NOVALUE;
    return 1;
L3: 
L1: 

    /** c_decl.e:1174		return 0*/
    DeRef(_eentry_44583);
    _23253 = NOVALUE;
    DeRef(_23246);
    _23246 = NOVALUE;
    DeRef(_23250);
    _23250 = NOVALUE;
    return 0;
    ;
}


void _58version()
{
    object _23289 = NOVALUE;
    object _23288 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:1207		c_puts("// Euphoria To C version " & version_string() & "\n")*/
    _23288 = _33version_string(0);
    {
        object concat_list[3];

        concat_list[0] = _22385;
        concat_list[1] = _23288;
        concat_list[2] = _23287;
        Concat_N((object_ptr)&_23289, concat_list, 3);
    }
    DeRef(_23288);
    _23288 = NOVALUE;
    _55c_puts(_23289);
    _23289 = NOVALUE;

    /** c_decl.e:1208	end procedure*/
    return;
    ;
}


void _58new_c_file(object _name_44690)
{
    object _23292 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:1213		cfile_size = 0*/
    _36cfile_size_21850 = 0;

    /** c_decl.e:1216		if LAST_PASS = FALSE then*/
    if (_58LAST_PASS_42880 != _13FALSE_445)
    goto L1; // [16] 26

    /** c_decl.e:1217			return*/
    DeRefDS(_name_44690);
    return;
L1: 

    /** c_decl.e:1220		write_checksum( c_code )*/
    _56write_checksum(_55c_code_46976);

    /** c_decl.e:1221		close(c_code)*/
    EClose(_55c_code_46976);

    /** c_decl.e:1223		c_code = open(output_dir & name & ".c", "w")*/
    {
        object concat_list[3];

        concat_list[0] = _23291;
        concat_list[1] = _name_44690;
        concat_list[2] = _58output_dir_42907;
        Concat_N((object_ptr)&_23292, concat_list, 3);
    }
    _55c_code_46976 = EOpen(_23292, _22326, 0);
    DeRefDS(_23292);
    _23292 = NOVALUE;

    /** c_decl.e:1224		if c_code = -1 then*/
    if (_55c_code_46976 != -1)
    goto L2; // [60] 74

    /** c_decl.e:1225			CompileErr(COULDNT_OPEN_C_FILE_FOR_OUTPUT)*/
    RefDS(_22190);
    _50CompileErr(57, _22190, 0);
L2: 

    /** c_decl.e:1228		cfile_count += 1*/
    _36cfile_count_21849 = _36cfile_count_21849 + 1;

    /** c_decl.e:1229		version()*/
    _58version();

    /** c_decl.e:1231		c_puts("#include \"include/euphoria.h\"\n")*/
    RefDS(_22331);
    _55c_puts(_22331);

    /** c_decl.e:1233		c_puts("#include \"main-.h\"\n\n")*/
    RefDS(_22332);
    _55c_puts(_22332);

    /** c_decl.e:1235		if not TUNIX then*/
    if (_46TUNIX_21918 != 0)
    goto L3; // [102] 114

    /** c_decl.e:1236			name = lower(name)  -- for faster compare later*/
    RefDS(_name_44690);
    _0 = _name_44690;
    _name_44690 = _14lower(_name_44690);
    DeRefDS(_0);
L3: 

    /** c_decl.e:1238	end procedure*/
    DeRefDS(_name_44690);
    return;
    ;
}


object _58unique_c_name(object _name_44720)
{
    object _i_44721 = NOVALUE;
    object _compare_name_44722 = NOVALUE;
    object _next_fc_44723 = NOVALUE;
    object _23308 = NOVALUE;
    object _23306 = NOVALUE;
    object _23305 = NOVALUE;
    object _23304 = NOVALUE;
    object _23302 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:1253		compare_name = name & ".c"*/
    Concat((object_ptr)&_compare_name_44722, _name_44720, _23291);

    /** c_decl.e:1254		if not TUNIX then*/
    if (_46TUNIX_21918 != 0)
    goto L1; // [13] 25

    /** c_decl.e:1255			compare_name = lower(compare_name)*/
    RefDS(_compare_name_44722);
    _0 = _compare_name_44722;
    _compare_name_44722 = _14lower(_compare_name_44722);
    DeRefDS(_0);
L1: 

    /** c_decl.e:1258		next_fc = 1*/
    _next_fc_44723 = 1;

    /** c_decl.e:1259		i = 1*/
    _i_44721 = 1;

    /** c_decl.e:1261		while i <= length(generated_files) do*/
L2: 
    if (IS_SEQUENCE(_58generated_files_42897)){
            _23302 = SEQ_PTR(_58generated_files_42897)->length;
    }
    else {
        _23302 = 1;
    }
    if (_i_44721 > _23302)
    goto L3; // [45] 141

    /** c_decl.e:1263			if equal(generated_files[i], compare_name) then*/
    _2 = (object)SEQ_PTR(_58generated_files_42897);
    _23304 = (object)*(((s1_ptr)_2)->base + _i_44721);
    if (_23304 == _compare_name_44722)
    _23305 = 1;
    else if (IS_ATOM_INT(_23304) && IS_ATOM_INT(_compare_name_44722))
    _23305 = 0;
    else
    _23305 = (compare(_23304, _compare_name_44722) == 0);
    _23304 = NOVALUE;
    if (_23305 == 0)
    {
        _23305 = NOVALUE;
        goto L4; // [61] 129
    }
    else{
        _23305 = NOVALUE;
    }

    /** c_decl.e:1265				if next_fc > length(file_chars) then*/
    if (IS_SEQUENCE(_58file_chars_44716)){
            _23306 = SEQ_PTR(_58file_chars_44716)->length;
    }
    else {
        _23306 = 1;
    }
    if (_next_fc_44723 <= _23306)
    goto L5; // [69] 83

    /** c_decl.e:1266					CompileErr(SORRY_TOO_MANY_C_FILES_WITH_THE_SAME_BASE_NAME)*/
    RefDS(_22190);
    _50CompileErr(140, _22190, 0);
L5: 

    /** c_decl.e:1269				name[1] = file_chars[next_fc]*/
    _2 = (object)SEQ_PTR(_58file_chars_44716);
    _23308 = (object)*(((s1_ptr)_2)->base + _next_fc_44723);
    Ref(_23308);
    _2 = (object)SEQ_PTR(_name_44720);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _name_44720 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _23308;
    if( _1 != _23308 ){
        DeRef(_1);
    }
    _23308 = NOVALUE;

    /** c_decl.e:1270				compare_name = name & ".c"*/
    Concat((object_ptr)&_compare_name_44722, _name_44720, _23291);

    /** c_decl.e:1271				if not TUNIX then*/
    if (_46TUNIX_21918 != 0)
    goto L6; // [103] 115

    /** c_decl.e:1272					compare_name = lower(compare_name)*/
    RefDS(_compare_name_44722);
    _0 = _compare_name_44722;
    _compare_name_44722 = _14lower(_compare_name_44722);
    DeRefDS(_0);
L6: 

    /** c_decl.e:1275				next_fc += 1*/
    _next_fc_44723 = _next_fc_44723 + 1;

    /** c_decl.e:1276				i = 1 -- start over and compare again*/
    _i_44721 = 1;
    goto L2; // [126] 40
L4: 

    /** c_decl.e:1279				i += 1*/
    _i_44721 = _i_44721 + 1;

    /** c_decl.e:1281		end while*/
    goto L2; // [138] 40
L3: 

    /** c_decl.e:1283		return name*/
    DeRef(_compare_name_44722);
    return _name_44720;
    ;
}


object _58is_file_newer(object _f1_44753, object _f2_44754)
{
    object _d1_44755 = NOVALUE;
    object _d2_44758 = NOVALUE;
    object _diff_2__tmp_at42_44769 = NOVALUE;
    object _diff_1__tmp_at42_44768 = NOVALUE;
    object _diff_inlined_diff_at_42_44767 = NOVALUE;
    object _23318 = NOVALUE;
    object _23316 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:1287		object d1 = file_timestamp(f1)*/
    RefDS(_f1_44753);
    _0 = _d1_44755;
    _d1_44755 = _17file_timestamp(_f1_44753);
    DeRef(_0);

    /** c_decl.e:1288		object d2 = file_timestamp(f2)*/
    RefDS(_f2_44754);
    _0 = _d2_44758;
    _d2_44758 = _17file_timestamp(_f2_44754);
    DeRef(_0);

    /** c_decl.e:1290		if atom(d1) or atom(d2) then return 1 end if*/
    _23316 = IS_ATOM(_d1_44755);
    if (_23316 != 0) {
        goto L1; // [22] 34
    }
    _23318 = IS_ATOM(_d2_44758);
    if (_23318 == 0)
    {
        _23318 = NOVALUE;
        goto L2; // [30] 39
    }
    else{
        _23318 = NOVALUE;
    }
L1: 
    DeRefDS(_f1_44753);
    DeRefDS(_f2_44754);
    DeRef(_d1_44755);
    DeRef(_d2_44758);
    return 1;
L2: 

    /** c_decl.e:1291		if datetime:diff(d1, d2) < 0 then*/

    /** datetime.e:1253		return datetimeToSeconds(dt2) - datetimeToSeconds(dt1)*/
    Ref(_d2_44758);
    _0 = _diff_1__tmp_at42_44768;
    _diff_1__tmp_at42_44768 = _18datetimeToSeconds(_d2_44758);
    DeRef(_0);
    Ref(_d1_44755);
    _0 = _diff_2__tmp_at42_44769;
    _diff_2__tmp_at42_44769 = _18datetimeToSeconds(_d1_44755);
    DeRef(_0);
    DeRef(_diff_inlined_diff_at_42_44767);
    if (IS_ATOM_INT(_diff_1__tmp_at42_44768) && IS_ATOM_INT(_diff_2__tmp_at42_44769)) {
        _diff_inlined_diff_at_42_44767 = _diff_1__tmp_at42_44768 - _diff_2__tmp_at42_44769;
        if ((object)((uintptr_t)_diff_inlined_diff_at_42_44767 +(uintptr_t) HIGH_BITS) >= 0){
            _diff_inlined_diff_at_42_44767 = NewDouble((eudouble)_diff_inlined_diff_at_42_44767);
        }
    }
    else {
        _diff_inlined_diff_at_42_44767 = binary_op(MINUS, _diff_1__tmp_at42_44768, _diff_2__tmp_at42_44769);
    }
    DeRef(_diff_1__tmp_at42_44768);
    _diff_1__tmp_at42_44768 = NOVALUE;
    DeRef(_diff_2__tmp_at42_44769);
    _diff_2__tmp_at42_44769 = NOVALUE;
    if (binary_op_a(GREATEREQ, _diff_inlined_diff_at_42_44767, 0)){
        goto L3; // [58] 69
    }

    /** c_decl.e:1292			return 1*/
    DeRefDS(_f1_44753);
    DeRefDS(_f2_44754);
    DeRef(_d1_44755);
    DeRef(_d2_44758);
    return 1;
L3: 

    /** c_decl.e:1295		return 0*/
    DeRefDS(_f1_44753);
    DeRefDS(_f2_44754);
    DeRef(_d1_44755);
    DeRef(_d2_44758);
    return 0;
    ;
}


void _58add_file(object _filename_44773, object _eu_filename_44774)
{
    object _obj_fname_44794 = NOVALUE;
    object _src_fname_44795 = NOVALUE;
    object _23342 = NOVALUE;
    object _23341 = NOVALUE;
    object _23328 = NOVALUE;
    object _23327 = NOVALUE;
    object _23324 = NOVALUE;
    object _23323 = NOVALUE;
    object _23322 = NOVALUE;
    object _23321 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:1303		if equal("c", fileext(filename)) then*/
    RefDS(_filename_44773);
    _23321 = _17fileext(_filename_44773);
    if (_23320 == _23321)
    _23322 = 1;
    else if (IS_ATOM_INT(_23320) && IS_ATOM_INT(_23321))
    _23322 = 0;
    else
    _23322 = (compare(_23320, _23321) == 0);
    DeRef(_23321);
    _23321 = NOVALUE;
    if (_23322 == 0)
    {
        _23322 = NOVALUE;
        goto L1; // [15] 35
    }
    else{
        _23322 = NOVALUE;
    }

    /** c_decl.e:1304			filename = filename[1..$-2]*/
    if (IS_SEQUENCE(_filename_44773)){
            _23323 = SEQ_PTR(_filename_44773)->length;
    }
    else {
        _23323 = 1;
    }
    _23324 = _23323 - 2;
    _23323 = NOVALUE;
    rhs_slice_target = (object_ptr)&_filename_44773;
    RHS_Slice(_filename_44773, 1, _23324);
    goto L2; // [32] 82
L1: 

    /** c_decl.e:1305		elsif equal("h", fileext(filename)) then*/
    RefDS(_filename_44773);
    _23327 = _17fileext(_filename_44773);
    if (_23326 == _23327)
    _23328 = 1;
    else if (IS_ATOM_INT(_23326) && IS_ATOM_INT(_23327))
    _23328 = 0;
    else
    _23328 = (compare(_23326, _23327) == 0);
    DeRef(_23327);
    _23327 = NOVALUE;
    if (_23328 == 0)
    {
        _23328 = NOVALUE;
        goto L3; // [45] 81
    }
    else{
        _23328 = NOVALUE;
    }

    /** c_decl.e:1306			generated_files = append(generated_files, filename)*/
    RefDS(_filename_44773);
    Append(&_58generated_files_42897, _58generated_files_42897, _filename_44773);

    /** c_decl.e:1307			if build_system_type = BUILD_DIRECT then*/
    if (_56build_system_type_45705 != 3)
    goto L4; // [62] 75

    /** c_decl.e:1308				outdated_files  = append(outdated_files, 0)*/
    Append(&_58outdated_files_42898, _58outdated_files_42898, 0);
L4: 

    /** c_decl.e:1311			return*/
    DeRefDS(_filename_44773);
    DeRefDS(_eu_filename_44774);
    DeRef(_obj_fname_44794);
    DeRef(_src_fname_44795);
    DeRef(_23324);
    _23324 = NOVALUE;
    return;
L3: 
L2: 

    /** c_decl.e:1314		sequence obj_fname = filename, src_fname = filename & ".c"*/
    RefDS(_filename_44773);
    DeRef(_obj_fname_44794);
    _obj_fname_44794 = _filename_44773;
    Concat((object_ptr)&_src_fname_44795, _filename_44773, _23291);

    /** c_decl.e:1316		if compiler_type = COMPILER_WATCOM then*/
    if (_56compiler_type_45709 != 2)
    goto L5; // [99] 112

    /** c_decl.e:1317			obj_fname &= ".obj"*/
    Concat((object_ptr)&_obj_fname_44794, _obj_fname_44794, _23334);
    goto L6; // [109] 119
L5: 

    /** c_decl.e:1319			obj_fname &= ".o"*/
    Concat((object_ptr)&_obj_fname_44794, _obj_fname_44794, _23336);
L6: 

    /** c_decl.e:1322		generated_files = append(generated_files, src_fname)*/
    RefDS(_src_fname_44795);
    Append(&_58generated_files_42897, _58generated_files_42897, _src_fname_44795);

    /** c_decl.e:1323		generated_files = append(generated_files, obj_fname)*/
    RefDS(_obj_fname_44794);
    Append(&_58generated_files_42897, _58generated_files_42897, _obj_fname_44794);

    /** c_decl.e:1324		if build_system_type = BUILD_DIRECT then*/
    if (_56build_system_type_45705 != 3)
    goto L7; // [141] 173

    /** c_decl.e:1325			outdated_files  = append(outdated_files, is_file_newer(eu_filename, output_dir & src_fname))*/
    Concat((object_ptr)&_23341, _58output_dir_42907, _src_fname_44795);
    RefDS(_eu_filename_44774);
    _23342 = _58is_file_newer(_eu_filename_44774, _23341);
    _23341 = NOVALUE;
    Ref(_23342);
    Append(&_58outdated_files_42898, _58outdated_files_42898, _23342);
    DeRef(_23342);
    _23342 = NOVALUE;

    /** c_decl.e:1326			outdated_files  = append(outdated_files, 0)*/
    Append(&_58outdated_files_42898, _58outdated_files_42898, 0);
L7: 

    /** c_decl.e:1328	end procedure*/
    DeRefDS(_filename_44773);
    DeRefDS(_eu_filename_44774);
    DeRef(_obj_fname_44794);
    DeRef(_src_fname_44795);
    DeRef(_23324);
    _23324 = NOVALUE;
    return;
    ;
}


object _58any_code(object _file_no_44818)
{
    object _these_routines_44820 = NOVALUE;
    object _s_44827 = NOVALUE;
    object _23358 = NOVALUE;
    object _23357 = NOVALUE;
    object _23356 = NOVALUE;
    object _23355 = NOVALUE;
    object _23354 = NOVALUE;
    object _23353 = NOVALUE;
    object _23352 = NOVALUE;
    object _23351 = NOVALUE;
    object _23350 = NOVALUE;
    object _23349 = NOVALUE;
    object _23348 = NOVALUE;
    object _23346 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:1334		check_file_routines()*/
    _58check_file_routines();

    /** c_decl.e:1336		sequence these_routines = file_routines[file_no]*/
    DeRef(_these_routines_44820);
    _2 = (object)SEQ_PTR(_58file_routines_45045);
    _these_routines_44820 = (object)*(((s1_ptr)_2)->base + _file_no_44818);
    Ref(_these_routines_44820);

    /** c_decl.e:1337		for i = 1 to length( these_routines ) do*/
    if (IS_SEQUENCE(_these_routines_44820)){
            _23346 = SEQ_PTR(_these_routines_44820)->length;
    }
    else {
        _23346 = 1;
    }
    {
        object _i_44824;
        _i_44824 = 1;
L1: 
        if (_i_44824 > _23346){
            goto L2; // [22] 126
        }

        /** c_decl.e:1338			symtab_index s = these_routines[i]*/
        _2 = (object)SEQ_PTR(_these_routines_44820);
        _s_44827 = (object)*(((s1_ptr)_2)->base + _i_44824);
        if (!IS_ATOM_INT(_s_44827)){
            _s_44827 = (object)DBL_PTR(_s_44827)->dbl;
        }

        /** c_decl.e:1339			if SymTab[s][S_FILE_NO] = file_no and*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _23348 = (object)*(((s1_ptr)_2)->base + _s_44827);
        _2 = (object)SEQ_PTR(_23348);
        if (!IS_ATOM_INT(_36S_FILE_NO_21400)){
            _23349 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21400)->dbl));
        }
        else{
            _23349 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21400);
        }
        _23348 = NOVALUE;
        if (IS_ATOM_INT(_23349)) {
            _23350 = (_23349 == _file_no_44818);
        }
        else {
            _23350 = binary_op(EQUALS, _23349, _file_no_44818);
        }
        _23349 = NOVALUE;
        if (IS_ATOM_INT(_23350)) {
            if (_23350 == 0) {
                DeRef(_23351);
                _23351 = 0;
                goto L3; // [55] 81
            }
        }
        else {
            if (DBL_PTR(_23350)->dbl == 0.0) {
                DeRef(_23351);
                _23351 = 0;
                goto L3; // [55] 81
            }
        }
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _23352 = (object)*(((s1_ptr)_2)->base + _s_44827);
        _2 = (object)SEQ_PTR(_23352);
        _23353 = (object)*(((s1_ptr)_2)->base + 5);
        _23352 = NOVALUE;
        if (IS_ATOM_INT(_23353)) {
            _23354 = (_23353 != 99);
        }
        else {
            _23354 = binary_op(NOTEQ, _23353, 99);
        }
        _23353 = NOVALUE;
        DeRef(_23351);
        if (IS_ATOM_INT(_23354))
        _23351 = (_23354 != 0);
        else
        _23351 = DBL_PTR(_23354)->dbl != 0.0;
L3: 
        if (_23351 == 0) {
            goto L4; // [81] 117
        }
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _23356 = (object)*(((s1_ptr)_2)->base + _s_44827);
        _2 = (object)SEQ_PTR(_23356);
        if (!IS_ATOM_INT(_36S_TOKEN_21409)){
            _23357 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21409)->dbl));
        }
        else{
            _23357 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21409);
        }
        _23356 = NOVALUE;
        _23358 = find_from(_23357, _38RTN_TOKS_16291, 1);
        _23357 = NOVALUE;
        if (_23358 == 0)
        {
            _23358 = NOVALUE;
            goto L4; // [105] 117
        }
        else{
            _23358 = NOVALUE;
        }

        /** c_decl.e:1342				return TRUE -- found a non-deleted routine in this file*/
        DeRef(_these_routines_44820);
        DeRef(_23350);
        _23350 = NOVALUE;
        DeRef(_23354);
        _23354 = NOVALUE;
        return _13TRUE_447;
L4: 

        /** c_decl.e:1344		end for*/
        _i_44824 = _i_44824 + 1;
        goto L1; // [121] 29
L2: 
        ;
    }

    /** c_decl.e:1345		return FALSE*/
    DeRef(_these_routines_44820);
    DeRef(_23350);
    _23350 = NOVALUE;
    DeRef(_23354);
    _23354 = NOVALUE;
    return _13FALSE_445;
    ;
}


void _58check_file_routines()
{
    object _s_45054 = NOVALUE;
    object _23520 = NOVALUE;
    object _23519 = NOVALUE;
    object _23518 = NOVALUE;
    object _23517 = NOVALUE;
    object _23516 = NOVALUE;
    object _23515 = NOVALUE;
    object _23514 = NOVALUE;
    object _23513 = NOVALUE;
    object _23512 = NOVALUE;
    object _23511 = NOVALUE;
    object _23510 = NOVALUE;
    object _23509 = NOVALUE;
    object _23507 = NOVALUE;
    object _23505 = NOVALUE;
    object _23503 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:1451		if not length( file_routines ) then*/
    if (IS_SEQUENCE(_58file_routines_45045)){
            _23503 = SEQ_PTR(_58file_routines_45045)->length;
    }
    else {
        _23503 = 1;
    }
    if (_23503 != 0)
    goto L1; // [8] 146
    _23503 = NOVALUE;

    /** c_decl.e:1452			file_routines = repeat( {}, length( known_files ) )*/
    if (IS_SEQUENCE(_37known_files_15638)){
            _23505 = SEQ_PTR(_37known_files_15638)->length;
    }
    else {
        _23505 = 1;
    }
    DeRefDS(_58file_routines_45045);
    _58file_routines_45045 = Repeat(_22190, _23505);
    _23505 = NOVALUE;

    /** c_decl.e:1453			integer s = SymTab[TopLevelSub][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _23507 = (object)*(((s1_ptr)_2)->base + _36TopLevelSub_21774);
    _2 = (object)SEQ_PTR(_23507);
    _s_45054 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_45054)){
        _s_45054 = (object)DBL_PTR(_s_45054)->dbl;
    }
    _23507 = NOVALUE;

    /** c_decl.e:1454			while s do*/
L2: 
    if (_s_45054 == 0)
    {
        goto L3; // [45] 145
    }
    else{
    }

    /** c_decl.e:1455				if SymTab[s][S_USAGE] != U_DELETED and*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _23509 = (object)*(((s1_ptr)_2)->base + _s_45054);
    _2 = (object)SEQ_PTR(_23509);
    _23510 = (object)*(((s1_ptr)_2)->base + 5);
    _23509 = NOVALUE;
    if (IS_ATOM_INT(_23510)) {
        _23511 = (_23510 != 99);
    }
    else {
        _23511 = binary_op(NOTEQ, _23510, 99);
    }
    _23510 = NOVALUE;
    if (IS_ATOM_INT(_23511)) {
        if (_23511 == 0) {
            goto L4; // [68] 124
        }
    }
    else {
        if (DBL_PTR(_23511)->dbl == 0.0) {
            goto L4; // [68] 124
        }
    }
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _23513 = (object)*(((s1_ptr)_2)->base + _s_45054);
    _2 = (object)SEQ_PTR(_23513);
    if (!IS_ATOM_INT(_36S_TOKEN_21409)){
        _23514 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21409)->dbl));
    }
    else{
        _23514 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21409);
    }
    _23513 = NOVALUE;
    _23515 = find_from(_23514, _38RTN_TOKS_16291, 1);
    _23514 = NOVALUE;
    if (_23515 == 0)
    {
        _23515 = NOVALUE;
        goto L4; // [92] 124
    }
    else{
        _23515 = NOVALUE;
    }

    /** c_decl.e:1458					file_routines[SymTab[s][S_FILE_NO]] &= s*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _23516 = (object)*(((s1_ptr)_2)->base + _s_45054);
    _2 = (object)SEQ_PTR(_23516);
    if (!IS_ATOM_INT(_36S_FILE_NO_21400)){
        _23517 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21400)->dbl));
    }
    else{
        _23517 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21400);
    }
    _23516 = NOVALUE;
    _2 = (object)SEQ_PTR(_58file_routines_45045);
    if (!IS_ATOM_INT(_23517)){
        _23518 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_23517)->dbl));
    }
    else{
        _23518 = (object)*(((s1_ptr)_2)->base + _23517);
    }
    if (IS_SEQUENCE(_23518) && IS_ATOM(_s_45054)) {
        Append(&_23519, _23518, _s_45054);
    }
    else if (IS_ATOM(_23518) && IS_SEQUENCE(_s_45054)) {
    }
    else {
        Concat((object_ptr)&_23519, _23518, _s_45054);
        _23518 = NOVALUE;
    }
    _23518 = NOVALUE;
    _2 = (object)SEQ_PTR(_58file_routines_45045);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _58file_routines_45045 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_23517))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_23517)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _23517);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _23519;
    if( _1 != _23519 ){
        DeRef(_1);
    }
    _23519 = NOVALUE;
L4: 

    /** c_decl.e:1460				s = SymTab[s][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _23520 = (object)*(((s1_ptr)_2)->base + _s_45054);
    _2 = (object)SEQ_PTR(_23520);
    _s_45054 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_45054)){
        _s_45054 = (object)DBL_PTR(_s_45054)->dbl;
    }
    _23520 = NOVALUE;

    /** c_decl.e:1461			end while*/
    goto L2; // [142] 45
L3: 
L1: 

    /** c_decl.e:1464	end procedure*/
    DeRef(_23511);
    _23511 = NOVALUE;
    _23517 = NOVALUE;
    return;
    ;
}


void _58GenerateUserRoutines()
{
    object _s_45088 = NOVALUE;
    object _sp_45089 = NOVALUE;
    object _next_c_char_45090 = NOVALUE;
    object _q_45091 = NOVALUE;
    object _temps_45092 = NOVALUE;
    object _buff_45093 = NOVALUE;
    object _base_name_45094 = NOVALUE;
    object _long_c_file_45095 = NOVALUE;
    object _c_file_45096 = NOVALUE;
    object _these_routines_45167 = NOVALUE;
    object _ret_type_45225 = NOVALUE;
    object _s_scope_45234 = NOVALUE;
    object _s_file_45237 = NOVALUE;
    object _scope_45314 = NOVALUE;
    object _names_45348 = NOVALUE;
    object _name_45358 = NOVALUE;
    object _23756 = NOVALUE;
    object _23754 = NOVALUE;
    object _23753 = NOVALUE;
    object _23752 = NOVALUE;
    object _23751 = NOVALUE;
    object _23750 = NOVALUE;
    object _23749 = NOVALUE;
    object _23747 = NOVALUE;
    object _23745 = NOVALUE;
    object _23744 = NOVALUE;
    object _23741 = NOVALUE;
    object _23739 = NOVALUE;
    object _23738 = NOVALUE;
    object _23737 = NOVALUE;
    object _23736 = NOVALUE;
    object _23735 = NOVALUE;
    object _23734 = NOVALUE;
    object _23732 = NOVALUE;
    object _23728 = NOVALUE;
    object _23726 = NOVALUE;
    object _23725 = NOVALUE;
    object _23724 = NOVALUE;
    object _23723 = NOVALUE;
    object _23721 = NOVALUE;
    object _23720 = NOVALUE;
    object _23718 = NOVALUE;
    object _23717 = NOVALUE;
    object _23715 = NOVALUE;
    object _23714 = NOVALUE;
    object _23713 = NOVALUE;
    object _23712 = NOVALUE;
    object _23710 = NOVALUE;
    object _23708 = NOVALUE;
    object _23707 = NOVALUE;
    object _23706 = NOVALUE;
    object _23705 = NOVALUE;
    object _23704 = NOVALUE;
    object _23703 = NOVALUE;
    object _23702 = NOVALUE;
    object _23700 = NOVALUE;
    object _23699 = NOVALUE;
    object _23698 = NOVALUE;
    object _23697 = NOVALUE;
    object _23696 = NOVALUE;
    object _23695 = NOVALUE;
    object _23694 = NOVALUE;
    object _23693 = NOVALUE;
    object _23691 = NOVALUE;
    object _23690 = NOVALUE;
    object _23688 = NOVALUE;
    object _23687 = NOVALUE;
    object _23686 = NOVALUE;
    object _23685 = NOVALUE;
    object _23684 = NOVALUE;
    object _23683 = NOVALUE;
    object _23682 = NOVALUE;
    object _23681 = NOVALUE;
    object _23679 = NOVALUE;
    object _23678 = NOVALUE;
    object _23676 = NOVALUE;
    object _23675 = NOVALUE;
    object _23674 = NOVALUE;
    object _23672 = NOVALUE;
    object _23667 = NOVALUE;
    object _23666 = NOVALUE;
    object _23664 = NOVALUE;
    object _23662 = NOVALUE;
    object _23656 = NOVALUE;
    object _23655 = NOVALUE;
    object _23654 = NOVALUE;
    object _23653 = NOVALUE;
    object _23652 = NOVALUE;
    object _23651 = NOVALUE;
    object _23650 = NOVALUE;
    object _23649 = NOVALUE;
    object _23647 = NOVALUE;
    object _23646 = NOVALUE;
    object _23644 = NOVALUE;
    object _23643 = NOVALUE;
    object _23640 = NOVALUE;
    object _23638 = NOVALUE;
    object _23637 = NOVALUE;
    object _23636 = NOVALUE;
    object _23632 = NOVALUE;
    object _23629 = NOVALUE;
    object _23626 = NOVALUE;
    object _23625 = NOVALUE;
    object _23624 = NOVALUE;
    object _23623 = NOVALUE;
    object _23621 = NOVALUE;
    object _23620 = NOVALUE;
    object _23618 = NOVALUE;
    object _23617 = NOVALUE;
    object _23616 = NOVALUE;
    object _23614 = NOVALUE;
    object _23611 = NOVALUE;
    object _23610 = NOVALUE;
    object _23609 = NOVALUE;
    object _23608 = NOVALUE;
    object _23607 = NOVALUE;
    object _23606 = NOVALUE;
    object _23605 = NOVALUE;
    object _23604 = NOVALUE;
    object _23603 = NOVALUE;
    object _23602 = NOVALUE;
    object _23601 = NOVALUE;
    object _23600 = NOVALUE;
    object _23599 = NOVALUE;
    object _23598 = NOVALUE;
    object _23597 = NOVALUE;
    object _23595 = NOVALUE;
    object _23592 = NOVALUE;
    object _23591 = NOVALUE;
    object _23589 = NOVALUE;
    object _23586 = NOVALUE;
    object _23585 = NOVALUE;
    object _23581 = NOVALUE;
    object _23580 = NOVALUE;
    object _23578 = NOVALUE;
    object _23574 = NOVALUE;
    object _23573 = NOVALUE;
    object _23572 = NOVALUE;
    object _23571 = NOVALUE;
    object _23570 = NOVALUE;
    object _23569 = NOVALUE;
    object _23568 = NOVALUE;
    object _23567 = NOVALUE;
    object _23566 = NOVALUE;
    object _23565 = NOVALUE;
    object _23564 = NOVALUE;
    object _23563 = NOVALUE;
    object _23562 = NOVALUE;
    object _23561 = NOVALUE;
    object _23559 = NOVALUE;
    object _23558 = NOVALUE;
    object _23556 = NOVALUE;
    object _23553 = NOVALUE;
    object _23550 = NOVALUE;
    object _23547 = NOVALUE;
    object _23544 = NOVALUE;
    object _23543 = NOVALUE;
    object _23542 = NOVALUE;
    object _23539 = NOVALUE;
    object _23536 = NOVALUE;
    object _23534 = NOVALUE;
    object _23530 = NOVALUE;
    object _23529 = NOVALUE;
    object _23527 = NOVALUE;
    object _23526 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** c_decl.e:1468		integer next_c_char, q, temps*/

    /** c_decl.e:1469		sequence buff, base_name, long_c_file, c_file*/

    /** c_decl.e:1471		if not silent then*/
    if (_36silent_21886 != 0)
    goto L1; // [9] 68

    /** c_decl.e:1472			if Pass = 1 then*/
    if (_58Pass_42882 != 1)
    goto L2; // [16] 31

    /** c_decl.e:1473				ShowMsg(1, TRANSLATING_CODE_PASS,,0)*/
    RefDS(_22190);
    _39ShowMsg(1, 239, _22190, 0);
L2: 

    /** c_decl.e:1476			if LAST_PASS = TRUE then*/
    if (_58LAST_PASS_42880 != _13TRUE_447)
    goto L3; // [37] 54

    /** c_decl.e:1477				ShowMsg(1, MSG__GENERATING)*/
    RefDS(_22190);
    _39ShowMsg(1, 240, _22190, 1);
    goto L4; // [51] 67
L3: 

    /** c_decl.e:1479				ShowMsg(1, MSG_1, Pass, 0)*/
    _39ShowMsg(1, 241, _58Pass_42882, 0);
L4: 
L1: 

    /** c_decl.e:1483		check_file_routines()*/
    _58check_file_routines();

    /** c_decl.e:1485		c_puts("// GenerateUserRoutines\n")*/
    RefDS(_23525);
    _55c_puts(_23525);

    /** c_decl.e:1486		for file_no = 1 to length(known_files) do*/
    if (IS_SEQUENCE(_37known_files_15638)){
            _23526 = SEQ_PTR(_37known_files_15638)->length;
    }
    else {
        _23526 = 1;
    }
    {
        object _file_no_45115;
        _file_no_45115 = 1;
L5: 
        if (_file_no_45115 > _23526){
            goto L6; // [84] 2208
        }

        /** c_decl.e:1487			if file_no = 1 or any_code(file_no) then*/
        _23527 = (_file_no_45115 == 1);
        if (_23527 != 0) {
            goto L7; // [97] 110
        }
        _23529 = _58any_code(_file_no_45115);
        if (_23529 == 0) {
            DeRef(_23529);
            _23529 = NOVALUE;
            goto L8; // [106] 2199
        }
        else {
            if (!IS_ATOM_INT(_23529) && DBL_PTR(_23529)->dbl == 0.0){
                DeRef(_23529);
                _23529 = NOVALUE;
                goto L8; // [106] 2199
            }
            DeRef(_23529);
            _23529 = NOVALUE;
        }
        DeRef(_23529);
        _23529 = NOVALUE;
L7: 

        /** c_decl.e:1490				next_c_char = 1*/
        _next_c_char_45090 = 1;

        /** c_decl.e:1491				base_name = name_ext(known_files[file_no])*/
        _2 = (object)SEQ_PTR(_37known_files_15638);
        _23530 = (object)*(((s1_ptr)_2)->base + _file_no_45115);
        Ref(_23530);
        _0 = _base_name_45094;
        _base_name_45094 = _54name_ext(_23530);
        DeRef(_0);
        _23530 = NOVALUE;

        /** c_decl.e:1492				c_file = base_name*/
        RefDS(_base_name_45094);
        DeRef(_c_file_45096);
        _c_file_45096 = _base_name_45094;

        /** c_decl.e:1494				q = length(c_file)*/
        if (IS_SEQUENCE(_c_file_45096)){
                _q_45091 = SEQ_PTR(_c_file_45096)->length;
        }
        else {
            _q_45091 = 1;
        }

        /** c_decl.e:1495				while q >= 1 do*/
L9: 
        if (_q_45091 < 1)
        goto LA; // [146] 187

        /** c_decl.e:1496					if c_file[q] = '.' then*/
        _2 = (object)SEQ_PTR(_c_file_45096);
        _23534 = (object)*(((s1_ptr)_2)->base + _q_45091);
        if (binary_op_a(NOTEQ, _23534, 46)){
            _23534 = NOVALUE;
            goto LB; // [156] 176
        }
        _23534 = NOVALUE;

        /** c_decl.e:1497						c_file = c_file[1..q-1]*/
        _23536 = _q_45091 - 1;
        rhs_slice_target = (object_ptr)&_c_file_45096;
        RHS_Slice(_c_file_45096, 1, _23536);

        /** c_decl.e:1498						exit*/
        goto LA; // [173] 187
LB: 

        /** c_decl.e:1500					q -= 1*/
        _q_45091 = _q_45091 - 1;

        /** c_decl.e:1501				end while*/
        goto L9; // [184] 146
LA: 

        /** c_decl.e:1503				if find(lower(c_file), {"main-", "init-"})  then*/
        RefDS(_c_file_45096);
        _23539 = _14lower(_c_file_45096);
        RefDS(_23541);
        RefDS(_23540);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _23540;
        ((intptr_t *)_2)[2] = _23541;
        _23542 = MAKE_SEQ(_1);
        _23543 = find_from(_23539, _23542, 1);
        DeRef(_23539);
        _23539 = NOVALUE;
        DeRefDS(_23542);
        _23542 = NOVALUE;
        if (_23543 == 0)
        {
            _23543 = NOVALUE;
            goto LC; // [202] 219
        }
        else{
            _23543 = NOVALUE;
        }

        /** c_decl.e:1504					CompileErr(MSG_1_CONFLICTS_WITH_A_FILE_NAME_USED_INTERNALLY_BY_THE_TRANSLATOR, {base_name})*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_base_name_45094);
        ((intptr_t*)_2)[1] = _base_name_45094;
        _23544 = MAKE_SEQ(_1);
        _50CompileErr(12, _23544, 0);
        _23544 = NOVALUE;
LC: 

        /** c_decl.e:1507				long_c_file = c_file*/
        RefDS(_c_file_45096);
        DeRef(_long_c_file_45095);
        _long_c_file_45095 = _c_file_45096;

        /** c_decl.e:1508				if LAST_PASS = TRUE then*/
        if (_58LAST_PASS_42880 != _13TRUE_447)
        goto LD; // [232] 257

        /** c_decl.e:1509					c_file = unique_c_name(c_file)*/
        RefDS(_c_file_45096);
        _0 = _c_file_45096;
        _c_file_45096 = _58unique_c_name(_c_file_45096);
        DeRefDS(_0);

        /** c_decl.e:1510					add_file(c_file, known_files[file_no])*/
        _2 = (object)SEQ_PTR(_37known_files_15638);
        _23547 = (object)*(((s1_ptr)_2)->base + _file_no_45115);
        RefDS(_c_file_45096);
        Ref(_23547);
        _58add_file(_c_file_45096, _23547);
        _23547 = NOVALUE;
LD: 

        /** c_decl.e:1513				if file_no = 1 then*/
        if (_file_no_45115 != 1)
        goto LE; // [259] 322

        /** c_decl.e:1515					if LAST_PASS = TRUE then*/
        if (_58LAST_PASS_42880 != _13TRUE_447)
        goto LF; // [269] 314

        /** c_decl.e:1516						add_file("main-")*/
        RefDS(_23540);
        RefDS(_22190);
        _58add_file(_23540, _22190);

        /** c_decl.e:1517						for i = 0 to main_name_num-1 do*/
        _23550 = _55main_name_num_46978 - 1;
        if ((object)((uintptr_t)_23550 +(uintptr_t) HIGH_BITS) >= 0){
            _23550 = NewDouble((eudouble)_23550);
        }
        {
            object _i_45157;
            _i_45157 = 0;
L10: 
            if (binary_op_a(GREATER, _i_45157, _23550)){
                goto L11; // [287] 313
            }

            /** c_decl.e:1518							buff = sprintf("main-%d", i)*/
            DeRefi(_buff_45093);
            _buff_45093 = EPrintf(-9999999, _23551, _i_45157);

            /** c_decl.e:1519							add_file(buff)*/
            RefDS(_buff_45093);
            RefDS(_22190);
            _58add_file(_buff_45093, _22190);

            /** c_decl.e:1520						end for*/
            _0 = _i_45157;
            if (IS_ATOM_INT(_i_45157)) {
                _i_45157 = _i_45157 + 1;
                if ((object)((uintptr_t)_i_45157 +(uintptr_t) HIGH_BITS) >= 0){
                    _i_45157 = NewDouble((eudouble)_i_45157);
                }
            }
            else {
                _i_45157 = binary_op_a(PLUS, _i_45157, 1);
            }
            DeRef(_0);
            goto L10; // [308] 294
L11: 
            ;
            DeRef(_i_45157);
        }
LF: 

        /** c_decl.e:1523					file0 = long_c_file*/
        RefDS(_long_c_file_45095);
        DeRef(_58file0_44851);
        _58file0_44851 = _long_c_file_45095;
LE: 

        /** c_decl.e:1526				new_c_file(c_file)*/
        RefDS(_c_file_45096);
        _58new_c_file(_c_file_45096);

        /** c_decl.e:1528				s = SymTab[TopLevelSub][S_NEXT]*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _23553 = (object)*(((s1_ptr)_2)->base + _36TopLevelSub_21774);
        _2 = (object)SEQ_PTR(_23553);
        _s_45088 = (object)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_s_45088)){
            _s_45088 = (object)DBL_PTR(_s_45088)->dbl;
        }
        _23553 = NOVALUE;

        /** c_decl.e:1530				sequence these_routines = file_routines[file_no]*/
        DeRef(_these_routines_45167);
        _2 = (object)SEQ_PTR(_58file_routines_45045);
        _these_routines_45167 = (object)*(((s1_ptr)_2)->base + _file_no_45115);
        Ref(_these_routines_45167);

        /** c_decl.e:1531				for routine_no = 1 to length( these_routines ) do*/
        if (IS_SEQUENCE(_these_routines_45167)){
                _23556 = SEQ_PTR(_these_routines_45167)->length;
        }
        else {
            _23556 = 1;
        }
        {
            object _routine_no_45170;
            _routine_no_45170 = 1;
L12: 
            if (_routine_no_45170 > _23556){
                goto L13; // [360] 2198
            }

            /** c_decl.e:1532					s = these_routines[routine_no]*/
            _2 = (object)SEQ_PTR(_these_routines_45167);
            _s_45088 = (object)*(((s1_ptr)_2)->base + _routine_no_45170);
            if (!IS_ATOM_INT(_s_45088)){
                _s_45088 = (object)DBL_PTR(_s_45088)->dbl;
            }

            /** c_decl.e:1533					if SymTab[s][S_USAGE] != U_DELETED then*/
            _2 = (object)SEQ_PTR(_37SymTab_15637);
            _23558 = (object)*(((s1_ptr)_2)->base + _s_45088);
            _2 = (object)SEQ_PTR(_23558);
            _23559 = (object)*(((s1_ptr)_2)->base + 5);
            _23558 = NOVALUE;
            if (binary_op_a(EQUALS, _23559, 99)){
                _23559 = NOVALUE;
                goto L14; // [391] 2189
            }
            _23559 = NOVALUE;

            /** c_decl.e:1537						if LAST_PASS = TRUE and*/
            _23561 = (_58LAST_PASS_42880 == _13TRUE_447);
            if (_23561 == 0) {
                goto L15; // [405] 601
            }
            _23563 = (_36cfile_size_21850 > _56max_cfile_size_45725);
            if (_23563 != 0) {
                DeRef(_23564);
                _23564 = 1;
                goto L16; // [417] 480
            }
            _23565 = (_s_45088 != _36TopLevelSub_21774);
            if (_23565 == 0) {
                _23566 = 0;
                goto L17; // [427] 447
            }
            _23567 = (_56max_cfile_size_45725 % 4) ? NewDouble((eudouble)_56max_cfile_size_45725 / 4) : (_56max_cfile_size_45725 / 4);
            if (IS_ATOM_INT(_23567)) {
                _23568 = (_36cfile_size_21850 > _23567);
            }
            else {
                _23568 = ((eudouble)_36cfile_size_21850 > DBL_PTR(_23567)->dbl);
            }
            DeRef(_23567);
            _23567 = NOVALUE;
            _23566 = (_23568 != 0);
L17: 
            if (_23566 == 0) {
                _23569 = 0;
                goto L18; // [447] 476
            }
            _2 = (object)SEQ_PTR(_37SymTab_15637);
            _23570 = (object)*(((s1_ptr)_2)->base + _s_45088);
            _2 = (object)SEQ_PTR(_23570);
            if (!IS_ATOM_INT(_36S_CODE_21416)){
                _23571 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21416)->dbl));
            }
            else{
                _23571 = (object)*(((s1_ptr)_2)->base + _36S_CODE_21416);
            }
            _23570 = NOVALUE;
            if (IS_SEQUENCE(_23571)){
                    _23572 = SEQ_PTR(_23571)->length;
            }
            else {
                _23572 = 1;
            }
            _23571 = NOVALUE;
            _23573 = (_23572 > _56max_cfile_size_45725);
            _23572 = NOVALUE;
            _23569 = (_23573 != 0);
L18: 
            DeRef(_23564);
            _23564 = (_23569 != 0);
L16: 
            if (_23564 == 0)
            {
                _23564 = NOVALUE;
                goto L15; // [481] 601
            }
            else{
                _23564 = NOVALUE;
            }

            /** c_decl.e:1546							if length(c_file) = 7 then*/
            if (IS_SEQUENCE(_c_file_45096)){
                    _23574 = SEQ_PTR(_c_file_45096)->length;
            }
            else {
                _23574 = 1;
            }
            if (_23574 != 7)
            goto L19; // [489] 500

            /** c_decl.e:1548								c_file &= " "*/
            Concat((object_ptr)&_c_file_45096, _c_file_45096, _23576);
L19: 

            /** c_decl.e:1551							if length(c_file) >= 8 then*/
            if (IS_SEQUENCE(_c_file_45096)){
                    _23578 = SEQ_PTR(_c_file_45096)->length;
            }
            else {
                _23578 = 1;
            }
            if (_23578 < 8)
            goto L1A; // [505] 528

            /** c_decl.e:1552								c_file[7] = '_'*/
            _2 = (object)SEQ_PTR(_c_file_45096);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _c_file_45096 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + 7);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = 95;
            DeRef(_1);

            /** c_decl.e:1553								c_file[8] = file_chars[next_c_char]*/
            _2 = (object)SEQ_PTR(_58file_chars_44716);
            _23580 = (object)*(((s1_ptr)_2)->base + _next_c_char_45090);
            Ref(_23580);
            _2 = (object)SEQ_PTR(_c_file_45096);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _c_file_45096 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + 8);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _23580;
            if( _1 != _23580 ){
                DeRef(_1);
            }
            _23580 = NOVALUE;
            goto L1B; // [525] 560
L1A: 

            /** c_decl.e:1556								if find('_', c_file) = 0 then*/
            _23581 = find_from(95, _c_file_45096, 1);
            if (_23581 != 0)
            goto L1C; // [535] 546

            /** c_decl.e:1557									c_file &= "_ "*/
            Concat((object_ptr)&_c_file_45096, _c_file_45096, _23583);
L1C: 

            /** c_decl.e:1560								c_file[$] = file_chars[next_c_char]*/
            if (IS_SEQUENCE(_c_file_45096)){
                    _23585 = SEQ_PTR(_c_file_45096)->length;
            }
            else {
                _23585 = 1;
            }
            _2 = (object)SEQ_PTR(_58file_chars_44716);
            _23586 = (object)*(((s1_ptr)_2)->base + _next_c_char_45090);
            Ref(_23586);
            _2 = (object)SEQ_PTR(_c_file_45096);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _c_file_45096 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + _23585);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _23586;
            if( _1 != _23586 ){
                DeRef(_1);
            }
            _23586 = NOVALUE;
L1B: 

            /** c_decl.e:1564							c_file = unique_c_name(c_file)*/
            RefDS(_c_file_45096);
            _0 = _c_file_45096;
            _c_file_45096 = _58unique_c_name(_c_file_45096);
            DeRefDS(_0);

            /** c_decl.e:1565							new_c_file(c_file)*/
            RefDS(_c_file_45096);
            _58new_c_file(_c_file_45096);

            /** c_decl.e:1567							next_c_char += 1*/
            _next_c_char_45090 = _next_c_char_45090 + 1;

            /** c_decl.e:1568							if next_c_char > length(file_chars) then*/
            if (IS_SEQUENCE(_58file_chars_44716)){
                    _23589 = SEQ_PTR(_58file_chars_44716)->length;
            }
            else {
                _23589 = 1;
            }
            if (_next_c_char_45090 <= _23589)
            goto L1D; // [584] 594

            /** c_decl.e:1569								next_c_char = 1  -- (unique_c_name will resolve)*/
            _next_c_char_45090 = 1;
L1D: 

            /** c_decl.e:1572							add_file(c_file)*/
            RefDS(_c_file_45096);
            RefDS(_22190);
            _58add_file(_c_file_45096, _22190);
L15: 

            /** c_decl.e:1575						sequence ret_type*/

            /** c_decl.e:1576						if SymTab[s][S_TOKEN] = PROC then*/
            _2 = (object)SEQ_PTR(_37SymTab_15637);
            _23591 = (object)*(((s1_ptr)_2)->base + _s_45088);
            _2 = (object)SEQ_PTR(_23591);
            if (!IS_ATOM_INT(_36S_TOKEN_21409)){
                _23592 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21409)->dbl));
            }
            else{
                _23592 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21409);
            }
            _23591 = NOVALUE;
            if (binary_op_a(NOTEQ, _23592, 27)){
                _23592 = NOVALUE;
                goto L1E; // [619] 633
            }
            _23592 = NOVALUE;

            /** c_decl.e:1577							ret_type = "void "*/
            RefDS(_22969);
            DeRefi(_ret_type_45225);
            _ret_type_45225 = _22969;
            goto L1F; // [630] 641
L1E: 

            /** c_decl.e:1579							ret_type = "object "*/
            RefDS(_22970);
            DeRefi(_ret_type_45225);
            _ret_type_45225 = _22970;
L1F: 

            /** c_decl.e:1581						integer s_scope = sym_scope( s )*/
            _s_scope_45234 = _54sym_scope(_s_45088);
            if (!IS_ATOM_INT(_s_scope_45234)) {
                _1 = (object)(DBL_PTR(_s_scope_45234)->dbl);
                DeRefDS(_s_scope_45234);
                _s_scope_45234 = _1;
            }

            /** c_decl.e:1582						integer s_file  = SymTab[s][S_FILE_NO]*/
            _2 = (object)SEQ_PTR(_37SymTab_15637);
            _23595 = (object)*(((s1_ptr)_2)->base + _s_45088);
            _2 = (object)SEQ_PTR(_23595);
            if (!IS_ATOM_INT(_36S_FILE_NO_21400)){
                _s_file_45237 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21400)->dbl));
            }
            else{
                _s_file_45237 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21400);
            }
            if (!IS_ATOM_INT(_s_file_45237)){
                _s_file_45237 = (object)DBL_PTR(_s_file_45237)->dbl;
            }
            _23595 = NOVALUE;

            /** c_decl.e:1583						if dll_option and*/
            if (_58dll_option_42893 == 0) {
                goto L20; // [669] 827
            }
            _23598 = (_s_scope_45234 == 6);
            if (_23598 != 0) {
                DeRef(_23599);
                _23599 = 1;
                goto L21; // [679] 757
            }
            _23600 = (_s_file_45237 == 1);
            if (_23600 == 0) {
                _23601 = 0;
                goto L22; // [687] 715
            }
            _23602 = (_s_scope_45234 == 13);
            if (_23602 != 0) {
                _23603 = 1;
                goto L23; // [697] 711
            }
            _23604 = (_s_scope_45234 == 11);
            _23603 = (_23604 != 0);
L23: 
            _23601 = (_23603 != 0);
L22: 
            if (_23601 != 0) {
                _23605 = 1;
                goto L24; // [715] 753
            }
            _23606 = (_s_scope_45234 == 13);
            if (_23606 == 0) {
                _23607 = 0;
                goto L25; // [725] 749
            }
            _2 = (object)SEQ_PTR(_37include_matrix_15644);
            _23608 = (object)*(((s1_ptr)_2)->base + 1);
            _2 = (object)SEQ_PTR(_23608);
            _23609 = (object)*(((s1_ptr)_2)->base + _s_file_45237);
            _23608 = NOVALUE;
            if (IS_ATOM_INT(_23609)) {
                {uintptr_t tu;
                     tu = (uintptr_t)_23609 & (uintptr_t)4;
                     _23610 = MAKE_UINT(tu);
                }
            }
            else {
                _23610 = binary_op(AND_BITS, _23609, 4);
            }
            _23609 = NOVALUE;
            if (IS_ATOM_INT(_23610))
            _23607 = (_23610 != 0);
            else
            _23607 = DBL_PTR(_23610)->dbl != 0.0;
L25: 
            _23605 = (_23607 != 0);
L24: 
            DeRef(_23599);
            _23599 = (_23605 != 0);
L21: 
            if (_23599 == 0)
            {
                _23599 = NOVALUE;
                goto L20; // [758] 827
            }
            else{
                _23599 = NOVALUE;
            }

            /** c_decl.e:1589							SymTab[s][S_RI_TARGET] = TRUE*/
            _2 = (object)SEQ_PTR(_37SymTab_15637);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _37SymTab_15637 = MAKE_SEQ(_2);
            }
            _3 = (object)(_s_45088 + ((s1_ptr)_2)->base);
            _2 = (object)SEQ_PTR(*(intptr_t *)_3);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                *(intptr_t *)_3 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + 53);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _13TRUE_447;
            DeRef(_1);
            _23611 = NOVALUE;

            /** c_decl.e:1590							LeftSym = TRUE*/
            _58LeftSym_42890 = _13TRUE_447;

            /** c_decl.e:1593							if TWINDOWS then*/
            if (_46TWINDOWS_21914 == 0)
            {
                goto L26; // [791] 810
            }
            else{
            }

            /** c_decl.e:1594								c_stmt(ret_type & " __stdcall @(", s)*/
            Concat((object_ptr)&_23614, _ret_type_45225, _23613);
            _58c_stmt(_23614, _s_45088, 0);
            _23614 = NOVALUE;
            goto L27; // [807] 850
L26: 

            /** c_decl.e:1596								c_stmt(ret_type & "@(", s)*/
            Concat((object_ptr)&_23616, _ret_type_45225, _23615);
            _58c_stmt(_23616, _s_45088, 0);
            _23616 = NOVALUE;
            goto L27; // [824] 850
L20: 

            /** c_decl.e:1600							LeftSym = TRUE*/
            _58LeftSym_42890 = _13TRUE_447;

            /** c_decl.e:1601							c_stmt( ret_type & "@(", s)*/
            Concat((object_ptr)&_23617, _ret_type_45225, _23615);
            _58c_stmt(_23617, _s_45088, 0);
            _23617 = NOVALUE;
L27: 

            /** c_decl.e:1605						sp = SymTab[s][S_NEXT]*/
            _2 = (object)SEQ_PTR(_37SymTab_15637);
            _23618 = (object)*(((s1_ptr)_2)->base + _s_45088);
            _2 = (object)SEQ_PTR(_23618);
            _sp_45089 = (object)*(((s1_ptr)_2)->base + 2);
            if (!IS_ATOM_INT(_sp_45089)){
                _sp_45089 = (object)DBL_PTR(_sp_45089)->dbl;
            }
            _23618 = NOVALUE;

            /** c_decl.e:1606						for p = 1 to SymTab[s][S_NUM_ARGS] do*/
            _2 = (object)SEQ_PTR(_37SymTab_15637);
            _23620 = (object)*(((s1_ptr)_2)->base + _s_45088);
            _2 = (object)SEQ_PTR(_23620);
            if (!IS_ATOM_INT(_36S_NUM_ARGS_21455)){
                _23621 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21455)->dbl));
            }
            else{
                _23621 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21455);
            }
            _23620 = NOVALUE;
            {
                object _p_45284;
                _p_45284 = 1;
L28: 
                if (binary_op_a(GREATER, _p_45284, _23621)){
                    goto L29; // [880] 956
                }

                /** c_decl.e:1607							c_puts("object _")*/
                RefDS(_23622);
                _55c_puts(_23622);

                /** c_decl.e:1608							c_puts(SymTab[sp][S_NAME])*/
                _2 = (object)SEQ_PTR(_37SymTab_15637);
                _23623 = (object)*(((s1_ptr)_2)->base + _sp_45089);
                _2 = (object)SEQ_PTR(_23623);
                if (!IS_ATOM_INT(_36S_NAME_21404)){
                    _23624 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21404)->dbl));
                }
                else{
                    _23624 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21404);
                }
                _23623 = NOVALUE;
                Ref(_23624);
                _55c_puts(_23624);
                _23624 = NOVALUE;

                /** c_decl.e:1609							if p != SymTab[s][S_NUM_ARGS] then*/
                _2 = (object)SEQ_PTR(_37SymTab_15637);
                _23625 = (object)*(((s1_ptr)_2)->base + _s_45088);
                _2 = (object)SEQ_PTR(_23625);
                if (!IS_ATOM_INT(_36S_NUM_ARGS_21455)){
                    _23626 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21455)->dbl));
                }
                else{
                    _23626 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21455);
                }
                _23625 = NOVALUE;
                if (binary_op_a(EQUALS, _p_45284, _23626)){
                    _23626 = NOVALUE;
                    goto L2A; // [923] 933
                }
                _23626 = NOVALUE;

                /** c_decl.e:1610								c_puts(", ")*/
                RefDS(_23628);
                _55c_puts(_23628);
L2A: 

                /** c_decl.e:1612							sp = SymTab[sp][S_NEXT]*/
                _2 = (object)SEQ_PTR(_37SymTab_15637);
                _23629 = (object)*(((s1_ptr)_2)->base + _sp_45089);
                _2 = (object)SEQ_PTR(_23629);
                _sp_45089 = (object)*(((s1_ptr)_2)->base + 2);
                if (!IS_ATOM_INT(_sp_45089)){
                    _sp_45089 = (object)DBL_PTR(_sp_45089)->dbl;
                }
                _23629 = NOVALUE;

                /** c_decl.e:1613						end for*/
                _0 = _p_45284;
                if (IS_ATOM_INT(_p_45284)) {
                    _p_45284 = _p_45284 + 1;
                    if ((object)((uintptr_t)_p_45284 +(uintptr_t) HIGH_BITS) >= 0){
                        _p_45284 = NewDouble((eudouble)_p_45284);
                    }
                }
                else {
                    _p_45284 = binary_op_a(PLUS, _p_45284, 1);
                }
                DeRef(_0);
                goto L28; // [951] 887
L29: 
                ;
                DeRef(_p_45284);
            }

            /** c_decl.e:1615						c_puts(")\n")*/
            RefDS(_23631);
            _55c_puts(_23631);

            /** c_decl.e:1616						c_stmt0("{\n")*/
            RefDS(_22294);
            _58c_stmt0(_22294);

            /** c_decl.e:1618						NewBB(0, E_ALL_EFFECT, 0)*/
            _58NewBB(0, 1073741823, 0);

            /** c_decl.e:1619						Initializing = TRUE*/
            _36Initializing_21851 = _13TRUE_447;

            /** c_decl.e:1622						while sp do*/
L2B: 
            if (_sp_45089 == 0)
            {
                goto L2C; // [989] 1128
            }
            else{
            }

            /** c_decl.e:1623							integer scope = SymTab[sp][S_SCOPE]*/
            _2 = (object)SEQ_PTR(_37SymTab_15637);
            _23632 = (object)*(((s1_ptr)_2)->base + _sp_45089);
            _2 = (object)SEQ_PTR(_23632);
            _scope_45314 = (object)*(((s1_ptr)_2)->base + 4);
            if (!IS_ATOM_INT(_scope_45314)){
                _scope_45314 = (object)DBL_PTR(_scope_45314)->dbl;
            }
            _23632 = NOVALUE;

            /** c_decl.e:1624							switch scope with fallthru do*/
            _0 = _scope_45314;
            switch ( _0 ){ 

                /** c_decl.e:1625								case SC_LOOP_VAR, SC_UNDEFINED then*/
                case 2:
                case 9:

                /** c_decl.e:1628									break*/
                goto L2D; // [1023] 1105

                /** c_decl.e:1630								case SC_PRIVATE then*/
                case 3:

                /** c_decl.e:1631									c_stmt0("object ")*/
                RefDS(_22970);
                _58c_stmt0(_22970);

                /** c_decl.e:1632									c_puts("_")*/
                RefDS(_22262);
                _55c_puts(_22262);

                /** c_decl.e:1633									c_puts(SymTab[sp][S_NAME])*/
                _2 = (object)SEQ_PTR(_37SymTab_15637);
                _23636 = (object)*(((s1_ptr)_2)->base + _sp_45089);
                _2 = (object)SEQ_PTR(_23636);
                if (!IS_ATOM_INT(_36S_NAME_21404)){
                    _23637 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21404)->dbl));
                }
                else{
                    _23637 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21404);
                }
                _23636 = NOVALUE;
                Ref(_23637);
                _55c_puts(_23637);
                _23637 = NOVALUE;

                /** c_decl.e:1635									c_puts(" = NOVALUE;\n")*/
                RefDS(_22978);
                _55c_puts(_22978);

                /** c_decl.e:1636									target[MIN] = NOVALUE*/
                Ref(_36NOVALUE_21621);
                _2 = (object)SEQ_PTR(_59target_28722);
                if (!UNIQUE(_2)) {
                    _2 = (object)SequenceCopy((s1_ptr)_2);
                    _59target_28722 = MAKE_SEQ(_2);
                }
                _2 = (object)(((s1_ptr)_2)->base + 1);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = _36NOVALUE_21621;
                DeRef(_1);

                /** c_decl.e:1637									target[MAX] = NOVALUE*/
                Ref(_36NOVALUE_21621);
                _2 = (object)SEQ_PTR(_59target_28722);
                if (!UNIQUE(_2)) {
                    _2 = (object)SequenceCopy((s1_ptr)_2);
                    _59target_28722 = MAKE_SEQ(_2);
                }
                _2 = (object)(((s1_ptr)_2)->base + 2);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = _36NOVALUE_21621;
                DeRef(_1);

                /** c_decl.e:1638									RemoveFromBB( sp )*/
                _58RemoveFromBB(_sp_45089);

                /** c_decl.e:1640									break*/
                goto L2D; // [1092] 1105

                /** c_decl.e:1642								case else*/
                default:

                /** c_decl.e:1643									exit*/
                goto L2C; // [1102] 1128
            ;}L2D: 

            /** c_decl.e:1645							sp = SymTab[sp][S_NEXT]*/
            _2 = (object)SEQ_PTR(_37SymTab_15637);
            _23638 = (object)*(((s1_ptr)_2)->base + _sp_45089);
            _2 = (object)SEQ_PTR(_23638);
            _sp_45089 = (object)*(((s1_ptr)_2)->base + 2);
            if (!IS_ATOM_INT(_sp_45089)){
                _sp_45089 = (object)DBL_PTR(_sp_45089)->dbl;
            }
            _23638 = NOVALUE;

            /** c_decl.e:1646						end while*/
            goto L2B; // [1125] 989
L2C: 

            /** c_decl.e:1649						temps = SymTab[s][S_TEMPS]*/
            _2 = (object)SEQ_PTR(_37SymTab_15637);
            _23640 = (object)*(((s1_ptr)_2)->base + _s_45088);
            _2 = (object)SEQ_PTR(_23640);
            if (!IS_ATOM_INT(_36S_TEMPS_21449)){
                _temps_45092 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TEMPS_21449)->dbl));
            }
            else{
                _temps_45092 = (object)*(((s1_ptr)_2)->base + _36S_TEMPS_21449);
            }
            if (!IS_ATOM_INT(_temps_45092)){
                _temps_45092 = (object)DBL_PTR(_temps_45092)->dbl;
            }
            _23640 = NOVALUE;

            /** c_decl.e:1650						sequence names = {}*/
            RefDS(_22190);
            DeRef(_names_45348);
            _names_45348 = _22190;

            /** c_decl.e:1651						while temps != 0 do*/
L2E: 
            if (_temps_45092 == 0)
            goto L2F; // [1156] 1348

            /** c_decl.e:1652							if SymTab[temps][S_SCOPE] != DELETED then*/
            _2 = (object)SEQ_PTR(_37SymTab_15637);
            _23643 = (object)*(((s1_ptr)_2)->base + _temps_45092);
            _2 = (object)SEQ_PTR(_23643);
            _23644 = (object)*(((s1_ptr)_2)->base + 4);
            _23643 = NOVALUE;
            if (binary_op_a(EQUALS, _23644, 2)){
                _23644 = NOVALUE;
                goto L30; // [1176] 1308
            }
            _23644 = NOVALUE;

            /** c_decl.e:1653								sequence name = sprintf("_%d", SymTab[temps][S_TEMP_NAME] )*/
            _2 = (object)SEQ_PTR(_37SymTab_15637);
            _23646 = (object)*(((s1_ptr)_2)->base + _temps_45092);
            _2 = (object)SEQ_PTR(_23646);
            _23647 = (object)*(((s1_ptr)_2)->base + 34);
            _23646 = NOVALUE;
            DeRefi(_name_45358);
            _name_45358 = EPrintf(-9999999, _22313, _23647);
            _23647 = NOVALUE;

            /** c_decl.e:1654								if temp_name_type[SymTab[temps][S_TEMP_NAME]][T_GTYPE]*/
            _2 = (object)SEQ_PTR(_37SymTab_15637);
            _23649 = (object)*(((s1_ptr)_2)->base + _temps_45092);
            _2 = (object)SEQ_PTR(_23649);
            _23650 = (object)*(((s1_ptr)_2)->base + 34);
            _23649 = NOVALUE;
            _2 = (object)SEQ_PTR(_36temp_name_type_21853);
            if (!IS_ATOM_INT(_23650)){
                _23651 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_23650)->dbl));
            }
            else{
                _23651 = (object)*(((s1_ptr)_2)->base + _23650);
            }
            _2 = (object)SEQ_PTR(_23651);
            _23652 = (object)*(((s1_ptr)_2)->base + 1);
            _23651 = NOVALUE;
            if (IS_ATOM_INT(_23652)) {
                _23653 = (_23652 != 0);
            }
            else {
                _23653 = binary_op(NOTEQ, _23652, 0);
            }
            _23652 = NOVALUE;
            if (IS_ATOM_INT(_23653)) {
                if (_23653 == 0) {
                    goto L31; // [1230] 1304
                }
            }
            else {
                if (DBL_PTR(_23653)->dbl == 0.0) {
                    goto L31; // [1230] 1304
                }
            }
            _23655 = find_from(_name_45358, _names_45348, 1);
            _23656 = (_23655 == 0);
            _23655 = NOVALUE;
            if (_23656 == 0)
            {
                DeRef(_23656);
                _23656 = NOVALUE;
                goto L31; // [1243] 1304
            }
            else{
                DeRef(_23656);
                _23656 = NOVALUE;
            }

            /** c_decl.e:1657									c_stmt0("object ")*/
            RefDS(_22970);
            _58c_stmt0(_22970);

            /** c_decl.e:1658									c_puts( name )*/
            RefDS(_name_45358);
            _55c_puts(_name_45358);

            /** c_decl.e:1659									c_puts(" = NOVALUE")*/
            RefDS(_23657);
            _55c_puts(_23657);

            /** c_decl.e:1661									target = {NOVALUE, NOVALUE}*/
            Ref(_36NOVALUE_21621);
            Ref(_36NOVALUE_21621);
            DeRef(_59target_28722);
            _1 = NewS1(2);
            _2 = (object)((s1_ptr)_1)->base;
            ((intptr_t *)_2)[1] = _36NOVALUE_21621;
            ((intptr_t *)_2)[2] = _36NOVALUE_21621;
            _59target_28722 = MAKE_SEQ(_1);

            /** c_decl.e:1663									SetBBType(temps, TYPE_INTEGER, target, TYPE_OBJECT, 0)*/
            RefDS(_59target_28722);
            _58SetBBType(_temps_45092, 1, _59target_28722, 16, 0);

            /** c_decl.e:1664									ifdef DEBUG then*/

            /** c_decl.e:1667										c_puts(";\n")*/
            RefDS(_22466);
            _55c_puts(_22466);

            /** c_decl.e:1669									names = prepend( names, name )*/
            RefDS(_name_45358);
            Prepend(&_names_45348, _names_45348, _name_45358);
            goto L32; // [1301] 1307
L31: 

            /** c_decl.e:1671									ifdef DEBUG then*/
L32: 
L30: 
            DeRefi(_name_45358);
            _name_45358 = NOVALUE;

            /** c_decl.e:1677							SymTab[temps][S_GTYPE] = TYPE_OBJECT*/
            _2 = (object)SEQ_PTR(_37SymTab_15637);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _37SymTab_15637 = MAKE_SEQ(_2);
            }
            _3 = (object)(_temps_45092 + ((s1_ptr)_2)->base);
            _2 = (object)SEQ_PTR(*(intptr_t *)_3);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                *(intptr_t *)_3 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + 36);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = 16;
            DeRef(_1);
            _23662 = NOVALUE;

            /** c_decl.e:1678							temps = SymTab[temps][S_NEXT]*/
            _2 = (object)SEQ_PTR(_37SymTab_15637);
            _23664 = (object)*(((s1_ptr)_2)->base + _temps_45092);
            _2 = (object)SEQ_PTR(_23664);
            _temps_45092 = (object)*(((s1_ptr)_2)->base + 2);
            if (!IS_ATOM_INT(_temps_45092)){
                _temps_45092 = (object)DBL_PTR(_temps_45092)->dbl;
            }
            _23664 = NOVALUE;

            /** c_decl.e:1679						end while*/
            goto L2E; // [1345] 1156
L2F: 

            /** c_decl.e:1680						Initializing = FALSE*/
            _36Initializing_21851 = _13FALSE_445;

            /** c_decl.e:1682						if SymTab[s][S_LHS_SUBS2] then*/
            _2 = (object)SEQ_PTR(_37SymTab_15637);
            _23666 = (object)*(((s1_ptr)_2)->base + _s_45088);
            _2 = (object)SEQ_PTR(_23666);
            _23667 = (object)*(((s1_ptr)_2)->base + 37);
            _23666 = NOVALUE;
            if (_23667 == 0) {
                _23667 = NOVALUE;
                goto L33; // [1371] 1384
            }
            else {
                if (!IS_ATOM_INT(_23667) && DBL_PTR(_23667)->dbl == 0.0){
                    _23667 = NOVALUE;
                    goto L33; // [1371] 1384
                }
                _23667 = NOVALUE;
            }
            _23667 = NOVALUE;

            /** c_decl.e:1683							c_stmt0("object _0, _1, _2, _3;\n\n")*/
            RefDS(_23668);
            _58c_stmt0(_23668);

            /** c_decl.e:1684							ifdef DEBUG then*/
            goto L34; // [1381] 1392
L33: 

            /** c_decl.e:1688							c_stmt0("object _0, _1, _2;\n\n")*/
            RefDS(_23670);
            _58c_stmt0(_23670);

            /** c_decl.e:1689							ifdef DEBUG then*/
L34: 

            /** c_decl.e:1696						sp = SymTab[s][S_NEXT]*/
            _2 = (object)SEQ_PTR(_37SymTab_15637);
            _23672 = (object)*(((s1_ptr)_2)->base + _s_45088);
            _2 = (object)SEQ_PTR(_23672);
            _sp_45089 = (object)*(((s1_ptr)_2)->base + 2);
            if (!IS_ATOM_INT(_sp_45089)){
                _sp_45089 = (object)DBL_PTR(_sp_45089)->dbl;
            }
            _23672 = NOVALUE;

            /** c_decl.e:1697						for p = 1 to SymTab[s][S_NUM_ARGS] do*/
            _2 = (object)SEQ_PTR(_37SymTab_15637);
            _23674 = (object)*(((s1_ptr)_2)->base + _s_45088);
            _2 = (object)SEQ_PTR(_23674);
            if (!IS_ATOM_INT(_36S_NUM_ARGS_21455)){
                _23675 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21455)->dbl));
            }
            else{
                _23675 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21455);
            }
            _23674 = NOVALUE;
            {
                object _p_45419;
                _p_45419 = 1;
L35: 
                if (binary_op_a(GREATER, _p_45419, _23675)){
                    goto L36; // [1422] 1773
                }

                /** c_decl.e:1698							SymTab[sp][S_ONE_REF] = FALSE*/
                _2 = (object)SEQ_PTR(_37SymTab_15637);
                if (!UNIQUE(_2)) {
                    _2 = (object)SequenceCopy((s1_ptr)_2);
                    _37SymTab_15637 = MAKE_SEQ(_2);
                }
                _3 = (object)(_sp_45089 + ((s1_ptr)_2)->base);
                _2 = (object)SEQ_PTR(*(intptr_t *)_3);
                if (!UNIQUE(_2)) {
                    _2 = (object)SequenceCopy((s1_ptr)_2);
                    *(intptr_t *)_3 = MAKE_SEQ(_2);
                }
                _2 = (object)(((s1_ptr)_2)->base + 35);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = _13FALSE_445;
                DeRef(_1);
                _23676 = NOVALUE;

                /** c_decl.e:1699							if SymTab[sp][S_ARG_TYPE] = TYPE_SEQUENCE then*/
                _2 = (object)SEQ_PTR(_37SymTab_15637);
                _23678 = (object)*(((s1_ptr)_2)->base + _sp_45089);
                _2 = (object)SEQ_PTR(_23678);
                _23679 = (object)*(((s1_ptr)_2)->base + 43);
                _23678 = NOVALUE;
                if (binary_op_a(NOTEQ, _23679, 8)){
                    _23679 = NOVALUE;
                    goto L37; // [1462] 1526
                }
                _23679 = NOVALUE;

                /** c_decl.e:1700								target[MIN] = SymTab[sp][S_ARG_SEQ_LEN]*/
                _2 = (object)SEQ_PTR(_37SymTab_15637);
                _23681 = (object)*(((s1_ptr)_2)->base + _sp_45089);
                _2 = (object)SEQ_PTR(_23681);
                _23682 = (object)*(((s1_ptr)_2)->base + 51);
                _23681 = NOVALUE;
                Ref(_23682);
                _2 = (object)SEQ_PTR(_59target_28722);
                if (!UNIQUE(_2)) {
                    _2 = (object)SequenceCopy((s1_ptr)_2);
                    _59target_28722 = MAKE_SEQ(_2);
                }
                _2 = (object)(((s1_ptr)_2)->base + 1);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = _23682;
                if( _1 != _23682 ){
                    DeRef(_1);
                }
                _23682 = NOVALUE;

                /** c_decl.e:1701								SetBBType(sp, SymTab[sp][S_ARG_TYPE], target,*/
                _2 = (object)SEQ_PTR(_37SymTab_15637);
                _23683 = (object)*(((s1_ptr)_2)->base + _sp_45089);
                _2 = (object)SEQ_PTR(_23683);
                _23684 = (object)*(((s1_ptr)_2)->base + 43);
                _23683 = NOVALUE;
                _2 = (object)SEQ_PTR(_37SymTab_15637);
                _23685 = (object)*(((s1_ptr)_2)->base + _sp_45089);
                _2 = (object)SEQ_PTR(_23685);
                _23686 = (object)*(((s1_ptr)_2)->base + 45);
                _23685 = NOVALUE;
                Ref(_23684);
                RefDS(_59target_28722);
                Ref(_23686);
                _58SetBBType(_sp_45089, _23684, _59target_28722, _23686, 0);
                _23684 = NOVALUE;
                _23686 = NOVALUE;
                goto L38; // [1523] 1750
L37: 

                /** c_decl.e:1704							elsif SymTab[sp][S_ARG_TYPE] = TYPE_INTEGER then*/
                _2 = (object)SEQ_PTR(_37SymTab_15637);
                _23687 = (object)*(((s1_ptr)_2)->base + _sp_45089);
                _2 = (object)SEQ_PTR(_23687);
                _23688 = (object)*(((s1_ptr)_2)->base + 43);
                _23687 = NOVALUE;
                if (binary_op_a(NOTEQ, _23688, 1)){
                    _23688 = NOVALUE;
                    goto L39; // [1542] 1666
                }
                _23688 = NOVALUE;

                /** c_decl.e:1705								if SymTab[sp][S_ARG_MIN] = NOVALUE then*/
                _2 = (object)SEQ_PTR(_37SymTab_15637);
                _23690 = (object)*(((s1_ptr)_2)->base + _sp_45089);
                _2 = (object)SEQ_PTR(_23690);
                _23691 = (object)*(((s1_ptr)_2)->base + 47);
                _23690 = NOVALUE;
                if (binary_op_a(NOTEQ, _23691, _36NOVALUE_21621)){
                    _23691 = NOVALUE;
                    goto L3A; // [1562] 1593
                }
                _23691 = NOVALUE;

                /** c_decl.e:1706									target[MIN] = MININT*/
                _2 = (object)SEQ_PTR(_59target_28722);
                if (!UNIQUE(_2)) {
                    _2 = (object)SequenceCopy((s1_ptr)_2);
                    _59target_28722 = MAKE_SEQ(_2);
                }
                _2 = (object)(((s1_ptr)_2)->base + 1);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = -1073741824;
                DeRef(_1);

                /** c_decl.e:1707									target[MAX] = MAXINT*/
                _2 = (object)SEQ_PTR(_59target_28722);
                if (!UNIQUE(_2)) {
                    _2 = (object)SequenceCopy((s1_ptr)_2);
                    _59target_28722 = MAKE_SEQ(_2);
                }
                _2 = (object)(((s1_ptr)_2)->base + 2);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = 1073741823;
                DeRef(_1);
                goto L3B; // [1590] 1638
L3A: 

                /** c_decl.e:1709									target[MIN] = SymTab[sp][S_ARG_MIN]*/
                _2 = (object)SEQ_PTR(_37SymTab_15637);
                _23693 = (object)*(((s1_ptr)_2)->base + _sp_45089);
                _2 = (object)SEQ_PTR(_23693);
                _23694 = (object)*(((s1_ptr)_2)->base + 47);
                _23693 = NOVALUE;
                Ref(_23694);
                _2 = (object)SEQ_PTR(_59target_28722);
                if (!UNIQUE(_2)) {
                    _2 = (object)SequenceCopy((s1_ptr)_2);
                    _59target_28722 = MAKE_SEQ(_2);
                }
                _2 = (object)(((s1_ptr)_2)->base + 1);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = _23694;
                if( _1 != _23694 ){
                    DeRef(_1);
                }
                _23694 = NOVALUE;

                /** c_decl.e:1710									target[MAX] = SymTab[sp][S_ARG_MAX]*/
                _2 = (object)SEQ_PTR(_37SymTab_15637);
                _23695 = (object)*(((s1_ptr)_2)->base + _sp_45089);
                _2 = (object)SEQ_PTR(_23695);
                _23696 = (object)*(((s1_ptr)_2)->base + 48);
                _23695 = NOVALUE;
                Ref(_23696);
                _2 = (object)SEQ_PTR(_59target_28722);
                if (!UNIQUE(_2)) {
                    _2 = (object)SequenceCopy((s1_ptr)_2);
                    _59target_28722 = MAKE_SEQ(_2);
                }
                _2 = (object)(((s1_ptr)_2)->base + 2);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = _23696;
                if( _1 != _23696 ){
                    DeRef(_1);
                }
                _23696 = NOVALUE;
L3B: 

                /** c_decl.e:1712								SetBBType(sp, SymTab[sp][S_ARG_TYPE], target, TYPE_OBJECT, 0)*/
                _2 = (object)SEQ_PTR(_37SymTab_15637);
                _23697 = (object)*(((s1_ptr)_2)->base + _sp_45089);
                _2 = (object)SEQ_PTR(_23697);
                _23698 = (object)*(((s1_ptr)_2)->base + 43);
                _23697 = NOVALUE;
                Ref(_23698);
                RefDS(_59target_28722);
                _58SetBBType(_sp_45089, _23698, _59target_28722, 16, 0);
                _23698 = NOVALUE;
                goto L38; // [1663] 1750
L39: 

                /** c_decl.e:1714							elsif SymTab[sp][S_ARG_TYPE] = TYPE_OBJECT then*/
                _2 = (object)SEQ_PTR(_37SymTab_15637);
                _23699 = (object)*(((s1_ptr)_2)->base + _sp_45089);
                _2 = (object)SEQ_PTR(_23699);
                _23700 = (object)*(((s1_ptr)_2)->base + 43);
                _23699 = NOVALUE;
                if (binary_op_a(NOTEQ, _23700, 16)){
                    _23700 = NOVALUE;
                    goto L3C; // [1682] 1724
                }
                _23700 = NOVALUE;

                /** c_decl.e:1716								SetBBType(sp, SymTab[sp][S_ARG_TYPE], novalue,*/
                _2 = (object)SEQ_PTR(_37SymTab_15637);
                _23702 = (object)*(((s1_ptr)_2)->base + _sp_45089);
                _2 = (object)SEQ_PTR(_23702);
                _23703 = (object)*(((s1_ptr)_2)->base + 43);
                _23702 = NOVALUE;
                _2 = (object)SEQ_PTR(_37SymTab_15637);
                _23704 = (object)*(((s1_ptr)_2)->base + _sp_45089);
                _2 = (object)SEQ_PTR(_23704);
                _23705 = (object)*(((s1_ptr)_2)->base + 45);
                _23704 = NOVALUE;
                Ref(_23703);
                RefDS(_55novalue_46980);
                Ref(_23705);
                _58SetBBType(_sp_45089, _23703, _55novalue_46980, _23705, 0);
                _23703 = NOVALUE;
                _23705 = NOVALUE;
                goto L38; // [1721] 1750
L3C: 

                /** c_decl.e:1720								SetBBType(sp, SymTab[sp][S_ARG_TYPE], novalue, TYPE_OBJECT, 0)*/
                _2 = (object)SEQ_PTR(_37SymTab_15637);
                _23706 = (object)*(((s1_ptr)_2)->base + _sp_45089);
                _2 = (object)SEQ_PTR(_23706);
                _23707 = (object)*(((s1_ptr)_2)->base + 43);
                _23706 = NOVALUE;
                Ref(_23707);
                RefDS(_55novalue_46980);
                _58SetBBType(_sp_45089, _23707, _55novalue_46980, 16, 0);
                _23707 = NOVALUE;
L38: 

                /** c_decl.e:1723							sp = SymTab[sp][S_NEXT]*/
                _2 = (object)SEQ_PTR(_37SymTab_15637);
                _23708 = (object)*(((s1_ptr)_2)->base + _sp_45089);
                _2 = (object)SEQ_PTR(_23708);
                _sp_45089 = (object)*(((s1_ptr)_2)->base + 2);
                if (!IS_ATOM_INT(_sp_45089)){
                    _sp_45089 = (object)DBL_PTR(_sp_45089)->dbl;
                }
                _23708 = NOVALUE;

                /** c_decl.e:1724						end for*/
                _0 = _p_45419;
                if (IS_ATOM_INT(_p_45419)) {
                    _p_45419 = _p_45419 + 1;
                    if ((object)((uintptr_t)_p_45419 +(uintptr_t) HIGH_BITS) >= 0){
                        _p_45419 = NewDouble((eudouble)_p_45419);
                    }
                }
                else {
                    _p_45419 = binary_op_a(PLUS, _p_45419, 1);
                }
                DeRef(_0);
                goto L35; // [1768] 1429
L36: 
                ;
                DeRef(_p_45419);
            }

            /** c_decl.e:1727						call_proc(Execute_id, {s})*/
            _1 = NewS1(1);
            _2 = (object)((s1_ptr)_1)->base;
            ((intptr_t*)_2)[1] = _s_45088;
            _23710 = MAKE_SEQ(_1);
            _1 = (object)SEQ_PTR(_23710);
            _2 = (object)((s1_ptr)_1)->base;
            _0 = (object)_00[_36Execute_id_21858].addr;
            Ref( *(( (intptr_t*)_2) + 1) );
            (*(intptr_t (*)())_0)(
                                *( ((intptr_t *)_2) + 1)
                                 );
            DeRefDS(_23710);
            _23710 = NOVALUE;

            /** c_decl.e:1729						c_puts("    ;\n}\n")*/
            RefDS(_23711);
            _55c_puts(_23711);

            /** c_decl.e:1730						if dll_option and is_exported( s ) then*/
            if (_58dll_option_42893 == 0) {
                goto L3D; // [1793] 2183
            }
            _23713 = _58is_exported(_s_45088);
            if (_23713 == 0) {
                DeRef(_23713);
                _23713 = NOVALUE;
                goto L3D; // [1802] 2183
            }
            else {
                if (!IS_ATOM_INT(_23713) && DBL_PTR(_23713)->dbl == 0.0){
                    DeRef(_23713);
                    _23713 = NOVALUE;
                    goto L3D; // [1802] 2183
                }
                DeRef(_23713);
                _23713 = NOVALUE;
            }
            DeRef(_23713);
            _23713 = NOVALUE;

            /** c_decl.e:1732							LeftSym = TRUE*/
            _58LeftSym_42890 = _13TRUE_447;

            /** c_decl.e:1733							if TOSX then*/
            if (_46TOSX_21922 == 0)
            {
                goto L3E; // [1818] 2078
            }
            else{
            }

            /** c_decl.e:1737								c_stmt0( ret_type & SymTab[s][S_NAME] & " (" )*/
            _2 = (object)SEQ_PTR(_37SymTab_15637);
            _23714 = (object)*(((s1_ptr)_2)->base + _s_45088);
            _2 = (object)SEQ_PTR(_23714);
            if (!IS_ATOM_INT(_36S_NAME_21404)){
                _23715 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21404)->dbl));
            }
            else{
                _23715 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21404);
            }
            _23714 = NOVALUE;
            {
                object concat_list[3];

                concat_list[0] = _23716;
                concat_list[1] = _23715;
                concat_list[2] = _ret_type_45225;
                Concat_N((object_ptr)&_23717, concat_list, 3);
            }
            _23715 = NOVALUE;
            _58c_stmt0(_23717);
            _23717 = NOVALUE;

            /** c_decl.e:1739								sp = SymTab[s][S_NEXT]*/
            _2 = (object)SEQ_PTR(_37SymTab_15637);
            _23718 = (object)*(((s1_ptr)_2)->base + _s_45088);
            _2 = (object)SEQ_PTR(_23718);
            _sp_45089 = (object)*(((s1_ptr)_2)->base + 2);
            if (!IS_ATOM_INT(_sp_45089)){
                _sp_45089 = (object)DBL_PTR(_sp_45089)->dbl;
            }
            _23718 = NOVALUE;

            /** c_decl.e:1740								for p = 1 to SymTab[s][S_NUM_ARGS] do*/
            _2 = (object)SEQ_PTR(_37SymTab_15637);
            _23720 = (object)*(((s1_ptr)_2)->base + _s_45088);
            _2 = (object)SEQ_PTR(_23720);
            if (!IS_ATOM_INT(_36S_NUM_ARGS_21455)){
                _23721 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21455)->dbl));
            }
            else{
                _23721 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21455);
            }
            _23720 = NOVALUE;
            {
                object _p_45538;
                _p_45538 = 1;
L3F: 
                if (binary_op_a(GREATER, _p_45538, _23721)){
                    goto L40; // [1876] 1952
                }

                /** c_decl.e:1741									c_puts("int _")*/
                RefDS(_23722);
                _55c_puts(_23722);

                /** c_decl.e:1742									c_puts(SymTab[sp][S_NAME])*/
                _2 = (object)SEQ_PTR(_37SymTab_15637);
                _23723 = (object)*(((s1_ptr)_2)->base + _sp_45089);
                _2 = (object)SEQ_PTR(_23723);
                if (!IS_ATOM_INT(_36S_NAME_21404)){
                    _23724 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21404)->dbl));
                }
                else{
                    _23724 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21404);
                }
                _23723 = NOVALUE;
                Ref(_23724);
                _55c_puts(_23724);
                _23724 = NOVALUE;

                /** c_decl.e:1743									if p != SymTab[s][S_NUM_ARGS] then*/
                _2 = (object)SEQ_PTR(_37SymTab_15637);
                _23725 = (object)*(((s1_ptr)_2)->base + _s_45088);
                _2 = (object)SEQ_PTR(_23725);
                if (!IS_ATOM_INT(_36S_NUM_ARGS_21455)){
                    _23726 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21455)->dbl));
                }
                else{
                    _23726 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21455);
                }
                _23725 = NOVALUE;
                if (binary_op_a(EQUALS, _p_45538, _23726)){
                    _23726 = NOVALUE;
                    goto L41; // [1919] 1929
                }
                _23726 = NOVALUE;

                /** c_decl.e:1744										c_puts(", ")*/
                RefDS(_23628);
                _55c_puts(_23628);
L41: 

                /** c_decl.e:1746									sp = SymTab[sp][S_NEXT]*/
                _2 = (object)SEQ_PTR(_37SymTab_15637);
                _23728 = (object)*(((s1_ptr)_2)->base + _sp_45089);
                _2 = (object)SEQ_PTR(_23728);
                _sp_45089 = (object)*(((s1_ptr)_2)->base + 2);
                if (!IS_ATOM_INT(_sp_45089)){
                    _sp_45089 = (object)DBL_PTR(_sp_45089)->dbl;
                }
                _23728 = NOVALUE;

                /** c_decl.e:1747								end for*/
                _0 = _p_45538;
                if (IS_ATOM_INT(_p_45538)) {
                    _p_45538 = _p_45538 + 1;
                    if ((object)((uintptr_t)_p_45538 +(uintptr_t) HIGH_BITS) >= 0){
                        _p_45538 = NewDouble((eudouble)_p_45538);
                    }
                }
                else {
                    _p_45538 = binary_op_a(PLUS, _p_45538, 1);
                }
                DeRef(_0);
                goto L3F; // [1947] 1883
L40: 
                ;
                DeRef(_p_45538);
            }

            /** c_decl.e:1749								c_puts( ") {\n")*/
            RefDS(_23730);
            _55c_puts(_23730);

            /** c_decl.e:1750								c_stmt("    return @(", s)*/
            RefDS(_23731);
            _58c_stmt(_23731, _s_45088, 0);

            /** c_decl.e:1751								sp = SymTab[s][S_NEXT]*/
            _2 = (object)SEQ_PTR(_37SymTab_15637);
            _23732 = (object)*(((s1_ptr)_2)->base + _s_45088);
            _2 = (object)SEQ_PTR(_23732);
            _sp_45089 = (object)*(((s1_ptr)_2)->base + 2);
            if (!IS_ATOM_INT(_sp_45089)){
                _sp_45089 = (object)DBL_PTR(_sp_45089)->dbl;
            }
            _23732 = NOVALUE;

            /** c_decl.e:1752								for p = 1 to SymTab[s][S_NUM_ARGS] do*/
            _2 = (object)SEQ_PTR(_37SymTab_15637);
            _23734 = (object)*(((s1_ptr)_2)->base + _s_45088);
            _2 = (object)SEQ_PTR(_23734);
            if (!IS_ATOM_INT(_36S_NUM_ARGS_21455)){
                _23735 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21455)->dbl));
            }
            else{
                _23735 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21455);
            }
            _23734 = NOVALUE;
            {
                object _p_45569;
                _p_45569 = 1;
L42: 
                if (binary_op_a(GREATER, _p_45569, _23735)){
                    goto L43; // [1994] 2070
                }

                /** c_decl.e:1753									c_puts("_")*/
                RefDS(_22262);
                _55c_puts(_22262);

                /** c_decl.e:1754									c_puts(SymTab[sp][S_NAME])*/
                _2 = (object)SEQ_PTR(_37SymTab_15637);
                _23736 = (object)*(((s1_ptr)_2)->base + _sp_45089);
                _2 = (object)SEQ_PTR(_23736);
                if (!IS_ATOM_INT(_36S_NAME_21404)){
                    _23737 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21404)->dbl));
                }
                else{
                    _23737 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21404);
                }
                _23736 = NOVALUE;
                Ref(_23737);
                _55c_puts(_23737);
                _23737 = NOVALUE;

                /** c_decl.e:1755									if p != SymTab[s][S_NUM_ARGS] then*/
                _2 = (object)SEQ_PTR(_37SymTab_15637);
                _23738 = (object)*(((s1_ptr)_2)->base + _s_45088);
                _2 = (object)SEQ_PTR(_23738);
                if (!IS_ATOM_INT(_36S_NUM_ARGS_21455)){
                    _23739 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21455)->dbl));
                }
                else{
                    _23739 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21455);
                }
                _23738 = NOVALUE;
                if (binary_op_a(EQUALS, _p_45569, _23739)){
                    _23739 = NOVALUE;
                    goto L44; // [2037] 2047
                }
                _23739 = NOVALUE;

                /** c_decl.e:1756										c_puts(", ")*/
                RefDS(_23628);
                _55c_puts(_23628);
L44: 

                /** c_decl.e:1758									sp = SymTab[sp][S_NEXT]*/
                _2 = (object)SEQ_PTR(_37SymTab_15637);
                _23741 = (object)*(((s1_ptr)_2)->base + _sp_45089);
                _2 = (object)SEQ_PTR(_23741);
                _sp_45089 = (object)*(((s1_ptr)_2)->base + 2);
                if (!IS_ATOM_INT(_sp_45089)){
                    _sp_45089 = (object)DBL_PTR(_sp_45089)->dbl;
                }
                _23741 = NOVALUE;

                /** c_decl.e:1759								end for*/
                _0 = _p_45569;
                if (IS_ATOM_INT(_p_45569)) {
                    _p_45569 = _p_45569 + 1;
                    if ((object)((uintptr_t)_p_45569 +(uintptr_t) HIGH_BITS) >= 0){
                        _p_45569 = NewDouble((eudouble)_p_45569);
                    }
                }
                else {
                    _p_45569 = binary_op_a(PLUS, _p_45569, 1);
                }
                DeRef(_0);
                goto L42; // [2065] 2001
L43: 
                ;
                DeRef(_p_45569);
            }

            /** c_decl.e:1761								c_puts( ");\n}\n" )*/
            RefDS(_23743);
            _55c_puts(_23743);
            goto L45; // [2075] 2173
L3E: 

            /** c_decl.e:1762							elsif TWINDOWS then*/
            if (_46TWINDOWS_21914 == 0)
            {
                goto L46; // [2082] 2145
            }
            else{
            }

            /** c_decl.e:1766								c_stmt0( ret_type & SymTab[s][S_NAME] & "() __attribute__ ((alias (\"" )*/
            _2 = (object)SEQ_PTR(_37SymTab_15637);
            _23744 = (object)*(((s1_ptr)_2)->base + _s_45088);
            _2 = (object)SEQ_PTR(_23744);
            if (!IS_ATOM_INT(_36S_NAME_21404)){
                _23745 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21404)->dbl));
            }
            else{
                _23745 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21404);
            }
            _23744 = NOVALUE;
            {
                object concat_list[3];

                concat_list[0] = _23746;
                concat_list[1] = _23745;
                concat_list[2] = _ret_type_45225;
                Concat_N((object_ptr)&_23747, concat_list, 3);
            }
            _23745 = NOVALUE;
            _58c_stmt0(_23747);
            _23747 = NOVALUE;

            /** c_decl.e:1767								CName( s )*/
            _58CName(_s_45088);

            /** c_decl.e:1768								c_puts( sprintf( "@%d\")));\n", SymTab[s][S_NUM_ARGS] * TARGET_SIZEOF_POINTER ) )*/
            _2 = (object)SEQ_PTR(_37SymTab_15637);
            _23749 = (object)*(((s1_ptr)_2)->base + _s_45088);
            _2 = (object)SEQ_PTR(_23749);
            if (!IS_ATOM_INT(_36S_NUM_ARGS_21455)){
                _23750 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21455)->dbl));
            }
            else{
                _23750 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21455);
            }
            _23749 = NOVALUE;
            if (IS_ATOM_INT(_23750)) {
                if (_23750 == (short)_23750){
                    _23751 = _23750 * _36TARGET_SIZEOF_POINTER_21589;
                }
                else{
                    _23751 = NewDouble(_23750 * (eudouble)_36TARGET_SIZEOF_POINTER_21589);
                }
            }
            else {
                _23751 = binary_op(MULTIPLY, _23750, _36TARGET_SIZEOF_POINTER_21589);
            }
            _23750 = NOVALUE;
            _23752 = EPrintf(-9999999, _23748, _23751);
            DeRef(_23751);
            _23751 = NOVALUE;
            _55c_puts(_23752);
            _23752 = NOVALUE;
            goto L45; // [2142] 2173
L46: 

            /** c_decl.e:1770								c_stmt( ret_type & SymTab[s][S_NAME] & "() __attribute__ ((alias (\"@\")));\n", s )*/
            _2 = (object)SEQ_PTR(_37SymTab_15637);
            _23753 = (object)*(((s1_ptr)_2)->base + _s_45088);
            _2 = (object)SEQ_PTR(_23753);
            if (!IS_ATOM_INT(_36S_NAME_21404)){
                _23754 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21404)->dbl));
            }
            else{
                _23754 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21404);
            }
            _23753 = NOVALUE;
            {
                object concat_list[3];

                concat_list[0] = _23755;
                concat_list[1] = _23754;
                concat_list[2] = _ret_type_45225;
                Concat_N((object_ptr)&_23756, concat_list, 3);
            }
            _23754 = NOVALUE;
            _58c_stmt(_23756, _s_45088, 0);
            _23756 = NOVALUE;
L45: 

            /** c_decl.e:1772							LeftSym = FALSE*/
            _58LeftSym_42890 = _13FALSE_445;
L3D: 

            /** c_decl.e:1774						c_puts("\n\n" )*/
            RefDS(_22334);
            _55c_puts(_22334);
L14: 
            DeRefi(_ret_type_45225);
            _ret_type_45225 = NOVALUE;
            DeRef(_names_45348);
            _names_45348 = NOVALUE;

            /** c_decl.e:1776				end for*/
            _routine_no_45170 = _routine_no_45170 + 1;
            goto L12; // [2193] 367
L13: 
            ;
        }
L8: 
        DeRef(_these_routines_45167);
        _these_routines_45167 = NOVALUE;

        /** c_decl.e:1778		end for*/
        _file_no_45115 = _file_no_45115 + 1;
        goto L5; // [2203] 91
L6: 
        ;
    }

    /** c_decl.e:1779	end procedure*/
    DeRefi(_buff_45093);
    DeRef(_base_name_45094);
    DeRef(_long_c_file_45095);
    DeRef(_c_file_45096);
    _23721 = NOVALUE;
    DeRef(_23604);
    _23604 = NOVALUE;
    _23571 = NOVALUE;
    DeRef(_23598);
    _23598 = NOVALUE;
    DeRef(_23561);
    _23561 = NOVALUE;
    DeRef(_23573);
    _23573 = NOVALUE;
    _23735 = NOVALUE;
    DeRef(_23610);
    _23610 = NOVALUE;
    _23650 = NOVALUE;
    DeRef(_23568);
    _23568 = NOVALUE;
    _23621 = NOVALUE;
    DeRef(_23550);
    _23550 = NOVALUE;
    _23675 = NOVALUE;
    DeRef(_23653);
    _23653 = NOVALUE;
    DeRef(_23602);
    _23602 = NOVALUE;
    DeRef(_23563);
    _23563 = NOVALUE;
    DeRef(_23600);
    _23600 = NOVALUE;
    DeRef(_23527);
    _23527 = NOVALUE;
    DeRef(_23565);
    _23565 = NOVALUE;
    DeRef(_23606);
    _23606 = NOVALUE;
    DeRef(_23536);
    _23536 = NOVALUE;
    return;
    ;
}



// 0x17804F84
