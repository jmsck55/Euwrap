// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _67advance(object _pc_53906, object _code_53907)
{
    object _27375 = NOVALUE;
    object _27373 = NOVALUE;
    object _0, _1, _2;
    

    /** inline.e:63		prev_pc = pc*/
    _67prev_pc_53889 = _pc_53906;

    /** inline.e:64		if pc > length( code ) then*/
    if (IS_SEQUENCE(_code_53907)){
            _27373 = SEQ_PTR(_code_53907)->length;
    }
    else {
        _27373 = 1;
    }
    if (_pc_53906 <= _27373)
    goto L1; // [15] 26

    /** inline.e:65			return pc*/
    DeRefDS(_code_53907);
    return _pc_53906;
L1: 

    /** inline.e:67		return shift:advance( pc, code )*/
    RefDS(_code_53907);
    _27375 = _66advance(_pc_53906, _code_53907);
    DeRefDS(_code_53907);
    return _27375;
    ;
}


void _67shift(object _start_53914, object _amount_53915, object _bound_53916)
{
    object _temp_LineTable_53917 = NOVALUE;
    object _temp_Code_53919 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_amount_53915)) {
        _1 = (object)(DBL_PTR(_amount_53915)->dbl);
        DeRefDS(_amount_53915);
        _amount_53915 = _1;
    }

    /** inline.e:72			temp_LineTable = LineTable,*/
    RefDS(_36LineTable_21860);
    DeRef(_temp_LineTable_53917);
    _temp_LineTable_53917 = _36LineTable_21860;

    /** inline.e:73			temp_Code = Code*/
    RefDS(_36Code_21859);
    DeRef(_temp_Code_53919);
    _temp_Code_53919 = _36Code_21859;

    /** inline.e:74		LineTable = {}*/
    RefDS(_22190);
    DeRefDS(_36LineTable_21860);
    _36LineTable_21860 = _22190;

    /** inline.e:75		Code = inline_code*/
    RefDS(_67inline_code_53881);
    DeRefDS(_36Code_21859);
    _36Code_21859 = _67inline_code_53881;

    /** inline.e:76		inline_code = {}*/
    RefDS(_22190);
    DeRefDS(_67inline_code_53881);
    _67inline_code_53881 = _22190;

    /** inline.e:78		shift:shift( start, amount, bound )*/
    _66shift(_start_53914, _amount_53915, _bound_53916);

    /** inline.e:80		LineTable = temp_LineTable*/
    RefDS(_temp_LineTable_53917);
    DeRefDS(_36LineTable_21860);
    _36LineTable_21860 = _temp_LineTable_53917;

    /** inline.e:81		inline_code = Code*/
    RefDS(_36Code_21859);
    DeRefDS(_67inline_code_53881);
    _67inline_code_53881 = _36Code_21859;

    /** inline.e:82		Code = temp_Code*/
    RefDS(_temp_Code_53919);
    DeRefDS(_36Code_21859);
    _36Code_21859 = _temp_Code_53919;

    /** inline.e:83	end procedure*/
    DeRefDS(_temp_LineTable_53917);
    DeRefDS(_temp_Code_53919);
    return;
    ;
}


void _67replace_code(object _code_53934, object _start_53935, object _finish_53936)
{
    object _27382 = NOVALUE;
    object _27381 = NOVALUE;
    object _27380 = NOVALUE;
    object _27379 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_finish_53936)) {
        _1 = (object)(DBL_PTR(_finish_53936)->dbl);
        DeRefDS(_finish_53936);
        _finish_53936 = _1;
    }

    /** inline.e:92		inline_code = replace( inline_code, code, start, finish )*/
    {
        intptr_t p1 = _67inline_code_53881;
        intptr_t p2 = _code_53934;
        intptr_t p3 = _start_53935;
        intptr_t p4 = _finish_53936;
        struct replace_block replace_params;
        replace_params.copy_to   = &p1;
        replace_params.copy_from = &p2;
        replace_params.start     = &p3;
        replace_params.stop      = &p4;
        replace_params.target    = &_67inline_code_53881;
        Replace( &replace_params );
    }

    /** inline.e:93		shift( start , length( code ) - (finish - start + 1), finish )*/
    if (IS_SEQUENCE(_code_53934)){
            _27379 = SEQ_PTR(_code_53934)->length;
    }
    else {
        _27379 = 1;
    }
    _27380 = _finish_53936 - _start_53935;
    if ((object)((uintptr_t)_27380 +(uintptr_t) HIGH_BITS) >= 0){
        _27380 = NewDouble((eudouble)_27380);
    }
    if (IS_ATOM_INT(_27380)) {
        _27381 = _27380 + 1;
        if (_27381 > MAXINT){
            _27381 = NewDouble((eudouble)_27381);
        }
    }
    else
    _27381 = binary_op(PLUS, 1, _27380);
    DeRef(_27380);
    _27380 = NOVALUE;
    if (IS_ATOM_INT(_27381)) {
        _27382 = _27379 - _27381;
        if ((object)((uintptr_t)_27382 +(uintptr_t) HIGH_BITS) >= 0){
            _27382 = NewDouble((eudouble)_27382);
        }
    }
    else {
        _27382 = NewDouble((eudouble)_27379 - DBL_PTR(_27381)->dbl);
    }
    _27379 = NOVALUE;
    DeRef(_27381);
    _27381 = NOVALUE;
    _67shift(_start_53935, _27382, _finish_53936);
    _27382 = NOVALUE;

    /** inline.e:94	end procedure*/
    DeRefDS(_code_53934);
    return;
    ;
}


void _67defer()
{
    object _dx_53944 = NOVALUE;
    object _0, _1, _2;
    

    /** inline.e:101		integer dx = find( inline_sub, deferred_inline_decisions )*/
    _dx_53944 = find_from(_67inline_sub_53895, _67deferred_inline_decisions_53897, 1);

    /** inline.e:102		if not dx then*/
    if (_dx_53944 != 0)
    goto L1; // [14] 36

    /** inline.e:103			deferred_inline_decisions &= inline_sub*/
    Append(&_67deferred_inline_decisions_53897, _67deferred_inline_decisions_53897, _67inline_sub_53895);

    /** inline.e:104			deferred_inline_calls = append( deferred_inline_calls, {} )*/
    RefDS(_22190);
    Append(&_67deferred_inline_calls_53898, _67deferred_inline_calls_53898, _22190);
L1: 

    /** inline.e:106	end procedure*/
    return;
    ;
}


object _67new_inline_temp(object _sym_53953)
{
    object _27388 = NOVALUE;
    object _0, _1, _2;
    

    /** inline.e:110		inline_temps &= sym*/
    Append(&_67inline_temps_53883, _67inline_temps_53883, _sym_53953);

    /** inline.e:111		return length( inline_temps )*/
    if (IS_SEQUENCE(_67inline_temps_53883)){
            _27388 = SEQ_PTR(_67inline_temps_53883)->length;
    }
    else {
        _27388 = 1;
    }
    return _27388;
    ;
}


object _67get_inline_temp(object _sym_53959)
{
    object _temp_num_53960 = NOVALUE;
    object _27392 = NOVALUE;
    object _0, _1, _2;
    

    /** inline.e:117		integer temp_num = find( sym, inline_params )*/
    _temp_num_53960 = find_from(_sym_53959, _67inline_params_53886, 1);

    /** inline.e:118		if temp_num then*/
    if (_temp_num_53960 == 0)
    {
        goto L1; // [14] 24
    }
    else{
    }

    /** inline.e:119			return temp_num*/
    return _temp_num_53960;
L1: 

    /** inline.e:122		temp_num = find( sym, proc_vars )*/
    _temp_num_53960 = find_from(_sym_53959, _67proc_vars_53882, 1);

    /** inline.e:123		if temp_num then*/
    if (_temp_num_53960 == 0)
    {
        goto L2; // [35] 45
    }
    else{
    }

    /** inline.e:124			return temp_num*/
    return _temp_num_53960;
L2: 

    /** inline.e:127		temp_num = find( sym, inline_temps )*/
    _temp_num_53960 = find_from(_sym_53959, _67inline_temps_53883, 1);

    /** inline.e:128		if temp_num then*/
    if (_temp_num_53960 == 0)
    {
        goto L3; // [56] 66
    }
    else{
    }

    /** inline.e:129			return temp_num*/
    return _temp_num_53960;
L3: 

    /** inline.e:132		return new_inline_temp( sym )*/
    _27392 = _67new_inline_temp(_sym_53959);
    return _27392;
    ;
}


object _67generic_symbol(object _sym_53971)
{
    object _inline_type_53972 = NOVALUE;
    object _px_53973 = NOVALUE;
    object _eentry_53980 = NOVALUE;
    object _27401 = NOVALUE;
    object _27400 = NOVALUE;
    object _27399 = NOVALUE;
    object _27398 = NOVALUE;
    object _27396 = NOVALUE;
    object _0, _1, _2;
    

    /** inline.e:137		integer px = find( sym, inline_params )*/
    _px_53973 = find_from(_sym_53971, _67inline_params_53886, 1);

    /** inline.e:138		if px then*/
    if (_px_53973 == 0)
    {
        goto L1; // [14] 25
    }
    else{
    }

    /** inline.e:139			inline_type = INLINE_PARAM*/
    _inline_type_53972 = 1;
    goto L2; // [22] 100
L1: 

    /** inline.e:141			px = find( sym, proc_vars )*/
    _px_53973 = find_from(_sym_53971, _67proc_vars_53882, 1);

    /** inline.e:142			if px then*/
    if (_px_53973 == 0)
    {
        goto L3; // [36] 47
    }
    else{
    }

    /** inline.e:143				inline_type = INLINE_VAR*/
    _inline_type_53972 = 6;
    goto L4; // [44] 99
L3: 

    /** inline.e:145				sequence eentry = SymTab[sym]*/
    DeRef(_eentry_53980);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _eentry_53980 = (object)*(((s1_ptr)_2)->base + _sym_53971);
    Ref(_eentry_53980);

    /** inline.e:146				if is_literal( sym ) or eentry[S_SCOPE] > SC_PRIVATE then*/
    _27396 = _67is_literal(_sym_53971);
    if (IS_ATOM_INT(_27396)) {
        if (_27396 != 0) {
            goto L5; // [63] 84
        }
    }
    else {
        if (DBL_PTR(_27396)->dbl != 0.0) {
            goto L5; // [63] 84
        }
    }
    _2 = (object)SEQ_PTR(_eentry_53980);
    _27398 = (object)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_27398)) {
        _27399 = (_27398 > 3);
    }
    else {
        _27399 = binary_op(GREATER, _27398, 3);
    }
    _27398 = NOVALUE;
    if (_27399 == 0) {
        DeRef(_27399);
        _27399 = NOVALUE;
        goto L6; // [80] 91
    }
    else {
        if (!IS_ATOM_INT(_27399) && DBL_PTR(_27399)->dbl == 0.0){
            DeRef(_27399);
            _27399 = NOVALUE;
            goto L6; // [80] 91
        }
        DeRef(_27399);
        _27399 = NOVALUE;
    }
    DeRef(_27399);
    _27399 = NOVALUE;
L5: 

    /** inline.e:147					return sym*/
    DeRef(_eentry_53980);
    DeRef(_27396);
    _27396 = NOVALUE;
    return _sym_53971;
L6: 

    /** inline.e:149				inline_type = INLINE_TEMP*/
    _inline_type_53972 = 2;
    DeRef(_eentry_53980);
    _eentry_53980 = NOVALUE;
L4: 
L2: 

    /** inline.e:153		return { inline_type, get_inline_temp( sym ) }*/
    _27400 = _67get_inline_temp(_sym_53971);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _inline_type_53972;
    ((intptr_t *)_2)[2] = _27400;
    _27401 = MAKE_SEQ(_1);
    _27400 = NOVALUE;
    DeRef(_27396);
    _27396 = NOVALUE;
    return _27401;
    ;
}


object _67adjust_symbol(object _pc_53995)
{
    object _sym_53997 = NOVALUE;
    object _eentry_54003 = NOVALUE;
    object _27409 = NOVALUE;
    object _27407 = NOVALUE;
    object _27406 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_pc_53995)) {
        _1 = (object)(DBL_PTR(_pc_53995)->dbl);
        DeRefDS(_pc_53995);
        _pc_53995 = _1;
    }

    /** inline.e:160		symtab_index sym = inline_code[pc]*/
    _2 = (object)SEQ_PTR(_67inline_code_53881);
    _sym_53997 = (object)*(((s1_ptr)_2)->base + _pc_53995);
    if (!IS_ATOM_INT(_sym_53997)){
        _sym_53997 = (object)DBL_PTR(_sym_53997)->dbl;
    }

    /** inline.e:161		if sym < 0 then*/
    if (_sym_53997 >= 0)
    goto L1; // [15] 28

    /** inline.e:162			return 0*/
    DeRef(_eentry_54003);
    return 0;
    goto L2; // [25] 41
L1: 

    /** inline.e:163		elsif not sym then*/
    if (_sym_53997 != 0)
    goto L3; // [30] 40

    /** inline.e:165			return 1*/
    DeRef(_eentry_54003);
    return 1;
L3: 
L2: 

    /** inline.e:168		sequence eentry = SymTab[sym]*/
    DeRef(_eentry_54003);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _eentry_54003 = (object)*(((s1_ptr)_2)->base + _sym_53997);
    Ref(_eentry_54003);

    /** inline.e:169		if is_literal( sym ) then*/
    _27406 = _67is_literal(_sym_53997);
    if (_27406 == 0) {
        DeRef(_27406);
        _27406 = NOVALUE;
        goto L4; // [57] 69
    }
    else {
        if (!IS_ATOM_INT(_27406) && DBL_PTR(_27406)->dbl == 0.0){
            DeRef(_27406);
            _27406 = NOVALUE;
            goto L4; // [57] 69
        }
        DeRef(_27406);
        _27406 = NOVALUE;
    }
    DeRef(_27406);
    _27406 = NOVALUE;

    /** inline.e:170			return 1*/
    DeRefDS(_eentry_54003);
    return 1;
    goto L5; // [66] 95
L4: 

    /** inline.e:172		elsif eentry[S_SCOPE] = SC_UNDEFINED then*/
    _2 = (object)SEQ_PTR(_eentry_54003);
    _27407 = (object)*(((s1_ptr)_2)->base + 4);
    if (binary_op_a(NOTEQ, _27407, 9)){
        _27407 = NOVALUE;
        goto L6; // [79] 94
    }
    _27407 = NOVALUE;

    /** inline.e:173			defer()*/
    _67defer();

    /** inline.e:174			return 0*/
    DeRefDS(_eentry_54003);
    return 0;
L6: 
L5: 

    /** inline.e:177		inline_code[pc] = generic_symbol( sym )*/
    _27409 = _67generic_symbol(_sym_53997);
    _2 = (object)SEQ_PTR(_67inline_code_53881);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67inline_code_53881 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _pc_53995);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27409;
    if( _1 != _27409 ){
        DeRef(_1);
    }
    _27409 = NOVALUE;

    /** inline.e:178		return 1*/
    DeRef(_eentry_54003);
    return 1;
    ;
}


object _67check_for_param(object _pc_54017)
{
    object _px_54018 = NOVALUE;
    object _27412 = NOVALUE;
    object _27410 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_pc_54017)) {
        _1 = (object)(DBL_PTR(_pc_54017)->dbl);
        DeRefDS(_pc_54017);
        _pc_54017 = _1;
    }

    /** inline.e:182		integer px = find( inline_code[pc], inline_params )*/
    _2 = (object)SEQ_PTR(_67inline_code_53881);
    _27410 = (object)*(((s1_ptr)_2)->base + _pc_54017);
    _px_54018 = find_from(_27410, _67inline_params_53886, 1);
    _27410 = NOVALUE;

    /** inline.e:183		if px then*/
    if (_px_54018 == 0)
    {
        goto L1; // [20] 51
    }
    else{
    }

    /** inline.e:184			if not find( px, assigned_params ) then*/
    _27412 = find_from(_px_54018, _67assigned_params_53887, 1);
    if (_27412 != 0)
    goto L2; // [32] 44
    _27412 = NOVALUE;

    /** inline.e:185				assigned_params &= px*/
    Append(&_67assigned_params_53887, _67assigned_params_53887, _px_54018);
L2: 

    /** inline.e:187			return 1*/
    return 1;
L1: 

    /** inline.e:189		return 0*/
    return 0;
    ;
}


void _67check_target(object _pc_54028, object _op_54029)
{
    object _targets_54030 = NOVALUE;
    object _27421 = NOVALUE;
    object _27420 = NOVALUE;
    object _27419 = NOVALUE;
    object _27418 = NOVALUE;
    object _27417 = NOVALUE;
    object _27415 = NOVALUE;
    object _0, _1, _2;
    

    /** inline.e:194		sequence targets = op_info[op][OP_TARGET]*/
    _2 = (object)SEQ_PTR(_66op_info_24561);
    _27415 = (object)*(((s1_ptr)_2)->base + _op_54029);
    DeRef(_targets_54030);
    _2 = (object)SEQ_PTR(_27415);
    _targets_54030 = (object)*(((s1_ptr)_2)->base + 4);
    Ref(_targets_54030);
    _27415 = NOVALUE;

    /** inline.e:196		if length( targets ) then*/
    if (IS_SEQUENCE(_targets_54030)){
            _27417 = SEQ_PTR(_targets_54030)->length;
    }
    else {
        _27417 = 1;
    }
    if (_27417 == 0)
    {
        _27417 = NOVALUE;
        goto L1; // [26] 72
    }
    else{
        _27417 = NOVALUE;
    }

    /** inline.e:197		for i = 1 to length( targets ) do*/
    if (IS_SEQUENCE(_targets_54030)){
            _27418 = SEQ_PTR(_targets_54030)->length;
    }
    else {
        _27418 = 1;
    }
    {
        object _i_54038;
        _i_54038 = 1;
L2: 
        if (_i_54038 > _27418){
            goto L3; // [34] 71
        }

        /** inline.e:198				if check_for_param( pc + targets[i] ) then*/
        _2 = (object)SEQ_PTR(_targets_54030);
        _27419 = (object)*(((s1_ptr)_2)->base + _i_54038);
        if (IS_ATOM_INT(_27419)) {
            _27420 = _pc_54028 + _27419;
            if ((object)((uintptr_t)_27420 + (uintptr_t)HIGH_BITS) >= 0){
                _27420 = NewDouble((eudouble)_27420);
            }
        }
        else {
            _27420 = binary_op(PLUS, _pc_54028, _27419);
        }
        _27419 = NOVALUE;
        _27421 = _67check_for_param(_27420);
        _27420 = NOVALUE;
        if (_27421 == 0) {
            DeRef(_27421);
            _27421 = NOVALUE;
            goto L4; // [55] 64
        }
        else {
            if (!IS_ATOM_INT(_27421) && DBL_PTR(_27421)->dbl == 0.0){
                DeRef(_27421);
                _27421 = NOVALUE;
                goto L4; // [55] 64
            }
            DeRef(_27421);
            _27421 = NOVALUE;
        }
        DeRef(_27421);
        _27421 = NOVALUE;

        /** inline.e:199					return*/
        DeRefDS(_targets_54030);
        return;
L4: 

        /** inline.e:201			end for*/
        _i_54038 = _i_54038 + 1;
        goto L2; // [66] 41
L3: 
        ;
    }
L1: 

    /** inline.e:203	end procedure*/
    DeRef(_targets_54030);
    return;
    ;
}


object _67adjust_il(object _pc_54046, object _op_54047)
{
    object _addr_54055 = NOVALUE;
    object _sub_54061 = NOVALUE;
    object _27446 = NOVALUE;
    object _27445 = NOVALUE;
    object _27444 = NOVALUE;
    object _27443 = NOVALUE;
    object _27442 = NOVALUE;
    object _27441 = NOVALUE;
    object _27440 = NOVALUE;
    object _27438 = NOVALUE;
    object _27437 = NOVALUE;
    object _27436 = NOVALUE;
    object _27435 = NOVALUE;
    object _27434 = NOVALUE;
    object _27433 = NOVALUE;
    object _27432 = NOVALUE;
    object _27431 = NOVALUE;
    object _27429 = NOVALUE;
    object _27428 = NOVALUE;
    object _27426 = NOVALUE;
    object _27425 = NOVALUE;
    object _27424 = NOVALUE;
    object _27423 = NOVALUE;
    object _27422 = NOVALUE;
    object _0, _1, _2;
    

    /** inline.e:208		for i = 1 to op_info[op][OP_SIZE] - 1 do*/
    _2 = (object)SEQ_PTR(_66op_info_24561);
    _27422 = (object)*(((s1_ptr)_2)->base + _op_54047);
    _2 = (object)SEQ_PTR(_27422);
    _27423 = (object)*(((s1_ptr)_2)->base + 2);
    _27422 = NOVALUE;
    if (IS_ATOM_INT(_27423)) {
        _27424 = _27423 - 1;
        if ((object)((uintptr_t)_27424 +(uintptr_t) HIGH_BITS) >= 0){
            _27424 = NewDouble((eudouble)_27424);
        }
    }
    else {
        _27424 = binary_op(MINUS, _27423, 1);
    }
    _27423 = NOVALUE;
    {
        object _i_54049;
        _i_54049 = 1;
L1: 
        if (binary_op_a(GREATER, _i_54049, _27424)){
            goto L2; // [23] 214
        }

        /** inline.e:210			integer addr = find( i, op_info[op][OP_ADDR] )*/
        _2 = (object)SEQ_PTR(_66op_info_24561);
        _27425 = (object)*(((s1_ptr)_2)->base + _op_54047);
        _2 = (object)SEQ_PTR(_27425);
        _27426 = (object)*(((s1_ptr)_2)->base + 3);
        _27425 = NOVALUE;
        _addr_54055 = find_from(_i_54049, _27426, 1);
        _27426 = NOVALUE;

        /** inline.e:211			integer sub  = find( i, op_info[op][OP_SUB] )*/
        _2 = (object)SEQ_PTR(_66op_info_24561);
        _27428 = (object)*(((s1_ptr)_2)->base + _op_54047);
        _2 = (object)SEQ_PTR(_27428);
        _27429 = (object)*(((s1_ptr)_2)->base + 5);
        _27428 = NOVALUE;
        _sub_54061 = find_from(_i_54049, _27429, 1);
        _27429 = NOVALUE;

        /** inline.e:212			if addr then*/
        if (_addr_54055 == 0)
        {
            goto L3; // [70] 121
        }
        else{
        }

        /** inline.e:213				if integer( inline_code[pc+i] ) then*/
        if (IS_ATOM_INT(_i_54049)) {
            _27431 = _pc_54046 + _i_54049;
        }
        else {
            _27431 = NewDouble((eudouble)_pc_54046 + DBL_PTR(_i_54049)->dbl);
        }
        _2 = (object)SEQ_PTR(_67inline_code_53881);
        if (!IS_ATOM_INT(_27431)){
            _27432 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27431)->dbl));
        }
        else{
            _27432 = (object)*(((s1_ptr)_2)->base + _27431);
        }
        if (IS_ATOM_INT(_27432))
        _27433 = 1;
        else if (IS_ATOM_DBL(_27432))
        _27433 = IS_ATOM_INT(DoubleToInt(_27432));
        else
        _27433 = 0;
        _27432 = NOVALUE;
        if (_27433 == 0)
        {
            _27433 = NOVALUE;
            goto L4; // [88] 205
        }
        else{
            _27433 = NOVALUE;
        }

        /** inline.e:214					inline_code[pc + i] = { INLINE_ADDR, inline_code[pc + i] }*/
        if (IS_ATOM_INT(_i_54049)) {
            _27434 = _pc_54046 + _i_54049;
            if ((object)((uintptr_t)_27434 + (uintptr_t)HIGH_BITS) >= 0){
                _27434 = NewDouble((eudouble)_27434);
            }
        }
        else {
            _27434 = NewDouble((eudouble)_pc_54046 + DBL_PTR(_i_54049)->dbl);
        }
        if (IS_ATOM_INT(_i_54049)) {
            _27435 = _pc_54046 + _i_54049;
        }
        else {
            _27435 = NewDouble((eudouble)_pc_54046 + DBL_PTR(_i_54049)->dbl);
        }
        _2 = (object)SEQ_PTR(_67inline_code_53881);
        if (!IS_ATOM_INT(_27435)){
            _27436 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27435)->dbl));
        }
        else{
            _27436 = (object)*(((s1_ptr)_2)->base + _27435);
        }
        Ref(_27436);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = 4;
        ((intptr_t *)_2)[2] = _27436;
        _27437 = MAKE_SEQ(_1);
        _27436 = NOVALUE;
        _2 = (object)SEQ_PTR(_67inline_code_53881);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _67inline_code_53881 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_27434))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27434)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _27434);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _27437;
        if( _1 != _27437 ){
            DeRef(_1);
        }
        _27437 = NOVALUE;
        goto L4; // [118] 205
L3: 

        /** inline.e:217			elsif sub then*/
        if (_sub_54061 == 0)
        {
            goto L5; // [123] 141
        }
        else{
        }

        /** inline.e:218				inline_code[pc+i] = {INLINE_SUB}*/
        if (IS_ATOM_INT(_i_54049)) {
            _27438 = _pc_54046 + _i_54049;
        }
        else {
            _27438 = NewDouble((eudouble)_pc_54046 + DBL_PTR(_i_54049)->dbl);
        }
        RefDS(_27439);
        _2 = (object)SEQ_PTR(_67inline_code_53881);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _67inline_code_53881 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_27438))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27438)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _27438);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _27439;
        DeRef(_1);
        goto L4; // [138] 205
L5: 

        /** inline.e:220				if op != STARTLINE and op != COVERAGE_LINE and op != COVERAGE_ROUTINE then*/
        _27440 = (_op_54047 != 58);
        if (_27440 == 0) {
            _27441 = 0;
            goto L6; // [149] 163
        }
        _27442 = (_op_54047 != 210);
        _27441 = (_27442 != 0);
L6: 
        if (_27441 == 0) {
            goto L7; // [163] 204
        }
        _27444 = (_op_54047 != 211);
        if (_27444 == 0)
        {
            DeRef(_27444);
            _27444 = NOVALUE;
            goto L7; // [174] 204
        }
        else{
            DeRef(_27444);
            _27444 = NOVALUE;
        }

        /** inline.e:221					check_target( pc, op )*/
        _67check_target(_pc_54046, _op_54047);

        /** inline.e:222					if not adjust_symbol( pc + i ) then*/
        if (IS_ATOM_INT(_i_54049)) {
            _27445 = _pc_54046 + _i_54049;
            if ((object)((uintptr_t)_27445 + (uintptr_t)HIGH_BITS) >= 0){
                _27445 = NewDouble((eudouble)_27445);
            }
        }
        else {
            _27445 = NewDouble((eudouble)_pc_54046 + DBL_PTR(_i_54049)->dbl);
        }
        _27446 = _67adjust_symbol(_27445);
        _27445 = NOVALUE;
        if (IS_ATOM_INT(_27446)) {
            if (_27446 != 0){
                DeRef(_27446);
                _27446 = NOVALUE;
                goto L8; // [193] 203
            }
        }
        else {
            if (DBL_PTR(_27446)->dbl != 0.0){
                DeRef(_27446);
                _27446 = NOVALUE;
                goto L8; // [193] 203
            }
        }
        DeRef(_27446);
        _27446 = NOVALUE;

        /** inline.e:223						return 0*/
        DeRef(_i_54049);
        DeRef(_27434);
        _27434 = NOVALUE;
        DeRef(_27438);
        _27438 = NOVALUE;
        DeRef(_27435);
        _27435 = NOVALUE;
        DeRef(_27440);
        _27440 = NOVALUE;
        DeRef(_27431);
        _27431 = NOVALUE;
        DeRef(_27442);
        _27442 = NOVALUE;
        DeRef(_27424);
        _27424 = NOVALUE;
        return 0;
L8: 
L7: 
L4: 

        /** inline.e:227		end for*/
        _0 = _i_54049;
        if (IS_ATOM_INT(_i_54049)) {
            _i_54049 = _i_54049 + 1;
            if ((object)((uintptr_t)_i_54049 +(uintptr_t) HIGH_BITS) >= 0){
                _i_54049 = NewDouble((eudouble)_i_54049);
            }
        }
        else {
            _i_54049 = binary_op_a(PLUS, _i_54049, 1);
        }
        DeRef(_0);
        goto L1; // [209] 30
L2: 
        ;
        DeRef(_i_54049);
    }

    /** inline.e:228		return 1*/
    DeRef(_27434);
    _27434 = NOVALUE;
    DeRef(_27438);
    _27438 = NOVALUE;
    DeRef(_27435);
    _27435 = NOVALUE;
    DeRef(_27440);
    _27440 = NOVALUE;
    DeRef(_27431);
    _27431 = NOVALUE;
    DeRef(_27442);
    _27442 = NOVALUE;
    DeRef(_27424);
    _27424 = NOVALUE;
    return 1;
    ;
}


object _67is_temp(object _sym_54096)
{
    object _27457 = NOVALUE;
    object _27456 = NOVALUE;
    object _27455 = NOVALUE;
    object _27454 = NOVALUE;
    object _27453 = NOVALUE;
    object _27452 = NOVALUE;
    object _27451 = NOVALUE;
    object _27450 = NOVALUE;
    object _27449 = NOVALUE;
    object _0, _1, _2;
    

    /** inline.e:232		if sym <= 0 then*/
    if (_sym_54096 > 0)
    goto L1; // [5] 16

    /** inline.e:233			return 0*/
    return 0;
L1: 

    /** inline.e:236		return (SymTab[sym][S_MODE] = M_TEMP) and (not TRANSLATE or equal( NOVALUE, SymTab[sym][S_OBJ]) )*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _27449 = (object)*(((s1_ptr)_2)->base + _sym_54096);
    _2 = (object)SEQ_PTR(_27449);
    _27450 = (object)*(((s1_ptr)_2)->base + 3);
    _27449 = NOVALUE;
    if (IS_ATOM_INT(_27450)) {
        _27451 = (_27450 == 3);
    }
    else {
        _27451 = binary_op(EQUALS, _27450, 3);
    }
    _27450 = NOVALUE;
    _27452 = (_36TRANSLATE_21369 == 0);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _27453 = (object)*(((s1_ptr)_2)->base + _sym_54096);
    _2 = (object)SEQ_PTR(_27453);
    _27454 = (object)*(((s1_ptr)_2)->base + 1);
    _27453 = NOVALUE;
    if (_36NOVALUE_21621 == _27454)
    _27455 = 1;
    else if (IS_ATOM_INT(_36NOVALUE_21621) && IS_ATOM_INT(_27454))
    _27455 = 0;
    else
    _27455 = (compare(_36NOVALUE_21621, _27454) == 0);
    _27454 = NOVALUE;
    _27456 = (_27452 != 0 || _27455 != 0);
    _27452 = NOVALUE;
    _27455 = NOVALUE;
    if (IS_ATOM_INT(_27451)) {
        _27457 = (_27451 != 0 && _27456 != 0);
    }
    else {
        _27457 = binary_op(AND, _27451, _27456);
    }
    DeRef(_27451);
    _27451 = NOVALUE;
    _27456 = NOVALUE;
    return _27457;
    ;
}


object _67is_literal(object _sym_54118)
{
    object _mode_54121 = NOVALUE;
    object _27472 = NOVALUE;
    object _27471 = NOVALUE;
    object _27470 = NOVALUE;
    object _27469 = NOVALUE;
    object _27468 = NOVALUE;
    object _27467 = NOVALUE;
    object _27465 = NOVALUE;
    object _27464 = NOVALUE;
    object _27463 = NOVALUE;
    object _27462 = NOVALUE;
    object _27461 = NOVALUE;
    object _27459 = NOVALUE;
    object _0, _1, _2;
    

    /** inline.e:240		if sym <= 0 then*/
    if (_sym_54118 > 0)
    goto L1; // [5] 16

    /** inline.e:241			return 0*/
    return 0;
L1: 

    /** inline.e:244		integer mode = SymTab[sym][S_MODE]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _27459 = (object)*(((s1_ptr)_2)->base + _sym_54118);
    _2 = (object)SEQ_PTR(_27459);
    _mode_54121 = (object)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_mode_54121)){
        _mode_54121 = (object)DBL_PTR(_mode_54121)->dbl;
    }
    _27459 = NOVALUE;

    /** inline.e:245		if (mode = M_CONSTANT and eu:compare( NOVALUE, SymTab[sym][S_OBJ]) ) */
    _27461 = (_mode_54121 == 2);
    if (_27461 == 0) {
        _27462 = 0;
        goto L2; // [40] 66
    }
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _27463 = (object)*(((s1_ptr)_2)->base + _sym_54118);
    _2 = (object)SEQ_PTR(_27463);
    _27464 = (object)*(((s1_ptr)_2)->base + 1);
    _27463 = NOVALUE;
    if (IS_ATOM_INT(_36NOVALUE_21621) && IS_ATOM_INT(_27464)){
        _27465 = (_36NOVALUE_21621 < _27464) ? -1 : (_36NOVALUE_21621 > _27464);
    }
    else{
        _27465 = compare(_36NOVALUE_21621, _27464);
    }
    _27464 = NOVALUE;
    _27462 = (_27465 != 0);
L2: 
    if (_27462 != 0) {
        goto L3; // [66] 117
    }
    if (_36TRANSLATE_21369 == 0) {
        _27467 = 0;
        goto L4; // [72] 86
    }
    _27468 = (_mode_54121 == 3);
    _27467 = (_27468 != 0);
L4: 
    if (_27467 == 0) {
        DeRef(_27469);
        _27469 = 0;
        goto L5; // [86] 112
    }
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _27470 = (object)*(((s1_ptr)_2)->base + _sym_54118);
    _2 = (object)SEQ_PTR(_27470);
    _27471 = (object)*(((s1_ptr)_2)->base + 1);
    _27470 = NOVALUE;
    if (IS_ATOM_INT(_27471) && IS_ATOM_INT(_36NOVALUE_21621)){
        _27472 = (_27471 < _36NOVALUE_21621) ? -1 : (_27471 > _36NOVALUE_21621);
    }
    else{
        _27472 = compare(_27471, _36NOVALUE_21621);
    }
    _27471 = NOVALUE;
    _27469 = (_27472 != 0);
L5: 
    if (_27469 == 0)
    {
        _27469 = NOVALUE;
        goto L6; // [113] 126
    }
    else{
        _27469 = NOVALUE;
    }
L3: 

    /** inline.e:247			return 1*/
    DeRef(_27461);
    _27461 = NOVALUE;
    DeRef(_27468);
    _27468 = NOVALUE;
    return 1;
    goto L7; // [123] 133
L6: 

    /** inline.e:249			return 0*/
    DeRef(_27461);
    _27461 = NOVALUE;
    DeRef(_27468);
    _27468 = NOVALUE;
    return 0;
L7: 
    ;
}


object _67returnf(object _pc_54168)
{
    object _retsym_54170 = NOVALUE;
    object _code_54203 = NOVALUE;
    object _ret_pc_54204 = NOVALUE;
    object _code_54249 = NOVALUE;
    object _ret_pc_54263 = NOVALUE;
    object _27545 = NOVALUE;
    object _27544 = NOVALUE;
    object _27542 = NOVALUE;
    object _27540 = NOVALUE;
    object _27539 = NOVALUE;
    object _27537 = NOVALUE;
    object _27536 = NOVALUE;
    object _27534 = NOVALUE;
    object _27533 = NOVALUE;
    object _27532 = NOVALUE;
    object _27530 = NOVALUE;
    object _27529 = NOVALUE;
    object _27527 = NOVALUE;
    object _27525 = NOVALUE;
    object _27524 = NOVALUE;
    object _27522 = NOVALUE;
    object _27521 = NOVALUE;
    object _27519 = NOVALUE;
    object _27518 = NOVALUE;
    object _27517 = NOVALUE;
    object _27515 = NOVALUE;
    object _27514 = NOVALUE;
    object _27513 = NOVALUE;
    object _27512 = NOVALUE;
    object _27511 = NOVALUE;
    object _27509 = NOVALUE;
    object _27508 = NOVALUE;
    object _27507 = NOVALUE;
    object _27506 = NOVALUE;
    object _27504 = NOVALUE;
    object _27502 = NOVALUE;
    object _27501 = NOVALUE;
    object _27500 = NOVALUE;
    object _27499 = NOVALUE;
    object _27498 = NOVALUE;
    object _27497 = NOVALUE;
    object _27496 = NOVALUE;
    object _27495 = NOVALUE;
    object _27494 = NOVALUE;
    object _27492 = NOVALUE;
    object _27491 = NOVALUE;
    object _27490 = NOVALUE;
    object _27488 = NOVALUE;
    object _27487 = NOVALUE;
    object _27486 = NOVALUE;
    object _27485 = NOVALUE;
    object _27484 = NOVALUE;
    object _27483 = NOVALUE;
    object _27481 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** inline.e:259		symtab_index retsym = inline_code[pc+3]*/
    _27481 = _pc_54168 + 3;
    _2 = (object)SEQ_PTR(_67inline_code_53881);
    _retsym_54170 = (object)*(((s1_ptr)_2)->base + _27481);
    if (!IS_ATOM_INT(_retsym_54170)){
        _retsym_54170 = (object)DBL_PTR(_retsym_54170)->dbl;
    }

    /** inline.e:260		if equal( inline_code[$], BADRETURNF ) then*/
    if (IS_SEQUENCE(_67inline_code_53881)){
            _27483 = SEQ_PTR(_67inline_code_53881)->length;
    }
    else {
        _27483 = 1;
    }
    _2 = (object)SEQ_PTR(_67inline_code_53881);
    _27484 = (object)*(((s1_ptr)_2)->base + _27483);
    if (_27484 == 43)
    _27485 = 1;
    else if (IS_ATOM_INT(_27484) && IS_ATOM_INT(43))
    _27485 = 0;
    else
    _27485 = (compare(_27484, 43) == 0);
    _27484 = NOVALUE;
    if (_27485 == 0)
    {
        _27485 = NOVALUE;
        goto L1; // [34] 102
    }
    else{
        _27485 = NOVALUE;
    }

    /** inline.e:261			if TRANSLATE then*/
    if (_36TRANSLATE_21369 == 0)
    {
        goto L2; // [41] 60
    }
    else{
    }

    /** inline.e:262				inline_code[$] = NOP1*/
    if (IS_SEQUENCE(_67inline_code_53881)){
            _27486 = SEQ_PTR(_67inline_code_53881)->length;
    }
    else {
        _27486 = 1;
    }
    _2 = (object)SEQ_PTR(_67inline_code_53881);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67inline_code_53881 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _27486);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 159;
    DeRef(_1);
    goto L3; // [57] 101
L2: 

    /** inline.e:263			elsif SymTab[inline_sub][S_TOKEN] = PROC then*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _27487 = (object)*(((s1_ptr)_2)->base + _67inline_sub_53895);
    _2 = (object)SEQ_PTR(_27487);
    if (!IS_ATOM_INT(_36S_TOKEN_21409)){
        _27488 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21409)->dbl));
    }
    else{
        _27488 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21409);
    }
    _27487 = NOVALUE;
    if (binary_op_a(NOTEQ, _27488, 27)){
        _27488 = NOVALUE;
        goto L4; // [78] 100
    }
    _27488 = NOVALUE;

    /** inline.e:264				replace_code( {}, length(inline_code), length(inline_code) )*/
    if (IS_SEQUENCE(_67inline_code_53881)){
            _27490 = SEQ_PTR(_67inline_code_53881)->length;
    }
    else {
        _27490 = 1;
    }
    if (IS_SEQUENCE(_67inline_code_53881)){
            _27491 = SEQ_PTR(_67inline_code_53881)->length;
    }
    else {
        _27491 = 1;
    }
    RefDS(_22190);
    _67replace_code(_22190, _27490, _27491);
    _27490 = NOVALUE;
    _27491 = NOVALUE;
L4: 
L3: 
L1: 

    /** inline.e:270		if is_temp( retsym ) */
    _27492 = _67is_temp(_retsym_54170);
    if (IS_ATOM_INT(_27492)) {
        if (_27492 != 0) {
            goto L5; // [108] 150
        }
    }
    else {
        if (DBL_PTR(_27492)->dbl != 0.0) {
            goto L5; // [108] 150
        }
    }
    _27494 = _67is_literal(_retsym_54170);
    if (IS_ATOM_INT(_27494)) {
        _27495 = (_27494 == 0);
    }
    else {
        _27495 = unary_op(NOT, _27494);
    }
    DeRef(_27494);
    _27494 = NOVALUE;
    if (IS_ATOM_INT(_27495)) {
        if (_27495 == 0) {
            DeRef(_27496);
            _27496 = 0;
            goto L6; // [119] 145
        }
    }
    else {
        if (DBL_PTR(_27495)->dbl == 0.0) {
            DeRef(_27496);
            _27496 = 0;
            goto L6; // [119] 145
        }
    }
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _27497 = (object)*(((s1_ptr)_2)->base + _retsym_54170);
    _2 = (object)SEQ_PTR(_27497);
    _27498 = (object)*(((s1_ptr)_2)->base + 4);
    _27497 = NOVALUE;
    if (IS_ATOM_INT(_27498)) {
        _27499 = (_27498 <= 3);
    }
    else {
        _27499 = binary_op(LESSEQ, _27498, 3);
    }
    _27498 = NOVALUE;
    DeRef(_27496);
    if (IS_ATOM_INT(_27499))
    _27496 = (_27499 != 0);
    else
    _27496 = DBL_PTR(_27499)->dbl != 0.0;
L6: 
    if (_27496 == 0)
    {
        _27496 = NOVALUE;
        goto L7; // [146] 393
    }
    else{
        _27496 = NOVALUE;
    }
L5: 

    /** inline.e:272			sequence code = {}*/
    RefDS(_22190);
    DeRef(_code_54203);
    _code_54203 = _22190;

    /** inline.e:274			integer ret_pc = 0*/
    _ret_pc_54204 = 0;

    /** inline.e:276			if not (find( retsym, inline_params ) or find( retsym, proc_vars )) then*/
    _27500 = find_from(_retsym_54170, _67inline_params_53886, 1);
    if (_27500 != 0) {
        DeRef(_27501);
        _27501 = 1;
        goto L8; // [171] 186
    }
    _27502 = find_from(_retsym_54170, _67proc_vars_53882, 1);
    _27501 = (_27502 != 0);
L8: 
    if (_27501 != 0)
    goto L9; // [186] 206
    _27501 = NOVALUE;

    /** inline.e:277				ret_pc = rfind( generic_symbol( retsym ), inline_code, pc )*/
    _27504 = _67generic_symbol(_retsym_54170);
    RefDS(_67inline_code_53881);
    _ret_pc_54204 = _16rfind(_27504, _67inline_code_53881, _pc_54168);
    _27504 = NOVALUE;
    if (!IS_ATOM_INT(_ret_pc_54204)) {
        _1 = (object)(DBL_PTR(_ret_pc_54204)->dbl);
        DeRefDS(_ret_pc_54204);
        _ret_pc_54204 = _1;
    }
L9: 

    /** inline.e:281			if ret_pc and eu:compare( inline_code[ret_pc-1], PRIVATE_INIT_CHECK ) then*/
    if (_ret_pc_54204 == 0) {
        goto LA; // [208] 277
    }
    _27507 = _ret_pc_54204 - 1;
    _2 = (object)SEQ_PTR(_67inline_code_53881);
    _27508 = (object)*(((s1_ptr)_2)->base + _27507);
    if (IS_ATOM_INT(_27508) && IS_ATOM_INT(30)){
        _27509 = (_27508 < 30) ? -1 : (_27508 > 30);
    }
    else{
        _27509 = compare(_27508, 30);
    }
    _27508 = NOVALUE;
    if (_27509 == 0)
    {
        _27509 = NOVALUE;
        goto LA; // [229] 277
    }
    else{
        _27509 = NOVALUE;
    }

    /** inline.e:282				inline_code[ret_pc] = {INLINE_TARGET}*/
    RefDS(_27510);
    _2 = (object)SEQ_PTR(_67inline_code_53881);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67inline_code_53881 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _ret_pc_54204);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27510;
    DeRef(_1);

    /** inline.e:284				if equal( inline_code[ret_pc-1], REF_TEMP ) then*/
    _27511 = _ret_pc_54204 - 1;
    _2 = (object)SEQ_PTR(_67inline_code_53881);
    _27512 = (object)*(((s1_ptr)_2)->base + _27511);
    if (_27512 == 207)
    _27513 = 1;
    else if (IS_ATOM_INT(_27512) && IS_ATOM_INT(207))
    _27513 = 0;
    else
    _27513 = (compare(_27512, 207) == 0);
    _27512 = NOVALUE;
    if (_27513 == 0)
    {
        _27513 = NOVALUE;
        goto LB; // [258] 292
    }
    else{
        _27513 = NOVALUE;
    }

    /** inline.e:287					inline_code[ret_pc-2] = {INLINE_TARGET}*/
    _27514 = _ret_pc_54204 - 2;
    RefDS(_27510);
    _2 = (object)SEQ_PTR(_67inline_code_53881);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67inline_code_53881 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _27514);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27510;
    DeRef(_1);
    goto LB; // [274] 292
LA: 

    /** inline.e:290				code = {ASSIGN, generic_symbol( retsym ), {INLINE_TARGET}}*/
    _27515 = _67generic_symbol(_retsym_54170);
    _0 = _code_54203;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 18;
    ((intptr_t*)_2)[2] = _27515;
    RefDS(_27510);
    ((intptr_t*)_2)[3] = _27510;
    _code_54203 = MAKE_SEQ(_1);
    DeRef(_0);
    _27515 = NOVALUE;
LB: 

    /** inline.e:293			if pc != length( inline_code ) - ( 3 + TRANSLATE ) then*/
    if (IS_SEQUENCE(_67inline_code_53881)){
            _27517 = SEQ_PTR(_67inline_code_53881)->length;
    }
    else {
        _27517 = 1;
    }
    _27518 = 3 + _36TRANSLATE_21369;
    _27519 = _27517 - _27518;
    _27517 = NOVALUE;
    _27518 = NOVALUE;
    if (_pc_54168 == _27519)
    goto LC; // [309] 330

    /** inline.e:294				code &= { ELSE, {INLINE_ADDR, -1 }}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 4;
    ((intptr_t *)_2)[2] = -1;
    _27521 = MAKE_SEQ(_1);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 23;
    ((intptr_t *)_2)[2] = _27521;
    _27522 = MAKE_SEQ(_1);
    _27521 = NOVALUE;
    Concat((object_ptr)&_code_54203, _code_54203, _27522);
    DeRefDS(_27522);
    _27522 = NOVALUE;
LC: 

    /** inline.e:298			replace_code( code, pc, pc + 3 )*/
    _27524 = _pc_54168 + 3;
    if ((object)((uintptr_t)_27524 + (uintptr_t)HIGH_BITS) >= 0){
        _27524 = NewDouble((eudouble)_27524);
    }
    RefDS(_code_54203);
    _67replace_code(_code_54203, _pc_54168, _27524);
    _27524 = NOVALUE;

    /** inline.e:299			ret_pc = find( { INLINE_ADDR, -1 }, inline_code, pc )*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 4;
    ((intptr_t *)_2)[2] = -1;
    _27525 = MAKE_SEQ(_1);
    _ret_pc_54204 = find_from(_27525, _67inline_code_53881, _pc_54168);
    DeRefDS(_27525);
    _27525 = NOVALUE;

    /** inline.e:300			if ret_pc then*/
    if (_ret_pc_54204 == 0)
    {
        goto LD; // [356] 382
    }
    else{
    }

    /** inline.e:301				inline_code[ret_pc][2] = length(inline_code) + 1*/
    _2 = (object)SEQ_PTR(_67inline_code_53881);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67inline_code_53881 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ret_pc_54204 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_67inline_code_53881)){
            _27529 = SEQ_PTR(_67inline_code_53881)->length;
    }
    else {
        _27529 = 1;
    }
    _27530 = _27529 + 1;
    _27529 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27530;
    if( _1 != _27530 ){
        DeRef(_1);
    }
    _27530 = NOVALUE;
    _27527 = NOVALUE;
LD: 

    /** inline.e:303			return 1*/
    DeRef(_code_54203);
    DeRef(_27519);
    _27519 = NOVALUE;
    DeRef(_27495);
    _27495 = NOVALUE;
    DeRef(_27507);
    _27507 = NOVALUE;
    DeRef(_27511);
    _27511 = NOVALUE;
    DeRef(_27492);
    _27492 = NOVALUE;
    DeRef(_27481);
    _27481 = NOVALUE;
    DeRef(_27514);
    _27514 = NOVALUE;
    DeRef(_27499);
    _27499 = NOVALUE;
    return 1;
    goto LE; // [390] 502
L7: 

    /** inline.e:306			sequence code = {ASSIGN, retsym, {INLINE_TARGET}}*/
    _0 = _code_54249;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 18;
    ((intptr_t*)_2)[2] = _retsym_54170;
    RefDS(_27510);
    ((intptr_t*)_2)[3] = _27510;
    _code_54249 = MAKE_SEQ(_1);
    DeRef(_0);

    /** inline.e:307			if pc != length( inline_code ) - ( 3 + TRANSLATE ) then*/
    if (IS_SEQUENCE(_67inline_code_53881)){
            _27532 = SEQ_PTR(_67inline_code_53881)->length;
    }
    else {
        _27532 = 1;
    }
    _27533 = 3 + _36TRANSLATE_21369;
    _27534 = _27532 - _27533;
    _27532 = NOVALUE;
    _27533 = NOVALUE;
    if (_pc_54168 == _27534)
    goto LF; // [420] 441

    /** inline.e:308				code &= { ELSE, {INLINE_ADDR, -1 }}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 4;
    ((intptr_t *)_2)[2] = -1;
    _27536 = MAKE_SEQ(_1);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 23;
    ((intptr_t *)_2)[2] = _27536;
    _27537 = MAKE_SEQ(_1);
    _27536 = NOVALUE;
    Concat((object_ptr)&_code_54249, _code_54249, _27537);
    DeRefDS(_27537);
    _27537 = NOVALUE;
LF: 

    /** inline.e:312			replace_code( code, pc, pc + 3 )*/
    _27539 = _pc_54168 + 3;
    if ((object)((uintptr_t)_27539 + (uintptr_t)HIGH_BITS) >= 0){
        _27539 = NewDouble((eudouble)_27539);
    }
    RefDS(_code_54249);
    _67replace_code(_code_54249, _pc_54168, _27539);
    _27539 = NOVALUE;

    /** inline.e:313			integer ret_pc = find( { INLINE_ADDR, -1 }, inline_code, pc )*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 4;
    ((intptr_t *)_2)[2] = -1;
    _27540 = MAKE_SEQ(_1);
    _ret_pc_54263 = find_from(_27540, _67inline_code_53881, _pc_54168);
    DeRefDS(_27540);
    _27540 = NOVALUE;

    /** inline.e:314			if ret_pc then*/
    if (_ret_pc_54263 == 0)
    {
        goto L10; // [467] 493
    }
    else{
    }

    /** inline.e:315				inline_code[ret_pc][2] = length(inline_code) + 1*/
    _2 = (object)SEQ_PTR(_67inline_code_53881);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67inline_code_53881 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ret_pc_54263 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_67inline_code_53881)){
            _27544 = SEQ_PTR(_67inline_code_53881)->length;
    }
    else {
        _27544 = 1;
    }
    _27545 = _27544 + 1;
    _27544 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27545;
    if( _1 != _27545 ){
        DeRef(_1);
    }
    _27545 = NOVALUE;
    _27542 = NOVALUE;
L10: 

    /** inline.e:317			return 1*/
    DeRef(_code_54249);
    DeRef(_27519);
    _27519 = NOVALUE;
    DeRef(_27495);
    _27495 = NOVALUE;
    DeRef(_27507);
    _27507 = NOVALUE;
    DeRef(_27511);
    _27511 = NOVALUE;
    DeRef(_27492);
    _27492 = NOVALUE;
    DeRef(_27534);
    _27534 = NOVALUE;
    DeRef(_27481);
    _27481 = NOVALUE;
    DeRef(_27514);
    _27514 = NOVALUE;
    DeRef(_27499);
    _27499 = NOVALUE;
    return 1;
LE: 

    /** inline.e:319		return 0*/
    DeRef(_27519);
    _27519 = NOVALUE;
    DeRef(_27495);
    _27495 = NOVALUE;
    DeRef(_27507);
    _27507 = NOVALUE;
    DeRef(_27511);
    _27511 = NOVALUE;
    DeRef(_27492);
    _27492 = NOVALUE;
    DeRef(_27534);
    _27534 = NOVALUE;
    DeRef(_27481);
    _27481 = NOVALUE;
    DeRef(_27514);
    _27514 = NOVALUE;
    DeRef(_27499);
    _27499 = NOVALUE;
    return 0;
    ;
}


object _67inline_op(object _pc_54273)
{
    object _op_54274 = NOVALUE;
    object _code_54279 = NOVALUE;
    object _stlen_54312 = NOVALUE;
    object _file_54317 = NOVALUE;
    object _ok_54322 = NOVALUE;
    object _original_table_54345 = NOVALUE;
    object _jump_table_54349 = NOVALUE;
    object _27606 = NOVALUE;
    object _27605 = NOVALUE;
    object _27604 = NOVALUE;
    object _27603 = NOVALUE;
    object _27602 = NOVALUE;
    object _27601 = NOVALUE;
    object _27600 = NOVALUE;
    object _27599 = NOVALUE;
    object _27598 = NOVALUE;
    object _27597 = NOVALUE;
    object _27596 = NOVALUE;
    object _27595 = NOVALUE;
    object _27592 = NOVALUE;
    object _27591 = NOVALUE;
    object _27590 = NOVALUE;
    object _27589 = NOVALUE;
    object _27587 = NOVALUE;
    object _27585 = NOVALUE;
    object _27584 = NOVALUE;
    object _27582 = NOVALUE;
    object _27578 = NOVALUE;
    object _27577 = NOVALUE;
    object _27576 = NOVALUE;
    object _27575 = NOVALUE;
    object _27574 = NOVALUE;
    object _27573 = NOVALUE;
    object _27570 = NOVALUE;
    object _27569 = NOVALUE;
    object _27567 = NOVALUE;
    object _27566 = NOVALUE;
    object _27564 = NOVALUE;
    object _27562 = NOVALUE;
    object _27561 = NOVALUE;
    object _27560 = NOVALUE;
    object _27559 = NOVALUE;
    object _27558 = NOVALUE;
    object _27557 = NOVALUE;
    object _27556 = NOVALUE;
    object _27554 = NOVALUE;
    object _27553 = NOVALUE;
    object _27552 = NOVALUE;
    object _27550 = NOVALUE;
    object _27549 = NOVALUE;
    object _27548 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** inline.e:324		integer op = inline_code[pc]*/
    _2 = (object)SEQ_PTR(_67inline_code_53881);
    _op_54274 = (object)*(((s1_ptr)_2)->base + _pc_54273);
    if (!IS_ATOM_INT(_op_54274))
    _op_54274 = (object)DBL_PTR(_op_54274)->dbl;

    /** inline.e:326		if op = RETURNP then*/
    if (_op_54274 != 29)
    goto L1; // [15] 150

    /** inline.e:333			sequence code = ""*/
    RefDS(_22190);
    DeRef(_code_54279);
    _code_54279 = _22190;

    /** inline.e:335			if pc != length( inline_code ) - 1 - TRANSLATE then*/
    if (IS_SEQUENCE(_67inline_code_53881)){
            _27548 = SEQ_PTR(_67inline_code_53881)->length;
    }
    else {
        _27548 = 1;
    }
    _27549 = _27548 - 1;
    _27548 = NOVALUE;
    _27550 = _27549 - _36TRANSLATE_21369;
    _27549 = NOVALUE;
    if (_pc_54273 == _27550)
    goto L2; // [43] 92

    /** inline.e:336				code = { ELSE, {INLINE_ADDR, length( inline_code ) + 1 }}*/
    if (IS_SEQUENCE(_67inline_code_53881)){
            _27552 = SEQ_PTR(_67inline_code_53881)->length;
    }
    else {
        _27552 = 1;
    }
    _27553 = _27552 + 1;
    _27552 = NOVALUE;
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 4;
    ((intptr_t *)_2)[2] = _27553;
    _27554 = MAKE_SEQ(_1);
    _27553 = NOVALUE;
    DeRefDS(_code_54279);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 23;
    ((intptr_t *)_2)[2] = _27554;
    _code_54279 = MAKE_SEQ(_1);
    _27554 = NOVALUE;

    /** inline.e:337				if TRANSLATE then*/
    if (_36TRANSLATE_21369 == 0)
    {
        goto L3; // [72] 134
    }
    else{
    }

    /** inline.e:338					inline_code[$] = NOP1*/
    if (IS_SEQUENCE(_67inline_code_53881)){
            _27556 = SEQ_PTR(_67inline_code_53881)->length;
    }
    else {
        _27556 = 1;
    }
    _2 = (object)SEQ_PTR(_67inline_code_53881);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67inline_code_53881 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _27556);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 159;
    DeRef(_1);
    goto L3; // [89] 134
L2: 

    /** inline.e:341			elsif TRANSLATE and inline_code[$] = BADRETURNF then*/
    if (_36TRANSLATE_21369 == 0) {
        goto L4; // [96] 133
    }
    if (IS_SEQUENCE(_67inline_code_53881)){
            _27558 = SEQ_PTR(_67inline_code_53881)->length;
    }
    else {
        _27558 = 1;
    }
    _2 = (object)SEQ_PTR(_67inline_code_53881);
    _27559 = (object)*(((s1_ptr)_2)->base + _27558);
    if (IS_ATOM_INT(_27559)) {
        _27560 = (_27559 == 43);
    }
    else {
        _27560 = binary_op(EQUALS, _27559, 43);
    }
    _27559 = NOVALUE;
    if (_27560 == 0) {
        DeRef(_27560);
        _27560 = NOVALUE;
        goto L4; // [116] 133
    }
    else {
        if (!IS_ATOM_INT(_27560) && DBL_PTR(_27560)->dbl == 0.0){
            DeRef(_27560);
            _27560 = NOVALUE;
            goto L4; // [116] 133
        }
        DeRef(_27560);
        _27560 = NOVALUE;
    }
    DeRef(_27560);
    _27560 = NOVALUE;

    /** inline.e:342				inline_code[$] = NOP1*/
    if (IS_SEQUENCE(_67inline_code_53881)){
            _27561 = SEQ_PTR(_67inline_code_53881)->length;
    }
    else {
        _27561 = 1;
    }
    _2 = (object)SEQ_PTR(_67inline_code_53881);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67inline_code_53881 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _27561);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 159;
    DeRef(_1);
L4: 
L3: 

    /** inline.e:344			replace_code( code, pc, pc + 2 )*/
    _27562 = _pc_54273 + 2;
    if ((object)((uintptr_t)_27562 + (uintptr_t)HIGH_BITS) >= 0){
        _27562 = NewDouble((eudouble)_27562);
    }
    RefDS(_code_54279);
    _67replace_code(_code_54279, _pc_54273, _27562);
    _27562 = NOVALUE;
    DeRefDS(_code_54279);
    _code_54279 = NOVALUE;
    goto L5; // [147] 526
L1: 

    /** inline.e:346		elsif op = RETURNF then*/
    if (_op_54274 != 28)
    goto L6; // [154] 171

    /** inline.e:347			return returnf( pc )*/
    _27564 = _67returnf(_pc_54273);
    DeRef(_27550);
    _27550 = NOVALUE;
    return _27564;
    goto L5; // [168] 526
L6: 

    /** inline.e:349		elsif op = ROUTINE_ID then*/
    if (_op_54274 != 134)
    goto L7; // [175] 273

    /** inline.e:351			integer*/

    /** inline.e:352				stlen = inline_code[pc+2+TRANSLATE],*/
    _27566 = _pc_54273 + 2;
    if ((object)((uintptr_t)_27566 + (uintptr_t)HIGH_BITS) >= 0){
        _27566 = NewDouble((eudouble)_27566);
    }
    if (IS_ATOM_INT(_27566)) {
        _27567 = _27566 + _36TRANSLATE_21369;
    }
    else {
        _27567 = NewDouble(DBL_PTR(_27566)->dbl + (eudouble)_36TRANSLATE_21369);
    }
    DeRef(_27566);
    _27566 = NOVALUE;
    _2 = (object)SEQ_PTR(_67inline_code_53881);
    if (!IS_ATOM_INT(_27567)){
        _stlen_54312 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27567)->dbl));
    }
    else{
        _stlen_54312 = (object)*(((s1_ptr)_2)->base + _27567);
    }
    if (!IS_ATOM_INT(_stlen_54312))
    _stlen_54312 = (object)DBL_PTR(_stlen_54312)->dbl;

    /** inline.e:353				file  = inline_code[pc+4+TRANSLATE],*/
    _27569 = _pc_54273 + 4;
    if ((object)((uintptr_t)_27569 + (uintptr_t)HIGH_BITS) >= 0){
        _27569 = NewDouble((eudouble)_27569);
    }
    if (IS_ATOM_INT(_27569)) {
        _27570 = _27569 + _36TRANSLATE_21369;
    }
    else {
        _27570 = NewDouble(DBL_PTR(_27569)->dbl + (eudouble)_36TRANSLATE_21369);
    }
    DeRef(_27569);
    _27569 = NOVALUE;
    _2 = (object)SEQ_PTR(_67inline_code_53881);
    if (!IS_ATOM_INT(_27570)){
        _file_54317 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27570)->dbl));
    }
    else{
        _file_54317 = (object)*(((s1_ptr)_2)->base + _27570);
    }
    if (!IS_ATOM_INT(_file_54317))
    _file_54317 = (object)DBL_PTR(_file_54317)->dbl;

    /** inline.e:354				ok    = adjust_il( pc, op )*/
    _ok_54322 = _67adjust_il(_pc_54273, _op_54274);
    if (!IS_ATOM_INT(_ok_54322)) {
        _1 = (object)(DBL_PTR(_ok_54322)->dbl);
        DeRefDS(_ok_54322);
        _ok_54322 = _1;
    }

    /** inline.e:355			inline_code[pc+2+TRANSLATE] = stlen*/
    _27573 = _pc_54273 + 2;
    if ((object)((uintptr_t)_27573 + (uintptr_t)HIGH_BITS) >= 0){
        _27573 = NewDouble((eudouble)_27573);
    }
    if (IS_ATOM_INT(_27573)) {
        _27574 = _27573 + _36TRANSLATE_21369;
    }
    else {
        _27574 = NewDouble(DBL_PTR(_27573)->dbl + (eudouble)_36TRANSLATE_21369);
    }
    DeRef(_27573);
    _27573 = NOVALUE;
    _2 = (object)SEQ_PTR(_67inline_code_53881);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67inline_code_53881 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27574))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27574)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27574);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _stlen_54312;
    DeRef(_1);

    /** inline.e:356			inline_code[pc+4+TRANSLATE] = file*/
    _27575 = _pc_54273 + 4;
    if ((object)((uintptr_t)_27575 + (uintptr_t)HIGH_BITS) >= 0){
        _27575 = NewDouble((eudouble)_27575);
    }
    if (IS_ATOM_INT(_27575)) {
        _27576 = _27575 + _36TRANSLATE_21369;
    }
    else {
        _27576 = NewDouble(DBL_PTR(_27575)->dbl + (eudouble)_36TRANSLATE_21369);
    }
    DeRef(_27575);
    _27575 = NOVALUE;
    _2 = (object)SEQ_PTR(_67inline_code_53881);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67inline_code_53881 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27576))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27576)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27576);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _file_54317;
    DeRef(_1);

    /** inline.e:358			return ok*/
    DeRef(_27570);
    _27570 = NOVALUE;
    DeRef(_27564);
    _27564 = NOVALUE;
    DeRef(_27567);
    _27567 = NOVALUE;
    DeRef(_27550);
    _27550 = NOVALUE;
    DeRef(_27574);
    _27574 = NOVALUE;
    DeRef(_27576);
    _27576 = NOVALUE;
    return _ok_54322;
    goto L5; // [270] 526
L7: 

    /** inline.e:360		elsif op_info[op][OP_SIZE_TYPE] = FIXED_SIZE then*/
    _2 = (object)SEQ_PTR(_66op_info_24561);
    _27577 = (object)*(((s1_ptr)_2)->base + _op_54274);
    _2 = (object)SEQ_PTR(_27577);
    _27578 = (object)*(((s1_ptr)_2)->base + 1);
    _27577 = NOVALUE;
    if (binary_op_a(NOTEQ, _27578, 1)){
        _27578 = NOVALUE;
        goto L8; // [289] 397
    }
    _27578 = NOVALUE;

    /** inline.e:361			switch op do*/
    _0 = _op_54274;
    switch ( _0 ){ 

        /** inline.e:362				case SWITCH, SWITCH_RT, SWITCH_I, SWITCH_SPI then*/
        case 185:
        case 202:
        case 193:
        case 192:

        /** inline.e:364					symtab_index original_table = inline_code[pc + 3]*/
        _27582 = _pc_54273 + 3;
        _2 = (object)SEQ_PTR(_67inline_code_53881);
        _original_table_54345 = (object)*(((s1_ptr)_2)->base + _27582);
        if (!IS_ATOM_INT(_original_table_54345)){
            _original_table_54345 = (object)DBL_PTR(_original_table_54345)->dbl;
        }

        /** inline.e:365					symtab_index jump_table = NewStringSym( {-2, length(SymTab) } )*/
        if (IS_SEQUENCE(_37SymTab_15637)){
                _27584 = SEQ_PTR(_37SymTab_15637)->length;
        }
        else {
            _27584 = 1;
        }
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = -2;
        ((intptr_t *)_2)[2] = _27584;
        _27585 = MAKE_SEQ(_1);
        _27584 = NOVALUE;
        _jump_table_54349 = _54NewStringSym(_27585);
        _27585 = NOVALUE;
        if (!IS_ATOM_INT(_jump_table_54349)) {
            _1 = (object)(DBL_PTR(_jump_table_54349)->dbl);
            DeRefDS(_jump_table_54349);
            _jump_table_54349 = _1;
        }

        /** inline.e:366					SymTab[jump_table][S_OBJ] = SymTab[original_table][S_OBJ]*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37SymTab_15637 = MAKE_SEQ(_2);
        }
        _3 = (object)(_jump_table_54349 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _27589 = (object)*(((s1_ptr)_2)->base + _original_table_54345);
        _2 = (object)SEQ_PTR(_27589);
        _27590 = (object)*(((s1_ptr)_2)->base + 1);
        _27589 = NOVALUE;
        Ref(_27590);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 1);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _27590;
        if( _1 != _27590 ){
            DeRef(_1);
        }
        _27590 = NOVALUE;
        _27587 = NOVALUE;

        /** inline.e:367					inline_code[pc+3] = jump_table*/
        _27591 = _pc_54273 + 3;
        _2 = (object)SEQ_PTR(_67inline_code_53881);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _67inline_code_53881 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _27591);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _jump_table_54349;
        DeRef(_1);
    ;}
    /** inline.e:369			return adjust_il( pc, op )*/
    _27592 = _67adjust_il(_pc_54273, _op_54274);
    DeRef(_27570);
    _27570 = NOVALUE;
    DeRef(_27582);
    _27582 = NOVALUE;
    DeRef(_27564);
    _27564 = NOVALUE;
    DeRef(_27567);
    _27567 = NOVALUE;
    DeRef(_27550);
    _27550 = NOVALUE;
    DeRef(_27591);
    _27591 = NOVALUE;
    DeRef(_27574);
    _27574 = NOVALUE;
    DeRef(_27576);
    _27576 = NOVALUE;
    return _27592;
    goto L5; // [394] 526
L8: 

    /** inline.e:372			switch op with fallthru do*/
    _0 = _op_54274;
    switch ( _0 ){ 

        /** inline.e:373				case REF_TEMP then*/
        case 207:

        /** inline.e:374					inline_code[pc+1] = {INLINE_TARGET}*/
        _27595 = _pc_54273 + 1;
        RefDS(_27510);
        _2 = (object)SEQ_PTR(_67inline_code_53881);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _67inline_code_53881 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _27595);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _27510;
        DeRef(_1);

        /** inline.e:376				case CONCAT_N then*/
        case 157:
        case 31:

        /** inline.e:379					if check_for_param( pc + 2 + inline_code[pc+1] ) then*/
        _27596 = _pc_54273 + 2;
        if ((object)((uintptr_t)_27596 + (uintptr_t)HIGH_BITS) >= 0){
            _27596 = NewDouble((eudouble)_27596);
        }
        _27597 = _pc_54273 + 1;
        _2 = (object)SEQ_PTR(_67inline_code_53881);
        _27598 = (object)*(((s1_ptr)_2)->base + _27597);
        if (IS_ATOM_INT(_27596) && IS_ATOM_INT(_27598)) {
            _27599 = _27596 + _27598;
            if ((object)((uintptr_t)_27599 + (uintptr_t)HIGH_BITS) >= 0){
                _27599 = NewDouble((eudouble)_27599);
            }
        }
        else {
            _27599 = binary_op(PLUS, _27596, _27598);
        }
        DeRef(_27596);
        _27596 = NOVALUE;
        _27598 = NOVALUE;
        _27600 = _67check_for_param(_27599);
        _27599 = NOVALUE;
        if (_27600 == 0) {
            DeRef(_27600);
            _27600 = NOVALUE;
            goto L9; // [450] 454
        }
        else {
            if (!IS_ATOM_INT(_27600) && DBL_PTR(_27600)->dbl == 0.0){
                DeRef(_27600);
                _27600 = NOVALUE;
                goto L9; // [450] 454
            }
            DeRef(_27600);
            _27600 = NOVALUE;
        }
        DeRef(_27600);
        _27600 = NOVALUE;
L9: 

        /** inline.e:383					for i = pc + 2 to pc + 2 + inline_code[pc+1] do*/
        _27601 = _pc_54273 + 2;
        if ((object)((uintptr_t)_27601 + (uintptr_t)HIGH_BITS) >= 0){
            _27601 = NewDouble((eudouble)_27601);
        }
        _27602 = _pc_54273 + 2;
        if ((object)((uintptr_t)_27602 + (uintptr_t)HIGH_BITS) >= 0){
            _27602 = NewDouble((eudouble)_27602);
        }
        _27603 = _pc_54273 + 1;
        _2 = (object)SEQ_PTR(_67inline_code_53881);
        _27604 = (object)*(((s1_ptr)_2)->base + _27603);
        if (IS_ATOM_INT(_27602) && IS_ATOM_INT(_27604)) {
            _27605 = _27602 + _27604;
            if ((object)((uintptr_t)_27605 + (uintptr_t)HIGH_BITS) >= 0){
                _27605 = NewDouble((eudouble)_27605);
            }
        }
        else {
            _27605 = binary_op(PLUS, _27602, _27604);
        }
        DeRef(_27602);
        _27602 = NOVALUE;
        _27604 = NOVALUE;
        {
            object _i_54381;
            Ref(_27601);
            _i_54381 = _27601;
LA: 
            if (binary_op_a(GREATER, _i_54381, _27605)){
                goto LB; // [478] 508
            }

            /** inline.e:384						if not adjust_symbol( i ) then*/
            Ref(_i_54381);
            _27606 = _67adjust_symbol(_i_54381);
            if (IS_ATOM_INT(_27606)) {
                if (_27606 != 0){
                    DeRef(_27606);
                    _27606 = NOVALUE;
                    goto LC; // [491] 501
                }
            }
            else {
                if (DBL_PTR(_27606)->dbl != 0.0){
                    DeRef(_27606);
                    _27606 = NOVALUE;
                    goto LC; // [491] 501
                }
            }
            DeRef(_27606);
            _27606 = NOVALUE;

            /** inline.e:385							return 0*/
            DeRef(_i_54381);
            DeRef(_27570);
            _27570 = NOVALUE;
            DeRef(_27595);
            _27595 = NOVALUE;
            DeRef(_27582);
            _27582 = NOVALUE;
            DeRef(_27603);
            _27603 = NOVALUE;
            DeRef(_27564);
            _27564 = NOVALUE;
            DeRef(_27605);
            _27605 = NOVALUE;
            DeRef(_27567);
            _27567 = NOVALUE;
            DeRef(_27550);
            _27550 = NOVALUE;
            DeRef(_27597);
            _27597 = NOVALUE;
            DeRef(_27591);
            _27591 = NOVALUE;
            DeRef(_27601);
            _27601 = NOVALUE;
            DeRef(_27574);
            _27574 = NOVALUE;
            DeRef(_27576);
            _27576 = NOVALUE;
            DeRef(_27592);
            _27592 = NOVALUE;
            return 0;
LC: 

            /** inline.e:388					end for*/
            _0 = _i_54381;
            if (IS_ATOM_INT(_i_54381)) {
                _i_54381 = _i_54381 + 1;
                if ((object)((uintptr_t)_i_54381 +(uintptr_t) HIGH_BITS) >= 0){
                    _i_54381 = NewDouble((eudouble)_i_54381);
                }
            }
            else {
                _i_54381 = binary_op_a(PLUS, _i_54381, 1);
            }
            DeRef(_0);
            goto LA; // [503] 485
LB: 
            ;
            DeRef(_i_54381);
        }

        /** inline.e:389					return 1*/
        DeRef(_27570);
        _27570 = NOVALUE;
        DeRef(_27595);
        _27595 = NOVALUE;
        DeRef(_27582);
        _27582 = NOVALUE;
        DeRef(_27603);
        _27603 = NOVALUE;
        DeRef(_27564);
        _27564 = NOVALUE;
        DeRef(_27605);
        _27605 = NOVALUE;
        DeRef(_27567);
        _27567 = NOVALUE;
        DeRef(_27550);
        _27550 = NOVALUE;
        DeRef(_27597);
        _27597 = NOVALUE;
        DeRef(_27591);
        _27591 = NOVALUE;
        DeRef(_27601);
        _27601 = NOVALUE;
        DeRef(_27574);
        _27574 = NOVALUE;
        DeRef(_27576);
        _27576 = NOVALUE;
        DeRef(_27592);
        _27592 = NOVALUE;
        return 1;

        /** inline.e:390				case else*/
        default:

        /** inline.e:391					return 0*/
        DeRef(_27570);
        _27570 = NOVALUE;
        DeRef(_27595);
        _27595 = NOVALUE;
        DeRef(_27582);
        _27582 = NOVALUE;
        DeRef(_27603);
        _27603 = NOVALUE;
        DeRef(_27564);
        _27564 = NOVALUE;
        DeRef(_27605);
        _27605 = NOVALUE;
        DeRef(_27567);
        _27567 = NOVALUE;
        DeRef(_27550);
        _27550 = NOVALUE;
        DeRef(_27597);
        _27597 = NOVALUE;
        DeRef(_27591);
        _27591 = NOVALUE;
        DeRef(_27601);
        _27601 = NOVALUE;
        DeRef(_27574);
        _27574 = NOVALUE;
        DeRef(_27576);
        _27576 = NOVALUE;
        DeRef(_27592);
        _27592 = NOVALUE;
        return 0;
    ;}L5: 

    /** inline.e:394		return 1*/
    DeRef(_27570);
    _27570 = NOVALUE;
    DeRef(_27595);
    _27595 = NOVALUE;
    DeRef(_27582);
    _27582 = NOVALUE;
    DeRef(_27603);
    _27603 = NOVALUE;
    DeRef(_27564);
    _27564 = NOVALUE;
    DeRef(_27605);
    _27605 = NOVALUE;
    DeRef(_27567);
    _27567 = NOVALUE;
    DeRef(_27550);
    _27550 = NOVALUE;
    DeRef(_27597);
    _27597 = NOVALUE;
    DeRef(_27591);
    _27591 = NOVALUE;
    DeRef(_27601);
    _27601 = NOVALUE;
    DeRef(_27574);
    _27574 = NOVALUE;
    DeRef(_27576);
    _27576 = NOVALUE;
    DeRef(_27592);
    _27592 = NOVALUE;
    return 1;
    ;
}


void _67restore_code()
{
    object _27608 = NOVALUE;
    object _0, _1, _2;
    

    /** inline.e:399		if length( temp_code ) then*/
    if (IS_SEQUENCE(_67temp_code_54391)){
            _27608 = SEQ_PTR(_67temp_code_54391)->length;
    }
    else {
        _27608 = 1;
    }
    if (_27608 == 0)
    {
        _27608 = NOVALUE;
        goto L1; // [8] 21
    }
    else{
        _27608 = NOVALUE;
    }

    /** inline.e:400			Code = temp_code*/
    RefDS(_67temp_code_54391);
    DeRef(_36Code_21859);
    _36Code_21859 = _67temp_code_54391;
L1: 

    /** inline.e:402	end procedure*/
    return;
    ;
}


void _67check_inline(object _sub_54400)
{
    object _pc_54429 = NOVALUE;
    object _s_54431 = NOVALUE;
    object _backpatch_op_54469 = NOVALUE;
    object _op_54473 = NOVALUE;
    object _rtn_idx_54484 = NOVALUE;
    object _args_54489 = NOVALUE;
    object _args_54521 = NOVALUE;
    object _values_54550 = NOVALUE;
    object _27695 = NOVALUE;
    object _27694 = NOVALUE;
    object _27692 = NOVALUE;
    object _27689 = NOVALUE;
    object _27687 = NOVALUE;
    object _27686 = NOVALUE;
    object _27685 = NOVALUE;
    object _27683 = NOVALUE;
    object _27682 = NOVALUE;
    object _27681 = NOVALUE;
    object _27680 = NOVALUE;
    object _27679 = NOVALUE;
    object _27678 = NOVALUE;
    object _27677 = NOVALUE;
    object _27676 = NOVALUE;
    object _27675 = NOVALUE;
    object _27673 = NOVALUE;
    object _27672 = NOVALUE;
    object _27671 = NOVALUE;
    object _27670 = NOVALUE;
    object _27669 = NOVALUE;
    object _27667 = NOVALUE;
    object _27666 = NOVALUE;
    object _27665 = NOVALUE;
    object _27664 = NOVALUE;
    object _27663 = NOVALUE;
    object _27661 = NOVALUE;
    object _27660 = NOVALUE;
    object _27659 = NOVALUE;
    object _27658 = NOVALUE;
    object _27657 = NOVALUE;
    object _27656 = NOVALUE;
    object _27655 = NOVALUE;
    object _27654 = NOVALUE;
    object _27653 = NOVALUE;
    object _27652 = NOVALUE;
    object _27651 = NOVALUE;
    object _27650 = NOVALUE;
    object _27649 = NOVALUE;
    object _27648 = NOVALUE;
    object _27646 = NOVALUE;
    object _27643 = NOVALUE;
    object _27638 = NOVALUE;
    object _27636 = NOVALUE;
    object _27633 = NOVALUE;
    object _27632 = NOVALUE;
    object _27631 = NOVALUE;
    object _27630 = NOVALUE;
    object _27629 = NOVALUE;
    object _27628 = NOVALUE;
    object _27627 = NOVALUE;
    object _27626 = NOVALUE;
    object _27624 = NOVALUE;
    object _27622 = NOVALUE;
    object _27621 = NOVALUE;
    object _27619 = NOVALUE;
    object _27617 = NOVALUE;
    object _27615 = NOVALUE;
    object _27613 = NOVALUE;
    object _27612 = NOVALUE;
    object _27611 = NOVALUE;
    object _27610 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** inline.e:411		if OpTrace or SymTab[sub][S_TOKEN] = TYPE then*/
    if (_36OpTrace_21840 != 0) {
        goto L1; // [7] 34
    }
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _27610 = (object)*(((s1_ptr)_2)->base + _sub_54400);
    _2 = (object)SEQ_PTR(_27610);
    if (!IS_ATOM_INT(_36S_TOKEN_21409)){
        _27611 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21409)->dbl));
    }
    else{
        _27611 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21409);
    }
    _27610 = NOVALUE;
    if (IS_ATOM_INT(_27611)) {
        _27612 = (_27611 == 504);
    }
    else {
        _27612 = binary_op(EQUALS, _27611, 504);
    }
    _27611 = NOVALUE;
    if (_27612 == 0) {
        DeRef(_27612);
        _27612 = NOVALUE;
        goto L2; // [30] 40
    }
    else {
        if (!IS_ATOM_INT(_27612) && DBL_PTR(_27612)->dbl == 0.0){
            DeRef(_27612);
            _27612 = NOVALUE;
            goto L2; // [30] 40
        }
        DeRef(_27612);
        _27612 = NOVALUE;
    }
    DeRef(_27612);
    _27612 = NOVALUE;
L1: 

    /** inline.e:412			return*/
    DeRefi(_backpatch_op_54469);
    return;
L2: 

    /** inline.e:414		inline_sub      = sub*/
    _67inline_sub_53895 = _sub_54400;

    /** inline.e:415		if get_fwdref_count() then*/
    _27613 = _44get_fwdref_count();
    if (_27613 == 0) {
        DeRef(_27613);
        _27613 = NOVALUE;
        goto L3; // [52] 65
    }
    else {
        if (!IS_ATOM_INT(_27613) && DBL_PTR(_27613)->dbl == 0.0){
            DeRef(_27613);
            _27613 = NOVALUE;
            goto L3; // [52] 65
        }
        DeRef(_27613);
        _27613 = NOVALUE;
    }
    DeRef(_27613);
    _27613 = NOVALUE;

    /** inline.e:416			defer()*/
    _67defer();

    /** inline.e:417			return*/
    DeRefi(_backpatch_op_54469);
    return;
L3: 

    /** inline.e:419		temp_code = ""*/
    RefDS(_22190);
    DeRef(_67temp_code_54391);
    _67temp_code_54391 = _22190;

    /** inline.e:420		if sub != CurrentSub then*/
    if (_sub_54400 == _36CurrentSub_21775)
    goto L4; // [76] 99

    /** inline.e:421			Code = SymTab[sub][S_CODE]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _27615 = (object)*(((s1_ptr)_2)->base + _sub_54400);
    DeRef(_36Code_21859);
    _2 = (object)SEQ_PTR(_27615);
    if (!IS_ATOM_INT(_36S_CODE_21416)){
        _36Code_21859 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21416)->dbl));
    }
    else{
        _36Code_21859 = (object)*(((s1_ptr)_2)->base + _36S_CODE_21416);
    }
    Ref(_36Code_21859);
    _27615 = NOVALUE;
    goto L5; // [96] 109
L4: 

    /** inline.e:423			temp_code = Code*/
    RefDS(_36Code_21859);
    DeRef(_67temp_code_54391);
    _67temp_code_54391 = _36Code_21859;
L5: 

    /** inline.e:426		if length(Code) > OpInline then*/
    if (IS_SEQUENCE(_36Code_21859)){
            _27617 = SEQ_PTR(_36Code_21859)->length;
    }
    else {
        _27617 = 1;
    }
    if (_27617 <= _36OpInline_21845)
    goto L6; // [118] 128

    /** inline.e:427			return*/
    DeRefi(_backpatch_op_54469);
    return;
L6: 

    /** inline.e:430		inline_code     = Code*/
    RefDS(_36Code_21859);
    DeRef(_67inline_code_53881);
    _67inline_code_53881 = _36Code_21859;

    /** inline.e:431		return_gotos    = 0*/
    _67return_gotos_53890 = 0;

    /** inline.e:432		prev_pc         = 1*/
    _67prev_pc_53889 = 1;

    /** inline.e:433		proc_vars       = {}*/
    RefDS(_22190);
    DeRefi(_67proc_vars_53882);
    _67proc_vars_53882 = _22190;

    /** inline.e:434		inline_temps    = {}*/
    RefDS(_22190);
    DeRef(_67inline_temps_53883);
    _67inline_temps_53883 = _22190;

    /** inline.e:435		inline_params   = {}*/
    RefDS(_22190);
    DeRefi(_67inline_params_53886);
    _67inline_params_53886 = _22190;

    /** inline.e:436		assigned_params = {}*/
    RefDS(_22190);
    DeRef(_67assigned_params_53887);
    _67assigned_params_53887 = _22190;

    /** inline.e:438		integer pc = 1*/
    _pc_54429 = 1;

    /** inline.e:439		symtab_index s = SymTab[sub][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _27619 = (object)*(((s1_ptr)_2)->base + _sub_54400);
    _2 = (object)SEQ_PTR(_27619);
    _s_54431 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_54431)){
        _s_54431 = (object)DBL_PTR(_s_54431)->dbl;
    }
    _27619 = NOVALUE;

    /** inline.e:440		for p = 1 to SymTab[sub][S_NUM_ARGS] do*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _27621 = (object)*(((s1_ptr)_2)->base + _sub_54400);
    _2 = (object)SEQ_PTR(_27621);
    if (!IS_ATOM_INT(_36S_NUM_ARGS_21455)){
        _27622 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21455)->dbl));
    }
    else{
        _27622 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21455);
    }
    _27621 = NOVALUE;
    {
        object _p_54437;
        _p_54437 = 1;
L7: 
        if (binary_op_a(GREATER, _p_54437, _27622)){
            goto L8; // [210] 248
        }

        /** inline.e:441			inline_params &= s*/
        Append(&_67inline_params_53886, _67inline_params_53886, _s_54431);

        /** inline.e:442			s = SymTab[s][S_NEXT]*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _27624 = (object)*(((s1_ptr)_2)->base + _s_54431);
        _2 = (object)SEQ_PTR(_27624);
        _s_54431 = (object)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_s_54431)){
            _s_54431 = (object)DBL_PTR(_s_54431)->dbl;
        }
        _27624 = NOVALUE;

        /** inline.e:443		end for*/
        _0 = _p_54437;
        if (IS_ATOM_INT(_p_54437)) {
            _p_54437 = _p_54437 + 1;
            if ((object)((uintptr_t)_p_54437 +(uintptr_t) HIGH_BITS) >= 0){
                _p_54437 = NewDouble((eudouble)_p_54437);
            }
        }
        else {
            _p_54437 = binary_op_a(PLUS, _p_54437, 1);
        }
        DeRef(_0);
        goto L7; // [243] 217
L8: 
        ;
        DeRef(_p_54437);
    }

    /** inline.e:445		while s != 0 and */
L9: 
    _27626 = (_s_54431 != 0);
    if (_27626 == 0) {
        goto LA; // [257] 335
    }
    _27628 = _54sym_scope(_s_54431);
    if (IS_ATOM_INT(_27628)) {
        _27629 = (_27628 <= 3);
    }
    else {
        _27629 = binary_op(LESSEQ, _27628, 3);
    }
    DeRef(_27628);
    _27628 = NOVALUE;
    if (IS_ATOM_INT(_27629)) {
        if (_27629 != 0) {
            DeRef(_27630);
            _27630 = 1;
            goto LB; // [271] 289
        }
    }
    else {
        if (DBL_PTR(_27629)->dbl != 0.0) {
            DeRef(_27630);
            _27630 = 1;
            goto LB; // [271] 289
        }
    }
    _27631 = _54sym_scope(_s_54431);
    if (IS_ATOM_INT(_27631)) {
        _27632 = (_27631 == 9);
    }
    else {
        _27632 = binary_op(EQUALS, _27631, 9);
    }
    DeRef(_27631);
    _27631 = NOVALUE;
    DeRef(_27630);
    if (IS_ATOM_INT(_27632))
    _27630 = (_27632 != 0);
    else
    _27630 = DBL_PTR(_27632)->dbl != 0.0;
LB: 
    if (_27630 == 0)
    {
        _27630 = NOVALUE;
        goto LA; // [290] 335
    }
    else{
        _27630 = NOVALUE;
    }

    /** inline.e:447			if sym_scope( s ) != SC_UNDEFINED then*/
    _27633 = _54sym_scope(_s_54431);
    if (binary_op_a(EQUALS, _27633, 9)){
        DeRef(_27633);
        _27633 = NOVALUE;
        goto LC; // [301] 314
    }
    DeRef(_27633);
    _27633 = NOVALUE;

    /** inline.e:448				proc_vars &= s*/
    Append(&_67proc_vars_53882, _67proc_vars_53882, _s_54431);
LC: 

    /** inline.e:451			s = SymTab[s][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _27636 = (object)*(((s1_ptr)_2)->base + _s_54431);
    _2 = (object)SEQ_PTR(_27636);
    _s_54431 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_54431)){
        _s_54431 = (object)DBL_PTR(_s_54431)->dbl;
    }
    _27636 = NOVALUE;

    /** inline.e:452		end while*/
    goto L9; // [332] 253
LA: 

    /** inline.e:453		sequence backpatch_op = {}*/
    RefDS(_22190);
    DeRefi(_backpatch_op_54469);
    _backpatch_op_54469 = _22190;

    /** inline.e:454		while pc < length( inline_code ) do*/
LD: 
    if (IS_SEQUENCE(_67inline_code_53881)){
            _27638 = SEQ_PTR(_67inline_code_53881)->length;
    }
    else {
        _27638 = 1;
    }
    if (_pc_54429 >= _27638)
    goto LE; // [352] 869

    /** inline.e:456			integer op = inline_code[pc]*/
    _2 = (object)SEQ_PTR(_67inline_code_53881);
    _op_54473 = (object)*(((s1_ptr)_2)->base + _pc_54429);
    if (!IS_ATOM_INT(_op_54473))
    _op_54473 = (object)DBL_PTR(_op_54473)->dbl;

    /** inline.e:457			switch op do*/
    _0 = _op_54473;
    switch ( _0 ){ 

        /** inline.e:458				case PROC_FORWARD, FUNC_FORWARD then*/
        case 195:
        case 196:

        /** inline.e:459					defer()*/
        _67defer();

        /** inline.e:460					restore_code()*/
        _67restore_code();

        /** inline.e:461					return*/
        DeRefi(_backpatch_op_54469);
        _27622 = NOVALUE;
        DeRef(_27632);
        _27632 = NOVALUE;
        DeRef(_27626);
        _27626 = NOVALUE;
        DeRef(_27629);
        _27629 = NOVALUE;
        return;
        goto LF; // [390] 851

        /** inline.e:463				case PROC, FUNC then*/
        case 27:
        case 501:

        /** inline.e:464					symtab_index rtn_idx = inline_code[pc+1]*/
        _27643 = _pc_54429 + 1;
        _2 = (object)SEQ_PTR(_67inline_code_53881);
        _rtn_idx_54484 = (object)*(((s1_ptr)_2)->base + _27643);
        if (!IS_ATOM_INT(_rtn_idx_54484)){
            _rtn_idx_54484 = (object)DBL_PTR(_rtn_idx_54484)->dbl;
        }

        /** inline.e:465					if rtn_idx = sub then*/
        if (_rtn_idx_54484 != _sub_54400)
        goto L10; // [414] 428

        /** inline.e:467						restore_code()*/
        _67restore_code();

        /** inline.e:468						return*/
        DeRefi(_backpatch_op_54469);
        _27622 = NOVALUE;
        DeRef(_27632);
        _27632 = NOVALUE;
        DeRef(_27626);
        _27626 = NOVALUE;
        _27643 = NOVALUE;
        DeRef(_27629);
        _27629 = NOVALUE;
        return;
L10: 

        /** inline.e:471					integer args = SymTab[rtn_idx][S_NUM_ARGS]*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _27646 = (object)*(((s1_ptr)_2)->base + _rtn_idx_54484);
        _2 = (object)SEQ_PTR(_27646);
        if (!IS_ATOM_INT(_36S_NUM_ARGS_21455)){
            _args_54489 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21455)->dbl));
        }
        else{
            _args_54489 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21455);
        }
        if (!IS_ATOM_INT(_args_54489)){
            _args_54489 = (object)DBL_PTR(_args_54489)->dbl;
        }
        _27646 = NOVALUE;

        /** inline.e:472					if SymTab[rtn_idx][S_TOKEN] != PROC and check_for_param( pc + args + 2 ) then*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _27648 = (object)*(((s1_ptr)_2)->base + _rtn_idx_54484);
        _2 = (object)SEQ_PTR(_27648);
        if (!IS_ATOM_INT(_36S_TOKEN_21409)){
            _27649 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21409)->dbl));
        }
        else{
            _27649 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21409);
        }
        _27648 = NOVALUE;
        if (IS_ATOM_INT(_27649)) {
            _27650 = (_27649 != 27);
        }
        else {
            _27650 = binary_op(NOTEQ, _27649, 27);
        }
        _27649 = NOVALUE;
        if (IS_ATOM_INT(_27650)) {
            if (_27650 == 0) {
                goto L11; // [464] 485
            }
        }
        else {
            if (DBL_PTR(_27650)->dbl == 0.0) {
                goto L11; // [464] 485
            }
        }
        _27652 = _pc_54429 + _args_54489;
        if ((object)((uintptr_t)_27652 + (uintptr_t)HIGH_BITS) >= 0){
            _27652 = NewDouble((eudouble)_27652);
        }
        if (IS_ATOM_INT(_27652)) {
            _27653 = _27652 + 2;
            if ((object)((uintptr_t)_27653 + (uintptr_t)HIGH_BITS) >= 0){
                _27653 = NewDouble((eudouble)_27653);
            }
        }
        else {
            _27653 = NewDouble(DBL_PTR(_27652)->dbl + (eudouble)2);
        }
        DeRef(_27652);
        _27652 = NOVALUE;
        _27654 = _67check_for_param(_27653);
        _27653 = NOVALUE;
        if (_27654 == 0) {
            DeRef(_27654);
            _27654 = NOVALUE;
            goto L11; // [481] 485
        }
        else {
            if (!IS_ATOM_INT(_27654) && DBL_PTR(_27654)->dbl == 0.0){
                DeRef(_27654);
                _27654 = NOVALUE;
                goto L11; // [481] 485
            }
            DeRef(_27654);
            _27654 = NOVALUE;
        }
        DeRef(_27654);
        _27654 = NOVALUE;
L11: 

        /** inline.e:475					for i = 2 to args + 1 + (SymTab[rtn_idx][S_TOKEN] != PROC) do*/
        _27655 = _args_54489 + 1;
        if (_27655 > MAXINT){
            _27655 = NewDouble((eudouble)_27655);
        }
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _27656 = (object)*(((s1_ptr)_2)->base + _rtn_idx_54484);
        _2 = (object)SEQ_PTR(_27656);
        if (!IS_ATOM_INT(_36S_TOKEN_21409)){
            _27657 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21409)->dbl));
        }
        else{
            _27657 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21409);
        }
        _27656 = NOVALUE;
        if (IS_ATOM_INT(_27657)) {
            _27658 = (_27657 != 27);
        }
        else {
            _27658 = binary_op(NOTEQ, _27657, 27);
        }
        _27657 = NOVALUE;
        if (IS_ATOM_INT(_27655) && IS_ATOM_INT(_27658)) {
            _27659 = _27655 + _27658;
            if ((object)((uintptr_t)_27659 + (uintptr_t)HIGH_BITS) >= 0){
                _27659 = NewDouble((eudouble)_27659);
            }
        }
        else {
            _27659 = binary_op(PLUS, _27655, _27658);
        }
        DeRef(_27655);
        _27655 = NOVALUE;
        DeRef(_27658);
        _27658 = NOVALUE;
        {
            object _i_54506;
            _i_54506 = 2;
L12: 
            if (binary_op_a(GREATER, _i_54506, _27659)){
                goto L13; // [513] 550
            }

            /** inline.e:476						if not adjust_symbol( pc + i ) then */
            if (IS_ATOM_INT(_i_54506)) {
                _27660 = _pc_54429 + _i_54506;
                if ((object)((uintptr_t)_27660 + (uintptr_t)HIGH_BITS) >= 0){
                    _27660 = NewDouble((eudouble)_27660);
                }
            }
            else {
                _27660 = NewDouble((eudouble)_pc_54429 + DBL_PTR(_i_54506)->dbl);
            }
            _27661 = _67adjust_symbol(_27660);
            _27660 = NOVALUE;
            if (IS_ATOM_INT(_27661)) {
                if (_27661 != 0){
                    DeRef(_27661);
                    _27661 = NOVALUE;
                    goto L14; // [530] 543
                }
            }
            else {
                if (DBL_PTR(_27661)->dbl != 0.0){
                    DeRef(_27661);
                    _27661 = NOVALUE;
                    goto L14; // [530] 543
                }
            }
            DeRef(_27661);
            _27661 = NOVALUE;

            /** inline.e:477							defer()*/
            _67defer();

            /** inline.e:478							return*/
            DeRef(_i_54506);
            DeRefi(_backpatch_op_54469);
            _27622 = NOVALUE;
            DeRef(_27659);
            _27659 = NOVALUE;
            DeRef(_27632);
            _27632 = NOVALUE;
            DeRef(_27626);
            _27626 = NOVALUE;
            DeRef(_27650);
            _27650 = NOVALUE;
            DeRef(_27643);
            _27643 = NOVALUE;
            DeRef(_27629);
            _27629 = NOVALUE;
            return;
L14: 

            /** inline.e:480					end for*/
            _0 = _i_54506;
            if (IS_ATOM_INT(_i_54506)) {
                _i_54506 = _i_54506 + 1;
                if ((object)((uintptr_t)_i_54506 +(uintptr_t) HIGH_BITS) >= 0){
                    _i_54506 = NewDouble((eudouble)_i_54506);
                }
            }
            else {
                _i_54506 = binary_op_a(PLUS, _i_54506, 1);
            }
            DeRef(_0);
            goto L12; // [545] 520
L13: 
            ;
            DeRef(_i_54506);
        }
        goto LF; // [552] 851

        /** inline.e:482				case RIGHT_BRACE_N then*/
        case 31:

        /** inline.e:484					sequence args = inline_code[pc+2..inline_code[pc+1] + pc + 1]*/
        _27663 = _pc_54429 + 2;
        if ((object)((uintptr_t)_27663 + (uintptr_t)HIGH_BITS) >= 0){
            _27663 = NewDouble((eudouble)_27663);
        }
        _27664 = _pc_54429 + 1;
        _2 = (object)SEQ_PTR(_67inline_code_53881);
        _27665 = (object)*(((s1_ptr)_2)->base + _27664);
        if (IS_ATOM_INT(_27665)) {
            _27666 = _27665 + _pc_54429;
            if ((object)((uintptr_t)_27666 + (uintptr_t)HIGH_BITS) >= 0){
                _27666 = NewDouble((eudouble)_27666);
            }
        }
        else {
            _27666 = binary_op(PLUS, _27665, _pc_54429);
        }
        _27665 = NOVALUE;
        if (IS_ATOM_INT(_27666)) {
            _27667 = _27666 + 1;
        }
        else
        _27667 = binary_op(PLUS, 1, _27666);
        DeRef(_27666);
        _27666 = NOVALUE;
        rhs_slice_target = (object_ptr)&_args_54521;
        RHS_Slice(_67inline_code_53881, _27663, _27667);

        /** inline.e:486					for i = 1 to length(args) - 1 do*/
        if (IS_SEQUENCE(_args_54521)){
                _27669 = SEQ_PTR(_args_54521)->length;
        }
        else {
            _27669 = 1;
        }
        _27670 = _27669 - 1;
        _27669 = NOVALUE;
        {
            object _i_54529;
            _i_54529 = 1;
L15: 
            if (_i_54529 > _27670){
                goto L16; // [598] 644
            }

            /** inline.e:487						if find( args[i], args, i + 1 ) then*/
            _2 = (object)SEQ_PTR(_args_54521);
            _27671 = (object)*(((s1_ptr)_2)->base + _i_54529);
            _27672 = _i_54529 + 1;
            _27673 = find_from(_27671, _args_54521, _27672);
            _27671 = NOVALUE;
            _27672 = NOVALUE;
            if (_27673 == 0)
            {
                _27673 = NOVALUE;
                goto L17; // [620] 637
            }
            else{
                _27673 = NOVALUE;
            }

            /** inline.e:488							defer()*/
            _67defer();

            /** inline.e:489							restore_code()*/
            _67restore_code();

            /** inline.e:490							return*/
            DeRefDS(_args_54521);
            DeRefi(_backpatch_op_54469);
            _27622 = NOVALUE;
            DeRef(_27659);
            _27659 = NOVALUE;
            DeRef(_27632);
            _27632 = NOVALUE;
            DeRef(_27626);
            _27626 = NOVALUE;
            DeRef(_27650);
            _27650 = NOVALUE;
            DeRef(_27670);
            _27670 = NOVALUE;
            DeRef(_27643);
            _27643 = NOVALUE;
            DeRef(_27664);
            _27664 = NOVALUE;
            DeRef(_27629);
            _27629 = NOVALUE;
            DeRef(_27667);
            _27667 = NOVALUE;
            DeRef(_27663);
            _27663 = NOVALUE;
            return;
L17: 

            /** inline.e:492					end for*/
            _i_54529 = _i_54529 + 1;
            goto L15; // [639] 605
L16: 
            ;
        }

        /** inline.e:493					goto "inline op"*/
        DeRef(_args_54521);
        _args_54521 = NOVALUE;
        goto G18;
        goto LF; // [654] 851

        /** inline.e:495				case RIGHT_BRACE_2 then*/
        case 85:

        /** inline.e:496					if equal( inline_code[pc+1], inline_code[pc+2] ) then*/
        _27675 = _pc_54429 + 1;
        _2 = (object)SEQ_PTR(_67inline_code_53881);
        _27676 = (object)*(((s1_ptr)_2)->base + _27675);
        _27677 = _pc_54429 + 2;
        _2 = (object)SEQ_PTR(_67inline_code_53881);
        _27678 = (object)*(((s1_ptr)_2)->base + _27677);
        if (_27676 == _27678)
        _27679 = 1;
        else if (IS_ATOM_INT(_27676) && IS_ATOM_INT(_27678))
        _27679 = 0;
        else
        _27679 = (compare(_27676, _27678) == 0);
        _27676 = NOVALUE;
        _27678 = NOVALUE;
        if (_27679 == 0)
        {
            _27679 = NOVALUE;
            goto L19; // [686] 703
        }
        else{
            _27679 = NOVALUE;
        }

        /** inline.e:497						defer()*/
        _67defer();

        /** inline.e:498						restore_code()*/
        _67restore_code();

        /** inline.e:499						return*/
        DeRefi(_backpatch_op_54469);
        _27622 = NOVALUE;
        DeRef(_27659);
        _27659 = NOVALUE;
        _27675 = NOVALUE;
        DeRef(_27632);
        _27632 = NOVALUE;
        DeRef(_27626);
        _27626 = NOVALUE;
        DeRef(_27650);
        _27650 = NOVALUE;
        DeRef(_27670);
        _27670 = NOVALUE;
        DeRef(_27643);
        _27643 = NOVALUE;
        _27677 = NOVALUE;
        DeRef(_27664);
        _27664 = NOVALUE;
        DeRef(_27629);
        _27629 = NOVALUE;
        DeRef(_27667);
        _27667 = NOVALUE;
        DeRef(_27663);
        _27663 = NOVALUE;
        return;
L19: 

        /** inline.e:501					goto "inline op"*/
        goto G18;
        goto LF; // [711] 851

        /** inline.e:503				case EXIT_BLOCK then*/
        case 206:

        /** inline.e:504					replace_code( "", pc, pc + 1 )*/
        _27680 = _pc_54429 + 1;
        if (_27680 > MAXINT){
            _27680 = NewDouble((eudouble)_27680);
        }
        RefDS(_22190);
        _67replace_code(_22190, _pc_54429, _27680);
        _27680 = NOVALUE;

        /** inline.e:505					continue*/
        goto LD; // [732] 347
        goto LF; // [734] 851

        /** inline.e:507				case SWITCH_RT then*/
        case 202:

        /** inline.e:508					sequence values = SymTab[inline_code[pc+2]][S_OBJ]*/
        _27681 = _pc_54429 + 2;
        _2 = (object)SEQ_PTR(_67inline_code_53881);
        _27682 = (object)*(((s1_ptr)_2)->base + _27681);
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        if (!IS_ATOM_INT(_27682)){
            _27683 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27682)->dbl));
        }
        else{
            _27683 = (object)*(((s1_ptr)_2)->base + _27682);
        }
        DeRef(_values_54550);
        _2 = (object)SEQ_PTR(_27683);
        _values_54550 = (object)*(((s1_ptr)_2)->base + 1);
        Ref(_values_54550);
        _27683 = NOVALUE;

        /** inline.e:509					for i = 1 to length( values ) do*/
        if (IS_SEQUENCE(_values_54550)){
                _27685 = SEQ_PTR(_values_54550)->length;
        }
        else {
            _27685 = 1;
        }
        {
            object _i_54558;
            _i_54558 = 1;
L1A: 
            if (_i_54558 > _27685){
                goto L1B; // [771] 811
            }

            /** inline.e:510						if sequence( values[i] ) then*/
            _2 = (object)SEQ_PTR(_values_54550);
            _27686 = (object)*(((s1_ptr)_2)->base + _i_54558);
            _27687 = IS_SEQUENCE(_27686);
            _27686 = NOVALUE;
            if (_27687 == 0)
            {
                _27687 = NOVALUE;
                goto L1C; // [787] 804
            }
            else{
                _27687 = NOVALUE;
            }

            /** inline.e:512							defer()*/
            _67defer();

            /** inline.e:513							restore_code()*/
            _67restore_code();

            /** inline.e:514							return*/
            DeRefDS(_values_54550);
            DeRefi(_backpatch_op_54469);
            _27622 = NOVALUE;
            DeRef(_27681);
            _27681 = NOVALUE;
            DeRef(_27659);
            _27659 = NOVALUE;
            _27682 = NOVALUE;
            DeRef(_27675);
            _27675 = NOVALUE;
            DeRef(_27632);
            _27632 = NOVALUE;
            DeRef(_27626);
            _27626 = NOVALUE;
            DeRef(_27650);
            _27650 = NOVALUE;
            DeRef(_27670);
            _27670 = NOVALUE;
            DeRef(_27643);
            _27643 = NOVALUE;
            DeRef(_27677);
            _27677 = NOVALUE;
            DeRef(_27664);
            _27664 = NOVALUE;
            DeRef(_27629);
            _27629 = NOVALUE;
            DeRef(_27667);
            _27667 = NOVALUE;
            DeRef(_27663);
            _27663 = NOVALUE;
            return;
L1C: 

            /** inline.e:516					end for*/
            _i_54558 = _i_54558 + 1;
            goto L1A; // [806] 778
L1B: 
            ;
        }

        /** inline.e:517					backpatch_op = append( backpatch_op, pc )*/
        Append(&_backpatch_op_54469, _backpatch_op_54469, _pc_54429);
        DeRef(_values_54550);
        _values_54550 = NOVALUE;

        /** inline.e:520				case else*/
        default:

        /** inline.e:521				label "inline op"*/
G18:

        /** inline.e:522					if not inline_op( pc ) then*/
        _27689 = _67inline_op(_pc_54429);
        if (IS_ATOM_INT(_27689)) {
            if (_27689 != 0){
                DeRef(_27689);
                _27689 = NOVALUE;
                goto L1D; // [833] 850
            }
        }
        else {
            if (DBL_PTR(_27689)->dbl != 0.0){
                DeRef(_27689);
                _27689 = NOVALUE;
                goto L1D; // [833] 850
            }
        }
        DeRef(_27689);
        _27689 = NOVALUE;

        /** inline.e:524						defer()*/
        _67defer();

        /** inline.e:525						restore_code()*/
        _67restore_code();

        /** inline.e:526						return*/
        DeRefi(_backpatch_op_54469);
        _27622 = NOVALUE;
        DeRef(_27681);
        _27681 = NOVALUE;
        DeRef(_27659);
        _27659 = NOVALUE;
        _27682 = NOVALUE;
        DeRef(_27675);
        _27675 = NOVALUE;
        DeRef(_27632);
        _27632 = NOVALUE;
        DeRef(_27626);
        _27626 = NOVALUE;
        DeRef(_27650);
        _27650 = NOVALUE;
        DeRef(_27670);
        _27670 = NOVALUE;
        DeRef(_27643);
        _27643 = NOVALUE;
        DeRef(_27677);
        _27677 = NOVALUE;
        DeRef(_27664);
        _27664 = NOVALUE;
        DeRef(_27629);
        _27629 = NOVALUE;
        DeRef(_27667);
        _27667 = NOVALUE;
        DeRef(_27663);
        _27663 = NOVALUE;
        return;
L1D: 
    ;}LF: 

    /** inline.e:530			pc = advance( pc, inline_code )*/
    RefDS(_67inline_code_53881);
    _pc_54429 = _67advance(_pc_54429, _67inline_code_53881);
    if (!IS_ATOM_INT(_pc_54429)) {
        _1 = (object)(DBL_PTR(_pc_54429)->dbl);
        DeRefDS(_pc_54429);
        _pc_54429 = _1;
    }

    /** inline.e:532		end while*/
    goto LD; // [866] 347
LE: 

    /** inline.e:534		SymTab[sub][S_INLINE] = { sort( assigned_params ), inline_code, backpatch_op }*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sub_54400 + ((s1_ptr)_2)->base);
    RefDS(_67assigned_params_53887);
    _27694 = _24sort(_67assigned_params_53887, 1);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _27694;
    RefDS(_67inline_code_53881);
    ((intptr_t*)_2)[2] = _67inline_code_53881;
    RefDS(_backpatch_op_54469);
    ((intptr_t*)_2)[3] = _backpatch_op_54469;
    _27695 = MAKE_SEQ(_1);
    _27694 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 29);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27695;
    if( _1 != _27695 ){
        DeRef(_1);
    }
    _27695 = NOVALUE;
    _27692 = NOVALUE;

    /** inline.e:535		restore_code()*/
    _67restore_code();

    /** inline.e:536	end procedure*/
    DeRefDSi(_backpatch_op_54469);
    _27622 = NOVALUE;
    DeRef(_27681);
    _27681 = NOVALUE;
    DeRef(_27659);
    _27659 = NOVALUE;
    _27682 = NOVALUE;
    DeRef(_27675);
    _27675 = NOVALUE;
    DeRef(_27632);
    _27632 = NOVALUE;
    DeRef(_27626);
    _27626 = NOVALUE;
    DeRef(_27650);
    _27650 = NOVALUE;
    DeRef(_27670);
    _27670 = NOVALUE;
    DeRef(_27643);
    _27643 = NOVALUE;
    DeRef(_27677);
    _27677 = NOVALUE;
    DeRef(_27664);
    _27664 = NOVALUE;
    DeRef(_27629);
    _27629 = NOVALUE;
    DeRef(_27667);
    _27667 = NOVALUE;
    DeRef(_27663);
    _27663 = NOVALUE;
    return;
    ;
}


void _67replace_temp(object _pc_54578)
{
    object _temp_num_54579 = NOVALUE;
    object _needed_54582 = NOVALUE;
    object _27708 = NOVALUE;
    object _27707 = NOVALUE;
    object _27706 = NOVALUE;
    object _27705 = NOVALUE;
    object _27703 = NOVALUE;
    object _27701 = NOVALUE;
    object _27698 = NOVALUE;
    object _27696 = NOVALUE;
    object _0, _1, _2;
    

    /** inline.e:539		integer temp_num = inline_code[pc][2]*/
    _2 = (object)SEQ_PTR(_67inline_code_53881);
    _27696 = (object)*(((s1_ptr)_2)->base + _pc_54578);
    _2 = (object)SEQ_PTR(_27696);
    _temp_num_54579 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_temp_num_54579)){
        _temp_num_54579 = (object)DBL_PTR(_temp_num_54579)->dbl;
    }
    _27696 = NOVALUE;

    /** inline.e:540		integer needed = temp_num - length( inline_temps )*/
    if (IS_SEQUENCE(_67inline_temps_53883)){
            _27698 = SEQ_PTR(_67inline_temps_53883)->length;
    }
    else {
        _27698 = 1;
    }
    _needed_54582 = _temp_num_54579 - _27698;
    _27698 = NOVALUE;

    /** inline.e:541		if needed > 0 then*/
    if (_needed_54582 <= 0)
    goto L1; // [30] 47

    /** inline.e:542			inline_temps &= repeat( 0, needed )*/
    _27701 = Repeat(0, _needed_54582);
    Concat((object_ptr)&_67inline_temps_53883, _67inline_temps_53883, _27701);
    DeRefDS(_27701);
    _27701 = NOVALUE;
L1: 

    /** inline.e:545		if not inline_temps[temp_num] then*/
    _2 = (object)SEQ_PTR(_67inline_temps_53883);
    _27703 = (object)*(((s1_ptr)_2)->base + _temp_num_54579);
    if (IS_ATOM_INT(_27703)) {
        if (_27703 != 0){
            _27703 = NOVALUE;
            goto L2; // [55] 100
        }
    }
    else {
        if (DBL_PTR(_27703)->dbl != 0.0){
            _27703 = NOVALUE;
            goto L2; // [55] 100
        }
    }
    _27703 = NOVALUE;

    /** inline.e:546			if TRANSLATE then*/
    if (_36TRANSLATE_21369 == 0)
    {
        goto L3; // [62] 84
    }
    else{
    }

    /** inline.e:547				inline_temps[temp_num] = new_inline_var( -temp_num, 0 )*/
    if ((uintptr_t)_temp_num_54579 == (uintptr_t)HIGH_BITS){
        _27705 = (object)NewDouble((eudouble) -HIGH_BITS);
    }
    else{
        _27705 = - _temp_num_54579;
    }
    _27706 = _67new_inline_var(_27705, 0);
    _27705 = NOVALUE;
    _2 = (object)SEQ_PTR(_67inline_temps_53883);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67inline_temps_53883 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _temp_num_54579);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27706;
    if( _1 != _27706 ){
        DeRef(_1);
    }
    _27706 = NOVALUE;
    goto L4; // [81] 99
L3: 

    /** inline.e:549				inline_temps[temp_num] = NewTempSym( TRUE )*/
    _27707 = _54NewTempSym(_13TRUE_447);
    _2 = (object)SEQ_PTR(_67inline_temps_53883);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67inline_temps_53883 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _temp_num_54579);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27707;
    if( _1 != _27707 ){
        DeRef(_1);
    }
    _27707 = NOVALUE;
L4: 
L2: 

    /** inline.e:554		inline_code[pc] = inline_temps[temp_num]*/
    _2 = (object)SEQ_PTR(_67inline_temps_53883);
    _27708 = (object)*(((s1_ptr)_2)->base + _temp_num_54579);
    Ref(_27708);
    _2 = (object)SEQ_PTR(_67inline_code_53881);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67inline_code_53881 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _pc_54578);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27708;
    if( _1 != _27708 ){
        DeRef(_1);
    }
    _27708 = NOVALUE;

    /** inline.e:555	end procedure*/
    return;
    ;
}


object _67get_param_sym(object _pc_54604)
{
    object _il_54605 = NOVALUE;
    object _px_54613 = NOVALUE;
    object _27715 = NOVALUE;
    object _27712 = NOVALUE;
    object _27711 = NOVALUE;
    object _27710 = NOVALUE;
    object _0, _1, _2;
    

    /** inline.e:558		object il = inline_code[pc]*/
    DeRef(_il_54605);
    _2 = (object)SEQ_PTR(_67inline_code_53881);
    _il_54605 = (object)*(((s1_ptr)_2)->base + _pc_54604);
    Ref(_il_54605);

    /** inline.e:559		if integer( il ) then*/
    if (IS_ATOM_INT(_il_54605))
    _27710 = 1;
    else if (IS_ATOM_DBL(_il_54605))
    _27710 = IS_ATOM_INT(DoubleToInt(_il_54605));
    else
    _27710 = 0;
    if (_27710 == 0)
    {
        _27710 = NOVALUE;
        goto L1; // [16] 34
    }
    else{
        _27710 = NOVALUE;
    }

    /** inline.e:560			return inline_code[pc]*/
    _2 = (object)SEQ_PTR(_67inline_code_53881);
    _27711 = (object)*(((s1_ptr)_2)->base + _pc_54604);
    Ref(_27711);
    DeRef(_il_54605);
    return _27711;
    goto L2; // [31] 53
L1: 

    /** inline.e:562		elsif length( il ) = 1 then*/
    if (IS_SEQUENCE(_il_54605)){
            _27712 = SEQ_PTR(_il_54605)->length;
    }
    else {
        _27712 = 1;
    }
    if (_27712 != 1)
    goto L3; // [39] 52

    /** inline.e:563			return inline_target*/
    DeRef(_il_54605);
    _27711 = NOVALUE;
    return _67inline_target_53888;
L3: 
L2: 

    /** inline.e:567		integer px = il[2]*/
    _2 = (object)SEQ_PTR(_il_54605);
    _px_54613 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_px_54613)){
        _px_54613 = (object)DBL_PTR(_px_54613)->dbl;
    }

    /** inline.e:568		return passed_params[px]*/
    _2 = (object)SEQ_PTR(_67passed_params_53884);
    _27715 = (object)*(((s1_ptr)_2)->base + _px_54613);
    Ref(_27715);
    DeRef(_il_54605);
    _27711 = NOVALUE;
    return _27715;
    ;
}


object _67get_original_sym(object _pc_54618)
{
    object _il_54619 = NOVALUE;
    object _px_54627 = NOVALUE;
    object _27722 = NOVALUE;
    object _27719 = NOVALUE;
    object _27718 = NOVALUE;
    object _27717 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_pc_54618)) {
        _1 = (object)(DBL_PTR(_pc_54618)->dbl);
        DeRefDS(_pc_54618);
        _pc_54618 = _1;
    }

    /** inline.e:572		object il = inline_code[pc]*/
    DeRef(_il_54619);
    _2 = (object)SEQ_PTR(_67inline_code_53881);
    _il_54619 = (object)*(((s1_ptr)_2)->base + _pc_54618);
    Ref(_il_54619);

    /** inline.e:573		if integer( il ) then*/
    if (IS_ATOM_INT(_il_54619))
    _27717 = 1;
    else if (IS_ATOM_DBL(_il_54619))
    _27717 = IS_ATOM_INT(DoubleToInt(_il_54619));
    else
    _27717 = 0;
    if (_27717 == 0)
    {
        _27717 = NOVALUE;
        goto L1; // [16] 34
    }
    else{
        _27717 = NOVALUE;
    }

    /** inline.e:574			return inline_code[pc]*/
    _2 = (object)SEQ_PTR(_67inline_code_53881);
    _27718 = (object)*(((s1_ptr)_2)->base + _pc_54618);
    Ref(_27718);
    DeRef(_il_54619);
    return _27718;
    goto L2; // [31] 53
L1: 

    /** inline.e:576		elsif length( il ) = 1 then*/
    if (IS_SEQUENCE(_il_54619)){
            _27719 = SEQ_PTR(_il_54619)->length;
    }
    else {
        _27719 = 1;
    }
    if (_27719 != 1)
    goto L3; // [39] 52

    /** inline.e:577			return inline_target*/
    DeRef(_il_54619);
    _27718 = NOVALUE;
    return _67inline_target_53888;
L3: 
L2: 

    /** inline.e:581		integer px = il[2]*/
    _2 = (object)SEQ_PTR(_il_54619);
    _px_54627 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_px_54627)){
        _px_54627 = (object)DBL_PTR(_px_54627)->dbl;
    }

    /** inline.e:582		return original_params[px]*/
    _2 = (object)SEQ_PTR(_67original_params_53885);
    _27722 = (object)*(((s1_ptr)_2)->base + _px_54627);
    Ref(_27722);
    DeRef(_il_54619);
    _27718 = NOVALUE;
    return _27722;
    ;
}


void _67replace_var(object _pc_54636)
{
    object _27726 = NOVALUE;
    object _27725 = NOVALUE;
    object _27724 = NOVALUE;
    object _0, _1, _2;
    

    /** inline.e:590		inline_code[pc] = proc_vars[inline_code[pc][2]]*/
    _2 = (object)SEQ_PTR(_67inline_code_53881);
    _27724 = (object)*(((s1_ptr)_2)->base + _pc_54636);
    _2 = (object)SEQ_PTR(_27724);
    _27725 = (object)*(((s1_ptr)_2)->base + 2);
    _27724 = NOVALUE;
    _2 = (object)SEQ_PTR(_67proc_vars_53882);
    if (!IS_ATOM_INT(_27725)){
        _27726 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27725)->dbl));
    }
    else{
        _27726 = (object)*(((s1_ptr)_2)->base + _27725);
    }
    _2 = (object)SEQ_PTR(_67inline_code_53881);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67inline_code_53881 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _pc_54636);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27726;
    if( _1 != _27726 ){
        DeRef(_1);
    }
    _27726 = NOVALUE;

    /** inline.e:591	end procedure*/
    _27725 = NOVALUE;
    return;
    ;
}


void _67fix_switch_rt(object _pc_54642)
{
    object _value_table_54644 = NOVALUE;
    object _jump_table_54651 = NOVALUE;
    object _27746 = NOVALUE;
    object _27745 = NOVALUE;
    object _27744 = NOVALUE;
    object _27743 = NOVALUE;
    object _27742 = NOVALUE;
    object _27741 = NOVALUE;
    object _27739 = NOVALUE;
    object _27738 = NOVALUE;
    object _27737 = NOVALUE;
    object _27736 = NOVALUE;
    object _27735 = NOVALUE;
    object _27733 = NOVALUE;
    object _27731 = NOVALUE;
    object _27730 = NOVALUE;
    object _27728 = NOVALUE;
    object _27727 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** inline.e:594		symtab_index value_table = NewStringSym( {-1, length(SymTab)} )*/
    if (IS_SEQUENCE(_37SymTab_15637)){
            _27727 = SEQ_PTR(_37SymTab_15637)->length;
    }
    else {
        _27727 = 1;
    }
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -1;
    ((intptr_t *)_2)[2] = _27727;
    _27728 = MAKE_SEQ(_1);
    _27727 = NOVALUE;
    _value_table_54644 = _54NewStringSym(_27728);
    _27728 = NOVALUE;
    if (!IS_ATOM_INT(_value_table_54644)) {
        _1 = (object)(DBL_PTR(_value_table_54644)->dbl);
        DeRefDS(_value_table_54644);
        _value_table_54644 = _1;
    }

    /** inline.e:595		symtab_index jump_table  = NewStringSym( {-1, length(SymTab)} )*/
    if (IS_SEQUENCE(_37SymTab_15637)){
            _27730 = SEQ_PTR(_37SymTab_15637)->length;
    }
    else {
        _27730 = 1;
    }
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -1;
    ((intptr_t *)_2)[2] = _27730;
    _27731 = MAKE_SEQ(_1);
    _27730 = NOVALUE;
    _jump_table_54651 = _54NewStringSym(_27731);
    _27731 = NOVALUE;
    if (!IS_ATOM_INT(_jump_table_54651)) {
        _1 = (object)(DBL_PTR(_jump_table_54651)->dbl);
        DeRefDS(_jump_table_54651);
        _jump_table_54651 = _1;
    }

    /** inline.e:597		SymTab[value_table][S_OBJ] = SymTab[inline_code[pc+2]][S_OBJ]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_value_table_54644 + ((s1_ptr)_2)->base);
    _27735 = _pc_54642 + 2;
    _2 = (object)SEQ_PTR(_67inline_code_53881);
    _27736 = (object)*(((s1_ptr)_2)->base + _27735);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!IS_ATOM_INT(_27736)){
        _27737 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27736)->dbl));
    }
    else{
        _27737 = (object)*(((s1_ptr)_2)->base + _27736);
    }
    _2 = (object)SEQ_PTR(_27737);
    _27738 = (object)*(((s1_ptr)_2)->base + 1);
    _27737 = NOVALUE;
    Ref(_27738);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27738;
    if( _1 != _27738 ){
        DeRef(_1);
    }
    _27738 = NOVALUE;
    _27733 = NOVALUE;

    /** inline.e:598		SymTab[jump_table][S_OBJ]  = SymTab[inline_code[pc+3]][S_OBJ]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_jump_table_54651 + ((s1_ptr)_2)->base);
    _27741 = _pc_54642 + 3;
    _2 = (object)SEQ_PTR(_67inline_code_53881);
    _27742 = (object)*(((s1_ptr)_2)->base + _27741);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!IS_ATOM_INT(_27742)){
        _27743 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27742)->dbl));
    }
    else{
        _27743 = (object)*(((s1_ptr)_2)->base + _27742);
    }
    _2 = (object)SEQ_PTR(_27743);
    _27744 = (object)*(((s1_ptr)_2)->base + 1);
    _27743 = NOVALUE;
    Ref(_27744);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27744;
    if( _1 != _27744 ){
        DeRef(_1);
    }
    _27744 = NOVALUE;
    _27739 = NOVALUE;

    /** inline.e:600		inline_code[pc+2] = value_table*/
    _27745 = _pc_54642 + 2;
    _2 = (object)SEQ_PTR(_67inline_code_53881);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67inline_code_53881 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _27745);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _value_table_54644;
    DeRef(_1);

    /** inline.e:601		inline_code[pc+3] = jump_table*/
    _27746 = _pc_54642 + 3;
    _2 = (object)SEQ_PTR(_67inline_code_53881);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67inline_code_53881 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _27746);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _jump_table_54651;
    DeRef(_1);

    /** inline.e:603	end procedure*/
    _27746 = NOVALUE;
    _27742 = NOVALUE;
    _27735 = NOVALUE;
    _27741 = NOVALUE;
    _27736 = NOVALUE;
    _27745 = NOVALUE;
    return;
    ;
}


void _67fixup_special_op(object _pc_54681)
{
    object _op_54682 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_pc_54681)) {
        _1 = (object)(DBL_PTR(_pc_54681)->dbl);
        DeRefDS(_pc_54681);
        _pc_54681 = _1;
    }

    /** inline.e:606		integer op = inline_code[pc]*/
    _2 = (object)SEQ_PTR(_67inline_code_53881);
    _op_54682 = (object)*(((s1_ptr)_2)->base + _pc_54681);
    if (!IS_ATOM_INT(_op_54682))
    _op_54682 = (object)DBL_PTR(_op_54682)->dbl;

    /** inline.e:607		switch op with fallthru do*/
    _0 = _op_54682;
    switch ( _0 ){ 

        /** inline.e:608			case SWITCH_RT then*/
        case 202:

        /** inline.e:609				fix_switch_rt( pc )*/
        _67fix_switch_rt(_pc_54681);

        /** inline.e:610				break*/
        goto L1; // [29] 32
    ;}L1: 

    /** inline.e:612	end procedure*/
    return;
    ;
}


object _67new_inline_var(object _ps_54693, object _reuse_54694)
{
    object _var_54696 = NOVALUE;
    object _vtype_54697 = NOVALUE;
    object _name_54698 = NOVALUE;
    object _s_54700 = NOVALUE;
    object _27809 = NOVALUE;
    object _27808 = NOVALUE;
    object _27806 = NOVALUE;
    object _27803 = NOVALUE;
    object _27802 = NOVALUE;
    object _27800 = NOVALUE;
    object _27797 = NOVALUE;
    object _27796 = NOVALUE;
    object _27795 = NOVALUE;
    object _27793 = NOVALUE;
    object _27788 = NOVALUE;
    object _27783 = NOVALUE;
    object _27782 = NOVALUE;
    object _27781 = NOVALUE;
    object _27780 = NOVALUE;
    object _27777 = NOVALUE;
    object _27775 = NOVALUE;
    object _27772 = NOVALUE;
    object _27767 = NOVALUE;
    object _27766 = NOVALUE;
    object _27765 = NOVALUE;
    object _27764 = NOVALUE;
    object _27763 = NOVALUE;
    object _27760 = NOVALUE;
    object _27759 = NOVALUE;
    object _27758 = NOVALUE;
    object _27757 = NOVALUE;
    object _27756 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_ps_54693)) {
        _1 = (object)(DBL_PTR(_ps_54693)->dbl);
        DeRefDS(_ps_54693);
        _ps_54693 = _1;
    }

    /** inline.e:622			var = 0, */
    _var_54696 = 0;

    /** inline.e:624		sequence name*/

    /** inline.e:627		if reuse then*/

    /** inline.e:631		if not var then*/

    /** inline.e:632			if ps > 0 then*/
    if (_ps_54693 <= 0)
    goto L1; // [45] 222

    /** inline.e:633				s = ps*/
    _s_54700 = _ps_54693;

    /** inline.e:634				if TRANSLATE then*/
    if (_36TRANSLATE_21369 == 0)
    {
        goto L2; // [60] 102
    }
    else{
    }

    /** inline.e:635					name = sprintf( "%s_inlined_%s", {SymTab[s][S_NAME], SymTab[inline_sub][S_NAME] })*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _27756 = (object)*(((s1_ptr)_2)->base + _s_54700);
    _2 = (object)SEQ_PTR(_27756);
    if (!IS_ATOM_INT(_36S_NAME_21404)){
        _27757 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21404)->dbl));
    }
    else{
        _27757 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21404);
    }
    _27756 = NOVALUE;
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _27758 = (object)*(((s1_ptr)_2)->base + _67inline_sub_53895);
    _2 = (object)SEQ_PTR(_27758);
    if (!IS_ATOM_INT(_36S_NAME_21404)){
        _27759 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21404)->dbl));
    }
    else{
        _27759 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21404);
    }
    _27758 = NOVALUE;
    Ref(_27759);
    Ref(_27757);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _27757;
    ((intptr_t *)_2)[2] = _27759;
    _27760 = MAKE_SEQ(_1);
    _27759 = NOVALUE;
    _27757 = NOVALUE;
    DeRefi(_name_54698);
    _name_54698 = EPrintf(-9999999, _27755, _27760);
    DeRefDS(_27760);
    _27760 = NOVALUE;
    goto L3; // [99] 139
L2: 

    /** inline.e:637					name = sprintf( "%s (from inlined routine '%s'", {SymTab[s][S_NAME], SymTab[inline_sub][S_NAME] })*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _27763 = (object)*(((s1_ptr)_2)->base + _s_54700);
    _2 = (object)SEQ_PTR(_27763);
    if (!IS_ATOM_INT(_36S_NAME_21404)){
        _27764 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21404)->dbl));
    }
    else{
        _27764 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21404);
    }
    _27763 = NOVALUE;
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _27765 = (object)*(((s1_ptr)_2)->base + _67inline_sub_53895);
    _2 = (object)SEQ_PTR(_27765);
    if (!IS_ATOM_INT(_36S_NAME_21404)){
        _27766 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21404)->dbl));
    }
    else{
        _27766 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21404);
    }
    _27765 = NOVALUE;
    Ref(_27766);
    Ref(_27764);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _27764;
    ((intptr_t *)_2)[2] = _27766;
    _27767 = MAKE_SEQ(_1);
    _27766 = NOVALUE;
    _27764 = NOVALUE;
    DeRefi(_name_54698);
    _name_54698 = EPrintf(-9999999, _27762, _27767);
    DeRefDS(_27767);
    _27767 = NOVALUE;
L3: 

    /** inline.e:640				if reuse then*/
    if (_reuse_54694 == 0)
    {
        goto L4; // [141] 163
    }
    else{
    }

    /** inline.e:641					if not TRANSLATE then*/
    if (_36TRANSLATE_21369 != 0)
    goto L5; // [148] 203

    /** inline.e:642						name &= ")"*/
    Concat((object_ptr)&_name_54698, _name_54698, _26532);
    goto L5; // [160] 203
L4: 

    /** inline.e:645					if TRANSLATE then*/
    if (_36TRANSLATE_21369 == 0)
    {
        goto L6; // [167] 187
    }
    else{
    }

    /** inline.e:646						name &= sprintf( "_at_%d", inline_start)*/
    _27772 = EPrintf(-9999999, _27771, _67inline_start_53893);
    Concat((object_ptr)&_name_54698, _name_54698, _27772);
    DeRefDS(_27772);
    _27772 = NOVALUE;
    goto L7; // [184] 202
L6: 

    /** inline.e:648						name &= sprintf( " at %d)", inline_start)*/
    _27775 = EPrintf(-9999999, _27774, _67inline_start_53893);
    Concat((object_ptr)&_name_54698, _name_54698, _27775);
    DeRefDS(_27775);
    _27775 = NOVALUE;
L7: 
L5: 

    /** inline.e:652				vtype = SymTab[s][S_VTYPE]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _27777 = (object)*(((s1_ptr)_2)->base + _s_54700);
    _2 = (object)SEQ_PTR(_27777);
    _vtype_54697 = (object)*(((s1_ptr)_2)->base + 15);
    if (!IS_ATOM_INT(_vtype_54697)){
        _vtype_54697 = (object)DBL_PTR(_vtype_54697)->dbl;
    }
    _27777 = NOVALUE;
    goto L8; // [219] 286
L1: 

    /** inline.e:654				name = sprintf( "%s_%d", {SymTab[inline_sub][S_NAME], -ps})*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _27780 = (object)*(((s1_ptr)_2)->base + _67inline_sub_53895);
    _2 = (object)SEQ_PTR(_27780);
    if (!IS_ATOM_INT(_36S_NAME_21404)){
        _27781 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21404)->dbl));
    }
    else{
        _27781 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21404);
    }
    _27780 = NOVALUE;
    if ((uintptr_t)_ps_54693 == (uintptr_t)HIGH_BITS){
        _27782 = (object)NewDouble((eudouble) -HIGH_BITS);
    }
    else{
        _27782 = - _ps_54693;
    }
    Ref(_27781);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _27781;
    ((intptr_t *)_2)[2] = _27782;
    _27783 = MAKE_SEQ(_1);
    _27782 = NOVALUE;
    _27781 = NOVALUE;
    DeRefi(_name_54698);
    _name_54698 = EPrintf(-9999999, _27779, _27783);
    DeRefDS(_27783);
    _27783 = NOVALUE;

    /** inline.e:655				if reuse then*/
    if (_reuse_54694 == 0)
    {
        goto L9; // [251] 263
    }
    else{
    }

    /** inline.e:656					name &= "__tmp"*/
    Concat((object_ptr)&_name_54698, _name_54698, _27785);
    goto LA; // [260] 276
L9: 

    /** inline.e:658					name &= sprintf( "__tmp_at%d", inline_start)*/
    _27788 = EPrintf(-9999999, _27787, _67inline_start_53893);
    Concat((object_ptr)&_name_54698, _name_54698, _27788);
    DeRefDS(_27788);
    _27788 = NOVALUE;
LA: 

    /** inline.e:660				vtype = object_type*/
    _vtype_54697 = _54object_type_47136;
L8: 

    /** inline.e:662			if CurrentSub = TopLevelSub then*/
    if (_36CurrentSub_21775 != _36TopLevelSub_21774)
    goto LB; // [292] 325

    /** inline.e:663				var = NewEntry( name, varnum, SC_LOCAL, VARIABLE, INLINE_HASHVAL, 0, vtype )*/
    RefDS(_name_54698);
    _var_54696 = _54NewEntry(_name_54698, _67varnum_53892, 5, -100, 2004, 0, _vtype_54697);
    if (!IS_ATOM_INT(_var_54696)) {
        _1 = (object)(DBL_PTR(_var_54696)->dbl);
        DeRefDS(_var_54696);
        _var_54696 = _1;
    }
    goto LC; // [322] 416
LB: 

    /** inline.e:666				var = NewBasicEntry( name, varnum, SC_PRIVATE, VARIABLE, INLINE_HASHVAL, 0, vtype )*/
    RefDS(_name_54698);
    _var_54696 = _54NewBasicEntry(_name_54698, _67varnum_53892, 3, -100, 2004, 0, _vtype_54697);
    if (!IS_ATOM_INT(_var_54696)) {
        _1 = (object)(DBL_PTR(_var_54696)->dbl);
        DeRefDS(_var_54696);
        _var_54696 = _1;
    }

    /** inline.e:667				SymTab[var][S_NEXT] = SymTab[last_param][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_var_54696 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _27795 = (object)*(((s1_ptr)_2)->base + _67last_param_53896);
    _2 = (object)SEQ_PTR(_27795);
    _27796 = (object)*(((s1_ptr)_2)->base + 2);
    _27795 = NOVALUE;
    Ref(_27796);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27796;
    if( _1 != _27796 ){
        DeRef(_1);
    }
    _27796 = NOVALUE;
    _27793 = NOVALUE;

    /** inline.e:668				SymTab[last_param][S_NEXT] = var*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_67last_param_53896 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _var_54696;
    DeRef(_1);
    _27797 = NOVALUE;

    /** inline.e:669				if last_param = last_sym then*/
    if (_67last_param_53896 != _54last_sym_47145)
    goto LD; // [403] 415

    /** inline.e:670					last_sym = var*/
    _54last_sym_47145 = _var_54696;
LD: 
LC: 

    /** inline.e:673			if deferred_inlining then*/
    if (_67deferred_inlining_53891 == 0)
    {
        goto LE; // [420] 451
    }
    else{
    }

    /** inline.e:674				SymTab[CurrentSub][S_STACK_SPACE] += 1*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_36CurrentSub_21775 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!IS_ATOM_INT(_36S_STACK_SPACE_21464)){
        _27802 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_STACK_SPACE_21464)->dbl));
    }
    else{
        _27802 = (object)*(((s1_ptr)_2)->base + _36S_STACK_SPACE_21464);
    }
    _27800 = NOVALUE;
    if (IS_ATOM_INT(_27802)) {
        _27803 = _27802 + 1;
        if (_27803 > MAXINT){
            _27803 = NewDouble((eudouble)_27803);
        }
    }
    else
    _27803 = binary_op(PLUS, 1, _27802);
    _27802 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_STACK_SPACE_21464))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_STACK_SPACE_21464)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_STACK_SPACE_21464);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27803;
    if( _1 != _27803 ){
        DeRef(_1);
    }
    _27803 = NOVALUE;
    _27800 = NOVALUE;
    goto LF; // [448] 471
LE: 

    /** inline.e:676				if param_num != -1 then*/
    if (_45param_num_55365 == -1)
    goto L10; // [455] 470

    /** inline.e:677					param_num += 1*/
    _45param_num_55365 = _45param_num_55365 + 1;
L10: 
LF: 

    /** inline.e:680			SymTab[var][S_USAGE] = U_USED*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_var_54696 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 3;
    DeRef(_1);
    _27806 = NOVALUE;

    /** inline.e:681			if reuse then*/
    if (_reuse_54694 == 0)
    {
        goto L11; // [490] 511
    }
    else{
    }

    /** inline.e:682				map:nested_put( inline_var_map, {CurrentSub, ps }, var )*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _36CurrentSub_21775;
    ((intptr_t *)_2)[2] = _ps_54693;
    _27808 = MAKE_SEQ(_1);
    Ref(_67inline_var_map_53900);
    _29nested_put(_67inline_var_map_53900, _27808, _var_54696, 1, 0);
    _27808 = NOVALUE;
L11: 

    /** inline.e:686		Block_var( var )*/
    _65Block_var(_var_54696);

    /** inline.e:687		if BIND then*/
    if (_36BIND_21372 == 0)
    {
        goto L12; // [521] 536
    }
    else{
    }

    /** inline.e:688			add_ref( {VARIABLE, var} )*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -100;
    ((intptr_t *)_2)[2] = _var_54696;
    _27809 = MAKE_SEQ(_1);
    _54add_ref(_27809);
    _27809 = NOVALUE;
L12: 

    /** inline.e:690		return var*/
    DeRefi(_name_54698);
    return _var_54696;
    ;
}


object _67get_inlined_code(object _sub_54830, object _start_54831, object _deferred_54832)
{
    object _is_proc_54833 = NOVALUE;
    object _backpatches_54851 = NOVALUE;
    object _prolog_54857 = NOVALUE;
    object _epilog_54858 = NOVALUE;
    object _s_54874 = NOVALUE;
    object _last_sym_54897 = NOVALUE;
    object _int_sym_54924 = NOVALUE;
    object _param_54932 = NOVALUE;
    object _ax_54935 = NOVALUE;
    object _var_54942 = NOVALUE;
    object _final_target_54957 = NOVALUE;
    object _var_54976 = NOVALUE;
    object _create_target_var_54989 = NOVALUE;
    object _check_pc_55012 = NOVALUE;
    object _op_55016 = NOVALUE;
    object _sym_55025 = NOVALUE;
    object _check_result_55030 = NOVALUE;
    object _inline_type_55108 = NOVALUE;
    object _replace_param_1__tmp_at1343_55119 = NOVALUE;
    object _27963 = NOVALUE;
    object _27962 = NOVALUE;
    object _27961 = NOVALUE;
    object _27960 = NOVALUE;
    object _27959 = NOVALUE;
    object _27958 = NOVALUE;
    object _27957 = NOVALUE;
    object _27956 = NOVALUE;
    object _27954 = NOVALUE;
    object _27951 = NOVALUE;
    object _27948 = NOVALUE;
    object _27947 = NOVALUE;
    object _27946 = NOVALUE;
    object _27945 = NOVALUE;
    object _27944 = NOVALUE;
    object _27943 = NOVALUE;
    object _27942 = NOVALUE;
    object _27941 = NOVALUE;
    object _27937 = NOVALUE;
    object _27936 = NOVALUE;
    object _27935 = NOVALUE;
    object _27934 = NOVALUE;
    object _27930 = NOVALUE;
    object _27929 = NOVALUE;
    object _27928 = NOVALUE;
    object _27927 = NOVALUE;
    object _27926 = NOVALUE;
    object _27925 = NOVALUE;
    object _27924 = NOVALUE;
    object _27922 = NOVALUE;
    object _27921 = NOVALUE;
    object _27920 = NOVALUE;
    object _27919 = NOVALUE;
    object _27918 = NOVALUE;
    object _27917 = NOVALUE;
    object _27916 = NOVALUE;
    object _27915 = NOVALUE;
    object _27914 = NOVALUE;
    object _27913 = NOVALUE;
    object _27912 = NOVALUE;
    object _27910 = NOVALUE;
    object _27909 = NOVALUE;
    object _27907 = NOVALUE;
    object _27906 = NOVALUE;
    object _27904 = NOVALUE;
    object _27903 = NOVALUE;
    object _27900 = NOVALUE;
    object _27899 = NOVALUE;
    object _27897 = NOVALUE;
    object _27895 = NOVALUE;
    object _27890 = NOVALUE;
    object _27886 = NOVALUE;
    object _27883 = NOVALUE;
    object _27879 = NOVALUE;
    object _27872 = NOVALUE;
    object _27871 = NOVALUE;
    object _27870 = NOVALUE;
    object _27869 = NOVALUE;
    object _27868 = NOVALUE;
    object _27867 = NOVALUE;
    object _27866 = NOVALUE;
    object _27864 = NOVALUE;
    object _27859 = NOVALUE;
    object _27856 = NOVALUE;
    object _27851 = NOVALUE;
    object _27850 = NOVALUE;
    object _27848 = NOVALUE;
    object _27847 = NOVALUE;
    object _27846 = NOVALUE;
    object _27843 = NOVALUE;
    object _27842 = NOVALUE;
    object _27841 = NOVALUE;
    object _27840 = NOVALUE;
    object _27839 = NOVALUE;
    object _27838 = NOVALUE;
    object _27837 = NOVALUE;
    object _27835 = NOVALUE;
    object _27834 = NOVALUE;
    object _27833 = NOVALUE;
    object _27831 = NOVALUE;
    object _27829 = NOVALUE;
    object _27828 = NOVALUE;
    object _27827 = NOVALUE;
    object _27826 = NOVALUE;
    object _27825 = NOVALUE;
    object _27824 = NOVALUE;
    object _27823 = NOVALUE;
    object _27820 = NOVALUE;
    object _27819 = NOVALUE;
    object _27817 = NOVALUE;
    object _27816 = NOVALUE;
    object _27814 = NOVALUE;
    object _27813 = NOVALUE;
    object _27811 = NOVALUE;
    object _27810 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_start_54831)) {
        _1 = (object)(DBL_PTR(_start_54831)->dbl);
        DeRefDS(_start_54831);
        _start_54831 = _1;
    }

    /** inline.e:694		integer is_proc = SymTab[sub][S_TOKEN] = PROC*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _27810 = (object)*(((s1_ptr)_2)->base + _sub_54830);
    _2 = (object)SEQ_PTR(_27810);
    if (!IS_ATOM_INT(_36S_TOKEN_21409)){
        _27811 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21409)->dbl));
    }
    else{
        _27811 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21409);
    }
    _27810 = NOVALUE;
    if (IS_ATOM_INT(_27811)) {
        _is_proc_54833 = (_27811 == 27);
    }
    else {
        _is_proc_54833 = binary_op(EQUALS, _27811, 27);
    }
    _27811 = NOVALUE;
    if (!IS_ATOM_INT(_is_proc_54833)) {
        _1 = (object)(DBL_PTR(_is_proc_54833)->dbl);
        DeRefDS(_is_proc_54833);
        _is_proc_54833 = _1;
    }

    /** inline.e:695		clear_inline_targets()*/
    _47clear_inline_targets();

    /** inline.e:697		inline_temps = {}*/
    RefDS(_22190);
    DeRef(_67inline_temps_53883);
    _67inline_temps_53883 = _22190;

    /** inline.e:698		inline_params = {}*/
    RefDS(_22190);
    DeRefi(_67inline_params_53886);
    _67inline_params_53886 = _22190;

    /** inline.e:699		assigned_params      = SymTab[sub][S_INLINE][1]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _27813 = (object)*(((s1_ptr)_2)->base + _sub_54830);
    _2 = (object)SEQ_PTR(_27813);
    _27814 = (object)*(((s1_ptr)_2)->base + 29);
    _27813 = NOVALUE;
    DeRef(_67assigned_params_53887);
    _2 = (object)SEQ_PTR(_27814);
    _67assigned_params_53887 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_67assigned_params_53887);
    _27814 = NOVALUE;

    /** inline.e:700		inline_code          = SymTab[sub][S_INLINE][2]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _27816 = (object)*(((s1_ptr)_2)->base + _sub_54830);
    _2 = (object)SEQ_PTR(_27816);
    _27817 = (object)*(((s1_ptr)_2)->base + 29);
    _27816 = NOVALUE;
    DeRef(_67inline_code_53881);
    _2 = (object)SEQ_PTR(_27817);
    _67inline_code_53881 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_67inline_code_53881);
    _27817 = NOVALUE;

    /** inline.e:701		sequence backpatches = SymTab[sub][S_INLINE][3]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _27819 = (object)*(((s1_ptr)_2)->base + _sub_54830);
    _2 = (object)SEQ_PTR(_27819);
    _27820 = (object)*(((s1_ptr)_2)->base + 29);
    _27819 = NOVALUE;
    DeRef(_backpatches_54851);
    _2 = (object)SEQ_PTR(_27820);
    _backpatches_54851 = (object)*(((s1_ptr)_2)->base + 3);
    Ref(_backpatches_54851);
    _27820 = NOVALUE;

    /** inline.e:703		passed_params = {}*/
    RefDS(_22190);
    DeRef(_67passed_params_53884);
    _67passed_params_53884 = _22190;

    /** inline.e:704		original_params = {}*/
    RefDS(_22190);
    DeRef(_67original_params_53885);
    _67original_params_53885 = _22190;

    /** inline.e:705		proc_vars = {}*/
    RefDS(_22190);
    DeRefi(_67proc_vars_53882);
    _67proc_vars_53882 = _22190;

    /** inline.e:706		sequence prolog = {}*/
    RefDS(_22190);
    DeRefi(_prolog_54857);
    _prolog_54857 = _22190;

    /** inline.e:707		sequence epilog = {}*/
    RefDS(_22190);
    DeRef(_epilog_54858);
    _epilog_54858 = _22190;

    /** inline.e:709		Start_block( EXIT_BLOCK, sprintf("Inline-%s from %s @ %d", */
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _27823 = (object)*(((s1_ptr)_2)->base + _sub_54830);
    _2 = (object)SEQ_PTR(_27823);
    if (!IS_ATOM_INT(_36S_NAME_21404)){
        _27824 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21404)->dbl));
    }
    else{
        _27824 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21404);
    }
    _27823 = NOVALUE;
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _27825 = (object)*(((s1_ptr)_2)->base + _36CurrentSub_21775);
    _2 = (object)SEQ_PTR(_27825);
    if (!IS_ATOM_INT(_36S_NAME_21404)){
        _27826 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21404)->dbl));
    }
    else{
        _27826 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21404);
    }
    _27825 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_27824);
    ((intptr_t*)_2)[1] = _27824;
    Ref(_27826);
    ((intptr_t*)_2)[2] = _27826;
    ((intptr_t*)_2)[3] = _start_54831;
    _27827 = MAKE_SEQ(_1);
    _27826 = NOVALUE;
    _27824 = NOVALUE;
    _27828 = EPrintf(-9999999, _27822, _27827);
    DeRefDS(_27827);
    _27827 = NOVALUE;
    _65Start_block(206, _27828);
    _27828 = NOVALUE;

    /** inline.e:712		symtab_index s = SymTab[sub][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _27829 = (object)*(((s1_ptr)_2)->base + _sub_54830);
    _2 = (object)SEQ_PTR(_27829);
    _s_54874 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_54874)){
        _s_54874 = (object)DBL_PTR(_s_54874)->dbl;
    }
    _27829 = NOVALUE;

    /** inline.e:714		varnum = SymTab[CurrentSub][S_NUM_ARGS]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _27831 = (object)*(((s1_ptr)_2)->base + _36CurrentSub_21775);
    _2 = (object)SEQ_PTR(_27831);
    if (!IS_ATOM_INT(_36S_NUM_ARGS_21455)){
        _67varnum_53892 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21455)->dbl));
    }
    else{
        _67varnum_53892 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21455);
    }
    if (!IS_ATOM_INT(_67varnum_53892)){
        _67varnum_53892 = (object)DBL_PTR(_67varnum_53892)->dbl;
    }
    _27831 = NOVALUE;

    /** inline.e:715		inline_start = start*/
    _67inline_start_53893 = _start_54831;

    /** inline.e:717		last_param = CurrentSub*/
    _67last_param_53896 = _36CurrentSub_21775;

    /** inline.e:718		for p = 1 to SymTab[CurrentSub][S_NUM_ARGS] do*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _27833 = (object)*(((s1_ptr)_2)->base + _36CurrentSub_21775);
    _2 = (object)SEQ_PTR(_27833);
    if (!IS_ATOM_INT(_36S_NUM_ARGS_21455)){
        _27834 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21455)->dbl));
    }
    else{
        _27834 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21455);
    }
    _27833 = NOVALUE;
    {
        object _p_54886;
        _p_54886 = 1;
L1: 
        if (binary_op_a(GREATER, _p_54886, _27834)){
            goto L2; // [250] 282
        }

        /** inline.e:719			last_param = SymTab[last_param][S_NEXT]*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _27835 = (object)*(((s1_ptr)_2)->base + _67last_param_53896);
        _2 = (object)SEQ_PTR(_27835);
        _67last_param_53896 = (object)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_67last_param_53896)){
            _67last_param_53896 = (object)DBL_PTR(_67last_param_53896)->dbl;
        }
        _27835 = NOVALUE;

        /** inline.e:720		end for*/
        _0 = _p_54886;
        if (IS_ATOM_INT(_p_54886)) {
            _p_54886 = _p_54886 + 1;
            if ((object)((uintptr_t)_p_54886 +(uintptr_t) HIGH_BITS) >= 0){
                _p_54886 = NewDouble((eudouble)_p_54886);
            }
        }
        else {
            _p_54886 = binary_op_a(PLUS, _p_54886, 1);
        }
        DeRef(_0);
        goto L1; // [277] 257
L2: 
        ;
        DeRef(_p_54886);
    }

    /** inline.e:722		symtab_index last_sym = last_param*/
    _last_sym_54897 = _67last_param_53896;

    /** inline.e:723		while last_sym and */
L3: 
    if (_last_sym_54897 == 0) {
        goto L4; // [296] 368
    }
    _27838 = _54sym_scope(_last_sym_54897);
    if (IS_ATOM_INT(_27838)) {
        _27839 = (_27838 <= 3);
    }
    else {
        _27839 = binary_op(LESSEQ, _27838, 3);
    }
    DeRef(_27838);
    _27838 = NOVALUE;
    if (IS_ATOM_INT(_27839)) {
        if (_27839 != 0) {
            DeRef(_27840);
            _27840 = 1;
            goto L5; // [310] 328
        }
    }
    else {
        if (DBL_PTR(_27839)->dbl != 0.0) {
            DeRef(_27840);
            _27840 = 1;
            goto L5; // [310] 328
        }
    }
    _27841 = _54sym_scope(_last_sym_54897);
    if (IS_ATOM_INT(_27841)) {
        _27842 = (_27841 == 9);
    }
    else {
        _27842 = binary_op(EQUALS, _27841, 9);
    }
    DeRef(_27841);
    _27841 = NOVALUE;
    DeRef(_27840);
    if (IS_ATOM_INT(_27842))
    _27840 = (_27842 != 0);
    else
    _27840 = DBL_PTR(_27842)->dbl != 0.0;
L5: 
    if (_27840 == 0)
    {
        _27840 = NOVALUE;
        goto L4; // [329] 368
    }
    else{
        _27840 = NOVALUE;
    }

    /** inline.e:725			last_param = last_sym*/
    _67last_param_53896 = _last_sym_54897;

    /** inline.e:726			last_sym = SymTab[last_sym][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _27843 = (object)*(((s1_ptr)_2)->base + _last_sym_54897);
    _2 = (object)SEQ_PTR(_27843);
    _last_sym_54897 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_last_sym_54897)){
        _last_sym_54897 = (object)DBL_PTR(_last_sym_54897)->dbl;
    }
    _27843 = NOVALUE;

    /** inline.e:727			varnum += 1*/
    _67varnum_53892 = _67varnum_53892 + 1;

    /** inline.e:728		end while*/
    goto L3; // [365] 296
L4: 

    /** inline.e:729		for p = SymTab[sub][S_NUM_ARGS] to 1 by -1 do*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _27846 = (object)*(((s1_ptr)_2)->base + _sub_54830);
    _2 = (object)SEQ_PTR(_27846);
    if (!IS_ATOM_INT(_36S_NUM_ARGS_21455)){
        _27847 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21455)->dbl));
    }
    else{
        _27847 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21455);
    }
    _27846 = NOVALUE;
    {
        object _p_54915;
        Ref(_27847);
        _p_54915 = _27847;
L6: 
        if (binary_op_a(LESS, _p_54915, 1)){
            goto L7; // [382] 407
        }

        /** inline.e:730			passed_params = prepend( passed_params, Pop() )*/
        _27848 = _47Pop();
        Ref(_27848);
        Prepend(&_67passed_params_53884, _67passed_params_53884, _27848);
        DeRef(_27848);
        _27848 = NOVALUE;

        /** inline.e:731		end for*/
        _0 = _p_54915;
        if (IS_ATOM_INT(_p_54915)) {
            _p_54915 = _p_54915 + -1;
            if ((object)((uintptr_t)_p_54915 +(uintptr_t) HIGH_BITS) >= 0){
                _p_54915 = NewDouble((eudouble)_p_54915);
            }
        }
        else {
            _p_54915 = binary_op_a(PLUS, _p_54915, -1);
        }
        DeRef(_0);
        goto L6; // [402] 389
L7: 
        ;
        DeRef(_p_54915);
    }

    /** inline.e:733		original_params = passed_params*/
    RefDS(_67passed_params_53884);
    DeRef(_67original_params_53885);
    _67original_params_53885 = _67passed_params_53884;

    /** inline.e:735		symtab_index int_sym = 0*/
    _int_sym_54924 = 0;

    /** inline.e:736		for p = 1 to SymTab[sub][S_NUM_ARGS] do*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _27850 = (object)*(((s1_ptr)_2)->base + _sub_54830);
    _2 = (object)SEQ_PTR(_27850);
    if (!IS_ATOM_INT(_36S_NUM_ARGS_21455)){
        _27851 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21455)->dbl));
    }
    else{
        _27851 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21455);
    }
    _27850 = NOVALUE;
    {
        object _p_54926;
        _p_54926 = 1;
L8: 
        if (binary_op_a(GREATER, _p_54926, _27851)){
            goto L9; // [437] 575
        }

        /** inline.e:737			symtab_index param = passed_params[p]*/
        _2 = (object)SEQ_PTR(_67passed_params_53884);
        if (!IS_ATOM_INT(_p_54926)){
            _param_54932 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_p_54926)->dbl));
        }
        else{
            _param_54932 = (object)*(((s1_ptr)_2)->base + _p_54926);
        }
        if (!IS_ATOM_INT(_param_54932)){
            _param_54932 = (object)DBL_PTR(_param_54932)->dbl;
        }

        /** inline.e:738			inline_params &= s*/
        Append(&_67inline_params_53886, _67inline_params_53886, _s_54874);

        /** inline.e:739			integer ax = find( p, assigned_params )*/
        _ax_54935 = find_from(_p_54926, _67assigned_params_53887, 1);

        /** inline.e:740			if ax or is_temp( param ) then*/
        if (_ax_54935 != 0) {
            goto LA; // [473] 486
        }
        _27856 = _67is_temp(_param_54932);
        if (_27856 == 0) {
            DeRef(_27856);
            _27856 = NOVALUE;
            goto LB; // [482] 548
        }
        else {
            if (!IS_ATOM_INT(_27856) && DBL_PTR(_27856)->dbl == 0.0){
                DeRef(_27856);
                _27856 = NOVALUE;
                goto LB; // [482] 548
            }
            DeRef(_27856);
            _27856 = NOVALUE;
        }
        DeRef(_27856);
        _27856 = NOVALUE;
LA: 

        /** inline.e:743				varnum += 1*/
        _67varnum_53892 = _67varnum_53892 + 1;

        /** inline.e:744				symtab_index var = new_inline_var( s, 0 )*/
        _var_54942 = _67new_inline_var(_s_54874, 0);
        if (!IS_ATOM_INT(_var_54942)) {
            _1 = (object)(DBL_PTR(_var_54942)->dbl);
            DeRefDS(_var_54942);
            _var_54942 = _1;
        }

        /** inline.e:745				prolog &= {ASSIGN, param, var}*/
        _1 = NewS1(3);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = 18;
        ((intptr_t*)_2)[2] = _param_54932;
        ((intptr_t*)_2)[3] = _var_54942;
        _27859 = MAKE_SEQ(_1);
        Concat((object_ptr)&_prolog_54857, _prolog_54857, _27859);
        DeRefDS(_27859);
        _27859 = NOVALUE;

        /** inline.e:746				if not int_sym then*/
        if (_int_sym_54924 != 0)
        goto LC; // [519] 531

        /** inline.e:747					int_sym = NewIntSym( 0 )*/
        _int_sym_54924 = _54NewIntSym(0);
        if (!IS_ATOM_INT(_int_sym_54924)) {
            _1 = (object)(DBL_PTR(_int_sym_54924)->dbl);
            DeRefDS(_int_sym_54924);
            _int_sym_54924 = _1;
        }
LC: 

        /** inline.e:750				inline_start += 3*/
        _67inline_start_53893 = _67inline_start_53893 + 3;

        /** inline.e:751				passed_params[p] = var*/
        _2 = (object)SEQ_PTR(_67passed_params_53884);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _67passed_params_53884 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_p_54926))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_p_54926)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _p_54926);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _var_54942;
        DeRef(_1);
LB: 

        /** inline.e:753			s = SymTab[s][S_NEXT]*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _27864 = (object)*(((s1_ptr)_2)->base + _s_54874);
        _2 = (object)SEQ_PTR(_27864);
        _s_54874 = (object)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_s_54874)){
            _s_54874 = (object)DBL_PTR(_s_54874)->dbl;
        }
        _27864 = NOVALUE;

        /** inline.e:755		end for*/
        _0 = _p_54926;
        if (IS_ATOM_INT(_p_54926)) {
            _p_54926 = _p_54926 + 1;
            if ((object)((uintptr_t)_p_54926 +(uintptr_t) HIGH_BITS) >= 0){
                _p_54926 = NewDouble((eudouble)_p_54926);
            }
        }
        else {
            _p_54926 = binary_op_a(PLUS, _p_54926, 1);
        }
        DeRef(_0);
        goto L8; // [570] 444
L9: 
        ;
        DeRef(_p_54926);
    }

    /** inline.e:757		symtab_index final_target = 0*/
    _final_target_54957 = 0;

    /** inline.e:758		while s and */
LD: 
    if (_s_54874 == 0) {
        goto LE; // [587] 699
    }
    _27867 = _54sym_scope(_s_54874);
    if (IS_ATOM_INT(_27867)) {
        _27868 = (_27867 <= 3);
    }
    else {
        _27868 = binary_op(LESSEQ, _27867, 3);
    }
    DeRef(_27867);
    _27867 = NOVALUE;
    if (IS_ATOM_INT(_27868)) {
        if (_27868 != 0) {
            DeRef(_27869);
            _27869 = 1;
            goto LF; // [601] 619
        }
    }
    else {
        if (DBL_PTR(_27868)->dbl != 0.0) {
            DeRef(_27869);
            _27869 = 1;
            goto LF; // [601] 619
        }
    }
    _27870 = _54sym_scope(_s_54874);
    if (IS_ATOM_INT(_27870)) {
        _27871 = (_27870 == 9);
    }
    else {
        _27871 = binary_op(EQUALS, _27870, 9);
    }
    DeRef(_27870);
    _27870 = NOVALUE;
    DeRef(_27869);
    if (IS_ATOM_INT(_27871))
    _27869 = (_27871 != 0);
    else
    _27869 = DBL_PTR(_27871)->dbl != 0.0;
LF: 
    if (_27869 == 0)
    {
        _27869 = NOVALUE;
        goto LE; // [620] 699
    }
    else{
        _27869 = NOVALUE;
    }

    /** inline.e:760			if sym_scope( s ) != SC_UNDEFINED then*/
    _27872 = _54sym_scope(_s_54874);
    if (binary_op_a(EQUALS, _27872, 9)){
        DeRef(_27872);
        _27872 = NOVALUE;
        goto L10; // [631] 676
    }
    DeRef(_27872);
    _27872 = NOVALUE;

    /** inline.e:763				varnum += 1*/
    _67varnum_53892 = _67varnum_53892 + 1;

    /** inline.e:764				symtab_index var = new_inline_var( s, 0 )*/
    _var_54976 = _67new_inline_var(_s_54874, 0);
    if (!IS_ATOM_INT(_var_54976)) {
        _1 = (object)(DBL_PTR(_var_54976)->dbl);
        DeRefDS(_var_54976);
        _var_54976 = _1;
    }

    /** inline.e:765				proc_vars &= var*/
    Append(&_67proc_vars_53882, _67proc_vars_53882, _var_54976);

    /** inline.e:766				if int_sym = 0 then*/
    if (_int_sym_54924 != 0)
    goto L11; // [662] 675

    /** inline.e:767					int_sym = NewIntSym( 0 )*/
    _int_sym_54924 = _54NewIntSym(0);
    if (!IS_ATOM_INT(_int_sym_54924)) {
        _1 = (object)(DBL_PTR(_int_sym_54924)->dbl);
        DeRefDS(_int_sym_54924);
        _int_sym_54924 = _1;
    }
L11: 
L10: 

    /** inline.e:770			s = SymTab[s][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _27879 = (object)*(((s1_ptr)_2)->base + _s_54874);
    _2 = (object)SEQ_PTR(_27879);
    _s_54874 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_54874)){
        _s_54874 = (object)DBL_PTR(_s_54874)->dbl;
    }
    _27879 = NOVALUE;

    /** inline.e:771		end while*/
    goto LD; // [696] 587
LE: 

    /** inline.e:773		if not is_proc then*/
    if (_is_proc_54833 != 0)
    goto L12; // [701] 831

    /** inline.e:774			integer create_target_var = 1*/
    _create_target_var_54989 = 1;

    /** inline.e:775			if deferred then*/
    if (_deferred_54832 == 0)
    {
        goto L13; // [711] 751
    }
    else{
    }

    /** inline.e:776				inline_target = Pop()*/
    _0 = _47Pop();
    _67inline_target_53888 = _0;
    if (!IS_ATOM_INT(_67inline_target_53888)) {
        _1 = (object)(DBL_PTR(_67inline_target_53888)->dbl);
        DeRefDS(_67inline_target_53888);
        _67inline_target_53888 = _1;
    }

    /** inline.e:777				if is_temp( inline_target ) then*/
    _27883 = _67is_temp(_67inline_target_53888);
    if (_27883 == 0) {
        DeRef(_27883);
        _27883 = NOVALUE;
        goto L14; // [729] 744
    }
    else {
        if (!IS_ATOM_INT(_27883) && DBL_PTR(_27883)->dbl == 0.0){
            DeRef(_27883);
            _27883 = NOVALUE;
            goto L14; // [729] 744
        }
        DeRef(_27883);
        _27883 = NOVALUE;
    }
    DeRef(_27883);
    _27883 = NOVALUE;

    /** inline.e:778					final_target = inline_target*/
    _final_target_54957 = _67inline_target_53888;
    goto L15; // [741] 750
L14: 

    /** inline.e:780					create_target_var = 0*/
    _create_target_var_54989 = 0;
L15: 
L13: 

    /** inline.e:784			if create_target_var then*/
    if (_create_target_var_54989 == 0)
    {
        goto L16; // [753] 816
    }
    else{
    }

    /** inline.e:785				varnum += 1*/
    _67varnum_53892 = _67varnum_53892 + 1;

    /** inline.e:786				if TRANSLATE then*/
    if (_36TRANSLATE_21369 == 0)
    {
        goto L17; // [768] 806
    }
    else{
    }

    /** inline.e:787					inline_target = new_inline_var( sub, 0 )*/
    _0 = _67new_inline_var(_sub_54830, 0);
    _67inline_target_53888 = _0;
    if (!IS_ATOM_INT(_67inline_target_53888)) {
        _1 = (object)(DBL_PTR(_67inline_target_53888)->dbl);
        DeRefDS(_67inline_target_53888);
        _67inline_target_53888 = _1;
    }

    /** inline.e:788					SymTab[inline_target][S_VTYPE] = object_type*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_67inline_target_53888 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 15);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _54object_type_47136;
    DeRef(_1);
    _27886 = NOVALUE;

    /** inline.e:789					Pop_block_var()*/
    _65Pop_block_var();
    goto L18; // [803] 815
L17: 

    /** inline.e:791					inline_target = NewTempSym()*/
    _0 = _54NewTempSym(0);
    _67inline_target_53888 = _0;
    if (!IS_ATOM_INT(_67inline_target_53888)) {
        _1 = (object)(DBL_PTR(_67inline_target_53888)->dbl);
        DeRefDS(_67inline_target_53888);
        _67inline_target_53888 = _1;
    }
L18: 
L16: 

    /** inline.e:794			proc_vars &= inline_target*/
    Append(&_67proc_vars_53882, _67proc_vars_53882, _67inline_target_53888);
    goto L19; // [828] 837
L12: 

    /** inline.e:796			inline_target = 0*/
    _67inline_target_53888 = 0;
L19: 

    /** inline.e:800		integer check_pc = 1*/
    _check_pc_55012 = 1;

    /** inline.e:802		while length(inline_code) > check_pc do*/
L1A: 
    if (IS_SEQUENCE(_67inline_code_53881)){
            _27890 = SEQ_PTR(_67inline_code_53881)->length;
    }
    else {
        _27890 = 1;
    }
    if (_27890 <= _check_pc_55012)
    goto L1B; // [852] 1218

    /** inline.e:803			integer op = inline_code[check_pc]*/
    _2 = (object)SEQ_PTR(_67inline_code_53881);
    _op_55016 = (object)*(((s1_ptr)_2)->base + _check_pc_55012);
    if (!IS_ATOM_INT(_op_55016))
    _op_55016 = (object)DBL_PTR(_op_55016)->dbl;

    /** inline.e:805			switch op with fallthru do*/
    _0 = _op_55016;
    switch ( _0 ){ 

        /** inline.e:806				case ATOM_CHECK then*/
        case 101:
        case 97:
        case 96:

        /** inline.e:809					symtab_index sym = get_original_sym( check_pc + 1 )*/
        _27895 = _check_pc_55012 + 1;
        if (_27895 > MAXINT){
            _27895 = NewDouble((eudouble)_27895);
        }
        _sym_55025 = _67get_original_sym(_27895);
        _27895 = NOVALUE;
        if (!IS_ATOM_INT(_sym_55025)) {
            _1 = (object)(DBL_PTR(_sym_55025)->dbl);
            DeRefDS(_sym_55025);
            _sym_55025 = _1;
        }

        /** inline.e:810					if is_literal( sym ) then*/
        _27897 = _67is_literal(_sym_55025);
        if (_27897 == 0) {
            DeRef(_27897);
            _27897 = NOVALUE;
            goto L1C; // [897] 1012
        }
        else {
            if (!IS_ATOM_INT(_27897) && DBL_PTR(_27897)->dbl == 0.0){
                DeRef(_27897);
                _27897 = NOVALUE;
                goto L1C; // [897] 1012
            }
            DeRef(_27897);
            _27897 = NOVALUE;
        }
        DeRef(_27897);
        _27897 = NOVALUE;

        /** inline.e:811						integer check_result*/

        /** inline.e:813						if op = INTEGER_CHECK then*/
        if (_op_55016 != 96)
        goto L1D; // [906] 930

        /** inline.e:814							check_result = integer( SymTab[sym][S_OBJ] )*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _27899 = (object)*(((s1_ptr)_2)->base + _sym_55025);
        _2 = (object)SEQ_PTR(_27899);
        _27900 = (object)*(((s1_ptr)_2)->base + 1);
        _27899 = NOVALUE;
        if (IS_ATOM_INT(_27900))
        _check_result_55030 = 1;
        else if (IS_ATOM_DBL(_27900))
        _check_result_55030 = IS_ATOM_INT(DoubleToInt(_27900));
        else
        _check_result_55030 = 0;
        _27900 = NOVALUE;
        goto L1E; // [927] 976
L1D: 

        /** inline.e:815						elsif op = SEQUENCE_CHECK then*/
        if (_op_55016 != 97)
        goto L1F; // [934] 958

        /** inline.e:816							check_result = sequence( SymTab[sym][S_OBJ] )*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _27903 = (object)*(((s1_ptr)_2)->base + _sym_55025);
        _2 = (object)SEQ_PTR(_27903);
        _27904 = (object)*(((s1_ptr)_2)->base + 1);
        _27903 = NOVALUE;
        _check_result_55030 = IS_SEQUENCE(_27904);
        _27904 = NOVALUE;
        goto L1E; // [955] 976
L1F: 

        /** inline.e:818							check_result = atom( SymTab[sym][S_OBJ] )*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _27906 = (object)*(((s1_ptr)_2)->base + _sym_55025);
        _2 = (object)SEQ_PTR(_27906);
        _27907 = (object)*(((s1_ptr)_2)->base + 1);
        _27906 = NOVALUE;
        _check_result_55030 = IS_ATOM(_27907);
        _27907 = NOVALUE;
L1E: 

        /** inline.e:821						if check_result then*/
        if (_check_result_55030 == 0)
        {
            goto L20; // [980] 997
        }
        else{
        }

        /** inline.e:822							replace_code( {}, check_pc, check_pc+1 )*/
        _27909 = _check_pc_55012 + 1;
        if (_27909 > MAXINT){
            _27909 = NewDouble((eudouble)_27909);
        }
        RefDS(_22190);
        _67replace_code(_22190, _check_pc_55012, _27909);
        _27909 = NOVALUE;
        goto L21; // [994] 1007
L20: 

        /** inline.e:826							CompileErr(TYPE_CHECK_ERROR_WHEN_INLINING_LITERAL)*/
        RefDS(_22190);
        _50CompileErr(146, _22190, 0);
L21: 
        goto L22; // [1009] 1174
L1C: 

        /** inline.e:829					elsif not is_temp( sym ) then*/
        _27910 = _67is_temp(_sym_55025);
        if (IS_ATOM_INT(_27910)) {
            if (_27910 != 0){
                DeRef(_27910);
                _27910 = NOVALUE;
                goto L23; // [1018] 1167
            }
        }
        else {
            if (DBL_PTR(_27910)->dbl != 0.0){
                DeRef(_27910);
                _27910 = NOVALUE;
                goto L23; // [1018] 1167
            }
        }
        DeRef(_27910);
        _27910 = NOVALUE;

        /** inline.e:831						if (op = INTEGER_CHECK and SymTab[sym][S_VTYPE] = integer_type )*/
        _27912 = (_op_55016 == 96);
        if (_27912 == 0) {
            _27913 = 0;
            goto L24; // [1029] 1055
        }
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _27914 = (object)*(((s1_ptr)_2)->base + _sym_55025);
        _2 = (object)SEQ_PTR(_27914);
        _27915 = (object)*(((s1_ptr)_2)->base + 15);
        _27914 = NOVALUE;
        if (IS_ATOM_INT(_27915)) {
            _27916 = (_27915 == _54integer_type_47142);
        }
        else {
            _27916 = binary_op(EQUALS, _27915, _54integer_type_47142);
        }
        _27915 = NOVALUE;
        if (IS_ATOM_INT(_27916))
        _27913 = (_27916 != 0);
        else
        _27913 = DBL_PTR(_27916)->dbl != 0.0;
L24: 
        if (_27913 != 0) {
            _27917 = 1;
            goto L25; // [1055] 1095
        }
        _27918 = (_op_55016 == 97);
        if (_27918 == 0) {
            _27919 = 0;
            goto L26; // [1065] 1091
        }
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _27920 = (object)*(((s1_ptr)_2)->base + _sym_55025);
        _2 = (object)SEQ_PTR(_27920);
        _27921 = (object)*(((s1_ptr)_2)->base + 15);
        _27920 = NOVALUE;
        if (IS_ATOM_INT(_27921)) {
            _27922 = (_27921 == _54sequence_type_47140);
        }
        else {
            _27922 = binary_op(EQUALS, _27921, _54sequence_type_47140);
        }
        _27921 = NOVALUE;
        if (IS_ATOM_INT(_27922))
        _27919 = (_27922 != 0);
        else
        _27919 = DBL_PTR(_27922)->dbl != 0.0;
L26: 
        _27917 = (_27919 != 0);
L25: 
        if (_27917 != 0) {
            goto L27; // [1095] 1143
        }
        _27924 = (_op_55016 == 101);
        if (_27924 == 0) {
            DeRef(_27925);
            _27925 = 0;
            goto L28; // [1105] 1138
        }
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _27926 = (object)*(((s1_ptr)_2)->base + _sym_55025);
        _2 = (object)SEQ_PTR(_27926);
        _27927 = (object)*(((s1_ptr)_2)->base + 15);
        _27926 = NOVALUE;
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _54integer_type_47142;
        ((intptr_t *)_2)[2] = _54atom_type_47138;
        _27928 = MAKE_SEQ(_1);
        _27929 = find_from(_27927, _27928, 1);
        _27927 = NOVALUE;
        DeRefDS(_27928);
        _27928 = NOVALUE;
        _27925 = (_27929 != 0);
L28: 
        if (_27925 == 0)
        {
            _27925 = NOVALUE;
            goto L29; // [1139] 1157
        }
        else{
            _27925 = NOVALUE;
        }
L27: 

        /** inline.e:834							replace_code( {}, check_pc, check_pc+1 )*/
        _27930 = _check_pc_55012 + 1;
        if (_27930 > MAXINT){
            _27930 = NewDouble((eudouble)_27930);
        }
        RefDS(_22190);
        _67replace_code(_22190, _check_pc_55012, _27930);
        _27930 = NOVALUE;
        goto L22; // [1154] 1174
L29: 

        /** inline.e:837							check_pc += 2*/
        _check_pc_55012 = _check_pc_55012 + 2;
        goto L22; // [1164] 1174
L23: 

        /** inline.e:841						check_pc += 2*/
        _check_pc_55012 = _check_pc_55012 + 2;
L22: 

        /** inline.e:843					continue*/
        goto L1A; // [1180] 847

        /** inline.e:844				case STARTLINE then*/
        case 58:

        /** inline.e:845					check_pc += 2*/
        _check_pc_55012 = _check_pc_55012 + 2;

        /** inline.e:846					continue*/
        goto L1A; // [1198] 847

        /** inline.e:848				case else*/
        default:

        /** inline.e:849					exit*/
        goto L1B; // [1208] 1218
    ;}
    /** inline.e:851		end while*/
    goto L1A; // [1215] 847
L1B: 

    /** inline.e:853		for pc = 1 to length( inline_code ) do*/
    if (IS_SEQUENCE(_67inline_code_53881)){
            _27934 = SEQ_PTR(_67inline_code_53881)->length;
    }
    else {
        _27934 = 1;
    }
    {
        object _pc_55103;
        _pc_55103 = 1;
L2A: 
        if (_pc_55103 > _27934){
            goto L2B; // [1225] 1422
        }

        /** inline.e:854			if sequence( inline_code[pc] ) then*/
        _2 = (object)SEQ_PTR(_67inline_code_53881);
        _27935 = (object)*(((s1_ptr)_2)->base + _pc_55103);
        _27936 = IS_SEQUENCE(_27935);
        _27935 = NOVALUE;
        if (_27936 == 0)
        {
            _27936 = NOVALUE;
            goto L2C; // [1243] 1413
        }
        else{
            _27936 = NOVALUE;
        }

        /** inline.e:855				integer inline_type = inline_code[pc][1]*/
        _2 = (object)SEQ_PTR(_67inline_code_53881);
        _27937 = (object)*(((s1_ptr)_2)->base + _pc_55103);
        _2 = (object)SEQ_PTR(_27937);
        _inline_type_55108 = (object)*(((s1_ptr)_2)->base + 1);
        if (!IS_ATOM_INT(_inline_type_55108)){
            _inline_type_55108 = (object)DBL_PTR(_inline_type_55108)->dbl;
        }
        _27937 = NOVALUE;

        /** inline.e:856				switch inline_type do*/
        _0 = _inline_type_55108;
        switch ( _0 ){ 

            /** inline.e:857					case INLINE_SUB then*/
            case 5:

            /** inline.e:858						inline_code[pc] = CurrentSub*/
            _2 = (object)SEQ_PTR(_67inline_code_53881);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _67inline_code_53881 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + _pc_55103);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _36CurrentSub_21775;
            DeRef(_1);
            goto L2D; // [1281] 1412

            /** inline.e:860					case INLINE_VAR then*/
            case 6:

            /** inline.e:861						replace_var( pc )*/
            _67replace_var(_pc_55103);

            /** inline.e:862						break*/
            goto L2D; // [1294] 1412
            goto L2D; // [1296] 1412

            /** inline.e:863					case INLINE_TEMP then*/
            case 2:

            /** inline.e:864						replace_temp( pc )*/
            _67replace_temp(_pc_55103);
            goto L2D; // [1307] 1412

            /** inline.e:866					case INLINE_PARAM then*/
            case 1:

            /** inline.e:867						replace_param( pc )*/

            /** inline.e:586		inline_code[pc] = get_param_sym( pc )*/
            _0 = _replace_param_1__tmp_at1343_55119;
            _replace_param_1__tmp_at1343_55119 = _67get_param_sym(_pc_55103);
            DeRef(_0);
            Ref(_replace_param_1__tmp_at1343_55119);
            _2 = (object)SEQ_PTR(_67inline_code_53881);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _67inline_code_53881 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + _pc_55103);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _replace_param_1__tmp_at1343_55119;
            DeRef(_1);

            /** inline.e:587	end procedure*/
            goto L2E; // [1329] 1332
L2E: 
            DeRef(_replace_param_1__tmp_at1343_55119);
            _replace_param_1__tmp_at1343_55119 = NOVALUE;
            goto L2D; // [1334] 1412

            /** inline.e:869					case INLINE_ADDR then*/
            case 4:

            /** inline.e:870						inline_code[pc] = inline_start + inline_code[pc][2]*/
            _2 = (object)SEQ_PTR(_67inline_code_53881);
            _27941 = (object)*(((s1_ptr)_2)->base + _pc_55103);
            _2 = (object)SEQ_PTR(_27941);
            _27942 = (object)*(((s1_ptr)_2)->base + 2);
            _27941 = NOVALUE;
            if (IS_ATOM_INT(_27942)) {
                _27943 = _67inline_start_53893 + _27942;
                if ((object)((uintptr_t)_27943 + (uintptr_t)HIGH_BITS) >= 0){
                    _27943 = NewDouble((eudouble)_27943);
                }
            }
            else {
                _27943 = binary_op(PLUS, _67inline_start_53893, _27942);
            }
            _27942 = NOVALUE;
            _2 = (object)SEQ_PTR(_67inline_code_53881);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _67inline_code_53881 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + _pc_55103);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _27943;
            if( _1 != _27943 ){
                DeRef(_1);
            }
            _27943 = NOVALUE;
            goto L2D; // [1364] 1412

            /** inline.e:872					case INLINE_TARGET then*/
            case 3:

            /** inline.e:873						inline_code[pc] = inline_target*/
            _2 = (object)SEQ_PTR(_67inline_code_53881);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _67inline_code_53881 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + _pc_55103);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _67inline_target_53888;
            DeRef(_1);

            /** inline.e:874						add_inline_target( pc + inline_start )*/
            _27944 = _pc_55103 + _67inline_start_53893;
            if ((object)((uintptr_t)_27944 + (uintptr_t)HIGH_BITS) >= 0){
                _27944 = NewDouble((eudouble)_27944);
            }
            _47add_inline_target(_27944);
            _27944 = NOVALUE;

            /** inline.e:875						break*/
            goto L2D; // [1393] 1412
            goto L2D; // [1395] 1412

            /** inline.e:877					case else*/
            default:

            /** inline.e:878						InternalErr( 265, {inline_type} )*/
            _1 = NewS1(1);
            _2 = (object)((s1_ptr)_1)->base;
            ((intptr_t*)_2)[1] = _inline_type_55108;
            _27945 = MAKE_SEQ(_1);
            _50InternalErr(265, _27945);
            _27945 = NOVALUE;
        ;}L2D: 
L2C: 

        /** inline.e:881		end for*/
        _pc_55103 = _pc_55103 + 1;
        goto L2A; // [1417] 1232
L2B: 
        ;
    }

    /** inline.e:883		for i = 1 to length(backpatches) do*/
    if (IS_SEQUENCE(_backpatches_54851)){
            _27946 = SEQ_PTR(_backpatches_54851)->length;
    }
    else {
        _27946 = 1;
    }
    {
        object _i_55131;
        _i_55131 = 1;
L2F: 
        if (_i_55131 > _27946){
            goto L30; // [1427] 1450
        }

        /** inline.e:884			fixup_special_op( backpatches[i] )*/
        _2 = (object)SEQ_PTR(_backpatches_54851);
        _27947 = (object)*(((s1_ptr)_2)->base + _i_55131);
        Ref(_27947);
        _67fixup_special_op(_27947);
        _27947 = NOVALUE;

        /** inline.e:885		end for*/
        _i_55131 = _i_55131 + 1;
        goto L2F; // [1445] 1434
L30: 
        ;
    }

    /** inline.e:887		epilog &= End_inline_block( EXIT_BLOCK )*/
    _27948 = _65End_inline_block(206);
    if (IS_SEQUENCE(_epilog_54858) && IS_ATOM(_27948)) {
        Ref(_27948);
        Append(&_epilog_54858, _epilog_54858, _27948);
    }
    else if (IS_ATOM(_epilog_54858) && IS_SEQUENCE(_27948)) {
    }
    else {
        Concat((object_ptr)&_epilog_54858, _epilog_54858, _27948);
    }
    DeRef(_27948);
    _27948 = NOVALUE;

    /** inline.e:889		if is_proc then*/
    if (_is_proc_54833 == 0)
    {
        goto L31; // [1464] 1474
    }
    else{
    }

    /** inline.e:890			clear_op()*/
    _47clear_op();
    goto L32; // [1471] 1597
L31: 

    /** inline.e:892			if not deferred then*/
    if (_deferred_54832 != 0)
    goto L33; // [1476] 1491

    /** inline.e:893				Push( inline_target )*/
    _47Push(_67inline_target_53888);

    /** inline.e:894				inlined_function()*/
    _47inlined_function();
L33: 

    /** inline.e:897			if final_target then*/
    if (_final_target_54957 == 0)
    {
        goto L34; // [1493] 1523
    }
    else{
    }

    /** inline.e:898				epilog &= { ASSIGN, inline_target, final_target }*/
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 18;
    ((intptr_t*)_2)[2] = _67inline_target_53888;
    ((intptr_t*)_2)[3] = _final_target_54957;
    _27951 = MAKE_SEQ(_1);
    Concat((object_ptr)&_epilog_54858, _epilog_54858, _27951);
    DeRefDS(_27951);
    _27951 = NOVALUE;

    /** inline.e:899				emit_temp( final_target, NEW_REFERENCE )*/
    _47emit_temp(_final_target_54957, 1);
    goto L35; // [1520] 1596
L34: 

    /** inline.e:905				emit_temp( inline_target, NEW_REFERENCE )*/
    _47emit_temp(_67inline_target_53888, 1);

    /** inline.e:906				if not TRANSLATE then*/
    if (_36TRANSLATE_21369 != 0)
    goto L36; // [1537] 1595

    /** inline.e:907					epilog &= { ELSE, 0, PRIVATE_INIT_CHECK, inline_target }*/
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 23;
    ((intptr_t*)_2)[2] = 0;
    ((intptr_t*)_2)[3] = 30;
    ((intptr_t*)_2)[4] = _67inline_target_53888;
    _27954 = MAKE_SEQ(_1);
    Concat((object_ptr)&_epilog_54858, _epilog_54858, _27954);
    DeRefDS(_27954);
    _27954 = NOVALUE;

    /** inline.e:908					epilog[$-2] = length(inline_code) + length(epilog) + inline_start + 1*/
    if (IS_SEQUENCE(_epilog_54858)){
            _27956 = SEQ_PTR(_epilog_54858)->length;
    }
    else {
        _27956 = 1;
    }
    _27957 = _27956 - 2;
    _27956 = NOVALUE;
    if (IS_SEQUENCE(_67inline_code_53881)){
            _27958 = SEQ_PTR(_67inline_code_53881)->length;
    }
    else {
        _27958 = 1;
    }
    if (IS_SEQUENCE(_epilog_54858)){
            _27959 = SEQ_PTR(_epilog_54858)->length;
    }
    else {
        _27959 = 1;
    }
    _27960 = _27958 + _27959;
    if ((object)((uintptr_t)_27960 + (uintptr_t)HIGH_BITS) >= 0){
        _27960 = NewDouble((eudouble)_27960);
    }
    _27958 = NOVALUE;
    _27959 = NOVALUE;
    if (IS_ATOM_INT(_27960)) {
        _27961 = _27960 + _67inline_start_53893;
        if ((object)((uintptr_t)_27961 + (uintptr_t)HIGH_BITS) >= 0){
            _27961 = NewDouble((eudouble)_27961);
        }
    }
    else {
        _27961 = NewDouble(DBL_PTR(_27960)->dbl + (eudouble)_67inline_start_53893);
    }
    DeRef(_27960);
    _27960 = NOVALUE;
    if (IS_ATOM_INT(_27961)) {
        _27962 = _27961 + 1;
        if (_27962 > MAXINT){
            _27962 = NewDouble((eudouble)_27962);
        }
    }
    else
    _27962 = binary_op(PLUS, 1, _27961);
    DeRef(_27961);
    _27961 = NOVALUE;
    _2 = (object)SEQ_PTR(_epilog_54858);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _epilog_54858 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _27957);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27962;
    if( _1 != _27962 ){
        DeRef(_1);
    }
    _27962 = NOVALUE;
L36: 
L35: 
L32: 

    /** inline.e:914		return prolog & inline_code & epilog*/
    {
        object concat_list[3];

        concat_list[0] = _epilog_54858;
        concat_list[1] = _67inline_code_53881;
        concat_list[2] = _prolog_54857;
        Concat_N((object_ptr)&_27963, concat_list, 3);
    }
    DeRef(_backpatches_54851);
    DeRefDSi(_prolog_54857);
    DeRefDS(_epilog_54858);
    DeRef(_27916);
    _27916 = NOVALUE;
    _27851 = NOVALUE;
    DeRef(_27924);
    _27924 = NOVALUE;
    DeRef(_27918);
    _27918 = NOVALUE;
    DeRef(_27839);
    _27839 = NOVALUE;
    DeRef(_27957);
    _27957 = NOVALUE;
    _27847 = NOVALUE;
    DeRef(_27871);
    _27871 = NOVALUE;
    DeRef(_27912);
    _27912 = NOVALUE;
    DeRef(_27842);
    _27842 = NOVALUE;
    DeRef(_27868);
    _27868 = NOVALUE;
    DeRef(_27922);
    _27922 = NOVALUE;
    _27834 = NOVALUE;
    return _27963;
    ;
}


void _67defer_call()
{
    object _defer_55171 = NOVALUE;
    object _27966 = NOVALUE;
    object _27965 = NOVALUE;
    object _0, _1, _2;
    

    /** inline.e:918		integer defer = find( inline_sub, deferred_inline_decisions )*/
    _defer_55171 = find_from(_67inline_sub_53895, _67deferred_inline_decisions_53897, 1);

    /** inline.e:919		if defer then*/
    if (_defer_55171 == 0)
    {
        goto L1; // [14] 36
    }
    else{
    }

    /** inline.e:921			deferred_inline_calls[defer] &= CurrentSub*/
    _2 = (object)SEQ_PTR(_67deferred_inline_calls_53898);
    _27965 = (object)*(((s1_ptr)_2)->base + _defer_55171);
    if (IS_SEQUENCE(_27965) && IS_ATOM(_36CurrentSub_21775)) {
        Append(&_27966, _27965, _36CurrentSub_21775);
    }
    else if (IS_ATOM(_27965) && IS_SEQUENCE(_36CurrentSub_21775)) {
    }
    else {
        Concat((object_ptr)&_27966, _27965, _36CurrentSub_21775);
        _27965 = NOVALUE;
    }
    _27965 = NOVALUE;
    _2 = (object)SEQ_PTR(_67deferred_inline_calls_53898);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67deferred_inline_calls_53898 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _defer_55171);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27966;
    if( _1 != _27966 ){
        DeRef(_1);
    }
    _27966 = NOVALUE;
L1: 

    /** inline.e:923	end procedure*/
    return;
    ;
}


void _67emit_or_inline()
{
    object _sub_55180 = NOVALUE;
    object _code_55211 = NOVALUE;
    object _27978 = NOVALUE;
    object _27977 = NOVALUE;
    object _27975 = NOVALUE;
    object _27974 = NOVALUE;
    object _27973 = NOVALUE;
    object _27971 = NOVALUE;
    object _27970 = NOVALUE;
    object _27969 = NOVALUE;
    object _27968 = NOVALUE;
    object _27967 = NOVALUE;
    object _0, _1, _2;
    

    /** inline.e:928		symtab_index sub = op_info1*/
    _sub_55180 = _47op_info1_51364;

    /** inline.e:929		inline_sub = sub*/
    _67inline_sub_53895 = _sub_55180;

    /** inline.e:931		if SymTab[sub][S_DEPRECATED] then*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _27967 = (object)*(((s1_ptr)_2)->base + _sub_55180);
    _2 = (object)SEQ_PTR(_27967);
    _27968 = (object)*(((s1_ptr)_2)->base + 30);
    _27967 = NOVALUE;
    if (_27968 == 0) {
        _27968 = NOVALUE;
        goto L1; // [31] 60
    }
    else {
        if (!IS_ATOM_INT(_27968) && DBL_PTR(_27968)->dbl == 0.0){
            _27968 = NOVALUE;
            goto L1; // [31] 60
        }
        _27968 = NOVALUE;
    }
    _27968 = NOVALUE;

    /** inline.e:932			Warning(327, deprecated_warning_flag, { SymTab[sub][S_NAME] })*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _27969 = (object)*(((s1_ptr)_2)->base + _sub_55180);
    _2 = (object)SEQ_PTR(_27969);
    if (!IS_ATOM_INT(_36S_NAME_21404)){
        _27970 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21404)->dbl));
    }
    else{
        _27970 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21404);
    }
    _27969 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_27970);
    ((intptr_t*)_2)[1] = _27970;
    _27971 = MAKE_SEQ(_1);
    _27970 = NOVALUE;
    _50Warning(327, 16384, _27971);
    _27971 = NOVALUE;
L1: 

    /** inline.e:935		if Parser_mode != PAM_NORMAL then*/
    if (_36Parser_mode_21876 == 0)
    goto L2; // [66] 85

    /** inline.e:938			emit_op( PROC )*/
    _47emit_op(27);

    /** inline.e:939			return*/
    DeRef(_code_55211);
    return;
    goto L3; // [82] 133
L2: 

    /** inline.e:941		elsif atom( SymTab[sub][S_INLINE] ) or has_forward_params(sub) then*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _27973 = (object)*(((s1_ptr)_2)->base + _sub_55180);
    _2 = (object)SEQ_PTR(_27973);
    _27974 = (object)*(((s1_ptr)_2)->base + 29);
    _27973 = NOVALUE;
    _27975 = IS_ATOM(_27974);
    _27974 = NOVALUE;
    if (_27975 != 0) {
        goto L4; // [102] 115
    }
    _27977 = _47has_forward_params(_sub_55180);
    if (_27977 == 0) {
        DeRef(_27977);
        _27977 = NOVALUE;
        goto L5; // [111] 132
    }
    else {
        if (!IS_ATOM_INT(_27977) && DBL_PTR(_27977)->dbl == 0.0){
            DeRef(_27977);
            _27977 = NOVALUE;
            goto L5; // [111] 132
        }
        DeRef(_27977);
        _27977 = NOVALUE;
    }
    DeRef(_27977);
    _27977 = NOVALUE;
L4: 

    /** inline.e:942			defer_call()*/
    _67defer_call();

    /** inline.e:943			emit_op( PROC )*/
    _47emit_op(27);

    /** inline.e:944			return*/
    DeRef(_code_55211);
    return;
L5: 
L3: 

    /** inline.e:947		sequence code = get_inlined_code( sub, length(Code) )*/
    if (IS_SEQUENCE(_36Code_21859)){
            _27978 = SEQ_PTR(_36Code_21859)->length;
    }
    else {
        _27978 = 1;
    }
    _0 = _code_55211;
    _code_55211 = _67get_inlined_code(_sub_55180, _27978, 0);
    DeRef(_0);
    _27978 = NOVALUE;

    /** inline.e:948		emit_inline( code )*/
    RefDS(_code_55211);
    _47emit_inline(_code_55211);

    /** inline.e:949		clear_last()*/
    _47clear_last();

    /** inline.e:951	end procedure*/
    DeRefDS(_code_55211);
    return;
    ;
}


void _67inline_deferred_calls()
{
    object _sub_55225 = NOVALUE;
    object _ix_55237 = NOVALUE;
    object _calling_sub_55239 = NOVALUE;
    object _code_55261 = NOVALUE;
    object _calls_55262 = NOVALUE;
    object _is_func_55266 = NOVALUE;
    object _offset_55273 = NOVALUE;
    object _op_55284 = NOVALUE;
    object _size_55287 = NOVALUE;
    object _28040 = NOVALUE;
    object _28038 = NOVALUE;
    object _28036 = NOVALUE;
    object _28035 = NOVALUE;
    object _28034 = NOVALUE;
    object _28032 = NOVALUE;
    object _28031 = NOVALUE;
    object _28030 = NOVALUE;
    object _28029 = NOVALUE;
    object _28028 = NOVALUE;
    object _28027 = NOVALUE;
    object _28026 = NOVALUE;
    object _28025 = NOVALUE;
    object _28024 = NOVALUE;
    object _28023 = NOVALUE;
    object _28021 = NOVALUE;
    object _28020 = NOVALUE;
    object _28019 = NOVALUE;
    object _28018 = NOVALUE;
    object _28016 = NOVALUE;
    object _28015 = NOVALUE;
    object _28014 = NOVALUE;
    object _28012 = NOVALUE;
    object _28010 = NOVALUE;
    object _28008 = NOVALUE;
    object _28006 = NOVALUE;
    object _28005 = NOVALUE;
    object _28004 = NOVALUE;
    object _28003 = NOVALUE;
    object _28001 = NOVALUE;
    object _28000 = NOVALUE;
    object _27997 = NOVALUE;
    object _27995 = NOVALUE;
    object _27993 = NOVALUE;
    object _27991 = NOVALUE;
    object _27989 = NOVALUE;
    object _27988 = NOVALUE;
    object _27987 = NOVALUE;
    object _27986 = NOVALUE;
    object _27985 = NOVALUE;
    object _27984 = NOVALUE;
    object _27982 = NOVALUE;
    object _27981 = NOVALUE;
    object _27980 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** inline.e:957		deferred_inlining = 1*/
    _67deferred_inlining_53891 = 1;

    /** inline.e:958		for i = 1 to length( deferred_inline_decisions ) do*/
    if (IS_SEQUENCE(_67deferred_inline_decisions_53897)){
            _27980 = SEQ_PTR(_67deferred_inline_decisions_53897)->length;
    }
    else {
        _27980 = 1;
    }
    {
        object _i_55220;
        _i_55220 = 1;
L1: 
        if (_i_55220 > _27980){
            goto L2; // [13] 506
        }

        /** inline.e:960			if length( deferred_inline_calls[i] ) then*/
        _2 = (object)SEQ_PTR(_67deferred_inline_calls_53898);
        _27981 = (object)*(((s1_ptr)_2)->base + _i_55220);
        if (IS_SEQUENCE(_27981)){
                _27982 = SEQ_PTR(_27981)->length;
        }
        else {
            _27982 = 1;
        }
        _27981 = NOVALUE;
        if (_27982 == 0)
        {
            _27982 = NOVALUE;
            goto L3; // [31] 497
        }
        else{
            _27982 = NOVALUE;
        }

        /** inline.e:962				integer sub = deferred_inline_decisions[i]*/
        _2 = (object)SEQ_PTR(_67deferred_inline_decisions_53897);
        _sub_55225 = (object)*(((s1_ptr)_2)->base + _i_55220);

        /** inline.e:963				check_inline( sub )*/
        _67check_inline(_sub_55225);

        /** inline.e:964				if atom( SymTab[sub][S_INLINE] ) then*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _27984 = (object)*(((s1_ptr)_2)->base + _sub_55225);
        _2 = (object)SEQ_PTR(_27984);
        _27985 = (object)*(((s1_ptr)_2)->base + 29);
        _27984 = NOVALUE;
        _27986 = IS_ATOM(_27985);
        _27985 = NOVALUE;
        if (_27986 == 0)
        {
            _27986 = NOVALUE;
            goto L4; // [64] 74
        }
        else{
            _27986 = NOVALUE;
        }

        /** inline.e:965					continue*/
        goto L5; // [71] 501
L4: 

        /** inline.e:967				for cx = 1 to length( deferred_inline_calls[i] ) do*/
        _2 = (object)SEQ_PTR(_67deferred_inline_calls_53898);
        _27987 = (object)*(((s1_ptr)_2)->base + _i_55220);
        if (IS_SEQUENCE(_27987)){
                _27988 = SEQ_PTR(_27987)->length;
        }
        else {
            _27988 = 1;
        }
        _27987 = NOVALUE;
        {
            object _cx_55234;
            _cx_55234 = 1;
L6: 
            if (_cx_55234 > _27988){
                goto L7; // [85] 496
            }

            /** inline.e:968					integer ix = 1*/
            _ix_55237 = 1;

            /** inline.e:969					symtab_index calling_sub = deferred_inline_calls[i][cx]*/
            _2 = (object)SEQ_PTR(_67deferred_inline_calls_53898);
            _27989 = (object)*(((s1_ptr)_2)->base + _i_55220);
            _2 = (object)SEQ_PTR(_27989);
            _calling_sub_55239 = (object)*(((s1_ptr)_2)->base + _cx_55234);
            if (!IS_ATOM_INT(_calling_sub_55239)){
                _calling_sub_55239 = (object)DBL_PTR(_calling_sub_55239)->dbl;
            }
            _27989 = NOVALUE;

            /** inline.e:970					CurrentSub = calling_sub*/
            _36CurrentSub_21775 = _calling_sub_55239;

            /** inline.e:971					Code = SymTab[calling_sub][S_CODE]*/
            _2 = (object)SEQ_PTR(_37SymTab_15637);
            _27991 = (object)*(((s1_ptr)_2)->base + _calling_sub_55239);
            DeRef(_36Code_21859);
            _2 = (object)SEQ_PTR(_27991);
            if (!IS_ATOM_INT(_36S_CODE_21416)){
                _36Code_21859 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21416)->dbl));
            }
            else{
                _36Code_21859 = (object)*(((s1_ptr)_2)->base + _36S_CODE_21416);
            }
            Ref(_36Code_21859);
            _27991 = NOVALUE;

            /** inline.e:972					LineTable = SymTab[calling_sub][S_LINETAB]*/
            _2 = (object)SEQ_PTR(_37SymTab_15637);
            _27993 = (object)*(((s1_ptr)_2)->base + _calling_sub_55239);
            DeRef(_36LineTable_21860);
            _2 = (object)SEQ_PTR(_27993);
            if (!IS_ATOM_INT(_36S_LINETAB_21439)){
                _36LineTable_21860 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_LINETAB_21439)->dbl));
            }
            else{
                _36LineTable_21860 = (object)*(((s1_ptr)_2)->base + _36S_LINETAB_21439);
            }
            Ref(_36LineTable_21860);
            _27993 = NOVALUE;

            /** inline.e:973					SymTab[calling_sub][S_CODE] = 0*/
            _2 = (object)SEQ_PTR(_37SymTab_15637);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _37SymTab_15637 = MAKE_SEQ(_2);
            }
            _3 = (object)(_calling_sub_55239 + ((s1_ptr)_2)->base);
            _2 = (object)SEQ_PTR(*(intptr_t *)_3);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                *(intptr_t *)_3 = MAKE_SEQ(_2);
            }
            if (!IS_ATOM_INT(_36S_CODE_21416))
            _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21416)->dbl));
            else
            _2 = (object)(((s1_ptr)_2)->base + _36S_CODE_21416);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = 0;
            DeRef(_1);
            _27995 = NOVALUE;

            /** inline.e:974					SymTab[calling_sub][S_LINETAB] = 0*/
            _2 = (object)SEQ_PTR(_37SymTab_15637);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _37SymTab_15637 = MAKE_SEQ(_2);
            }
            _3 = (object)(_calling_sub_55239 + ((s1_ptr)_2)->base);
            _2 = (object)SEQ_PTR(*(intptr_t *)_3);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                *(intptr_t *)_3 = MAKE_SEQ(_2);
            }
            if (!IS_ATOM_INT(_36S_LINETAB_21439))
            _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_LINETAB_21439)->dbl));
            else
            _2 = (object)(((s1_ptr)_2)->base + _36S_LINETAB_21439);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = 0;
            DeRef(_1);
            _27997 = NOVALUE;

            /** inline.e:975					sequence code = {}*/
            RefDS(_22190);
            DeRef(_code_55261);
            _code_55261 = _22190;

            /** inline.e:977					sequence calls = find_ops( 1, PROC )*/
            RefDS(_36Code_21859);
            _0 = _calls_55262;
            _calls_55262 = _66find_ops(1, 27, _36Code_21859);
            DeRef(_0);

            /** inline.e:978					integer is_func = SymTab[sub][S_TOKEN] != PROC */
            _2 = (object)SEQ_PTR(_37SymTab_15637);
            _28000 = (object)*(((s1_ptr)_2)->base + _sub_55225);
            _2 = (object)SEQ_PTR(_28000);
            if (!IS_ATOM_INT(_36S_TOKEN_21409)){
                _28001 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21409)->dbl));
            }
            else{
                _28001 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21409);
            }
            _28000 = NOVALUE;
            if (IS_ATOM_INT(_28001)) {
                _is_func_55266 = (_28001 != 27);
            }
            else {
                _is_func_55266 = binary_op(NOTEQ, _28001, 27);
            }
            _28001 = NOVALUE;
            if (!IS_ATOM_INT(_is_func_55266)) {
                _1 = (object)(DBL_PTR(_is_func_55266)->dbl);
                DeRefDS(_is_func_55266);
                _is_func_55266 = _1;
            }

            /** inline.e:979					integer offset = 0*/
            _offset_55273 = 0;

            /** inline.e:980					for o = 1 to length( calls ) do*/
            if (IS_SEQUENCE(_calls_55262)){
                    _28003 = SEQ_PTR(_calls_55262)->length;
            }
            else {
                _28003 = 1;
            }
            {
                object _o_55275;
                _o_55275 = 1;
L8: 
                if (_o_55275 > _28003){
                    goto L9; // [233] 453
                }

                /** inline.e:981						if calls[o][2][2] = sub then*/
                _2 = (object)SEQ_PTR(_calls_55262);
                _28004 = (object)*(((s1_ptr)_2)->base + _o_55275);
                _2 = (object)SEQ_PTR(_28004);
                _28005 = (object)*(((s1_ptr)_2)->base + 2);
                _28004 = NOVALUE;
                _2 = (object)SEQ_PTR(_28005);
                _28006 = (object)*(((s1_ptr)_2)->base + 2);
                _28005 = NOVALUE;
                if (binary_op_a(NOTEQ, _28006, _sub_55225)){
                    _28006 = NOVALUE;
                    goto LA; // [254] 444
                }
                _28006 = NOVALUE;

                /** inline.e:982							ix = calls[o][1]*/
                _2 = (object)SEQ_PTR(_calls_55262);
                _28008 = (object)*(((s1_ptr)_2)->base + _o_55275);
                _2 = (object)SEQ_PTR(_28008);
                _ix_55237 = (object)*(((s1_ptr)_2)->base + 1);
                if (!IS_ATOM_INT(_ix_55237)){
                    _ix_55237 = (object)DBL_PTR(_ix_55237)->dbl;
                }
                _28008 = NOVALUE;

                /** inline.e:983							sequence op = calls[o][2]*/
                _2 = (object)SEQ_PTR(_calls_55262);
                _28010 = (object)*(((s1_ptr)_2)->base + _o_55275);
                DeRef(_op_55284);
                _2 = (object)SEQ_PTR(_28010);
                _op_55284 = (object)*(((s1_ptr)_2)->base + 2);
                Ref(_op_55284);
                _28010 = NOVALUE;

                /** inline.e:984							integer size = length( op ) - 1*/
                if (IS_SEQUENCE(_op_55284)){
                        _28012 = SEQ_PTR(_op_55284)->length;
                }
                else {
                    _28012 = 1;
                }
                _size_55287 = _28012 - 1;
                _28012 = NOVALUE;

                /** inline.e:985							if is_func then*/
                if (_is_func_55266 == 0)
                {
                    goto LB; // [293] 319
                }
                else{
                }

                /** inline.e:987								Push( op[$] )*/
                if (IS_SEQUENCE(_op_55284)){
                        _28014 = SEQ_PTR(_op_55284)->length;
                }
                else {
                    _28014 = 1;
                }
                _2 = (object)SEQ_PTR(_op_55284);
                _28015 = (object)*(((s1_ptr)_2)->base + _28014);
                Ref(_28015);
                _47Push(_28015);
                _28015 = NOVALUE;

                /** inline.e:988								op = remove( op, length(op) )*/
                if (IS_SEQUENCE(_op_55284)){
                        _28016 = SEQ_PTR(_op_55284)->length;
                }
                else {
                    _28016 = 1;
                }
                {
                    s1_ptr assign_space = SEQ_PTR(_op_55284);
                    int len = assign_space->length;
                    int start = (IS_ATOM_INT(_28016)) ? _28016 : (object)(DBL_PTR(_28016)->dbl);
                    int stop = (IS_ATOM_INT(_28016)) ? _28016 : (object)(DBL_PTR(_28016)->dbl);
                    if (stop > len){
                        stop = len;
                    }
                    if (start > len || start > stop || stop<1) {
                    }
                    else if (start < 2) {
                        if (stop >= len) {
                            Head( SEQ_PTR(_op_55284), start, &_op_55284 );
                        }
                        else Tail(SEQ_PTR(_op_55284), stop+1, &_op_55284);
                    }
                    else if (stop >= len){
                        Head(SEQ_PTR(_op_55284), start, &_op_55284);
                    }
                    else {
                        assign_slice_seq = &assign_space;
                        _op_55284 = Remove_elements(start, stop, (SEQ_PTR(_op_55284)->ref == 1));
                    }
                }
                _28016 = NOVALUE;
                _28016 = NOVALUE;
LB: 

                /** inline.e:992							for p = 3 to length( op ) do*/
                if (IS_SEQUENCE(_op_55284)){
                        _28018 = SEQ_PTR(_op_55284)->length;
                }
                else {
                    _28018 = 1;
                }
                {
                    object _p_55297;
                    _p_55297 = 3;
LC: 
                    if (_p_55297 > _28018){
                        goto LD; // [324] 347
                    }

                    /** inline.e:993								Push( op[p] )*/
                    _2 = (object)SEQ_PTR(_op_55284);
                    _28019 = (object)*(((s1_ptr)_2)->base + _p_55297);
                    Ref(_28019);
                    _47Push(_28019);
                    _28019 = NOVALUE;

                    /** inline.e:994							end for*/
                    _p_55297 = _p_55297 + 1;
                    goto LC; // [342] 331
LD: 
                    ;
                }

                /** inline.e:995							code = get_inlined_code( sub, ix + offset - 1, 1 )*/
                _28020 = _ix_55237 + _offset_55273;
                if ((object)((uintptr_t)_28020 + (uintptr_t)HIGH_BITS) >= 0){
                    _28020 = NewDouble((eudouble)_28020);
                }
                if (IS_ATOM_INT(_28020)) {
                    _28021 = _28020 - 1;
                    if ((object)((uintptr_t)_28021 +(uintptr_t) HIGH_BITS) >= 0){
                        _28021 = NewDouble((eudouble)_28021);
                    }
                }
                else {
                    _28021 = NewDouble(DBL_PTR(_28020)->dbl - (eudouble)1);
                }
                DeRef(_28020);
                _28020 = NOVALUE;
                _0 = _code_55261;
                _code_55261 = _67get_inlined_code(_sub_55225, _28021, 1);
                DeRef(_0);
                _28021 = NOVALUE;

                /** inline.e:996							shift:replace_code( repeat( NOP1, length(code) ), ix + offset, ix + offset + size )*/
                if (IS_SEQUENCE(_code_55261)){
                        _28023 = SEQ_PTR(_code_55261)->length;
                }
                else {
                    _28023 = 1;
                }
                _28024 = Repeat(159, _28023);
                _28023 = NOVALUE;
                _28025 = _ix_55237 + _offset_55273;
                if ((object)((uintptr_t)_28025 + (uintptr_t)HIGH_BITS) >= 0){
                    _28025 = NewDouble((eudouble)_28025);
                }
                _28026 = _ix_55237 + _offset_55273;
                if ((object)((uintptr_t)_28026 + (uintptr_t)HIGH_BITS) >= 0){
                    _28026 = NewDouble((eudouble)_28026);
                }
                if (IS_ATOM_INT(_28026)) {
                    _28027 = _28026 + _size_55287;
                    if ((object)((uintptr_t)_28027 + (uintptr_t)HIGH_BITS) >= 0){
                        _28027 = NewDouble((eudouble)_28027);
                    }
                }
                else {
                    _28027 = NewDouble(DBL_PTR(_28026)->dbl + (eudouble)_size_55287);
                }
                DeRef(_28026);
                _28026 = NOVALUE;
                _66replace_code(_28024, _28025, _28027);
                _28024 = NOVALUE;
                _28025 = NOVALUE;
                _28027 = NOVALUE;

                /** inline.e:999							Code = eu:replace( Code, code, ix + offset, ix + offset + length( code ) -1 )*/
                _28028 = _ix_55237 + _offset_55273;
                if ((object)((uintptr_t)_28028 + (uintptr_t)HIGH_BITS) >= 0){
                    _28028 = NewDouble((eudouble)_28028);
                }
                _28029 = _ix_55237 + _offset_55273;
                if ((object)((uintptr_t)_28029 + (uintptr_t)HIGH_BITS) >= 0){
                    _28029 = NewDouble((eudouble)_28029);
                }
                if (IS_SEQUENCE(_code_55261)){
                        _28030 = SEQ_PTR(_code_55261)->length;
                }
                else {
                    _28030 = 1;
                }
                if (IS_ATOM_INT(_28029)) {
                    _28031 = _28029 + _28030;
                    if ((object)((uintptr_t)_28031 + (uintptr_t)HIGH_BITS) >= 0){
                        _28031 = NewDouble((eudouble)_28031);
                    }
                }
                else {
                    _28031 = NewDouble(DBL_PTR(_28029)->dbl + (eudouble)_28030);
                }
                DeRef(_28029);
                _28029 = NOVALUE;
                _28030 = NOVALUE;
                if (IS_ATOM_INT(_28031)) {
                    _28032 = _28031 - 1;
                    if ((object)((uintptr_t)_28032 +(uintptr_t) HIGH_BITS) >= 0){
                        _28032 = NewDouble((eudouble)_28032);
                    }
                }
                else {
                    _28032 = NewDouble(DBL_PTR(_28031)->dbl - (eudouble)1);
                }
                DeRef(_28031);
                _28031 = NOVALUE;
                {
                    intptr_t p1 = _36Code_21859;
                    intptr_t p2 = _code_55261;
                    intptr_t p3 = _28028;
                    intptr_t p4 = _28032;
                    struct replace_block replace_params;
                    replace_params.copy_to   = &p1;
                    replace_params.copy_from = &p2;
                    replace_params.start     = &p3;
                    replace_params.stop      = &p4;
                    replace_params.target    = &_36Code_21859;
                    Replace( &replace_params );
                }
                DeRef(_28028);
                _28028 = NOVALUE;
                DeRef(_28032);
                _28032 = NOVALUE;

                /** inline.e:1000							offset += length(code) - size - 1*/
                if (IS_SEQUENCE(_code_55261)){
                        _28034 = SEQ_PTR(_code_55261)->length;
                }
                else {
                    _28034 = 1;
                }
                _28035 = _28034 - _size_55287;
                if ((object)((uintptr_t)_28035 +(uintptr_t) HIGH_BITS) >= 0){
                    _28035 = NewDouble((eudouble)_28035);
                }
                _28034 = NOVALUE;
                if (IS_ATOM_INT(_28035)) {
                    _28036 = _28035 - 1;
                    if ((object)((uintptr_t)_28036 +(uintptr_t) HIGH_BITS) >= 0){
                        _28036 = NewDouble((eudouble)_28036);
                    }
                }
                else {
                    _28036 = NewDouble(DBL_PTR(_28035)->dbl - (eudouble)1);
                }
                DeRef(_28035);
                _28035 = NOVALUE;
                if (IS_ATOM_INT(_28036)) {
                    _offset_55273 = _offset_55273 + _28036;
                }
                else {
                    _offset_55273 = NewDouble((eudouble)_offset_55273 + DBL_PTR(_28036)->dbl);
                }
                DeRef(_28036);
                _28036 = NOVALUE;
                if (!IS_ATOM_INT(_offset_55273)) {
                    _1 = (object)(DBL_PTR(_offset_55273)->dbl);
                    DeRefDS(_offset_55273);
                    _offset_55273 = _1;
                }
LA: 
                DeRef(_op_55284);
                _op_55284 = NOVALUE;

                /** inline.e:1003					end for*/
                _o_55275 = _o_55275 + 1;
                goto L8; // [448] 240
L9: 
                ;
            }

            /** inline.e:1004					SymTab[calling_sub][S_CODE] = Code*/
            _2 = (object)SEQ_PTR(_37SymTab_15637);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _37SymTab_15637 = MAKE_SEQ(_2);
            }
            _3 = (object)(_calling_sub_55239 + ((s1_ptr)_2)->base);
            RefDS(_36Code_21859);
            _2 = (object)SEQ_PTR(*(intptr_t *)_3);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                *(intptr_t *)_3 = MAKE_SEQ(_2);
            }
            if (!IS_ATOM_INT(_36S_CODE_21416))
            _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21416)->dbl));
            else
            _2 = (object)(((s1_ptr)_2)->base + _36S_CODE_21416);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _36Code_21859;
            DeRef(_1);
            _28038 = NOVALUE;

            /** inline.e:1005					SymTab[calling_sub][S_LINETAB] = LineTable*/
            _2 = (object)SEQ_PTR(_37SymTab_15637);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _37SymTab_15637 = MAKE_SEQ(_2);
            }
            _3 = (object)(_calling_sub_55239 + ((s1_ptr)_2)->base);
            RefDS(_36LineTable_21860);
            _2 = (object)SEQ_PTR(*(intptr_t *)_3);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                *(intptr_t *)_3 = MAKE_SEQ(_2);
            }
            if (!IS_ATOM_INT(_36S_LINETAB_21439))
            _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_LINETAB_21439)->dbl));
            else
            _2 = (object)(((s1_ptr)_2)->base + _36S_LINETAB_21439);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _36LineTable_21860;
            DeRef(_1);
            _28040 = NOVALUE;
            DeRef(_code_55261);
            _code_55261 = NOVALUE;
            DeRef(_calls_55262);
            _calls_55262 = NOVALUE;

            /** inline.e:1006				end for*/
            _cx_55234 = _cx_55234 + 1;
            goto L6; // [491] 92
L7: 
            ;
        }
L3: 

        /** inline.e:1008		end for*/
L5: 
        _i_55220 = _i_55220 + 1;
        goto L1; // [501] 20
L2: 
        ;
    }

    /** inline.e:1009	end procedure*/
    _27987 = NOVALUE;
    _27981 = NOVALUE;
    return;
    ;
}



// 0x77BAF88C
