// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _68GetSourceName()
{
    object _real_name_67254 = NOVALUE;
    object _fh_67255 = NOVALUE;
    object _has_extension_67257 = NOVALUE;
    object _33215 = NOVALUE;
    object _33213 = NOVALUE;
    object _33212 = NOVALUE;
    object _33209 = NOVALUE;
    object _33208 = NOVALUE;
    object _33207 = NOVALUE;
    object _33206 = NOVALUE;
    object _33205 = NOVALUE;
    object _33204 = NOVALUE;
    object _33201 = NOVALUE;
    object _33200 = NOVALUE;
    object _33198 = NOVALUE;
    object _33197 = NOVALUE;
    object _33196 = NOVALUE;
    object _33195 = NOVALUE;
    object _33194 = NOVALUE;
    object _33193 = NOVALUE;
    object _33190 = NOVALUE;
    object _33189 = NOVALUE;
    object _33187 = NOVALUE;
    object _33186 = NOVALUE;
    object _33183 = NOVALUE;
    object _33182 = NOVALUE;
    object _33179 = NOVALUE;
    object _33178 = NOVALUE;
    object _33177 = NOVALUE;
    object _33175 = NOVALUE;
    object _33174 = NOVALUE;
    object _33173 = NOVALUE;
    object _33172 = NOVALUE;
    object _33171 = NOVALUE;
    object _33170 = NOVALUE;
    object _33169 = NOVALUE;
    object _0, _1, _2;
    

    /** main.e:48		boolean has_extension = FALSE*/
    _has_extension_67257 = _13FALSE_445;

    /** main.e:50		if length(src_name) = 0 and not repl then*/
    if (IS_SEQUENCE(_49src_name_49951)){
            _33169 = SEQ_PTR(_49src_name_49951)->length;
    }
    else {
        _33169 = 1;
    }
    _33170 = (_33169 == 0);
    _33169 = NOVALUE;
    if (_33170 == 0) {
        goto L1; // [19] 45
    }
    _33172 = (0 == 0);
    if (_33172 == 0)
    {
        DeRef(_33172);
        _33172 = NOVALUE;
        goto L1; // [29] 45
    }
    else{
        DeRef(_33172);
        _33172 = NOVALUE;
    }

    /** main.e:51			show_banner()*/
    _49show_banner();

    /** main.e:52			return -2 -- No source file*/
    DeRef(_real_name_67254);
    DeRef(_33170);
    _33170 = NOVALUE;
    return -2;
    goto L2; // [42] 143
L1: 

    /** main.e:53		elsif length(src_name) = 0 and repl then*/
    if (IS_SEQUENCE(_49src_name_49951)){
            _33173 = SEQ_PTR(_49src_name_49951)->length;
    }
    else {
        _33173 = 1;
    }
    _33174 = (_33173 == 0);
    _33173 = NOVALUE;
    if (_33174 == 0) {
        goto L3; // [56] 142
    }
    goto L3; // [63] 142

    /** main.e:54			known_files = append(known_files, "")*/
    RefDS(_22190);
    Append(&_37known_files_15638, _37known_files_15638, _22190);

    /** main.e:55			known_files_hash &= hash(known_files[$], stdhash:HSIEH32)*/
    if (IS_SEQUENCE(_37known_files_15638)){
            _33177 = SEQ_PTR(_37known_files_15638)->length;
    }
    else {
        _33177 = 1;
    }
    _2 = (object)SEQ_PTR(_37known_files_15638);
    _33178 = (object)*(((s1_ptr)_2)->base + _33177);
    _33179 = calc_hash(_33178, -5);
    _33178 = NOVALUE;
    Ref(_33179);
    Append(&_37known_files_hash_15639, _37known_files_hash_15639, _33179);
    DeRef(_33179);
    _33179 = NOVALUE;

    /** main.e:56			real_name = ""*/
    RefDS(_22190);
    DeRef(_real_name_67254);
    _real_name_67254 = _22190;

    /** main.e:57			finished_files &= 0*/
    Append(&_37finished_files_15640, _37finished_files_15640, 0);

    /** main.e:58			file_include_depend = append( file_include_depend, { length( known_files ) } )*/
    if (IS_SEQUENCE(_37known_files_15638)){
            _33182 = SEQ_PTR(_37known_files_15638)->length;
    }
    else {
        _33182 = 1;
    }
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _33182;
    _33183 = MAKE_SEQ(_1);
    _33182 = NOVALUE;
    RefDS(_33183);
    Append(&_37file_include_depend_15641, _37file_include_depend_15641, _33183);
    DeRefDS(_33183);
    _33183 = NOVALUE;

    /** main.e:59			return repl_file*/
    DeRefDS(_real_name_67254);
    DeRef(_33170);
    _33170 = NOVALUE;
    DeRef(_33174);
    _33174 = NOVALUE;
    return 5555;
L3: 
L2: 

    /** main.e:62		ifdef WINDOWS then*/

    /** main.e:63			src_name = match_replace("/", src_name, "\\")*/
    RefDS(_23766);
    RefDS(_49src_name_49951);
    RefDS(_23889);
    _0 = _16match_replace(_23766, _49src_name_49951, _23889, 0);
    DeRefDS(_49src_name_49951);
    _49src_name_49951 = _0;

    /** main.e:66		for p = length(src_name) to 1 by -1 do*/
    if (IS_SEQUENCE(_49src_name_49951)){
            _33186 = SEQ_PTR(_49src_name_49951)->length;
    }
    else {
        _33186 = 1;
    }
    {
        object _p_67296;
        _p_67296 = _33186;
L4: 
        if (_p_67296 < 1){
            goto L5; // [165] 229
        }

        /** main.e:67			if src_name[p] = '.' then*/
        _2 = (object)SEQ_PTR(_49src_name_49951);
        _33187 = (object)*(((s1_ptr)_2)->base + _p_67296);
        if (binary_op_a(NOTEQ, _33187, 46)){
            _33187 = NOVALUE;
            goto L6; // [180] 198
        }
        _33187 = NOVALUE;

        /** main.e:68			   has_extension = TRUE*/
        _has_extension_67257 = _13TRUE_447;

        /** main.e:69			   exit*/
        goto L5; // [193] 229
        goto L7; // [195] 222
L6: 

        /** main.e:70			elsif find(src_name[p], SLASH_CHARS) then*/
        _2 = (object)SEQ_PTR(_49src_name_49951);
        _33189 = (object)*(((s1_ptr)_2)->base + _p_67296);
        _33190 = find_from(_33189, _46SLASH_CHARS_21935, 1);
        _33189 = NOVALUE;
        if (_33190 == 0)
        {
            _33190 = NOVALUE;
            goto L8; // [213] 221
        }
        else{
            _33190 = NOVALUE;
        }

        /** main.e:71			   exit*/
        goto L5; // [218] 229
L8: 
L7: 

        /** main.e:73		end for*/
        _p_67296 = _p_67296 + -1;
        goto L4; // [224] 172
L5: 
        ;
    }

    /** main.e:75		if not has_extension then*/
    if (_has_extension_67257 != 0)
    goto L9; // [231] 336

    /** main.e:79			known_files = append(known_files, "")*/
    RefDS(_22190);
    Append(&_37known_files_15638, _37known_files_15638, _22190);

    /** main.e:82			for i = 1 to length( DEFAULT_EXTS ) do*/
    _33193 = 4;
    {
        object _i_67315;
        _i_67315 = 1;
LA: 
        if (_i_67315 > 4){
            goto LB; // [251] 316
        }

        /** main.e:83				known_files[$] = src_name & DEFAULT_EXTS[i]*/
        if (IS_SEQUENCE(_37known_files_15638)){
                _33194 = SEQ_PTR(_37known_files_15638)->length;
        }
        else {
            _33194 = 1;
        }
        _2 = (object)SEQ_PTR(_46DEFAULT_EXTS_21909);
        _33195 = (object)*(((s1_ptr)_2)->base + _i_67315);
        Concat((object_ptr)&_33196, _49src_name_49951, _33195);
        _33195 = NOVALUE;
        _2 = (object)SEQ_PTR(_37known_files_15638);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37known_files_15638 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _33194);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _33196;
        if( _1 != _33196 ){
            DeRef(_1);
        }
        _33196 = NOVALUE;

        /** main.e:84				real_name = e_path_find(known_files[$])*/
        if (IS_SEQUENCE(_37known_files_15638)){
                _33197 = SEQ_PTR(_37known_files_15638)->length;
        }
        else {
            _33197 = 1;
        }
        _2 = (object)SEQ_PTR(_37known_files_15638);
        _33198 = (object)*(((s1_ptr)_2)->base + _33197);
        Ref(_33198);
        _0 = _real_name_67254;
        _real_name_67254 = _48e_path_find(_33198);
        DeRef(_0);
        _33198 = NOVALUE;

        /** main.e:85				if sequence(real_name) then*/
        _33200 = IS_SEQUENCE(_real_name_67254);
        if (_33200 == 0)
        {
            _33200 = NOVALUE;
            goto LC; // [301] 309
        }
        else{
            _33200 = NOVALUE;
        }

        /** main.e:86					exit*/
        goto LB; // [306] 316
LC: 

        /** main.e:88			end for*/
        _i_67315 = _i_67315 + 1;
        goto LA; // [311] 258
LB: 
        ;
    }

    /** main.e:90			if atom(real_name) then*/
    _33201 = IS_ATOM(_real_name_67254);
    if (_33201 == 0)
    {
        _33201 = NOVALUE;
        goto LD; // [323] 372
    }
    else{
        _33201 = NOVALUE;
    }

    /** main.e:91				return -1*/
    DeRef(_real_name_67254);
    DeRef(_33170);
    _33170 = NOVALUE;
    DeRef(_33174);
    _33174 = NOVALUE;
    return -1;
    goto LD; // [333] 372
L9: 

    /** main.e:94			known_files = append(known_files, src_name)*/
    RefDS(_49src_name_49951);
    Append(&_37known_files_15638, _37known_files_15638, _49src_name_49951);

    /** main.e:95			real_name = e_path_find(src_name)*/
    RefDS(_49src_name_49951);
    _0 = _real_name_67254;
    _real_name_67254 = _48e_path_find(_49src_name_49951);
    DeRef(_0);

    /** main.e:96			if atom(real_name) then*/
    _33204 = IS_ATOM(_real_name_67254);
    if (_33204 == 0)
    {
        _33204 = NOVALUE;
        goto LE; // [361] 371
    }
    else{
        _33204 = NOVALUE;
    }

    /** main.e:97				return -1*/
    DeRef(_real_name_67254);
    DeRef(_33170);
    _33170 = NOVALUE;
    DeRef(_33174);
    _33174 = NOVALUE;
    return -1;
LE: 
LD: 

    /** main.e:100		known_files[$] = canonical_path(real_name,,CORRECT)*/
    if (IS_SEQUENCE(_37known_files_15638)){
            _33205 = SEQ_PTR(_37known_files_15638)->length;
    }
    else {
        _33205 = 1;
    }
    Ref(_real_name_67254);
    _33206 = _17canonical_path(_real_name_67254, 0, 2);
    _2 = (object)SEQ_PTR(_37known_files_15638);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37known_files_15638 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _33205);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33206;
    if( _1 != _33206 ){
        DeRef(_1);
    }
    _33206 = NOVALUE;

    /** main.e:101		known_files_hash &= hash(known_files[$], stdhash:HSIEH32)*/
    if (IS_SEQUENCE(_37known_files_15638)){
            _33207 = SEQ_PTR(_37known_files_15638)->length;
    }
    else {
        _33207 = 1;
    }
    _2 = (object)SEQ_PTR(_37known_files_15638);
    _33208 = (object)*(((s1_ptr)_2)->base + _33207);
    _33209 = calc_hash(_33208, -5);
    _33208 = NOVALUE;
    Ref(_33209);
    Append(&_37known_files_hash_15639, _37known_files_hash_15639, _33209);
    DeRef(_33209);
    _33209 = NOVALUE;

    /** main.e:102		finished_files &= 0*/
    Append(&_37finished_files_15640, _37finished_files_15640, 0);

    /** main.e:103		file_include_depend = append( file_include_depend, { length( known_files ) } )*/
    if (IS_SEQUENCE(_37known_files_15638)){
            _33212 = SEQ_PTR(_37known_files_15638)->length;
    }
    else {
        _33212 = 1;
    }
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _33212;
    _33213 = MAKE_SEQ(_1);
    _33212 = NOVALUE;
    RefDS(_33213);
    Append(&_37file_include_depend_15641, _37file_include_depend_15641, _33213);
    DeRefDS(_33213);
    _33213 = NOVALUE;

    /** main.e:105		if file_exists(real_name) then*/
    Ref(_real_name_67254);
    _33215 = _17file_exists(_real_name_67254);
    if (_33215 == 0) {
        DeRef(_33215);
        _33215 = NOVALUE;
        goto LF; // [451] 475
    }
    else {
        if (!IS_ATOM_INT(_33215) && DBL_PTR(_33215)->dbl == 0.0){
            DeRef(_33215);
            _33215 = NOVALUE;
            goto LF; // [451] 475
        }
        DeRef(_33215);
        _33215 = NOVALUE;
    }
    DeRef(_33215);
    _33215 = NOVALUE;

    /** main.e:106			real_name = maybe_preprocess(real_name)*/
    Ref(_real_name_67254);
    _0 = _real_name_67254;
    _real_name_67254 = _64maybe_preprocess(_real_name_67254);
    DeRef(_0);

    /** main.e:107			fh = open_locked(real_name)*/
    Ref(_real_name_67254);
    _fh_67255 = _37open_locked(_real_name_67254);
    if (!IS_ATOM_INT(_fh_67255)) {
        _1 = (object)(DBL_PTR(_fh_67255)->dbl);
        DeRefDS(_fh_67255);
        _fh_67255 = _1;
    }

    /** main.e:108			return fh*/
    DeRef(_real_name_67254);
    DeRef(_33170);
    _33170 = NOVALUE;
    DeRef(_33174);
    _33174 = NOVALUE;
    return _fh_67255;
LF: 

    /** main.e:111		return -1*/
    DeRef(_real_name_67254);
    DeRef(_33170);
    _33170 = NOVALUE;
    DeRef(_33174);
    _33174 = NOVALUE;
    return -1;
    ;
}


void _68main()
{
    object _argc_67384 = NOVALUE;
    object _argv_67385 = NOVALUE;
    object _33255 = NOVALUE;
    object _33254 = NOVALUE;
    object _33253 = NOVALUE;
    object _33252 = NOVALUE;
    object _33251 = NOVALUE;
    object _33250 = NOVALUE;
    object _33249 = NOVALUE;
    object _33248 = NOVALUE;
    object _33247 = NOVALUE;
    object _33246 = NOVALUE;
    object _33245 = NOVALUE;
    object _33242 = NOVALUE;
    object _33240 = NOVALUE;
    object _33238 = NOVALUE;
    object _33237 = NOVALUE;
    object _33236 = NOVALUE;
    object _33235 = NOVALUE;
    object _33234 = NOVALUE;
    object _33233 = NOVALUE;
    object _33232 = NOVALUE;
    object _33231 = NOVALUE;
    object _33227 = NOVALUE;
    object _0, _1, _2;
    

    /** main.e:131		argv = command_line()*/
    DeRef(_argv_67385);
    _argv_67385 = Command_Line();

    /** main.e:133		if BIND then*/
    if (_36BIND_21372 == 0)
    {
        goto L1; // [9] 21
    }
    else{
    }

    /** main.e:134			argv = extract_options(argv)*/
    RefDS(_argv_67385);
    _0 = _argv_67385;
    _argv_67385 = _2extract_options(_argv_67385);
    DeRefDS(_0);
L1: 

    /** main.e:137		argc = length(argv)*/
    if (IS_SEQUENCE(_argv_67385)){
            _argc_67384 = SEQ_PTR(_argv_67385)->length;
    }
    else {
        _argc_67384 = 1;
    }

    /** main.e:139		Argv = argv*/
    RefDS(_argv_67385);
    DeRef(_36Argv_21778);
    _36Argv_21778 = _argv_67385;

    /** main.e:140		Argc = argc*/
    _36Argc_21777 = _argc_67384;

    /** main.e:142		TempErrName = "ex.err"*/
    RefDS(_33226);
    DeRefi(_50TempErrName_49592);
    _50TempErrName_49592 = _33226;

    /** main.e:143		TempWarningName = STDERR*/
    DeRef(_36TempWarningName_21781);
    _36TempWarningName_21781 = 2;

    /** main.e:144		display_warnings = 1*/
    _50display_warnings_49593 = 1;

    /** main.e:146		InitGlobals()*/
    _45InitGlobals();

    /** main.e:148		if TRANSLATE or BIND or INTERPRET then*/
    if (_36TRANSLATE_21369 != 0) {
        _33227 = 1;
        goto L2; // [69] 79
    }
    _33227 = (_36BIND_21372 != 0);
L2: 
    if (_33227 != 0) {
        goto L3; // [79] 90
    }
    if (_36INTERPRET_21366 == 0)
    {
        goto L4; // [86] 96
    }
    else{
    }
L3: 

    /** main.e:149			InitBackEnd(0)*/
    _2InitBackEnd(0);
L4: 

    /** main.e:152		src_file = GetSourceName()*/
    _0 = _68GetSourceName();
    _36src_file_21892 = _0;
    if (!IS_ATOM_INT(_36src_file_21892)) {
        _1 = (object)(DBL_PTR(_36src_file_21892)->dbl);
        DeRefDS(_36src_file_21892);
        _36src_file_21892 = _1;
    }

    /** main.e:154		if src_file = -1 then*/
    if (_36src_file_21892 != -1)
    goto L5; // [107] 185

    /** main.e:156			screen_output(STDERR, GetMsgText(CANT_OPEN_1, 0, {known_files[$]}))*/
    if (IS_SEQUENCE(_37known_files_15638)){
            _33231 = SEQ_PTR(_37known_files_15638)->length;
    }
    else {
        _33231 = 1;
    }
    _2 = (object)SEQ_PTR(_37known_files_15638);
    _33232 = (object)*(((s1_ptr)_2)->base + _33231);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_33232);
    ((intptr_t*)_2)[1] = _33232;
    _33233 = MAKE_SEQ(_1);
    _33232 = NOVALUE;
    _33234 = _39GetMsgText(51, 0, _33233);
    _33233 = NOVALUE;
    _50screen_output(2, _33234);
    _33234 = NOVALUE;

    /** main.e:157			if not batch_job and not test_only then*/
    _33235 = (_36batch_job_21780 == 0);
    if (_33235 == 0) {
        goto L6; // [147] 177
    }
    _33237 = (_36test_only_21779 == 0);
    if (_33237 == 0)
    {
        DeRef(_33237);
        _33237 = NOVALUE;
        goto L6; // [157] 177
    }
    else{
        DeRef(_33237);
        _33237 = NOVALUE;
    }

    /** main.e:158				maybe_any_key(GetMsgText(PAUSED_PRESS_ANY_KEY,0), STDERR)*/
    RefDS(_22190);
    _33238 = _39GetMsgText(277, 0, _22190);
    _5maybe_any_key(_33238, 2);
    _33238 = NOVALUE;
L6: 

    /** main.e:160			Cleanup(1)*/
    _50Cleanup(1);
    goto L7; // [182] 230
L5: 

    /** main.e:162		elsif src_file >= 0 then*/
    if (_36src_file_21892 < 0)
    goto L8; // [189] 229

    /** main.e:163			main_path = known_files[$]*/
    if (IS_SEQUENCE(_37known_files_15638)){
            _33240 = SEQ_PTR(_37known_files_15638)->length;
    }
    else {
        _33240 = 1;
    }
    DeRef(_36main_path_21891);
    _2 = (object)SEQ_PTR(_37known_files_15638);
    _36main_path_21891 = (object)*(((s1_ptr)_2)->base + _33240);
    Ref(_36main_path_21891);

    /** main.e:164			if length(main_path) = 0 then*/
    if (IS_SEQUENCE(_36main_path_21891)){
            _33242 = SEQ_PTR(_36main_path_21891)->length;
    }
    else {
        _33242 = 1;
    }
    if (_33242 != 0)
    goto L9; // [213] 228

    /** main.e:165				main_path = '.' & SLASH*/
    Concat((object_ptr)&_36main_path_21891, 46, 92);
L9: 
L8: 
L7: 

    /** main.e:171		if TRANSLATE then*/
    if (_36TRANSLATE_21369 == 0)
    {
        goto LA; // [234] 243
    }
    else{
    }

    /** main.e:172			InitBackEnd(1)*/
    _2InitBackEnd(1);
LA: 

    /** main.e:175		CheckPlatform()*/
    _2CheckPlatform();

    /** main.e:177		InitSymTab()*/
    _54InitSymTab();

    /** main.e:178		InitEmit()*/
    _47InitEmit();

    /** main.e:179		InitLex()*/
    _62InitLex();

    /** main.e:180		InitParser()*/
    _45InitParser();

    /** main.e:184		eu_namespace()*/
    _62eu_namespace();

    /** main.e:186		ifdef TRANSLATOR then*/

    /** main.e:187			if keep and build_system_type = BUILD_DIRECT then*/
    if (_58keep_42900 == 0) {
        goto LB; // [273] 342
    }
    _33246 = (_56build_system_type_45705 == 3);
    if (_33246 == 0)
    {
        DeRef(_33246);
        _33246 = NOVALUE;
        goto LB; // [286] 342
    }
    else{
        DeRef(_33246);
        _33246 = NOVALUE;
    }

    /** main.e:188				if 0 and not quick_has_changed(known_files[$]) then*/
    if (0 == 0) {
        goto LC; // [291] 341
    }
    if (IS_SEQUENCE(_37known_files_15638)){
            _33248 = SEQ_PTR(_37known_files_15638)->length;
    }
    else {
        _33248 = 1;
    }
    _2 = (object)SEQ_PTR(_37known_files_15638);
    _33249 = (object)*(((s1_ptr)_2)->base + _33248);
    Ref(_33249);
    _33250 = _56quick_has_changed(_33249);
    _33249 = NOVALUE;
    if (IS_ATOM_INT(_33250)) {
        _33251 = (_33250 == 0);
    }
    else {
        _33251 = unary_op(NOT, _33250);
    }
    DeRef(_33250);
    _33250 = NOVALUE;
    if (_33251 == 0) {
        DeRef(_33251);
        _33251 = NOVALUE;
        goto LC; // [312] 341
    }
    else {
        if (!IS_ATOM_INT(_33251) && DBL_PTR(_33251)->dbl == 0.0){
            DeRef(_33251);
            _33251 = NOVALUE;
            goto LC; // [312] 341
        }
        DeRef(_33251);
        _33251 = NOVALUE;
    }
    DeRef(_33251);
    _33251 = NOVALUE;

    /** main.e:189					build_direct(1, known_files[$])*/
    if (IS_SEQUENCE(_37known_files_15638)){
            _33252 = SEQ_PTR(_37known_files_15638)->length;
    }
    else {
        _33252 = 1;
    }
    _2 = (object)SEQ_PTR(_37known_files_15638);
    _33253 = (object)*(((s1_ptr)_2)->base + _33252);
    Ref(_33253);
    _56build_direct(1, _33253);
    _33253 = NOVALUE;

    /** main.e:190					Cleanup(0)*/
    _50Cleanup(0);

    /** main.e:191					return*/
    DeRef(_argv_67385);
    DeRef(_33235);
    _33235 = NOVALUE;
    return;
LC: 
LB: 

    /** main.e:197		main_file()*/
    _62main_file();

    /** main.e:199		check_coverage()*/
    _51check_coverage();

    /** main.e:201		parser()*/
    _45parser();

    /** main.e:203		init_coverage()*/
    _51init_coverage();

    /** main.e:206		if TRANSLATE then*/
    if (_36TRANSLATE_21369 == 0)
    {
        goto LD; // [362] 373
    }
    else{
    }

    /** main.e:207			BackEnd(0) -- translate IL to C*/
    _2BackEnd(0);
    goto LE; // [370] 460
LD: 

    /** main.e:209		elsif BIND then*/
    if (_36BIND_21372 == 0)
    {
        goto LF; // [377] 387
    }
    else{
    }

    /** main.e:210			OutputIL()*/
    _2OutputIL();
    goto LE; // [384] 460
LF: 

    /** main.e:212		elsif INTERPRET and not test_only then*/
    if (_36INTERPRET_21366 == 0) {
        goto L10; // [391] 459
    }
    _33255 = (_36test_only_21779 == 0);
    if (_33255 == 0)
    {
        DeRef(_33255);
        _33255 = NOVALUE;
        goto L10; // [401] 459
    }
    else{
        DeRef(_33255);
        _33255 = NOVALUE;
    }

    /** main.e:213			ifdef not STDDEBUG then*/

    /** main.e:214				BackEnd(0) -- execute IL using Euphoria-coded back-end*/
    _2BackEnd(0);

    /** main.e:216			while repl do*/
L10: 
LE: 

    /** main.e:225		Cleanup(0) -- does warnings*/
    _50Cleanup(0);

    /** main.e:226	end procedure*/
    DeRef(_argv_67385);
    DeRef(_33235);
    _33235 = NOVALUE;
    return;
    ;
}



// 0xA6EAFC7F
