// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _48convert_from_OEM(object _s_50697)
{
    object _ls_50698 = NOVALUE;
    object _rc_50699 = NOVALUE;
    object _26028 = NOVALUE;
    object _26027 = NOVALUE;
    object _26025 = NOVALUE;
    object _26024 = NOVALUE;
    object _26021 = NOVALUE;
    object _26020 = NOVALUE;
    object _0, _1, _2;
    

    /** pathopen.e:37		ls=length(s)*/
    if (IS_SEQUENCE(_s_50697)){
            _ls_50698 = SEQ_PTR(_s_50697)->length;
    }
    else {
        _ls_50698 = 1;
    }

    /** pathopen.e:38		if ls>convert_length then*/
    if (_ls_50698 <= _48convert_length_50677)
    goto L1; // [12] 47

    /** pathopen.e:39			free(convert_buffer)*/
    Ref(_48convert_buffer_50676);
    _9free(_48convert_buffer_50676);

    /** pathopen.e:40			convert_length=and_bits(ls+15,-16)+1*/
    _26020 = _ls_50698 + 15;
    {uintptr_t tu;
         tu = (uintptr_t)_26020 & (uintptr_t)-16;
         _26021 = MAKE_UINT(tu);
    }
    _26020 = NOVALUE;
    if (IS_ATOM_INT(_26021)) {
        _48convert_length_50677 = _26021 + 1;
    }
    else
    { // coercing _48convert_length_50677 to an integer 1
        _48convert_length_50677 = 1+(object)(DBL_PTR(_26021)->dbl);
        if( !IS_ATOM_INT(_48convert_length_50677) ){
            _48convert_length_50677 = (object)DBL_PTR(_48convert_length_50677)->dbl;
        }
    }
    DeRef(_26021);
    _26021 = NOVALUE;

    /** pathopen.e:41			convert_buffer=allocate(convert_length)*/
    _0 = _9allocate(_48convert_length_50677, 0);
    DeRef(_48convert_buffer_50676);
    _48convert_buffer_50676 = _0;
L1: 

    /** pathopen.e:43		poke(convert_buffer,s)*/
    if (IS_ATOM_INT(_48convert_buffer_50676)){
        poke_addr = (uint8_t *)_48convert_buffer_50676;
    }
    else {
        poke_addr = (uint8_t *)(uintptr_t)(DBL_PTR(_48convert_buffer_50676)->dbl);
    }
    _1 = (object)SEQ_PTR(_s_50697);
    _1 = (object)((s1_ptr)_1)->base;
    while (1) {
        _1 += sizeof(object);
        _2 = *((object *)_1);
        if (IS_ATOM_INT(_2)) {
            *poke_addr++ = (uint8_t)_2;
        }
        else if (_2 == NOVALUE) {
            break;
        }
        else {
            *poke_addr++ = (uint8_t)DBL_PTR(_2)->dbl;
        }
    }

    /** pathopen.e:44		poke(convert_buffer+ls,0)*/
    if (IS_ATOM_INT(_48convert_buffer_50676)) {
        _26024 = _48convert_buffer_50676 + _ls_50698;
        if ((object)((uintptr_t)_26024 + (uintptr_t)HIGH_BITS) >= 0){
            _26024 = NewDouble((eudouble)_26024);
        }
    }
    else {
        _26024 = NewDouble(DBL_PTR(_48convert_buffer_50676)->dbl + (eudouble)_ls_50698);
    }
    if (IS_ATOM_INT(_26024)){
        poke_addr = (uint8_t *)_26024;
    }
    else {
        poke_addr = (uint8_t *)(uintptr_t)(DBL_PTR(_26024)->dbl);
    }
    *poke_addr = (uint8_t)0;
    DeRef(_26024);
    _26024 = NOVALUE;

    /** pathopen.e:45		rc=c_func(oem2char,{convert_buffer,convert_buffer}) -- always nonzero*/
    Ref(_48convert_buffer_50676);
    Ref(_48convert_buffer_50676);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _48convert_buffer_50676;
    ((intptr_t *)_2)[2] = _48convert_buffer_50676;
    _26025 = MAKE_SEQ(_1);
    _rc_50699 = call_c(1, _48oem2char_50675, _26025);
    DeRefDS(_26025);
    _26025 = NOVALUE;
    if (!IS_ATOM_INT(_rc_50699)) {
        _1 = (object)(DBL_PTR(_rc_50699)->dbl);
        DeRefDS(_rc_50699);
        _rc_50699 = _1;
    }

    /** pathopen.e:46		return peek({convert_buffer,ls}) */
    Ref(_48convert_buffer_50676);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _48convert_buffer_50676;
    ((intptr_t *)_2)[2] = _ls_50698;
    _26027 = MAKE_SEQ(_1);
    _1 = (object)SEQ_PTR(_26027);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _26028 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    DeRefDS(_26027);
    _26027 = NOVALUE;
    DeRefDS(_s_50697);
    return _26028;
    ;
}


object _48exe_path()
{
    object _26032 = NOVALUE;
    object _0, _1, _2;
    

    /** pathopen.e:70		if sequence(exe_path_cache) then*/
    _26032 = IS_SEQUENCE(_48exe_path_cache_50729);
    if (_26032 == 0)
    {
        _26032 = NOVALUE;
        goto L1; // [8] 20
    }
    else{
        _26032 = NOVALUE;
    }

    /** pathopen.e:71			return exe_path_cache*/
    Ref(_48exe_path_cache_50729);
    return _48exe_path_cache_50729;
L1: 

    /** pathopen.e:74		exe_path_cache = command_line()*/
    DeRef(_48exe_path_cache_50729);
    _48exe_path_cache_50729 = Command_Line();

    /** pathopen.e:75		exe_path_cache = exe_path_cache[1]*/
    _0 = _48exe_path_cache_50729;
    _2 = (object)SEQ_PTR(_48exe_path_cache_50729);
    _48exe_path_cache_50729 = (object)*(((s1_ptr)_2)->base + 1);
    RefDS(_48exe_path_cache_50729);
    DeRefDS(_0);

    /** pathopen.e:77		return exe_path_cache*/
    RefDS(_48exe_path_cache_50729);
    return _48exe_path_cache_50729;
    ;
}


object _48check_cache(object _env_50741, object _inc_path_50742)
{
    object _delim_50743 = NOVALUE;
    object _pos_50744 = NOVALUE;
    object _26083 = NOVALUE;
    object _26082 = NOVALUE;
    object _26081 = NOVALUE;
    object _26080 = NOVALUE;
    object _26078 = NOVALUE;
    object _26077 = NOVALUE;
    object _26076 = NOVALUE;
    object _26075 = NOVALUE;
    object _26074 = NOVALUE;
    object _26073 = NOVALUE;
    object _26072 = NOVALUE;
    object _26071 = NOVALUE;
    object _26070 = NOVALUE;
    object _26069 = NOVALUE;
    object _26068 = NOVALUE;
    object _26064 = NOVALUE;
    object _26063 = NOVALUE;
    object _26062 = NOVALUE;
    object _26061 = NOVALUE;
    object _26060 = NOVALUE;
    object _26059 = NOVALUE;
    object _26058 = NOVALUE;
    object _26057 = NOVALUE;
    object _26055 = NOVALUE;
    object _26054 = NOVALUE;
    object _26053 = NOVALUE;
    object _26052 = NOVALUE;
    object _26051 = NOVALUE;
    object _26050 = NOVALUE;
    object _26048 = NOVALUE;
    object _26047 = NOVALUE;
    object _26046 = NOVALUE;
    object _26045 = NOVALUE;
    object _0, _1, _2;
    

    /** pathopen.e:83		if not num_var then -- first time the var is accessed, add cache entry*/
    if (_48num_var_50718 != 0)
    goto L1; // [9] 94

    /** pathopen.e:84			cache_vars = append(cache_vars,env)*/
    RefDS(_env_50741);
    Append(&_48cache_vars_50719, _48cache_vars_50719, _env_50741);

    /** pathopen.e:85			cache_strings = append(cache_strings,inc_path)*/
    RefDS(_inc_path_50742);
    Append(&_48cache_strings_50720, _48cache_strings_50720, _inc_path_50742);

    /** pathopen.e:86			cache_substrings = append(cache_substrings,{})*/
    RefDS(_22190);
    Append(&_48cache_substrings_50721, _48cache_substrings_50721, _22190);

    /** pathopen.e:87			cache_starts = append(cache_starts,{})*/
    RefDS(_22190);
    Append(&_48cache_starts_50722, _48cache_starts_50722, _22190);

    /** pathopen.e:88			cache_ends = append(cache_ends,{})*/
    RefDS(_22190);
    Append(&_48cache_ends_50723, _48cache_ends_50723, _22190);

    /** pathopen.e:89			ifdef WINDOWS then*/

    /** pathopen.e:90				cache_converted = append(cache_converted,{})*/
    RefDS(_22190);
    Append(&_48cache_converted_50724, _48cache_converted_50724, _22190);

    /** pathopen.e:92			num_var = length(cache_vars)*/
    if (IS_SEQUENCE(_48cache_vars_50719)){
            _48num_var_50718 = SEQ_PTR(_48cache_vars_50719)->length;
    }
    else {
        _48num_var_50718 = 1;
    }

    /** pathopen.e:93			cache_complete &= 0*/
    Append(&_48cache_complete_50725, _48cache_complete_50725, 0);

    /** pathopen.e:94			cache_delims &= 0*/
    Append(&_48cache_delims_50726, _48cache_delims_50726, 0);

    /** pathopen.e:95			return 0*/
    DeRefDSi(_env_50741);
    DeRefDSi(_inc_path_50742);
    return 0;
    goto L2; // [91] 456
L1: 

    /** pathopen.e:97			if compare(inc_path,cache_strings[num_var]) then*/
    _2 = (object)SEQ_PTR(_48cache_strings_50720);
    _26045 = (object)*(((s1_ptr)_2)->base + _48num_var_50718);
    if (IS_ATOM_INT(_inc_path_50742) && IS_ATOM_INT(_26045)){
        _26046 = (_inc_path_50742 < _26045) ? -1 : (_inc_path_50742 > _26045);
    }
    else{
        _26046 = compare(_inc_path_50742, _26045);
    }
    _26045 = NOVALUE;
    if (_26046 == 0)
    {
        _26046 = NOVALUE;
        goto L3; // [108] 455
    }
    else{
        _26046 = NOVALUE;
    }

    /** pathopen.e:98				cache_strings[num_var] = inc_path*/
    RefDS(_inc_path_50742);
    _2 = (object)SEQ_PTR(_48cache_strings_50720);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _48cache_strings_50720 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _48num_var_50718);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _inc_path_50742;
    DeRefDS(_1);

    /** pathopen.e:99				cache_complete[num_var] = 0*/
    _2 = (object)SEQ_PTR(_48cache_complete_50725);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _48cache_complete_50725 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _48num_var_50718);
    *(intptr_t *)_2 = 0;

    /** pathopen.e:100				if match(cache_strings[num_var],inc_path)!=1 then -- try to salvage what we can*/
    _2 = (object)SEQ_PTR(_48cache_strings_50720);
    _26047 = (object)*(((s1_ptr)_2)->base + _48num_var_50718);
    _26048 = e_match_from(_26047, _inc_path_50742, 1);
    _26047 = NOVALUE;
    if (_26048 == 1)
    goto L4; // [146] 454

    /** pathopen.e:101					pos = -1*/
    _pos_50744 = -1;

    /** pathopen.e:102					for i=1 to length(cache_strings[num_var]) do*/
    _2 = (object)SEQ_PTR(_48cache_strings_50720);
    _26050 = (object)*(((s1_ptr)_2)->base + _48num_var_50718);
    if (IS_SEQUENCE(_26050)){
            _26051 = SEQ_PTR(_26050)->length;
    }
    else {
        _26051 = 1;
    }
    _26050 = NOVALUE;
    {
        object _i_50765;
        _i_50765 = 1;
L5: 
        if (_i_50765 > _26051){
            goto L6; // [168] 453
        }

        /** pathopen.e:103						if cache_ends[num_var][i] > length(inc_path) or */
        _2 = (object)SEQ_PTR(_48cache_ends_50723);
        _26052 = (object)*(((s1_ptr)_2)->base + _48num_var_50718);
        _2 = (object)SEQ_PTR(_26052);
        _26053 = (object)*(((s1_ptr)_2)->base + _i_50765);
        _26052 = NOVALUE;
        if (IS_SEQUENCE(_inc_path_50742)){
                _26054 = SEQ_PTR(_inc_path_50742)->length;
        }
        else {
            _26054 = 1;
        }
        if (IS_ATOM_INT(_26053)) {
            _26055 = (_26053 > _26054);
        }
        else {
            _26055 = binary_op(GREATER, _26053, _26054);
        }
        _26053 = NOVALUE;
        _26054 = NOVALUE;
        if (IS_ATOM_INT(_26055)) {
            if (_26055 != 0) {
                goto L7; // [196] 250
            }
        }
        else {
            if (DBL_PTR(_26055)->dbl != 0.0) {
                goto L7; // [196] 250
            }
        }
        _2 = (object)SEQ_PTR(_48cache_substrings_50721);
        _26057 = (object)*(((s1_ptr)_2)->base + _48num_var_50718);
        _2 = (object)SEQ_PTR(_26057);
        _26058 = (object)*(((s1_ptr)_2)->base + _i_50765);
        _26057 = NOVALUE;
        _2 = (object)SEQ_PTR(_48cache_starts_50722);
        _26059 = (object)*(((s1_ptr)_2)->base + _48num_var_50718);
        _2 = (object)SEQ_PTR(_26059);
        _26060 = (object)*(((s1_ptr)_2)->base + _i_50765);
        _26059 = NOVALUE;
        _2 = (object)SEQ_PTR(_48cache_ends_50723);
        _26061 = (object)*(((s1_ptr)_2)->base + _48num_var_50718);
        _2 = (object)SEQ_PTR(_26061);
        _26062 = (object)*(((s1_ptr)_2)->base + _i_50765);
        _26061 = NOVALUE;
        rhs_slice_target = (object_ptr)&_26063;
        RHS_Slice(_inc_path_50742, _26060, _26062);
        if (IS_ATOM_INT(_26058) && IS_ATOM_INT(_26063)){
            _26064 = (_26058 < _26063) ? -1 : (_26058 > _26063);
        }
        else{
            _26064 = compare(_26058, _26063);
        }
        _26058 = NOVALUE;
        DeRefDS(_26063);
        _26063 = NOVALUE;
        if (_26064 == 0)
        {
            _26064 = NOVALUE;
            goto L8; // [246] 261
        }
        else{
            _26064 = NOVALUE;
        }
L7: 

        /** pathopen.e:107							pos = i-1*/
        _pos_50744 = _i_50765 - 1;

        /** pathopen.e:108							exit*/
        goto L6; // [258] 453
L8: 

        /** pathopen.e:110						if pos = 0 then*/
        if (_pos_50744 != 0)
        goto L9; // [263] 276

        /** pathopen.e:111							return 0*/
        DeRefDSi(_env_50741);
        DeRefDSi(_inc_path_50742);
        _26062 = NOVALUE;
        DeRef(_26055);
        _26055 = NOVALUE;
        _26060 = NOVALUE;
        _26050 = NOVALUE;
        return 0;
        goto LA; // [273] 446
L9: 

        /** pathopen.e:112						elsif pos >0 then -- crop cache data*/
        if (_pos_50744 <= 0)
        goto LB; // [278] 445

        /** pathopen.e:113							cache_substrings[num_var] = cache_substrings[num_var][1..pos]*/
        _2 = (object)SEQ_PTR(_48cache_substrings_50721);
        _26068 = (object)*(((s1_ptr)_2)->base + _48num_var_50718);
        rhs_slice_target = (object_ptr)&_26069;
        RHS_Slice(_26068, 1, _pos_50744);
        _26068 = NOVALUE;
        _2 = (object)SEQ_PTR(_48cache_substrings_50721);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _48cache_substrings_50721 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _48num_var_50718);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _26069;
        if( _1 != _26069 ){
            DeRefDS(_1);
        }
        _26069 = NOVALUE;

        /** pathopen.e:114							cache_starts[num_var] = cache_starts[num_var][1..pos]*/
        _2 = (object)SEQ_PTR(_48cache_starts_50722);
        _26070 = (object)*(((s1_ptr)_2)->base + _48num_var_50718);
        rhs_slice_target = (object_ptr)&_26071;
        RHS_Slice(_26070, 1, _pos_50744);
        _26070 = NOVALUE;
        _2 = (object)SEQ_PTR(_48cache_starts_50722);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _48cache_starts_50722 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _48num_var_50718);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _26071;
        if( _1 != _26071 ){
            DeRef(_1);
        }
        _26071 = NOVALUE;

        /** pathopen.e:115							cache_ends[num_var] = cache_ends[num_var][1..pos]*/
        _2 = (object)SEQ_PTR(_48cache_ends_50723);
        _26072 = (object)*(((s1_ptr)_2)->base + _48num_var_50718);
        rhs_slice_target = (object_ptr)&_26073;
        RHS_Slice(_26072, 1, _pos_50744);
        _26072 = NOVALUE;
        _2 = (object)SEQ_PTR(_48cache_ends_50723);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _48cache_ends_50723 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _48num_var_50718);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _26073;
        if( _1 != _26073 ){
            DeRef(_1);
        }
        _26073 = NOVALUE;

        /** pathopen.e:116							ifdef WINDOWS then*/

        /** pathopen.e:117								cache_converted[num_var] = cache_converted[num_var][1..pos]*/
        _2 = (object)SEQ_PTR(_48cache_converted_50724);
        _26074 = (object)*(((s1_ptr)_2)->base + _48num_var_50718);
        rhs_slice_target = (object_ptr)&_26075;
        RHS_Slice(_26074, 1, _pos_50744);
        _26074 = NOVALUE;
        _2 = (object)SEQ_PTR(_48cache_converted_50724);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _48cache_converted_50724 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _48num_var_50718);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _26075;
        if( _1 != _26075 ){
            DeRef(_1);
        }
        _26075 = NOVALUE;

        /** pathopen.e:119							delim = cache_ends[num_var][$]+1*/
        _2 = (object)SEQ_PTR(_48cache_ends_50723);
        _26076 = (object)*(((s1_ptr)_2)->base + _48num_var_50718);
        if (IS_SEQUENCE(_26076)){
                _26077 = SEQ_PTR(_26076)->length;
        }
        else {
            _26077 = 1;
        }
        _2 = (object)SEQ_PTR(_26076);
        _26078 = (object)*(((s1_ptr)_2)->base + _26077);
        _26076 = NOVALUE;
        if (IS_ATOM_INT(_26078)) {
            _delim_50743 = _26078 + 1;
        }
        else
        { // coercing _delim_50743 to an integer 1
            _delim_50743 = 1+(object)(DBL_PTR(_26078)->dbl);
            if( !IS_ATOM_INT(_delim_50743) ){
                _delim_50743 = (object)DBL_PTR(_delim_50743)->dbl;
            }
        }
        _26078 = NOVALUE;

        /** pathopen.e:120							while delim <= length(inc_path) and delim != PATH_SEPARATOR do*/
LC: 
        if (IS_SEQUENCE(_inc_path_50742)){
                _26080 = SEQ_PTR(_inc_path_50742)->length;
        }
        else {
            _26080 = 1;
        }
        _26081 = (_delim_50743 <= _26080);
        _26080 = NOVALUE;
        if (_26081 == 0) {
            goto LD; // [409] 434
        }
        _26083 = (_delim_50743 != 59);
        if (_26083 == 0)
        {
            DeRef(_26083);
            _26083 = NOVALUE;
            goto LD; // [420] 434
        }
        else{
            DeRef(_26083);
            _26083 = NOVALUE;
        }

        /** pathopen.e:121								delim+=1*/
        _delim_50743 = _delim_50743 + 1;

        /** pathopen.e:122							end while*/
        goto LC; // [431] 402
LD: 

        /** pathopen.e:123							cache_delims[num_var] = delim*/
        _2 = (object)SEQ_PTR(_48cache_delims_50726);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _48cache_delims_50726 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _48num_var_50718);
        *(intptr_t *)_2 = _delim_50743;
LB: 
LA: 

        /** pathopen.e:125					end for*/
        _i_50765 = _i_50765 + 1;
        goto L5; // [448] 175
L6: 
        ;
    }
L4: 
L3: 
L2: 

    /** pathopen.e:129		return 1*/
    DeRefDSi(_env_50741);
    DeRefDSi(_inc_path_50742);
    _26062 = NOVALUE;
    DeRef(_26055);
    _26055 = NOVALUE;
    _26060 = NOVALUE;
    DeRef(_26081);
    _26081 = NOVALUE;
    _26050 = NOVALUE;
    return 1;
    ;
}


object _48get_conf_dirs()
{
    object _delimiter_50808 = NOVALUE;
    object _dirs_50809 = NOVALUE;
    object _26088 = NOVALUE;
    object _26086 = NOVALUE;
    object _26085 = NOVALUE;
    object _0, _1, _2;
    

    /** pathopen.e:136		ifdef UNIX then*/

    /** pathopen.e:139			delimiter = ';'*/
    _delimiter_50808 = 59;

    /** pathopen.e:142		dirs = ""*/
    RefDS(_22190);
    DeRef(_dirs_50809);
    _dirs_50809 = _22190;

    /** pathopen.e:143		for i = 1 to length(config_inc_paths) do*/
    if (IS_SEQUENCE(_48config_inc_paths_50727)){
            _26085 = SEQ_PTR(_48config_inc_paths_50727)->length;
    }
    else {
        _26085 = 1;
    }
    {
        object _i_50811;
        _i_50811 = 1;
L1: 
        if (_i_50811 > _26085){
            goto L2; // [22] 68
        }

        /** pathopen.e:144			dirs &= config_inc_paths[i]*/
        _2 = (object)SEQ_PTR(_48config_inc_paths_50727);
        _26086 = (object)*(((s1_ptr)_2)->base + _i_50811);
        Concat((object_ptr)&_dirs_50809, _dirs_50809, _26086);
        _26086 = NOVALUE;

        /** pathopen.e:145			if i != length(config_inc_paths) then*/
        if (IS_SEQUENCE(_48config_inc_paths_50727)){
                _26088 = SEQ_PTR(_48config_inc_paths_50727)->length;
        }
        else {
            _26088 = 1;
        }
        if (_i_50811 == _26088)
        goto L3; // [48] 61

        /** pathopen.e:146				dirs &= delimiter*/
        Append(&_dirs_50809, _dirs_50809, _delimiter_50808);
L3: 

        /** pathopen.e:148		end for*/
        _i_50811 = _i_50811 + 1;
        goto L1; // [63] 29
L2: 
        ;
    }

    /** pathopen.e:150		return dirs*/
    return _dirs_50809;
    ;
}


object _48strip_file_from_path(object _full_path_50821)
{
    object _26094 = NOVALUE;
    object _26092 = NOVALUE;
    object _26091 = NOVALUE;
    object _0, _1, _2;
    

    /** pathopen.e:156		for i = length(full_path) to 1 by -1 do*/
    if (IS_SEQUENCE(_full_path_50821)){
            _26091 = SEQ_PTR(_full_path_50821)->length;
    }
    else {
        _26091 = 1;
    }
    {
        object _i_50823;
        _i_50823 = _26091;
L1: 
        if (_i_50823 < 1){
            goto L2; // [8] 46
        }

        /** pathopen.e:157			if full_path[i] = SLASH then*/
        _2 = (object)SEQ_PTR(_full_path_50821);
        _26092 = (object)*(((s1_ptr)_2)->base + _i_50823);
        if (binary_op_a(NOTEQ, _26092, 92)){
            _26092 = NOVALUE;
            goto L3; // [23] 39
        }
        _26092 = NOVALUE;

        /** pathopen.e:158				return full_path[1..i]*/
        rhs_slice_target = (object_ptr)&_26094;
        RHS_Slice(_full_path_50821, 1, _i_50823);
        DeRefDS(_full_path_50821);
        return _26094;
L3: 

        /** pathopen.e:160		end for*/
        _i_50823 = _i_50823 + -1;
        goto L1; // [41] 15
L2: 
        ;
    }

    /** pathopen.e:162		return ""*/
    RefDS(_22190);
    DeRefDS(_full_path_50821);
    DeRef(_26094);
    _26094 = NOVALUE;
    return _22190;
    ;
}


object _48expand_path(object _path_50832, object _prefix_50833)
{
    object _absolute_50834 = NOVALUE;
    object _26109 = NOVALUE;
    object _26108 = NOVALUE;
    object _26107 = NOVALUE;
    object _26106 = NOVALUE;
    object _26105 = NOVALUE;
    object _26104 = NOVALUE;
    object _26100 = NOVALUE;
    object _26099 = NOVALUE;
    object _26098 = NOVALUE;
    object _26095 = NOVALUE;
    object _0, _1, _2;
    

    /** pathopen.e:169		if not length(path) then*/
    if (IS_SEQUENCE(_path_50832)){
            _26095 = SEQ_PTR(_path_50832)->length;
    }
    else {
        _26095 = 1;
    }
    if (_26095 != 0)
    goto L1; // [10] 22
    _26095 = NOVALUE;

    /** pathopen.e:170			return pwd*/
    RefDS(_48pwd_50730);
    DeRefDS(_path_50832);
    DeRefDS(_prefix_50833);
    return _48pwd_50730;
L1: 

    /** pathopen.e:174		ifdef UNIX then*/

    /** pathopen.e:185			absolute = find(path[1], SLASH_CHARS) or find(':', path)*/
    _2 = (object)SEQ_PTR(_path_50832);
    _26098 = (object)*(((s1_ptr)_2)->base + 1);
    _26099 = find_from(_26098, _46SLASH_CHARS_21935, 1);
    _26098 = NOVALUE;
    _26100 = find_from(58, _path_50832, 1);
    _absolute_50834 = (_26099 != 0 || _26100 != 0);
    _26099 = NOVALUE;
    _26100 = NOVALUE;

    /** pathopen.e:188		if not absolute then*/
    if (_absolute_50834 != 0)
    goto L2; // [50] 64

    /** pathopen.e:189			path = prefix & SLASH & path*/
    {
        object concat_list[3];

        concat_list[0] = _path_50832;
        concat_list[1] = 92;
        concat_list[2] = _prefix_50833;
        Concat_N((object_ptr)&_path_50832, concat_list, 3);
    }
L2: 

    /** pathopen.e:192		if length(path) and not find(path[$], SLASH_CHARS) then*/
    if (IS_SEQUENCE(_path_50832)){
            _26104 = SEQ_PTR(_path_50832)->length;
    }
    else {
        _26104 = 1;
    }
    if (_26104 == 0) {
        goto L3; // [69] 103
    }
    if (IS_SEQUENCE(_path_50832)){
            _26106 = SEQ_PTR(_path_50832)->length;
    }
    else {
        _26106 = 1;
    }
    _2 = (object)SEQ_PTR(_path_50832);
    _26107 = (object)*(((s1_ptr)_2)->base + _26106);
    _26108 = find_from(_26107, _46SLASH_CHARS_21935, 1);
    _26107 = NOVALUE;
    _26109 = (_26108 == 0);
    _26108 = NOVALUE;
    if (_26109 == 0)
    {
        DeRef(_26109);
        _26109 = NOVALUE;
        goto L3; // [91] 103
    }
    else{
        DeRef(_26109);
        _26109 = NOVALUE;
    }

    /** pathopen.e:193			path &= SLASH*/
    Append(&_path_50832, _path_50832, 92);
L3: 

    /** pathopen.e:196		return path*/
    DeRefDS(_prefix_50833);
    return _path_50832;
    ;
}


void _48add_include_directory(object _path_50860)
{
    object _26112 = NOVALUE;
    object _0, _1, _2;
    

    /** pathopen.e:200		path = expand_path( path, pwd )*/
    RefDS(_path_50860);
    RefDS(_48pwd_50730);
    _0 = _path_50860;
    _path_50860 = _48expand_path(_path_50860, _48pwd_50730);
    DeRefDS(_0);

    /** pathopen.e:202		if not find( path, config_inc_paths ) then*/
    _26112 = find_from(_path_50860, _48config_inc_paths_50727, 1);
    if (_26112 != 0)
    goto L1; // [23] 35
    _26112 = NOVALUE;

    /** pathopen.e:203			config_inc_paths = append( config_inc_paths, path )*/
    RefDS(_path_50860);
    Append(&_48config_inc_paths_50727, _48config_inc_paths_50727, _path_50860);
L1: 

    /** pathopen.e:205	end procedure*/
    DeRefDS(_path_50860);
    return;
    ;
}


object _48load_euphoria_config(object _file_50869)
{
    object _fn_50870 = NOVALUE;
    object _in_50871 = NOVALUE;
    object _spos_50872 = NOVALUE;
    object _epos_50873 = NOVALUE;
    object _conf_path_50874 = NOVALUE;
    object _new_args_50875 = NOVALUE;
    object _arg_50876 = NOVALUE;
    object _parm_50877 = NOVALUE;
    object _section_50878 = NOVALUE;
    object _needed_50975 = NOVALUE;
    object _26209 = NOVALUE;
    object _26208 = NOVALUE;
    object _26205 = NOVALUE;
    object _26203 = NOVALUE;
    object _26202 = NOVALUE;
    object _26180 = NOVALUE;
    object _26177 = NOVALUE;
    object _26176 = NOVALUE;
    object _26174 = NOVALUE;
    object _26170 = NOVALUE;
    object _26168 = NOVALUE;
    object _26166 = NOVALUE;
    object _26164 = NOVALUE;
    object _26162 = NOVALUE;
    object _26160 = NOVALUE;
    object _26159 = NOVALUE;
    object _26158 = NOVALUE;
    object _26157 = NOVALUE;
    object _26156 = NOVALUE;
    object _26155 = NOVALUE;
    object _26154 = NOVALUE;
    object _26153 = NOVALUE;
    object _26151 = NOVALUE;
    object _26149 = NOVALUE;
    object _26147 = NOVALUE;
    object _26143 = NOVALUE;
    object _26142 = NOVALUE;
    object _26137 = NOVALUE;
    object _26135 = NOVALUE;
    object _26133 = NOVALUE;
    object _26132 = NOVALUE;
    object _26124 = NOVALUE;
    object _26118 = NOVALUE;
    object _26117 = NOVALUE;
    object _26115 = NOVALUE;
    object _0, _1, _2;
    

    /** pathopen.e:213		sequence new_args = {}*/
    RefDS(_22190);
    DeRef(_new_args_50875);
    _new_args_50875 = _22190;

    /** pathopen.e:219		if file_type(file) = FILETYPE_DIRECTORY then*/
    RefDS(_file_50869);
    _26115 = _17file_type(_file_50869);
    if (binary_op_a(NOTEQ, _26115, 2)){
        DeRef(_26115);
        _26115 = NOVALUE;
        goto L1; // [18] 53
    }
    DeRef(_26115);
    _26115 = NOVALUE;

    /** pathopen.e:220			if file[$] != SLASH then*/
    if (IS_SEQUENCE(_file_50869)){
            _26117 = SEQ_PTR(_file_50869)->length;
    }
    else {
        _26117 = 1;
    }
    _2 = (object)SEQ_PTR(_file_50869);
    _26118 = (object)*(((s1_ptr)_2)->base + _26117);
    if (binary_op_a(EQUALS, _26118, 92)){
        _26118 = NOVALUE;
        goto L2; // [33] 46
    }
    _26118 = NOVALUE;

    /** pathopen.e:221				file &= SLASH*/
    Append(&_file_50869, _file_50869, 92);
L2: 

    /** pathopen.e:223			file &= "eu.cfg"*/
    Concat((object_ptr)&_file_50869, _file_50869, _26121);
L1: 

    /** pathopen.e:226		conf_path = canonical_path( file,,CORRECT )*/
    RefDS(_file_50869);
    _0 = _conf_path_50874;
    _conf_path_50874 = _17canonical_path(_file_50869, 0, 2);
    DeRef(_0);

    /** pathopen.e:229		if find(conf_path, seen_conf) != 0 then*/
    _26124 = find_from(_conf_path_50874, _48seen_conf_50866, 1);
    if (_26124 == 0)
    goto L3; // [74] 85

    /** pathopen.e:230			return {}*/
    RefDS(_22190);
    DeRefDS(_file_50869);
    DeRefi(_in_50871);
    DeRefDS(_conf_path_50874);
    DeRef(_new_args_50875);
    DeRefi(_arg_50876);
    DeRefi(_parm_50877);
    DeRef(_section_50878);
    return _22190;
L3: 

    /** pathopen.e:232		seen_conf = append(seen_conf, conf_path)*/
    RefDS(_conf_path_50874);
    Append(&_48seen_conf_50866, _48seen_conf_50866, _conf_path_50874);

    /** pathopen.e:234		section = "all"*/
    RefDS(_26127);
    DeRef(_section_50878);
    _section_50878 = _26127;

    /** pathopen.e:235		fn = open( conf_path, "r" )*/
    _fn_50870 = EOpen(_conf_path_50874, _26128, 0);

    /** pathopen.e:236		if fn = -1 then return {} end if*/
    if (_fn_50870 != -1)
    goto L4; // [109] 118
    RefDS(_22190);
    DeRefDS(_file_50869);
    DeRefi(_in_50871);
    DeRefDS(_conf_path_50874);
    DeRef(_new_args_50875);
    DeRefi(_arg_50876);
    DeRefi(_parm_50877);
    DeRefDSi(_section_50878);
    return _22190;
L4: 

    /** pathopen.e:238		in = gets( fn )*/
    DeRefi(_in_50871);
    _in_50871 = EGets(_fn_50870);

    /** pathopen.e:239		while sequence( in ) do*/
L5: 
    _26132 = IS_SEQUENCE(_in_50871);
    if (_26132 == 0)
    {
        _26132 = NOVALUE;
        goto L6; // [131] 768
    }
    else{
        _26132 = NOVALUE;
    }

    /** pathopen.e:241			spos = 1*/
    _spos_50872 = 1;

    /** pathopen.e:242			while spos <= length(in) do*/
L7: 
    if (IS_SEQUENCE(_in_50871)){
            _26133 = SEQ_PTR(_in_50871)->length;
    }
    else {
        _26133 = 1;
    }
    if (_spos_50872 > _26133)
    goto L8; // [147] 182

    /** pathopen.e:243				if find( in[spos], "\n\r \t" ) = 0 then*/
    _2 = (object)SEQ_PTR(_in_50871);
    _26135 = (object)*(((s1_ptr)_2)->base + _spos_50872);
    _26137 = find_from(_26135, _26136, 1);
    _26135 = NOVALUE;
    if (_26137 != 0)
    goto L9; // [162] 171

    /** pathopen.e:244					exit*/
    goto L8; // [168] 182
L9: 

    /** pathopen.e:246				spos += 1*/
    _spos_50872 = _spos_50872 + 1;

    /** pathopen.e:247			end while*/
    goto L7; // [179] 144
L8: 

    /** pathopen.e:249			epos = length(in)*/
    if (IS_SEQUENCE(_in_50871)){
            _epos_50873 = SEQ_PTR(_in_50871)->length;
    }
    else {
        _epos_50873 = 1;
    }

    /** pathopen.e:250			while epos >= spos do*/
LA: 
    if (_epos_50873 < _spos_50872)
    goto LB; // [192] 227

    /** pathopen.e:251				if find( in[epos], "\n\r \t" ) = 0 then*/
    _2 = (object)SEQ_PTR(_in_50871);
    _26142 = (object)*(((s1_ptr)_2)->base + _epos_50873);
    _26143 = find_from(_26142, _26136, 1);
    _26142 = NOVALUE;
    if (_26143 != 0)
    goto LC; // [207] 216

    /** pathopen.e:252					exit*/
    goto LB; // [213] 227
LC: 

    /** pathopen.e:254				epos -= 1*/
    _epos_50873 = _epos_50873 - 1;

    /** pathopen.e:255			end while*/
    goto LA; // [224] 192
LB: 

    /** pathopen.e:257			in = in[spos .. epos]		*/
    rhs_slice_target = (object_ptr)&_in_50871;
    RHS_Slice(_in_50871, _spos_50872, _epos_50873);

    /** pathopen.e:260			arg = ""*/
    RefDS(_22190);
    DeRefi(_arg_50876);
    _arg_50876 = _22190;

    /** pathopen.e:261			parm = ""*/
    RefDS(_22190);
    DeRefi(_parm_50877);
    _parm_50877 = _22190;

    /** pathopen.e:269			if length(in) > 0 then*/
    if (IS_SEQUENCE(_in_50871)){
            _26147 = SEQ_PTR(_in_50871)->length;
    }
    else {
        _26147 = 1;
    }
    if (_26147 <= 0)
    goto LD; // [253] 477

    /** pathopen.e:270				if in[1] = '[' then*/
    _2 = (object)SEQ_PTR(_in_50871);
    _26149 = (object)*(((s1_ptr)_2)->base + 1);
    if (_26149 != 91)
    goto LE; // [263] 354

    /** pathopen.e:272					section = in[2..$]*/
    if (IS_SEQUENCE(_in_50871)){
            _26151 = SEQ_PTR(_in_50871)->length;
    }
    else {
        _26151 = 1;
    }
    rhs_slice_target = (object_ptr)&_section_50878;
    RHS_Slice(_in_50871, 2, _26151);

    /** pathopen.e:273					if length(section) > 0 and section[$] = ']' then*/
    if (IS_SEQUENCE(_section_50878)){
            _26153 = SEQ_PTR(_section_50878)->length;
    }
    else {
        _26153 = 1;
    }
    _26154 = (_26153 > 0);
    _26153 = NOVALUE;
    if (_26154 == 0) {
        goto LF; // [286] 320
    }
    if (IS_SEQUENCE(_section_50878)){
            _26156 = SEQ_PTR(_section_50878)->length;
    }
    else {
        _26156 = 1;
    }
    _2 = (object)SEQ_PTR(_section_50878);
    _26157 = (object)*(((s1_ptr)_2)->base + _26156);
    _26158 = (_26157 == 93);
    _26157 = NOVALUE;
    if (_26158 == 0)
    {
        DeRef(_26158);
        _26158 = NOVALUE;
        goto LF; // [302] 320
    }
    else{
        DeRef(_26158);
        _26158 = NOVALUE;
    }

    /** pathopen.e:274						section = section[1..$-1]*/
    if (IS_SEQUENCE(_section_50878)){
            _26159 = SEQ_PTR(_section_50878)->length;
    }
    else {
        _26159 = 1;
    }
    _26160 = _26159 - 1;
    _26159 = NOVALUE;
    rhs_slice_target = (object_ptr)&_section_50878;
    RHS_Slice(_section_50878, 1, _26160);
LF: 

    /** pathopen.e:276					section = lower(trim(section))*/
    RefDS(_section_50878);
    RefDS(_3922);
    _26162 = _14trim(_section_50878, _3922, 0);
    _0 = _section_50878;
    _section_50878 = _14lower(_26162);
    DeRefDS(_0);
    _26162 = NOVALUE;

    /** pathopen.e:277					if length(section) = 0 then*/
    if (IS_SEQUENCE(_section_50878)){
            _26164 = SEQ_PTR(_section_50878)->length;
    }
    else {
        _26164 = 1;
    }
    if (_26164 != 0)
    goto L10; // [339] 476

    /** pathopen.e:278						section = "all"*/
    RefDS(_26127);
    DeRefDS(_section_50878);
    _section_50878 = _26127;
    goto L10; // [351] 476
LE: 

    /** pathopen.e:281				elsif length(in) > 2 then*/
    if (IS_SEQUENCE(_in_50871)){
            _26166 = SEQ_PTR(_in_50871)->length;
    }
    else {
        _26166 = 1;
    }
    if (_26166 <= 2)
    goto L11; // [359] 461

    /** pathopen.e:282					if in[1] = '-' then*/
    _2 = (object)SEQ_PTR(_in_50871);
    _26168 = (object)*(((s1_ptr)_2)->base + 1);
    if (_26168 != 45)
    goto L12; // [369] 443

    /** pathopen.e:283						if in[2] != '-' then*/
    _2 = (object)SEQ_PTR(_in_50871);
    _26170 = (object)*(((s1_ptr)_2)->base + 2);
    if (_26170 == 45)
    goto L10; // [379] 476

    /** pathopen.e:284							spos = find(' ', in)*/
    _spos_50872 = find_from(32, _in_50871, 1);

    /** pathopen.e:285							if spos = 0 then*/
    if (_spos_50872 != 0)
    goto L13; // [392] 413

    /** pathopen.e:286								arg = in*/
    Ref(_in_50871);
    DeRefi(_arg_50876);
    _arg_50876 = _in_50871;

    /** pathopen.e:287								parm = ""*/
    RefDS(_22190);
    DeRefi(_parm_50877);
    _parm_50877 = _22190;
    goto L10; // [410] 476
L13: 

    /** pathopen.e:289								arg = in[1..spos - 1]*/
    _26174 = _spos_50872 - 1;
    rhs_slice_target = (object_ptr)&_arg_50876;
    RHS_Slice(_in_50871, 1, _26174);

    /** pathopen.e:290								parm = in[spos + 1 .. $]*/
    _26176 = _spos_50872 + 1;
    if (_26176 > MAXINT){
        _26176 = NewDouble((eudouble)_26176);
    }
    if (IS_SEQUENCE(_in_50871)){
            _26177 = SEQ_PTR(_in_50871)->length;
    }
    else {
        _26177 = 1;
    }
    rhs_slice_target = (object_ptr)&_parm_50877;
    RHS_Slice(_in_50871, _26176, _26177);
    goto L10; // [440] 476
L12: 

    /** pathopen.e:294						arg = "-i"*/
    RefDS(_26179);
    DeRefi(_arg_50876);
    _arg_50876 = _26179;

    /** pathopen.e:295						parm = in*/
    Ref(_in_50871);
    DeRefi(_parm_50877);
    _parm_50877 = _in_50871;
    goto L10; // [458] 476
L11: 

    /** pathopen.e:298					arg = "-i"*/
    RefDS(_26179);
    DeRefi(_arg_50876);
    _arg_50876 = _26179;

    /** pathopen.e:299					parm = in*/
    Ref(_in_50871);
    DeRefi(_parm_50877);
    _parm_50877 = _in_50871;
L10: 
LD: 

    /** pathopen.e:303			if length(arg) > 0 then*/
    if (IS_SEQUENCE(_arg_50876)){
            _26180 = SEQ_PTR(_arg_50876)->length;
    }
    else {
        _26180 = 1;
    }
    if (_26180 <= 0)
    goto L14; // [482] 756

    /** pathopen.e:304				integer needed = 0*/
    _needed_50975 = 0;

    /** pathopen.e:305				switch section do*/
    _1 = find(_section_50878, _26182);
    switch ( _1 ){ 

        /** pathopen.e:306					case "all" then*/
        case 1:

        /** pathopen.e:307						needed = 1*/
        _needed_50975 = 1;
        goto L15; // [507] 691

        /** pathopen.e:309					case "windows" then*/
        case 2:

        /** pathopen.e:310						needed = TWINDOWS*/
        _needed_50975 = _46TWINDOWS_21914;
        goto L15; // [522] 691

        /** pathopen.e:312					case "unix" then*/
        case 3:

        /** pathopen.e:313						needed = TUNIX*/
        _needed_50975 = _46TUNIX_21918;
        goto L15; // [537] 691

        /** pathopen.e:315					case "translate" then*/
        case 4:

        /** pathopen.e:316						needed = TRANSLATE*/
        _needed_50975 = _36TRANSLATE_21369;
        goto L15; // [552] 691

        /** pathopen.e:318					case "translate:windows" then*/
        case 5:

        /** pathopen.e:319						needed = TRANSLATE and TWINDOWS*/
        _needed_50975 = (_36TRANSLATE_21369 != 0 && _46TWINDOWS_21914 != 0);
        goto L15; // [570] 691

        /** pathopen.e:321					case "translate:unix" then*/
        case 6:

        /** pathopen.e:322						needed = TRANSLATE and TUNIX*/
        _needed_50975 = (_36TRANSLATE_21369 != 0 && _46TUNIX_21918 != 0);
        goto L15; // [588] 691

        /** pathopen.e:324					case "interpret" then*/
        case 7:

        /** pathopen.e:325						needed = INTERPRET*/
        _needed_50975 = _36INTERPRET_21366;
        goto L15; // [603] 691

        /** pathopen.e:327					case "interpret:windows" then*/
        case 8:

        /** pathopen.e:328						needed = INTERPRET and TWINDOWS*/
        _needed_50975 = (_36INTERPRET_21366 != 0 && _46TWINDOWS_21914 != 0);
        goto L15; // [621] 691

        /** pathopen.e:330					case "interpret:unix" then*/
        case 9:

        /** pathopen.e:331						needed = INTERPRET and TUNIX*/
        _needed_50975 = (_36INTERPRET_21366 != 0 && _46TUNIX_21918 != 0);
        goto L15; // [639] 691

        /** pathopen.e:333					case "bind" then*/
        case 10:

        /** pathopen.e:334						needed = BIND*/
        _needed_50975 = _36BIND_21372;
        goto L15; // [654] 691

        /** pathopen.e:336					case "bind:windows" then*/
        case 11:

        /** pathopen.e:337						needed = BIND and TWINDOWS*/
        _needed_50975 = (_36BIND_21372 != 0 && _46TWINDOWS_21914 != 0);
        goto L15; // [672] 691

        /** pathopen.e:339					case "bind:unix" then*/
        case 12:

        /** pathopen.e:340						needed = BIND and TUNIX*/
        _needed_50975 = (_36BIND_21372 != 0 && _46TUNIX_21918 != 0);
    ;}L15: 

    /** pathopen.e:344				if needed then*/
    if (_needed_50975 == 0)
    {
        goto L16; // [693] 755
    }
    else{
    }

    /** pathopen.e:345					if equal(arg, "-c") then*/
    if (_arg_50876 == _26201)
    _26202 = 1;
    else if (IS_ATOM_INT(_arg_50876) && IS_ATOM_INT(_26201))
    _26202 = 0;
    else
    _26202 = (compare(_arg_50876, _26201) == 0);
    if (_26202 == 0)
    {
        _26202 = NOVALUE;
        goto L17; // [702] 728
    }
    else{
        _26202 = NOVALUE;
    }

    /** pathopen.e:346						if length(parm) > 0 then*/
    if (IS_SEQUENCE(_parm_50877)){
            _26203 = SEQ_PTR(_parm_50877)->length;
    }
    else {
        _26203 = 1;
    }
    if (_26203 <= 0)
    goto L18; // [710] 754

    /** pathopen.e:347							new_args &= load_euphoria_config(parm)*/
    RefDS(_parm_50877);
    _26205 = _48load_euphoria_config(_parm_50877);
    if (IS_SEQUENCE(_new_args_50875) && IS_ATOM(_26205)) {
        Ref(_26205);
        Append(&_new_args_50875, _new_args_50875, _26205);
    }
    else if (IS_ATOM(_new_args_50875) && IS_SEQUENCE(_26205)) {
    }
    else {
        Concat((object_ptr)&_new_args_50875, _new_args_50875, _26205);
    }
    DeRef(_26205);
    _26205 = NOVALUE;
    goto L18; // [725] 754
L17: 

    /** pathopen.e:350						new_args = append(new_args, arg)*/
    RefDS(_arg_50876);
    Append(&_new_args_50875, _new_args_50875, _arg_50876);

    /** pathopen.e:351						if length(parm > 0) then*/
    _26208 = binary_op(GREATER, _parm_50877, 0);
    if (IS_SEQUENCE(_26208)){
            _26209 = SEQ_PTR(_26208)->length;
    }
    else {
        _26209 = 1;
    }
    DeRefDS(_26208);
    _26208 = NOVALUE;
    if (_26209 == 0)
    {
        _26209 = NOVALUE;
        goto L19; // [743] 753
    }
    else{
        _26209 = NOVALUE;
    }

    /** pathopen.e:352							new_args = append(new_args, parm)*/
    RefDS(_parm_50877);
    Append(&_new_args_50875, _new_args_50875, _parm_50877);
L19: 
L18: 
L16: 
L14: 

    /** pathopen.e:358			in = gets( fn )*/
    DeRefi(_in_50871);
    _in_50871 = EGets(_fn_50870);

    /** pathopen.e:359		end while*/
    goto L5; // [765] 128
L6: 

    /** pathopen.e:360		close(fn)*/
    EClose(_fn_50870);

    /** pathopen.e:362		return new_args*/
    DeRefDS(_file_50869);
    DeRefi(_in_50871);
    DeRef(_conf_path_50874);
    DeRefi(_arg_50876);
    DeRefi(_parm_50877);
    DeRef(_section_50878);
    DeRef(_26160);
    _26160 = NOVALUE;
    _26168 = NOVALUE;
    DeRef(_26174);
    _26174 = NOVALUE;
    DeRef(_26154);
    _26154 = NOVALUE;
    _26149 = NOVALUE;
    _26170 = NOVALUE;
    _26208 = NOVALUE;
    DeRef(_26176);
    _26176 = NOVALUE;
    return _new_args_50875;
    ;
}


object _48GetDefaultArgs(object _user_files_51042)
{
    object _env_51043 = NOVALUE;
    object _default_args_51044 = NOVALUE;
    object _conf_file_51045 = NOVALUE;
    object _cmd_options_51047 = NOVALUE;
    object _user_config_51053 = NOVALUE;
    object _26254 = NOVALUE;
    object _26253 = NOVALUE;
    object _26252 = NOVALUE;
    object _26249 = NOVALUE;
    object _26248 = NOVALUE;
    object _26247 = NOVALUE;
    object _26245 = NOVALUE;
    object _26241 = NOVALUE;
    object _26240 = NOVALUE;
    object _26239 = NOVALUE;
    object _26238 = NOVALUE;
    object _26234 = NOVALUE;
    object _26233 = NOVALUE;
    object _26232 = NOVALUE;
    object _26230 = NOVALUE;
    object _26224 = NOVALUE;
    object _26223 = NOVALUE;
    object _26221 = NOVALUE;
    object _26219 = NOVALUE;
    object _26218 = NOVALUE;
    object _26214 = NOVALUE;
    object _26213 = NOVALUE;
    object _0, _1, _2;
    

    /** pathopen.e:367		sequence default_args = {}*/
    RefDS(_22190);
    DeRef(_default_args_51044);
    _default_args_51044 = _22190;

    /** pathopen.e:368		sequence conf_file = "eu.cfg"*/
    RefDS(_26121);
    DeRefi(_conf_file_51045);
    _conf_file_51045 = _26121;

    /** pathopen.e:370		if loaded_config_inc_paths then return "" end if*/
    if (_48loaded_config_inc_paths_50728 == 0)
    {
        goto L1; // [21] 29
    }
    else{
    }
    RefDS(_22190);
    DeRefDS(_user_files_51042);
    DeRef(_env_51043);
    DeRefDS(_default_args_51044);
    DeRefDSi(_conf_file_51045);
    DeRef(_cmd_options_51047);
    return _22190;
L1: 

    /** pathopen.e:371		loaded_config_inc_paths = 1*/
    _48loaded_config_inc_paths_50728 = 1;

    /** pathopen.e:380		sequence cmd_options = get_options()*/
    _0 = _cmd_options_51047;
    _cmd_options_51047 = _49get_options();
    DeRef(_0);

    /** pathopen.e:382		default_args = {}*/
    RefDS(_22190);
    DeRef(_default_args_51044);
    _default_args_51044 = _22190;

    /** pathopen.e:385		for i = 1 to length( user_files ) do*/
    if (IS_SEQUENCE(_user_files_51042)){
            _26213 = SEQ_PTR(_user_files_51042)->length;
    }
    else {
        _26213 = 1;
    }
    {
        object _i_51051;
        _i_51051 = 1;
L2: 
        if (_i_51051 > _26213){
            goto L3; // [53] 92
        }

        /** pathopen.e:386			sequence user_config = load_euphoria_config( user_files[i] )*/
        _2 = (object)SEQ_PTR(_user_files_51042);
        _26214 = (object)*(((s1_ptr)_2)->base + _i_51051);
        Ref(_26214);
        _0 = _user_config_51053;
        _user_config_51053 = _48load_euphoria_config(_26214);
        DeRef(_0);
        _26214 = NOVALUE;

        /** pathopen.e:387			default_args = merge_parameters( user_config, default_args, cmd_options, 1 )*/
        RefDS(_user_config_51053);
        RefDS(_default_args_51044);
        RefDS(_cmd_options_51047);
        _0 = _default_args_51044;
        _default_args_51044 = _49merge_parameters(_user_config_51053, _default_args_51044, _cmd_options_51047, 1);
        DeRefDS(_0);
        DeRefDS(_user_config_51053);
        _user_config_51053 = NOVALUE;

        /** pathopen.e:388		end for*/
        _i_51051 = _i_51051 + 1;
        goto L2; // [87] 60
L3: 
        ;
    }

    /** pathopen.e:391		default_args = merge_parameters( load_euphoria_config("./" & conf_file), default_args, cmd_options, 1 )*/
    Concat((object_ptr)&_26218, _26217, _conf_file_51045);
    _26219 = _48load_euphoria_config(_26218);
    _26218 = NOVALUE;
    RefDS(_default_args_51044);
    RefDS(_cmd_options_51047);
    _0 = _default_args_51044;
    _default_args_51044 = _49merge_parameters(_26219, _default_args_51044, _cmd_options_51047, 1);
    DeRefDS(_0);
    _26219 = NOVALUE;

    /** pathopen.e:394		env = strip_file_from_path( exe_path() )*/
    _26221 = _48exe_path();
    _0 = _env_51043;
    _env_51043 = _48strip_file_from_path(_26221);
    DeRef(_0);
    _26221 = NOVALUE;

    /** pathopen.e:395		default_args = merge_parameters( load_euphoria_config( env & conf_file ), default_args, cmd_options, 1 )*/
    if (IS_SEQUENCE(_env_51043) && IS_ATOM(_conf_file_51045)) {
    }
    else if (IS_ATOM(_env_51043) && IS_SEQUENCE(_conf_file_51045)) {
        Ref(_env_51043);
        Prepend(&_26223, _conf_file_51045, _env_51043);
    }
    else {
        Concat((object_ptr)&_26223, _env_51043, _conf_file_51045);
    }
    _26224 = _48load_euphoria_config(_26223);
    _26223 = NOVALUE;
    RefDS(_default_args_51044);
    RefDS(_cmd_options_51047);
    _0 = _default_args_51044;
    _default_args_51044 = _49merge_parameters(_26224, _default_args_51044, _cmd_options_51047, 1);
    DeRefDS(_0);
    _26224 = NOVALUE;

    /** pathopen.e:398		ifdef UNIX then*/

    /** pathopen.e:407			env = getenv( "ALLUSERSPROFILE" )*/
    DeRef(_env_51043);
    _env_51043 = EGetEnv(_26228);

    /** pathopen.e:408			if sequence(env) then*/
    _26230 = IS_SEQUENCE(_env_51043);
    if (_26230 == 0)
    {
        _26230 = NOVALUE;
        goto L4; // [151] 179
    }
    else{
        _26230 = NOVALUE;
    }

    /** pathopen.e:409				default_args = merge_parameters( load_euphoria_config( expand_path( "euphoria", env ) & conf_file ), default_args, cmd_options, 1 )*/
    RefDS(_26231);
    Ref(_env_51043);
    _26232 = _48expand_path(_26231, _env_51043);
    if (IS_SEQUENCE(_26232) && IS_ATOM(_conf_file_51045)) {
    }
    else if (IS_ATOM(_26232) && IS_SEQUENCE(_conf_file_51045)) {
        Ref(_26232);
        Prepend(&_26233, _conf_file_51045, _26232);
    }
    else {
        Concat((object_ptr)&_26233, _26232, _conf_file_51045);
        DeRef(_26232);
        _26232 = NOVALUE;
    }
    DeRef(_26232);
    _26232 = NOVALUE;
    _26234 = _48load_euphoria_config(_26233);
    _26233 = NOVALUE;
    RefDS(_default_args_51044);
    RefDS(_cmd_options_51047);
    _0 = _default_args_51044;
    _default_args_51044 = _49merge_parameters(_26234, _default_args_51044, _cmd_options_51047, 1);
    DeRefDS(_0);
    _26234 = NOVALUE;
L4: 

    /** pathopen.e:412			env = getenv( "APPDATA" )*/
    DeRef(_env_51043);
    _env_51043 = EGetEnv(_26236);

    /** pathopen.e:413			if sequence(env) then*/
    _26238 = IS_SEQUENCE(_env_51043);
    if (_26238 == 0)
    {
        _26238 = NOVALUE;
        goto L5; // [189] 217
    }
    else{
        _26238 = NOVALUE;
    }

    /** pathopen.e:414				default_args = merge_parameters( load_euphoria_config( expand_path( "euphoria", env ) & conf_file ), default_args, cmd_options, 1 )*/
    RefDS(_26231);
    Ref(_env_51043);
    _26239 = _48expand_path(_26231, _env_51043);
    if (IS_SEQUENCE(_26239) && IS_ATOM(_conf_file_51045)) {
    }
    else if (IS_ATOM(_26239) && IS_SEQUENCE(_conf_file_51045)) {
        Ref(_26239);
        Prepend(&_26240, _conf_file_51045, _26239);
    }
    else {
        Concat((object_ptr)&_26240, _26239, _conf_file_51045);
        DeRef(_26239);
        _26239 = NOVALUE;
    }
    DeRef(_26239);
    _26239 = NOVALUE;
    _26241 = _48load_euphoria_config(_26240);
    _26240 = NOVALUE;
    RefDS(_default_args_51044);
    RefDS(_cmd_options_51047);
    _0 = _default_args_51044;
    _default_args_51044 = _49merge_parameters(_26241, _default_args_51044, _cmd_options_51047, 1);
    DeRefDS(_0);
    _26241 = NOVALUE;
L5: 

    /** pathopen.e:417			env = getenv( "HOMEPATH" )*/
    DeRef(_env_51043);
    _env_51043 = EGetEnv(_26243);

    /** pathopen.e:418			if sequence(env) then*/
    _26245 = IS_SEQUENCE(_env_51043);
    if (_26245 == 0)
    {
        _26245 = NOVALUE;
        goto L6; // [227] 256
    }
    else{
        _26245 = NOVALUE;
    }

    /** pathopen.e:419				default_args = merge_parameters( load_euphoria_config( getenv( "HOMEDRIVE" ) & env & "\\" & conf_file ), default_args, cmd_options, 1 )*/
    _26247 = EGetEnv(_26246);
    {
        object concat_list[4];

        concat_list[0] = _conf_file_51045;
        concat_list[1] = _23889;
        concat_list[2] = _env_51043;
        concat_list[3] = _26247;
        Concat_N((object_ptr)&_26248, concat_list, 4);
    }
    DeRef(_26247);
    _26247 = NOVALUE;
    _26249 = _48load_euphoria_config(_26248);
    _26248 = NOVALUE;
    RefDS(_default_args_51044);
    RefDS(_cmd_options_51047);
    _0 = _default_args_51044;
    _default_args_51044 = _49merge_parameters(_26249, _default_args_51044, _cmd_options_51047, 1);
    DeRefDS(_0);
    _26249 = NOVALUE;
L6: 

    /** pathopen.e:427		env = get_eudir()*/
    _0 = _env_51043;
    _env_51043 = _37get_eudir();
    DeRef(_0);

    /** pathopen.e:428		if sequence(env) then*/
    _26252 = IS_SEQUENCE(_env_51043);
    if (_26252 == 0)
    {
        _26252 = NOVALUE;
        goto L7; // [266] 291
    }
    else{
        _26252 = NOVALUE;
    }

    /** pathopen.e:429			default_args = merge_parameters( load_euphoria_config(env & "/" & conf_file), default_args, cmd_options, 1 )*/
    {
        object concat_list[3];

        concat_list[0] = _conf_file_51045;
        concat_list[1] = _23766;
        concat_list[2] = _env_51043;
        Concat_N((object_ptr)&_26253, concat_list, 3);
    }
    _26254 = _48load_euphoria_config(_26253);
    _26253 = NOVALUE;
    RefDS(_default_args_51044);
    RefDS(_cmd_options_51047);
    _0 = _default_args_51044;
    _default_args_51044 = _49merge_parameters(_26254, _default_args_51044, _cmd_options_51047, 1);
    DeRefDS(_0);
    _26254 = NOVALUE;
L7: 

    /** pathopen.e:432		return default_args*/
    DeRefDS(_user_files_51042);
    DeRef(_env_51043);
    DeRefi(_conf_file_51045);
    DeRef(_cmd_options_51047);
    return _default_args_51044;
    ;
}


object _48ConfPath(object _file_name_51110)
{
    object _file_path_51111 = NOVALUE;
    object _try_51112 = NOVALUE;
    object _26261 = NOVALUE;
    object _26257 = NOVALUE;
    object _26256 = NOVALUE;
    object _0, _1, _2;
    

    /** pathopen.e:440		for i = 1 to length(config_inc_paths) do*/
    if (IS_SEQUENCE(_48config_inc_paths_50727)){
            _26256 = SEQ_PTR(_48config_inc_paths_50727)->length;
    }
    else {
        _26256 = 1;
    }
    {
        object _i_51114;
        _i_51114 = 1;
L1: 
        if (_i_51114 > _26256){
            goto L2; // [10] 60
        }

        /** pathopen.e:441			file_path = config_inc_paths[i] & file_name*/
        _2 = (object)SEQ_PTR(_48config_inc_paths_50727);
        _26257 = (object)*(((s1_ptr)_2)->base + _i_51114);
        Concat((object_ptr)&_file_path_51111, _26257, _file_name_51110);
        _26257 = NOVALUE;
        _26257 = NOVALUE;

        /** pathopen.e:442			try = open( file_path, "r" )*/
        _try_51112 = EOpen(_file_path_51111, _26128, 0);

        /** pathopen.e:443			if try != -1 then*/
        if (_try_51112 == -1)
        goto L3; // [38] 53

        /** pathopen.e:444				return {file_path, try}*/
        RefDS(_file_path_51111);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _file_path_51111;
        ((intptr_t *)_2)[2] = _try_51112;
        _26261 = MAKE_SEQ(_1);
        DeRefDS(_file_name_51110);
        DeRefDS(_file_path_51111);
        return _26261;
L3: 

        /** pathopen.e:446		end for*/
        _i_51114 = _i_51114 + 1;
        goto L1; // [55] 17
L2: 
        ;
    }

    /** pathopen.e:447		return -1*/
    DeRefDS(_file_name_51110);
    DeRef(_file_path_51111);
    DeRef(_26261);
    _26261 = NOVALUE;
    return -1;
    ;
}


object _48ScanPath(object _file_name_51124, object _env_51125, object _flag_51126)
{
    object _inc_path_51127 = NOVALUE;
    object _full_path_51128 = NOVALUE;
    object _file_path_51129 = NOVALUE;
    object _strings_51130 = NOVALUE;
    object _end_path_51131 = NOVALUE;
    object _start_path_51132 = NOVALUE;
    object _try_51133 = NOVALUE;
    object _use_cache_51134 = NOVALUE;
    object _pos_51135 = NOVALUE;
    object _26339 = NOVALUE;
    object _26338 = NOVALUE;
    object _26337 = NOVALUE;
    object _26336 = NOVALUE;
    object _26335 = NOVALUE;
    object _26334 = NOVALUE;
    object _26333 = NOVALUE;
    object _26332 = NOVALUE;
    object _26331 = NOVALUE;
    object _26330 = NOVALUE;
    object _26329 = NOVALUE;
    object _26328 = NOVALUE;
    object _26327 = NOVALUE;
    object _26326 = NOVALUE;
    object _26325 = NOVALUE;
    object _26324 = NOVALUE;
    object _26319 = NOVALUE;
    object _26318 = NOVALUE;
    object _26317 = NOVALUE;
    object _26316 = NOVALUE;
    object _26315 = NOVALUE;
    object _26311 = NOVALUE;
    object _26310 = NOVALUE;
    object _26309 = NOVALUE;
    object _26308 = NOVALUE;
    object _26307 = NOVALUE;
    object _26306 = NOVALUE;
    object _26304 = NOVALUE;
    object _26302 = NOVALUE;
    object _26301 = NOVALUE;
    object _26299 = NOVALUE;
    object _26298 = NOVALUE;
    object _26297 = NOVALUE;
    object _26294 = NOVALUE;
    object _26293 = NOVALUE;
    object _26291 = NOVALUE;
    object _26290 = NOVALUE;
    object _26289 = NOVALUE;
    object _26287 = NOVALUE;
    object _26285 = NOVALUE;
    object _26280 = NOVALUE;
    object _26279 = NOVALUE;
    object _26278 = NOVALUE;
    object _26277 = NOVALUE;
    object _26276 = NOVALUE;
    object _26271 = NOVALUE;
    object _26263 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** pathopen.e:459		inc_path = getenv(env)*/
    DeRefi(_inc_path_51127);
    _inc_path_51127 = EGetEnv(_env_51125);

    /** pathopen.e:460		if compare(inc_path,{})!=1 then -- nothing to do, just fail*/
    if (IS_ATOM_INT(_inc_path_51127) && IS_ATOM_INT(_22190)){
        _26263 = (_inc_path_51127 < _22190) ? -1 : (_inc_path_51127 > _22190);
    }
    else{
        _26263 = compare(_inc_path_51127, _22190);
    }
    if (_26263 == 1)
    goto L1; // [18] 29

    /** pathopen.e:461			return -1*/
    DeRefDS(_file_name_51124);
    DeRefDSi(_env_51125);
    DeRefi(_inc_path_51127);
    DeRef(_full_path_51128);
    DeRef(_file_path_51129);
    DeRef(_strings_51130);
    return -1;
L1: 

    /** pathopen.e:464		num_var = find(env,cache_vars)*/
    _48num_var_50718 = find_from(_env_51125, _48cache_vars_50719, 1);

    /** pathopen.e:465		use_cache = check_cache(env,inc_path)*/
    RefDS(_env_51125);
    Ref(_inc_path_51127);
    _use_cache_51134 = _48check_cache(_env_51125, _inc_path_51127);
    if (!IS_ATOM_INT(_use_cache_51134)) {
        _1 = (object)(DBL_PTR(_use_cache_51134)->dbl);
        DeRefDS(_use_cache_51134);
        _use_cache_51134 = _1;
    }

    /** pathopen.e:466		inc_path = append(inc_path, PATH_SEPARATOR)*/
    Append(&_inc_path_51127, _inc_path_51127, 59);

    /** pathopen.e:468		file_name = SLASH & file_name*/
    Prepend(&_file_name_51124, _file_name_51124, 92);

    /** pathopen.e:469		if flag then*/
    if (_flag_51126 == 0)
    {
        goto L2; // [65] 77
    }
    else{
    }

    /** pathopen.e:470			file_name = include_subfolder & file_name*/
    Concat((object_ptr)&_file_name_51124, _48include_subfolder_50714, _file_name_51124);
L2: 

    /** pathopen.e:472		strings = cache_substrings[num_var]*/
    DeRef(_strings_51130);
    _2 = (object)SEQ_PTR(_48cache_substrings_50721);
    _strings_51130 = (object)*(((s1_ptr)_2)->base + _48num_var_50718);
    RefDS(_strings_51130);

    /** pathopen.e:474		if use_cache then*/
    if (_use_cache_51134 == 0)
    {
        goto L3; // [91] 292
    }
    else{
    }

    /** pathopen.e:475			for i=1 to length(strings) do*/
    if (IS_SEQUENCE(_strings_51130)){
            _26271 = SEQ_PTR(_strings_51130)->length;
    }
    else {
        _26271 = 1;
    }
    {
        object _i_51151;
        _i_51151 = 1;
L4: 
        if (_i_51151 > _26271){
            goto L5; // [99] 252
        }

        /** pathopen.e:476				full_path = strings[i]*/
        DeRef(_full_path_51128);
        _2 = (object)SEQ_PTR(_strings_51130);
        _full_path_51128 = (object)*(((s1_ptr)_2)->base + _i_51151);
        Ref(_full_path_51128);

        /** pathopen.e:477				file_path = full_path & file_name*/
        Concat((object_ptr)&_file_path_51129, _full_path_51128, _file_name_51124);

        /** pathopen.e:478				try = open_locked(file_path)    */
        RefDS(_file_path_51129);
        _try_51133 = _37open_locked(_file_path_51129);
        if (!IS_ATOM_INT(_try_51133)) {
            _1 = (object)(DBL_PTR(_try_51133)->dbl);
            DeRefDS(_try_51133);
            _try_51133 = _1;
        }

        /** pathopen.e:479				if try != -1 then*/
        if (_try_51133 == -1)
        goto L6; // [130] 145

        /** pathopen.e:480					return {file_path,try}*/
        RefDS(_file_path_51129);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _file_path_51129;
        ((intptr_t *)_2)[2] = _try_51133;
        _26276 = MAKE_SEQ(_1);
        DeRefDS(_file_name_51124);
        DeRefDSi(_env_51125);
        DeRefi(_inc_path_51127);
        DeRefDS(_full_path_51128);
        DeRefDS(_file_path_51129);
        DeRefDS(_strings_51130);
        return _26276;
L6: 

        /** pathopen.e:482				ifdef WINDOWS then */

        /** pathopen.e:483					if sequence(cache_converted[num_var][i]) then*/
        _2 = (object)SEQ_PTR(_48cache_converted_50724);
        _26277 = (object)*(((s1_ptr)_2)->base + _48num_var_50718);
        _2 = (object)SEQ_PTR(_26277);
        _26278 = (object)*(((s1_ptr)_2)->base + _i_51151);
        _26277 = NOVALUE;
        _26279 = IS_SEQUENCE(_26278);
        _26278 = NOVALUE;
        if (_26279 == 0)
        {
            _26279 = NOVALUE;
            goto L7; // [164] 245
        }
        else{
            _26279 = NOVALUE;
        }

        /** pathopen.e:486						full_path = cache_converted[num_var][i]*/
        _2 = (object)SEQ_PTR(_48cache_converted_50724);
        _26280 = (object)*(((s1_ptr)_2)->base + _48num_var_50718);
        DeRef(_full_path_51128);
        _2 = (object)SEQ_PTR(_26280);
        _full_path_51128 = (object)*(((s1_ptr)_2)->base + _i_51151);
        Ref(_full_path_51128);
        _26280 = NOVALUE;

        /** pathopen.e:487						file_path = full_path & file_name*/
        Concat((object_ptr)&_file_path_51129, _full_path_51128, _file_name_51124);

        /** pathopen.e:488						try = open_locked(file_path)*/
        RefDS(_file_path_51129);
        _try_51133 = _37open_locked(_file_path_51129);
        if (!IS_ATOM_INT(_try_51133)) {
            _1 = (object)(DBL_PTR(_try_51133)->dbl);
            DeRefDS(_try_51133);
            _try_51133 = _1;
        }

        /** pathopen.e:489						if try != -1 then*/
        if (_try_51133 == -1)
        goto L8; // [199] 244

        /** pathopen.e:490							cache_converted[num_var][i] = 0*/
        _2 = (object)SEQ_PTR(_48cache_converted_50724);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _48cache_converted_50724 = MAKE_SEQ(_2);
        }
        _3 = (object)(_48num_var_50718 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_51151);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = 0;
        DeRef(_1);
        _26285 = NOVALUE;

        /** pathopen.e:491							cache_substrings[num_var][i] = full_path*/
        _2 = (object)SEQ_PTR(_48cache_substrings_50721);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _48cache_substrings_50721 = MAKE_SEQ(_2);
        }
        _3 = (object)(_48num_var_50718 + ((s1_ptr)_2)->base);
        RefDS(_full_path_51128);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_51151);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _full_path_51128;
        DeRef(_1);
        _26287 = NOVALUE;

        /** pathopen.e:492							return {file_path,try}*/
        RefDS(_file_path_51129);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _file_path_51129;
        ((intptr_t *)_2)[2] = _try_51133;
        _26289 = MAKE_SEQ(_1);
        DeRefDS(_file_name_51124);
        DeRefDSi(_env_51125);
        DeRefi(_inc_path_51127);
        DeRefDS(_full_path_51128);
        DeRefDS(_file_path_51129);
        DeRef(_strings_51130);
        DeRef(_26276);
        _26276 = NOVALUE;
        return _26289;
L8: 
L7: 

        /** pathopen.e:496			end for*/
        _i_51151 = _i_51151 + 1;
        goto L4; // [247] 106
L5: 
        ;
    }

    /** pathopen.e:497			if cache_complete[num_var] then -- nothing to scan*/
    _2 = (object)SEQ_PTR(_48cache_complete_50725);
    _26290 = (object)*(((s1_ptr)_2)->base + _48num_var_50718);
    if (_26290 == 0)
    {
        _26290 = NOVALUE;
        goto L9; // [262] 274
    }
    else{
        _26290 = NOVALUE;
    }

    /** pathopen.e:498				return -1*/
    DeRefDS(_file_name_51124);
    DeRefDSi(_env_51125);
    DeRefi(_inc_path_51127);
    DeRef(_full_path_51128);
    DeRef(_file_path_51129);
    DeRef(_strings_51130);
    DeRef(_26276);
    _26276 = NOVALUE;
    DeRef(_26289);
    _26289 = NOVALUE;
    return -1;
    goto LA; // [271] 298
L9: 

    /** pathopen.e:500				pos = cache_delims[num_var]+1 -- scan remainder, starting from as far sa possible*/
    _2 = (object)SEQ_PTR(_48cache_delims_50726);
    _26291 = (object)*(((s1_ptr)_2)->base + _48num_var_50718);
    _pos_51135 = _26291 + 1;
    _26291 = NOVALUE;
    goto LA; // [289] 298
L3: 

    /** pathopen.e:503			pos = 1*/
    _pos_51135 = 1;
LA: 

    /** pathopen.e:506		start_path = 0*/
    _start_path_51132 = 0;

    /** pathopen.e:507		for p = pos to length(inc_path) do*/
    if (IS_SEQUENCE(_inc_path_51127)){
            _26293 = SEQ_PTR(_inc_path_51127)->length;
    }
    else {
        _26293 = 1;
    }
    {
        object _p_51183;
        _p_51183 = _pos_51135;
LB: 
        if (_p_51183 > _26293){
            goto LC; // [310] 716
        }

        /** pathopen.e:508			if inc_path[p] = PATH_SEPARATOR then*/
        _2 = (object)SEQ_PTR(_inc_path_51127);
        _26294 = (object)*(((s1_ptr)_2)->base + _p_51183);
        if (_26294 != 59)
        goto LD; // [325] 665

        /** pathopen.e:510				cache_delims[num_var] = p*/
        _2 = (object)SEQ_PTR(_48cache_delims_50726);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _48cache_delims_50726 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _48num_var_50718);
        *(intptr_t *)_2 = _p_51183;

        /** pathopen.e:512				end_path = p-1*/
        _end_path_51131 = _p_51183 - 1;

        /** pathopen.e:513				while end_path >= start_path and find(inc_path[end_path], " \t" & SLASH_CHARS) do*/
LE: 
        _26297 = (_end_path_51131 >= _start_path_51132);
        if (_26297 == 0) {
            goto LF; // [354] 388
        }
        _2 = (object)SEQ_PTR(_inc_path_51127);
        _26299 = (object)*(((s1_ptr)_2)->base + _end_path_51131);
        Concat((object_ptr)&_26301, _26300, _46SLASH_CHARS_21935);
        _26302 = find_from(_26299, _26301, 1);
        _26299 = NOVALUE;
        DeRefDS(_26301);
        _26301 = NOVALUE;
        if (_26302 == 0)
        {
            _26302 = NOVALUE;
            goto LF; // [374] 388
        }
        else{
            _26302 = NOVALUE;
        }

        /** pathopen.e:514					end_path-=1*/
        _end_path_51131 = _end_path_51131 - 1;

        /** pathopen.e:515				end while*/
        goto LE; // [385] 350
LF: 

        /** pathopen.e:517				if start_path and end_path then*/
        if (_start_path_51132 == 0) {
            goto L10; // [390] 709
        }
        if (_end_path_51131 == 0)
        {
            goto L10; // [395] 709
        }
        else{
        }

        /** pathopen.e:518					full_path = inc_path[start_path..end_path]*/
        rhs_slice_target = (object_ptr)&_full_path_51128;
        RHS_Slice(_inc_path_51127, _start_path_51132, _end_path_51131);

        /** pathopen.e:519					cache_substrings[num_var] = append(cache_substrings[num_var],full_path)*/
        _2 = (object)SEQ_PTR(_48cache_substrings_50721);
        _26306 = (object)*(((s1_ptr)_2)->base + _48num_var_50718);
        RefDS(_full_path_51128);
        Append(&_26307, _26306, _full_path_51128);
        _26306 = NOVALUE;
        _2 = (object)SEQ_PTR(_48cache_substrings_50721);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _48cache_substrings_50721 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _48num_var_50718);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _26307;
        if( _1 != _26307 ){
            DeRefDS(_1);
        }
        _26307 = NOVALUE;

        /** pathopen.e:520					cache_starts[num_var] &= start_path*/
        _2 = (object)SEQ_PTR(_48cache_starts_50722);
        _26308 = (object)*(((s1_ptr)_2)->base + _48num_var_50718);
        if (IS_SEQUENCE(_26308) && IS_ATOM(_start_path_51132)) {
            Append(&_26309, _26308, _start_path_51132);
        }
        else if (IS_ATOM(_26308) && IS_SEQUENCE(_start_path_51132)) {
        }
        else {
            Concat((object_ptr)&_26309, _26308, _start_path_51132);
            _26308 = NOVALUE;
        }
        _26308 = NOVALUE;
        _2 = (object)SEQ_PTR(_48cache_starts_50722);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _48cache_starts_50722 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _48num_var_50718);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _26309;
        if( _1 != _26309 ){
            DeRef(_1);
        }
        _26309 = NOVALUE;

        /** pathopen.e:521					cache_ends[num_var] &= end_path*/
        _2 = (object)SEQ_PTR(_48cache_ends_50723);
        _26310 = (object)*(((s1_ptr)_2)->base + _48num_var_50718);
        if (IS_SEQUENCE(_26310) && IS_ATOM(_end_path_51131)) {
            Append(&_26311, _26310, _end_path_51131);
        }
        else if (IS_ATOM(_26310) && IS_SEQUENCE(_end_path_51131)) {
        }
        else {
            Concat((object_ptr)&_26311, _26310, _end_path_51131);
            _26310 = NOVALUE;
        }
        _26310 = NOVALUE;
        _2 = (object)SEQ_PTR(_48cache_ends_50723);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _48cache_ends_50723 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _48num_var_50718);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _26311;
        if( _1 != _26311 ){
            DeRef(_1);
        }
        _26311 = NOVALUE;

        /** pathopen.e:522					file_path = full_path & file_name  */
        Concat((object_ptr)&_file_path_51129, _full_path_51128, _file_name_51124);

        /** pathopen.e:523					try = open_locked(file_path)*/
        RefDS(_file_path_51129);
        _try_51133 = _37open_locked(_file_path_51129);
        if (!IS_ATOM_INT(_try_51133)) {
            _1 = (object)(DBL_PTR(_try_51133)->dbl);
            DeRefDS(_try_51133);
            _try_51133 = _1;
        }

        /** pathopen.e:524					if try != -1 then -- valid path, no point trying to convert*/
        if (_try_51133 == -1)
        goto L11; // [479] 514

        /** pathopen.e:525						ifdef WINDOWS then*/

        /** pathopen.e:526							cache_converted[num_var] &= 0*/
        _2 = (object)SEQ_PTR(_48cache_converted_50724);
        _26315 = (object)*(((s1_ptr)_2)->base + _48num_var_50718);
        if (IS_SEQUENCE(_26315) && IS_ATOM(0)) {
            Append(&_26316, _26315, 0);
        }
        else if (IS_ATOM(_26315) && IS_SEQUENCE(0)) {
        }
        else {
            Concat((object_ptr)&_26316, _26315, 0);
            _26315 = NOVALUE;
        }
        _26315 = NOVALUE;
        _2 = (object)SEQ_PTR(_48cache_converted_50724);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _48cache_converted_50724 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _48num_var_50718);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _26316;
        if( _1 != _26316 ){
            DeRef(_1);
        }
        _26316 = NOVALUE;

        /** pathopen.e:528						return {file_path,try}*/
        RefDS(_file_path_51129);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _file_path_51129;
        ((intptr_t *)_2)[2] = _try_51133;
        _26317 = MAKE_SEQ(_1);
        DeRefDS(_file_name_51124);
        DeRefDSi(_env_51125);
        DeRefi(_inc_path_51127);
        DeRefDSi(_full_path_51128);
        DeRefDS(_file_path_51129);
        DeRef(_strings_51130);
        DeRef(_26297);
        _26297 = NOVALUE;
        DeRef(_26276);
        _26276 = NOVALUE;
        DeRef(_26289);
        _26289 = NOVALUE;
        _26294 = NOVALUE;
        return _26317;
L11: 

        /** pathopen.e:530					ifdef WINDOWS then*/

        /** pathopen.e:531						if find(1, full_path>=128) then*/
        _26318 = binary_op(GREATEREQ, _full_path_51128, 128);
        _26319 = find_from(1, _26318, 1);
        DeRefDS(_26318);
        _26318 = NOVALUE;
        if (_26319 == 0)
        {
            _26319 = NOVALUE;
            goto L12; // [527] 637
        }
        else{
            _26319 = NOVALUE;
        }

        /** pathopen.e:533							full_path = convert_from_OEM(full_path)*/
        RefDS(_full_path_51128);
        _0 = _full_path_51128;
        _full_path_51128 = _48convert_from_OEM(_full_path_51128);
        DeRefDS(_0);

        /** pathopen.e:534							file_path = full_path & file_name*/
        Concat((object_ptr)&_file_path_51129, _full_path_51128, _file_name_51124);

        /** pathopen.e:535							try = open_locked(file_path)*/
        RefDS(_file_path_51129);
        _try_51133 = _37open_locked(_file_path_51129);
        if (!IS_ATOM_INT(_try_51133)) {
            _1 = (object)(DBL_PTR(_try_51133)->dbl);
            DeRefDS(_try_51133);
            _try_51133 = _1;
        }

        /** pathopen.e:536							if try != -1 then -- that was it; record translation as the valid path*/
        if (_try_51133 == -1)
        goto L13; // [554] 611

        /** pathopen.e:537								cache_converted[num_var] &= 0*/
        _2 = (object)SEQ_PTR(_48cache_converted_50724);
        _26324 = (object)*(((s1_ptr)_2)->base + _48num_var_50718);
        if (IS_SEQUENCE(_26324) && IS_ATOM(0)) {
            Append(&_26325, _26324, 0);
        }
        else if (IS_ATOM(_26324) && IS_SEQUENCE(0)) {
        }
        else {
            Concat((object_ptr)&_26325, _26324, 0);
            _26324 = NOVALUE;
        }
        _26324 = NOVALUE;
        _2 = (object)SEQ_PTR(_48cache_converted_50724);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _48cache_converted_50724 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _48num_var_50718);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _26325;
        if( _1 != _26325 ){
            DeRef(_1);
        }
        _26325 = NOVALUE;

        /** pathopen.e:538								cache_substrings[num_var] = append(cache_substrings[num_var],full_path)*/
        _2 = (object)SEQ_PTR(_48cache_substrings_50721);
        _26326 = (object)*(((s1_ptr)_2)->base + _48num_var_50718);
        RefDS(_full_path_51128);
        Append(&_26327, _26326, _full_path_51128);
        _26326 = NOVALUE;
        _2 = (object)SEQ_PTR(_48cache_substrings_50721);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _48cache_substrings_50721 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _48num_var_50718);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _26327;
        if( _1 != _26327 ){
            DeRefDS(_1);
        }
        _26327 = NOVALUE;

        /** pathopen.e:539								return {file_path,try}*/
        RefDS(_file_path_51129);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _file_path_51129;
        ((intptr_t *)_2)[2] = _try_51133;
        _26328 = MAKE_SEQ(_1);
        DeRefDS(_file_name_51124);
        DeRefDSi(_env_51125);
        DeRefi(_inc_path_51127);
        DeRefDS(_full_path_51128);
        DeRefDS(_file_path_51129);
        DeRef(_strings_51130);
        DeRef(_26297);
        _26297 = NOVALUE;
        DeRef(_26276);
        _26276 = NOVALUE;
        DeRef(_26289);
        _26289 = NOVALUE;
        DeRef(_26317);
        _26317 = NOVALUE;
        _26294 = NOVALUE;
        return _26328;
        goto L14; // [608] 656
L13: 

        /** pathopen.e:541								cache_converted[num_var] = append(cache_converted[num_var],full_path)*/
        _2 = (object)SEQ_PTR(_48cache_converted_50724);
        _26329 = (object)*(((s1_ptr)_2)->base + _48num_var_50718);
        RefDS(_full_path_51128);
        Append(&_26330, _26329, _full_path_51128);
        _26329 = NOVALUE;
        _2 = (object)SEQ_PTR(_48cache_converted_50724);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _48cache_converted_50724 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _48num_var_50718);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _26330;
        if( _1 != _26330 ){
            DeRef(_1);
        }
        _26330 = NOVALUE;
        goto L14; // [634] 656
L12: 

        /** pathopen.e:544							cache_converted[num_var] &= 0*/
        _2 = (object)SEQ_PTR(_48cache_converted_50724);
        _26331 = (object)*(((s1_ptr)_2)->base + _48num_var_50718);
        if (IS_SEQUENCE(_26331) && IS_ATOM(0)) {
            Append(&_26332, _26331, 0);
        }
        else if (IS_ATOM(_26331) && IS_SEQUENCE(0)) {
        }
        else {
            Concat((object_ptr)&_26332, _26331, 0);
            _26331 = NOVALUE;
        }
        _26331 = NOVALUE;
        _2 = (object)SEQ_PTR(_48cache_converted_50724);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _48cache_converted_50724 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _48num_var_50718);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _26332;
        if( _1 != _26332 ){
            DeRef(_1);
        }
        _26332 = NOVALUE;
L14: 

        /** pathopen.e:547					start_path = 0*/
        _start_path_51132 = 0;
        goto L10; // [662] 709
LD: 

        /** pathopen.e:549			elsif not start_path and (inc_path[p] != ' ' and inc_path[p] != '\t') then*/
        _26333 = (_start_path_51132 == 0);
        if (_26333 == 0) {
            goto L15; // [670] 708
        }
        _2 = (object)SEQ_PTR(_inc_path_51127);
        _26335 = (object)*(((s1_ptr)_2)->base + _p_51183);
        _26336 = (_26335 != 32);
        _26335 = NOVALUE;
        if (_26336 == 0) {
            DeRef(_26337);
            _26337 = 0;
            goto L16; // [682] 698
        }
        _2 = (object)SEQ_PTR(_inc_path_51127);
        _26338 = (object)*(((s1_ptr)_2)->base + _p_51183);
        _26339 = (_26338 != 9);
        _26338 = NOVALUE;
        _26337 = (_26339 != 0);
L16: 
        if (_26337 == 0)
        {
            _26337 = NOVALUE;
            goto L15; // [699] 708
        }
        else{
            _26337 = NOVALUE;
        }

        /** pathopen.e:550				start_path = p*/
        _start_path_51132 = _p_51183;
L15: 
L10: 

        /** pathopen.e:552		end for*/
        _p_51183 = _p_51183 + 1;
        goto LB; // [711] 317
LC: 
        ;
    }

    /** pathopen.e:554		cache_complete[num_var] = 1*/
    _2 = (object)SEQ_PTR(_48cache_complete_50725);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _48cache_complete_50725 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _48num_var_50718);
    *(intptr_t *)_2 = 1;

    /** pathopen.e:555		return -1*/
    DeRefDS(_file_name_51124);
    DeRefDSi(_env_51125);
    DeRefi(_inc_path_51127);
    DeRef(_full_path_51128);
    DeRef(_file_path_51129);
    DeRef(_strings_51130);
    DeRef(_26333);
    _26333 = NOVALUE;
    DeRef(_26297);
    _26297 = NOVALUE;
    DeRef(_26328);
    _26328 = NOVALUE;
    DeRef(_26276);
    _26276 = NOVALUE;
    DeRef(_26339);
    _26339 = NOVALUE;
    DeRef(_26289);
    _26289 = NOVALUE;
    DeRef(_26317);
    _26317 = NOVALUE;
    _26294 = NOVALUE;
    DeRef(_26336);
    _26336 = NOVALUE;
    return -1;
    ;
}


object _48Include_paths(object _add_converted_51247)
{
    object _status_51248 = NOVALUE;
    object _pos_51249 = NOVALUE;
    object _inc_path_51250 = NOVALUE;
    object _full_path_51251 = NOVALUE;
    object _start_path_51252 = NOVALUE;
    object _end_path_51253 = NOVALUE;
    object _eudir_path_51269 = NOVALUE;
    object _26400 = NOVALUE;
    object _26399 = NOVALUE;
    object _26398 = NOVALUE;
    object _26397 = NOVALUE;
    object _26396 = NOVALUE;
    object _26395 = NOVALUE;
    object _26394 = NOVALUE;
    object _26392 = NOVALUE;
    object _26391 = NOVALUE;
    object _26390 = NOVALUE;
    object _26389 = NOVALUE;
    object _26388 = NOVALUE;
    object _26387 = NOVALUE;
    object _26386 = NOVALUE;
    object _26385 = NOVALUE;
    object _26384 = NOVALUE;
    object _26383 = NOVALUE;
    object _26382 = NOVALUE;
    object _26381 = NOVALUE;
    object _26380 = NOVALUE;
    object _26379 = NOVALUE;
    object _26378 = NOVALUE;
    object _26377 = NOVALUE;
    object _26376 = NOVALUE;
    object _26375 = NOVALUE;
    object _26374 = NOVALUE;
    object _26373 = NOVALUE;
    object _26372 = NOVALUE;
    object _26370 = NOVALUE;
    object _26368 = NOVALUE;
    object _26367 = NOVALUE;
    object _26366 = NOVALUE;
    object _26365 = NOVALUE;
    object _26364 = NOVALUE;
    object _26361 = NOVALUE;
    object _26360 = NOVALUE;
    object _26358 = NOVALUE;
    object _26356 = NOVALUE;
    object _26354 = NOVALUE;
    object _26353 = NOVALUE;
    object _26351 = NOVALUE;
    object _26348 = NOVALUE;
    object _26346 = NOVALUE;
    object _26341 = NOVALUE;
    object _26340 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_add_converted_51247)) {
        _1 = (object)(DBL_PTR(_add_converted_51247)->dbl);
        DeRefDS(_add_converted_51247);
        _add_converted_51247 = _1;
    }

    /** pathopen.e:566		if length(include_Paths) then*/
    if (IS_SEQUENCE(_48include_Paths_51244)){
            _26340 = SEQ_PTR(_48include_Paths_51244)->length;
    }
    else {
        _26340 = 1;
    }
    if (_26340 == 0)
    {
        _26340 = NOVALUE;
        goto L1; // [10] 22
    }
    else{
        _26340 = NOVALUE;
    }

    /** pathopen.e:567			return include_Paths*/
    RefDS(_48include_Paths_51244);
    DeRefi(_inc_path_51250);
    DeRefi(_full_path_51251);
    DeRef(_eudir_path_51269);
    return _48include_Paths_51244;
L1: 

    /** pathopen.e:570		include_Paths = append(config_inc_paths, current_dir())*/
    _26341 = _17current_dir();
    Ref(_26341);
    Append(&_48include_Paths_51244, _48config_inc_paths_50727, _26341);
    DeRef(_26341);
    _26341 = NOVALUE;

    /** pathopen.e:571		num_var = find("EUINC", cache_vars)*/
    _48num_var_50718 = find_from(_26343, _48cache_vars_50719, 1);

    /** pathopen.e:572		inc_path = getenv("EUINC")*/
    DeRefi(_inc_path_51250);
    _inc_path_51250 = EGetEnv(_26343);

    /** pathopen.e:573		if atom(inc_path) then*/
    _26346 = IS_ATOM(_inc_path_51250);
    if (_26346 == 0)
    {
        _26346 = NOVALUE;
        goto L2; // [52] 61
    }
    else{
        _26346 = NOVALUE;
    }

    /** pathopen.e:574			inc_path = ""*/
    RefDS(_22190);
    DeRefi(_inc_path_51250);
    _inc_path_51250 = _22190;
L2: 

    /** pathopen.e:576		status = check_cache("EUINC", inc_path)*/
    RefDS(_26343);
    Ref(_inc_path_51250);
    _status_51248 = _48check_cache(_26343, _inc_path_51250);
    if (!IS_ATOM_INT(_status_51248)) {
        _1 = (object)(DBL_PTR(_status_51248)->dbl);
        DeRefDS(_status_51248);
        _status_51248 = _1;
    }

    /** pathopen.e:577		if length(inc_path) then*/
    if (IS_SEQUENCE(_inc_path_51250)){
            _26348 = SEQ_PTR(_inc_path_51250)->length;
    }
    else {
        _26348 = 1;
    }
    if (_26348 == 0)
    {
        _26348 = NOVALUE;
        goto L3; // [75] 87
    }
    else{
        _26348 = NOVALUE;
    }

    /** pathopen.e:578			inc_path = append(inc_path, PATH_SEPARATOR)*/
    Append(&_inc_path_51250, _inc_path_51250, 59);
L3: 

    /** pathopen.e:580		object eudir_path = get_eudir()*/
    _0 = _eudir_path_51269;
    _eudir_path_51269 = _37get_eudir();
    DeRef(_0);

    /** pathopen.e:581		if sequence(eudir_path) then*/
    _26351 = IS_SEQUENCE(_eudir_path_51269);
    if (_26351 == 0)
    {
        _26351 = NOVALUE;
        goto L4; // [97] 117
    }
    else{
        _26351 = NOVALUE;
    }

    /** pathopen.e:582			include_Paths = append(include_Paths, sprintf("%s/include", { eudir_path }))*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_eudir_path_51269);
    ((intptr_t*)_2)[1] = _eudir_path_51269;
    _26353 = MAKE_SEQ(_1);
    _26354 = EPrintf(-9999999, _26352, _26353);
    DeRefDS(_26353);
    _26353 = NOVALUE;
    RefDS(_26354);
    Append(&_48include_Paths_51244, _48include_Paths_51244, _26354);
    DeRefDS(_26354);
    _26354 = NOVALUE;
L4: 

    /** pathopen.e:585		if status then*/
    if (_status_51248 == 0)
    {
        goto L5; // [119] 161
    }
    else{
    }

    /** pathopen.e:587			if cache_complete[num_var] then*/
    _2 = (object)SEQ_PTR(_48cache_complete_50725);
    _26356 = (object)*(((s1_ptr)_2)->base + _48num_var_50718);
    if (_26356 == 0)
    {
        _26356 = NOVALUE;
        goto L6; // [132] 144
    }
    else{
        _26356 = NOVALUE;
    }

    /** pathopen.e:588				goto "cache done"*/
    goto G7;
L6: 

    /** pathopen.e:590			pos = cache_delims[num_var]+1*/
    _2 = (object)SEQ_PTR(_48cache_delims_50726);
    _26358 = (object)*(((s1_ptr)_2)->base + _48num_var_50718);
    _pos_51249 = _26358 + 1;
    _26358 = NOVALUE;
    goto L8; // [158] 167
L5: 

    /** pathopen.e:592	        pos = 1*/
    _pos_51249 = 1;
L8: 

    /** pathopen.e:594		start_path = 0*/
    _start_path_51252 = 0;

    /** pathopen.e:595		for p = pos to length(inc_path) do*/
    if (IS_SEQUENCE(_inc_path_51250)){
            _26360 = SEQ_PTR(_inc_path_51250)->length;
    }
    else {
        _26360 = 1;
    }
    {
        object _p_51286;
        _p_51286 = _pos_51249;
L9: 
        if (_p_51286 > _26360){
            goto LA; // [179] 456
        }

        /** pathopen.e:596			if inc_path[p] = PATH_SEPARATOR then*/
        _2 = (object)SEQ_PTR(_inc_path_51250);
        _26361 = (object)*(((s1_ptr)_2)->base + _p_51286);
        if (_26361 != 59)
        goto LB; // [194] 405

        /** pathopen.e:598				cache_delims[num_var] = p*/
        _2 = (object)SEQ_PTR(_48cache_delims_50726);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _48cache_delims_50726 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _48num_var_50718);
        *(intptr_t *)_2 = _p_51286;

        /** pathopen.e:600				end_path = p-1*/
        _end_path_51253 = _p_51286 - 1;

        /** pathopen.e:601				while end_path >= start_path and find(inc_path[end_path]," \t" & SLASH_CHARS) do*/
LC: 
        _26364 = (_end_path_51253 >= _start_path_51252);
        if (_26364 == 0) {
            goto LD; // [223] 257
        }
        _2 = (object)SEQ_PTR(_inc_path_51250);
        _26366 = (object)*(((s1_ptr)_2)->base + _end_path_51253);
        Concat((object_ptr)&_26367, _26300, _46SLASH_CHARS_21935);
        _26368 = find_from(_26366, _26367, 1);
        _26366 = NOVALUE;
        DeRefDS(_26367);
        _26367 = NOVALUE;
        if (_26368 == 0)
        {
            _26368 = NOVALUE;
            goto LD; // [243] 257
        }
        else{
            _26368 = NOVALUE;
        }

        /** pathopen.e:602					end_path -= 1*/
        _end_path_51253 = _end_path_51253 - 1;

        /** pathopen.e:603				end while*/
        goto LC; // [254] 219
LD: 

        /** pathopen.e:605				if start_path and end_path then*/
        if (_start_path_51252 == 0) {
            goto LE; // [259] 449
        }
        if (_end_path_51253 == 0)
        {
            goto LE; // [264] 449
        }
        else{
        }

        /** pathopen.e:606					full_path = inc_path[start_path..end_path]*/
        rhs_slice_target = (object_ptr)&_full_path_51251;
        RHS_Slice(_inc_path_51250, _start_path_51252, _end_path_51253);

        /** pathopen.e:607					cache_substrings[num_var] = append(cache_substrings[num_var],full_path)*/
        _2 = (object)SEQ_PTR(_48cache_substrings_50721);
        _26372 = (object)*(((s1_ptr)_2)->base + _48num_var_50718);
        RefDS(_full_path_51251);
        Append(&_26373, _26372, _full_path_51251);
        _26372 = NOVALUE;
        _2 = (object)SEQ_PTR(_48cache_substrings_50721);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _48cache_substrings_50721 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _48num_var_50718);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _26373;
        if( _1 != _26373 ){
            DeRefDS(_1);
        }
        _26373 = NOVALUE;

        /** pathopen.e:608					cache_starts[num_var] &= start_path*/
        _2 = (object)SEQ_PTR(_48cache_starts_50722);
        _26374 = (object)*(((s1_ptr)_2)->base + _48num_var_50718);
        if (IS_SEQUENCE(_26374) && IS_ATOM(_start_path_51252)) {
            Append(&_26375, _26374, _start_path_51252);
        }
        else if (IS_ATOM(_26374) && IS_SEQUENCE(_start_path_51252)) {
        }
        else {
            Concat((object_ptr)&_26375, _26374, _start_path_51252);
            _26374 = NOVALUE;
        }
        _26374 = NOVALUE;
        _2 = (object)SEQ_PTR(_48cache_starts_50722);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _48cache_starts_50722 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _48num_var_50718);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _26375;
        if( _1 != _26375 ){
            DeRef(_1);
        }
        _26375 = NOVALUE;

        /** pathopen.e:609					cache_ends[num_var] &= end_path*/
        _2 = (object)SEQ_PTR(_48cache_ends_50723);
        _26376 = (object)*(((s1_ptr)_2)->base + _48num_var_50718);
        if (IS_SEQUENCE(_26376) && IS_ATOM(_end_path_51253)) {
            Append(&_26377, _26376, _end_path_51253);
        }
        else if (IS_ATOM(_26376) && IS_SEQUENCE(_end_path_51253)) {
        }
        else {
            Concat((object_ptr)&_26377, _26376, _end_path_51253);
            _26376 = NOVALUE;
        }
        _26376 = NOVALUE;
        _2 = (object)SEQ_PTR(_48cache_ends_50723);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _48cache_ends_50723 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _48num_var_50718);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _26377;
        if( _1 != _26377 ){
            DeRef(_1);
        }
        _26377 = NOVALUE;

        /** pathopen.e:610					ifdef WINDOWS then*/

        /** pathopen.e:611						if find(1, full_path>=128) then*/
        _26378 = binary_op(GREATEREQ, _full_path_51251, 128);
        _26379 = find_from(1, _26378, 1);
        DeRefDS(_26378);
        _26378 = NOVALUE;
        if (_26379 == 0)
        {
            _26379 = NOVALUE;
            goto LF; // [345] 377
        }
        else{
            _26379 = NOVALUE;
        }

        /** pathopen.e:614							cache_converted[num_var] = append(cache_converted[num_var], */
        _2 = (object)SEQ_PTR(_48cache_converted_50724);
        _26380 = (object)*(((s1_ptr)_2)->base + _48num_var_50718);
        RefDS(_full_path_51251);
        _26381 = _48convert_from_OEM(_full_path_51251);
        Ref(_26381);
        Append(&_26382, _26380, _26381);
        _26380 = NOVALUE;
        DeRef(_26381);
        _26381 = NOVALUE;
        _2 = (object)SEQ_PTR(_48cache_converted_50724);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _48cache_converted_50724 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _48num_var_50718);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _26382;
        if( _1 != _26382 ){
            DeRef(_1);
        }
        _26382 = NOVALUE;
        goto L10; // [374] 396
LF: 

        /** pathopen.e:617							cache_converted[num_var] &= 0*/
        _2 = (object)SEQ_PTR(_48cache_converted_50724);
        _26383 = (object)*(((s1_ptr)_2)->base + _48num_var_50718);
        if (IS_SEQUENCE(_26383) && IS_ATOM(0)) {
            Append(&_26384, _26383, 0);
        }
        else if (IS_ATOM(_26383) && IS_SEQUENCE(0)) {
        }
        else {
            Concat((object_ptr)&_26384, _26383, 0);
            _26383 = NOVALUE;
        }
        _26383 = NOVALUE;
        _2 = (object)SEQ_PTR(_48cache_converted_50724);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _48cache_converted_50724 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _48num_var_50718);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _26384;
        if( _1 != _26384 ){
            DeRef(_1);
        }
        _26384 = NOVALUE;
L10: 

        /** pathopen.e:620					start_path = 0*/
        _start_path_51252 = 0;
        goto LE; // [402] 449
LB: 

        /** pathopen.e:622			elsif not start_path and (inc_path[p] != ' ' and inc_path[p] != '\t') then*/
        _26385 = (_start_path_51252 == 0);
        if (_26385 == 0) {
            goto L11; // [410] 448
        }
        _2 = (object)SEQ_PTR(_inc_path_51250);
        _26387 = (object)*(((s1_ptr)_2)->base + _p_51286);
        _26388 = (_26387 != 32);
        _26387 = NOVALUE;
        if (_26388 == 0) {
            DeRef(_26389);
            _26389 = 0;
            goto L12; // [422] 438
        }
        _2 = (object)SEQ_PTR(_inc_path_51250);
        _26390 = (object)*(((s1_ptr)_2)->base + _p_51286);
        _26391 = (_26390 != 9);
        _26390 = NOVALUE;
        _26389 = (_26391 != 0);
L12: 
        if (_26389 == 0)
        {
            _26389 = NOVALUE;
            goto L11; // [439] 448
        }
        else{
            _26389 = NOVALUE;
        }

        /** pathopen.e:623				start_path = p*/
        _start_path_51252 = _p_51286;
L11: 
LE: 

        /** pathopen.e:625		end for*/
        _p_51286 = _p_51286 + 1;
        goto L9; // [451] 186
LA: 
        ;
    }

    /** pathopen.e:627	label "cache done"*/
G7:

    /** pathopen.e:628		include_Paths &= cache_substrings[num_var]*/
    _2 = (object)SEQ_PTR(_48cache_substrings_50721);
    _26392 = (object)*(((s1_ptr)_2)->base + _48num_var_50718);
    Concat((object_ptr)&_48include_Paths_51244, _48include_Paths_51244, _26392);
    _26392 = NOVALUE;

    /** pathopen.e:629		cache_complete[num_var] = 1*/
    _2 = (object)SEQ_PTR(_48cache_complete_50725);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _48cache_complete_50725 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _48num_var_50718);
    *(intptr_t *)_2 = 1;

    /** pathopen.e:631		ifdef WINDOWS then*/

    /** pathopen.e:632			if add_converted then*/
    if (_add_converted_51247 == 0)
    {
        goto L13; // [490] 562
    }
    else{
    }

    /** pathopen.e:633		    	for i=1 to length(cache_converted[num_var]) do*/
    _2 = (object)SEQ_PTR(_48cache_converted_50724);
    _26394 = (object)*(((s1_ptr)_2)->base + _48num_var_50718);
    if (IS_SEQUENCE(_26394)){
            _26395 = SEQ_PTR(_26394)->length;
    }
    else {
        _26395 = 1;
    }
    _26394 = NOVALUE;
    {
        object _i_51331;
        _i_51331 = 1;
L14: 
        if (_i_51331 > _26395){
            goto L15; // [506] 561
        }

        /** pathopen.e:634		        	if sequence(cache_converted[num_var][i]) then*/
        _2 = (object)SEQ_PTR(_48cache_converted_50724);
        _26396 = (object)*(((s1_ptr)_2)->base + _48num_var_50718);
        _2 = (object)SEQ_PTR(_26396);
        _26397 = (object)*(((s1_ptr)_2)->base + _i_51331);
        _26396 = NOVALUE;
        _26398 = IS_SEQUENCE(_26397);
        _26397 = NOVALUE;
        if (_26398 == 0)
        {
            _26398 = NOVALUE;
            goto L16; // [530] 554
        }
        else{
            _26398 = NOVALUE;
        }

        /** pathopen.e:635			        	include_Paths = append(include_Paths, cache_converted[num_var][i])*/
        _2 = (object)SEQ_PTR(_48cache_converted_50724);
        _26399 = (object)*(((s1_ptr)_2)->base + _48num_var_50718);
        _2 = (object)SEQ_PTR(_26399);
        _26400 = (object)*(((s1_ptr)_2)->base + _i_51331);
        _26399 = NOVALUE;
        Ref(_26400);
        Append(&_48include_Paths_51244, _48include_Paths_51244, _26400);
        _26400 = NOVALUE;
L16: 

        /** pathopen.e:637				end for*/
        _i_51331 = _i_51331 + 1;
        goto L14; // [556] 513
L15: 
        ;
    }
L13: 

    /** pathopen.e:640		return include_Paths*/
    RefDS(_48include_Paths_51244);
    DeRefi(_inc_path_51250);
    DeRefi(_full_path_51251);
    DeRef(_eudir_path_51269);
    DeRef(_26364);
    _26364 = NOVALUE;
    DeRef(_26391);
    _26391 = NOVALUE;
    _26361 = NOVALUE;
    DeRef(_26388);
    _26388 = NOVALUE;
    DeRef(_26385);
    _26385 = NOVALUE;
    _26394 = NOVALUE;
    return _48include_Paths_51244;
    ;
}


object _48e_path_find(object _name_51343)
{
    object _scan_result_51344 = NOVALUE;
    object _26410 = NOVALUE;
    object _26409 = NOVALUE;
    object _26408 = NOVALUE;
    object _26405 = NOVALUE;
    object _26404 = NOVALUE;
    object _26403 = NOVALUE;
    object _26402 = NOVALUE;
    object _0, _1, _2;
    

    /** pathopen.e:656		if file_exists(name) then*/
    RefDS(_name_51343);
    _26402 = _17file_exists(_name_51343);
    if (_26402 == 0) {
        DeRef(_26402);
        _26402 = NOVALUE;
        goto L1; // [9] 19
    }
    else {
        if (!IS_ATOM_INT(_26402) && DBL_PTR(_26402)->dbl == 0.0){
            DeRef(_26402);
            _26402 = NOVALUE;
            goto L1; // [9] 19
        }
        DeRef(_26402);
        _26402 = NOVALUE;
    }
    DeRef(_26402);
    _26402 = NOVALUE;

    /** pathopen.e:657			return name*/
    DeRef(_scan_result_51344);
    return _name_51343;
L1: 

    /** pathopen.e:661		for i = 1 to length(SLASH_CHARS) do*/
    if (IS_SEQUENCE(_46SLASH_CHARS_21935)){
            _26403 = SEQ_PTR(_46SLASH_CHARS_21935)->length;
    }
    else {
        _26403 = 1;
    }
    {
        object _i_51349;
        _i_51349 = 1;
L2: 
        if (_i_51349 > _26403){
            goto L3; // [26] 63
        }

        /** pathopen.e:662			if find(SLASH_CHARS[i], name) then*/
        _2 = (object)SEQ_PTR(_46SLASH_CHARS_21935);
        _26404 = (object)*(((s1_ptr)_2)->base + _i_51349);
        _26405 = find_from(_26404, _name_51343, 1);
        _26404 = NOVALUE;
        if (_26405 == 0)
        {
            _26405 = NOVALUE;
            goto L4; // [46] 56
        }
        else{
            _26405 = NOVALUE;
        }

        /** pathopen.e:663				return -1*/
        DeRefDS(_name_51343);
        DeRef(_scan_result_51344);
        return -1;
L4: 

        /** pathopen.e:665		end for*/
        _i_51349 = _i_51349 + 1;
        goto L2; // [58] 33
L3: 
        ;
    }

    /** pathopen.e:667		scan_result = ScanPath(name, "PATH", 0)*/
    RefDS(_name_51343);
    RefDS(_26406);
    _0 = _scan_result_51344;
    _scan_result_51344 = _48ScanPath(_name_51343, _26406, 0);
    DeRef(_0);

    /** pathopen.e:668		if sequence(scan_result) then*/
    _26408 = IS_SEQUENCE(_scan_result_51344);
    if (_26408 == 0)
    {
        _26408 = NOVALUE;
        goto L5; // [76] 98
    }
    else{
        _26408 = NOVALUE;
    }

    /** pathopen.e:669			close(scan_result[2])*/
    _2 = (object)SEQ_PTR(_scan_result_51344);
    _26409 = (object)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_26409))
    EClose(_26409);
    else
    EClose((object)DBL_PTR(_26409)->dbl);
    _26409 = NOVALUE;

    /** pathopen.e:670			return scan_result[1]*/
    _2 = (object)SEQ_PTR(_scan_result_51344);
    _26410 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_26410);
    DeRefDS(_name_51343);
    DeRef(_scan_result_51344);
    return _26410;
L5: 

    /** pathopen.e:673		return -1*/
    DeRefDS(_name_51343);
    DeRef(_scan_result_51344);
    _26410 = NOVALUE;
    return -1;
    ;
}



// 0x4B34E519
